// AI 工具定义与执行器：DeepSeek 函数调用 → 法律工作台域操作 → 实时上板
import crypto from 'node:crypto';
import * as store from './store.js';
import { broadcast } from './sse.js';
import { projectCase, computeStats, KANBAN_COLUMNS } from './board.js';

export const TOOL_CN = {
  case_get: '读取案件信息',
  case_update: '更新案件信息',
  party_add: '登记当事人',
  evidence_add: '登记证据',
  evidence_status: '更新证据状态',
  claim_add: '登记主张/争点',
  claim_link: '关联证据与主张',
  deadline_add: '登记期限',
  event_add: '登记日程',
  research_note_save: '沉淀检索记录',
  minutes_save: '保存会话纪要',
  doc_draft: '起草文书',
  doc_draft_save: '保存文书草稿',
  case_transition: '推进案件阶段',
  gate_request: '提交门禁',
};

const str = (v) => (typeof v === 'string' ? v : v == null ? '' : String(v));
const num = (v, d = 0) => (typeof v === 'number' && isFinite(v) ? v : d);

const DOC_TYPES = {
  complaint: '起诉状', answer: '答辩状', 'agent-opinion': '代理词', appeal: '上诉状',
  retrial: '再审申请书', 'evidence-opinion': '质证意见', 'lawyer-letter': '律师函', 'legal-opinion': '法律意见书',
};
const DOC_TYPE_IDS = Object.keys(DOC_TYPES);

export const TOOL_DEFS = [
  { type: 'function', function: { name: 'case_get', description: '读取当前案件最新完整信息（当事人/证据/主张/期限/文书/门禁等）', parameters: { type: 'object', properties: {}, additionalProperties: false } } },
  { type: 'function', function: { name: 'case_update', description: '更新案件基本信息：标题/案号/法院/法官/案情摘要', parameters: { type: 'object', properties: {
      title: { type: 'string', description: '案件标题' }, caseNumber: { type: 'string', description: '案号，如 (2026)沪0113民初12345号' },
      court: { type: 'string' }, judge: { type: 'string' }, summary: { type: 'string', description: '案情摘要' } }, additionalProperties: false } } },
  { type: 'function', function: { name: 'party_add', description: '登记当事人', parameters: { type: 'object', required: ['name', 'role'], properties: {
      name: { type: 'string' }, role: { type: 'string', enum: ['plaintiff', 'defendant', 'applicant', 'respondent', 'thirdParty', 'other'] },
      contact: { type: 'string' } }, additionalProperties: false } } },
  { type: 'function', function: { name: 'evidence_add', description: '登记证据（对话/材料中出现的证据必须登记）', parameters: { type: 'object', required: ['name'], properties: {
      name: { type: 'string', description: '证据名称，如 借款转账记录' },
      kind: { type: 'string', enum: ['documentary', 'physical', 'electronic', 'witness', 'audio_video', 'other'], description: '证据种类' },
      source: { type: 'string', description: '来源，如 委托人提供' },
      description: { type: 'string' },
      status: { type: 'string', enum: ['todo', 'collected', 'submitted'], description: '三态：待收集/已收集/已提交，默认 todo' } }, additionalProperties: false } } },
  { type: 'function', function: { name: 'evidence_status', description: '更新证据三态：todo 待收集 / collected 已收集 / submitted 已提交', parameters: { type: 'object', required: ['evidenceId', 'status'], properties: {
      evidenceId: { type: 'string' }, status: { type: 'string', enum: ['todo', 'collected', 'submitted'] } }, additionalProperties: false } } },
  { type: 'function', function: { name: 'claim_add', description: '登记主张/争点（请求权基础、答辩理由、争议焦点、待证事实）', parameters: { type: 'object', required: ['title', 'statement'], properties: {
      title: { type: 'string' }, kind: { type: 'string', enum: ['request_basis', 'defense', 'issue', 'fact'], description: '请求权基础/答辩/争点/事实' },
      statement: { type: 'string' }, basisLaw: { type: 'array', items: { type: 'string' }, description: '法律依据，如 ["《民法典》第667条"]' } }, additionalProperties: false } } },
  { type: 'function', function: { name: 'claim_link', description: '把证据关联到主张并写明证明目的', parameters: { type: 'object', required: ['claimId', 'evidenceId', 'purpose'], properties: {
      claimId: { type: 'string' }, evidenceId: { type: 'string' }, purpose: { type: 'string', description: '证明目的' },
      strength: { type: 'string', enum: ['direct', 'indirect'] } }, additionalProperties: false } } },
  { type: 'function', function: { name: 'deadline_add', description: '登记期限（上诉期/举证期/答辩期/开庭等）。给 days 从 startDate 次日算起，或直接给 dueDate', parameters: { type: 'object', required: ['title'], properties: {
      title: { type: 'string' }, kind: { type: 'string', enum: ['appeal', 'evidence', 'answer', 'hearing', 'statute', 'other'] },
      startDate: { type: 'string', description: '起算日 YYYY-MM-DD，当天不算' }, days: { type: 'integer', description: '期限天数' },
      businessDays: { type: 'boolean', description: '是否仅工作日（默认自然日）' }, dueDate: { type: 'string', description: '届满日 YYYY-MM-DD' },
      basis: { type: 'string', description: '法律依据，如 民诉法第171条' } }, additionalProperties: false } } },
  { type: 'function', function: { name: 'event_add', description: '登记日程（开庭/会议）', parameters: { type: 'object', required: ['title', 'date'], properties: {
      title: { type: 'string' }, date: { type: 'string', description: 'YYYY-MM-DD' }, kind: { type: 'string', enum: ['hearing', 'meeting', 'other'] }, note: { type: 'string' } }, additionalProperties: false } } },
  { type: 'function', function: { name: 'research_note_save', description: '沉淀检索记录（法答网/人民法院案例库/北大法宝等来源的结论）', parameters: { type: 'object', required: ['title', 'source', 'summary'], properties: {
      title: { type: 'string' }, source: { type: 'string' }, summary: { type: 'string' }, links: { type: 'array', items: { type: 'string' } } }, additionalProperties: false } } },
  { type: 'function', function: { name: 'minutes_save', description: '把讨论结论整理为会话纪要存档', parameters: { type: 'object', required: ['title', 'content'], properties: {
      title: { type: 'string' }, content: { type: 'string', description: 'Markdown 纪要正文' } }, additionalProperties: false } } },
  { type: 'function', function: { name: 'doc_draft', description: '起草法律文书：创建文书记录，随后在回复中写出全文并调用 doc_draft_save 保存', parameters: { type: 'object', required: ['docType'], properties: {
      docType: { type: 'string', enum: DOC_TYPE_IDS }, title: { type: 'string' }, instructions: { type: 'string', description: '起草要点' } }, additionalProperties: false } } },
  { type: 'function', function: { name: 'doc_draft_save', description: '把写好的文书正文保存为草稿版本（每次保存追加不可变版本）', parameters: { type: 'object', required: ['docId', 'content'], properties: {
      docId: { type: 'string' }, content: { type: 'string', description: '文书全文' } }, additionalProperties: false } } },
  { type: 'function', function: { name: 'case_transition', description: '推进案件在看板上的阶段（只能推进到非终局列，结案必须由律师人工操作）', parameters: { type: 'object', required: ['to'], properties: {
      to: { type: 'string', enum: ['intake', 'survey', 'strategy', 'drafting', 'filing'], description: '目标列：待接案/调查取证/策略制定/文书起草/待定稿送审' } }, additionalProperties: false } } },
  { type: 'function', function: { name: 'gate_request', description: '提交门禁申请（接案/策略/定稿/结案），由律师在界面人工审批，AI 不能自行通过', parameters: { type: 'object', required: ['type', 'title'], properties: {
      type: { type: 'string', enum: ['intake', 'strategy', 'filing', 'closure'] }, title: { type: 'string' }, summary: { type: 'string' } }, additionalProperties: false } } },
];

// ---------- 事件发射 ----------
function afterChange(caseId, feedEntry) {
  if (feedEntry) store.addFeed({ caseId, caseTitle: store.getCase(caseId)?.title || '', ...feedEntry });
  const cards = store.listCases().map(projectCase);
  broadcast('case.updated', { case: projectCase(store.getCase(caseId)) });
  broadcast('stats', computeStats(cards));
}

// ---------- 工具执行 ----------
export async function executeTool(caseId, name, args = {}) {
  const c = store.getCase(caseId);
  if (!c) return { ok: false, error: '案件不存在' };
  switch (name) {
    case 'case_get':
      return { ok: true, case: c };

    case 'case_update': {
      const patch = {};
      for (const k of ['title', 'caseNumber', 'court', 'judge', 'summary']) if (args[k] != null) patch[k] = str(args[k]);
      const updated = store.updateCase(caseId, patch);
      afterChange(caseId, { type: 'case', label: `AI 更新案件信息` });
      return { ok: true, case: projectCase(updated) };
    }

    case 'party_add': {
      const name_ = str(args.name).trim();
      if (!name_) return { ok: false, error: '缺少当事人姓名' };
      const p = { id: store.uid('party'), name: name_, role: args.role || 'other', contact: str(args.contact) };
      c.parties.push(p);
      store.touch(c); store.persist();
      afterChange(caseId, { type: 'party', label: `AI 登记当事人：${p.name}` });
      return { ok: true, party: p };
    }

    case 'evidence_add': {
      const name_ = str(args.name).trim();
      if (!name_) return { ok: false, error: '缺少证据名称' };
      const e = { id: store.uid('ev'), name: name_, kind: args.kind || 'other', source: str(args.source), description: str(args.description), status: args.status || 'todo', at: store.now() };
      c.evidence.push(e);
      store.touch(c); store.persist();
      afterChange(caseId, { type: 'evidence', label: `AI 登记证据：${e.name}` });
      return { ok: true, evidence: e };
    }

    case 'evidence_status': {
      const e = c.evidence.find((x) => x.id === args.evidenceId);
      if (!e) return { ok: false, error: '证据不存在' };
      e.status = args.status; e.at = store.now();
      store.touch(c); store.persist();
      afterChange(caseId, { type: 'evidence', label: `证据「${e.name}」→ ${STATUS_CN[e.status]}` });
      return { ok: true, evidence: e };
    }

    case 'claim_add': {
      const title_ = str(args.title).trim();
      if (!title_) return { ok: false, error: '缺少主张标题' };
      const cl = { id: store.uid('claim'), title: title_, kind: args.kind || 'issue', statement: str(args.statement), basisLaw: Array.isArray(args.basisLaw) ? args.basisLaw.map(str) : [], links: [], at: store.now() };
      c.claims.push(cl);
      store.touch(c); store.persist();
      afterChange(caseId, { type: 'claim', label: `AI 登记主张：${cl.title}` });
      return { ok: true, claim: cl };
    }

    case 'claim_link': {
      const cl = c.claims.find((x) => x.id === args.claimId);
      const ev = c.evidence.find((x) => x.id === args.evidenceId);
      if (!cl || !ev) return { ok: false, error: '主张或证据不存在' };
      cl.links.push({ evidenceId: ev.id, purpose: str(args.purpose), strength: args.strength || 'indirect', at: store.now() });
      store.touch(c); store.persist();
      afterChange(caseId, { type: 'claim', label: `AI 关联证据「${ev.name}」→ 主张「${cl.title}」` });
      return { ok: true, links: cl.links.length };
    }

    case 'deadline_add': {
      const title_ = str(args.title).trim();
      if (!title_) return { ok: false, error: '缺少期限名称' };
      const dueDate = args.dueDate
        ? str(args.dueDate)
        : args.days != null
          ? (args.businessDays ? addBusinessDays(str(args.startDate || todayStr()), num(args.days)) : addDays(str(args.startDate || todayStr()), num(args.days)))
          : null;
      if (!dueDate) return { ok: false, error: '请提供 dueDate 或 (startDate + days)' };
      const dl = { id: store.uid('dl'), title: title_, kind: args.kind || 'other', startDate: str(args.startDate) || null, days: args.days != null ? num(args.days) : null, businessDays: !!args.businessDays, dueDate, basis: str(args.basis), done: false, at: store.now() };
      c.deadlines.push(dl);
      store.touch(c); store.persist();
      afterChange(caseId, { type: 'deadline', label: `AI 登记期限：${dl.title}（届满 ${dl.dueDate}）` });
      return { ok: true, deadline: dl };
    }

    case 'event_add': {
      const ev = { id: store.uid('evt'), title: str(args.title), date: str(args.date), kind: args.kind || 'other', note: str(args.note), at: store.now() };
      c.events.push(ev);
      store.touch(c); store.persist();
      afterChange(caseId, { type: 'event', label: `AI 登记日程：${ev.title}（${ev.date}）` });
      return { ok: true, event: ev };
    }

    case 'research_note_save': {
      const rn = { id: store.uid('rs'), title: str(args.title), source: str(args.source), summary: str(args.summary), links: Array.isArray(args.links) ? args.links.map(str) : [], at: store.now() };
      c.research.push(rn);
      store.touch(c); store.persist();
      afterChange(caseId, { type: 'research', label: `AI 沉淀检索记录：${rn.title}` });
      return { ok: true, note: rn };
    }

    case 'minutes_save': {
      const mn = { id: store.uid('min'), title: str(args.title), content: str(args.content), at: store.now() };
      c.minutes.push(mn);
      store.touch(c); store.persist();
      afterChange(caseId, { type: 'minute', label: `AI 保存会话纪要：${mn.title}` });
      return { ok: true, minute: mn };
    }

    case 'doc_draft': {
      const type_ = DOC_TYPE_IDS.includes(args.docType) ? args.docType : 'complaint';
      const doc = { id: store.uid('doc'), docType: type_, title: str(args.title) || DOC_TYPES[type_], instructions: str(args.instructions), status: 'draft', versions: [], at: store.now() };
      c.docs.push(doc);
      store.touch(c); store.persist();
      afterChange(caseId, { type: 'doc', label: `AI 起草文书：${doc.title}` });
      return { ok: true, docId: doc.id, docType: type_, title: doc.title, 提示: '请在回复中起草全文，然后用 doc_draft_save(docId, content) 保存草稿版本' };
    }

    case 'doc_draft_save': {
      const doc = c.docs.find((x) => x.id === args.docId);
      if (!doc) return { ok: false, error: '文书不存在，请先 doc_draft 创建' };
      const content = str(args.content);
      if (!content.trim()) return { ok: false, error: '内容为空' };
      const v = { v: doc.versions.length + 1, content, at: store.now(), hash: crypto.createHash('sha1').update(content).digest('hex').slice(0, 8) };
      doc.versions.push(v);
      doc.status = 'draft';
      store.touch(c); store.persist();
      afterChange(caseId, { type: 'doc', label: `文书「${doc.title}」草稿 v${v.v} 已保存` });
      return { ok: true, docId: doc.id, version: v.v, chars: content.length };
    }

    case 'case_transition': {
      const to = str(args.to);
      if (!KANBAN_COLUMNS.some((k) => k.id === to)) return { ok: false, error: `无效目标列: ${to}` };
      if (to === 'closed') return { ok: false, error: '结案必须由律师在界面人工操作' };
      const moved = store.transitionCase(c, to, 'ai');
      if (!moved) return { ok: false, error: '已经在目标列' };
      afterChange(caseId, { type: 'transition', label: `AI 推进阶段：${colTitle(c.history[c.history.length - 1].from)} → ${colTitle(to)}` });
      return { ok: true, status: to };
    }

    case 'gate_request': {
      const g = { id: store.uid('gate'), type: str(args.type), title: str(args.title), summary: str(args.summary), status: 'pending', requestedAt: store.now(), decidedAt: null, decision: null };
      c.gates.push(g);
      store.touch(c); store.persist();
      afterChange(caseId, { type: 'gate', label: `AI 提交门禁待审批：${g.title}` });
      broadcast('gate.updated', { caseId });
      return { ok: true, gate: g, 提示: '门禁须由律师在界面人工审批' };
    }

    default:
      return { ok: false, error: `未知工具: ${name}` };
  }
}

const STATUS_CN = { todo: '待收集', collected: '已收集', submitted: '已提交' };
function colTitle(id) { return KANBAN_COLUMNS.find((k) => k.id === id)?.title || id; }
function todayStr() { return new Date().toISOString().slice(0, 10); }
function addDays(d, n) { const x = new Date(d + 'T00:00:00'); x.setDate(x.getDate() + n); return x.toISOString().slice(0, 10); }
function addBusinessDays(d, n) {
  let x = new Date(d + 'T00:00:00');
  let added = 0;
  while (added < n) { x.setDate(x.getDate() + 1); const dow = x.getDay(); if (dow !== 0 && dow !== 6) added++; }
  return x.toISOString().slice(0, 10);
}
