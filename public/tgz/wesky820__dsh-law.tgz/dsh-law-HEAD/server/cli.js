// 独立运行入口：node server/cli.js
process.env.LW_DATA_DIR ??= new URL('../data', import.meta.url).pathname;

const { startLawBench } = await import('./index.js');

console.log('  深法工作台 · DeepSeek Legal Workbench（独立模式）');
console.log('  插件模式请通过 dsh-lawbench 插件在 DeepSeek Harness 中使用\n');

const { server } = await startLawBench({ port: 8898, openBrowser: true });

function shutdown() {
  import('./index.js').then(({ closeLawBench }) => {
    closeLawBench(server).then(() => process.exit(0));
  });
}
process.once('SIGINT', shutdown);
process.once('SIGTERM', shutdown);
