import { posix } from 'node:path'
import type { Context } from '@deepseek-ai/cordis'
import type {
  PackageComponent,
  PackageFormatObservation,
  PackageFormatProvider,
  PluginPackageSource,
} from '../kernel.js'

const FORMAT = 'pi-package'
const MANIFEST_PATH = 'package.json'

const RESOURCES = [
  { field: 'extensions', type: 'pi-extension-set', convention: 'extensions/' },
  { field: 'skills', type: 'pi-skill-set', convention: 'skills/' },
  { field: 'prompts', type: 'pi-prompt-set', convention: 'prompts/' },
  { field: 'themes', type: 'pi-theme-set', convention: 'themes/' },
] as const

function record(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value)
}

function packageManifest(value: unknown): Record<string, unknown> {
  if (!record(value)) throw new TypeError(`${FORMAT}: package.json must contain an object`)
  if (typeof value.name !== 'string' || value.name.trim().length === 0) {
    throw new TypeError(`${FORMAT}: package.json field "name" must be a non-empty string`)
  }
  return value
}

function normalizeResourcePath(value: string, field: string): string {
  if (value.length === 0) {
    throw new TypeError(`${FORMAT}: pi.${field} entries must be non-empty paths`)
  }
  const exclusion = value.startsWith('!')
  const rawPath = exclusion ? value.slice(1) : value
  if (rawPath.length === 0 || rawPath.includes('\\') || rawPath.includes('\0') || posix.isAbsolute(rawPath)) {
    throw new TypeError(`${FORMAT}: pi.${field} entry "${value}" must remain within the package root`)
  }
  const withoutPrefix = rawPath.startsWith('./') ? rawPath.slice(2) : rawPath
  const normalized = posix.normalize(withoutPrefix)
  if (normalized.length === 0
    || normalized === '.'
    || normalized === '..'
    || normalized.startsWith('../')) {
    throw new TypeError(`${FORMAT}: pi.${field} entry "${value}" must remain within the package root`)
  }
  return `${exclusion ? '!' : ''}${normalized}`
}

function isPattern(path: string): boolean {
  return path.startsWith('!') || /[*?\[\]{}()]/u.test(path)
}

function asDirectory(path: string): string {
  return path.endsWith('/') ? path : `${path}/`
}

function declaredResources(
  source: PluginPackageSource,
  pi: Record<string, unknown>,
): { readonly components: readonly PackageComponent[]; readonly diagnostics: readonly string[] } {
  const components: PackageComponent[] = []
  const diagnostics: string[] = []
  for (const resource of RESOURCES) {
    const declared = pi[resource.field]
    if (declared === undefined) continue
    if (!Array.isArray(declared) || declared.some(entry => typeof entry !== 'string')) {
      throw new TypeError(`${FORMAT}: pi.${resource.field} must be an array of strings`)
    }
    const normalizedEntries = (declared as string[]).map(entry => normalizeResourcePath(entry, resource.field))
    for (const [index, path] of normalizedEntries.entries()) {
      if (isPattern(path)) continue
      if (!source.has(path)) {
        diagnostics.push(
          `${FORMAT}: pi.${resource.field} path "${(declared as string[])[index]}" does not exist; resource disabled`,
        )
      }
    }
    const entries = normalizedEntries.filter(path => isPattern(path) || source.has(path))
    if (entries.length > 0) {
      components.push({
        type: resource.type,
        path: MANIFEST_PATH,
        manifestField: `pi.${resource.field}`,
        metadata: Object.freeze({ entries: Object.freeze(entries) }),
      })
    }
  }
  return {
    components: Object.freeze(components),
    diagnostics: Object.freeze(diagnostics),
  }
}

function conventionalResources(source: PluginPackageSource): {
  readonly claimed: boolean
  readonly components: readonly PackageComponent[]
  readonly diagnostics: readonly string[]
} {
  const components: PackageComponent[] = []
  const diagnostics: string[] = []
  for (const resource of RESOURCES) {
    if (!source.has(resource.convention)) continue
    if (source.kind(resource.convention) !== 'directory') {
      diagnostics.push(`${FORMAT}: ${resource.convention} must be a directory; resource disabled`)
      continue
    }
    components.push({
      type: resource.type,
      path: resource.convention,
      metadata: Object.freeze({ entries: Object.freeze([resource.convention]) }),
    })
  }
  return {
    claimed: components.length > 0,
    components: Object.freeze(components),
    diagnostics: Object.freeze(diagnostics),
  }
}

/** Pi package.json dialect. Runtime-specific Pi resources remain explicit and inert. */
export const piPackageProvider: PackageFormatProvider = {
  name: FORMAT,
  probe(source: PluginPackageSource): PackageFormatObservation | undefined {
    if (!source.has(MANIFEST_PATH) || source.kind(MANIFEST_PATH) !== 'file') return undefined
    const manifest = packageManifest(source.readJson(MANIFEST_PATH))
    if (Object.hasOwn(manifest, 'pi')) {
      if (!record(manifest.pi)) throw new TypeError(`${FORMAT}: package.json field "pi" must be an object`)
      const observation = declaredResources(source, manifest.pi)
      return {
        manifestPath: MANIFEST_PATH,
        manifest: Object.freeze({ ...manifest }),
        components: observation.components,
        ...observation.diagnostics.length === 0
          ? {}
          : { diagnostics: observation.diagnostics },
      }
    }

    const observation = conventionalResources(source)
    if (!observation.claimed) return undefined
    return {
      manifestPath: MANIFEST_PATH,
      manifest: Object.freeze({ ...manifest }),
      components: observation.components,
      ...observation.diagnostics.length === 0
        ? {}
        : { diagnostics: observation.diagnostics },
    }
  },
}

export const name = 'plugin-bridge-format-pi-package'
export const inject = ['pluginBridge']

export function apply(ctx: Context): void {
  ctx.pluginBridge.registerPackageFormatProvider(piPackageProvider)
}
