import type {
  MarketplaceCatalogObservation,
  MarketplaceCatalogProvider,
  MarketplacePluginSource,
} from './types.js'
import type { Context } from '@deepseek-ai/cordis'
import {
  parseGitRepositorySource,
  parseMarketplaceRelativeDirectory,
  parsePluginEntry,
  requireIdentifier,
  requirePlugins,
  requireRecord,
  requireUniquePluginNames,
} from './validation.js'

export const CODEX_MARKETPLACE_MANIFEST = '.agents/plugins/marketplace.json'
export const CODEX_LEGACY_MARKETPLACE_MANIFEST = 'marketplace.json'

/**
 * Codex's observed local catalog shape.
 *
 * No public remote marketplace wire format is assumed here: additional source
 * kinds must be introduced from published documentation or a real fixture.
 */
export const codexMarketplaceProvider: MarketplaceCatalogProvider = {
  name: 'codex-marketplace',
  probe(source): MarketplaceCatalogObservation | undefined {
    if (source.manifestPath !== CODEX_MARKETPLACE_MANIFEST
      && source.manifestPath !== CODEX_LEGACY_MARKETPLACE_MANIFEST) return undefined

    const manifest = requireRecord(source.manifest, 'marketplace')
    const plugins = requirePlugins(manifest).map((entry, index) =>
      parsePluginEntry(entry, index, parseCodexSource),
    )
    requireUniquePluginNames(plugins)
    return {
      name: requireIdentifier(manifest.name, 'marketplace.name'),
      manifestPath: source.manifestPath,
      plugins,
    }
  },
}

function parseCodexSource(value: unknown, field: string): MarketplacePluginSource {
  if (typeof value === 'string') return parseMarketplaceRelativeDirectory(value, field)
  const source = requireRecord(value, field)
  if (source.source === 'npm') {
    throw new TypeError(`${field}: npm marketplace sources are documented but not supported by this bridge`)
  }
  if (source.source === 'url' || source.source === 'git-subdir') {
    return parseGitRepositorySource(source, field)
  }
  const unsupportedKey = Object.keys(source).find(key => key !== 'source' && key !== 'path')
  if (unsupportedKey !== undefined) throw new TypeError(`${field}.${unsupportedKey} is not supported`)
  if (source.source !== 'local') throw new TypeError(`${field}.source must be "local"`)
  return parseMarketplaceRelativeDirectory(source.path, `${field}.path`)
}

export const name = 'plugin-bridge-marketplace-codex'
export const inject = ['pluginBridge']

/** Register only the evidence-backed Codex local marketplace dialect on this Cordis row. */
export function apply(ctx: Context): void {
  ctx.pluginBridge.registerMarketplaceProvider(codexMarketplaceProvider)
}
