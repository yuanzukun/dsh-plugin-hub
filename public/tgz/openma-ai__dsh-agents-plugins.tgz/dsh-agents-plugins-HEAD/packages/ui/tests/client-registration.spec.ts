import assert from 'node:assert/strict'
import test from 'node:test'

test('the Web contribution mounts its Remote before registering the bridge settings tab', async () => {
  const client = await import('../src/client/register.js').catch(() => undefined)
  assert.equal(typeof client?.registerPluginBridgeUi, 'function')

  const events: string[] = []
  const contribution = { package: '@openma/dsh-agents-plugins-bridge', descriptors: [] }
  const component = () => null
  let registration: { options: Record<string, unknown>; component: unknown } | undefined
  let remoteInjectionActive = false
  const api = {
    snapshot: async () => ({ ok: true, value: { marketplaces: [], installations: [] } }),
    discoverLocal: async () => ({ ok: true, value: { candidates: [], diagnostics: [] } }),
    discoverMarketplaces: async () => ({ ok: true, value: { candidates: [], diagnostics: [] } }),
    piUpdates: async () => ({ ok: true, value: { mode: 'notify', updates: [] } }),
  }
  const ctx = {
    remote: {
      $mount: async (value: unknown) => {
        assert.equal(value, contribution)
        events.push('remote')
        return async () => { events.push('remote:dispose') }
      },
    },
    locale: {
      register: () => {
        events.push('locale')
        return () => { events.push('locale:dispose') }
      },
      bind: () => (key: string) => key,
    },
    effect: (factory: () => unknown) => factory(),
    inject: (services: readonly string[], callback: (scope: unknown) => void) => {
      assert.deepEqual(services, ['remote.agentPluginsBridge'])
      events.push('remote:inject')
      remoteInjectionActive = true
      callback({
        ...ctx,
        remote: {
          ...ctx.remote,
          get agentPluginsBridge() {
            if (!remoteInjectionActive) throw new Error('Remote face escaped its Cordis injection scope')
            return api
          },
        },
      })
      remoteInjectionActive = false
    },
    slots: {
      inject: (name: string, factory: () => unknown) => {
        assert.equal(name, 'settings.plugins.tab')
        events.push('slot:inject')
        factory()
      },
      register: (options: Record<string, unknown>, value: unknown) => {
        events.push('slot:register')
        registration = { options, component: value }
        return () => { events.push('slot:dispose') }
      },
    },
  }

  const dispose = await client?.registerPluginBridgeUi(
    ctx as never,
    contribution as never,
    component as never,
    { zh: {}, en: {} },
  )

  assert.deepEqual(events, ['remote', 'remote:inject', 'locale', 'slot:inject', 'slot:register'])
  assert.equal(registration?.component, component)
  assert.deepEqual(registration?.options, {
    name: 'settings.plugins.tab',
    id: 'agent-plugins',
    order: 5,
    label: registration?.options.label,
    locale: 'settings.pluginBridge',
    inject: registration?.options.inject,
  })
  assert.equal(typeof registration?.options.label, 'function')
  assert.equal(typeof registration?.options.inject, 'function')
  const face = (registration?.options.inject as (() => Record<string, unknown>))()
  assert.deepEqual(Object.keys(face).sort(), [
    'addMarketplace',
    'checkPiUpdates',
    'importLocal',
    'importMarketplace',
    'install',
    'load',
    'rescan',
    'setEnabled',
    'setPiPackageAutoUpdate',
    'setPiUpdateMode',
    'updateAllPiPackages',
    'updatePiPackage',
  ])
  assert.equal(Object.hasOwn(face, 'api'), false)
  await (face.load as () => Promise<unknown>)()

  await dispose?.()
  assert.equal(events.at(-1), 'remote:dispose')
})

test('mutation callbacks reuse the returned durable snapshot and rescan only foreign state', async () => {
  const client = await import('../src/client/register.js')
  const calls: string[] = []
  const snapshot = {
    marketplaces: [{ name: 'team', provider: 'codex-marketplace', plugins: ['demo'] }],
    installations: [{
      name: 'demo',
      marketplace: 'team',
      format: 'codex-legacy',
      enabled: true,
      rowCount: 2,
      protectedCount: 0,
      unsupportedCount: 0,
      diagnostics: [],
    }],
  }
  const local = { candidates: [], diagnostics: [] }
  const marketplaces = { candidates: [], diagnostics: [] }
  const piUpdates = { mode: 'notify' as const, updates: [] }
  const api = {
    snapshot: async () => { throw new Error('mutation must not reload the durable snapshot') },
    discoverLocal: async () => {
      calls.push('discoverLocal')
      return { ok: true as const, value: local }
    },
    discoverMarketplaces: async () => {
      calls.push('discoverMarketplaces')
      return { ok: true as const, value: marketplaces }
    },
    piUpdates: async () => {
      calls.push('piUpdates')
      return { ok: true as const, value: piUpdates }
    },
    installPlugin: async (name: string, marketplace: string) => {
      calls.push(`install:${name}@${marketplace}`)
      return { ok: true as const, value: { status: 'installed' as const, snapshot } }
    },
  }

  const face = client.createPluginBridgeSettingsFace(api as never)

  assert.deepEqual(await face.install('demo', 'team'), { snapshot, local, marketplaces, piUpdates })
  assert.deepEqual(calls, ['install:demo@team', 'discoverLocal', 'discoverMarketplaces', 'piUpdates'])
})

test('an install failure preserves its Host-classified reason without exposing Host details', async () => {
  const client = await import('../src/client/register.js')
  const api = {
    installPlugin: async () => ({
      ok: true as const,
      value: { status: 'failed' as const, reason: 'unsupported' as const },
    }),
  }
  const face = client.createPluginBridgeSettingsFace(api as never)

  await assert.rejects(
    () => face.install('demo', 'team'),
    (error: unknown) => (
      error instanceof Error
      && error.message === 'Plugin install failed: unsupported'
      && (error as Error & { reason?: string }).reason === 'unsupported'
    ),
  )
})

test('Pi settings callbacks delegate checks, policy, exclusions, and native update actions', async () => {
  const client = await import('../src/client/register.js')
  const calls: string[] = []
  const viewParts = {
    snapshot: { marketplaces: [], installations: [] },
    local: { candidates: [], diagnostics: [] },
    marketplaces: { candidates: [], diagnostics: [] },
    piUpdates: { mode: 'notify' as const, updates: [] },
  }
  const ok = <T>(value: T) => ({ ok: true as const, value })
  const api = {
    snapshot: async () => ok(viewParts.snapshot),
    discoverLocal: async () => ok(viewParts.local),
    discoverMarketplaces: async () => ok(viewParts.marketplaces),
    piUpdates: async () => ok(viewParts.piUpdates),
    checkPiUpdates: async () => { calls.push('check'); return ok(viewParts.piUpdates) },
    setPiUpdateMode: async (mode: string) => { calls.push(`mode:${mode}`); return ok(viewParts.piUpdates) },
    setPiPackageAutoUpdate: async (id: string, enabled: boolean) => {
      calls.push(`auto:${id}:${enabled}`)
      return ok(viewParts.piUpdates)
    },
    updatePiPackage: async (id: string) => { calls.push(`update:${id}`); return ok(viewParts.piUpdates) },
    updateAllPiPackages: async () => { calls.push('update-all'); return ok(viewParts.piUpdates) },
  }
  const face = client.createPluginBridgeSettingsFace(api as never)
  const id = 'a'.repeat(32)

  await face.checkPiUpdates()
  await face.setPiUpdateMode('auto')
  await face.setPiPackageAutoUpdate(id, false)
  await face.updatePiPackage(id)
  await face.updateAllPiPackages()

  assert.deepEqual(calls, ['check', 'mode:auto', `auto:${id}:false`, `update:${id}`, 'update-all'])
})
