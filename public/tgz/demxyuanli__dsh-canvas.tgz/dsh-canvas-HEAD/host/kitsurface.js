/**
 * The `dsh/canvas` export surface, as a compile-time contract.
 *
 * Why this file exists: the kit itself is defined in `lib/client.js` (the browser
 * half, which the host cannot import), but the host has to be able to reject an
 * import of a name the kit does not export. Without that check the only feedback
 * is a render-time crash card - `canvas_check` stays green, and an agent has to
 * wait for a human to report the crash. Measured case: a canvas written against
 * a similar kit imported `H3` and `PieChart`; after fixing the module specifier
 * it compiled with zero errors and threw twice at render time.
 *
 * Duplicating the list here is only safe if drift is impossible, so
 * `test/client.test.mjs` asserts this list against the names `lib/client.js`
 * actually publishes, in both directions. Adding a component or hook means
 * adding it in both places; removing or renaming one is a breaking change of the
 * frozen interface (INTERFACE.md section 5) and needs a kit version bump.
 */

/** Components, in the kit's own grouping order. */
export const KIT_COMPONENTS = [
  "Stack", "Row", "Grid", "Divider", "CollapsibleSection",
  "H1", "H2", "H3", "Text", "Code",
  "Card", "CardHeader", "CardBody", "Callout",
  "Stat", "Table", "BarChart", "PieChart", "HeatMatrix", "TodoList",
  "Progress", "KeyValue", "Timeline",
  "Button", "Pill",
];

/** Hooks: the five React re-exports plus the five canvas-specific ones. */
export const KIT_HOOKS = [
  "useState", "useEffect", "useMemo", "useCallback", "useRef",
  "useCanvasState", "useCanvasOverlay", "useCanvasAction", "useHostTheme", "useCanvasResource",
];

/** Every name a canvas may import from "dsh/canvas". */
export const KIT_SURFACE = new Set(KIT_COMPONENTS.concat(KIT_HOOKS));

/** Names the module wrapper also injects (not importable; documented for tests). */
export const KIT_GLOBALS = ["h", "Fragment", "React", "CanvasContext", "runtime", "version"];

function editDistance(a, b) {
  const prev = new Array(b.length + 1);
  const cur = new Array(b.length + 1);
  for (let j = 0; j <= b.length; j++) prev[j] = j;
  for (let i = 1; i <= a.length; i++) {
    cur[0] = i;
    for (let j = 1; j <= b.length; j++) {
      const cost = a[i - 1] === b[j - 1] ? 0 : 1;
      cur[j] = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + cost);
    }
    for (let j = 0; j <= b.length; j++) prev[j] = cur[j];
  }
  return prev[b.length];
}

/**
 * A close-but-not-exact export name, or null. Keeps the diagnostic actionable
 * for the common case (wrong case, singular/plural, one transposed letter).
 * @param name - the unknown name found in the import clause.
 * @returns the suggested export name, or null when nothing is close.
 */
export function suggestExport(name) {
  if (typeof name !== "string" || name.length === 0) return null;
  const lower = name.toLowerCase();
  let best = null;
  let bestScore = Infinity;
  for (const candidate of KIT_SURFACE) {
    if (candidate.toLowerCase() === lower) return candidate;   // case-only mismatch
    const d = editDistance(lower, candidate.toLowerCase());
    if (d < bestScore) { bestScore = d; best = candidate; }
  }
  // One edit for short names, two for longer ones; anything else is a different
  // name (e.g. "PieChart" has no close neighbour in this kit).
  const limit = name.length <= 4 ? 1 : 2;
  return bestScore <= limit ? best : null;
}

/** The hint attached to every E_UNKNOWN_EXPORT diagnostic. */
export function surfaceHint() {
  return "The kit exports " + KIT_COMPONENTS.length + " components + " + KIT_HOOKS.length +
    " hooks; the full surface is in INTERFACE.md section 5 and skills/canvas/references/kit.md.";
}
