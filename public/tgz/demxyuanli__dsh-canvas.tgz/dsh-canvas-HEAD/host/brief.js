/**
 * Cold-start digest of a canvas's DATA.
 *
 * A canvas is the durable summary of a project. After a context truncation, or in
 * a fresh session, an agent should re-hydrate from a few KB rather than the whole
 * file -- and it should be able to do so without re-litigating settled ground.
 * The digest therefore answers four questions in a fixed order:
 *
 *   1. where are we going   -> goal / asOf / revision / staleDays
 *   2. what must not break  -> constraints
 *   3. what is already decided -> decisions (chose vs rejected)
 *   4. what now             -> nextAction + the rows still in flight
 *
 * Everything else stays behind canvas_read's dataPath slices.
 */

/** Statuses that still need someone's attention. */
const OPEN_STATUSES = new Set(["in_progress", "blocked", "pending"]);

/**
 * Statuses that mean "settled". Only used to tell two situations apart when no
 * row matches OPEN_STATUSES: "everything is closed" (normal, stay silent) versus
 * "this canvas uses a status vocabulary the digest does not know" (worth a note).
 */
const CLOSED_STATUSES = new Set(["completed", "cancelled", "done", "closed"]);

/** Anchor field names accepted on nextAction, in preference order. */
const ANCHOR_FIELDS = ["taskId", "claimId", "rowId"];

/**
 * Does this array hold rows? Every item must be an object with a string id (so
 * overlays and dependsOn can address it) AND a status (which is what the digest
 * filters on). Without those two, `constraints` and `decisions` would qualify.
 * @param value - Candidate value from DATA.
 * @returns True when the array is a row set.
 */
function isRowSet(value) {
  return Array.isArray(value) && value.length > 0
    && value.every((row) => row !== null && typeof row === "object"
      && typeof row.id === "string" && Object.prototype.hasOwnProperty.call(row, "status"));
}

/** Fields kept per in-flight row: enough to act, short enough to stay cheap. */
const FOCUS_FIELDS = [
  "id", "lane", "title", "status", "priority", "owner", "progress",
  "updatedAt", "blocker", "dependsOn", "next", "acceptance",
];

/**
 * Copy only the defined, non-empty fields, so the digest has no blank noise.
 * @param row - Source object.
 * @param fields - Field names to keep, in order.
 * @returns A new object holding just those fields.
 */
function pick(row, fields) {
  const out = {};
  if (row === null || typeof row !== "object") return out;
  for (const field of fields) {
    const value = row[field];
    if (value === undefined || value === "" || value === null) continue;
    if (Array.isArray(value) && value.length === 0) continue;
    out[field] = value;
  }
  return out;
}

/**
 * Whole days from an ISO date (or date-time) to now.
 * @param iso - Date string from DATA.
 * @param now - Epoch milliseconds used as "today".
 * @returns Day count, or undefined when the value is absent or unparseable.
 */
function daysSince(iso, now) {
  if (typeof iso !== "string" || iso === "") return undefined;
  const then = Date.parse(iso.length <= 10 ? iso + "T00:00:00Z" : iso);
  if (Number.isNaN(then)) return undefined;
  return Math.max(0, Math.floor((now - then) / 86400000));
}

/**
 * Decide which top-level array holds the rows, and which statuses count as open.
 *
 * The digest used to hard-code `tasks` and `taskId`, which made every canvas whose
 * rows are called something else (an audit's `claims`, say) invisible to the one
 * path a resuming agent depends on -- and it said so silently: "0 in flight".
 * Explicit options win; `tasks` stays the default when present; otherwise the
 * first array of id-bearing objects is used and the choice is reported in a note.
 *
 * @param data - The canvas DATA object.
 * @param options - `rowsKey` and `openStatuses` overrides.
 * @returns { rowsKey, rows, open, auto } plus any notes explaining the choice.
 */function resolveRows(data, options) {
  const notes = [];
  const explicit = typeof options.rowsKey === "string" && options.rowsKey !== "" ? options.rowsKey : null;
  // A canvas may declare its own shape in DATA: `rowsKey` (the audit's rows are
  // `claims`) and `openStatuses` (the audit's vocabulary is 未修 / 部分). A
  // declaration is not a guess, so neither needs a note.
  const declaredKey = typeof data.rowsKey === "string" && data.rowsKey !== "" ? data.rowsKey : null;
  let rowsKey = explicit !== null ? explicit : declaredKey;
  let auto = false;

  if (rowsKey === null) {
    if (Array.isArray(data.tasks)) {
      rowsKey = "tasks";
    } else {
      // Auto-detection stays strict on purpose: only the array that the canvas's
      // own anchor points into is adopted. A looser rule ("any id+status array")
      // adopted a gate table -- whose statuses are green/red verdicts, not work
      // states -- and then reported "0 of 4 rows match the open statuses", which
      // is a false alarm dressed as a finding.
      const anchor = data.nextAction === null || typeof data.nextAction !== "object"
        ? null
        : ANCHOR_FIELDS.map((field) => data.nextAction[field]).find((value) => typeof value === "string") ?? null;
      if (anchor !== null) {
        for (const key of Object.keys(data)) {
          const value = data[key];
          if (!isRowSet(value)) continue;
          if (!value.some((row) => row.id === anchor)) continue;
          rowsKey = key;
          auto = true;
          break;
        }
      }
    }
  }

  const rows = rowsKey !== null && Array.isArray(data[rowsKey])
    ? data[rowsKey].filter((row) => row !== null && typeof row === "object")
    : [];

  if (rowsKey !== null && !Array.isArray(data[rowsKey])) {
    notes.push("rowsKey \"" + rowsKey + "\" is not an array in DATA: the digest found no rows to summarise");
  } else if (rowsKey === null) {
    // Nothing was declared, nothing was anchored: name the candidate instead of
    // reporting zero rows in silence. Only for arrays that already look like work
    // rows (a status from the default vocabulary) -- a gate table's green/red, or a
    // chart's label/value pairs, must not be advertised as a row set.
    const candidates = Object.keys(data).filter((key) => isRowSet(data[key]));
    const workLike = candidates.filter((key) => data[key].some((row) => OPEN_STATUSES.has(row.status)));
    if (workLike.length > 0) {
      notes.push("DATA." + workLike.join(" / DATA.") + " looks like a row set but rowsKey is not declared: "
        + "pass rowsKey (and openStatuses) to have the digest summarise those rows");
    }
  } else if (auto) {
    notes.push("rows came from DATA." + rowsKey + " (auto-detected; pass rowsKey to pin it)");
  }

  const open = Array.isArray(options.openStatuses) && options.openStatuses.length > 0
    ? new Set(options.openStatuses)
    : OPEN_STATUSES;
  // A canvas may declare its own vocabulary in DATA (an audit's rows are 未修 /
  // 部分, not pending / in_progress). A declaration is not a guess, so it needs no
  // note -- but the digest says where its vocabulary came from.
  const declared = Array.isArray(data.openStatuses)
    ? data.openStatuses.filter((status) => typeof status === "string" && status !== "")
    : [];
  const openSource = Array.isArray(options.openStatuses) && options.openStatuses.length > 0
    ? "caller"
    : (declared.length > 0 ? "data" : "default");
  const openSet = openSource === "data" ? new Set(declared) : open;

  // Silence used to be the failure mode here: rows the digest did not recognise
  // produced "0 in flight" with no hint that the vocabulary was the problem.
  if (rows.length > 0 && !rows.some((row) => openSet.has(row.status))) {
    const known = rows.every((row) => CLOSED_STATUSES.has(row.status));
    if (!known) {
      notes.push("0 of " + rows.length + " row(s) match the open statuses (" + Array.from(openSet).join("/")
        + "): pass openStatuses if this canvas uses another vocabulary");
    }
  }
  return { rowsKey, rows, open: openSet, openSource, notes };
}

/**
 * Compose the resume digest: a self-contained, ordered answer to "where are we".
 * @param data - The canvas DATA object, with sidecar overlays already merged.
 * @param options - `now` (Date), `focusLimit` / `activityLimit` (row caps),
 *   `rowsKey` (which top-level array holds the rows) and `openStatuses`.
 * @returns A plain object ready to JSON-serialize into the tool result.
 */
export function briefDigest(data, options = {}) {
  const now = options.now instanceof Date ? options.now.getTime() : Date.now();
  const focusLimit = Number.isInteger(options.focusLimit) ? options.focusLimit : 20;
  const activityLimit = Number.isInteger(options.activityLimit) ? options.activityLimit : 3;
  const resolved = resolveRows(data, options);
  const tasks = resolved.rows;
  const OPEN_STATUSES_LOCAL = resolved.open;
  const rowsLabel = resolved.rowsKey === null ? "rows" : resolved.rowsKey + "[]";
  const ids = new Set(tasks.map((t) => t.id));
  const byId = new Map(tasks.map((t) => [t.id, t]));
  const notes = resolved.notes.slice();

  const focus = tasks.filter((t) => OPEN_STATUSES_LOCAL.has(t.status)).slice(0, focusLimit).map((t) => pick(t, FOCUS_FIELDS));

  const nextAction = data.nextAction === undefined || data.nextAction === null
    ? data.nextAction
    : pick(data.nextAction, ANCHOR_FIELDS.concat(["action", "why"]));
  const anchorField = data.nextAction === undefined || data.nextAction === null
    ? null
    : ANCHOR_FIELDS.find((field) => typeof data.nextAction[field] === "string") ?? null;
  if (data.nextAction === undefined) {
    // A missing field is not the same as a deliberate null: null states "nothing
    // is open", so it must read as an answer rather than as a gap.
    notes.push("no nextAction in DATA: after a truncation the agent cannot tell which single step comes first");
  } else if (data.nextAction === null) {
    // null is a claim: "nothing is open". It has to be checked like any other
    // claim, or a board can sit there insisting it has nothing to do.
    const stillOpen = tasks.filter((t) => OPEN_STATUSES_LOCAL.has(t.status)).length;
    if (stillOpen > 0) notes.push("nextAction is null but " + stillOpen + " row(s) are still open: null means nothing is open");
  } else {
    if (typeof data.nextAction.action !== "string" || data.nextAction.action === "") notes.push("nextAction.action is empty");
    if (data.nextAction.taskId === undefined && data.nextAction.claimId === undefined && data.nextAction.rowId === undefined) {
      notes.push("nextAction names no row (expected one of " + ANCHOR_FIELDS.join("/") + "): a resuming agent cannot tell which row it means");
    } else if (anchorField !== null) {
      const anchor = data.nextAction[anchorField];
      const target = byId.get(anchor);
      if (target === undefined) {
        notes.push("nextAction." + anchorField + " " + anchor + " does not exist in " + rowsLabel);
      } else if (!OPEN_STATUSES_LOCAL.has(target.status)) {
        // Pointing the single next step at a closed row is exactly the drift the
        // digest exists to catch: it reads as "do this" after it is done.
        notes.push("nextAction." + anchorField + " " + anchor + " is already " + String(target.status) + "; point it at the next open row");
      }
    }
  }
  // Duplicate ids make every id-keyed thing ambiguous: the sidecar overlay,
  // dependsOn, nextAction, and any matrix the canvas derives from rows.
  const seenIds = new Set();
  for (const task of tasks) {
    if (typeof task.id !== "string" || task.id === "") continue;
    if (seenIds.has(task.id)) notes.push("duplicate row id " + task.id + ": overlays and dependsOn cannot address it unambiguously");
    seenIds.add(task.id);
  }
  for (const task of tasks) {
    if (!Array.isArray(task.dependsOn)) continue;
    for (const dependency of task.dependsOn) {
      if (!ids.has(dependency)) notes.push("row " + String(task.id) + " dependsOn unknown row " + String(dependency));
    }
  }
  if (tasks.length > 0) {
    if (data.constraints === undefined) notes.push("no constraints in DATA: red lines are not recorded where a resuming agent will read them");
    if (data.decisions === undefined) notes.push("no decisions in DATA: settled trade-offs can be re-litigated after a truncation");
  }

  const activity = Array.isArray(data.activity) ? data.activity : [];
  return {
    goal: data.goal,
    asOf: data.asOf,
    asOfAgeDays: daysSince(data.asOf, now),
    revision: data.revision,
    staleDays: data.staleDays,
    // Provenance only when it is not the default: a canvas that says nothing
    // about its shape should not pay bytes for "rowsKey: tasks, source: default".
    ...(resolved.rowsKey === null ? {} : { rowsKey: resolved.rowsKey }),
    ...(resolved.openSource === "default"
      ? {}
      : { openStatuses: Array.from(resolved.open), openStatusesSource: resolved.openSource }),
    nextAction,
    constraints: Array.isArray(data.constraints) ? data.constraints : [],
    decisions: Array.isArray(data.decisions) ? data.decisions : [],
    focus,
    counts: { tasks: tasks.length, focus: focus.length, closed: tasks.length - focus.length },
    recentActivity: activity.slice(0, activityLimit)
      .filter((row) => row !== null && typeof row === "object")
      .map((row) => pick(row, ["id", "at", "title", "tone", "detail", "ref"])),
    notes,
  };
}
