# 变更记录

本包早期版本（0.1.x）是开发期内部版本，**未发布到 npm**；`0.2.0` 是首次发布。

## 0.2.0

首次发布。形态：一个适配 DeepSeek Harness 的工作区 bundle，单包双半（host + 浏览器半边），画布是一段 `*.canvas.tsx`，host 编译后渲染进右栏。

### 能力

- **五类画布范式**：看板 / 门禁 / 时间线 / 对比 / **审计**。前三类有随包模板，后两类是"窄表 + 图表"的组合；审计范式另带 `canvas_new(path, "audit")` 骨架。
- **套件（`dsh/canvas`，`KIT_VERSION = k4`）**：25 个组件 + 10 个钩子。本轮之前已加性新增 `Progress` / `KeyValue` / `Timeline`（kit v1.1）、`H3` / `Text` 的 `as="span"` 与 tone 别名（v1.2）、`PieChart`（饼/环，v1.3）与 `HeatMatrix`。套件**只加不减**：改签名或删导出必须升 `version`。
- **编译期导出面校验（`E_UNKNOWN_EXPORT`）**：具名导入不在套件导出面内即在编译期报错并给出近似名建议。导出面在 `host/kitsurface.js`，与浏览器半边 `lib/client.js` 的实际导出**双向锚定**（测试会在任一侧漂移时失败）。
- **读路径**：`canvas_read` 的 `dataPath` / `filter` / `ids` / `limit` 现在**只回被切片的那一支**（`{ [key]: rows, __counts, __overlays }`），不再把整个 `DATA` 一起返回——1 行切片实测 10 676 → 1 036 字符；未知 `dataPath` 报错并列出真实顶层键，不再静默回整包。
- **恢复摘要**：`brief: true` 返回 goal / asOf / 修订 / `nextAction` / 红线 / 已定决策 / 在办行 / 最近活动 / 一致性 `notes`。行不叫 `tasks` 的画布可在 `DATA` 里声明 `rowsKey` 与 `openStatuses`（摘要回显 `openStatusesSource`：`caller` / `data` / `default`）；两者都没有时摘要只跟随 `nextAction` 的锚点（`taskId` / `claimId` / `rowId`）自动探测，并把"自动探测""词表不认识"变成显式 `notes` 而不是静默的 `0 in flight`。
- **intake 入口**：`agent/pre-step` 上的意图入口，命中"建个看板 / 画布 / 项目文档"时注入 intake 指引（7 条对齐问题 + 第 0 步：参照物与口径 / 产物类型 / 本轮预算）。

### 文档

- `skills/canvas/`：`SKILL.md` + 5 份 references（`kit` / `patterns` / `troubleshooting` / `intake` / `resume`）+ 4 个模板。
- 仓库内另有两份产物（**不随包发布**）：审计实例 `docs/audit/interface-audit.canvas.tsx`（以冻结契约为参照物核对本实现，12 条论断）、论文 `docs/paper/paper.md` / `.docx`（思路 / 实现 / 效果与局限）。

### 验收

- `npm test` → 9 个文件 / 489 处断言；画布语料 **10 张，10/10 零 error 零 warning**；模板必须永远可编译且带 `hidden: true`。
- 最大画布（43.6 KB / 685 行）冷编译中位数约 4 ms（设计预算 50 ms），缓存命中约 0.08 ms。

### 已知限制（随包发布）

- **`compileTimeoutMs` 未生效**：配置照常解析并出现在 `/canvas/api` 的 `limits` 里，但 host 侧没有计时器，不会拒绝编译（审计条目 C-05）。
- **`W_DEPRECATED` 无产出点**：契约要求套件破坏性变更时由 client 渲染期发出该信号，实现里只有注释；当前尚不可触发。
- **旧 ESM 模块不回收**：浏览器无法卸载已 import 的模块，长期会话里旧版本会累积，只能提示重载。
- **无真正虚拟化**：超限只截断并显示 `showing N of M`（渲染期文案，不是编译诊断——`canvas_check` 看不到）。
- **信任级别 = 插件**：画布代码在宿主页面里执行；不注入 `fetch` / `localStorage` / `document`，不允许远程资源，但不引入 iframe / Worker 隔离。
