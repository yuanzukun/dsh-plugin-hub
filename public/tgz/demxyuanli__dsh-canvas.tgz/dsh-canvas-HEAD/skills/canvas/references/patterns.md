# 画布范式

**五类**覆盖绝大多数需求的画布。**先套范式，再谈自定义**：套范式写出来的画布很短，自定义渲染往往只是把复杂度从数据搬进了 UI。

| 范式 | 回答的问题 | 读者 | 模板 |
|---|---|---|---|
| 看板 board | "这一批任务各自到哪一步了？" | owner | [../templates/board.canvas.tsx](../templates/board.canvas.tsx) |
| 门禁 gates | "基线对齐了没有？哪条红了？" | 双方 | [../templates/gates.canvas.tsx](../templates/gates.canvas.tsx) |
| 时间线 timeline | "这几轮/这几天分别推进了什么？" | owner | 无独立模板，用 Table + 分组 |
| 对比 comparison | "我们这个和参考差在哪、差多少？" | 双方 | 无独立模板，用 Table + BarChart |
| **审计 audit** | "**靠参照物的口径，我们还差什么、缺的是哪一段、不许怎么走捷径**" | **接手的技术人 / Agent** | 见第 5 类 |

前四类共用同一套骨架顺序：**标题 → Stat 概览 → 约束/风险 Callout → 筛选 → 主体 → 明细**。顺序不要乱：人第一眼要看到"总量与红点"，最后才看细节。第 5 类（audit）的骨架不同，见该节。

**tracker 与 audit 是两种产物，不要混成一张。** 看板 / 门禁 / 时间线 / 对比都属于 tracker 家族（推进工作），audit 是另一族（纠正判断）。混在一起的结果：`progress` / `owner` / WIP 在 audit 里是噪声，而 `criterion` / `counterpart` 在 tracker 里没有位置。要同时有，就写两张画布，**让 tracker 的 `ref` 指向 audit 的 id，不要复制内容**。

**并排看内容量。** 卡片里只有「一个数字 + 一句标签」这种短内容（例如顶部的 Stat 概览）就并排——用 `<Grid columns="repeat(auto-fit, minmax(120px, 1fr))">`，窄栏会自动折成 2 列。承载句子、字段列表、表格的内容（待办 / 详情 / 明细 / 时间线）一律纵向：右栏宽度可变、默认偏窄，把长内容分栏必然挤碎（标签折行、表格列被挤成竖排）。Pill / Button / 徽标这类小控件可以放进 `Row`（记得 `wrap`）。

---

## 1. 看板 board

**用途**：把一批条目（任务、工单、迁移单元）按状态/分组盯住，并支持点开某条做决定。

**结构**

~~~text
H1 + Text(目标) + Text(快照日 / 修订 / WIP 上限)
Progress              -> 加权进度（按估算人日，不是条目计数）
Grid auto-fit         -> Stat 总数(带在办/关闭) / 在办-WIP / 阻塞 / 加权进度（一行并排，窄栏自动折 2 列）
Callout               -> 从数据派生的风险清单（阻塞 / 超期未更新 / WIP 超限 / 超估算 / 锚点自检）
Callout(info)         -> 「现在该做」：nextAction 一句话 —— 截断后第一眼要看的就是它
Row wrap              -> Pill 筛选（在办 / 阻塞 / 已关闭 / 全部 / 按分组）
Stack                 -> 主体：待办在前，详情在后
  CollapsibleSection(每组, trailing=在办数·完成%) -> Progress(该组) + TodoList
  CollapsibleSection(已关闭) -> TodoList(dense)
  Card 详情 -> Progress + KeyValue(字段，含依赖) + 动作按钮
Stack                 -> "下一步"：按优先级取前 3 条，各带一个开始按钮
Table                 -> 明细：ID / 优先 / 分组 / 标题 / 状态 / 负责人 / 进度 / 更新
CollapsibleSection    -> 约束与红线：rule / because / violation
CollapsibleSection    -> 已定决策：chose / rejected / why（用来阻止重新讨论）
CollapsibleSection    -> 活动时间线（Timeline）+ 维护说明
~~~

**上下文锚点。** `nextAction` / `constraints` / `decisions` 不是"额外的好东西"，而是
**截断后能否接手**的分界线：只有跟踪字段，接手的人知道你到哪了，但不知道自己能不能动
（红线）、什么已经被否（决策）、现在该做哪一件（唯一动作）。读取配方见
[resume.md](resume.md)。

**每个条目要有的字段**（少一个，跟踪就断一条）

| 字段 | 回答的问题 |
|---|---|
| `status` | 到哪一步了：`pending \| in_progress \| blocked \| completed \| cancelled` |
| `progress` + `estimate` + `actual` | 还要多少、已经花了多少（进度条与加权进度都从它算） |
| `startedAt` / `updatedAt` / `completedAt` | 停了多久、多久没动过（陈旧 = 需要复核） |
| `blocker` | 卡在哪；非空即算阻塞，必须写明在等谁 |
| `next` | 下一步动作一句话；它同时是 `startTurn` 的输入 |
| `acceptance` | 怎样算完成（可核对的断言，不是「做完」） |
| `evidence` | 结论指向的文件:行 / 测试名 / 运行编号 |
| `lane` / `priority` / `owner` | 分组、排序与认领 |

**派生分析一律现算，不手抄**

统计、加权进度、风险清单、下一步都从 `DATA` 现算：手抄的数字会先于现实过期，而且无法复核。

~~~tsx
const counted = tasks.filter((t) => t.status !== "cancelled");          // 取消的不计入分母
const estTotal = counted.reduce((s, t) => s + t.estimate, 0);
const weighted = counted.reduce((s, t) => s + t.estimate * progressOf(t), 0);
const progressPct = estTotal === 0 ? 0 : Math.round(weighted / estTotal);

const blocked = tasks.filter((t) => t.status === "blocked" || (t.blocker !== "" && isOpen(t)));
const stale = open.filter((t) => (daysBetween(t.updatedAt, DATA.asOf) ?? 0) > DATA.staleDays);
const risks = [];
if (blocked.length > 0) risks.push(blocked.length + " 条阻塞：" + blocked.map((t) => t.id).join("、"));
if (wip.length > DATA.wipLimit) risks.push("在办超过 WIP 上限 " + DATA.wipLimit);
~~~

> `asOf` 是**数据里的快照日**。所有「多少天没动」都相对它算，不要用 `Date.now()`：画布是快照，不是一个会自己漂的时钟。

**迭代热力：谁在反复折腾**

"这个任务改了多少次" 不该手抄 —— 它应该从**已有记录**里数出来。约定：活动日志的每条带上它属于哪个任务。

~~~tsx
activity: [
  { id: "a20", at: "2026-09-29", taskId: "V-04", title: "沙箱策略透传已验证",
    tone: "success", detail: "…", ref: "test/serve.test.mjs" },
]
~~~

看板据此现算矩阵（列 = 出现过的日期，行 = 任务）：

~~~tsx
const columns = useMemo(
  () => Array.from(new Set(DATA.activity.map((e) => e.at))).sort(),
  [],
);
const heatRows = tasks.map((task) => ({
  id: task.id,
  status: task.status,
  values: columns.map((at) => DATA.activity.filter((e) => e.at === at && e.taskId === task.id).length),
}));

<HeatMatrix columns={columns} rows={heatRows} unit="次" />
~~~

- **没有 `taskId` 的历史条目数不进来**，也不要用标题文本匹配兜底：那是猜的，而热力图的数字必须可复核；
- 数据不是活动日志的画布（例如按轮次人工记录），直接显式写 `iterations: { columns, rows }`；
- 两种 layout：`matrix` 看"哪一轮动的、谁最反复"，`grid` 看"整体规模 + 分布"（**面积 = 条目数**）；
- 想让**读者**自己切就加 `switchable`：`<HeatMatrix switchable … />` —— 视图存本机、agent 看不到（那是 UI 态，不是数据）。要自定义文案/位置，就在画布里用 `useCanvasState` 接自己的 `Pill` 行。


**关键片段：筛选 + 选中 + 人的状态改动**

~~~tsx
const dispatch = useCanvasAction();
const [filter, setFilter] = useCanvasState("filter", "open");
const [activeId, setActiveId] = useCanvasState("active", "T-01");
const overlay = useCanvasOverlay("tasks", DATA.tasks);   // 人的改动，agent 可见

const merged = useMemo(
  () => overlay.items.map((t) => ({ ...t, status: (t.status ?? "pending") })),
  [overlay.items],
);
const open = merged.filter((t) => t.status === "pending" || t.status === "in_progress" || t.status === "blocked");
const visible = filter === "open" ? open : merged;
const active = merged.find((t) => t.id === activeId) ?? open[0];
~~~

**关键片段：按钮把决定权交回 agent**

~~~tsx
<Button
  variant="primary"
  onClick={() => dispatch({
    type: "startTurn",
    prompt: "处理 " + active.id + "：" + active.title +
            "\n目标：" + active.goal +
            "\n遵守项目门禁；不要改共享管线以外的东西。",
  })}
>
  Start in chat
</Button>
<Button onClick={() => overlay.set(active.id, { status: "in_progress" })}>Mark active</Button>
<Button variant="ghost" onClick={() => overlay.set(active.id, { status: "completed" })}>Mark done</Button>
<Button variant="ghost" onClick={() => dispatch({ type: "openFile", path: active.write })}>Open file</Button>
~~~

**注意事项**

- **状态一定要走 `useCanvasOverlay`**：人要能用面板改状态，而你下一轮必须看得见。放 `useCanvasState` 等于人白点。
- **`blocked` 是状态，不是备注**：写在 `blocker` 字段里，面板才能把它算进风险清单；只写在 `note` 里等于没跟踪。
- 分组（`lane` / `bucket`）用 `CollapsibleSection` 包一组 `TodoList`，而不是一个巨大的扁平列表；组头带「在办数 · 完成%」。
- 详情卡用 `KeyValue` 排列字段，不要堆一长串 `Text`；字段超过 8 条就把历史挪进时间线。
- 进度用 `Progress`，更新用 `updatedAt`：只给状态不给进度，人看不出是在推进还是在原地打转。
- 内联只留"当前窗口"：在办 + 最近完成。归档进折叠区或另一张画布。

---

## 2. 门禁 gates

**用途**：盯一组**可复现的检查**（测试、对拍、基线）的通过情况，并让人能当场重跑。

**结构**

~~~text
H1 + Text(基线是什么、怎么复现)
Grid auto-fit         -> Stat 通过 / 失败 / 未跑（一行并排）
Callout danger        -> 失败清单（有失败时才渲染）
Table                 -> Gate | 基线 | 最近 | Δ | 状态 | 操作(每行一个 Run 按钮)
Row                   -> Run all 按钮 + 最近一次运行时间
CollapsibleSection    -> 如何在 Config 里登记白名单
~~~

**关键片段：每行一个重跑按钮**

~~~tsx
<Table
  headers={["Gate", "基线", "最近", "Δ", "状态", "操作"]}
  columnAlign={["left", "left", "left", "right", "left", "left"]}
  rows={DATA.gates.map((g) => [
    <Code>{g.id}</Code>,
    g.baseline,
    g.last,
    g.baseline === g.last ? "0" : "changed",
    <Pill size="sm" tone={g.ok ? "success" : "danger"}>{g.ok ? "pass" : "fail"}</Pill>,
    <Button size="sm" onClick={() => run(g)}>Run</Button>,
  ])}
  rowTone={DATA.gates.map((g) => (g.ok ? "success" : "danger"))}
/>
~~~

~~~tsx
async function run(g) {
  const r = await dispatch({ type: "runCommand", id: g.runId });
  if (!r.ok) {
    await dispatch({ type: "notify", tone: "warning", message: g.id + " 未执行：" + r.message });
  }
}
~~~

**关键片段：人工确认走 overlay**

~~~tsx
// 门禁结果来自 harness；人只对"我知道这条红着但先接受"负责
const acks = useCanvasOverlay("gates", DATA.gates);
<Pill
  tone={acks.get(g.id)?.acked ? "neutral" : g.ok ? "success" : "danger"}
  onClick={() => acks.set(g.id, { acked: true })}
>
  {acks.get(g.id)?.acked ? "acked" : g.ok ? "pass" : "fail"}
</Pill>
~~~

**注意事项**

- **`runCommand` 默认全拒**：`id` 必须先在插件 Config 的 `commandWhitelist` 里登记，且逐字匹配。被拒返回 `{ ok: false, code: "denied" }`——要在画布上显示"需登记 / 需提权"，不要静默失败。
- **结果不要手抄进 `DATA`**：`baseline` / `last` 是运行产物。画布只负责**显示与触发**；数字由 harness 写回（`canvas_state_merge` 或 agent 改 DATA）。手抄就是伪造证据。
- `基线 vs 最近` 两列都要有：只有一列"通过"的话，人看不出是不是回落了。
- 颜色只用 tone：`success` 通过、`danger` 失败、`neutral` 未跑 / 已接受、`warning` 抖动。

---

## 3. 时间线 timeline

**用途**：按时间/轮次看推进过程，回答"这几轮分别做了什么、什么时候停的"。

v1 没有专用时间线组件——用 `Table` + 分组实现，效果一样且更省事。

**结构**

~~~text
H1 + Text(时间范围)
Grid auto-fit         -> Stat 本轮 / 累计 / 停滞天数（一行并排）
BarChart (可选)        -> 每天/每轮的事件计数
CollapsibleSection(每天/每轮, defaultOpen=最近一个)
   Table              -> 时间 | 事件 | 状态 | 证据
~~~

**关键片段：倒序 + 分组**

~~~tsx
const groups = useMemo(() => {
  const by = new Map();
  for (const e of DATA.events) {
    if (!by.has(e.day)) by.set(e.day, []);
    by.get(e.day).push(e);
  }
  return Array.from(by.entries()).sort((a, b) => (a[0] < b[0] ? 1 : -1)); // 新的在前
}, []);

groups.map(([day, events]) => (
  <CollapsibleSection key={day} title={day} count={events.length} defaultOpen={day === groups[0][0]}>
    <Table
      headers={["时间", "事件", "状态", "证据"]}
      columnAlign={["left", "left", "left", "left"]}
      rows={events.map((e) => [
        e.at,
        e.title,
        <Pill size="sm" tone={e.ok ? "success" : "warning"}>{e.ok ? "done" : "partial"}</Pill>,
        <Code>{e.ref}</Code>,
      ])}
      rowTone={events.map((e) => (e.ok ? "success" : "warning"))}
    />
  </CollapsibleSection>
))
~~~

**注意事项**

- **日期是数据，不是现场取的**：`DATA` 里写字符串字面量（`"2026-09-21"`）。画布里没有定时器，也不该有"当前时间"这种会漂的状态。
- `new Date()` 只在渲染期做分组/排序时用（`DATA` 内禁止函数调用）。
- 只显示"最近 N 条 / 最近 N 天"，更早的进折叠区或另一个画布——时间线最容易无限膨胀。
- 时间线的价值在**证据列**：每条都该指向可核对的文件、日志或提交，而不是一句结论。

---

## 4. 对比 comparison

**用途**：把"我们的结果"和"参考结果"逐项摆在一起，让人一眼看到差在哪、差多少。

**结构**

~~~text
H1 + Text(参考是什么、口径是什么)
BarChart              -> 分组柱：ours vs reference（缺失值不要用 0 冒充）
Table                 -> 项 | ours | ref | Δ | 结论
Callout (可选)         -> 最大的差异点与下一步
~~~

**关键片段：Δ 与方向色**

~~~tsx
const rows = DATA.models.map((m) => {
  const hasRef = m.ref !== null;
  const delta = hasRef ? m.ours - m.ref : null;
  return {
    ...m,
    hasRef,
    delta,
    tone: !hasRef ? "neutral" : delta === 0 ? "success" : delta > 0 ? "warning" : "danger",
  };
});

<Table
  headers={["项", "ours", "ref", "Δ", "结论"]}
  columnAlign={["left", "right", "right", "right", "left"]}
  striped
  rows={rows.map((r) => [
    r.name,
    String(r.ours),
    r.hasRef ? String(r.ref) : "—",
    r.delta === null ? "no ref" : (r.delta > 0 ? "+" : "") + String(r.delta),
    r.hasRef ? (r.delta === 0 ? "aligned" : "differs") : "no reference",
  ])}
  rowTone={rows.map((r) => r.tone)}
/>
~~~

**注意事项**

- **缺失参考要明确写"—" / "no ref"**，绝不能用 0 参与比较：0 会被读成"我们少了 100%"，而且会污染图表尺度。`BarChart` 里缺失项要显式给 0 但配以列表说明，或干脆排除该 category。
- `Δ` 只在双方都有值时计算。方向色要固定含义（大 = 警告 / 小 = 危险，或反之），并在画布上写清口径。
- 口径写在 `Text` 里：参考来自哪个文件、哪个版本、什么参数。没有口径的对比表会误导人。
- 结论列是有价值的一列：把"是否在容差内"显式写出来，不要让人自己算。

---

## 5. 审计 audit

**用途**：把一个**有参照物**的对象核对清楚，交给**接手的人**——他要的是三件事：*我原来的哪些判断已经过期*、*还差什么（缺的是参照物的哪一段）*、*不许怎么走捷径*。

**先决条件（缺一条就别用这个范式）**：① 有参照物与口径（参照实现 / 冻结契约 / 规范文档都算；**没有就退回自基线对照并显式声明**）；② 读者是接手的人而不是汇报对象；③ 有预算做逐项核对（没有预算就立骨架 + 标 `未填`，别写满空话）。

### 骨架

`标题（对象 + 参照物 + 口径）` → `Stat 概览（条目数 · 已核对 · 残留 · 覆盖轮次）` → `口径 Callout` → `参照物与残差总览（PieChart：已核对/部分/未修）` → `论断表` → `仍为未修（带对照物，标题写「勿误读为已修」）` → `禁令` → `勘误` → `复核轮记录`。

**不要**放进度百分比、`owner`、WIP 上限、优先级——那些属于 tracker。

### 数据形状（字段化索引 + 论证散文化）

能用来**按条件筛**的进字段，只有人能读的推理留在 `note`：

~~~ts
export const DATA = {
  reference: {
    // 四选一。它决定这张画布**能查出哪一类问题**：
    //   文档   = 契约 / 规范文档     → 能查「说 vs 做」（承诺与实现是否一致）
    //   实现   = 参照实现（源码）     → 能查「做 vs 做」（逐行/逐符号是否对应）
    //   产物   = 参照产物（模型/导出）→ 能查「做 vs 对」（读数逐项是否相同）
    //   自基线 = 没有外部参照物       → 只能查「今天 vs 昨天」；禁止写"逐项相同"
    kind: "产物",
    what: "OCCT 的 .cxx 与 data/occ/*.step",
    scope: "忠实 = 与 .cxx 逐行对应；等价替换 = 语义等价但须登记翻译边界；自创 = 参照物无此规则/阈值/分支",
    at: "2026-09-20",                      // 审查基线
    detects: "面/点逐值、WIREHIST 逐项",     // 这张画布能查出什么
    cannotDetect: "性能与内存（参照产物里没有这两个读数）",  // 查不出什么——读者要一眼看见边界
  },
  product: "audit",
  rowsKey: "claims",                       // 声明行键，接手路径才看得见这些行
  openStatuses: ["未修", "部分"],           // 声明状态词表，摘要据此判断哪些行还要人管
  claims: [{
    id: "A26", claim: "STEP 写侧用 6×6 采样重拟产 B-spline 曲面",
    status: "已核对" | "部分" | "未修",
    criterion: { level: "L1", metric: "面/点逐值", ref: "data/occ/occ-motoc.obj", delta: "4 → 0" },
    counterpart: { port: "step/write_context.rs:404 emit_surface",
                   occt: "GeomToStep_MakeBoundedSurface.cxx:41-88",
                   doneWhen: "直读面自身极点/结点/权重，不再拟合" },
    measured: { round: "三轮", at: "2026-10-07", mode: "热跑 336.72s" },
    note: "多行推导：为什么诱人、试过什么、结论怎么来的",
  }],
  stillUnported: [{ id, what, portRef, occtRef }],           // 标题必须写「本轮未动，勿误读为已修」
  prohibitions: [{ pattern, temptingBecause, observableSymptom, reviewWhen }],
  corrections: [{ id, was, now, why, at, round }],            // 旧断言 → 新事实；判断级留，行号级不留
  rounds: [{ id, at, what, gates: [{ id, reading, mode }] }], // 复核轮 + 门禁读数（含冷/热）
} as const;
~~~

### 三条纪律（第三条最常被漏）

1. **判据分级**：`L1` = 与外部参照逐项对拍并指名参照产物；`L2` = 与自身基线对拍并给 Δ。有参照物却只用 L2 不算交付。
2. **残留带对照物**：`端口符号 ⇔ 参照物 文件:行` + `doneWhen`。只写"待重做"等于没写；**假出处比不写更糟**（本仓有过"假出处 7 处"的前科）。
3. **禁令是三元组且必须可执行**：`禁止的模式 / 为什么诱人 / 违反后的可观测症状` + `reviewWhen`。只写第一项，Agent 判不出自己做没做。

### 让接手路径认得这张画布

audit 的行通常不叫 `tasks`，状态词表也不是 `pending/in_progress/blocked`。**最省事的做法是画布自己声明**：

~~~ts
rowsKey: "claims",                    // 哪一支是行集
openStatuses: ["未修", "部分"],        // 哪些状态算「还要人管」
~~~

声明之后 `canvas_read(path, brief: true)` 无参就能拿到正确的 `focus`，`notes` 归零，摘要还会回显 `openStatusesSource`（`caller` / `data` / `default`）告诉你词表是谁定的。调用方也可以用参数覆盖：`canvas_read(path, brief: true, rowsKey: "claims", openStatuses: [...])`。

两者都没有时，digest 只会**跟着 `nextAction` 的锚点走**（锚点点进哪一支，就认哪一支是行集），因为放宽到"任何 id+status 数组"会把门禁表也当成行集——它的 `status` 是 green/red 这类判决，不是工作状态，于是产出一句误导性的"0 of 4 rows match the open statuses"。没被采纳的行集不会被静默吞掉：若它看起来像工作行（状态落在默认词表里），digest 会**点名**它并提示传 `rowsKey`。

同理，`nextAction` 的锚点字段可以叫 `claimId` / `taskId` / `rowId`，digest 都认。

### 反模式

| 反模式 | 为什么坏 | 正确做法 |
|---|---|---|
| 没有参照物也写"逐项相同" | 伪造证据 | 声明 `reference.kind`，降级 L2 并改措辞 |
| 用存在性检查当判据（"能装上了"） | 不可复算、不可否证 | L1 对拍 / L2 自基线 + Δ |
| 残留只写"待重做" | 接手的人没有目标态，只能自己猜 | 补 `counterpart` 三件套 |
| 静默改掉旧断言 | 接手的人会误信已失效的结论 | 写进 `corrections` |
| 把进度字段搬进来 | audit 变成第二张进度看板 | 进度留 tracker，用 `ref` 关联 |
| 24 条勘误里一半是行号漂移 | 每次改动都要重写，价值接近零 | 行号由工具现查，勘误只留**判断级**变更 |

### 最小示例（本仓可跑）

`canvas_new(path, "audit")` 直接起步（骨架带四条自查）；完整实例见 `docs/audit/interface-audit.canvas.tsx`：以 [INTERFACE.md](../../../INTERFACE.md)（冻结契约）+ 规范文档为参照物，核对本插件实现。它的 `prohibitions` / `stillUnported` / `corrections` 三段可以直接照抄结构。
