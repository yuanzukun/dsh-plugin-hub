/** @canvas
 * title: Auditoría / 审计骨架
 * description: 以参照物为准核对实现或产物的骨架：断言带判据分级与对照物，另有禁令、勘误、残留、复核轮
 * icon: board
 * hidden: true
 */
// 模板：`canvas_new(path, "audit")` 复制出去用。四条纪律先看这里再看代码——
//   1) 先声明参照物与口径（reference）：判据的合法性全来自它；
//   2) 每条断言给「判据分级 + 度量 + 结果」与「端口符号 ⇔ 参照物 文件:行 + 完成判据」；
//   3) 禁令是三元组（模式 / 为什么诱人 / 违反后的可观测症状）+ 复核条件；
//   4) 判断级变更写进 corrections，行号级漂移不进板面（由工具现查）。
// 完整实例见 docs/audit/interface-audit.canvas.tsx。
import {
  Button,
  Callout,
  Card,
  CardBody,
  CardHeader,
  Code,
  Grid,
  H1,
  H2,
  H3,
  KeyValue,
  PieChart,
  Pill,
  Row,
  Stack,
  Stat,
  Table,
  Text,
  useCanvasAction,
  useCanvasOverlay,
} from "dsh/canvas";

type AuditStatus = "已核对" | "部分" | "未修";
type Tone = "success" | "warning" | "danger" | "info" | "neutral";

export const DATA = {
  // ---- 第 0 步三件 --------------------------------------------------------
  reference: {
    // kind 四选一，它决定这张画布**能查出哪一类问题**：
    //   文档   = 冻结契约 / 规范文档  → 能查「说 vs 做」（承诺与实现是否一致）
    //   实现   = 参照实现（源码）      → 能查「做 vs 做」（逐行/逐符号是否对应）
    //   产物   = 参照产物（模型/导出） → 能查「做 vs 对」（读数逐项是否相同）
    //   自基线 = 没有外部参照物        → 只能查「今天 vs 昨天」；禁止写"逐项相同"
    kind: "文档",
    what: "把参照物逐项列出来（哪份契约、哪个模块、哪批产物）",
    scope: "口径：什么算等价、什么算自创、什么算通过。没有口径就没有判据。",
    at: "2026-10-02",
    detects: "承诺与实现是否一致（说 vs 做）",
    cannotDetect: "行为偏差（需要实现型或产物型参照物才能逐项对拍）",
  },
  product: "audit",
  budget: "本轮预算：几路深审、有没有可对拍的参照产物；预算不足就立骨架并显式标未填",

  asOf: "2026-10-02",
  revision: "a1",
  goal: "一句话说清这次要核对到什么程度",
  // 画布自己声明行键与状态词表：摘要据此直接看见在办行，调用方不必传参
  rowsKey: "claims",
  openStatuses: ["未修", "部分"],

  // ---- 唯一下一步 + 审计自身的红线 + 已定裁决 ------------------------------
  nextAction: {
    claimId: "X-01",
    action: "下一步只写一件：谁、做什么、改完拿什么当判据",
    why: "为什么是它而不是别的（截断后接手的人只看这一行）",
  },
  constraints: [
    { rule: "对照物必须可核对：给到参照物的 文件:行", because: "不可核对的对照物等于空话，假出处比不写更糟", violation: "整条断言作废" },
    { rule: "判据必须分级且不许留空", because: "L1 = 外部对拍，L2 = 自基线 + Δ；留空会被读成「刚测过」", violation: "接手的人无法判断结论是否仍然成立" },
  ],
  decisions: [
    { id: "D-a1", at: "2026-10-02", chose: "参照物取 A，不取 B", rejected: ["以 B 为参照物"], why: "A 可 grep / 可对拍，B 拿不到", ref: "参照物的出处" },
  ],

  // ---- 断言 ---------------------------------------------------------------
  claims: [
    {
      id: "X-01",
      claim: "一句话断言（可判定，不是感想）",
      status: "未修",
      criterion: { level: "L1", metric: "可复算的度量", ref: "参照物里对应的那一句/那一段", delta: "要求 X → 实测 Y" },
      counterpart: {
        port: "端口哪个符号（文件:行）",
        occt: "参照物哪个文件:行 + 它要求什么",
        doneWhen: "什么算完成（可判定，不是「改好为止」）",
      },
      measured: { round: "一轮", at: "2026-10-02", mode: "冷跑 / 热跑 / 探针名（口径也是证据）" },
      note: "多行推导：为什么诱人、试过什么、怎么排除的。推理链是资产，不受 120 字纪律约束。",
    },
    {
      id: "X-02",
      claim: "第二条断言",
      status: "已核对",
      criterion: { level: "L2", metric: "占基线的比例", ref: "自基线（写明是哪份基线）", delta: "29.3% → 目标 <10%" },
      counterpart: {
        port: "端口符号（文件:行）",
        occt: "无外部参照物——只能自比，禁止写「与 X 一致」",
        doneWhen: "什么算完成",
      },
      measured: { round: "一轮", at: "2026-10-02", mode: "探针 / 测试命令" },
      note: "L2 的 Δ 非零时必须写清为什么可接受。",
    },
  ],

  // ---- 仍为未修（本轮未动，勿误读为已修）----------------------------------
  stillUnported: [
    { id: "S-01", what: "明确写出仍是欠账的那一小件", portRef: "端口位置", occtRef: "参照物位置，或「无外部参照物」" },
  ],

  // ---- 禁令（未经尝试就先禁止的路线）------------------------------------
  prohibitions: [
    {
      pattern: "禁止的模式（例如：用某个自创启发式迁就）",
      temptingBecause: "为什么它看起来划算",
      observableSymptom: "违反后你看得见的症状——没有这一项，禁令不可执行",
      reviewWhen: "什么条件下重评（上游阻塞解除后？）",
    },
    {
      pattern: "把门禁 / 测试数字手抄进 DATA 当证据",
      temptingBecause: "写进去之后板面看起来最有说服力",
      observableSymptom: "读数与最近一次真实运行不一致",
      reviewWhen: "runCommand 的结果能自动写回 DATA 之后重评",
    },
  ],

  // ---- 勘误（旧断言 → 新事实；判断级留，行号级不留）----------------------
  corrections: [
    { id: "E-01", was: "旧的判断", now: "现在的事实", why: "为什么会漂（口径变了？没人重测？）", at: "2026-10-02", round: "一轮" },
  ],

  // ---- 复核轮与门禁读数（含冷/热与「未复跑」）----------------------------
  rounds: [
    {
      id: "一轮",
      at: "2026-10-02",
      what: "这轮做了什么（参照物怎么对、命令怎么跑）",
      gates: [
        { id: "门禁名", reading: "读数", mode: "冷跑 / 热跑" },
        { id: "真实 GUI 目视", reading: "未复跑", mode: "—" },
      ],
    },
  ],
} as const;

const TONE: Record<AuditStatus, Tone> = { 已核对: "success", 部分: "warning", 未修: "danger" };

export default function AuditSkeleton() {
  const dispatch = useCanvasAction();
  const reviewed = useCanvasOverlay("claims", DATA.claims);
  const claims = reviewed.items as unknown as Array<(typeof DATA.claims)[number]>;

  const counts = { ok: 0, part: 0, open: 0 };
  for (const c of claims) {
    if (c.status === "已核对") counts.ok++;
    else if (c.status === "部分") counts.part++;
    else counts.open++;
  }

  const statusPill = (s: AuditStatus) => <Pill size="sm" tone={TONE[s]}>{s}</Pill>;

  return (
    <Stack gap={24}>
      <Stack gap={6}>
        <H1>审计：&lt;对象&gt; vs &lt;参照物&gt;</H1>
        <Text tone="secondary">
          审计日 {DATA.asOf} · 修订 {DATA.revision} · 参照物（{DATA.reference.kind}）
          <Text as="span" weight="semibold"> {DATA.reference.what}</Text>
        </Text>
        <Text tone="tertiary" size="small">
          本画布的参照物类型是「{DATA.reference.kind}」：能查 {DATA.reference.detects}；查不出 {DATA.reference.cannotDetect}。
        </Text>
      </Stack>

      <Callout tone="info" title="口径">
        <KeyValue
          items={[
            { label: "口径", value: <Text as="span" size="small">{DATA.reference.scope}</Text> },
            { label: "基线日", value: <Code>{DATA.reference.at}</Code> },
          ]}
          dense
        />
      </Callout>

      <Grid columns={4} gap={12}>
        <Stat value={String(claims.length)} label="断言" />
        <Stat value={String(counts.ok)} label="已核对" tone="success" />
        <Stat value={String(counts.part)} label="部分" tone="warning" />
        <Stat value={String(counts.open)} label="未修" tone="danger" />
      </Grid>

      <Grid columns="1fr 1fr" gap={16}>
        <Stack gap={10}>
          <Text weight="semibold">处置分布</Text>
          <PieChart
            donut
            data={[
              { label: "已核对", value: counts.ok, tone: "success" },
              { label: "部分", value: counts.part, tone: "warning" },
              { label: "未修", value: counts.open, tone: "danger" },
            ]}
          />
        </Stack>
        <Stack gap={10}>
          <Text weight="semibold">现在该做（全局唯一）</Text>
          <Callout tone="warning" title={DATA.nextAction.claimId}>
            <Text>{DATA.nextAction.action}</Text>
            <Text as="span" tone="tertiary" size="small">（{DATA.nextAction.why}）</Text>
          </Callout>
          <Row gap={8} wrap>
            <Button
              size="sm"
              onClick={() =>
                dispatch({
                  type: "startTurn",
                  prompt: "处理 " + DATA.nextAction.claimId + "：" + DATA.nextAction.action + "。只改这一处，改完跑自检并把判据与测量口径写回这张审计画布。",
                })
              }
            >
              在会话里开始
            </Button>
            <Button size="sm" variant="ghost" onClick={() => reviewed.set(String(DATA.nextAction.claimId), { status: "已核对" })}>
              标记已复核
            </Button>
          </Row>
        </Stack>
      </Grid>

      <H2>断言明细</H2>
      <Text tone="tertiary" size="small">
        窄表只放能扫的字段；断言、对照物与推导放在下面的卡片里——右栏默认偏窄，把句子塞进多列表格会把列挤成竖排。
      </Text>
      <Table
        headers={["#", "状态 / 级别", "判据（度量 → 结果）"]}
        rows={claims.map((c) => [
          <Code>{c.id}</Code>,
          <Row gap={4} align="center">{statusPill(c.status)}<Pill size="sm">{c.criterion.level}</Pill></Row>,
          <Text as="span" size="small">{c.criterion.metric + " → " + c.criterion.delta}</Text>,
        ])}
        columnAlign={["left", "center", "left"]}
        rowTone={claims.map((c) => TONE[c.status])}
        striped
      />

      <Stack gap={12}>
        {claims.map((c) => (
          <Card key={c.id}>
            <CardHeader trailing={<Row gap={4} align="center">{statusPill(c.status)}<Pill size="sm">{c.criterion.level}</Pill></Row>}>
              <Text>
                <Code>{c.id}</Code>
                <Text as="span" weight="semibold">　{c.claim}</Text>
              </Text>
            </CardHeader>
            <CardBody>
              <Stack gap={8}>
                <KeyValue
                  dense
                  items={[
                    { label: "端口", value: <Code>{c.counterpart.port}</Code> },
                    { label: "参照物", value: <Text as="span" size="small">{c.counterpart.occt}</Text> },
                    { label: "完成判据", value: <Text as="span" size="small">{c.counterpart.doneWhen}</Text> },
                    { label: "判据来源", value: <Text as="span" size="small" tone="tertiary">{c.criterion.ref}</Text> },
                    { label: "测量", value: <Text as="span" size="small">{c.measured.round + " · " + c.measured.at + " · " + c.measured.mode}</Text> },
                  ]}
                />
                <Text size="small" tone="secondary">{c.note}</Text>
              </Stack>
            </CardBody>
          </Card>
        ))}
      </Stack>

      <H2>仍为未修（本轮未动，勿误读为已修）</H2>
      <Table
        headers={["#", "条目 · 端口 · 参照物"]}
        rows={DATA.stillUnported.map((s) => [
          <Code>{s.id}</Code>,
          <Stack gap={2}>
            <Text as="span" size="small">{s.what}</Text>
            <Text as="span" size="small" tone="secondary">{s.portRef}</Text>
            <Text as="span" size="small" tone="tertiary">{s.occtRef}</Text>
          </Stack>,
        ])}
        columnAlign={["left", "left"]}
        rowTone={["warning"]}
        striped
      />

      <H2>禁令（未经尝试就先禁止的路线）</H2>
      <Stack gap={12}>
        {DATA.prohibitions.map((p, index) => (
          <Card key={p.pattern}>
            <CardHeader trailing={<Pill size="sm" tone="danger">禁令 {index + 1}</Pill>}>
              <Text weight="semibold">{p.pattern}</Text>
            </CardHeader>
            <CardBody>
              <KeyValue
                dense
                items={[
                  { label: "为什么诱人", value: <Text as="span" size="small">{p.temptingBecause}</Text> },
                  { label: "可观测症状", value: <Text as="span" size="small">{p.observableSymptom}</Text> },
                  { label: "复核条件", value: <Text as="span" size="small" tone="tertiary">{p.reviewWhen}</Text> },
                ]}
              />
            </CardBody>
          </Card>
        ))}
      </Stack>

      <H2>勘误（旧断言 → 新事实）</H2>
      <Table
        headers={["#", "旧断言 → 新事实 · 为什么漂了"]}
        rows={DATA.corrections.map((c) => [
          <Code>{c.id}</Code>,
          <Stack gap={2}>
            <Text as="span" size="small" tone="danger">{c.was}</Text>
            <Text as="span" size="small">→ {c.now}</Text>
            <Text as="span" size="small" tone="tertiary">{c.why}（{c.at} · {c.round}）</Text>
          </Stack>,
        ])}
        columnAlign={["left", "left"]}
        rowTone={["warning"]}
        striped
      />

      <H2>复核轮与门禁读数</H2>
      <Table
        headers={["轮", "门禁", "读数 · 口径"]}
        rows={DATA.rounds.flatMap((r) => r.gates.map((g) => [
          <Text as="span" size="small" weight="semibold">{r.id}</Text>,
          <Code>{g.id}</Code>,
          <Stack gap={2}>
            <Text as="span" size="small">{g.reading}</Text>
            <Text as="span" size="small" tone="tertiary">{g.mode} · {r.what}</Text>
          </Stack>,
        ]))}
        columnAlign={["left", "left", "left"]}
        rowTone={["success", "warning"]}
        striped
      />

      <Card>
        <CardHeader trailing={<Pill size="sm">audit</Pill>}><H3>交付前自查（四条）</H3></CardHeader>
        <CardBody>
          <Stack gap={6}>
            <Text size="small">① 每条断言的 `counterpart.occt` 都能被一次 grep 否证（写不出 `文件:行` 就等于没写）；</Text>
            <Text size="small">② `criterion.level` 是 L1 还是 L2 说得清；L2 的 Δ 非零时写清了为什么可接受；</Text>
            <Text size="small">③ 每条禁令都有「可观测症状」——否则 Agent 判不出自己做没做；</Text>
            <Text size="small">④ 判断级变更进了 `corrections`，行号级漂移没有进板面。</Text>
          </Stack>
        </CardBody>
      </Card>

      <Text tone="tertiary" size="small">
        范式与完整实例：skills/canvas/references/patterns.md 第 5 类 · docs/audit/interface-audit.canvas.tsx。
      </Text>
    </Stack>
  );
}
