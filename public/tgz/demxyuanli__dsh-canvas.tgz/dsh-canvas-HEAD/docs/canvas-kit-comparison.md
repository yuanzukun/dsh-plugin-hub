# `cursor/canvas` ↔ `dsh/canvas` 对照

> 对读对象：一份真实的 Cursor 画布源码（OCCT → Rust 移植审计：`A0–A31` 32 条 + 6 个开放项 + 8 个门禁 + 12 个大文件 + 1 个开放个案），`import` 16 个符号自 `"cursor/canvas"`。
> 本侧：本插件的套件 `dsh/canvas`，版本 `KIT_VERSION = "k4"`，**25 个组件 + 10 个钩子**（冻结契约见 [INTERFACE.md](../INTERFACE.md) §5；编译期导出面单一来源在 `host/kitsurface.js`，与 `lib/client.js` 由测试双向校验）。
>
> **落地状态（对读后两轮）**：本次对读直接产出三项改动，均已实现并有回归测试，见 [DESIGN.md](../DESIGN.md) §32：
> 1. **`E_UNKNOWN_EXPORT`** —— 编译期校验具名导入（P0，把"渲染期崩溃"提前成"编译期诊断"）；
> 2. **`H3` / `Text as="span"` / `Text tone` 四档别名** —— 补齐组件面缺口（P1，v1.2）；
> 3. **`PieChart`（饼/环）** —— 本次对读列出的最后一个组件缺口（P2，v1.3）。
> 下文的表格已是**落地后**的状态；§5.2 保留了改动**前**的实测输出作为证据。

---

## 1 一句话结论

**组件面已经完全对齐；真正值得复用的是那条导出面校验。**

16 个 import 现在**全部**在名字、props、语义上与本套件一致（其中 `H3`、`Text as="span"`、`tone="quaternary"`、`PieChart` 是对读后补上的）。

而对读暴露出的、比任何组件缺口都值钱的问题是一条**契约漏洞**：套件的导出面早已是冻结契约，但编译期只校验**模块说明符**，不校验**具名导入**。于是一份从兄弟套件搬来的画布只差一行 import 就能通过 `canvas_check`，然后在渲染期崩成错误卡——反馈落在最贵的路径上。现在这条由 `E_UNKNOWN_EXPORT` 在编译期挡下（实测见 §5.2）。

另外两条仍是**契约级差异**，与组件无关：

1. **数据契约**：这份画布把数据放在模块级 `const ITEMS / OPEN_ITEMS / GATES / BIG_FILES` 里，而本套件的规范是 `export const DATA = {...} as const`。后果不是"能不能渲染"，而是 **Agent 能不能只读一片**——没有 `DATA` 就没有 `dataPath` 切片、没有 overlay 可寻址的行、没有 `brief` 摘要。
2. **产物意图**：这份画布是纯只读报表（无按钮、无锚点），本套件的规范要求产物可回灌。

---

## 2 组件面逐项对照

| 这份源码的用法 | `dsh/canvas` | 判定 | 说明（实现位置） |
|---|---|---|---|
| `Callout tone="success\|warning" title=…` | `Callout {tone="info", title?, size?, children}` | ✅ 等价 | `lib/client.js:253` |
| `Card` / `CardHeader trailing` / `CardBody` | 同名同形 | ✅ 等价 | `:226 / :235 / :249` |
| `Grid columns={5}` 与 `columns="1fr 1fr"` | `columns?: number \| string = 2` | ✅ 等价 | 数字 → `repeat(N, minmax(0,1fr))`，字符串原样；`:146` |
| `H1` / `H2` | 同名，仅 `children`（另有 `style` 逃生口） | ✅ 等价 | `:190 / :194` |
| `H3` | `H3`（**对读后补上**，harness 刻度 14/22 · 500） | ✅ 等价 | `lib/client.js` H3；`k2 → k3` |
| `PieChart donut data={[{label,value,tone}]}` | `PieChart {data, donut?, height?, unit?, maxSlices?, showLegend?}`（**对读后补上**，v1.3） | ✅ 等价 | 手写 SVG；未给 tone 时五档循环取色；超 `maxSlices` 折成「其他」并计数 |
| `Pill size="sm"`（无 tone） | `Pill {size, tone?, active?, onClick?}` | ✅ 等价 | 无 `tone` = 中性色，且 `cursor: default`；`:410` |
| `Row gap align="center"` / `wrap` | `Row {gap=8, wrap?, align=center, justify?, style?}` | ✅ 等价 | `:132` |
| `Stack gap={24}` | `Stack {gap=12, align?, style?}` | ✅ 等价 | `:120` |
| `Stat value label tone` | `Stat {value, label, tone?, hint?}` | ✅ 等价 | `:267` |
| `Table headers rows columnAlign rowTone striped` | 同名同形 | ✅ 等价 | 另有 `stickyHeader` / `emptyText` / `maxRows=300` / `maxHeight` / `onRowClick(index)`；`:433` |
| `Text tone="secondary"\|"tertiary" size="small"` | `Text {size, weight, tone, as?, style?, children}` | ✅ 等价 | `:198` |
| `Text tone="quaternary"` | `quaternary`（**对读后补上**） | ✅ 等价 | 与 `caption` 同档，映射 `--dsw-alias-label-caption`；顺带修掉 `tone="primary"` 原本也静默降级的问题；`:104` |
| `<Text as="span" weight="semibold">`（嵌在 `<Text>` 里做行内强调） | `as="span"`（**对读后补上**） | ✅ 等价 | 默认仍是 `div`，`as="span"` 才内联；`:198` |
| `useHostTheme()` | 同名，返回 `{dark, tone(), text, space()}` | ✅ 等价 | 该源码取了 `theme` 却未使用——两边都不报错；`:1038` |

**我们多出、这份源码没有用到的**（不代表 Cursor 没有，只是这份没用）：

- 组件：`Divider`、`CollapsibleSection`、`Code`、`BarChart`、`HeatMatrix`、`TodoList`、`Progress`、`KeyValue`、`Timeline`、`Button`
- 钩子：`useCanvasState`、`useCanvasOverlay`、`useCanvasAction`、`useCanvasResource`，以及 `useState/useEffect/useMemo/useCallback/useRef` 的 re-export

---

## 3 钩子面

| Cursor（本份源码 + 设计文档记录） | `dsh/canvas` | 判定 |
|---|---|---|
| `useHostTheme` | `useHostTheme` | ✅ 同名同形 |
| `useCanvasState`（localStorage 持久化） | `useCanvasState` | ✅ 同名（键空间与作用域实现不同，见下） |
| `useCanvasAction`（`{type:"newComposerChat",…}`） | `useCanvasAction`（`startTurn` / `runCommand` / `overlaySet` / `notify` / `openFile` / `openResource` / `copy`） | ✅ 同位置，动作表不同 |
| — | `useCanvasOverlay`（落 sidecar，Agent 可见） | ➕ 本侧独有，是"内联数据"的补偿机制 |
| — | `useCanvasResource`（读工作区文本） | ➕ 本侧独有 |
| `useMemo` re-export | 5 个 React 钩子全部 re-export | ✅ 同思路 |

---

## 4 这份源码逐构造移植评估

| 源码构造 | 在本套件下的行为 | 等级 |
|---|---|---|
| `import { … } from "cursor/canvas"` | 改成 `"dsh/canvas"` 即可；其它任何说明符 → `E_PARSE_IMPORT` | ✅ 一行改动 |
| `type Disposition` / `interface AuditItem` | 允许（sucrase 剥类型） | ✅ 直接可用 |
| `const ITEMS: AuditItem[] = [ … 32 条 … ]` | 允许（顶层纯字面量）；但 `canvas_read` 报 **`W_NO_DATA`** 并退化为全文读取，`canvas_state_merge` 无法寻址 | ⚠️ 静默降级 |
| `const TONE: Record<Disposition, …>` | 允许（纯字面量） | ✅ 直接可用 |
| `const statusPill = (s) => <Pill size="sm">{s}</Pill>` | 允许（顶层纯函数） | ✅ 直接可用 |
| 渲染期 `ITEMS.map(…)` / `.slice(0, 6)` | 允许 | ✅ 直接可用 |
| `<Table rows={ITEMS.map(…)} rowTone={…}></Table>` | 等价 | ✅ 直接可用 |
| `<Text as="span" weight="semibold">` 嵌套 | **直接可用**（`as="span"` 已补） | ✅ 一行改动 |
| `tone="quaternary"` | **直接可用**（与 `caption` 同档） | ✅ 直接可用 |
| `<H3>旁支（未动手）</H3>` | **直接可用**（`H3` 已补） | ✅ 直接可用 |
| `<PieChart donut data={…} />` | **直接可用**（v1.3 补上） | ✅ 直接可用 |
| `const theme = useHostTheme();`（取了不用） | 允许 | ✅ 直接可用 |

**综合（落地后）**：这份源码现在**只差一行 import**（`cursor/canvas` → `dsh/canvas`），`canvas_check` 给出的只剩 **1 个 warning（`W_NO_DATA`）**——因为它的数据还没收进 `export const DATA`。把数据搬进去就是 0 error 0 warning。改动前这里会崩两次，且 `canvas_check` 是 0 error；这就是 §5.2 那条改动的全部价值。

---

## 5 三条契约级差异（比组件差异更值得处理）

### 5.1 数据契约：`export const DATA` vs 模块级 const

| | Cursor 这份 | 本套件规范 |
|---|---|---|
| 数据位置 | 4 个模块级 `const`（`ITEMS` / `OPEN_ITEMS` / `GATES` / `BIG_FILES`）+ 1 个 `TONE` 映射 | 一个 `export const DATA = { … } as const`，**纯字面量** |
| Agent 读取 | 只能全文重读 | `canvas_read(path, "items", {status:"已修"})` 切片 |
| 人的改动 | 无处可落（无 id 行可寻址） | `useCanvasOverlay("items", DATA.items)` + sidecar |
| 接手成本 | 整份源码 | `brief: true` → 2.7%–10.6%（§6.4 实测） |
| 编译期检查 | — | `DATA` 非纯字面量 → `E_DATA_NOT_LITERAL`；缺 → `W_NO_DATA` |

同构的迁移写法（保持这份源码的结构，只是把它放进 `DATA`）：

```tsx
export const DATA = {
  asOf: "2026-10-02",
  goal: "把 OCCT → Rust 移植的自创实现收敛到可复核的忠实度",
  constraints: [{ rule: "…", because: "…", violation: "…" }],
  decisions: [{ id: "T-03", at: "…", chose: "夹具不合法", rejected: ["引擎缺口"], why: "…", ref: "…" }],
  nextAction: { taskId: "A18", action: "把平面面片三角化改走约束 Delaunay", why: "A13/A23 都被它阻塞" },
  items: [ { id: "A0", topic: "…", status: "已修", evidence: "…" } /* … */ ],
  openItems: [ /* … */ ],
  gates: [ /* … */ ],
  bigFiles: [ /* … */ ],
} as const;
```

注意 `as const` 的硬要求：**只读数组**。所以套件的所有数组 prop 都接受 `readonly T[]`——否则每个画布都要写 `as unknown as`。

### 5.2 导出面校验（**本侧缺口 → 已修**）

- kit 的导出面是**冻结契约**（INTERFACE §5），套件版本号还参与模块 URL 哈希；
- 但改动前 `host/compile.js` 只做三件与 import 相关的事：说明符白名单（`E_PARSE_IMPORT`）、`require` 白名单、`wrap()` 里的运行时 `__require` 兜底。**具名导入不与导出面对比**；
- 于是 `H3` / `PieChart` 这类拼错或缺失的名字，走的是"渲染期崩溃卡"这条最贵的反馈路径（`canvas_check` 看不见，Agent 得等用户报错）。

**已实现**（[DESIGN.md](../DESIGN.md) §32）：新增 `E_UNKNOWN_EXPORT`，在扫描器层比对具名导入与 `host/kitsurface.js` 的导出面，附带"是不是想用 X"的建议；`kitsurface.js` 与 `lib/client.js` 发布的 `kit` 由 `test/client.test.mjs` **双向**校验，一侧加组件而另一侧忘了会被测试拦住。

**实测（直接调用 `host/compile.js`，把这份源码按三个变体编译）：**

| 变体 | 编译结果 |
|---|---|
| 原样（`from "cursor/canvas"`） | `ok=false`；唯一诊断 `E_PARSE_IMPORT` line 1 |
| 只把说明符改成 `dsh/canvas`（**改动前**） | `ok=true`，**0 error**，1 warning `W_NO_DATA`——`H3`、`PieChart` 没有任何诊断，最终渲染期崩两次 |
| 只把说明符改成 `dsh/canvas`（**E_UNKNOWN_EXPORT 落地后、组件补齐前**） | `ok=false`，**1 error `E_UNKNOWN_EXPORT` line 1:31 → "dsh/canvas" does not export "PieChart"**，hint 给出"kit exports 24 components + 10 hooks"；另有 1 warning `W_NO_DATA` |
| 今天（v1.3：`H3` 与 `PieChart` 都已补） | `ok=true`，**0 error**，只剩 1 warning `W_NO_DATA`（数据还没进 `DATA`） |

校验本身现在由 `test/core.test.mjs` 用 `LineChart`（套件里确实没有的名字）锚定，所以"组件补齐"不会把这条规则测空。

### 5.3 图表族：`PieChart`（**缺口 → 已补，v1.3**）

`BarChart`（分组柱，40 category 上限）与 `HeatMatrix` 表达不了"占比"：`Stat` 只能给一个数，`BarChart` 要读者自己除。已补 `PieChart`（饼/环，手写 SVG），并按套件纪律加了两条约束：

- **颜色只来自语义 tone**：某片没给 `tone` 时在五档里**循环**取色，保证相邻片不同色——不引入自创色板；
- **上限不静默隐藏数据**：超过 `maxSlices`（默认 10）时尾部折成一片「其他」，并写明 `showing N of M slices — K folded into 其他`；
- `value <= 0` 的项直接丢弃（占比里没有 0 或负数），全零给 `No chart data` 空态。

它同时进了自检画布（`examples/selfcheck.canvas.tsx` 的「Kit surface share」区块），所以"套件全貌"这句话仍然成立。

---

## 6 另一个观察：这份画布是"只读报表"

整份源码 **没有一个 `Button`、没有 overlay、没有 `nextAction` / `constraints` / `decisions` 锚点**。按本插件的 skill（[SKILL.md](../skills/canvas/SKILL.md)、[intake.md](../skills/canvas/references/intake.md)），同一份审计会被要求至少再补三样：

1. **三个锚点**：红线（`constraints`，带"违反了会怎样"）、已定决策（`decisions`，含**被否决的方案**）、全局唯一的下一步（`nextAction`）——它的价值在"接手"，而不在"看现状"；
2. **人的动作入口**：标记 / 认领 / 豁免 走 `useCanvasOverlay`（Agent 下轮可见），"在会话里开始"走 `startTurn`；
3. **每条要有 `next` 与 `acceptance`**：现状是"主题 + 状态 + 证据"，缺"下一步"和"怎样算完成"，于是看板只能汇报、不能驱动。

这不是对这份源码的批评——它是**只读审计**，本来就不打算驱动动作。但它正好说明两套形态的分工：Cursor 的实例可以停在报表；本插件的规范要求产物**可回灌**。

---

## 7 建议清单（按性价比）

| 优先级 | 动作 | 状态 |
|---|---|---|
| **P0** | 编译期导出面校验 → `E_UNKNOWN_EXPORT` | ✅ 已落地（`host/kitsurface.js` + `host/scan.js` + `host/diagnostics.js`，`core.test.mjs` +5、`client.test.mjs` +1 双向校验） |
| **P1** | `Text` 支持 `as="span"`、补 `H3`、补齐文字 tone 四档（含顺带修掉 `tone="primary"` 的静默降级） | ✅ 已落地（`KIT_VERSION` `k2 → k3`） |
| **P1** | 文档同步：kit.md 的 import 块（此前还缺 `HeatMatrix`）、排版表、troubleshooting 的逐码修法 | ✅ 已落地 |
| **P2** | 补 `PieChart`（含 `donut`） | ✅ 已落地（v1.3，`KIT_VERSION` `k3 → k4`；`client.test.mjs` +1 行为断言） |
| **P2** | 一份"Cursor 画布 → `dsh/canvas`"迁移三步文档（改说明符 → 数据收进 `DATA` → 替换缺件） | ✅ 已落地：[cursor-canvas-migration.md](cursor-canvas-migration.md)（含 before/after fixture，由 `test/templates.test.mjs` 断言：before 只报 `E_PARSE_IMPORT`，after 零诊断） |

---

## 附：本套件全量导出面（k4）

**组件（25）**：`Stack` `Row` `Grid` `Divider` `CollapsibleSection` `H1` `H2` `H3` `Text` `Code` `Card` `CardHeader` `CardBody` `Callout` `Stat` `Table` `BarChart` `PieChart` `HeatMatrix` `TodoList` `Progress` `KeyValue` `Timeline` `Button` `Pill`

**钩子（10）**：`useState` `useEffect` `useMemo` `useCallback` `useRef` `useCanvasState` `useCanvasOverlay` `useCanvasAction` `useHostTheme` `useCanvasResource`

**另注入全局**：`h`、`Fragment`、`React`、`CanvasContext`、`runtime`、`version: "1"`（画布模块只允许引用这些）。

编译期以此为准的文件是 `host/kitsurface.js`；导入任何不在此列的名字会得到 `E_UNKNOWN_EXPORT` 而不是渲染期崩溃。
