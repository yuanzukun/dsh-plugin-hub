# 从 Cursor Canvas 迁到 `dsh/canvas`

> **这份指南不会过期**：它引用的 before/after 两个文件就在 [docs/migration/](migration/) 里，`test/templates.test.mjs` 每次跑测试都会编译它们并断言——
> before 只能因为**模块说明符**一条原因失败（`E_PARSE_IMPORT`），after 必须**零诊断**通过且 `DATA` 的键齐备。指南与可编译的例子因此被绑在一起。
>
> 适用范围：把一份为 `cursor/canvas` 写的画布搬到本插件的 `dsh/canvas`（`KIT_VERSION = "k4"`，25 组件 + 10 钩子）。差异清单与实测输出见 [canvas-kit-comparison.md](canvas-kit-comparison.md)。

---

## 0 先看清三条硬约束

| # | 约束 | 违反时的诊断 |
|---|---|---|
| 1 | 只能 `import … from "dsh/canvas"`（**且必须是套件真的导出的名字**） | `E_PARSE_IMPORT` / `E_UNKNOWN_EXPORT` |
| 2 | 必须有 `export default` 的无参组件 | `E_NO_DEFAULT` |
| 3 | 数据放 `export const DATA = { … } as const`，且必须是**纯字面量** | `W_NO_DATA`（缺）/ `E_DATA_NOT_LITERAL`（不纯） |

第 1 条里的"导出面校验"是 v1.2 新增的：拼错的名字或兄弟套件里的名字**在编译期**就被拒绝，并附带最接近的候选名。第 3 条不是风格要求——宿主靠它把数据抽出来给 Agent 读切片（`canvas_read`），也靠它给"人的改动"提供可寻址的行（overlay）。

---

## 1 第一步：换说明符，按对照表改名

**改动量通常就是一行 import。** 十六个符号的逐项对照（`cursor/canvas` → `dsh/canvas`）：

| Cursor | `dsh/canvas` | 备注 |
|---|---|---|
| `Callout` / `Card` / `CardHeader` / `CardBody` | 同名同形 | `Callout` 的 `tone` 默认 `info`，另有 `title` |
| `Grid` | 同名同形 | `columns={5}` 与 `columns="1fr 1fr"` 都等价 |
| `H1` / `H2` / `H3` | 同名同形 | `H3` 于 v1.2 补齐（刻度 14/22 · 500） |
| `PieChart` | 同名（`donut` 支持） | v1.3 补齐；`data: {label, value, tone?}[]`，另有 `unit` / `maxSlices` / `showLegend` |
| `Pill` | 同名同形 | 不给 `tone` = 中性色；`active` / `onClick` 可选 |
| `Row` / `Stack` | 同名同形 | `Row` 的 `align` 默认 `center` |
| `Stat` | 同名，多一个 `hint` | `tone` 语义相同 |
| `Table` | 同名同形 | `headers` / `rows` / `columnAlign` / `rowTone` / `striped` / `stickyHeader` / `emptyText`；**`maxRows` 默认 300** |
| `Text` | 同名，多两个 prop | `as="span"`（行内强调）与 tone 别名 `primary/secondary/tertiary/quaternary/caption` |
| `useHostTheme` | 同名同形 | 返回 `{dark, tone(), text, space()}` |
| `useCanvasState`（本地 UI 态） | 同名 | 键空间是 `dsh.canvas.<画布绝对路径>.<key>`；**Agent 看不到** |
| `useCanvasAction`（`newComposerChat` …） | `useCanvasAction` | 动作表不同，见 §4 |

**本套件多出来、迁移时可以按需加进来的**：`Divider`、`CollapsibleSection`（控制体积的主力）、`Code`、`BarChart`、`HeatMatrix`、`TodoList`、`Progress`、`KeyValue`、`Timeline`、`Button`，以及 `useCanvasOverlay`（人机共享态）、`useCanvasResource`（读工作区文本）。

> 换成 `dsh/canvas` 之后，**如果还想让旧页面继续可用**，注意宿主侧只认 `*.canvas.tsx` 与 `dsh/canvas`；这里没有"两个套件并存"的兼容层。

---

## 2 第二步：把模块级数据收进 `export const DATA`

这是迁移里**唯一需要动结构**的一步。Cursor 那份画布把数据放在模块级 `const ITEMS / OPEN_ITEMS / GATES / BIG_FILES`，本套件要求它们进同一个 `DATA`：

```diff
-const ITEMS: AuditItem[] = [ … ];
-const OPEN_ITEMS = [ … ];
-const GATES = [ … ];
-const BIG_FILES = [ … ];
+export const DATA = {
+  goal: "把 OCCT → Rust 移植的自创实现收敛到可复核的忠实度",
+  asOf: "2026-10-02", revision: "r7", staleDays: 7,
+  constraints: [ { rule, because, violation } … ],   // 红线
+  decisions:   [ { id, at, chose, rejected, why, ref } … ],
+  nextAction:  { taskId: "A18", action: "…", why: "…" },
+  items: [ … ], openItems: [ … ], gates: [ … ], bigFiles: [ … ], surface: [ … ],
+} as const;
```

三条纪律（`intake.md` 与 `patterns.md` 里有完整版）：

1. **纯字面量**：不能有函数调用、模板拼接、非字面量 spread、`Date.now()`。想"预先算好再塞进 `DATA`"就会得到 `E_DATA_NOT_LITERAL`——**计算属于渲染期**。
2. **只收数据，不收映射与辅助函数**：像 `const TONE: Record<Disposition, Tone> = {…}` 与 `const statusPill = (s) => …` 这类是**代码**，留在 `DATA` 外面（before/after 两个文件就是这么分的）。
3. **`as const` 的代价是只读**：它产出的数组是 `readonly`，所以套件所有数组 prop 都接受 `readonly T[]`；但把 `DATA.items` 交给需要可变数组的第三方 API 时，要写一次 `as unknown as T[]`（after 文件里 `rows` 那一行就是）。

**顺带要补的东西**：即使只做"只读报表"，也建议先把 `goal` / `asOf` / `revision` 三个字段写上——`brief` 恢复摘要靠它们回答"要去哪、多久没动"。

---

## 3 第三步：补人机闭环（这一步才让画布变成"活"的）

只读报表迁移完就能渲染，但 `SKILL.md` 的规范会要求再加三样：

**(a) 人的判断走 `useCanvasOverlay`，不走本地状态。** 判断的标准是一句话：**这个改动会不会影响 Agent 下一轮该做什么？** 会 → overlay（落 sidecar，`canvas_read` 读得到）；不会（筛选器、当前选中项）→ `useCanvasState`。

```tsx
const items = useCanvasOverlay("items", DATA.items);   // 键名 = DATA 里的数组字段名
const rows = items.items as unknown as AuditItem[];    // 合并后的行：DATA + 人的补丁
…
<Button size="sm" onClick={() => items.set("A18", { status: "部分" })}>标记进行中</Button>
```

**(b) 把任务交回 Agent 用 `startTurn`；打开文件用 `openFile`。**

```tsx
const dispatch = useCanvasAction();
<Button size="sm" onClick={() => dispatch({ type: "startTurn", prompt: "处理 T-101：…只改这一处。" })}>在会话里开始</Button>
<Button size="sm" variant="ghost" onClick={() => dispatch({ type: "openFile", path: "occt-topo/src/shhealing/wire_fix.rs", line: 1100 })}>打开文件</Button>
```

**(c) 三个上下文锚点**：`constraints`（红线，带"违反了会怎样"）、`decisions`（已定，**含被否决的方案**）、`nextAction`（全局唯一的下一步）。跟踪字段回答"现在在哪"，锚点回答"**能不能接手**"——会话被截断后，接手的人读的就是这三块。

---

## 4 动作表对照

| Cursor（设计文档记录） | `dsh/canvas` | 语义差别 |
|---|---|---|
| `{type:"newComposerChat", userPrompt:[…]}` | `{type:"startTurn", prompt, newSession?}` | 默认**追加到当前会话**；同画布同 prompt 在 30 s 内只接受一次（限流去重） |
| — | `{type:"runCommand", id?, command?, title?, cwd?}` | **默认全拒**：命令串只能从 Config 的 `commandWhitelist` 逐字选中，经 `ctx.shell` 执行并按调用 Session 的沙箱策略约束 |
| 打开文件（客户端） | `{type:"openFile", path, line?}` / `{type:"openResource", address, params?}` | 客户端本地处理，不走网络 |
| 剪贴板 | `{type:"copy", text}` | 本地 |
| — | `{type:"notify", tone, message}` | 前端提示条 |
| — | `{type:"overlaySet"/"overlayClear", key, id, patch?}` | 写 sidecar |

失败**不抛异常**，返回 `{ok:false, code, message}`，所以按钮可以渲染"被拒绝"的状态而不是崩掉。

---

## 5 会"编译通过但行为不同"的清单

迁移里最危险的几处是**静默**的（没有诊断，只是结果不一样）：

| 写法 | 会发生什么 | 怎么办 |
|---|---|---|
| `<Text>` 里嵌 `<Text weight="semibold">` 想做行内强调 | 内层是**块级** div，整句被拆行 | 内层写 `as="span"` |
| `tone="quaternary"` | 与 `caption` 同档（最弱的一档） | 知道即可；想要四档之外的颜色要改套件 |
| `Table` 全量渲染几百行 | 超过 `maxRows`（默认 300）只渲染前 300 并显示 `showing N of M` | 加筛选器（`Pill`），或拆画布 |
| `BarChart` 很多 category | 只渲染前 40 并提示 | 同上 |
| `PieChart` 很多片 | 超过 `maxSlices`（默认 10）把尾部折成一片「其他」并注明 | 同上 |
| 顶层 `console.log` / `fetch` / `setTimeout` | **不静默**：`E_SIDE_EFFECT` / `E_EXTERNAL` 直接拒绝编译 | 数据写进 `DATA`，动作走 `useCanvasAction` |
| 远程图片 / `http(s)://` 字面量 | `<img src=…>` 报 `E_EXTERNAL`，URL 报 `W_REMOTE_URL` | 内联 SVG 或把数据内联 |

**关于 `canvas_check` 的边界**：它只编译不渲染，所以"作用域重复声明""TDZ""渲染期截断"它都看不见。**改完一定要打开看一眼**（或在 CI 里跑一遍真实渲染，本仓用 `docs/preview/render.mjs` 做这件事）。

---

## 6 迁移后的验证清单

1. `canvas_check(path)` → 期望 **0 error**；只剩 `W_NO_DATA` 说明数据还没进 `DATA`；
2. 打开画布 tab → 渲染正确、明暗主题都看一次；
3. 点一次面板上的按钮（标记/开始）→ 关掉页面重开，标记还在，且 `canvas_read(path, "items", {status:"部分"})` 能读到；
4. 会话被截断后 `canvas_read(path, brief:true)` → 应该能用 1–3 KB 回答"要去哪 / 什么不能碰 / 什么已经定了 / 现在做什么"。

---

## 7 迁移之后仍然不成立的事

- **没有折线图**：图表只有 `BarChart`（分组柱）、`PieChart`（饼/环）、`HeatMatrix`（二维强度）。趋势类需求请用 `Table` + 分组，或提需求改套件。
- **不能 import 第三方库，画布之间也不能互相 import**；需要复用就复制那几行，或把逻辑提成 Agent 侧的工具。
- **不能拉远程数据**：所有数据必须内联在 `DATA` 里（这也正是它可被切片读取的前提）。
- **画布代码的信任级别 = 插件代码**：它跑在宿主页面里，没有 iframe/Worker 隔离（不注入 `fetch`/`localStorage`/`document`，但这不等于沙箱）。

---

## 附：复跑那条断言

```bash
node --test test/templates.test.mjs
# ok   docs/migration pair: before fails on E_PARSE_IMPORT, after compiles clean (DATA keys = 12)
```

两个 fixture：

| 文件 | 说明 |
|---|---|
| [docs/migration/cursor-style.before.txt](migration/cursor-style.before.txt) | 迁移前：`from "cursor/canvas"`、模块级 const 数据、`TONE` 映射、`statusPill` 辅助函数 |
| [docs/migration/dsh-canvas.after.txt](migration/dsh-canvas.after.txt) | 迁移后：`dsh/canvas`、`export const DATA`、overlay 按钮 + `startTurn` + 三个锚点 |

两者都不是活画布（因此用 `.txt` 扩展名）——仓库里的 `*.canvas.tsx` 会被工作区发现机制列进画布目录，指南的示例不该出现在那里。
