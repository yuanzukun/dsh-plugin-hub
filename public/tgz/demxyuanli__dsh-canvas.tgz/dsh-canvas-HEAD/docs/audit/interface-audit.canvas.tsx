/** @canvas
 * title: 实现 vs 冻结契约：审计
 * description: 以 INTERFACE.md 与规范文档为参照物核对本插件实现；每条断言带判据分级、对照物与测量口径
 * icon: board
 */
import {
  Button,
  Callout,
  Card,
  CardBody,
  CardHeader,
  Code,
  Grid,
  H1,
  H2,
  H3,
  KeyValue,
  PieChart,
  Pill,
  Row,
  Stack,
  Stat,
  Table,
  Text,
  useCanvasAction,
  useCanvasOverlay,
} from "dsh/canvas";

type AuditStatus = "已核对" | "部分" | "未修";
type Tone = "success" | "warning" | "danger" | "neutral" | "info";

export const DATA = {
  // ---- 第 0 步三件：参照物与口径 / 产物类型 / 本轮预算 --------------------
  reference: {
    // 四取值，决定这张画布**能查出哪一类问题**：
    //   文档   = 契约 / 规范文档    → 能查「说 vs 做」
    //   实现   = 参照实现（源码）    → 能查「做 vs 做」
    //   产物   = 参照产物（模型/导出）→ 能查「做 vs 对」
    //   自基线 = 无外部参照物        → 只能查「今天 vs 昨天」，禁止写"逐项相同"
    kind: "文档",
    what: "INTERFACE.md（冻结契约）· DESIGN.md（决策与裁决）· README.md（对外承诺）· skills/canvas/references/kit.md（套件参考）",
    scope:
      "契约 = 实现必须逐项匹配的对外承诺；裁决 = DESIGN §21+ 已定的归属；漂移 = 文档落后于既成事实。判据以「消费点计数」与「键构造」这类可复算量为准。",
    at: "2026-10-07",
    detects: "承诺与实现是否一致（说 vs 做）——本轮 5 条未修/部分里 4 条是这一类",
    cannotDetect: "行为偏差（几何读数、逐项对拍）：需要实现型或产物型参照物；本审计对 C-09 只能退到 L2 自基线",
  },
  product: "audit",
  budget: "1 路 + 可对拍参照物（契约文档在仓内）⇒ 本轮收口 11 条断言，未复跑项显式标注",
  // 画布自己声明行键与状态词表：摘要据此直接看见在办行，调用方不必传参
  rowsKey: "claims",
  openStatuses: ["未修", "部分"],

  asOf: "2026-10-07",
  revision: "a1",

  // ---- 唯一下一步 ---------------------------------------------------------
  nextAction: {
    claimId: "C-05",
    action:
      "把 compileTimeoutMs 二选一了结：要么在 host/compile.js 的 transform 外包 race 并产出超时诊断，要么从 Config / cordis.patch.yml / /canvas/api / README 四处一起删掉",
    why: "C-10 / C-11 两条机制缺陷已在本轮修掉；剩下唯一「对外承诺了不存在的保护」的条目就是它，其余五条都只是文档落后，不会骗人",
  },

  // ---- 审计自身的红线 -----------------------------------------------------
  constraints: [
    {
      rule: "对照物必须可核对：给到参照物的 文件:行",
      because: "不可核对的对照物等于空话，而假出处比不写更糟",
      violation: "整条断言作废（本仓有过「假出处 7 处」的前科）",
    },
    {
      rule: "判据必须分级且不许留空",
      because: "L1 = 与外部参照逐项对拍；L2 = 与自身基线对拍并给 Δ；留空会被读成「刚测过」",
      violation: "接手的人无法判断结论是否仍然成立",
    },
  ],

  // ---- 本次审计的口径裁决（含被否决的方案）--------------------------------
  decisions: [
    {
      id: "D-a1",
      at: "2026-10-07",
      chose: "参照物取仓内的契约与规范文档，不取「与 Cursor Canvas 的行为一致」",
      rejected: ["以 Cursor Canvas 为参照物", "以「测试是否通过」为参照物"],
      why: "契约文档在仓内、可 grep、可 diff；Cursor 那边只能拿到源码片段，无法逐项对拍",
      ref: "INTERFACE.md §5 · docs/canvas-kit-comparison.md",
    },
    {
      id: "D-a2",
      at: "2026-10-07",
      chose: "审计产物与进度产物分开；本画布只作 audit，进度留在 board.canvas.tsx",
      rejected: ["一张画布同时装进度与断言"],
      why: "字段集互斥：progress/owner 在审计里是噪声，criterion/counterpart 在进度看板里没有位置",
      ref: "skills/canvas/references/patterns.md 第 5 类",
    },
  ],

  // ---- 断言 ---------------------------------------------------------------
  claims: [
    {
      id: "C-01",
      claim: "插件注册的路由不在宿主 cookie 边界内，所以入口自己守：非 JSON 的 POST 一律 403",
      status: "已核对",
      criterion: { level: "L1", metric: "非 JSON 请求的状态码", ref: "INTERFACE.md §3.1", delta: "要求 403 → 实测 403（含伪造 Origin）" },
      counterpart: {
        port: "index.js createHandler 入口门",
        occt: "INTERFACE.md §3.1",
        doneWhen: "text/plain 与 x-www-form-urlencoded 都 403，application/json 正常",
      },
      measured: { round: "本轮", at: "2026-10-07", mode: "node --test test/serve.test.mjs" },
      note: "承重条：宿主外壳的 401 只守连接，插件自己的特权面（startTurn / runCommand）必须自守。这条一破，画布动作桥就是跨站可触发的。",
    },
    {
      id: "C-02",
      claim: "套件导出面在编译期被校验，且校验用的名单与浏览器半边实际发布的名字双向锚定",
      status: "已核对",
      criterion: { level: "L1", metric: "两侧名单差异", ref: "INTERFACE.md §5", delta: "0（25 组件 + 10 钩子）" },
      counterpart: {
        port: "host/kitsurface.js ↔ lib/client.js kit",
        occt: "INTERFACE.md §5 的导出面清单",
        doneWhen: "只在一侧加组件时 test/client.test.mjs 失败",
      },
      measured: { round: "本轮", at: "2026-10-07", mode: "node --test test/client.test.mjs" },
      note: "这条机制本身是 v1.2 从一次真实对读里补出来的（见勘误 E-04）：在那之前，缺失的具名导入编译期 0 诊断，直到渲染期才崩成错误卡。",
    },
    {
      id: "C-03",
      claim: "被 /canvas/api 发布的 limits 真的被客户端消费，不是装饰性配置",
      status: "已核对",
      criterion: { level: "L1", metric: "消费点计数", ref: "INTERFACE.md §3（/canvas/api）", delta: "maxRenderRows 1 处消费" },
      counterpart: {
        port: "lib/client.js Table hardCap = runtime.limits.maxRenderRows",
        occt: "README.md 配置项表（maxRenderRows 默认 5000）",
        doneWhen: "改 Config 后渲染上限跟着变",
      },
      measured: { round: "本轮", at: "2026-10-07", mode: "读码 + 渲染路径" },
      note: "它是「正例」，用来证明口径被应用过：同批发布的 compileTimeoutMs 就没有消费点（C-05）。「发布了配置」与「配置生效」必须逐条核对，不能整批信任。",
    },
    {
      id: "C-04",
      claim: "契约要求套件破坏性变更时由 client 渲染期报 W_DEPRECATED，实现里没有产出点",
      status: "部分",
      criterion: { level: "L1", metric: "产出点计数", ref: "INTERFACE.md:111", delta: "要求 1 → 实测 0" },
      counterpart: {
        port: "lib/client.js（无产出点）· host/diagnostics.js:13（仅注释列为 reserved）",
        occt: "INTERFACE.md:111「改签名或删导出必须升级 version，并在 client 渲染期报 W_DEPRECATED」",
        doneWhen: "套件发生破坏性变更时，client 渲染期真的发出该信号",
      },
      measured: { round: "本轮", at: "2026-10-07", mode: "grep W_DEPRECATED（命中 2 处，均在文档与注释）" },
      note: "属于「约定未落地」而非当前故障：尚未发生破坏性变更，所以不可触发。风险在于它是契约里一条没有机制的承诺——真到那天才发现，代价最大。",
    },
    {
      id: "C-05",
      claim: "README 对外承诺 compileTimeoutMs「超出拒绝编译」，实现里没有任何计时器或竞态围着 transform",
      status: "未修",
      criterion: { level: "L1", metric: "消费点计数", ref: "README.md:115", delta: "承诺 1 → 实测 0" },
      counterpart: {
        port: "host/compile.js:94 transform 调用点（无计时器包裹）· index.js:36 只把它读进 limits",
        occt: "README.md:115「单文件编译超时，超出拒绝编译」+ cordis.patch.yml:10 + /canvas/api limits",
        doneWhen: "要么实现超时并在超时时产出诊断，要么把它从 Config / patch / api / README 四处一起删掉",
      },
      measured: { round: "本轮", at: "2026-10-07", mode: "grep compileTimeoutMs：8 处引用（含论文），消费点 0" },
      note: "为什么一直没被发现：最大画布冷编译中位数 4.13 ms（N=200），距 2000 ms 三个数量级——它永远不会触发。缺口不是「慢」，是「承诺了不存在的保护」。",
    },
    {
      id: "C-06",
      claim: "kit.md 说 useCanvasState 的键空间用「画布绝对路径的短哈希」，实现用的是完整路径",
      status: "未修",
      criterion: { level: "L1", metric: "键构造", ref: "kit.md:518", delta: "短哈希 → 完整路径" },
      counterpart: {
        port: "lib/client.js:886 storageKey = \"dsh.canvas.\" + (canvasPath ?? \"global\") + \".\" + key",
        occt: "kit.md:518「键空间 dsh.canvas.<canvasId>.<key>（canvasId 是画布绝对路径的短哈希）」",
        doneWhen: "文档与实现二选一对齐，并写明未绑定画布时的 global 取值",
      },
      measured: { round: "本轮", at: "2026-10-07", mode: "读码" },
      note: "后果不是功能故障，是三件小事叠起来：(a) 键变长、(b) 把用户目录结构写进 localStorage 键、(c) 未绑定画布时所有画布共用 global 前缀，与「跨会话共享筛选器」的意图有冲突。",
    },
    {
      id: "C-07",
      claim: "kit.md 说 Divider「无 props」，代码已实现 orientation",
      status: "未修",
      criterion: { level: "L1", metric: "props 面", ref: "kit.md:135", delta: "0 → 1" },
      counterpart: {
        port: "lib/client.js:159-165 Divider orientation === \"vertical\"",
        occt: "kit.md:135「1px 分隔线，无 props。」（DESIGN §21 A4 已裁决「代码已实现」）",
        doneWhen: "kit.md 补上 orientation 并标注默认 horizontal",
      },
      measured: { round: "本轮", at: "2026-10-07", mode: "读码" },
      note: "最典型的一类漂移：连裁决（DESIGN §21 A4）都写了，参考文档没跟上。它不会让任何人失败，只会让照文档写的人少用一个已有能力。",
    },
    {
      id: "C-08",
      claim: "index.js 头部注释与 JSDoc 说三个模型工具，实际注册四个",
      status: "未修",
      criterion: { level: "L1", metric: "工具条数", ref: "index.js:6 / index.js:735", delta: "3 → 4" },
      counterpart: {
        port: "index.js:6 头部注释 · index.js:735 JSDoc",
        occt: "toolDefinitions 实际返回 4 条（canvas_check / new / read / state_merge，test/tools.test.mjs 断言 4）",
        doneWhen: "注释与 JSDoc 改成四条，或删掉计数以免再漂",
      },
      measured: { round: "本轮", at: "2026-10-07", mode: "grep + 测试断言" },
      note: "零功能影响，但读注释的 Agent 会少用一个工具——而漏掉的恰好是 canvas_state_merge，四条里唯一会写回源文件的那个。",
    },
    {
      id: "C-09",
      claim: "canvas_read 只有 filter / ids / limit 三层，没有字段投影：limit 只截数组长度",
      status: "未修",
      criterion: { level: "L2", metric: "单行切片占源文件比例", ref: "自基线 board.canvas.tsx（36 476 字符）", delta: "29.3% → 目标 <10%" },
      counterpart: {
        port: "index.js canvas_read 的三层切片",
        occt: "无外部参照物——参照实现没有对应 API，判据只能自比",
        doneWhen: "加 fields 参数后，取 1 行 3 个字段 < 2 KB",
      },
      measured: { round: "本轮", at: "2026-10-07", mode: "N=200 measure.mjs：filter 到 1 行仍返回 10 676 字符" },
      note: "这条是本审计里唯一 reference.kind 需要分叉的样本：没有外部对照物 ⇒ 判据降级 L2（自基线 + 目标 Δ），且不得写「与 X 一致」这类措辞。29.3% 出自本仓 docs/paper/measure.mjs，可复算。",
    },
    {
      id: "C-10",
      claim: "canvas_read 的 dataPath / ids 只裁目标那一支，返回体仍是整个 DATA 信封",
      status: "已核对",
      criterion: {
        level: "L1",
        metric: "1 行切片返回体",
        ref: "README.md:8",
        delta: "10 676 → 1 036 字符（该行自身 831，即 80% 已是内容）",
      },
      counterpart: {
        port: "index.js canvas_read：dataPath 分支现在只回 { [key]: rows, __counts, __overlays }",
        occt: "README.md:8「对 agent 省 context：canvas_read 只取切片（dataPath / filter / ids / limit）」+ skills/canvas/SKILL.md 的读纪律",
        doneWhen: "返回体只含被切片的那一支（+ __counts）；不存在的键报错并列出真实顶层键",
      },
      measured: { round: "二轮（修复后）", at: "2026-10-07", mode: "本仓探针：board ids=[R-04] 10 676 → 1 036；dataPath 给不存在的键现在报 `DATA has no key … (top-level keys: …)` 而不再静默回整包" },
      note: "修前三件套：目标支被替换、其余键照旧随行（82.4%）、未知键静默回整包。修后 1 036 字符里 831 是那一行本身（80%），信封开销降到 205。附带修正：先前论文 §6.4 把它归因于行宽，实测主因是信封——勘误 E-05。",
    },
    {
      id: "C-11",
      claim: "briefDigest 把行键硬编码为 tasks、把锚点字段硬编码为 taskId，于是 audit 型画布对恢复摘要完全不可见",
      status: "已核对",
      criterion: {
        level: "L1",
        metric: "audit 画布被 digest 看见的在办行数",
        ref: "工具描述「the rows still in flight」+ resume.md 四步读法",
        delta: "focus 0 → 8（显式 rowsKey=claims / openStatuses=[未修,部分] 时）",
      },
      counterpart: {
        port: "host/brief.js resolveRows()：显式 rowsKey > tasks[] > 自动探测（要求每行有 string id + status）；锚点接受 taskId/claimId/rowId；行键缺失与词表不识均产出 note",
        occt: "工具描述 + skills/canvas/references/resume.md 的四步读法",
        doneWhen: "显式传参后重点行进 focus、notes 归零；不传参时自动探测并明确说明，而不是静默 0 行",
      },
      measured: { round: "二轮（修复后）", at: "2026-10-07", mode: "同一探针：brief 现在报 rowsKey=claims、counts={tasks:11,focus:0,closed:11}、claimId 保留，并给 3 条 note（自动探测 / 词表不识 / 锚点落在非在办行）；显式传 rowsKey+openStatuses 后 focus=8、notes=0" },
      note: "这是「范式落地」的硬缺口而非笔误：摘要机制按 tracker 形状写死，恰好在最需要它的场景（接手一份审计）失效，而且是静默失效。修复保留了向后兼容（tasks 仍在时优先）并把不确定性变成可见的 note。",
    },
    {
      id: "C-12",
      claim: "画布可以在 DATA 里自声明行键与状态词表，接手路径因此不必由调用方猜参数",
      status: "已核对",
      criterion: {
        level: "L1",
        metric: "无参 brief 看见的在办行 / notes 数",
        ref: "工具描述「the rows still in flight」",
        delta: "本画布：focus 0 → 8、notes 3 → 0（`rowsKey: claims` + `openStatuses: [未修, 部分]` 写在 DATA 里）",
      },
      counterpart: {
        port: "host/brief.js resolveRows()：显式参数 > DATA 声明 > tasks[] > 自动探测；digest 回显 rowsKey / openStatuses / openStatusesSource",
        occt: "本套件约定（无外部参照物）",
        doneWhen: "自声明的画布无参 brief 即得正确 focus，且不产生任何 note",
      },
      measured: { round: "三轮（本轮）", at: "2026-10-07", mode: "本仓探针：audit 模板无参 brief → rowsKey=claims / openStatusesSource=data / focus=1 / notes=0" },
      note: "S-04 就是这一条的前身（原先必须由调用方传 openStatuses）。修法遵循同一条原则：声明不是猜测——声明进字段、猜测才发 note，并且摘要回显 openStatusesSource（caller / data / default）让人一眼看出词表是谁定的。",
    },
  ],
  stillUnported: [
    {
      id: "S-01",
      what: "套件破坏性变更时的 W_DEPRECATED 渲染期信号仍是欠账（C-04）",
      portRef: "lib/client.js（无）",
      occtRef: "INTERFACE.md:111",
    },
    {
      id: "S-02",
      what: "旧 ESM 模块不可回收：浏览器不能卸载已 import 的模块，长期会话里旧版本会累积",
      portRef: "lib/client.js useCanvasView 的 key={sha} 重挂载（只换组件，不卸模块）",
      occtRef: "无外部参照物（本套件独有约束）",
    },
    {
      id: "S-03",
      what: "canvas_check 不能静态估算渲染行数，所以 W_MANY_ROWS 永远只能出现在渲染期",
      portRef: "host/compile.js 无行数估算 · lib/client.js Table 截断文案",
      occtRef: "skills/canvas/references/troubleshooting.md（W_MANY_ROWS 归属）",
    },
  ],

  // ---- 禁令（三元组 + 复核条件）------------------------------------------
  prohibitions: [
    {
      pattern: "用 canvas_check 的 0 error 断言「行数上限没问题」",
      temptingBecause: "canvas_check 是唯一随手可跑的自检，而且它确实一路绿灯",
      observableSymptom: "面板上出现 showing N of M，而 canvas_check 报 0 error —— 你验证的是一个看不见这件事的工具",
      reviewWhen: "canvas_check 获得静态行数估算后重评",
    },
    {
      pattern: "把门禁 / 测试数字手抄进 DATA 当证据",
      temptingBecause: "写进去之后板面看起来最有说服力",
      observableSymptom: "读数与最近一次真实运行不一致（本仓 README 曾长期写着 8 文件 / 94 断言，实测 9 / 437）",
      reviewWhen: "runCommand 的结果能自动写回 DATA 之后重评",
    },
    {
      pattern: "把「会影响 Agent 下一轮判断」的状态放进 useCanvasState",
      temptingBecause: "一个钩子就够，不需要服务端往返",
      observableSymptom: "人点了「完成」，canvas_read 读不到，下一轮 Agent 按旧状态继续干",
      reviewWhen: "无（设计红线，不设复核）",
    },
    {
      pattern: "给画布加第三方图表库，或用 iframe / Worker 做隔离",
      temptingBecause: "现成图表库比手写 SVG 快，隔离看起来更安全",
      observableSymptom: "import 第三方 → E_PARSE_IMPORT；iframe → E_EXTERNAL；且 iframe 拿不到主题 token 与 locale",
      reviewWhen: "无（套件纪律，不设复核）",
    },
  ],

  // ---- 勘误（判断级；行号漂移不进本表）-----------------------------------
  corrections: [
    {
      id: "E-01",
      was: "kit.md 的规范 import 块里没有 HeatMatrix",
      now: "已补，并同时补上 H3 与 PieChart",
      why: "同一份导出面写了两处清单，只更新了一处",
      at: "2026-10-07",
      round: "本轮",
    },
    {
      id: "E-02",
      was: "README 声称 npm test 是 8 个文件 / 94 断言",
      now: "9 个文件 / 437 处断言",
      why: "断言数随开发增长，README 里的那个数字没人重测",
      at: "2026-10-07",
      round: "本轮",
    },
    {
      id: "E-03",
      was: "诊断码写成 15 条（8 error + 4 warning + 4 reserved）",
      now: "16 条（10 error + 3 产出型 warning + 3 reserved）",
      why: "分项自相加不等于总数，写下时没有加一遍",
      at: "2026-10-07",
      round: "本轮",
    },
    {
      id: "E-04",
      was: "套件导出面只有 lib/client.js 一处清单，编译期无法校验具名导入",
      now: "host/kitsurface.js 与 lib/client.js 双向锚定，缺失名字报 E_UNKNOWN_EXPORT",
      why: "单侧清单无法在编译期回答「这个名字存在吗」",
      at: "2026-10-07",
      round: "本轮",
    },
    {
      id: "E-05",
      was: "论文 §6.4 把「1 行切片仍占 29.3%」归因于行宽（每行 20 个字段、evidence 是长散文）",
      now: "主因是信封里其它键照旧随行：该行 831 字符（7.8%）、兄弟键 8 794（82.4%）",
      why: "当时只看了「返回体总长」与「源文件长度」，没有把返回体拆开量——把相关性当成了因果",
      at: "2026-10-07",
      round: "本轮",
    },
  ],

  // ---- 复核轮与门禁读数（含冷/热与未复跑）--------------------------------
  rounds: [
    {
      id: "一审",
      at: "2026-10-07",
      what: "以契约与规范文档为参照物核对实现：grep + 读码 + 跑测试",
      gates: [
        { id: "npm test", reading: "9 文件 / 437 处断言全绿", mode: "热跑" },
        { id: "9 张画布 canvas_check", reading: "9 / 9 零诊断", mode: "measure.mjs" },
        { id: "冷编译（最大画布）", reading: "中位数 4.13 ms（N=200）", mode: "本机热缓存" },
        { id: "本审计画布 canvas_check", reading: "0 error / 0 warning（518 行 / 25 259 字节）", mode: "compileCanvas" },
        { id: "canvas_read 切片分解", reading: "1 行 10 676 字符 = 该行 831 + 兄弟键 8 794 + 其余 1 051", mode: "本仓探针" },
        { id: "brief 对 audit 的可见性", reading: "focus 0 行 / 9 断言，无 note 告警", mode: "本仓探针" },
      ],
    },
    {
      id: "二轮（修复 C-10 / C-11 后）",
      at: "2026-10-07",
      what: "按一审的结论修机制：canvas_read 的 dataPath 只回目标支；briefDigest 接受 rowsKey/openStatuses 并对不确定性发声",
      gates: [
        { id: "npm test", reading: "9 文件全绿（brief/tools 各 +3 / +2 条断言）", mode: "热跑" },
        { id: "C-10 验收", reading: "board ids=[R-04]：10 676 → 1 036 字符", mode: "本仓探针" },
        { id: "C-11 验收", reading: "audit brief：focus 0 → 8（显式传参）· notes 3 → 0", mode: "本仓探针" },
        { id: "未知 dataPath", reading: "报错并列出真实顶层键（不再静默回整包）", mode: "tools.test.mjs" },
      ],
    },
    {
      id: "未复跑",
      at: "—",
      what: "真实 GUI 里的目视验收（本会话无浏览器控制能力）",
      gates: [{ id: "Desktop 渲染 / 点击 / 主题切换", reading: "未复跑", mode: "—" }],
    },
  ],
} as const;

const TONE: Record<AuditStatus, Tone> = { 已核对: "success", 部分: "warning", 未修: "danger" };

export default function InterfaceAudit() {
  const dispatch = useCanvasAction();
  const reviewed = useCanvasOverlay("claims", DATA.claims);
  const claims = reviewed.items as unknown as Array<(typeof DATA.claims)[number] & { __overlay?: { at: string | null } }>;

  const counts = { total: claims.length, ok: 0, part: 0, open: 0 };
  for (const c of claims) {
    if (c.status === "已核对") counts.ok++;
    else if (c.status === "部分") counts.part++;
    else counts.open++;
  }
  const open = claims.filter((c) => c.status !== "已核对");
  const top = claims.find((c) => c.id === DATA.nextAction.claimId);

  const statusPill = (s: AuditStatus) => <Pill size="sm" tone={TONE[s]}>{s}</Pill>;
  const levelPill = (level: string) => <Pill size="sm" tone={level === "L1" ? "info" : "neutral"}>{level}</Pill>;

  return (
    <Stack gap={24}>
      <Stack gap={6}>
        <H1>实现 vs 冻结契约：审计</H1>
        <Text tone="secondary">
          对象 <Text as="span" weight="semibold">@demxyuanli/dsh-canvas 0.2.0（k4）</Text> · 审计日 {DATA.asOf} · 修订 {DATA.revision} · 参照物
          <Text as="span" weight="semibold"> 仓内契约与规范文档</Text>
        </Text>
        <Text tone="tertiary" size="small">
          只读审计：逐条 grep / 读码 / 跑测试，判据带分级与测量口径；未复跑项显式标注。产物类型 {DATA.product}，预算 {DATA.budget}。
        </Text>
      </Stack>

      <Callout tone="info" title={"口径（参照物 = " + DATA.reference.kind + "）"}>
        <KeyValue
          items={[
            { label: "参照物", value: <Text as="span" size="small">{DATA.reference.what}</Text> },
            { label: "口径", value: <Text as="span" size="small">{DATA.reference.scope}</Text> },
            { label: "基线日", value: <Code>{DATA.reference.at}</Code> },
          ]}
          dense
        />
      </Callout>

      <Grid columns={4} gap={12}>
        <Stat value={String(counts.total)} label="断言" />
        <Stat value={String(counts.ok)} label="已核对" tone="success" />
        <Stat value={String(counts.part)} label="部分" tone="warning" />
        <Stat value={String(counts.open)} label="未修（含部分）" tone="danger" />
      </Grid>

      <Grid columns="1fr 1fr" gap={16}>
        <Stack gap={10}>
          <Text weight="semibold">处置分布</Text>
          <PieChart
            donut
            data={[
              { label: "已核对", value: counts.ok, tone: "success" },
              { label: "部分", value: counts.part, tone: "warning" },
              { label: "未修", value: counts.open - counts.part, tone: "danger" },
            ]}
          />
        </Stack>
        <Stack gap={10}>
          <Text weight="semibold">现在该做（全局唯一）</Text>
          <Callout tone="warning" title={DATA.nextAction.claimId}>
            <Text>{DATA.nextAction.action}</Text>
            <Text as="span" tone="tertiary" size="small">（{DATA.nextAction.why}）</Text>
          </Callout>
          <Row gap={8} wrap>
            <Button
              size="sm"
              onClick={() =>
                dispatch({
                  type: "startTurn",
                  prompt:
                    "处理 " + DATA.nextAction.claimId + "：" + DATA.nextAction.action + "。只改这一处，改完跑 npm test 自检并把判据与测量口径写回这张审计画布。",
                })
              }
            >
              在会话里开始
            </Button>
            <Button size="sm" variant="ghost" onClick={() => reviewed.set(String(DATA.nextAction.claimId), { status: "已核对" })}>
              标记已复核
            </Button>
          </Row>
        </Stack>
      </Grid>

      <H2>断言明细</H2>
      <Text tone="tertiary" size="small">
        窄表只放能扫的字段；断言、对照物与推导放在下面的卡片里——右栏默认偏窄，把句子塞进多列表格会把列挤成竖排。
      </Text>
      <Table
        headers={["#", "状态 / 级别", "判据（度量 → 结果）"]}
        rows={claims.map((c) => [
          <Code>{c.id}</Code>,
          <Row gap={4} align="center">
            {statusPill(c.status)}
            {levelPill(c.criterion.level)}
          </Row>,
          <Text as="span" size="small">{c.criterion.metric + " → " + c.criterion.delta}</Text>,
        ])}
        columnAlign={["left", "center", "left"]}
        rowTone={claims.map((c) => TONE[c.status])}
        striped
      />

      <Stack gap={12}>
        {claims.map((c) => (
          <Card key={c.id}>
            <CardHeader
              trailing={
                <Row gap={4} align="center">
                  {statusPill(c.status)}
                  {levelPill(c.criterion.level)}
                </Row>
              }
            >
              <Text>
                <Code>{c.id}</Code>
                <Text as="span" weight="semibold">　{c.claim}</Text>
              </Text>
            </CardHeader>
            <CardBody>
              <Stack gap={8}>
                <KeyValue
                  dense
                  items={[
                    { label: "端口", value: <Code>{c.counterpart.port}</Code> },
                    { label: "参照物", value: <Text as="span" size="small">{c.counterpart.occt}</Text> },
                    { label: "完成判据", value: <Text as="span" size="small">{c.counterpart.doneWhen}</Text> },
                    { label: "判据来源", value: <Text as="span" size="small" tone="tertiary">{c.criterion.ref}</Text> },
                    { label: "测量", value: <Text as="span" size="small">{c.measured.round + " · " + c.measured.at + " · " + c.measured.mode}</Text> },
                  ]}
                />
                <Text size="small" tone="secondary">{c.note}</Text>
              </Stack>
            </CardBody>
          </Card>
        ))}
      </Stack>

      <H2>仍为未修（本轮未动，勿误读为已修）</H2>
      <Table
        headers={["#", "条目 · 端口 · 参照物"]}
        rows={DATA.stillUnported.map((s) => [
          <Code>{s.id}</Code>,
          <Stack gap={2}>
            <Text as="span" size="small">{s.what}</Text>
            <Text as="span" size="small" tone="secondary">{s.portRef}</Text>
            <Text as="span" size="small" tone="tertiary">{s.occtRef}</Text>
          </Stack>,
        ])}
        columnAlign={["left", "left"]}
        rowTone={["warning", "warning", "warning"]}
        striped
      />

      <H2>禁令（未经尝试就先禁止的路线）</H2>
      <Stack gap={12}>
        {DATA.prohibitions.map((p, index) => (
          <Card key={p.pattern}>
            <CardHeader trailing={<Pill size="sm" tone="danger">禁令 {index + 1}</Pill>}>
              <Text weight="semibold">{p.pattern}</Text>
            </CardHeader>
            <CardBody>
              <KeyValue
                dense
                items={[
                  { label: "为什么诱人", value: <Text as="span" size="small">{p.temptingBecause}</Text> },
                  { label: "可观测症状", value: <Text as="span" size="small">{p.observableSymptom}</Text> },
                  { label: "复核条件", value: <Text as="span" size="small" tone="tertiary">{p.reviewWhen}</Text> },
                ]}
              />
            </CardBody>
          </Card>
        ))}
      </Stack>

      <H2>勘误（旧断言 → 新事实）</H2>
      <Table
        headers={["#", "旧断言 → 新事实 · 为什么漂了"]}
        rows={DATA.corrections.map((c) => [
          <Code>{c.id}</Code>,
          <Stack gap={2}>
            <Text as="span" size="small" tone="danger">{c.was}</Text>
            <Text as="span" size="small">→ {c.now}</Text>
            <Text as="span" size="small" tone="tertiary">{c.why}（{c.at} · {c.round}）</Text>
          </Stack>,
        ])}
        columnAlign={["left", "left"]}
        rowTone={["warning", "warning", "warning", "warning", "warning"]}
        striped
      />

      <H2>复核轮与门禁读数</H2>
      <Table
        headers={["轮", "门禁", "读数 · 口径"]}
        rows={DATA.rounds.flatMap((r) =>
          r.gates.map((g) => [
            <Text as="span" size="small" weight="semibold">{r.id}</Text>,
            <Code>{g.id}</Code>,
            <Stack gap={2}>
              <Text as="span" size="small">{g.reading}</Text>
              <Text as="span" size="small" tone="tertiary">{g.mode} · {r.what}</Text>
            </Stack>,
          ])
        )}
        columnAlign={["left", "left", "left"]}
        rowTone={["success", "success", "success", "success", "success", "success", "success", "warning"]}
        striped
      />

      <Card>
        <CardHeader trailing={<Row gap={6} align="center"><Pill size="sm">human</Pill><Pill size="sm">audit</Pill></Row>}>
          <H3>人手要做的三件事</H3>
        </CardHeader>
        <CardBody>
          <Stack gap={8}>
            <Text size="small">① 复核 C-05 的处置方向（实现超时，还是四处一起删）；② 对 C-06 / C-07 / C-08 三条文档漂移选「改文档」还是「改实现」；③ 确认 C-09 的字段投影是否要进下一轮。</Text>
            <Text size="small" tone="tertiary">
              人在面板上的标记走 sidecar（{reviewed.pending ? "写入中…" : "已落盘"}），下一轮 canvas_read 读得到；{top === undefined ? "（未找到锚点行）" : "当前锚点：" + top.id + " " + top.status}
            </Text>
          </Stack>
        </CardBody>
      </Card>

      <Text tone="tertiary" size="small">
        主要来源：INTERFACE.md（§3 §3.1 §5）· DESIGN.md（§21 A4 · §6.8）· README.md（配置项表 · 已知限制）· skills/canvas/references/（kit.md · troubleshooting.md · patterns.md 第 5 类）· 本轮实测：npm test / measure.mjs / 逐条 grep。
      </Text>
    </Stack>
  );
}
