"""Build docs/paper/paper.docx from docs/paper/paper.md.

Minimal, dependency-light Markdown -> DOCX converter for this one paper:
headings, paragraphs, blockquotes, bullets/numbers, pipe tables, fenced code,
images (height-capped so a tall board screenshot is not a 20-page figure) and
a centered caption paragraph. CJK glyphs get an explicit w:eastAsia font.
"""
import os
import re
import sys

from docx import Document
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor
from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
MD = os.path.join(HERE, "paper.md")
OUT = os.path.join(HERE, "paper.docx")

BODY_EA = "宋体"
HEAD_EA = "黑体"
LATIN = "Times New Roman"
MONO = "Consolas"

MAX_IMG_W = Cm(15.5)
MAX_IMG_H = Cm(21.0)


def style_run(run, *, latin=LATIN, ea=BODY_EA, size=None, bold=None, italic=None, mono=False):
    run.font.name = MONO if mono else latin
    rpr = run._element.get_or_add_rPr()
    rfonts = rpr.find(qn("w:rFonts"))
    if rfonts is None:
        rfonts = rpr.makeelement(qn("w:rFonts"), {})
        rpr.append(rfonts)
    rfonts.set(qn("w:eastAsia"), ea)
    rfonts.set(qn("w:ascii"), MONO if mono else latin)
    rfonts.set(qn("w:hAnsi"), MONO if mono else latin)
    if size is not None:
        run.font.size = size
    if bold is not None:
        run.font.bold = bold
    if italic is not None:
        run.font.italic = italic
    return run


INLINE = re.compile(r"(\*\*.+?\*\*|`[^`]+`|\[[^\]]+\]\([^)]+\))")


def add_inline(paragraph, text, *, ea=BODY_EA, size=None, base_bold=False):
    """Render **bold**, `code` and [label](target) into runs."""
    for token in INLINE.split(text):
        if not token:
            continue
        if token.startswith("**") and token.endswith("**") and len(token) > 4:
            style_run(paragraph.add_run(token[2:-2]), ea=ea, size=size, bold=True)
        elif token.startswith("`") and token.endswith("`") and len(token) > 2:
            style_run(paragraph.add_run(token[1:-1]), ea=ea, size=Pt(9.5), mono=True)
        elif token.startswith("[") and "](" in token and token.endswith(")"):
            label, target = token[1:-1].split("](", 1)
            style_run(paragraph.add_run(label), ea=ea, size=size, bold=base_bold)
            style_run(paragraph.add_run(" (" + target + ")"), ea=ea, size=Pt(8.5),
                      italic=True, latin=LATIN)
        else:
            style_run(paragraph.add_run(token), ea=ea, size=size, bold=base_bold)


def add_image(document, alt, src):
    path = os.path.normpath(os.path.join(HERE, src))
    if not os.path.exists(path):
        p = document.add_paragraph()
        style_run(p.add_run("[missing figure: %s]" % src), italic=True)
        return
    with Image.open(path) as im:
        w, h = im.size
    width = MAX_IMG_W
    height = int(width * h / w)
    if height > MAX_IMG_H:
        height = MAX_IMG_H
        width = int(height * w / h)
    p = document.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.add_run().add_picture(path, width=width, height=height)
    cap = document.add_paragraph()
    cap.alignment = WD_ALIGN_PARAGRAPH.CENTER
    style_run(cap.add_run(alt), ea=BODY_EA, size=Pt(9), italic=True)


def add_code_block(document, lines):
    p = document.add_paragraph()
    pf = p.paragraph_format
    pf.space_before = Pt(4)
    pf.space_after = Pt(8)
    pf.left_indent = Cm(0.4)
    for i, line in enumerate(lines):
        if i:
            p.add_run().add_break()
        style_run(p.add_run(line), ea=BODY_EA, size=Pt(8), mono=True)


def add_table(document, rows):
    header, body = rows[0], rows[1:]
    table = document.add_table(rows=1, cols=len(header))
    table.style = "Table Grid"
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = True
    for i, cell in enumerate(header):
        para = table.rows[0].cells[i].paragraphs[0]
        add_inline(para, cell, size=Pt(9), base_bold=True)
    for row in body:
        cells = table.add_row().cells
        for i in range(len(header)):
            text = row[i] if i < len(row) else ""
            add_inline(cells[i].paragraphs[0], text, size=Pt(9))
    document.add_paragraph()


def split_row(line):
    line = line.strip()
    if line.startswith("|"):
        line = line[1:]
    if line.endswith("|"):
        line = line[:-1]
    return [c.strip() for c in line.split("|")]


def main():
    with open(MD, encoding="utf-8") as fh:
        lines = fh.read().split("\n")

    document = Document()
    normal = document.styles["Normal"]
    normal.font.name = LATIN
    normal.font.size = Pt(10.5)
    normal._element.rPr.rFonts.set(qn("w:eastAsia"), BODY_EA)
    for section in document.sections:
        section.top_margin = Cm(2.2)
        section.bottom_margin = Cm(2.2)
        section.left_margin = Cm(2.4)
        section.right_margin = Cm(2.4)

    i = 0
    while i < len(lines):
        line = lines[i]
        stripped = line.strip()

        if stripped.startswith("```"):
            i += 1
            block = []
            while i < len(lines) and not lines[i].strip().startswith("```"):
                block.append(lines[i])
                i += 1
            add_code_block(document, block)
            i += 1
            continue

        if stripped.startswith("|") and i + 1 < len(lines) and re.match(r"^\|[\s:|-]+\|$", lines[i + 1].strip()):
            rows = [split_row(stripped)]
            i += 2
            while i < len(lines) and lines[i].strip().startswith("|"):
                rows.append(split_row(lines[i]))
                i += 1
            add_table(document, rows)
            continue

        image = re.match(r"^!\[(.*?)\]\((.+?)\)$", stripped)
        if image:
            add_image(document, image.group(1), image.group(2))
            i += 1
            continue

        if stripped in ("---", "***", "___"):
            p = document.add_paragraph()
            style_run(p.add_run("—" * 30), size=Pt(8))
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            i += 1
            continue

        if not stripped:
            i += 1
            continue

        m = re.match(r"^(#{1,4})\s+(.*)$", stripped)
        if m:
            level = len(m.group(1))
            text = m.group(2)
            if level == 1:
                p = document.add_paragraph()
                p.alignment = WD_ALIGN_PARAGRAPH.CENTER
                add_inline(p, text, ea=HEAD_EA, size=Pt(18), base_bold=True)
            elif level == 2:
                p = document.add_paragraph()
                p.alignment = WD_ALIGN_PARAGRAPH.CENTER
                add_inline(p, text, ea=HEAD_EA, size=Pt(13), base_bold=True)
            else:
                p = document.add_paragraph()
                p.paragraph_format.space_before = Pt(10)
                add_inline(p, text, ea=HEAD_EA, size=Pt(12) if level == 3 else Pt(11), base_bold=True)
            i += 1
            continue

        if stripped.startswith("> "):
            p = document.add_paragraph()
            p.paragraph_format.left_indent = Cm(0.8)
            p.paragraph_format.space_after = Pt(6)
            add_inline(p, stripped[2:], size=Pt(9.5))
            for run in p.runs:
                run.font.color.rgb = RGBColor(0x44, 0x44, 0x44)
            i += 1
            continue

        if stripped.startswith("- "):
            p = document.add_paragraph(style="List Bullet")
            add_inline(p, stripped[2:])
            i += 1
            continue

        m = re.match(r"^(\d+)\.\s+(.*)$", stripped)
        if m:
            p = document.add_paragraph(style="List Number")
            add_inline(p, m.group(2))
            i += 1
            continue

        if stripped.startswith("<") and stripped.endswith(">"):
            p = document.add_paragraph()
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            style_run(p.add_run(re.sub(r"<[^>]+>", "", stripped)), ea=BODY_EA, size=Pt(9), italic=True)
            i += 1
            continue

        p = document.add_paragraph()
        p.paragraph_format.space_after = Pt(6)
        p.paragraph_format.first_line_indent = Cm(0.74)
        add_inline(p, stripped)
        i += 1

    document.save(OUT)
    print("wrote", OUT)


if __name__ == "__main__":
    sys.exit(main())
