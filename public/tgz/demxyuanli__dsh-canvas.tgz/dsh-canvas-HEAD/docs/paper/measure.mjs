/**
 * Reproducibility harness for docs/paper/paper.md.
 *
 * Every number quoted in the paper's evaluation section is produced here, from
 * the real host modules — no re-implementation, no hand-copied figures.
 *
 *   node docs/paper/measure.mjs            # full report
 *   node docs/paper/measure.mjs --json     # machine-readable, for diffing
 *
 * Measured: canvas corpus health, cold-compile latency vs content-hash hit
 * latency, and the context cost of each canvas_read slice against the raw file.
 */
import { promises as fs } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { transform } from "sucrase";

import { compileCanvas, contentSha, DEFAULT_LIMITS, COMPILER_VERSION, KIT_VERSION } from "../../host/compile.js";
import { briefDigest } from "../../host/brief.js";
import { toolDefinitions } from "../../index.js";
import { defineTool } from "@deepseek-ai/dsh-tools";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..", "..");
const AS_JSON = process.argv.includes("--json");
const out = [];
function say(line = "") { if (!AS_JSON) console.log(line); else out.push(line); }

const SKIP_DIRS = new Set(["node_modules", ".git", ".canvas", "docs", "test"]);

/** All *.canvas.tsx in the repo, excluding the shot-render fixtures under docs/. */
async function findCanvases(dir, acc = []) {
  for (const entry of await fs.readdir(dir, { withFileTypes: true })) {
    if (entry.isDirectory()) {
      if (SKIP_DIRS.has(entry.name)) continue;
      await findCanvases(path.join(dir, entry.name), acc);
    } else if (entry.name.endsWith(".canvas.tsx")) {
      acc.push(path.join(dir, entry.name));
    }
  }
  return acc;
}

const rel = (p) => path.relative(ROOT, p).replace(/\\/g, "/");
const bytes = (s) => Buffer.byteLength(s, "utf8");

function percentile(sorted, p) {
  const i = Math.min(sorted.length - 1, Math.max(0, Math.ceil((p / 100) * sorted.length) - 1));
  return sorted[i];
}

function stats(samples) {
  const s = samples.slice().sort((a, b) => a - b);
  const sum = s.reduce((a, b) => a + b, 0);
  return {
    n: s.length,
    min: +s[0].toFixed(3),
    median: +percentile(s, 50).toFixed(3),
    p95: +percentile(s, 95).toFixed(3),
    max: +s[s.length - 1].toFixed(3),
    mean: +(sum / s.length).toFixed(3),
  };
}

// ---------------------------------------------------------------- 1. corpus
const canvases = (await findCanvases(ROOT)).sort();
const corpus = [];
for (const file of canvases) {
  const source = await fs.readFile(file, "utf8");
  const result = compileCanvas({ path: file, source });
  const errors = result.diagnostics.filter((d) => d.severity === "error");
  const warnings = result.diagnostics.filter((d) => d.severity === "warning");
  corpus.push({
    path: rel(file),
    lines: result.lines ?? source.split("\n").length,
    bytes: bytes(source),
    dataBytes: result.data === undefined ? null : bytes(JSON.stringify(result.data)),
    ok: result.ok === true,
    errors: errors.map((d) => d.code),
    warnings: warnings.map((d) => d.code),
    sha: result.sha ?? null,
  });
}

// ------------------------------------------------- 2. compile / cache latency
const LARGE = path.join(ROOT, "board.canvas.tsx");
const largeSource = await fs.readFile(LARGE, "utf8");
const N = Number(process.env.N ?? 50);

const cold = [];
const hit = [];
const sucraseOnly = [];
for (let i = 0; i < 5; i++) compileCanvas({ path: LARGE, source: largeSource }); // warm up
for (let i = 0; i < N; i++) {
  let t = process.hrtime.bigint();
  compileCanvas({ path: LARGE, source: largeSource });
  cold.push(Number(process.hrtime.bigint() - t) / 1e6);

  t = process.hrtime.bigint();
  contentSha(largeSource);
  hit.push(Number(process.hrtime.bigint() - t) / 1e6);

  t = process.hrtime.bigint();
  transform(largeSource, {
    transforms: ["typescript", "jsx", "imports"],
    jsxRuntime: "classic",
    jsxPragma: "__DSH_CANVAS__.h",
    jsxFragmentPragma: "__DSH_CANVAS__.Fragment",
    production: true,
    filePath: LARGE,
  });
  sucraseOnly.push(Number(process.hrtime.bigint() - t) / 1e6);
}

// ------------------------------------------------------ 3. context cost
const state = { config: { limits: DEFAULT_LIMITS }, rootFor: () => ROOT };
const readTool = defineTool(toolDefinitions(state).find((o) => o.name === "canvas_read"));

async function readSlice(args) {
  const res = await readTool.execute(args, {});
  const json = String(res.json ?? "");
  let rows = null;
  try {
    const parsed = JSON.parse(json);
    if (Array.isArray(parsed)) rows = parsed.length;
    else if (parsed && Array.isArray(parsed.tasks)) rows = parsed.tasks.length;
    else if (parsed && Array.isArray(parsed.rows)) rows = parsed.rows.length;
  } catch { /* scalar slices have no row count */ }
  return { chars: json.length, bytes: bytes(json), rows, summary: String(res.summary ?? "") };
}

const slices = [];
for (const [label, args] of [
  ["brief digest", { path: LARGE, brief: true }],
  ["DATA (no slice)", { path: LARGE }],
  ["DATA.tasks", { path: LARGE, dataPath: "tasks" }],
  ["tasks.status=in_progress", { path: LARGE, dataPath: "tasks", filter: { status: "in_progress" } }],
  ["tasks.status=blocked", { path: LARGE, dataPath: "tasks", filter: { status: "blocked" } }],
  ["tasks.ids=[R-04]", { path: LARGE, dataPath: "tasks", ids: ["R-04"] }],
  ["DATA.activity limit=5", { path: LARGE, dataPath: "activity", limit: 5 }],
]) {
  const r = await readSlice(args);
  slices.push({ label, ...r });
}

const briefPerCanvas = [];
for (const file of canvases) {
  const source = await fs.readFile(file, "utf8");
  const result = compileCanvas({ path: file, source });
  if (!result.ok || result.data === undefined) continue;
  briefPerCanvas.push({
    path: rel(file),
    sourceChars: source.length,
    dataChars: JSON.stringify(result.data).length,
    briefChars: JSON.stringify(briefDigest(result.data)).length,
  });
}

// ------------------------------------------------------ 4. component surface
const clientSrc = await fs.readFile(path.join(ROOT, "lib", "client.js"), "utf8");
const hostFiles = ["index.js", ...(await fs.readdir(path.join(ROOT, "host"))).filter((f) => f.endsWith(".js")).map((f) => "host/" + f)];
let hostBytes = 0;
let hostLines = 0;
for (const f of hostFiles) {
  const s = await fs.readFile(path.join(ROOT, f), "utf8");
  hostBytes += bytes(s);
  hostLines += s.split("\n").length;
}
let testFiles = 0;
let testLines = 0;
let testAsserts = 0;
for (const f of (await fs.readdir(path.join(ROOT, "test"))).filter((f) => f.endsWith(".mjs"))) {
  const s = await fs.readFile(path.join(ROOT, "test", f), "utf8");
  testFiles++;
  testLines += s.split("\n").length;
  testAsserts += (s.match(/\bassert\b/g) ?? []).length;
}

const report = {
  generatedAt: new Date().toISOString(),
  node: process.version,
  compiler: { COMPILER_VERSION, KIT_VERSION },
  corpus,
  latencyMs: { coldCompile: stats(cold), shaHit: stats(hit), sucraseOnly: stats(sucraseOnly), iterations: N },
  contextCost: {
    canvas: rel(LARGE),
    sourceChars: largeSource.length,
    sourceBytes: bytes(largeSource),
    slices,
  },
  briefPerCanvas,
  surface: {
    clientLines: clientSrc.split("\n").length,
    clientBytes: bytes(clientSrc),
    hostLines,
    hostBytes,
    hostFiles: hostFiles.length,
    testFiles,
    testLines,
    testAsserts,
  },
};

if (AS_JSON) {
  console.log(JSON.stringify(report, null, 2));
} else {
  say("=== 1. canvas corpus (repo-local instances + shipped templates) ===");
  say("path".padEnd(46) + "lines".padStart(7) + "bytes".padStart(9) + "DATA".padStart(9) + "  ok  diag");
  for (const c of corpus) {
    const diag = [...c.errors, ...c.warnings].join(",") || "-";
    say(c.path.padEnd(46) + String(c.lines).padStart(7) + String(c.bytes).padStart(9) +
        String(c.dataBytes ?? "-").padStart(9) + "  " + (c.ok ? "yes" : "NO ") + "  " + diag);
  }
  say(`total ${corpus.length} canvases, ${corpus.filter((c) => c.ok).length} compile clean, ` +
      `${corpus.filter((c) => c.errors.length > 0).length} with errors, ` +
      `${corpus.filter((c) => c.warnings.length > 0).length} with warnings`);

  say("\n=== 2. latency on the largest canvas (" + rel(LARGE) + ", " + bytes(largeSource) + " B, N=" + N + ") ===");
  say("path                    min     median     p95      max     mean   (ms)");
  for (const [label, s] of [["cold compile (scan+sucrase+extract)", report.latencyMs.coldCompile],
                            ["sucrase transform only", report.latencyMs.sucraseOnly],
                            ["content-hash hit (no compile)", report.latencyMs.shaHit]]) {
    say(label.padEnd(38) + String(s.min).padStart(6) + String(s.median).padStart(10) +
        String(s.p95).padStart(9) + String(s.max).padStart(9) + String(s.mean).padStart(9));
  }

  say("\n=== 3. context cost of canvas_read on " + rel(LARGE) + " (raw source " + largeSource.length + " chars) ===");
  say("slice".padEnd(28) + "chars".padStart(8) + "bytes".padStart(8) + "rows".padStart(6) +
      "   vs raw");
  for (const s of slices) {
    const ratio = (s.chars / largeSource.length * 100).toFixed(1) + "%";
    say(s.label.padEnd(28) + String(s.chars).padStart(8) + String(s.bytes).padStart(8) +
        String(s.rows ?? "-").padStart(6) + "   " + ratio);
  }

  say("\n=== 4. digest vs source, per compiled canvas ===");
  say("canvas".padEnd(46) + "source".padStart(9) + "DATA".padStart(9) + "brief".padStart(8) + "  brief/source");
  for (const b of briefPerCanvas) {
    say(b.path.padEnd(46) + String(b.sourceChars).padStart(9) + String(b.dataChars).padStart(9) +
        String(b.briefChars).padStart(8) + "  " + (b.briefChars / b.sourceChars * 100).toFixed(1) + "%");
  }

  say("\n=== 5. implementation surface ===");
  say(`host:   ${hostFiles.length} files, ${hostLines} lines, ${hostBytes} B`);
  say(`client: 1 file,  ${report.surface.clientLines} lines, ${report.surface.clientBytes} B`);
  say(`test:   ${testFiles} files, ${testLines} lines, ${testAsserts} assert references`);
}
