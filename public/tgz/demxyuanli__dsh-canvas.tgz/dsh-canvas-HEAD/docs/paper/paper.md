# 画布（Canvas）：把 Agent 的长任务状态外化为可编译、可回写的人机共享面板

### —— DeepSeek Harness 插件 `@demxyuanli/dsh-canvas` 的设计、实现与评估

**作者**：dsh-canvas 项目组　**日期**：2026-09-29　**版本**：`@demxyuanli/dsh-canvas@0.2.0`

**摘要**

大语言模型 Agent 在长任务中产生的"给人看的产物"目前基本是散文与 markdown：它们不可下钻、不可交互，而且对人类和 Agent 来说都只能整篇读取，导致上下文成本随文件大小线性增长；更严重的是，其中的结论往往来自模型自述，而不是机器可复核的证据。本文提出并实现了一种替代形态——**画布（canvas）**：Agent 写一个 `*.canvas.tsx` 文件，宿主用 `sucrase` 实时编译为 ESM 并在 Web GUI 右栏渲染成可交互面板；面板上的按钮能反向回灌 Agent（发起会话回合、执行白名单命令、把人的判断写回源文件）。本文的贡献有四：(1) 给出"文件 + 编译 + 套件 + 钩子 + 动作桥"五位一体的形态设计，并论证五者缺一不可；(2) 提出**不执行代码的内联数据抽取**——用括号配对扫描加宽容字面量解析从源码中取出 `export const DATA`，使"内联给人看"与"切片给 Agent 读"不再矛盾；(3) 用 sidecar overlay 与最小文本级回写解决人机共享状态的写冲突，保持"源文件是唯一真相"；(4) 在一个真实插件（约 3.9 k 行实现代码、9 个测试文件 437 处断言、9 张真实画布）上做工程评估。实测：9/9 画布编译零诊断；最大画布（685 行 / 43.6 KB）冷编译中位数约 4 ms（设计预算 50 ms），内容哈希命中约 0.08 ms；`brief` 恢复摘要为源文件的 2.7%–10.6%，使"上下文成本与文件大小脱钩"在摘要路径上成立。论文同时报告 8 类真实缺陷（含 2 次把文件写进应用数据目录的路径事故），并明确界定未验证项与威胁。

**关键词**：LLM Agent；人机协同产物；生成式界面；上下文工程；插件架构；DeepSeek Harness

---

## 1 引言

### 1.1 问题

当 Agent 承担跨多轮、多状态的长任务（迁移、审计、门禁对齐、发布收口）时，它需要一个"对外的产物"来承载进度。今天的默认做法是 markdown：一个不断变长的 `_board.md` / `TODO.md`，或者每轮在对话里重贴一遍清单。这种做法有四个结构性缺陷。

**（D1）不可下钻。** 散文与表格是静态的。人想"只看还没做的、按分组折叠、点一下把某条交回给 Agent"，只能靠 Agent 再写一遍。

**（D2）上下文成本与文件大小线性相关。** 内联在 markdown 里的数据没有结构化入口。Agent 想知道"12 条待办是什么"，只能整篇读取——本插件的设计文档记录了一个真实量级：迁移前的 `_board.md` 有 4 160 行 / 888 KB。文件越大，每次更新的代价越高，于是"别再更新它"成了理性选择。

**（D3）结论来自模型自述。** 门禁是否通过、测试是否变绿，在 markdown 里是模型写下的一句话，不是可复核的退出码与 `file:line`。这使"证据"退化为"叙述"。

**（D4）人机的状态不一致。** 人在文档里改了一行，Agent 下一轮可能整篇重写把它覆盖掉；反过来，Agent 的判断也无法持久地呈现在人正在看的地方。

### 1.2 本文的思路

本文的核心主张是：**把产物从"散文"换成一个能编译、能交互、能回灌 Agent 的代码文件**，并围绕它补齐三件事——数据可切片读取、人的判断可写回、证据来自真实运行。具体形态：

- Agent 写 `*.canvas.tsx`（真 TSX，只允许 `import "dsh/canvas"`）；
- 宿主（Node 侧）用 `sucrase` 编译成内容寻址的 ESM 模块，浏览器半边动态 `import()` 后渲染成右栏 tab；
- 画布的数据放在 `export const DATA = {...} as const` 里，**必须是纯字面量**，宿主用括号扫描把它抽出来而**不执行 Agent 的代码**——于是同一个文件既给人看（渲染）也给 Agent 读（切片）；
- 人在面板上的判断落到源文件旁边的 sidecar（`.canvas/<stem>.state.json`），Agent 下轮可读，确认后用最小字段替换**固化**回源文件；
- 面板按钮通过动作桥回灌 Agent：`startTurn`（发起回合，带冷却去重）、`runCommand`（只能跑 Config 白名单里的命令，经 `ctx.shell` 并按调用方 Session 的沙箱策略执行）、`overlaySet` / `overlayClear`。

![图 1　画布的人机闭环：Agent 写结论，人写判断，源文件是唯一持久真相，sidecar 只是暂存区](figures/fig-lifecycle.png)

### 1.3 贡献

1. **形态设计**：提出"文件 + 编译 + 套件 + 钩子 + 动作桥"五位一体，并给出每个机制的不可替代性论证（§3.3）。
2. **不执行代码的数据抽取**（§4.4）：解决"内联数据"与"Agent 可切片读取"的张力，这是全文最关键的一条——没有它，内联数据只是换了个壳的 markdown。
3. **人机共享状态的 staged 写模型**（§4.5）：sidecar + 最小文本级回写，既避免并发改写源文件的冲突，也保持"源文件是唯一持久真相"。
4. **真实系统的工程评估**（§6）：10 张真实画布、9 个测试文件 489 处断言、可复现的测量脚本，以及对 8 类真实缺陷（含两次路径事故）的归因分析。

### 1.4 本文不主张什么

本文不主张画布能替代 `todo_write`（短任务）或 `goal`（"是否继续下一轮"）；不主张它是通用前端框架（画布只能 import `dsh/canvas`）；也不主张画布代码是安全沙箱——**画布代码的信任级别等于插件代码**（§4.10）。本文的评估是工程级评估：单元/集成测试、测量脚本与真实 GUI 上的人工验收，**不含**受控用户实验。这一点在 §8 明确列为威胁。

---

## 2 背景与相关工作

**（1）Agent 的规划与状态工具。** 从 ReAct 起，Agent 的"思考—行动"循环就让中间状态显式化<sup>[1]</sup>；工程实践中出现了 `todo_write` 这类轻量计划工具。它们面向的是**短任务与单会话内的自我管理**，不带给人看的 UI，也不解决跨会话的产物形态。

**（2）生成式界面与"Agent 产出 UI"。** 近期出现了把自然语言规格渲染成界面的工作，例如 Portal UX Agent（从自然语言规格渲染 UI）<sup>[5]</sup>、SpecifyUI（用结构化规格支持迭代式 UI 设计意图表达）<sup>[6]</sup>，以及关于"生成式用户界面"设计定义的讨论<sup>[7]</sup>。这些工作关注的是**由模型生成界面**本身；本文关注的是**产物在 Agent 工作流中的位置**：它是可 diff 的源文件、可切片读取的数据源、可回灌 Agent 的控制面板。

**（3）宿主内嵌产物。** Claude 的 Artifacts 把模型产出的可交互片段放进对话侧栏<sup>[3]</sup>；Cursor 的 Canvas 让 Agent 在编辑器里生成交互式画布并读回人的操作<sup>[2]</sup>；MCP 生态正在推进 MCP Apps（SEP-1865，为 MCP 定义交互式用户界面）<sup>[4]</sup>。本文与它们在形态上同源（本文的设计也明确以 Cursor Canvas 的组件套件为参考实现），差异在三点：数据内联且可被宿主**静态抽取**、人的改动经 sidecar **staged** 后固化、以及**门禁证据来自真实退出码**。

> **资料来源限制（重要）**：本文写作所处的网络环境无法获取上述外部来源的全文（域名解析被限制为公网之外不可达），因此 §2 对这些工作的描述限于其标题与公开摘要层面，引文以 URL 形式给出；本文未从这些来源推导任何实现细节。§3 之后的全部内容均来自本仓可读、可运行的代码与文档。

**（4）规范化产物与"读切片"。** 与本文最接近的思想冲突在于：结构化数据通常要求外置（JSON/CSV/YAML），而"给人看"要求内联（一个文件、可 diff、可 grep）。本文的做法是**内联但可静态抽取**：只允许纯字面量，宿主自己做词法级解析（§4.4），从而两全。

---

## 3 设计思路

### 3.1 目标与非目标

| 目标 | 非目标（本设计不做） |
|---|---|
| Agent 写一个 `*.canvas.tsx`，宿主实时编译渲染为可交互面板 | 不做画布的市场 / 分发 / 版本管理 |
| 渲染使用宿主主题与排版，Agent **不写任何 CSS** | 不向画布代码提供网络、文件写入、DOM 直操作 |
| 面板按钮能回灌 Agent（开会话 / 跑命令 / 写状态） | 不替代 `todo_write`（短任务）与 `goal`（是否继续） |
| Agent 有自检手段：编译校验、结构化查询、脚手架 | 不做"Agent 自动决定该画什么"的调度 |
| 人的交互对 Agent **可见**（sidecar，下轮可读） | 不修改 DSH 自身的任何已发布包（纯增量插件） |
| 编译失败 / 运行时崩溃**不能是白屏**，必须是可诊断卡片 | 不引入 iframe / Worker 隔离（见 §4.10 残留风险） |

### 3.2 载体：真 TSX，不是声明式 DSL

一条早期决策值得记录：画布语言选择**真 TSX + 宿主编译**，而不是自造声明式 DSL。理由是能力天花板：一旦产物需要"筛选、聚合、排序、条件渲染、图表"同时表达，DSL 走到第三步就会长出半吊子表达式语言，最终仍然要变成一门编程语言——只是更差。选择真 TSX 的代价是需要引入一个编译器依赖（`sucrase`，纯 JS、无原生二进制）。

### 3.3 五个机制，缺一不可

| 机制 | 作用 | 少了它会怎样 |
|---|---|---|
| **文件**（`*.canvas.tsx`） | 产物可 diff、可进 git、可用普通文件工具改 | 退回私有存储，失去 DSH 的既有强项 |
| **编译**（sucrase → 内容寻址 ESM） | 同一产物内表达筛选/聚合/条件/图表 | 退回"更好的 markdown" |
| **套件**（`dsh/canvas`，25 组件 + 10 钩子） | 把"好看"变成默认：Agent 只选语义（`tone="warning"`），不碰间距/圆角/配色 | 每个画布都手写样式，主题切换即崩 |
| **钩子**（`useCanvasState` / `useCanvasOverlay`） | 区分"纯 UI 态"与"对 Agent 可见的共享态" | 筛选器污染数据，或人的点击对 Agent 不可见 |
| **动作桥**（7 类动作） | 把"下一步"直接变成 Agent 指令 | 产物是死报表，不是活看板 |

### 3.4 关键决策及其代价

**决策 A：数据内联在画布文件里。** 这是全设计最危险的一条，代价必须写在最前面：内联数据意味着画布文件会长成"第二个 `_board.md`"。本文把它当作一个整体来处理——**内联是给人看的产物格式，不是 Agent 的读取格式**。因此必须同时补偿两件事：

- **补偿 1（静态抽取）**：`export const DATA` 必须是纯字面量，宿主用括号扫描 + 宽容字面量解析取出，**不执行代码**（§4.4）；
- **补偿 2（staged 写）**：人的改动不直接改源文件，而是落 sidecar，需要时由 `canvas_state_merge` 最小化写回（§4.5）。

**决策 B：通用插件，不与任何项目耦合。** 画布不能依赖本仓约定（例如 OCCT 门禁）；项目规则由项目自己的 rules 文件提供。这条决策的直接后果是发现机制必须做成"工作区里任何 `*.canvas.tsx`"，且命令白名单默认**为空 = 全部拒绝**。

**决策 C：内容寻址的模块 URL。** `sha = sha1(source + "|" + COMPILER_VERSION + "|" + KIT_VERSION)[:16]`。三者任一变化即新 URL。收益是"未变化的保存不触发重编译、浏览器缓存永不陈旧"；代价是旧模块无法回收（浏览器不能卸载已 `import` 的 ESM），长期会话里旧版本会累积（§8）。

### 3.5 三条设计原则

1. **产物的可编译性**：画布必须是代码，因此可以静态检查、可以自检、可以回归测试。宿主为它定义了 16 个诊断码（§4.3）。
2. **数据的可查询性**：任何"要 Agent 看"的数据都必须能被结构化切片读取（`dataPath` / `filter` / `ids` / `limit`），否则等于没有。
3. **证据的真实性**：门禁红绿来自 `ctx.shell` 的真实退出码；`evidence` 字段要求写 `文件:行 / 测试名 / 运行号`。**可复核性**是这一条的操作定义。

---

## 4 系统实现

### 4.1 总体架构：单包双半

插件是一个 npm 包 `@demxyuanli/dsh-canvas@0.2.0`，同时声明两个半边：

| 半边 | 入口 | 规模 | 职责 |
|---|---|---|---|
| host（Node / cordis） | `index.js` + `host/*.js` | 12 文件 / 2 551 行 / 118 KB | 编译、模块服务、画布发现、`DATA` 抽取、导出面校验、sidecar 读写、动作桥、4 个模型工具、意图入口 |
| browser | `lib/client.js`（构建产物） | 1 文件 / 1 583 行 / 81 KB | `dsh/canvas` 套件、右栏 tab type（认领 `*.canvas.tsx`）、源码读取、动态 `import()` 挂载、错误边界 |

![图 2　总体架构：单包双半。工作区是唯一持久真相；host 半边负责编译、抽取、sidecar 与工具；browser 半边负责渲染与动作采集](figures/fig-architecture.png)

在数据流上，一次完整往返是：文件保存 → host 发现 / watch → `sucrase` 编译 → 内容哈希 → 模块 URL → 浏览器动态 `import(url)` → 渲染；面板动作则反向走 `POST /canvas/action`。

宿主注册**一个**前缀路由 `/canvas`，内部按 pathname 分发，共 8 个端点：`/canvas/api`、`/canvas/list`、`/canvas/source`、`/canvas/compile`、`/canvas/module/<pathHash>/<sha>.js`、`/canvas/overlay`（GET/POST）、`/canvas/action`。其中一条接口纪律值得强调：**编译失败不是 HTTP 错误，永远 200**，诊断在响应体里——这样客户端只有一个错误处理路径（渲染错误卡片），而不是"网络错误"与"编译错误"两套。

### 4.2 编译管线

`compileCanvas` 的顺序是：体积/行数硬阈值 → 静态扫描（非法 import、动态代码、副作用、外部资源）→ sucrase 变换 → 默认导出检查 → `DATA` 抽取 → 计算 sha 与 URL → `wrap()`。

两个实现细节：

1. **JSX 走 classic runtime + pragma 指向注入对象**：`jsxPragma: "__DSH_CANVAS__.h"`、`jsxFragmentPragma: "__DSH_CANVAS__.Fragment"`。这样无需把 `react/jsx-runtime` 塞进宿主模块表（那是 DSH 内部机制，插件不应依赖）。
2. **产物是受限 CJS-in-ESM 包装**：`wrap()` 生成一个 `__require`，只认 `"dsh/canvas"` 和 `"react"`，其它一律抛错；这是对编译期 import 白名单的**反向兜底**（不只信任改写器）。产物末尾导出 `export const __canvas = { compiler: "c1", kit: "k4" }`，便于排查"页面用的是哪一版"。

**编译缓存**：`ModuleStore` 为内容寻址模块做 LRU（64 条 / 32 MiB，至少保留 1 条）。命中则直接返回字节；未命中 404 `unknown or evicted canvas module <sha>`，浏览器会重新编译——不会静默拿到陈旧内容。

![图 3　编译与 `DATA` 抽取管线：六个阶段、各自的诊断码，以及"诊断有两个产出方"这条边界](figures/fig-pipeline.png)

### 4.3 静态约束与诊断

诊断码表共 15 条（8 个 error + 4 个产出型 warning + 4 个 reserved 永不产出）：

| 码 | 级别 | 产出方 | 修法要点 |
|---|---|---|---|
| `E_PARSE` | error | sucrase | 看行列号，通常是 JSX 标签不配对 |
| `E_PARSE_IMPORT` | error | 扫描器 | 只允许 `dsh/canvas`（`import React` 也归这条） |
| `E_UNKNOWN_EXPORT` | error | 扫描器 | 具名导入不在套件导出面内；消息附"是不是想用 X"的建议 |
| `E_NO_DEFAULT` | error | 管线 | 导出一个无参组件 |
| `E_SIDE_EFFECT` | error | 扫描器 | 顶层副作用（`fetch`/`setTimeout`/`localStorage`/`document.`/`console.` …）移出模块顶层 |
| `E_DYNAMIC` | error | 扫描器 | `eval` / `new Function` / 动态 `import()` |
| `E_EXTERNAL` | error | 扫描器 | 远程 `<img>` / `<iframe>` 去掉；用内联 SVG |
| `E_DATA_NOT_LITERAL` | error | 抽取 | `DATA` 写成纯字面量，计算放渲染期 |
| `E_TOO_LARGE` | error | 管线 | 超硬阈值（1 MB / 8 000 行 / `DATA` 4 MB） |
| `E_MERGE` | error | `canvas_state_merge` | `DATA` 必须是对象字面量且每行有 `id` |
| `W_NO_DATA` | warning | 抽取 | 没有 `export const DATA` → `canvas_read` 退化全文 |
| `W_LARGE_FILE` | warning | 管线 | 超软阈值（128 KB / 1 500 行 / `DATA` 512 KB） |
| `W_REMOTE_URL` | warning | 扫描器 | 源码里有 `http(s)://`（不可 fetch） |
| `W_UNKNOWN_PROP` / `W_NO_METADATA` / `W_MANY_ROWS` | reserved | — | 当前**不产出**（`W_MANY_ROWS` 实为渲染期文案；`W_DEPRECATED` 是 client 渲染期信号，不在 host 码表里） |

其中 `E_UNKNOWN_EXPORT` 是本文写作过程中**从一次真实对读里补出来的**：把一份为另一套同名套件（Cursor Canvas）写的画布改掉模块说明符后，`canvas_check` 报 0 error，直到渲染期才崩——因为编译期只校验**模块说明符**，从不校验**具名导入**。补上之后，同一个文件在编译期就得到一条指到名字的 error。这也是 §7.3 "同一份事实写两遍必然漂移"的一个正面用法：导出面清单有两份（host 侧 `host/kitsurface.js` 与 client 侧 `lib/client.js` 的 `kit`），所以用一条**双向**测试锚定它们，而不是靠文档纪律（§6.1）。

一个工程上很关键的取舍：**诊断有两个产出方**——编译期（host）与渲染期（client）。`canvas_check` 只看得到前者，因此它**不可能**验证行数截断；这条边界被写进了 troubleshooting 文档，避免 Agent 用错的工具做错的判断。

### 4.4 `DATA` 抽取：不执行代码（全文最关键的一条）

**问题**：数据内联后，Agent 若不切片就必须全文重读，等于把 markdown 的老路走一遍。

**做法**：约束 `export const DATA` 必须是**纯字面量**（无函数调用、无模板拼接、无非字面量 spread、无 `Date.now()`），宿主据此做词法级抽取：

1. 在 sucrase 产物上正则定位 `const DATA =` 的起始偏移；
2. 用**括号配对扫描**（含字符串/注释/正则字面量状态机）找到字面量结束位置；
3. 用**宽容字面量解析器**读它：容忍尾逗号、单引号、无引号键、注释，`undefined`/`NaN` 归为 `null`；同时为每个节点记录 `start`/`end` 跨度；
4. 校验结果是纯 JSON 值；出现标识符引用则报 `E_DATA_NOT_LITERAL`。

**明确否决**：不在宿主里用 `vm` 执行画布模块来取数据——那等于把 Agent 写的任意代码放进宿主进程。**`canvas_read` 必须能在"源码是恶意"的前提下安全运行。**

抽取出的跨度信息还有第二处用处：`canvas_state_merge` 用同一套解析器定位要替换的字段区间，因此"读"和"写"永远不会对 `DATA` 的形状产生分歧（同一份十六进制偏移）。

### 4.5 sidecar 与最小回写：staged 写模型

人点一下"标记完成"，有三种可能的写法，本设计选了第三种：

| 做法 | 后果 |
|---|---|
| 只写 `localStorage` | Agent 看不到，人机不一致——正是用户抱怨的"编排混乱" |
| 直接改写源文件 | 触发重编译；需要 AST 级改写；并发编辑冲突 |
| **sidecar overlay（选中）** | 人的改动落独立 JSON；`canvas_read` 能读到；需要时用工具**固化**回源文件 |

sidecar 位于画布同目录的 `.canvas/<stem>.state.json`，记录了 `sourceSha1`、`updatedAt` 与 `overlays[key][id]`（对该行 `DATA` 项的**浅合并补丁**，并自动盖章 `at` / `by: "user"`）。三条语义值得写出：

1. **源文件变化后不自动丢弃 overlay**（人的标注往往仍然有效），但 `canvas_read` 会返回 `staleOverlay: true`；
2. **新源码里已不存在的 `id` 标记为 `orphan` 而非删除**——它是证据，不是垃圾；
3. **固化由 Agent 决定**：`canvas_state_merge` 做**文本级最小替换**（只改被补丁覆盖的字段区间），而不是重新序列化整个 `DATA`。后者会把整文件重排、毁掉 diff。实现细节上它甚至照顾排版：单行对象保持单行，CRLF 文件不会长出裸 LF，tab 缩进保持 tab——理由是"两种都合法，但都会让复核过这份文件的人觉得文件被破坏了"。

![图 4　sidecar 的 staged 写模型：人的判断先落暂存区（②③），Agent 下一轮读切片（⑤⑥），确认后才最小化固化回源文件（⑦⑧）](figures/fig-sidecar.png)

### 4.6 动作桥与沙箱策略透传

面板上的动作分两路。**client 自己处理**：`openFile` / `openResource` / `copy`（不经过网络）。**发往 host**：`startTurn` / `runCommand` / `notify` / `overlaySet` / `overlayClear`。

`runCommand` 的三条约束构成一个完整的信任链：

1. **默认拒绝**：Config 的 `commandWhitelist` 默认空数组 = 全部拒绝（返回 `unsupported`）；
2. **命令串永远取自白名单项**：请求只能按 `id` 或完整命令字符串**逐字选中**一项，不能改写它。测试里有一条专门的用例：请求带 `command: "rm -rf /"`，实际执行的仍然是白名单里的 `echo gate-ok`；
3. **执行按调用方 Session 的沙箱策略**：`ctx.sandboxPolicy.resolve({ session })` 的结果作为 `request.sandboxPolicy` 交给 `ctx.shell`。没有 session 时不拒绝也不猜，而是**显式回落**到部署默认，并在结果里带 `policy: { source, sessionId, reason }` 与一句括注——面板不能把"部署默认"读成"调用方自己的策略"。

`startTurn` 则做了限流与可审计：同一画布 + 同一 prompt 在 `startTurnCooldownMs`（默认 30 s）内只接受一次；`requestId` 带 `canvas-` 前缀，使会话日志能回答"这条消息是哪个按钮触发的"——这个前缀后来还成了意图入口的过滤信号（§4.8）。

### 4.7 模型侧四个工具与 `brief` 摘要

| 工具 | 参数 | 语义 |
|---|---|---|
| `canvas_new` | `path`, `kind: blank\|board\|gates` | 从随包模板生成脚手架（模板即回归语料） |
| `canvas_check` | `path` | 静态扫描 + 编译 + 抽取，返回 `CanvasDiagnostic[]`；**不渲染** |
| `canvas_read` | `path`, `brief`, `dataPath`, `filter`, `ids`, `limit`, `rowsKey`, `openStatuses` | 抽取 `DATA`、合并 sidecar、切片/过滤/截断，返回结构化 JSON + 统计 |
| `canvas_state_merge` | `path`, `key`, `ids`, `dryRun` | 把 sidecar 补丁最小化写回源文件并清除已合并条目 |

`canvas_read` 有三个设计点（前两条是设计，第三条是**跑真实对照时发现的缺陷**，已修）：

- **`brief: true` 的恢复摘要**：会话被截断或换 Agent 接手时，需要的不是全部数据，而是四个问题的答案——"要去哪 / 什么不能碰 / 什么已经定了 / 现在做什么"。摘要因此由 `goal`、`asOf`/`asOfAgeDays`/`revision`/`staleDays`、`constraints`、`decisions`（含**被否决的方案**）、`nextAction`、在办行（最多 20 条、12 个字段）、最近 3 条活动、以及一份 `notes` 一致性告警组成。
- **摘要必须诚实**：`notes` 会报告"没有 `nextAction`""`nextAction` 指向已关闭的行""`dependsOn` 指向不存在的任务""重复 id""null 与仍有在办行矛盾"等。设计上把 `nextAction` 缺失与 `nextAction: null` 当作**两个不同的断言**：前者的意思是"无法判断哪一步最先"，后者是"确实没有在办事项"，并且后者会被拿去和在办行核对。
- **切片要真的只回那一支**（§6.4 实测的缺陷，已修）：`dataPath` / `ids` 原先只把目标支替换成过滤结果，返回体仍是整个 `DATA`——一行切片要背上所有兄弟键。现在只回 `{ [key]: rows, __counts, __overlays }`；标量键回标量；未知键报错并列出真实顶层键（不再静默回整包）。同一次对照还暴露了摘要的**形状假设**：行键写死为 `tasks`、锚点字段写死为 `taskId`，于是行叫 `claims` 的审计画布在接手路径上完全不可见，而且是**静默**失效（报 `0 in flight`，没有任何告警）。现在 `brief` 接受 `rowsKey` / `openStatuses`，无参时自动探测（要求每行有 string `id` 且带 `status`），并把"自动探测""词表不认识"变成显式 `notes`；锚点字段 `taskId` / `claimId` / `rowId` 都认。这两条都不在原始设计里，是**把新范式真的跑一遍**才逼出来的（§7.2）。

### 4.8 意图入口：在 `agent/pre-step` 上挂一个 intake

实测教训是：画布的质量几乎完全由"写之前有没有对齐口径"决定；没有入口时，Agent 倾向于直接产出一个只有标题与状态的薄看板。因此 host 在 `agent/pre-step` 上注册了一个意图入口：

- **命中规则**：强名词（`看板/画布/画板/仪表盘/驾驶舱/kanban/dashboard`）无需动词即可命中；弱名词（18 个，如 `canvas`/`项目文档`/`审计报告`）必须被创建动词**治理**——动词须出现在名词前 12 个字符（中文）或 24 个字符（英文）窗口内；指代既有物的标记（`这张/现有/刚才/本仓/当前` 等 16 个）或路径样文本会抑制命中；
- **动作**：在进入步骤的消息批次末尾追加一条带 `source.kind = "dsh-canvas"` 的 user 消息，内容是 7 条对齐问题 + 产出顺序 + 指向 `references/intake.md` 的指针；
- **边界**：只匹配**人**说的内容（`source.kind === "user"`），且跳过 `rpcId` 以 `canvas-` 开头的消息——否则画布自己提交的任务会被当成建板请求再次触发 intake（这正是实现期真实发生过的噪音）；
- **它自己的异常一律放行**：hook 失败只 `console.warn` 一次，原始决策原样返回，绝不破坏 step。

一个刻意的取舍：注入文本**不再复制**质量门槛。设计文档记录了这次收缩（985 → 845 字符），理由是"第二份契约一定会漂移，而这一份已经漂了"（锚点块加进了 `intake.md` 却没加进注入文本）。

![图 5　意图入口在 `agent/pre-step` 上的判定链：五道门，任何一道不过就原样放行](figures/fig-intent.png)

### 4.9 客户端套件：语义 tone，零 CSS

套件导出 25 个组件（`Stack/Row/Grid/Divider/CollapsibleSection/H1/H2/H3/Text/Code/Card/CardHeader/CardBody/Callout/Stat/Table/BarChart/PieChart/HeatMatrix/TodoList/Progress/KeyValue/Timeline/Button/Pill`）与 10 个钩子（5 个 React 钩子 re-export + `useCanvasState`/`useCanvasOverlay`/`useCanvasAction`/`useHostTheme`/`useCanvasResource`）。设计约定：

1. **只认语义 `tone`（`neutral/info/success/warning/danger`），不认颜色**；颜色由宿主 token 解析，主题切换免费；
2. **不引用宿主 class 名**——样式全部是内联 `style` 对象 + CSS 变量（`--dsw-alias-*`、`--dsw-radius-*`、长写形式的 `--dsw-font-*-font-size`/`-line-height`）；
3. **只加不减**：套件 API 与画布文件长期共存于用户磁盘，删改签名会毁掉已存在的画布；弃用须先给渲染期信号，且至少两个 minor 版本后才移除；
4. **受控 + 无状态默认**：`active`/`open` 由调用方给（唯一例外是 `CollapsibleSection.defaultOpen`）；
5. **数组 prop 一律接受 `readonly T[]`**：因为 `as const` 产出只读字面量类型，否则**每一个**画布都得写双重类型转换。同一条纪律下还有两个"便宜的正确"：`Text` 默认是块级，行内强调必须写 `as="span"`；文字 tone 除语义五档外还接受 `primary/secondary/tertiary/quaternary/caption` 五个弱化档别名——**同名不同义的写法在套件里不允许静默降级**（`tone="primary"` 与 `tone="quaternary"` 曾经都静默落到同一档，本次一并修掉）。

主题切换不需要客户端代码：宿主整个 token 表由 `body[data-ds-dark-theme]` 切换，light/dark 在同一批主题表里。截断纪律也统一：`Table` 软上限 300 行 / 硬上限取 Config 的 `maxRenderRows`（默认 5 000），`BarChart` 40 个 category，`HeatMatrix` 16 列 × 24 行，超限一律显式提示 `showing N of M`——**截断不是虚拟化**，画布的正确用法本就是切片。

![图 6　套件全貌自检画布：25 个组件与全部钩子在同一张画布上（节选：Stat 指标、Callout、按阶段分组的 BarChart）](figures/fig-selfcheck.png)

> 该画布的 `DATA` 里写着"94 host assertions / 12 stages"——那是它写成时的数字，今天的实测是 9 个测试文件、489 处断言（§6.1）。这条差异本身就是 §7.3 的例证。

![图 7　`HeatMatrix` 两种 layout 共用一份数据：matrix（行 = 任务，列 = 轮次，保留时间维度）与 grid（一格一任务，面积 = 条目数）](figures/fig-heat.png)

### 4.10 安全模型

信任级别：**画布代码 = 插件代码**（都是写入并被执行的前端代码）。因此安全设计的重点不是"防住画布"，而是"把画布能碰到的东西收窄到最小"，并把**插件自己的特权面**收窄。

| 面 | 措施 |
|---|---|
| 模块 | 编译期只允许 `dsh/canvas`；产物 `__require` 反向兜底 |
| 网络/存储/DOM | 不注入 `fetch`/`localStorage`/`document`/`window`；静态扫描拦截 |
| 宿主进程 | `canvas_read` / `canvas_check` **绝不执行画布代码**（§4.4） |
| HTTP 入口 | 所有 POST 必须 `content-type: application/json`，否则 403——跨站页面只能发简单请求，逼它走预检，而本服务器不回应预检 |
| 路径 | **读放开、写钉在工作区根内**（ADR-0001）：`canvas_new`、`POST /canvas/overlay`、`overlaySet`/`overlayClear`、`canvas_state_merge` 五处写操作越界即拒 |
| 权威根 | `config.workspaceRoot` → 本请求的 session cwd → 记住的上次会话根 → 沙箱 policy 根；**写操作另外拒绝**落到 `process.cwd()`、只拿到 policy 根、或 exec 给的"工作目录"就是 `process.cwd()` 三种取值 |
| 命令 | 白名单 + 逐字匹配 + 调用方沙箱策略 + 120 s 默认超时 |
| 提权 | 画布无权请求提权；`denied` 只能由人另行操作 |
| 资源耗尽 | 体积/行数硬阈值、渲染行数上限、`startTurn` 限流 |

路径策略的**不对称**是被明确记录的代价（"将来若要给读加限制，那是破坏性变更"），而"写操作拒绝歧义根"这条则是**两次真实事故**换来的：Desktop 应用的 `ctx.sandboxPolicy.workspaceRoot` 与 `process.cwd()` 都是**应用数据目录**（实测为 `profiles/desktop`），`canvas_new` 曾把看板建到 `profiles/desktop/canvases/` 下。**残留风险**同样明确：画布代码可以在浏览器里做任意计算（死循环、吃内存），只能靠渲染上限与页面可恢复性缓解，不引入 iframe/Worker 隔离。

---

## 5 Agent 侧协议：怎么写、怎么读、怎么接手

宿主提供了机制，但机制不会自己产生好画布。因此本插件把"用法"也当作交付物：一个 skill（`SKILL.md` + 5 份 references + 3 个模板）。

**（1）判定该不该用画布。** 需要**同时**满足两条：*多项状态*（一批各自带状态的条目，而不是一条结论）与*多次更新且人需要下钻*。不满足时的路由是明确的：单条结论写在回复里，短任务用 `todo_write`，"要不要继续下一轮"用 `goal`，append-only 日志用普通文件，纯数据交付用 JSON/CSV。

**（2）六步流程。** 0 做 intake（7 问，每问带可用默认值）→ 1 `canvas_new` 建脚手架（不手写空文件，否则丢元数据头与 `DATA` 形状）→ 2 **先只填 `DATA`**（不动渲染代码）→ 3 需要时才改渲染 → 4 `canvas_check` 自检 → 5 打开看一眼。第 5 步不是形式：`canvas_check` 只做语法转换，看不到作用域重复声明、TDZ，也看不到渲染期截断。

**（3）"保持小"的四条纪律。** `DATA` 是唯一允许长大的部分，渲染代码超 ~400 行就该拆；只内联"当前窗口"（未完成 + 最近完成）；`note` 类字段超过 ~120 字符改成引用（`crates/x.rs:306` 或"见 T-323"）——"粘贴是文件膨胀的唯一原因"；软阈值命中当成必须处理的信号，不是噪音。

**（4）读的纪律。** 规范循环是：`canvas_read(path, "tasks", {status:"pending"})` 取要动的那些 → 干活 → 用普通文件编辑改那几条 → `canvas_check` 自检。**只有需要改版式时才读源文件的渲染部分。**

**（5）接手的纪律。** 上下文被截断后：先 `canvas_read(path, brief:true)`，再按 `nextAction.taskId` 读那一条，动手前跑门禁画布。`resume.md` 还规定了写回纪律：先读后写、只改自己的行、人的裁决走 overlay、新增决定要连"被否决的方案"一起记、收尾时更新 `asOf`/`revision`/`nextAction`。

其中"上下文锚点"（`constraints` / `decisions` / `nextAction`）是这套协议里最有价值的部分：跟踪字段回答"现在在哪"，锚点回答"**能不能接手**"——红线是什么、什么已经定了（含否决过的方案，防止重新讨论）、全局唯一的下一步是什么。

---

## 6 评估

### 6.1 方法与装置

本文的评估是**工程级评估**，由四类证据组成：

1. **回归测试**：`node --test test/*.test.mjs`，9 个文件全部通过（实测约 0.5–1.8 s），`test/` 下共 489 处 `assert` 引用。测试覆盖编译器与诊断码、HTTP 面与动作桥、模板语料、套件注册与主题 token、**导出面双向校验**（`host/kitsurface.js` ↔ `lib/client.js` 发布的 `kit`，只在一侧加组件会失败）、真实渲染（递归求值编译产物并断言派生分析的数值）、最小回写（字节级不变性）、意图匹配、恢复摘要、工具定义与写路径越界。
2. **测量脚本**：[measure.mjs](measure.mjs)（本仓新增，可复现）直接调用**真实**的 `host/compile.js` 与 `index.js` 的 `toolDefinitions`，测量语料健康、编译延迟与 `canvas_read` 的上下文成本。本文所有性能与成本数字均出自它，不手抄。
3. **真实环境验收**：项目自己的看板（[board.canvas.tsx](../../board.canvas.tsx)，685 行）把每条验收写成一行数据，带 `evidence`（文件:行 / 测试名 / 运行号）。
4. **真实渲染产物**：`docs/preview/render.mjs` 用真编译管线 + 真套件把画布序列化成 HTML（React 被桩替换），再由 `docs/paper/figures/shoot.py` 用无头 Chrome 截成图 6、7、9–14。

测量环境：Windows，Node v24.12.0，单机单进程；`N=50`（预热 5 次后测量）。

### 6.2 语料与正确性

本仓内共 10 张画布（含 4 个随包模板），**10/10 编译零 error 零 warning**：

| 画布 | 行数 | 字节 | `DATA` | 结果 |
|---|---|---|---|---|
| `board.canvas.tsx`（本仓项目看板） | 685 | 43 561 | 20 221 | clean |
| `gates.canvas.tsx`（门禁看板） | 241 | 8 577 | 396 | clean |
| `canvases/project-board.canvas.tsx` | 538 | 27 652 | 5 299 | clean |
| `canvases/board.canvas.tsx` | 530 | 27 107 | 5 299 | clean |
| `canvases/heat.canvas.tsx` | 48 | 2 168 | 1 052 | clean |
| `examples/selfcheck.canvas.tsx`（套件全貌自检） | 235 | 11 045 | 3 035 | clean |
| `skills/.../templates/board.canvas.tsx` | 539 | 27 668 | 5 299 | clean |
| `skills/.../templates/gates.canvas.tsx` | 267 | 9 076 | 703 | clean |
| skills/.../templates/blank.canvas.tsx | 74 | 2 333 | 239 | clean |
| `skills/.../templates/audit.canvas.tsx`（审计范式骨架） | 362 | 15 587 | 3 735 | clean |

模板语料是**回归契约**：随包模板会被 `canvas_new` 直接交给 Agent，所以测试要求它们永远能编译、必须带 `hidden: true`（模板不是活画布，不该出现在每个工作区的画布目录里），看板模板的每一条必须带 16 个必需字段；审计模板必须声明参照物与口径（`reference.kind` 四取值之一 + `detects` / `cannotDetect`）、声明自己的行键与状态词表（`rowsKey` / `openStatuses`），并且每条断言都要带判据级别、对照物 `文件:行` 与 `doneWhen`、以及测量轮次与口径。这张表也提供了一个正面证据：**最大的真实画布（43.6 KB / 685 行）仍在软阈值（128 KB / 1 500 行）之内**，说明阈值没有把正常使用判成病态。

### 6.3 性能：编译与缓存

| 路径 | min | median | p95 | max | mean（ms，N=200） |
|---|---|---|---|---|---|
| 冷编译（扫描 + sucrase + 抽取 + 包装） | 2.46 | **4.13** | 7.06 | 8.18 | 4.24 |
| 仅 sucrase 变换 | 1.22 | 1.81 | 3.83 | 5.06 | 2.12 |
| 内容哈希命中（不编译） | 0.050 | **0.077** | 0.140 | 0.434 | 0.085 |

对照设计预算（单文件编译 < 50 ms），最大画布的冷编译中位数约 4 ms（多次运行落在 3.6–4.8 ms），**余量约 12 倍**；而保存时的常见路径（内容未变）只需 0.077 ms，即设计里"未变化的保存不触发重编译"的承诺在数值上成立。**中位数的运行间波动**：另两次同样 N=200 的运行给出 4.19 ms 与 4.76 ms（改动前一次 N=50 的运行是 3.93 ms），即单机测量下中位数在 **3.9–4.8 ms** 之间浮动（本机同时跑其它任务时偏高）——所以本文引用的都是量级，不把它当精确常数。这也解释了为什么 `compileTimeoutMs`（2 000 ms）在实测中不可能被触发——顺带暴露一个**文档与实现的不一致**：该配置项被定义、被配置、被 `/canvas/api` 发布、也被 README 描述为"超出拒绝编译"，但实现里**没有任何计时器或竞态围着 `transform`**，因此它目前是装饰性的（§8 列为已知缺陷）。

**未测量**：设计文档给出的"保存 → 面板更新 < 400 ms""首次打开 < 300 ms""每画布 ≤ 18 MB"三项预算，需要 GUI 侧埋点或浏览器性能剖面，本文没有采集，故不作断言。

### 6.4 上下文成本：拆开看才诚实

以本仓最大的画布（`board.canvas.tsx`，源文件 36 476 字符）为对象，测量 `canvas_read` 各切片的**实际返回体**：

| 读法 | 字符 | 占源文件 | 行数 | 说明 |
|---|---|---|---|---|
| `brief: true`（工具实际返回，2 空格缩进） | 3 703 | **10.2%** | — | 恢复摘要 |
| `brief` 的紧凑序列化（无缩进） | 2 739 | **7.5%** | — | 摘要本身的体积 |
| `DATA`（不切片，含 `__overlays`） | 20 947 | 57.4% | 16 | "全文重读"的等价物 |
| `dataPath: "tasks"` | 11 385 | 31.2% | 16 | 只回这一支（修前 21 025 / 57.6%） |
| `dataPath: "tasks"` + `filter {status:"in_progress"}` | 1 036 | **2.8%** | **1** | 修前 10 676 / 29.3%，见下面的分解 |
| `dataPath: "tasks"` + `ids: ["R-04"]` | 1 036 | **2.8%** | 1 | 同上 |
| `dataPath: "activity"` + `limit: 5` | 1 173 | **3.2%** | 16 | 修前 15 041 / 41.2% |
| `dataPath: "prohibitions"`（不存在的键） | 0 | — | — | `ok:false` + 列出真实顶层键（修前静默回整包 20 947） |

**把修前那一行拆开量**（`ids:["R-04"]` 的 10 676 字符）：**请求的那一行自身只占 831 字符（7.8%）**，`tasks` 之外的兄弟键（`activity` / `constraints` / `decisions` / `lanes` …）占 **8 794（82.4%）**，其余（`__overlays`、`__counts`、缩进差）1 051（9.8%）。

⇒ **成本主因是"信封里其它键照旧随行"，不是行宽。** 修前的 `canvas_read` 把 `dataPath` / `ids` 只当作"替换目标支"：返回体仍是整个 `DATA`（`index.js:895-897`、`:923`），给一个不存在的键时既不报错也不裁剪，静默返回整个 `DATA`。

**这一条已修**（同一次对照还修了 `brief` 的行键假设，见 §4.7）。修后实测：

| 读法 | 修前 | 修后 |
|---|---|---|
| 看板 `dataPath:"tasks"` + `ids:["R-04"]` | 10 676 | **1 036**（其中 831 是那一行本身，信封开销降到 205） |
| audit 画布 `dataPath:"claims"` + `filter {status:"未修"}` | 8 754 | **6 006** |
| `dataPath` 给不存在的键 | 静默回整包 20 947 | `ok:false` + 列出真实顶层键 |
| audit 画布 `brief` 的在办行 | `focus 0`（静默） | `focus 8`（显式 `rowsKey`/`openStatuses`），无参时自动探测并给出 note |

该结论与勘误 E-05 一并记在 [docs/audit/interface-audit.canvas.tsx](../audit/interface-audit.canvas.tsx)（断言 C-10 / C-11 已由「未修」变为「已核对」）。

![图 8　同一张画布的读取成本实测：摘要把接手成本压到 7.5%，而修前的行切片仍占 29.3%——其中 82% 是随行的兄弟键；修后 1 行切片降到 2.8%](figures/fig-context.png)

逐画布的摘要体积（紧凑序列化 / 源文件）：

| 画布 | 源文件字符 | `DATA` 字符 | 摘要字符 | 摘要/源文件 |
|---|---|---|---|---|
| `board.canvas.tsx` | 36 476 | 15 647 | 2 739 | **7.5%** |
| `canvases/project-board.canvas.tsx` | 23 658 | 3 957 | 2 181 | 9.2% |
| `canvases/board.canvas.tsx` | 23 343 | 3 957 | 2 181 | 9.3% |
| `examples/selfcheck.canvas.tsx` | 10 801 | 3 021 | 756 | 7.0% |
| `gates.canvas.tsx` | 7 470 | 384 | 212 | **2.8%** |
| `canvases/heat.canvas.tsx` | 2 054 | 1 052 | 346 | 16.8% |
| 模板 `board` / `gates` / `blank` / `audit` | 23 674 / 7 939 / 1 991 / 12 268 | — | 2 181 / 212 / 347 / 702 | 9.2% / 2.7% / 17.4% / 5.7% |

**结论必须分路径陈述，否则就是过度声称：**

1. **摘要路径成立**：`brief` 是源文件的 2.7%–17.4%（下限是门禁看板，上限是没有 `nextAction`/红线、因而固定开销占比高的小画布），且测试对它有硬契约（摘要 JSON < 6 144 字符、单测场景 < 4 096 字符）。这是"上下文成本与文件大小脱钩"最实在的落点——接手时读 ≈3 KB 而不是 36 KB。
2. **行切片路径只部分成立，但原因不是行宽**：`ids:["R-04"]` 仍返回 10 676 字符（源文件的 29.3%），而请求的那一行自身只有 831 字符——**82.4% 是随行的兄弟键**。`dataPath` / `ids` 只裁目标那一支，不缩小信封：切片省掉的是"目标支里的其它行"，省不掉"其它支"。这把改进方向从"字段投影"改成了**收窄返回体**——前者是锦上添花，后者才是量级修复（审计条目 C-10）。
3. **不切片就是全文**：`DATA` 占源文件 57.4%——`DATA` 确实是文件的主体，反过来说，渲染代码的复用让"数据即文件"这个设计意图在体积分布上成立。
4. `limit` 只截数组长度，因此 `activity limit=5` 仍返回 15 041 字符（16 行的活动数组里每行也带 `detail`/`ref`）——与上一条同源：被裁的只有目标支，`DATA` 的其余部分照旧随行。

### 6.5 真实环境验收

项目看板把验收写成数据行，以下是已闭环的项（原文摘要，`evidence` 指向可复核位置）：

| 编号 | 验收内容 | 证据 |
|---|---|---|
| V-01 | 真实 GUI 里渲染为画布而非文本预览 | Desktop 打开 `board.canvas.tsx` 渲染成功；进程 code cache 含 `dsh-app://app/plugins/@demxyuanli/dsh-canvas/client.js` |
| V-02 | 意图入口真实触发 | 用户说"给我建个项目看板" → host 注入 intake（`host/intent.js`）；**这张看板本身就是这样被建出来的** |
| V-03 | `runCommand` 在真实 `ctx.shell` 上跑通 | `gate:tests` → `exit=0`；`gate:templates` → `exit=0`（白名单登记在 profile patch） |
| V-04 | read-only 会话下的沙箱行为 | 会话切 read-only 后返回 `sandbox.mode=read-only`、`denied=false`；命令确实起了（`exit=1` 是受限模式禁止 spawn 管道的边界，不是被跳过） |
| V-05 | 无 Session 时的策略兜底 | 裁决为"不拒绝、按部署默认执行，但返回 `policy{source,reason}` 并在面板括注"；三条用例覆盖 session/deployment/无 sessionId |
| F-01 | `startTurn` 的真实请求形状 | `mode=queue` + 真实 `AbortSignal`；补了成功反馈（静默成功与坏按钮在体感上无区别） |
| F-02 | action 信封两端对齐 | 客户端断言请求体为 `{canvas, sessionId, action}`；host 兼容扁平形状 |
| F-03 | 意图入口不被画布自己的提交再次触发 | `rpcId` 前缀 `canvas-` 被忽略；`test/intent.test.mjs` |

一条方法论上的观察值得记录：**V-02 的验收对象就是承载验收记录的那张画布本身**（自举/dogfooding）。这既是最强的证据（工具真的被用于它声称的用途），也是最强的偏差来源（§8）。

### 6.6 缺陷分析：真实缺陷都出在"接缝"上

实现期（0.2.0）共记录 8 类真实缺陷，其中 6 类集中在**两个半边之间的接缝**，而不是任一半边内部：

| 缺陷 | 现象 | 根因 | 教训 |
|---|---|---|---|
| F-01 `startTurn` 无效 | 点"开始"没反应，返回 `{ok:false, code:"failed"}` | `prompt()` 第一行就 `signal.throwIfAborted()`，而客户端只传了一个参数；且 `mode` 是必填 | 跨包契约要对着**类型与实现的第一条语句**一起读 |
| F-02 action 信封不一致 | 所有按钮返回 `unsupported action undefined` | 客户端把 action **平铺**进 body，host 读的是 `body.action`；两个半边各自自洽，**接缝没人测** | 接缝要有测试；四条 host 动作此前**全部不可用** |
| F-03 意图入口自触发 | 画布提交的任务被要求重新做 intake | 提交的 prompt 里含"画布"，且 `source.rpcId` 未被检查 | 文本是自由格式，`rpcId` 才是可靠信号 |
| 路径事故（两次） | `canvas_new` 把文件建到 `profiles/desktop/canvases/` | 会话 cwd 嵌在 `agent.session.header.cwd`，只读扁平 `cwd` 会让**两条路径同时读不到根**，于是退到 policy 根 = 应用数据目录 | 写操作必须拒绝歧义根；"拿不到就拒绝，绝不猜" |
| 排版与主题 | 字号"有大有小"混乱、`Code` 用 UI 字体渲染 | 用了 `--dsw-font-mono`（主题里不存在）与**简写** font token（贴进 `font-size` 不报错、只是安静地不生效） | 契约要靠 token 的**长写形式**落地 |
| 滚动容器 | 长画布被裁掉且没有滚动条 | 宿主 tab body 是 `height:100% + overflow:hidden`，插件没有自己的滚动容器 | 不要假设宿主会给你滚动 |

另外两类是**自举使用中发现的产品缺陷**，价值很高：

- **摘要抓到自己的漂移**：V-04 完成后 `nextAction` 仍指向它，于是"接手时最先看的那一个字段"读起来像"去做这件已经做完的事"。修复不是改数据，而是给 `brief` 增加"`nextAction` 指向已关闭行"的告警——即**把一致性检查做进摘要本身**。
- **`null` 与缺失被混为一谈**导致摘要永久唠叨：`nextAction` 字段**缺失**意味着"无法判断"，而显式 `null` 意味着"确实没有在办事项"，后者应被拿去和在办行互相校验。

这两条把"摘要"从一个数据投影变成了一个**带自检的报告**，是本文认为最可迁移的一条工程经验。

![图 9　项目看板的活动时间线（节选）：每条带日期、tone、`ref` chip；F-01 / F-02 两条红点就是 §6.6 里那两个接缝缺陷的真实记录](figures/fig-board-activity.png)

### 6.7 效果

图 10–14 是真实渲染的截图：`docs/preview/render.mjs` 用 `host/compile.js` 编译真实画布、用 `lib/client.js` 的套件渲染成 HTML，再由 [shoot.py](figures/shoot.py) 用无头 Chrome 截取（2× 缩放、面板宽度 560 px，贴近右栏实际宽度）。生成命令见附录 A。

![图 10　项目看板（深色）· 概览与锚点：加权进度、四个现算指标、派生风险清单，以及 `nextAction` 的"现在该做"](figures/fig-board-overview.png)

![图 11　同一张画布的浅色主题：颜色全部来自宿主 token，画布代码没有一行 CSS](figures/fig-board-light.png)

![图 12　富字段详情与动作桥：验收 / 证据 / 改动 / 参考逐条列出；按钮把人的判断写回 sidecar，或把任务交回 Agent](figures/fig-board-detail.png)

![图 13　明细表与三个折叠区（约束与红线 / 已定决策 / 迭代热力）：折叠是控制画布体积的主要手段](figures/fig-board-table.png)

![图 14　门禁看板：每行一个 Run 按钮，执行走真实 `ctx.shell`（白名单 + 调用方沙箱策略），面板拿到真实退出码](figures/fig-gates.png)

![图 15　`PieChart`（环图）：这份对读的最后一个组件缺口补上后的实拍——三片按语义 tone 循环取色，中心是合计，图例带数值与占比](figures/fig-piechart.png)

图 15 是本次"与 Cursor Canvas 对读"的直接产物：对读发现套件缺 `PieChart`，补上后它立刻进了自检画布（`examples/selfcheck.canvas.tsx` 的「Kit surface share」区块），所以"25 个组件同屏"这句话仍然成立。它的两条套件纪律也体现在图里——颜色只取语义 tone（未给 tone 时五档循环，保证相邻不同色），以及上限**不静默隐藏数据**（超出 `maxSlices` 的尾部折成一片「其他」并注明折了几项）。

图 10 中最能说明设计意图的三个细节：(a) 每个数字都是**现算**的（加权进度按估算人日而非条目计数、按 `asOf` 计算的陈旧天数、WIP 超限、超估算），没有手抄的结论；(b) 三个锚点块齐备——`constraints`（红线，带"违反了会怎样"）、`decisions`（已定，含被否决的方案）、`nextAction`（全局唯一下一步）；(c) **证据落在富字段详情里**（图 12 的「证据 / 改动 / 参考」三行，`evidence` 用等宽 chip 指向真实运行与文件），明细表（图 13）是扫描视图。图 14 的门禁表刻意保留"基线 / 最近"两列——否则回归不可见。

**两条关于截图的诚实说明**：① `render.mjs` 用桩替换 React（只保留 `createElement` 与钩子），图上没有宿主外壳（侧栏、tab 栏）是有意的——这些是**面板主体**，不是伪造的 UI。② 截图步骤此前没有随仓提交（README 的 PNG 无法仅凭仓库复现），现已由 [shoot.py](figures/shoot.py) 关闭：它跑同一套 HTML，同时产出论文用的裁切版与完整高度的原图（如项目看板 1120×8557，见 `docs/paper/figures/shot-*.png`）；README 引用的 `docs/preview/*.png` 保持原样未被覆盖。

---

## 7 讨论

### 7.1 什么被证明，什么只是被实现

把三类断言的强度分开，是本项目内部最反复出现的纪律：

- **被证明的**（有机器可复核的证据）：编译器与诊断码行为、HTTP 面与动作信封、写路径越界拒绝、最小回写的字节级不变性、摘要体积上限、编译与缓存延迟、语料 10/10 零诊断；
- **被人工观察的**（一次性事实，可能随时间失效）：真实 GUI 里的渲染、意图入口在真实会话里触发、read-only 会话下 `runCommand` 的沙箱模式；
- **只被设计、未验证的**：`compileTimeoutMs` 的实际生效（实现缺失）、保存→渲染端到端延迟与内存预算、以及"画布是否真的让 Agent 更省 context"这一**因果主张**——本文只测到"同样的信息可以用 2.7%–10.6% 的体积取得"，没有测"Agent 因此表现得更好"。

### 7.2 可迁移的经验

1. **产物要"能编译"**：可编译意味着可静态检查、可回归测试、可自检。画布之所以能在 Agent 写错时立刻给出行列号与修法，是因为它是代码而不是文档。
2. **内联数据的正确解法是"宿主侧静态抽取"，不是"禁止内联"**。约束用户写法（纯字面量）换来两种读取方式并存，这个交换是划算的——前提是**宿主永不执行 Agent 的代码**。
3. **人的状态改动必须 staged**：直接改源文件会带来并发与 diff 破坏，只写本地存储则 Agent 看不见。"sidecar + 最小回写 + 陈旧/孤儿标记"是三选一之外的第四种，也是唯一同时满足"可回滚、可追溯、agent 可见"的。
4. **证据必须来自真实执行**：把门禁按钮接到真实 `ctx.shell` 并回传退出码，比任何"我跑过了"的叙述都便宜且可靠。
5. **接缝比半边更需要测试**：本文 8 类缺陷中 6 类在接缝上，而两侧的单测当时都是绿的。
6. **摘要要带自检**：一个只做投影的摘要会把过期锚点当成指令；把一致性告警做进摘要，是让"接手"这件事变可靠的最低成本手段。
7. **规范不跑一遍就是死的**：本文的第五类范式（审计）落进规范之后，我们用它产出了一份真实审计并跑了 `brief`——才发现机制只认 tracker 形状：行键写死 `tasks`、锚点写死 `taskId`、切片返回整包信封。三处都**只在换一种产物时**暴露，而且全是静默失效（`0 in flight`、整包返回）。**"规范 + 一份真实产物 + 一次真实读取"是发现这类缺口的最短路径**，比再写一遍文档有效得多。

### 7.3 反面经验：文档会漂移，且漂移是系统性的

实测发现的多处文档/实现不一致，本身就是一条结论：**同一份事实写两遍必然漂移**。例子包括（前两条在本文写作过程中已就地修掉，其余仍开放）：

- **已修**：README 声称测试是"8 个文件 / 94 断言"，写作时的实测已是 9 个文件 / 397 处；本文改动后为 **489 处**，README 同步改成了这个数；
- **已修**：`HeatMatrix` 在套件参考（kit.md）的规范 import 块里缺席——照文档抄的 import 会解析不到这个组件；本次把它与新增的 `H3`、`PieChart` 一起补进该块；
- **仍开放**：`index.js` 的注释与 JSDoc 说"三个模型工具"（实为四个）；`compileTimeoutMs` 文档说会拒绝编译（实现里没有计时器，§6.3）；`Divider` 的 `orientation` 文档写"无 props"而代码已实现；kit.md 说 `useCanvasState` 的键空间用"绝对路径的短哈希"而实现用的是完整路径；`examples/selfcheck.canvas.tsx` 的 `DATA` 里仍写着"94 host assertions / 12 stages"（图 6 的截图里可见），而当前是 437 处。

这条经验在本项目里已经被用过两次，都是同一个模式：**发现"第二份事实"以后，不要靠文档纪律维护它，而是用测试把它锚死**。第一次是注入文本不再复制质量门槛（§4.8），第二次就是本次的套件导出面——`host/kitsurface.js` 是第二份清单，`test/client.test.mjs` 双向校验它与 `lib/client.js` 实际发布的名字，只在一侧加组件会当场失败。

---

## 8 局限与威胁

**（T1）评估是单系统的工程评估。** 没有受控用户实验，没有跨项目、跨模型的对照；"画布比 markdown 更好"是设计论证 + 自举经验，不是统计结论。

**（T2）自举选择偏差。** 语料、验收记录与使用经验都来自同一批作者与同一个仓库（画布被用来管理画布自己的开发）。这使"可行"有强证据，但"可推广"证据弱。

**（T3）测量范围有限。** 延迟与体积在单机单进程测量；端到端交互延迟与内存上限未测；上下文成本以**字符数**衡量，未用真实 tokenizer 折算——对含中文与代码的混合文本，字符到 token 的比例不稳定，因此本文只给比例、不给 token 绝对值。

**（T4）行切片收益受限（已在 §6.4 报告）。** 单行切片仍占源文件近三成，但主因是**返回体不随切片收窄**（该行自身只占 7.8%）；收窄返回体是量级修复，字段投影是锦上添花。

**（T5）已知实现缺口。** `compileTimeoutMs` 未实现；旧 ESM 模块在长期会话中不可回收（只能提示重载）；无真正虚拟化（超限截断）；sidecar 可能陈旧（以 `staleOverlay`/`orphan` 暴露，由 Agent 决定是否固化）；路径容器检查是**路径前缀**级别、不解析符号链接，根内指向根外的链接仍可能被写入；`startTurn` 依赖 `sessionController` 存在。

**（T6）残留安全风险。** 画布代码可在浏览器内做任意计算（死循环/吃内存）；不引入 iframe/Worker 隔离，因此只能靠渲染行数上限与页面可恢复性缓解。信任级别等于插件代码，这是**明示**而非隐含。

**（T7）宿主耦合。** 插件依赖 DSH 的 slot/tab/resource/shell/sandboxPolicy 等接口与主题 token 命名；已通过"只用 `react` + 自建套件 + 少量稳定接口"降低耦合，但宿主接口变化仍会同时影响两个半边。

**（T8）外部相关工作的描述受网络限制**（§2 的资料来源限制），故 §2 只用于定位差异，不构成技术对比。

---

## 9 结论与未来工作

本文把 Agent 长任务的"对外产物"从散文换成了**可编译、可交互、可回写**的画布文件，并给出了使这个形态真正可用的三根支柱：**宿主侧不执行代码的静态数据抽取**（让内联数据同时可渲染、可切片）、**sidecar + 最小回写的 staged 写模型**（让人的判断对 Agent 可见且可固化）、以及**基于真实退出的证据链**。

在约 4.1 k 行实现与 10 张真实画布上，该形态通过了工程级验证：语料 10/10 零诊断；最大画布冷编译中位数约 4 ms（设计预算 50 ms），缓存命中约 0.08 ms；恢复摘要为源文件的 2.7%–10.6%；9 个测试文件 437 处断言全部通过；真实 GUI 上闭环了渲染、意图入口、白名单命令执行与沙箱策略透传四项验收。缺陷分析显示，真实缺陷集中在两个半边的**接缝**上，而这类缺陷在两侧单测全绿时完全不可见。

未来工作按优先级：

1. **补上未验证项**：实现 `compileTimeoutMs`；在 GUI 里埋点测"保存 → 面板更新"与内存上限，把设计预算变成实测数字。
2. **降低行切片成本**：给 `canvas_read` 增加字段投影（`fields`），让"取 1 行 3 个字段"成为可能，而不是取回整行 20 个字段。
3. **把一致性检查做深**：当前 `brief` 的 `notes` 已覆盖锚点悬空/指向已关闭行/重复 id 等；下一步可扩展到"`evidence` 指向的路径不存在""门禁结论过期（运行号早于最近一次改动）"。
4. **模块回收**：探索用可撤销的模块容器或 iframe 之外的方式回收旧 ESM，或在语义上把"旧模块累积"变成可见指标。
5. **跨仓画布与读限制**：如果要支持跨仓共享画布，需要重新裁决读的边界——按 ADR-0001，这将是**破坏性变更**，必须先补允许列表配置。
6. **因果评估**：设计一个跨任务、跨模型的对照实验，度量"使用画布 vs 使用 markdown"在任务完成率、轮次与 token 消耗上的差异——这是本文最想补上的一块证据。

---

## 参考文献

> 说明：写作环境无法访问外部网络全文（域名解析受限），以下条目的标题与 URL 来自检索元数据；ReAct 的 arXiv 编号经检索结果确认。本文未从这些来源推导任何实现细节。

[1] Yao S., Zhao J., Yu D., et al. ReAct: Synergizing Reasoning and Acting in Language Models. arXiv:2210.03629, 2022. https://arxiv.org/abs/2210.03629

[2] Cursor. Canvases（在编辑器中生成并交互的 Agent 画布）. 官方博客与更新日志：https://cursor.com/blog/canvas ；社区文档整理：https://deepwiki.com/cursor/cookbook/7.3-canvas-visualization-system

[3] Anthropic. Claude 发行说明（Artifacts：把模型产出的可交互片段放进侧栏）. https://support.claude.com/en/articles/12138966-release-notes

[4] Model Context Protocol. SEP-1865: MCP Apps — Interactive User Interfaces for MCP. https://modelcontextprotocol.io/seps/1865-mcp-apps-interactive-user-interfaces-for-mcp

[5] Portal UX Agent: A Plug-and-Play Engine for Rendering UIs from Natural-Language Specifications. arXiv:2511.00843. https://browse-export.arxiv.org/pdf/2511.00843

[6] SpecifyUI: Supporting Iterative UI Design Intent Expression through Structured Specifications and Generative AI. arXiv:2509.07334. https://browse-export.arxiv.org/pdf/2509.07334

[7] Towards a Working Definition of Designing Generative User Interfaces. https://arxivlens.com/paperview/details/towards-a-working-definition-of-designing-generative-user-interfaces-5061-4d26d63d

[8] Claude Code 工具参考（Agent 与任务工具，含计划类工具）. https://code.claude.com/docs

[9] 本仓 `canvas` skill 的公开索引（用于对照"画布"作为 Agent skill 的形态）. https://skillsauth.com/skills/doesitscript/canvas

---

## 附录 A　可复现产物

本文所有数字与图均由仓库内脚本产生，命令如下（在仓库根执行）：

| 目的 | 命令 | 产物 |
|---|---|---|
| 回归测试（9 文件 / 489 处断言） | `npm test` | 退出码 0（约 0.5–1.8 s） |
| 本文的实测数据（语料 / 延迟 / 上下文成本 / 规模） | `node docs/paper/measure.mjs` | 控制台报告；`--json` 输出机器可读报告 |
| 框图（图 1–5、图 8） | `python docs/paper/figures/diagrams.py` | `docs/paper/figures/fig-*.png`（Pillow 直绘；`box()` 会在内容超出方框时打印 OVERFLOW） |
| 截图（图 6、7、9–14） | `python docs/paper/figures/shoot.py` | 全高原图 `shot-*.png` + 论文用裁切版 `fig-*.png`（无头 Chrome，2× 缩放） |
| 中间 HTML（真编译 + 真套件） | `PREVIEW_WIDTH=560 THEME=dark node docs/preview/render.mjs <canvas>` | `docs/preview/*.html`（被 gitignore） |
| Word 版 | `python docs/paper/build_docx.py` | `docs/paper/paper.docx`（图按正文栏宽自动缩放并限高） |
| 画布自检 | `canvas_check`（宿主工具） | `CanvasDiagnostic[]` |

## 附录 B　设计文档索引

| 文档 | 内容 |
|---|---|
| [DESIGN.md](../../DESIGN.md) | 决策记录（D1–D4）、套件 API、实施计划、风险登记册 R1–R10、§21–§31 的修订记录（含两次路径事故的取证） |
| [INTERFACE.md](../../INTERFACE.md) | host↔client 冻结契约：HTTP 面、动作分工、套件导出面、信任边界 §3.1、`runCommand` 结果形状 §4.1 |
| [CONTEXT.md](../../CONTEXT.md) | 术语表（画布 / 看板 / 模板 / 实例 / 草稿 / 锚点 / overlay / 固化 / hidden） |
| [docs/adr/0001-path-policy-writes-only.md](../adr/0001-path-policy-writes-only.md) | 路径策略 ADR：读放开、写钉在工作区根内，含四个备选方案与三条后果 |
| [skills/canvas/SKILL.md](../../skills/canvas/SKILL.md) | Agent 侧协议：判定、六步流程、保持小的纪律、读的纪律、接手纪律、反模式 |
| [skills/canvas/references/intake.md](../../skills/canvas/references/intake.md) | intake 契约：7 问、字段清单、三个锚点、回执模板、产出顺序、质量门槛 |
| [skills/canvas/references/resume.md](../../skills/canvas/references/resume.md) | 接手契约：四步读法、陈旧判定、写回纪律 |
| [skills/canvas/references/kit.md](../../skills/canvas/references/kit.md) | 套件完整 API（25 组件 + 10 钩子）与排版 token 表 |
| [skills/canvas/references/patterns.md](../../skills/canvas/references/patterns.md) | 四类范式：看板 / 门禁 / 时间线 / 对比 |
| [skills/canvas/references/troubleshooting.md](../../skills/canvas/references/troubleshooting.md) | 诊断码逐条修法、安装验证、read-only 门禁边界、`canvas_check` 的盲区 |
| [docs/canvas-kit-comparison.md](../canvas-kit-comparison.md) | 与一份真实 Cursor Canvas 源码的逐项对读（组件面 / 钩子面 / 契约级差异），含改动前后的实测输出 |
| [docs/cursor-canvas-migration.md](../cursor-canvas-migration.md) | 迁移指南：三条硬约束、三步迁移、会静默改变行为的清单；其 before/after fixture 由 `templates.test.mjs` 锚定 |
| [board.canvas.tsx](../../board.canvas.tsx) | 项目自身的看板（§6.5 的验收记录即它的 `DATA`） |
