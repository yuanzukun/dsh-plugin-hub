"""Screenshot the real canvas pipeline into docs/paper/figures/.

Every figure comes from the repo's own preview harness, never a mock:
docs/preview/render.mjs compiles the canvas with the real host/compile.js and
renders it with the real lib/client.js kit; this script then screenshots the
resulting HTML with headless Chrome. The PNG step was the one part of the
README's figure story that was never committed -- this closes it.

    python docs/paper/figures/shoot.py                 # every shot below
    python docs/paper/figures/shoot.py --only heat     # one canvas

Per shot it writes
    shot-<stem>[-dark].png   full-height capture (artifact, 2x)
    fig-<name>.png           crop sized for a page-width A4 figure
    _qa/<name>@qa.png        downscaled copy for eyeballing
"""
import argparse
import os
import shutil
import subprocess
import sys

from PIL import Image, ImageChops

ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", ".."))
FIGDIR = os.path.join(ROOT, "docs", "paper", "figures")
QADIR = os.path.join(FIGDIR, "_qa")
PREVIEW = os.path.join(ROOT, "docs", "preview")
NODE = shutil.which("node") or "node"
CHROME = next((p for p in [
    r"C:\Program Files\Google\Chrome\Application\chrome.exe",
    r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
    r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
    r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
] if os.path.exists(p)), None)

SCALE = 2     # device-scale-factor -> 2x pixels for print
TALL = 7400   # initial viewport height in CSS px; grown if content hits the bottom
PAD = 24      # uniform margin added around every cropped figure (2x px)

# canvas, theme, panel width (CSS px), crops [(figure name, top px, height px)]
# A4 usable height at page width needs aspect (h/w) <= ~1.35, i.e. crop height
# <= ~1.35 * width * SCALE, which is why the crops below are ~1500 px tall.
SHOTS = [
    ("board.canvas.tsx", "dark", 560, [
        ("board-overview", 0, 1500),
        ("board-detail", 1500, 1500),
        ("board-table", 2300, 1500),
        ("board-activity", 5000, 1500),
    ]),
    ("board.canvas.tsx", "light", 560, [
        ("board-light", 0, 1500),
    ]),
    ("gates.canvas.tsx", "dark", 560, [
        ("gates", 0, 1500),
    ]),
    ("examples/selfcheck.canvas.tsx", "dark", 560, [
        ("selfcheck", 0, 1500),
    ]),
    # The heat matrix is wider than the 560 px sidebar, so it gets a wider panel
    # or its left column is clipped.
    ("canvases/heat.canvas.tsx", "dark", 820, [
        ("heat", 0, 1050),
    ]),
]


def stem_of(canvas):
    rel = os.path.relpath(os.path.join(ROOT, canvas), ROOT).replace("\\", "/")
    return rel[: -len(".canvas.tsx")].replace("/", "-")


def render_html(canvas, theme, width):
    env = dict(os.environ, PREVIEW_WIDTH=str(width), THEME=theme)
    proc = subprocess.run([NODE, os.path.join(PREVIEW, "render.mjs"), canvas],
                          cwd=ROOT, env=env, capture_output=True, text=True)
    if proc.returncode != 0:
        raise RuntimeError("render.mjs failed for %s: %s" % (canvas, proc.stderr.strip()[:400]))
    return os.path.join(PREVIEW, "%s%s.html" % (stem_of(canvas), "" if theme == "light" else "-dark"))


def shoot(html, png, width, height):
    cmd = [CHROME, "--headless=new", "--disable-gpu", "--hide-scrollbars",
           "--force-device-scale-factor=%d" % SCALE,
           "--window-size=%d,%d" % (width, height),
           "--screenshot=" + png, "file:///" + html.replace("\\", "/")]
    subprocess.run(cmd, capture_output=True, text=True)
    if not os.path.exists(png):
        raise RuntimeError("chrome produced no file for " + html)


def trim(path):
    """Crop trailing background. Returns (size, content_reached_bottom)."""
    with Image.open(path) as im:
        rgb = im.convert("RGB")
        w, h = rgb.size
        bg = rgb.getpixel((5, 5))
        diff = ImageChops.difference(rgb, Image.new("RGB", (w, h), bg)).convert("L")
        box = diff.point(lambda v: 255 if v > 6 else 0).getbbox()
        if box is None:
            return rgb.size, False
        crop = rgb.crop((0, 0, min(w, box[2] + 24), min(h, box[3] + 24)))
        crop.save(path)
        return crop.size, box[3] >= h - 2


def save_thumb(path, name):
    os.makedirs(QADIR, exist_ok=True)
    with Image.open(path) as im:
        im = im.convert("RGB")
        w, h = im.size
        if h > 1400:
            im = im.resize((max(1, int(w * 1400 / h)), 1400), Image.LANCZOS)
        im.save(os.path.join(QADIR, name))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--only", default=None, help="substring filter on the canvas path")
    args = ap.parse_args()

    if CHROME is None:
        print("no chrome/edge found", file=sys.stderr)
        return 2
    os.makedirs(FIGDIR, exist_ok=True)

    for canvas, theme, width, crops in SHOTS:
        if args.only and args.only not in canvas:
            continue
        html = render_html(canvas, theme, width)
        stem = "shot-%s%s.png" % (stem_of(canvas), "" if theme == "light" else "-dark")
        full = os.path.join(FIGDIR, stem)
        height = TALL
        for _ in range(3):
            shoot(html, full, width, height)
            size, at_bottom = trim(full)
            if not at_bottom:
                break
            height = int(height * 1.5)
        print("%-40s %s" % (stem, "%dx%d" % size))
        save_thumb(full, os.path.splitext(stem)[0] + "@qa.png")

        with Image.open(full) as im:
            rgb = im.convert("RGB")
            w, h = rgb.size
            bg = rgb.getpixel((5, 5))
            for name, top, ch in crops:
                box = (0, min(top, h - 1), w, min(top + ch, h))
                piece = rgb.crop(box)
                # The preview HTML has no panel padding of its own, so glyphs sit
                # flush on the edge. Give every figure a small uniform margin.
                fig = Image.new("RGB", (piece.width + 2 * PAD, piece.height + 2 * PAD), bg)
                fig.paste(piece, (PAD, PAD))
                out = os.path.join(FIGDIR, "fig-%s.png" % name)
                fig.save(out)
                save_thumb(out, "fig-%s@qa.png" % name)
                print("   -> fig-%-22s %s" % (name + ".png", "%dx%d" % fig.size))
    return 0


if __name__ == "__main__":
    sys.exit(main())
