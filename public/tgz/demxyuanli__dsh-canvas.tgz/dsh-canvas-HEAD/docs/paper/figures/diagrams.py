"""Block diagrams for docs/paper/paper.md -- drawn with Pillow, no mock screenshots.

    python docs/paper/figures/diagrams.py

Writes fig-lifecycle / fig-architecture / fig-pipeline / fig-sidecar / fig-intent
/ fig-context into docs/paper/figures/. Every structure drawn here comes from the
code and docs in this repo; the only numbers are the latency and context-cost
annotations, which come from docs/paper/measure.mjs. box() prints an OVERFLOW
warning whenever its content is taller than the box, so a bad layout fails loudly
here instead of silently clipping in the PDF.
"""
import os
import re

from PIL import Image, ImageDraw, ImageFont

OUT = os.path.dirname(os.path.abspath(__file__))
FDIR = r"C:\Windows\Fonts"
F_REG = os.path.join(FDIR, "msyh.ttc")
F_BOLD = os.path.join(FDIR, "msyhbd.ttc")
F_MONO = os.path.join(FDIR, "consola.ttf")

INK = (28, 32, 38)
BODY = (58, 64, 74)
MUTED = (104, 112, 124)
LINE = (120, 128, 140)
WHITE = (255, 255, 255)
ROSE = (198, 74, 96)
GREEN = (38, 140, 90)

PALETTE = {
    "agent":   ((238, 235, 255), (122, 96, 214)),
    "human":   ((255, 238, 241), (198, 74, 96)),
    "file":    ((255, 247, 229), (190, 140, 30)),
    "host":    ((233, 241, 254), (58, 110, 200)),
    "client":  ((233, 247, 239), (38, 140, 90)),
    "neutral": ((245, 246, 248), (150, 157, 166)),
    "risk":    ((255, 236, 236), (198, 60, 60)),
    "info":    ((236, 246, 252), (46, 120, 170)),
    "ok":      ((233, 247, 239), (38, 140, 90)),
    "warn":    ((255, 246, 229), (190, 130, 20)),
}
PROBLEMS = []


class Fig:
    def __init__(self, w, h):
        self.im = Image.new("RGB", (w, h), WHITE)
        self.d = ImageDraw.Draw(self.im)
        self.w, self.h = w, h
        self._fonts = {}

    # ---------------------------------------------------------------- text
    def font(self, size, bold=False, mono=False):
        key = (size, bold, mono)
        if key not in self._fonts:
            path = F_MONO if mono else (F_BOLD if bold else F_REG)
            self._fonts[key] = ImageFont.truetype(path, size)
        return self._fonts[key]

    def text(self, x, y, s, size=25, bold=False, color=INK, anchor="la", mono=False):
        self.d.text((x, y), s, font=self.font(size, bold, mono), fill=color, anchor=anchor)

    def width(self, s, size=25, bold=False, mono=False):
        return self.d.textlength(s, font=self.font(size, bold, mono))

    def wrap(self, s, size, maxw, bold=False, mono=False):
        f = self.font(size, bold, mono)
        lines = []
        for para in s.split("\n"):
            line = ""
            for tok in re.findall(r"[A-Za-z0-9_\-./:+*<>=|\[\](){}@]+|\s+|.", para):
                trial = line + tok
                if self.d.textlength(trial, font=f) <= maxw or not line.strip():
                    line = trial
                else:
                    lines.append(line.rstrip())
                    line = "" if tok.isspace() else tok
            lines.append(line.rstrip())
        return [ln for ln in lines if ln != ""] or [""]

    def para(self, x, y, s, size=25, maxw=400, bold=False, color=INK, leading=None, mono=False,
             center=False):
        lead = leading or int(size * 1.42)
        lines = self.wrap(s, size, maxw, bold=bold, mono=mono)
        for i, ln in enumerate(lines):
            self.text(x + maxw / 2 if center else x, y + i * lead, ln, size=size, bold=bold,
                      color=color, anchor=("ma" if center else "la"), mono=mono)
        return y + len(lines) * lead

    def para_h(self, s, size, maxw, leading=None):
        lead = leading or int(size * 1.42)
        return len(self.wrap(s, size, maxw)) * lead

    # --------------------------------------------------------------- shapes
    def box(self, x, y, w, h, title=None, body=None, palette="neutral", radius=14,
            tsize=28, bsize=23, accent_left=False, title_color=None, pad=16, name=""):
        fill, stroke = PALETTE[palette]
        self.d.rounded_rectangle([x, y, x + w, y + h], radius=radius, fill=fill,
                                 outline=stroke, width=3)
        if accent_left:
            self.d.rounded_rectangle([x, y, x + 9, y + h], radius=4, fill=stroke)
        cy = y + pad
        if title:
            cy = self.para(x + pad, cy, title, size=tsize, maxw=w - 2 * pad, bold=True,
                           color=title_color or INK) + 4
        if body:
            cy = self.para(x + pad, cy, body, size=bsize, maxw=w - 2 * pad, color=BODY)
        if cy > y + h - 6:
            PROBLEMS.append("box %r content ends at %d, box bottom %d" % (name or title, cy, y + h))
        return (x, y, x + w, y + h)

    def container(self, x, y, w, h, label, stroke=(150, 157, 166), radius=18, dash_len=14):
        self.dashed_rect(x, y, x + w, y + h, stroke, dash_len=dash_len, radius=radius)
        lw = self.width(label, 24, bold=True) + 26
        self.d.rectangle([x + 20, y - 17, x + 20 + lw, y + 17], fill=WHITE)
        self.text(x + 33, y, label, size=24, bold=True, color=stroke)

    def dashed_rect(self, x0, y0, x1, y1, color, dash_len=14, radius=18):
        for x in range(int(x0) + radius, int(x1) - radius, dash_len * 2):
            self.d.line([(x, y0), (min(x + dash_len, x1 - radius), y0)], fill=color, width=3)
            self.d.line([(x, y1), (min(x + dash_len, x1 - radius), y1)], fill=color, width=3)
        for y in range(int(y0) + radius, int(y1) - radius, dash_len * 2):
            self.d.line([(x0, y), (x0, min(y + dash_len, y1 - radius))], fill=color, width=3)
            self.d.line([(x1, y), (x1, min(y + dash_len, y1 - radius))], fill=color, width=3)
        for cx, cy, start in ((x0 + radius, y0 + radius, 180), (x1 - radius, y0 + radius, 270),
                              (x0 + radius, y1 - radius, 90), (x1 - radius, y1 - radius, 0)):
            self.d.arc([cx - radius, cy - radius, cx + radius, cy + radius], start, start + 90,
                       fill=color, width=3)

    def dashed_line(self, p1, p2, color=LINE, width=2, dash=12, gap=9):
        (x1, y1), (x2, y2) = p1, p2
        total = ((x2 - x1) ** 2 + (y2 - y1) ** 2) ** 0.5
        if total == 0:
            return
        ux, uy = (x2 - x1) / total, (y2 - y1) / total
        t = 0.0
        while t < total:
            e = min(t + dash, total)
            self.d.line([(x1 + ux * t, y1 + uy * t), (x1 + ux * e, y1 + uy * e)],
                        fill=color, width=width)
            t = e + gap

    # --------------------------------------------------------------- arrows
    def _head(self, tip, direction, color, size=13):
        x, y = tip
        dx, dy = direction
        if dx and not dy:
            pts = [(x, y), (x - size * dx, y - size * 0.6), (x - size * dx, y + size * 0.6)]
        elif dy and not dx:
            pts = [(x, y), (x - size * 0.6, y - size * dy), (x + size * 0.6, y - size * dy)]
        else:
            pts = [(x, y), (x - size * dx - size * 0.5, y - size * dy + size * 0.5),
                   (x - size * dx + size * 0.5, y - size * dy - size * 0.5)]
        self.d.polygon(pts, fill=color)

    def arrow(self, p1, p2, color=(74, 82, 94), width=3, label=None, lsize=21,
              loff=(0, 0), dashed=False, bg=True):
        (x1, y1), (x2, y2) = p1, p2
        if dashed:
            self.dashed_line(p1, p2, color=color, width=width)
        else:
            self.d.line([p1, p2], fill=color, width=width)
        dx = 0 if x2 == x1 else (1 if x2 > x1 else -1)
        dy = 0 if y2 == y1 else (1 if y2 > y1 else -1)
        self._head((x2, y2), (dx, dy), color)
        if label:
            mx, my = (x1 + x2) / 2 + loff[0], (y1 + y2) / 2 + loff[1]
            tw = self.width(label, lsize)
            if bg:
                self.d.rectangle([mx - tw / 2 - 8, my - lsize * 0.82, mx + tw / 2 + 8,
                                  my + lsize * 0.72], fill=WHITE)
            self.text(mx, my, label, size=lsize, color=(64, 72, 84), anchor="mm")

    def path(self, pts, color=(74, 82, 94), width=3, dashed=False, label=None, lsize=21,
             lpos=None):
        for a, b in zip(pts, pts[1:]):
            if dashed:
                self.dashed_line(a, b, color=color, width=width)
            else:
                self.d.line([a, b], fill=color, width=width)
        (x1, y1), (x2, y2) = pts[-2], pts[-1]
        dx = 0 if x2 == x1 else (1 if x2 > x1 else -1)
        dy = 0 if y2 == y1 else (1 if y2 > y1 else -1)
        self._head((x2, y2), (dx, dy), color)
        if label and lpos:
            tw = self.width(label, lsize)
            self.d.rectangle([lpos[0] - tw / 2 - 8, lpos[1] - lsize * 0.82,
                              lpos[0] + tw / 2 + 8, lpos[1] + lsize * 0.72], fill=WHITE)
            self.text(lpos[0], lpos[1], label, size=lsize, color=(64, 72, 84), anchor="mm")

    def save(self, name):
        path = os.path.join(OUT, name)
        self.im.save(path)
        bad = [p for p in PROBLEMS]
        print("wrote %-26s %dx%d%s" % (name, self.w, self.h,
                                       "" if not bad else "   <-- " + " | ".join(bad)))
        PROBLEMS.clear()


# --------------------------------------------------------------------------
def lifecycle():
    f = Fig(1500, 1000)
    f.para(50, 26, "画布的人机闭环：Agent 写结论，人写判断，源文件是唯一持久真相", size=32,
           maxw=1400, bold=True)
    w, h = 420, 200
    xs = [50, 540, 1030]
    top, bot = 120, 620
    f.box(xs[0], top, w, h, "① Agent 写 / 改 *.canvas.tsx",
          "数据内联在 export const DATA\n纯字面量 · 可 diff · 可进 git", "agent", accent_left=True)
    f.box(xs[1], top, w, h, "② 宿主实时编译",
          "sucrase → 内容寻址 ESM\nsha1(src | c1 | k4)[:16]", "host", accent_left=True)
    f.box(xs[2], top, w, h, "③ 右栏面板渲染",
          "动态 import(url) → tab\n主题 token 跟随明暗", "client", accent_left=True)
    f.box(xs[2], bot, w, h, "④ 人操作",
          "标记 / 认领 / 豁免 / 跑门禁\n打开文件 / 把任务交回 Agent", "human", accent_left=True)
    f.box(xs[1], bot, w, h, "⑤ sidecar 暂存",
          ".canvas/<stem>.state.json\n补丁 + at / by: \"user\"", "file", accent_left=True)
    f.box(xs[0], bot, w, h, "⑥ Agent 读切片 / 固化",
          "canvas_read 取 dataPath 切片\ncanvas_state_merge 最小回写", "agent", accent_left=True)

    mid_top, mid_bot = top + h / 2, bot + h / 2
    f.arrow((xs[0] + w, mid_top), (xs[1], mid_top), label="文件工具", loff=(0, -26))
    f.arrow((xs[1] + w, mid_top), (xs[2], mid_top), label="内容寻址 URL", loff=(0, -26))
    f.arrow((xs[2] + w / 2, top + h), (xs[2] + w / 2, bot), label="点击", loff=(56, 0))
    f.arrow((xs[1] + w, mid_bot), (xs[2], mid_bot), label="POST /canvas/action", loff=(0, 112))
    f.arrow((xs[0] + w, mid_bot), (xs[1], mid_bot), label="canvas_read / merge", loff=(0, 112))
    f.arrow((xs[0] + w / 2, bot), (xs[0] + w / 2, top + h), label="下一轮重写", loff=(-64, 0))

    f.box(50, 870, 1400, 96,
          "不变量：源文件 = 唯一持久真相　·　sidecar = 暂存区（不自动丢弃，只标 stale / orphan）"
          "　·　编译失败与运行时崩溃都进诊断卡片，不是白屏",
          None, "info", tsize=24)
    f.save("fig-lifecycle.png")


def architecture():
    f = Fig(1520, 1470)
    f.para(40, 20, "总体架构：单包双半，Agent 与人都只通过稳定的接口接触画布", size=31,
           maxw=1440, bold=True)
    f.box(60, 76, 520, 130, "Agent（模型）", "四个工具：canvas_new / check / read / state_merge", "agent")
    f.box(900, 76, 520, 130, "人（用户）", "只与面板交互：点按钮 / 开文件 / 发起回合", "human")

    f.container(50, 250, 1360, 175, "工作区（普通文件，可 diff / 可进 git）")
    f.box(80, 290, 640, 110, "*.canvas.tsx", "数据内联 · DATA 必须是纯字面量 · 不含远程资源", "file")
    f.box(750, 290, 630, 110, ".canvas/<stem>.state.json", "sidecar：人的判断，暂存待固化", "file")

    f.container(50, 485, 1360, 330, "host 半边（Node / cordis）· 11 文件 2 250 行")
    chips = [
        ("编译管线", "sucrase c1\n扫描 + 抽取 + 包装", "host"),
        ("DATA 抽取", "括号扫描 + 宽容字面量解析\n（不执行画布代码）", "host"),
        ("模块服务", "内容寻址 + ModuleStore\n64 条 / 32 MiB", "host"),
        ("sidecar 读写", "原子 rename\nstale / orphan 不删除", "host"),
        ("动作桥", "7 动作；runCommand 走白名单\n+ 调用方沙箱策略", "host"),
        ("意图入口 + 4 个模型工具", "agent/pre-step 注入 intake\nnew / check / read / state_merge", "host"),
    ]
    cw, ch, gx, gy = 430, 125, 20, 20
    for i, (t, b, p) in enumerate(chips):
        f.box(80 + (i % 3) * (cw + gx), 525 + (i // 3) * (ch + gy), cw, ch, t, b, p,
              tsize=26, bsize=21)

    f.box(50, 865, 1360, 105, "HTTP 前缀路由 /canvas（8 端点）",
          "api · list · source · compile · module/<pathHash12>/<sha16>.js · overlay · action"
          "　｜　POST 必须是 application/json，否则 403", "neutral", tsize=26, bsize=21)

    f.container(50, 1020, 1360, 255, "browser 半边（lib/client.js，零依赖，只 require(\"react\")）")
    chips2 = [
        ("tab type", "认领 *.canvas.tsx\npriority: extension", "client"),
        ("加载器", "同步注入 __DSH_CANVAS__\n→ 动态 import(url)", "client"),
        ("套件 dsh/canvas", "25 组件 + 10 钩子\n样式全用宿主 token", "client"),
        ("错误边界", "key={sha} 重挂载\n崩溃只影响本 tab", "client"),
    ]
    for i, (t, b, p) in enumerate(chips2):
        f.box(80 + i * 333, 1060, 320, 125, t, b, p, tsize=26, bsize=21)

    f.box(50, 1330, 1360, 120, None,
          "回到 Agent 的三条路：startTurn（队列消息，requestId 前缀 canvas-）· runCommand（白名单 + 调用方沙箱策略）"
          "· overlaySet / overlayClear（写 sidecar）。人的入口只有面板本身（右侧虚线）。",
          "info", tsize=23)

    f.arrow((300, 206), (300, 248), label="写 / 改", loff=(90, 0))
    f.arrow((150, 425), (150, 483), label="4 个模型工具", loff=(128, 0), dashed=True)
    f.arrow((700, 815), (700, 863), label="注册一个前缀路由", loff=(140, 0))
    f.arrow((700, 970), (700, 1018), label="GET 模块 / POST 动作", loff=(160, 0))
    f.path([(1160, 206), (1440, 206), (1440, 1140), (1412, 1140)], dashed=True,
           label="人只点面板", lpos=(1440, 840))
    f.save("fig-architecture.png")


def pipeline():
    f = Fig(1560, 940)
    f.para(30, 20, "编译与 DATA 抽取管线：一条链，16 个诊断码，两个产出方", size=31, maxw=1500, bold=True)
    f.text(280, 70, "命中 ModuleStore 缓存（64 条 / 32 MiB）时跳过 ②–⑤：0.077 ms", size=22,
           bold=True, color=GREEN)

    stages = [
        ("① 阈值检查", "1 MB · 8 000 行\nDATA 4 MB", "E_TOO_LARGE\nW_LARGE_FILE", 208),
        ("② 静态扫描", "import 白名单\n动态代码 · 副作用\n外部资源",
         "E_PARSE_IMPORT\nE_UNKNOWN_EXPORT\nE_DYNAMIC · E_SIDE_EFFECT\nE_EXTERNAL · W_REMOTE_URL", 300),
        ("③ sucrase 变换", "typescript + jsx\n+ imports（classic）", "E_PARSE", 226),
        ("④ 默认导出检查", "必须是无参组件", "E_NO_DEFAULT", 196),
        ("⑤ DATA 抽取", "括号配对扫描 +\n宽容字面量解析\n（不执行代码）",
         "E_DATA_NOT_LITERAL\nW_NO_DATA", 220),
        ("⑥ 内容哈希", "sha1(src | c1 | k4)[:16]\n→ 模块 URL", "—", 190),
    ]
    sh, gap = 158, 18
    x0, y0 = 30, 104
    xs = []
    cursor = x0
    for _, _, _, w in stages:
        xs.append(cursor)
        cursor += w + gap
    for i, (t, b, codes, w) in enumerate(stages):
        x = xs[i]
        f.box(x, y0, w, sh, t, b, "host", tsize=25, bsize=19, name=t)
        f.para(x, y0 + sh + 10, codes, size=16, maxw=w, color=(186, 60, 60))
        if i < len(stages) - 1:
            f.arrow((x + w + 2, y0 + sh / 2), (xs[i + 1] - 2, y0 + sh / 2), width=3)

    f.dashed_rect(xs[1] - 8, y0 - 8, xs[4] + stages[4][3] + 8, y0 + sh + 118,
                  GREEN, dash_len=16)

    f.box(30, 420, 940, 175, "诊断（同一条 CanvasDiagnostic，供三处使用）", None, "neutral", tsize=26)
    for i, (t, b) in enumerate([("canvas_check", "Agent 自检的唯一输出"),
                                ("tab 错误卡片", "带行列号 + hint + 两个按钮"),
                                ("host 日志", "装不上 / 编译异常时排查")]):
        f.box(50 + i * 305, 480, 285, 100, t, b, "info", tsize=24, bsize=20)

    f.box(1000, 420, 530, 175, "浏览器动态 import(url)",
          "内容寻址 → 缓存永不陈旧\n旧模块无法卸载，长期会话会累积", "client", tsize=26, bsize=21)

    f.box(30, 620, 1500, 134, "可测量的三个点（见 §6.3）",
          "冷编译（扫描 + sucrase + 抽取 + 包装）中位数 4.13 ms　·　仅 sucrase 1.81 ms　·　"
          "内容哈希命中 0.077 ms　｜　设计预算：单文件编译 < 50 ms（N=200）", "warn", tsize=26, bsize=22)
    f.box(30, 772, 1500, 140, "两条接口纪律",
          "① 编译失败不是 HTTP 错误：永远 200，诊断在响应体里，客户端只有一条错误处理路径。\n"
          "② 诊断有两个产出方：编译期（host）与渲染期（client）；canvas_check 看不到行数截断。",
          "info", tsize=26, bsize=22)
    f.save("fig-pipeline.png")


def sidecar():
    f = Fig(1620, 1090)
    f.para(30, 20, "sidecar 的 staged 写模型：人的判断先落暂存区，再由 Agent 固化回源文件",
           size=31, maxw=1560, bold=True)
    lanes = [("人", None, 150, "human"), ("面板（client 半边）", None, 480, "client"),
             ("host 半边", None, 810, "host"), ("Agent（下一轮）", None, 1140, "agent"),
             ("磁盘", "源文件 + sidecar", 1470, "file")]
    for label, sub, x, p in lanes:
        f.box(x - 135, 88, 270, 96, label, sub, p, tsize=24, bsize=21)
        f.dashed_line((x, 190), (x, 930), color=(178, 184, 194), width=2)

    def msg(y, a, b, label, color=(74, 82, 94), dashed=False):
        f.arrow((lanes[a][2], y), (lanes[b][2], y), color=color, label=label, lsize=21,
                loff=(0, -21), dashed=dashed)

    msg(228, 0, 1, "① 点「标记完成」")
    msg(302, 1, 2, "② POST /canvas/action { overlaySet, key, id, patch }")
    msg(376, 2, 4, "③ 原子写 sidecar：补丁 + at / by:\"user\"")
    f.box(430, 424, 340, 120, None, "④ items = DATA 行 + 补丁\n乐观合并；pending = 在途",
          "client", tsize=21)
    msg(580, 3, 2, "⑤ canvas_read(path, \"tasks\", { status: \"pending\" })", dashed=True)
    msg(654, 2, 3, "⑥ 返回合并结果 + staleOverlay / orphanIds")
    msg(728, 3, 4, "⑦ canvas_state_merge：文本级最小替换")
    msg(802, 2, 4, "⑧ 从 sidecar 移除已合并条目（orphan 保留）")

    f.box(30, 890, 1560, 160, "为什么不是另外两种写法",
          "直接改源文件 → 触发重编译、需要 AST 级改写、并发编辑冲突　｜　只写 localStorage → Agent 看不见，人机不一致。\n"
          "staged 写同时满足：可回滚（sidecar 可清空）· 可追溯（谁在什么时候改的）· Agent 可见（canvas_read 读得到）。",
          "info", tsize=26, bsize=22)
    f.save("fig-sidecar.png")


def intent():
    f = Fig(1560, 1220)
    f.para(30, 20, "意图入口在 agent/pre-step 上的判定链：命中才注入 intake，任何一步不过就原样放行",
           size=30, maxw=1500, bold=True)
    gates = [
        ("① 进入步骤", "await next() → downstream.kind === \"enter\"，且消息批次非空"),
        ("② 只认人说的话", "userPlainText：source.kind === \"user\"；跳过 rpcId 前缀 canvas-*"),
        ("③ 名词命中", "强名词 7 个直接命中：看板 / 画布 / 画板 / 仪表盘 / 驾驶舱 / kanban / dashboard"),
        ("④ 弱名词要被动词「治理」", "弱名词 18 个（canvas / 项目文档 / 审计报告 …）+ 创建动词 27 个，\n"
                                    "动词须落在名词前 12（中文）/ 24（英文）字符窗口内"),
        ("⑤ 抑制「指代既有物」", "16 个标记（这张 / 现有 / 刚才 / 本仓 …）或路径样文本 → 不触发"),
    ]
    x, w, h, gap = 50, 1000, 126, 28
    y = 110
    for t, b in gates:
        f.box(x, y, w, h, t, b, "host", tsize=26, bsize=21, accent_left=True, name=t)
        f.arrow((x + w, y + 62), (1130, y + 62), color=ROSE, width=2, label="不过", lsize=19,
                loff=(0, -22))
        y += h + gap
    last_bottom = y - gap

    f.dashed_line((1150, 110), (1150, last_bottom), color=ROSE, width=3, dash=14, gap=10)
    f.arrow((550, last_bottom + 2), (550, 878), color=GREEN, width=3, label="全部通过",
            lsize=20, loff=(78, 0))
    f.box(50, 880, 1000, 122, "action", "追加一条 source.kind = dsh-canvas 的 user 消息："
                                        "先说清 intent + 7 条对齐问题 + 产出顺序与指针（约 845 字符）",
          "ok", tsize=26, bsize=21)

    f.box(1220, 110, 320, 105, "原样放行", "不注入、不改下游决策", "risk", tsize=26, bsize=21)
    f.box(1220, 250, 320, 400, "注入内容（约 845 字符）",
          "一、先把 intent 说清楚\n二、7 条对齐问题 + 默认值\n三、口径确认后的产出顺序\n\n"
          "刻意不复制：\n· 质量门槛\n· 锚点块说明\n\n因为第二份契约一定会漂移\n（实测注入文本已从 985\n收缩到 845 字符）",
          "info", tsize=25, bsize=20)
    f.box(1220, 685, 320, 120, "异常", "onError 警告一次\n仍原样放行，绝不破坏 step", "risk",
          tsize=25, bsize=21)

    f.box(50, 1020, 1490, 170, "为什么需要「治理窗口」（实测反例）",
          "「做个看板」→ 动词紧随名词，命中。　「一起做（schema 三块 + 模板 + 本仓看板 + resume.md）」→ "
          "动词落在 12 字符窗口之外，且出现「本仓」这一指代标记，不命中。\n"
          "误判与漏判都会发生：用 intentHook / intentKeywords / intentGuide 三个配置项调，不承诺 100% 准。",
          "warn", tsize=26, bsize=22)
    f.save("fig-intent.png")


def context_cost():
    f = Fig(1500, 880)
    f.para(30, 22, "同一张画布（board.canvas.tsx，685 行 / 36 476 字符）的读取成本实测",
           size=31, maxw=1450, bold=True)
    f.text(30, 62, "前五行 = 修前；末三行 = 修后（dataPath 只回目标支）", size=22, color=MUTED)
    rows = [
        ("源文件全文（基准）", 36476, "neutral"),
        ("DATA（不切片）", 20947, "warn"),
        ("dataPath=\"tasks\"", 21025, "warn"),
        ("activity + limit=5", 15041, "info"),
        ("tasks + filter(status=in_progress)", 10676, "info"),
        ("1 行切片 · 修后", 1036, "ok"),
        ("activity + limit=5 · 修后", 1173, "ok"),
        ("brief（工具实际返回）· 修后", 3703, "ok"),
    ]
    base_chars = 36476
    bar_x, bar_max = 560, 620
    y = 112
    for label, chars, palette in rows:
        wpx = max(6, int(bar_max * chars / base_chars))
        fill, stroke = PALETTE[palette]
        f.text(540, y + 6, label, size=23, color=INK, anchor="ra")
        f.d.rounded_rectangle([bar_x, y, bar_x + wpx, y + 40], radius=6, fill=fill,
                              outline=stroke, width=2)
        f.text(bar_x + wpx + 14, y + 8, "%s 字符 · %.1f%%" % (format(chars, ","),
               chars / base_chars * 100), size=22, color=BODY)
        y += 54
    f.dashed_line((bar_x + bar_max, 96), (bar_x + bar_max, y + 4), color=(198, 60, 60),
                  width=3, dash=10, gap=8)
    f.text(bar_x + bar_max + 10, y - 6, "源文件 = 100%", size=21, color=(198, 60, 60))

    f.box(30, 640, 1440, 200, "读法决定成本，必须分路径陈述",
          "摘要路径成立：brief 是源文件的 2.7%–17.4%（工具返回含缩进为 10.2%），接手时读约 3–4 KB 而不是 36 KB。\n"
          "行切片修前只部分成立，主因不是行宽：1 行切片 10 676 字符里该行自身 831（7.8%）、兄弟键 8 794（82.4%）——\n"
          "已修：dataPath/ids 只回目标支，1 行切片 10 676 → 1 036 字符（2.8%）。",
          "info", tsize=26, bsize=22)
    f.save("fig-context.png")


if __name__ == "__main__":
    lifecycle()
    architecture()
    pipeline()
    sidecar()
    intent()
    context_cost()
