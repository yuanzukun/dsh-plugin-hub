/**
 * Template corpus regression: every shipped template must compile clean and
 * expose a literal DATA block, because canvas_new hands them straight to an
 * agent as a starting point. A broken template is a broken first experience.
 */
import assert from "node:assert/strict";
import { promises as fs } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

import { compileCanvas } from "../host/compile.js";
import { readMetadata } from "../host/discovery.js";

const ROOT = path.dirname(path.dirname(fileURLToPath(import.meta.url)));
const corpus = [];

for (const dir of ["skills/canvas/templates", "examples"]) {
  let entries = [];
  try { entries = await fs.readdir(path.join(ROOT, dir)); } catch { continue; }
  for (const entry of entries) {
    if (entry.endsWith(".canvas.tsx")) corpus.push(path.join(ROOT, dir, entry));
  }
}

assert.ok(corpus.length >= 4, "expected the templates plus the example, found " + corpus.length);

let pass = 0;
let fail = 0;

// --- the migration guide's before/after pair ---------------------------------
// docs/cursor-canvas-migration.md tells a reader that a canvas written for a
// sibling kit fails for exactly one reason (the module specifier) and that the
// migrated version compiles clean. Both halves are asserted here, so the guide
// cannot quietly drift away from a working example.
const MIGRATION = path.join(ROOT, "docs", "migration");
try {
  const before = await fs.readFile(path.join(MIGRATION, "cursor-style.before.txt"), "utf8");
  const beforeResult = compileCanvas({ path: path.join(MIGRATION, "before.canvas.tsx"), source: before });
  const beforeCodes = beforeResult.diagnostics.map((d) => d.code);
  assert.deepEqual(beforeCodes, ["E_PARSE_IMPORT"], "the before fixture must fail on the specifier alone, got " + beforeCodes.join(","));

  const after = await fs.readFile(path.join(MIGRATION, "dsh-canvas.after.txt"), "utf8");
  const afterResult = compileCanvas({ path: path.join(MIGRATION, "after.canvas.tsx"), source: after });
  assert.equal(afterResult.ok, true, "the migrated fixture must compile: " + JSON.stringify(afterResult.diagnostics));
  assert.deepEqual(afterResult.diagnostics, [], "the migrated fixture must be diagnostic-free");
  const keys = afterResult.data === undefined ? [] : Object.keys(afterResult.data);
  for (const key of ["goal", "constraints", "decisions", "nextAction", "items", "openItems", "gates", "bigFiles", "surface"]) {
    assert.ok(keys.includes(key), "the migrated DATA must expose " + key + ", got " + keys.join(","));
  }
  console.log("ok   docs/migration pair: before fails on E_PARSE_IMPORT, after compiles clean (DATA keys = " + keys.length + ")");
} catch (error) {
  fail++;
  console.log("FAIL docs/migration pair: " + (error && error.message ? error.message : error));
}

// --- the audit paradigm's shipped artifacts ----------------------------------
// The fifth paradigm has a shape the rest of the system depends on: a declared
// reference (with what it can and cannot detect), a declared row key and
// vocabulary, and claims carrying a graded criterion plus a checkable
// counterpart. Asserted here so a skeleton cannot rot into a look-alike.
const AUDIT_KINDS = ["文档", "实现", "产物", "自基线"];
try {
  for (const rel of ["skills/canvas/templates/audit.canvas.tsx", "docs/audit/interface-audit.canvas.tsx"]) {
    const file = path.join(ROOT, rel);
    let source;
    try { source = await fs.readFile(file, "utf8"); } catch { console.log("skip " + rel + " (not in this checkout)"); continue; }
    const result = compileCanvas({ path: file, source });
    assert.deepEqual(result.diagnostics.map((d) => d.code), [], rel + " must be diagnostic-free");
    const data = result.data;
    assert.equal(data.product, "audit", rel + " must declare product: audit");
    assert.ok(AUDIT_KINDS.includes(data.reference.kind), rel + " reference.kind must be one of " + AUDIT_KINDS.join("/") + ", got " + data.reference.kind);
    assert.ok(typeof data.reference.detects === "string" && data.reference.detects.length > 0, rel + " must say what its reference can detect");
    assert.ok(typeof data.reference.cannotDetect === "string" && data.reference.cannotDetect.length > 0, rel + " must say what it cannot detect");
    assert.equal(data.rowsKey, "claims", rel + " must declare its row key so brief can see the rows");
    assert.ok(Array.isArray(data.openStatuses) && data.openStatuses.length > 0, rel + " must declare its open-status vocabulary");
    assert.ok(data.claims.length >= 2, rel + " must ship claims");
    for (const claim of data.claims) {
      for (const field of ["id", "claim", "status", "criterion", "counterpart", "measured"]) {
        assert.ok(claim[field] !== undefined, rel + " claim " + claim.id + " is missing " + field);
      }
      assert.ok(["L1", "L2"].includes(claim.criterion.level), rel + " claim " + claim.id + " criterion.level must be L1 or L2");
      assert.ok(typeof claim.counterpart.occt === "string" && claim.counterpart.occt.length > 0, rel + " claim " + claim.id + " has no counterpart");
      assert.ok(typeof claim.counterpart.doneWhen === "string" && claim.counterpart.doneWhen.length > 0, rel + " claim " + claim.id + " has no doneWhen");
      assert.ok(typeof claim.measured.round === "string" && typeof claim.measured.mode === "string", rel + " claim " + claim.id + " has no measurement conditions");
    }
    for (const p of data.prohibitions) {
      for (const field of ["pattern", "temptingBecause", "observableSymptom", "reviewWhen"]) {
        assert.ok(typeof p[field] === "string" && p[field].length > 0, rel + " prohibition is missing " + field + " (an unenforceable ban is not a ban)");
      }
    }
    for (const c of data.corrections) {
      for (const field of ["was", "now", "why"]) {
        assert.ok(typeof c[field] === "string" && c[field].length > 0, rel + " correction is missing " + field);
      }
    }
    console.log("ok   " + rel + ": " + data.claims.length + " claims, " + data.prohibitions.length + " prohibitions, " + data.corrections.length + " corrections");
  }
} catch (error) {
  fail++;
  console.log("FAIL audit artifacts: " + (error && error.message ? error.message : error));
}


for (const file of corpus) {
  const rel = path.relative(ROOT, file).replace(/\\/g, "/");
  const source = await fs.readFile(file, "utf8");
  const result = compileCanvas({ path: file, source: source });
  const errors = result.diagnostics.filter((d) => d.severity === "error");
  const warnings = result.diagnostics.filter((d) => d.severity === "warning");
  if (errors.length > 0) {
    fail++;
    console.log("FAIL " + rel);
    for (const d of errors) console.log("     " + d.code + (d.line === undefined ? "" : " line " + d.line) + ": " + d.message);
    continue;
  }
  // A shipped template is not a live canvas: without the marker it would show up
  // in every picker of every workspace that contains the plugin source.
  if (rel.startsWith("skills/canvas/templates/")) {
    assert.equal(readMetadata(source).meta.hidden, "true", rel + " must be marked hidden");
  }
  // The board is the tracking template: a thin row would silently undo the
  // detail/analysis it exists for, so the shape is part of the contract.
  if (rel.endsWith("board.canvas.tsx")) {
    const tasks = result.data === undefined ? undefined : result.data.tasks;
    assert.ok(Array.isArray(tasks) && tasks.length > 0, "board template must ship tasks");
    for (const field of ["id", "lane", "status", "priority", "owner", "progress", "estimate", "actual", "startedAt", "updatedAt", "blocker", "goal", "next", "acceptance", "evidence", "write"]) {
      for (const task of tasks) assert.ok(task[field] !== undefined, "board task " + task.id + " is missing " + field);
    }
  }
  pass++;
  const dataKeys = result.data === undefined ? "none" : Object.keys(result.data).join(",");
  console.log("ok   " + rel + "  lines=" + result.lines + "  DATA={" + dataKeys + "}" + (warnings.length === 0 ? "" : "  warnings=" + warnings.map((w) => w.code).join(",")));
}

console.log("\n" + pass + " compiled, " + fail + " broken");
process.exit(fail === 0 ? 0 : 1);
