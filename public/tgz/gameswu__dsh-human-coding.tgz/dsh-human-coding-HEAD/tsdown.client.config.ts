import { defineConfig } from 'tsdown'

// Client half: browser bundle compiled to the lazy-CJS factory format that
// `window.__ModuleLoader__` (dsh-client-modules) materializes.
//
// `scripts/wrap-client.mjs` wraps the CJS output in
// `window.__ModuleLoader__.load({ id, factory: (require) => ... })`, which is
// the exact bundle shape the platform's client module system expects.
//
// React is platform-provided (`react` / `react/jsx-runtime` are seed words of
// the module table), so both stay external — nothing dsh-specific is required
// at runtime.
export default defineConfig({
  entry: { client: 'src/client/index.tsx' },
  format: ['cjs'],
  platform: 'browser',
  dts: false,
  clean: false,
  sourcemap: false,
  deps: { neverBundle: ['react', 'react/jsx-runtime', 'react-dom'] },
})
