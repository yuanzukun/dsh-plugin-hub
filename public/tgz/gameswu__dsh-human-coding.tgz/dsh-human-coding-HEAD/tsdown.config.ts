import { defineConfig } from 'tsdown'

// Host half: Node ESM plugin consumed by the harness composition loader.
export default defineConfig({
  entry: { index: 'src/host/index.ts' },
  format: ['esm'],
  platform: 'node',
  dts: true,
  clean: false,
  sourcemap: true,
  deps: { neverBundle: [/^@deepseek-ai\//] },
})
