// Wrap the tsdown CJS client bundle into the lazy-CJS factory format the
// dsh client module system executes:
//
//   window.__ModuleLoader__.load({ id, factory: (require) => { ... } })
//
// The factory runs at materialization time: `require` resolves platform seed
// words (react) and other registered plugin bundles. The CJS semantics of the
// wrapped body (module / exports / require) match this contract exactly.
//
// Expected input: dist/client*.js (or .cjs) produced by tsdown.client.config.ts.
// Output: dist/client.js — the file the `./client` export points at.
import { readFileSync, writeFileSync, readdirSync } from 'node:fs'
import { fileURLToPath } from 'node:url'
import { join } from 'node:path'

const BUNDLE_ID = 'dsh-human-coding'
const dist = fileURLToPath(new URL('../dist/', import.meta.url))
const candidates = readdirSync(dist).filter(
  (file) => file.startsWith('client.') && /\.c?js$/.test(file) && file !== 'client.js',
)
if (candidates.length !== 1) {
  console.error(
    `[wrap-client] expected exactly one client bundle in ${dist}, got: ${candidates.join(', ') || 'none'}`,
  )
  process.exit(1)
}
const source = join(dist, candidates[0])
const body = readFileSync(source, 'utf8')
const wrapped = [
  'window.__ModuleLoader__.load({',
  `\tid: ${JSON.stringify(BUNDLE_ID)},`,
  '\tfactory: (require) => {',
  '\t\tvar module = { exports: {} };',
  '\t\tvar exports = module.exports;',
  '\t\tObject.defineProperty(exports, Symbol.toStringTag, { value: "Module" });',
  body,
  '\t\treturn module.exports;',
  '\t}',
  '});',
  '',
].join('\n')
const target = join(dist, 'client.js')
writeFileSync(target, wrapped)
console.log(`[wrap-client] ${candidates[0]} -> client.js (id: ${BUNDLE_ID})`)
