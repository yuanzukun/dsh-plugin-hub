// 修复被 gufa 自定义会话事件阻塞的历史会话日志：
// 把指定事件类型的信封标记为 `ignorable: true`（逐帧重压缩，不改动
// seq/结构），使 dsh-session-persistence 的读取路径不再拒绝该日志。
//
// 仅用于 0.1.5 之前写入的旧日志（v0/v1/v2 世代、含 gufa/* 自定义事件）；
// DSH 0.1.5-rc.1 起会话格式为 v3，由 session-format 迁移升级，本脚本
// 只负责在迁移前/迁移后给这些自定义事件补 ignorable 标记。
//
// 用法：
//   node scripts/repair-gufa-log.mjs <session.v3.jsonl.zstd> <type1> [type2 ...]
// 示例：
//   node scripts/repair-gufa-log.mjs "C:\...\session.v3.jsonl.zstd" gufa/meta gufa/state gufa/change
//
// 修改前自动备份为 <file>.repair-bak。
import { readFileSync, writeFileSync, copyFileSync } from 'node:fs'
import { constants, zstdCompressSync, zstdDecompressSync } from 'node:zlib'

const ZSTD_MAGIC = 0xfd2fb528
const CHECKSUM_OPTIONS = { params: { [constants.ZSTD_c_checksumFlag]: 1 } }

/** 扫描完整 zstd 帧边界（与 dsh-session-persistence-jsonl 同构）。 */
function scanFrames(buffer) {
  const frames = []
  let offset = 0
  while (offset < buffer.length) {
    const start = offset
    if (buffer.length - offset < 4) return { frames, tornStart: start }
    if (buffer.readUInt32LE(offset) !== ZSTD_MAGIC) {
      throw new Error(`invalid Zstandard frame magic at byte ${offset}`)
    }
    offset += 4
    if (offset === buffer.length) return { frames, tornStart: start }
    const descriptor = buffer.readUInt8(offset)
    offset += 1
    if ((descriptor & 24) !== 0) {
      throw new Error(`reserved frame-header bit at byte ${offset - 1}`)
    }
    const contentSizeFlag = descriptor >>> 6
    const singleSegment = (descriptor & 32) !== 0
    const checksum = (descriptor & 4) !== 0
    const dictionaryFlag = descriptor & 3
    const dictionaryBytes = dictionaryFlag === 3 ? 4 : dictionaryFlag
    const contentSizeBytes =
      contentSizeFlag === 0 ? (singleSegment ? 1 : 0) : 1 << contentSizeFlag
    const remainingHeaderBytes = (singleSegment ? 0 : 1) + dictionaryBytes + contentSizeBytes
    if (buffer.length - offset < remainingHeaderBytes) return { frames, tornStart: start }
    offset += remainingHeaderBytes
    for (;;) {
      if (buffer.length - offset < 3) return { frames, tornStart: start }
      const blockHeader = buffer.readUIntLE(offset, 3)
      offset += 3
      const lastBlock = (blockHeader & 1) !== 0
      const blockType = (blockHeader >>> 1) & 3
      const blockSize = blockHeader >>> 3
      if (blockType === 3) throw new Error(`reserved block type at byte ${offset - 3}`)
      const payloadBytes = blockType === 1 ? 1 : blockSize
      if (buffer.length - offset < payloadBytes) return { frames, tornStart: start }
      offset += payloadBytes
      if (lastBlock) break
    }
    if (checksum) {
      if (buffer.length - offset < 4) return { frames, tornStart: start }
      offset += 4
    }
    frames.push({ start, end: offset })
  }
  return { frames }
}

const file = process.argv[2]
const types = new Set(process.argv.slice(3))
if (!file || types.size === 0) {
  console.error('用法: node scripts/repair-gufa-log.mjs <session.jsonl.zstd> <type1> [type2 ...]')
  process.exit(2)
}

const buffer = readFileSync(file)
const { frames, tornStart } = scanFrames(buffer)
if (tornStart !== undefined) {
  throw new Error(`日志末帧不完整（byte ${tornStart}），可能正在写入——拒绝改写`)
}

let changed = 0
const out = []
for (const { start, end } of frames) {
  const text = zstdDecompressSync(buffer.subarray(start, end)).toString('utf8')
  let frameChanged = false
  const rebuilt = text
    .split('\n')
    .map((line) => {
      if (line.trim() === '') return line
      const event = JSON.parse(line)
      if (types.has(event.type) && event.ignorable !== true) {
        event.ignorable = true
        frameChanged = true
        changed += 1
      }
      // 墓碑事件（data: null）会让会话时间线索引在 payloadCoordinates
      // 里读 event.data.turn 崩溃——把 null 换成空对象（无 turn 即会话级）。
      if (types.has(event.type) && event.data === null) {
        event.data = {}
        frameChanged = true
      }
      return frameChanged ? JSON.stringify(event) : line
    })
    .join('\n')
  out.push(zstdCompressSync(Buffer.from(frameChanged ? rebuilt : text, 'utf8'), CHECKSUM_OPTIONS))
}

copyFileSync(file, `${file}.repair-bak`)
writeFileSync(file, Buffer.concat(out))
console.log(
  `已标记 ${changed} 个事件为 ignorable（帧数 ${frames.length}，备份: ${file}.repair-bak）`,
)
