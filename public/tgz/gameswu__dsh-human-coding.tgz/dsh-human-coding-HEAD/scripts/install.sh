#!/usr/bin/env bash
# 古法编程模式安装脚本（bash 版）。
#
# 用法（在仓库根目录或任意位置）：
#   bash scripts/install.sh                 # 默认 Profile
#   bash scripts/install.sh --profile mydev # 指定 Profile
#
# 本脚本执行五件事，且不破坏任何现有设置（需 DSH ≥ 0.1.5-rc.1）：
#   1) 构建插件包（pnpm install && pnpm build，仓库内操作）；
#   2) dsh plugin add <仓库根>（装入 Profile，不动 Profile 其他配置）；
#      本包声明 dsh.bundle.patch，装入后由 DSH 自动纳入 profile 的
#      bundle 层栈（dsh.profile.bundles）——常驻宿主行（statsOnly）随层
#      生效，无需再写入 Profile 的 cordis.patch.yml；
#   3) npm link（把插件链接到 harness 安装旁的全局 node_modules）。
#      DSH ≥ 0.1.5 的预设健康检查与预设挂载都从 harness 安装目录向上
#      解析插件包名，只装在 Profile 里的插件会被判定为「损坏」从而
#      无法切换预设；链接到全局后两者都能找到；
#   4) 准备「古法编程」预设并把 preset/agent.cordis.yml 中的两行片段
#      「外科手术式」并入其 agent.cordis.yml：
#        - 预设已存在：只做合并；
#        - 预设不存在：自动定位已安装的 standard 预设并以其为基础创建，
#          再合并（找不到 standard 时给出手动创建指引并退出）；
#        - 修改前自动备份为 agent.cordis.yml.bak；
#        - 仅替换 persona 行的 prefix/suffix、追加或替换 tool-human-coding 行，
#          其余内容逐字节保留；
#        - preset.yml 仅在缺失时创建，绝不覆盖用户已有元数据；
#   5) 清理旧版安装写入 Profile cordis.patch.yml 的常驻宿主行
#      （tool-human-coding-host）：该行现由插件 bundle 层提供，保留会
#      造成重复行 id；修改前备份为 cordis.patch.yml.bak。
set -euo pipefail

PROFILE='web'
while [ "$#" -gt 0 ]; do
  case "$1" in
    --profile|-p)
      PROFILE="${2:-}"
      shift 2
      ;;
    *)
      echo "未知参数: $1" >&2
      exit 2
      ;;
  esac
done

REPO="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
DSH_ROOT="${DSH_HOME:-$HOME/.dsh}"
PRESET_DIR="$DSH_ROOT/.agent-presets/human-coding"
COMPOSE_FILE="$PRESET_DIR/agent.cordis.yml"
FRAGMENT="$REPO/preset/agent.cordis.yml"

# 从片段文件提取一个顶层行块（自 `- id: <id>` 起，到下一个顶层 `- id:` 止）。
extract_block() {
  local id="$1"
  awk -v id="$id" '
    BEGIN { capture = 0 }
    /^[[:space:]]*- id: / {
      if (capture) exit
      if ($0 ~ ("- id: " id "[[:space:]]*$")) capture = 1
    }
    capture { print }
  ' "$FRAGMENT"
}

# 用 block 替换目标文件中 `- id: <id>` 的整块（不存在则原样保留）。
# 替换后保留一个空行分隔，避免与相邻行粘连。
# block 经环境变量传给 awk：BSD/macOS awk 的 -v 不接受含换行的值。
replace_block() {
  local file="$1" id="$2"
  BLOCK="$3" awk -v id="$id" '
    BEGIN { inblock = 0 }
    /^[[:space:]]*- id: / {
      if (inblock) { printf "%s\n\n", ENVIRON["BLOCK"]; inblock = 0 }
      if ($0 ~ ("- id: " id "[[:space:]]*$")) inblock = 1
      else print
      next
    }
    { if (!inblock) print }
    END { if (inblock) printf "%s\n", ENVIRON["BLOCK"] }
  ' "$file"
}

# 定位已安装的 standard 预设组合文件；找不到返回非零。
# 0.1.5-rc.1：预设随 @deepseek-ai/dsh-agent-presets 发布
# (presets/standard/agent.cordis.yml)；旧版内嵌在 dsh 包的
# config/agent-presets 下，保留为兜底。
find_standard_compose() {
  local root d candidate profile_dir
  for candidate in \
    "${DSH_HOME:-$HOME/.dsh}/profiles/node_modules/@deepseek-ai/dsh-agent-presets/presets/standard/agent.cordis.yml" \
    "$HOME/node_modules/@deepseek-ai/dsh-agent-presets/presets/standard/agent.cordis.yml" \
    "${APPDATA:-}/npm/node_modules/@deepseek-ai/dsh/node_modules/@deepseek-ai/dsh-agent-presets/presets/standard/agent.cordis.yml"; do
    if [ -n "$candidate" ] && [ -f "$candidate" ]; then echo "$candidate"; return 0; fi
  done
  # 部分安装形态把依赖放在 profiles/<name>/node_modules 下。
  for profile_dir in "${DSH_HOME:-$HOME/.dsh}"/profiles/*/node_modules; do
    candidate="$profile_dir/@deepseek-ai/dsh-agent-presets/presets/standard/agent.cordis.yml"
    if [ -f "$candidate" ]; then echo "$candidate"; return 0; fi
  done
  for root in "${DSH_HOME:-$HOME/.dsh}/node_modules/.pnpm" "$HOME/node_modules/.pnpm"; do
    for d in "$root"/@deepseek-ai+dsh-agent-presets@*; do
      candidate="$d/node_modules/@deepseek-ai/dsh-agent-presets/presets/standard/agent.cordis.yml"
      if [ -f "$candidate" ]; then echo "$candidate"; return 0; fi
    done
    for d in "$root"/@deepseek-ai+dsh@*; do
      candidate="$d/node_modules/@deepseek-ai/dsh/config/agent-presets/standard/agent.cordis.yml"
      if [ -f "$candidate" ]; then echo "$candidate"; return 0; fi
    done
  done
  candidate="$HOME/node_modules/@deepseek-ai/dsh/config/agent-presets/standard/agent.cordis.yml"
  if [ -f "$candidate" ]; then echo "$candidate"; return 0; fi
  return 1
}

echo '==> [1/5] 构建插件包（pnpm install && pnpm build）...'
(cd "$REPO" && pnpm install && pnpm build)

echo '==> [2/5] 把插件包装入 Profile（bundle 层）...'
if [ -n "$PROFILE" ]; then
  dsh plugin --profile "$PROFILE" add "$REPO"
else
  dsh plugin add "$REPO"
fi

echo '==> [3/5] 链接到 harness 旁（npm link，0.1.5+ 预设健康检查要求）...'
(cd "$REPO" && npm link)

echo '==> [4/5] 准备并合并「古法编程」预设片段 ...'
if [ ! -f "$COMPOSE_FILE" ]; then
  # 预设不存在：自动以已安装的 standard 预设为基础创建。
  STANDARD="$(find_standard_compose || true)"
  if [ -z "$STANDARD" ]; then
    echo "错误: 未找到预设组合 ${COMPOSE_FILE}，且无法定位已安装的 standard 预设。" >&2
    echo '请手动以 standard 为基础创建名为 human-coding 的预设（standard 的全部行保持不变），' >&2
    echo '然后重跑本脚本完成合并。' >&2
    exit 1
  fi
  mkdir -p "$PRESET_DIR"
  cp "$STANDARD" "$COMPOSE_FILE"
  echo "已以 standard 为基础自动创建预设组合: $COMPOSE_FILE"
fi

PERSONA_BLOCK="$(extract_block 'persona')"
TOOL_BLOCK="$(extract_block 'tool-human-coding')"
if [ -z "$PERSONA_BLOCK" ] || [ -z "$TOOL_BLOCK" ]; then
  echo "错误: 无法从片段文件提取 persona / tool-human-coding 行块: $FRAGMENT" >&2
  exit 1
fi

cp "$COMPOSE_FILE" "$COMPOSE_FILE.bak"
echo "已备份现有组合: $COMPOSE_FILE.bak"

if grep -qE '^[[:space:]]*- id: persona[[:space:]]*$' "$COMPOSE_FILE"; then
  replace_block "$COMPOSE_FILE" 'persona' "$PERSONA_BLOCK" > "$COMPOSE_FILE.tmp"
  mv "$COMPOSE_FILE.tmp" "$COMPOSE_FILE"
else
  printf '\n%s\n' "$PERSONA_BLOCK" >> "$COMPOSE_FILE"
fi

if grep -qE '^[[:space:]]*- id: tool-human-coding[[:space:]]*$' "$COMPOSE_FILE"; then
  replace_block "$COMPOSE_FILE" 'tool-human-coding' "$TOOL_BLOCK" > "$COMPOSE_FILE.tmp"
  mv "$COMPOSE_FILE.tmp" "$COMPOSE_FILE"
else
  printf '\n%s\n' "$TOOL_BLOCK" >> "$COMPOSE_FILE"
fi

if [ ! -f "$PRESET_DIR/preset.yml" ]; then
  cp "$REPO/preset/preset.yml" "$PRESET_DIR/preset.yml"
  echo "已创建预设元数据: $PRESET_DIR/preset.yml"
else
  echo 'preset.yml 已存在，保持原样（不覆盖你的设置）。'
fi

echo '==> [5/5] 清理旧版宿主行（已由插件 bundle 层接管）...'
PROFILE_NAME="${PROFILE:-web}"
PATCH_FILE="$DSH_ROOT/profiles/$PROFILE_NAME/cordis.patch.yml"
if [ -f "$PATCH_FILE" ] && grep -qE '^[[:space:]]*- id:[[:space:]]*tool-human-coding-host[[:space:]]*$' "$PATCH_FILE"; then
  cp "$PATCH_FILE" "$PATCH_FILE.bak"
  # 逐条过滤顶层补丁条目：整块移除包含 tool-human-coding-host 的 insert 块，
  # 其余条目与注释原样保留；清空后若没有任何条目，回退为合法的空数组 `[]`。
  # 顶层条目必须从列首开始（补丁文件是顶层数组，子行均缩进），
  # 因此只以行首 `- id:` / `- insert:` 作为条目边界。
  FILTERED="$(awk '
    /^- (id|insert):/ {
      if (buffer != "" && !drop) printf "%s", buffer
      buffer = $0 "\n"
      drop = 0
      next
    }
    {
      buffer = buffer $0 "\n"
      if ($0 ~ /- id:[[:space:]]*tool-human-coding-host[[:space:]]*$/) drop = 1
    }
    END { if (buffer != "" && !drop) printf "%s", buffer }
  ' "$PATCH_FILE")"
  if ! printf '%s' "$FILTERED" | grep -qE '^- (id|insert):'; then
    FILTERED='[]'
  fi
  printf '%s\n' "$FILTERED" > "$PATCH_FILE"
  echo "已移除旧版宿主行（备份: $PATCH_FILE.bak；常驻宿主行现由 bundle 层提供）"
else
  echo '无需清理（未发现旧版宿主行）。'
fi

echo ''
echo '安装完成。下一步: 重启 Profile -> 刷新网页 -> 新建会话并选择「古法编程」预设。'
