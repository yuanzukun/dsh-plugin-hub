﻿# 古法编程模式安装脚本（PowerShell 版）。
#
# 用法：
#   .\scripts\install.ps1                 # 默认 Profile
#   .\scripts\install.ps1 -Profile mydev  # 指定 Profile
#
# 本脚本执行五件事，且不破坏任何现有设置（需 DSH ≥ 0.1.5-rc.1）：
#   1) 构建插件包（pnpm install && pnpm build，仓库内操作）；
#   2) dsh plugin add <仓库根>（装入 Profile，不动 Profile 其他配置）；
#      本包声明 dsh.bundle.patch，装入后由 DSH 自动纳入 profile 的
#      bundle 层栈（dsh.profile.bundles）——常驻宿主行（statsOnly）随层
#      生效，无需再写入 Profile 的 cordis.patch.yml；
#   3) npm link（把插件链接到 harness 安装旁的全局 node_modules）。
#      DSH ≥ 0.1.5 的预设健康检查与预设挂载都从 harness 安装目录向上
#      解析插件包名，只装在 Profile 里的插件会被判定为「损坏」从而
#      无法切换预设；链接到全局后两者都能找到；
#   4) 准备「古法编程」预设并把 preset/agent.cordis.yml 中的两行片段
#      「外科手术式」并入其 agent.cordis.yml：
#        - 预设已存在：只做合并；
#        - 预设不存在：自动定位已安装的 standard 预设并以其为基础创建，
#          再合并（找不到 standard 时给出手动创建指引并退出）；
#        - 修改前自动备份为 agent.cordis.yml.bak；
#        - 仅替换 persona 行的 prefix/suffix、追加或替换 tool-human-coding 行，
#          其余内容逐字节保留；
#        - preset.yml 仅在缺失时创建，绝不覆盖用户已有元数据；
#   5) 清理旧版安装写入 Profile cordis.patch.yml 的常驻宿主行
#      （tool-human-coding-host）：该行现由插件 bundle 层提供，保留会
#      造成重复行 id；修改前备份为 cordis.patch.yml.bak。
param(
  [string]$Profile = 'web'
)

$ErrorActionPreference = 'Stop'
$repoRoot = Split-Path -Parent $PSScriptRoot
$fragmentPath = Join-Path $repoRoot 'preset\agent.cordis.yml'
$dsHroot = if ($env:DSH_HOME) { $env:DSH_HOME } else { Join-Path $HOME '.dsh' }
$presetDir = Join-Path $dsHroot '.agent-presets\human-coding'
$composePath = Join-Path $presetDir 'agent.cordis.yml'
$metaPath = Join-Path $presetDir 'preset.yml'

# pnpm.ps1 / dsh.ps1 包装器会把命令回显到 stderr；PowerShell 5.1 在
# stderr 被重定向时会把这些回显当成错误记录，配合 EAP=Stop 变成终止性
# 错误，脚本会在第一个原生命令处静默死亡。原生命令的成败只看
# $LASTEXITCODE，因此原生调用期间临时放宽 EAP，调用后统一检查退出码。
function Invoke-Native {
  param(
    [Parameter(Mandatory = $true)][scriptblock]$Command,
    [Parameter(Mandatory = $true)][string]$FailureMessage
  )
  $prev = $ErrorActionPreference
  $ErrorActionPreference = 'Continue'
  try {
    & $Command
  }
  finally {
    $ErrorActionPreference = $prev
  }
  if ($LASTEXITCODE -ne 0) { throw "$FailureMessage（exit $LASTEXITCODE）" }
}

# 定位已安装的 standard 预设组合文件；找不到返回 $null。
function Find-StandardCompose {
  # 0.1.5-rc.1：预设随 @deepseek-ai/dsh-agent-presets 发布
  # (presets/standard/agent.cordis.yml)；旧版内嵌在 dsh 包的
  # config/agent-presets 下，保留为兜底。
  $directs = @()
  if ($env:DSH_HOME) {
    $directs += (Join-Path $env:DSH_HOME 'profiles\node_modules\@deepseek-ai\dsh-agent-presets\presets\standard\agent.cordis.yml')
  }
  $directs += (Join-Path $HOME 'node_modules\@deepseek-ai\dsh-agent-presets\presets\standard\agent.cordis.yml')
  if ($env:APPDATA) {
    $directs += (Join-Path $env:APPDATA 'npm\node_modules\@deepseek-ai\dsh\node_modules\@deepseek-ai\dsh-agent-presets\presets\standard\agent.cordis.yml')
  }
  foreach ($candidate in $directs) {
    if (Test-Path $candidate) { return $candidate }
  }
  # 部分安装形态把依赖放在 profiles/<name>/node_modules 下。
  if ($env:DSH_HOME) {
    $profileDirs = Get-ChildItem (Join-Path $env:DSH_HOME 'profiles') -Directory -ErrorAction SilentlyContinue
    foreach ($profileDir in $profileDirs) {
      $candidate = Join-Path $profileDir.FullName 'node_modules\@deepseek-ai\dsh-agent-presets\presets\standard\agent.cordis.yml'
      if (Test-Path $candidate) { return $candidate }
    }
  }
  # pnpm store：新版包名，旧版 dsh 内嵌路径兜底。
  $roots = @()
  if ($env:DSH_HOME) { $roots += (Join-Path $env:DSH_HOME 'node_modules\.pnpm') }
  $roots += (Join-Path $HOME 'node_modules\.pnpm')
  foreach ($root in $roots) {
    $dirs = Get-ChildItem $root -Directory -Filter '@deepseek-ai+dsh-agent-presets@*' -ErrorAction SilentlyContinue
    foreach ($dir in $dirs) {
      $candidate = Join-Path $dir.FullName 'node_modules\@deepseek-ai\dsh-agent-presets\presets\standard\agent.cordis.yml'
      if (Test-Path $candidate) { return $candidate }
    }
    $legacyDirs = Get-ChildItem $root -Directory -Filter '@deepseek-ai+dsh@*' -ErrorAction SilentlyContinue
    foreach ($dir in $legacyDirs) {
      $candidate = Join-Path $dir.FullName 'node_modules\@deepseek-ai\dsh\config\agent-presets\standard\agent.cordis.yml'
      if (Test-Path $candidate) { return $candidate }
    }
  }
  $legacy = Join-Path $HOME 'node_modules\@deepseek-ai\dsh\config\agent-presets\standard\agent.cordis.yml'
  if (Test-Path $legacy) { return $legacy }
  return $null
}

Write-Host '==> [1/5] 构建插件包（pnpm install && pnpm build）...'
Push-Location $repoRoot
try {
  Invoke-Native { pnpm install } 'pnpm install 失败'
  Invoke-Native { pnpm build } 'pnpm build 失败'
}
finally {
  Pop-Location
}

Write-Host '==> [2/5] 把插件包装入 Profile（bundle 层）...'
if ($Profile -ne '') {
  Invoke-Native { dsh plugin --profile $Profile add $repoRoot } 'dsh plugin add 失败'
}
else {
  Invoke-Native { dsh plugin add $repoRoot } 'dsh plugin add 失败'
}

Write-Host '==> [3/5] 链接到 harness 旁（npm link，0.1.5+ 预设健康检查要求）...'
Push-Location $repoRoot
try {
  Invoke-Native { npm link } 'npm link 失败'
}
finally {
  Pop-Location
}

Write-Host '==> [4/5] 准备并合并「古法编程」预设片段 ...'
if (-not (Test-Path $composePath)) {
  # 预设不存在：自动以已安装的 standard 预设为基础创建。
  $standard = Find-StandardCompose
  if (-not $standard) {
    Write-Host "错误: 未找到预设组合 $composePath，且无法定位已安装的 standard 预设。" -ForegroundColor Red
    Write-Host '请手动以 standard 为基础创建名为 human-coding 的预设（standard 的全部行保持不变），' -ForegroundColor Red
    Write-Host '然后重跑本脚本完成合并。' -ForegroundColor Red
    exit 1
  }
  New-Item -ItemType Directory -Path $presetDir -Force | Out-Null
  Copy-Item $standard $composePath
  Write-Host "已以 standard 为基础自动创建预设组合: $composePath"
}

# 从片段文件提取顶层行块（去注释、去首部空行后按顶层 `- id:` 切块）。
$fragmentLines = Get-Content $fragmentPath -Encoding UTF8 | Where-Object { $_ -notmatch '^\s*#' }
$fragment = ($fragmentLines -join "`n").TrimStart("`r", "`n", "`t", ' ')
$blocks = [regex]::Matches($fragment, '(?ms)^- id: .*?(?=^- id:|\z)')
$personaBlock = ($blocks | Where-Object { $_.Value -match '(?m)^- id: persona\s*$' }).Value
$toolBlock = ($blocks | Where-Object { $_.Value -match '(?m)^- id: tool-human-coding\s*$' }).Value
if (-not $personaBlock -or -not $toolBlock) {
  throw "无法从片段文件提取 persona / tool-human-coding 行块: $fragmentPath"
}
$personaBlock = $personaBlock.TrimEnd("`r", "`n")
$toolBlock = $toolBlock.TrimEnd("`r", "`n")

$content = Get-Content $composePath -Raw -Encoding UTF8

# 修改前备份（固定文件名，每次运行覆盖上一次备份）。
Copy-Item $composePath "$composePath.bak" -Force
Write-Host "已备份现有组合: $composePath.bak"

# 1) persona：存在则整块替换（仅该行块；前瞻保留与下一行之间的换行），不存在则追加到末尾。
if ($content -match '(?m)^- id: persona\s*$') {
  $content = [regex]::Replace($content, '(?ms)^- id: persona.*?(?=\r?\n- id:|\r?\n?\z)', $personaBlock)
}
else {
  $content = $content.TrimEnd("`r", "`n") + "`n`n" + $personaBlock + "`n"
}

# 2) tool-human-coding：存在则整块替换，不存在则追加到末尾。
if ($content -match '(?m)^- id: tool-human-coding\s*$') {
  $content = [regex]::Replace($content, '(?ms)^- id: tool-human-coding.*?(?=\r?\n- id:|\r?\n?\z)', $toolBlock)
}
else {
  $content = $content.TrimEnd("`r", "`n") + "`n`n" + $toolBlock + "`n"
}

# 用 .NET 写回 UTF-8 无 BOM（兼容 Windows PowerShell 5.1）。
[IO.File]::WriteAllText($composePath, $content, (New-Object Text.UTF8Encoding $false))

# preset.yml 仅在缺失时创建，绝不覆盖用户已有元数据。
if (-not (Test-Path $metaPath)) {
  Copy-Item (Join-Path $repoRoot 'preset\preset.yml') $metaPath
  Write-Host "已创建预设元数据: $metaPath"
}
else {
  Write-Host 'preset.yml 已存在，保持原样（不覆盖你的设置）。'
}

Write-Host '==> [5/5] 清理旧版宿主行（已由插件 bundle 层接管）...'
$profileName = if ($Profile -ne '') { $Profile } else { 'web' }
$patchPath = Join-Path $dsHroot "profiles\$profileName\cordis.patch.yml"
if ((Test-Path $patchPath) -and ((Get-Content $patchPath -Raw -Encoding UTF8) -match '(?m)^\s*- id:\s*tool-human-coding-host\s*$')) {
  Copy-Item $patchPath "$patchPath.bak" -Force
  # 逐条过滤顶层补丁条目：整块移除包含 tool-human-coding-host 的 insert 块，
  # 其余条目与注释原样保留；清空后若没有任何条目，回退为合法的空数组 `[]`。
  # 顶层条目必须从列首开始（补丁文件是顶层数组，子行均缩进），
  # 因此只以行首 `- id:` / `- insert:` 作为条目边界。
  $lines = Get-Content $patchPath -Encoding UTF8
  $out = New-Object System.Collections.Generic.List[string]
  $cur = New-Object System.Collections.Generic.List[string]
  $drop = $false
  foreach ($line in $lines) {
    if ($line -match '^- (id|insert):') {
      if ($cur.Count -gt 0) {
        if (-not $drop) { $out.AddRange($cur) }
        $cur.Clear()
        $drop = $false
      }
    }
    $cur.Add($line)
    if ($line -match '- id:\s*tool-human-coding-host\s*$') { $drop = $true }
  }
  if ($cur.Count -gt 0 -and -not $drop) { $out.AddRange($cur) }
  $joined = $out -join "`n"
  if ($joined -notmatch '(?m)^- (id|insert):') { $joined = '[]' }
  [IO.File]::WriteAllText($patchPath, $joined + "`n", (New-Object Text.UTF8Encoding $false))
  Write-Host "已移除旧版宿主行（备份: $patchPath.bak；常驻宿主行现由 bundle 层提供）"
}
else {
  Write-Host '无需清理（未发现旧版宿主行）。'
}

Write-Host ''
Write-Host '安装完成。下一步: 重启 Profile -> 刷新网页 -> 新建会话并选择「古法编程」预设。'
