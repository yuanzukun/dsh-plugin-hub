import { describe, expect, it } from 'vitest'
import type { Agent } from '@deepseek-ai/dsh-agent'
import type { ToolRunContext } from '@deepseek-ai/dsh-tools'
import type { SessionEvent } from '@deepseek-ai/dsh-session'
import { HarnessError } from '@deepseek-ai/dsh-llm'
import { liveAgent, openTurnEvents, requireHumanTurn } from '../src/host/authority'
import type { GufaContext } from '../src/host/context'

type SourceKind = 'user' | 'goal' | 'plugin' | 'subagent'

let nextSeq = 0

/** Build one session event; cast at the boundary because tests only exercise discriminated fields. */
function sessionEvent(type: string, data: Record<string, unknown> = {}): SessionEvent {
  nextSeq += 1
  return { type, seq: nextSeq, time: nextSeq, data } as unknown as SessionEvent
}

function turnStart(turn = 1): SessionEvent {
  return sessionEvent('turn/start', { turn })
}

function turnEnd(turn = 1): SessionEvent {
  return sessionEvent('turn/end', { turn, reason: { kind: 'completed' } })
}

function userMessage(source: SourceKind = 'user'): SessionEvent {
  return sessionEvent('user/message', { content: [], source: { kind: source } })
}

function assistantMessage(): SessionEvent {
  return sessionEvent('assistant/message', { content: [] })
}

function stepStart(): SessionEvent {
  return sessionEvent('step/start', { turn: 1, step: 1 })
}

function makeAgent(
  id: string,
  events: readonly SessionEvent[],
  status: 'idle' | 'running' = 'running',
): Agent {
  return {
    id,
    status,
    session: { snapshotEvents: () => events },
  } as unknown as Agent
}

function agentsFace(options: {
  all?: readonly Agent[]
  roots?: readonly Agent[]
  initiator?: Agent
} = {}): GufaContext['agents'] {
  const all = options.all ?? []
  const roots = options.roots ?? all
  return {
    get(id: string) {
      return all.find((agent) => String(agent.id) === id)
    },
    roots: () => [...roots],
    currentInitiator: () => options.initiator,
  }
}

function makeCtx(options: Parameters<typeof agentsFace>[0] = {}): GufaContext {
  return { agents: agentsFace(options) } as unknown as GufaContext
}

function makeExec(agent: Agent | undefined): ToolRunContext {
  return { agent } as unknown as ToolRunContext
}

function thrown(fn: () => unknown): unknown {
  try {
    fn()
    return undefined
  } catch (error) {
    return error
  }
}

function expectCode(fn: () => unknown, code: string): void {
  const error = thrown(fn)
  expect(error).toBeInstanceOf(HarnessError)
  expect((error as HarnessError).code).toBe(code)
}

describe('openTurnEvents', () => {
  it('returns the suffix after the latest turn/start', () => {
    const current = userMessage()
    const reply = assistantMessage()
    const agent = makeAgent('a', [turnStart(1), userMessage(), turnEnd(1), turnStart(2), current, reply])
    expect(openTurnEvents(agent)).toEqual([current, reply])
  })

  it('rejects when the latest turn boundary is turn/end', () => {
    const agent = makeAgent('a', [turnStart(), userMessage(), turnEnd()])
    expectCode(() => openTurnEvents(agent), 'GUFA_TURN_REQUIRED')
  })

  it('rejects when the log has no turn boundary', () => {
    expectCode(() => openTurnEvents(makeAgent('empty', [])), 'GUFA_TURN_REQUIRED')
    expectCode(
      () => openTurnEvents(makeAgent('no-turn', [stepStart(), userMessage(), assistantMessage()])),
      'GUFA_TURN_REQUIRED',
    )
  })

  it('ignores a closed earlier turn when the latest turn is open', () => {
    const closedUser = userMessage()
    const openUser = userMessage()
    const agent = makeAgent('a', [
      turnStart(1),
      closedUser,
      turnEnd(1),
      turnStart(2),
      openUser,
      assistantMessage(),
    ])
    expect(openTurnEvents(agent).map((event) => event.type)).toEqual(['user/message', 'assistant/message'])
  })
})

describe('requireHumanTurn', () => {
  it('passes a direct human user/message in the agent open turn', () => {
    const agent = makeAgent('root', [turnStart(), userMessage('user')])
    const ctx = makeCtx({ all: [agent], roots: [agent], initiator: agent })
    expect(() => requireHumanTurn(ctx, agent)).not.toThrow()
  })

  it('rejects a non-root agent before inspecting its turn', () => {
    const root = makeAgent('root', [])
    const child = makeAgent('child', [turnStart(), userMessage('user')])
    const ctx = makeCtx({ all: [root, child], roots: [root], initiator: child })
    expectCode(() => requireHumanTurn(ctx, child), 'GUFA_ROOT_REQUIRED')
  })

  for (const source of ['goal', 'plugin', 'subagent'] as const) {
    it(`rejects an open turn whose user/message source is ${source}`, () => {
      const agent = makeAgent('root', [turnStart(), userMessage(source)])
      const ctx = makeCtx({ all: [agent], roots: [agent], initiator: agent })
      expectCode(() => requireHumanTurn(ctx, agent), 'GUFA_HUMAN_REQUIRED')
    })
  }

  it('rejects a root agent with an open turn but no user/message', () => {
    const agent = makeAgent('root', [turnStart(), assistantMessage()])
    const ctx = makeCtx({ all: [agent], roots: [agent], initiator: agent })
    expectCode(() => requireHumanTurn(ctx, agent), 'GUFA_HUMAN_REQUIRED')
  })

  it('propagates GUFA_TURN_REQUIRED for a root agent whose turn is closed', () => {
    const agent = makeAgent('root', [turnStart(), userMessage(), turnEnd()])
    const ctx = makeCtx({ all: [agent], roots: [agent], initiator: agent })
    expectCode(() => requireHumanTurn(ctx, agent), 'GUFA_TURN_REQUIRED')
  })
})

describe('liveAgent', () => {
  it('rejects execution without a calling agent', () => {
    expectCode(() => liveAgent(makeCtx(), makeExec(undefined)), 'GUFA_AGENT_REQUIRED')
  })

  it('accepts the exact running registry agent when it is the current initiator', () => {
    const agent = makeAgent('a', [])
    const ctx = makeCtx({ all: [agent], initiator: agent })
    expect(liveAgent(ctx, makeExec(agent))).toBe(agent)
  })

  it('rejects an agent whose id does not resolve to the exact live instance', () => {
    const registered = makeAgent('a', [])
    const caller = makeAgent('a', [])
    const ctx = makeCtx({ all: [registered], initiator: registered })
    expectCode(() => liveAgent(ctx, makeExec(caller)), 'GUFA_DRIVER_REQUIRED')
  })

  it('rejects an agent that is not running', () => {
    const agent = makeAgent('a', [], 'idle')
    const ctx = makeCtx({ all: [agent], initiator: agent })
    expectCode(() => liveAgent(ctx, makeExec(agent)), 'GUFA_DRIVER_REQUIRED')
  })

  it('rejects a running registry agent when a different driver is active', () => {
    const agent = makeAgent('a', [])
    const other = makeAgent('b', [])
    const ctx = makeCtx({ all: [agent, other], initiator: other })
    expectCode(() => liveAgent(ctx, makeExec(agent)), 'GUFA_DRIVER_REQUIRED')
  })

  it('rejects an agent missing from the registry', () => {
    const agent = makeAgent('a', [])
    const ctx = makeCtx({ all: [], initiator: agent })
    expectCode(() => liveAgent(ctx, makeExec(agent)), 'GUFA_DRIVER_REQUIRED')
  })
})
