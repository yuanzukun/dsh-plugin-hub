import { describe, expect, it } from 'vitest'
import type { GufaChallengeRecord, GufaStats } from '../src/shared/state'
import { emptyStats } from '../src/shared/state'
import {
  buildExport,
  deriveStats,
  mergeHistory,
  mergeImport,
  parseImport,
  PERFORMANCE_DENOMINATOR,
  performanceContributions,
  performanceScore,
  recomputeStats,
} from '../src/client/records'

function record(overrides: Partial<GufaChallengeRecord>): GufaChallengeRecord {
  return {
    id: 'r-1',
    title: '词频统计',
    outcome: 'pass',
    mode: 'keep',
    score: 0.8,
    difficulty: 0.5,
    attempts: 2,
    hintsUsed: 1,
    maxHints: 3,
    updatedAt: 1000,
    ...overrides,
  }
}

const baseStats = (): GufaStats => ({ ...emptyStats(0), offers: 5, skips: 2, exits: 1 })

describe('导出/导入（数值记录）', () => {
  it('buildExport 打包 schema/stats/history', () => {
    const stats = baseStats()
    const history = [record({})]
    const data = buildExport(stats, history, 42)
    expect(data).toMatchObject({ schema: 'dsh-human-coding-stats', version: 1, exportedAt: 42, stats, history })
  })

  it('parseImport 往返还原，非法输入报错', () => {
    const data = buildExport(baseStats(), [record({})], 42)
    const parsed = parseImport(JSON.stringify(data))
    expect(parsed.ok).toBe(true)
    if (parsed.ok) {
      expect(parsed.data.history).toHaveLength(1)
      expect(parsed.data.stats.offers).toBe(5)
    }
    expect(parseImport('not json').ok).toBe(false)
    expect(parseImport(JSON.stringify({ schema: 'other' })).ok).toBe(false)
    expect(parseImport(JSON.stringify({ schema: 'dsh-human-coding-stats', stats: {}, history: 'x' })).ok).toBe(false)
  })

  it('parseImport 过滤非法逐题记录', () => {
    const data = { schema: 'dsh-human-coding-stats', version: 1, exportedAt: 0, stats: baseStats(), history: [record({}), { title: '坏' }, record({ outcome: 'pass', score: 99 })] }
    const parsed = parseImport(JSON.stringify(data))
    expect(parsed.ok).toBe(true)
    if (parsed.ok) {
      expect(parsed.data.history).toHaveLength(2)
      expect(parsed.data.history[1]?.score).toBe(1) // 分数越界收敛到 1
    }
  })

  it('mergeHistory 按标题去重（大小写不敏感，本地优先）', () => {
    const local = [record({ id: 'l1', title: '词频统计' }), record({ id: 'l2', title: 'TODO 列表', outcome: 'fail' })]
    const imported = [
      record({ id: 'i1', title: '词频统计', outcome: 'giveup' }),
      record({ id: 'i2', title: '  词频统计 ' }),
      record({ id: 'i3', title: '计算器' }),
    ]
    const merged = mergeHistory(local, imported)
    expect(merged).toHaveLength(3)
    expect(merged[0]?.id).toBe('l1')
    expect(merged.map((r) => r.title)).toEqual(['词频统计', 'TODO 列表', '计算器'])
  })

  it('recomputeStats 由逐题记录重算可推导计数，保留 offers/skips/exits', () => {
    const history = [
      record({ outcome: 'pass', mode: 'keep', score: 0.8, difficulty: 0.5, attempts: 2, hintsUsed: 1, maxHints: 3 }),
      record({ outcome: 'fail', mode: 'takeover', score: null, difficulty: 0.6, attempts: 1, hintsUsed: 2, maxHints: 4 }),
      record({ outcome: 'giveup', mode: 'takeover', score: null, difficulty: 0.2, attempts: 0, hintsUsed: 0, maxHints: 2 }),
    ]
    const stats = recomputeStats(history, baseStats())
    expect(stats).toMatchObject({
      offers: 5,
      skips: 2,
      exits: 1,
      passes: 1,
      fails: 1,
      giveUps: 1,
      giveUpsAfterFail: 1,
      attempts: 3,
      hintsUsed: 3,
      hintsBudget: 9,
      difficultySum: 1.3,
      difficultyCount: 3,
      scoreSum: 0.8,
      scoreCount: 1,
    })
    expect(stats.modes).toEqual({ keep: 1, polish: 0, rewrite: 0, takeover: 2 })
    expect(stats.weightedScoreSum).toBeCloseTo(0.4)
    expect(stats.scoredDifficultySum).toBeCloseTo(0.5)
  })

  it('mergeImport 合并去重并重算，offers/skips/exits 取较大值', () => {
    const local = [record({ id: 'l1', title: '词频统计', score: 0.8, difficulty: 0.5 })]
    const imported = [record({ id: 'i1', title: '词频统计', score: 0.9 }), record({ id: 'i2', title: '计算器', score: 0.6, difficulty: 0.3, outcome: 'pass' })]
    const merged = mergeImport(local, { ...emptyStats(0), offers: 4, skips: 1, exits: 0 }, imported, { ...emptyStats(0), offers: 7, skips: 0, exits: 2 })
    expect(merged.history.map((r) => r.title)).toEqual(['词频统计', '计算器'])
    expect(merged.stats).toMatchObject({ offers: 7, skips: 1, exits: 2, passes: 2, scoreCount: 2 })
    expect(merged.stats.scoreSum).toBeCloseTo(1.4)
  })

  it('performanceScore: 空记录为 0；单题 = 完成度×难度×100 ÷ 固定归一化 × 100', () => {
    expect(performanceScore([])).toBe(0)
    const expected = ((0.9 * 0.5 * 100) / PERFORMANCE_DENOMINATOR) * 100
    expect(performanceScore([record({ outcome: 'pass', score: 0.9, difficulty: 0.5 })])).toBeCloseTo(expected, 10)
  })

  it('performanceScore: 从高到低按 0.95 几何衰减，与记录顺序无关', () => {
    const a = [
      record({ outcome: 'pass', score: 1, difficulty: 0.3 }),
      record({ outcome: 'pass', score: 0.5, difficulty: 0.9 }),
    ]
    const b = [...a].reverse()
    // 单题表现分: 30 / 45 → 降序 45, 30；分子 = 45 + 30×0.95
    const expected = ((45 + 30 * 0.95) / PERFORMANCE_DENOMINATOR) * 100
    expect(performanceScore(a)).toBeCloseTo(expected, 10)
    expect(performanceScore(b)).toBeCloseTo(expected, 10)
  })

  it('performanceScore: 不足 100 题的位次按 0 分计（固定归一化）', () => {
    // 2 题满分 + 其余 98 个空位按 0 分：分子 = 100 + 100×0.95
    const history = [
      record({ outcome: 'pass', score: 1, difficulty: 1 }),
      record({ outcome: 'pass', score: 1, difficulty: 1 }),
    ]
    const expected = ((100 + 100 * 0.95) / PERFORMANCE_DENOMINATOR) * 100
    expect(performanceScore(history)).toBeCloseTo(expected, 10)
  })

  it('performanceScore: 100 题满分为 100', () => {
    const history = Array.from({ length: 100 }, (_, i) =>
      record({ id: `p${i}`, title: `满分 ${i}`, outcome: 'pass', score: 1, difficulty: 1 }),
    )
    expect(performanceScore(history)).toBeCloseTo(100, 10)
  })

  it('performanceScore: 放弃/未通过按 0 分计，不改变总分', () => {
    const only = [record({ outcome: 'pass', score: 1, difficulty: 1 })]
    const withZeros = [
      record({ outcome: 'pass', score: 1, difficulty: 1 }),
      record({ outcome: 'fail', score: null, difficulty: 0.5 }),
      record({ outcome: 'giveup', score: null, difficulty: 0.9 }),
    ]
    expect(performanceScore(withZeros)).toBeCloseTo(performanceScore(only), 10)
  })

  it('performanceScore: 只取前 100 高，尾部记录不影响', () => {
    const top = Array.from({ length: 100 }, (_, i) =>
      record({ id: `t${i}`, title: `满分 ${i}`, outcome: 'pass', score: 1, difficulty: 1 }),
    )
    const tail = Array.from({ length: 5 }, (_, i) =>
      record({ id: `z${i}`, title: `零分 ${i}`, outcome: 'fail', score: null, difficulty: 1 }),
    )
    expect(performanceScore(top)).toBeCloseTo(100, 10)
    expect(performanceScore([...top, ...tail])).toBeCloseTo(100, 10)
  })

  it('performanceScore: 第 100 名之后的记录被截断', () => {
    const top = Array.from({ length: 101 }, (_, i) =>
      record({ id: `t${i}`, title: `满分 ${i}`, outcome: 'pass', score: 1, difficulty: 1 }),
    )
    const zero = record({ id: 'z0', title: '零分', outcome: 'fail', score: null, difficulty: 1 })
    expect(performanceScore([...top, zero])).toBeCloseTo(100, 10)
  })

  it('performanceContributions: 按单题表现分降序、权重 0.95^(rank-1)、贡献之和 = 总表现分', () => {
    const history = [
      record({ id: 'a', title: 'A', outcome: 'pass', score: 1, difficulty: 0.3 }),
      record({ id: 'b', title: 'B', outcome: 'pass', score: 0.5, difficulty: 0.9 }),
      record({ id: 'c', title: 'C', outcome: 'fail', score: null, difficulty: 0.8 }),
    ]
    const items = performanceContributions(history)
    expect(items.map((i) => i.record.id)).toEqual(['b', 'a', 'c'])
    expect(items[0]?.points).toBeCloseTo(45)
    expect(items[0]?.weight).toBeCloseTo(1)
    expect(items[1]?.points).toBeCloseTo(30)
    expect(items[1]?.weight).toBeCloseTo(0.95)
    expect(items[2]?.points).toBeCloseTo(0)
    expect(items[2]?.weight).toBeCloseTo(0.95 * 0.95)
    expect(items[0]?.contribution).toBeCloseTo(((45 * 1) / PERFORMANCE_DENOMINATOR) * 100, 10)
    const sum = items.reduce((acc, i) => acc + i.contribution, 0)
    expect(sum).toBeCloseTo(performanceScore(history), 10)
  })

  it('performanceContributions: 最多返回前 100 题，超出部分不进入分解', () => {
    const history = Array.from({ length: 105 }, (_, i) =>
      record({ id: `t${i}`, title: `题 ${i}`, outcome: 'pass', score: 1, difficulty: 1 }),
    )
    const items = performanceContributions(history)
    expect(items).toHaveLength(100)
    expect(items[0]?.weight).toBeCloseTo(1)
    expect(items[99]?.weight).toBeCloseTo(Math.pow(0.95, 99), 10)
    expect(performanceScore(history)).toBeCloseTo(100, 10)
  })

  it('deriveStats 结果类指标由逐题记录计算，事件计数保留聚合', () => {
    const stats: GufaStats = {
      ...emptyStats(0),
      offers: 5,
      accepts: 3,
      skips: 1,
      exits: 1,
      // 聚合里的旧结果类数值应被忽略
      passes: 99,
      attempts: 99,
    }
    const history = [
      record({ outcome: 'pass', mode: 'polish', score: 0.93, difficulty: 0.35, attempts: 1, hintsUsed: 1, maxHints: 4 }),
      record({ outcome: 'pass', mode: 'polish', score: 0.93, difficulty: 0.4, attempts: 1, hintsUsed: 1, maxHints: 4 }),
      record({ outcome: 'pass', mode: 'polish', score: 0.9, difficulty: 0.45, attempts: 1, hintsUsed: 0, maxHints: 5 }),
    ]
    const display = deriveStats(stats, history)
    expect(display).toMatchObject({
      offers: 5,
      accepts: 3,
      skips: 1,
      exits: 1,
      passes: 3,
      attempts: 3,
      hintsUsed: 2,
      hintsBudget: 13,
      scoreCount: 3,
      difficultyCount: 3,
    })
    expect(display.modes.polish).toBe(3)
    expect(display.scoreSum).toBeCloseTo(2.76)
    expect(display.weightedScoreSum).toBeCloseTo(0.93 * 0.35 + 0.93 * 0.4 + 0.9 * 0.45)
  })
})
