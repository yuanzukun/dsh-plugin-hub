import { describe, expect, it } from 'vitest'
import { emptyStats } from '../src/shared/state'
import {
  recordAccept,
  recordCancel,
  recordExit,
  recordFailGiveUp,
  recordGiveUp,
  recordHint,
  recordOffer,
  recordPass,
  recordSkip,
  recordSubmit,
} from '../src/host/stats'

describe('stats 纯记录函数', () => {
  it('offer/accept/skip 与接受率分母', () => {
    let s = emptyStats(0)
    s = recordOffer(s, 1)
    s = recordOffer(s, 2)
    s = recordAccept(s, 0.3, 4, 3)
    s = recordSkip(s, 4)
    expect(s).toMatchObject({ offers: 2, accepts: 1, skips: 1, updatedAt: 4 })
    expect(s.difficultySum).toBeCloseTo(0.3)
    expect(s.difficultyCount).toBe(1)
    expect(s.hintsBudget).toBe(4)
  })

  it('submit/hint 单调计数，提示允许超支', () => {
    let s = emptyStats(0)
    s = recordSubmit(recordSubmit(s, 1), 2)
    s = recordHint(recordHint(s, 3), 4)
    expect(s).toMatchObject({ attempts: 2, hintsUsed: 2 })
  })

  it('giveUp 与 failGiveUp 都计入 takeover 收尾', () => {
    let s = emptyStats(0)
    s = recordGiveUp(s, 1)
    s = recordFailGiveUp(s, 0.1, 2)
    expect(s).toMatchObject({ giveUps: 1, fails: 1, giveUpsAfterFail: 1 })
    expect(s.modes).toMatchObject({ takeover: 2 })
    expect(s.difficultySum).toBeCloseTo(0.1)
  })

  it('recordPass 记录分数、收尾方式与难度加权（分母只含已评分题）', () => {
    let s = emptyStats(0)
    s = recordAccept(s, 0.5, 3, 1)
    s = recordPass(s, { score: 0.8, finalDifficulty: 0.6, difficultyDelta: 0.1, mode: 'keep' }, 2)
    expect(s).toMatchObject({ passes: 1, scoreCount: 1, modes: { keep: 1, polish: 0, rewrite: 0, takeover: 0 } })
    expect(s.scoreSum).toBeCloseTo(0.8)
    expect(s.weightedScoreSum).toBeCloseTo(0.8 * 0.6)
    expect(s.scoredDifficultySum).toBeCloseTo(0.6)
    expect(s.difficultySum).toBeCloseTo(0.6)
    // 难度加权评分 = Σ(score × difficulty) / Σ(difficulty，仅已评分题目)
    expect(s.weightedScoreSum / s.scoredDifficultySum).toBeCloseTo(0.8)
  })

  it('exit 只记录主动中止', () => {
    const s = recordExit(emptyStats(0), 1)
    expect(s.exits).toBe(1)
  })

  it('recordCancel 回滚本题全部足迹，收尾分布不计数', () => {
    // 模拟：出题 → 接受（难度 0.4、预算 3）→ 提交 2 次 → 提示 1 次 → 作废
    let s = emptyStats(0)
    s = recordOffer(s, 1)
    s = recordAccept(s, 0.4, 3, 2)
    s = recordSubmit(recordSubmit(s, 3), 4)
    s = recordHint(s, 5)
    s = recordCancel(
      s,
      { offered: true, accepted: true, difficulty: 0.4, maxHints: 3, attempts: 2, hintsUsed: 1 },
      6,
    )
    expect(s).toMatchObject({ offers: 0, accepts: 0, attempts: 0, hintsUsed: 0, hintsBudget: 0, exits: 0 })
    expect(s.difficultySum).toBeCloseTo(0)
    expect(s.difficultyCount).toBe(0)
    expect(s.modes).toEqual({ keep: 0, polish: 0, rewrite: 0, takeover: 0 })
    expect(s.updatedAt).toBe(6)
  })

  it('recordCancel 出题阶段作废只回滚 offers；减法钳制到 0', () => {
    let s = emptyStats(0)
    s = recordOffer(s, 1)
    s = recordCancel(s, { offered: true, accepted: false, difficulty: 0.4, maxHints: 3, attempts: 0, hintsUsed: 0 }, 2)
    expect(s).toMatchObject({ offers: 0, accepts: 0 })
    // 防御：stats 不足时不会减成负数
    s = recordCancel(s, { offered: true, accepted: true, difficulty: 0.4, maxHints: 3, attempts: 5, hintsUsed: 5 }, 3)
    expect(s).toMatchObject({ offers: 0, accepts: 0, attempts: 0, hintsUsed: 0, hintsBudget: 0 })
    expect(s.difficultySum).toBeCloseTo(0)
    expect(s.difficultyCount).toBe(0)
  })

  it('记录不修改输入（纯函数）', () => {
    const before = emptyStats(0)
    const after = recordOffer(before, 1)
    expect(before.offers).toBe(0)
    expect(after.offers).toBe(1)
  })
})
