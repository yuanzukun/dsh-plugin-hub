import { describe, expect, it } from 'vitest'
import type { GufaState } from '../src/shared/state'
import { decodeGufaChange } from '../src/host/domain'
import { setChallenge } from '../src/host/challenge-store'

function baseState(overrides: Partial<GufaState> = {}): GufaState {
  return {
    phase: 'offering',
    title: '测试题',
    summary: '实现一个函数',
    language: 'typescript',
    files: ['src/demo.ts'],
    scope: '',
    attempts: 0,
    maxHints: 3,
    hintsUsed: 0,
    difficulty: 0.4,
    score: null,
    solutionMode: null,
    updatedAt: 1000,
    ...overrides,
  }
}

describe('challenges 表纯操作（settings 键控持久化）', () => {
  it('写入一格的挑战状态', () => {
    const next = setChallenge({ 's-1': baseState() }, 's-2', baseState({ phase: 'solving' }))
    expect(next).toMatchObject({
      's-1': expect.any(Object),
      's-2': { phase: 'solving' },
    })
    // 不修改输入
    expect(setChallenge({}, 's-1', baseState())).not.toBe({})
  })

  it('null 清除并删除键', () => {
    const before = { 's-1': baseState(), 's-2': baseState() }
    const next = setChallenge(before, 's-1', null)
    expect(next).toEqual({ 's-2': baseState() })
    expect('s-1' in before).toBe(true)
  })

  it('非法数据解码为 undefined（读取时视为无挑战）', () => {
    expect(decodeGufaChange({ phase: 'solving' })).toBeUndefined()
    expect(decodeGufaChange({ ...baseState(), maxHints: 0 })).toBeUndefined()
    expect(decodeGufaChange('garbage')).toBeUndefined()
  })

  it('合法整值与 null 墓碑正常解码', () => {
    expect(decodeGufaChange(baseState())).toEqual(baseState())
    expect(decodeGufaChange(null)).toBeNull()
  })
})
