import { describe, expect, it } from 'vitest'
import { MAX_HINTS_LIMIT, type GufaState } from '../src/shared/state'
import {
  consumeHint,
  continueAfterFail,
  recordScore,
  reviseDifficulty,
  startSolving,
  submitChallenge,
  takeOver,
} from '../src/host/transitions'
import { decodeGufaChange } from '../src/host/domain'

function baseState(overrides: Partial<GufaState> = {}): GufaState {
  return {
    phase: 'offering',
    title: '测试题',
    summary: '实现一个函数',
    language: 'typescript',
    files: ['src/demo.ts'],
    scope: '',
    attempts: 0,
    maxHints: 3,
    hintsUsed: 0,
    difficulty: 0.4,
    score: null,
    solutionMode: null,
    updatedAt: 1000,
    ...overrides,
  }
}

describe('transitions', () => {
  it('startSolving 重置尝试与提示消耗，保留预算/难度/范围', () => {
    const next = startSolving(baseState({ attempts: 3, hintsUsed: 2, maxHints: 5 }), 2000)
    expect(next).toMatchObject({
      phase: 'solving',
      attempts: 0,
      hintsUsed: 0,
      maxHints: 5,
      difficulty: 0.4,
      solutionMode: null,
      updatedAt: 2000,
    })
  })

  it('submitChallenge 计数并进入 reviewing', () => {
    const solving = startSolving(baseState(), 2000)
    const next = submitChallenge(solving, 3000)
    expect(next).toMatchObject({ phase: 'reviewing', attempts: 1, updatedAt: 3000 })
  })

  it('continueAfterFail 回到答题且不扣提示预算', () => {
    const reviewing = baseState({ phase: 'reviewing', hintsUsed: 2, maxHints: 3 })
    const next = continueAfterFail(reviewing, 4000)
    expect(next).toMatchObject({ phase: 'solving', hintsUsed: 2, maxHints: 3 })
  })

  it('consumeHint 每次求助扣一次且允许超支', () => {
    const maxed = baseState({ phase: 'solving', maxHints: MAX_HINTS_LIMIT, hintsUsed: 0 })
    const first = consumeHint(maxed, 4000)
    expect(first.hintsUsed).toBe(1)
    const overspent = consumeHint(baseState({ phase: 'solving', maxHints: 1, hintsUsed: 1 }), 4000)
    expect(overspent.hintsUsed).toBe(2)
  })

  it('reviseDifficulty 与 recordScore 落定验收事实', () => {
    const revised = reviseDifficulty(baseState(), 0.7, 4000)
    expect(revised.difficulty).toBe(0.7)
    const scored = recordScore(revised, 0.85, 4000)
    expect(scored.score).toBe(0.85)
  })

  it('takeOver 记录接手方式', () => {
    const next = takeOver(baseState({ phase: 'solving' }), 'polish', 5000)
    expect(next).toMatchObject({ phase: 'solution', solutionMode: 'polish', updatedAt: 5000 })
  })
})

describe('decodeGufaChange', () => {
  it('接受合法整值状态', () => {
    const decoded = decodeGufaChange(baseState())
    expect(decoded).toEqual(baseState())
  })

  it('接受 null 墓碑', () => {
    expect(decodeGufaChange(null)).toBeNull()
  })

  it('兼容 stateVersion=1 旧事件（hintLevel 被丢弃，新字段回落默认）', () => {
    const legacy = {
      phase: 'solving',
      title: '旧题',
      summary: '旧说明',
      language: 'ts',
      files: ['src/a.ts'],
      attempts: 1,
      hintLevel: 2,
      solutionMode: null,
      updatedAt: 1000,
    }
    const decoded = decodeGufaChange(legacy)
    expect(decoded).toMatchObject({
      phase: 'solving',
      title: '旧题',
      attempts: 1,
      scope: '',
      maxHints: 3,
      hintsUsed: 0,
      difficulty: 0.5,
      score: null,
    })
    expect(decoded).not.toHaveProperty('hintLevel')
  })

  it('拒绝非法数据', () => {
    expect(decodeGufaChange({ phase: 'solving' })).toBeUndefined()
    expect(decodeGufaChange({ ...baseState(), difficulty: 2 })).toBeUndefined()
    expect(decodeGufaChange({ ...baseState(), maxHints: 0 })).toBeUndefined()
    expect(decodeGufaChange('garbage')).toBeUndefined()
  })
})
