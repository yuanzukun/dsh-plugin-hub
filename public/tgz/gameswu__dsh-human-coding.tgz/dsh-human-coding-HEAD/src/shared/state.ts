/**
 * 古法编程模式的纯状态模型：只含类型与常量，不依赖任何运行时包。
 *
 * Host 侧把它作为会话投影（`gufa` projection）的整值状态写入会话日志；
 * Client 侧通过 `useProjection('gufa')` 读取同一份状态。跨会话的用户
 * 表现统计（`GufaStats`）不进入会话投影，而是由 Host 侧持久化到
 * settings 命名空间，Client 经 `settingsScope` 读取。
 */

/** 挑战进行中的四个阶段（无活动题目时投影为 `null`，即普通模式）。 */
export type GufaPhase = 'offering' | 'solving' | 'reviewing' | 'solution'

/** AI 接手实现时的三种方式。 */
export type SolutionMode = 'takeover' | 'polish' | 'rewrite'

/** 验收通过后用户的收尾方式（keep 不是 AI 接手，单独计数）。 */
export type ClosingMode = SolutionMode | 'keep'

/** 会话投影的整值状态：每次变更写入完整的新状态（last-wins）。 */
export interface GufaState {
  /** 当前阶段。 */
  phase: GufaPhase
  /** 题目标题（简短）。 */
  title: string
  /** 题目说明：需求、骨架位置、待补全点。 */
  summary: string
  /** 语言 / 技术栈。 */
  language: string
  /**
   * 骨架涉及的文件路径（相对工作区）。出题时必填：骨架必须先写入
   * 真实项目文件，这是「请求确实涉及编码」的硬闸门。
   */
  files: string[]
  /**
   * 本题覆盖范围说明：大请求只挑一块出题时，写明本块是什么、
   * 其余部分何时/如何完成。空串表示请求整体即本题。
   */
  scope: string
  /** 已提交验收次数。 */
  attempts: number
  /** 本题提示预算：出题时由模型决定，1..MAX_HINTS_LIMIT。 */
  maxHints: number
  /** 已消耗的提示次数：答题期间每次求助（gufa_hint）扣一次。 */
  hintsUsed: number
  /**
   * 归一化难度（0..1）：出题时模型自评，验收时可通过 gufa_decide
   * 修正。
   */
  difficulty: number
  /**
   * 完成度分数（0..1）：验收通过时由模型给出；未评分时为 null。
   * 最终总分计算规则另行约定。
   */
  score: number | null
  /** 仅在 phase === 'solution' 时有意义。 */
  solutionMode: SolutionMode | null
  /** 最近一次状态变更时间（epoch ms）。 */
  updatedAt: number
}

/** 提示预算缺省值（模型未指定 max_hints 时）。 */
export const DEFAULT_MAX_HINTS = 3

/** 提示预算上限：防止模型设置离谱的预算。 */
export const MAX_HINTS_LIMIT = 20

/**
 * 注意：挑战状态不写入会话日志。dsh-session-persistence 只接受内置
 * 事件类型或带 `ignorable` 信封标记的事件，而 `Session.append` 无法
 * 设置该标记——仓库外插件写自定义会话事件会导致会话拒绝打开。
 * 因此挑战状态由 Host 侧持久化到 settings 命名空间，按会话 id 键控。
 */

/** 会话投影键名：Client 用 `useProjection('gufa')` 读取。 */
export const GUFA_PROJECTION = 'gufa'

/** settings 命名空间：跨会话的用户表现统计与插件配置。 */
export const GUFA_SETTINGS_NS = 'dsh-human-coding'

/** 阶段的中文展示标签。 */
export const PHASE_LABELS: Record<GufaPhase, string> = {
  offering: '出题中',
  solving: '答题中',
  reviewing: '验收中',
  solution: 'AI 接手',
}

/** 出题提问的选项值。 */
export const OFFER_ACCEPT = 'accept'
export const OFFER_SKIP = 'skip'

/** 验收不通过时提问的选项值。 */
export const RETRY_CONTINUE = 'continue'
export const RETRY_GIVE_UP = 'give_up'

/** 验收通过时提问的选项值。 */
export const PASS_KEEP = 'keep'
export const PASS_POLISH = 'polish'
export const PASS_REWRITE = 'rewrite'

/**
 * 跨会话的用户表现统计：Host 侧记录原始计数，比率与加权评分由
 * Client 侧即时推导。所有字段单调不减（reset 清零除外）。
 */
export interface GufaStats {
  /** 出题提议次数（含被跳过与拒绝的）。 */
  offers: number
  /** 接受挑战次数。 */
  accepts: number
  /** 跳过挑战次数。 */
  skips: number
  /** 验收通过的挑战数。 */
  passes: number
  /** 验收不通过（失败后放弃）的挑战数。 */
  fails: number
  /** 答题阶段直接放弃的次数。 */
  giveUps: number
  /** 验收不通过后放弃的次数。 */
  giveUpsAfterFail: number
  /** 主动中止（gufa_exit）的次数。 */
  exits: number
  /** 收尾方式分布。 */
  modes: Record<ClosingMode, number>
  /** 提交验收总次数。 */
  attempts: number
  /** 消耗的提示总次数。 */
  hintsUsed: number
  /** 提示预算总和（接受挑战时累计）。 */
  hintsBudget: number
  /** 完成度分数总和（0..1 × 已评分题数）。 */
  scoreSum: number
  /** 已评分的挑战数（即 passes）。 */
  scoreCount: number
  /** 最终难度总和（出题自评、验收可修正）。 */
  difficultySum: number
  /** 已记录难度的挑战数（即 accepts）。 */
  difficultyCount: number
  /** Σ(完成度分数 × 最终难度)：难度加权评分的分子。 */
  weightedScoreSum: number
  /** Σ(最终难度)（仅已评分题目）：难度加权评分的分母。 */
  scoredDifficultySum: number
  /** 最近一次更新（epoch ms）。 */
  updatedAt: number
}

/** 零值统计。 */
export function emptyStats(now: number = Date.now()): GufaStats {
  return {
    offers: 0,
    accepts: 0,
    skips: 0,
    passes: 0,
    fails: 0,
    giveUps: 0,
    giveUpsAfterFail: 0,
    exits: 0,
    modes: { keep: 0, polish: 0, rewrite: 0, takeover: 0 },
    attempts: 0,
    hintsUsed: 0,
    hintsBudget: 0,
    scoreSum: 0,
    scoreCount: 0,
    difficultySum: 0,
    difficultyCount: 0,
    weightedScoreSum: 0,
    scoredDifficultySum: 0,
    updatedAt: now,
  }
}

/** settings 命名空间的节面：跨会话统计 + 逐题数值记录 + 按会话 id 键控的挑战状态。 */
export interface GufaSettings {
  stats: GufaStats
  history: GufaChallengeRecord[]
  challenges: Record<string, GufaState | null>
}

/** 逐题结算结果。 */
export type ChallengeOutcome = 'pass' | 'fail' | 'giveup'

/**
 * 逐题数值记录：每道结算的挑战一条，是导出/导入（含按题目去重的
 * 叠加合并）与统计重算的最小粒度。
 */
export interface GufaChallengeRecord {
  /** 记录唯一 id（本机内唯一；跨机去重按标题）。 */
  id: string
  title: string
  outcome: ChallengeOutcome
  /** 收尾方式（pass→keep/polish/rewrite；放弃→takeover）。 */
  mode: ClosingMode
  /** 完成度分数（仅 pass 有值）。 */
  score: number | null
  /** 最终难度（验收可修正）。 */
  difficulty: number
  /** 本题提交验收次数。 */
  attempts: number
  /** 本题消耗提示次数。 */
  hintsUsed: number
  /** 本题提示预算。 */
  maxHints: number
  updatedAt: number
}

/** 导出文件格式（仅数值记录，不含会话历史）。 */
export interface GufaExport {
  schema: 'dsh-human-coding-stats'
  version: 1
  exportedAt: number
  stats: GufaStats
  history: GufaChallengeRecord[]
}
