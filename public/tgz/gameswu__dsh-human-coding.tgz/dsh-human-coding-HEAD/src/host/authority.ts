/**
 * 工具执行权限：沿用内置 goal 工具的模式 ——
 * 状态变更只接受「确切的活体调用 agent + 当前驱动」，
 * 且必须来自一个顶层 agent 的直接人类消息轮次。
 */
import type { Agent } from '@deepseek-ai/dsh-agent'
import type { ToolRunContext } from '@deepseek-ai/dsh-tools'
import { HarnessError } from '@deepseek-ai/dsh-llm'
import type { SessionEvent } from '@deepseek-ai/dsh-session'
import type { GufaContext } from './context'

function reject(message: string, code: string): never {
  throw new HarnessError(message, code)
}

/** 校验调用 agent 是注册表里的活体实例且正处于其活动驱动中。 */
export function liveAgent(ctx: GufaContext, exec: ToolRunContext): Agent {
  const agent = exec.agent
  if (agent === undefined) {
    return reject('gufa tools require a calling agent', 'GUFA_AGENT_REQUIRED')
  }
  if (
    ctx.agents.get(agent.id) !== agent ||
    agent.status !== 'running' ||
    ctx.agents.currentInitiator() !== agent
  ) {
    return reject(
      'gufa tools require the exact live calling agent inside its active driver',
      'GUFA_DRIVER_REQUIRED',
    )
  }
  return agent
}

/** 当前开启轮次内的事件（自最近一次 turn/start 起）。 */
export function openTurnEvents(agent: Agent): readonly SessionEvent[] {
  const events = agent.session.snapshotEvents()
  for (let index = events.length - 1; index >= 0; index -= 1) {
    const event = events[index]
    if (event?.type === 'turn/end') {
      return reject('gufa tools require an open model turn', 'GUFA_TURN_REQUIRED')
    }
    if (event?.type === 'turn/start') return events.slice(index + 1)
  }
  return reject('gufa tools require an open model turn', 'GUFA_TURN_REQUIRED')
}

/**
 * 状态变更要求：顶层 agent 的当前轮次中存在直接人类消息
 * （来源 kind === 'user'，排除 goal 轮次 / 插件注入等自动来源）。
 *
 * Agent Teams（DSH 0.1.5-rc.1）下 teammate 不是运行时根 agent：它能通过
 * {@link liveAgent} 的活体校验，但任何状态变更都会在这里以
 * GUFA_ROOT_REQUIRED 拒绝；Lead（根 agent）不受影响。只读的 gufa_status
 * 不经过本函数。详见 README「与 Agent Teams 的交互」。
 */
export function requireHumanTurn(ctx: GufaContext, agent: Agent): void {
  if (!ctx.agents.roots().includes(agent)) {
    return reject('gufa state changes require a top-level agent', 'GUFA_ROOT_REQUIRED')
  }
  const events = openTurnEvents(agent)
  const hasHuman = events.some(
    (event) => event.type === 'user/message' && event.data.source.kind === 'user',
  )
  if (!hasHuman) {
    return reject(
      'gufa state changes require a direct human turn',
      'GUFA_HUMAN_REQUIRED',
    )
  }
}
