/**
 * gufa_cancel：作废当前挑战——题目本身有缺陷（骨架写错、需求不再成立等）
 * 时直接把题目作废。本题**不留任何记录**：不写逐题 history，并回滚
 * 出题/接受以来已入账的全部计数，回到普通模式。项目文件保留。
 */
import { defineTool } from '@deepseek-ai/dsh-tools'
import { HarnessError } from '@deepseek-ai/dsh-llm'
import { liveAgent, requireHumanTurn } from '../authority'
import type { ChallengeStore } from '../challenge-store'
import type { GufaContext } from '../context'
import { recordCancel, type StatsRecorder } from '../stats'
import { STRING_OUTPUT, outcomeText, present } from './support'

export function registerCancelTool(ctx: GufaContext, stats: StatsRecorder, challenges: ChallengeStore): void {
  ctx.tools.register(
    defineTool({
      name: 'gufa_cancel',
      description:
        '古法编程模式：作废当前挑战（题目本身有缺陷、骨架写错、需求不再成立等）。清除挑战状态，回滚本题已累计的统计（提议/接受/难度/提示预算/提交/提示消耗），不写入任何逐题记录。仅对出题中/答题中/验收中的挑战有效；已收尾（AI 接手阶段）的挑战请用 gufa_exit 清扫状态。',
      parameters: {
        reason: {
          type: 'string',
          required: true,
          description: '作废原因（会展示给用户，如「骨架文件写错了位置」）。',
        },
      },
      output: STRING_OUTPUT,
      async execute(args, exec) {
        const agent = liveAgent(ctx, exec)
        requireHumanTurn(ctx, agent)
        const state = challenges.current(agent)
        if (state === null) {
          throw new HarnessError('当前没有活动挑战，无需作废。', 'GUFA_NOT_ACTIVE')
        }
        if (state.phase === 'solution') {
          throw new HarnessError(
            '挑战已收尾（AI 接手阶段），逐题记录已入账；如需清扫状态请用 gufa_exit。',
            'GUFA_ALREADY_SETTLED',
          )
        }
        const accepted = state.phase !== 'offering'
        stats.record((s) =>
          recordCancel(s, {
            offered: true,
            accepted,
            difficulty: state.difficulty,
            maxHints: state.maxHints,
            attempts: state.attempts,
            hintsUsed: state.hintsUsed,
          }),
        )
        challenges.write(agent, null)
        return outcomeText(
          `已作废挑战「${state.title}」（原因：${String(args.reason).trim()}）。本题不留任何统计与逐题记录，回到普通模式。项目中的骨架与用户代码保留。`,
          null,
        )
      },
      presentCall: (args) => present('作废挑战', args.reason),
    }),
  )
}
