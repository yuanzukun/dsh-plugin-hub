/**
 * gufa_offer：注册一道挑战并交互式询问「接受挑战 / 跳过」。
 *
 * 前置：模型已把骨架（含 TODO 标记）与测试写入真实项目文件。
 * 硬闸门：files 必填且非空 —— 没有真实骨架文件就不允许出题，
 * 这同时挡住「非编码请求」与「纸上谈兵」两类误触发。
 * 可重入：提问无应答时状态停留在 offering，可再次调用。
 */
import { defineTool } from '@deepseek-ai/dsh-tools'
import { HarnessError } from '@deepseek-ai/dsh-llm'
import {
  DEFAULT_MAX_HINTS,
  MAX_HINTS_LIMIT,
  OFFER_ACCEPT,
  OFFER_SKIP,
  type GufaState,
} from '../../shared/state'
import { askOne, selected } from '../ask'
import { liveAgent, requireHumanTurn } from '../authority'
import type { ChallengeStore } from '../challenge-store'
import type { GufaContext } from '../context'
import { recordAccept, recordOffer, recordSkip, type StatsRecorder } from '../stats'
import { startSolving } from '../transitions'
import { STRING_OUTPUT, outcomeText, present } from './support'

export function registerOfferTool(ctx: GufaContext, stats: StatsRecorder, challenges: ChallengeStore): void {
  ctx.tools.register(
    defineTool({
      name: 'gufa_offer',
      description:
        '古法编程模式：向用户提议一道编程挑战（骨架已写入真实项目文件）。工具会交互式询问用户接受挑战还是跳过；接受则进入答题阶段，跳过则像正常模式一样直接完成需求。只对需要写多行真实实现代码的编码请求出题；纯问答、配置调整、单行修改不得出题。',
      parameters: {
        title: {
          type: 'string',
          required: true,
          description: '简短题目标题。',
        },
        summary: {
          type: 'string',
          required: true,
          description:
            '题目说明：需求是什么、骨架写在哪些文件、用户需要补全哪些 TODO 点。',
        },
        files: {
          type: 'array',
          items: { type: 'string' },
          required: true,
          description:
            '骨架涉及的文件路径（必填，至少一个）：出题前必须已把骨架（含 TODO 标记）与测试写入真实项目文件。',
        },
        language: {
          type: 'string',
          description: '语言 / 技术栈（可选）。',
        },
        scope: {
          type: 'string',
          description:
            '本题覆盖范围（可选）：请求较大、涉及多处修改时，只挑其中一块出题，写明本块是什么、其余部分在挑战结束后由 AI 正常实现（或另行出题）。请求整体即本题时可省略。',
        },
        max_hints: {
          type: 'number',
          description:
            '本题提示预算（可选整数，1-20，缺省 3）：答题期间用户每次求助扣一次，按已用/预算比例递进提示具体度。',
        },
        difficulty: {
          type: 'number',
          required: true,
          description:
            '归一化难度自评（0-1）：0 最易、1 最难，按题目规模与你对用户技能水平的估计给出；验收时可修正。',
        },
      },
      output: STRING_OUTPUT,
      async execute(args, exec) {
        const agent = liveAgent(ctx, exec)
        requireHumanTurn(ctx, agent)
        const current = challenges.current(agent)
        if (current !== null && current.phase !== 'offering') {
          throw new HarnessError(
            '已有一道进行中的挑战，先完成、gufa_exit 或等其结束再出题。',
            'GUFA_BUSY',
          )
        }
        const files = Array.isArray(args.files) ? args.files.map(String).filter((f) => f.trim() !== '') : []
        if (files.length === 0) {
          throw new HarnessError(
            '出题前必须先把骨架（含 TODO 标记）与测试写入真实项目文件，并在 files 中列出这些文件。没有真实代码文件的请求不能作为挑战。',
            'GUFA_FILES_REQUIRED',
          )
        }
        const difficulty = Number(args.difficulty)
        if (!Number.isFinite(difficulty) || difficulty < 0 || difficulty > 1) {
          throw new HarnessError(
            'difficulty 必须是 0..1 的归一化难度自评。',
            'GUFA_BAD_DIFFICULTY',
          )
        }
        const maxHintsRaw = Number(args.max_hints ?? DEFAULT_MAX_HINTS)
        const maxHints = Number.isFinite(maxHintsRaw)
          ? Math.min(MAX_HINTS_LIMIT, Math.max(1, Math.round(maxHintsRaw)))
          : DEFAULT_MAX_HINTS
        const offering: GufaState = {
          phase: 'offering',
          title: String(args.title).trim(),
          summary: String(args.summary).trim(),
          language: typeof args.language === 'string' ? args.language : '',
          files,
          scope: typeof args.scope === 'string' ? args.scope.trim() : '',
          attempts: 0,
          maxHints,
          hintsUsed: 0,
          difficulty,
          score: null,
          solutionMode: null,
          updatedAt: Date.now(),
        }
        // 首次注册才计一次提议；提问无应答后的重入（phase 仍是
        // offering）不重复计 offers。
        const firstOffer = current === null
        challenges.write(agent, offering)
        if (firstOffer) stats.record(recordOffer)

        const answer = await askOne(ctx, agent, exec.signal, {
          header: '古法编程 · 挑战',
          question: '是否接受这道编程挑战？',
          options: [
            {
              label: '接受挑战',
              description: 'AI 只答疑、给渐进提示，由你补全实现。',
            },
            {
              label: '跳过',
              description: 'AI 像正常模式一样直接完成需求。',
            },
          ],
        })
        if (answer === null) {
          return outcomeText(
            '没有可用的交互式提问界面。请用文字询问用户「接受挑战还是跳过」，得到回答后再次调用 gufa_offer（接受则继续本流程，跳过则清除挑战并正常实现）。',
            challenges.current(agent),
          )
        }
        if (selected(answer, OFFER_SKIP)) {
          stats.record(recordSkip)
          challenges.write(agent, null)
          return outcomeText(
            '用户选择跳过：挑战已清除，像正常编码 Agent 一样直接实现该需求。',
            null,
          )
        }
        stats.record((s) => recordAccept(s, difficulty, maxHints))
        const solving = challenges.write(agent, startSolving(challenges.current(agent)!))
        return outcomeText(
          `用户接受挑战，已进入答题阶段（attempts=0，提示 0/${maxHints}）。现在向用户宣布：题目、涉及文件、待补全的 TODO 点、以及规则 —— 答题期间你不会代写实现，只答疑和给渐进提示（每次求助调用 gufa_hint 扣一次提示次数）；用户说「提交/验收」你调用 gufa_submit，说「放弃」你调用 gufa_give_up。`,
          solving,
        )
      },
      presentCall: (args) => present('古法出题', args.title),
    }),
  )
}
