/**
 * gufa_submit：记录一次提交（attempts+1，进入 reviewing）。
 * 之后模型跑测试、读实现、评审，再调用 gufa_decide 落定判定。
 */
import { defineTool } from '@deepseek-ai/dsh-tools'
import { HarnessError } from '@deepseek-ai/dsh-llm'
import { liveAgent, requireHumanTurn } from '../authority'
import type { ChallengeStore } from '../challenge-store'
import type { GufaContext } from '../context'
import { recordSubmit, type StatsRecorder } from '../stats'
import { submitChallenge } from '../transitions'
import { STRING_OUTPUT, outcomeText, present } from './support'

export function registerSubmitTool(ctx: GufaContext, stats: StatsRecorder, challenges: ChallengeStore): void {
  ctx.tools.register(
    defineTool({
      name: 'gufa_submit',
      description:
        '古法编程模式：用户提交验收。记录一次提交并进入验收阶段；随后你应运行测试、阅读用户实现并评审，再调用 gufa_decide 给出判定。',
      parameters: {},
      output: STRING_OUTPUT,
      async execute(_args, exec) {
        const agent = liveAgent(ctx, exec)
        requireHumanTurn(ctx, agent)
        const state = challenges.current(agent)
        if (state === null || state.phase !== 'solving') {
          throw new HarnessError(
            '当前不在答题阶段，无法提交（用 gufa_status 查看状态）。',
            'GUFA_NOT_SOLVING',
          )
        }
        const reviewing = challenges.write(agent, submitChallenge(state))
        stats.record(recordSubmit)
        return outcomeText(
          `已记录第 ${reviewing!.attempts} 次提交，进入验收阶段。现在：1) 运行测试；2) 阅读用户的实现与改动；3) 对照题目说明评审；4) 调用 gufa_decide 给出 verdict（pass/fail）与简要 feedback。`,
          reviewing,
        )
      },
      presentCall: () => present('提交验收'),
    }),
  )
}
