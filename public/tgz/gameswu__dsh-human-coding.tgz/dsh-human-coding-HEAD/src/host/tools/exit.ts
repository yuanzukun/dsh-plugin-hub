/**
 * gufa_exit：任何阶段中止挑战，回到普通模式（文件保留，只清状态）。
 */
import { defineTool } from '@deepseek-ai/dsh-tools'
import { liveAgent, requireHumanTurn } from '../authority'
import type { ChallengeStore } from '../challenge-store'
import type { GufaContext } from '../context'
import { recordExit, type StatsRecorder } from '../stats'
import { STRING_OUTPUT, outcomeText, present } from './support'

export function registerExitTool(ctx: GufaContext, stats: StatsRecorder, challenges: ChallengeStore): void {
  ctx.tools.register(
    defineTool({
      name: 'gufa_exit',
      description:
        '古法编程模式：中止当前挑战并回到普通模式。题目文件保留在项目中，仅清除挑战状态。',
      parameters: {},
      output: STRING_OUTPUT,
      async execute(_args, exec) {
        const agent = liveAgent(ctx, exec)
        requireHumanTurn(ctx, agent)
        const previous = challenges.current(agent)
        // solution 阶段说明挑战已由 giveUp/pass 收尾，exit 只是清扫状态，
        // 不再计入「主动中止」。
        if (previous !== null && previous.phase !== 'solution') stats.record(recordExit)
        challenges.write(agent, null)
        return outcomeText(
          previous === null
            ? '本来就没有活动挑战，已确保回到普通模式。'
            : `已中止挑战「${previous.title}」，回到普通模式。项目里的骨架与用户代码都保留着。`,
          null,
        )
      },
      presentCall: () => present('退出古法模式'),
    }),
  )
}
