/**
 * 工具注册的共享部件。
 *
 * 输出统一为可读文本（string schema）：状态机效果在 execute 内已落定，
 * 文本携带「下一步指示」+ 当前状态快照，模型据其继续对话。
 */
import { PHASE_LABELS, type GufaState } from '../../shared/state'

/** 组装工具输出文本：指示 + 状态快照行。 */
export function outcomeText(instruction: string, state: GufaState | null): string {
  const stateLine =
    state === null
      ? '当前无活动挑战（普通模式）。'
      : `当前状态: ${PHASE_LABELS[state.phase]} (${state.phase}) | 题目: ${state.title} | 提交次数: ${state.attempts} | 提示: ${state.hintsUsed}/${state.maxHints}`
  return `${instruction}\n\n${stateLine}`
}

/** 文本输出的统一声明与渲染。 */
export const STRING_OUTPUT = {
  schema: { type: 'string' },
  render: (_args: unknown, value: string): Array<{ type: 'text'; text: string }> => [
    { type: 'text', text: value },
  ],
} as const

/** 调用卡片展示：标题 + 原始输入摘录。 */
export function present(title: string, rawInput?: unknown): {
  card: 'generic'
  title: string
  kind: 'other'
  rawInput?: unknown
} {
  return {
    card: 'generic',
    title,
    kind: 'other',
    ...(rawInput === undefined ? {} : { rawInput }),
  }
}
