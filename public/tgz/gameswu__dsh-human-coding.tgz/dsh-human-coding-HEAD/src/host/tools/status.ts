/**
 * gufa_status：只读查询当前挑战状态。
 */
import { defineTool } from '@deepseek-ai/dsh-tools'
import { PHASE_LABELS, type GufaState } from '../../shared/state'
import { liveAgent } from '../authority'
import type { ChallengeStore } from '../challenge-store'
import type { GufaContext } from '../context'
import { STRING_OUTPUT, present } from './support'

function describe(state: GufaState): string {
  return [
    `阶段: ${PHASE_LABELS[state.phase]} (${state.phase})`,
    `题目: ${state.title}`,
    `语言: ${state.language || '(未指定)'}`,
    `涉及文件: ${state.files.length > 0 ? state.files.join(', ') : '(未记录)'}`,
    state.scope !== '' ? `覆盖范围: ${state.scope}` : '',
    `已提交次数: ${state.attempts}`,
    `提示: ${state.hintsUsed}/${state.maxHints}`,
    `难度(0-1): ${state.difficulty}`,
    state.score !== null ? `完成度分数(0-1): ${state.score}` : '',
    state.phase === 'solution' && state.solutionMode !== null
      ? `接手方式: ${state.solutionMode}`
      : '',
    `题目说明: ${state.summary}`,
  ]
    .filter((line) => line !== '')
    .join('\n')
}

export function registerStatusTool(ctx: GufaContext, challenges: ChallengeStore): void {
  ctx.tools.register(
    defineTool({
      name: 'gufa_status',
      description:
        '古法编程模式：查询当前挑战的阶段、题目、提交次数、提示消耗与预算、难度与完成度分数（只读）。',
      parameters: {},
      output: STRING_OUTPUT,
      async execute(_args, exec) {
        const agent = liveAgent(ctx, exec)
        const state = challenges.current(agent)
        if (state === null) {
          return '当前没有活动挑战（普通模式）。用户提出合适的编码需求时，可考虑写骨架后调用 gufa_offer 提议挑战。'
        }
        return describe(state)
      },
      presentCall: () => present('查询古法状态'),
    }),
  )
}
