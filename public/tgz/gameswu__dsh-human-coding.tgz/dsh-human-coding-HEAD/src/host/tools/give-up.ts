/**
 * gufa_give_up：答题阶段用户主动放弃 → AI 接手正常实现。
 */
import { defineTool } from '@deepseek-ai/dsh-tools'
import { HarnessError } from '@deepseek-ai/dsh-llm'
import { liveAgent, requireHumanTurn } from '../authority'
import type { ChallengeStore } from '../challenge-store'
import type { GufaContext } from '../context'
import { challengeRecord, recordGiveUp, type StatsRecorder } from '../stats'
import { takeOver } from '../transitions'
import { STRING_OUTPUT, outcomeText, present } from './support'

export function registerGiveUpTool(ctx: GufaContext, stats: StatsRecorder, challenges: ChallengeStore): void {
  ctx.tools.register(
    defineTool({
      name: 'gufa_give_up',
      description:
        '古法编程模式：用户在答题阶段放弃挑战。AI 随即接手，像正常模式一样实现该需求。',
      parameters: {},
      output: STRING_OUTPUT,
      async execute(_args, exec) {
        const agent = liveAgent(ctx, exec)
        requireHumanTurn(ctx, agent)
        const state = challenges.current(agent)
        if (state === null || state.phase !== 'solving') {
          throw new HarnessError(
            '当前不在答题阶段，无需放弃（用 gufa_status 查看状态）。',
            'GUFA_NOT_SOLVING',
          )
        }
        const solution = challenges.write(agent, takeOver(state, 'takeover'))
        stats.record(recordGiveUp)
        stats.appendHistory(challengeRecord(String(agent.session.id), state, 'giveup', 'takeover'))
        return outcomeText(
          '用户放弃挑战。已进入 AI 接手（takeover）：像正常编码 Agent 一样实现该需求，可整合用户已有的部分工作。完成后可调 gufa_exit 收尾。',
          solution,
        )
      },
      presentCall: () => present('放弃挑战'),
    }),
  )
}
