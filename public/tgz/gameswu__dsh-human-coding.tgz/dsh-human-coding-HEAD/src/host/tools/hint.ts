/**
 * gufa_hint：答题阶段的提示求助。
 *
 * 用户在 solving 阶段每一次询问模型（无论是否明确要提示）都要先调本工具：
 * - hintsUsed + 1（每次求助扣一次预算）；
 * - 提示具体度按「已用 / 预算」比例递进：刚起步给方向，越接近预算越
 *   接近答案，但任何情况下都不代写实现、不给出完整解法；
 * - 超支（hintsUsed > maxHints）后不再给提示：只做与提示无关的答疑，
 *   并引导用户提交验收或放弃。
 */
import { defineTool } from '@deepseek-ai/dsh-tools'
import { HarnessError } from '@deepseek-ai/dsh-llm'
import { liveAgent, requireHumanTurn } from '../authority'
import type { ChallengeStore } from '../challenge-store'
import type { GufaContext } from '../context'
import { recordHint, type StatsRecorder } from '../stats'
import { consumeHint } from '../transitions'
import { STRING_OUTPUT, outcomeText, present } from './support'

export function registerHintTool(ctx: GufaContext, stats: StatsRecorder, challenges: ChallengeStore): void {
  ctx.tools.register(
    defineTool({
      name: 'gufa_hint',
      description:
        '古法编程模式：答题阶段用户向你求助/提问时，先调用本工具登记一次提示消耗（每次求助扣一次预算），再按返回的具体度要求给出提示。提示要一次比一次具体详细，但绝不代写实现、绝不透露完整解法；预算耗尽后停止给提示，只答疑并引导用户提交或放弃。',
      parameters: {
        topic: {
          type: 'string',
          description: '用户卡住的问题点（可选，一句话）。',
        },
      },
      output: STRING_OUTPUT,
      async execute(args, exec) {
        const agent = liveAgent(ctx, exec)
        requireHumanTurn(ctx, agent)
        const state = challenges.current(agent)
        if (state === null || state.phase !== 'solving') {
          throw new HarnessError(
            '当前不在答题阶段，无需登记提示（用 gufa_status 查看状态）。',
            'GUFA_NOT_SOLVING',
          )
        }
        const topic =
          typeof args.topic === 'string' && args.topic.trim() !== ''
            ? `问题点: ${args.topic.trim()}`
            : ''
        const next = challenges.write(agent, consumeHint(state))
        stats.record(recordHint)
        const ratio = next!.maxHints > 0 ? next!.hintsUsed / next!.maxHints : 1
        if (next!.hintsUsed > next!.maxHints) {
          return outcomeText(
            `提示预算已耗尽（${next!.hintsUsed}/${next!.maxHints}，超支 ${next!.hintsUsed - next!.maxHints} 次）。${topic} 不再给提示、绝不代写：仅可回答与提示无关的简短问题；明确告诉用户提示已用完，建议「提交」验收（你调用 gufa_submit）或「放弃」（你调用 gufa_give_up）。`,
            next,
          )
        }
        return outcomeText(
          `已登记第 ${next!.hintsUsed} 次提示（剩余 ${next!.maxHints - next!.hintsUsed}/${next!.maxHints}）。${topic} 现在按比例 ${ratio.toFixed(2)}（已用/预算）给出提示：0-0.33 只给方向与起点，0.33-0.66 给具体思路与结构，0.66 以上接近答案但不完整；务必比上一次提示更具体，同时绝不代写实现、绝不给出完整解法。`,
          next,
        )
      },
      presentCall: () => present('提示求助'),
    }),
  )
}
