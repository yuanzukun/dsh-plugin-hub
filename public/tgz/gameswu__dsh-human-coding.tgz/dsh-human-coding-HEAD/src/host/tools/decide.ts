/**
 * gufa_decide：落定验收判定。
 *
 * - fail：交互式询问「继续 / 放弃」——继续则回到答题（预算不扣减，但
 *   反馈提示不得低于已达具体度），放弃则进入 AI 接手（takeover）；
 * - pass：需给出完成度分数 score（0..1），交互式询问
 *   「采用你的写法 / AI 略做修改 / AI 彻底重写」。
 * - difficulty（可选）在验收时修正出题时的自评难度。
 *
 * 提问无应答时状态停留在 reviewing，模型可文字询问后以相同判定重调；
 * score/difficulty 在判定落定时即写入状态（重调幂等），统计在用户
 * 做出收尾选择后一次性记录。
 */
import { defineTool } from '@deepseek-ai/dsh-tools'
import { HarnessError } from '@deepseek-ai/dsh-llm'
import type { GufaState } from '../../shared/state'
import {
  PASS_KEEP,
  PASS_POLISH,
  PASS_REWRITE,
  RETRY_CONTINUE,
  RETRY_GIVE_UP,
} from '../../shared/state'
import { askOne, selected } from '../ask'
import { liveAgent, requireHumanTurn } from '../authority'
import type { ChallengeStore } from '../challenge-store'
import type { GufaContext } from '../context'
import { challengeRecord, recordFailGiveUp, recordPass, type StatsRecorder } from '../stats'
import { continueAfterFail, recordScore, reviseDifficulty, takeOver } from '../transitions'
import { STRING_OUTPUT, outcomeText, present } from './support'

export function registerDecideTool(ctx: GufaContext, stats: StatsRecorder, challenges: ChallengeStore): void {
  ctx.tools.register(
    defineTool({
      name: 'gufa_decide',
      description:
        '古法编程模式：落定验收判定。verdict=fail 时询问用户继续还是放弃；verdict=pass 时必须给出完成度分数 score（0..1），并询问用户采用自己的写法、让 AI 略做修改、还是让 AI 彻底重写。feedback 会作为提示/评审要点反馈给用户；可选 difficulty（0..1）修正出题时的难度自评。',
      parameters: {
        verdict: {
          type: 'string',
          required: true,
          enum: ['pass', 'fail'],
          description: '验收判定：测试与代码评审的综合结论。',
        },
        feedback: {
          type: 'string',
          required: true,
          description:
            '简要反馈要点：通过则说明亮点；不通过则指出问题所在（不给完整解法）。',
        },
        score: {
          type: 'number',
          description:
            '完成度分数（0..1，verdict=pass 时必填）：综合正确性、代码质量与完成情况的归一化打分，计入用户长期评分（总分计算规则另行约定）。',
        },
        difficulty: {
          type: 'number',
          description: '归一化难度（0..1，可选）：验收时若发现出题自评不准，在此修正。',
        },
      },
      output: STRING_OUTPUT,
      async execute(args, exec) {
        const agent = liveAgent(ctx, exec)
        requireHumanTurn(ctx, agent)
        const state = challenges.current(agent)
        if (state === null || state.phase !== 'reviewing') {
          throw new HarnessError(
            '当前不在验收阶段（先 gufa_submit）。',
            'GUFA_NOT_REVIEWING',
          )
        }
        const feedback = String(args.feedback).trim()
        const isPass = args.verdict === 'pass'

        const score = Number(args.score)
        if (isPass && (!Number.isFinite(score) || score < 0 || score > 1)) {
          throw new HarnessError(
            'verdict=pass 时必须给出 0..1 的完成度分数 score。',
            'GUFA_SCORE_REQUIRED',
          )
        }

        // 验收时的难度修正与分数落定（重调幂等）。
        let judged: GufaState = state
        if (args.difficulty !== undefined) {
          const difficulty = Number(args.difficulty)
          if (!Number.isFinite(difficulty) || difficulty < 0 || difficulty > 1) {
            throw new HarnessError(
              'difficulty 必须是 0..1 的归一化难度。',
              'GUFA_BAD_DIFFICULTY',
            )
          }
          judged = reviseDifficulty(judged, difficulty)
        }
        if (isPass) judged = recordScore(judged, score)
        const difficultyDelta = judged.difficulty - state.difficulty
        judged = challenges.write(agent, judged)!

        if (!isPass) {
          const answer = await askOne(ctx, agent, exec.signal, {
            header: '古法编程 · 验收未通过',
            question: `验收未通过（第 ${judged.attempts} 次提交）。接下来怎么做？`,
            options: [
              {
                label: '继续',
                description: '回到答题阶段，AI 给出不低于此前具体度的反馈提示（不扣提示预算）。',
              },
              {
                label: '放弃',
                description: 'AI 接手，像正常模式一样实现该需求。',
              },
            ],
          })
          if (answer === null) {
            return outcomeText(
              '没有可用的交互式提问界面。请用文字询问用户「继续还是放弃」，得到回答后以相同 verdict/fail 与 feedback 再次调用 gufa_decide。',
              judged,
            )
          }
          if (selected(answer, RETRY_GIVE_UP)) {
            stats.record((s) => recordFailGiveUp(s, difficultyDelta))
            stats.appendHistory(challengeRecord(String(agent.session.id), judged, 'fail', 'takeover'))
            const solution = challenges.write(agent, takeOver(judged, 'takeover'))
            return outcomeText(
              `用户选择放弃。已进入 AI 接手（takeover）：像正常编码 Agent 一样完成该需求，整合用户已有的部分实现。`,
              solution,
            )
          }
          const solving = challenges.write(agent, continueAfterFail(judged))
          return outcomeText(
            `用户选择继续。已回到答题阶段（提示 ${solving!.hintsUsed}/${solving!.maxHints}，不扣预算）。现在给出评审反馈（${feedback}）并附上不低于此前具体度的提示 —— 不写实现、不给完整解法。`,
            solving,
          )
        }

        // verdict === 'pass'
        const answer = await askOne(ctx, agent, exec.signal, {
          header: '古法编程 · 验收通过',
          question: '实现正确！最终代码采用哪种方式收尾？',
          options: [
            {
              label: '采用你的写法',
              description: '保留你的实现，AI 做简短总结与差异讲解。',
            },
            {
              label: 'AI 略做修改',
              description: '以你的实现为基础，AI 只做必要的小修正并逐处解释。',
            },
            {
              label: 'AI 彻底重写',
              description: 'AI 按自己的写法重写，并对比讲解差异。',
            },
          ],
        })
        if (answer === null) {
          return outcomeText(
            '没有可用的交互式提问界面。请用文字询问用户选择「采用你的写法 / AI 略做修改 / AI 彻底重写」，得到回答后以相同 verdict/pass、score 与 feedback 再次调用 gufa_decide。',
            judged,
          )
        }
        const recordPassOutcome = (mode: 'keep' | 'polish' | 'rewrite'): void => {
          stats.record((s) =>
            recordPass(s, {
              score,
              finalDifficulty: judged.difficulty,
              difficultyDelta,
              mode,
            }),
          )
          stats.appendHistory(challengeRecord(String(agent.session.id), judged, 'pass', mode))
        }
        if (selected(answer, PASS_KEEP)) {
          recordPassOutcome('keep')
          challenges.write(agent, null)
          return outcomeText(
            `用户选择采用自己的写法。挑战结束（状态已清除）。给出简短验收总结：亮点（${feedback}）、完成度分数（${score}）与可选的一段参考写法差异讲解。`,
            null,
          )
        }
        const mode = selected(answer, PASS_REWRITE) ? 'rewrite' : 'polish'
        recordPassOutcome(mode)
        const solution = challenges.write(agent, takeOver(judged, mode))
        return outcomeText(
          mode === 'polish'
            ? `用户选择 AI 略做修改。已进入 AI 接手（polish）：以用户实现为基础只做必要的小修正，逐处解释改动原因。完成度分数已记录（${score}）。`
            : `用户选择 AI 彻底重写。已进入 AI 接手（rewrite）：按自己的写法重写实现，并与用户版本对比讲解差异。完成度分数已记录（${score}）。`,
          solution,
        )
      },
      presentCall: (args) => present(args.verdict === 'pass' ? '验收通过' : '验收未通过', args.feedback),
    }),
  )
}
