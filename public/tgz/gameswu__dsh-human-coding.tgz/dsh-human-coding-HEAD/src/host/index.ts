/**
 * 插件入口（Host 半边）：古法编程模式的状态机、八个模型工具、
 * 行为提示段与跨会话持久化（统计 + 按会话键控的挑战状态，均在
 * settings 命名空间）。
 *
 * 组合行引用本包时（如 preset 中的 `- id: tool-human-coding`），
 * cordis 加载器取 `exports.apply` 挂载本插件；各注册均归属插件
 * fiber，随预设会话卸载而清理。本插件不发布任何服务，因此组合里
 * 无需 isolate realm。
 *
 * 两种挂载形态（按行 config.statsOnly 区分）：
 * - 预设行（缺省，statsOnly=false）：注册全部能力——提示段、统计与
 *   挑战持久化、八个工具；
 * - 常驻宿主行（statsOnly=true，写入 Profile 的 cordis.patch.yml）：
 *   只注册 settings 持久化——让「设置 → 插件」统计卡片在没有古法
 *   会话时也始终可用，同时古法模式不会泄漏进其他会话。命名空间
 *   注册是进程级幂等的（模块级单例），两行并存不会重复注册。
 */
import type { Context } from '@deepseek-ai/cordis'
import { asGufaContext } from './context'
import { ChallengeStore } from './challenge-store'
import { GUFA_SECTION, GUFA_SECTION_NAME, GUFA_SECTION_ORDER } from './prompt'
import { SettingsStore } from './settings-store'
import { StatsRecorder } from './stats'
import { registerOfferTool } from './tools/offer'
import { registerStatusTool } from './tools/status'
import { registerSubmitTool } from './tools/submit'
import { registerDecideTool } from './tools/decide'
import { registerGiveUpTool } from './tools/give-up'
import { registerCancelTool } from './tools/cancel'
import { registerExitTool } from './tools/exit'
import { registerHintTool } from './tools/hint'

export const name = 'dsh-human-coding'

export const inject = ['agents', 'tools', 'systemPrompt', 'userQuestions', 'settings']

export interface HumanCodingConfig {
  /** true = 常驻宿主行：只注册 settings 持久化，不注册工具/提示段。 */
  statsOnly?: boolean
}

export function apply(ctx: Context, config: HumanCodingConfig = {}) {
  const gctx = asGufaContext(ctx)
  const statsOnly = config.statsOnly === true

  if (!statsOnly) {
    ctx.systemPrompt.section({
      name: GUFA_SECTION_NAME,
      order: GUFA_SECTION_ORDER,
      text: GUFA_SECTION,
    })
  }

  // settings 命名空间：统计 + 挑战状态（进程内单例共享）。
  const store = new SettingsStore()
  store.install(ctx)

  if (statsOnly) return

  const stats = new StatsRecorder(store)
  const challenges = new ChallengeStore(store)

  registerOfferTool(gctx, stats, challenges)
  registerStatusTool(gctx, challenges)
  registerSubmitTool(gctx, stats, challenges)
  registerDecideTool(gctx, stats, challenges)
  registerGiveUpTool(gctx, stats, challenges)
  registerCancelTool(gctx, stats, challenges)
  registerExitTool(gctx, stats, challenges)
  registerHintTool(gctx, stats, challenges)
}

export default { name, inject, apply }
