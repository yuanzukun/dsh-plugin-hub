/**
 * 纯状态迁移函数：输入当前状态，输出新状态。
 * 不触碰任何服务，便于单元测试与投影一致性校验。
 */
import type { GufaState, SolutionMode } from '../shared/state'

export function startSolving(state: GufaState, now: number = Date.now()): GufaState {
  return {
    ...state,
    phase: 'solving',
    attempts: 0,
    hintsUsed: 0,
    solutionMode: null,
    updatedAt: now,
  }
}

export function submitChallenge(state: GufaState, now: number = Date.now()): GufaState {
  return {
    ...state,
    phase: 'reviewing',
    attempts: state.attempts + 1,
    updatedAt: now,
  }
}

/**
 * 验收不通过、用户选择继续：回到答题阶段。
 * 提示预算不因失败反馈而扣减（那是评审反馈，不是用户主动求助）；
 * 但反馈中附带的提示不得低于此前已达的具体度。
 */
export function continueAfterFail(state: GufaState, now: number = Date.now()): GufaState {
  return {
    ...state,
    phase: 'solving',
    updatedAt: now,
  }
}

/** 一次提示求助：扣一次预算（允许超支，超支由提示段语义约束）。 */
export function consumeHint(state: GufaState, now: number = Date.now()): GufaState {
  return {
    ...state,
    hintsUsed: state.hintsUsed + 1,
    updatedAt: now,
  }
}

/** 验收时修正难度（0..1）。 */
export function reviseDifficulty(
  state: GufaState,
  difficulty: number,
  now: number = Date.now(),
): GufaState {
  return { ...state, difficulty, updatedAt: now }
}

/** 验收通过时记录完成度分数（0..1）。 */
export function recordScore(
  state: GufaState,
  score: number,
  now: number = Date.now(),
): GufaState {
  return { ...state, score, updatedAt: now }
}

export function takeOver(
  state: GufaState,
  mode: SolutionMode,
  now: number = Date.now(),
): GufaState {
  return {
    ...state,
    phase: 'solution',
    solutionMode: mode,
    updatedAt: now,
  }
}
