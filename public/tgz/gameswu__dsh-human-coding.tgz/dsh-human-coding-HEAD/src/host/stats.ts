/**
 * 跨会话用户表现统计：纯计数函数 + settings 持久化（经 SettingsStore）。
 *
 * - 记录函数（record*）都是纯函数：输入旧统计、输出新统计，便于单元测试；
 * - 持久化走 settings 服务（命名空间 dsh-human-coding，节面 `{ stats }`），
 *   由 `StatsRecorder` 委托 `SettingsStore` 做「读-改-写」；
 * - 重置（Client 卡片按钮）是 settings 层面的 set('stats', 零值) +
 *   set('history', [])（统计页的结果类指标由 history 重算，必须一并清除），
 *   Host 侧每次记录都会读到最新值，无需额外同步。
 */
import {
  emptyStats,
  type ChallengeOutcome,
  type ClosingMode,
  type GufaChallengeRecord,
  type GufaState,
  type GufaStats,
} from '../shared/state'
import { SettingsStore } from './settings-store'

/* ------------------------------ 纯记录函数 ------------------------------ */

function touch(stats: GufaStats, now: number): GufaStats {
  return { ...stats, updatedAt: now }
}

/** 提议一次挑战（含被跳过/拒绝的）。 */
export function recordOffer(stats: GufaStats, now: number = Date.now()): GufaStats {
  return touch({ ...stats, offers: stats.offers + 1 }, now)
}

/** 接受一次挑战：累计难度（出题自评）与提示预算。 */
export function recordAccept(
  stats: GufaStats,
  difficulty: number,
  maxHints: number,
  now: number = Date.now(),
): GufaStats {
  return touch(
    {
      ...stats,
      accepts: stats.accepts + 1,
      difficultySum: stats.difficultySum + difficulty,
      difficultyCount: stats.difficultyCount + 1,
      hintsBudget: stats.hintsBudget + maxHints,
    },
    now,
  )
}

/** 跳过一次挑战。 */
export function recordSkip(stats: GufaStats, now: number = Date.now()): GufaStats {
  return touch({ ...stats, skips: stats.skips + 1 }, now)
}

/** 一次提交验收。 */
export function recordSubmit(stats: GufaStats, now: number = Date.now()): GufaStats {
  return touch({ ...stats, attempts: stats.attempts + 1 }, now)
}

/** 一次提示（gufa_hint）：每次求助扣一次预算。 */
export function recordHint(stats: GufaStats, now: number = Date.now()): GufaStats {
  return touch({ ...stats, hintsUsed: stats.hintsUsed + 1 }, now)
}

/** 答题阶段直接放弃（进入 AI 接手 takeover）。 */
export function recordGiveUp(stats: GufaStats, now: number = Date.now()): GufaStats {
  return touch(
    {
      ...stats,
      giveUps: stats.giveUps + 1,
      modes: { ...stats.modes, takeover: stats.modes.takeover + 1 },
    },
    now,
  )
}

/** 验收不通过后放弃：最终难度可按修订值修正（delta = 修订 - 出题自评）。 */
export function recordFailGiveUp(
  stats: GufaStats,
  difficultyDelta: number,
  now: number = Date.now(),
): GufaStats {
  return touch(
    {
      ...stats,
      fails: stats.fails + 1,
      giveUpsAfterFail: stats.giveUpsAfterFail + 1,
      modes: { ...stats.modes, takeover: stats.modes.takeover + 1 },
      difficultySum: stats.difficultySum + difficultyDelta,
    },
    now,
  )
}

/** 验收通过：记录完成度分数、收尾方式与最终难度修正。 */
export function recordPass(
  stats: GufaStats,
  input: {
    score: number
    finalDifficulty: number
    difficultyDelta: number
    mode: ClosingMode
  },
  now: number = Date.now(),
): GufaStats {
  return touch(
    {
      ...stats,
      passes: stats.passes + 1,
      modes: { ...stats.modes, [input.mode]: stats.modes[input.mode] + 1 },
      scoreSum: stats.scoreSum + input.score,
      scoreCount: stats.scoreCount + 1,
      weightedScoreSum: stats.weightedScoreSum + input.score * input.finalDifficulty,
      scoredDifficultySum: stats.scoredDifficultySum + input.finalDifficulty,
      difficultySum: stats.difficultySum + input.difficultyDelta,
    },
    now,
  )
}

/** 主动中止一道进行中的挑战。 */
export function recordExit(stats: GufaStats, now: number = Date.now()): GufaStats {
  return touch({ ...stats, exits: stats.exits + 1 }, now)
}

/** 作废一道挑战需要回滚的累计足迹（出题/接受时已入账的量）。 */
export interface CancelFootprint {
  /** 本题已计入 offers+1（出题注册时入账；作废回滚）。 */
  offered: boolean
  /** 是否已接受（接受时入账 difficultySum/difficultyCount/hintsBudget）。 */
  accepted: boolean
  /** 出题自评难度（接受时已累计）。 */
  difficulty: number
  /** 本题提示预算（接受时已累计）。 */
  maxHints: number
  /** 本题已提交验收次数。 */
  attempts: number
  /** 本题已消耗提示次数。 */
  hintsUsed: number
}

/**
 * 作废一道挑战：不留任何记录——回滚本题已入账的全部计数
 * （提议/接受/难度/提示预算/提交/提示消耗），收尾分布不计数。
 * 全部减法钳制到 0，防御性兼容异常状态。
 */
export function recordCancel(stats: GufaStats, footprint: CancelFootprint, now: number = Date.now()): GufaStats {
  const next: GufaStats = {
    ...stats,
    offers: footprint.offered ? Math.max(0, stats.offers - 1) : stats.offers,
    attempts: Math.max(0, stats.attempts - footprint.attempts),
    hintsUsed: Math.max(0, stats.hintsUsed - footprint.hintsUsed),
  }
  if (footprint.accepted) {
    next.accepts = Math.max(0, stats.accepts - 1)
    next.difficultySum = Math.max(0, stats.difficultySum - footprint.difficulty)
    next.difficultyCount = Math.max(0, stats.difficultyCount - 1)
    next.hintsBudget = Math.max(0, stats.hintsBudget - footprint.maxHints)
  }
  return touch(next, now)
}

/* ------------------------------ 持久化记录器 ------------------------------ */

/**
 * 统计记录器：委托 SettingsStore 做读-改-写。
 * 记录是异步的（settings 写入在宿主侧排队落盘，不阻塞工具执行），
 * 失败仅告警，不影响挑战流程。
 */
export class StatsRecorder {
  constructor(private readonly store: SettingsStore) {}

  /** 应用一次纯记录函数并持久化；settings 未就绪时静默跳过。 */
  record(fn: (stats: GufaStats) => GufaStats): void {
    this.store.updateStats(fn)
  }

  /** 追加一条逐题数值记录。 */
  appendHistory(record: GufaChallengeRecord): void {
    this.store.updateHistory((history) => [...history, record])
  }
}

/** 由结算时的挑战状态构造逐题记录。 */
export function challengeRecord(
  sessionId: string,
  state: GufaState,
  outcome: ChallengeOutcome,
  mode: ClosingMode,
): GufaChallengeRecord {
  return {
    id: `${sessionId}:${state.updatedAt}`,
    title: state.title,
    outcome,
    mode,
    score: state.score,
    difficulty: state.difficulty,
    attempts: state.attempts,
    hintsUsed: state.hintsUsed,
    maxHints: state.maxHints,
    updatedAt: state.updatedAt,
  }
}
