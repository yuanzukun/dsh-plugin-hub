/**
 * 状态的结构化校验与解码：settings 里持久化的挑战状态不可信，
 * 所有读取路径都经过这里的 schema 解码。
 */
import { z } from 'zod'
import {
  DEFAULT_MAX_HINTS,
  MAX_HINTS_LIMIT,
  type GufaState,
} from '../shared/state'

const phaseSchema = z.enum(['offering', 'solving', 'reviewing', 'solution'])

const solutionModeSchema = z.union([z.enum(['takeover', 'polish', 'rewrite']), z.null()])

/** 挑战整值状态（settings 持久化形态）。 */
export const gufaStateSchema = z.object({
  phase: phaseSchema,
  title: z.string(),
  summary: z.string(),
  language: z.string().default(''),
  files: z.array(z.string()).default([]),
  scope: z.string().default(''),
  attempts: z.number().min(0).default(0),
  maxHints: z.number().int().min(1).max(MAX_HINTS_LIMIT).default(DEFAULT_MAX_HINTS),
  hintsUsed: z.number().int().min(0).default(0),
  difficulty: z.number().min(0).max(1).default(0.5),
  score: z.union([z.number().min(0).max(1), z.null()]).default(null),
  solutionMode: solutionModeSchema.default(null),
  updatedAt: z.number(),
})

/** 挑战状态或清除墓碑。 */
export const gufaProjectionSchema = z.union([gufaStateSchema, z.null()])

/**
 * 解码持久化的挑战状态；非法数据返回 undefined（调用方视为无挑战）。
 */
export function decodeGufaChange(data: unknown): GufaState | null | undefined {
  const parsed = gufaProjectionSchema.safeParse(data)
  return parsed.success ? parsed.data : undefined
}
