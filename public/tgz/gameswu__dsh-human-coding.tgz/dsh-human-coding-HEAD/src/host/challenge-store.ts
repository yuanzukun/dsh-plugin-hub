/**
 * 挑战状态存储：settings 命名空间按会话 id 键控 + 进程内缓存。
 *
 * 为什么不用会话日志：dsh-session-persistence 只接受内置事件类型或带
 * `ignorable` 信封标记的事件，而 `Session.append` API 无法设置该标记——
 * 仓库外插件写自定义会话事件会让会话拒绝打开。因此挑战状态持久化到
 * settings 命名空间（跨重启仍在），进程内用模块级缓存保证同轮次连续
 * 读写的一致性（settings 的异步落盘可能滞后于下一次读取）。
 */
import type { Agent } from '@deepseek-ai/dsh-agent'
import type { GufaState } from '../shared/state'
import { decodeGufaChange } from './domain'
import { SettingsStore } from './settings-store'

/** 进程内缓存：会话 id → 挑战状态（含 null 墓碑）。 */
const cache = new Map<string, GufaState | null>()

/** 纯函数：把一格的挑战状态并入 challenges 表（null 删除键）。 */
export function setChallenge(
  challenges: Record<string, unknown>,
  id: string,
  next: GufaState | null,
): Record<string, unknown> {
  const updated = { ...challenges }
  if (next === null) delete updated[id]
  else updated[id] = next
  return updated
}

export class ChallengeStore {
  constructor(private readonly store: SettingsStore) {}

  /** 读取当前会话的挑战状态（无挑战时为 null）。 */
  current(agent: Agent): GufaState | null {
    const id = String(agent.session.id)
    if (cache.has(id)) return cache.get(id) ?? null
    const raw = this.store.get().challenges[id]
    const decoded = raw === undefined || raw === null ? null : decodeGufaChange(raw)
    const value = decoded === undefined ? null : decoded
    cache.set(id, value)
    return value
  }

  /** 写入挑战状态；传 null 清除并删除键。 */
  write(agent: Agent, next: GufaState | null): GufaState | null {
    const id = String(agent.session.id)
    cache.set(id, next)
    this.store.updateChallenges((challenges) => setChallenge(challenges, id, next))
    return next
  }
}
