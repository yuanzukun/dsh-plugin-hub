/**
 * 宿主服务的最小结构化面：只声明本包实际消费的能力。
 *
 * 类型上不依赖 dsh 各包的 `declare module` 增强链（那些增强在运行时始终
 * 存在，但类型面较深）；此处用局部结构类型在 apply 边界做一次收窄，
 * 使工具模块的签名尽量自描述。运行时行为以宿主注册表的真实实现为准。
 */
import type { Context } from '@deepseek-ai/cordis'
import type { Agent } from '@deepseek-ai/dsh-agent'
import type { ToolRuntime } from '@deepseek-ai/dsh-tools'

export interface AskQuestionSpec {
  id: string
  question: string
  header?: string
  options?: Array<{ label: string; description?: string }>
  multiSelect?: boolean
}

export interface AskAnswer {
  id: string
  selected: string[]
  custom?: string
}

export interface UserQuestionsFace {
  ask(request: {
    questions: AskQuestionSpec[]
    agent?: Agent
    signal?: AbortSignal
  }): Promise<{ answers: AskAnswer[] }>
}

export interface SystemPromptFace {
  section(section: { name: string; order: number; text: string }): () => void
}

/** 本插件消费的宿主能力集合。 */
export interface GufaContext {
  agents: {
    get(id: string): Agent | undefined
    roots(): Agent[]
    currentInitiator(): Agent | undefined
  }
  userQuestions: UserQuestionsFace
  systemPrompt: SystemPromptFace
  tools: ToolRuntime
}

/** 在 apply 边界把 Cordis Context 收窄为本插件的消费面。 */
export function asGufaContext(ctx: Context): GufaContext {
  return ctx as unknown as GufaContext
}
