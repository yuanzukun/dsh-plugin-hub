/**
 * 交互式提问封装：复用平台 userQuestions 的 UI 提供商（与内置
 * ask_user_question 同一套卡片）。
 *
 * 没有活跃 UI 提供商（无头上下文）时 ask 会失败 —— 返回 null，
 * 由工具把「改用文字询问」的指示交还模型，状态机保持可重入。
 */
import type { Agent } from '@deepseek-ai/dsh-agent'
import type { GufaContext } from './context'

export interface AskSpec {
  header: string
  question: string
  options: Array<{ label: string; description?: string }>
}

export interface AskResult {
  selected: string[]
  custom?: string
}

export async function askOne(
  ctx: GufaContext,
  agent: Agent,
  signal: AbortSignal | undefined,
  spec: AskSpec,
): Promise<AskResult | null> {
  try {
    const answer = await ctx.userQuestions.ask({
      questions: [
        {
          id: 'gufa',
          header: spec.header,
          question: spec.question,
          options: spec.options,
        },
      ],
      agent,
      signal,
    })
    return answer.answers[0] ?? null
  } catch {
    // 无活跃提供商（如无头会话）：由调用方转为文字提问。
    return null
  }
}

export function selected(answer: AskResult | null, option: string): boolean {
  return answer !== null && answer.selected.includes(option)
}
