/**
 * settings 命名空间（dsh-human-coding）的进程内共享注册与读-改-写。
 *
 * 命名空间是进程全局的（重复注册抛错），而本包既可能被常驻宿主行
 * （statsOnly）也可能被每个古法会话各挂载一次——因此模块级单例共享
 * scope：首个实例注册，其余实例复用。节面 `{ stats, challenges }`：
 * stats 为跨会话统计，challenges 为按会话 id 键控的挑战状态。
 */
import z from '@deepseek-ai/schemastery'
import type { Context } from '@deepseek-ai/cordis'
import type { SettingsScope } from '@deepseek-ai/dsh-settings'
import {
  GUFA_SETTINGS_NS,
  emptyStats,
  type GufaSettings,
  type GufaStats,
} from '../shared/state'

/** 节面 schema：所有字段带默认值；challenges 值在读取时经 zod 解码。 */
export const GufaSettingsSchema = z.object({
  stats: z
    .object({
      offers: z.number().min(0).default(0),
      accepts: z.number().min(0).default(0),
      skips: z.number().min(0).default(0),
      passes: z.number().min(0).default(0),
      fails: z.number().min(0).default(0),
      giveUps: z.number().min(0).default(0),
      giveUpsAfterFail: z.number().min(0).default(0),
      exits: z.number().min(0).default(0),
      modes: z
        .object({
          keep: z.number().min(0).default(0),
          polish: z.number().min(0).default(0),
          rewrite: z.number().min(0).default(0),
          takeover: z.number().min(0).default(0),
        })
        .default({ keep: 0, polish: 0, rewrite: 0, takeover: 0 }),
      attempts: z.number().min(0).default(0),
      hintsUsed: z.number().min(0).default(0),
      hintsBudget: z.number().min(0).default(0),
      scoreSum: z.number().min(0).default(0),
      scoreCount: z.number().min(0).default(0),
      difficultySum: z.number().min(0).default(0),
      difficultyCount: z.number().min(0).default(0),
      weightedScoreSum: z.number().min(0).default(0),
      scoredDifficultySum: z.number().min(0).default(0),
      updatedAt: z.number().default(0),
    })
    .default(emptyStats()),
  challenges: z.any().default({}),
  history: z.array(z.any()).default([]),
})

interface SettingsFace {
  settings: {
    register<T>(ns: string, schema: object, options?: object): SettingsScope<T>
  }
}

/** 进程内共享 scope：注册一次、全员复用；注册后进程内常驻。 */
let sharedScope: SettingsScope<GufaSettings> | undefined

function resolveSharedScope(ctx: Context, face: SettingsFace): SettingsScope<GufaSettings> | undefined {
  if (sharedScope !== undefined) return sharedScope
  try {
    sharedScope = face.settings.register(GUFA_SETTINGS_NS, GufaSettingsSchema, {
      applies: 'live',
    }) as SettingsScope<GufaSettings>
  } catch (error) {
    console.warn(
      `[dsh-human-coding] settings namespace "${GUFA_SETTINGS_NS}" already registered by another owner; persistence disabled.`,
      error,
    )
    return undefined
  }
  return sharedScope
}

/** 未就绪时的空节面。 */
const EMPTY_SETTINGS: GufaSettings = { stats: emptyStats(0), challenges: {}, history: [] }

/**
 * 持久化存储：绑定命名空间并做读-改-写。
 * 写入是异步的（settings 在宿主侧排队落盘，不阻塞工具执行），
 * 失败仅告警，不影响挑战流程。
 */
export class SettingsStore {
  private scope: SettingsScope<GufaSettings> | undefined

  /** 挂接 settings 服务（在插件 apply 内调用一次）。 */
  install(ctx: Context): void {
    ctx.inject(['settings'], (sctx) => {
      const face = sctx as unknown as SettingsFace
      this.scope = resolveSharedScope(sctx, face)
    })
  }

  /** 当前节面（未就绪时为空节面）。 */
  get(): GufaSettings {
    try {
      return this.scope?.get() ?? EMPTY_SETTINGS
    } catch (error) {
      console.warn('[dsh-human-coding] settings read failed; falling back to empty.', error)
      return EMPTY_SETTINGS
    }
  }

  /** 读-改-写 stats 节。 */
  updateStats(fn: (stats: GufaStats) => GufaStats): void {
    const scope = this.scope
    if (scope === undefined) return
    try {
      const next = fn(scope.get().stats)
      void scope.update({ stats: next }).catch((error: unknown) => {
        console.warn('[dsh-human-coding] stats update failed; record dropped.', error)
      })
    } catch (error) {
      console.warn('[dsh-human-coding] stats read failed; record dropped.', error)
    }
  }

  /** 读-改-写 history 节（逐题数值记录）。 */
  updateHistory(fn: (history: unknown[]) => unknown[]): void {
    const scope = this.scope
    if (scope === undefined) return
    try {
      const next = fn(scope.get().history ?? [])
      void scope.update({ history: next }).catch((error: unknown) => {
        console.warn('[dsh-human-coding] history update failed.', error)
      })
    } catch (error) {
      console.warn('[dsh-human-coding] history read failed.', error)
    }
  }

  /** 读-改-写 challenges 节（按会话 id 键控）。 */
  updateChallenges(fn: (challenges: Record<string, unknown>) => Record<string, unknown>): void {
    const scope = this.scope
    if (scope === undefined) return
    try {
      const next = fn(scope.get().challenges ?? {})
      void scope.update({ challenges: next }).catch((error: unknown) => {
        console.warn('[dsh-human-coding] challenges update failed.', error)
      })
    } catch (error) {
      console.warn('[dsh-human-coding] challenges read failed.', error)
    }
  }
}
