/**
 * 古法编程状态条：常驻在输入框上方（conversation.input.dock）。
 *
 * - 数据：经平台 settingsScope 读取 Host 侧持久化的挑战状态
 *   （命名空间 dsh-human-coding 的 challenges 节，按会话 id 键控），
 *   跨刷新/重启仍在；
 * - 操作：答题阶段提供「提交」「放弃」按钮，经 inputActions 写入草稿并
 *   直接提交，等价于用户输入这两个词，由 Agent 调用对应 gufa 工具。
 *
 * 样式复用平台主题变量（--dsw-*），与内置 goal bar 视觉一致。
 */
import React from 'react'
import { useSyncExternalStore } from 'react'
import { PHASE_LABELS, type GufaState } from '../shared/state'
import { getGufaScope, UNAVAILABLE_SNAPSHOT } from './settings-scope'
import { difficultyColor } from './score-color'

export interface GufaDockProps {
  sessionId: string
  inputActions: {
    setDraft: (text: string) => void
    submit: () => void
  }
}

const dockStyle: React.CSSProperties = {
  boxSizing: 'border-box',
  width:
    'calc(100% - var(--dsh-composer-side-clearance) - var(--dsh-composer-side-clearance) - var(--dsh-composer-dock-inset) - var(--dsh-composer-dock-inset))',
  margin: '0 auto',
}

const barStyle: React.CSSProperties = {
  boxSizing: 'border-box',
  width: '100%',
  maxWidth: 'calc(var(--dsh-composer-card-max-width) - 4 * var(--dsh-composer-dock-inset))',
  border: '1px solid var(--dsw-alias-border-l1)',
  background: 'var(--dsw-specific-tip)',
  borderRadius: 12,
  alignItems: 'center',
  gap: 10,
  height: 36,
  margin: '0 auto',
  padding: '4px 5px 4px 12px',
  display: 'flex',
}

const badgeStyle: React.CSSProperties = {
  flex: 'none',
  fontSize: 12,
  fontWeight: 600,
  lineHeight: '20px',
  color: 'var(--dsw-alias-state-business-primary, #4176e6)',
  border: '1px solid var(--dsw-alias-state-business-primary, #4176e6)',
  borderRadius: 999,
  padding: '0 8px',
  whiteSpace: 'nowrap',
}

const titleStyle: React.CSSProperties = {
  minWidth: 0,
  flex: 1,
  color: 'var(--dsw-alias-label-primary)',
  fontSize: 13,
  fontWeight: 500,
  lineHeight: '24px',
  textOverflow: 'ellipsis',
  whiteSpace: 'nowrap',
  overflow: 'hidden',
}

const phaseStyle: React.CSSProperties = {
  flex: 'none',
  color: 'var(--dsw-alias-label-secondary)',
  fontSize: 12,
  lineHeight: '20px',
  whiteSpace: 'nowrap',
}

const metaStyle: React.CSSProperties = {
  flex: 'none',
  color: 'var(--dsw-alias-label-tertiary)',
  fontSize: 12,
  lineHeight: '20px',
  whiteSpace: 'nowrap',
}

const actionsStyle: React.CSSProperties = {
  flex: 'none',
  display: 'flex',
  alignItems: 'center',
  gap: 6,
}

const buttonBase: React.CSSProperties = {
  height: 26,
  borderRadius: 6,
  fontSize: 12,
  lineHeight: '20px',
  padding: '0 10px',
  cursor: 'pointer',
  border: 'none',
  whiteSpace: 'nowrap',
}

const primaryButton: React.CSSProperties = {
  ...buttonBase,
  background: 'var(--dsw-alias-state-business-primary, #4176e6)',
  color: 'var(--dsw-alias-bg-base)',
}

const ghostButton: React.CSSProperties = {
  ...buttonBase,
  background: 'transparent',
  border: '1px solid var(--dsw-alias-border-l2)',
  color: 'var(--dsw-alias-label-secondary)',
}

export default function GufaDock({ sessionId, inputActions }: GufaDockProps) {
  const snapshot = useSyncExternalStore(
    (listener) => (getGufaScope() === undefined ? () => {} : getGufaScope()!.subscribe(listener)),
    () => getGufaScope()?.getSnapshot() ?? UNAVAILABLE_SNAPSHOT,
  )
  const raw = snapshot.value?.challenges?.[sessionId]
  const state = raw === undefined || raw === null ? null : (raw as GufaState)
  if (state === null) return null

  const send = (text: string) => () => {
    inputActions.setDraft(text)
    inputActions.submit()
  }

  return (
    <div style={dockStyle} data-gufa-dock>
      <div style={barStyle}>
        <span style={badgeStyle}>古法</span>
        <span style={titleStyle} title={state.title}>
          {state.title}
        </span>
        <span style={phaseStyle}>{PHASE_LABELS[state.phase]}</span>
        {state.phase === 'solving' || state.phase === 'reviewing' ? (
          <span style={{ ...metaStyle, color: difficultyColor(state.difficulty) }}>
            难度 {state.difficulty.toFixed(2)}
          </span>
        ) : null}
        {state.phase === 'solving' ? (
          <span style={metaStyle}>
            第 {state.attempts} 次提交 · 提示 {state.hintsUsed}/{state.maxHints}
          </span>
        ) : null}
        {state.phase === 'solving' ? (
          <div style={actionsStyle}>
            <button type="button" style={primaryButton} onClick={send('提交')}>
              提交
            </button>
            <button type="button" style={ghostButton} onClick={send('放弃')}>
              放弃
            </button>
          </div>
        ) : null}
      </div>
    </div>
  )
}
