/**
 * 古法编程统计卡片（设置 → 插件 → dsh-human-coding）。
 *
 * 数据经平台 `settingsScope` 服务读写 Host 侧注册的同名 settings
 * 命名空间（无需自定义 RPC 通道）：getSnapshot/subscribe 订阅变更，
 * set('stats', 零值) + set('history', []) 清零。比率与加权评分由原始计数即时推导：
 * - 接受率 = accepts / offers
 * - 通过率 = passes / (passes + fails)（只统计有验收判定的题）
 * - 平均提交 = attempts / 已结束题数
 * - 提示消耗率 = hintsUsed / hintsBudget（>100% 告警色）
 * - 平均完成度 = scoreSum / scoreCount（百分比）
 * - 表现分 = 每题表现分（完成度 × 难度 × 100）从高到低取前 100，
 *   按 0.95 几何衰减加权（第 i 高分权重 0.95^(i-1)），除以 100 题
 *   全满分的固定归一化因子（不足 100 题的位次按 0 分计），以
 *   **100 分制** 展示（保留两位小数，无百分号）
 * - 逐题记录表格（RecordsTable）：标题/完成度/难度/表现分（贡献），
 *   贡献之和 = 总表现分；每页 5 项翻页，点击表头切换排序字段与方向
 *
 * 配色为统一的红→黄→绿连续色阶（score-color.ts）：按数值计算 HSL
 * 色相（0° 红 → 60° 黄 → 120° 绿，饱和度 88%、亮度 52%），以
 * **内联样式** 直接作用于数字，不依赖 CSS 类、主题变量或注入时机。
 * 分数越高越绿；难度越高越红。计数保持中性。
 */
import React from 'react'
import { useSyncExternalStore } from 'react'
import { emptyStats, type GufaChallengeRecord, type GufaStats } from '../shared/state'
import { getGufaScope, UNAVAILABLE_SNAPSHOT } from './settings-scope'
import { difficultyColor, scoreColor } from './score-color'
import RecordsTable from './RecordsTable'
import { buildExport, deriveStats, mergeImport, parseImport, performanceScore } from './records'

export const LOCALE_NS = 'settings.dsh-human-coding'

/* ------------------------------ 样式 ------------------------------ */

const CARD_CSS = [
  '.gc-card{list-style:none;border:1px solid var(--dsw-alias-border-l2);border-radius:12px;background:var(--dsw-alias-bg-layer-2);transition:border-color .16s,background .16s}',
  '.gc-card:hover{border-color:var(--dsw-alias-label-dimmed)}',
  '.gc-card-open{background:var(--dsw-alias-bg-layer-2);border-color:var(--dsw-alias-label-dimmed)}',
  '.gc-header{width:100%;appearance:none;border:0;background:0 0;font:inherit;color:inherit;text-align:left;cursor:pointer;align-items:center;gap:12px;padding:14px 16px;border-radius:12px;display:flex}',
  '.gc-header:focus-visible{outline:2px solid var(--dsw-alias-brand-primary);outline-offset:-2px}',
  '.gc-head-text{flex-direction:column;flex:1;gap:4px;min-width:0;display:flex}',
  '.gc-name{color:var(--dsw-alias-label-primary);font-size:15px;font-weight:600;line-height:1.4}',
  '.gc-desc{color:var(--dsw-alias-label-tertiary);font-size:13px;line-height:1.5}',
  '.gc-chevron{flex:none;color:var(--dsw-alias-label-tertiary);transition:transform .16s}',
  '.gc-chevron-open{transform:rotate(180deg)}',
  '.gc-body{border-top:1px solid var(--dsw-alias-border-l2);margin:0 16px;padding-bottom:8px}',
  '.gc-summary{color:var(--dsw-alias-label-secondary);font-size:13px;line-height:1.6;margin:12px 0 0}',
  '.gc-summary b{color:var(--dsw-alias-label-primary);font-weight:600}',
  '.gc-section-title{color:var(--dsw-alias-label-primary);font-size:13px;font-weight:600;line-height:1.5;margin:12px 0 0}',
  '.gc-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:8px;margin-top:8px}',
  '.gc-cell{background:var(--dsw-alias-bg-layer-1);border:1px solid var(--dsw-alias-border-l1);border-radius:8px;padding:8px 10px;min-width:0}',
  '.gc-value{font-size:16px;font-weight:600;line-height:1.4}',
  '.gc-label{color:var(--dsw-alias-label-tertiary);font-size:12px;line-height:1.5}',
  '.gc-footer{border-top:1px solid var(--dsw-alias-border-l2);justify-content:flex-end;align-items:center;gap:8px;padding:12px 0 4px;display:flex}',
  '.gc-reset{appearance:none;font:inherit;cursor:pointer;border:1px solid var(--dsw-alias-border-l2);color:var(--dsw-alias-state-error-primary);background:0 0;border-radius:8px;padding:5px 14px;font-size:13px;line-height:1.5}',
  '.gc-reset:hover:not(:disabled){border-color:var(--dsw-alias-state-error-primary)}',
  '.gc-reset:disabled{opacity:.4;cursor:default}',
  '.gc-import{appearance:none;font:inherit;cursor:pointer;border:1px solid var(--dsw-alias-border-l2);color:var(--dsw-alias-label-secondary);background:0 0;border-radius:8px;padding:5px 14px;font-size:13px;line-height:1.5}',
  '.gc-import:hover:not(:disabled){border-color:var(--dsw-alias-label-secondary)}',
  '.gc-import:disabled{opacity:.4;cursor:default}',
  '.gc-status{color:var(--dsw-alias-label-secondary);font-size:12px;line-height:1.5;margin:8px 0 0}',
  '.gc-table{width:100%;border-collapse:collapse;table-layout:fixed;font-size:13px;margin-top:8px}',
  '.gc-col-title{width:46%}',
  '.gc-col-num{width:18%}',
  '.gc-th{text-align:left;padding:0;border-bottom:1px solid var(--dsw-alias-border-l2)}',
  '.gc-th-btn{appearance:none;border:0;background:0 0;font:inherit;color:var(--dsw-alias-label-tertiary);cursor:pointer;display:inline-flex;align-items:center;gap:4px;padding:6px 4px;width:100%;text-align:left;white-space:nowrap}',
  '.gc-th-btn:hover{color:var(--dsw-alias-label-primary)}',
  '.gc-sort{font-size:10px;line-height:1;flex:none}',
  '.gc-td{padding:6px 4px;border-top:1px solid var(--dsw-alias-border-l1);color:var(--dsw-alias-label-secondary);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}',
  '.gc-title{color:var(--dsw-alias-label-primary)}',
  '.gc-sum{color:var(--dsw-alias-label-secondary);font-size:12px;line-height:1.5;padding:6px 4px 0;border-top:1px solid var(--dsw-alias-border-l2)}',
  '.gc-pager{display:flex;align-items:center;justify-content:flex-end;gap:10px;margin-top:8px;font-size:12px;color:var(--dsw-alias-label-secondary)}',
  '.gc-count{flex:1}',
  '.gc-page-btn{appearance:none;border:1px solid var(--dsw-alias-border-l2);background:0 0;color:inherit;font:inherit;font-size:12px;border-radius:6px;padding:2px 10px;cursor:pointer;line-height:1.6}',
  '.gc-page-btn:hover:not(:disabled){border-color:var(--dsw-alias-label-dimmed)}',
  '.gc-page-btn:disabled{opacity:.4;cursor:default}',
  '.gc-page-info{white-space:nowrap}',
  '.gc-empty{color:var(--dsw-alias-label-tertiary);font-size:12px;line-height:1.5;margin:8px 0 0}',
].join('\n')

function injectCardCss(): void {
  if (typeof document === 'undefined') return
  const id = 'dsh-human-coding/card.css'
  if (document.querySelector(`style[data-plugin-css=${JSON.stringify(id)}]`) !== null) return
  const tag = document.createElement('style')
  tag.dataset.plugin = 'dsh-human-coding'
  tag.dataset.pluginCss = id
  tag.textContent = CARD_CSS
  document.head.appendChild(tag)
}

/* ------------------------------ 词典 ------------------------------ */

export const zh: Record<string, string> = {
  'card.name': 'dsh-human-coding',
  'card.description': '古法编程模式：跨会话的挑战统计与长期评分',
  'card.expand': '展开插件设置',
  'card.collapse': '收起插件设置',
  'section.overview': '挑战概览',
  'section.results': '挑战结果',
  'section.modes': '收尾分布',
  'section.process': '答题过程',
  'section.scoring': '评分',
  'section.records': '逐题记录',
  'table.colTitle': '标题',
  'table.colScore': '完成度',
  'table.colDifficulty': '难度',
  'table.colContribution': '表现分（贡献）',
  'table.empty': '暂无逐题记录',
  'table.count': '共 {count} 题',
  'table.sum': '贡献合计 = 总表现分 {value}',
  'table.page': '{page} / {pages} 页',
  'table.prev': '上一页',
  'table.next': '下一页',
  'table.sortHint': '点击表头切换排序',
  'field.offers': '提议挑战',
  'field.accepts': '接受',
  'field.skips': '跳过',
  'field.acceptRate': '接受率',
  'field.passes': '通过',
  'field.fails': '未通过',
  'field.passRate': '通过率',
  'field.giveUps': '中途放弃',
  'field.giveUpsAfterFail': '失败后放弃',
  'field.exits': '主动退出',
  'field.attempts': '提交总次数',
  'field.avgAttempts': '平均提交/题',
  'field.hints': '提示消耗',
  'field.hintRate': '提示消耗率',
  'field.meanScore': '平均完成度',
  'field.performance': '表现分',
  'field.performanceTitle': '表现分（百分制，保留两位小数）= Σ(第 i 高单题表现分 × 0.95^(i-1)，最多取前 100 题) ÷ 100 题全满分的固定归一化因子 × 100（不足 100 题的位次按 0 分计）；单题表现分 = 完成度 × 难度 × 100（放弃/未通过的题按 0 分计）',
  'field.avgDifficulty': '平均难度',
  'field.scored': '已评分题目',
  'field.reset': '清零统计',
  'field.export': '导出记录',
  'field.importOverwrite': '导入（覆盖）',
  'field.importMerge': '导入（叠加）',
  importConfirmOverwrite: '覆盖导入将替换当前全部统计记录，确定继续？',
  importDone: '导入完成。',
  importError: '导入失败',
  'field.summary': '共 {count} 次挑战 · 通过率 {rate}',
  'mode.keep': '保留你的写法',
  'mode.polish': 'AI 略做修改',
  'mode.rewrite': 'AI 彻底重写',
  'mode.takeover': 'AI 接手',
  resetConfirm: '确定清空所有挑战统计与逐题记录？此操作不可撤销。',
  'status.loading': '统计加载中…',
  'status.unavailable': '统计暂不可用（Host 未注册命名空间）',
  'status.overBudget': '提示预算已超支',
}

export const en: Record<string, string> = {
  'card.name': 'dsh-human-coding',
  'card.description': 'Classical Programming Mode: cross-session challenge stats and long-term rating',
  'card.expand': 'Expand plugin settings',
  'card.collapse': 'Collapse plugin settings',
  'section.overview': 'Challenges',
  'section.results': 'Outcomes',
  'section.modes': 'Closing modes',
  'section.process': 'Solving',
  'section.scoring': 'Rating',
  'section.records': 'Per-challenge records',
  'table.colTitle': 'Title',
  'table.colScore': 'Completion',
  'table.colDifficulty': 'Difficulty',
  'table.colContribution': 'Performance (share)',
  'table.empty': 'No per-challenge records yet',
  'table.count': '{count} challenges',
  'table.sum': 'Shares sum to total performance {value}',
  'table.page': 'Page {page} / {pages}',
  'table.prev': 'Prev',
  'table.next': 'Next',
  'table.sortHint': 'Click headers to sort',
  'field.offers': 'Offered',
  'field.accepts': 'Accepted',
  'field.skips': 'Skipped',
  'field.acceptRate': 'Accept rate',
  'field.passes': 'Passed',
  'field.fails': 'Failed',
  'field.passRate': 'Pass rate',
  'field.giveUps': 'Gave up while solving',
  'field.giveUpsAfterFail': 'Gave up after fail',
  'field.exits': 'Aborted',
  'field.attempts': 'Total submissions',
  'field.avgAttempts': 'Avg submissions',
  'field.hints': 'Hints used',
  'field.hintRate': 'Hint consumption',
  'field.meanScore': 'Mean completion',
  'field.performance': 'Performance',
  'field.performanceTitle': 'Performance (0-100, two decimals) = Σ(top-100 per-challenge points, i-th highest × 0.95^(i-1)) ÷ the fixed all-perfect 100-challenge denominator × 100 (slots below 100 challenges count as 0); per-challenge points = score × difficulty × 100 (failed/given-up count as 0)',
  'field.avgDifficulty': 'Avg difficulty',
  'field.scored': 'Scored challenges',
  'field.reset': 'Reset stats',
  'field.export': 'Export records',
  'field.importOverwrite': 'Import (replace)',
  'field.importMerge': 'Import (merge)',
  importConfirmOverwrite: 'Replacing import will overwrite all current records. Continue?',
  importDone: 'Import complete.',
  importError: 'Import failed',
  'field.summary': '{count} challenges · pass rate {rate}',
  'mode.keep': 'Kept yours',
  'mode.polish': 'AI polished',
  'mode.rewrite': 'AI rewrote',
  'mode.takeover': 'AI took over',
  resetConfirm: 'Reset all challenge stats and per-challenge records? This cannot be undone.',
  'status.loading': 'Loading stats…',
  'status.unavailable': 'Stats unavailable (namespace not registered on host)',
  'status.overBudget': 'Hint budget exceeded',
}

/* ------------------------------ 组件 ------------------------------ */

const pct = (ratio: number): string => `${Math.round(ratio * 100)}%`

const one = (value: number): string => (Number.isFinite(value) ? value.toFixed(1) : '—')

/** 0-1 数值的显示：固定两位小数（0.4 → "0.40"；0.35 的浮点误差由 toFixed(2) 正确舍入）。 */
const fmt01 = (value: number): string => value.toFixed(2)

function derive(stats: GufaStats) {
  const verdicts = stats.passes + stats.fails
  const ended = verdicts + stats.giveUps + stats.giveUpsAfterFail + stats.exits
  return {
    acceptRate: stats.offers > 0 ? stats.accepts / stats.offers : 0,
    passRate: verdicts > 0 ? stats.passes / verdicts : 0,
    avgAttempts: ended > 0 ? stats.attempts / ended : 0,
    hintRate: stats.hintsBudget > 0 ? stats.hintsUsed / stats.hintsBudget : 0,
    meanScore: stats.scoreCount > 0 ? stats.scoreSum / stats.scoreCount : 0,
    avgDifficulty: stats.difficultyCount > 0 ? stats.difficultySum / stats.difficultyCount : 0,
  }
}

function Cell(props: {
  t: (key: string) => string
  labelKey: string
  value: string
  color?: string
  title?: string
}): React.ReactNode {
  const { t, labelKey, value, color, title } = props
  return (
    <div className="gc-cell" title={title}>
      <div className="gc-value" style={color === undefined ? undefined : { color }}>
        {value}
      </div>
      <div className="gc-label">{t(labelKey)}</div>
    </div>
  )
}

function Section(props: {
  t: (key: string) => string
  titleKey: string
  children: React.ReactNode
}): React.ReactNode {
  return (
    <div>
      <div className="gc-section-title">{props.t(props.titleKey)}</div>
      <div className="gc-grid">{props.children}</div>
    </div>
  )
}

const MODE_CELLS: Array<{ mode: keyof GufaStats['modes']; labelKey: string }> = [
  { mode: 'keep', labelKey: 'mode.keep' },
  { mode: 'polish', labelKey: 'mode.polish' },
  { mode: 'rewrite', labelKey: 'mode.rewrite' },
  { mode: 'takeover', labelKey: 'mode.takeover' },
]

export default function StatsCard(props: { t: (key: string) => string }): React.ReactNode {
  const { t } = props
  const [open, setOpen] = React.useState(false)
  const [resetting, setResetting] = React.useState(false)

  React.useEffect(() => {
    injectCardCss()
  }, [])

  const snapshot = useSyncExternalStore(
    (listener) => (getGufaScope() === undefined ? () => {} : getGufaScope()!.subscribe(listener)),
    () => getGufaScope()?.getSnapshot() ?? UNAVAILABLE_SNAPSHOT,
  )

  const ready = snapshot.status === 'ready' && snapshot.value !== undefined
  const stats = ready && snapshot.value !== undefined ? (snapshot.value.stats as unknown as GufaStats) : emptyStats(0)
  const history = ready && snapshot.value !== undefined ? (snapshot.value.history as GufaChallengeRecord[]) : []
  // 展示统计：结果类指标由逐题记录计算，事件计数（offers/skips/accepts/exits）保留聚合。
  const display = deriveStats(stats, history)
  const d = derive(display)
  const performance = performanceScore(history)

  const reset = (): void => {
    const scope = getGufaScope()
    if (scope === undefined || resetting || !snapshot.writable) return
    if (typeof window !== 'undefined' && !window.confirm(t('resetConfirm'))) return
    setResetting(true)
    // 统计页的结果类指标由逐题 history 重算（deriveStats/performanceScore），
    // 因此清零必须同时清除 stats 与 history，否则信息仍会残留。
    void Promise.all([scope.set('stats', emptyStats()), scope.set('history', [])])
      .catch(() => {})
      .finally(() => setResetting(false))
  }

  const importMode = React.useRef<'overwrite' | 'merge'>('overwrite')
  const fileRef = React.useRef<HTMLInputElement | null>(null)
  const [importMsg, setImportMsg] = React.useState<string | null>(null)

  const exportRecords = (): void => {
    if (typeof document === 'undefined') return
    const data = buildExport(stats, history)
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `dsh-human-coding-stats-${new Date().toISOString().slice(0, 10)}.json`
    a.click()
    URL.revokeObjectURL(url)
  }

  const applyImport = async (text: string): Promise<void> => {
    const scope = getGufaScope()
    if (scope === undefined) return
    const parsed = parseImport(text)
    if (!parsed.ok) {
      setImportMsg(`${t('importError')}：${parsed.error}`)
      return
    }
    const mode = importMode.current
    if (mode === 'overwrite') {
      if (typeof window !== 'undefined' && !window.confirm(t('importConfirmOverwrite'))) return
      await scope.set('stats', parsed.data.stats)
      await scope.set('history', parsed.data.history)
      setImportMsg(t('importDone'))
      return
    }
    const merged = mergeImport(history, stats, parsed.data.history, parsed.data.stats)
    await scope.set('history', merged.history)
    await scope.set('stats', merged.stats)
    setImportMsg(t('importDone'))
  }

  const pickImport = (mode: 'overwrite' | 'merge'): void => {
    importMode.current = mode
    setImportMsg(null)
    fileRef.current?.click()
  }

  const onFileChange = (event: React.ChangeEvent<HTMLInputElement>): void => {
    const file = event.target.files?.[0]
    event.target.value = ''
    if (file === undefined) return
    void file
      .text()
      .then((text) => applyImport(text))
      .catch(() => setImportMsg(t('importError')))
  }

  const summary = t('field.summary')
    .replace('{count}', String(display.accepts))
    .replace('{rate}', pct(d.passRate))

  return (
    <li className={open ? 'gc-card gc-card-open' : 'gc-card'}>
      <button
        type="button"
        className="gc-header"
        aria-expanded={open}
        aria-label={`${t(open ? 'card.collapse' : 'card.expand')}: ${t('card.name')}`}
        onClick={() => setOpen(!open)}
      >
        <span className="gc-head-text">
          <span className="gc-name">{t('card.name')}</span>
          <span className="gc-desc">{t('card.description')}</span>
        </span>
        <svg
          className={open ? 'gc-chevron gc-chevron-open' : 'gc-chevron'}
          width="14"
          height="14"
          viewBox="0 0 14 14"
          fill="none"
          aria-hidden="true"
        >
          <path
            d="M3.5 5.25 7 8.75l3.5-3.5"
            stroke="currentColor"
            strokeWidth="1.5"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </svg>
      </button>
      {open ? (
        <div className="gc-body">
          {!ready ? (
            <p className="gc-status">
              {snapshot.status === 'unavailable' ? t('status.unavailable') : t('status.loading')}
            </p>
          ) : (
            <>
              <p className="gc-summary">
                <b>{summary}</b>
              </p>
              <Section t={t} titleKey="section.overview">
                <Cell t={t} labelKey="field.offers" value={String(display.offers)} />
                <Cell t={t} labelKey="field.accepts" value={String(display.accepts)} />
                <Cell t={t} labelKey="field.skips" value={String(display.skips)} />
                <Cell
                  t={t}
                  labelKey="field.acceptRate"
                  value={pct(d.acceptRate)}
                  color={display.offers > 0 ? scoreColor(d.acceptRate) : undefined}
                />
              </Section>
              <Section t={t} titleKey="section.results">
                <Cell t={t} labelKey="field.passes" value={String(display.passes)} />
                <Cell t={t} labelKey="field.fails" value={String(display.fails)} />
                <Cell
                  t={t}
                  labelKey="field.passRate"
                  value={pct(d.passRate)}
                  color={display.passes + display.fails > 0 ? scoreColor(d.passRate) : undefined}
                />
                <Cell t={t} labelKey="field.giveUps" value={String(display.giveUps)} />
                <Cell t={t} labelKey="field.giveUpsAfterFail" value={String(display.giveUpsAfterFail)} />
                <Cell t={t} labelKey="field.exits" value={String(display.exits)} />
              </Section>
              <Section t={t} titleKey="section.modes">
                {MODE_CELLS.map(({ mode, labelKey }) => (
                  <Cell key={mode} t={t} labelKey={labelKey} value={String(display.modes[mode])} />
                ))}
              </Section>
              <Section t={t} titleKey="section.process">
                <Cell t={t} labelKey="field.attempts" value={String(display.attempts)} />
                <Cell t={t} labelKey="field.avgAttempts" value={one(d.avgAttempts)} />
                <Cell t={t} labelKey="field.hints" value={`${display.hintsUsed}/${display.hintsBudget}`} />
                <Cell
                  t={t}
                  labelKey="field.hintRate"
                  value={pct(d.hintRate)}
                  color={d.hintRate > 1 ? scoreColor(0) : undefined}
                  title={d.hintRate > 1 ? t('status.overBudget') : undefined}
                />
              </Section>
              <Section t={t} titleKey="section.scoring">
                <Cell
                  t={t}
                  labelKey="field.meanScore"
                  value={pct(d.meanScore)}
                  color={display.scoreCount > 0 ? scoreColor(d.meanScore) : undefined}
                />
                <Cell
                  t={t}
                  labelKey="field.performance"
                  value={performance.toFixed(2)}
                  color={history.length > 0 ? scoreColor(performance / 100) : undefined}
                  title={t('field.performanceTitle')}
                />
                <Cell
                  t={t}
                  labelKey="field.avgDifficulty"
                  value={fmt01(d.avgDifficulty)}
                  color={display.difficultyCount > 0 ? difficultyColor(d.avgDifficulty) : undefined}
                />
                <Cell t={t} labelKey="field.scored" value={String(display.scoreCount)} />
              </Section>
              <div className="gc-section-title">{t('section.records')}</div>
              <RecordsTable records={history} t={t} />
              <div className="gc-footer">
                <button
                  type="button"
                  className="gc-reset"
                  disabled={!ready || resetting || !snapshot.writable}
                  onClick={reset}
                >
                  {t('field.reset')}
                </button>
                <button type="button" className="gc-import" disabled={!ready} onClick={exportRecords}>
                  {t('field.export')}
                </button>
                <button type="button" className="gc-import" disabled={!ready || !snapshot.writable} onClick={() => pickImport('overwrite')}>
                  {t('field.importOverwrite')}
                </button>
                <button type="button" className="gc-import" disabled={!ready || !snapshot.writable} onClick={() => pickImport('merge')}>
                  {t('field.importMerge')}
                </button>
                <input ref={fileRef} type="file" accept=".json,application/json" style={{ display: 'none' }} onChange={onFileChange} />
              </div>
              {importMsg !== null ? <p className="gc-status">{importMsg}</p> : null}
            </>
          )}
        </div>
      ) : null}
    </li>
  )
}
