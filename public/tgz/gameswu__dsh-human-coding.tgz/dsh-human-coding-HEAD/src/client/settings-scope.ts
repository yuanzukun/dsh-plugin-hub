/**
 * 客户端 settings 命名空间的共享绑定（Host 侧同名命名空间）。
 *
 * 状态条与统计卡片共用同一个 scope 绑定：命名空间由常驻宿主行注册，
 * 因此无论当前是否有古法会话，绑定与订阅都可用。
 */
export interface GufaSettingsSnapshot {
  status: string
  value?: {
    stats: {
      offers: number
      accepts: number
      passes: number
      fails: number
      [key: string]: unknown
    }
    history: unknown[]
    challenges: Record<string, unknown>
  }
  writable: boolean
}

export interface GufaSettingsScope {
  getSnapshot(): GufaSettingsSnapshot
  subscribe(listener: () => void): () => void
  set(field: string, value: unknown): Promise<void>
}

interface PluginCtxFace {
  settingsScope: {
    bind(spec: { namespace: string }): unknown
  }
}

/** 命名空间未绑定的稳定快照：useSyncExternalStore 要求 getSnapshot 返回缓存引用。 */
export const UNAVAILABLE_SNAPSHOT: GufaSettingsSnapshot = {
  status: 'unavailable',
  writable: false,
}

let gufaScope: GufaSettingsScope | undefined

/** 在插件 apply 内绑定 settings 命名空间（生命周期随插件 fiber）。 */
export function attachGufaScope(ctx: PluginCtxFace): void {
  gufaScope = ctx.settingsScope.bind({ namespace: 'dsh-human-coding' }) as GufaSettingsScope
}

export function getGufaScope(): GufaSettingsScope | undefined {
  return gufaScope
}
