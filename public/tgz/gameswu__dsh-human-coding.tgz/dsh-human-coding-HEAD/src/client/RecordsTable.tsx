/**
 * 逐题记录表格（统计卡片内）：标题 / 完成度 / 难度 / 表现分（贡献）。
 *
 * - 「表现分」列 = performanceContributions() 的 contribution——
 *   该题在总表现分里贡献的数值；所有贡献之和 === 总表现分
 *   （performanceScore），表尾合计行展示这层关系；
 * - 每页固定 5 项，翻页按钮在越界时禁用；
 * - 默认按贡献降序；点击表头切换排序字段，再点同列切换升/降序；
 * - 标题超长省略号 + 原生 title 提示；贡献列按「贡献 / 最大贡献」
 *   着色（最高贡献最绿），0 贡献保持中性。
 */
import React from 'react'
import type { GufaChallengeRecord } from '../shared/state'
import { performanceContributions, performanceScore } from './records'
import { scoreColor } from './score-color'

/** 每页固定展示的题目数。 */
export const PAGE_SIZE = 5

type SortKey = 'contribution' | 'title' | 'score' | 'difficulty'

interface Row {
  stableId: string
  record: GufaChallengeRecord
  contribution: number
  score: number
}

interface Column {
  key: SortKey
  labelKey: string
}

const COLUMNS: Column[] = [
  { key: 'title', labelKey: 'table.colTitle' },
  { key: 'score', labelKey: 'table.colScore' },
  { key: 'difficulty', labelKey: 'table.colDifficulty' },
  { key: 'contribution', labelKey: 'table.colContribution' },
]

/** 完成度显示：未评分为 —，否则百分比整数。 */
function formatScore(score: number | null): string {
  return score === null ? '—' : `${Math.round(score * 100)}%`
}

export default function RecordsTable(props: { records: GufaChallengeRecord[]; t: (key: string) => string }): React.ReactNode {
  const { records, t } = props
  const [page, setPage] = React.useState(0)
  const [sortKey, setSortKey] = React.useState<SortKey>('contribution')
  const [sortAsc, setSortAsc] = React.useState(false)

  const contributionById = React.useMemo(() => {
    const map = new Map<string, number>()
    for (const item of performanceContributions(records)) map.set(item.record.id, item.contribution)
    return map
  }, [records])

  const rows: Row[] = React.useMemo(() => {
    const built = records.map((record, index) => ({
      stableId: `${record.id}@${index}`,
      record,
      contribution: contributionById.get(record.id) ?? 0,
      score: record.score ?? 0,
    }))
    const dir = sortAsc ? 1 : -1
    built.sort((a, b) => {
      switch (sortKey) {
        case 'title':
          return a.record.title.localeCompare(b.record.title, 'zh-Hans-CN') * dir
        case 'score':
          return (a.score - b.score) * dir
        case 'difficulty':
          return (a.record.difficulty - b.record.difficulty) * dir
        default:
          return (a.contribution - b.contribution) * dir
      }
    })
    return built
  }, [records, contributionById, sortKey, sortAsc])

  const totalPages = Math.max(1, Math.ceil(rows.length / PAGE_SIZE))
  const safePage = Math.min(page, totalPages - 1)
  const pageRows = rows.slice(safePage * PAGE_SIZE, safePage * PAGE_SIZE + PAGE_SIZE)
  const maxContribution = rows.length > 0 ? Math.max(...rows.map((row) => row.contribution)) : 0

  const onSort = (key: SortKey): void => {
    if (sortKey === key) {
      setSortAsc(!sortAsc)
    } else {
      setSortKey(key)
      // 切到新字段：贡献列默认降序（值大者靠前），其余默认升序。
      setSortAsc(key !== 'contribution')
    }
    setPage(0)
  }

  if (records.length === 0) {
    return <p className="gc-empty">{t('table.empty')}</p>
  }

  return (
    <div>
      <table className="gc-table">
        <colgroup>
          <col className="gc-col-title" />
          <col className="gc-col-num" />
          <col className="gc-col-num" />
          <col className="gc-col-num" />
        </colgroup>
        <thead>
          <tr>
            {COLUMNS.map((column) => (
              <th key={column.key} className="gc-th">
                <button
                  type="button"
                  className="gc-th-btn"
                  title={t('table.sortHint')}
                  onClick={() => onSort(column.key)}
                >
                  {t(column.labelKey)}
                  {sortKey === column.key ? (
                    <span className="gc-sort" aria-hidden="true">
                      {sortAsc ? '▲' : '▼'}
                    </span>
                  ) : null}
                </button>
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {pageRows.map((row) => (
            <tr key={row.stableId}>
              <td className="gc-td gc-title" title={row.record.title}>
                {row.record.title}
              </td>
              <td className="gc-td">{formatScore(row.record.score)}</td>
              <td className="gc-td">{row.record.difficulty.toFixed(2)}</td>
              <td
                className="gc-td"
                style={maxContribution > 0 ? { color: scoreColor(row.contribution / maxContribution) } : undefined}
              >
                {row.contribution.toFixed(2)}
              </td>
            </tr>
          ))}
        </tbody>
        <tfoot>
          <tr>
            <td className="gc-sum" colSpan={4}>
              {t('table.sum').replace('{value}', performanceScore(records).toFixed(2))}
            </td>
          </tr>
        </tfoot>
      </table>
      <div className="gc-pager">
        <span className="gc-count">{t('table.count').replace('{count}', String(records.length))}</span>
        <button
          type="button"
          className="gc-page-btn"
          disabled={safePage === 0}
          onClick={() => setPage(safePage - 1)}
        >
          {t('table.prev')}
        </button>
        <span className="gc-page-info">
          {t('table.page').replace('{page}', String(safePage + 1)).replace('{pages}', String(totalPages))}
        </span>
        <button
          type="button"
          className="gc-page-btn"
          disabled={safePage >= totalPages - 1}
          onClick={() => setPage(safePage + 1)}
        >
          {t('table.next')}
        </button>
      </div>
    </div>
  )
}
