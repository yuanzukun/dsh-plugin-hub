/**
 * 数值记录的导出/导入（只涉及数值，不含会话历史）。
 *
 * - 导出：stats + 逐题 history 打包成 JSON 文件；
 * - 覆盖导入：整体替换 stats 与 history；
 * - 叠加导入：history 按标题去重合并（本地优先），stats 由合并后的
 *   history 重算；offers/skips/exits 无法从逐题记录推导，取两侧较大值
 *   （避免跨机重复计数）。
 */
import type {
  GufaChallengeRecord,
  GufaExport,
  GufaStats,
} from '../shared/state'
import { emptyStats } from '../shared/state'

/** 标题归一化：trim + 小写（去重键）。 */
function normTitle(title: unknown): string {
  return String(title ?? '').trim().toLowerCase()
}

/** 表现分聚合参数：最多取前 100 高的单题表现分；几何衰减因子。 */
export const PERFORMANCE_TOP = 100
export const PERFORMANCE_DECAY = 0.95

/** 固定归一化因子：100 题全满分时的分子大小（不足 100 题的位次按 0 分计）。 */
export const PERFORMANCE_DENOMINATOR =
  (100 * (1 - Math.pow(PERFORMANCE_DECAY, PERFORMANCE_TOP))) / (1 - PERFORMANCE_DECAY)

/**
 * 表现分（0-100，百分制）：
 * 每题表现分 = 完成度 × 难度 × 100（满分 100；放弃/未通过按 0 分计）。
 * 单题表现分从高到低排序，只取前 100 题，按 0.95 的几何衰减加权
 * （第 i 高分权重 0.95^(i-1)），除以**固定**的 100 题全满分归一化因子
 * 再 × 100——不足 100 题的位次按 0 分计，因此记录不足时分数随积累
 * 增长，新增任何记录都不会降低总分（0 分的记录也不扣分，只是不涨）。
 * 无记录时为 0。实现上即逐题贡献（performanceContributions）之和。
 */
export function performanceScore(history: GufaChallengeRecord[]): number {
  return performanceContributions(history).reduce((sum, item) => sum + item.contribution, 0)
}

/** 一条逐题记录在总表现分中的贡献分解。 */
export interface PerformanceContribution {
  record: GufaChallengeRecord
  /** 单题表现分 = 完成度 × 难度 × 100（未评分/放弃为 0）。 */
  points: number
  /** 名次权重 0.95^(rank-1)（rank 从 1 起，按单题表现分降序）。 */
  weight: number
  /** 贡献 = points × weight ÷ PERFORMANCE_DENOMINATOR × 100。 */
  contribution: number
}

/**
 * 逐题贡献分解：按单题表现分降序取前 100 题（第 100 名之后贡献为 0，
 * 不进入分解），每题贡献 = points × 0.95^(rank-1) ÷ 固定归一化 × 100。
 * 所有贡献之和 === performanceScore（总表现分）；题目表格的
 * 「表现分」列即本函数的 contribution。
 */
export function performanceContributions(history: GufaChallengeRecord[]): PerformanceContribution[] {
  const ranked = history
    .map((record) => ({ record, points: (record.score ?? 0) * record.difficulty * 100 }))
    .sort((a, b) => b.points - a.points)
  return ranked.slice(0, PERFORMANCE_TOP).map(({ record, points }, index) => {
    const weight = Math.pow(PERFORMANCE_DECAY, index)
    return { record, points, weight, contribution: ((points * weight) / PERFORMANCE_DENOMINATOR) * 100 }
  })
}

/** 构建导出文件内容。 */
export function buildExport(stats: GufaStats, history: GufaChallengeRecord[], now: number = Date.now()): GufaExport {
  return { schema: 'dsh-human-coding-stats', version: 1, exportedAt: now, stats, history }
}

function finite(value: unknown): number | undefined {
  const n = Number(value)
  return Number.isFinite(n) ? n : undefined
}

/** 校验并规整一条逐题记录；非法返回 undefined。 */
function normalizeRecord(raw: unknown): GufaChallengeRecord | undefined {
  if (typeof raw !== 'object' || raw === null) return undefined
  const r = raw as Record<string, unknown>
  const title = typeof r.title === 'string' && r.title.trim() !== '' ? r.title.trim() : undefined
  const outcome = r.outcome === 'pass' || r.outcome === 'fail' || r.outcome === 'giveup' ? r.outcome : undefined
  const mode = r.mode === 'keep' || r.mode === 'polish' || r.mode === 'rewrite' || r.mode === 'takeover' ? r.mode : undefined
  if (title === undefined || outcome === undefined || mode === undefined) return undefined
  const difficulty = finite(r.difficulty)
  const attempts = finite(r.attempts)
  const hintsUsed = finite(r.hintsUsed)
  const maxHints = finite(r.maxHints)
  const updatedAt = finite(r.updatedAt)
  const scoreRaw = r.score === null ? null : finite(r.score)
  if (scoreRaw === undefined) return undefined
  if (difficulty === undefined || attempts === undefined || hintsUsed === undefined || maxHints === undefined || updatedAt === undefined) return undefined
  return {
    id: typeof r.id === 'string' ? r.id : `${title}:${updatedAt}`,
    title,
    outcome,
    mode,
    score: scoreRaw === null ? null : Math.min(1, Math.max(0, scoreRaw)),
    difficulty: Math.min(1, Math.max(0, difficulty)),
    attempts: Math.max(0, Math.round(attempts)),
    hintsUsed: Math.max(0, Math.round(hintsUsed)),
    maxHints: Math.max(1, Math.round(maxHints)),
    updatedAt,
  }
}

/** 解析导入文本；非法返回错误信息。 */
export function parseImport(text: string): { ok: true; data: GufaExport } | { ok: false; error: string } {
  let parsed: unknown
  try {
    parsed = JSON.parse(text)
  } catch {
    return { ok: false, error: '不是合法的 JSON 文件' }
  }
  if (typeof parsed !== 'object' || parsed === null) return { ok: false, error: '文件结构不正确' }
  const p = parsed as Record<string, unknown>
  if (p.schema !== 'dsh-human-coding-stats') return { ok: false, error: '不是古法编程的导出文件' }
  if (!Array.isArray(p.history)) return { ok: false, error: '文件缺少 history 记录' }
  if (typeof p.stats !== 'object' || p.stats === null) return { ok: false, error: '文件缺少 stats 数据' }
  const history = p.history.map(normalizeRecord).filter((r): r is GufaChallengeRecord => r !== undefined)
  return { ok: true, data: { schema: 'dsh-human-coding-stats', version: 1, exportedAt: finite(p.exportedAt) ?? Date.now(), stats: p.stats as GufaStats, history } }
}

/** 叠加合并：本地优先，导入记录按标题去重后并入。 */
export function mergeHistory(local: GufaChallengeRecord[], imported: GufaChallengeRecord[]): GufaChallengeRecord[] {
  const seen = new Set(local.map((r) => normTitle(r.title)))
  const merged = [...local]
  for (const record of imported) {
    const key = normTitle(record.title)
    if (seen.has(key)) continue
    seen.add(key)
    merged.push(record)
  }
  return merged
}

/**
 * 由逐题记录重算可推导的统计；offers/skips/exits 取 base（两侧较大值）。
 */
export function recomputeStats(history: GufaChallengeRecord[], base: GufaStats): GufaStats {
  const stats = emptyStats(base.updatedAt)
  stats.offers = base.offers
  stats.skips = base.skips
  stats.exits = base.exits
  stats.accepts = base.accepts
  for (const record of history) {
    stats.attempts += record.attempts
    stats.hintsUsed += record.hintsUsed
    stats.hintsBudget += record.maxHints
    stats.difficultySum += record.difficulty
    stats.difficultyCount += 1
    stats.modes[record.mode] += 1
    if (record.outcome === 'pass') {
      stats.passes += 1
      const score = record.score ?? 0
      stats.scoreSum += score
      stats.scoreCount += 1
      stats.weightedScoreSum += score * record.difficulty
      stats.scoredDifficultySum += record.difficulty
    } else if (record.outcome === 'fail') {
      stats.fails += 1
      stats.giveUpsAfterFail += 1
    } else {
      stats.giveUps += 1
    }
  }
  return stats
}

/** 叠加导入的合并结果：去重后的 history + 重算后的 stats。 */
export function mergeImport(
  localHistory: GufaChallengeRecord[],
  localStats: GufaStats,
  importedHistory: GufaChallengeRecord[],
  importedStats: GufaStats,
): { history: GufaChallengeRecord[]; stats: GufaStats } {
  const history = mergeHistory(localHistory, importedHistory)
  const base: GufaStats = {
    ...emptyStats(Date.now()),
    offers: Math.max(localStats.offers, importedStats.offers),
    skips: Math.max(localStats.skips, importedStats.skips),
    exits: Math.max(localStats.exits, importedStats.exits),
    accepts: Math.max(localStats.accepts, importedStats.accepts),
  }
  return { history, stats: recomputeStats(history, base) }
}

/**
 * 展示统计 = 由逐题记录重算可推导项（结果类指标），offers/skips/
 * accepts/exits 保留聚合事件计数。历史为空时结果类指标为 0。
 */
export function deriveStats(stats: GufaStats, history: GufaChallengeRecord[]): GufaStats {
  const base: GufaStats = {
    ...emptyStats(stats.updatedAt),
    offers: stats.offers,
    skips: stats.skips,
    exits: stats.exits,
    accepts: stats.accepts,
  }
  return recomputeStats(history, base)
}
