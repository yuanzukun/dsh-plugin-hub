/**
 * 统一色阶：0-1 数值 → 红(0°) → 黄(60°) → 绿(120°) 的连续 HSL 渐变。
 *
 * - 连续插值：每个数值都有专属色相（无限分区，足够细致）；
 * - 高亮：饱和度 88%、亮度 52%，明暗主题下都醒目；
 * - 输出为内联样式可直接使用的颜色字符串，不依赖 CSS 类或主题变量。
 */

/** 0-1 → 红到绿（分数类：越高越绿）。 */
export function scoreColor(ratio: number): string {
  const clamped = Math.min(1, Math.max(0, ratio))
  const hue = Math.round(clamped * 120)
  return `hsl(${hue}, 88%, 52%)`
}

/** 0-1 难度 → 绿到红（越难越红）。 */
export function difficultyColor(difficulty: number): string {
  return scoreColor(1 - Math.min(1, Math.max(0, difficulty)))
}
