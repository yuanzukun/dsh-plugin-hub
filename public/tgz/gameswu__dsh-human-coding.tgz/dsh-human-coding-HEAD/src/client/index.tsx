/**
 * 插件入口（Client 半边）：
 * 1. 输入框上方 dock：古法编程状态条（挑战中常驻）；
 * 2. 设置 → 插件：dsh-human-coding 统计卡片（读 settings 命名空间，
 *    经平台 settingsScope 服务读写，无需自定义 RPC）。
 *
 * 包在 package.json 中声明 `dsh.client`，由 dsh-client-modules 扫描并
 * 编入页面模块图；`window.__ModuleLoader__` 在运行时按需物化本模块。
 */
import GufaDock from './GufaDock'
import StatsCard, { LOCALE_NS, zh, en } from './StatsCard'
import { attachGufaScope } from './settings-scope'

interface PluginCtx {
  slots: {
    register(options: Record<string, unknown>, component: unknown): () => void
    inject(key: string, callback: () => unknown): void
  }
  locale: {
    register(namespace: string, dictionaries: Record<string, Record<string, string>>): unknown
  }
  effect(callback: () => unknown, label?: string): unknown
  settingsScope: {
    bind(spec: { namespace: string }): unknown
  }
}

export const inject = ['slots', 'locale', 'settingsScope']

export function apply(ctx: PluginCtx) {
  ctx.effect(() => ctx.locale.register(LOCALE_NS, { zh, en }), 'dsh-human-coding: card dictionaries')
  attachGufaScope(ctx)

  ctx.slots.inject('conversation.input.dock', () =>
    ctx.slots.register(
      {
        name: 'conversation.input.dock',
        id: 'gufa',
        order: 15,
        label: '古法编程',
      },
      GufaDock,
    ),
  )

  // 设置页卡片：key = settings 命名空间（dsh-human-coding），与 Host 侧
  // settings.register 的命名空间一致，平台按命名空间分派。
  ctx.slots.inject('settings.plugin.item', () =>
    ctx.slots.register(
      { name: 'settings.plugin.item', key: 'dsh-human-coding', locale: LOCALE_NS },
      StatsCard,
    ),
  )
}
