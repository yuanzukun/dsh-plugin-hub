/**
 * Host half of dsh-notify: a deliberate no-op.
 *
 * All behavior lives in the browser half (`client.js`), which the web shell
 * loads through the client-module system. This entry exists only so the
 * Loader row inserted by cordis.patch.yml has a valid host-side module to
 * load; keeping it empty guarantees the plugin costs nothing on the host.
 */

export const name = 'dsh-notify'

export function apply() {
  // No host-side capability to register.
}
