/**
 * dsh-notify browser bundle (hand-written in the client-module handoff format:
 * script execution only REGISTERS this factory; the body runs at
 * materialization inside the web shell).
 *
 * Watches the sessions list through the standard-kit useSessions hook and
 * fires desktop browser notifications on two edges:
 *   1. running true -> false          对话完成
 *   2. pendingInteraction unset -> set 等待确认 (approval / question / plan-review)
 *
 * Noise gate: a notification fires only when the page is hidden, or the
 * affected session is not the currently selected one. Permission is requested
 * once on mount; a denied/absent Notification API degrades to silence.
 */
window.__ModuleLoader__.load({
	id: "dsh-notify",
	factory: (require) => {
		var module = { exports: {} };
		var exports = module.exports;
		Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
		let react = require("react");

		const WAIT_LABELS = {
			approval: "等待批准",
			"plan-review": "等待计划审批",
			question: "等待回答",
		};

		const AUTO_CLOSE_MS = 10000;

		/** Fire one desktop notification; silent on any refusal or absence. */
		function notify(title, body, tag) {
			try {
				if (typeof Notification === "undefined") return;
				if (Notification.permission !== "granted") return;
				const n = new Notification(title, { body, tag });
				n.onclick = () => {
					window.focus();
					n.close();
				};
				setTimeout(() => n.close(), AUTO_CLOSE_MS);
			} catch {
				// Degrade to silence — never break the slot tree.
			}
		}

		/**
		 * Invisible watcher mounted in the always-rendered `shell.overlay` slot.
		 * Root-scoped slot components receive the global standard kit, which
		 * carries useSessions over the full session list (running bits and
		 * pending interaction status included).
		 */
		function NotifyWatcher({ useSessions }) {
			const state = useSessions((s) => s);
			const prevRef = react.useRef(undefined);

			react.useEffect(() => {
				const prev = prevRef.current;
				prevRef.current = state;
				if (prev === undefined) return; // first snapshot is the baseline

				const pageVisible = typeof document !== "undefined" && document.visibilityState === "visible";

				for (const id of Object.keys(state.byId)) {
					const now = state.byId[id];
					const before = prev.byId[id];
					if (before === undefined) continue; // session appeared mid-flight: no edge
					const title = now.displayTitle || id;
					const background = !pageVisible || state.current !== id;

					// 对话完成: the session stopped running.
					if (before.running && !now.running && background) {
						notify("对话完成", title, `dsh-notify-done-${id}`);
					}

					// 等待确认: an interaction started blocking the session.
					const waitBefore = before.pendingInteraction;
					const waitNow = now.pendingInteraction;
					if (waitNow !== undefined && waitBefore === undefined && background) {
						notify(WAIT_LABELS[waitNow] || "等待确认", title, `dsh-notify-wait-${id}`);
					}
				}
			}, [state]);

			// Request permission exactly once per page (no user gesture needed on
			// localhost origins; a dismissed prompt stays dismissed until the user
			// re-enables it in site settings).
			react.useEffect(() => {
				try {
					if (typeof Notification === "undefined") return;
					if (Notification.permission === "default") {
						void Notification.requestPermission();
					}
				} catch {
					// Ignore — plugin stays silent.
				}
			}, []);

			return null;
		}
		NotifyWatcher.displayName = "DshNotifyWatcher";

		const inject = ["slots"];

		/** Register the invisible watcher into the always-mounted shell overlay. */
		function apply(ctx) {
			ctx.slots.inject("shell.overlay", () => ctx.slots.register({
				name: "shell.overlay",
				id: "dsh-notify",
				order: 90,
			}, NotifyWatcher));
		}

		exports.apply = apply;
		exports.inject = inject;
		exports.NotifyWatcher = NotifyWatcher;
		return module.exports;
	},
});
