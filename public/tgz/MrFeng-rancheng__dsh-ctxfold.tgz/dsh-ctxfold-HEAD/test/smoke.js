/**
 * 冒烟测试：不启动 DSH，直接在 node 里跑插件的 apply()，
 * 检查 7 个工具都注册上、ask 的输出带可 recall 的 id、fix_context 能取回原文。
 *
 *   node test/smoke.js [corpus]
 */
'use strict'

const os = require('node:os')
const path = require('node:path')
const plugin = require(path.join(__dirname, '..', 'index.js'))

const CORPUS = process.argv[2]
  || 'C:\\Users\\13956\\.dsh\\dsh-runtimes\\dsh-primary-runtime\\dependencies\\python\\Lib\\json'
const STATE = path.join(os.tmpdir(), 'ctxfold-smoke-state')

const specs = []
const ctx = { tools: { register: function (s) { specs.push(s); return s } } }

async function main() {
  plugin.apply(ctx, { corpus: CORPUS, state: STATE, budget: 1600 })
  const names = specs.map(function (s) { return s.name })
  console.log('注册工具数:', names.length)
  console.log('工具:', names.join(', '))
  if (names.length !== 7) throw new Error('工具数量不是 7')

  const ask = specs.find(function (s) { return s.name === 'ctxfold_ask' })
  const t0 = Date.now()
  const r1 = await ask.execute({ query: 'JSONDecoder.decode 抛什么异常、它调用了谁' })
  const txt1 = (r1 && r1.text) || ''
  console.log('\n[ask] 耗时', Date.now() - t0, 'ms | 长度', txt1.length)
  console.log('[ask] 含出处头:', /### #/.test(txt1))
  console.log('[ask] 含 recall 建议:', txt1.indexOf('可按下 id 取回原文') >= 0)
  console.log('[ask] 有改动检测提示:', txt1.indexOf('改动检测') >= 0)
  console.log('[ask] 首行:', txt1.split('\n')[0].slice(0, 90))

  const fix = specs.find(function (s) { return s.name === 'ctxfold_fix_context' })
  const t1 = Date.now()
  const r2 = await fix.execute({
    fail_output: 'AssertionError: assert 3 == 4  in JSONDecoder.decode',
    file: 'decoder.py',
    maxRecall: 2,
  })
  const txt2 = (r2 && r2.text) || ''
  console.log('\n[fix] 耗时', Date.now() - t1, 'ms | 长度', txt2.length)
  console.log('[fix] 含取回原文段:', txt2.indexOf('按 id 取回的原文') >= 0)
  console.log('[fix] 兜底分支:', txt2.indexOf('没有可取的 id') >= 0)

  const ok = names.length === 7
    && /### #/.test(txt1)
    && txt1.indexOf('可按下 id 取回原文') >= 0
    && txt2.indexOf('按 id 取回的原文') >= 0
  console.log('\n结论:', ok ? 'PASS' : 'FAIL')
  process.exit(ok ? 0 : 1)
}

main().catch(function (e) {
  console.error('ERROR', e && e.message)
  process.exit(1)
})
