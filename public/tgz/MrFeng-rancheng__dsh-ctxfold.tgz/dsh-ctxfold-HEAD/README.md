# dsh-ctxfold

把 [`ctxfold`](https://github.com/MrFeng-rancheng/dsh-ctxfold) 注册成 DeepSeek Harness 的**原生工具**——装好即自动生效，
不用指望模型自己想起来敲命令。

## 提供三个工具

> **0.4.0 起是 7 个工具**，其中三处改动直接来自实验结论，不是拍脑袋加的：
>
> - `ctxfold_ask` **默认先做一次失效检查（invalidate）**。理由：代码修改实验里 4 种无状态基线
>   共 8 次判定有 7 次沿用了改前的旧结论，而「改完代码还要记得手动失效」本身就是个坑。
>   现在改完直接 ask，顶部会给出「⚠ 改动检测：N 条失效、M 条下游受影响」。传 `autoInvalidate:false` 可跳过。
> - `ctxfold_ask` **结果末尾自动列出可 recall 的 id**。理由：跨 5 个模型的在线实验里取回率只有
>   0.011–0.167——模型几乎不会主动取回占位符里的原文，等于把证据扔了。现在 id 直接摊在眼前。
> - 新增 **`ctxfold_fix_context`**。理由：多步修复实验中「按报错里的符号名精确取回原文」是唯一跑通
>   的形态（通过率 69.7% 对全量历史 57.6%，token 少 48%）。现在把报错贴进去，它自己装配 + 取回 4 段原文。

| 工具 | 作用 | 只读 |
|---|---|---|
| `ctxfold_doctor` | 采用前体检：仓库规模、依赖密度、模拟节省、可读证据率损失、建议预算与是否 `--strict` | 是 |
| `ctxfold_ask` | 为某个问题装配一轮上下文（**不调用模型**）：返回将要发送的 prompt、`### #path::symbol \| file:start-end` 出处头、卡片/占位符、token 与免算状态；先失效、末尾附可 recall 的 id | 是 |
| `ctxfold_fix_context` | 给一段测试报错（+ 可选待改文件），装配上下文并按 id 取回报错里出现的符号原文，一条调用拿到可改的代码 | 是 |
| `ctxfold_status` | 记忆条数（fresh/stale）、账本事件计数、预算与 guard 级别 | 是 |
| `ctxfold_recall` | 按 id 取回某个证据块的逐字原文（含快照，文件改了也能取） | 是 |
| `ctxfold_invalidate` | 重新按内容哈希核对全部守卫，给出 invalidated / downstream / kept 三组 | 否 |
| `ctxfold_state` | 导出状态 S=(C,G,D,L)：结论、守卫哈希与新鲜度、1 跳依赖边、各 id 的表示层级 | 是 |

## 依赖

**不用单独装工具。** 插件自带 `vendor/ctxfold-tool.zip`，第一次调用任一工具时会自动解包到用户
site-packages（纯文件复制，不联网、不走 pip、不受中文路径影响）。想额外拿到 `ctxfold` 命令别名，
再 `pip install` 一次就行，可选：

```bash
python -m pip install "<本包路径>/03-插件-ctxfold工具"
ctxfold --help          # 确认可用
```

## 安装

装法（一句话）：

```bash
# 从 GitHub 装
dsh plugin add MrFeng-rancheng/dsh-ctxfold

# 或者装本地目录（投稿包内）
dsh plugin add "<本包路径>/dsh-ctxfold"
```

**Windows 也可以直接双击投稿包根目录的 `一键安装.cmd`**（macOS `一键安装.command`，Linux `./一键安装.sh`）。
它会自动找 DSH profile、装插件、装工具本体并自检。等价的命令行写法：

```bash
cd <本包路径>/04-插件-DSH集成
python install.py --with-tool "<本包路径>/03-插件-ctxfold工具"
```

它补齐 DSH 认插件需要的四处登记（`node_modules` 文件、`dependencies`、`dsh.profile.bundles`、`cordis.patch.yml` 的 insert 行），
改前自动备份，已存在的跳过。先看要改什么加 `--dry-run`；profile 不是 desktop 加 `--profile <名字>`。

装完**完全退出并重开 DSH**（刷新页面不算）。

### 找不到 ctxfold 命令时

插件按三级回退找工具：环境变量 `CTXFOLD_BIN` → PATH 里的 `ctxfold` → `python -m ctxfold.cli`。
都不行才报错，并在报错里列出尝试过的命令。可用环境变量指定：

| 变量 | 例子 | 用途 |
| --- | --- | --- |
| `CTXFOLD_BIN` | `C:/Python312/Scripts/ctxfold.exe` | 直接指向可执行文件 |
| `CTXFOLD_PYTHON` | `C:/Python312/python.exe` | 指向解释器，插件自动改用 `python -m ctxfold.cli` |

排障与常见问题见 [安装说明.md](安装说明.md)。

## 配置（cordis.patch.yml）

```yaml
- insert:
    - id: dsh-ctxfold
      name: dsh-ctxfold
      config:
        enabled: true
        corpus: ''        # 默认仓库根；留空则用会话工作目录
        budget: 1600      # 单轮证据 token 预算
        strict: false     # true = 可见性优先（成本约 +45%，严格可见率 +31pt）
        timeoutMs: 90000
```

## 说明

- 纯只读 + 本地子进程调用，**不联网、不读密钥**。
- 参数以数组传给 `execFile`，不做字符串拼接，避免命令注入。
- 若 `ctxfold` 未安装，工具会返回一条明确的安装提示，而不是报错崩溃。
- token 数为估算值（代码文本上偏高约 30%），当上界看；`省了多少百分比` 这类比值不受影响。
- 关闭插件：把 `config.enabled` 设为 `false`。
