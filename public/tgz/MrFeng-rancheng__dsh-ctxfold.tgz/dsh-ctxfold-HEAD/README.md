# dsh-ctxfold

![release](https://img.shields.io/github/v/release/MrFeng-rancheng/dsh-ctxfold)
![license](https://img.shields.io/badge/license-MIT-green)

解决 AI 重复阅读上下文的问题，节省 token，提高效率。

问过的代码记下来，下次不再重读；代码改了只重算改动的部分。


装完完全退出 DeepSeek Harness 再打开，不用装 Python，不用联网，不用密钥。

项目太小时省不出什么，装完可以先用看看值不值得用。
