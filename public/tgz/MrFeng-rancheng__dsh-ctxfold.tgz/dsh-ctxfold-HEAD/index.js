/**
 * dsh-memo —— 把 ctxfold 注册成 DSH 的原生工具（CommonJS）。
 *
 * 提供：ctxfold_doctor / ctxfold_ask / ctxfold_status
 * 依赖本机已安装的 `ctxfold` 命令（pip install ctxfold）。
 */
'use strict'

const { execFile } = require('node:child_process')
const fs = require('node:fs')
const os = require('node:os')
const path = require('node:path')

// 优先用 Harness 的 defineTool；拿不到时用恒等函数（注册表也接受普通对象）
let defineTool = function (spec) { return spec }
try {
  const mod = require('@deepseek-ai/dsh-tools')
  if (mod && typeof mod.defineTool === 'function') defineTool = mod.defineTool
} catch (_) { /* 可选依赖，缺了也能工作 */ }

const isWin = process.platform === 'win32'

function clip(text, max) {
  const s = String(text == null ? '' : text)
  const limit = max || 12000
  return s.length > limit ? s.slice(0, limit) + '\n…（已截断，共 ' + s.length + ' 字符）' : s
}

/**
 * 候选调用方式，按顺序尝试。同一份插件在三种环境下都能工作：
 *   1) 环境变量 CTXFOLD_BIN 指向可执行文件（venv / conda / 非标准 PATH）
 *   2) PATH 里的 ctxfold / ctxfold.exe（pip install 后通常如此）
 *   3) python -m ctxfold.cli（PATH 里没有脚本但有解释器时最稳）
 * 全部失败才报错，并在报错里列出尝试过的命令。
 */
function candidates() {
  const env = process.env
  const list = []
  if (env.CTXFOLD_BIN) list.push({ cmd: env.CTXFOLD_BIN, prefix: [] })
  list.push({ cmd: isWin ? 'ctxfold.exe' : 'ctxfold', prefix: [] })
  const pys = []
  if (env.CTXFOLD_PYTHON) pys.push(env.CTXFOLD_PYTHON)
  if (isWin) pys.push('python.exe', 'py')
  pys.push('python3', 'python')
  const seen = {}
  for (const py of pys) {
    if (seen[py]) continue
    seen[py] = true
    list.push({ cmd: py, prefix: ['-m', 'ctxfold.cli'] })
  }
  return list
}

/** 数组参数调用，绝不拼接命令行；missing=true 表示该候选不可用，继续试下一个 */
function runOnce(cand, argv, cwd, timeoutMs) {
  return new Promise(function (resolve) {
    execFile(cand.cmd, cand.prefix.concat(argv), {
      cwd: cwd,
      timeout: timeoutMs,
      maxBuffer: 8 * 1024 * 1024,
      windowsHide: true,
      env: Object.assign({}, process.env, { PYTHONIOENCODING: 'utf-8' }),
    }, function (error, stdout, stderr) {
      if (error && (error.code === 'ENOENT' || error.code === 'EACCES' || error.code === 9009)) {
        resolve({ missing: true })
        return
      }
      const out = [stdout, stderr].filter(Boolean).join('\n').trim()
      if (error) {
        resolve({ text: 'ctxfold 执行失败（' + (error.code || 'error') + '）：\n' + (clip(out) || error.message) })
        return
      }
      resolve({ text: clip(out) })
    })
  })
}

const PACKAGE_DIR = __dirname
let toolReady = null

/** 静默执行：返回 true/false，不抛错、不打印 */
function runQuiet(cmd, argv) {
  return new Promise(function (resolve) {
    execFile(cmd, argv, {
      cwd: PACKAGE_DIR,
      timeout: 120000,
      windowsHide: true,
      env: Object.assign({}, process.env, { PYTHONIOENCODING: "utf-8" }),
    }, function (error) { resolve(!error) })
  })
}

function pythonCandidates() {
  const list = []
  if (process.env.CTXFOLD_PYTHON) list.push(process.env.CTXFOLD_PYTHON)
  if (isWin) list.push("python.exe", "python", "py")
  else list.push("python3", "python")
  return list
}

/**
 * 确保工具本体可用：先看能不能 import，不能就用插件自带的 zip 解包到用户 site-packages。
 * 这样「装插件」就等于「装好工具」，不需要 pip、不需要网络、不受中文路径影响。
 */
async function ensureTool() {
  if (toolReady !== null) return toolReady
  const zip = path.join(PACKAGE_DIR, "vendor", "ctxfold-tool.zip")
  const script = path.join(PACKAGE_DIR, "vendor", "bootstrap.py")
  const pys = pythonCandidates()
  for (const py of pys) {
    if (await runQuiet(py, ["-c", "import ctxfold"])) {
      toolReady = true
      return true
    }
  }
  if (!fs.existsSync(zip) || !fs.existsSync(script)) {
    toolReady = false
    return false
  }
  for (const py of pys) {
    if (await runQuiet(py, [script, zip])) {
      const ok = await runQuiet(py, ["-c", "import ctxfold"])
      if (ok) {
        toolReady = true
        return true
      }
    }
  }
  toolReady = false
  return false
}
async function runCtxfold(argv, cwd, timeoutMs) {
  await ensureTool()
  const tried = []
  for (const cand of candidates()) {
    tried.push([cand.cmd].concat(cand.prefix).join(' '))
    const r = await runOnce(cand, argv, cwd, timeoutMs)
    if (!r.missing) return r.text
  }
  return [
    '找不到 ctxfold 命令，工具无法工作。已依次尝试：',
    '  ' + tried.join('\n  '),
    '',
    '三种修法（任选其一，装完重开 DSH）：',
    '  1) 安装工具本体：python -m pip install <本包路径>/03-插件-ctxfold工具',
    '     然后终端执行 ctxfold --help 确认可用。',
    '  2) 已有 venv/conda：设置 CTXFOLD_BIN 指向该环境里的 ctxfold（Windows 为 ctxfold.exe）。',
    '  3) 不想进 PATH：设置 CTXFOLD_PYTHON 指向解释器，插件会自动改用 python -m ctxfold.cli。',
  ].join('\n')
}

const TEXT_OUTPUT = {
  schema: {
    type: 'object',
    properties: { text: { type: 'string' } },
  },
  render: function (_args, value) {
    const text = value && typeof value.text === 'string' ? value.text : JSON.stringify(value)
    return [{ type: 'text', text: text }]
  },
}

const name = 'dsh-ctxfold'
const inject = ['tools']

function apply(ctx, config) {
  const cfg = config || {}
  if (cfg.enabled === false) return
  if (!ctx || !ctx.tools || typeof ctx.tools.register !== 'function') {
    console.warn('[dsh-memo] 当前上下文没有 tools 注册表，插件未生效')
    return
  }

  const defaultCorpus = cfg.corpus || ''
  const budget = Number(cfg.budget) || 1600
  const strict = cfg.strict === true
  const timeoutMs = Number(cfg.timeoutMs) || 90000

  try {
    fs.appendFileSync(
      path.join(os.tmpdir(), 'dsh-ctxfold-loaded.log'),
      new Date().toISOString() + ' apply() executed\n',
    )
  } catch (_) { /* 忽略 */ }

  const baseArgs = function (corpus) {
    const args = []
    if (corpus) args.push('--corpus', corpus)
    args.push('--state', '.ctxfold', '--budget', String(budget))
    if (strict) args.push('--strict')
    return args
  }

  ctx.tools.register(defineTool({
    name: 'ctxfold_doctor',
    description: 'Adoption check for ctxfold on a repository: reports scale, dependency density, '
      + 'simulated token saving, strict-visibility loss, and a suggested budget / whether to use --strict. '
      + 'Read-only; call before ctxfold_ask on an unfamiliar repo.',
    parameters: {
      corpus: { type: 'string', description: 'Repository root path. Defaults to the current working directory.' },
    },
    output: TEXT_OUTPUT,
    isConcurrencySafe: function () { return true },
    isReadOnly: function () { return true },
    execute: async function (args) {
      const corpus = String((args && args.corpus) || defaultCorpus || process.cwd()).trim()
      return { text: await runCtxfold(baseArgs(corpus).concat(['doctor']), corpus, timeoutMs) }
    },
  }))

  ctx.tools.register(defineTool({
    name: 'ctxfold_ask',
    description: 'Assemble context for ONE query against a repository using ctxfold, WITHOUT calling any model. '
      + 'Returns the prompt that would be sent: verbatim evidence blocks tagged '
      + '`### #path::symbol | file:start-end`, summary cards, recallable placeholders, plus token count / '
      + 'whether it was free (免算) / stale entries. Use when a coding task spans many turns and full history '
      + 'is expensive, or when you need traceable file:line evidence. Token counts are estimates (~30% high).',
    parameters: {
      query: { type: 'string', required: true, description: 'The question to assemble evidence for.' },
      corpus: { type: 'string', description: 'Repository root path. Defaults to the current working directory.' },
    },
    output: TEXT_OUTPUT,
    isConcurrencySafe: function () { return true },
    isReadOnly: function () { return true },
    execute: async function (args) {
      const query = String((args && args.query) || '').trim()
      if (!query) return { text: 'query 不能为空' }
      const corpus = String((args && args.corpus) || defaultCorpus || process.cwd()).trim()
      return { text: await runCtxfold(baseArgs(corpus).concat(['ask', query]), corpus, timeoutMs) }
    },
  }))

  ctx.tools.register(defineTool({
    name: 'ctxfold_status',
    description: 'Show ctxfold state for a repository: chunks/symbols, memory entries (fresh/stale), '
      + 'ledger event counts, budget and guard level. Read-only.',
    parameters: {
      corpus: { type: 'string', description: 'Repository root path. Defaults to the current working directory.' },
    },
    output: TEXT_OUTPUT,
    isConcurrencySafe: function () { return true },
    isReadOnly: function () { return true },
    execute: async function (args) {
      const corpus = String((args && args.corpus) || defaultCorpus || process.cwd()).trim()
      return { text: await runCtxfold(baseArgs(corpus).concat(['status']), corpus, timeoutMs) }
    },
  }))
}

module.exports = { name: name, inject: inject, apply: apply, _candidates: candidates, _ensureTool: ensureTool }
