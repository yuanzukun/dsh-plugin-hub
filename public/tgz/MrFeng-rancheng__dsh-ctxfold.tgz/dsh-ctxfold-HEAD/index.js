/**
 * dsh-memo —— 把 ctxfold 注册成 DSH 的原生工具（CommonJS）。
 *
 * 提供：ctxfold_doctor / ctxfold_ask / ctxfold_status
 * 依赖本机已安装的 `ctxfold` 命令（pip install ctxfold）。
 */
'use strict'

const { execFile } = require('node:child_process')
const fs = require('node:fs')
const os = require('node:os')
const path = require('node:path')

// 优先用 Harness 的 defineTool；拿不到时用恒等函数（注册表也接受普通对象）
let defineTool = function (spec) { return spec }
try {
  const mod = require('@deepseek-ai/dsh-tools')
  if (mod && typeof mod.defineTool === 'function') defineTool = mod.defineTool
} catch (_) { /* 可选依赖，缺了也能工作 */ }

const isWin = process.platform === 'win32'

function clip(text, max) {
  const s = String(text == null ? '' : text)
  const limit = max || 12000
  return s.length > limit ? s.slice(0, limit) + '\n…（已截断，共 ' + s.length + ' 字符）' : s
}

/**
 * 候选调用方式，按顺序尝试。同一份插件在三种环境下都能工作：
 *   1) 环境变量 CTXFOLD_BIN 指向可执行文件（venv / conda / 非标准 PATH）
 *   2) PATH 里的 ctxfold / ctxfold.exe（pip install 后通常如此）
 *   3) python -m ctxfold.cli（PATH 里没有脚本但有解释器时最稳）
 * 全部失败才报错，并在报错里列出尝试过的命令。
 */
function candidates() {
  const env = process.env
  const list = []
  if (env.CTXFOLD_BIN) list.push({ cmd: env.CTXFOLD_BIN, prefix: [] })
  list.push({ cmd: isWin ? 'ctxfold.exe' : 'ctxfold', prefix: [] })
  const pys = []
  if (env.CTXFOLD_PYTHON) pys.push(env.CTXFOLD_PYTHON)
  if (isWin) pys.push('python.exe', 'py')
  pys.push('python3', 'python')
  const seen = {}
  for (const py of pys) {
    if (seen[py]) continue
    seen[py] = true
    list.push({ cmd: py, prefix: ['-m', 'ctxfold.cli'] })
  }
  return list
}

/** 数组参数调用，绝不拼接命令行；missing=true 表示该候选不可用，继续试下一个 */
function runOnce(cand, argv, cwd, timeoutMs) {
  return new Promise(function (resolve) {
    execFile(cand.cmd, cand.prefix.concat(argv), {
      cwd: cwd,
      timeout: timeoutMs,
      maxBuffer: 8 * 1024 * 1024,
      windowsHide: true,
      env: Object.assign({}, process.env, {
        PYTHONIOENCODING: 'utf-8',
        // 实验结论：依赖信息不该被折叠，依赖类查询要把被调用项升为卡片，
        // 中英混排要按标识符对齐——默认打开，避免用户没设就悄悄退化。
        CTXFOLD_DEPS_BOOST: process.env.CTXFOLD_DEPS_BOOST || '1',
        CTXFOLD_IDENT_FIX: process.env.CTXFOLD_IDENT_FIX || '1',
      }),
    }, function (error, stdout, stderr) {
      if (error && (error.code === 'ENOENT' || error.code === 'EACCES' || error.code === 9009)) {
        resolve({ missing: true })
        return
      }
      const out = [stdout, stderr].filter(Boolean).join('\n').trim()
      if (error) {
        resolve({ text: 'ctxfold 执行失败（' + (error.code || 'error') + '）：\n' + (clip(out) || error.message) })
        return
      }
      resolve({ text: clip(out) })
    })
  })
}

const PACKAGE_DIR = __dirname
let toolReady = null

/** 静默执行：返回 true/false，不抛错、不打印 */
function runQuiet(cmd, argv) {
  return new Promise(function (resolve) {
    execFile(cmd, argv, {
      cwd: PACKAGE_DIR,
      timeout: 120000,
      windowsHide: true,
      env: Object.assign({}, process.env, { PYTHONIOENCODING: "utf-8" }),
    }, function (error) { resolve(!error) })
  })
}

function pythonCandidates() {
  const list = []
  if (process.env.CTXFOLD_PYTHON) list.push(process.env.CTXFOLD_PYTHON)
  if (isWin) list.push("python.exe", "python", "py")
  else list.push("python3", "python")
  return list
}

/**
 * 确保工具本体可用：先看能不能 import，不能就用插件自带的 zip 解包到用户 site-packages。
 * 这样「装插件」就等于「装好工具」，不需要 pip、不需要网络、不受中文路径影响。
 */
async function ensureTool() {
  if (toolReady !== null) return toolReady
  const zip = path.join(PACKAGE_DIR, "vendor", "ctxfold-tool.zip")
  const script = path.join(PACKAGE_DIR, "vendor", "bootstrap.py")
  const pys = pythonCandidates()
  for (const py of pys) {
    if (await runQuiet(py, ["-c", "import ctxfold"])) {
      toolReady = true
      return true
    }
  }
  if (!fs.existsSync(zip) || !fs.existsSync(script)) {
    toolReady = false
    return false
  }
  for (const py of pys) {
    if (await runQuiet(py, [script, zip])) {
      const ok = await runQuiet(py, ["-c", "import ctxfold"])
      if (ok) {
        toolReady = true
        return true
      }
    }
  }
  toolReady = false
  return false
}
async function runCtxfold(argv, cwd, timeoutMs) {
  await ensureTool()
  const tried = []
  for (const cand of candidates()) {
    tried.push([cand.cmd].concat(cand.prefix).join(' '))
    const r = await runOnce(cand, argv, cwd, timeoutMs)
    if (!r.missing) return r.text
  }
  return [
    '找不到 ctxfold 命令，工具无法工作。已依次尝试：',
    '  ' + tried.join('\n  '),
    '',
    '三种修法（任选其一，装完重开 DSH）：',
    '  1) 安装工具本体：python -m pip install <本包路径>/03-插件-ctxfold工具',
    '     然后终端执行 ctxfold --help 确认可用。',
    '  2) 已有 venv/conda：设置 CTXFOLD_BIN 指向该环境里的 ctxfold（Windows 为 ctxfold.exe）。',
    '  3) 不想进 PATH：设置 CTXFOLD_PYTHON 指向解释器，插件会自动改用 python -m ctxfold.cli。',
  ].join('\n')
}

const TEXT_OUTPUT = {
  schema: {
    type: 'object',
    properties: { text: { type: 'string' } },
  },
  render: function (_args, value) {
    const text = value && typeof value.text === 'string' ? value.text : JSON.stringify(value)
    return [{ type: 'text', text: text }]
  },
}

const name = 'dsh-ctxfold'
const inject = ['tools']

function apply(ctx, config) {
  const cfg = config || {}
  if (cfg.enabled === false) return
  if (!ctx || !ctx.tools || typeof ctx.tools.register !== 'function') {
    console.warn('[dsh-memo] 当前上下文没有 tools 注册表，插件未生效')
    return
  }

  const defaultCorpus = cfg.corpus || ''
  // state 目录默认放在语料根下的 .ctxfold；只读语料（如系统目录）可用 cfg.state 指到可写位置。
  const stateDir = String(cfg.state || '.ctxfold')
  const budget = Number(cfg.budget) || 1600
  const strict = cfg.strict === true
  const timeoutMs = Number(cfg.timeoutMs) || 90000

  try {
    fs.appendFileSync(
      path.join(os.tmpdir(), 'dsh-ctxfold-loaded.log'),
      new Date().toISOString() + ' apply() executed\n',
    )
  } catch (_) { /* 忽略 */ }

  const baseArgs = function (corpus) {
    const args = []
    if (corpus) args.push('--corpus', corpus)
    args.push('--state', stateDir, '--budget', String(budget))
    if (strict) args.push('--strict')
    return args
  }

  // ---- 以下三个小工具来自实验结果，不是拍脑袋加的 ----
  // 1) 取回率实验（5 个模型 0.011–0.167）：模型几乎不会自己 recall，
  //    所以装配结果里必须把"可以取回的 id"显式列出来，否则占位符等于丢证据。
  // 2) 陈旧误用实验（基线 8 次判定 7 次沿用旧结论）：改动后要先失效再装配，
  //    所以 ask 默认先跑一次 invalidate，把失效结果摆在最前面。
  // 3) 多步修复实验（按报错里的符号名精确 recall 才修得动）：
  //    于是有 ctxfold_fix_context，一条调用就能拿到"该改的那几段原文"。
  const ID_RE = /#([A-Za-z0-9_.\\/-]+::[^\s|,，]+)/g

  function extractIds(text, limit) {
    const out = []
    const seen = {}
    let m
    ID_RE.lastIndex = 0
    while ((m = ID_RE.exec(String(text || ''))) !== null) {
      const id = m[1].trim()
      if (!id || seen[id]) continue
      seen[id] = true
      out.push(id)
      if (out.length >= (limit || 8)) break
    }
    return out
  }

  /** 从 invalidate 输出里读出失效规模；读不出来就返回空串，不编数 */
  function invalidationNote(text) {
    const s = String(text || '')
    const m = s.match(/\{[\s\S]*\}/)
    if (m) {
      try {
        const d = JSON.parse(m[0])
        const inv = (d.invalidated || []).length
        const down = (d.downstream || []).length
        if (inv || down) {
          return '⚠ 改动检测：' + inv + ' 条结论失效、' + down + ' 条下游受影响（已失效，装配按新内容进行）'
        }
        return ''
      } catch (_) { /* 落到下面 */ }
    }
    return ''
  }

  ctx.tools.register(defineTool({
    name: 'ctxfold_doctor',
    description: 'Adoption check for ctxfold on a repository: reports scale, dependency density, '
      + 'simulated token saving, strict-visibility loss, and a suggested budget / whether to use --strict. '
      + 'Read-only; call before ctxfold_ask on an unfamiliar repo.',
    parameters: {
      corpus: { type: 'string', description: 'Repository root path. Defaults to the current working directory.' },
    },
    output: TEXT_OUTPUT,
    isConcurrencySafe: function () { return true },
    isReadOnly: function () { return true },
    execute: async function (args) {
      const corpus = String((args && args.corpus) || defaultCorpus || process.cwd()).trim()
      return { text: await runCtxfold(baseArgs(corpus).concat(['doctor']), corpus, timeoutMs) }
    },
  }))

  ctx.tools.register(defineTool({
    name: 'ctxfold_ask',
    description: 'Assemble context for ONE query against a repository using ctxfold, WITHOUT calling any model. '
      + 'Returns the prompt that would be sent: verbatim evidence blocks tagged '
      + '`### #path::symbol | file:start-end`, summary cards, recallable placeholders, plus token count / '
      + 'whether it was free (免算) / stale entries. Use when a coding task spans many turns and full history '
      + 'is expensive, or when you need traceable file:line evidence. Token counts are estimates (~30% high). '
      + 'IMPORTANT: text that only appears as a placeholder id is NOT in the prompt — before answering from it, '
      + 'call ctxfold_recall for that id instead of guessing. The output ends with a suggested recall list. '
      + 'By default this first re-checks guards (invalidation), so an edited file never gets assembled from a '
      + 'superseded conclusion; set autoInvalidate=false to skip that check.',
    parameters: {
      query: { type: 'string', required: true, description: 'The question to assemble evidence for.' },
      corpus: { type: 'string', description: 'Repository root path. Defaults to the current working directory.' },
      autoInvalidate: {
        type: 'boolean',
        description: 'Check guards (invalidate) before assembling. Defaults to true; keep it on after editing code.',
      },
    },
    output: TEXT_OUTPUT,
    isConcurrencySafe: function () { return true },
    isReadOnly: function () { return true },
    execute: async function (args) {
      const query = String((args && args.query) || '').trim()
      if (!query) return { text: 'query 不能为空' }
      const corpus = String((args && args.corpus) || defaultCorpus || process.cwd()).trim()
      const autoInv = !(args && args.autoInvalidate === false)
      const head = []
      if (autoInv) {
        const inv = await runCtxfold(baseArgs(corpus).concat(['invalidate']), corpus, timeoutMs)
        const note = invalidationNote(inv)
        if (note) head.push(note)
      }
      const body = await runCtxfold(baseArgs(corpus).concat(['ask', query]), corpus, timeoutMs)
      const ids = extractIds(body, 8)
      const tail = ids.length
        ? '\n\n[可按下 id 取回原文：需要其中任何一段就调 ctxfold_recall，不要凭占位符臆测]\n'
          + ids.map(function (x) { return '  - ' + x }).join('\n')
        : ''
      return { text: head.concat([body + tail]).join('\n\n') }
    },
  }))

  ctx.tools.register(defineTool({
    name: 'ctxfold_status',
    description: 'Show ctxfold state for a repository: chunks/symbols, memory entries (fresh/stale), '
      + 'ledger event counts, budget and guard level. Read-only.',
    parameters: {
      corpus: { type: 'string', description: 'Repository root path. Defaults to the current working directory.' },
    },
    output: TEXT_OUTPUT,
    isConcurrencySafe: function () { return true },
    isReadOnly: function () { return true },
    execute: async function (args) {
      const corpus = String((args && args.corpus) || defaultCorpus || process.cwd()).trim()
      return { text: await runCtxfold(baseArgs(corpus).concat(['status']), corpus, timeoutMs) }
    },
  }))

  ctx.tools.register(defineTool({
    name: 'ctxfold_recall',
    description: 'Fetch the original source text of ONE evidence block by its id, as it was when it was '
      + 'solidified. Works for placeholders (which are not in the prompt) and stays stable even after the '
      + 'file changed: the snapshot is returned, with unchanged=false telling you the file has moved on. '
      + 'Ids look like `path/file.py::symbol` and appear in ctxfold_ask output as `### #<id> | file:start-end`.',
    parameters: {
      cid: { type: 'string', required: true, description: 'Evidence id, e.g. base.py::add' },
      corpus: { type: 'string', description: 'Repository root path. Defaults to the current working directory.' },
    },
    output: TEXT_OUTPUT,
    isConcurrencySafe: function () { return true },
    isReadOnly: function () { return true },
    execute: async function (args) {
      const cid = String((args && args.cid) || '').trim()
      if (!cid) return { text: 'cid 不能为空' }
      const corpus = String((args && args.corpus) || defaultCorpus || process.cwd()).trim()
      return { text: await runCtxfold(baseArgs(corpus).concat(['recall', cid]), corpus, timeoutMs) }
    },
  }))

  ctx.tools.register(defineTool({
    name: 'ctxfold_invalidate',
    description: 'Re-read the repository from disk, re-check every guard by content hash, and report three '
      + 'groups: `invalidated` (symbols that changed), `downstream` (memory entries that depend on them, '
      + '1 hop) and `kept` (entries still reusable). Call this right after you edit code, before asking again.',
    parameters: {
      corpus: { type: 'string', description: 'Repository root path. Defaults to the current working directory.' },
    },
    output: TEXT_OUTPUT,
    isConcurrencySafe: function () { return true },
    isReadOnly: function () { return false },
    execute: async function (args) {
      const corpus = String((args && args.corpus) || defaultCorpus || process.cwd()).trim()
      return { text: await runCtxfold(baseArgs(corpus).concat(['invalidate']), corpus, timeoutMs) }
    },
  }))

  ctx.tools.register(defineTool({
    name: 'ctxfold_state',
    description: 'Dump the explicit state tuple S=(C,G,D,L): conclusions with claims, guard hashes and '
      + 'fresh/stale status, 1-hop dependency edges, and the representation level each id landed on in the '
      + 'latest assembly (raw / card / claim / placeholder). Read-only.',
    parameters: {
      corpus: { type: 'string', description: 'Repository root path. Defaults to the current working directory.' },
    },
    output: TEXT_OUTPUT,
    isConcurrencySafe: function () { return true },
    isReadOnly: function () { return true },
    execute: async function (args) {
      const corpus = String((args && args.corpus) || defaultCorpus || process.cwd()).trim()
      return { text: await runCtxfold(baseArgs(corpus).concat(['state']), corpus, timeoutMs) }
    },
  }))

  ctx.tools.register(defineTool({
    name: 'ctxfold_fix_context',
    description: 'Context for ONE failing test: given the failure output (and optionally the file you want to '
      + 'fix), assemble a prompt from the failure text, then fetch by id the code blocks whose symbol names '
      + 'appear in that output, plus the module header of that file. This is the shape that worked in the '
      + 'multi-step repair experiment: precise recall of the symbols named in the error, not the whole file. '
      + 'Read-only; call it instead of ask + several manual recalls when you have a stack trace or assertion error.',
    parameters: {
      fail_output: { type: 'string', required: true, description: 'Test/pytest/traceback output or the assertion message.' },
      file: { type: 'string', description: 'Optional source file you intend to edit; its blocks get priority.' },
      corpus: { type: 'string', description: 'Repository root path. Defaults to the current working directory.' },
      maxRecall: { type: 'number', description: 'How many blocks to fetch verbatim. Defaults to 4.' },
    },
    output: TEXT_OUTPUT,
    isConcurrencySafe: function () { return true },
    isReadOnly: function () { return true },
    execute: async function (args) {
      const fail = String((args && args.fail_output) || '').trim()
      if (!fail) return { text: 'fail_output 不能为空（把测试报错原文贴进来）' }
      const file = String((args && args.file) || '').trim()
      const corpus = String((args && args.corpus) || defaultCorpus || process.cwd()).trim()
      const limit = Math.max(1, Math.min(8, Number((args && args.maxRecall)) || 4))

      const inv = await runCtxfold(baseArgs(corpus).concat(['invalidate']), corpus, timeoutMs)
      const note = invalidationNote(inv)
      const head = note ? note + '\n\n' : ''

      const body = await runCtxfold(
        baseArgs(corpus).concat(['ask', '修 bug：' + fail.slice(0, 300)]), corpus, timeoutMs)
      let ids = extractIds(body, 12)
      if (file) {
        const base = file.split(/[\\/]/).pop()
        const hit = ids.filter(function (x) { return x.indexOf(base) >= 0 })
        if (hit.length) {
          ids = hit.concat(ids.filter(function (x) { return hit.indexOf(x) < 0 }))
        }
      }
      ids = ids.slice(0, limit)
      const blocks = []
      for (const id of ids) {
        const r = await runCtxfold(baseArgs(corpus).concat(['recall', id]), corpus, timeoutMs)
        blocks.push(r)
      }
      const tail = blocks.length
        ? '\n\n[按 id 取回的原文（' + blocks.length + ' 段）]\n' + blocks.join('\n\n')
        : '\n\n（装配结果里没有可取的 id：这段报错没有落在符号上，改用 ctxfold_ask 换个问法）'
      return { text: head + body + tail }
    },
  }))
}

module.exports = { name: name, inject: inject, apply: apply, _candidates: candidates, _ensureTool: ensureTool }
