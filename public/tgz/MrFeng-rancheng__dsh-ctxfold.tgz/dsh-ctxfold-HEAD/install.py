"""install.py —— 一键把 dsh-ctxfold 装进 DSH（跨平台，只用标准库）。

设计目标：**零参数**。双击 一键安装.cmd 或直接 `python install.py` 就应该装好。
所有路径都相对本文件所在位置自动推断，整个投稿包可随便挪、随便拷。

做五件事（已完成自动跳过）：
  1. 找到 DSH profile（~/.dsh/profiles/desktop，找不到就取唯一一个）
  2. 复制插件到 <profile>/node_modules/dsh-ctxfold/
  3. 在 <profile>/package.json 登记 dependencies 并加入 dsh.profile.bundles
  4. 在 <profile>/cordis.patch.yml 追加 insert 行
  5. pip 安装工具本体（自动找包内 03 目录或 dist/*.zip），并验证 ctxfold 真能跑

改文件前自动备份。想先看要改什么：python install.py --dry-run
"""
from __future__ import annotations

import argparse
import datetime as _dt
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
PLUGIN_NAME = "dsh-ctxfold"
SKIP = {"_smoke.js", "_boot_smoke.js", "*.tgz", "node_modules", "__pycache__", ".git", "install_v1.py.bak"}

INSERT_BLOCK = """  - insert:
      - id: dsh-ctxfold
        name: dsh-ctxfold
        config:
          enabled: true
          corpus: ''
          budget: 1600
          strict: false
          timeoutMs: 90000
"""


def log(msg: str = "") -> None:
    print(msg, flush=True)


def plugin_dir() -> Path:
    """插件文件在哪：可能在 <这里>/dsh-ctxfold，也可能这里本身就是插件目录。"""
    for cand in (HERE / PLUGIN_NAME, HERE):
        if (cand / "index.js").is_file():
            return cand
    sys.exit("[FAIL] 找不到插件文件 index.js —— 请把整个「04-插件-DSH集成」目录一起拷过来。")


def find_tool():
    """工具本体在哪：包内 03 目录或它的 dist/*.zip；都没有返回 None。"""
    for root in (HERE, HERE.parent, HERE.parent.parent):
        if not root.is_dir():
            continue
        for name in ("03-插件-ctxfold工具", "ctxfold"):
            d = root / name
            if (d / "pyproject.toml").is_file():
                return d
        dist = root / "03-插件-ctxfold工具" / "dist"
        if dist.is_dir():
            zips = sorted(dist.glob("ctxfold-*.zip"))
            if zips:
                return zips[-1]
    return None


def find_profile(name, explicit):
    if explicit:
        p = Path(explicit).expanduser()
        return p if p.is_dir() else None
    dsh_home = Path(os.environ.get("DSH_HOME") or (Path.home() / ".dsh"))
    root = dsh_home / "profiles" / name
    if root.is_dir():
        return root
    base = root.parent
    if base.is_dir():
        cands = [d for d in base.iterdir() if (d / "package.json").is_file()]
        if len(cands) == 1:
            log("  · 没找到 profiles/%s，改用唯一的 profile：%s" % (name, cands[0].name))
            return cands[0]
        if cands:
            log("  ! 多个 profile，默认用 %s（可用 --profile 指定）" % cands[0].name)
            return cands[0]
    return None


def backup(path):
    if not path.exists():
        return
    stamp = _dt.datetime.now().strftime("%Y%m%d-%H%M%S")
    dst = path.with_name(path.name + ".bak-ctxfold-" + stamp)
    shutil.copy2(path, dst)
    log("    · 已备份 %s → %s" % (path.name, dst.name))


def copy_plugin(src, profile, dry):
    dst = profile / "node_modules" / PLUGIN_NAME
    if dry:
        log("    [dry] 复制 %s → %s" % (src, dst))
        return
    if dst.exists():
        shutil.rmtree(dst)
    dst.mkdir(parents=True, exist_ok=True)
    for item in src.iterdir():
        if item.name in SKIP:
            continue
        if item.is_dir():
            shutil.copytree(item, dst / item.name, ignore=shutil.ignore_patterns(*SKIP))
        else:
            shutil.copy2(item, dst / item.name)
    log("    · 插件文件已就位：%s" % dst)


def patch_package_json(profile, dry):
    pkg = profile / "package.json"
    data = json.loads(pkg.read_text(encoding="utf-8"))
    changed = []
    deps = data.setdefault("dependencies", {})
    want = "file:./node_modules/" + PLUGIN_NAME
    if deps.get(PLUGIN_NAME) != want:
        deps[PLUGIN_NAME] = want
        changed.append("dependencies")
    bundles = data.setdefault("dsh", {}).setdefault("profile", {}).setdefault("bundles", [])
    if PLUGIN_NAME not in bundles:
        bundles.append(PLUGIN_NAME)
        changed.append("dsh.profile.bundles")
    if not changed:
        log("    · package.json 已登记，跳过")
        return
    if dry:
        log("    [dry] 改 package.json：%s" % changed)
        return
    backup(pkg)
    pkg.write_text(json.dumps(data, ensure_ascii=False, indent=2) + chr(10), encoding="utf-8")
    log("    · package.json 已更新：%s" % changed)


def patch_cordis(profile, dry):
    yml = profile / "cordis.patch.yml"
    text = yml.read_text(encoding="utf-8") if yml.exists() else ""
    if "id: dsh-ctxfold" in text:
        log("    · cordis.patch.yml 已有装载行，跳过")
        return
    if dry:
        log("    [dry] 追加 cordis.patch.yml 的 insert 行")
        return
    backup(yml)
    if text and not text.endswith(chr(10)):
        text += chr(10)
    yml.write_text(text + INSERT_BLOCK, encoding="utf-8")
    log("    · cordis.patch.yml 已追加装载行")


def user_site():
    r = subprocess.run([sys.executable, "-c", "import site;print(site.getusersitepackages())"],
                       capture_output=True, text=True)
    return Path(r.stdout.strip()) if r.returncode == 0 and r.stdout.strip() else None


def copy_into_site(tool):
    """离线兜底：把 src/ctxfold 直接放进用户 site-packages。

    插件的第三级回退是 `python -m ctxfold.cli`，只要能 import 到就够用，
    不需要 console script，因此这条路在没网、没 setuptools 的机器上也能成。
    """
    src = tool / "src" / "ctxfold"
    if not (src / "cli.py").is_file():
        return False
    site = user_site()
    if site is None:
        return False
    dst = site / "ctxfold"
    try:
        if dst.exists():
            shutil.rmtree(dst)
        shutil.copytree(src, dst, ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))
    except OSError as exc:
        log("    ! 复制到 site-packages 失败：%s" % exc)
        return False
    log("    · 已直接放入用户 site-packages：%s" % dst)
    return True


def staged_copy(tool):
    """把工具拷到 %TEMP% 下的纯 ASCII 路径再装。

    踩过的坑：包路径含中文（03-插件-ctxfold工具）时，pip 在 Windows 上把参数当
    file link 解析会失败，抛出 _make_base_candidate_from_link 的 Exception——
    看起来像 pip 坏了，其实是路径编码。拷到 ASCII 路径即可绕开。
    """
    import tempfile
    stage = Path(tempfile.gettempdir()) / "ctxfold-install"
    if stage.exists():
        shutil.rmtree(stage, ignore_errors=True)
    if tool.is_dir():
        shutil.copytree(tool, stage, ignore=shutil.ignore_patterns(
            "__pycache__", "*.pyc", "build", "*.egg-info", "experiments", "docs", "tests"))
        return stage
    stage.mkdir(parents=True, exist_ok=True)
    dst = stage / tool.name
    shutil.copy2(tool, dst)
    return dst


def install_tool(tool, dry, allow_pip=True):
    """装工具本体。顺序很重要：

    1) 先把 src/ctxfold 直接放进用户 site-packages —— 纯文件复制，不需要网络、
       不需要 setuptools、不受中文路径影响，插件走 `python -m ctxfold.cli` 即可工作。
    2) 再尝试 pip（只为额外得到 ctxfold 命令）。失败只是少个命令别名，不影响功能，
       所以不再打印 traceback，只提示一句。

    踩过的坑：Python 3.12+ 常不带 setuptools，pip 会抛
    BackendUnavailable: Cannot import 'setuptools.build_meta'。
    """
    if dry:
        log("    [dry] 复制 src/ctxfold 到用户 site-packages，再尝试 pip 安装命令别名")
        return
    copied = copy_into_site(tool)
    if not copied:
        log("    ! 复制到 site-packages 失败，改为尝试 pip")
    if not allow_pip:
        return
    try:
        target = staged_copy(tool)
    except OSError as exc:
        log("    · 跳过 pip（准备临时目录失败：%s）" % exc)
        return
    cmd = [sys.executable, "-m", "pip", "install", "--quiet",
           "--disable-pip-version-check", "--no-input", "--retries", "0", "--timeout", "15",
           str(target)]
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=180)
    except subprocess.TimeoutExpired:
        log("    · pip 超时，已跳过（不影响使用）")
        return
    if r.returncode == 0:
        shutil.rmtree(target, ignore_errors=True)
        log("    · 已同时安装 ctxfold 命令（可选）")
        return
    err = (r.stderr or "").strip().splitlines()
    hint = ""
    for line in reversed(err):
        if "BackendUnavailable" in line or "Cannot import" in line:
            hint = "（本机缺 setuptools，属正常）"
            break
    log("    · pip 未成功，已跳过命令别名%s；不影响使用" % hint)
    shutil.rmtree(target, ignore_errors=True)


def verify():
    """用与插件相同的三级回退找 ctxfold，确认它真能跑。"""
    cands = []
    if os.environ.get("CTXFOLD_BIN"):
        cands.append([os.environ["CTXFOLD_BIN"]])
    cands.append(["ctxfold.exe" if os.name == "nt" else "ctxfold"])
    pys = [sys.executable] + (["py", "python3", "python"] if os.name == "nt" else ["python3", "python"])
    for py in pys:
        cands.append([py, "-m", "ctxfold.cli"])
    for cmd in cands:
        try:
            r = subprocess.run(cmd + ["--help"], capture_output=True, timeout=90)
        except (OSError, subprocess.TimeoutExpired):
            continue
        if r.returncode == 0:
            log("    · 验证通过：%s" % " ".join(cmd))
            return True
    return False


def main():
    ap = argparse.ArgumentParser(description="一键安装 dsh-ctxfold")
    ap.add_argument("--profile", default="desktop")
    ap.add_argument("--profile-dir", default=None)
    ap.add_argument("--no-tool", action="store_true", help="只装插件，不安装工具本体")
    ap.add_argument("--no-pip", action="store_true",
                    help="只把工具放进 site-packages，不尝试 pip（离线/无 setuptools 机器用）")
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()

    log("=" * 56)
    log("  ctxfold 插件安装器")
    log("=" * 56)

    profile = find_profile(args.profile, args.profile_dir)
    if profile is None:
        log("[FAIL] 没找到 DSH 的 profile 目录（应在 ~/.dsh/profiles/ 下）。")
        log("  请先安装并启动一次 DeepSeek Harness，再运行本安装器。")
        log('  若 profile 在别处：python install.py --profile-dir "<绝对路径>"')
        return 2
    log("目标 profile：%s" % profile)

    src = plugin_dir()
    log("插件源目录：%s" % src)
    tool = None if args.no_tool else find_tool()
    log("工具本体：%s" % (tool if tool else "未找到（跳过 pip 安装）"))
    log("")

    log("[1/4] 复制插件文件")
    copy_plugin(src, profile, args.dry_run)
    log("[2/4] 登记依赖与启用")
    patch_package_json(profile, args.dry_run)
    log("[3/4] 追加装载行")
    patch_cordis(profile, args.dry_run)
    log("[4/4] 安装并验证工具本体")
    if tool:
        install_tool(tool, args.dry_run, allow_pip=not args.no_pip)
    ok = True if args.dry_run else verify()
    if not args.dry_run and not ok:
        log("    ! 没找到可用的 ctxfold 命令；按上面的提示手动装一次即可。")

    log("")
    log("=" * 56)
    if args.dry_run:
        log("  预演结束，未改动任何文件。去掉 --dry-run 才真的安装。")
    else:
        log("  安装完成。请【完全退出并重开 DSH】（刷新页面不算）。")
        log("  重开后让模型调用 ctxfold_doctor 即可验证。")
        log("")
        log("  若看不到工具，依次检查：")
        log("   1) 日志 %TEMP%/dsh-ctxfold-loaded.log 有无 apply() executed")
        log("   2) 终端执行 ctxfold --help 能否跑")
        log("   3) 详细排障见 安装说明.md")
    log("=" * 56)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
