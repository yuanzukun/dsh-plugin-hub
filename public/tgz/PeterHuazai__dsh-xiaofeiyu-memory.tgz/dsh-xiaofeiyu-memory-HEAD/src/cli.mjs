#!/usr/bin/env node
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { openStore, backup, rebuildFromShadow, integrity, listBackups, DEFAULT_CONFIG, deepMerge } from './db.mjs';
import * as engine from './engine.mjs';
import * as tasks from './tasks.mjs';
import { checkGuard, audit, listGuardEvents, deleteGuardEvents, restoreGuardEvents, purgeGuardEvents, planFix, applyFix } from './guard.mjs';
import * as vision from './vision.mjs';
import * as vector from './vector.mjs';
import * as tools from './tools.mjs';
import * as harness from './harness.mjs';

const argv = process.argv.slice(2);

function parse(argv) {
  const flags = {};
  const rest = [];
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a.startsWith('--')) {
      const key = a.slice(2);
      const next = argv[i + 1];
      if (next !== undefined && !next.startsWith('--')) { flags[key] = next; i += 1; }
      else flags[key] = true;
    } else rest.push(a);
  }
  return { flags: flags, rest: rest };
}

const { flags, rest } = parse(argv);
const asJson = !!flags.json;
const store = openStore({ root: process.env.MEMORY_ROOT || undefined });

function out(value, text) {
  if (asJson) { console.log(JSON.stringify(value, null, 2)); return; }
  console.log(text === undefined ? (typeof value === 'string' ? value : JSON.stringify(value, null, 2)) : text);
}

function need(name) {
  if (flags[name] === undefined) { console.error('missing --' + name); process.exit(2); }
  return flags[name];
}

// 允许 `mem get m-xxx` / `mem delete m-xxx` 两种位置写法：cmd [sub] <id>
function argId() {
  if (flags.id !== undefined) return String(flags.id);
  const pos = rest.filter(function (x) { return typeof x === 'string'; });
  const at = pos.length > 1 ? pos[pos.length - 1] : (pos.length === 1 && pos[0] === cmd ? undefined : pos[0]);
  if (at !== undefined) return String(at);
  console.error('missing --id');
  process.exit(2);
}

const cmd = rest[0];
const sub = rest[1];

function help() {
  return [
    '小肥鱼记忆库 CLI',
    '',
    '分区   mem partition add --name <slug> --title <标题> [--desc ..]',
    '       mem partition list',
    '写入   mem remember --partition <p> --title <标题> [--body 正文] [--kind fact|decision|constraint|preference|task|report|note|trunk|scene]',
    '                      [--tags a,b] [--importance 1-5] [--pinned] [--task t_xxx]',
    '召回   mem recall "关键词" --partition <p> [--limit 8] [--detail index|full|auto] [--budget 1200] [--dormant] [--task t_xxx]',
  '反馈   mem feedback <eventId> [--used 1|0]   （命中率与遗忘曲线的唯一信号来源）',
  '主干速览 mem trunk --partition <p> [--digest] [--max-tokens 320]   # --digest 直接给一段能塞进上下文的主干摘要',
  '多模态 mem attach --itemId <id> --file <图片> [--caption 说明]',
  '向量   mem vector | mem reindex [分区] [--provider 1] | mem enrich [分区] [--limit 20]',
  '        mem describe --id <attachmentId>  或  --file <图片>   （视觉模型写描述，需先开 vision）',
  '        mem vision   （看多模态配置是否就绪）',
    '详情   mem get <itemId> [--days 120]',
    '删除   mem delete <itemId> [--hard] [--reason ..]      # 默认进回收站',
    '恢复   mem restore <itemId>',
    '回收   mem recycle [--partition <p>]',
    '清空   mem purge [--days 30] [--id <itemId>]',
    '附件   mem attach <itemId> --file <路径> [--caption ..] [--mime image/png]',
    '休眠   mem sweep                     # 按遗忘曲线把低保留条目转成 dormant',
    '任务   mem task start --partition <p> --title <标题> [--goal ..]',
    '       mem task log --id <taskId> --note .. [--tokens N]',
    '       mem task end --id <taskId> [--summary ..] [--md "## 做了什么\\n- ..."] [--report-file <path>] [--partition <p>] [--no-archive]',
    '汇报   mem report --partition <p> [--title ..] [--summary ..] [--file <md>] [--task <id>]',
    '       mem report list [--partition <p>] [--trash] | delete <id> | restore <id> | purge [--days 30]',
    '多模态 mem caption [--partition <p>] [--limit 20] [--all]   # 批量给图片写描述',
    '       mem caption status [--partition <p>]',
    '守卫   mem guard check --partition <p> [--tokens 150000] [--chars 240000] [--task t_xxx]',
    '一键修复 mem fix --partition <p>                      # 只出计划（安全步骤预勾选）',
    '       mem fix --partition <p> --apply [--step sweep,trunk,backup,cleanup,merge] [--cleanup-days 30] [--threshold 0.6]',
    '审查   mem audit [--partition <p>] [--hours 168]',
    '参数   mem config get | mem config set guard.contextBlockTokens=200000',
    '导出   mem export [--partition <p>] [--out file.json]',
    '导入   mem import --file file.json [--rename-partition newname]',
    '备份   mem backup | mem backups | mem integrity | mem rebuild',
    '统计   mem stats [--partition <p>] [--hours 24]',
    '主干   mem trunk --partition <p>          # 谁能豁免衰老 + 强化到什么程度',
    '强化   mem reinforce <itemId> [--strength 1.5] [--reason ..]   # 稳定度与强化系数同乘',
    '曲线   mem forecast <itemId> [--days 90]   # 未来留存预测（主干带地板线）',
    '合并   mem merge --partition <p> [--threshold 0.6] [--apply]   # 默认只预演',
    '评测   mem eval --partition <p> [--topK 5]   # 三种权重变体的命中率/MRR/token',
    '日报   mem daily [--partition <p>] [--days 7] [--dir data]   # 记忆健康日报（markdown）',
    '站点   mem site [--partition <p>] [--dir <目录>]   # 导出静态 Markdown 站点',
    '网页   mem ui [--port 8787]'
  ].join('\n');
}

function setPath(obj, dotted, value) {
  const parts = dotted.split('.');
  let cur = obj;
  for (let i = 0; i < parts.length - 1; i++) {
    if (typeof cur[parts[i]] !== 'object' || cur[parts[i]] === null) cur[parts[i]] = {};
    cur = cur[parts[i]];
  }
  const last = parts[parts.length - 1];
  const prev = cur[last];
  if (typeof prev === 'boolean') cur[last] = value === 'true' || value === '1';
  else if (typeof prev === 'number') cur[last] = Number(value);
  else if (typeof prev === 'object' && prev !== null) cur[last] = JSON.parse(value);
  else cur[last] = value;
  return obj;
}

async function main() {
  if (!cmd || cmd === 'help' || flags.help) return out(help());
  if (cmd === 'partition') {
    if (sub === 'list') {
      const rows = engine.listPartitions(store);
      return out({ partitions: rows }, rows.map(function (r) { return r.id + '  ' + r.name + '  ' + r.title; }).join('\n') || '(空)');
    }
    const p = engine.ensurePartition(store, { name: need('name'), title: flags.title, description: flags.desc });
    return out(p, '分区已就绪：' + p.name + ' · ' + p.title);
  }
  if (cmd === 'remember') {
    const r = engine.remember(store, {
      partition: need('partition'), title: flags.title, body: flags.body, kind: flags.kind,
      tags: flags.tags, importance: flags.importance, pinned: !!flags.pinned, taskId: flags.task, source: 'cli'
    });
    return out(r, (r.deduped ? '已存在，刷新时间戳：' : '已写入：') + r.item.id + '  ' + r.item.title);
  }
  if (cmd === 'recall') {
    const r = engine.recall(store, {
      partition: need('partition'), query: rest[1] || flags.query || '', limit: flags.limit,
      detail: flags.detail, includeDormant: !!flags.dormant, taskId: flags.task, sessionId: flags.session,
      budget: flags.budget === undefined ? undefined : Number(flags.budget)
    });
    if (asJson) return out(r);
    const lines = r.items.map(function (it, i) {
      const head = String(i + 1) + '. [' + it.score.toFixed(2) + '] ' + it.title + '  (' + it.kind + ', 保留 ' + (it.retention * 100).toFixed(0) + '%)' + (it.pinned ? ' ★' : '') + (it.redundant ? ' [已读多次，正文省略]' : '') + (it.layer ? ' · ' + it.layer : '');
      return it.body ? head + '\n   ' + it.body.replace(/\n/g, ' ') : head;
    });
    const tail = 'eventId=' + r.eventId + '  候选 ' + r.candidates + ' 条，命中 ' + r.items.length + ' 条，耗时 ' + r.tookMs + 'ms' +
      (r.budgetTokens === undefined ? '' : '  ·  token ' + r.totalTokens + '/' + r.budgetTokens + (r.budgetDropped ? '（超预算丢弃 ' + r.budgetDropped + ' 条）' : '') + (r.budgetDowngraded ? '（降级正文 ' + r.budgetDowngraded + ' 条）' : ''));
    return out(r, lines.join('\n') + '\n' + tail);
  }
  if (cmd === 'feedback') {
    const r = engine.feedback(store, { eventId: flags.eventId || rest[1] || need('eventId'), used: flags.used === undefined ? 1 : Number(flags.used) ? 1 : 0 });
    return out(r, '已回填反馈：event ' + r.eventId + ' → ' + (r.used ? '用上了' : '没用上') + '，影响 ' + r.affected + ' 条记忆稳定度');
  }
  if (cmd === 'vector') {
    const s = vector.vectorStatus(store);
    s.backend = vector.annBackend(store);
    const line = '向量：' + (s.enabled ? '开启' : '关闭') + ' · ' + s.dims + ' 维 · 覆盖 ' + s.covered + '/' + s.items +
      ' · 权重 ' + s.vectorWeight + ' · 后端 ' + s.backend.effective +
      ' · DeepSeek 指纹 ' + (s.deepseek && s.deepseek.ready ? '就绪(' + s.deepseek.model + ')' : '未就绪');
    return out(s, line);
  }
  if (cmd === 'reindex') {
    const name = flags.partition || rest[1] || null;
    const part = name ? engine.partitionByName(store, name) : null;
    if (name && !part) throw new Error('unknown partition: ' + name);
    const r = await vector.reindex(store, { partitionId: part ? part.id : null, provider: flags.provider === '1' || flags.provider === 'true' });
    return out(r, '向量重建完成：模型 ' + r.model + '，' + (r.written === undefined ? r.items : r.written) + ' 条，维度 ' + r.dims);
  }
  if (cmd === 'enrich') {
    const name = flags.partition || rest[1] || null;
    const part = name ? engine.partitionByName(store, name) : null;
    if (name && !part) throw new Error('unknown partition: ' + name);
    const r = await vector.enrichSemantics(store, { partitionId: part ? part.id : null, limit: flags.limit });
    return out(r, 'DeepSeek 语义指纹：新增 ' + r.enriched + ' 条，跳过 ' + r.skipped + ' 条，用掉 ' + r.tokens + ' tokens');
  }
  if (cmd === 'describe') {
    const r = await vision.describeImage(store, { attachmentId: flags.id || flags.attachmentId, path: flags.file, prompt: flags.prompt });
    return out(r, '描述已写入：' + r.caption);
  }
  if (cmd === 'vision') {
    const s = vision.visionStatus(store);
    return out(s, '视觉描述：' + (s.ready ? '就绪（' + s.model + '）' : '未就绪') + (s.hint ? '  ' + s.hint : ''));
  }
  if (cmd === 'get') return out(engine.getItem(store, argId(), { days: flags.days }));
  if (cmd === 'delete') {
    const r = engine.deleteItem(store, { id: argId(), hard: !!flags.hard, reason: flags.reason });
    return out(r, r.hard ? '已彻底删除 ' + r.id : '已移入回收站 ' + r.id + '（恢复：mem restore ' + r.id + '）');
  }
  if (cmd === 'restore') { const r = engine.restoreItem(store, argId()); return out(r, '已恢复 ' + r.id + ' · ' + r.title); }
  if (cmd === 'recycle') {
    const rows = engine.listRecycle(store, flags.partition ? engine.partitionByName(store, flags.partition).id : null);
    return out({ items: rows }, rows.map(function (r) { return r.id + '  ' + r.title + '  (删除于 ' + new Date(r.deleted_at).toLocaleString() + ')' + (r.expired ? ' [已过期]' : ''); }).join('\n') || '(回收站为空)');
  }
  if (cmd === 'purge') return out(engine.purgeDeleted(store, { id: flags.id, olderThanDays: flags.days === undefined ? flags.olderThanDays : flags.days }));
  if (cmd === 'attach') {
    const r = engine.attachToItem(store, { itemId: need('itemId') || need('item'), path: need('file'), caption: flags.caption, mime: flags.mime });
    return out(r, '附件已存：' + r.id + '  ' + r.path);
  }
  if (cmd === 'sweep') {
    const r = engine.sweep(store);
    return out(r, '扫描 ' + r.scanned + ' 条，状态变化 ' + r.changed.length + ' 条');
  }
  if (cmd === 'task') {
    if (sub === 'start') {
      const r = tasks.startTask(store, { partition: need('partition'), title: need('title'), goal: flags.goal, contextTokens: flags.tokens });
      return out(r, '任务已开启：' + r.task.id + '\n' + r.directive);
    }
    if (sub === 'log') return out(tasks.taskLog(store, { taskId: argId(), note: flags.note, tokens: flags.tokens }));
    if (sub === 'end' || sub === 'stop') {
      const md = flags['report-file']
        ? fs.readFileSync(String(flags['report-file']), 'utf8')
        : (flags.md === undefined ? undefined : String(flags.md).replace(/\\n/g, '\n'));
      const archive = !flags['no-archive'] && String(flags.archive || '1') !== '0';
      const r = tasks.endTask(store, { taskId: argId(), summary: flags.summary, markdown: md, partition: flags.partition, tokens: flags.tokens, abort: !!flags.abort, archive: archive });
      return out(r, '任务已关闭：' + r.task.id + (r.report ? '  汇报：' + r.report.path : '  (未写汇报)'));
    }
    return out(help());
  }
  if (cmd === 'report') {
    if (sub === 'list') {
      const part = flags.partition ? engine.partitionByName(store, flags.partition) : null;
      const rows = tasks.listReports(store, { trash: !!flags.trash, partitionId: part ? part.id : null, limit: Number(flags.limit || 100) });
      return out({ reports: rows }, rows.map(function (r) { return r.id + '  ' + new Date(Number(r.created_at)).toLocaleString() + '  ' + r.title + '  ' + r.path; }).join('\n') || (flags.trash ? '(汇报回收站为空)' : '(没有汇报)'));
    }
    if (sub === 'delete') {
      const r = tasks.deleteReport(store, { id: argId(), path: flags.path });
      return out(r, '汇报已移入回收站：' + r.report.title + '\n可恢复到 ' + new Date(r.restoreUntil).toLocaleDateString());
    }
    if (sub === 'restore') {
      const r = tasks.restoreReport(store, { id: argId(), path: flags.path });
      return out(r, '汇报已恢复：' + r.report.path);
    }
    if (sub === 'purge') {
      const r = tasks.purgeReports(store, { id: flags.id, path: flags.path, olderThanDays: flags.days === undefined ? flags.olderThanDays : flags.days });
      return out(r, '已彻底清理 ' + r.purged + ' 份汇报，删除文件 ' + r.filesRemoved + ' 个');
    }
    const md = flags.file ? fs.readFileSync(String(flags.file), 'utf8') : undefined;
    const r = tasks.writeReport(store, { partition: need('partition'), title: flags.title, summary: flags.summary, markdown: md, taskId: flags.task });
    return out(r, '汇报已写入：' + r.path);
  }
  if (cmd === 'caption') {
    const part = flags.partition ? engine.partitionByName(store, flags.partition) : null;
    if (sub === 'status' || flags.status) {
      const s = vision.captionStatus(store, { partitionId: part ? part.id : null });
      return out(s, '附件 ' + s.total + ' 个 · 已有描述 ' + s.captioned + ' · 待描述 ' + s.missing + (s.vision.ready ? '' : '  (' + (s.vision.hint || '视觉未就绪') + ')'));
    }
    const r = await vision.batchCaption(store, { partitionId: part ? part.id : null, limit: Number(flags.limit || 20), includeCaptioned: !!flags.all });
    return out(r, '批量描述：处理 ' + r.processed + ' · 成功 ' + r.done + ' · 失败 ' + r.failed + ' · 剩余 ' + r.remaining + (r.failed ? '（失败项重跑即重试）' : ''));
  }
  if (cmd === 'guard') {
    if (sub === 'list') {
      const r = listGuardEvents(store, {
        partitionId: flags.partition ? engine.partitionByName(store, flags.partition).id : null,
        level: flags.level || 'all',
        source: flags.source || 'all',
        deleted: flags.deleted === true || flags.deleted === '1',
        includeDeleted: flags['include-deleted'] === true || flags['include-deleted'] === '1',
        limit: Number(flags.limit || 40),
        offset: Number(flags.offset || 0)
      });
      if (asJson) return out(r);
      const head = '守卫记录 ' + r.total + ' 条（模拟 ' + r.bySource.simulated + ' / 真实 ' + r.bySource.real + '），本页 ' + r.events.length + ' 条';
      return out(r, head + '\n' + r.events.map(function (e) {
        return e.id + '  ' + new Date(e.ts).toISOString().slice(0, 16).replace('T', ' ') + '  ' + e.level + '  ' + e.source + (e.deleted ? '  [已删]' : '') + '  ' + String((e.reasons || []).join(' / ')).slice(0, 80);
      }).join('\n'));
    }
    if (sub === 'delete') {
      const ids = flags.ids ? String(flags.ids).split(',').filter(Boolean) : null;
      const r = deleteGuardEvents(store, { id: flags.id || rest[2], ids: ids, onlySimulated: !!flags.simulated, all: !!flags.all, hard: !!flags.hard });
      return out(r, '已删除 ' + r.deleted + ' 条守卫记录（其中模拟记录 ' + r.simulated + '）' + (r.hard ? '，彻底删除不可恢复' : '，已进回收（mem guard restore 可恢复）'));
    }
    if (sub === 'clear') {
      const r = deleteGuardEvents(store, { onlySimulated: true, hard: !!flags.hard });
      return out(r, '已清空 ' + r.deleted + ' 条模拟检查记录' + (r.hard ? '（彻底删除）' : '（可 mem guard restore 恢复）'));
    }
    if (sub === 'restore') {
      const ids = flags.ids ? String(flags.ids).split(',').filter(Boolean) : null;
      const r = restoreGuardEvents(store, { id: flags.id || rest[2], ids: ids });
      return out(r, '已恢复 ' + r.restored + ' 条守卫记录');
    }
    if (sub === 'purge') {
      const r = purgeGuardEvents(store, { olderThanDays: flags.days === undefined ? flags.olderThanDays : flags.days });
      return out(r, '已彻底清理 ' + r.purged + ' 条超过 ' + r.olderThanDays + ' 天的守卫记录');
    }
    if (sub && sub !== 'check') throw new Error('unknown guard subcommand: ' + sub);
    const r = checkGuard(store, { partition: need('partition'), contextTokens: flags.tokens, chars: flags.chars, taskId: flags.task, source: flags.simulated ? 'simulated' : 'real' });
    return out(r, '守卫生效等级：' + r.level + ' (score ' + r.score + ') · ' + r.source + '\n' + r.reasons.join('\n') + '\n→ ' + r.directive);
  }
  if (cmd === 'harness') {
    if (sub === 'import') {
      const sessions = flags.sessions ? String(flags.sessions).split(',').filter(Boolean) : null;
      const r = harness.importHarness(store, { root: flags.root, sessions: sessions, project: flags.project, confirmed: !!flags.confirm || !!flags.yes, force: !!flags.force });
      if (asJson) return out(r);
      if (r.dryRun) return out(r, '预演：将导入 ' + r.wouldImport + ' 条会话，跳过 ' + r.skipped + ' 条。加 --confirm 才真正写入。');
      return out(r, '已导入 ' + r.imported + ' 条会话记忆，跳过 ' + r.skipped + ' 条，涉及分区：' + (r.reusedPartitions.join(', ') || '无'));
    }
    const scan = harness.scanHarness(store, { root: flags.root });
    if (asJson) return out(scan);
    const lines = ['DSH 会话根：' + scan.root + '（存在 ' + scan.exists + '）',
      '共 ' + scan.totals.projects + ' 个项目 / ' + scan.totals.sessions + ' 个会话，已导入 ' + scan.totals.imported + ' 个'];
    for (const p of scan.projects) {
      lines.push('');
      lines.push('[' + p.partition + '] ' + p.name + ' · ' + p.sessionCount + ' 个会话（已导入 ' + p.importedCount + '）· ' + p.cwd);
      for (const s of p.sessions) {
        if (s.empty) continue;
        lines.push('  ' + (s.imported ? '✓' : '·') + ' ' + s.id + '  ' + new Date(s.updatedAt).toISOString().slice(0, 10) + '  ' + String(s.title).slice(0, 40) + '  (' + s.turns + ' 轮 / ' + s.toolCalls + ' 工具)');
      }
    }
    lines.push('', '导入：mem harness import --project <分区> --confirm   或   --sessions <id,id> --confirm');
    return out(scan, lines.join('\n'));
  }
  if (cmd === 'item') {
    const ids = flags.ids ? String(flags.ids).split(',').filter(Boolean) : (flags.id ? [String(flags.id)] : []);
    if (!ids.length) throw new Error('需要 --ids a,b 或 --id');
    const action = sub || 'pin';
    const results = [];
    for (const id of ids) {
      try {
        if (action === 'pin' || action === 'unpin') tools.setPinned(store, { id: id, pinned: action === 'pin' });
        else if (action === 'delete') engine.deleteItem(store, { id: id, reason: flags.reason || 'batch' });
        else if (action === 'restore') engine.restoreItem(store, id);
        else throw new Error('unknown item action: ' + action + '（pin|unpin|delete|restore）');
        results.push({ id: id, ok: true });
      } catch (err) { results.push({ id: id, ok: false, error: String(err.message || err) }); }
    }
    const ok = results.filter(function (x) { return x.ok; }).length;
    return out({ action: action, results: results }, action + '：成功 ' + ok + ' / ' + results.length + (ok < results.length ? '\n' + results.filter(function (x) { return !x.ok; }).map(function (x) { return x.id + ' → ' + x.error; }).join('\n') : ''));
  }
  if (cmd === 'audit') {
    const r = audit(store, { partition: flags.partition || null, hours: flags.hours });
    return out(r, r.findings.length ? r.findings.map(function (f) { return '[' + f.severity + '] ' + (f.partition || '*') + ' · ' + f.message + '  → ' + f.suggestion; }).join('\n') : '未发现问题');
  }
  if (cmd === 'config') {
    if (sub === 'set') {
      const patch = {};
      const pairs = rest.slice(2);
      if (!pairs.length) { console.error('usage: mem config set key=value [key=value]'); process.exit(2); }
      for (let k = 0; k < pairs.length; k++) {
        const pair = String(pairs[k]);
        const at = pair.indexOf('=');
        if (at > 0) { setPath(patch, pair.slice(0, at), pair.slice(at + 1)); continue; }
        const nextVal = pairs[k + 1];
        if (nextVal === undefined) throw new Error('参数要写成 key=value 或 key value：' + pair);
        setPath(patch, pair, String(nextVal));
        k += 1;
      }
      const next = tasks.updateConfig(store, patch);
      return out(next, '参数已更新');
    }
    return out(store.config);
  }
  if (cmd === 'export') {
    const include = flags.include ? String(flags.include).split(',').map(function (s) { return s.trim(); }).filter(Boolean) : null;
    const bundle = tasks.exportBundle(store, { partition: flags.partition || null, withEvents: flags.events !== '0', withGuardEvents: flags.guard === true || flags.guard === '1', withConfig: !!flags.config, include: include });
    if (flags.out) { fs.writeFileSync(String(flags.out), JSON.stringify(bundle, null, 2)); return out({ file: flags.out, items: bundle.items.length }); }
    return out(bundle);
  }
  if (cmd === 'import') {
    const file = flags.file || rest[1] || need('file');
    const bundle = JSON.parse(fs.readFileSync(String(file), 'utf8'));
    const r = tasks.importBundle(store, bundle, { renamePartition: flags['rename-partition'] || flags.rename });
    return out(r, '导入完成：分区 ' + r.partitions + '，条目 ' + r.items + '，任务 ' + r.tasks + '，跳过 ' + r.skipped);
  }
  if (cmd === 'backup') { const r = backup(store); return out(r, '已备份：' + r.path); }
  if (cmd === 'backups') { const rows = listBackups(store); return out({ backups: rows }, rows.map(function (r) { return r.name + '  ' + (r.bytes / 1024).toFixed(0) + 'KB'; }).join('\n') || '(无备份)'); }
  if (cmd === 'integrity') { const r = integrity(store); return out(r, (r.ok ? '数据库完好' : '数据库异常：') + r.detail); }
  if (cmd === 'rebuild') {
    backup(store);
    const r = rebuildFromShadow(store.root);
    return out(r, '已从影子日志重建：' + r.applied + '/' + r.entries + ' 条');
  }
  if (cmd === 'stats') {
    const pid = flags.partition ? engine.partitionByName(store, flags.partition).id : null;
    const r = { overview: engine.overview(store), hit: engine.hitStats(store, pid, Number(flags.hours || 24)) };
    return out(r);
  }
  if (cmd === 'search') {
    const r = tools.searchItems(store, {
      partition: need('partition'), q: rest[1] || flags.q || flags.query || '', tags: flags.tags, state: flags.state,
      kind: flags.kind, sort: flags.sort, limit: flags.limit, offset: flags.offset
    });
    if (asJson) return out(r);
    const lines = r.items.map(function (it, i) {
      return String(r.offset + i + 1) + '. [' + it.score.toFixed(2) + '] ' + it.title + '  (' + it.kind + ' · 保留 ' + (it.retention * 100).toFixed(0) + '% · 命中 ' + it.hitCount + ')' + '\n   ' + it.id + '  ' + it.snippet;
    });
    return out(r, lines.join('\n') + '\n共 ' + r.total + ' 条，本页 ' + r.items.length + ' 条（offset=' + r.offset + '）');
  }
  if (cmd === 'digest') {
    const r = tools.digest(store, { partition: need('partition'), days: flags.days });
    if (asJson) return out(r);
    const lines = [];
    lines.push('近 ' + r.days + ' 天 · ' + r.partition);
    lines.push('  记忆：新增 ' + r.items.created + ' · 更新 ' + r.items.updated + ' · 状态 ' + JSON.stringify(r.items.states));
    lines.push('  召回：' + r.recall.events + ' 次，返回 ' + r.recall.returned + ' 条，命中率 ' + (r.recall.hitRate === null ? '—' : (r.recall.hitRate * 100).toFixed(1) + '%'));
    lines.push('  守卫：' + (Object.keys(r.guards).length ? JSON.stringify(r.guards) : '无事件'));
    lines.push('  快忘：' + (r.nearForget.length ? r.nearForget.map(function (x) { return x.title; }).join('、') : '无'));
    lines.push('  冷掉：' + (r.cooling.length ? r.cooling.map(function (x) { return x.title + '(' + (x.retention * 100).toFixed(0) + '%)'; }).join('、') : '无'));
    lines.push('  任务：' + r.tasks.length + ' · 汇报：' + r.reports.length);
    return out(r, lines.join('\n'));
  }
  if (cmd === 'explain') {
    const r = tools.explain(store, { id: argId(), query: rest[2] && !flags.id ? undefined : (flags.query || rest[1]) });
    if (asJson) return out(r);
    const it = r.item;
    const lines = [it.title + '  (' + it.id + ')', '  保留率 ' + (it.retention * 100).toFixed(1) + '% · 稳定性 ' + it.stability + ' 天 · 已 ' + it.ageDays + ' 天没动 · 约 ' + it.daysUntilForget + ' 天后低于遗忘线 ' + it.forgetThreshold];
    if (r.components) {
      const c = r.components;
      lines.push('  打分：相关 ' + c.relevance + ' × 衰减 ' + c.retentionFactor + ' × 重要度 ' + c.importanceFactor + ' + 钉住 ' + c.pinnedBoost + ' = ' + c.score + (c.passesMinScore ? '（过线）' : '（低于 minScore ' + c.minScore + '，不会被召回）'));
      lines.push('  向量：cos ' + c.cos + '（floor ' + c.vectorFloor + '，权重 ' + c.vectorWeight + '）');
    }
    if (r.note) lines.push('  注意：' + r.note);
    if (r.events.length) lines.push('  最近召回：' + r.events.map(function (e) { return new Date(e.ts).toLocaleString() + (e.used === 1 ? ' 用上' : e.used === 0 ? ' 没用' : ' 未反馈'); }).join(' | '));
    return out(r, lines.join('\n'));
  }
  if (cmd === 'link') {
    const r = tools.link(store, { from: argId(), to: need('to'), relation: flags.relation });
    return out(r, (r.created ? '已建立关联：' : '已存在关联：') + r.link.from_id + ' -[' + r.link.relation + ']-> ' + r.link.to_id);
  }
  if (cmd === 'unlink') {
    const r = tools.unlink(store, { id: flags.id, from: flags.from, to: flags.to, relation: flags.relation });
    return out(r, '已删除关联 ' + r.removed + ' 条');
  }
  if (cmd === 'links') {
    const r = tools.links(store, { id: argId() });
    if (asJson) return out(r);
    const outLines = r.out.map(function (l) { return '  -> ' + l.to_id + '  [' + l.relation + '] ' + l.title; });
    const backLines = r.back.map(function (l) { return '  <- ' + l.from_id + '  [' + l.relation + '] ' + l.title; });
    return out(r, (outLines.concat(backLines).join('\n') || '  (没有关联)'));
  }
  if (cmd === 'expand') {
    const r = tools.expand(store, { id: argId(), depth: flags.depth });
    if (asJson) return out(r);
    return out(r, r.items.length ? r.items.map(function (x) { return '  ' + x.hop + '跳 [' + x.relation + '] ' + x.title + '  (' + x.id + ')'; }).join('\n') : '(没有邻居)');
  }
  if (cmd === 'pin') {
    const r = tools.setPinned(store, { id: argId(), pinned: flags.off || flags.unpin ? false : true });
    return out(r, (r.pinned ? '已钉住：' : '已取消钉住：') + r.title);
  }
  if (cmd === 'health') {
    const r = tools.health(store, { partition: flags.partition, fix: !!flags.fix });
    if (asJson) return out(r);
    const lines = ['体检 [' + r.partition + '] 等级 ' + r.level + (r.fixed ? ' · 已修复 ' + r.fixed + ' 项' : '')];
    lines.push('  条目 ' + r.counts.items + '（活跃 ' + r.counts.active + '，主干 ' + r.counts.trunk + '）· 附件 ' + r.counts.attachments + ' · 缺向量 ' + r.counts.missingVector + ' · 备份 ' + r.counts.backups + ' 份');
    for (const fd of r.findings) lines.push('  [' + fd.severity + '] ' + fd.code + '：' + fd.detail);
    return out(r, lines.join('\n'));
  }
  if (cmd === 'dedupe') {
    const r = tools.dedupe(store, { partition: need('partition'), threshold: flags.threshold });
    if (asJson) return out(r);
    if (!r.pairs.length) return out(r, '没有相似度超过 ' + r.threshold + ' 的条目（扫描 ' + r.scanned + ' 条）');
    const lines = r.pairs.map(function (p, i) { return String(i + 1) + '. ' + (p.similarity * 100).toFixed(1) + '%  ' + p.keep.title + '  <->  ' + p.drop.title + '\n   ' + p.suggestion; });
    return out(r, lines.join('\n'));
  }
  if (cmd === 'summarize') {
    const r = tools.summarize(store, { partition: need('partition'), limit: flags.limit, title: flags.title, taskId: flags.task });
    if (asJson) return out(r);
    if (!r.created) return out(r, '未生成主干：' + r.reason);
    return out(r, '已生成主干：' + r.item.id + '  ' + r.item.title + '\n  归纳 ' + r.sources.length + ' 条' + (r.superseded.length ? '，取代旧主干 ' + r.superseded.length + ' 条' : ''));
  }
  if (cmd === 'trunk') {
    const part = engine.partitionByName(store, need('partition'));
    if (!part) throw new Error('没有这个分区：' + flags.partition);
    if (flags.digest) {
      const d = engine.trunkDigest(store, { partition: part.name, maxTokens: flags['max-tokens'] === undefined ? undefined : Number(flags['max-tokens']), maxItems: flags['max-items'] === undefined ? undefined : Number(flags['max-items']) });
      if (asJson) return out(d);
      const head = '主干摘要 ' + d.items + ' 条 / 约 ' + d.tokens + ' tokens（预算 ' + d.budget + (d.truncated ? '，已截断' : '') + '）  层级：★' + d.layerCounts.trunk + ' ·' + d.layerCounts.scene + ' 细节' + d.layerCounts.detail;
      return out(d, head + '\n\n' + (d.text || '(这个分区还没有可当主干的内容)'));
    }
    const rows = engine.trunkSnapshot(store, part.id);
    if (asJson) return out({ partition: part.name, items: rows });
    if (!rows.length) return out({ partition: part.name, items: rows }, '这个分区还没有主干记忆（pinned 或 importance >= trunkImportance）');
    return out({ partition: part.name, items: rows }, rows.map(function (r) { return r.id + '  ★' + r.importance + '  留存 ' + (r.retention * 100).toFixed(0) + '%  强化 ' + r.boost + '  ' + r.title; }).join('\n'));
  }
  if (cmd === 'fix') {
    const part = engine.partitionByName(store, need('partition'));
    if (!part) throw new Error('没有这个分区：' + flags.partition);
    const steps = flags.step === undefined ? undefined : String(flags.step).split(',').map(function (x) { return x.trim(); }).filter(Boolean);
    const plan = planFix(store, { partition: part.name, cleanupDays: flags['cleanup-days'] === undefined ? undefined : Number(flags['cleanup-days']), threshold: flags.threshold === undefined ? undefined : Number(flags.threshold) });
    if (!flags.apply) {
      if (asJson) return out(plan);
      const lines = plan.steps.map(function (s) {
        return '  [' + (steps && steps.indexOf(s.id) < 0 ? ' ' : 'x') + '] ' + s.id.padEnd(8) + (s.safe ? '安全' : '需确认') + ' · ' + (s.reversible ? '可逆' : '不可逆') + '  ×' + s.count + '  ' + s.title + '\n        ' + s.detail;
      });
      const head = '守卫一键修复 · ' + part.name + '  等级 ' + plan.level + (plan.codes.length ? '（' + plan.codes.join(' / ') + '）' : '') + '\n主干摘要 ' + plan.trunk.items + ' 条 / 约 ' + plan.trunk.tokens + ' tokens';
      return out(plan, head + '\n' + lines.join('\n') + '\n\n只预览，什么都没改。确认后加 --apply（可配合 --step ' + plan.steps.map(function (s) { return s.id; }).join(',') + '）');
    }
    const r = applyFix(store, { partition: part.name, steps: steps, confirm: true, cleanupDays: flags['cleanup-days'] === undefined ? undefined : Number(flags['cleanup-days']), threshold: flags.threshold === undefined ? undefined : Number(flags.threshold) });
    if (r.ok === false && r.requiresConfirm) return out(r, '没有执行：需要 --apply 明确确认');
    if (asJson) return out(r);
    return out(r, '已执行 ' + r.applied + ' 步：\n' + r.results.map(function (x) { return '  ' + (x.ok ? '✓' : '✗') + ' ' + x.id.padEnd(8) + (x.error ? '  ' + x.error : '  ' + x.title + (x.reversible ? '' : '（不可逆）')); }).join('\n') + '\n\n跑 mem guard check 复查等级。');
  }
  if (cmd === 'reinforce') {
    const r = engine.reinforce(store, { id: argId(), strength: flags.strength, reason: flags.reason });
    return out(r, '已强化：' + r.item.title + '\n  稳定度 ' + r.before.stability + ' → ' + r.after.stability + ' · 强化系数 ' + r.before.boost + ' → ' + r.after.boost);
  }
  if (cmd === 'merge') {
    const part = engine.partitionByName(store, need('partition'));
    const r = engine.mergeSimilar(store, { partitionId: part.id, threshold: flags.threshold, apply: !!flags.apply, maxGroups: flags.max });
    if (asJson) return out(r);
    if (!r.groups.length) return out(r, '没有相似度超过 ' + r.threshold + ' 的组（扫描 ' + r.candidates + ' 条）');
    const lines = r.groups.map(function (g, i) {
      return String(i + 1) + '. 保留 ' + g.keeper.title + '\n' + g.members.map(function (m) { return '     <- ' + (m.score * 100).toFixed(1) + '%  ' + m.title; }).join('\n');
    });
    lines.push(r.dryRun ? '（预演，没有写库；确认无误加 --apply 真正合并）' : '已合并 ' + r.merged + ' 条');
    return out(r, lines.join('\n'));
  }
  if (cmd === 'eval') {
    const r = engine.evalRetrieval(store, { partition: need('partition'), topK: flags.topk || flags.topK, limit: flags.limit });
    if (asJson) return out(r);
    const lines = ['检索评测 [' + r.partition + '] · 每条标题自检索，比对三种权重'];
    for (const v of r.variants) lines.push('  ' + v.name.padEnd(14) + ' 命中率 ' + (v.hitRate * 100).toFixed(1) + '%  MRR ' + v.mrr.toFixed(3) + '  平均 ' + v.avgTokens + ' token');
    return out(r, lines.join('\n'));
  }
  if (cmd === 'daily') {
    const r = tasks.healthReport(store, { partition: flags.partition, days: flags.days, dir: flags.dir });
    if (asJson) return out(r);
    return out(r, r.markdown);
  }
  if (cmd === 'site') {
    const r = tasks.exportSite(store, { partition: flags.partition, dir: flags.dir, title: flags.title });
    return out(r, '静态站点已导出：' + r.dir + '\n  文件 ' + r.files.join(', ') + ' · 分区 ' + r.partitions.length + ' · 汇报 ' + r.reports + ' 篇 · index.html ' + r.bytes + ' 字节');
  }
  if (cmd === 'forecast') {
    const row = store.db.prepare('SELECT * FROM item WHERE id = ?').get(argId());
    if (!row) throw new Error('unknown item: ' + argId());
    const r = engine.projectCurve(row, store.config, Number(flags.days || 90));
    if (asJson) return out(r);
    const lines = ['曲线预测：' + (r.title || r.id), '  稳定度 ' + r.stability + '（基础 ' + r.baseStability + '）· 强化系数 ' + r.boost + ' · 主干 ' + (r.trunk ? '是' : '否') + (r.trunk ? ' · 地板 ' + r.floor : '')];
    for (const pt of r.points) if ([0, 7, 30, 90, 180, 365].indexOf(pt.day) !== -1) lines.push('  +' + pt.day + ' 天  留存 ' + (pt.retention * 100).toFixed(1) + '%');
    return out(r, lines.join('\n'));
  }
  if (cmd === 'ui') {
    const { spawn } = await import('node:child_process');
    const port = String(flags.port || store.config.server.port || 8787);
    const here = path.dirname(fileURLToPath(import.meta.url));
    const child = spawn(process.execPath, [path.join(here, 'server.mjs'), '--port', port], { detached: true, stdio: 'ignore' });
    child.unref();
    console.log('看板已启动：http://127.0.0.1:' + port);
    return;
  }
  return out(help());
}

main().catch(function (err) {
  console.error('错误：' + (err && err.message ? err.message : err));
  process.exit(1);
});