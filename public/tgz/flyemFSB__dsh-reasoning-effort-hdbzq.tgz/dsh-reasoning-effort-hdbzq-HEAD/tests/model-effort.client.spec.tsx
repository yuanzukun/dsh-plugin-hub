// @vitest-environment jsdom
import { cleanup, fireEvent, render, screen, waitFor } from '@testing-library/react'
import { afterEach, describe, expect, it, vi } from 'vitest'
import type { ModelSelection } from '@deepseek-ai/dsh-api-remotes/client'
import type { ComponentProps } from 'react'
import type { ModelDirectoryState } from '@deepseek-ai/dsh-client-ui-model-selection/client'
import { EFFORT_ASSETS } from '../src/client/assets.generated.ts'
import { zh } from '../src/client/locales.ts'
import { ModelEffort } from '../src/client/ModelEffort.tsx'
import { createSnapshotStore } from './vendor/client-runtime.ts'

// 真实应用中的 locale 查找链是：包字典 → 公共词汇表 → 键本身；这里的桩
// 只镜像首尾两环。
const t: ComponentProps<typeof ModelEffort>['t'] = (key, params) => {
  const template = (zh as Record<string, string>)[key] ?? key
  return params === undefined
    ? template
    : template.replace(/\{(\w+)\}/g, (match, name: string) => name in params ? String(params[name]) : match)
}

const reasoning = {
  efforts: [
    { id: 'off', name: 'Off' },
    { id: 'high', name: 'High' },
    { id: 'max', name: 'Max' },
  ],
  defaultEffort: 'high',
}

function state(overrides: Partial<ModelDirectoryState> = {}): ModelDirectoryState {
  return {
    current: { provider: 'deepseek-official', model: 'deepseek-v4-flash' },
    routable: true,
    groups: [{
      id: 'deepseek-official',
      name: 'DeepSeek',
      models: [
        { id: 'deepseek-v4-flash', name: 'DeepSeek-V4-Flash', reasoning },
        { id: 'deepseek-v4-pro', name: 'DeepSeek-V4-Pro', reasoning },
      ],
    }],
    failures: [],
    status: 'ready',
    error: null,
    ...overrides,
  }
}

interface SeatProps {
  locked?: boolean
  available?: boolean
  state?: Partial<ModelDirectoryState>
}

/** 在全新目录上渲染席位；select 模拟 host 应用所选选择。 */
function bench(props: SeatProps = {}) {
  const directory = createSnapshotStore<ModelDirectoryState>(state(props.state))
  const select = vi.fn(async (selection: ModelSelection) => {
    directory.set(state({ current: selection }))
    return true
  })
  const load = vi.fn()
  const utils = render(<ModelEffort
    locked={props.locked ?? false}
    available={props.available ?? true}
    directory={directory}
    load={load}
    select={select}
    t={t}
  />)
  return { ...utils, directory, select, load }
}

const open = () => {
  fireEvent.click(screen.getByRole('button', { name: /选择模型/ }))
}

afterEach(cleanup)

describe('ModelEffort 触发器', () => {
  it('显示模型名与取自图片文件名的按位置档位名', () => {
    bench({ state: { current: { provider: 'deepseek-official', model: 'deepseek-v4-flash', reasoningEffort: 'off' } } })
    expect(screen.getByRole('button', { name: '选择模型，当前 DeepSeek-V4-Flash，推理档位 小难梁' })).toBeTruthy()
    const img = document.querySelector('img')
    expect(img?.getAttribute('src')).toMatch(/^data:image\/(png|jpeg);base64,/)
    expect(EFFORT_ASSETS[0]?.name).toBe('小难梁')
  })

  it('会话不可用时渲染为空', () => {
    const { container } = bench({ available: false })
    expect(container.firstChild).toBeNull()
  })

  it('locked 时禁用触发器且永不展开', () => {
    bench({ locked: true })
    const trigger = screen.getByRole('button', { name: /选择模型/ }) as HTMLButtonElement
    expect(trigger.disabled).toBe(true)
    fireEvent.click(trigger)
    expect(screen.queryByRole('dialog')).toBeNull()
  })
})

describe('ModelEffort 面板', () => {
  it('展开时显示模型列表与三档滑块', () => {
    bench()
    open()
    expect(screen.getByRole('dialog')).toBeTruthy()
    const slider = screen.getByRole('slider') as HTMLInputElement
    expect(slider.min).toBe('0')
    expect(slider.max).toBe('2')
    expect(slider.value).toBe('1') // defaultEffort high -> 第 2 档
    expect(slider.getAttribute('aria-valuetext')).toBe('梁子')
    // 档位名同时出现在触发器与档位指示区（aria-hidden），故用 getAllByText
    expect(screen.getAllByText('小难梁').length).toBeGreaterThan(0)
    expect(screen.getAllByText('梁子').length).toBeGreaterThan(0)
    expect(screen.getAllByText('梁圣').length).toBeGreaterThan(0)
    expect(document.querySelectorAll('img').length).toBe(4) // 触发器头像 + 三个档位头像
    expect(screen.getByRole('menuitemradio', { name: /DeepSeek-V4-Flash/ })).toBeTruthy()
  })

  it('拖动滑块提交真实 effort id 且面板保持展开', async () => {
    const { select } = bench()
    open()
    const slider = screen.getByRole('slider')
    fireEvent.change(slider, { target: { value: '2' } })
    await waitFor(() => expect(select).toHaveBeenCalledWith({
      provider: 'deepseek-official',
      model: 'deepseek-v4-flash',
      reasoningEffort: 'max',
    }))
    expect(screen.getByRole('dialog')).toBeTruthy() // 滑块语义：无需重新展开即可连续调整
    fireEvent.change(slider, { target: { value: '0' } })
    await waitFor(() => expect(select).toHaveBeenCalledWith({
      provider: 'deepseek-official',
      model: 'deepseek-v4-flash',
      reasoningEffort: 'off',
    }))
  })

  it('切换模型只提交 provider/model，不带档位', async () => {
    const { select } = bench()
    open()
    fireEvent.click(screen.getByRole('menuitemradio', { name: /DeepSeek-V4-Pro/ }))
    await waitFor(() => expect(select).toHaveBeenCalledWith({
      provider: 'deepseek-official',
      model: 'deepseek-v4-pro',
    }))
  })

  it('Escape 关闭面板并把焦点还给触发器', async () => {
    const { getByRole } = bench()
    const trigger = getByRole('button', { name: /选择模型/ }) as HTMLButtonElement
    trigger.focus() // 真实浏览器点击后焦点在触发器；jsdom 的 fireEvent 不执行默认聚焦
    open()
    fireEvent.keyDown(document, { key: 'Escape' })
    expect(screen.queryByRole('dialog')).toBeNull()
    await Promise.resolve()
    expect(document.activeElement).toBe(trigger)
  })

  it('焦点在面板外时 Escape 不关闭面板', () => {
    bench()
    open()
    ;(document.activeElement as HTMLElement | null)?.blur()
    fireEvent.keyDown(document, { key: 'Escape' })
    expect(screen.getByRole('dialog')).toBeTruthy()
  })

  it('面板外 mousedown 关闭面板', () => {
    bench()
    open()
    fireEvent.mouseDown(document.body)
    expect(screen.queryByRole('dialog')).toBeNull()
  })

  it('selecting 期间滑块禁用且不触发提交', () => {
    const { select } = bench({ state: { status: 'selecting' } })
    open()
    const slider = screen.getByRole('slider') as HTMLInputElement
    expect(slider.disabled).toBe(true)
    fireEvent.change(slider, { target: { value: '2' } })
    expect(select).not.toHaveBeenCalled()
  })

  it('自身提交在途时输入不禁用，新档位合并续传（latest wins）', async () => {
    // 模拟真实 host：select 同步置 selecting，落地后才更新 current。
    const directory = createSnapshotStore<ModelDirectoryState>(state())
    let settle!: (accepted: boolean) => void
    const select = vi.fn((selection: ModelSelection) => {
      directory.set({ ...state({ current: selection }), status: 'selecting' })
      return new Promise<boolean>((resolve) => { settle = resolve })
    })
    render(<ModelEffort locked={false} available directory={directory} load={vi.fn()} select={select} t={t} />)
    open()
    const slider = screen.getByRole('slider') as HTMLInputElement
    fireEvent.change(slider, { target: { value: '2' } })
    // 在途：不因 busy 禁用，thumb 跟手到草稿位置。
    expect(slider.disabled).toBe(false)
    expect(slider.value).toBe('2')
    // 在途期间的新档位：只记 latest，不重复提交。
    fireEvent.change(slider, { target: { value: '0' } })
    expect(select).toHaveBeenCalledTimes(1)
    settle(true)
    // host 先落地第一次提交（max），随后效果续传积压的 latest（off）。
    directory.set(state({ current: { provider: 'deepseek-official', model: 'deepseek-v4-flash', reasoningEffort: 'max' } }))
    await waitFor(() => expect(select).toHaveBeenCalledTimes(2))
    expect(select).toHaveBeenLastCalledWith({
      provider: 'deepseek-official',
      model: 'deepseek-v4-flash',
      reasoningEffort: 'off',
    })
  })

  it('提交被拒后草稿回弹到已确认档位', async () => {
    const directory = createSnapshotStore<ModelDirectoryState>(state())
    const select = vi.fn(async () => false)
    render(<ModelEffort locked={false} available directory={directory} load={vi.fn()} select={select} t={t} />)
    open()
    const slider = screen.getByRole('slider') as HTMLInputElement
    fireEvent.change(slider, { target: { value: '2' } })
    await screen.findByRole('alert')
    await waitFor(() => expect(slider.value).toBe('1')) // 回弹到 store 确认档位 high
  })

  it('无档位元数据的模型不把残留档位 id 泄漏到触发器', () => {
    bench({
      state: {
        groups: [{ id: 'g', name: 'G', models: [{ id: 'm', name: 'M' }] }],
        // host 上报的 current 残留旧模型的档位，但模型本身无档位元数据。
        current: { provider: 'g', model: 'm', reasoningEffort: 'max' },
      },
    })
    const trigger = screen.getByRole('button', { name: /选择模型/ })
    expect(trigger.getAttribute('aria-label')).toBe('选择模型，当前 M')
    expect(document.querySelector('img')).toBeNull() // 无档位无头像
  })

  it('当前模型不在目录中时触发器显示选择回退文案', () => {
    bench({ state: { current: { provider: 'gone', model: 'gone' } } })
    expect(screen.getByRole('button', { name: '选择模型' })).toBeTruthy()
  })

  it('目录加载失败的错误条提供重新加载且可清除', async () => {
    const { directory, load } = bench()
    load.mockImplementation(() => { directory.set(state()) })
    open()
    // 模拟一次失败的目录加载：错误落在 store 上。
    directory.set({ ...state(), error: 'catalog exploded' })
    const alert = await screen.findByRole('alert')
    expect(alert.textContent).toContain('重新加载')
    fireEvent.click(screen.getByRole('button', { name: '重新加载' }))
    expect(load).toHaveBeenCalled()
    await waitFor(() => expect(screen.queryByRole('alert')).toBeNull())
  })

  it('选择失败的错误条不显示误导性的重新加载按钮', async () => {
    const directory = createSnapshotStore<ModelDirectoryState>({ ...state(), error: 'select rejected' })
    const select = vi.fn(async () => false)
    render(<ModelEffort locked={false} available directory={directory} load={vi.fn()} select={select} t={t} />)
    open()
    fireEvent.change(screen.getByRole('slider'), { target: { value: '2' } })
    const alert = await screen.findByRole('alert')
    expect(alert.textContent).toContain('select rejected')
    expect(screen.queryByRole('button', { name: '重新加载' })).toBeNull()
  })

  it('被拒绝的选择在面板内呈现 store 错误', async () => {
    const directory = createSnapshotStore<ModelDirectoryState>({ ...state(), error: 'catalog exploded' })
    const select = vi.fn(async () => false)
    render(<ModelEffort locked={false} available directory={directory} load={vi.fn()} select={select} t={t} />)
    open()
    fireEvent.change(screen.getByRole('slider'), { target: { value: '2' } })
    const alert = await screen.findByRole('alert')
    expect(alert.textContent).toContain('catalog exploded')
  })

  it('目录加载中显示加载状态', () => {
    bench({ state: { status: 'loading', groups: [], current: null } })
    open()
    expect(screen.getByText('正在刷新模型列表…')).toBeTruthy()
  })

  it('无内嵌图片的档位位置回退到目录提供的档位名', () => {
    const four = { efforts: [...reasoning.efforts, { id: 'ultra', name: 'Ultra' }], defaultEffort: 'high' }
    bench({
      state: {
        groups: [{
          id: 'deepseek-official',
          name: 'DeepSeek',
          models: [{ id: 'deepseek-v4-flash', name: 'DeepSeek-V4-Flash', reasoning: four }],
        }],
      },
    })
    open()
    expect(screen.getByRole('slider').getAttribute('max')).toBe('3')
    expect(screen.getAllByText('小难梁').length).toBeGreaterThan(0)
    expect(screen.getAllByText('梁子').length).toBeGreaterThan(0)
    expect(screen.getAllByText('梁圣').length).toBeGreaterThan(0)
    expect(screen.getByText('Ultra')).toBeTruthy()
    expect(document.querySelectorAll('img').length).toBe(4) // 触发器头像 + 三个内嵌档位
  })

  it('无推理元数据的模型显示空档位提示', () => {
    bench({
      state: {
        groups: [{ id: 'g', name: 'G', models: [{ id: 'm', name: 'M' }] }],
        current: { provider: 'g', model: 'm' },
      },
    })
    open()
    expect(screen.getByText('当前模型未提供推理档位。')).toBeTruthy()
  })

  it('目录失败以不可交互行列出', () => {
    bench({ state: { failures: [{ id: 'x', name: 'X-Provider', message: 'boom' }] } })
    open()
    expect(screen.getByText('X-Provider 加载失败：boom')).toBeTruthy()
  })
})
