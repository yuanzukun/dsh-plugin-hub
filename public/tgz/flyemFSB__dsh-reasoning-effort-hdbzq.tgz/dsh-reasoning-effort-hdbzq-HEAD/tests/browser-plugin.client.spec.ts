/**
 * dsh-reasoning-effort-hdbzq 浏览器半区，跑在真实 cordis Context 上，配
 * 假 locale/slots/sessions/modelDirectories 面：插件注册字典命名空间、
 * 在共享目录之上挂载 `conversation.input.model` 席位（locale + 覆盖优先
 * 级），且席位注入面接通目录动词并尊重子代理寻址。注册的释放函数即
 * HMR 安全契约（一切贡献都是效果）。
 */
import { Context } from '@deepseek-ai/cordis'
import { describe, expect, it, vi } from 'vitest'
import type { SessionId } from '@deepseek-ai/dsh-client-runtime/client'
import type { ModelSelection } from '@deepseek-ai/dsh-api-remotes/client'
import { apply, inject } from '../src/client/index.ts'
import type { ModelEffortInjected } from '../src/client/slots.ts'

const sid = (k: string): SessionId => k as SessionId

interface SeatRecord {
  locale: string | undefined
  priority: number | undefined
  inject: ((sessionId: SessionId) => ModelEffortInjected) | undefined
}

async function bench() {
  const ctx = new Context()
  const dictionaries = new Map<string, { zh: Record<string, string>; en: Record<string, string> }>()
  ctx.provide('locale', {
    register: (ns: string, dicts: { zh: Record<string, string>; en: Record<string, string> }) => {
      dictionaries.set(ns, dicts)
      return () => { dictionaries.delete(ns) }
    },
  })
  const addressed = new Set<SessionId>()
  ctx.provide('sessions', {
    subagentAddress: (id: SessionId) => addressed.has(id)
      ? { parentSessionId: sid('parent'), childSessionId: id, mode: 'continuable' as const }
      : undefined,
  })
  const directory = {
    store: {
      subscribe: vi.fn(() => () => {}),
      getSnapshot: vi.fn(() => ({
        current: null, routable: true, groups: [], failures: [], status: 'ready' as const, error: null,
      })),
    },
    load: vi.fn(() => Promise.resolve()),
    select: vi.fn(async (selection: ModelSelection) => selection),
  }
  ctx.provide('modelDirectories', { directoryFor: vi.fn(() => directory) })
  let seat: SeatRecord | undefined
  let disposeSeat: (() => void) | undefined
  ctx.provide('slots', {
    inject(_name: string, callback: () => () => void) { return callback() },
    register(options: SeatRecord) {
      seat = options
      disposeSeat = () => { seat = undefined }
      return disposeSeat
    },
  })
  const fiber = ctx.plugin({ inject: [...inject], apply })
  await fiber.await()
  await ctx.plugin(function probe() {}).await()
  return {
    seat: () => seat!,
    disposeSeat: () => disposeSeat!(),
    dictionaries,
    directory,
    addressed,
    fiber,
  }
}

describe('dsh-reasoning-effort-hdbzq 插件', () => {
  it('注册字典命名空间与带覆盖优先级的模型席位', async () => {
    const b = await bench()
    expect(b.dictionaries.has('modelEffort')).toBe(true)
    expect(b.seat().locale).toBe('modelEffort')
    expect(b.seat().priority).toBe(-10)
    expect(b.seat().inject).toBeTypeOf('function')
  })

  it('注入面接通共享目录动词并尊重子代理寻址', async () => {
    const b = await bench()
    const face = b.seat().inject!(sid('s1'))
    expect(face.available).toBe(true)
    await face.select({ provider: 'p', model: 'm', reasoningEffort: 'max' })
    expect(b.directory.select).toHaveBeenCalledWith({ provider: 'p', model: 'm', reasoningEffort: 'max' })
    face.load()
    expect(b.directory.load).toHaveBeenCalled()
    b.addressed.add(sid('s1'))
    const child = b.seat().inject!(sid('s1'))
    expect(child.available).toBe(false)
    await expect(child.select({ provider: 'p', model: 'm' })).resolves.toBe(false)
    child.load()
    expect(b.directory.load).toHaveBeenCalledTimes(1) // 被寻址会话不再触发加载
  })

  it('注册可逆：释放函数清空席位', async () => {
    const b = await bench()
    expect(b.seat()).toBeDefined()
    b.disposeSeat()
    expect(b.seat()).toBeUndefined()
  })
})
