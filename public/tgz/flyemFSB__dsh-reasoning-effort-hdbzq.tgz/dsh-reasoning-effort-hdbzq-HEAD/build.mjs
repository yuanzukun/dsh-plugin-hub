#!/usr/bin/env node
/**
 * dsh-reasoning-effort-hdbzq 构建脚本。
 *
 * `node build.mjs`             —— 完整构建：生成内嵌资产模块，用 tsc 产出
 *                                 声明，再用 esbuild 打包 node 半区
 *                                 （lib/index.js、lib/invariant.js）与浏览器半区
 *                                 （lib/client.js）。
 * `node build.mjs gen-assets`  —— 仅重新生成 src/client/assets.generated.ts
 *                                 （typecheck 与测试也需要它）。
 *
 * 浏览器包严格遵循 dsh 客户端插件契约（参考实现为
 * packages/client/tsdown.client.ts 的 tsdown 预设）：`__ModuleLoader__.load`
 * 闭包包装、平台模块 external（由注入的 require 解析）、CSS Modules 经
 * lightningcss 编译并自动注入 `<style data-plugin>`，以及拒绝跨插件值导入
 * 的纯度门禁（类型导入会在 esbuild 转换阶段被擦除，永远不会到达该门禁）。
 *
 * src/client/assets 下的三张 PNG 会被双线性缩放到最长边 160px 后内嵌为
 * data URL；档位显示名取自文件名（小难梁 / 梁子 / 梁圣），因此改文件名即
 * 改档位名。
 */
import { spawnSync } from 'node:child_process'
import { readFileSync, readdirSync, writeFileSync } from 'node:fs'
import { createRequire } from 'node:module'
import { basename, dirname, join, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'
import * as esbuild from 'esbuild'
import { transform } from 'lightningcss'

const require = createRequire(import.meta.url)

const ROOT = dirname(fileURLToPath(import.meta.url))
const ASSETS_DIR = join(ROOT, 'src', 'client', 'assets')
const GENERATED = join(ROOT, 'src', 'client', 'assets.generated.ts')
/** 头像内嵌前的最大边长（像素）；显示尺寸最大 36px，160px 足够 4 倍屏。 */
const ASSET_MAX_EDGE = 160
/** 头像照片的 JPEG 质量（0-100）；36px 显示尺寸下 q85 肉眼无损。 */
const JPEG_QUALITY = 85
const PACKAGE_ID = 'dsh-reasoning-effort-hdbzq'

/** 冻结的客户端模块表中的平台模块（镜像 dsh 源码 apps/web/src/platform.ts），外加 runtime store 引擎豁免项。 */
const CLIENT_EXTERNALS = [
  'react', 'react/jsx-runtime', 'react-dom', 'react-dom/client',
  '@deepseek-ai/cordis',
  '@deepseek-ai/dsh-client-ui-slots',
  '@deepseek-ai/dsh-client-web-react',
  '@deepseek-ai/dsh-client-ui-primitives',
  '@deepseek-ai/dsh-client-ui-attachment',
  '@deepseek-ai/dsh-client-schema-form',
  '@deepseek-ai/dsh-client-runtime/client',
]

/** 允许内联进浏览器包的线层/类型层（无共享运行时身份）。 */
const INLINE_SAFE = /^@deepseek-ai\/dsh-(host-apiproxy|session|llm|tools|brand)(\/|$)/

/** 已 rescope 的框架库（无跨插件运行时身份），与官方门禁一致。 */
const VENDORED_LIBRARY = /^@deepseek-ai\/(cosmokit|schemastery)(\/|$)/

/** 档位从左到右的固定顺序（显示名 = 文件名，按此顺序取用）。 */
const ASSET_ORDER = ['小难梁', '梁子', '梁圣']

/** pngjs 是 devDependency：缺席时降级为内嵌原始字节，避免构建脚本硬失败。 */
let pngModule = null
function pngjs() {
  if (pngModule === null) {
    try {
      pngModule = require('pngjs')
    } catch {
      pngModule = false
    }
  }
  return pngModule
}

/** jpeg-js 是 devDependency：照片（无透明通道）转 JPEG 可再省 3-4 倍体积；缺席时回退 PNG。 */
let jpegModule = null
function jpegjs() {
  if (jpegModule === null) {
    try {
      jpegModule = require('jpeg-js')
    } catch {
      jpegModule = false
    }
  }
  return jpegModule
}

/**
 * 对解码后的 RGBA PNG 做双线性缩放，边缘按最近像素钳制。
 * @param src - pngjs 解码出的源图像。
 * @param maxEdge - 目标最长边（像素）。
 * @returns 缩放到最长边不超过 maxEdge 的新图像。
 */
function downscale(src, maxEdge) {
  const scale = Math.min(1, maxEdge / Math.max(src.width, src.height))
  const w = Math.max(1, Math.round(src.width * scale))
  const h = Math.max(1, Math.round(src.height * scale))
  const dst = new (pngjs().PNG)({ width: w, height: h })
  const { data } = src
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      // 目标像素中心映射回源坐标，四邻域按距离加权。
      const sx = ((x + 0.5) / w) * src.width - 0.5
      const sy = ((y + 0.5) / h) * src.height - 0.5
      const x0 = Math.max(0, Math.floor(sx))
      const y0 = Math.max(0, Math.floor(sy))
      const x1 = Math.min(src.width - 1, x0 + 1)
      const y1 = Math.min(src.height - 1, y0 + 1)
      const fx = Math.min(1, Math.max(0, sx - x0))
      const fy = Math.min(1, Math.max(0, sy - y0))
      const o = (y * w + x) * 4
      for (let c = 0; c < 4; c++) {
        const a = data[(y0 * src.width + x0) * 4 + c]
        const b = data[(y0 * src.width + x1) * 4 + c]
        const d = data[(y1 * src.width + x0) * 4 + c]
        const e = data[(y1 * src.width + x1) * 4 + c]
        dst.data[o + c] = Math.round(
          a * (1 - fx) * (1 - fy) + b * fx * (1 - fy) + d * (1 - fx) * fy + e * fx * fy,
        )
      }
    }
  }
  return dst
}

/**
 * 将 src/client/assets 下每张 PNG 内嵌为 data URL；显示名 = 文件名。
 * 顺序固定为 {@link ASSET_ORDER}（用户指定的左到右），未列入的文件按
 * 码位排序追加到末尾（第 4 档起显示 host 原始名称）。
 */
function genAssets() {
  const files = readdirSync(ASSETS_DIR).filter((f) => f.endsWith('.png'))
  const byName = new Map(files.map((f) => [basename(f, '.png'), f]))
  const ordered = [
    ...ASSET_ORDER.map((n) => byName.get(n)).filter((f) => f !== undefined),
    ...files.map((f) => basename(f, '.png')).filter((n) => !ASSET_ORDER.includes(n)).sort().map((n) => byName.get(n)).filter((f) => f !== undefined),
  ]
  if (ordered.length === 0) throw new Error(`build: no PNG assets in ${ASSETS_DIR}`)
  const assets = ordered.map((file) => {
    const raw = readFileSync(join(ASSETS_DIR, file))
    // 照片走 JPEG（体积最小）；pngjs/jpeg-js 任一缺席时降级：能缩则 PNG，
    // 不能则嵌入原始字节——构建脚本不为缺 devDependency 而硬失败。
    let bytes = raw
    let mime = 'image/png'
    if (pngjs()) {
      try {
        const png = pngjs().PNG.sync.read(raw)
        const resized = Math.max(png.width, png.height) > ASSET_MAX_EDGE ? downscale(png, ASSET_MAX_EDGE) : png
        if (jpegjs()) {
          bytes = jpegjs().encode(resized, JPEG_QUALITY).data
          mime = 'image/jpeg'
        } else {
          bytes = pngjs().PNG.sync.write(resized)
        }
      } catch (cause) {
        console.warn(`build: pngjs could not process ${file}, embedding original bytes (${cause.message})`)
      }
    } else {
      console.warn('build: pngjs unavailable — embedding original-size images (npm install to enable downscaling)')
    }
    return { name: basename(file, '.png'), src: `data:${mime};base64,${bytes.toString('base64')}` }
  })
  const body = assets.map((a) => `  { name: ${JSON.stringify(a.name)}, src: ${JSON.stringify(a.src)} }`).join(',\n')
  writeFileSync(
    GENERATED,
    '// Generated by build.mjs from src/client/assets/*.png — do not edit.\n'
    + 'export interface EffortAsset { name: string; src: string }\n'
    + `export const EFFORT_ASSETS: readonly EffortAsset[] = [\n${body},\n]\n`,
  )
  const report = assets.map((a) => `${a.name}:${(a.src.length * 0.75 / 1024).toFixed(1)}KB`).join(', ')
  console.log(`build: embedded ${assets.length} assets (${report})`)
}

/**
 * 客户端模块边界规则的构建期镜像：平台条目保持 external，线层内联，
 * 其余 @deepseek-ai 值导入一律构建失败——跨插件值导入要么内联出重复的
 * 运行时实例，要么要求冻结的模块表回答一个不存在的说明符。
 */
const purityGate = {
  name: 'dsh-client-bundle-purity',
  setup(build) {
    build.onResolve({ filter: /^@deepseek-ai\// }, (args) => {
      if (CLIENT_EXTERNALS.includes(args.path)) return null
      if (VENDORED_LIBRARY.test(args.path)) return null
      if (INLINE_SAFE.test(args.path)) return null
      throw new Error(
        `client bundle purity: "${args.path}" is not a platform module or inline-safe wire layer — `
        + 'cross-plugin value imports are forbidden; use type-only imports (erased before resolution)',
      )
    })
  },
}

/** CSS Modules 经 lightningcss 编译：哈希类名映射 + 自动注入 `<style data-plugin>`（loader 卸载时会移除插件自有的 style 标签）。 */
const cssModules = {
  name: 'dsh-css-modules-inline',
  setup(build) {
    build.onResolve({ filter: /\.module\.css$/ }, (args) => ({
      path: resolve(args.resolveDir, args.path),
      namespace: 'css-module',
    }))
    build.onLoad({ filter: /.*/, namespace: 'css-module' }, async (args) => {
      const source = readFileSync(args.path)
      const { code, exports: cssExports } = transform({
        filename: args.path,
        code: source,
        cssModules: { pattern: '[hash]_[local]' },
        minify: true,
      })
      const classMap = {}
      for (const [local, exp] of Object.entries(cssExports ?? {})) classMap[local] = exp.name
      const tagId = `${PACKAGE_ID}/${basename(args.path)}`
      return {
        contents: [
          `const css = ${JSON.stringify(code.toString())};`,
          `const tagId = ${JSON.stringify(tagId)};`,
          `if (typeof document !== 'undefined' && document.querySelector('style[data-plugin-css=' + JSON.stringify(tagId) + ']') === null) {`,
          `  const tag = document.createElement('style');`,
          `  tag.dataset.plugin = ${JSON.stringify(PACKAGE_ID)};`,
          '  tag.dataset.pluginCss = tagId;',
          '  tag.textContent = css;',
          '  document.head.appendChild(tag);',
          '}',
          `export default ${JSON.stringify(classMap)};`,
        ].join('\n'),
        loader: 'js',
      }
    })
  },
}

async function build() {
  // 1. 声明（lib/types）——包的公开类型面。
  const tsc = join(ROOT, 'node_modules', 'typescript', 'bin', 'tsc')
  const tscRun = spawnSync(process.execPath, [tsc, '-p', 'tsconfig.build.json'], { cwd: ROOT, stdio: 'inherit' })
  if (tscRun.status !== 0) process.exit(tscRun.status ?? 1)

  // 2. node 半区（host 侧）：空 apply 在这里；host Loader 导入包根入口，
  //    与浏览器包无关。
  await esbuild.build({
    entryPoints: [join(ROOT, 'src', 'index.ts'), join(ROOT, 'src', 'invariant.ts')],
    outdir: join(ROOT, 'lib'),
    bundle: true,
    format: 'esm',
    platform: 'node',
    target: 'es2022',
    minify: true,
    logLevel: 'info',
  })

  // 3. 浏览器半区：客户端模块表加载的闭包工厂产物。
  await esbuild.build({
    entryPoints: { client: join(ROOT, 'src', 'client', 'index.ts') },
    outfile: join(ROOT, 'lib', 'client.js'),
    bundle: true,
    format: 'cjs',
    platform: 'browser',
    target: 'es2022',
    external: CLIENT_EXTERNALS,
    define: {
      'process.env.NODE_ENV': JSON.stringify(process.env.NODE_ENV ?? 'production'),
      'import.meta.env.MODE': JSON.stringify(process.env.NODE_ENV ?? 'production'),
      'import.meta.env': JSON.stringify({ MODE: process.env.NODE_ENV ?? 'production' }),
    },
    sourcemap: true,
    minify: true,
    banner: { js: `window.__ModuleLoader__.load({ id: ${JSON.stringify(PACKAGE_ID)}, factory: (require) => { var module = { exports: {} }; var exports = module.exports;` },
    footer: { js: 'return module.exports; } });' },
    plugins: [purityGate, cssModules],
    logLevel: 'info',
  })
}

const command = process.argv[2]
if (command === 'gen-assets') {
  genAssets()
} else if (command === undefined) {
  genAssets()
  await build()
} else {
  throw new Error(`build.mjs: unknown command "${command}"`)
}
