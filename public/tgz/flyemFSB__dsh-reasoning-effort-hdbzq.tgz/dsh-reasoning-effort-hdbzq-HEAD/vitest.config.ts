import { defineConfig } from 'vitest/config'

export default defineConfig({
  test: {
    include: ['tests/**/*.spec.{ts,tsx}'],
    // dsh 客户端包发布的是浏览器闭包包：必须由 vite 转换（连同其 CSS
    // 导入），而不是交给 Node ESM loader。
    server: {
      deps: {
        inline: [/@deepseek-ai\//],
      },
    },
  },
})
