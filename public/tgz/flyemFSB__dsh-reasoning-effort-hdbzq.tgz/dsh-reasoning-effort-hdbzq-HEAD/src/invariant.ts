/**
 * dsh-reasoning-effort-hdbzq 的包内运行时不变式伴生插件。
 * @module dsh-reasoning-effort-hdbzq/invariant
 */

import type { Context } from '@deepseek-ai/cordis'
import type { InvariantInstaller } from '@deepseek-ai/dsh-invariants'

const PACKAGE_NAME = 'dsh-reasoning-effort-hdbzq'

/** Cordis 伴生插件名。 */
export const name = 'reasoning-effort-hdbzq-invariant'
/** 注册前需要的不变式注册服务。 */
export const inject = ['invariants']

/**
 * 无运行时不变式：本插件只有一次插槽注册，其可逆性由 HMR 安全测试证明——
 * 不发射任何 cordis 事件，也不持有跨插件可变状态。
 */
const install: InvariantInstaller = () => {}

/**
 * 注册本包的不变式伴生插件。
 * @param ctx - 携带不变式服务的 Cordis 上下文。
 * @returns 安装成功后返回注册项的释放函数。
 */
export const apply = (ctx: Context): Promise<() => void> =>
  Promise.resolve(ctx.invariants.register(PACKAGE_NAME, install))
