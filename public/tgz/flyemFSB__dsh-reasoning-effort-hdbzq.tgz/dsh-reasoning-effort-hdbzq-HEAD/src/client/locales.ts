/**
 * `modelEffort` 命名空间字典——覆盖席位的文案。
 *
 * `trigger.selectAria` 当前与 `trigger.fallback` 相同，仍是独立键：未设置
 * 时触发器的可见回退文案与无障碍名称允许按 locale 分别演化。
 */

/** 简体中文词典（键集的事实来源）。 */
export const zh = {
  'trigger.fallback': '选择模型',
  'trigger.selectAria': '选择模型',
  'trigger.aria': '选择模型，当前 {model}',
  'trigger.ariaEffort': '选择模型，当前 {model}，推理档位 {effort}',
  'panel.aria': '模型与推理档位',
  'panel.model': '模型',
  'panel.effort': '滑动变祖器',
  'status.loading': '正在刷新模型列表…',
  'error.rejected': '选择未生效，请重试',
  'action.reload': '重新加载',
  'warning.groupLoad': '{name} 加载失败：{message}',
  'empty.models': '没有可用的模型。',
  'empty.efforts': '当前模型未提供推理档位。',
} satisfies Record<string, string>

/** modelEffort 命名空间的键联合。 */
export type ModelEffortKey = keyof typeof zh

/** 英文词典，按 zh 键集校验完整性。 */
export const en = {
  'trigger.fallback': 'Select model',
  'trigger.selectAria': 'Select model',
  'trigger.aria': 'Select model, current {model}',
  'trigger.ariaEffort': 'Select model, current {model}, effort {effort}',
  'panel.aria': 'Model and reasoning effort',
  'panel.model': 'Model',
  'panel.effort': 'Effort',
  'status.loading': 'Refreshing model list…',
  'error.rejected': 'Selection was not applied, try again',
  'action.reload': 'Reload',
  'warning.groupLoad': '{name} failed to load: {message}',
  'empty.models': 'No models available.',
  'empty.efforts': 'This model provides no reasoning effort levels.',
} satisfies Record<ModelEffortKey, string>
