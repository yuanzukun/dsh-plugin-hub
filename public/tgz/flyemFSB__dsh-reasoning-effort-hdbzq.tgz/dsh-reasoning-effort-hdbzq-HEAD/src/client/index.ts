/**
 * 推理档位选择插件，浏览器半区——composer 的命名模型席位
 * （`conversation.input.model`），覆盖内置 ModelSelect。单个弹出面板同时
 * 容纳 provider 分组的模型列表与三档推理档位条；档位显示名与头像来自
 * 构建期内嵌的图片（按位置映射：第 i 档 ↔ efforts[i]），而 `select` 提交
 * 的是 host 目录提供的真实 effort id——显示名永远不会进入模型请求。
 *
 * 数据与提交走与内置席位、/model 弹窗完全相同的按会话共享
 * ModelDirectory，因此任意入口的切换都是其他入口下一次看到的当前值。
 * 被寻址的子代理会话（available = false）不渲染任何内容，与内置契约一致。
 */
// 仅类型导入：载体类型与转发的 Host 事件面。
import type { ModelSelection } from '@deepseek-ai/dsh-api-remotes/client'
import type { ClientContext, SessionId } from '@deepseek-ai/dsh-client-runtime/client'
// 仅类型导入：拉取 locale 插件的 Context 合并（ctx.locale）。
import type {} from '@deepseek-ai/dsh-client-locale/client'
// 仅类型导入：拉取 ui-conversation 的 SlotMap 合并（input.model 席位声明）。
import type {} from '@deepseek-ai/dsh-client-ui-conversation/client'
// 仅类型导入：拉取 ui-model-selection 的 Context 合并（ctx.modelDirectories）。
import type {} from '@deepseek-ai/dsh-client-ui-model-selection/client'
import { en, zh, type ModelEffortKey } from './locales.ts'
import { ModelEffort } from './ModelEffort.tsx'
import type { ModelEffortInjected } from './slots.ts'

declare module '@deepseek-ai/dsh-client-ui-slots' {
  interface LocaleNamespaceMap {
    /** 推理档位席位的文案命名空间。 */
    modelEffort: ModelEffortKey
  }
}

/** 本插件拥有的字典命名空间。 */
const NS = 'modelEffort'

/** 需要的服务：席位插槽注册表、共享目录、locale、会话。 */
export const inject = ['locale', 'slots', 'modelDirectories', 'sessions']

/**
 * 客户端插件主体：注册字典，然后在共享目录之上注册 composer 模型席位。
 * @param ctx - 客户端根上下文。
 */
export function apply(ctx: ClientContext): void {
  ctx.effect(() => ctx.locale.register(NS, { zh, en }), 'ui-model-effort: dictionaries')

  ctx.inject(['slots', 'modelDirectories', 'sessions'], (scope: ClientContext) => {
    const models = scope.modelDirectories
    const sessions = scope.sessions
    scope.slots.inject('conversation.input.model', () => scope.slots.register({
      name: 'conversation.input.model',
      locale: NS,
      // 覆盖内置席位（优先级 0）：最低优先级者渲染，故 -10 替换整个
      // composer 的模型控件。这是协议常量而非可调参数——内置席位的默认
      // 优先级就是契约锚点。
      priority: -10,
      inject: (sessionId: SessionId): ModelEffortInjected => {
        const directory = models.directoryFor(sessionId)
        const available = sessions.subagentAddress(sessionId) === undefined
        return {
          available,
          directory: directory.store,
          load: () => {
            if (available) directory.load().catch(() => { /* 错误落在 store 上呈现 */ })
          },
          select: (selection: ModelSelection) => available
            ? directory.select(selection).then(() => true, () => false)
            : Promise.resolve(false),
        }
      },
    }, ModelEffort))
  })
}
