/**
 * ModelEffort：composer 模型席位（conversation.input.model）——模型列表 +
 * 三档推理滑块。档位名/头像按位置取自内嵌图片；select 提交真实 effort id。
 * 滑块为原生 range 语义 + 自绘交互：指针连续跟手、越界弹性、松手吸附提交；
 * 键盘 ← → 走原生事件即时提交；提交在途时输入保持可用（latest-wins 合并）。
 */
import { useEffect, useId, useMemo, useRef, useState, useSyncExternalStore, type CSSProperties, type KeyboardEvent, type PointerEvent } from 'react'
import clsx from 'clsx'
import { IconCheckOutline16, IconChevronDownOutline14 } from '@deepseek-ai/dsh-client-ui-primitives'
import type { PropsLocale } from '@deepseek-ai/dsh-client-ui-slots'
import { EFFORT_ASSETS } from './assets.generated.ts'
import type { ModelEffortInjected } from './slots.ts'
import css from './ModelEffort.module.css'

/**
 * 渲染 composer 模型席位。
 * @param props - owner 分享（locked）+ 注入面（共享目录 store/动词）+ locale 席位。
 */
export function ModelEffort(
  { locked, available, directory, load, select, t }:
  ModelEffortInjected & { locked: boolean } & PropsLocale<'modelEffort'>,
) {
  const state = useSyncExternalStore(
    fn => directory.subscribe(fn),
    () => directory.getSnapshot(),
  )
  const [open, setOpen] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [dragging, setDragging] = useState(false)
  // 跟手草稿：指针/键盘先落本地位置，null = 跟随 store 确认档位。
  const [draft, setDraft] = useState<number | null>(null)
  // 自身提交在途：输入保持可用，新档位记入 pendingRef，落地后 latest-wins 续传。
  const [ownPending, setOwnPending] = useState(false)
  const pendingRef = useRef<number | null>(null)
  const inFlightRef = useRef(false)
  // 指针手势进行中：拖动完全自绘（preventDefault 弃用原生拖动），并抑制外点关闭。
  const gestureRef = useRef(false)
  // 最近一次提交请求的档位（幂等去重；被拒后复位以允许重试）。
  const requestedRef = useRef(-1)
  const inputRef = useRef<HTMLInputElement | null>(null)
  // 面板打开时的档位名：冻结按钮标签，避免宽度变化带动 right:0 面板位移。
  const openedNameRef = useRef<string | undefined>(undefined)
  const rootRef = useRef<HTMLDivElement | null>(null)
  const triggerRef = useRef<HTMLButtonElement | null>(null)
  const itemRefs = useRef<(HTMLButtonElement | null)[]>([])
  const id = useId()

  const rows = useMemo(() => state.groups.flatMap(group =>
    group.models.map(model => ({ group, model }))), [state.groups])
  const selectedIndex = state.current === null
    ? -1
    : rows.findIndex(row => row.group.id === state.current?.provider && row.model.id === state.current?.model)
  const currentRow = rows[selectedIndex]
  const reasoning = currentRow?.model.reasoning
  const efforts = reasoning?.efforts ?? []
  const effectiveEffort = state.current?.reasoningEffort ?? reasoning?.defaultEffort
  const effortIndex = efforts.findIndex(effort => effort.id === effectiveEffort)
  // 触发器只反映 store 确认档位；无档位元数据时不显示名（避免残留 id 泄漏）。
  const committedAsset = EFFORT_ASSETS[effortIndex]
  const effortName = reasoning === undefined || efforts.length === 0
    ? undefined
    : committedAsset?.name ?? efforts[effortIndex]?.name
      ?? (effortIndex < 0 ? effectiveEffort : undefined)
  const modelLabel = currentRow?.model.name ?? t('trigger.fallback')
  const busy = state.status === 'selecting'
  // 档位位置（百分比）；轨道两端留出 thumb 半宽（TRACK_PAD，与 CSS padding 同步）。
  const trackPos = (index: number): number => efforts.length <= 1 ? 0 : index / (efforts.length - 1) * 100
  const TRACK_PAD = 22
  // 面板内显示：thumb 用草稿原值连续跟手（弹性区可越界）；语义取整夹紧。
  const displayPos = draft ?? effortIndex
  const posClamped = Math.min(Math.max(displayPos, 0), Math.max(0, efforts.length - 1))
  const displayIndex = Math.round(posClamped)
  const displayAsset = EFFORT_ASSETS[displayIndex]
  const progress = trackPos(posClamped)
  const knobPos = trackPos(displayPos)
  const effortNameAt = (index: number): string | undefined =>
    EFFORT_ASSETS[index]?.name ?? efforts[index]?.name

  // 挂载时加载一次以解析触发器标签；每次展开都刷新。
  useEffect(() => {
    if (available) {
      load()
    }
  }, [available, load])

  // 外点与 Escape 关闭（Escape 后把焦点还给触发器）。
  useEffect(() => {
    if (!open) return
    const closeOutside = (event: MouseEvent): void => {
      // 手势进行中不关闭：误关会让指针 capture 留在已卸载的 input 上，拖动冻结。
      if (gestureRef.current) return
      if (!rootRef.current?.contains(event.target as Node)) setOpen(false)
    }
    const onKey = (event: globalThis.KeyboardEvent): void => {
      if (event.key === 'Escape' && rootRef.current?.contains(document.activeElement)) {
        setOpen(false)
        queueMicrotask(() => { triggerRef.current?.focus() })
      }
    }
    document.addEventListener('mousedown', closeOutside)
    document.addEventListener('keydown', onKey)
    return () => {
      document.removeEventListener('mousedown', closeOutside)
      document.removeEventListener('keydown', onKey)
    }
  }, [open])

  // 提交落地或失败时清在途标记；失败在面板内呈现 store 错误。
  const settleSelection = (accepted: boolean): void => {
    inFlightRef.current = false
    if (!accepted) {
      requestedRef.current = -1
      setError(directory.getSnapshot().error ?? t('error.rejected'))
    }
  }

  const commitEffort = (index: number): void => {
    const effort = efforts[index]
    if (effort === undefined || state.current === null) return
    inFlightRef.current = true
    requestedRef.current = index
    setOwnPending(true)
    setError(null)
    void select({
      provider: state.current.provider,
      model: state.current.model,
      reasoningEffort: effort.id,
    }).then(settleSelection)
  }

  // 非手势路径（键盘、点轨）：位置落草稿即时跟手，提交幂等去重 + 在途合并。
  const chooseEffort = (index: number): void => {
    if (efforts[index] === undefined || state.current === null) return
    if (busy && !ownPending) return
    setDraft(index)
    if (index === requestedRef.current) return
    if (inFlightRef.current) {
      pendingRef.current = index
      return
    }
    commitEffort(index)
  }

  // 指针手势：preventDefault 弃用原生拖动（原生 value 拖动中步进取整无法跟手），
  // 焦点手动恢复以保键盘可达；按下即定位（点击轨道同一路径）。
  const startGesture = (event: PointerEvent<HTMLInputElement>): void => {
    event.preventDefault()
    gestureRef.current = true
    setDragging(true)
    event.currentTarget.focus()
    try { event.currentTarget.setPointerCapture(event.pointerId) } catch { /* 老引擎无捕获：降级为窗口内跟手 */ }
    moveTo(event.clientX)
  }

  // 指针位置 → 草稿：与可见轨道同一线性映射；越界 25% 阻尼（rubber-band），
  // 视觉上最多越出半个 thumb；同步原生 value 保持 aria-valuenow 实时。
  const moveTo = (clientX: number): void => {
    const input = inputRef.current
    if (input === null) return
    const rect = input.getBoundingClientRect()
    const max = Math.max(0, efforts.length - 1)
    const trackW = Math.max(1, rect.width - TRACK_PAD * 2)
    const raw = (clientX - rect.left - TRACK_PAD) / trackW * max
    if (!Number.isFinite(raw)) return // 异常几何（如空 rect）不产生 NaN 草稿
    const rubber = raw < 0 ? raw * 0.25 : raw > max ? max + (raw - max) * 0.25 : raw
    const edge = TRACK_PAD / trackW * max
    const pos = Math.min(Math.max(rubber, -edge), max + edge)
    setDraft(pos)
    input.value = String(Math.min(Math.max(Math.round(raw), 0), max))
  }

  // 松手/取消/捕获丢失：吸附最近档位并提交；弹簧回弹由 CSS 过渡承担。
  const endGesture = (): void => {
    gestureRef.current = false
    setDragging(false)
    const max = Math.max(0, efforts.length - 1)
    const target = Math.min(Math.max(Math.round(draft ?? effortIndex), 0), max)
    setDraft(target)
    chooseEffort(target)
  }

  // 提交落地（busy 复位）后清在途标记；期间积压的最新档位续传。
  useEffect(() => {
    if (!ownPending || busy) return
    setOwnPending(false)
    const pending = pendingRef.current
    pendingRef.current = null
    if (pending !== null && pending !== effortIndex) commitEffort(pending)
  }, [ownPending, busy, effortIndex, commitEffort])

  // 草稿收敛：不拖动且无自身提交在途时，草稿偏离 store 确认档位（被拒/外部
  // 变更）→ 回到确认值，CSS 回弹曲线做吸附动画。
  useEffect(() => {
    if (dragging || ownPending || draft === null || draft === effortIndex) return
    setDraft(null)
  }, [dragging, ownPending, draft, effortIndex])

  // 非受控 input 的 value 同步：键盘/外部/回弹后 aria-valuenow 与视觉一致。
  useEffect(() => {
    if (gestureRef.current) return
    const input = inputRef.current
    if (input === null) return
    const target = String(Math.max(Math.round(draft ?? effortIndex), 0))
    if (input.value !== target) input.value = target
  }, [draft, effortIndex])

  // 换模型后复位提交去重：新模型同位置的档位与旧模型无语义关联，首次交互必须提交。
  useEffect(() => {
    requestedRef.current = -1
  }, [state.current?.model])

  if (!available) return null

  const show = (): void => {
    setError(null)
    setOpen(true)
    load()
    openedNameRef.current = effortName // 冻结按钮标签：面板打开期间宽度不变
  }

  const close = (restoreFocus = false): void => {
    setOpen(false)
    if (restoreFocus) queueMicrotask(() => { triggerRef.current?.focus() })
  }

  const chooseModel = (index: number): void => {
    const row = rows[index]
    if (row === undefined) return
    setError(null)
    if (state.current?.provider === row.group.id && state.current.model === row.model.id) {
      close(true)
      return
    }
    // 切模型只带 provider/model，不带档位：host 按其默认档位解析。
    void select({ provider: row.group.id, model: row.model.id }).then((accepted) => {
      settleSelection(accepted)
      if (accepted) close(true)
    })
  }

  // 模型行上的漫游焦点（与内置席位同款模式）。
  const moveFocus = (offset: number): void => {
    const items = itemRefs.current.filter((item): item is HTMLButtonElement => item !== null)
    if (items.length === 0) return
    const active = items.findIndex(item => item === document.activeElement)
    const next = (Math.max(active, 0) + offset + items.length) % items.length
    items[next]?.focus()
  }

  const onModelListKeyDown = (event: KeyboardEvent<HTMLDivElement>): void => {
    if (event.key !== 'ArrowDown' && event.key !== 'ArrowUp') return
    event.preventDefault()
    moveFocus(event.key === 'ArrowDown' ? 1 : -1)
  }

  const triggerLabel = effortName === undefined ? modelLabel : `${modelLabel} · ${effortName}`
  const triggerAria = currentRow === undefined
    ? t('trigger.selectAria')
    : effortName === undefined
      ? t('trigger.aria', { model: modelLabel })
      : t('trigger.ariaEffort', { model: modelLabel, effort: effortName })
  // 渲染前清空引用数组：残留旧引用会让漫游焦点指向已卸载的节点。
  itemRefs.current = []
  let itemIndex = 0
  const itemRef = () => {
    const at = itemIndex++
    return (node: HTMLButtonElement | null) => { itemRefs.current[at] = node }
  }

  return (
    <div ref={rootRef} className={css.root}>
      <button
        ref={triggerRef}
        type="button"
        className={css.trigger}
        aria-label={triggerAria}
        aria-haspopup="dialog"
        aria-expanded={open}
        aria-controls={open ? `${id}-panel` : undefined}
        title={triggerLabel}
        disabled={locked}
        onClick={() => { if (open) { close() } else { show() } }}
      >
        {committedAsset !== undefined && <img className={css.triggerAvatar} src={committedAsset.src} alt="" />}
        <span className={css.triggerLabel}>{modelLabel}</span>
        {(open ? openedNameRef.current : effortName) !== undefined
          && <span className={css.triggerEffort}>{open ? openedNameRef.current : effortName}</span>}
        <IconChevronDownOutline14 className={clsx(css.chevron, open && css.chevronOpen)} />
      </button>

      {open && (
        <div id={`${id}-panel`} className={css.panel} role="dialog" aria-label={t('panel.aria')}>
          <div className={css.sectionTitle}>{t('panel.model')}</div>
          {state.status === 'loading' && rows.length === 0 && (
            <div className={css.status}>{t('status.loading')}</div>
          )}
          <div role="menu" aria-label={t('panel.model')} className={css.modelList} onKeyDown={onModelListKeyDown}>
            {rows.map((row, index) => {
              const selected = index === selectedIndex
              return (
                <button
                  key={`${row.group.id}/${row.model.id}`}
                  ref={itemRef()}
                  type="button"
                  role="menuitemradio"
                  aria-checked={selected}
                  className={clsx(css.modelRow, selected && css.modelRowSelected)}
                  disabled={busy}
                  onClick={() => { chooseModel(index) }}
                >
                  <span className={css.modelCopy}>
                    <span className={css.modelName}>{row.model.name}</span>
                    <span className={css.modelGroup}>{row.group.name}</span>
                  </span>
                  {selected && <IconCheckOutline16 className={css.check} />}
                </button>
              )
            })}
            {state.failures.map(failure => (
              <div key={failure.id} className={css.warning}>
                <span>{t('warning.groupLoad', { name: failure.name, message: failure.message })}</span>
              </div>
            ))}
            {state.status === 'ready' && rows.length === 0 && (
              <div className={css.status}>{t('empty.models')}</div>
            )}
          </div>

          <div className={css.sectionTitle}>
            {/* 中文梗标题：中间字加粗；非中文 locale 显示词典值。 */}
            {t('panel.effort') === '滑动变祖器'
              ? <>滑动变<strong className={css.effortStrong}>祖</strong>器</>
              : t('panel.effort')}
          </div>
          {efforts.length > 0 ? (
            <div className={css.effortBar}>
              <div className={clsx(css.trackWrap, dragging && css.trackWrapDragging)}>
                {/* 装饰轨道层：填充、刻度、火花（档位渐强）；语义在原生 range 上。 */}
                <div className={css.track} aria-hidden="true">
                  {/* 填充在轨道（已含留白）内，直接按轨道百分比。 */}
                  <div className={css.trackFill} style={{ width: `${progress}%` }} />
                  {efforts.map((_, index) => (
                    <span
                      key={index}
                      className={clsx(css.tick, index <= displayIndex && css.tickActive)}
                      style={{ left: `${trackPos(index)}%` }}
                    />
                  ))}
                  {efforts.map((_, index) => index > 0 && index <= displayIndex
                    ? <span key={index} className={css.spark} style={{ left: `${trackPos(index)}%` }} />
                    : null)}
                </div>
                {/* 自绘 thumb：当前档位头像 + 光环，弹性区可越出轨道两端，拖动中放大。 */}
                <div
                  className={clsx(css.knob, dragging && css.knobDragging)}
                  style={{
                    left: `calc(${TRACK_PAD}px + (100% - ${TRACK_PAD * 2}px) * ${knobPos} / 100)`,
                    '--thumb-image': displayAsset !== undefined ? `url("${displayAsset.src}")` : 'none',
                  } as CSSProperties}
                  aria-hidden="true"
                />
                {/* 原生 range 透明 thumb：a11y/键盘语义载体，拖动完全自绘。 */}
                <input
                  ref={inputRef}
                  type="range"
                  className={css.range}
                  min={0}
                  max={Math.max(0, efforts.length - 1)}
                  step={1}
                  defaultValue={String(Math.max(effortIndex, 0))}
                  disabled={(busy && !ownPending) || efforts.length <= 1}
                  aria-label={t('panel.effort')}
                  aria-valuetext={effortNameAt(displayIndex)}
                  onPointerDown={startGesture}
                  onPointerMove={(event) => { if (gestureRef.current) moveTo(event.clientX) }}
                  onPointerUp={endGesture}
                  onPointerCancel={endGesture}
                  onLostPointerCapture={endGesture}
                  onChange={(event) => {
                    // 键盘 ← →（非受控原生事件）；指针路径已被 preventDefault 拦下。
                    if (gestureRef.current) return
                    chooseEffort(Math.round(Number(event.currentTarget.value)))
                  }}
                />
              </div>
              <div className={css.stops} aria-hidden="true">
                {efforts.map((effort, index) => {
                  const stop = EFFORT_ASSETS[index]
                  const active = index === displayIndex
                  return (
                    <span
                      key={effort.id}
                      className={clsx(css.stop, active && css.stopActive)}
                      style={{ left: `calc(${TRACK_PAD}px + (100% - ${TRACK_PAD * 2}px) * ${trackPos(index)} / 100)` }}
                    >
                      {stop !== undefined && <img className={css.stopAvatar} src={stop.src} alt="" />}
                      <span className={css.stopName}>{stop?.name ?? effort.name}</span>
                    </span>
                  )
                })}
              </div>
            </div>
          ) : (
            <div className={css.status}>{t('empty.efforts')}</div>
          )}

          {(error ?? state.error) !== null && (
            <div className={css.error} role="alert">
              <span>{error ?? state.error}</span>
              {/* 重载按钮只针对目录加载失败；选择失败已在本地 error 呈现，不误导重试。 */}
              {state.error !== null && error === null && (
                <button type="button" className={css.retry} onClick={() => { setError(null); load() }}>{t('action.reload')}</button>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  )
}
