/**
 * ModelEffort 面向 `conversation.input.model` 席位的注入面。席位由
 * ui-conversation 的 composer-bar 条目声明并定类型；本包只贡献唯一占位
 * （覆盖内置 ModelSelect），因此这里不做 SlotMap 合并。注入面与内置席位的
 * `ModelSelectInjected` 同形：两者都通过共享的按会话
 * `modelDirectories` 目录提交。
 */
import type { ModelSelection } from '@deepseek-ai/dsh-api-remotes/client'
import type { SnapshotStore } from '@deepseek-ai/dsh-client-runtime/client'
import type { ModelDirectoryState } from '@deepseek-ai/dsh-client-ui-model-selection/client'

/** 注入到 composer 模型席位组件中的业务面。 */
export interface ModelEffortInjected {
  /** 本会话是否支持 Agent 绑定的模型检查与选择。 */
  available: boolean
  /** 会话的共享目录 store（与内置 /model 弹窗读同一实例）。 */
  directory: SnapshotStore<ModelDirectoryState>
  /** 刷新建议性目录（即发即忘；错误落在 store 上）。 */
  load: () => void
  /**
   * 提交完整的 provider/model/reasoning 选择。
   * @param selection - 模型选择及可选的适配器自有 effort。
   * @returns host 是否接受了该选择。
   */
  select: (selection: ModelSelection) => Promise<boolean>
}
