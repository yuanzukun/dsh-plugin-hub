/**
 * dsh-reasoning-effort-hdbzq 的 node 半区。纯 UI 插件：空 apply 仅用于让
 * 插件出现在 host 的 cordis.yml / Loader 中；浏览器半区经
 * exports["./client"] 提供，由 package.json 的 dsh.client 声明被发现。
 */

/** Host 侧插件主体——该表面插件无任何 host 侧行为。 */
export function apply(): void {}
