# dsh-reasoning-effort-hdbzq

DeepSeek Harness 前端插件：把输入框里的模型选择控件换成**模型列表 + 三档推理档位滑块**。档位名称和头像取自 `src/client/assets/` 下的三张图片，从左到右：**小难梁 · 梁子 · 梁圣**。

实现遵循官方客户端插件契约（`packages/client/AGENTS.md`、`ui-slots` 插槽系统、`tsdown.client.ts` 构建契约），没有基于既有插件二开：

- 用官方 `ctx.slots.inject` + `slots.register`（`priority: -10`）覆盖内置 `conversation.input.model` 席位，卸载后自动恢复。
- 复用官方 `modelDirectories` 服务与共享目录 store，不自己实现模型调用。真实 Effort ID（如 `off` / `high` / `max`）原样交给 `session.selectModel`，「小难梁 / 梁子 / 梁圣」只在浏览器界面出现，不会写进模型请求。
- 样式只用官方 `--dsw-alias-*` 语义 token，跟随亮/暗主题。
- 文案走官方 locale 字典机制（`zh` / `en` 双词典）。
- 构建产出与官方一致的 `__ModuleLoader__` 闭包包（`lib/client.js` + source map），CSS Modules 经 lightningcss 编译并自动注入 `<style data-plugin>`。

## 功能

- 触发按钮：当前模型名 + 当前档位名 + 档位头像。
- 弹出面板：按 provider 分组的模型列表（含加载/失败/空态），下方是可拖动的三档滑块。
- 滑块是原生 `range` 语义 + 完全自绘交互：
  - **连续跟手**：拖动时 thumb、填充、档位名、头像由指针直接驱动，没有往返延迟。原生 value 拖动中是步进取整，无法跟手，所以 pointerdown 直接弃用原生拖动。
  - **弹性越界**：拖出轨道两端后 thumb 带 25% 阻尼跟随，松手弹簧回弹。
  - **松手吸附提交**：松手吸附到最近档位并提交一次真实 Effort ID；半程松手吸附最近档；键盘 ← → 和点击轨道即时提交。
  - **合并去重**：自己提交在途时输入保持可用，新档位 latest-wins 落地后续传，连续快速拖动不丢档位。提交被拒时回弹到已确认档位，错误显示在面板内。
  - **面板稳定**：拖动中不响应外点关闭；面板打开期间按钮标签冻结，轨道不会位移；档位标签与轨道刻度对齐。
- 档位名称按位置映射：`efforts[i]` ↔ 第 i 张图片的文件名；图片不足或档位超过三张时回退到 host 目录提供的原始名称。
- 被寻址的子代理会话（`subagentAddress` 命中）不渲染任何内容，与内置席位契约一致。
- 无障碍：`role="slider"` + 实时 `aria-valuetext`、键盘 ← →、Escape 关闭并还原焦点、外部点击关闭、`prefers-reduced-motion`。

## 档位映射

| 位置（从左到右） | 图片文件 | 显示名 | 提交的 Effort ID |
|---|---|---|---|
| 第 1 档 | `小难梁.png` | 小难梁 | host 目录 `efforts[0]` 的 id |
| 第 2 档 | `梁子.png` | 梁子 | host 目录 `efforts[1]` 的 id |
| 第 3 档 | `梁圣.png` | 梁圣 | host 目录 `efforts[2]` 的 id |

> 显示名与头像按位置取自图片文件名，与真实档位语义无关。顺序由 `build.mjs` 的 `ASSET_ORDER` 固定，重命名图片文件（并同步该列表）即可重命名档位。构建时自动缩图并内嵌。

## 安装

```sh
dsh plugin --profile web add https://github.com/flyemFSB/dsh-reasoning-effort-hdbzq/releases/download/v0.1.0/dsh-reasoning-effort-hdbzq-0.1.0.tgz
```

安装完成后启动：

```sh
dsh --profile web
```

## 卸载

```sh
dsh plugin --profile web remove dsh-reasoning-effort-hdbzq
```

卸载后内置模型选择席位自动恢复。

## 从源码构建与校验

需要 Node ≥ 20 和 npm 安装的 devDependencies：

```sh
npm install
npm run check      # typecheck + 单测 + 完整构建
```

构建脚本（`build.mjs`）分三步：

1. `gen-assets`：读 `src/client/assets/*.png`，双线性缩放到最长边 160px 后以 JPEG(q85) 内嵌为 data URL，档位名取文件名（生成 `src/client/assets.generated.ts`，不入库）。
2. `tsc`：产出 `lib/types` 声明。
3. `esbuild`：node 半区（`lib/index.js`、`lib/invariant.js`）+ 浏览器半区（`lib/client.js`，`__ModuleLoader__` 闭包包 + source map，平台模块 external，CSS Modules 经 lightningcss，含跨插件值导入纯度门禁）。

## 打包内容

`npm run pack` 只包含运行必需的文件（与官方包的 `files` 清单一致，不含源码和测试）：

```
package.json          # 含 dsh.bundle / dsh.client 声明
cordis.patch.yml      # 插入行补丁（dsh plugin add 自动激活 bundle 层）
README.md / LICENSE
lib/index.js          # host 半区（空 apply）
lib/invariant.js      # 不变式伴生
lib/client.js         # 浏览器半区（头像已内嵌，约 50KB）
lib/types/**/*.d.ts   # 类型声明（含 ./client 面）
```

## Model Experience

None, as this plugin is browser-side UI plumbing; nothing here reaches a model request.

#### KV Cache effect

None; this package neither assembles nor sends a provider request.

## 兼容性

- 目标：提供 `conversation.input.model` 席位与 `modelDirectories` 服务的 DeepSeek Harness Web profile（`dsh` ≥ 0.1.0-rc.6）。
- 运行时依赖（peerDependencies）由 Web profile 提供：`react`、`@deepseek-ai/cordis`、`dsh-client-ui-slots`、`dsh-client-ui-primitives`、`dsh-client-runtime`、`dsh-client-locale`、`dsh-client-ui-conversation`、`dsh-client-ui-model-selection`、`dsh-api-remotes`、`dsh-invariants`、`clsx`。
- 档位数量取决于模型目录的 `efforts` 数组：少于 3 档只显示对应数量的档位；多于 3 档时第 4 档起显示 host 原始名称。

## 已知限制

- **固定阴影优先级 -10**：覆盖关系依赖内置席位注册在默认优先级 0。如果官方未来改变内置注册优先级或席位名，最坏情况是插槽冲突显式报错，插件届时需同步调整。
- **档位显示名按位置而非按 id 映射**：同一张图在不同模型的档位语义可能不同（这是设计意图，档位名是纯显示层）。
- **头像为构建期内嵌 data URL**：tarball 不含独立静态资源（官方客户端模块系统只服务 `client.js` 与 source map，无静态资源路由）。
- 头像图片的人物肖像权归原权利人所有，见下方声明。

## 图片权利声明

`src/client/assets/` 下图片中人物的肖像权归其本人/原权利人所有。本仓库（MIT 许可）只覆盖本项目维护者有权许可的代码与材料，不授予任何与肖像、姓名、身份、公开权、商标、版权或其他第三方权利有关的许可。公开传播、商业使用、再分发或制作衍生版本前请自行确认所需授权。

## 许可

[MIT](./LICENSE)。
