// 冒烟测试：用 mock 的 ctx / window 验证宿主端与客户端在加载、激活阶段不抛错。
// 运行：node test/smoke.mjs

import { readFileSync } from 'node:fs';
import { pathToFileURL } from 'node:url';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.dirname(here);

let failed = false;
function fail(label, error) {
  failed = true;
  console.error('[FAIL] ' + label + ': ' + (error && error.stack ? error.stack : error));
}

// ---- 宿主端 ----
try {
  const host = await import(pathToFileURL(path.join(root, 'lib', 'index.js')).href);
  const routes = [];
  const ctx = {
    webServer: { register: (spec) => { routes.push(spec); return () => {}; } },
    effect: (fn) => { const d = fn(); return d; },
    get: () => undefined,
  };
  host.apply(ctx);
  if (routes.length !== 1 || routes[0].path !== '/quick-chat') {
    fail('host route', new Error('expected one /quick-chat route, got ' + JSON.stringify(routes.map((r) => r.path))));
  } else {
    console.log('[host] OK — 注册了路由: ' + routes[0].path);
  }
} catch (e) {
  fail('host', e);
}

// ---- 客户端 ----
try {
  const clientCode = readFileSync(path.join(root, 'lib', 'client.js'), 'utf8');
  const React = {
    createElement: (...args) => ({ t: 'el', args }),
    Fragment: Symbol('Fragment'),
    useState: (v) => [v, () => {}],
    useCallback: (fn) => fn,
    useEffect: () => {},
    useMemo: (fn) => fn(),
    useRef: () => ({}),
  };
  let factory = null;
  globalThis.window = {
    __ModuleLoader__: {
      load: (spec) => { factory = spec.factory; },
    },
  };
  // 间接 eval，让 client.js 里的 window.__ModuleLoader__.load(...) 命中上面的 mock
  (0, eval)(clientCode);

  if (!factory) throw new Error('client factory 未被捕获');
  const plugin = factory((name) => (name === 'react' ? React : {}));
  console.log('[client] OK — factory inject: ' + JSON.stringify(plugin.inject));

  const ctx = {
    slots: {
      entries: () => [],
      subscribe: () => () => {},
      inject: (name, fn) => { fn(); },
    },
    sessions: { list: { getSnapshot: () => ({ current: undefined, ids: [], byId: {} }) } },
  };
  const cleanup = plugin.apply(ctx);
  if (typeof cleanup !== 'function') throw new Error('apply 未返回清理函数');
  cleanup();
  console.log('[client] OK — apply + cleanup 正常');
} catch (e) {
  fail('client', e);
}

if (failed) {
  console.log('\n冒烟测试失败');
  process.exit(1);
} else {
  console.log('\n冒烟测试通过');
}
