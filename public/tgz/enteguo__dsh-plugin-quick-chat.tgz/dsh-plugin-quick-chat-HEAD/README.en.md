<div align="center">

# Quick Chat for DSH

**A lightweight chat window in the sidebar: ask anything instantly, optionally carrying the current session's context.**

[简体中文](README.md) · English

[![DSH](https://img.shields.io/badge/DSH-0.1.2--rc.1-23272f?style=flat-square)](https://github.com/deepseek-ai/deepseek-harness)
[![License](https://img.shields.io/badge/license-MIT-f0b429?style=flat-square)](LICENSE)

</div>

Adds a lightweight "Quick Chat" entry to DeepSeek Harness: open a small window to ask quick questions without interrupting the main session, optionally carrying the current session's full history so the quick chat can keep the topic going.

## Features

- **Sidebar entry**: right below the "New Session" button, styled to match it.
- **Bottom-right chat window**: a rounded panel with streaming output.
- **Model & reasoning effort**: switch model and reasoning strength via the gear button, defaulting to `deepseek-v4-flash · low`.
- **Context (optional)**: when starting a new chat, optionally carry the current session's full history (off by default).
- **History**: every quick chat is kept; continue, rename, or delete, and it survives a restart.

## Install

Install from a local directory:

```bash
dsh plugin --profile desktop add ./dsh-plugin-quick-chat
```

Or package as a tarball and install:

```bash
dsh plugin --profile desktop add ./dsh-plugin-quick-chat-0.1.0.tgz
```

Restart DSH after installing so both the host and client halves reload.

## Usage

1. Click the "快速会话" (Quick Chat) button below "New Session" in the sidebar to open the bottom-right window.
2. Use the gear button to pick a model and reasoning strength; use the context button to decide whether to carry the current session's context (off by default).
3. Type a message and press Enter to send; the reply streams in.
4. Click the "☰" button in the window to browse history — click an item to continue, or use "rename / delete" to manage.

## Data storage

All quick chats are stored in `~/.dsh/quick-chat/store.json`; they never appear in the main session list.

## Compatibility

Tested against DSH `0.1.2-rc.1`. Text-only chat — no tools or subagents.

## License

[MIT](LICENSE)
