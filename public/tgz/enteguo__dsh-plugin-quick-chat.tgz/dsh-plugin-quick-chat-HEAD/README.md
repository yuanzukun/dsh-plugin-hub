<div align="center">

# 快速会话（Quick Chat）for DSH

**侧边栏里的即时对话窗口：随时快速提问，可选携带当前主会话的上下文。**

[English](README.en.md) · 简体中文

[![DSH](https://img.shields.io/badge/DSH-0.1.2--rc.1-23272f?style=flat-square)](https://github.com/deepseek-ai/deepseek-harness)
[![License](https://img.shields.io/badge/license-MIT-f0b429?style=flat-square)](LICENSE)

</div>

为 DeepSeek Harness 添加一个轻量的「快速会话」入口：不打断主会话，随时开一个小窗快速提问；可选带上当前主会话的全文，让快速对话也能接着当前话题往下聊。

## 功能

- **侧边栏入口**：在「新会话」按钮正下方，样式与新会话按钮一致。
- **右下角对话窗口**：圆润的小窗，回答流式输出、边生成边显示。
- **模型与思考强度**：窗口内用齿轮按钮切换模型和思考强度，默认 `deepseek-v4-flash · low`。
- **上下文（可选）**：开新对话时可选择「携带当前主会话上下文」，默认关闭；开启后把主会话全文作为背景。
- **历史记录**：所有快速对话都保留，可继续、重命名、删除；重启后仍在。

## 安装

从本地目录安装：

```bash
dsh plugin --profile desktop add ./dsh-plugin-quick-chat
```

或打包成 tarball 后安装：

```bash
dsh plugin --profile desktop add ./dsh-plugin-quick-chat-0.1.0.tgz
```

安装后重启 DSH，让宿主端和客户端代码一起重新加载。

## 使用

1. 点击侧边栏「新会话」下方的「快速会话」按钮，打开右下角窗口。
2. 点击齿轮图标选择模型和思考强度；点击上下文按钮决定是否携带主会话上下文（默认不带）。
3. 在输入框输入消息，按 Enter 发送，回答逐字流式显示。
4. 点击窗口右上角的「☰」查看历史对话：点击某条继续，或用「重命名 / 删除」管理。

## 数据存储

所有快速对话保存在 `~/.dsh/quick-chat/store.json`，不会进入主会话列表。

## 兼容性

已针对 DSH `0.1.2-rc.1` 验证。纯文本对话，不调用工具或子代理。

## License

[MIT](LICENSE)
