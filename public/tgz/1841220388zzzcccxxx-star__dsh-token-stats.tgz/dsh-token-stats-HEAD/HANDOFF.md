<!-- handoff:auto:start -->
# 项目交接

## 项目概况

- 项目名称：dsh-token-stats — DeepSeek Harness Token 用量统计插件
- 用途：统计 DSH 各模型/日期/会话的 token 用量与费用（USD/CNY），设置面板 → 📊 Token 统计 页签展示；DSH 外部插件，随启动自动加载
- 技术栈：Node.js ESM + Cordis 插件（服务端 index.js / 客户端 client.js）；前端零第三方依赖（原生 SVG/React 运行时）；PowerShell 部署脚本
- 主要入口：index.js（服务端：事件采集/回溯/聚合//token-stats/api）；client.js（浏览器：settings.section 页签）；cordis.patch.yml（bundle 挂载点）；sync-deploy.ps1（部署）

## 当前状态

- 状态：功能可运行；本轮修复「DSH 0.2.0-rc.1 升级后插件失效」——按官方 0.2.x 插件契约补齐兼容声明并用 link: 直挂重新装入 web profile，组合层验证通过
- 最后更新：2026-09-29T13:05:00+08:00

## 本次变更

失效根因：2026-09-25 升级 DSH 0.2.0-rc.1 时 web profile 的 package.json 被清空社区插件（备份 package.json.bak-pre-upgrade-020rc1），git-graph 重装了而 token-stats 没有 → 插件彻底不在 profile 里。修复：① package.json 补官方兼容声明（`engines.dsh` 与 `peerDependencies["@deepseek-ai/dsh"]` 均 `>=0.1.0-rc.6 <0.3.0`、`dsh.manifestVersion: 1`、repository、dsh-plugin keyword），版本 1.0.0→1.1.0；API 核对：sessionQuery/tokenMeter.estimateMessage/session/event/llm/stream/webServer.register/settings.section 槽位在 0.2.0-rc.1 全部存在（官方 cordis-plugin-development skill 与安装包源码逐一验证），代码零改动。② 装回 profile：依赖改 `link:D:/桌面/Agent操作文件夹/token计数插件_deepseek harness`（源码直挂，以后改完重启即生效，不再需要 sync-deploy.ps1）+ bundles 加 `dsh-token-stats` + `pnpm install`。③ `dsh --profile web --dump-config` 确认补丁行 `- id: token-stats / name: dsh-token-stats` 进入组合且无兼容告警。

## 验证结果

node --check 两文件通过；node test-client-refs.js 14 项全过；node test-plugin.js 35 项全过；profile pnpm install 成功（node_modules/dsh-token-stats → 源码目录 symlink）；dsh --profile web --dump-config 组合通过无告警。待用户重启 DSH web 验收页面。

## 待办与阻塞

用户需重启 DSH web 验收；README 截图 docs/demo.png 仍是旧版 UI（旧布局/分栏版），建议重启后重截。

## 常用命令

改源码后：直接重启 DSH web（link: 直挂，无需部署步骤）；node test-plugin.js（服务端测试）；node test-client-refs.js（前端引用/渲染检查）；node --check index.js / client.js；dsh --profile web --dump-config（不启动验证组合）

## 交接记录

<!-- handoff:history:start -->
- [2026-08-22T19:35:55+08:00] 目标：修复 Token 统计页白屏崩溃并做回归验证；结果：已完成：修复 t 未定义引用，加错误边界，新增前端引用测试，已部署并推送（commit 6f5df43）；下一步：用户重启 DSH web 验收；后续可选：费用卡片+预算条 / 时间范围快捷键 / ECharts 交互图 / 偏好记忆；README 截图更新
- [2026-09-22T10:54:00+08:00] 目标：优化 Token 统计页（列表长且丑 / 左右分栏乱 / 太紧凑）；结果：已完成：单列全宽布局重构（删 .tkst-split 分栏 + 重复的 tkst-bars 模型横条列表）、工具栏两行化、间距字号圆角全面放大、会话表标题化（sessTitleMap join op=sessions）、三分区表头计数 meta、清死 CSS；14+35 项测试全过；下一步：用户重启 DSH web 验收；后续可选：README demo.png 重截 / 表格行数偏好 / 模型表内嵌占比小条
- [2026-09-29T13:05:00+08:00] 目标：修复 DSH 0.2.0-rc.1 升级后插件失效（查官网/社区要求）；结果：已完成：根因=升级时 profile 被清空社区插件、本插件未重装；按官方契约补 package.json 兼容声明（engines.dsh + peerDependencies @deepseek-ai/dsh >=0.1.0-rc.6 <0.3.0、manifestVersion 1）并逐 API 核对 0.2.0-rc.1 兼容（代码零改动）；以 link: 直挂重装 web profile（依赖+bundles+pnpm install），dump-config 组合验证通过，14+35 项测试全过；下一步：用户重启 DSH web 验收；备注：link: 直挂后 sync-deploy.ps1 退役
<!-- handoff:history:end -->
<!-- handoff:auto:end -->

## 人工补充

### 版本与修改历史（git 提交时间序）

| 版本/提交 | 内容 |
|---|---|
| `c7a60c2` Initial commit | 初版：会话日志采集、历史回溯、/token-stats/api、设置页统计页签、CSV/JSON 导出 |
| `b53474c` | 开源准备：README 中英双语、MIT LICENSE、.gitignore、docs/demo.png 界面截图 |
| `9ce8088` Perf | 性能优化：sessions 批量读标题+缓存（1.7s→12ms）、summary 单次遍历、单价/费用记忆化、backfill 并发；前端 stale-while-revalidate 缓存、60s 自动刷新、手动刷新按钮、「最后更新」时间戳 |
| `451cc01` UI | 双列网格、会话搜索框、表格列头排序、卡片+模型表环比、三层钻取（模型→会话→每日明细）；服务端 summary.prev + models.prevTotal |
| `3a406bd` UI | 趋势折线图→可悬停柱状图 |
| `d34c78b` UI | 细柱+圆角+网格线+按模型堆叠柱（series.models）+修复设置页横向溢出（响应式 grid、tablewrap、会话名截断） |
| `488217e` UI | 堆叠柱压密（柱宽85%）、图表加高 230px、近 30 天、鲜亮 8 色板、顶部汇总条、表格 20 行、tooltip 加调用+费用 |
| `6f5df43` Fix | **修复白屏崩溃**（见历史问题）+ StatsErrorBoundary 错误边界 + test-client-refs.js |
| 工作区打磨（提交于本轮） | UI 美术升级：卡片 accent/spark/delta 芯片、分段粒度控件、渐变堆叠柱+总量线、费用环图、模型色贯穿、sticky 表、骨架屏、StatsView page 数组组装 |
| 本轮（提交于本轮） | UI 布局重构：单列全宽（删左右分栏 tkst-split + 重复模型横条列表 tkst-bars）、工具栏两行化、间距/字号/圆角全面放大、会话表标题化（sessTitleMap）、分区表头计数、清死 CSS |

### 升级 / 部署方法

1. **当前形态（2026-09-29 起）**：web profile 以 `link:` 直挂本仓库源码目录，改完源码**直接重启 DSH web 即生效**，无需任何部署步骤。`sync-deploy.ps1` 仅在用 `file:` 安装形态时才需要（link: 下已退役）。
2. **重装进 profile 的方法**（profile 被升级清空或换机器时）：profile 的 `package.json` 里 dependencies 加 `"dsh-token-stats": "link:D:/桌面/Agent操作文件夹/token计数插件_deepseek harness"`、`dsh.profile.bundles` 加 `"dsh-token-stats"`，然后在 `C:\Users\18412\.dsh\profiles\web` 跑 `pnpm install`。注意 `dsh plugin --profile web add` 只转发 pnpm、**不会**自动登记 bundles。
3. **兼容声明是硬要求**：DSH ≥0.2.0 在安装/启动 preflight 按 `peerDependencies["@deepseek-ai/dsh"]` 校验运行时版本，不满足会拒绝；改范围前必须重新实测。官方插件开发文档内置在产品里：`@deepseek-ai/dsh-agent-preset/skills/cordis-plugin-development/`（含模板与 references）。
4. 云端：改完 `git add -A && git commit && git push origin main`（推送需临时 token 认证，token 用完在 GitHub 删除）。
5. **DSH 升级注意**：0.1.7-rc.2 → 0.2.0-rc.1 升级时 profile 的社区插件会被整体清空（git-graph 也是此时丢的、后来单独重装）；每次升级后要检查 profile package.json 里外部插件是否还在。

### 历史问题与踩坑记录

- **白屏崩溃（已修，commit 6f5df43）**：`TrendChart` 是模块级函数，作用域内没有 `t` 变量（`t=T()` 只在 `StatsView` 内），tooltip 误用 `t.calls` → `ReferenceError` → React 整树卸载 → 页面全白。教训：组件外函数取词必须用 `T()`，且这类"变量未定义" `node --check` 查不出，需引用级伪执行测试（test-client-refs.js）。
- **pnpm 跳过副本刷新**：`file:` 依赖 package.json 未变时 `pnpm install` 不更新 node_modules 副本，改源码后必须手动 Copy-Item（sync-deploy.ps1 已内置）。
- **PowerShell 编码**：① `.ps1` 中文在 GBK 解析环境会乱码/报语法错 → 脚本需 UTF-8 BOM；② PowerShell→Python 传中文 argv 会被破坏 → 大段中文 JSON 数据需写临时 UTF-8 文件由 Python 侧读取；③ PowerShell `Invoke-RestMethod` 发中文 JSON body 会变 `?????` → 用 UTF-8 字节数组作 body。
- **GitHub 描述中文损坏**：第一次 PATCH description 中文变问号，改用 UTF-8 字节 body 后正常。
- **旧代码残留**：线上实例重启前一直加载旧代码，改完必须重启才能验证新效果；判断新代码是否生效可用 API 耗时对比（如 sessions ~11ms 为新版，~1500ms 为旧版）。
- **前端无法直接单测**：client.js 是 `window.__ModuleLoader__.load` 包裹，node 直接跑不了；test-client-refs.js 用 stub 环境 + 真实数据伪执行覆盖渲染路径。

### 已知待办（非阻塞）

- README.md 截图（docs/demo.png）还是旧版 UI，重启后建议重截一张替换。
- 后续可选优化（未做）：费用卡片+月度预算进度条 / 时间范围快捷按钮（近7天/30天）/ ECharts 交互图 / 用户偏好记忆（granularity/排序存 localStorage）。
