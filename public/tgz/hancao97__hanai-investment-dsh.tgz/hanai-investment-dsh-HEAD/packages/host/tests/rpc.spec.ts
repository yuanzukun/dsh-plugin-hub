import { describe, expect, it } from 'vitest'
import { parseHanaiRequest } from '../src/rpc.ts'

describe('Hanai RPC request validation', () => {
  it('accepts namespaced backup sector nodes without accepting arbitrary query or URL input', () => {
    for (const sectorCode of ['BK0475', 'SINA:new_blhy', 'SINA:gn_BCdc']) {
      expect(parseHanaiRequest('sector.stocks', { sectorCode })).toEqual({ sectorCode })
    }
    for (const sectorCode of ['SINA:hs_a', 'SINA:gn_x&page=2', 'https://example.com', 'SINA:../new_blhy']) {
      expect(() => parseHanaiRequest('sector.stocks', { sectorCode })).toThrow()
    }
  })
  it('accepts only conventional persisted themes', () => {
    expect(parseHanaiRequest('theme.set', { theme: 'light' })).toEqual({ theme: 'light' })
    expect(parseHanaiRequest('theme.set', { theme: 'dark' })).toEqual({ theme: 'dark' })
    expect(() => parseHanaiRequest('theme.set', { theme: 'ocean' })).toThrow()
    expect(() => parseHanaiRequest('theme.set', { theme: 'jade' })).toThrow()
  })

  it('validates independently refreshable stock surfaces and cache scopes strictly', () => {
    expect(parseHanaiRequest('security.quote', { secId: '1.600519' })).toEqual({ secId: '1.600519' })
    expect(parseHanaiRequest('security.trend', { secId: '0.000001' })).toEqual({ secId: '0.000001' })
    expect(parseHanaiRequest('security.kline', {
      secId: '1.600519', period: 'monthly',
    })).toEqual({ secId: '1.600519', period: 'monthly' })
    expect(parseHanaiRequest('security.kline', {
      secId: '1.600519', period: 'daily', before: '2018-06-08',
    })).toEqual({ secId: '1.600519', period: 'daily', before: '2018-06-08' })
    expect(parseHanaiRequest('security.valuation', { secId: '1.600519' })).toEqual({ secId: '1.600519' })
    expect(parseHanaiRequest('watch.valuations', { groupId: 'default' })).toEqual({ groupId: 'default' })
    expect(parseHanaiRequest('judgement.remove', { id: 'judgement-1' })).toEqual({ id: 'judgement-1' })
    expect(parseHanaiRequest('expert-chat.create', {
      masterId: 'sun-yuchen-perspective',
      openingMessage: ' 存储为什么会短缺？ ',
    })).toEqual({ masterId: 'sun-yuchen-perspective', openingMessage: '存储为什么会短缺？' })
    expect(parseHanaiRequest('expert-chat.get', { id: 'chat-1' })).toEqual({ id: 'chat-1' })
    expect(parseHanaiRequest('cache.clear', { scope: 'valuation' })).toEqual({ scope: 'valuation' })
    expect(parseHanaiRequest('storage.openDataRoot', {})).toEqual({})

    expect(() => parseHanaiRequest('security.kline', {
      secId: '1.600519', period: '15m',
    })).toThrow()
    expect(() => parseHanaiRequest('security.kline', {
      secId: '1.600519', period: 'daily', before: '20180608',
    })).toThrow()
    expect(() => parseHanaiRequest('cache.clear', { scope: 'all' })).toThrow()
    expect(() => parseHanaiRequest('storage.openDataRoot', { path: '/tmp' })).toThrow()
    expect(() => parseHanaiRequest('security.trend', {
      secId: '1.600519', refreshAll: true,
    })).toThrow()
    expect(() => parseHanaiRequest('watch.valuations', { groupId: '../default' })).toThrow()
    expect(() => parseHanaiRequest('judgement.remove', { id: '../judgement-1' })).toThrow()
    expect(() => parseHanaiRequest('expert-chat.create', {
      masterId: 'sun-yuchen-perspective', openingMessage: '   ',
    })).toThrow()
    expect(() => parseHanaiRequest('expert-chat.create', {
      masterId: 'sun-yuchen-perspective', openingMessage: '问题', stockId: '1.600519',
    })).toThrow()
    expect(() => parseHanaiRequest('expert-chat.remove', { id: '../chat-1' })).toThrow()
  })

  it('validates the DSH default-model bridge strictly and normalizes text', () => {
    expect(parseHanaiRequest('model.default.get', {})).toEqual({})
    expect(parseHanaiRequest('model.default.set', {
      provider: ' deepseek-official ',
      model: ' deepseek-v4-pro ',
      reasoningEffort: ' high ',
    })).toEqual({
      provider: 'deepseek-official',
      model: 'deepseek-v4-pro',
      reasoningEffort: 'high',
    })

    expect(() => parseHanaiRequest('model.default.get', { ns: 'agent-default-model' })).toThrow()
    expect(() => parseHanaiRequest('model.default.set', {
      provider: '', model: 'deepseek-v4-pro',
    })).toThrow()
    expect(() => parseHanaiRequest('model.default.set', {
      provider: 'deepseek-official', model: 'deepseek-v4-pro', revision: 1,
    })).toThrow()
  })
})
