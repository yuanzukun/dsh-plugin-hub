# 变更记录

## 0.4.1 — 2026-10-21

- Retry transient Windows state-file locks with a bounded backoff, retaining atomic replacement and surfacing persistent failures.

- Remove orphaned node injection overrides after physical deletion, undoing newly added nodes, and removing bases; preserve policies for soft-deleted nodes and prune stale IDs before allocating new nodes.
- Tutorial v19 documents mixed injection limits, scrolling, font sizes and title-only previews.

- Mark genuinely overflowing card bodies with a visible long-note/scroll hint and an Edit action. Use a clearer thin scrollbar; update hints after content/size changes and hide them in title-only mode.

- Bound automatic canvas cards to 320px with full body scrolling so one long note cannot push the next layer several screens away. Keep explicit node heights, header/byline visibility, and contain scrolling within long bodies.

- 新增节点级分层注入：库默认方式 + 节点全文/按需覆盖；编辑器及右键菜单即时保存，正文独立存储。

- Resolve restored, nonresident sessions from a read-only persistence header before panel reads/writes. Close the header handle without replaying history or activating an agent. Resident sessions keep their existing fast path.
- Background activity reads and diary replies no longer overwrite the canvas save banner on failure; explicit save errors and diary-local errors remain visible.

- Increase canvas body text to 15px, regular titles to 16px and root titles to 17px, with matching layout height estimates.

- Use an explicit CJK sans-serif stack for canvas text and a CJK-aware code font fallback. Render canvas zoom with layout zoom instead of scaling a painted text layer; preserve existing camera and pointer coordinates.

- Make canvas node titles and bodies larger and increase body/date contrast. At reduced zoom, hover or focus a node for a screen-sized text preview; the canvas still keeps compact overview cards.
- Cache layout, parent-edge routes and Markdown separately from camera movement. Reuse a parent-to-children index and subtree widths, and reject distant curve obstacles by their bounding boxes before precise tests.
- Preserve full-detail measurements across overview zoom. Recompute when node content, dimensions, placement or layout changes; scroll a constrained node body without zooming the canvas.
- Add a seeded collision-equivalence regression test. No model calls, knowledge storage migration or new image-reading behavior are introduced by these UI changes.

- Reply to a diary directly from its sidebar page. The reply and the addressed diary excerpt are admitted as a user message to the current Session; the agent responds in the conversation. Existing composer drafts are untouched.
- Keep per-page drafts while browsing and persist reply records separately as encrypted data. Confirmed messages are marked as delivered; failed or uncertain delivery can be retried with the same request id and content.
- Session ownership is checked before reading or sending replies. Concurrent replies are serialized, the original diary is not rewritten, and unreadable reply records are preserved.
- Tutorial v18 documents diary replies. Existing knowledge tools are unchanged.

## 0.4.0 — 2026-10-18

- Diary bases now open as a notebook: month catalog, readable pages, earlier/newer navigation, collapsed recall hints, and edit-history access. Narrow panels use a catalog button; the original knowledge canvas remains available.
- Send or drag a diary page into the current conversation using the existing attachment workflow. No diary content or storage format is migrated.

- Add per-workspace attachment reading policy in DSH settings: on-demand (default) or required.
- `knowledge_read` supports individual attachment selection and character-based text pagination; required mode returns supported text and image blocks with explicit limits and delivery warnings.
- `knowledge_show_images` remains available for on-demand image reading. Attachment preferences are independent of base selection, layout, and prompt injection.
- Update tutorial and manual to explain token costs, unsupported formats and manual drag behavior.

## 0.3.0

- A node can carry pictures and documents. Paste, drop, or pick them in the editor; a picture is drawn in the card, anything else becomes a chip you open in a new tab.
- Attachments are content-addressed under `.dsh-knowledge/assets/`, so the same file attached twice is stored once. Their own names stay in the note; only the path is a hash.
- Reading a node brings its attachments with it: text under 8 KB (and Office text, extracted in place) inline, everything
  else as an absolute path.
- `knowledge_show_images` hands a node's pictures to the model as images, so a screenshot in a note can be looked at
  rather than guessed about.
- A failed attachment is a red line under the editor, with the reason. It is never written into the note.
- A node handed to the conversation carries its attachments as session files.


Tools in this release: knowledge_read, knowledge_create_base, knowledge_write_node, knowledge_link,
knowledge_unlink, knowledge_remove_node, knowledge_select, knowledge_remove_base, knowledge_show_images.

## 0.2.5 — 2026-10-17

**两个设置自己跑掉的问题，以及教程补上今晚新增的两个动作。**

```
记录调用过程会自己关掉   拖动库的顺序、或改某个库的索引/全文，会把 selection.json 整份重写，
                        而那两个写者没有带上 live —— 下次重启就看到它又是关的
                        ★ 现在 writeOrder / writeInject 也把 live（和 diary）带过来了
别的 workspace 设置不了   设置页是跨工作区的，但写操作从会话推工作区；你在 A 工作区，
                        就改不了 B 工作区的「记录调用过程」（报 a Session id is required）
                        ★ 写操作现在可以带 workspace 路径，且只接受进程已知的工作区
教程 v13                 补了"不想要这条线了"，以及 n22「改错了怎么撤回」
打包                     CHANGELOG.md 与 README.zh.md 之前没有进 files[]，npm 上一直缺这两份
```

## 0.2.4 — 2026-10-17

**撤销、断线，以及一次该有的收尾。**

```
knowledge_unlink    能画线，也能删线；节点不动，只去掉那条虚线
撤销节点改动        右键菜单和节点编辑器各一个入口，按【单个节点】撤回未看过的改动
撤销改动 N          面板顶部最右，两次点击确认（第一次变红，4 秒复位），整库撤回
   ★ 边界：新增的删掉、改过的回到上一版（正文存在 history 里）、标记移除的恢复
   ★ 撤回"删除"时，那个节点当初的子节点与连线回不来（它们当时已经被改掉了）
右键菜单位置        换成屏幕坐标定位，画布缩放 / 平移不会再让它跑偏
activity.log        三个字段统一用 " / " 分隔，空字段写 "-"，列不再错位
恢复节点            写进被标记移除的节点时返回 "Restored …"，不再和普通修改一样
教程 v13            补了"不想要这条线了"，以及 n22「改错了怎么撤回」
```

## 0.2.3 — 2026-10-17

**文档和教程补齐。这一版没有改行为。**

0.2.2 是边发边补的，结果 README 还停在 0.1.0 的篇幅，教程也缺了两节。这次先把它们写完，再改版本号。

```
README      76 行 → 96/148 行（英文/中文）：面板手势表、六个工具、按工作区设置、
            日记模式、五条"它不做什么"、文件布局、第一次用、常见问题
            顶部加了语言切换；旧的三节薄内容与新的合并
教程        n20 写一篇要几次调用（建库后立刻可用、write_node 返回里带 id）
            n21 日记模式（按会话、不按天、不用宣告、只给约定不给口吻）
            老工作区的教程按【内容】认，不再按文件名
检查        check-public.mjs 进 check:all：本机路径、私人邮箱、私人节点 id、包名
```

**什么时候该想起它**：你要发版时 ✅ —— **先确认文档和教程写完、检查全绿，再改版本号** ✅。

## 0.2.2 — 2026-10-16

**教程写细了，而且是九章**

原来那六条更像目录 —— 它说"长按拖 → 挪到别的父节点下"，但没写到底按多久、
拖到哪儿松手；它提了右键看修改历史，但没写绿色和红色各是什么。现在按操作拆成九章:

```
n1 这个知识库是什么           两个读者各自看到什么
n2 面板：先认位置             顶上那排、每个库一行、画布工具栏，逐个说
n3 节点：每一步怎么做         新建 / 改内容 / 挪位置 / 改父子 / 颜色 / 大小 / 已读 / 废弃
n7 关联线：怎么画，注释怎么写  点它、写它、改它
n8 修改历史：怎么看           十版、绿红各是什么、展开
n9 找到某个节点               搜索框 / 定位到… / 直接说 id
n4 模型该往里写什么           写什么、不写什么、触发行、一条只写一件事
n5 示例：一条写对了的笔记
n6 这些库是示例，删掉就好      以及它会跟着插件更新
```

**已有的教程会自动补上新增的三章** —— 但只在整份教程没被人改过的时候。
如果你改过其中任意一条，它只更新没动过的正文，不会把我们的章节塞进你写的库里。

**大纲里能看出教程换过版本了**

标题那一行多一段 `内置教程 v3，<时间> 更新（正文随插件变，别凭印象）`。
以前看不出：升级只换正文，节点数和时间戳都是特意保留的（不然颜色和位置会失效），
所以一个读过旧教程的会话再看到完全一样的标题，会以为自己没漏掉什么。

**关联线上的注释现在可以改了**

之前 `knowledge_link` 对已经存在的两个节点只会回「already linked」，而这个工具没有删除 ——
所以想改一句注释，唯一的办法是打开 JSON 手改。注释恰恰是最需要改的东西：它写的是"什么时候该顺着
这条线走"，而理解变深之后这句话常常要重写。

现在同一对再调一次就是改注释，线本身不动。同样的措辞再说一遍会明确回「没有变化」，
而不是假装写成功了。空注释仍然拒绝，改的时候也一样 —— 一条没有注释的线，别人拿它做不了任何事。

## 0.2.1 — 2026-10-16

**教程库会跟着插件一起更新**

之前那份「怎么用这个知识库」只在工作区第一次使用时生成一次，之后再也不变。所以插件加了功能，
老工作区的教程还停在它出生那天 —— 而大纲是模型读的东西，**它会一直照着旧说明理解一个已经不是那样的面板**。

现在每个种子节点会记住「我们写的那段正文的指纹」。启动时如果那份教程还在、而且是旧版本：

- **没被人改过的节点** → 换成当前版本的正文
- **被人改过的节点** → 一个字都不动
- 节点 id 和时间戳从不重写，所以颜色、位置、宽高（都存在 `layout.json` 里、按 id 索引）继续有效
- 教程库被你删掉的情况不变：**删了就不会自己回来**

**修改历史：卡片上多了一个「展开 ⤢」**

右键节点出来的卡片是「原地看一眼」，点它的展开按钮，同一份历史会铺满整个面板 ——
整块的宽和高，十版加上长正文都放得下。返回之后画布停在你原来看的位置。

**教程补上了最近几版新增的东西**：右键看修改历史、点关联线写注释、按 id 定位，
以及「模型给两个节点连关联时必须写一行注释」这条规矩（那行注释会进别的会话的大纲，
而一条只写着"这两个有关"的线，别人拿它做不了任何事）。

## 0.2.0 — 2026-10-16

**修改历史：从只有日期，变成有内容**

以前一条历史只记「什么时候被改的、哪个会话改的」—— 而一个节点只有一个 `body`，写入就是覆盖，
**旧正文从来没被存下来过**。所以「上次写的是什么」不是没显示，是做不到。

现在写入时会把**即将被覆盖的那一版**整个存进历史（标题 + 正文 + 作者 + 那一版自己的时间）。
右键节点 → 修改历史，卡片里是：

```
当前         <时间>
             <标题>
             <正文，相对上一版【新增的行标绿】>

上一个版本    <时间>  <谁>
             <标题>
             <正文，之后【被删掉的行标红】>
```

两侧各承担一半改动，拼起来就是完整的一次修改。长正文可展开；
被折掉的部分里若有改动，按钮会写明还有几处。
空行的增删是真实差异但不标色 —— 一个指着空白行的红标，花了注意力却什么也换不来。

每个节点最多留 10 版。

**关联线带注释**

橙线的注释现在是**模型必填**的：那条注释会进别的会话的大纲，
而一条只有 id 对的关联（`n1 <-> n2`）说了「这两个有关」，没说「什么时候该顺着它走」——
不足以让人做任何决定。

- `knowledge_link` 不写注释会被拒绝，并说明为什么
- **用户不受这条约束**：自己画的线，注释可选。点那条线就能写/改/清空
- 注释进大纲；老的无注释链接会被标出来（和「无触发器」同一套思路）
- `knowledge_read` 加 `node` 参数：**只读一个节点**，附上它的父、子、关联各一行摘要 ——
  顺着关联走从此是一小步，而不是读整个库

**画布**

- **缩放下限 40% → 12%**。原来的下限是按「阅读」定的，而缩小的目的是看一个大库的形状、好整理；
  33 个节点的库大概要 15% 才看得全。顺带：「适应」按钮以前被同一个下限卡着
- 小于 55% 时节点只画标题（那个尺度下正文本来就读不了），几何也跟着用一行的高度，
  所以**连线不会断在半空**
- 低缩放时连线对比度提高，线宽按屏幕像素算（`vector-effect: non-scaling-stroke`）——
  以前 31% 时线是 0.34px 宽、42% 不透明，抗锯齿把它抹成一片模糊，
  看起来像散落的卡片而不是关联图
- **平移按动画帧节流**：以前每个 `pointermove` 一次 `setState`，高回报率鼠标一秒 100+ 次

**性能**

- 节点的 id 查找从每帧 O(n) 次数组扫描换成一次 Map（布局与几何两处共用）
- 边路由的记忆键补上了注释字段：键漏一个输入，热区就会带着旧注释打开编辑器

**开发**

- 面板多了一条诊断通道（路由的 `diag` 动作）：把渲染耗时写回宿主日志。
  加它是因为「大库就卡」这件事我猜错了七次，每一次都是从代码里论证的 ——
  而那唯一能回答它的地方是浏览器

## 0.1.0 — 2026-10-16

第一个公开版本。

**知识库**

- 一个库 = 一棵树，存在 `<工作区>/.dsh-knowledge/<库名>.json`
- 节点：标题 + 正文（markdown），宽度按内容自适应，也能手动调
- 连线：右键节点拖到另一个节点
- 修改标记：模型改过的节点带 `[新增]` / `[修改]` / `[已废弃]`，审完可清
- 节点宽高、位置、颜色存在 `layout.json`，跟着仓库走

**面板**

- 右侧画布，可平移缩放；节点可拖动，位置会记住
- 搜索；按节点 id 定位（对话里提到 `n3`，能直接在画布上找到）
- 库的开关分两层：工作区默认，和「仅本会话」
- 切回某个会话时，面板停在这个会话**实际生效**的那一档

**给模型**

- 八个工具：`knowledge_read` / `create_base` / `write_node` / `link` / `unlink` / `remove_node` / `select` / `remove_base`
- 注入有两种：默认只给大纲（标题 + 触发行），每个库可以单独选**整库全文**
- 关掉一个库 = 模型不能读它也不能写它（不是"只是不进提示词"）
- 记一份 `activity.log`，`report-kb-use.mjs` 能读成"哪个会话用了几次"

**改宿主文件时会附一条提醒**

模型调用 `write` / `edit` 动 `lib/` 或 `index.js` 时，插件会把相关节点附在**那次工具调用的返回**里
（`tools/post-execute` 的 `additionalContexts`）。改 `client.js` 时是另一组节点。

实测结论：**送达已验证；对"该不该重启"这类问题，与系统提示里的大纲相比没有可测量的增量。**
所以它留着，但不声称它提升了遵守率。

想关掉它：在 `<工作区>/.dsh-knowledge/` 下放一个空文件 `.no-action-notes`，删掉即恢复。
