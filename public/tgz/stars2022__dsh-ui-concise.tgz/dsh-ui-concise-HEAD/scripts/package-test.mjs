import assert from 'node:assert/strict'
import { readFileSync } from 'node:fs'
import { dirname, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..')
const manifest = JSON.parse(readFileSync(resolve(root, 'package.json'), 'utf8'))
const bundlePatch = readFileSync(resolve(root, 'cordis.patch.yml'), 'utf8')
const clientBundle = readFileSync(resolve(root, 'lib/client.js'), 'utf8')
const invariantBundle = readFileSync(resolve(root, 'lib/invariant.js'), 'utf8')

assert.deepEqual(manifest.dsh?.bundle, { patch: './cordis.patch.yml' })
assert.equal(manifest.dsh?.client?.platform, 'web')
assert.equal(manifest.exports['./client'], './lib/client.js')
assert.equal(manifest.bin, undefined)
assert.match(bundlePatch, /id: ui-conversation\n  disabled: true/)
assert.match(bundlePatch, /name: dsh-ui-concise/)
assert.match(clientBundle, /id: "dsh-ui-concise"/)
assert.doesNotMatch(clientBundle, /id: "@deepseek-ai\/dsh-client-ui-conversation"/)
assert.match(invariantBundle, /PACKAGE_NAME = "dsh-ui-concise"/)

process.stdout.write('npm package checks passed\n')
