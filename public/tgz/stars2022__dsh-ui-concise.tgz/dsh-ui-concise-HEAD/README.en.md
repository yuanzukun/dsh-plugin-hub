# dsh-ui-concise

English | [中文](README.md)

A Codex/macOS-style concise conversation mode for the DeepSeek Harness WebUI.

## Installation

Run from the DeepSeek Harness directory:

```bash
dsh plugin --profile web add \
  https://github.com/stars2022/dsh-ui-concise/releases/download/v0.1.3/dsh-ui-concise-0.1.3.tgz
dsh web
```

To uninstall:

```bash
dsh plugin --profile web remove dsh-ui-concise
dsh web
```

## Features

- Adds Concise mode and Hide reasoning content options to Settings.
- Shows a timer for each Turn: live while running, collapsed after completion, and expanded after interruption or failure.
- Merges consecutive Tool calls into one activity row with live labels such as Reading files and Editing files, followed by a completion summary.
- Expanding an activity row shows every original Tool detail and Tool card.
- Keeps the final Assistant answer outside the outer disclosure with the normal Markdown layout and message actions.
- With Hide reasoning content enabled, displays Thinking while reasoning is active and hides the reasoning text after completion.
- Includes Chinese and English UI text.

## License

[MIT](LICENSE)
