# dsh-ui-concise

[English](README.en.md) | 中文

DeepSeek Harness WebUI 的 Codex/macOS 风格简洁会话模式。

## 安装

在 DeepSeek Harness 根目录运行：

```bash
dsh plugin --profile web add \
  https://github.com/stars2022/dsh-ui-concise/releases/download/v0.1.3/dsh-ui-concise-0.1.3.tgz
dsh web
```

卸载插件：

```bash
dsh plugin --profile web remove dsh-ui-concise
dsh web
```

## 功能

- 设置页提供“简洁模式”和“隐藏思考内容”选项。
- 每个 Turn 显示独立计时器：运行中实时计时，完成后自动收起，中断或失败时保持展开。
- Turn 内的连续工具调用合并为一个活动栏，运行时显示“正在读取文件”“正在编辑文件”等状态，完成后显示操作汇总。
- 展开活动栏可以查看每个工具的原始详情和工具卡。
- 最后的 Assistant 答案保留在外层折叠栏之外，Markdown 排版和消息操作保持正常视图样式。
- 开启“隐藏思考内容”后，思考过程中显示“正在思考”，完成后隐藏思考文本。
- 中文、英文界面均已支持。

## 许可证

[MIT](LICENSE)
