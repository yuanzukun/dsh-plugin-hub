# DSH 工作区管理

[![Release](https://img.shields.io/github/v/release/yxv1203-collab/dsh-conversation-archive?display_name=tag)](https://github.com/yxv1203-collab/dsh-conversation-archive/releases/latest)
![Platform](https://img.shields.io/badge/platform-Windows%2010%20%7C%2011-0078D4)
[![License](https://img.shields.io/badge/license-MIT-2ea44f)](LICENSE)

[English](README.md) · [简体中文](README.zh-CN.md)

面向 DeepSeek Harness（DSH）的原生工作区治理插件，将已归档对话管理、删除前重要文件保护与可验证本地备份统一集成到设置界面。插件以 DSH 原生会话状态为准，并通过严格的路径边界校验、内容哈希与失败关闭机制，降低清理历史会话时误删重要产出或产生不可恢复状态的风险。

## 主要功能

- **原生归档管理：**集中浏览、搜索和筛选 DSH 已归档对话，支持单项或批量取消归档与删除；归档状态始终以 DSH 原生记录为唯一依据，不维护平行索引。
- **重要产出保护：**删除前由 DSH 当前配置的模型审核符合条件的工作区产出，将选中文件写入共享去重保留库，并以内容哈希验证副本完整性；同时支持恢复、批量移除与应用内提醒。
- **可验证本地备份：**支持手动、定时及正常关闭前生成 ZIP 备份。每份备份均包含文件清单与哈希，只能恢复到空目录且不会覆盖现有文件；自动备份默认关闭，默认保留最近五份已验证备份。
- **工作区与路径安全：**支持跨磁盘的 DSH 已登记工作区和独立项目目录，可从原生元数据自动补齐历史映射，并拒绝通过 Junction 或符号链接越过受管路径边界。

## 界面预览

![已归档对话与保留文件](docs/images/workspace-manager-overview.png)

![本地备份与插件设置](docs/images/backup-and-settings.png)

## 环境要求

| 组件 | 要求 |
| --- | --- |
| 操作系统 | Windows 10 或 11 |
| DSH | 已测试 `0.1.1-rc.2` 至 `0.1.2-rc.1`，其他版本尚未验证 |
| PowerShell | 5.1 或更高版本 |
| Node.js | 20 或更高版本，同时满足所安装 DSH 的要求 |
| 工作区 | 具有读写权限的文件夹，不直接使用盘符或网络共享根目录 |

## 安装

### 从 GitHub 安装

```powershell
dsh plugin --profile web add github:yxv1203-collab/dsh-conversation-archive#v1.1.0
```

重启 DSH，打开“设置 → 工作区管理”。

### 从发布包安装

从 [GitHub Releases](https://github.com/yxv1203-collab/dsh-conversation-archive/releases/tag/v1.1.0) 下载 `dsh-conversation-archive-1.1.0.tgz` 及其 `.sha256` 文件。

```powershell
Get-FileHash .\dsh-conversation-archive-1.1.0.tgz -Algorithm SHA256
Get-Content .\dsh-conversation-archive-1.1.0.tgz.sha256
```

确认哈希一致。离线安装时，先把发布包复制到 profile 的持久依赖目录，再安装这份保留副本：

```powershell
$profileDeps = Join-Path $env:DSH_HOME 'profiles\web\deps'
New-Item -ItemType Directory -Force $profileDeps | Out-Null
$profilePackage = Join-Path $profileDeps 'dsh-conversation-archive-1.1.0.tgz'
Copy-Item .\dsh-conversation-archive-1.1.0.tgz $profilePackage
dsh plugin --profile web add $profilePackage
```

只要 profile 仍采用文件依赖，就必须保留该 `.tgz`，不要删除或移动；否则 pnpm 在后续安装其他插件、重新解析全部依赖时会失败。使用上面的 GitHub 标签安装则不会依赖临时下载路径。

## 删除与数据保护

取消归档与删除是独立操作。删除流程先校验会话归属和路径，再扫描符合条件的产出，交由 DSH 配置的模型审核内容；保留副本通过校验后，才回收会话数据。候选文件内容可能发送给 DSH 配置的模型服务商。

原始项目目录和源码文件不属于删除目标。审核、复制、完整性或路径校验失败时，保护性删除流程会停止。AI 保留是选择性保护，不能替代完整项目备份。

在已支持的 DSH 版本中，会话数据回收后暂时保留归档标记；下次正常启动时解除工作区引用并完成删除，避免对话重新出现在活动列表。

## 工作区与元数据

**元数据未登记**表示原生归档会话尚无有效的插件工作区映射。插件在启动和归档同步时，从 DSH 会话元数据自动回填映射。若提示持续出现，请检查工作区是否可访问、会话元数据是否可读取；完整的工作区产出保护和备份需要有效映射。

原生会话路径不受共享存储根目录限制。插件首次使用时可从规范的日常工作区识别共享根目录，并记录该位置供后续启动使用。已有映射和保留文件不会自动迁移。显式设置的 `harnessRoot`、`DCA_HARNESS_ROOT` 或 `DSH_HARNESS_ROOT` 优先。

恢复保留文件到原位置时，目标须属于可识别的 DSH 工作区；否则请选择其他恢复目录。恢复不会覆盖已有文件，并拒绝通过 Junction 或符号链接越界的路径。

## 备份范围

备份包含已登记的 DSH 会话数据和保留文件，不包含完整源码仓库。目标可选本地文件夹或受支持的网络路径；最新备份验证通过后，才会回收超出保留数量的旧备份。网络可用性、目录权限及回收站支持取决于目标位置。

插件不直接连接云盘账号，可由外部同步软件同步备份文件夹。提醒仅在 DSH 内显示，不发送 Windows 系统通知。

## 卸载

```powershell
dsh plugin --profile web remove dsh-conversation-archive
```

卸载后重启 DSH。已有保留文件和备份不会被删除。

## 开发与测试

本机安装兼容版本的 DSH 后执行：

```powershell
npm test
npm pack --dry-run --json
npm pack
```

测试覆盖归档同步、历史元数据回填、跨盘路径规则、文件保留、备份、删除恢复及发布完整性。

## 反馈与协议

通过 [GitHub Issues](https://github.com/yxv1203-collab/dsh-conversation-archive/issues) 反馈问题，或联系 **yxv1203@gmail.com**。请提供 DSH 与插件版本、复现步骤和脱敏后的诊断信息。

本项目采用 [MIT 协议](LICENSE)。
