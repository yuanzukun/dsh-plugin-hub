import crypto from 'node:crypto';

/**
 * 任务锚点与请求快照的身份规则都在这里：纯函数，不摸盘、不调模型。
 * 无法确定时只留 unbound 作品壳；栏目默认必须由用户显式确认，不能按“只有一个”猜。
 */

export const ANCHOR_STATUSES = ['unbound', 'proposed', 'active', 'continuable', 'ambiguous', 'closed'];
export const TASK_LIMITS = { sessions: 8, episodes: 12, sourceMessages: 8, idleMs: 7 * 24 * 60 * 60 * 1000, indexBytes: 600 };

const SWITCH_WORDS = /(改做|改为|改到|改成|换个|换一个|换成|转到|现在做|接下来做|新做|另做|开始做|去做)/;
const CONTINUE_WORDS = /(继续|再做一期|下一期|再来一期|再开一期|续一集|再拍一期)/;
/** 短续句只由通用动作词组成、没点名新对象：仍属于当前任务，不能当换任务。 */
const ELLIPTICAL_CONTINUE = /^(?:继续|接着|再接着|往下)[，,、\s]*(?:把|将|再)?(?:优化|收敛|调整|完善|打磨|推进|处理|改|修|做|写|整理|检查|排查|测试|发布|跑|看看|看下|弄|试|收尾|统一|对齐|细化|补|过一遍|走一遍|一下|下)+[。.!！?？…]*$/u;
const REVISE_WORDS = /(再改一下|改一版|再改改|调整一下|这版再|继续改)/;
const THANKS_WORDS = /^(谢谢|多谢|谢了|辛苦了|thanks|thank\s*you)[!！。.～~\s]*$/i;
const REFERENCE_WORDS = /(这个|这条|这次|上次|之前|刚才|上面|前面|它|这里|继续|接着|还是|同样|再改)/;
const TASK_STOP = new Set(['一个','一下','这个','那个','我们','你们','他们','什么','怎么','可以','需要','帮我','帮忙','请问','然后','现在','还是','就是','没有','不是','以及','关于','进行','使用','问题','任务','内容','时候','已经','如果','因为','所以','但是','而且','或者','这些','那些','这样','那样','一下','一点','一些']);
/** 判断任务是否换了对象时，这些词只表示动作或指代，不算对象证据。 */
const TASK_NOISE = /(继续|再做一期|下一期|再来一期|再开一期|续一集|再拍一期|接着|然后|接下来|现在|帮我|帮忙|这个|这条|这次|上次|之前|刚才|上面|前面|下面|后面|这里|还是|同样|再改|排查|处理|检查|看看|看一下|看下|修复|解决|优化|调整|修改|分析|研究|对比|评估|调研|测试|设计|实现|开发|搭建|部署|定位|复现|查一下|找一下|问题|任务|内容|一下)/g;
/** 续接词后面还得跟一个动作，才算真正在改旧稿；单说「继续 / 这个 / 之前」不构成复用依据。 */
const CONTINUATION_ACTION = /(继续|接着|然后|再|还是|同样)\s*(做|改|调|弄|看|写|处理|优化|调整|检查|完成)/;
/** 明确指向刚才那一版作品的说法，是沿用旧范围的正面证据；「这版/那版」只是指示，不算旧稿。 */
const OLD_WORK_REFERENCE = /(刚才那版|之前那版|上一版|原稿|旧稿)/;
/** 旧稿被放下、否定或只作为话题提起时，不能因为它出现就恢复旧范围。 */
const OLD_WORK_PAUSE = /(先放着|放着|放一边|先不|先别|别管|不用管|搁置|暂停|不做了|先不做|不用了)/;
const OLD_WORK_ACTION = /(继续|接着|再改|改成|改一下|调整|优化|改改|开头|结尾|结构|节奏|语气|口吻|文案|措辞|细节|版本)/;
/** 创作类与工程类任务的默认判断不同；同一主题从写口播切到排查代码，不能沿用旧栏目。 */
const CONTENT_INTENT = /(口播|拍摄|录制|剪辑|文案|封面|字幕|直播|视频|选题|脚本|一期|栏目)/;
const ENGINEERING_INTENT = /(代码|排查|故障|部署|调试|重构|接口|数据库|查询|报错|日志|服务|环境|依赖|测试|配置|修复)/;
/** 运行时任务判断只分工程/创作两类；两类词同时出现时工程证据优先。 */
const CODE_TASK_WORDS = /(源码|代码|插件|仓库|数据库|报错|日志|重构|修复|排查|测试|编译|依赖|bug)/i;
const CONTENT_TASK_WORDS = /(口播|选题|拍摄|剪辑|发布|封面|字幕)/;
/** 「口播功能/模块/页面」是代码对象；只有整句确有工程语境时才否定栏目绑定。 */
const CODE_OBJECT_AFTER = /^\s*(插件|源码|代码|仓库|报错|日志|接口|函数|依赖|测试|编译|功能|模块|组件|页面|流程|逻辑)/;
const CODE_OBJECT_NOUN = /(功能|模块|组件|页面|接口|流程|逻辑)/;
const CODE_CONTEXT_WORDS = /(bug|代码|修复|排查|故障|报错|调试|测试|编译|部署|仓库|函数|插件|源码|接口|实现|开发|重构|配置)/i;
/** 讲解/介绍后面的对象是话题，不是当前交付栏目。 */
const TOPIC_SERIES_BEFORE = /(讲解|介绍|聊聊|说说|分享|科普|解释|围绕|关于|主题是|主题为|话题是|话题为)[^，。；！？\n]{0,8}$/;
const TOPIC_AFTER = /(?:讲解|介绍|聊聊|说说|分享|科普|解释|围绕|关于|主题是|主题为|话题是|话题为)\s*([^，。；！？,.;!?\n]{2,24})/;
const TOPIC_OBJECT = /([^\s，。；！？,.;!?]{2,16}?(?:功能|模块|组件|页面|接口|流程|逻辑))/;
const TOPIC_SUBJECT = /^([^，。；！？\n]{2,20}?)(?:最近|现在|老是|总是|已经|出现|报|有|坏|异常|不对)/;
/** 明确把栏目放下、停掉，才算撤销；句末的「吧/啦/了」只是语气，不是撤销。 */
const REVOKE_SERIES_BEFORE = /(先不做|不做了|不再做|不做|不搞|不拍|不写|不剪|不发|先放着|先放|放一边|暂停|停掉|去掉|别做|不要做)[^，。；！？\n]{0,8}$/;
const REVOKE_SERIES_AFTER = /^(先不做|不做了|不搞了|不拍了|不写了|暂停|先放着|放一边|不要了|停掉)/;
const ACTION_RULES = [
  ['fix', /(修复|修好|排查|定位|解决|修正|调试|debug|bug|报错|故障)/i],
  ['review', /(审阅|审查|检查|评估|看看|复盘|review)/i],
  ['edit', /(改|调整|优化|润色|修改|重写|更新)/],
  ['create', /(做|制作|写|拍摄|录制|剪辑|生成|出一期|再做一期)/],
  ['explain', /(讲解|介绍|说明|分享|聊聊|说说|科普|解释)/],
];
/** 这些词描述的是旧稿的某个方面，不是新对象；不该因为它们出现就撤销旧范围。 */
const ASPECT_NOISE = /(节奏|速度|风格|语气|口吻|结构|长度|时长|篇幅|配色|字号|字体|标题|文案|措辞|逻辑|细节|开头|结尾|过渡|画面|镜头|音乐|音效|字幕|参数|格式|排版)/g;
/** 程度、指代和虚词组成的二字片段不是对象证据。 */
const GENERIC_CHARS = /[再更稍很太挺点些快慢多少好坏大小高低长短早晚新旧一二三四五六七八九十百千万个把的得地了着过吗呢吧啊]/;
function taskTerms(value) {
  const plain = text(value, 200).toLowerCase().replace(/[^\p{L}\p{N}]+/gu, ' ').replace(ASPECT_NOISE, ' ').replace(TASK_NOISE, ' ').replace(/\s+/g, ' ').trim();
  const terms = new Set();
  for (const word of plain.match(/[a-z][a-z0-9_-]{2,}/g) || []) terms.add(word);
  const runs = plain.match(/[\u4e00-\u9fff]+/g) || [];
  for (const run of runs) {
    if (TASK_STOP.has(run)) continue;
    for (let i = 0; i + 2 <= run.length; i += 1) {
      const gram = run.slice(i, i + 2);
      if (TASK_STOP.has(gram) || GENERIC_CHARS.test(gram)) continue;
      terms.add(gram);
    }
  }
  return terms;
}
/** 继承旧任务要有正面证据：新要求与本轮任务没有实质对象交集时，先按新任务处理。 */
export function looksLikeNewTask(query, previousText) {
  const current = text(query, 200);
  if (!current || isThanks(current)) return false;
  if (ELLIPTICAL_CONTINUE.test(current)) return false;
  const next = taskTerms(current);
  const previous = taskTerms(previousText);
  const cue = isContinuation(current) || REFERENCE_WORDS.test(current);
  /** 只剩指代或续接词时，必须另有动作才算续接；否则宁可换任务也不沿用旧范围。 */
  if (!next.size) return cue ? !CONTINUATION_ACTION.test(current) : false;
  if (!previous.size) return false;
  /** 同一主题换了工作类型（口播 → 排查代码）是新任务，不靠对象词重叠判续作。 */
  const nextKind = CONTENT_INTENT.test(current) ? (ENGINEERING_INTENT.test(current) ? '' : 'content')
    : (ENGINEERING_INTENT.test(current) ? 'engineering' : '');
  const previousKind = CONTENT_INTENT.test(previousText) ? (ENGINEERING_INTENT.test(previousText) ? '' : 'content')
    : (ENGINEERING_INTENT.test(previousText) ? 'engineering' : '');
  if (nextKind && previousKind && nextKind !== previousKind) return true;
  for (const term of next) if (previous.has(term)) return false;
  /** 指向旧稿还要有继续改它的动作；「旧稿先放着」「这版数据库配置怎么改」都算新任务。 */
  if (OLD_WORK_REFERENCE.test(current) && !OLD_WORK_PAUSE.test(current) && OLD_WORK_ACTION.test(current)) return false;
  /**
   * 有实质对象词却跟旧任务没有任何交集：这就是新任务，不因为句首带了
   * 「继续」「这个」就把旧范围连同正文一起搬过来。继承只认对象交集、
   * 明确的旧稿指代，或者除动作/指代外没有新对象（上面两条）。
   */
  return true;
}

export function emptyTasks() {
  return { revision: 0, defaults: null, sessions: {}, episodes: {} };
}

function text(value, max = 120) {
  return typeof value === 'string' ? value.normalize('NFKC').replace(/\s+/g, ' ').trim().slice(0, max) : '';
}

function clone(value) {
  return value === undefined ? undefined : JSON.parse(JSON.stringify(value));
}

export function isThanks(query) {
  return THANKS_WORDS.test(text(query, 40));
}

export function isContinuation(query) {
  return CONTINUE_WORDS.test(text(query, 160));
}

export function isRevision(query) {
  return REVISE_WORDS.test(text(query, 160));
}

const NEGATED_SERIES = /(不要|不用|别|不按|不照|不是|并非|先不|不做|不搞|忽略|跳过|不管|别提)[^，。；！？\n]{0,10}$/;
const MENTION_SERIES = /(日志|报错|错误|信息|提到|说到|包含|关键词|这个词|源码|代码|插件|文档|规则名|栏目名|分析)[^，。；！？\n]{0,10}$/;
const PAUSED_SERIES = /^(先放着|先放|放一边|先不做|不做了|不用了|暂停)/;
const PAUSED_BEFORE = /(先放着|先放|放一边|先不做|不做了|不用了|暂停)[^，。；！？\n]{0,4}$/;
/** 提到栏目名不等于选中它：否定、引用、看源码或「先放着」都只是话题，不能建绑定。 */
export function seriesChosenBy(query, series) {
  const value = text(query, 400);
  const name = text(series, 40);
  if (!value || !name) return false;
  let from = 0;
  while (from <= value.length) {
    const at = value.indexOf(name, from);
    if (at < 0) return false;
    const before = value.slice(Math.max(0, at - 14), at);
    const after = value.slice(at + name.length);
    const asCodeObject = CODE_OBJECT_AFTER.test(after) && CODE_CONTEXT_WORDS.test(value);
    if (!NEGATED_SERIES.test(before) && !MENTION_SERIES.test(before) && !PAUSED_BEFORE.test(before)
      && !PAUSED_SERIES.test(after) && !TOPIC_SERIES_BEFORE.test(before) && !asCodeObject) return true;
    from = at + name.length;
  }
  return false;
}

/**
 * 把一句话拆成动作、交付物和话题：只有交付物才参与任务类型与栏目绑定，
 * 动作和话题都带来源，避免把「讲解数据库事务」当成交付栏目。
 */
export function taskFacetsOf(query) {
  const value = text(query, 400);
  if (!value) {
    return {
      action: { kind: 'unknown', evidence: 'none' },
      deliverable: { kind: '', seriesId: '', evidence: 'none' },
      topic: { text: '', evidence: 'none' },
      conflict: false,
    };
  }
  const found = ACTION_RULES.find(([, pattern]) => pattern.test(value));
  const action = { kind: found ? found[0] : 'unknown', evidence: found ? 'query' : 'none' };
  const codeIntent = CODE_TASK_WORDS.test(value);
  const codeObject = CODE_OBJECT_NOUN.test(value);
  const contentIntent = CONTENT_TASK_WORDS.test(value) || /(一期|栏目|视频|脚本)/.test(value);
  const contentCreate = (action.kind === 'create' || action.kind === 'edit') && contentIntent;
  const strongCodeAction = (action.kind === 'fix' || action.kind === 'review') && (codeIntent || codeObject);
  let kind = '';
  if (strongCodeAction || (codeObject && action.kind !== 'create')) kind = 'code';
  else if (contentCreate) kind = 'content';
  else if (codeIntent && !contentIntent) kind = 'code';
  else if (contentIntent && !codeIntent) kind = 'content';
  else if (codeIntent && contentIntent) kind = 'code';

  const marker = TOPIC_AFTER.exec(value);
  let topicText = marker ? marker[1].replace(/[，。；！？,.;!?\s]+$/g, '').replace(/(讲讲|聊聊|说说|展开|讲一下|说一下)$/g, '').trim() : '';
  let topicEvidence = topicText ? 'query' : 'none';
  if (!topicText) {
    const object = TOPIC_OBJECT.exec(value);
    if (object) {
      topicText = object[1];
      topicEvidence = 'inferred';
    } else if (kind === 'code') {
      const subject = TOPIC_SUBJECT.exec(value);
      if (subject) {
        topicText = subject[1];
        topicEvidence = 'inferred';
      }
    }
  }
  const conflict = Boolean(codeIntent && contentIntent && !strongCodeAction
    && !(kind === 'content' && contentCreate && topicText));
  return {
    action,
    deliverable: { kind, seriesId: '', evidence: kind ? 'query' : 'none' },
    topic: { text: topicText, evidence: topicEvidence },
    conflict,
  };
}

/** 任务类型只作上下文判断，不替代已有栏目：交付物目标决定类型。 */
export function taskKindOf(query) {
  return taskFacetsOf(query).deliverable.kind;
}

/** 从一句话里找出被明确撤销的栏目；只认「先不做 / 放一边」这类停做动作。 */
export function revokeSeriesBy(query, registeredSeries) {
  const value = text(query, 400);
  if (!value) return [];
  const series = [...new Set((Array.isArray(registeredSeries) ? registeredSeries : []).map((item) => text(item, 40)).filter(Boolean))];
  return series.filter((name) => {
    let from = 0;
    while (from <= value.length) {
      const at = value.indexOf(name, from);
      if (at < 0) return false;
      const before = value.slice(Math.max(0, at - 12), at);
      const after = value.slice(at + name.length);
      if (REVOKE_SERIES_BEFORE.test(before) || REVOKE_SERIES_AFTER.test(after)) return true;
      from = at + name.length;
    }
    return false;
  });
}

/**
 * 生成本轮请求的运行时任务上下文：身份字段只来自可信批次，
 * 任务字段优先用已绑定锚点，未绑定时才看本句的任务类型。
 */
export function buildRuntimeContext(input = {}) {
  const projectId = text(input.projectId, 240);
  const sessionId = text(input.sessionId, 120);
  const messageIds = (Array.isArray(input.messageIds) ? input.messageIds : []).map((id) => text(id, 120)).filter(Boolean);
  const batchKey = text(input.batchKey, 120) || requestBatchKey(messageIds);
  const anchor = input.anchor && typeof input.anchor === 'object' ? input.anchor : null;
  const episode = input.episode && typeof input.episode === 'object' ? input.episode : null;
  const anchorKind = text(anchor && anchor.taskKind, 40);
  const episodeKind = text(episode && episode.taskKind, 40);
  const facets = taskFacetsOf(input.query);
  const inferredKind = facets.deliverable.kind;
  const kind = episodeKind || anchorKind || inferredKind;
  /** 存储下来的 query 推断仍是 query，不能因为落过盘就自升为用户确认。 */
  const storedKindEvidence = text(episode && episode.kindEvidence, 20) || text(anchor && anchor.kindEvidence, 20);
  const evidence = storedKindEvidence
    || (inferredKind ? 'query' : (episodeKind || anchorKind ? 'inferred' : 'none'));
  const storedAction = text(episode && episode.actionKind, 20) || text(anchor && anchor.actionKind, 20);
  const storedTopic = text(episode && episode.topicText, 120) || text(anchor && anchor.topicText, 120);
  const topicEvidence = text(episode && episode.topicEvidence, 20) || text(anchor && anchor.topicEvidence, 20);
  return {
    projectId,
    sessionId,
    requestId: contextIdFor(projectId, batchKey, text(episode && episode.episodeId, 120) || text(anchor && anchor.episodeId, 120)),
    controlEpoch: input.controlEpoch === undefined || input.controlEpoch === null ? '' : String(input.controlEpoch),
    task: {
      kind,
      seriesId: text(episode && episode.seriesId, 80) || text(anchor && anchor.seriesId, 80),
      artifactKey: text(episode && episode.artifactKey, 120) || text(anchor && anchor.artifactKey, 120),
      phase: text(episode && episode.phase, 40) || text(anchor && anchor.phase, 40),
      evidence,
      seriesEvidence: text(episode && episode.seriesEvidence, 20) || text(anchor && anchor.seriesEvidence, 20)
        || (text(episode && episode.seriesId, 80) || text(anchor && anchor.seriesId, 80) ? 'inferred' : 'none'),
      action: storedAction || facets.action.kind,
      actionEvidence: storedAction ? 'query' : facets.action.evidence,
      topic: storedTopic || facets.topic.text,
      topicEvidence: storedTopic ? (topicEvidence || 'inferred') : facets.topic.evidence,
      conflict: Boolean((episode && episode.conflict === true) || (anchor && anchor.conflict === true) || facets.conflict),
    },
  };
}

export function requestBatchKey(messageIds) {
  const ids = [...new Set((Array.isArray(messageIds) ? messageIds : []).map((id) => String(id || '')).filter(Boolean))].sort();
  if (!ids.length) return '';
  return `rb_${crypto.createHash('sha256').update(ids.join('\u0000')).digest('hex').slice(0, 16)}`;
}

function hash(value, chars = 12) {
  return crypto.createHash('sha256').update(String(value)).digest('hex').slice(0, chars);
}

export function transitionIdFor(batchKey, previousRevision = 0) {
  return `tr_${hash(`${batchKey}\u0000${Number(previousRevision) || 0}`)}`;
}

export function episodeIdFor(transitionId) {
  return `ep_${hash(`episode\u0000${transitionId}`)}`;
}

/** contextId 只在本请求内有效；前缀带项目摘要，跨项目一眼就能拒绝。 */
export function contextIdFor(projectId, batchKey, nonce) {
  return `ctx_${hash(`project\u0000${projectId}`, 8)}_${hash(`request\u0000${batchKey}\u0000${nonce || ''}`, 8)}`;
}

export function projectTagOf(contextId) {
  const match = /^ctx_([a-f0-9]{8})_/.exec(String(contextId || ''));
  return match ? match[1] : '';
}

export function projectTag(projectId) {
  return hash(`project\u0000${projectId}`, 8);
}

export function normalizeTasks(raw) {
  const base = emptyTasks();
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return base;
  const output = base;
  output.revision = Number.isInteger(raw.revision) && raw.revision > 0 ? raw.revision : 0;
  if (raw.defaults && typeof raw.defaults === 'object') {
    const taskKind = text(raw.defaults.taskKind, 40);
    const seriesId = text(raw.defaults.seriesId, 40);
    const phase = text(raw.defaults.phase, 40);
    if (taskKind || seriesId || phase) {
      output.defaults = {
        ...(taskKind ? { taskKind } : {}),
        ...(seriesId ? { seriesId } : {}),
        ...(phase ? { phase } : {}),
        confirmedBy: 'user',
        confirmedAt: text(raw.defaults.confirmedAt, 40),
      };
    }
  }
  const sessions = raw.sessions && typeof raw.sessions === 'object' ? raw.sessions : {};
  for (const [sessionId, anchor] of Object.entries(sessions)) {
    if (!sessionId || !anchor || typeof anchor !== 'object') continue;
    const status = ANCHOR_STATUSES.includes(anchor.status) ? anchor.status : 'unbound';
    output.sessions[sessionId] = {
      episodeId: text(anchor.episodeId, 80),
      batchKey: text(anchor.batchKey, 40),
      ...(text(anchor.taskKind, 40) ? { taskKind: text(anchor.taskKind, 40) } : {}),
      ...(text(anchor.seriesId, 40) ? { seriesId: text(anchor.seriesId, 40) } : {}),
      ...(text(anchor.phase, 40) ? { phase: text(anchor.phase, 40) } : {}),
      ...(text(anchor.kindEvidence, 20) ? { kindEvidence: text(anchor.kindEvidence, 20) } : {}),
      ...(text(anchor.seriesEvidence, 20) ? { seriesEvidence: text(anchor.seriesEvidence, 20) } : {}),
      ...(text(anchor.actionKind, 20) ? { actionKind: text(anchor.actionKind, 20) } : {}),
      ...(text(anchor.topicText, 120) ? { topicText: text(anchor.topicText, 120) } : {}),
      ...(text(anchor.topicEvidence, 20) ? { topicEvidence: text(anchor.topicEvidence, 20) } : {}),
      ...(anchor.conflict === true ? { conflict: true } : {}),
      status,
      bindingRevision: Number.isInteger(anchor.bindingRevision) && anchor.bindingRevision > 0 ? anchor.bindingRevision : 1,
      sourceMessageIds: (Array.isArray(anchor.sourceMessageIds) ? anchor.sourceMessageIds : []).map((id) => text(id, 120)).filter(Boolean).slice(0, TASK_LIMITS.sourceMessages),
      updatedAt: text(anchor.updatedAt, 40),
    };
  }
  const episodes = raw.episodes && typeof raw.episodes === 'object' ? raw.episodes : {};
  for (const [episodeId, episode] of Object.entries(episodes)) {
    if (!episodeId || !episode || typeof episode !== 'object') continue;
    output.episodes[episodeId] = {
      episodeId,
      ...(text(episode.taskKind, 40) ? { taskKind: text(episode.taskKind, 40) } : {}),
      ...(text(episode.seriesId, 40) ? { seriesId: text(episode.seriesId, 40) } : {}),
      ...(text(episode.phase, 40) ? { phase: text(episode.phase, 40) } : {}),
      ...(text(episode.kindEvidence, 20) ? { kindEvidence: text(episode.kindEvidence, 20) } : {}),
      ...(text(episode.seriesEvidence, 20) ? { seriesEvidence: text(episode.seriesEvidence, 20) } : {}),
      ...(text(episode.actionKind, 20) ? { actionKind: text(episode.actionKind, 20) } : {}),
      ...(text(episode.topicText, 120) ? { topicText: text(episode.topicText, 120) } : {}),
      ...(text(episode.topicEvidence, 20) ? { topicEvidence: text(episode.topicEvidence, 20) } : {}),
      ...(episode.conflict === true ? { conflict: true } : {}),
      status: ANCHOR_STATUSES.includes(episode.status) ? episode.status : 'unbound',
      transitionId: text(episode.transitionId, 80),
      previousEpisodeId: text(episode.previousEpisodeId, 80),
      ...(text(episode.taskText, 200) ? { taskText: text(episode.taskText, 200) } : {}),
      createdAt: text(episode.createdAt, 40),
      updatedAt: text(episode.updatedAt, 40),
    };
  }
  return pruneTasks(output);
}

/** 只保留最近的表和作品壳：项目状态有硬上限，读路径不能越用越肥。 */
export function pruneTasks(tasks, now = Date.now()) {
  const out = normalizeTasksShallow(tasks);
  const sessions = Object.entries(out.sessions)
    .sort((a, b) => String(b[1].updatedAt).localeCompare(String(a[1].updatedAt)))
    .slice(0, TASK_LIMITS.sessions);
  out.sessions = Object.fromEntries(sessions);
  const live = new Set(Object.values(out.sessions).map((anchor) => anchor.episodeId).filter(Boolean));
  const episodes = Object.entries(out.episodes)
    .filter(([id, episode]) => live.has(id) || now - Date.parse(episode.updatedAt || episode.createdAt || 0) < TASK_LIMITS.idleMs)
    .sort((a, b) => String(b[1].updatedAt).localeCompare(String(a[1].updatedAt)))
    .slice(0, TASK_LIMITS.episodes);
  out.episodes = Object.fromEntries(episodes);
  return out;
}

/** 防止 prune 调 normalize 无限递归；这里只做浅层结构复制。 */
function normalizeTasksShallow(raw) {
  const base = emptyTasks();
  if (!raw || typeof raw !== 'object') return base;
  base.revision = Number.isInteger(raw.revision) ? raw.revision : 0;
  base.defaults = raw.defaults && typeof raw.defaults === 'object' ? clone(raw.defaults) : null;
  base.sessions = raw.sessions && typeof raw.sessions === 'object' ? clone(raw.sessions) : {};
  base.episodes = raw.episodes && typeof raw.episodes === 'object' ? clone(raw.episodes) : {};
  return base;
}

function episodeOf(tasks, episodeId) {
  return episodeId ? tasks.episodes[episodeId] || null : null;
}

function anchorOf(episode, { sessionId, batchKey, messageIds, status, bindingRevision, now }) {
  return {
    episodeId: episode.episodeId,
    ...(episode.taskKind ? { taskKind: episode.taskKind } : {}),
    ...(episode.seriesId ? { seriesId: episode.seriesId } : {}),
    ...(episode.phase ? { phase: episode.phase } : {}),
    ...(episode.kindEvidence ? { kindEvidence: episode.kindEvidence } : {}),
    ...(episode.seriesEvidence ? { seriesEvidence: episode.seriesEvidence } : {}),
    ...(episode.actionKind ? { actionKind: episode.actionKind } : {}),
    ...(episode.topicText ? { topicText: episode.topicText } : {}),
    ...(episode.topicEvidence ? { topicEvidence: episode.topicEvidence } : {}),
    ...(episode.conflict === true ? { conflict: true } : {}),
    status,
    bindingRevision,
    batchKey,
    sessionId,
    sourceMessageIds: [...messageIds].slice(0, TASK_LIMITS.sourceMessages),
    updatedAt: new Date(now).toISOString(),
  };
}

function createEpisode(tasks, { taskKind, seriesId, phase, status, transitionId, previousEpisodeId, taskText, kindEvidence, seriesEvidence, actionKind, topicText, topicEvidence, conflict, now }) {
  const episodeId = episodeIdFor(transitionId);
  const at = new Date(now).toISOString();
  const episode = {
    episodeId,
    ...(taskKind ? { taskKind } : {}),
    ...(seriesId ? { seriesId } : {}),
    ...(phase ? { phase } : {}),
    ...(kindEvidence ? { kindEvidence } : {}),
    ...(seriesEvidence ? { seriesEvidence } : {}),
    ...(actionKind ? { actionKind } : {}),
    ...(topicText ? { topicText } : {}),
    ...(topicEvidence ? { topicEvidence } : {}),
    ...(conflict === true ? { conflict: true } : {}),
    status,
    transitionId,
    ...(previousEpisodeId ? { previousEpisodeId } : {}),
    ...(text(taskText, 200) ? { taskText: text(taskText, 200) } : {}),
    createdAt: at,
    updatedAt: at,
  };
  tasks.episodes[episodeId] = episode;
  tasks.revision += 1;
  return episode;
}

function touch(tasks, episode, patch, now) {
  const at = new Date(now).toISOString();
  Object.assign(episode, patch, { updatedAt: at });
  tasks.episodes[episode.episodeId] = episode;
  tasks.revision += 1;
}

/**
 * 依据可信批次与焦点决定本轮锚点。这里不读自由文本里的“可能栏目”，
 * 只认明确切换、已确认延续、已确认项目默认和前台选择过的 proposed。
 */
export function routeTask(tasksInput, input = {}) {
  const tasks = normalizeTasks(tasksInput);
  const now = Number.isFinite(input.now) ? input.now : Date.now();
  const sessionId = text(input.sessionId, 120);
  const query = text(input.query, 400);
  const messageIds = (Array.isArray(input.messageIds) ? input.messageIds : []).map((id) => text(id, 120)).filter(Boolean);
  const batchKey = input.batchKey || requestBatchKey(messageIds);
  const projectId = text(input.projectId, 240);
  if (!sessionId || !batchKey) return { tasks, anchor: null, episode: null, decision: { kind: 'none', reason: 'no_batch' }, changed: false };

  const current = tasks.sessions[sessionId] || null;
  const currentEpisode = episodeOf(tasks, current && current.episodeId);
  /** 同一批人类消息重试/重放：已有本轮结果就原样返回，不重复建 episode。 */
  if (current && current.batchKey === batchKey) {
    if (currentEpisode && currentEpisode.status !== 'unbound' && !input.selection) {
      return { tasks, anchor: current, episode: currentEpisode, decision: { kind: 'focus', anchor: current }, changed: false };
    }
    if (currentEpisode && currentEpisode.status !== 'unbound' && input.selection
      && (!input.selection.seriesId || currentEpisode.seriesId === input.selection.seriesId)) {
      return { tasks, anchor: current, episode: currentEpisode, decision: { kind: 'selected', anchor: current }, changed: false };
    }
    if (currentEpisode && currentEpisode.status === 'unbound' && !input.selection) {
      return { tasks, anchor: current, episode: currentEpisode, decision: { kind: 'unbound', anchor: current }, changed: false };
    }
  }
  const registered = (Array.isArray(input.registeredSeries) ? input.registeredSeries : []).map((item) => text(item, 40)).filter(Boolean);
  /** 用户在这句话里点名的栏目优先于旧栏目和项目默认值。 */
  const namedSeries = registered.find((series) => seriesChosenBy(query, series)) || '';
  const changedSeries = current && namedSeries && namedSeries !== (current.seriesId || '') ? namedSeries : '';
  const projectDefaults = input.defaults || tasks.defaults;
  const facets = taskFacetsOf(query);
  const queryKind = facets.deliverable.kind;
  /** 调用方显式给的类型才是 explicit；从本句推断出的 code 只算 query 证据。 */
  const inputKind = text(input.taskKind, 40) || (input.selection && text(input.selection.taskKind, 40)) || '';
  const inferredKind = queryKind === 'code' ? 'code' : '';
  /** content 是弱类型：只在没有旧栏目/项目默认值可继承时，才作为本句推断落盘。 */
  const contentKind = queryKind === 'content' ? 'content' : '';
  const explicitKind = inputKind || inferredKind;
  const kindEvidence = inputKind ? 'explicit' : (inferredKind ? 'query' : '');
  const inheritedKindEvidence = (currentEpisode && currentEpisode.kindEvidence) || (kindEvidence === 'query' ? 'query' : 'inferred');
  const inheritedSeriesEvidence = (currentEpisode && currentEpisode.seriesEvidence) || 'inferred';
  const fallbackKind = explicitKind || (currentEpisode && currentEpisode.taskKind)
    || (projectDefaults && projectDefaults.taskKind) || '';
  const fallbackKindEvidence = explicitKind ? kindEvidence
    : ((currentEpisode && currentEpisode.taskKind) ? inheritedKindEvidence : (projectDefaults && projectDefaults.taskKind ? 'explicit' : ''));
  const facetFields = {
    ...(facets.action.kind !== 'unknown' ? { actionKind: facets.action.kind } : {}),
    ...(facets.topic.text ? { topicText: facets.topic.text, topicEvidence: facets.topic.evidence } : {}),
    ...(facets.conflict ? { conflict: true } : {}),
  };

  if ((!current || current.status === 'unbound' || current.status === 'proposed') && input.selection && (input.selection.seriesId || input.selection.taskKind)) {
    const transitionId = transitionIdFor(batchKey, current ? current.bindingRevision || 0 : 0);
    const existing = Object.values(tasks.episodes).find((episode) => episode.transitionId === transitionId);
    /** 已有无正文作品壳时原地升级，不额外留一个作废的空集。 */
    const shell = !existing && current && currentEpisode && currentEpisode.status === 'unbound' && !currentEpisode.seriesId && !currentEpisode.taskKind;
    let episode;
    if (shell) {
      episode = currentEpisode;
      Object.assign(episode, {
        ...(input.selection.taskKind ? { taskKind: input.selection.taskKind, kindEvidence: 'explicit' } : {}),
        ...(input.selection.seriesId ? { seriesId: input.selection.seriesId, seriesEvidence: 'explicit' } : {}),
        phase: input.selection.phase || 'brief',
        ...facetFields,
      });
      touch(tasks, episode, { status: 'proposed' }, now);
    } else {
      episode = existing || createEpisode(tasks, {
        taskKind: input.selection.taskKind,
        seriesId: input.selection.seriesId,
        phase: input.selection.phase || 'brief',
        status: 'proposed',
        transitionId,
        kindEvidence: input.selection.taskKind ? 'explicit' : '',
        seriesEvidence: input.selection.seriesId ? 'explicit' : '',
        ...facetFields,
        taskText: query,
        now,
      });
    }
    const anchor = anchorOf(episode, { sessionId, batchKey, messageIds, status: 'proposed', bindingRevision: tasks.revision, now });
    tasks.sessions[sessionId] = anchor;
    return { tasks, anchor, episode, decision: { kind: 'selected', anchor }, changed: true };
  }

  if (isThanks(query)) {
    if (!current) return { tasks, anchor: null, episode: null, decision: { kind: 'none', reason: 'thanks' }, changed: false };
    return { tasks, anchor: current, episode: currentEpisode, decision: { kind: 'none', reason: 'thanks', pointer: true }, changed: false };
  }

  /** 明确撤销旧栏目要先于续作和项目默认值：说了「先不做口播」就不能再继承口播正文。 */
  const revocable = [...new Set([...registered, current && current.seriesId, currentEpisode && currentEpisode.seriesId,
    projectDefaults && projectDefaults.seriesId].filter(Boolean))];
  const revoked = revokeSeriesBy(query, revocable);
  if (revoked.length) {
    const transitionId = transitionIdFor(batchKey, tasks.revision);
    const existing = Object.values(tasks.episodes).find((episode) => episode.transitionId === transitionId);
    const nextSeries = namedSeries && !revoked.includes(namedSeries) ? namedSeries : '';
    const nextKind = explicitKind;
    const status = nextSeries || nextKind ? 'active' : 'unbound';
    const episode = existing || createEpisode(tasks, {
      ...(nextKind ? { taskKind: nextKind, kindEvidence } : {}),
      ...(nextSeries ? { seriesId: nextSeries, seriesEvidence: 'query' } : {}),
      status,
      phase: 'brief',
      transitionId,
      ...facetFields,
      ...(currentEpisode ? { previousEpisodeId: currentEpisode.episodeId } : {}),
      taskText: query,
      now,
    });
    const anchor = anchorOf(episode, { sessionId, batchKey, messageIds, status, bindingRevision: tasks.revision, now });
    tasks.sessions[sessionId] = anchor;
    return { tasks, anchor, episode, decision: { kind: 'revoked', anchor, revoked: [...revoked], ...(nextKind ? { taskKind: nextKind } : {}) }, changed: true };
  }

  /** 先认新对象，再认续作：带「继续 / 这个」但换了对象，也必须撤销旧范围。
   *  本句点名了已登记栏目（「再做一期口播」）就是明确的对象证据，不算换任务。 */
  if (current && currentEpisode && currentEpisode.status !== 'unbound'
    && !SWITCH_WORDS.test(query) && !changedSeries && !namedSeries
    && looksLikeNewTask(query, currentEpisode.taskText || '')) {
    const transitionId = transitionIdFor(batchKey, tasks.revision);
    const existing = Object.values(tasks.episodes).find((episode) => episode.transitionId === transitionId);
    const episode = existing || createEpisode(tasks, {
      ...(explicitKind ? { taskKind: explicitKind, kindEvidence } : {}),
      status: 'unbound',
      phase: 'brief',
      transitionId,
      ...facetFields,
      previousEpisodeId: currentEpisode.episodeId,
      taskText: query,
      now,
    });
    const anchor = anchorOf(episode, { sessionId, batchKey, messageIds, status: 'unbound', bindingRevision: tasks.revision, now });
    tasks.sessions[sessionId] = anchor;
    return { tasks, anchor, episode, decision: { kind: 'unbound', anchor, reason: 'new_task', ...(explicitKind ? { taskKind: explicitKind } : {}) }, changed: true };
  }

  if (isContinuation(query) && current && currentEpisode) {
    const previousRevision = current.bindingRevision || 1;
    const transitionId = transitionIdFor(batchKey, previousRevision);
    const existing = Object.values(tasks.episodes).find((episode) => episode.transitionId === transitionId);
    /** 「再做一期 Vlog」：继承上一期的任务类型，但栏目换成本句点名的那个。 */
    const seriesId = changedSeries || currentEpisode.seriesId || '';
    const status = changedSeries ? 'active' : 'continuable';
    const episode = existing || createEpisode(tasks, {
      ...(fallbackKind ? { taskKind: fallbackKind, kindEvidence: fallbackKindEvidence } : {}),
      ...(seriesId ? { seriesId, seriesEvidence: changedSeries ? 'query' : inheritedSeriesEvidence } : {}),
      phase: 'brief',
      status,
      transitionId,
      ...facetFields,
      previousEpisodeId: currentEpisode.episodeId,
      taskText: query,
      now,
    });
    const anchor = anchorOf(episode, { sessionId, batchKey, messageIds, status, bindingRevision: tasks.revision, now });
    tasks.sessions[sessionId] = anchor;
    return { tasks, anchor, episode, decision: { kind: 'continuation', anchor, inherited: currentEpisode, ...(episode && episode.taskKind ? { taskKind: episode.taskKind } : {}) }, changed: true };
  }

  if (isRevision(query) && current && currentEpisode) {
    touch(tasks, currentEpisode, { status: currentEpisode.status === 'proposed' ? 'proposed' : 'continuable' }, now);
    const anchor = anchorOf(currentEpisode, { sessionId, batchKey, messageIds, status: currentEpisode.status === 'proposed' ? 'proposed' : 'continuable', bindingRevision: tasks.revision, now });
    tasks.sessions[sessionId] = anchor;
    return { tasks, anchor, episode: currentEpisode, decision: { kind: 'revision', anchor, ...(currentEpisode && currentEpisode.taskKind ? { taskKind: currentEpisode.taskKind } : {}) }, changed: true };
  }

  if (current && (SWITCH_WORDS.test(query) || changedSeries)) {
    /** 明确点到已登记的栏目就切过去并立即生效；只说「换个」没点栏目才留无正文作品壳。 */
    const nextSeries = changedSeries || '';
    const transitionId = transitionIdFor(batchKey, tasks.revision);
    const existing = Object.values(tasks.episodes).find((episode) => episode.transitionId === transitionId);
    const status = nextSeries ? 'active' : 'unbound';
    const episode = existing || createEpisode(tasks, {
      ...(fallbackKind ? { taskKind: fallbackKind, kindEvidence: fallbackKindEvidence } : {}),
      ...(nextSeries ? { seriesId: nextSeries, seriesEvidence: changedSeries ? 'query' : inheritedSeriesEvidence } : {}),
      status,
      phase: 'brief',
      transitionId,
      ...facetFields,
      previousEpisodeId: currentEpisode ? currentEpisode.episodeId : '',
      taskText: query,
      now,
    });
    const anchor = anchorOf(episode, { sessionId, batchKey, messageIds, status, bindingRevision: tasks.revision, now });
    tasks.sessions[sessionId] = anchor;
    return { tasks, anchor, episode, decision: { kind: nextSeries ? 'selected' : 'unbound', anchor, switched: true, ...(episode && episode.taskKind ? { taskKind: episode.taskKind } : {}) }, changed: true };
  }

  /** 新会话或尚无有效栏目时，本句点名的已登记栏目直接生效，不被项目默认值覆盖。 */
  if (namedSeries && !changedSeries && (!current || current.status === 'unbound' || current.status === 'proposed')) {
    const transitionId = transitionIdFor(batchKey, tasks.revision);
    const existing = Object.values(tasks.episodes).find((episode) => episode.transitionId === transitionId);
    const namedKind = fallbackKind || contentKind;
    const namedKindEvidence = fallbackKind ? fallbackKindEvidence : (contentKind ? 'query' : '');
    const episode = existing || createEpisode(tasks, {
      ...(namedKind ? { taskKind: namedKind, kindEvidence: namedKindEvidence } : {}),
      seriesId: namedSeries,
      seriesEvidence: 'query',
      status: 'active',
      phase: 'brief',
      transitionId,
      ...facetFields,
      taskText: query,
      now,
    });
    const anchor = anchorOf(episode, { sessionId, batchKey, messageIds, status: 'active', bindingRevision: tasks.revision, now });
    tasks.sessions[sessionId] = anchor;
    return { tasks, anchor, episode, decision: { kind: 'selected', anchor, explicit: true, ...(episode && episode.taskKind ? { taskKind: episode.taskKind } : {}) }, changed: true };
  }

  if (current && currentEpisode) {
    /** 任务文本只作后续「是否换任务」的比对材料，不改锚点时间，免得把正在整理的这期作废。 */
    const nextTaskText = text(query, 200);
    if (nextTaskText && currentEpisode.taskText !== nextTaskText) {
      currentEpisode.taskText = nextTaskText;
      tasks.episodes[currentEpisode.episodeId] = currentEpisode;
    }
    const anchor = anchorOf(currentEpisode, {
      sessionId, batchKey, messageIds,
      status: currentEpisode.status,
      bindingRevision: current.bindingRevision || tasks.revision,
      now,
    });
    tasks.sessions[sessionId] = anchor;
    return { tasks, anchor, episode: currentEpisode, decision: { kind: 'focus', anchor, ...(currentEpisode && currentEpisode.taskKind ? { taskKind: currentEpisode.taskKind } : {}) }, changed: false };
  }

  const defaults = projectDefaults;
  if (!explicitKind && defaults && (defaults.seriesId || defaults.taskKind)) {
    const transitionId = transitionIdFor(batchKey, tasks.revision);
    const existing = Object.values(tasks.episodes).find((episode) => episode.transitionId === transitionId);
    const episode = existing || createEpisode(tasks, {
      taskKind: defaults.taskKind,
      seriesId: defaults.seriesId,
      phase: 'brief',
      status: 'active',
      transitionId,
      kindEvidence: defaults.taskKind ? 'explicit' : '',
      seriesEvidence: defaults.seriesId ? 'explicit' : '',
      ...facetFields,
      taskText: query,
      now,
    });
    const anchor = anchorOf(episode, { sessionId, batchKey, messageIds, status: 'active', bindingRevision: tasks.revision, now });
    tasks.sessions[sessionId] = anchor;
    return { tasks, anchor, episode, decision: { kind: 'default', anchor, ...(episode && episode.taskKind ? { taskKind: episode.taskKind } : {}) }, changed: true };
  }

  /** 新会话/新任务、无法确定栏目：只建无正文作品壳，不猜 seriesId；显式任务类型要留下。 */
  const transitionId = transitionIdFor(batchKey, tasks.revision);
  const existing = Object.values(tasks.episodes).find((episode) => episode.transitionId === transitionId);
  const status = explicitKind ? 'active' : 'unbound';
  const episode = existing || createEpisode(tasks, {
    ...(explicitKind ? { taskKind: explicitKind, kindEvidence } : {}), status, phase: 'brief', transitionId,
    ...facetFields, taskText: query, now,
  });
  const anchor = anchorOf(episode, { sessionId, batchKey, messageIds, status, bindingRevision: tasks.revision, now });
  tasks.sessions[sessionId] = anchor;
  return { tasks, anchor, episode, decision: { kind: 'unbound', anchor, ...(explicitKind ? { taskKind: explicitKind } : {}) }, changed: true };
}

export function contextOfAnchor(anchor, base = {}) {
  return {
    ...base,
    ...(anchor && anchor.taskKind ? { taskKind: anchor.taskKind } : {}),
    ...(anchor && anchor.seriesId ? { seriesId: anchor.seriesId } : {}),
    ...(anchor && anchor.phase ? { phase: anchor.phase } : {}),
  };
}

/** 自动读取决策表：只有明确绑定才给正文；未绑定只给栏目索引。 */
export function decideRead(input = {}) {
  if (input.mode === 'off') return { kind: 'none', reason: 'mode_off' };
  if (input.enabled !== true) return { kind: 'none', reason: 'experiment_off' };
  if (input.identityConfirmed !== true) return { kind: 'none', reason: 'identity_unknown' };
  if (input.thanks) return { kind: 'none', reason: 'thanks', pointerOnly: true };
  if (input.conflict) return { kind: 'conflict', reason: 'conflict' };
  const anchor = input.anchor;
  if (!anchor || anchor.status === 'unbound') {
    const ranges = (Array.isArray(input.ranges) ? input.ranges : []).filter(Boolean).slice(0, 3);
    return ranges.length
      ? { kind: 'index', ranges, reason: 'unbound' }
      : { kind: 'none', reason: 'no_range' };
  }
  if (anchor.status === 'ambiguous') {
    const ranges = (Array.isArray(input.ranges) ? input.ranges : []).filter(Boolean).slice(0, 3);
    return { kind: 'index', ranges, reason: 'ambiguous' };
  }
  if (anchor.status === 'proposed' && input.boundForRequest !== true) {
    return { kind: 'index', ranges: (Array.isArray(input.ranges) ? input.ranges : []).filter(Boolean).slice(0, 3), reason: 'proposed' };
  }
  return { kind: 'rules', reason: 'bound' };
}

export function applySelection(tasksInput, { sessionId, selection, batchKey, messageIds, now = Date.now() }) {
  return routeTask(tasksInput, {
    sessionId,
    batchKey,
    messageIds,
    query: '',
    selection,
    now,
  });
}

export function setDefault(tasksInput, input = {}) {
  const tasks = normalizeTasks(tasksInput);
  const taskKind = text(input.taskKind, 40);
  const seriesId = text(input.seriesId, 40);
  const phase = text(input.phase, 40);
  if (!taskKind && !seriesId && !phase) {
    tasks.defaults = null;
    tasks.revision += 1;
    return tasks;
  }
  tasks.defaults = {
    ...(taskKind ? { taskKind } : {}),
    ...(seriesId ? { seriesId } : {}),
    ...(phase ? { phase } : {}),
    confirmedBy: 'user',
    confirmedAt: new Date(input.now || Date.now()).toISOString(),
  };
  tasks.revision += 1;
  return tasks;
}
