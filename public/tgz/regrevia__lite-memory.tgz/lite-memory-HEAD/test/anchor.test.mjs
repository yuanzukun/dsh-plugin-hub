import test from 'node:test';
import assert from 'node:assert/strict';
import * as anchor from '../anchor.js';
import * as view from '../view.js';

const base = () => ({
  projectId: '/work/demo',
  sessionId: 's1',
  messageIds: ['m1'],
  query: '帮我把这期视频的开头改快一点',
  registeredSeries: ['口播', 'Vlog'],
  now: Date.now(),
});

test('R01 首个自由任务只建 unbound 作品壳，读取只给索引', () => {
  const routed = anchor.routeTask(anchor.emptyTasks(), base());
  assert.equal(routed.anchor.status, 'unbound');
  assert.equal(routed.anchor.taskKind, undefined);
  assert.equal(routed.anchor.seriesId, undefined);
  const decision = anchor.decideRead({
    mode: 'adaptive', enabled: true, identityConfirmed: true,
    anchor: routed.anchor, ranges: ['口播', 'Vlog', '访谈'],
  });
  assert.equal(decision.kind, 'index');
  assert.deepEqual(decision.ranges, ['口播', 'Vlog', '访谈']);
  assert.ok(!('rules' in decision));
});

test('R02 前台选择只能把锚点升为 proposed，不冒充 active', () => {
  const first = anchor.routeTask(anchor.emptyTasks(), base());
  const selected = anchor.applySelection(first.tasks, {
    sessionId: 's1', batchKey: first.anchor.batchKey, messageIds: ['m1'],
    selection: { seriesId: '口播' }, now: base().now,
  });
  assert.equal(selected.anchor.status, 'proposed');
  assert.equal(selected.anchor.seriesId, '口播');
  assert.equal(selected.episode.status, 'proposed');
});

test('R03 再做一期创建新 episode，继承系列并回到 brief', () => {
  const first = anchor.routeTask(anchor.emptyTasks(), {
    ...base(), selection: { seriesId: '口播' },
  });
  const next = anchor.routeTask(first.tasks, {
    ...base(), messageIds: ['m2'], query: '再做一期口播，讲同一套开场',
  });
  assert.equal(next.decision.kind, 'continuation');
  assert.notEqual(next.anchor.episodeId, first.anchor.episodeId);
  assert.equal(next.anchor.seriesId, '口播');
  assert.equal(next.anchor.phase, 'brief');
  assert.equal(next.episode.previousEpisodeId, first.anchor.episodeId);
  assert.equal(next.episode.status, 'continuable');
});

test('R04 新一期不继承上一期的主题、脚本和临时例外', () => {
  const first = anchor.routeTask(anchor.emptyTasks(), {
    ...base(), selection: { seriesId: '口播' },
  });
  const next = anchor.routeTask(first.tasks, {
    ...base(), messageIds: ['m2'], query: '再来一期',
  });
  for (const key of ['theme', 'script', 'client', 'music', 'exceptions']) {
    assert.equal(next.anchor[key], undefined, `${key} 不应被继承`);
  }
});

test('R05 新会话有明确项目默认时建立 active 锚点', () => {
  const tasks = anchor.setDefault(anchor.emptyTasks(), { seriesId: '口播', taskKind: 'video' });
  const routed = anchor.routeTask(tasks, { ...base(), sessionId: 's2' });
  assert.equal(routed.anchor.status, 'active');
  assert.equal(routed.anchor.seriesId, '口播');
  assert.equal(routed.anchor.taskKind, 'video');
});

test('R06 明确改做别的任务时退出旧焦点，不把视频规则带过去', () => {
  const first = anchor.routeTask(anchor.emptyTasks(), {
    ...base(), selection: { seriesId: '口播' },
  });
  const switched = anchor.routeTask(first.tasks, {
    ...base(), messageIds: ['m2'], query: '改做 README 和计费说明',
  });
  assert.equal(switched.anchor.episodeId === first.anchor.episodeId, false);
  assert.equal(switched.anchor.seriesId, undefined);
  assert.equal(switched.anchor.status, 'unbound');
  assert.equal(switched.decision.switched, true);
});

test('R07 只说谢谢不注入规则，但保留后续可续指针', () => {
  const first = anchor.routeTask(anchor.emptyTasks(), {
    ...base(), selection: { seriesId: '口播' },
  });
  const thanks = anchor.routeTask(first.tasks, { ...base(), messageIds: ['m2'], query: '谢谢！' });
  assert.equal(thanks.decision.kind, 'none');
  assert.equal(thanks.decision.pointer, true);
  const decision = anchor.decideRead({
    mode: 'adaptive', enabled: true, identityConfirmed: true,
    anchor: thanks.anchor, ranges: ['口播'], thanks: true,
  });
  assert.equal(decision.kind, 'none');
});

test('R08 未知阶段的条件只算 needs_context，不当成适用', () => {
  const record = {
    id: 'mem_x', title: '口播开头', applicability: 'conditional',
    conditions: [{ key: 'seriesId', value: '口播' }, { key: 'phase', value: 'editing' }],
  };
  const context = view.trustedContext({ cwd: '/work/demo' }, { seriesId: '口播' });
  const evaluated = view.evaluate(record, context);
  assert.equal(evaluated.state, 'unknown');
  assert.deepEqual(evaluated.missing, ['phase']);
});

test('R09 任务条件键可由已确认绑定进入可信上下文', () => {
  const context = view.trustedContext({ cwd: '/work/demo' }, {
    taskKind: 'video', seriesId: '口播', phase: 'brief',
  });
  assert.equal(context.taskKind, 'video');
  assert.equal(context.seriesId, '口播');
  assert.equal(context.phase, 'brief');
});

test('R10 同一批次重放只生成一个 episode', () => {
  const first = anchor.routeTask(anchor.emptyTasks(), {
    ...base(), selection: { seriesId: '口播' },
  });
  const again = anchor.routeTask(first.tasks, {
    ...base(), selection: { seriesId: '口播' },
  });
  assert.equal(again.anchor.episodeId, first.anchor.episodeId);
  assert.equal(Object.keys(again.tasks.episodes).length, 1);
});

test('R10b 同一延续请求重试只生成一个新 episode', () => {
  const first = anchor.routeTask(anchor.emptyTasks(), {
    ...base(), selection: { seriesId: '口播' },
  });
  const a = anchor.routeTask(first.tasks, { ...base(), messageIds: ['m2', 'm3'], query: '再做一期' });
  const b = anchor.routeTask(a.tasks, { ...base(), messageIds: ['m3', 'm2'], query: '再做一期' });
  assert.equal(b.anchor.episodeId, a.anchor.episodeId);
  assert.equal(Object.keys(b.tasks.episodes).length, 2);
});

test('R11 请求批次只由本轮新人类消息决定', () => {
  assert.equal(anchor.requestBatchKey(['b', 'a']), anchor.requestBatchKey(['a', 'b', 'a']));
  assert.notEqual(anchor.requestBatchKey(['a']), anchor.requestBatchKey(['a', 'b']));
  assert.equal(anchor.requestBatchKey([]), '');
});

test('R12 contextId 带项目摘要，跨项目直接识别', () => {
  const id = anchor.contextIdFor('/work/demo', 'rb_1', 'n');
  assert.equal(anchor.projectTagOf(id), anchor.projectTag('/work/demo'));
  assert.notEqual(anchor.projectTagOf(id), anchor.projectTag('/work/other'));
});

test('R13 未绑定的索引最多三个栏目且不超过 600 字节', () => {
  const decision = anchor.decideRead({
    mode: 'adaptive', enabled: true, identityConfirmed: true, anchor: { status: 'unbound' },
    ranges: ['口播', 'Vlog', '访谈', '广告'],
  });
  assert.equal(decision.ranges.length, 3);
  assert.ok(Buffer.byteLength(decision.ranges.join('、'), 'utf8') <= anchor.TASK_LIMITS.indexBytes);
});

test('R14 实验关闭与身份未确认都不读', () => {
  assert.equal(anchor.decideRead({ mode: 'adaptive', enabled: false, identityConfirmed: true, anchor: { status: 'active' } }).kind, 'none');
  assert.equal(anchor.decideRead({ mode: 'adaptive', enabled: true, identityConfirmed: false, anchor: { status: 'active' } }).kind, 'none');
  assert.equal(anchor.decideRead({ mode: 'off', enabled: true, identityConfirmed: true, anchor: { status: 'active' } }).kind, 'none');
});

test('R15 proposed 自动路径只给索引，前台绑定后才给规则', () => {
  const auto = anchor.decideRead({
    mode: 'adaptive', enabled: true, identityConfirmed: true,
    anchor: { status: 'proposed', seriesId: '口播' }, ranges: ['口播'],
  });
  assert.equal(auto.kind, 'index');
  const bound = anchor.decideRead({
    mode: 'adaptive', enabled: true, identityConfirmed: true, boundForRequest: true,
    anchor: { status: 'proposed', seriesId: '口播' }, ranges: ['口播'],
  });
  assert.equal(bound.kind, 'rules');
});

test('R16 会话指针硬上限 8，超出按最近更新保留', () => {
  let tasks = anchor.emptyTasks();
  for (let i = 0; i < 12; i += 1) {
    const routed = anchor.routeTask(tasks, {
      ...base(), sessionId: `s${i}`, messageIds: [`m${i}`], now: base().now + i * 1000,
    });
    tasks = routed.tasks;
  }
  const normalized = anchor.normalizeTasks(tasks);
  assert.equal(Object.keys(normalized.sessions).length, 8);
  assert.equal(normalized.sessions.s11.seriesId, undefined);
  assert.equal(normalized.sessions.s0, undefined);
});

test('R17 切换任务后旧 episode 不再被当前会话引用', () => {
  const first = anchor.routeTask(anchor.emptyTasks(), {
    ...base(), selection: { seriesId: '口播' },
  });
  const switched = anchor.routeTask(first.tasks, {
    ...base(), messageIds: ['m2'], query: '换个任务，做代码审查',
  });
  assert.notEqual(switched.anchor.episodeId, first.anchor.episodeId);
  assert.equal(switched.tasks.sessions.s1.episodeId, switched.anchor.episodeId);
  assert.equal(switched.tasks.episodes[first.anchor.episodeId].status, 'proposed');
});

test('R18 自由措辞不能把未注册栏目变成已绑定', () => {
  const routed = anchor.routeTask(anchor.emptyTasks(), {
    ...base(), query: '做一期美食节目', registeredSeries: ['口播', 'Vlog'],
  });
  assert.equal(routed.anchor.status, 'unbound');
  assert.equal(routed.anchor.seriesId, undefined);
});

test('R12 无切换词的新任务撤销旧作品绑定，不继承栏目和规则', () => {
  const sessionId = 'sess-r12';
  let tasks = anchor.emptyTasks();
  const first = anchor.routeTask(tasks, {
    sessionId,
    batchKey: 'rb_first',
    messageIds: ['m1'],
    query: '帮我把这期口播视频的开头改一下',
    selection: { seriesId: '口播', taskKind: '口播视频' },
    now: 1000,
  });
  assert.equal(first.anchor.status, 'proposed');
  const bound = anchor.applySelection(first.tasks, { sessionId, selection: { seriesId: '口播' }, batchKey: 'rb_first', messageIds: ['m1'], now: 1500 });
  assert.equal(bound.anchor.status, 'proposed');
  const active = bound.tasks.sessions[sessionId];
  active.status = 'active';
  tasks = bound.tasks;
  const next = anchor.routeTask(tasks, {
    sessionId,
    batchKey: 'rb_next',
    messageIds: ['m2'],
    query: '帮我排查 PostgreSQL 连接超时',
    registeredSeries: ['口播'],
    now: 2000,
  });
  assert.equal(next.anchor.status, 'unbound');
  assert.equal(next.decision.kind, 'unbound');
  assert.equal(next.decision.reason, 'new_task');
  assert.ok(next.episode.previousEpisodeId);

  /** 新任务已撤销旧绑定：旧栏目规则不能再自动进入这一步。 */
  const read = anchor.decideRead({
    enabled: true,
    identityConfirmed: true,
    anchor: next.anchor,
    ranges: [{ seriesId: '口播', taskKind: '口播视频', reason: '旧任务' }],
  });
  assert.equal(read.kind, 'index');
  assert.equal(read.rules, undefined);
});

test('R13 继续改/接着做仍继承同一任务', () => {
  let tasks = anchor.emptyTasks();
  const first = anchor.routeTask(tasks, {
    sessionId: 'sess-r13',
    batchKey: 'rb_a',
    messageIds: ['m1'],
    query: '帮我把这期口播视频的开头改一下',
    selection: { seriesId: '口播' },
    now: 1000,
  });
  tasks = first.tasks;
  const next = anchor.routeTask(tasks, {
    sessionId: 'sess-r13',
    batchKey: 'rb_b',
    messageIds: ['m2'],
    query: '继续改，节奏再快一点',
    now: 2000,
  });
  assert.equal(next.anchor.status, 'continuable');
  assert.equal(next.decision.kind, 'continuation');
});

test('R14 无候选栏目时返回 none，不再要求选栏目', () => {
  const read = anchor.decideRead({ enabled: true, identityConfirmed: true, anchor: null, ranges: [] });
  assert.equal(read.kind, 'none');
  assert.equal(read.reason, 'no_range');
});

/** 已绑定的口播任务：用于验证换任务时旧范围确实被撤销。 */
function activeVideoSession() {
  const first = anchor.routeTask(anchor.emptyTasks(), {
    sessionId: 'sess-switch',
    batchKey: 'rb_video',
    messageIds: ['m1'],
    query: '帮我把这期口播视频的开头改一下',
    selection: { seriesId: '口播', taskKind: '口播视频' },
    now: 1000,
  });
  const anchorState = first.tasks.sessions['sess-switch'];
  anchorState.status = 'active';
  return first.tasks;
}

test('R20 带「继续」但出现新对象时，先撤销旧范围', () => {
  const tasks = activeVideoSession();
  const next = anchor.routeTask(tasks, {
    sessionId: 'sess-switch',
    batchKey: 'rb_pg_continue',
    messageIds: ['m2'],
    query: '接下来继续排查 PostgreSQL 连接超时',
    registeredSeries: ['口播'],
    now: 2000,
  });
  assert.equal(next.decision.kind, 'unbound');
  assert.equal(next.decision.reason, 'new_task');
  assert.equal(next.anchor.seriesId, undefined);
  assert.equal(next.episode.previousEpisodeId, tasks.sessions['sess-switch'].episodeId);
});

test('R21 带「这个」但出现新对象时，不沿用旧范围', () => {
  const tasks = activeVideoSession();
  const next = anchor.routeTask(tasks, {
    sessionId: 'sess-switch',
    batchKey: 'rb_pg_this',
    messageIds: ['m2'],
    query: '现在帮我排查这个 PostgreSQL 连接超时',
    registeredSeries: ['口播'],
    now: 2000,
  });
  assert.equal(next.decision.kind, 'unbound');
  assert.equal(next.decision.reason, 'new_task');
  assert.equal(next.anchor.seriesId, undefined);
});

test('R22 真正的续改保留原任务范围', () => {
  const tasks = activeVideoSession();
  const next = anchor.routeTask(tasks, {
    sessionId: 'sess-switch',
    batchKey: 'rb_video_continue',
    messageIds: ['m2'],
    query: '继续改刚才那版脚本，开头再直接一点',
    registeredSeries: ['口播'],
    now: 2000,
  });
  assert.equal(next.decision.kind, 'continuation');
  assert.equal(next.anchor.seriesId, '口播');
  assert.equal(next.episode.previousEpisodeId, tasks.sessions['sess-switch'].episodeId);
});

test('R22b 短续句「继续优化收敛」不点名新对象，仍算续作', () => {
  const tasks = activeVideoSession();
  const next = anchor.routeTask(tasks, {
    sessionId: 'sess-switch',
    batchKey: 'rb_ellipse',
    messageIds: ['m2'],
    query: '继续优化收敛',
    registeredSeries: ['口播'],
    now: 2000,
  });
  assert.equal(next.decision.kind, 'continuation');
  assert.equal(next.anchor.seriesId, '口播');
  assert.equal(next.episode.previousEpisodeId, tasks.sessions['sess-switch'].episodeId);
});

test('R22c 短续句点名新对象时仍然换任务', () => {
  const tasks = activeVideoSession();
  const next = anchor.routeTask(tasks, {
    sessionId: 'sess-switch',
    batchKey: 'rb_ellipse_obj',
    messageIds: ['m2'],
    query: '继续优化数据库连接池',
    registeredSeries: ['口播'],
    now: 2000,
  });
  assert.equal(next.decision.kind, 'unbound');
  assert.equal(next.decision.reason, 'new_task');
});

test('R23 只指代旧稿的局部修改不被当成换任务', () => {
  const tasks = activeVideoSession();
  const next = anchor.routeTask(tasks, {
    sessionId: 'sess-switch',
    batchKey: 'rb_video_tweak',
    messageIds: ['m2'],
    query: '现在把开头改短一点',
    registeredSeries: ['口播'],
    now: 2000,
  });
  assert.equal(next.decision.kind, 'focus');
  assert.equal(next.anchor.seriesId, '口播');
});

test('R24 继续做新领域的中文任务也算换任务', () => {
  const tasks = activeVideoSession();
  const next = anchor.routeTask(tasks, {
    sessionId: 'sess-switch',
    batchKey: 'rb_research',
    messageIds: ['m2'],
    query: '继续看看竞品定价',
    registeredSeries: ['口播'],
    now: 2000,
  });
  assert.equal(next.decision.kind, 'unbound');
  assert.equal(next.decision.reason, 'new_task');
});

test('R25 单独说「继续」不沿用旧任务范围', () => {
  const tasks = activeVideoSession();
  const previous = tasks.sessions['sess-switch'];
  const next = anchor.routeTask(tasks, {
    sessionId: 'sess-switch',
    batchKey: 'rb_weak_continue',
    messageIds: ['m2'],
    query: '继续',
    registeredSeries: ['口播'],
    now: 2000,
  });
  assert.equal(next.decision.kind, 'unbound');
  assert.equal(next.decision.reason, 'new_task');
  assert.equal(next.anchor.seriesId, undefined);
  assert.equal(next.episode.previousEpisodeId, previous.episodeId);
});

test('R26 单独说「这个」不沿用旧任务范围', () => {
  const tasks = activeVideoSession();
  const next = anchor.routeTask(tasks, {
    sessionId: 'sess-switch',
    batchKey: 'rb_weak_this',
    messageIds: ['m2'],
    query: '这个',
    registeredSeries: ['口播'],
    now: 2000,
  });
  assert.equal(next.decision.kind, 'unbound');
  assert.equal(next.decision.reason, 'new_task');
  assert.equal(next.anchor.seriesId, undefined);
});

test('R27 单独说「之前」不沿用旧任务范围', () => {
  const tasks = activeVideoSession();
  const next = anchor.routeTask(tasks, {
    sessionId: 'sess-switch',
    batchKey: 'rb_weak_before',
    messageIds: ['m2'],
    query: '之前',
    registeredSeries: ['口播'],
    now: 2000,
  });
  assert.equal(next.decision.kind, 'unbound');
  assert.equal(next.decision.reason, 'new_task');
  assert.equal(next.anchor.seriesId, undefined);
});

test('R28 指代加动作的续接仍保留旧任务范围', () => {
  const tasks = activeVideoSession();
  const previous = tasks.sessions['sess-switch'];
  const next = anchor.routeTask(tasks, {
    sessionId: 'sess-switch',
    batchKey: 'rb_strong_continue',
    messageIds: ['m2'],
    query: '把刚才那个再调一下',
    registeredSeries: ['口播'],
    now: 2000,
  });
  assert.notEqual(next.decision.kind, 'unbound');
  assert.equal(next.anchor.episodeId, previous.episodeId);
  assert.equal(next.anchor.seriesId, '口播');
});

test('R29 带「继续改」但对象换成新的英文主题时撤销旧范围', () => {
  const tasks = activeVideoSession();
  const next = anchor.routeTask(tasks, {
    sessionId: 'sess-switch',
    batchKey: 'rb_switch_pg_continue',
    messageIds: ['m2'],
    query: '继续改 PostgreSQL 连接池配置',
    registeredSeries: ['口播'],
    now: 2000,
  });
  assert.equal(next.decision.kind, 'unbound');
  assert.equal(next.decision.reason, 'new_task');
  assert.equal(next.anchor.seriesId, undefined);
});

test('R30 带「调整一下」但对象换了时撤销旧范围', () => {
  const tasks = activeVideoSession();
  const next = anchor.routeTask(tasks, {
    sessionId: 'sess-switch',
    batchKey: 'rb_switch_pg_adjust',
    messageIds: ['m2'],
    query: '调整一下 PostgreSQL 连接池配置',
    registeredSeries: ['口播'],
    now: 2000,
  });
  assert.equal(next.decision.kind, 'unbound');
  assert.equal(next.decision.reason, 'new_task');
});

test('R31 带「继续改」但明确指向新对象动作时撤销旧范围', () => {
  const tasks = activeVideoSession();
  const next = anchor.routeTask(tasks, {
    sessionId: 'sess-switch',
    batchKey: 'rb_switch_db_code',
    messageIds: ['m2'],
    query: '继续改数据库连接超时的处理代码',
    registeredSeries: ['口播'],
    now: 2000,
  });
  assert.equal(next.decision.kind, 'unbound');
  assert.equal(next.decision.reason, 'new_task');
});

/** 复核复现：句首带「继续」不能成为沿用旧正文的通行证。 */
for (const [label, query] of [
  ['R32 继续改数据库连接池配置', '继续改数据库连接池配置'],
  ['R33 继续优化数据库连接池', '继续优化数据库连接池'],
  ['R34 继续写数据库故障报告', '继续写数据库故障报告'],
  ['R35 这个数据库连接池配置怎么改', '这个数据库连接池配置怎么改'],
]) {
  test(`${label}：与旧任务没有对象交集时不继承旧范围`, () => {
    const tasks = activeVideoSession();
    const next = anchor.routeTask(tasks, {
      sessionId: 'sess-switch',
      batchKey: `rb_${label.slice(0, 3)}_db`,
      messageIds: ['m2'],
      query,
      registeredSeries: ['口播'],
      now: 2000,
    });
    assert.equal(next.decision.kind, 'unbound');
    assert.equal(next.decision.reason, 'new_task');
    assert.equal(next.anchor.seriesId, undefined);
  });
}

test('R41 旧稿提到但明确换到排查任务时不再绑定旧栏目', () => {
  const tasks = activeVideoSession();
  for (const query of ['排查 PostgreSQL 连接池故障，旧稿先放着', '这版数据库连接池配置怎么改']) {
    const next = anchor.routeTask(tasks, {
      sessionId: 'sess-switch',
      batchKey: `rb_${query.length}`,
      messageIds: ['m2'],
      query,
      registeredSeries: ['口播'],
      now: 2000,
    });
    assert.equal(next.decision.kind, 'unbound', query);
    assert.equal(next.anchor.seriesId, undefined, query);
  }
});

test('R42 栏目只被提到、否定或搁置时都不算用户选中', () => {
  assert.equal(anchor.seriesChosenBy('把口播开头改一下', '口播'), true);
  assert.equal(anchor.seriesChosenBy('先不做口播了', '口播'), false);
  assert.equal(anchor.seriesChosenBy('不要按口播的规矩来', '口播'), false);
  assert.equal(anchor.seriesChosenBy('日志里提到口播吗', '口播'), false);
  assert.equal(anchor.seriesChosenBy('先放着口播，改数据库', '口播'), false);
});

test('R43 任务类型判断：工程词优先于创作词，纯创作才归 content', () => {
  assert.equal(anchor.taskKindOf('审阅口播插件的源码，修复上下文串扰问题'), 'code');
  assert.equal(anchor.taskKindOf('日志里提到口播'), 'code');
  assert.equal(anchor.taskKindOf('先不做口播，排查 PostgreSQL 连接池故障'), 'code');
  assert.equal(anchor.taskKindOf('再做一期口播'), 'content');
  assert.equal(anchor.taskKindOf('改成口播'), 'content');
  assert.equal(anchor.taskKindOf('帮我看看这个'), '');
  assert.equal(anchor.taskKindOf(''), '');
});

test('R44 栏目名后跟代码对象时只算读源码，不算选中栏目', () => {
  assert.equal(anchor.seriesChosenBy('审阅口播插件的源码，修复上下文串扰问题', '口播'), false);
  assert.equal(anchor.seriesChosenBy('检查口播插件代码', '口播'), false);
  assert.equal(anchor.seriesChosenBy('口播源码里日志有问题', '口播'), false);
  assert.equal(anchor.seriesChosenBy('再做一期口播', '口播'), true);
  assert.equal(anchor.seriesChosenBy('改成口播', '口播'), true);
});

test('R45 明确撤销栏目：先不做口播优先于续作和旧栏目', () => {
  const tasks = activeVideoSession();
  const next = anchor.routeTask(tasks, {
    sessionId: 'sess-switch',
    batchKey: 'rb_revoke',
    messageIds: ['m2'],
    query: '先不做口播，排查 PostgreSQL 连接池故障',
    registeredSeries: ['口播'],
    now: 2000,
  });
  assert.equal(next.decision.kind, 'revoked');
  assert.deepEqual(next.decision.revoked, ['口播']);
  assert.equal(next.anchor.status, 'active');
  assert.equal(next.anchor.seriesId, undefined);
  assert.equal(next.anchor.taskKind, 'code');
  assert.equal(next.episode.taskKind, 'code');
  assert.equal(next.episode.previousEpisodeId, tasks.sessions['sess-switch'].episodeId);
  assert.equal(anchor.revokeSeriesBy('不要按口播的规矩来', ['口播']).length, 0);
  assert.deepEqual(anchor.revokeSeriesBy('先不做口播，排查故障', ['口播', 'Vlog']), ['口播']);
});

test('R46 读源码/提到栏目都不建内容绑定，项目默认值不能趁机补栏目', () => {
  const tasks = anchor.emptyTasks();
  tasks.defaults = { taskKind: 'video', seriesId: '口播' };
  const reading = anchor.routeTask(tasks, {
    sessionId: 'sess-reading', batchKey: 'rb_reading', messageIds: ['m1'],
    query: '审阅口播插件的源码，修复上下文串扰问题', registeredSeries: ['口播'], now: 1000,
  });
  assert.equal(reading.anchor.seriesId, undefined);
  assert.equal(reading.episode.taskKind, 'code');
  assert.notEqual(reading.decision.kind, 'selected');
  assert.notEqual(reading.decision.kind, 'default');

  const mention = anchor.routeTask(tasks, {
    sessionId: 'sess-mention', batchKey: 'rb_mention', messageIds: ['m1'],
    query: '日志里提到口播', registeredSeries: ['口播'], now: 1000,
  });
  assert.equal(mention.anchor.seriesId, undefined);
  assert.equal(mention.anchor.taskKind, 'code');
});

test('R47 项目默认值只补缺失字段，不覆盖显式任务类型和撤销', () => {
  const tasks = anchor.emptyTasks();
  tasks.defaults = { taskKind: 'video', seriesId: '口播' };
  const filled = anchor.routeTask(tasks, {
    sessionId: 'sess-default', batchKey: 'rb_default', messageIds: ['m1'],
    query: '继续改上次那期的开头', registeredSeries: ['口播'], now: 1000,
  });
  assert.equal(filled.decision.kind, 'default');
  assert.equal(filled.anchor.seriesId, '口播');
  assert.equal(filled.anchor.taskKind, 'video');

  const explicit = anchor.routeTask(tasks, {
    sessionId: 'sess-explicit-kind', batchKey: 'rb_explicit_kind', messageIds: ['m1'],
    query: '帮我看看 PostgreSQL 连接池', taskKind: 'code', registeredSeries: ['口播'], now: 1000,
  });
  assert.equal(explicit.anchor.taskKind, 'code');
  assert.equal(explicit.anchor.seriesId, undefined);
  assert.equal(explicit.decision.taskKind, 'code');
  assert.notEqual(explicit.decision.kind, 'default');
});

test('R48 RuntimeContext 形状确定，任务字段来自锚点与本句判断', () => {
  const routed = anchor.routeTask(anchor.emptyTasks(), {
    sessionId: 'sess-ctx', batchKey: 'rb_ctx', messageIds: ['m1'],
    query: '审阅口播插件的源码，修复上下文串扰问题', registeredSeries: ['口播'], now: 1000,
  });
  const ctx = anchor.buildRuntimeContext({
    projectId: '/work/demo', sessionId: 'sess-ctx', batchKey: 'rb_ctx', messageIds: ['m1'],
    controlEpoch: 7, query: '继续看这段代码', anchor: routed.anchor, episode: routed.episode,
  });
  assert.deepEqual(Object.keys(ctx).sort(), ['controlEpoch', 'projectId', 'requestId', 'sessionId', 'task']);
  assert.deepEqual(Object.keys(ctx.task).sort(), ['action', 'actionEvidence', 'artifactKey', 'conflict', 'evidence', 'kind', 'phase', 'seriesEvidence', 'seriesId', 'topic', 'topicEvidence']);
  assert.equal(ctx.projectId, '/work/demo');
  assert.equal(ctx.sessionId, 'sess-ctx');
  assert.equal(ctx.requestId, anchor.contextIdFor('/work/demo', 'rb_ctx', routed.episode.episodeId));
  assert.equal(ctx.controlEpoch, '7');
  assert.equal(ctx.task.kind, 'code');
  assert.equal(ctx.task.seriesId, '');
  assert.equal(ctx.task.phase, 'brief');
  assert.equal(ctx.task.evidence, 'query');

  const inferred = anchor.buildRuntimeContext({
    projectId: '/work/demo', sessionId: 'sess-ctx', batchKey: 'rb_ctx', messageIds: ['m1'],
    query: '审阅口播插件的源码',
  });
  assert.equal(inferred.task.kind, 'code');
  assert.equal(inferred.task.evidence, 'query');
});

test('R49 动作/交付物/话题分开：代码 bug 不把「口播」绑成栏目', () => {
  const query = '口播功能最近有 bug，请修复代码';
  const facets = anchor.taskFacetsOf(query);
  assert.equal(facets.action.kind, 'fix');
  assert.equal(facets.deliverable.kind, 'code');
  assert.equal(facets.topic.text, '口播功能');
  assert.equal(facets.topic.evidence, 'inferred');
  assert.equal(anchor.seriesChosenBy(query, '口播'), false);
  assert.deepEqual(anchor.revokeSeriesBy(query, ['口播']), []);

  const routed = anchor.routeTask(anchor.emptyTasks(), {
    sessionId: 'sess-boundary-fix', batchKey: 'rb_boundary_fix', messageIds: ['m1'],
    query, registeredSeries: ['口播'], now: 1000,
  });
  assert.notEqual(routed.decision.kind, 'selected');
  assert.equal(routed.episode.taskKind, 'code');
  assert.equal(routed.episode.kindEvidence, 'query');
  assert.equal(routed.anchor.seriesId, undefined);
  assert.equal(routed.episode.actionKind, 'fix');

  const ctx = anchor.buildRuntimeContext({
    projectId: '/work/demo', sessionId: 'sess-boundary-fix', batchKey: 'rb_boundary_fix',
    messageIds: ['m1'], query: '继续修', anchor: routed.anchor, episode: routed.episode,
  });
  assert.equal(ctx.task.kind, 'code');
  assert.equal(ctx.task.evidence, 'query');
  assert.equal(ctx.task.seriesId, '');
  assert.equal(ctx.task.action, 'fix');
});

test('R50 内容任务：数据库事务只是话题，口播才是交付栏目', () => {
  const query = '做一期口播，讲解数据库事务，给普通观众听';
  const facets = anchor.taskFacetsOf(query);
  assert.equal(facets.action.kind, 'create');
  assert.equal(facets.deliverable.kind, 'content');
  assert.equal(facets.topic.text, '数据库事务');
  assert.equal(facets.topic.evidence, 'query');
  assert.equal(facets.conflict, false);
  assert.equal(anchor.taskKindOf(query), 'content');
  assert.equal(anchor.seriesChosenBy(query, '口播'), true);
  assert.equal(anchor.seriesChosenBy(query, '数据库'), false);
  assert.equal(anchor.seriesChosenBy(query, '数据库事务'), false);

  const routed = anchor.routeTask(anchor.emptyTasks(), {
    sessionId: 'sess-boundary-content', batchKey: 'rb_boundary_content', messageIds: ['m1'],
    query, registeredSeries: ['口播', '数据库', '数据库事务'], now: 1000,
  });
  assert.equal(routed.decision.kind, 'selected');
  assert.equal(routed.anchor.seriesId, '口播');
  assert.equal(routed.anchor.taskKind, 'content');
  assert.equal(routed.episode.kindEvidence, 'query');
  assert.equal(routed.episode.seriesEvidence, 'query');
  assert.equal(routed.episode.topicText, '数据库事务');
  assert.equal(routed.episode.topicEvidence, 'query');

  /** 落过一次盘之后，query 推断仍不能自升成用户确认。 */
  const ctx = anchor.buildRuntimeContext({
    projectId: '/work/demo', sessionId: 'sess-boundary-content', batchKey: 'rb_boundary_content',
    messageIds: ['m1'], query: '继续', anchor: routed.anchor, episode: routed.episode,
  });
  assert.equal(ctx.task.kind, 'content');
  assert.equal(ctx.task.evidence, 'query');
  assert.equal(ctx.task.seriesEvidence, 'query');
  assert.equal(ctx.task.topic, '数据库事务');
  assert.equal(ctx.task.topicEvidence, 'query');
});

test('R51 句末语气词不是撤销；只有明确的停止动作才撤销栏目', () => {
  const query = '做一期口播吧';
  assert.deepEqual(anchor.revokeSeriesBy(query, ['口播']), []);
  assert.equal(anchor.seriesChosenBy(query, '口播'), true);
  assert.equal(anchor.taskKindOf(query), 'content');

  const routed = anchor.routeTask(anchor.emptyTasks(), {
    sessionId: 'sess-boundary-particle', batchKey: 'rb_boundary_particle', messageIds: ['m1'],
    query, registeredSeries: ['口播'], now: 1000,
  });
  assert.equal(routed.decision.kind, 'selected');
  assert.equal(routed.anchor.seriesId, '口播');
  assert.equal(routed.anchor.taskKind, 'content');
  assert.equal(routed.episode.kindEvidence, 'query');

  for (const soft of ['做一期口播吧', '做一期口播啦', '做一期口播了', '做一期口播吧！']) {
    assert.deepEqual(anchor.revokeSeriesBy(soft, ['口播']), [], soft);
  }
  for (const hard of ['先不做口播了', '口播不做了', '暂停口播', '放一边口播', '口播先不做']) {
    assert.deepEqual(anchor.revokeSeriesBy(hard, ['口播']), ['口播'], hard);
  }
});

test('R52 中英文标点与同义词：代码对象、话题前缀、内容用法都按同一规则', () => {
  for (const query of [
    '口播功能最近有 bug, 请修复代码.',
    '口播模块报错，帮我排查',
    '口播页面有个故障！',
    '口播组件接口流程逻辑都改一下',
  ]) {
    assert.equal(anchor.seriesChosenBy(query, '口播'), false, query);
    assert.equal(anchor.taskKindOf(query), 'code', query);
  }
  for (const soft of ['做一期口播吧!', '做一期口播啦。', '做一期口播了？']) {
    assert.equal(anchor.seriesChosenBy(soft, '口播'), true, soft);
    assert.equal(anchor.taskKindOf(soft), 'content', soft);
  }
  /** 「做一期口播功能」是内容用法，不能因为「功能」就否掉栏目。 */
  assert.equal(anchor.seriesChosenBy('做一期口播功能', '口播'), true);
  assert.equal(anchor.taskKindOf('做一期口播功能'), 'content');

  for (const query of ['做一期口播, 讲解数据库事务, 给普通观众听.', '做一期口播；介绍数据库事务；给普通观众听']) {
    assert.equal(anchor.taskKindOf(query), 'content', query);
    assert.equal(anchor.seriesChosenBy(query, '口播'), true, query);
    assert.equal(anchor.seriesChosenBy(query, '数据库'), false, query);
  }
  for (const query of ['聊聊数据库事务', '主题是数据库事务', '围绕数据库事务讲讲']) {
    assert.equal(anchor.seriesChosenBy(query, '数据库'), false, query);
    assert.equal(anchor.seriesChosenBy(query, '数据库事务'), false, query);
  }

  const conflict = anchor.taskFacetsOf('日志里提到口播，顺便讲数据库事务');
  assert.equal(conflict.conflict, true);
  const routed = anchor.routeTask(anchor.emptyTasks(), {
    sessionId: 'sess-boundary-conflict', batchKey: 'rb_boundary_conflict', messageIds: ['m1'],
    query: '日志里提到口播，顺便讲数据库事务', registeredSeries: ['口播'], now: 1000,
  });
  assert.notEqual(routed.anchor.seriesId, '口播');
  const ctx = anchor.buildRuntimeContext({
    projectId: '/work/demo', sessionId: 'sess-boundary-conflict', batchKey: 'rb_boundary_conflict',
    messageIds: ['m1'], query: '日志里提到口播，顺便讲数据库事务', anchor: routed.anchor, episode: routed.episode,
  });
  assert.equal(ctx.task.conflict, true);
});
