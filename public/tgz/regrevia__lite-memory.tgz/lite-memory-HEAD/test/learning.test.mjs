import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

process.env.DSH_HOME = fs.mkdtempSync(path.join(os.tmpdir(), 'lite-memory-learning-'));
const store = await import('../store.js');
const learning = await import('../learning.js');
const anchor = await import('../anchor.js');
const state = await import('../state.js');
const view = await import('../view.js');

let passed = 0;
const test = (name, fn) => {
  try {
    fn();
    passed += 1;
  } catch (error) {
    console.error(`FAIL ${name}`);
    throw error;
  }
};

const fresh = (label) => {
  const dir = path.join(os.tmpdir(), `lite-memory-learn-${label}-${Math.random().toString(16).slice(2, 8)}`);
  fs.mkdirSync(dir, { recursive: true });
  return store.scopeOf(dir);
};
const evolutionOf = (scope) => store.loadIndex(scope).__evolution;
const ruleRows = (scope) => store.loadIndex(scope).entries.filter((row) => row.origin === 'project_evolution');
const ruleOf = (scope, id) => ruleRows(scope).find((row) => row.id === id);

const enable = (scope, label = 'on') => {
  const result = store.setEvolution(scope, true, { operationId: `on_${label}_${Math.random().toString(16).slice(2, 8)}` });
  assert.equal(result.ok, true, result.reason);
  return result;
};

/** 造一个已绑定作品，返回锚点与落盘后的作品版本。 */
function seedEpisode(scope, overrides = {}) {
  const sessionId = overrides.sessionId || 's1';
  const ids = overrides.messageIds || ['m1'];
  const routed = anchor.routeTask(anchor.emptyTasks(), {
    sessionId,
    projectId: 'proj',
    query: overrides.query || '改一下这期口播开头',
    messageIds: ids,
    batchKey: anchor.requestBatchKey(ids),
    defaults: { taskKind: 'video', seriesId: '口播' },
    now: overrides.now || Date.now(),
  });
  const saved = store.saveTaskState(scope, routed.tasks, { operationId: `tasks_${sessionId}_${Math.random().toString(16).slice(2, 8)}` });
  assert.equal(saved.ok, true, saved.reason);
  return { anchor: routed.anchor, episode: routed.episode, sessionId, messageIds: ids };
}

function begin(scope, grown, overrides = {}) {
  const result = store.beginLearningAttempt(scope, {
    episodeId: grown.episode.episodeId,
    operationId: overrides.operationId || `start_${Math.random().toString(16).slice(2, 10)}`,
    now: overrides.now,
  });
  return result;
}

const NEW_CHANGE = {
  target: 'new',
  feedbackType: 'spec_change',
  topicKey: '口播开头',
  currentText: '开头三句内给结论。',
  applicability: 'conditional',
  conditions: [{ key: 'seriesId', value: '口播' }],
  evidence: ['u0'],
  persistence: 'project_candidate',
};

const RULES = [];
const REFS = { feedback: { u0: 'm1' }, rules: {} };
const RANGES = { taskKinds: ['video'], series: ['口播'] };

function parsed(change, extra = {}) {
  return learning.parseOutput(JSON.stringify({ changes: [change] }), {
    finish: { kind: 'stop' },
    refs: extra.refs || REFS,
    rules: extra.rules || RULES,
    ranges: extra.ranges || RANGES,
  });
}

function commitNew(scope, grown, started, change = NEW_CHANGE, overrides = {}) {
  const check = parsed(change, overrides);
  assert.equal(check.ok, true, check.reason);
  return store.commitLearning(scope, {
    operationId: overrides.operationId || `learn_${Math.random().toString(16).slice(2, 10)}`,
    epoch: started.epoch,
    episodeId: grown.episode.episodeId,
    episodeUpdatedAt: grown.episode.updatedAt,
    projectId: 'proj',
    sessionId: grown.sessionId,
    messageIds: grown.messageIds,
    changes: check.changes,
    preparedTargets: [],
    usage: overrides.usage,
    explicitLongTerm: Boolean(overrides.explicitLongTerm),
    now: overrides.now,
  });
}

/** 对已有规则提交一次样例或检查点变化。 */
function commitExisting(scope, grown, started, id, change, extra = {}) {
  const flat = ruleOf(scope, id);
  const rules = [{ ref: 'r0', id, revision: flat.revision, conditions: flat.conditions }];
  const refs = { feedback: { u0: grown.messageIds[0] }, rules: { r0: id } };
  const check = parsed(change, { rules, refs, ranges: { taskKinds: ['video'], series: ['口播', '字幕'] } });
  assert.equal(check.ok, true, check.reason);
  return store.commitLearning(scope, {
    operationId: extra.operationId || `learn_${Math.random().toString(16).slice(2, 10)}`,
    epoch: started.epoch,
    episodeId: grown.episode.episodeId,
    episodeUpdatedAt: grown.episode.updatedAt,
    projectId: 'proj',
    sessionId: grown.sessionId,
    messageIds: grown.messageIds,
    feedbackText: extra.feedbackText || '',
    dimension: extra.dimension || '',
    changes: check.changes,
    preparedTargets: [{ id, revision: flat.revision, specDigest: flat.learning.specDigest }],
    usage: extra.usage,
  });
}

test('P00 初始任务与致谢不算反馈', () => {
  assert.equal(learning.classifyFeedback('帮我做一期口播，开头要抓人').worth, false);
  assert.equal(learning.classifyFeedback('谢谢').worth, false);
  assert.equal(learning.classifyFeedback('').worth, false);

  /** 问句与「别记这句」都不能变成生效规则：先挡掉再分类。 */
  assert.equal(learning.classifyFeedback('这个边框是不是太粗了？').worth, false);
  assert.equal(learning.classifyFeedback('以后都用圆角吗？').worth, false);
  const refused = learning.classifyFeedback('这条不要记住，也别写进规则');
  assert.equal(refused.worth, false);
  assert.equal(refused.negative, true);
  assert.equal(learning.classifyFeedback('不要存全局').worth, false, '否定记忆本身不是反向规范');
  /** 真正的规范变更仍然认得出来。 */
  assert.equal(learning.classifyFeedback('以后发布都用 dsh-npm，别再用原生 npm').worth, true);
});

test('P00 明确长期要求分类为规范变化', () => {
  const cue = learning.classifyFeedback('以后口播开头都先给结论，别再铺垫');
  assert.equal(cue.worth, true);
  assert.equal(cue.type, 'spec_change');
  assert.equal(cue.explicitLongTerm, true);
  assert.equal(learning.isLongTerm('这次就先这样'), false);
});

test('P00 作品验收不直接形成长期规则', () => {
  const cue = learning.classifyFeedback('这版可以');
  assert.equal(cue.type, 'artifact_accept');
  assert.equal(parsed({ ...NEW_CHANGE, feedbackType: 'artifact_accept' }).ok, false);
});

test('P00 长期声明本身就算规范变化', () => {
  const cue = learning.classifyFeedback('这个项目默认用 pnpm');
  assert.equal(cue.worth, true);
  assert.equal(cue.type, 'spec_change');
  assert.equal(cue.explicitLongTerm, true);
});

test('P00 未绑定的作品可以回落到项目候选', () => {
  const human = (id, text) => ({ id, source: { kind: 'user' }, content: [{ type: 'text', text }] });
  const base = { episodeId: 'ep_x', status: 'active', updatedAt: '2026-01-01T00:00:00.000Z' };
  assert.equal(learning.candidateFrom({ messages: [human('m1', '以后开头先给结论')], anchor: { ...base, status: 'unbound' } }), null);
  const projectCandidate = learning.candidateFrom({
    messages: [human('m2', '以后这个项目默认用 pnpm')],
    anchor: { ...base, status: 'unbound' }, sessionId: 's', projectId: 'p',
  });
  assert.equal(projectCandidate.scope, 'project');
  assert.equal(projectCandidate.episodeId, '');
  assert.equal(projectCandidate.expectedTarget.scope, 'project');
  const correction = learning.candidateFrom({
    messages: [human('m3', '这里改成蓝色')], anchor: { ...base, status: 'unbound' }, projectId: 'p',
  });
  assert.equal(correction.scope, 'project');
  assert.equal(learning.candidateFrom({
    messages: [human('m4', '这次这里改成蓝色')], anchor: { ...base, status: 'unbound' }, projectId: 'p',
  }), null);
  assert.equal(learning.candidateFrom({ messages: [{ id: 'a1', source: { kind: 'assistant' }, content: '收到' }], anchor: base }), null);
  const candidate = learning.candidateFrom({ messages: [human('m1', '以后开头都先给结论，别再铺垫')], anchor: base, sessionId: 's', projectId: 'p' });
  assert.equal(candidate.episodeId, 'ep_x');
  assert.equal(candidate.messageIds[0], 'm1');
  assert.equal(candidate.cue.explicitLongTerm, true);
});

test('B01 调用输入不超过 8 KiB 且只有本地引用', () => {
  const long = '口播开头先给结论，'.repeat(800);
  const input = learning.buildCallInput({
    projectId: 'p'.repeat(200),
    episodeId: 'ep',
    taskKind: 'video',
    seriesId: '口播',
    phase: 'script',
    feedback: { text: long, messageIds: ['m1'], cue: { type: 'spec_change', explicitLongTerm: false } },
    rules: Array.from({ length: 10 }, (_, index) => ({
      id: `mem_${index}`,
      revision: 3,
      title: '标题'.repeat(50),
      summary: '摘要'.repeat(80),
      body: '正文'.repeat(300),
      conditions: [{ key: 'seriesId', value: '口播' }],
      learning: { state: 'trial' },
    })),
    ranges: { taskKinds: ['video'], series: ['口播'] },
  });
  assert.ok(input.bytes <= 8192, `bytes=${input.bytes}`);
  assert.equal(input.rules.length >= 1, true);
  assert.equal(input.rules.length <= 6, true);
  assert.equal(input.prompt.includes(long), false);
  assert.equal(input.refs.feedback.u0, 'm1');
  assert.equal(input.refs.rules.r0, 'mem_0');
  assert.equal(input.messages.length, 1);
  assert.doesNotMatch(input.system, /工具调用/);
});

test('B01 项目层整理输入不带作品身份', () => {
  const input = learning.buildCallInput({
    projectId: 'p',
    episodeId: '',
    feedback: { text: '以后这个项目默认用 pnpm', messageIds: ['m1'], cue: { type: 'spec_change', explicitLongTerm: true }, scope: 'project' },
    rules: [],
  });
  assert.match(input.prompt, /"scope":"project"/);
  assert.doesNotMatch(input.prompt, /"episodeId"/);
  assert.match(input.system, /待确认候选/);
});

test('B01 截断、工具调用、额外字段整批拒绝', () => {
  assert.equal(learning.parseOutput('{"changes":[{"target":"new"', { finish: { kind: 'stop' } }).ok, false);
  assert.equal(learning.parseOutput('<tool>memory_save</tool>', { finish: { kind: 'stop' } }).ok, false);
  assert.equal(learning.parseOutput('{"changes":[],"note":"x"}', { finish: { kind: 'stop' } }).ok, false);
  assert.equal(learning.parseOutput('{"changes":[]}', { finish: { kind: 'length' } }).ok, false);
  assert.equal(learning.parseOutput('{"changes":[]}', { finish: { kind: 'stop' } }).ok, true);
});

test('B01 未知字段和越界条件整批拒绝', () => {
  assert.equal(parsed({ ...NEW_CHANGE, surprise: 1 }).ok, false);
  assert.equal(parsed({ ...NEW_CHANGE, conditions: [{ key: 'taskKind', value: 'podcast' }] }).ok, false);
  assert.equal(parsed({ ...NEW_CHANGE, conditions: [{ key: 'seriesId', value: '直播' }] }).ok, false);
  assert.equal(parsed({ ...NEW_CHANGE, conditions: [{ key: 'seriesId' }] }).ok, false);
  const good = parsed(NEW_CHANGE);
  assert.equal(good.ok, true);
  assert.equal(good.changes[0].topicKey, '口播开头');
});

test('B01 证据必须来自本次反馈且不超过三条', () => {
  assert.equal(parsed({ ...NEW_CHANGE, evidence: ['u9'] }).ok, false);
  assert.equal(parsed({ ...NEW_CHANGE, evidence: [] }).ok, false);
  const refs = { feedback: { u0: 'm1', u1: 'm2', u2: 'm3', u3: 'm4' }, rules: {} };
  assert.equal(parsed({ ...NEW_CHANGE, evidence: ['u0', 'u1', 'u2', 'u3'] }, { refs }).ok, false);
});

test('B02 真实用量与缺失用量区分', () => {
  assert.deepEqual(learning.usageOf([]), { known: false });
  assert.deepEqual(learning.usageOf([{ type: 'text-delta', text: 'x' }]), { known: false });
  const usage = learning.usageOf([{ type: 'usage', inputTokens: 120, outputTokens: 40, cachedInputTokens: 80 }]);
  assert.equal(usage.known, true);
  assert.equal(usage.inputTokens, 120);
  assert.equal(usage.outputTokens, 40);
  assert.equal(usage.cachedInputTokens, 80);
});

test('B05 频次：每作品两次、每项目 24 小时六次，失败也计数', () => {
  const scope = fresh('quota');
  enable(scope);
  const grown = seedEpisode(scope);
  const first = begin(scope, grown);
  assert.equal(first.ok, true, first.reason);
  const second = begin(scope, grown);
  assert.equal(second.ok, true, second.reason);
  const third = begin(scope, grown);
  assert.equal(third.ok, false);
  assert.equal(third.reason, 'episode_limit');
  for (let index = 0; index < 4; index += 1) {
    const other = seedEpisode(scope, { sessionId: `s${index + 2}`, messageIds: [`m${index + 2}`] });
    assert.equal(begin(scope, other).ok, true);
  }
  const overflow = seedEpisode(scope, { sessionId: 's9', messageIds: ['m9'] });
  const blocked = begin(scope, overflow);
  assert.equal(blocked.ok, false);
  assert.equal(blocked.reason, 'project_limit');
});

test('P10 执行没做到时只补检查点，不改规范正文', () => {
  const scope = fresh('checkpoint');
  enable(scope);
  const grown = seedEpisode(scope);
  const started = begin(scope, grown);
  assert.equal(commitNew(scope, grown, started, NEW_CHANGE, { explicitLongTerm: true }).ok, true);
  const id = ruleRows(scope)[0].id;
  const before = ruleOf(scope, id);
  const next = begin(scope, grown);
  const result = commitExisting(scope, grown, next, id, {
    target: 'r0', feedbackType: 'execution_miss', currentText: '交付前先核对开头是否先给结论。', evidence: ['u0'],
  });
  assert.equal(result.ok, true, result.reason);
  const after = ruleOf(scope, id);
  assert.equal(after.body, before.body);
  assert.equal(after.revision, before.revision + 1);
  assert.equal(after.learning.state, 'active');
  assert.equal(after.learning.checkpoints.length, 1);
  assert.match(after.learning.checkpoints[0].text, /核对/);
  assert.equal(after.learning.evidence.length, before.learning.evidence.length);
  assert.equal(after.learning.samples, undefined);
});

test('P11 认可作品只记有限样例，不抬规则证据也不改正文', () => {
  const scope = fresh('sample');
  enable(scope);
  const grown = seedEpisode(scope);
  const started = begin(scope, grown);
  assert.equal(commitNew(scope, grown, started, NEW_CHANGE, { explicitLongTerm: true }).ok, true);
  const id = ruleRows(scope)[0].id;
  const before = ruleOf(scope, id);
  const next = begin(scope, grown);
  const result = commitExisting(scope, grown, next, id, {
    target: 'r0', feedbackType: 'artifact_accept', evidence: ['u0'],
  }, { dimension: '开头' });
  assert.equal(result.ok, true, result.reason);
  const after = ruleOf(scope, id);
  assert.equal(after.body, before.body);
  assert.equal(after.revision, before.revision + 1);
  assert.equal(after.learning.samples.length, 1);
  assert.equal(after.learning.samples[0].dimension, '开头');
  assert.equal(after.learning.samples[0].verified, false);
  assert.equal(after.learning.samples[0].artifactVersion, grown.episode.updatedAt);
  assert.equal(after.learning.evidence.length, before.learning.evidence.length);
  assert.equal(after.learning.supportedEpisodeIds.length, before.learning.supportedEpisodeIds.length);
});

test('P12 样例只能挂已有规则，临时例外仍不形成规则', () => {
  const scope = fresh('sample-new');
  enable(scope);
  const grown = seedEpisode(scope);
  const started = begin(scope, grown);
  const rejected = parsed({
    target: 'new', feedbackType: 'artifact_accept', currentText: '这次就这版。', evidence: ['u0'],
  });
  assert.equal(rejected.ok, false);
  assert.match(rejected.reason, /已有规则/);
  assert.equal(parsed({ target: 'new', feedbackType: 'task_exception', currentText: '这次例外。', evidence: ['u0'] }).ok, false);
  assert.equal(parsed({ target: 'new', feedbackType: 'unclear', currentText: '说不上。', evidence: ['u0'] }).ok, false);
  assert.equal(commitNew(scope, grown, started, NEW_CHANGE).ok, true);
  const id = ruleRows(scope)[0].id;
  const second = begin(scope, grown);
  const exception = parsed({ target: 'r0', feedbackType: 'task_exception', currentText: '这次例外。', evidence: ['u0'] }, {
    rules: [{ ref: 'r0', id, revision: ruleOf(scope, id).revision, conditions: ruleOf(scope, id).conditions }],
    refs: { feedback: { u0: grown.messageIds[0] }, rules: { r0: id } },
  });
  assert.equal(exception.ok, false);
  assert.equal(second.ok, true);
});

test('P13 样例与检查点按上限保留', () => {
  const scope = fresh('sample-caps');
  enable(scope);
  const grown = seedEpisode(scope);
  const started = begin(scope, grown);
  assert.equal(commitNew(scope, grown, started, NEW_CHANGE, { explicitLongTerm: true }).ok, true);
  const id = ruleRows(scope)[0].id;
  for (const dimension of ['开头', '字幕', '节奏', '配乐', '镜头']) {
    assert.equal(commitExisting(scope, grown, { epoch: evolutionOf(scope).epoch }, id, {
      target: 'r0', feedbackType: 'artifact_accept', evidence: ['u0'],
    }, { dimension }).ok, true);
  }
  assert.equal(ruleOf(scope, id).learning.samples.length, 4);
  for (const text of ['检查一。', '检查二。', '检查三。', '检查四。']) {
    assert.equal(commitExisting(scope, grown, { epoch: evolutionOf(scope).epoch }, id, {
      target: 'r0', feedbackType: 'execution_miss', currentText: text, evidence: ['u0'],
    }).ok, true);
  }
  assert.equal(ruleOf(scope, id).learning.checkpoints.length, 3);
});

test('P01 新规则落盘带来源、条件与待复核状态', () => {
  const scope = fresh('commit-new');
  enable(scope);
  const grown = seedEpisode(scope);
  const started = begin(scope, grown);
  const result = commitNew(scope, grown, started, NEW_CHANGE, { explicitLongTerm: true, usage: { known: true, inputTokens: 90, outputTokens: 20 } });
  assert.equal(result.ok, true, result.reason);
  assert.equal(result.touched, 1);
  const rows = ruleRows(scope);
  assert.equal(rows.length, 1);
  const flat = store.loadIndex(scope).entries.find((row) => row.id === rows[0].id);
  assert.equal(flat.conditions[0].value, '口播');
  assert.equal(flat.learning.state, 'active');
  assert.equal(flat.learning.evidence.at(-1).episodeId, grown.episode.episodeId);
  assert.equal(flat.learning.evidence.at(-1).sourceType, 'human_feedback');
  assert.equal(flat.learning.evidence.at(-1).evidenceRef, undefined);
  const ledger = evolutionOf(scope).learning;
  assert.equal(ledger.receipts.at(-1).status, 'applied');
  assert.equal(ledger.receipts.at(-1).usage.inputTokens, 90);
});

test('P01 同一 operationId 重放返回原回执，不重复写', () => {
  const scope = fresh('replay');
  enable(scope);
  const grown = seedEpisode(scope);
  const started = begin(scope, grown);
  const op = 'learn_replay_1';
  const first = commitNew(scope, grown, started, NEW_CHANGE, { operationId: op });
  assert.equal(first.ok, true, first.reason);
  const again = commitNew(scope, grown, started, NEW_CHANGE, { operationId: op });
  assert.equal(again.ok, true);
  assert.equal(again.replayed, true);
  assert.equal(again.receipt.status, 'applied');
  assert.equal(ruleRows(scope).length, 1);
});

test('B06 目标规则版本变了整批拒绝', () => {
  const scope = fresh('stale-target');
  enable(scope);
  const grown = seedEpisode(scope);
  const started = begin(scope, grown);
  assert.equal(commitNew(scope, grown, started, NEW_CHANGE).ok, true);
  const id = ruleRows(scope)[0].id;
  const version = ruleOf(scope, id).revision;
  const rules = [{ ref: 'r0', id, revision: version, conditions: [{ key: 'seriesId', value: '口播' }] }];
  const refs = { feedback: { u0: 'm1' }, rules: { r0: id } };
  const update = { target: 'r0', feedbackType: 'spec_change', currentText: '开头两句内给结论。', evidence: ['u0'] };
  const check = parsed(update, { rules, refs });
  assert.equal(check.ok, true, check.reason);
  const second = begin(scope, grown);
  assert.equal(second.ok, true, second.reason);
  // 另一次整理先改了同一条
  const rival = parsed({ ...update, currentText: '开头一句内给结论。' }, { rules, refs });
  const applied = store.commitLearning(scope, {
    operationId: 'learn_rival',
    epoch: second.epoch,
    episodeId: grown.episode.episodeId,
    episodeUpdatedAt: grown.episode.updatedAt,
    projectId: 'proj',
    sessionId: grown.sessionId,
    messageIds: grown.messageIds,
    changes: rival.changes,
    preparedTargets: [{ id, revision: version, specDigest: ruleOf(scope, id).learning.specDigest }],
  });
  assert.equal(applied.ok, true, applied.reason);
  const stale = store.commitLearning(scope, {
    operationId: 'learn_stale',
    epoch: second.epoch,
    episodeId: grown.episode.episodeId,
    episodeUpdatedAt: grown.episode.updatedAt,
    projectId: 'proj',
    sessionId: grown.sessionId,
    messageIds: grown.messageIds,
    changes: check.changes,
    preparedTargets: [{ id, revision: version, specDigest: ruleOf(scope, id).learning.specDigest }],
  });
  assert.equal(stale.ok, false);
  assert.match(stale.reason, /版本|改过/);
  assert.match(ruleOf(scope, id).body, /一句/);
});

test('P06 作品版本变了旧整理整批作废', () => {
  const scope = fresh('stale-episode');
  enable(scope);
  const grown = seedEpisode(scope);
  const started = begin(scope, grown);
  const later = anchor.routeTask(store.loadIndex(scope).__tasks, {
    sessionId: grown.sessionId,
    projectId: 'proj',
    query: '这期改成另一条',
    messageIds: ['m2'],
    batchKey: anchor.requestBatchKey(['m2']),
    now: Date.now() + 1000,
  });
  store.saveTaskState(scope, later.tasks, { operationId: 'tasks_later' });
  const stale = commitNew(scope, grown, started, NEW_CHANGE, { now: Date.now() + 2000 });
  assert.equal(stale.ok, false);
  assert.match(stale.reason, /换到别的作品|改过这期|失效|没采用/);
  assert.equal(ruleRows(scope).length, 0);
});

test('P05 关闭实验后旧提案不能写入', () => {
  const scope = fresh('off-stale');
  enable(scope);
  const grown = seedEpisode(scope);
  const started = begin(scope, grown);
  store.setEvolution(scope, false, { operationId: 'off_1' });
  const offline = commitNew(scope, grown, started);
  assert.equal(offline.ok, false);
  assert.equal(ruleRows(scope).length, 0);
});

test('P05 epoch 变了旧提案作废', () => {
  const scope = fresh('epoch-stale');
  enable(scope);
  const grown = seedEpisode(scope);
  const started = begin(scope, grown);
  store.setEvolution(scope, false, { operationId: 'off_2' });
  store.setEvolution(scope, true, { operationId: 'on_2' });
  const stale = commitNew(scope, grown, started);
  assert.equal(stale.ok, false);
  assert.match(stale.reason, /重新开启|作废/);
});

test('P02 两个独立作品后升为已生效，单次只到试用', () => {
  const scope = fresh('promote');
  enable(scope);
  const one = seedEpisode(scope, { sessionId: 'a', messageIds: ['a1'] });
  const first = commitNew(scope, one, begin(scope, one), NEW_CHANGE);
  assert.equal(first.ok, true, first.reason);
  let id = ruleRows(scope)[0].id;
  assert.equal(ruleOf(scope, id).learning.state, 'trial');
  const two = seedEpisode(scope, { sessionId: 'b', messageIds: ['b1'] });
  const version = ruleOf(scope, id).revision;
  const rules = [{ ref: 'r0', id, revision: version, conditions: [{ key: 'seriesId', value: '口播' }] }];
  const refs = { feedback: { u0: 'b1' }, rules: { r0: id } };
  const check = parsed({ target: 'r0', feedbackType: 'spec_change', currentText: NEW_CHANGE.currentText, evidence: ['u0'] }, { rules, refs });
  const second = store.commitLearning(scope, {
    operationId: 'learn_promote',
    epoch: begin(scope, two).epoch,
    episodeId: two.episode.episodeId,
    episodeUpdatedAt: two.episode.updatedAt,
    projectId: 'proj',
    sessionId: two.sessionId,
    messageIds: two.messageIds,
    changes: check.changes,
    preparedTargets: [{ id, revision: version, specDigest: ruleOf(scope, id).learning.specDigest }],
  });
  assert.equal(second.ok, true, second.reason);
  id = ruleRows(scope)[0].id;
  assert.equal(ruleOf(scope, id).learning.state, 'active');
  assert.equal(ruleOf(scope, id).learning.supportedEpisodeIds.length, 2);
});

test('D01 撤回过且没有上一版时拒撤回', () => {
  const scope = fresh('undo-empty');
  enable(scope);
  const grown = seedEpisode(scope);
  assert.equal(commitNew(scope, grown, begin(scope, grown)).ok, true);
  const id = ruleRows(scope)[0].id;
  const result = store.undoLearningChange(scope, id, { expectedRevision: ruleOf(scope, id).revision, operationId: 'undo_1' });
  assert.equal(result.ok, false);
  assert.match(result.reason, /上一版/);
});

test('D02 版本对不上就拒绝撤回，旧正文不覆盖新版本', () => {
  const scope = fresh('undo-stale');
  enable(scope);
  const grown = seedEpisode(scope);
  assert.equal(commitNew(scope, grown, begin(scope, grown)).ok, true);
  const id = ruleRows(scope)[0].id;
  const version = ruleOf(scope, id).revision;
  const rules = [{ ref: 'r0', id, revision: version, conditions: [{ key: 'seriesId', value: '口播' }] }];
  const refs = { feedback: { u0: 'm1' }, rules: { r0: id } };
  const check = parsed({ target: 'r0', feedbackType: 'spec_change', currentText: '开头两句内给结论。', evidence: ['u0'] }, { rules, refs });
  const updated = store.commitLearning(scope, {
    operationId: 'learn_undo_newer',
    epoch: begin(scope, grown).epoch,
    episodeId: grown.episode.episodeId,
    episodeUpdatedAt: grown.episode.updatedAt,
    projectId: 'proj',
    sessionId: grown.sessionId,
    messageIds: grown.messageIds,
    changes: check.changes,
    preparedTargets: [{ id, revision: version, specDigest: ruleOf(scope, id).learning.specDigest }],
  });
  assert.equal(updated.ok, true, updated.reason);
  const stale = store.undoLearningChange(scope, id, { expectedRevision: version, operationId: 'undo_stale' });
  assert.equal(stale.ok, false);
  assert.match(stale.reason, /刷新/);
  assert.match(ruleOf(scope, id).body, /两句/);
  const undo = store.undoLearningChange(scope, id, { expectedRevision: ruleOf(scope, id).revision, operationId: 'undo_ok' });
  assert.equal(undo.ok, true, undo.reason);
  assert.match(ruleOf(scope, id).body, /三句/);
  assert.equal(ruleOf(scope, id).learning.state, 'paused');
});

test('D03 负反馈先本地暂停，恢复只回到试用', () => {
  const scope = fresh('pause');
  enable(scope);
  const grown = seedEpisode(scope);
  assert.equal(commitNew(scope, grown, begin(scope, grown)).ok, true);
  const id = ruleRows(scope)[0].id;
  const paused = store.pauseLearningRules(scope, [id], { operationId: 'pause_1', by: 'feedback', reason: 'feedback_pending' });
  assert.equal(paused.ok, true);
  assert.equal(paused.changed, true);
  assert.equal(ruleOf(scope, id).learning.state, 'paused');
  const resumed = store.resumeLearningRule(scope, id, { operationId: 'resume_1' });
  assert.equal(resumed.ok, true, resumed.reason);
  assert.equal(ruleOf(scope, id).learning.state, 'trial');
  assert.equal(ruleOf(scope, id).learning.blockedReason, undefined);
});

test('D05 候选缺值或未知键不写入', () => {
  assert.equal(parsed({ ...NEW_CHANGE, topicKey: undefined }).ok, false);
  assert.equal(parsed({ ...NEW_CHANGE, currentText: undefined }).ok, false);
  assert.equal(parsed({ ...NEW_CHANGE, currentText: 'x'.repeat(241) }).ok, false);
  assert.equal(parsed({ ...NEW_CHANGE, applicability: 'sometimes' }).ok, false);
  assert.equal(parsed({ ...NEW_CHANGE, persistence: 'global' }).ok, false);
});

test('D06 同名规则条件不同就各存一条', () => {
  const scope = fresh('no-merge');
  enable(scope);
  const one = seedEpisode(scope, { sessionId: 'c1', messageIds: ['c1'] });
  assert.equal(commitNew(scope, one, begin(scope, one), NEW_CHANGE).ok, true);
  const two = seedEpisode(scope, { sessionId: 'c2', messageIds: ['c2'] });
  const refs = { feedback: { u0: 'c2' }, rules: {} };
  const changed = { ...NEW_CHANGE, conditions: [{ key: 'phase', value: 'edit' }] };
  const check = learning.parseOutput(JSON.stringify({ changes: [changed] }), { finish: { kind: 'stop' }, refs, rules: [], ranges: RANGES });
  assert.equal(check.ok, true, check.reason);
  const second = store.commitLearning(scope, {
    operationId: 'learn_no_merge',
    epoch: begin(scope, two).epoch,
    episodeId: two.episode.episodeId,
    episodeUpdatedAt: two.episode.updatedAt,
    projectId: 'proj',
    sessionId: two.sessionId,
    messageIds: two.messageIds,
    changes: check.changes,
    preparedTargets: [],
  });
  assert.equal(second.ok, true, second.reason);
  assert.equal(ruleRows(scope).length, 2);
});

test('B06 待确认候选到上限后拒绝新建', () => {
  const scope = fresh('pending-cap');
  enable(scope);
  for (let index = 0; index < learning.LIMITS.pending; index += 1) {
    const grown = seedEpisode(scope, { sessionId: `p${index}`, messageIds: [`pm${index}`] });
    const change = { ...NEW_CHANGE, topicKey: `主题${index}`, applicability: 'unresolved', conditions: [] };
    const result = commitNew(scope, grown, begin(scope, grown), change);
    assert.equal(result.ok, true, `${index}:${result.reason}`);
  }
  const overflow = seedEpisode(scope, { sessionId: 'p99', messageIds: ['pm99'] });
  const blocked = commitNew(scope, overflow, begin(scope, overflow), { ...NEW_CHANGE, topicKey: '主题溢出', applicability: 'unresolved', conditions: [] });
  assert.equal(blocked.ok, false);
  assert.match(blocked.reason, /上限/);
});

test('B06 失败调用只留回执不写正文', () => {
  const scope = fresh('failure');
  enable(scope);
  const grown = seedEpisode(scope);
  const started = begin(scope, grown);
  const result = store.recordLearningFailure(scope, {
    operationId: 'learn_fail_1',
    episodeId: grown.episode.episodeId,
    epoch: started.epoch,
    reason: '整理没有返回内容',
    usage: { known: false },
  });
  assert.equal(result.ok, true, result.reason);
  assert.equal(ruleRows(scope).length, 0);
  const receipt = evolutionOf(scope).learning.receipts.at(-1);
  assert.equal(receipt.status, 'failed');
  assert.equal(receipt.usage.known, false);
  assert.equal(receipt.reason, '整理没有返回内容');
});

test('P07 项目层候选无需作品也能落规则', () => {
  const scope = fresh('project-rule');
  enable(scope);
  const started = store.beginLearningAttempt(scope, { episodeId: '', operationId: 'start_project' });
  assert.equal(started.ok, true, started.reason);
  const check = parsed(NEW_CHANGE);
  assert.equal(check.ok, true, check.reason);
  const result = store.commitLearning(scope, {
    operationId: 'learn_project',
    epoch: started.epoch,
    episodeId: '',
    projectId: scope.key,
    sessionId: 's1',
    messageIds: ['m1'],
    changes: check.changes,
    preparedTargets: [],
  });
  assert.equal(result.ok, true, result.reason);
  assert.equal(ruleRows(scope).length, 1);
  assert.equal(ruleRows(scope)[0].ownerProjectId, scope.key);
  assert.equal(ruleRows(scope)[0].learning.state, 'trial');
});

test('P07 两条同批变化一次写入', () => {
  const scope = fresh('two-changes');
  enable(scope);
  const grown = seedEpisode(scope);
  const check = learning.parseOutput(JSON.stringify({
    changes: [NEW_CHANGE, { ...NEW_CHANGE, topicKey: '口播结尾', currentText: '结尾留一句行动提示。' }],
  }), { finish: { kind: 'stop' }, refs: REFS, rules: [], ranges: RANGES });
  assert.equal(check.ok, true, check.reason);
  const result = store.commitLearning(scope, {
    operationId: 'learn_two',
    epoch: begin(scope, grown).epoch,
    episodeId: grown.episode.episodeId,
    episodeUpdatedAt: grown.episode.updatedAt,
    projectId: 'proj',
    sessionId: grown.sessionId,
    messageIds: grown.messageIds,
    changes: check.changes,
    preparedTargets: [],
  });
  assert.equal(result.ok, true, result.reason);
  assert.equal(result.touched, 2);
  assert.equal(ruleRows(scope).length, 2);
});

test('P08 超过两条变化整批拒绝', () => {
  const scope = fresh('too-many');
  enable(scope);
  const grown = seedEpisode(scope);
  const check = learning.parseOutput(JSON.stringify({
    changes: [NEW_CHANGE, { ...NEW_CHANGE, topicKey: 'b' }, { ...NEW_CHANGE, topicKey: 'c' }],
  }), { finish: { kind: 'stop' }, refs: REFS, rules: [], ranges: RANGES });
  assert.equal(check.ok, false);
  const result = store.commitLearning(scope, {
    operationId: 'learn_many',
    epoch: begin(scope, grown).epoch,
    episodeId: grown.episode.episodeId,
    episodeUpdatedAt: grown.episode.updatedAt,
    projectId: 'proj',
    sessionId: grown.sessionId,
    messageIds: grown.messageIds,
    changes: [NEW_CHANGE, NEW_CHANGE, NEW_CHANGE],
    preparedTargets: [],
  });
  assert.equal(result.ok, false);
  assert.equal(ruleRows(scope).length, 0);
});

test('P09 生命周期清理过期试用但保留固定规则', () => {
  const scope = fresh('lifecycle');
  enable(scope);
  const grown = seedEpisode(scope);
  assert.equal(commitNew(scope, grown, begin(scope, grown)).ok, true);
  const id = ruleRows(scope)[0].id;
  const now = Date.now() + learning.LIMITS.trialMs + 1000;
  const report = store.expireLearning(scope, { operationId: 'expire_1', now });
  assert.equal(report.ok, true, report.reason);
  assert.equal(ruleOf(scope, id).learning.state, 'paused');
  assert.equal(ruleOf(scope, id).learning.blockedReason, 'trial_expired');
  const later = now + learning.LIMITS.pausedMs + 1000;
  store.expireLearning(scope, { operationId: 'expire_2', now: later });
  assert.equal(ruleOf(scope, id), undefined);
});

test('D04 新状态格式不抹掉实验标记', () => {
  const scope = fresh('d04');
  enable(scope);
  const raw = fs.readFileSync(path.join(scope.dir, 'state.json'), 'utf8');
  assert.equal(JSON.parse(raw).format, 'dsh-lite-memory/state@4');
  const oldReader = (text) => {
    const data = JSON.parse(text);
    if (data.format !== 'dsh-lite-memory/state@2') throw new state.StateError('invalid', '旧版不认这个格式');
    return data.payload;
  };
  assert.throws(() => oldReader(raw), /旧版不认/);
  assert.equal(evolutionOf(scope).enabled, true);
  assert.equal(evolutionOf(scope).policyVersion, learning.POLICY_VERSION);
});

test('D07 关闭后仍可查看、固定与删除成果', () => {
  const scope = fresh('manage-off');
  enable(scope);
  const grown = seedEpisode(scope);
  assert.equal(commitNew(scope, grown, begin(scope, grown)).ok, true);
  const id = ruleRows(scope)[0].id;
  const off = store.setEvolution(scope, false, { operationId: 'off_manage' });
  assert.equal(off.ok, true, off.reason);
  const snapshot = store.learningSnapshot(scope);
  assert.equal(snapshot.enabled, false);
  assert.equal(snapshot.rules.some((rule) => rule.id === id), true);
  const pinned = store.pinLearningRule(scope, id, { pinned: true, expectedRevision: ruleOf(scope, id).revision, operationId: 'pin_off' });
  assert.equal(pinned.ok, true, pinned.reason);
  assert.equal(ruleOf(scope, id).learning.pinned, true);
  const removed = store.removeLearningRule(scope, id, { expectedRevision: ruleOf(scope, id).revision, operationId: 'delete_off' });
  assert.equal(removed.ok, true, removed.reason);
  assert.equal(store.loadIndex(scope).archived.some((row) => row.id === id), true);
  assert.equal(store.learningSnapshot(scope).rules.some((rule) => rule.id === id), false);
});

test('D08 删除按预期版本，旧版本不能误删', () => {
  const scope = fresh('delete-stale');
  enable(scope);
  const grown = seedEpisode(scope);
  assert.equal(commitNew(scope, grown, begin(scope, grown)).ok, true);
  const id = ruleRows(scope)[0].id;
  const before = ruleOf(scope, id).revision;
  const stale = store.removeLearningRule(scope, id, { expectedRevision: before - 1, operationId: 'delete_stale' });
  assert.equal(stale.ok, false);
  assert.match(stale.reason, /刷新/);
  const done = store.removeLearningRule(scope, id, { expectedRevision: before, operationId: 'delete_ok' });
  assert.equal(done.ok, true, done.reason);
});

test('D09 用量缺失只报未知，不补零', () => {
  const scope = fresh('economy-unknown');
  enable(scope);
  const grown = seedEpisode(scope);
  assert.equal(store.recordLearningFailure(scope, {
    operationId: 'learn_failed',
    episodeId: grown.episode.episodeId,
    reason: '模型超时',
  }).ok, true);
  const snapshot = store.learningSnapshot(scope);
  assert.equal(snapshot.economy.calls, 1);
  assert.equal(snapshot.economy.knownCalls, 0);
  assert.equal(snapshot.economy.inputTokens, null);
  assert.equal(snapshot.economy.outputTokens, null);
});

test('D10 效果摘要只算最近 64 条，未知用量不补零', () => {
  const scope = fresh('effect-window');
  enable(scope);
  const grown = seedEpisode(scope);
  assert.equal(commitNew(scope, grown, begin(scope, grown), NEW_CHANGE, {
    usage: { known: true, inputTokens: 30, outputTokens: 7 },
  }).ok, true);
  assert.equal(store.recordLearningFailure(scope, { operationId: 'effect_fail', episodeId: grown.episode.episodeId, reason: '模型超时' }).ok, true);
  const first = store.learningSnapshot(scope).effect;
  assert.equal(first.window, 2);
  assert.equal(first.applied, 1);
  assert.equal(first.failed, 1);
  assert.equal(first.knownCalls, 1);
  assert.equal(first.inputTokens, 30);
  for (let i = 0; i < 70; i += 1) {
    assert.equal(store.recordLearningFailure(scope, { operationId: `effect_more_${i}`, episodeId: grown.episode.episodeId, reason: '超时' }).ok, true);
  }
  const after = store.learningSnapshot(scope).effect;
  assert.equal(after.window, 64);
  assert.equal(after.knownCalls, 0);
  assert.equal(after.inputTokens, null);
  assert.equal(after.outputTokens, null);
});

test('L01 没有作品绑定的长期项目要求仍是待确认候选', () => {
  const message = (id, text) => ({ id, source: { kind: 'user' }, content: [{ type: 'text', text }] });
  const candidate = learning.candidateFrom({
    messages: [message('m1', '以后数据库查询都改成参数化查询')],
    anchor: null,
    sessionId: 's1',
    projectId: 'proj_a',
    now: 1000,
  });
  assert.ok(candidate);
  assert.equal(candidate.scope, 'project');
  assert.equal(candidate.state, 'pending');
  assert.equal(candidate.episodeId, '');
  assert.equal(candidate.seriesId, '');
  assert.deepEqual(candidate.messageIds, ['m1']);
  assert.equal(candidate.expectedTarget.scope, 'project');
  assert.equal(candidate.expectedTarget.projectId, 'proj_a');
  assert.equal(candidate.expectedTarget.applicability, 'unresolved');
  assert.match(candidate.sourceExcerpt, /参数化查询/);
  /** 跨项目一律不接收；没有项目身份的裸反馈也不进候选。 */
  assert.equal(learning.candidateFrom({
    messages: [message('m1', '以后数据库查询都改成参数化查询')],
    anchor: { episodeId: 'e0', projectId: 'proj_b', status: 'active' },
    projectId: 'proj_a',
  }), null);
  assert.equal(learning.candidateFrom({ messages: [message('m1', '以后都参数化查询')] }), null);
  /** 短期例外即使没绑定作品也不当项目规范。 */
  assert.equal(learning.candidateFrom({
    messages: [message('m1', '这次开头先别放字幕')],
    anchor: null,
    projectId: 'proj_a',
  }), null);
  /** 有作品绑定仍走作品作用域，且不把项目当成单条栏目。 */
  const bound = learning.candidateFrom({
    messages: [message('m1', '以后字幕都改成底部安全区')],
    anchor: { episodeId: 'e1', projectId: 'proj_a', status: 'active', taskKind: 'video', seriesId: 's1' },
    sessionId: 's1',
    projectId: 'proj_a',
  });
  assert.equal(bound.scope, 'episode');
  assert.equal(bound.episodeId, 'e1');
  assert.equal(bound.expectedTarget.episodeId, 'e1');
  assert.equal(bound.seriesId, 's1');
});

test('L02 先按相关性选规则，再截断，字幕规则不会被挤掉', () => {
  const rows = [];
  for (let index = 0; index < 6; index += 1) {
    rows.push({
      id: `mem_a${index}`, topicKey: `配色${index}`, title: `配色${index}`,
      body: `配色方案${index}`, summary: `配色经验${index}`,
      conditions: [], applicability: 'all_in_scope',
      learning: { state: 'active' }, updated: '2026-01-01T00:00:00.000Z',
    });
  }
  rows.push({
    id: 'mem_sub', topicKey: '字幕样式', title: '字幕样式', body: '字幕放底部安全区',
    summary: '字幕经验', conditions: [{ key: 'seriesId', value: '字幕' }],
    applicability: 'conditional', learning: { state: 'trial' }, updated: '2025-01-01T00:00:00.000Z',
  });
  rows.push({
    id: 'mem_old', topicKey: '标题', title: '标题', body: '标题要短',
    summary: '标题经验', conditions: [], applicability: 'all_in_scope',
    learning: { state: 'pending' }, updated: '2025-01-01T00:00:00.000Z',
  });
  rows.push({
    id: 'mem_bgm', topicKey: '配乐', title: '配乐', body: '配乐低一点',
    summary: '配乐经验', conditions: [], applicability: 'all_in_scope',
    learning: { state: 'active' }, updated: '2025-01-01T00:00:00.000Z',
  });
  rows.push({
    id: 'mem_safe', topicKey: '字幕安全区', title: '字幕安全区', body: '字幕不要贴边',
    summary: '字幕留安全区', conditions: [{ key: 'seriesId', value: '字幕' }],
    applicability: 'conditional', learning: { state: 'active' }, updated: '2024-01-01T00:00:00.000Z',
  });
  const context = { query: '字幕位置太低，以后字幕都放底部安全区', dimensions: ['字幕'] };
  const ranked = learning.rankRules(rows, context);
  assert.equal(ranked[0].id, 'mem_safe');
  assert.equal(ranked[1].id, 'mem_sub');
  const selected = learning.selectRules(rows, { ...context, limit: 6 });
  assert.equal(selected.length, 6);
  assert.equal(selected[0].id, 'mem_safe');
  assert.equal(selected[1].id, 'mem_sub');
  assert.deepEqual(learning.rankRules(rows, context).map((row) => row.id), ranked.map((row) => row.id));
  /** buildCallInput 的输入上限是 6，但字幕规则必须在里面。 */
  const input = learning.buildCallInput({
    projectId: 'proj', episodeId: 'e1', taskKind: 'video', seriesId: '字幕', phase: 'p1',
    feedback: { text: '字幕位置太低，以后字幕都放底部安全区', cue: { dimension: '字幕' }, messageIds: ['m1'] },
    rules: rows, ranges: RANGES,
  });
  assert.ok(input.rules.length <= 6);
  const ids = new Set(Object.values(input.refs.rules));
  assert.ok(ids.has('mem_safe'));
  assert.ok(ids.has('mem_sub'));
});

test('L03 反馈类型限制动作：例外/检查点/认可不能写规范', () => {
  const rules = [{ ref: 'r0', id: 'mem_1', revision: 2, conditions: [{ key: 'seriesId', value: '口播' }] }];
  const refs = { feedback: { u0: 'm1' }, rules: { r0: 'mem_1' } };
  const check = (change) => learning.validateChange(change, { refs, rules, ranges: RANGES });
  assert.equal(check({ ...NEW_CHANGE, target: 'new', feedbackType: 'task_exception' }).ok, false);
  assert.equal(check({ ...NEW_CHANGE, target: 'new', feedbackType: 'unclear' }).ok, false);
  const checkpoint = check({ target: 'r0', feedbackType: 'execution_miss', currentText: '发布前核对字幕安全区', evidence: ['u0'] });
  assert.equal(checkpoint.ok, true, checkpoint.reason);
  const rewritten = check({ target: 'r0', feedbackType: 'execution_miss', currentText: '新正文', title: '新标题' });
  assert.equal(rewritten.ok, false);
  const newAccept = check({ target: 'new', feedbackType: 'aspect_accept', topicKey: '字幕', currentText: '字幕放底部' });
  assert.equal(newAccept.ok, false);
  const accept = check({ target: 'r0', feedbackType: 'aspect_accept', conditions: [{ key: 'seriesId', value: '口播' }], evidence: ['u0'] });
  assert.equal(accept.ok, true, accept.reason);
  const mismatched = check({ target: 'r0', feedbackType: 'aspect_accept', conditions: [{ key: 'seriesId', value: '字幕' }] });
  assert.equal(mismatched.ok, false);
  assert.equal(mismatched.reason, '认可条件与目标规则不一致');
  const rewrite = check({ target: 'r0', feedbackType: 'aspect_accept', currentText: '顺手把正文改了' });
  assert.equal(rewrite.ok, false);
  /** 同类型走 nextLearningState 也不抬状态。 */
  const active = { id: 'mem_1', revision: 2, topicKey: '字幕', body: '字幕放底部', applicability: 'conditional', conditions: [{ key: 'seriesId', value: '口播' }], learning: { state: 'active', supportedEpisodeIds: ['e1', 'e2'], evidence: [] } };
  for (const feedbackType of ['execution_miss', 'aspect_accept', 'artifact_accept', 'task_exception', 'unclear']) {
    const next = learning.nextLearningState({ existing: active, change: { id: 'mem_1', feedbackType }, evidence: { episodeId: 'e3' }, now: 1000 });
    assert.equal(next.state, 'active', feedbackType);
    assert.deepEqual(next.supportedEpisodeIds, ['e1', 'e2'], feedbackType);
    const created = learning.nextLearningState({ existing: null, change: { feedbackType }, evidence: { episodeId: 'e1' }, now: 1000 });
    assert.notEqual(created.state, 'active', feedbackType);
  }
});

test('L03b 明确长期要求整理为空时也留下规则', () => {
  const change = learning.pendingChangeFrom({ text: '以后这个项目默认用 pnpm。', cue: { explicitLongTerm: true } });
  assert.equal(change.target, 'new');
  assert.equal(change.feedbackType, 'spec_change');
  assert.equal(change.currentText, '以后这个项目默认用 pnpm。');
  assert.equal(change.evidence[0], 'u0');
  const check = learning.validateChange(change, { refs: { feedback: { u0: 'm1' }, rules: {} }, rules: [], ranges: RANGES });
  assert.equal(check.ok, true, check.reason);
  assert.equal(learning.pendingChangeFrom({ text: '   ' }), null);
});

test('L03c 兜底不把没说范围的要求抬成全项目规则', () => {
  const vague = learning.pendingChangeFrom({ text: '以后口播开头先给结论。', cue: { explicitLongTerm: true } });
  assert.equal(vague.applicability, 'unresolved');
  /** 「所有口播」限定的是栏目对象，不是整个项目；没有可信栏目就留待确认，不能扩成全项目。 */
  const allLines = learning.pendingChangeFrom({ text: '以后所有口播都先给结论。', cue: { explicitLongTerm: true } });
  assert.equal(allLines.applicability, 'unresolved', '「所有口播」不能当全项目授权');
  const always = learning.pendingChangeFrom({ text: '以后一律先给结论。', cue: { explicitLongTerm: true } });
  assert.equal(always.applicability, 'unresolved', '「一律」不能单独当项目范围');
  assert.deepEqual(vague.conditions, []);
  const scoped = learning.pendingChangeFrom({ text: '以后口播开头先给结论。', cue: { explicitLongTerm: true, taskKind: 'video' } });
  assert.equal(scoped.applicability, 'conditional');
  assert.deepEqual(scoped.conditions, [{ key: 'taskKind', value: 'video' }]);
  const global = learning.pendingChangeFrom({ text: '以后这个项目默认用 pnpm。', cue: { explicitLongTerm: true } });
  assert.equal(global.applicability, 'all_in_scope');
  assert.deepEqual(global.conditions, []);
});

test('L03d 作用域在收集时固定，整理只能沿用或收窄', () => {
  const human = (id, text) => ({ id, source: { kind: 'user' }, content: [{ type: 'text', text }] });
  const anchor = { episodeId: 'ep_x', status: 'unbound', updatedAt: '2026-01-01T00:00:00.000Z' };
  const narrow = learning.candidateFrom({ messages: [human('m1', '以后开头先给结论')], anchor, projectId: 'p' });
  assert.equal(narrow.expectedTarget.applicability, 'unresolved');
  const wide = learning.candidateFrom({ messages: [human('m2', '以后这个项目默认用 pnpm')], anchor, projectId: 'p' });
  assert.equal(wide.expectedTarget.applicability, 'all_in_scope');

  const refs = { feedback: { u0: 'm1' }, rules: {} };
  const base = { target: 'new', feedbackType: 'spec_change', topicKey: '开头', currentText: '开头先给结论', evidence: ['u0'] };
  const needsScope = learning.validateChange({ ...base, applicability: 'all_in_scope' }, { refs, rules: [], ranges: RANGES, expectedTarget: narrow.expectedTarget });
  assert.equal(needsScope.ok, false);
  assert.match(needsScope.reason, /不能.*全项目/);
  assert.equal(learning.validateChange({ ...base, applicability: 'unresolved' }, { refs, rules: [], ranges: RANGES, expectedTarget: narrow.expectedTarget }).ok, true);
  assert.equal(learning.validateChange({ ...base, applicability: 'all_in_scope' }, { refs, rules: [], ranges: RANGES, expectedTarget: wide.expectedTarget }).ok, true);

  const video = { scope: 'episode', episodeId: 'ep_x', taskKind: 'video' };
  /** 作品里学到的规范：想说成全项目时收窄成任务条件，而不是整条作废。 */
  const episodeWide = learning.validateChange({ ...base, applicability: 'all_in_scope' }, { refs, rules: [], ranges: RANGES, expectedTarget: video });
  assert.equal(episodeWide.ok, true, episodeWide.reason);
  assert.equal(episodeWide.change.applicability, 'conditional');
  assert.deepEqual(episodeWide.change.conditions, [{ key: 'taskKind', value: 'video' }]);
  const droppedKind = learning.validateChange({ ...base, applicability: 'conditional', conditions: [{ key: 'phase', value: 'script' }] }, { refs, rules: [], ranges: RANGES, expectedTarget: video });
  assert.equal(droppedKind.ok, true, droppedKind.reason);
  assert.deepEqual(droppedKind.change.conditions, [{ key: 'phase', value: 'script' }, { key: 'taskKind', value: 'video' }], '缺的任务范围自动补回，不能丢');
  const keptKind = learning.validateChange({ ...base, applicability: 'conditional', conditions: [{ key: 'taskKind', value: 'video' }, { key: 'phase', value: 'script' }] }, { refs, rules: [], ranges: RANGES, expectedTarget: video });
  assert.equal(keptKind.ok, true, keptKind.reason);
  assert.deepEqual(keptKind.change.conditions, [{ key: 'taskKind', value: 'video' }, { key: 'phase', value: 'script' }]);

  const fallback = learning.pendingChangeFrom({ text: '以后所有开头都先给结论。', cue: { explicitLongTerm: true }, expectedTarget: narrow.expectedTarget });
  assert.equal(fallback.applicability, 'unresolved', '兜底不重新推导作用域');
  assert.equal(learning.pendingChangeFrom({ text: '以后开头都先给结论。', cue: { explicitLongTerm: true }, expectedTarget: wide.expectedTarget }).applicability, 'all_in_scope');
});

test('L03d2 代码任务学到的规则不会在数据库任务里生效', () => {
  const refs = { feedback: { u0: 'm1' }, rules: {} };
  const parsed = learning.parseOutput(JSON.stringify({
    changes: [{
      target: 'new', feedbackType: 'spec_change', topicKey: '迁移',
      currentText: '先跑迁移再改代码', applicability: 'all_in_scope', evidence: ['u0'],
    }],
  }), {
    finish: { kind: 'stop' }, refs, rules: [], ranges: { ...RANGES, taskKinds: ['code', 'database'] },
    expectedTarget: { scope: 'episode', projectId: 'p', episodeId: 'ep_code', taskKind: 'code' },
  });
  assert.equal(parsed.ok, true, parsed.reason);
  const change = parsed.changes[0];
  assert.equal(change.applicability, 'conditional');
  assert.deepEqual(change.conditions, [{ key: 'taskKind', value: 'code' }]);
  const code = view.eligibility({ id: 'mem_1', title: '迁移', status: 'active', origin: 'project_evolution', conditions: change.conditions, learning: { state: 'active' } }, { task: { kind: 'code' } }, 'auto');
  const db = view.eligibility({ id: 'mem_1', title: '迁移', status: 'active', origin: 'project_evolution', conditions: change.conditions, learning: { state: 'active' } }, { task: { kind: 'database' } }, 'auto');
  assert.equal(code.ok, true);
  assert.equal(db.ok, false);
  assert.equal(db.reason, 'condition_mismatch');
});

test('L03d3 空项目的第一条反馈能带上真实任务范围保存', () => {
  const parsed = learning.parseOutput(JSON.stringify({
    changes: [{
      target: 'new', feedbackType: 'spec_change', topicKey: '前端边框',
      currentText: '前端页面默认采用细边框', applicability: 'all_in_scope', evidence: ['u0'],
    }],
  }), {
    finish: { kind: 'stop' }, refs: { feedback: { u0: 'm1' }, rules: {} }, rules: [],
    ranges: { taskKinds: [], series: [], projects: ['p'] },
    expectedTarget: { scope: 'episode', projectId: 'p', episodeId: 'ep1', taskKind: 'code', phase: 'brief' },
  });
  assert.equal(parsed.ok, true, parsed.reason);
  assert.equal(parsed.changes[0].applicability, 'conditional');
  assert.deepEqual(parsed.changes[0].conditions, [{ key: 'taskKind', value: 'code' }], '采集阶段不该锁死长期适用范围');
});

test('L03d4 模型条件与采集任务范围冲突时拒绝，不生成永不生效的规则', () => {
  const parsed = learning.parseOutput(JSON.stringify({
    changes: [{
      target: 'new', feedbackType: 'spec_change', topicKey: '迁移',
      currentText: '先跑迁移再改代码', applicability: 'conditional',
      conditions: [{ key: 'taskKind', value: 'database' }], evidence: ['u0'],
    }],
  }), {
    finish: { kind: 'stop' }, refs: { feedback: { u0: 'm1' }, rules: {} }, rules: [],
    ranges: { ...RANGES, taskKinds: ['code', 'database'] },
    expectedTarget: { scope: 'episode', projectId: 'p', episodeId: 'ep1', taskKind: 'code' },
  });
  assert.equal(parsed.ok, false);
  assert.match(parsed.reason, /冲突/);
});

test('L03d5 同一条件键的两个值不能都留下', () => {
  const parsed = learning.parseOutput(JSON.stringify({
    changes: [{
      target: 'new', feedbackType: 'spec_change', topicKey: '阶段冲突',
      currentText: '只在脚本阶段生效', applicability: 'conditional',
      conditions: [{ key: 'phase', value: 'script' }, { key: 'phase', value: 'brief' }], evidence: ['u0'],
    }],
  }), {
    finish: { kind: 'stop' }, refs: { feedback: { u0: 'm1' }, rules: {} }, rules: [],
    ranges: { ...RANGES },
    expectedTarget: { scope: 'episode', projectId: 'p', episodeId: 'ep1', taskKind: 'code', phase: 'brief' },
  });
  assert.equal(parsed.ok, false);
  assert.match(parsed.reason, /条件/);
});

test('L03e 先按相关性排序再截断，输入顺序不挤掉真正相关的旧规则', () => {
  const rules = [];
  for (let index = 0; index < 32; index += 1) {
    rules.push({
      id: `mem_${String(index).padStart(2, '0')}`,
      state: 'active',
      updated: `2026-01-${String((index % 28) + 1).padStart(2, '0')}T00:00:00.000Z`,
      title: index === 31 ? '字幕字号' : `无关规则${index}`,
      summary: '',
      body: index === 31 ? '字幕固定 32 号' : '',
      conditions: [],
    });
  }
  const selected = learning.selectRules(rules, { query: '字幕太小了，改大一点', dimensions: ['字幕'], limit: 6 });
  assert.equal(selected.length, 6);
  assert.ok(selected.some((row) => row.id === 'mem_31'), '相关但排在最后的规则要进候选');
  assert.equal(learning.selectRules(rules, { limit: 32 }).length, 32, '候选池上限是 32 条，不是先砍到 6 条');
});

test('L03f 整理器规则先按状态和最近使用排序再取 8 条', () => {
  const rules = [];
  for (let index = 0; index < 12; index += 1) {
    rules.push({
      id: `mem_${String(index).padStart(2, '0')}`,
      state: index === 11 ? 'active' : index === 10 ? 'trial' : 'paused',
      updatedAt: `2026-01-${String(index + 1).padStart(2, '0')}T00:00:00.000Z`,
      title: `规则${index}`,
    });
  }
  const ordered = learning.orderOrganizerRules(rules);
  assert.equal(ordered.length, learning.LIMITS.organizerRules);
  assert.equal(ordered[0].id, 'mem_11', '生效规则优先于暂停规则');
  assert.equal(ordered[1].id, 'mem_10', '试用规则排在暂停之前');
});

test('L04 先算目标状态再查配额，过期候选可恢复', () => {
  const base = { existing: null, evidence: { episodeId: 'e1', messageIds: ['m1'], sourceExcerpt: '以后都用参数化查询' }, pending: 12, rules: 0, now: 1000 };
  const active = learning.admitChange({ ...base, change: NEW_CHANGE, explicitLongTerm: true });
  assert.equal(active.ok, true, active.reason);
  assert.equal(active.learning.state, 'active');
  assert.equal(active.merged.current.body, NEW_CHANGE.currentText);
  const candidate = learning.admitChange({
    ...base,
    pending: 12,
    change: { ...NEW_CHANGE, conditions: [], applicability: 'unresolved' },
  });
  assert.equal(candidate.ok, false);
  assert.equal(candidate.reason, '待确认候选已经到上限');
  const full = learning.admitChange({ ...base, rules: learning.LIMITS.rules, pending: 0, change: NEW_CHANGE });
  assert.equal(full.ok, false);
  assert.equal(full.reason, '项目实验规则已经到上限');
  const existing = {
    id: 'mem_1', revision: 3, topicKey: '口播开头', body: '开头三句内给结论。',
    applicability: 'conditional', conditions: [{ key: 'seriesId', value: '口播' }],
    learning: {
      state: 'trial',
      specDigest: learning.specDigestOf({ topicKey: '口播开头', body: '开头三句内给结论。', applicability: 'conditional', conditions: [{ key: 'seriesId', value: '口播' }] }),
      supportedEpisodeIds: [],
      evidence: [],
    },
  };
  const update = learning.admitChange({
    existing, change: { ...NEW_CHANGE, target: 'r0' }, evidence: { episodeId: 'e2' }, pending: 99, rules: 99, now: 1000,
  });
  assert.equal(update.ok, true, update.reason);
  assert.equal(update.learning.state, 'trial');
  /** 过期待确认既不是永久候选，也不该被删；能重新唤起，且不占有效名额。 */
  const stale = { id: 'mem_stale', origin: 'project_evolution', learning: { state: 'pending', createdAt: new Date(1000).toISOString() } };
  const now = 1000 + learning.LIMITS.trialMs + 1000;
  assert.equal(learning.candidateExpired(stale.learning, now), true);
  assert.equal(learning.pendingCount([stale], now), 0);
  assert.equal(learning.pendingCount([stale], 1000), 1);
  const plan = learning.lifecycle([stale], now);
  assert.deepEqual(plan.purge, []);
  assert.deepEqual(plan.recoverable, ['mem_stale']);
  const revived = learning.reviveCandidate(stale.learning, { now });
  assert.equal(revived.state, 'pending');
  assert.equal(learning.candidateExpired(revived, now), false);
});

test('L05 规范或目标变了旧证据清零，来源与版本绑定留在规则上', () => {
  const conditions = [{ key: 'seriesId', value: '口播' }];
  const body = '开头三句内给结论。';
  const existing = {
    id: 'mem_1', revision: 4, topicKey: '口播开头', title: '口播开头', body,
    applicability: 'conditional', conditions,
    learning: {
      state: 'active', specDigest: learning.specDigestOf({ topicKey: '口播开头', body, applicability: 'conditional', conditions }),
      supportedEpisodeIds: ['e1', 'e2'],
      evidence: [{ episodeId: 'e1' }, { episodeId: 'e2' }],
      samples: [{ episodeId: 'e1', dimension: '字幕' }],
    },
  };
  const evidence = { episodeId: 'e3', messageIds: ['m1', 'm2', 'm3', 'm4'], sourceExcerpt: '原始反馈：以后开头先给结论' };
  const changed = learning.nextLearningState({
    existing,
    change: { id: 'mem_1', currentText: '开头五句内给结论。', feedbackType: 'spec_change' },
    evidence: { ...evidence, explicitLongTerm: true },
    specChanged: true,
    now: 2000,
  });
  assert.deepEqual(changed.supportedEpisodeIds, ['e3']);
  assert.equal(changed.evidence.length, 1);
  assert.equal(changed.evidenceResetReason, 'spec_changed');
  assert.equal(changed.samples, undefined);
  assert.equal(changed.sourceExcerpt, evidence.sourceExcerpt);
  assert.deepEqual(changed.binding.messageIds, ['m2', 'm3', 'm4']);
  assert.equal(changed.binding.targetId, 'mem_1');
  assert.equal(changed.binding.baseRevision, 4);
  assert.equal(changed.state, 'active');
  /** 没有规范变化时保留证据，只追加本次作品。 */
  const kept = learning.nextLearningState({
    existing,
    change: { id: 'mem_1', currentText: body, feedbackType: 'spec_change' },
    evidence: { episodeId: 'e9', sourceExcerpt: '补充' },
    specChanged: false,
    now: 2000,
  });
  assert.deepEqual(kept.supportedEpisodeIds, ['e1', 'e2', 'e9']);
  assert.equal(kept.evidenceResetReason, undefined);
  /** 目标对象换了也清零。 */
  const retargeted = learning.nextLearningState({
    existing,
    change: { id: 'mem_2', feedbackType: 'spec_change' },
    evidence: { episodeId: 'e3' },
    specChanged: false,
    now: 2000,
  });
  assert.deepEqual(retargeted.supportedEpisodeIds, ['e3']);
  assert.equal(retargeted.evidenceResetReason, 'target_changed');
});

test('L06 运行上下文只认传入身份，未绑定的 episodeId 不挡项目候选', () => {
  const message = (id, text) => ({ id, source: { kind: 'user' }, content: [{ type: 'text', text }] });
  const messages = [message('m1', '以后数据库查询都改成参数化查询')];
  const runtime = learning.runtimeContextOf({
    projectId: 'proj_a',
    sessionId: 's1',
    requestId: 'req_1',
    anchor: { episodeId: 'e1', status: 'active', projectId: 'proj_a', taskKind: 'video', seriesId: '口播', phase: 'script' },
  });
  assert.deepEqual(
    [runtime.projectId, runtime.sessionId, runtime.requestId, runtime.episodeId, runtime.bound],
    ['proj_a', 's1', 'req_1', 'e1', true],
  );
  const unbound = learning.runtimeContextOf({ projectId: 'proj_a', anchor: { episodeId: 'e9', status: 'unbound', projectId: 'proj_a' } });
  assert.equal(unbound.bound, false);
  assert.equal(unbound.episodeId, 'e9');
  /** 未绑定但任务里留着 episodeId：仍按项目候选收集，而不是「绑定失效」整条丢掉。 */
  for (const anchorRow of [
    { episodeId: 'e9', status: 'unbound', projectId: 'proj_a' },
    { episodeId: 'e9', projectId: 'proj_a' },
    { episodeId: 'e9', status: 'paused', projectId: 'proj_a' },
  ]) {
    const candidate = learning.candidateFrom({ messages, anchor: anchorRow, projectId: 'proj_a', sessionId: 's1', now: 1000 });
    assert.ok(candidate, JSON.stringify(anchorRow));
    assert.equal(candidate.scope, 'project', JSON.stringify(anchorRow));
    assert.equal(candidate.episodeId, '');
    assert.equal(candidate.projectId, 'proj_a');
  }
  /** 上下文之外的任何身份都不补：没传项目就是没有。 */
  assert.equal(learning.runtimeContextOf({ anchor: { episodeId: 'e1', status: 'active' } }).projectId, '');
  assert.equal(learning.candidateFrom({ messages }), null);
});

test('L07 sourceExcerpt 从候选到调用输入到兜底变化全程不丢', () => {
  const message = (id, text) => ({ id, source: { kind: 'user' }, content: [{ type: 'text', text }] });
  const text = '以后字幕都改成底部安全区，别再顶到画面中间';
  const candidate = learning.candidateFrom({
    messages: [message('m1', text), message('m2', '这期先这样')],
    anchor: { episodeId: 'e1', status: 'active', projectId: 'proj_a' },
    projectId: 'proj_a',
    sessionId: 's1',
    now: 1000,
  });
  assert.ok(candidate);
  assert.match(candidate.sourceExcerpt, /底部安全区/);
  const input = learning.buildCallInput({
    projectId: 'proj_a',
    episodeId: 'e1',
    feedback: candidate,
    rules: [],
    ranges: RANGES,
  });
  assert.equal(input.overLimit, undefined);
  assert.equal(input.sourceExcerpt, candidate.sourceExcerpt);
  assert.deepEqual(input.messageIds, ['m1', 'm2']);
  const rendered = JSON.parse(input.prompt);
  assert.equal(rendered.feedback.sourceExcerpt, candidate.sourceExcerpt);
  assert.deepEqual(rendered.feedback.messageIds, ['m1', 'm2']);
  assert.deepEqual(input.refs.feedback, { u0: 'm1' });
  /** 整理器返回空时的兜底变化也带着同一段来源。 */
  const change = learning.pendingChangeFrom(candidate);
  assert.equal(change.sourceExcerpt, candidate.sourceExcerpt);
  const checked = learning.validateChange(change, { refs: input.refs, rules: [], ranges: RANGES });
  assert.equal(checked.ok, true, checked.reason);
  assert.equal(checked.change.sourceExcerpt, candidate.sourceExcerpt);
  assert.equal(learning.pendingChangeFrom({ text: '   ' }), null);
});

test('L08 admissionOf 统一收集与展示，启发式推断不等于用户确认', () => {
  const message = (id, text) => ({ id, source: { kind: 'user' }, content: [{ type: 'text', text }] });
  const bound = learning.candidateFrom({
    messages: [message('m1', '以后字幕都改成底部安全区')],
    anchor: { episodeId: 'e1', status: 'active', projectId: 'proj_a', taskKind: 'video' },
    projectId: 'proj_a',
    sessionId: 's1',
    now: 1000,
  });
  for (const purpose of ['collect', 'display']) {
    const admission = learning.admissionOf(bound, {
      projectId: 'proj_a',
      sessionId: 's1',
      anchor: { episodeId: 'e1', status: 'active', projectId: 'proj_a' },
    }, purpose);
    assert.equal(admission.ok, true, admission.reason);
    assert.equal(admission.scope, 'episode');
    assert.equal(admission.episodeId, 'e1');
    assert.equal(admission.confirmed, false);
    assert.equal(admission.requiresUserConfirmation, true);
    assert.equal(admission.persistence, 'project_candidate');
    assert.equal(admission.visibility, 'candidate');
  }
  /** 明确长期要求也只是候选：用户说过“以后”，不等于点过“记住”。 */
  const longTerm = learning.candidateFrom({
    messages: [message('m1', '以后数据库查询都改成参数化查询')],
    anchor: null,
    projectId: 'proj_a',
    now: 1000,
  });
  assert.equal(learning.admissionOf(longTerm, { projectId: 'proj_a' }).confirmed, false);
  /** 未绑定但带着 episodeId 的任务：作品候选失效，项目候选照常准入。 */
  const unbound = learning.admissionOf(bound, {
    projectId: 'proj_a',
    anchor: { episodeId: 'e1', status: 'unbound', projectId: 'proj_a' },
  });
  assert.equal(unbound.ok, false);
  assert.equal(unbound.reason, '作品绑定已经失效');
  assert.equal(learning.admissionOf({ ...longTerm }, {
    projectId: 'proj_a',
    anchor: { episodeId: 'e9', status: 'unbound', projectId: 'proj_a' },
  }).ok, true);
  assert.equal(learning.admissionOf({ ...bound, confirmed: true }, {
    projectId: 'proj_a',
    anchor: { episodeId: 'e1', status: 'active', projectId: 'proj_a' },
  }).requiresUserConfirmation, false);
  assert.equal(learning.admissionOf(bound, { projectId: 'proj_a', anchor: { episodeId: 'e1', status: 'active' } }, 'commit').ok, false);
  assert.equal(learning.admissionOf(null).ok, false);
  assert.equal(learning.admissionOf(bound, { projectId: 'proj_b', anchor: { episodeId: 'e1', status: 'active' } }).ok, false);
});

test('L09 项目滚动额度与单次去重分离，开关不重置已用额度', () => {
  let ledger = {};
  const base = Date.parse('2026-01-01T00:00:00.000Z');
  /** 同一期最多两次：去重按 episode 行记，滚动 recent 清空也不放宽。 */
  ledger = learning.recordAttempt(ledger, { episodeId: 'e1', now: base });
  assert.equal(learning.quota(ledger, { episodeId: 'e1', now: base }).ok, true);
  ledger = learning.recordAttempt(ledger, { episodeId: 'e1', now: base + 1000 });
  const episodeLimit = learning.quota(ledger, { episodeId: 'e1', now: base + 2000 });
  assert.equal(episodeLimit.reason, 'episode_limit');
  assert.equal(episodeLimit.episodeCount, learning.LIMITS.attemptsPerEpisode);
  /** 模拟实验关开：state.applyEvolution 会清空 recent，attempts 保留。 */
  const toggled = { ...learning.recordAttempt(ledger, { episodeId: 'e2', now: base + 3000 }), recent: [] };
  assert.equal(learning.quota(toggled, { episodeId: 'e1', now: base + 4000 }).reason, 'episode_limit');
  assert.equal(learning.quota(toggled, { episodeId: 'e2', now: base + 4000 }).episodeCount, 1);
  /** 跨作品项目上限按窗口内总次数算，不依赖 recent。 */
  let project = {};
  for (const episodeId of ['p1', 'p1', 'p2', 'p2', 'p3', 'p3']) {
    project = learning.recordAttempt(project, { episodeId, now: base });
  }
  project = { ...project, recent: [] };
  const window = learning.attemptWindowOf(project, { now: base + 1000 });
  assert.equal(window.projectCount, learning.LIMITS.attemptsPerProject);
  assert.equal(learning.quota(project, { episodeId: 'p4', now: base + 1000 }).reason, 'project_limit');
  /** 只按窗口自然衰减，不因开关或去重重置。 */
  const later = base + learning.LIMITS.windowMs + 1;
  assert.equal(learning.quota(project, { episodeId: 'p4', now: later }).ok, true);
  assert.equal(learning.attemptWindowOf(project, { now: later }).projectCount, 0);
  /** 项目层候选按 project:<key> 记账：不能被“每期两次”终身卡死，只受滚动项目额度约束。 */
  let pseudo = {};
  for (let index = 0; index < 3; index += 1) pseudo = learning.recordAttempt(pseudo, { episodeId: 'project:proj_a', now: base + index });
  const pseudoQuota = learning.quota(pseudo, { episodeId: 'project:proj_a', now: base + 10 });
  assert.equal(pseudoQuota.ok, true, JSON.stringify(pseudoQuota));
  assert.equal(pseudoQuota.episodeCount, 0);
  assert.equal(learning.quota(pseudo, { episodeId: '', now: base + 10 }).ok, true);
  /** 两条不同作品各自占一次额度，单条去重不合并跨期调用。 */
  const distinct = learning.recordAttempt(learning.recordAttempt({}, { episodeId: 'q1', now: base }), { episodeId: 'q2', now: base });
  assert.equal(learning.quota(distinct, { episodeId: 'q3', now: base }).projectCount, 2);
});

test('L10 整理器规则先稳定排序再取 8', () => {
  const rules = [];
  for (let index = 0; index < 9; index += 1) {
    rules.push({
      id: `mem_${index}`,
      status: 'active',
      learning: { state: 'pending', updatedAt: new Date(Date.UTC(2026, 0, 1, 0, index)).toISOString() },
      updated: new Date(Date.UTC(2026, 0, 1, 0, index)).toISOString(),
    });
  }
  /** 真正可用的旧经验排在输入最后：先截断就会丢掉它。 */
  rules.push({
    id: 'mem_star',
    status: 'active',
    learning: { state: 'active', lastUsedAt: '2025-12-31T00:00:00.000Z', updatedAt: '2025-01-01T00:00:00.000Z' },
    updated: '2025-01-01T00:00:00.000Z',
  });
  assert.equal(rules.slice(0, 8).some((row) => row.id === 'mem_star'), false);
  const ordered = learning.orderOrganizerRules(rules);
  assert.equal(ordered.length, learning.LIMITS.organizerRules);
  assert.equal(ordered[0].id, 'mem_star');
  assert.equal(ordered.some((row) => row.id === 'mem_star'), true);
  /** 同样输入换个顺序结果一样；同状态按最近使用、再按时间、最后按 id。 */
  const shuffled = [...rules].reverse();
  assert.deepEqual(learning.orderOrganizerRules(shuffled).map((row) => row.id), ordered.map((row) => row.id));
  const sameState = [
    { id: 'b', learning: { state: 'active', updatedAt: '2025-01-01T00:00:00.000Z' } },
    { id: 'a', learning: { state: 'active', lastUsedAt: '2026-01-01T00:00:00.000Z', updatedAt: '2025-01-01T00:00:00.000Z' } },
    { id: 'c', learning: { state: 'active', updatedAt: '2025-01-01T00:00:00.000Z' } },
  ];
  assert.deepEqual(learning.orderOrganizerRules(sameState, { limit: 2 }).map((row) => row.id), ['a', 'b']);
  assert.equal(learning.orderOrganizerRules([], { limit: 3 }).length, 0);
});

/* 收敛：连续纠正同一主题只留一条现行规则；换栏目不适用；关掉再开还是同一现行版。 */
test('B30 连续纠正同一规则收敛到一条现行版', () => {
  const scope = fresh('converge');
  enable(scope);
  const firstEpisode = seedEpisode(scope, { sessionId: 'conv1', messageIds: ['cm1'] });
  const firstStart = begin(scope, firstEpisode);
  assert.equal(commitNew(scope, firstEpisode, firstStart, NEW_CHANGE).ok, true);
  const id = ruleRows(scope)[0].id;
  const bodies = ['开头两句内给结论。', '开头一句内给结论。'];
  bodies.forEach((body, index) => {
    const episode = seedEpisode(scope, { sessionId: `conv${index + 2}`, messageIds: [`cm${index + 2}`] });
    const started = begin(scope, episode);
    assert.equal(started.ok, true, started.reason);
    const result = commitExisting(scope, episode, started, id, {
      target: 'r0', feedbackType: 'spec_change', currentText: body, evidence: ['u0'],
    });
    assert.equal(result.ok, true, result.reason);
  });
  const rows = ruleRows(scope);
  assert.equal(rows.length, 1, '同一主题不堆多份现行规则');
  const current = rows[0];
  assert.equal(current.id, id);
  assert.match(current.body, /一句内给结论/);
  assert.ok((current.versions || []).length <= 2, '旧版有上限');
  const wrongColumn = view.eligibility(current, {
    projectId: scope.key,
    context: { seriesId: '字幕' },
    task: { taskKind: 'video', seriesId: '字幕' },
  }, 'auto');
  assert.equal(wrongColumn.ok, false, '换栏目不适用');
  store.setMemoryEnabled(scope, false, { operationId: 'conv-close' });
  assert.equal(ruleRows(scope).length, 1, '关闭不清成果');
  store.setMemoryEnabled(scope, true, { operationId: 'conv-open' });
  const reopened = ruleOf(scope, id);
  assert.equal(reopened.body, current.body);
  assert.equal(reopened.revision, current.revision);
  assert.equal(reopened.learning.state, current.learning.state);
});

console.log(`learning.test.mjs: ${passed} passed`);

test('L03b 反馈类型按同义词归一，真不认的才拒', () => {
  const rules = [];
  const refs = { feedback: { u0: 'm1' }, rules: {} };
  const check = (feedbackType) => learning.validateChange({ ...NEW_CHANGE, target: 'new', feedbackType }, { refs, rules, ranges: RANGES });
  assert.equal(learning.normalizeFeedbackType('preference'), 'spec_change');
  assert.equal(learning.normalizeFeedbackType('Spec-Change'), 'spec_change');
  assert.equal(learning.normalizeFeedbackType('执行检查点'), '');
  assert.equal(check('preference').ok, true, '同义词应归一到 spec_change 并放行');
  assert.equal(check('spec-change').ok, true);
  assert.equal(check('新规则').ok, false);
});

test('L03c 整理超时给了模型足够时间', () => {
  assert.ok(learning.LIMITS.timeoutMs >= 60000, `timeoutMs 太小：${learning.LIMITS.timeoutMs}`);
  assert.ok(learning.LIMITS.maxTokens >= 1024, `maxTokens 太小：${learning.LIMITS.maxTokens}`);
});

test('L03d 只有同一期的新反馈才作废在途整理', () => {
  const mk = (episodeId, revision) => {
    const episodeRevisions = new Map();
    const scopeRevisions = new Map();
    episodeRevisions.set(`S\u0000${episodeId}`, revision);
    scopeRevisions.set('S', revision);
    return { episodeRevisions, scopeRevisions, scopeKey: 'S', episodeId, revision };
  };
  const own = mk('ep_1', 7);
  assert.equal(learning.feedbackStillCurrent(own), true);
  const other = mk('ep_2', 9);
  assert.equal(learning.feedbackStillCurrent({ ...other, episodeId: 'ep_1', revision: 7 }), true, '别的作品来新反馈不该作废这一期');
  const superseded = { episodeRevisions: new Map([['S\u0000ep_1', 9]]), scopeRevisions: new Map([['S', 9]]), scopeKey: 'S', episodeId: 'ep_1', revision: 7 };
  assert.equal(learning.feedbackStillCurrent(superseded), false, '同一期又来新反馈才作废');
  const noEpisode = mk('', 3);
  assert.equal(learning.feedbackStillCurrent({ ...noEpisode, revision: 5 }), false, '没有作品时按项目代次判断');
});
