import {
  scopeOf,
  globalScope,
  search,
  markUsed,
  readEntry,
  readLinks,
  forget,
  undoChange,
  locate,
  runtimeLayers,
  renderIndex,
  conflictsOf,
  resolveConflict,
  dropConflict,
  loadIndex,
  saveEntry,
  move,
  resumeMove,
  movePending,
  suggestionGate,
  noteSuggestion,
  acceptCandidate,
  rejectCandidate,
  recordCitations,
  listCitations,
  readCitationBody,
  readCitationBodyByTitle,
  locateByTitle,
  evolutionStatus,
  controlStatus,
  setMemoryControl,
  isExperimentalRecord,
  setEvolution,
  taskState,
  saveTaskState,
  learningSnapshot,
  beginLearningAttempt,
  commitLearning,
  recordLearningFailure,
  pauseLearningRules,
  removeLearningRule,
  undoLearningChange,
  pinLearningRule,
  resumeLearningRule,
  adoptLearningRule,
  editLearningRule,
  maybeExpire,
  LIMITS,
} from './store.js';
import path from 'node:path';
import crypto from 'node:crypto';
import * as view from './view.js';
import * as state from './state.js';
import * as anchor from './anchor.js';
import * as learning from './learning.js';
import * as persona from './persona.js';
import * as personaStore from './persona-store.js';
import * as evolve from './evolve.js';
import * as evolveStore from './evolve-store.js';
import * as scheduler from './scheduler.js';

/** 开关路由在 apply 外，也要能中止在途整理。 */
const learningAborts = new Map();
/** 上一句里出现这些词，说明本轮有硬要求，优先于已形成的偏好；只在本轮生效。 */
const EXPLICIT_MARKERS = ['务必', '必须', '一定要', '不要', '别', '只用', '仅用', '先说结论', '表格', '列表', '分成', '分步', '分点', '要点', '代码块', '英文', '中文'];
/** 上次成功准备的记忆载荷字节数；只按会话记，重启后显示未知。 */
const payloadBytes = new Map();

/** Only the tool registry is required; everything else is optional. */
export const inject = ['tools'];

/** Model-facing contract. Kept short on purpose: this text is the only resident cost. */
const NOTES = [
  '记忆是历史笔记，不是本轮要求。',
  '值得记：用户明确说「记住」的偏好、约定、踩坑、可复用流程、「去哪读 / 怎么调用」指针。',
  '不记：常识、一次性参数、文件里能读到的正文、凭据值、尺寸/字号/层级/颜色这类实现细节。',
  '凭据只记位置与调用方式。',
  '摘要写名词短语，别写指令。',
].join('');

function cwdOf(execution) {
  try {
    const agent = execution?.agent;
    const value = agent?.cwd ?? agent?.session?.header?.cwd ?? agent?.header?.cwd;
    if (typeof value === 'string' && value) return value;
  } catch {
    /* fall through to the process directory */
  }
  return process.cwd();
}

/** 插件配置的默认触发方式，面板要按项目实际生效值显示。 */
let hostRecallMode = 'adaptive';

/** 本项目记忆总开关：读不出来时不擅自关掉，按开处理。 */
function memoryEnabled(scope) {
  try {
    return controlStatus(scope).enabled !== false;
  } catch {
    return true;
  }
}

/** 关着的原因决定下一步：恢复出来的状态要用户重新开启，而不是让人以为是自己关的。 */
function memoryOffCopy(scope) {
  try {
    return controlStatus(scope).recoveryPending
      ? '本项目记忆刚从损坏里恢复，需要你重新开启'
      : '本项目记忆已关闭，先在面板打开';
  } catch {
    return '本项目记忆已关闭，先在面板打开';
  }
}

function memoryEnabledFor(execution) {
  return memoryEnabled(scopeOf(cwdOf(execution)));
}

/** 总开关关掉时这组工具对模型不可见，也不接受执行。 */
const MEMORY_TOOLS = ['memory_save', 'memory_suggest', 'memory_search', 'memory_read', 'memory_forget', 'memory_persona', 'memory_tune'];

const REMOTE_PATH = '/lite-memory';

/** 引用的归属会话：界面上那句「N 条记忆引用」按它分开存。 */
function sessionIdOf(execution) {
  try {
    const id = execution?.agent?.session?.id;
    return typeof id === 'string' ? id : '';
  } catch {
    return '';
  }
}

function sendJson(res, status, value) {
  res.writeHead(status, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' });
  res.end(JSON.stringify(value));
}

function readJsonBody(req, limit = 8192) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    req.on('data', (chunk) => {
      size += chunk.length;
      if (size > limit) {
        reject(new Error('请求过大'));
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });
    req.on('end', () => {
      try {
        resolve(JSON.parse(Buffer.concat(chunks).toString('utf8') || '{}'));
      } catch {
        reject(new Error('请求无法解析'));
      }
    });
    req.on('error', reject);
  });
}

/** 每个会话最近一次自动召回的判断依据；只留判断，不留正文。 */
const recallReceipts = new Map();

function noteRecall(scope, sessionId, receipt) {
  if (!scope || typeof sessionId !== 'string' || !sessionId) return;
  recallReceipts.set(`${scope.key}\u0000${sessionId}`, {
    at: new Date().toISOString(),
    reason: String(receipt.reason || ''),
    matched: Number(receipt.matched) || 0,
    cards: Number(receipt.cards) || 0,
    chars: Number(receipt.chars) || 0,
    limit: view.CARD.max,
    /** 使用字节的口径就是这一轮的档位额度，不再固定报硬顶 1200。 */
    bytes: receipt.plan && Number(receipt.plan.bytes) ? Number(receipt.plan.bytes) : view.CARD.bytes,
    /** 这一轮按什么档位检索的：类型与深度，不记用户原话。 */
    plan: receipt.plan && receipt.plan.type
      ? { type: receipt.plan.type, tier: receipt.plan.tier, candidates: receipt.plan.candidates, cards: receipt.plan.cards, dropped: Number(receipt.dropped) || 0 }
      : null,
    /** 与 plan 同一份数据的一行话，面板不必自己拼词。 */
    summary: scheduler.planSummaryOf(receipt.plan),
    /** 注入为空时留在回执里的最近候选：查了什么、差多少，阈值只能靠这个调。 */
    closest: String(receipt.closest || '').slice(0, 200),
  });
  while (recallReceipts.size > 64) recallReceipts.delete(recallReceipts.keys().next().value);
}

/** 投影没发出去就撤销回执：面板不能显示一条模型从没见过的提醒。 */
function clearRecall(scope, sessionId) {
  if (!scope || typeof sessionId !== 'string' || !sessionId) return;
  recallReceipts.delete(`${scope.key}\u0000${sessionId}`);
}

function recallReceiptOf(scope, sessionId) {
  if (!scope || typeof sessionId !== 'string' || !sessionId) return null;
  return recallReceipts.get(`${scope.key}\u0000${sessionId}`) || null;
}

/**
 * 桌面壳与本地 Web 是同一个界面：认 host 自己的 origin，也认 app 内建协议。
 */
function sameSurface(origin, selfOrigin) {
  if (typeof origin !== 'string' || origin.length === 0) return true;
  if (origin === selfOrigin) return true;
  return /^dsh-app:\/\/[A-Za-z0-9.-]+$/.test(origin);
}


/**
 * 「记住我」面板数据：只有闭集枚举与计数，不带自由文本，也不掺项目记忆。
 * 标签在服务端给，两侧（工具与面板）用同一份文案，避免各写一套。
 */
const PERSONA_DIMENSION_COPY = {
  answer_order: ['回答顺序', { conclusion_first: '结论先行', background_first: '先讲背景' }],
  explanation_depth: ['解释深度', { brief: '简短', detailed: '详细', layered: '分层' }],
  example_use: ['举例习惯', { with_examples: '带例子', without_examples: '不举例', only_on_request: '要求时再举' }],
  option_presentation: ['选项形式', { single_recommendation: '只给一个推荐', multiple_options: '给多个选项', tradeoff_table: '对比表' }],
  tone: ['语气', { plain: '平实', warm: '温和', direct: '直接', playful: '轻松' }],
  progress_updates: ['过程汇报', { announce_before_steps: '动手前先说', report_on_completion: '做完再报', silent_until_done: '做完为止不打扰' }],
  option_count: ['选项数量', { one: '一个', two_to_three: '两到三个', many: '多个' }],
  comparison_format: ['对比形式', { table: '表格', bullet_list: '分条', prose: '整段' }],
};

function personaCatalog() {
  return persona.DIMENSION_NAMES.map((dimension) => {
    const copy = PERSONA_DIMENSION_COPY[dimension];
    const values = (persona.PREFERENCE_DIMENSIONS[dimension] || []).map((value) => ({
      value,
      label: (copy && copy[1] && copy[1][value]) || value,
    }));
    return { dimension, label: (copy && copy[0]) || dimension, values };
  });
}

function personaPanel() {
  const panel = personaStore.describePersona();
  const catalog = personaCatalog();
  const labelOf = (dimension) => (catalog.find((row) => row.dimension === dimension) || {}).label || dimension;
  const valueLabel = (dimension, value) => {
    const row = catalog.find((item) => item.dimension === dimension);
    const hit = row && row.values.find((item) => item.value === value);
    return hit ? hit.label : value;
  };
  return {
    ok: true,
    enabled: panel.enabled === true,
    pending: Number(panel.pending) || 0,
    corrupt: panel.corrupt === true,
    reason: panel.reason || '',
    revision: panel.revision,
    formed: panel.formed.map((row) => ({
      dimension: row.dimension,
      label: labelOf(row.dimension),
      value: row.value,
      valueLabel: valueLabel(row.dimension, row.value),
      support: Number(row.support) || 0,
      source: row.source || '',
      lockedByUser: row.lockedByUser === true,
    })),
    observing: panel.observing.map((row) => ({
      dimension: row.dimension,
      label: labelOf(row.dimension),
      text: row.text,
      support: Number(row.support) || 0,
      missing: Array.isArray(row.missing) ? row.missing.slice(0, 3) : [],
    })),
    evidence: panel.evidence.map((row) => ({
      dimension: row.dimension,
      label: labelOf(row.dimension),
      eventId: row.eventId || '',
      at: row.at || '',
      date: row.date || '',
      value: row.value || '',
      valueLabel: row.value ? valueLabel(row.dimension, row.value) : '',
      basis: row.basis || '',
      oppose: row.polarity === 'oppose',
    })),
    recentChanges: panel.recentChanges.map((row) => ({
      at: row.at || '',
      dimension: row.dimension || '',
      label: labelOf(row.dimension || ''),
      from: row.from || '',
      to: row.to || '',
      basis: row.basis || '',
    })),
    catalog,
  };
}

/**
 * 参数进化（受限自进化）：唯一的数据来源是用户自己标注的「这条查询该想起哪条」。
 * 不凭空造用例、不动隔离与授权，只按白名单参数一档一档试，而且必须整批不变差。
 */
const TUNE_FIELDS = ['id', 'title', 'summary', 'when', 'body', 'kind', 'status', 'aliases', 'tags', 'triggers', 'conditions', 'applicability'];

function tunePanel(scope) {
  const described = evolveStore.describeEvolve(scope);
  return {
    ok: true,
    corrupt: described.corrupt === true,
    revision: described.revision,
    params: described.params,
    defaults: described.defaults,
    replayCases: described.replayCases,
    /** 证据集版本与生效策略版本分开报：证据变了不代表参数变了。 */
    evidenceRevision: described.evidenceRevision,
    policyRevision: described.policyRevision,
    needsReeval: described.needsReeval === true,
    canRollback: described.canRollback === true,
    ...(described.lastChange ? { lastChange: described.lastChange } : {}),
  };
}

function tuneAction(scope, body) {
  const op = typeof body.op === 'string' && body.op ? body.op : 'status';
  const allowed = new Set(['status', 'remember', 'suggest', 'apply', 'rollback', 'clear']);
  if (!allowed.has(op)) return { status: 400, value: { ok: false, reason: '不认识这个操作' } };
  if (op === 'status') return { status: 200, value: tunePanel(scope) };
  const lab = evolveStore.readEvolve(scope).lab;
  if (op === 'remember') {
    const query = typeof body.query === 'string' ? body.query.trim().slice(0, 120) : '';
    const entryId = typeof body.entryId === 'string' ? body.entryId.trim() : '';
    if (!query || !entryId) return { status: 400, value: { ok: false, reason: '缺查询或记忆 id' } };
    /** 只拿还能被想起的记忆当回放题：归档行永远不参与排序，收进来只会让整批题永远全空。 */
    const current = (state.load(scope).state.entries || []).filter((row) => row && row.id && row.status !== 'archived');
    const target = current.find((row) => row.id === entryId);
    if (!target) return { status: 404, value: { ok: false, reason: '这个项目里没有这条记忆' } };
    /** 库里是 {id, status, current:{正文}} 的包裹结构，回放要的是摊平后可排序的一份。 */
    const snapshot = current.slice(0, 60).map((row) => {
      const flat = { ...(row.current || {}), id: row.id, status: row.status || (row.current && row.current.status) };
      const shape = {};
      for (const key of TUNE_FIELDS) if (flat[key] !== undefined) shape[key] = flat[key];
      return shape;
    });
    /** 没有任何可匹配文字的条目排不出名次，标了也只会得到空回放，当场说清楚。 */
    const textOf = (row) => [row.title, row.summary, row.when, row.body, ...(Array.isArray(row.aliases) ? row.aliases : [])]
      .map((part) => String(part || '')).join('');
    if (!snapshot.some((row) => row.id === entryId && textOf(row).trim())) {
      return { status: 400, value: { ok: false, reason: '这条记忆没有可匹配的正文' } };
    }
    /** 题只存问答与预期，快照共用一份，文件体积不再随题数翻倍。 */
    const cases = (lab.replay.cases || []).filter((row) => row && row.query !== query);
    cases.push({
      id: `case-${cases.length + 1}-${Date.now()}`, query, expectIds: [entryId], forbidIds: [],
      context: { taskKind: typeof body.taskKind === 'string' ? body.taskKind.trim().slice(0, 40) : '' },
    });
    const frozen = evolveStore.freezeReplay(scope, cases.slice(-evolve.LIMITS.maxCases), { records: snapshot });
    return { status: frozen.ok ? 200 : 409, value: { ...tunePanel(scope), changed: frozen.ok === true, reason: frozen.reason || '' } };
  }
  if (op === 'clear') {
    const frozen = evolveStore.freezeReplay(scope, []);
    return { status: frozen.ok ? 200 : 409, value: { ...tunePanel(scope), changed: frozen.ok === true, reason: frozen.reason || '' } };
  }
  const cases = evolveStore.materializeCases(lab);
  if (!cases.length) return { status: 409, value: { ...tunePanel(scope), ok: false, reason: '还没有标注过没被想起来的查询' } };
  if (op === 'suggest') {
    const proposal = evolve.proposeChange(cases, lab.params);
    return { status: 200, value: { ...tunePanel(scope), baseline: proposal.baseline, proposal: proposal.proposal } };
  }
  if (op === 'apply') {
    const proposal = evolve.proposeChange(cases, lab.params);
    if (!proposal.proposal) return { status: 409, value: { ...tunePanel(scope), ok: false, reason: '没有整批不变差的档位' } };
    const applied = evolveStore.applyProposal(scope, proposal.proposal, { cases });
    if (!applied.ok) return { status: 409, value: { ...tunePanel(scope), ok: false, reason: applied.reason || '这次没有改动' } };
    return { status: 200, value: { ...tunePanel(scope), changed: true, applied: proposal.proposal } };
  }
  const back = evolveStore.rollbackParams(scope);
  return { status: back.ok ? 200 : 409, value: { ...tunePanel(scope), changed: back.ok === true, reason: back.ok ? '' : (back.reason || '没有可回滚的改动') } };
}

/**
 * 「保留」「✕」的唯一入口。定位只认 id / candidateId，作用域由服务端按 id 查，
 * 不再从展示文案里解析标题或 [全局]。已处理的候选重放返回原回执。
 */
/** 路由层改开关时用来取消在途抽取；插件没加载时是空操作。 */
let personaAbortHook = () => {};
function keepHandler(webServer, cwdForSession) {
  return async (req, res) => {
    if (req.method !== 'POST') return sendJson(res, 405, { ok: false, reason: '只接受 POST' });
    const origin = req.headers.origin;
    if (!sameSurface(origin, webServer.getOrigin())) {
      return sendJson(res, 403, { ok: false, reason: '来源不符' });
    }
    const pathname = String(req.url || '').split('?')[0];
    const action = pathname === REMOTE_PATH + '/undo' ? 'undo'
      : pathname === REMOTE_PATH + '/reject' ? 'reject'
        : pathname === REMOTE_PATH + '/keep' ? 'keep'
          : pathname === REMOTE_PATH + '/citations' ? 'citations'
            : pathname === REMOTE_PATH + '/body' ? 'body'
              : pathname === REMOTE_PATH + '/entry' ? 'entry'
              : pathname === REMOTE_PATH + '/move' ? 'move'
                : pathname === REMOTE_PATH + '/overview' ? 'overview'
                  : pathname === REMOTE_PATH + '/conflict' ? 'conflict'
                  : pathname === REMOTE_PATH + '/control' ? 'control'
                  : pathname === REMOTE_PATH + '/evolution' ? 'evolution'
                  : pathname === REMOTE_PATH + '/resume-move' ? 'resume-move'
                    : pathname === REMOTE_PATH + '/persona' ? 'persona'
                      : pathname === REMOTE_PATH + '/tune' ? 'tune' : '';
    if (!action) return sendJson(res, 404, { ok: false, reason: '未知操作' });
    let body;
    try {
      body = await readJsonBody(req);
    } catch (error) {
      return sendJson(res, 400, { ok: false, reason: error instanceof Error ? error.message : '请求无法解析' });
    }

    /**
     * 正文按 id 现查当前层：引用是历史事实，正文必须给当前版本，不能吃缓存。
     * 只认本会话引用过的那条，或本工作目录这一层的条目；否则任意 id 都能读到别人的正文。
     */
    if (action === 'body') {
      const id = typeof body.id === 'string' ? body.id : '';
      /** 界面只有标题：按标题照样能读，id 留着兼容旧引用文件。 */
      const titleRef = typeof body.title === 'string' ? body.title.trim() : '';
      const revisionRef = Number.isInteger(body.revision) ? body.revision : undefined;
      if (!id && !titleRef) return sendJson(res, 400, { ok: false, reason: '缺少标题' });
      /** 找不到时只回调用方给的那个句柄：按 id 问就回 id，按标题问就回标题。 */
      const goneReply = () => sendJson(res, 200, titleRef
        ? { ok: true, status: 'gone', title: titleRef }
        : { ok: true, status: 'gone', id });
      const sessionId = typeof body.sessionId === 'string' ? body.sessionId : '';
      const cwd = typeof body.cwd === 'string' ? body.cwd : '';
      const scopeKey = typeof body.scopeKey === 'string' ? body.scopeKey : '';
      const scopeRef = body.scope === 'global' || body.scope === 'project' ? body.scope : '';
      let found;
      if (scopeKey) {
        /**
         * 面板可以读枚举出来的项目层，但键必须来自服务端列表；
         * 不接受客户端拼路径，会话也只用来确认当前身份。
         */
        if (!cwdForSession(sessionId)) return sendJson(res, 409, { ok: false, reason: '这个会话还没有项目目录' });
        const listed = state.knownProjectScopes().find((row) => row.key === scopeKey);
        const target = scopeKey === 'global' ? globalScope()
          : listed ? { key: listed.key, dir: listed.dir, cwd: listed.cwd || '', requestedCwd: listed.cwd || '', rootSource: 'configured', confirmed: true }
            : null;
        if (!target) return sendJson(res, 404, { ok: false, reason: '没有这个项目' });
        const located = id ? locate(target, id, { readOnly: true })
          : locateByTitle(target, titleRef, { readOnly: true, revision: revisionRef });
        if (!located) return goneReply();
        found = {
          ...located.record,
          scope: located.scope.key === 'global' ? 'global' : 'project',
          scopeLabel: located.scope.key === 'global' ? '全局' : path.basename(located.scope.cwd || '') || located.scope.key,
          body: located.record.body,
        };
      } else if (sessionId) {
        try {
          found = id ? readCitationBody(sessionId, id)
            : readCitationBodyByTitle(sessionId, titleRef, { revision: revisionRef, scope: scopeRef });
        } catch {
          found = null;
        }
        /** 不在本会话引用里就当已消失：不给跨会话探正文，界面也只显示「已删除」。 */
        if (!found) return goneReply();
      } else if (cwd) {
        const located = id ? locate(scopeOf(cwd), id, { readOnly: true })
          : locateByTitle(scopeOf(cwd), titleRef, { readOnly: true, revision: revisionRef });
        if (!located) return goneReply();
        found = {
          ...located.record,
          scope: located.scope.key === 'global' ? 'global' : 'project',
          scopeLabel: located.scope.key === 'global' ? '全局' : path.basename(located.scope.cwd || '') || located.scope.key,
          body: located.record.body,
        };
      } else {
        return sendJson(res, 400, { ok: false, reason: '缺少来源' });
      }
      if (!found) return goneReply();
      /** 面板要分开「当前规范」和旧版本；历史只作可折叠对照，不拼进正文。 */
      const versions = Array.isArray(found.versions) ? found.versions
        : Array.isArray(found.history) ? found.history : [];
      const learning = found.learning && typeof found.learning === 'object' ? found.learning : {};
      const enums = new Set(['applied', 'unchanged', 'superseded', 'failed']);
      const processingStatus = enums.has(found.processingStatus) ? found.processingStatus
        : enums.has(learning.lastStatus) ? learning.lastStatus : '';
      return sendJson(res, 200, {
        ok: true,
        status: found.status,
        title: found.title,
        when: found.when || '',
        scope: found.scope,
        scopeLabel: found.scopeLabel || '',
        revision: found.revision,
        applicability: found.applicability || 'all_in_scope',
        conditions: Array.isArray(found.conditions) ? found.conditions : [],
        body: found.body,
        currentBody: typeof found.currentBody === 'string' ? found.currentBody : found.body,
        versions,
        sourceExcerpt: found.sourceExcerpt || learning.sourceExcerpt || '',
        sourceRefs: Array.isArray(found.sourceRefs) ? found.sourceRefs : (Array.isArray(learning.sourceRefs) ? learning.sourceRefs : []),
        evidence: found.evidence || (found.evidenceRef ? [found.evidenceRef] : []),
        evidenceRef: found.evidenceRef || '',
        processingStatus,
      });
    }

    /**
     * 面板改一条普通记忆：只改当前项目里的标题与正文，别层只读。
     * 必须带读到的版本，写前再对一次；中间被别人改过就拒绝，不覆盖。
     */
    if (action === 'entry') {
      const edit = typeof body.edit === 'string' ? body.edit : '';
      if (edit && edit !== 'save') return sendJson(res, 400, { ok: false, reason: '不认识这个操作' });
      const sessionId = typeof body.sessionId === 'string' ? body.sessionId : '';
      if (!sessionId) return sendJson(res, 400, { ok: false, reason: '缺少 sessionId' });
      const cwd = typeof cwdForSession === 'function' ? cwdForSession(sessionId) : '';
      if (!cwd) return sendJson(res, 409, { ok: false, reason: '这个会话还没有项目目录' });
      const scope = scopeOf(cwd);
      if (!scope.confirmed) return sendJson(res, 409, { ok: false, reason: '项目根还没确认，先重新打开这个项目' });
      const scopeKey = typeof body.scopeKey === 'string' ? body.scopeKey : '';
      if (scopeKey && scopeKey !== scope.key) {
        return sendJson(res, 409, { ok: false, reason: '别的项目只读，回到那个项目里再改' });
      }
      if (!memoryEnabled(scope)) return sendJson(res, 409, { ok: false, code: 'memory_disabled', reason: '本项目记忆已关闭' });
      const id = typeof body.id === 'string' ? body.id : '';
      const title = typeof body.title === 'string' ? body.title : '';
      const text = typeof body.body === 'string' ? body.body : '';
      const expectedRevision = Number(body.expectedRevision);
      if (!id) return sendJson(res, 400, { ok: false, reason: '缺少这条记忆' });
      if (!Number.isInteger(expectedRevision) || expectedRevision < 1) {
        return sendJson(res, 409, { ok: false, reason: '这条记忆的版本不清楚，先刷新再改' });
      }
      if (!title.trim()) return sendJson(res, 400, { ok: false, reason: '标题不能为空' });
      /** 面板只让人确认「适用范围」这一件事实，不开放条件编辑；取值由 view 再校验。 */
      const applicability = typeof body.applicability === 'string' ? body.applicability : undefined;
      const conditions = Array.isArray(body.conditions) ? body.conditions : undefined;
      try {
        const result = saveEntry(scope, {
          id, title, body: text, expectedRevision, scope: 'project', origin: 'user_explicit',
          ...(applicability !== undefined ? { applicability } : {}),
          ...(conditions !== undefined ? { conditions } : {}),
        });
        if (!result || !result.record) {
          const reason = result && result.reasonCode === 'memory_disabled' ? '本项目记忆已关闭'
            : result && result.needsResolution ? '改动和另一条太像，先去那条上改'
              : '这次没有改动';
          return sendJson(res, 409, { ok: false, reason });
        }
        return sendJson(res, 200, { ok: true, title: result.record.title, revision: result.record.revision, changed: result.noop !== true });
      } catch (error) {
        const conflict = error && error.code === 'conflict';
        return sendJson(res, conflict ? 409 : 400, {
          ok: false,
          retry: conflict,
          reason: error instanceof Error ? error.message : '这次没有改动',
        });
      }
    }

    /**
     * 「记住我」面板：读现状与四类动作都在这。用户级、独立于项目层，
     * 只认闭集枚举值；动作失败把原因带回去，面板不改本地状态硬撑。
     */
    if (action === 'persona') {
      const op = typeof body.op === 'string' && body.op ? body.op : 'status';
      const allowed = new Set(['status', 'enable', 'disable', 'edit', 'reject', 'clear', 'forget_evidence']);
      if (!allowed.has(op)) return sendJson(res, 400, { ok: false, reason: '不认识这个操作' });
      const dim = typeof body.dimension === 'string' ? body.dimension.trim() : '';
      const value = typeof body.value === 'string' ? body.value.trim() : '';
      try {
        if (op === 'enable' || op === 'disable') {
          if (op === 'disable') personaAbortHook();
          const next = personaStore.setPersonaEnabled({ enabled: op === 'enable' });
          if (!next.ok) return sendJson(res, 409, { ...personaPanel(), ok: false, reason: next.reason || '这次没有改动' });
        } else if (op === 'edit') {
          if (!dim || !value) return sendJson(res, 400, { ok: false, reason: '缺少维度或取值' });
          const next = personaStore.editPersonaPreference({ dimension: dim, value });
          if (!next.ok) {
            const reason = next.reason === 'unknown_dimension' ? '没有这个维度'
              : next.reason === 'value_not_in_dimension' ? '这个取值不在该维度里'
                : '这次没有改动';
            return sendJson(res, 409, { ...personaPanel(), ok: false, reason });
          }
        } else if (op === 'reject') {
          if (!dim) return sendJson(res, 400, { ok: false, reason: '缺少维度' });
          const next = personaStore.rejectPersonaPreference({ dimension: dim });
          if (!next.ok) {
            const reason = next.reason === 'unknown_dimension' ? '没有这个维度' : '这次没有改动';
            return sendJson(res, 409, { ...personaPanel(), ok: false, reason });
          }
        } else if (op === 'forget_evidence') {
          const eventId = typeof body.eventId === 'string' ? body.eventId.trim() : '';
          /** 单条依据按 eventId 删；整维清空按 dimension 删，两种都得给一个。 */
          if (!eventId && !dim) return sendJson(res, 400, { ok: false, reason: '缺少要删的依据' });
          const next = personaStore.retractPersonaEvidence({ eventId, dimension: dim || undefined });
          if (!next.ok) {
            const reason = next.reason === 'not_found' ? '这条依据已经不在了' : '这次没有改动';
            return sendJson(res, 409, { ...personaPanel(), ok: false, reason });
          }
        } else if (op === 'clear') {
          const next = personaStore.clearPersona();
          if (!next.ok) return sendJson(res, 409, { ...personaPanel(), ok: false, reason: next.reason || '这次没有改动' });
        }
        return sendJson(res, 200, { ...personaPanel(), changed: op !== 'status' });
      } catch (error) {
        return sendJson(res, 500, { ok: false, reason: error instanceof Error ? error.message : '画像文件读不了' });
      }
    }

    /**
     * 参数进化：读现状、记下一条漏报、试一档、采纳、回滚、清空。
     * 作用域就是面板当前项目；用户级画像不在这里，互不影响。
     */
    if (action === 'tune') {
      const sessionId = typeof body.sessionId === 'string' ? body.sessionId : '';
      const cwd = typeof cwdForSession === 'function' ? cwdForSession(sessionId) : '';
      if (!cwd) return sendJson(res, 409, { ok: false, reason: '这个会话还没有项目目录' });
      const scope = scopeOf(cwd);
      if (!memoryEnabled(scope)) return sendJson(res, 409, { ok: false, code: 'memory_disabled', reason: '本项目记忆已关闭' });
      try {
        const { status, value } = tuneAction(scope, body);
        return sendJson(res, status, value);
      } catch (error) {
        return sendJson(res, 500, { ok: false, reason: error instanceof Error ? error.message : '这次没有改动' });
      }
    }

    /**
     * 面板总览：当前会话项目、可切换的项目层与全局层，都从服务端枚举。
     * 只读；正文不进列表，点开单条再按 scopeKey 取。
     */
    if (action === 'overview') {
      const sessionId = typeof body.sessionId === 'string' ? body.sessionId : '';
      if (!sessionId) return sendJson(res, 400, { ok: false, reason: '缺少 sessionId' });
      const cwd = typeof cwdForSession === 'function' ? cwdForSession(sessionId) : '';
      if (!cwd) return sendJson(res, 409, { ok: false, reason: '这个会话还没有项目目录' });
      const scope = scopeOf(cwd);
      if (!scope.confirmed) return sendJson(res, 409, { ok: false, reason: '项目根还没确认，先重新打开这个项目' });
      let currentState;
      try {
        currentState = state.load(scope).state;
      } catch (error) {
        return sendJson(res, 409, { ok: false, reason: error instanceof Error ? error.message : '这个项目的记忆读不出来' });
      }
      const currentEvolution = (() => {
        try {
          return learningSnapshot(scope, { readOnly: true });
        } catch {
          return null;
        }
      })();
      const labelOf = (target) => target.key === 'global' ? '全局' : (path.basename(target.cwd || '') || target.key);
      const listed = state.knownProjectScopes();
      const scopes = listed.map((row) => ({
        key: row.key,
        kind: 'project',
        label: path.basename(row.cwd || '') || row.key,
        entries: row.entries,
        archived: row.archived,
        experimental: row.experimental,
        enabled: row.enabled,
        updatedAt: row.updatedAt,
      }));
      if (!scopes.some((row) => row.key === scope.key)) {
        const active = currentState.entries.filter((entry) => entry.status !== 'archived');
        scopes.unshift({
          key: scope.key,
          kind: 'project',
          label: labelOf(scope),
          entries: active.length,
          archived: currentState.entries.length - active.length,
          experimental: active.filter((entry) => isExperimentalRecord(entry)).length,
          enabled: currentState.experimental?.projectEvolution?.enabled === true,
          updatedAt: currentState.updatedAt || '',
        });
      }
      let globalState = null;
      try {
        globalState = state.load(globalScope()).state;
      } catch {
        globalState = null;
      }
      if (globalState) {
        const active = globalState.entries.filter((entry) => entry.status !== 'archived');
        scopes.push({
          key: 'global',
          kind: 'global',
          label: '全局',
          entries: active.length,
          archived: globalState.entries.length - active.length,
          experimental: 0,
          enabled: false,
          updatedAt: globalState.updatedAt || '',
        });
      } else {
        scopes.push({ key: 'global', kind: 'global', label: '全局', entries: 0, archived: 0, experimental: 0, enabled: false, updatedAt: '' });
      }
      const requested = typeof body.scopeKey === 'string' ? body.scopeKey : '';
      /** 「所有」只是读视图：把枚举到的项目层和全局层合成一份，写操作仍按行自己的层走。 */
      const allView = requested === 'all';
      let selectedScope = scope;
      if (requested === 'global') selectedScope = globalScope();
      else if (requested && !allView) {
        if (requested === scope.key) selectedScope = scope;
        else {
          const row = listed.find((item) => item.key === requested);
          if (!row) return sendJson(res, 404, { ok: false, reason: '没有这个项目' });
          selectedScope = { key: row.key, dir: row.dir, cwd: row.cwd || '', requestedCwd: row.cwd || '', rootSource: 'configured', confirmed: true };
        }
      }
      const shapeRecord = (record, layer, scopeKey, scopeLabel) => ({
        id: record.id,
        title: record.title || '',
        summary: record.summary || '',
        kind: record.kind || 'note',
        when: record.when || '',
        tags: Array.isArray(record.tags) ? record.tags.slice(0, 12) : [],
        topicKey: record.topicKey || '',
        triggers: Array.isArray(record.triggers) ? record.triggers.slice(0, 8) : [],
        applicability: record.applicability || 'all_in_scope',
        conditions: Array.isArray(record.conditions) ? record.conditions.slice(0, 8) : [],
        selection: record.selection || null,
        links: Array.isArray(record.links) ? record.links.slice(0, 24).map((link) => ({ type: link.type || 'related', id: link.id })) : [],
        revision: Number(record.revision) || 1,
        origin: originOut(record.origin),
        updated: record.updated || '',
        lastUsed: record.lastUsed || '',
        used: record.used === true,
        bytes: Number(record.bytes) || 0,
        experimental: isExperimentalRecord(record),
        scope: layer,
        scopeKey,
        scopeLabel,
        learning: record.learning ? {
          state: record.learning.state || '',
          pinned: record.learning.pinned === true,
          samples: Array.isArray(record.learning.samples) ? record.learning.samples.length : 0,
          checkpoints: Array.isArray(record.learning.checkpoints) ? record.learning.checkpoints.length : 0,
          evidence: Array.isArray(record.learning.evidence) ? record.learning.evidence.length : 0,
          versions: Array.isArray(record.learning.versions) ? record.learning.versions.length : 0,
        } : null,
      });
      const targetsOfView = (() => {
        if (!allView) return [selectedScope];
        const rows = [];
        const seen = new Set();
        const add = (target) => {
          if (!target || seen.has(target.key)) return;
          seen.add(target.key);
          rows.push(target);
        };
        for (const row of listed) add({ key: row.key, dir: row.dir, cwd: row.cwd || '', requestedCwd: row.cwd || '', rootSource: 'configured', confirmed: true });
        add(scope);
        add(globalScope());
        return rows;
      })();
      /** 有的项目状态读坏了不连坐整张视图：跳过那一层继续渲染别的。 */
      const records = [];
      const archives = [];
      const conflicts = [];
      /** 读不出来的层要报出来：跳过一层还当整张视图完整，用户会以为记忆丢了。 */
      const failed = [];
      const seenIds = new Set();
      for (const target of targetsOfView) {
        let loaded;
        try {
          loaded = loadIndex(target, { readOnly: true });
        } catch (error) {
          if (!allView) return sendJson(res, 409, { ok: false, reason: error instanceof Error ? error.message : '这个项目的记忆读不出来' });
          failed.push({ key: target.key, label: labelOf(target) });
          continue;
        }
        const layer = target.key === 'global' ? 'global' : 'project';
        const scopeLabel = labelOf(target);
        for (const record of loaded.entries) {
          if (record.status === 'archived') continue;
          const key = `${target.key}:${record.id}`;
          if (seenIds.has(key)) continue;
          seenIds.add(key);
          records.push(shapeRecord(record, layer, target.key, scopeLabel));
        }
        for (const record of (Array.isArray(loaded.archived) ? loaded.archived : [])) {
          archives.push({
            id: record.id,
            title: record.title || '',
            revision: Number(record.revision) || 1,
            updated: record.updated || '',
            scope: layer,
            scopeKey: target.key,
            scopeLabel,
          });
        }
        let rows = [];
        try { rows = conflictsOf(target); } catch { rows = []; }
        for (const row of rows) conflicts.push({ ...row, scope: layer, scopeKey: target.key, scopeLabel });
      }
      const archived = archives.slice(0, 80);
      const tags = new Set();
      let links = 0;
      for (const record of records) {
        for (const tag of record.tags) tags.add(tag);
        links += record.links.length;
      }
      const currentControl = (() => {
        try { return controlStatus(scope); } catch { return { enabled: true, epoch: '' }; }
      })();
      const modeOf = (target) => {
        try { return { effectiveMode: controlStatus(target).mode || hostRecallMode }; } catch { return { effectiveMode: hostRecallMode }; }
      };
      currentControl.effectiveMode = modeOf(scope).effectiveMode;
      const selectedControl = selectedScope.key === scope.key
        ? currentControl
        : (() => {
          try { return { ...controlStatus(selectedScope), ...modeOf(selectedScope) }; } catch { return { enabled: true, epoch: '', effectiveMode: recallMode() }; }
        })();
      const selectedEvolution = selectedScope.key === scope.key
        ? currentEvolution
        : (() => {
          try {
            return learningSnapshot(selectedScope, { readOnly: true });
          } catch {
            return null;
          }
        })();
      return sendJson(res, 200, {
        ok: true,
        current: { key: scope.key, label: labelOf(scope), control: currentControl, evolution: currentEvolution, recall: recallReceiptOf(scope, sessionId) },
        scopes,
        failed,
        selected: {
          key: allView ? 'all' : selectedScope.key,
          kind: allView ? 'all' : selectedScope.key === 'global' ? 'global' : 'project',
          label: allView ? '所有项目' : labelOf(selectedScope),
          updatedAt: records.reduce((latest, record) => record.updated > latest ? record.updated : latest, ''),
          control: selectedControl,
          evolution: selectedEvolution,
          records,
          archived,
          conflicts,
          stats: {
            total: records.length,
            experimental: records.filter((record) => record.experimental).length,
            links,
            tags: tags.size,
            archived: archives.length,
          },
        },
      });
    }

    /** 待裁决：用队列里留下的草稿另存，或删掉这条待办；不预写、不替用户合并。 */
    if (action === 'conflict') {
      const sessionId = typeof body.sessionId === 'string' ? body.sessionId : '';
      if (!sessionId) return sendJson(res, 400, { ok: false, reason: '缺少 sessionId' });
      const cwd = typeof cwdForSession === 'function' ? cwdForSession(sessionId) : '';
      if (!cwd) return sendJson(res, 409, { ok: false, reason: '这个会话还没有项目目录' });
      const projectScope = scopeOf(cwd);
      if (!projectScope.confirmed) return sendJson(res, 409, { ok: false, reason: '项目根还没确认，先重新打开这个项目' });
      /** 请求里的目标必须与当前会话项目一致；别的项目只读，不能借面板改过去。 */
      const requested = typeof body.scopeKey === 'string' ? body.scopeKey : '';
      if (!requested) return sendJson(res, 400, { ok: false, reason: '缺少目标范围' });
      if (requested !== 'global' && requested !== projectScope.key) {
        return sendJson(res, 409, { ok: false, reason: '别的项目只读，回到那个项目里再改' });
      }
      const target = requested === 'global' ? globalScope() : projectScope;
      /** 关闭的项目记忆不能从这个入口绕过；选全局时全局总开关也必须开着。 */
      if (!memoryEnabled(projectScope)) {
        return sendJson(res, 409, { ok: false, code: 'memory_disabled', reason: memoryOffCopy(projectScope) });
      }
      if (target.key === 'global' && !memoryEnabled(target)) {
        return sendJson(res, 409, { ok: false, code: 'memory_disabled', reason: '总记忆已关闭，先在面板打开' });
      }
      const op = body.op;
      if (op !== 'keep' && op !== 'drop') return sendJson(res, 400, { ok: false, reason: '不认识这个操作' });
      const conflictId = typeof body.conflictId === 'string' ? body.conflictId.trim() : '';
      if (!conflictId) return sendJson(res, 400, { ok: false, reason: '缺少这条待裁决' });
      /** 丢掉不写记忆，不拿版本挡它；只有另存一条要知道批的是哪一版草稿。 */
      const expectedRevision = Number(body.expectedRevision);
      const staleKnown = Number.isInteger(expectedRevision) && expectedRevision >= 1;
      if (op === 'keep' && !staleKnown) {
        return sendJson(res, 409, { ok: false, reason: '这条待裁决的版本不清楚，先刷新再处理' });
      }
      try {
        const ref = staleKnown ? { id: conflictId, expectedRevision } : { id: conflictId };
        const outcome = op === 'drop' ? dropConflict(target, ref) : resolveConflict(target, ref);
        if (!outcome.ok) {
          return sendJson(res, 409, {
            ok: false,
            code: outcome.reasonCode || '',
            reason: outcome.reason || '这条待裁决还没处理成',
            /** 失败时也给队列现状：面板据此换掉过期行，而不是让同一个按钮反复点不动。 */
            remaining: conflictsOf(target).length,
          });
        }
        return sendJson(res, 200, {
          ok: true,
          remaining: conflictsOf(target).length,
          record: outcome.record ? { id: outcome.record.id, title: outcome.record.title, revision: outcome.record.revision } : null,
        });
      } catch (error) {
        return sendJson(res, 409, { ok: false, reason: error instanceof Error ? error.message : '待裁决处理失败' });
      }
    }

    /**
     * 本项目记忆总开关：关闭后这层不再召回、检索、读写、学习，也不继承全局记忆。
     * 自进化设置原样保留，但有效状态随总开关暂停。
     */
    if (action === 'control') {
      const sessionId = typeof body.sessionId === 'string' ? body.sessionId : '';
      if (!sessionId) return sendJson(res, 400, { ok: false, reason: '缺少 sessionId' });
      const cwd = typeof cwdForSession === 'function' ? cwdForSession(sessionId) : '';
      if (!cwd) return sendJson(res, 409, { ok: false, reason: '这个会话还没有项目目录' });
      const scope = scopeOf(cwd);
      if (!scope.confirmed) return sendJson(res, 409, { ok: false, reason: '项目根还没确认，先重新打开这个项目' });
      const operationId = typeof body.operationId === 'string' ? body.operationId : '';
      try {
        const result = typeof body.enabled === 'boolean' || typeof body.mode === 'string'
          ? setMemoryControl(scope, {
            ...(typeof body.enabled === 'boolean' ? { enabled: body.enabled } : {}),
            ...(typeof body.mode === 'string' ? { mode: body.mode } : {}),
          }, { operationId })
          : { ok: true, ...controlStatus(scope) };
        if (typeof body.enabled === 'boolean' && result && result.ok !== false && body.enabled === false) {
          personaAbortHook();
          /** 这个项目已经退出「记住我」：它没整理完的片段不能留到别的项目里再学。 */
          try { personaStore.dropPersonaPendingForProject({ projectId: scope.key }); } catch { /* 画像写不动不影响关开关 */ }
          const controller = learningAborts.get(scope.key);
          if (controller) {
            try { controller.abort(); } catch { /* already gone */ }
            learningAborts.delete(scope.key);
          }
        }
        return sendJson(res, result.ok === false ? 409 : 200, {
          ...result,
          project: path.basename(scope.cwd || '') || scope.key,
        });
      } catch (error) {
        return sendJson(res, 409, { ok: false, reason: error instanceof Error ? error.message : '记忆开关没有改动' });
      }
    }

    /**
     * 项目实验开关：作用域只由服务端按 cwd 判，身份不确定就不写。
     * 不传 enabled 是查状态；传布尔才是切换，切换在项目锁里旋转 epoch。
     */
    if (action === 'evolution') {
      const sessionId = typeof body.sessionId === 'string' ? body.sessionId : '';
      if (!sessionId) return sendJson(res, 400, { ok: false, reason: '缺少 sessionId' });
      const cwd = typeof cwdForSession === 'function' ? cwdForSession(sessionId) : '';
      if (!cwd) return sendJson(res, 409, { ok: false, confirmed: false, reason: '这个会话还没有项目目录' });
      const scope = scopeOf(cwd);
      if (!scope.confirmed) {
        return sendJson(res, 409, { ok: false, confirmed: false, reason: '项目根还没确认，先重新打开这个项目' });
      }
      const operationId = typeof body.operationId === 'string' ? body.operationId : '';
      const learningAction = typeof body.learningAction === 'string' ? body.learningAction : '';
      if (learningAction) {
        try {
          if (learningAction !== 'snapshot' && !memoryEnabled(scope)) {
            return sendJson(res, 409, { ok: false, code: 'memory_disabled', reason: '本项目记忆已关闭' });
          }
          if (learningAction === 'snapshot') {
            /** 查看不改盘：到期状态在写入事务里清理，读路径不写文件。 */
            const request = typeof body.sessionId === 'string' ? body.sessionId : '';
            return sendJson(res, 200, {
              ok: true,
              ...learningSnapshot(scope),
              payload: { bytes: request && payloadBytes.has(request) ? payloadBytes.get(request) : null },
            });
          }
          /** 用户显式管理动作顺带跑一次生命周期：同一项目 24 小时内最多一次，每次最多 8 条。 */
          maybeExpire(scope, {});
          const id = typeof body.id === 'string' ? body.id : '';
          if (learningAction === 'undo') {
            const result = undoLearningChange(scope, id, {
              expectedRevision: Number(body.expectedRevision || 0),
              operationId: operationId || `undo_learn_${id}_${Date.now()}`,
            });
            return sendJson(res, result && result.ok !== false ? 200 : 409, { ...result });
          }
          if (learningAction === 'pin') {
            const result = pinLearningRule(scope, id, {
              pinned: body.pinned === true,
              expectedRevision: Number(body.expectedRevision || 0),
              operationId: operationId || `pin_learn_${id}_${Date.now()}`,
            });
            return sendJson(res, result && result.ok !== false ? 200 : 409, { ...result });
          }
          if (learningAction === 'adopt') {
            const result = adoptLearningRule(scope, id, {
              expectedRevision: Number(body.expectedRevision || 0),
              title: typeof body.title === 'string' ? body.title : '',
              body: typeof body.body === 'string' ? body.body : '',
              operationId: operationId || `adopt_learn_${id}_${Date.now()}`,
            });
            return sendJson(res, result && result.ok !== false ? 200 : 409, { ...result });
          }
          if (learningAction === 'edit') {
            const result = editLearningRule(scope, id, {
              expectedRevision: Number(body.expectedRevision || 0),
              title: typeof body.title === 'string' ? body.title : '',
              body: typeof body.body === 'string' ? body.body : '',
              operationId: operationId || `edit_learn_${id}_${Date.now()}`,
            });
            return sendJson(res, result && result.ok !== false ? 200 : 409, { ...result });
          }
          if (learningAction === 'pause') {
            const ids = Array.isArray(body.ids) ? body.ids.filter((value) => typeof value === 'string').slice(0, 12) : [];
            const result = pauseLearningRules(scope, ids, { operationId: operationId || `pause_learn_${Date.now()}`, by: 'management', reason: 'paused_by_user' });
            return sendJson(res, result && result.ok !== false ? 200 : 409, { ...result });
          }
          if (learningAction === 'delete' || learningAction === 'discard') {
            const result = removeLearningRule(scope, id, {
              expectedRevision: Number(body.expectedRevision || 0),
              operationId: operationId || `delete_learn_${id}_${Date.now()}`,
            });
            return sendJson(res, result && result.ok !== false ? 200 : 409, { ...result });
          }
          if (learningAction === 'resume') {
            const result = resumeLearningRule(scope, id, { operationId: operationId || `resume_learn_${id}_${Date.now()}` });
            return sendJson(res, result && result.ok !== false ? 200 : 409, { ...result });
          }
          return sendJson(res, 400, { ok: false, reason: '不认识这个操作' });
        } catch (error) {
          return sendJson(res, 409, { ok: false, reason: error instanceof Error ? error.message : '这次没有改动' });
        }
      }
      try {
        const result = typeof body.enabled === 'boolean'
          ? setEvolution(scope, body.enabled, { operationId })
          : { ok: true, ...evolutionStatus(scope) };
        if (typeof body.enabled === 'boolean' && result && result.ok !== false) {
          const controller = learningAborts.get(scope.key);
          if (controller) {
            try { controller.abort(); } catch { /* already gone */ }
            learningAborts.delete(scope.key);
          }
        }
        return sendJson(res, result.ok === false ? 409 : 200, {
          ...result,
          project: path.basename(scope.cwd || '') || scope.key,
        });
      } catch (error) {
        return sendJson(res, 409, { ok: false, reason: error instanceof Error ? error.message : '实验开关没有改动' });
      }
    }

    if (action === 'citations') {
      const sessionId = typeof body.sessionId === 'string' ? body.sessionId : '';
      if (!sessionId) return sendJson(res, 400, { ok: false, reason: '缺少 sessionId' });
      return sendJson(res, 200, { ok: true, ...listCitations(sessionId) });
    }

    /** 面板只带会话：工作目录由会话身份查，客户端不用抄路径。 */
    const cwd = typeof body.cwd === 'string' && body.cwd
      ? body.cwd
      : (typeof body.sessionId === 'string' ? cwdForSession(body.sessionId) || '' : '');
    if (cwd.length === 0) return sendJson(res, 400, { ok: false, reason: '请求不完整' });
    const scope = scopeOf(cwd);
    const id = typeof body.id === 'string' ? body.id : '';
    const candidateId = typeof body.candidateId === 'string' && body.candidateId
      ? body.candidateId
      : typeof body.suggestionId === 'string' ? body.suggestionId : '';
    const sessionId = typeof body.sessionId === 'string' ? body.sessionId : '';

    /** 总开关关闭时面板只能看：保留、拒绝、搬移、撤销都不落盘。 */
    if (!controlStatus(scope).enabled) {
      return sendJson(res, 409, { ok: false, reason: memoryOffCopy(scope), code: 'memory_disabled' });
    }

    if (action === 'move' || action === 'resume-move') {
      const operationId = typeof body.operationId === 'string' ? body.operationId : '';
      /**
       * 搬移只认会话身份推出的项目：请求参数里的 cwd 能让 A 会话把 B 项目的记忆搬走，
       * 这里不再回落到 body.cwd；推不出来就直接拒绝。
       */
      const ownCwd = typeof body.sessionId === 'string' ? cwdForSession(body.sessionId) || '' : '';
      if (!ownCwd) return sendJson(res, 400, { ok: false, reason: '请求不完整', code: 'missing_session' });
      const moveScope = scopeOf(ownCwd);
      try {
        const done = action === 'resume-move'
          ? resumeMove(moveScope, { operationId })
          : move(moveScope, id, { target: body.target === 'global' ? 'global' : 'project', operationId });
        return sendJson(res, done.status === 'move_pending' ? 202 : 200, { ok: true, ...done });
      } catch (error) {
        const pending = (() => { try { return movePending(); } catch { return null; } })();
        return sendJson(res, 409, {
          ok: false,
          reason: error instanceof Error ? error.message : '搬移失败',
          pending: pending ? { operationId: pending.operationId } : null,
        });
      }
    }

    if (action === 'undo') {
      const undoTitle = typeof body.title === 'string' ? body.title.trim() : '';
      if (!id && !undoTitle) return sendJson(res, 400, { ok: false, reason: '缺少标题' });
      const located = id ? locate(scope, id)
        : locateByTitle(scope, undoTitle, { revision: Number.isInteger(body.revision) ? body.revision : undefined });
      if (!located) return sendJson(res, 404, { ok: false, reason: '没有这条记忆' });
      /** 撤销是精确动作：必须带当时看到的版本；缺版本就不猜，免得撤掉别人后来的修改。 */
      if (!Number.isInteger(body.revision) || body.revision < 1) {
        return sendJson(res, 400, { ok: false, reason: '缺少版本' });
      }
      try {
        const undone = undoChange(scope, located.record.id, { expectedRevision: body.revision });
        if (!undone) return sendJson(res, 404, { ok: false, reason: '没有这条记忆' });
        return sendJson(res, 200, { ok: true, title: undone.title, revision: undone.revision, mode: undone.mode });
      } catch (error) {
        return sendJson(res, 409, { ok: false, reason: error instanceof Error ? error.message : '撤销失败' });
      }
    }

    if (action === 'reject') {
      if (!candidateId) return sendJson(res, 400, { ok: false, reason: '缺少 candidateId' });
      const dropped = rejectCandidate(scope, candidateId);
      return sendJson(res, dropped.ok ? 200 : 404, dropped);
    }

    if (!candidateId) return sendJson(res, 400, { ok: false, reason: '缺少 candidateId' });
    const operationId = typeof body.operationId === 'string' ? body.operationId : '';
    try {
      const kept = acceptCandidate(scope, candidateId, operationId);
      if (!kept.ok) {
        return sendJson(res, kept.reason === '候选与已有条目相近，需要确认' ? 409 : 404, kept);
      }
      if (kept.id) recordCitations(scope, sessionId, [{ id: kept.id, title: kept.title }]);
      return sendJson(res, 200, kept);
    } catch (error) {
      return sendJson(res, 409, { ok: false, reason: error instanceof Error ? error.message : '保存失败' });
    }
  };
}

/** 给界面的事件引用：只有定位与版次，不带正文，避免把维护字段当内容画出来。 */
/** 保存失败的统一回执：字段与成功回执同形，渲染只报这一次没写成。 */
function saveFailure(message, args) {
  return {
    title: String(args && args.title || '').trim(), summary: '', when: '', revision: 0,
    merged: false, changed: false, scope: '', needsResolution: false, needsScope: false,
    archived: '', error: String(message || '').replace(/^memory · /, ''),
  };
}

/** 软提示：只提醒怎么写更好，不拦写入、不改正文；命中才给一行。 */
function qualityHintsOf(draft) {
  const body = String((draft && draft.body) || '');
  const summary = String((draft && draft.summary) || '');
  const when = String((draft && draft.when) || '');
  const hints = [];
  const bodyBytes = Buffer.byteLength(body);
  const lines = body.split('\n').filter((line) => line.trim());
  if (bodyBytes > 600 || lines.length > 8) hints.push('细节较多，只留判断规则和触发条件');
  if (/\/tmp\/|[~]\/\.cache\/|\/var\/folders\//.test(body)) hints.push('引用临时路径，换机器就失效');
  const conditional = /只在|仅当|仅限|只有/.test(`${summary}\n${when}\n${body}`);
  const hasConditions = Array.isArray(draft && draft.conditions) && draft.conditions.length > 0;
  if (conditional && !hasConditions) hints.push('建议补适用条件');
  /** 三个以上小标题通常是几条互不相干的事摞成一条；两条（背景 / 结论）是正常结构，不算。 */
  const sections = (body.match(/^#{2,3}\s+\S/gm) || []).length;
  if (sections >= 3) hints.push('混合多个主题，建议拆分');
  return hints;
}

/** 硬上限没收下时的统一回执：告诉模型怎么拆，而不是只说失败。 */
function compactionFailure(message, args, scope) {
  return {
    ...saveFailure(message, args),
    stored: false,
    needsCompaction: true,
    maxBytes: state.LIMITS.entryBytes,
    suggestedAction: `拆成多条保存：每条只写一个判断规则，正文压到 ${state.LIMITS.entryBytes} 字节以内；完整原句留在对话里，不抄进记忆`,
  };
}

function originOut(value) {
  return value === 'project_evolution' || value === 'model_drafted' ? value : 'user_explicit';
}

function refsOf(hits) {
  return hits.map((item) => ({
    title: item.title || '',
    scope: item.scope || 'project',
    revision: item.revision || 1,
    status: item.status || 'ok',
    origin: originOut(item.origin),
    /** 界面要按类型分开展示（偏好/约定/流程/资料），维护字段不进正文。 */
    kind: typeof item.kind === 'string' && item.kind ? item.kind : 'note',
    when: typeof item.when === 'string' ? item.when : '',
    /** 界面要能说「N 天前更新」，只给时间不给正文。 */
    updated: typeof item.updated === 'string' ? item.updated : '',
  }));
}

const SAVE_PARAMS = {
  type: 'object',
  properties: {
    updateTitle: { type: 'string', description: '要更新的已有条目标题；同一件事就地更新，不新建' },
    title: { type: 'string', description: `标题，名词短语，≤${LIMITS.titleChars} 字；就是条目身份` },
    summary: { type: 'string', description: '一句话说明记什么；超长截断' },
    body: { type: 'string', description: `正文 markdown，≤${LIMITS.entryBytes} 字节；只写原则、判断规则、触发条件和边界` },
    when: { type: 'string', description: `适用场景（机器/环境/情况），≤${LIMITS.whenChars} 字；同标题不同 when 可存两条` },
    kind: { type: 'string', enum: ['preference', 'convention', 'procedure', 'pointer', 'pitfall', 'credential_hint', 'note'], description: '条目类型；更新不给则保留' },
    tags: { type: 'array', items: { type: 'string' }, description: '最多 5 个' },
    supersedes: {
      type: 'string',
      description: '被取代的旧条目标题；旧条目留在历史',
    },
    resolution: {
      type: 'string',
      enum: ['distinct', 'merge', 'discard'],
      description: '自己裁决：distinct 换标题另存、merge 并进相近那条（配 mergeInto）、discard 不存',
    },
    mergeInto: { type: 'string', description: 'resolution="merge" 时并进哪条的标题，不给取最相近' },
    scope: { type: 'string', enum: ['auto', 'project', 'global'], description: 'auto（默认）/ project / global；用户明确说「所有项目」才 global，本机路径、端口、项目事实降为项目层' },
    memoryClass: { type: 'string', enum: ['personal_preference', 'project_fact', 'environment_fact', 'portable_procedure'], description: '归属：个人偏好/项目事实/设备事实/可搬流程；设备事实须带条件' },
    durability: { type: 'string', enum: ['durable', 'task'], description: 'durable（默认）或 task（一次性参数，不落盘）' },
    evidenceRef: { type: 'string', description: '归属依据：哪条消息/文件/观察' },
    sameTopicAs: {
      type: 'object',
      description: '绑定已有主题槽位；标题对不上则不写',
      properties: {
        scope: { type: 'string', enum: ['project', 'global'] },
        title: { type: 'string' },
      },
      required: ['scope', 'title'],
      additionalProperties: false,
    },
    mode: {
      type: 'string',
      enum: ['patch', 'replace_current'],
      description: 'patch（默认，未给字段保留）或 replace_current（整条替换，须给 title/summary/body/kind）',
    },
    applicability: {
      type: 'string',
      enum: view.APPLICABILITY,
      description: 'all_in_scope / conditional（须给 conditions）/ unresolved（默认）',
    },
    conditions: {
      type: 'array',
      description: '最多 8 条；空数组清空',
      items: {
        type: 'object',
        properties: {
          key: { type: 'string', enum: view.CONDITION_KEYS },
          value: { type: 'string' },
        },
        required: ['key', 'value'],
        additionalProperties: false,
      },
    },
    selection: {
      type: 'object',
      description: '只对某产物成立：complete 清单完整（须 artifactKey）/ examples 仅举例；clearSelection 清空',
      properties: {
        mode: { type: 'string', enum: view.SELECTION_MODES },
        artifactKey: { type: 'string' },
        items: { type: 'array', items: { type: 'string' }, description: 'examples 的举例清单' },
      },
      required: ['mode'],
      additionalProperties: false,
    },
    links: {
      type: 'array',
      description: '最多 3 条，目标须存在；空数组清空',
      items: {
        type: 'object',
        properties: {
          type: { type: 'string', enum: view.LINK_TYPES, description: '默认 related' },
          title: { type: 'string', description: '被关联条目标题' },
        },
        required: ['title'],
        additionalProperties: false,
      },
    },
    triggers: {
      type: 'array',
      items: { type: 'string' },
      description: '自动召回触发词，最多 4 个；空数组清空',
    },
    topicKey: { type: 'string', description: '主题槽位，去重用；空串清空' },
    clearSelection: { type: 'boolean', description: 'true 清掉 selection' },
  },
  required: ['title', 'summary'],
  additionalProperties: false,
};

const SUGGEST_PARAMS = {
  ...SAVE_PARAMS,
  properties: Object.fromEntries(Object.entries(SAVE_PARAMS.properties).filter(([key]) => !['scope', 'id', 'updateTitle', 'resolution', 'mergeInto', 'memoryClass', 'durability', 'evidenceRef', 'sameTopicAs', 'supersedes', 'mode'].includes(key))),
};

const SEARCH_PARAMS = {
  type: 'object',
  properties: {
    query: { type: 'string', description: '要查的主题；用用户原话里的词，长句也行' },
    limit: { type: 'integer', minimum: 1, maximum: 4, description: '最多返回几条，默认 3' },
    history: { type: 'boolean', description: '连已归档的旧记录一起找；默认只看当前有效' },
    contextId: { type: 'string', description: '上一轮索引或工具结果给的任务上下文 id' },
    bindForRequest: { type: 'boolean', description: '把这次选择绑定为本请求的任务；有 contextId 时带上' },
  },
  required: ['query'],
  additionalProperties: false,
};

const READ_PARAMS = {
  type: 'object',
  properties: {
    title: { type: 'string', description: '标题或 id，展示行可原样粘贴' },
    view: { type: 'string', enum: ['full', 'links'], description: '默认 full 读正文；links 只看相关清单，不取正文' },
    scope: { type: 'string', enum: ['project', 'global'], description: '只在指定层解析标题；默认先当前项目再全局' },
    contextId: { type: 'string', description: '上一轮给的上下文 id；读实验规则时带上' },
    taskKind: { type: 'string' },
    taskSeriesId: { type: 'string' },
    taskPhase: { type: 'string' },
    taskArtifactKey: { type: 'string' },
  },
  additionalProperties: false,
};

const FORGET_PARAMS = {
  type: 'object',
  properties: {
    title: { type: 'string', description: '要忘掉的那条记忆的标题' },
    scope: { type: 'string', enum: ['project', 'global'], description: '只在指定层解析标题；默认先当前项目再全局' },
    mode: {
      type: 'string',
      enum: ['archive', 'purge'],
      description: 'archive 移入归档可找回（只是不想再提）；purge 彻底忘掉，正文与受管副本清除且不可复活。没点明是哪种就两种都别做，先问用户',
    },
  },
  additionalProperties: false,
};

/**
 * 按标题解析内部身份。对外仍只显示标题，但解析必须能说明「唯一 / 同层歧义 / 不存在」：
 * 同层同名只应剩一条（旧数据残留才会撞上歧义），跨层同名才是常态。
 */
/**
 * 展示格式不是句柄：召回卡/搜索结果印的是「[项目] 「标题」（场景）」，
 * 解析时先剥掉装饰再按裸标题找，别让「原样抄」变成三次失败。
 */
function cleanTitleHandle(value) {
  let text = String(value ?? '').trim();
  if (!text) return '';
  const quoted = text.match(/「([^」]+)」/);
  if (quoted && quoted[1].trim()) return quoted[1].trim();
  text = text.replace(/^\[[^\]]{0,40}\]\s*/, '');
  text = text.replace(/^[「『"“]([\s\S]*)[」』"”]$/, '$1');
  text = text.replace(/\s*（[^（）]*）\s*$/, '');
  return text.trim();
}

function titleHitsIn(target, title, { includeArchived = false } = {}) {
  let index;
  try { index = loadIndex(target); } catch { return []; }
  const rows = includeArchived ? (index.archived || []) : (index.entries || []);
  return rows.filter((entry) => entry && (includeArchived || entry.status !== 'archived')
    && String(entry.title || '').trim() === title);
}

function candidateNote(entry) {
  const conditions = Array.isArray(entry.conditions) ? entry.conditions.filter((row) => row && row.key) : [];
  const parts = [];
  if (entry.when) parts.push(String(entry.when));
  if (conditions.length) parts.push(conditions.map((row) => `${row.key}=${row.value}`).join('·'));
  return parts.join('，');
}

/** 同层同名时把候选条件一起报出来，模型/用户才能决定改哪条或先归档哪条。 */
function ambiguousTitleError(title, hits, label) {
  const detail = hits.slice(0, 4).map((entry) => {
    const note = candidateNote(entry);
    return note ? `「${title}」（${note}）` : `「${title}」`;
  }).join('、');
  return `${label}「${title}」有 ${hits.length} 条同名，无法确定是哪一条：${detail}。先归档其中一条，或换一个能区分的标题再试`;
}

/**
 * 标题解析失败时给几条相近的完整标题：上下文里常只剩缩短的标题，
 * 精确匹配失败就地列出候选，比让模型再猜一次省一轮。
 */
function nearTitleHints(targets, title) {
  const out = [];
  const seen = new Set();
  for (const target of targets) {
    let index;
    try { index = loadIndex(target); } catch { continue; }
    for (const entry of [...(index.entries || []), ...(index.archived || [])]) {
      const current = String(entry && entry.title || '').trim();
      if (!current || current === title || seen.has(current)) continue;
      if (!current.includes(title) && !title.includes(current)) continue;
      seen.add(current);
      out.push(current);
      if (out.length >= 3) return out;
    }
  }
  return out;
}

/**
 * 只读路径的兜底：上下文里常只剩缩短的标题（「npm 发布一律走 dsh-npm」对
 * 「npm 发布一律走 dsh-npm，ENEEDAUTH 不是缺凭据」），精确匹配失败时只有一条
 * 前缀关系成立且缩写本身够长，就直接认这条；能对上两条以上仍报接近候选，不猜。
 * 写和忘不走这条：认错条目的代价比多问一轮大。
 */
function nearTitleMatches(targets, title) {
  const wanted = String(title || '').trim().toLowerCase();
  if (wanted.length < 6) return [];
  const out = [];
  const seen = new Set();
  for (const target of targets) {
    let index;
    try { index = loadIndex(target); } catch { continue; }
    for (const entry of [...(index.entries || []), ...(index.archived || [])]) {
      const plain = String(entry && entry.title || '').trim().toLowerCase();
      if (!plain || plain === wanted || !entry.id || seen.has(entry.id)) continue;
      /** 前缀关系（不是随便包含）才算同一个标题的缩写：「发布」「顺序」这类碎片不进来。 */
      if (!plain.startsWith(wanted) && !wanted.startsWith(plain)) continue;
      seen.add(entry.id);
      out.push(entry);
    }
  }
  return out;
}

/**
 * 返回 { id } 或抛出：显式层只查那一层；默认先项目后全局（别的项目不参与解析）。
 * 同一层出现多条同名一律报歧义，绝不取第一条。
 * adoptNear 只在读的时候开：唯一一条前缀匹配就地命中，读工具不该因为标题少几个字空转。
 */
function refIdOf(scope, args, label = '记忆', options = {}) {
  const id = typeof args.id === 'string' ? args.id.trim() : '';
  if (id) return id;
  const rawTitle = typeof args.title === 'string' ? args.title.trim() : '';
  const received = String(rawTitle ?? '').trim();
  const title = cleanTitleHandle(rawTitle);
  if (!title) throw new Error(`要读或要忘一条${label}，先给标题`);
  /** 显式指定层时只解析那一层：同名条目不会被顺手改掉，项目层也不会命中全局。 */
  const explicit = args && args.scope === 'global' ? globalScope() : args && args.scope === 'project' ? scope : null;
  const sources = explicit ? [explicit] : runtimeLayers(scope);
  let crossLayerHit = null;
  for (const target of sources) {
    const hits = titleHitsIn(target, title);
    if (hits.length > 1) throw new Error(ambiguousTitleError(title, hits, label));
    if (hits.length === 1 && !crossLayerHit) crossLayerHit = hits[0];
  }
  if (crossLayerHit) return crossLayerHit.id;
  /** 忘掉已归档的条目也要能按标题解析到；归档不会因此重新参与召回。 */
  for (const target of sources) {
    const hits = titleHitsIn(target, title, { includeArchived: true });
    if (hits.length > 1) throw new Error(ambiguousTitleError(title, hits, label));
    if (hits.length === 1) return hits[0].id;
  }
  const near = nearTitleHints(sources, title);
  if (near.length) {
    if (options.adoptNear) {
      const matches = nearTitleMatches(sources, title);
      /** 收并后的旧副本会留在归档里：它和活条目同名前缀，不该把唯一答案拖成歧义。 */
      const live = matches.filter((entry) => entry.status !== 'archived' && entry.archived !== true);
      const pick = live.length ? live : matches;
      if (pick.length === 1) return pick[0].id;
    }
    throw new Error(`没有「${received || title}」这条${label}。相近的里有：${near.map((item) => `「${item}」`).join('、')}；展示行可原样粘贴，也可以给 id`);
  }
  throw new Error(`没有「${received || title}」这条${label}；标题可粘展示行或给 id，也可以先用 memory_search 对一下`);
}

/** 同名条目可能分布在项目层和全局层：更新前先报候选，不能先匹配。 */
function titleCandidates(scope, title) {
  const out = [];
  for (const target of runtimeLayers(scope)) {
    const hits = titleHitsIn(target, title);
    if (!hits.length) continue;
    if (hits.length > 1) out.push({ ambiguous: true, title, hits, scope: target.key === 'global' ? 'global' : 'project' });
    else out.push({ id: hits[0].id, scope: target.key === 'global' ? 'global' : 'project', note: candidateNote(hits[0]) });
  }
  return out;
}

/** 记忆归属标记：全局 `[global]`，项目用项目目录名（如 `[DSH]`）。 */
function projectNameOf(scope) {
  const base = scope && scope.cwd ? path.basename(scope.cwd) : '';
  return String(base || '').replace(/[^\w.\-\u4e00-\u9fff]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 16);
}

function scopeTag(value) {
  if (value && value.scope === 'global') return '[global]';
  if (value && value.scopeName) return `[${value.scopeName}]`;
  return '';
}

function withTag(value, text) {
  const tag = scopeTag(value);
  return tag ? `${tag} ${text}` : text;
}

/** 候选要能自己解释「什么时候的、为什么像」，模型才好判断是更新还是另一条。 */
function humanAge(iso) {
  const at = Date.parse(String(iso || ''));
  if (!Number.isFinite(at)) return '';
  const days = Math.floor((Date.now() - at) / 86400000);
  if (days <= 0) return '今天';
  if (days === 1) return '昨天';
  if (days < 30) return `${days} 天前`;
  if (days < 365) return `${Math.floor(days / 30)} 个月前`;
  return `${Math.floor(days / 365)} 年前`;
}

function describeCandidate(item, options = {}) {
  const age = humanAge(item.updated);
  const why = options.sameTopic ? '' : item.reason === 'similar_summary' ? '摘要相近' : '标题相近';
  const parts = [`「${item.title}」`];
  if (age) parts.push(`${age}更新`);
  if (item.when) parts.push(item.when);
  if (why) parts.push(why);
  if (item.summary) parts.push(item.summary);
  return parts.join(' · ');
}

function statusLabel(status) {
  if (status === 'archived') return ' · 已归档';
  if (status === 'needs_context') return ' · 适用范围待确认';
  if (status === 'not_applicable') return ' · 当前条件不适用';
  if (status === 'gone') return ' · 已删除';
  if (status && status !== 'ok') return ` · ${status}`;
  return '';
}

/**
 * 自动召回：用户这句话真跟已有记忆有关才给一张短卡，整条索引不常驻。
 * 策略、预算与冻结快照都在 apply 内部，provider 只读内存。
 */
export const RECALL_MODES = ['adaptive', 'tool_only', 'off'];
const RECALL_QUERY_CHARS = 400;
/**
 * 单轮投影的耗时上限：慢机器上宁可这轮不注入，也不把回合拖住。测试可临时放宽。
 * 条目多了以后，索引解析和指纹计算本身就随条数线性涨；固定 150ms 会在 600 条左右
 * 随机丢整轮召回（投影已经算完，却被耗时判丢弃）。所以上限按可见条目数放宽，
 * 每多 8 条加 1ms，最多到 400ms；低于 200 条仍是原来的 150ms。
 */
let recallDeadlineMs = 150;
const RECALL_DEADLINE_MAX = 400;
const RECALL_DEADLINE_FREE_ENTRIES = 200;
const RECALL_DEADLINE_ENTRIES_PER_MS = 8;
/** 本项目的投影耗时上限：条目越多给得越宽，但封顶，避免病态项目无限拖慢首字。 */
function recallDeadlineFor(scope) {
  const base = recallDeadlineMs;
  try {
    const count = loadIndex(scope).entries.length + loadIndex(globalScope()).entries.length;
    const extra = Math.max(0, count - RECALL_DEADLINE_FREE_ENTRIES) / RECALL_DEADLINE_ENTRIES_PER_MS;
    /** 显式放宽（测试/宿主）永远优先：只往上放，不因为封顶反而收紧。 */
    return Math.max(base, Math.min(RECALL_DEADLINE_MAX, base + Math.floor(extra)));
  } catch {
    return base;
  }
}
const RECALL_HEADER = '已有记忆可能相关（需要细节用 memory_read 带标题取正文，别凭标题猜）：';

/** 卡片行格式只在 view.js 定义一份：回放算字节必须和线上注入逐字一致。 */
const renderRecallCard = (card) => view.renderCard(card);

export function apply(ctx, config) {
  const tools = ctx.tools;
  const getService = (name) => (typeof ctx.get === 'function' ? ctx.get(name) : undefined);

  /** 关掉记忆的会话看不到这组工具；每次进入新步骤前按当前开关同步一次。 */
  const hiddenTools = new WeakMap();
  const memoryOnForAgent = (agent) => {
    try {
      return memoryEnabled(scopeOf(cwdOf({ agent })));
    } catch {
      return true;
    }
  };
  const syncMemoryTools = (agent) => {
    const scoped = agent?.ctx?.tools;
    if (!scoped) return;
    const dispose = hiddenTools.get(agent);
    if (memoryOnForAgent(agent)) {
      if (!dispose) return;
      hiddenTools.delete(agent);
      try { dispose(); } catch { /* scope already gone */ }
      return;
    }
    if (dispose) return;
    try { hiddenTools.set(agent, scoped.restrict({ deny: MEMORY_TOOLS })); } catch { /* no global tools to mask */ }
  };

  /* ---------------- 自动召回：策略、冻结快照、任务窗口与请求预算 ---------------- */

  /** 升级不覆盖用户的选择：默认 adaptive，别的模式只由明确配置切换。 */
  const recallMode = () => (RECALL_MODES.includes(config?.mode) ? config.mode : 'adaptive');
  hostRecallMode = recallMode();
  /** 项目自己的选择优先；没有写过就跟随插件配置，升级不改用户选择。 */
  const modeFor = (scope) => {
    try {
      const mode = controlStatus(scope).mode;
      return RECALL_MODES.includes(mode) ? mode : recallMode();
    } catch {
      return recallMode();
    }
  };
  /** 已准备好的快照只挂在 Agent 上，弱引用随手回收，不跨会话串。 */
  const prepared = new WeakMap();
  /**
   * 写入授权单独记，不跟 prepared 走：召回为空、工具模式、面板上一步都可能清掉快照，
   * 但「这句话是不是用户亲口说的」不能跟着丢，否则否定句会被当成跨项目授权。
   * 只认同一 turn 的真人原话，换一轮自动作废。
   */
  const requestAuth = new WeakMap();
  /** 最近一次请求的任务身份：本轮没注入任何内容时 prepared 会清掉，补查仍需要知道上一轮任务。 */
  const lastTask = new Map();
  /** 任务本身也要独立于 prepared：轮次收尾只清投影，不把「刚才在做什么」一起清掉。 */
  const recallTasks = new Map();
  /** turn-stopping 只回 signal，不带头 agent；这里记 signal → agent 供收尾清理。 */
  const signalAgents = new Map();
  const generations = new WeakMap();
  /** 同一真人请求共用一个额度窗口；provider 只读，不记账。 */
  const windows = new Map();
  /**
   * 同一任务里同一条记忆只记一次使用。
   * 任务内反复读到（续说、重查、换工具）不该把活跃度和有益反馈反复抬高；
   * 换任务（新的起始消息）才重新算一次。
   */
  const usedByTask = new Map();
  const TASK_USED_MAX = 24;
  const abortCleanups = new Map();
  /** 哪些用户消息已经建立过窗口；工具续步不重复开窗。 */
  const seenHumans = new Map();
  /** 本轮真人反馈先记在这里，等 turn/end 再决定要不要整理；不跨会话。 */
  const feedbackCandidates = new Map();
  /** 项目内反馈代次：每来一次新的可整理反馈就加一，旧整理结果必须作废。 */
  const feedbackRevisions = new Map();
  /** 按项目+作品记代次：别处的新反馈不该作废这一期的整理结果。 */
  const feedbackEpisodeRevisions = new Map();
  /** 一个项目同一时间只整理一次；控制器放在模块级供开关路由中止。 */
  const learningJobs = new Map();

  const agentKey = (agent) => String(agent?.id ?? '');

  /** 回合收尾/换请求时批量记账：一次锁，不在 provider 输出路径上。 */
  const flushUsage = (state) => {
    if (!state || !state.scope || !(state.deliveredIds instanceof Set) || state.deliveredIds.size === 0) return;
    const ids = [...state.deliveredIds].filter(Boolean);
    state.deliveredIds = new Set();
    if (!ids.length) return;
    /** 同一任务内已经记过的条目不再记第二遍；任务变了才重新记账。 */
    const taskKey = `${state.scope.key}\u0000${state.taskStartId || state.sessionId || ''}`;
    let seen = usedByTask.get(taskKey);
    if (!seen) {
      seen = new Set();
      usedByTask.set(taskKey, seen);
      while (usedByTask.size > TASK_USED_MAX) usedByTask.delete(usedByTask.keys().next().value);
    }
    const fresh = ids.filter((id) => !seen.has(id));
    if (!fresh.length) return;
    for (const id of fresh) seen.add(id);
    try { markUsed(state.scope, fresh); } catch { /* usage is best-effort */ }
  };

  const clearPrepared = (agent) => {
    if (!agent) return;
    const state = prepared.get(agent);
    if (state && state.signal) signalAgents.delete(state.signal);
    flushUsage(state);
    prepared.delete(agent);
    const key = agentKey(agent);
    const cleanup = key ? abortCleanups.get(key) : null;
    if (cleanup) {
      abortCleanups.delete(key);
      try { cleanup(); } catch { /* listener already gone */ }
    }
  };

  const windowOf = (agent) => windows.get(agentKey(agent)) || null;

  /** 取本轮真人原话：上一轮的授权不能给这一轮的写作用。 */
  const authorizedSaidOf = (agent) => {
    try {
      const held = agent ? requestAuth.get(agent) : null;
      if (!held || typeof held.said !== 'string' || !held.said) return '';
      const win = windowOf(agent);
      if (win && held.turn && win.turn !== held.turn) return '';
      return held.said;
    } catch {
      return '';
    }
  };

  /** 自动注入账本：普通段、实验段与「记住我」段共用 3 条 / 1200 字节，量的是拼接后的完整文本。 */
  const emptyAutoBudget = () => ({
    normalText: '', experimentText: '', personaText: '',
    normalCards: 0, experimentCards: 0,
    cards: 0, cardBytes: 0, experimentBytes: 0, personaBytes: 0, totalBytes: 0,
  });


  /** 预算按规范化 JSON 字节算：转义、中文、换行都算进模型真正收到的内容。 */
  const jsonBytes = (value) => Buffer.byteLength(JSON.stringify(value));

  function affordable(win, bytes, bodies = 0) {
    if (!win) return true;
    if (win.reads >= view.REQUEST_LIMITS.reads) return false;
    if (bodies && win.bodies + bodies > view.REQUEST_LIMITS.bodies) return false;
    return win.bytes + bytes <= view.REQUEST_BYTES;
  }

  /**
   * 工具自己取的记忆另算一笔：自动注入已经用满时，模型按标题来读正文不该被连带挡掉，
   * 否则用户看到的就是「额度已用完」这种没法处理的死路。
   */
  function affordableTool(win, bytes, bodies = 0) {
    if (!win) return true;
    if (win.reads >= view.REQUEST_LIMITS.reads) return false;
    if (bodies && win.bodies + bodies > view.REQUEST_LIMITS.bodies) return false;
    return (win.toolBytes || 0) + bytes <= view.TOOL_BYTES;
  }

  /** 续写轮没有新消息：沿用上一次能核对的请求上下文。 */
  const lastRuntime = new Map();
  const rememberRuntime = (scope, sessionId, held) => {
    if (!held || !sessionId) return;
    const key = `${scope.key}\u0000${sessionId}`;
    lastRuntime.delete(key);
    lastRuntime.set(key, held);
    if (lastRuntime.size > 20) lastRuntime.delete(lastRuntime.keys().next().value);
  };

  function openWindow(agent, { sessionId, turn, messageIds }) {
    const key = agentKey(agent);
    if (!key) return null;
    const signature = `${sessionId}\u0000${turn}\u0000${messageIds.join(',')}`;
    const existing = windows.get(key);
    if (existing && existing.signature === signature) return existing;
    const next = {
      signature, sessionId, turn, messageIds,
      bytes: 0, bodies: 0, reads: 0, toolBytes: 0,
      provided: new Map(), readBodies: new Map(), at: Date.now(),
      experiment: null, contexts: new Map(), runtime: null, autoBudget: null,
    };
    windows.set(key, next);
    return next;
  }

  /** 新消息才会建立新窗口；同一批消息在同一 turn 里只开一次。 */
  function freshHumans(sessionId, humans) {
    if (!humans.length) return [];
    const seen = seenHumans.get(sessionId) || new Set();
    const fresh = humans.filter((message) => {
      const id = String(message?.id ?? '');
      return id && !seen.has(id);
    });
    for (const message of humans) {
      const id = String(message?.id ?? '');
      if (id) seen.add(id);
    }
    while (seen.size > 400) seen.delete(seen.values().next().value);
    seenHumans.set(sessionId, seen);
    while (seenHumans.size > 64) seenHumans.delete(seenHumans.keys().next().value);
    return fresh;
  }

  /** 两层都算：任何一层换库、换代或清空，之前准备的卡片都要失效。 */
  /**
   * 同一请求的召回快照只要内容没变就保持原样：命中次数、使用时间这类使用记录
   * 不参与指纹，否则模型多读一次就会触发重投影。真正改变应看条目内容版本、
   * 启停/控制代号与自进化代号。
   */
  function fingerprintOf(scope) {
    try {
      return [scope, globalScopeView()].map((source) => {
        const index = loadIndex(source);
        const meta = index.__meta || {};
        const evolutionEpoch = index.__evolution && index.__evolution.epoch ? index.__evolution.epoch : '';
        const controlEpoch = index.__control && index.__control.epoch ? index.__control.epoch : '';
        const content = (index.entries || [])
          .map((entry) => `${entry.id}:${entry.revision || 1}:${entry.status || 'active'}:${entry.updated || ''}:${entry.topicKey || ''}`)
          .sort()
          .join(',');
        return `${index.scope}:${meta.storeId || ''}:${evolutionEpoch}:${controlEpoch}:${content}`;
      }).join('|');
    } catch {
      return '';
    }
  }

  const globalScopeView = () => globalScope();

  /** 纯内存：读两层当前投影，先判适用再排序，整卡装预算。 */
  function projectRecall(scope, query, context, win, runtime) {
    /** 检索调度：先按这一轮的话定档位，再决定查多深、给几张卡；字节上限仍由投递端封顶。 */
    const plan = scheduler.retrievalPlanOf(query, { cardMax: view.CARD.max });
    /** 档位预算是这一轮投递的天花板，实验段也要算在同一份额度里，交给后面的投影读。 */
    if (win) win.recallPlanBytes = plan.bytes;
    context = view.contextWithTask(context, runtime && runtime.task);
    const layers = { project: [], global: [] };
    const seen = new Set();
    for (const source of [scope, globalScope()]) {
      const layer = source.key === 'global' ? 'global' : 'project';
      let index;
      try { index = loadIndex(source); } catch { continue; }
      for (const item of index.entries) {
        if (!item || !item.title || item.status === 'archived') continue;
        /** 生命周期先于主题裁决：过期/被取代的条目不再参与分组，不能把现行条目标成冲突。 */
        if (view.lifecycleStatusOf(item)) continue;
        /** 实验来源只走任务绑定后的专用读取，不混进普通自动召回。 */
        if (item.origin === 'project_evolution') continue;
        if (seen.has(item.id)) continue;
        seen.add(item.id);
        layers[layer].push(item);
      }
    }
    /** 同一槽位只让胜出的规范进去；冲突或条件未知的整组不进自动召回。 */
    const groups = [...view.resolveTopics(layers.project, layers.global, context).values()];
    const records = [];
    const layerOf = new Map();
    for (const group of groups) {
      if (group.status !== 'ok' || !group.record) continue;
      records.push(group.record);
      layerOf.set(group.record.id, group.scope === 'global' ? 'global' : 'project');
    }
    const gateRuntime = runtime || (win && win.runtime) || null;
    const task = runtime && runtime.task ? runtime.task : null;
    /** 进化里被采纳的参数只影响排序阈值，绝不影响存储、隔离或授权；读不到就用默认值。 */
    const tuned = (() => {
      try {
        return evolveStore.readEvolve(scope).lab.params;
      } catch {
        return null;
      }
    })();
    const ranked = view.recallRank(records, query, {
      limit: plan.candidates, requireApplicable: true, context, runtime: gateRuntime, task,
      ...(tuned ? { params: tuned } : {}),
    });
    /** 普通记忆与实验规则共用一份自动注入预算：总条数和最终完整文本字节一起算。 */
    const auto = win && win.autoBudget ? win.autoBudget : null;
    /** 卡片上限含包装；共享请求账本也要把标题行算进去，不能只算卡片行。 */
    let headerCharged = win ? win.recallHeader === true : false;
    const lines = [];
    const linesMeta = [];
    const cards = [];
    /** 预算与准入挡下的卡片数：回执里要能说「候选几张、实际给几张、丢了几张」。 */
    let dropped = 0;
    for (const row of ranked) {
      const usedCards = cards.length + (auto ? (auto.experimentCards || 0) : 0);
      if (usedCards >= plan.cards) break;
      const card = view.cardOf(row.record, layerOf.get(row.record.id));
      if (card.scope === 'project') card.scopeName = projectNameOf(scope);
      const line = renderRecallCard(card);
      const nextText = `${RECALL_HEADER}\n${[...lines, line].join('\n')}`;
      /** 档位给的字节上限先看：这一张放进来就超了，直接跳过，不进候选也不记账。 */
      if (Buffer.byteLength(nextText) > plan.bytes) {
        dropped += 1;
        continue;
      }
      if (auto) {
        /** 实验段可能先渲染：组装成最终两段再量，超了就跳过这张，不把标题留在模型侧。 */
        const admitted = admitAuto(win, {
          normal: nextText,
          experiment: auto.experimentText || '',
          normalCards: cards.length + 1,
          experimentCards: auto.experimentCards || 0,
        });
        /** 准入被拒就不进输出：账本说不要，输出里也不能有。 */
        if (!admitted.ok) {
          dropped += 1;
          continue;
        }
      } else {
        const size = Buffer.byteLength(nextText);

        const cost = Buffer.byteLength(`\n${line}`) + (headerCharged ? 0 : Buffer.byteLength(RECALL_HEADER));

        if (win) win.bytes += cost;
      }
      const revision = card.revision || 1;
      if (win) win.provided.set(card.id, revision);
      if (win && !headerCharged) {
        headerCharged = true;
        win.recallHeader = true;
      }
      lines.push(line);
      cards.push({ id: card.id, revision, scope: card.scope, title: card.title });
      /** 卡片行与到期时间一起留到最后输出：中间隔了系统提示组装，不能拿投影时的判断当现在。 */
      linesMeta.push({ id: card.id, line, validUntil: row.record.validUntil || '' });
    }
    /** 每张准入时已按「拼上这一张后的完整文本」量过，最终文本必然在档位内，不再留二次清零分支。 */
    const finalText = `${RECALL_HEADER}\n${lines.join('\n')}`;
    if (auto) {
      /** 没有任何普通卡片时也要把已有实验段记账成当前状态。 */
      admitAuto(win, {
        normal: lines.length ? finalText : (auto.normalText || ''),
        experiment: auto.experimentText || '',
        normalCards: cards.length,
        experimentCards: auto.experimentCards || 0,
      });
    }
    /** 没卡片也要给出判断依据：面板要能回答「为什么这次没提醒我」。 */
    let near = [];
    if (!cards.length && !ranked.length) {
      /** 自动召回只认完全适用；再放宽一层看有没有字面匹配，好把「条件未确认」和「没有匹配」分开。 */
      near = view.recallRank(records, query, {
        limit: 8, requireApplicable: false, context, runtime: gateRuntime, task,
        ...(tuned ? { params: tuned } : {}),
      });
    }
    let waiting = near.some((row) => row.status !== 'ok' || row.record.reviewState === 'legacy_unreviewed');
    let nearMatched = near.length;
    /** 冲突与「条件未确认」是两种原因：前者要人先裁决，后者只差一句任务说明。 */
    let conflictNear = false;
    if (!cards.length && !ranked.length) {
      /** 整组被条件或冲突挡下的候选没进 records，单独按同一查询算；只计数，不投放。 */
      for (const group of groups) {
        if (group.status !== 'conflict' && group.status !== 'needs_context') continue;
        const hits = view.recallRank(group.records || [], query, {
          limit: 1, requireApplicable: false, context, runtime: gateRuntime, task,
          ...(tuned ? { params: tuned } : {}),
        });
        if (!hits.length) continue;
        waiting = true;
        if (group.status === 'conflict') conflictNear = true;
        nearMatched += hits.length;
      }
    }
    const reason = cards.length ? 'hit'
      : ranked.length ? 'budget'
        : conflictNear ? 'conflict'
          : waiting ? 'needs_context'
            : (gateRuntime && gateRuntime.enabled ? 'no_overlap' : 'needs_context');
    const matched = ranked.length || nearMatched;
    const ids = cards.map((card) => card.id).filter(Boolean);
    if (!cards.length) return { text: '', cards: [], lines: [], ids, bytes: 0, query, reason, matched, plan, dropped };
    return { text: finalText, cards, lines: linesMeta, ids, bytes: Buffer.byteLength(finalText), query, reason, matched, plan, dropped };
  }

  /* ---------------- 项目自进化：任务锚点、读取决策、上下文解析 ---------------- */

  const EXPERIMENT_INDEX_HEADER = '项目里这些记忆范围可能适用当前任务（未绑定）；需要细节再用 memory_search 带上 contextId：';
  const EXPERIMENT_RULES_HEADER = '项目实验规则（只在当前任务条件匹配时适用；细节用 memory_read 取正文，别凭标题猜）：';
  const EXPERIMENT_BYTES = view.CARD.bytes;
  const EXPERIMENT_SHORT_CHARS = 240;

  /** 登记过的栏目只能来自项目里已有的条件、默认值和实验条目，不从自由措辞里新造。 */
  function rangesOf(scope) {
    let index;
    try { index = loadIndex(scope); } catch { return { series: [], taskKinds: [], taskKind: '', seriesId: '' }; }
    const series = [];
    const taskKinds = [];
    const add = (list, value) => {
      const text = typeof value === 'string' ? value.trim().slice(0, 40) : '';
      if (text && !list.includes(text) && list.length < 8) list.push(text);
    };
    for (const record of [...index.entries, ...index.archived]) {
      if (record.reviewState === 'legacy_unreviewed') continue;
      for (const condition of record.conditions || []) {
        if (condition.key === 'seriesId') add(series, condition.value);
        if (condition.key === 'taskKind') add(taskKinds, condition.value);
      }
      const learning = record.learning || {};
      if (learning.seriesId) add(series, learning.seriesId);
      if (learning.taskKind) add(taskKinds, learning.taskKind);
    }
    const defaults = index.__tasks && index.__tasks.defaults ? index.__tasks.defaults : null;
    if (defaults) {
      add(series, defaults.seriesId);
      add(taskKinds, defaults.taskKind);
    }
    return {
      series, taskKinds,
      seriesId: defaults && defaults.seriesId ? defaults.seriesId : '',
      taskKind: defaults && defaults.taskKind ? defaults.taskKind : '',
    };
  }

  function conditionLabel(conditions) {
    return (Array.isArray(conditions) ? conditions : [])
      .map((condition) => `${condition.key}=${condition.value}`)
      .join('、');
  }

  /**
   * 自动注入只有一份预算：普通卡片、实验规则和「记住我」合计最多 3 条 / 1200 字节。
   * 这里按 provider 最终会看到的完整文本量字节（含标题行、ID、换行和段之间的空行），
   * 先组装再测量，不能只量卡片正文再拼。画像段先渲染，后面的卡片按剩下的额度装。
   */
  function autoTextOf(win, normal, experiment, personaText) {
    const auto = win && win.autoBudget ? win.autoBudget : null;
    const n = normal === undefined ? String(auto?.normalText || '') : String(normal || '');
    const e = experiment === undefined ? String(auto?.experimentText || '') : String(experiment || '');
    const p = personaText === undefined ? String(auto?.personaText || '') : String(personaText || '');
    return { normal: n, experiment: e, persona: p, text: [e, p, n].filter(Boolean).join('\n\n') };
  }

  function autoBytesOf(win, normal, experiment, personaText) {
    return Buffer.byteLength(autoTextOf(win, normal, experiment, personaText).text);
  }

  /**
   * 原子准入：量的是最终完整文本和总条数；通过才写入预算账本。
   * 任何一段超限都整段回退，不截半句前提、不把标题留在模型侧。
   */
  function admitAuto(win, { normal, experiment, persona, normalCards, experimentCards } = {}) {
    if (!win || !win.autoBudget) return { ok: false, bytes: 0 };
    const auto = win.autoBudget;
    const parts = autoTextOf(win, normal, experiment, persona);
    const cards = (normalCards === undefined ? (auto.normalCards || 0) : normalCards)
      + (experimentCards === undefined ? (auto.experimentCards || 0) : experimentCards);
    const bytes = Buffer.byteLength(parts.text);
    const capBytes = win && Number.isInteger(win.recallPlanBytes)
      ? Math.min(view.CARD.bytes, win.recallPlanBytes) : view.CARD.bytes;
    if (cards > view.CARD.max || bytes > capBytes) return { ok: false, bytes, cards };
    const previousTotal = Number(auto.totalBytes || 0);
    if (!affordable(win, bytes - previousTotal)) return { ok: false, bytes, cards };
    auto.normalText = parts.normal;
    auto.experimentText = parts.experiment;
    auto.personaText = parts.persona;
    auto.normalCards = normalCards === undefined ? (auto.normalCards || 0) : normalCards;
    auto.experimentCards = experimentCards === undefined ? (auto.experimentCards || 0) : experimentCards;
    auto.cards = cards;
    auto.cardBytes = Buffer.byteLength(parts.normal);
    auto.experimentBytes = Buffer.byteLength(parts.experiment);
    auto.personaBytes = Buffer.byteLength(parts.persona);
    auto.totalBytes = bytes;
    win.bytes += bytes - previousTotal;
    return { ok: true, bytes, cards };
  }

  /** 「记住我」段也走同一份自动注入预算：装不下就不投影，不把 1200 字节撑破。 */
  function chargePersona(win, block) {
    const body = String(block || '');
    if (!body) return '';
    const auto = win && win.autoBudget ? win.autoBudget : null;
    if (!auto) return body;
    const admitted = admitAuto(win, {
      normal: auto.normalText || '',
      experiment: auto.experimentText || '',
      persona: body,
      normalCards: auto.normalCards || 0,
      experimentCards: auto.experimentCards || 0,
    });
    return admitted.ok ? body : '';
  }

  /** 实验内容单独记账：同一请求里再次渲染替换旧段，只补差额。 */
  function chargeExperiment(win, text, cards = 1) {
    if (!text) return '';
    const auto = win && win.autoBudget ? win.autoBudget : null;
    if (auto) {
      const admitted = admitAuto(win, {
        normal: auto.normalText || '',
        experiment: text,
        normalCards: auto.normalCards || 0,
        experimentCards: cards,
      });
      if (!admitted.ok) return '';
      return text;
    }
    const bytes = Buffer.byteLength(`\n\n${text}`);
    const previous = win ? (win.experimentBytes || 0) : 0;
    /** 低档回合的 400 B 是整段投递的额度，实验段不能单独按 1200 B 算。 */
    const cap = win && Number.isInteger(win.recallPlanBytes)
      ? Math.min(EXPERIMENT_BYTES, win.recallPlanBytes) : EXPERIMENT_BYTES;
    if (bytes > cap) return '';
    if (win) {
      if (!affordable(win, bytes - previous)) return '';
      win.bytes += bytes - previous;
      win.experimentBytes = bytes;
    }
    return text;
  }

  /** 实验正文按条目记有效期：一条到期只撤一条，不把同请求里其他规则一起清掉。 */
  function experimentTextFrom(parts, now = Date.now()) {
    if (!parts || !Array.isArray(parts.items)) return '';
    const items = parts.items.filter((item) => !item.validUntil || now <= Date.parse(String(item.validUntil)));
    if (!items.length) return '';
    return `${parts.header}\n${items.map((item) => item.line).join('\n')}${parts.tail || ''}`;
  }

  /** 本轮问题与栏目名的字面相关度：只展示有交集的栏目，交集为空就整段跳过。 */
  function relevantRanges(names, query) {
    const text = String(query || '').toLowerCase();
    if (!text) return [];
    const tokens = new Set();
    for (const word of text.match(/[a-z][a-z0-9_-]{2,}/g) || []) tokens.add(word);
    for (const run of text.match(/[\u4e00-\u9fff]+/g) || []) {
      for (let i = 0; i + 2 <= run.length; i += 1) tokens.add(run.slice(i, i + 2));
    }
    if (!tokens.size) return [];
    return (Array.isArray(names) ? names : []).filter((name) => {
      const value = String(name || '').toLowerCase();
      if (!value) return false;
      if (text.includes(value)) return true;
      for (const token of tokens) if (value.includes(token)) return true;
      return false;
    });
  }

  /** 实验正文只在「自进化开着，且还是同一代」时可用；关掉再开不能复活旧正文。 */
  function experimentStillCurrent(scope, held) {
    let evolution;
    try { evolution = evolutionStatus(scope); } catch { return false; }
    if (!evolution || evolution.enabled !== true || evolution.compatible === false) return false;
    if (held && held.epoch && String(evolution.epoch || '') !== String(held.epoch)) return false;
    return true;
  }

  /** 读决策 → 一段短提示：未绑定只给栏目索引，已绑定才给规则正文。 */
  function renderExperiment(scope, decision, context, held, win) {
    if (held && typeof held === 'object') { held.validUntil = ''; held.experimentParts = null; held.injectedIds = []; }
    if (!experimentStillCurrent(scope, held)) return '';
    if (!decision || decision.kind === 'none') return '';
    if (decision.kind === 'conflict') {
      return chargeExperiment(win, '这些实验规则互相冲突，先按用户这次说的做，别叠加对立的规则。');
    }
    if (decision.kind === 'index' || decision.kind === 'clarify') {
      const names = relevantRanges(Array.isArray(decision.ranges) ? decision.ranges.filter(Boolean) : [], held && held.query).slice(0, 3);
      /** 没有适用栏目就什么也不注入：不拿无关范围冒充当前任务，也不催用户选栏目。 */
      if (!names.length) return '';
      const tail = held && held.contextId ? `\ncontextId=${held.contextId}` : '';
      return chargeExperiment(win, `${EXPERIMENT_INDEX_HEADER}\n${names.map((name) => `- ${name}`).join('\n')}${tail}`);
    }
    let index;
    try { index = loadIndex(scope); } catch { return ''; }
    const matched = [];
    const unknown = [];
    const byTopic = new Map();
    let conflict = false;
    const now = Date.now();
    const query = held && held.query ? String(held.query) : '';
    const runtime = { projectId: scope.key, experimental: true, context: context || {}, task: (held && held.task) || {} };
    for (const record of index.entries) {
      if (record.origin !== 'project_evolution') continue;
      if (record.ownerProjectId && record.ownerProjectId !== scope.key) continue;
      const score = query ? view.matchScore(record, query).score : 0;
      /** 生命周期、归属、学习状态、适用条件统一走 eligibility：被取代、过期、暂停都不该从实验通道溜进来。 */
      const usable = view.eligibility(record, runtime, 'auto', now);
      if (!usable.ok) {
        if (usable.status === 'needs_context' && usable.reason !== 'condition_mismatch'
          && score >= view.MATCH_FLOOR) unknown.push(record);
        continue;
      }
      /**
       * 只有任务范围条件（栏目/阶段/任务类型）才算相关度：环境条件（系统/机器/路径）人人都过，
       * 拿它当绑定条件会让一条宽泛规则出现在每个请求里。其余规则照旧过词面门。
       */
      const conditions = Array.isArray(record.conditions) ? record.conditions.filter((row) => row && row.key) : [];
      const bound = conditions.some((row) => view.TASK_CONDITION_KEYS.includes(row.key) && !view.isBroadCondition(row));
      if (!bound && score < view.MATCH_FLOOR) continue;
      const topic = record.topicKey || record.id;
      if (byTopic.has(topic) && byTopic.get(topic).body !== record.body) conflict = true;
      byTopic.set(topic, record);
      matched.push({ record, score: bound ? Math.max(score, view.MATCH_FLOOR) : score });
    }
    if (conflict) {
      return chargeExperiment(win, '这些实验规则互相冲突，先按用户这次说的做，别叠加对立的规则。');
    }
    const parts = { header: EXPERIMENT_RULES_HEADER, items: [], tail: held && held.contextId ? `\ncontextId=${held.contextId}` : '' };
    /** 与普通记忆共用 3 张卡片 / 1200 字节：普通卡片先占掉的位子和字节，实验规则不能再拿。 */
    const auto = win && win.autoBudget ? win.autoBudget : null;
    const cardCap = auto
      ? Math.max(0, view.CARD.max - (auto.normalCards || 0) - (auto.experimentCards || 0))
      : view.CARD.max;
    /** 档位预算包含实验段：低档 400 B 的回合不能靠实验规则再多吃掉中档的额度。 */
    const planCap = win && Number.isInteger(win.recallPlanBytes)
      ? Math.min(view.CARD.bytes, win.recallPlanBytes) : view.CARD.bytes;
    const autoCap = auto
      ? Math.max(0, planCap - Buffer.byteLength(auto.normalText || '') - 2)
      : Math.min(EXPERIMENT_BYTES, planCap);
    const relevant = matched
      .slice()
      .sort((a, b) => b.score - a.score)
      .map((row) => row.record);
    /** 候选行先排好，预算交给跟卡片、画像共用的那套选件：装不下就少放一条，不改写任何一行。 */
    const candidates = [];
    for (const record of relevant.slice(0, 12)) {
      const body = String(record.body || '');
      const short = body && body.length <= EXPERIMENT_SHORT_CHARS && body.split('\n').length <= 4;
      const conditions = conditionLabel(record.conditions);
      const checkpoint = record.learning && Array.isArray(record.learning.checkpoints) ? record.learning.checkpoints[0] : null;
      const check = checkpoint && checkpoint.text
        ? `；核对：${String(checkpoint.text).slice(0, 40)}`
        : '';
      const line = short
        ? `- 「${record.title}」${conditions ? `（${conditions}）` : ''}：${body}${check}`
        : `- 「${record.title}」（用途：${record.summary || record.title}；要用时 memory_read 带标题取正文）`;
      const trialLearning = record.learning && typeof record.learning === 'object' ? record.learning : {};
      const trialUntil = trialLearning.state === 'trial' && Number.isFinite(Date.parse(String(trialLearning.trialUntil || '')))
        ? String(trialLearning.trialUntil) : '';
      candidates.push({ id: record.id, line, validUntil: trialUntil });
    }
    const headerBytes = Buffer.byteLength(EXPERIMENT_RULES_HEADER) + 1;
    const bundle = view.selectContextBundle(candidates, {
      maxItems: cardCap,
      maxBytes: Math.max(0, autoCap - headerBytes),
      allowEmpty: true,
      sizeOf: (item) => Buffer.byteLength(`\n${item.line}`),
    });
    for (const item of bundle.items) parts.items.push({ id: item.id, line: item.line, validUntil: item.validUntil });
    if (held) held.injectedIds = parts.items.map((item) => item.id);
    if (!parts.items.length && unknown.length) {
      /** 条件没确认的条目只报数量，绝不在模型侧暴露标题。 */
      return chargeExperiment(win, '有些实验规则的适用条件还没确认，先按用户这次说的做，别把它们当本轮依据。');
    }
    if (!parts.items.length) return '';
    /** 先按最终整段文本过预算，再登记可发布内容；没通过就一条都不留。 */
    const admitted = chargeExperiment(win, experimentTextFrom(parts), parts.items.length);
    if (!admitted) {
      if (held) { held.experimentParts = null; held.injectedIds = []; held.validUntil = ''; }
      return '';
    }
    if (held) held.experimentParts = parts;
    /** 兼容旧读取点：整体最早到期只取本轮真正注入的条目，不再被无关试验拖下水。 */
    if (held) {
      const deadlines = parts.items.map((item) => Date.parse(String(item.validUntil))).filter(Number.isFinite);
      if (deadlines.length) held.validUntil = new Date(Math.min(...deadlines)).toISOString();
    }
    return admitted;
  }

  /**
   * 一次真人请求只路由一次：不管自进化开没开，都先建独立的任务上下文。
   * 普通记忆按这个上下文判适用；实验规则只是在这个上下文上再加一层可用性。
   */
  function runtimeFor(scope, { sessionId, query, batchKey, messageIds, autoRoute = true }) {
    if (!batchKey) return null;
    let status = null;
    try { status = evolutionStatus(scope); } catch { status = null; }
    const enabled = Boolean(status && status.enabled === true && status.compatible !== false && scope.confirmed === true);
    /** 任务上下文独立于自进化：项目状态读不出来也要按当前任务判普通记忆，不能整段取消召回。 */
    let tasks = null;
    try { tasks = taskState(scope); } catch { tasks = null; }
    tasks = tasks && typeof tasks === 'object' ? tasks : {};
    const ranges = rangesOf(scope);
    /**
     * 工具模式不自动路由：上下文照样要有，但不能因为一句点名就改任务状态；
     * 真正的绑定留给 memory_search bindForRequest，绑定后状态是 proposed。
     */
    const routed = autoRoute
      ? anchor.routeTask(tasks, {
        projectId: scope.key,
        sessionId,
        batchKey,
        messageIds,
        query,
        registeredSeries: ranges.series,
        defaults: tasks.defaults,
        now: Date.now(),
      })
      : (() => {
        const sessionAnchor = tasks.sessions && tasks.sessions[sessionId] ? tasks.sessions[sessionId] : null;
        const episode = sessionAnchor && sessionAnchor.episodeId && tasks.episodes
          ? tasks.episodes[sessionAnchor.episodeId] || null
          : null;
        return { tasks, anchor: sessionAnchor, episode, changed: false, decision: { kind: 'none', reason: 'tool_only' } };
      })();
    if (routed.changed) {
      /** 落盘失败也不能取消本轮任务判断：进程内上下文仍然有效，只是不留任务历史。 */
      saveTaskState(scope, routed.tasks, { operationId: `task_${batchKey}` });
    }
    const context = view.trustedContext(scope, anchor.contextOfAnchor(routed.anchor, {}));
    const thanks = anchor.isThanks(query);
    const decision = anchor.decideRead({
      mode: recallMode(),
      enabled,
      identityConfirmed: scope.confirmed === true,
      anchor: routed.anchor,
      ranges: [...ranges.taskKinds, ...ranges.series],
      thanks,
      boundForRequest: false,
    });
    const contextId = anchor.contextIdFor(scope.key, batchKey, crypto.randomUUID().slice(0, 8));
    const episode = routed.episode
      || (routed.anchor && routed.tasks && routed.tasks.episodes ? routed.tasks.episodes[routed.anchor.episodeId] : null);
    let epoch = '';
    try { epoch = String(status && status.epoch ? status.epoch : ''); } catch { epoch = ''; }
    const anchorTask = routed.anchor || {};
    /** 与自进化开关无关的请求上下文：普通记忆也靠它判断项目、任务与代号。 */
    const requestContext = anchor.buildRuntimeContext({
      projectId: scope.key,
      sessionId,
      batchKey,
      messageIds,
      controlEpoch: epoch,
      query,
      anchor: anchorTask,
      episode,
    });
    const task = {
      ...requestContext.task,
      kind: anchorTask.taskKind || requestContext.task.kind || context.taskKind || '',
      seriesId: anchorTask.seriesId || requestContext.task.seriesId || context.seriesId || '',
      artifactKey: requestContext.task.artifactKey || context.artifactKey || '',
      phase: requestContext.task.phase || context.phase || '',
    };
    const held = {
      contextId, requestId: requestContext.requestId, controlEpoch: epoch,
      projectKey: scope.key, sessionId, batchKey, messageIds, query,
      context, task, anchor: routed.anchor, ranges, decision, epoch,
      experimental: enabled,
      episodeId: (episode && episode.episodeId) || (routed.anchor && routed.anchor.episodeId) || '',
      episodeUpdatedAt: episode ? episode.updatedAt : '', injectedIds: [],
      at: Date.now(),
    };
    return { held, decision, ranges, enabled, status };
  }

  /** 实验正文只在自进化开着时登记；普通记忆共享同一个任务上下文。 */
  function experimentFor(scope, runtime, win) {
    if (!runtime || !runtime.held) return null;
    const held = runtime.held;
    if (win) win.runtime = held;
    if (!runtime.enabled) return null;
    if (!experimentStillCurrent(scope, held)) return { text: '', held, decision: held.decision };
    if (win) {
      win.experiment = held;
      win.contexts.set(held.contextId, held);
    }
    return { text: renderExperiment(scope, held.decision, held.context, held, win), decision: held.decision, held };
  }

  function resolveRequestContext(execution, optionalContextId) {
    const scope = scopeOf(cwdOf(execution));
    const win = windowOf(execution && execution.agent);
    const contextId = typeof optionalContextId === 'string' ? optionalContextId.trim() : '';
    if (!contextId) {
      /** 没有显式上下文时，用本请求已经路由出来的任务；这层不依赖自进化开关。 */
      const live = win && win.runtime ? win.runtime : null;
      const runtime = live
        || (win && win.sessionId ? lastRuntime.get(`${scope.key}\u0000${win.sessionId}`) : null);
      const sameRequest = runtime
        && runtime.projectKey === scope.key
        && (!runtime.sessionId || runtime.sessionId === String(win.sessionId || ''))
        && (runtime === live ? runtime.batchKey === anchor.requestBatchKey(win.messageIds || []) : true);
      if (sameRequest) {
        /** 普通记忆可以直接用本请求上下文；实验正文仍要求显式 contextId，不能顺手放行。 */
        return { ok: true, scope, win, context: runtime.context, held: runtime, experimental: false };
      }
      return { ok: true, scope, win, context: view.trustedContext(scope, {}), experimental: false };
    }
    /** 先认项目再找本地记录：别的项目的上下文要明确拒绝，不能只报过期。 */
    if (anchor.projectTagOf(contextId) !== anchor.projectTag(scope.key)) {
      return { ok: false, status: 'needs_context', reason: '这个上下文属于另一个项目' };
    }
    if (!win) return { ok: false, status: 'needs_context', reason: '这个请求的上下文已经过期，先重新问一次当前任务' };
    const held = win.contexts.get(contextId);
    if (!held) return { ok: false, status: 'needs_context', reason: '这个上下文已经过期，先重新问一次当前任务' };
    /** 凭据只在当轮、当次开关代次内有效：换轮、关闭、重开或过期都不再放行旧正文。 */
    const expired = (reason) => {
      win.contexts.delete(contextId);
      if (win.experiment && win.experiment.contextId === contextId) win.experiment = null;
      return { ok: false, status: 'needs_context', reason };
    };
    if (held.projectKey !== scope.key) return expired('这个上下文属于另一个项目');
    if (held.sessionId && held.sessionId !== String(win.sessionId || '')) return expired('这个上下文已经过期，先重新问一次当前任务');
    if (!held.batchKey || held.batchKey !== anchor.requestBatchKey(win.messageIds || [])) {
      return expired('这个上下文已经过期，先重新问一次当前任务');
    }
    let evolution;
    try { evolution = evolutionStatus(scope); } catch { return expired('当前项目状态读不出来，先重新问一次当前任务'); }
    if (!evolution || evolution.enabled !== true || evolution.compatible === false) {
      return expired('项目自进化已经关闭，先重新问一次当前任务');
    }
    if (held.epoch && evolution.epoch !== held.epoch) {
      return expired('项目自进化重新开过，先重新问一次当前任务');
    }
    return { ok: true, scope, win, context: held.context, experimental: true, held, contextId };
  }

  /** 工具模式没有自动索引时，按本轮真人消息现开一个请求上下文，只按问题与记忆范围的字面关系判断。 */
  function toolContextFor(execution) {
    const win = windowOf(execution && execution.agent);
    if (!win || !win.sessionId || !Array.isArray(win.messageIds) || win.messageIds.length === 0) return '';
    const scope = scopeOf(cwdOf(execution));
    if (scope.confirmed !== true) return '';
    let status;
    try { status = evolutionStatus(scope); } catch { return ''; }
    if (!status || status.enabled !== true || status.compatible === false) return '';
    const batchKey = anchor.requestBatchKey(win.messageIds);
    const held = win.experiment && win.experiment.batchKey === batchKey && win.experiment.epoch === status.epoch
      ? win.experiment
      : null;
    if (held) return held.contextId;
    const contextId = anchor.contextIdFor(scope.key, batchKey, crypto.randomUUID().slice(0, 8));
    const created = {
      contextId, projectKey: scope.key, sessionId: win.sessionId, batchKey,
      messageIds: win.messageIds.slice(), query: trustedQueryOf(win), context: view.trustedContext(scope, {}),
      anchor: null, ranges: rangesOf(scope), decision: { kind: 'none' }, epoch: status.epoch, at: Date.now(),
    };
    win.experiment = created;
    win.contexts.set(contextId, created);
    return contextId;
  }

  /** 本轮真人消息是唯一可信的任务依据；模型自己写的 query 只用于检索词，不能拿来建绑定。 */
  function trustedQueryOf(win) {
    return win && typeof win.query === 'string' ? win.query : '';
  }

  /** 前台绑定只升到 proposed：真正执行链还没发生，不冒充 active。 */
  function bindSelection(execution, resolved) {
    const held = resolved.held;
    if (!held || typeof held !== 'object') return { ok: false, status: 'needs_context', reason: '本轮还没有可核对的用户消息，先重新问一次当前任务' };
    const query = held.query || trustedQueryOf(resolved.win);
    if (!query) return { ok: false, status: 'needs_context', reason: '本轮还没有可核对的用户消息，先重新问一次当前任务' };
    const ranges = held.ranges || { series: [], taskKinds: [] };
    /** 自动路由已经选了范围就沿用同一个结果，工具绑定不重新猜一遍，避免两处给出不同任务。 */
    const routedAnchor = held.anchor && typeof held.anchor === 'object' ? held.anchor : null;
    const hits = [];
    if (routedAnchor && routedAnchor.seriesId) hits.push({ seriesId: routedAnchor.seriesId });
    else if (routedAnchor && routedAnchor.taskKind) hits.push({ taskKind: routedAnchor.taskKind });
    else {
      for (const value of ranges.series || []) if (anchor.seriesChosenBy(query, value)) hits.push({ seriesId: value });
      for (const value of ranges.taskKinds || []) if (anchor.seriesChosenBy(query, value)) hits.push({ taskKind: value });
    }
    if (hits.length !== 1) {
      const names = [...(ranges.series || []), ...(ranges.taskKinds || [])].slice(0, 3);
      return { ok: false, status: 'needs_context', reason: names.length ? '本轮没有匹配的记忆范围，按当前任务继续' : '本轮没有适用的记忆范围，按当前任务继续' };
    }
    let tasks;
    try { tasks = taskState(resolved.scope); } catch { return { ok: false, status: 'needs_context', reason: '任务状态还没读出来' }; }
    const applied = anchor.applySelection(tasks, {
      sessionId: held.sessionId,
      selection: hits[0],
      batchKey: held.batchKey,
      messageIds: held.messageIds,
      now: Date.now(),
    });
    const saved = saveTaskState(resolved.scope, applied.tasks, { operationId: `bind_${held.batchKey}` });
    if (!saved.ok) return { ok: false, status: 'needs_context', reason: saved.reason || '任务选择没有保存' };
    held.anchor = applied.anchor;
    held.context = view.trustedContext(resolved.scope, anchor.contextOfAnchor(applied.anchor, {}));
    held.decision = { kind: 'rules', reason: 'bound' };
    resolved.context = held.context;
    const text = renderExperiment(resolved.scope, held.decision, held.context, held, resolved.win);
    const preparedState = prepared.get(execution && execution.agent);
    if (preparedState) {
      preparedState.experimentText = text;
      preparedState.experimentParts = held.experimentParts || null;
      preparedState.validUntil = held.validUntil || '';
    }
    return { ok: true };
  }

  /** provider 只读内存快照：不查盘、不搜索、不写 hits、不动 lastUsed。 */
  function recallText(holder) {
    try {
      const agent = holder?.agent ?? getService('agents')?.currentInitiator?.();
      if (!agent) return '';
      const state = prepared.get(agent);

      const signal = holder?.signal;
      if (signal?.aborted) return '';
      if (state.signal && signal && state.signal !== signal) return '';
      const sessionId = agent?.session?.id;
      if (state.sessionId !== (typeof sessionId === 'string' ? sessionId : '')) return '';
      /** 开关/自进化换代后，关掉前准备好的正文一律不再输出。 */
      const scope = scopeOf(cwdOf({ agent }));
      if (!memoryEnabled(scope)) return '';
      const epoch = controlStatus(scope).epoch || '';

      /** 自进化关掉或换过代：关掉前的实验正文不再输出，重开也不复活。 */
      let evolutionText = state.experimentParts ? experimentTextFrom(state.experimentParts) : state.experimentText;
      if (evolutionText) {
        let evolution;
        try { evolution = evolutionStatus(scope); } catch { evolution = null; }
        if (!evolution || evolution.enabled !== true || evolution.compatible === false
          || (state.evolutionEpoch && String(evolution.epoch || '') !== state.evolutionEpoch)) evolutionText = '';
      }
      /** 没有逐条快照时才退回整段到期判断；有快照就只撤到期的那一条。 */
      if (evolutionText && !state.experimentParts && state.validUntil && Date.now() > Date.parse(String(state.validUntil))) evolutionText = '';
      /** 普通卡片也在输出前逐条复核到期：投影到真正发给模型之间可能已经过了 validUntil。 */
      let normalText = state.text;
      if (Array.isArray(state.lines)) {
        const now = Date.now();
        const live = state.lines.filter((row) => !row.validUntil || now <= Date.parse(String(row.validUntil)));
        normalText = live.length ? `${RECALL_HEADER}\n${live.map((row) => row.line).join('\n')}` : '';
        /** 真正交付的卡片才记使用；记账推迟到回合收尾，provider 不碰写锁。 */
        if (live.length && state.scope) {
          if (!(state.deliveredIds instanceof Set)) state.deliveredIds = new Set();
          for (const row of live) if (row.id) state.deliveredIds.add(row.id);
        }
        /** 投影时还在、发出时已过期：回执跟着真实输出改，别在面板上说「提醒了 2 条」而正文是空的。 */
        if (state.scope && live.length !== state.cards.length) {
          noteRecall(state.scope, state.sessionId, {
            reason: live.length ? 'hit' : 'expired',
            matched: state.matched || state.cards.length,
            cards: live.length,
            chars: live.length ? view.bytesOf(normalText) : 0,
          });
        }
      }
      return [evolutionText, normalText].filter(Boolean).join('\n\n');
    } catch {
      return '';
    }
  }

  /** 交付形式明确的回合（JSON、翻译、模板）不投影表达偏好：格式优先于风格。 */
  const outputModeOf = (said) => {
    const text = String(said || '');
    if (/(?:只|仅|必须)?\s*(?:输出|返回|给我)\s*(?:一段|一个|纯)?\s*(?:JSON|json)/u.test(text)
      || /(?:JSON|json)\s*(?:格式|only)/u.test(text)) return 'strict_json';
    if (/(?:翻译成|译成|翻成|translate to)/iu.test(text)) return 'verbatim_translation';
    if (/(?:按|用).{0,6}(?:模板|格式)\s*(?:输出|写|回)/u.test(text)) return 'fixed_template';
    return 'chat';
  };
  /** 本轮原话里的硬要求要压过已形成的偏好；只在本轮，不写回画像。 */
  const explicitRequirementOf = (said) => {
    const text = String(said || '');
    const marked = EXPLICIT_MARKERS.some((marker) => text.includes(marker));
    return marked ? text.slice(0, 200) : '';
  };

  /**
   * 「记住我」投影：只在本轮交付形式确实相关时放一两句表达偏好。
   * 与召回完全分开：它不取记忆正文、不碰项目层，也不改任何技术结论。
   * 关闭开关或项目记忆关闭时一律不输出。
   */
  function personaText(holder) {
    try {
      const agent = holder?.agent ?? getService('agents')?.currentInitiator?.();
      if (!agent) return '';
      if (holder?.signal?.aborted) return '';
      const scope = scopeOf(cwdOf({ agent }));
      if (!memoryEnabled(scope)) return '';
      const read = personaStore.readPersona();
      if (read.corrupt || !read.persona || read.persona.control.enabled !== true) return '';
      /** 本轮用户原话是最高优先级；没有本轮请求就不投影，避免拿上一轮的偏好套这次。 */
      const said = authorizedSaidOf(agent);
      if (!said) return '';
      const formed = {};
      const preferences = read.persona.preferences || {};
      for (const dimension of persona.DIMENSION_NAMES) {
        const row = preferences[dimension];
        if (row && row.state === 'formed' && row.value) formed[dimension] = row;
      }
      if (!Object.keys(formed).length) return '';
      /** 自动出口同样受召回模式约束（项目自己的选择优先）：只走工具或全关时画像不冒出来。 */
      if (modeFor(scope) !== 'adaptive') return '';
      const picked = persona.selectPreferenceProjection({
        currentRequest: said.slice(0, 400),
        outputMode: outputModeOf(said),
        explicitRequirements: explicitRequirementOf(said),
        formed,
      });
      /** 和召回共用同一份 1200 字节：卡片先按召回顺序装，剩下的额度够才投影画像，装不下整段不出现。 */
      return picked && picked.block ? chargePersona(windowOf(agent), picked.block) : '';
    } catch {
      return '';
    }
  }


  ctx.effect(() => tools.register({
    name: 'memory_save',
    description: `保存跨会话有用的记忆。只在会改变以后判断时存；说「记住」或已是长期规则就直接调用。先搜，能更新就不新建。needsResolution 自己裁决：补充就 resolution="merge"（mergeInto 指定并进哪条），另一条就 resolution="distinct" 换标题另存，重复就 resolution="discard" 不存。按标题更新时未给字段保留，正文整段替换。同层同名只有一条：两个标题同时存在时再另存，不靠同名加前置条件分开。${NOTES}`,
    parameters: SAVE_PARAMS,
    output: {
      presentationMeta: (_args, value) => ({
        kind: 'memory-save',
        title: value.title || '',
        scope: value.scope || '',
        revision: value.revision || 0,
        changed: value.changed === true,
        recordKind: typeof value.kind === 'string' && value.kind ? value.kind : '',
        mode: value.error ? 'failed'
          : value.discarded ? 'discarded'
            : value.needsScope ? 'needs_scope'
          : value.existingTitle ? 'duplicate'
            : value.needsResolution ? 'needs_resolution'
              : value.changed === false ? 'unchanged' : value.merged ? 'updated' : 'created',
      }),
      schema: {
        type: 'object',
        properties: {
          title: { type: 'string' },
          summary: { type: 'string' },
          when: { type: 'string' },
          kind: { type: 'string' },
          summaryShortened: { type: 'boolean' },
          fullTextSaved: { type: 'boolean' },
          hints: { type: 'string' },
          stored: { type: 'boolean' },
          needsCompaction: { type: 'boolean' },
          maxBytes: { type: 'integer' },
          suggestedAction: { type: 'string' },
          revision: { type: 'integer' },
          merged: { type: 'boolean' },
          changed: { type: 'boolean' },
          scope: { type: 'string' },
          scopeName: { type: 'string' },
          needsResolution: { type: 'boolean' },
          discarded: { type: 'boolean' },
          needsScope: { type: 'boolean' },
          reason: { type: 'string' },
          existingTitle: { type: 'string' },
          existingScope: { type: 'string' },
          crossLayer: { type: 'boolean' },
          crossScope: { type: 'string', enum: ['global', 'project'] },
          sameTopic: { type: 'boolean' },
          similarTitles: { type: 'string' },
          similar: { type: 'string' },
          scopeNote: { type: 'string' },
          supersededTitle: { type: 'string' },
          archived: { type: 'string' },
          pendingConflicts: { type: 'integer' },
          error: { type: 'string' },
          offCopy: { type: 'string' },
        },
        required: ['title', 'summary', 'when', 'revision', 'merged', 'changed', 'scope', 'needsResolution', 'archived'],
        additionalProperties: false,
      },
      render: (_args, value) => [{
        type: 'text',
        text: value.error
          ? value.needsCompaction
            ? `memory · ${value.error}\n${value.suggestedAction || ''}`
            : `memory · ${value.error}`
          : value.discarded
          ? `memory · 没存：「${value.title}」和已有记忆重复，不另存`
          : value.needsScope
          ? value.reason === 'memory_disabled'
            ? `memory · ${value.offCopy || '本项目记忆已关闭，先在面板打开'}`
            : value.reason === 'unconfirmed_project'
            ? `memory · 当前目录还不能确认属于哪个项目：「${value.title}」\n先确认项目根目录，或显式 scope="global"`
            : `memory · 归属还没定：「${value.title}」\n补 memoryClass（personal_preference / project_fact / environment_fact / portable_procedure）或显式 scope；设备事实还要给设备条件`
          : value.existingTitle
            ? `memory · 已有相同记忆：「${value.title}」（${value.existingScope}）\n要改成另一条，加 resolution="distinct"`
            : value.needsResolution
          ? `memory · 需要确认：「${value.title}」与已有条目相近${value.crossLayer ? '（在另一层）' : ''}${value.sameTopic ? '（同一主题槽位）' : ''}\n${value.similar}\n要更新它：用同一个标题${value.crossScope === 'global' ? '、并带 scope="global"' : ''}再存一次；确实是另一条，加 resolution="distinct"`
          : value.changed === false
            ? `memory · unchanged ${withTag(value, `"${value.title}"`)}`
            : `memory · ${value.merged ? 'merged' : 'saved'} ${withTag(value, `"${value.title}"`)}${value.when ? `（${value.when}）` : ''}${value.similar ? ` · 相近：${value.similar}` : ''}${value.archived ? ` · 已归档「${value.archived}」腾位` : ''}${value.fullTextSaved ? ' · 完整原句已另存' : ''}${value.supersededTitle ? ` · 已取代「${value.supersededTitle}」` : ''}${value.scopeNote ? ` · ${value.scopeNote}` : ''}${value.hints ? ` · 提示：${value.hints}` : ''}${value.mergedTitles ? ` · 已收并同名「${[].concat(value.mergedTitles).join('、')}」` : ''}`,
      }],
    },
    execute: async (args, execution) => {
      const projectScope = scopeOf(cwdOf(execution));
      const projectScopeName = projectNameOf(projectScope);
      if (!memoryEnabled(projectScope)) {
        return {
          title: String(args.title || ''), summary: '', when: '', revision: 0,
          merged: false, changed: false, scope: '', needsScope: true, reason: 'memory_disabled',
          needsResolution: false, similarTitles: '', similar: '', archived: '', offCopy: memoryOffCopy(projectScope),
        };
      }
      const supersedes = String(args.supersedes || '').trim();
      const supersedesId = supersedes && !/^mem_[a-z0-9]+$/.test(supersedes)
        ? (() => { try { return refIdOf(projectScope, { title: supersedes }, '记忆'); } catch { return ''; } })()
        : supersedes;
      /**
       * 模型写进参数里的 scope 只是提案：只有本轮真人原话明确说「所有项目/全局」，
       * 或面板直接确认过，才允许落到全局层。工具写入的正文由模型写，不能冒充用户原话。
       */
      const preparedState = prepared.get(execution && execution.agent);
      /** 先看本轮原话，再退到召回快照：快照会被清掉，授权不能因此消失。 */
      const humanSaid = authorizedSaidOf(execution && execution.agent)
        || String(preparedState && preparedState.saidOnly || '');
      const humanGlobal = humanAskedGlobal(humanSaid);
      const draft = {
        ...args,
        writeMode: args.mode || 'patch',
        origin: 'model_drafted',
        scopeConfirmed: humanGlobal,
        requestedScope: args.scope,
      };
      if (args.clearSelection) draft.selection = null;
      if (typeof args.topicKey === 'string' && args.topicKey.trim() === '') draft.topicKey = null;
      delete draft.clearSelection;
      if (humanGlobal) draft.scope = 'global'; else delete draft.scope;
      if (supersedes) { if (supersedesId) draft.supersedes = supersedesId; else delete draft.supersedes; }
      /** 更新句柄也用标题：id 只是底层实现，模型抄标题就行。 */
      const updateTitle = String(args.updateTitle || '').trim();
      if (updateTitle) {
        const candidates = titleCandidates(projectScope, updateTitle);
        const ambiguous = candidates.find((row) => row.ambiguous);
        /** 同层同名是允许的（不同前置条件各一条），但不能替用户挑第一条改。 */
        if (ambiguous) return saveFailure(ambiguousTitleError(updateTitle, ambiguous.hits, '记忆'), args);
        if (!args.scope && candidates.length > 1) {
          return saveFailure(`「${updateTitle}」在项目层和全局层各有一条：改全局加 scope="global"，改项目加 scope="project"`, args);
        }
        const layer = args.scope === 'global' ? 'global' : args.scope === 'project' ? 'project' : '';
        const picked = layer ? candidates.find((row) => row.scope === layer) : candidates[0];
        if (!picked) {
          const near = nearTitleHints(runtimeLayers(projectScope), updateTitle);
          if (near.length) {
            return saveFailure(`没有「${updateTitle}」这条记忆。相近的里有：${near.map((item) => `「${item}」`).join('、')}；要新增就不用 updateTitle`, args);
          }
          return saveFailure(`没有「${updateTitle}」这条记忆；要新增就不用 updateTitle`, args);
        }
        draft.id = picked.id;
      }
      /** 关联目标同样按标题解析成内部 id 再落盘。 */
      if (Array.isArray(args.links) && args.links.length) {
        const resolved = [];
        for (const link of args.links) {
          const title = typeof link?.title === 'string' ? link.title.trim() : '';
          if (!title) return saveFailure('关联要写成 {type, title}：给被关联那条记忆的标题', args);
          let targetId = '';
          try { targetId = refIdOf(projectScope, { title }, '记忆'); } catch (error) {
            return saveFailure(String(error && error.message ? error.message : `没有「${title}」这条记忆`), args);
          }
          resolved.push({ type: link.type || 'related', id: targetId });
        }
        draft.links = resolved;
      }
      let saved;
      try {
        saved = saveEntry(projectScope, draft);
      } catch (error) {
        const message = String(error && error.message || '');
        /** 超单条上限不是「写坏了」：按长度失败给出可执行的拆法，别的错误照旧抛。 */
        if (/超过单条 \d+ 字节/.test(message)) return compactionFailure(message, args, projectScope);
        throw error;
      }
      if (saved.needsScope) {
        return {
          title: saved.draft?.title || '',
          summary: saved.draft?.summary || '',
          when: saved.draft?.when || '',
          revision: 0,
          merged: false,
          changed: false,
          scope: '',
          needsScope: true,
          reason: saved.reasonCode,
          needsResolution: false,
          similarTitles: '',
          similar: '',
          archived: '',
        };
      }
      if (saved.discarded) {
        return {
          title: saved.draft?.title || '', summary: '', when: '', revision: 0,
          merged: false, changed: false, scope: saved.chosenScope || '', discarded: true,
          needsScope: false, needsResolution: false, similarTitles: '', similar: '', archived: '',
        };
      }
      if (saved.existing) {
        return {
          title: saved.existing.title || saved.draft?.title || '',
          summary: '',
          when: '',
          revision: saved.existing.revision,
          merged: false,
          changed: false,
          scope: saved.existing.scope,
          scopeName: saved.existing.scope === 'global' ? '' : projectScopeName,
          needsScope: false,
          existingTitle: saved.existing.title || saved.draft?.title || '',
          existingScope: saved.existing.scope,
          needsResolution: false,
          similarTitles: '',
          similar: '',
          archived: '',
        };
      }
      const scope = saved.chosenScope === 'global' || (args.scope === 'global' && !saved.chosenScope) ? globalScope() : projectScope;
      /** 显式要了全局却被硬冲突挡回项目层时说清原因：否则模型只能看到 scope=project，无从纠。 */
      const scopeNote = (() => {
        if (args.scope !== 'global' || scope.key === 'global') return '';
        if (saved.reasonCode === 'machine_bound_scope' || saved.reasonCode === 'machine_bound_procedure') return '按本机痕迹留在项目层：正文或依据里写了本机路径/端口，改成别的项目仍成立的通用规则再存全局；只在本机适用的流程可补 machine 条件后存全局';
        if (saved.reasonCode === 'model_global_project_fact' || saved.reasonCode === 'class_project_fact') return '按项目事实留在项目层：换成别的项目就不成立；确实是通用流程就改 memoryClass';
        if (saved.reasonCode === 'model_class_project' || saved.reasonCode === 'unclassified_project') return '按当前项目保存：模型归类只是提案，要存全局得由用户明确说「所有项目都这样」';
        return '';
      })();
      if (saved.needsResolution) {
        return {
          title: saved.draft.title,
          summary: saved.draft.summary,
          when: saved.draft.when,
          revision: 0,
          merged: false,
          changed: false,
          scope: saved.chosenScope || (scope.key === 'global' ? 'global' : 'project'),
          needsScope: false,
          needsResolution: true,
          crossLayer: Boolean(saved.crossLayer),
          crossScope: saved.crossScope === 'global' ? 'global' : 'project',
          sameTopic: Boolean(saved.sameTopic),
          similarTitles: saved.similarList.map((item) => item.title).join('、'),
          similar: saved.similarList.map((item) => describeCandidate(item, { sameTopic: saved.sameTopic })).join('；'),
          archived: '',
          ...(scopeNote ? { scopeNote } : {}),
          pendingConflicts: Number(saved.pendingConflicts) || 0,
        };
      }
      recordCitations(scope, sessionIdOf(execution), [saved.record]);
      return {
        title: saved.record.title,
        summary: saved.record.summary,
        when: saved.record.when || '',
        kind: saved.record.kind || 'note',
        summaryShortened: Boolean(saved.draft?.summaryShortened),
        fullTextSaved: Boolean(saved.draft?.fullTextSaved ?? saved.draft?.fullTextInBody),
        revision: saved.record.revision || 1,
        merged: saved.merged,
        changed: !saved.noop,
        scope: scope.key === 'global' ? 'global' : 'project',
        scopeName: scope.key === 'global' ? '' : projectScopeName,
        needsScope: false,
        needsResolution: false,
        similarTitles: saved.similarList.map((item) => item.title).join('、'),
        ...(scopeNote ? { scopeNote } : {}),
        supersededTitle: supersedes && supersedesId ? supersedes : '',
        archived: (saved.archived || []).map((item) => item.title).join('、'),
        pendingConflicts: Number(saved.pendingConflicts) || 0,
        ...(saved.similar ? { similar: `「${saved.similar.title}」` } : {}),
        ...(() => {
          const hints = qualityHintsOf(saved.record || draft);
          /** 撞标题时已经并进已有那条：明确说出来，避免模型以为又新加了一条。 */
          if (saved.autoMerged) hints.unshift('正文和已有的一条几乎相同，已并进那条（旧正文留在版本里）');
          return hints.length ? { hints: hints.join('；') } : {};
        })(),
      };
    },
  }), 'lite-memory: memory_save');

  ctx.effect(() => tools.register({
    name: 'memory_suggest',
    description: `对用户没说、但跨会话有用的经验提出保存建议。出现「保留」按钮，用户点了才进正式记忆；不要用问句征询。一次对话最多一条，48 小时内每项目一条；相近条目记为「更新候选」。判据同 memory_save。`,
    parameters: SUGGEST_PARAMS,
    output: {
      presentationMeta: (_args, value) => ({ kind: 'memory-suggest', id: value.id || '', asked: value.asked }),
      schema: {
        type: 'object',
        properties: {
          asked: { type: 'boolean' },
          title: { type: 'string' },
          id: { type: 'string' },
          reason: { type: 'string' },
          targetTitle: { type: 'string' },
        },
        required: ['asked'],
        additionalProperties: false,
      },
      render: (_args, value) => [{
        type: 'text',
        text: value.asked
          ? `memory · suggested "${value.title}"${value.targetTitle ? ` · 确认后更新「${value.targetTitle}」` : ''}`
          : `memory · skipped${value.reason ? `\n${value.reason}` : ''}`,
      }],
    },
    execute: async (args, execution) => {
      const scope = scopeOf(cwdOf(execution));
      if (!memoryEnabled(scope)) return { asked: false, reason: '本项目记忆已关闭' };
      const gate = suggestionGate(scope, args);
      if (!gate.ok) return { asked: false, reason: gate.reason };
      const noted = noteSuggestion(scope, gate.target ? { ...args, targetId: gate.target.id } : args);
      return {
        asked: true,
        title: noted.title,
        id: noted.id,
        ...(noted.targetTitle ? { targetTitle: noted.targetTitle } : {}),
      };
    },
  }), 'lite-memory: memory_suggest');

  ctx.effect(() => tools.register({
    name: 'memory_search',
    description: `检索已有记忆；命中后 memory_read 带标题读正文。用户提到「记住了什么/上次/规范/约定/路径/凭据怎么取」，或眼前反复出现报错、弹窗、异常时先查这里。跨项目条目以 [global] 开头。要更新就按返回标题重存。默认只列当前有效的；查历史传 history。`,
    parameters: SEARCH_PARAMS,
    output: {
      presentationMeta: (_args, value) => ({
        kind: 'memory-search', count: value.count, status: value.status || 'ok', refs: value.refs || [],
        noTriggerReason: value.noTriggerReason || '',
      }),
      schema: {
        type: 'object',
        properties: {
          count: { type: 'integer' },
          chars: { type: 'integer' },
          text: { type: 'string' },
          status: { type: 'string', enum: ['ok', 'budget_exhausted', 'memory_disabled', 'needs_context'] },
          reasonCode: { type: 'string' },
          noTriggerReason: { type: 'string' },
          refs: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                title: { type: 'string' },
                scope: { type: 'string' },
                revision: { type: 'integer' },
                status: { type: 'string' },
                origin: { type: 'string' },
                kind: { type: 'string' },
                when: { type: 'string' },
                updated: { type: 'string' }, // ui-copy-ignore
              },
              required: ['title', 'scope', 'revision', 'status', 'origin', 'kind', 'when'],
              additionalProperties: false,
            },
          },
        },
        required: ['count', 'chars', 'text', 'refs'],
        additionalProperties: false,
      },
      render: (_args, value) => [{
        type: 'text',
        text: value.status === 'budget_exhausted'
          ? 'memory · 这条消息已停止检索，下一条消息再查'
          : value.status === 'memory_disabled'
            ? 'memory · 记忆检索已关闭'
            : value.status === 'needs_context'
              ? `memory · 先确认当前任务\n${value.text}`
              : value.count > 0
              ? `memory · 命中 ${value.count} 条 · 引用 ${value.chars} 字\n${value.text}`
              : 'memory · 没有命中',
      }],
    },
    execute: async (args, execution) => {
      if (!memoryEnabledFor(execution) || modeFor(scopeOf(cwdOf(execution))) === 'off') return { count: 0, chars: 0, text: '', status: 'memory_disabled', refs: [] };
      const agent = execution?.agent;
      const win = windowOf(agent);
      if (win && !affordableTool(win, 0)) return { count: 0, chars: 0, text: '', status: 'budget_exhausted', refs: [] };
      const wantsBind = args.bindForRequest === true;
      const contextId = wantsBind && !args.contextId ? toolContextFor(execution) : args.contextId;
      if (wantsBind && !contextId) {
        return { count: 0, chars: 0, text: '先带上当前任务的 contextId，再绑定这一期。', status: 'needs_context', refs: [] };
      }
      const resolved = resolveRequestContext(execution, contextId);
      if (!resolved.ok) return { count: 0, chars: 0, text: resolved.reason, status: resolved.status || 'needs_context', refs: [] };
      if (wantsBind) {
        const bound = bindSelection(execution, resolved);
        if (!bound.ok) return { count: 0, chars: 0, text: bound.reason, status: bound.status || 'needs_context', refs: [] };
      }
      const scope = resolved.scope;
      const context = resolved.context;
      const gateRuntime = resolved.held || win?.runtime
        || { projectId: scope.key, context, experimental: resolved.experimental === true };
      /** 检索只列当前任务真能用的条目；先取全量候选，过滤后再截断，避免不可用条目挤掉后面的命中。 */
      const limit = args.limit ?? 3;
      const rawHits = search(scope, args.query, 50, {
        context,
        history: args.history === true,
        allowExperimental: resolved.experimental === true,
        /** 「用过」要等真正给了模型看再记：检索到的前 50 条不是交付。 */
        markUsed: false,
      }).filter((item) => !item.ownerProjectId || item.ownerProjectId === scope.key)
        .filter((item) => item.archived || view.eligibility(item, gateRuntime, 'search').ok);
      const hits = rawHits.filter((item) => item.archived || item.status === 'ok').slice(0, limit);
      const withheld = rawHits.filter((item) => !item.archived && item.status !== 'ok');
      const scopeName = scope.key === 'global' ? '' : projectNameOf(scope);
      const shown = hits.map((item) => ({
        ...view.toModelView(item, 'search', { status: item.status || (item.archived ? 'archived' : 'ok') }),
        scopeName: item.scope === 'global' ? '' : scopeName,
      }));
      const valueOf = (kept) => {
        const rendered = renderIndex(shown.slice(0, kept));
        return { count: kept, chars: rendered.chars, text: rendered.text, status: 'ok', refs: refsOf(hits.slice(0, kept)) };
      };
      /** 有匹配但当前用不上：只说状态，不把标题、编号或旧规则递给模型，避免它被这些字面带偏。 */
      if (!hits.length && withheld.length) {
        const unresolved = withheld.some((item) => item.status === 'needs_context');
        const value = {
          count: 0,
          chars: 0,
          text: unresolved
            ? '有相关的项目记忆，但适用条件还没确认。先说明当前任务，或确认这条记忆的适用范围。'
            : '有相关的项目记忆，但当前任务明确不适用。',
          status: unresolved ? 'needs_context' : 'ok',
          reasonCode: unresolved ? 'applicability_unresolved' : 'not_applicable',
          noTriggerReason: unresolved ? '适用条件未确认' : '当前任务不适用',
          refs: [],
        };
        if (win) {
          const bytes = jsonBytes(value);
          if (!affordableTool(win, bytes)) return { ...value, status: 'budget_exhausted', text: '' };
          win.bytes += bytes;
          win.toolBytes += bytes;
          win.reads += 1;
        }
        return value;
      }
      /** 没命中是正常结果，不是额度问题；空响应同样记一次本请求开销。 */
      if (!hits.length) {
        const empty = { count: 0, chars: 0, text: '', status: 'ok', reasonCode: 'no_match', noTriggerReason: '没有匹配的记忆', refs: [] };
        if (win) {
          const bytes = jsonBytes(empty);
          if (!affordableTool(win, bytes)) return { ...empty, status: 'budget_exhausted' };
          win.bytes += bytes;
          win.toolBytes += bytes;
          win.reads += 1;
        }
        return empty;
      }
      if (win) {
        let kept = shown.length;
        while (kept > 0 && !affordableTool(win, jsonBytes(valueOf(kept)))) kept -= 1;
        if (kept === 0) return { count: 0, chars: 0, text: '', status: 'budget_exhausted', refs: [] };
        const value = valueOf(kept);
        win.bytes += jsonBytes(value);
        win.toolBytes += jsonBytes(value);
        win.reads += 1;
        recordCitations(scope, sessionIdOf(execution), hits.slice(0, kept));
        markUsed(scope, hits.slice(0, kept).map((item) => item.id));
        return value;
      }
      const value = valueOf(shown.length);
      recordCitations(scope, sessionIdOf(execution), hits);
      markUsed(scope, hits.map((item) => item.id));
      return value;
    },
  }), 'lite-memory: memory_search');

  ctx.effect(() => tools.register({
    name: 'memory_read',
    description: `读一条记忆的正文。搜索只有摘要，细节按标题读；缺条件加 taskPhase。一条消息读 ${view.REQUEST_LIMITS.bodies} 条 / ${view.REQUEST_LIMITS.reads} 次为限，下一条接着算。正文丢了报错，不返回空正文。`,
    parameters: READ_PARAMS,
    output: {
      schema: {
        type: 'object',
        properties: {
          title: { type: 'string' },
          when: { type: 'string' },
          revision: { type: 'integer' },
          scope: { type: 'string' },
          scopeName: { type: 'string' },
          origin: { type: 'string', enum: ['user_explicit', 'model_drafted', 'project_evolution'] },
          kind: { type: 'string' },
          status: { type: 'string', enum: ['ok', 'archived', 'needs_context', 'not_applicable', 'gone', 'budget_exhausted', 'memory_disabled'] },
          missing: { type: 'string' },
          body: { type: 'string' },
          links: { type: 'string' },
          repeat: { type: 'boolean' },
        },
        required: ['scope', 'status'],
        additionalProperties: false,
      },
      render: (_args, value) => [{
        type: 'text',
        text: value.status === 'budget_exhausted'
          ? `memory · 本条消息读正文到上限（${view.REQUEST_LIMITS.bodies} 条 / 共 ${view.REQUEST_LIMITS.reads} 次），下一条消息接着读；已读到的不会丢`
          : value.status === 'memory_disabled'
            ? 'memory · 记忆检索已关闭'
            : value.repeat
              ? 'memory · 本请求已读过这条记忆'
              : value.body
                ? `memory · ${withTag(value, `「${value.title}」`)}${value.when ? `（${value.when}）` : ''}${statusLabel(value.status)}\n${value.body}`
                : value.links !== undefined && value.status === 'ok'
                  ? `memory · 「${value.title}」的相关记忆\n${value.links || '(无)'}`
                  : value.status === 'needs_context'
                    ? `memory · 这条记忆的适用条件还没确认${value.missing ? `（缺 ${value.missing}）` : ''}；带 task 声明本轮任务再读，或先说明当前任务`
                    : value.status === 'not_applicable'
                      ? 'memory · 这条记忆不适用于当前任务'
                      : value.status === 'archived'
                        ? 'memory · 这条记忆已归档'
                        : value.status === 'gone'
                          ? 'memory · 这条记忆已不存在'
                          : 'memory · 当前不能读这条记忆',
      }],
      presentationMeta: (_args, value) => ({
        kind: 'memory-read',
        title: value.title || '',
        scope: value.scope || '',
        revision: value.revision || 0,
        origin: originOut(value.origin),
        recordKind: typeof value.kind === 'string' && value.kind ? value.kind : '',
        status: value.status || 'ok',
      }),
    },
    execute: async (args, execution) => {
      if (!memoryEnabledFor(execution) || modeFor(scopeOf(cwdOf(execution))) === 'off') return { scope: '', status: 'memory_disabled' };
      const resolved = resolveRequestContext(execution, args.contextId);
      if (!resolved.ok) return { scope: '', status: resolved.status || 'needs_context' };
      const scope = resolved.scope;
      const scopeName = scope.key === 'global' ? '' : projectNameOf(scope);
      /** 明确指定层时只在那一层解析标题，同名条目不会串到别的层。 */
      const readScope = args.scope === 'global' ? globalScope() : scope;
      const context = resolved.context;
      const allowExperimental = resolved.experimental === true;
      const agent = execution?.agent;
      const win = windowOf(agent);
      const gateBase = resolved.held || win?.runtime
        || { projectId: scope.key, context, experimental: resolved.experimental === true };
      /** task 只补本次读取的条件上下文：模型显式声明已确认的任务键，不写回任何记忆、不影响自动召回。 */
      const flatTask = ['kind', 'seriesId', 'phase', 'artifactKey']
        .reduce((acc, key) => (typeof args[`task${key[0].toUpperCase()}${key.slice(1)}`] === 'string'
          ? { ...acc, [key]: args[`task${key[0].toUpperCase()}${key.slice(1)}`] } : acc), {});
      const task = args.task && typeof args.task === 'object' ? args.task : (Object.keys(flatTask).length ? flatTask : null);
      const gateRuntime = task
        ? { ...gateBase, task: { ...(gateBase.task || {}), ...task } }
        : gateBase;
      const readContext = task ? view.contextWithTask(context, task) : context;
      if (args.view === 'links') {
        const refId = refIdOf(readScope, args, '记忆', { adoptNear: true });
        const source = locate(readScope, refId);
        const gateOk = !source || view.eligibility(source.record, gateRuntime, 'read').ok;
        if (!gateOk) {
          const gaps = view.conditionGaps(source.record, gateRuntime).join('、');
          return { scope: '', status: 'needs_context', missing: gaps, links: '' };
        }
        const found = readLinks(readScope, refId, { context: readContext, allowExperimental, runtime: gateRuntime, now: Date.now() });
        if (!found) throw new Error(`没有「${String(args.title || args.id || '').trim()}」这条记忆；标题可粘展示行或给 id`);
        if (found.status !== 'ok') {
          const withheld = { scope: '', status: found.status, links: '' };
          if (win) {
            const bytes = jsonBytes(withheld);
            if (!affordableTool(win, bytes)) return { scope: '', status: 'budget_exhausted' };
            win.bytes += bytes;
            win.toolBytes += bytes;
            win.reads += 1;
          }
          return withheld;
        }
        const rows = found.links.filter((link) => link.status === 'invalid' || link.status === 'ok')
          .map((link) => (link.status === 'invalid'
          ? '- 有一条已失效'
          : `- ${link.scope === 'global' ? '[global] ' : (scopeName ? `[${scopeName}] ` : '')}「${link.title}」`));
        const text = rows.join('\n') || '(无)';
        const value = { title: found.title || '', scope: found.scope, scopeName, status: found.status, links: text };
        if (win) {
          const bytes = jsonBytes(value);
          if (!affordableTool(win, bytes)) return { scope: '', status: 'budget_exhausted' };
          win.bytes += bytes;
          win.toolBytes += bytes;
          win.reads += 1;
        }
        return value;
      }
      const record = readEntry(readScope, refIdOf(readScope, args, '记忆', { adoptNear: true }), {
        layers: args.scope ? [readScope] : undefined,
        context: readContext,
        allowExperimental,
        /** 只有真正把正文交出去的读取才算用过：条件未知/被取代/过期不更新使用记录。 */
        usage: (item) => view.eligibility(item, gateRuntime, 'read').ok,
      });
      if (!record) throw new Error(`没有「${String(args.title || args.id || '').trim()}」这条记忆；标题可粘展示行或给 id`);
      /** 归档条目还能按标题找到：只回状态，不交正文，也不把它当成「不存在」。 */
      if (record.status === 'archived') return { title: record.title, scope: record.scope, status: 'archived', body: '' };
      const gate = view.eligibility(record, gateRuntime, 'read');
      if (!gate.ok) {
        const gaps = gate.status === 'needs_context' ? view.conditionGaps(record, gateRuntime).join('、') : '';
        return { scope: record.scope, status: gate.status, missing: gaps, body: '' };
      }
      /** 条件未知或不适用的条目只报状态：标题只能定位，不能证明适用，正文一律不先返回。 */
      if (record.status !== 'ok' && record.status !== 'archived') {
        const gaps = record.status === 'needs_context' ? view.conditionGaps(record, gateRuntime).join('、') : '';
        return { scope: record.scope, status: record.status === 'needs_context' ? 'needs_context' : 'not_applicable', missing: gaps, body: '' };
      }
      const revision = record.revision || 1;
      const body = String(record.body ?? '');
      /** 空正文只回标题与状态：没有正文可交付，就不占正文额度、不算引用。 */
      const hasBody = body.trim() !== '';
      const value = {
        title: record.title,
        when: record.when || '',
        revision,
        scope: record.scope,
        scopeName,
        status: record.status,
        kind: record.kind || 'note',
        /** 来源随正文回执一起给：模型整理稿要能标出来，但不会因此变成全局。 */
        origin: originOut(record.origin),
        body,
      };
      if (win) {
        if (!affordableTool(win, 0)) return { scope: '', status: 'budget_exhausted' };
        const seenRevision = win.readBodies.get(record.id);
        if (seenRevision === revision) {
          const receipt = { ...value, body: '', repeat: true };
          const bytes = jsonBytes(receipt);
          if (!affordableTool(win, bytes)) return { scope: '', status: 'budget_exhausted' };
          win.bytes += bytes;
          win.toolBytes += bytes;
          win.reads += 1;
          return receipt;
        }
        const bytes = jsonBytes(value);
        if (!affordableTool(win, bytes, hasBody ? 1 : 0)) return { scope: '', status: 'budget_exhausted' };
        win.bytes += bytes;
        win.toolBytes += bytes;
        if (hasBody) win.bodies += 1;
        win.reads += 1;
        if (hasBody) win.readBodies.set(record.id, revision);
      }
      if (hasBody) recordCitations(scope, sessionIdOf(execution), [record]);
      return value;
    },
  }), 'lite-memory: memory_read');

  ctx.effect(() => tools.register({
    name: 'memory_forget',
    description: '把一条记忆移入归档（不是彻底删除，正文与记录都留在 archive/，可人工取回）。只在用户明确说「别记这个 / 删掉那条」时用。',
    parameters: FORGET_PARAMS,
    output: {
      schema: {
        type: 'object',
        properties: {
          title: { type: 'string' },
          scope: { type: 'string' },
          scopeName: { type: 'string' },
          mode: { type: 'string', enum: ['archive', 'purged', 'needs_resolution', 'purge_pending', 'memory_disabled'] },
        },
        required: ['mode'],
        additionalProperties: false,
      },
      render: (_args, value) => [{
        type: 'text',
        text: value.mode === 'memory_disabled'
          ? 'memory · 本项目记忆已关闭，先在面板打开'
          : value.mode === 'purged'
          ? `memory · forgotten "${value.title}"`
          : value.mode === 'purge_pending'
            ? `memory · 清除未完成 · 「${value.title || '这条记忆'}」，重启后会继续`
            : value.mode === 'needs_resolution'
              ? `memory · 先确认是归档还是彻底忘掉 · 「${value.title || '这条记忆'}」`
              : `memory · archived ${withTag(value, `"${value.title}"`)}，可找回`,
      }],
      presentationMeta: (_args, value) => ({
        kind: 'memory-forget',
        title: value.title || '',
        scope: value.scope || '',
        mode: value.mode,
      }),
    },
    execute: async (args, execution) => {
      const scope = scopeOf(cwdOf(execution));
      const projectScopeName = projectNameOf(scope);
      if (!memoryEnabled(scope)) return { title: '', scope: '', mode: 'memory_disabled' };
      const forgetTitle = String(args.title || args.id || '').trim();
      if (!args.scope && args.mode) {
        const candidates = titleCandidates(scope, forgetTitle);
        if (candidates.length > 1) {
          throw new Error(`「${forgetTitle}」在项目层和全局层各有一条：删全局加 scope="global"，删项目加 scope="project"`);
        }
      }
      const onlyLayer = args.scope === 'global' ? globalScope() : args.scope === 'project' ? scope : null;
      const refId = refIdOf(scope, args);
      const located = locate(scope, refId, onlyLayer ? { layers: [onlyLayer] } : {});
      if (!located && !args.mode) throw new Error(`没有「${String(args.title || args.id || '').trim()}」这条记忆`);
      if (!args.mode) {
        return { title: located.record.title || '', mode: 'needs_resolution', scope: located.scope.key === 'global' ? 'global' : 'project' };
      }
      let dropped;
      try {
        dropped = forget(scope, refId, onlyLayer ? { mode: args.mode, layers: [onlyLayer] } : { mode: args.mode });
      } catch (error) {
        if (error && error.code === 'purge_pending') {
          const layer = located ? located.scope : scope;
          try {
            state.resumePurge(layer);
            dropped = forget(scope, refId, onlyLayer ? { mode: args.mode, layers: [onlyLayer] } : { mode: args.mode });
          } catch (again) {
            if (again && again.code === 'purge_pending') {
              return {
                title: located ? located.record.title : '',
                mode: 'purge_pending',
                scope: layer.key === 'global' ? 'global' : 'project',
                scopeName: layer.key === 'global' ? '' : projectScopeName,
              };
            }
            throw again;
          }
        } else {
          throw error;
        }
      }
      if (!dropped) throw new Error(`没有「${String(args.title || args.id || '').trim()}」这条记忆`);
      const layerKey = dropped.scopeKey || (located ? located.scope.key : scope.key);
      if (dropped.mode === 'purged') revokeLearningUse(layerKey);
      return {
        title: dropped.title || (located ? located.record.title : ''),
        mode: dropped.mode,
        scope: layerKey === 'global' ? 'global' : 'project',
        scopeName: layerKey === 'global' ? '' : projectScopeName,
      };
    },
  }), 'lite-memory: memory_forget');

  /**
   * 「记住我」的用户接口：开关、看已形成/观察中、手动修改、否掉某维、清空。
   * 面板没接上之前，这是唯一入口；参数与返回都保持封闭集，不接受自由文本人设。
   */
  const PERSONA_PARAMS = {
    type: 'object',
    properties: {
      action: {
        type: 'string',
        enum: ['status', 'enable', 'disable', 'edit', 'reject', 'clear', 'forget_evidence'],
        description: 'status 看现状；enable/disable 开关；edit 手动改一维；reject 否掉一维并停止使用；clear 清空全部；forget_evidence 删一条证据',
      },
      dimension: { type: 'string', description: '维度名，见 status 返回的 dimension 字段' },
      value: { type: 'string', description: '该维度的取值；必须是该维度允许的取值' },
      eventId: { type: 'string', description: 'forget_evidence 用：要删的证据编号' },
    },
    required: ['action'],
    additionalProperties: false,
  };
  const TUNE_PARAMS = {
    type: 'object',
    properties: {
      action: {
        type: 'string',
        enum: ['status', 'remember', 'suggest', 'apply', 'rollback', 'clear'],
        description: 'status 看现状；remember 记一条「这条查询该想起某条记忆」；suggest 试算一档；apply 采纳；rollback 回到上一组；clear 清空标注',
      },
      query: { type: 'string', description: 'remember 用：当时没被想起来的查询' },
      entryId: { type: 'string', description: 'remember 用：该想起的记忆 id' },
    },
    required: ['action'],
    additionalProperties: false,
  };
  const personaSummary = (action, persona_, extra = {}) => {
    const panel = personaStore.describePersona();
    return {
      action,
      ok: extra.ok !== false,
      ...(extra.reason ? { reason: extra.reason } : {}),
      enabled: persona_ ? persona_.control.enabled === true : panel.enabled,
      corrupt: panel.corrupt === true,
      formed: panel.formed.map((row) => `${row.dimension}=${row.value}`),
      observing: panel.observing.map((row) => `${row.dimension} · ${row.text}`),
    };
  };

  ctx.effect(() => tools.register({
    name: 'memory_persona',
    description: `用户的长期表达偏好（「记住我」），默认关闭。只记沟通方式，不记技术结论、项目事实或任何指令。status 看现状；disable 关掉。开启和修改只在记忆面板里由人确认，模型不能代办。`,
    parameters: PERSONA_PARAMS,
    output: {
      schema: {
        type: 'object',
        properties: {
          action: { type: 'string' },
          ok: { type: 'boolean' },
          reason: { type: 'string' },
          enabled: { type: 'boolean' },
          corrupt: { type: 'boolean' },
          formed: { type: 'array', items: { type: 'string' } },
          observing: { type: 'array', items: { type: 'string' } },
        },
        required: ['action', 'ok', 'enabled', 'formed', 'observing'],
        additionalProperties: false,
      },
      render: (_args, value) => [{
        type: 'text',
        text: value.corrupt
          ? 'memory · 记住我：画像文件读不了，已保留原文件不动'
          : `memory · 记住我 ${value.enabled ? '已开启' : '已关闭'}${value.formed.length ? ` · 已形成 ${value.formed.length} 项` : ''}${value.observing.length ? ` · 观察中 ${value.observing.length} 项` : ''}${value.reason ? `\n${value.reason}` : ''}`,
      }],
    },
    execute: async (args, execution) => {
      const action = String(args.action || 'status');
      const fail = (reason) => ({ action, ok: false, reason, enabled: false, corrupt: false, formed: [], observing: [] });
      /** 工具自带这道门：宿主层的隐藏/守卫之外再核一次，关着就什么都不读不写。 */
      if (!memoryEnabledFor(execution)) return fail(memoryOffCopy(scopeOf(cwdOf(execution))));
      const dim = String(args.dimension || '').trim();
      const value = String(args.value || '').trim();
      /** 开启与手动设定只由人在面板里做，模型不能把一次调用写成用户确认。 */
      if (action === 'enable') return fail('开启只在记忆面板里由你确认');
      if (action === 'disable') {
        /** 和面板、卸载走同一条取消路径：关掉后不能还有一次抽取把结果写回来。 */
        personaAbortHook();
        const next = personaStore.setPersonaEnabled({ enabled: false });
        return personaSummary(action, next.persona, { ok: next.ok });
      }
      if (action === 'status') return personaSummary(action, null);
      if (action === 'clear') {
        personaAbortHook();
        const next = personaStore.clearPersona();
        return personaSummary(action, next.persona, { ok: next.ok });
      }
      if (action === 'edit') {
        if (!dim || !value) return fail('edit 需要 dimension 和 value');
        return fail('修改只在记忆面板里由你确认');
      }
      if (action === 'reject') {
        if (!dim) return fail('reject 需要 dimension');
        const next = personaStore.rejectPersonaPreference({ dimension: dim });
        return personaSummary(action, next.persona, { ok: next.ok, reason: next.ok ? '' : next.reason });
      }
      if (action === 'forget_evidence') {
        const next = personaStore.retractPersonaEvidence({ eventId: args.eventId, dimension: dim });
        return personaSummary(action, next.persona, { ok: next.ok, reason: next.ok ? '' : next.reason });
      }
      return fail(`不认识的 action：${action}`);
    },
  }), 'lite-memory: memory_persona');

  /** 受限自进化：只吃用户标过「该想起却没想到」的查询，一次只走一档，必须整批不变差。 */
  ctx.effect(() => tools.register({
    name: 'memory_tune',
    description: '记忆排序的自进化。只按用户明确标过的「这条查询该想起某条记忆」调整白名单参数，一次一档、可回滚；不改存储、隔离与授权。用户说「刚才没想起来」时才 remember。',
    parameters: TUNE_PARAMS,
    output: {
      schema: {
        type: 'object',
        properties: {
          action: { type: 'string' },
          ok: { type: 'boolean' },
          reason: { type: 'string' },
          changed: { type: 'boolean' },
          replayCases: { type: 'number' },
          evidenceRevision: { type: 'number' },
          policyRevision: { type: 'number' },
          needsReeval: { type: 'boolean' },
          canRollback: { type: 'boolean' },
          params: { type: 'object', additionalProperties: true },
          defaults: { type: 'object', additionalProperties: true },
          corrupt: { type: 'boolean' },
          revision: { type: 'number' },
          proposal: { type: 'object', additionalProperties: true },
          baseline: { type: 'object', additionalProperties: true },
          applied: { type: 'object', additionalProperties: true },
          lastChange: { type: 'object', additionalProperties: true },
        },
        required: ['action'],
        additionalProperties: false,
      },
      render: (_args, value) => [{
        type: 'text',
        text: value.ok === false
          ? `memory · 调参没有改动${value.reason ? ` · ${value.reason}` : ''}`
          : `memory · 调参 · 回放 ${Number(value.replayCases) || 0} 条${value.needsReeval ? '（证据变了，需重评）' : ''} · ${value.changed ? '已改一档' : '未改动'}${value.proposal ? ` · 建议 ${value.proposal.key} ${value.proposal.from}→${value.proposal.to}` : ''}`,
      }],
    },
    execute: async (args, execution) => {
      const action = String(args.action || 'status');
      const scope = scopeOf(cwdOf(execution));
      if (!memoryEnabled(scope)) return { action, ok: false, reason: memoryOffCopy(scope), changed: false };
      const { status, value } = tuneAction(scope, { op: action, query: args.query, entryId: args.entryId });
      return { action, ...value, ok: status === 200 && value.ok !== false, changed: value.changed === true };
    },
  }), 'lite-memory: memory_tune');

  /** 「保留」「✕」按钮与统计都挂在 WebServer 上；没有该服务时工具照常可用。 */
  const mountRoute = (holder) => {
    const webServer = holder.webServer ?? holder;
    if (!webServer || typeof webServer.register !== 'function' || typeof webServer.getOrigin !== 'function') return;
    const cwdForSession = (sessionId) => {
      const sessions = getService('sessions');
      if (!sessions || typeof sessions.get !== 'function') return '';
      try {
        const cwd = sessions.get(sessionId)?.header?.cwd;
        return typeof cwd === 'string' ? cwd : '';
      } catch {
        return '';
      }
    };
    holder.effect(() => webServer.register({ kind: 'prefix', path: REMOTE_PATH, handler: keepHandler(webServer, cwdForSession) }), 'lite-memory: keep route');
  };
  if (typeof ctx.inject === 'function') ctx.inject(['webServer'], (scope) => mountRoute(scope));
  else mountRoute(ctx);

  /**
   * 自动召回：provider 在加载时注册一次，pre-step 拿到这次请求的准备结果后填充。
   * provider 只读内存快照；没准备好就返回空字符串，不注入任何东西。
   * 画像段排在召回段之前：两段共用 1200 字节，先渲染的那段先占额度。
   */
  const prompt = getService('systemPrompt');
  if (prompt && typeof prompt.context === 'function') {
    ctx.effect(() => prompt.context({
      name: 'lite-memory:persona',
      order: 59,
      interpolate: false,
      required: false,
      text: (holder) => personaText(holder),
    }), 'lite-memory: persona context');
  }

  if (prompt && typeof prompt.context === 'function') {
    ctx.effect(() => prompt.context({
      name: 'lite-memory:recall',
      order: 60,
      interpolate: false,
      required: false,
      text: (holder) => recallText(holder),
    }), 'lite-memory: recall context');
  }

  /** 引号/反引号里的是「被引用的字」：按钮文案、别人说的话都不构成授权。 */
  const QUOTED_SPAN = /`[^`]*`|「[^」]*」|『[^』]*』|“[^”]*”|"[^"\n]*"/gu;
  const GLOBAL_OBJECT = '(?:全局|所有项目|跨项目|全库)';
  /** 否定句是相反的指令：「不要存全局」「全局的别记」都必须留在项目层。 */
  const GLOBAL_NEGATED = new RegExp(
    `(?:不要|不用|别|不准|不需要|禁止|勿).{0,8}(?:存|记|写|放|加|保存|放到|记到|写进|进).{0,12}${GLOBAL_OBJECT}`
    + `|${GLOBAL_OBJECT}.{0,8}(?:不要|不用|别|不准|不需要|禁止|勿|不存|不记|不写)`,
    'u',
  );

  /**
   * 只有人在这句话里明确要求「存到全局/所有项目」才算跨项目授权。
   * 句子里同时出现「全局」和「保存」不够：那可能是在说全局变量，或只是在念按钮文字。
   */
  const humanAskedGlobal = (said) => {
    const text = String(said || '').replace(QUOTED_SPAN, ' ').replace(/\s+/g, ' ').trim();
    if (!text) return false;
    if (GLOBAL_NEGATED.test(text)) return false;
    /** 「保存全局变量/配置/状态」说的是代码里的对象，不是记忆归属。 */
    const action = new RegExp(
      `(?:存|记|写|放|加|保存|放到|记到|写进).{0,10}${GLOBAL_OBJECT}(?!变[量数]|配置|状态|作用域|对象|数组)`,
      'u',
    );
    const universal = new RegExp(`${GLOBAL_OBJECT}.{0,10}(?:都|一律|通用|适用|记住)`, 'u');
    const future = /(?:以后|今后).{0,16}(?:所有项目|每个项目|全局|跨项目)/u;
    return action.test(text) || universal.test(text) || future.test(text);
  };

  /**
   * 动作前提示：只把「当前项目/任务下确实适用、且和这条命令真的相关」的记忆交给模型。
   * 判断与排序复用自动召回那一套（按项目层、全局层取候选，同一份 eligibility/rank），
   * 不另写关键字命中，也不在这里补业务结论——正文写什么就交什么。
   */
  const npmProbeHint = (agent, execution) => {
    try {
      const name = String(execution?.name || '');
      if (!/^(bash|run_command|shell|terminal|exec)$/.test(name)) return undefined;
      const command = String(execution?.arguments?.command || execution?.arguments?.cmd || execution?.arguments?.input || '');
      if (!command || command.length > 4000 || !/\bnpm\b/.test(command)) return undefined;
      /** 已经在用 dsh-npm 的调用不拦：要提示的是原生 npm 的探测/发布。 */
      if (/dsh-npm/.test(command)) return undefined;
      const probe = /(^|[;&|]\s*)(?:sudo\s+)?npm\s+(?:whoami|publish|login|adduser|add-user|token|config\s+get)\b/.test(command);
      if (!probe) return undefined;
      const held = prepared.get(agent);
      if (!held || held.npmHinted) return undefined;
      if (!memoryOnForAgent(agent)) return undefined;
      const win = windowOf(agent);
      /** 没有请求账本就不额外交付：提示也是给模型的内容，必须能记账。 */
      if (!win || !win.autoBudget) return undefined;
      const runtime = held.runtimeHeld || win.runtime || null;
      const context = runtime && runtime.context ? runtime.context : view.trustedContext(held.scope, {});
      const task = runtime && runtime.task ? runtime.task : null;
      /** 当前项目的规则先于全局规则：本项目怎么发布，比通用说明更该先看。 */
      let row = null;
      for (const source of [held.scope, globalScope()]) {
        let index;
        try { index = loadIndex(source); } catch { continue; }
        const records = [];
        for (const entry of index.entries || []) {
          if (!entry || entry.archived || entry.origin === 'project_evolution') continue;
          if (held.deliveredIds instanceof Set && held.deliveredIds.has(entry.id)) continue;
          records.push(entry);
        }
        if (!records.length) continue;
        const ranked = view.rank(records, command, { limit: 1, requireApplicable: true, context, runtime, task });
        row = ranked[0] && ranked[0].record ? ranked[0].record : null;
        if (row) break;
      }
      if (!row) return undefined;
      const body = String(row.body || row.summary || '').trim();
      if (!body) return undefined;
      const hint = `[lite-memory] 这条 npm 命令先别执行，先看记忆「${row.title}」：\n${body}`;
      if (!affordableTool(win, Buffer.byteLength(hint))) return undefined;
      win.toolBytes = Number(win.toolBytes || 0) + Buffer.byteLength(hint);
      held.npmHinted = true;
      /** 这条正文真的交给模型了，按交付记使用。 */
      if (!(held.deliveredIds instanceof Set)) held.deliveredIds = new Set();
      if (row.id) held.deliveredIds.add(row.id);
      return hint;
    } catch {
      return undefined;
    }
  };

  /**
   * 动作侧通道：工具真的被调用时，用「工具名 + 关键参数」做一次窄查询。
   * 预防型条目（procedure / pitfall）约束的是下一步动作，字面常写在命令里，而不是用户那句话里；
   * 只认触发词真的出现在这次调用里的条目，避免把泛泛相关的记忆塞进工具结果。
   * 与自动召回共用同一份请求额度（win.toolBytes），每轮最多补一次。
   */
  const PASSIVE_ACTION = /^(?:read|read_image|glob|grep|list|find|view|fetch|web_search|web_fetch|job_output|job_list|job_kill|todo_write|ask_user_question|ask_user|question|skill|working_directory|present|sidebar_open|unlag_refresh|schedule_list|schedule_create|schedule_delete|schedule_update|memory_)/;
  const ACTION_ARG_KEYS = ['command', 'cmd', 'input', 'file_path', 'path', 'pattern', 'query', 'url', 'description', 'content', 'old_string', 'new_string', 'script', 'code', 'target', 'action', 'package'];
  const ACTION_ARG_CHARS = 160;
  const actionQueryOf = (execution) => {
    const name = String(execution?.name || '').trim();
    const args = execution?.arguments && typeof execution.arguments === 'object' ? execution.arguments : {};
    let text = name;
    for (const key of ACTION_ARG_KEYS) {
      const value = args[key];
      if (typeof value === 'string' && value.trim()) text += ` ${value.trim().slice(0, ACTION_ARG_CHARS)}`;
    }
    return text.slice(0, 600);
  };
  const actionSideHint = (agent, execution) => {
    try {
      const name = String(execution?.name || '');
      if (!name || MEMORY_TOOLS.includes(name) || PASSIVE_ACTION.test(name)) return undefined;
      const held = prepared.get(agent);
      if (!held || held.actionHinted) return undefined;
      if (!memoryOnForAgent(agent)) return undefined;
      const win = windowOf(agent);
      if (!win || !win.autoBudget) return undefined;
      const query = actionQueryOf(execution);
      if (!query || query === name) return undefined;
      const runtime = held.runtimeHeld || win.runtime || null;
      const context = runtime && runtime.context ? runtime.context : view.trustedContext(held.scope, {});
      const task = runtime && runtime.task ? runtime.task : null;
      const lowered = query.toLowerCase();
      let row = null;
      for (const source of [held.scope, globalScope()]) {
        let index;
        try { index = loadIndex(source); } catch { continue; }
        const records = [];
        for (const entry of index.entries || []) {
          if (!entry || entry.archived || entry.origin === 'project_evolution') continue;
          if (entry.kind !== 'procedure' && entry.kind !== 'pitfall') continue;
          if (held.deliveredIds instanceof Set && held.deliveredIds.has(entry.id)) continue;
          /** 窄：触发词必须真的出现在这次调用里，否则不打扰。 */
          const fired = (entry.triggers || []).some((trigger) => {
            const text = String(trigger || '').trim().toLowerCase();
            return Boolean(text) && lowered.includes(text);
          });
          if (fired) records.push(entry);
        }
        if (!records.length) continue;
        const ranked = view.rank(records, query, { limit: 1, requireApplicable: true, context, runtime, task });
        row = ranked[0] && ranked[0].record ? ranked[0].record : null;
        if (row) break;
      }
      if (!row) return undefined;
      const body = String(row.body || row.summary || '').trim().slice(0, 600);
      if (!body) return undefined;
      const hint = `[lite-memory] 执行 ${name} 之前先看记忆「${row.title}」：\n${body}`;
      if (!affordableTool(win, Buffer.byteLength(hint))) return undefined;
      win.toolBytes = Number(win.toolBytes || 0) + Buffer.byteLength(hint);
      held.actionHinted = true;
      if (!(held.deliveredIds instanceof Set)) held.deliveredIds = new Set();
      if (row.id) held.deliveredIds.add(row.id);
      return hint;
    } catch {
      return undefined;
    }
  };

  /** 执行入口再拦一次：工具若已出现在旧快照里，调用时也不放行。 */
  if (typeof ctx.on === 'function') ctx.on('agent/created', (payload) => {
    const agent = payload?.agent;
    if (!agent?.ctx?.tools) return;
    try {
      agent.ctx.effect(() => agent.ctx.tools.guard((execution) => {
        if (MEMORY_TOOLS.includes(execution?.name)) {
          return memoryOnForAgent(agent) ? undefined : '本项目记忆已关闭，先在面板打开';
        }
        return npmProbeHint(agent, execution) || actionSideHint(agent, execution);
      }), 'lite-memory: tool guard');
    } catch { /* older host without guards */ }
    syncMemoryTools(agent);
  });

  if (typeof ctx.on === 'function') ctx.on('agent/pre-step', async (payload, next) => {
    const agent = payload?.agent;
    syncMemoryTools(agent);
    let decision;
    try {
      decision = await next();
    } catch (error) {
      clearPrepared(agent);
      throw error;
    }
    /** 宿主等待不算本地召回时间：额度从拿到这一步的开始算。 */
    const startedAt = Date.now();
    try {
      if (!agent || decision?.kind !== 'enter') {
        clearPrepared(agent);
        return decision;
      }
      const signal = payload?.signal;
      if (signal?.aborted) {
        clearPrepared(agent);
        return decision;
      }
      const sessionId = String(agent?.session?.id ?? '');
      if (!sessionId) {
        clearPrepared(agent);
        return decision;
      }
      const generation = (generations.get(agent) || 0) + 1;
      generations.set(agent, generation);
      const turn = String(payload?.turn ?? payload?.step?.turn ?? payload?.turnIndex ?? '');
      const humans = (Array.isArray(decision.messages) ? decision.messages : [])
        .filter((message) => message?.source?.kind === 'user');
      const fresh = freshHumans(sessionId, humans);
      const previous = prepared.get(agent);
      if (fresh.length > 0 && previous) flushUsage(previous);
      const sameSession = Boolean(previous && previous.sessionId === sessionId);
      const sessionTask = recallTasks.get(sessionId) || null;
      /**
       * 授权与召回模式无关：这句话先记下来，写工具在哪条分支被调用都能核对。
       * 必须在任何模式分支返回之前记，否则 adaptive 下的真实原话会在下一步丢失。
       */
      const saidThisStep = view.newestUserQuery(fresh).slice(0, RECALL_QUERY_CHARS);
      const heldAuth = requestAuth.get(agent);
      if (saidThisStep) requestAuth.set(agent, { said: saidThisStep, turn, sessionId });
      else if (!(heldAuth && heldAuth.turn === turn && heldAuth.sessionId === sessionId)) requestAuth.delete(agent);
      /** 「记住我」第一阶段：只在本轮真人原话里认信号，不调模型、不写项目记忆。 */
      if (saidThisStep) {
        const personaScope = scopeOf(cwdOf({ agent }));
        enqueuePersonaSignal(saidThisStep, {
          sessionId,
          taskId: '',
          projectId: personaScope ? personaScope.key : '',
          memoryOn: memoryEnabled(personaScope),
        });
      }

      if (fresh.length === 0) {
        /** 工具续步：内容冻结，只把快照绑到本步的 signal；盘上版本变了才重投影。 */
        const turnChanged = !!(turn && previous?.turn && turn !== previous.turn);
        if (!sameSession || turnChanged) {
          clearPrepared(agent);
          return decision;
        }
        previous.signal = signal;
        const scope = scopeOf(cwdOf({ agent }));
        if (!memoryEnabled(scope)) {
          clearPrepared(agent);
          return decision;
        }
        const fingerprint = fingerprintOf(scope);
        /** 指纹拿不到就当作已失效：不拿旧任务内容硬撑这一步。 */
        if (!fingerprint) {
          clearPrepared(agent);
          return decision;
        }
        if (fingerprint !== previous.fingerprint) {
          const win = windowOf(agent);
          if (win) win.autoBudget = emptyAutoBudget();
          const snapshot = projectRecall(scope, previous.query, win && win.runtime ? win.runtime.context : view.trustedContext(scope, {}), win, win && win.runtime ? win.runtime : null);
          let experimentText = '';
          if (win && win.experiment) {
            experimentText = renderExperiment(scope, win.experiment.decision, win.experiment.context, win.experiment, win);
          }
          if (generation === generations.get(agent) && !signal?.aborted) {
            if (snapshot || experimentText) {
              previous.text = snapshot ? snapshot.text : '';
              previous.cards = snapshot ? snapshot.cards : [];
              previous.lines = snapshot ? snapshot.lines : [];
              previous.experimentText = experimentText;
              previous.experimentParts = win && win.experiment ? (win.experiment.experimentParts || null) : null;
              previous.validUntil = win && win.experiment ? (win.experiment.validUntil || '') : '';
              previous.fingerprint = fingerprint;
            } else {
              clearPrepared(agent);
            }
          }
        }
        /**
         * 工具续步里没有新的真人原话，但刚执行的动作本身就是线索。
         * 只补一次、共用一个请求额度，补到的卡片追加到已发布快照，超出仍由预算挡。
         */
        const stepMessages = Array.isArray(decision.messages) ? decision.messages : [];
        const seenIds = previous.seenIds instanceof Set ? previous.seenIds : new Set(previous.seenIds || []);
        const stepActions = stepMessages.filter((message) => {
          const id = String(message?.id ?? '');
          return id ? !seenIds.has(id) : false;
        });
        previous.seenIds = new Set([...seenIds, ...stepMessages.map((message) => String(message?.id ?? '')).filter(Boolean)].slice(-64));
        previous.seenMessages = stepMessages.length;
        /** 只读文件、搜索、记忆工具都不算动作；一次请求最多补查一次。 */
        const actionQuery = previous.recalledContext && !previous.actionRetried
          && view.hasEffectiveAction(stepActions)
          ? view.actionTerms(stepActions, { limit: 10 }).slice(0, 240) : '';
        if (actionQuery) {
          previous.actionRetried = true;
          const win = windowOf(agent);
          if (win && generation === generations.get(agent) && !signal?.aborted) {
            const nextQuery = `${actionQuery} ${previous.query}`.trim().slice(0, RECALL_QUERY_CHARS);
            const retry = projectRecall(scope, nextQuery, previous.recalledContext, win, previous.runtimeHeld || null);
            if (retry.cards.length) {
              /** 补查结果整体替换展示快照；账本与正文来自同一次准入。 */
              previous.text = retry.text;
              previous.cards = retry.cards;
              previous.lines = retry.lines;
              previous.query = nextQuery;
              previous.matched = retry.matched || retry.cards.length;
              if (win) win.query = nextQuery;
            }
          }
        }
        return decision;
      }

      /** 工具模式也要开额度窗口：只是不自动注入，工具调用同样受每请求预算约束。 */
      const ids = fresh.map((message) => String(message?.id ?? '')).filter(Boolean).sort();
      const win = openWindow(agent, { sessionId, turn, messageIds: ids });
      const budgetBefore = win ? {
        bytes: win.bytes, bodies: win.bodies, reads: win.reads, toolBytes: win.toolBytes || 0,
        provided: new Map(win.provided), readBodies: new Map(win.readBodies),
        recallHeader: win.recallHeader, experimentBytes: win.experimentBytes,
        autoBudget: win.autoBudget ? JSON.parse(JSON.stringify(win.autoBudget)) : null,
      } : null;
      /** 工具模式也要记下本轮真人原话：只用于核对绑定，不自动注入。 */
      const said = saidThisStep;
      const continuationHint = view.isContinuationQuery(said) || view.isEllipticalContinuation(said)
        || view.isContinuationOpening(said);
      /** 「继续」这类续说没有检索词：带上同会话上一轮原话，否则这一轮必然召回为空。 */
      const carried = continuationHint
        ? (sessionTask?.taskQuery || previous?.query || sessionTask?.query || '') : '';
      let query = (carried ? `${said} ${carried}` : said).trim().slice(0, RECALL_QUERY_CHARS);
      if (win && query) win.query = query;

      if (!query) {
        clearPrepared(agent);
        return decision;
      }
      const cwd = cwdOf({ agent });
      if (typeof cwd !== 'string' || !cwd) {
        clearPrepared(agent);
        return decision;
      }
      const scope = scopeOf(cwd);
      if (!memoryEnabled(scope)) {
        noteRecall(scope, sessionId, { reason: 'memory_off' });
        clearPrepared(agent);
        return decision;
      }
      const batchKey = anchor.requestBatchKey(ids);
      /**
       * 工具模式也必须先有本请求上下文：memory_search/read/links 靠同一个 contextId 判项目和任务，
       * 不能等到自动召回分支才建，否则工具模式永远拿不到可核对的任务。
       */
      const runtime = runtimeFor(scope, { sessionId, query, batchKey, messageIds: ids, autoRoute: modeFor(scope) === 'adaptive' });
      if (win && runtime) win.runtime = runtime.held;
      rememberRuntime(scope, sessionId, runtime && runtime.held);
      if (modeFor(scope) !== 'adaptive') {
        noteRecall(scope, sessionId, { reason: 'tools_only' });
        clearPrepared(agent);
        return decision;
      }
      const context = view.trustedContext(scope, {});
      const fingerprint = fingerprintOf(scope);
      const controlEpoch = controlStatus(scope).epoch || '';
      dropStaleCandidate(sessionId, batchKey);
      /** 任务上下文独立于自进化开关：普通记忆按当前任务判适用，实验规则再叠一层可用性。 */
      const auto = emptyAutoBudget();
      if (win) win.autoBudget = auto;
      const recalledContext = runtime ? runtime.held.context : context;
      const remembered = runtime && runtime.enabled
        ? rememberFeedback(scope, sessionId, fresh, runtime.held, turn)
        : null;
      const currentTask = {
        kind: (runtime && runtime.held && runtime.held.task && runtime.held.task.kind) || '',
        episodeId: (runtime && runtime.held && runtime.held.episodeId) || '',
      };
      const rememberedTask = lastTask.get(sessionId) || null;
      const previousTask = (previous && previous.task) || (sessionTask && sessionTask.task) || rememberedTask;
      const previousText = (previous && previous.query) || (sessionTask && sessionTask.query) || '';
      const previousSaid = (previous && previous.saidOnly) || (sessionTask && sessionTask.saidOnly) || '';
      const sameQuery = Boolean(previousSaid && said && previousSaid === said);
      const sameTask = Boolean(sameSession || sessionTask || rememberedTask)
        && !view.isExplicitSwitch(said, previousText)
        && view.sameRecallTask(previousTask, currentTask, { continuation: continuationHint, sameQuery });
      const taskStartMessageId = sameTask && sessionTask && sessionTask.startMessageId
        ? sessionTask.startMessageId : ids[0];
      lastTask.set(sessionId, currentTask);
      recallTasks.set(sessionId, {
        query,
        saidOnly: said,
        /** 当前任务的稳定原话：续说只拼这一份，不把上一轮的动作线索越滚越长。 */
        taskQuery: sameTask ? (sessionTask?.taskQuery || carried || said) : said,
        task: currentTask,
        startMessageId: taskStartMessageId,
        updatedAt: Date.now(),
      });
      while (lastTask.size > 64) lastTask.delete(lastTask.keys().next().value);
      while (recallTasks.size > 64) recallTasks.delete(recallTasks.keys().next().value);
      /**
       * 预防型记忆约束的是「下一步动作」，词面常写在上一轮助手的话和工具调用里，用户这句话反而没提。
       * 续句或没有具体动作的短问句，直接把最近的动作线索并进同一份查询：只查一次，不额外占预算。
       * 明确换任务时不并，旧任务的动作历史不能给新任务找记忆。
       */
      const humanTail = (() => {
        const messages = Array.isArray(decision.messages) ? decision.messages : [];
        for (let i = messages.length - 1; i >= 0; i -= 1) {
          if (messages[i]?.source?.kind === 'user') return messages.slice(0, i);
        }
        return messages;
      })();
      /** 只拿当前任务开始之后的消息，旧任务的工具痕迹不能混进新任务。 */
      const taskStart = taskStartMessageId
        ? decision.messages.findIndex((message) => String(message?.id ?? '') === taskStartMessageId) : -1;
      const tailMessages = sameTask && taskStart >= 0 ? decision.messages.slice(taskStart + 1) : humanTail;
      const trail = sameTask ? view.actionTerms(tailMessages, { limit: 12 }).slice(0, 240) : '';
      const trailInQuery = Boolean(trail) && (Boolean(carried) || !view.hasConcreteAction(said));
      if (trailInQuery) {
        query = `${query} ${trail}`.trim().slice(0, RECALL_QUERY_CHARS);
        if (win) win.query = query;
      }
      let snapshot = projectRecall(scope, query, recalledContext, win, runtime ? runtime.held : null);
      /**
       * 并了动作线索仍一张卡都没有，才补一次有界查询。
       * 补到就用补查结果整体替换：两批卡片各量一次会绕过 3 条 / 1200 字节的共用额度。
       */
      if (!snapshot.cards.length && !carried && sameTask && trail && !trailInQuery) {
        const actionQuery = `${trail} ${query}`.trim().slice(0, RECALL_QUERY_CHARS);
        const retry = projectRecall(scope, actionQuery, recalledContext, win, runtime ? runtime.held : null);
        if (retry.cards.length) {
          snapshot = retry;
          query = actionQuery;
          if (win) win.query = actionQuery;
        }
      }
      /** 实验规则最后才取预算：普通卡片先占，弱相关实验不能把强相关项目规则挤出去。 */
      const experiment = runtime ? experimentFor(scope, runtime, win) : null;
      /**
       * 一条卡片都没发布时落 miss 证据：查询原话、最接近的候选与分数。
       * 只记判断不留正文，面板与回执都读得到，阈值调整才有依据。
       */
      let closest = '';
      if (!snapshot.cards.length && query) {
        const near = [];
        for (const source of [scope, globalScope()]) {
          let index;
          try { index = loadIndex(source); } catch { continue; }
          const records = (index.entries || []).filter((item) => item && item.title && item.status !== 'archived'
            && item.origin !== 'project_evolution' && !view.lifecycleStatusOf(item));
          if (!records.length) continue;
          const rows = view.rank(records, query, {
            limit: 2, requireApplicable: true, context: recalledContext, runtime: runtime ? runtime.held : null, task: currentTask,
          });
          for (const row of rows) near.push(`${row.record.title} ${(Number(row.score) || 0).toFixed(2)}`);
        }
        closest = near.slice(0, 3).join(' / ');
      }
      noteRecall(scope, sessionId, {
        reason: snapshot.reason, matched: snapshot.matched, cards: snapshot.cards.length, chars: snapshot.bytes, closest,
        plan: snapshot.plan,
      });
      /** 没发布出去的投影要退还额度：不能因为一次超时把本请求的召回额度耗掉。 */
      const rollbackBudget = () => {
        if (!win || !budgetBefore) return;
        win.bytes = budgetBefore.bytes;
        win.bodies = budgetBefore.bodies;
        win.reads = budgetBefore.reads;
        win.toolBytes = budgetBefore.toolBytes;
        win.provided = budgetBefore.provided;
        win.readBodies = budgetBefore.readBodies;
        win.recallHeader = budgetBefore.recallHeader;
        win.experimentBytes = budgetBefore.experimentBytes;
        win.autoBudget = budgetBefore.autoBudget || emptyAutoBudget();
        win.experiment = null;
        win.contexts.clear();
      };
      if (generation !== generations.get(agent)) { rollbackBudget(); if (snapshot.cards.length) clearRecall(scope, sessionId); return decision; }
      /** 投影期间开关被改过：丢弃这批内容，不把关闭前的记忆交给当前请求。 */
      if (!memoryEnabled(scope) || (controlStatus(scope).epoch || '') !== controlEpoch) {
        rollbackBudget();
        if (snapshot.cards.length) clearRecall(scope, sessionId);
        clearPrepared(agent);
        return decision;
      }
      /** 超时或被取消：这一步不留半旧卡片，下一真人请求重新投影。 */
      const deadlineMs = recallDeadlineFor(scope);
      if (signal?.aborted || Date.now() - startedAt > deadlineMs) {
        rollbackBudget();
        /** 面板要说清这次为什么没有卡片：超时丢的是已经算完的投影，不是没命中。 */
        noteRecall(scope, sessionId, {
          reason: signal?.aborted ? 'aborted' : 'deadline',
          matched: snapshot ? snapshot.matched : 0,
          cards: 0,
          chars: 0,
        });
        clearPrepared(agent);
        return decision;
      }
      /**
       * 零命中也要保留请求状态：这一轮第一步没命中，下一步的动作仍可能触发一次补查。
       * 展示快照为空即可，不把任务身份和额度窗口一起丢掉。
       */
      let evolutionEpoch = '';
      try { evolutionEpoch = String(evolutionStatus(scope).epoch || ''); } catch { evolutionEpoch = ''; }
      const state = {
        text: snapshot && snapshot.cards.length ? snapshot.text : '',
        experimentText: experiment ? experiment.text : '',
        experimentParts: experiment && experiment.held ? (experiment.held.experimentParts || null) : null,
        validUntil: experiment && experiment.held ? (experiment.held.validUntil || '') : '',
        cards: snapshot ? snapshot.cards : [],
        lines: snapshot ? snapshot.lines : [],
        matched: snapshot ? snapshot.matched : 0,
        task: currentTask,
        scope,
        query,
        saidOnly: said,
        sessionId,
        turn,
        signal,
        fingerprint,
        controlEpoch,
        evolutionEpoch,
        recalledContext,
        runtimeHeld: runtime && runtime.held ? runtime.held : null,
        seenMessages: Array.isArray(decision.messages) ? decision.messages.length : 0,
        seenIds: Array.isArray(decision.messages) ? decision.messages.map((message) => String(message?.id ?? '')).filter(Boolean).slice(-64) : [],
        actionRetried: false,
        deliveredIds: new Set(),
        /** 同一任务共用一份使用账本：续说/重查不重复抬高价值。 */
        taskStartId: taskStartMessageId,
        at: Date.now(),
      };
      prepared.set(agent, state);
      /** 真正输出给模型时才算使用；准备阶段被丢弃/中止的快照不能改 lastUsed。 */
      payloadBytes.set(sessionId, win.bytes);
      while (payloadBytes.size > 64) payloadBytes.delete(payloadBytes.keys().next().value);
      if (signal) signalAgents.set(signal, agent);
      const key = agentKey(agent);
      if (key && signal && typeof signal.addEventListener === 'function') {
        const onAbort = () => { clearPrepared(agent); clearRecall(scope, sessionId); };
        signal.addEventListener('abort', onAbort, { once: true });
        abortCleanups.set(key, () => signal.removeEventListener('abort', onAbort));
      }
    } catch {
      clearPrepared(agent);
    }
    return decision;
  });


  /* ---------------- 项目自进化：一次短整理，先扣频次，再走提交门禁 ---------------- */

  /** 只清不属于当前这批人类消息的旧候选：新一轮开始后，上一轮没整理完的反馈不能再落盘。 */
  function dropStaleCandidate(sessionId, batchKey) {
    const prior = feedbackCandidates.get(sessionId);
    if (prior && prior.candidate && prior.candidate.batchKey !== batchKey) {
      feedbackCandidates.delete(sessionId);
    }
  }

  /**
   * 反馈只来自本轮真人消息；初始任务、工具成功、沉默都不算。
   * 解析目标由整理器完成：不在这里暂停所有已注入规则，避免一次 BGM 纠正打掉开头和字幕。
   */
  function rememberFeedback(scope, sessionId, messages, held, turn) {
    let candidate;
    try {
      candidate = learning.candidateFrom({
        messages, anchor: held.anchor, sessionId, projectId: scope.key, now: Date.now(),
      });
    } catch { return null; }
    if (!candidate) return null;
    candidate.cwd = scope.cwd;
    candidate.episodeUpdatedAt = held.episodeUpdatedAt || '';
    candidate.batchKey = held.batchKey || '';
    candidate.turn = String(turn || '');
    const revision = (feedbackRevisions.get(scope.key) || 0) + 1;
    feedbackRevisions.set(scope.key, revision);
    feedbackEpisodeRevisions.set(`${scope.key}\u0000${candidate.episodeId || ''}`, revision);
    candidate.feedbackRevision = revision;
    const prior = feedbackCandidates.get(sessionId);
    feedbackCandidates.set(sessionId, {
      scope,
      candidate,
      held,
      session: prior && prior.session ? prior.session : null,
      queued: Boolean(prior && prior.queued),
      at: Date.now(),
    });
    while (feedbackCandidates.size > 8) feedbackCandidates.delete(feedbackCandidates.keys().next().value);
    return { candidate };
  }

  /** 只认前台最近一次真实请求的路线；拿不到就宁可这次不整理。 */
  function routeForSession(session) {
    let config;
    try { config = session && typeof session.requestHeader === 'function' ? session.requestHeader()?.config : null; } catch { config = null; }
    const provider = config && typeof config.provider === 'string' ? config.provider : '';
    const model = config && typeof config.model === 'string' ? config.model : '';
    return provider && model ? { provider, model } : null;
  }

  function sessionIdOfSession(session) {
    try { return String(session?.header?.id ?? session?.id ?? ''); } catch { return ''; }
  }

  function scopeOfSession(session) {
    let cwd = '';
    try { cwd = String(session?.header?.cwd ?? ''); } catch { cwd = ''; }
    if (!cwd) return null;
    const scope = scopeOf(cwd);
    return scope && scope.confirmed ? scope : null;
  }

  /** 有配额才调用；输出整批校验，提交门禁再复核开关、版本、来源与目标。 */
  async function organize(scope, session, pending) {
    const status = evolutionStatus(scope);
    if (!status || status.enabled !== true || status.compatible === false) return;
    if (status.policyVersion !== learning.POLICY_VERSION) return;
    const route = routeForSession(session);
    if (!route) return;
    const candidate = pending.candidate;
    /** 候选进入整理前再走一次统一准入：项目/作品身份、作用域与反馈类型都对上才花配额。 */
    const admission = learning.admissionOf(candidate, {
      projectId: scope.key,
      sessionId: candidate.sessionId,
      anchor: pending.held?.anchor || null,
    }, 'collect');
    if (!admission || admission.ok !== true) return;
    const operationId = `learn_${crypto.createHash('sha256')
      .update(`${scope.key}|${candidate.episodeId}|${candidate.messageIds.join(',')}`)
      .digest('hex').slice(0, 16)}`;
    /** 没有可用模型就别先扣滚动额度：扣了却发不出调用，额度会白烧一整窗口。 */
    const llm = getService('llm');
    if (!llm || typeof llm.prepareCall !== 'function') return;
    const begin = beginLearningAttempt(scope, { episodeId: candidate.episodeId, operationId: `${operationId}_start`, now: Date.now() });
    if (!begin || begin.ok !== true || begin.replayed) return;
    const ranges = rangesOf(scope);
    const input = learning.buildCallInput({
      projectId: scope.key,
      episodeId: candidate.episodeId,
      taskKind: candidate.taskKind,
      seriesId: candidate.seriesId,
      phase: candidate.phase,
      feedback: candidate,
      rules: begin.rules,
      ranges,
    });
    const preparedTargets = (begin.rules || []).map((record) => ({
      id: record.id,
      revision: record.revision || 1,
      specDigest: learning.specDigestOf(record),
    }));
    const controller = new AbortController();
    learningAborts.set(scope.key, controller);
    const deadline = setTimeout(() => { try { controller.abort(); } catch { /* already aborted */ } }, learning.LIMITS.timeoutMs);
    const chunks = [];
    let text = '';
    let sawTool = false;
    let finish = { kind: 'stop' };
    try {
      const call = await llm.prepareCall({ ...route, maxTokens: learning.LIMITS.maxTokens }, controller.signal);
      const options = {
        ...call.config,
        messages: [{ role: 'user', content: [{ type: 'text', text: input.prompt }] }],
        system: input.system,
        sessionId: sessionIdOfSession(session),
        purpose: 'project-evolution',
        signal: controller.signal,
      };
      for await (const chunk of call.stream(options)) {
        if (controller.signal.aborted) throw new Error('整理已取消');
        chunks.push(chunk);
        if (chunk && chunk.type === 'text-delta') text += String(chunk.text || '');
        else if (chunk && chunk.type === 'tool-call-delta') sawTool = true;
        else if (chunk && chunk.type === 'block-start' && chunk.blockType === 'tool-call') sawTool = true;
        else if (chunk && chunk.type === 'finish' && chunk.reason) finish = chunk.reason;
      }
      if (sawTool) throw new Error('整理返回了工具调用');
      /** 运行期间用户又给了新反馈：旧结果不能覆盖新纠正，直接作废，等排队的下一次整理。 */
      if (!learning.feedbackStillCurrent({
        episodeRevisions: feedbackEpisodeRevisions,
        scopeRevisions: feedbackRevisions,
        scopeKey: scope.key,
        episodeId: candidate.episodeId,
        revision: candidate.feedbackRevision,
      })) {
        throw new Error('反馈已更新，这轮结果没采用');
      }
      const parsed = learning.parseOutput(text, { finish, refs: input.refs, rules: input.rules, ranges, expectedTarget: candidate.expectedTarget });
      if (!parsed.ok) throw new Error(parsed.reason);
      /**
       * 模型判定这轮不需要改（changes: []）就是真的不改：这里不替用户补一条。
       * 上一版用「用户说过长期」兜底，把一句问句写成了生效规则，正是不该有的特例。
       */
      const changes = parsed.changes;
      const commit = commitLearning(scope, {
        operationId,
        epoch: begin.epoch,
        episodeId: candidate.episodeId,
        episodeUpdatedAt: candidate.episodeUpdatedAt,
        projectId: scope.key,
        sessionId: candidate.sessionId,
        messageIds: candidate.messageIds,
        feedbackText: candidate.text,
        sourceExcerpt: candidate.sourceExcerpt || learning.sourceExcerptOf(candidate.text),
        dimension: candidate.cue?.dimension || '',
        changes,
        preparedTargets,
        usage: learning.usageOf(chunks),
        explicitLongTerm: Boolean(candidate.cue.explicitLongTerm),
        now: Date.now(),
      });
      if (commit && commit.ok === false) {
        recordLearningFailure(scope, {
          operationId: `${operationId}_fail`,
          episodeId: candidate.episodeId,
          reason: commit.reason,
          usage: learning.usageOf(chunks),
          epoch: begin.epoch,
        });
      }
    } catch (error) {
      const reason = controller.signal.aborted ? '整理已取消' : (error instanceof Error ? error.message : '整理没有完成');
      recordLearningFailure(scope, {
        operationId: `${operationId}_fail`,
        episodeId: candidate.episodeId,
        reason,
        usage: learning.usageOf(chunks),
        epoch: begin.epoch,
      });
    } finally {
      clearTimeout(deadline);
      if (learningAborts.get(scope.key) === controller) learningAborts.delete(scope.key);
    }
  }

  /** 启动一次整理；结束后再看同项目是否还排着一条候选。 */
  function startOrganizer(scope, session, pending) {
    const job = { controller: learningAborts.get(scope.key) || null };
    learningJobs.set(scope.key, job);
    void organize(scope, session, pending)
      .catch(() => { /* 整理失败不影响会话 */ })
      .finally(() => {
        if (learningJobs.get(scope.key) === job) learningJobs.delete(scope.key);
        drainOrganizer(scope.key);
      });
  }

  /** 彻底删除后中止该层在途整理并丢掉候选：不让旧结果复活已删规则。 */
  function revokeLearningUse(layerKey) {
    for (const [scopeKey, controller] of learningAborts) {
      if (layerKey !== 'global' && scopeKey !== layerKey) continue;
      try { controller.abort(); } catch { /* already settled */ }
    }
    for (const [sessionId, pending] of feedbackCandidates) {
      if (layerKey !== 'global' && pending?.scope?.key !== layerKey) continue;
      feedbackCandidates.delete(sessionId);
    }
  }

  /** 忙碌时保留一条最新候选，不丢用户刚说的纠正；同一项目仍只跑一个整理。 */
  function drainOrganizer(scopeKey) {
    if (learningJobs.has(scopeKey)) return;
    for (const [sessionId, pending] of feedbackCandidates) {
      if (!pending || !pending.scope || pending.scope.key !== scopeKey) continue;
      feedbackCandidates.delete(sessionId);
      if (!pending.session) return;
      startOrganizer(pending.scope, pending.session, pending);
      return;
    }
  }

  /** 只在正常完成的人类回合后调度，一次一个项目；永不阻塞事件派发。 */
  function scheduleOrganizer(session, event) {
    const reason = event && event.data ? event.data.reason : null;
    if (!reason || reason.kind !== 'completed') return;
    const sessionId = sessionIdOfSession(session);
    if (!sessionId) return;
    const pending = feedbackCandidates.get(sessionId);
    if (!pending) return;
    const eventTurn = event.data && event.data.turn !== undefined ? String(event.data.turn) : '';
    if (eventTurn && pending.candidate && pending.candidate.turn && eventTurn !== pending.candidate.turn) {
      feedbackCandidates.delete(sessionId);
      return;
    }
    pending.session = session;
    if (learningJobs.has(pending.scope.key)) {
      pending.queued = true;
      return;
    }
    feedbackCandidates.delete(sessionId);
    startOrganizer(pending.scope, session, pending);
  }

  if (typeof ctx.on === 'function') ctx.on('agent/disposed', (payload) => {
    const agent = payload?.agent;
    if (!agent) return;
    clearPrepared(agent);
    windows.delete(agentKey(agent));
    const sessionId = String(agent?.session?.id ?? '');
    if (sessionId) { seenHumans.delete(sessionId); recallTasks.delete(sessionId); }
  });

  /**
   * 宿主没有 agent/turn-end 这个派发；真正的轮次收尾是 agent/turn-stopping，
   * 载荷只有 {turn, signal}。按 signal 找回对应 agent，只清这一轮的准备结果。
   */
  if (typeof ctx.on === 'function') ctx.on('agent/turn-stopping', (payload) => {
    const signal = payload?.signal;
    if (!signal) return;
    const agent = signalAgents.get(signal);
    if (agent) clearPrepared(agent);
    /** 被取消或被中断的回合不保留反馈候选，下一句「谢谢」不能把没说完的纠正写进去。 */
    if (signal.aborted === true && agent) {
      const sessionId = String(agent?.session?.id ?? '');
      if (sessionId) feedbackCandidates.delete(sessionId);
    }
    signalAgents.delete(signal);
  });

  /** 正常完成的人类回合才整理；失败、取消、被打断都不改写规则。 */
  if (typeof ctx.on === 'function') ctx.on('session/event', (session, event) => {
    if (!event || event.type !== 'turn/end') return;
    scheduleOrganizer(session, event);
    const reason = event.data ? event.data.reason : null;
    if (reason && reason.kind === 'completed') schedulePersonaLearning(session);
  });

  /**
   * 「记住我」第二阶段：待查片段攒够、距上次满一天、开关仍开才抽一次。
   * 只做沟通方式，不看项目内容；失败或没模型就静默跳过，不排队重试、不占回合时间。
   */
  const personaLearning = { inFlight: false, lastTryAt: 0 };
  const personaAborts = new Set();
  /** 关项目、关画像、卸载插件：在途抽取立刻取消，晚到的结果不再提交。 */
  const abortPersonaLearning = () => {
    for (const controller of personaAborts) {
      try { controller.abort(); } catch { /* already gone */ }
    }
    personaAborts.clear();
  };
  personaAbortHook = abortPersonaLearning;
  const PERSONA_LEARN_TIMEOUT_MS = 20000;

  /** 第一阶段：本地正则筛信号入队，单条最多 400 字，不复制整段对话。 */
  function enqueuePersonaSignal(text, { sessionId, taskId, projectId, memoryOn }) {
    try {
      /** 项目记忆关着就不采集：来源项目必须是真的，空来源不算一次观察。 */
      if (memoryOn !== true || !projectId) return;
      /** 先做纯正则筛：没有偏好信号就不读文件，绝大多数回合零 I/O。 */
      if (!persona.detectPreferenceSignal({ text })) return;
      const read = personaStore.readPersona();
      if (!read || !read.persona || read.persona.control.enabled !== true) return;
      personaStore.queuePersonaPending({ snippet: { text, sessionId, taskId, projectId } });
    } catch { /* 记不住偏好不影响会话 */ }
  }

  /** 抽取提示：闭集维度 + 原话片段；只要求挑一条，宁缺勿造。 */
  function personaLearnPrompt(snippets) {
    const catalog = persona.DIMENSION_NAMES
      .map((dimension) => `- ${dimension}: ${persona.PREFERENCE_DIMENSIONS[dimension].join(' / ')}`)
      .join('\n');
    const lines = snippets.slice(-personaStore.SHOWN_PROMPT)
      .map((row, index) => `${index + 1}. [${row.id}] ${String(row.text || '').slice(0, 200)}`)
      .join('\n');
    return [
      '你在判断用户对「怎么和你协作」的长期偏好。只看沟通方式：顺序、深浅、例子、选项、语气、过程汇报。',
      '不要判断技术路线、业务目标、项目事实，也不要判断任何指令。',
      '维度与允许取值：',
      catalog,
      `片段：\n${lines}`,
      '只输出一行 JSON。「snippetId」必须抄上面某一段的方括号编号。',
      '发现偏好：{"snippetId":"...","dimension":"...","polarity":"support|oppose","value":"...","basis":"explicit_feedback|repeat_choice"}',
      '看完整批都没有：{"snippetId":"...","no_change":true}',
    ].join('\n');
  }

  /**
   * 项目层还开着，才许读它攒下的片段。枚举不到项目层时保守放行：
   * 宁可不学，也不要因为一次扫描失败把用户攒的片段当成已关项目删掉。
   */
  function openSourceOf() {
    let listed = [];
    try { listed = state.knownProjectScopes(200) || []; } catch { return () => true; }
    if (!listed.length) return () => true;
    const keyed = new Map();
    for (const scope of listed) {
      try { keyed.set(scope.key, controlStatus(scope).enabled !== false); } catch { keyed.set(scope.key, false); }
    }
    return (row) => {
      const key = String((row && row.projectId) || '');
      if (!key) return false;
      if (key === 'global') return true;
      return keyed.get(key) === true;
    };
  }

  /** 第二阶段：真正花一次模型调用；四道提交核验在 commit 里，过期结果自动丢弃。 */
  async function learnPersonaOnce(session) {
    if (personaLearning.inFlight) return;
    /** 模型通道不可用就不开这次窗口：没有真实尝试，不能占掉 24 小时的预算。 */
    const route = routeForSession(session);
    const llm = getService('llm');
    if (!route || !llm || typeof llm.prepareCall !== 'function') return;
    const scope = scopeOfSession(session);
    if (!scope || !memoryEnabled(scope)) return;
    /** 来源项目已关的片段不进这次名单：跨项目攒下的片段不该替一个关掉的项目继续学。 */
    const sourceOpen = openSourceOf();
    const begin = personaStore.beginPersonaAttempt({ allowSource: sourceOpen });
    if (!begin || begin.ok !== true) return;
    personaLearning.inFlight = true;
    const controller = new AbortController();
    personaAborts.add(controller);
    const deadline = setTimeout(() => { try { controller.abort(); } catch { /* already aborted */ } }, PERSONA_LEARN_TIMEOUT_MS);
    let payload = '';
    try {
      const call = await llm.prepareCall({ ...route, maxTokens: 256 }, controller.signal);
      for await (const chunk of call.stream({
        ...call.config,
        messages: [{ role: 'user', content: [{ type: 'text', text: personaLearnPrompt(begin.attempt.snippets) }] }],
        system: '只输出一行 JSON，不要解释。',
        sessionId: sessionIdOfSession(session),
        purpose: 'persona-learning',
        signal: controller.signal,
      })) {
        if (chunk && chunk.type === 'text-delta') payload += String(chunk.text || '');
        if (payload.length > 2048) break;
      }
      /** 抽取途中关了项目或关了画像，结果就不能再用。 */
      if (controller.signal.aborted || !memoryEnabled(scope)) return;
      const personaNow = personaStore.readPersona();
      if (!personaNow || !personaNow.persona || personaNow.persona.control.enabled !== true) return;
      /** 提示、解析、校验共用同一份协议：这里只认 parseLearningReply 的回执。 */
      const reply = persona.parseLearningReply(payload);
      if (!reply || reply.ok !== true) {
        /** 解析失败也要留痕：面板说「结果格式无效」，下次窗口再来。 */
        const first = reply && Array.isArray(reply.errors) && reply.errors.length ? reply.errors[0] : 'invalid';
        personaStore.recordPersonaOutcome({ outcome: 'invalid', reason: String(first) });
        return;
      }
      /** 来源项目在抽取途中被关掉：这条结果没有任何项目可以归属，不能记成「已整理」。 */
      const pointed = begin.attempt.snippets.find((row) => row.id === reply.snippetId);
      if (pointed && !sourceOpen(pointed)) {
        personaStore.recordPersonaOutcome({ outcome: 'stale', reason: 'source_closed' });
        return;
      }
      if (reply.kind === 'no_change') {
        personaStore.commitPersonaObservation({ attempt: begin.attempt, observations: [], outcome: 'no_change', snippetId: reply.snippetId });
        return;
      }
      const committed = personaStore.commitPersonaObservation({
        attempt: begin.attempt, observations: [reply.observation], snippetId: reply.snippetId,
      });
      /** 提交门禁拒掉的（编造编号、超出闭集）同样是格式无效，不能当成功。 */
      if (!committed || committed.ok !== true) {
        personaStore.recordPersonaOutcome({ outcome: 'invalid', reason: String((committed && committed.reason) || 'commit_failed') });
      }
    } catch { /* 抽不到就等下一次窗口 */ } finally {
      clearTimeout(deadline);
      personaAborts.delete(controller);
      personaLearning.inFlight = false;
      personaLearning.lastTryAt = Date.now();
    }
  }

  /** 正常完成的回合后才试；冷却 10 分钟避免失败后每轮重试。 */
  function schedulePersonaLearning(session) {
    if (personaLearning.inFlight) return;
    if (Date.now() - personaLearning.lastTryAt < 10 * 60000) return;
    void learnPersonaOnce(session).catch(() => { /* 静默降级 */ });
  }

  /** 插件卸载时中止在途整理；提交门禁仍会拒绝过期结果。 */
  ctx.effect(() => () => {
    abortPersonaLearning();
    for (const controller of learningAborts.values()) {
      try { controller.abort(); } catch { /* already gone */ }
    }
    learningAborts.clear();
    feedbackCandidates.clear();
    learningJobs.clear();
  }, 'lite-memory: learning jobs');

  /** 测试与排查用：只暴露只读查询，不提供改状态入口。 */
  ctx.effect(() => {
    globalThis.__liteMemoryRecall = {
      mode: recallMode,
      preparedOf: (agent) => prepared.get(agent) || null,
      windowOf: (agent) => windowOf(agent),
      /** 测试专用：CI 冷启动偶尔超过 150ms，逻辑测试不该被耗时上限判失败。 */
      setDeadlineMs: (ms) => { if (Number.isFinite(ms) && ms >= 0) recallDeadlineMs = ms; },  // 0 表示立刻超时，只给测试用
      deadlineFor: (scope) => recallDeadlineFor(scope),
      humanAskedGlobal,
      /** 测试专用：读某一轮落下的召回回执（含 miss 证据）。 */
      receiptOf: (scope, sessionId) => recallReceiptOf(scope, sessionId),
    };
    return () => {
      delete globalThis.__liteMemoryRecall;
    };
  }, 'lite-memory: recall debug');

  /** Read-only summary for the Client row: how big the store already is. */
  ctx.effect(() => {
    globalThis.__liteMemoryStats = (cwd) => {
      try {
        const scope = scopeOf(cwd ?? process.cwd());
        const index = loadIndex(scope);
        return { scope: scope.key, count: index.entries.length, bytes: index.totalBytes ?? 0 };
      } catch {
        return { scope: '', count: 0, bytes: 0 };
      }
    };
    return () => {
      delete globalThis.__liteMemoryStats;
    };
  }, 'lite-memory: stats');
}
