# 安装指南

## 前置条件

- DeepSeek Harness **0.2.0-rc.2**（`dsh` CLI）已安装，web profile 可用（`dsh web` 能启动）；使用插件 **0.1.5 或以上的适配版本**
- Node.js ≥ 20
- 一个企查查账号（用于在授权页登录授权；法律数据 MCP 需账号已开通法规/案例权限）

## 方式 A：npm 发布版（推荐给普通用户）

```bash
# 1) 安装插件到 profile（自动安装依赖并注册 bundle）
dsh plugin --profile web add qcc-dsh-mcp-legal-oauth

# 2) 重启 dsh web（Ctrl-C 停止后重新运行 dsh web）
#    注：声明了 dsh.bundle 的包会被 dsh plugin add 自动加入
#    ~/.dsh/profiles/web/package.json 的 dsh.profile.bundles；若未自动注册，
#    手动在该数组追加 "qcc-dsh-mcp-legal-oauth"（与 "@deepseek-ai/dsh-base" 等并列）后再重启
```

## 方式 B：GitHub 直装（未发 npm 时）

```bash
dsh plugin --profile web add github:duhu2000/qcc-mcp-legal-oauth
# 再执行方式 A 的第 2 步（重启）
```

## 方式 C：本地源码

```bash
git clone https://github.com/duhu2000/qcc-mcp-legal-oauth.git
cd qcc-mcp-legal-oauth
dsh plugin --profile web add "link:$(pwd)"
# 再执行方式 A 的第 2 步（重启）
```

## 验证安装

重启后，在对话中输入：

```
查看企查查法律数据连接状态
```

- 若返回「企查查法律数据 MCP 未连接。对我说"连接企查查法律数据"即可一键 OAuth 授权。」→ 安装成功
- 若提示找不到 `qcc_legal_oauth_status` 工具 → 检查 bundle 是否已注册、重启是否完成、日志是否有报错

## 升级 / 卸载

```bash
# 升级
dsh plugin --profile web update qcc-dsh-mcp-legal-oauth
# 卸载（先断开连接）
# 对话中执行 qcc_legal_oauth_disconnect，然后：
dsh plugin --profile web remove qcc-dsh-mcp-legal-oauth
# 并从 package.json 的 bundles 中移除该包名
```

## 常见问题

### 提示 0.1.4 与 DSH 0.2.0-rc.2 不兼容？

旧版插件声明 `@deepseek-ai/dsh-mcp-client: ^0.1.0-rc.6`，不包含 0.2.0-rc.2。请先停止 DSH，再安装修复版。

在本仓库目录执行（无需等待 npm 发布）：

```bash
npm pack
dsh plugin --profile web add ./qcc-dsh-mcp-legal-oauth-0.1.5.tgz
```

或在 0.1.5 发布后运行 `dsh plugin --profile web add qcc-dsh-mcp-legal-oauth@0.1.5`。完成后重启 `dsh web`。

### 如何运行完整开发测试？

```bash
npm install --ignore-scripts --legacy-peer-deps --no-package-lock
npm run lint
npm test
npm run verify-pack
```

开发依赖固定为 DSH 0.2.0-rc.2 对应的 Cordis、存储域等真实包；`--legacy-peer-deps` 仅用于此隔离测试环境，避免安装完整宿主。CI 设置 `QCC_REQUIRE_HOST_DEPS=1`，依赖加载失败时直接失败，防止插件集成测试被跳过。

### 安装后工具不出现？
1. 确认 `dsh plugin --profile web add` 成功（profile node_modules 里有 `qcc-dsh-mcp-legal-oauth`）；
2. 确认 `package.json` 的 `bundles` 包含包名；
3. 重启 web；
4. 查看启动日志中是否有 `qcc-legal-mcp-oauth` 相关报错。

### 授权页打不开？
- 检查 `openBrowser` 配置（默认 true）；false 时插件会打印授权 URL，可手动复制到浏览器打开。
- macOS/Linux/Windows 分别使用 `open` / `xdg-open` / `start`，如缺失请自行安装（Linux 常见）。

### 回调一直等不到？
- loopback 监听 `127.0.0.1:{随机端口}/callback`，请确认本机防火墙未拦截；
- 授权页提示「暂未完成授权」时，确认 `redirect_uri` 的协议/host/端口/路径与注册一致（插件每次授权重新注册客户端，通常不会出现）；
- 等待超时（默认 5 分钟）会自动报错，可重试。

### 连接后只有法规工具、没有案例工具？
- 法律数据 MCP 按账号实际开通范围授权：token 的 `resource` claim 同时含 `legal-regulation` + `legal-case` 时挂载 2 个，仅含 `legal-regulation` 时只挂载法规（1 个）。若需案例，请先在企查查开通法律数据案例权限，再 `qcc_legal_oauth_disconnect` 后重新连接。

### token 会过期吗？
- access_token 过期前插件自动刷新；refresh_token 轮换后旧值立即失效；
- `client_id` 默认 90 天有效，成功授权/刷新会自动续期；若长期未用被清理，重新执行"连接企查查法律数据"即可（会自动重新注册）。
