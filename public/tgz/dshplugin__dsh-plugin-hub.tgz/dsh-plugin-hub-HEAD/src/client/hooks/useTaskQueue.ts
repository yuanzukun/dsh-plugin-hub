/**
 * DSH Plugin Hub — the community plugin marketplace for DeepSeek Harness.
 * Website: https://dsh-plugin.org
 * GitHub: https://github.com/dshplugin/dsh-plugin-hub
 *
 * 插件中心的后台安装/卸载任务队列。
 *
 * 通过轮询 /active 镜像服务端 FIFO 活动队列，对消失的任务用 /status 收尾，并暴露
 * 队列动作（安装、卸载、取消）以及弹窗用的任务查找。
 */
import { useEffect, useRef, useState } from 'react'
import type { HubPlugin, InstallChannel, LocaleId, Translate } from '../types.ts'
import { executedCommandOf, installCommandOf, installTargetOf, repoFromInstallTarget } from '../logic/install-command.ts'
import type { InstalledItem } from '../logic/installed.ts'

/** 安装/卸载请求超时（ms）：服务端入队前要做目录包校验与网络探测（各自有超时，合计可达十几秒），
 *  给足余量；超时主动中止，避免服务端网络挂起时前端永久卡「安装中 0%」。 */
const REQUEST_TIMEOUT_MS = 60_000

/** 客户端任务队列项：镜像服务端 active 任务（running 在前、pending 在后）。 */
export interface QueueTask {
  id: number
  kind: 'install' | 'uninstall'
  /** 展示目标：owner/repo（安装）或 npm 包名（卸载） */
  target: string
  /** 插件中文简介（入队时从插件数据带过来，轮询合并时保留）：展示在仓库名下方，标识排队中的插件 */
  desc?: string
  /** 所属插件仓库（owner/repo）：失败时错误弹窗据此提供「去仓库反馈」入口；卸载为 null */
  repo: string | null
  /** 自定义安装入口渠道（NPM 包卡片）：失败时错误/通知精准溯源「从哪个入口发起」；
   *  目录插件安装无此字段（非自定义入口）。 */
  channel?: InstallChannel
  /** 实际动作（add/update/remove）：成功通知据此区分「安装成功」与「更新成功」。
   *  服务端 /active 带回真实动作；本地乐观入队按 update 标记推断。 */
  action?: 'add' | 'update' | 'remove'
  /** 安装时的目录信号快照（版本 + 仓库更新时间）：任务成功后在本地记录，供「有更新」比对 */
  version?: string
  updatedAt?: string
  /** 服务端在成功终态带出的**实际**安装版本（读 profile 的 node_modules）：优先于目录版本写账本 */
  installedVersion?: string
  /** pending 排队中 / running 执行中 / cancelling 取消中（客户端乐观过渡态） */
  status: 'pending' | 'running' | 'cancelling'
  progress: number
  lines: string[]
  /** 乐观入队条目：点击安装后立即显示「正在安装中」，等 POST 响应回来再换成真实任务 id。
   *  服务端还没登记，轮询合并/消失检测都必须跳过，避免被当作已结束任务收尾。 */
  optimistic?: boolean
  /** 实际执行的安装命令（随插件数据决定）：失败时 issue 预填如实展示 */
  command?: string
  /** 实际执行/重试过的安装命令（按先后顺序）：失败时 issue 预填一并贴给作者 */
  attempts?: string[]
  /** 完成结果是否需要重启才生效（服务端任务终态带出）。默认 true 保底：数据缺失时不静默视为已生效。
   *  仅刷新解决不了的兜底场景（热挂载失败 / 非 dsh 插件 / 更新）为 true，结果视图给「立即重启」；
   *  其余（热挂载成功、卸载已即时停用、全局安装）为 false，结果视图仅「完成」。 */
  needsRestart: boolean
  /** 完成结果是否只需刷新页面即生效（插件已热挂进运行中 loader，或卸载后插件面板仍残留在当前页面）：
   *  true 时关闭结果弹窗 / Toast 消失后由上层自动刷新页面，不给手动刷新按钮。 */
  needsReload?: boolean
  /** 市场自更新成功、但 profile 的 bundle 列表里已不含 dsh-plugin：重启后市场不会出现 */
  bundleDeselected?: boolean
}

/** 客户端待重启项：镜像服务端内存列表 + 本地补齐的展示信息（简介/版本）。 */
export interface PendingRestart {
  /** owner/repo（展示用，已从安装目标归一化） */
  target: string
  /** 待重启语义：install 装完等挂载 / uninstall 卸完等清理 */
  kind: 'install' | 'uninstall'
  at: number
  desc?: string
  version?: string
}

export interface TaskQueueOptions {
  t: Translate
  /** 界面语言（zh/en）：随安装请求带给服务端，安装前网络探测等错误消息按用户语言提示 */
  langKey?: LocaleId
  refreshInstalled: () => void
  /** 任务成功完成：viaModal 表示任务对应当前打开弹窗（弹窗切结果视图），否则走 Toast；repo 供成功通知记录；
   *  needsRestart 表示该任务完成后是否仍需宿主重启（结果视图据此给「重启 / 仅完成」）；
   *  needsReload 表示是否只需刷新页面即生效（热挂载成功、或卸载后插件面板仍残留）。
   *  update 表示实际执行的是更新（覆盖重装）而非首次安装：通知中心据此显示「更新成功」而非「安装成功」。 */
  onInstallDone: (viaModal: boolean, repo: string | null, needsRestart: boolean, update?: boolean, needsReload?: boolean, bundleDeselected?: boolean) => void
  onUninstallDone: (viaModal: boolean, repo: string | null, needsRestart: boolean, needsReload?: boolean) => void
  /** 任务失败：完整输出或兜底文案 + 所属插件仓库 + 操作类型（安装/卸载）+ 实际执行的安装命令（issue 预填用，可缺省）+ 实际执行/重试过的安装命令（可缺省）+ 是否更新。 */
  onError: (message: string, repo: string | null, kind: 'install' | 'uninstall', command?: string, attempts?: string[], update?: boolean) => void
  /** 当前打开的安装/卸载弹窗插件：用于在弹窗内匹配进行中的任务。 */
  installPlugin: HubPlugin | null
  /** 当前打开的自定义安装（命令行）确认弹窗目标：与应用商店同一弹窗机制，匹配进行中的 custom 安装任务。 */
  installCustomTarget?: string | null
  /** 当前打开的全局 npm 安装（`npm install -g <pkgs>`）确认弹窗身份（包列表空格拼接）：
   *  匹配服务端登记的全局安装任务（target = 包列表 join(' ')）。 */
  installGlobalTarget?: string | null
  uninstallPlugin: HubPlugin | null
  /** 已安装视图发起的卸载目标（npm 包名）：目录插件走 uninstallPlugin，自定义安装走包名直卸。 */
  uninstallName: string | null
  installedName: (p: HubPlugin) => string | null
  /** 待重启项展示信息补齐：按 owner/repo 从插件目录解析简介/版本；找不到返回 null。 */
  resolvePending: (repo: string) => { desc?: string; version?: string } | null
}

/** 失败消息的入口溯源前缀：自定义安装（带渠道）在错误正文顶部精准指出从哪张卡片发起；
 *  目录插件安装（无渠道）返回 null，错误正文保持原样。 */
const entryLineOf = (t: Translate, channel: InstallChannel | undefined): string | null =>
  channel ? t('installEntryLine', { c: t('installChannelNpm') }) : null

export function useTaskQueue(opts: TaskQueueOptions) {
  const {
    t, langKey, refreshInstalled, onInstallDone, onUninstallDone, onError,
    installPlugin, installCustomTarget, installGlobalTarget, uninstallPlugin, uninstallName, installedName, resolvePending,
  } = opts
  const [queue, setQueue] = useState<QueueTask[]>([])
  const queueRef = useRef<QueueTask[]>([])
  /** 待重启列表（服务端内存态 + 本地展示信息补齐）；与 queue 一样以 ref 为唯一事实来源。 */
  const [pendingRestarts, setPendingRestarts] = useState<PendingRestart[]>([])
  const pendingRef = useRef<PendingRestart[]>([])
  /** 本次会话内安装成功插件的展示信息（目标 → 简介/版本）：轮询合并待重启列表时补齐，刷新后由 resolvePending 兜底。 */
  const pendingInfoRef = useRef<Map<string, { desc?: string; version?: string }>>(new Map())
  /** 保持最新的 resolvePending：轮询闭包捕获的是调用那一刻的目录状态，目录晚加载时也能补齐。 */
  const resolvePendingRef = useRef(resolvePending)
  resolvePendingRef.current = resolvePending
  /** 当前打开弹窗所对应的任务 id：该任务完成时弹窗切换为结果视图 */
  const modalTaskRef = useRef<number | null>(null)
  /** 已开始收尾但尚未结束的任务 id（服务端 /active 已消失 → 查 /status 中）：并发轮询时跳过，避免重复收尾 */
  const settlingRef = useRef<Set<number>>(new Set())
  /** 轮询定时器句柄（队列清空/组件卸载时清理） */
  const pollRef = useRef<number | null>(null)
  /** 请求在途的目标集合（同步防重）：双击安装/卸载时第二击直接忽略。
   *  本地队列任务要等 fetch 返回后才入队，仅靠 queueRef 检查拦不住请求窗口内的重复点击。 */
  const submittingRef = useRef<Set<string>>(new Set())
  /** 乐观入队临时 id 计数器：递减产生唯一负数，与服务端自增正数 id 永不冲突。 */
  const tempIdRef = useRef(0)
  /** 请求在途标记：弹窗据此禁用确认按钮，避免等待响应期间被再次点击。 */
  const [submitting, setSubmitting] = useState(false)

  /** 停止后台任务轮询（任务结束或组件卸载时清理）。 */
  const stopPoll = () => {
    if (pollRef.current !== null) {
      window.clearInterval(pollRef.current)
      pollRef.current = null
    }
  }

  /** 队列与待重启都清空才停轮询：待重启期间持续轮询，宿主一重启（内存列表清空）立刻感知并消失。 */
  const maybeStopPoll = () => {
    if (queueRef.current.length === 0 && pendingRef.current.length === 0) stopPoll()
  }

  // 组件卸载时兜底清理轮询定时器
  useEffect(() => stopPoll, [])

  /** 更新队列（同步镜像到 ref：queueRef 是唯一事实来源，state 只负责触发渲染，
   *  避免依赖 React updater 的异步调度时序导致 gone/stopPoll/防重复入队读到旧值）。 */
  const applyQueue = (updater: (prev: QueueTask[]) => QueueTask[]) => {
    const next = updater(queueRef.current)
    queueRef.current = next
    setQueue(next)
  }

  /** 解析服务端待重启列表（安装目标归一化为 owner/repo，与安装任务对齐）。 */
  const parsePendingRestarts = (value: unknown): PendingRestart[] => {
    if (!Array.isArray(value)) return []
    const out: PendingRestart[] = []
    for (const x of value) {
      if (typeof x !== 'object' || x === null) continue
      const target = (x as { target?: unknown }).target
      if (typeof target !== 'string' || target === '') continue
      const at = (x as { at?: unknown }).at
      out.push({
        target: repoFromInstallTarget(target),
        kind: (x as { kind?: unknown }).kind === 'uninstall' ? 'uninstall' : 'install',
        at: typeof at === 'number' ? at : 0,
      })
    }
    return out
  }

  /** 合并服务端待重启列表：保留已有展示信息，缺失时用会话内记录 / 目录解析补齐。 */
  const applyPending = (raw: PendingRestart[]) => {
    const prev = pendingRef.current
    const next = raw.map((p) => {
      const old = prev.find((q) => q.target === p.target)
      if (old?.desc !== undefined) return { ...p, desc: old.desc, version: old.version }
      const info = pendingInfoRef.current.get(p.target) ?? resolvePendingRef.current?.(p.target) ?? null
      return info ? { ...p, desc: info.desc, version: info.version } : p
    })
    pendingRef.current = next
    setPendingRestarts(next)
  }

  /** 向宿主记录某插件的安装时目录信号（version + updatedAt）。
   *  版本未知时**不写**：服务端把空版本当作「卸载清理」会删掉整条记录（连 npm 包名映射一起），
   *  刷新页面后任务丢了快照就会走到这条路径 —— 宁可保留旧记录，也不能把账本清空。 */
  const syncInstalledVersion = async (repo: string | null, version: string | undefined, updatedAt: string | undefined) => {
    if (!repo || version === undefined || version === '') return
    try {
      await fetch('/dsh-plugin-hub/installed-version', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ repo, version, updatedAt }),
      })
    } catch {
      // 宿主未挂本地路由：静默忽略，仅本机展示受影响
    }
  }

  /** 清除某仓库的版本记录（卸载成功后调用）：空版本是服务端的「删除记录」语义，只在这里显式发送。 */
  const clearInstalledVersion = async (repo: string | null) => {
    if (!repo) return
    try {
      await fetch('/dsh-plugin-hub/installed-version', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ repo, version: null }),
      })
    } catch {
      // 同上：清理失败不影响卸载结果
    }
  }

  /** 后台任务结束（active 中消失后查终态确认）：完成 → 刷新安装表 + 结果视图/toast；失败 → 完整错误弹窗 */
  const finishQueueTask = (ok: boolean, q: QueueTask, lines: string[]) => {
    applyQueue((prev) => prev.filter((x) => x.id !== q.id))
    if (ok) {
      refreshInstalled()
      if (q.kind === 'uninstall') {
        // 卸载成功：清掉本地版本记录
        void clearInstalledVersion(q.repo)
        onUninstallDone(modalTaskRef.current === q.id, q.repo, q.needsRestart, q.needsReload ?? false)
      } else {
        // 安装成功：记录安装时的目录信号（版本 + 仓库更新时间），供「有更新」比对；
        // 同时缓存展示信息，待重启列表（服务端已登记）合并时直接补齐简介/版本
        // 账本记**实际装上的版本**：目录版本可能滞后，抄目录字段会让「有更新」永久失真
        const recordedVersion = q.installedVersion ?? q.version
        void syncInstalledVersion(q.repo, recordedVersion, q.updatedAt)
        pendingInfoRef.current.set(q.target, { desc: q.desc, version: recordedVersion })
        onInstallDone(modalTaskRef.current === q.id, q.repo, q.needsRestart, q.action === 'update', q.needsReload ?? false, q.bundleDeselected === true)
      }
    } else {
      // 失败：完整展示全部输出行（最新在前，逆序为日志阅读顺序），不裁剪
      const rawDetail = lines.length > 0
        ? [...lines].reverse().join('\n')
        : q.kind === 'uninstall' ? t('uninstallFail') : t('installFail')
      // 自定义安装（带入口渠道）：错误正文顶部精准提示「从哪张卡片发起」，目录安装保持原样
      const entry = entryLineOf(t, q.channel)
      onError(entry ? `${entry}\n${rawDetail}` : rawDetail, q.repo, q.kind, executedCommandOf(q.command, q.attempts), q.attempts, q.action === 'update')
    }
    maybeStopPoll()
  }

  /** 卸载成功收尾前的进度过渡：任务已在服务端结束，但保留本地展示，
   *  让进度条在 ~2.4s 内缓缓跑到 100% 再切结果/Toast，给用户一个交互过程，
   *  而不是命令一执行进度条就一闪消失。 */
  const settleDone = (q: QueueTask, lines: string[]) => {
    // 收尾动画期间停止轮询：任务已从服务端 /active 消失，无需再查；
    // 停掉可避免 pollQueue 的 gone 检测把它当「再消失一次」而重复收尾
    stopPoll()
    const from = Math.min(q.progress, 90) // 起点最多 90，给进度条留出跑满的缓冲空间
    const steps = 20
    const stepMs = 120 // 20 步 × 120ms = 2.4s
    let step = 0
    // 动画期间固定显示「卸载中」：任务实已结束，但进度在跑，与「排队中」文案更协调
    applyQueue((prev) => prev.map((x) => (x.id === q.id ? { ...x, status: 'running' as const } : x)))
    const timer = window.setInterval(() => {
      step += 1
      const progress = Math.round(from + (100 - from) * (step / steps))
      applyQueue((prev) => prev.map((x) => (x.id === q.id ? { ...x, progress } : x)))
      if (step >= steps) {
        window.clearInterval(timer)
        finishQueueTask(true, q, lines)
        // 队列若还有其它已在排队/执行的任务，恢复轮询继续盯；已清空则自然停住
        if (queueRef.current.length > 0) pollQueue()
      }
    }, stepMs)
  }

  /** 任务在 /active 中消失 = 已结束：查 /status 拿终态并收尾（cancelled 静默移除）。 */
  const settleTask = async (q: QueueTask) => {
    let status = 'failed'
    let lines: string[] = []
    let attempts: string[] | undefined
    let bundleDeselected: boolean | undefined
    let installedVersion: string | undefined
    try {
      const res = await fetch(`/dsh-plugin-hub/status?task=${q.id}`, { cache: 'no-store' })
      if (res.ok) {
        const data = await res.json() as { task?: { status?: string; lines?: string[]; attempts?: string[]; needsRestart?: unknown; needsReload?: unknown; bundleDeselected?: unknown; installedVersion?: unknown } }
        const task = data.task
        if (task !== undefined) {
          status = task.status ?? 'failed'
          lines = task.lines ?? []
          attempts = Array.isArray(task.attempts) ? task.attempts : undefined
          bundleDeselected = task.bundleDeselected === true ? true : undefined
          installedVersion = typeof task.installedVersion === 'string' && task.installedVersion !== '' ? task.installedVersion : undefined
          // 终态带出的「是否需要重启 / 是否只需刷新」覆盖本地（服务端 done 时按 loader 热挂/即时移除情况设置）
          const needsRestart = typeof task.needsRestart === 'boolean' ? task.needsRestart : q.needsRestart
          const needsReload = typeof task.needsReload === 'boolean' ? task.needsReload : (q.needsReload ?? false)
          if (status === 'done') {
            const settled = { ...q, needsRestart, needsReload, bundleDeselected: bundleDeselected === true ? true : q.bundleDeselected, installedVersion }
            // 卸载成功走进度过渡动画；安装成功直接收尾
            if (q.kind === 'uninstall') settleDone(settled, lines)
            else finishQueueTask(true, settled, lines)
            return
          }
          if (status === 'failed') {
            // 服务端终态带出的尝试记录覆盖本地：以实际执行为准
            finishQueueTask(false, { ...q, attempts }, lines)
            return
          }
        }
      }
    } catch { /* 服务端不可达：按失败处理 */ }
    applyQueue((prev) => prev.filter((x) => x.id !== q.id)) // cancelled / 未知
    maybeStopPoll()
  }

  /** 轮询整个队列：合并服务端 /active（running 在前、pending 在后），
   *  消失的任务查终态收尾；队列清空即停止轮询。 */
  const pollQueue = () => {
    stopPoll()
    pollRef.current = window.setInterval(async () => {
      try {
        const res = await fetch('/dsh-plugin-hub/active', { cache: 'no-store' })
        if (!res.ok) throw new Error(`active ${res.status}`)
        const data = await res.json() as {
          tasks?: { id?: unknown; action?: unknown; target?: unknown; status?: unknown; progress?: unknown; lines?: unknown; attempts?: unknown; needsRestart?: unknown; installChannel?: unknown; bundleDeselected?: unknown }[]
          pendingRestarts?: unknown
        }
        const active = (data.tasks ?? []).filter((a) => typeof a.id === 'number')
        const byId = new Map(active.map((a) => [a.id as number, a]))
        // 先捕获旧队列：gone 是「旧队列里服务端已消失的任务」的差集，必须在 applyQueue 更新前取
        const prevQueue = queueRef.current
        // 待重启列表同步（服务端内存态：宿主重启后自然变空，这里随之清空 UI）
        applyPending(parsePendingRestarts(data.pendingRestarts))
        // 合并：running 在前、pending 在后（与服务端一致），新出现任务补入队列
          applyQueue((prev) => {
            const next: QueueTask[] = []
            for (const a of active) {
              const id = a.id as number
              const prevTask = prev.find((q) => q.id === id)
              const isRemove = a.action === 'remove'
              next.push({
                id,
                kind: isRemove ? 'uninstall' : 'install',
                target: typeof a.target === 'string' ? repoFromInstallTarget(a.target) : (prevTask?.target ?? ''),
                desc: prevTask?.desc,
                repo: prevTask?.repo ?? (isRemove ? null : (typeof a.target === 'string' ? repoFromInstallTarget(a.target) : null)),
                // 安装时快照的目录信号：轮询合并时保留，任务成功后记录到本地
                version: prevTask?.version,
                updatedAt: prevTask?.updatedAt,
                status: a.status === 'running' ? 'running' : 'pending',
                progress: typeof a.progress === 'number' ? a.progress : prevTask?.progress ?? 0,
                lines: Array.isArray(a.lines) ? (a.lines as string[]) : (prevTask?.lines ?? []),
                attempts: Array.isArray(a.attempts) ? (a.attempts as string[]) : (prevTask?.attempts ?? []),
                needsRestart: typeof a.needsRestart === 'boolean' ? a.needsRestart : (prevTask?.needsRestart ?? true),
                bundleDeselected: a.bundleDeselected === true || prevTask?.bundleDeselected === true,
                // 入口渠道：本地乐观入队已带；服务端 /active 也带回（刷新恢复用），服务端优先。
                // 旧服务端可能回传已废弃的 'git'/'dsh' 渠道，忽略即可、回退本地值。
                channel: a.installChannel === 'npm' ? 'npm' : prevTask?.channel,
              })
            }
            // 保留乐观条目：服务端尚未登记，无真实 id，不能因 active 缺它就被合并吞掉
            const keepOpt = prev.filter((q) => q.optimistic && !next.some((x) => x.id === q.id))
            if (keepOpt.length > 0) next.push(...keepOpt)
            // 保留「已从服务端消失、但尚未收尾」的任务：收尾（settleTask）负责移除。
            // 若在这里提前摘除，卸载/安装完成的那一瞬队列会先变空，弹窗闪回「确认」态
            // （busy=false 且未 done），表现为「卸载中 → 卸载 → 卸载完成」的中间回退。
            const keepGone = prev.filter((q) =>
              !byId.has(q.id) && !next.some((x) => x.id === q.id) && q.status !== 'cancelling' && !q.optimistic)
            if (keepGone.length > 0) next.push(...keepGone)
            return next
          })
          // 本地有、服务端已消失 → 已结束：逐个查终态收尾
          // （cancelling 是客户端乐观过渡态，交给 cancelTask 的定时移除，不在轮询里提前收敛；
          //   optimistic 是点击后尚未登记的占位，服务端 /status 查不到，跳过免误判成失败；
          //   settling 是上一轮已开始收尾的任务，并发轮询直接跳过，避免重复收尾）
          const gone = prevQueue.filter((q) =>
            !byId.has(q.id) && q.status !== 'cancelling' && !q.optimistic && !settlingRef.current.has(q.id))
        for (const q of gone) {
          // 防御：同 id 任务可能已被上一轮收尾移除（极端时序下轮询合并出的重复条目），跳过避免重复收尾
          if (!queueRef.current.some((x) => x.id === q.id)) continue
          settlingRef.current.add(q.id)
          try { await settleTask(q) } finally { settlingRef.current.delete(q.id) }
        }
      } catch {
        // 服务端暂不可达：静默等待下一轮
      }
    }, 600)
  }

  // 刷新后恢复任务队列与待重启列表：任务注册表在服务端内存里，只要宿主进程没重启就还在；
  // 重新拉取 /active（数组）继续轮询，界面上显示「进行中」状态条，可展开查看实时输出。
  useEffect(() => {
    let cancelled = false
    const restore = async () => {
      try {
        const res = await fetch('/dsh-plugin-hub/active', { cache: 'no-store' })
        if (!res.ok) return
        const data = await res.json() as {
          tasks?: { id?: unknown; action?: unknown; target?: unknown; status?: unknown; progress?: unknown; lines?: unknown; attempts?: unknown; needsRestart?: unknown; displayTarget?: unknown; installChannel?: unknown }[]
          pendingRestarts?: unknown
        }
        if (cancelled) return
        // 待重启：装完没重启的持久提醒，刷新页面也要恢复
        applyPending(parsePendingRestarts(data.pendingRestarts))
        const items: QueueTask[] = (data.tasks ?? [])
          .filter((a) => typeof a.id === 'number')
          .map((a) => {
            const isRemove = a.action === 'remove'
            // 服务端任务的 target：显式 HTTPS Git URL（安装）/ npm 包名（npm 安装/卸载）。
            // 恢复展示统一用 displayTarget（owner/repo，服务端固定传）：npm 安装时 target 是包名，
            // 直接展示会让用户看到「安装方式」的内部细节，违背无感知原则；卸载保持包名（匹配已装表）。
            const display = typeof (a as { displayTarget?: unknown }).displayTarget === 'string' ? repoFromInstallTarget((a as { displayTarget: string }).displayTarget) : ''
            const fallback = typeof a.target === 'string' ? repoFromInstallTarget(a.target) : ''
            return {
              id: a.id as number,
              kind: (isRemove ? 'uninstall' : 'install') as 'install' | 'uninstall',
              target: isRemove ? fallback : (display || fallback),
              repo: isRemove ? null : (display || fallback),
              action: (a.action === 'add' || a.action === 'update' || a.action === 'remove') ? a.action : 'add',
              status: a.status === 'running' ? 'running' : 'pending',
              progress: typeof a.progress === 'number' ? a.progress : 0,
              lines: Array.isArray(a.lines) ? (a.lines as string[]) : [],
              attempts: Array.isArray((a as { attempts?: unknown }).attempts) ? ((a as { attempts: string[] }).attempts) : [],
              needsRestart: typeof (a as { needsRestart?: unknown }).needsRestart === 'boolean' ? (a as { needsRestart: boolean }).needsRestart : true,
              // 服务端登记的入口渠道：自定义安装刷新后也能精准溯源（目录安装无此字段）。
              // 旧服务端可能回传已废弃的 'git'/'dsh' 渠道，忽略即可。
              channel: a.installChannel === 'npm' ? 'npm' : undefined,
            }
          })
        if (items.length > 0 || pendingRef.current.length > 0) {
          applyQueue((prev) => [...prev, ...items.filter((n) => !prev.some((p) => p.id === n.id))])
          // 刷新后恢复的任务同样保持折叠：摘要条提示进行中，点开才看明细/日志
          pollQueue()
        }
      } catch { /* 宿主未挂本插件服务端路由 */ }
    }
    void restore()
    return () => { cancelled = true }
  }, [])

  /** 弹窗动作：直接安装。请求宿主本地路由，任务进入服务端队列（FIFO），弹窗内实时显示进度。 */
  /** 安装入队核心：目录插件（catalog，后端走目录白名单）与命令行安装（custom，
   *  受安全开关控制）共用。队列条目一律用仓库名（repo）展示/防重，只有发给后端的
   *  实际安装目标（target）为 npm 包名。 */
  const submitInstall = async (input: {
    /** 发给后端的实际安装目标：npm 包名 */
    target: string
    /** 队列展示与防重用的仓库名 */
    repo: string
    desc?: string
    version?: string
    updatedAt?: string
    command: string
    source: 'catalog' | 'custom'
    /** 更新已安装目标（放行 add 覆盖重装） */
    update?: boolean
    /** 钉住精确版本（Hub 自我更新用）：最新版可能仍在 pnpm 供应链门禁内，
     *  必须安装「已过门禁」的那个版本，不能再用 @latest。 */
    pinVersion?: string
    /** 全局 npm 安装包列表（`npm install -g <pkgs>`）：非空时服务端执行全局安装，不进任何 profile */
    globalNpm?: string[]
    /** 自定义安装入口渠道（NPM 包卡片）：随请求上报服务端落日志，
     *  失败弹窗/通知据此精准溯源「从哪个入口发起」；目录安装不传。 */
    channel?: InstallChannel
  }) => {
    // 防重复入队：同一目标已在排队/执行中则忽略
    if (queueRef.current.some((q) => q.kind === 'install' && q.target === input.repo)) return
    // 请求在途防重：任务要等响应回来才进本地队列，这之前再次点击（双击）直接忽略
    if (submittingRef.current.has(input.repo)) return
    submittingRef.current.add(input.repo)
    // 乐观入队：点击安装立即显示「正在安装中」，不等 POST 响应。
    // 服务端 /install 会先做校验与网络探测再入队，若等响应才入队列，
    // 用户点完安装立刻去看任务会看不到 —— 只有刷新后 restore 才拉回来。
    // 用负临时 id 占位，响应回来换成真实 task id；失败/出错则移除该占位。
    tempIdRef.current -= 1
    const tempId = tempIdRef.current
    modalTaskRef.current = tempId
    applyQueue((prev) => [...prev, {
      id: tempId, kind: 'install', target: input.repo, repo: input.repo, desc: input.desc,
      version: input.version, updatedAt: input.updatedAt,
      status: 'running', progress: 0, lines: [], optimistic: true,
      command: input.command,
      channel: input.channel,
      action: input.update ? 'update' : 'add',
      // 服务端登记后 /active 会带回真实执行过的命令，先占位空列表
      attempts: [], needsRestart: true,
    }])
    setSubmitting(true)
    const controller = new AbortController()
    const timeout = window.setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS)
    try {
      const res = await fetch('/dsh-plugin-hub/install', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({
          repo: input.target,
          display: input.repo,
          source: input.source,
          mode: input.update ? 'update' : undefined,
          // 钉住版本（Hub 自我更新）：服务端据此执行 `add <pkg>@<version>` 而不是 @latest
          ...(input.pinVersion ? { version: input.pinVersion } : {}),
          // 界面语言带给服务端：安装前网络探测等错误消息按用户当前语言返回（中文界面给中文，英文界面给英文）
          ...(langKey ? { lang: langKey } : {}),
          // 安装入口渠道（只可能是 npm）：服务端日志/报错提示据此溯源
          ...(input.channel ? { installChannel: input.channel } : {}),
          ...(input.globalNpm && input.globalNpm.length > 0 ? { globalNpm: input.globalNpm } : {}),
        }),
        signal: controller.signal,
      })
      const data = await res.json() as { ok?: boolean; task?: number; error?: string; attempts?: string[] }
      if (!data.ok || typeof data.task !== 'number') {
        // 请求层失败（重复安装 409 / 参数错误 / 安全开关 403 等）：移除乐观条目 + 完整错误弹窗
        applyQueue((prev) => prev.filter((x) => x.id !== tempId))
        // 同步 400（如安装前网络探测拦截）服务端会附上已尝试的安装方式，issue 预填一并展示；
        // 用 || 而非 ?? ：error 为空字符串时回退 HTTP 状态，避免复制出来是空白。
        // 自定义安装（带入口渠道）：错误正文顶部精准提示「从哪张卡片发起」
        const entry = entryLineOf(t, input.channel)
        const msg = data.error || `HTTP ${res.status}`
        onError(entry ? `${entry}\n${msg}` : msg, input.repo, 'install', input.command, data.attempts)
        return
      }
      const taskId = data.task
      modalTaskRef.current = taskId
      // 用真实任务 id 替换乐观占位，解除 optimistic 标记（此后归正常收尾/轮询处理）
      applyQueue((prev) => prev.map((x) => (x.id === tempId
        ? { ...x, id: taskId, optimistic: undefined }
        : x)))
      // 提前缓存展示信息：安装成功后服务端登记待重启，轮询合并时不用等目录解析
      pendingInfoRef.current.set(input.repo, { desc: input.desc, version: input.version })
      // 摘要条常驻顶部（含实时进度），明细面板保持折叠，想看时再点开
      pollQueue()
    } catch (err) {
      // 网络异常：移除乐观条目 + 兜底错误弹窗（附上底层原因，避免只剩一句笼统的「安装失败」）
      applyQueue((prev) => prev.filter((x) => x.id !== tempId))
      const aborted = (err as { name?: string } | null)?.name === 'AbortError'
      // [request-timeout]：给分类器一个与界面语言无关的超时标记
      const reason = aborted
        ? `${t('requestTimeout')}\n[request-timeout]`
        : err instanceof Error && err.message ? err.message : String(err ?? '')
      // 自定义安装（带入口渠道）：错误正文顶部精准提示「从哪张卡片发起」
      const entry = entryLineOf(t, input.channel)
      const msg = reason ? `${t('installFail')} — ${reason}` : t('installFail')
      onError(entry ? `${entry}\n${msg}` : msg, input.repo, 'install', input.command)
    } finally {
      window.clearTimeout(timeout)
      submittingRef.current.delete(input.repo)
      setSubmitting(false)
    }
  }

  /** 目录插件安装：安装目标取目录数据的 npm 包名，走 catalog 白名单。 */
  const installNow = async (p: HubPlugin, opts?: { update?: boolean; pinVersion?: string }) => {
    const repo = p.source?.repo ?? ''
    if (!repo) return
    // 目录条目必带 npm 包名：直接用包名安装（用户无感知）。
    const target = installTargetOf(p)
    if (!target) return
    await submitInstall({
      target,
      repo,
      desc: p.description,
      version: p.version,
      updatedAt: p.dates?.repoUpdatedAt,
      command: installCommandOf(p, true),
      source: 'catalog',
      update: opts?.update,
      pinVersion: opts?.pinVersion,
    })
  }

  /** 命令行安装：用户手输 npm 包名，走 custom 源（受安全开关控制）。
   *  update=true 时对已安装目标放行覆盖重装（与目录插件「更新」同一语义）。
   *  channel=入口渠道（NPM 包卡片）：上报服务端落日志，失败弹窗/通知据此精准溯源。
   *  队列展示/防重一律用归一化身份：与服务端 /active 合并、弹窗目标匹配同口径，
   *  npm 包名透传不受影响。 */
  const installCustom = async (raw: string, opts?: { update?: boolean; channel?: InstallChannel }) => {
    const target = raw.trim()
    if (!target) return
    const repo = repoFromInstallTarget(target)
    await submitInstall({
      target,
      repo,
      command: `pnpm add ${target}`,
      source: 'custom',
      update: opts?.update,
      channel: opts?.channel,
    })
  }

  /** 全局 npm 安装（官方 README 的 `npm install -g <pkgs>`）：不进任何 profile、无需宿主重启。
   *  队列展示/防重用包列表空格拼接的身份（与服务端 target 同口径）；入口渠道固定为 npm（NPM 包卡片）。 */
  const installGlobalNpm = async (pkgs: string[], opts?: { update?: boolean; channel?: InstallChannel }) => {
    const list = (pkgs ?? []).map((p) => p.trim()).filter((p) => p !== '')
    if (list.length === 0) return
    const identity = list.join(' ')
    await submitInstall({
      target: identity,
      repo: identity,
      command: `npm install -g ${identity}`,
      source: 'custom',
      globalNpm: list,
      update: opts?.update,
      channel: opts?.channel ?? 'npm',
    })
  }

  /** 卸载入队核心：按 npm 包名直卸（目录插件与自定义安装共用，弹窗进度匹配同源）。 */
  const enqueueUninstall = async (name: string, repo: string | null, desc?: string) => {
    if (!name) return
    if (queueRef.current.some((q) => q.kind === 'uninstall' && q.target === name)) return
    // 请求在途防重：与安装一致，响应回来前再次点击直接忽略
    if (submittingRef.current.has(name)) return
    submittingRef.current.add(name)
    setSubmitting(true)
    const controller = new AbortController()
    const timeout = window.setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS)
    try {
      const res = await fetch('/dsh-plugin-hub/uninstall', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ name, repo: repo ?? undefined }),
        signal: controller.signal,
      })
      const data = await res.json() as { ok?: boolean; task?: number; error?: string }
      if (!data.ok || typeof data.task !== 'number') {
        onError(data.error || `HTTP ${res.status}`, repo, 'uninstall')
        return
      }
      const taskId = data.task
      modalTaskRef.current = taskId
      applyQueue((prev) => [...prev, { id: taskId, kind: 'uninstall', target: name, desc, repo, status: 'pending', progress: 0, lines: [], needsRestart: true }])
      // 摘要条常驻顶部（含实时进度），明细面板保持折叠，想看时再点开
      pollQueue()
    } catch (err) {
      // 网络异常：附上底层原因，避免只剩一句笼统的「卸载失败」
      const aborted = (err as { name?: string } | null)?.name === 'AbortError'
      // [request-timeout]：给分类器一个与界面语言无关的超时标记
      const reason = aborted
        ? `${t('requestTimeout')}\n[request-timeout]`
        : err instanceof Error && err.message ? err.message : String(err ?? '')
      onError(reason ? `${t('uninstallFail')} — ${reason}` : t('uninstallFail'), repo, 'uninstall')
    } finally {
      window.clearTimeout(timeout)
      submittingRef.current.delete(name)
      setSubmitting(false)
    }
  }

  /** 弹窗动作：直接卸载（目录插件入口）。与安装同一队列机制，弹窗内实时显示进度。 */
  const uninstallNow = async (p: HubPlugin) => {
    const name = installedName(p)
    if (!name) return
    await enqueueUninstall(name, p.source?.repo ?? null, p.description)
  }

  /** 已安装视图动作：按已安装项卸载（覆盖目录外自定义安装，无目录数据也能卸）。 */
  const uninstallItem = async (item: InstalledItem) => {
    await enqueueUninstall(item.name, item.repo, item.plugin?.description)
  }

  /** 取消任务：排队中立即出队，执行中终止子进程；先标记「正在取消」短暂过渡后再移除。 */
  const cancelTask = async (id: number) => {
    if (modalTaskRef.current === id) modalTaskRef.current = null
    // 乐观标记「正在取消」，给用户一个可见反馈，而不是瞬间消失
    applyQueue((prev) => prev.map((q) => (q.id === id ? { ...q, status: 'cancelling' as const } : q)))
    try {
      await fetch('/dsh-plugin-hub/cancel', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ id }),
      })
    } catch { /* 服务端不可达：仍按取消处理，稍后移除 */ }
    // 短暂展示「正在取消」后移除；队列清空则停止轮询
    window.setTimeout(() => {
      applyQueue((prev) => prev.filter((x) => x.id !== id))
      maybeStopPoll()
    }, 700)
  }

  /** 打开新弹窗前清空任务匹配：避免旧任务 id 误匹配到新弹窗。 */
  const clearModalTask = () => { modalTaskRef.current = null }

  // 弹窗对应任务：优先当前弹窗发起任务，其次按目标匹配（重新打开弹窗 / 目标已在队列时也能展示实时进度）
  // 目录插件按 source.repo 匹配；命令行安装（custom）按归一化后的仓库身份/包名匹配；
  // 全局 npm 安装按包列表身份（空格拼接）匹配；
  // 排除 cancelling：取消中的任务不再关联到弹窗，弹窗回到「确认」态可重新操作
  const installModalTarget = installPlugin?.source?.repo
    ?? (installCustomTarget ? repoFromInstallTarget(installCustomTarget) : null)
    ?? installGlobalTarget ?? null
  const installModalTask = (installPlugin || installCustomTarget || installGlobalTarget)
    ? (queue.find((q) => q.id === modalTaskRef.current && q.kind === 'install' && q.status !== 'cancelling')
      ?? queue.find((q) => q.kind === 'install' && q.target === installModalTarget && q.status !== 'cancelling')
      ?? null)
    : null
  const uninstallModalTask = (uninstallPlugin || uninstallName)
    ? (queue.find((q) => q.id === modalTaskRef.current && q.status !== 'cancelling')
      ?? queue.find((q) => q.kind === 'uninstall' && q.target === (uninstallName ?? installedName(uninstallPlugin!) ?? '') && q.status !== 'cancelling')
      ?? null)
    : null

  return {
    queue,
    pendingRestarts,
    installModalTask,
    uninstallModalTask,
    submitting,
    installNow,
    installCustom,
    installGlobalNpm,
    uninstallNow,
    uninstallItem,
    cancelTask,
    clearModalTask,
  }
}
