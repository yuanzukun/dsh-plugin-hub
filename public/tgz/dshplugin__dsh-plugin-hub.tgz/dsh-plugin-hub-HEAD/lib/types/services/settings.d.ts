export interface HubSettings {
    /** 启动时检查目录插件更新，发现可更新时在通知中心提示（安装不自动进行） */
    checkUpdatesOnStart: boolean;
    /** HTTP(S) 代理地址，用于 npm / git / 目录请求（空串 = 直连） */
    proxy: string;
    /** npm 镜像源 registry 地址（空串 = 未配置，跟随用户本机 npm 配置） */
    npmRegistry: string;
    /** 公共源传输失败时自动换下一个镜像重试（自定义/内网源不切换） */
    registryFallback: boolean;
    /** 启用命令行安装 NPM 包（默认开；关掉后输入 npm 包名安装被拦截） */
    enableNpmInstall: boolean;
    /** 日志存放位置覆盖（空串 = 默认 ~/.dsh/profiles/<profile>/hub.log；可填目录或 .log 文件路径） */
    logPath: string;
}
export declare const DEFAULT_SETTINGS: HubSettings;
export declare function settingsFile(profile: string): string;
/** 读取当前 profile 的设置；文件缺失/损坏时回退默认值（只读路径绝不抛错）。 */
export declare function loadSettings(profile: string): HubSettings;
/** 合并并持久化设置（部分更新），返回合并后的完整设置。 */
export declare function saveSettings(profile: string, patch: Partial<HubSettings>): HubSettings;
/** 重置为默认设置：删除设置文件，下次读取全部回退默认值（陈旧/白名单外键一并清除）。 */
export declare function resetSettings(profile: string): HubSettings;
