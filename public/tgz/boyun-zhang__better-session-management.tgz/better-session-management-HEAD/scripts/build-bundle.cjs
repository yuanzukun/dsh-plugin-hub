#!/usr/bin/env node
/**
 * better-session-management — bundle 移植生成器（无外部依赖）
 * 从动态插件源码（src/host.js / dist/client.chunked.js）机械生成 DSH 官方
 * bundle 形态：index.js（Host，Typert Remote + tools 注册）与 client.js
 * （浏览器模块加载器格式 + Remote 调用），逻辑与动态版逐行一致。
 */
'use strict'
const fs = require('fs')
const path = require('path')
const ROOT = path.join(__dirname, '..')

const PKG = 'dsh-better-session-management'
const NS = 'bsm'

const RPC = [
  ['bsm/sub-create', 'subCreate', 'async (args)'],
  ['bsm/parent-of', 'parentOf', 'async (args)'],
  ['bsm/sub-rename', 'subRename', 'async (args)'],
  ['bsm/sub-delete', 'subDelete', 'async (args)'],
  ['bsm/workspace-list', 'workspaceList', 'async ()'],
  ['bsm/workspace-delete', 'workspaceDelete', 'async (args)'],
  ['bsm/sub-list', 'subList', 'async (args)'],
  ['bsm/sub-inject', 'subInject', 'async (args)'],
  ['bsm/interrupt', 'interrupt', '(args)'],
  ['bsm/stop-main', 'stopMain', '(args)'],
  ['bsm/btw-set-effort', 'btwSetEffort', 'async (args)'],
  ['bsm/btw-create', 'btwCreate', 'async (args)'],
  ['bsm/btw-answer', 'btwAnswer', 'async (args)'],
  ['bsm/btw-destroy', 'btwDestroy', 'async (args)'],
  ['bsm/btw-promote', 'btwPromote', 'async (args)'],
  ['bsm/feedback-list', 'feedbackList', 'async (args)'],
  ['bsm/feedback-put', 'feedbackPut', 'async (args)'],
]

// ---------- Host ----------
let host = fs.readFileSync(path.join(ROOT, 'src', 'host.js'), 'utf8')

host = host.replace(/^\/\/[^\n]*\n(?:^\/\/[^\n]*\n)+/, '')
const HEADER = `// dsh-better-session-management — Host half（bundle 形态，与 src/host.js 动态版逻辑一致）\n// 官方打包模型：dsh.bundle（package.json）+ cordis.patch.yml + 本模块。\n// 与动态版的差异：harness.handle/defineTool → Typert Remote 服务 + ctx.tools.register；\n// 无沙箱 guard（原生运行）。\n\nimport { Remote, TypertRemoteService } from '@deepseek-ai/dsh-typert-protocol'\n\n`
host = HEADER + host

host = host.replace('return {\n  apply(ctx) {', 'export function apply(ctx) {')
host = host.replace(/\n  \},\n\}\s*$/, '\n}')

// 1) harness.handle 头 → const h_xxx
for (const [wire, camel, sig] of RPC) {
  const from = "harness.handle('" + wire + "', " + sig + ' => {'
  if (host.indexOf(from) === -1) throw new Error('host: missing handle head ' + wire)
  host = host.split(from).join('const h_' + camel + ' = ' + sig + ' => {')
}
// 2) 每个 h_xxx 块的收尾 `\n    })`（自其头部之后第一次出现）→ `\n    }`
let out = host
for (const [, camel] of RPC) {
  const marker = 'const h_' + camel + ' = '
  const start = out.indexOf(marker)
  if (start === -1) throw new Error('host: missing body head ' + camel)
  const close = out.indexOf('\n    })\n', start)
  if (close === -1) throw new Error('host: missing body close ' + camel)
  out = out.slice(0, close) + '\n    }\n' + out.slice(close + 8)
}
host = out
// 3) defineTool → 工具对象 + 注册
host = host.replace('const createSubTool = harness.defineTool({', 'const createSubTool = {')
  {
    const start = host.indexOf('const createSubTool = {')
    const close = host.indexOf('\n    })\n', start)
    if (close === -1) throw new Error('host: missing defineTool close')
    host = host.slice(0, close) + '\n    }\n' + host.slice(close + 8)
  }
if (host.indexOf('harness.registerTool(ctx, createSubTool)') === -1) throw new Error('host: missing registerTool')
host = host.replace('harness.registerTool(ctx, createSubTool)', 'if (ctx.get(\'tools\') !== undefined && typeof ctx.get(\'tools\').register === \'function\') {\n      ctx.get(\'tools\').register(createSubTool)\n    }')

// 4) 追加 RPC 网关
const names = RPC.map(([, c]) => c)
const GATEWAY = `
  // ---------- Typert Remote 网关（宿主 RPC；命名空间 ${NS}） ----------
  const rpcTable = { ${names.map(c => c + ': h_' + c).join(', ')} }
  const bsmDescriptors = Object.keys(rpcTable).map((method) => ({
    id: '${PKG}#${NS}/' + method,
    service: '${NS}',
    namespace: '${NS}',
    method,
    invocation: { kind: 'direct' },
    parameters: [{ name: 'args', wire: 'args', source: 'json', codec: { mode: 'src-json' } }],
    result: { mode: 'src-json' },
  }))
  class BsmGateway extends TypertRemoteService {
    constructor(ownerCtx) { super(ownerCtx, '${NS}') }
  }
  const bsmInitializers = []
  for (const [method, fn] of Object.entries(rpcTable)) {
    BsmGateway.prototype[method] = fn
    Remote(method)(BsmGateway.prototype[method], {
      kind: 'method', name: method, static: false, private: false,
      access: {},
      addInitializer(init) { bsmInitializers.push(init) },
    })
  }
  class BsmGatewayRuntime extends BsmGateway {
    constructor(ownerCtx) {
      super(ownerCtx)
      for (const init of bsmInitializers) init.call(this)
    }
  }
  ctx.plugin(BsmGatewayRuntime)
  const typert = ctx.get('typert')
  if (typert !== undefined && typeof typert.register === 'function') {
    ctx.effect(() => typert.register({
      package: '${PKG}',
      face: 'host',
      schemas: [],
      model: { services: [], events: [], objects: [] },
      invocations: bsmDescriptors,
    }))
  }
}
`
host = host.replace(/\n\}\s*$/, GATEWAY)
fs.writeFileSync(path.join(ROOT, 'index.js'), host)

// ---------- Client ----------
let client = fs.readFileSync(path.join(ROOT, 'dist', 'client.chunked.js'), 'utf8')
client = client.replace(/^\/\/[^\n]*\n(?:^\/\/[^\n]*\n)+/, '')
const CHEADER = `// dsh-better-session-management — Client half（bundle 形态，与 dist/client.chunked.js 逻辑一致）\nwindow.__ModuleLoader__.load({\n  id: '${PKG}',\n  factory: (require) => {\n    const React = require('react')\n\n`
const CMOUNT = `
    // ---------- Typert Remote（命名空间 ${NS}；替代动态插件的 host.call） ----------
    let bsmRemote = null
    const bsmMethods = [${names.map(n => "'" + n + "'").join(', ')}]
    const bsmCall = (method, args) => {
      if (bsmRemote === null || typeof bsmRemote[method] !== 'function') {
        return Promise.resolve({ ok: false, error: '远程通道未就绪' })
      }
      try { return Promise.resolve(bsmRemote[method](args)) } catch (error) {
        return Promise.resolve({ ok: false, error: String(error && error.message ? error.message : error) })
      }
    }
    const bsmContribution = {
      package: '${PKG}',
      descriptors: bsmMethods.map((method) => ({
        id: '${PKG}#${NS}/' + method,
        service: '${NS}',
        namespace: '${NS}',
        method,
        invocation: { kind: 'direct' },
        parameters: [{ name: 'args', wire: 'args', source: 'json', codec: { mode: 'src-json' } }],
        result: { mode: 'src-json' },
      })),
    }
    function bsmReady() { return bsmRemote !== null }\n\n`
client = CHEADER + CMOUNT + client

// host.call('bsm/x', ...) -> bsmCall('camel', ...)
for (const [wire, camel] of RPC) {
  client = client.split("host.call('" + wire + "',").join("bsmCall('" + camel + "',")
}
client = client.split("typeof host === 'undefined' || !host.call").join('!bsmReady()')
client = client.split("typeof host !== 'undefined' && host.call").join('bsmReady()')

// 服务获取兼容：静态客户端 ctx 可能以属性暴露
client = client.split("const slots = ctx.get('slots')").join("const slots = ctx.get('slots') || ctx.slots")
client = client.split("sessionsSvcRef = ctx.get('sessions')").join("sessionsSvcRef = ctx.get('sessions') || ctx.sessions")
client = client.split("timerSvcRef = ctx.get('timer')").join("timerSvcRef = ctx.get('timer') || ctx.timer")
client = client.split("const styles = ctx.get('styles')").join("const styles = ctx.get('styles') || ctx.styles")

// Remote 挂载：apply 内注册（在 return { apply(ctx) { 之后注入）
const MOUNT = `
    const remoteSvc = ctx.get('remote') || ctx.remote
    if (remoteSvc !== undefined && typeof remoteSvc.$mount === 'function') {
      ctx.effect(() => {
        remoteSvc.$mount(bsmContribution).then((disposeMount) => {
          const mounted = ctx.get('remote.${NS}', false)
          if (mounted !== undefined) {
            bsmRemote = mounted
            bsmNotify()
          }
          return disposeMount
        }).catch(() => { /* 挂载失败：bsmCall 回退为错误提示 */ })
      })
    }
`
const applyAnchor = 'return {\n  apply(ctx) {\n'
if (client.indexOf(applyAnchor) === -1) throw new Error('client: missing apply anchor')
client = client.replace(applyAnchor, applyAnchor + MOUNT)

// 模块加载器收尾
client = client.replace(/\n\}\s*$/, '\n}\n  }\n})\n')
fs.writeFileSync(path.join(ROOT, 'client.js'), client)

console.log('bundle generated: index.js / client.js')
