#!/usr/bin/env node
/**
 * better-session-management — client 构建脚本（无外部依赖）
 *
 * 将 src/client2.template.js 中的 __ICONS_JSON__ 占位符替换为
 * src/icons.json（IconPark SVG 图标目录，Apache-2.0）的 JS 对象字面量，
 * 长 SVG 字符串按安全边界分块、逐块 JSON 转义后显式 `+` 拼接
 * （避免超长行与转义序列截断问题），输出 dist/client.chunked.js 并做语法检查。
 *
 * 用法：node scripts/build-client.js
 */
'use strict'
const fs = require('fs')
const path = require('path')

const ROOT = path.join(__dirname, '..')
const TPL = path.join(ROOT, 'src', 'client2.template.js')
const ICONS = path.join(ROOT, 'src', 'icons.json')
const OUT = path.join(ROOT, 'dist', 'client.chunked.js')
const CHUNK_WIDTH = 1000

function chunkValue(raw, width = CHUNK_WIDTH) {
  // 原始 SVG 字符串按固定宽度分块；每块独立 JSON 转义后显式 + 拼接，
  // 保证不会在转义序列（如 \"）中间切断
  if (raw.length <= width) return JSON.stringify(raw)
  const pieces = []
  let rest = raw
  while (rest.length > width) {
    pieces.push(JSON.stringify(rest.slice(0, width)))
    rest = rest.slice(width)
  }
  pieces.push(JSON.stringify(rest))
  return pieces.join(' +\n    ')
}

function main() {
  const template = fs.readFileSync(TPL, 'utf8')
  if (template.indexOf('__ICONS_JSON__') === -1) {
    throw new Error('src/client2.template.js 缺少 __ICONS_JSON__ 占位符')
  }
  const icons = JSON.parse(fs.readFileSync(ICONS, 'utf8'))
  const keys = Object.keys(icons)
  if (keys.length === 0) throw new Error('src/icons.json 为空')

  const parts = []
  for (const key of keys.sort()) {
    parts.push('  ' + JSON.stringify(key) + ': ' + chunkValue(icons[key]))
  }
  const literal = '{\n' + parts.join(',\n') + '\n}'
  const code = template.replace('__ICONS_JSON__', literal)

  // 语法检查（不执行）
  new Function(code)

  fs.mkdirSync(path.dirname(OUT), { recursive: true })
  fs.writeFileSync(OUT, code)

  const lines = code.split('\n')
  console.log('client build OK ->', OUT)
  console.log('bytes:', Buffer.byteLength(code), '| lines:', lines.length,
    '| maxLine:', Math.max(...lines.map(l => l.length)), '| icons:', keys.length)
}

main()
