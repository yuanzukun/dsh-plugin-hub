// dsh-better-session-management — Client half（bundle 形态，与 dist/client.chunked.js 逻辑一致）
window.__ModuleLoader__.load({
  id: 'dsh-better-session-management',
  factory: (require) => {
    const React = require('react')


    // ---------- Typert Remote（命名空间 bsm；替代动态插件的 host.call） ----------
    let bsmRemote = null
    const bsmMethods = ['subCreate', 'parentOf', 'subRename', 'subDelete', 'workspaceList', 'workspaceDelete', 'subList', 'subInject', 'interrupt', 'stopMain', 'btwSetEffort', 'btwCreate', 'btwAnswer', 'btwDestroy', 'btwPromote', 'feedbackList', 'feedbackPut']
    const bsmCall = (method, args) => {
      if (bsmRemote === null || typeof bsmRemote[method] !== 'function') {
        return Promise.resolve({ ok: false, error: '远程通道未就绪' })
      }
      try { return Promise.resolve(bsmRemote[method](args)) } catch (error) {
        return Promise.resolve({ ok: false, error: String(error && error.message ? error.message : error) })
      }
    }
    const bsmContribution = {
      package: 'dsh-better-session-management',
      descriptors: bsmMethods.map((method) => ({
        id: 'dsh-better-session-management#bsm/' + method,
        service: 'bsm',
        namespace: 'bsm',
        method,
        invocation: { kind: 'direct' },
        parameters: [{ name: 'args', wire: 'args', source: 'json', codec: { mode: 'src-json' } }],
        result: { mode: 'src-json' },
      })),
    }
    function bsmReady() { return bsmRemote !== null }

// better-session-management — pkg36 Client half (源码镜像)
// 纯 JavaScript。图标来自字节跳动 IconPark 开源图标库（https://iconpark.oceanengine.com/official，@icon-park/svg，Apache-2.0）。
// pkg36 变更：
// - 【修复】链视图「加载更早」按钮无效：conversation.view 槽位并没有 loadOlder 标准 prop，
//   改为经 sessions 服务的 binding(sessionId).session.loadOlder()（SessionFace）触发真正的历史分页。
// - pkg35 内容保留：代码窗口纯内联布局、会话栏主会话缩进、长行不换行、指令气泡硬换行等。

// ---------- IconPark 图标（outline 主题，currentColor 描边） ----------
const ICONS_INNER = {
  "AddSubset": "<path d=\"M10 28V35H18\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M18 28H42V42H18V35V28Z\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><line x1=\"6\" y1=\"13.5\" x2=\"6\" y2=\"12.5\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><line x1=\"6\" y1=\"20\" x2=\"6\" y2=\"19\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><line x1=\"6\" y1=\"7\" x2=\"6\" y2=\"6\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><line x1=\"32\" y1=\"13.5\" x2=\"32\" y2=\"12.5\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><line x1=\"32\" y1=\"20\" x2=\"32\" y2=\"19\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><line x1=\"32\" y1=\"7\" x2=\"32\" y2=\"6\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><line x1=\"" +
    "32\" y1=\"20\" x2=\"31\" y2=\"20\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><line x1=\"7\" y1=\"20\" x2=\"6\" y2=\"20\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><line x1=\"7\" y1=\"6\" x2=\"6\" y2=\"6\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><line x1=\"13\" y1=\"6\" x2=\"12\" y2=\"6\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><line x1=\"19.5\" y1=\"6\" x2=\"18.5\" y2=\"6\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><line x1=\"19.5\" y1=\"20\" x2=\"18.5\" y2=\"20\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><line x1=\"26\" y1=\"6\" x2=\"25\" y2=\"6\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><line x1=\"13\" y1=\"20\" x2=\"12\" y2=\"20\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><line x1=\"26\" " +
    "y1=\"20\" x2=\"25\" y2=\"20\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><line x1=\"32\" y1=\"6\" x2=\"31\" y2=\"6\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
  "Application": "<path d=\"M40.0391 22V42H8.03906V22\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M5.84231 13.7766C4.31276 17.7377 7.26307 22 11.5092 22C14.8229 22 17.5276 19.3137 17.5276 16C17.5276 19.3137 20.2139 22 23.5276 22H24.546C27.8597 22 30.546 19.3137 30.546 16C30.546 19.3137 33.2518 22 36.5655 22C40.8139 22 43.767 17.7352 42.2362 13.7723L39.2337 6H8.84523L5.84231 13.7766Z\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linejoin=\"round\"/>",
  "Attention": "<path d=\"M24 44C29.5228 44 34.5228 41.7614 38.1421 38.1421C41.7614 34.5228 44 29.5228 44 24C44 18.4772 41.7614 13.4772 38.1421 9.85786C34.5228 6.23858 29.5228 4 24 4C18.4772 4 13.4772 6.23858 9.85786 9.85786C6.23858 13.4772 4 18.4772 4 24C4 29.5228 6.23858 34.5228 9.85786 38.1421C13.4772 41.7614 18.4772 44 24 44Z\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linejoin=\"round\"/><path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M24 37C25.3807 37 26.5 35.8807 26.5 34.5C26.5 33.1193 25.3807 32 24 32C22.6193 32 21.5 33.1193 21.5 34.5C21.5 35.8807 22.6193 37 24 37Z\" fill=\"currentColor\"/><path d=\"M24 12V28\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
  "BookOpen": "<path d=\"M5 7H16C20.4183 7 24 10.5817 24 15V42C24 38.6863 21.3137 36 18 36H5V7Z\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linejoin=\"round\"/><path d=\"M43 7H32C27.5817 7 24 10.5817 24 15V42C24 38.6863 26.6863 36 30 36H43V7Z\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linejoin=\"round\"/>",
  "Brain": "<path d=\"M19.036 44.0002C18.0561 40.8046 16.5778 38.4223 14.6011 36.8533C11.636 34.4998 6.92483 35.9625 5.18458 33.535C3.44433 31.1074 6.40382 26.6432 7.44234 24.0091C8.48086 21.3751 3.46179 20.4437 4.04776 19.6959C4.43842 19.1974 6.97471 17.7588 11.6567 15.3802C12.987 7.79356 17.9008 4.00024 26.3982 4.00024C39.1441 4.00024 44 14.8062 44 21.6791C44 28.5521 38.1201 35.9564 29.7441 37.5529C28.9951 38.6437 30.0754 40.7928 32.9848 44.0002\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M19.4997 14.5001C18.8464 17.0344 19.0408 18.8139 20.0829 19.8386C21.125 20.8634 22.9011 21.5335 25.4112 21.849C24.8417 25.1177 25.5361 26.6512 27.4942 26.4494C29.4524 26.2476 30.6289 25.434 31.0239 24.0084C34.0842 24.8685 35.7428 24.1487 35.9997 21.849C36.3852 18.3994 34.525 15.6476 33.7624 15.6476C32.9997 15.6476 31.0239 15.5548 31.0239 14.5001C31.0239 13.4453 28.7159 12.8494 26.6329 12.8494C24.5499 12.8494 25.8035 11.4" +
    "453 22.9432 12.0001C21.0363 12.3699 19.8885 13.2032 19.4997 14.5001Z\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linejoin=\"round\"/><path d=\"M30.5002 25.5002C29.4833 26.1313 28.0878 27.1805 27.5002 28.0002C26.0313 30.0497 24.8398 31.2976 24.5791 32.6083\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linecap=\"round\"/>",
  "Branch": "<path d=\"M40 28C42.2091 28 44 26.2091 44 24C44 21.7909 42.2091 20 40 20C37.7909 20 36 21.7909 36 24C36 26.2091 37.7909 28 40 28Z\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linejoin=\"round\"/><path d=\"M9 12C11.2091 12 13 10.2091 13 8C13 5.79086 11.2091 4 9 4C6.79086 4 5 5.79086 5 8C5 10.2091 6.79086 12 9 12Z\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linejoin=\"round\"/><path d=\"M9 44C11.2091 44 13 42.2091 13 40C13 37.7909 11.2091 36 9 36C6.79086 36 5 37.7909 5 40C5 42.2091 6.79086 44 9 44Z\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linejoin=\"round\"/><path d=\"M9 12V36V24.0083H36\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
  "BranchTwo": "<path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M36 12C38.2091 12 40 10.2091 40 8C40 5.79086 38.2091 4 36 4C33.7909 4 32 5.79086 32 8C32 10.2091 33.7909 12 36 12Z\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M14 12C16.2091 12 18 10.2091 18 8C18 5.79086 16.2091 4 14 4C11.7909 4 10 5.79086 10 8C10 10.2091 11.7909 12 14 12Z\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M14 44C16.2091 44 18 42.2091 18 40C18 37.7909 16.2091 36 14 36C11.7909 36 10 37.7909 10 40C10 42.2091 11.7909 44 14 44Z\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M14 12L14 36L14 33C14 25 36 24 36 16V12\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
  "CategoryManagement": "<rect x=\"6\" y=\"28\" width=\"36\" height=\"14\" rx=\"4\" stroke=\"currentColor\" stroke-width=\"4\"/><path d=\"M20 7H10C7.79086 7 6 8.79086 6 11V17C6 19.2091 7.79086 21 10 21H20\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linecap=\"round\"/><circle cx=\"34\" cy=\"14\" r=\"8\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"4\"/><circle cx=\"34\" cy=\"14\" r=\"3\" fill=\"currentColor\"/>",
  "Checklist": "<path d=\"M34 10L42 18\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M42 10L34 18\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M44 30L37 38L33 34\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M26 10H4V18H26V10Z\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M26 30H4V38H26V30Z\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
  "Command": "<path d=\"M9.45455 14.9091C10.5023 14.9091 12.3205 14.9091 14.9091 14.9091C14.9091 12.2333 14.9091 10.4151 14.9091 9.45455C14.9091 6.44208 12.467 4 9.45455 4C6.44208 4 4 6.44208 4 9.45455C4 12.467 6.44208 14.9091 9.45455 14.9091Z\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linejoin=\"round\"/><path d=\"M9.45455 33.0909H14.9091V38.5454C14.9091 41.5579 12.467 44 9.45455 44C6.44208 44 4 41.5579 4 38.5454C4 35.533 6.44208 33.0909 9.45455 33.0909Z\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linejoin=\"round\"/><rect x=\"14.9092\" y=\"14.9091\" width=\"18.1818\" height=\"18.1818\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M38.5454 14.9091H33.0908V9.45455C33.0908 6.44208 35.5329 4 38.5454 4C41.5578 4 43.9999 6.44208 43.9999 9.45455C43.9999 12.467 41.5578 14.9091 38.5454 14.9091Z\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linejoin=\"round\"/><path d=\"M38.5454 33.0909C41.5578 33.0909 43.9999 35.533 43.9999 38.54" +
    "54C43.9999 41.5579 41.5578 44 38.5454 44C35.5329 44 33.0908 41.5579 33.0908 38.5454V33.0909H38.5454Z\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linejoin=\"round\"/>",
  "Comment": "<path d=\"M44 6H4V36H13V41L23 36H44V6Z\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M14 19.5V22.5\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M24 19.5V22.5\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M34 19.5V22.5\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
  "Compression": "<path d=\"M8.91962 8.7141C8.49508 7.38938 9.47567 6 10.8668 6H37.1332C38.5243 6 39.5049 7.38938 39.0804 8.7141C37.8993 12.3995 36 19.0894 36 24C36 28.9106 37.8993 35.6005 39.0804 39.2859C39.5049 40.6106 38.5243 42 37.1332 42H10.8668C9.47567 42 8.49508 40.6106 8.91962 39.2859C10.1007 35.6005 12 28.9106 12 24C12 19.0894 10.1007 12.3995 8.91962 8.7141Z\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M4 15C5.5 17 5.99988 21 5.99988 24C5.99988 27 5.5 31 4 33\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M18 15.5H30\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linecap=\"round\"/><path d=\"M18 24H30\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linecap=\"round\"/><path d=\"M18 32H22\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linecap=\"round\"/><path d=\"M44 15C42.5 17 42.0001 21 42.0001 24C42.0001 27 42.5 30 44 33\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-li" +
    "nejoin=\"round\"/>",
  "Copy": "<path d=\"M13 12.4316V7.8125C13 6.2592 14.2592 5 15.8125 5H40.1875C41.7408 5 43 6.2592 43 7.8125V32.1875C43 33.7408 41.7408 35 40.1875 35H35.5163\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M32.1875 13H7.8125C6.2592 13 5 14.2592 5 15.8125V40.1875C5 41.7408 6.2592 43 7.8125 43H32.1875C33.7408 43 35 41.7408 35 40.1875V15.8125C35 14.2592 33.7408 13 32.1875 13Z\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linejoin=\"round\"/>",
  "DataAll": "<ellipse cx=\"24\" cy=\"11\" rx=\"20\" ry=\"6\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M10.7709 15.5C6.61878 16.5994 4 18.208 4 20C4 23.3137 12.9543 26 24 26C35.0457 26 44 23.3137 44 20C44 18.208 41.3812 16.5994 37.2291 15.5C33.7035 16.4335 29.0722 17 24 17C18.9278 17 14.2965 16.4335 10.7709 15.5Z\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M10.7709 24.5C6.61878 25.5994 4 27.208 4 29C4 32.3137 12.9543 35 24 35C35.0457 35 44 32.3137 44 29C44 27.208 41.3812 25.5994 37.2291 24.5C33.7035 25.4335 29.0722 26 24 26C18.9278 26 14.2965 25.4335 10.7709 24.5Z\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M10.7709 33.5C6.61878 34.5994 4 36.208 4 38C4 41.3137 12.9543 44 24 44C35.0457 44 44 41.3137 44 38C44 36.208 41.3812 34.5994 37.2291 33.5C33.7035 34.4335 29.0722 35 24 35C18.9278 35 14.2965 34.4335 10.7709 33.5" +
    "Z\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
  "Delete": "<path d=\"M9 10V44H39V10H9Z\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linejoin=\"round\"/><path d=\"M20 20V33\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M28 20V33\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M4 10H44\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M16 10L19.289 4H28.7771L32 10H16Z\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linejoin=\"round\"/>",
  "Edit": "<path d=\"M7 42H43\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M11 26.7199V34H18.3172L39 13.3081L31.6951 6L11 26.7199Z\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linejoin=\"round\"/>",
  "Folder": "<path d=\"M7 6C7 4.89543 7.89543 4 9 4H39C40.1046 4 41 4.89543 41 6V42C41 43.1046 40.1046 44 39 44H9C7.89543 44 7 43.1046 7 42V6Z\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M16 29H20\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M16 35H26\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M8 5C8 5 11.7647 18 24 18C36.2353 18 40 5 40 5\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><circle cx=\"24\" cy=\"18\" r=\"4\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M15 4H9C7.89543 4 7 4.89543 7 6V12\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M33 4H39C40.1046 4 41 4.89543 41 6V12\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
  "FolderOpen": "<path d=\"M4 9V41L9 21H39.5V15C39.5 13.8954 38.6046 13 37.5 13H24L19 7H6C4.89543 7 4 7.89543 4 9Z\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M40 41L44 21H8.8125L4 41H40Z\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
  "Globe": "<path d=\"M37.8261 4C41.6276 7.58886 44 12.6753 44 18.3158C44 29.1871 35.1871 38 24.3158 38C18.6753 38 13.5889 35.6276 10 31.8261\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M24 32C31.732 32 38 25.732 38 18C38 10.268 31.732 4 24 4C16.268 4 10 10.268 10 18C10 25.732 16.268 32 24 32Z\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M24 38V44\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M18 44H30\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
  "Help": "<path d=\"M24 44C29.5228 44 34.5228 41.7614 38.1421 38.1421C41.7614 34.5228 44 29.5228 44 24C44 18.4772 41.7614 13.4772 38.1421 9.85786C34.5228 6.23858 29.5228 4 24 4C18.4772 4 13.4772 6.23858 9.85786 9.85786C6.23858 13.4772 4 18.4772 4 24C4 29.5228 6.23858 34.5228 9.85786 38.1421C13.4772 41.7614 18.4772 44 24 44Z\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linejoin=\"round\"/><path d=\"M24 28.6248V24.6248C27.3137 24.6248 30 21.9385 30 18.6248C30 15.3111 27.3137 12.6248 24 12.6248C20.6863 12.6248 18 15.3111 18 18.6248\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M24 37.6248C25.3807 37.6248 26.5 36.5055 26.5 35.1248C26.5 33.7441 25.3807 32.6248 24 32.6248C22.6193 32.6248 21.5 33.7441 21.5 35.1248C21.5 36.5055 22.6193 37.6248 24 37.6248Z\" fill=\"currentColor\"/>",
  "Magic": "<path d=\"M20.1005 8.1005L24.3431 12.3431M30 4V10V4ZM39.8995 8.1005L35.6569 12.3431L39.8995 8.1005ZM44 18H38H44ZM39.8995 27.8995L35.6569 23.6569L39.8995 27.8995ZM30 32V26V32ZM20.1005 27.8995L24.3431 23.6569L20.1005 27.8995ZM16 18H22H16Z\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M29.5856 18.4143L5.54395 42.4559\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
  "Plug": "<path d=\"M6 14H42V24C38 32 32 36 24 36C16 36 10 32 6 24V14Z\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linejoin=\"round\"/><path d=\"M33 34L32 44H16L15 34\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M22 24H26\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M16 4L16 12\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M32 4V12\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
  "Refresh": "<path d=\"M42 8V24\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M6 24L6 40\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M42 24C42 14.0589 33.9411 6 24 6C18.9145 6 14.3216 8.10896 11.0481 11.5M6 24C6 33.9411 14.0589 42 24 42C28.8556 42 33.2622 40.0774 36.5 36.9519\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
  "Robot": "<rect x=\"9\" y=\"17\" width=\"30\" height=\"26\" rx=\"2\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M33 9L28 17\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M15 9L20 17\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><circle cx=\"34\" cy=\"7\" r=\"2\" stroke=\"currentColor\" stroke-width=\"4\"/><circle cx=\"14\" cy=\"7\" r=\"2\" stroke=\"currentColor\" stroke-width=\"4\"/><rect x=\"16\" y=\"24\" width=\"16\" height=\"8\" rx=\"4\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"4\"/><path d=\"M9 24H4V34H9\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M39 24H44V34H39\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
  "Search": "<path d=\"M21 38C30.3888 38 38 30.3888 38 21C38 11.6112 30.3888 4 21 4C11.6112 4 4 11.6112 4 21C4 30.3888 11.6112 38 21 38Z\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linejoin=\"round\"/><path d=\"M26.657 14.3431C25.2093 12.8954 23.2093 12 21.0001 12C18.791 12 16.791 12.8954 15.3433 14.3431\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M33.2216 33.2217L41.7069 41.707\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
  "Target": "<path d=\"M21.4172 18.5828C19.3962 19.5481 18 21.6109 18 23.9999C18 27.3136 20.6863 29.9999 24 29.9999C26.389 29.9999 28.4519 28.6037 29.4172 26.5828\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M28.2793 11.7207C26.9392 11.2538 25.4992 11 24 11C16.8203 11 11 16.8203 11 24C11 31.1797 16.8203 37 24 37C31.1797 37 37 31.1797 37 24C37 22.5008 36.7462 21.0608 36.2793 19.7207\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M33.5675 6.43255C30.7255 4.88151 27.4657 4 24 4C12.9543 4 4 12.9543 4 24C4 35.0457 12.9543 44 24 44C35.0457 44 44 35.0457 44 24C44 20.5343 43.1185 17.2745 41.5675 14.4325\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M44 4L24 24\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
  "Terminal": "<rect x=\"4\" y=\"8\" width=\"40\" height=\"32\" rx=\"2\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linejoin=\"round\"/><path d=\"M12 18L19 24L12 30\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M23 32H36\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
  "ThumbsDown": "<path d=\"M20.3793 29.4002V36.6002C20.3793 39.5826 22.7969 42.0002 25.7793 42.0002L32.9793 25.8002V6.00023H12.0633C10.2682 5.97994 8.73244 7.2853 8.46327 9.06023L5.97927 25.2602C5.82077 26.3045 6.12885 27.3657 6.82192 28.1627C7.51499 28.9597 8.52311 29.4122 9.57927 29.4002H20.3793Z\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linejoin=\"round\"/><path d=\"M32.9795 6.00017H37.7855C39.8942 5.96288 41.6968 7.51019 41.9795 9.60017V22.2002C41.6968 24.2901 39.8942 26.0375 37.7855 26.0002H32.9795V6.00017Z\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linejoin=\"round\"/>",
  "ThumbsUp": "<path d=\"M27.6002 18.5998V11.3998C27.6002 8.41743 25.1826 5.99977 22.2002 5.99977L15.0002 22.1998V41.9998H35.9162C37.7113 42.0201 39.2471 40.7147 39.5162 38.9398L42.0002 22.7398C42.1587 21.6955 41.8506 20.6343 41.1576 19.8373C40.4645 19.0403 39.4564 18.5878 38.4002 18.5998H27.6002Z\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linejoin=\"round\"/><path d=\"M15 22.0001H10.194C8.08532 21.9628 6.2827 23.7095 6 25.7994V38.3994C6.2827 40.4894 8.08532 42.0367 10.194 41.9994H15V22.0001Z\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linejoin=\"round\"/>",
  "User": "<circle cx=\"24\" cy=\"12\" r=\"8\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M42 44C42 34.0589 33.9411 26 24 26C14.0589 26 6 34.0589 6 44\" stroke=\"currentColor\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>"
}
function svgOf(name) { const p = ICONS_INNER[name] || ICONS_INNER.Application; return '<svg width="1em" height="1em" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">' + p + '</svg>' }

function Icon(props) {
  const size = props.size || 14
  const color = props.color || 'inherit'
  const html = svgOf(props.name)
  return React.createElement('span', {
    style: { display: 'inline-flex', width: size, height: size, color, flexShrink: 0, alignItems: 'center', justifyContent: 'center' },
    dangerouslySetInnerHTML: { __html: html },
  })
}

// ---------- 用户偏好（进程内内存态） ----------
const prefs = { mode: 'A', chainCollapsed: false, feedbackHighlight: true, mdRender: true, mdWidth: 'standard', subMode: 'window', btwEffort: 'high' }
const prefsListeners = new Set()
const MD_WIDTH = { standard: 720, wide: 960, full: 0 }

function usePref(key) {
  return React.useSyncExternalStore(
    (cb) => { prefsListeners.add(cb); return () => { prefsListeners.delete(cb) } },
    () => prefs[key],
  )
}

function setPref(key, value) {
  prefs[key] = value
  for (const fn of Array.from(prefsListeners)) {
    try { fn() } catch (error) { /* ignore */ }
  }
}

// ---------- 包内业务 store ----------
const bsmStore = {
  subs: {},        // parentSessionId -> { subs: [...], btws: [...], loadedAt }
  feedbacks: {},   // sessionId -> { items: [...], loadedAt }
  workspaces: [],  // [{ id, path, title }]
  workspacesAt: 0,
  archivedIds: [], // 持久归档集合（workspaceRegistry.archivedSessionIds 下发）
  notice: null,
  listeners: new Set(),
}
let sessionsSvcRef = null
let timerSvcRef = null
let storeVersion = 0 // bsmNotify 递增；useBsmStore 快照用它驱动重渲染（可变对象引用不变会被 React 跳过）

function bsmSubscribe(cb) { bsmStore.listeners.add(cb); return () => { bsmStore.listeners.delete(cb) } }
function useBsmStore() {
  // 订阅版本号：每次 store 变更都触发重渲染，数据本体仍读可变 bsmStore
  React.useSyncExternalStore(bsmSubscribe, () => storeVersion)
  return bsmStore
}
function bsmNotify() {
  storeVersion++
  for (const fn of Array.from(bsmStore.listeners)) {
    try { fn() } catch (error) { /* ignore */ }
  }
}
function bsmNotice(text) {
  bsmStore.notice = { text, at: Date.now() }
  bsmNotify()
  if (timerSvcRef && typeof timerSvcRef.timeout === 'function') {
    timerSvcRef.timeout(() => {
      if (bsmStore.notice) { bsmStore.notice = null; bsmNotify() }
    }, 5000)
  }
}

const subsInflight = {} // sessionId -> boolean（并发去重）
const watchedSubs = new Set() // 被界面关注的父会话 id：全局轮询刷新 sub-list

function watchSubs(id) {
  if (id) watchedSubs.add(id)
}

async function refreshSubs(sessionId, force) {
  if (!sessionId || !bsmReady()) return
  const cur = bsmStore.subs[sessionId]
  if (!force && cur && Date.now() - cur.loadedAt < 15000) return
  if (!force && subsInflight[sessionId]) return
  subsInflight[sessionId] = true
  try {
    const res = await bsmCall('subList', { parentSessionId: sessionId })
    if (res && res.ok) {
      bsmStore.subs[sessionId] = {
        subs: res.subs || [],
        btws: res.btws || [],
        deleted: res.deleted || [],
        loadedAt: Date.now(),
      }
      bsmNotify()
    }
  } catch (error) { /* ignore */ } finally {
    subsInflight[sessionId] = false
  }
}

async function refreshWorkspaces(force) {
  if (!bsmReady()) return
  if (!force && bsmStore.workspacesAt && Date.now() - bsmStore.workspacesAt < 30000) return
  bsmStore.workspacesAt = Date.now()
  try {
    const res = await bsmCall('workspaceList', {})
    if (res && res.ok && Array.isArray(res.workspaces)) {
      bsmStore.workspaces = res.workspaces
      bsmStore.archivedIds = Array.isArray(res.archived) ? res.archived : []
      bsmNotify()
    }
  } catch (error) { /* ignore */ }
}

async function refreshFeedbacks(sessionId, force) {
  if (!sessionId || !bsmReady()) return
  const cur = bsmStore.feedbacks[sessionId]
  if (!force && cur && Date.now() - cur.loadedAt < 15000) return
  try {
    const res = await bsmCall('feedbackList', { sessionId })
    if (res && res.ok) {
      bsmStore.feedbacks[sessionId] = { items: res.items || [], loadedAt: Date.now() }
      bsmNotify()
    }
  } catch (error) { /* ignore */ }
}

// 打开子会话：fork 子会话是普通会话（open），遗留子代理子会话走 openSubagent
function openChild(entry, parentSessionId) {
  if (entry && entry.kind === 'fork') {
    if (sessionsSvcRef && typeof sessionsSvcRef.open === 'function') sessionsSvcRef.open(entry.id)
    return
  }
  jumpToChild(parentSessionId, entry ? entry.id : null, entry && entry.mode ? entry.mode : 'continuable')
}

function jumpToChild(parentSessionId, childId, mode) {
  if (!childId) return
  const doOpen = () => {
    if (sessionsSvcRef && typeof sessionsSvcRef.openSubagent === 'function') {
      sessionsSvcRef.openSubagent({ parentSessionId, childSessionId: childId, mode: mode === 'one-shot' ? 'one-shot' : 'continuable' })
    }
  }
  if (sessionsSvcRef && typeof sessionsSvcRef.refreshSubagents === 'function') {
    Promise.resolve(sessionsSvcRef.refreshSubagents(parentSessionId))
      .then(doOpen)
      .catch(() => { if (sessionsSvcRef && typeof sessionsSvcRef.open === 'function') sessionsSvcRef.open(childId) })
  } else {
    doOpen()
  }
}

// ---------- Markdown 渲染（与对话视图同款 CSS 变量/版式；产品渲染器未以服务暴露，故按同款对齐） ----------
const MD_CSS = '.bsm-md{min-width:0;overflow-wrap:anywhere;font:var(--dsw-font-markdown-base);color:var(--dsw-alias-label-primary)}'
  + '.bsm-md strong{font-weight:600}'
  + '.bsm-md h1{font:var(--dsw-font-markdown-h1);margin:32px 0 16px}'
  + '.bsm-md h2{font:var(--dsw-font-markdown-h2);margin:32px 0 16px}'
  + '.bsm-md h3{font:var(--dsw-font-markdown-h3);margin:32px 0 16px}'
  + '.bsm-md h4{font:var(--dsw-font-markdown-h4);margin:16px 0}'
  + '.bsm-md h5,.bsm-md h6{font:var(--dsw-font-markdown-base-strong);margin:16px 0}'
  + '.bsm-md :where(h1,h2,h3,h4,h5,h6) strong{font-weight:inherit}'
  + '.bsm-md p{margin:16px 0}'
  + '.bsm-md a{color:var(--dsw-alias-state-business-primary);text-decoration:none}'
  + '.bsm-md a:hover,.bsm-md a:focus{text-decoration:underline var(--dsw-alias-state-business-primary)}'
  + '.bsm-md ul,.bsm-md ol{margin:16px 0;padding-left:18px}'
  + '.bsm-md li:not(:first-child){margin-top:6px}'
  + '.bsm-md li>ul,.bsm-md li>ol{margin-top:4px}'
  + '.bsm-md li::marker{line-height:28px;color:var(--dsw-alias-label-secondary)}'
  + '.bsm-md :where(ul,ol) ol{list-style-position:inside;padding-left:0}'
  + '.bsm-md :where(ul,ol) ol li p{display:inline}'
  + '.bsm-md li>p{margin:8px 0}'
  + '.bsm-md li>*:first-child{margin-top:0}'
  + '.bsm-md li>*:last-child{margin-bottom:0}'
  + '.bsm-md hr{display:block;border:none;height:1px;margin:32px 0;background:var(--dsw-alias-border-l2)}'
  + '.bsm-md blockquote{border-left:2px solid var(--dsw-alias-label-caption);margin:16px 0 0;padding-left:14px}'
  + '.bsm-md pre{margin:16px 0;font-family:var(--ds-font-family-code);overflow:auto}'
  + '.bsm-md :not(pre)>code{display:inline-flex;align-items:center;box-sizing:border-box;font:var(--dsw-font-markdown-code);font-family:var(--ds-font-family-code);font-size:0.875em !important;background-color:var(--dsw-alias-markdown-inline-code);border-radius:6px;padding:0 5px}'
  + '.bsm-md :where(h1,h2,h3,h4,h5,h6) code{font:inherit;font-family:var(--ds-font-family-code)}'
  + '.bsm-md input[type=checkbox]{margin:0 8px 0 0;accent-color:var(--dsw-alias-label-secondary)}'
  + '.bsm-md-table{max-width:100%;overflow-x:auto;overscroll-behavior-x:contain}'
  + '.bsm-md-table table{border-collapse:collapse;width:max-content;max-width:max-content}'
  + '.bsm-md-table th{text-align:start;padding:10px 16px;border-bottom:1px solid var(--dsw-alias-border-l3);font:var(--dsw-font-markdown-table-head);max-width:min(30vw,320px);min-width:100px}'
  + '.bsm-md-table td{padding:10px 16px;border-bottom:1px solid var(--dsw-alias-border-l2);font:var(--dsw-font-markdown-table);max-width:min(30vw,320px);min-width:100px}'
  + '.bsm-md-table th:first-child,.bsm-md-table td:first-child{padding-left:0}'
  + '.bsm-md-table td:last-child{padding-right:0}'
  + '.bsm-md-table table code{font-size:13px}'
  + '.bsm-md>*:first-child,.bsm-md p:first-child{margin-top:0 !important}'
  + '.bsm-md>*:last-child,.bsm-md p:last-child{margin-bottom:0 !important}'

function mdInline(text, keyPrefix) {
  const parts = String(text).split(/(`[^`]+`|\*\*[^*]+\*\*|\*[^*]+\*|~~[^~]+~~|\[[^\]]*\]\([^)]*\)|<https?:\/\/[^>\s]+>)/g)
  return parts.filter(p => p !== '').map((p, i) => {
    const key = keyPrefix + 'i' + i
    if (p.startsWith('`') && p.endsWith('`') && p.length > 2) {
      return React.createElement('code', { key }, p.slice(1, -1))
    }
    if (p.startsWith('**') && p.endsWith('**') && p.length > 4) {
      return React.createElement('strong', { key }, p.slice(2, -2))
    }
    if (p.startsWith('~~') && p.endsWith('~~') && p.length > 4) {
      return React.createElement('del', { key }, p.slice(2, -2))
    }
    if (p.startsWith('*') && p.endsWith('*') && p.length > 2) {
      return React.createElement('em', { key }, p.slice(1, -1))
    }
    const lm = p.match(/^\[([^\]]*)\]\(([^)]*)\)$/)
    if (lm) {
      return React.createElement('a', { key, href: lm[2], target: '_blank', rel: 'noreferrer' }, lm[1])
    }
    const am = p.match(/^<(https?:\/\/[^>\s]+)>$/)
    if (am) {
      return React.createElement('a', { key, href: am[1], target: '_blank', rel: 'noreferrer' }, am[1])
    }
    return p
  })
}

// 列表树：{ ordered, items: [{ check, text, children }] }
function buildListTree(items) {
  const root = { ordered: false, items: [] }
  const stack = [root]
  for (const it of items) {
    let depth = it.indent
    while (stack.length - 1 > depth) stack.pop()
    if (stack.length - 1 < depth) {
      const parent = stack[stack.length - 1]
      const last = parent.items[parent.items.length - 1]
      if (last === undefined) {
        depth = stack.length - 1 // 异常缩进：压平到当前层级
      } else {
        if (last.children === null) last.children = { ordered: it.ordered, items: [] }
        stack.push(last.children)
      }
    }
    const cur = stack[stack.length - 1]
    cur.ordered = it.ordered
    cur.items.push({ check: it.check, text: it.text, children: null })
  }
  return root
}

function renderListTree(node, key) {
  return React.createElement(node.ordered ? 'ol' : 'ul', { key },
    node.items.map((item, i) => React.createElement('li', { key: key + 'li' + i },
      item.check !== null && item.check !== undefined
        ? React.createElement('span', { key: key + 'cb' + i },
          React.createElement('input', {
            type: 'checkbox', checked: item.check === true, disabled: true, readOnly: true,
            style: { pointerEvents: 'none' },
          }),
          mdInline(item.text, key + 't' + i),
        )
        : mdInline(item.text, key + 't' + i),
      item.children !== null && item.children.items.length > 0
        ? renderListTree(item.children, key + 'n' + i)
        : null,
    )),
  )
}

function renderTableEl(rows, key) {
  const parse = (ln) => ln.trim().replace(/^\|/, '').replace(/\|$/, '').split('|').map(c => c.trim())
  const head = parse(rows[0])
  const body = rows.slice(2).map(parse)
  return React.createElement('div', { key, className: 'bsm-md-table' },
    React.createElement('table', null,
      React.createElement('thead', null,
        React.createElement('tr', null, head.map((c, i) => React.createElement('th', { key: 'h' + i }, mdInline(c, key + 'h' + i))))),
      React.createElement('tbody', null,
        body.map((r, rn) => React.createElement('tr', { key: 'r' + rn },
          r.map((c, cn) => React.createElement('td', { key: 'c' + cn }, mdInline(c, key + 'c' + rn + '_' + cn))))) ),
    ),
  )
}

function mdBlocks(text, hardBreaks) {
  const lines = String(text).split('\n')
  const out = []
  let keyN = 0
  const K = () => 'b' + (keyN++)
  let para = []
  let code = []
  let inCode = false
  let quote = []
  const flushPara = () => {
    if (para.length) {
      out.push(React.createElement('p', { key: K(), style: hardBreaks ? { whiteSpace: 'pre-line' } : undefined },
        mdInline(hardBreaks ? para.join('\n') : para.join(' '), 'pt' + keyN)))
      para = []
    }
  }
  const flushQuote = () => {
    if (quote.length) {
      out.push(React.createElement('blockquote', { key: K() }, mdInline(quote.join('\n'), 'qt' + keyN)))
      quote = []
    }
  }
  let i = 0
  while (i < lines.length) {
    const line = lines[i]
    if (inCode) {
      if (line.trim().startsWith('```')) {
        out.push(renderCodeBlock(code, K()))
        code = []
        inCode = false
      } else {
        code.push(line)
      }
      i++
      continue
    }
    const trimmed = line.trim()
    if (trimmed.startsWith('```')) { flushPara(); flushQuote(); inCode = true; code = []; i++; continue }
    // 表格（段落为空时识别：首行含 | 且下一行是分隔行）
    if (para.length === 0 && quote.length === 0 && trimmed.indexOf('|') >= 0 && i + 1 < lines.length) {
      const sep = lines[i + 1] || ''
      if (/^\s*\|?\s*:?-{3,}:?\s*(\|\s*:?-{3,}:?\s*)+\|?\s*$/.test(sep.trim())) {
        const rows = []
        while (i < lines.length && lines[i].trim().indexOf('|') >= 0) { rows.push(lines[i]); i++ }
        out.push(renderTableEl(rows, K()))
        continue
      }
    }
    const h = trimmed.match(/^(#{1,6})\s+(.*)$/)
    if (h) {
      flushPara(); flushQuote()
      out.push(React.createElement('h' + h[1].length, { key: K() }, mdInline(h[2], 'ht' + keyN)))
      i++
      continue
    }
    if (/^([-*_])([ \t]*\1){2,}[ \t]*$/.test(trimmed)) { flushPara(); flushQuote(); out.push(React.createElement('hr', { key: K() })); i++; continue }
    const q = line.match(/^\s*>\s?(.*)$/)
    if (q) { flushPara(); quote.push(q[1]); i++; continue }
    if (quote.length > 0) flushQuote()
    const li = line.match(/^([ \t]*)([-*+]|\d+[.)])\s+(.*)$/)
    if (li) {
      flushPara()
      const items = []
      let j = i
      while (j < lines.length) {
        const ln = lines[j]
        const lm = ln.match(/^([ \t]*)([-*+]|\d+[.)])\s+(.*)$/)
        if (lm) {
          const indent = Math.floor(lm[1].replace(/\t/g, '  ').length / 2)
          const checkM = lm[3].match(/^\[([ xX])\]\s+(.*)$/)
          items.push({
            indent,
            ordered: /^\d/.test(lm[2]),
            check: checkM ? checkM[1] !== ' ' : null,
            text: checkM ? checkM[2] : lm[3],
          })
          j++
        } else if (/^[ \t]+\S/.test(ln) && items.length > 0) {
          const last = items[items.length - 1]
          last.text = last.text + '\n' + ln.trim()
          j++
        } else {
          break
        }
      }
      out.push(renderListTree(buildListTree(items), K()))
      i = j
      continue
    }
    if (trimmed === '') { flushPara(); i++; continue }
    para.push(line)
    i++
  }
  if (inCode) {
    out.push(renderCodeBlock(code, K()))
  }
  flushQuote()
  flushPara()
  return out
}

function MarkdownText(props) {
  return React.createElement('div', { className: 'bsm-md' }, mdBlocks(props.text, props.hardBreaks))
}

// 代码窗口：独立圆角框（纯内联样式，不依赖宿主样式服务）；行号列与代码列之间以竖线分割；长行不换行、横向溢出滚动
function renderCodeBlock(lines, key) {
  if (!lines.length) return null
  return React.createElement('div', {
    key,
    style: {
      margin: '14px 0',
      border: '1px solid var(--dsw-alias-border-l2)',
      borderRadius: '10px',
      background: 'var(--dsw-alias-markdown-inline-code)',
      overflow: 'hidden',
      boxShadow: '0 1px 3px rgba(0,0,0,0.08)',
    },
  },
    React.createElement('div', { style: { overflow: 'auto' } },
      React.createElement('div', {
        style: {
          display: 'flex',
          minWidth: 'max-content',
          fontFamily: 'var(--ds-font-family-code)',
          fontSize: '12px',
          lineHeight: 1.7,
        },
      },
        React.createElement('div', {
          style: {
            flexShrink: 0,
            padding: '10px 0',
            borderRight: '1px solid var(--dsw-alias-border-l2)',
            background: 'rgba(127,127,127,0.06)',
          },
        },
          lines.map((ln, i) => React.createElement('div', {
            key: 'n' + i,
            style: {
              whiteSpace: 'nowrap',
              padding: '0 14px 0 12px',
              textAlign: 'right',
              color: 'var(--dsw-alias-label-caption)',
              userSelect: 'none',
            },
          }, String(i + 1)))),
        React.createElement('div', {
          style: {
            padding: '10px 16px',
            whiteSpace: 'pre',
            wordBreak: 'normal',
            overflowWrap: 'normal',
          },
        }, lines.join('\n')),
      )),
  )
}

// ---------- 文本与节点辅助 ----------
function short(text, max) {
  const s = text === undefined || text === null ? '' : String(text)
  const t = s.replace(/\s+/g, ' ').trim()
  return t.length > max ? t.slice(0, max - 1) + '…' : t
}

function blockText(blocks) {
  if (!Array.isArray(blocks)) return ''
  let out = ''
  for (const b of blocks) {
    if (b && b.type === 'text' && typeof b.text === 'string') out += b.text
  }
  return out
}

function feedbackText(node) {
  if (!node || node.kind !== 'assistant' || !Array.isArray(node.blocks)) return ''
  return node.blocks.filter(b => b && b.kind === 'text').map(b => b.text).join('\n').trim()
}

function reasoningBlocks(node) {
  if (!node || !Array.isArray(node.blocks)) return []
  return node.blocks.filter(b => b && b.kind === 'reasoning')
}

// 工具名 → IconPark 图标键
function iconForTool(name) {
  const n = String(name || '')
  if (n.startsWith('read') || n === 'read_image') return 'BookOpen'
  if (n.startsWith('write') || n.startsWith('edit')) return 'Edit'
  if (n.startsWith('bash') || n.startsWith('subprocess') || n.startsWith('terminal') || n.startsWith('job_')) return 'Terminal'
  if (n.startsWith('glob') || n.startsWith('grep')) return 'Search'
  if (n.startsWith('web_')) return 'Globe'
  if (n.startsWith('cordis_')) return 'Plug'
  if (n.startsWith('todo')) return 'Checklist'
  if (n.startsWith('skill')) return 'Magic'
  if (n.startsWith('subagent') || n.startsWith('list_agents') || n.startsWith('send_message') || n.startsWith('interrupt_agent') || n.startsWith('ralph') || n.startsWith('workflow')) return 'Robot'
  if (n.startsWith('goal')) return 'Target'
  if (n.startsWith('ask_user')) return 'Help'
  return 'Application'
}

function fileName(p) {
  const parts = String(p || '').split('/')
  return parts[parts.length - 1] || String(p || '')
}

function cmdKinds(cmd) {
  const s = String(cmd || '').replace(/^\s*\$?\s*/, '')
  const parts = s.split(/[;&|]|\n/).map(x => x.trim()).filter(Boolean).slice(0, 3)
  const names = []
  for (const x of parts) {
    const m = x.match(/^(?:sudo\s+)?(?:env\s+[A-Z_]+=\S+\s+)*([a-zA-Z0-9._-]+)/)
    if (m) names.push(m[1])
  }
  return Array.from(new Set(names)).join('; ')
}

function toolSummary(name, argsRaw) {
  let args = null
  try { args = JSON.parse(argsRaw) } catch (error) { args = null }
  if (!args || typeof args !== 'object') return short(argsRaw, 50)
  switch (name) {
    case 'read':
    case 'read_image':
    case 'write':
    case 'edit':
      return fileName(args.file_path)
    case 'bash':
    case 'shell': {
      const kinds = cmdKinds(args.command)
      return kinds || short(String(args.command || ''), 50)
    }
    case 'grep':
      return short((args.pattern || '') + (args.path ? ' · ' + fileName(args.path) : ''), 48)
    case 'glob':
      return short(args.pattern || '', 48)
    case 'web_search':
      return short(args.query || '', 48)
    case 'web_fetch':
      return short(args.url || '', 48)
    case 'todo_write':
      return (Array.isArray(args.todos) ? args.todos.map(t => short(t && t.content, 20)).join('; ') : '').slice(0, 48)
    case 'skill':
      return short(args.name || '', 48)
    case 'cordis_define':
      return 'define ' + short(args.name || (args.plugin && args.plugin.idPrefix ? args.plugin.idPrefix : ''), 40)
    case 'cordis_run':
      return 'run ' + short(args.packageId || '', 30) + ' / ' + short(args.pluginId || '', 30)
    case 'cordis_stop':
    case 'cordis_undefine':
    case 'cordis_inspect_self':
      return short(args.pluginId || '', 48)
    case 'subagent':
    case 'subagent_fork':
    case 'ralph':
    case 'workflow':
      return short(args.description || (typeof args.prompt === 'string' ? args.prompt : ''), 48)
    case 'interrupt_agent':
    case 'list_agents':
    case 'send_message':
      return short(args.subagent_id || args.agent_id || '', 48)
    case 'job_output':
    case 'job_kill':
      return 'job ' + short(args.job_id || '', 40)
    case 'ask_user_question':
      return (Array.isArray(args.questions) ? args.questions.map(q => short(q && q.question, 24)).join('; ') : '').slice(0, 48)
    case 'create_goal':
    case 'update_goal':
    case 'get_goal':
      return short(args.objective || args.action || '', 48)
    default:
      return short(argsRaw, 50)
  }
}

// ---------- 步骤模型 ----------
function stepFor(node) {
  switch (node.kind) {
    case 'tool-result': {
      const name = node.call ? node.call.name : 'tool'
      return { key: 't' + node.seq, icon: iconForTool(name), title: name, summary: toolSummary(name, node.call ? node.call.argsRaw : ''), node }
    }
    case 'command':
      return { key: 'c' + node.seq, icon: 'Command', title: '/' + (node.name || '?'), summary: short(node.args || '', 60), node }
    case 'context':
      return { key: 'x' + node.seq, icon: 'DataAll', title: '上下文注入', summary: short(blockText(node.content), 60), node }
    case 'steering':
      return { key: 's' + node.seq, icon: 'Comment', title: '用户插话', summary: short(blockText(node.content), 60), node }
    case 'compaction':
      return { key: 'p' + node.seq, icon: 'Compression', title: '上下文压缩', summary: short(node.summary || '', 60), node }
    case 'turn-error':
      return { key: 'e' + node.seq, icon: 'Attention', title: '轮次错误', summary: '', node }
    case 'turn-max-tokens':
      return { key: 'm' + node.seq, icon: 'Attention', title: '达到令牌上限', summary: '', node }
    case 'model-retry':
      return { key: 'r' + node.seq, icon: 'Refresh', title: '模型重试', summary: '', node }
    case 'unknown':
      return { key: 'u' + node.seq, icon: 'Application', title: String(node.type || '未知'), summary: '', node }
    default:
      return { key: '?' + node.seq, icon: 'Application', title: String(node.kind || '节点'), summary: '', node }
  }
}

function thinkStep(seq, blocks) {
  return { key: 'th' + seq, icon: 'Brain', title: '思考', summary: short(blocks.map(b => b.text).join(' '), 60), node: { kind: 'think', seq, blocks } }
}

function toolHeadStep(callId, seq, name, argsRaw) {
  return { key: 'h' + callId, icon: iconForTool(name), title: name, summary: toolSummary(name, argsRaw), node: { kind: 'tool-call-head', seq, name, argsRaw } }
}

// ---------- 分组：节点 → 段落（指令 + 链条框[]） ----------
function groupSegments(nodes) {
  const segments = []
  let cur = { instruction: null, chains: [], pending: [] }
  const pushSeg = () => {
    if (cur.instruction || cur.chains.length || cur.pending.length) segments.push(cur)
  }
  for (const n of nodes) {
    if (n.kind === 'user') {
      pushSeg()
      cur = { instruction: n, chains: [], pending: [] }
    } else if (n.kind === 'assistant') {
      const fb = feedbackText(n)
      const reas = reasoningBlocks(n)
      const heads = (n.blocks || []).filter(b => b && b.kind === 'tool-call')
      if (fb !== '') {
        if (reas.length) cur.pending.push(thinkStep(n.seq, reas))
        for (const h of heads) {
          cur.pending.push(toolHeadStep(h.callId, n.seq, h.name, h.argsRaw || ''))
        }
        cur.chains.push({ steps: cur.pending, feedback: n })
        cur.pending = []
      } else if (reas.length) {
        cur.pending.push(thinkStep(n.seq, reas))
      }
    } else {
      cur.pending.push(stepFor(n))
    }
  }
  pushSeg()
  return segments
}

// ---------- 详情内容提取 ----------
function detailSections(step) {
  const n = step.node
  if (!n) return []
  if (n.kind === 'think') {
    return [{ label: '思考内容', text: (n.blocks || []).map(b => b.text).join('\n\n') }]
  }
  if (n.kind === 'tool-call-head') {
    return [{ label: '调用参数', text: n.argsRaw || '' }]
  }
  switch (n.kind) {
    case 'tool-result': {
      const out = []
      if (n.call && n.call.argsRaw) out.push({ label: '参数', text: n.call.argsRaw })
      const parts = []
      for (const b of (n.content || [])) {
        if (b && b.type === 'text' && typeof b.text === 'string') parts.push(b.text)
        else if (b && b.type) parts.push('[' + b.type + ']')
      }
      const text = parts.join('\n')
      out.push({ label: n.isError ? '输出（出错）' : '输出', text: text.length > 6000 ? text.slice(0, 5999) + '…(截断)' : text })
      if (n.error) out.push({ label: '错误', text: n.error.name + ' / ' + n.error.code })
      return out
    }
    case 'command': {
      const out = []
      if (n.args) out.push({ label: '参数', text: n.args })
      if (n.outcome && n.outcome.text) out.push({ label: n.outcome.kind === 'success' ? '结果' : '错误', text: n.outcome.text })
      return out
    }
    case 'context':
    case 'steering':
    case 'user':
      return [{ label: '内容', text: blockText(n.content) }]
    case 'compaction':
      return [{ label: '摘要', text: n.summary || '' }]
    default:
      return []
  }
}

// ---------- 样式 ----------
const S = {
  view: { padding: '12px 8px 40px 8px', display: 'flex', flexDirection: 'column', gap: '14px', fontSize: '13px' },
  bubble: { display: 'flex', flexDirection: 'column', gap: '8px' },
  bubbleBig: { border: '1px solid rgba(128,128,128,0.32)', borderRadius: '12px', padding: '10px 12px', display: 'flex', flexDirection: 'column', gap: '8px', background: 'rgba(128,128,128,0.03)' },
  instruction: { padding: '8px 12px', border: '1px solid rgba(128,128,128,0.35)', borderRadius: '10px', background: 'rgba(128,128,128,0.08)', alignSelf: 'flex-end', maxWidth: '82%', whiteSpace: 'pre-wrap', wordBreak: 'break-word' },
  chain: { border: '1px solid rgba(128,128,128,0.28)', borderRadius: '10px', padding: '8px', display: 'flex', flexDirection: 'column', gap: '6px' },
  chainHead: { display: 'flex', alignItems: 'center', gap: '8px', cursor: 'pointer', userSelect: 'none', color: 'rgba(128,128,128,0.9)', minWidth: 0 },
  chainNames: { fontFamily: 'ui-monospace, monospace', fontSize: '11px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', flex: 1, minWidth: 0 },
  chainSteps: { display: 'flex', flexWrap: 'wrap', gap: '6px' },
  step: { display: 'inline-flex', alignItems: 'center', gap: '6px', border: '1px solid rgba(128,128,128,0.4)', borderRadius: '8px', padding: '3px 8px', cursor: 'pointer', background: 'transparent', fontSize: '12px' },
  stepIcon: { color: '#6366f1' },
  stepTitle: { fontWeight: 500 },
  feedback: { padding: '8px 12px', borderRadius: '10px', lineHeight: 1.55, cursor: 'pointer' },
  feedbackPlain: { background: 'rgba(128,128,128,0.06)' },
  feedbackHi: { background: 'rgba(59,130,246,0.10)', border: '1px solid rgba(59,130,246,0.35)', fontWeight: 500 },
  detail: { margin: '4px 0 2px 4px', padding: '8px 10px', border: '1px dashed rgba(128,128,128,0.4)', borderRadius: '8px', display: 'flex', flexDirection: 'column', gap: '6px' },
  detailLabel: { fontSize: '11px', fontWeight: 700, color: 'rgba(128,128,128,0.95)', textTransform: 'uppercase' },
  detailText: { whiteSpace: 'pre-wrap', wordBreak: 'break-word', fontFamily: 'ui-monospace, monospace', fontSize: '12px', maxHeight: '360px', overflow: 'auto' },
  pending: { opacity: 0.85, fontStyle: 'italic', color: 'rgba(128,128,128,0.9)' },
  actions: { display: 'flex', alignItems: 'center', gap: '2px', marginTop: '2px', opacity: 0.85 },
  iconBtn: { display: 'inline-flex', alignItems: 'center', justifyContent: 'center', width: 22, height: 22, padding: 0, border: 'none', background: 'transparent', cursor: 'pointer', borderRadius: '5px' },
  iconBtnOn: { color: '#3b82f6' },
}

const SUB = {
  chips: { display: 'flex', flexWrap: 'wrap', gap: '8px', padding: '4px 0' },
  card: { border: '1px solid rgba(99,102,241,0.45)', borderRadius: '10px', padding: '6px 10px', background: 'rgba(99,102,241,0.05)', display: 'flex', flexDirection: 'column', gap: '6px', maxWidth: 560 },
  cardHead: { display: 'flex', alignItems: 'center', gap: '6px', cursor: 'pointer', userSelect: 'none' },
  cardTitle: { fontSize: '12px', fontWeight: 600 },
  cardFoot: { display: 'flex', alignItems: 'center', gap: '8px', flexWrap: 'wrap' },
  chipState: { fontSize: '11px', color: 'rgba(128,128,128,0.9)' },
}

const BTW = {
  card: { border: '1px dashed rgba(234,179,8,0.6)', borderRadius: '10px', padding: '8px 10px', background: 'rgba(234,179,8,0.06)', display: 'flex', flexDirection: 'column', gap: '6px', maxWidth: 560 },
  head: { display: 'flex', alignItems: 'center', gap: '6px', cursor: 'pointer', userSelect: 'none' },
  question: { fontSize: '12px', fontWeight: 600 },
  answer: { whiteSpace: 'pre-wrap', wordBreak: 'break-word', fontSize: '12px', maxHeight: 240, overflow: 'auto', padding: '6px 8px', borderRadius: '8px', background: 'rgba(128,128,128,0.06)' },
  foot: { display: 'flex', alignItems: 'center', gap: '8px', flexWrap: 'wrap' },
}

const UTIL = {
  row: { display: 'inline-flex', alignItems: 'center', gap: '6px', fontSize: '12px' },
  label: { color: 'rgba(128,128,128,0.9)' },
  btn: { display: 'inline-flex', alignItems: 'center', gap: '4px', border: '1px solid rgba(128,128,128,0.4)', borderRadius: '6px', padding: '2px 8px', cursor: 'pointer', background: 'transparent', fontSize: '12px' },
}

const TOAST = {
  root: { position: 'absolute', bottom: 24, right: 24, maxWidth: 420, padding: '10px 14px', borderRadius: '10px', background: 'rgba(30,30,35,0.96)', color: '#e8e8e8', border: '1px solid rgba(99,102,241,0.6)', fontSize: '13px', boxShadow: '0 8px 24px rgba(0,0,0,0.35)', pointerEvents: 'auto' },
}

// 左侧会话栏样式（sidebar.workspaces：工作区 > 会话 > 子会话）
const SB = {
  root: { display: 'flex', flexDirection: 'column', height: '100%', color: '#e8e8e8', fontSize: '12px', minHeight: 0 },
  head: { padding: '8px 12px 2px', fontWeight: 700, fontSize: '12px', letterSpacing: '0.4px', color: 'rgba(200,200,210,0.85)' },
  input: { margin: '4px 12px 8px', padding: '4px 8px', borderRadius: '8px', border: '1px solid rgba(128,128,128,0.35)', background: 'rgba(128,128,128,0.08)', color: '#e8e8e8', fontSize: '12px', outline: 'none' },
  body: { flex: 1, overflow: 'auto', padding: '0 8px 12px', display: 'flex', flexDirection: 'column', gap: '1px', minHeight: 0 },
  rowWrap: { display: 'flex', alignItems: 'center', borderRadius: '6px' },
  foldBtn: { width: 18, height: 24, padding: 0, border: 'none', background: 'transparent', color: 'rgba(180,180,200,0.9)', fontSize: 10, cursor: 'pointer', flexShrink: 0, display: 'inline-flex', alignItems: 'center', justifyContent: 'center' },
  openBtn: { display: 'flex', alignItems: 'center', gap: 6, padding: '5px 0', border: 'none', background: 'transparent', color: '#e8e8e8', fontSize: '12px', textAlign: 'left', cursor: 'pointer', flex: 1, minWidth: 0, borderRadius: 6 },
  act: { display: 'inline-flex', alignItems: 'center', justifyContent: 'center', width: 20, height: 20, padding: 0, border: 'none', background: 'transparent', color: 'rgba(200,200,210,0.9)', cursor: 'pointer', borderRadius: 4 },
  dot: { width: 7, height: 7, borderRadius: '50%', flexShrink: 0 },
  title: { flex: 1, minWidth: 0, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' },
  empty: { color: 'rgba(200,200,200,0.6)', padding: '8px 6px' },
  wsRow: { display: 'flex', alignItems: 'center', gap: 6, padding: '5px 6px', borderRadius: 6, cursor: 'pointer', color: 'rgba(210,210,225,0.95)', fontWeight: 600 },
  wsIcon: { color: '#c8a24a' },
}

// ---------- 子组件 ----------
function StepBox(props) {
  const [open, setOpen] = React.useState(false)
  const sections = open ? detailSections(props.step) : []
  return React.createElement('div', { style: { display: 'flex', flexDirection: 'column' } },
    React.createElement('button', {
      type: 'button',
      style: S.step,
      title: props.step.summary,
      onClick: () => setOpen(v => !v),
    },
      React.createElement('span', { style: S.stepIcon }, React.createElement(Icon, { name: props.step.icon, size: 14 })),
      React.createElement('span', { style: S.stepTitle }, props.step.title),
      props.step.summary ? React.createElement('span', { style: { color: 'rgba(128,128,128,0.75)', fontSize: '11px', maxWidth: '280px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' } }, props.step.summary) : null,
    ),
    open ? React.createElement('div', { style: S.detail },
      sections.map((sec, i) => React.createElement('div', { key: i },
        React.createElement('div', { style: S.detailLabel }, sec.label),
        React.createElement('div', { style: S.detailText }, sec.text === '' ? '（无内容）' : sec.text),
      )),
    ) : null,
  )
}

function ChainBox(props) {
  const chain = props.chain
  const [open, setOpen] = React.useState(!props.defaultCollapsed)
  const count = chain.steps.length
  const names = chain.steps.map(s => s.title).join(' → ')
  return React.createElement('div', { style: S.chain },
    React.createElement('div', { style: S.chainHead, onClick: () => setOpen(v => !v), title: names },
      React.createElement('span', null, open ? '▾' : '▸'),
      React.createElement('span', { style: { flexShrink: 0 } }, '插件链 ' + count + ' 步'),
      React.createElement('span', { style: S.chainNames }, names),
    ),
    open ? React.createElement('div', { style: S.chainSteps },
      chain.steps.map(s => React.createElement(StepBox, { key: s.key, step: s })),
    ) : null,
  )
}

function Feedback(props) {
  const md = usePref('mdRender')
  const style = Object.assign({}, S.feedback, props.highlight ? S.feedbackHi : S.feedbackPlain)
  return React.createElement('div', { style, onClick: props.onClick, title: props.title },
    md ? React.createElement(MarkdownText, { text: props.text }) : props.text,
  )
}

// 反馈操作条：复制 / 分支 / 创建子会话 / 点赞 / 点踩（与对话视图功能对齐）
function FeedbackActions(props) {
  const store = useBsmStore()
  const sessionId = props.sessionId
  const [busySub, setBusySub] = React.useState(false)
  React.useEffect(() => { if (sessionId) void refreshFeedbacks(sessionId) }, [sessionId])
  const fb = (store.feedbacks[sessionId] || {}).items || []
  const item = fb.find(i => i.messageId === props.messageId) || null
  const active = item ? item.rating : null
  const put = (rating) => {
    bsmCall('feedbackPut', {
      sessionId, messageId: props.messageId, rating,
      ifVersion: item ? item.version : null,
    }).then(res => {
      if (res && res.ok) void refreshFeedbacks(sessionId, true)
      else bsmNotice('反馈失败：' + (res && res.error ? res.error : '未知错误'))
    })
  }
  const copy = () => {
    if (typeof navigator !== 'undefined' && navigator.clipboard && typeof navigator.clipboard.writeText === 'function') {
      navigator.clipboard.writeText(props.text).then(
        () => bsmNotice('已复制'),
        () => bsmNotice('复制失败'),
      )
    } else {
      bsmNotice('当前环境不支持复制')
    }
  }
  // 分支与子会话共用一条自有创建路径（不再调用 DSH 官方 fork RPC）：
  // 分支 = mode 'full'（复制边界前全部历史）；子会话 = prefs.subMode。
  // 两者的子会话均以普通会话身份创建（无 subagent origin），不会触发任何自动上下文注入。
  const createSubWith = (mode, label) => {
    if (busySub) return
    setBusySub(true)
    bsmCall('subCreate', { sessionId, boundarySeq: props.boundarySeq, mode, ...(label ? { label } : {}) }).then(res => {
      setBusySub(false)
      if (res && res.ok) {
        void refreshSubs(sessionId, true)
        if (sessionsSvcRef && typeof sessionsSvcRef.open === 'function') sessionsSvcRef.open(res.childId)
        const t = res.timings
        bsmNotice((label ? label + '已创建并打开：' : '子会话已创建并打开：') + res.childId + (t ? (res.mode === 'full' ? '（完整 fork ' : '（转录种子 ') + t.seedMs + 'ms / 共 ' + t.totalMs + 'ms）' : ''))
      } else {
        bsmNotice((label ? label + '创建失败：' : '创建子会话失败：') + (res && res.error ? res.error : '未知错误'))
      }
    })
  }
  const fork = () => createSubWith('full', '分支')
  const createSub = () => createSubWith(prefs.subMode, null)
  return React.createElement('div', { style: S.actions },
    React.createElement('button', { type: 'button', style: S.iconBtn, title: '复制', onClick: copy }, React.createElement(Icon, { name: 'Copy', size: 14 })),
    React.createElement('button', { type: 'button', style: S.iconBtn, title: busySub ? '创建中…' : '在新会话中分支', onClick: fork }, React.createElement(Icon, { name: 'Branch', size: 14 })),
    React.createElement('button', { type: 'button', style: S.iconBtn, title: busySub ? '创建中…' : '创建子会话', onClick: createSub }, React.createElement(Icon, { name: 'AddSubset', size: 14 })),
    React.createElement('button', { type: 'button', style: Object.assign({}, S.iconBtn, active === 'positive' ? S.iconBtnOn : null), title: '点赞', onClick: () => put('positive') }, React.createElement(Icon, { name: 'ThumbsUp', size: 14 })),
    React.createElement('button', { type: 'button', style: Object.assign({}, S.iconBtn, active === 'negative' ? S.iconBtnOn : null), title: '点踩', onClick: () => put('negative') }, React.createElement(Icon, { name: 'ThumbsDown', size: 14 })),
  )
}

// 气泡（方案 A：大气泡交错；方案 B：每链条一个气泡）
function Bubble(props) {
  const defaultCollapsed = usePref('chainCollapsed')
  const highlight = usePref('feedbackHighlight')
  const md = usePref('mdRender')
  const [collapsed, setCollapsed] = React.useState(defaultCollapsed)
  const chains = props.chains
  const hasChains = chains.length > 0
  const lastFeedback = hasChains ? chains[chains.length - 1].feedback : null
  const big = props.big === true
  const toggle = () => setCollapsed(v => !v)

  const feedbackEl = (node, key) => {
    const text = feedbackText(node)
    const seq = node && Number.isSafeInteger(node.seq) ? node.seq : 0
    return React.createElement('div', { key },
      React.createElement(Feedback, {
        text,
        highlight,
        onClick: toggle,
        title: collapsed ? '展开插件链' : '折叠为最后反馈',
      }),
      node && node.messageId ? React.createElement(FeedbackActions, {
        sessionId: props.sessionId,
        messageId: node.messageId,
        text,
        boundarySeq: props.boundarySeq,
        seq,
      }) : null,
    )
  }

  let body = null
  if (!collapsed) {
    const items = []
    for (let i = 0; i < chains.length; i++) {
      const c = chains[i]
      items.push(React.createElement(ChainBox, { key: 'ch' + i, chain: c, defaultCollapsed }))
      if (c.feedback) items.push(feedbackEl(c.feedback, 'fb' + i))
    }
    body = items
  } else if (lastFeedback) {
    body = [feedbackEl(lastFeedback, 'fb-last')]
  }

  if (props.liveTail) {
    body = (body || []).concat([React.createElement('div', { key: 'live', style: S.chain },
      React.createElement('div', { style: S.chainHead }, React.createElement('span', null, '▾'), React.createElement('span', null, '进行中')),
      React.createElement('div', { style: S.chainSteps }, props.liveTail),
    )])
  }

  const container = big ? S.bubbleBig : S.bubble
  return React.createElement('div', { style: container },
    props.instruction ? React.createElement('div', { style: S.instruction },
      md ? React.createElement(MarkdownText, { text: blockText(props.instruction.content), hardBreaks: true })
        : short(blockText(props.instruction.content), 2000)) : null,
    body || null,
    hasChains && !lastFeedback && !props.liveTail && !collapsed ? React.createElement('div', { style: S.pending }, '…运行中') : null,
  )
}

// ---------- M2/M3：btw 卡片（问题+回答内联，销毁/创建子会话/发送给主会话） ----------
function BtwCard(props) {
  const sessionId = props.sessionId
  const entry = props.entry
  const md = usePref('mdRender')
  const [open, setOpen] = React.useState(true)
  const [answer, setAnswer] = React.useState('')
  const [meta, setMeta] = React.useState(null)
  const [err, setErr] = React.useState(null)
  const [busyD, setBusyD] = React.useState(false)
  const [busyP, setBusyP] = React.useState(false)
  const running = entry.activity === 'running'
  const question = entry.label ? String(entry.label).replace(/^btw:\s*/, '') : ''
  const loadAnswer = () => {
    bsmCall('btwAnswer', { childSessionId: entry.id }).then(res => {
      if (res && res.ok) {
        setAnswer(res.text || '')
        setMeta({ startedMs: res.startedMs, doneMs: res.doneMs })
        setErr(res.error || null)
      }
    })
  }
  // 回答为空时持续轮询（尾部增量读取，代价小）；手动刷新兜底
  React.useEffect(() => {
    void loadAnswer()
    if (timerSvcRef && typeof timerSvcRef.interval === 'function') {
      const dispose = timerSvcRef.interval(() => { void loadAnswer() }, 4000)
      return () => { dispose() }
    }
    return undefined
  }, [])
  const destroy = () => {
    if (busyD) return
    setBusyD(true)
    bsmCall('btwDestroy', { childSessionId: entry.id }).then(res => {
      setBusyD(false)
      if (res && res.ok) {
        bsmNotice('btw 对话已销毁')
        void refreshSubs(sessionId, true)
      } else {
        bsmNotice('销毁失败：' + (res && res.error ? res.error : '未知错误'))
      }
    })
  }
  const promote = () => {
    if (busyP) return
    setBusyP(true)
    bsmCall('btwPromote', { parentSessionId: sessionId, childSessionId: entry.id, mode: prefs.subMode }).then(res => {
      setBusyP(false)
      if (res && res.ok) {
        bsmNotice(res.inheritedTranscript === true ? '已基于 btw 创建子会话（注入完整 btw 问答转录）' : '已基于 btw 创建子会话')
        void refreshSubs(sessionId, true)
        openChild({ id: res.newChildId, kind: 'fork' }, sessionId)
      } else {
        bsmNotice('创建子会话失败：' + (res && res.error ? res.error : '未知错误'))
      }
    })
  }
  const sendToMain = () => {
    bsmCall('subInject', { parentSessionId: sessionId, childSessionId: entry.id, template: 'brief' }).then(res => {
      if (res && res.ok) bsmNotice('btw 摘要已发送到主会话')
      else bsmNotice('发送失败：' + (res && res.error ? res.error : '未知错误'))
    })
  }
  return React.createElement('div', { style: BTW.card },
    React.createElement('div', { style: BTW.head, onClick: () => setOpen(v => !v) },
      React.createElement(Icon, { name: 'Comment', size: 14, color: '#ca8a04' }),
      React.createElement('span', { style: BTW.question }, 'btw · ' + short(question, 60)),
      running ? React.createElement('span', { style: SUB.chipState }, '回答中…') : null,
      meta && meta.doneMs !== undefined && meta.doneMs !== null && !running
        ? React.createElement('span', { style: SUB.chipState, title: 'fork 启动 ' + (meta.startedMs || 0) + 'ms，总耗时 ' + meta.doneMs + 'ms' }, '回答耗时 ' + (meta.doneMs / 1000).toFixed(1) + 's')
        : null,
      React.createElement('span', { style: { marginLeft: 'auto', fontSize: '11px', color: 'rgba(128,128,128,0.8)' } }, open ? '▴ 收起' : '▾ 展开回答'),
    ),
    open ? React.createElement('div', { style: BTW.answer },
      answer === ''
        ? (running ? '（等待回答…）' : (err !== null && err !== undefined ? '（btw 异常：' + err + '）' : '（暂无回答，可点击下方刷新重试）'))
        : (md ? React.createElement(MarkdownText, { text: answer }) : answer),
    ) : null,
    React.createElement('div', { style: BTW.foot },
      React.createElement('button', { type: 'button', style: UTIL.btn, onClick: () => void loadAnswer(), title: '重新读取回答' }, '刷新'),
      React.createElement('button', { type: 'button', style: UTIL.btn, disabled: busyD, onClick: destroy, title: '销毁该 btw 问答记录' }, '销毁'),
      React.createElement('button', { type: 'button', style: UTIL.btn, disabled: busyP, onClick: promote, title: '基于该 btw 问答创建子会话继续工作' }, '创建子会话'),
      React.createElement('button', { type: 'button', style: UTIL.btn, onClick: sendToMain, title: '将 btw 摘要压缩发送到主会话' }, '发送给主会话'),
    ),
  )
}

function SubCard(props) {
  const sessionId = props.sessionId
  const entry = props.entry
  const [open, setOpen] = React.useState(false)
  const title = entry.label || '子会话'
  const running = entry.running === true || entry.activity === 'running'
  const inject = (template) => {
    bsmCall('subInject', { parentSessionId: sessionId, childSessionId: entry.id, template }).then(res => {
      if (res && res.ok) bsmNotice('子会话摘要已注入主会话')
      else bsmNotice('注入失败：' + (res && res.error ? res.error : '未知错误'))
    })
  }
  return React.createElement('div', { style: SUB.card },
    React.createElement('div', { style: SUB.cardHead, onClick: () => setOpen(v => !v) },
      React.createElement(Icon, { name: 'BranchTwo', size: 14, color: '#6366f1' }),
      React.createElement('span', { style: SUB.cardTitle }, short(title, 44)),
      running ? React.createElement('span', { style: SUB.chipState }, '运行中') : null,
      React.createElement('span', { style: { marginLeft: 'auto', fontSize: '11px', color: 'rgba(128,128,128,0.8)' } }, open ? '▴ 收起操作' : '▾ 操作'),
    ),
    open ? React.createElement('div', { style: SUB.cardFoot },
      React.createElement('button', { type: 'button', style: UTIL.btn, onClick: () => openChild(entry, sessionId), title: '打开该子会话继续工作' }, '打开子会话'),
      React.createElement('button', { type: 'button', style: UTIL.btn, onClick: () => inject('brief'), title: '压缩子会话上下文并注入主会话（简洁摘要）' }, '注入·简洁'),
      React.createElement('button', { type: 'button', style: UTIL.btn, onClick: () => inject('detailed'), title: '压缩子会话上下文并注入主会话（详细纪要）' }, '注入·详细'),
      React.createElement('button', { type: 'button', style: UTIL.btn, onClick: () => inject('actions'), title: '压缩子会话上下文并注入主会话（结论+行动项）' }, '注入·行动项'),
    ) : null,
  )
}

function SubBubbles(props) {
  const sessionId = props.sessionId
  const store = useBsmStore()
  const turn = props.matched ? props.matched.turn : undefined
  const turnEnds = props.useSession(s => (s && s.turnEnds) || null)
  React.useEffect(() => {
    if (sessionId) {
      watchSubs(sessionId)
      void refreshSubs(sessionId)
    }
  }, [sessionId])
  if (!sessionId || turn === undefined) return null
  const boundarySeq = turnEnds ? turnEnds.get(turn) : undefined
  if (boundarySeq === undefined) return null
  const rec = store.subs[sessionId]
  const subs = rec && Array.isArray(rec.subs) ? rec.subs : []
  const btws = rec && Array.isArray(rec.btws) ? rec.btws : []
  const hereSubs = subs.filter(e => e.boundarySeq === boundarySeq)
  // btw 卡片：显示在最后一个轮次尾部（创建时机在轮次内部，边界不可预测）
  let lastBoundary = null
  if (turnEnds) {
    for (const b of turnEnds.values()) {
      if (lastBoundary === null || b > lastBoundary) lastBoundary = b
    }
  }
  const hereBtws = boundarySeq === lastBoundary ? btws : btws.filter(e => e.boundarySeq === boundarySeq)
  if (hereSubs.length === 0 && hereBtws.length === 0) return null
  return React.createElement('div', { style: SUB.chips },
    hereBtws.map(e => React.createElement(BtwCard, { key: 'btw' + e.id, sessionId, entry: e })),
    hereSubs.map(e => React.createElement(SubCard, { key: 'sub' + e.id, sessionId, entry: e })),
  )
}

// ---------- 链条视图主体 ----------
function ChainView(props) {
  const mode = usePref('mode')
  const mdWidth = usePref('mdWidth')
  const store = useBsmStore()
  const snapshot = props.useSession(s => s)
  if (!snapshot || !Array.isArray(snapshot.nodes)) return null
  React.useEffect(() => {
    if (snapshot.sessionId) {
      watchSubs(snapshot.sessionId)
      void refreshSubs(snapshot.sessionId, true)
    }
  }, [snapshot.sessionId])

  // 打开会话时定位到末尾（最新上下文）；「加载更早」向前追加时保持当前阅读位置
  const viewRef = React.useRef(null)
  const lastScrolledSession = React.useRef(null)
  const pendingAnchor = React.useRef(null)
  const scrollportOf = (el) => {
    if (el === null) return null
    let node = el
    while (node !== null && node.parentElement !== null) {
      if (node.scrollHeight > node.clientHeight + 4) {
        let oy = 'visible'
        try { oy = getComputedStyle(node).overflowY } catch (error) { /* ignore */ }
        if (oy === 'auto' || oy === 'scroll') return node
      }
      node = node.parentElement
    }
    return null
  }
  React.useEffect(() => {
    const sid = snapshot.sessionId
    if (!sid || !Array.isArray(snapshot.nodes) || snapshot.nodes.length === 0) return
    if (lastScrolledSession.current === sid) return
    lastScrolledSession.current = sid
    const sp = scrollportOf(viewRef.current)
    if (sp !== null) {
      sp.scrollTop = sp.scrollHeight
    } else if (typeof window !== 'undefined' && window.document && window.document.body) {
      try { window.scrollTo(0, window.document.body.scrollHeight) } catch (error) { /* ignore */ }
    }
  }, [snapshot.sessionId, snapshot.nodes])

  const segments = React.useMemo(() => groupSegments(snapshot.nodes), [snapshot.nodes])

  let liveTail = null
  if (snapshot.running) {
    const items = []
    for (const c of (snapshot.runningCalls || [])) {
      items.push(React.createElement('span', { key: 'rc' + c.callId, style: Object.assign({}, S.step, S.pending) },
        React.createElement('span', { style: S.stepIcon }, React.createElement(Icon, { name: iconForTool(c.name), size: 14 })),
        React.createElement('span', { style: S.stepTitle }, c.name),
      ))
    }
    if (snapshot.partial && Array.isArray(snapshot.partial.blocks)) {
      const reas = snapshot.partial.blocks.filter(b => b && b.kind === 'reasoning')
      const text = snapshot.partial.blocks.filter(b => b && b.kind === 'text')
      if (reas.length) items.push(React.createElement('span', { key: 'p-th', style: Object.assign({}, S.step, S.pending) },
        React.createElement('span', { style: S.stepIcon }, React.createElement(Icon, { name: 'Brain', size: 14 })),
        React.createElement('span', null, '思考…'),
      ))
      if (text.length) items.push(React.createElement('span', { key: 'p-tx', style: Object.assign({}, S.step, S.pending) },
        React.createElement('span', { style: S.stepIcon }, React.createElement(Icon, { name: 'Comment', size: 14 })),
        React.createElement('span', null, '回答…'),
      ))
    }
    if (items.length) liveTail = items
  }

  // boundarySeq 映射：feedback 节点的轮次 → turn/end seq
  const boundaryOf = (node) => {
    if (!node || !Number.isSafeInteger(node.turn)) return null
    const b = snapshot.turnEnds.get(node.turn)
    return b === undefined ? null : b
  }

  const bubbles = []
  for (const seg of segments) {
    const endTurn = seg.chains.length && seg.chains[seg.chains.length - 1].feedback
      ? seg.chains[seg.chains.length - 1].feedback.turn
      : null
    if (mode === 'B') {
      const n = Math.max(seg.chains.length, 1)
      for (let i = 0; i < n; i++) {
        bubbles.push({ instruction: i === 0 ? seg.instruction : null, chains: seg.chains.slice(i, i + 1), endTurn: i === n - 1 ? endTurn : null })
      }
      if (seg.chains.length === 0) bubbles.push({ instruction: seg.instruction, chains: [], endTurn: null })
    } else {
      bubbles.push({ instruction: seg.instruction, chains: seg.chains, endTurn })
    }
  }
  const last = bubbles[bubbles.length - 1]

  const btwRec = store.subs[snapshot.sessionId]
  const activeBtws = btwRec && Array.isArray(btwRec.btws) ? btwRec.btws : []
  const activeSubs = btwRec && Array.isArray(btwRec.subs) ? btwRec.subs : []

  // btw/子会话卡片嵌入位置（两视图统一语义：贴在「边界轮次」尾部）：
  // boundarySeq = 创建时的 turn/end；找到对应轮次后把卡片贴在该轮气泡之后；找不到则贴末尾。
  const turnEntries = []
  if (snapshot.turnEnds) {
    for (const [t, b] of snapshot.turnEnds.entries()) turnEntries.push({ turn: t, end: b })
    turnEntries.sort((a, b) => a.end - b.end)
  }
  const placeByBoundary = (entries) => {
    const placement = new Map() // 'turn:<t>' 或 'end' -> entries[]
    for (const e of entries) {
      let key = 'end'
      if (e.boundarySeq !== undefined && e.boundarySeq !== null) {
        const idx = turnEntries.findIndex(t => t.end === e.boundarySeq)
        if (idx >= 0) key = 'turn:' + turnEntries[idx].turn
      }
      if (!placement.has(key)) placement.set(key, [])
      placement.get(key).push(e)
    }
    return placement
  }
  const btwPlacement = placeByBoundary(activeBtws)
  const subPlacement = placeByBoundary(activeSubs)

  const btwChips = (list) => list.length > 0 ? React.createElement('div', { style: SUB.chips },
    list.map(e => React.createElement(BtwCard, { key: 'btw' + e.id, sessionId: snapshot.sessionId, entry: e })),
  ) : null
  const subChips = (list) => list.length > 0 ? React.createElement('div', { style: SUB.chips },
    list.map(e => React.createElement(SubCard, { key: 'sub' + e.id, sessionId: snapshot.sessionId, entry: e })),
  ) : null

  const viewStyle = Object.assign({}, S.view)
  const widthPx = MD_WIDTH[mdWidth]
  if (widthPx > 0) {
    viewStyle.maxWidth = widthPx
    viewStyle.margin = '0 auto'
    viewStyle.width = '100%'
  }

  const content = []
  for (let i = 0; i < bubbles.length; i++) {
    const b = bubbles[i]
    content.push(React.createElement(Bubble, {
      key: 'b' + i,
      sessionId: snapshot.sessionId,
      instruction: b.instruction,
      chains: b.chains,
      boundarySeq: b.chains.length && b.chains[b.chains.length - 1].feedback ? boundaryOf(b.chains[b.chains.length - 1].feedback) : null,
      liveTail: b === last ? liveTail : null,
      big: mode === 'A',
    }))
    if (b.endTurn !== null && b.endTurn !== undefined) {
      const placeB = btwPlacement.get('turn:' + b.endTurn)
      if (placeB && placeB.length) content.push(React.createElement('div', { key: 'btwp' + i }, btwChips(placeB)))
      const placeS = subPlacement.get('turn:' + b.endTurn)
      if (placeS && placeS.length) content.push(React.createElement('div', { key: 'subp' + i }, subChips(placeS)))
    }
  }
  if (liveTail && bubbles.length === 0) {
    content.push(React.createElement(Bubble, { key: 'b-live', sessionId: snapshot.sessionId, instruction: null, chains: [], boundarySeq: null, liveTail, big: mode === 'A' }))
  }
  const tailBtws = btwPlacement.get('end') || []
  if (tailBtws.length) content.push(React.createElement('div', { key: 'btw-end' }, btwChips(tailBtws)))
  const tailSubs = subPlacement.get('end') || []
  if (tailSubs.length) content.push(React.createElement('div', { key: 'sub-end' }, subChips(tailSubs)))
  if (content.length === 0) {
    content.push(React.createElement('div', { key: 'empty', style: { color: 'rgba(128,128,128,0.7)', padding: '24px', textAlign: 'center' } }, '（暂无内容）'))
  }

  // 顶部「加载更早」：conversation.view 槽位不含 loadOlder 标准 prop，
  // 真正的历史分页在 sessions 服务的 SessionBinding.session（SessionFace.loadOlder）；
  // 点击前记录滚动高度，追加页后补偿 scrollTop，保持阅读位置。
  const hasMore = snapshot.hasMore === true
  const loadingOlder = snapshot.loadingOlder === true
  const loadOlderAnchored = () => {
    const sp = scrollportOf(viewRef.current)
    if (sp !== null) pendingAnchor.current = { el: sp, height: sp.scrollHeight }
    const binding = sessionsSvcRef && typeof sessionsSvcRef.binding === 'function'
      ? sessionsSvcRef.binding(snapshot.sessionId)
      : undefined
    const face = binding && binding.session
    if (face && typeof face.loadOlder === 'function') {
      void face.loadOlder()
    } else {
      bsmNotice('当前会话不支持加载更早历史')
    }
  }
  React.useEffect(() => {
    if (!loadingOlder && pendingAnchor.current !== null) {
      const { el, height } = pendingAnchor.current
      pendingAnchor.current = null
      el.scrollTop = el.scrollTop + (el.scrollHeight - height)
    }
  }, [loadingOlder, snapshot.nodes])
  const olderBtn = (hasMore || loadingOlder)
    ? React.createElement('div', { key: 'older', style: { display: 'flex', justifyContent: 'center', padding: '2px 0 10px' } },
      React.createElement('button', {
        type: 'button',
        style: UTIL.btn,
        disabled: loadingOlder,
        onClick: loadOlderAnchored,
        title: '加载更早的历史上下文',
      }, loadingOlder ? '加载中…' : '加载更早'),
    )
    : null

  return React.createElement('div', { style: viewStyle, ref: viewRef }, olderBtn, content)
}

// ---------- M2：创建子会话按钮（助手消息操作条，纯图标；创建后自动打开） ----------
function CreateSubAction(props) {
  const sessionId = props.sessionId
  const messageId = props.messageId
  const [busy, setBusy] = React.useState(false)
  const boundarySeq = props.useSession(s => {
    if (!s || !Array.isArray(s.nodes) || !messageId) return null
    const node = s.nodes.find(n => n.kind === 'assistant' && n.messageId === messageId)
    if (!node) return null
    const b = s.turnEnds.get(node.turn)
    return b === undefined ? null : b
  })
  if (!sessionId || !boundarySeq) return null
  const create = () => {
    if (busy) return
    setBusy(true)
    bsmCall('subCreate', { sessionId, boundarySeq, mode: prefs.subMode }).then(res => {
      setBusy(false)
      if (res && res.ok) {
        void refreshSubs(sessionId, true)
        if (sessionsSvcRef && typeof sessionsSvcRef.open === 'function') sessionsSvcRef.open(res.childId)
        const t = res.timings
        bsmNotice('子会话已创建并打开：' + res.childId + (t ? (res.mode === 'full' ? '（完整 fork ' : '（转录种子 ') + t.seedMs + 'ms / 共 ' + t.totalMs + 'ms）' : ''))
      } else {
        bsmNotice('创建子会话失败：' + (res && res.error ? res.error : '未知错误'))
      }
    })
  }
  return React.createElement('button', {
    type: 'button',
    style: S.iconBtn,
    disabled: busy,
    onClick: create,
    title: busy ? '创建中…' : '创建子会话（继承此处之前的上下文）',
  },
    React.createElement(Icon, { name: 'AddSubset', size: 14 }),
  )
}

// ---------- M2：会话头工具（子会话内：压缩注入主会话） ----------
function BsmSessionUtility(props) {
  const sessionId = props.sessionId
  const sub = props.useSession(s => (s && s.subagent) || null)
  const [busy, setBusy] = React.useState(false)
  const [forkParentId, setForkParentId] = React.useState(null)
  React.useEffect(() => {
    if (sessionId) {
      watchSubs(sessionId)
      void refreshSubs(sessionId)
    }
    if (sessionId && !sub && bsmReady()) {
      bsmCall('parentOf', { sessionId }).then(res => {
        if (res && res.ok && res.parentSessionId) setForkParentId(res.parentSessionId)
      })
    }
  }, [sessionId, sub])
  const targetParent = sub && sub.address ? sub.address.parentSessionId : forkParentId
  if (!sessionId || !targetParent) return null
  const inject = (template) => {
    setBusy(true)
    bsmCall('subInject', {
      parentSessionId: targetParent,
      childSessionId: sessionId,
      template,
    }).then(res => {
      setBusy(false)
      if (res && res.ok) {
        bsmNotice('子会话摘要已注入主会话')
        void refreshSubs(targetParent, true)
      } else {
        bsmNotice('注入失败：' + (res && res.error ? res.error : '未知错误'))
      }
    })
  }
  return React.createElement('div', { style: UTIL.row, title: '压缩子会话上下文并注入主会话（quiet，不自动开始新轮次）' },
    React.createElement('span', { style: UTIL.label }, '压缩注入主会话'),
    React.createElement('button', { type: 'button', style: UTIL.btn, disabled: busy, onClick: () => inject('brief') }, '简洁摘要'),
    React.createElement('button', { type: 'button', style: UTIL.btn, disabled: busy, onClick: () => inject('detailed') }, '详细纪要'),
    React.createElement('button', { type: 'button', style: UTIL.btn, disabled: busy, onClick: () => inject('actions') }, '结论+行动项'),
  )
}

// ---------- 左侧会话栏（sidebar.workspaces：工作区 > 会话 > 子会话） ----------
function SidebarSessions(props) {
  const store = useBsmStore()
  const list = props.useSessions ? props.useSessions(s => s) : null
  const [query, setQuery] = React.useState('')
  const [collapsed, setCollapsed] = React.useState({})
  const [hovered, setHovered] = React.useState(null)
  const ids = list && Array.isArray(list.ids) ? list.ids : null

  React.useEffect(() => {
    if (!list || !list.byId || !ids) return undefined
    const byId = list.byId
    const roots = ids
      .map(id => byId[id])
      .filter(r => r && r.parentId === undefined)
      .map(r => r.id)
    for (const rootId of roots) {
      watchSubs(rootId)
      void refreshSubs(rootId)
    }
    void refreshWorkspaces()
    if (timerSvcRef && typeof timerSvcRef.interval === 'function') {
      const dispose = timerSvcRef.interval(() => {
        for (const rootId of roots) void refreshSubs(rootId)
        void refreshWorkspaces()
      }, 20000)
      return () => { dispose() }
    }
    return undefined
  }, [ids])

  if (props.wide === false) return null

  const toggle = (id) => {
    setCollapsed(prev => Object.assign({}, prev, { [id]: !prev[id] }))
  }

  const wsOf = (cwd) => {
    if (!cwd) return null
    const wsList = store.workspaces || []
    let best = null
    const norm = (p) => String(p).replace(/\/+$/, '')
    const cp = norm(cwd)
    for (const w of wsList) {
      if (!w || !w.path) continue
      const wp = norm(w.path)
      if (cp === wp) return w
      if (cp.startsWith(wp + '/') && (best === null || wp.length > norm(best.path).length)) best = w
    }
    return best
  }

  let body = null
  if (list && list.byId && ids) {
    const byId = list.byId
    const subIds = new Set()
    const deletedIds = new Set()
    const archivedIds = new Set(store.archivedIds || [])
    for (const pid of Object.keys(store.subs || {})) {
      const rec = store.subs[pid]
      for (const s of (rec && rec.subs) || []) subIds.add(s.id)
      for (const d of (rec && rec.deleted) || []) deletedIds.add(d)
    }
    const isSubOf = (row) => subIds.has(row.id) || String(row.id).indexOf('sub-') === 0
    const isHidden = (row) => deletedIds.has(row.id) || archivedIds.has(row.id) || String(row.id).indexOf('btw-') === 0 || (row.origin === 'subagent' && !subIds.has(row.id))
    const openRow = (row) => {
      if (!sessionsSvcRef) return
      if (row.origin === 'subagent') {
        jumpToChild(row.parentId, row.id, 'continuable')
      } else if (typeof sessionsSvcRef.open === 'function') {
        sessionsSvcRef.open(row.id)
      }
    }
    const renameRow = (row) => {
      if (typeof window === 'undefined' || typeof window.prompt !== 'function') return
      const next = window.prompt('重命名会话', row.title || row.displayTitle || '')
      if (next === null || String(next).trim() === '') return
      bsmCall('subRename', { sessionId: row.id, title: String(next).trim() }).then(res => {
        if (res && res.ok) bsmNotice('已重命名')
        else bsmNotice('重命名失败：' + (res && res.error ? res.error : '未知错误'))
      })
    }
    const deleteRow = (row) => {
      if (typeof window === 'undefined' || typeof window.confirm !== 'function') return
      if (!window.confirm('确认删除（归档）会话「' + (row.displayTitle || row.id) + '」？')) return
      bsmCall('subDelete', { sessionId: row.id }).then(res => {
        if (res && res.ok) {
          bsmNotice('已删除（归档）')
          void refreshSubs(row.parentId || row.id, true)
          void refreshWorkspaces(true)
        } else {
          bsmNotice('删除失败：' + (res && res.error ? res.error : '未知错误'))
        }
      })
    }
    const deleteWs = (ws) => {
      if (typeof window === 'undefined' || typeof window.confirm !== 'function') return
      if (!window.confirm('确认删除工作区「' + (ws.title || ws.path) + '」？该工作区下的会话将被归档隐藏。')) return
      bsmCall('workspaceDelete', { workspaceId: ws.id }).then(res => {
        if (res && res.ok) {
          bsmNotice('工作区已删除' + (res.archivedCount ? '（归档 ' + res.archivedCount + ' 个会话）' : ''))
          void refreshWorkspaces(true)
        } else {
          bsmNotice('删除工作区失败：' + (res && res.error ? res.error : '未知错误'))
        }
      })
    }

    const q = String(query || '').trim().toLowerCase()
    const match = (row) => q === '' || String(row.displayTitle || '').toLowerCase().indexOf(q) >= 0

    // 树态子节点映射（提升到分支外作用域，renderSessionRow 需要引用）
    const childrenOf = {}
    for (const id of ids) {
      const row = byId[id]
      if (!row || isHidden(row)) continue
      const isSub = isSubOf(row)
      const pid = isSub && row.parentId !== undefined && byId[row.parentId] !== undefined ? row.parentId : ''
      if (!childrenOf[pid]) childrenOf[pid] = []
      childrenOf[pid].push(row)
    }

    const renderSessionRow = (row, depth) => {
      const kids = childrenOf[row.id] || []
      const hasKids = kids.length > 0
      const isCollapsed = collapsed[row.id] === true
      const isCurrent = list.current === row.id
      const isHover = hovered === row.id
      const items = [React.createElement('div', {
        key: row.id,
        style: Object.assign({}, SB.rowWrap, { paddingLeft: depth * 14, background: isCurrent ? 'rgba(99,102,241,0.22)' : (isHover ? 'rgba(128,128,128,0.12)' : undefined) }),
        onMouseEnter: () => setHovered(row.id),
        onMouseLeave: () => setHovered(null),
      },
        // 左侧折叠按钮：有子会话时点击收缩/展开（不打开会话）
        React.createElement('button', {
          type: 'button',
          style: Object.assign({}, SB.foldBtn, { cursor: hasKids ? 'pointer' : 'default' }),
          onClick: () => { if (hasKids) toggle(row.id) },
          title: hasKids ? (isCollapsed ? '展开子会话' : '折叠子会话') : '',
        }, hasKids ? (isCollapsed ? '▸' : '▾') : ''),
        // 主区：点击打开会话
        React.createElement('button', {
          type: 'button',
          style: SB.openBtn,
          onClick: () => openRow(row),
          title: row.id,
        },
          React.createElement('span', { style: Object.assign({}, SB.dot, { background: row.running ? 'rgba(74,222,128,0.9)' : 'rgba(128,128,128,0.5)' }), title: row.running ? '运行中' : '' }, ''),
          depth > 0 ? React.createElement('span', { style: { color: '#8b8bf0' } }, '↳ ') : null,
          React.createElement('span', { style: SB.title }, row.displayTitle || row.id),
        ),
        isHover ? React.createElement('div', { style: { display: 'flex', gap: 2, paddingRight: 4 } },
          React.createElement('button', { type: 'button', style: SB.act, title: '重命名', onClick: () => renameRow(row) }, React.createElement(Icon, { name: 'Edit', size: 12 })),
          React.createElement('button', { type: 'button', style: SB.act, title: '删除（归档）', onClick: () => deleteRow(row) }, React.createElement(Icon, { name: 'Delete', size: 12 })),
        ) : null,
      )]
      if (hasKids && !isCollapsed) {
        for (const k of kids) items.push(renderSessionRow(k, depth + 1))
      }
      return items
    }

    if (q !== '') {
      // 搜索态：平铺显示匹配行
      const rows = ids
        .map(id => byId[id])
        .filter(r => r && !isHidden(r) && match(r))
      body = rows.map(row => React.createElement('div', { key: row.id },
        React.createElement('div', {
          style: Object.assign({}, SB.rowWrap, { background: list.current === row.id ? 'rgba(99,102,241,0.22)' : undefined }),
          onMouseEnter: () => setHovered(row.id),
          onMouseLeave: () => setHovered(null),
        },
          React.createElement('button', { type: 'button', style: SB.foldBtn }, ''),
          React.createElement('button', { type: 'button', style: SB.openBtn, onClick: () => openRow(row), title: row.id },
            React.createElement('span', { style: Object.assign({}, SB.dot, { background: row.running ? 'rgba(74,222,128,0.9)' : 'rgba(128,128,128,0.5)' }) }, ''),
            isSubOf(row) ? React.createElement('span', { style: { color: '#8b8bf0' } }, '↳ ') : null,
            React.createElement('span', { style: SB.title }, row.displayTitle || row.id),
          ),
          hovered === row.id ? React.createElement('div', { style: { display: 'flex', gap: 2, paddingRight: 4 } },
            React.createElement('button', { type: 'button', style: SB.act, title: '重命名', onClick: () => renameRow(row) }, React.createElement(Icon, { name: 'Edit', size: 12 })),
            React.createElement('button', { type: 'button', style: SB.act, title: '删除（归档）', onClick: () => deleteRow(row) }, React.createElement(Icon, { name: 'Delete', size: 12 })),
          ) : null,
        ),
      ))
      if (body.length === 0) body = [React.createElement('div', { key: 'empty', style: SB.empty }, '（无匹配会话）')]
    } else {
      // 树态：工作区（文件夹）> 会话 > 子会话
      const roots = childrenOf[''] || []
      const wsIds = []
      for (const w of (store.workspaces || [])) if (w && w.id) wsIds.push(w.id)
      const folderMap = {} // wsId -> rows[]
      const others = []
      for (const row of roots) {
        const ws = wsOf(row.cwd)
        if (ws && ws.id && wsIds.indexOf(ws.id) >= 0) {
          if (!folderMap[ws.id]) folderMap[ws.id] = []
          folderMap[ws.id].push(row)
        } else {
          others.push(row)
        }
      }
      // 未匹配任何注册工作区的会话：按 cwd 合成文件夹（保证始终归属可见）
      const synthetic = {} // 'cwd:<path>' -> rows[]
      const stillOthers = []
      for (const row of others) {
        if (row.cwd) {
          const key = 'cwd:' + row.cwd
          if (!synthetic[key]) synthetic[key] = []
          synthetic[key].push(row)
        } else {
          stillOthers.push(row)
        }
      }
      const out = []
      const wsById = {}
      for (const w of (store.workspaces || [])) wsById[w.id] = w
      for (const key of Object.keys(synthetic)) {
        const path = key.slice(4)
        wsById[key] = { id: key, path, title: fileName(path) || path, synthetic: true }
      }
      const renderFolder = (wsId, rows) => {
        const ws = wsById[wsId] || {}
        const fkey = 'ws:' + wsId
        const isCollapsed = collapsed[fkey] === true
        const isHover = hovered === fkey
        out.push(React.createElement('div', {
          key: fkey,
          style: Object.assign({}, SB.wsRow, { background: isHover ? 'rgba(128,128,128,0.12)' : undefined }),
          onMouseEnter: () => setHovered(fkey),
          onMouseLeave: () => setHovered(null),
        },
          React.createElement('button', { type: 'button', style: SB.foldBtn, onClick: () => toggle(fkey), title: isCollapsed ? '展开' : '折叠' },
            isCollapsed ? '▸' : '▾'),
          React.createElement(Icon, { name: isCollapsed ? 'Folder' : 'FolderOpen', size: 13, color: '#c8a24a' }),
          React.createElement('span', { style: SB.title }, ws.title || ws.path || wsId),
          isHover && !ws.synthetic ? React.createElement('button', { type: 'button', style: SB.act, title: '删除工作区（会话将被归档）', onClick: () => deleteWs(ws) }, React.createElement(Icon, { name: 'Delete', size: 12 })) : null,
        ))
        if (!isCollapsed) {
          // 主会话相对工作区文件夹缩进一级（14px）；子会话再缩进一级（28px）
          for (const row of rows) out.push(renderSessionRow(row, 1))
        }
      }
      for (const wsId of wsIds) {
        const rows = folderMap[wsId]
        if (rows && rows.length) renderFolder(wsId, rows)
      }
      for (const key of Object.keys(synthetic)) {
        renderFolder(key, synthetic[key])
      }
      if (stillOthers.length) {
        const fkey = 'ws:other'
        const isCollapsed = collapsed[fkey] === true
        out.push(React.createElement('div', { key: fkey, style: SB.wsRow },
          React.createElement('button', { type: 'button', style: SB.foldBtn, onClick: () => toggle(fkey) }, isCollapsed ? '▸' : '▾'),
          React.createElement(Icon, { name: isCollapsed ? 'Folder' : 'FolderOpen', size: 13, color: '#c8a24a' }),
          React.createElement('span', { style: SB.title }, '其他会话'),
        ))
        if (!isCollapsed) {
          for (const row of stillOthers) out.push(renderSessionRow(row, 1))
        }
      }
      body = out
      if (body.length === 0) body = [React.createElement('div', { key: 'empty', style: SB.empty }, '（暂无会话）')]
    }
  }

  return React.createElement('div', { style: SB.root },
    React.createElement('div', { style: SB.head }, '会话'),
    React.createElement('input', {
      type: 'text',
      value: query,
      style: SB.input,
      placeholder: '搜索会话…',
      onChange: (ev) => setQuery(ev.target.value),
    }),
    React.createElement('div', { style: SB.body }, body || null),
  )
}

// ---------- 浮层：仅提示 toast ----------
function BsmOverlay(props) {
  const store = useBsmStore()
  return React.createElement('div', { style: { position: 'absolute', inset: 0, pointerEvents: 'none' } },
    store.notice ? React.createElement('div', { key: 'n' + store.notice.at, style: TOAST.root }, store.notice.text) : null,
  )
}

// ---------- 设置页 ----------
function BsmSettings() {
  const mode = usePref('mode')
  const chainCollapsed = usePref('chainCollapsed')
  const feedbackHighlight = usePref('feedbackHighlight')
  const mdRender = usePref('mdRender')
  const mdWidth = usePref('mdWidth')
  const subMode = usePref('subMode')
  const btwEffort = usePref('btwEffort')
  const btn = (active) => ({
    padding: '4px 12px', borderRadius: '8px', border: '1px solid rgba(128,128,128,0.4)', cursor: 'pointer',
    background: active ? 'rgba(59,130,246,0.2)' : 'transparent', fontWeight: active ? 700 : 400,
  })
  const row = { display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '8px 0', gap: '12px' }
  return React.createElement('div', { style: { display: 'flex', flexDirection: 'column', gap: '4px', padding: '4px 0' } },
    React.createElement('div', { style: row },
      React.createElement('span', null, '气泡整合方案'),
      React.createElement('span', { style: { display: 'flex', gap: '6px' } },
        React.createElement('button', { type: 'button', style: btn(mode === 'A'), onClick: () => setPref('mode', 'A') }, 'A 大气泡多轮'),
        React.createElement('button', { type: 'button', style: btn(mode === 'B'), onClick: () => setPref('mode', 'B') }, 'B 单链气泡'),
      ),
    ),
    React.createElement('div', { style: row },
      React.createElement('span', null, '默认折叠链条框'),
      React.createElement('button', { type: 'button', style: btn(chainCollapsed), onClick: () => setPref('chainCollapsed', !chainCollapsed) }, chainCollapsed ? '折叠' : '展开'),
    ),
    React.createElement('div', { style: row },
      React.createElement('span', null, '高亮反馈样式'),
      React.createElement('button', { type: 'button', style: btn(feedbackHighlight), onClick: () => setPref('feedbackHighlight', !feedbackHighlight) }, feedbackHighlight ? '高亮' : '标准'),
    ),
    React.createElement('div', { style: row },
      React.createElement('span', null, 'Markdown 渲染'),
      React.createElement('button', { type: 'button', style: btn(mdRender), onClick: () => setPref('mdRender', !mdRender) }, mdRender ? '开启' : '关闭'),
    ),
    React.createElement('div', { style: row },
      React.createElement('span', null, '子会话继承模式'),
      React.createElement('span', { style: { display: 'flex', gap: '6px' } },
        React.createElement('button', { type: 'button', style: btn(subMode !== 'full'), onClick: () => setPref('subMode', 'window') }, '摘要快建'),
        React.createElement('button', { type: 'button', style: btn(subMode === 'full'), onClick: () => setPref('subMode', 'full') }, '完整继承'),
      ),
    ),
    React.createElement('div', { style: row },
      React.createElement('span', null, 'btw 思考深度'),
      React.createElement('span', { style: { display: 'flex', gap: '6px' } },
        ['off', 'high', 'max'].map(effort => {
          const label = effort === 'off' ? '低（快速）' : (effort === 'high' ? '中（标准）' : '高（深入）')
          return React.createElement('button', {
            key: effort,
            type: 'button',
            style: btn(btwEffort === effort),
            title: '选择后同步宿主：/btw 提问按该档位控制思考深度与耗时',
            onClick: () => {
              setPref('btwEffort', effort)
              bsmCall('btwSetEffort', { effort }).then(res => {
                if (!res || !res.ok) bsmNotice('思考深度同步失败：' + (res && res.error ? res.error : '未知错误'))
              })
            },
          }, label)
        }),
      ),
    ),
    React.createElement('div', { style: row },
      React.createElement('span', null, '显示宽度'),
      React.createElement('span', { style: { display: 'flex', gap: '6px' } },
        React.createElement('button', { type: 'button', style: btn(mdWidth === 'standard'), onClick: () => setPref('mdWidth', 'standard') }, '标准'),
        React.createElement('button', { type: 'button', style: btn(mdWidth === 'wide'), onClick: () => setPref('mdWidth', 'wide') }, '宽'),
        React.createElement('button', { type: 'button', style: btn(mdWidth === 'full'), onClick: () => setPref('mdWidth', 'full') }, '全宽'),
      ),
    ),
    React.createElement('p', { style: { color: 'rgba(128,128,128,0.8)', fontSize: '12px', marginTop: '8px' } },
      '说明：左侧会话栏按 工作区（文件夹）> 会话（含分支会话）> 子会话 三级组织；▸/▾ 折叠，点文字打开；悬停可重命名/删除（删除=归档）。子会话继承模式：「摘要快建」以最近 24 轮转录为种子（毫秒级创建，早期历史以转录摘要呈现）；「完整继承」复制父会话全部历史（慢，与分支按钮同成本）。btw 为一次性只读临时问答：仅一次提问机会，回答后立即销毁，仅保留主会话中的问答记录；想继续追问请用卡片上的「创建子会话」把 btw 上下文迁入子会话。btw 思考深度：低=off（最快）、中=high（标准，默认）、高=max（最深入、最慢）。链视图顶部可「加载更早」展开更早的上下文。',
    ),
  )
}

// ---------- 插件主体 ----------
return {
  apply(ctx) {

    const remoteSvc = ctx.get('remote') || ctx.remote
    if (remoteSvc !== undefined && typeof remoteSvc.$mount === 'function') {
      ctx.effect(() => {
        remoteSvc.$mount(bsmContribution).then((disposeMount) => {
          const mounted = ctx.get('remote.bsm', false)
          if (mounted !== undefined) {
            bsmRemote = mounted
            bsmNotify()
          }
          return disposeMount
        }).catch(() => { /* 挂载失败：bsmCall 回退为错误提示 */ })
      })
    }
    const slots = ctx.get('slots') || ctx.slots
    if (slots === undefined) return

    sessionsSvcRef = ctx.get('sessions') || ctx.sessions
    timerSvcRef = ctx.get('timer') || ctx.timer

    // 全局轮询：btw/子会话状态变更及时反映到链条视图与轮次卡片（sub-list 为轻量内存调用）
    if (timerSvcRef && typeof timerSvcRef.interval === 'function') {
      ctx.effect(() => timerSvcRef.interval(() => {
        for (const id of Array.from(watchedSubs)) void refreshSubs(id, true)
      }, 8000))
    }

    const styles = ctx.get('styles') || ctx.styles
    if (styles && typeof styles.insert === 'function') {
      ctx.effect(() => styles.insert(
        '.bsm-settings-row{display:flex;align-items:center;justify-content:space-between;padding:8px 0}' + MD_CSS,
      ))
    }

    // M1：链条视图页签
    slots.inject('conversation.view', () => slots.register({
      name: 'conversation.view',
      id: 'bsm-chain',
      order: 1,
      label: '链条视图',
    }, ChainView))

    // M1：设置页
    slots.inject('settings.section', () => slots.register({
      name: 'settings.section',
      id: 'bsm',
      order: 50,
      label: '会话管理',
    }, BsmSettings))

    // M2/M3：轮次尾部子会话/btw 卡片
    slots.inject('conversation.chat.turnTail', () => slots.register({
      name: 'conversation.chat.turnTail',
      select: (owner) => ({ turn: owner.turn }),
    }, SubBubbles))

    // M2：创建子会话图标按钮
    slots.inject('conversation.chat.assistant-actions', () => slots.register({
      name: 'conversation.chat.assistant-actions',
      id: 'bsm-create-sub',
      order: 5,
      label: '创建子会话',
    }, CreateSubAction))

    // M2：会话头工具
    slots.inject('conversation.session.header.utilities', () => slots.register({
      name: 'conversation.session.header.utilities',
      id: 'bsm-session-util',
      order: 10,
      label: '子会话工具',
    }, BsmSessionUtility))

    // 左侧会话栏：覆盖默认会话浏览区（工作区 > 会话 > 子会话）
    slots.inject('sidebar.workspaces', () => slots.register({
      name: 'sidebar.workspaces',
      id: 'bsm-sessions',
      order: 10,
      label: '会话（工作区/子会话树）',
    }, SidebarSessions))

    // 浮层：提示 toast
    slots.inject('shell.overlay', () => slots.register({
      name: 'shell.overlay',
      id: 'bsm-overlay',
      order: 10,
      label: '提示浮层',
    }, BsmOverlay))
  },
}
  }
})
