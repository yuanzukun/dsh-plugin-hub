// better-session-management — pkg31 Host half (源码镜像)
// pkg31 变更（整项目 review 修复）：
// - 【修复】forkSubsOf/bsm-parent-of 原先读取 s.header.meta：运行版 SessionHeader 为扁平
//   结构（无 meta 字段），导致子会话枚举与父会话解析恒为空——子会话卡片/会话栏嵌套/
//   「压缩注入主会话」全部失效。改为直接读 header.parentSession/seedLength；
//   卡片标题改用 sessionTitle.get(s).title。
// - 【修复】bsm/sub-inject：btw 卡片「发送给主会话」传的是卡片 id（非会话 id），
//   现经 btwRegistry 映射到实际子会话 id，摘要头区分【btw 摘要】/【子会话摘要】。
// - 【修复】bsm/sub-rename 移除 prepare 冷会话回退（分离对象写入不落盘，会造成
//   "显示成功但未生效"）；冷会话返回明确错误提示。
// - 【修复】bsm/btw-destroy 归档目标改为实际子会话 id（此前归档卡片 id 恒失败被吞）。
// - 【改进】bsm/workspace-delete 删除工作区时同步归档其下会话（与界面文案一致）。
// - pkg30 内容保留：btw 思考深度档位、一次性销毁、无结算通知、未追踪 registry 创建等。

return {
  apply(ctx) {
    const sessions = ctx.get('sessions') // session store：fork / get / list
    const agents = ctx.get('agents')
    const subagents = ctx.get('subagents') // btw + 遗留子会话
    const sessionQuery = ctx.get('sessionQuery')
    const llm = ctx.get('llm')
    const persistence = ctx.get('sessionPersistence')
    const agentDefaultModel = ctx.get('agentDefaultModel')
    const feedback = ctx.get('messageFeedback')
    const sessionTitle = ctx.get('sessionTitle')
    const workspaceRegistry = ctx.get('workspaceRegistry')

    // ---------- 公共辅助 ----------
    function makePluginUserMessage(text, form) {
      return {
        id: 'bsm-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 10),
        role: 'user',
        content: [{ type: 'text', text }],
        source: form === 'recall'
          ? { kind: 'plugin', plugin: 'better-session-management', form: 'recall' }
          : { kind: 'user' },
      }
    }

    function errorText(error) {
      return String(error && error.message ? error.message : error)
    }

    function randId() {
      return Math.random().toString(36).slice(2, 10) + Date.now().toString(36).slice(-4)
    }

    async function requireLiveAgent(sessionId) {
      const live = agents !== undefined ? agents.get(sessionId) : undefined
      if (live !== undefined) return live
      if (agents === undefined || typeof agents.resume !== 'function') {
        throw new Error('agent registry unavailable')
      }
      const handle = await agents.resume({ resumeSessionId: sessionId })
      return handle.agent
    }

    function sanitizeBoundary(events, boundarySeq) {
      if (!Number.isSafeInteger(boundarySeq) || boundarySeq < 0) throw new Error('invalid boundary seq')
      const ev = events[boundarySeq]
      if (ev === undefined || ev.type !== 'turn/end') {
        throw new Error('boundary must be an existing turn/end seq')
      }
      return boundarySeq
    }

    function textOfBlocks(content) {
      if (!Array.isArray(content)) return ''
      return content
        .filter(b => b && b.type === 'text' && typeof b.text === 'string')
        .map(b => b.text).join('\n').trim()
    }

    // ---------- 子会话：agents.create（会话 + agent 一次建成；与 DSH 官方 fork 同原语） ----------
    const createInFlight = new Map() // parentId -> Promise（防连点重复创建）
    const subParentBoundary = new Map() // 转录种子子会话 -> 真实父会话 turn/end seq（卡片定位）
    const subHandles = new Map() // 子会话 id -> AgentHandle（删除时 dispose：卸下 live 会话与 agent）

    // 事件区间 → 文本转录行（用户/助手/工具调用/工具输出）；事件字段位于 data 层
    function transcriptLinesOf(events, from, to) {
      const lines = []
      for (let i = from; i <= to && i < events.length; i++) {
        const ev = events[i]
        if (!ev || !ev.type) continue
        const d = ev.data || {}
        if (ev.type === 'user/message') {
          const t = textOfBlocks(d.content)
          if (t) lines.push('用户：' + t.slice(0, 2000) + (t.length > 2000 ? '…(截断)' : ''))
        } else if (ev.type === 'assistant/message') {
          const t = textOfBlocks(d.message ? d.message.content : undefined)
          if (t) lines.push('助手：' + t.slice(0, 2000) + (t.length > 2000 ? '…(截断)' : ''))
        } else if (ev.type === 'tool/call') {
          const argsRaw = typeof d.arguments === 'string' ? d.arguments : ''
          lines.push('工具调用 ' + (d.name || '工具') + (argsRaw !== '' ? '（参数 ' + argsRaw.slice(0, 200) + (argsRaw.length > 200 ? '…' : '') + '）' : ''))
        } else if (ev.type === 'tool/result') {
          const msg = d.message || {}
          const block = Array.isArray(msg.content) && msg.content[0] ? msg.content[0] : null
          const isErr = block && block.isError === true
          const out = block && Array.isArray(block.content) ? textOfBlocks(block.content) : ''
          lines.push('工具输出' + (isErr ? '（出错）' : '') + '：' + out.slice(0, 240) + (out.length > 240 ? '…(截断)' : ''))
        }
      }
      return lines
    }

    // 从边界向前取最近 maxTurns 个完整轮次的转录；超 maxChars 从头部截断（保留最新）
    function buildHistoryPack(parentEvents, boundary, maxTurns, maxChars) {
      const end = Math.min(boundary, parentEvents.length - 1)
      const turnEnds = []
      for (let i = end; i >= 0 && turnEnds.length < maxTurns; i--) {
        if (parentEvents[i] && parentEvents[i].type === 'turn/end') turnEnds.push(i)
      }
      if (turnEnds.length === 0) return ''
      const oldestEnd = turnEnds[turnEnds.length - 1]
      let start = 0
      for (let i = oldestEnd; i >= 0; i--) {
        if (parentEvents[i] && parentEvents[i].type === 'turn/start') { start = i; break }
      }
      const head = start > 0 ? '（更早的历史已省略：仅保留最近 ' + turnEnds.length + ' 轮）\n' : ''
      let text = transcriptLinesOf(parentEvents, start, end).join('\n')
      if (head.length + text.length > maxChars) {
        text = '…(前文截断)\n' + text.slice(-(maxChars - head.length - 20))
      }
      return head + text
    }

    // 转录文本 → 最小合法合成种子：每块一个完整轮（仅 append 型表面事件）
    function syntheticSeedFromText(text) {
      const events = []
      const chunks = []
      let rest = text
      while (rest.length > 0) {
        if (rest.length <= 12000) { chunks.push(rest); break }
        let cut = rest.lastIndexOf('\n', 12000)
        if (cut < 1000) cut = 12000
        chunks.push(rest.slice(0, cut + 1))
        rest = rest.slice(cut + 1)
      }
      const t0 = Date.now()
      chunks.forEach((chunk, ci) => {
        const turn = ci + 1
        const base = events.length
        events.push({ type: 'turn/start', seq: base, time: t0 + base, data: { turn } })
        events.push({
          type: 'user/message',
          seq: base + 1,
          time: t0 + base + 1,
          data: makePluginUserMessage(chunk, 'recall'),
          surfaceOp: 'append',
        })
        events.push({
          type: 'turn/end',
          seq: base + 2,
          time: t0 + base + 2,
          data: { turn, reason: { kind: 'completed' } },
        })
      })
      return events
    }

    async function createSub(parent, boundarySeq, prompt, mode, labelArg) {
      if (agents === undefined || typeof agents.create !== 'function') {
        throw new Error('agent registry unavailable')
      }
      const boundary = sanitizeBoundary(parent.session.events, boundarySeq)
      const inflight = createInFlight.get(parent.id)
      if (inflight !== undefined) {
        // 同一父会话的创建请求共享一次 fork（连点去重）
        return inflight
      }
      const task = (async () => {
        const t0 = Date.now()
        const hasPrompt = prompt !== undefined && prompt !== null && String(prompt).trim() !== ''
        const text = hasPrompt ? String(prompt) : ''
        const explicitLabel = labelArg !== undefined && labelArg !== null && String(labelArg).trim() !== ''
          ? String(labelArg).trim().slice(0, 60)
          : ''
        const label = explicitLabel !== ''
          ? explicitLabel
          : (hasPrompt ? (text.length > 60 ? text.slice(0, 59) + '…' : text) : '子会话')
        const childId = 'sub-' + randId()
        // 继承模式：window（转录种子，快，默认）/ full（完整 fork，慢）
        const useWindow = mode !== 'full' && boundary + 1 > 20000
        let seed
        if (useWindow) {
          const pack = buildHistoryPack(parent.session.events, boundary, 24, 80000)
          seed = syntheticSeedFromText(
            '【父会话历史转录】本子会话继承自主会话 ' + parent.id
            + '（截至该会话第 ' + boundary + ' 个事件边界）。以下为最近轮次的对话转录：\n'
            + (pack || '（无内容）'),
          )
        } else {
          seed = parent.session.events.slice(0, boundary + 1)
        }
        const presets = ctx.get('agentPresets')
        let presetId
        if (presets !== undefined && typeof presets.composedPreset === 'function') {
          try { presetId = presets.composedPreset(parent.ctx) } catch (error) { presetId = undefined }
        }
        // 沙箱禁止 ctx.root；经 cordis 全局符号取未追踪的原始 registry 创建：
        // this.ctx = registry 的构造 ctx（宿主根，无 agent 作用域）→ owner = undefined
        // （顶层/根 agent），避免 hasApiRemoteSubagentOwner 的 agent-busy 栅栏。
        let registry = agents
        try {
          const orig = agents[Symbol.for('cordis.original')]
          if (orig !== undefined && orig !== null && typeof orig === 'object' && typeof orig.create === 'function') {
            registry = orig
          }
        } catch (error) { /* 回退到追踪实例 */ }
        const handle = await registry.create({
          sessionId: childId,
          seed,
          meta: {
            ...(parent.session.header && parent.session.header.cwd !== undefined
              ? { cwd: parent.session.header.cwd }
              : {}),
            parentSession: parent.id,
            seedLength: seed.length,
            ...(presetId !== undefined ? { agentPreset: presetId } : {}),
          },
          agentOptions: {
            ...(parent.options && parent.options.provider !== undefined
              ? { provider: parent.options.provider } : {}),
            ...(parent.options && parent.options.model !== undefined
              ? { model: parent.options.model } : {}),
            ...(parent.options && parent.options.maxTokens !== undefined
              ? { maxTokens: parent.options.maxTokens } : {}),
          },
          setup: (childCtx) => {
            const ap = childCtx.get('agentPresets')
            if (ap !== undefined && typeof ap.composeFrom === 'function') {
              // 与主会话共享同一 standing 组合实例（同一插件对象/工具/提示段）
              ap.composeFrom(childCtx, parent.ctx)
            }
          },
        })
        const t1 = Date.now()
        const childAgent = handle.agent
        const child = childAgent.session
        subHandles.set(child.id, handle)
        if (useWindow) subParentBoundary.set(child.id, boundary)
        if (sessionTitle !== undefined && typeof sessionTitle.rename === 'function') {
          try { sessionTitle.rename(child, label) } catch (error) { /* 命名失败不阻断 */ }
        }
        const t2 = Date.now()
        // 子会话上下文继承自 fork 种子本身；注入任务只是补充首条提示。
        // 会话已带 live agent：直接 inject，无 resume、无 prepare 冲突。
        if (hasPrompt) {
          try { childAgent.inject(makePluginUserMessage('任务：' + text, 'recall')) } catch (error) { /* ignore */ }
        }
        const t3 = Date.now()
        return {
          ok: true,
          childId: child.id,
          boundarySeq: boundary,
          standby: !hasPrompt,
          kind: 'fork',
          mode: useWindow ? 'window' : 'full',
          timings: { seedMs: t1 - t0, renameMs: t2 - t1, injectMs: t3 - t2, totalMs: t3 - t0 },
        }
      })()
      createInFlight.set(parent.id, task)
      try { return await task } finally { createInFlight.delete(parent.id) }
    }

    harness.handle('bsm/sub-create', async (args) => {
      try {
        const parent = await requireLiveAgent(args.sessionId)
        return await createSub(parent, args.boundarySeq, args.prompt, args.mode, args.label)
      } catch (error) {
        return { ok: false, error: errorText(error) }
      }
    })

    // 查询会话血缘父会话（fork 子会话内使用）：header 为扁平结构，parentSession 直接读取；
    // 冷会话不在 live store 时回退 persistence.inspect
    harness.handle('bsm/parent-of', async (args) => {
      try {
        let parentSessionId = null
        const s = sessions !== undefined ? sessions.get(args.sessionId) : undefined
        if (s !== undefined && s.header !== undefined && s.header.parentSession !== undefined) {
          parentSessionId = s.header.parentSession
        } else if (persistence !== undefined && typeof persistence.inspect === 'function') {
          try {
            const info = await persistence.inspect(args.sessionId)
            if (info && info.meta && info.meta.parentSession) parentSessionId = info.meta.parentSession
          } catch (error) { parentSessionId = null }
        }
        return { ok: true, parentSessionId }
      } catch (error) {
        return { ok: false, error: errorText(error) }
      }
    })

    // ---------- 会话/子会话重命名、归档；工作区列表/删除 ----------
    harness.handle('bsm/sub-rename', async (args) => {
      try {
        if (sessions === undefined || sessionTitle === undefined || typeof sessionTitle.rename !== 'function') {
          return { ok: false, error: 'services unavailable' }
        }
        const title = String(args.title || '').trim()
        if (title === '') return { ok: false, error: '标题不能为空' }
        // 仅支持 live 会话重命名：冷会话没有可写的 live 实例，prepare 产生的分离对象
        // 写入不会落盘（避免"显示成功但未生效"的误导）
        const s = sessions.get(args.sessionId)
        if (s === undefined) return { ok: false, error: '会话未加载：请先打开该会话再重命名' }
        sessionTitle.rename(s, title)
        return { ok: true }
      } catch (error) {
        return { ok: false, error: errorText(error) }
      }
    })

    // 删除（归档）集合：子会话/btw 在会话栏与轮次卡片中立即隐藏
    const deletedIds = new Set()

    // 持久归档集合（workspaceRegistry 落盘）：插件更新/进程重启后依然过滤，彻底删除的基础
    function archivedIdsSet() {
      const out = new Set()
      if (workspaceRegistry !== undefined && Array.isArray(workspaceRegistry.archivedSessionIds)) {
        for (const id of workspaceRegistry.archivedSessionIds) out.add(id)
      }
      return out
    }

    harness.handle('bsm/sub-delete', async (args) => {
      try {
        deletedIds.add(args.sessionId)
        subParentBoundary.delete(args.sessionId)
        let archived = false
        if (workspaceRegistry !== undefined && typeof workspaceRegistry.archiveSession === 'function') {
          try {
            await workspaceRegistry.archiveSession(args.sessionId)
            archived = true
          } catch (error) { /* 归档失败仍按已删除处理（本插件界面隐藏） */ }
        }
        // 彻底删除：dispose 卸下 live 会话（agent 注销 + session 移出 store）
        let disposed = false
        const handle = subHandles.get(args.sessionId)
        if (handle !== undefined && typeof handle.dispose === 'function') {
          subHandles.delete(args.sessionId)
          try {
            await handle.dispose()
            disposed = true
          } catch (error) { /* dispose 失败：仍已归档隐藏 */ }
        } else {
          const live = agents !== undefined ? agents.get(args.sessionId) : undefined
          if (live !== undefined) {
            try { live.cancel({ kind: 'user' }, { keepInbox: false }) } catch (error) { /* ignore */ }
          }
        }
        return { ok: true, archived, disposed }
      } catch (error) {
        return { ok: false, error: errorText(error) }
      }
    })

    harness.handle('bsm/workspace-list', async () => {
      try {
        if (workspaceRegistry === undefined || typeof workspaceRegistry.list !== 'function') {
          return { ok: true, workspaces: [], archived: [] }
        }
        const list = workspaceRegistry.list()
        return {
          ok: true,
          workspaces: (list || []).map(w => ({
            id: w && w.id, path: w && w.path, title: w && w.title,
          })),
          archived: Array.isArray(workspaceRegistry.archivedSessionIds)
            ? Array.from(workspaceRegistry.archivedSessionIds)
            : [],
        }
      } catch (error) {
        return { ok: false, error: errorText(error) }
      }
    })

    harness.handle('bsm/workspace-delete', async (args) => {
      try {
        if (workspaceRegistry === undefined || typeof workspaceRegistry.delete !== 'function') {
          return { ok: false, error: 'workspace registry unavailable' }
        }
        // 删除工作区的同时归档其下会话（与界面文案一致：工作区删除后其会话不可见）
        let archivedCount = 0
        try {
          const list = workspaceRegistry.list()
          const ws = (list || []).find(w => w && w.id === args.workspaceId)
          if (ws !== undefined && Array.isArray(ws.sessionIds) && typeof workspaceRegistry.archiveSession === 'function') {
            for (const sid of ws.sessionIds) {
              try { await workspaceRegistry.archiveSession(sid); archivedCount++ } catch (error) { /* ignore */ }
            }
          }
        } catch (error) { /* 归档失败不阻断工作区删除 */ }
        const deleted = await workspaceRegistry.delete(args.workspaceId)
        return { ok: true, deleted: deleted === true, archivedCount }
      } catch (error) {
        return { ok: false, error: errorText(error) }
      }
    })

    // ---------- btw 注册表（一次性只读问答：内存记录 + 父会话命令结果即为持久记录） ----------
    const btwRegistry = new Map() // id -> { parentSessionId, question, answer, running, at, boundarySeq, transcript, controller, startedMs, doneMs }
    const legacyBoundaryCache = new Map() // 遗留子代理子会话 id -> boundarySeq（sub-list 轮询缓存）

    // btw 子代理自身事件转录（问 + 工具调用 + 答）：btw→子会话时注入，使子会话继承 btw 上下文
    function transcriptOf(events) {
      const lines = []
      for (const ev of events) {
        if (!ev || !ev.type) continue
        const d = ev.data || {}
        if (ev.type === 'user/message') {
          const t = textOfBlocks(d.content)
          if (t) lines.push('用户：' + t)
        } else if (ev.type === 'assistant/message') {
          const t = textOfBlocks(d.message ? d.message.content : undefined)
          if (t) lines.push('助手：' + t)
        } else if (ev.type === 'tool/call') {
          const name = d.name || '工具'
          const argsRaw = typeof d.arguments === 'string' ? d.arguments : ''
          lines.push('工具调用 ' + name + (argsRaw !== '' ? '（参数 ' + argsRaw.slice(0, 400) + '）' : ''))
        } else if (ev.type === 'tool/result') {
          const msg = d.message || {}
          const block = Array.isArray(msg.content) && msg.content[0] ? msg.content[0] : null
          const isErr = block && block.isError === true
          const out = block && Array.isArray(block.content) ? textOfBlocks(block.content) : ''
          lines.push('工具输出' + (isErr ? '（出错）' : '') + '：' + out.slice(0, 800))
        }
      }
      return lines.join('\n')
    }

    // fork 子会话枚举（血缘 + id 前缀双重判定；分支会话不受影响；已删除/已归档的隐藏）
    // 注意：SessionHeader 为扁平结构（parentSession/seedLength 直接在 header 上，无 meta 字段）
    function forkSubsOf(parentSessionId) {
      const rows = []
      const archivedSet = archivedIdsSet()
      if (sessions !== undefined && typeof sessions.list === 'function') {
        for (const s of sessions.list()) {
          if (deletedIds.has(s.id) || archivedSet.has(s.id)) continue
          const hdr = s.header
          if (hdr === undefined || hdr.parentSession !== parentSessionId) continue
          if (String(s.id).indexOf('sub-') !== 0) continue
          const live = agents !== undefined ? agents.get(s.id) : undefined
          // 转录种子子会话：卡片定位用真实父边界（进程内存态；重启后退化为 seedLength-1）
          const knownBoundary = subParentBoundary.get(s.id)
          let label = null
          if (sessionTitle !== undefined && typeof sessionTitle.get === 'function') {
            try {
              const snap = sessionTitle.get(s)
              if (snap && typeof snap.title === 'string' && snap.title !== '') label = snap.title
            } catch (error) { /* ignore */ }
          }
          rows.push({
            id: s.id, kind: 'fork',
            boundarySeq: Number.isSafeInteger(knownBoundary)
              ? knownBoundary
              : (Number.isSafeInteger(hdr.seedLength) ? hdr.seedLength - 1 : null),
            running: live !== undefined && live.status === 'running',
            label,
          })
        }
      }
      return rows
    }

    // ---------- RPC：子会话列表（fork 子会话 + 遗留子代理子会话 + btw 记录分离） ----------
    harness.handle('bsm/sub-list', async (args) => {
      try {
        const subs = forkSubsOf(args.parentSessionId)
        const btws = []
        // btw 一次性记录（内存注册表；无子代理会话管理、无收尾通知）
        for (const rec of btwRegistry.values()) {
          if (rec.parentSessionId !== args.parentSessionId) continue
          if (deletedIds.has(rec.id)) continue
          btws.push({
            id: rec.id,
            activity: rec.running ? 'running' : 'inactive',
            mode: 'continuable',
            label: 'btw: ' + rec.question,
            boundarySeq: rec.boundarySeq,
          })
        }
        if (subagents !== undefined) {
          const archivedSet = archivedIdsSet()
          const registryChildIds = new Set()
          for (const rec of btwRegistry.values()) {
            if (rec.childSessionId !== null && rec.childSessionId !== undefined) {
              registryChildIds.add(rec.childSessionId)
            }
          }
          const entries = await subagents.listChildren(args.parentSessionId)
          for (const e of entries) {
            if (e.kind !== 'child') continue
            if (deletedIds.has(e.id) || archivedSet.has(e.id)) continue
            // 一次性子代理不列为持久记录；运行中的 btw 子代理已由注册表列出（防双卡片）
            if (e.mode === 'one-shot' || registryChildIds.has(e.id)) continue
            let boundarySeq = null
            if (legacyBoundaryCache.has(e.id)) {
              boundarySeq = legacyBoundaryCache.get(e.id)
            } else {
              try {
                if (persistence !== undefined) {
                  const info = await persistence.inspect(e.id)
                  if (info && info.meta && Number.isSafeInteger(info.meta.seedLength)) {
                    boundarySeq = info.meta.seedLength - 1
                  }
                }
              } catch (error) { boundarySeq = null }
              legacyBoundaryCache.set(e.id, boundarySeq)
            }
            const isBtw = e.label && String(e.label).indexOf('btw: ') === 0
            if (isBtw) {
              btws.push({ id: e.id, activity: e.activity, mode: e.mode, label: e.label, boundarySeq })
            } else {
              subs.push({ id: e.id, kind: 'subagent', activity: e.activity, mode: e.mode, label: e.label || null, boundarySeq })
            }
          }
        }
        return { ok: true, subs, btws, deleted: Array.from(deletedIds) }
      } catch (error) {
        return { ok: false, error: errorText(error) }
      }
    })

    // ---------- 压缩注入 ----------
    const TEMPLATES = {
      brief: '你是会话整理助手。请用不超过 200 字概括下面子会话的目标、结论与待办事项。',
      detailed: '你是会话整理助手。请分节整理下面子会话内容：背景、过程要点、最终产出、遗留问题，总长不超过 800 字。',
      actions: '你是会话整理助手。请列出下面子会话的结论与可执行行动项清单（每条一句），总长不超过 400 字。',
    }

    function extractTranscript(events) {
      const lines = []
      for (const ev of events) {
        if (!ev) continue
        const d = ev.data || {}
        if (ev.type === 'user/message') {
          const t = textOfBlocks(d.content)
          if (t) lines.push('用户: ' + t)
        } else if (ev.type === 'assistant/message') {
          const t = textOfBlocks(d.message ? d.message.content : undefined)
          if (t) lines.push('助手: ' + t)
        } else if (ev.type === 'tool/call') {
          lines.push('工具调用: ' + (d.name || '工具'))
        }
      }
      return lines
    }

    function capLines(lines, budget) {
      const out = []
      let n = 0
      for (const l of lines) {
        if (n + l.length > budget) {
          out.push(l.slice(0, Math.max(0, budget - n)) + '…(截断)')
          break
        }
        out.push(l)
        n += l.length
      }
      return out
    }

    async function compress(childId, parentAgent, template) {
      if (sessionQuery === undefined || llm === undefined) throw new Error('compression services unavailable')
      const snap = await sessionQuery.readSession(childId)
      const lines = capLines(extractTranscript(snap.events), 60000)
      const text = lines.join('\n') || '（子会话暂无内容）'
      const sel = {
        provider: parentAgent.options && parentAgent.options.provider,
        model: parentAgent.options && parentAgent.options.model,
      }
      if (!sel.provider || !sel.model) {
        const def = agentDefaultModel !== undefined ? agentDefaultModel.currentSelection() : undefined
        if (def) {
          sel.provider = sel.provider || def.provider
          sel.model = sel.model || def.model
        }
      }
      if (!sel.provider || !sel.model) throw new Error('无法确定模型配置')
      let summary = ''
      for await (const chunk of llm.stream({
        provider: sel.provider,
        model: sel.model,
        system: TEMPLATES[template] || TEMPLATES.brief,
        messages: [{ role: 'user', content: [{ type: 'text', text }] }],
        maxTokens: 1024,
      })) {
        if (chunk && chunk.type === 'text-delta' && typeof chunk.text === 'string') summary += chunk.text
      }
      const s = summary.trim()
      if (s === '') throw new Error('压缩结果为空')
      return s
    }

    harness.handle('bsm/sub-inject', async (args) => {
      try {
        const parent = await requireLiveAgent(args.parentSessionId)
        // btw 卡片 id（'btw-xxx'）→ 实际子会话 id（rec.childSessionId）；普通子会话 id 原样使用
        let targetChildId = args.childSessionId
        let isBtw = false
        const brec = btwRegistry.get(args.childSessionId)
        if (brec !== undefined && brec.childSessionId !== null && brec.childSessionId !== undefined) {
          targetChildId = brec.childSessionId
          isBtw = true
        }
        const summary = await compress(targetChildId, parent, args.template || 'brief')
        const head = isBtw
          ? '【btw 摘要】btw ' + args.childSessionId + ' 的问答整理：'
          : '【子会话摘要】子会话 ' + targetChildId + ' 的工作整理：'
        const message = makePluginUserMessage(head + '\n' + summary, 'recall')
        parent.inject(message)
        return { ok: true, messageId: message.id }
      } catch (error) {
        return { ok: false, error: errorText(error) }
      }
    })

    // ---------- RPC：打断 / 停止 ----------
    harness.handle('bsm/interrupt', (args) => {
      try {
        try {
          subagents.interrupt(args.sessionId, { kind: 'user', parentSessionId: args.parentSessionId })
        } catch (e1) {
          // fork 子会话等普通会话：直接取消当前轮次（保留排队消息）
          const agent = agents !== undefined ? agents.get(args.sessionId) : undefined
          if (agent !== undefined) agent.cancel({ kind: 'user' }, { keepInbox: true })
          else throw e1
        }
        return { ok: true }
      } catch (error) {
        return { ok: false, error: errorText(error) }
      }
    })

    harness.handle('bsm/stop-main', (args) => {
      try {
        if (agents === undefined) return { ok: false, error: 'agent registry unavailable' }
        const agent = agents.get(args.sessionId)
        if (agent === undefined) return { ok: false, error: '会话未在运行' }
        agent.cancel({ kind: 'user' }, { keepInbox: true })
        return { ok: true }
      } catch (error) {
        return { ok: false, error: errorText(error) }
      }
    })

    // ---------- M3：/btw 上下文无关插话（一次性只读子代理：继承上下文、无会话管理、无收尾通知） ----------
    const BTW_ALLOW = ['read', 'read_image', 'glob', 'grep', 'web_search', 'skill']
    const BTW_EFFORTS = ['off', 'high', 'max'] // 低=off（快速直接）/ 中=high（标准，默认）/ 高=max（深入）
    let btwEffortPref = 'high' // settings 页经 bsm/btw-set-effort 下发；进程内偏好（动态插件生命周期内有效）
    const BTW_PERSONA = '你是 /btw 临时会话：回答用户的临时询问。你通过父会话上下文（fork 种子或提示中附带的转录）了解背景，'
      + '但只拥有只读工具：不修改任何文件、不执行命令、不创建子代理、不改动任何状态。'
      + '不要调用 report 工具向主会话回传内容。'

    // btw 思考深度档位（settings 页选择后同步到宿主，/btw 命令统一读取）
    harness.handle('bsm/btw-set-effort', async (args) => {
      const v = String(args && args.effort)
      if (BTW_EFFORTS.indexOf(v) >= 0) btwEffortPref = v
      return { ok: true, effort: btwEffortPref }
    })

    function lastTurnBoundaryOf(session) {
      const events = session.events
      for (let i = events.length - 1; i >= 0; i--) {
        if (events[i] && events[i].type === 'turn/end') return i
      }
      return null
    }

    // 子代理管理器旁路的一次性 runner：直接经未追踪原始 registry 创建子代理（owner=undefined、
    // meta 无 origin），不走 subagents.start → 不注册 continuation 激活记录 → 不触发
    // notifySettlement/subagent-report 向主会话注入并唤醒（用户报告的主会话自动执行根因）。
    // 子代理组合仍沿用 applyChildComposition 语义：join 父组合 + persona + 只读工具白名单。
    const BTW_DELEGATION_TEXT = '你是主会话派生的临时只读子代理：你的权限范围在创建时固定，不可在本会话内扩大'
      + '——需要批准的操作会被自动拒绝。当任务需要超出范围的能力时，不要重试被拒绝的操作；'
      + '在回复中说明限制，由主会话处理。'

    async function createBtw(parent, text) {
      const t0 = Date.now()
      const id = 'btw-' + randId()
      const controller = typeof AbortController !== 'undefined' ? new AbortController() : null
      const rec = {
        id,
        parentSessionId: parent.id,
        question: text,
        answer: '',
        error: '',
        transcript: '',
        childSessionId: null,
        running: true,
        at: Date.now(),
        boundarySeq: lastTurnBoundaryOf(parent.session),
        controller,
        startedMs: null,
        doneMs: null,
      }
      btwRegistry.set(id, rec)
      void (async () => {
        let handle = null
        try {
          if (agents === undefined || typeof agents.create !== 'function') {
            throw new Error('agent registry unavailable')
          }
          // 与 createSub 相同：经 cordis 全局符号取未追踪的原始 registry（this.ctx = 构造 ctx
          // = 宿主根，无 agent 作用域 → owner = undefined → 不产生结算/回报注入）
          let registry = agents
          try {
            const orig = agents[Symbol.for('cordis.original')]
            if (orig !== undefined && orig !== null && typeof orig === 'object' && typeof orig.create === 'function') {
              registry = orig
            }
          } catch (error) { /* 回退到追踪实例 */ }
          const childId = 'btw-' + randId()
          const effort = BTW_EFFORTS.indexOf(btwEffortPref) >= 0 ? btwEffortPref : 'high'
          const pack = buildHistoryPack(
            parent.session.events,
            rec.boundarySeq === null ? parent.session.events.length - 1 : rec.boundarySeq,
            24, 40000,
          )
          const taskText = pack !== ''
            ? '【父会话近期上下文（来自主会话 ' + parent.id + '）】\n' + pack + '\n\n【用户临时询问】\n' + text
            : text
          handle = await registry.create({
            sessionId: childId,
            // 不设 origin / delegationDepth：不入子代理目录、不参与 subagent 血缘统计、
            // 不触发结算通知（与官方 fork 相同的"普通会话"分类）
            meta: {
              ...(parent.session.header && parent.session.header.cwd !== undefined
                ? { cwd: parent.session.header.cwd }
                : {}),
              parentSession: parent.id,
            },
            agentOptions: {
              ...(parent.options && parent.options.provider !== undefined
                ? { provider: parent.options.provider } : {}),
              ...(parent.options && parent.options.model !== undefined
                ? { model: parent.options.model } : {}),
              ...(parent.options && parent.options.maxTokens !== undefined
                ? { maxTokens: parent.options.maxTokens } : {}),
            },
            setup: (childCtx) => {
              // btw 思考深度：agent/request waterfall 覆盖 reasoningEffort
              //（作用域过滤：仅影响本子代理自身的模型请求；off=低/high=中/max=高）
              if (typeof childCtx.on === 'function') {
                try {
                  childCtx.on('agent/request', async (_payload, next) => {
                    const resolved = await next()
                    if (resolved === null || typeof resolved !== 'object') return resolved
                    return Object.assign({}, resolved, { reasoningEffort: effort })
                  })
                } catch (error) { /* ignore */ }
              }
              const ap = childCtx.get('agentPresets')
              if (ap !== undefined && typeof ap.composeFrom === 'function') {
                try { ap.composeFrom(childCtx, parent.ctx) } catch (error) { /* ignore */ }
              }
              if (childCtx.systemPrompt !== undefined) {
                try {
                  if (typeof childCtx.systemPrompt.context === 'function') {
                    childCtx.systemPrompt.context({ name: 'subagent:delegation', order: 120, text: BTW_DELEGATION_TEXT })
                  }
                  if (typeof childCtx.systemPrompt.section === 'function') {
                    childCtx.systemPrompt.section({ name: 'deployment:persona', order: 0, text: BTW_PERSONA })
                  }
                } catch (error) { /* ignore */ }
              }
              if (childCtx.tools !== undefined && typeof childCtx.tools.restrict === 'function') {
                try { childCtx.tools.restrict({ allow: BTW_ALLOW }) } catch (error) { /* ignore */ }
              }
            },
          })
          rec.childSessionId = childId
          const child = handle.agent
          const flags = { cancelled: false }
          const onAbort = () => {
            flags.cancelled = true
            try { child.cancel({ kind: 'parent' }) } catch (error) { /* ignore */ }
          }
          if (controller !== null) controller.signal.addEventListener('abort', onAbort, { once: true })
          try {
            rec.startedMs = Date.now() - t0
            if (!flags.cancelled) {
              // followup = 下一轮 + 唤醒：子代理执行一问一答后自动回到空闲
              child.followup(makePluginUserMessage(taskText, 'user'))
              await child.whenIdle()
            }
            rec.doneMs = Date.now() - t0
            // 从子代理自身事件读取回答（最后一次助手文本）与完整转录
            const evs = child.session && child.session.events ? child.session.events : []
            rec.transcript = transcriptOf(evs)
            let out = ''
            let hadTurnError = false
            for (let i = evs.length - 1; i >= 0; i--) {
              const ev = evs[i]
              if (!ev || !ev.type) continue
              if (out === '' && ev.type === 'assistant/message') {
                const d = ev.data || {}
                out = textOfBlocks(d.message ? d.message.content : undefined)
              }
              if (ev.type === 'turn-error') hadTurnError = true
            }
            rec.answer = out !== ''
              ? out
              : (hadTurnError ? '（btw 轮次出错，未产生文本回答；可重试或查看主会话日志）' : '（btw 已完成，但未产生文本回答）')
          } finally {
            if (controller !== null) controller.signal.removeEventListener('abort', onAbort)
          }
        } catch (error) {
          rec.error = errorText(error)
          rec.answer = '（btw 未完成：' + errorText(error) + '）'
          rec.doneMs = Date.now() - t0
        } finally {
          // 无论成败都释放子代理并归档其派生会话（主会话界面之外的副产物，不进任何列表）
          if (handle !== null && typeof handle.dispose === 'function') {
            try { await handle.dispose() } catch (error) { /* ignore */ }
          }
          if (rec.childSessionId !== null && rec.childSessionId !== undefined
            && workspaceRegistry !== undefined && typeof workspaceRegistry.archiveSession === 'function') {
            try { await workspaceRegistry.archiveSession(rec.childSessionId) } catch (error) { /* ignore */ }
          }
          rec.running = false
        }
      })()
      return { id }
    }

    const commands = ctx.get('commands')
    if (commands !== undefined) {
      ctx.effect(() => commands.register({
        name: 'btw',
        description: '上下文无关的临时询问（只读工具，回答显示在主会话 btw 卡片，可手动销毁/创建子会话/发送给主会话）',
        input: { hint: '临时询问内容' },
        handler: async ({ agent, rawInput }) => {
          try {
            const text = String(rawInput || '').trim()
            if (text === '') return { kind: 'error', text: 'btw 需要询问内容' }
            const { id } = await createBtw(agent, text)
            return {
              kind: 'success',
              text: 'btw 临时会话已创建（' + id + '）。回答将显示在主会话的 btw 卡片中，可手动销毁/创建子会话/发送给主会话。',
            }
          } catch (error) {
            return { kind: 'error', text: 'btw 创建失败：' + errorText(error) }
          }
        },
      }))
    }

    harness.handle('bsm/btw-create', async (args) => {
      try {
        const parent = await requireLiveAgent(args.sessionId)
        const text = String(args.text || '').trim()
        if (text === '') return { ok: false, error: 'btw 需要询问内容' }
        const { id } = await createBtw(parent, text)
        return { ok: true, id }
      } catch (error) {
        return { ok: false, error: errorText(error) }
      }
    })

    // btw 回答读取（内存注册表，瞬时返回）
    harness.handle('bsm/btw-answer', async (args) => {
      try {
        const rec = btwRegistry.get(args.childSessionId)
        if (rec === undefined) return { ok: true, text: '', missing: true }
        return {
          ok: true,
          text: rec.answer ? rec.answer.slice(0, 4000) : '',
          running: rec.running,
          startedMs: rec.startedMs,
          doneMs: rec.doneMs,
          error: rec.error || null,
        }
      } catch (error) {
        return { ok: false, error: errorText(error) }
      }
    })

    // btw 销毁：从注册表移除；若仍在运行则中止；遗留子代理 btw 同时持久归档（更新后不再复现）
    harness.handle('bsm/btw-destroy', async (args) => {
      try {
        deletedIds.add(args.childSessionId)
        const rec = btwRegistry.get(args.childSessionId)
        const archiveTarget = rec !== undefined && rec.childSessionId !== null && rec.childSessionId !== undefined
          ? rec.childSessionId
          : args.childSessionId
        if (rec !== undefined) {
          btwRegistry.delete(args.childSessionId)
          if (rec.controller !== null && typeof rec.controller.abort === 'function') {
            try { rec.controller.abort() } catch (error) { /* ignore */ }
          }
        }
        if (workspaceRegistry !== undefined && typeof workspaceRegistry.archiveSession === 'function') {
          try { await workspaceRegistry.archiveSession(archiveTarget) } catch (error) { /* ignore */ }
        }
        return { ok: true }
      } catch (error) {
        return { ok: false, error: errorText(error) }
      }
    })

    // btw 创建子会话：fork 主会话最新轮次边界（agent+session 一次建成），
    // 并把 btw 完整问答转录（问 + 工具调用 + 答）注入新子会话，继承 btw 上下文。
    harness.handle('bsm/btw-promote', async (args) => {
      try {
        const parent = await requireLiveAgent(args.parentSessionId)
        const rec = btwRegistry.get(args.childSessionId)
        const question = rec ? rec.question : ''
        const answer = rec ? rec.answer : ''
        const transcript = rec && typeof rec.transcript === 'string' && rec.transcript !== ''
          ? rec.transcript
          : null
        const events = parent.session.events
        let boundary = -1
        for (let i = events.length - 1; i >= 0; i--) {
          if (events[i] && events[i].type === 'turn/end') { boundary = i; break }
        }
        if (boundary < 0) throw new Error('主会话尚无完成的轮次，无法创建子会话')
        const made = await createSub(parent, boundary, null, args.mode)
        if (sessionTitle !== undefined && typeof sessionTitle.rename === 'function') {
          const childSess = sessions !== undefined ? sessions.get(made.childId) : undefined
          if (childSess !== undefined) {
            try { sessionTitle.rename(childSess, '子会话（自 btw）') } catch (error) { /* ignore */ }
          }
        }
        const note = transcript !== null
          ? '以下是延续自 btw 临时会话的完整问答记录（含工具调用过程），作为本子会话的工作背景：\n\n'
            + transcript
          : '延续 btw 提问：' + (question || '（见 btw 卡片）')
            + (answer !== '' ? '\n\n参考回答：\n' + answer : '')
        const live = agents !== undefined ? agents.get(made.childId) : undefined
        if (live !== undefined) {
          try { live.inject(makePluginUserMessage(note, 'recall')) } catch (error) { /* ignore */ }
        }
        return {
          ok: true,
          newChildId: made.childId,
          kind: 'fork',
          timings: made.timings,
          inheritedTranscript: transcript !== null,
        }
      } catch (error) {
        return { ok: false, error: errorText(error) }
      }
    })

    // ---------- 点赞/点踩代理 ----------
    harness.handle('bsm/feedback-list', async (args) => {
      try {
        if (feedback === undefined) return { ok: false, error: 'messageFeedback unavailable' }
        const res = await feedback.list({ sessionId: args.sessionId })
        if (res && res.ok === true && res.value) {
          return { ok: true, items: res.value.items || [] }
        }
        return { ok: true, items: [] }
      } catch (error) {
        return { ok: false, error: errorText(error) }
      }
    })

    harness.handle('bsm/feedback-put', async (args) => {
      try {
        if (feedback === undefined) return { ok: false, error: 'messageFeedback unavailable' }
        const res = await feedback.put({
          sessionId: args.sessionId,
          messageId: args.messageId,
          rating: args.rating === 'negative' ? 'negative' : 'positive',
          ifVersion: args.ifVersion === undefined ? null : args.ifVersion,
        })
        if (res && res.ok === true && res.value) {
          return { ok: true, item: res.value }
        }
        return { ok: false, error: res && res.error ? String(res.error.code || res.error) : 'put rejected' }
      } catch (error) {
        return { ok: false, error: errorText(error) }
      }
    })

    // ---------- 模型可用的子会话创建工具 ----------
    const createSubTool = harness.defineTool({
      name: 'bsm_create_sub',
      description:
        '在当前会话的指定轮次边界创建子会话（session fork：血缘持久记录于子会话 header）。'
        + 'mode=window（默认）时以最近 24 轮转录为种子快速创建；mode=full 时复制边界之前的全部上下文（慢）。'
        + 'boundarySeq 省略时取最后完成的轮次边界。子会话创建后以卡片形式标记在主会话该轮次尾部，'
        + '并在左侧会话栏嵌套显示于主会话之下；其工作不会自动进入主会话上下文（需手动"压缩注入主会话"）。',
      parameters: {
        type: 'object',
        properties: {
          sessionId: { type: 'string', description: '父会话 id；省略时取当前会话。' },
          boundarySeq: { type: 'number', description: '轮次边界事件序号（turn/end seq）；省略时取最后完成的轮次边界。' },
          prompt: { type: 'string', description: '子会话的初始任务提示。' },
          mode: { type: 'string', description: '继承模式：window（转录种子，快，默认）/ full（完整 fork，慢）。' },
        },
      },
      output: {
        schema: { type: 'json' },
        render: (_args, value) => [{ type: 'text', text: JSON.stringify(value, null, 2) }],
      },
      execute: async (args, exec) => {
        try {
          const sid = args.sessionId
            || (exec && exec.agent && exec.agent.id)
          if (!sid) throw new Error('无法确定父会话 id')
          const parent = await requireLiveAgent(sid)
          let boundary = args.boundarySeq
          if (boundary === undefined || boundary === null) {
            const events = parent.session.events
            let last = -1
            for (let i = events.length - 1; i >= 0; i--) {
              if (events[i] && events[i].type === 'turn/end') { last = i; break }
            }
            if (last < 0) throw new Error('父会话尚无完成的轮次')
            boundary = last
          }
          return await createSub(parent, boundary, args.prompt, args.mode)
        } catch (error) {
          return { ok: false, error: errorText(error) }
        }
      },
    })
    harness.registerTool(ctx, createSubTool)
  },
}
