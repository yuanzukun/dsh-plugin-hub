# Changelog

## 0.2.0 - 2026-08-13

### Added

- Added guarded CSS file import and JPEG/PNG/WebP background upload with compression and size enforcement.
- Added draft persistence, revision conflict handling, explicit remote/local conflict resolution, and expanded host/client regression coverage.
- Added the Aurora Nexus example theme and preview asset.

### Changed

- Migrated the plugin manifest and dependencies to the DSH npm `next` contract: DSH rc.5, scoped Cordis rc.4, and scoped Schemastery rc.4.
- Replaced the removed client settings event with the forwarded `settings/document-updated` remote event.
- Declared all client runtime services, including `remote`, and aligned the bundle externals with the rc.5 loader module table.
- Made builds clean stale artifacts before compiling and added a reproducible pnpm lockfile.

### Fixed

- Prevented stale load/save responses from rolling back newer settings revisions or overwriting newer drafts.
- Prevented overlapping imports and background uploads from replacing edits made while file processing was in progress.
- Kept the settings UI recoverable after malformed host values, connection resets, and synchronization failures.

## 0.1.0 - 2026-08-09

- Initial DSH Custom CSS bundle with shared host settings, RPC synchronization, and browser style injection.
