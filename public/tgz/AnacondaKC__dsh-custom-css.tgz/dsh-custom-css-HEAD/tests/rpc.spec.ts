import { describe, expect, it, vi } from 'vitest'
import { createCssRpcHandler, type CssSettingsSeam } from '../src/rpc.ts'
import { CUSTOM_CSS_NS, type CssSettingsValue } from '../src/types.ts'
import { SettingsConflictError } from '@deepseek-ai/dsh-settings'

/** Build an in-memory Settings seam with revision-checked replace semantics. */
function makeSeam(initial: CssSettingsValue = { enabled: false, css: '' }): {
  seam: CssSettingsSeam
  stored: CssSettingsValue
  revisions: number[]
} {
  const stored = { ...initial }
  let revision = 0
  const revisions: number[] = []
  return {
    stored,
    revisions,
    seam: {
      describe: vi.fn(() => [{
        ns: CUSTOM_CSS_NS,
        schema: {},
        value: stored,
        revision,
        applies: 'live' as const,
      }]),
      replace: vi.fn(async (_ns, section, expectedRevision) => {
        if (expectedRevision !== undefined && expectedRevision !== revision) {
          throw new SettingsConflictError(CUSTOM_CSS_NS, expectedRevision, revision)
        }
        Object.assign(stored, section)
        revision += 1
        revisions.push(revision)
      }),
    },
  }
}

describe('dsh-custom-css RPC handlers', () => {
  it('serves the resolved view on the read channel', async () => {
    const { seam } = makeSeam({ enabled: true, css: 'body {}' })
    const handler = createCssRpcHandler(seam, false)

    const response = await handler('get', {}, new AbortController().signal)

    expect(response).toEqual({
      ok: true,
      value: { value: { enabled: true, css: 'body {}' }, revision: 0 },
    })
  })

  it('rejects unknown or malformed read endpoints', async () => {
    const { seam } = makeSeam()
    const handler = createCssRpcHandler(seam, false)

    const unknown = await handler('save', {}, new AbortController().signal)
    expect(unknown).toMatchObject({ ok: false, error: { code: 'bad-request' } })

    const malformed = await handler('get', { extra: 1 }, new AbortController().signal)
    expect(malformed).toMatchObject({ ok: false, error: { code: 'bad-request' } })
  })

  it('saves a validated payload through the revision-checked replace', async () => {
    const { seam, revisions } = makeSeam()
    const handler = createCssRpcHandler(seam, true)

    const response = await handler('save', {
      value: { enabled: true, css: 'body { color: red }' },
      expectedRevision: 0,
    }, new AbortController().signal)

    expect(seam.replace).toHaveBeenCalledWith(
      CUSTOM_CSS_NS,
      { enabled: true, css: 'body { color: red }' },
      0,
    )
    expect(revisions).toEqual([1])
    expect(response).toMatchObject({
      ok: true,
      value: { value: { enabled: true, css: 'body { color: red }' }, revision: 1 },
    })
  })

  it('maps a stale writer to settings-conflict with expected/actual', async () => {
    const { seam } = makeSeam({ enabled: true, css: 'body {}' })
    const handler = createCssRpcHandler(seam, true)
    await seam.replace(CUSTOM_CSS_NS, { enabled: false, css: '' }, 0) // revision → 1

    const response = await handler('save', {
      value: { enabled: true, css: 'body { color: blue }' },
      expectedRevision: 0,
    }, new AbortController().signal)

    expect(response).toMatchObject({
      ok: false,
      error: {
        code: 'settings-conflict',
        details: { ns: CUSTOM_CSS_NS, expected: 0, actual: 1 },
      },
    })
  })

  it('rejects invalid, oversized, and obsolete save payloads before they reach the seam', async () => {
    const { seam } = makeSeam()
    const handler = createCssRpcHandler(seam, true)

    const badShape = await handler('save', {
      value: { enabled: 'yes', css: '' },
      expectedRevision: 0,
    }, new AbortController().signal)
    expect(badShape).toMatchObject({ ok: false, error: { code: 'bad-request' } })

    const obsoletePreset = await handler('save', {
      value: { enabled: true, css: '', preset: 'custom' },
      expectedRevision: 0,
    }, new AbortController().signal)
    expect(obsoletePreset).toMatchObject({ ok: false, error: { code: 'bad-request' } })

    const tooLong = await handler('save', {
      value: { enabled: true, css: 'x'.repeat(1024 * 1024 + 1) },
      expectedRevision: 0,
    }, new AbortController().signal)
    expect(tooLong).toMatchObject({ ok: false, error: { code: 'bad-request' } })

    expect(seam.replace).not.toHaveBeenCalled()
  })

  it('rejects unknown write endpoints', async () => {
    const { seam } = makeSeam()
    const handler = createCssRpcHandler(seam, true)

    const response = await handler('get', {}, new AbortController().signal)
    expect(response).toMatchObject({ ok: false, error: { code: 'bad-request' } })
  })
})
