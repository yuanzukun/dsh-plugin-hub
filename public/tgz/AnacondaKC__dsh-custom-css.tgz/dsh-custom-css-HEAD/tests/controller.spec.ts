import { describe, expect, it, vi } from 'vitest'
// The real runtime/client entry is browser-only; tests use a minimal snapshot
// store with the same immutable-snapshot contract.
vi.mock('@deepseek-ai/dsh-client-runtime/client', () => ({
  createSnapshotStore: (init: unknown, _opts?: unknown) => {
    let state = init as never
    const listeners = new Set<() => void>()
    return {
      getSnapshot: () => state,
      subscribe: (fn: () => void) => {
        listeners.add(fn)
        return () => { listeners.delete(fn) }
      },
      update: (mutator: (draft: never) => void) => {
        const draft = structuredClone(state)
        mutator(draft)
        state = draft
        for (const fn of [...listeners]) fn()
      },
      set: (next: unknown) => {
        state = next as never
        for (const fn of [...listeners]) fn()
      },
    }
  },
}))
import { CssSettingsController } from '../src/client/controller.ts'
import { CUSTOM_CSS_READ_CHANNEL, CUSTOM_CSS_WRITE_CHANNEL, type CssSettingsValue } from '../src/types.ts'

type RpcCall = (channel: string, endpoint: string, payload: unknown) => Promise<{
  ok: boolean
  value?: unknown
  error?: { code: string; message: string; details?: Record<string, unknown> }
}>

type RpcResponse = Awaited<ReturnType<RpcCall>>

function mockConnection(call: RpcCall, isLoopback = true): { connection: { rpc: { call: typeof call }; isLoopback: boolean } } {
  return { connection: { rpc: { call: vi.fn(call) }, isLoopback } }
}

const VALUE: CssSettingsValue = { enabled: true, css: 'body { color: red }' }

describe('CssSettingsController', () => {
  it('loads the host view into serverValue and draft', async () => {
    const { connection } = mockConnection(async () => ({ ok: true, value: { value: VALUE, revision: 3 } }))
    const controller = new CssSettingsController(connection as never)

    await controller.load()

    const state = controller.store.getSnapshot()
    expect(state.status).toBe('ready')
    expect(state.serverValue).toEqual(VALUE)
    expect(state.draft).toEqual(VALUE)
    expect(state.revision).toBe(3)
    expect(state.dirty).toBe(false)
  })

  it('rejects malformed host views before they reach render state', async () => {
    const { connection } = mockConnection(async () => ({ ok: true, value: { value: { enabled: true }, revision: 3 } }))
    const controller = new CssSettingsController(connection as never)

    await controller.load()

    const state = controller.store.getSnapshot()
    expect(state.status).toBe('error')
    expect(state.serverValue).toEqual({ enabled: false, css: '' })
    expect(state.draft).toEqual({ enabled: false, css: '' })
  })

  it('surfaces load failures without clobbering the last committed value', async () => {
    const { connection } = mockConnection(async () => ({ ok: false, error: { code: 'internal', message: 'boom' } }))
    const controller = new CssSettingsController(connection as never)

    await controller.load()

    const state = controller.store.getSnapshot()
    expect(state.status).toBe('error')
    expect(state.error).toBe('boom')
    expect(state.serverValue).toEqual({ enabled: false, css: '' })
  })

  it('keeps an edit made before the initial read resolves', async () => {
    let resolveRead!: (response: RpcResponse) => void
    const { connection } = mockConnection(async () => await new Promise<RpcResponse>((resolve) => { resolveRead = resolve }))
    const controller = new CssSettingsController(connection as never)

    const pendingLoad = controller.load()
    controller.updateDraft((draft) => { draft.css = 'body { color: purple }'; draft.enabled = true })
    resolveRead({ ok: true, value: { value: VALUE, revision: 3 } })
    await pendingLoad

    const state = controller.store.getSnapshot()
    expect(state.status).toBe('ready')
    expect(state.serverValue).toEqual(VALUE)
    expect(state.draft.css).toContain('purple')
    expect(state.dirty).toBe(true)
  })

  it('marks drafts dirty and persists them for refresh survival', async () => {
    const { connection } = mockConnection(async () => ({ ok: true, value: { value: VALUE, revision: 3 } }))
    const controller = new CssSettingsController(connection as never)
    await controller.load()

    controller.updateDraft((draft) => { draft.css = 'body { color: blue }' })

    expect(controller.store.getSnapshot().dirty).toBe(true)
    expect(controller.store.getSnapshot().serverValue.css).toBe('body { color: red }')
  })

  it('saves the draft through the write channel and commits it', async () => {
    const { connection } = mockConnection(async (channel) => {
      if (channel === CUSTOM_CSS_READ_CHANNEL) return { ok: true, value: { value: VALUE, revision: 3 } }
      return { ok: true, value: { value: { ...VALUE, css: 'body { color: blue }' }, revision: 4 } }
    })
    const controller = new CssSettingsController(connection as never)
    await controller.load()
    controller.updateDraft((draft) => { draft.css = 'body { color: blue }' })

    const failure = await controller.save()

    expect(failure).toBeNull()
    const state = controller.store.getSnapshot()
    expect(state.status).toBe('ready')
    expect(state.dirty).toBe(false)
    expect(state.serverValue.css).toBe('body { color: blue }')
    expect(state.revision).toBe(4)
    expect(connection.rpc.call).toHaveBeenCalledWith(
      CUSTOM_CSS_WRITE_CHANNEL,
      'save',
      { value: { ...VALUE, css: 'body { color: blue }' }, expectedRevision: 3 },
    )
  })

  it('preserves edits made while a host write is in flight', async () => {
    let resolveWrite!: (response: RpcResponse) => void
    const { connection } = mockConnection(async (channel) => {
      if (channel === CUSTOM_CSS_READ_CHANNEL) return { ok: true, value: { value: VALUE, revision: 3 } }
      return await new Promise<RpcResponse>((resolve) => { resolveWrite = resolve })
    })
    const controller = new CssSettingsController(connection as never)
    await controller.load()
    controller.updateDraft((draft) => { draft.css = 'body { color: blue }' })

    const pendingSave = controller.save()
    controller.updateDraft((draft) => { draft.css = 'body { color: purple }' })
    resolveWrite({
      ok: true,
      value: { value: { ...VALUE, css: 'body { color: blue }' }, revision: 4 },
    })
    await pendingSave

    const state = controller.store.getSnapshot()
    expect(state.serverValue.css).toBe('body { color: blue }')
    expect(state.draft.css).toBe('body { color: purple }')
    expect(state.dirty).toBe(true)
    expect(state.status).toBe('ready')
  })

  it('keeps saving visible when an unchanged reload arrives during a write', async () => {
    let resolveWrite!: (response: RpcResponse) => void
    const { connection } = mockConnection(async (channel) => {
      if (channel === CUSTOM_CSS_READ_CHANNEL) return { ok: true, value: { value: VALUE, revision: 3 } }
      return await new Promise<RpcResponse>((resolve) => { resolveWrite = resolve })
    })
    const controller = new CssSettingsController(connection as never)
    await controller.load()
    controller.updateDraft((draft) => { draft.css = 'body { color: blue }' })

    const pendingSave = controller.save()
    await controller.reload()
    expect(controller.store.getSnapshot().status).toBe('saving')

    resolveWrite({ ok: true, value: { value: { ...VALUE, css: 'body { color: blue }' }, revision: 4 } })
    await pendingSave
    expect(controller.store.getSnapshot().status).toBe('ready')
  })

  it('keeps the draft and re-reads the host value on settings-conflict', async () => {
    let revision = 3
    const { connection } = mockConnection(async (channel, endpoint, payload) => {
      if (channel === CUSTOM_CSS_READ_CHANNEL && endpoint === 'get') {
        return { ok: true, value: { value: revision === 3 ? VALUE : { ...VALUE, css: 'body { color: green }' }, revision } }
      }
      if (channel === CUSTOM_CSS_WRITE_CHANNEL && endpoint === 'save') {
        const request = payload as { expectedRevision: number }
        if (request.expectedRevision !== revision) {
          return { ok: false, error: { code: 'settings-conflict', message: 'stale', details: { ns: 'dsh-custom-css', expected: request.expectedRevision, actual: revision } } }
        }
        revision += 1
        return { ok: true, value: { value: { ...VALUE, css: 'body { color: blue }' }, revision } }
      }
      return { ok: false, error: { code: 'internal', message: 'unexpected call' } }
    })
    const controller = new CssSettingsController(connection as never)
    await controller.load()
    controller.updateDraft((draft) => { draft.css = 'body { color: blue }' })
    // A remote writer lands first.
    await connection.rpc.call(CUSTOM_CSS_WRITE_CHANNEL, 'save', { value: { ...VALUE, css: 'body { color: green }' }, expectedRevision: 3 })

    const failure = await controller.save()

    expect(failure).toBe('conflict')
    const state = controller.store.getSnapshot()
    expect(state.status).toBe('conflict')
    expect(state.draft.css).toBe('body { color: blue }')
    expect(state.serverValue.css).toBe('body { color: green }')
    expect(state.dirty).toBe(true)
  })

  it('does not turn a local draft into a conflict when reload returns the same host view', async () => {
    const host = { value: VALUE, revision: 3 }
    const { connection } = mockConnection(async () => ({ ok: true, value: host }))
    const controller = new CssSettingsController(connection as never)
    await controller.load()
    controller.updateDraft((draft) => { draft.css = 'body { color: purple }' })

    await controller.reload()

    expect(controller.store.getSnapshot()).toMatchObject({
      status: 'ready',
      dirty: true,
      serverValue: VALUE,
      draft: { ...VALUE, css: 'body { color: purple }' },
    })
  })

  it('leaves the saving state when a conflict cannot re-read the remote view', async () => {
    let reads = 0
    const { connection } = mockConnection(async (channel) => {
      if (channel === CUSTOM_CSS_READ_CHANNEL) {
        reads += 1
        return reads === 1
          ? { ok: true, value: { value: VALUE, revision: 3 } }
          : { ok: false, error: { code: 'internal', message: 'offline' } }
      }
      return { ok: false, error: { code: 'settings-conflict', message: 'stale', details: {} } }
    })
    const controller = new CssSettingsController(connection as never)
    await controller.load()
    controller.updateDraft((draft) => { draft.css = 'body { color: blue }' })

    expect(await controller.save()).toBe('conflict')
    expect(controller.store.getSnapshot()).toMatchObject({
      status: 'error',
      draft: { ...VALUE, css: 'body { color: blue }' },
      dirty: true,
    })
    expect(controller.store.getSnapshot().error).toContain('could not reload remote settings')
  })

  it('refuses an automatic save while the page is in conflict', async () => {
    let host = { value: VALUE, revision: 3 }
    const { connection } = mockConnection(async (channel) => {
      if (channel === CUSTOM_CSS_READ_CHANNEL) return { ok: true, value: host }
      return { ok: true, value: { value: { ...VALUE, css: 'unexpected' }, revision: 5 } }
    })
    const controller = new CssSettingsController(connection as never)
    await controller.load()
    controller.updateDraft((draft) => { draft.css = 'body { color: purple }' })
    host = { value: { ...VALUE, css: 'body { color: green }' }, revision: 4 }
    await controller.reload()

    const failure = await controller.save()

    expect(failure).toBe('conflict')
    expect(connection.rpc.call).not.toHaveBeenCalledWith(CUSTOM_CSS_WRITE_CHANNEL, 'save', expect.anything())
    expect(controller.store.getSnapshot().status).toBe('conflict')
  })

  it('does not roll state back when a stale save response arrives after a newer reload', async () => {
    let host = { value: VALUE, revision: 1 }
    let resolveWrite!: (response: RpcResponse) => void
    const { connection } = mockConnection(async (channel) => {
      if (channel === CUSTOM_CSS_READ_CHANNEL) return { ok: true, value: host }
      return await new Promise<RpcResponse>((resolve) => { resolveWrite = resolve })
    })
    const controller = new CssSettingsController(connection as never)
    await controller.load()
    controller.updateDraft((draft) => { draft.css = 'body { color: blue }' })

    const pendingSave = controller.save()
    host = { value: { ...VALUE, css: 'body { color: green }' }, revision: 3 }
    await controller.reload()
    resolveWrite({ ok: true, value: { value: { ...VALUE, css: 'body { color: blue }' }, revision: 2 } })

    expect(await pendingSave).toBe('conflict')
    const state = controller.store.getSnapshot()
    expect(state.revision).toBe(3)
    expect(state.serverValue.css).toBe('body { color: green }')
    expect(state.draft.css).toBe('body { color: blue }')
    expect(state.status).toBe('conflict')
  })

  it('keeps an unsaved draft when a remote change arrives mid-edit', async () => {
    let css = VALUE.css
    let revision = 3
    const { connection } = mockConnection(async () => ({ ok: true, value: { value: { ...VALUE, css }, revision } }))
    const controller = new CssSettingsController(connection as never)
    await controller.load()
    controller.updateDraft((draft) => { draft.css = 'body { color: purple }' })
    css = 'body { color: green }'
    revision = 4

    await controller.reload()

    const state = controller.store.getSnapshot()
    expect(state.status).toBe('conflict')
    expect(state.draft.css).toBe('body { color: purple }')
    expect(state.serverValue.css).toBe('body { color: green }')
  })

  it('allows an explicit overwrite from a remote page after conflict resolution', async () => {
    let host = { value: VALUE, revision: 3 }
    const { connection } = mockConnection(async (channel, _endpoint, payload) => {
      if (channel === CUSTOM_CSS_READ_CHANNEL) return { ok: true, value: host }
      const request = payload as { value: CssSettingsValue; expectedRevision: number }
      expect(request.expectedRevision).toBe(4)
      host = { value: request.value, revision: 5 }
      return { ok: true, value: host }
    }, false)
    const controller = new CssSettingsController(connection as never)
    await controller.load()
    controller.updateDraft((draft) => { draft.css = 'body { color: orange }' })
    host = { value: { ...VALUE, css: 'body { color: green }' }, revision: 4 }
    await controller.reload()

    const failure = await controller.save({ overrideConflict: true })

    expect(failure).toBeNull()
    expect(controller.store.getSnapshot()).toMatchObject({
      status: 'ready',
      revision: 5,
      serverValue: { css: 'body { color: orange }' },
      dirty: false,
    })
  })
})
