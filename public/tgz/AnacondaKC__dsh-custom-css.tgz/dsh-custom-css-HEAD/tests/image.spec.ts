import { describe, expect, it } from 'vitest'
import { ImageCompressionError, compressImage } from '../src/client/image.ts'

describe('background image compression guards', () => {
  it('rejects unsupported image formats before decoding', async () => {
    const file = { type: 'image/svg+xml', size: 20 } as File

    await expect(compressImage(file, 1024)).rejects.toMatchObject<ImageCompressionError>({
      reason: 'unsupported',
    })
  })

  it('rejects an impossible CSS capacity before decoding', async () => {
    const file = { type: 'image/png', size: 20 } as File

    await expect(compressImage(file, 1)).rejects.toMatchObject<ImageCompressionError>({
      reason: 'too-large',
    })
  })

  it('rejects bytes that do not match a claimed supported MIME type before decoding', async () => {
    const file = {
      type: 'image/png',
      size: 12,
      slice: () => ({
        arrayBuffer: async () => new Uint8Array([0x3c, 0x73, 0x76, 0x67]).buffer,
      }),
    } as File

    await expect(compressImage(file, 1024)).rejects.toMatchObject<ImageCompressionError>({
      reason: 'unsupported',
    })
  })
})
