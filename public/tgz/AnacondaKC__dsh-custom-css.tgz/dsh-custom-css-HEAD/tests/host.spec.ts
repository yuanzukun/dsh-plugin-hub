import { describe, expect, it, vi } from 'vitest'
import { apply } from '../src/index.ts'
import { registerCssRpc, type CssSettingsSeam } from '../src/rpc.ts'
import {
  CUSTOM_CSS_READ_CHANNEL,
  CUSTOM_CSS_WRITE_CHANNEL,
  DEFAULT_CSS_SETTINGS,
} from '../src/types.ts'

describe('dsh-custom-css host registration', () => {
  it('registers a complete base value so an absent settings section is renderable', () => {
    const register = vi.fn(() => ({}))
    const handle = vi.fn()
    const ctx = {
      inject: (_services: unknown, callback: (services: { settings: { register: typeof register } }) => void) => {
        callback({ settings: { register } })
      },
      connection: { rpc: { handle } },
    }

    apply(ctx as never)

    expect(register).toHaveBeenCalledWith(
      expect.anything(),
      expect.anything(),
      { applies: 'live', base: DEFAULT_CSS_SETTINGS },
    )
    const schema = register.mock.calls[0]![1] as (value: unknown) => unknown
    expect(schema(DEFAULT_CSS_SETTINGS)).toEqual(DEFAULT_CSS_SETTINGS)
  })

  it('puts both RPC routes behind the trusted-host policy', () => {
    const handle = vi.fn()
    const seam: CssSettingsSeam = {
      describe: vi.fn(() => []),
      replace: vi.fn(),
    }

    registerCssRpc({ connection: { rpc: { handle } } } as never, seam)

    expect(handle).toHaveBeenCalledWith(
      CUSTOM_CSS_READ_CHANNEL,
      expect.any(Function),
      { authority: 'trusted-host' },
    )
    expect(handle).toHaveBeenCalledWith(
      CUSTOM_CSS_WRITE_CHANNEL,
      expect.any(Function),
      { authority: 'trusted-host' },
    )
  })
})
