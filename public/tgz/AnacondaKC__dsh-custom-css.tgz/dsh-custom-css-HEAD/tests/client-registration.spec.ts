import { describe, expect, it, vi } from 'vitest'

vi.mock('../src/client/ThemeSection.tsx', () => ({
  ThemeSection: () => null,
}))

vi.mock('@deepseek-ai/dsh-client-ui-primitives', () => ({
  Button: () => null,
  IconCodeOutline16: () => null,
  IconFolderOpen16: () => null,
  StateDot: () => null,
}))

vi.mock('@deepseek-ai/dsh-client-runtime/client', () => ({
  createSnapshotStore: (init: unknown) => {
    let state = init
    const listeners = new Set<() => void>()
    return {
      getSnapshot: () => state,
      subscribe: (listener: () => void) => {
        listeners.add(listener)
        return () => { listeners.delete(listener) }
      },
      update: (mutator: (draft: never) => void) => {
        const draft = structuredClone(state) as never
        mutator(draft)
        state = draft
        for (const listener of listeners) listener()
      },
    }
  },
}))
import type { ConnectionHandle } from '@deepseek-ai/dsh-client-connection/client'
import { apply, inject } from '../src/client/index.ts'
import { CUSTOM_CSS_NS, DEFAULT_CSS_SETTINGS } from '../src/types.ts'

describe('dsh-custom-css client registration', () => {
  it('declares every Cordis service it reads', () => {
    expect(inject).toEqual(['slots', 'connection', 'locale', 'remote'])
  })

  it('reloads only for its forwarded rc.5 settings event', async () => {
    const call = vi.fn(async () => ({
      ok: true as const,
      value: { value: DEFAULT_CSS_SETTINGS, revision: 1 },
    }))
    const connection = { rpc: { call } } as unknown as ConnectionHandle
    let onDocumentUpdated: ((ns: string) => void) | undefined
    const remote = {
      $on: vi.fn((event: string, listener: (ns: string) => void) => {
        expect(event).toBe('settings/document-updated')
        onDocumentUpdated = listener
        return () => undefined
      }),
    }
    const ctx = {
      get: vi.fn(() => connection),
      locale: {
        bind: vi.fn(() => (key: string) => key),
        register: vi.fn(() => () => undefined),
      },
      remote,
      slots: {
        inject: vi.fn(() => () => undefined),
      },
      on: vi.fn(() => () => undefined),
      effect: vi.fn((callback: () => unknown, label: string) => {
        if (label === 'dsh-custom-css: host sync') callback()
      }),
    }

    apply(ctx as never)
    await vi.waitFor(() => expect(call).toHaveBeenCalledTimes(1))

    onDocumentUpdated?.('other-plugin')
    expect(call).toHaveBeenCalledTimes(1)

    onDocumentUpdated?.(CUSTOM_CSS_NS)
    await vi.waitFor(() => expect(call).toHaveBeenCalledTimes(2))
  })
})
