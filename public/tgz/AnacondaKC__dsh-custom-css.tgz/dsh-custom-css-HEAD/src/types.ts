/**
 * Shared types and constants for dsh-custom-css. Pure type/constant surface
 * (no runtime imports): the node half and the client bundle both consume it
 * — the client inlines it via a relative import, the node half via tsc.
 */

/** Host Settings namespace owned by this plugin (lowercase kebab per the settings seam). */
export const CUSTOM_CSS_NS = 'dsh-custom-css'

/** Read RPC channel: trusted-host authority, so LAN pages can apply shared styles. */
export const CUSTOM_CSS_READ_CHANNEL = '/dsh-custom-css-read'

/** Write RPC channel: trusted-host authority, so approved remote pages can change shared styles. */
export const CUSTOM_CSS_WRITE_CHANNEL = '/dsh-custom-css-write'

/** Upper bound for CSS text stored in the host settings document, measured in JavaScript string code units. */
export const CSS_MAX_LENGTH = 1024 * 1024

/** The persisted settings shape (host Settings schema). */
export interface CssSettingsValue {
  /** Master switch; false by default — installing the plugin changes nothing. */
  enabled: boolean
  /** Shared custom CSS text. */
  css: string
}

/** Fresh-install and reset value. */
export const DEFAULT_CSS_SETTINGS: CssSettingsValue = Object.freeze({
  enabled: false,
  css: '',
})

/** The read RPC success payload: resolved value plus its concurrency revision. */
export interface CssSettingsView {
  value: CssSettingsValue
  /** Host-managed revision; send it back as expectedRevision on save. */
  revision: number
}

/** The write RPC request payload. */
export interface CssSaveRequest {
  value: CssSettingsValue
  expectedRevision: number
}

/** RPC endpoint names. */
export type CssRpcEndpoint = 'get' | 'save'

/** Machine-readable error codes the client controller understands. */
export type CssRpcErrorCode =
  | 'bad-request'
  | 'settings-conflict'
  | 'settings-rejected'
  | 'internal'
