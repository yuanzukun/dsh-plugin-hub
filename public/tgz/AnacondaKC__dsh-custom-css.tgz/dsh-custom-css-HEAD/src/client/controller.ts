/**
 * Browser-side settings controller for dsh-custom-css.
 *
 * `serverValue` is the only value applied to the page. `draft` is local editor
 * state, persisted only for refresh recovery. Every host write carries the
 * revision read with its view, so remote changes can be detected before an
 * editor silently replaces them.
 */
import type { ConnectionHandle } from '@deepseek-ai/dsh-client-connection/client'
import { createSnapshotStore, type SnapshotStore } from '@deepseek-ai/dsh-client-runtime/client'
import {
  CSS_MAX_LENGTH,
  CUSTOM_CSS_READ_CHANNEL,
  CUSTOM_CSS_WRITE_CHANNEL,
  DEFAULT_CSS_SETTINGS,
  type CssSaveRequest,
  type CssSettingsValue,
  type CssSettingsView,
} from '../types.ts'

/** localStorage key holding only the unsaved editor draft (never applied styles). */
const DRAFT_STORAGE_KEY = 'dsh.custom-css.draft'

export interface CssControllerState {
  status: 'loading' | 'ready' | 'saving' | 'conflict' | 'error'
  serverValue: CssSettingsValue
  draft: CssSettingsValue
  revision: number
  /** draft differs from serverValue (unsaved edits or restored draft). */
  dirty: boolean
  error: string | null
}

interface SaveOptions {
  /** A conflict needs an explicit user choice before its draft may be written. */
  overrideConflict?: boolean
}

function initialState(): CssControllerState {
  return {
    status: 'loading',
    serverValue: { ...DEFAULT_CSS_SETTINGS },
    draft: { ...DEFAULT_CSS_SETTINGS },
    revision: 0,
    dirty: false,
    error: null,
  }
}

/** Compare the fixed persisted shape without depending on object key order. */
function sameValue(a: CssSettingsValue, b: CssSettingsValue): boolean {
  return a.enabled === b.enabled && a.css === b.css
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value)
}

/** Validate an untrusted RPC/localStorage value before it reaches render state. */
function parseValue(value: unknown): CssSettingsValue {
  if (!isRecord(value) || typeof value.enabled !== 'boolean' || typeof value.css !== 'string') {
    throw new Error('custom CSS settings value is malformed')
  }
  if (value.css.length > CSS_MAX_LENGTH) {
    throw new Error(`custom CSS exceeds the ${CSS_MAX_LENGTH} character limit`)
  }
  return { enabled: value.enabled, css: value.css }
}

function parseView(value: unknown): CssSettingsView {
  if (!isRecord(value) || !Number.isSafeInteger(value.revision) || (value.revision as number) < 0) {
    throw new Error('custom CSS settings view is malformed')
  }
  return { value: parseValue(value.value), revision: value.revision as number }
}

/** Read the unsaved draft from localStorage (non-browser runs: none). */
function readStoredDraft(): CssSettingsValue | undefined {
  try {
    if (typeof localStorage === 'undefined') return undefined
    const raw = localStorage.getItem(DRAFT_STORAGE_KEY)
    if (raw === null) return undefined
    return parseValue(JSON.parse(raw))
  } catch {
    return undefined
  }
}

/** Persist the draft (failures only lose the draft, never break the store). */
function writeStoredDraft(value: CssSettingsValue | undefined): void {
  try {
    if (typeof localStorage === 'undefined') return
    if (value === undefined) localStorage.removeItem(DRAFT_STORAGE_KEY)
    else localStorage.setItem(DRAFT_STORAGE_KEY, JSON.stringify(value))
  } catch {
    // Quota/private-mode: draft persistence is best-effort only.
  }
}

/** Owner of settings-page state: loads, saves, drafts, and conflict resolution. */
export class CssSettingsController {
  readonly store: SnapshotStore<CssControllerState> = createSnapshotStore(initialState())

  private latestLoad = 0
  private draftVersion = 0
  private saving = false
  private disposed = false

  constructor(
    private readonly connection: ConnectionHandle,
  ) {}

  /** Fetch the current host view. A remote refresh preserves a dirty draft. */
  async load(preserveDraft = false): Promise<void> {
    const request = ++this.latestLoad
    try {
      const response = await this.connection.rpc.call(CUSTOM_CSS_READ_CHANNEL, 'get', {})
      if (!response.ok) throw new Error(response.error.message)
      const view = parseView(response.value)
      if (this.disposed || request !== this.latestLoad) return
      this.accept(view, preserveDraft)
    } catch (error) {
      if (this.disposed || request !== this.latestLoad) return
      this.fail(error)
    }
  }

  /** Refresh after a host settings event or transport reset. */
  reload(): Promise<void> {
    return this.load(true)
  }

  /** Apply one editor mutation to the local draft, never the committed value. */
  updateDraft(mutator: (draft: CssSettingsValue) => void): void {
    if (this.disposed) return
    this.draftVersion += 1
    this.store.update((state) => {
      mutator(state.draft)
      state.dirty = !sameValue(state.draft, state.serverValue)
      // Editing after a transient error makes retry possible. If the editor
      // now exactly matches the latest host value, it also resolves a conflict.
      if (state.status === 'error' || (state.status === 'conflict' && !state.dirty)) {
        state.status = 'ready'
        state.error = null
      }
      writeStoredDraft(state.dirty ? state.draft : undefined)
    })
  }

  /**
   * Persist the current draft. Normal auto/manual saves refuse a conflict;
   * callers must opt in after presenting an explicit overwrite action.
   * @returns null on success, otherwise a compact user-visible failure code/message.
   */
  async save(options: SaveOptions = {}): Promise<string | null> {
    if (this.disposed) return 'disposed'
    if (this.saving) return 'saving'

    const state = this.store.getSnapshot()
    if (state.status === 'conflict' && options.overrideConflict !== true) return 'conflict'
    if (!state.dirty) return null

    const draftVersion = this.draftVersion
    const payload: CssSaveRequest = {
      value: { ...state.draft },
      expectedRevision: state.revision,
    }
    this.saving = true
    this.store.update((next) => {
      next.status = 'saving'
      next.error = null
    })

    try {
      const response = await this.connection.rpc.call(CUSTOM_CSS_WRITE_CHANNEL, 'save', payload)
      if (!response.ok) {
        if (response.error.code === 'settings-conflict') {
          await this.settleConflict(response.error.message, payload.expectedRevision)
          return 'conflict'
        }
        throw new Error(response.error.message)
      }

      const view = parseView(response.value)
      if (!this.publishSave(view, payload.value, draftVersion)) {
        // A later host view is already known locally. Never roll it back with
        // this delayed response; keep the draft for an explicit resolution.
        void this.reload()
        return 'conflict'
      }
      return null
    } catch (error) {
      if (!this.disposed && this.store.getSnapshot().status !== 'conflict') this.fail(error)
      return error instanceof Error ? error.message : String(error)
    } finally {
      this.saving = false
    }
  }

  /** Discard the local draft and return the editor to the latest host value. */
  discardDraft(): void {
    if (this.disposed) return
    this.draftVersion += 1
    this.store.update((state) => {
      state.draft = { ...state.serverValue }
      state.dirty = false
      state.status = 'ready'
      state.error = null
    })
    writeStoredDraft(undefined)
  }

  /** Prevent in-flight responses from publishing after plugin disposal. */
  dispose(): void {
    this.disposed = true
    this.latestLoad += 1
  }

  /** Apply a fetched view only when it cannot move the known revision backward. */
  private accept(view: CssSettingsView, preserveDraft: boolean): void {
    const state = this.store.getSnapshot()
    if (view.revision < state.revision) return

    // Keep edits even if a user starts typing before the initial read returns;
    // only a remote refresh labels those edits as a conflict.
    const keepDraft = state.dirty
    const draft = keepDraft ? { ...state.draft } : this.recoverDraft(view)
    const dirty = !sameValue(draft, view.value)
    // A reconnect often re-reads exactly the view we already know. That must
    // not turn an ordinary unsaved edit into a conflict. A retained conflict
    // clears automatically once the remote value catches up to the draft.
    const remoteChanged = view.revision > state.revision || !sameValue(view.value, state.serverValue)
    const conflict = dirty && (state.status === 'conflict' || (preserveDraft && keepDraft && remoteChanged))
    // A connection reset can re-read the exact pre-save view while its write
    // request is still in flight. Keep the public state truthful in that case.
    const stillSaving = this.saving && state.status === 'saving' && !remoteChanged

    this.store.update((next) => {
      if (view.revision < next.revision) return
      next.serverValue = { ...view.value }
      next.revision = view.revision
      next.draft = draft
      next.dirty = dirty
      next.status = conflict ? 'conflict' : stillSaving ? 'saving' : 'ready'
      next.error = null
    })
  }

  /** Publish a successful write only if no newer host revision is known. */
  private publishSave(view: CssSettingsView, savedValue: CssSettingsValue, savedDraftVersion: number): boolean {
    if (this.disposed) return false
    const state = this.store.getSnapshot()
    if (view.revision < state.revision) {
      this.enterConflictIfDirty()
      return false
    }

    const draftUnchanged = this.draftVersion === savedDraftVersion && sameValue(state.draft, savedValue)
    this.store.update((next) => {
      if (view.revision < next.revision) return
      next.serverValue = { ...view.value }
      next.revision = view.revision
      if (draftUnchanged) {
        next.draft = { ...view.value }
        next.dirty = false
      } else {
        next.dirty = !sameValue(next.draft, next.serverValue)
      }
      next.status = 'ready'
      next.error = null
    })

    if (draftUnchanged) writeStoredDraft(undefined)
    return true
  }

  /** Re-read after a revision conflict without accepting an older response. */
  private async settleConflict(message: string, expectedRevision: number): Promise<void> {
    const view = await this.readView()
    if (this.disposed) return

    const state = this.store.getSnapshot()
    if (view !== undefined && view.revision >= state.revision) {
      const draft = { ...state.draft }
      const dirty = !sameValue(draft, view.value)
      this.store.update((next) => {
        if (view.revision < next.revision) return
        next.serverValue = { ...view.value }
        next.revision = view.revision
        next.draft = draft
        next.dirty = dirty
        next.status = dirty ? 'conflict' : 'ready'
        next.error = null
      })
      return
    }

    // A settings-change event may already have delivered a newer view while
    // this fallback read was in flight. Otherwise, do not leave the editor in
    // the transient `saving` state: the remote value is unknown and must be
    // loaded again before a user can safely resolve the conflict.
    if (state.revision > expectedRevision) return
    this.store.update((next) => {
      if (next.revision > expectedRevision) return
      next.status = 'error'
      next.error = `${message} (could not reload remote settings)`
    })
  }

  private enterConflictIfDirty(): void {
    this.store.update((state) => {
      if (!state.dirty) return
      state.status = 'conflict'
      state.error = null
    })
  }

  /** Restore a stored unsaved draft when it differs from the committed value. */
  private recoverDraft(view: CssSettingsView): CssSettingsValue {
    const stored = readStoredDraft()
    if (stored !== undefined && !sameValue(stored, view.value)) return stored
    writeStoredDraft(undefined)
    return { ...view.value }
  }

  private async readView(): Promise<CssSettingsView | undefined> {
    try {
      const response = await this.connection.rpc.call(CUSTOM_CSS_READ_CHANNEL, 'get', {})
      return response.ok ? parseView(response.value) : undefined
    } catch {
      return undefined
    }
  }

  private fail(error: unknown): void {
    this.store.update((state) => {
      state.status = 'error'
      state.error = error instanceof Error ? error.message : String(error)
    })
  }
}
