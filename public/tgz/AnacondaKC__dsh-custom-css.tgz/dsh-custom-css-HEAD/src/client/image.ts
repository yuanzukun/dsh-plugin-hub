/**
 * Client-side background-image compression. Images are converted to a small
 * JPEG data URI so they can use the existing settings transport safely.
 */

/** Reject oversized input before asking the browser to decode it. */
const MAX_INPUT_BYTES = 16 * 1024 * 1024
/** A decoded source beyond this size is not reasonable for a settings-page background. */
const MAX_SOURCE_PIXELS = 40 * 1024 * 1024
/** Longest edge of the first output attempt. Later attempts scale down further. */
const MAX_EDGE = 1920
const SCALE_STEPS = [1, 0.75, 0.5]
const QUALITY_STEPS = [0.85, 0.7, 0.55]
const DATA_URL_PREFIX = 'data:image/jpeg;base64,'
const SUPPORTED_IMAGE_TYPES = new Set(['image/jpeg', 'image/png', 'image/webp'])
type SupportedImageType = 'image/jpeg' | 'image/png' | 'image/webp'

export class ImageCompressionError extends Error {
  constructor(readonly reason: 'unsupported' | 'too-large') {
    super(reason)
  }
}

export interface CompressedImage {
  /** data:image/jpeg;base64,... URI ready to embed in CSS. */
  dataUrl: string
}

function sniffImageType(bytes: Uint8Array): SupportedImageType | undefined {
  const isJpeg = bytes.length >= 3 && bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff
  if (isJpeg) return 'image/jpeg'

  const isPng = bytes.length >= 8
    && bytes[0] === 0x89 && bytes[1] === 0x50 && bytes[2] === 0x4e && bytes[3] === 0x47
    && bytes[4] === 0x0d && bytes[5] === 0x0a && bytes[6] === 0x1a && bytes[7] === 0x0a
  if (isPng) return 'image/png'

  const isWebp = bytes.length >= 12
    && bytes[0] === 0x52 && bytes[1] === 0x49 && bytes[2] === 0x46 && bytes[3] === 0x46
    && bytes[8] === 0x57 && bytes[9] === 0x45 && bytes[10] === 0x42 && bytes[11] === 0x50
  if (isWebp) return 'image/webp'

  return undefined
}

/** Validate declared type and binary signature before any expensive decode. */
async function assertInput(file: File, maxDataUrlLength: number): Promise<void> {
  if (!Number.isSafeInteger(file.size) || file.size < 0 || file.size > MAX_INPUT_BYTES
    || !Number.isSafeInteger(maxDataUrlLength) || maxDataUrlLength <= DATA_URL_PREFIX.length) {
    throw new ImageCompressionError('too-large')
  }
  if (file.type !== '' && !SUPPORTED_IMAGE_TYPES.has(file.type)) throw new ImageCompressionError('unsupported')

  const bytes = new Uint8Array(await file.slice(0, 12).arrayBuffer())
  const detectedType = sniffImageType(bytes)
  if (detectedType === undefined || (file.type !== '' && file.type !== detectedType)) {
    throw new ImageCompressionError('unsupported')
  }
}

/** Read the source once; browser decoding errors are surfaced to the caller. */
async function loadBitmap(file: File): Promise<ImageBitmap> {
  return await createImageBitmap(file)
}

function canvasFor(bitmap: ImageBitmap, scale: number): HTMLCanvasElement {
  const edgeScale = Math.min(1, MAX_EDGE / Math.max(bitmap.width, bitmap.height)) * scale
  const canvas = document.createElement('canvas')
  canvas.width = Math.max(1, Math.round(bitmap.width * edgeScale))
  canvas.height = Math.max(1, Math.round(bitmap.height * edgeScale))
  const context = canvas.getContext('2d')
  if (context === null) throw new Error('canvas 2d context unavailable')
  context.drawImage(bitmap, 0, 0, canvas.width, canvas.height)
  return canvas
}

function toBlob(canvas: HTMLCanvasElement, quality: number): Promise<Blob> {
  return new Promise((resolve, reject) => {
    canvas.toBlob((blob) => {
      if (blob === null) reject(new Error('canvas JPEG encoding failed'))
      else resolve(blob)
    }, 'image/jpeg', quality)
  })
}

function toDataUrl(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader()
    reader.addEventListener('load', () => {
      if (typeof reader.result === 'string') resolve(reader.result)
      else reject(new Error('image data URL encoding failed'))
    }, { once: true })
    reader.addEventListener('error', () => reject(reader.error ?? new Error('image data URL encoding failed')), { once: true })
    reader.readAsDataURL(blob)
  })
}

/**
 * Compress an image to fit the caller's exact remaining CSS capacity. The
 * canvas encoding is asynchronous and retries both quality and dimensions.
 */
export async function compressImage(file: File, maxDataUrlLength: number): Promise<CompressedImage> {
  await assertInput(file, maxDataUrlLength)
  const bitmap = await loadBitmap(file)
  try {
    if (bitmap.width * bitmap.height > MAX_SOURCE_PIXELS) throw new ImageCompressionError('too-large')

    for (const scale of SCALE_STEPS) {
      const canvas = canvasFor(bitmap, scale)
      for (const quality of QUALITY_STEPS) {
        const dataUrl = await toDataUrl(await toBlob(canvas, quality))
        if (dataUrl.length <= maxDataUrlLength) return { dataUrl }
      }
    }
    throw new ImageCompressionError('too-large')
  } finally {
    bitmap.close()
  }
}
