/** Custom CSS settings section and guarded local-file import actions. */
import {
  Button,
  IconCodeOutline16,
  IconFolderOpen16,
  StateDot,
  type StateDotState,
} from '@deepseek-ai/dsh-client-ui-primitives'
import { useEffect, useMemo, useRef, useState, useSyncExternalStore, type ChangeEvent } from 'react'
import { CSS_MAX_LENGTH, type CssSettingsValue } from '../types.ts'
import { ImageCompressionError, compressImage } from './image.ts'
import type { CssSettingsController } from './controller.ts'
import type { CustomCssKey } from './locales.ts'
import css from './ThemeSection.module.css'

/** Background-image CSS block markers, used to replace a previous upload. */
const BG_MARK = '/* dsh-custom-css:background */'
const BG_END = '/* dsh-custom-css:background-end */'
const AUTO_SAVE_MS = 500
/** Allows valid multi-byte CSS while rejecting arbitrarily large files before reading them. */
const MAX_CSS_IMPORT_BYTES = CSS_MAX_LENGTH * 4

interface ImportGuard {
  request: number
  draftVersion: number
  draft: CssSettingsValue
}

/** Build full-page background rules that embed the data URI exactly once. */
function buildBackgroundCss(dataUrl: string): string {
  return `${BG_MARK}
:root {
  --dsh-bg: url('${dataUrl}');  /* 背景图（只内嵌一次，勿重复粘贴） */
  --dsh-bg-mask: 0.45;          /* 亮色遮罩透明度：越小图越清晰，改这里 */
  --dsh-bg-mask-dark: 0.55;     /* 暗色遮罩透明度：越小图越清晰，改这里 */
}
body [class$="_frame"][class$="_frame"] {
  background: linear-gradient(rgba(239, 243, 235, var(--dsh-bg-mask)), rgba(239, 243, 235, var(--dsh-bg-mask))), var(--dsh-bg) center / cover no-repeat fixed !important;
}
body[data-ds-dark-theme] [class$="_frame"][class$="_frame"] {
  background: linear-gradient(rgba(18, 22, 20, var(--dsh-bg-mask-dark)), rgba(18, 22, 20, var(--dsh-bg-mask-dark))), var(--dsh-bg) center / cover no-repeat fixed !important;
}
${BG_END}`
}

/** Replace the previous background block, or append one at the end. */
function upsertBackground(cssText: string, block: string): string {
  const complete = /\/\* dsh-custom-css:background \*\/[\s\S]*?\/\* dsh-custom-css:background-end \*\//
  if (complete.test(cssText)) return cssText.replace(complete, block)

  // A broken older block cannot safely coexist with a fresh one: drop its tail.
  const orphan = cssText.indexOf(BG_MARK)
  if (orphan >= 0) {
    const trimmed = cssText.slice(0, orphan).trimEnd()
    return trimmed === '' ? block : `${trimmed}\n\n${block}`
  }

  const trimmed = cssText.trimEnd()
  return trimmed === '' ? block : `${trimmed}\n\n${block}`
}

/** Capacity for the data URI after replacing/appending the generated block. */
function backgroundDataUrlCapacity(cssText: string): number {
  return CSS_MAX_LENGTH - upsertBackground(cssText, buildBackgroundCss('')).length
}

function countLines(text: string): number {
  let lines = 1
  for (let index = 0; index < text.length; index += 1) {
    if (text.charCodeAt(index) === 10) lines += 1
  }
  return lines
}

export interface ThemeSectionInjected {
  controller: CssSettingsController
  t: (key: CustomCssKey) => string
}

export function ThemeSection({ controller, t }: ThemeSectionInjected): React.ReactElement {
  const state = useSyncExternalStore(controller.store.subscribe, controller.store.getSnapshot)
  const timerRef = useRef<number | undefined>(undefined)
  const fileInputRef = useRef<HTMLInputElement | null>(null)
  const bgInputRef = useRef<HTMLInputElement | null>(null)
  const importRequestRef = useRef(0)
  const draftVersionRef = useRef(0)
  const [fileName, setFileName] = useState<string | null>(null)
  const [importError, setImportError] = useState<CustomCssKey | null>(null)
  const [isImporting, setIsImporting] = useState(false)

  const clearScheduledSave = (): void => {
    window.clearTimeout(timerRef.current)
    timerRef.current = undefined
  }

  useEffect(() => () => { clearScheduledSave() }, [])
  useEffect(() => {
    if (state.status === 'conflict' || state.status === 'loading') clearScheduledSave()
  }, [state.status])

  const saveDraft = (): void => {
    if (controller.store.getSnapshot().status === 'conflict') return
    void controller.save().then((failure) => {
      if (failure === 'saving' && controller.store.getSnapshot().status !== 'conflict') {
        timerRef.current = window.setTimeout(saveDraft, AUTO_SAVE_MS)
      }
    })
  }

  const scheduleSave = (delay: number): void => {
    const status = controller.store.getSnapshot().status
    if (status === 'conflict' || status === 'loading') return
    clearScheduledSave()
    timerRef.current = window.setTimeout(saveDraft, delay)
  }

  const markDraftMutation = (): void => {
    draftVersionRef.current += 1
  }

  const updateCss = (value: string, delay = AUTO_SAVE_MS): void => {
    setImportError(null)
    markDraftMutation()
    controller.updateDraft((draft) => {
      draft.enabled = true
      draft.css = value
    })
    scheduleSave(delay)
  }

  const onEnabledChange = (enabled: boolean): void => {
    setImportError(null)
    markDraftMutation()
    controller.updateDraft((draft) => {
      draft.enabled = enabled
    })
    scheduleSave(0)
  }

  const beginImport = (): ImportGuard => {
    const request = ++importRequestRef.current
    setIsImporting(true)
    return {
      request,
      draftVersion: draftVersionRef.current,
      draft: { ...controller.store.getSnapshot().draft },
    }
  }

  const isCurrentImport = (guard: ImportGuard): boolean => {
    const draft = controller.store.getSnapshot().draft
    return guard.request === importRequestRef.current
      && guard.draftVersion === draftVersionRef.current
      && guard.draft.enabled === draft.enabled
      && guard.draft.css === draft.css
  }

  const finishImport = (request: number): void => {
    if (request === importRequestRef.current) setIsImporting(false)
  }

  const onImport = async (event: ChangeEvent<HTMLInputElement>): Promise<void> => {
    const input = event.currentTarget
    const file = input.files?.[0]
    if (file === undefined) return
    const guard = beginImport()

    try {
      if (!file.name.toLowerCase().endsWith('.css')) {
        if (isCurrentImport(guard)) setImportError('import.invalidType')
        return
      }
      if (file.size > MAX_CSS_IMPORT_BYTES) {
        if (isCurrentImport(guard)) setImportError('import.tooLarge')
        return
      }

      const source = await file.text()
      if (!isCurrentImport(guard)) return
      if (source.length > CSS_MAX_LENGTH) {
        setImportError('import.tooLarge')
        return
      }
      setFileName(file.name)
      updateCss(source, 0)
    } catch {
      if (isCurrentImport(guard)) setImportError('import.readError')
    } finally {
      input.value = ''
      finishImport(guard.request)
    }
  }

  /** Compress and insert a background only if the editor stayed unchanged meanwhile. */
  const onPickBackground = async (event: ChangeEvent<HTMLInputElement>): Promise<void> => {
    const input = event.currentTarget
    const file = input.files?.[0]
    if (file === undefined) return
    const guard = beginImport()

    try {
      const dataUrl = (await compressImage(file, backgroundDataUrlCapacity(guard.draft.css))).dataUrl
      if (!isCurrentImport(guard)) return

      const latestCss = controller.store.getSnapshot().draft.css
      const next = upsertBackground(latestCss, buildBackgroundCss(dataUrl))
      if (next.length > CSS_MAX_LENGTH) {
        setImportError('background.tooLarge')
        return
      }
      updateCss(next, 0)
    } catch (error) {
      if (!isCurrentImport(guard)) return
      if (error instanceof ImageCompressionError && error.reason === 'unsupported') {
        setImportError('background.unsupported')
      } else if (error instanceof ImageCompressionError && error.reason === 'too-large') {
        setImportError('background.tooLarge')
      } else {
        setImportError('background.compressError')
      }
    } finally {
      input.value = ''
      finishImport(guard.request)
    }
  }

  const onSave = (): void => {
    clearScheduledSave()
    void controller.save()
  }

  const onOverwrite = (): void => {
    clearScheduledSave()
    void controller.save({ overrideConflict: true })
  }

  const onDiscard = (): void => {
    clearScheduledSave()
    markDraftMutation()
    controller.discardDraft()
  }

  const onReload = (): void => {
    clearScheduledSave()
    void controller.reload()
  }

  let statusKey: CustomCssKey
  let statusTone: StateDotState
  if (importError !== null) {
    statusKey = 'status.error'
    statusTone = 'error'
  } else if (state.status === 'loading') {
    statusKey = 'status.loading'
    statusTone = 'ongoing'
  } else if (state.status === 'saving') {
    statusKey = 'status.saving'
    statusTone = 'ongoing'
  } else if (state.status === 'conflict') {
    statusKey = 'status.conflict'
    statusTone = 'warning'
  } else if (state.status === 'error') {
    statusKey = 'status.error'
    statusTone = 'error'
  } else if (state.dirty) {
    statusKey = 'status.pending'
    statusTone = 'warning'
  } else if (!state.draft.enabled) {
    statusKey = 'status.disabled'
    statusTone = 'error'
  } else {
    statusKey = 'status.synced'
    statusTone = 'done'
  }

  const lineCount = useMemo(() => countLines(state.draft.css), [state.draft.css])
  const detail = importError === null ? state.error : t(importError)
  const loading = state.status === 'loading'
  const saveDisabled = !state.dirty || loading || state.status === 'saving' || state.status === 'conflict'
  const importsDisabled = loading || isImporting

  return (
    <div className={css.page}>
      <header className={css.pageHeader}>
        <div className={css.heading}>
          <h2 className={css.title}>{t('page.title')}</h2>
          <p className={css.scope}>{t('page.scope')}</p>
        </div>
        <div className={css.headerActions}>
          <label className={css.enableControl}>
            <span className={css.enableLabel}>{t('control.enabled')}</span>
            <input
              className={css.switchInput}
              type="checkbox"
              role="switch"
              checked={state.draft.enabled}
              disabled={loading}
              onChange={(event) => { onEnabledChange(event.currentTarget.checked) }}
            />
            <span className={css.switchTrack} aria-hidden="true"><span /></span>
          </label>
          <input
            ref={fileInputRef}
            hidden
            tabIndex={-1}
            type="file"
            accept=".css,text/css"
            onChange={(event) => { void onImport(event) }}
          />
          <input
            ref={bgInputRef}
            hidden
            tabIndex={-1}
            type="file"
            accept="image/jpeg,image/png,image/webp"
            onChange={(event) => { void onPickBackground(event) }}
          />
          <Button
            className={css.importButton}
            variant="outline"
            size="sm"
            icon={<IconFolderOpen16 size={16} />}
            disabled={importsDisabled}
            onClick={() => { bgInputRef.current?.click() }}
          >
            {t('action.background')}
          </Button>
          <Button
            className={css.importButton}
            variant="outline"
            size="sm"
            icon={<IconFolderOpen16 size={16} />}
            disabled={importsDisabled}
            onClick={() => { fileInputRef.current?.click() }}
          >
            {t('action.import')}
          </Button>
        </div>
      </header>

      <section className={css.editor} aria-label={t('editor.ariaLabel')}>
        <div className={css.editorToolbar}>
          <div className={css.fileIdentity}>
            <IconCodeOutline16 className={css.codeIcon} size={16} />
            <span className={css.fileName} title={fileName ?? t('editor.filename')}>
              {fileName ?? t('editor.filename')}
            </span>
            <span className={css.languageBadge}>CSS</span>
          </div>
          <div className={css.status} aria-live="polite">
            <StateDot state={statusTone} size={10} />
            <span>{t(statusKey)}</span>
          </div>
        </div>

        <textarea
          id="dsh-custom-css-textarea"
          className={css.textarea}
          spellCheck={false}
          value={state.draft.css}
          maxLength={CSS_MAX_LENGTH}
          disabled={loading}
          placeholder={t('css.placeholder')}
          aria-label={t('editor.ariaLabel')}
          aria-describedby={detail === null ? undefined : 'dsh-custom-css-message'}
          onChange={(event) => { updateCss(event.currentTarget.value) }}
        />

        <footer className={css.editorFooter}>
          <span className={css.stats}>
            {lineCount} {t(lineCount === 1 ? 'editor.line' : 'editor.lines')} · {state.draft.css.length} {t('editor.characters')}
          </span>
          <div className={css.footerRight}>
            {detail !== null && (
              <span id="dsh-custom-css-message" className={css.errorMessage} role="alert" title={detail}>
                {detail}
              </span>
            )}
            <div className={css.editorActions}>
              {state.status === 'conflict' ? (
                <>
                  <Button className={css.actionButton} variant="outline" size="sm" onClick={onDiscard}>
                    {t('action.useRemote')}
                  </Button>
                  <Button className={css.actionButton} variant="outline" size="sm" onClick={onOverwrite}>
                    {t('action.overwrite')}
                  </Button>
                </>
              ) : (
                <>
                  {state.status === 'error' && (
                    <Button className={css.actionButton} variant="outline" size="sm" onClick={onReload}>
                      {t('action.reload')}
                    </Button>
                  )}
                  {state.dirty && (
                    <Button className={css.actionButton} variant="outline" size="sm" disabled={saveDisabled} onClick={onSave}>
                      {t('action.save')}
                    </Button>
                  )}
                  {state.dirty && (
                    <Button className={css.actionButton} variant="outline" size="sm" disabled={loading || state.status === 'saving'} onClick={onDiscard}>
                      {t('action.discard')}
                    </Button>
                  )}
                </>
              )}
            </div>
          </div>
        </footer>
      </section>
    </div>
  )
}
