/**
 * dsh-custom-css, browser half: registers the Settings section, keeps a
 * controller in sync with the host settings via the plugin RPC channels, and
 * injects the effective CSS as one plugin-owned <style data-plugin> tag.
 *
 * Lifecycle rules (design doc v0.3):
 * - the tag is created inside ctx.effect and removed by its disposer; HMR
 *   additionally removes it via the data-plugin attribute before re-materializing;
 * - only the committed serverValue drives the injected styles (drafts preview
 *   in the editor only);
 * - `?dsh-custom-css=off` (safe mode) suppresses injection while keeping the
 *   Settings section available for recovery.
 */
import type { ConnectionHandle } from '@deepseek-ai/dsh-client-connection/client'
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client'
// Type-only: pulls the forwarded Host event contract and ctx.remote merge.
import type {} from '@deepseek-ai/dsh-api-remotes/client'
// Type-only: pulls the locale plugin's Context merge (ctx.locale).
import type {} from '@deepseek-ai/dsh-client-locale/client'
// Type-only: pulls the ui-settings SlotMap merge (the 'settings.section' entry).
import type {} from '@deepseek-ai/dsh-client-ui-settings/client'
import { CUSTOM_CSS_NS } from '../types.ts'
import { CssSettingsController } from './controller.ts'
import { ThemeSection, type ThemeSectionInjected } from './ThemeSection.tsx'
import { en, NS, zh, type CustomCssKey } from './locales.ts'

/** Plugin id == graph entry name == bundle registration key. */
export const ID = 'dsh-custom-css'

/** Style-tag data-plugin-css id for this plugin-owned stylesheet. */
const STYLE_TAG_ID = `${ID}/custom`

/** Query parameter that disables style injection for one page load. */
const SAFE_MODE_PARAM = 'dsh-custom-css'

declare module '@deepseek-ai/dsh-client-ui-slots' {
  interface LocaleNamespaceMap {
    /** The Custom CSS settings section copy. */
    customCss: CustomCssKey
  }
}

/** Required services: the slot registry, transport, and locale registry. */
export const inject = ['slots', 'connection', 'locale', 'remote']

/** Resolve the effective CSS for one committed value ('' disables injection). */
export function effectiveCss(value: { enabled: boolean; css: string }): string {
  return value.enabled ? value.css : ''
}

/** Browser plugin body: styles + settings section + host sync. */
export function apply(ctx: ClientContext): void {
  ctx.effect(() => { return ctx.locale.register(NS, { zh, en }) }, 'dsh-custom-css: dictionaries')

  // Single-package tsc compiles the host half's Context merge (src/index.ts)
  // into the same program, so ctx.get('connection') types as the host handle;
  // the browser runtime hands the client handle with api/isLoopback.
  const connection = ctx.get('connection') as unknown as ConnectionHandle
  const controller = new CssSettingsController(connection)
  const t = ctx.locale.bind(NS) as ThemeSectionInjected['t']
  const safeMode = typeof location !== 'undefined' && new URLSearchParams(location.search).has(SAFE_MODE_PARAM)

  // Style injection: one stable tag, content follows the committed value.
  ctx.effect(() => {
    const tag = document.createElement('style')
    tag.dataset.plugin = ID
    tag.dataset.pluginCss = STYLE_TAG_ID
    document.head.appendChild(tag)
    const render = (): void => {
      tag.textContent = safeMode ? '' : effectiveCss(controller.store.getSnapshot().serverValue)
    }
    const unsubscribe = controller.store.subscribe(render)
    render()
    return () => { unsubscribe(); tag.remove() }
  }, 'dsh-custom-css: style injection')

  // Host sync: initial load, remote settings changes, connection resets.
  ctx.effect(() => {
    void controller.load()
    const disposers = [
      ctx.remote.$on('settings/document-updated', (ns) => {
        if (String(ns) === CUSTOM_CSS_NS) void controller.reload()
      }),
      ctx.on('connection/reset', () => { void controller.reload() }),
    ]
    return () => { for (const dispose of disposers) dispose() }
  }, 'dsh-custom-css: host sync')

  const injected = (): ThemeSectionInjected => ({ controller, t })
  ctx.slots.inject('settings.section', () => ctx.slots.register({
    name: 'settings.section',
    id: 'custom-css',
    order: 90,
    label: () => t('nav.label'),
    inject: injected,
  }, ThemeSection))

  ctx.effect(() => () => controller.dispose(), 'dsh-custom-css: controller disposal')
}

export type { ThemeSectionInjected } from './ThemeSection.tsx'
