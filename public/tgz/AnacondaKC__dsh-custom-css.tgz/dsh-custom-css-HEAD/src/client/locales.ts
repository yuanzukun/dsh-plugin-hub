/** `dsh-custom-css` Settings-section dictionaries. */

/** Dictionary namespace owned by the client plugin. */
export const NS = 'customCss'

/** Simplified Chinese dictionary (the key-set source of truth). */
export const zh = {
  'nav.label': '自定义CSS',
  'page.title': '自定义 CSS',
  'page.scope': '主机共享样式表',
  'css.placeholder': '在此输入 CSS 代码…',
  'control.enabled': '启用',
  'action.import': '导入 CSS',
  'action.save': '保存修改',
  'action.reload': '重新加载',
  'action.discard': '放弃草稿',
  'action.useRemote': '采用远端版本',
  'action.overwrite': '覆盖远端版本',
  'editor.ariaLabel': 'CSS 代码编辑器',
  'editor.filename': 'custom.css',
  'editor.line': '行',
  'editor.lines': '行',
  'editor.characters': '字符',
  'status.loading': '正在加载',
  'status.saving': '正在保存',
  'status.pending': '等待保存',
  'status.synced': '已同步',
  'status.disabled': '已关闭',
  'status.conflict': '同步冲突',
  'status.error': '保存失败',
  'import.invalidType': '请选择 .css 文件',
  'import.tooLarge': 'CSS 内容不能超过 1,048,576 个字符',
  'import.readError': '无法读取该 CSS 文件',
  'action.background': '上传背景图',
  'background.compressError': '图片压缩失败，无法内嵌',
  'background.tooLarge': '图片过大，压缩后仍超限',
  'background.unsupported': '请上传 JPEG、PNG 或 WebP 图片',
} satisfies Record<string, string>

/** The key union. */
export type CustomCssKey = keyof typeof zh

/** English dictionary, checked complete against the zh key set. */
export const en = {
  'nav.label': 'Custom CSS',
  'page.title': 'Custom CSS',
  'page.scope': 'Host-shared stylesheet',
  'css.placeholder': 'Enter CSS here…',
  'control.enabled': 'Enabled',
  'action.import': 'Import CSS',
  'action.save': 'Save changes',
  'action.reload': 'Reload',
  'action.discard': 'Discard draft',
  'action.useRemote': 'Use remote version',
  'action.overwrite': 'Overwrite remote version',
  'editor.ariaLabel': 'CSS code editor',
  'editor.filename': 'custom.css',
  'editor.line': 'line',
  'editor.lines': 'lines',
  'editor.characters': 'characters',
  'status.loading': 'Loading',
  'status.saving': 'Saving',
  'status.pending': 'Pending save',
  'status.synced': 'Synced',
  'status.disabled': 'Disabled',
  'status.conflict': 'Sync conflict',
  'status.error': 'Save failed',
  'import.invalidType': 'Choose a .css file',
  'import.tooLarge': 'CSS content must be 1,048,576 characters or fewer',
  'import.readError': 'Could not read this CSS file',
  'action.background': 'Upload background',
  'background.compressError': 'Image compression failed',
  'background.tooLarge': 'Image too large after compression',
  'background.unsupported': 'Choose a JPEG, PNG, or WebP image',
} satisfies Record<CustomCssKey, string>
