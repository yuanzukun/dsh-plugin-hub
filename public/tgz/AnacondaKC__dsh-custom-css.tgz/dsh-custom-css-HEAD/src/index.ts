/**
 * dsh-custom-css host half: registers the `dsh-custom-css` Settings namespace
 * (the durable, multi-browser-shared store for the CSS text) and mounts the
 * read/write RPC channels the browser half talks to. The Web settings API
 * (`api.settings.*`) only serves an explicit allowlist of namespaces, so
 * plugin settings travel over its own channels instead (see rpc.ts).
 */
import type { Context } from '@deepseek-ai/cordis'
import z from '@deepseek-ai/schemastery'
// Type-only: carries the host Connection Context merge for ctx.connection.
import type {} from '@deepseek-ai/dsh-client-connection'
import { settingsNamespace, type SettingsScope } from '@deepseek-ai/dsh-settings'
import { registerCssRpc } from './rpc.ts'
import { CSS_MAX_LENGTH, CUSTOM_CSS_NS, DEFAULT_CSS_SETTINGS, type CssSettingsValue } from './types.ts'

/** Stable Cordis bundle name. */
export const name = 'dsh-custom-css'

/** Host services required by the settings registration and RPC channels. */
export const inject = ['settings', 'connection']

/** The namespace schema: JSON-shaped value, CSS bounded to protect the settings document. */
const CssSettingsSchema: z<CssSettingsValue> = z.object({
  enabled: z.boolean(),
  css: z.string().max(CSS_MAX_LENGTH),
})

/** Register the Settings namespace and mount the RPC channels. */
export function apply(ctx: Context): void {
  ctx.inject(['settings'], (settingsCtx) => {
    // An invalid stored section fails the registration itself — the earliest
    // point the schema can judge it (recovery: remove the `dsh-custom-css`
    // section from $DSH_HOME/settings.yaml and restart).
    const scope: SettingsScope<CssSettingsValue> = settingsCtx.settings.register(
      settingsNamespace(CUSTOM_CSS_NS),
      CssSettingsSchema,
      { applies: 'live', base: DEFAULT_CSS_SETTINGS },
    )
    void scope
    registerCssRpc(ctx, settingsCtx.settings)
  })
}
