/**
 * Host RPC handlers for dsh-custom-css. Two channels, both under the
 * trusted-host authority fence (loopback pages and every --trusted-host
 * authority may read AND write): remote pages apply shared styles and may
 * also change them — the settings page is the collaboration surface for
 * every visitor, not just the local machine. The write path goes through the
 * Settings seam's revision-checked `replace`, so a stale writer receives a
 * settings-conflict instead of silently overwriting a concurrent edit.
 */
import type { ConnectionRpcHandler, HostConnectionHandle } from '@deepseek-ai/dsh-client-connection'
import { z } from 'zod'
import type { Context } from '@deepseek-ai/cordis'
import SettingsProvider, { SettingsConflictError, settingsNamespace } from '@deepseek-ai/dsh-settings'
import {
  CSS_MAX_LENGTH,
  CUSTOM_CSS_NS,
  CUSTOM_CSS_READ_CHANNEL,
  CUSTOM_CSS_WRITE_CHANNEL,
  type CssSaveRequest,
  type CssSettingsValue,
  type CssSettingsView,
} from './types.ts'

type RpcResult = Awaited<ReturnType<ConnectionRpcHandler>>

const emptyPayloadSchema = z.object({}).strict()
const savePayloadSchema = z.object({
  value: z.object({
    enabled: z.boolean(),
    css: z.string().max(CSS_MAX_LENGTH),
  }).strict(),
  expectedRevision: z.number().int().min(0),
}).strict()

/** The Settings seam face this handler needs (injectable for contract tests). */
export interface CssSettingsSeam {
  describe: SettingsProvider['describe']
  replace: SettingsProvider['replace']
}

/** Read the namespace's resolved view from the settings seam. */
function viewOf(seam: CssSettingsSeam): CssSettingsView | undefined {
  const descriptor = seam.describe({ redactSecrets: true }).find(candidate => String(candidate.ns) === CUSTOM_CSS_NS)
  if (descriptor === undefined) return undefined
  return { value: descriptor.value as CssSettingsValue, revision: descriptor.revision }
}

/** Build the pure endpoint dispatcher independently of Cordis for contract tests. */
export function createCssRpcHandler(seam: CssSettingsSeam, write: boolean): ConnectionRpcHandler {
  return async (endpoint, payload) => {
    try {
      if (!write) {
        // Read channel: only 'get' exists.
        if (endpoint !== 'get' || !emptyPayloadSchema.safeParse(payload).success) {
          return badRequest(`unknown or malformed read endpoint: ${JSON.stringify(endpoint)}`)
        }
        const view = viewOf(seam)
        if (view === undefined) return internalError('settings namespace is not registered')
        return success(view)
      }
      // Write channel: only 'save' exists; the trusted-host fence admits
      // local and remote authorities alike (both channels share the policy).
      if (endpoint !== 'save') {
        return badRequest(`unknown write endpoint: ${JSON.stringify(endpoint)}`)
      }
      const request = savePayloadSchema.safeParse(payload)
      if (!request.success) return badRequest(`save payload is invalid (value must be {enabled,css}, css <= ${CSS_MAX_LENGTH} characters)`)
      return await saveView(seam, request.data)
    } catch (error) {
      return internalError(error)
    }
  }
}

/** Apply one revision-checked save and acknowledge with the fresh view. */
async function saveView(seam: CssSettingsSeam, request: CssSaveRequest): Promise<RpcResult> {
  try {
    await seam.replace(settingsNamespace(CUSTOM_CSS_NS), request.value, request.expectedRevision)
  } catch (error) {
    // A stale writer is its own outcome, not a malformed request: the client
    // must re-read and re-apply rather than treat the write as invalid.
    if (error instanceof SettingsConflictError) {
      return {
        ok: false,
        error: {
          code: 'settings-conflict',
          message: error.message,
          details: { ns: CUSTOM_CSS_NS, expected: error.expected, actual: error.actual },
        },
      }
    }
    return {
      ok: false,
      error: {
        code: 'settings-rejected',
        message: error instanceof Error ? error.message : String(error),
        details: { ns: CUSTOM_CSS_NS },
      },
    }
  }
  const view = viewOf(seam)
  if (view === undefined) {
    return { ok: false, error: { code: 'internal', message: 'settings namespace vanished after save', details: {} } }
  }
  return success(view)
}

/**
 * Register both channels on the host Connection service. Each `rpc.handle`
 * mounts its route through its own cordis effect, so fiber teardown removes
 * the routes; no extra lifecycle bookkeeping is needed here.
 */
export function registerCssRpc(ctx: Context, seam: CssSettingsSeam): void {
  const connection = ctx.connection as HostConnectionHandle
  connection.rpc.handle(CUSTOM_CSS_READ_CHANNEL, createCssRpcHandler(seam, false), { authority: 'trusted-host' })
  connection.rpc.handle(CUSTOM_CSS_WRITE_CHANNEL, createCssRpcHandler(seam, true), { authority: 'trusted-host' })
}

function success(value: unknown): RpcResult {
  return { ok: true, value } as RpcResult
}

function badRequest(message: string): RpcResult {
  return { ok: false, error: { code: 'bad-request', message, details: { issues: [] } } } as RpcResult
}

function internalError(error: unknown): RpcResult {
  return {
    ok: false,
    error: { code: 'internal', message: error instanceof Error ? error.message : String(error), details: {} },
  } as RpcResult
}
