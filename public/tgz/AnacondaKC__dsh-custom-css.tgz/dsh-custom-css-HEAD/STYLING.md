# DSH WebUI 样式接口对应表（CSS 定制指南）

> 用途：写自定义 CSS 时知道"改哪个 token / 类名 → 影响哪个界面元素"。
> 依据：DSH source `staging-20260809T055543Z`，`packages/client/ui-*/src/**/*.module.css` 静态消费扫描 + 浏览器实测。
> 接口三层：token 覆盖（最稳）＞ 主题注册 API（ctx.theme.register）＞ 任意 CSS 注入（dsh-custom-css）。
>
> 完整参考实现：[`examples/dsh-aurora-nexus.css`](examples/dsh-aurora-nexus.css)；它覆盖全部官方语义 token、静态色阶、排版、动效、阴影、滚动条和 Shiki 接口，并提供亮/暗主题与无障碍分支。

## 1. 组件名 → UI 区域对照（消费表里的英文名）

| 组件 | 界面区域 |
|---|---|
| `AppFrame` | 主框架布局（三列容器，背景 = `--dsw-alias-bg-base`） |
| `SidebarRoot` | 左侧栏（背景 = `--dsw-specific-sidebar-fill`） |
| `ConversationRoot` / `ChatView` | 会话/聊天区 |
| `MessageItem` | 消息气泡（背景 = `--dsw-specific-bubble`） |
| `InputBar` | 底部输入栏（= `--dsw-specific-input-major`） |
| `Input` | 输入框（焦点描边 = brand-primary） |
| `Button` | 按钮（primary 变体 = `--dsw-alias-button-primary-fill`） |
| `MarkdownText` / `CodeBlock` | Markdown 正文 / 代码块 |
| `Modal` / `Menu` / `Tooltip` / `Pill` / `StateDot` | 弹窗 / 菜单 / 提示 / 标签 / 状态点 |
| `SettingsRoot` | 设置面板 |
| `HeroShell` | 空状态首页 |
| `GoalBar` / `TodoPanel` / `QueueDock` | 目标栏 / 任务面板 / 队列坞 |
| `TrajectoryTable` / `TrajectoryTimeline` | 轨迹视图（表/时间线） |
| `JsonBlock` / `JsonTree` / `TerminalBlock` / `DiffBlock` / `SearchBlock` / `WebBlock` | JSON / 终端 / diff / 搜索 / 网页快照 内容块 |
| `ModelSelect` / `WorkspaceBrowser` / `WorkspacePicker` | 模型选择 / 工作区浏览 / 工作区选择 |
| `ApprovalPanel` / `PlanReviewPanel` / `QuestionComposer` | 审批面板 / 计划审查 / 提问输入 |
| `ReasoningRow` / `ToolRow` / `SkillRow` | 推理行 / 工具行 / 技能行 |
| `ConnectionBanner` | 连接状态横幅 |
| `AppearanceRow` | 设置→通用→外观（主题切换行） |

## 2. 核心 token → 消费组件（"改它 = 改哪里"）

| Token | 影响 | 消费组件 |
|---|---|---|
| `--dsw-alias-bg-base` | **全站主背景** | AppFrame、MarkdownText、CodeBlock、ConversationRoot、DetailsPanel、GoalBar、QueueDock、ToolRow 等 12 处 |
| `--dsw-alias-bg-layer-1` | 次级面板背景（输入框、JSON 树、轨迹单元） | Input、JsonTree、ModelsSection、OnboardingSurface、Trajectory* 等 |
| `--dsw-alias-bg-layer-2` | 弹窗/设置面板/标签背景 | Modal、Pill、SettingsRoot、Trajectory* |
| `--dsw-alias-label-primary` | **主文字色**（几乎所有组件） | 60+ 组件 |
| `--dsw-alias-label-secondary` | 次级文字 | 45+ 组件 |
| `--dsw-alias-label-tertiary` | 弱化文字/占位 | 45+ 组件 |
| `--dsw-alias-border-l1/l2/l3/l4` | 边框层级（l1 最淡） | AppFrame 侧栏分隔、Input、Menu、Rows 等 30+ 组件 |
| `--dsw-alias-brand-primary` | **品牌色：仅输入框焦点描边 + 模型页**（不作用于按钮！） | Input、ModelsSection |
| `--dsw-alias-button-primary-fill` | **主按钮背景** | Button(primary)、ModelsSection、RiskConfirmation |
| `--dsw-alias-button-primary-hover` | 主按钮悬停 | Button、ModelsSection |
| `--dsw-alias-button-tool-bar-fill` | 工具栏图标按钮背景 | Button |
| `--dsw-alias-interactive-bg-hover/active` | 列表项/菜单悬停、选中背景 | 30+ 组件 |
| `--dsw-specific-sidebar-fill` | **侧栏背景** | AppFrame、SidebarRoot、TrajectoryTable、WorkspaceBrowser |
| `--dsw-specific-bubble` | 聊天气泡背景 | MessageItem |
| `--dsw-specific-input-major` | 输入栏背景 | InputBar、ApprovalPanel、PlanReviewPanel、QuestionComposer |
| `--dsw-alias-markdown-inline-code` | 行内代码色 | MarkdownText |
| `--dsw-alias-markdown-code-block` | 代码块背景 | CodeBlock 等 15 处内容块 |
| `--dsw-alias-state-error/success/warn-primary` | 状态色（错误/成功/警告） | 30+ 组件（横幅、状态点、diff） |
| `--dsw-alias-tooltip-bg` | 提示浮层背景 | Tooltip |
| `--dsw-alias-scrollbar-bg-l1` | 滚动条 | （语义层预留） |
| `--dsw-shadow-lv1/2/3` | 阴影层级 | 组件（非 module.css 消费） |

> 完整 alias/specific 清单见 `design-platform.css`（bg-*/label-*/border-*/button-*/interactive-*/markdown-*/state-*/scrollbar-*/toast/tooltip + specific-*）。
> 字体族 `--dsw-font-family`（正文）/ `--ds-font-family-code`（代码）；字号阶梯 `--dsw-font-{xxs,s,base,m,l,xl}-*`；动效 `--ds-ease-in-out`、`--ds-transition-duration(-fast/slow)`。

## 3. 运行时探测脚本（DevTools 控制台粘贴）

解决"这个元素到底用了哪些 token"——反向查询：

```js
(() => {
  const rules = [];
  for (const sheet of document.styleSheets) {
    try { for (const r of sheet.cssRules) if (r.selectorText) rules.push(r); } catch {}
  }
  const tokenOf = (css) => [...css.matchAll(/var\((--dsw-(?:alias|specific)-[a-z0-9-]+)\)/g)].map(m => m[1]);
  window.__cssTokens = {
    // 用法1：window.__cssTokens.byToken() —— 每个 token 命中哪些规则/多少元素
    byToken() {
      const map = {};
      for (const r of rules) {
        const toks = tokenOf(r.cssText);
        if (!toks.length) continue;
        let count = 0;
        try { count = document.querySelectorAll(r.selectorText).length; } catch {}
        for (const t of toks) (map[t] ??= []).push([r.selectorText, count]);
      }
      return map;
    },
    // 用法2：window.__cssTokens.forElement(某个元素) —— 该元素用了哪些 token
    forElement(el) {
      const out = new Map();
      for (const r of rules) {
        try { if (!el.matches(r.selectorText)) continue; } catch { continue; }
        for (const t of tokenOf(r.cssText)) out.set(t, r.selectorText);
      }
      return Object.fromEntries(out);
    },
  };
  return '已安装：window.__cssTokens.byToken() / .forElement(el)';
})()
```

用法示例：
```js
// 查"发送按钮"用了什么 token
window.__cssTokens.forElement(document.querySelector('[class*="sendButton"]'))
// 查哪个 token 影响侧栏
window.__cssTokens.byToken()['--dsw-specific-sidebar-fill']
```

## 4. 实测踩坑记录（本插件开发过程）

1. **brand-primary ≠ 按钮色**：按钮只消费 `button-primary-fill`；改 brand 只影响输入框焦点描边和模型页。
2. **暗色覆盖必须成对写**：官方 token 定义在 `body`（亮）与 `body[data-ds-dark-theme]`（暗，特异性更高）；只写 `body{...}` 在暗色下被压过。
3. **body 背景被布局容器盖住**：`body{background}` 看不到——必须改 `--dsw-alias-bg-base`（AppFrame 消费）或 `[class$="_frame"]`。
4. **哈希类名两种格式并存**：`ixtILa_primaryButton`（hash 前）与 `_primary_kz6gm_38`（hash 后）——后缀选择器不可靠，类名层只能 `[class*="..."]` 包含匹配 + 实测。
5. **当前视图没有消费方**：token 覆盖生效 ≠ 界面有变化——先确认目标界面有对应组件（如 primary 按钮只在部分界面出现）。
6. **侧栏背景专用 token**：`--dsw-specific-sidebar-fill`，不是 bg-layer。
