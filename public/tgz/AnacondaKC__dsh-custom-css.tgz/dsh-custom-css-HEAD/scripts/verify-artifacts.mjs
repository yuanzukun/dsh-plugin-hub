import { existsSync, readFileSync } from 'node:fs'

const required = [
  'lib/index.js',
  'lib/client.js',
  'lib/types/index.d.ts',
  'lib/types/client/index.d.ts',
]

const missing = required.filter(file => !existsSync(file))
if (missing.length > 0) {
  throw new Error(`build did not produce required artifacts: ${missing.join(', ')}`)
}

const staleImports = ['lib/index.js', 'lib/client.js']
  .filter(file => /from\s+['"][^'"]+\.ts['"]/.test(readFileSync(file, 'utf8')))
if (staleImports.length > 0) {
  throw new Error(`emitted JavaScript still imports TypeScript sources: ${staleImports.join(', ')}`)
}
