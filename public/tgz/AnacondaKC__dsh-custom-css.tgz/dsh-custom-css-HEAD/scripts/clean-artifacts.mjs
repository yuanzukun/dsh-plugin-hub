import { rmSync } from 'node:fs'

// tsc emits the host half first and tsdown deliberately keeps that output.
// Clean before tsc, not inside tsdown, so removed source modules cannot leak
// into a subsequently packed lib/ directory.
rmSync('lib', { recursive: true, force: true })
