﻿<#
  奶蛙版改动保险栓 —— 一键撤销上一步

  给「我不能确定风险、但你先做了」的操作兜底。
  用法（建议做成桌面快捷方式）：
    dsh-guard.ps1 undo            # 撤销最近一次未撤销的操作
    dsh-guard.ps1 undo -Times 2   # 连撤两步
    dsh-guard.ps1 list            # 看最近 10 条记录
    dsh-guard.ps1 begin -Note "改 cordis.patch.yml" -Paths "C:\...\cordis.patch.yml"
#>
param(
  [Parameter(Position = 0, Mandatory = $true)]
  [ValidateSet('begin', 'undo', 'list', 'status')]
  [string]$Command,

  [string]$Note = '',
  [string[]]$Paths = @(),
  [string]$Id = '',
  [int]$Times = 1
)

$ErrorActionPreference = 'Stop'
$Root    = Join-Path $env:USERPROFILE '.dsh\checkpoints'
$Journal = Join-Path $Root 'journal.jsonl'
if (-not (Test-Path $Root)) { New-Item -ItemType Directory -Path $Root -Force | Out-Null }

function Read-Journal {
  if (-not (Test-Path $Journal)) { return @() }
  $lines = Get-Content $Journal -Encoding UTF8 | Where-Object { $_.Trim() -ne '' }
  $out = @()
  foreach ($l in $lines) { try { $out += ($l | ConvertFrom-Json) } catch { } }
  return $out
}

function Write-Journal([object[]]$Entries) {
  $tmp = "$Journal.tmp"
  $sb = New-Object System.Text.StringBuilder
  foreach ($e in $Entries) {
    $json = $e | ConvertTo-Json -Compress -Depth 8
    [void]$sb.AppendLine($json)
  }
  [IO.File]::WriteAllText($tmp, $sb.ToString(), (New-Object System.Text.UTF8Encoding($false)))
  Move-Item $tmp $Journal -Force
}

function Do-Begin {
  $stamp = Get-Date -Format 'yyyyMMdd-HHmmss-fff'
  $dir = Join-Path $Root $stamp
  $filesDir = Join-Path $dir 'files'
  New-Item -ItemType Directory -Path $filesDir -Force | Out-Null

  $items = @()
  $i = 0
  $flattened = @(); foreach ($one in $Paths) { foreach ($part in ($one -split '[;,]')) { if ($one -ne $null -and $part.Trim() -ne '') { $flattened += $part.Trim() } } }
  foreach ($p in $flattened) {
    if ([string]::IsNullOrWhiteSpace($p)) { continue }
    $full = [IO.Path]::GetFullPath($p)
    $i++
    if (Test-Path -LiteralPath $full -PathType Leaf) {
      $name = "f$i.bin"
      Copy-Item -LiteralPath $full -Destination (Join-Path $filesDir $name) -Force
      $items += [pscustomobject]@{ path = $full; existed = $true; backup = $name }
    }
    elseif (Test-Path -LiteralPath $full -PathType Container) {
      # 目录：整棵复制（体积可能大，仅用于小配置目录）
      $name = "d$i"
      Copy-Item -LiteralPath $full -Destination (Join-Path $filesDir $name) -Recurse -Force
      $items += [pscustomobject]@{ path = $full; existed = $true; backup = $name; isDir = $true }
    }
    else {
      $items += [pscustomobject]@{ path = $full; existed = $false; backup = $null }
    }
  }

  $entry = [pscustomobject]@{
    id     = $stamp
    time   = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
    note   = $Note
    undone = $false
    items  = $items
  }
  $all = @(Read-Journal) + $entry
  Write-Journal $all
  Write-Host "已记录检查点 $stamp —— $Note"
  foreach ($it in $items) {
    $state = if ($it.existed) { '已备份' } else { '原本不存在（撤销将删除）' }
    Write-Host ("  {0}  [{1}]" -f $it.path, $state)
  }
  return $stamp
}

function Restore-Entry($e) {
  foreach ($it in $e.items) {
    if ($it.existed) {
      $bak = Join-Path (Join-Path (Join-Path $Root $e.id) 'files') $it.backup
      if (-not (Test-Path -LiteralPath $bak)) { Write-Warning "缺少备份：$bak"; continue }
      $parent = Split-Path -Parent $it.path
      if ($parent -and -not (Test-Path -LiteralPath $parent)) { New-Item -ItemType Directory -Path $parent -Force | Out-Null }
      if (Test-Path -LiteralPath $it.path -PathType Container) { Remove-Item -LiteralPath $it.path -Recurse -Force }
      Copy-Item -LiteralPath $bak -Destination $it.path -Recurse -Force
      Write-Host "  还原 $($it.path)"
    }
    else {
      if (Test-Path -LiteralPath $it.path) {
        Remove-Item -LiteralPath $it.path -Recurse -Force
        Write-Host "  删除 $($it.path)（原本不存在）"
      }
    }
  }
}

function Do-Undo {
  $all = @(Read-Journal)
  if ($all.Count -eq 0) { Write-Host '没有可撤销的记录。'; return }

  $targets = @()
  if ($Id -ne '') {
    $targets = @($all | Where-Object { $_.id -eq $Id })
    if ($targets.Count -eq 0) { Write-Host "找不到记录 $Id"; return }
  }
  else {
    $todo = @($all | Where-Object { -not $_.undone })
    if ($todo.Count -eq 0) { Write-Host '没有可撤销的记录（都撤过了）。'; return }
    $n = [Math]::Min($Times, $todo.Count)
    $targets = @($todo[($todo.Count - $n)..($todo.Count - 1)])
  }

  foreach ($e in $targets) {
    Write-Host "撤销 $($e.id)  $($e.time)  $($e.note)"
    Restore-Entry $e
    $e.undone = $true
  }
  Write-Journal $all
  Write-Host '完成。'
}

function Do-List {
  $all = @(Read-Journal)
  if ($all.Count -eq 0) { Write-Host '还没有任何检查点。'; return }
  $all | Select-Object -Last 10 | ForEach-Object {
    $mark = if ($_.undone) { '已撤销' } else { '可撤销' }
    $n = @($_.items).Count
    Write-Host ("{0}  [{1}]  {2}  ({3} 个文件)  {4}" -f $_.id, $mark, $_.time, $n, $_.note)
    foreach ($it in $_.items) { Write-Host ("      - {0}" -f $it.path) }
  }
}

switch ($Command) {
  'begin'  { [void](Do-Begin) }
  'undo'   { Do-Undo }
  'list'   { Do-List }
  'status' { Write-Host ("检查点目录：{0}" -f $Root); Write-Host ("记录条数：{0}" -f @(Read-Journal).Count) }
}