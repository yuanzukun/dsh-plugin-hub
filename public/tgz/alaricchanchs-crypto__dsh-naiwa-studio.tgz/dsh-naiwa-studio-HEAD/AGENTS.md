
## 改动保险栓（一键撤销）

仓库外的改动（profile、cordis.patch.yml、别的插件的 lib、node_modules 下的文件、任何删除/移动）
在执行前**必须**先登记：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File scripts\dsh-guard.ps1 
  begin -Note "改 cordis.patch.yml 之前" -Paths "C:\Users\...\cordis.patch.yml"
```

多个路径用分号连：`-Paths "a;b;c"`。文件不存在也能登记（撤销时会删掉它）。

用户侧的固定入口（桌面两个 .cmd）：

- **撤销上一步.cmd** —— 撤销最近一次未撤销的改动
- **改动记录.cmd** —— 看最近 10 条记录与状态

记录存放在 `~/.dsh/checkpoints/`：每条一个目录（`files/` 里是原文件副本）+ `journal.jsonl`。
撤销就是把副本复制回去、把原先不存在的文件删掉，不依赖 git、不重启 DSH。

不适用：纯运行时行为（往别人页面插 DOM 之类）。那类只能靠「隔离环境先验证」。