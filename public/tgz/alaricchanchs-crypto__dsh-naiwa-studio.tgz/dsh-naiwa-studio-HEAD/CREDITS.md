# 致谢与来源

> 代码均为 MIT，许可证全文见 [`docs/third-party/`](./docs/third-party/)；素材授权状态见 [THIRD-PARTY-NOTICES.md](./THIRD-PARTY-NOTICES.md)。

## 代码

| 项目 | 用途 | 许可 |
|---|---|---|
| [dsh-startup-screen](https://github.com/6shenhonghong9/dsh-startup-screen) | 启动动画架构（tapIndex 注入、独立 splash、无白闪） | 见原项目 |
| [dsh-wallpaper-engine](https://github.com/elysia395/dsh-wallpaper-engine) | 壁纸库、玻璃层、配色 | 见原项目 |
| [dsh-plugin-naiwa-theme](https://github.com/seaison/dsh-plugin-naiwa-theme) | 灵感池卡片样式与文案、发送按钮 | 见原项目 |
| [dsh-naiwa](https://github.com/weikangzeng07-ops/dsh-naiwa) | 桌宠引擎（动画/物理/拖拽） | 见原项目 |
| [dsh-meme](https://github.com/yyh-001/dsh-meme) | 表情包系统 | 见原项目 |
| [dsh-skin-market](https://github.com/kingOfSoySauce/dsh-skin-market) | 皮肤市场 | 见原项目 |
| [dsh-memory-evolve](https://github.com/csyangwen/dsh-memory-evolve) | 长期记忆 | 见原项目 |

## 素材

- 启动动画视频：Minimax H3 生成
- 机械语音：edge-tts（Microsoft Azure TTS）合成后二次处理
- 音效与铺底：本项目脚本现场合成
- 奶蛙形象：网友二创作品，仅作主题展示，如权利人提出异议会立即移除
- 壁纸示例：使用者自行提供，不在仓库内

## 参考但未使用代码

- [dsh-plugin-wallpaper-engine-Yun](https://github.com/sdfsd85fds74f9d8/dsh-plugin-wallpaper-engine-Yun)
- [dsh-whale-wallpaper-skin](https://github.com/fishcg/dsh-whale-wallpaper-skin)

## 音效素材

- ssets/startup/sfx-tick.mp3、ssets/startup/sfx-ticks-run.mp3
  - 来源：[6shenhonghong9/dsh-startup-screen](https://github.com/6shenhonghong9/dsh-startup-screen)（lib/assets/）
  - 用途：启动动画的齿轮/计时音效
  - 说明：以上为界面音效，原仓库随插件分发；如权利人提出异议，将立即替换为自合成音轨。