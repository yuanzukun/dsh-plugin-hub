/*
 * Copyright (c) 2026 Huawei Device Co., Ltd.
 * SPDX-License-Identifier: MIT
 */
import { defineConfig } from 'tsup';
import fs from 'fs';

const pkg = JSON.parse(fs.readFileSync('./package.json', 'utf8'));

export default defineConfig({
  entry: [
    'src/cli.ts',
    'src/dsh-plugin.ts',
    'src/internal/doc-init-background.ts',
    'src/internal/telemetry-upload-background.ts',
  ],
  format: ['esm'],
  platform: 'node',
  target: 'node22',
  clean: true,
  dts: false,
  shims: true,
  minify: true,
  splitting: false,
  external: [
    'jieba-wasm',
    '@sqlite.org/sqlite-wasm',
    'yauzl',
    '@deepseek-ai/cordis',
    '@deepseek-ai/dsh-tools',
  ],
  env: {
    npm_package_version: pkg.version,
    npm_package_name: pkg.name,
    npm_config_tag: process.env.npm_config_tag || 'latest',
  },
});
