/*
 * Copyright (c) 2026 Huawei Device Co., Ltd.
 * SPDX-License-Identifier: MIT
 */
import { Command, InvalidArgumentError } from 'commander';
import { ToolProvider } from '../toolchain/index.js';
import { HilogAdapter } from '../utils/hilog-adapter.js';
import { CommonUtils } from '../utils/common-utils.js';
import { cyan, red } from 'colorette';
import ora from 'ora';
import { debugLog } from '../utils/logger.js';
import {
  telemetry,
  EventType,
  type CommandExecuted,
  type TrackMeasurement,
  TraceError,
} from '../trace/index.js';

interface LogOptions {
  device?: string;
  crash?: boolean;
  level?: string;
  bundleName?: string;
  keyword?: string;
  follow?: boolean;
  tail?: number;
  from?: number;
  to?: number;
}

interface LogTraceEvent extends CommandExecuted {
  logType: 'common' | 'crash';
  level: string;
  bundleName: string;
}

function buildLogArgs(options: LogOptions): string[] {
  return [
    'log',
    ...(options.device ? ['--device'] : []),
    ...(options.crash ? ['--crash'] : []),
    ...(options.level ? ['--level'] : []),
    ...(options.bundleName ? ['--bundle-name'] : []),
    ...(options.keyword ? ['--keyword'] : []),
    ...(options.tail !== undefined ? ['--tail'] : []),
    ...(options.from !== undefined ? ['--from'] : []),
    ...(options.to !== undefined ? ['--to'] : []),
    ...(options.follow ? ['--follow'] : []),
  ];
}

function buildLogEvent(options: LogOptions): LogTraceEvent {
  return {
    event: EventType.CommandExecuted,
    args: buildLogArgs(options),
    logType: options.crash ? 'crash' : 'common',
    level: options.level ?? 'ALL',
    bundleName: options.bundleName ?? 'ALL',
  };
}

function resolveLogErrorCode(error: unknown): string {
  if (error instanceof TraceError) {
    return error.traceMessage;
  }
  if (error instanceof Error) {
    return (error as NodeJS.ErrnoException).code ?? error.name;
  }
  return 'UnknownError';
}

async function withLogTrace(
  event: LogTraceEvent,
  action: () => Promise<void>
): Promise<void> {
  const start = Date.now();
  let success = true;
  let errorCode: string | null = null;
  try {
    await action();
  } catch (error) {
    success = false;
    errorCode = resolveLogErrorCode(error);
    console.error(red((error as Error).message));
    process.exitCode = 1;
  } finally {
    const measurement: TrackMeasurement = {
      duration_ms: Date.now() - start,
      success,
      error_code: errorCode,
    };
    await telemetry.track(event, measurement).catch(() => {});
  }
}

function parsePositiveInt(value: string): number {
  try {
    return CommonUtils.parsePositiveInteger(value, 'tail');
  } catch {
    throw new InvalidArgumentError('`tail` must be a positive integer.');
  }
}

function parseDuration(value: string, fieldName: string): number {
  try {
    return CommonUtils.parseDurationToSeconds(value, fieldName);
  } catch {
    throw new InvalidArgumentError(
      `${fieldName} must be a valid duration string (e.g.,30s, 5m or 2.5m).Supported units: s and m.when specified in seconds(with \`s\` or as a raw number), the value must be an integer.`
    );
  }
}

function parseHilogLevel(value: string): string {
  try {
    CommonUtils.assertHilogLevel(value);
    return value;
  } catch {
    throw new InvalidArgumentError('`level` must be one of: D, I, W, E, F.');
  }
}

function parseBundleName(value: string): string {
  try {
    CommonUtils.assertBundleNameStrict(value);
    return value;
  } catch (error) {
    throw new InvalidArgumentError((error as Error).message);
  }
}

function validateLogTimeRange(options: LogOptions): void {
  if (options.to && options.follow) {
    throw new Error('`--to` cannot be used with `--follow`.');
  }
}

async function fetchLogsByOptions(
  service: HilogAdapter,
  deviceId: string,
  options: LogOptions,
  fromSeconds?: number,
  toSeconds?: number
): Promise<string> {
  return options.crash
    ? await service.getCrashLog(deviceId, options.bundleName)
    : await service.getHilog(deviceId, {
        level: options.level,
        bundleName: options.bundleName,
        keyword: options.keyword,
        isFollow: options.follow ? true : false,
        tail: options.tail,
        fromSeconds,
        toSeconds,
      });
}

function postProcessCrashLogs(
  logs: string,
  options: LogOptions,
  fromSeconds?: number,
  toSeconds?: number
): string {
  const windowFiltered = CommonUtils.filterLogsByRelativeWindow(
    logs,
    fromSeconds,
    toSeconds
  );
  if (!options.tail) {
    return windowFiltered;
  }
  return CommonUtils.getLastLines(windowFiltered, options.tail);
}

const logCommand = new Command('log')
  .description('Obtain device application logs')
  .configureOutput({
    outputError: (str, write) => write(red(str)),
  })
  .option('--device <device>', 'Target device (name or serial)')
  .option('--crash', 'Only obtain crash logs')
  .option('--level <level>', 'Log level filter: D, I, W, E, F', parseHilogLevel)
  .option(
    '--bundle-name <bundle-name>',
    'Filter by application bundle name',
    parseBundleName
  )
  .option('--keyword <keyword>', 'Keyword filter')
  .option('--tail <num>', 'Show only the latest N log lines', parsePositiveInt)
  .option(
    '--from <start>',
    'Start offset from now, e.g. 30s, 5m, 2.5m, or 120',
    (value: string) => parseDuration(value, 'from')
  )
  .option(
    '--to <end>',
    'End offset from now, e.g. 30s, 5m, 2.5m, or 120',
    (value: string) => parseDuration(value, 'to')
  )
  .option('--follow', 'Follow the log stream in real-time.')
  .action(async (options: LogOptions) => {
    await withLogTrace(buildLogEvent(options), () => handleLogCommand(options));
  });

async function handleLogCommand(options: LogOptions): Promise<void> {
  const spinner = ora({
    text: 'Preparing log request…',
    color: 'cyan',
  });
  const stopAndClearSpinner = () => {
    spinner.stop();
    spinner.clear();
  };
  spinner.start();
  try {
    validateLogTimeRange(options);
    const fromSeconds = options.from;
    const toSeconds = options.to;

    const toolProvider = await ToolProvider.new();
    const service = new HilogAdapter(toolProvider);

    const deviceId = await service.selectDevice(options.device);
    if (!deviceId) {
      throw new TraceError(
        'No active devices found.',
        'No active devices found.'
      );
    }

    debugLog(cyan(`deviceId: ${deviceId}`));
    debugLog(cyan(`type: ${options.crash ? 'Crash logs' : 'Common logs'}`));
    debugLog(cyan('Obtaining logs ...'));

    spinner.text = 'Fetching logs…';
    if (options.follow) {
      stopAndClearSpinner();
    }

    let logs = await fetchLogsByOptions(
      service,
      deviceId,
      options,
      fromSeconds,
      toSeconds
    );
    stopAndClearSpinner();

    if (options.crash && logs) {
      logs = postProcessCrashLogs(logs, options, fromSeconds, toSeconds);
    }

    if (logs) {
      console.log(logs);
    }
  } finally {
    stopAndClearSpinner();
  }
}

export default logCommand;
