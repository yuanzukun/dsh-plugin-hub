/*
 * Copyright (c) 2026 Huawei Device Co., Ltd.
 * SPDX-License-Identifier: MIT
 */
import { spawn } from 'child_process';
import { fileURLToPath } from 'url';
import path from 'path';
import type { Context } from '@deepseek-ai/cordis';
import { defineTool } from '@deepseek-ai/dsh-tools';
import { debugLog } from './utils/logger.js';

export const name = 'deveco-cli-dsh-plugin';
export const inject = ['tools'];

const COMMANDS = [
  'auth',
  'build',
  'check',
  'create',
  'device',
  'docs',
  'emulator',
  'help',
  'init',
  'log',
  'run',
  'serve',
  'signature',
  'skills',
  'ui',
  'update',
] as const;

type DevecoCommand = (typeof COMMANDS)[number];

interface SpawnResult {
  stdout: string;
  stderr: string;
  exitCode: number | null;
  signal: string | null;
}

interface DevecoCliOutput {
  commandLine: string;
  cwd: string;
  stdout: string;
  stderr: string;
  exitCode: number | null;
  signal: string | null;
}

const DEVECO_CLI_PARAMETERS = {
  command: {
    type: 'string',
    enum: COMMANDS,
    required: true,
    description: 'Top-level devecocli command to run.',
  },
  args: {
    type: 'array',
    items: { type: 'string' },
    description:
      'Additional command arguments, for example ["search", "List", "--format", "json"].',
  },
  cwd: {
    type: 'string',
    description:
      'Working directory for project commands. Omit to use the current Harness workspace.',
  },
} as const;

const DEVECO_CLI_OUTPUT = {
  schema: {
    type: 'object',
    additionalProperties: false,
    properties: {
      commandLine: { type: 'string', required: true },
      cwd: { type: 'string', required: true },
      stdout: { type: 'string', required: true },
      stderr: { type: 'string', required: true },
      exitCode: {
        oneOf: [{ type: 'integer' }, { type: 'null' }],
        required: true,
      },
      signal: {
        oneOf: [{ type: 'string' }, { type: 'null' }],
        required: true,
      },
    },
  },
  render: (_args: unknown, value: DevecoCliOutput) => {
    const status =
      value.exitCode === null
        ? `signal ${value.signal ?? 'unknown'}`
        : `exit ${value.exitCode}`;
    const output = [value.stdout, value.stderr].filter(Boolean).join('\n');
    return [
      {
        type: 'text' as const,
        text:
          `$ ${value.commandLine}\n` +
          `status: ${status}` +
          (output ? `\n\n${output}` : ''),
      },
    ];
  },
  presentationMeta: (_args: unknown, value: DevecoCliOutput) => ({
    output: [value.stdout, value.stderr].filter(Boolean).join('\n'),
    exitCode: value.exitCode,
    signal: value.signal,
  }),
} as const;

function getCliPath(): string {
  return path.join(path.dirname(fileURLToPath(import.meta.url)), 'cli.js');
}

function renderCommand(command: DevecoCommand, args: string[]): string {
  return ['devecocli', command, ...args].join(' ');
}

async function runDevecoCli(
  command: DevecoCommand,
  args: string[],
  cwd: string | undefined,
  execSignal: AbortSignal
): Promise<SpawnResult> {
  const cliPath = getCliPath();
  const nodeArgs = [cliPath, command, ...args];
  debugLog(() => `Executing: ${process.execPath} ${nodeArgs.join(' ')}`);

  return await new Promise<SpawnResult>((resolve, reject) => {
    const child = spawn(process.execPath, nodeArgs, {
      cwd,
      env: process.env,
      stdio: ['ignore', 'pipe', 'pipe'],
    });
    const stdoutChunks: string[] = [];
    const stderrChunks: string[] = [];

    const abort = (): void => {
      child.kill('SIGTERM');
    };
    execSignal.addEventListener('abort', abort, { once: true });
    if (execSignal.aborted) {
      abort();
    }

    child.stdout?.on('data', (chunk: Buffer | string) => {
      stdoutChunks.push(chunk.toString());
    });
    child.stderr?.on('data', (chunk: Buffer | string) => {
      stderrChunks.push(chunk.toString());
    });
    child.on('error', (error) => {
      execSignal.removeEventListener('abort', abort);
      reject(error);
    });
    child.on('close', (exitCode, signal) => {
      execSignal.removeEventListener('abort', abort);
      resolve({
        stdout: stdoutChunks.join(''),
        stderr: stderrChunks.join(''),
        exitCode,
        signal,
      });
    });
  });
}

const devecoCliTool = defineTool({
  name: 'deveco_cli',
  description:
    'Run DevEco CLI for HarmonyOS development. Use args as an argv array, not a shell string. Supports build, run, device, emulator, docs, ui, log, check, create, init, skills, auth, signature, serve, update, and help.',
  parameters: DEVECO_CLI_PARAMETERS,
  output: DEVECO_CLI_OUTPUT,
  async execute(args, exec) {
    const argv = args.args ?? [];
    const result = await runDevecoCli(
      args.command,
      argv,
      args.cwd,
      exec.signal
    );
    return {
      commandLine: renderCommand(args.command, argv),
      cwd: args.cwd ?? process.cwd(),
      stdout: result.stdout,
      stderr: result.stderr,
      exitCode: result.exitCode,
      signal: result.signal,
    };
  },
  presentCall(args) {
    return {
      card: 'terminal',
      title: renderCommand(args.command, args.args ?? []),
      description: 'Run DevEco CLI',
      cwd: args.cwd,
    };
  },
  presentResult(_args, result) {
    const meta =
      result.meta &&
      typeof result.meta === 'object' &&
      !Array.isArray(result.meta)
        ? result.meta
        : undefined;
    return {
      card: 'terminal',
      output:
        typeof meta?.output === 'string'
          ? meta.output
          : result.content
              .map((block) => (block.type === 'text' ? block.text : ''))
              .join('\n'),
      exitCode: typeof meta?.exitCode === 'number' ? meta.exitCode : undefined,
      signal: typeof meta?.signal === 'string' ? meta.signal : undefined,
    };
  },
});

export function apply(ctx: Context): void {
  ctx.tools.register(devecoCliTool);
}
