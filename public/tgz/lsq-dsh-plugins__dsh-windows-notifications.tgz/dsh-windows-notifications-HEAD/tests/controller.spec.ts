// @vitest-environment jsdom

import { describe, expect, it, vi } from 'vitest'
import type { ISessions, SessionListState, SessionSummary } from '@deepseek-ai/dsh-api-session-controller/client'
import type { SessionId } from '@deepseek-ai/dsh-session/types'
import type { SettingsScope } from '@deepseek-ai/dsh-client-ui-settings/client'
import type { HostObservable } from '@deepseek-ai/dsh-client-ui-slots'
import type { SessionPendingInteractionSnapshot } from '@deepseek-ai/dsh-client-ui-session/client'
import { DEFAULT_NOTIFICATION_SETTINGS, type NotificationSettings } from '../src/contracts.ts'
import type { BrowserNotifier } from '../src/client/browser-notifier.ts'
import { NotificationController } from '../src/client/controller.ts'
import { zh } from '../src/client/locales.ts'

const sid = (value: string): SessionId => value as SessionId

function row(options: Partial<SessionSummary> = {}): SessionSummary {
  return {
    id: sid('a'),
    displayTitle: '示例会话',
    running: false,
    blank: false,
    updatedAt: 1,
    projectionValues: { windowsNotificationTurnEnd: null },
    ...options,
  }
}

function list(summary: SessionSummary): SessionListState {
  return {
    ids: [summary.id],
    byId: { [summary.id]: summary } as Record<SessionId, SessionSummary>,
    current: summary.id,
    phase: 'ready',
    subagentsByParent: {},
    jobsBySession: {},
    currentAddress: undefined,
  }
}

function bench(settingsValue: NotificationSettings = { ...DEFAULT_NOTIFICATION_SETTINGS }) {
  let snapshot = list(row())
  let listener: (() => void) | undefined
  const open = vi.fn()
  const sessions = {
    list: {
      getSnapshot: () => snapshot,
      subscribe: (next: () => void) => { listener = next; return () => { listener = undefined } },
    },
    open,
  } as unknown as ISessions
  let pendingSnapshot: SessionPendingInteractionSnapshot = new Map()
  let pendingListener: (() => void) | undefined
  const pendingInteractions = {
    getSnapshot: (): SessionPendingInteractionSnapshot => pendingSnapshot,
    subscribe: (next: () => void) => { pendingListener = next; return () => { pendingListener = undefined } },
  } as unknown as HostObservable<SessionPendingInteractionSnapshot>
  const settings = {
    getSnapshot: () => ({
      status: 'ready' as const,
      value: settingsValue,
      base: undefined,
      user: undefined,
      revision: 1,
      writable: true,
      mode: 'host' as const,
    }),
    subscribe: vi.fn(),
    set: vi.fn(),
    unset: vi.fn(),
  } as unknown as SettingsScope<NotificationSettings>
  const browser = {
    permission: vi.fn(() => 'granted' as const),
    requestPermission: vi.fn(() => Promise.resolve('granted' as const)),
    primeSound: vi.fn(() => Promise.resolve()),
    show: vi.fn(() => true),
    playSound: vi.fn(() => Promise.resolve()),
  } as unknown as BrowserNotifier
  const showPageNotification = vi.fn()
  const info = vi.fn()
  const warn = vi.fn()
  const controller = new NotificationController({
    sessions,
    pendingInteractions,
    settings,
    browser,
    t: ((key: keyof typeof zh, params?: Record<string, unknown>) => {
      const text = zh[key]
      return params === undefined ? text : text.replace('{title}', String(params.title))
    }) as never,
    showPageNotification,
    onPermissionChange: vi.fn(),
    info,
    warn,
  })
  controller.start()
  return {
    browser,
    controller,
    info,
    open,
    showPageNotification,
    warn,
    publish: (next: SessionSummary) => {
      snapshot = list(next)
      const pendingKind = (next as { pendingInteraction?: string }).pendingInteraction
      pendingSnapshot = pendingKind !== undefined ? new Map([[next.id, { kind: pendingKind }]]) : new Map()
      listener?.()
      pendingListener?.()
    },
  }
}

describe('NotificationController', () => {
  it('uses a unique tag for every Windows test without waiting for audio', async () => {
    const b = bench()

    await b.controller.testNotification()
    await b.controller.testNotification()

    expect(b.browser.primeSound).not.toHaveBeenCalled()
    expect(b.browser.show).toHaveBeenCalledTimes(2)
    const first = vi.mocked(b.browser.show).mock.calls[0]?.[0]
    const second = vi.mocked(b.browser.show).mock.calls[1]?.[0]
    expect(first?.tag).toMatch(/^dsh-notification-test-/)
    expect(second?.tag).toMatch(/^dsh-notification-test-/)
    expect(first?.tag).not.toBe(second?.tag)
    expect(first?.replaceKey).toBe('windows-notification-test')
    expect(second?.replaceKey).toBe('windows-notification-test')
    first?.onShow?.()
    expect(b.info).toHaveBeenCalledWith('Windows notification test displayed')
  })

  it('reports a rejected Windows test through the in-app Toast and logs', async () => {
    const b = bench()
    vi.mocked(b.browser.show).mockReturnValue(false)

    await b.controller.testNotification()

    expect(b.showPageNotification).toHaveBeenCalledWith({
      title: 'Windows 通知发送失败，请检查浏览器和 Windows 通知设置。',
      kind: 'failure',
      replaceKey: 'windows-notification-test-feedback',
    })
    expect(b.warn).toHaveBeenCalledWith('Windows notification test failed', undefined)
  })

  it('routes the in-app notification test through the real Toast path', () => {
    const b = bench()

    b.controller.testPageNotification()

    expect(b.showPageNotification).toHaveBeenCalledWith({
      title: '通知测试成功',
      body: '页面内通知工作正常。',
      kind: 'success',
      replaceKey: 'page-notification-test',
    })
  })

  it('uses a Windows notification in the background and opens its session on click', () => {
    Object.defineProperty(document, 'visibilityState', { configurable: true, value: 'hidden' })
    const b = bench()
    b.publish(row({
      projectionValues: {
        windowsNotificationTurnEnd: { seq: 4, turn: 1, outcome: 'completed' },
      },
    }))

    expect(b.browser.show).toHaveBeenCalledOnce()
    expect(b.showPageNotification).not.toHaveBeenCalled()
    expect(b.browser.playSound).toHaveBeenCalledWith('success', 0.55)
    const request = vi.mocked(b.browser.show).mock.calls[0]?.[0]
    request?.onClick()
    expect(b.open).toHaveBeenCalledWith(sid('a'))
  })

  it('uses a DSH-style page card for a foreground question without duplicating the system alert', () => {
    Object.defineProperty(document, 'visibilityState', { configurable: true, value: 'visible' })
    vi.spyOn(document, 'hasFocus').mockReturnValue(true)
    const b = bench()
    b.publish(row({ pendingInteraction: 'question' }))

    expect(b.browser.show).not.toHaveBeenCalled()
    expect(b.showPageNotification).toHaveBeenCalledWith({
      title: '等待回答',
      body: '会话“示例会话”向你提出了问题。',
      kind: 'attention',
    })
  })

  it('honors event and subagent switches while still advancing the detector baseline', () => {
    const settings = {
      ...DEFAULT_NOTIFICATION_SETTINGS,
      notifyCompleted: false,
      notifySubagents: false,
    }
    const b = bench(settings)
    b.publish(row({
      origin: 'subagent',
      projectionValues: {
        windowsNotificationTurnEnd: { seq: 3, turn: 1, outcome: 'completed' },
      },
    }))
    expect(b.browser.show).not.toHaveBeenCalled()
    expect(b.showPageNotification).not.toHaveBeenCalled()
    expect(b.browser.playSound).not.toHaveBeenCalled()
  })
})
