// @vitest-environment jsdom

import { cleanup, fireEvent, render, screen } from '@testing-library/react'
import { afterEach, describe, expect, it, vi } from 'vitest'
import { DEFAULT_NOTIFICATION_SETTINGS } from '../src/contracts.ts'
import {
  NotificationSettingsSection,
  type NotificationSettingsSectionProps,
} from '../src/client/NotificationSettingsSection.tsx'
import { zh } from '../src/client/locales.ts'

vi.mock('@deepseek-ai/dsh-client-ui-primitives', async () => {
  const React = await import('react')
  return {
    Button: ({ children, variant: _variant, size: _size, ...props }: React.ButtonHTMLAttributes<HTMLButtonElement> & {
      variant?: string
      size?: string
    }) => React.createElement('button', props, children),
  }
})

afterEach(cleanup)

function props(overrides: Partial<NotificationSettingsSectionProps> = {}): NotificationSettingsSectionProps {
  return {
    useStore: selector => selector({
      settings: { ...DEFAULT_NOTIFICATION_SETTINGS },
      status: 'ready',
      writable: true,
      revision: 1,
      permission: 'default',
    }),
    t: (key, params) => {
      const value = zh[key]
      return params === undefined ? value : value.replace('{title}', String(params.title))
    },
    setSetting: vi.fn(),
    requestPermission: vi.fn(),
    testNotification: vi.fn(),
    testPageNotification: vi.fn(),
    testSound: vi.fn(),
    close: vi.fn(),
    useSessions: vi.fn() as never,
    useWorkspaces: vi.fn() as never,
    ...overrides,
  } as NotificationSettingsSectionProps
}

describe('NotificationSettingsSection', () => {
  it('renders the permission action and routes toggles and test buttons', () => {
    const setSetting = vi.fn()
    const requestPermission = vi.fn()
    const testNotification = vi.fn()
    const testPageNotification = vi.fn()
    const testSound = vi.fn()
    render(<NotificationSettingsSection {...props({
      setSetting,
      requestPermission,
      testNotification,
      testPageNotification,
      testSound,
    })} />)

    fireEvent.click(screen.getByRole('button', { name: '授权通知' }))
    fireEvent.click(screen.getByRole('switch', { name: '任务完成' }))
    fireEvent.click(screen.getByRole('button', { name: '测试 Windows 通知' }))
    fireEvent.click(screen.getByRole('button', { name: '测试页面通知' }))
    fireEvent.click(screen.getByRole('button', { name: '测试声音' }))

    expect(requestPermission).toHaveBeenCalledOnce()
    expect(setSetting).toHaveBeenCalledWith('notifyCompleted', false)
    expect(testNotification).toHaveBeenCalledOnce()
    expect(testPageNotification).toHaveBeenCalledOnce()
    expect(testSound).toHaveBeenCalledOnce()
  })

  it('disables subordinate controls when the master switch is off', () => {
    const off = props({
      useStore: selector => selector({
        settings: { ...DEFAULT_NOTIFICATION_SETTINGS, enabled: false },
        status: 'ready',
        writable: true,
        revision: 1,
        permission: 'granted',
      }),
    })
    render(<NotificationSettingsSection {...off} />)
    expect((screen.getByRole('switch', { name: '启用通知' }) as HTMLButtonElement).disabled).toBe(false)
    expect((screen.getByRole('switch', { name: 'Windows 系统通知' }) as HTMLButtonElement).disabled).toBe(true)
    expect((screen.getByRole('slider', { name: '音量' }) as HTMLInputElement).disabled).toBe(true)
  })
})
