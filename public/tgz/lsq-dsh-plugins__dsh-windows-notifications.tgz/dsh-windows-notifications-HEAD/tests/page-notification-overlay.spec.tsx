// @vitest-environment jsdom

import { act, cleanup, render, screen } from '@testing-library/react'
import type { Context as ClientContext } from '@deepseek-ai/cordis'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import {
  PAGE_NOTIFICATION_DURATION_MS,
  PageNotificationOverlay,
  type PageNotificationOverlayProps,
} from '../src/client/PageNotificationOverlay.tsx'
import { installPageNotificationStyles } from '../src/client/page-notification-styles.ts'
import type { PageNotificationQueueState } from '../src/client/stores.ts'

vi.mock('@deepseek-ai/dsh-client-ui-primitives', async () => {
  const React = await import('react')
  return {
    FishLogo: ({ size, className }: { size: number, className: string }) => React.createElement('span', {
      'data-testid': 'fish-logo',
      'data-size': size,
      className,
    }),
    StateDot: ({ state, size, className }: { state: string, size: number, className: string }) => React.createElement('span', {
      'data-testid': 'state-dot',
      'data-state': state,
      'data-size': size,
      className,
    }),
  }
})

beforeEach(() => { vi.useFakeTimers() })

afterEach(() => {
  cleanup()
  document.head.querySelectorAll('style[data-plugin-css]').forEach(tag => { tag.remove() })
  vi.useRealTimers()
})

function props(state: PageNotificationQueueState, dismiss = vi.fn()): PageNotificationOverlayProps {
  return {
    useStore: selector => selector(state),
    actions: { dismiss },
  } as unknown as PageNotificationOverlayProps
}

describe('PageNotificationOverlay', () => {
  it('renders the official DSH fish mark and a restrained status dot', () => {
    render(<PageNotificationOverlay {...props({
      current: {
        id: 1,
        title: '通知测试成功',
        body: '页面内通知工作正常。',
        kind: 'success',
      },
      queued: [],
    })} />)

    const card = screen.getByRole('status')
    expect(card.parentElement).toBe(document.body)
    expect(card.className).toBe('dsh-win-page-notification')
    expect(card.dataset.placement).toBe('top-center')
    expect(card.dataset.kind).toBe('success')
    expect(screen.getByText('通知测试成功')).toBeTruthy()
    expect(screen.getByText('页面内通知工作正常。')).toBeTruthy()
    expect(screen.getByTestId('fish-logo').dataset.size).toBe('30')
    expect(screen.getByTestId('state-dot').dataset.state).toBe('done')
  })

  it('uses assertive semantics for attention cards and dismisses after the fade', () => {
    const dismiss = vi.fn()
    render(<PageNotificationOverlay {...props({
      current: { id: 7, title: '等待回答', kind: 'attention' },
      queued: [],
    }, dismiss)} />)

    expect(screen.getByRole('alert')).toBeTruthy()
    expect(screen.getByTestId('fish-logo')).toBeTruthy()
    expect(screen.getByTestId('state-dot').dataset.state).toBe('warning')
    act(() => { vi.advanceTimersByTime(PAGE_NOTIFICATION_DURATION_MS - 1) })
    expect(dismiss).not.toHaveBeenCalled()
    act(() => { vi.advanceTimersByTime(1) })
    expect(dismiss).toHaveBeenCalledWith(7)
  })

  it('maps failure notifications to the native DSH error state', () => {
    render(<PageNotificationOverlay {...props({
      current: { id: 9, title: '任务执行失败', kind: 'failure' },
      queued: [],
    })} />)

    expect(screen.getByTestId('state-dot').dataset.state).toBe('error')
  })

  it('restarts the lifetime when an active test card is replaced', () => {
    const dismiss = vi.fn()
    const first = props({
      current: { id: 10, title: '第一次测试', kind: 'success', replaceKey: 'page-test' },
      queued: [],
    }, dismiss)
    const { rerender } = render(<PageNotificationOverlay {...first} />)
    act(() => { vi.advanceTimersByTime(3500) })

    rerender(<PageNotificationOverlay {...props({
      current: { id: 11, title: '第二次测试', kind: 'success', replaceKey: 'page-test' },
      queued: [],
    }, dismiss)} />)
    act(() => { vi.advanceTimersByTime(500) })
    expect(dismiss).not.toHaveBeenCalled()
    act(() => { vi.advanceTimersByTime(3500) })
    expect(dismiss).toHaveBeenCalledWith(11)
  })

  it('installs a compact elevated surface using recurring DSH geometry and tokens', () => {
    const effect = vi.fn((setup: () => void | (() => void)) => setup())
    installPageNotificationStyles({ effect } as unknown as ClientContext)

    const css = document.head.querySelector('style[data-plugin-css$="/page-notification"]')?.textContent
    expect(css).toContain('top: 20px')
    expect(css).toContain('left: 50%')
    expect(css).toContain('border-radius: 20px')
    expect(css).toContain('background: var(--dsw-alias-bg-layer-2)')
    expect(css).toContain('border: 1px solid var(--dsw-alias-border-l2-darkmode-thin)')
    expect(css).toContain('box-shadow: var(--dsw-shadow-lv3)')
    expect(css).toContain('color: var(--dsw-alias-label-primary)')
    expect(css).not.toContain('scale(')
    expect(css).not.toContain('--dsw-alias-button-contrast-fill')
  })
})
