import { readFileSync } from 'node:fs'
import { describe, expect, it } from 'vitest'

const PACKAGE_ID = '@lsq64737/dsh-windows-notifications'
const root = new URL('../', import.meta.url)

interface PublishableManifest {
  name: string
  private?: boolean
  publishConfig?: {
    access?: string
    registry?: string
  }
  repository?: {
    type?: string
    url?: string
  }
  dsh?: {
    bundle?: { patch?: string }
    client?: { platform?: string }
  }
}

function text(path: string): string {
  return readFileSync(new URL(path, root), 'utf8')
}

describe('npm publishing contract', () => {
  it('keeps the public package, DSH bundle, and browser module identities aligned', () => {
    const manifest = JSON.parse(text('package.json')) as PublishableManifest

    expect(manifest).toMatchObject({
      name: PACKAGE_ID,
      publishConfig: {
        access: 'public',
        registry: 'https://registry.npmjs.org/',
      },
      repository: {
        type: 'git',
        url: 'git+https://github.com/lsq-dsh-plugins/dsh-windows-notifications.git',
      },
      dsh: {
        bundle: { patch: './cordis.patch.yml' },
        client: { platform: 'web' },
      },
    })
    expect(manifest.private).not.toBe(true)
    expect(text('cordis.patch.yml')).toContain(`name: "${PACKAGE_ID}"`)
    expect(text('tsdown.config.ts')).toContain(`const PLUGIN_ID = '${PACKAGE_ID}'`)
  })

  it('keeps publishable documentation free of private machine references', () => {
    const documentation = [text('README.md'), text('README.zh.md')].join('\n')

    expect(documentation).not.toMatch(/\/(?:home|Users)\//)
    expect(documentation).not.toMatch(/[A-Za-z]:\\/)
    expect(documentation).not.toMatch(/\b(?:localhost|127\.0\.0\.1|192\.168\.\d{1,3}\.\d{1,3})\b/)
    expect(documentation).not.toContain('Local development')
    expect(documentation).not.toContain('本地开发')
  })
})
