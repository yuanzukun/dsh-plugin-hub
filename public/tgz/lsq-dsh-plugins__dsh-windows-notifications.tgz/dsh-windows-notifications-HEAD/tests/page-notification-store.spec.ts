import { describe, expect, it } from 'vitest'
import {
  createPageNotificationQueueState,
  dismissPageNotificationInQueue,
  showPageNotificationInQueue,
  type PageNotificationItem,
} from '../src/client/page-notification-queue.ts'

function item(id: number, replaceKey?: string): PageNotificationItem {
  return {
    id,
    title: `通知 ${id}`,
    kind: 'success',
    ...(replaceKey === undefined ? {} : { replaceKey }),
  }
}

describe('page notification queue', () => {
  it('replaces the active test card immediately instead of extending the queue', () => {
    const state = createPageNotificationQueueState()

    showPageNotificationInQueue(state, item(1, 'page-test'))
    showPageNotificationInQueue(state, item(2, 'page-test'))
    showPageNotificationInQueue(state, item(3, 'page-test'))

    expect(state).toEqual({
      current: item(3, 'page-test'),
      queued: [],
    })
  })

  it('replaces a queued test card while preserving real event notifications', () => {
    const state = createPageNotificationQueueState()

    showPageNotificationInQueue(state, item(1))
    showPageNotificationInQueue(state, item(2, 'page-test'))
    showPageNotificationInQueue(state, item(3))
    showPageNotificationInQueue(state, item(4, 'page-test'))

    expect(state).toEqual({
      current: item(1),
      queued: [item(3), item(4, 'page-test')],
    })
  })

  it('keeps distinct real notifications queued in arrival order', () => {
    const state = createPageNotificationQueueState()

    showPageNotificationInQueue(state, item(1))
    showPageNotificationInQueue(state, item(2))
    showPageNotificationInQueue(state, item(3))
    dismissPageNotificationInQueue(state, 1)

    expect(state).toEqual({
      current: item(2),
      queued: [item(3)],
    })
  })
})
