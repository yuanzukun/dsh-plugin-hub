import { Context } from '@deepseek-ai/cordis'
import SessionStore from '@deepseek-ai/dsh-session'
import SessionProjectionRegistry from '@deepseek-ai/dsh-session-projection'
import {
  SettingsProvider,
  type SettingsNamespace,
} from '@deepseek-ai/dsh-settings'
import { describe, expect, it } from 'vitest'
import {
  NOTIFICATION_SETTINGS_NAMESPACE,
  DEFAULT_NOTIFICATION_SETTINGS,
} from '../src/contracts.ts'
import { apply, inject } from '../src/index.ts'

class MemorySettings extends SettingsProvider {
  readonly writable = true
  protected load(): Promise<Record<string, unknown>> { return Promise.resolve({}) }
  protected persist(_ns: SettingsNamespace, _section: Record<string, unknown>): Promise<void> {
    return Promise.resolve()
  }
}

describe('Host plugin composition', () => {
  it('registers disposable settings and a client-visible turn projection', async () => {
    const ctx = new Context()
    await ctx.plugin(SessionStore).await()
    await ctx.plugin(SessionProjectionRegistry).await()
    await ctx.plugin(MemorySettings).await()
    const fiber = ctx.plugin({ inject: [...inject], apply })
    await fiber.await()

    const ns = NOTIFICATION_SETTINGS_NAMESPACE
    expect(ctx.settings.get(ns)).toEqual(DEFAULT_NOTIFICATION_SETTINGS)
    await ctx.settings.update(ns, { soundVolume: 0.25, notifySubagents: true })
    expect(ctx.settings.get(ns)).toMatchObject({ soundVolume: 0.25, notifySubagents: true })
    await expect(ctx.settings.update(ns, { soundVolume: 2 })).rejects.toThrow()

    const session = ctx.sessions.create()
    session.append('turn/start', { turn: 1 })
    session.append('turn/end', { turn: 1, reason: { kind: 'interrupted' } })
    expect(ctx.sessionProjections.snapshot(session).values.windowsNotificationTurnEnd)
      .toMatchObject({ turn: 1, outcome: 'interrupted' })

    await fiber.dispose()
    expect(ctx.settings.describe().map(row => row.ns as string)).not.toContain(ns)
    expect(ctx.sessionProjections.snapshot(session).values.windowsNotificationTurnEnd).toBeUndefined()
  })
})
