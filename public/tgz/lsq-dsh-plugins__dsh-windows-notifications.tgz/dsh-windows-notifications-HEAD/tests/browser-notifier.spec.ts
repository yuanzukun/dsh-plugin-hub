// @vitest-environment jsdom

import { afterEach, describe, expect, it, vi } from 'vitest'
import {
  BrowserNotifier,
  desktopPermission,
} from '../src/client/browser-notifier.ts'

class FakeNotification {
  static permission: NotificationPermission = 'granted'
  static requestPermission = vi.fn(() => Promise.resolve(FakeNotification.permission))
  static latest: FakeNotification | undefined
  static instances: FakeNotification[] = []
  onclick: (() => void) | null = null
  onshow: (() => void) | null = null
  onerror: ((error: Event) => void) | null = null
  onclose: ((event: Event) => void) | null = null
  readonly close = vi.fn(() => { this.onclose?.(new Event('close')) })

  constructor(
    readonly title: string,
    readonly options?: NotificationOptions,
  ) {
    FakeNotification.latest = this
    FakeNotification.instances.push(this)
  }
}

function installNotification(): void {
  Object.defineProperty(window, 'isSecureContext', { configurable: true, value: true })
  Object.defineProperty(window, 'Notification', { configurable: true, value: FakeNotification })
}

afterEach(() => {
  vi.restoreAllMocks()
  FakeNotification.latest = undefined
  FakeNotification.instances = []
  FakeNotification.permission = 'granted'
})

describe('BrowserNotifier', () => {
  it('reports unsupported and insecure environments before browser permission', () => {
    Object.defineProperty(window, 'Notification', { configurable: true, value: undefined })
    expect(desktopPermission()).toBe('unsupported')
    installNotification()
    Object.defineProperty(window, 'isSecureContext', { configurable: true, value: false })
    expect(desktopPermission()).toBe('insecure')
  })

  it('creates a silent Windows notification and focuses through its click callback', () => {
    installNotification()
    const focus = vi.spyOn(window, 'focus').mockImplementation(() => undefined)
    const loggedError = vi.spyOn(console, 'error').mockImplementation(() => undefined)
    const clicked = vi.fn()
    const shown = vi.fn()
    const failed = vi.fn()
    const notifier = new BrowserNotifier()
    expect(notifier.show({
      title: 'Done',
      body: 'Session A',
      tag: 'a',
      onClick: clicked,
      onShow: shown,
      onError: failed,
    })).toBe(true)
    expect(FakeNotification.latest?.options).toMatchObject({
      body: 'Session A', icon: '/favicon.svg', tag: 'a', silent: true,
    })
    FakeNotification.latest?.onshow?.()
    expect(shown).toHaveBeenCalledOnce()
    const deliveryError = new Event('error')
    FakeNotification.latest?.onerror?.(deliveryError)
    expect(failed).toHaveBeenCalledWith(deliveryError)
    expect(loggedError).toHaveBeenCalledWith(
      '[windows-notifications] Windows notification delivery failed:',
      deliveryError,
    )
    FakeNotification.latest?.onclick?.()
    expect(FakeNotification.latest?.close).toHaveBeenCalledOnce()
    expect(focus).toHaveBeenCalledOnce()
    expect(clicked).toHaveBeenCalledOnce()
  })

  it('does not construct a notification before permission is granted', () => {
    installNotification()
    FakeNotification.permission = 'default'
    const notifier = new BrowserNotifier()
    expect(notifier.show({ title: 'x', body: 'y', tag: 'z', onClick: vi.fn() })).toBe(false)
    expect(FakeNotification.latest).toBeUndefined()
  })

  it('explicitly closes the unfinished notification in the same replacement channel', () => {
    installNotification()
    const notifier = new BrowserNotifier()

    expect(notifier.show({
      title: 'First', body: 'one', tag: 'unique-1', replaceKey: 'settings-test', onClick: vi.fn(),
    })).toBe(true)
    expect(notifier.show({
      title: 'Second', body: 'two', tag: 'unique-2', replaceKey: 'settings-test', onClick: vi.fn(),
    })).toBe(true)

    const [first, second] = FakeNotification.instances
    expect(first?.options?.tag).toBe('unique-1')
    expect(second?.options?.tag).toBe('unique-2')
    expect(first?.close).toHaveBeenCalledOnce()
    expect(second?.close).not.toHaveBeenCalled()
  })

  it('closes active replaceable notifications during teardown', async () => {
    installNotification()
    const notifier = new BrowserNotifier()
    notifier.show({
      title: 'Test', body: 'active', tag: 'unique', replaceKey: 'settings-test', onClick: vi.fn(),
    })

    await notifier.dispose()

    expect(FakeNotification.latest?.close).toHaveBeenCalledOnce()
  })
})
