import { describe, expect, it } from 'vitest'
import type {
  SessionId,
  SessionListState,
  SessionSummary,
} from '@deepseek-ai/dsh-api-session-controller/client'
import type { SessionPendingInteractionSnapshot } from '@deepseek-ai/dsh-client-ui-session/client'
import { SessionNotificationDetector } from '../src/client/event-detector.ts'

const sid = (value: string): SessionId => value as SessionId

const EMPTY_PENDING: SessionPendingInteractionSnapshot = new Map()

function pending(sessionId: string, kind: string): SessionPendingInteractionSnapshot {
  return new Map([[sid(sessionId), { kind }]])
}

function summary(
  id: string,
  options: Partial<SessionSummary> & {
    end?: { seq: number; turn: number; outcome: 'completed' | 'error' }
  } = {},
): SessionSummary {
  const { end, ...rest } = options
  return {
    id: sid(id),
    displayTitle: `会话 ${id}`,
    running: false,
    blank: false,
    updatedAt: 1,
    projectionValues: { windowsNotificationTurnEnd: end ?? null },
    ...rest,
  } as SessionSummary
}

function state(rows: SessionSummary[], phase: SessionListState['phase'] = 'ready'): SessionListState {
  return {
    ids: rows.map(row => row.id),
    byId: Object.fromEntries(rows.map(row => [row.id, row])) as Record<SessionId, SessionSummary>,
    current: rows[0]?.id,
    phase,
    subagentsByParent: {},
    jobsBySession: {},
    currentAddress: undefined,
  } as SessionListState
}

describe('SessionNotificationDetector', () => {
  it('keeps initial hydration silent and emits each later turn ending once', () => {
    const detector = new SessionNotificationDetector()
    expect(detector.scan(state([summary('a', { end: { seq: 3, turn: 1, outcome: 'completed' } })]), EMPTY_PENDING)).toEqual([])

    const next = state([summary('a', { end: { seq: 8, turn: 2, outcome: 'error' } })])
    expect(detector.scan(next, EMPTY_PENDING)).toEqual([expect.objectContaining({
      kind: 'turn',
      sessionId: sid('a'),
      end: { seq: 8, turn: 2, outcome: 'error' },
    })])
    expect(detector.scan(next, EMPTY_PENDING)).toEqual([])
  })

  it('emits new pending interactions but not clearing or unchanged states', () => {
    const detector = new SessionNotificationDetector()
    detector.scan(state([summary('a')]), EMPTY_PENDING)
    const question = state([summary('a')])
    const pendingQuestion = pending('a', 'question')
    expect(detector.scan(question, pendingQuestion)).toEqual([expect.objectContaining({
      kind: 'interaction', interaction: 'question',
    })])
    expect(detector.scan(question, pendingQuestion)).toEqual([])
    expect(detector.scan(state([summary('a')]), EMPTY_PENDING)).toEqual([])
    expect(detector.scan(question, pendingQuestion)).toHaveLength(1)
  })

  it('baselines sessions first seen after ready and marks subagents without notifying old work', () => {
    const detector = new SessionNotificationDetector()
    expect(detector.scan(state([], 'pending'), EMPTY_PENDING)).toEqual([])
    expect(detector.scan(state([summary('a')]), EMPTY_PENDING)).toEqual([])
    expect(detector.scan(state([
      summary('a'),
      summary('child', {
        origin: 'subagent',
        end: { seq: 5, turn: 1, outcome: 'completed' },
      }),
    ]), EMPTY_PENDING)).toEqual([])

    const events = detector.scan(state([
      summary('a'),
      summary('child', {
        origin: 'subagent',
        end: { seq: 9, turn: 2, outcome: 'completed' },
      }),
    ]), EMPTY_PENDING)
    expect(events).toEqual([expect.objectContaining({ sessionId: sid('child'), subagent: true })])
  })

  it('forgets removed sessions so reappearing history is treated as a new baseline', () => {
    const detector = new SessionNotificationDetector()
    detector.scan(state([summary('a')]), EMPTY_PENDING)
    detector.scan(state([]), EMPTY_PENDING)
    expect(detector.scan(state([
      summary('a', { end: { seq: 100, turn: 10, outcome: 'completed' } }),
    ]), EMPTY_PENDING)).toEqual([])
  })
})
