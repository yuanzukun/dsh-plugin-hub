import { describe, expect, it } from 'vitest'
import type { SessionEvent } from '@deepseek-ai/dsh-session'
import { normalizeTurnOutcome, turnEndProjection } from '../src/projection.ts'

function event(type: string, data: unknown, seq = 0): SessionEvent {
  return { type, seq, time: seq, data } as SessionEvent
}

describe('turnEndProjection', () => {
  it('keeps unrelated events reference-stable and records the latest durable ending', () => {
    const initial = turnEndProjection.init()
    expect(initial).toBeNull()
    expect(turnEndProjection.apply(initial, event('turn/start', { turn: 1 }))).toBe(initial)

    const completed = turnEndProjection.apply(initial, event(
      'turn/end',
      { turn: 1, reason: { kind: 'completed' } },
      7,
    ))
    expect(completed).toEqual({ seq: 7, turn: 1, outcome: 'completed' })
    expect(turnEndProjection.wire.view(completed)).toBe(completed)
  })

  it.each(['aborted', 'blocked', 'error', 'max-tokens', 'interrupted'] as const)(
    'preserves the %s outcome',
    (kind) => {
      const result = turnEndProjection.apply(null, event(
        'turn/end',
        { turn: 2, reason: { kind } },
        9,
      ))
      expect(result).toEqual({ seq: 9, turn: 2, outcome: kind })
    },
  )

  it('folds extension-defined reasons into other', () => {
    expect(normalizeTurnOutcome('plugin-specific')).toBe('other')
  })
})
