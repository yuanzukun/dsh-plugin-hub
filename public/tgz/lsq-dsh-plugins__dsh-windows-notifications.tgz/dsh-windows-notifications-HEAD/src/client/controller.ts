/** Notification policy: settings gates, localization, Windows dispatch, sound, and navigation. */

import type { ISessions } from '@deepseek-ai/dsh-api-session-controller/client'
import type { SettingsScope } from '@deepseek-ai/dsh-client-ui-settings/client'
import type { SessionPendingInteractionSnapshot } from '@deepseek-ai/dsh-client-ui-session/client'
import type { HostObservable } from '@deepseek-ai/dsh-client-ui-slots'
import type { TranslateNS } from '@deepseek-ai/dsh-client-locale/client'
import {
  DEFAULT_NOTIFICATION_SETTINGS,
  type NotificationSettings,
  type TurnOutcome,
} from '../contracts.ts'
import type { NotificationLocaleKey } from './locales.ts'
import type { NotificationCandidate } from './event-detector.ts'
import { SessionNotificationDetector } from './event-detector.ts'
import {
  BrowserNotifier,
  type DesktopPermission,
  type SoundKind,
} from './browser-notifier.ts'
import type { PageNotificationMessage } from './page-notification-model.ts'

export interface NotificationControllerOptions {
  sessions: ISessions
  pendingInteractions: HostObservable<SessionPendingInteractionSnapshot>
  settings: SettingsScope<NotificationSettings>
  browser: BrowserNotifier
  t: TranslateNS<'settings.windows-notifications'>
  showPageNotification: (message: PageNotificationMessage) => void
  onPermissionChange: (permission: DesktopPermission) => void
  info: (message: string) => void
  warn: (message: string, error?: unknown) => void
}

interface Copy {
  title: NotificationLocaleKey
  body: NotificationLocaleKey
  sound: SoundKind
}

const TURN_COPY: Record<TurnOutcome, Copy> = {
  completed: { title: 'notification.completed.title', body: 'notification.completed.body', sound: 'success' },
  aborted: { title: 'notification.aborted.title', body: 'notification.aborted.body', sound: 'failure' },
  blocked: { title: 'notification.blocked.title', body: 'notification.blocked.body', sound: 'attention' },
  error: { title: 'notification.error.title', body: 'notification.error.body', sound: 'failure' },
  'max-tokens': { title: 'notification.max-tokens.title', body: 'notification.max-tokens.body', sound: 'attention' },
  interrupted: { title: 'notification.interrupted.title', body: 'notification.interrupted.body', sound: 'failure' },
  other: { title: 'notification.other.title', body: 'notification.other.body', sound: 'failure' },
}

const INTERACTION_COPY: Record<string, Copy> = {
  approval: { title: 'notification.approval.title', body: 'notification.approval.body', sound: 'attention' },
  'plan-review': { title: 'notification.plan-review.title', body: 'notification.plan-review.body', sound: 'attention' },
  question: { title: 'notification.question.title', body: 'notification.question.body', sound: 'attention' },
}

const WINDOWS_TEST_REPLACE_KEY = 'windows-notification-test'
const WINDOWS_TEST_FEEDBACK_REPLACE_KEY = 'windows-notification-test-feedback'
const PAGE_TEST_REPLACE_KEY = 'page-notification-test'

/** One plugin-lifetime controller. It never replays the baseline after reload or reconnect. */
export class NotificationController {
  private readonly detector = new SessionNotificationDetector()
  private readonly options: NotificationControllerOptions
  private testSequence = 0

  constructor(options: NotificationControllerOptions) {
    this.options = options
  }

  start(): () => void {
    const scan = (): void => {
      const events = this.detector.scan(
        this.options.sessions.list.getSnapshot(),
        this.options.pendingInteractions.getSnapshot(),
      )
      for (const event of events) this.dispatch(event)
    }
    scan()
    const disposeList = this.options.sessions.list.subscribe(scan)
    const disposePending = this.options.pendingInteractions.subscribe(scan)
    return () => { disposeList(); disposePending() }
  }

  permission(): DesktopPermission {
    return this.options.browser.permission()
  }

  async requestPermission(): Promise<DesktopPermission> {
    const permission = await this.options.browser.requestPermission()
    this.options.onPermissionChange(permission)
    return permission
  }

  async testNotification(): Promise<void> {
    const permission = await this.requestPermission()
    if (permission !== 'granted') {
      this.options.showPageNotification({
        title: this.options.t('settings.permission.denied'),
        kind: 'failure',
        replaceKey: WINDOWS_TEST_FEEDBACK_REPLACE_KEY,
      })
      return
    }
    const tag = `dsh-notification-test-${Date.now()}-${++this.testSequence}`
    const reportFailure = (error?: unknown): void => {
      this.options.warn('Windows notification test failed', error)
      this.options.showPageNotification({
        title: this.options.t('settings.test.notification.failed'),
        kind: 'failure',
        replaceKey: WINDOWS_TEST_FEEDBACK_REPLACE_KEY,
      })
    }
    const accepted = this.options.browser.show({
      title: `${this.options.t('notification.app')} · ${this.options.t('notification.test.title')}`,
      body: this.options.t('notification.test.body'),
      tag,
      replaceKey: WINDOWS_TEST_REPLACE_KEY,
      onClick: () => { window.focus() },
      onShow: () => { this.options.info('Windows notification test displayed') },
      onError: reportFailure,
    })
    if (accepted) this.options.info('Windows notification test requested with active-test replacement')
    else reportFailure()
  }

  testPageNotification(): void {
    this.options.showPageNotification({
      title: this.options.t('notification.test.title'),
      body: this.options.t('notification.test.toast.body'),
      kind: 'success',
      replaceKey: PAGE_TEST_REPLACE_KEY,
    })
  }

  async testSound(): Promise<void> {
    const settings = this.settings()
    await this.options.browser.primeSound()
    await this.options.browser.playSound('attention', settings.soundVolume)
  }

  private dispatch(candidate: NotificationCandidate): void {
    const settings = this.settings()
    if (!settings.enabled || (candidate.subagent && !settings.notifySubagents)) return
    if (candidate.kind === 'turn') {
      if (candidate.end.outcome === 'completed' ? !settings.notifyCompleted : !settings.notifyFailed) return
    } else if (!settings.notifyInteraction) return

    const copy = candidate.kind === 'turn'
      ? TURN_COPY[candidate.end.outcome]
      : INTERACTION_COPY[candidate.interaction]
    if (copy === undefined) return
    const eventTitle = this.options.t(copy.title)
    const body = this.options.t(copy.body, { title: candidate.title })
    const inactive = document.visibilityState !== 'visible' || !document.hasFocus()
    const mayShowDesktop = settings.desktopEnabled && (!settings.onlyWhenInactive || inactive)
    const desktopShown = mayShowDesktop && this.options.browser.show({
      title: `${this.options.t('notification.app')} · ${eventTitle}`,
      body,
      tag: this.tagOf(candidate),
      onClick: () => {
        try {
          this.options.sessions.open(candidate.sessionId)
        } catch (error) {
          this.options.warn(`cannot open notification session ${String(candidate.sessionId)}`, error)
        }
      },
    })

    if (!desktopShown && settings.toastEnabled) {
      this.options.showPageNotification({ title: eventTitle, body, kind: copy.sound })
    }
    if (settings.soundEnabled) void this.options.browser.playSound(copy.sound, settings.soundVolume)
  }

  private settings(): NotificationSettings {
    return this.options.settings.getSnapshot().value ?? { ...DEFAULT_NOTIFICATION_SETTINGS }
  }

  private tagOf(candidate: NotificationCandidate): string {
    return candidate.kind === 'turn'
      ? `dsh-${String(candidate.sessionId)}-turn-${candidate.end.seq}`
      : `dsh-${String(candidate.sessionId)}-${candidate.interaction}`
  }
}
