/** Browser adapters for Windows Notification API and a small synthesized alert sound. */

export type DesktopPermission = 'granted' | 'default' | 'denied' | 'insecure' | 'unsupported'
export type SoundKind = 'success' | 'attention' | 'failure'

interface WindowWithWebkitAudio extends Window {
  webkitAudioContext?: typeof AudioContext
}

export interface DesktopNotificationRequest {
  title: string
  body: string
  tag: string
  /** Equal non-empty keys explicitly close an unfinished notification after its replacement is created. */
  replaceKey?: string
  onClick: () => void
  onShow?: () => void
  onError?: (error: Event) => void
}

/** Read the effective permission, including the secure-origin requirement browsers expose separately. */
export function desktopPermission(): DesktopPermission {
  if (typeof window === 'undefined' || typeof window.Notification === 'undefined') return 'unsupported'
  if (!window.isSecureContext) return 'insecure'
  return window.Notification.permission
}

/** Imperative browser boundary kept separate from event detection and settings UI. */
export class BrowserNotifier {
  private audio: AudioContext | null = null
  private readonly replaceableNotifications = new Map<string, Notification>()

  permission(): DesktopPermission {
    return desktopPermission()
  }

  async requestPermission(): Promise<DesktopPermission> {
    const current = this.permission()
    if (current === 'unsupported' || current === 'insecure' || current === 'denied') return current
    if (current === 'granted') return current
    try {
      return await window.Notification.requestPermission()
    } catch (error) {
      console.error('[windows-notifications] requesting browser notification permission failed:', error)
      return this.permission()
    }
  }

  show(request: DesktopNotificationRequest): boolean {
    if (this.permission() !== 'granted') return false
    try {
      const notification = new window.Notification(request.title, {
        body: request.body,
        icon: '/favicon.svg',
        tag: request.tag,
        silent: true,
      })
      const replaceKey = request.replaceKey === '' ? undefined : request.replaceKey
      if (replaceKey !== undefined) {
        const previous = this.replaceableNotifications.get(replaceKey)
        this.replaceableNotifications.set(replaceKey, notification)
        previous?.close()
        notification.onclose = () => {
          if (this.replaceableNotifications.get(replaceKey) === notification) {
            this.replaceableNotifications.delete(replaceKey)
          }
        }
      }
      notification.onclick = () => {
        notification.close()
        window.focus()
        request.onClick()
      }
      notification.onshow = () => { request.onShow?.() }
      notification.onerror = (error) => {
        if (replaceKey !== undefined && this.replaceableNotifications.get(replaceKey) === notification) {
          this.replaceableNotifications.delete(replaceKey)
        }
        console.error('[windows-notifications] Windows notification delivery failed:', error)
        request.onError?.(error)
      }
      return true
    } catch (error) {
      console.error('[windows-notifications] creating Windows notification failed:', error)
      return false
    }
  }

  /** Resume Web Audio from a user gesture without producing an audible tone. */
  async primeSound(): Promise<void> {
    const audio = this.audioContext()
    if (audio.state === 'suspended') await audio.resume()
  }

  async playSound(kind: SoundKind, volume: number): Promise<void> {
    try {
      const audio = this.audioContext()
      if (audio.state === 'suspended') await audio.resume()
      const now = audio.currentTime
      const gain = audio.createGain()
      gain.gain.setValueAtTime(0.0001, now)
      gain.gain.exponentialRampToValueAtTime(Math.max(0.0001, volume * 0.16), now + 0.018)
      gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.34)
      gain.connect(audio.destination)

      const frequencies = kind === 'success' ? [660, 880]
        : kind === 'attention' ? [520, 660]
          : [360, 300]
      for (const [index, frequency] of frequencies.entries()) {
        const oscillator = audio.createOscillator()
        oscillator.type = 'sine'
        oscillator.frequency.setValueAtTime(frequency, now + index * 0.09)
        oscillator.connect(gain)
        oscillator.start(now + index * 0.09)
        oscillator.stop(now + 0.25 + index * 0.09)
      }
    } catch (error) {
      console.warn('[windows-notifications] playing notification sound failed:', error)
    }
  }

  async dispose(): Promise<void> {
    const activeNotifications = [...this.replaceableNotifications.values()]
    this.replaceableNotifications.clear()
    for (const notification of activeNotifications) notification.close()
    const audio = this.audio
    this.audio = null
    if (audio !== null) await audio.close()
  }

  private audioContext(): AudioContext {
    if (this.audio !== null) return this.audio
    const AudioConstructor = window.AudioContext
      ?? (window as WindowWithWebkitAudio).webkitAudioContext
    if (AudioConstructor === undefined) throw new Error('Web Audio API is unavailable')
    this.audio = new AudioConstructor()
    return this.audio
  }
}
