/** Dedicated settings page for desktop notifications, in-app cards, and sound. */

import { Button } from '@deepseek-ai/dsh-client-ui-primitives'
import type {
  PropsLocale,
  PropsRuntime,
  PropsStore,
} from '@deepseek-ai/dsh-client-ui-slots'
import type {} from '@deepseek-ai/dsh-client-ui-settings/client'
import type {
  NotificationSettingField,
} from '../contracts.ts'
import type { NotificationLocaleKey } from './locales.ts'
import type { createNotificationSettingsStore } from './stores.ts'

export interface NotificationSettingsSectionInjected {
  setSetting: (field: NotificationSettingField, value: boolean | number) => void
  requestPermission: () => void
  testNotification: () => void
  testPageNotification: () => void
  testSound: () => void
}

export type NotificationSettingsSectionProps =
  PropsRuntime<'settings.section'>
  & PropsStore<ReturnType<typeof createNotificationSettingsStore>>
  & PropsLocale<'settings.windows-notifications'>
  & NotificationSettingsSectionInjected

interface ToggleRowProps {
  title: string
  description: string
  checked: boolean
  disabled: boolean
  onChange: (checked: boolean) => void
}

function ToggleRow(props: ToggleRowProps) {
  return (
    <div className={`dsh-win-notify-row${props.disabled ? ' dsh-win-notify-disabled' : ''}`}>
      <div className="dsh-win-notify-row-copy">
        <div className="dsh-win-notify-row-title">{props.title}</div>
        <div className="dsh-win-notify-row-description">{props.description}</div>
      </div>
      <button
        type="button"
        className="dsh-win-notify-switch"
        role="switch"
        aria-label={props.title}
        aria-checked={props.checked}
        disabled={props.disabled}
        onClick={() => { props.onChange(!props.checked) }}
      />
    </div>
  )
}

const permissionKey: Record<string, NotificationLocaleKey> = {
  granted: 'settings.permission.granted',
  default: 'settings.permission.default',
  denied: 'settings.permission.denied',
  insecure: 'settings.permission.insecure',
  unsupported: 'settings.permission.unsupported',
}

/** Render the plugin-owned Settings → Notifications page. */
export function NotificationSettingsSection({
  useStore,
  t,
  setSetting,
  requestPermission,
  testNotification,
  testPageNotification,
  testSound,
}: NotificationSettingsSectionProps) {
  const state = useStore(value => value)
  const { settings } = state
  const available = state.status === 'ready'
  const writable = available && state.writable
  const subordinateDisabled = !writable || !settings.enabled
  const statusText = state.status === 'loading'
    ? t('settings.sync.loading')
    : state.status === 'unavailable'
      ? t('settings.sync.unavailable')
      : t(permissionKey[state.permission] ?? 'settings.permission.unsupported')

  const toggle = (
    field: NotificationSettingField,
    title: NotificationLocaleKey,
    description: NotificationLocaleKey,
    disabled = subordinateDisabled,
  ) => (
    <ToggleRow
      title={t(title)}
      description={t(description)}
      checked={Boolean(settings[field])}
      disabled={disabled}
      onChange={(checked) => { setSetting(field, checked) }}
    />
  )

  return (
    <section className="dsh-win-notify-settings" aria-labelledby="dsh-win-notify-title">
      <div className="dsh-win-notify-heading">
        <div className="dsh-win-notify-heading-copy">
          <h2 className="dsh-win-notify-title" id="dsh-win-notify-title">{t('settings.title')}</h2>
          <div className="dsh-win-notify-description">{t('settings.description')}</div>
        </div>
        <span className="dsh-win-notify-status" data-state={state.permission}>{statusText}</span>
      </div>

      {settings.desktopEnabled && state.permission !== 'granted' && (
        <div className="dsh-win-notify-permission">
          <div className="dsh-win-notify-permission-text">
            {t(permissionKey[state.permission] ?? 'settings.permission.unsupported')}
          </div>
          <Button
            variant="outline"
            size="sm"
            disabled={state.permission === 'unsupported' || state.permission === 'insecure'}
            onClick={requestPermission}
          >
            {t(state.permission === 'default' ? 'settings.permission.button' : 'settings.permission.retry')}
          </Button>
        </div>
      )}

      {toggle('enabled', 'settings.master.title', 'settings.master.description', !writable)}
      {toggle('desktopEnabled', 'settings.desktop.title', 'settings.desktop.description')}
      {toggle('onlyWhenInactive', 'settings.background.title', 'settings.background.description', subordinateDisabled || !settings.desktopEnabled)}
      {toggle('toastEnabled', 'settings.toast.title', 'settings.toast.description')}
      {toggle('soundEnabled', 'settings.sound.title', 'settings.sound.description')}

      <div className={`dsh-win-notify-row${subordinateDisabled || !settings.soundEnabled ? ' dsh-win-notify-disabled' : ''}`}>
        <div className="dsh-win-notify-row-copy">
          <div className="dsh-win-notify-row-title">{t('settings.volume.title')}</div>
        </div>
        <div className="dsh-win-notify-volume">
          <input
            type="range"
            min="0"
            max="100"
            step="5"
            aria-label={t('settings.volume.title')}
            value={Math.round(settings.soundVolume * 100)}
            disabled={subordinateDisabled || !settings.soundEnabled}
            onChange={(event) => { setSetting('soundVolume', Number(event.currentTarget.value) / 100) }}
          />
          <span className="dsh-win-notify-volume-value">{Math.round(settings.soundVolume * 100)}%</span>
        </div>
      </div>

      {toggle('notifyCompleted', 'settings.completed.title', 'settings.completed.description')}
      {toggle('notifyFailed', 'settings.failed.title', 'settings.failed.description')}
      {toggle('notifyInteraction', 'settings.interaction.title', 'settings.interaction.description')}
      {toggle('notifySubagents', 'settings.subagents.title', 'settings.subagents.description')}

      <div className="dsh-win-notify-actions">
        <Button variant="outline" size="sm" onClick={testNotification}>
          {t('settings.test.notification')}
        </Button>
        <Button variant="outline" size="sm" onClick={testPageNotification}>
          {t('settings.test.toast')}
        </Button>
        <Button variant="outline" size="sm" onClick={testSound}>
          {t('settings.test.sound')}
        </Button>
      </div>
    </section>
  )
}
