/** Browser half: wires settings, list transitions, native notifications, sound, and UI slots. */

import type { Context as ClientContext } from '@deepseek-ai/cordis'
import type { ISessions } from '@deepseek-ai/dsh-api-session-controller/client'
import type { BoundActions } from '@deepseek-ai/dsh-client-ui-slots'
import type {} from '@deepseek-ai/dsh-client-ui-layout/client'
import type {} from '@deepseek-ai/dsh-client-ui-renderer/client'
import type {} from '@deepseek-ai/dsh-client-ui-session/client'
import type {} from '@deepseek-ai/dsh-client-ui-settings/client'
import {
  NOTIFICATION_SETTINGS_NAMESPACE,
  type NotificationSettingField,
  type NotificationSettings,
} from '../contracts.ts'
import { BrowserNotifier } from './browser-notifier.ts'
import { NotificationController } from './controller.ts'
import { PageNotificationOverlay } from './PageNotificationOverlay.tsx'
import {
  NotificationSettingsSection,
  type NotificationSettingsSectionInjected,
} from './NotificationSettingsSection.tsx'
import { en, SETTINGS_NS, zh } from './locales.ts'
import type { PageNotificationMessage } from './page-notification-model.ts'
import { installPageNotificationStyles } from './page-notification-styles.ts'
import {
  createNotificationSettingsStore,
  createPageNotificationQueueStore,
  type PageNotificationItem,
} from './stores.ts'
import { installSettingsStyles } from './styles.ts'

export const inject = ['slots', 'locale', 'sessions', 'settingsScope', 'uiSession']

/** Install every browser contribution under the plugin fiber. */
export function apply(ctx: ClientContext): void {
  installSettingsStyles(ctx)
  installPageNotificationStyles(ctx)
  ctx.effect(() => ctx.locale.register(SETTINGS_NS, { zh, en }), 'windows-notifications: dictionaries')

  const settings = ctx.settingsScope.bind<NotificationSettings>({
    namespace: NOTIFICATION_SETTINGS_NAMESPACE,
  })
  const browser = new BrowserNotifier()
  const settingsStore = createNotificationSettingsStore()
  const pageNotificationStore = createPageNotificationQueueStore()
  let settingsActions: BoundActions<ReturnType<typeof createNotificationSettingsStore>> | undefined
  let pageNotificationActions: BoundActions<ReturnType<typeof createPageNotificationQueueStore>> | undefined
  let pageNotificationSequence = 0
  const pendingPageNotifications: PageNotificationItem[] = []

  const syncSettings = (): void => {
    settingsActions?.sync(settings.getSnapshot(), browser.permission())
  }
  ctx.effect(() => settings.subscribe(syncSettings), 'windows-notifications: settings subscription')

  const showPageNotification = (message: PageNotificationMessage): void => {
    const item: PageNotificationItem = { id: ++pageNotificationSequence, ...message }
    if (pageNotificationActions === undefined) pendingPageNotifications.push(item)
    else pageNotificationActions.show(item)
    const behavior = message.replaceKey === undefined ? 'queued' : `replace=${message.replaceKey}`
    ctx.logger.info(`windows-notifications: branded page notification shown (kind=${message.kind}, ${behavior}, placement=top-center, mark=FishLogo)`)
  }

  const controller = new NotificationController({
    // This package compiles Host and browser faces together; both declare a
    // `sessions` Context service. The browser composition supplies ISessions.
    sessions: ctx.get('sessions') as unknown as ISessions,
    pendingInteractions: ctx.uiSession.pendingInteractions,
    settings,
    browser,
    t: ctx.locale.bind(SETTINGS_NS),
    showPageNotification,
    onPermissionChange: permission => { settingsActions?.setPermission(permission) },
    info: message => { ctx.logger.info(`windows-notifications: ${message}`) },
    warn: (message, error) => {
      ctx.logger.warn(`windows-notifications: ${message}`)
      if (error !== undefined) ctx.logger.warn(error)
    },
  })
  ctx.effect(() => controller.start(), 'windows-notifications: session transition listener')
  ctx.effect(() => () => { void browser.dispose() }, 'windows-notifications: audio teardown')

  ctx.effect(() => {
    const refresh = (): void => { settingsActions?.setPermission(controller.permission()) }
    window.addEventListener('focus', refresh)
    document.addEventListener('visibilitychange', refresh)
    return () => {
      window.removeEventListener('focus', refresh)
      document.removeEventListener('visibilitychange', refresh)
    }
  }, 'windows-notifications: permission refresh')

  ctx.effect(() => {
    let primed = false
    const prime = (): void => {
      if (primed || settings.getSnapshot().value?.soundEnabled === false) return
      primed = true
      window.removeEventListener('pointerdown', prime, true)
      window.removeEventListener('keydown', prime, true)
      void browser.primeSound().catch((error: unknown) => {
        ctx.logger.warn('windows-notifications: priming sound from first interaction failed')
        ctx.logger.warn(error)
      })
    }
    window.addEventListener('pointerdown', prime, true)
    window.addEventListener('keydown', prime, true)
    return () => {
      window.removeEventListener('pointerdown', prime, true)
      window.removeEventListener('keydown', prime, true)
    }
  }, 'windows-notifications: first-interaction sound unlock')

  ctx.slots.inject('shell.overlay', () => ctx.slots.register({
    name: 'shell.overlay',
    id: 'windows-notifications',
    order: 20,
    store: pageNotificationStore,
    inject: (actions: BoundActions<typeof pageNotificationStore>) => {
      pageNotificationActions = actions
      for (const item of pendingPageNotifications.splice(0)) actions.show(item)
      return {}
    },
  }, PageNotificationOverlay))

  ctx.slots.inject('settings.section', () => ctx.slots.register({
    name: 'settings.section',
    id: 'notifications',
    order: 30,
    label: () => ctx.locale.bind(SETTINGS_NS)('settings.nav'),
    store: settingsStore,
    locale: SETTINGS_NS,
    inject: (actions: BoundActions<typeof settingsStore>): NotificationSettingsSectionInjected => {
      settingsActions = actions
      syncSettings()
      return {
        setSetting: (field: NotificationSettingField, value: boolean | number) => {
          actions.setLocal(field, value)
          if (field === 'soundEnabled' && value === true) {
            void browser.primeSound().catch((error: unknown) => {
              ctx.logger.warn('windows-notifications: priming notification sound failed')
              ctx.logger.warn(error)
            })
          }
          void settings.set(field, value).catch((error: unknown) => {
            ctx.logger.warn(`windows-notifications: setting ${JSON.stringify(field)} write failed`)
            ctx.logger.warn(error)
            syncSettings()
          })
        },
        requestPermission: () => { void controller.requestPermission() },
        testNotification: () => { void controller.testNotification() },
        testPageNotification: () => {
          controller.testPageNotification()
          ctx.logger.info('windows-notifications: in-app notification test dispatched')
        },
        testSound: () => { void controller.testSound() },
      }
    },
  }, NotificationSettingsSection))

  ctx.logger.info('windows-notifications: browser notifier activated')
}
