/** Frame-wide renderer for the plugin's DSH-styled page notification queue. */

import { useEffect } from 'react'
import { createPortal } from 'react-dom'
import {
  FishLogo,
  StateDot,
  type StateDotState,
} from '@deepseek-ai/dsh-client-ui-primitives'
import type {
  PropsRuntime,
  PropsStore,
} from '@deepseek-ai/dsh-client-ui-slots'
import type {} from '@deepseek-ai/dsh-client-ui-layout/client'
import type { createPageNotificationQueueStore } from './stores.ts'

/** Keep the card readable, then let its final 240 ms CSS fade finish. */
export const PAGE_NOTIFICATION_DURATION_MS = 4000

export type PageNotificationOverlayProps =
  PropsRuntime<'shell.overlay'>
  & PropsStore<ReturnType<typeof createPageNotificationQueueStore>>

function stateOf(kind: 'success' | 'attention' | 'failure'): StateDotState {
  if (kind === 'success') return 'done'
  if (kind === 'attention') return 'warning'
  return 'error'
}

/** Render one compact, viewport-centered card and advance the queue after it fades. */
export function PageNotificationOverlay({ useStore, actions }: PageNotificationOverlayProps) {
  const item = useStore(state => state.current)
  const itemId = item?.id

  useEffect(() => {
    if (itemId === undefined) return
    const timer = window.setTimeout(() => { actions.dismiss(itemId) }, PAGE_NOTIFICATION_DURATION_MS)
    return () => { window.clearTimeout(timer) }
  }, [actions, itemId])

  if (item === null) return null
  return createPortal(
    <div
      key={item.id}
      className="dsh-win-page-notification"
      data-kind={item.kind}
      data-placement="top-center"
      role={item.kind === 'success' ? 'status' : 'alert'}
    >
      <span className="dsh-win-page-notification-brand" aria-hidden="true">
        <FishLogo size={30} className="dsh-win-page-notification-fish" />
      </span>
      <span className="dsh-win-page-notification-copy">
        <span className="dsh-win-page-notification-heading">
          <span className="dsh-win-page-notification-title">{item.title}</span>
          <StateDot
            state={stateOf(item.kind)}
            size={8}
            className="dsh-win-page-notification-state"
          />
        </span>
        {item.body !== undefined && (
          <span className="dsh-win-page-notification-body">{item.body}</span>
        )}
      </span>
    </div>,
    document.body,
  )
}
