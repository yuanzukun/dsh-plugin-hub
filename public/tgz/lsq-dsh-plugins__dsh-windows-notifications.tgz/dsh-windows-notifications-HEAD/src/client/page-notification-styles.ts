/** DSH design-token stylesheet for the top-center page notification card. */

import type { Context as ClientContext } from '@deepseek-ai/cordis'

const PLUGIN_ID = '@lsq64737/dsh-windows-notifications'

const PAGE_NOTIFICATION_CSS = `
.dsh-win-page-notification {
  box-sizing: border-box;
  position: fixed;
  top: 20px;
  left: 50%;
  z-index: 1100;
  pointer-events: none;
  display: flex;
  align-items: center;
  gap: 13px;
  width: max-content;
  min-width: 300px;
  max-width: min(440px, calc(100vw - 32px));
  padding: 13px 16px 13px 14px;
  border: 1px solid var(--dsw-alias-border-l2-darkmode-thin);
  border-radius: 20px;
  background: var(--dsw-alias-bg-layer-2);
  box-shadow: var(--dsw-shadow-lv3);
  color: var(--dsw-alias-label-primary);
  transform: translateX(-50%);
  animation:
    dsh-win-page-notification-in 180ms var(--ds-ease-in-out),
    dsh-win-page-notification-out 200ms var(--ds-ease-in-out) 3800ms forwards;
}
.dsh-win-page-notification-brand {
  display: grid;
  place-items: center;
  flex: none;
  width: 36px;
  height: 36px;
  color: var(--dsw-alias-label-primary);
}
.dsh-win-page-notification-fish {
  display: block;
}
.dsh-win-page-notification-copy {
  display: flex;
  flex-direction: column;
  min-width: 0;
}
.dsh-win-page-notification-heading {
  display: flex;
  align-items: center;
  gap: 8px;
  min-width: 0;
}
.dsh-win-page-notification-title {
  min-width: 0;
  overflow-wrap: anywhere;
  color: var(--dsw-alias-label-primary);
  font-size: 14px;
  font-weight: 500;
  line-height: 20px;
}
.dsh-win-page-notification-state {
  flex: none;
}
.dsh-win-page-notification-body {
  overflow-wrap: anywhere;
  margin-top: 1px;
  color: var(--dsw-alias-label-tertiary);
  font-size: 13px;
  line-height: 20px;
}
@keyframes dsh-win-page-notification-in {
  from { opacity: 0; transform: translate(-50%, -8px); }
  to { opacity: 1; transform: translate(-50%, 0); }
}
@keyframes dsh-win-page-notification-out {
  to { opacity: 0; transform: translate(-50%, -4px); }
}
@media (max-width: 480px) {
  .dsh-win-page-notification {
    top: 12px;
    width: calc(100vw - 32px);
    min-width: 0;
  }
}
@media (prefers-reduced-motion: reduce) {
  .dsh-win-page-notification {
    animation: dsh-win-page-notification-out 200ms var(--ds-ease-in-out) 3800ms forwards;
  }
}
`

/** Mount the card stylesheet once for the lifetime of the plugin fiber. */
export function installPageNotificationStyles(ctx: ClientContext): void {
  ctx.effect(() => {
    const tag = document.createElement('style')
    tag.dataset.plugin = PLUGIN_ID
    tag.dataset.pluginCss = `${PLUGIN_ID}/page-notification`
    tag.textContent = PAGE_NOTIFICATION_CSS
    document.head.appendChild(tag)
    return () => { tag.remove() }
  }, 'windows-notifications: page notification styles')
}
