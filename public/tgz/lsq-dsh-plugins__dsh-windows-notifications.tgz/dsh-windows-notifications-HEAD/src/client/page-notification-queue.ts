/** Pure queue transitions shared by the DSH store wrapper and focused tests. */

import type { PageNotificationMessage } from './page-notification-model.ts'

export interface PageNotificationItem extends PageNotificationMessage {
  id: number
}

export interface PageNotificationQueueState {
  current: PageNotificationItem | null
  queued: PageNotificationItem[]
}

export function createPageNotificationQueueState(): PageNotificationQueueState {
  return { current: null, queued: [] }
}

/** Replace the matching transient channel; preserve distinct real events in order. */
export function showPageNotificationInQueue(
  state: PageNotificationQueueState,
  item: PageNotificationItem,
): void {
  const replaceKey = item.replaceKey === '' ? undefined : item.replaceKey
  if (replaceKey !== undefined) {
    state.queued = state.queued.filter(queued => queued.replaceKey !== replaceKey)
    if (state.current?.replaceKey === replaceKey) {
      state.current = item
      return
    }
  }
  if (state.current === null) state.current = item
  else state.queued.push(item)
}

export function dismissPageNotificationInQueue(
  state: PageNotificationQueueState,
  id: number,
): void {
  if (state.current?.id !== id) return
  state.current = state.queued.shift() ?? null
}
