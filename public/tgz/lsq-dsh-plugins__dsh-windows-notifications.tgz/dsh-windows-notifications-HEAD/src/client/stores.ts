/** View-state stores for notification settings and the frame-wide page-card queue. */

import {
  defineStore,
  type EngineStoreHandle,
} from '@deepseek-ai/dsh-client-store'
import type { SettingsScopeSnapshot } from '@deepseek-ai/dsh-client-ui-settings/client'
import {
  DEFAULT_NOTIFICATION_SETTINGS,
  type NotificationSettingField,
  type NotificationSettings,
} from '../contracts.ts'
import type { DesktopPermission } from './browser-notifier.ts'
import {
  createPageNotificationQueueState,
  dismissPageNotificationInQueue,
  showPageNotificationInQueue,
  type PageNotificationItem,
  type PageNotificationQueueState,
} from './page-notification-queue.ts'

export type { PageNotificationItem, PageNotificationQueueState } from './page-notification-queue.ts'

export interface NotificationSettingsState {
  settings: NotificationSettings
  status: SettingsScopeSnapshot<NotificationSettings>['status']
  writable: boolean
  revision: number
  permission: DesktopPermission
}

type NotificationSettingsActions = {
  sync: (
    draft: NotificationSettingsState,
    snapshot: SettingsScopeSnapshot<NotificationSettings>,
    permission: DesktopPermission,
  ) => void
  setLocal: (
    draft: NotificationSettingsState,
    field: NotificationSettingField,
    value: boolean | number,
  ) => void
  setPermission: (draft: NotificationSettingsState, permission: DesktopPermission) => void
}

export function createNotificationSettingsStore(): EngineStoreHandle<NotificationSettingsState, NotificationSettingsActions> {
  return defineStore({
    init: (): NotificationSettingsState => ({
      settings: { ...DEFAULT_NOTIFICATION_SETTINGS },
      status: 'loading',
      writable: false,
      revision: -1,
      permission: 'unsupported',
    }),
    actions: {
      sync: (draft, snapshot, permission) => {
        draft.status = snapshot.status
        draft.writable = snapshot.writable
        draft.revision = snapshot.revision ?? draft.revision
        draft.permission = permission
        if (snapshot.value !== undefined) draft.settings = { ...snapshot.value }
      },
      setLocal: (draft, field, value) => {
        Object.assign(draft.settings, { [field]: value })
      },
      setPermission: (draft, permission) => {
        draft.permission = permission
      },
    },
  })
}

type PageNotificationQueueActions = {
  show: (draft: PageNotificationQueueState, item: PageNotificationItem) => void
  dismiss: (draft: PageNotificationQueueState, id: number) => void
}

export function createPageNotificationQueueStore(): EngineStoreHandle<PageNotificationQueueState, PageNotificationQueueActions> {
  return defineStore({
    init: createPageNotificationQueueState,
    actions: {
      show: showPageNotificationInQueue,
      dismiss: dismissPageNotificationInQueue,
    },
  })
}
