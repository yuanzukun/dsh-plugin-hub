/** Edge detector over the global sessions list and pending interactions. Initial hydration is always silent. */

import type {
  SessionListState,
  SessionSummary,
} from '@deepseek-ai/dsh-api-session-controller/client'
import type {
  SessionPendingInteraction,
  SessionPendingInteractionSnapshot,
} from '@deepseek-ai/dsh-client-ui-session/client'
import type { SessionId } from '@deepseek-ai/dsh-session/types'
import type { TurnEndProjection } from '../contracts.ts'

/**
 * User-visible pending interaction kinds. The pending-interaction registry is
 * merge-extensible (`kind: string`), so the detector mirrors the workspace
 * tree's visible-kind filter: only these three ever surface as notification
 * edges, and any future domain kind stays silent until copy exists for it.
 */
export type PendingInteractionStatus = 'approval' | 'plan-review' | 'question'

function visiblePendingKind(interaction: SessionPendingInteraction | undefined): PendingInteractionStatus | undefined {
  switch (interaction?.kind) {
    case 'approval':
    case 'plan-review':
    case 'question':
      return interaction.kind
    default:
      return undefined
  }
}

export type NotificationCandidate = TurnCandidate | InteractionCandidate

export interface CandidateBase {
  sessionId: SessionId
  title: string
  subagent: boolean
}

export interface TurnCandidate extends CandidateBase {
  kind: 'turn'
  end: TurnEndProjection
}

export interface InteractionCandidate extends CandidateBase {
  kind: 'interaction'
  interaction: PendingInteractionStatus
}

interface SeenState {
  turnEndSeq: number
  pendingInteraction: PendingInteractionStatus | undefined
}

function turnEndOf(summary: SessionSummary): TurnEndProjection | null {
  return summary.projectionValues?.windowsNotificationTurnEnd ?? null
}

function seenStateOf(summary: SessionSummary, pending: SessionPendingInteractionSnapshot): SeenState {
  return {
    turnEndSeq: turnEndOf(summary)?.seq ?? -1,
    pendingInteraction: visiblePendingKind(pending.get(summary.id)),
  }
}

/** Stateful transition detector; one instance lives for one browser plugin lifetime. */
export class SessionNotificationDetector {
  private ready = false
  private seen = new Map<SessionId, SeenState>()

  /** Consume immutable list and pending-interaction snapshots and return only newly reached user-visible edges. */
  scan(snapshot: SessionListState, pending: SessionPendingInteractionSnapshot): NotificationCandidate[] {
    if (snapshot.phase !== 'ready') return []

    if (!this.ready) {
      this.ready = true
      this.replaceBaseline(snapshot, pending)
      return []
    }

    const events: NotificationCandidate[] = []
    const live = new Set<SessionId>()
    for (const sessionId of snapshot.ids) {
      const summary = snapshot.byId[sessionId]
      if (summary === undefined) continue
      live.add(sessionId)
      const previous = this.seen.get(sessionId)
      const next = seenStateOf(summary, pending)
      if (previous === undefined) {
        this.seen.set(sessionId, next)
        continue
      }

      const base: CandidateBase = {
        sessionId,
        title: summary.displayTitle,
        subagent: summary.origin === 'subagent',
      }
      const end = turnEndOf(summary)
      if (end !== null && end.seq > previous.turnEndSeq) {
        events.push({ ...base, kind: 'turn', end })
      }
      if (
        next.pendingInteraction !== undefined
        && next.pendingInteraction !== previous.pendingInteraction
      ) {
        events.push({ ...base, kind: 'interaction', interaction: next.pendingInteraction })
      }
      this.seen.set(sessionId, next)
    }

    for (const sessionId of this.seen.keys()) {
      if (!live.has(sessionId)) this.seen.delete(sessionId)
    }
    return events
  }

  private replaceBaseline(snapshot: SessionListState, pending: SessionPendingInteractionSnapshot): void {
    this.seen.clear()
    for (const sessionId of snapshot.ids) {
      const summary = snapshot.byId[sessionId]
      if (summary !== undefined) this.seen.set(sessionId, seenStateOf(summary, pending))
    }
  }
}
