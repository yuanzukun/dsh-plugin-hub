/** Settings-page stylesheet mounted for the plugin fiber lifetime. */

import type { Context as ClientContext } from '@deepseek-ai/cordis'

const PLUGIN_ID = '@lsq64737/dsh-windows-notifications'

const CSS = `
.dsh-win-notify-settings {
  display: flex;
  flex-direction: column;
  max-width: 720px;
  color: var(--dsw-alias-label-primary);
}
.dsh-win-notify-heading {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 16px;
  margin-bottom: 14px;
}
.dsh-win-notify-heading-copy { min-width: 0; }
.dsh-win-notify-title { margin: 0; font-size: 16px; line-height: 24px; font-weight: 500; }
.dsh-win-notify-description,
.dsh-win-notify-row-description,
.dsh-win-notify-hint {
  color: var(--dsw-alias-label-tertiary);
  font-size: 12px;
  line-height: 18px;
}
.dsh-win-notify-description { margin-top: 3px; }
.dsh-win-notify-status {
  flex: none;
  padding: 3px 9px;
  border-radius: 12px;
  background: var(--dsw-alias-bg-module-platform);
  color: var(--dsw-alias-label-secondary);
  font-size: 11px;
  line-height: 16px;
  white-space: nowrap;
}
.dsh-win-notify-status[data-state='granted'] {
  background: var(--dsw-alias-state-success-tertiary);
  color: var(--dsw-alias-state-success-primary);
}
.dsh-win-notify-status[data-state='denied'],
.dsh-win-notify-status[data-state='insecure'],
.dsh-win-notify-status[data-state='unsupported'] {
  color: var(--dsw-alias-state-error-primary);
}
.dsh-win-notify-permission {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  margin: 0 0 8px;
  padding: 10px 12px;
  border-radius: 12px;
  background: var(--dsw-alias-bg-module-platform);
}
.dsh-win-notify-permission-text {
  min-width: 0;
  color: var(--dsw-alias-label-secondary);
  font-size: 12px;
  line-height: 18px;
}
.dsh-win-notify-row {
  display: flex;
  align-items: center;
  gap: 16px;
  min-height: 46px;
  padding: 8px 0;
}
.dsh-win-notify-row + .dsh-win-notify-row {
  border-top: 1px solid var(--dsw-alias-border-l1);
}
.dsh-win-notify-row-copy { flex: 1; min-width: 0; }
.dsh-win-notify-row-title { font-size: 13px; line-height: 20px; }
.dsh-win-notify-switch {
  position: relative;
  flex: none;
  width: 38px;
  height: 22px;
  padding: 0;
  border: none;
  border-radius: 11px;
  background: var(--dsw-static-neutral-bluish-300);
  cursor: pointer;
  transition: background var(--ds-transition-duration) var(--ds-ease-in-out);
}
.dsh-win-notify-switch[aria-checked='true'] {
  background: var(--dsw-alias-state-business-primary);
}
.dsh-win-notify-switch:disabled { cursor: not-allowed; opacity: .45; }
.dsh-win-notify-switch::after {
  content: '';
  position: absolute;
  top: 3px;
  left: 3px;
  width: 16px;
  height: 16px;
  border-radius: 50%;
  background: var(--dsw-static-neutral-00);
  box-shadow: var(--dsw-shadow-lv1);
  transition: transform var(--ds-transition-duration) var(--ds-ease-in-out);
}
.dsh-win-notify-switch[aria-checked='true']::after { transform: translateX(16px); }
.dsh-win-notify-volume {
  display: flex;
  align-items: center;
  gap: 10px;
  width: 190px;
}
.dsh-win-notify-volume input { flex: 1; accent-color: var(--dsw-alias-state-business-primary); }
.dsh-win-notify-volume-value {
  width: 34px;
  color: var(--dsw-alias-label-secondary);
  font-size: 12px;
  text-align: right;
}
.dsh-win-notify-actions { display: flex; flex-wrap: wrap; gap: 8px; margin-top: 14px; }
.dsh-win-notify-disabled { opacity: .58; }
@media (prefers-reduced-motion: reduce) {
  .dsh-win-notify-switch,
  .dsh-win-notify-switch::after { transition: none; }
}
`

/** Install one deduplicated style tag and remove it with the owning plugin. */
export function installSettingsStyles(ctx: ClientContext): void {
  ctx.effect(() => {
    const tag = document.createElement('style')
    tag.dataset.plugin = PLUGIN_ID
    tag.dataset.pluginCss = `${PLUGIN_ID}/settings`
    tag.textContent = CSS
    document.head.appendChild(tag)
    return () => { tag.remove() }
  }, 'windows-notifications: styles')
}
