/** Shared data contract between notification policy, queue state, and presentation. */

import type { SoundKind } from './browser-notifier.ts'

export interface PageNotificationMessage {
  title: string
  body?: string
  kind: SoundKind
  /** Equal non-empty keys replace an unfinished page notification instead of queueing. */
  replaceKey?: string
}
