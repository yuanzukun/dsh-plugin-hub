/** Host half: settings registration plus the durable latest-turn projection. */

import type { Context } from '@deepseek-ai/cordis'
import type {} from '@deepseek-ai/dsh-settings'
import { NOTIFICATION_SETTINGS_NAMESPACE } from './contracts.ts'
import { turnEndProjection } from './projection.ts'
import { NotificationSettingsSchema } from './settings.ts'

export const name = 'windows-notifications'
export const inject = ['settings', 'sessionProjections']

/** Register the two Host capabilities consumed by the browser half. */
export function apply(ctx: Context): void {
  // The namespace is validated at compile time by SettingsNamespaceInput on
  // register's signature (dsh-settings ≥ 0.1.2); the runtime brand helper
  // `settingsNamespace` was removed, so the raw lowercase-kebab string is passed.
  ctx.settings.register(
    NOTIFICATION_SETTINGS_NAMESPACE,
    NotificationSettingsSchema,
  )
  ctx.sessionProjections.register(turnEndProjection)
  ctx.logger.info('windows-notifications: public-package settings and turn outcome projection registered')
}
