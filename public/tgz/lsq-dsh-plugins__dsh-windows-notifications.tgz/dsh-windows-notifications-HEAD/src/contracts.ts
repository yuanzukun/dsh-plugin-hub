/** Shared wire-safe contracts for the Host projection and browser notifier. */

/** Durable settings namespace owned by this plugin. */
export const NOTIFICATION_SETTINGS_NAMESPACE = 'windows-notifications'

/** Session projection key carrying the latest durable turn ending. */
export const TURN_END_PROJECTION_KEY = 'windowsNotificationTurnEnd'

/** Settings persisted by Harness. */
export interface NotificationSettings {
  enabled: boolean
  desktopEnabled: boolean
  toastEnabled: boolean
  soundEnabled: boolean
  soundVolume: number
  onlyWhenInactive: boolean
  notifyCompleted: boolean
  notifyFailed: boolean
  notifyInteraction: boolean
  notifySubagents: boolean
}

/** Scalar settings fields editable by the General settings row. */
export type NotificationSettingField = keyof NotificationSettings

/** Defaults used before Host settings arrive and after a field is reset. */
export const DEFAULT_NOTIFICATION_SETTINGS: Readonly<NotificationSettings> = Object.freeze({
  enabled: true,
  desktopEnabled: true,
  toastEnabled: true,
  soundEnabled: true,
  soundVolume: 0.55,
  onlyWhenInactive: true,
  notifyCompleted: true,
  notifyFailed: true,
  notifyInteraction: true,
  notifySubagents: false,
})

/** Stable built-in turn outcomes emitted by Harness 0.1.1. */
export type TurnOutcome =
  | 'completed'
  | 'aborted'
  | 'blocked'
  | 'error'
  | 'max-tokens'
  | 'interrupted'
  | 'other'

/** Latest durable turn ending, or null before the first turn finishes. */
export interface TurnEndProjection {
  seq: number
  turn: number
  outcome: TurnOutcome
}

declare module '@deepseek-ai/dsh-session-projection/types' {
  interface SessionProjectionMap {
    windowsNotificationTurnEnd: TurnEndProjection | null
  }

  interface SessionProjectionStateMap {
    windowsNotificationTurnEnd: TurnEndProjection | null
  }
}
