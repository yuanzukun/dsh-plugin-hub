/** Durable latest-turn projection used to distinguish completion from interruption and failure. */

import { z } from 'zod'
import type { SessionEvent } from '@deepseek-ai/dsh-session'
import type { ProjectionDefinition } from '@deepseek-ai/dsh-session-projection'
import {
  TURN_END_PROJECTION_KEY,
  type TurnEndProjection,
  type TurnOutcome,
} from './contracts.ts'

const OUTCOMES = [
  'completed', 'aborted', 'blocked', 'error', 'max-tokens', 'interrupted', 'other',
] as const

const TurnEndProjectionSchema = z.object({
  seq: z.number().int().nonnegative(),
  turn: z.number().int().nonnegative(),
  outcome: z.enum(OUTCOMES),
}).nullable()

/** Keep known outcomes stable while folding extension-defined reasons into a safe fallback. */
export function normalizeTurnOutcome(kind: string): TurnOutcome {
  return (OUTCOMES as readonly string[]).includes(kind) ? kind as TurnOutcome : 'other'
}

/** Pure Host projection definition registered once by the plugin. */
type TurnEndProjectionDefinition = Omit<ProjectionDefinition<
  typeof TURN_END_PROJECTION_KEY,
  TurnEndProjection | null
>, 'wire'> & {
  wire: NonNullable<ProjectionDefinition<
    typeof TURN_END_PROJECTION_KEY,
    TurnEndProjection | null
  >['wire']>
}

export const turnEndProjection: TurnEndProjectionDefinition = {
  key: TURN_END_PROJECTION_KEY,
  stateSchema: TurnEndProjectionSchema,
  init: () => null,
  apply: (state, event: SessionEvent) => {
    if (event.type !== 'turn/end') return state
    return {
      seq: event.seq,
      turn: event.data.turn,
      outcome: normalizeTurnOutcome(String(event.data.reason.kind)),
    }
  },
  wire: {
    viewSchema: TurnEndProjectionSchema,
    view: state => state,
  },
  stateVersion: 1,
}
