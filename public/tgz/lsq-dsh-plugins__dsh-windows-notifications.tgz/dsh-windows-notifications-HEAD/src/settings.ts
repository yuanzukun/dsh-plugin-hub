/** Host settings schema. Kept out of the browser entry so Schemastery is not bundled client-side. */

import z from '@deepseek-ai/schemastery'
import {
  DEFAULT_NOTIFICATION_SETTINGS,
  type NotificationSettings,
} from './contracts.ts'

/** Durable settings schema shared through the Harness settings transport. */
export const NotificationSettingsSchema: z<NotificationSettings> = z.object({
  enabled: z.boolean().default(DEFAULT_NOTIFICATION_SETTINGS.enabled),
  desktopEnabled: z.boolean().default(DEFAULT_NOTIFICATION_SETTINGS.desktopEnabled),
  toastEnabled: z.boolean().default(DEFAULT_NOTIFICATION_SETTINGS.toastEnabled),
  soundEnabled: z.boolean().default(DEFAULT_NOTIFICATION_SETTINGS.soundEnabled),
  soundVolume: z.number().min(0).max(1).default(DEFAULT_NOTIFICATION_SETTINGS.soundVolume),
  onlyWhenInactive: z.boolean().default(DEFAULT_NOTIFICATION_SETTINGS.onlyWhenInactive),
  notifyCompleted: z.boolean().default(DEFAULT_NOTIFICATION_SETTINGS.notifyCompleted),
  notifyFailed: z.boolean().default(DEFAULT_NOTIFICATION_SETTINGS.notifyFailed),
  notifyInteraction: z.boolean().default(DEFAULT_NOTIFICATION_SETTINGS.notifyInteraction),
  notifySubagents: z.boolean().default(DEFAULT_NOTIFICATION_SETTINGS.notifySubagents),
})
