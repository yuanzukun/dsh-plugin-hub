# dsh-hiboard-push

把任务完成消息以服务卡片的形式推送到华为鸿蒙**负一屏（智慧助手·今天）**，
由 DeepSeek Harness（dsh）智能体在任务完成后自动调用。与 OpenClaw
[today-task](https://clawhub.com/skills/today-task) 技能完全线级兼容：同一
HIBoard 上传端点、同一负载契约、同一卡片渲染规则——负一屏获取的同一个
authCode 直接可用。

任务完成时，智能体调用 `hiboard_push`，传入任务名称与 Markdown 结果，
卡片即刻出现在手机负一屏的 Today 动态流中。无前端 UI、无额外运行时依赖
（HTTP 使用 Node 内置 `fetch`）。

## 安装

```bash
dsh plugin --profile web add github:Entity-Him/dsh-hiboard-push
```

## 链接教程（负一屏）

把 dsh 接到你手机的负一屏，三步：

### 1. 手机端获取授权码

1. 手机打开负一屏（智慧助手·今天）。
2. 我的 → 动态管理 → 关联账号 → **Claw 智能体** → 获取授权码。
3. 得到一串授权码（形如 `uhIzvTvjwnAD`），**不要外传**。

### 2. 安装插件

```bash
dsh plugin --profile web add github:Entity-Him/dsh-hiboard-push
```

### 3. 终端配置授权码（推荐）

用终端命令写入授权码，配置存放在 `~/.dsh/hiboard-auth.env`（权限 600，
不在设置面板显示），dsh 由 supervisor 拉起时自动注入环境变量：

```bash
dsh-hiboard-auth 你的授权码      # 写入授权码
dsh-hiboard-auth                 # 查看是否已配置（不显示值）
dsh-hiboard-auth -d              # 清除授权码
```

改完重启 dsh 生效。也可以走设置面板（`hiboard-push` 分区，密码框写入，
字段已标 `role(secret)` 脱敏）或环境变量：

```bash
export DSH_HIBOARD_AUTH_CODE=你的授权码
```

### 验证

在 dsh 对话里说：

- 先干跑：`调 hiboard_push 做一个 dry-run 测试`（不真发）。
- 再真发：`调 hiboard_verify`，手机会收到一张「dsh 连接测试」卡片。

手机收到卡片即链接成功。之后任务完成时智能体会自动调 `hiboard_push` 推送。

### 常见问题

- `0000900034` 授权码无效：去手机 负一屏 → 我的 → 动态管理 → 关联账号 →
  Claw 智能体 重新获取，再用 `dsh-hiboard-auth 新码` 更新后重启 dsh。
- 授权码是个人凭证：谁拿到就能往你的负一屏推卡片，别发群里、别提交到仓库。
## 使用

插件注册两个工具：

### `hiboard_push`

| 参数          | 必填 | 说明                                                |
|---------------|------|-----------------------------------------------------|
| `name`        | ✅   | 任务名称；卡片标题、`scheduleTaskName` 与 `summary`。|
| `content`     | ✅   | Markdown 正文（≤ 5000 字符），卡片上原样渲染。      |
| `result`      | ❌   | 结果摘要 / 状态标签。默认：`任务已完成`。            |
| `schedule_id` | ❌   | 周期任务 ID；周期任务保持同一 ID 以便分组展示。     |
| `dry_run`     | ❌   | 仅构造并校验负载，不真正发送（无需 authCode）。     |

卡片样式由填充字段决定（与 today-task 一致）：

- **标准任务卡片** —— `name` + `content` + `result`。
- **周期任务卡片** —— 同标准卡片，另加 `schedule_id`。
- **仅摘要卡片** —— `name` + `result`，无 `content`。

### `hiboard_verify`

向手机发送一张最小的真实连接测试卡片，用于端到端确认 authCode 与网络链路。

## 接口契约（参考）

- 端点：`POST https://hiboard-claw-drcn.ai.dbankcloud.cn/distribution/message/cloud/claw/msg/upload`
- 请求头：`Content-Type: application/json; charset=utf-8`、
  `x-trace-id: task-push-<yyyyMMddHHmmss>`
- 请求体：

```json
{
  "data": {
    "authCode": "<authCode>",
    "msgContent": [
      {
        "msgId": "dsh_<epoch-sec>_<rand>",
        "scheduleTaskId": "",
        "scheduleTaskName": "任务名称",
        "summary": "任务名称",
        "result": "任务已完成",
        "content": "# Markdown",
        "source": "OpenClaw",
        "taskFinishTime": 1710000000
      }
    ]
  }
}
```

- 成功：HTTP 200 且 `"code": "0000000000"`。
- `"code": "0000900034"` 表示授权码无效。

## 开发

```bash
node --test test/core.test.mjs
```

## 许可

MIT
