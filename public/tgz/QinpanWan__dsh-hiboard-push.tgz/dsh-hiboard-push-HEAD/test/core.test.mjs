import assert from "node:assert/strict";
import { test } from "node:test";
import { parameterSchemaSpecToJsonSchema } from "@deepseek-ai/dsh-tools";
import {
	apply,
	buildPayload,
	normalizeContent,
	sendPush,
	validatePush
} from "../lib/index.js";

// ---------------------------------------------------------------- payload

test("buildPayload matches the HIBoard wire contract", () => {
	const payload = buildPayload({
		authCode: "test-code",
		name: "开发日报",
		content: "# 今日工作",
		result: "3 项完成",
		scheduleId: "weekly_report"
	});
	assert.deepEqual(Object.keys(payload), ["data"]);
	const inner = payload.data;
	assert.equal(inner.authCode, "test-code");
	assert.ok(Array.isArray(inner.msgContent) && inner.msgContent.length === 1);
	const msg = inner.msgContent[0];
	assert.equal(msg.scheduleTaskName, "开发日报");
	assert.equal(msg.summary, "开发日报");
	assert.equal(msg.result, "3 项完成");
	assert.equal(msg.content, "# 今日工作");
	assert.equal(msg.source, "OpenClaw");
	assert.equal(msg.scheduleTaskId, "weekly_report");
	assert.match(msg.msgId, /^dsh_\d+_/);
	assert.equal(typeof msg.taskFinishTime, "number");
	assert.ok(msg.taskFinishTime > 1_600_000_000);
});

test("empty scheduleId yields one-off card", () => {
	const payload = buildPayload({ authCode: "c", name: "n", content: "x", result: "r", scheduleId: "" });
	assert.equal(payload.data.msgContent[0].scheduleTaskId, "");
});

// ---------------------------------------------------------------- normalize

test("normalizeContent unescapes JSON-style escapes", () => {
	assert.equal(normalizeContent("a\\nb"), "a\nb");
	assert.equal(normalizeContent("a\\tb"), "a\tb");
	assert.equal(normalizeContent("\\\"q\\\""), "\"q\"");
	assert.equal(normalizeContent("  padded  "), "padded");
	assert.equal(normalizeContent("real\nnewline"), "real\nnewline");
	assert.equal(normalizeContent(undefined), "");
});

// ---------------------------------------------------------------- validate

test("validatePush flags empty name/content and oversized content", () => {
	assert.deepEqual(validatePush({ name: "  ", content: "  ", maxContentLength: 5000 }).length, 2);
	assert.deepEqual(validatePush({ name: "ok", content: "ok", maxContentLength: 5000 }), []);
	const big = "x".repeat(5001);
	assert.ok(validatePush({ name: "ok", content: big, maxContentLength: 5000 }).some(p => p.includes("长度限制")));
	assert.equal(validatePush({ name: "ok", content: "ok", result: "  ", maxContentLength: 5000 }).length, 1);
});

// ---------------------------------------------------------------- wire

test("sendPush reports success code 0000000000 as success", async () => {
	const orig = globalThis.fetch;
	const calls = [];
	globalThis.fetch = async (url, init) => {
		calls.push({ url, headers: init.headers, body: JSON.parse(init.body) });
		return { ok: true, status: 200, text: async () => JSON.stringify({ code: "0000000000" }) };
	};
	try {
		const out = await sendPush("https://example.invalid/upload", { data: {} }, { timeoutMs: 1000 });
		assert.equal(out.success, true);
		assert.equal(out.code, "0000000000");
		assert.equal(calls.length, 1);
		assert.equal(calls[0].headers["x-trace-id"].startsWith("task-push-"), true);
	} finally {
		globalThis.fetch = orig;
	}
});

test("sendPush maps authCode-invalid error hint", async () => {
	const orig = globalThis.fetch;
	globalThis.fetch = async () => ({ ok: true, status: 200, text: async () => JSON.stringify({ code: "0000900034", message: "authCode is invalid" }) });
	try {
		const out = await sendPush("https://example.invalid/upload", { data: {} }, { timeoutMs: 1000 });
		assert.equal(out.success, false);
		assert.match(out.message, /授权码无效/);
	} finally {
		globalThis.fetch = orig;
	}
});

test("sendPush surfaces HTTP errors and network failures", async () => {
	const orig = globalThis.fetch;
	globalThis.fetch = async () => ({ ok: false, status: 500, text: async () => "boom" });
	try {
		const out = await sendPush("https://example.invalid/upload", { data: {} }, { timeoutMs: 1000 });
		assert.equal(out.success, false);
		assert.match(out.message, /HTTP 500/);
	} finally {
		globalThis.fetch = orig;
	}
	globalThis.fetch = async () => { throw new TypeError("fetch failed"); };
	try {
		const out = await sendPush("https://example.invalid/upload", { data: {} }, { timeoutMs: 1000 });
		assert.equal(out.success, false);
		assert.match(out.message, /网络错误/);
	} finally {
		globalThis.fetch = orig;
	}
});

// ---------------------------------------------------------------- schema

test("tool parameter schema compiles with required flags", () => {
	const { byName } = defineToolHarness();
	const tool = byName("hiboard_push");
	assert.ok(tool, "hiboard_push registered");
	assert.ok(tool.parameters.required.includes("name"));
	assert.ok(tool.parameters.required.includes("content"));
	assert.equal(tool.parameters.properties.schedule_id.type, "string");
	assert.equal(tool.parameters.properties.dry_run.type, "boolean");
});

// ---------------------------------------------------------------- apply

function defineToolHarness() {
	// Mirror the public registry path: apply() registers via ctx.tools.register(defineTool(...)).
	const registered = [];
	const ctx = {
		tools: {
			register: (tool) => {
				registered.push(tool);
			}
		},
		inject: () => {}, // settings service absent → installSettingsSection no-ops (designed behavior)
		logger: {
			info: () => {}
		}
	};
	apply(ctx, { authCode: "" });
	assert.ok(registered.length >= 2, "expected tools to be registered");
	const byName = (n) => registered.find((t) => t.name === n);
	return { byName, registered };
}

test("apply registers a runnable tool with dry-run and missing-auth paths", async () => {
	const { byName } = defineToolHarness();
	const tool = byName("hiboard_push");
	const dryRun = await tool.execute(
		{ name: "日报", content: "# 完成事项\n- 重构\n- 测试", result: "2 项完成", dry_run: true },
		{ signal: undefined }
	);
	assert.equal(dryRun.success, true);
	assert.equal(dryRun.dryRun, true);
	assert.equal(dryRun.taskName, "日报");

	await assert.rejects(
		tool.execute({ name: "日报", content: "# 内容" }, { signal: undefined }),
		/未配置授权码/
	);

	await assert.rejects(
		tool.execute({ name: "", content: "", dry_run: true }, { signal: undefined }),
		/不能为空/
	);
});

test("apply resolves authCode from env fallback", async () => {
	process.env.DSH_HIBOARD_AUTH_CODE = "env-code";
	try {
		const { byName } = defineToolHarness();
		const tool = byName("hiboard_push");
		const out = await tool.execute({ name: "t", content: "c", dry_run: true }, { signal: undefined });
		assert.equal(out.dryRun, true); // dry-run path short-circuits before network
	} finally {
		delete process.env.DSH_HIBOARD_AUTH_CODE;
	}
});

test("payload JSON serializes with the exact camelCase field names", () => {
	const payload = buildPayload({ authCode: "a", name: "n", content: "c", result: "r", scheduleId: "" });
	const raw = JSON.stringify(payload);
	for (const key of ["authCode", "msgContent", "msgId", "scheduleTaskId", "scheduleTaskName", "summary", "result", "content", "source", "taskFinishTime"]) {
		assert.ok(raw.includes(`"${key}"`), `missing ${key}`);
	}
});
