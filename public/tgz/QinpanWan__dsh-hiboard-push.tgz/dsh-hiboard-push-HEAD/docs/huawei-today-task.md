# 华为负一屏 Today-Task 机制说明

本插件对标 OpenClaw 的 `today-task` skill（ClawHub 版本 1.0.17，2026-04 上线），
并交叉核对了第三方 Rust 兼容实现 [lichtcui/hwpush](https://github.com/lichtcui/hwpush)
与 today-task 官方包源码（`config.json` / `hiboards_client.py` / `task_pusher.py`）。

## 机制

- 华为负一屏「智慧助手·今天」提供 Today-Task 能力：第三方智能体（Claw/OpenClaw、
  dsh）通过 AGC 关联账号后获得 `authCode`，将任务结果以标准负载推送到 HIBoard
  云侧，负一屏以服务卡片展示任务进度与结果。
- authCode 获取路径：负一屏 → 我的 → 动态管理 → 关联账号 → Claw 智能体。
- 官方 skill 要求推送只走 JSON 输入（`task_push.py --data task.json`），以保证
  Markdown 100% 保留；本插件在 dsh 侧直接以工具参数承载同一契约。

## 契约要点（three 实现一致）

| 项 | 值 |
|---|---|
| 端点 | `https://hiboard-claw-drcn.ai.dbankcloud.cn/distribution/message/cloud/claw/msg/upload` |
| 负载外层 | `{ "data": { "authCode", "msgContent": [...] } }` |
| msgContent 必填字段 | `msgId, scheduleTaskId, scheduleTaskName, summary, result, content, source, taskFinishTime` |
| `source` | 固定 `"OpenClaw"`（后端按此值品牌化渲染） |
| 内容上限 | 5000 字符 |
| 成功码 | `0000000000`（官方客户端亦接受 `0`） |
| authCode 无效码 | `0000900034` / `The authCode is invalid` |
| 默认结果文案 | `任务已完成` |
| 请求头 | `Content-Type: application/json; charset=utf-8`、`x-trace-id: task-push-<时间戳>` |

## 卡片样式

| 类型 | 填充字段 | 效果 |
|---|---|---|
| 标准任务卡片 | `name` + content + result | 标题栏 + 状态标签 + 完整 Markdown 正文 |
| 周期任务卡片 | 同上 + `scheduleTaskId` | 与标准一致，可分组重复展示 |
| 仅摘要卡片 | `name` + result（无 content） | 紧凑卡片，无可展开正文 |

## 验证记录

- 2026-08-23：协议冒烟（无效 authCode → `0000900034`，证明负载形状正确）；
  使用真实 authCode 端到端推送 → `0000000000` 成功，手机负一屏收到测试卡片。
