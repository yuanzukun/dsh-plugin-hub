/**
 * dsh-jimeng —— 设置分区「即梦生图」(client 半边)。
 *
 * 以 dsh.client bundle 格式加载(与 dsh-meme 同款):注册 settings.section
 * 「即梦生图」分区,渲染可编辑的 API 配置(火山方舟 Ark Key / baseUrl / 模型 /
 * 尺寸 / 水印 / 保存目录)+ 手动生图面板(文生图 / 图生图)。
 * 数据走 host 的 HTTP API(/dsh-jimeng/api/*),API Key 只在 host 保存。
 * 注册 id 必须等于 loader entry 名(dsh-jimeng)。
 */
window.__ModuleLoader__.load({
  id: 'dsh-jimeng',
  factory: (require) => {
    var module = { exports: {} }
    var exports = module.exports
    Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' })

    const React = require('react')

    const CSS = [
      '.jimeng-panel{display:flex;flex-direction:column;gap:16px;padding:4px 0;font-size:13px;color:var(--dsw-alias-label-primary)}',
      '.jimeng-panel .card{border:1px solid var(--dsw-alias-border-l1);border-radius:12px;background:var(--dsw-alias-bg-layer-1);padding:14px;display:flex;flex-direction:column;gap:10px}',
      '.jimeng-panel .card-title{font-size:13px;font-weight:600;margin:0;display:flex;align-items:center;gap:8px}',
      '.jimeng-panel .hint{font-size:12px;color:var(--dsw-alias-label-secondary);line-height:1.5}',
      '.jimeng-panel .field{display:flex;flex-direction:column;gap:5px}',
      '.jimeng-panel .field label{font-size:11px;color:var(--dsw-alias-label-secondary)}',
      '.jimeng-panel .row{display:flex;gap:10px;flex-wrap:wrap}',
      '.jimeng-panel .row .grow{flex:1;min-width:180px}',
      '.jimeng-panel input[type=text],.jimeng-panel input[type=password],.jimeng-panel select,.jimeng-panel textarea{background:var(--dsw-alias-bg-layer-2);color:var(--dsw-alias-label-primary);border:1px solid var(--dsw-alias-border-l1);border-radius:8px;padding:7px 10px;font-size:13px;outline:none;transition:border-color .12s ease;box-sizing:border-box;width:100%}',
      '.jimeng-panel input:focus,.jimeng-panel select:focus,.jimeng-panel textarea:focus{border-color:var(--dsw-alias-brand-primary)}',
      '.jimeng-panel textarea{resize:vertical;font-family:inherit;min-height:80px}',
      '.jimeng-panel button{background:var(--dsw-alias-bg-layer-2);color:var(--dsw-alias-label-primary);border:1px solid var(--dsw-alias-border-l1);border-radius:8px;padding:7px 14px;font-size:13px;cursor:pointer;transition:border-color .12s ease,background .12s ease}',
      '.jimeng-panel button:hover{border-color:var(--dsw-alias-brand-primary)}',
      '.jimeng-panel button:disabled{opacity:.5;cursor:default}',
      '.jimeng-panel .btn-primary{background:var(--dsw-alias-button-primary-fill);border-color:var(--dsw-alias-button-primary-fill);color:var(--dsw-alias-label-primary-foreground)}',
      '.jimeng-panel .btn-primary:hover{background:var(--dsw-alias-button-primary-hover);border-color:var(--dsw-alias-button-primary-hover)}',
      '.jimeng-panel .switch{position:relative;width:38px;height:20px;border-radius:999px;background:var(--dsw-alias-border-l1);cursor:pointer;transition:background .15s ease;flex:none;display:inline-block}',
      '.jimeng-panel .switch::after{content:"";position:absolute;top:2px;left:2px;width:16px;height:16px;border-radius:50%;background:#fff;box-shadow:0 1px 3px rgba(0,0,0,.2);transition:transform .15s ease}',
      '.jimeng-panel .switch.on{background:var(--dsw-alias-brand-primary)}',
      '.jimeng-panel .switch.on::after{transform:translateX(18px)}',
      '.jimeng-panel .notice{padding:8px 12px;border-radius:8px;font-size:12px;background:var(--dsw-alias-bg-layer-2);border:1px solid var(--dsw-alias-border-l1);color:var(--dsw-alias-label-secondary)}',
      '.jimeng-panel .notice.ok{color:var(--dsw-alias-brand-primary);border-color:var(--dsw-alias-brand-primary)}',
      '.jimeng-panel .error{color:#e5484d;font-size:12px;padding:8px 12px;border-radius:8px;background:color-mix(in srgb,#e5484d 10%,transparent)}',
      '.jimeng-panel .mode-tabs{display:flex;gap:6px;background:var(--dsw-alias-bg-layer-2);border:1px solid var(--dsw-alias-border-l1);border-radius:8px;padding:3px;width:fit-content}',
      '.jimeng-panel .mode-tab{border:none;background:transparent;padding:5px 12px;border-radius:6px;cursor:pointer;font-size:12px;color:var(--dsw-alias-label-secondary)}',
      '.jimeng-panel .mode-tab.on{background:var(--dsw-alias-button-primary-fill);color:var(--dsw-alias-label-primary-foreground)}',
      // ---- 多图参考图条(手动生图面板) ----
      '.jimeng-panel .refs{display:flex;gap:8px;flex-wrap:wrap}',
      '.jimeng-panel .ref-chip{position:relative;width:62px;height:62px;border-radius:8px;overflow:hidden;border:1px solid var(--dsw-alias-border-l1);background:var(--dsw-alias-bg-layer-2);flex:none}',
      '.jimeng-panel .ref-chip img{width:100%;height:100%;object-fit:cover;display:block}',
      '.jimeng-panel .ref-chip .ref-unknown{display:flex;align-items:center;justify-content:center;height:100%;font-size:10px;color:var(--dsw-alias-label-secondary)}',
      '.jimeng-panel .ref-chip .ref-x{position:absolute;top:2px;right:2px;width:17px;height:17px;line-height:15px;text-align:center;border-radius:50%;background:rgba(0,0,0,.62);color:#fff;font-size:12px;cursor:pointer;border:none;padding:0;font-family:inherit}',
      '.jimeng-panel .ref-chip .ref-n{position:absolute;left:2px;bottom:2px;font-size:10px;line-height:14px;padding:0 4px;border-radius:4px;background:rgba(0,0,0,.62);color:#fff}',
      '.jimeng-panel .ref-count{font-size:11px;color:var(--dsw-alias-label-secondary)}',
      '.jimeng-panel .ref-count.warn{color:#e5484d}',
      '.jimeng-panel .result-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:12px}',
      '.jimeng-panel .result-card{border:1px solid var(--dsw-alias-border-l1);border-radius:10px;overflow:hidden;background:var(--dsw-alias-bg-layer-1)}',
      '.jimeng-panel .result-card img{width:100%;height:auto;display:block;background:var(--dsw-alias-bg-base)}',
      '.jimeng-panel .result-card .meta{padding:7px 10px;font-size:11px;color:var(--dsw-alias-label-secondary);word-break:break-all}',
      '.jimeng-panel .result-card a{color:var(--dsw-alias-brand-primary);text-decoration:none}',
      // ---- 工具卡图片预览(generate_image / image_to_image 的结果卡) ----
      '.jimeng-view{display:flex;flex-direction:column;gap:8px;padding:2px 0}',
      '.jimeng-view .view-row{display:flex;gap:8px;flex-wrap:wrap}',
      '.jimeng-view .view-card{border:1px solid var(--dsw-alias-border-l1);border-radius:10px;background:var(--dsw-alias-bg-layer-1);padding:8px;display:flex;flex-direction:column;gap:6px;width:fit-content;max-width:100%}',
      '.jimeng-view .view-imgwrap{display:flex;align-items:center;justify-content:center;background:var(--dsw-alias-bg-base);border-radius:6px;overflow:hidden}',
      '.jimeng-view .view-img{display:block;max-width:100%;border-radius:6px;cursor:zoom-in}',
      '.jimeng-view .view-loading{font-size:12px;color:var(--dsw-alias-label-secondary);padding:10px;display:flex;align-items:center;justify-content:center}',
      '.jimeng-view button.view-loading{background:transparent;border:1px dashed var(--dsw-alias-border-l1);border-radius:6px;cursor:pointer;font-family:inherit}',
      '.jimeng-view .view-meta{display:flex;align-items:center;gap:10px;font-size:11px;color:var(--dsw-alias-label-secondary);flex-wrap:wrap}',
      '.jimeng-view .view-meta button{background:transparent;border:1px solid var(--dsw-alias-border-l1);color:var(--dsw-alias-label-secondary);border-radius:6px;padding:2px 8px;font-size:11px;cursor:pointer;font-family:inherit}',
      '.jimeng-view .view-meta button:hover{border-color:var(--dsw-alias-brand-primary);color:var(--dsw-alias-label-primary)}',
      '.jimeng-view .view-meta a{color:var(--dsw-alias-brand-primary);text-decoration:none}',
      '.jimeng-view .view-path{font-size:11px;font-family:ui-monospace,Consolas,monospace;color:var(--dsw-alias-label-secondary);word-break:break-all;white-space:pre-wrap}',
      '.jimeng-view .view-lightbox{position:fixed;inset:0;z-index:2147483000;background:rgba(0,0,0,.78);display:flex;align-items:center;justify-content:center;cursor:zoom-out}',
      '.jimeng-view .view-lightbox img{max-width:94vw;max-height:94vh;border-radius:8px;box-shadow:0 12px 48px rgba(0,0,0,.5)}',
      '.jimeng-view .view-row-line{display:flex;align-items:baseline;gap:8px;cursor:pointer;user-select:none;line-height:1.5}',
      '.jimeng-view .view-caret{color:var(--dsw-alias-label-secondary);font-size:10px;width:10px;flex:none}',
      '.jimeng-view .view-prompt{font-size:12px;color:var(--dsw-alias-label-secondary);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:100%}',
      '.jimeng-view .view-output{font-size:12px;color:var(--dsw-alias-label-secondary);white-space:pre-wrap;word-break:break-word;margin-top:6px;padding:8px 10px;border-radius:8px;background:var(--dsw-alias-bg-layer-2)}',
      '.jimeng-view .view-error{font-size:12px;color:#e5484d;white-space:pre-wrap;word-break:break-word;margin-top:6px}',
      '.jimeng-view .view-dot{width:6px;height:6px;border-radius:50%;background:var(--dsw-alias-brand-primary);flex:none;animation:jimeng-view-pulse 1s ease-in-out infinite}',
      '@keyframes jimeng-view-pulse{0%,100%{opacity:.25}50%{opacity:1}}',
    ].join('')

    const api = async (path, opts) => {
      const resp = await fetch(path, opts || {})
      const json = await resp.json()
      return json
    }

    /** 参考图张数上限,与 host 侧 MAX_REF_IMAGES 一致(火山方舟实测:>10 张报 400)。 */
    const MAX_REFS = 10

    // ================= 工具卡图片预览 =================
    // 为什么需要它:generate_image / image_to_image 的结果 content 是
    // [text(JSON), image(attachment)]，但内置的图片卡只认 read_image 这一个工具名，
    // 其它工具的图片块会退化成通用卡 —— 把整个 attachment 对象 JSON.stringify 成文字
    // 印在「输出」里。这里给这两个工具名注册专属 toolview，把 image 块里的附件引用
    // 交给会话授权的 loadImage 解析成真实 URL，直接渲染在消息里。

    /** 只取 image 块的 attachment 引用：逐字段判类型，不整体序列化工具结果。 */
    function imageRefsFromContent(content) {
      const out = []
      if (!Array.isArray(content)) return out
      for (const block of content) {
        if (!block || block.type !== 'image') continue
        const a = block.attachment
        if (!a || typeof a !== 'object') continue
        if (typeof a.attachmentId !== 'string' || a.attachmentId === '') continue
        if (typeof a.mediaType !== 'string') continue
        if (typeof a.bytes !== 'number' || typeof a.width !== 'number' || typeof a.height !== 'number') continue
        const ref = { attachmentId: a.attachmentId, mediaType: a.mediaType, bytes: a.bytes, width: a.width, height: a.height }
        if (typeof a.name === 'string') ref.name = a.name
        out.push(ref)
      }
      return out
    }

    /** 结果文本里列出的本地文件路径（host 侧写的是「- <绝对路径>」）。 */
    function imageResultPaths(content) {
      const out = []
      if (!Array.isArray(content)) return out
      for (const block of content) {
        if (!block || block.type !== 'text' || typeof block.text !== 'string') continue
        for (const line of block.text.split('\n')) {
          const m = /^\s*-\s+([A-Za-z]:[\\/][^\r\n]+|\/[^\r\n]+)$/.exec(line)
          if (m) out.push(m[1].trim())
        }
      }
      return out
    }

    function fmtImageBytes(n) {
      if (typeof n !== 'number' || n <= 0) return ''
      if (n < 1024) return n + ' B'
      if (n < 1024 * 1024) return (n / 1024).toFixed(1) + ' KB'
      return (n / 1024 / 1024).toFixed(2) + ' MB'
    }

    /** 单张图：懒加载 → 就绪显示（点击看大图）/ 失败可重试。 */
    function JimengThumb(props) {
      const h = React.createElement
      const { attachment: ref, loadImage, onOpen } = props
      const [state, setState] = React.useState({ url: null, error: false, attempt: 0 })

      React.useEffect(() => {
        if (typeof loadImage !== 'function') {
          setState(s => ({ url: null, error: true, attempt: s.attempt }))
          return undefined
        }
        let live = true
        setState(s => ({ url: null, error: false, attempt: s.attempt }))
        Promise.resolve(loadImage(ref)).then(url => {
          if (!live) return
          const ok = typeof url === 'string' && url !== ''
          setState(s => ({ url: ok ? url : null, error: !ok, attempt: s.attempt }))
        }).catch(() => {
          if (live) setState(s => ({ url: null, error: true, attempt: s.attempt }))
        })
        return () => { live = false }
      }, [ref.attachmentId, state.attempt])

      const ratio = Math.max(1, ref.width) / Math.max(1, ref.height)
      const boxW = ratio >= 1 ? 260 : Math.round(260 * ratio)
      const boxH = ratio >= 1 ? Math.round(260 / ratio) : 260
      const name = typeof ref.name === 'string' && ref.name ? ref.name : 'jimeng.png'

      let body
      if (state.error) {
        body = h('button', {
          type: 'button', className: 'view-loading',
          style: { width: boxW + 'px', height: boxH + 'px', cursor: 'pointer' },
          onClick: () => setState(s => ({ url: null, error: false, attempt: s.attempt + 1 })),
        }, '图片加载失败，点此重试')
      } else if (state.url === null) {
        body = h('div', { className: 'view-loading', style: { width: boxW + 'px', height: boxH + 'px' } }, '加载中…')
      } else {
        body = h('img', {
          className: 'view-img', src: state.url, alt: name,
          style: { maxWidth: boxW + 'px', maxHeight: boxH + 'px' },
          title: '点击查看大图',
          onClick: () => onOpen(state.url, name),
        })
      }

      const meta = [
        h('span', { key: 'dim' },
          ref.mediaType.replace('image/', '').toUpperCase() + ' · ' + ref.width + '×' + ref.height
          + (fmtImageBytes(ref.bytes) ? ' · ' + fmtImageBytes(ref.bytes) : '')),
      ]
      if (state.url !== null) {
        meta.push(h('a', { key: 'dl', href: state.url, download: name }, '下载'))
        meta.push(h('button', {
          key: 'copy', type: 'button',
          onClick: () => {
            try {
              const nav = typeof navigator === 'undefined' ? undefined : navigator
              if (nav && nav.clipboard && nav.clipboard.writeText) nav.clipboard.writeText(state.url)
            } catch { /* 剪贴板不可用则忽略 */ }
          },
        }, '复制链接'))
      }

      return h('div', { className: 'view-card' }, [
        h('div', { className: 'view-imgwrap', key: 'wrap' }, body),
        h('div', { className: 'view-meta', key: 'meta' }, meta),
      ])
    }

    /** 大图浮层：点击任意处或按 ESC 关闭。 */
    function JimengLightbox(props) {
      const h = React.createElement
      const { url, name, onClose } = props
      React.useEffect(() => {
        if (typeof document === 'undefined') return undefined
        const onKey = e => { if (e && e.key === 'Escape') onClose() }
        document.addEventListener('keydown', onKey)
        return () => document.removeEventListener('keydown', onKey)
      }, [])
      return h('div', { className: 'view-lightbox', onClick: () => onClose() },
        h('img', { src: url, alt: name }))
    }

    /** 工具卡上显示的工具名（生成用词，不是 wire 名）。 */
    function jimengTitle(toolName) {
      if (toolName === 'generate_image') return '生成图片'
      if (toolName === 'image_to_image') return '图生图'
      return toolName || '即梦生图'
    }

    /** 参数 JSON 里的字段（obsolete/半截日志一律兜底，不抛）。 */
    function jimengArgs(block) {
      try {
        const raw = block && block.call && typeof block.call.argsRaw === 'string' ? block.call.argsRaw : ''
        if (!raw) return {}
        const parsed = JSON.parse(raw)
        return parsed && typeof parsed === 'object' ? parsed : {}
      } catch {
        return {}
      }
    }

    /** 结果文本全部拼起来（错误信息、模型可见的输出）。 */
    function imageResultText(content) {
      if (!Array.isArray(content)) return ''
      const parts = []
      for (const block of content) {
        if (block && block.type === 'text' && typeof block.text === 'string') parts.push(block.text)
      }
      return parts.join('\n')
    }

    /**
     * generate_image / image_to_image 的工具卡视图。
     *
     * 注册即接管：keyed 槽一旦命中本条目就会渲染本组件，owner 的 fallback 不再生效，
     * 所以这里必须自己覆盖所有状态（运行中 / 失败 / 无图片块 / 有图片），
     * 不能靠 return null 把某些形态交回通用卡 —— 那会渲染成一片空白。
     * 有图片块时走与内置 read_image 图片卡同一条通路：附件引用 + 会话授权的 loadImage。
     */
    function JimengImageView(props) {
      const h = React.createElement
      const { block, toolName, loadImage } = props
      const isResult = !!block && typeof block === 'object' && block.kind === 'tool-result'
      const args = jimengArgs(block)
      const prompt = typeof args.prompt === 'string' ? args.prompt : ''
      const content = isResult ? block.content : undefined
      const refs = isResult ? imageRefsFromContent(content) : []
      const text = isResult ? imageResultText(content) : ''

      // 有图默认展开（看图是这行的目的）；其余状态折叠，点行展开。
      const [open, setOpen] = React.useState(refs.length > 0)
      const [opened, setOpened] = React.useState(null)
      const toggle = () => setOpen(v => !v)

      const running = !isResult
      const failed = isResult && !!block.isError
      const hasDetail = failed || text !== '' || refs.length > 0
      const summary = failed
        ? (text.split('\n')[0] || '调用失败')
        : (refs.length > 0
          ? ('已生成 ' + refs.length + ' 张')
          : (prompt ? prompt : (text.split('\n')[0] || '')))
      const files = isResult ? imageResultPaths(content) : []

      const head = h('div', {
        className: 'view-row-line',
        key: 'head',
        onClick: hasDetail ? toggle : undefined,
      }, [
        h('span', { className: 'view-caret', key: 'caret' }, hasDetail ? (open ? '▾' : '▸') : ''),
        h('span', { className: 'view-title', key: 'title' }, jimengTitle(toolName)),
        running
          ? h('span', { className: 'view-dot', key: 'dot' })
          : h('span', {
            className: 'view-prompt',
            key: 'sum',
            style: failed ? { color: '#e5484d' } : undefined,
            title: summary,
          }, summary),
      ])

      const children = [head]

      if (open) {
        if (failed) {
          children.push(h('div', { className: 'view-error', key: 'err' }, text || '调用失败'))
        } else if (refs.length > 0) {
          if (prompt) children.push(h('div', { className: 'view-prompt', key: 'prompt' }, prompt))
          children.push(h('div', { className: 'view-row', key: 'row' },
            refs.map((ref, i) => h(JimengThumb, {
              key: String(ref.attachmentId) + ':' + i,
              attachment: ref,
              loadImage,
              onOpen: (url, name) => setOpened({ url, name }),
            }))))
          if (files.length > 0) {
            children.push(h('div', { className: 'view-path', key: 'paths' }, files.join('\n')))
          }
        } else if (text !== '') {
          children.push(h('div', { className: 'view-output', key: 'out' }, text))
        }
      }

      if (opened) {
        children.push(h(JimengLightbox, {
          key: 'lightbox', url: opened.url, name: opened.name,
          onClose: () => setOpened(null),
        }))
      }
      return h('div', { className: 'jimeng-view' }, children)
    }

    /** URL 参考图的小缩略图:加载失败就退回「URL」文字,不留破图。 */
    function UrlRefChip(props) {
      const h = React.createElement
      const { url, index, onRemove } = props
      const [bad, setBad] = React.useState(false)
      return h('div', { className: 'ref-chip', title: url }, [
        bad
          ? h('div', { className: 'ref-unknown' }, 'URL')
          : h('img', { src: url, alt: 'URL', onError: () => setBad(true) }),
        h('span', { className: 'ref-n' }, '图' + index),
        h('button', { className: 'ref-x', title: '移除', onClick: onRemove }, '×'),
      ])
    }

    const modeTabs = [
      { key: 't2i', label: '文生图' },
      { key: 'i2i', label: '图生图' },
    ]

    const CURATED_MODELS = [
      'doubao-seedream-4-0-250828',
      'doubao-seedream-3-0-t2i-250415',
      'doubao-seedream-3-0-i2i-250415',
      'doubao-seededit-3-0-i2i-250628',
      'doubao-seedream-2-1-t2i-250828',
      'doubao-seedream-2-1-i2i-250828',
    ]

    // 模型下拉:<select> 固定列出(内置 + 检测到的生图模型),另有「自定义…」展开文本框手动填。
    function ModelField({ label, value, onChange, detected, placeholder }) {
      const h = React.createElement
      const opts = [...new Set([...CURATED_MODELS, ...(detected || [])])]
      const [custom, setCustom] = React.useState(value != null && value !== '' && opts.indexOf(value) === -1)
      const selValue = custom ? '__custom__' : (value || '')
      return h('div', { className: 'field' }, [
        h('label', null, label),
        h('select', {
          value: selValue,
          onChange: e => {
            if (e.target.value === '__custom__') { setCustom(true); onChange('') }
            else { setCustom(false); onChange(e.target.value) }
          },
        }, [
          h('option', { value: '' }, placeholder || '选择模型…'),
          ...opts.map(m => h('option', { key: m, value: m }, m)),
          h('option', { value: '__custom__' }, '自定义…'),
        ]),
        custom ? h('input', {
          type: 'text', value: value || '',
          placeholder: '输入模型名或接入点 ID (ep-xxx)',
          onChange: e => onChange(e.target.value),
        }) : null,
      ])
    }

    function JimengPanel() {
      const [loaded, setLoaded] = React.useState(false)
      const [config, setConfig] = React.useState(null)
      const [draft, setDraft] = React.useState({ apiKey: '' })
      const [busy, setBusy] = React.useState(false)
      const [notice, setNotice] = React.useState('')
      const [error, setError] = React.useState('')

      const [mode, setMode] = React.useState('t2i')
      const [prompt, setPrompt] = React.useState('')
      const [refFiles, setRefFiles] = React.useState([])      // 本地参考图(可多选):[{ id, name, dataUrl }]
      const [refUrlText, setRefUrlText] = React.useState('')  // URL 参考图:每行一个
      const [size, setSize] = React.useState('')
      const [result, setResult] = React.useState(null)
      const [detected, setDetected] = React.useState([])
      const [detectMsg, setDetectMsg] = React.useState('')

      const loadConfig = async () => {
        try {
          const r = await api('/dsh-jimeng/api/config')
          if (r && r.ok) {
            setConfig(r.config)
            setDraft({ ...r.config, apiKey: '' })
            if (!size && r.config.size) setSize(r.config.size)
          }
        } catch (e) { /* 首次加载失败静默,交互时报错 */ }
        setLoaded(true)
      }

      React.useEffect(() => { loadConfig() }, [])

      const set = (k, v) => setDraft(d => ({ ...d, [k]: v }))

      const saveConfig = async () => {
        setBusy(true); setError(''); setNotice('')
        try {
          const r = await api('/dsh-jimeng/api/config', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(draft),
          })
          if (r && r.ok) { setNotice('配置已保存'); await loadConfig() } else setError((r && r.error) || '保存失败')
        } catch (e) { setError(e.message || String(e)) } finally { setBusy(false) }
      }

      // 有序参考图列表:本地图在前(按选择顺序)、URL 图在后 —— 这个顺序就是提示词里的「图1、图2…」。
      const urlRefs = refUrlText.split(/[\s,;]+/).map(s => s.trim()).filter(Boolean)
      const allRefs = [...refFiles.map(r => r.dataUrl), ...urlRefs]
      const overLimit = allRefs.length > MAX_REFS

      const onFiles = (e) => {
        const picked = Array.from((e.target && e.target.files) || [])
        if (picked.length === 0) return
        Promise.all(picked.slice(0, MAX_REFS).map(file => new Promise(resolve => {
          const reader = new FileReader()
          reader.onload = () => resolve({
            id: file.name + ':' + file.size + ':' + file.lastModified,
            name: file.name,
            dataUrl: String(reader.result),
          })
          reader.onerror = () => resolve(null)
          reader.readAsDataURL(file)
        }))).then(loaded => {
          const ok = loaded.filter(Boolean)
          setRefFiles(prev => {
            const seen = new Set(prev.map(r => r.id))
            const next = prev.slice()
            for (const r of ok) {
              if (next.length >= MAX_REFS) break
              if (!seen.has(r.id)) { seen.add(r.id); next.push(r) }
            }
            return next
          })
          if (e.target) e.target.value = ''   // 清空以便再次选同一文件
        })
      }

      const removeRef = (id) => setRefFiles(prev => prev.filter(r => r.id !== id))

      const removeUrlRef = (i) => setRefUrlText(urlRefs.filter((_, k) => k !== i).join('\n'))

      const detectModels = async () => {
        setBusy(true); setDetectMsg('')
        try {
          const r = await api('/dsh-jimeng/api/models')
          if (r && r.ok && Array.isArray(r.models)) {
            setDetected(r.models)
            if (r.models.length) {
              setDetectMsg('检测到 ' + r.models.length + ' 个生图模型,已加入下拉')
            } else {
              setDetectMsg('未检测到生图模型(/models 返回 ' + (r.total || 0) + ' 个条目,但都是对话模型;生图请用内置列表或「自定义」手动输入)')
            }
          } else {
            setDetectMsg((r && r.error) || '未检测到模型(该平台可能未开放 /models)')
          }
        } catch (e) { setDetectMsg(e.message || String(e)) } finally { setBusy(false) }
      }

      const generate = async () => {
        setBusy(true); setError(''); setNotice(''); setResult(null)
        try {
          if (!prompt.trim()) { setError('请输入图片描述 prompt'); setBusy(false); return }
          const body = { prompt: prompt.trim(), size: size.trim() || undefined }
          if (mode === 'i2i') {
            if (allRefs.length === 0) { setError('图生图需要至少 1 张参考图:选本地图片(可多选)或填 URL(每行一个)'); setBusy(false); return }
            if (overLimit) { setError('参考图最多 ' + MAX_REFS + ' 张,当前选了 ' + allRefs.length + ' 张'); setBusy(false); return }
            body.images = allRefs
          }
          const r = await api('/dsh-jimeng/api/generate', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(body),
          })
          if (r && r.ok) { setResult(r.images) } else { setError((r && r.error) || '生成失败') }
        } catch (e) { setError(e.message || String(e)) } finally { setBusy(false) }
      }

      const h = React.createElement

      const field = (label, node) => h('div', { className: 'field' },
        h('label', null, label), node)

      const configCard = h('div', { className: 'card' }, [
        h('p', { className: 'card-title' }, '火山方舟(即梦 Seedream)API 配置'),
        h('p', { className: 'hint' },
          '接入火山方舟 Volcengine Ark 的 OpenAI 兼容 images API。在火山引擎控制台创建推理接入点(或直接填模型名),并把 Ark API Key 填到下面。'),
        field('API Key(Ark API Key)', h('input', {
          type: 'password', autoComplete: 'off', value: draft.apiKey || '',
          placeholder: config && config.hasKey ? ('已保存 ' + config.keyMasked + ';留空则不修改') : '粘贴火山方舟 Ark API Key',
          onChange: e => set('apiKey', e.target.value),
        })),
        field('Base URL', h('input', {
          type: 'text', value: draft.baseUrl || '',
          placeholder: 'https://ark.cn-beijing.volces.com/api/v3',
          onChange: e => set('baseUrl', e.target.value),
        })),
        h('div', { className: 'row' }, [
          h('div', { className: 'grow' }, h(ModelField, {
            label: '模型(文生图)', value: draft.model || '', onChange: v => set('model', v),
            detected, placeholder: '选择文生图模型…',
          })),
          h('div', { className: 'grow' }, h(ModelField, {
            label: '模型(图生图,可选)', value: draft.modelI2i || '', onChange: v => set('modelI2i', v),
            detected, placeholder: '留空则沿用文生图模型',
          })),
        ]),
        h('div', { className: 'row', style: { alignItems: 'center' } }, [
          h('button', { disabled: busy, onClick: detectModels }, busy ? '检测中…' : '检测可用模型'),
          detectMsg ? h('span', { className: 'hint' }, detectMsg) : null,
        ]),
        h('div', { className: 'row' }, [
          h('div', { className: 'grow' }, field('默认尺寸', h('select', {
            value: draft.size || '', onChange: e => set('size', e.target.value),
          },
            ['1024x1024', '1280x720', '720x1280', '2K', '4K'].map(s => h('option', { key: s, value: s }, s)),
          ))),
          h('div', { className: 'grow' }, field('保存目录', h('input', {
            type: 'text', value: draft.saveDir || '',
            placeholder: '默认 ~/.dsh/jimeng-images',
            onChange: e => set('saveDir', e.target.value),
          }))),
        ]),
        h('div', { className: 'row', style: { alignItems: 'center' } }, [
          h('span', { className: 'hint' }, '添加水印'),
          h('span', {
            className: 'switch' + (draft.watermark ? ' on' : ''),
            role: 'switch', 'aria-checked': !!draft.watermark,
            onClick: () => set('watermark', !draft.watermark),
          }),
        ]),
        h('div', null, h('button', { className: 'btn-primary', disabled: busy, onClick: saveConfig },
          busy ? '保存中…' : '保存配置')),
      ])

      const refInput = mode === 'i2i' ? h('div', { className: 'field' }, [
        h('label', null, '参考图(可多选,1-' + MAX_REFS + ' 张;顺序即提示词里的「图1、图2…」)'),
        h('input', {
          type: 'file', accept: 'image/*', multiple: true, onChange: onFiles,
        }),
        h('textarea', {
          value: refUrlText, rows: 2,
          placeholder: '或粘贴图片 URL:每行一个(也支持空格/逗号分隔)',
          onChange: e => setRefUrlText(e.target.value),
        }),
        allRefs.length > 0 ? h('div', { className: 'refs' }, [
          ...refFiles.map((r, i) => h('div', { className: 'ref-chip', key: r.id, title: r.name }, [
            h('img', { src: r.dataUrl, alt: r.name }),
            h('span', { className: 'ref-n' }, '图' + (i + 1)),
            h('button', { className: 'ref-x', title: '移除', onClick: () => removeRef(r.id) }, '×'),
          ])),
          ...urlRefs.map((u, i) => h(UrlRefChip, {
            key: 'u' + i + ':' + u,
            url: u,
            index: refFiles.length + i + 1,
            onRemove: () => removeUrlRef(i),
          })),
        ]) : null,
        allRefs.length > 0 ? h('div', { className: 'ref-count' + (overLimit ? ' warn' : '') },
          overLimit
            ? '已选 ' + allRefs.length + ' 张,超过上限 ' + MAX_REFS + ' 张(火山方舟只支持 ' + MAX_REFS + ' 张参考图)'
            : '已选 ' + allRefs.length + ' / ' + MAX_REFS + ' 张') : null,
        h('div', { className: 'hint' },
          '多图用法:描述里点名各图职责,例如「把图2的鲸鱼放进图1的场景,配色参考图3」。参考图越多越慢。'),
      ]) : null

      const generateCard = h('div', { className: 'card' }, [
        h('p', { className: 'card-title' }, '手动生图'),
        h('div', { className: 'mode-tabs' },
          modeTabs.map(t => h('button', {
            key: t.key, className: 'mode-tab' + (mode === t.key ? ' on' : ''),
            onClick: () => { setMode(t.key); setResult(null) },
          }, t.label))),
        field('描述(prompt)', h('textarea', {
          value: prompt, placeholder: '例如:一只蓝鲸在深海星空下缓缓游动,梦幻光影,插画风',
          onChange: e => setPrompt(e.target.value),
        })),
        refInput,
        h('div', { className: 'row' }, [
          h('div', { className: 'grow' }, field('尺寸(留空用默认)', h('input', {
            type: 'text', value: size, placeholder: '1024x1024',
            onChange: e => setSize(e.target.value),
          }))),
        ]),
        h('div', null, h('button', { className: 'btn-primary', disabled: busy, onClick: generate },
          busy
            ? '生成中…'
            : (mode === 'i2i'
              ? '生成(图生图' + (allRefs.length > 1 ? ' · ' + allRefs.length + ' 张参考' : '') + ')'
              : '生成'))),
      ])

      const resultGrid = result && result.length
        ? h('div', { className: 'result-grid' },
          result.map((img, i) => h('div', { className: 'result-card', key: i }, [
            h('img', { src: img.dataUrl, alt: 'generated ' + (i + 1) }),
            h('div', { className: 'meta' },
              h('a', { href: img.dataUrl, download: (img.path || 'jimeng.png').split(/[\\/]/).pop() }, '下载')),
          ])))
        : null

      return h('div', { className: 'jimeng-panel' }, [
        error ? h('div', { className: 'error' }, error) : null,
        notice ? h('div', { className: 'notice ok' }, notice) : null,
        configCard,
        generateCard,
        resultGrid,
        !loaded ? h('div', { className: 'notice' }, '加载中…') : null,
      ])
    }

    function apply(ctx) {
      const styleEl = document.createElement('style')
      styleEl.textContent = CSS
      document.head.appendChild(styleEl)
      ctx.effect(() => () => { styleEl.remove() }, 'dsh-jimeng: styles')

      const slots = ctx.get('slots')
      if (slots === undefined) return
      slots.inject('settings.section', () => slots.register(
        { name: 'settings.section', id: 'jimeng', order: 11, label: '即梦生图' },
        () => React.createElement(JimengPanel),
      ))

      // 消息内的图片预览：接管两个生图工具的工具卡视图。
      // 只认自己注册的工具名，不碰内置工具；结果里没有图片块时返回 null 交回通用卡。
      for (const toolName of ['generate_image', 'image_to_image']) {
        slots.inject('tool.call.toolview', () => slots.register({
          name: 'tool.call.toolview',
          key: toolName,
          registrant: 'dsh-jimeng',
        }, JimengImageView))
      }
    }

    exports.apply = apply
    exports.inject = ['slots']
    return module.exports
  },
})
