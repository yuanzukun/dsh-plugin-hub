/**
 * dsh-jimeng —— 即梦(火山方舟 Seedream)文生图 / 图生图插件(host 半边)。
 *
 * 能力:
 *   1. 模型工具 generate_image(文生图) / image_to_image(图生图,支持 1-10 张参考图):
 *      调用火山方舟 OpenAI 兼容的 POST {baseUrl}/images/generations,把生成的图片落盘 +
 *      注册为对话附件,直接在对话里显示。
 *   2. HTTP API(供设置分区 client 半边使用):/dsh-jimeng/api/config(GET/POST)
 *      与 /dsh-jimeng/api/generate(POST)。API Key 只存在 host 的配置 JSON 里,
 *      前端不持有明文。
 *   3. 配置持久化到 ~/.dsh/dsh-jimeng.json(node:fs 直写,重启不丢)。
 *
 * 接入方式:火山方舟 Volcengine Ark,OpenAI 兼容 images API。
 *   默认 baseUrl:https://ark.cn-beijing.volces.com/api/v3
 *   默认模型:doubao-seedream-4-0-250828(统一文生图/图生图)
 *   鉴权:Authorization: Bearer <ARK_API_KEY>
 */
import { defineTool } from '@deepseek-ai/dsh-tools'
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs'
import { join, basename } from 'node:path'
import { homedir } from 'node:os'

export const name = 'dsh-jimeng'
export const inject = ['tools', 'webServer', 'attachments']

/**
 * DSH 状态根目录。
 *
 * 必须尊重 `DSH_HOME`：本机跑着两个隔离实例（主实例 ~/.dsh、实验室 G:\DSHTest），
 * 一个插件若把配置与产物写死在 `os.homedir()/.dsh`，实验室实例就会往主实例的目录里写。
 * 与 dsh-memory / dsh-balance-whale-widget 保持同一优先级：env 优先，未设时回落到历史行为。
 */
const DSH_HOME = (() => {
  const fromEnv = process.env.DSH_HOME
  if (typeof fromEnv === 'string' && fromEnv.trim() !== '') return fromEnv.trim()
  try { return join(homedir(), '.dsh') } catch { return join(process.env.USERPROFILE || process.env.HOME || '.', '.dsh') }
})()

const ROUTE = '/dsh-jimeng'

const DEFAULTS = {
  apiKey: '',
  baseUrl: 'https://ark.cn-beijing.volces.com/api/v3',
  model: 'doubao-seedream-4-0-250828',
  modelI2i: '',
  size: '1024x1024',
  watermark: false,
  saveDir: join(DSH_HOME, 'jimeng-images'),
}

/** 供验证脚本读取真实解析结果（不参与运行逻辑）。 */
export const __probe = { dshHome: DSH_HOME, saveDir: DEFAULTS.saveDir, configFile: join(DSH_HOME, 'dsh-jimeng.json') }

const SIZE_HINTS = ['1024x1024', '1280x720', '720x1280', '2K', '4K']

/**
 * 参考图张数上限。实测(2026-10-01,Seedream 5.0 Pro):传 11 张 → HTTP 400
 * "InvalidParameter: number of reference images cannot exceed 10"。
 * 超限请求不计费,但没必要发出去,本地先拦。
 */
const MAX_REF_IMAGES = 10

/** seedream / seededit 2.x–3.x 的 image 字段只接受单个字符串,多图会被拒。 */
function isLegacySingleImageModel(model) {
  return /seedream[._-]?[23]|seededit[._-]?[23]/i.test(String(model || ''))
}

/** 单张参考图时使用数组形态的模型(与旧版逐字一致,不改变既有行为)。 */
function prefersArrayForSingleImage(model) {
  return /4[._-]?0|seedream-?4/i.test(String(model || ''))
}

/** 把多形态入参归一成有序参考图列表:string / string[] / {value|url|path|image}[] 都认。 */
function normalizeRefList(input) {
  const out = []
  const push = (v) => {
    if (typeof v === 'string') {
      if (v.trim()) out.push(v.trim())
      return
    }
    if (v && typeof v === 'object') {
      const s = v.value !== undefined ? v.value : (v.url !== undefined ? v.url : (v.path !== undefined ? v.path : v.image))
      if (typeof s === 'string' && s.trim()) out.push(s.trim())
    }
  }
  if (Array.isArray(input)) input.forEach(push)
  else push(input)
  return out
}

/**
 * 由「模型 + 有序参考图列表」决定 body.image 的形态(纯函数,离线可测):
 *   []        → undefined(不传 image,纯文生图)
 *   1 张      → 与旧版逐字一致的形态(4.x 数组 / 其余字符串),零行为变更
 *   2-10 张   → 数组(实测服务端 usage.input_images 与张数一致)
 * 旧模型(seedream/seededit 2.x-3.x)给多图、或任何模型超过上限,都在这里抛错。
 */
function imageFieldFor(model, refs) {
  const list = normalizeRefList(refs)
  if (list.length > MAX_REF_IMAGES) {
    throw new Error(`参考图最多 ${MAX_REF_IMAGES} 张(火山方舟限制),当前给了 ${list.length} 张`)
  }
  if (list.length === 0) return undefined
  if (list.length === 1) return prefersArrayForSingleImage(model) ? [list[0]] : list[0]
  if (isLegacySingleImageModel(model)) {
    throw new Error(`模型 ${model} 只支持 1 张参考图;要多图请改用 seedream-4 / seedream-5 系列(或清空「模型(图生图)」让它跟随当前模型)`)
  }
  return list
}

/**
 * 纯逻辑导出：离线测试脚本直接调用，不必联网（不参与运行逻辑）。
 * ⚠️ 必须放在被引用的 const / function 之后 —— 放前面会在模块求值期撞 TDZ
 * （ReferenceError: Cannot access 'MAX_REF_IMAGES' before initialization）。
 */
export const __internals = { MAX_REF_IMAGES, normalizeRefList, isLegacySingleImageModel, prefersArrayForSingleImage, imageFieldFor }

function configFile() {
  return join(DSH_HOME, 'dsh-jimeng.json')
}

function readConfig() {
  try {
    return { ...DEFAULTS, ...JSON.parse(readFileSync(configFile(), 'utf8')) }
  } catch {
    return { ...DEFAULTS }
  }
}

function writeConfig(patch) {
  mkdirSync(DSH_HOME, { recursive: true })
  const next = { ...readConfig(), ...patch }
  writeFileSync(configFile(), JSON.stringify(next, null, 2))
  return next
}

function maskKey(key) {
  if (!key) return ''
  if (key.length <= 8) return '*'.repeat(key.length)
  return key.slice(0, 4) + '…' + key.slice(-4)
}

/**
 * 调用火山方舟 images/generations,返回 { images: [{ base64 }], usage }。
 *
 * 文生图只发 prompt;图生图/图像编辑额外发 image:
 *   0 张     → 不传 image 字段(纯文生图)
 *   1 张     → 与旧版逐字一致的形态(4.x 数组 / 其余字符串),零行为变更
 *   2-10 张  → 统一数组形态(实测 2 张 HTTP 200 且 usage.input_images=2,
 *              输出里两张参考图的内容都出现)
 * 超过 10 张本地拦下(服务端会 400 且明确说 cannot exceed 10)。
 */
async function callArk(cfg, { prompt, size, images, imageUrl, n }) {
  if (!cfg.apiKey) throw new Error('即梦 API Key 未配置:请在「设置 → 即梦生图」填写火山方舟 Ark API Key')
  let refs = normalizeRefList(images)
  if (refs.length === 0) refs = normalizeRefList(imageUrl)
  const model = (refs.length > 0 && cfg.modelI2i) ? cfg.modelI2i : cfg.model
  const body = {
    model,
    prompt,
    response_format: 'b64_json',
    watermark: !!cfg.watermark,
  }
  if (size) body.size = size
  if (n && n > 1) body.n = Math.min(Math.max(Math.floor(n), 1), 4)
  const imageField = imageFieldFor(model, refs)
  if (imageField !== undefined) body.image = imageField

  const url = String(cfg.baseUrl || '').replace(/\/+$/, '') + '/images/generations'
  const resp = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: 'Bearer ' + cfg.apiKey,
    },
    body: JSON.stringify(body),
  })

  const text = await resp.text()
  let json = null
  try { json = JSON.parse(text) } catch { /* 非 JSON 错误体 */ }

  if (!resp.ok) {
    const msg = json && (json.error?.message || json.message)
      ? (json.error?.message || json.message)
      : (text.slice(0, 300) || resp.statusText || ('HTTP ' + resp.status))
    throw new Error(`即梦 API 错误 (HTTP ${resp.status}): ${msg}`)
  }

  const data = json && Array.isArray(json.data) ? json.data : []
  const out = []
  for (const item of data) {
    if (typeof item.b64_json === 'string' && item.b64_json) {
      out.push({ base64: item.b64_json })
    } else if (typeof item.url === 'string' && item.url) {
      const r = await fetch(item.url)
      if (!r.ok) throw new Error('下载生成图失败: HTTP ' + r.status)
      out.push({ base64: Buffer.from(await r.arrayBuffer()).toString('base64') })
    }
  }
  if (out.length === 0) throw new Error('即梦 API 未返回任何图片(检查模型/接入点与额度)')
  return { images: out, usage: (json && json.usage) ? json.usage : null }
}

function imageMime(buf) {
  const isPng = buf.length > 8 && buf[0] === 0x89 && buf[1] === 0x50 && buf[2] === 0x4e && buf[3] === 0x47
  const isJpeg = buf.length > 3 && buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff
  return isPng ? 'image/png' : (isJpeg ? 'image/jpeg' : 'image/png')
}

/** 把参考图解析成图片 URL(data URL 或 http URL),供火山方舟 image 字段使用。 */
async function resolveImageUrl(input) {
  const s = String(input || '').trim()
  if (!s) throw new Error('参考图为空')
  if (/^data:image\//i.test(s)) return s
  if (/^https?:\/\//i.test(s)) return s
  try {
    const buf = readFileSync(s)
    return 'data:' + imageMime(buf) + ';base64,' + buf.toString('base64')
  } catch {
    throw new Error('无法读取参考图文件: ' + s)
  }
}

function saveImageToDisk(cfg, base64, index, ts) {
  const buf = Buffer.from(base64, 'base64')
  const isPng = buf.length > 8 && buf[0] === 0x89 && buf[1] === 0x50 && buf[2] === 0x4e && buf[3] === 0x47
  const mediaType = isPng ? 'image/png' : 'image/jpeg'
  const ext = isPng ? 'png' : 'jpg'
  const dir = cfg.saveDir || DEFAULTS.saveDir
  mkdirSync(dir, { recursive: true })
  const file = join(dir, `jimeng-${ts}-${index + 1}.${ext}`)
  writeFileSync(file, buf)
  return { file, mediaType, buf }
}

export function apply(ctx) {
  const cfg = () => readConfig()

  const attachments = ctx.attachments

  /** 落盘 + 注册附件,返回工具结果值(可 JSON 序列化)。note 会附在文本首行。 */
  async function persist(images, note) {
    const ts = Date.now()
    const files = []
    const imgs = []
    for (let i = 0; i < images.length; i++) {
      const saved = saveImageToDisk(cfg(), images[i].base64, i, ts)
      files.push(saved.file)
      const entry = { file: saved.file }
      if (attachments) {
        try {
          const ref = await attachments.saveImage({
            data: new Uint8Array(saved.buf),
            mediaType: saved.mediaType,
            name: basename(saved.file),
          })
          entry.attachment = {
            attachmentId: ref.attachmentId,
            mediaType: ref.mediaType,
            bytes: ref.bytes,
            width: ref.width,
            height: ref.height,
            ...(ref.name === undefined ? {} : { name: ref.name }),
          }
        } catch { /* 附件注册失败不影响文件落盘 */ }
      }
      imgs.push(entry)
    }
    return {
      text: (note ? note + '\n' : '') + `已生成 ${images.length} 张图片:\n` + files.map(f => `- ${f}`).join('\n'),
      images: imgs,
    }
  }

  /** 服务端 usage 是「参考图真的被收下」的硬证据,写成一句人话附在结果里。 */
  function refNote(refCount, usage) {
    if (!refCount) return ''
    const got = usage && typeof usage.input_images === 'number' ? usage.input_images : null
    return got === null
      ? `参考图 ${refCount} 张`
      : `参考图 ${refCount} 张(服务端确认 input_images=${got})`
  }

  const renderGenerated = (_args, value) => {
    const blocks = [{ type: 'text', text: value.text }]
    for (const img of value.images || []) {
      if (img && img.attachment) blocks.push({ type: 'image', attachment: img.attachment })
    }
    return blocks
  }

  const clampN = v => (Number.isFinite(v) ? Math.min(Math.max(Math.floor(v), 1), 4) : 1)

  // ---- 工具:文生图 ----
  ctx.tools.register(defineTool({
    name: 'generate_image',
    description: '使用即梦(火山方舟 Seedream)文生图生成图片。'
      + '输入中文或英文的详细 prompt,生成的图片会保存到本地目录并直接显示在对话里。'
      + '适合用户说「帮我画一张…」等场景时主动调用。',
    parameters: {
      prompt: { type: 'string', required: true, description: '图片描述 prompt(中文/英文),越具体越好,可指定风格、主体、构图、光线。' },
      size: { type: 'string', description: `可选。图片尺寸,如 ${SIZE_HINTS.join('、')}。默认用设置里的尺寸。` },
      n: { type: 'number', description: '可选。生成张数 1-4,默认 1。' },
    },
    output: { schema: { type: 'json' }, render: renderGenerated },
    isConcurrencySafe: () => true,
    async execute(args) {
      const prompt = String(args.prompt || '').trim()
      if (!prompt) throw new Error('prompt 不能为空')
      const { images } = await callArk(cfg(), {
        prompt,
        size: args.size ? String(args.size).trim() : cfg().size,
        n: clampN(args.n),
      })
      return persist(images)
    },
  }))

  // ---- 工具:图生图(支持 1-10 张参考图) ----
  ctx.tools.register(defineTool({
    name: 'image_to_image',
    description: '使用即梦(火山方舟 Seedream)图生图/图像编辑:输入 1-10 张参考图 + 修改描述,生成基于参考图的新图。'
      + '支持多张参考图(如「把图2的鲸鱼放进图1的场景」「按这三张图的配色重画」);参考图越多越慢,提示词里用「图1/图2…」指明各图用途。'
      + '参考图支持本地文件绝对路径、http(s) URL、或 data:image/...;base64,...。'
      + '适合「把这张图改成…」「把这几张图合成一张…」等场景。',
    parameters: {
      images: {
        type: 'array',
        items: { type: 'string' },
        description: '参考图列表,1-10 张;顺序即提示词里的「图1、图2…」。每项为本地文件绝对路径、http(s) URL 或 data URL。',
      },
      image: { type: 'string', description: '单张参考图(等价于 images 只给一项)。与 images 二选一;两个都给时以 images 为准。' },
      prompt: { type: 'string', required: true, description: '基于参考图的修改描述(中文/英文)。多图时请写清每张图各自负责什么(主体/场景/风格)。' },
      size: { type: 'string', description: `可选。图片尺寸,如 ${SIZE_HINTS.join('、')}。默认用设置里的尺寸。` },
    },
    output: { schema: { type: 'json' }, render: renderGenerated },
    isConcurrencySafe: () => true,
    async execute(args) {
      const prompt = String(args.prompt || '').trim()
      if (!prompt) throw new Error('prompt 不能为空')
      const list = normalizeRefList(args.images)
      if (list.length === 0) list.push(...normalizeRefList(args.image))
      if (list.length === 0) {
        throw new Error('至少需要 1 张参考图:images(1-10 张)或 image(单张),每项是本地绝对路径 / http(s) URL / data URL')
      }
      if (list.length > MAX_REF_IMAGES) {
        throw new Error(`参考图最多 ${MAX_REF_IMAGES} 张,当前给了 ${list.length} 张`)
      }
      const refs = []
      for (const item of list) refs.push(await resolveImageUrl(item))
      const { images, usage } = await callArk(cfg(), {
        prompt,
        size: args.size ? String(args.size).trim() : cfg().size,
        images: refs,
      })
      return persist(images, refNote(refs.length, usage))
    },
  }))

  // ---- HTTP API(设置分区 + 手动生图面板用)----
  const webServer = ctx.webServer
  if (webServer) {
    const send = (res, code, obj) => {
      const body = JSON.stringify(obj)
      res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' })
      res.end(body)
    }
    const readBody = req => new Promise((resolve, reject) => {
      const chunks = []
      req.on('data', c => chunks.push(c))
      req.on('end', () => {
        try { resolve(chunks.length ? JSON.parse(Buffer.concat(chunks).toString('utf8')) : {}) } catch (e) { reject(e) }
      })
      req.on('error', reject)
    })

    webServer.register({
      kind: 'prefix',
      path: ROUTE + '/api',
      handler: async (req, res) => {
        const method = req.method || 'GET'
        const pathname = String(req.url || '').split('?')[0]
        try {
          if (method === 'GET' && pathname === ROUTE + '/api/config') {
            const c = cfg()
            return send(res, 200, {
              ok: true,
              config: {
                baseUrl: c.baseUrl, model: c.model, modelI2i: c.modelI2i, size: c.size,
                watermark: !!c.watermark, saveDir: c.saveDir,
                hasKey: !!c.apiKey, keyMasked: maskKey(c.apiKey),
              },
              sizeHints: SIZE_HINTS,
            })
          }
          if (method === 'POST' && pathname === ROUTE + '/api/config') {
            const body = await readBody(req)
            const patch = {}
            if (typeof body.baseUrl === 'string' && body.baseUrl.trim()) patch.baseUrl = body.baseUrl.trim()
            if (typeof body.model === 'string' && body.model.trim()) patch.model = body.model.trim()
            if (typeof body.modelI2i === 'string') patch.modelI2i = body.modelI2i.trim()
            if (typeof body.size === 'string' && body.size.trim()) patch.size = body.size.trim()
            if (typeof body.watermark === 'boolean') patch.watermark = body.watermark
            if (typeof body.saveDir === 'string' && body.saveDir.trim()) patch.saveDir = body.saveDir.trim()
            if (typeof body.apiKey === 'string' && body.apiKey.trim()) patch.apiKey = body.apiKey.trim()
            writeConfig(patch)
            return send(res, 200, { ok: true })
          }
          if (method === 'POST' && pathname === ROUTE + '/api/generate') {
            const body = await readBody(req)
            const prompt = typeof body.prompt === 'string' ? body.prompt.trim() : ''
            if (!prompt) return send(res, 400, { ok: false, error: 'prompt 不能为空' })
            // 参考图:优先 images 数组(1-10 张),兼容旧的单张 image 字段
            const rawRefs = normalizeRefList(body.images)
            if (rawRefs.length === 0) rawRefs.push(...normalizeRefList(body.image))
            if (rawRefs.length > MAX_REF_IMAGES) {
              return send(res, 400, { ok: false, error: `参考图最多 ${MAX_REF_IMAGES} 张,当前给了 ${rawRefs.length} 张` })
            }
            const refs = []
            for (const item of rawRefs) refs.push(await resolveImageUrl(item))
            const size = typeof body.size === 'string' && body.size.trim() ? body.size.trim() : cfg().size
            const { images, usage } = await callArk(cfg(), { prompt, size, images: refs, n: 1 })
            const ts = Date.now()
            const out = images.map((img, i) => {
              const saved = saveImageToDisk(cfg(), img.base64, i, ts)
              return { dataUrl: 'data:' + saved.mediaType + ';base64,' + img.base64, path: saved.file }
            })
            return send(res, 200, { ok: true, images: out, inputImages: refs.length, usage })
          }
          if (method === 'GET' && pathname === ROUTE + '/api/models') {
            const c = cfg()
            if (!c.apiKey) return send(res, 400, { ok: false, error: '未配置 API Key,无法检测模型' })
            const url = String(c.baseUrl || '').replace(/\/+$/, '') + '/models'
            const resp = await fetch(url, {
              method: 'GET',
              headers: { Authorization: 'Bearer ' + c.apiKey },
            })
            if (!resp.ok) {
              return send(res, 200, { ok: false, error: `该平台未开放 /models 列表接口 (HTTP ${resp.status})` })
            }
            const json = await resp.json()
            const list = Array.isArray(json.data) ? json.data
              : Array.isArray(json.models) ? json.models
                : Array.isArray(json) ? json
                  : []
            const all = []
            for (const m of list) {
              if (typeof m === 'string' && m) all.push(m)
              else if (m && typeof m.id === 'string' && m.id) all.push(m.id)
            }
            const unique = [...new Set(all)]
            const IMAGE_MODEL_RE = /seedream|seededit|t2i|i2i|image|flux|kolors|dall|stable|sana|dreamina|jimeng|wanx/i
            const images = unique.filter(id => IMAGE_MODEL_RE.test(id))
            return send(res, 200, { ok: true, models: images, total: unique.length })
          }
          return send(res, 404, { ok: false, error: 'not found' })
        } catch (error) {
          return send(res, 500, { ok: false, error: error instanceof Error ? error.message : String(error) })
        }
      },
    })
  }

  console.log('[dsh-jimeng] 已注册 generate_image / image_to_image 工具(图生图支持 1-10 张参考图)' + (webServer ? ' + HTTP API /dsh-jimeng/api' : ''))
}
