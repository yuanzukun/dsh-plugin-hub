// 校验 dsh-jimeng「多图参考」的纯逻辑（离线、零 API 成本）：
//   ① index.js 的 imageFieldFor / normalizeRefList 决定 body.image 的形态 ——
//      单张必须与旧版逐字一致（零回归）、多张必须是数组、旧模型必须明确报错、超 10 张本地拦。
//   ② client.js 的手动生图面板必须真的把多图发出去（multiple 选择器 + body.images）。
// 真机行为另由两处验证：_stage/probe-jimeng-multi.mjs（联网实测服务端契约）与实验室实例（真 GUI）。
import { readFileSync } from 'node:fs'
import { fileURLToPath } from 'node:url'

const idx = readFileSync(fileURLToPath(new URL('../index.js', import.meta.url)), 'utf8')
const cli = readFileSync(fileURLToPath(new URL('../client.js', import.meta.url)), 'utf8')

/** 把某个函数声明整段从源码里抠出来（按花括号配对）。 */
function extract(src, name) {
  const start = src.indexOf(`function ${name}(`)
  if (start === -1) throw new Error(`没找到函数 ${name}`)
  let depth = 0
  let i = src.indexOf('{', start)
  for (; i < src.length; i++) {
    const c = src[i]
    if (c === '{') depth++
    else if (c === '}') {
      depth--
      if (depth === 0) break
    }
  }
  return src.slice(start, i + 1)
}

/** 抠出一行的常量声明（如 const MAX_REF_IMAGES = 10）。 */
function extractConst(src, name) {
  const m = new RegExp(`const ${name} = ([^\\n]+)`).exec(src)
  if (!m) throw new Error(`没找到常量 ${name}`)
  return `const ${name} = ${m[1]}`
}

const names = ['isLegacySingleImageModel', 'prefersArrayForSingleImage', 'normalizeRefList', 'imageFieldFor']
const code = [extractConst(idx, 'MAX_REF_IMAGES'), ...names.map(n => extract(idx, n))].join('\n\n')
const api = new Function(`${code}\nreturn { MAX_REF_IMAGES, ${names.join(', ')} }`)()

let pass = 0
let fail = 0
function check(label, actual, expected) {
  const a = JSON.stringify(actual)
  const e = JSON.stringify(expected)
  if (a === e) { pass++; console.log(`  ok   ${label}`) } else { fail++; console.log(`  FAIL ${label}\n       实际: ${a}\n       期望: ${e}`) }
}
function checkThrows(label, fn, needle) {
  try {
    fn()
    fail++
    console.log(`  FAIL ${label}\n       期望抛错但没有`)
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e)
    if (msg.includes(needle)) { pass++; console.log(`  ok   ${label}`) } else {
      fail++
      console.log(`  FAIL ${label}\n       报错信息里没有「${needle}」: ${msg}`)
    }
  }
}
function checkHas(label, haystack, needle) {
  check(label, haystack.includes(needle), true)
}
function checkHasNot(label, haystack, needle) {
  check(label, haystack.includes(needle), false)
}

const M4 = 'doubao-seedream-4-0-250828'
const M5 = 'doubao-seedream-5-0-pro-260628'
const M3 = 'doubao-seedream-3-0-i2i-250415'
const M3E = 'doubao-seededit-3-0-i2i-250628'
const M21 = 'doubao-seedream-2-1-i2i-250828'

console.log('MAX_REF_IMAGES / 版本识别：')
check('上限 = 10（与实测的服务端限制一致）', api.MAX_REF_IMAGES, 10)
check('4.x 不算旧模型', api.isLegacySingleImageModel(M4), false)
check('5.x 不算旧模型', api.isLegacySingleImageModel(M5), false)
check('3.0 i2i 是旧模型', api.isLegacySingleImageModel(M3), true)
check('seededit 3.0 是旧模型', api.isLegacySingleImageModel(M3E), true)
check('2.1 i2i 是旧模型', api.isLegacySingleImageModel(M21), true)
check('自定义接入点 ep-xxx 不作旧模型假设', api.isLegacySingleImageModel('ep-20260101abc'), false)

console.log('normalizeRefList（多形态入参）：')
check('字符串 → 单项列表', api.normalizeRefList('A'), ['A'])
check('数组保序并去首尾空白', api.normalizeRefList([' A ', 'B']), ['A', 'B'])
check('对象形态 value/url/path/image 都认', api.normalizeRefList([{ value: 'A' }, { url: 'B' }, { path: 'C' }, { image: 'D' }]), ['A', 'B', 'C', 'D'])
check('空串、空白、null、数字、空对象全部丢掉', api.normalizeRefList(['', '   ', null, 3, {}]), [])
check('undefined → 空列表', api.normalizeRefList(undefined), [])
check('嵌套数组里的对象也认', api.normalizeRefList([{ url: ' A ' }, 'B ']), ['A', 'B'])

console.log('imageFieldFor —— 单张（必须与旧版逐字一致，零回归）：')
check('4.x 单张 → 数组', api.imageFieldFor(M4, ['A']), ['A'])
check('5.x 单张 → 字符串', api.imageFieldFor(M5, ['A']), 'A')
check('3.x 单张 → 字符串', api.imageFieldFor(M3, ['A']), 'A')
check('2.1 单张 → 字符串', api.imageFieldFor(M21, ['A']), 'A')
check('模型名为空时单张 → 字符串（保险侧）', api.imageFieldFor('', ['A']), 'A')
check('无参考图 → undefined（不传 image 字段）', api.imageFieldFor(M5, []), undefined)
check('无参考图（null）→ undefined', api.imageFieldFor(M5, null), undefined)

console.log('imageFieldFor —— 多张（新能力）：')
check('5.x 两张 → 数组且保序', api.imageFieldFor(M5, ['A', 'B']), ['A', 'B'])
check('4.x 三张 → 数组且保序', api.imageFieldFor(M4, ['A', 'B', 'C']), ['A', 'B', 'C'])
check('刚好 10 张 → 放行', api.imageFieldFor(M5, new Array(10).fill('x')).length, 10)
check('模型名为空的两位数接入点也允许多图', api.imageFieldFor('ep-abc', ['A', 'B']), ['A', 'B'])
checkThrows('11 张 → 本地拦下（服务端会 400 cannot exceed 10）',
  () => api.imageFieldFor(M5, new Array(11).fill('x')), '最多 10 张')
checkThrows('3.0 i2i 两张 → 明确报错，不发出去',
  () => api.imageFieldFor(M3, ['A', 'B']), '只支持 1 张参考图')
checkThrows('seededit 3.0 两张 → 同样报错',
  () => api.imageFieldFor(M3E, ['A', 'B']), '只支持 1 张参考图')
checkThrows('2.1 i2i 两张 → 同样报错',
  () => api.imageFieldFor(M21, ['A', 'B']), '只支持 1 张参考图')

console.log('index.js 契约：')
checkHas('image_to_image 声明 images 数组参数', idx, "images: {\n        type: 'array',")
checkHas('保留单图 image 字段做兼容', idx, "image: { type: 'string', description: '单张参考图")
checkHas('工具描述写明 1-10 张', idx, '1-10 张参考图')
checkHas('HTTP API 也收 images 数组', idx, 'normalizeRefList(body.images)')
checkHas('HTTP API 兼容旧的单张 image', idx, 'normalizeRefList(body.image)')
checkHas('结果里附服务端 input_images 佐证', idx, 'input_images=')
checkHas('纯逻辑导出供离线测试', idx, 'export const __internals')

console.log('client.js 契约：')
checkHas('文件选择器开了多选', cli, 'multiple: true')
checkHas('本地图读成 dataUrl 列表', cli, 'setRefFiles(')
checkHas('面板把多图发到 body.images', cli, 'body.images = allRefs')
checkHasNot('面板不再发旧的单张 body.image', cli, 'body.image = ')
checkHas('客户端上限与 host 一致', cli, 'const MAX_REFS = 10')
checkHas('URL 参考图逐行解析', cli, 'refUrlText.split(/[\\s,;]+/)')
checkHas('参考图缩略图条', cli, "h('div', { className: 'refs' }")
checkHas('每张参考图可移除', cli, "className: 'ref-x'")
checkHas('超过上限在界面上标红', cli, "'ref-count' + (overLimit ? ' warn' : '')")
checkHas('URL 缩略图失败不留破图', cli, 'function UrlRefChip(')

console.log(`\n${pass} 项通过, ${fail} 项失败`)
process.exit(fail === 0 ? 0 : 1)
