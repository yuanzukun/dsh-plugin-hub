// 把 index.js 当**真实模块**跑一遍：stub 掉 @deepseek-ai/dsh-tools，在临时 DSH_HOME 下
// 调 apply() 拿注册的工具，再用 mock fetch 执行 image_to_image，断言**真正发出去的 body.image**。
//
// 为什么要有它（实测教训）：`node --check` 只查语法，抓不到模块求值期的错误。
// 本次改多图时就踩过一个：把 `export const __internals = {...}` 写在 `const MAX_REF_IMAGES`
// 之前 → 模块加载即 ReferenceError（TDZ），而语法检查全绿、插件在真机上静默地"failed to import"。
// 这条测试把「模块能求值 + schema 正确 + payload 形态正确」一次性焊死，且零网络、零成本。
import { mkdtempSync, mkdirSync, writeFileSync, copyFileSync, readdirSync, rmSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { fileURLToPath, pathToFileURL } from 'node:url'

const here = fileURLToPath(new URL('..', import.meta.url))
const work = mkdtempSync(join(tmpdir(), 'dsh-jimeng-host-test-'))

let pass = 0
let fail = 0
function check(label, actual, expected) {
  const a = JSON.stringify(actual)
  const e = JSON.stringify(expected)
  if (a === e) { pass++; console.log(`  ok   ${label}`) } else { fail++; console.log(`  FAIL ${label}\n       实际: ${a}\n       期望: ${e}`) }
}
async function checkThrows(label, fn, needle) {
  try {
    await fn()
    fail++
    console.log(`  FAIL ${label}\n       期望抛错但没有`)
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e)
    if (msg.includes(needle)) { pass++; console.log(`  ok   ${label}`) } else {
      fail++
      console.log(`  FAIL ${label}\n       报错信息里没有「${needle}」: ${msg}`)
    }
  }
}

// ---- 搭一个最小的宿主沙箱：stub 依赖 + 临时 DSH_HOME + 真实 index.js 拷贝 ----
const home = join(work, 'home')
const plug = join(work, 'plugins', 'dsh-jimeng')
const saveDir = join(work, 'images')
mkdirSync(home, { recursive: true })
mkdirSync(plug, { recursive: true })
const stub = join(work, 'node_modules', '@deepseek-ai', 'dsh-tools')
mkdirSync(stub, { recursive: true })
writeFileSync(join(stub, 'package.json'), JSON.stringify({
  name: '@deepseek-ai/dsh-tools', version: '0.0.0-stub', type: 'module', main: 'index.js',
  exports: { '.': './index.js' },
}))
writeFileSync(join(stub, 'index.js'), 'export function defineTool(options) { return options }\n')
copyFileSync(join(here, 'index.js'), join(plug, 'index.js'))

const CONFIG = join(home, 'dsh-jimeng.json')
function setConfig(patch) {
  writeFileSync(CONFIG, JSON.stringify({
    apiKey: 'sk-test', baseUrl: 'https://mock.local/api/v3',
    model: 'doubao-seedream-5-0-pro-260628', modelI2i: '',
    size: '1024x1024', watermark: false, saveDir,
    ...patch,
  }))
}
setConfig({})
process.env.DSH_HOME = home   // 必须在 import 之前：模块顶层就解析 DSH_HOME

const TINY_PNG = 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8DwHwAFAAH/q842iQAAAABJRU5ErkJggg=='
const calls = []
globalThis.fetch = async (url, init) => {
  const body = JSON.parse(init.body)
  calls.push({ url: String(url), body })
  const n = body.image === undefined ? 0 : (Array.isArray(body.image) ? body.image.length : 1)
  return {
    ok: true,
    status: 200,
    text: async () => JSON.stringify({
      model: body.model,
      data: [{ b64_json: TINY_PNG }],
      usage: { input_images: n, generated_images: 1, output_tokens: 4096, total_tokens: 4096 },
    }),
  }
}

let mod = null
try {
  console.log('模块求值（TDZ / 顶层异常在这条上现形）：')
  mod = await import(pathToFileURL(join(plug, 'index.js')).href)
  check('index.js 能作为真实模块加载', typeof mod.apply, 'function')
  check('name / inject 导出正确', [mod.name, mod.inject], ['dsh-jimeng', ['tools', 'webServer', 'attachments']])
  check('__probe 跟随 DSH_HOME', mod.__probe.dshHome, home)
  check('__internals 已导出', Object.keys(mod.__internals).sort(),
    ['MAX_REF_IMAGES', 'imageFieldFor', 'isLegacySingleImageModel', 'normalizeRefList', 'prefersArrayForSingleImage'])

  console.log('apply() 注册的工具：')
  const tools = []
  mod.apply({ tools: { register: t => tools.push(t) }, attachments: null, webServer: null })
  check('注册了 2 个工具', tools.map(t => t.name), ['generate_image', 'image_to_image'])
  const i2i = tools.find(t => t.name === 'image_to_image')
  const t2i = tools.find(t => t.name === 'generate_image')
  check('i2i 的 images 是字符串数组参数', [i2i.parameters.images.type, i2i.parameters.images.items.type], ['array', 'string'])
  check('i2i 保留单图 image 参数（向后兼容）', i2i.parameters.image.type, 'string')
  check('i2i 的 prompt 必填', i2i.parameters.prompt.required, true)
  check('i2i 描述写明张数范围', typeof i2i.description === 'string' && i2i.description.includes('1-10 张'), true)

  console.log('真正发出去的 payload：')
  const A = 'https://example.com/a.png'
  const B = 'https://example.com/b.png'

  calls.length = 0
  let r = await i2i.execute({ images: [A, B], prompt: '把图2放进图1' })
  check('两张 → body.image 是数组且保序', calls[0].body.image, [A, B])
  check('两张 → url 落在 mock baseUrl', calls[0].url, 'https://mock.local/api/v3/images/generations')
  check('两张 → 结果文本带服务端佐证', r.text.split('\n')[0], '参考图 2 张(服务端确认 input_images=2)')

  calls.length = 0
  r = await i2i.execute({ images: [A], prompt: '改成油画风' })
  check('单张（5.x 模型）→ body.image 是字符串（旧版逐字行为）', calls[0].body.image, A)

  calls.length = 0
  r = await i2i.execute({ image: A, prompt: '旧的单图字段仍可用' })
  check('旧字段 image → 照常工作', calls[0].body.image, A)

  calls.length = 0
  await checkThrows('11 张 → 本地拦下，且不发出任何请求', async () => {
    await i2i.execute({ images: new Array(11).fill(A), prompt: 'x' })
  }, '最多 10 张')
  check('11 张 → 确实没有发出请求', calls.length, 0)

  calls.length = 0
  r = await t2i.execute({ prompt: '一只蓝鲸' })
  check('文生图 → 不带 image 字段', 'image' in calls[0].body, false)
  check('文生图 → 结果文本无参考图行', r.text.split('\n')[0], '已生成 1 张图片:')

  console.log('模型版本分支（配置逐次改写）：')
  setConfig({ model: 'doubao-seedream-4-0-250828' })
  calls.length = 0
  await i2i.execute({ images: [A], prompt: 'x' })
  check('4.x 单张 → 数组（旧版逐字行为）', calls[0].body.image, [A])

  setConfig({ model: 'doubao-seedream-3-0-i2i-250415' })
  calls.length = 0
  await checkThrows('3.x 两张 → 明确报错', async () => {
    await i2i.execute({ images: [A, B], prompt: 'x' })
  }, '只支持 1 张参考图')
  check('3.x 两张 → 没有发出请求', calls.length, 0)

  setConfig({ model: 'doubao-seedream-5-0-pro-260628', modelI2i: 'doubao-seedream-3-0-i2i-250415' })
  calls.length = 0
  await checkThrows('配了 3.x 的「模型(图生图)」时多图也拦得住', async () => {
    await i2i.execute({ images: [A, B], prompt: 'x' })
  }, '只支持 1 张参考图')

  console.log('落盘：')
  const files = readdirSync(saveDir)
  check('每次成功都落盘一张图（5 次成功调用）', files.length, 5)
  check('扩展名按魔数判定（返回的是 PNG）', files.every(f => f.endsWith('.png')), true)
} finally {
  try { rmSync(work, { recursive: true, force: true }) } catch { /* 清理失败不影响结论 */ }
}

console.log(`\n${pass} 项通过, ${fail} 项失败`)
process.exit(fail === 0 ? 0 : 1)
