/**
 * `ctx.office` — the OfficeCLI service. It translates typed operations into
 * officecli argv, runs them through the `ctx.subprocess` capability, parses
 * the `--json` envelope, and manages per-file `officecli watch` processes for
 * the live-preview tab.
 *
 * Consumers (the model-facing tools and the preview routes) never touch the
 * binary directly; this service owns argv building, the envelope contract, and
 * the error taxonomy. It is provided by the `dsh-office-tool` host plugin.
 * @module dsh-office-tool/service
 */

import { Context, Service } from '@deepseek-ai/cordis'
import type { JsonValue } from '@deepseek-ai/dsh-tools'
import type { SubprocessRuntime } from '@deepseek-ai/dsh-subprocess'
import { OfficeError, officeErrorFromInfo, type OfficeErrorInfo } from './errors.ts'

export { OfficeError, officeErrorFromInfo, type OfficeErrorInfo } from './errors.ts'

/** One typed OfficeCLI operation. `cli` passes raw argv through verbatim. */
export type OfficeVerb =
  | 'create' | 'get' | 'query' | 'set' | 'add' | 'remove' | 'move' | 'swap'
  | 'view' | 'batch' | 'merge' | 'dump' | 'import' | 'validate'
  | 'raw' | 'raw-set' | 'refresh' | 'help' | 'save' | 'close' | 'open'
  | 'watch' | 'unwatch'
  | 'cli'

/** A typed command. `props` expands to repeated `--prop k=v` entries. */
export interface OfficeRunSpec {
  verb: OfficeVerb
  /** Document path (positional after the verb). Omitted for `cli`. */
  file?: string
  /** Further positional arguments after `file`. */
  args?: readonly string[]
  /** Repeated `--prop <k>=<v>` entries (set/add/create). */
  props?: Readonly<Record<string, string | number | boolean>>
  /** `--<name> <value>` flags; boolean true pushes `--<name>` only. */
  flags?: Readonly<Record<string, string | number | boolean | undefined>>
  /** Append `--json` (default true for `run`; false for raw/HTML output). */
  json?: boolean
  /** Child working directory; defaults to the host process cwd. */
  cwd?: string
}

/** The officecli success envelope (`{"success":true,"data":...,"message"?}`). */
export interface OfficeSuccessEnvelope {
  success: true
  data: JsonValue
  message?: string
  matched?: number
  warnings?: string[]
}

/** The officecli error envelope (`{"success":false,"error":{...}}`). */
export interface OfficeErrorEnvelope {
  success: false
  error: OfficeErrorInfo
}

/** The full parsed officecli envelope. */
export type OfficeEnvelope = OfficeSuccessEnvelope | OfficeErrorEnvelope

/** Raw process output from {@link OfficeService.runRaw}. */
export interface OfficeRawResult {
  exitCode: number | null
  signal: NodeJS.Signals | null
  /** The collected stdout text (tail when truncated). */
  stdout: string
  /** The collected stderr tail. */
  stderr: string
  /** True when stdout overflowed the in-memory cap. */
  truncated: boolean
}

/** Construction options for {@link OfficeService}. */
export interface OfficeServiceOptions {
  /** Resolved officecli executable path. */
  bin: string
  /** Extra child environment entries. */
  env?: Readonly<Record<string, string>>
  /** Default per-command deadline in milliseconds. */
  timeoutMs: number
  /** stdout collection cap in bytes. */
  maxOutputBytes: number
}

declare module '@deepseek-ai/cordis' {
  interface Context {
    office: OfficeService
  }
}

/** Strip the UTF-8 BOM and any trailing `\r`/whitespace officecli may append. */
function cleanCliOutput(text: string): string {
  return text.replace(/^﻿/, '').replace(/\r?$/, '').trimEnd()
}

/**
 * Parse one officecli `--json` envelope from collected stdout. Returns
 * `undefined` when the output is not a JSON envelope at all.
 * @param stdout - raw collected stdout.
 * @returns the parsed envelope, or `undefined` for non-JSON output.
 */
export function parseEnvelope(stdout: string): OfficeEnvelope | undefined {
  const text = cleanCliOutput(stdout)
  if (text.length === 0) return undefined
  let value: unknown
  try {
    value = JSON.parse(text)
  } catch {
    return undefined
  }
  if (typeof value !== 'object' || value === null) return undefined
  const { success, data, message, matched, warnings } = value as Record<string, unknown>
  if (success === true) {
    return { success: true, data: data as JsonValue, ...message !== undefined ? { message: String(message) } : {}, ...matched !== undefined ? { matched: Number(matched) } : {}, ...warnings !== undefined ? { warnings: warnings as string[] } : {} }
  }
  if (success === false) {
    const error = (value as { error?: unknown }).error
    if (typeof error === 'object' && error !== null) {
      const { error: msg, code, suggestion, validValues } = error as Record<string, unknown>
      return {
        success: false,
        error: {
          error: typeof msg === 'string' ? msg : 'officecli reported a failure',
          ...typeof code === 'string' ? { code } : {},
          ...typeof suggestion === 'string' ? { suggestion } : {},
          ...Array.isArray(validValues) ? { validValues: validValues.filter((v): v is string => typeof v === 'string') } : {},
        },
      }
    }
  }
  return undefined
}

/**
 * The OfficeCLI service. Construct with resolved binary + config, then
 * `ctx.provide('office', office)` from the host plugin.
 */
export class OfficeService extends Service {
  constructor(
    ctx: Context,
    private readonly options: OfficeServiceOptions,
  ) {
    super(ctx, 'office')
  }

  /**
   * Build the full argv for one typed spec.
   * @param spec - the typed operation.
   * @returns argv with `argv[0]` = the resolved binary.
   */
  buildArgv(spec: OfficeRunSpec): string[] {
    const argv: string[] = [this.options.bin]
    if (spec.verb === 'cli') {
      argv.push(...(spec.args ?? []))
      return argv
    }
    argv.push(spec.verb)
    if (spec.file !== undefined) argv.push(spec.file)
    argv.push(...(spec.args ?? []))
    for (const [key, value] of Object.entries(spec.props ?? {})) {
      argv.push('--prop', `${key}=${String(value)}`)
    }
    for (const [key, value] of Object.entries(spec.flags ?? {})) {
      if (value === undefined || value === false) continue
      if (value === true) {
        argv.push(`--${key}`)
        continue
      }
      argv.push(`--${key}`, String(value))
    }
    if (spec.json !== false) argv.push('--json')
    return argv
  }

  /**
   * Run argv through `ctx.subprocess` and return raw output. Enforces the
   * timeout via an owned abort controller (the subprocess seam reacts to the
   * signal with its terminate escalation). A caller-provided `signal` is
   * honored; when the caller's signal fires, its abort is rethrown untouched.
   * @param argv - full argv including the binary.
   * @param opts - caller cancellation and/or an explicit deadline override.
   * @returns the raw collected output.
   * @throws {@link OfficeError} on spawn failure or deadline expiry.
   */
  async runRaw(argv: readonly string[], opts: { signal?: AbortSignal; timeoutMs?: number; cwd?: string } = {}): Promise<OfficeRawResult> {
    const subprocess = this.ctx.get('subprocess') as SubprocessRuntime
    const timeoutMs = opts.timeoutMs ?? this.options.timeoutMs
    const controller = new AbortController()
    const timer = setTimeout(() => controller.abort(), timeoutMs)
    const onAbort = () => controller.abort()
    if (opts.signal !== undefined) {
      if (opts.signal.aborted) controller.abort()
      else opts.signal.addEventListener('abort', onAbort, { once: true })
    }
    try {
      const handle = subprocess.spawn({
        argv,
        cwd: opts.cwd ?? process.cwd(),
        stdio: {
          stdin: 'ignore',
          stdout: { maxBytes: this.options.maxOutputBytes },
          stderr: { maxBytes: 1 << 20 },
        },
        graceMs: 2_000,
        env: this.options.env as NodeJS.ProcessEnv | undefined,
        signal: controller.signal,
      })
      const outcome = await handle.done
      // Classify the settlement: the caller's own abort wins over the deadline,
      // so a tool cancellation is never mislabelled as a timeout.
      if (opts.signal !== undefined && opts.signal.aborted) {
        throw new OfficeError('officecli call was cancelled', { code: 'office_cancelled' })
      }
      if (controller.signal.aborted) {
        throw new OfficeError(`officecli did not finish within ${timeoutMs}ms`, { code: 'office_timeout' })
      }
      const stdoutRead = handle.collected.stdout?.readFrom(0)
      const stderrRead = handle.collected.stderr?.readFrom(0)
      return {
        exitCode: outcome.exitCode,
        signal: outcome.signal,
        stdout: stdoutRead?.text ?? '',
        stderr: stderrRead?.text ?? '',
        truncated: stdoutRead?.lossy ?? false,
      }
    } catch (error) {
      if (opts.signal !== undefined && opts.signal.aborted) {
        // The caller (tool execution) cancelled: rethrow so dsh classifies it.
        throw error
      }
      if (controller.signal.aborted) {
        throw new OfficeError(`officecli did not finish within ${timeoutMs}ms`, { code: 'office_timeout', cause: error })
      }
      throw new OfficeError(`failed to start officecli: ${String(error)}`, { code: 'office_spawn_failed', cause: error })
    } finally {
      clearTimeout(timer)
      if (opts.signal !== undefined) opts.signal.removeEventListener('abort', onAbort)
    }
  }

  /**
   * Run a typed operation and parse the `--json` envelope.
   * @param spec - the typed operation.
   * @param signal - caller cancellation forwarded to the child.
   * @returns the parsed success envelope.
   * @throws {@link OfficeError} when officecli fails (structured fields) or
   *   returns output that is not a JSON envelope.
   */
  async run(spec: OfficeRunSpec, signal?: AbortSignal): Promise<OfficeSuccessEnvelope> {
    const argv = this.buildArgv(spec)
    const raw = await this.runRaw(argv, { signal, cwd: spec.cwd })
    if (raw.signal !== null && raw.signal !== 'SIGTERM') {
      throw new OfficeError(`officecli was killed by signal ${raw.signal}`, { code: 'office_command_failed' })
    }
    const envelope = parseEnvelope(raw.stdout)
    if (envelope === undefined) {
      if (raw.exitCode === 0) {
        throw new OfficeError(`officecli produced non-JSON output: ${truncate(raw.stdout, 300)}`, { code: 'office_invalid_output' })
      }
      throw new OfficeError(`officecli exited with code ${String(raw.exitCode)}: ${truncate(raw.stdout, 300)}`, {
        code: 'office_command_failed',
        exitCode: raw.exitCode ?? undefined,
      })
    }
    if (!envelope.success) throw officeErrorFromInfo(envelope.error, raw.exitCode ?? 0)
    return envelope
  }

  /**
   * Same as {@link run} but returns the full envelope (including a structured
   * error) instead of throwing — used by the `office_cli` passthrough tool so
   * the model sees the raw failure as data.
   * @param spec - the typed operation.
   * @param signal - caller cancellation.
   * @returns the parsed envelope, or a synthetic failure when output is not JSON.
   */
  async runEnvelope(spec: OfficeRunSpec, signal?: AbortSignal): Promise<OfficeEnvelope> {
    try {
      return await this.run(spec, signal)
    } catch (error) {
      if (error instanceof OfficeError) {
        return { success: false, error: { error: error.message, ...error.code !== undefined ? { code: error.code } : {}, ...error.suggestion !== undefined ? { suggestion: error.suggestion } : {}, ...error.validValues !== undefined ? { validValues: error.validValues } : {} } }
      }
      throw error
    }
  }

  /**
   * Relative preview URL for one document (rendered by the host `/office/preview`
   * route). Used by the tools so `office_view` / `office_cli` can point the UI
   * and the model at the sidebar preview without emitting the raw HTML.
   * @param file - the document path (absolute, or relative to the host cwd).
   * @param opts - optional page selection.
   * @returns a same-origin `/office/preview?...` URL.
   */
  previewUrl(file: string, opts: { page?: number | string } = {}): string {
    const params = new URLSearchParams({ path: file })
    if (opts.page !== undefined) params.set('page', String(opts.page))
    return `/office/preview?${params.toString()}`
  }
}

/** Keep a string within `max` chars for error messages. */
export function truncate(text: string, max: number): string {
  return text.length > max ? `${text.slice(0, max)}…` : text
}
