/**
 * The better-sidebar file viewer for .docx/.xlsx/.pptx: fetches officecli's
 * rendered HTML from the host `/office/preview` route and shows it in an
 * iframe (via a blob URL so render errors surface instead of a blank box).
 * A refresh button and a light mtime probe keep the preview current as the
 * agent edits the document.
 * @module dsh-office-tool/client/viewer
 */

import { useEffect, useRef, useState } from 'react'
import type { SessionScope } from './urls.ts'
import { previewUrl, probeUrl } from './urls.ts'

/** Props the viewer needs from better-sidebar's `FileViewerProps`. */
export interface OfficePreviewViewProps {
  scope: SessionScope
  path: string
}

const POLL_MS = 3000

/** The file viewer component registered for office extensions. */
export function OfficePreviewView(props: OfficePreviewViewProps): JSX.Element {
  const { scope, path } = props
  const [bust, setBust] = useState(0)
  const [iframeSrc, setIframeSrc] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)
  const loadedPath = useRef<string>('')

  const src = previewUrl(scope, path, bust === 0 ? undefined : bust)

  // (Re)load the rendered HTML whenever the path or a refresh changes.
  useEffect(() => {
    let cancelled = false
    async function load(): Promise<void> {
      setError(null)
      try {
        const response = await fetch(src)
        if (cancelled) return
        if (!response.ok) {
          const body = (await response.json().catch(() => null)) as { error?: { error?: string } } | null
          setError(body?.error?.error ?? `HTTP ${response.status}`)
          return
        }
        const html = await response.text()
        if (cancelled) return
        const blob = new Blob([html], { type: 'text/html' })
        setIframeSrc(URL.createObjectURL(blob))
        loadedPath.current = path
      } catch {
        if (!cancelled) setError('无法连接预览服务')
      }
    }
    void load()
    return () => {
      cancelled = true
    }
  }, [src, path])

  // Auto-reload: poll the cheap probe endpoint; when the file mtime changes,
  // re-fetch (skip the first report so an initial load is not doubled).
  useEffect(() => {
    let cancelled = false
    let timer: number | undefined
    let lastMtime: number | null = null
    async function tick(): Promise<void> {
      try {
        const response = await fetch(probeUrl(scope, path))
        if (response.ok) {
          const json = (await response.json()) as { mtime?: number }
          if (json.mtime !== undefined && json.mtime !== lastMtime) {
            if (lastMtime !== null) setBust((b) => b + 1)
            lastMtime = json.mtime
          }
        }
      } catch {
        // transient — keep polling
      }
      if (!cancelled) timer = window.setTimeout(() => { void tick() }, POLL_MS)
    }
    void tick()
    return () => {
      cancelled = true
      if (timer !== undefined) window.clearTimeout(timer)
    }
  }, [scope.sessionId, path])

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', minHeight: 0 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '4px 8px', borderBottom: '1px solid rgba(128,128,128,.3)', flex: '0 0 auto' }}>
        <span style={{ flex: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', fontSize: 12 }} title={path}>{path}</span>
        <button type="button" onClick={() => setBust((b) => b + 1)} style={{ fontSize: 12 }}>刷新</button>
      </div>
      {error !== null ? (
        <div style={{ padding: 16, fontSize: 12, color: '#c44' }}>{error}</div>
      ) : iframeSrc !== null ? (
        <iframe key={`${loadedPath.current}:${bust}`} src={iframeSrc} title={path} style={{ flex: 1, width: '100%', border: 'none', minHeight: 0 }} />
      ) : (
        <div style={{ padding: 16, fontSize: 12, color: 'rgba(128,128,128,.8)' }}>渲染中…</div>
      )}
    </div>
  )
}
