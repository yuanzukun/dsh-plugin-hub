/**
 * URL builders for the client half. The host `/office/preview` and
 * `/office/watch` routes accept the same `sessionId`/`path`/`cwd` parameters
 * better-sidebar's own `/sidebar/file` route uses, so a viewer's `scope` and
 * `path` map straight onto them.
 * @module dsh-office-tool/client/urls
 */

/** One request's session scope (mirror of better-sidebar's SessionScope). */
export interface SessionScope {
  sessionId: string
  /** The session working directory, when known. */
  cwd?: string
}

/** Build the `/office/preview` URL for a document (cache-bustable). */
export function previewUrl(scope: SessionScope, path: string, cacheBust?: number): string {
  return buildUrl('/office/preview', scope, path, cacheBust !== undefined ? { t: String(cacheBust) } : {})
}

/** Build the `/office/preview` probe URL (cheap mtime check for auto-reload). */
export function probeUrl(scope: SessionScope, path: string): string {
  return buildUrl('/office/preview', scope, path, { probe: '1' })
}

/** Build the `/office/watch` URL for one action. */
export function watchUrl(scope: SessionScope, path: string, action: 'open' | 'close'): string {
  return buildUrl('/office/watch', scope, path, { action })
}

/** Shared builder. */
function buildUrl(route: string, scope: SessionScope, path: string, extra: Record<string, string>): string {
  const params = new URLSearchParams({ sessionId: scope.sessionId, path })
  if (scope.cwd !== undefined && scope.cwd !== '') params.set('cwd', scope.cwd)
  for (const [key, value] of Object.entries(extra)) params.set(key, value)
  return `${route}?${params.toString()}`
}
