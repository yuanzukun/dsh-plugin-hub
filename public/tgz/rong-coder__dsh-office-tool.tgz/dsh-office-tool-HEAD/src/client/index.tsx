/**
 * dsh-office-tool, client half. Registers the docx/xlsx/pptx file viewer and
 * the "Office 预览" live tab through better-sidebar's `ctx.betterSidebar`.
 * The viewer renders with officecli (server-side HTML via `/office/preview`),
 * not a client-side Office library. Skipped entirely when better-sidebar is
 * absent — the office tools keep working in the host half.
 * @module dsh-office-tool/client
 */

import { createElement } from 'react'
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client'
// Type-only: pulls better-sidebar's `declare module 'cordis'` Context merge
// (ctx.betterSidebar) and the descriptor types. Erased at build time, so it
// never reaches the client bundle's module table.
import type {} from 'dsh-better-sidebar/client'
import type { FileViewerDescriptor, TabDescriptor } from 'dsh-better-sidebar'
import { OfficePreviewView } from './viewer.tsx'
import { OfficeWatchTab, type OfficeWatchTabProps } from './tab.tsx'

/** Services required before mounting: better-sidebar's client service. */
export const inject = ['betterSidebar']

/** A minimal structural view of better-sidebar's service (defensive cast). */
interface BetterSidebarLike {
  registerFileViewer(descriptor: FileViewerDescriptor): () => void
  registerTab(descriptor: TabDescriptor): () => void
}

/**
 * Client plugin body.
 * @param ctx - the client cordis context (betterSidebar service).
 */
export function apply(ctx: ClientContext): void {
  const betterSidebar = (ctx as unknown as { betterSidebar?: BetterSidebarLike }).betterSidebar
  if (betterSidebar === undefined) return

  // File viewer for Office documents — snapshot render through /office/preview.
  ctx.effect(() => betterSidebar.registerFileViewer({
    id: 'office:officecli',
    title: () => 'Office (OfficeCLI)',
    exts: ['docx', 'xlsx', 'pptx'],
    priority: 100,
    fetchStrategy: 'none',
    component: (props) => createElement(OfficePreviewView, { scope: props.scope, path: props.path }),
  }), 'dsh-office-tool: office file viewer')

  // Live-preview tab — officecli watch in an iframe.
  ctx.effect(() => betterSidebar.registerTab({
    id: 'office:preview',
    title: () => 'Office 预览',
    order: 200,
    component: (props) => createElement(OfficeWatchTab, { scope: (props as { scope?: OfficeWatchTabProps['scope'] }).scope }),
    onClose: () => { /* watch cleanup happens on tab unmount */ },
  }), 'dsh-office-tool: office watch tab')
}
