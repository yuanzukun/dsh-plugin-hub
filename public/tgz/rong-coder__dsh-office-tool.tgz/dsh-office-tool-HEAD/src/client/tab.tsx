/**
 * The better-sidebar "Office 预览" tab: pick a document, start `officecli
 * watch` for it through the host `/office/watch` route, and iframe the live
 * SSE-refreshing preview. The watch process is stopped when the tab unmounts.
 * @module dsh-office-tool/client/tab
 */

import { useEffect, useState } from 'react'
import type { SessionScope } from './urls.ts'
import { watchUrl } from './urls.ts'

/** Props the tab needs from better-sidebar's `TabComponentProps`. */
export interface OfficeWatchTabProps {
  scope?: SessionScope
}

/** The live-preview tab component. */
export function OfficeWatchTab(props: OfficeWatchTabProps): JSX.Element {
  const { scope } = props
  const sessionId = scope?.sessionId ?? ''
  const cwd = scope?.cwd
  const [file, setFile] = useState('')
  const [url, setUrl] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)

  async function open(): Promise<void> {
    const name = file.trim()
    if (name === '') return
    setError(null)
    try {
      const response = await fetch(watchUrl({ sessionId, cwd }, name, 'open'))
      const json = (await response.json()) as { ok?: boolean; url?: string; error?: { error?: string } }
      if (json.ok === true && json.url !== undefined) {
        setUrl(json.url)
      } else {
        setError(json.error?.error ?? '启动预览失败')
      }
    } catch {
      setError('无法连接预览服务')
    }
  }

  // Stop the watch process when the tab closes.
  useEffect(() => {
    const name = file.trim()
    return () => {
      if (name !== '') void fetch(watchUrl({ sessionId, cwd }, name, 'close')).catch(() => {})
    }
  }, [sessionId, cwd, file])

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', minHeight: 0 }}>
      <div style={{ display: 'flex', gap: 8, padding: 8, borderBottom: '1px solid rgba(128,128,128,.3)', flex: '0 0 auto' }}>
        <input
          value={file}
          onChange={(e) => setFile(e.target.value)}
          onKeyDown={(e) => { if (e.key === 'Enter') void open() }}
          placeholder="文档路径，如 report.docx"
          style={{ flex: 1, fontSize: 12 }}
        />
        <button type="button" onClick={() => { void open() }} style={{ fontSize: 12 }}>打开</button>
      </div>
      {error !== null ? (
        <div style={{ padding: 16, fontSize: 12, color: '#c44' }}>{error}</div>
      ) : url !== null ? (
        <iframe src={url} title="office watch" style={{ flex: 1, width: '100%', border: 'none', minHeight: 0 }} />
      ) : (
        <div style={{ padding: 16, fontSize: 12, color: 'rgba(128,128,128,.8)' }}>输入文档路径后点击「打开」，OfficeCLI 将启动实时预览（每次编辑自动刷新）。</div>
      )}
    </div>
  )
}
