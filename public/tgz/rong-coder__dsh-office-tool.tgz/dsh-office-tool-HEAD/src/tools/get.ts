/**
 * `office_get`: read one document element and its children as structured JSON.
 * @module dsh-office-tool/tools/get
 */

import { Context } from '@deepseek-ai/cordis'
import { defineTool, type JsonValue } from '@deepseek-ai/dsh-tools'
import type { OfficeService } from '../service.ts'
import { genericCall, renderJson } from './common.ts'

/** Register the `office_get` tool. */
export function applyOfficeGetTool(ctx: Context, office: OfficeService): void {
  ctx.tools.register(defineTool({
    name: 'office_get',
    description: 'Read one Office document element and its children as structured JSON. Path syntax: /slide[1]/shape[2] (PowerPoint), /body/p[3] or /body/tbl[1] (Word), /Sheet1/A1 or /Sheet1 (Excel), or / for the whole document. Indexes are 1-based.',
    parameters: {
      file: { type: 'string', required: true, description: 'Document path, e.g. "deck.pptx" or "report.docx".' },
      path: { type: 'string', description: 'Element path; defaults to "/" (the whole document).' },
      depth: { type: 'integer', description: 'How many child levels to include, 0-8 (default 0).' },
    },
    output: {
      schema: { type: 'json' },
      render: (_args, value) => [{ type: 'text', text: renderJson(value) }],
    },
    timeoutMs: 60_000,
    isConcurrencySafe: () => true,
    async execute(args, exec) {
      const envelope = await office.run({
        verb: 'get',
        file: args.file,
        args: [args.path ?? '/'],
        flags: { depth: args.depth },
      }, exec.signal)
      return envelope.data as JsonValue
    },
    presentCall: (args) => genericCall(`get ${args.file} ${args.path ?? '/'}`, args.path ?? '/'),
  }))
}
