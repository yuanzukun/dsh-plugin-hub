/**
 * `office_set`: modify document element properties.
 * @module dsh-office-tool/tools/set
 */

import { Context } from '@deepseek-ai/cordis'
import { defineTool, type JsonValue } from '@deepseek-ai/dsh-tools'
import type { OfficeService } from '../service.ts'
import { genericCall, stringifyProps, warningsOf } from './common.ts'

/** Register the `office_set` tool. */
export function applyOfficeSetTool(ctx: Context, office: OfficeService): void {
  ctx.tools.register(defineTool({
    name: 'office_set',
    description: 'Modify properties of an Office document element (text, fonts, colors, layout, formulas, ...). Path syntax as in office_get; "set /" targets the whole document. Properties are key=value pairs, e.g. {text:"Revenue grew 25%", bold:true, font:Arial, size:24, color:FF0000}.',
    parameters: {
      file: { type: 'string', required: true, description: 'Document path.' },
      path: { type: 'string', required: true, description: 'Element path to modify.' },
      props: {
        type: 'object', additionalProperties: true, required: true,
        description: 'Property map, e.g. {text:"Hello", bold:true}.',
      },
      find: { type: 'string', description: 'For text replacement: the substring to find.' },
      replace: { type: 'string', description: 'For text replacement: the replacement substring.' },
    },
    output: {
      schema: {
        type: 'object', additionalProperties: false,
        properties: {
          success: { type: 'boolean', required: true },
          path: { type: 'string', required: true },
          warnings: { type: 'array', items: { type: 'string' } },
        },
      },
      render: (args, value) => [{ type: 'text', text: value.warnings !== undefined && value.warnings.length > 0 ? `Updated ${value.path} (${value.warnings.length} warning${value.warnings.length === 1 ? '' : 's'}).` : `Updated ${value.path}.` }],
    },
    timeoutMs: 60_000,
    isConcurrencySafe: () => false,
    async execute(args, exec) {
      const envelope = await office.run({
        verb: 'set',
        file: args.file,
        args: [args.path],
        props: stringifyProps(args.props as Record<string, JsonValue>),
        flags: { find: args.find, replace: args.replace },
      }, exec.signal)
      const warnings = warningsOf(envelope.data)
      return { success: true, path: args.path, ...warnings !== undefined ? { warnings } : {} }
    },
    presentCall: (args) => genericCall(`set ${args.file} ${args.path}`, Object.keys(args.props).join(', ')),
  }))
}
