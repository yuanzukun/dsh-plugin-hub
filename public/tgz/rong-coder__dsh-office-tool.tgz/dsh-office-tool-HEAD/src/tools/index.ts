/**
 * Aggregates the office_* model-facing tools onto `ctx.tools`. Each tool is a
 * pure Consumer: it owns its schema, description, timeout, and presentation,
 * and executes through `ctx.office` (never the binary directly).
 * @module dsh-office-tool/tools
 */

import type { Context } from '@deepseek-ai/cordis'
import type {} from '@deepseek-ai/dsh-tools'
import type { OfficeService } from '../service.ts'
import { applyOfficeAddTool } from './add.ts'
import { applyOfficeBatchTool } from './batch.ts'
import { applyOfficeCliTool } from './cli.ts'
import { applyOfficeCreateTool } from './create.ts'
import { applyOfficeGetTool } from './get.ts'
import { applyOfficeQueryTool } from './query.ts'
import { applyOfficeRemoveTool } from './remove.ts'
import { applyOfficeSetTool } from './set.ts'
import { applyOfficeViewTool } from './view.ts'

/**
 * Register the full office_* tool set (8 typed tools + the `office_cli`
 * passthrough). Every registration is effect-scoped and unregisters on plugin
 * dispose.
 * @param ctx - context whose `tools` registry receives the tools.
 * @param office - the resolved office service.
 */
export function applyOfficeTools(ctx: Context, office: OfficeService): void {
  applyOfficeCreateTool(ctx, office)
  applyOfficeGetTool(ctx, office)
  applyOfficeQueryTool(ctx, office)
  applyOfficeSetTool(ctx, office)
  applyOfficeAddTool(ctx, office)
  applyOfficeRemoveTool(ctx, office)
  applyOfficeViewTool(ctx, office)
  applyOfficeBatchTool(ctx, office)
  applyOfficeCliTool(ctx, office)
}
