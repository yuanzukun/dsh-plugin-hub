/**
 * `office_add`: add a document element (slide/shape/paragraph/row/sheet/...).
 * @module dsh-office-tool/tools/add
 */

import { Context } from '@deepseek-ai/cordis'
import { defineTool, type JsonValue } from '@deepseek-ai/dsh-tools'
import type { OfficeService } from '../service.ts'
import { extractPath, genericCall, stringifyProps, warningsOf } from './common.ts'

/** Register the `office_add` tool. */
export function applyOfficeAddTool(ctx: Context, office: OfficeService): void {
  ctx.tools.register(defineTool({
    name: 'office_add',
    description: 'Add a document element: a slide, shape, paragraph, run, table, row, sheet, chart, etc. Parent is an existing element path (or "/" for the document root); type names the element kind (e.g. slide, shape, paragraph, chart, sheet, pivot...). Use props for the element content. --after/--before/--index position the new element; --from clones an existing element.',
    parameters: {
      file: { type: 'string', required: true, description: 'Document path.' },
      parent: { type: 'string', required: true, description: 'Parent element path to add under (e.g. "/", "/slide[1]").' },
      type: { type: 'string', required: true, description: 'Element type, e.g. "slide", "shape", "paragraph", "chart", "sheet".' },
      props: {
        type: 'object', additionalProperties: true,
        description: 'Element properties, e.g. {title:"Q4 Report", background:1A1A2E} for a slide or {text:"Revenue", x:"2cm", y:"5cm"} for a shape.',
      },
      after: { type: 'string', description: 'Insert after this sibling path (mutually exclusive with before/index).' },
      before: { type: 'string', description: 'Insert before this sibling path (mutually exclusive with after/index).' },
      index: { type: 'integer', description: 'Insert at this 0-based sibling index (mutually exclusive with after/before).' },
      from: { type: 'string', description: 'Clone an existing element from this path instead of creating blank.' },
    },
    output: {
      schema: {
        type: 'object', additionalProperties: false,
        properties: {
          success: { type: 'boolean', required: true },
          path: { type: 'string', required: true },
          warnings: { type: 'array', items: { type: 'string' } },
        },
      },
      render: (args, value) => [{ type: 'text', text: `Added ${args.type} at ${value.path}.` }],
    },
    timeoutMs: 60_000,
    isConcurrencySafe: () => false,
    async execute(args, exec) {
      const envelope = await office.run({
        verb: 'add',
        file: args.file,
        args: [args.parent],
        props: stringifyProps(args.props as Record<string, JsonValue>),
        flags: { type: args.type, after: args.after, before: args.before, index: args.index, from: args.from },
      }, exec.signal)
      const warnings = warningsOf(envelope.data)
      return { success: true, path: extractPath(envelope.data) ?? args.parent, ...warnings !== undefined ? { warnings } : {} }
    },
    presentCall: (args) => genericCall(`add ${args.type} to ${args.file}`, args.parent),
  }))
}
