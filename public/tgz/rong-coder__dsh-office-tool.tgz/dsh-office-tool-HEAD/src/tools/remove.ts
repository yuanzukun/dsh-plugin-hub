/**
 * `office_remove`: remove a document element.
 * @module dsh-office-tool/tools/remove
 */

import { Context } from '@deepseek-ai/cordis'
import { defineTool } from '@deepseek-ai/dsh-tools'
import type { OfficeService } from '../service.ts'
import { genericCall } from './common.ts'

/** Register the `office_remove` tool. */
export function applyOfficeRemoveTool(ctx: Context, office: OfficeService): void {
  ctx.tools.register(defineTool({
    name: 'office_remove',
    description: 'Remove an element from an Office document (slide, shape, paragraph, row, cell, sheet, ...). Path syntax as in office_get.',
    parameters: {
      file: { type: 'string', required: true, description: 'Document path.' },
      path: { type: 'string', required: true, description: 'Element path to remove.' },
      shift: { type: 'string', enum: ['left', 'up'], description: 'Excel only: shift adjacent cells left or up after removal.' },
    },
    output: {
      schema: {
        type: 'object', additionalProperties: false,
        properties: {
          success: { type: 'boolean', required: true },
          path: { type: 'string', required: true },
        },
      },
      render: (args) => [{ type: 'text', text: `Removed ${args.path}.` }],
    },
    timeoutMs: 60_000,
    isConcurrencySafe: () => false,
    async execute(args, exec) {
      await office.run({
        verb: 'remove',
        file: args.file,
        args: [args.path],
        flags: { shift: args.shift },
      }, exec.signal)
      return { success: true, path: args.path }
    },
    presentCall: (args) => genericCall(`remove ${args.path}`, args.path),
  }))
}
