/**
 * `office_view`: view document content as text/outline/annotated/stats/issues,
 * or get a preview URL for the sidebar-rendered HTML/screenshot.
 * @module dsh-office-tool/tools/view
 */

import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { Context } from '@deepseek-ai/cordis'
import { defineTool } from '@deepseek-ai/dsh-tools'
import { OfficeError, truncate } from '../service.ts'
import type { OfficeService } from '../service.ts'
import { genericCall } from './common.ts'

/** Text-producing view modes (their output is the envelope `data` string). */
const TEXT_MODES = ['text', 'outline', 'annotated', 'stats', 'issues'] as const

/** Register the `office_view` tool. */
export function applyOfficeViewTool(ctx: Context, office: OfficeService): void {
  ctx.tools.register(defineTool({
    name: 'office_view',
    description: 'View an Office document. Modes: text, outline, annotated, stats, issues return content as text; html and screenshot return a preview URL for the sidebar/UI (html) or render a PNG (screenshot). Use --page to target one slide/page/sheet.',
    parameters: {
      file: { type: 'string', required: true, description: 'Document path.' },
      mode: {
        type: 'string', required: true,
        enum: [...TEXT_MODES, 'html', 'screenshot'],
        description: 'View mode.',
      },
      page: { type: 'string', description: 'Page/slide filter, e.g. "2" or "1-5" (pptx/docx) or a sheet name (xlsx).' },
      cols: { type: 'string', description: 'Excel only: column letters to include, e.g. "A,B,C".' },
      maxLines: { type: 'integer', description: 'Cap the number of lines returned (>=1, default unlimited).' },
    },
    output: {
      schema: {
        type: 'object', additionalProperties: false,
        properties: {
          mode: { type: 'string', required: true },
          content: { type: 'string' },
          previewUrl: { type: 'string' },
          outputPath: { type: 'string' },
        },
      },
      render: (_args, value) => {
        if (value.mode === 'html') return [{ type: 'text', text: `Preview ready: open the sidebar (or this URL) to see the rendered document: ${value.previewUrl ?? ''}` }]
        if (value.mode === 'screenshot') return [{ type: 'text', text: `Rendered screenshot to ${value.outputPath ?? ''}. Preview: ${value.previewUrl ?? ''}` }]
        return [{ type: 'text', text: value.content ?? '' }]
      },
    },
    timeoutMs: 120_000,
    isConcurrencySafe: (args) => (TEXT_MODES as readonly string[]).includes(args.mode),
    async execute(args, exec) {
      const { mode } = args
      if ((TEXT_MODES as readonly string[]).includes(mode)) {
        const envelope = await office.run({
          verb: 'view',
          file: args.file,
          args: [mode],
          flags: { page: args.page, cols: args.cols, 'max-lines': args.maxLines },
        }, exec.signal)
        return { mode, content: String(envelope.data) }
      }
      if (mode === 'html') {
        return { mode, previewUrl: office.previewUrl(args.file, pageOpt(args.page)) }
      }
      // screenshot: render a PNG through officecli (needs a headless browser).
      const outputPath = join(tmpdir(), `officecli-shot-${process.pid}-${Date.now()}.png`)
      const raw = await office.runRaw(office.buildArgv({
        verb: 'view',
        file: args.file,
        args: ['screenshot'],
        flags: { out: outputPath, ...pageOpt(args.page) },
        json: false,
      }), { signal: exec.signal })
      if (raw.exitCode !== 0) {
        throw new OfficeError(`officecli view screenshot failed: ${truncate(`${raw.stdout}\n${raw.stderr}`, 300)}`, { code: 'office_command_failed', exitCode: raw.exitCode ?? undefined })
      }
      return { mode, previewUrl: office.previewUrl(args.file, pageOpt(args.page)), outputPath: raw.stdout.trim() || outputPath }
    },
    presentCall: (args) => genericCall(`view ${args.file} ${args.mode}`, args.mode),
  }))
}

/** Normalize a page filter into the flags shape. */
function pageOpt(page: string | undefined): { page?: string } {
  return page !== undefined ? { page } : {}
}
