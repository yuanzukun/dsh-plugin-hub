/**
 * `office_query`: query document elements with a CSS-like selector.
 * @module dsh-office-tool/tools/query
 */

import { Context } from '@deepseek-ai/cordis'
import { defineTool, type JsonValue } from '@deepseek-ai/dsh-tools'
import type { OfficeService } from '../service.ts'
import { genericCall, renderJson } from './common.ts'

/** Register the `office_query` tool. */
export function applyOfficeQueryTool(ctx: Context, office: OfficeService): void {
  ctx.tools.register(defineTool({
    name: 'office_query',
    description: 'Query Office document elements with a CSS-like selector, e.g. "run:contains(TODO)", "paragraph[style=Heading1]", "shape", or Excel "row[Salary>5000 and Region=EMEA]" within "Sheet1!row[...]". Returns matching elements as JSON.',
    parameters: {
      file: { type: 'string', required: true, description: 'Document path.' },
      selector: { type: 'string', required: true, description: 'CSS-like selector (element type plus optional attribute filters with and/or).' },
      limit: { type: 'integer', description: 'Maximum number of results, 1-500 (default unlimited).' },
    },
    output: {
      schema: {
        type: 'object', additionalProperties: false,
        properties: {
          matches: { type: 'integer', required: true },
          results: { type: 'array', required: true },
        },
      },
      render: (_args, value) => [{ type: 'text', text: `${value.matches} match${value.matches === 1 ? '' : 'es'}:\n${renderJson(value.results)}` }],
    },
    timeoutMs: 60_000,
    isConcurrencySafe: () => true,
    async execute(args, exec) {
      const envelope = await office.run({
        verb: 'query',
        file: args.file,
        args: [args.selector],
        flags: { limit: args.limit },
      }, exec.signal)
      const data = envelope.data
      const results: JsonValue[] = Array.isArray(data) ? data : [data]
      return { matches: results.length, results }
    },
    presentCall: (args) => genericCall(`query ${args.file} ${args.selector}`, args.selector),
  }))
}
