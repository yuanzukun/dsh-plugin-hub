/**
 * `office_create`: create a blank Office document (.docx/.xlsx/.pptx).
 * @module dsh-office-tool/tools/create
 */

import { Context } from '@deepseek-ai/cordis'
import { defineTool } from '@deepseek-ai/dsh-tools'
import type { OfficeService } from '../service.ts'
import { genericCall } from './common.ts'

/** Register the `office_create` tool. */
export function applyOfficeCreateTool(ctx: Context, office: OfficeService): void {
  ctx.tools.register(defineTool({
    name: 'office_create',
    description: 'Create a blank Office document (.docx/.xlsx/.pptx). The type is inferred from the file extension unless `type` is given. Use `office_set`/`office_add` afterwards to populate it.',
    parameters: {
      file: { type: 'string', required: true, description: 'Output path, e.g. "report.docx" or "deck.pptx".' },
      type: { type: 'string', enum: ['docx', 'xlsx', 'pptx'], description: 'Document type; inferred from the file extension when omitted.' },
      force: { type: 'boolean', description: 'Overwrite the file if it already exists.' },
    },
    output: {
      schema: {
        type: 'object', additionalProperties: false,
        properties: {
          success: { type: 'boolean', required: true },
          file: { type: 'string', required: true },
          message: { type: 'string' },
        },
      },
      render: (_args, value) => [{ type: 'text', text: `Created ${value.file}.` }],
    },
    timeoutMs: 60_000,
    isConcurrencySafe: () => false,
    async execute(args, exec) {
      const envelope = await office.run({
        verb: 'create',
        file: args.file,
        flags: { type: args.type, force: args.force },
      }, exec.signal)
      return { success: true, file: args.file, ...envelope.message !== undefined ? { message: envelope.message } : {} }
    },
    presentCall: (args) => genericCall(`create ${args.file}`, args.file),
  }))
}
