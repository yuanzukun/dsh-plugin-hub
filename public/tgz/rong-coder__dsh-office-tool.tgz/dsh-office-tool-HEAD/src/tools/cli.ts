/**
 * `office_cli`: raw officecli passthrough — the fallback tool covering every
 * command without a dedicated tool (merge, dump, import, validate, raw,
 * raw-set, move, swap, refresh, help, ...). The model supplies the command
 * line as an argv array.
 * @module dsh-office-tool/tools/cli
 */

import { Context } from '@deepseek-ai/cordis'
import { defineTool, type JsonValue } from '@deepseek-ai/dsh-tools'
import { parseEnvelope, truncate } from '../service.ts'
import type { OfficeService } from '../service.ts'
import { genericCall } from './common.ts'

/** Register the `office_cli` passthrough tool. */
export function applyOfficeCliTool(ctx: Context, office: OfficeService): void {
  ctx.tools.register(defineTool({
    name: 'office_cli',
    description: 'Run an arbitrary officecli command line (the fallback tool). Pass the command verb and arguments as an argv array, e.g. ["merge","in.pptx","out.pptx","--data",\'{"client":"Acme"}\'] or ["validate","report.docx"]. Returns stdout (parsed as JSON when --json is passed). Covers commands without a dedicated tool: move, swap, merge, dump, import, validate, raw, raw-set, refresh, help, load_skill.',
    parameters: {
      argv: {
        type: 'array', required: true,
        items: { type: 'string' },
        description: 'officecli command line arguments (verb first).',
      },
    },
    output: {
      schema: {
        type: 'object', additionalProperties: false,
        properties: {
          ok: { type: 'boolean', required: true },
          exitCode: { required: true, oneOf: [{ type: 'integer' }, { type: 'null' }] },
          stdout: { type: 'string', required: true },
          stderr: { type: 'string', required: true },
          data: { type: 'json' },
          error: { type: 'object', additionalProperties: true },
        },
      },
      render: (_args, value) => {
        if (value.ok && value.data !== undefined) return [{ type: 'text', text: JSON.stringify(value.data, null, 2) }]
        const text = value.stdout.length > 0 ? value.stdout : value.stderr
        return [{ type: 'text', text: truncate(text, 4000) }]
      },
    },
    timeoutMs: 120_000,
    isConcurrencySafe: (args) => isReadOnlyArgv(args.argv),
    async execute(args, exec) {
      const full = office.buildArgv({ verb: 'cli', args: args.argv })
      const raw = await office.runRaw(full, { signal: exec.signal })
      const envelope = parseEnvelope(raw.stdout)
      const ok = raw.exitCode === 0
      const result: OfficeCliResult = { ok, exitCode: raw.exitCode, stdout: raw.stdout, stderr: raw.stderr }
      if (envelope !== undefined && envelope.success) result.data = envelope.data
      if (envelope !== undefined && !envelope.success) result.error = envelope.error
      if (!ok && result.error === undefined && raw.stderr.length > 0) {
        result.error = { error: truncate(raw.stderr, 300) }
      }
      return result
    },
    presentCall: (args) => genericCall(`officecli ${args.argv.join(' ')}`, args.argv[0] ?? ''),
  }))
}

/** The `office_cli` output value. */
interface OfficeCliResult {
  ok: boolean
  exitCode: number | null
  stdout: string
  stderr: string
  data?: JsonValue
  error?: { error: string; code?: string; suggestion?: string }
}

/** Pure classifier: argv whose first token is a read-only verb may run in parallel. */
function isReadOnlyArgv(argv: readonly string[]): boolean {
  const verb = argv[0]?.toLowerCase()
  if (verb === undefined) return true
  return ['get', 'query', 'view', 'validate', 'raw', 'help', 'dump'].includes(verb)
}
