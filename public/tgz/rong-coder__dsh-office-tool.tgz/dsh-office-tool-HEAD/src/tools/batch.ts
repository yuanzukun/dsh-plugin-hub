/**
 * `office_batch`: apply multiple operations to a document in one pass.
 * @module dsh-office-tool/tools/batch
 */

import { Context } from '@deepseek-ai/cordis'
import { defineTool, type JsonValue } from '@deepseek-ai/dsh-tools'
import type { OfficeService } from '../service.ts'
import { genericCall, renderJson } from './common.ts'

/** Register the `office_batch` tool. */
export function applyOfficeBatchTool(ctx: Context, office: OfficeService): void {
  ctx.tools.register(defineTool({
    name: 'office_batch',
    description: 'Apply a sequence of operations to one document atomically (any failed item rolls back the whole batch). Each command is {op, path, parent, type, props}, where op is one of add/set/remove/get/query/move/swap/view. Prefer batch for multi-step edits — one call, one atomic transaction.',
    parameters: {
      file: { type: 'string', required: true, description: 'Document path.' },
      commands: {
        type: 'array', required: true,
        items: { type: 'object', additionalProperties: true },
        description: 'Operations to apply, e.g. [{"op":"add","parent":"/","type":"slide","props":{"title":"Q4"}},{"op":"set","path":"/slide[1]/shape[1]","props":{"text":"Revenue"}}].',
      },
      bestEffort: { type: 'boolean', description: 'Keep whatever succeeds even if some items fail (default: atomic rollback).' },
    },
    output: {
      schema: {
        type: 'object', additionalProperties: false,
        properties: {
          success: { type: 'boolean', required: true },
          summary: { type: 'json', required: true },
        },
      },
      render: (_args, value) => [{ type: 'text', text: `Batch ${value.success ? 'succeeded' : 'failed'}:\n${renderJson(value.summary, 2000)}` }],
    },
    timeoutMs: 120_000,
    isConcurrencySafe: () => false,
    async execute(args, exec) {
      const envelope = await office.run({
        verb: 'batch',
        file: args.file,
        flags: { commands: JSON.stringify(args.commands), 'best-effort': args.bestEffort },
      }, exec.signal)
      return { success: true, summary: envelope.data as JsonValue }
    },
    presentCall: (args) => genericCall(`batch ${args.file} (${args.commands.length} ops)`, `${args.commands.length} ops`),
  }))
}
