/**
 * Shared helpers for the office_* tools: call-card presentation and JSON
 * rendering. Presenters are pure functions of args/values — no I/O.
 * @module dsh-office-tool/tools/common
 */

import type { GenericCallView, JsonValue } from '@deepseek-ai/dsh-tools'

/** A generic pending-call card titled by the operation. */
export function genericCall(title: string, rawInput: string): GenericCallView {
  return { card: 'generic', title, rawInput }
}

/** Pretty-print a JSON value for the model, capped to `max` characters. */
export function renderJson(value: unknown, max = 4000): string {
  const text = JSON.stringify(value, null, 2)
  if (text.length <= max) return text
  return `${text.slice(0, max)}\n… (output truncated at ${max} characters)`
}

/** Extract the created/modified element path from an officecli mutation result. */
export function extractPath(data: JsonValue | undefined): string | undefined {
  if (data === undefined) return undefined
  if (typeof data === 'string') return data
  if (typeof data === 'object' && data !== null && !Array.isArray(data)) {
    const path = (data as { path?: unknown }).path
    if (typeof path === 'string') return path
  }
  return undefined
}

/** Whether a mutation confirmation object carries warnings (strings). */
export function warningsOf(data: JsonValue | undefined): string[] | undefined {
  if (typeof data !== 'object' || data === null || Array.isArray(data)) return undefined
  const warnings = (data as { warnings?: unknown }).warnings
  return Array.isArray(warnings) ? warnings.filter((w): w is string => typeof w === 'string') : undefined
}

/**
 * Flatten model-supplied `props` (any JSON values) into the scalar `--prop
 * key=value` vocabulary officecli expects. Objects/arrays collapse to JSON
 * strings; null becomes the literal `null`.
 */
export function stringifyProps(props: Record<string, JsonValue> | undefined): Record<string, string | number | boolean> | undefined {
  if (props === undefined) return undefined
  const out: Record<string, string | number | boolean> = {}
  for (const [key, value] of Object.entries(props)) {
    if (value === null) out[key] = 'null'
    else if (typeof value === 'object') out[key] = JSON.stringify(value)
    else out[key] = value
  }
  return out
}
