/**
 * Path resolution for the preview routes. better-sidebar's file viewers pass a
 * `path` (absolute or relative to the session cwd) plus a `cwd`; the preview
 * routes resolve that to an absolute file path before handing it to officecli.
 * The extension allowlist keeps the renderer off non-Office files.
 * @module dsh-office-tool/paths
 */

import { extname, resolve as resolvePath } from 'node:path'

/** Allowed preview document extensions (lowercase). */
export const OFFICE_EXTENSIONS = ['.docx', '.xlsx', '.pptx'] as const

/** The outcome of {@link resolvePreviewPath}. */
export type ResolvedPath =
  | { ok: true; abs: string }
  | { ok: false; status: number; error: string; code: string }

/**
 * Resolve a viewer-provided path to an absolute Office file path.
 * @param path - absolute path, or relative to `cwd` (else the host cwd).
 * @param cwd - the session working directory, when known.
 * @returns the canonical absolute path, or a structured refusal.
 */
export function resolvePreviewPath(path: string | null, cwd?: string | null): ResolvedPath {
  if (path === null || path.trim().length === 0) {
    return { ok: false, status: 400, error: 'missing "path" query parameter', code: 'invalid_path' }
  }
  // `resolve` normalizes separators on Windows too, so an absolute path given
  // with forward slashes matches the workspace check exactly like a relative one.
  const candidate = resolvePath(cwd ?? process.cwd(), path)
  const extension = extname(candidate).toLowerCase()
  if (!(OFFICE_EXTENSIONS as readonly string[]).includes(extension)) {
    return { ok: false, status: 415, error: `unsupported file type "${extension}" (expected ${OFFICE_EXTENSIONS.join(', ')})`, code: 'unsupported_type' }
  }
  return { ok: true, abs: candidate }
}
