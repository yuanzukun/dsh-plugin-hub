/**
 * `/office/preview`: render an Office document to self-contained HTML via
 * officecli's `view html` on demand and stream it to the browser. The
 * better-sidebar file viewer iframes this route; the tools return its URL.
 * A `probe=1` request stats the file cheaply for the viewer's auto-reload.
 * @module dsh-office-tool/preview/route
 */

import type { IncomingMessage, ServerResponse } from 'node:http'
import { stat } from 'node:fs/promises'
import type { WebServer } from '@deepseek-ai/dsh-host-webserver'
import { resolvePreviewPath } from '../paths.ts'
import { OfficeError, truncate } from '../service.ts'
import type { OfficeService } from '../service.ts'

/** Preview-route configuration. */
export interface PreviewConfig {
  /** Allow rendering absolute paths outside the workspace (default false). */
  allowOutsideWorkspace?: boolean
}

/**
 * Register the `/office/preview` route on an already-available web server.
 * @param webServer - the web server service (obtained reactively by the caller).
 * @param office - the office service.
 * @param config - preview configuration.
 * @returns the route disposer.
 */
export function registerPreviewRoute(webServer: WebServer, office: OfficeService, config: PreviewConfig = {}): () => void {
  return webServer.register({
    kind: 'prefix',
    path: '/office/preview',
    handler: (req, res) => handlePreviewRequest(office, config, req, res),
  })
}

/** Dispatch one `/office/preview` request. */
async function handlePreviewRequest(office: OfficeService, config: PreviewConfig, req: IncomingMessage, res: ServerResponse): Promise<void> {
  const url = new URL(req.url ?? '/', 'http://localhost')
  const path = url.searchParams.get('path')
  const cwd = url.searchParams.get('cwd')
  if (url.searchParams.get('probe') === '1') {
    await handleProbe(path, cwd, res)
    return
  }
  const resolved = resolvePreviewPath(path, cwd)
  if (!resolved.ok) {
    writeJson(res, resolved.status, { success: false, error: { error: resolved.error, code: resolved.code } })
    return
  }
  if (config.allowOutsideWorkspace !== true && !isInsideWorkspace(resolved.abs)) {
    writeJson(res, 403, { success: false, error: { error: 'path resolves outside the workspace; set preview.allowOutsideWorkspace to allow it', code: 'outside_workspace' } })
    return
  }
  const page = url.searchParams.get('page')
  try {
    const raw = await office.runRaw(office.buildArgv({
      verb: 'view',
      file: resolved.abs,
      args: ['html'],
      flags: page !== null && page.length > 0 ? { page } : {},
      json: false,
    }))
    if (raw.exitCode !== 0) {
      writeJson(res, 422, { success: false, error: { error: truncate(`${raw.stdout}\n${raw.stderr}`, 400), code: 'render_failed' } })
      return
    }
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-cache' })
    res.end(raw.stdout)
  } catch (error) {
    writeJson(res, 500, officeErrorBody(error))
  }
}

/** Cheap `?probe=1` handler: report the file's mtime so the viewer can reload. */
async function handleProbe(path: string | null, cwd: string | null, res: ServerResponse): Promise<void> {
  const resolved = resolvePreviewPath(path, cwd)
  if (!resolved.ok) {
    writeJson(res, resolved.status, { success: false, error: { error: resolved.error, code: resolved.code } })
    return
  }
  try {
    const info = await stat(resolved.abs)
    writeJson(res, 200, { success: true, mtime: info.mtimeMs })
  } catch {
    writeJson(res, 404, { success: false, error: { error: 'file not found', code: 'file_not_found' } })
  }
}

/** Whether an absolute path sits under the host working directory (the workspace). */
function isInsideWorkspace(abs: string): boolean {
  const root = process.cwd().replace(/[\\/]$/, '')
  const lower = abs.toLowerCase()
  const lowerRoot = root.toLowerCase()
  return lower === lowerRoot || lower.startsWith(`${lowerRoot}${process.platform === 'win32' ? '\\' : '/'}`)
}

/** Write a JSON response. */
function writeJson(res: ServerResponse, status: number, body: unknown): void {
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8' })
  res.end(JSON.stringify(body))
}

/** Map any thrown error to a structured body. */
function officeErrorBody(error: unknown): { success: false; error: { error: string; code: string } } {
  if (error instanceof OfficeError) return { success: false, error: { error: error.message, code: error.code } }
  return { success: false, error: { error: String(error), code: 'internal_error' } }
}
