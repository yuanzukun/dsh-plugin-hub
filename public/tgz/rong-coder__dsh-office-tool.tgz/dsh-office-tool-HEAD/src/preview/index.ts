/**
 * dsh-office-tool web-preview half (plugin `dsh-office-tool/preview`). Mounts
 * the `/office/preview` render route and the `/office/watch` live-preview route
 * onto `ctx.webServer` — but only once a web server actually exists. The plugin
 * injects only `office` (always available once the tools host activates), so it
 * activates in headless profiles too: there it registers a `webServer` arrival
 * listener and no routes, and a pending entry never fails the boot.
 * @module dsh-office-tool/preview
 */

import { Context } from '@deepseek-ai/cordis'
import type { WebServer } from '@deepseek-ai/dsh-host-webserver'
import type {} from '@deepseek-ai/dsh-host-webserver'
import type { PreviewConfig } from './route.ts'
import { registerPreviewRoute } from './route.ts'
import { registerWatchRoute, WatchManager } from './watch.ts'

/** Plugin name (row `name` in cordis.patch.yml). */
export const name = 'office-tool-preview'

/** Host services required before activation: the office service only. */
export const inject = ['office']

/** Preview-half configuration. */
export interface Config {
  preview?: PreviewConfig
  watch?: {
    enabled?: boolean
    idleSeconds?: number
  }
}

/**
 * Apply the web-preview half. Registers the render and watch routes reactively
 * when `ctx.webServer` becomes available, and stops every watch process on
 * plugin disposal.
 * @param ctx - host context (`office`).
 * @param config - preview configuration.
 */
export function apply(ctx: Context, config: Config = {}): void {
  const office = ctx.office
  const previewConfig = config.preview ?? {}
  const watchEnabled = config.watch?.enabled !== false
  const watch = watchEnabled ? new WatchManager(ctx, office) : undefined

  // Register the routes once webServer exists; no-op in headless profiles.
  registerWhenWebServer(ctx, (webServer) => {
    const disposers: (() => void)[] = [registerPreviewRoute(webServer, office, previewConfig)]
    if (watch !== undefined) disposers.push(registerWatchRoute(webServer, watch))
    return () => {
      for (const disposer of disposers) disposer()
    }
  })

  // Stop every watch subprocess when this plugin fiber disposes.
  if (watch !== undefined) {
    ctx.effect(() => () => watch.dispose(), 'dsh-office-tool: watch cleanup')
  }
}

/**
 * Run `register` exactly once, either with the already-present `webServer` or
 * when the `internal/service` event reports its arrival. The registration and
 * the listener are both effect-scoped so disposal unwinds cleanly.
 * @param ctx - the plugin context (its `root` receives the global service event).
 * @param register - builds the route registrations from the web server.
 */
function registerWhenWebServer(ctx: Context, register: (webServer: WebServer) => () => void): void {
  const root = ctx.root
  const existing = root.get('webServer') as WebServer | undefined
  if (existing !== undefined) {
    ctx.effect(() => register(existing), 'dsh-office-tool: preview routes')
    return
  }
  let registered = false
  const listener = (name: string, value: unknown): void => {
    if (registered || name !== 'webServer' || value === undefined) return
    registered = true
    unsubscribe()
    ctx.effect(() => register(value as WebServer), 'dsh-office-tool: preview routes')
  }
  const unsubscribe = root.on('internal/service', listener)
  ctx.effect(() => () => {
    if (!registered) unsubscribe()
  }, 'dsh-office-tool: webServer listener')
}
