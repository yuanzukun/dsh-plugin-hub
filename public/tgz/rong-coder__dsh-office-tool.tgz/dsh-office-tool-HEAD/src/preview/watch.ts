/**
 * `officecli watch` process manager plus the `/office/watch` JSON route. One
 * watch process per document (officecli enforces this itself); the tab client
 * calls this route to start/stop a live preview and gets the loopback URL to
 * iframe. All processes are terminated when the plugin fiber disposes.
 * @module dsh-office-tool/preview/watch
 */

import type { IncomingMessage, ServerResponse } from 'node:http'
import { Context } from '@deepseek-ai/cordis'
import type { WebServer } from '@deepseek-ai/dsh-host-webserver'
import type { SubprocessHandle, SubprocessRuntime } from '@deepseek-ai/dsh-subprocess'
import { resolvePreviewPath } from '../paths.ts'
import { OfficeError } from '../service.ts'
import type { OfficeService } from '../service.ts'

const WATCH_URL_PATTERN = /http:\/\/localhost:(\d+)/
const MAX_WATCH_STARTUP_MS = 5_000
const WATCH_START_POLL_MS = 100

/** The live-preview facts for one watched file. */
export interface WatchInfo {
  port: number
  url: string
}

/**
 * Owns the live `officecli watch` subprocesses for the preview tab. Keys are
 * canonical absolute file paths; `start` is idempotent per file.
 */
export class WatchManager {
  private readonly watches = new Map<string, { handle: SubprocessHandle } & WatchInfo>()

  constructor(
    private readonly ctx: Context,
    private readonly office: OfficeService,
  ) {}

  /** Whether a file is currently being watched. */
  isWatching(file: string): boolean {
    return this.watches.has(file)
  }

  /** The live info for a watched file, if any. */
  get(file: string): WatchInfo | undefined {
    const watch = this.watches.get(file)
    return watch !== undefined ? { port: watch.port, url: watch.url } : undefined
  }

  /**
   * Start (or reuse) the watch process for one file.
   * @param file - canonical absolute path.
   * @returns the loopback URL the browser tab iframes.
   */
  async start(file: string): Promise<WatchInfo> {
    const existing = this.watches.get(file)
    if (existing !== undefined) return { port: existing.port, url: existing.url }
    const argv = this.office.buildArgv({ verb: 'watch', file, flags: { port: 0 }, json: false })
    const subprocess = this.ctx.get('subprocess') as SubprocessRuntime
    const handle = subprocess.spawn({
      argv,
      cwd: process.cwd(),
      stdio: {
        stdin: 'ignore',
        stdout: { maxBytes: 64 * 1024 },
        stderr: { maxBytes: 64 * 1024 },
      },
      graceMs: 2_000,
    })
    const info = await waitForWatchUrl(handle)
    this.watches.set(file, { handle, ...info })
    return info
  }

  /**
   * Stop the watch process for one file (`officecli unwatch` + terminate).
   * @param file - canonical absolute path.
   */
  async stop(file: string): Promise<void> {
    const watch = this.watches.get(file)
    if (watch === undefined) return
    this.watches.delete(file)
    // Tell the watch server to shut down cleanly (best-effort), then force.
    void this.office.run({ verb: 'unwatch', file, json: true }).catch(() => {})
    watch.handle.terminate()
  }

  /** Terminate every watch process (fiber disposal). */
  dispose(): void {
    for (const { handle } of this.watches.values()) handle.terminate()
    this.watches.clear()
  }
}

/**
 * Register the `/office/watch` JSON route on an already-available web server.
 * @param webServer - the web server service (obtained reactively by the caller).
 * @param watch - the watch manager.
 * @returns the route disposer.
 */
export function registerWatchRoute(webServer: WebServer, watch: WatchManager): () => void {
  return webServer.register({
    kind: 'prefix',
    path: '/office/watch',
    handler: (req, res) => handleWatchRequest(watch, req, res),
  })
}

/** Dispatch one `/office/watch` request (open / close / status). */
async function handleWatchRequest(watch: WatchManager, req: IncomingMessage, res: ServerResponse): Promise<void> {
  const url = new URL(req.url ?? '/', 'http://localhost')
  const action = url.searchParams.get('action') ?? 'status'
  const path = url.searchParams.get('path')
  const cwd = url.searchParams.get('cwd')
  const resolved = path !== null ? resolvePreviewPath(path, cwd) : undefined

  if (action === 'open') {
    if (resolved === undefined || !resolved.ok) {
      writeJson(res, 400, { ok: false, watching: false, error: { error: resolved?.error ?? 'missing "path"', code: resolved?.code ?? 'invalid_path' } })
      return
    }
    try {
      const info = await watch.start(resolved.abs)
      writeJson(res, 200, { ok: true, watching: true, port: info.port, url: info.url })
    } catch (error) {
      writeJson(res, 500, { ok: false, watching: false, error: { error: String(error), code: 'office_watch_failed' } })
    }
    return
  }

  if (action === 'close') {
    if (resolved === undefined || !resolved.ok) {
      writeJson(res, 400, { ok: false, watching: false, error: { error: resolved?.error ?? 'missing "path"', code: resolved?.code ?? 'invalid_path' } })
      return
    }
    await watch.stop(resolved.abs)
    writeJson(res, 200, { ok: true, watching: false })
    return
  }

  // status (default)
  const info = resolved !== undefined && resolved.ok ? watch.get(resolved.abs) : undefined
  writeJson(res, 200, { ok: true, watching: info !== undefined, ...info !== undefined ? { port: info.port, url: info.url } : {} })
}

/** Wait until officecli watch prints its listen line and parse the port. */
async function waitForWatchUrl(handle: SubprocessHandle): Promise<WatchInfo> {
  const deadline = Date.now() + MAX_WATCH_STARTUP_MS
  let offset = 0
  for (;;) {
    const read = handle.collected.stdout?.readFrom(offset)
    if (read !== undefined) {
      offset = read.nextOffset
      const match = WATCH_URL_PATTERN.exec(read.text)
      if (match?.[1] !== undefined) {
        const port = Number(match[1])
        return { port, url: `http://127.0.0.1:${port}` }
      }
    }
    const exited = await Promise.race([handle.done.then(() => true, () => true), delay(WATCH_START_POLL_MS).then(() => false)])
    if (exited) {
      throw new OfficeError(`officecli watch exited before printing its URL: ${String(handle.collected.stdout?.readFrom(0).text ?? '')}`, { code: 'office_watch_failed' })
    }
    if (Date.now() >= deadline) {
      throw new OfficeError(`officecli watch did not report a listen port within ${MAX_WATCH_STARTUP_MS}ms`, { code: 'office_watch_failed' })
    }
  }
}

/** `setTimeout` as a promise. */
function delay(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms))
}

/** Write a JSON response. */
function writeJson(res: ServerResponse, status: number, body: unknown): void {
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8' })
  res.end(JSON.stringify(body))
}

/** A failed watch start or render, surfaced as `{success:false, error:{...}}`. */
export function officeErrorBody(error: unknown): { success: false; error: { error: string; code: string } } {
  if (error instanceof OfficeError) {
    return { success: false, error: { error: error.message, code: error.code } }
  }
  return { success: false, error: { error: String(error), code: 'internal_error' } }
}
