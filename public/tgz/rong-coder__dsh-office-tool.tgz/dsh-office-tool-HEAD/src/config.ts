/**
 * dsh-office-tool host plugin configuration. No runtime schema is exported
 * (the Loader passes the patch `config` through untouched); `normalizeConfig`
 * applies defaults and validates at apply time — misconfiguration fails loud.
 * @module dsh-office-tool/config
 */

/** Validated host configuration. */
export interface OfficeConfig {
  /** officecli binary name (resolved on PATH) or absolute path. */
  command: string
  /** Extra environment entries merged onto the child's scrubbed base. */
  env?: Readonly<Record<string, string>>
  /** Per-command deadline in milliseconds. */
  timeoutMs: number
  /** stdout collection cap in bytes (overflow keeps the tail). */
  maxOutputBytes: number
}

const DEFAULTS: OfficeConfig = {
  command: 'officecli',
  timeoutMs: 60_000,
  maxOutputBytes: 16 * 1024 * 1024,
}

/** The accepted `apply` config shape: every field optional, unknown keys ignored. */
export type OfficeConfigInput = Partial<OfficeConfig>

/**
 * Apply defaults and validate the incoming config.
 * @param input - the Loader-provided plugin config (may be empty).
 * @returns the validated, defaulted configuration.
 * @throws `Error` when a provided value is out of range — loud at load.
 */
export function normalizeConfig(input: OfficeConfigInput = {}): OfficeConfig {
  const config: OfficeConfig = {
    command: input.command ?? DEFAULTS.command,
    timeoutMs: input.timeoutMs ?? DEFAULTS.timeoutMs,
    maxOutputBytes: input.maxOutputBytes ?? DEFAULTS.maxOutputBytes,
  }
  if (input.env !== undefined) config.env = input.env
  if (config.command.trim().length === 0) throw new Error('office-tool config: `command` must be a non-empty string')
  if (!Number.isInteger(config.timeoutMs) || config.timeoutMs <= 0) {
    throw new Error('office-tool config: `timeoutMs` must be a positive integer')
  }
  if (!Number.isInteger(config.maxOutputBytes) || config.maxOutputBytes <= 0) {
    throw new Error('office-tool config: `maxOutputBytes` must be a positive integer')
  }
  return config
}
