/**
 * dsh-office-tool, node half. The host plugin provides `ctx.office` (the
 * OfficeCLI service) and registers the office_* model-facing tools. The
 * web-preview half (routes + client viewer) lives in the `./preview` entry
 * and the `./client` bundle.
 *
 * The binary is resolved at load through `ctx.subprocess.resolveExecutable`;
 * a missing officecli fails loud with install guidance.
 * @module dsh-office-tool
 */

import { Context } from '@deepseek-ai/cordis'
import type {} from '@deepseek-ai/dsh-tools'
import type { SubprocessRuntime } from '@deepseek-ai/dsh-subprocess'
import { normalizeConfig, type OfficeConfigInput } from './config.ts'
import { OfficeService } from './service.ts'
import { applyOfficeTools } from './tools/index.ts'

/** Plugin name (row `name` in cordis.patch.yml). */
export const name = 'office-tool'

/** Host services required before activation: both ship with the base bundle. */
export const inject = ['subprocess', 'tools']

/** Configuration; see {@link OfficeConfigInput}. */
export type Config = OfficeConfigInput

/**
 * Apply the host half: resolve the binary, provide `ctx.office`, and register
 * the office_* tools.
 * @param ctx - host context (`subprocess`, `tools`).
 * @param config - plugin configuration.
 */
export async function apply(ctx: Context, config: OfficeConfigInput = {}): Promise<void> {
  const cfg = normalizeConfig(config)
  const subprocess = ctx.get('subprocess') as SubprocessRuntime
  let bin: string
  try {
    bin = await subprocess.resolveExecutable(cfg.command, cfg.env)
  } catch (error) {
    throw new Error(
      `dsh-office-tool: cannot resolve the officecli binary "${cfg.command}". Install it (e.g. "officecli install", or point "command" at its path). Cause: ${String(error)}`,
      { cause: error },
    )
  }
  // Constructing a `Service` subclass registers it as `ctx.office` on this
  // context (cordis Service semantics); no explicit `ctx.provide` — a second
  // registration would throw "service office has been registered".
  const office = new OfficeService(ctx, { bin, env: cfg.env, timeoutMs: cfg.timeoutMs, maxOutputBytes: cfg.maxOutputBytes })
  applyOfficeTools(ctx, office)
}
