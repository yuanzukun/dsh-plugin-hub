/**
 * OfficeCLI error taxonomy. Officecli's structured `--json` error envelope is
 * surfaced verbatim where possible; failures that happen outside officecli
 * (spawn, timeout, non-JSON output) get their own codes under the `office_`
 * prefix so callers can distinguish CLI errors from transport errors.
 * @module dsh-office-tool/errors
 */

/** One officecli error-envelope field set (from `{"success":false,"error":{...}}`). */
export interface OfficeErrorInfo {
  /** Human-readable message officecli produced. */
  error: string
  /** Machine code (`not_found`, `invalid_value`, ...); absent when unclassified. */
  code?: string
  /** Self-healing hint for the agent. */
  suggestion?: string
  /** Valid values when the failure is a range/choice violation. */
  validValues?: readonly string[]
}

/** A tool/transport failure carrying officecli's structured fields. */
export class OfficeError extends Error {
  readonly code: string
  readonly suggestion?: string
  readonly validValues?: readonly string[]
  readonly exitCode?: number

  constructor(
    message: string,
    options: {
      code?: string
      suggestion?: string
      validValues?: readonly string[]
      exitCode?: number
      cause?: unknown
    } = {},
  ) {
    super(message, options.cause !== undefined ? { cause: options.cause } : {})
    this.name = 'OfficeError'
    this.code = options.code ?? 'office_error'
    this.suggestion = options.suggestion
    this.validValues = options.validValues
    this.exitCode = options.exitCode
  }
}

/** Build an {@link OfficeError} from officecli's structured error envelope. */
export function officeErrorFromInfo(info: OfficeErrorInfo, exitCode: number): OfficeError {
  return new OfficeError(info.error, {
    code: info.code,
    suggestion: info.suggestion,
    validValues: info.validValues,
    exitCode,
  })
}
