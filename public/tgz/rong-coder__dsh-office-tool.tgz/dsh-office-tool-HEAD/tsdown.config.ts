/**
 * tsdown build for dsh-office-tool: two node-half entries (lib/index.js tools
 * plugin, lib/preview.js web-preview plugin) plus one browser client bundle
 * (lib/client.js, CJS closure factory).
 *
 * The client bundle replicates the official DSH client-bundle preset (mirror
 * of dsh-better-sidebar's tsdown config): externals resolve through the loader
 * module table at runtime (react + cordis + client runtime), everything else
 * inlines into the single bundle. Each artifact registers itself via
 * `window.__ModuleLoader__.load({ id, factory })` with the `(require) =>`
 * CJS closure shape.
 *
 * Types ship from `tsc -p tsconfig.build.json`, not from tsdown.
 */
import { readFile } from 'node:fs/promises'
import { basename, dirname, relative, resolve as resolvePath, sep } from 'node:path'
import { fileURLToPath } from 'node:url'
import type { UserConfig } from 'tsdown'

const REPOSITORY_ROOT = fileURLToPath(new URL('.', import.meta.url))

/** Bundle id (= package name; the client-modules compose keys on it). */
const CLIENT_ID = 'dsh-office-tool'

/** Module specifiers the web shell shares into the frozen module table. */
const CLIENT_EXTERNALS = [
  'react',
  'react/jsx-runtime',
  'react-dom',
  'react-dom/client',
  '@deepseek-ai/cordis',
  '@deepseek-ai/dsh-client-runtime',
  '@deepseek-ai/dsh-client-runtime/client',
  '@deepseek-ai/dsh-client-ui-primitives',
  '@deepseek-ai/dsh-client-ui-primitives/client',
  '@deepseek-ai/dsh-client-ui-slots',
  '@deepseek-ai/dsh-client-ui-slots/client',
]

/** Rebase a physical lib-relative source onto the repository-shaped URL tree. */
function browserSourcePath(source: string, sourcemapPath: string): string {
  if (!source.startsWith('.')) return source
  const physicalSource = resolvePath(dirname(sourcemapPath), source)
  const repositoryPath = relative(REPOSITORY_ROOT, physicalSource).split(sep).join('/')
  return `../../../${repositoryPath}`
}

/** The node-half build (lib/index.js + lib/preview.js, ESM node). */
const hostConfig: UserConfig = {
  entry: { index: 'src/index.ts', preview: 'src/preview/index.ts' },
  outDir: 'lib',
  format: ['esm'],
  platform: 'node',
  target: 'es2024',
  fixedExtension: false,
  dts: false,
  clean: true,
}

/** The client bundle build (lib/client.js, CJS closure factory). */
const clientConfig: UserConfig = {
  entry: { client: 'src/client/index.tsx' },
  outDir: 'lib',
  format: 'cjs',
  platform: 'browser',
  target: 'es2024',
  dts: false,
  sourcemap: true,
  clean: false,
  external: [...CLIENT_EXTERNALS],
  define: {
    'process.env.NODE_ENV': JSON.stringify(process.env.NODE_ENV ?? 'production'),
    'import.meta.env.MODE': JSON.stringify(process.env.NODE_ENV ?? 'production'),
    'import.meta.env': JSON.stringify({ MODE: process.env.NODE_ENV ?? 'production' }),
  },
  // Browser bundle inline node-idiom deps; anything NOT in the loader module
  // table must inline instead. A require() the table cannot answer is a
  // guaranteed runtime throw.
  noExternal: (id: string) => (CLIENT_EXTERNALS.includes(id) ? undefined : true),
  outputOptions: {
    entryFileNames: 'client.js',
    sourcemapPathTransform: browserSourcePath,
    banner: `window.__ModuleLoader__.load({ id: ${JSON.stringify(CLIENT_ID)}, factory: (require) => {`,
    footer: 'return module.exports; } });',
    intro: 'var module = { exports: {} }; var exports = module.exports;',
    // The CJS wrapper factory's `require` only resolves module-table entries;
    // it cannot load relative chunk URLs in the browser. Disable code
    // splitting so dynamic import() inlines into the single factory chunk.
    codeSplitting: false,
  },
}

export default [hostConfig, clientConfig] satisfies UserConfig[]
