/**
 * Unit tests for the preview routes: registration and full HTTP-handler
 * behavior against a fake web server and a fake subprocess.
 * @file tests/preview.spec.ts
 */

import { describe, expect, it } from 'vitest'
import { mkdtemp, rm, writeFile } from 'node:fs/promises'
import { join } from 'node:path'
import type { ServerResponse } from 'node:http'
import { Context } from '@deepseek-ai/cordis'
import type { SubprocessRuntime } from '@deepseek-ai/dsh-subprocess'
import type { WebRoute, WebServer } from '@deepseek-ai/dsh-host-webserver'
import { OfficeService } from '../src/service.ts'
import { registerPreviewRoute } from '../src/preview/route.ts'

/** A fake web server capturing registered routes. */
function fakeWebServer(): { routes: WebRoute[]; register: (r: WebRoute) => () => void } {
  const routes: WebRoute[] = []
  return { routes, register: (r) => { routes.push(r); return () => {} } }
}

/** Build an OfficeService whose subprocess returns canned output per argv. */
function officeWith(stdout: string, exitCode = 0): { office: OfficeService; capturedArgv: string[][] } {
  const ctx = new Context()
  const capturedArgv: string[][] = []
  const fake = {
    resolveExecutable: async (command: string) => command,
    spawn: (spec: { argv: string[] }) => {
      capturedArgv.push([...spec.argv])
      return {
        pid: 1,
        collected: {
          stdout: { readFrom: () => ({ text: stdout, nextOffset: 0, lossy: false }) },
          stderr: { readFrom: () => ({ text: '', nextOffset: 0, lossy: false }) },
        },
        done: Promise.resolve({ exitCode, signal: null }),
        terminate: () => {},
        waitForExit: async () => true,
      }
    },
  } as unknown as SubprocessRuntime
  ctx.provide('subprocess', fake)
  return { office: new OfficeService(ctx, { bin: 'officecli', timeoutMs: 1_000, maxOutputBytes: 1 << 20 }), capturedArgv }
}

/** Minimal fake req/res pair for one route handler call. */
function fakeReq(url: string): unknown {
  return { url }
}
function fakeRes(): { res: ServerResponse; status(): number; body(): string } {
  const state = { status: 200, body: '' }
  const res = {
    writeHead: (status: number) => { state.status = status; return res },
    end: (body: string) => { state.body = body ?? ''; return res },
  } as unknown as ServerResponse
  return { res, status: () => state.status, body: () => state.body }
}

/** Run one captured route handler and return the response state. */
async function hit(handler: WebRoute['handler'], url: string): Promise<{ status: number; body: string }> {
  const { res, status, body } = fakeRes()
  await handler(fakeReq(url) as never, res)
  // Read the state AFTER the handler settles (lazy access, not destructured).
  return { status: status(), body: body() }
}

describe('/office/preview route', () => {
  it('renders a document to HTML through officecli and writes it to the response', async () => {
    const dir = await mkdtemp(join(process.cwd(), '.preview-test-'))
    const file = join(dir, 'deck.pptx')
    const html = '<html><body>Hello World</body></html>'
    const { office, capturedArgv } = officeWith(html)
    try {
      const server = fakeWebServer()
      registerPreviewRoute(server as unknown as WebServer, office, {})
      expect(server.routes).toHaveLength(1)
      expect(server.routes[0]!.path).toBe('/office/preview')

      const { status, body } = await hit(server.routes[0]!.handler, `/office/preview?path=${encodeURIComponent(file)}`)
      expect(status).toBe(200)
      expect(body).toContain('Hello World')
      // runRaw path: view html WITHOUT --json.
      expect(capturedArgv[0]).toEqual(['officecli', 'view', file, 'html'])
    } finally {
      await rm(dir, { recursive: true, force: true })
    }
  })

  it('rejects non-office extensions with 415', async () => {
    const { office } = officeWith('')
    const server = fakeWebServer()
    registerPreviewRoute(server as unknown as WebServer, office, {})
    const { status, body } = await hit(server.routes[0]!.handler, '/office/preview?path=notes.txt')
    expect(status).toBe(415)
    expect(body).toContain('unsupported_type')
  })

  it('returns a structured render failure when officecli fails', async () => {
    const { office } = officeWith('boom', 2)
    const server = fakeWebServer()
    registerPreviewRoute(server as unknown as WebServer, office, {})
    const { status, body } = await hit(server.routes[0]!.handler, '/office/preview?path=deck.pptx&cwd=' + encodeURIComponent(process.cwd()))
    expect(status).toBe(422)
    expect(body).toContain('render_failed')
  })

  it('rejects paths outside the workspace by default', async () => {
    const { office } = officeWith('')
    const server = fakeWebServer()
    registerPreviewRoute(server as unknown as WebServer, office, {})
    const { status, body } = await hit(server.routes[0]!.handler, '/office/preview?path=' + encodeURIComponent('D:/outside/deck.pptx'))
    expect(status).toBe(403)
    expect(body).toContain('outside_workspace')
  })

  it('probe=1 reports the file mtime cheaply', async () => {
    const dir = await mkdtemp(join(process.cwd(), '.preview-probe-'))
    const file = join(dir, 'deck.pptx')
    await writeFile(file, 'placeholder')
    const { office } = officeWith('')
    try {
      const server = fakeWebServer()
      registerPreviewRoute(server as unknown as WebServer, office, {})
      const { status, body } = await hit(server.routes[0]!.handler, `/office/preview?probe=1&path=${encodeURIComponent(file)}`)
      expect(status).toBe(200)
      expect(body).toContain('"success":true')
      expect(body).toContain('"mtime"')
    } finally {
      await rm(dir, { recursive: true, force: true })
    }
  })
})
