/**
 * Unit tests for argv construction. Uses a real cordis Context only to satisfy
 * the Service constructor; no subprocess runs.
 * @file tests/argv.spec.ts
 */

import { describe, expect, it } from 'vitest'
import { Context } from '@deepseek-ai/cordis'
import { OfficeService } from '../src/service.ts'

function makeService(): OfficeService {
  return new OfficeService(new Context(), { bin: 'officecli', timeoutMs: 1_000, maxOutputBytes: 1_000 })
}

describe('buildArgv', () => {
  it('builds a get argv with --json', () => {
    const s = makeService()
    expect(s.buildArgv({ verb: 'get', file: 'deck.pptx', args: ['/slide[1]'] }))
      .toEqual(['officecli', 'get', 'deck.pptx', '/slide[1]', '--json'])
  })

  it('expands props to repeated --prop key=value entries', () => {
    const s = makeService()
    expect(s.buildArgv({ verb: 'set', file: 'd.docx', args: ['/body/p[1]'], props: { text: 'Hi there', bold: true } }))
      .toEqual(['officecli', 'set', 'd.docx', '/body/p[1]', '--prop', 'text=Hi there', '--prop', 'bold=true', '--json'])
  })

  it('handles flags: skips undefined/false, pushes booleans, pairs values', () => {
    const s = makeService()
    expect(s.buildArgv({ verb: 'create', file: 'd.pptx', flags: { type: 'pptx', force: true, minimal: false, depth: 2, page: undefined } }))
      .toEqual(['officecli', 'create', 'd.pptx', '--type', 'pptx', '--force', '--depth', '2', '--json'])
  })

  it('does not append --json when json:false', () => {
    const s = makeService()
    expect(s.buildArgv({ verb: 'view', file: 'd.pptx', args: ['html'], json: false }))
      .toEqual(['officecli', 'view', 'd.pptx', 'html'])
  })

  it('cli verb passes argv verbatim without --json', () => {
    const s = makeService()
    expect(s.buildArgv({ verb: 'cli', args: ['merge', 'a.pptx', 'b.pptx', '--data', '{}'] }))
      .toEqual(['officecli', 'merge', 'a.pptx', 'b.pptx', '--data', '{}'])
  })
})
