/**
 * Integration tests against a real officecli binary. Self-skip when the binary
 * is unavailable (the `@officecli/officecli` devDependency downloads it on
 * postinstall; without it, `binaryPath()` is undefined and these tests skip).
 * These tests validate the argv + envelope + `view html` assumptions the
 * service layer relies on.
 * @file tests/integration.spec.ts
 */

import { describe, expect, it } from 'vitest'
import { execFile } from 'node:child_process'
import { existsSync } from 'node:fs'
import { mkdtemp, rm } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { promisify } from 'node:util'
import { createRequire } from 'node:module'
import { parseEnvelope } from '../src/service.ts'

const exec = promisify(execFile)

/** Run officecli without its auto-resident so the temp files unlock on cleanup. */
function runOffice(bin: string, args: string[]): Promise<{ stdout: string; stderr: string }> {
  return exec(bin, args, { env: { ...process.env, OFFICECLI_NO_AUTO_RESIDENT: '1' } })
}

/** Resolve the officecli binary shipped by the devDependency, if present. */
function binaryPath(): string | undefined {
  try {
    const require = createRequire(import.meta.url)
    const pkg = require('@officecli/officecli') as { binaryPath?: () => string }
    const path = pkg.binaryPath?.()
    return path !== undefined && existsSync(path) ? path : undefined
  } catch {
    return undefined
  }
}

const BIN = binaryPath()
const run = BIN !== undefined ? describe : describe.skip

run('officecli integration', () => {
  it('creates, edits, reads, and renders a .pptx', async () => {
    const dir = await mkdtemp(join(tmpdir(), 'dsh-office-tool-'))
    const bin = BIN as string
    const file = join(dir, 'deck.pptx')
    try {
      // create
      await runOffice(bin, ['create', file])
      expect(existsSync(file)).toBe(true)

      // add a slide with a title
      const added = await runOffice(bin, ['add', file, '/', '--type', 'slide', '--prop', 'title=Hello World', '--json'])
      expect(parseEnvelope(added.stdout)).toMatchObject({ success: true })

      // read it back
      const got = await runOffice(bin, ['get', file, '/slide[1]', '--json'])
      const envelope = parseEnvelope(got.stdout)
      expect(envelope).toMatchObject({ success: true })
      expect(JSON.stringify(envelope)).toContain('Hello World')

      // render to HTML (self-contained; images inline)
      const html = await runOffice(bin, ['view', file, 'html'])
      expect(html.stdout).toContain('Hello World')
      expect(html.stdout).toContain('<html')
    } finally {
      await rm(dir, { recursive: true, force: true })
    }
  }, 120_000)

  it('returns a structured error envelope for a missing element', async () => {
    const dir = await mkdtemp(join(tmpdir(), 'dsh-office-tool-'))
    const bin = BIN as string
    const file = join(dir, 'empty.docx')
    try {
      await runOffice(bin, ['create', file])
      const { stdout } = await runOffice(bin, ['get', file, '/body/p[99]', '--json']).catch((error) => {
        // officecli may exit non-zero; the envelope still lands on stdout.
        return { stdout: String(error.stdout ?? '') }
      })
      const envelope = parseEnvelope(stdout)
      expect(envelope).toMatchObject({ success: false })
    } finally {
      await rm(dir, { recursive: true, force: true })
    }
  }, 60_000)
})
