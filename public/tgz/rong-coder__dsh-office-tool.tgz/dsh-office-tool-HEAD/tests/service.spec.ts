/**
 * Unit tests for OfficeService.run/runRaw against a fake `ctx.subprocess`.
 * @file tests/service.spec.ts
 */

import { describe, expect, it } from 'vitest'
import { Context } from '@deepseek-ai/cordis'
import type { SubprocessHandle, SubprocessSpawnSpec, SubprocessRuntime } from '@deepseek-ai/dsh-subprocess'
import { OfficeError, OfficeService } from '../src/service.ts'

/** A collect-output reader returning fixed text. */
function reader(text: string): SubprocessHandle['collected']['stdout'] {
  return { readFrom: () => ({ text, nextOffset: 0, lossy: false }) }
}

/** A fake handle whose `done` resolves immediately with the given facts. */
function settledHandle(result: { exitCode: number | null; signal?: NodeJS.Signals | null; stdout: string; stderr?: string }): SubprocessHandle {
  return {
    pid: 1,
    stdin: undefined,
    stdout: undefined,
    stderr: undefined,
    collected: { stdout: reader(result.stdout), stderr: reader(result.stderr ?? '') },
    done: Promise.resolve({ exitCode: result.exitCode, signal: result.signal ?? null }),
    terminate: () => {},
    waitForExit: async () => true,
  } as unknown as SubprocessHandle
}

/** A fake handle whose `done` resolves only when the spec's signal aborts. */
function abortReactiveHandle(): SubprocessHandle {
  let resolveDone!: (v: { exitCode: number | null; signal: NodeJS.Signals | null }) => void
  const done = new Promise<{ exitCode: number | null; signal: NodeJS.Signals | null }>((resolve) => { resolveDone = resolve })
  const onAbort = () => resolveDone({ exitCode: null, signal: 'SIGTERM' })
  return {
    pid: 1,
    stdin: undefined,
    stdout: undefined,
    stderr: undefined,
    collected: { stdout: reader(''), stderr: reader('') },
    done,
    terminate: onAbort,
    waitForExit: async () => true,
  } as unknown as SubprocessHandle
}

/** Build a service over a fake subprocess; capture every spawn spec. */
function makeService(options: {
  handle: SubprocessHandle
  captured?: SubprocessSpawnSpec[]
}): { office: OfficeService; captured: SubprocessSpawnSpec[] } {
  const ctx = new Context()
  const captured: SubprocessSpawnSpec[] = options.captured ?? []
  const fake = {
    resolveExecutable: async (command: string) => command,
    spawn: (spec: SubprocessSpawnSpec) => {
      captured.push(spec)
      return options.handle
    },
  } as unknown as SubprocessRuntime
  ctx.provide('subprocess', fake)
  return { office: new OfficeService(ctx, { bin: 'officecli', timeoutMs: 1_000, maxOutputBytes: 1_000 }), captured }
}

describe('OfficeService.run', () => {
  it('returns the parsed success envelope', async () => {
    const { office } = makeService({ handle: settledHandle({ exitCode: 0, stdout: '{"success":true,"data":{"tag":"slide"}}' }) })
    const env = await office.run({ verb: 'get', file: 'deck.pptx', args: ['/slide[1]'] })
    expect(env).toEqual({ success: true, data: { tag: 'slide' } })
  })

  it('throws a structured OfficeError on an officecli error envelope', async () => {
    const { office } = makeService({ handle: settledHandle({ exitCode: 1, stdout: '{"success":false,"error":{"error":"Slide 50 not found","code":"not_found","suggestion":"1-8"}}' }) })
    await expect(office.run({ verb: 'get', file: 'deck.pptx', args: ['/slide[50]'] })).rejects.toMatchObject({
      name: 'OfficeError',
      message: 'Slide 50 not found',
      code: 'not_found',
      suggestion: '1-8',
    })
  })

  it('throws office_invalid_output on non-JSON stdout with exit 0', async () => {
    const { office } = makeService({ handle: settledHandle({ exitCode: 0, stdout: '<html>hi</html>' }) })
    await expect(office.run({ verb: 'view', file: 'd.pptx', args: ['html'], json: false })).rejects.toMatchObject({ code: 'office_invalid_output' })
  })

  it('throws office_command_failed on non-JSON stdout with non-zero exit', async () => {
    const { office } = makeService({ handle: settledHandle({ exitCode: 2, stdout: 'boom', stderr: 'detail' }) })
    await expect(office.run({ verb: 'get', file: 'd.docx', args: ['/x'] })).rejects.toMatchObject({ code: 'office_command_failed', exitCode: 2 })
  })
})

describe('OfficeService.runRaw cancellation', () => {
  it('throws office_timeout when the deadline fires', async () => {
    const ctx = new Context()
    const fake = {
      resolveExecutable: async (command: string) => command,
      spawn: (spec: SubprocessSpawnSpec) => {
        const handle = abortReactiveHandle()
        if (spec.signal !== undefined) {
          if (spec.signal.aborted) handle.terminate()
          else spec.signal.addEventListener('abort', handle.terminate, { once: true })
        }
        return handle
      },
    } as unknown as SubprocessRuntime
    ctx.provide('subprocess', fake)
    const office = new OfficeService(ctx, { bin: 'officecli', timeoutMs: 30, maxOutputBytes: 1_000 })
    await expect(office.runRaw(['officecli', 'get', 'x.docx'])).rejects.toMatchObject({ code: 'office_timeout' })
  })

  it('classifies a caller abort as office_cancelled, not a timeout', async () => {
    const ctx = new Context()
    const controller = new AbortController()
    const fake = {
      resolveExecutable: async (command: string) => command,
      spawn: (spec: SubprocessSpawnSpec) => {
        const handle = abortReactiveHandle()
        if (spec.signal !== undefined) {
          if (spec.signal.aborted) handle.terminate()
          else spec.signal.addEventListener('abort', handle.terminate, { once: true })
        }
        return handle
      },
    } as unknown as SubprocessRuntime
    ctx.provide('subprocess', fake)
    const office = new OfficeService(ctx, { bin: 'officecli', timeoutMs: 10_000, maxOutputBytes: 1_000 })
    const pending = office.runRaw(['officecli', 'get', 'x.docx'], { signal: controller.signal })
    setTimeout(() => controller.abort(), 5)
    await expect(pending).rejects.toMatchObject({ code: 'office_cancelled' })
  })
})

describe('OfficeService.runRaw spawn spec', () => {
  it('passes cwd, env, collect caps, and --json flags to the spawn', async () => {
    const captured: SubprocessSpawnSpec[] = []
    const { office } = makeService({
      handle: settledHandle({ exitCode: 0, stdout: '{"success":true,"data":1}' }),
      captured,
    })
    await office.run({ verb: 'get', file: 'd.docx', args: ['/'], cwd: 'D:/ws' })
    expect(captured).toHaveLength(1)
    const spec = captured[0]!
    expect(spec.argv).toEqual(['officecli', 'get', 'd.docx', '/', '--json'])
    expect(spec.cwd).toBe('D:/ws')
    expect(spec.stdio.stdout).toMatchObject({ maxBytes: 1_000 })
  })
})

describe('OfficeError', () => {
  it('carries code, suggestion, and exitCode', () => {
    const err = new OfficeError('bad', { code: 'x', suggestion: 'try y', exitCode: 1 })
    expect(err).toBeInstanceOf(Error)
    expect(err.code).toBe('x')
    expect(err.suggestion).toBe('try y')
    expect(err.exitCode).toBe(1)
  })
})
