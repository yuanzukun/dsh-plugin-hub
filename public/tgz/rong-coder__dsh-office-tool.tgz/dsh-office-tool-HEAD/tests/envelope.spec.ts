/**
 * Unit tests for the officecli `--json` envelope parser.
 * @file tests/envelope.spec.ts
 */

import { describe, expect, it } from 'vitest'
import { parseEnvelope } from '../src/service.ts'

describe('parseEnvelope', () => {
  it('parses a success envelope', () => {
    expect(parseEnvelope('{"success":true,"data":{"tag":"slide"}}')).toEqual({ success: true, data: { tag: 'slide' } })
  })

  it('strips the UTF-8 BOM and a trailing CR', () => {
    expect(parseEnvelope('﻿{"success":true,"data":1}\r')).toEqual({ success: true, data: 1 })
  })

  it('parses an error envelope with structured fields', () => {
    expect(parseEnvelope('{"success":false,"error":{"error":"Slide 50 not found","code":"not_found","suggestion":"Valid range 1-8","validValues":["1","2"]}}'))
      .toEqual({ success: false, error: { error: 'Slide 50 not found', code: 'not_found', suggestion: 'Valid range 1-8', validValues: ['1', '2'] } })
  })

  it('carries message/matched/warnings when present', () => {
    expect(parseEnvelope('{"success":true,"data":[],"message":"ok","matched":3,"warnings":["a"]}'))
      .toEqual({ success: true, data: [], message: 'ok', matched: 3, warnings: ['a'] })
  })

  it('returns undefined for non-JSON output', () => {
    expect(parseEnvelope('<html>not json</html>')).toBeUndefined()
    expect(parseEnvelope('')).toBeUndefined()
  })
})
