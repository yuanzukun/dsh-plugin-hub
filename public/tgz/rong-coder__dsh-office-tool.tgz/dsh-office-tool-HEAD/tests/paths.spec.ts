/**
 * Unit tests for preview path resolution.
 * @file tests/paths.spec.ts
 */

import { describe, expect, it } from 'vitest'
import { resolve } from 'node:path'
import { resolvePreviewPath } from '../src/paths.ts'

describe('resolvePreviewPath', () => {
  it('rejects a missing or blank path', () => {
    expect(resolvePreviewPath(null).ok).toBe(false)
    expect(resolvePreviewPath('   ').ok).toBe(false)
  })

  it('accepts an absolute office path', () => {
    const r = resolvePreviewPath(resolve('C:/ws/report.docx'))
    expect(r.ok).toBe(true)
  })

  it('resolves a relative path against cwd', () => {
    const r = resolvePreviewPath('deck.pptx', 'D:/ws')
    expect(r.ok).toBe(true)
    if (r.ok) expect(r.abs).toBe(resolve('D:/ws', 'deck.pptx'))
  })

  it('resolves a relative path against the host cwd when no cwd given', () => {
    const r = resolvePreviewPath('deck.pptx')
    expect(r.ok).toBe(true)
    if (r.ok) expect(r.abs).toBe(resolve(process.cwd(), 'deck.pptx'))
  })

  it('rejects non-office extensions', () => {
    const r = resolvePreviewPath('a.txt')
    expect(r.ok).toBe(false)
    if (!r.ok) expect(r.code).toBe('unsupported_type')
  })

  it('is case-insensitive about the extension', () => {
    const r = resolvePreviewPath('DECK.PPTX')
    expect(r.ok).toBe(true)
  })

  it('normalizes forward-slash absolute paths so the workspace check matches', () => {
    // On Windows, an absolute path arriving with forward slashes must be
    // normalized to the platform separator, or the workspace-prefix check
    // rejects it as outside the workspace.
    const base = resolve(process.cwd(), 'deck.pptx')
    const slashy = base.replaceAll('\\', '/')
    const r = resolvePreviewPath(slashy)
    expect(r.ok).toBe(true)
    if (r.ok) expect(r.abs).toBe(base)
  })
})
