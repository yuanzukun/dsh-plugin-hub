/**
 * Boot the REAL host half against a throwaway data root, and drive its route.
 *
 * This exists so both panel test files exercise the same artifact:
 *   - `panel-host.test.js` drives the route directly and reads the ledger off
 *     disk;
 *   - `panel-client.test.js` feeds the route's OWN responses to the browser half,
 *     so the panel is rendered from real host output rather than from a fixture
 *     somebody wrote by hand.
 *
 * That second use is the point. A hand-written fixture cannot catch the host and
 * the panel disagreeing about where the transcript lives — and on 2026-10-16 they
 * did disagree (`messages` at the top level vs inside `group`), which in a browser
 * is simply "this room is empty".
 *
 * @module test/support/host-harness
 */

import { mkdtempSync, rmSync, readFileSync, existsSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { Readable } from 'node:stream'

import { entry as pluginEntry, describeSource, usingInstalled } from './entry.mjs'

export { profileRoot } from './entry.mjs'

/** The module under test. Kept as a named export because suites refer to it. */
export const installedEntry = pluginEntry

/**
 * Load the plugin and return a handle that can boot it repeatedly.
 *
 * @param {object} [options]
 *   - `extraTools`: tool names to pretend the deployment already has, so a soft
 *     integration can be tested in both of its states rather than only the one
 *     this machine happens to be in.
 *   - `liveSessions`: session ids that should look LIVE, so a delivery can be
 *     observed end-to-end. Everything they receive is captured in
 *     `handle.delivered` — the only way to assert WHAT a woken member is told,
 *     which is the whole point of several features.
 *   - `withSessionController`: mount a recording `sessionController`, the service
 *     `@deepseek-ai/dsh-web-app` provides and a headless deployment does not.
 *     Every `selectModel` call lands in `handle.effortCalls`. Left out by
 *     default, so the "no such service" path is the one most tests exercise.
 *   - `sessionCatalog`: session records the fake `sessionQuery` should list
 *     (`{id, title, cwd, createdAt, live, origin, agentPreset}`), so the panel's
 *     「拉人」 picker can be tested against a deployment that HAS sessions. Each
 *     entry is also given a `readSession` route, so the cold-resume path keeps
 *     working in the same test.
 *   - `workspaces`: workspace records the fake `workspaceRegistry` should list
 *     (`{title, path, sessionIds}`), for the picker's workspace labels.
 * @returns {Promise<object>} host handle.
 */
export async function createHost(options = {}) {
  const extraTools = Array.isArray(options.extraTools) ? options.extraTools : []
  const liveIds = new Set(Array.isArray(options.liveSessions) ? options.liveSessions.map(String) : [])
  const withSessionController = options.withSessionController === true
  const sessionRoutes = options.sessionRoutes ?? {}
  const sessionCatalog = Array.isArray(options.sessionCatalog) ? options.sessionCatalog : undefined
  const workspaces = Array.isArray(options.workspaces) ? options.workspaces : []
  const effortCalls = []
  const delivered = []
  const modelCalls = []
  const model = options.model ?? undefined
  if (!existsSync(pluginEntry)) {
    throw new Error(`the plugin entry is missing: ${pluginEntry}`)
  }
  const { apply } = await import(`file:///${pluginEntry.replace(/\\/g, '/')}`)

  const homes = []
  let home = ''
  let route = null
  let tools = new Map()
  // The deployment's real route registry, including its duplicate guard: the
  // host's `webServer.register` THROWS on a second registration of the same
  // exact path (`webserver: duplicate exact route`). Modelling the throw is what
  // turns "a re-activated child fiber must not lose the panel" into a test.
  let registrations = []
  // Every `ctx.inject` callback, kept so a test can re-activate the child fiber
  // the way Cordis does when a dependency is re-composed.
  let injects = []
  // Every runtime prompt context the plugin published. A test drives it exactly
  // the way the harness does: `definition.text({ agent: { session: { id } } })`.
  let promptContexts = []
  // Human-command definitions the plugin registered. The runtime's `commands`
  // registry calls `handler({rawInput, agent, …})` directly when the human types
  // `/group …`, so a test drives the same entry point.
  let commandDefs = new Map()

  // The deployment's real `webServer` face, hoisted out of `reboot()` so that
  // `reactivate()` can hand the SAME service object back to the child fiber.
  const webServer = {
    register(definition) {
      const clash = registrations.some(
        (row) => row.kind === definition.kind && row.path === definition.path,
      )
      if (clash) throw new Error(`webserver: duplicate ${definition.kind} route "${definition.path}"`)
      registrations.push(definition)
      route = definition
      return () => {
        const index = registrations.indexOf(definition)
        if (index >= 0) registrations.splice(index, 1)
        if (route === definition) route = null
      }
    },
  }

  /** A fresh data root plus a freshly applied plugin, as a restart would give. */
  function boot() {
    home = mkdtempSync(join(tmpdir(), 'attention-host-'))
    homes.push(home)
    return reboot()
  }

  /** Re-apply the plugin against the SAME data root: an upgrade or a restart. */
  function reboot() {
    process.env.DSH_HOME = home
    route = null
    // A reboot disposes the previous plugin instance, and Cordis runs its
    // disposers: the old route is gone before the new apply runs.
    registrations = []
    injects = []
    promptContexts = []
    commandDefs = new Map()
    tools = new Map()
    for (const name of extraTools) {
      tools.set(name, {
        name,
        description: 'stand-in for a tool this deployment is supposed to have',
        parameters: {},
        output: { schema: {} },
        execute: async () => ({ ok: true }),
      })
    }
    const ctx = {
      tools: {
        register(definition) {
          tools.set(definition.name, definition)
          return () => tools.delete(definition.name)
        },
        // The real registry has this, and the soft memory integration asks it
        // whether a tool exists before promising anything.
        get(name) {
          return tools.get(name)
        },
      },
      agents: {
        get(id) {
          if (!liveIds.has(String(id))) return undefined
          return {
            id: String(id),
            status: 'idle',
            followup(message) {
              delivered.push({ sessionId: String(id), message })
            },
          }
        },
        // Cold resume is deliberately not modelled: a test that wants to prove a
        // REAL wake declares the target in `liveSessions` and gets the
        // live-followup path above. A stored target that is woken lands here and
        // is reported as a failed delivery — an honest answer, not a silent one.
        resume: () => {
          throw new Error('cold resume is not modelled by this harness (declare the target in liveSessions instead)')
        },
      },
      get(name) {
        // `sessionQuery.readSession` is how the plugin learns a session's own
        // provider/model — both when cold-resuming it and when changing its effort
        // in place. Supplying it here is what lets those two paths be tested
        // without a real session log on disk.
        //
        // `listSessions` is the same service's catalogue half, which the panel's
        // 「拉人」 picker reads. Only mounted when a test asked for a catalogue, so
        // every other suite keeps exercising the "service absent -> degrade" path.
        //
        // Titles are NOT read here: the picker takes those from the projection
        // cache (`sessionProjectionCache`), because folding them out of a session
        // log costs a full log read per row. The stub below keeps that split
        // honest — a test that wants titles has to declare a projection cache too.
        if (name === 'sessionQuery' && (Object.keys(sessionRoutes).length > 0 || sessionCatalog !== undefined)) {
          return {
            async readSession(sessionId) {
              const route = sessionRoutes[String(sessionId)]
              if (route === undefined) return { events: [] }
              return { events: [{ type: 'request/header', data: { header: { config: route } } }] }
            },
            ...(sessionCatalog === undefined
              ? {}
              : {
                  // The real service returns newest-first records; the picker does
                  // its own ordering, so the stub deliberately returns them in the
                  // order the test declared them.
                  async listSessions() {
                    return sessionCatalog.map((row) => ({
                      header: {
                        version: 4,
                        id: String(row.id),
                        createdAt: Number.isFinite(row.createdAt) ? row.createdAt : 0,
                        isSeeded: row.isSeeded === true,
                        ...(typeof row.cwd === 'string' ? { cwd: row.cwd } : {}),
                        ...(typeof row.origin === 'string' ? { origin: row.origin } : {}),
                        ...(typeof row.agentPreset === 'string' ? { agentPreset: row.agentPreset } : {}),
                      },
                      live: row.live === true,
                      persisted: true,
                    }))
                  },
                }),
          }
        }
        // ⚠️ The projection cache is the picker's cheap title source, and its
        // signature DIFFERS between DSH versions: the running 0.2.1-rc.2 (extracted
        // from app.asar) is `cachedSnapshot(meta, keys?)`, while the stale
        // 0.1.5-rc.1 tree in ~/.dsh/profiles/node_modules declares a middle
        // `inheritedEventCount`. Guessing wrong loses every title silently while
        // tests stay green — which is exactly what happened in front of the user on
        // 2026-10-17. This stub declares the LIVE arity (two parameters), so the
        // module's adaptation takes the live branch here.
        if (name === 'sessionProjectionCache' && sessionCatalog !== undefined) {
          return {
            cachedSnapshot(meta, keys) {
              const row = sessionCatalog.find((candidate) => String(candidate.id) === String(meta?.id))
              if (row === undefined || typeof row.title !== 'string' || row.title.length === 0) return undefined
              return { asOfSeq: 1, values: { title: row.title } }
            },
            cachedPredecessorTitle() {
              return undefined
            },
          }
        }
        if (name === 'workspaceRegistry' && workspaces.length > 0) {
          return {
            list() {
              return workspaces.map((row) => ({
                id: `workspace-${row.title}`,
                title: String(row.title),
                path: String(row.path ?? ''),
                createdAt: '2026-10-01T00:00:00.000Z',
                updatedAt: '2026-10-01T00:00:00.000Z',
                sessionIds: Array.isArray(row.sessionIds) ? row.sessionIds.map(String) : [],
              }))
            },
          }
        }
        // 2026-10-21: R9++ summarises through the DEPLOYMENT's model service.
        // These two stubs model the real pair the plugin asks for: `llm.stream`
        // (adapter holds the credentials — the plugin passes no key) and
        // `agentDefaultModel.currentSelection()` (provider/model).
        if (name === 'llm' && model !== undefined) {
          return {
            async *stream(request) {
              modelCalls.push({ provider: request.provider, model: request.model, system: request.system, messages: request.messages })
              yield { type: 'block-start', index: 0, blockType: 'text' }
              yield { type: 'text-delta', index: 0, text: String(model.reply ?? '摘要正文') }
              yield {
                type: 'usage',
                usage: { inputTokens: Number(model.inputTokens ?? 300), outputTokens: Number(model.outputTokens ?? 40) },
              }
              yield { type: 'finish', reason: { kind: 'stop' } }
            },
          }
        }
        if (name === 'agentDefaultModel' && model !== undefined) {
          return {
            currentSelection() {
              return { provider: String(model.provider ?? 'deepseek'), model: String(model.model ?? 'deepseek-chat') }
            },
          }
        }
        return undefined
      },
      inject(names, cb) {
        if (names.includes('webServer')) {
          injects.push(cb)
          cb({ webServer })
        }
        if (names.includes('systemPrompt')) {
          // The real child scope has `effect`; a stub that runs the callback and
          // returns its disposer is enough to prove registration and release.
          cb({
            systemPrompt: {
              context(definition) {
                promptContexts.push(definition)
                return () => {
                  const index = promptContexts.indexOf(definition)
                  if (index >= 0) promptContexts.splice(index, 1)
                }
              },
            },
            effect(callback) {
              return callback()
            },
          })
        }
        if (names.includes('commands')) {
          cb({
            commands: {
              register(definition) {
                commandDefs.set(definition.name, definition)
                return () => commandDefs.delete(definition.name)
              },
            },
            effect(callback) {
              return callback()
            },
          })
        }
        // A deployment without `sessionController` never calls back at all — which
        // is what a headless tree looks like, and the state most tests should be
        // in.
        if (names.includes('sessionController') && withSessionController) {
          cb({
            sessionController: {
              async selectModel(request) {
                effortCalls.push(request)
                return {}
              },
            },
          })
        }
      },
    }
    apply(ctx)
  }

  /**
   * Re-run each `ctx.inject` callback, as Cordis does when a dependency is
   * re-composed or the web entry reloads. The plugin must treat that as
   * idempotent — measured on 0.2.1-rc.1: the second activation threw
   * `duplicate exact route`, the panel survived on the FIRST registration, and
   * only the diagnostic knew, so it reported a healthy panel as failed.
   */
  function reactivate() {
    for (const cb of injects) cb({ webServer })
  }

  /** Drive the real handler with a request, and parse what it wrote back. */
  async function call(options = {}) {
    if (route === null) throw new Error('the panel route was never registered')
    const { method = 'GET', url = '/attention-group', body } = options
    const req = Readable.from([Buffer.from(body === undefined ? '' : JSON.stringify(body))])
    req.method = method
    req.url = url
    const out = { status: 0, headers: null, text: '' }
    const res = {
      writeHead(status, headers) {
        out.status = status
        out.headers = headers
      },
      end(chunk) {
        if (chunk !== undefined) out.text += String(chunk)
      },
    }
    await route.handler(req, res)
    return { status: out.status, headers: out.headers, json: out.text.length === 0 ? undefined : JSON.parse(out.text) }
  }

  const get = (query) => call({ method: 'GET', url: `/attention-group${query ?? ''}` })
  const post = (body) => call({ method: 'POST', body })

  /** The ledger as it exists on disk — the durability witness, not the response. */
  function ledgerOnDisk() {
    return JSON.parse(readFileSync(join(home, 'attention-group', 'groups.json'), 'utf8'))
  }

  /** The transcript file for one room, or '' when it was never written. */
  function messagesOnDisk(groupId) {
    const file = join(home, 'attention-group', 'messages', `${groupId}.jsonl`)
    return existsSync(file) ? readFileSync(file, 'utf8') : ''
  }

  /** Create a room through the panel and return its id. */
  async function newRoom(title) {
    const response = await post({ action: 'create', title })
    if (response.status !== 200) throw new Error(`create failed: ${response.text}`)
    return response.json.groupId
  }

  return {
    boot,
    reboot,
    reactivate,
    call,
    get,
    post,
    newRoom,
    ledgerOnDisk,
    messagesOnDisk,
    writeFileSync,
    /** Everything delivered to a declared-live session, oldest first. */
    delivered,
    /** Every `sessionController.selectModel` call, oldest first. */
    effortCalls,
    /** Every `llm.stream` call the plugin made, oldest first (R9++ direct summary). */
    modelCalls,
    get home() {
      if (home.length === 0) {
        // Without this, `join(host.home, 'x')` silently yields a RELATIVE path and
        // a test writes into the repository instead of a temp folder. Measured:
        // exactly that happened on 2026-10-16, and it also made a later run see a
        // stale file and fail for the wrong reason. Loud beats silent.
        throw new Error('host.home is empty: call host.boot() before using the data root')
      }
      return home
    },
    get route() {
      return route
    },
    /** How many route registrations are live right now (must never exceed 1). */
    get routeCount() {
      return registrations.length
    },
    /** Runtime prompt contexts the plugin published, in registration order. */
    get promptContexts() {
      return promptContexts
    },
    /** Human commands the plugin registered, keyed by name. */
    get commands() {
      return commandDefs
    },
    tool(name) {
      return tools.get(name)
    },
    cleanup() {
      for (const dir of homes) rmSync(dir, { recursive: true, force: true })
    },
  }
}
