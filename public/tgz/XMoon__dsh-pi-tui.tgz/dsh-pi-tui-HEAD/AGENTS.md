# AGENTS.md

`dsh-pi-tui` is a third-party TUI mode for DeepSeek Harness (`dsh`). Read this file
before editing. Read subsystem docs only when the task touches that subsystem.

## Execution discipline

- **Stay in scope.** Do only the requested work; report unrelated bugs, cleanup opportunities, refactors, or improvements separately; do not implement them unless required by the task.
- **Investigation is read-only by default.** Review, investigate, compare, assess, research, and planning requests do not authorize source changes.
- **Prefer the smallest sufficient change.** Do not introduce speculative abstractions, APIs, hooks, dependencies, compatibility layers, or future migration work.
- **Do not fix unrelated pre-existing failures.** Distinguish them from
  regressions caused by the current work and report them separately.
- **Do not hide contradictions.** Prefer fast failure over silent defaults, broad catches, speculative fallbacks, or validation for states guaranteed by internal contracts. Validate at real system boundaries.
- **Never push or force-push without explicit user approval.** Local commits are allowed when appropriate; remote changes are not.

## Code review

Before reviewing code changes, read `docs/code-review.md` and pass it plus the
applicable requirements/contracts to the reviewer. It supplements the generic
review loop; subsystem contracts remain authoritative. PR acceptance is not
stage closure or permission to merge.

Before adding a surface or restyling one, read `docs/tui-design-language.md`
(the canonical TUI visual vocabulary, role→token table and governance) and walk
its §11.2 checklist for any change that alters what a surface paints.

## Naming and writing

- Repository/profile/package names are `dsh-pi-tui`, `pi-tui`, `@xmoon76/pi-tui`
  (private vendored fork), and `@xmoon76/dsh-pi-tui` (the only published
  package). Never introduce the reserved `dsh-tui` / `@deepseek-ai/dsh-tui`
  naming family.
- User-facing strings, code comments, commit messages, and docs are English;
  `README.md` and `CHANGELOG.md` are the intentional Simplified-Chinese exceptions.
- Keep `README.md` / `README.en.md` and
  `CHANGELOG.md` / `CHANGELOG.en.md` synchronized.
- Changelog entries describe user-visible outcomes, not review rounds, divergence IDs, CI/tooling work, or implementation mechanics. Follow `docs/releasing.md` for release details.
- Before adding a command, check this repository and official dsh for confusing or near-synonym names. This applies to new independent commands; preserve explicit existing aliases such as `/statusline` for `/footer`.

## Repository boundaries

### Source module placement

Before adding a production module, identify the layer that owns its state/lifetime/IO.

- `src/app/**` — application lifecycle, orchestration, currentness and owner composition.
- `src/runtime/**` — semantic ports/contracts plus Direct/Remote backend adapters.
- `src/domain/**` — transport/UI-neutral semantic models, policies, folds and derived state.
- `src/client/**` — Client-local non-TUI platform capabilities such as local media,
  clipboard, artifact IO and Client-local path completion.
- `src/tui/**` — terminal rendering, pickers, panels, commands and interaction.
- `src/extension/**` — public extension compatibility boundary.

A feature may span several layers when the responsibilities differ: file completion
owns neutral query/ranking/discovery policy in `domain/file-completion/**`, the
Client-local filesystem capability in `client/file-completion/**`, the terminal
trigger/presentation in `tui/file-completion/**` and the Direct Host WORKSPACE
compatibility IO in `runtime/direct/file-completion/**`. Do not recreate the retired
mixed `src/file-completion/**` directory.

Do not add an ordinary new root feature/helper (`src/*.ts`, `*.tsx`, `*.mts`,
`*.cts`). Root modules are limited to documented entries/facades/compatibility
islands guarded by the architecture gate; the gate scans all four extensions.

Choose placement by the owning layer, not by the feature noun. A domain may appear in
multiple layers when the responsibilities differ (for example `app/command/**` owns
application command execution while `tui/commands/**` owns terminal slash-command
presentation).

Do not create a parallel root feature tree when a canonical owner layer exists, do not
move code only for visual symmetry, and do not hide cross-layer dependencies behind a
generic Context/Services bag.

When placement is ambiguous, stop before creating the file and identify the state owner,
lifecycle owner, IO authority, primary callers and forbidden dependencies. Read
`docs/architecture.md` for the complete taxonomy and dependency direction.

### Vendored pi-tui

`packages/pi-tui/**` is a protected vendored fork, not a normal implementation layer.

- Implement behavior in the root bundle whenever it can be done correctly through the existing consumer/public surface.
- Treat the fork as read-only for ordinary feature/bug work.
- Cleaner, smaller, more direct, or easier to test is not sufficient reason for a fork change.
- Every intentional fork source difference must belong to an existing/new X### divergence and have a guarding regression test.
- `packages/pi-tui/UPSTREAM.json` is the sole upstream baseline source;
  `packages/pi-tui/vendor-divergences.json` is the authoritative schema-v2
  inventory; `DIVERGENCES.md` is its generated human report.
- Read `packages/pi-tui/AGENTS.md` before editing anything in that package.

### Package ownership

- `@xmoon76/pi-tui` is private and bundled into `@xmoon76/dsh-pi-tui`; it is never published independently.
- Every published/runtime `@deepseek-ai/*` import/dependency resolves as a peer from the installed Harness. Dev/test dependencies may declare those packages; do not add duplicate runtime copies to the published package or tracked lockfile through `file:`, `link:`, or `workspace:` specs.
- Keep public entry-point types structural. Do not expose internal classes such as `TuiApp`, private registries, screens, terminal objects, or repository-private paths through public declarations.
- `src/startup.ts` remains a zero-dependency compatibility island. Optional runtime/backend imports must not enter its static dependency graph.

## Server/client architecture

The current production backend is Direct. The long-term migration is tracked in
`docs/client-server-migration.md`.

- Direct remains the production default until an explicit migration milestone;
  do not silently change `dsh --profile pi-tui`, `--session`, or `--preset`, or
  implement future milestones opportunistically during unrelated work.
- New Host-owned behavior must not add direct Host coupling outside the approved
  semantic-port boundary. `scripts/client-boundary-gate.mjs` enforces the
  existing baseline and no-new-debt rule; baseline changes are deliberate phase
  relocations only, with migration and coupling docs updated in the same PR.
- Every Host-touching feature declares locality (Client-local, Host-owned, or
  split), its narrow semantic-port owner, and its wire story. Never assume
  Client cwd/filesystem equals Host cwd/filesystem. Host workspace semantics —
  `@file`, Host user-shell execution, and any future Host-owned filesystem
  editing/open — require an authoritative Host seam and fail closed until one
  exists. Client-local semantics — terminal/editor UI, the current draft
  external editor, Client-local draft file/image intake, and Client-local
  artifact output — stay Client-local by contract.
- Keep Client-local and Host-owned state explicit; callbacks/renderers/editor
  objects never cross the process boundary. Do not replace Context with a
  universal god object; keep ports narrow and domain-owned.
- Prefer official DSH client/Remote/event contracts over TUI-specific RPCs,
  DTOs, or duplicate transport state.
- Direct and wire implementations share semantic contracts and contract tests;
  do not maintain two independent feature semantics. Remote async results must
  re-check generation/identity before mutating visible state. Every migration PR
  leaves the Direct path green.
- Direct session-safety mechanisms remain authoritative until the migration
  roadmap explicitly retires them.

Read `docs/client-server-migration.md` and `docs/client-server-coupling.md`
before changing Host-owned behavior.

## Extension boundary

`@xmoon76/dsh-pi-tui/extensions` is a public compatibility boundary.

- Stable APIs stay semantic and must not expose TUI/terminal/repository
  internals. Low-level capabilities belong to Advanced/Unstable supported
  entries, never private imports.
- Preserve existing public semantics and caller-owned lifecycle across unload/HMR
  and surface recreation.
- Prefer additive evolution. Do not silently repurpose or remove exported
  behavior.
- First-party success is insufficient for public API changes; preserve
  third-party-style packed/public-export coverage.
- Do not expand the Extension API merely for future flexibility or to make an
  internal implementation/test easier.

Read `docs/extension-api.md` and `docs/plugin-authoring.md` before changing an
extension-facing contract.

## Correctness invariants

- **One Direct surface per session.** DSH `SessionHandle` / `SessionWriteLease`
  is the sole cross-process Session writer ownership authority on the master
  baseline; one process-owned surface per session is guaranteed by DSH
  authority. Do not add a second persistence/artifact-level owner lock in the
  TUI. The TUI still owns process-local surface correctness:
  `SessionTransitionGate`, `SessionOperationBarrier`, and stale/generation
  fences. Keep the submit hot path free of persistence reads. See
  `docs/concurrency.md`.
- **No bare fire-and-forget promises.** Use the repository's `runDetached` /
  `runOwned` ownership model and preserve its failure semantics. See
  `docs/failure-model.md`.
- **Use semantic key matching.** TUI components use `matchesKey`/the keyboard
  abstraction, never raw terminal escape-sequence equality; terminals may use
  CSI-u / modifyOtherKeys.
- **Respect Cordis injection.** Do not read an uninjected service through a bare
  `ctx.foo`; use the declared injection or the appropriate `ctx.get(...)` path.
- **Agent-scoped DSH services use the live Agent object as scope.** Do not
  substitute the Cordis context or silently omit required scope.
- **Do not recreate catalog probes.** Cold command/skill discovery uses the
  standing scope; do not call `agents.create()` merely to discover a catalog.
  See `docs/surface-catalog.md`.
- **Question flow stays in the editor seat.** Keep one unified, budgeted
  scrollport and preserve its seat/modal ownership. See
  `test/question-flow.test.ts` and `test/rendering.test.ts`.
- **Managed overlays follow the overlay/focus contract.** Logical intent is
  committed before any fork call that can synchronously run a plugin callback,
  and a callback's newer operation always wins; the host derives the focused
  seat from the live physical focus. See `docs/overlay-focus-contract.md`.
- **Context presentation does not rewrite model input.** Keep model-facing bytes
  untouched; render parsed skill/system envelopes, never raw XML. See
  `test/rendering.test.ts`.
- **Prove lifecycle invariants with a probe, not with intuition.** For
  generation/lease, proxy-receiver, attachment and teardown-idempotence changes,
  confirm the real numbers and identities (a targeted probe or test) instead of
  reasoning from the code alone — this repository has had a double
  `markAttachment()` inflate a generation. See `docs/concurrency.md`.

## Development

Common checks:

```sh
pnpm build
pnpm typecheck
pnpm test
```

Use the smallest relevant validation for the current change. Prefer targeted
tests first; do not run expensive compatibility suites mechanically.

A stage-final validation must not run the same suite twice. `pnpm verify:prepush`
is the repository's full pipeline: `typecheck:fork` + `typecheck:bench`,
`test:fork`, `test:docs`, `test:tooling`, the architecture / boundary /
keybinding / naming / session-event / installation-doc / pi-divergence /
pi-vendor gates, `pnpm audit`, and finally `pnpm pack:release`. `pack:release`
is NOT packaging-only: its `prepack` runs `clean` + `build` +
`typecheck:bundle` + `test:product`, and its `postpack` runs the eight
public-package smokes (tarball, extension fixture, advanced, phase4, unstable,
vim, examples, composeAgent). So in one pass never also run `typecheck:bundle`,
`test:product`, `scripts/tarball-smoke.mjs` or
`scripts/compose-agent-compat-smoke.mjs` by hand, and never invoke
`pnpm pack`/`pack:release` while a build or an artifact-dependent gate is
running. `pnpm test` already contains `test:fork` + `test:product` +
`test:tooling` + `test:docs`; prefer it over the individual pieces. What a
stage-final pass still needs ON TOP of `verify:prepush`: the migration contract
smokes (`smoke:remote-*`), `smoke:boundary`, `smoke:startup-strictness`, the
published-DSH compatibility checks (`compat:dsh:npm`, `compat:dsh:client-family`
— `verify:prepush` does NOT contain them), `git diff --check` (unstaged and
staged), plus whatever stage-specific validation the authority plan for the
current stage requires (e.g. the Pre-M3 plan's §35.5/§35.6 matrix).

**Never re-run a lane that is already green on the same state.** Before a
stage-final pass, take stock of what has already run against the CURRENT tree
and run only the remainder — re-running a green lane after an edit that does
not touch its inputs buys no evidence and costs the whole suite. A delta
invalidates a lane only when it touches that lane's inputs: `packages/pi-tui/**`
for the fork lanes, `src/**` + `test/**` + `scripts/**` for the bundle suites,
`docs/**` and the doc-gate inputs for `test:docs`/the documentation gates.
A docs-only or comment-only delta does not invalidate a suite already green on
the same code. State which lanes were already green (and against which state)
and which were run for the delta, so the evidence stays auditable. CI runs the
full pipeline on the PR; the local stage-final pass exists to catch failures
before pushing, not to reproduce CI.

**Start a long lane only on a frozen tree.** Begin a stage-final pass — or any
lane that takes minutes — only once every known finding is fixed, no review
round or acceptance item is in flight, and you cannot name a reason another edit
is expected; until then run only the delta-targeted tests. An edit made while a
lane runs voids that run: kill it explicitly, record why, and re-run once after
the tree is frozen instead of letting it finish and then running the same state
twice.

`ci.yml` coverage is what makes a green PR check evidence instead of work to
reproduce: `Source checks` runs `build:fork`, `typecheck:fork`,
`typecheck:bench`, `test:fork`, the `smoke:remote-*` parity/closure lanes (five
of them only when the resolved DSH mode is `source`), `test:docs`,
`gate:installation-doc`, `test:tooling`, `gate:pi-surface-compat`,
`generate:pi-divergences` with a `git diff --exit-code` on `DIVERGENCES.md`,
`gate:pi-divergence-ledger`, `gate:pi-vendor-diff --strict` and the naming gate;
`Build and pack` runs the root `build`, `typecheck:bundle` and `test:product`
through `pack`, the public-package smokes and `smoke:startup-strictness`; the
remaining jobs run `smoke:boundary`, `smoke:official-presets`,
`compat:dsh:client-family`, the tarball smokes and `pnpm audit`. The lanes CI
does NOT run — therefore the only ones a stage-final pass must run locally — are
`compat:dsh:npm`, `gate:keybindings`, `gate:boundary`, `gate:architecture`,
`scripts/check-no-session-events.mjs`, `gate:dsh-preset-parity`,
`smoke:remote-d2-fork` and `smoke:remote-session-lifecycle-parity`; a mode-gated
CI step that was skipped counts as not covered.

**Keep one run ledger per session** (lane → last green state → its inputs) and
consult it before every run: having to run a lane again is a fact to state, not
a habit to fall back on.

Validation mechanics for this toolchain:

* `packages/pi-tui/dist` is a build INPUT to the root bundle and to the tests:
  run `pnpm build` before testing anything that depends on the fork, and never
  run a build and an artifact-dependent test or gate at the same time.
* Some bundle paths run under Node's strip-only TypeScript loader: new `src/**`
  files must not use TypeScript parameter properties
  (`constructor(private readonly x: T) {}`) — assign explicit fields instead.
* `scripts/client-boundary-gate.mjs` counts a Host package import even when it is
  TYPE-ONLY (`@deepseek-ai/dsh-agent` / `@deepseek-ai/dsh-session`). Prefer a
  local structural type or the owning port's type; see
  `docs/client-server-coupling.md`.
* Extending a shared interface (e.g. `TuiCommandRunner`, `TuiSettingsDoc`) also
  reaches its test fakes and literal builders: update them with the change and
  let `pnpm typecheck:bundle` enumerate the remainder.
* Changing WHAT the public entry re-exports (moving or re-exporting a
  publicly-exported type/function) changes the emitted declaration graph: the
  bundled `dist/*.d.mts` may only carry the top-level regions allowlisted in
  `scripts/tarball-smoke.mjs`. Run `pnpm build` and then
  `node scripts/tarball-smoke.mjs` before pushing — the ordinary product suite
  does NOT cover this (it is a `postpack`/CI check), and a stale `dist` makes it
  pass locally.
* A publicly-exported helper therefore follows the canonical owner-layer placement
  (`## Repository boundaries` → `### Source module placement`) and is exposed through
  the public entry (`src/index.ts`) or an existing documented facade. Do not create a
  new root `src/*.ts` module merely to satisfy declaration bundling. The root
  ledger `scripts/source-root-baseline.json` is CLOSED at the seven stable
  entries/facades with no legacy root left (the architecture gate also forbids
  every retired root path); those entries are not a template for new modules. If the declaration/tarball boundary
  cannot expose the canonical nested owner, STOP and report the packaging constraint
  instead of growing the root baseline.

When entering a development worktree:

```sh
pnpm dev:doctor
```

Use `pnpm dev:bootstrap` only when the environment is not ready. On a
source-mode worktree (a worktree whose tracked `test/compat/dsh-mode.json`
selects `source` — `next` is not always source-mode), a plain `pnpm install`
before bootstrap leaves the DSH workspace state incorrect (`workspace DSH
incorrect` / `local state missing`); run `pnpm dev:doctor` first and let
`pnpm dev:bootstrap` perform the dependency install itself, then re-run
`pnpm dev:doctor` until it reports `READY`. A plain `pnpm install` after
bootstrap re-resolves `@deepseek-ai/*` to registry versions and breaks the
source-mode workspace again; use `pnpm dev:shell` (or
`source ./.dsh-dev-env`) for commands that need the source environment, and
re-run `pnpm dev:bootstrap` after any real install. Keep each worktree's
`node_modules` and `dist` independent; never symlink them, and build in that
worktree before using a profile.

* `main` is the released npm-backed compatibility line; `next` is the
  forward-integration line and may use its tracked Source Mode.
* Normal feature/fix work lands on `main`, then merges `main -> next`; do not
  duplicate shared implementations. Use `next` directly only for explicit
  next-only work requiring an unpublished DSH API or contract.
* A promotion uses a real merge commit; never squash/reset long-lived history or
  replace `next`'s newer DSH target/policy with `main`'s released one.
* Do not modify the real-use `pi-tui` profile during development.
* `compat:dsh:source` is a full distribution-boundary verification, not a
  routine test after ordinary TUI changes. Run it only when the DSH source or
  distribution boundary changes (source pin, target metadata, distribution
  infrastructure, source/npm discrepancy, or an unpublished DSH commit), or
  when explicitly requested; skip it for TUI-only changes when DSH is
  unchanged.

Read `docs/local-development.md` before changing DSH mode, worktree/bootstrap
behavior, or promoting `main`/`next`. Read `docs/dsh-compatibility.md` for
distribution compatibility.

## Release

* Follow `docs/releasing.md`. Publishing is performed by GitHub CI from the
  release tag; never run `npm publish` from a development machine.
* Release commits/tags also require explicit user approval. Keep bilingual
  changelogs synchronized and user-facing.

## Documentation map

Read these only when the task touches the corresponding area:

* `docs/README.md` — complete documentation index and ownership map.
* `docs/client-server-migration.md` — Direct → DSH-native client roadmap.
* `docs/client-server-coupling.md` — current Host-coupling inventory.
* `docs/concurrency.md` — Direct session ownership and safety.
* `docs/failure-model.md` — detached async ownership/error handling.
* `docs/extension-api.md` — public extension compatibility contract.
* `docs/plugin-authoring.md` — extension tier/authoring guidance.
* `docs/surface-catalog.md` — command/skill catalog ownership.
* `docs/local-development.md` — worktrees, Source Mode, branch promotion.
* `docs/tmux-testing.md` — visual/TTY verification and real-testing traps.
* `docs/dsh-compatibility.md` — DSH distribution compatibility.
* `docs/releasing.md` — release/tag/publish procedure.
* `packages/pi-tui/AGENTS.md` — vendored-fork rules.

When a subsystem already has a dedicated contract document, keep detailed
implementation history there or in its regression tests rather than growing
this file. Update behavior decisions and rationale in the owning doc in the
same PR; keep each fact in one place and link rather than copy it.
