#!/usr/bin/env node
/**
 * @xmoon76/dsh-pi-tui/scripts/tarball-smoke — verify a packed
 * `@xmoon76/dsh-pi-tui` tarball end to end, so a fresh checkout can never
 * publish a broken or leaky artifact:
 *
 *   1. structure — every `exports` file exists, cordis.patch.yml is
 *      included, no duplicated official preset root is shipped, and
 *      nothing else leaks in (no test fixtures,
 *      no backups, no nested tarballs, no absolute paths);
 *   2. content — no workspace absolute paths anywhere, and the bundle does
 *      NOT import `@xmoon76/pi-tui` externally (it is bundled);
 *   3. parse — every `.mjs` passes `node --check`; every `.d.mts` parses via
 *      the TypeScript compiler when available;
 *   4. install — the tarball installs with the exact declared DSH Host
 *      (`npm install --omit=dev` in a fresh temp project), public `exports`
 *      entries import, and
 *      `@xmoon76/pi-tui` is NOT resolvable from the installed package.
 *
 * Usage: node scripts/tarball-smoke.mjs [path-to-tgz]
 *   [--dsh-distribution path]
 * The tarball path defaults to the newest `xmoon76-dsh-pi-tui-*.tgz` in
 * the current directory (the `pnpm pack` / `npm pack` output location;
 * npm/pnpm strip the `@` scope from tarball filenames).
 *
 * `--dsh-distribution` (or DSH_SOURCE_DISTRIBUTION) selects the validated
 * local DSH source-pack adapter for a truly fresh pnpm install. Without it,
 * the existing npm registry install path is used.
 *
 * Env: TARBALL_SMOKE_SKIP_INSTALL=1 skips the install step (offline packed-artifact
 * structural checks) when no source distribution is supplied; it is rejected
 * for Source Mode so a fresh-install check cannot be bypassed. TARBALL_SMOKE_KEEP=1
 * keeps the temp dirs for inspection.
 * @module tarball-smoke
 */

import { spawnSync } from 'node:child_process'
import {
  existsSync,
  mkdirSync,
  mkdtempSync,
  readdirSync,
  readFileSync,
  realpathSync,
  rmSync,
  statSync,
  writeFileSync,
} from 'node:fs'
import { tmpdir } from 'node:os'
import { basename, dirname, join, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'
import { createRequire } from 'node:module'
import { parseArgs } from 'node:util'

import {
  assertSourceResolution,
  isDshPackage,
  loadDshDistribution,
  npmDshVersion,
  prepareDshInstall,
  restoreDshInstall,
  sourceInstallPackages,
} from './lib/dsh-distribution.mjs'
import { COMPAT_MATRIX } from './lib/dsh-compat.mjs'
import { pnpmExecutable } from './lib/process.mjs'

const SCRIPT_DIR = dirname(fileURLToPath(import.meta.url))
/** The dsh-pi-tui package root (the workspace checkout). */
const PACKAGE_ROOT = join(SCRIPT_DIR, '..')

const failures = []
const checks = []

/** Record a passing check or a hard failure (failures exit non-zero at the end). */
function check(name, ok, detail = '') {
  checks.push(`${ok ? 'ok  ' : 'FAIL'} ${name}${detail === '' ? '' : ` — ${detail}`}`)
  if (!ok) failures.push(`${name}${detail === '' ? '' : `: ${detail}`}`)
}

function run(command, args, options = {}) {
  return spawnSync(command, args, { encoding: 'utf8', maxBuffer: 64 * 1024 * 1024, ...options })
}

/** Resolve the tarball: explicit arg, else the newest matching tgz in the
 * current directory or its parent (pnpm workspace packs may land either
 * place depending on how the lifecycle was invoked). */
function resolveTarball(explicit) {
  if (explicit !== undefined) {
    // Absolutize BEFORE any subprocess uses it: `npm install` below runs
    // with cwd=probeDir, so a caller-relative path (e.g. the CI artifact
    // download `tarball/xmoon76-*.tgz`) would resolve against the temp
    // probe and fail with ENOENT.
    const absolute = resolve(explicit)
    if (!existsSync(absolute)) throw new Error(`tarball not found: ${explicit}`)
    return absolute
  }
  // npm/pnpm strip the `@` scope from tarball filenames, so the glob is
  // `xmoon76-dsh-pi-tui-*.tgz` even though the package is @xmoon76/dsh-pi-tui.
  const candidates = [process.cwd(), join(process.cwd(), '..')]
    .flatMap(dir => {
      try {
        return readdirSync(dir).map(name => join(dir, name))
      } catch {
        return []
      }
    })
    .filter(path => /xmoon76-dsh-pi-tui-.*\.tgz$/.test(path))
    .sort((a, b) => statSync(b).mtimeMs - statSync(a).mtimeMs)
  if (candidates.length === 0) throw new Error(`no xmoon76-dsh-pi-tui-*.tgz in the current directory (${process.cwd()}) or its parent (${join(process.cwd(), '..')}); pass the tarball path`)
  return candidates[0]
}

/** Extract an npm tarball; returns the `package/` directory. */
function extract(tarball, workDir) {
  const result = run('tar', ['-xzf', tarball, '-C', workDir])
  if (result.status !== 0) throw new Error(`tar extraction failed: ${result.stderr}`)
  const extracted = join(workDir, 'package')
  if (!existsSync(extracted)) throw new Error('tarball has no package/ root (not an npm tarball?)')
  return extracted
}

/** Walk a directory tree, returning relative file paths. */
function walkFiles(root) {
  const out = []
  const walk = (dir, prefix) => {
    for (const entry of readdirSync(dir, { withFileTypes: true })) {
      const rel = prefix === '' ? entry.name : `${prefix}/${entry.name}`
      if (entry.isDirectory()) walk(join(dir, entry.name), rel)
      else out.push(rel)
    }
  }
  walk(root, '')
  return out
}

/** Load the TypeScript compiler for parse-only validation, when available. */
function loadTypescript() {
  try {
    return createRequire(join(PACKAGE_ROOT, 'package.json'))('typescript')
  } catch {
    return undefined
  }
}

/** Parse-only check of a .d.mts file: no resolution, syntax errors only. */
function dtsParses(ts, file) {
  const text = readFileSync(file, 'utf8')
  const source = ts.createSourceFile(file, text, ts.ScriptTarget.ES2022, true, ts.ScriptKind.TS)
  return source.parseDiagnostics.length === 0
    ? { ok: true }
    : { ok: false, detail: source.parseDiagnostics[0].messageText }
}

function parseCli() {
  const { values, positionals } = parseArgs({
    args: process.argv.slice(2),
    options: {
      'dsh-distribution': { type: 'string' },
    },
    allowPositionals: true,
    strict: true,
  })
  if (positionals.length > 1) throw new Error('usage: node scripts/tarball-smoke.mjs [candidate.tgz] [--dsh-distribution path]')
  return {
    tarball: positionals[0],
    dshDistribution: values['dsh-distribution'] ?? process.env.DSH_SOURCE_DISTRIBUTION,
  }
}

/** Build a clean probe package that exposes every candidate DSH edge to the
 * shared source-install planner without borrowing the TUI workspace metadata. */
function sourceProbePackage(tarball, candidate) {
  const peerDependencies = { ...candidate.peerDependencies }
  for (const section of ['dependencies', 'optionalDependencies']) {
    for (const [name, range] of Object.entries(candidate[section] ?? {})) {
      if (isDshPackage(name) && peerDependencies[name] === undefined) peerDependencies[name] = range
    }
  }
  return {
    name: 'tarball-smoke-source-probe',
    private: true,
    dependencies: { [candidate.name]: `file:${tarball}` },
    peerDependencies,
    ...(candidate.peerDependenciesMeta === undefined ? {} : { peerDependenciesMeta: candidate.peerDependenciesMeta }),
  }
}

function sourceInstallEnvironment() {
  return {
    ...process.env,
    PNPM_CONFIG_VERIFY_DEPS_BEFORE_RUN: 'false',
    PNPM_CONFIG_MANAGE_PACKAGE_MANAGER_VERSIONS: 'false',
    npm_config_minimum_release_age: '0',
    pnpm_config_minimum_release_age: '0',
  }
}

function resultDetail(result) {
  const lines = [result?.stderr, result?.stdout, result?.error?.message]
    .filter(value => typeof value === 'string' && value.length > 0)
    .join('\n')
    .split(/\r?\n/u)
  return (lines.length <= 120
    ? lines
    : [...lines.slice(0, 80), '[... output truncated ...]', ...lines.slice(-40)])
    .join('\n')
}

function runSourceInstall(tarball, candidate, distribution, probeDir) {
  mkdirSync(probeDir)
  const probePackage = sourceProbePackage(tarball, candidate)
  const packagePath = join(probeDir, 'package.json')
  writeFileSync(packagePath, `${JSON.stringify(probePackage, null, 2)}\n`)
  const required = sourceInstallPackages(distribution, probePackage)
  const prepared = prepareDshInstall(distribution, probeDir, {
    materializeSourceDependencies: true,
    stripPackageManager: true,
  })
  let install
  try {
    install = run(pnpmExecutable(), [
      ...prepared.installArgs,
      '--ignore-scripts',
      '--config.minimum-release-age=0',
      '--reporter=append-only',
    ], {
      cwd: probeDir,
      env: sourceInstallEnvironment(),
      timeout: 10 * 60_000,
    })
  } finally {
    restoreDshInstall(prepared)
  }
  check('source distribution fresh install (pnpm)', install.status === 0,
    install.status === 0 ? '' : resultDetail(install))
  if (install.status !== 0) return { probePackage, required, installed: false }

  try {
    assertSourceResolution(probeDir, distribution, required)
    check('all reachable DSH packages resolve from local tarballs', true)
  } catch (error) {
    check('all reachable DSH packages resolve from local tarballs', false,
      error instanceof Error ? error.message : String(error))
  }
  return { probePackage, required, installed: true }
}

function main() {
  const cli = parseCli()
  const tarball = resolveTarball(cli.tarball)
  const keep = process.env.TARBALL_SMOKE_KEEP === '1'
  const skipInstall = process.env.TARBALL_SMOKE_SKIP_INSTALL === '1'
  const workDir = mkdtempSync(join(tmpdir(), 'tarball-smoke-'))
  const probeDir = join(workDir, 'probe')
  try {
    check('tarball exists', existsSync(tarball), basename(tarball))
    const extracted = extract(tarball, workDir)
    const pkg = JSON.parse(readFileSync(join(extracted, 'package.json'), 'utf8'))
    check('package name', pkg.name === '@xmoon76/dsh-pi-tui', pkg.name)
    check('published package is not private', pkg.private !== true, `private=${String(pkg.private)}`)
    // The runtime contract must survive packing: DSH reads an own `engines.dsh`
    // range in preference to the DSH peer ranges, so a manifest that only has
    // the field in the working tree would ship a different floor than the one
    // the build and the matrix gate verified.
    const expectedDshEngine = `>=${COMPAT_MATRIX.matrix.at(-1).dshFrom}`
    check('published manifest restates the matrix floor as engines.dsh',
      pkg.engines?.dsh === expectedDshEngine, `engines.dsh=${String(pkg.engines?.dsh)}`)
    const sourceDistribution = cli.dshDistribution === undefined
      ? undefined
      : loadDshDistribution({ mode: 'source', manifest: cli.dshDistribution, packageJson: pkg })
    if (sourceDistribution !== undefined && skipInstall) {
      throw new Error('TARBALL_SMOKE_SKIP_INSTALL=1 cannot be combined with a DSH source distribution; source mode requires a fresh install')
    }

    // --- structure ---
    const files = walkFiles(extracted)
    const has = (path) => files.includes(path)
    check('exports entry dist/extension/advanced.mjs', has('dist/extension/advanced.mjs'))
    check('exports entry dist/extension/unstable.mjs', has('dist/extension/unstable.mjs'))
    check('types dist/extension/advanced.d.mts', has('dist/extension/advanced.d.mts'))
    check('types dist/extension/unstable.d.mts', has('dist/extension/unstable.d.mts'))
    check('exports entry dist/builtins.mjs', has('dist/builtins.mjs'))
    check('types dist/builtins.d.mts', has('dist/builtins.d.mts'))
    check('exports entry dist/visual-tools.mjs', has('dist/visual-tools.mjs'))
    check('types dist/visual-tools.d.mts', has('dist/visual-tools.d.mts'))
    check('exports entry dist/web-preferences.mjs', has('dist/web-preferences.mjs'))
    check('types dist/web-preferences.d.mts', has('dist/web-preferences.d.mts'))
    check('exports entry dist/host-runtime.mjs', has('dist/host-runtime.mjs'))
    check('types dist/host-runtime.d.mts', has('dist/host-runtime.d.mts'))
    // M4-B2-HF: ONE Loader subpath for the built-in Host composition. The two
    // private business services must never become installable business
    // subpaths of their own.
    check('host-runtime is the only new Loader subpath',
      pkg.exports?.['./host-runtime'] !== undefined
        && pkg.exports?.['./file-reference-host'] === undefined
        && pkg.exports?.['./terminal-progress-host'] === undefined,
      `exports=${Object.keys(pkg.exports ?? {}).join(',')}`)
    check('cordis.patch.yml included', has('cordis.patch.yml'))
    check('no duplicated official preset root', !files.some(name => name.startsWith('config/agent-presets/')))
    // The generated preset mirror MUST ship: upstream bundle-patch loading
    // downgrades a missing patch file to a stderr "skipping profile bundle"
    // line, so a stripped mirror would silently drop the whole preset roster
    // from an otherwise-clean install. Assert every dsh.bundle.patch entry
    // (cordis.patch.yml + the four generated preset patches) is packed.
    for (const patch of pkg.dsh?.bundle?.patch ?? []) {
      check(`bundle patch ships: ${patch}`, has(patch.replace('./', '')))
    }
    check('README included', has('README.md'))
    check('English README included', has('README.en.md'))
    const leaks = files.filter(name => name.includes('test/')
      || name.endsWith('.bak')
      || name.endsWith('.tgz')
      || /^\//.test(name)
      || name.includes('..'))
    check('no test fixtures / backups / nested tarballs / absolute paths', leaks.length === 0,
      leaks.length === 0 ? '' : leaks.join(', '))

    // --- content ---
    const textFiles = files
      .filter(name => /\.(mjs|ts|yml|yaml|json|md)$/.test(name))
      .map(name => join(extracted, name))
    // Leak detection is DYNAMIC, not tied to this machine: the runtime-
    // resolved repo/package/dist roots (realpath) catch THIS checkout's
    // absolute paths on any machine, and the generic patterns catch the
    // common absolute-path shapes (Unix home, macOS Users, CI workspaces,
    // Windows drives) everywhere. The smoke script itself is exempt from
    // the generic patterns: its source deliberately assembles the old
    // /home/xmoon/ marker at runtime (the literal would otherwise trip the
    // check on its own file). The dynamic-root checks still apply to it.
    // After the root-package migration the repository root IS the package
    // root, so both resolve from SCRIPT_DIR with a single `..`.
    const repoRoot = realpathSync(join(SCRIPT_DIR, '..'))
    const packageRoot = realpathSync(PACKAGE_ROOT)
    // The bundle dist may be absent (a smoke run on a raw checkout); the
    // structure checks below already fail loudly for that, so never crash
    // here — realpathSync on a missing dir would throw ENOENT and turn the
    // failure into a bare `tarball-smoke: ...` stderr line.
    const distRoot = join(PACKAGE_ROOT, 'dist')
    const leakRoots = [...new Set([
      repoRoot,
      packageRoot,
      ...(existsSync(distRoot) ? [realpathSync(distRoot)] : []),
    ])]
    const absolutePathPatterns = [
      /\/home\/[^/"']+/,
      /\/Users\/[^/"']+/,
      /\/home\/runner\/work\//,
      /[A-Za-z]:\\(?:[^\\"']*\\)+/,
    ]
    const workspaceLeaks = textFiles.filter(file => {
      const text = readFileSync(file, 'utf8')
      if (leakRoots.some(root => root.length > 1 && text.includes(root))) return true
      if (basename(file) === 'tarball-smoke.mjs') return false
      return absolutePathPatterns.some(pattern => pattern.test(text))
    })
    check('no workspace absolute paths in packaged files', workspaceLeaks.length === 0,
      workspaceLeaks.length === 0 ? '' : workspaceLeaks.join(', '))
    const dist = files.filter(name => name.startsWith('dist/') && name.endsWith('.mjs'))
      .map(name => readFileSync(join(extracted, name), 'utf8'))
    const externalFork = dist.filter(text => /from\s*["']@xmoon76\/pi-tui["']/.test(text) || /require\(\s*["']@xmoon76\/pi-tui["']/.test(text))
    check('bundle does not import @xmoon76/pi-tui externally', externalFork.length === 0,
      externalFork.length === 0 ? '' : `${externalFork.length} file(s) still import the fork`)

    // --- parse ---
    const mjsFiles = files.filter(name => /\.mjs$/.test(name)).map(name => join(extracted, name))
    const badMjs = mjsFiles.filter(file => run(process.execPath, ['--check', file]).status !== 0)
    check('every .mjs parses (node --check)', badMjs.length === 0,
      badMjs.length === 0 ? '' : badMjs.join(', '))
    const ts = loadTypescript()
    const dtsFiles = files.filter(name => /\.d\.mts$/.test(name)).map(name => join(extracted, name))
    if (ts !== undefined) {
      const badDts = dtsFiles.filter(file => !dtsParses(ts, file).ok)
      check('every .d.mts parses (typescript)', badDts.length === 0,
        badDts.length === 0 ? '' : badDts.join(', '))
    } else {
      checks.push(`skip .d.mts parse — typescript unavailable`)
    }

    // --- public .d.mts leak gate (M3/E, round-1/2 review): the shipped
    // declarations must not reference the vendored fork, TuiApp, private
    // screens, or repository source paths. tsdown INLINES types into the
    // .d.mts with `//#region <path>` markers; a fork leak shows up as a
    // region pointing OUTSIDE the package's own src/ (`../pi-tui/...`,
    // `node_modules/@xmoon76/pi-tui/...`) or as fork module names
    // (`src/tui-main-screen.d.ts`), often inside an auto-generated SHARED
    // CHUNK that the SDK entries only re-export. The gate therefore:
    //   (a) scans EVERY dist/*.d.mts (entries AND chunks);
    //   (b) treats any region marker whose path is not this package's own
    //       src/ as a leak (allowlist by construction);
    //   (c) bans fork imports and fork module names anywhere;
    //   (d) bans the bare private identifiers (TuiMainScreen/TuiAltScreen/
    //       TuiApp) line-scoped over every file, skipping comment lines.
    const dtsAll = files.filter(name => name.startsWith('dist/') && name.endsWith('.d.mts'))
    const sdkIdentifiers = [/\bTuiMainScreen\b/, /\bTuiAltScreen\b/, /\bTuiApp\b/]
    const dtsLeaks = []
    for (const name of dtsAll) {
      const text = readFileSync(join(extracted, name), 'utf8')
      const lines = text.split('\n')
      // (b) region markers: allow only `//#region src/<public module>.d.ts`.
      // The ROOT entry (dist/index.d.mts) is the runner's own surface: it
      // legitimately inlines the TuiApp implementation (src/tui-app.d.ts)
      // for the Loader row — it is NOT a third-party SDK entry. Its region
      // is exempted; everything else (chunks, extensions, builtins) must
      // name only the public modules below. The media vocabulary modules
      // (src/client/media/image/types.d.ts, src/domain/media/types.d.ts) are
      // also legitimately inlined into the root entry: the public
      // `commandRejectsImages` signature references `DraftImageStoreLike`,
      // which pulls in the draft vocabulary (and the recalled-ref shape).
      // When a root module named here is retired to its canonical owner, this
      // list must move WITH it — TS8-F1: diag -> runtime/process/diagnostics;
      // TS8-F2: tui-config -> app/config/schema, dsh-profile ->
      // app/bootstrap/profile + client/launcher/profile; TS8-F3: command-policy
      // -> domain/command/policy + domain/shell/danger + app/submission/command-policy,
      // communication-policy -> domain/communication/policy; TS8-F4: subagent-viewer
      // -> app/surface/viewer-policy, task-presentation -> app/surface/task-presentation;
      // TS8-F5: compaction-presentation -> app/surface/compaction-presentation — never
      // gain a new entry for an internal implementation path.
      // `app/host/performance-host` is a public Loader row ENTRY (like
      // `startup`/`builtins`), exposed as the flat `./performance-host`
      // subpath — the nested canonical source path, never a new root module.
      // `app/host/pi-tui-host-runtime` is the M4-B2-HF built-in Host Runtime
      // entry; its two internal feature modules are inlined regions of that
      // entry, not separate public entries.
      const isRoot = name === 'dist/index.d.mts'
      for (const line of lines) {
        const match = /\/\/#region\s+(\S+)/.exec(line)
        if (match) {
          const regionPath = match[1]
          const allowed = /^src\/(app\/bootstrap\/profile|app\/config\/schema|app\/host\/features\/file-reference|app\/host\/features\/terminal-progress|app\/host\/performance-host|app\/host\/pi-tui-host-runtime|app\/host\/visual-tools|app\/host\/web-preferences|app\/session\/interrupt|app\/submission\/command-policy|app\/submission\/pending-input|app\/surface\/compaction-presentation|app\/surface\/pending-presentation|app\/surface\/task-presentation|app\/surface\/viewer-policy|builtins|client\/launcher\/profile|client\/media\/image\/types|commands|display-preset|domain\/catalog\/skill|domain\/catalog\/surface|domain\/command\/policy|domain\/communication\/policy|domain\/media\/types|domain\/shell\/danger|extension\/advanced|extension\/advanced-types|extension\/public-types|extension\/service|extension\/slot-map|extension\/unstable|extension\/unstable-types|extensions|index|runtime\/direct\/surface-catalog|runtime\/process\/diagnostics|startup)\.d\.ts$/.test(regionPath)
          const rootAllowed = isRoot && /^src\/tui-app\.d\.ts$/.test(regionPath)
          if (!allowed && !rootAllowed) dtsLeaks.push(`${name}: region ${regionPath}`)
        }
      }
      // (c) fork imports and fork module names anywhere.
      if (/from\s*["']@xmoon76\/pi-tui["']/.test(text)) dtsLeaks.push(`${name}: fork import`)
      if (/packages\/pi-tui/.test(text)) dtsLeaks.push(`${name}: packages/pi-tui path`)
      if (/\b(tui-main-screen|tui-alt-screen)\.d\.ts\b/.test(text)) dtsLeaks.push(`${name}: fork screen module`)
      // (d) bare private identifiers, line-scoped (comments skipped). No
      // exemption: the clean dist has zero TuiApp identifiers anywhere
      // (round-3 finding 1 — the old root exemption was dead code).
      for (const line of lines) {
        const trimmed = line.trim()
        if (trimmed.startsWith('*') || trimmed.startsWith('//') || trimmed.startsWith('/*')) continue
        for (const pattern of sdkIdentifiers) {
          if (pattern.test(trimmed)) dtsLeaks.push(`${name}: bare ${pattern}`)
        }
      }
    }
    check('every public .d.mts leaks no private pi-tui / internal paths', dtsLeaks.length === 0,
      dtsLeaks.length === 0 ? '' : dtsLeaks.join('; '))
    // The .mjs bodies must not import the fork externally either (it is
    // bundled) — the existing dist check below covers every .mjs.

    // --- install + runtime ---
    if (skipInstall) {
      checks.push('skip install (TARBALL_SMOKE_SKIP_INSTALL=1)')
    } else {
      let installSucceeded = false
      if (sourceDistribution !== undefined) {
        const sourceInstall = runSourceInstall(tarball, pkg, sourceDistribution, probeDir)
        installSucceeded = sourceInstall.installed
      } else {
        mkdirSync(probeDir)
        const dshPeers = Object.keys(pkg.peerDependencies ?? {}).filter(isDshPackage)
        let installLabel = 'tarball installs standalone (npm install --omit=dev)'
        if (dshPeers.length === 0) {
          // A synthetic fixture without a DSH peer family is not a published
          // DSH plugin; keep the plain standalone probe.
          writeFileSync(join(probeDir, 'package.json'), JSON.stringify({ name: 'tarball-smoke-probe', private: true }))
        } else {
          // The published bundle is a DSH plugin: the Host owns its peer family.
          // A bare npm project auto-installs each DSH peer independently, mixing
          // stale/latest and next release trains instead of testing a real Host.
          // Include the Host and the exact DSH peers this candidate requires;
          // this is probe-only and does not alter the published peer ranges.
          const dshVersion = npmDshVersion()
          const dependencies = { '@deepseek-ai/dsh': dshVersion }
          for (const name of dshPeers) dependencies[name] = dshVersion
          writeFileSync(join(probeDir, 'package.json'), JSON.stringify({
            name: 'tarball-smoke-probe',
            private: true,
            dependencies,
          }))
          installLabel = 'tarball installs with exact DSH Host (npm install --omit=dev)'
        }
        const install = run('npm', [
          'install', '--omit=dev', '--no-save',
          '--cache', join(workDir, 'npm-cache'),
          tarball,
        ], { cwd: probeDir, timeout: 180_000 })
        installSucceeded = install.status === 0
        check(installLabel, installSucceeded, installSucceeded ? '' : resultDetail(install))
      }
      if (installSucceeded) {
        const installed = join(probeDir, 'node_modules', '@xmoon76', 'dsh-pi-tui')
        check('installed package contains dist', existsSync(join(installed, 'dist', 'index.mjs')))
        const importRun = run(process.execPath, ['--input-type=module', '-e',
          "Promise.all([import('@xmoon76/dsh-pi-tui'), import('@xmoon76/dsh-pi-tui/startup'),"
            + "import('@xmoon76/dsh-pi-tui/extensions'), import('@xmoon76/dsh-pi-tui/builtins'),"
            + "import('@xmoon76/dsh-pi-tui/extensions/advanced'), import('@xmoon76/dsh-pi-tui/extensions/unstable'),"
            + "import('@xmoon76/dsh-pi-tui/performance-host'), import('@xmoon76/dsh-pi-tui/visual-tools'),"
            + "import('@xmoon76/dsh-pi-tui/host-runtime'), import('@xmoon76/dsh-pi-tui/web-preferences')])"
            + ".then(m => { if (m[4].ADVANCED_API_LEVEL !== 1) throw new Error('ADVANCED_API_LEVEL');"
            + "if (m[5].UNSTABLE_API_LEVEL !== 1) throw new Error('UNSTABLE_API_LEVEL');"
            + "if (m[6].name !== 'pi-tui-performance-host') throw new Error('performance-host row');"
            + "if (m[7].name !== 'pi-tui-visual-tools') throw new Error('visual-tools row');"
            // The Loader row has PUBLICLY exported these two tool names since it
            // shipped; dropping them would break a published entry, so the packed
            // package must keep them.
            + "if (m[7].CHART_TOOL_NAME !== 'dsh_pi_tui_chart') throw new Error('CHART_TOOL_NAME');"
            + "if (m[7].SVG_TOOL_NAME !== 'dsh_pi_tui_svg') throw new Error('SVG_TOOL_NAME');"
            + "if (typeof m[7].apply !== 'function') throw new Error('visual-tools apply');"
            + "if (!Array.isArray(m[7].inject)) throw new Error('visual-tools inject');"
            + "if (m[8].name !== 'pi-tui-host-runtime') throw new Error('host-runtime row');"
            + "if (typeof m[8].apply !== 'function') throw new Error('host-runtime apply');"
            + "if (!Array.isArray(m[8].inject) || m[8].inject.join(',') !== 'typert,agents,fileReferences,workingDirectory') throw new Error('host-runtime inject');"
            + "if (m[9].name !== 'pi-tui-web-preferences') throw new Error('web-preferences row');"
            + "if (typeof m[9].Config !== 'function' && typeof m[9].Config !== 'object') throw new Error('web-preferences Config');"
            + "if (typeof m[9].apply !== 'function') throw new Error('web-preferences apply');"
            + "console.log('imports-ok') })"
            + ".catch(e => { console.error(e.message); process.exit(1) })",
        ], { cwd: probeDir })
        check('all exports entries import', importRun.status === 0 && importRun.stdout.includes('imports-ok'),
          importRun.status === 0 ? '' : importRun.stderr.slice(0, 200))
        const forkRun = run(process.execPath, ['--input-type=module', '-e',
          "import('@xmoon76/pi-tui').then(() => process.exit(0)).catch(() => process.exit(3))",
        ], { cwd: probeDir })
        check('@xmoon76/pi-tui is not resolvable from the installed package (self-contained)',
          forkRun.status === 3, `status=${forkRun.status}`)
      }
    }
  } finally {
    if (!keep) rmSync(workDir, { recursive: true, force: true })
  }

  for (const line of checks) console.log(line)
  if (failures.length > 0) {
    console.error(`\ntarball smoke FAILED (${failures.length}):`)
    for (const failure of failures) console.error(`  - ${failure}`)
    process.exit(1)
  }
  console.log('\ntarball smoke passed')
}

try {
  await main()
} catch (error) {
  console.error(`tarball-smoke: ${error instanceof Error ? error.message : String(error)}`)
  process.exit(1)
}
