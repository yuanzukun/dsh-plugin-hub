#!/usr/bin/env node
/**
 * D1.3 same-Host history/live presentation parity smoke over the official
 * SessionBinding.eventSource and SessionFace.loadOlder contracts.
 *
 * @module dsh-remote-presentation-parity-smoke
 */

import assert from 'node:assert/strict'
import { createRequire } from 'node:module'
import { Context } from '@deepseek-ai/cordis'
import AgentRegistry from '@deepseek-ai/dsh-agent'
import { HostConnectionService } from '@deepseek-ai/dsh-client-connection'
import TypertGatewayService from '@deepseek-ai/dsh-api-gateway'
import commandsRemote from '@deepseek-ai/dsh-commands/remote'
import { apply as applyApiRemotes, inject as apiRemotesInject } from '@deepseek-ai/dsh-api-remotes'
import SessionController from '@deepseek-ai/dsh-api-session-controller'
import sessionRemote from '@deepseek-ai/dsh-api-session-controller/remote'
import subagentsRemote from '@deepseek-ai/dsh-subagent/remote'
import SessionStore, { SessionId } from '@deepseek-ai/dsh-session'
import { createUserMessage, MessageId } from '@deepseek-ai/dsh-llm'
import SessionProjectionRegistry from '@deepseek-ai/dsh-session-projection'
import { agentPresetProjectionDefinition } from '@deepseek-ai/dsh-agent-preset-registry'
import LocalFileSystem from '@deepseek-ai/dsh-fs-local'
import SystemPrompt from '@deepseek-ai/dsh-system-prompt'
import { RemoteAccessService } from '@deepseek-ai/dsh-api-remote-access'
import WorkingDirectory from '@deepseek-ai/dsh-working-directory'
import { titleProjectionDefinition } from '@deepseek-ai/dsh-session-title'
import { SqliteSessionQueryEngine } from '@deepseek-ai/dsh-session-query-sqlite'
import TypertRegistry from '@deepseek-ai/dsh-typert-registry'
import { DirectPresentationReader } from '../src/runtime/direct/presentation-read-direct.ts'
import { RemotePresentationReader } from '../src/runtime/remote/presentation-read-remote.ts'
import {
  projectPresentationSnapshot,
  RemotePresentationReadShadow,
} from './support/presentation-read-shadow.ts'

function installModuleLoader() {
  const nodeRequire = createRequire(import.meta.url)
  const modules = new Map()
  const previousWindow = globalThis.window
  const previousLocation = globalThis.location
  const previousTransport = globalThis.__DSH_TRANSPORT__
  const requireModule = specifier => {
    if (specifier.endsWith('/client')) {
      const id = specifier.slice(0, -'/client'.length)
      const module = modules.get(id)
      if (module === undefined) throw new Error(`official Client module ${specifier} loaded before ${id}`)
      return module
    }
    return nodeRequire(specifier)
  }
  globalThis.window = {
    __ModuleLoader__: {
      load({ id, factory }) {
        if (modules.has(id)) throw new Error(`official Client module ${id} loaded twice`)
        modules.set(id, factory(requireModule))
      },
    },
  }
  globalThis.location = { hostname: 'localhost', origin: 'http://dsh-presentation-parity.local', search: '' }
  /**
   * Import one official Client bundle from whichever channel its published
   * `./client` entry selects. DSH 0.2.1-rc.1+ splits that entry into a
   * standalone Node ESM half (`node`, which never registers through
   * `__ModuleLoader__`) and a browser loader factory (`browser`/`default`).
   * A browser registration always wins; the Node namespace only fills a gap,
   * into the SAME table the registering factories resolve `/client`
   * dependencies from.
   */
  const importClient = async (specifier) => {
    const id = specifier.slice(0, -'/client'.length)
    const imported = await import(specifier)
    if (!modules.has(id)) modules.set(id, imported)
    return modules.get(id)
  }
  return {
    modules,
    importClient,
    restore() {
      if (previousWindow === undefined) delete globalThis.window
      else globalThis.window = previousWindow
      if (previousLocation === undefined) delete globalThis.location
      else globalThis.location = previousLocation
      if (previousTransport === undefined) delete globalThis.__DSH_TRANSPORT__
      else globalThis.__DSH_TRANSPORT__ = previousTransport
    },
  }
}

function provideHostPeripheralServices(ctx) {
  ctx.provide('agentDefaultModel', {
    currentSelection: () => ({ provider: 'fixture', model: 'fixture' }),
    saveSelection: async () => {},
  })
  ctx.provide('llm', { listProviders: () => [{ id: 'fixture', name: 'fixture' }] })
  ctx.provide('attachments', {
    imageLimits: Object.freeze({
      maxImageBytes: 5 * 1024 * 1024,
      maxImagesPerMessage: 20,
      maxMessageImageBytes: 100 * 1024 * 1024,
      maxImagePixels: 40_000_000,
      maxImageDimension: 2000,
      mediaTypes: Object.freeze(['image/png']),
    }),
    admitPromptContent: async content => content,
  })
  ctx.provide('fileUploads', {
    registerAgentResolver: () => () => {},
    resolve: () => undefined,
    bindPrompt: () => ({ commit: () => {}, [Symbol.dispose]: () => {} }),
    retirePrompt: () => {},
  })
  ctx.provide('workspaceRegistry', {})
  ctx.provide('webServer', { registerUpgrade: () => () => {} })
}

const BOUNDARY_TURN = 35
const BOUNDARY_PATH = 'boundary-delivery.txt'
const BOUNDARY_DESCRIPTION = 'pagination boundary sentinel'

function appendTurn(session, turn, text, context = false) {
  session.append('turn/start', { turn })
  if (context) {
    session.append('user/message', createUserMessage({
      content: [{ type: 'text', text: `fixture context ${turn}` }],
      // Native V4 source admission rejects the retired catch-all `plugin`
      // kind, so the rc.1 parity fixture must not manufacture it. A pure
      // fixture should not impersonate a real producer either: an unknown
      // non-empty producer kind is the documented default for opaque
      // content and keeps the ContextFormed notice semantics intact.
      // Pagination counting only looks at the event type + surface op, so
      // this preserves the window tuning.
      source: { kind: 'presentation-fixture', form: 'notice', summary: 'fixture context' },
    }), { surfaceOp: 'append' })
  }
  session.append('user/message', createUserMessage({
    content: [{ type: 'text', text }],
    source: { kind: 'user' },
  }), { surfaceOp: 'append' })
  session.append('step/start', { turn, step: 0 })
  if (turn === BOUNDARY_TURN) {
    session.append('deliverables/presented', {
      turn,
      callId: 'presentation-boundary',
      files: [{ path: BOUNDARY_PATH, description: 'draft boundary description' }],
    })
    session.append('deliverables/presented', {
      turn,
      callId: 'presentation-boundary',
      files: [{ path: 'second-boundary.txt', description: 'second boundary file' }],
    })
    session.append('deliverables/presented', {
      turn,
      callId: 'presentation-boundary',
      files: [{ path: BOUNDARY_PATH, description: BOUNDARY_DESCRIPTION }],
    })
  }
  session.append('assistant/message', {
    turn,
    step: 0,
    message: {
      id: MessageId(`presentation-assistant-${turn}`),
      role: 'assistant',
      content: [{ type: 'text', text: `answer ${turn}` }],
      source: { kind: 'model', provider: 'fixture', model: 'fixture' },
    },
    stream: [],
  }, { surfaceOp: 'append' })
  if (turn === BOUNDARY_TURN) {
    session.append('deliverables/presented', {
      turn,
      callId: 'presentation-boundary',
      files: [{ path: 'late-boundary.txt', description: 'must be excluded' }],
    })
  }
  session.append('step/end', { turn, step: 0 })
  session.append('turn/end', { turn, reason: { kind: 'completed' } })
}

async function createHost() {
  const ctx = new Context()
  await ctx.plugin(TypertRegistry)
  // rc.2: the Gateway and the SessionController both inject the official
  // access decider, so the Host mounts it before either is injected.
  await ctx.plugin(RemoteAccessService)
  await ctx.plugin(SessionStore)
  await ctx.plugin(AgentRegistry)
  await ctx.plugin(SessionProjectionRegistry)
  provideHostPeripheralServices(ctx)
  ctx.get('sessionProjections').register(titleProjectionDefinition)
  ctx.get('sessionProjections').register(agentPresetProjectionDefinition)
  await ctx.inject(SqliteSessionQueryEngine.inject, queryCtx => {
    new SqliteSessionQueryEngine(queryCtx, { path: ':memory:', openAt: 'first-search' })
  })
  await ctx.plugin(SystemPrompt)
  await ctx.plugin(LocalFileSystem)
  await ctx.plugin(WorkingDirectory)
  // DSH 0.2.2 builds the controller's control/history/state sub-owners in the
  // async `[Service.init]`, so mount the plugin form (which awaits init)
  // instead of constructing the service inside an inject callback.
  await ctx.plugin(SessionController, { nativeOpen: false })
  await ctx.plugin(hostCtx => { new HostConnectionService(hostCtx, [], {}) })
  await ctx.inject(TypertGatewayService.inject, gatewayCtx => {
    new TypertGatewayService(gatewayCtx, { websocketHeartbeatIntervalMs: 50 })
  })
  await ctx.plugin({ inject: apiRemotesInject, apply: applyApiRemotes })

  const session = ctx.get('sessions').create(SessionId('presentation-session'), {
    meta: { cwd: '/tmp/dsh-d1-3-presentation', createdAt: 4_000 },
  })
  for (let turn = 0; turn < 60; turn += 1) {
    // The extra counted surface message shifts the 50-message initial page so
    // the boundary turn's assistant is the oldest included message.
    appendTurn(session, turn, `prompt ${turn}`, turn === 0 || turn === 59)
  }

  const agentFiber = ctx.plugin(() => {})
  const agent = {
    id: session.id,
    session,
    status: 'idle',
    ctx: agentFiber.ctx,
    inbox: { nextTurn: [], nextStep: [] },
  }
  ctx.get('agents').register(agent)
  return { ctx, session, agent }
}

function hostTransport(host) {
  /** The client stream carrier contract passes an optional uplink; the Host
   * wire face always takes one, so an absent uplink is an empty one. */
  async function* emptyUplink() {}
  const connection = host.ctx.get('connection')
  const shared = connection.createSharedFetchHandler('/api')
  // The official Gateway speaks for the Host Connection's own owner Peer on
  // both carrier paths (DSH 0.2.1-rc.2 requires an explicit Peer).
  const peer = connection.browserPeer
  return {
    ownsHost: true,
    fetch(input, init) {
      const request = input instanceof Request
        ? new Request(input, init)
        : new Request(new URL(String(input), 'http://dsh-presentation-parity.local'), init)
      return shared.fetch(request, peer)
    },
    openStream(endpoint, payload, signal, uplink) {
      return (async function* () {
        // Wire face: (endpoint, payload, uplink, peer, signal).
        yield* await host.ctx.get('typertGateway').wireStream.open(endpoint, payload, uplink ?? emptyUplink(), peer, signal)
      })()
    },
  }
}

async function waitFor(description, predicate) {
  const started = Date.now()
  while (!predicate()) {
    if (Date.now() - started > 5_000) throw new Error(`timed out waiting for ${description}`)
    await new Promise(resolve => setTimeout(resolve, 10))
  }
}

async function main() {
  const loader = installModuleLoader()
  let client
  let host
  let shadow
  try {
    const connectionClient = await loader.importClient('@deepseek-ai/dsh-client-connection/client')
    const gatewayClient = await loader.importClient('@deepseek-ai/dsh-api-gateway/client')
    const sessionClient = await loader.importClient('@deepseek-ai/dsh-api-session-controller/client')
    assert.ok(connectionClient !== undefined, 'official Connection Client did not load')
    assert.ok(gatewayClient !== undefined, 'official API Gateway Client did not load')
    assert.ok(sessionClient !== undefined, 'official Session Controller Client did not load')

    host = await createHost()
    globalThis.__DSH_TRANSPORT__ = hostTransport(host)

    client = new Context()
    await client.plugin(TypertRegistry)
    await client.plugin(connectionClient)
    await client.plugin(gatewayClient)
    for (const contribution of [commandsRemote, subagentsRemote, sessionRemote]) {
      await client.remote.$mount(contribution)
    }
    client.provide('fileUpload', { available: false })
    await client.plugin(sessionClient)

    const connection = client.get('connection')
    const sessions = client.get('sessions')
    await waitFor('official Client readiness', () => connection.generation.getSnapshot() !== undefined && sessions.list.getSnapshot().phase === 'ready')
    // alpha2: opening history is an explicit reference acquisition; there is
    // no Client-global selection slot to move.
    sessions.retain(SessionId('presentation-session'), { source: 'tuiMainView' })
    await waitFor('presentation binding', () => {
      const binding = sessions.binding(SessionId('presentation-session'))
      return binding !== undefined && binding.session.getSnapshot().openState === 'open' && binding.eventSource.getSnapshot().entries.length > 0
    })

    const liveAttemptId = 'presentation-smoke-live-attempt'
    const liveTurn = 60
    const liveTime = 1_700_000_000_060
    const liveChunk = { type: 'text-delta', index: 0, text: 'live fixture chunk' }
    const liveInputs = [
      { kind: 'start', sessionId: 'presentation-session', attemptId: liveAttemptId, turn: liveTurn, step: 0 },
      { kind: 'chunk', sessionId: 'presentation-session', attemptId: liveAttemptId, turn: liveTurn, step: 0, time: liveTime, chunk: liveChunk },
    ]
    const emit = host.ctx.emit.bind(host.ctx)
    emit('agent/assistant-stream', {
      agent: host.agent,
      frame: { type: 'start', attemptId: liveAttemptId, revision: 1, turn: liveTurn, step: 0 },
    })
    emit('agent/assistant-stream', {
      agent: host.agent,
      frame: { type: 'chunk', attemptId: liveAttemptId, revision: 2, index: 0, time: liveTime, chunk: liveChunk },
    })
    await waitFor('official Client transient baseline', () => {
      const binding = sessions.binding(SessionId('presentation-session'))
      return binding?.eventSource.getSnapshot().entries.some(entry => entry.type === 'transient') === true
    })

    const direct = new DirectPresentationReader({
      agentFor: id => String(host.agent.id) === id ? host.agent : undefined,
      assistantStreamBaselineFor: () => liveInputs,
    })
    const remote = new RemotePresentationReader(sessions, connection.generation)
    shadow = new RemotePresentationReadShadow(direct, remote, connection.generation)

    const directSnapshot = await direct.read('presentation-session')
    assert.ok(directSnapshot !== undefined)
    const boundaryDelivery = directSnapshot.durableEvents.find(event => {
      const data = event.data
      return event.type === 'deliverables/presented'
        && typeof data === 'object'
        && data !== null
        && data.turn === BOUNDARY_TURN
        && Array.isArray(data.files)
        && data.files.some(file => typeof file === 'object' && file !== null && file.path === BOUNDARY_PATH)
    })
    const boundaryAssistant = directSnapshot.durableEvents.find(event => {
      const data = event.data
      return event.type === 'assistant/message'
        && typeof data === 'object'
        && data !== null
        && data.turn === BOUNDARY_TURN
    })
    assert.ok(boundaryDelivery !== undefined, 'fixture did not retain the boundary delivery declaration')
    assert.ok(boundaryAssistant !== undefined, 'fixture did not retain the boundary closing assistant')

    const initialBinding = sessions.binding(SessionId('presentation-session'))
    assert.ok(initialBinding !== undefined)
    const rawInitialWindow = initialBinding.eventSource.getSnapshot()
    const rawInitialDurableEvents = rawInitialWindow.entries.flatMap(entry => entry.type === 'event' ? [entry.event] : [])
    const rawInitialFirstSeq = rawInitialDurableEvents[0]?.seq
    const rawInitialLastSeq = rawInitialDurableEvents.at(-1)?.seq
    assert.ok(rawInitialFirstSeq !== undefined, 'initial raw Remote page has no durable events')
    assert.ok(rawInitialLastSeq !== undefined, 'initial raw Remote page has no durable tail')
    assert.equal(rawInitialWindow.hasMore, true, 'fixture did not produce a paged Client tail')
    const rawHasClosingAssistant = rawInitialDurableEvents.some(event => event.seq === boundaryAssistant.seq)
    const rawHasPreClosingDelivery = rawInitialDurableEvents.some(event => event.seq === boundaryDelivery.seq)
    // rc.1 turn-aligned opening windows: the Client's follow snapshot cuts
    // at a turn boundary, so including the boundary assistant necessarily
    // includes its WHOLE leading turn — the 0.1.6-era mid-turn cut (delivery
    // excluded while the assistant stayed in) is gone upstream.
    assert.equal(rawHasClosingAssistant, true, 'raw initial page did not include the boundary assistant')
    assert.equal(rawHasPreClosingDelivery, true, 'raw initial page dropped the boundary turn\x27s own delivery declaration')
    const rawLeadingIsTurnStart = rawInitialDurableEvents[0]?.type === 'turn/start'
    assert.equal(rawLeadingIsTurnStart, true, 'rc.1 opening window must be turn-aligned')
    const completeLeadingTurn = rawLeadingIsTurnStart && rawHasClosingAssistant && rawHasPreClosingDelivery
    assert.equal(completeLeadingTurn, true, 'fixture did not reproduce a complete leading turn')

    let remoteSnapshot = await remote.read('presentation-session')
    assert.ok(remoteSnapshot !== undefined)
    assert.equal(remoteSnapshot.liveInputs.length, 2, 'fixture did not retain the live transient baseline')
    const remoteHasClosingAssistant = remoteSnapshot.durableEvents.some(event => event.seq === boundaryAssistant.seq)
    const remoteHasPreClosingDelivery = remoteSnapshot.durableEvents.some(event => event.seq === boundaryDelivery.seq)
    // The official leading-turn completeness gap CLOSED with the rc.1
    // turn-aligned opening window: the reader's initial page now carries the
    // whole leading turn (delivery declaration included) with no prefetching.
    assert.equal(remoteHasClosingAssistant, true, 'Remote reader lost the boundary assistant')
    assert.equal(remoteHasPreClosingDelivery, true, 'Remote reader dropped the boundary turn\x27s own delivery declaration')
    const readerInitialFirstSeq = remoteSnapshot.durableEvents[0]?.seq
    const readerInitialLastSeq = remoteSnapshot.durableEvents.at(-1)?.seq
    const presentationSkips = []

    let comparisons = 0
    let deliveredTail
    while (true) {
      const outcome = await shadow.compare({
        sessionId: 'presentation-session',
        projection: { focusMode: true, windowTurns: 20 },
      })
      assert.equal(outcome.status, 'compared')
      assert.equal(outcome.report.comparable, true)
      assert.deepEqual(outcome.report.mismatches, [])
      const pageProjection = projectPresentationSnapshot(remoteSnapshot, { focusMode: true, windowTurns: 100 })
      const pageClosing = pageProjection.messages.find(message => message.kind === 'assistant' && message.text === `answer ${BOUNDARY_TURN}`)
      if (pageClosing?.deliverables !== undefined) {
        if (deliveredTail !== undefined) assert.deepEqual(pageClosing.deliverables, deliveredTail)
        deliveredTail = pageClosing.deliverables
      }
      comparisons += 1
      if (!remoteSnapshot.hasMore) break

      const before = remoteSnapshot.durableEvents.map(event => event.seq)
      remoteSnapshot = await remote.loadOlder('presentation-session')
      assert.ok(remoteSnapshot !== undefined)
      const after = remoteSnapshot.durableEvents.map(event => event.seq)
      assert.ok(after.length > before.length, 'loadOlder did not extend the durable window')
      assert.deepEqual(after.slice(-before.length), before, 'older paging changed the retained overlap')
    }

    assert.equal(remoteSnapshot.durableEvents.length, directSnapshot.durableEvents.length)
    assert.equal(remoteSnapshot.hasMore, false)
    assert.ok(comparisons >= 2, `expected explicit loadOlder coverage; comparisons=${comparisons}`)
    const finalProjection = projectPresentationSnapshot(remoteSnapshot, { focusMode: true, windowTurns: 100 })
    const boundaryMessages = finalProjection.messages.filter(message => {
      const value = message
      return value.kind === 'assistant' && value.deliverables?.some(file => file.path === BOUNDARY_PATH)
    })
    assert.equal(boundaryMessages.length, 1, 'boundary delivery did not attach to exactly one closing assistant')
    assert.deepEqual(boundaryMessages[0].deliverables, [
      { path: BOUNDARY_PATH, description: BOUNDARY_DESCRIPTION },
      { path: 'second-boundary.txt', description: 'second boundary file' },
    ])
    assert.equal(finalProjection.messages.some(message => message.kind === 'deliverables'), false)
    console.log(JSON.stringify({
      status: 'passed',
      comparable: true,
      mismatchCount: 0,
      skipped: presentationSkips,
      liveInputs: liveInputs.length,
      pagesCompared: comparisons,
      durableEvents: remoteSnapshot.durableEvents.length,
      deliveryBoundaryChecked: true,
      deliveryBoundaryComplete: remoteHasPreClosingDelivery,
      fullHistoryDeliveryComplete: deliveredTail !== undefined,
      targetTurn: BOUNDARY_TURN,
      deliverySeq: boundaryDelivery.seq,
      closingAssistantSeq: boundaryAssistant.seq,
      remoteInitialFirstSeq: rawInitialFirstSeq,
      remoteInitialLastSeq: rawInitialLastSeq,
      remoteInitialHasMore: rawInitialWindow.hasMore,
      remoteInitialEventTypes: rawInitialDurableEvents.map(event => event.type),
      assistantPresentInInitialPage: rawHasClosingAssistant,
      deliveryPresentInInitialPage: rawHasPreClosingDelivery,
      readerInitialFirstSeq,
      readerInitialLastSeq,
      readerHasClosingAssistant: remoteHasClosingAssistant,
      readerHasPreClosingDelivery: remoteHasPreClosingDelivery,
      completeLeadingTurnReproduced: completeLeadingTurn,
    }))
  } finally {
    shadow?.dispose()
    if (client !== undefined) await client.fiber.dispose()
    if (host !== undefined) await host.ctx.fiber.dispose()
    loader.restore()
  }
}

main().catch(error => {
  console.error(`DSH_REMOTE_PRESENTATION_PARITY_FAILURE: ${error instanceof Error ? error.message : String(error)}`)
  process.exitCode = 1
})
