# Terminal output safety

This is the ONE contract for how `@xmoon76/dsh-pi-tui` projects untrusted text
onto a terminal. It owns the display projection itself, the authority split
between raw source and rendered bytes, and the exceptions; subsystem documents
own their own layout contracts and link here instead of restating this policy.

## Threat and boundary

Text that originates outside the TUI — DSH/Host Job output, Session transcript
rows, model output, tool JSON results, local `!` shell output, subprocess logs,
external package metadata, approval arguments, session titles and search
snippets — may carry arbitrary terminal control bytes. The terminal interprets
those bytes; it does not display them. A raw `ESC ] 52 ; … BEL` can overwrite
the clipboard, `ESC [ ? 1049 h` can switch screens, `ESC [ 2 J` can erase the
frame, and a bare `CR` can rewrite a hint row so the UI lies about which key
does what.

The TUI therefore treats every external byte as display material, never as
terminal protocol. Legitimate application-generated control (framing, cursor,
mouse, images, theme color, the terminal title and the footer's vetted
hyperlinks) is trusted and must survive untouched.

## Authority: one raw source, one disposable projection

| Fact | Authority | Projection |
|---|---|---|
| Job raw bytes, retention proof, exact copy | DSH Host observation / `JobInspectorState` | `sanitizeDisplayLog` on the **body Text only** |
| Transcript message text, classification, persistence | canonical Session/Transcript message | `sanitizeDisplayText` at render construction |
| Rendered row geometry / search hits | the actually painted rows + `JobOutputSearch` | never recomputed from raw bytes |
| Terminal style for **external** log text | the whitelist below | `sanitizeDisplayLog` |
| Plugin install operations, session identities, picker ids | existing controllers / `SessionReader` | display-only string projections |
| TSP frame/currentness | installed SDK + `src/tui/tsp/session.ts` | `sanitizeDisplayText` on node **text props only** |
| Display `/copy` payload | official latest `assistant/message` + same-Session Folder settlement + PR1 publications + `planVisualPlacement` | text spans only; raw Session/`/transcript` keep the marker |

The source of truth — event objects, raw observations, copy payloads, search
source keys, navigation ids, exact-copy offsets and persistence — is **never**
sanitized in place.

`/copy` is a display sink with one deliberate projection of its own: a
published-visual marker line that the renderer CONSUMED is not part of what the
user reads, so the clipboard payload omits that exact source span while every
other byte stays original (see `docs/architecture/transcript.md`, "Display
`/copy` for consumed visual markers"). The durable Session body, the model
history, search and the raw `/transcript` export never take this projection. Rendering is a disposable projection over it: the same raw
value can be copied byte-exactly and also painted safely.

## The two policies

`src/tui/presentation/terminal-text.ts` is the only implementation. It is a
pure linear-time `string -> string` scanner: no cache, no process state, no
side effects, and it returns the exact input string when nothing needs
projection.

### `sanitizeDisplayText(source)` — plain text

Used for prose, labels, Markdown, command arguments, titles, descriptions,
paths, diff line text and tool summaries.

- removes every recognized ANSI/VT sequence: CSI, OSC (including OSC 8), DCS,
  SOS, PM, APC, both 7-bit (`ESC …`) and 8-bit C1 forms, complete or
  unterminated (an unterminated string consumes to end of input);
- removes other ESC-led forms and every remaining C0/C1 control and DEL;
- normalizes `CRLF` to one `LF`, a lone `CR` to one ASCII space;
- converts `TAB` to three spaces;
- preserves `LF`, ordinary Unicode, CJK, emoji and combining marks verbatim;
- never emits raw `ESC`, DEL, C1, OSC, DCS, APC, CSI or any C0 other than `LF`.

### `sanitizeDisplayLog(source)` — untrusted log/terminal text

Used only for captured terminal streams: bash/pwsh tool results, the local
`!`/`!!` shell card, the legacy Job output viewer and the Job workspace body.

- identical control removal, except that **strictly whitelisted complete CSI
  SGR** survives (see below);
- a lone `CR` becomes `LF` so progress frames become readable **records**
  instead of overwriting one screen row (deliberate divergence from PTY
  overwrite semantics; readable history beats exact mutable-screen emulation);
- when at least one SGR survives, an app-owned `ESC[0m` is appended so a
  source-controlled style can never bleed past its display block.

### `sanitizedPhysicalLine(source)` — one physical row

`src/tui/presentation/lines.ts` applies the plain policy and then folds every
surviving `LF` (and any residual `TAB`/`CR`) into one space. It is the required
projection for display slots that are semantically exactly ONE terminal row:
list/panel rows and their labels, badges, secondary text, notices, install log
rows and panel titles; picker item fields (label, group, description, badge /
effort token); one-line headers (tool / command / workflow card heads, Context
row titles, the approval tool name, diff hunk headers); the working message,
dock/todo summary and goal line; the footer's builtin external fields
(model provider/id/effort, cwd, branch, project, agent-preset label, reasoning
effort and host versions) and the welcome card's session facts (cwd, session
id, model, preset, version); and the TSP one-line structured props
(`ui.card.head`, `ui.tool.name`/`title`/`target`, picker `label`/`detail`/
`title`/group labels/subtitle) plus its single-line interaction labels
(approval `tool` identity, question `status`/`header`, option labels). A row
budget, click/hit map or width measurement is built from one array element;
an embedded line break would escape both the row count and the geometry it
indexes.

Multi-line prose, Markdown, code and result/log bodies keep
`sanitizeDisplayText` (or `sanitizeDisplayLog`) and are carried by a component
or node with a real multi-line budget (`Text`, `Markdown`,
`CompactTextPreview`, `ui.md`, `ui.code`, wrapped rows). When a folded terminal
preview is reduced to ONE row, the ORDER is load-bearing:
1. project the FULL source under the log policy first — a lone `CR` is a
   zero-width raw control but a visible record/space after the policy, so
   measuring the raw text would under-count the folded row's width;
2. fold the safe `LF` records into the preview (first records, width-capped);
3. re-project the SHORTENED preview so its app-owned `ESC[0m` reset rides at
   the preview tail (the full-log reset was cut away), then fold any residual
   break. Skipping the first step can widen the row past its budget; skipping
   the third can bleed a styled prefix into the next physical row.
A preview that dropped whole records must end in the hidden-content `…`
marker even when the retained text fits the width (only the exact record
budget is unmarked); a width cut already terminates in the same marker, so
the two causes never double it. A final newline — and a trailing segment that
only carries terminal style, such as the app-owned `ESC[0m` — terminates the
last record and is never itself a hidden record; genuinely blank records
(including a blank line between two newlines) stay records.

## SGR whitelist (log policy only)

Only a complete `ESC [` … `m` with numeric semicolon parameters survives:

- attributes `0,1,2,3,4,7,9,22,23,24,27,29,39,49`;
- standard 8/16-color foreground/background `30–37`, `40–47`, `90–97`,
  `100–107`;
- extended color `38/48;5;n` with `0 <= n <= 255`, or `38/48;2;r;g;b` with
  every channel `0..255`;
- empty `ESC[m` as a reset.

The **whole** SGR is rejected on malformed, unknown, colon, empty or
out-of-range parameters and on missing components. A raw C1 CSI never survives
even when it expresses SGR, so no C1 byte reaches the TTY. OSC 8 hyperlinks
are intentionally **not** part of this policy (the footer command's separate
sanitizer keeps its own vetted OSC 8 contract; that contract is unchanged).

## What is forbidden

- **Never** strip ANSI at the final terminal writer
  (`TuiAltScreen`/`TuiMainScreen.terminal.write`) or in the vendored
  `packages/pi-tui/**` fork. Application framing, color, mouse, image and
  cursor protocols are trusted and share that writer.
- **Never** sanitize the source object, the copy payload, the search source
  key, a navigation id, a picker value or an exact-copy offset. Only the
  painted string is disposable.
- **Never** sanitize an already theme-painted string: that would strip the
  TUI's own trusted color. Project the external part **before** the theme
  applies.
- **Never** add a terminal emulator, PTY, image passthrough or a
  color-preserving parser dependency to solve this.

## Specialized contracts that stay as they are

These own their own policy and are guarded by negative-control regression
tests, not converted to the log policy:

- `src/tui/footer/ansi-sanitize.ts` — the user-configured footer command may
  style its output (SGR + vetted OSC 8).
- `src/tui/terminal/title.ts` — the terminal title projection.
- `src/tui/components/source-text-layout.ts` + the History / Job Command
  readers — offset-aware exact-source rendering and copy.
- extension `slot-outlet` spans — the extension boundary owns its presentation.

## TSP opt-in parity

The experimental Tern renderer (`DSH_PI_TUI_RENDERER=tsp`, off by default) maps
the same transcript structure onto SDK nodes. Multi-line node content
(`ui.text` bodies, `ui.md`, `ui.code`, `ui.badge`) uses `sanitizeDisplayText`;
one-line structured props (`ui.card.head`, `ui.tool.name`/`title`/`target`,
picker `label`/`detail`/`title`, group labels and `subtitle`) and the
single-line interaction labels (approval `tool` identity, question
`status`/`header`, option labels) use `sanitizedPhysicalLine`; the approval
reason/arguments, question body/detail and option descriptions keep the
multi-line plain policy. The tool's canonical `TranscriptMessage.name` and the
`SessionEvent` payload stay raw for tool semantics; only the displayed
`ui.tool.name` is projected. Raw ids, node keys, answer values, action/event
identifiers, SDK frames and currentness are untouched, so source/GUI evidence
tiers are unchanged. A structural node check proves the payload is safe; it
does not prove the closed-source Tern client's own rendering — that requires
version-qualified real-pane evidence before it may be claimed.

## Terminal title (OSC 0) and terminal-local cwd (OSC 7)

OSC 0 (window title, Session identity) and OSC 7 (terminal-local cwd) are
DISTINCT authorities. The title source order is fixed:

```text
1. session title non-empty                    -> dsh · <sanitized session title>
2. session identity WITH an official cwd      -> dsh · <shortCwd(official session cwd)>
                                                 (Direct and Remote alike)
3. session identity WITHOUT an official cwd   -> dsh
                                                 (never the Client launch cwd)
4. no session identity (sessionless, either   -> dsh · <shortCwd(Client launch cwd)>
   backend)
5. a Remote Host cwd may be shown as OSC 0 identity, but is never published as
   the OSC 7 terminal-local cwd
```

Step 3 is the negative control that separates identity from the OSC 7 fallback:
a session that exists but has no official cwd names itself with the bare brand,
never with the local directory. Step 4 is legal on both branches — with no
session identity there is no Host workspace to impersonate.

The seam is `updateTerminalTitle({ sessionTitle, cwd: sessionCwdFact() })`; the
cwd source is never re-chosen in the terminal adapter. Authority:
`src/app/surface/status-runtime.ts`, `src/tui/terminal/title.ts`. Proof:
`test/app/tern-terminal.test.ts` (fact/observable matrix) and
`test/tui/terminal-title.test.ts` (connected OSC 0 proof).

## Test matrix and repro

| Contract | Test owner | What it proves |
|---|---|---|
| projection semantics (whitelist, CR/TAB, incomplete sequences, 1 MiB bound) | `test/tui/terminal-display-sanitize.test.ts` | pure `string -> string` behaviour |
| untrusted transcript bytes on the wire | `test/domain/rendering.test.ts` | Full/Compact/Focus, every message class, raw source unchanged, one-row command/tool/Activity identities |
| Job body / search / copy | `test/app/job-inspector-workspace.test.ts`, `test/app/job-output-interaction.test.ts`, `test/app/job-workspace-visual.test.ts` | hostile output, CR records, Find on the painted row, byte-exact copy |
| local `!` shell log | `test/tui/local-shell-card.test.ts` | whitelisted SGR only, CR frames readable |
| sibling surfaces | `test/domain/approval.test.ts`, `test/app/plugin-manager-classify.test.ts`, `test/app/plugin-manager-install.test.ts`, `test/tui/model-picker.test.ts`, `test/integration/job-output-viewer.test.ts`, `test/app/session-picker-content-search.test.ts` | no fake hint row via CR, no OSC in chrome, LF/CRLF/TAB/OSC folded onto ONE row per single-line field |
| builtin footer + welcome chrome | `test/domain/footer-display-safety.test.ts`, `test/domain/rendering.test.ts` | hostile cwd/model/branch/project/preset/version rendered through the REAL default footer and welcome card: one physical row each, no OSC/C1 at the TTY, raw workspace authority untouched |
| TSP interaction labels | `test/app/tern-tsp-interaction.test.ts` | approval tool identity / question header / option labels carry no LF or control in their SDK props; question body/detail and option descriptions stay multi-line |
| negative controls | `test/tui/footer-ansi-sanitize.test.ts`, `test/tui/terminal-title.test.ts`, `test/client/history-panel.test.ts` | the specialized contracts above still work |

Minimal reproduction:

```ts
import { sanitizeDisplayLog, sanitizeDisplayText } from './src/tui/presentation/terminal-text.ts'

sanitizeDisplayText('\u001b]52;c;YXR0YWNr\u0007ok\u001b[2J')  // 'ok'
sanitizeDisplayLog('start\r10%\r100%\n')                     // 'start\n10%\n100%\n'
sanitizeDisplayLog('a\u001b[38;5;196mred\u001b[0m')          // keeps the SGR, ends with ESC[0m
sanitizeDisplayLog('a\u001b[38;2;999;1;1mb')                  // 'ab' (malformed SGR dropped whole)
```

Wire assertions must assert that the malicious **specific** sequences are
absent and that the only surviving SGR are whitelisted — never that the stream
contains zero `ESC`, because application-owned cursor, rendering, color, input
and protocol controls legitimately use it.

## Attachment placeholder projection

Attachment placeholders exist only in the DISPLAY projection:
`textWithAttachmentMarkers(blocks)` keeps text blocks verbatim and inserts
`🖼️ name` / `📄 name` at each block's position with exactly one separating
space (never doubling a user-typed space). For text-only content it equals
`textOf`. The projection feeds the user-message flat text, the search corpus and
the bubble/loader-less fallback.

Authority: `src/domain/transcript/content-blocks.ts` (re-exported by
`src/transcript.ts`), consumed by `TuiApp`.

Must-not: mutate the source `ContentBlock`s or an assistant/tool `textOf`; let
search miss the image identity; let a loader-less host drop the image; treat the
marker as a second persisted representation.

Proof: `test/client/image-transcript.test.ts`, `test/client/folding.test.ts`,
`test/app/queue-notices.test.ts`.

## Surface-specific projection

The generic policies above are the only sanitizers. Two surface-specific
applications are load-bearing:

- **Task Browser.** Every dynamic Task Browser field (list/detail/parent/mode/
  status/access/Stop confirmation, header, stale banner, no-match text) goes
  through `sanitizedPhysicalLine` BEFORE width/theme. The one app transient
  notice line does the same for Stop/interrupt/delivery-error text. Stored
  notices and business DTOs stay raw. The Job workspace keeps its own
  `chromeText()` projection. The Search row is user/query text and is outside
  this boundary. Never sanitize after theme styling, never sanitize the copy
  payload/DTO, and do not add a second single-line helper.
  Proof: `test/app/task-browser-text-safety.test.ts`,
  `test/app/task-center-refactor.test.ts`.
- **Job Command / Output copy.** Output Copy sends the captured
  `JobObservedSnapshot.text` verbatim; Command Copy All sends the original
  `label` byte-exact (whitespace/TAB/CRLF/trailing newline survive); drag sends
  `label.slice(start, end)`. Every chrome field strips complete CSI/OSC/APC/DCS
  and drops C0/C1/DEL before styling. Official bytes and copy payloads are never
  rewritten, and no payload is inferred from painted/truncated text. `Copy sent`
  proves emission only, never an OS-clipboard receipt. Authority:
  `src/tui/components/source-text-layout.ts`, `JobCommandDocument`/`Reader`,
  `ClientActions.copySelection`. Proof: `test/app/job-workspace-visual.test.ts`
  ("the Command page owns the EXACT selection copy", "copies only the original
  label").
