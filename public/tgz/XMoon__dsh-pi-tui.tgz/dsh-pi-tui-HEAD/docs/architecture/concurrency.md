# Session ownership and safety

Session writer ownership has exactly two layers on the master baseline:

1. **Host writer ownership (cross-process)** — DSH's `SessionHandle` +
   `SessionWriteLease` (a kernel flock on `session.lock`) is the sole
   cross-process authority for who may write a session. One process-owned
   surface per session is guaranteed by DSH authority; the TUI adds no
   second persistence/artifact-level owner lock.
2. **TUI local coordination (in-process)** — `SessionTransitionGate`,
   `SessionOperationBarrier`, and generation/stale fences keep the TUI's
   own surface consistent while it switches sessions.

The in-process layer lives in the session layer (A2): the ownership core
(`src/app/session/ownership-core.ts`) owns the ONE current-owner slot, the
session generation, the navigation epoch, the transition gate, the operation
barrier and the owner-release ledger; the bound runtime
(`src/app/session/runtime.ts`) runs the four commit shapes
(`src/app/session/commit-order.ts`) plus the retirement coordination; the
consumer-owned ports are in `src/app/session/owner-access.ts`; and
`src/app/direct/owner-registry.ts` + `src/app/direct/owner-retirement.ts` are
the Direct adapters. The runner keeps the surface providers and the Direct
composition root.

## Host writer ownership: DSH SessionHandle + SessionWriteLease

dsh sessions cannot be shared across processes. Two dsh processes (TUI +
web, or two TUIs) holding one session each number events from their own
in-memory log length, so both can mint the same `seq` and corrupt the log
at the `session/end-seed` marker. DSH closes the OPEN path itself:
`agents.create` / `agents.resume` return a `SessionHandle` whose
`dispose()` is the structured teardown of the persistence writer, and the
kernel-flock `SessionWriteLease` (on `session.lock`) is the cross-process
writer authority. A competing opener is refused with
`SessionAlreadyOwnedError`; the TUI surfaces that refusal and leaves the
session untouched — no pin, no retry, no fallback.

The TUI therefore performs NO TUI-side lock bookkeeping: no `owner.lock`
file, no pid/starttime stale takeover, no lease/cooling verifier, no
PINNED quarantine, no manual lock recovery. A clean exit needs no lock
release — the DSH session teardown releases the lease. The TUI's physical
owner.lock / lease / cooling / PINNED stack is removed legacy.

## DSH Session persistence and v2 event planes

The TUI leaves durable format generation to DSH (Session V2/V3 per the runtime)
while keeping its two Session v2 event planes distinct:

- durable `assistant/message` is the surface settlement; durable
  `assistant/attempt` is non-surface attempt evidence that may be projected as
  interrupted UI evidence but never as a model-visible message;
- transient `agent/assistant-stream` carries live deltas and controls before
  durable settlement, and is not used as a second persistence format. Its
  `block-end` control carries the completed content block; the TUI replaces
  that block index in the live projection rather than appending a duplicate.
  The Direct adapter also retains the active prefix per exact live Agent for a
  late subagent-viewer attach, clears it at end/restart/disposal, and never
  writes that transient baseline to the durable Session. A continuable child
  viewer follows the current registered Agent lifecycle, so a same-session
  cold-resume after disposal rebinds to the new Agent at `turn/start` (before
  the first assistant frame) while delayed frames from the retired Agent remain
  fenced.

The session picker consumes the semantic list and zero-I/O projection-cache
seams only. It never observes a cold Session merely to fill a label and never
triggers historical migration; DSH persistence owns migration when an explicit
resume opens the Session.

### The field-observed worst shape

Without the open-time refusal, the worst corruption shape unfolds
silently:

1. Process A opens session S and is mid-turn (an open `step/start` is the
   last event, A's in-memory seq is `n+1`).
2. Process B opens S. dsh's persistence `prepare` sees the open turn and
   **synthesizes interrupted-turn closers into the shared log** (`step/end`,
   `turn/end interrupted`, then the constructor's `session/end-seed`), all
   appended to the file at seqs `n+1…n+3`.
3. B's in-memory log is now `n+4` — it MATCHES the file, so B proceeds. A,
   meanwhile, still holds seq `n+1` in memory and keeps appending
   `assistant/chunk` at seq `n+1` — colliding with B's synthesized events
   and corrupting the log. No post-open check can catch this: B's memory
   equals the file from its very first write.

The DSH `SessionWriteLease` closes the OPEN path so the scenario never
starts: the second opener's `resume` is refused with
`SessionAlreadyOwnedError` before any persistence work happens.

## TUI local coordination

The DSH lease protects the session FILE from cross-process writers. A
separate hazard is IN-PROCESS interleaving between the TUI's own
transition paths — `/new`, `/fork`, `/rewind`, `/sessions` switch/open
and the first-session creation. Before the gate, two such workflows could
overlap across their awaits:

- a fork child can be published while the visible surface moves; publication
  is not rolled back because the persisted child is authoritative. The stale
  child owner is parked in a Direct-only pool and a later `/sessions` open
  claims it instead of starting a second writer;
- a rewind adoption's identity check could pass, then yield across the
  old-owner retirement await, letting a concurrent switch land and later be
  overwritten by the first continuation. The adoption critical section now
  rechecks the navigation identity under the gate.

### SessionTransitionGate — one transition at a time

`src/app/session/transition-gate.ts` is a **process-local single-writer queue**: ordinary
session transitions run inside `SessionTransitionGate.run`, held from BEFORE
the child create or Direct `resume` until the transaction settles. Host fork
dispatch is intentionally outside this destructive transition queue; only a
known-current fork adoption enters the gate for the visible handoff and
old-owner retirement. Tasks are strictly FIFO; a rejected task fails its own
caller and never blocks the queue; re-entering the gate from inside a task
is refused loudly (AsyncLocalStorage detects it — re-entry would deadlock
the queue). The runner exposes the gate as `runner.withSessionTransition(task)`
(the user-navigation admission is `SessionRuntime.withNavigation`, entered
through the same gate).

On top of the gate, ordinary session transitions share ONE transaction shape
(`runner.transitionTo`), whose phase order — fixed in `src/app/session/transition.ts`
(`runTransitionTo`, unit-tested) — is the whole point:

1. QUIESCE OLD — `old.whenIdle()` then the FINAL flush. May fail → abort,
   ZERO child side effects. For a USER NAVIGATION (`/new`, a selected-session
   switch) the session runtime has ALREADY sent ONE exact-owner stop of the
   captured old generation at the transition admission, BEFORE the admitted
   writers drained (see "Navigation-initiated stop"); this quiesce then waits
   for that stopped Turn to actually end. `/preset` and the other ordinary
   transitions never stop the owner they are replacing.
2. ALL TUI-owned preflight (preset/composition/stale checks — BEFORE the
   DSH boundary, so failures abort with ZERO side effects).
3. create/open the CHILD — may fail → abort; once it SUCCEEDS the child
   is published (`session/created` → persistence may already write its
   seed) and there is NO failure path after this point that may be
   interpreted as "the child never happened": `dispose()` stops an agent
   but never deletes a persisted session, and dsh has no durable rollback
   API. A rejection is NEVER retried (no same-ID recovery): the old
   session stays current and the user may retry.
4. COMMIT — a synchronous critical section: the generation reset runs BEFORE
   the new owner is published into the ownership core
   (`runOrdinaryCommit`, `src/app/session/commit-order.ts`), with no awaits
   between its steps.
5. RETIRE — retire the OLD owner through the retirement port, which owns the
   official session-close order (see the session-owner retirement section);
   child surface/catalog work is best-effort and the committed child always
   stands.

### Fork dispatch and adoption

`/fork` and `/rewind` are deliberately not ordinary transition transactions.
They capture the source identity and navigation epoch, dispatch the semantic
Host fork immediately without `whenIdle()` or the destructive transition gate,
and keep the operation in the session runtime's pending-fork ledger through
adoption or parking. The Host boundary fixes the completed-turn cut at
admission, so a busy source is not waited to a later boundary.

When a known child settles, the runner rechecks the captured identity. A newer
navigation leaves the visible surface unchanged and parks the successful Direct
owner; it does not roll back the published child. If the identity is current,
a short gated handoff swaps the visible handle, bumps the generation, restores
rewind draft state, and retires the old owner. Cleanup waits for pending forks
before retiring current and parked Direct owners, including late published-
with-error settlements.

A rejected `create`/`open` is handled WITHOUT any publication-phase
inference: the old session simply stays current and the user may retry.

`whenIdle()` is an INSTANT check, not a freeze: the old agent can be
woken again by a prompt in `queue` or `steer` mode while the transition still
awaits (flush, prepare, create). A write in that window would target a session
the transition is about to retire. Two mechanisms cover it, on DIFFERENT sides
of admission:

- A writer that starts BEFORE the transition has `whenIdle()` observe the
  active turn, but the transition cannot wait for it via `whenIdle()`. The
  `SessionOperationBarrier` is what makes the transition WAIT: every TUI-owned
  session write runs inside `runWriter` and every transition inside
  `runTransition`, so once a writer is ADMITTED the transition drains it before
  quiescing the old agent. An admitted writer therefore never re-reads the
  transition gate — doing so would truncate it mid-sweep (the writer-first
  contract).
- A writer that STARTS while a transition already holds the barrier is refused
  by the barrier itself (`TransitionInProgressError`), restores/keeps the
  draft, the invocation line or the shell card, and notifies "a session
  transition is in progress". This is the only gate-based refusal for a
  semantic write; there is no automatic retry.
- The submission re-validation (agent object + session generation) covers the
  window AFTER the transition commits.

The legacy `SessionTransitionGate.busy` pre-read survives ONLY as the
attachment-intake UX fence (`sessionTransitionPending()`); no semantic writer
re-reads it. The live `/preset` swap (the official
`agentPresets.select` blank check + recompose transaction + durable
`agent-preset/selected` commit) likewise runs INSIDE the transition gate,
so the captured Session can never be quiesced mid-swap.

### SessionOperationBarrier — writers vs. transitions

The `busy` flag alone cannot stop a writer that started BEFORE the
transition and is still awaiting a provider/IO — the
`SessionOperationBarrier` therefore runs every TUI-owned session write
inside `runWriter` and every transition inside `runTransition`: a
transition waits for in-flight writers to drain before it quiesces the old
agent, and writers that start while a transition holds the barrier are
refused (`TransitionInProgressError`).

`runTransition` also owns the ONE user-navigation admission seam
(`stopOldOwner`, see below). It runs after the freeze and before the drain,
exactly once; it is not a writer admission and ordinary writers stay refused
while it runs.

### Navigation-initiated stop — `/new` and a selected-session switch

A user who leaves the current Session (`/new`, a Session-Browser selection,
`/resume <id>`) does not have to wait for the old Turn to finish naturally, and
does not depend on a modal Question being answered. The canonical order is:

```text
UI intent captures the OLD generation (scope)
→ freeze new ordinary writers (barrier)
→ ONE exact-owner stop of the CAPTURED owner (control authority)
→ admitted ordinary writers drain (the stop may be what lets one settle)
→ whenIdleOrAbort / preflight
→ final flush
→ create/open the target ONCE
→ synchronous owner publication
→ old-owner retirement (its own close-order cancel → idle → drain → flush → dispose)
```

- The stop is the semantic USER cancel of the exact captured owner
  (`SessionOwnerRetirement.cancel`): Direct calls the captured
  `Agent.cancel({kind:'user'}, {keepInbox:true})`, Remote calls the exact
  binding generation's official `SessionFace.cancel()`. It runs at most once,
  and it is NOT the shutdown `preCancel`, NOT the retirement close-order
  cancel (which still runs after the commit) and NOT a writer bypass.
- The identity is captured SYNCHRONOUSLY by the command owner before its first
  await (`/new`) or by the scoped browser intent. A stale capture — another
  navigation published first — aborts silently without touching the
  replacement generation. An UNSCOPED picker selection captures the owner it
  is actually leaving inside the gate, right before the freeze, so a queued
  later selection keeps its own FIFO intent instead of inheriting an older
  generation.
- ONLY a `committed` cancellation is permission to enter the next phase.
  `rejected` (a proven refusal), `cancelled` (confirmed pre-dispatch: the exact
  generation could not be addressed, or the runner is exiting) and
  `indeterminate` (the call WAS dispatched but its effect is unproven) all abort
  BEFORE the drain and before any child work: the current Session stays live,
  nothing is created/opened and nothing is retried. `cancelled` means "the Host
  cancel was NOT ADDRESSED", never "there is no work to stop": a disconnected
  Connection generation, a replaced binding or a released owner reference
  leaves the old Host Turn unproven, and `whenIdleOrAbort` returning
  `'unobservable'` for a rolled/released binding or a changed Connection
  generation is not proof of idle — the accepted stop carries its EXACT
  generation receipt into the quiesce, so a reconnect during the writer drain
  can never make the quiesce observe a later generation —
  navigation never reaches that quiesce without a `committed` stop. Only
  `indeterminate` states that the old Turn may already have stopped. The phase
  distinction comes from `SessionOwnerRetirement.cancelForNavigation`, which
  leaves the control `cancel` taxonomy untouched: the control Stop still
  reports a dispatched caller/carrier cancellation as `cancelled`, while
  navigation resolves that same reply as dispatched-unproven.
- Cancellation is never rolled back. An ACCEPTED stop has two distinct proven
  facts: until the pre-commit OLD-owner quiesce completes, a failure says the
  stop was REQUESTED but its completion is not confirmed; only after an
  OBSERVED settle (`whenIdleOrAbort === false`) followed by the final flush does
  a failure say the old Turn is stopped and cannot be resumed. An
  `'unobservable'` quiesce (a rolled/released exact binding) is NOT a completed
  quiesce, and the Remote no-op flush adds no proof. A failure before any
  accepted stop owns no message.
- Browsing is read-only: opening `/sessions`, bare `/resume` or `/search` never
  stops the current owner. Only an explicit target selection enters this
  admission.
- Duplicate `/new`: the command registration holds a local in-flight marker,
  set in the handler's FIRST synchronous step (before its first await and
  before the transition gate) and released at the true terminal settlement.
  A second `/new` that reaches the handler while the first is in flight is
  refused before any Host create ("a fresh session is already starting"),
  never reuses the first result, and can be retried after a failure. The
  transition gate's `busy` is NOT the duplicate authority — the gate also
  serializes `/preset`, switches and fork adoption. A composer's own Submit
  FIFO + frozen surface refuse an overlapping second gesture before the
  handler (its draft is restored); the marker is the admission for every other
  caller (the Host command plane / another surface) and for the registration
  entry itself.

### SessionRuntime.withWriter — the writer-admission owner

Every TUI-owned session writer enters the barrier through the BOUND session
runtime (`src/app/session/runtime.ts`, `SessionRuntime.withWriter(scope, task)`).
This is the ONE writer-admission owner: the package entry and the composition
root (`src/app/bootstrap.ts`) hold no direct `barrier.runWriter` call. No semantic writer re-checks the transition gate
AFTER it was admitted: the submission-facing entrypoints (plain prompt, busy
delivery, steer, queue pull-back, `HostCommandPort` submission, shell submit)
admit through the bound runtime and, once admitted, carry only the
surface-lifetime fence — an admitted writer is never truncated by a waiting
transition. Reading `transitionGate.busy` is therefore NOT a writer-admission
mechanism at all: it has exactly ONE production reader, the attachment-intake
UX fence (`sessionTransitionPending()`, `src/tui/commands/artifacts.ts`). Every semantic
writer — including the `HostCommandPort` submission — admits only through the
bound runtime, and a `TransitionInProgressError` raised there is settled as a
PROVEN pre-dispatch refusal (draft restored + the transition notice), never as
a generic command failure.

- The admission is SCOPE-BOUND and a NO-YIELD section: the scope-currentness
  read (`SessionScopeAuthority.isCurrent`) and the barrier occupancy run in the
  SAME synchronous call stack — there is deliberately no `await` between them,
  so a transition started immediately after the writer returns must wait for it,
  and a stale capture cannot be overtaken by a transition that commits in a
  later microtask.
- The two refusals are DISTINCT signals and must never be conflated. A STALE
  capture (the owner/generation the scope pinned is gone) rejects with
  `SessionScopeSupersededError` (exported from `src/app/session/scope.ts`)
  BEFORE the task body runs; a writer arriving after a transition already FROZE
  the barrier keeps the barrier's own `TransitionInProgressError` (no automatic
  retry — the caller restores its draft). Collapsing them would misreport a
  stale owner as a frozen transition.
- The `session/writer-held` caller/UI insertion point is
  `src/app/submission/runtime.ts` (the lower-level writer admission owner):
  it owns the submission-facing APPLICATION entrypoints (`submitPrompt`,
  `deliverBusy`, `steer`, `pullBackQueue`, `executeHostCommandSubmission`,
  `submitShell`) and, for each, the `WriteOutcome` classification plus the
  draft/queue/card settlement. Since A5b the caller-side WORKFLOW (the submit
  FIFO/ack/local-echo state, the dispatch and the shell card lifecycle) lives in
  `src/app/submission/controller.ts` + `src/app/submission/user-shell.ts`, and
  the one scope-fenced section helper is
  `SubmissionController.withWriterSection` — ownership moved, the contract did
  not. Every write they perform enters through `SessionRuntime.withWriter`, so
  the future Remote writer-held recovery hangs off this ONE caller-side module
  rather than every writer site.

### Control admission — Stop stays reachable during a transition

A user Stop gesture is not a session write. Busy Esc / extension
`cancel-activity` and the Task-Center selected-subagent Stop enter
`SessionOperationBarrier.runControl` (through `SessionRuntime.withControl` /
`interrupt`) instead of `runWriter`:

- a frozen navigation transition does NOT refuse the control section: the
  captured owner's turn can still be stopped while the transition is waiting
  for admitted writers to drain;
- the control section never increments the writer count, never waits for the
  transition, and never releases an ordinary writer; every ordinary writer
  keeps `withWriter` and is still refused while frozen;
- the control admission is scope-bound and NO-YIELD exactly like `withWriter`:
  the captured live scope is checked and the EXACT owner is captured in the
  same synchronous stack before the backend cancel. A stale capture rejects
  with `SessionScopeSupersededError`; the semantic `interrupt` maps that and an
  aborted runner to `cancelled` (a confirmed pre-dispatch outcome, never a
  generic `agent interrupt` ERROR). A same-id owner rollover can never address
  the newer generation;
- the backend cancel is the ONE-SHOT user interrupt of that exact owner
  (`SessionOwnerRetirement.cancel`), never the shutdown `preCancel`: Direct
  calls the captured `Agent.cancel(..., { keepInbox: true })`, Remote calls the
  exact borrowed `SessionFace.cancel()`; both return the shared `WriteOutcome`
  (`committed` / `rejected` / `indeterminate` / `cancelled`) and never retry an
  indeterminate result. Remote captures the official Connection generation
  before dispatch and re-checks it together with the exact binding after the
  reply; a reply from a superseded owner or connection generation is
  `indeterminate` (the call did dispatch, so it is never a definite
  success/refusal for the current generation);
- Task-Center subagent Stop uses the same admission, while the durable
  parent/child authority and the live activity/view fences still decide which
  child may be stopped. A legitimate Stop is therefore not refused merely
  because a navigation transition froze the ordinary writers.

The transition's commit ordering is unchanged: an admitted ordinary writer
still drains before the transition quiesces, flushes and commits, and the
control cancel cannot turn a pre-publication failure into a commit.

### Known-rejection settlement inside the held writer

The ordinary prompt's `WriteOutcome` settlement happens INSIDE the admitted
writer section: `SessionRuntime.withWriter` wraps
`withPromptAdmission → prepareMessage → isScopeCurrent → markDispatch → prompt
→ settlement`. A proven rejection (`kind: 'rejected'`, e.g. the official
`session/writer-held`) is a NORMAL terminal return from that body, not a throw:

```text
merge the submitted human text into the editor exactly once
settle the local submission echo
terminate this gesture's submit ack with the structural code
notify the refusal's own message (the centralized writer-held guidance)
return
```

Consequences that are part of the contract:

- A Session transition that arrives after the writer is admitted WAITS for the
  result AND the caller-side terminal settlement — the barrier is the
  currentness/lifecycle authority for that interval. There is therefore
  **intentionally no post-dispatch prompt currentness fence**; adding one would
  duplicate authority over a state the barrier contract excludes. The existing
  post-`prepareMessage()`/pre-dispatch fence is unchanged.
- Because the body returns normally, the reserved-submit wrapper performs no
  generic exception restore and `runOwned.onError` emits no generic
  "submission failed" wrapper. A `cancelled` outcome still throws the
  cancellation error, and an `unsupported` outcome still fails fast.
- A writer-held refusal is restored/never-auto-retried according to the proven
  pre-commit semantics: no lease takeover, no force-resume, no Direct fallback
  and no optimistic success. An indeterminate post-dispatch result keeps its
  existing settlement — the draft is NOT restored and nothing is retried.
- Remote surfaces obey the same rule at their own owner. The Remote preset
  adapter classifies only the EXACT `session/writer-held` (alongside its
  operation-specific preset refusals) as a proven rejection, keeps the official
  `details`, and uses the centralized guidance; a TRUE indeterminate typed
  `/preset <id>` records `suppressed` so the command is not restored as
  retry-ready intent. `/title` (whose official `rename` resolves the Agent
  before the title mutation) restores the typed command with the guidance and
  mutates no title.

### Write settlement

The current Direct writes are asynchronous at the semantic boundary without
changing the ownership or ordering rules:

- Ordinary input uses `SessionWriter.prompt(sessionId, message, mode)`;
  `queue` and `steer` are explicit. Direct Agent admission exceptions settle as
  the official `session/agent-busy` rejection (`prompt rejected` plus the
  exception reason); only a successful Direct call settles as `committed`.
- Ctrl+S remains one operation-barrier turn. A payload-bearing draft takes
  priority and is sent alone through `prompt(..., 'steer')`; it never sweeps
  the queue. With an empty draft, it reads the `PendingInputReader` snapshot,
  selects only `placement: 'queued'`, revalidates the agent identity and
  generation, then calls `updateQueue({ kind: 'steer' })` once per occurrence in
  FIFO order. An empty-draft gesture is gated on `PendingInputSnapshot.running`;
  an idle subject is left untouched. Queue races settle per occurrence rather
  than aborting the whole sweep; missing/unavailable occurrences stop it quietly
  without replay, and a genuine or indeterminate failure never claims
  atomicity or retries. Direct validates edit content before Agent lookup;
  successful removals retire user `rpcId` upload bindings. A failure after
  removal, including retirement failure, is `indeterminate`; cancellation
  before confirmed removal remains `cancelled`.
- Alt+Up is a TUI-only recall-all extension: it calls
  `updateQueue({ kind: 'remove' })` one occurrence at a time in FIFO order,
  then stages the removed content in the editor. It is not the official in-place
  `updateQueue({ kind: 'edit' })` operation, so the recalled draft is a new
  human submission if the user sends it. Already-`steering` and `context`
  placements are not recall targets. A known partial refusal restores only
  confirmed removals; an indeterminate removal keeps every recalled
  representation for manual review and is never retried.
  If a session transition queues while the writer is in flight, visible
  reconciliation waits for its outcome: a committed transition discards the
  staged references without injecting old content, while a failed transition
  restores the appropriate confirmed or indeterminate representation in the
  original editor.
- Host command execution uses `HostCommandPort` after the runner has already
  decided that the line belongs to the Host. Cancellation-shaped adapter throws
  settle `cancelled`; other execution throws settle `indeterminate`, so the
  runner never restores or automatically retries a command whose side effect
  status is unknown. A settled command result is committed separately from the
  TUI's fallback prompt path.
- Task Center child interruption uses `SubagentPort` with the durable direct
  parent and child identities. The semantic writer hides Direct cancellation
  knobs such as the user reason and inbox-preservation option.
- Continuable viewer prompts carry the runner-resolved `queue` or `steer`
  delivery from the child running state and `busyEnter` policy. The prompt
  port forwards that delivery with human provenance; it does not force every
  viewer prompt into a FIFO queue. An empty accelerated viewer submit is a
  child-scoped queue steer-all: it snapshots only the live child’s `queued`
  occurrences and never calls the child prompt API. If that no-payload sweep
  cannot settle, the original child draft (including whitespace-only input) is
  restored to the current editor or the stale child slot. Child queue occurrence
  reads and mutations require the exact interactive continuable viewer Agent,
  its live registry identity, and its pinned direct parent; ordinary child
  prompts retain `SubagentPort` parent authority. The queue pane reads that
  same active child subject while the viewer is mounted; an unavailable child
  clears the pane rather than falling back to the parent's queue.

Known-unwritten outcomes are never reported as committed. An indeterminate
future wire result is not retried automatically or restored as if the queued
occurrence were known-unwritten. A no-payload whitespace draft may still be
restored as editor input; that does not restore or replay the occurrence. Direct
normally returns confirmed `committed` or explicit
refusal outcomes; its exceptional non-occurrence failures continue through the
owned rejection path, while occurrence-level exceptions remain indeterminate
because removal may already have happened.

A single process-local submit FIFO covers ordinary prompts, explicit queue
prompts, Ctrl+S per-occurrence steer sweeps, and command execution including its fallback
prompt. Each gesture takes its turn before async preparation and releases it
only after the semantic command/write path settles, so delayed mention or
attachment preparation cannot let a later gesture overtake an earlier one.

### Model / preset / create-open ordering

- A live Session model selection is a Session WRITE: `/model` dispatches
  `ModelCatalog.selectSessionModel` INSIDE the writer barrier
  (`SessionRuntime.withWriter(scope, …)`), so a transition that started first
  refuses the write before dispatch and a transition that starts after waits for
  it. The picker
  itself enters an in-place `Selecting…` state (a duplicate apply is never a
  second commit) and the footer shows the in-flight choice as `(selecting…)`
  while keeping the authoritative current value. The
  outcome drives presentation: `committed` follows the authoritative Session
  projection, `rejected`/`cancelled` returns to the model list with the Host
  refusal, and `indeterminate` dismisses without retry and never claims the
  requested model. `/model` and `/preset` capture their semantic SUBJECT once —
  the Session generation PLUS the exact session identity (including `undefined`
  for a sessionless surface) — and re-fence it after EVERY await and before any
  UI mutation; a same-generation Session-identity drift is `superseded` exactly
  like a generation bump, so it is dropped (no repaint, no close/open decision,
  no notice). A dropped live Session write also makes no default-intent claim:
  the sessionless global-default tracker is never entered by a live Session
  write, so nothing leaks into a later fresh create.
- Preset selection stays inside the local transition gate as coordination
  only: the Host owns the serialized switch, the blank re-check, the recompose
  transaction and the durable commit. The command captures the subject once
  (the typed `/preset <id>` path binds the subject it started with, never
  whatever Session exists when an await returns) and revalidates it after every
  await — roster, resolve, the Host transition (before classifying the result)
  and the follow-up catalog refresh (a superseded refresh never repaints).
  Blankness for the picker comes from the official turn-boundary projection,
  never the TUI transcript. `agent-preset/locked` is the
  race-proof final authority and maps to the started-session wording; the TUI
  never mutates its display to a rejected choice.
- A sessionless `/model` choice is a global-default intent. The footer derives
  its sessionless marker from that single tracker: `(selecting…)` while the
  default write is in flight, an explicit `(unconfirmed)` once it settles
  `indeterminate`, and NOTHING once an authoritative Host read reconciles it
  (the persisted default either carries the choice — committed — or proves it
  did not land); a reconciliation that restores an older still-pending intent
  shows `(selecting…)` again. EVERY in-flight
  write (and its fenced correction) is tracked and a fresh create AWAITS their
  settle before dispatching, so the Direct adapter's Host-default activation
  cannot race an older value; the wait is abort-aware, so a hung Host save can
  never block first creation past shutdown. The fresh create consumes the
  SETTLED persisted Host default and
  never durable-seeds a Session choice: a committed save is observed
  dynamically, and a FAILED latest intent is walked back in the UI
  — the create uses the actual Host default, it does NOT seed the failed
  selection (a fabricated choice would freeze a default the user never
  durably set, and the sticky failure would leak into later creates). The
  global default is BEST-EFFORT Host state: a fencing correction
  that itself fails is warned and leaves the persisted default stale until the
  next save — it never becomes durable Session authority.
- Fresh create has NO blind retry: one Host dispatch, and a post-publication
  create error is never reported as "the Session was never created" — the
  requested/published identity is preserved for later reconciliation. `/new`
  keeps the old surface
  until the create commits.
- Remote open is a Client selection, not Host activation:
  `ClientSessions.open()/binding()`. It fails closed for an unaddressable
  Session and never invents a Host resume RPC.

### Generation/stale fences

- The ownership core (`src/app/session/ownership-core.ts`) keeps the ONE
  **monotonic session generation**, bumped on EVERY session swap (switch,
  `/new`, `/fork`, rewind, open) by the bound runtime. Late async work from the
  old session captures the generation it started under and refuses to commit
  state once a newer generation owns the surface. Session IDENTITY is the opaque
  `SessionOwnerRef` + generation (`SessionSubject`), never a session id alone;
  the Direct Agent object is reachable only through the Direct owner registry,
  and the transitional `currentDirectAttachment()` projection serves Direct
  DATA/OPERATION reads only — identity and currentness always come from the
  core.
- The submission re-validation checks the live owner SUBJECT (owner ref +
  generation) before mutating visible state.
- Rewind captures the source identity, generation and navigation epoch when the
  picker opens. Selection revalidates that full identity before dispatching the
  Host fork, so returning to the same Session id after newer navigation still
  rejects the stale picker row without creating a child.

## Session-owner retirement

The session layer drives retirement through the consumer-owned
`SessionOwnerRetirement` port (`src/app/session/owner-access.ts`): quiesce or
pre-cancel one owner, retire it in the official session-close order, park a
refused fork's owner for a later claim, and report the retirement outcome: when
a `durabilityFailure` exists the surface shows the SEMANTIC "the latest events
may not be persisted" warning; otherwise, if any failures remain, it summarizes
them for the user with the BACKEND-defined phase labels (diagnostic labels only
— never a cross-backend contract). The bound runtime owns WHEN to retire and
the control flow after an abort.

The backend adapter that implements the port on the in-process path is
`src/app/direct/owner-retirement.ts`; it owns the exactly-once shutdown cancel,
the abort listener and the fixed-phase execution
(`src/runtime/direct/owned-session-retirement.ts`). On the Direct backend the
TUI and the Host share one process and the TUI created the top-level Agent, so
the adapter's cancel/dispose really does release Agent-scoped work. That is
NOT a future Remote `session.close` RPC — a Remote client closes its client-side
observation/connection state through official DSH client contracts and never
destroys the Host Agent, which is exactly why the port fixes only the
observable contract (await quiescence and report which condition ended the
wait) and leaves HOW an abort is reflected onto the owner to the backend.

The retirement order is mode-dependent, because the two modes have different
durability owners:

```text
transition (the Host stays live):  cancel → idle → descendants → sessions.flush → dispose
shutdown / HMR / parked exit:       cancel → idle → descendants → AgentHandle.dispose
```

- `cancel` — `agent.cancel({ kind: 'user' })` stops new main-Agent work.
- `idle` — `agent.whenIdle()` awaits the main Agent's quiescence.
- `descendants` — `subagents.drainContinuableDescendants([agent])` closes
  continuable admission below the exact parent, stops visible descendant
  Activations, and releases their `AgentHandle`s child-first. This is the
  piece that previously let a continuable subagent keep the process alive
  for minutes after the TUI exited.
- `flush` (transition only) — the FINAL `sessions.flush` runs AFTER the
  descendant drain, so the durability boundary includes every descendant
  settlement. It is ISSUED while the live-Host regime holds, which is what
  makes it the transition's own durability barrier; it is not immune to a
  concurrent close that STARTS during the flush (see the overtake rule
  below), and a failure it records is never reclassified.
- `dispose` — `AgentHandle.dispose()` releases the persistence writer and
  stops Agent-scoped background jobs (the TUI never enumerates/kills jobs
  itself — DSH jobs lifecycle is bound to the Agent scope). In shutdown
  mode this disposal IS the durability settlement (no flush phase runs to
  compete with it): it joins DSH's own durable handle close/drain.

The shutdown mode deliberately runs NO explicit `sessions.flush`: during
root unload the DSH agent loop and the JSONL backend may already be closing
the same write handle (the backend's `session/disposed` listener and its
open-handle close sweep), and a flush issued after `closing` started is
rejected with `flush on a closed handle`. Re-issuing that flush would race
DSH's close authority instead of adding durability; a shutdown dispose
failure is therefore reported as durability UNCONFIRMED (never as a flush
failure, and never as proof that data was lost).

The transition mode is not a synonym for "the lifecycle is live"; it is a
claim that must still hold when the flush phase RUNS. A transition (or fork
adoption) retirement can enter while the lifecycle is live and then span its
own `idle`/`descendants` awaits across an exit — the shutdown does not wait
for an in-flight transition retirement, so the root teardown can start
closing that write handle mid-retirement. The retirement therefore re-reads
the authoritative lifecycle fact at flush time: once the lifecycle aborted,
the retirement does not START an explicit flush (the same fact the cancel
phase reads to choose the shutdown cancel). That decision is only about
starting the phase; it never decides how a failure of an
already-started flush is classified (the rule below fixes durability to
that flush).

A successful ordinary transition also checkpoints the COMMITTED child:
IMMEDIATELY after the synchronous commit, BEFORE the OLD owner's retirement
(whose descendant drain is unbounded), before the abort-aware child quiesce
and before any surface work, ONE `retirement.flush(nextOwner)` materializes
the new session's durable boundary (an empty `/new` session has no events,
so only an explicit flush makes it resumable). That position is part of the
contract, not an implementation detail: a shutdown closes the handle
concurrently with the transaction, and DSH's close drains what was appended
but does NOT materialize a never-appended session — a checkpoint parked
behind the quiesce await can therefore be stranded by the very exit it must
survive. The checkpoint uses the commit-time owner only — never a re-read —
and a failure never rolls the child back or misreports the switch: the
surface warns "session committed, durability checkpoint failed" with the
original error. Both the diagnostic and that single notice are emitted AT
the failure itself, before the next unbounded await, because the OLD owner's
retirement and the child quiesce can outlive the process's shutdown budget; a
later summary re-logs the failure as part of the transaction but never
re-reports it as a second durability failure.

A flush can also be OVERTAKEN while it is in flight: DSH re-checks the
handle's closing state inside the flush's own turn, so a `close()` that
starts after the flush was issued refuses it. Two rules bound what pi-tui
may conclude from that:

- An explicit flush is not ISSUED once the lifecycle has aborted (the exit
  owns durability then). This is a decision before the call, never a
  re-reading of its failure: refusing to START a shutdown flush and hiding a
  failure of one already started are different rules and never merge.
- Once a flush HAS been issued, a rejection is always recorded and
  reported. The lifecycle flag is not evidence about the cause:
  `sessions.flush` awaits every `session/flush` listener, so the failure can
  be a real persistence I/O error rather than a close takeover, and an
  aborted lifecycle does not distinguish them. A recorded flush failure
  therefore always owns durability for the report — a later successful
  close proves only the close's own drain, never that every listener
  succeeded. Only when no flush failure happened does the shutdown dispose
  decide (durability unconfirmed). The failing phase stays in the report and
  reaches the user (or the diagnostics when the surface is gone), including
  on the aborted post-commit early return. No error is reclassified by error
  text or by the lifecycle flag.

A never-materialized session is the exception the checkpoint placement above
exists for: the close cannot be its durability owner, which is why the
checkpoint is never suppressed. DSH `AgentHandle.dispose` remains the sole
final close/drain authority; the pi-tui flush only establishes the
recoverable boundary while the Host is live. Root shutdown never waits for
a full retirement before `appExit`.

Every phase is individually contained: a failure is recorded and the next
phase still runs, so one failure can never re-create a handle leak (a
skipped dispose would pin the old session lease).

Where it runs:

- **Interactive exit** (`/exit`, Ctrl+C/D, plain `exit`): the exit
  controller latches, disposes the Client surface, then runs ONE synchronous
  Direct-retirement preparation hook, then prints the resume hint and
  requests `appExit`:

  ```text
  latch
  → dispose/restore the Client surface
  → synchronously cancel the exact CURRENT Direct owner
  → resume hint
  → appExit
  → application-tree disposer joins the SAME memoized retirement:
       idle → descendants → dispose (shutdown mode: DSH close owns durability)
  ```

  Only the FIRST cancel comes forward. It is needed because the ordinary
  exit reaches the appExit disposal through `transitionGate.run(...)`, whose
  task is scheduled on a promise continuation: the root teardown could
  unregister the inbox projection before the retirement's async `cancel`
  phase ran (`phase=cancel ... its projection registration is not active`).
  The TUI still never awaits `whenIdle` / drain / flush / dispose in front of
  `appExit` — that full retirement stays inside the application-tree disposal
  under the DSH process-shutdown watchdog.

  The pre-cancel is deduplicated by **exact Agent object identity**, not by a
  boolean or a session id: a session transition that commits during the exit
  replaces the current owner, and the NEW owner must still be cancelled by the
  retirement's cancel phase. A pre-cancel that THROWS is not recorded as done,
  so the retirement retries it. This is Direct-only shutdown preparation; it
  is not the Remote `session.close`, and parked owners are retired by the
  disposal's own loop rather than by the interactive call stack.

  Every shutdown-aware cancel shares that one identity set, because more than
  one owner can be cancelled in a single exit: the current owner is
  pre-cancelled before `appExit`, and a session transition or fork that commits
  AFTERWARDS still retires the owner it replaced. Those transition/fork cancel
  phases join the same set while the lifecycle signal is aborted (outside
  shutdown they keep the ordinary cancel semantics), which is what keeps a late
  non-cooperative child create from producing a second cancel after the root
  teardown unregistered the inbox projection. The `whenIdleOrAbort`
  lifecycle-abort listener contains a throwing cancel and rejects its quiesce
  instead: an `AbortSignal` is a Node EventTarget, so a listener exception
  would otherwise become an `uncaughtException` that the caller's `try`/`catch`
  cannot observe, and the memoized retirement would never get to retry. The
  listener rejects the RAW thrown value — any formatting step (`String(value)`,
  an unprotected `instanceof`, a `.message` read) can itself throw for a
  hostile value, which would escape the listener the same way; observation
  downstream goes through the repo's total error formatters.
- **HMR / runner fiber unload**: the fiber disposer is async (Cordis
  unloads await it) and runs the SAME memoized retirement — one teardown
  promise shared by every teardown path, never four copies. That entry has no
  exit-controller hook, so `retireOwnedSession` performs the same synchronous
  pre-cancel itself before creating the memoized promise.
- **Client detach vs explicit Stop**: a Client surface teardown, Client
  process exit or connection loss releases only the Client-owned surface,
  official transport and Client root. It does not invoke the Direct/runtime
  Session retirement cancel: that cancel remains the explicit Stop/navigation
  authority. A Host-owned pending Question/Approval forward must stay pending in
  the Host Gateway across the detach, and a later Client must answer the same
  event/call identity at most once. A split Client composition must install its
  interaction owner before the official Gateway event pump can consume the
  pending forwarded event; a surface teardown must not settle that Host event,
  and a permanent pending promise or private pending store is not a substitute
  for the official Loader readiness ordering.
- **Same-process Client surface revision**: when the internal split Client
  replaces its surface, ONE serial revision task slot owns the transition:
  close the old revision's input/admission, await the old runner's physical
  tty release and Session-reference retirement, dispose its UI and memoized
  application adapters in reverse, mount the new revision on the same Client
  Context/transport, and await its real `surfaceReady`. The root Domain plane,
  root interaction delivery owner and B1 transport stay alive across the
  revision; the same Host Question/Approval invocation is handed to the new
  surface at most once. A stop request aborts the in-flight revision and waits
  for that slot before releasing the Client root; a failed revision disposes
  its partial graph and exits the Client. The Host identity and Host business
  objects never change.
- **Successful ordinary session transition** (`/new`, `/sessions` switch,
  or open): a USER NAVIGATION first sends its one exact-owner stop at the
  transition admission (before the drain), then the pre-commit quiesce
  (whenIdle + flush) waits for that Turn to end; AFTER the commit the old owner
  is retired with the same fixed order, so the old Agent's continuable
  descendants are drained and its final flush lands after the drain. A failed
  child create never drains or disposes the old owner — the old session stays
  current and, when the navigation stop was accepted, the failure says the old
  Turn is already stopped (the transaction semantics are unchanged).
- **Fork/rewind adoption:** Host publication is not rolled back on navigation
  supersession. Current Direct adoption retires the old owner after the gated
  visible handoff; a successful unselected child remains parked for a later
  owner claim, and runner teardown retires all remaining parked owners.

The process-local transition gate / operation barrier coordinate only the
TUI's Client writers; they do not take over Host ownership. The retirement
serializes against an in-flight transition through the same gate + barrier
(a FIFO no-op task waits for a running transition to settle — the lifecycle
abort already cancelled its create/open), then retires the CURRENT owner.

### Runner lifecycle contract: surface → retirement → transport

Every runner teardown path shares ONE frozen top-level order:

```text
normal unload / HMR:
  surface total cleanup attempt
  → Session retirement settlement
  → selected transport disposal

mounted fatal:
  same surface cleanup authority
  → bounded Session retirement
  → transport only if retirement settled
  → exit(1)
```

Surface cleanup is **non-truncating**: every independent surface-owned
resource is attempted in its original order even when a sibling throws
(`src/runtime/process/disposal.ts::runSyncDisposalSteps` runs every step, then rethrows the
single failure by identity or an `AggregateError`). The same primitive
hardens each owner's own `dispose()` chain (viewer, command catalog, footer
settings, Plugin Manager, Question, OverlayBroker, `TuiApp.stop/dispose`,
`SurfaceRuntime.dispose`, and the bootstrap `disposeSurface`). A cleanup
error is recorded (or surfaced) but never reorders or replaces the Session
retirement / selected-transport disposal: the surface failure is secondary,
the retirement outcome stays the returned HMR result.

`TuiApp.dispose()` remains **fail-closed** on the process live-TUI slot: the
non-truncating batch runs to the end, but the process slot is released only
when the WHOLE batch returned successfully — a final-dispose error keeps the
slot claimed (a half-torn-down surface is never publicly replaceable).

The mounted-fatal catch (`handleStartupFailure`) reaches the SAME
`disposeSurface` authority through a runner-scope ref, so a fatal after the
TUI mount runs the identical surface cleanup before the bounded retirement;
only a fatal before the surface owner exists keeps its own minimal
focus/abort safety. Cleanup errors never replace the original fatal message
and never prevent `exit(1)`.

## The submit path is guard-free (the decision)

A per-submit cross-process consistency check (stat + a full committed read
comparing the file against memory) USED to run before every Enter/Ctrl+S
send. It was removed: its cost grew with the session history
(`readFrom(id, 0)` parses the whole artifact), long submissions sat for
seconds on a silent no-feedback UI, and its one-time force-through token
invited exactly the double-write it existed to prevent. With the old guard
gone, the single-writer boundary is the DSH `SessionWriteLease`, and the
submit hot path performs ZERO persistence work (a runner-level test pins
this: `test/app/submit-hot-path.test.ts`). The web surface and other
pre-baseline TUIs are out of scope by design — they are not part of this
project's ownership model.

## Counting events in a session file (trap)

File rows are the **storage format**, not events. Packed `*-chunks` rows
(`seq0` + `dt`) expand via `decodeStorageRecord` into individual events with
real `seq` values. Any code that counts "events in the file" must expand
rows through the persistence read path (`readFrom`), which expands them;
naive line-counting does not.

## One live TUI per process

The vendored keybindings are a process-global singleton. `TuiApp.start()`
claims the process slot on the first successful start; `stop()` never releases
it; `dispose()` releases it LAST and only after a fully successful
non-truncating teardown. A second concurrently live `TuiApp` rejects
deterministically, and exclusivity is fail-closed: a failed final teardown keeps
the slot claimed, because a half-torn-down surface is never publicly
replaceable. External-editor suspend/resume, stop/start and screen swaps keep
the claim; a constructed app never touches the global keybindings.

Authority: `src/tui/process-slot.ts` (`claimProcessTuiSlot`,
`releaseProcessTuiSlot`) + `TuiApp.start/stop/dispose`.
Proof: `test/tui/process-tui-slot.test.ts`.
