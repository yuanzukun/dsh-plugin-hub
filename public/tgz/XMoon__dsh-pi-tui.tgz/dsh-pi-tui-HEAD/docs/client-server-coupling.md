# Server/client migration — coupling inventory

> Part of milestone M0 (see `docs/client-server-migration.md` for phase
> status). This file is the **coupling allowlist** referenced by the
> AGENTS.md "Server/client migration guardrails (hard rules)": existing
> Host coupling may stay here until its owning phase moves it; new coupling
> is rejected by `scripts/client-boundary-gate.mjs` (baseline allowlist +
> no-new-debt).

## How the allowlist works

- `scripts/client-boundary-gate.mjs` scans `src/` for Host-coupling patterns
  (the `ctx.get('service')` / `ctx.<service>` forms and
  `@deepseek-ai/dsh-agent` / `@deepseek-ai/dsh-session` type imports) and
  compares against the frozen baseline
  `scripts/client-boundary-baseline.json`.
- The baseline is the **current** inventory below, at (file, pattern)
  granularity — a new pattern in an already-allowlisted file is still new
  debt and fails the gate.
- Updating the baseline is a deliberate maintainer action, only when a
  migration phase legitimately relocates coupling into a semantic port
  (e.g. M1 moves `subagents` out of the runner). Never update it to absorb
  new feature debt — that is exactly what the gate exists to stop.
- The gate deliberately does NOT flag: the TUI's own services
  (`TUI_STARTUP_SERVICE`, `PI_TUI_EXTENSIONS_SERVICE`), Cordis process
  services with no Host business state (`loader`, `appExit`), and
  `src/startup.ts` (the zero-dependency compatibility island — see
  `docs/client-server-migration.md` §Startup).
- The gate also covers `goal`, `planMode` and `sandboxPolicy` (dsh Host
  services with **zero baseline entries today** — no current `src/` usage).
  Any future feature that reads them is new Host coupling and must route
  through the runner/allowlist, never a UI module. The M0 status semantics
  layer is the sanctioned seam: `src/domain/status/derive-*.ts` read the official
  services through STRUCTURAL interfaces (generic over the event type, so
  the derives carry no Host type imports), and the runner (`src/index.ts`)
  wires the real services in — the two new `index.ts` baseline entries
  (`planMode`, `sandboxPolicy`) are exactly that wiring, not UI debt.
- The **application-layer dependency direction** between the `src/app/**`
  owners, the frozen `src/runtime/**` semantic layer, and presentation modules
  is enforced separately by `scripts/application-architecture-gate.mjs`
  (`pnpm gate:architecture`, see the application architecture dependency
  direction status in `docs/client-server-migration.md`). This file stays the
  Host-coupling authority only; the two gates answer different questions.

## Composition ownership and wire-shape inventory

`scripts/client-boundary-gate.mjs` remains the mechanical
no-new-business-coupling gate; it does not infer Cordis composition semantics it
cannot see. The legacy `File | Coupling | Notes` allowlist below is grandfathered
and remains the mechanical coupling inventory; this section is the
composition-semantics inventory.

Every NEW or materially changed composition-sensitive domain from M3-4 onward
must have an ownership row here that records locality, composition owner,
allowed consumer, wire source, reuse-vs-additive mount and evidence owner; the
canonical M3-3B rows below already use that shape.

`Evidence owner` is the test/smoke lane or the document that carries the proof.
This inventory is the composition-ownership authority; the M3-0 architecture
statements it was derived from were retired by M3-6 PR4 (Git history keeps the
last version); qualification evidence lives in `docs/client-server-migration.md`.

### Composition-owner classes

```text
BASE_HOST_PREREQUISITE   ordinary DSH/base/profile composition owns it;
                         migration code may require/read/adapt/verify identity
                         but MUST NOT mount a second copy merely to satisfy
                         Remote composition
MIGRATION_ADDITIVE_HOST  a Host contribution genuinely added by the migration
                         composition contract; it may mount only the frozen
                         additive rows (see `docs/client-server-migration.md`)
GENERATED_CLIENT_REMOTE  official Client-side generated Remote/service
                         contribution; the TUI consumes it and does not
                         reconstruct its namespace object
CLIENT_LOCAL             terminal/editor/clipboard/draft/overlay/keybinding/
                         shell gesture+card/UI extension state; no Host
                         semantic coupling is invented for it
HOST_OWNED               Host execution environment, process lifetime and
                         Host-side policies (incl. user-shell execution —
                         the M3-4 PR3 shell amendment)
SPLIT                    one capability split across the Client gesture/
                         presentation and the Host execution authority
                         (incl. the user-shell request/stream bridge and
                         the `!` result handoff into Session)
```

### Core vs optional-feature Remote composition (2026-10-03 clarification)

The classes above describe the current M3 core graph; they do not turn the
current composition owners into universal registries. Generated Remote
availability is not sufficient evidence for `MIGRATION_ADDITIVE_HOST` ownership, and it
does not imply `RemoteHostRuntime` must own the Host plugin.

```text
CORE GENERATED REMOTE
  mounted/disposed by RemoteClientRuntime (the
  current M3 core generated contribution closure)

OPTIONAL FEATURE GENERATED REMOTE
  may be mounted/disposed by that feature's Client owner when the feature is
  adopted and the selected released DSH target actually provides the public
  contract; it reuses the existing Connection/Gateway and duplicates no core
  namespace/authority

HOST FEATURE WITH REMOTE
  remains feature-owned on Host unless an accepted contract explicitly
  reclassifies it as base/common/core
```

No current row of this inventory is added, moved or reclassified by this
clarification; update the rows only when a real coupling/composition change
lands.

### Canonical M3-3B ownership rows

| Domain/service | Locality | Class | Composition owner | Consumer | Wire/source | Mount rule | Evidence owner |
|---|---|---|---|---|---|---|---|
| `userQuestions` Host service | Host-owned | `BASE_HOST_PREREQUISITE` | `@deepseek-ai/dsh-base` (row `user-questions`) | `InteractionPort` (Direct + Remote) | forwarded `user-questions/request` waterfall + Host service | reuse; never mount a second `UserQuestionService` in `RemoteHostRuntime` | `test/remote-m3a-semantics-smoke.test.ts` |
| `userQuestions` Client Remote | Client-local consumption of a Host authority | `GENERATED_CLIENT_REMOTE` | official client contribution (`@deepseek-ai/dsh-user-questions/remote`) | `QuestionInteractionPort` + the `userQuestions` Session projection | generated `/remote` namespace | additive Client contribution; preserve the generated object identity | `test/remote-m3a-semantics-smoke.test.ts` |
| `configEditor` | Host-owned | `BASE_HOST_PREREQUISITE` | profile/base composition (`profileContext` config plane) | `ConfigPort` settings mirror | Host settings/config plane | reuse; `RemoteHostRuntime` must not mount it | M3-3B same-Host smoke (fixture-mounted only per `docs/client-server-migration.md`) |
| `settings` | Host-owned | `BASE_HOST_PREREQUISITE` | profile/base composition | Remote Config adapter | generated `settings` Remote | reuse; no second settings authority or namespace | `test/remote-config-port.test.ts` + same-Host smoke |
| `workingDirectory` Host service | Host-owned | `BASE_HOST_PREREQUISITE` | `@deepseek-ai/dsh-base` (row `working-directory`) | Direct status/catalog/file/command/child-view adapters (`sessionStatus().cwd`, `@`/skill scopes, command routing, child viewer) | the same-session `workingDirectory` Session projection; the header stays the immutable ORIGINAL project | reuse; the TUI never caches a second cwd, never substitutes the process cwd, and a Remote consumer never reads a Host cwd for Client-local shell/OSC 7 | `test/direct-working-directory-rc2.test.ts` + `test/runner-direct-working-directory.test.ts` |
| `web` / `web-deepseek-api` settings sections | Host-owned | `BASE_HOST_PREREQUISITE` | `@deepseek-ai/dsh-base` (rows `web`, `web-deepseek-api`; providers and `dsh-web` selection at call time) | Direct `ConfigPort.web` (`DirectWebProviderConfig`) → `/settings` Web section; `ctx.web.search/fetch` + `tool-web` at call time | the official revision-checked `settings.describe/mutate` plane; the live provider selection is `ctx.web`'s own volatile state | reuse; never a second YAML/store, never a plugin enabled flag as the selection, and the Remote adapter is a static unavailable/refuse implementation (no Host namespace on the wire) | `test/web-provider-config-direct.test.ts` + `test/web-provider-rc2-integration.test.ts` + `test/settings-web-provider.test.ts` |
| `jobController` | Host-owned | `BASE_HOST_PREREQUISITE` | the existing TUI row | `JobObservationPort` | `IJobs` + generated `job` Remote | reuse; no second job observation authority | `test/remote-job-observation.test.ts` + the Job roster in `test/remote-client-runtime.test.ts` |
| M3 Host API/session helper rows | Host-owned | `MIGRATION_ADDITIVE_HOST` | `RemoteHostRuntime` | the M3 adapters | official Host plugins + generated Remotes | additive; mount only the frozen additive closure | `test/remote-client-runtime.test.ts` |
| TUI Task Center / Question presentation | Client-local | `CLIENT_LOCAL` | TUI application surface | user-facing surfaces | semantic ports/projections only | never becomes Host authority; the Remote Task composition resolves no Host `ctx.jobs`/`ctx.subagents` (Direct-only gate, M3-5 PR6) | `test/runner-viewer-task-integration.test.ts` + `test/runner-remote-task-center.test.ts` + the Remote Task locality source lock in `test/application-runtime-selection.test.ts` |
| Application runtime selection (`SelectedApplicationRuntime`) | Client-local composition | composition spine (M3-4 PR1) | `src/app/remote/application-runtime.ts` (Remote aggregate) + `selectApplicationRuntime` in `src/app/bootstrap/runtime-selection.ts` (the seam) | `bindSessionRuntime` common inputs (`owners`/`retirement`/`lifecycle`) and the runner's `backend` | Remote aggregate reuses the M3-1 wire + M3-3B backend + M3-2 owner services; reached ONLY through `runtime/backend-loader.ts` (the ONE frozen dynamic edge into `app/remote/runtime.ts`, which statically re-exports the aggregate) | exactly ONE Remote Host/Client graph, ONE semantic assembly, ONE owner registry per selected runtime; no second construction site; no public/config/env selector — normal `apply()` stays Direct | `test/remote-application-runtime.test.ts` + `test/application-runtime-selection.test.ts` + the dynamic-boundary rules in `test/application-architecture-gate.test.mjs` |
| PiTui Client UI subtree (`RemoteClientUiRuntime`) | CLIENT_LOCAL | `CLIENT_LOCAL` | `src/app/remote/client-ui-runtime.ts`, composed by the Remote application runtime (M3-6 PR1) on the EXISTING official Client Context (`wire.client.context` — `client-runtime.ts` stays the official transport/data core and creates that Context exactly once) | SurfaceRuntime / extension-facing TUI owners (through `RemoteApplicationOverride.extensionService` — the narrow service object; it does not expose the Client Context or plugin fibers, only the selected PiTuiExtensionService capability crosses the in-process composition seam) | none for extension callbacks (TUI-local `src/extensions.ts`/`src/builtins.ts` plugin fibers); plugins may separately consume public Client/Remote facts | one subtree per Remote application aggregate: exactly three fibers (Client-local tuiStartup facts provider → extension host → builtins), no second Client Context, no generic Loader/profile/bundle discovery | `test/remote-client-ui-runtime.test.ts` (component) + `test/remote-application-runtime.test.ts` (aggregate) + `test/runner-remote-command-plane.test.ts` (L6 locality) |
| Host performance projection (`piTuiPerformance`) | Host-owned | `HOST_OWNED` (bundle row; NOT a base prerequisite) | `@xmoon76/dsh-pi-tui/performance-host` (`src/app/host/performance-host.ts`): the Direct profile row `pi-tui-performance-host` in `cordis.patch.yml`, and the experimental `RemoteHostRuntime` mount right after the official `sessionStats` unit | Client carriers: the Session's `SessionStatusProjection.performance` → `derivePerformance` → `UsageStatus.performance`, consumed by `/status` and the Footer (PR-3's `full` / `speed` / `speed-all` / `speed-both` / `latency` formats) | the bundle's OWN `sessionProjections.register('piTuiPerformance')` unit (see "Permanent Host-plane plugin boundary" below for the sanctioned reflect read); snapshot / change feed / control-frame projection and checkpoint replay stay the official seam's (no new RPC, no Client-side sample ring) | exactly ONE registration per Host Context — the Direct row registers on the base Host Context, `RemoteHostRuntime` on its own; the TUI runner injects `piTuiPerformanceReady`, so a composition without the row fails loud instead of estimating | `test/performance-host-projection.test.ts` (fold, route epoch, checkpoint/restore replay, registration lifetime), `test/performance-host-remote-wire.test.ts` (real Host→Client projection face), `test/footer-items.test.ts` + `test/footer-density.test.ts` (the five styles and their compact forms) and the L6 `test/runner-remote-presentation.test.ts` (Host → Client → rendered Footer) + the shipped-row lock |

The exact package/row names may evolve; the ownership rule must remain explicit.

### TUI extension/builtins module ownership (M3-6 PR1)

`src/extensions.ts` and `src/builtins.ts` are the SAME TUI-local modules on
both compositions — they carry no Host business coupling and no backend
branching:

```text
Direct  -> mounted by the ordinary profile Context (cordis.patch.yml rows
           pi-tui-extension-host / pi-tui-builtins)
Remote  -> mounted as Client plugin fibers by RemoteClientUiRuntime on the
           official Client application Context
```

The Remote branch's disposal is explicit and reverse (builtins → extension
host → startup facts) and runs before the official Client core
(`clientUi.dispose()` is the FIRST step of the aggregate's transport
disposal). The Remote bootstrap never resolves the Host-context
`piTuiExtensions` as its UI authority (branch-exclusive selection locked in
`test/application-runtime-selection.test.ts`).

### Duplicate-mount prohibition

Before mounting any Host service/plugin row in M3+:

```text
1. determine whether base/profile already owns it
2. determine whether mounting replaces a Cordis namespace owner
3. determine whether projection units/event handlers would be registered twice
4. freeze the owner in this inventory
5. record the coupling/owner row here
```

A missing service in a fixture is not evidence that production
`RemoteHostRuntime` should own it — fix the fixture to reproduce the production
prerequisite instead.

### One runtime graph / one semantic assembly

A product runtime or L5 qualification should have ONE Host graph → ONE
Connection/Client graph → ONE semantic assembly → ONE Backend assembly. Do not
create semantics manually AND call `createRemoteBackendRuntime()` (which creates
another semantics bundle) and then treat that as evidence of one production
wiring. Extra semantic bundles are allowed only in a test explicitly about
multiple independent consumers, never implicitly in the main qualification
fixture.

### Generated Client / Remote identity invariant

Official generated Client namespace properties may be prototype accessors.
Therefore:

```ts
const bad = { ...source.remote }
```

is forbidden for semantic adapter wiring: an own-property spread copies
bookkeeping fields only, so the generated prototype namespaces disappear and
`settings` / `credentials` / `llm` / `presets` / `commands` become `undefined`.
Preserve the source object's identity and pass the original generated object
through. A structural fake used by L3 tests should model important accessor
behavior when the adapter depends on the generated object shape, but L5 real-wire
qualification remains mandatory.

### Receiver/method-binding invariant

Forwarded event methods may read receiver-owned state. Forbidden:

```ts
const on = source.remote.$on
on(...)
```

Required:

```ts
const on = source.remote.$on.bind(source.remote)
```

or an equivalent call that preserves the receiver. This applies to any generated
Client method whose contract is receiver-sensitive, not only `$on`.

### Carrier Peer, `./client` conditions and the working-directory prerequisite (0.2.1-rc.2 baseline)

The 0.2.1-rc.2 re-qualification of the experimental M3 composition keeps the
frozen ownership rows above and adds four facts the implementation must not
reinterpret:

- **One owner Peer, two paths.** `createInProcessCarrier()` passes
  `hostContext.connection.browserPeer` — the Peer the `HostConnectionService`
  constructor creates with `principal: { kind: 'owner' }` and disposes with the
  Connection plugin fiber — to BOTH `shared.fetch(request, peer)` and
  `gateway.wireStream.open(endpoint, payload, uplink, peer, signal)`. The carrier
  never creates, caches, or disposes a Peer; the peer's lifetime stays the
  Connection fiber's, so a retired Connection really does refuse later work.
- **`interactions: 'answer'` is declared, not inherited.** The official
  Connection default is `answer` only for a page carrier (one with a location)
  and `none` otherwise, and `none` refuses forwarded events outright. This
  in-process Client is the TUI's only answering surface, so
  `installConnection(..., { interactions: 'answer' })` states it explicitly.
- **`./client` entries are condition-selected.** The official packages publish a
  standalone Node ESM half (`node`) and a `__ModuleLoader__`-registering browser
  factory (`browser`/`default`). The in-process Client composes the Node half
  where the package publishes one and the registering browser factory otherwise,
  through ONE module table, so a registering factory can still resolve a
  Node-half dependency (`src/app/remote/client-runtime.ts`).
- **The real `workingDirectory` owner is a base prerequisite.** 0.2.1-rc.2's
  `SubagentRuntime`, the SessionController's nested skill catalog and
  `@deepseek-ai/dsh-file-reference-local` all inject it; without that row the
  affected Remotes silently never register (which surfaces as a bare 404).
  Production inherits the `dsh-base` row; the Host runtime asserts it, and every
  independent Host fixture must mount the official owner rather than fake it.

- **Remote lifecycle gaps (S3 PR-C status).** These behaviours are reachable
  with the 0.2.1-rc.2 composition. The M3 Remote parity stage owned them; PR-C
  resolves the ones below and leaves the rest recorded, never papered over:
  1. **Admission is not the durable append — RULED_BY_S3.** The official
     `session/prompt` Remote answers when the Host Agent ACCEPTED the message
     (`agent.followup`/`steer`); the HOST then owns the durable append and the
     runtime-context message it composes with the first accepted prompt.
     `RemoteSessionOwnerServices.flush()` stays a documented no-op — there is no
     public Remote durable-flush verb — so an accepted write may become durable
     AFTER the Client transport is disposed. S3's fixed verdict is that this
     receipt IS the product contract: `WriteOutcome.committed` means Host
     admission, never fsync/flush, and no client-side sleep/poll/retry may
     fabricate a durability barrier. Teardown guarantees the SURFACE boundary,
     pinned in `test/runner-remote-races.test.ts` (surface stops, a writer parked
     at teardown settles between the stop and the disposal, the selected
     transport disposes exactly once, no terminal write after the stop), AND it
     refuses a write still parked BEFORE dispatch when the surface stops: the
     composition-owned dispatch admission is closed synchronously at the
     surface-stop boundary, so the official echo is abandoned and the Host sees
     nothing (plan §9 "prompt serializer parked then shutdown"). A write that
     already dispatched keeps its accepted receipt and is never reinterpreted.
     The OWNER-APPROVED terminal contract (plan §9 amendment, 2026-10-19) makes
     the draft half explicit: a refusal on the still-LIVE surface restores the
     draft once, but once the surface has stopped there is no post-shutdown UI
     write-back and restore into the destroyed editor is deliberately not
     guaranteed; the submission's disposed guard is the authority and must not
     be weakened to manufacture a callback after the stop.
  2. **Session creation entry — RESOLVED_BY_S3_PR_C.** `RemoteSessionLifecycle`
     no longer keeps the raw generated `session.create` + `sessions.refresh()`
     path and its `RemoteLifecycleSessionRemotes` seam: ordinary and
     explicit-preset creates share the ONE official
     `ClientSessions.create({sessionId, cwd, agentPreset})` entry and adopt the
     returned identity.
  3. **Fork migration — RESOLVED_BY_S3_PR_C.** `fork()` always passes
     `allowMigration:false` and classifies the official
     `session/migration-required` refusal as a proven rejection. The explicit
     user open/resume still uses the official `retain → Session.open` path where
     the Host may migrate; the read-only Browser state never acts as a
     migration veto or authority.
  4. **Explicit open failure — RESOLVED_BY_S3_PR_C.** An explicit Remote
     open/resume awaits the retained generation's initial-history settlement
     (`SessionReference.ready`) and then reads the OFFICIAL `openState`/
     `openError`; `ready` resolves even when `Session.doOpen` recorded an error,
     so `retain()` success alone is never treated as a successful open. The commit
     boundary requires the TERMINAL `openState === 'open'`: `error`, `cold`,
     `loading` and an absent state all release the failed generation exactly once
     and return `unavailable`. The non-error half is not theoretical — the
     official `Session.configureSubagent()` address replacement calls
     `Session.resync()`, which invalidates the old open, sets the SAME binding to
     `cold` and reopens it (`loading`); the old `reference.ready` can resolve
     first, and a stale completion must never commit history the reference no
     longer proves. `/resume`, `--session` startup recovery and post-fork
     adoption all keep the OLD subject/draft and never report a committed switch.
     Proven on the real Host/Client graph by
     `test/remote-session-migration-rc2.test.ts`, plus the resync/cold/loading/
     absent-state matrix in `test/remote-session-lifecycle.test.ts`.
  5. **Reconnect transcript currentness — RESOLVED_BY_S3_R0.** The Remote
     ingress no longer treats the latest `change` as a fold input: delivery is a
     SEQUENCE contract over the official identity (Connection generation +
     exact retained binding + eventSource revision). Any generation rollover,
     same-generation revision discontinuity, window `replace`/`prepend`, missing
     change or hydrate gap puts the ONE ingress handle into `recovering`, which
     suppresses partial increments and asks the fold OWNER to reconcile the
     CURRENT official window; delivery resumes only after the owner acknowledges
     the exact committed `{generation, binding, revision}` (the window must
     still BE that revision and the Session must be open). The main fold owner
     is `src/app/surface/session-presentation.ts` (`rehydrateFromWindow`, now
     revision-fenced before it replaces the fold), the child owner is
     `src/app/surface/viewer-runtime.ts` (`rehydrateViewedChild`); the bootstrap
     runs ONE single-flight re-fold per surface and never disposes or
     re-creates the ingress for a window reconcile (the previous
     `onWindowReplaced → initRemoteLiveSurface` path released the only live
     ingress before its ownership-fenced hydrate could abort — the
     dispose-before-rearm hazard that left the transcript on the dead window).
     A same-id BINDING replacement still retires the handle, and the owner's
     existing commit/acquire path installs the next one. Installing that
     ingress also CLOSES the opening journal for the session
     (`OpeningJournal.close`): the journal's pre-commit buffering exists for the
     hydrate gap, and keeping it open past the live subscription recorded events
     that `clearOpening` then DISCARDED — a real lost-event window a reconnect's
     fresh generation could land in. Direct keeps the journal semantics it has;
     only the Remote live-surface install ends the window early. Direct behaviour
     still shares no state with this path.
  6. **Post-reconnect catalog re-read — test readiness, not a defect.**
     `test/runner-remote-command-plane.test.ts` "L6 §7.4-14 stale catalog"
     holds a verified stale catalog snapshot, replaces the official Connection
     (`connection.reconnect()`) and disposes the old claim, then requires the
     NEW generation to re-read the Host catalog on its own and route a mounted
     command to the real Host handler exactly once. It used to time out under
     full-suite concurrency because the test treated the automatic refresh's
     authoritative READ as readiness, while the coordinator installs it an
     instant later: the single submit was classified against the previous
     claims and the same-named Client-context twin claimed the line (the
     `catalog applied … source=invalidation` report followed the submit). The
     test now waits for the product's own apply report before submitting, and
     the end-to-end path (generation subscription → refresh → install →
     classification → real Host handler) is green.
     **NEEDS-DECISION (Owner handoff, not a fix):** the read→apply window
     itself is unchanged PRODUCT BEHAVIOUR — a submission classified inside it
     is routed against the previous claims (and a same-named Client-context
     definition can claim the line). Whether the command plane must serialize a
     submission behind an in-flight catalog install, or whether the last-good
     claim rule already covers it, belongs to the command-plane stage (PR4/S4);
     this PR only re-witnesses the test's readiness and records the window. The
     handoff needs the Owner's explicit acceptance before it counts as
     dispositioned.

Evidence: the `PEER` block in `test/remote-client-runtime.test.ts` (owner identity
observed inside the real Gateway on the stream path, the same object on the Fetch
path, a no-policy guest refused with `remote-access/denied`, a disposed Peer
refused with `gateway/peer-disposed`, and the owner Peer aborted with the
Connection fiber).

### L5 fixture topology

Every NEW or materially modified test described as real-wire / real-Host from
M3-4 onward must list, next to the fixture:

```text
reproduced production prerequisites
stand-ins
deliberately absent services
```

Existing pre-governance fixtures are grandfathered and are upgraded only when
materially touched; the canonical manifest contract is in
`docs/client-server-migration.md` §Production-equivalent fixture manifest. This
document records the stable ownership rule;
`docs/client-server-migration.md` records the qualification evidence. A fixture
may stand in for an unrelated domain, but it must not omit a base prerequisite
that ordinary production composition owns and still claim to prove the product
topology.

### Coupling review checklist

Before accepting a new Host/Client coupling:

```text
[ ] locality is explicit
[ ] semantic port owner is explicit
[ ] composition owner is explicit
[ ] official wire/source is explicit
[ ] generated object identity is preserved
[ ] receiver-sensitive methods preserve binding
[ ] no duplicate service/projection owner
[ ] no second Connection/Client/semantic graph
[ ] L5 evidence exists when wire shape matters
```

## Application-layer ownership target (Pre-M3 TS Architecture Convergence)

The stage moves M3-critical runner ownership out of `src/index.ts` into
`src/app/**`. Host business coupling is allowed only in
`runtime/direct/**` and `app/direct/**`; the other application owners consume
semantic ports / the `Backend` / narrow injected callbacks. Status below is
`planned` until its slice lands.

| Owner | Owns | Host coupling | Status |
|---|---|---|---|
| `src/app/direct/**` | Direct application runtime: the Direct resolver POLICY and facades (the ONE `DirectModelSelectionOwner`, `agentFor`/`queueAgentFor`, the semantic `Backend` call, the assistant-stream install, model-selection/image-admission facade) | allowed zone — the Direct application coupling owner: the concrete Host lookups (`agents.get`/`sessions.get`/`agentDefaultModel`) move behind this module's composition seam; in A1 they are still supplied temporarily by the runner | current policy (A1); the A3 scope-bound stats/routing/approval reads land as command-runtime surface hooks resolved by the runner (A3-5) |
| `src/app/session/**` | current session subject/generation, transition gate + operation barrier ownership, ordinary create/open/switch and fork adoption orchestration, opaque `SessionSubject` authority | none | current (A2) |
| `src/app/submission/**` | the submission domain's APPLICATION orchestration and its `WriteOutcome` classification + draft/queue/card settlement: plain prompt, busy delivery, Ctrl+S steer sweep, queue pull-back, HostCommandPort submission + agent-facing fallback, shell submit, writer-barrier admission, prompt admission, draft restore/consume | none | current (A3-3/A3-4; the A3 fix round moved the remaining entrypoints in) |
| `src/app/command/client-command-registry.ts` | (none) | M3-4 PR4 §D2: the CLIENT-owned command execution registry — TUI built-ins and dynamic skill wrappers register here (their ONLY registration surface on the Remote branch); the Client handler runs in the Client Context with a Client-minted correlation id. It calls no Host service, exposes no wire surface and owns no Host id. The protocol package it imports (`dsh-commands`, types + the `CommandId` brand) is not Host-ownership coupling and is not tracked by the boundary gate. |
| `src/app/remote/command-source.ts` | (none) | M3-4 PR4 §D1: the Remote branch's command-authority bundle (the metadata-only authority reader + the shared Connection generation), assembled from the SAME aggregate; no second Connection and never moved into the Backend. M3-6 PR2: it ALSO exposes that same official generation observable as an invalidation hint (`connectionGeneration()`/`subscribeConnectionGeneration()`, direct delegation only) to the Client-local CommandSurface. Generation remains official Client authority; the command source owns no new cache/currentness truth, and no Host coupling is added. |
| `src/app/remote/session-facts-compose.ts` | (none) | M3-4 PR4 §3.3/§3.6: the whole-log projection + bounded-paging composition for `sessionStats`/`lastAssistantText` (official projections for lifetime truth, the exact binding's window for the recent figures). Host-import-free. |
| `src/tui/transcript/client-tool-presenter.ts` | (none) | M3-4 PR4 §5: the Client-derived tool presenter (diff/terminal cards from raw call arguments, generic fallback otherwise). Never consults `ctx.tools`, never invokes `presentCall`/`presentResult`; the `dsh-tools` import is type-only presentation vocabulary. |
| `src/app/command/**` | the SEMANTIC `TuiCommandRunner` facade: scope/currentness facts, scoped catalog, skill execution, stats/read, catalog refresh, prompt admission and the writer exposure (the presentation dependency bag is finalized in A5) | none | current (A3-5) |
| `src/app/surface/**` | the mounted surface (`createSurfaceRuntime` two-phase aggregate + `start()`), the opening journal, the unified status projection store instance, the surface-local TuiApp option wiring (image loader, history search, clipboard/link, extension registries + input routes, resize/workflow hooks), the extension `SurfaceHost` + Plugin Manager + keybinding sync + attach seams, the completion-notification/terminal-focus presentation, the Task Center (`TaskBrowserRuntime` + browser + Job viewer) and the approval/question presentation providers. TS3 splits the independent lifetimes into explicit application-level owners beside the aggregate (`notification-runtime`, `extension-runtime`, `plugin-manager-runtime`, `task-runtime`, `interaction-runtime`, `event-routing`), each constructed exactly once from the aggregate and released through its idempotent hook in the frozen teardown order. | none | current (A4; TS3 owner split) |
| `src/app/bootstrap.ts` + `src/app/bootstrap/**` | the application composition zone (A5-2, TS2): the entry facade keeps the process/Cordis startup prerequisites, the runner lifetime controller + diagnostics, **Host service resolution**, the owner constructions/bindings (Direct application runtime, session ownership + runtime, submission runtime + its controller/user shell, surface runtime + the surface owners, command authority/model-selection/artifacts), callback connection, the surface mount, disposal/retirement registration and the startup/fatal cleanup; the cohesive wiring-only helpers (`runtime-selection`, `presentation-bridge`, `task-source`, `event-wiring`, `lifecycle`, `session-startup`) take narrow injected values and resolve no Host service of their own. Composition only, never a business domain; M3 starts here. | `agents`, `sessions`, `subagents`, `jobs`, `attachments`, `llm`, `commands`, `settings`, `agentPresets`, `tools`, `permissionPresets`, `agentDefaultModel`, `planMode`, `sandboxPolicy`, `sessionQuery`; `import:dsh-agent`, `import:dsh-session` | current (A5-2) — the earlier "connects owners only, never a Host-coupling zone" wording is superseded by §23/§26: resolving the services the owners are built from IS the composition root's job, while every Direct-only fact stays behind `app/direct` §23's composition-only / giant-root criterion is **COMPLETE** (A5b): `startRunner()` carries no application handler group — the extracted owners (`app/surface/{viewer-runtime,session-presentation,status-runtime,input-history,settings-runtime,application-events,client-actions}.ts`, `app/command/{surface,model-selection,artifacts}.ts`, `app/submission/{controller,user-shell}.ts`) consume narrow injected capabilities and the semantic ports, so none of them introduces concrete Agent/Session Host coupling, a raw Host service lookup or Direct-runtime coupling (the protocol/DTO packages a few of them use — `dsh-commands`, `dsh-llm` and the type-only `dsh-user-approval/types` — are not Host-ownership coupling and are not tracked by the boundary gate); the ownership matrix records an empty unowned residual. See `docs/client-server-migration.md`. |

`src/runtime/**` (semantic ports, `backend.ts`, `direct/**`, `remote/**`) keeps
its current coupling and must not import `src/app/**`. Only `src/index.ts`,
the `src/app/bootstrap.ts` + `src/app/bootstrap/**` composition zone,
`src/app/direct/**` and `src/runtime/**` may import
`app/direct/**` / `runtime/direct/**` — every other module (the non-Direct
application owners `app/session`, `app/submission`, `app/command`, `app/surface`,
`app/plugin-manager`, and all presentation such as `tui-app.ts`, `transcript.ts`, `tui/transcript/tool-presentation.ts`,
`footer/**`, `components/**`) consumes semantic DTOs / Backend ports / narrow
injected callbacks; the historical type-only `legacy-settings-migration.ts`
exception is GONE — TS8-F2 moved that file into the `app/bootstrap/**`
composition zone, where the Direct import is legal, and emptied the gate
allowlist (`ARCHITECTURE_ALLOWLIST = []`). `app/surface/**` must not construct
Direct adapters, and experimental Remote composition must not be statically
reachable from `startup.ts`.

The A3 application owners confirm the boundary: `src/app/submission/runtime.ts`
and `src/app/command/runtime.ts` hold NO Host coupling (no `ctx.get`/`ctx.<service>`
and no `@deepseek-ai/dsh-agent` / `@deepseek-ai/dsh-session` import). Every
Direct fact they read arrives as a narrow injected surface hook, and the
session/skill writes go through `SessionRuntime.withWriter` / the semantic
`SkillCatalogCapability` port. The boundary gate therefore still reports
the unchanged `scripts/client-boundary-baseline.json` (28 coupled files).

The A4 surface owner confirms the same boundary: `src/app/surface/**` holds NO
Host coupling (no `ctx.get`/`ctx.<service>`, no `@deepseek-ai/dsh-agent` /
`@deepseek-ai/dsh-session` import, no `app/direct`/`runtime/direct` import) and
constructs no Direct adapter. Every Host/Direct fact it needs arrives as a
narrow injected capability or a semantic port. The Task Center consumes
`TaskSurfaceSource` — the production capability of the A4 plan §15.2, not a new
`Backend` port and not a second task model. M3-5 PR2 replaced the old
`TaskSurfaceAgents` group with the SELECTED `TaskSurfaceRead` bundle
(`currentKey` + `currentSessionId` + the semantic `readTask` + the commit-time
`activityOf`); M3-5 PR2 briefly renamed the jobs half's `get`/`kill` to OPTIONAL
selected-Job capabilities, and M3-5 PR3 removed them entirely: the jobs half is
now the roster feed ONLY (`list`/`subscribe`), because the selected-Job detail
and Stop are the ONE semantic `backend.jobObservation` port on BOTH backends.
M3-5 PR2 also made `TaskSurfaceSource.sessionId()` the transport-neutral
ownership read. The runner keeps the `SessionId`/`JobId` casts, the
retained-snapshot session fence, the `ownership` subject fences, the
`SessionRuntime.withWriter` interruption admission and the `cleanedUp` latch.
On the Remote branch the Task rows/activity come exclusively from
`RemoteApplicationSources.task`
(`readDescendants`/`jobs`/`subscribeJobs`/`subscribeSessions`) and the child
viewer from `RemoteApplicationSources.childView`; the Host `subagent/start|end`
and `agent/status` channels are registered on the Direct branch only, so no Host
event doubles as a Remote Task authority. The runner also keeps the semantic
status DERIVATION, because the `status/derive-*` seam is the sanctioned
Host-reading path (`planMode` / `sandboxPolicy` / `permissionPresets` /
`sessionProjections`); the surface owns the store instance and the app's own
projection. The boundary gate therefore still reports the unchanged
`scripts/client-boundary-baseline.json` (28 coupled files), and the A5b-0 root
matrix was regenerated at that stage for the M3-5 PR2 root declarations (that
migration ledger was retired in TS2 — the durable invariants it stood for are
enforced by the architecture gate and the bootstrap composition/single-owner
tests).

Composition locality (M3-5 PR6): the **Direct** Task composition is the ONLY
branch that evaluates the Host `ctx.jobs` / `ctx.subagents` lookups — both are
gated on `remoteSources === undefined`. The **Remote** Task composition resolves
neither Host service; it consumes `RemoteApplicationSources.task` / `childView`
plus `backend.jobObservation`. `src/app/bootstrap.ts` remains the composition
root and still lexically contains both lookups (the boundary baseline keeps its
`jobs` / `subagents` entries); the closure fact is branch reachability, not
lexical absence. The source lock is `test/application-runtime-selection.test.ts`
(Remote-selected Task composition resolves no Host `ctx.jobs` / `ctx.subagents`);
the real Remote surface proof remains `test/runner-remote-task-center.test.ts`.

## Categories

| Category | Meaning | Retirement |
|---|---|---|
| `DIRECT_HOST_REQUIRED` | Direct-mode-only machinery; must survive until the Host owns every write | M8 (prove Host-owned writes + cross-client concurrency first) |
| `MIGRATABLE` | Business Host access that a semantic port + wire adapter can replace | M1–M5, capability by capability |
| `CLIENT_LOCAL` | No Host coupling today; must stay that way | never |
| `TEMPORARY_EXCEPTION` | Allowed by design, not migration debt | never (documented carve-outs) |

The Direct owned-session retirement
(`src/runtime/direct/owned-session-retirement.ts`) is a structural,
callback-only helper: it imports no Host package and touches no `ctx`, so it
adds ZERO baseline entries. The runner (`src/index.ts`, already the primary
Direct coupling point) wires the live Agent / AgentHandle / sessions /
subagents into it — the same Direct ownership escape the runner already
owns. This is Direct ownership retirement, not a semantic-port or Remote
capability (see `docs/client-server-migration.md` §Direct ownership
retirement).

The bundle also mounts one Host row the base layer deliberately leaves to the
web bundle: `@deepseek-ai/dsh-workspace` (`cordis.patch.yml`, row id
`workspace`), injected by the `tui-app` row. D2.4 Direct fork must observe the
official workspace membership (`workspaceRegistry` in the
`session-lifecycle-direct.ts` row below), and that service only exists while the
row is mounted. It is the same official row the web bundle inserts, and the DSH
installation already ships the package; activating it performs the upstream
one-time history bootstrap that groups stored Session headers by canonical cwd
into durable workspace records. See the D2.4 status and the fork exact-cut
convergence sections in `docs/client-server-migration.md`.

## Inventory (baseline, generated from the current tree)

### DIRECT_HOST_REQUIRED

| File | Coupling | Notes |
|---|---|---|
| `src/index.ts` | `import:dsh-agent` | The package FACADE (A5, plan §28/§29): module docs, the Cordis contract (`name`, `inject`), the `Config` re-export, the public root re-exports, and `apply(ctx, config)` delegating to `app/bootstrap`'s `applyRunner`. A5-1 relocated the helper IMPLEMENTATIONS to their natural top-level modules with every root export preserved; A5-2 moved the runner body to `src/app/bootstrap.ts`. The one remaining Host import is `@deepseek-ai/dsh-agent`, whose types are part of the frozen public `composeAgent` overload declarations (the Direct body lives in `app/direct/composition.ts`). |
| `src/app/direct/composition.ts` | `agentPresets`, `import:dsh-agent` | The public `composeAgent` / `recordedPreset` helper's Direct implementation (A5-1, plan §27): resolve the preset an agent will be composed from and build the setup that installs the Agent-scoped model selection, the preset mount and the TUI prompt sections. Direct-only by construction (the Host preset registry, `installModelSelection`), so it lives under `app/direct` while `src/index.ts` keeps the public overload declarations and delegates — which keeps the entry one-way (`index -> bootstrap -> app/direct`). Baseline entries added by the A5-1 relocation: both patterns were already `index.ts` entries (the `import:dsh-agent` one stays in the entry for its public overload types). |
| `src/app/direct/runtime.ts` | `agents`, `sessions`, `subagents`, `import:dsh-agent` | The Direct application runtime (Pre-M3 A1): the Direct resolver POLICY and facades — the ONE `DirectModelSelectionOwner`, the live-Agent / queue-Agent / registered-Agent selection logic, Host Session accessor forwarding, model-selection/image-admission facade and the Direct assistant-stream install — delegating adapter assembly to `runtime/direct/backend-direct.ts`. It holds NO mutable current-session truth (live getters into the session authority). A5-3 completed the A1 promise: the Direct-only Host lookups (`agents`/`sessions` for the resolver and retirement seams, `subagents` for the descendant drain) moved behind this module's own composition seam (`directHostAccessors`), so `app/bootstrap` hands over the Context plus the verified owner/ledger seams and never a Direct fact it resolved itself. The three baseline entries added by that relocation are the same services the composition root still resolves for its own startup gate. No UI, transition, draft, command routing or panel state. Baseline entry added by the A1 relocation. |
| `src/app/direct/owner-registry.ts` | `import:dsh-agent` | The Direct Agent↔OwnerRef registry (A2): one exact Agent OBJECT maps to one opaque `SessionOwnerRef` (stable across repeated `SessionHandle` wrappers; different Agents stay distinct even on the same session id). `fromHandle` is the ONLY `SessionHandle → SessionOwnerRef` path; `currentDirectAttachment()` is the explicitly A2-TRANSITIONAL derived projection of the ownership core's current owner (never identity/currentness, never a sessionId→Agent reverse lookup). Baseline entry added by the A2-2b relocation. |
| `src/app/direct/owner-retirement.ts` | `import:dsh-agent` | The Direct adapter for the consumer-owned `SessionOwnerRetirement` port (A2 §3.3): the exactly-once shutdown cancel, the abort-aware quiesce mechanism and the official close-order retirement (`cancel → idle → descendants → flush → dispose`), plus park/retireParked over the Direct owner pool. The port speaks only opaque `SessionOwnerRef`s; every Direct fact (Agent, AgentHandle, cancel policy, descendant drain, durable flush) stays here or arrives as a boundary dependency. Baseline entry added by the A2-3 relocation. |
| `src/domain/session/rewind.ts`, `src/runtime/direct/turn-outline-compat.ts` | `import:dsh-session` | Rewind semantics (TS8-E relocation of the retired `src/rewind.ts`): the neutral candidate fold lives in `domain/session/rewind.ts`; the Direct-only compatibility `turnOutline` fold lives in `runtime/direct/turn-outline-compat.ts` (Remote must not import it). |

### MIGRATABLE

| File | Coupling | Notes |
|---|---|---|
| `src/commands.ts` | `import:dsh-agent`, `import:dsh-session` | The command layer's stable facade + registration/catalog coordinator and its Host-type escape — M1.7–M1.11 narrowed it to ZERO `ctx.get` and ZERO service-object access: every Host read/write a command performs goes through the semantic ports (`catalog`/`config`/`hostFile`/`sessionReader`/`sessionWriter`/`interaction`); the `CommandHostCapabilities` facade and `runner.host` are RETIRED. TS1 moved the built-in definitions into `src/tui/commands/**` (settings, sessions, models, skills, tasks, artifacts, status, auth, utility): those modules add ZERO Host service/type coupling of their own — they consume the coordinator's primitives and the same semantic ports — so this row remains the only command-layer Host coupling. `src/app/command/**` remains the application command authority (execution, catalog lifecycle); `src/tui/commands/**` is terminal definition/presentation only. The remaining type-only imports are the runner's Direct ownership escape (live Agent/Session types), kept until M8. |
| `src/runtime/direct/skill-catalog.ts` | `agentPresets`, `skills` | The Direct Host skill read: structural `SkillRegistryLike`/`AgentPresetsLike` + capability detection (decision 11). TS8-E moved the neutral `HumanSkillSummary`/`HumanSkillCatalog`/`SkillSummaryLike` vocabulary and the official `isUserInvocableSkill` policy guard to `src/domain/catalog/skill.ts`; the Host coupling stays attributed here. |
| `src/runtime/direct/surface-catalog.ts` | `commands` | TS8-E split: the neutral snapshot DTOs live in `src/domain/catalog/surface.ts`; this Direct adapter owns the live-agent collector (`readSurfaceCatalog`) and the in-process `commands.list(undefined)` global-layer read (`listGlobalCommands`). The runner's pre-mount prefetch and the coordinator's live-agent read hook consume it through injected neutral-DTO operations (agent-owned, M8 escape — the sessionless STANDING read routes through the catalog port, M1.8), so the Host coupling stays here. |
| `src/app/command/catalog-refresh.ts` | (none) | Coordinator; its refresh target is the branch-opaque `CatalogReadTarget` (M3-4 PR4 §2.3): Direct feeds the exact Agent, the Remote branch a session-keyed target the command source resolves, so the coordinator carries no Host type import. The `import:dsh-agent` baseline entry was REMOVED by that relocation (coupling reduced). |
| `src/runtime/direct/subagent-direct.ts` (+ `src/runtime/subagent-port.ts`, `src/runtime/subagent-outcome.ts`) | (structural `ctx.subagents` official prompt surface, injected) | The pure human-prompt delivery core (alpha.4's `ctx.subagents.prompt`); the TS8-F4 split puts the detached DTOs in `runtime/subagent-port.ts`, the refusal/indeterminate classification in `runtime/subagent-outcome.ts` and the Direct deliver helper inside this adapter. Consumed by `SubagentPort` (M1.2). The runner resolves `queue` / `steer` for continuable viewer gestures against child activity and `busyEnter`; the port forwards the result. Task Center interruption is a separate `SubagentPort.interrupt()` operation (D2.1). |
| `src/runtime/direct/subagent-direct.ts` | `subagents` | The Direct `SubagentPort` adapter (M1.2/D2.1) — the ONLY module in the prompt and interrupt paths that touches `ctx` (and the only one minting the caller-owned prompt `requestId`); it maps explicit parent/child interruption to the official user-authority call. The runner depends on the port. Baseline entry added by the M1.2 relocation. |
| `src/runtime/direct/backend-direct.ts` | (none) | The Direct semantic-assembly owner (Pre-M3): builds the complete `Backend` from the runner-supplied Direct-only resolvers (live-Agent/queue-Agent lookup, preset compose, Session accessors, settings/model-selection/ownership seams). It resolves no Host service itself and owns no UI, transition, draft, panel or command routing. |
| `src/runtime/direct/session-direct.ts` | `import:dsh-session`, `sessionPersistence`, `sessionQuery`, `agentPresets`, `sessionProjections`, `sessionProjectionCache` | The Direct `SessionReader` adapter (M1.3, extended M1.11 + master alignment) — owns master-visible semantic session-query listing (live rows remain visible without `cwd`; cold rows require `cwd`), official-parity content search (`SessionReader.search()` → `sessionQuery.searchSessions()` with master `ApiSessionList.search()` business semantics — the pure cursor/authorization/dedupe loop lives in `session-search-direct.ts`, the retired TUI-owned newest-100 + `filterEvents` private rule is gone) and best-effort context measurement (`measureContext`, the /status row — M3-3A: the official `contextPressure` projection numerator `projectedTokens ?? pressureTokens`, no `tokenMeter` second authority; the projection reads also feed `turnOutline` and the subject-neutral `sessionStatus` snapshot); the combined `title`+`agentPreset` projection batch delegates to `session-projection-direct.ts` (the official live-cached-snapshot/cache-checkpoint ladder, with cold misses left unknown). The TUI-local title cache and the `readTitleSnapshots()` path are retired — the adapter's structural query surface no longer even declares them. The migration-era `readExportData` seam is RETIRED (Pre-Stage-D export convergence): the export plane is the `SessionArchivePort` (`session-archive-direct.ts`), never this reader. The consumers (the command layer — `src/tui/commands/sessions.ts` and `src/tui/commands/status.ts` — through the coordinator facade) depend on the port. Baseline entries added by the M1.3/M1.11 relocations, the master projection-cache contract, and the projection module split (the cache/`sessionProjections` reads moved with it). **`sessionStatus` model compat (2026-10-08, temporary, owner-revised scope):** this composition does not register the official `modelSelection` projection unit (its only registrant is the API SessionController row, composed by the web bundle), so the adapter treats the key's ABSENCE from the snapshot `values` — never a present-but-empty value, because the registered unit's legal `{ next: null, lastUsed: null }` stays authoritative — as the signal to read the EXACT attached Session's own latest request header through `DurableModelSelectionReader.durableProjectionForSession` into the same `SessionStatusProjection.model`. The compat source restores the **latest actually used route only**: an unconsumed pending `model/selection` intent is out of scope, the official `next` slot therefore reads as `lastUsed`, and the source must not be described as the complete official semantic. It adds no deprecated history-reader call site (no log scan, baseline unchanged). The shared DTO mapping and the Remote binding read are untouched. **Exit condition:** delete this fallback once DSH exposes an independent official registration entry for the projection; this is recorded as the only follow-up of the fix, together with the released-child cold status read (tracked separately, not in scope). |
| `src/runtime/direct/session-archive-direct.ts` | `import:dsh-session` (the base `dsh-session` type package — `SessionId`; `dsh-session-log-export` is a separate package and the exact-match matcher no longer conflates the two) | The Direct `SessionArchivePort` adapter (Pre-Stage-D export convergence) — the ONLY module in the export path that touches the Host archive primitives: `sessionLogExportDeps` service resolution, `flushLiveSessionLog` through the store's durability barrier, the committed-log READ handle (never the cold-view observation seam), and the official full-tree ZIP stream (`streamSessionLogZip`, descendants + attachments). The FILE WRITE stays Client-local (`client/artifact/save.ts`); a future Remote adapter maps the same port onto `GET/HEAD /api/session.export`. Baseline entry added with the module itself. |
| `src/runtime/direct/session-preset-direct.ts` | `agentPresets`, `import:dsh-session`, `sessionQuery`, `sessionProjections` | The Direct session-preset adapter — explicit resume/preset paths read cold sessions through the official `sessionQuery.observeSession()` observation seam (the engine owns live/cold source selection, persistence borrow/preparation, projection-cache hydration, tail replay, and the projection cut); picker enrichment stays on the live/cache-only projection path. D2.3 adds `selectBlankSessionPreset()`, the official in-process `agentPresets.select(agent, id)` write used by the Direct catalog adapter to SWITCH an already-created BLANK Session (the Host owns the blank check, recompose transaction and durable `agent-preset/selected` commit). It is NOT the fresh-create/launch `--preset` path: a fresh Session carries its preset at creation time (Direct compose/mount setup; Remote atomic `session.create({ agentPreset })`). The TUI reads the current DSH V3 `agentPreset` projection value as-is; DSH owns historical V2→V3 preset migration, while the TUI retains only the narrow omitted-settings-default shim in `src/runtime/session-preset.ts`. |
| `src/runtime/direct/session-projection-direct.ts` | `import:dsh-session`, (`sessionProjections` / `sessionProjectionCache` structural reads) | The Direct combined session-projection batch (the picker-projection alignment) — `SessionReader.projectionBatch()` implementation: live rows read only already-materialized cells through the official `sessionProjections.cachedSnapshot()`, cold rows read the `sessionProjectionCache.cachedSnapshot()` checkpoint keyed by the `list()` header identity (or its predecessor-title hint), and cold misses remain unknown without activating a historical Session. Current DSH V3 preset identities are consumed as-is; this is Host coupling INSIDE the Direct adapter by design (the projection semantics are DSH-owned), not Client debt: a future Remote adapter maps the same port method onto the official client projection contract instead of copying this ladder. Baseline entry added with the module itself. |
| `src/runtime/remote/session-reader-remote.ts` | (none) | Experimental M2/D1.1 `SessionReader` adapter over the official DSH Client Session list/projection/search faces. It consumes detached Client facts only: ready list snapshots, authoritative `ids` order, `updatedAt`, projection values/faces, and official search results. It has no Host imports, persistence access, writer methods, or production wiring. |
| `src/runtime/remote/session-read-shadow.ts` | (none) | Experimental M2/D1.1 Direct-vs-Remote diagnostic comparator. It owns only an operation epoch and Connection-generation fence; it emits bounded parity facts and explicit discarded/unavailable outcomes. It never changes Direct authority or renders Remote data. |
| `src/runtime/surface-authority-port.ts` | (none) | Structural live-Session command/skill authority read port; only detached commands and human-skill metadata cross it. |
| `src/runtime/direct/surface-authority-direct.ts` | (none; reuses `surface-catalog`) | Direct M2/D1.2 adapter over the existing effective live surface collector; it resolves an already-live Agent and does not create or mutate Host state. |
| `src/runtime/remote/surface-authority-remote.ts` | (none) | Experimental M2/D1.2 adapter over official generated `commands.list` and `skills.list` Remotes; explicit detached whitelist, no Host imports, no writes or execution. M3-4 PR4 added a commands-only, generation-fenced `readCommands` metadata read so the command provider and the skill provider degrade independently (one absent skill registry must not zero the Host command catalog). |
| `src/runtime/remote/surface-authority-shadow.ts` | (none) | Experimental M2/D1.2 generation-fenced Direct-vs-Remote comparator; bounded command/skill mismatches and metadata-derived claim diagnostics only. |
| `src/runtime/task-read-port.ts` | (none) | Structural Task read contract (M3-5 PR2): the FULL Task Center dataset — one root Session, its complete descendant catalog in stable DFS pre-order (`parentId` + `depth` + mode/label/activity/`hasChildren`/diagnostic per entry) and the root's status-only job roster. `readDescendants()` replaced the old direct-child read; the descendant tree is no longer an upstream gap. |
| `src/runtime/direct/task-read-direct.ts` | (none) | Direct Task read adapter (M3-5 PR2); composes the injected official `listDescendants`, the live-Agent registry activity, and `jobs.list` faces without exposing Host objects or creating Agents. |
| `src/runtime/remote/task-read-remote.ts` | (none) | Experimental Task read adapter (M3-5 PR2) over the official Client Session projections: a RECURSIVE `subagentCatalog` walk (`projectionsBySession` + `refreshProjections`, root failure throws, an unreadable/absent child branch degrades to a branch-scoped `corrupt`/`unavailable` diagnostic whose siblings stay visible — the owner-ruled branch-isolation product contract (explicitly NOT implementation parity: the current Host `listDescendants()` rethrows, and on the ready/key-absent shape the Web mapper coalesces to a known leaf) — and an `unknown` mode an `unsupported` diagnostic whose children are still traversed), activity from the official Session-list `running` bit, and the ClientJobs retained `watchRows` roster; generation/cancellation/operation-fenced, read-only, detached/frozen, and it never retains or opens a child log. The rc.2 carrier cannot distinguish the `null` (missing Session) from the non-null (catalog-less baseline) `ready` provenance — recorded as an explicit user-visible failure-scope limitation in `client-server-migration.md`. |
| `src/runtime/remote/task-read-shadow.ts` | (none) | Experimental Task comparator (M3-5 PR2); compares the FULL descendant tree (ids/order/kind/label/mode/activity/`hasChildren`/`parentId`/`depth`, diagnostics, job roster) plus `buildTaskRows`, with bounded diagnostics. The former `subagent.descendantTree` skip is REMOVED: nothing is skipped. |
| `src/app/direct/child-view.ts` | (none) | Direct child-view source (M3-5 PR2): composes the live/cold child Session read, the Agent registry activity, and the live assistant-stream baseline into the viewer's `ViewerChildSource`. Constructed only on the Direct branch; no Host object escapes and no per-child subscription exists (the Host firehose already routes the viewed child). |
| `src/app/remote/child-view.ts` | official Client `ISessions`/`PresentationReader`/`SessionFace`/eventSource, through the ONE Remote aggregate | Remote child-view source (M3-5 PR2): acquires ONE `tuiChildView` `SessionReference` from the exact durable `SubagentAddress` (parent + child + catalog mode, never a plain id, never a Host Agent), awaits its open, hydrates through the SHARED `PresentationReader`, subscribes the SHARED `RemoteLiveIngress`, pages via `loadOlder`, and releases exactly once with the ingress disposed first. |
| `src/runtime/presentation-read-port.ts` | (none) | Structural D1.3 presentation read contract; keeps durable history and live inputs as separate detached planes, plus window flags and open state, without a TUI or transport object. |
| `src/runtime/direct/presentation-read-direct.ts` | (none) | Direct D1.3 presentation reference adapter over existing Session event snapshots and assistant stream baseline; no duplicate history or stream tracker. |
| `src/runtime/remote/presentation-read-remote.ts` | (none) | Experimental D1.3 adapter over official `SessionBinding.eventSource`, `SessionFace` snapshots, and `loadOlder()` only; it preserves source order within each plane and protects detached payloads. |
| `src/runtime/direct/session-writer-direct.ts` | `sessionTitle`, `fileUploads` | The Direct `SessionWriter` adapter (D2.1) — identity-based (sessionId) semantic operations over the live Agent resolver and the `ctx.sessionTitle` service: explicit-mode ordinary prompts, dsh-web-style FIFO per-occurrence `updateQueue({ kind: 'steer' })` calls, official text-only/non-whitespace edit validation (with malformed structural blocks treated as non-text), edit/remove/steer queue mutations, user `rpcId` file-upload retirement after remove, user cancel with pending inbox preserved, normalized rename, and title refresh. Ordinary session verbs retain their caller-authorized resolver; queue occurrence verbs may use the separately fenced exact live continuable-child viewer resolver. Steer orchestration, barriers and revalidation stay in the runner. Baseline entry retained from the M1.4 relocation and updated for the converged contract. |
| `src/runtime/remote/session-writer-remote.ts` | (none) | Experimental M2/D2.2 `SessionWriter` adapter over the official `ClientSessions.binding(id).session` `SessionFace`. Identity-addressed writes only, and never a Client-global selection verb. alpha.2 made `binding()` borrow-only, so each write borrows the existing generation and pins it with a temporary `tuiOperation` reference for the whole operation (never materializing a cold Session); a replaced live binding fails the dispatch closed. The official `beginSubmission`→identified-`prompt` echo lifecycle, occurrence-level `updateQueue`, `cancel`, normalized `rename`, and an explicit `unsupported` title refresh. A Connection generation captured before dispatch fences the binding too; a `RemoteResult` failure is classified rejected/cancelled/indeterminate without a Remote-only taxonomy, and `session/writer-held` settles `rejected` with preserved `details` and actionable holder guidance. It resolves the prepared submission through a migration-local serializer seam and has no Host imports or production wiring. |
| `src/runtime/remote/write-failure.ts` | (none) | Experimental M2/D2.2 settlement classifier: maps an official `RemoteResult` failure (or an assembly throw) onto the shared `WriteOutcome` vocabulary. Domain and `gateway/bad-request` codes are proven refusals; universal carrier codes stay `cancelled`/`indeterminate`. Host-free and transport-free. |
| `src/runtime/remote/pending-input-reader-remote.ts` | (none) | Experimental M2/D2.2 `PendingInputReader` adapter over the official alpha.2 durable inbox projection (`session.projections.faceOf('inbox')`). It maps `next-turn` to `queued`, a user-origin `next-step` message to `steering`, every other `next-step` message to `context`, preserves the official order, carries the optional plain `rpcId`, detaches/freezes content, and is Connection-generation fenced. It never reads Direct `nextTurn`/`nextStep` names, never infers placement from `running`, and never reads the removed alpha.1 `SessionSnapshot.queue`. |
| `src/runtime/remote/host-command-remote.ts` | (none) | Experimental M2/D2.2 `HostCommandPort` adapter over the official generated `commands.execute(agentId, line, attachments, signal)` Remote — the attachment-preserving path (never the `SessionFace.command(line)` convenience that drops attachments). It forwards the full line, opaque attachments and caller signal unchanged and classifies settlement without a model fallback. |
| `src/runtime/remote/subagent-remote.ts` | (none) | Experimental M2/D2.2 `SubagentPort` adapter over the official generated `subagents.prompt` / `subagents.interruptByParent` Remotes. Continuation prompts keep the exact durable parent/child address and `continuable` mode with one pre-call request identity per human submit; interruption addresses the explicit direct parent. It never opens a child to write to it and never infers parent authority from UI nesting. |
| `src/runtime/pending-input-reader-port.ts` | (none) | Semantic pending-input projection: running state plus `queued` / `steering` / `context` placements, and an optional plain `rpcId` correlation string for user-origin occurrences. It contains no Direct or Remote transport vocabulary and never exposes the raw message `source`. |
| `src/runtime/direct/pending-input-reader-direct.ts` | (none; structural Direct read) | The Direct `PendingInputReader` adapter — the only consumer-facing read adapter that knows `Agent.inbox.nextTurn` / `nextStep` and their sources; it maps next-turn to `queued`, user-origin next-step to `steering`, all other next-step rows to `context`, projects a user `source.rpcId` to the plain `rpcId` correlation field, exposes no source field, and returns `undefined` when the session is unavailable. Its resolver is separately fenced for the exact live continuable child mounted by an interactive viewer. |
| `src/app/submission/pending-submission.ts` | (none) | The D2.1 follow-up Client-local pending-submission ledger: insertion-ordered, request-id-keyed echoes (`transcript` / `queued` / `steering` placements) bridging the editor-clear → authoritative-occurrence window. Pure and Host-free; it never reads a Host inbox or the terminal. |
| `src/app/submission/presentation.ts`, `src/app/remote/submission-presentation.ts` | (none) | The D2.2 client-local submission-presentation seam (TS8-E split): the shared transport-neutral contract + the Direct ledger source live in `app/submission/presentation.ts`; the experimental Remote official `SessionSnapshot.pendingSubmissions` projection (under the Connection generation) lives in `app/remote/submission-presentation.ts` — it alone consumes the Remote connection-generation faces. The renderer joins these items with authoritative pending-input rows by request/rpc identity only — never by text — and the seam owns no Host state. |
| `src/runtime/host-command-port.ts` | (none) | The D2.1 Host command execution port — carries session identity, the full selected line, opaque submitted attachments and signal; it owns execution only, not command claim precedence or TUI-local/extension/skill routing. Zero Host coupling. |
| `src/runtime/direct/host-command-direct.ts` | `commands` | The Direct D2.1 `HostCommandPort` adapter — resolves the live Agent by session id at call time and invokes the official `commands.execute` service. It preserves the selected line, attachments, signal and settled command result; it does not parse, claim or route commands. Baseline entry added with the new Direct adapter. |
| `src/runtime/direct/plugin-manager-direct.ts` | `pluginManager` | The Direct P1-A `PluginManagerPort` adapter — the ONLY module that resolves the official `@deepseek-ai/dsh-plugin-manager` Host service and maps its records/events onto detached TUI facts. It performs package/profile mutations ONLY through the official service (never pnpm, package.json, patch YAML or a profile path) and exposes no Host object above the port. The base layer already mounts the service; this is a P1 Host seam that M3 later re-points at the official client contract. Pre-M3 extracts the pure record mapping into the shared `plugin-manager-mapping.ts` (the Remote adapter uses the SAME mapping). M3-5 PR4: the official `plugin-manager/changed` notification maps to ONE transport-neutral invalidation hint (`subscribeInvalidation`) — the payload is never treated as inventory truth. Baseline entry added with the module. |
| `src/runtime/direct/job-observation-direct.ts` | `jobController`, `jobs` | The Direct P1-B `JobObservationPort` adapter — the ONLY module that resolves the official `@deepseek-ai/dsh-api-job-controller` service and consumes `follow()`, the official NON-CONSUMING Host observer (it reads only `JobRegistry.readAt()`; it never calls `jobs.read()`, never advances the model `job_output` cursor and never acknowledges a completion notice). It also resolves the official local `jobs` registry for the port's ONE human mutation: `jobs.get` proves the row is still in the caller's visible list, then `jobs.kill` yields the registry's admission, mapped onto `JobStopOutcome` with no local roster/status mutation and no retry. The TUI inserts the same `job-controller` row the rc.1 web bundle mounts; the adapter owns only the observer lifetime, frame mapping and stop admission. Pre-M3 serves this port through the `Backend` (`backend.jobObservation`) instead of a runner-local construction. Same process/Context — NOT M3. Baseline entry added with the module; M3-5 PR3 added the local `jobs` registry for the selected-Job Stop seam (a deliberate Direct seam relocation, not new Remote-path coupling). |
| `src/runtime/plugin-manager-mapping.ts` | (none) | The ONE pure Plugin Manager record mapping (P1, shared by Pre-M3): official `@deepseek-ai/dsh-plugin-manager` records → detached `PluginManagerPort` facts, used by BOTH the Direct Host-service adapter and the generated-Remote adapter so the presentation semantics cannot drift. S4-D1 forwards the complete rc.2 `BundleInfo.official/availability/installTarget/source` facts and the render-relevant `ChangeResult` facts (`restartReason`, actual `version`, `pendingBuilds`, `approvedBuilds`, `packageResult`, `registries`, `failedAt`) plus `InstallBundleOptions.approvedBuilds` unchanged. No Cordis context, Host service or `RemoteResult` crosses it. |
| `src/runtime/remote/plugin-manager-remote.ts` | (none) | Experimental `PluginManagerPort` adapter over the official generated `pluginManager` Remote namespace plus the typed Remote's forwarded `plugin-manager/changed\|install-state\|install-log` events. Mapped through the shared pure mapping; a refused `RemoteResult` becomes one thrown Error (the controller's failure entry), with no retry and no second install state. Composed by the M3 Remote application runtime (`src/app/remote/m3a-semantics.ts`) and served through `Backend.pluginManager`; the forwarded `plugin-manager/changed` AND a new official Connection generation each map to ONE transport-neutral invalidation hint, while an authoritative `snapshot()` reread remains the only business truth (M3-5 PR4). |
| `src/runtime/remote/job-observation-remote.ts` | (none) | Experimental P1 `JobObservationPort` adapter over the official Client `IJobs` (`state.rows` metadata authority, `state.observed` text/gap/streaming/error, reference-counted `watchRows`/`observe`). It owns no follow/cursor/reconnect state machine and never re-clips the official bounded render tail; both leases release exactly once. NOT production-composed. See the open evidence gap recorded in `client-server-migration.md` (section "Open evidence gap — Remote same-run Job Command producer attribution"). |
| `src/app/plugin-manager/**` | the Plugin Manager APPLICATION owner (TS3/S4-D1): `controller.ts` (official inventory read epochs, install request identity/recovery/approval, mutation currentness and disposal — it no longer owns list selection, search/filter, focus or scroll), `host-registry.ts` (one active surface claim/token), `extension-inventory.ts` (read-only extension observation projection), `classify.ts` (frozen four-section/provenance classification; the exact rc.2 B01–B14/base identity lists are version-limited presentation evidence, never catalog authority) and `model.ts` (pure detached section/card/Detail projection). The Host business authority stays in `runtime/plugin-manager-port.ts` + the shared mapping; the concrete fullscreen page is `src/tui/plugin-manager/workspace.ts` (S4-D1) and reaches the application only through the injected `PluginManagerPanelFactory` seam. | none | current (S4-D1) |
| `src/app/plugin-manager/extension-inventory.ts` | (none) | The TUI-internal read-only projection over the shared `piTuiExtensions` runtime: it aggregates the runtime's own contribution-health records and the internal owner→Loader-entry-id projection into detached observations, used ONLY for presentation classification. It is not a second inventory, loader or enable/disable authority, and is not part of the public Extension API. The service-side seam (`_ownerEntryIds()`, `recordOwnerEntry()`) is package-private. Zero Host-service coupling (the ledger view is injected). |
| `src/runtime/host-file-port.ts` | (none) | The Host-file port interface (M1.10, contract review) — path-only candidates (`{path, kind}`, the official `FileReferenceCandidate` shape). The Host discovery authority owns filtering, ranking, result bounds and order (the client presents them verbatim); only the TUI's quoting/`@`-insertion value/label/description/directory-continuation are CLIENT policy in `src/tui/interaction/autocomplete/provider.ts` + `src/tui/file-completion/presentation.ts`, never Host data. Zero Host coupling. |
| `src/runtime/direct/host-file-direct.ts` | `fileReferences` (read lazily per call through `this.ctx?.get('fileReferences')` — the Direct Host context seam) | The Direct `HostFilePort` adapter (M1.10, TS8-HF1 routing) — the mapper over the session `@` router: the SESSION scope resolves the live Agent and hands it to `runtime/direct/host-file-augmentation-direct.ts`, which owns the bare-vs-explicit decision (bare → official `ctx.fileReferences.list(agent, query, signal)`, the `dsh-file-reference-local` service the composition mounts; explicit → the Host scoped scanner), while the WORKSPACE scope has no Host service and delegates to the Direct-only compatibility scanner. Since TS8-A the filesystem mechanics live in the canonical Direct owner `src/runtime/direct/file-completion/host-discovery.ts` (fd discovery or the bounded recursive fallback scan; renamed from `workspace-discovery.ts` by TS8-HF1 when it gained its second consumer); the `resolveReference` existence probe and its private `resolveReferenceCandidate()` path resolution (`~` expansion, absolute passthrough, relative against the Host workspace) stay here. Returns path-only DTOs; discovery bounds only, no presentation. |
| `src/runtime/direct/file-completion/host-discovery.ts` | (none) | The Direct Host scoped-discovery driver (TS8-A, renamed TS8-HF1): the Direct process's own PATH/PATHEXT finder detection, `node:fs` facts and fd/fdfind process behind the neutral `LocalDiscoveryDriver` contract. Two consumers — the sessionless WORKSPACE compatibility path and the explicit Session `@` path-navigation route. Base-relative joins deliberately do NOT re-normalize a `..` segment (raw concatenation), so a search base that keeps the Host's PHYSICAL traversal spelling survives to the syscall; for every base the neutral resolver already normalized this is identical to `path.join`. No Host service, no `Context`, no Client fact; detached directory-entry/candidate facts only. |
| `src/runtime/direct/host-file-augmentation-direct.ts` | (none) | The TS8-HF1 session `@` Host router — the ONE Host-side authority both backends share. Inputs are narrow Host facts only (the live Agent, the injected official `FileReferencesServiceLike`, the discovery driver, the Host path environment): no `ctx` resolution, no Client cwd/home/platform read. Owns the explicit-path classifier, the scoped recursive search, parent/absolute/Host-home navigation (ranking always scores the SCOPE-RELATIVE candidate, and only the accepted home candidate is materialized as an absolute Host path — the home prefix can never satisfy the path-substring tier) and the ONE upstream-retirement marker. POSIX BOUNDARY: because the reused TS8-A resolver normalizes any backslash-bearing token into its Windows dialect on a POSIX host (a pinned Client-local cross-dialect contract), an ambiguous POSIX token containing a backslash is NOT claimed by the scoped route and stays with the official provider — a deliberate fail-closed narrowing over searching a DIFFERENT directory. PARENT-TRAVERSAL SPELLING: the search base follows the spelling `dsh-fs-local` gives the ACTUAL accepted value. It tests the whole anchored raw spelling (`<cwd>/<displayBase>`, so a `..` carried by the Session cwd counts too) and keeps that raw concatenation when required; the bare `~`/`~/` scope is normalized like the absolute value the home branch emits. Completion and the model's read must resolve to one directory. Zero Host-service coupling. |
| `src/runtime/remote/host-file-remote.ts` | (none) | The Remote `HostFilePort` adapter (M3-3A, TS8-HF1 namespace cutover) — maps the SESSION scope onto the private `piTuiFileReferences/list(sessionId, query, signal)` Remote and unwraps the Host's own `HostFileListResult` (an `unavailable` business value is preserved as the port's unavailable, distinct from a transport failure). No Client filesystem discovery of any kind (mechanically asserted): no cwd/home guess, no local file source, no stat probe, no `runtime/direct/**` import. The WORKSPACE scope and existence probing stay explicitly unavailable. The Host endpoint — not this Client adapter — decides the query's route. |
| `src/runtime/remote/pi-tui-file-reference-contract.ts` | (none) | The TS8-HF1 private `piTuiFileReferences` Typert contract: ONE handwritten `InvocationDescriptor` that BOTH the Host registration and the Client contribution derive from (namespace/method/parameter drift is impossible by construction), plus the strict input codecs and the wire `HostFileListResult` codec. No decorator discovery, no generated artifact, no duplicated literal. Zero Host-service coupling. |
| `src/runtime/remote/pi-tui-file-reference-host-bridge.ts` | (none) | The TS8-HF1 Remote Host-side bridge — a CONSTRUCTION/ADAPTATION seam only: it binds the private Remote method to `listPiTuiHostFileReferences` over the composition-supplied Agent lookup, the official provider getter and the Direct Host driver. It owns no Cordis service, no Typert registration and no lifecycle policy (`app/remote/pi-tui-file-reference-host.ts` does), and it lives in `runtime/remote/**` so `app/remote/**` never imports `runtime/direct/**`. |
| `src/app/remote/pi-tui-file-reference-host.ts` | `typert` (the service binding only) | The TS8-HF1 private `piTuiFileReferences` Cordis Host row: service key + wire namespace and the `list` implementation. The Typert CONTRIBUTION is no longer registered here: rc.2 admits exactly ONE contribution per package identity, so the package's single contribution (this descriptor + `piTuiTerminalProgress/watch`) is registered once by the composition (`runtime/remote/pi-tui-remote-contribution.ts`, mounted in `app/remote/host-runtime.ts`), which also owns its lifetime. It resolves the two narrow Host facts (the `agents` registry and the official `fileReferences` provider) through the composition's reflect reads — the same idiom `host-runtime.ts` already uses for its base-service prerequisites — and hands them to the bridge, so no `ctx.get('<Host service>')` coupling enters this file (the boundary baseline is unchanged). |
| `src/runtime/remote/pi-tui-terminal-progress-contract.ts` | (none) | The remote terminal-status private Typert STREAM contract (`piTuiTerminalProgress/watch`, `mode: 'stream'`): ONE handwritten `InvocationDescriptor` both the Host registration and the Client mount derive from, the strict frame codec and the exported structural validator. The rc.2 wire does NOT apply the result codec to stream downlink items, so the validator is the boundary the Client source calls itself. Zero Host-service coupling. |
| `src/runtime/remote/pi-tui-remote-contribution.ts` | (none) | The ONE private Remote contribution of the `@xmoon76/dsh-pi-tui` package. The rc.2 registries key a contribution by package identity (Host `package#face`, Client the package alone) and admit exactly one, so every private invocation this package owns is listed here; each feature keeps its own contract module as the single descriptor source. Zero Host-service coupling. |
| `src/app/remote/terminal-progress-host.ts` | `typert` (the service binding) + the Host events `agent/status`, `session/event`, `agent/disposed` (registered `global: true`, so the row is independent of the mount level) | The Remote terminal-status Host row: it observes the durable turn boundaries and the live Agent status edges in their true synchronous order, fences them by the EXACT live Agent object and the EXACT `agent.session` object (never a same-id string match), classifies them with the SHARED `domain/terminal-progress/interval.ts` fold (one instance per Agent lifetime) and serves ONE per-session snapshot + ordered-update stream carrying `hostEpoch`/`agentEpoch`/`revision`. A replaced Agent opens a new epoch and inherits nothing; a disposal retires a live interval to `idle`, ends the watchers and drops the record; a stalled subscriber fails explicitly. It never writes a terminal byte and never touches the Direct evidence path. The subscription sites are pinned in `test/a5-composition-inventory.test.ts` as the Remote-branch counterpart of the Direct rows. |
| `src/app/remote/terminal-progress-source.ts` | (none) | The Remote terminal-status Client source: structural validation of every frame, per-frame re-check of the Connection generation and the exact retained Session binding, `hostEpoch`/`agentEpoch`/`revision` fencing, and a PER-WATCH snapshot rule: provenance never crosses watches, so every watch's baseline carries only the Host's current `running` truth with `idle` (marked `restart`) and a proven `done`/`error` is only ever delivered by an `update` of the watch that observed its interval. It classifies nothing. Zero Host-service coupling. |
| `src/runtime/session-lifecycle-port.ts` | (none) | The session LIFECYCLE port interface (D2.1/D2.3/D2.4 convergence, alpha.2 ownership escape) — transport-neutral semantic `create`/`open` operations and `SessionHandle` (no Host types). `SessionHandle` carries exactly one backend ownership escape: Direct's `direct` (live Agent + AgentHandle) or Remote's `client` (`ClientSessionOwner`: an exact-binding token plus a `release()` that must run exactly once); `clientOwnerOf()` reads the latter. The Direct runner does not consume `client` yet: Remote stays non-composed until its production composition phase. No `SessionReference` import enters this module. D2.3 removed the ordinary `provider`/`model` inputs from `CreateSessionRequest` and converged `OpenSessionRequest` to `{ sessionId, signal? }` (no `resumeSessionId`/provider/model/preset knobs); `ForkSessionRequest` carries only `sourceSessionId` and optional `atSeq`; seed, child identity, lineage, workspace and model/preset inheritance remain Host-owned. Cancellation is client-local and never serialized. Zero Host coupling. |
| `src/runtime/direct/session-lifecycle-direct.ts` | `agentDefaultModel`, `agents`, `import:dsh-agent`, `import:dsh-session`, `sessionQuery`, `workspaceRegistry` | The Direct `SessionLifecycle` adapter (D2.1/D2.3/D2.4) — the ONLY module converting semantic `create`/`open`/`fork` requests into Direct shapes (preset composition → `setup` callback, `SessionId`, and the official alpha.2 fork mapping: exact `atSeq` cut or `latestCompletedPrefixBoundary` default, seed through the public `@deepseek-ai/dsh-session/fork` `buildForkSeed()`, `inheritedEventCount = boundary + 1`) and mapping the client-local cancellation signal to `agents.create` / `agents.resume`; `agents.resume` is an implementation detail hidden behind semantic `open`. D2.3 moved the Direct-only lookups inside: the activation fallback reads the Host `agentDefaultModel.currentSelection()` (exactly like the official `ApiSessionAgentController.agentOptions()`), and `open` resolves the persisted recorded preset through `recordedSessionPreset`. The runner keeps the process-local surface coordination (transition gate, operation barrier, generation/stale fences) around the port calls; fork dispatch stays outside the destructive transition FIFO, stale Direct children enter a runner-owned park/claim pool, and `open` claims a parked owner before `agents.resume()`. DSH `SessionHandle` / `SessionWriteLease` is the cross-process writer authority. Baseline entries gained `agentDefaultModel` with D2.3 and `sessionQuery`/`workspaceRegistry` with D2.4. |
| `src/runtime/remote/model-remote.ts` | (none) | Experimental M2/D2.3 `ModelCatalog` adapter over the official `session.modelCatalog` / `session.selectModel` Remotes and the Session binding's `modelSelection` projection. Host-free structural inputs, a Connection-generation fence before/after dispatch, and operation-specific settlement (only a proven pre-commit code is `rejected`; no reuse of the D2.2 broad refusal helper). No second global-default write and no custom reasoning normalization. `defaultSelection()` is the CURRENT-generation directory-cache default (invalidated on a reconnect); `sessionSelection()` reads the Client binding's `modelSelection` projection and falls back to that cached default; `listProviders()`/`listModels()` are UNAVAILABLE (empty) in Remote D2.3 — provider-endpoint discovery has no official Remote capability and is never faked from the directory cache (the subagent allowlist that consumes it is a Direct-only surface). |
| `src/runtime/remote/preset-remote.ts` | (none) | Experimental M2/D2.3 `PresetCatalog` adapter over the official `agentPresets.list` roster and `agentPresets.select(sessionId, presetId)` blank-Session write. Host-free structural inputs, generation fence, and operation-specific settlement (`agent-preset/locked` etc. are proven rejections). No local blank reducer or recompose logic. **M3-5 PR5:** `session/writer-held` is an EXACT proven refusal (the pinned Host resolves the Agent before `agentPresets.select` enters its mutation), so it is rejected with the shared `settledWriteMessage()` guidance and its official `details` preserved by `copyFailureDetails()`; an unknown/`gateway/internal` code stays `indeterminate` (no `session/*` namespace widening, and the D2.2 broad classifier is deliberately not used). |
| `src/runtime/remote/session-lifecycle-remote.ts` | (none) | Experimental M2/D2.4 `SessionLifecycle` adapter, aligned to the alpha.2 reference contract: ordinary create via official `ClientSessions.create()` + one explicit `retain`, guaranteed-fresh explicit-preset create via generated `session.create({sessionId, cwd, agentPreset})` + public `refresh()` reconciliation + `retain`, open via `retain()` (`binding()` is borrow-only; there is no Client-global selection verb), and Host-owned fork via exactly one `ClientSessions.fork({sessionId, atSeq?})` with NO retain (publication is independent from navigation adoption, which is the separate `open()` call). A post-publication retain/reconcile failure preserves the published identity as `published-with-error`; fork failures preserve published identity or become indeterminate without retry. No Host imports and no invented Host resume RPC. |
| `src/runtime/remote/session-reference.ts` | (none) | The alpha.2 Client reference-ownership seam — the only place the TUI declares its own `SessionReferenceSourceMap` labels (`tuiMainView`, `tuiOperation`, and M3-5 PR2's `tuiChildView`) through a type-only import of the public `@deepseek-ai/dsh-api-session-controller/client` entry. It owns the three lifetime patterns: `acquireMainSurfaceReference()` (navigation create/open; may materialize a generation and never awaits `ready`), `acquireChildViewReference()` (one subagent child viewer's exact generation, addressed by its durable `SubagentAddress` and never materializing a Host Agent) and `pinExistingGeneration()` (borrow an existing generation first, then retain it with `tuiOperation`, so a plain read/write can never cold-open a Session). Release is exactly once (idempotent). No concrete Client implementation, Host implementation, or runtime import. |
| `src/runtime/interaction-port.ts` | (type-only peer imports) | The interaction port interface (M1.6) — uses the official dsh-user-approval / dsh-user-questions types (declared peers). |
| `src/runtime/direct/interaction-direct.ts` | `approval`, `userQuestions`, `sessionProjections` | The Direct `InteractionPort` adapter (M1.6; M3-3B Question reconvergence) — owns the `userQuestions` / `approval` service access, the `approval/request` subscription, and the `sessionProjections` read that maps the official `userQuestions` + `inbox` durable state (the SAME semantics the Remote adapter maps over the wire); the listeners/providers are registered by the surface owner (`SurfaceRuntime.attachInteraction`). Baseline entries added by the M1.6 relocation (commands.ts and index.ts drop `approval` / `userQuestions`) plus the M3-3B `sessionProjections` read. |
| `src/runtime/direct/catalog-direct.ts` | `llm`, `agentDefaultModel`, `agentPresets`, `tools` (the row also takes a type-only `AgentPreset` from `dsh-agent-preset-registry`; the base-package matchers track neither that package nor this file) | The Direct `Catalog` adapter (M1.8; D2.3 convergence) — owns the model directory (`loadDirectory()` = the official `session.modelCatalog` generation snapshot; `listProviders()`/`listModels()` remain the provider-discovery capability), the Session-local model write (`selectSessionModel()` → `WriteOutcome`, best-effort default save never undoing a committed Session choice), the preset roster + official blank-Session write (`roster()`/`selectSessionPreset()`), and the skill sub-domain's service discovery. Consumers depend on the port DTOs. Baseline entries added by the M1.8 relocation (commands.ts drops `llm`/`agentDefaultModel`/`agentPresets`/`tools` access). |
| `src/runtime/direct/model-selection-direct.ts` | `import:dsh-agent` | The Direct Agent-local model-selection owner (M1.12): installs one selection ref per Agent, folds durable Session intent/request headers, and maps explicit Session selection to the semantic catalog operations; a future Remote adapter replaces this ownership escape with `session.models` / `session.selectModel`. It ALSO owns the Direct-only `DurableModelSelectionReader.durableProjectionForSession(session)`: the exact Session's own latest **used** route in the official `modelSelection` wire shape, consumed ONLY by `session-direct.ts`'s absence-triggered compat read (see that row for the scope and the exit condition). Purely synchronous and read-only: it installs no DSH request listener, appends no event, scans no Session log (no new deprecated reader call site) and never reads the Agent's current choice, the global default or another Session. |
| `src/runtime/direct/config-direct.ts` | `settings`, `credentials`, `authorization`, `permissionPresets`, `commands`, `agentPresets`, `llm` | The Direct `ConfigPort` adapter (M1.9) — owns the Host schema knowledge (the `llm-pi-ai` / `permission` / `agent-presets` settings namespaces), the credential/authorization service access, the credential event wiring, the official `/permission` command line for the `/yolo` switch, and the `llm` directory reads ONLY for the provider-profile target resolution (the keyless-profile write + the merged /login option list). Consumers never name a settings namespace or touch the raw services — the merged /login options cross as the port's `CredentialProviderOption` DTO (semantic flags only: `canProvisionProfile` collapses the namespace/path facts; ONE adapter-owned rule `isKeylessProfileSlot` drives both the flag and the write-time validation, so they can never drift). The authorization contract is an EVENT surface (contract review): the adapter bridges the upstream callback-shaped interaction into detached begin→attemptId→notice/prompt events→respond/cancel — no callback-bearing interaction ever crosses the port (a Remote adapter replays the same events from the wire). Baseline entries added by the M1.9 relocation (commands.ts drops `settings`/`credentials`/`authorization`/`permissionPresets` access; the `/yolo` commands-execute access moves here; index.ts drops `credentials`/`authorization`; the `llm` entry was added with the M1 review round-2 target-resolution fix). |
| `src/domain/media/**` | (none) | TS8-C neutral media vocabulary: media types, durable image/file refs, the deployment image policy, the media failure vocabulary and the image-pipeline byte formatter. Detached structural facts only — no `Context`, Agent, Session, filesystem handle or Host service interface. |
| `src/client/media/**` + `src/client/clipboard/**` + `src/client/url/**` | (none) | TS8-C Client-local capability: image/file draft stores, image and generic-file intake, local file SOURCE streaming (64 KiB, pre/post fingerprint, cancellation, close-on-all-exits), the bounded durable-image byte cache + presentation-scoped loader, the ONE combined draft lifecycle, the clipboard read probes/copy policy and the URL opener. Zero Host/composition import (mechanically gated by `runtime/domain -> client` and `client -/-> runtime/direct|remote`). |
| `src/app/submission/direct-*.ts` | `attachments` (injected structurally), `import:dsh-llm` (type-only `ContentBlock`/`UserMessage`) | TS8-C Direct-path application preparation: `direct-image-admission.ts` (batched `saveImages()` → ordered ContentBlocks), `direct-image-capability.ts` (`resolveModelInfo()` image preflight), `direct-file-admission.ts` (delegates source bytes to the Client streamer and calls the injected Host `saveFileStream`) and `direct-message-preparation.ts` (the Direct `UserMessage` pipeline). No `ctx` resolution: the composition root injects the Host services, and only for the Direct backend. Remote MUST NOT call these. |
| `src/app/submission/submit-flow.ts` | (none) | TS8-C transport-neutral application submission ordering (`reserve` → async `run` → restore-before-release on failure → release in `finally`). It is NOT a `direct-*` module and touches no Host service: both backends' pinned submit paths share this one core. |
| `src/app/submission/prepared-prompt.ts` | (none) | TS8-C application builder of the immutable `PreparedPrompt` snapshot, used by the REMOTE transport preparation path only. Direct keeps its separate `direct-message-preparation.ts` pipeline and does not consume `PreparedPrompt` today. |
| `src/runtime/prepared-prompt.ts` | (none) | TS8-C transport-neutral `PreparedPrompt` contract consumed by `src/runtime/remote/prompt-serializer-remote.ts`; imports only `domain/media/types.ts`. No Client draft-store/placeholder type may enter it. |
| `src/app/command/model-default-intent.ts` | (none) | The pure D2.3 sessionless `/model` default-intent state machine (operation ancestry + settle authority). It uses the structural `ModelSelectionValue` (generic over the caller's selection type) — no `ctx`, no Host services, no I/O, no Host import. |
| `src/domain/status/stats.ts` | `import:dsh-session` | `SessionEvent` type + the `isReplacementSurfaceEvent` replacement fence; the session stats fold/facts (moved from the retired `src/stats.ts` by TS8-D). |
| `src/client/artifact/transcript-markdown.ts` | `import:dsh-session` | `SessionEvent`/`SessionHeader` types + the `isReplacementSurfaceEvent` / `TOOL_NOT_STARTED` event helpers; the Client artifact Markdown formatter (moved out of the `src/transcript.ts` facade by TS8-D), not transport (plan §20). |
| `src/domain/transcript/types.ts` | `import:dsh-session` | Type-only; the canonical session-event identity carriers (`CommandId` / `SessionEventSeq`) relocated by TS7 from `src/transcript.ts`. |
| `src/domain/transcript/folder.ts` | `import:dsh-session` | Session event/window values (`isReplacementSurfaceEvent`, `TOOL_NOT_STARTED`) consumed by the ONE fold; relocated by TS7 from `src/transcript.ts`. |

TS6 reclassified the former `src/runtime/remote/presentation-read-shadow.ts`
row: the D1.3 Direct-vs-Remote presentation comparator is qualification
oracle/tooling, not a runtime product adapter. It compares the SAME semantic
projections the product renders, so once those projections moved into the
backend-neutral `src/tui/transcript/**` core, keeping the comparator under
`src/runtime/**` would have required a `runtime/** -> tui/**` allowlist. It now
lives at `scripts/support/presentation-read-shadow.ts` (consumed by
`scripts/dsh-remote-presentation-parity-smoke.mjs` and
`test/remote-presentation-shadow.test.ts`) and no production `src/**` module
imports it. Remote product architecture is unchanged.

### CLIENT_LOCAL (no Host coupling — keep it that way)

Terminal rendering, editor, keybindings, clipboard/OSC52, input history,
search UI state, picker cursor, overlay state, fullscreen, theme, draft
state, the shell editor mode / gesture parsing / shell card / bounded tail /
fold/copy presentation (execution is Host-owned — see the user-shell SPLIT
below), question/approval *presentation* (the
authority stays Host-owned), and session transition coordination
(`src/app/session/transition-gate.ts`, `src/app/session/transition.ts`,
`src/app/session/operation-barrier.ts` — the process-local single-writer
transition rules; zero Host coupling). Pending-input presentation is
Client-local policy over the semantic projection: the ephemeral steering lane's
`steering…` / `waiting for next turn…` label derives from the subject's
`placement + running` state in `src/tui-app.ts`, and the parked-steering
recovery notice in `src/app/submission/steer.ts` explains the official next-wake path while
performing no Host write. Representative files:
`src/tui-app.ts`, `src/tui/interaction/tui-editor.ts`, `src/tui/theme/runtime.ts`,
`src/tui/transcript/tool-presentation.ts` (rendering half), `src/client/clipboard/copy.ts`, `src/client/history/store.ts`,
`src/tui/interaction/transcript-search.ts`, `src/tui/interaction/overlay-broker.ts`,
`src/extension/internal/keybinding-registry.ts`, `src/extension/internal/editor-registry.ts`,
`src/extension/internal/renderer-registry.ts`.
`src/app/command/artifacts.ts` (the artifact-save owner; the fixed filename helpers were inlined by TS8-F4) carries the Pre-Stage-D export convergence policy — it is
Client-local filename policy with ZERO Host coupling: the archive name
mirrors the upstream `sessionLogZipFilename` convention exactly and is
test-pinned against the upstream function (parity test in
`test/export-command.test.ts`), and the transcript name shares the same
safe full-Session-id convention. `src/client/artifact/save.ts` and
`src/tui/interaction/save-location.ts` are the Client-local temp/atomic-commit
sink and the Save Location UI — zero Host coupling.

### Request-zone metadata (Client-local sample, Host-owned interpretation)

One human prompt's request zone is the sending Client runtime's own IANA zone — a
`CLIENT_LOCAL` sample taken per submit (`src/client/time-zone.ts`, the same
`Intl.DateTimeFormat().resolvedOptions().timeZone` fact the official
`SessionFace.prompt()` samples). It is request metadata: never durable TUI state,
never a Host service read, and never the Host process/fallback zone.

- **Direct ordinary prompt** — `src/app/submission/controller.ts` samples once at
  the send point and `src/app/submission/direct-message-preparation.ts` maps it
  onto the official `UserMessage.source.clientTimeZone` (the official `user-rpc`
  vocabulary) beside the existing `rpcId`; the unidentified Skill/command
  preparation path keeps its plain `{ kind: 'user' }` source.
- **Remote ordinary prompt** — zero TUI-side field: the official
  `SessionFace.prompt()` samples inside the official Client and the Host
  `SessionController` validates it. `RemoteSessionWriter` must keep calling the
  official four-argument `prompt(content, mode, undefined, requestId)`.
- **Continuable child follow-up** — the Viewer composition
  (`src/app/surface/application-events.ts`) provides the per-call
  `clientTimeZone()` capability on `SubagentPromptContext`; the Direct and Remote
  `SubagentPort` adapters sample once immediately before dispatch and put it on
  the official `subagents.prompt` request. The Remote branch resolves no Host
  `ctx.subagents`.

Forbidden substitutions: the Host process zone (or any Host-global fallback zone)
as the human zone; a TUI-owned timezone setting/store; reading the
`time-context` projection; deriving a zone from rendered timestamps or from the
TSP/Tern paint area. An unsamplable or reader-incompatible value refuses the send
before dispatch (draft restored) instead of sending zone-less or fabricated. The
`resolved`/`mixed`/`unavailable` policy, refresh cadence and display fallback stay
Host-owned in the official plugin.

Owning tests: `test/client-time-zone.test.ts`, `test/image-submit.test.ts`,
`test/attachment-submit.test.ts`, `test/request-time-zone.test.ts` (Direct main
source + rendered parity), `test/request-time-zone-child.test.ts` (REAL official
subagent runtime → child durable source), `test/subagent-port.test.ts`,
`test/subagent-viewer-submit.test.ts`, `test/remote-subagent-port.test.ts`,
`test/remote-session-writer.test.ts`, `test/runner-remote-presentation.test.ts`
(Client zone ≠ Host zone over the real Remote route),
`test/runner-viewer-task-integration.test.ts` and
`test/runner-remote-task-center.test.ts` (real child follow-up → Host child
source).

### User shell ownership (shell amendment, M3-4 PR3)

`!` and `!!` are both Host-side user-shell operations; bypass/sandbox are
Host execution policies, not locality choices, and the two gestures differ
only in result routing (`!` submits into Session/model; `!!` stays
presentation-only). The ownership split:

```text
CLIENT_LOCAL:
  shell editor mode
  gesture parsing
  shell card / bounded-tail presentation
  local bounded display cache / temp artifact (labelled Client-owned)

HOST_OWNED:
  user-shell execution
  cwd / workspace
  PATH / environment
  shell discovery
  process lifetime
  process cancellation

SPLIT:
  request/stream/control bridge (HostUserShellPort)
  `!` result handoff into Session (SessionWriter)
```

The application owner (`src/app/submission/user-shell.ts` (renamed by the
PR3 refactor) consumes the narrow `HostUserShellPort` semantic port; it never
owns Client process execution. The Direct adapter is the in-process Host
(bypass spawn and the `ctx.shell` sandbox policy live behind adapter
ownership); the Remote adapter reports the truthful unavailable state because
the rc.2 terminal-controller Remote is a retained interactive PTY carrier and
fails the one-shot qualification (CARRIER_GAP, U11a/U11b open). No row of
this inventory may describe the application submission owner as the owner of
Client process execution.

Clipboard writes are CLIENT_LOCAL and share ONE app-level policy. The
fullscreen drag selection and `/copy` are the same user copy intent and both
call `copyToClipboard()`; it delivers through two INDEPENDENT legs — the
terminal-client OSC 52 sequence and the native/platform compatibility helpers
(`tmux load-buffer`, `pbcopy`, `wl-copy`, `xclip`, `xsel`, `clip`). A helper
success must never suppress the terminal-client leg: on a remote host a helper
that succeeds would otherwise short-circuit the copy and strand the text in the
remote clipboard, which the user cannot paste from. The Direct/Remote backend
mode does not determine clipboard locality (ORCA/xterm.js is remote transport
with a Direct backend). The OSC 52 leg is best-effort by construction (no ACK),
so an emitted sequence is never proof that the user's clipboard changed. No Host
clipboard semantic port or Remote RPC exists for this.

### TEMPORARY_EXCEPTION

| File | Coupling | Why it is allowed |
|---|---|---|
| `src/startup.ts` | (none by design) | Zero-dependency compatibility island; must never import experimental client/runtime code (plan §23). |
| `src/builtins.ts`, `src/extensions.ts` | `ctx.get(TUI_STARTUP_SERVICE)` / `ctx.get(PI_TUI_EXTENSIONS_SERVICE)` | The TUI's own services, not Host services; excluded from the gate patterns. |
| `src/index.ts` (`loader`, `appExit`) | `ctx.get('loader')`, `ctx.get('appExit')` | Cordis/dsh process services with no Host business state; excluded from the gate patterns. |
| `src/app/remote/host-runtime.ts` | (none — `ctx.reflect.get(...)` is not a tracked pattern) | M3-1 experimental Remote Host composition owner (the retired M3-0 entry contract §2.4.1). The earlier `import:dsh-session` baseline entry was removed when the gate matcher was narrowed to exact package matching; the module imports `dsh-session-stats` / `dsh-session-turn-outline` / `dsh-session-log-export` projection plugins, not the Host `dsh-session` type package. |
| `src/app/remote/client-runtime.ts` | (none) | M3-1 experimental Client composition owner (the retired M3-0 entry contract §2.4.2/§2.4.3). The earlier `import:dsh-agent` baseline entry was removed when the gate matcher was narrowed to exact package matching; the import is `dsh-agent-preset-registry/remote` — a Remote contribution, not the Host `dsh-agent` type package. |

The M3-1 composition owners also introduce the first scanned `src/app/remote/**`
coupling of a new kind: they mount official Host plugin rows by plugin object
(the rows' own `inject` declarations carry the service dependencies) and read
service presence through `ctx.reflect.get(...)` for fail-fast diagnostics. This
is Host-side composition sanctioned by the frozen M3-0 contract, not Client-side
business coupling; the M3-4 bootstrap integration owns any future inventory
relocation.

### Permanent Host-plane plugin boundary (2026-10-10)

`src/app/host/**` is the bundle's own HOST plane: a Cordis row that computes a
Host-owned projection over committed Session events and publishes it on the
official seam. Registering a projection there is Host-owned work, NOT a
Client/application surface reaching into a Host service, and it is NOT a
Direct→Remote migration debt item — this boundary is permanent, so it is
deliberately NOT listed under `TEMPORARY_EXCEPTION` above.

`src/app/host/performance-host.ts` registers the bundle's `piTuiPerformance`
unit. It resolves the registry with `ctx.reflect.get('sessionProjections')`
(the same Host-plane reflect read the Remote composition owner above uses)
because a Loader row has no composition owner to hand the service in, and it
declares `inject: ['sessionProjections']` so Cordis, not a lookup, owns the
ordering. The consumer-side rules are what keep this from becoming a second
authority:

| Item | Rule |
|---|---|
| Registration inside `src/app/host/**` | allowed |
| `ctx.reflect.get('sessionProjections')` inside `src/app/host/**` | allowed, only with the two rows below |
| `inject = ['sessionProjections']` on the row | REQUIRED (replaces any lazy lookup) |
| Host ownership row in this file | REQUIRED |
| `src/app/surface/**` or `src/tui/**` reading `sessionProjections` directly | FORBIDDEN |
| Editing `scripts/client-boundary-baseline.json` to absorb new coupling | FORBIDDEN |

The `reflect.get` read is an access-mechanics exception, not an absence of
coupling: the row IS the Host plane, and every Client/application consumer must
still read the resulting values through the semantic DTO / port boundary
(`src/domain/status/performance-view.ts` and, from PR-2 on,
`SessionStatusProjection.performance`).

## Locality rules for new features

Per the AGENTS.md guardrails, every new feature declares its locality before
implementation:

- **Client-local**: terminal rendering, key handling, clipboard, draft state,
  the current draft external editor (`$VISUAL`/`$EDITOR`), Client-local draft
  file/image intake, Client-local artifact output (the save of an exported
  archive/transcript), local UI history, search filter UI state, picker cursor,
  overlay state, fullscreen, TUI theme.
- **Host-owned**: Agent, Session, subagent, jobs, tools, LLM/provider/model,
  skills, agent presets, persistence, session search, approval/question
  authority, workspace, Host filesystem references, Host-side shell/tool
  execution, credentials, settings.
- **Explicitly split** (must define which machine owns each operation):
  `!` / `!!` execution, `@file`, `/open`, `/image` (Client staging + Host durable
  read), `/export` (Host archive read + Client-local save), working directory.
  Remote mode fails closed rather than silently running on the Client
  filesystem with Host semantics. The current draft external editor stays
  Client-local — it edits the draft, not Host workspace files; a future
  Host-filesystem editor/open is a SEPARATE capability that requires an
  authoritative Host seam.

Two UI ownership forms are legal (2026-10-03 clarification):

```text
CLIENT IMPERATIVE UI:
  callbacks/components/renderers/editors/keybindings
  remain Client-local (the existing PiTui extension API).

HOST DECLARATIVE SURFACE:
  Host state/callbacks remain Host-owned;
  only serialized facts/tree/action identity cross an official Remote;
  Client owns rendering and local input presentation.
```

No executable callback/component/renderer/editor object crosses the process
boundary in either form, and neither form creates a current rc.2 capability.

### Direct command compatibility mirror vs Host-origin ownership (M3-4 PR5)

The one command-registry seam where Direct couples to the Host, and the exact
boundary of that coupling:

```text
Direct commands.register(TUI definition)
  = compatibility EXECUTION mirror
  != semantic Host-origin ownership

effective winner's exact registered `definitionId`
  = mirror provenance discriminator

Host-only catalog source
  != display/completion synthesis
```

- A successful Direct Host registration of a TUI definition is a mirror: it
  exists so in-process Host dispatch keeps working, and this surface records the
  exact `definitionId` it stamped on that registration. Host ORIGIN is the
  effective winner view with those stamped mirrors SUBTRACTED; raw registry
  membership is never origin.
- A same-name **Agent-scoped** genuine Host definition SHADOWS the global mirror
  as the complete effective descriptor (official `ScopedLayers` winner rule), so
  it keeps its own identity — including no identity at all — and must not be
  subtracted by name.
- The origin map's inputs are pure Host rows on every path (Host global layer +
  Host-derived scoped overrides on Direct sessionless; the effective
  `commands.list(agent)` view on Direct live; the Host-derived surface snapshot
  on Remote). Client registrations, extension contributions and completion
  synthesis join only the DISPLAY list and the advertised-claim view, and never
  flow back into origin authority.
- `definitionId` is provenance/discovery metadata ONLY — never authorization,
  trust, or a capability grant.

## S4-D1 / PR-D1 — official catalog → fullscreen page source→sink

The Plugin Manager is still ONE authority chain: the real Host
`PluginManager.listBundles()/listPlugins()` (Direct service or generated
Remote face) → the SHARED `detachPluginManagerSnapshot()` mapping →
`app/plugin-manager/classify.ts` (frozen four sections, exact rc.2 B01–B14/base
identity evidence, exact `SELF_BUNDLE`, proven Loader-entry-id extension
association) → `model.ts` (pure section/card/Detail projection) → the ONE
`PluginManagerController` → `PluginManagerWorkspacePanel`. No Web React list,
static 14-item card set, package-scope heuristic or `experimental` substring is
a catalog authority.

- **One controller, one page:** the controller outlives the page and owns only
  the official read/operation lifecycle. The page owns per-open selection,
  search/filter, focus, scroll, painted hit map/revision and view mode.
- **One screen lease:** the direct `/plugins` root and the in-place
  `Settings → Plugins` page use the SAME `TuiApp` workspace Alt-Screen
  primitive (`leaseWorkspaceScreen`). There is no nested Alt Screen, no second
  focus broker and no overlay fallback; the workspace record is a
  `settings | plugin` union, and Settings-only `rereadFacts()/refreshRow()`
  paths are type-guarded.
- **Direct/Remote parity:** both adapters share the mapping; `approvedBuilds`
  is forwarded through `InstallBundleOptions` on both, and the Remote
  generation/invalidation hints remain hints for an authoritative `snapshot()`
  reread (never inventory truth).
- **Qualification boundary:** this PR proves `CATALOG_MANAGEABLE`
  (real rc.2 Host catalog → page → official action → authoritative reread).
  It does NOT claim `HOST_CAPABLE` or `TUI_FEATURE_SUPPORTED` for the 14
  bundles; those remain S4-D2/D3 ledger items.

## How to update this file

1. A migration phase moves coupling into a semantic port: move the entry to
   the port's row, update `scripts/client-boundary-baseline.json` (the gate
   then stops flagging the relocated pattern), and record the phase in
   `docs/client-server-migration.md`.
2. New feature code must NOT appear here — the gate rejects it first.
3. Keep the `HOST_SERVICES` list in `scripts/client-boundary-gate.mjs` in
   sync with this inventory when upstream adds a service the migration must
   isolate.
4. Composition ownership changes follow the row classes above:
   - a semantic coupling move updates the allowlist row and the boundary
     baseline intentionally;
   - a composition-owner change updates this ownership inventory (the frozen
     M3-0 architecture statements were retired by M3-6 PR4);
   - implementation progress alone never changes frozen ownership;
   - a fixture that adds a production prerequisite documents its topology and
     does not automatically grant product composition ownership.
