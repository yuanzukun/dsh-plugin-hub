/**
 * Shared per-step token usage accounting, used by BOTH the session stats
 * fold (footer) and the Focus per-turn token projection. One accounting
 * implementation, so the two surfaces can never drift:
 *
 * - usage is counted ONCE per attempt. An assistant/message or
 *   assistant/attempt settlement replaces that attempt's provisional stream
 *   usage; `llm/retry-started` closes that replacement slot so the next
 *   attempt on the same (turn, step) adds to the total;
 * - a usage fact without a step boundary (replay edge) counts immediately;
 * - the per-turn DISPLAY total is committed completed steps PLUS the open
 *   steps' current usage (provisional or authoritative) — provisional
 *   values are never committed early, so an authoritative replacement
 *   cannot double-count.
 *
 * TS8-D moved this accounting authority out of the legacy root
 * `src/token-usage.ts`. The compact token-count FORMATTER is TUI presentation
 * and lives in `src/tui/token-format.ts`.
 * @module @xmoon76/dsh-pi-tui/domain/transcript/usage
 */

import { expandAssistantStream } from '@deepseek-ai/dsh-llm/assistant-stream'

/** Usage shape the fold accepts (the dsh TokenUsage's accounting fields). */
export interface UsageLike {
  inputTokens: number
  outputTokens: number
  cacheReadTokens?: number
  cacheWriteTokens?: number
}

/** The four token totals of one turn or session. */
export interface TokenUsageTotals {
  inputTokens: number
  outputTokens: number
  cacheReadTokens: number
  cacheWriteTokens: number
}

/** The billed total: uncached input + cache read + cache write + output. */
export function totalTokens(usage: TokenUsageTotals): number {
  return usage.inputTokens
    + usage.outputTokens
    + usage.cacheReadTokens
    + usage.cacheWriteTokens
}

/** A zeroed totals record (the accumulation base). */
function emptyTotals(): TokenUsageTotals {
  return { inputTokens: 0, outputTokens: 0, cacheReadTokens: 0, cacheWriteTokens: 0 }
}

/** Add one usage record into a totals accumulator. */
function addTotals(target: TokenUsageTotals, usage: UsageLike): void {
  target.inputTokens += usage.inputTokens
  target.outputTokens += usage.outputTokens
  target.cacheReadTokens += usage.cacheReadTokens ?? 0
  target.cacheWriteTokens += usage.cacheWriteTokens ?? 0
}

/** Key identifying one step's model output (turn + step). */
function stepKey(turn: number, step: number): string {
  return `${turn}/${step}`
}

/** The turn number encoded in a step key. */
function turnOfKey(key: string): number {
  const slash = key.indexOf('/')
  return slash === -1 ? -1 : Number(key.slice(0, slash))
}

/** The canonical first-token predicate shared by live and durable folds. */
export function isAssistantTokenDelta(chunk: {
  type: string
  text?: string
  argumentsDelta?: string
  name?: unknown
}): boolean {
  switch (chunk.type) {
    case 'text-delta':
    case 'reasoning-delta':
      return chunk.text !== undefined && chunk.text !== ''
    case 'tool-call-delta':
      return (chunk.argumentsDelta ?? '') !== '' || chunk.name !== undefined
    default:
      return false
  }
}

/** The first and last token timestamps embedded in a compact assistant
 * stream (text / reasoning / tool-call deltas — the Web's isTokenDelta).
 * `block-start/end`, `usage`, and `finish` are not tokens. */
export interface AssistantTokenTimeRange {
  first: number
  last: number
}

/** Return the first and last token timestamps embedded in a compact
 * assistant stream, in one pass. Undefined when the stream is missing or
 * carries no token-bearing delta. Older compatible event records may omit
 * the optional stream. */
export function tokenTimeRangeFromAssistantStream(stream: readonly unknown[] | undefined): AssistantTokenTimeRange | undefined {
  if (stream === undefined) return undefined
  let first: number | undefined
  let last: number | undefined
  for (const member of expandAssistantStream(stream as Parameters<typeof expandAssistantStream>[0])) {
    if (isAssistantTokenDelta(member.chunk)) {
      if (first === undefined) first = member.time
      last = member.time
    }
  }
  return first === undefined || last === undefined ? undefined : { first, last }
}

/** Return the first token timestamp embedded in a compact assistant stream. */
export function firstTokenTimeFromAssistantStream(stream: readonly unknown[] | undefined): number | undefined {
  return tokenTimeRangeFromAssistantStream(stream)?.first
}

/** Return the latest provider usage embedded in a compact assistant stream. */
export function usageFromAssistantStream(stream: readonly unknown[] | undefined): UsageLike | undefined {
  if (stream === undefined) return undefined
  let sample: UsageLike | undefined
  for (const member of expandAssistantStream(stream as Parameters<typeof expandAssistantStream>[0])) {
    if (member.chunk.type === 'usage') sample = member.chunk.usage
  }
  return sample
}

/** Resolve the usage committed by one durable assistant settlement. Message
 * records prefer their top-level usage; when it is absent, their embedded
 * stream's final usage is authoritative. Attempt records always use the
 * embedded stream because they have no top-level settlement usage. */
export function usageFromAssistantSettlement(
  kind: 'message' | 'attempt',
  topLevelUsage: UsageLike | undefined,
  stream: readonly unknown[] | undefined,
): UsageLike | undefined {
  return kind === 'message' && topLevelUsage !== undefined
    ? topLevelUsage
    : usageFromAssistantStream(stream)
}

/**
 * Per-step usage accounting shared by the session stats fold and the Focus
 * per-turn token projection. Feed it the same events in the same order and
 * both surfaces read identical totals (the footer's session total is the
 * sum of the per-turn committed totals plus orphan usage — the invariant
 * that keeps `sum(per-turn) ≈ session` strict).
 *
 * Lifecycle: `onStepStart` opens an attempt; `onUsageChunk` records the
 * LATEST streaming usage (the assembler value is cumulative — later chunks
 * replace earlier ones); `onAssistantMessage` or `onAssistantAttempt` commits
 * that attempt's authoritative usage; `onRetryStarted` opens a fresh
 * replacement slot on the same (turn, step). A usage fact with no open step
 * counts immediately (replay edge).
 */
/** One usage fact with its provenance: authoritative (assistant/message)
 * or provisional (streaming chunk). */
interface StepFact {
  usage: UsageLike
  authoritative: boolean
}

export class StepUsageAccumulator {
  /** Open steps: their current usage (undefined = no usage fact yet) and
   * whether an authoritative message settled it. */
  private readonly perStep = new Map<string, { usage?: UsageLike; authoritative?: boolean }>()
  /** Facts WITHOUT an open step per (turn, step) — orphan facts (the step
   * never opened) and closed steps' committed values alike. Each fact
   * carries its provenance: a PROVISIONAL chunk never replaces an
   * AUTHORITATIVE value (the message is the step's final usage; a later
   * chunk is stale), while a message replaces anything and a chunk
   * replaces a provisional value (the latest fact wins — review
   * findings). */
  private readonly settledByStep = new Map<string, StepFact>()
  /** Committed per-turn totals (completed steps + orphan facts). */
  private readonly turnTotals = new Map<number, TokenUsageTotals>()
  /** Open steps' current usage per turn (the running display share). */
  private readonly turnPending = new Map<number, TokenUsageTotals>()
  /** The session-wide total (every committed fact), kept O(1). */
  private readonly session: TokenUsageTotals = emptyTotals()
  /** The highest turn seen so far: when a NEW turn appears, the settled
   * records of all OLDER turns are dropped — their steps are closed and a
   * well-formed log never revisits them, so the map stays bounded by the
   * current turn's steps (review finding). A fact for an older turn's
   * step beyond that (corrupt log) commits as a new fact. */
  private currentTurn = -1

  /** Track the turn boundary: when the turn advances, drop the settled
   * records of older turns, FINALIZE their still-open steps (commit the
   * pending usage — the facts were real) and drop their pending totals,
   * so no open-step state leaks across turn boundaries (review finding).
   * The current turn is remembered so a LATE fact for an older turn
   * (corrupt log) is ignored — never re-counted. */
  private noteTurn(turn: number): void {
    if (turn <= this.currentTurn) return
    if (this.currentTurn >= 0) {
      for (const key of this.settledByStep.keys()) {
        if (turnOfKey(key) < turn) this.settledByStep.delete(key)
      }
      for (const [key, entry] of this.perStep) {
        if (turnOfKey(key) < turn) {
          if (entry.usage !== undefined) {
            addTotals(this.turnTotalFor(turnOfKey(key)), entry.usage)
            addTotals(this.session, entry.usage)
          }
          this.perStep.delete(key)
        }
      }
      for (const pendingTurn of this.turnPending.keys()) {
        if (pendingTurn < turn) this.turnPending.delete(pendingTurn)
      }
    }
    this.currentTurn = turn
  }

  /** Whether a fact for this turn is stale: the turn already advanced past
   * it (a well-formed log is monotonic; a late older-turn fact is a
   * corrupt-log artifact and is ignored entirely). */
  private staleTurn(turn: number): boolean {
    return turn < this.currentTurn
  }

  /** Open one step's accounting. A step that opens AFTER a settled fact of
   * the same (turn, step) (out-of-order replay) reconciles the fact: the
   * premature commit is reversed and the fact becomes the step's pending
   * usage — with its provenance preserved — to be committed once at
   * step/end, never twice (review findings). */
  onStepStart(turn: number, step: number): void {
    this.noteTurn(turn)
    if (this.staleTurn(turn)) return
    const key = stepKey(turn, step)
    // Idempotent: a duplicate step/start keeps the open entry — replacing
    // it would leak the pending usage (review finding).
    if (this.perStep.has(key)) return
    const settled = this.settledByStep.get(key)
    if (settled !== undefined) {
      this.settledByStep.delete(key)
      this.subtractTotals(this.turnTotalFor(turn), settled.usage)
      this.subtractTotals(this.session, settled.usage)
      this.perStep.set(key, { usage: settled.usage, authoritative: settled.authoritative })
      this.addPending(turn, settled.usage)
    } else {
      this.perStep.set(key, {})
    }
  }

  /** Record a streaming usage chunk: the LATEST chunk of an open step
   * replaces the previous one (the assembler value is cumulative — the
   * running display must show the latest provisional usage, plan §13.2),
   * but a provisional chunk NEVER replaces an authoritative value. A
   * chunk without an open step (replay edge) is a settled fact and
   * commits to the turn's totals immediately. */
  onUsageChunk(turn: number, step: number, usage: UsageLike): void {
    this.noteTurn(turn)
    if (this.staleTurn(turn)) return
    const entry = this.perStep.get(stepKey(turn, step))
    if (entry !== undefined) {
      if (entry.authoritative === true) return
      if (entry.usage !== undefined) this.subtractPending(turn, entry.usage)
      entry.usage = usage
      this.addPending(turn, usage)
    } else {
      this.commitSettled(turn, step, { usage, authoritative: false })
    }
  }

  /** The authoritative usage of a settled step replaces the provisional
   * one (never adds to it) — on the open-step path AND the settled path.
   * A message without an open step (replay edge) commits to the turn's
   * totals immediately. */
  onAssistantMessage(turn: number, step: number, usage?: UsageLike): void {
    this.noteTurn(turn)
    if (this.staleTurn(turn)) return
    const entry = this.perStep.get(stepKey(turn, step))
    if (entry !== undefined) {
      if (usage !== undefined) {
        if (entry.usage !== undefined) this.subtractPending(turn, entry.usage)
        entry.usage = usage
        entry.authoritative = true
        this.addPending(turn, usage)
      }
    } else if (usage !== undefined) {
      this.commitSettled(turn, step, { usage, authoritative: true })
    }
  }

  /** Settle a failed attempt from its durable embedded stream. The attempt
   * has no surface message, but its provider usage is still billed. Any live
   * provisional value is replaced by the stream's last usage sample. */
  onAssistantAttempt(turn: number, step: number, usage?: UsageLike): void {
    this.noteTurn(turn)
    if (this.staleTurn(turn)) return
    const key = stepKey(turn, step)
    const entry = this.perStep.get(key)
    if (entry !== undefined) {
      // A usage-less late failed-attempt record must not erase an
      // authoritative assistant/message value already held for this step.
      if (usage === undefined && entry.authoritative === true) return
      if (entry.usage !== undefined) this.subtractPending(turn, entry.usage)
      this.perStep.delete(key)
    }
    if (usage !== undefined) this.commitSettled(turn, step, { usage, authoritative: true })
  }

  /** Close the current replacement slot before a retry opens the same
   * (turn, step) again. The settled attempt remains in the totals; removing
   * only the replacement record makes the retried attempt add rather than
   * replace it. */
  onRetryStarted(turn: number, step: number): void {
    this.noteTurn(turn)
    if (this.staleTurn(turn)) return
    const key = stepKey(turn, step)
    const entry = this.perStep.get(key)
    if (entry !== undefined) {
      if (entry.usage !== undefined) this.subtractPending(turn, entry.usage)
      this.perStep.delete(key)
    }
    this.settledByStep.delete(key)
    this.perStep.set(key, {})
  }

  /** Advance the turn boundary: finalize the prior turn's still-open
   * steps and make its delayed facts stale. Called by the folds at
   * turn/start — a delayed usage event for the prior turn must not
   * replace its pending usage after the next turn started (review
   * finding). */
  onTurnStart(turn: number): void {
    this.noteTurn(turn)
  }

  /** Finalize a turn: commit its still-open steps' pending usage (the
   * facts were real) and drop the pending totals, so the Focus per-turn
   * total and the session total agree even when turn/end arrives with
   * open steps (review finding). Idempotent — a second call finds no open
   * steps. */
  onTurnEnd(turn: number): void {
    for (const [key, entry] of this.perStep) {
      if (turnOfKey(key) === turn && entry.usage !== undefined) {
        addTotals(this.turnTotalFor(turn), entry.usage)
        addTotals(this.session, entry.usage)
        this.perStep.delete(key)
      }
    }
    this.turnPending.delete(turn)
  }

  /** Commit one step's usage (once) and drop its open state. The step's
   * final fact stays in {@link settledByStep} (with its provenance) so a
   * late fact replaces or is ignored correctly; a step that never opened
   * keeps its settled fact unchanged. */
  onStepEnd(turn: number, step: number): void {
    this.noteTurn(turn)
    if (this.staleTurn(turn)) return
    const key = stepKey(turn, step)
    const entry = this.perStep.get(key)
    if (entry !== undefined) {
      if (entry.usage !== undefined) {
        this.subtractPending(turn, entry.usage)
        addTotals(this.turnTotalFor(turn), entry.usage)
        addTotals(this.session, entry.usage)
        this.settledByStep.set(key, { usage: entry.usage, authoritative: entry.authoritative === true })
      }
      this.perStep.delete(key)
    }
  }

  /** Discard an OPEN attempt's provisional accounting WITHOUT committing it
   * when the live stream is abandoned and has no durable settlement. A
   * durable `assistant/attempt` must use {@link onAssistantAttempt} instead,
   * because its embedded stream carries real provider usage. An authoritative
   * value (a durable `assistant/message` already settled the step) and a
   * committed fact are never discarded — the durable log owns them. */
  discardStep(turn: number, step: number): void {
    if (this.staleTurn(turn)) return
    const key = stepKey(turn, step)
    const entry = this.perStep.get(key)
    if (entry === undefined || entry.authoritative === true) return
    if (entry.usage !== undefined) this.subtractPending(turn, entry.usage)
    this.perStep.delete(key)
  }

  /** The committed per-turn totals (completed steps + orphan facts);
   * undefined when the turn has no committed usage fact. */
  turnUsage(turn: number): TokenUsageTotals | undefined {
    return this.turnTotals.get(turn)
  }

  /** The per-turn DISPLAY totals: committed steps plus the open steps'
   * current usage (provisional or authoritative) — never double-counted.
   * Undefined when the turn has no usage fact at all (the header then
   * hides the token segment instead of showing `0 tok`). */
  turnUsageWithPending(turn: number): TokenUsageTotals | undefined {
    const committed = this.turnTotals.get(turn)
    const pending = this.turnPending.get(turn)
    if (committed === undefined && pending === undefined) return undefined
    const totals = emptyTotals()
    if (committed !== undefined) addTotals(totals, committed)
    if (pending !== undefined) addTotals(totals, pending)
    return totals
  }

  /** The session-wide totals (every committed fact — the sum of the
   * per-turn committed totals by construction, so the footer and the
   * Focus per-turn projection can never drift). */
  sessionTotals(): TokenUsageTotals {
    return { ...this.session }
  }

  private turnTotalFor(turn: number): TokenUsageTotals {
    let totals = this.turnTotals.get(turn)
    if (totals === undefined) {
      totals = emptyTotals()
      this.turnTotals.set(turn, totals)
    }
    return totals
  }

  private addPending(turn: number, usage: UsageLike): void {
    let pending = this.turnPending.get(turn)
    if (pending === undefined) {
      pending = emptyTotals()
      this.turnPending.set(turn, pending)
    }
    addTotals(pending, usage)
  }

  private subtractPending(turn: number, usage: UsageLike): void {
    const pending = this.turnPending.get(turn)
    if (pending === undefined) return
    pending.inputTokens -= usage.inputTokens
    pending.outputTokens -= usage.outputTokens
    pending.cacheReadTokens -= usage.cacheReadTokens ?? 0
    pending.cacheWriteTokens -= usage.cacheWriteTokens ?? 0
    // A fully drained pending bucket is dropped so a turn with NO open
    // usage reads as absent (never a fake `0 tok` segment).
    if (pending.inputTokens === 0 && pending.outputTokens === 0 && pending.cacheReadTokens === 0 && pending.cacheWriteTokens === 0) {
      this.turnPending.delete(turn)
    }
  }

  /** A usage fact without an open step (replay edge) is a settled fact:
   * commit it to the turn's totals immediately, so
   * sum(per-turn committed) == session total stays strict. The latest
   * fact REPLACES the previous one of the same (turn, step) — the same
   * replace-never-add rule as the open-step path — EXCEPT a provisional
   * chunk never replaces an authoritative value (the message is the
   * step's final usage; the chunk is stale and is ignored entirely, so
   * the step is never double-counted). */
  private commitSettled(turn: number, step: number, fact: StepFact): void {
    const key = stepKey(turn, step)
    const existing = this.settledByStep.get(key)
    if (existing !== undefined) {
      if (existing.authoritative && !fact.authoritative) return
      this.subtractTotals(this.turnTotalFor(turn), existing.usage)
      this.subtractTotals(this.session, existing.usage)
    }
    this.settledByStep.set(key, fact)
    addTotals(this.turnTotalFor(turn), fact.usage)
    addTotals(this.session, fact.usage)
  }

  /** Subtract one usage record from a totals accumulator. */
  private subtractTotals(target: TokenUsageTotals, usage: UsageLike): void {
    target.inputTokens -= usage.inputTokens
    target.outputTokens -= usage.outputTokens
    target.cacheReadTokens -= usage.cacheReadTokens ?? 0
    target.cacheWriteTokens -= usage.cacheWriteTokens ?? 0
  }
}
