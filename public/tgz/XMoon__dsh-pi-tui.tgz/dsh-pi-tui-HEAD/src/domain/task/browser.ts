/**
 * Task-browser row model — the merged view over the SELECTED semantic Task
 * sources (M3-5 PR2):
 *  A. the root Job roster feed (the selected roster capability
 *     `TaskSurfaceSource.jobs`, a `TaskSurfaceJobs`), and
 *  B. the selected Task read's descendant subagent catalog
 *     (`TaskSurfaceRead.readTask`, the full tree).
 *
 * The selection is transport-neutral. Direct maps the roster to the Host
 * JobRegistry (`ctx.jobs`) and the tree to `ctx.subagents.listDescendants`,
 * with live activity from `ctx.agents`; Remote maps the roster to the official
 * Client Jobs service (`remoteSources.task.jobs()`, a retained `watchRows`),
 * the tree to the official descendant projections, and live activity to the
 * official Client Session-list running fact. The model never learns which
 * backend produced the rows.
 *
 * Since DSH 0.1.7 the JobRegistry is NOT a background-only roster: the
 * foreground `bash`/`pwsh` wait path temporarily registers the work while
 * it is observable/stoppable, a foreground completion may `remove()` the
 * record (the model never saw the id), and an explicit
 * `run_in_background` / promoted job is handed out and its terminal
 * record stays listed until an owner removes/disposes it. The TUI only
 * consumes `JobView` — it has no handed-out/provisional bit and NEVER
 * guesses provenance (kind/tool args/transcript/timing); row membership
 * simply follows the selected roster source on every commit. A job row is STATUS-ONLY:
 *  - a shell job's output has a single read cursor owned by the model's
 *    `job_output`; consuming it from the UI would swallow the main
 *    session's result;
 *  - a `subagent`-kind job record is the registry's reliable contract for
 *    a background ONE-SHOT subagent job, but it carries no child session
 *    id, so it can never be matched to its child transcript — label/
 *    order/time are never identity (see subagentJobTranscriptId).
 *
 * Source B — the selected descendant catalog: the durable child tree. Every row —
 * continuable AND one-shot, running AND inactive — is a viewable row: the
 * catalog `activity` is live-store PRESENCE, never an outcome, and a
 * finished one-shot child stays reachable through its persisted
 * transcript (plan §6.4). Rows keep the DSH stable pre-order VERBATIM
 * (plan §6.5): the tree structure comes from `parentId` + `depth`, so no
 * running-first re-sort may ever break the lineage.
 *
 * Runtime activity is NOT a catalog fact: the UI projects each child's
 * `running` / `inactive` word at COMMIT time from the selected `activityOf`
 * read (Direct: the live Agent registry `ctx.agents.get(id)?.status`; Remote:
 * the official Client Session-list running fact — see
 * {@link projectSubagentActivity}). The catalog's store-presence
 * `activity` must never reach a row or the badge as the execution state:
 * an idle continuable child stays live in the session store and would
 * otherwise read as `running` forever.
 *
 * Deliberate overlap: a running BACKGROUND one-shot has BOTH a job record
 * and a child record with no cross-reference, so it may appear twice — the
 * job row (status-only) and the child row (transcript viewable). Dedup is
 * impossible without the missing childSessionId on the job record; the
 * viewable child row is strictly more useful, so the overlap is accepted.
 *
 * Pure and injectable so row typing, ordering, tree prefixes, and
 * descriptions are unit-testable without any dsh service.
 * @module @xmoon76/dsh-pi-tui/domain/task/browser
 */

import type { WorkflowRunStatus } from '../transcript/workflow-projection.ts'

/** Picker-value prefix for a subagent row. */
export const AGENT_ROW_PREFIX = 'agent:'
/** Picker-value prefix for a job row. */
export const JOB_ROW_PREFIX = 'job:'
/** Structural job input (a projection of dsh's JobSnapshot). */
export interface TaskBrowserJobInput {
  readonly id: string
  readonly kind: string
  readonly label: string
  readonly status: string
  readonly detail?: string
  readonly startedAt: number
  readonly finishedAt?: number
}

/** Structural subagent-list entry (a projection of dsh's
 * SubagentDescendantListEntry). parentId/depth are the CATALOG'S OWN
 * facts (plan §6.3) — never guessed from labels or order. The `activity`
 * field may carry the catalog's store-presence value on INPUT, but the
 * caller MUST overwrite it with the selected live activity projection
 * (`activityOf`) before the entry becomes a row (see
 * {@link projectSubagentActivity}) — a row's `running`/`inactive` means
 * "the selected source reports a live driver right now". */
export interface TaskBrowserAgentInput {
  readonly kind: 'child' | 'diagnostic'
  readonly id: string
  /** Absent for a one-shot child; continuable children always carry one. */
  readonly label?: string
  /**
   * The official durable classification. `external` (0.2.1-rc.1 catalog v2) records
   * an external provider execution with no local child Session: it is carried
   * through the read ports but the classification guard below keeps it out of
   * the browsable rows, because this surface owns no external-child viewer.
   */
  readonly mode?: 'one-shot' | 'continuable' | 'external'
  /** UI-PROJECTED runtime activity of the child's driver
   * (`running` = the selected activity source reports a live driver right
   * now; `inactive` = no live driver — idle, cold, or disposed, never
   * completed/failed/terminal). Never interpret the catalog's
   * store-presence value as execution state. */
  readonly activity?: 'running' | 'inactive'
  readonly hasChildren?: boolean
  /** Durable direct parent (descendant rows; absent for direct children
   * of the requested root — the root is then the implicit parent). */
  readonly parentId?: string
  /** Edge distance from the requested root; direct children are `1`. */
  readonly depth?: number
  /** Diagnostic rows carry the fold reason instead of identity facts. */
  readonly reason?: 'corrupt' | 'unsupported' | 'unavailable'
}

/** One task-browser row. The value is the picker row id. */
export type TaskBrowserRow =
  | {
      readonly kind: 'job'
      readonly value: string
      readonly jobId: string
      readonly jobKind: string
      readonly label: string
      readonly status: string
      readonly detail?: string
      readonly startedAt: number
      readonly finishedAt?: number
      /** Runtime-owned unacknowledged failure attention marker. */
      readonly attention?: boolean
    }
  | {
      /**
       * An rc.2 catalog v2 `mode: 'external'` leaf: a real child identity the
       * parent catalog carries, with NO local child Session. It is VISIBLE and
       * never openable/continuable here (S2-B1 §4A.1), so it is its own kind
       * instead of a `subagent` row whose mode would have to lie.
       */
      readonly kind: 'external'
      readonly value: string
      readonly childId: string
      readonly label: string
      readonly mode: 'external'
      /** Catalog label facts for the shared row decorations. */
      readonly hasChildren: false
      readonly parentId: string
      readonly depth: number
    }
  | {
      readonly kind: 'subagent'
      readonly value: string
      readonly childId: string
      readonly label: string
      /** The catalog's classification — NEVER derived from activity: a
       * running child is not necessarily continuable and an inactive one
       * is not necessarily one-shot. The viewer's interactivity and the
       * follow-up write path both key off this exact field. */
      readonly mode: 'one-shot' | 'continuable'
      /** UI-PROJECTED runtime activity (see {@link projectSubagentActivity}):
       * `running` = the child's Agent driver is executing right now;
       * `inactive` = no live driver (idle/cold/disposed) — never
       * completed/failed. The catalog's store-presence value never
       * reaches a row. */
      readonly activity: 'running' | 'inactive'
      readonly hasChildren: boolean
      /** Durable direct parent ('' for a direct child — the browser's
       * root is the implicit parent). */
      readonly parentId: string
      /** Edge distance from the requested root; direct children are 1. */
      readonly depth: number
    }

const isActiveJob = (status: string): boolean => status === 'running' || status === 'stopping'

/** Whether a job status is ACTIVE (running/stopping) — the preferred-row
 * rule's job half (plan §6.6). */
export function isActiveJobStatus(status: string): boolean {
  return isActiveJob(status)
}

/**
 * Build the merged browser rows.
 *
 * SUBAGENT rows keep the catalog's stable pre-order VERBATIM (plan §6.5):
 * the descendant listing IS the tree, so rows are NEVER re-sorted by
 * activity — a running grandchild must not jump above its inactive
 * parent. Every healthy child (kind 'child' with a classified mode) is a
 * row: the finished one-shot filter is REMOVED (plan §6.4), because the
 * projected activity is runtime-only, never an outcome — a settled
 * one-shot's persisted transcript stays viewable.
 *
 * JOB rows keep their own registry ordering (active by startedAt,
 * terminal newest-finish first) as a separate flat group after the tree —
 * job status is never fused into subagent lineage (plan §2.2).
 */
export function buildTaskRows(
  jobs: readonly TaskBrowserJobInput[],
  agents: readonly TaskBrowserAgentInput[],
): TaskBrowserRow[] {
  // Child rows: every healthy classified child — continuable AND one-shot,
  // running AND inactive (a settled one-shot's persisted transcript is
  // still viewable, plan §6.3). The filter is a TYPE GUARD on mode: an
  // entry whose mode is missing or unclassified (`unknown`) is dropped like
  // a diagnostic (never silently defaulted to continuable), while an
  // `external` leaf is carried as its OWN row kind — visible with its
  // durable classification and never openable/continuable, because it has
  // no local child Session (S2-B1 §4A.1).
  type AgentRow = Extract<TaskBrowserRow, { kind: 'subagent' }>
  // Child rows in ONE catalog-order pass: a healthy classified local child
  // (continuable / one-shot) is a browsable row, and an rc.2 catalog v2
  // `mode: 'external'` leaf is carried as its own VISIBLE kind — it has no
  // local child Session, so it is never openable or continuable here
  // (S2-B1 §4A.1).
  const childRows: TaskBrowserRow[] = []
  for (const entry of agents) {
    if (entry.kind !== 'child') continue
    if (entry.mode === 'external') {
      childRows.push({
        kind: 'external',
        value: `${AGENT_ROW_PREFIX}${entry.id}`,
        childId: entry.id,
        label: entry.label ?? entry.id,
        mode: 'external',
        hasChildren: false,
        parentId: entry.parentId ?? '',
        depth: entry.depth ?? 1,
      })
      continue
    }
    if (entry.mode !== 'continuable' && entry.mode !== 'one-shot') continue
    childRows.push({
      kind: 'subagent',
      value: `${AGENT_ROW_PREFIX}${entry.id}`,
      childId: entry.id,
      label: entry.label ?? entry.id,
      mode: entry.mode,
      activity: entry.activity ?? 'inactive',
      hasChildren: entry.hasChildren ?? false,
      parentId: entry.parentId ?? '',
      depth: entry.depth ?? 1,
    })
  }
  // The tree order is the catalog order: no running-first re-sort.
  const sortedJobs = [...jobs].sort((a, b) => {
    const aTerminal = !isActiveJob(a.status)
    const bTerminal = !isActiveJob(b.status)
    if (aTerminal !== bTerminal) return aTerminal ? 1 : -1
    if (!aTerminal) return a.startedAt - b.startedAt
    return (b.finishedAt ?? b.startedAt) - (a.finishedAt ?? a.startedAt)
  }).map(job => ({
    kind: 'job' as const,
    value: `${JOB_ROW_PREFIX}${job.id}`,
    jobId: job.id,
    jobKind: job.kind,
    label: job.label,
    status: job.status,
    detail: job.detail,
    startedAt: job.startedAt,
    finishedAt: job.finishedAt,
  }))
  return [...childRows, ...sortedJobs]
}

/**
 * Project the UI runtime activity of one descendant catalog onto its
 * entries: a child's `activity` is overwritten from the selected live
 * activity read (`agentStatusOf(id)` — Direct: the live Agent registry;
 * Remote: the official Client Session-list running fact), read AT COMMIT
 * TIME — never captured when the (async) listing started. A slow catalog
 * response must not flip an already-idle child back to `running` with
 * the store-presence status it captured earlier (plan §7.3).
 *
 * EVERYTHING else is untouched: id/label/mode/hasChildren/parentId/depth
 * and the pre-order all stay catalog facts (plan §7.5). Diagnostic rows
 * pass through unchanged.
 */
export function projectSubagentActivity(
  entries: readonly TaskBrowserAgentInput[],
  agentStatusOf: (childId: string) => string | undefined,
): TaskBrowserAgentInput[] {
  return entries.map(entry =>
    entry.kind === 'child'
      ? { ...entry, activity: agentStatusOf(entry.id) === 'running' ? 'running' : 'inactive' }
      : entry)
}

/** Whether a subagent row can be interrupted RIGHT NOW: only a
 * continuable child with a LIVE running driver — an idle/inactive
 * continuable has no driver to stop, so the UI must not advertise (or
 * fire) the stop verb for it. One-shot rows are never interruptible (the
 * interrupt transport is an accepted no-op for them). */
export function isSubagentRowInterruptible(
  row: Extract<TaskBrowserRow, { kind: 'subagent' }>,
): boolean {
  return row.mode === 'continuable' && row.activity === 'running'
}

/** The viewer's interaction authority for one row (plan §6.10): mode is
 * the DURABLE semantic, access is the CURRENT surface authority. A direct
 * (depth 1) continuable child is interactive from the root; every other
 * row is read-only from this surface — nested descendants belong to their
 * exact parent, never to the root (plan §2.4). */
export type ViewerAccess =
  | 'interactive-direct-child'
  | 'readonly-one-shot'
  | 'readonly-nested'

/** Classify a subagent row's viewer authority from the row's own facts
 * (mode + depth — never activity). */
export function viewerAccessOf(row: Extract<TaskBrowserRow, { kind: 'subagent' }>): ViewerAccess {
  if (row.depth > 1) return 'readonly-nested'
  if (row.mode === 'one-shot') return 'readonly-one-shot'
  return 'interactive-direct-child'
}

/** Resolve a viewer target's authority, deriving the DEFAULT from the
 * mode when the caller did not pass one (a plain depth-1 viewer): a
 * continuable child is interactive, a one-shot child is read-only. A
 * caller that KNOWS the row is nested passes `readonly-nested` explicitly
 * (the mode alone cannot express it). */
export function resolveViewerAccess(
  mode: 'one-shot' | 'continuable',
  access: ViewerAccess | undefined,
): ViewerAccess {
  if (access !== undefined) return access
  return mode === 'continuable' ? 'interactive-direct-child' : 'readonly-one-shot'
}

/** Whether an access permits drafting a follow-up to the child (only the
 * interactive direct child does, plan §6.10). */
export function isViewerAccessInteractive(access: ViewerAccess): boolean {
  return access === 'interactive-direct-child'
}

/** The interrupt authority for one subagent row (review P1): DSH's
 * `{ kind: 'user', parentSessionId }` contract requires the child's
 * DURABLE DIRECT parent — a deep descendant passed with the main session
 * id is rejected as unauthorized. The row's own parentId is the durable
 * address the tree already carries; a direct child (no parentId) falls
 * back to the browser root (the live main session). */
export function subagentInterruptParent(
  row: Extract<TaskBrowserRow, { kind: 'subagent' }>,
  rootSessionId: string,
): string {
  return row.parentId !== '' ? row.parentId : rootSessionId
}

/** The direct-navigation authority for one Workflow member row (PR2 plan
 * §9.2/§14.6): the SINGLE resolver both the Workflow card action and its
 * tests use — the 5 authority conditions are never copied twice. The
 * member must still be RUNNING (the model-side fact), the catalog row
 * must exist and be a subagent, the child must be a DIRECT child of the
 * current root session (depth 1 + exact durable parent), and the child's
 * Agent driver must be running right now. Returns the viewer-open facts
 * (the same shape `enterView` consumes) or undefined when any condition
 * fails — a terminal member, a missing catalog row, a wrong parent or a
 * nested child never cold-opens from the Workflow card (plan §9.4/§9.5). */
export function workflowMemberViewerTarget(
  member: { readonly status: WorkflowRunStatus; readonly childId: string },
  row: TaskBrowserRow | undefined,
  rootSessionId: string,
): { parentSessionId: string; childSessionId: string; label: string; mode: 'one-shot' | 'continuable'; activity: 'running' | 'inactive'; depth: number } | undefined {
  if (member.status !== 'running') return undefined
  if (row === undefined || row.kind !== 'subagent') return undefined
  // The row must BE the member's row: a mismatched row would combine one
  // child's label/mode/parent with another child's identity (review
  // finding). Workflow `agent()` children are one-shot by contract (plan
  // §2.6/§9.3) — a continuable catalog row is never a Workflow member
  // target, so the viewer can never accidentally grant an interactive
  // continuable editor.
  if (row.childId !== member.childId) return undefined
  if (row.mode !== 'one-shot') return undefined
  if (row.activity !== 'running') return undefined
  if (row.depth !== 1) return undefined
  const parentSessionId = row.parentId !== '' ? row.parentId : rootSessionId
  if (parentSessionId !== rootSessionId) return undefined
  return {
    parentSessionId,
    childSessionId: member.childId,
    label: row.label,
    mode: row.mode,
    activity: row.activity,
    depth: row.depth,
  }
}
