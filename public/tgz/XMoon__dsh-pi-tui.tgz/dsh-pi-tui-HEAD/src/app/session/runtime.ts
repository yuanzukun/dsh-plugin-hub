/**
 * The BOUND session runtime (A2 plan §1.1 phase 3): the session layer's session
 * orchestration. It owns the RETIREMENT COORDINATION (§4.1), the ORDINARY
 * TRANSITION/switch (§4A), the FORK ADOPTION (§4B), the FIRST-SESSION COMMIT
 * (§4C), the STARTUP-RESUME PUBLICATION (§4D) and the COMMAND SETTLEMENT (§3.5).
 * The read authority is the ownership core (`app/session/ownership-core.ts`),
 * which the runner may consult directly.
 *
 * Every backend or Host operation arrives as a consumer-owned port
 * (`SessionOwnerAccess`, `SessionOwnerRetirement`) or a runner-supplied surface
 * hook, so this module never sees an `Agent`, an `AgentHandle` or a Direct
 * module.
 * @module @xmoon76/dsh-pi-tui/app/session/runtime
 */

import type { Diag } from '../../runtime/process/diagnostics.ts'
import { observeSettled, runOwned } from '../../runtime/process/tasks.ts'
import { safeErrorMessage } from '../../runtime/process/errors.ts'
import type { WriteOutcome } from '../../runtime/session-writer-port.ts'
import {
  LifecycleError,
  requireCreated,
  requireOpened,
  WorkspaceSelectionError,
  type ResolvedWorkspaceSelection,
  type SessionHandle,
  type SessionLifecycle,
  type WorkspaceSelectionIntent,
} from '../../runtime/session-lifecycle-port.ts'
import { isRewindIdentityCurrent, type RewindNavigationIdentity } from './navigation-identity.ts'
import { runFirstSessionCommit, runForkCommit, runOrdinaryCommit, runResumeCommit } from './commit-order.ts'
import type {
  NavigationStopReceipt,
  SessionOwnerAccess,
  SessionOwnerRetirement,
  SessionRetirementReport,
} from './owner-access.ts'
import type { ForkSourcePin, SessionOwnershipCore } from './ownership-core.ts'
import { SessionScopeSupersededError, type LiveSessionScope, type SessionScope } from './scope.ts'
import type { SessionOwnerRef } from './subject.ts'
import {
  runTransitionTo,
  SessionNavigationStopError,
  type NavigationAdmission,
  type NavigationIntent,
  type NavigationStopFailure,
  type TransitionOutcome,
  type TransitionSteps,
} from './transition.ts'

/** The runner-supplied surface operations the runtime drives. */
export interface SessionRuntimeSurface {
  /** ALL user-facing retirement reporting stays with the runner (it owns the
   *  terminal writer); the runtime calls this ONCE with the MERGED report
   *  (current owner + every parked owner). */
  warnRetirement(report: SessionRetirementReport): void
  /** The coordinator-level warning: the gate/barrier guard skipped a retirement
   *  that would have raced an active transition (no backend phase ran). */
  warnRetirementSkipped(reason: string): void
  /** Whether the surface is already disposed (`cleanedUp`). */
  isSurfaceDisposed(): boolean
  /** The opening-session journal (opaque token; the runner owns the journal). */
  beginOpening(sessionId: string): unknown
  clearOpening(token: unknown): void
  // The commit seams the ordinary transition drives.
  settlePendingQueueRecalls(committed: boolean): void
  settleLocalSubmitAck(reason: string): void
  resetSubmitLatency(): void
  setCompletionOwner(identity: string | undefined): void
  // Post-commit surface work. These receive the opaque owner; the runner
  // resolves its own Direct attachment inside the provider.
  initLiveSession(owner: SessionOwnerRef): Promise<void>
  refreshLiveCatalog(owner: SessionOwnerRef): Promise<void>
  /** Report a committed switch (the runner logs it and adds its own Direct
   *  session detail). */
  reportSwitch(from: string | undefined, to: SessionOwnerRef): void
  /** Drop the unpinned per-session drafts after a committed switch/fork. */
  clearUnpinnedDrafts(): void
  /**
   * PR3-B §7.3 (the B2 external-review F1): drop the ACTIVE editor draft at
   * a COMMITTED cross-owner switch. Called ONLY at the two sites that have
   * already proven the publication (the ordinary switch's and the fork
   * adoption's post-commit phases) — never at the generation reset (an
   * invalidation signal the first-session creation and a pre-publication
   * failure also produce) and never for a same-session resume. The surface
   * implementation routes to the display seam (the PiTui adapter keeps its
   * own retention contract).
   */
  dropOutgoingActiveDraft(): void
  /**
   * PR3-B B3 (external review P2-B): withdraw the REPLACED subject's live
   * interaction presentation at the SAME synchronous publication commit. The
   * commit section is state-only and must not throw, so the implementation
   * performs no Host read and routes any renderer frame failure to that
   * renderer's fatal sink. Called immediately after `setCurrentOwner`, before any
   * post-commit await.
   */
  withdrawReplacedPresentation(): void
  /**
   * Open the editor-recall scope of the owner this commit section is about to
   * publish (or create): the owner's hydration reseeds ↕ recall from its
   * session-scoped JSONL rows, while a submission accepted in the
   * publication→hydration gap has its own append ordered behind the transition
   * (the submit FIFO turn and `ensureSession()`), so the row can land after
   * that read. The seam starts the scope-bound temporary submissions so the
   * reseed reconciles them instead of dropping them, drops the previous
   * owner's entries with them, and ADOPTS the sessionless pool's entries for
   * the first Session. State-only and synchronous: called INSIDE the commit
   * section, right after `setCurrentOwner`, before any post-commit await.
   * @param owner - the published Session's id.
   */
  beginInputHistoryScope(owner: string): void
  /**
   * Phase 3B / B3-B: physically close a mounted History editor-seat tenant whose
   * captured Session scope is no longer current. Called at the SAME synchronous
   * publication commit, right after `beginInputHistoryScope`, and from the
   * ownership core's generation-reset hook. The implementation is state-only and
   * non-throwing: it never lets a UI cleanup failure roll back or mask the
   * already-published Session.
   */
  retireStaleHistorySeat(): void
  /** Report a failed switch (the runner owns the logger + diagnostics). */
  reportSwitchFailure(sessionId: string, message: string): void
  /**
   * The committed child's post-commit durability checkpoint failed: the
   * switch DID commit (never report a failed transition), but the new
   * session's persisted boundary could not be confirmed. The runner turns
   * this into a clear error notice + diagnostic with the session id.
   */
  warnCommittedDurability(sessionId: string, error: string): void
  // First-session (deferred creation) runner operations.
  /** Build the launch composition for the first session. */
  launchComposition(): Promise<{ failure?: string; composition: { agentPreset?: string } }>
  /** Record a first-session failure for the next resume notice. */
  setResumeFailure(failure: string): void
  /** Report a failed first-session create (the runner logs + records it). */
  reportFirstSessionCreateFailure(message: string): void
  /** Show (and clear) the pending resume notice. */
  notifyResumeFailure(): void
  /** Quiesce every sessionless `/model` default write before the create. */
  awaitPendingDefaultWrite(signal: AbortSignal): Promise<void>
  /** Generate the first session's id (the runner owns the Host id type). */
  newSessionId(): string
  /** The CLIENT-LOCAL workspace intent the first-session create pre-selects
   *  through the Host. The Client's launch directory is only a proposal: the
   *  Host Workspace registry decides the durable Session directory. */
  initialWorkspaceIntent(): WorkspaceSelectionIntent
  /** The current opening-journal token (opaque to the session layer). */
  currentOpening(): unknown
  /** Reset the whole opening journal (the first-session finally). */
  resetOpening(): void
}

export interface SessionRuntimeDeps {
  /** The opaque owner mapping (backend-side). */
  readonly owners: SessionOwnerAccess
  /** The owner retirement port (backend-side implementation). */
  readonly retirement: SessionOwnerRetirement
  /** The session lifecycle port (open/create/fork). */
  readonly lifecycle: SessionLifecycle
  /** The runner lifecycle abort signal (the quiesces observe it). */
  readonly lifecycleSignal: AbortSignal
  readonly surface: SessionRuntimeSurface
  /** Synchronous scope-currentness read (the runner's scope authority). */
  isScopeCurrent(scope: SessionScope): boolean
  /** ONE synchronous scope capture over the same authority (a navigation
   *  intent pins the owner/generation it is leaving BEFORE its first await). */
  captureScope(): SessionScope
  /** Diagnostics; the runtime logs per-owner retirement failures and disposes
   *  the sink at the end of the exit retirement (its last consumer). */
  readonly diag: Diag
}

/**
 * The outcome of one fork navigation. Structurally a `CommandResult` (the
 * command layer renders it), but defined here so `app/session` never imports
 * the Host command package.
 */
/**
 * PR5 v2 §3C (plan-owner amendment): the machine-readable reason of one
 * fork error. REASON controls the user-facing wording; the separate
 * `notificationNavigation` controls currentness — never the error text.
 */
export type SessionForkErrorReason =
  | 'navigation-changed-before-dispatch'
  | 'host-refused'
  | 'adoption-failed'
  | 'fork-failed'
export type SessionForkOutcome =
  | { readonly kind: 'success'; readonly text?: string; readonly adoptedNavigation?: RewindNavigationIdentity }
  | {
    readonly kind: 'error'
    readonly text: string
    readonly reason: SessionForkErrorReason
    /**
     * The notification fence of THIS error — the navigation identity the
     * failure was determined against:
     * - pre-admission stale-picker detection: the LIVE identity observed
     *   at detection (`before` — A→B→A lands on A/N+2);
     * - every post-admission failure (host refusal, adoption, lifecycle):
     *   THIS fork's ADMISSION identity (`expected`) — the failure happened
     *   inside this operation's claim, and the picker-open identity was
     *   already invalidated by the claim's own bump (the d529d464 defect:
     *   it made every admitted error settlement compare against a
     *   necessarily-stale snapshot).
     * The presentation publishes only while this identity is current.
     */
    readonly notificationNavigation: RewindNavigationIdentity
  }
/* PR5 v2 §3C: `adoptedNavigation` (above) is the POST-ADOPTION navigation
 * identity minted by THIS runtime at the adoption commit (the only layer
 * allowed to mint it). The final visible settlement ("rewound to turn N")
 * may notify only while this identity is still current — a successful
 * rewind's OWN adoption is not external supersession, but a LATER external
 * navigation (A→B→A included) must suppress the stale toast. */

/**
 * The fork-adoption ownership ledger (plan §8.5): tracks what adoption
 * acquired, released or committed, so the fork error path can distinguish an
 * owner that still awaits parking from one the adoption cleanup already
 * released exactly once (re-parking the latter would resurrect a disposed
 * Direct handle or double-retire on the exit drain).
 */
interface ForkAdoptionLedger {
  /** The adoption cleanup already released the acquired child owner. */
  released: boolean
}

/** The narrow entries the runner consumes. */
/** The SETTLED result of a tracked session switch. `matched`/accepted is not
 *  success: only `committed` means the target own the visible surface.
 *  `superseded` is a locally stale intent (definitely not applied);
 *  `indeterminate` is a Host-side open/commit whose local currentness was lost
 *  (the target may be active — never report it as "not executed"). */
export type SessionSwitchOutcome =
  | { readonly kind: 'committed'; readonly sessionId: string }
  | { readonly kind: 'already-current'; readonly message: string }
  | { readonly kind: 'failed'; readonly message: string }
  | { readonly kind: 'superseded'; readonly message: string }
  | { readonly kind: 'indeterminate'; readonly message: string }
  | { readonly kind: 'cancelled' }

export interface SessionRuntime {
  /**
   * Run one scope-bound TUI writer. The admission is a NO-YIELD section:
   * `isScopeCurrent(scope)` and the barrier occupancy happen in the SAME
   * synchronous call stack, so a transition started immediately after this
   * returns must wait for the writer. A stale scope is refused with
   * {@link SessionScopeSupersededError} (never the barrier's
   * `TransitionInProgressError`) BEFORE the task runs; a frozen transition
   * keeps the barrier's own refusal (no auto retry).
   */
  withWriter<T>(scope: LiveSessionScope, task: () => Promise<T> | T): Promise<T>
  /**
   * Run one CONTROL operation against the captured live scope: a user
   * interrupt or a selected subagent Stop. It is admitted while a navigation
   * transition holds the barrier (the writer drain does NOT block it) but
   * still refuses a stale scope synchronously, and it receives the EXACT
   * owner captured in the same no-yield section. It is not a writer bypass:
   * an admitted writer still drains before the transition commits, and this
   * section never increments the writer count.
   */
  withControl<T>(
    scope: LiveSessionScope,
    task: (owner: SessionOwnerRef) => Promise<T> | T,
  ): Promise<T>
  /**
   * Interrupt the captured session's current work through the control
   * admission, preserving its pending inbox. A stale capture or an aborted
   * runner is `cancelled` (confirmed not dispatched, never a generic error);
   * a backend refusal/unknown carrier result keeps its typed settlement.
   */
  interrupt(scope: LiveSessionScope): Promise<WriteOutcome<undefined>>
  /** Run one ordinary session transition/switch (plan §4A). */
  transitionTo<T>(steps: TransitionSteps<T>): Promise<TransitionOutcome<T>>
  /**
   * Run ONE user-navigation transaction through the same transition gate and
   * barrier. The transition admission applies the backend's navigation
   * ownership BEFORE the admitted-writer drain: a `stop-and-quiesce` backend
   * stops the intent's captured generation exactly once (a stale capture or a
   * refused/unproven stop aborts before the body with
   * {@link SessionNavigationStopError}, and `admission.oldStopAccepted` records
   * the accepted stop so a later failure in `task` can state that the old Turn
   * is already stopped), while a `detach-client` backend dispatches no Host
   * stop, so `admission.oldStopAccepted` stays false and only the captured
   * scope's currentness is checked.
   */
  withNavigation<T>(intent: NavigationIntent, task: () => Promise<T> | T): Promise<T>
  /** Hand the TUI over to another persisted session (never throws). A scoped
   *  UI intent can supply its captured scope so a queued stale request is
   *  refused inside the transition gate before navigation side effects. */
  switchSession(sessionId: string, expectedScope?: SessionScope): Promise<string | undefined>
  /** The tracked settled switch outcome used by `/resume` (acceptance is not success). */
  switchSessionOutcome(sessionId: string, expectedScope?: SessionScope): Promise<SessionSwitchOutcome>
  /** Adopt one forked child inside the gate (plan §4B). Resolves to the
   * navigation identity captured INSIDE the publication commit (PR5 v2
   * §3C — the caller's final settlement consumes exactly this saved
   * value), or `undefined` when the child was not adopted. */
  adoptFork(
    handle: SessionHandle,
    expected: RewindNavigationIdentity,
    onAdopted?: () => void,
    pin?: ForkSourcePin,
  ): Promise<RewindNavigationIdentity | undefined>
  /** Fork one source Session (capture → pin → Host fork → supersession fence →
   *  adopt/park). Never throws. */
  forkSession(
    sourceSessionId: string,
    atSeq?: number,
    onAdopted?: () => void,
    pickerIdentity?: RewindNavigationIdentity,
  ): Promise<SessionForkOutcome>
  /** Park one refused fork's owner for a later claim. */
  parkForkOwner(handle: SessionHandle | undefined): void
  /** Whether a captured fork/rewind identity still owns the visible surface. */
  isNavigationCurrent(expected: RewindNavigationIdentity): boolean
  /** Track one in-flight fork (the exit retirement drains them first). */
  trackFork(promise: Promise<unknown>): void
  hasPendingForks(): boolean
  /** Track one in-flight command settlement / nested submission. */
  trackSettlementWork(promise: Promise<unknown>): void
  // command settlement (§3.5)
  beginCommandSettlement(): void
  abortCommandSettlement(): void
  settleCommandSettlement(): Promise<void>
  /** Run the first-session commit (plan §4C). Returns whether the child
   *  committed (`false` = the lifecycle aborted during its quiesce). */
  commitFirstSession(handle: SessionHandle): Promise<boolean>
  /** Create the first session lazily (deferred session creation). */
  ensureSession(): Promise<void>
  /** Publish the startup-resume owner synchronously (plan §4D: publish →
   *  completion → pre-mount quiesce). Returns the quiesce promise only when the
   *  runner's hook produced one, so a sessionless startup stays synchronous. */
  publishResumedOwner(
    handle: SessionHandle | undefined,
    preMountQuiesce: (owner: SessionOwnerRef) => Promise<unknown> | undefined,
  ): Promise<unknown> | undefined
  // retirement coordination (§4.1)
  retireOwnedSession(): Promise<SessionRetirementReport>
  preCancelOwnedSession(): void
}

export function bindSessionRuntime(core: SessionOwnershipCore, deps: SessionRuntimeDeps): SessionRuntime {
  let retirementPromise: Promise<SessionRetirementReport> | undefined

  /**
   * The scope-bound writer admission (A3 §1.3). The stale check and the
   * barrier occupancy run in the same synchronous stack: there is deliberately
   * NO await between them, so a writer that has already admitted CANNOT be
   * overtaken by a transition that starts right after this returns. A stale
   * scope rejects with its OWN signal before the task body runs.
   */
  const withWriter = <T>(scope: LiveSessionScope, task: () => Promise<T> | T): Promise<T> => {
    if (!deps.isScopeCurrent(scope)) return Promise.reject(new SessionScopeSupersededError())
    return core.barrier.runWriter(scope.sessionId, async () => task())
  }

  /**
   * The scope-bound CONTROL admission (Busy Esc / subagent Stop). The scope
   * check, the EXACT owner capture and the barrier control section run in the
   * same synchronous stack, so a stale capture can never address a newer
   * owner and a transition that is about to publish one can never hand its
   * cancel to the wrong generation. Unlike {@link withWriter}, a frozen
   * transition does NOT refuse this section; unlike an ordinary writer, it
   * does not delay the transition's drain or its commit.
   */
  const withControl = <T>(
    scope: LiveSessionScope,
    task: (owner: SessionOwnerRef) => Promise<T> | T,
  ): Promise<T> => {
    if (!deps.isScopeCurrent(scope)) return Promise.reject(new SessionScopeSupersededError())
    const owner = core.owner()
    // `isScopeCurrent` already proved an owner-bearing capture; the guard
    // only narrows the type and is unreachable in production.
    if (owner === undefined) return Promise.reject(new SessionScopeSupersededError())
    return core.barrier.runControl(() => task(owner))
  }

  /**
   * Interrupt the captured live session's current work. The backend cancel is
   * addressed by the EXACT owner captured inside {@link withControl}; a stale
   * capture and an exiting runner are both `cancelled` (the request provably
   * never left the TUI) and therefore never surface as a spurious
   * `agent interrupt` ERROR.
   */
  const interrupt = (scope: LiveSessionScope): Promise<WriteOutcome<undefined>> => {
    if (deps.lifecycleSignal.aborted) return Promise.resolve({ kind: 'cancelled' })
    return withControl(scope, owner => deps.retirement.cancel(owner)).catch((error: unknown) => {
      if (error instanceof SessionScopeSupersededError) return { kind: 'cancelled' as const }
      throw error
    })
  }

  /**
   * The user-navigation admission. A `stop-and-quiesce` backend sends ONE
   * exact-owner stop here; a `detach-client` backend returns `nothing` after
   * the capture check and dispatches no Host call. It runs INSIDE the frozen
   * barrier: the scope check and the owner capture happen in the SAME
   * synchronous stack as the backend call (exactly like the control
   * admission), so a replacement published elsewhere can never receive this
   * navigation's stop. A still-current capture is the ONLY prerequisite:
   *
   * - `stopped` (backend `committed`) — the backend accepted the STOP REQUEST;
   *   only the transition's OLD-owner quiesce can prove the Turn stopped, and
   *   the failure wording distinguishes "requested, not yet confirmed" from
   *   "quiesced, cannot be resumed";
   * - `nothing` — the surface is sessionless (there is no old owner to stop),
   *   the runner is exiting (the transition is moot), or the backend's
   *   `navigationKind` is `detach-client` (leaving a Session only releases
   *   THIS Client's reference; the Host Turn keeps running and is never
   *   addressed by a navigation cancel);
   * - `failed` — ONLY a `committed` cancellation is permission to enter the
   *   next phase. A proven refusal (`rejected`), a confirmed pre-dispatch
   *   refusal (`cancelled`) and a dispatched-unproven stop (`indeterminate`)
   *   all abort navigation. A `cancelled` result means the exact generation
   *   could not be addressed, NOT that the Host has no running work; a Remote
   *   `whenIdleOrAbort` returning `'unobservable'` for a rolled/released
   *   binding is likewise not proof of idle, and is never reached on this
   *   path. An
   *   indeterminate stop is never retried.
   * A stale capture aborts FIRST: another navigation owns the surface, and
   * this intent must not stop the replacement's work.
   */
  /** The receipt of the LAST `stop-and-quiesce` navigation stop in this gate
   *  task; read by `transitionTo` so the OLD-owner quiesce validates the SAME
   *  generation the accepted cancel was addressed to (never a later
   *  reconnect). Always undefined for a `detach-client` navigation. */
  let navigationReceipt: NavigationStopReceipt | undefined

  const navigationStop = async (scope: SessionScope): Promise<
    | { readonly kind: 'stopped'; readonly receipt?: NavigationStopReceipt }
    | { readonly kind: 'nothing' }
    | { readonly kind: 'failed'; readonly failure: NavigationStopFailure }
  > => {
    if (deps.lifecycleSignal.aborted) return { kind: 'nothing' }
    if (!deps.isScopeCurrent(scope)) {
      return { kind: 'failed', failure: { settlement: 'stale', detail: '' } }
    }
    // A detach-client backend keeps the Host Turn alive across the navigation:
    // leaving the Session releases THIS Client's reference and never stops the
    // Host Agent, so there is no stop to address and no stop fact to admit.
    if (deps.retirement.navigationKind === 'detach-client') return { kind: 'nothing' }
    const owner = core.owner()
    if (owner === undefined) return { kind: 'nothing' }
    // The PHASE-RESOLVED navigation settlement: a pre-dispatch refusal is
    // `cancelled`; a dispatched reply whose effect is unproven (including a
    // caller/carrier cancellation) is `indeterminate`. Only `committed` may
    // proceed.
    const settlement = await deps.retirement.cancelForNavigation(owner)
    if (settlement.kind === 'committed') {
      return settlement.receipt === undefined
        ? { kind: 'stopped' }
        : { kind: 'stopped', receipt: settlement.receipt }
    }
    if (settlement.kind === 'cancelled') {
      return { kind: 'failed', failure: { settlement: 'cancelled', detail: '' } }
    }
    return { kind: 'failed', failure: { settlement: settlement.kind, detail: settlement.detail } }
  }

  /**
   * The barrier half of a navigation admission (the caller holds the gate):
   * freeze → the backend's navigation ownership (`stop-and-quiesce`: ONE
   * exact-owner stop of the intent's captured generation; `detach-client`: no
   * Host stop, scope currentness only) → admitted writer drain → the
   * transition body. The intent's `admission` fact is written from that
   * admission callback, before the body runs; a stop failure aborts with ZERO
   * body side effects.
   */
  const runNavigationTransition = <T>(intent: NavigationIntent, task: () => Promise<T> | T): Promise<T> => {
    let stopReceipt: NavigationStopReceipt | undefined
    return core.barrier.runTransition(
      async () => {
        // Publish the accepted stop's exact generation for the transition body
        // (and only for it): the quiesce must not re-capture a later
        // generation after a writer-drain reconnect.
        navigationReceipt = stopReceipt
        try {
          return await task()
        } finally {
          navigationReceipt = undefined
        }
      },
      async () => {
        const stop = await navigationStop(intent.scope)
        if (stop.kind === 'failed') throw new SessionNavigationStopError(stop.failure)
        intent.admission.oldStopAccepted = stop.kind === 'stopped'
        stopReceipt = stop.kind === 'stopped' ? stop.receipt : undefined
      },
    )
  }

  /**
   * Run one navigation task through the gate and ALWAYS close the
   * deferred-queue-recall window at its end. A queue pull-back admitted before
   * the freeze can finish during the stop, remove its occurrences and DEFER its
   * local restore to the pending transition — whose production predicate is
   * `gate.pending || barrier.inTransition`, so a QUEUED later task also keeps it
   * pending. The body's own settle restores it only when the body runs; a
   * refused admission, a stale scoped recheck and a stop failure never reach
   * that body.
   *
   * The settle is registered DIRECTLY on the gate task promise. The gate's own
   * `active=false` reaction was registered first, and the next queued task is
   * chained on the tail that reaction resolves — so this runs after the gate
   * cleared and BEFORE the next task starts. A writer that defers during this
   * task (including one that observed the still-queued next task) is caught
   * here; one that defers later is attributed to the NEXT navigation task, which
   * closes its own window the same way. The commit/body settlements already
   * performed make this a no-op on the ordinary success path.
   */
  const runNavigationGate = <T>(task: () => Promise<T> | T): Promise<T> =>
    core.gate.run(task).finally(() => deps.surface.settlePendingQueueRecalls(false))

  /**
   * Run ONE user-navigation transaction through the gate + barrier. The stop
   * and drain run BEFORE the body; the body then creates and commits exactly
   * like {@link transitionTo}.
   */
  const withNavigation = <T>(intent: NavigationIntent, task: () => Promise<T> | T): Promise<T> =>
    runNavigationGate(() => runNavigationTransition(intent, task))

  /**
   * Run one ordinary session transition/switch: quiesce (only when the backend
   * owns the replaced owner's Host lifecycle) the old owner, run the caller's
   * preflight/create, commit the visible handle through the fixed order
   * (`runOrdinaryCommit`, plan §4A) and retire the old owner. The committed
   * child always stands: a post-commit failure is contained and reported as a
   * failed step. ONE deliberate exception: when the lifecycle aborts during the
   * post-commit child quiesce, the transition returns early — the surface init
   * and the switch report are skipped (the exiting runner's retirement takes
   * over) and the outcome stays successful.
   */
  const transitionTo = async <T>(steps: TransitionSteps<T>): Promise<TransitionOutcome<T>> => {
    // The accepted navigation stop's generation receipt, if this transition is
    // the body of a `stop-and-quiesce` user navigation. A plain transition and
    // a `detach-client` navigation have none.
    const stopReceipt = navigationReceipt
    core.bumpNavigationEpoch()
    const from = core.currentSessionId()
    const opening = deps.surface.beginOpening(steps.target.id)
    // The OLD owner is captured at ADMISSION: the post-commit retirement must
    // retire exactly the owner this transition replaced.
    const oldOwner = core.owner()
    // The NEW owner this transaction commits, mapped ONCE in the synchronous
    // commit section: the post-commit phases reuse it instead of re-wrapping
    // the handle (each `fromHandle` of a Remote reference wrapper is an
    // ownership transfer, never a free re-read).
    let committedOwner: SessionOwnerRef | undefined
    // The owner metadata the post-publication phases may consume. Everything
    // throwable is snapshotted BEFORE `setCurrentOwner` (the sole commit
    // point); after the publication a transaction never re-resolves the owner
    // through `SessionOwnerAccess` — it only consumes these primitives.
    let committedSessionId: string | undefined
    // The exactly-once release of a NEW owner that was acquired but never
    // published, STARTED synchronously in the commit section and AWAITED
    // before this transition settles (so the gate/barrier it holds stay
    // closed until the released reference/lease is actually gone — never a
    // fire-and-forget retirement).
    let preCommitRelease: Promise<void> | undefined
    let transitionCommitted = false
    try {
      return await runTransitionTo<T>({
        quiesceOld: async () => {
          // A detach-client backend keeps the replaced Host Turn alive: the
          // admitted Client writers already drained in the barrier, the replaced
          // Client reference is released only AFTER the synchronous commit, and
          // `flush` is a Client no-op that proves no durability. Waiting for the
          // old Host owner's idle here would reintroduce exactly the implicit
          // wait this navigation contract removes, and an `'unobservable'`
          // quiesce would abort a navigation the Host never blocked.
          if (deps.retirement.navigationKind === 'detach-client') return
          const owner = core.owner()
          if (owner === undefined) return
          // QUIESCE first: after whenIdle the old owner can no longer produce turn
          // events, so the final flush below is truly final. The wait is
          // abort-aware: an exit during the quiesce cancels the CURRENT owner
          // (which may be a NEW owner committed by an earlier queued transition),
          // so the transition settles instead of hanging past the appExit
          // watchdog.
          const idle = await deps.retirement.whenIdleOrAbort(owner, deps.lifecycleSignal, stopReceipt)
          if (idle === true) return
          if (idle === 'unobservable') {
            // The exact OLD generation can no longer be observed: we cannot
            // prove its Turn stopped. A user navigation must NOT create/open a
            // replacement behind an unknown old Turn (that would be a silent
            // detach); abort before the create with the phase fact preserved.
            throw new Error('the old session owner is no longer observable — refusing to switch without a confirmed stop')
          }
          // Final flush before the switch. The owner is re-read AFTER the quiesce
          // (the abort path may have swapped it), matching the pre-cutover read.
          const flushOwner = core.owner()
          if (flushOwner === undefined) return
          if (deps.lifecycleSignal.aborted) {
            // The exit already began: issuing an explicit flush now would race
            // the close that owns durability. The flush is therefore NOT
            // ATTEMPTED — which is different from swallowing its failure: once
            // issued, any rejection is a real, reported failure (the shutdown
            // close settlement is the only authority that can own durability).
            deps.diag.info('old-owner flush skipped: the lifecycle already aborted')
            return
          }
          // A rejection here is NEVER reclassified by the lifecycle flag: the
          // flush may have failed on its own (a persistence listener's real
          // I/O error), and an aborted lifecycle does not prove otherwise.
          await deps.retirement.flush(flushOwner)
          // ONLY an OBSERVED settle proves the old Turn idle; 'unobservable'
          // (a rolled Remote binding / missing attachment) is not idle.
          if (idle === false) steps.onOldOwnerQuiesced?.()
        },
        commit: (next) => {
          // Map the NEW owner BEFORE the commit section can throw: the commit
          // ORDER stays fixed by `runOrdinaryCommit` (the generation reset runs
          // BEFORE the new owner is published, so it observes the OLD owner),
          // but a pre-publication seam failure must be able to release the
          // acquired NEW owner exactly once instead of leaking its reference.
          const nextOwner = deps.owners.fromHandle(next as SessionHandle)
          if (nextOwner === undefined) throw new Error('ordinary transition published a handle without an owned Session generation')
          try {
            runOrdinaryCommit({
              isSurfaceDisposed: deps.surface.isSurfaceDisposed,
              settlePendingQueueRecalls: deps.surface.settlePendingQueueRecalls,
              settleLocalSubmitAck: deps.surface.settleLocalSubmitAck,
              resetSubmitLatency: deps.surface.resetSubmitLatency,
              bumpGeneration: core.bumpGeneration,
              publishOwner: () => {
                // Every owner-metadata lookup that can throw runs BEFORE the
                // publication; after `setCurrentOwner` the commit point is
                // seamless (plain assignments only), so `runOrdinaryCommit`'s
                // recall commit directly follows the true publication.
                const identity = deps.owners.completionIdentity(nextOwner)
                const sessionId = deps.owners.sessionId(nextOwner)
                committedOwner = nextOwner
                committedSessionId = sessionId
                // PR3-B §7.3 (F1): the active-draft drop rides the
                // publication's SYNCHRONOUS commit block — after the
                // captured facts are resolved, inside the same seam as
                // `setCurrentOwner`, BEFORE the first await (retirement,
                // hydration, catalog) and therefore before any new-source
                // frame can lift the input fence: the outgoing text is gone
                // before the new session is editable, and no post-hydration
                // keystroke can be wiped by a late clear. The discriminator
                // is the OPAQUE OWNER REF (the same axis the stale-restore
                // policy reads): only a genuinely REPLACED owner drops —
                // aligned with `SessionSubjectAuthority.ownerReplaced`, so
                // a same-id re-publication and a same-owner generation bump
                // answer consistently on both surfaces. The first-session
                // creation publishes without an outgoing owner; a
                // pre-publication failure never reaches this seam.
                if (oldOwner !== undefined && oldOwner !== nextOwner) {
                  deps.surface.dropOutgoingActiveDraft()
                }
                core.setCurrentOwner(nextOwner, sessionId)
                // The editor-recall scope follows the SAME synchronous
                // publication: the new owner's hydration reseeds ↕ recall
                // from its disk rows, and an input accepted before that
                // reseed must survive it (the owner is current here, so the
                // entry belongs to the new Session). State-only.
                deps.surface.beginInputHistoryScope(sessionId)
                // Phase 3B / B3-B: the old Session's History seat is logically
                // dead the instant the new owner is published; close its physical
                // tenant in the same synchronous commit, before the post-commit
                // awaits, so the new owner's first editable frame never paints a
                // stale History. State-only and non-throwing.
                deps.surface.retireStaleHistorySeat()
                // External review P2-B: the new owner IS published here, so the
                // replaced subject's modal must already be out of the seat before
                // the post-commit awaits below (retirement, quiesce, hydration).
                if (oldOwner !== undefined && oldOwner !== nextOwner) {
                  deps.surface.withdrawReplacedPresentation()
                }
                // The publication is the transition's COMMIT POINT: only from
                // here on does the `finally` below stop restoring the queued
                // recalls (a pre-publication failure settles them aborted).
                transitionCommitted = true
                return identity
              },
              setCompletionOwner: deps.surface.setCompletionOwner,
            }, next)
          } catch (error) {
            if (core.owner() !== nextOwner) {
              // PRE-publication failure: the NEW owner was acquired (its
              // reference retained) but never committed. Release it exactly
              // once; OLD stays current and the original failure propagates
              // unchanged. The release is awaited before the transition
              // settles (see the catch below), and the transition's `finally`
              // restores the queued recalls when this throw unwinds.
              preCommitRelease = deps.retirement.retire(nextOwner, 'transition').then(report => {
                for (const failure of report.failures) {
                  // No owner re-read here: the target id is the semantic id of
                  // this transaction, and the original failure may itself be a
                  // metadata throw — a re-read could reject this cleanup and
                  // mask the transition's real error.
                  deps.diag.error('pre-commit NEW owner release failed', {
                    session: steps.target.id,
                    phase: failure.phase,
                    error: failure.error,
                  })
                }
              })
              throw error
            } else {
              // POST-publication failure (a synchronous seam after the
              // publication): the child IS committed. Contain it as a failed
              // post-commit step and let the transition proceed to the OLD
              // retirement: the committed child stands, never a rollback
              // and never a skipped OLD release. The recalls were already
              // settled committed by the commit section.
              deps.diag.error('transition commit seam failed after publication (child committed)', {
                to: committedSessionId,
                error: safeErrorMessage(error),
              })
            }
          }
        },
      retireOld: async () => {
        const retired: string[] = []
        // The committed owner was mapped once in the commit section; a
        // successful commit always published one (the commit section fails
        // fast otherwise).
        const nextOwner = committedOwner
        if (nextOwner === undefined) throw new Error('committed transition child has no owned Session generation')
        // D2 durability checkpoint — the FIRST post-commit step, before the OLD
        // owner's retirement and before the abort-aware child quiesce. The
        // order is load-bearing: DSH's close drains what was appended but does
        // not materialize an empty, never-appended session (asserted against
        // the installed backend in test/runtime/direct/session-flush-close-race),
        // and a shutdown closes the handle concurrently with this transaction.
        // Both of the steps below are unbounded awaits (the OLD owner's
        // descendant drain and the child quiesce), so a checkpoint behind
        // either of them can be overtaken by an exit that closes the handle
        // first. Only the COMMIT-time `nextOwner` is flushed — never a re-read
        // of the current owner (a newer transition may already have replaced
        // it). A failure does NOT roll the child back or fail the transition:
        // it is recorded here, and the surface warns when it is still reachable.
        let committedDurabilityFailure: string | undefined
        try {
          await deps.retirement.flush(nextOwner)
        } catch (error) {
          // The failure is fixed HERE, before the next await: the OLD owner's
          // retirement and the child quiesce are unbounded, and the exit
          // watchdog may end the process before a later summary line. The
          // diagnostic sink writes synchronously (`writeSync`), so the exact
          // session id and the original error are captured in this same stack.
          committedDurabilityFailure = safeErrorMessage(error)
          deps.diag.error('committed session durability checkpoint failed', {
            session: committedSessionId,
            error: committedDurabilityFailure,
          })
          retired.push(`committed child flush: ${committedDurabilityFailure}`)
          // Single user notice, also at the failure itself. A synchronous
          // notify may re-enter the application (and even begin an exit), so
          // nothing below may assume the surface stayed live.
          if (!deps.surface.isSurfaceDisposed() && committedSessionId !== undefined) {
            deps.surface.warnCommittedDurability(committedSessionId, committedDurabilityFailure)
          }
        }
        // Retire the OLD owner through the retirement port (which owns the
        // official close order): the pre-commit quiesce already idled + flushed,
        // so this covers the window where the old owner was re-woken by a
        // Host-side continuation and releases its handle.
        if (oldOwner !== undefined) {
          const report = await deps.retirement.retire(oldOwner, 'transition')
          for (const failure of report.failures) {
            // A failed dispose means the old session may still have writers; the
            // child stays current and the failure is recorded (the DSH
            // SessionWriteLease still guards the session cross-process).
            retired.push(`old ${failure.phase}: ${failure.error}`)
          }
        }
        try {
          // The child quiesce is abort-aware too: an exit during this
          // post-commit phase must cancel the NEW owner instead of hanging past
          // the watchdog. When the lifecycle aborted, the surface is already
          // disposed and the retirement takes over: skip the surface
          // initialization below (it would repaint into the disposed app) and
          // let the committed child stand.
          //
          // A detach-client backend keeps the committed child's Host Turn
          // running — the target may legitimately be busy when the Client
          // arrives — so it must not wait for that child's idle. The lifecycle
          // check still runs: an exit during this phase owns the same
          // skip-the-surface-init behavior on BOTH backends.
          const aborted = deps.retirement.navigationKind === 'detach-client'
            ? deps.lifecycleSignal.aborted
            : (await deps.retirement.whenIdleOrAbort(nextOwner, deps.lifecycleSignal)) === true
          if (aborted) {
            // The lifecycle is exiting: the committed child stands and the
            // retirement takes over. Skip the surface init AND the switch
            // report (the `finally` still clears the opening journal).
            retired.push('child quiesce aborted by lifecycle')
            // The surface warning below is unreachable on this path (the
            // surface is disposed), so EVERY recorded post-commit failure —
            // the committed child's checkpoint and the OLD owner's retirement —
            // must still reach the diagnostics instead of dying with the early
            // return. An aborted lifecycle never proves a failure benign.
            if (retired.length > 0) {
              deps.diag.error('transition retire failed (child committed)', {
                to: committedSessionId,
                failures: retired,
              })
            }
            return
          }
        } catch (error) {
          retired.push(`child whenIdle: ${safeErrorMessage(error)}`)
        }
        try {
          await deps.surface.initLiveSession(nextOwner)
        } catch (error) {
          retired.push(`surface rebuild: ${safeErrorMessage(error)}`)
        }
        // The new owner's catalog refresh is AWAITED before the switch is
        // reported: the old wrappers became revalidating transitions at the
        // target change, and the report must not precede the new catalog (a
        // failed attempt still returns a successful switch — the coordinator
        // warns and the transition commands keep re-validating).
        try {
          await deps.surface.refreshLiveCatalog(nextOwner)
        } catch (error) {
          retired.push(`catalog refresh: ${safeErrorMessage(error)}`)
        }
        deps.surface.clearOpening(opening)
        if (retired.length > 0) {
          deps.diag.error('transition retire failed (child committed)', {
            to: committedSessionId,
            failures: retired,
          })
        }
        // The checkpoint failure (if any) was already diagnosed and notified at
        // the failure itself; the switch DID commit, so it is never reported as
        // a failed transition.
        deps.surface.reportSwitch(from, nextOwner)
      },
      recordFailure: (phase, error) => {
        deps.diag.error(`transition ${phase} failed`, { from, error: safeErrorMessage(error) })
        deps.surface.clearOpening(opening)
      },
      }, steps)
    } catch (error) {
      // The commit section started the exactly-once release of an acquired
      // but never-published NEW owner: AWAIT it before this transition
      // settles, so the transition gate/barrier it still holds stay closed
      // until the released reference/lease is actually gone. A concurrent
      // exit retirement or a same-session reopen is thereby serialized behind
      // the release instead of racing it.
      if (preCommitRelease !== undefined) await preCommitRelease
      throw error
    } finally {
      if (!transitionCommitted) deps.surface.settlePendingQueueRecalls(false)
      deps.surface.clearOpening(opening)
    }
  }

  /**
   * Hand the TUI over to another persisted session. Never throws: every failure
   * (unknown session, broken log, preset mount) returns an error string so the
   * caller's `.then(error => ...)` needs no rejection path. The whole switch
   * (open → commit) runs inside the session-transition gate, so it can never
   * interleave with another ordinary transition.
   *
   * A switch is a USER NAVIGATION: the barrier admission applies the backend's
   * navigation ownership before the admitted writers drain (a
   * `stop-and-quiesce` backend stops the captured OLD generation once, a
   * `detach-client` backend sends no Host stop and waits for no idle). A
   * SCOPED intent (the Session Browser's captured row) is fenced by that
   * capture: a stale one is a superseded navigation and settles silently. An
   * UNSCOPED intent (a picker selection made against the live surface)
   * captures its scope INSIDE the gate right before the freeze, so a queued
   * later selection still follows the FIFO and never inherits an older
   * generation. A refused or unproven stop keeps the CURRENT session live and
   * says why.
   */
  const switchSessionOutcome = (sessionId: string, expectedScope?: SessionScope): Promise<SessionSwitchOutcome> => {
    /** The barrier half of this switch (the gate wrapper is added below). */
    const runLocked = (scope: SessionScope): Promise<SessionSwitchOutcome> => {
      const intent: NavigationIntent = { scope, admission: { oldStopAccepted: false } }
      return runNavigationTransition(intent, async () => {
        try {
          return await switchSessionLockedOutcome(sessionId, intent.admission)
        } finally {
          // Preflight can fail before `transitionTo` is reached; settle any
          // recall that was waiting on this transition in that case.
          deps.surface.settlePendingQueueRecalls(false)
        }
      })
    }
    const mapStopFailure = (error: unknown): SessionSwitchOutcome => {
      if (!(error instanceof SessionNavigationStopError)) throw error
      // A stale capture is a locally superseded navigation: the surface
      // already moved, so the intent is definitely not applied here.
      if (error.settlement === 'stale') {
        return { kind: 'superseded', message: 'the session changed before this switch could start' }
      }
      return { kind: 'failed', message: `${error.message}; the session was not switched` }
    }
    /**
     * A switch INTO the session already current is a NO-OP: it replaces nothing,
     * so it must NOT stop the current owner's turn. Evaluated INSIDE the gate,
     * so a queued intent whose target became current in the meantime skips the
     * stop too — on BOTH the scoped and the unscoped admission.
     */
    const noOpSwitch = (): SessionSwitchOutcome | undefined => {
      if (core.currentSessionId() !== sessionId) return undefined
      deps.surface.settlePendingQueueRecalls(false)
      return { kind: 'already-current', message: 'already on this session' }
    }
    if (expectedScope === undefined) {
      core.bumpNavigationEpoch()
      return runNavigationGate((): SessionSwitchOutcome | Promise<SessionSwitchOutcome> => {
        const noOp = noOpSwitch()
        if (noOp !== undefined) return noOp
        // Capture the owner this queued selection is actually leaving WHEN ITS
        // TURN COMES: every earlier transition already settled, and the capture
        // and the barrier freeze still happen in the SAME synchronous stack.
        return runLocked(deps.captureScope())
      }).catch(mapStopFailure)
    }
    if (!deps.isScopeCurrent(expectedScope)) {
      return Promise.resolve<SessionSwitchOutcome>({ kind: 'superseded', message: 'the session changed before this switch could start' })
    }
    return runNavigationGate((): SessionSwitchOutcome | Promise<SessionSwitchOutcome> => {
      // A previous queued transition may have published a new owner while this
      // intent waited. Recheck before this request bumps navigation or opens B.
      if (!deps.isScopeCurrent(expectedScope)) {
        return { kind: 'superseded', message: 'the session changed before this switch could start' }
      }
      const noOp = noOpSwitch()
      if (noOp !== undefined) return noOp
      core.bumpNavigationEpoch()
      return runLocked(expectedScope)
    }).catch(mapStopFailure)
  }

  /** Compatibility projection for callers that only need the old error string
   *  (`undefined` = committed or a silent superseded intent). New navigation
   *  settlement code must use {@link switchSessionOutcome}. */
  const switchSession = async (sessionId: string, expectedScope?: SessionScope): Promise<string | undefined> => {
    const outcome = await switchSessionOutcome(sessionId, expectedScope)
    switch (outcome.kind) {
      case 'committed':
      case 'cancelled':
      case 'superseded':
        return undefined
      case 'already-current':
      case 'failed':
      case 'indeterminate':
        return outcome.message
    }
  }

  const switchSessionLockedOutcome = async (
    sessionId: string,
    admission: NavigationAdmission,
  ): Promise<SessionSwitchOutcome> => {
    // Every failure AFTER an ACCEPTED stop distinguishes the two proven
    // states: the old Turn is stopped and can never be resumed only once the
    // pre-commit quiesce completed; before that, the stop is merely requested.
    const stopNote = (quiesced: boolean): string => {
      if (!admission.oldStopAccepted) return ''
      return quiesced
        ? '; old turn stopped (cannot resume)'
        : '; turn stop requested (not yet confirmed)'
    }
    // Draft cleanup happens ONLY after the switch committed (the transaction
    // returned ok): a refused/failed switch keeps the CURRENT session and its
    // staged drafts intact — clearing up front would orphan the editor's
    // placeholders on every failed switch.
    let oldOwnerQuiesced = false
    try {
      if (deps.lifecycleSignal.aborted) return { kind: 'cancelled' }
      const result = await transitionTo({
        target: { id: sessionId },
        // The quiesce callback is the ONLY proof that the old Turn reached
        // idle; the failure note below distinguishes it from a stop request.
        onOldOwnerQuiesced: () => { oldOwnerQuiesced = true },
        // A rejected open leaves the target untouched: no pin, no retry — the
        // CURRENT session stays live and the user can retry the switch.
        create: async () => requireOpened(await deps.lifecycle.open({
          sessionId,
          signal: deps.lifecycleSignal,
        })),
      })
      if (!result.ok) {
        if (result.error instanceof LifecycleError) {
          deps.diag.warn('session switch did not own the surface', {
            settlement: result.error.settlement,
            ownership: result.error.ownership,
            publishedSessionId: result.error.publishedSessionId,
            requestedSessionId: result.error.requestedSessionId,
          })
          if (result.error.ownership === 'superseded') {
            // A superseded OPEN that already published/opened its target is
            // an INDETERMINATE switch, not a silent success and not a proven
            // non-execution: the Host may already have opened it.
            return result.error.publishedSessionId !== undefined
              ? {
                  kind: 'indeterminate',
                  message: `${result.message}${stopNote(oldOwnerQuiesced)} — do not retry automatically`,
                }
              : { kind: 'superseded', message: 'the session changed before this switch completed' }
          }
          if (result.error.settlement === 'indeterminate') {
            return { kind: 'indeterminate', message: `${result.message}${stopNote(oldOwnerQuiesced)} — do not retry automatically` }
          }
        }
        // The resume failed: the CURRENT session is still live. The full
        // official message (including its raw-log path) stays in the
        // diagnostic log; the NOTICE drops the path so the actionable refusal
        // plus the old-turn note fit a 44x20 viewport without scrolling the
        // current Session card away.
        deps.diag.warn('session switch refused', { sessionId, message: result.message })
        const displayMessage = result.message.replace(/\s+\(raw log: .*\)$/u, '')
        return { kind: 'failed', message: `${displayMessage}${stopNote(oldOwnerQuiesced)}` }
      }
      // The switch COMMITTED: staged drafts are per-session UI state — drop the
      // unpinned ones now (never durable attachments). In-flight submissions
      // keep their pinned drafts so a stale submission can still restore its
      // text with a live backing draft.
      deps.surface.clearUnpinnedDrafts()
      return { kind: 'committed', sessionId }
    } catch (error) {
      const message = safeErrorMessage(error)
      deps.surface.reportSwitchFailure(sessionId, message)
      // The CURRENT session is still live.
      return { kind: 'failed', message: `switch failed: ${message}${stopNote(oldOwnerQuiesced)}` }
    }
  }

  // The fork + source-retirement ledgers (A2-3b-3): they moved out of the
  // runner together with the flows that fill them. The command-settlement
  // window state lives here too, because a committed `/fork` QUEUES its source
  // retirement while an executor is still appending `command/done`.
  const pendingForks = new Set<Promise<unknown>>()
  const pendingSourceRetirements = new Set<Promise<void>>()
  // In-flight command settlements / nested submissions (reachable only from a
  // later callback, so the exit retirement waits for them explicitly).
  const pendingSettlementWork = new Set<Promise<unknown>>()
  let commandExecutionDepth = 0
  const deferredSourceRetirements: Array<{ sessionId: string; retire: () => Promise<void> }> = []

  /** Track one in-flight fork (the exit retirement drains them first). */
  const trackFork = (promise: Promise<unknown>): void => {
    pendingForks.add(promise)
    // `then(onSettled, onSettled)`: tracking must not add an unhandled rejection
    // branch next to the fork's own failure handling.
    observeSettled(promise, () => { pendingForks.delete(promise) })
  }

  const hasPendingForks = (): boolean => pendingForks.size > 0

  /** Track one in-flight command settlement / nested submission. */
  const trackSettlementWork = (promise: Promise<unknown>): void => {
    pendingSettlementWork.add(promise)
    // `then(onSettled, onSettled)`: tracking must not add an unhandled rejection
    // branch next to `runOwned`'s own failure handling.
    observeSettled(promise, () => { pendingSettlementWork.delete(promise) })
  }

  /** Whether a captured fork/rewind identity still owns the visible surface. */
  const isNavigationCurrent = (expected: RewindNavigationIdentity): boolean =>
    isRewindIdentityCurrent(core.captureNavigationIdentity(), expected)

  /** Park one refused fork's owner for a later claim (an ownerless
   *  publication-only child parks nothing). */
  const parkForkOwner = (handle: SessionHandle | undefined): void => {
    const owner = handle === undefined ? undefined : deps.owners.fromHandle(handle)
    if (owner !== undefined) deps.retirement.park(owner)
  }

  /**
   * Start one source retirement through the owned-task model AND register its
   * promise, so teardown can wait for it before the Host teardown. The task
   * promise is returned so a non-command caller can preserve the awaited
   * ordering.
   */
  const startSourceRetirement = (sessionId: string, retire: () => Promise<void>): Promise<void> | undefined => {
    let pending: Promise<void> | undefined
    runOwned('fork source retirement', () => {
      const task = retire()
      pending = task
      return task
    }, { diag: deps.diag, sessionId: () => undefined })
    if (pending !== undefined) {
      const tracked = pending
      pendingSourceRetirements.add(tracked)
      observeSettled(tracked, () => { pendingSourceRetirements.delete(tracked) })
    }
    return pending
  }

  /**
   * Retire the source owner. A DSH command defers it to its own settlement (the
   * executor's `command/done` append must land first) and returns `undefined`;
   * outside a command the retirement promise is returned so the caller keeps the
   * baseline ordering.
   *
   * `finishRelease` settles the fork's admission pin when the retirement has
   * FINISHED — success or a CONTAINED failure: a failed phase is recorded in the
   * retirement report (never a rejection), and holding the pin on a failed
   * dispose would leave `open`/`resume` pending forever.
   */
  const retireSourceOwnerAfterSettlement = (
    sessionId: string,
    retire: () => Promise<void>,
    finishRelease: () => void,
  ): Promise<void> | undefined => {
    const run = async (): Promise<void> => {
      try {
        await retire()
      } finally {
        finishRelease()
      }
    }
    if (commandExecutionDepth === 0) return startSourceRetirement(sessionId, run)
    deferredSourceRetirements.push({ sessionId, retire: run })
    return undefined
  }

  /** Start every retirement queued by the settled command(s) and return the
   *  started promises so the settlement can WAIT for them. */
  const flushSourceRetirementsAfterSettlement = (): Promise<void>[] => {
    const started: Promise<void>[] = []
    while (deferredSourceRetirements.length > 0) {
      const entry = deferredSourceRetirements.shift()
      if (entry === undefined) continue
      const pending = startSourceRetirement(entry.sessionId, entry.retire)
      if (pending !== undefined) started.push(pending)
    }
    return started
  }

  /** Open one command-settlement window: while any is open a committed `/fork`
   *  QUEUES its source retirement instead of detaching the Session whose
   *  executor is still appending `command/done`. */
  const beginCommandSettlement = (): void => { commandExecutionDepth += 1 }
  /** Close a window whose handler never ran: nothing was queued. */
  const abortCommandSettlement = (): void => { commandExecutionDepth -= 1 }
  /** Close one window EXACTLY once and WAIT for the retirements it queued: the
   *  command workflow must not report completion (nor release the submit FIFO)
   *  while the old owner still holds its write lease. */
  const settleCommandSettlement = async (): Promise<void> => {
    commandExecutionDepth -= 1
    if (commandExecutionDepth === 0) await Promise.allSettled(flushSourceRetirementsAfterSettlement())
  }

  /**
   * Adopt one forked child inside the gate: re-check the navigation fence, park
   * a refused child, commit through the fixed §4B order, retire the source owner
   * (deferred to its command settlement when one is open) and rebuild the
   * child's surface. Returns whether the child was adopted.
   *
   * A publication-only fork child (the Remote shape) carries no owner: adoption
   * happens through an explicit `lifecycle.open(childId)` retain of the
   * published identity — one Host fork dispatch plus at most one adoption
   * open, and the newly retained owner is released exactly once when a
   * re-checked fence refuses the commit. `ledger` (plan §8.5) tells the fork
   * error path when that exactly-once release already happened, so it never
   * parks an owner the adoption cleanup already released.
   *
   * The transaction-finally mirrors `transitionTo`: the fork holds the
   * transition gate from `gate.run`, so a writer finishing in that window may
   * DEFER a queue recall against it. EVERY pre-publication exit (refused
   * navigation, adoption-open failure, stale-after-retain, an invariant
   * failure, a pre-publication commit seam) therefore restores the deferred
   * recalls through ONE settle authority — the `finally` below — instead of
   * per-branch restores; the child publication is the commit point that turns
   * the settlement into `committed`.
   */
  const adoptFork = async (
    handle: SessionHandle,
    expected: RewindNavigationIdentity,
    onAdopted?: () => void,
    pin?: ForkSourcePin,
    ledger: ForkAdoptionLedger = { released: false },
    /** The navigation epoch THIS fork claimed at admission (PR5 v2 §3C,
     *  review R6-5): the publication identity is minted from THIS value,
     *  never re-read from the shared counter — a concurrent external
     *  bump (before the gate queues it) must not get absorbed into the
     *  operation's own identity. */
    claimedEpoch?: number,
  ): Promise<RewindNavigationIdentity | undefined> => {
    let adopted = false
    let forkCommitted = false
    /** PR5 v2 §3C: the navigation identity captured SYNCHRONOUSLY inside
     *  the publication commit (undefined until the commit happens). */
    let committedNavigation: RewindNavigationIdentity | undefined
    try {
      await core.gate.run(() => core.barrier.runTransition(async () => {
        if (deps.surface.isSurfaceDisposed() || !isNavigationCurrent(expected)) {
          parkForkOwner(handle)
          return
        }
        const oldOwner = core.owner()
        let commitHandle: SessionHandle = handle
        let nextOwner = deps.owners.fromHandle(handle)
        if (nextOwner === undefined) {
          // Publication-only child: retain the published identity through the
          // official open semantic. A failure here settles through the thrown
          // `LifecycleError` — the child stays published and the fork is never
          // redispatched.
          commitHandle = requireOpened(await deps.lifecycle.open({
            sessionId: handle.session.id,
            signal: deps.lifecycleSignal,
          }))
          nextOwner = deps.owners.fromHandle(commitHandle)
          if (nextOwner === undefined) {
            throw new Error(`forked session "${handle.session.id}" has no owned Session generation after adoption open`)
          }
          // Re-check the fence AFTER the await: the navigation (or the runner
          // lifecycle) may have moved while the adoption retain was in flight.
          // Release the NEW owner exactly once and keep OLD current; the child
          // stays a published catalog identity.
          if (deps.surface.isSurfaceDisposed() || !isNavigationCurrent(expected)) {
            const report = await deps.retirement.retire(nextOwner, 'transition')
            for (const failure of report.failures) {
              deps.diag.error('fork adoption cleanup failed', { session: handle.session.id, phase: failure.phase, error: failure.error })
            }
            return
          }
        }
        // The fork-adoption commit ORDER is fixed by `runForkCommit` (plan §4B):
        // the generation reset runs BEFORE the child is published, exactly like
        // the ordinary transition. A pre-publication seam failure must release
        // the acquired child owner exactly once instead of leaking it; a
        // post-publication seam failure is CONTAINED (the committed child
        // stands — the same contract as the ordinary transition). The recall
        // restore for EVERY pre-publication exit is owned by the single
        // transaction-finally below, never by this catch. The sessionId
        // lookup joins the protected region: a throw from it must also take
        // the exactly-once release path for the open-retained child owner.
        let nextSessionId!: string
        let oldSessionId: string | undefined
        try {
          // The pre-publication metadata snapshot: everything throwable this
          // transaction still needs (the child's id, the source's id for the
          // post-commit retirement) resolves BEFORE the publication, so a
          // metadata failure is a pre-publication failure with an exactly-once
          // child release — never a committed child that cannot retire its
          // source.
          nextSessionId = deps.owners.sessionId(nextOwner)
          oldSessionId = oldOwner === undefined ? undefined : deps.owners.sessionId(oldOwner)
          runForkCommit({
            settlePendingQueueRecalls: deps.surface.settlePendingQueueRecalls,
            settleLocalSubmitAck: deps.surface.settleLocalSubmitAck,
            resetSubmitLatency: deps.surface.resetSubmitLatency,
            bumpGeneration: core.bumpGeneration,
            publishOwner: () => {
              // Every owner-metadata lookup that can throw runs BEFORE the
              // publication; after `setCurrentOwner` the commit point is
              // seamless (plain assignments only).
              const identity = deps.owners.completionIdentity(nextOwner)
              // PR3-B §7.3 (F1): the active-draft drop rides the SAME
              // synchronous publication commit as the ordinary switch —
              // before any post-commit await (source retirement, quiesce,
              // hydration, catalog), so the adopted child's first editable
              // frame never shows the source session's text and no
              // post-hydration keystroke is wiped. The discriminator is the
              // OPAQUE OWNER REF (the same axis as the ordinary seam and the
              // stale-restore policy): only a genuinely replaced owner drops.
              if (oldOwner !== undefined && oldOwner !== nextOwner) {
                deps.surface.dropOutgoingActiveDraft()
              }
              core.setCurrentOwner(nextOwner, nextSessionId)
              // The editor-recall scope follows the same synchronous
              // publication (see the ordinary commit seam).
              deps.surface.beginInputHistoryScope(nextSessionId)
              // Phase 3B / B3-B: see the ordinary commit seam — retire a stale
              // History seat inside the same synchronous publication.
              deps.surface.retireStaleHistorySeat()
              // External review P2-B: same publication commit, same rule.
              if (oldOwner !== undefined && oldOwner !== nextOwner) {
                deps.surface.withdrawReplacedPresentation()
              }
              // PR5 v2 §3C (plan-owner amendment): the operation-owned
              // settlement identity composes the PUBLISHED CHILD session id
              // with the epoch THIS rewind claimed at its admission bump —
              // an immutable claim, never a re-read of the shared counter
              // (a concurrent external bump, e.g. a queued /resume's
              // synchronous pre-gate advance, must not get absorbed into
              // this operation's own identity) and never the picker-open
              // identity (this operation's own adoption legitimately
              // invalidates that one).
              committedNavigation = claimedEpoch === undefined
                ? { sessionId: nextSessionId, navigationEpoch: core.captureNavigationIdentity().navigationEpoch }
                : { sessionId: nextSessionId, navigationEpoch: claimedEpoch }
              forkCommitted = true
              return identity
            },
            setCompletionOwner: deps.surface.setCompletionOwner,
          }, commitHandle)
        } catch (error) {
          if (core.owner() !== nextOwner) {
            // PRE-publication failure: the child owner was retained (possibly
            // through the adoption open) but never committed: release it
            // exactly once and keep OLD current; the child stays a published
            // catalog identity. Mark the ledger so the fork error path never
            // parks this released owner. The deferred recalls are restored by
            // the transaction-finally when this throw unwinds.
            ledger.released = true
            const report = await deps.retirement.retire(nextOwner, 'transition')
            for (const failure of report.failures) {
              deps.diag.error('fork pre-commit owner release failed', { session: handle.session.id, phase: failure.phase, error: failure.error })
            }
            throw error
          } else {
            // POST-publication failure (a synchronous seam after the
            // publication): the child IS committed. Contain it as a failed
            // post-commit step and continue with the adoption (source
            // retirement + surface work): the committed child stands, never a
            // rollback, never a re-park.
            deps.diag.error('fork commit seam failed after publication (child committed)', {
              session: handle.session.id,
              error: safeErrorMessage(error),
            })
          }
        }
        adopted = true
        try {
          onAdopted?.()
        } catch (error) {
          deps.diag.error('fork adoption callback failed after child commit', { error: safeErrorMessage(error), session: nextSessionId })
        }
        if (oldOwner !== undefined && oldSessionId !== undefined) {
          // The retirement now owns the fork's admission pin: it is released
          // only when the source owner has actually been disposed.
          if (pin !== undefined) pin.state.retirementOwnsRelease = true
          const retirement = retireSourceOwnerAfterSettlement(oldSessionId, async () => {
            const report = await deps.retirement.retire(oldOwner, 'transition')
            if (report.failures.length > 0) {
              deps.diag.error('fork old-owner retirement failed (child committed)', { from: oldSessionId, failures: report.failures })
            }
          }, pin?.release ?? ((): void => {}))
          // A DSH command defers (`undefined`): the source owner must stay
          // attached through its own `command/done` append. Every OTHER path
          // (the rewind picker) awaits it here, so the handoff cannot report
          // success until the source is disposed — an immediate open/resume after
          // that success would otherwise race its own retirement.
          if (retirement !== undefined) await retirement
        }
        // A detach-client backend keeps the committed child's Host Turn alive:
        // the forked child is a Host-owned Session that may legitimately be
        // RUNNING when this Client adopts it (the Host fork business interface
        // decides the cut and the child's activity, never the Client), so the
        // adoption must not wait for its idle — the same rule the ordinary
        // transition's committed-child phase follows. The lifecycle-abort skip
        // still runs on BOTH backends: an exit during this phase owns the same
        // skip-the-surface-init behavior.
        let aborted: boolean | 'unobservable' = false
        if (deps.retirement.navigationKind === 'detach-client') {
          aborted = deps.lifecycleSignal.aborted
        } else {
          try {
            aborted = await deps.retirement.whenIdleOrAbort(nextOwner, deps.lifecycleSignal)
          } catch (error) {
            deps.diag.error('fork child quiescence failed after commit', { error: safeErrorMessage(error), session: nextSessionId })
          }
        }
        if (aborted !== true) {
          try {
            await deps.surface.initLiveSession(nextOwner)
          } catch (error) {
            deps.diag.error('fork child initialization failed after commit', { error: safeErrorMessage(error), session: nextSessionId })
          }
        }
        try {
          await deps.surface.refreshLiveCatalog(nextOwner)
        } catch (error) {
          deps.diag.error('fork child catalog refresh failed after commit', { error: safeErrorMessage(error), session: nextSessionId })
        }
      }))
    } catch (error) {
      if (!adopted) throw error
      deps.diag.error('fork post-commit handoff failed', { error: safeErrorMessage(error), session: handle.session.id })
    } finally {
      // The ONE recall-restore authority for every pre-publication fork exit:
      // the gate was held (a finishing writer may have deferred a queue recall
      // against it), so an un-committed adoption must restore those recalls —
      // whether it exited through the refused-navigation return, the adoption
      // open failure, the stale-after-retain cleanup, an invariant failure or
      // a pre-publication commit seam. A committed child keeps its committed
      // recalls (post-publication failures are contained, never restored).
      if (!forkCommitted) deps.surface.settlePendingQueueRecalls(false)
    }
    return adopted ? committedNavigation : undefined
  }

  /**
   * Fork one source Session: capture the navigation identity, claim the
   * operation epoch, pin the source for the whole fork, dispatch the Host fork,
   * apply the supersession fence to every outcome, then adopt or park the child.
   * Never throws.
   */
  const forkSession = async (
    sourceSessionId: string,
    atSeq?: number,
    onAdopted?: () => void,
    pickerIdentity?: RewindNavigationIdentity,
  ): Promise<SessionForkOutcome> => {
    // A rewind picker captures identity BEFORE its overlay can yield to a newer
    // navigation. Validate that capture against the live surface before claiming
    // a fresh operation epoch; A → B → A must not revive A's row.
    const before = core.captureNavigationIdentity()
    const pickerCurrent = pickerIdentity === undefined || isRewindIdentityCurrent(before, pickerIdentity)
    const expectedSessionId = pickerIdentity?.sessionId ?? before.sessionId
    // Reject an obsolete picker before consuming an epoch. A stale A picker must
    // not invalidate a newer legitimate A fork that already admitted.
    if (deps.surface.isSurfaceDisposed() || !pickerCurrent || expectedSessionId !== sourceSessionId) {
      return {
        kind: 'error' as const,
        text: 'the session changed before fork dispatch',
        reason: 'navigation-changed-before-dispatch' as const,
        notificationNavigation: before,
      }
    }
    const claimedEpoch = core.bumpNavigationEpoch()
    const expected: RewindNavigationIdentity = {
      sessionId: expectedSessionId,
      navigationEpoch: claimedEpoch,
    }
    // Pin the source for the WHOLE fork (from admission, before the child is
    // created): an open/resume of it must wait until the fork settles and, if it
    // committed, until the source owner has been retired.
    const pin = core.beginForkSourcePin(sourceSessionId)
    let settleFork!: () => void
    let forkedHandle: SessionHandle | undefined
    // The adoption ownership ledger (plan §8.5): only the owner it names may
    // be parked by the error path — an owner the adoption cleanup already
    // released exactly once must never re-enter the parked pool.
    const adoption: ForkAdoptionLedger = { released: false }
    const pending = new Promise<void>(resolve => { settleFork = resolve })
    trackFork(pending)
    try {
      const result = await deps.lifecycle.fork({
        sourceSessionId,
        ...atSeq === undefined ? {} : { atSeq },
      })
      const outcome = result.outcome
      if (outcome.kind === 'unavailable') {
        // Client-local pre-dispatch refusal: nothing reached the Host, so there
        // is no child to park and no Host settlement to report.
        if (result.ownership === 'superseded' || !isNavigationCurrent(expected)) return { kind: 'success' as const }
        return { kind: 'error' as const, text: outcome.message, reason: 'host-refused' as const, notificationNavigation: expected }
      }
      if (outcome.kind === 'rejected' || outcome.kind === 'indeterminate' || outcome.kind === 'published-with-error') {
        if (outcome.kind === 'published-with-error') parkForkOwner(outcome.handle)
        // A Direct failure is still returned as `current` because Direct has no
        // transport generation to supersede it. Navigation owns whether that
        // failure may be shown, so apply the same fence as success.
        if (result.ownership === 'superseded' || !isNavigationCurrent(expected)) {
          return { kind: 'success' as const }
        }
        // The refusal happened INSIDE this fork's claim: its notification
        // fence is the ADMISSION identity (the claimed epoch), not the
        // picker-open identity the admission bump already invalidated.
        return { kind: 'error' as const, text: `${outcome.error.message} (${outcome.error.code})`, reason: 'host-refused' as const, notificationNavigation: expected }
      }
      if (result.ownership === 'superseded' || !isNavigationCurrent(expected)) {
        parkForkOwner(outcome.handle)
        return { kind: 'success' as const, text: `forked as ${outcome.handle.session.id}; navigation stayed on the newer session` }
      }
      forkedHandle = outcome.handle
      // §3C (review R6-5): adoptFork returns the identity captured INSIDE
      // the publication commit — the caller consumes exactly that SAVED
      // value, never a re-capture after the post-commit awaits (source
      // retirement, child quiescence, catalog refresh) during which an
      // external navigation may have bumped the epoch.
      const adoptedNavigation = await adoptFork(outcome.handle, expected, onAdopted, pin, adoption, claimedEpoch)
      if (adoptedNavigation === undefined) {
        return { kind: 'success' as const, text: `forked as ${outcome.handle.session.id}` }
      }
      deps.surface.clearUnpinnedDrafts()
      // (PR3-B §7.3: the ACTIVE-draft drop moved onto the adoption's
      // synchronous publication commit — see the publishOwner seam above.)
      return { kind: 'success' as const, text: `forked as ${outcome.handle.session.id}`, adoptedNavigation }
    } catch (error) {
      // An owner the adoption cleanup already released exactly once must not
      // be parked again (a disposed Direct handle in the pool would be
      // claimed as a live owner later, and the exit drain would double-retire).
      if (forkedHandle !== undefined && !adoption.released) parkForkOwner(forkedHandle)
      if (!isNavigationCurrent(expected)) return { kind: 'success' as const }
      if (forkedHandle !== undefined) {
        // The Host fork already published the child; the failure happened
        // while ADOPTING it (the open, or a commit seam). Report the truthful
        // outcome — the child exists, must not be redispatched and is not
        // adopted now — instead of disguising it as "the fork did not happen".
        return {
          kind: 'error' as const,
          text: `forked as ${forkedHandle.session.id}, but adopting the child session failed: ${safeErrorMessage(error)}`,
          reason: 'adoption-failed' as const,
          // Post-adoption failure: THIS claim's currency is the fence.
          notificationNavigation: expected,
        }
      }
      return { kind: 'error' as const, text: `fork failed: ${safeErrorMessage(error)}`, reason: 'fork-failed' as const, notificationNavigation: expected }
    } finally {
      settleFork()
      // If the fork committed, its source retirement owns the pin (released when
      // that retirement finishes); otherwise the source was never detached and
      // is immediately reopenable.
      if (!pin.state.retirementOwnsRelease) pin.release()
    }
  }

  /**
   * Run the first-session commit (plan §4C: publish → completion → await the
   * child's idle → bump → init). Post-create initialization is best-effort: the
   * child is committed, so a failure is warned (never a fallback), the same
   * retire-warn-only semantics as every other transition.
   */
  const commitFirstSession = async (handle: SessionHandle): Promise<boolean> => {
    const childOwner = deps.owners.fromHandle(handle)
    if (childOwner === undefined) throw new Error('first-session create published a handle without an owned Session generation')
    return runFirstSessionCommit({
      publishOwner: () => {
        core.setCurrentOwner(childOwner, deps.owners.sessionId(childOwner))
        // The editor-recall scope follows the same synchronous publication:
        // the deferred first session's hydration reseeds ↕ recall afterwards,
        // and the sessionless submission that CREATED it was accepted in the
        // sessionless pool BEFORE this create — the seam ADOPTS those pending
        // entries instead of clearing them, because their row is written under
        // THIS Session and can therefore not be in the snapshot yet.
        deps.surface.beginInputHistoryScope(deps.owners.sessionId(childOwner))
        // Phase 3B / B3-B: the first published Session kills a sessionless
        // History seat even though no id string moved (the capture's
        // subject-undefined branch fails the moment an owner exists). The
        // generation bump below would also catch it; retiring here keeps the
        // commit's own first frame clean.
        deps.surface.retireStaleHistorySeat()
        return deps.owners.completionIdentity(childOwner)
      },
      setCompletionOwner: deps.surface.setCompletionOwner,
      bumpGeneration: core.bumpGeneration,
      quiesceChild: async () => {
        try {
          return (await deps.retirement.whenIdleOrAbort(childOwner, deps.lifecycleSignal)) === true
        } catch (error) {
          deps.diag.warn('first session whenIdle failed', { error: safeErrorMessage(error) })
          return false
        }
      },
      initChild: async () => {
        try {
          await deps.surface.initLiveSession(childOwner)
        } catch (error) {
          deps.diag.warn('first session surface rebuild failed', { error: safeErrorMessage(error) })
        }
      },
    }, handle)
  }

  /**
   * Publish the startup-resume owner (plan §4D). The publication itself is
   * SYNCHRONOUS and transport-neutral: the injected `SessionOwnerAccess`
   * resolves the owner whether the resumed handle is Direct or Remote; the
   * runner's `preMountQuiesce` hook is consulted only once an owner exists —
   * a sessionless (deferred) startup therefore gains no microtask yield here.
   */
  const publishResumedOwner = (
    handle: SessionHandle | undefined,
    preMountQuiesce: (owner: SessionOwnerRef) => Promise<unknown> | undefined,
  ): Promise<unknown> | undefined =>
    runResumeCommit({
      publishOwner: (owner) => {
        const resumed = owner as SessionHandle | undefined
        const nextOwner = resumed === undefined ? undefined : deps.owners.fromHandle(resumed)
        // NO editor-recall scope call here: the resume publication happens
        // BEFORE the surface is mounted, so the mounted app's SESSIONLESS POOL
        // scope is already open and the resumed owner's hydration reseed closes
        // it. That is what covers the Remote startup resume, whose
        // `remote.read` await leaves the terminal accepting input: the entries
        // accepted in that window are pool entries and the resumed owner's
        // reseed adopts them (the Direct startup has no await before the reset,
        // and the TSP renderer holds input until bind — both stay empty).
        core.setCurrentOwner(nextOwner, nextOwner === undefined ? undefined : deps.owners.sessionId(nextOwner))
        // External review P2-B: a resume publishes a new owner too.
        if (nextOwner !== undefined) deps.surface.withdrawReplacedPresentation()
        return nextOwner === undefined ? undefined : deps.owners.completionIdentity(nextOwner)
      },
      setCompletionOwner: deps.surface.setCompletionOwner,
      preMountQuiesce: () => {
        const owner = core.owner()
        return owner === undefined ? undefined : preMountQuiesce(owner)
      },
    }, handle)
  /**
   * The synchronous shutdown preparation: ask the retirement port to cancel the
   * CURRENT owner's work BEFORE the Host tree is torn down (the port keeps that
   * exactly-once with its lifecycle-abort cancel).
   */
  const preCancelOwnedSession = (): void => {
    const owner = core.owner()
    if (owner !== undefined) deps.retirement.preCancel(owner)
  }

  /**
   * Report the MERGED retirement (the current owner PLUS every parked owner), so
   * a parked owner's failure — a durability failure above all — reaches the user
   * even when the current owner retired cleanly. The per-owner failure
   * diagnostics were already logged by the owner that produced them.
   */
  const reportRetirement = (report: SessionRetirementReport): void => {
    if (report.failures.length > 0) deps.surface.warnRetirement(report)
    deps.diag.info('retire complete', { failures: report.failures.length })
  }

  const retireOwnedSession = (): Promise<SessionRetirementReport> => {
    if (retirementPromise !== undefined) return retirementPromise
    // Every entry (interactive exit, HMR unload, fatal teardown) shares the ONE
    // synchronous pre-cancel before the memoized retirement is created.
    preCancelOwnedSession()
    retirementPromise = (async (): Promise<SessionRetirementReport> => {
      const retire = async (): Promise<SessionRetirementReport> => {
        // Re-read the CURRENT owner INSIDE the gate (plan §4.1): a transition
        // committed while the shutdown waited must be the one retired, never a
        // pre-cancelled capture.
        const owner = core.owner()
        if (owner === undefined) return { failures: [], durabilityFailure: undefined }
        const ownerSessionId = deps.owners.sessionId(owner)
        const report = await deps.retirement.retire(owner, 'shutdown')
        // Attribute each failure to the owner it came from (the parked owners
        // log their own, with their own ids).
        for (const failure of report.failures) {
          deps.diag.error('retire phase failed', {
            session: ownerSessionId,
            phase: failure.phase,
            error: failure.error,
          })
        }
        return report
      }
      try {
        // Serialize against an in-flight session transition: the gate queue is
        // FIFO, so this no-op task waits for a running transition to settle. The
        // barrier freezes TUI writers for the retirement's write boundary. Each
        // ledger is re-snapshotted until it is empty (a drain can be extended
        // while it runs).
        let forks = [...pendingForks]
        while (forks.length > 0) {
          await Promise.allSettled(forks)
          forks = [...pendingForks]
        }
        // A `/fork` command's SOURCE Session is retired by ITS OWN command
        // settlement, never by navigation: wait for every in-flight command
        // first (that `command/done` append included), then for every source
        // retirement it queued.
        let settlement = [...pendingSettlementWork]
        while (settlement.length > 0) {
          await Promise.allSettled(settlement)
          settlement = [...pendingSettlementWork]
        }
        let sourceRetirements = [...pendingSourceRetirements]
        while (sourceRetirements.length > 0) {
          await Promise.allSettled(sourceRetirements)
          sourceRetirements = [...pendingSourceRetirements]
        }
        return await core.gate.run(() => core.barrier.runTransition(async () => {
          const current = await retire()
          const parked = await deps.retirement.retireParked()
          const report: SessionRetirementReport = {
            failures: [...current.failures, ...parked.failures],
            durabilityFailure: current.durabilityFailure ?? parked.durabilityFailure,
          }
          reportRetirement(report)
          return report
        }))
      } catch (error) {
        // Defensive: a reentrant gate/barrier means a transition is STILL active
        // — retiring now would race it. SKIP the retirement (the process is
        // exiting; the appExit watchdog bounds it) and report it as a
        // COORDINATOR failure: no backend retirement phase ran, so it must not
        // masquerade as one.
        const reason = safeErrorMessage(error)
        deps.diag.error('retire barrier failed', { error: reason })
        deps.surface.warnRetirementSkipped(reason)
        return { failures: [], durabilityFailure: undefined }
      } finally {
        deps.diag.dispose()
      }
    })()
    return retirementPromise
  }

  let creating: Promise<void> | undefined

  /**
   * Create the FIRST session lazily — the first user message triggers it
   * (deferred session creation). Opening the TUI with no `--session` carries zero
   * session side-effects: no agent, no log, no persistence. The creation is a
   * session transition too, so it runs inside the single-writer gate and can
   * never interleave with an ordinary transition already in flight.
   */
  const ensureSession = async (): Promise<void> => {
    if (core.owner() !== undefined) return
    if (creating !== undefined) return creating
    creating = core.gate.run(() => core.barrier.runTransition(async () => {
      // The Host Workspace pre-selection precedes every Session side-effect: a
      // refused/unavailable workspace leaves the surface sessionless without a
      // Session create, an opening journal entry or a consumed draft.
      let workspace: ResolvedWorkspaceSelection
      try {
        workspace = await deps.lifecycle.resolveWorkspace(deps.surface.initialWorkspaceIntent(), deps.lifecycleSignal)
      } catch (error) {
        if (deps.lifecycleSignal.aborted
          || (error instanceof WorkspaceSelectionError && error.kind === 'superseded')) {
          // A superseded/aborted pre-selection publishes nothing: no notice, no
          // Session. The surface stays sessionless.
          deps.diag.warn('first session workspace selection superseded', {
            settlement: error instanceof WorkspaceSelectionError ? error.kind : 'aborted',
            code: error instanceof WorkspaceSelectionError ? error.code : undefined,
          })
          return
        }
        // A refused/unavailable workspace is a real first-session failure under
        // the existing sessionless contract (notice + retry on the next input);
        // NO Session was dispatched and nothing is retried automatically.
        const message = safeErrorMessage(error)
        deps.surface.reportFirstSessionCreateFailure(message)
        throw error
      }
      // The pre-selection awaited Host IO: re-check the two existing authorities
      // before creating anything. A lifetime abort wins; a Session that appeared
      // while the selection ran makes this attempt obsolete.
      deps.lifecycleSignal.throwIfAborted()
      if (core.owner() !== undefined) return
      const launched = await deps.surface.launchComposition()
      if (launched.failure !== undefined) deps.surface.setResumeFailure(launched.failure)
      // The first-session creation follows the same transaction shape as every
      // other transition: the id is pre-generated and the DSH create publishes
      // the session; a create failure leaves the surface sessionless — the next
      // user input starts a NEW attempt (no pin, no second fresh fallback).
      let created: SessionHandle
      try {
        const sessionId = deps.surface.newSessionId()
        deps.surface.beginOpening(sessionId)
        // Quiesce EVERY sessionless `/model` default write (and its fenced
        // correction) BEFORE the create: the Direct adapter captures the settled
        // persisted Host default for Agent activation. A failed latest intent is
        // NOT seeded — the fresh Session uses the actual Host default, not a
        // fabricated choice.
        await deps.surface.awaitPendingDefaultWrite(deps.lifecycleSignal)
        deps.lifecycleSignal.throwIfAborted()
        created = requireCreated(await deps.lifecycle.create({
          sessionId,
          // The semantic `agentPreset` is the sole preset authority; the Direct
          // adapter writes the actually composed preset into the durable header
          // (never a duplicated meta field). The Host Workspace id is the ONE
          // directory authority: no cwd crosses this request.
          workspaceId: workspace.workspaceId,
          agentPreset: launched.composition.agentPreset,
          signal: deps.lifecycleSignal,
        }))
      } catch (error) {
        if (error instanceof LifecycleError && error.ownership === 'superseded') {
          // A superseded first-session create is UI-silent — no degradation
          // notice; the surface simply stays sessionless.
          deps.diag.warn('first session creation superseded', {
            settlement: error.settlement,
            publishedSessionId: error.publishedSessionId,
            requestedSessionId: error.requestedSessionId,
          })
          return
        }
        // A failed create leaves the surface sessionless — the next user input
        // starts a NEW attempt (no pin, no second fresh fallback). Preset mount
        // failures are no longer auto-replaced; the resolve-level fallback
        // (requested → default) already happened inside `launchComposition`,
        // BEFORE any DSH call.
        const message = safeErrorMessage(error)
        deps.surface.reportFirstSessionCreateFailure(message)
        throw error
      }
      const opening = deps.surface.currentOpening()
      const committed = await commitFirstSession(created)
      if (!committed) {
        // The lifecycle aborted during the first-session quiesce: the surface is
        // disposed and the retirement takes over — skip the surface
        // initialization below.
        return
      }
      if (opening !== undefined) deps.surface.clearOpening(opening)
      const owner = core.owner()
      if (owner === undefined) throw new Error('first-session commit published no owner')
      // The first real session's catalog comes from the REAL owner: await the
      // coordinator refresh so the first submission rides the live scope (the
      // probe snapshot is never execution authorization). Provider issues degrade
      // fields inside the snapshot; a failed attempt is warned, never fatal.
      try {
        await deps.surface.refreshLiveCatalog(owner)
      } catch (error) {
        deps.diag.warn('first session catalog refresh failed', { error: safeErrorMessage(error) })
      }
      deps.surface.notifyResumeFailure()
    })).finally(() => {
      creating = undefined
      deps.surface.resetOpening()
    })
    return creating
  }
  return {
    withWriter,
    withControl,
    interrupt,
    withNavigation,
    transitionTo,
    switchSession,
    switchSessionOutcome,
    adoptFork,
    forkSession,
    parkForkOwner,
    isNavigationCurrent,
    trackFork,
    hasPendingForks,
    trackSettlementWork,
    beginCommandSettlement,
    abortCommandSettlement,
    settleCommandSettlement,
    commitFirstSession,
    ensureSession,
    publishResumedOwner,
    retireOwnedSession,
    preCancelOwnedSession,
  }
}
