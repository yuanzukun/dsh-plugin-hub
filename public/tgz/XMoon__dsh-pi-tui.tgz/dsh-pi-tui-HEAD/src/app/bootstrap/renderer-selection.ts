/**
 * PR3-A: the ONE experimental renderer selection, extracted from the
 * bootstrap composition root so tests can drive the DECISION (and its
 * fallback/fatal branches) without patching the composition body.
 *
 * Production behaviour is unchanged: `DSH_PI_TUI_RENDERER=tsp` lazily
 * imports the TSP renderer and runs the official SDK connect BEFORE PiTui
 * could take stdin; `null` yields no mount (PiTui); a connect throw
 * propagates to the caller (the runner fatal path).
 * @module @xmoon76/dsh-pi-tui/app/bootstrap/renderer-selection
 */

import type { StatusSnapshotReader } from '../../domain/status/types.ts'
import type { TspNativeFooterConfig } from '../../domain/footer/tsp-native-config.ts'
import type { SurfaceRendererMount } from '../surface/runtime.ts'

/** What the selection needs from the composition root. */
/** Whether this boot asked for the experimental TSP renderer. The composition
 *  reads the SAME predicate: application-side terminal writes are suspended only
 *  for a boot that actually attempts TSP, so the default PiTui path never loses
 *  output in an async selection window. */
export function tspRequested(env: { readonly DSH_PI_TUI_RENDERER?: string | undefined }): boolean {
  return env.DSH_PI_TUI_RENDERER === 'tsp'
}

export interface RendererSelectionDeps {
  /** Diagnostics sink for the selection's own lifecycle facts. */
  readonly log: (message: string, fields?: Record<string, unknown>) => void
  /**
   * The lazy TSP connector (the production default imports the renderer
   * module and connects through the official SDK). Tests inject a scripted
   * pane; returning `undefined` mirrors `connect() === null`.
   */
  readonly connectTsp: () => Promise<{
    readonly display: import('../surface/display-seam.ts').SurfaceDisplaySeam
    /** B3-A1: the renderer's Task Center presentation sink (the internal
     *  native Work Hub on TSP). It carries presentation only; the renderer's
     *  own capability flag decides production reachability. */
    readonly taskPresentation: import('../surface/task-presentation-port.ts').TaskCenterPresentationPort
    readonly composer: import('../submission/composer-port.ts').SubmissionComposerPort
    readonly modelPresentation?: import('../command/model-presentation.ts').ModelPresentation | undefined
    readonly presetPresentation?: import('../command/preset-presentation.ts').PresetPresentation | undefined
    /** M5-W PR-C: the native `/web` presenter. */
    readonly webPresentation?: import('../command/web-access-presentation.ts').WebAccessPresentation | undefined
    readonly sessionBrowserPresentation?: import('../command/session-browser-presentation.ts').SessionBrowserPresentation | undefined
    readonly interaction: import('../surface/interaction-presenter.ts').SurfaceInteractionPresenter
    readonly bindInput: (handlers: import('../surface/runtime.ts').SurfaceInputBinding) => void
    /**
     * TSP I-C: publish ONE effective slash-command catalog commit onto the
     * connected renderer. The composition root forwards it verbatim; it holds no
     * catalog, no provider and no candidate state of its own.
     */
    readonly installCommandCompletions: (
      installation: import('../surface/runtime.ts').TspCommandCompletionInstallation,
    ) => void
    /**
     * TSP I-D: install the ONE inline-attachment stager on the connected
     * renderer. Forwarded verbatim like the catalog commit above; this
     * projection holds no stager, stake, draft or attachment state. The surface
     * runtime's mount slot is OPTIONAL, so THIS forward is what makes the
     * production TSP composition carry the stager at all.
     *
     * Optional on the CONNECTOR INPUT so a scripted test connector can express
     * "no attachment plane"; the production connector below declares it
     * REQUIRED, because a connected TSP renderer always carries it.
     */
    readonly installInlineAttachmentStager?: (
      stager: import('../surface/runtime.ts').TspInlineAttachmentStager,
    ) => void
    /**
     * PR-C: install the ONE image binding (the mount's loader + scope
     * sampler) on the connected renderer. It is SYNCHRONOUS and ONE-TIME:
     * the renderer needs it before its first tool projection.
     */
    readonly bindImages: (binding: import('../surface/runtime.ts').SurfaceImageBinding) => void
    /**
     * TSP-7 PR-A: install the read-only status reader ONCE, before the first
     * image binding. It carries presentation capability only — no render, no
     * store subscription, no business write — so a later `bindImages` failure
     * still leaves the existing acquired-session release path intact.
     */
    readonly bindStatusReader: (reader: StatusSnapshotReader) => void
    /**
     * TSP-7 PR-D: install the ONE-SHOT read-only footer config. Called at
     * most once, at the mount — a snapshot taken at boot; the TSP renderer
     * re-reads nothing later (a settings change needs a TSP restart).
     */
    readonly bindNativeFooterConfig: (config: TspNativeFooterConfig) => void
    readonly dispose: () => Promise<void>
  } | undefined>
  /** The environment read (production: `process.env`). */
  readonly env: Record<string, string | undefined>
  /**
   * TSP-7 PR-D: the boot-time footer projection source. Evaluated ONLY when
   * the TSP mount actually runs (never on the PiTui path or a declined
   * connect) — the composition root supplies the settings owner's read-only
   * resolver here.
   */
  readonly resolveFooterConfig: () => TspNativeFooterConfig
}

/**
 * Select the renderer once. Returns the mount for `surface.start`, or
 * `undefined` for the unchanged PiTui path.
 */
export async function selectRendererMount(deps: RendererSelectionDeps): Promise<SurfaceRendererMount | undefined> {
  if (!tspRequested(deps.env)) return undefined
  const tsp = await deps.connectTsp()
  if (tsp === undefined) {
    deps.log('tsp renderer unavailable (SDK declined); mounting PiTui', {})
    return undefined
  }
  deps.log('tsp renderer selected', {})
  // Ownership handshake: `mount()` transfers the SDK session to the surface's
  // ordered disposal; `releaseUnmounted()` closes it when the mount was
  // rejected or never ran (idempotent, and inert after a transfer).
  return {
    // PR-C: the image binding is installed SYNCHRONOUSLY, exactly once, at
    // the mount — before the surface's first transcript projection. The
    // renderer keeps the ONE loader of this mount; the wrapper never builds
    // a second one.
    // TSP-7 PR-A: the status reader is installed FIRST and synchronously — a
    // renderer that later fails its image binding still releases through the
    // existing acquired-session path, and no status subscription is created.
    // TSP-7 PR-D: the footer config binds exactly once at the mount, BEFORE
    // the first status commit can paint a row (a resolver throw propagates —
    // the mount-failure release path owns the session).
    mount: (binding, statusReader) => {
      tsp.bindStatusReader(statusReader)
      tsp.bindNativeFooterConfig(deps.resolveFooterConfig())
      tsp.bindImages(binding)
      return {
        display: tsp.display,
        taskPresentation: tsp.taskPresentation,
        composer: tsp.composer,
        modelPresentation: tsp.modelPresentation,
        presetPresentation: tsp.presetPresentation,
        webPresentation: tsp.webPresentation,
        sessionBrowserPresentation: tsp.sessionBrowserPresentation,
        interaction: tsp.interaction,
        bindInput: (handlers) => tsp.bindInput(handlers),
        // TSP I-C: the ONE catalog commit forwarded to the renderer's own seat.
        // No catalog, no provider and no candidate list is held here.
        installCommandCompletions: (installation) => tsp.installCommandCompletions(installation),
        // TSP I-D: the ONE inline-attachment stager forwarded the same way. The
        // surface runtime's mount slot is optional, so a projection that forgot
        // this member would silently ship a mount with no attachment intake.
        installInlineAttachmentStager: (stager) => tsp.installInlineAttachmentStager?.(stager),
        dispose: () => tsp.dispose(),
      }
    },
    releaseUnmounted: () => tsp.dispose(),
  }
}

/** The PRODUCTION connector inputs: lazy import + the official SDK connect. */
export interface ProductionTspConnectorDeps {
  readonly cwd: string
  readonly requestExit: () => void
  readonly onFatal: (error: unknown) => void
  readonly log: (message: string, fields?: Record<string, unknown>) => void
  readonly logError: (message: string, fields?: Record<string, unknown>) => void
  /**
   * The official SDK connect boundary (`TspRendererOptions.connect`): the
   * production wiring leaves it unset, so the renderer module uses its own
   * shipped `connect`. Tests supply the scripted pane HERE, so the REAL
   * `connectTspRenderer` — and with it the owned-session mount-failure release
   * and its secondary-restoration diagnostics — stays in the path instead of
   * being bypassed by a hand-rolled mount.
   */
  readonly connect?: NonNullable<Parameters<(typeof import('../../tui/tsp/session.ts'))['connectTspRenderer']>[0]['connect']>
  /**
   * PR-B1: the presentation bridge over the REGISTERED tool definitions. It is
   * forwarded to the renderer so a tool row's target KIND can be proven from
   * the tool's own registered view. It changes no displayed string.
   */
  readonly toolPresenter?: import('../../tui/transcript/tool-presentation.ts').ToolPresenter
  /**
   * PR3: the ONE Client-local clipboard callback for a published visual's
   * authoritative payload. The composition root injects the EXISTING
   * `ClientActions.copySelection`; this connector forwards it unchanged to the
   * renderer, which owns no clipboard policy of its own.
   */
  readonly copyVisual: (text: string) => Promise<boolean>
}

/** The PRODUCTION connector: lazy import + the official SDK connect. */
export function productionTspConnector(
  deps: ProductionTspConnectorDeps,
): () => Promise<{
  readonly display: import('../surface/display-seam.ts').SurfaceDisplaySeam
  readonly taskPresentation: import('../surface/task-presentation-port.ts').TaskCenterPresentationPort
  readonly composer: import('../submission/composer-port.ts').SubmissionComposerPort
  readonly modelPresentation?: import('../command/model-presentation.ts').ModelPresentation | undefined
  readonly presetPresentation?: import('../command/preset-presentation.ts').PresetPresentation | undefined
  /** M5-W PR-C: the native `/web` presenter. */
  readonly webPresentation?: import('../command/web-access-presentation.ts').WebAccessPresentation | undefined
  readonly sessionBrowserPresentation?: import('../command/session-browser-presentation.ts').SessionBrowserPresentation | undefined
  readonly interaction: import('../surface/interaction-presenter.ts').SurfaceInteractionPresenter
  readonly bindInput: (handlers: import('../surface/runtime.ts').SurfaceInputBinding) => void
  /** TSP I-C: the ONE catalog commit forwarded to the renderer's own seat (see
   *  the connector input above). Required: a connected TSP renderer always
   *  carries the seat, and a test connector is that contract's fake. */
  readonly installCommandCompletions: (
    installation: import('../surface/runtime.ts').TspCommandCompletionInstallation,
  ) => void
  /** TSP I-D: the ONE inline-attachment stager forwarded to the renderer's own
   *  mount (see the connector input above). Required: a connected TSP renderer
   *  always carries the attachment plane, and a test connector is that
   *  contract's fake. */
  readonly installInlineAttachmentStager: (
    stager: import('../surface/runtime.ts').TspInlineAttachmentStager,
  ) => void
  readonly bindImages: (binding: import('../surface/runtime.ts').SurfaceImageBinding) => void
  readonly bindStatusReader: (reader: StatusSnapshotReader) => void
  readonly bindNativeFooterConfig: (config: TspNativeFooterConfig) => void
  readonly dispose: () => Promise<void>
} | undefined> {
  return async () => {
    const { connectTspRenderer } = await import('../../tui/tsp/session.ts')
    return connectTspRenderer(deps)
  }
}
