/**
 * The transport-neutral application-composition result (M3-4 PR1): what the
 * application composition root (`app/bootstrap.ts`) needs from whichever
 * backend application runtime the internal selection seam picked — the
 * semantic `Backend` plus the Session owner pair the transport-neutral session
 * runtime consumes, and the LATE transport disposal slot.
 *
 * This is NOT a new Backend SDK: it only groups the already-required
 * application composition ownership. Direct-only helpers (compose/agentFor/
 * queueAgentFor/modelSelections/...) stay on `DirectApplicationRuntime`;
 * later M3-4 PRs replace their individual Direct assumptions through their
 * owning domains, never through a speculative neutral facade here.
 *
 * `disposeTransport()` disposes adapter/transport composition AFTER the
 * application/session owners have completed their own retirement; for Direct
 * it is a no-op (the Direct backend owns no transport graph). It must never
 * retire the currently selected Session — that remains `app/session`
 * ownership.
 *
 * Transport-neutral by contract: this module must not import
 * `@deepseek-ai/dsh-agent`, `app/remote/**` or `runtime/remote/**`.
 * @module @xmoon76/dsh-pi-tui/app/application-runtime
 */

import type { PresentationReader } from '../runtime/presentation-read-port.ts'
import type { SessionReader } from '../runtime/session-reader-port.ts'
import type { ImageAttachmentRefLike } from '../domain/media/types.ts'
import type { TerminalProgressOutcome } from '../domain/terminal-progress/settings.ts'
import type { SubmissionPresentationSource } from './submission/presentation.ts'
import type { Backend, BackendKind } from '../runtime/backend.ts'
import type { SessionOwnerAccess, SessionOwnerRetirement } from './session/owner-access.ts'
import type { PiTuiExtensionService } from '../extensions.ts'

/**
 * The one selected application runtime core: the common inputs the bootstrap
 * binds into the session runtime (`owners`/`retirement`/`lifecycle` via
 * `backend.sessionLifecycle`) plus the selected-runtime teardown hook.
 */
export interface SelectedApplicationRuntime {
  readonly kind: BackendKind
  readonly backend: Backend
  readonly owners: SessionOwnerAccess
  readonly retirement: SessionOwnerRetirement

  /**
   * Synchronously close the pre-dispatch write admission at the surface-stop
   * boundary: a write parked before dispatch (the serializer window) is then
   * refused instead of being admitted after the surface stopped. Idempotent.
   * Absent on Direct (the Direct owner retires its own in-flight writes).
   */
  stopSurfaceAdmission?: () => void

  /**
   * Dispose adapter/transport composition after application/session owners
   * have completed their own retirement. Idempotent; error-preserving (a
   * step's failure never skips the remaining steps).
   */
  disposeTransport(): Promise<void>
}

/**
 * The detached startup facts the Remote Client-local UI subtree consumes
 * (M3-6 PR1 D2): plain data only. It must never contain
 * `markSurfaceMounted`, `appExit`, a Host Context, a Loader,
 * `profileContext`, Host services or callbacks — the Client Context gets a
 * frozen copy of exactly these two optional fields.
 */
export interface ClientUiStartupFacts {
  readonly sessionId?: string
  readonly presetId?: string
}

/**
 * The Remote branch's application presentation sources (M3-4 PR2/PR4),
 * declared STRUCTURALLY here so the composition root (`app/bootstrap.ts`)
 * consumes the bundle without any static `app/remote/**` edge — the real
 * bundle is assembled inside `app/remote/presentation-source.ts` from the
 * ONE aggregate and satisfies these shapes by construction.
 */
/**
 * The Remote branch's branch-specific command authority read (PR4 §D1):
 * Host command + human-skill metadata behind one generation-fenced
 * snapshot, declared STRUCTURALLY so the composition root stays
 * transport-clean. The real bundle is assembled inside
 * .
 */
export interface RemoteCommandSourceFace {
  read(sessionId: string, signal?: AbortSignal): Promise<import('../runtime/surface-authority-port.ts').SurfaceAuthoritySnapshot | undefined>
  /** The commands-only, generation-fenced metadata read (PR4 §2.2). */
  readCommands(sessionId: string, signal?: AbortSignal): Promise<import('../runtime/surface-authority-port.ts').SurfaceAuthoritySnapshot['commands'] | undefined>
  /** The §2.2/§16 admission transport identity (generation + exact
   *  binding), captured ONCE before the provider reads. */
  captureTransportToken(sessionId: string): unknown
  /** Whether the captured transport identity is still live (the COMBINED
   *  multi-provider settle re-checks this after every await). */
  isTransportTokenCurrent(sessionId: string, token: unknown): boolean
  /** Current official Connection generation; undefined while disconnected
   *  (M3-6 PR2). Direct delegation only — the SAME official snapshot
   *  object by identity, never a cached/normalized copy. */
  connectionGeneration(): unknown | undefined
  /** Subscribe the official Connection generation observable (M3-6 PR2):
   *  the invalidation hint the Client-local CommandSurface consumes. The
   *  returned unsubscribe is the official one, unchanged. */
  subscribeConnectionGeneration(listener: () => void): () => void
}

export interface RemoteApplicationSources {
  /** The ONE shared presentation reader (the M3-3A Remote adapter). */
  readonly presentationReader: PresentationReader
  /** The official pending-submissions optimistic echo source. */
  readonly submissionPresentation: SubmissionPresentationSource
  /** The eventSource live-ingress subscription factory. */
  readonly liveIngress: RemoteLiveIngressFactory
  /** The official Session-scoped facts (sessionStatus/plan/running). */
  readonly sessionFacts: RemoteSessionFactsSource
  /** The branch-specific command authority read (PR4). */
  readonly commandSource: RemoteCommandSourceFace
  /** The M3-5 PR2 Task Center read source (descendant catalog + Job roster). */
  readonly task: RemoteTaskApplicationSource
  /** The M3-5 PR2 child-view source (retained child reference + read/ingress). */
  readonly childView: import('./surface/viewer-runtime.ts').ViewerChildSource<import('./surface/session-presentation.ts').SessionPresentationEvent>
  /** The M3-5 PR2 durable image read of the OWNING presentation's retained
   *  Session (exact scoped lifetime, never an ambient "currently displayed"
   *  subject). */
  readonly attachments: RemoteAttachmentSource
  /** The R2 Remote terminal-progress Host evidence stream (the ONLY main
   *  terminal-outcome authority on this branch). */
  readonly terminalProgress: RemoteTerminalProgressSource
}

/**
 * The exact display-subject lifetime a durable attachment read is authorized
 * under: the Connection generation at capture time plus the EXACT SessionBinding
 * object the owning presentation was created with. A same-binding Connection
 * generation rollover is the official ADOPTION (the retained binding survives),
 * while a DIFFERENT binding retires the presentation.
 */
export interface RemoteTransportLifetime {
  readonly generation: unknown
  readonly binding: unknown
}

/**
 * One authorized Remote main-Agent progress fact (R2 §7.1/§7.2): the Host
 * already classified the outcome with the shared interval fold, so the Client
 * only carries the proven `(running, outcome)` pair. `kind` distinguishes the
 * opening authoritative SNAPSHOT (display truth only, NEVER completion
 * evidence) from a real Host `update` edge.
 */
export interface RemoteMainProgressFact {
  readonly kind: 'snapshot' | 'update'
  /**
   * Whether this frame opens a NEW interval lineage (a fresh watch with no
   * provable continuity, a Host remount, or an Agent replacement) instead of
   * continuing one this Client already observed. The display adopts both, but a
   * restart MUST re-baseline the completion controller: a previous running edge
   * may never pair with this frame's `idle` into a false completion.
   */
  readonly restart: boolean
  readonly running: boolean
  /** The SAME settled-outcome vocabulary the Direct adapter uses (declared
   *  once in `domain/terminal-progress/settings.ts`). */
  readonly outcome: TerminalProgressOutcome
}

/**
 * The neutral Remote terminal-progress source (R2 §7.1): the ONE Host evidence
 * stream of the current main session, fenced by the exact transport identity.
 * The CALLER owns the iteration, so cancellation and failure ownership stay
 * with the bootstrap (the same shape as the live-ingress subscription).
 */
export interface RemoteTerminalProgressSource {
  /**
   * Open the Host evidence stream of one session.
   * @throws when the session has no retained binding, when a frame violates the
   * private contract, or when the transport identity moved mid-stream.
   */
  open(sessionId: string, signal: AbortSignal): AsyncIterable<RemoteMainProgressFact>
}

/**
 * The neutral Remote durable-image read face (M3-5 PR2 Step 9): resolve one
 * attachment through the EXACT retained binding the OWNING presentation was
 * authorized under. There is no Host attachment shortcut and no cold retain on
 * this path. `expectedLifetime` is REQUIRED — the seam itself expresses the
 * owning-presentation invariant, so there is no "read through whatever binding
 * the Session has now" path: a missing/malformed lifetime, a different binding,
 * or a missing binding fails closed BEFORE the Session is touched.
 */
export interface RemoteAttachmentSource {
  readDurableImage(
    sessionId: string,
    attachment: ImageAttachmentRefLike,
    expectedLifetime: RemoteTransportLifetime,
  ): Promise<{ ref: unknown; data: Uint8Array }>
}

/**
 * The neutral Remote Task Center source face (M3-5 PR2): the semantic Task
 * descendant read plus the official Client model's roster/activity reads and
 * invalidation subscriptions. Declared structurally here so the composition
 * root consumes it without any static `app/remote/**` edge.
 */
export interface RemoteTaskApplicationSource {
  /** The full descendant catalog + root Job roster read. */
  readDescendants(
    parentSessionId: string,
    signal?: AbortSignal,
  ): Promise<import('../runtime/task-read-port.ts').TaskReadSnapshot | undefined>
  /** The CURRENT official Job roster of one root session. */
  jobs(sessionId: string): readonly import('../runtime/task-read-port.ts').TaskJobEntry[]
  /**
   * The CURRENT official activity of one descendant, read from the Session-list
   * fact (`byId.running`) WITHOUT borrowing or retaining a binding — the Task
   * listing deliberately retains no descendant. `undefined` = the Client does
   * not know the Session.
   */
  activityOf(childSessionId: string): 'running' | 'inactive' | undefined
  /** Subscribe the official Job state changes (roster/status invalidation). */
  subscribeJobs(listener: () => void): () => void
  /** Subscribe the official Session-list changes (catalog/activity
   * availability invalidation). */
  subscribeSessions(listener: () => void): () => void
  /** Release the retained roster watch and invalidate every in-flight read.
   *  Idempotent; must run before the Client Context is disposed. */
  dispose(): void
}

/** The neutral live-ingress factory face (see `app/remote/live-ingress.ts`
 *  for the official-contract documentation; this structural mirror keeps
 *  the bootstrap transport-clean). */
export interface RemoteLiveIngressFactory {
  subscribe(
    sessionId: string,
    sinks: {
      onDurableEvent: (sessionId: string, event: { readonly type: string; readonly seq: number; readonly time: number }) => void
      onLiveInput: (input: import('../runtime/assistant-stream-port.ts').AssistantLiveInput) => void
      /** S3-R0: the incremental sequence is no longer trustworthy (generation
       *  rollover, revision discontinuity, window replace/prepend, missing
       *  change, hydrate gap). Intent only — the fold owner re-folds the
       *  CURRENT official window and then acknowledges the committed revision
       *  through the handle. */
      onWindowRefoldRequired: (sessionId: string, reason?: 'paging' | 'recovery') => void
      onSessionSnapshotChanged: (sessionId: string) => void
      /** The official PROJECTION store changed: the only channel carrying
       *  projection-owned current values (the Session snapshot never does). */
      onProjectionsChanged: (sessionId: string) => void
    },
    /** The caller's hydrate/read baseline: the committed revision plus the
     *  EXACT transport identity it was fenced under. A rollover/replacement or
     *  a revision change between the read and this subscription makes the
     *  baseline unusable, so the ingress recovers through
     *  `onWindowRefoldRequired` (never a lost event). */
    hydrate?: {
      readonly revision: number
      readonly transportToken?: unknown
    },
  ): {
    dispose(): void
    /** S3-R0: acknowledge one committed window re-fold (exact generation +
     *  binding + revision, Session open). `true` resumes incremental delivery. */
    acknowledgeWindowRefold(proof: {
      readonly generation: unknown
      readonly binding: unknown
      readonly revision: number
    }): boolean
    /** Whether a window read at `revision` may REPLACE the fold (the retained
     *  window of a rolled-over generation may not; checked before the commit,
     *  not after it). */
    refoldEligible(revision: number): boolean
  }
}

/** The pre-composed Remote application input for the internal L6
 *  composition entry (M3-4 PR2): the aggregate the caller already built
 *  through `createRemoteApplicationRuntime` (ONE Host/Client/Backend/owner
 *  graph), its presentation source bundle, and the SELECTED Client-local
 *  extension service from that same aggregate (M3-6 PR1: the Remote branch's
 *  UI extension authority — the Client Context's `piTuiExtensions`, never a
 *  Host-context lookup). The selection seam re-uses the aggregate's selected
 *  core instead of constructing a second Remote graph; internal/test paths
 *  only. The override carries the narrow service object, NOT the Client
 *  Context or plugin fibers; only the selected PiTuiExtensionService
 *  capability crosses the in-process composition seam. */
export interface RemoteApplicationOverride {
  readonly selected: SelectedApplicationRuntime
  readonly presentation: RemoteApplicationSources
  readonly extensionService: PiTuiExtensionService
}

/**
 * The process-owned refusal vocabulary of ONE manual Client reload request
 * (M4 PR4). It is separate from the Client-local safety refusals
 * (`app/remote-process/client-reload-safety`): these are decided by the
 * process entry's OWN preflight, which owns the live transport/Host status
 * and the installed-package resolution.
 *
 * - `already-current`: the installed replacement build IS the running build;
 * - `not-ready`: the process preflight (transport/surface/authenticated Host)
 *   is not currently satisfied;
 * - `target-invalid`: the installed replacement package is missing or
 *   incompatible with this Host/DSH runtime;
 * - `stopping`: this Client already owns ONE stop/reexec request.
 */
export type ClientReloadProcessRefusal =
  | 'already-current'
  | 'not-ready'
  | 'target-invalid'
  | 'stopping'

/** The synchronous result of ONE process-owned Client reload request. */
export type ClientReloadRequestResult =
  | { readonly kind: 'accepted' }
  | { readonly kind: 'refused'; readonly reason: ClientReloadProcessRefusal }

/**
 * The internal startup-settlement seam for the split Client's ONE real
 * Surface composition (M4-B2-S §7.1). `applyRunnerWithRuntime` is synchronous
 * and starts an asynchronous runner root, so the caller cannot learn from its
 * return value whether a physical surface was actually mounted:
 *
 * - `surfaceReady()` fires exactly once, after `surface.start(...)` returned
 *   successfully and the renderer/terminal ownership transfer settled — i.e.
 *   the real tty is owned by the mounted TUI;
 * - `surfaceFailed(error)` fires instead when the runner's startup root (or
 *   the surface acquisition) fails before `surfaceReady`, with the ORIGINAL
 *   error so the caller can unwind its whole Client graph in reverse order.
 *
 * Omitted by the Direct package entry (`applyRunner`) and every test that does
 * not observe real mount readiness; internal split-Client composition is the
 * only caller.
 */
export interface RunnerStartupSettlement {
  surfaceReady(): void
  surfaceFailed(error: unknown): void
  /**
   * M4 PR4: the split Client's ONE process-owned manual-reload request. It
   * returns the process preflight's synchronous decision; the caller
   * (the `/reload-client` command handler) has already made the Client-local
   * safety decision in the SAME synchronous stack. Absent on Direct and on
   * every composition without a Client OS entry.
   */
  requestClientReload?(): ClientReloadRequestResult
}

/** The neutral Session-scoped facts face. */
export interface RemoteSessionFactsSource {
  sessionStatus: SessionReader['sessionStatus']
  plan(sessionId: string): { readonly active: boolean; readonly pending: boolean } | undefined
  running(sessionId: string): boolean | undefined
  /** The §6.5 transport identity capture/compare pair (Connection
   *  generation + exact binding object; see the owning module). */
  captureTransportToken(sessionId: string): unknown
  isTransportTokenCurrent(sessionId: string, token: unknown): boolean
  /** S3-R0: the read→commit revision/identity proof of one window re-fold
   *  (undefined when a newer window or a replaced identity made the read
   *  superseded; see the owning module). */
  windowRefoldProof(
    sessionId: string,
    revision: number,
  ): { readonly generation: unknown; readonly binding: unknown; readonly revision: number } | undefined
  /** The official whole-log `sessionStats` projection value off the exact
   *  retained binding (PR4 §3.3; unknown-shaped — the composer narrows it;
   * an absent capability reads undefined, never a window-fold substitute). */
  sessionStatsProjection(sessionId: string): unknown
}

/** The internal application runtime-selection seam input: which core to adopt
 *  and how to construct the Direct one. There is deliberately NO Remote
 *  construction input: the retired in-process Remote aggregate is test-only, so
 *  a production Remote core can only arrive FULLY ASSEMBLED as `preselected`
 *  from the internal split Client composition root. */
export interface ApplicationRuntimeSelection {
  readonly kind: BackendKind
  /** Construct the Direct application runtime (the Direct branch's source). */
  readonly createDirect: () => {
    readonly backend: Backend
    readonly owners: SessionOwnerAccess
    readonly retirement: SessionOwnerRetirement
  }
  /**
   * A pre-built selected core the seam adopts VERBATIM: the caller already
   * constructed the ONE application core (the internal split Client's
   * `createRemoteApplicationRuntimeFromClient`), so the seam constructs nothing
   * and returns it by identity. The Direct root never supplies it.
   */
  readonly preselected?: SelectedApplicationRuntime
}
