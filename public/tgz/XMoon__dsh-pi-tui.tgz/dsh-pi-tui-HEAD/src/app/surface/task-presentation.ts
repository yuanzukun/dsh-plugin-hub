/**
 * Pure Task Center presentation projection.
 *
 * The durable task rows stay in catalog order. This module only decides what
 * the current surface can see: scope/type/search filtering, ancestor
 * retention, disclosure, and tree connectors. It never mutates a runtime row
 * or reorders the catalog.
 *
 * It also owns the Task Center's row-SELECTION disposition and the Job
 * viewer's fallback body (`taskRowSelectionDisposition`,
 * `subagentJobViewHint`, `subagentJobTranscriptId`).
 *
 * @module @xmoon76/dsh-pi-tui/app/surface/task-presentation
 */

import type { TaskBrowserRow, ViewerAccess } from '../../domain/task/browser.ts'

/** Picker group label for continuable subagents. */
export const SUBAGENT_GROUP = 'subagents'
/** Picker group label for jobs. */
export const JOB_GROUP = 'jobs'

/**
 * The tree connector prefix for one subagent row: indentation by depth
 * (the browser's root is depth 1) plus a stable `├─ ` branch connector.
 * The connector is a fixed layout region (plan §6.7) — it never scrolls
 * with the selected label (M4 marquee) and never carries label text, so
 * the marquee's moving window starts after it.
 */
export function taskTreePrefix(depth: number): string {
  const safe = Math.max(1, Math.floor(depth))
  return `${'  '.repeat(safe - 1)}├─ `
}

/** The one-line picker label for a row. The subagent label CARRIES the
 * mode as its final segment (never inferred from running/inactive): the
 * user must know before entering a viewer whether it is interactive. A
 * JOB row whose kind is `subagent` is the jobs registry's reliable
 * contract for a background ONE-SHOT subagent job (continuable children
 * never register jobs), so it carries `one-shot` too; any other job kind
 * keeps its own semantics (no fabricated mode). */
export function taskRowLabel(row: TaskBrowserRow): string {
  if (row.kind === 'job') {
    return row.jobKind === 'subagent'
      ? `subagent job · ${row.label} · one-shot`
      : `${row.jobKind} · ${row.label}`
  }
  return `subagent · ${row.label} · ${row.mode}`
}

/** The picker group a row belongs to. */
export function rowGroup(row: TaskBrowserRow): string {
  return row.kind === 'job' ? JOB_GROUP : SUBAGENT_GROUP
}

/** The picker description line for a row. The subagent line carries the
 * PROJECTED runtime activity only — `has children` is deliberately NOT
 * shown: the tree connector already expresses parenthood, so the text
 * would duplicate the structure (the `hasChildren` data fact stays on
 * the row for future fold/disclosure work). */
export function describeTaskRow(row: TaskBrowserRow, now: number): string {
  if (row.kind === 'job') {
    const elapsed = Math.max(0, Math.floor((now - row.startedAt) / 1000))
    return `${row.status}${row.detail === undefined ? '' : ` — ${row.detail}`} · ${elapsed}s`
  }
  // An rc.2 catalog v2 external leaf has NO local child Session: it is stated
  // as such and never offered as an openable child (S2-B1).
  if (row.kind === 'external') return 'External · no local session'
  return `${row.activity}${row.depth > 1 ? ` · depth ${row.depth}` : ''}`
}

/** The viewer header hint for one access (plan §6.10: the UI shows the
 * REAL mode and states the surface authority explicitly — a nested
 * continuable child is never relabeled one-shot to borrow read-only
 * logic, and a nested ONE-SHOT child keeps its own mode too). MODE is
 * the durable semantic, ACCESS the surface authority — the hint must
 * render BOTH truthfully, so it takes the mode alongside the access: a
 * nested one-shot row reads `one-shot · nested · read-only from this
 * parent`, never `continuable · …` (review P2). */
export function viewerAccessHint(mode: 'one-shot' | 'continuable', access: ViewerAccess): string {
  switch (access) {
    case 'interactive-direct-child': return 'continuable · interactive'
    case 'readonly-one-shot': return 'one-shot · read-only'
    case 'readonly-nested': return `${mode} · nested · read-only from this parent`
  }
}

/** The two independent Task Center scope filters. */
export type TaskScope = 'active' | 'all'

/** A row-shaped value consumed by both Quick Tasks and Task Center. */
export interface TaskPanelItem {
  /** Stable row identity (`agent:…`, `job:…`). */
  readonly value: string
  /** Primary display label. */
  readonly label: string
  /** Durable mode or another non-truncatable semantic suffix. */
  readonly suffix?: string
  /** Current state word. */
  readonly status: string
  /** Optional status/detail metadata. */
  readonly detail?: string
  readonly startedAt?: number
  readonly finishedAt?: number
  /** Logical group (`subagents` / `jobs`, or a display label). */
  readonly group?: string
  /** Type-filter identity (`subagent`, `bash`, `pwsh`, ...). */
  readonly type?: string
  /** Source and semantic capabilities. */
  /** Work-domain source, or `question` for human-required Question attention
   *  (a NON-work row: it has no stop semantics and never counts as active work). */
  readonly source?: 'subagent' | 'job' | 'question'
  readonly canOpen?: boolean
  readonly canStop?: boolean
  readonly active?: boolean
  readonly attention?: boolean
  /** Durable tree facts. Parent ids are row ids when possible. */
  readonly parentId?: string
  readonly depth?: number
  readonly hasChildren?: boolean
  readonly parentLabel?: string
  readonly mode?: 'one-shot' | 'continuable' | string
  readonly access?: string
  /** Presentation facts populated by {@link projectTaskItems}. */
  readonly expanded?: boolean
  readonly ancestorContext?: boolean
  readonly treePrefix?: string
}

/** Inputs controlling one projection. */
export interface TaskPresentationProjectionOptions {
  readonly scope: TaskScope
  readonly typeFilter?: string | null
  readonly query?: string
  readonly expandedIds?: ReadonlySet<string>
  readonly collapsedIds?: ReadonlySet<string>
  /** Running/search branches expand unless explicitly collapsed. */
  readonly autoExpandRunning?: boolean
  /** Quick may surface attention rows when there is no live work. */
  readonly includeAttentionInActive?: boolean
}

/** A projected row set and the ids that remain visible. */
export interface TaskPresentationProjection {
  readonly rows: TaskPanelItem[]
  readonly matchedIds: ReadonlySet<string>
}

const ACTIVE_STATES = new Set(['running', 'stopping'])

/** Status-based fallback for callers that have not supplied `active`. */
export function isTaskItemActive(item: Pick<TaskPanelItem, 'active' | 'status'>): boolean {
  return item.active ?? ACTIVE_STATES.has(item.status)
}

/** Whether a task status deserves an error/attention marker. */
export function isTaskItemFailure(status: string): boolean {
  return status === 'failed' || status === 'timed_out' || status === 'lost'
}

/** Normalize a parent reference from a durable child id to a row id. */
function parentIdOf(item: TaskPanelItem, byId: ReadonlyMap<string, TaskPanelItem>, byChildId: ReadonlyMap<string, string>): string | undefined {
  const parent = item.parentId
  if (parent === undefined || parent === '') return undefined
  if (byId.has(parent)) return parent
  return byChildId.get(parent) ?? parent
}

/**
 * Project rows for one Quick/Full view.
 *
 * Active projection is `active rows + their ancestors`; it never promotes a
 * child to a root and never changes the input order. Search and type are
 * applied orthogonally. Ancestors retained only for context are marked
 * `ancestorContext` and keep their real inactive state.
 */
export function projectTaskItems(
  input: readonly TaskPanelItem[],
  options: TaskPresentationProjectionOptions,
): TaskPresentationProjection {
  const all = [...input]
  const byId = new Map(all.map(item => [item.value, item]))
  const byChildId = new Map<string, string>()
  for (const item of all) {
    if (item.source === 'subagent' && item.value.startsWith('agent:')) {
      byChildId.set(item.value.slice('agent:'.length), item.value)
    }
  }
  const parentById = new Map<string, string | undefined>()
  for (const item of all) parentById.set(item.value, parentIdOf(item, byId, byChildId))

  const typeFilter = options.typeFilter ?? null
  const query = (options.query ?? '').trim().toLowerCase()
  const typeMatches = (item: TaskPanelItem): boolean => typeFilter === null || item.type === typeFilter
  const queryMatches = (item: TaskPanelItem): boolean => query === '' || [
    item.value,
    item.label,
    item.suffix ?? '',
    item.status,
    item.detail ?? '',
    item.group ?? '',
  ].join('\n').toLowerCase().includes(query)
  const filterMatches = (item: TaskPanelItem): boolean => typeMatches(item) && queryMatches(item)

  const matchedIds = new Set(all.filter(filterMatches).map(item => item.value))
  // The FULL tree (before any include pass): answering "does this inactive
  // branch contain active work?" during Active projection needs the
  // complete lineage, not the selected subset.
  const childrenMap = new Map<string | undefined, TaskPanelItem[]>()
  for (const item of all) {
    const parent = parentById.get(item.value)
    const list = childrenMap.get(parent) ?? []
    list.push(item)
    childrenMap.set(parent, list)
  }
  /** Fold a subtree predicate bottom-up in ONE reverse-preorder pass —
   * eliminates the repeated subtree scans that made search keystrokes
   * quadratic; common projection paths stay near-linear. (Whole-graph
   * strict linearity is not claimed: the include-with-ancestors, visible-
   * ancestry and connector walks are depth-proportional by nature, which
   * is negligible for Task Center's realistic tens-to-hundreds of
   * descendants.) */
  const propagateSubtree = (
    nodes: readonly TaskPanelItem[],
    tree: Map<string | undefined, TaskPanelItem[]>,
    marker: (item: TaskPanelItem) => boolean,
  ): (id: string) => boolean => {
    const subtree = new Map<string, boolean>()
    for (let i = nodes.length - 1; i >= 0; i -= 1) {
      const node = nodes[i]!
      const anyChild = (tree.get(node.value) ?? []).some(child => subtree.get(child.value) === true)
      subtree.set(node.value, anyChild || marker(node))
    }
    return (id: string) => (tree.get(id) ?? []).some(child => subtree.get(child.value) === true)
  }
  const hasActiveDescendantInAll = propagateSubtree(all, childrenMap, isTaskItemActive)
  /**
   * The query-matching inactive branches that still host active work, and
   * EVERYTHING below them. Computed in one preorder pass (a parent is
   * always visited before its children, so the marker propagates top-down
   * without re-scanning subtrees): the Active+search branch membership
   * test is then O(1) per row — the earlier nested candidate loop
   * re-walked every branch per matching root (PR review M2).
   */
  const matchingInactiveRoots = new Set<string>()
  const underMatchingInactive = new Set<string>()
  if (options.scope === 'active') {
    for (const item of all) {
      if (!isTaskItemActive(item) && queryMatches(item) && item.hasChildren && hasActiveDescendantInAll(item.value)) {
        matchingInactiveRoots.add(item.value)
      }
    }
    for (const item of all) {
      const parent = parentById.get(item.value)
      if (matchingInactiveRoots.has(item.value) || (parent !== undefined && underMatchingInactive.has(parent))) {
        underMatchingInactive.add(item.value)
      }
    }
  }

  const includedIds = new Set<string>()
  const includeWithAncestors = (item: TaskPanelItem): void => {
    let current: TaskPanelItem | undefined = item
    const seen = new Set<string>()
    while (current !== undefined && !seen.has(current.value)) {
      seen.add(current.value)
      if (typeMatches(current)) includedIds.add(current.value)
      const parent = parentById.get(current.value)
      current = parent === undefined ? undefined : byId.get(parent)
    }
  }

  if (options.scope === 'active') {
    // Search narrows the active set; with an empty query every active row is
    // retained. A query that matches an INACTIVE branch keeps that branch
    // only as the CONTEXT of active work below it — the matching ancestors
    // and their active descendants join together, never an isolated dead
    // branch (an Active view must keep at least one active row; PR review
    // M3).
    for (const item of all) {
      if (!typeMatches(item)) continue
      // Human-required Question attention is NEITHER work NOR failure
      // attention. It is included by its own rule so a pending Question can
      // never be hidden by the `includeAttentionInActive` (no-live-work)
      // condition — one running Job plus one pending Question must still show
      // the Question (addendum §10.3).
      if (item.source === 'question' && queryMatches(item)) {
        includeWithAncestors(item)
        continue
      }
      if (isTaskItemActive(item) && queryMatches(item)) includeWithAncestors(item)
      else if (options.includeAttentionInActive === true && !isTaskItemActive(item)
        && (item.attention === true || isTaskItemFailure(item.status)) && queryMatches(item)) includeWithAncestors(item)
      else if (matchingInactiveRoots.has(item.value)) includeWithAncestors(item)
      else if (isTaskItemActive(item) && underMatchingInactive.has(item.value)) includeWithAncestors(item)
    }
  } else {
    for (const item of all) {
      if (filterMatches(item)) includeWithAncestors(item)
    }
  }

  const selected = all.filter(item => includedIds.has(item.value))
  const children = new Map<string | undefined, TaskPanelItem[]>()
  for (const item of selected) {
    const parent = parentById.get(item.value)
    const list = children.get(parent) ?? []
    list.push(item)
    children.set(parent, list)
  }
  const expandedIds = options.expandedIds ?? new Set<string>()
  const collapsedIds = options.collapsedIds ?? new Set<string>()
  const autoExpandRunning = options.autoExpandRunning ?? true

  // Descendant predicates over the SELECTED tree, folded once per
  // projection pass (near-linear) — the disclosure pass below then answers
  // each query in constant time.
  const hasMatchingDescendant = query === ''
    ? (): boolean => false
    : propagateSubtree(selected, children, item => matchedIds.has(item.value))
  const hasActiveDescendant = propagateSubtree(selected, children, isTaskItemActive)
  const hasAttentionDescendant = propagateSubtree(selected, children,
    item => item.attention === true || isTaskItemFailure(item.status))
  const isExpanded = (item: TaskPanelItem): boolean => {
    if (!(item.hasChildren || (children.get(item.value)?.length ?? 0) > 0)) return false
    if (collapsedIds.has(item.value)) return false
    if (expandedIds.has(item.value)) return true
    if (hasMatchingDescendant(item.value)) return true
    if (autoExpandRunning && hasActiveDescendant(item.value)) return true
    if (options.includeAttentionInActive === true && hasAttentionDescendant(item.value)) return true
    // Settled branches start collapsed. Disclosure is presentation state, so
    // the user can expand a historical branch without changing the catalog.
    return false
  }

  const visible: TaskPanelItem[] = []
  for (const item of selected) {
    let parent = parentById.get(item.value)
    let hidden = false
    const seen = new Set<string>()
    while (parent !== undefined && !seen.has(parent)) {
      seen.add(parent)
      const ancestor = byId.get(parent)
      if (ancestor !== undefined && !isExpanded(ancestor)) {
        hidden = true
        break
      }
      parent = parentById.get(parent)
    }
    if (hidden) continue
    // Context rows are the NON-ACTIVE rows kept only to explain the view:
    // inactive ancestors in Active scope, or any row that survived a filter
    // without matching it. An ACTIVE row is never context — it is the work
    // the view exists to show, even when a search query did not match it
    // (a matching inactive branch pulls its running descendants in, PR
    // review M3).
    // Human-required Question attention is a PRIMARY row, never an ancestor
    // context row: it is deliberately not "active work", so the generic rule
    // would dim the very thing the user must act on (Quick's Active scope has
    // no work row above it to explain).
    const context = item.source !== 'question'
      && !isTaskItemActive(item)
      && ((options.scope === 'active') || !matchedIds.has(item.value))
    visible.push({
      ...item,
      parentId: parentById.get(item.value),
      expanded: isExpanded(item),
      ancestorContext: context,
    })
  }

  // Connectors are calculated from the projected visible tree, not written
  // back into durable rows. Hidden siblings therefore do not leave misleading
  // branch tails in the current view.
  const visibleSubagents = visible.filter(item => item.source === 'subagent')
  const visibleById = new Map(visibleSubagents.map(item => [item.value, item]))
  const siblings = new Map<string | undefined, TaskPanelItem[]>()
  for (const item of visibleSubagents) {
    const parent = item.parentId === undefined || item.parentId === '' ? undefined : item.parentId
    const list = siblings.get(parent) ?? []
    list.push(item)
    siblings.set(parent, list)
  }
  const connectorFor = (item: TaskPanelItem): string => {
    if (item.depth === undefined && item.parentId === undefined) return item.treePrefix ?? ''
    const parts: string[] = []
    let currentParent = item.parentId
    const path: TaskPanelItem[] = []
    const seen = new Set<string>()
    while (currentParent !== undefined && !seen.has(currentParent)) {
      seen.add(currentParent)
      const parent = visibleById.get(currentParent)
      if (parent === undefined) break
      path.unshift(parent)
      currentParent = parent.parentId
    }
    for (const ancestor of path) {
      const parentSiblings = siblings.get(ancestor.parentId === '' ? undefined : ancestor.parentId) ?? []
      const last = parentSiblings.length === 0 || parentSiblings.at(-1)?.value === ancestor.value
      parts.push(last ? '   ' : '│  ')
    }
    const parentSiblings = siblings.get(item.parentId === '' ? undefined : item.parentId) ?? []
    const last = parentSiblings.length === 0 || parentSiblings.at(-1)?.value === item.value
    parts.push(last ? '└─ ' : '├─ ')
    return parts.join('')
  }

  return {
    rows: visible.map(item => item.source === 'subagent'
      ? { ...item, treePrefix: connectorFor(item) }
      : item),
    matchedIds,
  }
}

export function subagentJobTranscriptId(snapshot: unknown): string | undefined {
  if (typeof snapshot !== 'object' || snapshot === null) return undefined
  const childSessionId = (snapshot as { readonly childSessionId?: unknown }).childSessionId
  return typeof childSessionId === 'string' && childSessionId.trim() !== '' ? childSessionId : undefined
}

/**
 * The Task Center row-selection disposition (plan §4.3/§4.4). A subagent
 * transcript opens a session/viewer surface that REPLACES the browser; a
 * Job row's detail keeps it mounted (the caller passes {@link openJobView}'s
 * disposition). An UNKNOWN row — a stale panel selection after a live
 * re-projection — also keeps the parent usable instead of dismissing it.
 */
export function taskRowSelectionDisposition(
  row: { readonly kind: 'job' | 'subagent' } | undefined,
  jobDetail: 'close' | 'keep-open',
): 'close' | 'keep-open' {
  if (row === undefined) return 'keep-open'
  if (row.kind === 'subagent') return 'close'
  return jobDetail
}

/** Viewer body for a subagent job with no uniquely matched child. */
export function subagentJobViewHint(status: string, detail: string | undefined): string {
  const tail = status === 'running' || status === 'stopping'
    ? ' — running in the background; its transcript updates live in /tasks'
    : ` — this subagent finished${detail === undefined ? '' : ` (${detail})`}`
  return [
    `status: ${status}${tail}`,
    '',
    'The job record does not carry the child session id, so this job cannot',
    'be matched to its child from the task browser (a same-label foreground',
    'run would be indistinguishable). Open /tasks and pick the child by',
    'its label to read the transcript.',
  ].join('\n')
}
