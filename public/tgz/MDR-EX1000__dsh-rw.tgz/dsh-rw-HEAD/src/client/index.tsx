/// <reference lib="dom" />

// dsh-rw — client half: the unified workspace directory picker.
//
// One modal fills ui-workspace's two directory-flow holes (sidebar +
// conversation hero). The entry is a compact two-card chooser (本机 / 远程);
// picking a card drills into that flow's page, which
// carries a 「← 返回」 back to the cards:
//   • 本机 → 手动输入本机路径，或经 POST /api/dsh-rw/local-pick 调起系统
//     文件夹选择器，结果直接 onPicked(localPath)。
//   • 远程 → 主机用下拉选择（选项只显示别名；来自 ~/.ssh/config + 手动条目）；
//     路径默认落在远端 home（~/，服务端经 realpath('.') 扩展），输入框下方是
//     行内目录列表（Codex「New remote project」式）：列表实时跟随输入
//     内容（对父目录做 ls + 前缀过滤，防抖 ~220ms），点行下钻、↑ 回上一级；
//     可选「工作区名称」命名本地占位目录（留空用路径 basename，
//     仅重名冲突时服务端才追加哈希后缀）。确认后 POST /api/dsh-rw/workspace
//     拿到本地占位目录 → onPicked(placeholderDir)，交给 DSH 原生流程登记为
//     workspace。「+ 添加主机」跳到 modal 内独立子页（带返回）：测试连接走
//     POST /test 完整字段形式（临时探测不入库），保存走 POST /hosts；手动
//     条目带「手动」标注，选中后可在远程页删除。密码只提交不展示。
//
// Client entries must be classic scripts registered via window.__ModuleLoader__.load
// ({ id, factory }); the factory receives a synchronous `require` — react and
// react/jsx-runtime are provided by the DSH runtime (esbuild externals), never
// bundled. All traffic goes to the loopback-only /api/dsh-rw/* routes; host
// payloads come from HostTable.summarize and never contain secrets.
import { useCallback, useEffect, useRef, useState, useSyncExternalStore, type CSSProperties } from 'react'
import { en, zh, type Translate } from './locales.js'

export const name = 'dsh-rw'

// ── wire types (mirror of the host-side JSON shapes) ────────────────────────

/** Host row from GET /api/dsh-rw/hosts or /status (summary only, no secrets). */
interface HostSummary {
  alias: string
  host: string
  port: number
  user: string
  authKind: 'key' | 'password'
  keyReady: boolean
  passwordSet: boolean
  /** key auth: the configured private-key path (a path, not a secret). */
  keyPath?: string
  source: 'ssh-config' | 'manual'
}

/** Last probe outcome of one host, kept in the modal's memory only. */
interface HostHealth {
  state: 'testing' | 'ok' | 'fail'
  ms?: number
  error?: string
}

/** One entry of a GET /api/dsh-rw/ls listing. */
interface LsItem {
  name: string
  type: 'dir' | 'file' | 'symlink'
}

interface StatusResponse {
  hosts?: HostSummary[]
  /** ssh-config aliases hidden from the list (restorable). */
  hiddenAliases?: string[]
  current?: { alias?: string | null } | null
}

interface LsResponse {
  path?: string
  items?: LsItem[]
  /** Local listing only: parent directory (null at the filesystem root). */
  parent?: string | null
  /** Local listing only: the host user's home directory. */
  home?: string
  /** Local listing only: the level was capped. */
  truncated?: boolean
}

/** Remembered local workspace directory, so the本机 page never starts empty. */
const LOCAL_PATH_KEY = 'dsh-rw:lastLocalPath'
/** Remembered SSH host alias, so the远程 page opens on the machine last used. */
const HOST_KEY = 'dsh-rw:lastHost'

interface LocalPickResponse {
  ok?: boolean
  path?: string
  cancelled?: boolean
  error?: string
}

interface WorkspaceResponse {
  ok?: boolean
  placeholderDir?: string
  error?: string
}

/** POST /api/dsh-rw/test probe result (probe failures are 200s with ok:false). */
interface TestResponse {
  ok?: boolean
  latencyMs?: number
  error?: string
  code?: string
}

/** POST /api/dsh-rw/hosts add result (echoes the summary only, no secrets). */
interface AddHostResponse {
  ok?: boolean
  host?: HostSummary
  error?: string
}

/** What ui-workspace passes to components registered on directoryFlow slots. */
export interface DirPickerProps {
  open: boolean
  busy: boolean
  onPicked: (path: string) => void
  onCancel: () => void
}

/** Structural face of the DSH client locale service used by this bundle. */
interface LocaleLike {
  register(namespace: string, dicts: { zh: Record<string, string>; en: Record<string, string> }): () => void
  bind(namespace: string): Translate
  subscribe(callback: () => void): () => void
  getSnapshot(): { active: string; revision: number }
}

interface LocalizedDirPickerProps extends DirPickerProps {
  locale: LocaleLike
  t: Translate
}

// ── helpers ─────────────────────────────────────────────────────────────────

/** JSON fetch wrapper: non-2xx → throw Error(body.error ?? `HTTP <status>`). */
async function api<T>(method: string, url: string, body?: unknown): Promise<T> {
  const headers: Record<string, string> = {}
  const init: RequestInit = { method, headers }
  if (body !== undefined) {
    headers['Content-Type'] = 'application/json'
    init.body = JSON.stringify(body)
  }
  const res = await fetch(url, init)
  const data = (await res.json().catch(() => ({}))) as (T & { error?: string; message?: string }) | null
  if (!res.ok) throw new Error((data && (data.error || data.message)) || `HTTP ${res.status}`)
  return data as T
}

/** Error → display text (Error.message when present, else String(value)). */
function errText(e: unknown): string {
  const m = (e as { message?: unknown } | null | undefined)?.message
  return String(typeof m === 'string' && m ? m : e)
}

/** Whether a listing entry can be entered. Symlinks may be followed — the
 * server realpath-resolves them and reports an error when the target is not a
 * directory, so the UI keeps the simple blueprint behavior. */
function drillable(it: LsItem): boolean {
  return it.type === 'dir' || it.type === 'symlink'
}

/** Why a host cannot be picked right now (null when it is usable). */
function hostProblem(h: HostSummary, t: Translate): string | null {
  if (h.authKind === 'key') return h.keyReady ? null : t('privateKeyMissing')
  return h.passwordSet ? null : t('passwordNotSet')
}

/** Tiny pill for one host attribute (provenance, credential readiness). */
function Pill(props: { tone?: 'ok' | 'warn'; children: unknown }) {
  const color = props.tone === 'ok' ? T.ok : props.tone === 'warn' ? T.danger : T.muted
  return (
    <span
      style={{
        fontSize: 11,
        lineHeight: '16px',
        padding: '0 6px',
        borderRadius: 6,
        border: '1px solid ' + T.border,
        color,
        whiteSpace: 'nowrap',
        flexShrink: 0,
      }}
    >
      {props.children as never}
    </span>
  )
}

/** Compact icon action inside a host row (test / edit / remove). */
function MiniAction(props: { title: string; danger?: boolean; onClick: () => void; children: unknown }) {
  const [hov, setHov] = useState(false)
  return (
    <button
      title={props.title}
      aria-label={props.title}
      onClick={(e) => {
        e.stopPropagation()
        props.onClick()
      }}
      onMouseEnter={() => setHov(true)}
      onMouseLeave={() => setHov(false)}
      style={{
        width: 26,
        height: 26,
        flexShrink: 0,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        borderRadius: 8,
        border: '1px solid transparent',
        background: hov ? T.bgHover : 'transparent',
        color: props.danger ? T.danger : T.muted,
        cursor: 'pointer',
        fontSize: 13,
        fontFamily: 'inherit',
        transition: 'background .15s',
      }}
    >
      {props.children as never}
    </button>
  )
}

/**
 * One SSH host row: identity, provenance, credential readiness, last probe
 * result and its actions. Replaces the bare <select>, which showed only the
 * alias and greyed unavailable hosts out with no reason.
 */
function HostCard(props: {
  host: HostSummary
  active: boolean
  health?: HostHealth
  t: Translate
  onPick: () => void
  onTest: () => void
  onEdit?: () => void
  onRemove?: () => void
  onHide?: () => void
}) {
  const { host, active, health, t } = props
  const [hov, setHov] = useState(false)
  const problem = hostProblem(host, t)
  const exact = host.authKind === 'key' ? host.keyReady : host.passwordSet
  const dot = health === undefined ? T.muted : health.state === 'ok' ? T.ok : health.state === 'fail' ? T.danger : T.accent
  const probe =
    health === undefined
      ? ''
      : health.state === 'testing'
        ? ` · ${t('testing')}`
        : health.state === 'ok'
          ? ` · ${t('hostLatency', { latency: health.ms ?? 0 })}`
          : ` · ${t('hostUnreachable', { error: health.error ?? '' })}`
  const detail = `${host.user}@${host.host}:${host.port}` + (problem !== null ? ` · ${problem}` : probe)
  return (
    <div
      role="button"
      tabIndex={problem === null ? 0 : -1}
      aria-disabled={problem !== null}
      onClick={() => {
        if (problem === null) props.onPick()
      }}
      onKeyDown={(e) => {
        if (problem === null && (e.key === 'Enter' || e.key === ' ')) {
          e.preventDefault()
          props.onPick()
        }
      }}
      onMouseEnter={() => setHov(true)}
      onMouseLeave={() => setHov(false)}
      style={{
        display: 'flex',
        alignItems: 'center',
        gap: 10,
        padding: '8px 8px 8px 12px',
        borderRadius: T.radius,
        border: '1px solid ' + (active ? T.accent : hov && problem === null ? T.borderStrong : T.border),
        background: active ? T.bgHover : 'transparent',
        cursor: problem === null ? 'pointer' : 'not-allowed',
        opacity: problem === null ? 1 : 0.62,
        transition: 'background .15s, border-color .15s',
      }}
    >
      <span style={{ width: 8, height: 8, borderRadius: 4, background: dot, flexShrink: 0 }} />
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6, minWidth: 0 }}>
          <span
            style={{
              fontSize: 14,
              fontWeight: active ? 600 : 500,
              color: T.label,
              overflow: 'hidden',
              textOverflow: 'ellipsis',
              whiteSpace: 'nowrap',
            }}
          >
            {host.alias}
          </span>
          <Pill>{host.source === 'manual' ? t('badgeManual') : t('badgeSshConfig')}</Pill>
          <Pill tone={exact ? 'ok' : 'warn'}>{host.authKind === 'key' ? t('badgeKey') : t('badgePassword')}</Pill>
        </div>
        <div
          style={{
            fontSize: 12,
            color: problem !== null ? T.danger : T.muted,
            marginTop: 2,
            overflow: 'hidden',
            textOverflow: 'ellipsis',
            whiteSpace: 'nowrap',
          }}
        >
          {detail}
        </div>
      </div>
      <MiniAction title={t('testConnection')} onClick={props.onTest}>
        {health?.state === 'testing' ? '…' : '⟳'}
      </MiniAction>
      {props.onEdit !== undefined ? (
        <MiniAction title={t('editHost')} onClick={props.onEdit}>
          ✎
        </MiniAction>
      ) : null}
      {props.onRemove !== undefined ? (
        <MiniAction title={t('remove')} danger onClick={props.onRemove}>
          ✕
        </MiniAction>
      ) : null}
      {props.onHide !== undefined ? (
        <MiniAction title={t('hideHost')} danger onClick={props.onHide}>
          ✕
        </MiniAction>
      ) : null}
    </div>
  )
}

/** Alias charset, mirroring the host-side HostTable.addManual ALIAS_RE. */
const ALIAS_RE = /^[a-zA-Z0-9][a-zA-Z0-9._-]*$/

/** The inline add-host form fields (port stays a string until submit). */
interface AddHostForm {
  alias: string
  host: string
  port: string
  user: string
  authKind: 'key' | 'password'
  keyPath: string
  passphrase: string
  password: string
}

const emptyAddForm = (): AddHostForm => ({ alias: '', host: '', port: '22', user: 'root', authKind: 'key', keyPath: '', passphrase: '', password: '' })

// ── theme (DSH design tokens with fallbacks, so light/dark just works) ──────

const v = (name: string, fb: string): string => `var(${name}, ${fb})`
const T = {
  bg: v('--dsw-alias-bg-layer-1', 'rgba(128,128,128,0.07)'),
  bgHover: v('--dsw-alias-bg-layer-2', 'rgba(128,128,128,0.14)'),
  border: v('--dsw-alias-border-l2', 'rgba(128,128,128,0.35)'),
  borderStrong: v('--dsw-alias-border-l3', 'rgba(128,128,128,0.5)'),
  accent: v('--dsw-alias-accent-primary', '#4c8dff'),
  danger: v('--dsw-static-red-500', '#e06c75'),
  ok: v('--dsw-static-green-500', '#4caf7d'),
  radius: 10,
  muted: v('--dsw-alias-label-tertiary', 'rgba(128,128,128,0.7)'),
  label: v('--dsw-alias-label-primary', '#e4e4e7'),
}
const panelBg = v('--dsw-alias-bg-layer-1', '#18181b')

const inputS: CSSProperties = { flex: 1, minWidth: 0, width: '100%', boxSizing: 'border-box', padding: '9px 14px', borderRadius: T.radius, border: '1px solid ' + T.border, background: T.bg, color: T.label, outline: 'none', fontFamily: 'inherit', fontSize: 14, transition: 'border-color .15s' }
const buttonS: CSSProperties = { padding: '9px 16px', borderRadius: T.radius, border: '1px solid ' + T.border, background: T.bg, color: T.label, cursor: 'pointer', fontFamily: 'inherit', fontSize: 14, whiteSpace: 'nowrap', transition: 'background .15s, border-color .15s' }

/** Section caption above a field group (form pages). */
const labelS: CSSProperties = { fontSize: 14, color: T.muted }

/** Button with hover feedback; `primary` renders the Codex-style white
 * call-to-action (cf. "Add project"), `danger` the muted-danger look. */
function Btn(props: { primary?: boolean; danger?: boolean; title?: string; disabled?: boolean; style?: CSSProperties; onClick?: () => void; children: unknown }) {
  const [hov, setHov] = useState(false)
  const base: CSSProperties = props.primary
    ? { ...buttonS, background: '#f4f4f5', border: '1px solid #f4f4f5', color: '#18181b', fontWeight: 600 }
    : props.danger
      ? { ...buttonS, color: T.danger }
      : buttonS
  const hover: CSSProperties = hov && !props.disabled ? (props.primary ? { filter: 'brightness(0.92)' } : { background: T.bgHover, border: '1px solid ' + T.borderStrong }) : {}
  return (
    <button
      title={props.title}
      disabled={props.disabled}
      onClick={props.onClick}
      onMouseEnter={() => setHov(true)}
      onMouseLeave={() => setHov(false)}
      style={{ ...base, ...hover, ...(props.disabled ? { opacity: 0.55, cursor: 'default' } : {}), ...(props.style || {}) }}
    >
      {props.children as never}
    </button>
  )
}

/** Text input with an accent focus ring (inline styles can't do :focus). */
function TextInput(props: Record<string, unknown> & { value: string; onChange: (e: { target: { value: string } }) => void }) {
  const [focus, setFocus] = useState(false)
  const { style, onFocus, onBlur, ...rest } = props as { style?: CSSProperties; onFocus?: (e: unknown) => void; onBlur?: (e: unknown) => void } & Record<string, unknown>
  return (
    <input
      {...(rest as any)} // eslint-disable-line @typescript-eslint/no-explicit-any -- passthrough input props
      style={{ ...inputS, ...(focus ? { border: '1px solid ' + T.accent } : {}), ...(style || {}) }}
      onFocus={(e: unknown) => {
        setFocus(true)
        if (onFocus) onFocus(e)
      }}
      onBlur={(e: unknown) => {
        setFocus(false)
        if (onBlur) onBlur(e)
      }}
    />
  )
}

// ── outline SVG icons (Codex-style flat line icons, stroke = currentColor) ──

function SvgFolder(props: { size?: number }) {
  const s = props.size ?? 15
  return (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round">
      <path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" />
    </svg>
  )
}

function SvgGlobe(props: { size?: number }) {
  const s = props.size ?? 15
  return (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="12" cy="12" r="9" />
      <path d="M3 12h18" />
      <path d="M12 3c2.5 2.6 3.9 5.7 3.9 9s-1.4 6.4-3.9 9c-2.5-2.6-3.9-5.7-3.9-9s1.4-6.4 3.9-9z" />
    </svg>
  )
}

function SvgLink(props: { size?: number }) {
  const s = props.size ?? 15
  return (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round">
      <path d="M10 13a5 5 0 0 0 7.5.5l3-3a5 5 0 0 0-7-7l-1.7 1.7" />
      <path d="M14 11a5 5 0 0 0-7.5-.5l-3 3a5 5 0 0 0 7 7l1.7-1.7" />
    </svg>
  )
}

function SvgArrowUp(props: { size?: number }) {
  const s = props.size ?? 16
  return (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
      <path d="M12 19V5" />
      <path d="M5 12l7-7 7 7" />
    </svg>
  )
}

function SvgChevronDown(props: { size?: number }) {
  const s = props.size ?? 16
  return (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
      <path d="M6 9l6 6 6-6" />
    </svg>
  )
}

function SvgChevronRight(props: { size?: number }) {
  const s = props.size ?? 16
  return (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
      <path d="M9 6l6 6-6 6" />
    </svg>
  )
}

function SvgArrowLeft(props: { size?: number }) {
  const s = props.size ?? 16
  return (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
      <path d="M19 12H5" />
      <path d="M12 19l-7-7 7-7" />
    </svg>
  )
}

function SvgArrowRight(props: { size?: number }) {
  const s = props.size ?? 16
  return (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
      <path d="M5 12h14" />
      <path d="M12 5l7 7-7 7" />
    </svg>
  )
}

function SvgMonitor(props: { size?: number }) {
  const s = props.size ?? 16
  return (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round">
      <rect x="3" y="4" width="18" height="12" rx="2" />
      <path d="M8 20h8M12 16v4" />
    </svg>
  )
}

function SvgFile(props: { size?: number }) {
  const s = props.size ?? 15
  return (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round">
      <path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z" />
      <path d="M14 3v5h5" />
    </svg>
  )
}

function SvgX(props: { size?: number }) {
  const s = props.size ?? 14
  return (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
      <path d="M18 6L6 18M6 6l12 12" />
    </svg>
  )
}

/** Composite input with an attached icon cell at the left (Codex-style):
 * the border wraps icon + field as one control; focus rings the outer box. */
function IconInput(props: { icon: unknown; value: string; placeholder?: string; onChange: (e: { target: { value: string } }) => void }) {
  const [focus, setFocus] = useState(false)
  return (
    <div
      style={{
        display: 'flex',
        alignItems: 'stretch',
        border: '1px solid ' + (focus ? T.accent : T.border),
        borderRadius: T.radius,
        background: T.bg,
        overflow: 'hidden',
        transition: 'border-color .15s',
      }}
    >
      <div style={{ width: 44, flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', color: T.muted, borderRight: '1px solid ' + T.border }}>
        {props.icon as never}
      </div>
      <input
        value={props.value}
        placeholder={props.placeholder}
        onChange={props.onChange}
        onFocus={() => setFocus(true)}
        onBlur={() => setFocus(false)}
        style={{ flex: 1, minWidth: 0, border: 'none', outline: 'none', background: 'transparent', color: T.label, padding: '9px 14px', fontSize: 14 }}
      />
    </div>
  )
}

/** Label-left form row (add-host page): fixed label column + flexible field. */
function FormRow(props: { label: string; children: unknown }) {
  return (
    <div style={{ minWidth: 0, display: 'flex', flexDirection: 'column', gap: 6 }}>
      <div style={{ fontSize: 12, lineHeight: 1.2, color: T.muted, whiteSpace: 'nowrap' }}>{props.label}</div>
      <div style={{ minWidth: 0, display: 'flex', gap: 8 }}>{props.children as never}</div>
    </div>
  )
}

/** Compact one-line copy. Long dynamic errors remain available in the title. */
function SingleLine(props: { text: string; color?: string; style?: CSSProperties }) {
  return (
    <div
      title={props.text}
      style={{ color: props.color ?? T.muted, fontSize: 12, lineHeight: 1.5, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', ...props.style }}
    >
      {props.text}
    </div>
  )
}

/** One row in the inline directory listing, with hover highlight. */
function DirRow(props: { item: LsItem; drill: boolean; onEnter: () => void; t: Translate }) {
  const [hov, setHov] = useState(false)
  const { item, drill } = props
  return (
    <div
      title={props.t(drill ? 'enterDirectory' : 'fileItem', { name: item.name })}
      onClick={drill ? props.onEnter : undefined}
      onMouseEnter={() => setHov(true)}
      onMouseLeave={() => setHov(false)}
      style={{ padding: '8px 12px', cursor: drill ? 'pointer' : 'default', color: T.label, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', display: 'flex', gap: 10, alignItems: 'center', fontSize: 14, borderRadius: 6, background: hov && drill ? T.bgHover : 'transparent' }}
    >
      <span style={{ color: T.muted, display: 'flex', flexShrink: 0 }}>{item.type === 'dir' ? <SvgFolder /> : item.type === 'symlink' ? <SvgLink /> : <SvgFile />}</span>
      <span style={{ overflow: 'hidden', textOverflow: 'ellipsis', flex: 1 }}>{item.name}</span>
      {drill ? (
        <span style={{ color: T.muted, display: 'flex' }}>
          <SvgChevronRight size={13} />
        </span>
      ) : null}
    </div>
  )
}

/** Entry-step card: lifts and highlights on hover, chevron hints drill-in. */
function FlowCard(props: { icon: unknown; title: string; onClick: () => void }) {
  const [hov, setHov] = useState(false)
  return (
    <div
      onClick={props.onClick}
      onMouseEnter={() => setHov(true)}
      onMouseLeave={() => setHov(false)}
      style={{
        flex: 1,
        border: '1px solid ' + (hov ? T.accent : T.border),
        borderRadius: 12,
        padding: '18px 16px',
        cursor: 'pointer',
        background: hov ? T.bgHover : T.bg,
        display: 'flex',
        alignItems: 'center',
        gap: 12,
        transform: hov ? 'translateY(-1px)' : 'none',
        boxShadow: hov ? '0 6px 20px rgba(0,0,0,0.25)' : 'none',
        transition: 'border-color .15s, background .15s, transform .15s, box-shadow .15s',
      }}
    >
      <div style={{ color: hov ? T.accent : T.label, display: 'flex', flexShrink: 0, transition: 'color .15s' }}>{props.icon as never}</div>
      <div style={{ flex: 1, minWidth: 0, fontWeight: 650, fontSize: 13, letterSpacing: '0.035em', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
        {props.title}
      </div>
      <div style={{ color: hov ? T.accent : T.muted, display: 'flex', flexShrink: 0, transition: 'color .15s' }}>
        <SvgArrowRight size={17} />
      </div>
    </div>
  )
}

// ── the picker ──────────────────────────────────────────────────────────────

function DirPicker(props: LocalizedDirPickerProps) {
  const { open, busy, onPicked, onCancel, locale, t } = props
  // DSH persists the active language in the Host-backed global settings.
  // Subscribe to the locale revision so an open picker switches immediately
  // when the user changes Language, including late dictionary registration.
  const localeRevision = useSyncExternalStore(
    useCallback((callback: () => void) => locale.subscribe(callback), [locale]),
    useCallback(() => locale.getSnapshot().revision, [locale]),
  )
  void localeRevision
  // 视图状态机：cards（两张大卡片入口）→ local / remote 表单页；addHost 是
  // 从 remote 页跳入的独立子页，四者互斥，除 cards 外都有「← 返回」。
  const [view, setView] = useState<'cards' | 'local' | 'remote' | 'addHost'>('cards')
  const [hosts, setHosts] = useState<HostSummary[]>([])
  const [alias, setAlias] = useState('')
  const [path, setPath] = useState('')
  // 本机路径独立成 state：远程页会把 path 写成远端 home（~/ 扩展结果），
  // 共用一个 state 会让远程路径残留进本机输入框。
  const [localPath, setLocalPath] = useState('')
  const [wsName, setWsName] = useState('')
  const [err, setErr] = useState('')
  const [loading, setLoading] = useState(false)
  // 行内目录列表状态：dirBase 是列表内容所属的目录，dirItems 是该目录下
  // 可下钻的条目（仅目录/符号链接；点行下钻，↑ 回上一级）。
  const [dirItems, setDirItems] = useState<LsItem[]>([])
  const [dirBase, setDirBase] = useState('')
  // 本机页有自己的行内列表：与远程列表分开，两个页面互不干扰。
  const [localItems, setLocalItems] = useState<LsItem[]>([])
  const [localBase, setLocalBase] = useState('')
  const [localParent, setLocalParent] = useState<string | null>(null)
  const suggestTimer = useRef<number | null>(null)
  const localTimer = useRef<number | null>(null)
  // 「添加主机」子页表单状态（view === 'addHost' 时独占整页）。
  const [form, setForm] = useState<AddHostForm>(emptyAddForm)
  const [formErr, setFormErr] = useState('')
  const [testing, setTesting] = useState(false)
  // 主机列表的健康状态与编辑目标：testHost 写入，HostCard 读取。
  const [hostHealth, setHostHealth] = useState<Record<string, HostHealth>>({})
  // ssh-config aliases removed from the list (they stay in ~/.ssh/config).
  const [hiddenAliases, setHiddenAliases] = useState<string[]>([])
  const [editingAlias, setEditingAlias] = useState('')
  const [saving, setSaving] = useState(false)
  const [testMsg, setTestMsg] = useState('')
  const [testOk, setTestOk] = useState(false)

  // On open: always land on the card step, then fetch the host inventory
  // (+ current alias for preselection).
  useEffect(() => {
    if (!open) return
    setView('cards')
    setWsName('')
    setErr('')
    api<StatusResponse>('GET', '/api/dsh-rw/status')
      .then((r) => {
        const list = Array.isArray(r.hosts) ? r.hosts : []
        setHosts(list)
        setHiddenAliases(Array.isArray(r.hiddenAliases) ? r.hiddenAliases : [])
        const cur = r.current && typeof r.current.alias === 'string' ? r.current.alias : ''
        // Prefer the live session host, then the machine used last time, then
        // the first host that is actually usable.
        let remembered = ''
        try {
          remembered = window.localStorage.getItem(HOST_KEY) ?? ''
        } catch {
          remembered = ''
        }
        const lastUsable = list.some((h) => h.alias === remembered && hostProblem(h, t) === null) ? remembered : ''
        setAlias(cur || lastUsable || (list[0] ? list[0].alias : ''))
      })
      .catch((e) => setErr(t('loadHostsFailed', { error: errText(e) })))
  }, [open, t])

  useEffect(
    () => () => {
      if (suggestTimer.current !== null) window.clearTimeout(suggestTimer.current)
      if (localTimer.current !== null) window.clearTimeout(localTimer.current)
    },
    [],
  )

  // 行内目录列表的数据源：列出 dir 的下钻条目（仅目录/符号链接）。
  // sync=true 时把服务端解析后的真实路径回填输入框（用于 ~/ 默认路径，
  // 服务端经 realpath('.') 扩展为远端 home 的绝对路径）。
  const loadDir = (a: string, dir: string, sync?: boolean) => {
    if (!a) return
    setLoading(true)
    setErr('')
    api<LsResponse>('GET', `/api/dsh-rw/ls?alias=${encodeURIComponent(a)}&path=${encodeURIComponent(dir || '/')}`)
      .then((res) => {
        const real = res.path || dir || '/'
        setDirBase(real)
        if (sync) setPath(real)
        setDirItems((Array.isArray(res.items) ? res.items : []).filter(drillable).slice(0, 400))
      })
      .catch((e) => {
        setDirItems([])
        setErr(errText(e))
      })
      .finally(() => setLoading(false))
  }

  // 输入补全：对末段的父目录做 ls，按末段前缀过滤，结果同样进列表。
  const completePath = (raw: string, aid?: string) => {
    const a = aid || alias
    const t = String(raw || '').trim()
    if (!a || !t) {
      setDirItems([])
      return
    }
    const slash = t.lastIndexOf('/')
    const parent = slash <= 0 ? '/' : t.slice(0, slash)
    const lastSeg = slash < 0 ? t : t.slice(slash + 1)
    api<LsResponse>('GET', `/api/dsh-rw/ls?alias=${encodeURIComponent(a)}&path=${encodeURIComponent(parent)}`)
      .then((res) => {
        const list = Array.isArray(res.items) ? res.items : []
        setDirBase(res.path || parent)
        setDirItems(
          list
            .filter((it) => drillable(it) && it.name.toLowerCase().startsWith(lastSeg.toLowerCase()))
            .slice(0, 400),
        )
      })
      .catch(() => setDirItems([]))
  }

  const onPathChange = (raw: string) => {
    setPath(raw)
    setErr('')
    if (suggestTimer.current !== null) window.clearTimeout(suggestTimer.current)
    suggestTimer.current = window.setTimeout(() => completePath(raw), 220)
  }

  // 下钻：点列表里的一行 → 路径进入该目录并刷新列表。
  const selectDir = (name: string) => {
    const base = dirBase || '/'
    const next = base === '/' ? '/' + name : base + '/' + name
    setPath(next)
    setErr('')
    loadDir(alias, next)
  }

  // ↑ 回上一级：取输入框路径的父目录并刷新列表。
  const goUp = () => {
    const norm = String(path || '').replace(/\/+$/, '')
    const idx = norm.lastIndexOf('/')
    const parent = idx <= 0 ? '/' : norm.slice(0, idx)
    setPath(parent)
    setErr('')
    loadDir(alias, parent)
  }

  // 本机目录列表的数据源（GET /api/dsh-rw/ls-local）。sync=true 时把服务端
  // 展开后的绝对路径回填输入框（~ 与服务端 home 保持一致）。
  const loadLocalDir = (dir: string, sync?: boolean) => {
    setLoading(true)
    setErr('')
    api<LsResponse>('GET', `/api/dsh-rw/ls-local?path=${encodeURIComponent(dir || '~')}`)
      .then((res) => {
        const real = res.path || dir || '~'
        setLocalBase(real)
        setLocalParent(res.parent === undefined ? null : res.parent)
        if (sync) setLocalPath(real)
        setLocalItems((Array.isArray(res.items) ? res.items : []).filter(drillable).slice(0, 400))
      })
      .catch((e) => {
        setLocalItems([])
        setErr(errText(e))
      })
      .finally(() => setLoading(false))
  }

  const selectLocalDir = (name: string) => {
    const base = localBase || '~'
    const next = base === '/' ? '/' + name : base + '/' + name
    setLocalPath(next)
    setErr('')
    loadLocalDir(next)
  }

  const goLocalUp = () => {
    const target = localParent ?? (() => {
      const norm = String(localPath || '').replace(/\/+$/, '')
      const idx = norm.lastIndexOf('/')
      return idx <= 0 ? '/' : norm.slice(0, idx)
    })()
    setLocalPath(target)
    setErr('')
    loadLocalDir(target)
  }

  // 输入过滤：对本机路径的父目录做一次 ls，按末段前缀筛选。
  const completeLocalPath = (raw: string) => {
    const value = String(raw || '').trim()
    if (!value) {
      setLocalItems([])
      return
    }
    const slash = value.lastIndexOf('/')
    const parent = slash <= 0 ? '/' : value.slice(0, slash)
    const lastSeg = slash < 0 ? value : value.slice(slash + 1)
    api<LsResponse>('GET', `/api/dsh-rw/ls-local?path=${encodeURIComponent(parent || '/')}`)
      .then((res) => {
        const list = Array.isArray(res.items) ? res.items : []
        setLocalBase(res.path || parent || '/')
        setLocalParent(res.parent === undefined ? null : res.parent)
        setLocalItems(
          list
            .filter((it) => drillable(it) && it.name.toLowerCase().startsWith(lastSeg.toLowerCase()))
            .slice(0, 400),
        )
      })
      .catch(() => setLocalItems([]))
  }

  const onLocalPathChange = (raw: string) => {
    setLocalPath(raw)
    setErr('')
    if (localTimer.current !== null) window.clearTimeout(localTimer.current)
    localTimer.current = window.setTimeout(() => completeLocalPath(raw), 220)
  }

  // 选用本机目录：记住它，下次打开本机页直接从这里开始。
  const pickLocal = (value: string) => {
    const target = String(value || '').trim()
    if (!target) return
    try {
      window.localStorage.setItem(LOCAL_PATH_KEY, target)
    } catch {
      // storage may be disabled; picking still works
    }
    onPicked(target)
  }

  const chooseLocal = () => {
    setLoading(true)
    setErr('')
    api<LocalPickResponse>('POST', '/api/dsh-rw/local-pick')
      .then((r) => {
        if (r && r.path) pickLocal(String(r.path))
        else if (r && r.cancelled) setErr(t('selectionCancelled'))
        else setErr((r && r.error) || t('localPickerUnavailable'))
      })
      .catch((e) => setErr(t('localPickerFallback', { error: errText(e) })))
      .finally(() => setLoading(false))
  }

  // 进入本机/远程表单页（卡片步点击或子页返回时调用）。
  const openFlow = (t: 'local' | 'remote') => {
    setView(t)
    setErr('')
    if (t === 'local') {
      // Start where the operator last chose, so the common case is one click.
      let remembered = ''
      try {
        remembered = window.localStorage.getItem(LOCAL_PATH_KEY) ?? ''
      } catch {
        remembered = ''
      }
      const start = localPath.trim() || remembered
      if (start) {
        setLocalPath(start)
        loadLocalDir(start)
      } else {
        loadLocalDir('~', true)
      }
      return
    }
    if (t === 'remote' && alias) {
      // 已输入过路径则保留（列表跟随其内容），否则默认落在远端 home（~/）。
      const start = path.trim()
      if (start) {
        loadDir(alias, start)
      } else {
        setPath('~/')
        loadDir(alias, '~/', true)
      }
    }
  }

  // Commit the remote path as the workspace: the host resolves it (realpath),
  // creates the local placeholder dir (named by 工作区名称 when given), and
  // answers with its path.
  const commitPath = (p: string) => {
    const target = String(p || '').trim()
    if (!target || !alias || busy) return
    const name = wsName.trim()
    api<WorkspaceResponse>('POST', '/api/dsh-rw/workspace', { alias, path: target, ...(name ? { name } : {}) })
      .then((res) => {
        if (res && res.ok && res.placeholderDir) {
          rememberHost(alias)
          onPicked(String(res.placeholderDir))
        } else {
          setErr((res && res.error) || t('setRemoteWorkspaceFailed'))
        }
      })
      .catch((e) => setErr(errText(e)))
  }

  // ── 添加主机表单 ────────────────────────────────────────────────────────

  // 表单局部更新：任何字段改动都让旧的测试结果失效。
  const updForm = (patch: Partial<AddHostForm>) => {
    setForm((f) => ({ ...f, ...patch }))
    setFormErr('')
    setTestMsg('')
  }

  // 收起/关闭时清空（密码与私钥口令不留存于 state）。
  const resetAddForm = () => {
    setForm(emptyAddForm())
    setFormErr('')
    setTestMsg('')
    setTestOk(false)
  }

  // 保存前置校验（与 host 端 addManual 一致）；测试连接不需要别名。
  const addFormError = (forSave: boolean): string => {
    if (forSave && !ALIAS_RE.test(form.alias.trim())) return t('aliasInvalid')
    if (!form.host.trim()) return t('hostRequired')
    if (!form.user.trim()) return t('userRequired')
    // While editing, a blank credential means "keep the stored one".
    if (!editingAlias) {
      if (form.authKind === 'key' && !form.keyPath.trim()) return t('keyPathRequired')
      if (form.authKind === 'password' && !form.password) return t('passwordRequired')
    }
    return ''
  }

  // 连接参数（不含别名）：测试与保存共用；二选一认证，与 addManual 语义一致。
  const addFormPayload = () => ({
    host: form.host.trim(),
    port: Number.parseInt(form.port, 10) || 22,
    user: form.user.trim(),
    ...(form.authKind === 'key'
      ? { keyPath: form.keyPath.trim(), ...(form.passphrase ? { passphrase: form.passphrase } : {}) }
      : { password: form.password }),
  })

  // 刷新主机列表（沿用现有 status 端点）。
  const refreshHosts = () =>
    api<StatusResponse>('GET', '/api/dsh-rw/status').then((r) => {
      const list = Array.isArray(r.hosts) ? r.hosts : []
      setHosts(list)
      setHiddenAliases(Array.isArray(r.hiddenAliases) ? r.hiddenAliases : [])
      return list
    })

  /**
   * Drop one ssh-config host from the list. The file is NOT touched: the plugin
   * remembers the alias, and "显示全部" puts it back.
   */
  const hideHost = (h: HostSummary) => {
    setErr('')
    api<{ ok?: boolean; hiddenAliases?: string[] }>('POST', '/api/dsh-rw/hosts/hide', { alias: h.alias })
      .then((r) => {
        setHiddenAliases(Array.isArray(r.hiddenAliases) ? r.hiddenAliases : [])
        return refreshHosts()
      })
      .then((list) => {
        if (alias !== h.alias) return
        // The selected host just disappeared: fall back to the first remaining.
        const next = list[0] ? list[0].alias : ''
        setAlias(next)
        setDirItems([])
        if (next) {
          setPath('~/')
          loadDir(next, '~/', true)
        }
      })
      .catch((e) => setErr(errText(e)))
  }

  /** Put every hidden alias back. */
  const unhideAll = () => {
    setErr('')
    Promise.all(hiddenAliases.map((a) => api<{ ok?: boolean }>('POST', '/api/dsh-rw/hosts/hide', { alias: a, hidden: false })))
      .then(() => refreshHosts())
      .catch((e) => setErr(errText(e)))
  }

  /** Remember the host so the next open lands on it. */
  const rememberHost = (a: string) => {
    if (!a) return
    try {
      window.localStorage.setItem(HOST_KEY, a)
    } catch {
      // storage may be disabled; selection still works for this session
    }
  }

  /** Pick a registered host: select it and load its home directory. */
  const selectHost = (a: string) => {
    setAlias(a)
    setErr('')
    if (!a) {
      setDirItems([])
      return
    }
    setPath('~/')
    loadDir(a, '~/', true)
    rememberHost(a)
  }

  /** Probe one registered host and keep the outcome for its row. */
  const testHost = (h: HostSummary) => {
    setHostHealth((prev) => ({ ...prev, [h.alias]: { state: 'testing' } }))
    api<TestResponse>('POST', '/api/dsh-rw/test', { alias: h.alias })
      .then((r) => {
        setHostHealth((prev) => ({
          ...prev,
          [h.alias]:
            r && r.ok
              ? { state: 'ok', ...(typeof r.latencyMs === 'number' ? { ms: r.latencyMs } : {}) }
              : { state: 'fail', error: (r && r.error) || t('connectionFailed') },
        }))
      })
      .catch((e) => setHostHealth((prev) => ({ ...prev, [h.alias]: { state: 'fail', error: errText(e) } })))
  }

  /** Open the add-host form pre-filled for an existing manual host. */
  const startEditHost = (h: HostSummary) => {
    setEditingAlias(h.alias)
    setForm({
      alias: h.alias,
      host: h.host,
      port: String(h.port),
      user: h.user,
      authKind: h.authKind,
      keyPath: h.keyPath ?? '',
      passphrase: '',
      password: '',
    })
    setFormErr('')
    setTestMsg('')
    setTestOk(false)
    setView('addHost')
  }

  // 测试连接：完整字段形式 POST /test —— 临时探测，不入库。
  const testNewHost = () => {
    const msg = addFormError(false)
    if (msg) {
      setFormErr(msg)
      return
    }
    setTesting(true)
    setFormErr('')
    setTestMsg('')
    api<TestResponse>('POST', '/api/dsh-rw/test', addFormPayload())
      .then((r) => {
        if (r && r.ok) {
          setTestOk(true)
          setTestMsg(t('connectionSuccess', { latency: r.latencyMs ?? 0 }))
        } else {
          setTestOk(false)
          setTestMsg(t('connectionFailure', {
            error: (r && r.error) || t('connectionFailed'),
            code: r && r.code ? ` [${r.code}]` : '',
          }))
        }
      })
      .catch((e) => {
        setTestOk(false)
        setTestMsg('✗ ' + errText(e))
      })
      .finally(() => setTesting(false))
  }

  // 保存手动主机：编辑模式发 PATCH（别名不可改），否则 POST 新增。成功后清空
  // 表单（含密码）、回到远程页、刷新列表并选中该主机。
  const saveNewHost = () => {
    const msg = addFormError(true)
    if (msg) {
      setFormErr(msg)
      return
    }
    const targetAlias = editingAlias || form.alias.trim()
    setSaving(true)
    setFormErr('')
    const request = editingAlias
      ? api<AddHostResponse>('PATCH', '/api/dsh-rw/hosts', { alias: editingAlias, ...addFormPayload() })
      : api<AddHostResponse>('POST', '/api/dsh-rw/hosts', { alias: targetAlias, ...addFormPayload() })
    request
      .then(() => {
        resetAddForm()
        setEditingAlias('')
        setView('remote')
        refreshHosts()
          .then(() => {
            setAlias(targetAlias)
            setErr('')
            setPath('~/')
            loadDir(targetAlias, '~/', true)
            rememberHost(targetAlias)
          })
          .catch((e) => setErr(t('hostSavedRefreshFailed', { error: errText(e) })))
      })
      .catch((e) => setFormErr(errText(e)))
      .finally(() => setSaving(false))
  }

  // 删除手动主机（ssh-config 条目在 hosts 端就会被拒，这里不显示按钮）。
  const removeManualHost = (h: HostSummary) => {
    if (!window.confirm(t('removeHostConfirm', { alias: h.alias }))) return
    setErr('')
    api<{ ok?: boolean }>('DELETE', '/api/dsh-rw/hosts', { alias: h.alias })
      .then(() => refreshHosts())
      .then((list) => {
        if (alias === h.alias) {
          const next = list[0] ? list[0].alias : ''
          setAlias(next)
          setDirItems([])
          if (next) {
            setPath('~/')
            loadDir(next, '~/', true)
          }
        }
      })
      .catch((e) => setErr(t('removeHostFailed', { error: errText(e) })))
  }

  function renderAddForm() {
    const busyForm = testing || saving
    // 认证方式分段选择器的一段。
    const seg = (kind: 'key' | 'password', label: string) => {
      const active = form.authKind === kind
      return (
        <button
          onClick={() => updForm({ authKind: kind })}
          style={{
            ...buttonS,
            flex: 1,
            border: '1px solid ' + (active ? T.accent : T.border),
            background: active ? T.bgHover : 'transparent',
            color: active ? T.accent : T.label,
            fontWeight: active ? 600 : 400,
          }}
        >
          {label}
        </button>
      )
    }
    return (
      <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
        <SingleLine text={editingAlias ? t('editHostHint') : t('manualHostHint')} />
        <div style={{ display: 'grid', gridTemplateColumns: 'minmax(0, 0.9fr) minmax(0, 1.35fr)', gap: 12 }}>
          <FormRow label={t('nameLabel')}>
            <TextInput
              value={form.alias}
              onChange={(e: { target: { value: string } }) => updForm({ alias: e.target.value })}
              placeholder={t('aliasPlaceholder')}
              disabled={editingAlias !== ''}
            />
            {editingAlias ? <SingleLine text={t('aliasFixedHint')} /> : null}
          </FormRow>
          <FormRow label={t('hostLabel')}>
            <TextInput value={form.host} onChange={(e: { target: { value: string } }) => updForm({ host: e.target.value })} placeholder={t('hostPlaceholder')} />
          </FormRow>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'minmax(0, 1fr) 112px', gap: 12 }}>
          <FormRow label={t('userLabel')}>
            <TextInput value={form.user} onChange={(e: { target: { value: string } }) => updForm({ user: e.target.value })} placeholder="root" />
          </FormRow>
          <FormRow label={t('portLabel')}>
            <TextInput value={form.port} onChange={(e: { target: { value: string } }) => updForm({ port: e.target.value })} placeholder="22" inputMode="numeric" />
          </FormRow>
        </div>
        <FormRow label={t('authMethodLabel')}>
          {seg('key', t('keyPathLabel'))}
          {seg('password', t('passwordLabel'))}
        </FormRow>
        {form.authKind === 'key' ? (
          <div style={{ display: 'grid', gridTemplateColumns: 'minmax(0, 1.35fr) minmax(0, 0.9fr)', gap: 12 }}>
            <FormRow label={t('keyPathLabel')}>
              <TextInput value={form.keyPath} onChange={(e: { target: { value: string } }) => updForm({ keyPath: e.target.value })} placeholder="~/.ssh/id_ed25519" />
            </FormRow>
            <FormRow label={t('passphraseLabel')}>
              <TextInput value={form.passphrase} onChange={(e: { target: { value: string } }) => updForm({ passphrase: e.target.value })} type="password" placeholder={t('optionalPlaceholder')} />
            </FormRow>
          </div>
        ) : (
          <FormRow label={t('passwordLabel')}>
            <TextInput value={form.password} onChange={(e: { target: { value: string } }) => updForm({ password: e.target.value })} type="password" placeholder={t('passwordPlaceholder')} />
          </FormRow>
        )}
        {formErr ? <SingleLine text={formErr} color={T.danger} /> : null}
        {testMsg ? <SingleLine text={testMsg} color={testOk ? T.ok : T.danger} /> : null}
        <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end', borderTop: '1px solid ' + T.border, paddingTop: 12, marginTop: 2 }}>
          <Btn onClick={resetAddForm} disabled={busyForm}>
            {t('clear')}
          </Btn>
          <Btn onClick={testNewHost} disabled={busyForm}>
            {testing ? t('testing') : t('testConnection')}
          </Btn>
          <Btn primary onClick={saveNewHost} disabled={busyForm}>
            {saving ? t('saving') : editingAlias ? t('saveChanges') : t('save')}
          </Btn>
        </div>
      </div>
    )
  }

  if (!open) return null

  const selectedHost = hosts.find((h) => h.alias === alias)

  // 卡片步：两张简洁入口卡片（本机 / 远程），点击进入对应表单页。
  const card = (flow: 'local' | 'remote', icon: unknown, title: string) => <FlowCard onClick={() => openFlow(flow)} icon={icon} title={title} />

  // 圆形返回钮（无文字）：addHost 子页回远程表单页（接管旧「取消」职责，
  // 清空表单——密码与私钥口令不留存于 state），其余表单页回卡片步。
  const backBtn = (
    <Btn
      title={t('back')}
      style={{ width: 32, height: 32, padding: 0, borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}
      onClick={() => {
        if (view === 'addHost') {
          resetAddForm()
          setEditingAlias('')
          setView('remote')
        } else {
          setView('cards')
        }
      }}
      disabled={busy}
    >
      <SvgArrowLeft size={16} />
    </Btn>
  )

  const viewTitle = view === 'cards'
    ? t('chooseWorkDirectory')
    : view === 'local'
      ? t('localDirectory')
      : view === 'remote'
        ? t('remoteWorkspace')
        : t('addRemoteHost')

  // 全屏居中 modal（遮罩 + 面板）：在窄 sidebar 和 conversation 里渲染一致。
  return (
    <div
      style={{ position: 'fixed', inset: 0, zIndex: 9999, background: 'rgba(0,0,0,0.5)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 16 }}
      onClick={() => {
        if (!busy) onCancel()
      }}
    >
      <div
        style={{ background: panelBg, border: '1px solid ' + T.borderStrong, borderRadius: 14, boxShadow: '0 16px 56px rgba(0,0,0,0.55)', width: 'min(640px, 94vw)', padding: 22, boxSizing: 'border-box' }}
        onClick={(e) => e.stopPropagation()}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 16 }}>
          {view !== 'cards' ? backBtn : null}
          <div style={{ flex: 1, minWidth: 0, fontSize: 17, fontWeight: 600, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{viewTitle}</div>
          <Btn
            style={{ padding: '4px 6px', border: '1px solid transparent', background: 'transparent', color: T.muted, display: 'flex', alignItems: 'center' }}
            onClick={() => {
              if (!busy) onCancel()
            }}
            disabled={busy}
          >
            <SvgX />
          </Btn>
        </div>
        {view === 'cards' ? (
          <div style={{ display: 'flex', gap: 12 }}>
            {card('local', <SvgMonitor size={22} />, t('localCardTitle'))}
            {card('remote', <SvgGlobe size={22} />, t('remoteCardTitle'))}
          </div>
        ) : null}
        {view === 'local' ? (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            <SingleLine text={t('localPickerHint')} />
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              <div style={labelS}>{t('localPathLabel')}</div>
              <div style={{ display: 'flex', gap: 8 }}>
                <TextInput
                  value={localPath}
                  onChange={(e) => onLocalPathChange(e.target.value)}
                  onFocus={() => (localPath.trim() ? completeLocalPath(localPath) : loadLocalDir('~', true))}
                  placeholder={t('localPathPlaceholder')}
                  style={{ flex: 1, minWidth: 120 }}
                />
                <Btn primary onClick={() => pickLocal(localPath)} disabled={!localPath.trim()}>
                  {t('useDirectory')}
                </Btn>
              </div>
              {/* 行内本机目录浏览器：与远程页同一套交互，不必再打开系统选择器。 */}
              <div style={{ border: '1px solid ' + T.border, borderRadius: 10, background: T.bg, maxHeight: 240, overflowY: 'auto', overflowX: 'hidden', padding: 4 }}>
                {loading ? (
                  <SingleLine text={t('loading')} style={{ padding: 12 }} />
                ) : (
                  <>
                    {localParent !== null ? (
                      <div
                        role="button"
                        tabIndex={0}
                        onClick={goLocalUp}
                        onKeyDown={(e) => (e.key === 'Enter' || e.key === ' ' ? goLocalUp() : undefined)}
                        style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '7px 10px', borderRadius: 8, cursor: 'pointer', color: T.muted, fontSize: 13 }}
                      >
                        <SvgFolder /> .. {t('goUp')}
                      </div>
                    ) : null}
                    {localItems.length ? (
                      localItems.map((it, i) => <DirRow key={it.name + '-' + i} item={it} drill onEnter={() => selectLocalDir(it.name)} t={t} />)
                    ) : (
                      <SingleLine text={t('noMatchingDirectories')} style={{ padding: 12 }} />
                    )}
                  </>
                )}
              </div>
            </div>
            <Btn style={{ alignSelf: 'flex-start' }} onClick={chooseLocal} disabled={loading}>
              {loading ? t('opening') : t('openSystemPicker')}
            </Btn>
            {err ? <SingleLine text={err} color={T.danger} /> : null}
          </div>
        ) : null}
        {view === 'remote' || view === 'addHost' ? (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 18 }}>
            {view === 'addHost' ? (
              renderAddForm()
            ) : (
              <>
                {/* 工作区名称（可选）：Codex 式图标格输入框，置顶；留空用路径末级目录名 */}
                <IconInput icon={<SvgFolder />} value={wsName} onChange={(e) => setWsName(e.target.value)} placeholder={t('workspaceNamePlaceholder')} />
                {/* 远程主机：caption 行内放「+ 添加主机 / 删除」，下拉选项只显示别名 */}
                <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                    <div style={{ ...labelS, flex: 1 }}>{t('remoteHostLabel')}</div>
                    <Btn
                      style={{ padding: '2px 9px', border: '1px solid transparent', background: 'transparent', color: T.accent, fontSize: 12, whiteSpace: 'nowrap' }}
                      onClick={() => {
                        resetAddForm()
                        setView('addHost')
                      }}
                    >
                      {t('addHost')}
                    </Btn>
                    {selectedHost && selectedHost.source === 'manual' ? (
                      <Btn danger style={{ padding: '2px 9px', fontSize: 12, whiteSpace: 'nowrap' }} title={t('removeManualHostTitle', { alias: selectedHost.alias })} onClick={() => removeManualHost(selectedHost)}>
                        {t('remove')}
                      </Btn>
                    ) : null}
                  </div>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                    {hosts.map((h) => (
                      <HostCard
                        key={h.alias}
                        host={h}
                        active={h.alias === alias}
                        health={hostHealth[h.alias]}
                        t={t}
                        onPick={() => selectHost(h.alias)}
                        onTest={() => testHost(h)}
                        onEdit={h.source === 'manual' ? () => startEditHost(h) : undefined}
                        onRemove={h.source === 'manual' ? () => removeManualHost(h) : undefined}
                        onHide={h.source === 'manual' ? undefined : () => hideHost(h)}
                      />
                    ))}
                  </div>
                </div>
                {hosts.length === 0 ? (
                  <SingleLine text={t('noHosts')} />
                ) : null}
                {hiddenAliases.length > 0 ? (
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
                    <SingleLine text={t('hiddenHosts', { count: hiddenAliases.length, aliases: hiddenAliases.join(', ') })} />
                    <Btn style={{ padding: '2px 9px', fontSize: 12, border: '1px solid transparent', background: 'transparent', color: T.accent }} onClick={unhideAll}>
                      {t('showAllHidden')}
                    </Btn>
                  </div>
                ) : null}
                {/* 远程路径：↑ 上一级 + 输入框，下方行内目录列表实时跟随 */}
                <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                  <div style={labelS}>{t('remotePathLabel')}</div>
                  <div style={{ display: 'flex', gap: 10, alignItems: 'stretch' }}>
                    <Btn style={{ padding: '0 12px', flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'center' }} title={t('parentDirectory')} onClick={goUp} disabled={!alias}>
                      <SvgArrowUp />
                    </Btn>
                    <TextInput
                      value={path}
                      onChange={(e: { target: { value: string } }) => onPathChange(e.target.value)}
                      onFocus={() => completePath(path)}
                      placeholder={alias ? t('remotePathPlaceholder') : t('chooseHostFirst')}
                      disabled={!alias}
                      style={{ flex: 1, minWidth: 120 }}
                    />
                  </div>
                  <div style={{ border: '1px solid ' + T.border, borderRadius: 10, background: T.bg, maxHeight: 240, overflowY: 'auto', overflowX: 'hidden', padding: 4 }}>
                    {!alias ? (
                      <SingleLine text={t('chooseHostFirst')} style={{ padding: 12 }} />
                    ) : loading ? (
                      <SingleLine text={t('loading')} style={{ padding: 12 }} />
                    ) : dirItems.length ? (
                      dirItems.map((it, i) => <DirRow key={it.name + '-' + i} item={it} drill onEnter={() => selectDir(it.name)} t={t} />)
                    ) : (
                      <SingleLine text={t('noMatchingDirectories')} style={{ padding: 12 }} />
                    )}
                  </div>
                </div>
                {err ? <SingleLine text={err} color={T.danger} /> : null}
                <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end', alignItems: 'center', borderTop: '1px solid ' + T.border, paddingTop: 12, marginTop: 2 }}>
                  <Btn style={{ border: '1px solid transparent', background: 'transparent', color: T.muted }} onClick={onCancel} disabled={busy}>
                    {t('cancel')}
                  </Btn>
                  <Btn primary onClick={() => commitPath(path)} disabled={busy || !alias || !path.trim()}>
                    {busy ? t('setting') : t('setRemoteWorkspace')}
                  </Btn>
                </div>
              </>
            )}
          </div>
        ) : null}
        {view === 'local' ? (
          <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
            <Btn style={{ border: '1px solid transparent', background: 'transparent', color: T.muted }} onClick={onCancel}>
              {t('cancel')}
            </Btn>
          </div>
        ) : null}
      </div>
    </div>
  )
}

// ── registration ────────────────────────────────────────────────────────────

/** Slot-registration metadata accepted by the DSH ui-slots client service. */
interface SlotMeta {
  name: string
  id: string
  priority: number
}

/** Structural slice of the DSH `slots` client service this plugin uses. */
interface SlotsLike {
  inject(slot: string, factory: () => unknown): unknown
  register(meta: SlotMeta, component: unknown): unknown
}

const LOCALE_NS = 'dsh-rw'

/** Client services required before the directory-flow contribution mounts. */
export const inject = ['slots', 'locale']

/**
 * Cordis client entry: register DirPicker into both directory-flow slots
 * (sidebar + conversation hero) at priority -100. The nested-inject shape is
 * copied from dsh-remote so installing into either slot drags the other along.
 */
export function apply(ctx: unknown): void {
  const get = (ctx as { get?: unknown } | null | undefined)?.get
  if (typeof get !== 'function') return
  const slots = (get as (key: string) => unknown).call(ctx, 'slots') as SlotsLike | null | undefined
  const locale = (get as (key: string) => unknown).call(ctx, 'locale') as LocaleLike | null | undefined
  if (
    !slots || typeof slots.inject !== 'function' || typeof slots.register !== 'function' ||
    !locale || typeof locale.register !== 'function' || typeof locale.bind !== 'function' ||
    typeof locale.subscribe !== 'function' || typeof locale.getSnapshot !== 'function'
  ) return

  const registerDictionaries = () => locale.register(LOCALE_NS, { zh, en })
  const effect = (ctx as { effect?: unknown }).effect
  if (typeof effect === 'function') {
    effect.call(ctx, registerDictionaries, 'dsh-rw: locale dictionaries')
  } else {
    // Structural test/legacy contexts may not expose effect; registering is
    // still safe for their activation lifetime.
    registerDictionaries()
  }
  const t = locale.bind(LOCALE_NS)
  const LocalizedDirPicker = (props: DirPickerProps) => <DirPicker {...props} locale={locale} t={t} />

  slots.inject('conversation.hero.workspace.directoryFlow', () =>
    slots.inject('sidebar.workspaces.directoryFlow', function* () {
      yield slots.register({ name: 'conversation.hero.workspace.directoryFlow', id: 'dsh-rw', priority: -100 }, LocalizedDirPicker)
      yield slots.register({ name: 'sidebar.workspaces.directoryFlow', id: 'dsh-rw', priority: -100 }, LocalizedDirPicker)
    }),
  )
}
