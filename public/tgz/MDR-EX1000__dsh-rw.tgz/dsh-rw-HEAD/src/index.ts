// dsh-rw — Remote-SSH-style workspace for DeepSeek Harness.
//
// Host half. The remote filesystem is the source of truth: the agent works on
// a remote directory through rw_* tools (SFTP/exec over a persistent ssh2
// pool). The local directory registered with DSH is only a placeholder so the
// native workspace flow accepts it — it never holds a copy of remote files.
import type { Context } from '@deepseek-ai/cordis'
import type {} from '@deepseek-ai/dsh-host-webserver'
import type {} from '@deepseek-ai/dsh-settings'
import type {} from '@deepseek-ai/dsh-system-prompt'
import type { ToolDefinition } from '@deepseek-ai/dsh-tools'
import z from 'schemastery'
import { HostTable } from './hosts.js'
import { KnownHosts } from './known-hosts.js'
import { makeRoutes } from './routes.js'
import { Session } from './session.js'
import { createNativeRouting, makeShim } from './shim.js'
import type { ShimConfig } from './shim.js'
import { resolvePlaceholderDir } from './placeholder.js'
import { SshPool } from './ssh-pool.js'
import { PersistentShellManager } from './persistent-shell.js'
import type { JobsRegistryLike } from './jobs.js'
import { makeTools, statusText } from './tools.js'
import type { HostTableLike, PoolLike, ToolsDeps } from './tools.js'

export const name = 'dsh-rw'

// webServer is INJECTED so apply() runs only after the web server is up and
// the /api/dsh-rw/* routes actually register.
export const inject = ['tools', 'systemPrompt', 'webServer']

/** Host key verification policy for outbound SSH connections. */
export type HostKeyPolicy = 'accept-new' | 'strict' | 'off'

export const Config = z.object({
  /** Host key policy: verify against ~/.ssh/known_hosts (accept-new learns on first connect). */
  hostKeyPolicy: z.string().default('accept-new'),
  /** known_hosts file path (default ~/.ssh/known_hosts). */
  knownHostsPath: z.string().default(''),
  /**
   * Which `~/.ssh/config` aliases become hosts. Empty = every alias (the
   * historical behaviour); shell-style globs, matched case-insensitively.
   * Use this to stop a machine full of build/test entries from flooding the
   * host list — `exclude` always wins over `include`.
   */
  sshConfigInclude: z.array(z.string()).default([]),
  sshConfigExclude: z.array(z.string()).default([]),
  /** Per remote command timeout. */
  commandTimeoutMs: z.number().step(1).min(1000).default(30000),
  /** SSH connection establishment timeout. */
  connectTimeoutMs: z.number().step(1).min(1000).default(15000),
  /** Channel/subsystem open timeout: bounds the wait on a silently dead connection before it is dropped and retried. */
  channelOpenTimeoutMs: z.number().step(1).min(1000).default(10000),
  /** Hard ceiling on collected remote output per call. */
  maxOutputChars: z.number().step(1).min(1024).default(200000),
  /** Shim mode: intercept DSH's native tools and translate them to remote execution. Default true: the agent uses native tools against the remote workspace out of the box. Set false in cordis config or in ~/.dsh/settings.yaml (`dsh-rw: shim: false`) to fall back to rw_*-only. */
  shim: z.boolean().default(true),
  /** With shim on, also intercept bash (session cwd must be the placeholder workspace). */
  shimBash: z.boolean().default(true),
  /** Shimmed bash approval: 'ask' escalates to the DSH approval dialog, 'native' defers to the native policy. */
  shimBashApproval: z.union(['ask', 'native']).default('ask'),
  /** Run the persistent-bash flavor on one long-lived remote shell per (host, workspace) instead of a fresh one-shot exec. Default true. */
  persistentShell: z.boolean().default(true),
  /** Close a persistent shell after this many ms without a command (default 10 minutes). */
  persistentShellIdleMs: z.number().step(1).min(0).default(600000),
  /** Run native background bash calls as REMOTE jobs registered with ctx.jobs (default true). Off → such a call is refused rather than run locally. */
  backgroundJobs: z.boolean().default(true),
  /** Poll cadence for a remote job's log (default 500 ms). */
  jobPollMs: z.number().step(1).min(50).default(500),
  /** Remote directory holding background-job logs (default /tmp). */
  jobDir: z.string().default('/tmp'),
})

export interface Config {
  hostKeyPolicy: HostKeyPolicy
  knownHostsPath: string
  sshConfigInclude?: readonly string[]
  sshConfigExclude?: readonly string[]
  commandTimeoutMs: number
  connectTimeoutMs: number
  channelOpenTimeoutMs: number
  maxOutputChars: number
  /** Optional so hand-built test configs still typecheck; apply() re-normalizes with the schema defaults. */
  shim?: boolean
  shimBash?: boolean
  shimBashApproval?: 'ask' | 'native'
  /** Optional so hand-built test configs still typecheck (schema default: true). */
  persistentShell?: boolean
  persistentShellIdleMs?: number
  backgroundJobs?: boolean
  jobPollMs?: number
  jobDir?: string
}

/**
 * Settings-layer schema for the DSH 0.1.2 namespace API only: it declares which
 * of `Config`'s keys the `dsh-rw` namespace may carry, resolved as schema
 * defaults → the cordis entry config (register `base`) → the user's `dsh-rw:`
 * section in ~/.dsh/settings.yaml. DSH 0.1.7+ derives namespaces from the
 * plugin's own `Config` schema instead and never calls this — see the settings
 * inject below.
 */
const ShimSettingsSchema = z.object({
  shim: z.boolean().default(true),
  shimBash: z.boolean().default(true),
  shimBashApproval: z.union(['ask', 'native']).default('ask'),
})

/** The resolved shim switches, as carried by the settings layer. */
interface ShimSwitches {
  shim: boolean
  shimBash: boolean
  shimBashApproval: 'ask' | 'native'
}

/**
 * The DSH 0.1.2 settings-namespace API, declared structurally on purpose: DSH
 * 0.1.7+ (and 0.2) dropped `register` from the `settings` service, so this has
 * to compile against a runtime whose service does not have the method at all.
 */
interface LegacySettingsRegistrar {
  register(
    ns: string,
    schema: unknown,
    options: { base: ShimSwitches },
  ): {
    get(): ShimSwitches
    watch(onChange: (next: ShimSwitches) => void): () => void
  }
}

/**
 * Test seams for apply(): the DSH loader calls apply(ctx, config); tests pass
 * in-memory fakes plus tmp paths so nothing touches the real ~/.ssh or ~/.dsh.
 */
export interface ApplyOverrides {
  hosts?: HostTableLike
  pool?: PoolLike
  session?: Session
  placeholderBaseDir?: string
  pickDirectory?: () => Promise<string | null>
}

/** Minimal shape of the optional DSH commands service (slash commands). */
interface CommandsLike {
  register(command: { name: string; description: string; handler: () => { kind: string; text: string } }):
    | (() => void)
    | void
}

/** Minimal shape of the optional DSH directoryPicker service. */
interface DirectoryPickerLike {
  capability?: () =>
    | Promise<{ kind?: string; pick?: (signal?: AbortSignal) => Promise<unknown> } | null | undefined>
    | { kind?: string; pick?: (signal?: AbortSignal) => Promise<unknown> }
    | null
    | undefined
}

/**
 * Adapt the ctx directoryPicker service (as used by dsh-remote's local-pick
 * endpoint) into a plain pick function. The service is resolved per call:
 * the web app's directory-picker row mounts its backend asynchronously during
 * boot (a nested loader.create), so a snapshot taken when this plugin applies
 * can miss a service that registers moments later. The returned function
 * throws a friendly Error when the service is absent or the backend is not
 * the native picker, and resolves null on cancel.
 */
function adaptDirectoryPicker(ctx: Context): () => Promise<string | null> {
  // Use ctx.get('directoryPicker') only: property access ctx.directoryPicker
  // throws when the service is absent and 'directoryPicker' is not in inject.
  // The service is optional (provided by @deepseek-ai/dsh-host-directory-picker-*);
  // when absent the pick function degrades to a friendly Error.
  return async () => {
    const dp = ctx.get('directoryPicker') as
      | DirectoryPickerLike
      | null
      | undefined
    if (!dp || typeof dp.capability !== 'function') {
      throw new Error(
        'local directory picker service is unavailable (no DSH directory-picker backend) — use the in-app local browser',
      )
    }
    const cap = await dp.capability()
    if (!cap || cap.kind !== 'native' || typeof cap.pick !== 'function') {
      throw new Error('local directory picker needs the native backend (this DSH composes a different one) — use the in-app local browser')
    }
    const pickAbort = new AbortController()
    try {
      const picked = await cap.pick(pickAbort.signal)
      return typeof picked === 'string' && picked !== '' ? picked : null
    } finally {
      pickAbort.abort()
    }
  }
}

export function apply(ctx: Context, config: Config, overrides: ApplyOverrides = {}): void {
  const hosts =
    overrides.hosts ??
    new HostTable({
      sshConfigInclude: config.sshConfigInclude ?? [],
      sshConfigExclude: config.sshConfigExclude ?? [],
    })
  const pool =
    overrides.pool ??
    new SshPool({
      hostKeyPolicy: config.hostKeyPolicy,
      knownHosts: new KnownHosts(config.knownHostsPath || KnownHosts.defaultPath()),
      connectTimeoutMs: config.connectTimeoutMs,
      channelOpenTimeoutMs: config.channelOpenTimeoutMs,
      commandTimeoutMs: config.commandTimeoutMs,
      maxOutputChars: config.maxOutputChars,
    })
  const session = overrides.session ?? new Session()
  // Shared observation of where native tools actually go; the shim writes it on
  // every dispatch, the prompt section and rw_info read it. Never inferred from
  // the session record alone — see promptText.
  const nativeRouting = createNativeRouting()
  // One long-lived remote shell per (host, workspace) backs the persistent-bash
  // flavor; ids are the pool's own so channel opens behave like every other op.
  const shells = new PersistentShellManager({
    open: (entry) => {
      if (pool.openShell === undefined) throw new Error('this pool cannot open a persistent shell')
      return pool.openShell(entry)
    },
    idleMs: config.persistentShellIdleMs ?? 600000,
  })

  const deps: ToolsDeps = {
    hosts,
    pool,
    session,
    config: {
      commandTimeoutMs: config.commandTimeoutMs,
      maxOutputChars: config.maxOutputChars,
      hostKeyPolicy: config.hostKeyPolicy,
    },
    routing: nativeRouting,
    shimEnabled: () => shimSettings.shim,
    ...(overrides.placeholderBaseDir !== undefined ? { placeholderBaseDir: overrides.placeholderBaseDir } : {}),
  }

  const tools = makeTools(deps)
  const routes = makeRoutes({ ...deps, pickDirectory: overrides.pickDirectory ?? adaptDirectoryPicker(ctx) })

  // The shim switches are mutable on purpose: the middlewares read them per
  // dispatch, so a settings-layer commit (or its absence) applies immediately
  // without re-registering anything. Initial values are the cordis entry
  // config — the base layer the settings overlay may later replace.
  const shimSettings: ShimConfig = {
    shim: config.shim ?? true,
    shimBash: config.shimBash ?? true,
    shimBashApproval: config.shimBashApproval ?? 'ask',
    commandTimeoutMs: config.commandTimeoutMs,
    maxOutputChars: config.maxOutputChars,
    persistentShell: config.persistentShell ?? true,
    backgroundJobs: config.backgroundJobs ?? true,
  }
  // The host job registry is optional (no jobs plugin → no background jobs).
  // Its absence is reported per call; it never falls back to running locally.
  const jobs = ctx.get('jobs') as JobsRegistryLike | undefined
  const logShimConfig = (source: string): void => {
    console.log(
      `[dsh-rw] shim config resolved (${source}): shim=${String(shimSettings.shim)} ` +
        `shimBash=${String(shimSettings.shimBash)} shimBashApproval=${shimSettings.shimBashApproval}`,
    )
  }

  // The prompt cannot read the agent's cwd (AssembleContext carries only a
  // scope), so it states the precedence instead of guessing: rw_* resolve from
  // the working directory first and fall back to the record.
  const workspacePrecedence =
    'Target selection: rw_* address the workspace this session is ACTUALLY working in (derived from the ' +
    'working directory when it is inside a dsh-rw placeholder); the plugin session record above is only a ' +
    'fallback — rw_info reports which one is in effect.'

  const promptText = (): string => {
    const alias = session.alias
    const workspace = session.workspace
    if (alias === null || workspace === null) {
      return [
        '## Remote workspace (dsh-rw)',
        'No remote workspace is active. When the task involves an SSH host, start with rw_hosts (list configured ' +
          'hosts), rw_connect(alias), then rw_pick_workspace(path) to choose the remote directory. Afterwards all ' +
          'rw_* file tools operate inside that remote workspace.',
      ].join('\n')
    }
    const entry = hosts.find(alias)
    const who = entry ? `${entry.user}@${entry.host}:${entry.port}` : alias
    if (shimSettings.shim) {
      const native = shimSettings.shimBash
        ? 'read/write/edit/str_replace_editor/glob/grep/bash'
        : 'read/write/edit/str_replace_editor/glob/grep'
      const rwTools =
        'The rw_* tools (rw_list_dir / rw_read_file / rw_write_file / rw_mkdir / rw_move / rw_delete / rw_exec) ' +
        'always address the remote host and are confined to the workspace root.'
      const placeholder =
        nativeRouting.placeholder ??
        resolvePlaceholderDir(alias, workspace, overrides.placeholderBaseDir) ??
        '(placeholder directory not found)'
      if (nativeRouting.mode === 'local') {
        // The last native call was rooted outside every placeholder and the
        // session cwd is a real local directory, so it went to the local
        // machine. Saying it reached the remote is how a session ends up
        // editing local files while believing it is working on the remote.
        return [
          '## Remote workspace (dsh-rw)',
          `Current remote workspace: ${who}:${workspace}`,
          workspacePrecedence,
          `WARNING — the native tools were running on the LOCAL machine for the last call: it named paths outside ` +
            `the dsh-rw placeholder (${placeholder}) and this session's working directory ` +
            `(${nativeRouting.cwd ?? 'unknown'}) is not inside that placeholder either. Native file calls that DO ` +
            `name a path inside ${placeholder} are translated to the remote from any working directory; bash and ` +
            'pathless glob/grep need the session cwd to be the placeholder. ' +
            rwTools,
        ].join('\n')
      }
      if (nativeRouting.mode === 'remote') {
        // Observed: native calls are being translated. Steer the model to them —
        // pushing rw_* here would keep the shim dormant. The anchor decides how
        // much of the session is remote-backed, so state it.
        const how =
          nativeRouting.reason === 'path'
            ? `an explicit path inside ${placeholder} is translated from any working directory (bash and pathless ` +
              'glob/grep still need the session cwd to be the placeholder)'
            : `this session's working directory is inside ${placeholder}`
        return [
          '## Remote workspace (dsh-rw)',
          `Current remote workspace: ${who}:${workspace}`,
          workspacePrecedence,
          `This session's workspace is remote-backed: the native ${native} tools are translated to the remote ` +
            `host automatically — ${how}. Use them exactly as if the workspace were local. ` +
            `${rwTools} The remote filesystem is the source of truth (no local mirror).`,
        ].join('\n')
      }
      // Nothing observed yet (the plugin loaded after the last dispatch, or no
      // tool has run in this session): state the rule instead of claiming an
      // outcome, and point at the one call that reports it.
      return [
        '## Remote workspace (dsh-rw)',
        `Current remote workspace: ${who}:${workspace}`,
          workspacePrecedence,
        `The native ${native} tools have two translation anchors: (1) a call whose path argument is inside the ` +
          `dsh-rw placeholder directory (${placeholder}) is translated to the remote host from ANY working ` +
          `directory; (2) bash — and glob/grep without an explicit path — is translated only while this ` +
          "session's working directory is inside that placeholder, because it has no path to anchor on. Calls " +
          'rooted outside both run on the local machine. No native tool call has been observed since the plugin ' +
          'loaded, so which anchor is in effect is not known yet — call rw_info to see where the native tools ' +
          'actually go. ' +
          rwTools,
      ].join('\n')
    }
    return [
      '## Remote workspace (dsh-rw)',
      `Current remote workspace: ${who}:${workspace}`,
          workspacePrecedence,
      'Use the rw_* tools (rw_list_dir / rw_read_file / rw_write_file / rw_mkdir / rw_move / rw_delete / rw_exec) ' +
        'to inspect and modify the remote host directly; the remote filesystem is the source of truth (no local ' +
        'mirror). All rw_* file paths are confined to the workspace root.',
    ].join('\n')
  }

  // Tools + routes + slash command under one effect so teardown unregisters
  // every surface in one pass.
  ctx.effect(() => {
    const disposers: (() => void)[] = []
    for (const tool of tools) disposers.push(ctx.tools.register(tool as ToolDefinition))
    for (const route of routes) disposers.push(ctx.webServer.register(route))
    const commands = ctx.get('commands') as CommandsLike | undefined
    if (commands !== undefined && typeof commands.register === 'function') {
      const dispose = commands.register({
        name: 'rw',
        description: 'Show the dsh-rw remote workspace status (hosts, connection, workspace).',
        handler: () => ({ kind: 'success', text: statusText(deps) }),
      })
      if (typeof dispose === 'function') disposers.push(dispose)
    }
    // Shim middlewares: registered unconditionally — with shim=false they are
    // a pure pass-through (first line is next()), which keeps the settings
    // hot-reload path registration-free. They live in this same effect so
    // plugin teardown unregisters them together with the tools.
    const shim = makeShim({
      hosts,
      pool,
      session,
      config: shimSettings,
      routing: nativeRouting,
      shells,
      ...(jobs !== undefined ? { jobs } : {}),
      jobPollMs: config.jobPollMs,
      jobDir: config.jobDir,
      ...(overrides.placeholderBaseDir !== undefined ? { placeholderBaseDir: overrides.placeholderBaseDir } : {}),
      getTool: (toolName, agent) => ctx.tools.get(toolName, agent as Parameters<Context['tools']['get']>[1]),
      // Never-ask detection for the pre-execute gate; absent/legacy approval
      // service → undefined → plain 'ask' behavior.
      approvalPolicyOf: (agentSession) => {
        const approval = ctx.get('approval') as { effectivePolicy?: (session: unknown) => string } | undefined
        if (approval === undefined || typeof approval.effectivePolicy !== 'function') return undefined
        try {
          return approval.effectivePolicy(agentSession)
        } catch {
          return undefined
        }
      },
    })
    disposers.push(ctx.on('tools/execute', shim.onExecute))
    disposers.push(ctx.on('tools/pre-execute', shim.onPreExecute))
    // Startup log is unconditional so a mis-delivered config shows up as shim=false here.
    logShimConfig('cordis base')
    return () => {
      for (const dispose of disposers) dispose()
    }
  }, 'dsh-rw: surfaces')

  // Settings layer, and the only place the two DSH settings models diverge.
  //
  // DSH 0.1.2: a per-plugin settings NAMESPACE. `settings.register(ns, schema,
  // { base })` returns a scope resolved as schema defaults → the cordis entry
  // config → the user's `dsh-rw:` section in ~/.dsh/settings.yaml, with a
  // watcher that hot-reloads a commit into the live switches.
  //
  // DSH 0.1.7+ / 0.2: that API is gone. Namespaces are DERIVED from the
  // plugin's own `Config` schema (below) and edited through the profile
  // composition, which is the cordis entry config this apply() already
  // received — so there is no second layer to overlay and nothing to watch.
  //
  // Both lines still mount a `settings` service, so the inject callback fires
  // either way: the model is selected by the method, never by a version check.
  // With no settings service, or with one that dropped `register`, the cordis
  // entry config logged above stays in charge.
  ctx.inject(['settings'], (sctx) => {
    const settings = sctx.settings as unknown as Partial<LegacySettingsRegistrar>
    const register = settings.register
    if (typeof register !== 'function') {
      logShimConfig('cordis base — no settings namespace API on this DSH')
      return undefined
    }
    try {
      const scope = register.call(settings, 'dsh-rw', ShimSettingsSchema, {
        base: {
          shim: config.shim ?? true,
          shimBash: config.shimBash ?? true,
          shimBashApproval: config.shimBashApproval ?? 'ask',
        },
      })
      const overlay = (value: ShimSwitches, source: string): void => {
        shimSettings.shim = value.shim
        shimSettings.shimBash = value.shimBash
        shimSettings.shimBashApproval = value.shimBashApproval
        logShimConfig(source)
      }
      overlay(scope.get(), 'cordis base + settings overlay')
      // The returned disposer rides the inject sub-fiber: unloading dsh-rw
      // disposes it, which also drops the namespace registration itself.
      return scope.watch((next) => overlay(next, 'settings overlay update'))
    } catch (err) {
      console.warn(
        `[dsh-rw] settings registration failed (${err instanceof Error ? err.message : String(err)}) — ` +
          'shim switches stay at the cordis entry config',
      )
      return undefined
    }
  })

  // Prompt section: registered through effect so the section disappears with
  // the plugin fiber (section() returns its exact disposer).
  ctx.effect(
    () =>
      ctx.systemPrompt.section({
        name: 'dsh-rw',
        order: 88,
        text: promptText,
      }),
    'dsh-rw: prompt',
  )

  ctx.effect(
    () => () => {
      shells.dispose()
      pool.dispose()
    },
    'dsh-rw: pool',
  )
}
