# Changelog

All notable changes to **dsh-rw**. Format follows [Keep a Changelog](https://keepachangelog.com/),
versioning follows [SemVer](https://semver.org/).

## 1.6.1 — 2026-10-19

### Fixed — a refused channel left later operations stuck on a dead connection

`SshPool.exec` / `sftp` retried a channel-open failure **only when the
connection had already dropped out of the pool**. That mis-modelled the shape
seen against proxy SSH frontends: the frontend keeps the TCP connection
perfectly healthy while its backend expires, so every later channel open is
refused with

```
(SSH) Channel open failure: ssh: rejected: connect failed (open failed)
```

and the pool kept reusing that connection until the process restarted — while
the very same host answered instantly from a fresh process and from plain
`ssh`. A refused channel cannot have side effects, so it is now treated as
"this connection is unusable": drop it and redial once, exactly like an open
timeout. A systemic refusal still surfaces, just one dial later.

Verified on the real host: the alias answered
`(SSH) Channel open failure ... (open failed)` before, `rw_disconnect` (drop the
pooled client) made it answer in 1.6 s / 0.6 s again, and a fresh pool never
reproduced the failure. Tests updated: the retry contract is now asserted
directly (refused channel → exactly two dials, then success).

## 1.6.0 — 2026-10-19

### Added — remove a host from the list without touching `~/.ssh/config`

Hosts imported from `~/.ssh/config` can now be dropped from the list with the
per-row **✕**. The plugin remembers the alias in its own store
(`~/.dsh/dsh-rw.json` → `hidden`); `~/.ssh/config` is **never edited**, so the
entry keeps working for plain `ssh`.

- a muted line under the list shows what is hidden, with **显示全部** to put it
  back (`POST /api/dsh-rw/hosts/hide` with `hidden: false`);
- `rw_info` reports `Hosts configured: N (M hidden: …)`;
- manual hosts keep the old ✕ (delete from the store); hiding one is rejected
  because that entry exists only here;
- the declarative `sshConfigInclude` / `sshConfigExclude` from 1.5.0 remain
  available — the button is the day-to-day path.

Tests: 519 (+4: hide persistence, manual-host rejection, route hide/unhide).

## 1.5.0 — 2026-10-19

### Added — `sshConfigInclude` / `sshConfigExclude`

Every alias in `~/.ssh/config` became a host, so a config full of build and
test entries produced a host list that was mostly noise. Two glob lists now
decide what is imported:

- `sshConfigExclude` — never import these aliases (an exclude match wins);
- `sshConfigInclude` — when non-empty, only these are imported.

Matching is shell-style (`*`, `?`) and case-insensitive, because an Alias is a
single path-free token and `ORIN` vs `orin` should not be a trap. Manual hosts
are never filtered. Both default to `[]`, so existing behaviour is unchanged
until you ask for it:

```yaml
sshConfigExclude: [ORIN, myhfool]
```

## 1.4.3 — 2026-10-19

### Docs — GitHub is the release channel; npm is prepared but unused

1.4.2 documented npm as the recommended install path before anything was
published there, so `dsh plugin add dsh-rw` would have failed to resolve. The
README leads with the GitHub source again and states plainly that the package is
*prepared* for npm (`prepublishOnly`, `publishConfig` remain in place) but not
published; CONTRIBUTING marks `npm publish` as the optional step it is.

No runtime change and no packaging change: the artifact is the same code as
1.4.2.

## 1.4.2 — 2026-10-19

### Packaging — npm is now the primary distribution channel

Installing from a `github:` spec is version-blind: the plugin catalogue can only
echo the dependency spec back (`github:MDR-EX1000/dsh-rw`), cannot compare an
installed version against a published one, and every install follows a moving
default branch. The package is now prepared for npm:

- `prepublishOnly` runs `typecheck`, `test`, and `build`, so a published tarball
  is always the tested one and never a stale `lib/` snapshot;
- `publishConfig.registry` pins `https://registry.npmjs.org/`, so a machine-level
  mirror setting (npmmirror) cannot misroute a release;
- the tarball carries only `lib/`, `cordis.patch.yml`, `README`, and `LICENSE`
  (verified with `npm pack --dry-run`), and needs no build step at install time.

No runtime change: the code is identical to 1.4.1.

## 1.4.1 — 2026-10-19

### Added — `rw_info` reports the version of the code that is LOADED

The plugin page shows the version read from `node_modules/dsh-rw/package.json`
**on disk**, while the host keeps running the module it loaded at boot. The two
can disagree for as long as the app stays open (this session shipped four
releases without a restart), and they disagree in the other direction while the
package directory is being reinstalled — during which the bundle row has no
manifest to read and therefore no version to show.

`rw_info` (and the `/rw` command) now ends with
`Plugin version: <x.y.z> (the code currently loaded by the host)`, resolved from
the plugin's own module location — so "which version is actually running?" is
answerable from inside the session, and a blank version in the UI is
distinguishable from a stale process.

## 1.4.0 — 2026-10-19

### Changed — rw_* target the workspace the session is ACTUALLY in

`rw_*` resolved its host and workspace from the plugin's session record
(`alias` + `workspace`). That record can be stale, can name a different machine
after a reconnect, or can be a leftover from a previous pick — while the agent
is working in a completely different placeholder. The shim had already moved to
"anchor on the actual working directory, never on the record"; `rw_*` had not,
so the two tool families could disagree about which machine was in play.

Resolution is now `activeWorkspace(deps, exec)`, in this order:

1. the agent's working directory, when it sits inside a dsh-rw placeholder —
   that placeholder's host and remote root are the truth (`source: 'cwd'`);
2. otherwise the plugin session record (`source: 'session'`);
3. a working directory whose placeholder host is no longer configured is a
   hard `NOT_CONNECTED` — it never silently falls back to the record.

`rw_info` reports which of the two is in effect ("from this session's working
directory" / "from the plugin session record"), and the prompt section states
the precedence (it cannot read the cwd itself — `AssembleContext` carries only
a scope).

`rw_exec` still works when a host is connected but no workspace is picked (the
SSH default directory); every file tool keeps saying `NO_WORKSPACE`.

## 1.3.0 — 2026-10-19

### Fixed — a background bash call inside a remote workspace ran on the LOCAL machine

`bash` with `run_in_background: true` was passed through to the native tool so
the command ran on the **local** machine while every other signal in the
session said the workspace was remote — the last place dsh-rw silently lied
about where work happens (and a direct contradiction of "never silently
local"). A remote background call is now started **on the host**:

- the command runs detached (`setsid` + log redirect) so closing the SSH
  channel cannot kill it, and the log gets an exit marker carrying `$?`;
- the job is registered with the host job registry (`ctx.jobs`), so the model
  collects and stops it with the **same** `job_output` / `job_kill` tools it
  uses for a local job — no second tool family;
- output is narrated incrementally (only new bytes are appended, the marker
  never leaks), terminal status comes from the exit marker, and `job_kill`
  signals the remote pid;
- a host without `setsid` fails loudly with the launch error instead of
  pretending;
- with no job registry composed (or `backgroundJobs: false`) the call is
  **refused** with an explicit message rather than run locally;
- the pre-execute approval gate now applies to background calls too, since
  they run on the host.

New config: `backgroundJobs` (default true), `jobPollMs` (500), `jobDir`
(`/tmp`). New module `src/jobs.ts`; 7 unit tests plus 2 shim-wiring tests.

## 1.2.0 — 2026-10-19

### Changed — the SSH host picker is a host list, not a dropdown

The 远程 page listed hosts in a native `<select>` that showed only the alias.
Everything the host table already knew — `user@host:port`, whether the entry
came from `~/.ssh/config` or was added by hand, whether its credential is
ready — was invisible, and an unusable host was silently greyed out with no
reason. The list is now one row per host:

- provenance and credential pills, plus a red inline reason (private key
  missing / password not set) instead of a silent grey-out;
- a status dot that turns green or red once the row has been probed;
- a per-row **test** action wired to the existing `POST /api/dsh-rw/test`,
  showing the measured latency or the failure;
- **edit** and **remove** actions for manual hosts (ssh-config entries stay
  read-only here — their source of truth is `~/.ssh/config`).

### Added — editing a manual host

`PATCH /api/dsh-rw/hosts` replaces one manual host's connection details in
place. The alias is the record key and cannot change (rename = remove + add),
and ssh-config hosts are refused. An edit that only moves the address **keeps
the stored credential**: `password` and `keyPath` are both optional on edit,
and the summary now exposes `keyPath` (a path, never a secret) so the form can
prefill it. The pooled connection is dropped after an edit so the next
operation redials with the new details.

### Added — the picker remembers the last host

The host last selected (or whose workspace was committed) is restored on the
next open: live session host first, then the remembered one, then the first
usable host. Same idea as the remembered local directory from 1.1.0.

## 1.1.1 — 2026-10-19

### Fixed — flaky host-key tests made CI red on the v1.1.0 tag

`tests/ssh-pool.test.ts` built its host keys with
`utils.generateKeyPairSync('ed25519')`. That helper intermittently (≈0.3% of
calls, measured: 13 of 4000) returns a **50-byte** public-key blob instead of
the valid 51-byte wire form, which ssh2's own `parseKey` then rejects with
"Unsupported key format" — so `verifyHostKey` correctly failed closed with
`HOSTKEY_VERIFY_FAILED` and the test asserting `HOSTKEY_UNKNOWN` /
`HOSTKEY_CHANGED` failed. The v1.1.0 tag's CI run hit it while the same commit
on `main` passed.

The keys are now **fixed ed25519 fixtures** (two distinct blobs), so the tests
are deterministic. Verified with 20 consecutive runs of the file: 0 failures.

No product-code change: rejecting an unparseable host key is the intended
fail-closed behaviour, and real hosts present well-formed keys.

## 1.1.0 — 2026-10-19

### Added — in-app local directory browser

- The 本机 page no longer depends on the OS chooser. It browses local
  directories in place — one level at a time, `..` to go up, type-to-filter —
  the same interaction the 远程 page already had, backed by a new loopback-only
  `GET /api/dsh-rw/ls-local` route (directories only, capped at 500 with an
  explicit truncation flag, `~` expanded against the host home, structured
  `NO_SUCH_PATH` / `NOT_A_DIRECTORY` / `PERMISSION_DENIED` answers).
- The last local workspace directory is remembered (`localStorage`) and
  restored when the page opens, so the common case is one click instead of a
  fresh Finder dialog. The OS chooser stays available as a secondary button and
  its result is remembered too.

### Fixed — a Finder dialog on every visit

The native picker seam is `pick(signal)` with no start directory, so every
visit began wherever the OS chooser last defaulted. The in-app browser removes
that dependency entirely; the system-picker failure messages now point at it
instead of telling the operator to type the path by hand.

## 1.0.0 — 2026-10-19

The first release where remote work stops being a second-class citizen: native
tools reach the remote from any working directory, the persistent shell keeps
its state, and the primitives a code workflow needs (fan-out, change watching,
diff/patch, optimistic write) exist.

### Added — path-anchored translation

- A native file call that names a path inside a dsh-rw placeholder is now
  translated to the remote **from any working directory**, not only when the
  agent session's cwd lives in that placeholder. The anchor travels with the
  call (`resolveCall` in `src/shim.ts`), so it can never be confused with
  ambient session state; `bash` — which has no path to anchor on — stays
  cwd-gated, and pathless `glob`/`grep` fall back to the cwd rule.
- The observation record, the prompt section and `rw_info` report *which*
  anchor translated the last call (`remote (by path)` vs `remote`), and the
  pass-through warning states that placeholder paths still translate.

### Added — `rw_exec_many`

- Fan a command out across hosts in one call with bounded concurrency (default
  4, ceiling 16), one section per call **in input order**. Give either `calls`
  (independent command per host, with `alias`/`cwd`/`timeoutMs`) or `command` +
  `hosts`.
- One unreachable host never voids the rest: its section reports
  `(not reached)` plus the error, while siblings complete normally. Every alias
  is resolved *before* anything runs, so a typo cannot half-apply a fan-out.
- `cwd` follows `rw_exec`'s rule: the current host's workspace when the call
  targets the current alias, otherwise the SSH default directory.

### Added — persistent shell

- The persistent-bash flavor now runs on one long-lived remote `bash` per
  (host, workspace), so `cd` and `export` survive between calls instead of
  degrading to a fresh one-shot exec. Commands are framed with a per-call
  random sentinel carrying the exit code (`src/persistent-shell.ts`).
- Streams are merged (`2>&1`) on purpose — a shell has ONE ordered stream, and
  losing that ordering would be worse than losing the stdout/stderr split; the
  rendered result says so. A stuck command kills the shell (state reset) rather
  than leaving unread output on the stream, and an idle shell closes after
  `persistentShellIdleMs`.
- `persistentShell: false` restores the pre-1.0 behavior (and its note).

### Added — `rw_watch`

- Poll-based remote change tracking: `start` (optional relative `path`, one
  `include` glob, `maxEntries`), `poll` (added / changed by size-or-mtime /
  removed since the previous snapshot), `stop`, `list`. Nothing runs on the
  remote between polls: the snapshot lives in the plugin process, so one poll
  costs one recursive SFTP listing.

### Added — `rw_diff`, `rw_apply_patch`, optimistic write

- `rw_diff` compares one remote file against supplied text or another remote
  file and renders a unified diff; it reads **raw bytes**, so a trailing
  newline is never reported as a phantom change, and binary files are rejected
  instead of diffed as mojibake.
- `rw_apply_patch` validates every path the patch would touch against the
  workspace root **before anything runs** (`patchTargets`), stages the patch on
  the host, and runs `patch -pN --dry-run` first, so a mismatch changes nothing.
  The staged file is always removed.
- `rw_write_file` gains `ifHash`: write only when the remote content hashes to
  the given sha256, or pass `"absent"` to only create. A mismatch fails with
  `RW_WRITE_CONFLICT` and reports the current hash.

### Changed

- **Shim semantics**: native file calls are now translated by their own path
  argument as well as by the session cwd. This is a behavior change — a session
  started in a local directory will translate calls that name a placeholder
  path (previously they ran locally). The "never silently local" guarantee is
  preserved: every pass-through is still observed, reported and warned once.
- **Remote search now mirrors the native tools**: `glob` runs with
  `--sort=modified --no-ignore --hidden` plus the VCS excludes, `grep` uses
  `rg --json` (the native transport, so a path containing colons cannot be
  mis-split), and both put `--` before the search root. When ripgrep is missing
  on the host, the `find`/`grep -rnE` fallback is labelled in the result rather
  than silently returning different ignore/hidden semantics.
- Tool count 12 → 16: `rw_exec_many`, `rw_watch`, `rw_diff`, `rw_apply_patch`
  are inserted between `rw_exec` and `rw_disconnect` (fixed registration order).
- DSH peer ranges extend to `^0.2.1-rc.1` (keeping `^0.1.2-rc.1` and
  `^0.2.0-rc.2`), and the development dependencies move to `0.2.1-rc.1`.

### Fixed

- Reading a file for diffing no longer loses its trailing newline (the line
  reader used before this release rejoins lines without the terminator).

## 0.4.6 — 2026-10-08

- Stop claiming native translation that is not happening. The prompt section used to say "this session's
  workspace is remote-backed: the native read/write/... tools are translated to the remote host
  automatically" whenever a remote workspace was recorded and shim was on — but the shim only translates
  while the agent session's working directory lives inside that workspace's placeholder
  (`src/shim.ts` `activeTarget`). With any other working directory the native tools ran on the LOCAL
  machine while the prompt said remote, and the pass-through produced no log at all. The one combination
  that could write to the wrong filesystem silently is now impossible to hit unaware:
  - the shim records where each dispatch actually went, and the prompt section, `rw_info` and `/rw` report
    that observation instead of inferring from the session record;
  - the prompt states the rule (placeholder containment) until a dispatch settles it, then reports the
    observed side: "translated to the remote host automatically" only after a translated call, and an
    explicit `WARNING — the native … tools are running on the LOCAL machine` naming the working directory
    and the expected placeholder after a pass-through;
  - `rw_info` gains a `Native tools:` line (`remote` / `LOCAL` / `not observed yet` / `shim off`), so the
    model can check where its own file tools go before using them;
  - a pass-through caused by a local working directory logs one `console.warn` naming the cwd, the
    workspace and the placeholder (once per distinct cwd — never per call). A runtime with no working
    directory to compare (`cwd` unset) keeps the previous observation rather than guessing.

## 0.4.5 — 2026-10-08

- Support DSH `0.2.0-rc.2` while keeping `0.1.2-rc.1`: the DSH peer ranges are now
  `^0.1.2-rc.1 || ^0.2.0-rc.2`, and the development ranges moved to the versions shipped with
  `0.2.0-rc.2`. Before this, DSH's loader refused the plugin outright — `Plugin dsh-rw@0.4.4 is
  incompatible with dsh 0.2.0-rc.2: peerDependencies {...}` — and rolled the installation back, so
  the plugin could not be installed on, or loaded by, a 0.2 runtime at all.
- Port the settings layer to DSH's `Config`-derived model. DSH 0.1.7+ (and 0.2) removed the
  per-plugin namespace API (`SettingsService.register`); plugin settings are now derived from the
  plugin's own `Config` schema and edited through the profile composition. The three shim switches
  therefore come from the `dsh-rw` entry config on those runtimes — set `shim: false` there, or use
  the plugin's row in the configuration form — instead of a `dsh-rw:` section in
  `~/.dsh/settings.yaml`. The 0.1.2 namespace path is kept, and the model is selected by the
  presence of `register` rather than a version check, so one build serves both lines.
- Log the resolved shim source on the `Config`-derived path too, so a runtime without the namespace
  API reports `shim config resolved (cordis base — no settings namespace API on this DSH)` instead
  of saying nothing about which layer won.

## 0.4.4 — 2026-09-15

- Resolve the `directoryPicker` service at local-pick time instead of caching it
  once when the plugin applies. The web app's `directory-picker` row mounts its
  backend asynchronously during boot, so the apply-time snapshot raced that
  mount and could permanently pin a missing backend — `/api/dsh-rw/local-pick`
  answered 400 until the plugin was reloaded. A missing service is now reported
  at call time with the same friendly message.
- Make `github:MDR-EX1000/dsh-rw` the documented default installation target so
  DSH Market keeps a compact GitHub basename source across future updates.

## 0.4.3 — 2026-09-07

- Add complete Chinese and English dictionaries for the workspace picker,
  including host management, validation, loading, confirmation, and fallback
  messages.
- Register the dictionaries through DSH's official client locale service and
  subscribe the picker to its revision snapshot. The picker now follows the
  global **Settings → Language** preference and switches live without a restart.
- Add `@deepseek-ai/dsh-client-locale` to the client composition and compatibility
  ranges for DSH `0.1.2-rc.1`.
- Simplify the picker entry cards to icon + short title (`LOCAL` / `REMOTE` in
  English), rebuild the add-host form as balanced two-column field groups, and
  shorten static hints so the interface stays on one line at the modal's normal
  width. Long dynamic errors use ellipsis while preserving their full tooltip.

## 0.4.2 — 2026-09-07

- Compatibility: support DSH `0.1.2-rc.1` by registering the `dsh-rw` settings
  namespace through the new literal-name API; the removed `settingsNamespace()`
  helper is no longer imported.
- Derive structured result values from the public `ToolExecutionResult` contract
  now that `dsh-tools` no longer re-exports its internal `JsonValue` type.
- Refresh DSH peer/development ranges to the versions shipped with DSH
  `0.1.2-rc.1`.

## 0.4.1 — 2026-08-24

Packaging fix for dsh-market and other package managers that block install-time build scripts.

- Remove the `prepack` lifecycle script from the published package.
- Build, test, and pack explicitly in the release workflow before uploading `dsh-rw.tgz`.
- Keep the compiled `lib/` output in the release tarball so GitHub/release installs work without
  a local TypeScript or esbuild toolchain.

## 0.4.0 — 2026-08-21

Shim mode is now on by default.

- **Breaking behavior change (opt-out, not opt-in):** the three shim switches now resolve with
  `shim: true` as the schema default — both the cordis entry config
  (`Config.shim: z.boolean().default(true)`) and the `dsh-rw:` settings layer
  (`ShimSettingsSchema.shim: z.boolean().default(true)`), with the `config.shim ?? true`
  fallbacks in `apply()` matching. Net effect for new installs: native `read` / `write` /
  `edit` / `str_replace_editor` / `glob` / `grep` / `bash` are translated to the remote host
  automatically once an `rw_*` workspace is active — no `~/.dsh/settings.yaml` entry needed.
- **Opt-out paths (unchanged surface):** set `shim: false` either in the cordis entry
  config or in `~/.dsh/settings.yaml` under `dsh-rw:` to fall back to the explicit
  `rw_*` tool path; the three keys (`shim` / `shimBash` / `shimBashApproval`) still resolve
  through the same schema-defaults → cordis → user layer pipeline, and hot-reload still
  applies settings-layer updates without re-registering.
- **README + prompt section:** the feature list bullet now reads "Shim mode (on by default)";
  the config table documents `shim` default `true`. The system prompt already steered models
  to native tools while shim was on, so existing `shim: true` users see no behavioral change.
- **Tests:** the schema-default test now exercises `shim=true` (the read intercepts and the
  pool acquires the placeholder's remote connection); the override and hot-reload tests pass
  an explicit `shim: false` base so the toggle remains visible; `tests/index.test.ts` adds a
  paired `shim: false` case asserting the prompt section steers to `rw_*`.

## 0.3.3 — 2026-08-21

- Fix: guard optional `directoryPicker` access against Cordis inject violation — the
  `ctx.get('directoryPicker') ?? ctx.directoryPicker` fallback in `adaptDirectoryPicker` used a
  direct property access, which Cordis reflect rejects with
  `cannot get property "directoryPicker" without inject` when the service is absent, aborting
  plugin load and taking the whole web profile down. Only `ctx.get('directoryPicker')` (safe,
  returns `undefined` when absent) is used now, matching the function's documented graceful
  degradation; `directoryPicker` is intentionally not added to `inject` since the service is
  optional and provided only by `dsh-host-directory-picker-*` when those are composed.

## 0.3.2 — 2026-08-21

Picker UX aligned to Codex's "New remote project", plus remote-home (`~`) support.

- Remote `~` support: `GET /api/dsh-rw/ls` and `rw_pick_workspace` / the workspace
  route now accept `~` and `~/…`, expanded server-side against the session home
  (SFTP `realpath('.')`) via the new `expandRemoteHome` guard helper.
- Picker (remote page) rework after Codex's dialog: workspace-name input with an
  attached icon cell on top; the host select shows alias-only options (unusable
  hosts still disabled) with a globe glyph and a drawn chevron (`appearance:
  none`); the path defaults to the remote home (`~/`, synced back to its real
  path); the inline directory list replaces both the autocomplete dropdown and
  the browse popup — rows drill in, an SVG up-button goes to the parent, and
  typing filters the list live. All glyph icons (folder / globe / arrows /
  close / file / link) are one line-SVG family, the primary action is a white
  Codex-style button, and the back button is a round icon-only button.
- Add-host subpage: label-left single-column rows (名称 / 主机 / 端口 / 用户 /
  认证方式 / …) with a 清空 / 测试连接 / 保存 footer; the back button took over
  取消's form-reset duty so secrets never linger in state.
- Fix (picker): the local page has its own path state — the remote page's `~/`
  expansion no longer leaks a remote home path into the local input.

## 0.3.1 — 2026-08-21

- Fix (shim): native tools are now anchored to the agent session cwd's placeholder, not the
  mutable rw_* session — after `rw_disconnect`, or when `rw_*` was reconnected to a different
  host, native read/write/edit/glob/grep/bash used to silently run on the local empty
  placeholder; they now target the remote the workspace actually points at (the pool redials
  lazily), and a placeholder whose host was removed from the config fails loudly with an
  actionable `NOT_CONNECTED` error instead of falling back silently. The block is path-aware:
  only calls that would touch the broken placeholder fail — calls rooted elsewhere still pass
  through to the local tool. Adds `scripts/live-shim.mjs` (live end-to-end shim acceptance).

## 0.3.0 — 2026-08-21

Picker UX rework, clean placeholder naming, and connection resilience.

- Resilience: an exec or SFTP call whose channel/subsystem open fails on a connection that has
  already dropped out of the pool (it died) now redials and retries the operation once
  transparently, instead of surfacing a transient error to the agent; SFTP ops on a wrapper
  whose connection dropped after acquisition re-acquire and retry once too. Remote business
  errors, command timeouts, and post-open stream failures are never retried, and a second
  failure surfaces the structured error as before.
- Resilience: channel/subsystem opens are now bounded by the new `channelOpenTimeoutMs`
  (default 10s). A silently dead connection (half-open TCP — network gone without a RST)
  previously hung an operation until keepalive detection (~45s) or indefinitely; it is now
  killed, dropped, and retried on a fresh connection within the timeout. Post-ready `error`
  events also drop the pooled client immediately (not only on `close`), so the retry
  discriminator no longer depends on `error`/`close` arrival order.
- Picker UX rework (Codex-style): the modal opens on a two-card chooser (本机 / 远程, each with
  a one-line explainer) instead of tabs; each flow is its own page with a 「← 返回」 back to the
  cards, and 「+ 添加主机」 is now a dedicated subpage rather than an inline expanding form.
- Placeholder naming: clean names by default — the remote basename, or the optional
  「工作区名称」 from the picker — with the `-<sha1[:8]>` suffix added only when the candidate
  directory is already occupied by another workspace. Lookup switches from computed paths to
  scanning `.dsh-rw-meta.json` (`resolvePlaceholderDir`), so legacy hash-suffixed placeholders
  from 0.1/0.2 keep resolving unchanged. `POST /api/dsh-rw/workspace` accepts an optional
  `name`.
- CI: GitHub Actions workflow (typecheck → build → test) on every push/PR.
- Docs: install via prebuilt GitHub Release tarball; add ACCEPTANCE.md (unit / live-host / UI checks).
- Fix: replace pnpm `allowBuilds` placeholder strings with real booleans — placeholders broke
  `pnpm install --frozen-lockfile` on fresh environments (`ERR_PNPM_IGNORED_BUILDS`).

## 0.2.0 — 2026-08-20

Shim mode: DSH's native tools run against the remote workspace.

- Opt-in shim mode (`shim: true`): cordis middleware on the `tools/execute` waterfall intercepts
  the seven native tools — `read` / `write` / `edit` / `str_replace_editor` / `glob` / `grep` /
  `bash` — and translates them to remote execution (SFTP/exec) whenever the call's paths resolve
  inside the active placeholder workspace. Anything outside passes through to the local tool
  untouched, and with shim off (the default) behavior is identical to 0.1.
- Paths map both ways: argument paths map placeholder → remote (relative paths resolve against
  the placeholder root), and every path in results and composed error messages maps back to
  placeholder form, so the agent's worldview stays a local directory.
- Edits (`edit`, `str_replace_editor` str_replace/insert) re-stat before writing back and fail
  with `RW_EDIT_CONFLICT` when the remote file changed since the read.
- `glob`/`grep` run remote `rg` when available (`find` / `grep -rnE` fallback); output is capped
  by `maxOutputChars` like every remote call.
- `bash` rewrites placeholder paths in the command, runs with the remote workspace root as cwd,
  honors `exec.signal` (abort drops the connection, interrupting the remote process), and a
  persistent `bash` (dsh-tool-bash-persistent registers the same tool name) degrades to a
  one-shot remote exec with a note that shell state is not preserved.
- Shimmed bash escalates through `tools/pre-execute` with `{ kind: 'ask' }` naming the remote
  host alias (default `shimBashApproval: 'ask'`; `'native'` defers to the native policy) — but
  stands down when the session's approval policy is `never` (e.g. the `danger-full-access`
  preset): asking there auto-rejects without a dialog, so the command just runs, matching
  that preset's contract. File tools never escalate — the workspace guard confines them.
- Result `value` shapes conform to each native tool's output schema (the registry validates
  them): bash returns the structured foreground object; read/write/edit/glob/grep return
  their schema's objects. String values failed live with "value must match exactly one oneOf
  branch" / "value must be an object" — caught in dogfooding, covered by per-tool value-shape
  tests. `str_replace_editor`'s native schema is a plain string, unchanged.
- Prompt steering: with shim on, the system-prompt section points the agent at the native
  tools (translated transparently) instead of pushing `rw_*` — the 0.1 wording kept the shim
  dormant because models dutifully preferred `rw_*`.
- New config keys: `shim` (default `false`), `shimBash` (default `true`),
  `shimBashApproval` (`'ask'` | `'native'`, default `'ask'`).
- Settings integration: the three shim switches (and only they) also resolve from the
  `dsh-rw:` section of `~/.dsh/settings.yaml` via `@deepseek-ai/dsh-settings` — schema defaults →
  cordis entry config (base) → user layer. Changes committed through the settings service
  apply live (the middlewares are registered unconditionally and read a shared config object
  per dispatch); after editing the file by hand, restart `dsh web` to be sure it is picked
  up. Without a settings service (or with an invalid stored section) the cordis entry config
  stays authoritative. `schemastery` is now a runtime dependency.

## 0.1.0 — 2026-08-19

Initial release.

- Remote-SSH-style workspaces for DSH: pick an SSH host and a remote directory as a native
  DSH workspace; the agent operates the remote filesystem directly via `rw_*` tools
  (SFTP/exec over a persistent ssh2 pool). No mirror, no sync — the remote is the source of truth.
- Hosts auto-parsed from `~/.ssh/config` (re-read on change); manual entries (password auth)
  stored in `~/.dsh/dsh-rw.json` with atomic writes and `0600` permissions.
- Workspace confinement for every file path: `../`, absolute paths outside the root, and
  symlink escapes are rejected (`OUTSIDE_WORKSPACE` / `SYMLINK_ESCAPE`, verified via remote
  `realpath`).
- SSH host key verification against `~/.ssh/known_hosts` (`accept-new` default; `strict` and
  explicit `off` policies; host key changes refused with `HOSTKEY_CHANGED`).
- Structured error taxonomy: `CONN_REFUSED` / `CONN_TIMEOUT` / `AUTH_FAILED` / `NO_SUCH_PATH` /
  `PERMISSION_DENIED` / `HOSTKEY_*` and more.
- Two-tab Add-workspace picker modal: local tab (OS folder chooser or manual path), remote tab
  (host dropdown, `/`-prefilled path autocomplete, cascading directory browser, inline
  add-host form with test-connection).
- 12 agent tools: `rw_info` / `rw_hosts` / `rw_connect` / `rw_pick_workspace` / `rw_list_dir` /
  `rw_read_file` / `rw_write_file` / `rw_mkdir` / `rw_move` / `rw_delete` / `rw_exec` /
  `rw_disconnect`.
- Loopback-only `/api/dsh-rw/*` routes; secrets never appear in tool output, API responses,
  or error messages.
- 285 vitest cases (SSH/SFTP fully mocked) plus an opt-in real-host acceptance script
  (`scripts/acceptance.mjs`), verified against two live hosts.
