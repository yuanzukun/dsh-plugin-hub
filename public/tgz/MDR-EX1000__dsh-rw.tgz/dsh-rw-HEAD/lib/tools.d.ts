import type { HostEntry, HostSummary } from './hosts.js';
import type { Session } from './session.js';
import type { NativeRouting } from './shim.js';
import type { ExecResult, RemoteShellChannel, SftpLike } from './ssh-pool.js';
/**
 * Structural subset of HostTable consumed by the tools/routes. HostTable has
 * private fields (nominally typed), so depending on this interface is what
 * lets tests supply an in-memory fake without casts; the real HostTable
 * satisfies it unchanged.
 */
export interface HostTableLike {
    list(): HostEntry[];
    find(alias: string): HostEntry | undefined;
    summarize(entry: HostEntry): HostSummary;
    summaries(): HostSummary[];
    addManual(payload: {
        alias: string;
        host: string;
        port?: number;
        user: string;
        password?: string;
        keyPath?: string;
        passphrase?: string;
    }): HostEntry;
    removeManual(alias: string): void;
    /** Drop an ssh-config alias from the list (never edits ~/.ssh/config). */
    hide?(alias: string): void;
    /** Put a hidden alias back. */
    unhide?(alias: string): void;
    /** Aliases currently hidden from the list. */
    hiddenAliases?(): string[];
    /**
     * Replace one manual host's connection details. Optional so a structural
     * double stays valid; the route reports 501 when a table cannot edit.
     */
    updateManual?(alias: string, payload: {
        host: string;
        port?: number;
        user: string;
        password?: string;
        keyPath?: string;
        passphrase?: string;
    }): HostEntry;
}
/** Structural subset of SshPool (same rationale as HostTableLike). */
export interface PoolLike {
    exec(entry: HostEntry, command: string, opts?: {
        cwd?: string;
        timeoutMs?: number;
    }): Promise<ExecResult>;
    sftp(entry: HostEntry): Promise<SftpLike>;
    /**
     * Open a long-lived shell channel. Optional so structural test doubles stay
     * valid; the persistent-shell manager reports a clear error when a pool
     * cannot provide one.
     */
    openShell?(entry: HostEntry): Promise<RemoteShellChannel>;
    testConnect(entry: HostEntry): Promise<number>;
    disconnect(alias: string): void;
    connected(): string[];
    dispose(): void;
}
export interface ToolsDeps {
    hosts: HostTableLike;
    pool: PoolLike;
    session: Session;
    config: {
        commandTimeoutMs: number;
        maxOutputChars: number;
        /** Shown by rw_info; optional so minimal test configs still typecheck. */
        hostKeyPolicy?: string;
    };
    /** Base dir for placeholder dirs (tests inject a tmp dir). */
    placeholderBaseDir?: string;
    /** Where native tools actually go, as observed by the shim (plugin-load scope). */
    routing?: NativeRouting;
    /** Whether the shim is currently on (a live getter: the settings layer can flip it). */
    shimEnabled?: () => boolean;
}
/**
 * The slice of the tool execution context this module reads. Structural on
 * purpose: the real value is a `ToolRunContext`, and tests drive plain objects.
 */
interface ExecLike {
    agent?: {
        session?: {
            header?: {
                cwd?: string;
            };
        };
    };
}
/**
 * Shared pick-workspace validation used by rw_pick_workspace and the
 * /api/dsh-rw/workspace route: resolve symlinks via realpath, require a
 * directory, create the local placeholder. Returns the real workspace path
 * and the placeholder directory. Does not touch the session. `name` (picker
 * only) names a fresh placeholder; the tool flow omits it (basename default).
 */
export declare function resolveWorkspaceDir(deps: ToolsDeps, alias: string, path: string, name?: string): Promise<{
    workspace: string;
    placeholderDir: string;
}>;
/** Sync status lines shared by rw_info and the /rw slash command. */
export declare function statusText(deps: ToolsDeps, exec?: ExecLike): string;
/** The fixed number of rw_* tools, exported so the registration-order tests track it. */
export declare const RW_TOOL_COUNT = 16;
/** The twelve rw_* tools in their fixed registration order. */
export declare function makeTools(deps: ToolsDeps): unknown[];
export {};
