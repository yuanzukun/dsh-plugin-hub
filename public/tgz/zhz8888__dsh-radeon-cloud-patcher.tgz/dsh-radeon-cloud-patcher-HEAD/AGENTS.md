# AGENTS.md

本文件为在本仓库工作的智能体与协作者提供指引。

## 这是什么

`@zhz8888/dsh-radeon-cloud-patcher` —— 一个把 AMD Radeon Cloud 接入 DeepSeek Harness 的 DSH 插件。

**核心认知：本插件不实现任何 provider 逻辑。** 传输、思考字段解析、多轮回传、用量计量全部由 DSH 自带的 `dsh-llm-pi-ai` 承担。本插件只做四件事：分发、**补丁层声明 provider 定义**、版本闸门、启动校验与 id 归属判定。

任何"顺手给 provider 加个功能"的想法都违背本项目的设计前提。

**第二条认知：插件不写用户的 profile。** 定义只活在插件自带的 `cordis.plugin.patch.yml` 里，profile 是用户的文件，本插件对它只读。这不是洁癖，而是三个需求的技术前提——设置页不出现「删除」按钮、卸载插件即删除供应商、删除供应商只能靠卸载插件（机制见下方「定义为什么必须落在补丁层」）。

## 架构约束

### 零运行时依赖

`package.json` 没有 `dependencies`。源码只 import Node 内置模块：

```
node:child_process  node:fs  node:module  node:path  node:url  node:util
```

`@deepseek-ai/*` 全部声明为 `peerDependencies`，由 DSH 宿主提供。**引入任何 npm 依赖前先问：这是否破坏了「零依赖、可审计、无供应链风险」这三个卖点？** 同类第三方 provider 插件的常规形态是两万行量级的宿主代码加浏览器卡片，本插件的卖点恰恰是反着来。

### 所有定位都走 import.meta.url

`src/index.js`、`src/yaml.js` 与 `scripts/` 下的脚本一律用

```js
const HERE = path.dirname(fileURLToPath(import.meta.url))
```

推导自身位置，**没有任何按包名自我解析的代码**。这正是本插件能安全改包名与加作用域的原因；改动时不要引入 `require('本插件包名')` 之类的自引用。

### 定义为什么必须落在补丁层

DSH 的非 `insert` 补丁是**整体替换**：同一 id 的 config 会整份盖掉它之前所有层给的 config（bundle 层按 `dsh.profile.bundles` 顺序，然后是 profile 的 `cordis.patch.yml`，最后是 home 与命令行 overlay）。

设置页的「删除」按钮判据是 `dsh-client-ui-settings-models` 里的：

```js
removable = settingsPath.length > 0 && hasPath(namespace.user, path) && !hasPath(namespace.base, path)
```

也就是说：**该 provider 路径只要出现在 base 层，按钮就永不渲染**。定义写在 profile（用户层）就必然带按钮，写在插件的 bundle 层则永远没有——而卸载插件就等于删除供应商，因为 profile 里没有副本。这就是 `cordis.plugin.patch.yml` 里那段生成区块存在的全部理由。

代价与配套：

- 定义在补丁文件里只能是文本副本，真源仍是 `provider/radeon-cloud.yml`，靠 `scripts/sync-bundle-patch.mjs` 渲染、`test/patch-sync.test.mjs` 断言一致——**改完真源必须跑 `pnpm sync:patch`**；
- profile 里一旦出现 `llm-pi-ai` 的 config（用户自己加过 provider），插件层会被整份盖掉。`src/index.js` 启动时静态读 profile / home / overlay 三层判定，`src/ownership.js` 给出四种归属结局：`plugin-layer`（正常）、`materialized`（同 id 且与本插件一致，视为设置页物化的副本，放行）、`shadowed`（被盖掉 → 启动失败 + 合并命令）、`conflict`（同 id 但不一致 → 启动失败 + 第一处差异），另有哨兵 `dynamic`（config 是 `!!js` 表达式、或本次运行拿不到 profile 目录时跳过判定，只告警）；
- 判定之所以是「一致即放行」而不是「有声明就失败」：设置页每保存一次都会把有效配置物化进用户层（录入 API Key 也会），严格判定会让插件在用户正常操作后无法启动；
- `scripts/apply-to-profile.mjs` 是补救路径（`shadowed` 时把定义按键合并进 profile），它同样拒绝覆盖不一致的同 id 定义，除非 `--force`。

`src/merge.js` 里写死两个常量，改动它们要极度谨慎：

```js
export const PROVIDER_KEY    = 'radeon-cloud'
export const TARGET_ENTRY_ID = 'llm-pi-ai'
```

`TARGET_ENTRY_ID` 是 DSH 自己的条目 id，与本插件无关。

### 客户端补丁用 DSH 的模块格式，不是 ESM

`client/client.js` 是设置页里隐藏「自定义」标签的那条 CSS，它**必须**是 DSH 客户端模块的包装格式：

```js
window.__ModuleLoader__.load({ id: '@zhz8888/dsh-radeon-cloud-patcher', factory: (require) => { … } })
```

- `id` 必须等于 `package.json` 的 `name`——DSH 按包名给客户端模块建表，写错会「加载了却没注册」而失败；
- 该文件**不是 ESM**，不要 `import` 进任何 Node 代码（测试用 `node:vm` 在桩环境里跑它）；
- `package.json` 里 `exports["./client"]` 指向它，`dsh.client.platform` 声明为 `web`；
- 客户端补丁不做 DOM 写入，只注入一条样式规则，判据是 DSH 自己拼的 `aria-label`（含 provider 路由名，与语言无关）。它依赖 DSH 的 DOM 结构，改版后可能静默失效——这是已知代价，写进了 README 的「归属与删除」。

### 「插件」页显示名称来自包内 locale，缺了会静默回落成包名

插件页那一行的标题由 `dsh-app-boot` 的 `readPluginMeta` 决定，判据写在
`dsh-client-ui-plugin-manager` 里：

```js
title: pkg.meta?.title === void 0 ? pkg.name : resolveText(pkg.meta.title)
```

也就是说：**读不到元信息就把整个 npm 包名原样显示出来**，全程没有任何报错。
本插件用 `locale/en.json` + `locale/zh.json` 提供 `meta.title` / `meta.description`，
前端再按当前语言取值（DSH 只内置 `zh` 与 `en` 两种，见 `dsh-client-locale` 的 `LOCALE_IDS`）。

三条硬要求，缺任何一条都会静默回落，只有肉眼能发现：

- **`locale/en.json` 必须存在**：`readPluginMeta` 只在 en 能解析时才去扫同目录的其它
  语言文件，所以 zh 写得再好，没有 en 就完全不生效（不只是「英文回落到包名」）；
- **`exports` 里必须有 `./locale/*.json` 模式**：DSH 走的是 Node 的真实模块解析
  （`loader.resolveSync`），缺了模式会抛 `ERR_PACKAGE_PATH_NOT_EXPORTED`，
  而 `optionalResourcePath` 把这个错**当成「没有元信息」吞掉**；
- **`files` 里必须有 `locale`**：漏了则本地开发全绿，发到 npm 的包里却没有这些文件。

同目录下的每个 `*.json` 都会被当作语言文件读取，因此**不要往 `locale/` 里放别的 JSON**
（文件名必须是语言 id，否则整个元信息读取抛错）；`meta.title`、`meta.description`
若存在就必须是非空字符串。

`test/plugin-meta.test.mjs` 钉住上述全部约束：解析那一层走 Node 真实的 `exports`
（包自引用），与 DSH 是同一条路径；语言取值那一层是按 `localizedText` / `resolveText`
语义复刻的模拟。改动 `locale/` 或 `exports` 后跑 `pnpm test:meta`。

### 补丁文件的 id 与 name 故意不同

```yaml
- id: radeon-cloud-patcher                      # profile 内唯一键，不带作用域
  name: "@zhz8888/dsh-radeon-cloud-patcher"     # 安装解析用，必须完整且带引号
```

**这两个值不一样是对的，不要"顺手统一"：**

- `id` 按 DSH 现有惯例取无作用域短名（对照 `llm-pi-ai`、`llm-commandcode`）。它只作唯一键，不承担包名职责。改名会让已装用户无法平滑升级。
- `name` 必须等于 profile `node_modules` 里的完整包标识符。裸写包名会解析失败，**且必须加引号**——YAML 中以 `@` 开头的标量会被当作指令符。

## 版本闸门

**DSH 的安装闸门只读 `peerDependencies`，不读 `engines.dsh`。** 实测代码（`@deepseek-ai/dsh-app-boot`）：

```js
if (!Object.hasOwn(fields, "peerDependencies")) return void 0;
for (const [name, range] of Object.entries(dependencies)) {
  if (name !== "@deepseek-ai/dsh" && !name.startsWith("@deepseek-ai/dsh-")) continue;
  if (!semver.satisfies(runtimeVersion, requirement, { includePrerelease: true })) peers[name] = range;
}
// 不匹配 → dsh-plugin-manager: rejected(preflight, "nothing was installed")
```

三条推论：

1. 只有 `@deepseek-ai/dsh` 与 `@deepseek-ai/dsh-*` 参与判定。**`@deepseek-ai/cordis` 被 `continue` 跳过**——它的范围不影响闸门，判定基准是 DSH 运行时版本而不是各包自身版本。它仍要留在 `peerDependencies` 里（运行时确实 import 它），并且**同样只有下界**：`>=4.0.2`。它不卡闸门，却会在 pnpm 那一步卡 peer 解析——将来 cordis 5.x 落地时不该为它再发一版插件。
2. `engines.dsh` 与 `dsh.compatibility` 是给人看的声明，**必须与 peer 保持同步**，但它们不决定能否安装。改兼容范围时改的是 peer。
3. 预检发生在 `pnpm install` **之前**，读的是我们自己写的 `peerDependencies`。

### 范围形态：只有下界 `>=0.2.0-rc.1`

当前范围是 `>=0.2.0-rc.1`——**故意不写上界**：写死上界意味着 DSH 每升一个大版本都要重发一版插件放宽范围，代价大于收益（原先的双分支 `>=0.2.0-rc.1 <0.2.1-0 || >=0.2.1-0 <0.3.0-0` 就是为此留下的历史）。

代价与边界，改范围前先看这张实测表（用 DSH 自带的 semver 跑过）：

| 运行时版本 | DSH 闸门（`includePrerelease: true`） | npm/pnpm 默认规则 |
|---|---|---|
| `0.2.0-rc.2` | ✅ | ✅ |
| `0.2.0` / `0.2.1` / `0.3.0` / `1.0.0` | ✅ | ✅ |
| `0.2.1-alpha.1`、`0.3.0-beta.1` 等**新元组的预发布** | ✅ | ❌ |

node-semver 规定：带预发布标签的版本，只有在范围里存在「元组相同、且自身也带预发布标签」的比较符时才被放行。`>=0.2.0-rc.1` 只覆盖 `0.2.0` 这一元组的预发布，于是新元组的预发布会卡在 pnpm 那一步（`ERESOLVE`），而 DSH 的闸门因为带 `includePrerelease` 会放行——**两者判定不一致时，失败的是 pnpm**。

真遇到时二选一，别去猜：

```bash
# ① 给该元组补一条分支（例：要支持 0.2.1 的预发布）
#    ">=0.2.0-rc.1 <0.2.1-0 || >=0.2.1-0"
# ② 或让 pnpm 放宽 peer 校验（dsh plugin 的参数原样转发给 pnpm）
dsh plugin --profile <profile> add @zhz8888/dsh-radeon-cloud-patcher \
  --config.strict-peer-dependencies=false
```

范围无上界的另一半代价：**失去「未来版本被挡住」这层保护**（原先 0.3.0 及以上根本装不上）。因此插件自身必须继续在启动时响亮失败——定义校验、id 归属判定、收尾核验路由是否注册，三者都不能退化。

三处声明（`peerDependencies`、`engines.dsh`、`dsh.compatibility.dsh`）由 `pnpm test:manifest` 断言逐字一致，改一处必须三处同改。

## 常用命令

```bash
pnpm test                 # 全量：清单不变式 / 插件页元信息 / 合并语义 / 文本级合并 / 所有权判定 / 启动看护 / 补丁一致性 / 思考取回
pnpm test:manifest        # 三处 DSH 版本声明一致、无上界、清单指向的文件都存在
pnpm test:meta            # 插件页显示名称：locale 文件形状、exports 解析、files 白名单
pnpm test:merge           # 合并语义 + 文本级合并 + 所有权判定（离线、不碰 DSH 运行时）
pnpm test:guard           # 启动看护的四种归属结局 + dynamic 跳过
pnpm test:patch           # 补丁与定义真源一致 + 客户端补丁注入的规则
pnpm test:reasoning       # 仅思考字段取回
pnpm sync:patch           # 把 provider/radeon-cloud.yml 同步进补丁的生成区块
pnpm validate             # 用 llm-pi-ai 真实 schema 校验 provider 定义
pnpm probe                # 实测各模型思考档位（需密钥，会打真实 API）
pnpm install:profile:dry  # 补救路径：演练合并进 profile，只打印不写入
pnpm install:profile      # 补救路径：实际写入（自动备份，冲突时拒绝覆盖）
```

改完代码至少跑 `pnpm test && pnpm validate`；**改了 `provider/radeon-cloud.yml` 还要跑 `pnpm sync:patch`**，否则补丁里的副本会漂。**改了 `peerDependencies` 的 DSH 范围要三处同改并跑 `pnpm install` 刷新锁文件**（锁文件里记着 specifier，不同步会让 `--frozen-lockfile` 失败）。`pnpm validate` 是唯一能发现「上游把字段改了名」的手段，**升级 DSH 后务必跑一次**。

### 测试用自研 runner，不是 node:test

`test/` 下的文件全是手写的计数式 runner——逐项检查、累加失败数、结束时
`if (failed > 0) process.exit(1)`。**项目没有引入任何测试框架**：

```bash
grep -rn "node:test\|node:assert" test/   # 无匹配
```

新增测试请沿用现有写法，不要引入 `node:test` 或断言库，否则与既有风格割裂，
且 `pnpm test` 里的退出码约定会失效（CI 依赖非零退出表示失败）。

除 `verify-reasoning.mjs`（读 `test/fixtures/` 里的真实抓取流）之外，其余测试都不碰网络。
`patch-sync.test.mjs` 与 `client-patch.test.mjs` 里的「不漂」断言是刻意设计的：
前者要求生成器再跑一遍**逐字符**不产生改动，后者用 `node:vm` 在桩环境里真跑一遍客户端补丁。

## 代码地图

```
src/index.js       插件入口：启动校验、所有权判定、收尾核验路由是否注册
src/ownership.js   所有权判定的纯函数（四种归属结局 + dynamic 哨兵、差异定位、子集比较）
src/merge.js       键级合并的纯函数（补救路径使用；PROVIDER_KEY / TARGET_ENTRY_ID 在此定义）
src/patch-text.js  文本级编辑：按行定位与替换，以保住用户注释、缩进与键序
src/validate.js    provider 定义的结构校验（不依赖 DSH）
src/yaml.js        定位 YAML 解析器，含回退路径
client/client.js   客户端补丁：隐藏本行的「自定义」标签（DSH 客户端模块格式，非 ESM）
locale/            en.json / zh.json —— 「插件」页显示名称与一句话简介（见下方约束）
provider/          radeon-cloud.yml —— 定义的唯一真源，副本由 sync-bundle-patch.mjs 生成
scripts/           sync-bundle-patch.mjs（生成副本）、apply-to-profile.mjs（补救合并）、
                   validate-config.mjs、probe-efforts.mjs、radeon-api.sh
```

`patch-text.js` 的存在理由值得单说：DSH 补丁是整体替换，走序列化再写回会丢掉
用户在该文件里的注释与格式。文本级编辑是补救路径"不破坏用户配置"这一卖点的实现基础，
改它等于改这个卖点。

### 改动 provider/radeon-cloud.yml 的正确流程

模型的 `reasoningEfforts` 档位表**无法从 API 推断**——模型目录接口只返回 id、
上下文与模态，不返回档位信息。档位只能逐模型实测：

```bash
pnpm probe --only Qwen3.8-27B   # 单模型实测
pnpm probe                        # 全量实测
./scripts/radeon-api.sh GET /models   # 只拉模型目录，不含档位
```

改完定义后跑 `pnpm validate` 确认 schema 合法，**再跑 `pnpm sync:patch` 把定义同步进
`cordis.plugin.patch.yml` 的生成区块**（忘了这一步，装上去的还是旧定义；
`pnpm test:patch` 会拦住这种漂移）。**不要凭模型名推测档位**——
GLM 不接受 `none`（所以它没有关闭档位；Qwen 系反过来，靠 `none` 关闭，不传档位时仍会思考）、某些模型不返回分离思考，这些都是实测结论
（`MiniCPM5-2B` 的 `reasoningEfforts: false` 即表示非推理模型）。
连同一厂商、名字相近的模型也不能互推：`MiniCPM-V-4.7-35B-A3B` 全档接受，
而 `MiniCPM-V-4.7-1B` 只接受 `low/medium/high`。

只有 `200` 是「接受」，`400`/`422` 是「拒绝」。**`429` 与 `5xx` 都不是档位结论**——
前者是限流，后者是上游偶发故障（`504` 被包装成 `500`）。`probe-efforts.mjs` 会自动重测
这两类响应，因此全量实测的真实耗时可能是「模型数 × 档位数 × 间隔」的数倍，
不要因为它跑得久就以为卡住了。

非推理模型写 `reasoningEfforts: false`，不是空对象，也不是省略。

## 实现约束

### 校验依赖 DSH 的真实 schema

`pnpm validate` 与测试都依赖 DSH 的**真实** schema，而不是本项目的副本——这是它能发现「上游把字段改名」的唯一原因，也是无法用假 schema 替代的原因。

代价是这两个命令需要一份可用的 DSH 安装。DSH 桌面版的安装路径随平台与安装位置变化，脚本因此支持用 `DSH_MODULES` 覆盖该路径；该变量的默认值写在 `scripts/validate-config.mjs` 与 `src/yaml.js` 里，不在文档中重复——**以代码为准**。

若因环境原因跑不了，**不要改成跳过校验或内联 schema 快照**：那会让「升级 DSH 后跑一次 validate」这条唯一的失效防线失效。

### pnpm-workspace.yaml 的 allowBuilds

```yaml
allowBuilds:
  '@google/genai': false
  protobufjs: false
```

pnpm v10+ 默认拦截依赖的安装期构建脚本，命中时以 `ERR_PNPM_IGNORED_BUILDS` 让 `pnpm install` **非零退出**，会打断 CI。这两个包是 `@deepseek-ai/dsh-llm-pi-ai` 的传递依赖，且它们发布 tarball 里根本没带构建脚本（`scripts/prepare.js` 与 `scripts/postinstall` 均不存在），故显式设为 `false` 而非放行。

**引入真需要构建的依赖时（如 esbuild），在这里追加 `pkg: true`，不要关闭这项保护。**

注意：**本仓库的这个文件只影响仓库自身开发**。用户安装插件时的构建授权，由 DSH profile 自己的 `pnpm-workspace.yaml` 管理，是另一个文件——不要试图在本仓库配置用户端的授权。

### 改包名后要同步的位置

改 `package.json` 的 `name` 时，以下位置必须一起改，否则装上去解析失败或排查方向错误：

- `cordis.plugin.patch.yml` 的 `name`（带引号的完整 scoped 名）
- `client/client.js` 里 `__ModuleLoader__.load` 的 `id`（DSH 按包名给客户端模块建表）
- `src/index.js` 的 `export const name`
- `src/yaml.js` 的错误信息前缀
- `README.md` 的包名说明与 `dsh plugin add` 命令
- `docs/` 下提到包名的地方（`patch` 的 `id` **不要**改）

`test/patch-sync.test.mjs` 与 `test/client-patch.test.mjs` 会断言这两个 `name`/`id` 与
包名一致，改漏了会红灯。

## 文档现状

仓库只留**必要的描述文档**，不要把它当经验数据库：过程叙述、实测记录、决策依据、
外部实现分析这类内容归个人记忆库，不进仓库。当前三份，全是**当前状态文档**：

- `README.md` —— 用户第一入口：安装、使用、已知限制与归属判定
- `AGENTS.md` —— 本文件：协作方式与架构约束
- `docs/market-submission.md` —— 投稿与发版的照做流程（含两条易踩的 DSH 规则）

三份都必须与代码一致。描述历史或过程的段落一旦与现状冲突，直接改写成现状，不要保留
「当时是这么想的」式叙述；需要交代「为什么」时写进本文件的对应约束一节，而不是另起
一份决策记录。

## 代码风格

- 注释用中文，说明「为什么」而非「做了什么」
- 不引入抽象层：`src/` 与 `client/` 合计约 950 行，薄壳的价值在于可读完
- 错误信息要可操作——告诉用户下一步做什么，而不是描述失败原因
- 新增依赖、新增外部服务、新增平台特定逻辑，都需要先质疑其必要性
- 客户端补丁只做「隐藏一个标签」这种量级的事；一旦需要在浏览器里做逻辑，
  先回头质疑需求本身，而不是把 `client/client.js` 养大

## 提交规范

Conventional Commits：type 与 scope 用英文，subject 与 body 用中文。**本仓库历史不使用 scope**（见 `git log`）。

一次提交一个逻辑改动。用户可见的错误修复（`fix`）与文档同步（`docs`）分开提交，便于日后区分真实缺陷与文档维护。

## 发版

1. 版本号与文档同步后提交，再打 tag（本仓库历史用轻量 tag，指向「版本号升至 X.Y.Z」那条提交）。
2. 创建 GitHub Release：标题用 tag 名，正文按下面这套栏目组织。**各版本保持同一结构**，
   读者才能对照着看；中文、讲清「为什么」，不写营销词。

   ```md
   ## <一句话主题：这一版做了什么>
   <2–4 句讲清动机与后果>

   ### 功能变更（DSH 插件口径）
   **结论：有功能变更 / 无功能变更**

   | 维度 | 与 v<上一版> 相比 |
   | --- | --- |
   | provider 定义（模型、上下文、思考档位） | … |
   | 插件行为（安装、启动看护、设置页表现） | … |
   | 安装方式与 DSH 兼容范围 | … |

   ### 变更 / 修复 / 新增      # 按类型分组，只写能对上代码或实测的事实
   ### 安装与升级              # 安装命令 + npm 版本页链接
   ### 测试                    # 有数字就写，数字来自实跑
   **Full Changelog**：https://github.com/zhz8888/dsh-radeon-cloud-patcher/compare/<上一 tag>...<本 tag>
   ```

   三条硬要求：

   - **「功能变更（DSH 插件口径）」是必备栏目**，三件事分开写清：provider 定义（模型 /
     上下文 / 档位）是否变、插件行为是否变、安装方式与兼容范围是否变。本插件是薄壳，
     「定义没变但插件变了」与「插件没变但定义变了」对用户是两件事，含混会让升级决策失准；
     确实都没变，也要在结论行直说「无功能变更」，再在表里逐项写「未变」。
   - **安装一节不能给出会 404 的命令**：没发布到 npm 的版本（如 `v1.0.0` 用的是无作用域
     包名）要直说，并指向真正可用的版本或安装路径。
   - **compare 链接写之前先验**：`gh api repos/zhz8888/dsh-radeon-cloud-patcher/compare/<a>...<b> --jq .status`
     应为 `ahead`——历史被重排过，旧链接可能失效。补发到 npm 的历史版本要在 npm 链接后
     注明补发日期，别让读者以为发布当天就有。
3. 发布到 npm 前确认目标 registry：npm 可能被全局 `registry` 配置指向镜像源，
   发布前显式指定官方源，避免误发到非预期源。手动步骤与踩坑点见
   [`docs/market-submission.md`](docs/market-submission.md) 的「发布到 npm」。

## 不要做的事

- ❌ 给 provider 加功能（越界，由 `dsh-llm-pi-ai` 负责）
- ❌ 往用户 profile 里写 provider 定义（定义归插件的补丁层；补救路径要用户显式执行）
- ❌ 用补丁整体替换 `llm-pi-ai` 的 config（会抹掉用户配置；插件层声明会被它盖掉，这正是启动看护要抓的情况）
- ❌ 改了 `provider/radeon-cloud.yml` 却忘了 `pnpm sync:patch`（补丁里的副本会与真源脱节）
- ❌ 在插件启动时写用户 profile（有竞态风险，故设计为只读判定 + 响亮失败）
- ❌ 让「一致即放行」的判定退化成「有声明就失败」（设置页每保存一次都会物化一份副本，那会让插件在正常操作后起不来）
- ❌ 统一 `id` 与 `name`（它们故意不同）
- ❌ 删掉 `exports` 里的 `./locale/*.json`、或往 `locale/` 放非语言文件的 JSON（插件页会静默回落成 npm 包名，没有任何报错）
- ❌ 给 `@deepseek-ai/cordis` 加上界（它不参与闸门，却是 pnpm 的 peer——写死上界会在 cordis 升大版本时卡住安装，和 DSH 范围当初的问题一模一样）
- ❌ 手工编辑 `node_modules` 或 profile 里的文件（改上游要从源码改）