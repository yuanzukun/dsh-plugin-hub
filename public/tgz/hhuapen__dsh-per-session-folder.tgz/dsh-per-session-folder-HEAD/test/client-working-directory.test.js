import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'
import test from 'node:test'

const source = await readFile(new URL('../client.js', import.meta.url), 'utf8')

function loadClientModule() {
  let registration
  const window = {
    __ModuleLoader__: {
      load(value) {
        registration = value
      },
    },
  }
  new Function('window', source)(window)
  assert.ok(registration)

  const React = {
    createElement() {
      return null
    },
    Fragment: {},
    useEffect() {},
    useState(value) {
      return [value, () => {}]
    },
  }
  class SettingsFormModel {
    constructor() {}
    actions() {
      return {
        discard() {},
        edit() {},
        resetField() {},
        save() {},
      }
    }
    bind(selector) {
      return {
        getSnapshot: selector,
        subscribe() {
          return () => {}
        },
      }
    }
    dispose() {}
    field(name) {
      return { name, text: '' }
    }
    shell() {
      return {
        creationMode: { text: 'immediate' },
        root: { text: '' },
        writable: false,
      }
    }
  }
  const primitives = {
    Button() {
      return null
    },
    SettingsForm() {
      return null
    },
    SettingsFormModel,
    settingsTextField(name) {
      return { name }
    },
  }
  const modules = {
    react: React,
    '@deepseek-ai/dsh-client-ui-primitives': primitives,
  }
  return registration.factory((name) => modules[name])
}

function makeClientHarness() {
  const originalCwd = 'C:\\default-workspace'
  const managedCwd = 'D:\\session-root\\first-name'
  const projected = new Map([['managed', managedCwd]])
  const listeners = new Set()
  let snapshot = {
    ids: ['managed', 'unmanaged'],
    byId: {
      managed: { cwd: originalCwd, id: 'managed' },
      unmanaged: { cwd: originalCwd, id: 'unmanaged' },
    },
    phase: 'ready',
    projectionsBySession: {},
  }

  function publish() {
    for (const listener of listeners) listener()
  }

  const list = {
    getSnapshot() {
      return snapshot
    },
    set(next) {
      snapshot = next
      publish()
    },
    subscribe(listener) {
      listeners.add(listener)
      return () => listeners.delete(listener)
    },
  }
  const sessions = {
    list,
    binding(sessionId) {
      if (sessionId !== 'managed') return undefined
      return {
        session: {
          projections: {
            get(key) {
              return key === 'workingDirectory' ? projected.get(sessionId) : undefined
            },
          },
        },
      }
    },
  }
  const disposers = []
  const ctx = {
    sessions,
    configForms: {
      get() {
        return {}
      },
    },
    effect(factory) {
      const dispose = factory()
      if (typeof dispose === 'function') disposers.push(dispose)
      return dispose
    },
    locale: {
      bind() {
        return (key) => key
      },
      register() {
        return () => {}
      },
    },
    slots: {
      inject(_name, callback) {
        return callback()
      },
      register() {
        return () => {}
      },
    },
    uiWorkspace: {
      async listDirectory() {
        return []
      },
      async pickDirectory() {
        return undefined
      },
    },
  }

  return {
    ctx,
    disposers,
    originalCwd,
    projected,
    snapshot: () => snapshot,
    reportProjectionChange() {
      snapshot = {
        ...snapshot,
        byId: {
          ...snapshot.byId,
          managed: { ...snapshot.byId.managed, cwd: originalCwd },
        },
      }
      publish()
    },
  }
}

async function settle() {
  await Promise.resolve()
  await Promise.resolve()
}

test('mirrors the effective working directory into DSH session rows', async () => {
  const client = loadClientModule()
  const h = makeClientHarness()
  client.apply(h.ctx)
  await settle()

  assert.equal(h.snapshot().byId.managed.cwd, 'D:\\session-root\\first-name')
  assert.equal(h.snapshot().byId.unmanaged.cwd, h.originalCwd)

  h.projected.set('managed', 'D:\\session-root\\final-title')
  h.reportProjectionChange()
  await settle()
  assert.equal(h.snapshot().byId.managed.cwd, 'D:\\session-root\\final-title')
  assert.equal(h.snapshot().byId.unmanaged.cwd, h.originalCwd)

  for (const dispose of h.disposers.reverse()) dispose()
  h.projected.set('managed', 'D:\\session-root\\ignored-after-dispose')
  h.reportProjectionChange()
  await settle()
  assert.equal(h.snapshot().byId.managed.cwd, h.originalCwd)
})

test('does not require the compatibility surface to exist', async () => {
  const client = loadClientModule()
  const h = makeClientHarness()
  delete h.ctx.sessions

  assert.doesNotThrow(() => client.apply(h.ctx))
  await settle()
})
