import assert from 'node:assert/strict'
import { mkdtemp, mkdir, readFile, readdir, rm, stat, writeFile } from 'node:fs/promises'
import os from 'node:os'
import path from 'node:path'
import test from 'node:test'

import { apply, safeFolderName } from '../index.js'

function human(text) {
  return {
    role: 'user',
    source: { kind: 'user' },
    content: [{ type: 'text', text }],
  }
}

function assistant(text = 'done') {
  return {
    role: 'assistant',
    source: { kind: 'model', provider: 'test', model: 'test' },
    content: [{ type: 'text', text }],
  }
}

async function exists(target) {
  try {
    await stat(target)
    return true
  } catch {
    return false
  }
}

async function waitFor(assertion, timeoutMs = 1_500) {
  const deadline = Date.now() + timeoutMs
  let lastError
  while (Date.now() < deadline) {
    try {
      await assertion()
      return
    } catch (error) {
      lastError = error
      await new Promise((resolve) => setTimeout(resolve, 20))
    }
  }
  throw lastError
}

async function makeHarness(options = {}) {
  const temp =
    options.temp ??
    (await mkdtemp(path.join(os.tmpdir(), 'dsh-per-session-folder-')))
  const workspace = options.workspace ?? path.join(temp, 'default-workspace')
  const root = options.root ?? path.join(temp, 'session-root')
  if (!(await exists(workspace))) await mkdir(workspace, { recursive: true })

  const listeners = new Map()
  const cwd = options.cwd ?? workspace
  const sessionEvents = [...(options.events ?? [])]
  let currentCwd = cwd
  const session = {
    id: options.id ?? 'session-test-12345678',
    header: {
      version: 4,
      createdAt: options.createdAt ?? Date.now(),
      cwd: options.headerCwd ?? workspace,
      isSeeded: false,
      ...(options.header ?? {}),
    },
    snapshotEvents: () => sessionEvents,
  }
  const agent = {
    id: session.id,
    session,
    inbox: { nextTurn: [], nextStep: [] },
  }

  const workingDirectory = {
    defaultDirectory: path.join(temp, 'launch-directory'),
    get(target) {
      assert.equal(target.id, session.id)
      return currentCwd
    },
    async set(target, directory) {
      assert.equal(target.id, session.id)
      assert.equal((await stat(directory)).isDirectory(), true)
      currentCwd = path.resolve(directory)
      sessionEvents.push({
        type: 'working-directory/change',
        data: { cwd: currentCwd },
      })
      return currentCwd
    },
  }

  const services = {
    storageDomain: {
      get(name) {
        if (name !== 'workspace') return undefined
        return {
          global: {
            get: () => ({ defaultWorkspaceId: 'workspace-default' }),
          },
        }
      },
    },
    workspaceRegistry: {
      get(id) {
        return id === 'workspace-default'
          ? { id, path: workspace, title: 'default-workspace' }
          : undefined
      },
    },
    agents: {
      get(id) {
        return id === session.id ? agent : undefined
      },
    },
  }

  const warnings = []
  const ctx = {
    workingDirectory,
    systemPrompt: {},
    logger: { warn: (message) => warnings.push(message) },
    get(name) {
      return services[name]
    },
    on(name, listener) {
      const entries = listeners.get(name) ?? []
      entries.push(listener)
      listeners.set(name, entries)
      return () => {
        const current = listeners.get(name) ?? []
        listeners.set(
          name,
          current.filter((candidate) => candidate !== listener),
        )
      }
    },
    effect(factory) {
      return factory()
    },
  }

  apply(ctx, {
    enabled: true,
    root: options.configRoot ?? root,
    creationMode: options.creationMode ?? 'immediate',
    workspacePath: '',
    maxNameChars: 60,
  })

  async function emitAgentCreated() {
    for (const listener of listeners.get('agent/created') ?? []) {
      await listener({ agent, source: 'create' })
    }
  }

  async function assemble(messages = []) {
    agent.inbox.nextTurn = [...messages]
    let nextCalls = 0
    for (const listener of listeners.get('system-prompt/assemble') ?? []) {
      await listener({}, { agent, signal: new AbortController().signal }, async () => {
        nextCalls += 1
        return {}
      })
    }
    agent.inbox.nextTurn = []
    return nextCalls
  }

  async function preStep(turn, step, messages = []) {
    let nextCalls = 0
    for (const listener of listeners.get('agent/pre-step') ?? []) {
      await listener(
        {
          agent,
          messages,
          turn,
          step,
          signal: new AbortController().signal,
        },
        async () => {
          nextCalls += 1
          return { kind: 'enter', messages }
        },
      )
    }
    return nextCalls
  }

  function sessionEvent(type, data = {}) {
    if (type === 'user/message') sessionEvents.push({ type, data })
    if (type === 'assistant/message') sessionEvents.push({ type, data: { message: data } })
    if (type === 'session/title') sessionEvents.push({ type, data })
    for (const listener of listeners.get('session/event') ?? []) listener(session, { type, data })
  }

  function turnStart() {
    sessionEvent('turn/start', { turn: 1 })
  }

  function turnEnd() {
    sessionEvent('turn/end', { turn: 1, reason: { kind: 'completed' } })
  }

  function title(value) {
    sessionEvent('session/title', {
      title: value,
      messageSeqs: [1],
      source: { kind: 'user' },
    })
  }

  return {
    temp,
    workspace,
    root,
    session,
    agent,
    sessionEvents,
    warnings,
    workingDirectory,
    currentCwd: () => currentCwd,
    emitAgentCreated,
    assemble,
    preStep,
    sessionEvent,
    turnStart,
    turnEnd,
    title,
    cleanup: () => rm(temp, { recursive: true, force: true }),
  }
}

test('creates, renames after the first message, then follows the title', async () => {
  const h = await makeHarness()
  try {
    await h.emitAgentCreated()
    const temporary = h.currentCwd()
    assert.notEqual(temporary, h.workspace)
    assert.equal((await readdir(h.root)).length, 1)

    await h.assemble([human('帮我看下登录报错')])
    const initial = path.join(h.root, '帮我看下登录报错')
    assert.equal(h.currentCwd(), initial)
    assert.equal(await exists(initial), true)
    const marker = JSON.parse(
      await readFile(path.join(initial, '.dsh-per-session-folder.json'), 'utf8'),
    )
    assert.equal(marker.sessionId, h.session.id)
    assert.equal(marker.version, 1)

    h.turnStart()
    h.title('修复登录失败')
    assert.equal(await exists(initial), true)
    h.turnEnd()

    const titled = path.join(h.root, '修复登录失败')
    await waitFor(async () => assert.equal(await exists(titled), true))
    assert.equal(h.currentCwd(), titled)
    assert.equal(await exists(initial), false)
  } finally {
    await h.cleanup()
  }
})

test('does not touch historical sessions, other workspaces, or subagents', async () => {
  const historical = await makeHarness({
    events: [
      { type: 'user/message', data: human('旧消息') },
      { type: 'assistant/message', data: { message: assistant() } },
    ],
  })
  try {
    await historical.emitAgentCreated()
    await historical.assemble([human('继续')])
    assert.equal(historical.currentCwd(), historical.workspace)
    assert.equal(await exists(historical.root), false)
  } finally {
    await historical.cleanup()
  }

  const other = await makeHarness()
  try {
    other.session.header.cwd = path.join(other.temp, 'real-project')
    await other.emitAgentCreated()
    await other.assemble([human('hello')])
    assert.equal(other.currentCwd(), other.workspace)
    assert.equal(await exists(other.root), false)
  } finally {
    await other.cleanup()
  }

  const child = await makeHarness({ header: { origin: 'subagent', parentSession: 'parent' } })
  try {
    await child.emitAgentCreated()
    await child.assemble([human('child')])
    assert.equal(child.currentCwd(), child.workspace)
    assert.equal(await exists(child.root), false)
  } finally {
    await child.cleanup()
  }
})

test('can wait for the first message before creating the folder', async () => {
  const h = await makeHarness({ creationMode: 'first-message' })
  try {
    await h.emitAgentCreated()
    assert.equal(h.currentCwd(), h.workspace)
    assert.equal(await exists(h.root), false)

    await h.assemble([human('只在发送消息后创建')])
    const directory = path.join(h.root, '只在发送消息后创建')
    assert.equal(h.currentCwd(), directory)
    assert.equal(await exists(directory), true)
  } finally {
    await h.cleanup()
  }
})

test('uses -2 for duplicate names and keeps a stable marker', async () => {
  const h = await makeHarness()
  try {
    await mkdir(h.root, { recursive: true })
    await mkdir(path.join(h.root, '同名对话'))
    await h.emitAgentCreated()
    await h.assemble([human('同名对话')])
    const expected = path.join(h.root, '同名对话-2')
    assert.equal(h.currentCwd(), expected)
    assert.equal((await stat(expected)).isDirectory(), true)
    assert.equal(
      (
        await readFile(
          path.join(expected, '.dsh-per-session-folder.json'),
          'utf8',
        )
      ).includes(h.session.id),
      true,
    )
  } finally {
    await h.cleanup()
  }
})

test('restart adoption renames the existing marked folder', async () => {
  const first = await makeHarness()
  try {
    await first.emitAgentCreated()
    await first.assemble([human('整理数据')])
    first.turnStart()
    first.title('整理销售数据')
    first.turnEnd()
    const oldFolder = path.join(first.root, '整理销售数据')
    await waitFor(async () => assert.equal(await exists(oldFolder), true))

    const restarted = await makeHarness({
      temp: first.temp,
      root: first.root,
      workspace: first.workspace,
      cwd: oldFolder,
      events: [
        { type: 'user/message', data: human('整理数据') },
        { type: 'assistant/message', data: { message: assistant() } },
        {
          type: 'session/title',
          data: {
            title: '季度销售数据',
            messageSeqs: [1],
            source: { kind: 'user' },
          },
        },
      ],
    })
    await restarted.assemble([human('继续整理')])
    const renamed = path.join(first.root, '季度销售数据')
    assert.equal(restarted.currentCwd(), renamed)
    assert.equal(await exists(renamed), true)
    assert.equal(await exists(oldFolder), false)
  } finally {
    await rm(first.temp, { recursive: true, force: true })
  }
})

test('adopts and renames folders from the previous development package name', async () => {
  const temp = await mkdtemp(path.join(os.tmpdir(), 'dsh-per-session-folder-legacy-'))
  const workspace = path.join(temp, 'default-workspace')
  const root = path.join(temp, 'session-root')
  const sessionId = 'session-legacy-12345678'
  const folder = path.join(root, '旧版会话目录')
  await mkdir(workspace, { recursive: true })
  await mkdir(folder, { recursive: true })
  await writeFile(
    path.join(folder, '.dsh-session-dir.json'),
    JSON.stringify({ version: 1, sessionId, createdAt: new Date().toISOString() }),
    'utf8',
  )

  const h = await makeHarness({
    temp,
    workspace,
    root,
    cwd: folder,
    id: sessionId,
    events: [
      { type: 'user/message', data: human('旧版消息') },
      { type: 'assistant/message', data: { message: assistant() } },
    ],
  })
  try {
    await h.assemble([human('继续旧版会话')])
    const renamed = path.join(root, '继续旧版会话')
    assert.equal(h.currentCwd(), renamed)
    assert.equal(
      await exists(path.join(renamed, '.dsh-per-session-folder.json')),
      true,
    )
  } finally {
    await h.cleanup()
  }
})

test('root failure leaves the conversation in the default workspace', async () => {
  const temp = await mkdtemp(
    path.join(os.tmpdir(), 'dsh-per-session-folder-failure-'),
  )
  const root = path.join(temp, 'not-a-directory')
  await writeFile(root, 'occupied', 'utf8')
  const h = await makeHarness({ temp, root })
  try {
    await h.emitAgentCreated()
    const nextCalls = await h.assemble([human('仍然可以聊天')])
    assert.equal(nextCalls, 1)
    assert.equal(h.currentCwd(), h.workspace)
    assert.equal(h.warnings.some((message) => message.includes('会话目录操作失败')), true)
  } finally {
    await rm(temp, { recursive: true, force: true })
  }
})

test('sanitizes Windows-invalid and reserved folder names', () => {
  assert.equal(safeFolderName('  a:b/c*?  ', 60), 'a-b-c--')
  assert.equal(safeFolderName('CON', 60), '_CON')
  assert.equal(safeFolderName('...', 60), '')
  assert.equal(Array.from(safeFolderName('😀'.repeat(80), 12)).length, 12)
})
