window.__ModuleLoader__.load({
  id: 'dsh-per-session-folder',
  factory: (require) => {
    const module = { exports: {} }
    const exports = module.exports
    Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' })

    const React = require('react')
    const primitives = require('@deepseek-ai/dsh-client-ui-primitives')
    const h = React.createElement

    const NS = 'dsh-per-session-folder'
    const ROW_NS = 'session-dir'
    const BUNDLE_KEY = 'dsh-per-session-folder'

    const zh = {
      title: 'Session Folders Settings',
      description: '设置新对话的独立文件夹放在哪里。',
      root: '会话文件夹的根目录',
      rootHint:
        '只会影响之后新建的对话，旧文件夹不会搬动。未选择时使用默认工作区。',
      currentPath: '当前路径',
      defaultPath: '默认工作区（未选择）',
      choose: '选择文件夹…',
      choosing: '正在打开…',
      pickFailed: '没有打开文件夹选择器，请重试。',
      useDefault: '使用默认工作区',
      pathDefault: '将使用默认工作区。',
      pathChecking: '正在检查文件夹…',
      pathReady: '文件夹可访问。',
      pathSelected: '文件夹已设置；创建新会话时会再次检查。',
      pathError: '这个文件夹无法访问，请重新选择。',
      creationMode: '创建时机',
      creationModeHint: '“打开时创建”会立刻生成文件夹；“首条消息时创建”可避免留下空文件夹。',
      creationImmediate: '打开对话时创建',
      creationFirstMessage: '首条消息时创建',
      overridden: '已覆盖',
      reset: '恢复默认',
      readOnly: '本部署的设置为只读。',
      unavailable: '该插件当前未加载，暂时无法配置。',
      save: '保存',
      saving: '保存中…',
      saveFailed: '路径没有被接受，请检查后重试。',
    }

    const en = {
      title: 'Session Folders Settings',
      description: 'Choose where new conversations keep their independent folders.',
      root: 'Session folder root',
      rootHint:
        'Only new conversations use this location. Existing folders are not moved; without a selection the default workspace is used.',
      currentPath: 'Current path',
      defaultPath: 'Default workspace (not selected)',
      choose: 'Choose folder…',
      choosing: 'Opening…',
      pickFailed: 'The folder picker could not be opened. Try again.',
      useDefault: 'Use default workspace',
      pathDefault: 'The default workspace will be used.',
      pathChecking: 'Checking folder…',
      pathReady: 'Folder is accessible.',
      pathSelected: 'Folder selected. Access will be checked when a session starts.',
      pathError: 'This folder is not accessible. Choose another folder.',
      creationMode: 'Creation timing',
      creationModeHint:
        'Create on open gives every new chat a folder immediately. Create on first message avoids empty folders.',
      creationImmediate: 'Create on open',
      creationFirstMessage: 'Create on first message',
      overridden: 'Overridden',
      reset: 'Reset to default',
      readOnly: 'This deployment stores settings read-only.',
      unavailable: 'This plugin is not loaded, so it cannot be configured right now.',
      save: 'Save',
      saving: 'Saving…',
      saveFailed: 'The path was not accepted. Check it and try again.',
    }

    function labels(t) {
      return {
        unavailable: t('unavailable'),
        readOnly: t('readOnly'),
        saveFailed: t('saveFailed'),
        save: t('save'),
        saving: t('saving'),
      }
    }

    function SessionDirCard(props) {
      const { t } = props
      const state = props.useSessionDirCard((snapshot) => snapshot)
      const [picking, setPicking] = React.useState(false)
      const [pickError, setPickError] = React.useState('')
      const [pathStatus, setPathStatus] = React.useState('default')

      const rootText =
        typeof state.root?.text === 'string' ? state.root.text.trim() : ''
      const currentPath = rootText || t('defaultPath')
      const creationMode =
        state.creationMode?.text === 'first-message'
          ? 'first-message'
          : 'immediate'

      React.useEffect(() => {
        let active = true
        if (!rootText) {
          setPathStatus('default')
          return () => {
            active = false
          }
        }
        if (!props.canVerifyDirectory) {
          setPathStatus('selected')
          return () => {
            active = false
          }
        }
        setPathStatus('checking')
        Promise.resolve(props.listDirectory(rootText)).then(
          () => {
            if (active) setPathStatus('ready')
          },
          (reason) => {
            if (active) {
              const message = String(reason?.message ?? reason)
              setPathStatus(
                message.includes('needs the browse capability') ||
                  message.includes('directory-picker/unavailable')
                  ? 'selected'
                  : 'error',
              )
            }
          },
        )
        return () => {
          active = false
        }
      }, [rootText, props.canVerifyDirectory, props.listDirectory])

      if (props.view === 'summary') return t('description')

      const choose = async () => {
        if (picking) return
        setPicking(true)
        setPickError('')
        try {
          const picked = await props.pickDirectory()
          if (typeof picked === 'string' && picked.length > 0) {
            props.edit('root', picked)
          }
        } catch {
          setPickError(t('pickFailed'))
        } finally {
          setPicking(false)
        }
      }

      return h(
        'section',
        {
          style: {
            display: 'flex',
            flexDirection: 'column',
            gap: 12,
            padding: 16,
            border: '1px solid var(--dsw-alias-border-l2)',
            borderRadius: 12,
          },
        },
        h('h3', { style: { margin: 0, fontSize: 16 } }, t('title')),
        h('p', { style: { margin: 0, opacity: 0.72, fontSize: 13 } }, t('description')),
        h(
          primitives.SettingsForm,
          {
            labels: labels(t),
            state,
            onSave: props.save,
            onDiscard: props.discard,
          },
          h(
            'div',
            { style: { display: 'flex', flexDirection: 'column', gap: 8 } },
            h('div', { style: { fontSize: 13, fontWeight: 600 } }, t('root')),
            h(
              'div',
              {
                style: {
                  padding: '9px 11px',
                  borderRadius: 8,
                  border: '1px solid var(--dsw-alias-border-l2)',
                  color: 'var(--dsw-alias-label-secondary)',
                  fontFamily: 'var(--dsw-font-family-mono, monospace)',
                  fontSize: 12,
                  overflowWrap: 'anywhere',
                },
              },
              currentPath,
            ),
            h(
              'div',
              { style: { display: 'flex', alignItems: 'center', gap: 8 } },
              h(
                primitives.Button,
                {
                  variant: 'outline',
                  size: 'sm',
                  disabled: !state.writable || picking,
                  onClick: choose,
                },
                picking ? t('choosing') : t('choose'),
              ),
              currentPath === t('defaultPath')
                ? null
                : h(
                    primitives.Button,
                    {
                      variant: 'ghost',
                      size: 'sm',
                      disabled: !state.writable,
                      onClick: () => props.resetField('root'),
                    },
                    t('useDefault'),
                  ),
            ),
            h(
              'div',
              {
                style: {
                  color: pickError
                    ? 'var(--dsw-alias-state-error-primary)'
                    : pathStatus === 'error'
                      ? 'var(--dsw-alias-state-error-primary)'
                      : pathStatus === 'ready'
                        ? 'var(--dsw-alias-state-success-primary, #48c78e)'
                    : 'var(--dsw-alias-label-tertiary)',
                  fontSize: 12,
                },
              },
              pickError ||
                (pathStatus === 'checking'
                  ? t('pathChecking')
                  : pathStatus === 'ready'
                    ? t('pathReady')
                    : pathStatus === 'error'
                      ? t('pathError')
                      : pathStatus === 'selected'
                        ? t('pathSelected')
                      : pathStatus === 'default'
                        ? t('pathDefault')
                        : t('rootHint')),
            ),
            h(
              'div',
              {
                style: {
                  display: 'flex',
                  flexDirection: 'column',
                  gap: 8,
                  paddingTop: 12,
                  borderTop: '1px solid var(--dsw-alias-border-l2)',
                },
              },
              h('div', { style: { fontSize: 13, fontWeight: 600 } }, t('creationMode')),
              h(
                'div',
                { style: { display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap' } },
                h(
                  primitives.Button,
                  {
                    variant: creationMode === 'immediate' ? 'primary' : 'outline',
                    size: 'sm',
                    disabled: !state.writable,
                    onClick: () => props.edit('creationMode', 'immediate'),
                  },
                  t('creationImmediate'),
                ),
                h(
                  primitives.Button,
                  {
                    variant:
                      creationMode === 'first-message' ? 'primary' : 'outline',
                    size: 'sm',
                    disabled: !state.writable,
                    onClick: () => props.edit('creationMode', 'first-message'),
                  },
                  t('creationFirstMessage'),
                ),
              ),
              h(
                'div',
                {
                  style: {
                    color: 'var(--dsw-alias-label-tertiary)',
                    fontSize: 12,
                  },
                },
                t('creationModeHint'),
              ),
            ),
          ),
        ),
      )
    }

    /**
     * DSH keeps the session's original workspace in the list-row `cwd`, while
     * this plugin changes the effective working-directory projection. The
     * Open In control reads the list row, so mirror the effective directory
     * until DSH updates the summary itself. This is deliberately isolated and
     * fails quietly if the internal client shape changes.
     */
    function installWorkingDirectoryCompatibility(ctx) {
      const sessions = ctx.sessions
      const list = sessions?.list
      if (
        typeof sessions?.binding !== 'function' ||
        typeof list?.getSnapshot !== 'function' ||
        typeof list?.subscribe !== 'function' ||
        typeof list?.set !== 'function'
      ) {
        return () => {}
      }

      let disposed = false
      let scheduled = false
      let warned = false

      const reconcile = () => {
        if (disposed) return
        const snapshot = list.getSnapshot()
        if (!Array.isArray(snapshot?.ids) || !snapshot?.byId) return

        let changed = false
        const byId = { ...snapshot.byId }
        for (const sessionId of snapshot.ids) {
          const row = byId[sessionId]
          if (!row) continue
          let workingDirectory
          try {
            workingDirectory = sessions
              .binding(sessionId)
              ?.session?.projections?.get?.('workingDirectory')
          } catch {
            continue
          }
          if (
            typeof workingDirectory === 'string' &&
            workingDirectory.length > 0 &&
            row.cwd !== workingDirectory
          ) {
            byId[sessionId] = { ...row, cwd: workingDirectory }
            changed = true
          }
        }

        if (!changed) return
        try {
          list.set({ ...snapshot, byId })
        } catch (error) {
          if (!warned) {
            warned = true
            console.warn(
              'dsh-per-session-folder: working-directory UI compatibility unavailable:',
              error,
            )
          }
        }
      }

      const schedule = () => {
        if (disposed || scheduled) return
        scheduled = true
        queueMicrotask(() => {
          scheduled = false
          reconcile()
        })
      }

      let stop
      try {
        stop = list.subscribe(schedule)
        schedule()
      } catch (error) {
        if (!warned) {
          console.warn(
            'dsh-per-session-folder: working-directory UI compatibility unavailable:',
            error,
          )
        }
        return () => {}
      }

      return () => {
        disposed = true
        if (typeof stop === 'function') stop()
      }
    }

    function apply(ctx) {
      const t = ctx.locale.bind(NS)
      ctx.effect(
        () =>
          ctx.locale.register(NS, {
            zh,
            en,
          }),
        'dsh-per-session-folder: dictionaries',
      )

      const form = new primitives.SettingsFormModel(ctx.configForms.get(ROW_NS), [
        primitives.settingsTextField('root'),
        primitives.settingsTextField('creationMode'),
      ])
      const store = form.bind(() => ({
        ...form.shell(),
        root: form.field('root'),
        creationMode: form.field('creationMode'),
      }))
      const desktopPicker = globalThis.__DSH_DIRECTORY_PICKER__
      const canVerifyDirectory =
        typeof desktopPicker?.pick !== 'function'
      const pickDirectory =
        typeof desktopPicker?.pick === 'function'
          ? () => desktopPicker.pick()
          : () => ctx.uiWorkspace.pickDirectory()
      const listDirectory = (directory) =>
        ctx.uiWorkspace.listDirectory(directory)
      ctx.effect(
        () => () => form.dispose(),
        'dsh-per-session-folder: form subscription',
      )

      ctx.effect(
        () => installWorkingDirectoryCompatibility(ctx),
        'dsh-per-session-folder: working-directory UI compatibility',
      )

      ctx.effect(
        () =>
          ctx.slots.inject('plugins.bundle.config', () =>
            ctx.slots.register(
              {
                name: 'plugins.bundle.config',
                key: BUNDLE_KEY,
                locale: NS,
                inject: () => ({
                  hooks: { sessionDirCard: store },
                  pickDirectory,
                  canVerifyDirectory,
                  listDirectory,
                  ...form.actions(),
                }),
              },
              SessionDirCard,
            ),
          ),
        'dsh-per-session-folder: bundle detail configuration',
      )
    }

    exports.apply = apply
    exports.inject = ['slots', 'locale', 'configForms', 'uiWorkspace', 'sessions']
    return module.exports
  },
})
