# Changelog

All notable changes to this project are documented here.

## 0.1.1 - 2026-11-02

- Mirror each session's effective working directory into DSH's client session state.
- Make the built-in Open In button and local-file actions target the managed session folder.
- Keep the compatibility layer isolated and degrade gracefully if DSH's internal client shape changes.

## 0.1.0 - 2026-11-02

- Create one isolated working folder for each new conversation in the default workspace.
- Rename the folder when the first message arrives and whenever the session title changes.
- Add a native folder picker and display the selected folder's availability.
- Support creating folders immediately or only after the first message.
- Preserve existing session folders across plugin restarts with durable marker files.
- Keep workspaces, historical sessions, and subagent sessions unchanged.
