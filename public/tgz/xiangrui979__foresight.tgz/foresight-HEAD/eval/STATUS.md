# ForeSight 评估任务仪表盘（STATUS）

> 每个 task 完成即更新本文件（计划 §12）。预注册见 `eval/DECISIONS.md`（冻结，只可追加）。
> 计划：`plans/2026-10-01_180525-foresight-eval-plan-v3.1.md`（v3.1）

## 里程碑 Gate

| Gate | 判据 | 状态 |
|---|---|---|
| G0（P0 末） | 预注册提交；CI 绿；分类器默认+切换规则冻结；seed 支持性入档；风险签字 | 🟡 条件性通过（预注册/分类器已冻结；seed 已入档；2026-10-02 存储层切换后 CI 矩阵改为 22/24，**新矩阵 8 job 待远端首跑**；原 12/12 证据已由新矩阵取代）；待关闭：风险签字 |
| G1（P1 末） | smoke 7/7；golden 5/5；机制修复 C1–C11 通过；成本误差 <15%；C5 终审；stale 抽检 ≥90% | 🟡 自动项全过（smoke 7/7、机制清单、C5 终审=维持 A、**真实 smoke（gpt-6.1-sol judge）foresight 0.90 / unknown 0 / 空答案 0、成本对账 0.0% ✅、LLM 对照臂 ✅**；judge 切换与中转通道已登记）；待人工：stale 抽检（§1 处置 A/B 待裁定）、10 条评分抽查、judge 人审 ≥40（§2B）、golden 签核、κ/AC1、风险签字 |
| G2（P2 pilot 末） | 仿真功效完成；样本量/扩样决策落 DECISIONS；judge 人审 ≥80% | ⬜ |
| G3（P2 末） | 矩阵无缺失格；`--no-cache` 双跑 Δ 报告；κ ≥0.7 | ⬜ |
| G4（P3 末） | 机制表完成；failure taxonomy 定稿；同向性检查通过 | ⬜ |
| G3.5（P4 末） | `ship-only / ship+C / revise-B` 决策记录 | ⬜ |
| G5（P4 末） | 预注册合规审计通过；内部评审闭环 | ⬜ |

## P0 · 预注册与仓库基线（2–3 天）

| Task | 状态 | commit | 备注 |
|---|---|---|---|
| 0.1 预注册 DECISIONS.md | ✅ | `141057e` | pre-reg-v1；含 C-extension 段 / stale_gt 协议 / decorative 清单 |
| 0.2 测试命令 + pin Node + CI | ✅ | `ce8b628` | `node --test`；`.nvmrc=24`；CI {ubuntu,windows}×{20,22,24}×{UTC,Asia/Shanghai}；首跑修复两轮后 12/12 全绿（2026-10-01，run `36879528894`） |
| 0.3 trace schema v2 + STATUS | ✅ | `36a163f` | schema + `lib/trace.mjs`（validate/SIR 复算）+ 3 条样例；修复 `/lib/` 误忽略 eval/lib |
| 0.4 eval 脚手架 | ✅ | `a1cfbb2` | runner --help / configs / eval README / artifact ignores |
| 0.5 成本模型骨架 | ✅ | `7961719` | budget.mjs / cost.mjs / fullcontext 入模（tokensPerCall.reader）/ 双跑 ×2；自检通过 |
| 0.6 冻结开关 + seed 探针 | ✅ | `d2b4fbe` | §14 开关/时间线冻结；`eval/scripts/seed-probe.mjs` 交付；seed 实测完成（2026-10-01 补测）：`seed_effective`（DECISIONS §4） |
| 0.7 分类器语言决策门 | ✅ | `278241a` | §15 默认 A（双语 rules）+ G1 切换规则 + 成本影响 + P1.9 范围冻结 |

**P0 收尾验证（2026-10-01，本机 Node v24.11.1）**：`pnpm build` ✅ · `pnpm test` 80/80 ✅ · `trace --validate` 3/3 ✅ · `cost/budget --selfcheck` ✅ · `runner --help` ✅（exit 0）。

## P1 · 机制修复与评估基建（10–12 天，2 checkpoint；D21）

> Checkpoint-1（Task 1.1–1.4 后）：时钟/生命周期/因子/UTC + trace/预算 + judge 基建跑通。
> Checkpoint-2（Task 1.5–1.7 后）：7 系统 + 3 adapter + golden 5/5；gate-eval（1.9）可与 P2 并行。

| Task | 状态 | commit | 备注 |
|---|---|---|---|
| 1.1 Clock + 生命周期接线 + 过期统一 + UTC（C1/C2/C7/C8/C10/C11） | ✅ | `af5049b` | 93/93（旧 80 + 新 13）；TZ=UTC / Asia/Shanghai 双跑通过；`Date.now()` 仅 `src/clock.ts`；nudge 重复实现删除；point 锚 TTL 修正；未然体证据通道；旧 gate 时区夹具 UTC 化（C8 语义） |
| 1.2 检索因子对齐 + 全 policy 表面一致性（C3/C9） | ✅ | `134051b` | 99/99；模板因子名对齐（embed/time/activation/links）+ 权重冻结 0.40/0.20/0.25/0.15；render_anchor 值域接线；全表面叶子审计（执行者或 §13 decorative）；DECISIONS §13 定稿 |
| 1.3 Trace + token 记账 + 预算护栏 | ✅ | `1ea22b0` | 99/99；`--selfcheck` 5 题离线端到端（真实 Store/search/render + ManualClock）→ trace v2 校验通过；运行时 SIR-i/SIR 与 `trace.mjs --sir` 一致；tokenizer=estimate@v1（偏离已登记） |
| 1.4 LLM 缓存 + judge 基建（D1/D6） | ✅ | `13fbec7` | 缓存 0 调用 / --no-cache 真调用 / 断网命中 / 退避重试自检通过；judge prompt 冻结 `42d5fff0-...` + 篡改检测 + 可插拔 |
| 1.5 消融开关 + 7 系统 + 预算渲染（D8/C6/D17） | ✅ | `8be880d` | 106/106（旧 99 + 新 7）；开关单测（lifecycle/conflict/classifier）；插件侧预算 + eval render-budget 同 counter；7 系统 × 3 题 dry-run = 21 trace 校验通过；D17 混合口径已登记 deviation |
| 1.6 Bench adapter（D7/D14） | ✅ | `87ffe27` | SPEC 冻结；`rules@v1` 标注器；3 adapter + golden 各 5/5 自检通过；`extract.mjs` 抽取接口；人工签核列 G1 前 |
| 1.7 基准拉取与许可核验 | ✅ | `b92d510` | LME cleaned s+oracle（MIT；s SHA256 与上游记录一致；KU=78/abstention=30 确认）；LoCoMo（CC BY-NC 4.0 实测；cat2=321/cat5=446）；`fetch/check.mjs` 通过；数据不入库 |
| 1.8 评分器（score/stats 骨架） | ✅ | `c1eedd7` | 110/110；stats 自检（McNemar/bootstrap/Holm/BH/效应量）；score 出 JSON+MD+review_sample；dry-run 的 foresight vs recency 配对表已生成；10 条人工抽查待签核（G1 前） |
| 1.9 Gate/aspect×anchor 分类器评估（C5，400 条） | 🟡 离线完成 | `dcfde34` | 双语 rules 扩展 + 400 条冻结；**rules aspect 90.0%**（hard 71.4%）→ PASS 维持 A（G1 C5 终审）；LLM 对照臂与 κ/AC1 待 key/人工（deviation） |
| 1.10 Smoke 矩阵（G1 门槛） | 🟡 离线完成 | `(next)` | 140 trace 校验通过；机制清单 C1/C2/C3/C5/C6/C7/C8/C10 全 PASS；foresight 0.90 vs recency 0.60；真实 reader/judge 与成本对账待 key |

**Checkpoint-1（Task 1.1–1.4）✅ 2026-10-01**：build ✅ · 99/99（当时） · TZ 双跑 ✅ · trace/cost/budget/llm/judge/runner selfcheck ✅。

**Checkpoint-2（Task 1.5–1.7）✅ 2026-10-01**：7 系统 × 3 题 dry-run 21 trace ✅ · 3 adapter golden 各 5/5 ✅ · 数据 `fetch --check` 全绿（LME s SHA256 与上游独立记录一致）✅。

## P1–P5

| 阶段 | 状态 | 备注 |
|---|---|---|
| P1 机制修复与评估基建（C1–C11，10 task，2 checkpoint） | 🟡 离线全部完成 | 1.1–1.10 交付（10/10，Checkpoint-1/2 通过）；G1 离线项全过。**2026-10-02 存储层 node:sqlite 适配已验证：120/120、smoke/gate-eval/selfcheck 数字逐项不变**。待 key 项已闭环（2026-10-03）：真实成本对账、LLM 对照臂、真实 smoke（judge=gpt-6.1-sol 经 codex 中转）；待人工：stale 抽检（§1 处置待裁定）、10 条评分抽查、judge 人审 ≥40（§2B）、golden 签核、κ/AC1、G0 风险签字。P2 在 G1 完全关闭后启动 |
| P2 主实验（pilot → 主矩阵 → 消融 → 人审 → 冻结） | 🟡 系统补全 + pilot | **系统补全**：时态演化（v1.23）+ gnomic/IMPORTANT.md（v1.25，policy v4）+ 正交转换模型（v1.26）+ **架构审计修复 B1–B5/P1**（v1.27）✅（单测 **139/139**）；gate-eval 新 gold：rules aspect 90%/anchor 92.5%、LLM 97.25%/79.75%；timesuite **6 类 × 15 = 90 题离线全过**；golden 5/5×3（新语义）。**2.1 pilot（rules gate）**：LME-KU 12/30、LoCoMo 0/30；**R14 = 切 LLM gate**（v1.22）。待：主矩阵分类策略裁定 → 系统冻结 → smoke real 重跑 → G2 功效 |
| P3 bench-timesuite（7 类 × 60 + 留出集 + 盲评 140） | 🟡 第一波完成 | 转换引擎四类 × 15 = **60 题**（完成归位/时钟跳跃/兜底升级/降冗余）：`gen/verify/selfcheck` 全绿（离线 60/60）；其余类别与留出/盲评后续 |
| P4 分析与写作（统计图表 → 草稿 → 合规审计 → 评审 → G3.5） | ⬜ | |
| P5 发布（repo 0.2.0 / artifact / arXiv） | ⬜ | |

## 已知阻塞

| 项 | 影响 | 处理 |
|---|---|---|
| `DEEPSEEK_API_KEY` 环境依赖 | P1.4 judge/LLM 基建真实调用 | P0.6 seed 补测已完成（2026-10-01 临时注入）；P1 真实调用前需确认 key 供应 |
| P1 产出含推理截断空响应（已修，已重跑） | 原 smoke real 汇总与 gate-eval LLM 臂含污染（9 行 judge unknown / 3 行空答案 / 1 条 gate 空响应） | 2026-10-03 修复并重跑：smoke foresight 0.90 / unknown 0 / 对账 0.0%；gate-LLM aspect 97.25%（Changelog v1.17–v1.19） |
| CI 远端首跑未验证（已解决） | ✅ G0「CI 绿」已确认 | 2026-10-01：两轮修复后 12/12 全绿（run `36879528894`）；pnpm@10.34.6（`295dd1c`）+ Windows node-gyp@12.4.0（`16a520e`） |
