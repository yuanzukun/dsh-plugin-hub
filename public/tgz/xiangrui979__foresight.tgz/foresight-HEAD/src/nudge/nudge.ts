/**
 * ForeSight nudge: periodic maintenance engine (design §11 ops face).
 *
 * Duties:
 *  1. maintenance reminder every every_turns (pure buildNudge, no dsh dep);
 *  2. temporal review questions: progressive near TTL → renewal confirm;
 *     prospective past review_every_turns → modality-branch question
 *     (prediction due / intention tri-question / plan revision);
 *  3. conflict review: list suppressed entries + contradicts edges
 *     (restore or confirm);
 *  4. candidate extraction: rules pattern-scan from recent session (zero LLM);
 *     llm mode uses LLM with rules fallback;
 *  5. session timeline one-liner (include_session_timeline).
 *
 * dsh scheduler shell NudgePlugin uses loose types (no @deepseek-ai/* import),
 * compiles without dsh; attach(ctx) only runs inside dsh.
 */
import { randomUUID } from 'node:crypto'
import type { Policy, Aspect, MemoryStatus } from '../policy.js'
import type { Memory } from '../store.js'
import { expireCheck, renewalDue } from '../evolve/temporal.js'
import { buildClassifyFn } from '../gate/classify.js'
import { normalizeClock, systemClock, type Clock, type ClockLike } from '../clock.js'

export type ReviewKind = 'renewal' | 'prospective' | 'conflict' | 'conflict_active' | 'expiry_suggest' | 'verdict' | 'uncertain'

export interface ReviewItem {
  type: ReviewKind
  memoryId: string
  text: string
}

export interface NudgeResult {
  trigger: boolean
  text: string | null
  reviewItems: ReviewItem[]
}

/** Narrow store interface (structural: real Store & test fakes both fit). */
export interface NudgeStore {
  listByAspectStatus(aspect: Aspect, status: MemoryStatus, scope?: string): Memory[]
  listLinksOf(id: string): Array<{ id: number; src: string; dst: string; rel: string; weight: number; source: string }>
  listConversationsSince?(sessionId: string, createdAfter: number, limit?: number): Array<{ id: number; peer: string; content: string; createdAt: number }>
  listActiveContradictions?(scope?: string): Array<{ src: string; dst: string }>
  listRecentUserTexts?(since: number, limit?: number): string[]
  searchConversations?(query: string, limit?: number): Array<{ id: number; content: string }>
  getMemory?(id: string): Memory | null
  updateMemory?(id: string, patch: Partial<Pick<Memory, 'content' | 'aspect' | 'status' | 'metadata' | 'activation' | 'baseWeight' | 'anchor' | 'category' | 'telicity' | 'modality'>>): Memory | null
  softDelete?(id: string): boolean
  emit?(type: string, target: string | null, detail: Record<string, unknown> | null): void
}

export interface NudgeDeps {
  store: NudgeStore
  policy: Policy
  now: number
  turnCount: number
  sessionStartTs: number
  sessionId?: string
  /** Isolation scope; dsh uses 'global'. */
  scope?: string
  llm?: LlmLike
  /** Injectable evidence provider for prediction verification (C7);
   *  default = conversation FTS + linked-memory evidence. */
  evidenceFor?: (m: Memory) => string[] | Promise<string[]>
}

export interface LlmLike {
  call(req: {
    model: string
    system: string
    user: string
    json?: boolean
    maxTokens?: number
  }): Promise<{ content: string; json: unknown | null }>
}

const DAY_MS = 86_400_000

// Temporal checks are the single evolve/temporal implementation (C2):
// expireCheck(policy, m, now) / renewalDue(policy, m, now) — no local copy.

// ── candidate extraction (rules pattern scan, zero LLM) ──────────────

export function extractCandidatesByRules(messages: string[], max: number): string[] {
  const hits: string[] = []
  for (const msg of messages) {
    if (/(以后|从此|总是|必须|不要|偏好|习惯|要求|希望)/.test(msg) && msg.length >= 8) {
      if (!hits.includes(msg)) hits.push(msg)
    } else if (/(路径|版本|配置|安装|更新)了?/.test(msg) && /[A-Z]:[\\/]|[A-Za-z0-9._-]+\.[a-z]{2,4}/.test(msg)) {
      if (!hits.includes(msg)) hits.push(msg)
    }
    if (hits.length >= max) break
  }
  return hits.slice(0, max)
}

function collectCandidates(deps: NudgeDeps): string[] {
  if (deps.policy.nudge.candidate_extraction !== 'rules') return []
  const max = deps.policy.nudge.candidate_max ?? 5
  const texts = recentUserTexts(deps)
  return extractCandidatesByRules(texts, max)
}

function recentUserTexts(deps: NudgeDeps): string[] {
  if (deps.sessionId && deps.store.listConversationsSince) {
    return deps.store
      .listConversationsSince(deps.sessionId, Math.max(0, deps.sessionStartTs - 1), 200)
      .filter((m) => m.peer === 'user')
      .map((m) => m.content)
  } else if (deps.store.listRecentUserTexts) {
    return deps.store.listRecentUserTexts(deps.sessionStartTs, 200)
  }
  return []
}

async function extractCandidatesByLlm(deps: NudgeDeps, texts: string[]): Promise<string[]> {
  const max = deps.policy.nudge.candidate_max ?? 5
  if (!deps.llm || texts.length === 0) return extractCandidatesByRules(texts, max)
  try {
    const r = await deps.llm.call({
      model: deps.policy.nudge.llm_model ?? deps.policy.llm.model_classify,
      system:
        '你是记忆候选提取器。从用户消息中提取值得长期记忆的事实/偏好/规则候选，' +
        `输出 JSON 数组（每个元素为单条候选文本，原句或简洁改写，去重），最多 ${max} 条，无候选输出 []。`,
      user: texts.join('\n'),
      json: true,
      maxTokens: 512,
    })
    const arr = Array.isArray(r.json) ? r.json : []
    const hits: string[] = []
    for (const x of arr) {
      const s = typeof x === 'string' ? x.trim() : ''
      if (s.length > 0 && !hits.includes(s)) hits.push(s)
      if (hits.length >= max) break
    }
    return hits
  } catch {
    return extractCandidatesByRules(texts, max)
  }
}

async function collectCandidatesAsync(deps: NudgeDeps): Promise<string[]> {
  if (deps.policy.nudge.candidate_extraction === 'llm') {
    return extractCandidatesByLlm(deps, recentUserTexts(deps))
  }
  return collectCandidates(deps)
}

// ── review collection ────────────────────────────────────────────────

function collectTemporalReviews(deps: NudgeDeps): ReviewItem[] {
  const items: ReviewItem[] = []
  const policy = deps.policy
  const now = deps.now

  for (const m of deps.store.listByAspectStatus('progressive', 'active', deps.scope)) {
    if (expireCheck(policy, m, now) === 'expired') continue
    if (!renewalDue(policy, m, now)) continue
    const ttl = policy.aspects.progressive.default_ttl_days ?? 7
    const ageDays = Math.floor((now - m.createdAt) / DAY_MS)
    if (m.anchor.type === 'none' || m.telicity === 'unbounded') {
      items.push({
        type: 'renewal',
        memoryId: m.id,
        text: `[renewal:${m.id}] ${m.content.slice(0, 80)} —— 已存在 ${ageDays} 天（TTL ${ttl} 天）：仍在进行→续期；已结束→转完成体（perfect）。`,
      })
    } else {
      items.push({
        type: 'expiry_suggest',
        memoryId: m.id,
        text: `[expiry_suggest:${m.id}] ${m.content.slice(0, 80)} —— 有效期内注入，到期自动抑制：端点临近请确认→结束转完成体 / 延长区间（续期）。`,
      })
    }
  }

  const reviewEvery = policy.aspects.prospective.review_every_turns ?? 30
  for (const m of deps.store.listByAspectStatus('prospective', 'active', deps.scope)) {
    const lastReviewed = (m.metadata?.last_reviewed_turn as number | undefined) ?? 0
    const predictBy = m.metadata?.predict_by as string | undefined
    let due = false
    let periodic = false
    let branch = ''
    if (m.modality === 'prediction') {
      if (predictBy) {
        if (deps.now >= Date.parse(predictBy)) {
          due = true
          branch = `预测已到判定日（${predictBy}）：已实现→转完成体；未实现→证伪删除；仍存疑→延长判定日。`
        } else if (deps.turnCount - lastReviewed >= reviewEvery) {
          due = true
          periodic = true
          const leftDays = Math.ceil((Date.parse(predictBy) - deps.now) / DAY_MS)
          branch = `预测中：判定日 ${predictBy}（约剩 ${leftDays} 天）—— 请确认预测是否仍成立。`
        }
      } else if (deps.turnCount - lastReviewed >= reviewEvery) {
        due = true
        periodic = true
        branch = '预测未带判定日（policy 要求 prediction 必带 predict_by）：请补判定日或转其他 modality。'
      }
    } else {
      if (deps.turnCount - lastReviewed >= reviewEvery) {
        due = true
        periodic = true
        if (m.modality === 'intention') {
          branch = '意图复审三问：实现→转完成体；放弃→转完成体（曾计划也是历史事实）；继续→保留。'
        } else if (m.modality === 'plan') {
          branch = '计划复审：完成→转完成体；修订→更新内容；继续→保留。'
        } else {
          branch = '复审：保留 / 转完成体 / 删除。'
        }
      }
    }
    if (!due) continue
    items.push({
      type: 'prospective',
      memoryId: m.id,
      text: `[prospective:${m.id}] ${m.content.slice(0, 80)} —— ${branch}`,
    })
    if (periodic) {
      deps.store.updateMemory?.(m.id, {
        metadata: { ...(m.metadata ?? {}), last_reviewed_turn: deps.turnCount },
      })
    }
  }

  // Activated plans (prospective → progressive) keep their deadline as
  // metadata.verdict_due; surface a verdict review once it passes (B1).
  for (const m of deps.store.listByAspectStatus('progressive', 'active', deps.scope)) {
    const vd = m.metadata?.verdict_due
    if (typeof vd !== 'string' || Number.isNaN(Date.parse(vd))) continue
    if (deps.now < Date.parse(vd)) continue
    items.push({
      type: 'verdict',
      memoryId: m.id,
      text: `[verdict:${m.id}] ${m.content.slice(0, 80)} —— 判定日 ${vd} 已到：实现→完成；未实现→软删；存疑→延长。`,
    })
  }

  // Uncertain fallback: always surface for reclassification (B2).
  for (const m of deps.store.listByAspectStatus('uncertain', 'active', deps.scope)) {
    items.push({
      type: 'uncertain',
      memoryId: m.id,
      text: `[uncertain:${m.id}] ${m.content.slice(0, 80)} —— 无法归类：请给出体/锚归类，或保持兜底（不影响检索）。`,
    })
  }
  return items
}

function collectConflictReviews(deps: NudgeDeps): ReviewItem[] {
  const items: ReviewItem[] = []
  for (const aspect of ['progressive', 'perfect', 'prospective', 'gnomic', 'uncertain'] as Aspect[]) {
    for (const m of deps.store.listByAspectStatus(aspect, 'suppressed', deps.scope)) {
      let peerText: string | null = null
      for (const link of deps.store.listLinksOf(m.id)) {
        if (link.rel !== 'contradicts') continue
        const peerId = link.src === m.id ? link.dst : link.src
        const peer = deps.store.getMemory?.(peerId) ?? null
        if (peer) { peerText = peer.content.slice(0, 80); break }
      }
      const why = peerText ? `被新事实「${peerText}」剪断（contradicts）` : '被证据抑制（无 contradicts 边详情）'
      items.push({
        type: 'conflict',
        memoryId: m.id,
        text: `[conflict:${m.id}] ${m.content.slice(0, 80)} —— ${why}：恢复（提权）或确认（保持抑制）。`,
      })
    }
  }
  // Both sides still active: β parked the new fact. Surface it so the user can
  // decide (update/delete/restore) instead of silently injecting both.
  for (const pair of deps.store.listActiveContradictions?.(deps.scope) ?? []) {
    const a = deps.store.getMemory?.(pair.src)
    const b = deps.store.getMemory?.(pair.dst)
    if (!a || !b) continue
    items.push({
      type: 'conflict_active',
      memoryId: b.id,
      text: `[conflict_active:${a.id}|${b.id}] 「${a.content.slice(0, 60)}」与「${b.content.slice(0, 60)}」都处于 active：确认保留哪条，另一条用 memory_delete 软删或 memory_update 修正。`,
    })
  }
  return items
}

// ── text rendering ───────────────────────────────────────────────────

function renderPolicySummary(policy: Policy): string[] {
  const lines: string[] = []
  lines.push(`[记忆维护提醒] 依据 policy v${policy.policy_version}（条款见 memory/policy.yaml）`)
  const prog = policy.aspects.progressive
  const perf = policy.aspects.perfect
  const pros = policy.aspects.prospective
  lines.push('- 三体映射：')
  lines.push(`  progressive: storage=${prog.storage} · injection=${prog.injection}（有效期内注入，过期即抑制） · expiry=${prog.expiry} · renewable=${prog.renewable ?? false} · TTL=${prog.default_ttl_days ?? 7} 天`)
  lines.push(`  perfect: injection=${perf.injection}（检索注入，永不主动过期）`)
  lines.push(`  prospective: injection=${pros.injection}（不注入，nudge 周期复审）`)
  lines.push(`- 门控要点：允许类别 ${policy.gate.allowed_categories.join(' / ')}；progressive 拒绝 ${policy.gate.forbidden_progressive.join(' / ')}（黑名单语义：不入注入层，可转 perfect 检索）`)
  return lines
}

export function renderNudgeText(opts: {
  policy: Policy
  reviewItems: ReviewItem[]
  candidates: string[]
  turnCount: number
  now: number
  sessionStartTs: number
}): string {
  const lines: string[] = []
  lines.push('<system-reminder>')
  lines.push(...renderPolicySummary(opts.policy))

  if (opts.reviewItems.length > 0) {
    lines.push('')
    lines.push('时间性复审问询（逐条回答：续期/删除/实现/放弃/继续/恢复/确认）：')
    for (const item of opts.reviewItems) lines.push(`  - ${item.text}`)
  }

  if (opts.candidates.length > 0) {
    lines.push('')
    lines.push('本窗口候选记忆（供确认，写入仍过门控）：')
    for (const c of opts.candidates) lines.push(`  - ${c.slice(0, 120)}`)
  }

  if (opts.policy.nudge.include_session_timeline) {
    const spanH = Math.max(1, Math.round((opts.now - opts.sessionStartTs) / 3_600_000))
    lines.push('')
    lines.push(`会话时间轴：开始于 ${new Date(opts.sessionStartTs).toISOString()}，当前 ${new Date(opts.now).toISOString()}（跨度约 ${spanH}h / 共 ${opts.turnCount} 轮）`)
  }
  lines.push('</system-reminder>')
  return lines.join('\n')
}

// ── prediction auto-resolve (`policy.nudge.auto_resolve_prediction`) ──
//
// Opt-in. When enabled, predictions at/after their predict_by date are
// adjudicated mechanically on each nudge tick instead of being queued as a
// review question:
//   fulfilled  → aspect=perfect (完成体归档), verdict recorded in metadata
//   refuted    → soft delete (row retained), verdict recorded first
//   uncertain  → predict_by extended by AUTO_RESOLVE_EXTEND_DAYS (no data loss)
// LLM unavailable / JSON parse failure / missing write hooks → 'uncertain'
// (conservative: never delete on insufficient evidence).

export type PredictionVerdict = 'fulfilled' | 'refuted' | 'uncertain'

export interface ResolveAction {
  memoryId: string
  verdict: PredictionVerdict
  action: 'perfect' | 'soft_delete' | 'extend'
}

const AUTO_RESOLVE_EXTEND_DAYS = 7

/** Due verdicts: prospective predictions at predict_by, plus activated plans
 *  (progressive) at metadata.verdict_due. */
function duePredictions(deps: NudgeDeps): Memory[] {
  const out: Memory[] = []
  for (const m of deps.store.listByAspectStatus('prospective', 'active', deps.scope)) {
    if (m.modality !== 'prediction') continue
    const predictBy = m.metadata?.predict_by as string | undefined
    if (!predictBy || Number.isNaN(Date.parse(predictBy))) continue
    if (deps.now >= Date.parse(predictBy)) out.push(m)
  }
  for (const m of deps.store.listByAspectStatus('progressive', 'active', deps.scope)) {
    const vd = m.metadata?.verdict_due as string | undefined
    if (!vd || Number.isNaN(Date.parse(vd))) continue
    if (deps.now >= Date.parse(vd)) out.push(m)
  }
  return out
}

/** Evidence lookup keywords: ASCII words (≥4) + CJK bigrams (C7). */
export function predictionKeywords(text: string): string[] {
  const out: string[] = []
  for (const w of text.toLowerCase().split(/[^a-z0-9]+/)) {
    if (w.length >= 4 && !/^\d+$/.test(w)) out.push(w)
  }
  for (const chunk of text.match(/[\u4e00-\u9fff]+/g) ?? []) {
    if (chunk.length >= 2) {
      for (let i = 0; i + 2 <= chunk.length && i < 4; i++) out.push(chunk.slice(i, i + 2))
    }
  }
  return [...new Set(out)].slice(0, 6)
}

/**
 * Evidence channel for prediction verification (C7): injectable provider
 * wins (tests/runner); default = conversation FTS on keywords + linked
 * memory evidence (supports/contradicts/refines/...).
 */
export async function evidenceForPrediction(deps: NudgeDeps, m: Memory): Promise<string[]> {
  if (deps.evidenceFor) return (await deps.evidenceFor(m)).slice(0, 8)
  const out: string[] = []
  const seen = new Set<string>()
  if (deps.store.searchConversations) {
    for (const kw of predictionKeywords(m.content)) {
      for (const hit of deps.store.searchConversations(kw, 3)) {
        if (!seen.has(hit.content)) {
          seen.add(hit.content)
          out.push(hit.content)
        }
      }
      if (out.length >= 8) break
    }
  }
  for (const link of deps.store.listLinksOf(m.id)) {
    if (out.length >= 8) break
    const peerId = link.src === m.id ? link.dst : link.src
    const peer = deps.store.getMemory?.(peerId)
    if (peer && !seen.has(peer.content)) {
      seen.add(peer.content)
      out.push(`[${link.rel}] ${peer.content}`)
    }
  }
  return out
}

async function verdictFor(deps: NudgeDeps, m: Memory): Promise<PredictionVerdict> {
  if (!deps.llm) return 'uncertain'
  const evidence = await evidenceForPrediction(deps, m)
  const evidenceBlock = evidence.length > 0 ? evidence.map((e) => `- ${e.slice(0, 200)}`).join('\n') : '（无证据）'
  try {
    const r = await deps.llm.call({
      model: deps.policy.nudge.llm_model ?? deps.policy.llm.model_classify,
      system:
        '你是预测验证器。给定一条预测记忆、判定日与相关证据，判断预测是否已实现。' +
        '只输出 JSON：{"verdict":"fulfilled"|"refuted"|"uncertain","reason":"..."}。' +
        '必须只依据给定证据判断；证据为空或不足以证明已实现/已证伪时，必须输出 uncertain。',
      user: `预测内容：${m.content}\n判定日：${(m.metadata?.predict_by ?? m.metadata?.verdict_due ?? '') as string}\n相关证据：\n${evidenceBlock}`,
      json: true,
      maxTokens: 1024,
    })
    const v = (r.json as { verdict?: unknown } | null)?.verdict
    return v === 'fulfilled' || v === 'refuted' || v === 'uncertain' ? v : 'uncertain'
  } catch {
    return 'uncertain'
  }
}

export async function resolvePredictionDues(deps: NudgeDeps): Promise<ResolveAction[]> {
  if (deps.policy.nudge.auto_resolve_prediction !== true) return []
  if (!deps.store.updateMemory) return []
  const actions: ResolveAction[] = []
  for (const m of duePredictions(deps)) {
    const verdict = await verdictFor(deps, m)
    const metadata = { ...(m.metadata ?? {}) }
    const resolvedAt = new Date(deps.now).toISOString()
    const activated = m.aspect === 'progressive'
    if (verdict === 'fulfilled') {
      const updated = deps.store.updateMemory(m.id, {
        aspect: 'perfect',
        ...(activated ? { anchor: { type: 'point', start: resolvedAt.slice(0, 10) } } : {}),
        metadata: {
          ...metadata,
          verdict: 'fulfilled',
          resolved_by: 'nudge-auto',
          resolved_at: resolvedAt,
          ...(activated ? { completed_at: resolvedAt, completed_from: 'prospective', completion_reason: 'fulfilled' } : {}),
        },
      })
      deps.store.emit?.('prediction.fulfilled', m.id, { memoryId: m.id })
      actions.push({ memoryId: m.id, verdict, action: updated ? 'perfect' : 'extend' })
    } else if (verdict === 'refuted') {
      deps.store.updateMemory(m.id, {
        metadata: { ...metadata, verdict: 'refuted', resolved_by: 'nudge-auto', resolved_at: resolvedAt },
      })
      const ok = deps.store.softDelete?.(m.id) ?? false
      deps.store.emit?.('prediction.refuted', m.id, { memoryId: m.id })
      actions.push({ memoryId: m.id, verdict, action: ok ? 'soft_delete' : 'extend' })
    } else {
      const newDue = new Date(deps.now + AUTO_RESOLVE_EXTEND_DAYS * DAY_MS).toISOString()
      deps.store.updateMemory(m.id, {
        metadata: {
          ...metadata,
          verdict: 'uncertain',
          resolved_by: 'nudge-auto',
          resolved_at: resolvedAt,
          ...(activated ? { verdict_due: newDue } : { predict_by: newDue }),
        },
      })
      deps.store.emit?.('prediction.extended', m.id, { memoryId: m.id, due: newDue })
      actions.push({ memoryId: m.id, verdict, action: 'extend' })
    }
  }
  return actions
}

/**
 * Uncertain fallback reclassification (B2, opt-in `auto_reclassify_uncertain`):
 * LLM classifier (rules fallback inside buildClassifyFn); failure/uncertain
 * keeps the fallback bucket — never drops data.
 */
export async function resolveUncertainDues(deps: NudgeDeps): Promise<number> {
  if (deps.policy.nudge.auto_reclassify_uncertain !== true) return 0
  if (!deps.llm || !deps.store.updateMemory) return 0
  const classifyFn = buildClassifyFn(deps.policy, deps.llm)
  let reclassified = 0
  for (const m of deps.store.listByAspectStatus('uncertain', 'active', deps.scope)) {
    try {
      const r = await classifyFn({ now: new Date(deps.now), text: m.content })
      if (!r) continue
      const target = r.aspect
      const anchor = r.anchor && r.anchor.type !== 'none' ? r.anchor : m.anchor
      deps.store.updateMemory(m.id, {
        aspect: target,
        anchor,
        metadata: {
          ...(m.metadata ?? {}),
          reclassified_to: target,
          reclassified_at: new Date(deps.now).toISOString(),
          reclassify_evidence: 'nudge-llm',
        },
      })
      deps.store.emit?.('memory.transition', m.id, {
        from: 'uncertain',
        to: target,
        at: new Date(deps.now).toISOString(),
        reason: 'reclassify',
        evidence: 'nudge-llm',
      })
      reclassified += 1
    } catch {
      /* keep fallback */
    }
  }
  return reclassified
}

// ── main entry ───────────────────────────────────────────────────────

export function buildNudge(deps: NudgeDeps): NudgeResult {
  const every = deps.policy.nudge.every_turns
  if (every <= 0 || deps.turnCount <= 0 || deps.turnCount % every !== 0) {
    return { trigger: false, text: null, reviewItems: [] }
  }
  return buildNudgeCore(deps, collectCandidates(deps))
}

export async function buildNudgeAsync(deps: NudgeDeps): Promise<NudgeResult> {
  const every = deps.policy.nudge.every_turns
  if (every <= 0 || deps.turnCount <= 0 || deps.turnCount % every !== 0) {
    return { trigger: false, text: null, reviewItems: [] }
  }
  // Auto-resolve first so newly adjudicated memories drop out of the review
  // queue before review items are collected.
  await resolvePredictionDues(deps)
  await resolveUncertainDues(deps)
  return buildNudgeCore(deps, await collectCandidatesAsync(deps))
}

function buildNudgeCore(deps: NudgeDeps, candidates: string[]): NudgeResult {
  const reviewItems: ReviewItem[] = []
  if (deps.policy.nudge.review_temporal) reviewItems.push(...collectTemporalReviews(deps))
  if (deps.policy.nudge.review_conflicts) reviewItems.push(...collectConflictReviews(deps))

  const text = renderNudgeText({
    policy: deps.policy,
    reviewItems,
    candidates,
    turnCount: deps.turnCount,
    now: deps.now,
    sessionStartTs: deps.sessionStartTs,
  })
  return { trigger: true, text, reviewItems }
}

// ── dsh scheduler shell (loose types; compiles without dsh) ──────────

export interface NudgePluginOptions {
  store: NudgeStore
  policy: Policy
  sessionIdOf?: (session: unknown) => string | undefined
  hook?: string
  llm?: LlmLike
  clock?: ClockLike
}

export class NudgePlugin {
  private turnCount = 0
  private sessionStartTs: number | undefined
  private lastNudgedTurn = -1
  private recentUserTexts: string[] = []
  private lastSessionId: string | undefined
  private clock: Clock

  constructor(private opts: NudgePluginOptions) {
    this.clock = normalizeClock(opts.clock ?? systemClock)
  }

  attach(ctx: unknown): () => void {
    const c = ctx as { on?: (ev: string, fn: (...args: unknown[]) => unknown) => unknown }
    if (!c?.on) {
      throw new Error('NudgePlugin.attach 需要 dsh ctx（含 on 方法）；无 dsh 环境请用 onSessionEvent/maybeNudge 手动驱动')
    }
    const disposers: Array<() => void> = []
    const onEvent = c.on('session/event', (...args: unknown[]) => this.onSessionEvent(args[1], args[0]))
    if (typeof onEvent === 'function') disposers.push(onEvent as () => void)
    const onPreStep = c.on(this.opts.hook ?? 'agent/pre-step', (...args: unknown[]) =>
      this.maybeNudge(args[0], args[1] as () => Promise<unknown>),
    )
    if (typeof onPreStep === 'function') disposers.push(onPreStep as () => void)
    return () => {
      for (const d of disposers) {
        try {
          d()
        } catch {
          /* ignore cleanup errors */
        }
      }
    }
  }

  onSessionEvent(event: unknown, session?: unknown): void {
    const e = event as { type?: string; data?: unknown }
    if (this.sessionStartTs === undefined) this.sessionStartTs = this.clock.now()
    if (e?.type === 'turn/end') {
      this.turnCount++
      this.lastSessionId = this.opts.sessionIdOf?.(session)
    } else if (e?.type === 'user/message') {
      this.lastSessionId = this.opts.sessionIdOf?.(session) ?? this.lastSessionId
      const data = e.data as { content?: Array<{ type?: string; text?: string }> } | undefined
      for (const block of data?.content ?? []) {
        if (block?.type === 'text' && block.text !== undefined) {
          this.recentUserTexts.push(block.text)
          if (this.recentUserTexts.length > 20) this.recentUserTexts.shift()
        }
      }
    }
  }

  async maybeNudge(payload: unknown, next: () => Promise<unknown>): Promise<unknown> {
    const decision = await next()
    const d = decision as { kind?: string; messages?: unknown[] } | null
    if (!d || d.kind === 'reject' || !Array.isArray(d.messages)) return decision
    const p = payload as { step?: number; messages?: unknown[] }
    if (p?.step !== 1) return decision

    const every = this.opts.policy.nudge.every_turns
    const due = every > 0 && this.turnCount > 0 && this.turnCount % every === 0 && this.turnCount !== this.lastNudgedTurn
    if (!due) return decision
    this.lastNudgedTurn = this.turnCount

    const now = this.clock.now()
    const result = await buildNudgeAsync({
      store: this.opts.store,
      policy: this.opts.policy,
      now,
      turnCount: this.turnCount,
      sessionStartTs: this.sessionStartTs ?? now,
      sessionId: this.lastSessionId,
      scope: 'global',
      llm: this.opts.llm,
    })
    if (!result.trigger || !result.text) return decision

    // dsh 0.2.x v4 sessions require an identified message with a
    // producer-owned source kind; the retired shared `plugin` kind is rejected
    // by the durable encoder, and a missing id breaks session restore.
    const nudgeMessage = {
      id: randomUUID(),
      role: 'user',
      content: [{ type: 'text', text: result.text }],
      source: { kind: 'plugin:foresight-nudge', form: 'notice', summary: '记忆维护提醒：续期/意图复审/冲突复核' },
    }
    const claimed = d.messages.findLastIndex((m: unknown) => (p.messages as unknown[] | undefined)?.includes(m))
    this.opts.store.emit?.('nudge.inject', null, { turn: this.turnCount, items: result.reviewItems.map((i) => i.type) })
    return {
      kind: 'enter',
      messages: d.messages.toSpliced(claimed + 1, 0, nudgeMessage),
    }
  }
}

// ── cordis plugin entry (dsh loader convention: name + apply) ────────

export const name = 'foresight-nudge'
export const inject = ['foresight']

/** dsh assembly: construct NudgePlugin from ctx.foresight and attach. */
export function apply(ctx: unknown): () => void {
  const fsight = (ctx as { foresight?: { store?: NudgeStore; policy?: Policy; llm?: LlmLike; clock?: ClockLike } }).foresight
  if (!fsight?.store || !fsight.policy) {
    throw new Error('foresight-nudge 需要 foresight 服务（@foresight/memory 主插件）')
  }
  const plugin = new NudgePlugin({
    store: fsight.store,
    policy: fsight.policy,
    llm: fsight.llm,
    clock: fsight.clock,
    sessionIdOf: (session) => {
      if (session && typeof session === 'object' && 'id' in session) {
        const id = (session as { id: unknown }).id
        if (id !== undefined && id !== null) return String(id)
      }
      return undefined
    },
  })
  return plugin.attach(ctx)
}
