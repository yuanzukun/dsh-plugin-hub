---
name: kicad-agent-workflow
description: Step-by-step loop for changing a KiCad schematic with the kicad_* tools — read, plan, one atomic edit batch, KiCad ERC verdict, iterate, render to check visually.
---

# KiCad agent workflow

Use this loop for any schematic change. KiCad, not you, decides whether the result is electrically correct.

1. **Locate the design.** The prompt context lists the KiCad files in the working directory. The root schematic has the same name as the `.kicad_pro`.
2. **Read.** `kicad_read_schematic` for the inventory (references, values, lib_ids, positions, labels, power nets). `kicad_list_nets` shows what is actually connected. `kicad_get_symbol_pins` gives exact pin positions and names before you wire.
3. **Pick parts.** `kicad_search_symbols` with plain keywords (`"ldo 3.3"`, `"usb c receptacle"`, `"ne555"`). Use the returned `lib_id` verbatim. `kicad_library_symbol` shows a part's pins and default footprint before you place it; `kicad_search_footprints` finds or confirms footprints (with pad names). Do not parse library files with shell commands.
4. **Plan placement.** For a design with several functions, lay it out as titled functional blocks (one frame per job, blocks joined only by labels and power symbols; see the `kicad-schematic-design` skill) and place each part inside its block's area. Place new parts in free space next to what they connect to, turned so the pins you will wire face each other (a pull-up beside the MCU pin it serves, the LED's resistor in line with the LED, decoupling beside the power pin): keep 10–15 mm between parts, everything on the 1.27 mm grid (multiples of 2.54 mm are tidiest). Y grows downward. Rotation is counter-clockwise: two-pin parts (Device:R/C/L) at 0° are vertical with pin 1 on top, at 90° horizontal with pin 1 on the left — for left-to-right signal flow use 90°.
5. **Edit once.** Put the whole change in one `kicad_edit_schematic` call — it is atomic. Use `"R?"` references to auto-number. Draw the circuit with wires: `connect_pins` for each connection between parts that work together (it routes around parts, labels and other nets; a net with several pins is a chain A–B, B–C, and a wire may join one already on the pin, with a junction). Supply rails get power symbols (`connect_pin_to_net` with `kind: "power"`; one per wired group is enough). Net labels are for connections between blocks or across the page, never for two parts side by side. If a `connect_pins` result carries a `note` about a detour, move, rotate or mirror a part so the pins face each other, or use labels for that net. Mark intentionally unused pins with `no_connect_pin`. Keep a batch to about 20 operations; split larger changes into several calls.
6. **Fix, don't rebuild.** To change something already placed, use `disconnect_pin` (removes the stub wire, label, power symbol or no-connect on a pin), `remove_item` with a uuid from `kicad_read_schematic` (`include_wiring: true`), `remove_symbol` or `move_symbol`, then re-add. To move a part together with its wires, labels and power symbols use `move_symbols`; to move a whole framed block, `move_block`. Never recreate the schematic file or edit its text with shell/file tools.
7. **Read the verdict.** The edit result ends with an automatic KiCad ERC. If it failed, fix the reported items (see the `kicad-erc-triage` skill) with another batch. Never claim success while ERC reports errors.
8. **Check visually when layout matters.** `kicad_render` writes SVG (and PNG for image-capable models) under `.dsh-kicad/render/`; the user sees it in the KiCad sidebar tab.
9. **Board work.** `kicad_read_pcb` shows the outline, footprints (position, side, courtyard, pad nets), rules and the unrouted count; change the board with one `kicad_edit_pcb` batch (outline, placement, rules and net classes, tracks routed pad to pad with `"REF:PAD"` endpoints, vias, zones, keepouts, silkscreen) and read the DRC verdict appended to it. `kicad_drc` with `schematic_parity: true` after schematic changes. Routing, once every part is placed: route critical nets by hand (power, USB/differential pairs, crystal) with `add_track`/`add_via` and `locked: true`, add a GND pour (`add_zone` on both copper layers, `connect_pads: "solid"`), then `kicad_autoroute` routes the rest without touching locked or existing copper and refills the pour. If it says Freerouting or Java is missing, pass its install advice to the user.

Report to the user: what changed (from the edit result's change list), the final ERC verdict, and anything left for them (footprint choices, layout).

## Handing over to the board

Start board work (syncing the schematic to a `.kicad_pcb`) only when both hold; otherwise finish the schematic first:

1. **0 ERC errors.** `kicad_erc` on the root schematic; explain any remaining warnings.
2. **Every symbol that goes on the board has a footprint.** Check the BOM (`kicad_export` kind `bom`, Footprint column) or `kicad_read_schematic` (`footprint` of each component; power symbols and `on_board: false` parts need none). Fill gaps with `set_footprint`, using `kicad_search_footprints` with pads so the pad names match the symbol's pin numbers.

Then sync (`kicad_update_pcb` when this session has it, otherwise the user runs Update PCB from Schematic in KiCad), and check the board with `kicad_drc` and `schematic_parity: true`. Parity is clean only when the report has no `schematic_parity` items (KiCad lists them as warnings). Triage the rest with the `kicad-drc-triage` skill.
