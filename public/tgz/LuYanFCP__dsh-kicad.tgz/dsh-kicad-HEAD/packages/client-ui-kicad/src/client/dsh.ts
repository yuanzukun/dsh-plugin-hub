/**
 * The dsh Web Client surface this plugin uses, typed structurally. dsh asks
 * third-party Client plugins not to import its Client packages, so the shapes
 * live here: when dsh changes one of them, this file is the adaptation point.
 * Verified against dsh 0.2.1-rc.2.
 */
import type { ComponentType } from 'react'

export interface RemoteFailure { message: string, code: string }
export type RemoteResult<T> = { ok: true, value: T } | { ok: false, error: RemoteFailure }

export interface WorkspaceFileBytes { absolutePath: string, version: string, data: Uint8Array, eof: boolean, bytes?: number, offset?: number }
/** `{}` reads the whole file (dsh caps that at 32 MiB); `range` reads one window of at most 2 MiB. */
export interface WorkspaceByteReadOptions { range?: { offset?: number, length?: number } }
export interface WorkspaceDirectoryListing {
  absolutePath: string
  entries: Array<{ name: string, type: 'file' | 'directory' | 'other', size?: number }>
  truncated?: boolean
}
export interface CommandExecution { result: { kind: 'success', text?: string } | { kind: 'error', text: string } }
/** One row of `remote.session.list` (dsh-api-session-controller SessionSummary, fields this plugin reads). */
export interface SessionSummary { sessionId: string, updatedAt: number, agentAvailable: boolean, blank?: boolean, origin?: 'subagent', cwd?: string }

export interface ClientRemote {
  workspaceFiles: {
    readBytes(sessionId: string, path: string, options: WorkspaceByteReadOptions, signal?: AbortSignal): Promise<RemoteResult<WorkspaceFileBytes>>
    list(sessionId: string, path: string, signal?: AbortSignal): Promise<RemoteResult<WorkspaceDirectoryListing>>
  }
  commands: {
    execute(sessionId: string, line: string, attachments: unknown[]): Promise<RemoteResult<CommandExecution | undefined>>
  }
  /** Session Controller; used only to find a session for machine-wide commands from session-less pages. */
  session?: {
    list(request: { cursor?: string }): Promise<RemoteResult<{ items: readonly SessionSummary[] }>>
  }
}

export interface SlotRegistration {
  name: string
  key?: string
  id?: string
  order?: number
  locale?: string
  inject?: (...args: never[]) => unknown
}

export interface ClientContext {
  effect(factory: () => () => void, label?: string): void
  slots: {
    inject(owner: string, register: () => () => void): () => void
    register(options: SlotRegistration, component: ComponentType<never>): () => void
  }
  sidebarRightTabs: {
    register(definition: {
      id: string
      kind: string
      patterns?: string[]
      priority?: 'extension' | 'builtin' | 'fallback'
      canOpen?(address: string): boolean
      title(address: string): string
    }): () => void
  }
  locale: { register(ns: string, dictionaries: Record<string, Record<string, string>>): () => void }
  remote: ClientRemote
}

/** Live value of a `dsh-resource://` address (the `useResource` standard prop). */
export interface ResourceState<V> { status: 'none' | 'loading' | 'live' | 'failed', value?: V }
export type UseResource = <V = { absolutePath: string, version: string }>(address: string) => ResourceState<V>

export interface TabInfo {
  tab: { id: string, contentId?: string, visible?: boolean, signal: AbortSignal }
}

/** Props the right-sidebar keyed tab seat passes to a body. */
export interface TabBodyProps {
  useTabInfo: () => TabInfo
  useResource?: UseResource
  sessionId?: string
  t?: (key: string, vars?: Record<string, string | number>) => string
}

/** Props of one atomic tool view in `tool.call.toolview`. */
export interface ToolViewProps {
  toolName: string
  callId: string
  phase: 'preparing' | 'start' | 'result'
  block: {
    /** Lazy argument view (dsh PartialArguments): `text(key)` reads a string field, even while arguments stream in. */
    args?: { text?(key: string): string | undefined }
    call?: { name: string, argsRaw: string } | null
    /** Raw JSON arguments of a dispatched call (start phase). */
    argsRaw?: string
    /** Unix epoch ms of the call or result event (tells live calls from replayed history). */
    time?: number
    content?: ReadonlyArray<{ type: string, text?: string }>
    isError?: boolean
    meta?: unknown
  }
  cwd?: string
  /** Present when the slot owner supplies it; the KiCad commands are machine-wide, so any session works. */
  sessionId?: string
  openFile?: (path: string, options?: { line?: number }) => void
  t?: (key: string, vars?: Record<string, string | number>) => string
}

/** Props of one `conversation.chat.commandview` row (dsh-client-ui-conversation CommandNode, fields this plugin reads). */
export interface CommandRowProps {
  node: {
    name: string | null
    /** Text after the command name; null when the command does not record it. */
    args: string | null
    /** null while the command is still running. */
    outcome: { kind: 'success' | 'error', text?: string } | null
  }
  t?: (key: string, vars?: Record<string, string | number>) => string
}

/** Props of a `plugins.row.config` page. */
// The page has no session: the bridge page borrows one through `remote.session` for /kicad-doctor.
export interface ConfigViewProps {
  view: 'summary' | 'page'
  form?: {
    state: { status: 'loading' | 'ready' | 'unavailable', value: Record<string, unknown> | undefined, revision: number | undefined, writable: boolean }
    mutate(ops: ReadonlyArray<{ op: 'set', path: string[], value: unknown } | { op: 'unset', path: string[] }>, expectedRevision?: number): Promise<boolean>
  }
  t?: (key: string, vars?: Record<string, string | number>) => string
}
