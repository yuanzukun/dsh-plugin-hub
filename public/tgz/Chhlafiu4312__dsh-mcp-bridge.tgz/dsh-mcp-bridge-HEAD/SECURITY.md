# Security

`dsh-mcp-bridge` runs third-party MCP servers as child processes **with your
permissions**. Treat every server you configure the way you would treat a
program you download and run yourself.

## What the bridge does (and does not do)

- It spawns exactly the commands you configure — nothing else.
- It speaks JSON-RPC 2.0 over the server's stdio; no network listener is opened.
- `url` servers are bridged through the community-standard `mcp-remote` tool
  (`npx -y mcp-remote <url>`); the URL is contacted by that tool, not by this
  plugin directly.
- It never uploads data anywhere. Logs go to the harness log only.

## Recommendations

1. **Only connect servers you trust.** A malicious MCP server is arbitrary
   code execution — same risk as installing any npm package globally.
2. **Scope the filesystem server.** Pass only the directories the agent may
   touch:
   `npx -y @modelcontextprotocol/server-filesystem /allowed/path /other/path`.
3. **Keep secrets out of logs and configs.** API tokens travel through the
   `env` field of a server entry. Prefer a secret manager, and never commit
   real tokens to a repository. Stderr tails (kept for diagnostics, last 2 KB)
   are logged on process exit — a server that echoes its token to stderr
   would expose it there.
4. **Pin what you can.** `npx -y <pkg>` always fetches the latest version.
   For sensitive workflows, prefer versioned installs or a locked lockfile.
5. **Review before installing from a marketplace.** Community registries do
   not perform security reviews; listing is not endorsement.

## Reporting a vulnerability

Open an issue in the repository, or contact the maintainers directly. Please
do not publish a working exploit before a fix is available.
