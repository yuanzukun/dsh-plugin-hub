# Architecture

How a tool call travels from the model to an MCP server and back.

```
┌────────────────────────────── DeepSeek Harness ──────────────────────────────┐
│                                                                              │
│  model ──calls──▶ mcp_<server>_<tool> ──▶ tools registry ──▶ bridge plugin   │
│                                                        (harness.defineTool)  │
│                                                                              │
└──────────────────────────────────────┬───────────────────────────────────────┘
                                       │ JSON-RPC 2.0 over stdio (newline-delimited)
                                       ▼
                        ┌──────────────────────────────┐
                        │   managed child process       │
                        │  ┌─────────────────────────┐  │
                        │  │ stdio MCP server        │  │  npx <pkg> <args>
                        │  └─────────────────────────┘  │
                        │  ┌─────────────────────────┐  │
                        │  │ mcp-remote <url>        │  │  HTTP/SSE servers
                        │  │   └─▶ remote MCP server │  │
                        │  └─────────────────────────┘  │
                        └──────────────────────────────┘
```

## Connection lifecycle

1. **Spawn.** For each configured server, `subprocess.resolveExecutable`
   resolves the command, then `subprocess.spawn` starts it with
   `stdin/stdout/stderr` piped.
2. **Handshake.** `initialize` (protocol `2024-11-05`, empty client
   capabilities) followed by the `notifications/initialized` notification.
3. **Discovery.** `tools/list` returns the tool schemas; when the server
   declares the `resources` / `prompts` capabilities, `resources/list` and
   `prompts/list` are fetched too (a rejected list is treated as empty).
4. **Registration.** Each tool becomes a DSH tool named
   `mcp_<server>_<tool>`:
   - `description` — the server's description, prefixed with `[MCP:<id>]`;
   - `parameters` — the server's `inputSchema`, sanitized into the DSH
     parameter DSL;
   - `execute` — forwards `tools/call` and joins the returned text parts;
   - `output` — open JSON; the renderer prefers the joined text and falls
     back to pretty-printed JSON for empty text.
5. **Teardown.** `ctx.effect` disposes terminate the child process and the
   tool registrations when the plugin stops or updates.

## Schema sanitizer

DSH's `defineTool` accepts a restricted schema subset. The sanitizer walks
the MCP `inputSchema` and keeps `object`/`array`/scalar nodes with
`properties`, `items`, `required`, `enum`, `const`, and annotations
(`description`, `title`). Anything unsupported — `anyOf`, `$ref`, `format`,
unknown types — degrades to the open `json` type: the model sees a looser
contract, and the MCP server stays the authoritative validator of its own
input.

## Concurrency and cancellation

- Tool definitions opt into concurrency-safe scheduling; the JSON-RPC client
  multiplexes requests by id, so overlapping calls share one connection.
- Every request races the caller's `AbortSignal` and a 120 s cooperative
  timeout; settling either path rejects the pending request.
- Aborted calls forward `notifications/cancelled` with the pending request
  id, so cooperative servers can stop working; the local rejection follows.

## Error handling

- `isError` responses from the server surface as DSH tool failures carrying
  the server's text.
- A process exit is logged with its stderr tail (last 2 KB) and the server's
  status flips to `error` in `mcp_status`.
- Misconfigured server entries fail the plugin startup with a specific
  message instead of a downstream crash.

## Tool filtering

Per server, `allowTools` keeps only the named tools and `denyTools` removes
them (exact names, combinable). Filtering runs before registration, so hidden
tools never enter the DSH tools registry; resource/prompt bridge tools are
not affected.

## Timeouts

Every bridge request races a cooperative timeout — `server.timeoutMs` (or the
120 s default) — plus the caller's `AbortSignal`. The tool definitions declare
the same budget, so the DSH registry's own deadline enforcement stays in
agreement with the transport.
