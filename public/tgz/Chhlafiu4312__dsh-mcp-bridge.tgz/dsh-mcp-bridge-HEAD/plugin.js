// dsh-mcp-bridge — connect MCP servers to DeepSeek Harness.
//
// A zero-dependency MCP client bridge for DeepSeek Harness. Mount this module
// as a row in your agent preset (agent.cordis.yml) or run the same logic as a
// dynamic Cordis plugin (cordis_define). It:
//
//   * spawns every configured MCP server (stdio via command, or HTTP/SSE via
//     `npx mcp-remote <url>`),
//   * performs the MCP initialize/tools.list handshake over raw JSON-RPC 2.0,
//   * auto-registers every tool as `mcp_<server>_<tool>` on the DSH tools
//     registry so the model can call it directly,
//   * forwards calls through tools/call and renders text content back,
//   * terminates every child process when the plugin is stopped.
//
// Config: set DSH_MCP_SERVERS to a JSON array of server entries, or edit
// the defaults in resolveServers() below. See README.md and examples/servers.json.

let dshDefineTool = null
try {
  // Resolves when mounted inside DeepSeek Harness (bare specifiers resolve
  // from the harness). Absent in plain-node test runs, which use the raw
  // fallback below.
  dshDefineTool = (await import('@deepseek-ai/dsh-tools')).defineTool
} catch { /* not mounted in the harness */ }

// Fallback for environments with neither the sandbox `harness` nor dsh-tools
// (plain-node tests): pass the DSL parameters through untouched.
const rawDefineTool = (options) => ({
  name: options.name,
  description: options.description,
  parameters: options.parameters,
  output: options.output,
  timeoutMs: options.timeoutMs,
  isConcurrencySafe: options.isConcurrencySafe,
  async execute(args, exec) {
    return options.execute(args, exec)
  },
})

// In the dynamic-plugin sandbox the harness provides `harness.defineTool`
// (which marker-tags the definition); in a normal preset mount the real
// dsh-tools defineTool is used instead. Both accept the same DSL parameters.
const define = (typeof harness !== 'undefined' && harness && typeof harness.defineTool === 'function')
  ? harness.defineTool
  : (dshDefineTool || rawDefineTool)

// Resolve the server list on every apply so a plugin reload (HMR) picks up a
// changed DSH_MCP_SERVERS without a process restart.
function resolveServers() {
  const envJson = (typeof process !== 'undefined' && process.env && process.env.DSH_MCP_SERVERS) || ''
  if (envJson) {
    try {
      const parsed = JSON.parse(envJson)
      if (Array.isArray(parsed) && parsed.length > 0) return parsed
    } catch (error) {
      console.error('[mcp-bridge] DSH_MCP_SERVERS is not valid JSON; falling back to defaults:', error)
    }
  }
  const workspace = (typeof process !== 'undefined' && typeof process.cwd === 'function' && process.cwd()) || '/tmp'
  return [
    {
      id: 'filesystem',
      command: 'npx',
      args: ['-y', '@modelcontextprotocol/server-filesystem', workspace],
    },
  ]
}

export default {
  inject: ['subprocess', 'tools', 'timer'],
  apply(ctx) {
    const MCP_SERVERS = resolveServers()

    const sanitize = (name) => String(name).replace(/[^A-Za-z0-9_-]+/g, '_').replace(/^_+|_+$/g, '') || 'tool'

    // ---------- MCP JSON Schema -> unified parameter DSL ----------
    // Both defineTool flavors accept the Schemastery-style DSL. Unsupported
    // JSON-Schema nodes degrade to the open "json" type (the MCP server still
    // validates its own input).
    const SCALAR_TYPES = new Set(['string', 'number', 'integer', 'boolean', 'null'])
    const matchesType = (value, type) => {
      if (value === null) return type === 'null'
      if (type === 'string') return typeof value === 'string'
      if (type === 'number') return typeof value === 'number'
      if (type === 'integer') return typeof value === 'number' && Number.isInteger(value)
      if (type === 'boolean') return typeof value === 'boolean'
      return false
    }

    function dslValue(node, required) {
      const spec = {}
      const record = (node && typeof node === 'object' && !Array.isArray(node)) ? node : {}
      if (typeof record.description === 'string') spec.description = record.description
      if (typeof record.title === 'string') spec.title = record.title
      if (required) spec.required = true
      const type = (record.type === 'object' || record.type === 'array' || SCALAR_TYPES.has(record.type)) ? record.type : 'json'
      spec.type = type
      if (type === 'object') {
        spec.additionalProperties = record.additionalProperties === false ? false : true
        const rawProps = (record.properties && typeof record.properties === 'object' && !Array.isArray(record.properties)) ? record.properties : {}
        const requiredNames = new Set(Array.isArray(record.required)
          ? record.required.filter((name) => typeof name === 'string' && Object.prototype.hasOwnProperty.call(rawProps, name))
          : [])
        spec.properties = {}
        for (const key of Object.keys(rawProps)) spec.properties[key] = dslValue(rawProps[key], requiredNames.has(key))
      } else if (type === 'array') {
        spec.items = dslValue(record.items, false)
      } else if (type !== 'json') {
        if (Array.isArray(record.enum)) {
          const values = record.enum.filter((value) => matchesType(value, type))
          if (values.length > 0) spec.enum = values
        }
        if (record.const !== undefined && matchesType(record.const, type)) spec.const = record.const
      }
      return spec
    }

    function toParameterSpec(inputSchema) {
      const root = (inputSchema && typeof inputSchema === 'object' && !Array.isArray(inputSchema)) ? inputSchema : {}
      if (root.type !== 'object') return {} // open root; the MCP server validates
      const rawProps = (root.properties && typeof root.properties === 'object' && !Array.isArray(root.properties)) ? root.properties : {}
      const requiredNames = new Set(Array.isArray(root.required)
        ? root.required.filter((name) => typeof name === 'string' && Object.prototype.hasOwnProperty.call(rawProps, name))
        : [])
      const spec = {}
      for (const key of Object.keys(rawProps)) spec[key] = dslValue(rawProps[key], requiredNames.has(key))
      return spec
    }

    // ---------- Minimal JSON-RPC 2.0 client over stdio ----------
    function createClient(serverId, handle) {
      const pending = new Map()
      let nextId = 1
      let buffer = ''
      const decoder = new TextDecoder()

      // A dead process must never leave requests hanging until their timeout.
      handle.done.then(() => {
        const error = new Error('[mcp:' + serverId + '] connection closed')
        for (const entry of Array.from(pending.values())) entry.finish(entry.reject, error)
      })

      const writeLine = (line) => {
        try { handle.stdin.write(line + '\n') } catch { /* broken pipe — handle.done rejects the pending requests */ }
      }

      handle.stdout.on('data', (chunk) => {
        buffer += decoder.decode(chunk, { stream: true })
        let nl
        while ((nl = buffer.indexOf('\n')) >= 0) {
          const line = buffer.slice(0, nl).trim()
          buffer = buffer.slice(nl + 1)
          if (!line) continue
          let msg
          try { msg = JSON.parse(line) } catch { continue }
          if (msg && msg.id !== undefined && msg.id !== null) {
            const entry = pending.get(msg.id)
            if (!entry) continue
            if (msg.error) entry.finish(entry.reject, new Error('[mcp:' + serverId + '] ' + (msg.error.message || 'json-rpc error')))
            else entry.finish(entry.resolve, msg.result)
          }
          // server notifications (logging, progress) are ignored
        }
      })

      function request(method, params, timeoutMs, signal) {
        const id = nextId++
        return new Promise((resolve, reject) => {
          let settled = false
          let timer = null
          let onAbort = null
          const finish = (fn, value) => {
            if (settled) return
            settled = true
            pending.delete(id)
            if (timer) timer()
            if (onAbort && signal) signal.removeEventListener('abort', onAbort)
            fn(value)
          }
          timer = ctx.timeout(() => finish(reject, new Error('[mcp:' + serverId + '] timeout on ' + method + ' after ' + timeoutMs + 'ms')), timeoutMs)
          if (signal) {
            if (signal.aborted) { finish(reject, new Error('[mcp:' + serverId + '] ' + method + ' aborted')); return }
            onAbort = () => {
              // Ask the server to stop working; the local rejection follows.
              writeLine(JSON.stringify({ jsonrpc: '2.0', method: 'notifications/cancelled', params: { requestId: id, reason: 'aborted' } }))
              finish(reject, new Error('[mcp:' + serverId + '] ' + method + ' aborted'))
            }
            signal.addEventListener('abort', onAbort, { once: true })
          }
          pending.set(id, { finish, resolve, reject })
          writeLine(JSON.stringify({ jsonrpc: '2.0', id, method, params: params || {} }))
        })
      }

      function notify(method, params) {
        writeLine(JSON.stringify({ jsonrpc: '2.0', method, params: params || {} }))
      }

      return { request, notify }
    }

    // ---------- Spawn + MCP handshake ----------
    async function connectServer(server) {
      const command = server.url ? 'npx' : server.command
      const args = server.url ? ['-y', 'mcp-remote', server.url] : server.args
      const cwd = server.cwd || ((typeof process !== 'undefined' && typeof process.cwd === 'function' && process.cwd()) || '/tmp')
      const exe = await ctx.subprocess.resolveExecutable(command, server.env || undefined)
      const handle = ctx.subprocess.spawn({
        argv: [exe].concat(args),
        cwd,
        stdio: { stdin: 'pipe', stdout: 'pipe', stderr: 'pipe' },
        graceMs: 3000,
        env: server.env || undefined,
      })
      if (!handle.stdin) throw new Error('stdin is not piped')
      let stderrTail = ''
      if (handle.stderr) {
        const stderrDecoder = new TextDecoder()
        handle.stderr.on('data', (chunk) => {
          stderrTail = (stderrTail + stderrDecoder.decode(chunk, { stream: true })).slice(-2000)
        })
      }
      handle.done.then((outcome) => {
        console.log('[mcp:' + server.id + '] exited code=' + outcome.exitCode + ' signal=' + outcome.signal + (stderrTail ? '\nstderr: ' + stderrTail : ''))
      }).catch((error) => {
        console.error('[mcp:' + server.id + '] spawn failed:', error)
      })
      const client = createClient(server.id, handle)
      const init = await client.request('initialize', {
        protocolVersion: '2024-11-05',
        capabilities: {},
        clientInfo: { name: 'dsh-mcp-bridge', version: '0.6.0' },
      }, 30000)
      client.notify('notifications/initialized', {})
      const listed = await client.request('tools/list', {}, 30000)
      const tools = Array.isArray(listed.tools) ? listed.tools : []
      // Resources and prompts are optional capabilities; only ask when the
      // server declared them, and treat a rejected list as "none".
      const capabilities = (init && init.capabilities) || {}
      let resources = []
      let prompts = []
      if (capabilities.resources) {
        try {
          const listedResources = await client.request('resources/list', {}, 30000)
          resources = Array.isArray(listedResources.resources) ? listedResources.resources : []
        } catch { /* server declared resources but refuses listing — treat as none */ }
      }
      if (capabilities.prompts) {
        try {
          const listedPrompts = await client.request('prompts/list', {}, 30000)
          prompts = Array.isArray(listedPrompts.prompts) ? listedPrompts.prompts : []
        } catch { /* same leniency as resources */ }
      }
      return { handle, client, init, tools, resources, prompts }
    }

    // ---------- Register one MCP tool as a DSH tool ----------
    const MAX_TOOL_NAME = 48
    const toolTimeoutMs = (server) => (typeof server.timeoutMs === 'number' && server.timeoutMs > 0 ? server.timeoutMs : 120000)
    function toolNameFor(server, tool) {
      let name = 'mcp_' + sanitize(server.id) + '_' + sanitize(tool.name)
      if (name.length > MAX_TOOL_NAME) name = name.slice(0, MAX_TOOL_NAME).replace(/_+$/, '')
      return name
    }

    function registerMcpTool(server, client, tool) {
      const name = toolNameFor(server, tool)
      const definition = define({
        name,
        description: '[MCP:' + server.id + '] ' + (tool.description || tool.name),
        parameters: toParameterSpec(tool.inputSchema),
        output: {
          schema: { type: 'json' },
          render: (_args, value) => [{
            type: 'text',
            text: (value && typeof value.text === 'string' && value.text.length > 0) ? value.text : JSON.stringify(value, null, 2),
          }],
        },
        timeoutMs: toolTimeoutMs(server),
        isConcurrencySafe: () => true,
        async execute(args, exec) {
          const res = await client.request('tools/call', {
            name: tool.name,
            arguments: (args && typeof args === 'object' && !Array.isArray(args)) ? args : {},
          }, toolTimeoutMs(server), exec.signal)
          const content = (res && Array.isArray(res.content)) ? res.content : []
          const textParts = content
            .filter((c) => c && c.type === 'text' && typeof c.text === 'string')
            .map((c) => c.text)
          const text = textParts.join('\n')
          if (res && res.isError) throw new Error('[MCP:' + server.id + ' ' + tool.name + '] ' + (text || 'server reported an error'))
          return { text, content, structuredContent: (res && res.structuredContent) ?? null }
        },
      })
      return ctx.tools.register(definition)
    }

    // ---------- Resources & prompts bridge tools (per server) ----------
    const MAX_BLOB_BASE64 = 65536 // larger blobs stay out of model context

    function registerResourceTools(server, client) {
      const prefix = 'mcp_' + sanitize(server.id)
      const disposers = []
      disposers.push(ctx.tools.register(define({
        name: prefix + '_list_resources',
        description: '[MCP:' + server.id + '] List the resources exposed by this MCP server (pass the returned nextCursor back to fetch more pages).',
        parameters: { cursor: { type: 'string', description: 'Optional pagination cursor from a previous call.' } },
        output: {
          schema: { type: 'json' },
          render: (_args, value) => [{ type: 'text', text: JSON.stringify(value, null, 2) }],
        },
        timeoutMs: toolTimeoutMs(server),
        isConcurrencySafe: () => true,
        async execute(args, exec) {
          const params = args && typeof args.cursor === 'string' && args.cursor.length > 0 ? { cursor: args.cursor } : {}
          const res = await client.request('resources/list', params, toolTimeoutMs(server), exec.signal)
          const resources = (res && Array.isArray(res.resources)) ? res.resources : []
          return {
            resources: resources.map((r) => ({ uri: r && r.uri, name: r && r.name, description: r && r.description, mimeType: r && r.mimeType })),
            nextCursor: (res && res.nextCursor) ?? null,
          }
        },
      })))
      disposers.push(ctx.tools.register(define({
        name: prefix + '_read_resource',
        description: '[MCP:' + server.id + '] Read one resource (by URI) exposed by this MCP server.',
        parameters: { uri: { type: 'string', required: true, description: 'The resource URI to read.' } },
        output: {
          schema: { type: 'json' },
          render: (_args, value) => [{
            type: 'text',
            text: (value && typeof value.text === 'string' && value.text.length > 0) ? value.text : JSON.stringify(value, null, 2),
          }],
        },
        timeoutMs: toolTimeoutMs(server),
        isConcurrencySafe: () => true,
        async execute(args, exec) {
          const res = await client.request('resources/read', { uri: String(args.uri) }, toolTimeoutMs(server), exec.signal)
          const contents = (res && Array.isArray(res.contents)) ? res.contents : []
          // Resource contents carry no `type` tag — `text` vs `blob` fields
          // discriminate them (unlike tool content parts).
          const textParts = contents
            .filter((c) => c && typeof c.text === 'string')
            .map((c) => c.text)
          let blobBase64 = null
          const blobs = contents.filter((c) => c && typeof c.blob === 'string')
          const blobTotal = blobs.reduce((n, c) => n + c.blob.length, 0)
          if (blobs.length > 0 && blobTotal <= MAX_BLOB_BASE64) blobBase64 = blobs.map((c) => c.blob).join('')
          return {
            uri: String(args.uri),
            mimeType: (contents[0] && contents[0].mimeType) || null,
            text: textParts.join('\n'),
            blobCount: blobs.length,
            blobBase64,
            blobOmitted: blobTotal > MAX_BLOB_BASE64,
          }
        },
      })))
      return disposers
    }

    function registerPromptTools(server, client) {
      const prefix = 'mcp_' + sanitize(server.id)
      const disposers = []
      disposers.push(ctx.tools.register(define({
        name: prefix + '_list_prompts',
        description: '[MCP:' + server.id + '] List the prompt templates exposed by this MCP server (pass the returned nextCursor back to fetch more pages).',
        parameters: { cursor: { type: 'string', description: 'Optional pagination cursor from a previous call.' } },
        output: {
          schema: { type: 'json' },
          render: (_args, value) => [{ type: 'text', text: JSON.stringify(value, null, 2) }],
        },
        timeoutMs: toolTimeoutMs(server),
        isConcurrencySafe: () => true,
        async execute(args, exec) {
          const params = args && typeof args.cursor === 'string' && args.cursor.length > 0 ? { cursor: args.cursor } : {}
          const res = await client.request('prompts/list', params, toolTimeoutMs(server), exec.signal)
          const prompts = (res && Array.isArray(res.prompts)) ? res.prompts : []
          return {
            prompts: prompts.map((p) => ({ name: p && p.name, description: p && p.description })),
            nextCursor: (res && res.nextCursor) ?? null,
          }
        },
      })))
      disposers.push(ctx.tools.register(define({
        name: prefix + '_get_prompt',
        description: '[MCP:' + server.id + '] Render one prompt template exposed by this MCP server.',
        parameters: {
          name: { type: 'string', required: true, description: 'The prompt template name.' },
          arguments: { type: 'json', description: 'Optional template arguments (key-value JSON object).' },
        },
        output: {
          schema: { type: 'json' },
          render: (_args, value) => [{
            type: 'text',
            text: (value && typeof value.text === 'string' && value.text.length > 0) ? value.text : JSON.stringify(value, null, 2),
          }],
        },
        timeoutMs: toolTimeoutMs(server),
        isConcurrencySafe: () => true,
        async execute(args, exec) {
          const res = await client.request('prompts/get', {
            name: String(args.name),
            arguments: (args.arguments && typeof args.arguments === 'object' && !Array.isArray(args.arguments)) ? args.arguments : {},
          }, toolTimeoutMs(server), exec.signal)
          const messages = (res && Array.isArray(res.messages)) ? res.messages : []
          const textParts = messages
            .flatMap((m) => (m && m.content && typeof m.content === 'object' && !Array.isArray(m.content) && m.content.type === 'text' ? [m.content.text] : []))
            .filter((t) => typeof t === 'string')
          return { name: String(args.name), description: (res && res.description) || null, messages, text: textParts.join('\n') }
        },
      })))
      return disposers
    }

    // ---------- Status tool ----------
    const state = []
    ctx.effect(() => ctx.tools.register(define({
      name: 'mcp_status',
      description: 'List every configured MCP server, its connection status, and the tool names it exposes.',
      parameters: {},
      output: {
        schema: { type: 'json' },
        render: (_args, value) => [{ type: 'text', text: JSON.stringify(value, null, 2) }],
      },
      execute: async () => state.map((s) => ({
        id: s.id, status: s.status, toolCount: s.toolNames.length, tools: s.toolNames, resourceCount: s.resourceCount, promptCount: s.promptCount, serverInfo: s.serverInfo, error: s.error,
      })),
    })), 'mcp status tool')

    // ---------- Validate config, then start every configured server ----------
    const seenIds = new Set()
    for (const server of MCP_SERVERS) {
      if (!server || typeof server !== 'object' || Array.isArray(server)) {
        throw new Error('[mcp-bridge] every server entry must be an object')
      }
      if (typeof server.id !== 'string' || server.id.length === 0) {
        throw new Error('[mcp-bridge] every server entry needs a non-empty string `id`')
      }
      if (seenIds.has(server.id)) {
        throw new Error('[mcp-bridge] duplicate server id: ' + JSON.stringify(server.id))
      }
      seenIds.add(server.id)
      if (server.disabled === true) {
        // Disabled entries are recorded but never validated or connected —
        // a deliberately inactive entry must not block plugin startup.
        state.push({ id: server.id, status: 'disabled', toolNames: [], resourceCount: 0, promptCount: 0, serverInfo: null, error: null })
        console.log('[mcp-bridge] server ' + server.id + ' is disabled, skipping')
        continue
      }
      if (!server.url && (typeof server.command !== 'string' || server.command.length === 0)) {
        throw new Error('[mcp-bridge] server ' + JSON.stringify(server.id) + ' needs either `url` or `command`')
      }
      if (!server.url && (!Array.isArray(server.args) || server.args.some((a) => typeof a !== 'string'))) {
        throw new Error('[mcp-bridge] server ' + JSON.stringify(server.id) + ' `args` must be an array of strings')
      }
      if (server.url && typeof server.url !== 'string') {
        throw new Error('[mcp-bridge] server ' + JSON.stringify(server.id) + ' `url` must be a string')
      }
      for (const field of ['allowTools', 'denyTools']) {
        if (server[field] !== undefined && (!Array.isArray(server[field]) || server[field].some((n) => typeof n !== 'string'))) {
          throw new Error('[mcp-bridge] server ' + JSON.stringify(server.id) + ' `' + field + '` must be an array of tool names')
        }
      }
      if (server.timeoutMs !== undefined && (!Number.isFinite(server.timeoutMs) || server.timeoutMs <= 0)) {
        throw new Error('[mcp-bridge] server ' + JSON.stringify(server.id) + ' `timeoutMs` must be a positive finite number')
      }
    }

    // Optional per-server tool filtering: `allowTools` keeps only the named
    // tools, `denyTools` removes them (both may combine; exact names).
    function filterTools(server, tools) {
      let result = tools
      if (Array.isArray(server.allowTools) && server.allowTools.length > 0) {
        const allowed = new Set(server.allowTools)
        result = result.filter((t) => allowed.has(t.name))
      }
      if (Array.isArray(server.denyTools) && server.denyTools.length > 0) {
        const denied = new Set(server.denyTools)
        result = result.filter((t) => !denied.has(t.name))
      }
      return result
    }

    // ---------- Start every configured server (with bounded auto-reconnect) ----------
    const MAX_RETRIES = 3
    const RETRY_DELAYS_MS = [2000, 5000, 10000]

    for (const server of MCP_SERVERS) {
      if (server.disabled === true) continue // already recorded as disabled
      const entry = { id: server.id, status: 'connecting', toolNames: [], resourceCount: 0, promptCount: 0, serverInfo: null, error: null }
      state.push(entry)
      let handle = null
      let disposed = false
      let retryTimer = null
      let toolDisposers = []
      ctx.effect(() => () => {
        disposed = true
        if (retryTimer) retryTimer()
        for (const disposer of toolDisposers) { try { disposer() } catch { /* already unregistered */ } }
        if (handle) handle.terminate()
      }, 'mcp connection: ' + server.id)

      async function startConnection(attempt) {
        if (disposed) return
        entry.status = 'connecting'
        entry.error = null
        let conn
        try {
          conn = await connectServer(server)
        } catch (error) {
          if (disposed) return
          entry.status = 'error'
          entry.error = String((error && error.message) || error)
          console.error('[mcp:' + server.id + '] connect attempt ' + (attempt + 1) + ' failed:', error)
          if (attempt < MAX_RETRIES) {
            const delay = RETRY_DELAYS_MS[attempt] ?? 10000
            retryTimer = ctx.timeout(() => { retryTimer = null; startConnection(attempt + 1) }, delay)
          } else {
            console.error('[mcp:' + server.id + '] giving up after ' + (attempt + 1) + ' attempts')
          }
          return
        }
        if (disposed) { conn.handle.terminate(); return }
        handle = conn.handle
        entry.serverInfo = (conn.init && conn.init.serverInfo) || null
        for (const disposer of toolDisposers) { try { disposer() } catch { /* already unregistered */ } }
        toolDisposers = []
        const visibleTools = filterTools(server, conn.tools)
        for (const tool of visibleTools) toolDisposers.push(registerMcpTool(server, conn.client, tool))
        if (conn.resources.length > 0) {
          for (const disposer of registerResourceTools(server, conn.client)) toolDisposers.push(disposer)
        }
        if (conn.prompts.length > 0) {
          for (const disposer of registerPromptTools(server, conn.client)) toolDisposers.push(disposer)
        }
        entry.toolNames = visibleTools.map((t) => t.name)
        entry.resourceCount = conn.resources.length
        entry.promptCount = conn.prompts.length
        entry.status = 'ready'
        entry.error = null
        console.log('[mcp:' + server.id + '] connected, ' + visibleTools.length + ' tools, ' + conn.resources.length + ' resources, ' + conn.prompts.length + ' prompts registered')
        conn.handle.done.then((outcome) => {
          if (disposed) return
          for (const disposer of toolDisposers) { try { disposer() } catch { /* already unregistered */ } }
          toolDisposers = []
          entry.toolNames = []
          entry.resourceCount = 0
          entry.promptCount = 0
          entry.status = 'error'
          entry.error = 'process exited unexpectedly (code=' + outcome.exitCode + ' signal=' + outcome.signal + ')'
          if (attempt < MAX_RETRIES) {
            const delay = RETRY_DELAYS_MS[attempt] ?? 10000
            console.error('[mcp:' + server.id + '] reconnecting in ' + delay + 'ms')
            retryTimer = ctx.timeout(() => { retryTimer = null; startConnection(attempt + 1) }, delay)
          } else {
            console.error('[mcp:' + server.id + '] exited; giving up after ' + (attempt + 1) + ' attempts')
          }
        }).catch(() => { /* spawn-level rejection already logged by connectServer */ })
      }

      startConnection(0)
    }

    console.log('mcp-bridge: started, servers=' + MCP_SERVERS.map((s) => s.id).join(','))
  },
}
