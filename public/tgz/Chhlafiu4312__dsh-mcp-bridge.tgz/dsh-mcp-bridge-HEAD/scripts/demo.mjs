// demo.mjs — self-running end-to-end demo of the REAL plugin.js against the
// local stdio MCP fixture. Produces a tidy terminal transcript suitable for a
// README GIF. Run: node scripts/demo.mjs
import { makeEnv, waitFor, call, SERVER_PATH } from '../test/helpers.mjs'

process.env.DSH_MCP_SERVERS = JSON.stringify([
  { id: 'test', command: process.execPath, args: [SERVER_PATH] },
])

const { default: plugin } = await import('../plugin.js')

const env = makeEnv()
try {
  console.log('=== dsh-mcp-bridge demo ===\n')
  console.log('You: connect the demo MCP server')
  plugin.apply(env.ctx)
  await waitFor(() => env.registered.some((t) => t.name === 'mcp_test_http_echo'))
  console.log('     ✓ bridge started — server connected, tools auto-registered\n')

  const echo = env.registered.find((t) => t.name === 'mcp_test_http_echo')
  console.log('You: echo "Hello MCP"')
  console.log('     → mcp_test_http_echo { message: "Hello MCP" }')
  console.log('     ✓ ' + (await call(echo, { message: 'Hello MCP' })).text + '\n')

  const read = env.registered.find((t) => t.name === 'mcp_test_read_resource')
  console.log('You: read the welcome document')
  console.log('     → mcp_test_read_resource { uri: "docs://welcome" }')
  console.log('     ✓ ' + (await call(read, { uri: 'docs://welcome' })).text + '\n')

  const getPrompt = env.registered.find((t) => t.name === 'mcp_test_get_prompt')
  console.log('You: render the greet prompt for DeepSeek')
  console.log('     → mcp_test_get_prompt { name: "greet", arguments: { who: "DeepSeek" } }')
  console.log('     ✓ ' + (await call(getPrompt, { name: 'greet', arguments: { who: 'DeepSeek' } })).text + '\n')

  const status = env.registered.find((t) => t.name === 'mcp_status')
  const snapshot = await status.execute({}, { signal: new AbortController().signal })
  const s = snapshot[0]
  console.log('You: mcp_status')
  console.log(`     ✓ ${s.id}: ${s.status}, ${s.toolCount} tools, ${s.resourceCount} resource, ${s.promptCount} prompt`)
  console.log('\n=== demo complete ===')
} finally {
  env.dispose()
}
