# Contributing

Thanks for helping! This project stays intentionally small — a single
zero-dependency file plus docs — so keep changes focused and reviewable.

## Setup

```bash
git clone https://github.com/Chhlafiu4312/dsh-mcp-bridge.git
cd dsh-mcp-bridge
node --check plugin.js            # syntax
```

The full local test (needs no dependencies):

```bash
node test/mcp-http-test-server.cjs 18181 &
node test/smoke-http.mjs 18181
```

## Ground rules

- **Zero runtime dependencies.** The bridge speaks raw JSON-RPC 2.0; do not
  add an SDK or npm dependency to `plugin.js`.
- **Both mounting paths.** `plugin.js` must keep working both as a dynamic
  Cordis plugin (where `harness.defineTool` exists) and as a preset/bundle
  mount (where it falls back to `@deepseek-ai/dsh-tools`).
- **The MCP server is the authority.** The schema sanitizer degrades
  unsupported JSON-Schema keywords to open inputs; it must never invent
  constraints the server did not declare.
- **Lifecycle discipline.** Every child process and tool registration must be
  owned by the plugin fiber and cleaned up on stop/update.

## Tests

CI runs `node --check` on the plugin and the test server plus the HTTP smoke
round trip. Changes to protocol handling should extend
`test/smoke-http.mjs` or the fixture server first.

## Commit style

Short imperative subject lines (feat:/fix:/docs:/test:/chore:), one concern
per commit.
