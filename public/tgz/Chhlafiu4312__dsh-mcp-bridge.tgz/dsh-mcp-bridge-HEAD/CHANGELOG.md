
## 0.7.0

- Renamed the npm package to `dsh-mcp-connect` (the unscoped
  `dsh-mcp-bridge` name was already taken on npm) and added the `repository`
  field required by registry validation. The bundle patch row matches the new
  name for both GitHub and npm installs.

## 0.6.2

- Per-server `timeoutMs` config (default 120000) applied to every bridge
  request and tool definition; invalid values fail startup validation.
- Edge-case hardening suite (20 tests): out-of-order responses, garbage
  stdout lines, oversized stderr, chunk-split responses, server error
  surfacing, cancellation-notification forwarding, and prompt timeouts.

## 0.6.1

- Per-server tool filtering: `allowTools` / `denyTools` (exact names,
  combinable) so destructive tools can be hidden from the model per server.
- List pagination: `mcp_<server>_list_resources` / `_list_prompts` accept a
  `cursor` parameter and return `nextCursor`.
- Suite now covers 13 cases (filters, pagination, config validation).
## 0.6.0

- MCP resources & prompts bridge (per server, capability-gated discovery):
  - `mcp_<server>_list_resources` / `mcp_<server>_read_resource`
  - `mcp_<server>_list_prompts` / `mcp_<server>_get_prompt`
- `mcp_status` reports resourceCount/promptCount per server.
- Resource blobs are kept out of model context beyond a 64 KB cap.
- Fixed resource text/blob discrimination (contents carry no `type` tag —
  caught by the new round-trip tests). Suite now covers 10 cases.

# Changelog

## 0.5.0

- Hardening pass driven by a code walkthrough plus a new hermetic test suite:
  - stderr tail decoding now uses a streaming TextDecoder (multibyte UTF-8 no
    longer corrupts across chunk boundaries)
  - in-flight requests reject immediately on process exit instead of hanging
    until their timeout
  - aborted calls forward `notifications/cancelled` to the server; abort
    listeners are removed on settle
  - pipe writes are guarded against broken-pipe throws
  - tool names are capped at 48 characters
  - disabled server entries are recorded in `mcp_status` and no longer fail
    startup validation
- `defineTool` falls back to a raw passthrough outside the harness, so the
  plugin loads in plain-node test environments.
- New zero-network test suite: `test/plugin.test.mjs` boots the real plugin
  against a local stdio MCP fixture and covers boot/registration, a tool-call
  round trip, crash reconnect, and in-flight rejection. CI runs it.

## 0.4.0

- Add `dsh.bundle` manifest (`package.json` + `cordis.patch.yml`) so the repo
  installs via `dsh plugin add` and qualifies for community registries.
- Bounded auto-reconnect: failed connects and unexpected process exits retry
  up to 3 times (2s/5s/10s backoff); tool registrations rebuild per connection.
- Per-server `disabled` flag for keeping entries configured but inactive.
- Validate server configuration at startup: unique ids, `command`+`args` or
  `url` per entry, clear errors on misconfiguration.
- CI workflow with an HTTP MCP round-trip smoke test.

## 0.3.1

- Unified JSON-Schema → parameter-DSL sanitizer shared by the dynamic-plugin
  and preset-mount paths; unsupported schema nodes degrade to open inputs
  while the MCP server remains the authority.
- Verified end-to-end against the official filesystem MCP server (stdio) and
  a local streamable-HTTP server (via `mcp-remote`).

## 0.3.0

- `url`-based servers: HTTP/SSE MCP servers bridged through `mcp-remote`.
- Empty MCP text responses now render the raw result JSON instead of nothing.
- `mcp_status` reports connection state, tool counts, and server info.

## 0.1.0

- Initial release: raw JSON-RPC 2.0 client over stdio, MCP
  initialize/tools.list/tools.calls handshake, automatic tool registration as
  `mcp_<server>_<tool>`, clean child-process teardown.

## 0.4.1

- Fix bundle patch row to use the package name (`dsh-mcp-bridge`) — relative
  paths compose from the profile directory and fail at boot.
- Verified on a real machine via `dsh plugin add` + headless profile boot:
  install, composition, activation, MCP connection, and a model-driven
  `mcp_status` round trip.
- Document the npm-cache `EPERM` (root-owned files) workaround in the FAQ.
