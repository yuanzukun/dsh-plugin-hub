import test from 'node:test'
import assert from 'node:assert/strict'
import { makeEnv, waitFor, call, SERVER_PATH } from './helpers.mjs'

const { default: plugin } = await import('../plugin.js')

const oneServer = () => [{ id: 'test', command: process.execPath, args: [SERVER_PATH] }]

// resolveServers() reads the environment on every apply — set it per test.
function boot(servers) {
  process.env.DSH_MCP_SERVERS = JSON.stringify(servers)
  const env = makeEnv()
  plugin.apply(env.ctx)
  return env
}

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms))

test('boot registers every MCP tool with sanitized schemas', async () => {
  const env = boot(oneServer())
  try {
    assert.ok(await waitFor(() => env.registered.some((t) => t.name === 'mcp_test_http_echo')), 'echo tool registered')
    assert.ok(env.registered.some((t) => t.name === 'mcp_test_http_add'), 'add tool registered')
    assert.ok(env.registered.some((t) => t.name === 'mcp_test_crash'), 'crash tool registered')
    assert.ok(env.registered.some((t) => t.name === 'mcp_status'), 'status tool registered')
    const echo = env.registered.find((t) => t.name === 'mcp_test_http_echo')
    assert.equal(echo.parameters.message.type, 'string')
    assert.equal(echo.parameters.message.required, true)
    assert.equal(echo.description.startsWith('[MCP:test]'), true)
  } finally {
    env.dispose()
  }
})

test('nested schemas sanitize: enum/array kept, unsupported keywords degrade', async () => {
  const env = boot(oneServer())
  try {
    await waitFor(() => env.registered.some((t) => t.name === 'mcp_test_complex'))
    const complex = env.registered.find((t) => t.name === 'mcp_test_complex')
    // nested object with enum survives
    assert.equal(complex.parameters.query.type, 'object')
    assert.equal(complex.parameters.query.required, true)
    assert.deepEqual(complex.parameters.query.properties.mode.enum, ['fast', 'deep'])
    assert.equal(complex.parameters.query.properties.tags.type, 'array')
    assert.equal(complex.parameters.query.properties.tags.items.type, 'string')
    // unsupported keywords (`format`) are dropped while the type survives
    assert.equal(complex.parameters.format.type, 'string')
    // numeric bounds are unsupported and dropped, the type stays
    assert.equal(complex.parameters.count.type, 'integer')
  } finally {
    env.dispose()
  }
})

test('tool call round trip through a real child process', async () => {
  const env = boot(oneServer())
  try {
    await waitFor(() => env.registered.some((t) => t.name === 'mcp_test_http_add'))
    const add = env.registered.find((t) => t.name === 'mcp_test_http_add')
    const result = await call(add, { a: 19, b: 23 })
    assert.equal(result.text, 'sum: 42')
  } finally {
    env.dispose()
  }
})

test('server crash triggers reconnect with working tools again', async () => {
  const env = boot(oneServer())
  try {
    await waitFor(() => env.registered.some((t) => t.name === 'mcp_test_crash'))
    const echoCount = () => env.registered.filter((t) => t.name === 'mcp_test_http_echo').length
    const before = echoCount()
    const crash = env.registered.find((t) => t.name === 'mcp_test_crash')
    await call(crash).catch(() => { /* connection dies mid-call */ })
    // bounded backoff (2s) then re-registration
    assert.ok(await waitFor(() => echoCount() > before, 20000), 'tools re-registered after crash')
    const echo = env.registered.filter((t) => t.name === 'mcp_test_http_echo').pop()
    const result = await call(echo, { message: 'after crash' })
    assert.equal(result.text, 'echo: after crash')
  } finally {
    env.dispose()
  }
})

test('connection loss rejects in-flight requests instead of hanging', async () => {
  const env = boot(oneServer())
  try {
    await waitFor(() => env.registered.some((t) => t.name === 'mcp_test_crash'))
    const crash = env.registered.find((t) => t.name === 'mcp_test_crash')
    await assert.rejects(call(crash), /connection closed|aborted|timeout/)
  } finally {
    env.dispose()
  }
})

test('multiple servers register independent tool prefixes', async () => {
  const env = boot([
    { id: 'test', command: process.execPath, args: [SERVER_PATH] },
    { id: 'second', command: process.execPath, args: [SERVER_PATH] },
  ])
  try {
    assert.ok(await waitFor(() => env.registered.some((t) => t.name === 'mcp_test_http_echo')), 'first server ready')
    assert.ok(await waitFor(() => env.registered.some((t) => t.name === 'mcp_second_http_echo')), 'second server ready')
    const first = env.registered.find((t) => t.name === 'mcp_test_http_echo')
    const second = env.registered.find((t) => t.name === 'mcp_second_http_echo')
    assert.equal((await call(first, { message: 'a' })).text, 'echo: a')
    assert.equal((await call(second, { message: 'b' })).text, 'echo: b')
  } finally {
    env.dispose()
  }
})

test('disabled entries appear in mcp_status without failing validation', async () => {
  const env = boot([
    { id: 'test', command: process.execPath, args: [SERVER_PATH] },
    { id: 'off', disabled: true }, // no command/url — must not fail validation
  ])
  try {
    await waitFor(() => env.registered.some((t) => t.name === 'mcp_status'))
    const status = env.registered.find((t) => t.name === 'mcp_status')
    const snapshot = await status.execute({}, { signal: new AbortController().signal })
    const ids = snapshot.map((s) => s.id).sort()
    assert.deepEqual(ids, ['off', 'test'])
    assert.equal(snapshot.find((s) => s.id === 'off').status, 'disabled')
  } finally {
    env.dispose()
  }
})

test('resources bridge: list and read round trip', async () => {
  const env = boot(oneServer())
  try {
    await waitFor(() => env.registered.some((t) => t.name === 'mcp_test_list_resources'))
    const list = env.registered.find((t) => t.name === 'mcp_test_list_resources')
    const listed = await call(list)
    assert.equal(listed.resources[0].uri, 'docs://welcome')

    const read = env.registered.find((t) => t.name === 'mcp_test_read_resource')
    const resource = await call(read, { uri: 'docs://welcome' })
    assert.equal(resource.text, 'welcome to the test server')
    assert.equal(resource.mimeType, 'text/plain')

    // status reports the counts
    const status = env.registered.find((t) => t.name === 'mcp_status')
    const snapshot = await status.execute({}, { signal: new AbortController().signal })
    assert.equal(snapshot.find((s) => s.id === 'test').resourceCount, 1)
  } finally {
    env.dispose()
  }
})

test('prompts bridge: list and get round trip with arguments', async () => {
  const env = boot(oneServer())
  try {
    await waitFor(() => env.registered.some((t) => t.name === 'mcp_test_list_prompts'))
    const list = env.registered.find((t) => t.name === 'mcp_test_list_prompts')
    const listed = await call(list)
    assert.equal(listed.prompts[0].name, 'greet')

    const get = env.registered.find((t) => t.name === 'mcp_test_get_prompt')
    const prompt = await call(get, { name: 'greet', arguments: { who: 'DSH' } })
    assert.equal(prompt.text, 'Hello DSH')
  } finally {
    env.dispose()
  }
})

test('pagination cursor passes through list calls', async () => {
  const env = boot(oneServer())
  try {
    await waitFor(() => env.registered.some((t) => t.name === 'mcp_test_list_resources'))
    const list = env.registered.find((t) => t.name === 'mcp_test_list_resources')
    const page1 = await call(list)
    assert.equal(page1.resources[0].uri, 'docs://welcome')
    assert.equal(page1.nextCursor, 'page2')
    const page2 = await call(list, { cursor: 'page2' })
    assert.equal(page2.resources[0].uri, 'docs://page2')
    assert.equal(page2.nextCursor, null)
  } finally {
    env.dispose()
  }
})

test('allowTools keeps only the named tools', async () => {
  const env = boot([{ id: 'test', command: process.execPath, args: [SERVER_PATH], allowTools: ['http_echo'] }])
  try {
    await waitFor(() => env.registered.some((t) => t.name === 'mcp_test_http_echo'))
    const names = env.registered.map((t) => t.name).filter((n) => n.startsWith('mcp_test_') && !n.includes('list_') && !n.includes('read_resource') && !n.includes('get_prompt'))
    assert.deepEqual(names, ['mcp_test_http_echo'])
  } finally {
    env.dispose()
  }
})

test('denyTools hides the named tools', async () => {
  const env = boot([{ id: 'test', command: process.execPath, args: [SERVER_PATH], denyTools: ['crash'] }])
  try {
    await waitFor(() => env.registered.some((t) => t.name === 'mcp_test_http_echo'))
    assert.ok(!env.registered.some((t) => t.name === 'mcp_test_crash'), 'crash tool not registered')
    assert.ok(env.registered.some((t) => t.name === 'mcp_test_http_add'), 'add tool still registered')
  } finally {
    env.dispose()
  }
})

test('out-of-order responses resolve by id, not arrival order', async () => {
  const env = boot(oneServer())
  try {
    await waitFor(() => env.registered.some((t) => t.name === 'mcp_test_slow_echo'))
    const slow = env.registered.find((t) => t.name === 'mcp_test_slow_echo')
    const fast = env.registered.find((t) => t.name === 'mcp_test_http_echo')
    const settled = []
    const slowCall = call(slow, { message: 'later' }).then((r) => settled.push('slow:' + r.text))
    const fastCall = call(fast, { message: 'first' }).then((r) => settled.push('fast:' + r.text))
    await Promise.all([slowCall, fastCall])
    assert.deepEqual(settled, ['fast:echo: first', 'slow:slow: later'])
  } finally {
    env.dispose()
  }
})

test('garbage stdout lines are skipped without breaking the stream', async () => {
  const env = boot(oneServer())
  try {
    await waitFor(() => env.registered.some((t) => t.name === 'mcp_test_spew_garbage'))
    const spew = env.registered.find((t) => t.name === 'mcp_test_spew_garbage')
    const result = await call(spew)
    assert.equal(result.text, 'garbage survived')
    // the stream still works afterwards
    const echo = env.registered.find((t) => t.name === 'mcp_test_http_echo')
    assert.equal((await call(echo, { message: 'again' })).text, 'echo: again')
  } finally {
    env.dispose()
  }
})

test('oversized stderr stays bounded and the call still succeeds', async () => {
  const env = boot(oneServer())
  try {
    await waitFor(() => env.registered.some((t) => t.name === 'mcp_test_spew_stderr'))
    const spew = env.registered.find((t) => t.name === 'mcp_test_spew_stderr')
    const result = await call(spew)
    assert.equal(result.text, 'stderr survived')
  } finally {
    env.dispose()
  }
})

test('responses split across many chunks parse correctly', async () => {
  const env = boot(oneServer())
  try {
    await waitFor(() => env.registered.some((t) => t.name === 'mcp_test_chunky_echo'))
    const chunky = env.registered.find((t) => t.name === 'mcp_test_chunky_echo')
    const result = await call(chunky, { message: 'piecewise' })
    assert.equal(result.text, 'chunky: piecewise')
  } finally {
    env.dispose()
  }
})

test('server-side errors surface as rejections with the server message', async () => {
  const env = boot(oneServer())
  try {
    await waitFor(() => env.registered.some((t) => t.name === 'mcp_test_read_resource'))
    const read = env.registered.find((t) => t.name === 'mcp_test_read_resource')
    await assert.rejects(call(read, { uri: 'docs://missing' }), /resource not found: docs:\/\/missing/)
  } finally {
    env.dispose()
  }
})

test('abort forwards notifications/cancelled to the server', async () => {
  const env = boot(oneServer())
  try {
    await waitFor(() => env.registered.some((t) => t.name === 'mcp_test_slow_echo'))
    const slow = env.registered.find((t) => t.name === 'mcp_test_slow_echo')
    const controller = new AbortController()
    const pending = slow.execute({ message: 'doomed' }, { signal: controller.signal })
    setTimeout(() => controller.abort(), 150)
    await assert.rejects(pending, /aborted/)
    // give the notification a moment to reach the fixture
    await sleep(200)
    const probe = env.registered.find((t) => t.name === 'mcp_test_last_event')
    const observed = await call(probe)
    assert.match(observed.text, /cancelled:\d+/)
  } finally {
    env.dispose()
  }
})

test('per-server timeoutMs rejects a never-answering server', async () => {
  const env = boot([{ id: 'test', command: process.execPath, args: [SERVER_PATH], timeoutMs: 500 }])
  try {
    await waitFor(() => env.registered.some((t) => t.name === 'mcp_test_never'))
    const never = env.registered.find((t) => t.name === 'mcp_test_never')
    const started = Date.now()
    await assert.rejects(call(never), /timeout/)
    assert.ok(Date.now() - started < 5000, 'rejects promptly, not after the default 120s')
  } finally {
    env.dispose()
  }
})

test('invalid config fails loudly at startup', () => {
  assert.throws(() => boot([{ id: 'a', command: 'x', args: ['y'] }, { id: 'a', command: 'x', args: ['y'] }]), /duplicate server id/)
  assert.throws(() => boot([{ id: 'a', args: ['y'] }]), /needs either `url` or `command`/)
  assert.throws(() => boot([{ id: 'a', command: 'x', args: ['y'], allowTools: [1] }]), /`allowTools` must be an array of tool names/)
  assert.throws(() => boot([{ id: 'a', command: 'x', args: ['y'], timeoutMs: -1 }]), /`timeoutMs` must be a positive finite number/)
})
