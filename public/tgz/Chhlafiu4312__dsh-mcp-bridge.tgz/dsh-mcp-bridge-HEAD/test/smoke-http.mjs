// smoke-http.mjs — verifies a full MCP JSON-RPC round trip against the local
// test server (test/mcp-http-test-server.js): initialize → tools/list →
// tools/call. Used by CI; run: node test/smoke-http.mjs [port, default 18181]
const PORT = Number(process.argv[2]) || 18181
const BASE = `http://127.0.0.1:${PORT}/mcp`

const failures = []
function check(label, ok) {
  console.log((ok ? '  ✓ ' : '  ✗ ') + label)
  if (!ok) failures.push(label)
}

async function post(payload) {
  const res = await fetch(BASE, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Accept: 'application/json, text/event-stream' },
    body: JSON.stringify(payload),
  })
  if (res.status === 202) return { status: res.status }
  const body = await res.json()
  return { status: res.status, body }
}

const init = await post({ jsonrpc: '2.0', id: 1, method: 'initialize', params: { protocolVersion: '2025-03-26', capabilities: {}, clientInfo: { name: 'smoke', version: '0.0.0' } } })
check('initialize returns protocolVersion', init.status === 200 && init.body && init.body.result && typeof init.body.result.protocolVersion === 'string')

const notified = await post({ jsonrpc: '2.0', method: 'notifications/initialized' })
check('notifications/initialized accepted (202)', notified.status === 202)

const listed = await post({ jsonrpc: '2.0', id: 2, method: 'tools/list', params: {} })
const tools = listed.body && listed.body.result && listed.body.result.tools
check('tools/list returns 2 tools', Array.isArray(tools) && tools.length === 2)

const called = await post({ jsonrpc: '2.0', id: 3, method: 'tools/call', params: { name: 'http_add', arguments: { a: 19, b: 23 } } })
const text = called.body && called.body.result && called.body.result.content && called.body.result.content[0] && called.body.result.content[0].text
check('tools/call http_add(19,23) returns "sum: 42"', text === 'sum: 42')

if (failures.length > 0) {
  console.error(`\nSMOKE FAILED: ${failures.length} check(s): ${failures.join('; ')}`)
  process.exit(1)
}
console.log('\nSMOKE PASSED')
