// helpers.mjs — shared mock-ctx harness for booting the REAL plugin.js against
// real child processes. Used by plugin.test.mjs and scripts/demo.mjs.
import { spawn } from 'node:child_process'
import { fileURLToPath } from 'node:url'

export const SERVER_PATH = fileURLToPath(new URL('./stdio-mcp-server.cjs', import.meta.url))

export function makeEnv() {
  const registered = []
  const disposers = []
  const timers = new Set()
  const tools = { register: (def) => { registered.push(def); return () => {} } }
  const ctx = {
    tools,
    get(name) {
      if (name === 'tools') return tools
      return undefined
    },
    timeout(callback, ms) {
      const t = setTimeout(callback, ms)
      timers.add(t)
      return () => { clearTimeout(t); timers.delete(t) }
    },
    effect(callback, _label) {
      const disposer = callback()
      disposers.push(() => { try { disposer() } catch { /* already disposed */ } })
      return () => {}
    },
    subprocess: {
      async resolveExecutable(command) { return command },
      spawn(spec) {
        const child = spawn(spec.argv[0], spec.argv.slice(1), {
          cwd: spec.cwd,
          env: { ...process.env, ...(spec.env || {}) },
          stdio: ['pipe', 'pipe', 'pipe'],
        })
        let resolveDone
        const done = new Promise((resolve) => { resolveDone = resolve })
        child.on('exit', (code, signal) => resolveDone({ exitCode: code, signal }))
        return {
          pid: child.pid,
          stdin: child.stdin,
          stdout: child.stdout,
          stderr: child.stderr,
          done,
          terminate: () => { try { child.kill('SIGTERM') } catch { /* already gone */ } },
          waitForExit: () => new Promise((resolve) => child.on('exit', () => resolve(true))),
        }
      },
    },
  }
  return {
    ctx,
    registered,
    dispose() {
      for (const disposer of disposers.splice(0)) disposer()
      for (const t of Array.from(timers)) clearTimeout(t)
    },
  }
}

export const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms))

export async function waitFor(condition, timeoutMs = 20000, stepMs = 100) {
  const deadline = Date.now() + timeoutMs
  while (Date.now() < deadline) {
    if (condition()) return true
    await sleep(stepMs)
  }
  return condition()
}

export const call = (def, args = {}) => def.execute(args, { signal: new AbortController().signal })
