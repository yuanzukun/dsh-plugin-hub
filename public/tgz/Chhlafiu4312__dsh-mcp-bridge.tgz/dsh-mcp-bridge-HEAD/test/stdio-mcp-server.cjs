// stdio-mcp-server.cjs — minimal MCP server over stdio for hermetic tests.
// Tools: http_echo, http_add, crash (exits the process to exercise reconnect).
// Speaks newline-delimited JSON-RPC 2.0, the same framing the bridge reads.
'use strict'

const TOOLS = [
  {
    name: 'http_echo',
    description: 'Echo text back over stdio.',
    inputSchema: {
      type: 'object',
      properties: {
        message: { type: 'string', description: 'Text to echo' },
      },
      required: ['message'],
    },
  },
  {
    name: 'http_add',
    description: 'Add two integers.',
    inputSchema: {
      type: 'object',
      properties: {
        a: { type: 'integer', description: 'First operand' },
        b: { type: 'integer', description: 'Second operand' },
      },
      required: ['a', 'b'],
    },
  },
  {
    name: 'crash',
    description: 'Exit the server process immediately (test-only).',
    inputSchema: { type: 'object', properties: {} },
  },
  {
    name: 'slow_echo',
    description: 'Respond after a delay (out-of-order / abort tests).',
    inputSchema: { type: 'object', properties: { message: { type: 'string' } } },
  },
  {
    name: 'spew_garbage',
    description: 'Write a garbage line, then a valid response.',
    inputSchema: { type: 'object', properties: {} },
  },
  {
    name: 'spew_stderr',
    description: 'Write 100 KB to stderr, then a valid response.',
    inputSchema: { type: 'object', properties: {} },
  },
  {
    name: 'chunky_echo',
    description: 'Respond split across five delayed writes.',
    inputSchema: { type: 'object', properties: { message: { type: 'string' } } },
  },
  {
    name: 'never',
    description: 'Never respond (timeout tests).',
    inputSchema: { type: 'object', properties: {} },
  },
  {
    name: 'last_event',
    description: 'Report the last cancellation notification the server observed.',
    inputSchema: { type: 'object', properties: {} },
  },
  {
    name: 'complex',
    description: 'Nested schema: object with enum, array of objects, and an unsupported keyword.',
    inputSchema: {
      type: 'object',
      properties: {
        query: {
          type: 'object',
          properties: {
            mode: { type: 'string', enum: ['fast', 'deep'], description: 'Search mode' },
            tags: { type: 'array', items: { type: 'string' }, description: 'Tag list' },
          },
          required: ['mode'],
        },
        format: { type: 'string', format: 'date-time', description: 'Unsupported keyword — should degrade to open' },
        count: { type: 'integer', minimum: 1, maximum: 10 },
      },
      required: ['query'],
    },
  },
]

function send(obj) {
  process.stdout.write(JSON.stringify(obj) + '\n')
}

function handle(msg) {
  if (msg.method === 'initialize') {
    return send({ jsonrpc: '2.0', id: msg.id, result: { protocolVersion: '2024-11-05', capabilities: { tools: {}, resources: {}, prompts: {} }, serverInfo: { name: 'test-stdio-server', version: '1.0.0' } } })
  }
  if (msg.method === 'tools/list') {
    return send({ jsonrpc: '2.0', id: msg.id, result: { tools: TOOLS } })
  }
  if (msg.method === 'tools/call') {
    const { name, arguments: args = {} } = (msg.params || {})
    if (name === 'crash') process.exit(1)
    if (name === 'http_echo') return send({ jsonrpc: '2.0', id: msg.id, result: { content: [{ type: 'text', text: 'echo: ' + String(args.message) }] } })
    if (name === 'http_add') return send({ jsonrpc: '2.0', id: msg.id, result: { content: [{ type: 'text', text: 'sum: ' + String(Number(args.a) + Number(args.b)) }] } })
    if (name === 'slow_echo') {
      setTimeout(() => send({ jsonrpc: '2.0', id: msg.id, result: { content: [{ type: 'text', text: 'slow: ' + String(args.message) }] } }), 400)
      return
    }
    if (name === 'spew_garbage') {
      process.stdout.write('this is not json {{{ \n')
      return send({ jsonrpc: '2.0', id: msg.id, result: { content: [{ type: 'text', text: 'garbage survived' }] } })
    }
    if (name === 'spew_stderr') {
      process.stderr.write('x'.repeat(100000) + '\n')
      return send({ jsonrpc: '2.0', id: msg.id, result: { content: [{ type: 'text', text: 'stderr survived' }] } })
    }
    if (name === 'chunky_echo') {
      const payload = JSON.stringify({ jsonrpc: '2.0', id: msg.id, result: { content: [{ type: 'text', text: 'chunky: ' + String(args.message) }] } }) + '\n'
      let offset = 0
      const step = Math.max(1, Math.ceil(payload.length / 5))
      const push = () => {
        process.stdout.write(payload.slice(offset, offset + step))
        offset += step
        if (offset < payload.length) setTimeout(push, 10)
      }
      push()
      return
    }
    if (name === 'never') return // intentionally no response
    if (name === 'last_event') return send({ jsonrpc: '2.0', id: msg.id, result: { content: [{ type: 'text', text: 'cancelled:' + String(state.lastCancelled) }] } })
    return send({ jsonrpc: '2.0', id: msg.id, error: { code: -32601, message: 'unknown tool: ' + name } })
  }
  if (msg.method === 'resources/list') {
    const cursor = (msg.params || {}).cursor
    if (cursor === 'page2') {
      return send({ jsonrpc: '2.0', id: msg.id, result: { resources: [{ uri: 'docs://page2', name: 'page2', description: 'Second page', mimeType: 'text/plain' }] } })
    }
    return send({ jsonrpc: '2.0', id: msg.id, result: { resources: [{ uri: 'docs://welcome', name: 'welcome', description: 'Welcome document', mimeType: 'text/plain' }], nextCursor: 'page2' } })
  }
  if (msg.method === 'resources/read') {
    const uri = String((msg.params || {}).uri)
    if (uri === 'docs://welcome') {
      return send({ jsonrpc: '2.0', id: msg.id, result: { contents: [{ uri, mimeType: 'text/plain', text: 'welcome to the test server' }] } })
    }
    return send({ jsonrpc: '2.0', id: msg.id, error: { code: -32002, message: 'resource not found: ' + uri } })
  }
  if (msg.method === 'prompts/list') {
    return send({ jsonrpc: '2.0', id: msg.id, result: { prompts: [{ name: 'greet', description: 'Greeting prompt' }] } })
  }
  if (msg.method === 'prompts/get') {
    const { name, arguments: args = {} } = (msg.params || {})
    if (name === 'greet') {
      return send({ jsonrpc: '2.0', id: msg.id, result: { description: 'Greeting prompt', messages: [{ role: 'user', content: { type: 'text', text: 'Hello ' + String(args.who || 'world') } }] } })
    }
    return send({ jsonrpc: '2.0', id: msg.id, error: { code: -32002, message: 'prompt not found: ' + name } })
  }
  // notifications (initialized, cancelled, ...) get no reply
  if (msg.method === 'notifications/cancelled') {
    state.lastCancelled = (msg.params || {}).requestId
  }
}

const state = { lastCancelled: null }

let buffer = ''
process.stdin.setEncoding('utf8')
process.stdin.on('data', (chunk) => {
  buffer += chunk
  let nl
  while ((nl = buffer.indexOf('\n')) >= 0) {
    const line = buffer.slice(0, nl).trim()
    buffer = buffer.slice(nl + 1)
    if (!line) continue
    let msg
    try { msg = JSON.parse(line) } catch { continue }
    handle(msg)
  }
})
