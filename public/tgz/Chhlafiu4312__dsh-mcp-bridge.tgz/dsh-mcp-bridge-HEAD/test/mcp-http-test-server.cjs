// mcp-http-test-server.js — minimal MCP "streamable HTTP" server for local bridge tests.
// Implements the subset of the spec needed to verify the bridge: POST JSON-RPC
// (responded as application/json) plus a GET SSE channel for server->client messages.
// Run: node mcp-http-test-server.js  [port, default 18181]
'use strict'

const http = require('http')

const PORT = Number(process.argv[2]) || 18181

function jsonRpcResult(id, result) {
  return { jsonrpc: '2.0', id, result }
}

function jsonRpcError(id, code, message) {
  return { jsonrpc: '2.0', id, error: { code, message } }
}

function handleRequest(msg) {
  switch (msg.method) {
    case 'initialize':
      return jsonRpcResult(msg.id, {
        protocolVersion: '2025-03-26',
        capabilities: { tools: {} },
        serverInfo: { name: 'local-http-test', version: '0.0.1' },
      })
    case 'tools/list':
      return jsonRpcResult(msg.id, {
        tools: [
          {
            name: 'http_echo',
            description: 'Echo text back over the HTTP transport (proves the full round trip).',
            inputSchema: {
              type: 'object',
              properties: {
                message: { type: 'string', description: 'Text to echo' },
              },
              required: ['message'],
            },
          },
          {
            name: 'http_add',
            description: 'Add two integers over the HTTP transport.',
            inputSchema: {
              type: 'object',
              properties: {
                a: { type: 'integer', description: 'First operand' },
                b: { type: 'integer', description: 'Second operand' },
              },
              required: ['a', 'b'],
            },
          },
        ],
      })
    case 'tools/call': {
      const { name, arguments: args = {} } = msg.params || {}
      if (name === 'http_echo') {
        return jsonRpcResult(msg.id, {
          content: [{ type: 'text', text: 'echo: ' + String(args.message) }],
        })
      }
      if (name === 'http_add') {
        return jsonRpcResult(msg.id, {
          content: [{ type: 'text', text: 'sum: ' + String(Number(args.a) + Number(args.b)) }],
        })
      }
      return jsonRpcError(msg.id, -32601, 'unknown tool: ' + name)
    }
    default:
      if (msg.id === undefined || msg.id === null) return null // notification -> 202
      return jsonRpcError(msg.id, -32601, 'method not found: ' + msg.method)
  }
}

const server = http.createServer((req, res) => {
  // Optional SSE channel for server->client messages (mcp-remote opens it).
  if (req.method === 'GET') {
    res.writeHead(200, {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache',
      Connection: 'keep-alive',
    })
    res.write(': connected\n\n')
    const keepalive = setInterval(() => res.write(': keepalive\n\n'), 15000)
    req.on('close', () => clearInterval(keepalive))
    return
  }
  if (req.method === 'DELETE') {
    res.writeHead(200, { 'Content-Type': 'application/json' })
    res.end('{}')
    return
  }
  if (req.method !== 'POST') {
    res.writeHead(405, { Allow: 'GET, POST, DELETE' })
    res.end()
    return
  }
  let body = ''
  req.setEncoding('utf8')
  req.on('data', (chunk) => { body += chunk })
  req.on('end', () => {
    let msg
    try {
      msg = JSON.parse(body)
    } catch {
      res.writeHead(400, { 'Content-Type': 'application/json' })
      res.end(JSON.stringify(jsonRpcError(null, -32700, 'parse error')))
      return
    }
    const reply = handleRequest(msg)
    if (reply === null) {
      res.writeHead(202)
      res.end()
      return
    }
    res.writeHead(200, {
      'Content-Type': 'application/json',
      'MCP-Protocol-Version': '2025-03-26',
    })
    res.end(JSON.stringify(reply))
  })
})

server.listen(PORT, '127.0.0.1', () => {
  console.log('mcp-http-test-server listening on http://127.0.0.1:' + PORT + '/mcp')
})
