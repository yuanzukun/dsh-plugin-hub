// #86: applyPatches() must not abort the whole run when one patch's target file
// is absent. 1.6.58 added `detail[p.id].push({...})` to the missing-target
// branch without declaring `detail`, so every host that lacks one of the 65
// targets (hooks for Claude Code / Codex, LiangShen cache, …) died mid-apply
// with `ReferenceError: detail is not defined` and the panel stayed at 4/65.
import { test } from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import os from "node:os";
import { ALL_PATCHES, applyPatches, patchStatus } from "../lib/core.js";
import { NATIVE_QUEUE_GUARD, OLD_QUEUE_FALLBACK } from "../lib/steering.js";
import { removeTreeNoFollowSync } from "../lib/remove-tree.js";

// 一条真能打上的补丁（单宿主、两个目标文件都在 fixture 里），用它的 applied
// 结果证明"前一条目标缺失"没有把后面的补丁连坐。
const APPLIES = ALL_PATCHES.find((p) => p.id === 90);
assert.ok(APPLIES, "补丁 90 必须存在于 ALL_PATCHES，否则下面全部断言失去意义");
const fixtureSource = JSON.parse(
  fs.readFileSync(new URL("./fixtures/steering-rc2.json", import.meta.url), "utf8"),
);
// fixtures 里的 controller 是"已打补丁"的样式，还原成宿主原文才是待打状态；
// replace 未命中时会静默返回原文，那样测试会得到莫名其妙的 already，所以先断言。
const RESTORED_CONTROLLER = fixtureSource.controller.replace(
  NATIVE_QUEUE_GUARD,
  OLD_QUEUE_FALLBACK,
);
assert.notEqual(
  RESTORED_CONTROLLER,
  fixtureSource.controller,
  "fixture 里应含 NATIVE_QUEUE_GUARD，否则无法还原成待打补丁的宿主原文",
);

function fixture({ withHostFiles = false }) {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), "purge-apply-missing-"));
  const home = path.join(root, "home");
  const aiBase = path.join(root, "node_modules", "@deepseek-ai");
  fs.mkdirSync(path.join(home, "profiles", "desktop"), { recursive: true });
  fs.writeFileSync(path.join(home, "profiles", "desktop", "package.json"), "{}");
  fs.mkdirSync(aiBase, { recursive: true });
  const targets = {};
  if (withHostFiles) {
    targets.controller = path.join(aiBase, "dsh-api-session-controller", "lib", "index.js");
    targets.loop = path.join(aiBase, "dsh-agent-loop", "lib", "index.js");
    for (const file of Object.values(targets)) {
      fs.mkdirSync(path.dirname(file), { recursive: true });
    }
    fs.writeFileSync(targets.controller, RESTORED_CONTROLLER);
    fs.writeFileSync(targets.loop, fixtureSource.agentMethods);
  }
  return { root, home, aiBase, targets, close: () => removeTreeNoFollowSync(root) };
}

async function withFixture(options, fn) {
  const f = fixture(options);
  const prevHome = process.env.DSH_HOME;
  const prevSurface = process.env.DSH_SURFACE;
  // 指向 fixture：apply 前的 profile 快照写到临时 home，绝不碰真实 ~/.dsh。
  process.env.DSH_HOME = f.home;
  process.env.DSH_SURFACE = "desktop";
  try {
    return await fn(f);
  } finally {
    if (prevHome === undefined) delete process.env.DSH_HOME;
    else process.env.DSH_HOME = prevHome;
    if (prevSurface === undefined) delete process.env.DSH_SURFACE;
    else process.env.DSH_SURFACE = prevSurface;
    f.close();
  }
}

/**
 * 取一条"目标文件在本 fixture 里全都不存在"的补丁，用 patchStatus 实证，
 * 而不是按 ALL_PATCHES 的顺序假定第一条就缺——#74/#87 这类补丁的目标恰好是
 * fixture 里建出来的 agent-loop，靠顺序撞运气会在补丁重排后误判。
 */
async function absentPatch(f) {
  const opts = { dshHome: f.home, surface: "desktop" };
  const status = await patchStatus(f.aiBase, ALL_PATCHES, opts);
  const found = ALL_PATCHES.find(
    (p) => p.id !== APPLIES.id && status[p.id] === "missing_file",
  );
  assert.ok(found, "本 fixture 里应至少有一条目标文件全缺的补丁");
  return found;
}

test("a patch whose target files are all absent is reported, not thrown", async () => {
  await withFixture({}, async (f) => {
    const absent = await absentPatch(f);
    const report = await applyPatches(f.aiBase, [absent]);
    assert.equal(report.length, 1);
    assert.equal(report[0].patch_id, absent.id);
    assert.equal(
      report[0].status,
      "missing_file",
      "目标文件全缺时记 missing_file，整次 apply 不能抛异常",
    );
    assert.ok(report[0].missing > 0);
  });
});

test("a missing target does not stop the patches that follow it", async () => {
  await withFixture({ withHostFiles: true }, async (f) => {
    const absent = await absentPatch(f);
    const report = await applyPatches(f.aiBase, [absent, APPLIES]);
    assert.equal(report.length, 2, "第二条补丁必须也被处理");
    assert.equal(report[0].patch_id, absent.id);
    assert.equal(report[0].status, "missing_file");
    const applied = report[1];
    assert.equal(applied.patch_id, APPLIES.id);
    assert.equal(applied.status, "applied", "后面的补丁不能被前一条的缺失连坐");
    assert.ok(
      (fs.readFileSync(f.targets.controller, "utf8")).includes(NATIVE_QUEUE_GUARD),
      "补丁内容必须真的写进磁盘",
    );
  });
});

test("re-applying after a missing target stays idempotent", async () => {
  await withFixture({ withHostFiles: true }, async (f) => {
    const absent = await absentPatch(f);
    await applyPatches(f.aiBase, [absent, APPLIES]);
    const once = fs.readFileSync(f.targets.controller, "utf8");
    const report = await applyPatches(f.aiBase, [absent, APPLIES]);
    assert.equal(report[1].status, "already", "第二次应判 already，不重复写");
    assert.equal(fs.readFileSync(f.targets.controller, "utf8"), once);
  });
});
