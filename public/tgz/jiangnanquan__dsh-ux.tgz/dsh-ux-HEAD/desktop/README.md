# dsh-desktop

> ## ⚠️ 已废弃(Deprecated)
>
> **不要再安装这一层。** 官方桌面版(`/Applications/DeepSeek Harness.app`)已经自带 dsh 运行时与 Electron 壳(`@deepseek-ai/dsh-desktop-host`),本目录做的一切——无边框窗口、拉起后端、认证打通——它都覆盖了,而且不需要你自己维护 Electron 与 dsh 的版本锁定。
>
> - **装插件到官方桌面版**:见仓库根目录 [INSTALL.md](../INSTALL.md) 的 §2b(注意 `desktop` profile 由应用独占,`dsh plugin --profile desktop …` 会被拒绝)。
> - **本目录保留原因**:历史参考。`node_modules/` 未被版本控制,可随时删除。
> - **已知失效点**:`package.json` 里锁的 `@deepseek-ai/dsh@0.1.5-rc.1` 已是旧版本;dsh 0.2.0 起 `dsh-client-runtime` 等包已不存在,按下面的方式跑起来也不会与新版 dsh 对齐。

dsh(DeepSeek Harness)的无边框沉浸式桌面壳:把 dsh web 前端装进一个无边框 Electron 窗口,自带悬浮窗口控制。

## 特性

- **无边框窗口**(`frame: false`),顶部 12px 拖拽带,右上角**指针靠近才显现**全屏 / 最小化 / 关闭按钮(收起时不占命中区域,不会挡住页面右上角自己的按钮)
- **双击即用**:`启动 DSH.command` 自动检测后端 → 未运行则拉起 `dsh web --no-open` → 等就绪 → 开窗 → 退出时只清理自己拉起的后端(你自己开的 dsh 不受影响)
- **认证自动打通**(dsh 0.1.5+ 的浏览器会话):自己拉起的后端拿启动日志里的官方 `?token=` 入口换 cookie;复用已有后端时用 `~/.dsh/.credentials.yaml` 里的签名密钥自签一枚等价 cookie。两条路都走不通时显示可操作的提示页,而不是白底 401
- 快捷键:`Cmd+Q` 退出、`Cmd+Shift+F` / `F11` 切换全屏、`Cmd+R` 重载
- 安全配置:`contextIsolation` 开启、`nodeIntegration` 关闭,窗口控制经 preload `contextBridge` 暴露

## 平台要求

- **macOS**(启动脚本为 zsh `.command`;窗口逻辑本身跨平台,其他系统可直接 `electron main.js`)
- Node.js + 本机已能运行 `dsh web`(即已配置 DSH profile)

## 使用

### 方式一:双击启动(推荐)

```bash
npm install        # 首次使用,安装 Electron + dsh(约 2 分钟)
open "启动 DSH.command"
```

脚本内部:检测 `127.0.0.1:3080` 是否已有 dsh(0.1.5 起无 cookie 的探测请求会拿到 401,所以按「能否拿到 HTTP 状态码」判断在不在)→ 无则用本地锁定依赖 `node_modules/.bin/dsh` 拉起 `dsh web --no-open --port 3080`(缺失时回退 `npx`)→ 等端口就绪并抓取带 `?token=` 的官方入口 → 启动 Electron 壳 → 壳退出后清理本次拉起的 dsh。

### 升级依赖

```bash
open "升级 DSH.command"   # 双击即可
```

对比 npm registry 最新版 → 升级 `@deepseek-ai/dsh`(精确锁版)与 `electron` → 失败自动回滚 `package.json` / `package-lock.json`。与启动脚本分离:启动器只管启动,升级器只管升级。dsh 正在运行时升级,需重启 dsh 使新版本生效。

### 方式二:手动启动

```bash
npm install
npm start          # 等价于 electron main.js,默认连 http://127.0.0.1:3080
```

## 环境变量

| 变量 | 作用 |
|------|------|
| `DSH_PORT` | 后端端口,默认 `3080`(启动脚本读取,并同步给壳的 `DSH_URL`,避免端口不一致串到别的实例) |
| `DSH_URL` | 覆盖窗口加载的目标地址,默认 `http://127.0.0.1:3080`(显式设置时以你为准) |
| `DSH_AUTH_URL` | 启动脚本注入:本次后端的官方 token 入口。壳优先走它;缺省时回退到凭证自签 cookie |
| `DSH_SNAPSHOT` | 截图调试模式:窗口加载 4 秒后把页面截图写到该路径并退出(认证失败提示页同样会截图),例如 `DSH_SNAPSHOT=/tmp/x.png npm start` |

## License

MIT
