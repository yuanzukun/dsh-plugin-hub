# ADR-0001:强化执行通道 — 隔离子会话 agent 为主,llm 直调为降级

- 状态:已接受
- 日期:2026-08-19

## 背景

「强化」需要一次模型调用:输入 = 原始提示词 + 有界对话上下文 + 工作目录内检索到的相关文件;输出 = 增强提示词。候选通道有三:

1. **通道 A:llm 直调** — 插件在 host 内解析会话的 provider/model 路由,`ctx.llm.stream` 单次调用,检索由插件自己完成(glob/grep/read 的有界扫描)。
2. **通道 B:隔离子会话 agent** — `ctx.agents.create` 建临时子会话(继承父会话工具组合 + 只读工具限制 + 强化专用 persona),`agent.followup` 跑一轮完整 agent 循环(带工具,文件定位由 agent 自己完成),读回子会话末条助手消息后 `dispose`,主会话历史零污染。
3. **通道 C:主会话内半可见调用** — 在用户当前会话里注入一条消息并读取回复(会污染主历史,且与「还原/手动发送」的交互语义冲突)。

## 决策

采用 **B 为主、A 为降级**。B 超时 90s;A 在 B 的创建或执行失败时兜底,超时 60s。两者共用同一 persona 与 payload 结构。

## 理由

1. **语义一致**:用户需求明言「整个功能与给子代理写任务提示词类似」。通道 B 让「定位关联文件」由 agent 的工具调用完成,而不是插件自建检索器——检索质量、检索边界的控制都随模型能力走,且天然遵守仓库已有的 ignore/观察策略。
2. **零污染**:子会话独立 `sessionId`,历史不进主对话;「还原」只需回退草稿文本,无需清理会话记录。
3. **降级保底**:通道 B 依赖 agent 工厂、工具组合、父会话存活等较多前置条件;A 只需 llm 服务与路由,保证「强化」在任何可发消息的会话里都可用(降级时无文件检索,输出纯改写,与「零命中静默降级」的产品语义一致)。

## 后果

- 正面:检索交给 agent;主历史干净;两条通道的 persona 与输出格式共享同一份定义,行为一致。
- 负面:通道 B 需要创建/销毁临时子会话,延迟与 token 成本高于纯直调;无工具时(composeFrom 失败)B 退化为纯改写,由 A 兜底同语义。
- 风险与缓解:子会话可能继承父预设的宽工具面 → 用 `tools.restrict({allow: [glob, grep, read]})` 收紧为只读;限制注册失败(工具名未知)时不阻断创建、仅告警退化。超时通过 `activityDone` + 定时器竞争实现,超时即 `agent.cancel` 并 dispose。

## 修订(2026-08-21):通道 B 二级降级——预设组合无文本时裸子会话重试

**问题**:用户会话运行在携带「首轮机制」的 agent 预设上(如 router 预设的
`router-bootstrap`:首轮 system-prompt 组装时要求平台 shell(pwsh/bash)在工具目录中,
否则直接 throw)时,强化子会话经 `composeFrom` join 该预设的 standing composition 后,
其**首轮**恰是子会话自己的首轮——bootstrap 作用于子会话,而只读限制已把平台 shell
移出目录 → 首轮 turn 以 `router-bootstrap: no platform shell in catalog` 错误终止、
无助手文本 → 通道 B 报「没有产出文本」,通道 A 又常因本地 LLM 空响应报「LLM 无输出」,
用户看到「强化失败」。(2026-08-21 诊断:`enhance-child-no-text` 事件落盘取证确认。)

**决策**:通道 B 失败(非超时、非客户端取消)且无文本时,以**不 join 预设的裸子会话**
重试一次:不 `composeFrom`、不 `restrict`,只注入强化 persona(与专用模型 waterfall)。
裸子会话不落在任何预设 scope 下,预设层首轮监听不作用于它,退化为纯改写(无文件检索)——
正是本 ADR 既有的「无工具时 B 退化为纯改写」语义。超时/客户端取消为致命错误,不重试
(避免双倍预算);重试后仍无文本则按原路径降级通道 A。

## 修订(2026-08-27):访问控制——三端点仅接受本机回环来源

**问题**:强化/models/diag 三个 HTTP 端点注册在宿主 webServer 上且无来源校验。DSH web 服务经
局域网/隧道/反代暴露时(远程使用常见),非本机来源可借已知/可猜测的 `sessionId` 调 enhance
端点——以该会话路由起子代理在用户仓库做 glob/grep/read 并消耗 LLM 额度,响应中还带回含
会话上下文与文件路径的增强文本;diag 端点可读写诊断日志,models 端点泄漏 provider/模型
配置。(2026-08-27 竞品分析:同名插件 LCQ-1024 已有 loopback-only 校验,本插件交叉核对确认缺口。)

**决策**:三端点统一前置回环校验——仅接受 `127.0.0.1`/`::1`/`::ffff:127.0.0.1`(Node 对
本机连接的 remoteAddress 归一形态),其余地址与缺失 socket 一律 403(fail-closed),不返回
业务错误信息;来源 IP 以 `foreign-request-rejected` 信标落盘取证。权衡:经远程方式浏览 DSH
web 的用户在远端页面使用强化按钮将不可用(端点只认服务所在机的回环)——安全优先,有意取舍。

## 修订(2026-08-27):双通道输出截断检测——截断不得静默覆盖草稿

**问题**:两通道都可能被 `maxTokens` 截断:通道 A 的 finish chunk `reason.kind ===
"max-tokens"` 此前未处理(只处理 `error`);通道 B 子会话的最终文本若在某一步被输出上限截断,
同样无信号。截断损坏的提示词(正文半截、参考文件节缺半边)被静默替换进输入框,用户无从知晓。
(竞品参照:LCQ-1024 有 `truncated` 标志 + UI 尾注;Fishsb 有截断检测 + 参考节修复。)

**决策**:两通道统一产 `truncated` 布尔——通道 A 在流式消费中捕获 `max-tokens` 终态;通道 B
以纯函数 `childOutputTruncated` 读取子会话事件流:取与最终文本同源的事件(最后一个有非空文本
的 `assistant/message`),向前找其紧邻的 `assistant/chunk` finish 块(`data.chunk` 为 LLM 原始
chunk,实测与 message seq 相邻),`reason.kind === "max-tokens"` 即该步被截断(未知情形不误报,
fail-open 到无告警)。截断时响应携带 `truncated: true`,客户端弹显式告警 toast(草稿仍替换、
「还原 ↺」入口保持可用),两端口分别落 `enhance-truncated` 信标(host 记通道与草稿长度,
client 记客户端侧确认)。UI 零功能破坏:不改动隔离子会话执行模型、skill 引用保留与单级还原。
