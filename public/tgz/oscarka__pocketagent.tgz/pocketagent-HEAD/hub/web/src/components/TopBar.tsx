import { h, Fragment } from 'preact';

export function TopBar() {
  return (
    <Fragment>
      {/* 1. 唯一极简顶栏 */}
      <header class="top-bar" id="mobileTopHostBtn">
          <div class="top-bar-left">
            <button
              type="button"
              class="host-switcher-btn"
              onClick={() => (window as any).openHostSheet?.()}
            >
              <span class="status-dot" id="topHostDot"></span>
              <span class="host-switcher-name" id="topHostName">
                连接中...
              </span>
              <span class="host-switcher-caret">▾</span>
            </button>
            <button
              type="button"
              id="turboBadgeBtn"
              onClick={() => (window as any).openTurboGuideSheet?.()}
              style="border:1px solid #a7f3d0;background:#ecfdf5;color:#059669;border-radius:999px;padding:4px 9px;font-size:11.5px;font-weight:700;cursor:pointer;white-space:nowrap;flex-shrink:0;"
            >
              ⚡ 极速
            </button>
          </div>
          <div style="display:flex;align-items:center;gap:6px;flex-shrink:0;">
            <button
              type="button"
              data-lang-toggle="1"
              onClick={() => (window as any).toggleLangPreference?.()}
              style="border:1px solid var(--border);background:var(--subtle);color:var(--text-secondary);border-radius:999px;padding:4px 9px;font-size:11.5px;font-weight:700;cursor:pointer;white-space:nowrap;flex-shrink:0;"
            >
              🌐 EN
            </button>
            <button
              type="button"
              class="new-chat-btn"
              onClick={() => (window as any).openNewTaskSheet?.()}
            >
              <span>＋</span>
              <span>新建对话</span>
            </button>
          </div>
      </header>

      {/* 交互式体验沙盒条（仅 ?demo=1 时显示，零后台数据泄露） */}
      <div id="demoModeBanner" class="demo-mode-banner" style="display:none;">
        <div class="demo-mode-text" id="demoModeBannerText">
          ✨ Interactive Demo · Swipe cards or tap Approve
        </div>
        <div class="demo-mode-actions">
          <button
            type="button"
            class="demo-pill-btn demo-pill-primary"
            onClick={() => (window as any).demoCopyNpx?.()}
            title="Copy npx pocketagent"
          >
            📋 npx
          </button>
          <button
            type="button"
            class="demo-pill-btn"
            onClick={() => (window as any).demoResetSandbox?.()}
            title="Reset Demo"
          >
            ↻
          </button>
          <a
            class="demo-pill-btn"
            href="https://github.com/oscarka/pocketagent"
            target="_blank"
            rel="noopener noreferrer"
          >
            ⭐ GitHub
          </a>
        </div>
      </div>

      {/* 断线重连状态细条 (#11) */}
      <div
        id="connectionStatusBanner"
        class="connection-status-banner"
        style="display:none;"
        onClick={() => (window as any).manualReconnectNow?.()}
      >
        <span>⚠️ 网络连接中断，正在自动重连…</span>
        <span style="text-decoration:underline;margin-left:6px;font-weight:700;">点此立即重试</span>
      </div>

      {/* 2. 搜索框 + 智能状态/项目筛选条 */}
      <div class="search-and-filter" id="searchAndFilterBox">
        <div class="search-box-wrap">
          <div class="search-box">
            <span style="font-size:13px;color:#94a3b8;">🔍</span>
            <input
              id="searchInput"
              placeholder="搜索对话标题、项目或内容..."
              onInput={() => (window as any).onSearchInput?.()}
            />
            <button
              type="button"
              class="search-clear"
              id="searchClearBtn"
              onClick={() => (window as any).clearSearch?.()}
            >
              ✕
            </button>
          </div>
        </div>
        <nav class="filter-strip" id="projectStrip"></nav>
      </div>
    </Fragment>
  );
}

