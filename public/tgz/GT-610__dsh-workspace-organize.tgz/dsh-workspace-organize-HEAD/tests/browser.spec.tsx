/**
 * The registered browser, mounted in jsdom against the primitives double.
 *
 * These prove the plugin's own wiring: which rows appear for a given catalog,
 * what a row's verbs do, and that the group and workspace menus reach the right
 * operation. The shipped primitives' appearance is the shell's business.
 */
import { act, cleanup, render, screen, waitFor, within } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import type { SessionListState, SessionSummary } from '@deepseek-ai/dsh-api-session-controller/client'
import type { WorkspaceView } from '@deepseek-ai/dsh-api-workspace-controller/client'
import type { SessionId } from '@deepseek-ai/dsh-session/types'
import type { SessionStatusSnapshot } from '@deepseek-ai/dsh-client-ui-session/client'
import { MAX_GROUP_NAME_LENGTH } from '../src/shared/contract.ts'
import { GroupedBrowser } from '../src/client/Browser.tsx'
import type { OrganizeBrowserProps, Services } from '../src/client/contract.ts'
import { ARCHIVED_FILTER_STORAGE_KEY, EXPANSION_STORAGE_KEY } from '../src/client/groups.ts'
import { messages, translate } from './i18n.ts'

const id = (value: string): SessionId => value as SessionId

/** One list row with the fields the browser reads. */
function sessionRow(value: string, overrides: Partial<SessionSummary> = {}): SessionSummary {
  return {
    id: id(value),
    title: value,
    displayTitle: value,
    running: false,
    blank: false,
    updatedAt: Date.now(),
    retainedBy: {},
    ...overrides,
  } as SessionSummary
}

/** One workspace view over the sessions it accounts for. */
function workspaceView(title: string, members: readonly string[]): WorkspaceView {
  return {
    workspaceId: title,
    path: `C:/repos/${title}`,
    title,
    sessionIds: members.map(id),
    createdAt: '2026-01-01T00:00:00.000Z',
    updatedAt: '2026-01-01T00:00:00.000Z',
  } as unknown as WorkspaceView
}

/** The operations a mounted browser should reach, recorded per call. */
function fakeServices() {
  return {
    openSession: vi.fn(),
    startSession: vi.fn(),
    archiveSession: vi.fn().mockResolvedValue(undefined),
    unarchiveSession: vi.fn().mockResolvedValue(undefined),
    renameWorkspace: vi.fn().mockResolvedValue(undefined),
    renameSession: vi.fn().mockResolvedValue(undefined),
    deleteWorkspace: vi.fn().mockResolvedValue(undefined),
    createWorkspace: vi.fn().mockResolvedValue(undefined),
    pickDirectory: vi.fn().mockResolvedValue(null),
  } satisfies Services
}

/** The Host's running-work refusal, in the shape the browser reads. */
function archiveRefusal(sessionId: string) {
  return Object.assign(new Error('session-active'), {
    name: 'WorkspaceArchiveError',
    rpcError: { code: 'workspace/session-active', details: { sessionId, activity: [{ kind: 'turn' }] } },
  })
}

/**
 * Props for one mount: real hooks, fake snapshots, recorded operations.
 * @param listPhase - arrival lifecycle of the session catalog; `pending` is an
 * empty catalog that has not arrived rather than one that is empty in fact.
 */
function propsFor(
  workspaces: readonly WorkspaceView[],
  sessions: readonly SessionSummary[],
  services: Services,
  statuses: SessionStatusSnapshot = new Map(),
  archived: readonly string[] = [],
  listPhase: SessionListState['phase'] = 'ready',
  wide = true,
): OrganizeBrowserProps {
  const list = {
    ids: sessions.map(row => row.id),
    byId: Object.fromEntries(sessions.map(row => [row.id, row])),
    projectionsBySession: {},
    phase: listPhase,
  } as unknown as SessionListState
  const workspaceSnapshot = {
    items: workspaces,
    archivedSessionIds: archived.map(id),
    pinnedSessionIds: [],
    state: 'idle',
    phase: 'ready',
  }
  return {
    wide,
    expandSidebar: vi.fn(),
    useWorkspaces: <T,>(select: (snapshot: unknown) => T): T => select(workspaceSnapshot),
    useSessions: <T,>(select: (snapshot: unknown) => T): T => select(list),
    useSessionStatus: <T,>(select: (snapshot: unknown) => T): T => select(statuses),
    usePanelInfo: <T,>(select: (snapshot: unknown) => T): T => select({ activePanelId: null }),
    t: translate(),
    services,
  } as unknown as OrganizeBrowserProps
}

/** The catalog one mount renders: one group holding one workspace. */
function mountBrowser(services: Services = fakeServices()) {
  const current = sessionRow('blank-current', {
    blank: true,
    retainedBy: { mainView: 1 } as SessionSummary['retainedBy'],
  })
  const spent = sessionRow('blank-spent', { blank: true })
  const named = sessionRow('named')
  const repo = workspaceView('repo', ['named', 'blank-spent', 'blank-current'])
  const other = workspaceView('other', [])
  render(<GroupedBrowser {...propsFor([repo, other], [current, spent, named], services)} />)
  return { services }
}

beforeEach(() => {
  localStorage.clear()
  // The browser loads its group document on mount; the Host answers with a group
  // holding `repo` so the grouped path renders instead of the ungrouped one.
  vi.stubGlobal('fetch', vi.fn(async (_url: string, init?: RequestInit) => ({
    ok: true,
    json: async () => (init?.method === 'POST'
      ? { version: 1, groups: [] }
      : { version: 1, groups: [{ id: 'g1', name: 'Work', workspaceIds: ['repo'] }] }),
  })))
})

afterEach(() => {
  // No globals in this config, so Testing Library's automatic cleanup is off:
  // without this, every mount would leave its tree behind and text queries
  // would start matching several copies.
  cleanup()
  vi.unstubAllGlobals()
})

describe('GroupedBrowser rows', () => {
  it('renders the group, its workspace, and only the visible sessions', async () => {
    mountBrowser()
    expect(await screen.findByText('Work')).toBeDefined()
    expect(screen.getByText('repo')).toBeDefined()
    expect(screen.getByText('other')).toBeDefined()
    // The retained placeholder and the real session; the spent draft is gone.
    expect(screen.getByText(messages.blankSession)).toBeDefined()
    expect(screen.getByText('named')).toBeDefined()
    expect(screen.queryByText('blank-spent')).toBeNull()
  })

  it('gives the placeholder no timestamp and no verbs', async () => {
    mountBrowser()
    await screen.findByText(messages.blankSession)
    const placeholder = document.querySelector('[data-row-key="session:blank-current"]')
    expect(placeholder).not.toBeNull()
    expect(placeholder?.querySelector('.dwo-time')).toBeNull()
    expect(placeholder?.querySelector('.dwo-actions')).toBeNull()
    // The real session in the same workspace keeps both.
    const named = document.querySelector('[data-row-key="session:named"]')
    expect(named?.querySelector('.dwo-time')).not.toBeNull()
    expect(named?.querySelector('.dwo-actions')).not.toBeNull()
  })

  it('opens a session when its row is clicked', async () => {
    const { services } = mountBrowser()
    await screen.findByText('named')
    await userEvent.click(screen.getByText('named'))
    expect(services.openSession).toHaveBeenCalledWith('named')
  })

  it('rolls member statuses up into the group row', async () => {
    const statuses: SessionStatusSnapshot = new Map([
      [id('named'), { running: true, pendingInteraction: undefined, completionUnread: false }],
    ])
    const services = fakeServices()
    const current = sessionRow('blank-current', { blank: true, retainedBy: { mainView: 1 } as SessionSummary['retainedBy'] })
    const named = sessionRow('named')
    const repo = workspaceView('repo', ['named', 'blank-current'])
    render(<GroupedBrowser {...propsFor([repo], [current, named], services, statuses)} />)
    await screen.findByText('Work')
    const count = document.querySelector('.dwo-count')
    expect(count?.textContent).toContain(`1 ${messages.unitWorkspaces}`)
    expect(count?.textContent).toContain(`1 ${messages.unitRunning}`)
    expect(count?.querySelector('[data-state-dot="ongoing"]')).not.toBeNull()
  })

  it('leaves a subagent child to the parent header that shows it', async () => {
    const current = sessionRow('blank-current', {
      blank: true,
      retainedBy: { mainView: 1 } as SessionSummary['retainedBy'],
    })
    const named = sessionRow('named')
    // The catalog carries spawned children; the shipped browser never gives them
    // a top-level row of their own, and neither may this tree.
    const child = sessionRow('spawned', { origin: 'subagent', parentId: id('named') })
    const repo = workspaceView('repo', ['named', 'spawned', 'blank-current'])
    render(<GroupedBrowser {...propsFor([repo], [current, named, child], fakeServices())} />)
    await screen.findByText('named')
    expect(document.querySelector('[data-row-key="session:spawned"]')).toBeNull()
  })
})

/**
 * A catalog whose only Workspace owns one Session, while further Sessions
 * belong to no Workspace at all — the shipped browser's Ungrouped bucket.
 * @param services - the operations the mount should reach.
 * @param extra - Sessions to place in the catalog outside every Workspace.
 * @param archived - archive-set members.
 * @returns the mount and its recorded operations.
 */
function mountUnowned(
  services: Services = fakeServices(),
  extra: readonly SessionSummary[] = [sessionRow('loose', { title: 'Loose conversation', displayTitle: 'Loose conversation' })],
  archived: readonly string[] = [],
) {
  const named = sessionRow('named')
  const repo = workspaceView('repo', ['named'])
  render(<GroupedBrowser {...propsFor([repo], [named, ...extra], services, new Map(), archived)} />)
  return { services }
}

/** The unowned bucket's node, found by its header row. */
function bucket(): Element | null | undefined {
  return document.querySelector('[data-row-key="unowned"]')?.parentElement
}

/** The stored disclosure choices, as the mirror holds them. */
function storedExpansion(): Record<string, boolean> {
  return JSON.parse(localStorage.getItem(EXPANSION_STORAGE_KEY) ?? '{}') as Record<string, boolean>
}

describe('GroupedBrowser unowned bucket', () => {
  it('renders a session no workspace owns, with no workspace row to reach it through', async () => {
    mountUnowned()
    expect(await screen.findByText(messages.ungroupedSessions)).toBeDefined()
    const row = document.querySelector('[data-row-key="session:loose"]')
    expect(row).not.toBeNull()
    expect(row?.textContent).toContain('Loose conversation')
    // The bucket counts what it holds, so a folded bucket still says it is there.
    expect(bucket()?.querySelector('.dwo-count')?.textContent).toContain(`1 ${messages.unitSessions}`)
  })

  it('lists only the sessions no workspace accounts for', async () => {
    mountUnowned()
    await screen.findByText(messages.ungroupedSessions)
    const rows = bucket()?.querySelectorAll('.dwo-session-row') ?? []
    expect(rows).toHaveLength(1)
    expect(bucket()?.querySelector('[data-row-key="session:named"]')).toBeNull()
  })

  it('opens an unowned session when its row is clicked', async () => {
    const { services } = mountUnowned()
    const row = await screen.findByText('Loose conversation')
    await userEvent.click(row)
    expect(services.openSession).toHaveBeenCalledWith('loose')
  })

  it('keeps a spent draft out of the bucket', async () => {
    mountUnowned(fakeServices(), [sessionRow('loose'), sessionRow('spent-draft', { blank: true })])
    await screen.findByText(messages.ungroupedSessions)
    expect(bucket()?.querySelector('[data-row-key="session:loose"]')).not.toBeNull()
    expect(bucket()?.querySelector('[data-row-key="session:spent-draft"]')).toBeNull()
  })

  it('keeps a subagent child out of the bucket', async () => {
    mountUnowned(fakeServices(), [sessionRow('loose'), sessionRow('spawned', { origin: 'subagent' })])
    await screen.findByText(messages.ungroupedSessions)
    expect(bucket()?.querySelector('[data-row-key="session:loose"]')).not.toBeNull()
    expect(bucket()?.querySelector('[data-row-key="session:spawned"]')).toBeNull()
  })

  it('follows the archived filter', async () => {
    mountUnowned(
      fakeServices(),
      [sessionRow('loose'), sessionRow('archived-loose')],
      ['archived-loose'],
    )
    await screen.findByText(messages.ungroupedSessions)
    expect(bucket()?.querySelector('[data-row-key="session:archived-loose"]')).toBeNull()
    await chooseViewOption(messages.showArchived)
    expect(bucket()?.querySelector('[data-row-key="session:archived-loose"]')).not.toBeNull()
    await chooseViewOption(messages.onlyArchived)
    expect(bucket()?.querySelector('[data-row-key="session:loose"]')).toBeNull()
    expect(bucket()?.querySelector('[data-row-key="session:archived-loose"]')).not.toBeNull()
  })

  it('counts an unowned archived row as content under the archived-only filter', async () => {
    mountUnowned(fakeServices(), [sessionRow('archived-loose')], ['archived-loose'])
    await chooseViewOption(messages.onlyArchived)
    await screen.findByText(messages.ungroupedSessions)
    expect(document.querySelector('[data-row-key="session:archived-loose"]')).not.toBeNull()
    expect(screen.queryByText(messages.archivedOnlyEmpty)).toBeNull()
  })

  it('folds away when its header is clicked, and remembers the choice', async () => {
    mountUnowned()
    const header = await screen.findByText(messages.ungroupedSessions)
    expect(document.querySelector('[data-row-key="session:loose"]')).not.toBeNull()
    await userEvent.click(header)
    await waitFor(() => {
      expect(document.querySelector('[data-row-key="session:loose"]')).toBeNull()
    })
    // The bucket's key belongs to no workspace, so it is its own disclosure slot.
    expect(storedExpansion()['u:unowned']).toBe(false)
  })

  it('keeps its fold choice while a search hides every row of it', async () => {
    mountUnowned()
    await userEvent.click(await screen.findByText(messages.ungroupedSessions))
    await waitFor(() => { expect(storedExpansion()['u:unowned']).toBe(false) })
    // A query that matches nothing in the bucket: the bucket leaves the tree,
    // but it still has rows to come back to, so pruning must not read the
    // filtered derivation and throw the choice away.
    await userEvent.click(document.querySelector('.dwo-search-btn') as HTMLElement)
    await userEvent.type(document.querySelector('.dwo-search-input') as HTMLInputElement, 'nothing-matches')
    await waitFor(() => { expect(document.querySelector('[data-row-key="unowned"]')).toBeNull() })
    expect(storedExpansion()['u:unowned']).toBe(false)
    // Clearing the search brings the bucket back the way the operator left it.
    await userEvent.clear(document.querySelector('.dwo-search-input') as HTMLInputElement)
    await screen.findByText(messages.ungroupedSessions)
    expect(bucket()?.querySelector('[data-row-key="unowned"]')?.getAttribute('aria-expanded')).toBe('false')
  })

  it('drops the fold choice once no unowned session is left', async () => {
    // The bucket is gone for good here, so its key is stale like any other.
    localStorage.setItem(EXPANSION_STORAGE_KEY, JSON.stringify({ 'u:unowned': false }))
    mountUnowned(fakeServices(), [])
    await screen.findByText('Work')
    await waitFor(() => { expect(storedExpansion()['u:unowned']).toBeUndefined() })
  })

  it('waits for the session catalog before pruning', async () => {
    // A `pending` catalog is empty because it has not arrived, not because there
    // is nothing in it: pruning on it would drop a bucket choice a moment before
    // the rows that justify it show up.
    localStorage.setItem(EXPANSION_STORAGE_KEY, JSON.stringify({ 'u:unowned': false }))
    render(<GroupedBrowser {...propsFor([workspaceView('repo', [])], [], fakeServices(), new Map(), [], 'pending')} />)
    await screen.findByText('Work')
    expect(storedExpansion()['u:unowned']).toBe(false)
  })

  it('reports no workspaces only when nothing at all would render', async () => {
    // No groups in the document, so every Workspace — including the unowned
    // bucket — is judged on its own.
    vi.stubGlobal('fetch', vi.fn(async () => ({ ok: true, json: async () => ({ version: 1, groups: [] }) })))
    const view = render(<GroupedBrowser {...propsFor([], [], fakeServices())} />)
    await waitFor(() => { expect(screen.getByText(messages.noWorkspaces)).toBeDefined() })
    view.unmount()
    // A loose session is a row even with no Workspace at all, so the empty state
    // must not claim the tree is empty.
    render(<GroupedBrowser {...propsFor([], [sessionRow('loose')], fakeServices())} />)
    await screen.findByText(messages.ungroupedSessions)
    expect(screen.queryByText(messages.noWorkspaces)).toBeNull()
  })
})

/**
 * The verb buttons of one row.
 *
 * They live in a hover strip (`display:none` until the row is hovered), so role
 * queries must include hidden elements to reach them.
 * @param row - the row element to search.
 * @returns its buttons, in DOM order.
 */
function rowButtons(row: Element): HTMLElement[] {
  return within(row as HTMLElement).getAllByRole('button', { hidden: true })
}

describe('GroupedBrowser keyboard and search', () => {
  it('does not let the row swallow a child control\'s Enter', async () => {
    const { services } = mountBrowser()
    await screen.findByText('named')
    const row = document.querySelector('[data-row-key="session:named"]') as Element
    const archive = rowButtons(row)[0] as HTMLElement
    archive.focus()
    // jsdom has no native button activation on Enter, but the regression is the
    // bubbled row handler: it used to preventDefault and open the Session.
    await userEvent.keyboard('{Enter}')
    expect(services.openSession).not.toHaveBeenCalled()
    await userEvent.click(archive)
    await waitFor(() => { expect(services.archiveSession).toHaveBeenCalledWith('named') })
  })

  it('keeps a newer dialog when an older archive refusal arrives', async () => {
    const services = fakeServices()
    let refuse: ((error: unknown) => void) | undefined
    services.archiveSession = vi.fn(() => new Promise<void>((_resolve, reject) => { refuse = reject }))
    const current = sessionRow('blank-current', {
      blank: true,
      retainedBy: { mainView: 1 } as SessionSummary['retainedBy'],
    })
    const named = sessionRow('named')
    render(<GroupedBrowser {...propsFor([workspaceView('repo', ['named', 'blank-current'])], [current, named], services)} />)
    await screen.findByText('named')
    const row = document.querySelector('[data-row-key="session:named"]') as Element
    await userEvent.click(rowButtons(row)[0] as HTMLElement)
    await chooseViewOption(messages.newGroup)
    const dialog = await screen.findByRole('dialog', { hidden: true })
    expect(within(dialog).getByText(messages.newGroup)).toBeDefined()
    await act(async () => { refuse?.(archiveRefusal('named')) })
    // The delayed rejection must not replace the dialog the operator opened.
    expect(screen.getByRole('dialog', { hidden: true })).toBe(dialog)
    expect(within(dialog).getByText(messages.newGroup)).toBeDefined()
  })

  it('searches the title a row displays, not its directory fallback', async () => {
    const current = sessionRow('blank-current', {
      blank: true,
      retainedBy: { mainView: 1 } as SessionSummary['retainedBy'],
    })
    const auto = sessionRow('auto', { title: undefined, displayTitle: 'dir-name' })
    render(<GroupedBrowser {...propsFor([workspaceView('repo', ['auto', 'blank-current'])], [current, auto], fakeServices())} />)
    await screen.findByText(messages.untitled)
    await userEvent.click(document.querySelector('.dwo-search-btn') as HTMLElement)
    const input = await screen.findByPlaceholderText(messages.search)
    await userEvent.type(input, 'untitled')
    await waitFor(() => {
      expect(document.querySelector('[data-row-key="session:auto"]')).not.toBeNull()
    })
    await userEvent.clear(input)
    await userEvent.type(input, 'dir-name')
    await waitFor(() => {
      expect(document.querySelector('[data-row-key="session:auto"]')).toBeNull()
    })
  })
})

describe('GroupedBrowser shipped chrome', () => {
  it('uses the shipped New Session glyph on a workspace row', async () => {
    mountBrowser()
    await screen.findByText('repo')
    const row = document.querySelector('[data-row-key="workspace:repo"]') as Element
    expect(rowButtons(row)[1]?.querySelector('[data-icon="new-chat"]')).not.toBeNull()
  })

  it('publishes row keys that match the rendered rows', async () => {
    mountBrowser()
    await screen.findByText('Work')
    const list = document.querySelector('[data-row-keys]') as HTMLElement
    expect(list).not.toBeNull()
    const declared = list.getAttribute('data-row-keys')?.split('|') ?? []
    const rendered = Array.from(list.querySelectorAll('[data-row-key]'))
      .map(element => element.getAttribute('data-row-key'))
    expect(declared).toEqual(rendered)
  })

  it('keeps the search field mounted and expands it through the header', async () => {
    mountBrowser()
    await screen.findByText('Work')
    expect(document.querySelector('.dwo-search-input')).not.toBeNull()
    expect(document.querySelector('.dwo-search.open')).toBeNull()
    await userEvent.click(document.querySelector('.dwo-search-btn') as HTMLElement)
    expect(document.querySelector('.dwo-search.open')).not.toBeNull()
    expect(document.querySelector('.dwo-search-clear')).not.toBeNull()
    await userEvent.click(document.querySelector('.dwo-search-clear') as HTMLElement)
    expect(document.querySelector('.dwo-search.open')).toBeNull()
  })
})

describe('GroupedBrowser menus', () => {
  it('opens the workspace menu and moves the workspace out of its group', async () => {
    const { services } = mountBrowser()
    await screen.findByText('repo')
    const row = document.querySelector('[data-row-key="workspace:repo"]')
    expect(row).not.toBeNull()
    await userEvent.click(rowButtons(row as Element)[0] as HTMLElement)
    const menu = await screen.findByRole('menu', { hidden: true })
    expect(within(menu).getByText(messages.renameWorkspace)).toBeDefined()
    await userEvent.click(within(menu).getByText(messages.removeFromGroup))
    await waitFor(() => {
      expect(fetch).toHaveBeenCalledWith(expect.anything(), expect.objectContaining({ method: 'POST' }))
    })
    expect(services.renameWorkspace).not.toHaveBeenCalled()
  })

  it('starts a session from the workspace menu', async () => {
    const { services } = mountBrowser()
    await screen.findByText('repo')
    const row = document.querySelector('[data-row-key="workspace:repo"]') as Element
    await userEvent.click(rowButtons(row)[1] as HTMLElement)
    expect(services.startSession).toHaveBeenCalledWith('repo')
  })

  it('confirms a workspace deletion through the modal', async () => {
    const { services } = mountBrowser()
    await screen.findByText('repo')
    const row = document.querySelector('[data-row-key="workspace:repo"]') as Element
    await userEvent.click(rowButtons(row)[0] as HTMLElement)
    const menu = await screen.findByRole('menu', { hidden: true })
    await userEvent.click(within(menu).getByText(messages.deleteWorkspace))
    const dialog = await screen.findByRole('dialog', { hidden: true })
    expect(within(dialog).getByText(messages.deleteWorkspace)).toBeDefined()
    await userEvent.click(within(dialog).getByText(messages.ok))
    await waitFor(() => { expect(services.deleteWorkspace).toHaveBeenCalledWith('repo') })
  })

  it('offers "move out of group" only where there is a group to leave', async () => {
    mountBrowser()
    // `other` belongs to no group, so the only entry that could address its
    // placement is "move to group"; `repo` sits in `Work` and keeps both.
    const ungroupedRow = (await screen.findByText('other')).closest('[data-row-key]') as Element
    await userEvent.click(rowButtons(ungroupedRow)[0] as HTMLElement)
    const menu = await screen.findByRole('menu', { hidden: true })
    expect(within(menu).queryByText(messages.removeFromGroup)).toBeNull()
    expect(within(menu).getByText(messages.moveToGroup)).toBeDefined()
  })

  it('gives a group name field the document cap', async () => {
    // A longer name would make every save of the document a 400, which the tree
    // could only show as a save that never settles.
    mountBrowser()
    await screen.findByText('Work')
    await chooseViewOption(messages.newGroup)
    const dialog = await screen.findByRole('dialog', { hidden: true })
    const field = within(dialog).getByLabelText(messages.nameGroup) as HTMLInputElement
    expect(field.getAttribute('maxlength')).toBe(String(MAX_GROUP_NAME_LENGTH))
  })

  it('collapses every workspace from the view menu', async () => {
    mountBrowser()
    await screen.findByText('repo')
    const viewButton = document.querySelector('.dwo-head-actions .dwo-icon-btn') as HTMLElement
    await userEvent.click(viewButton)
    const menu = await screen.findByRole('menu', { hidden: true })
    await userEvent.click(within(menu).getByText(messages.collapseAll))
    await waitFor(() => {
      const stored = storedExpansion()
      expect(stored['ws:repo']).toBe(false)
      expect(stored['g:g1']).toBe(false)
    })
  })

  it('drops disclosure choices for nodes that no longer exist', async () => {
    // Keyed for a group and a workspace the catalog does not have: the mirror
    // must not accumulate them forever.
    localStorage.setItem(EXPANSION_STORAGE_KEY, JSON.stringify({
      'g:g1': true,
      'ws:repo': false,
      'g:deleted': true,
      'ws:gone-away': false,
    }))
    mountBrowser()
    await screen.findByText('Work')
    await waitFor(() => {
      const stored = storedExpansion()
      expect(Object.keys(stored).toSorted()).toEqual(['g:g1', 'ws:repo'])
      expect(stored['g:g1']).toBe(true)
      expect(stored['ws:repo']).toBe(false)
    })
  })
})

/**
 * The catalog for the archived-row cases: one group holding one workspace with
 * a live session, an archived one, and the retained placeholder.
 *
 * The placeholder matters: it keeps `repo` open, which is the shipped resting
 * shape and what makes its session rows reachable at all.
 * @returns the recorded operations the mount exposes.
 */
function mountWithArchive() {
  const current = sessionRow('blank-current', {
    blank: true,
    retainedBy: { mainView: 1 } as SessionSummary['retainedBy'],
  })
  const named = sessionRow('named')
  const gone = sessionRow('gone')
  const repo = workspaceView('repo', ['named', 'gone', 'blank-current'])
  const services = fakeServices()
  render(<GroupedBrowser {...propsFor([repo], [current, named, gone], services, new Map(), ['gone'])} />)
  return services
}

/**
 * Choose one row of the view options menu.
 * @param label - the row's visible label.
 */
async function chooseViewOption(label: string): Promise<void> {
  const viewButton = document.querySelector('.dwo-head-actions .dwo-icon-btn') as HTMLElement
  await userEvent.click(viewButton)
  const menu = await screen.findByRole('menu', { hidden: true })
  await userEvent.click(within(menu).getByText(label))
  await waitFor(() => { expect(screen.queryByRole('menu', { hidden: true })).toBeNull() })
}

/**
 * Create one group through the view menu and its dialog.
 * @param name - the name to type into the field.
 */
async function createGroup(name: string): Promise<void> {
  await chooseViewOption(messages.newGroup)
  const dialog = await screen.findByRole('dialog', { hidden: true })
  await userEvent.type(within(dialog).getByLabelText(messages.nameGroup), name)
  await userEvent.click(within(dialog).getByText(messages.ok))
  await waitFor(() => { expect(screen.queryByRole('dialog', { hidden: true })).toBeNull() })
}

describe('GroupedBrowser archived rows', () => {
  it('hides an archived row by default', async () => {
    mountWithArchive()
    await screen.findByText('named')
    expect(screen.queryByText('gone')).toBeNull()
  })

  it('shows an archived row beside the live ones and restores it', async () => {
    const services = mountWithArchive()
    await screen.findByText('named')
    await chooseViewOption(messages.showArchived)
    expect(await screen.findByText('gone')).toBeDefined()
    // An archived row keeps its hover restore button instead of an archive one.
    const row = document.querySelector('[data-row-key="session:gone"]') as Element
    await userEvent.click(rowButtons(row)[0] as HTMLElement)
    await waitFor(() => { expect(services.unarchiveSession).toHaveBeenCalledWith('gone') })
    expect(services.archiveSession).not.toHaveBeenCalled()
  })

  it('does not open an archived row', async () => {
    const services = mountWithArchive()
    await screen.findByText('named')
    await chooseViewOption(messages.showArchived)
    await userEvent.click(await screen.findByText('gone'))
    expect(services.openSession).not.toHaveBeenCalled()
  })

  it('lists nothing but archived rows under the archived-only filter', async () => {
    mountWithArchive()
    await screen.findByText('named')
    await chooseViewOption(messages.onlyArchived)
    expect(await screen.findByText('gone')).toBeDefined()
    expect(screen.queryByText('named')).toBeNull()
    expect(screen.queryByText(messages.blankSession)).toBeNull()
  })

  it('offers the way back when nothing is archived', async () => {
    const current = sessionRow('blank-current', {
      blank: true,
      retainedBy: { mainView: 1 } as SessionSummary['retainedBy'],
    })
    const named = sessionRow('named')
    const repo = workspaceView('repo', ['named', 'blank-current'])
    render(<GroupedBrowser {...propsFor([repo], [current, named], fakeServices())} />)
    await screen.findByText('named')
    await chooseViewOption(messages.onlyArchived)
    expect(await screen.findByText(messages.archivedOnlyEmpty)).toBeDefined()
    await userEvent.click(screen.getByText(messages.viewOtherSessions))
    expect(await screen.findByText('named')).toBeDefined()
  })

  it('says "no matches" when the archive holds rows the query misses', async () => {
    mountWithArchive()
    await screen.findByText('named')
    await chooseViewOption(messages.onlyArchived)
    expect(await screen.findByText('gone')).toBeDefined()
    // `gone` is archived but does not match: the empty state must name the
    // search, not claim the archive is empty.
    await userEvent.click(document.querySelector('.dwo-search-btn') as HTMLElement)
    await userEvent.type(await screen.findByPlaceholderText(messages.search), 'zzz')
    expect(await screen.findByText(messages.noMatches)).toBeDefined()
    expect(screen.queryByText(messages.archivedOnlyEmpty)).toBeNull()
    expect(screen.queryByText(messages.viewOtherSessions)).toBeNull()
  })

  it('remembers the filter across a reload', async () => {
    mountWithArchive()
    await screen.findByText('named')
    await chooseViewOption(messages.onlyArchived)
    expect(localStorage.getItem(ARCHIVED_FILTER_STORAGE_KEY)).toBe('only')
  })

  it('archives a group counting only live, non-blank sessions', async () => {
    const services = mountWithArchive()
    await screen.findByText('repo')
    const groupRow = document.querySelector('[data-row-key="group:g1"]') as Element
    await userEvent.click(rowButtons(groupRow)[0] as HTMLElement)
    const menu = await screen.findByRole('menu', { hidden: true })
    await userEvent.click(within(menu).getByText(messages.archiveGroup))
    const dialog = await screen.findByRole('dialog', { hidden: true })
    // One live session: `gone` is already archived and the placeholder has no
    // content, so neither is promised nor touched.
    expect(within(dialog).getByText(messages.archiveGroupBody(1))).toBeDefined()
    await userEvent.click(within(dialog).getByText(messages.ok))
    await waitFor(() => { expect(services.archiveSession).toHaveBeenCalledWith('named') })
    expect(services.archiveSession).not.toHaveBeenCalledWith('gone')
    expect(services.archiveSession).not.toHaveBeenCalledWith('blank-current')
  })

  it('asks before stopping running work, then archives', async () => {
    const services = fakeServices()
    // The Host's refusal shape: the class name and RPC code are what the
    // browser reads; class identity is not shared across bundles.
    const refusal = Object.assign(new Error('session-active'), {
      name: 'WorkspaceArchiveError',
      rpcError: {
        code: 'workspace/session-active',
        details: { sessionId: 'named', activity: [{ kind: 'turn' }] },
      },
    })
    services.archiveSession = vi.fn()
      .mockRejectedValueOnce(refusal)
      .mockResolvedValue(undefined)
    const current = sessionRow('blank-current', {
      blank: true,
      retainedBy: { mainView: 1 } as SessionSummary['retainedBy'],
    })
    const named = sessionRow('named')
    render(<GroupedBrowser {...propsFor([workspaceView('repo', ['named', 'blank-current'])], [current, named], services)} />)
    await screen.findByText('named')
    const row = document.querySelector('[data-row-key="session:named"]') as Element
    await userEvent.click(rowButtons(row)[0] as HTMLElement)
    const dialog = await screen.findByRole('dialog', { hidden: true })
    expect(within(dialog).getByText(messages.archiveConfirmTitle)).toBeDefined()
    expect(within(dialog).getByText(messages.activityTurn)).toBeDefined()
    // Nothing was stopped before the operator confirmed.
    expect(services.archiveSession).toHaveBeenCalledTimes(1)
    await userEvent.click(within(dialog).getByText(messages.archiveConfirmAction))
    await waitFor(() => {
      expect(services.archiveSession).toHaveBeenNthCalledWith(1, 'named')
      expect(services.archiveSession).toHaveBeenNthCalledWith(2, 'named', { stopActivity: true })
    })
  })

  it('does not stop work for a failure that is not a running-work refusal', async () => {
    const services = fakeServices()
    services.archiveSession = vi.fn().mockRejectedValue(new Error('carrier down'))
    const warn = vi.spyOn(console, 'warn').mockImplementation(() => undefined)
    const current = sessionRow('blank-current', {
      blank: true,
      retainedBy: { mainView: 1 } as SessionSummary['retainedBy'],
    })
    const named = sessionRow('named')
    render(<GroupedBrowser {...propsFor([workspaceView('repo', ['named', 'blank-current'])], [current, named], services)} />)
    await screen.findByText('named')
    const row = document.querySelector('[data-row-key="session:named"]') as Element
    await userEvent.click(rowButtons(row)[0] as HTMLElement)
    await waitFor(() => {
      expect(warn).toHaveBeenCalledWith('workspace-organize: archive refused', 'named', expect.any(Error))
    })
    expect(services.archiveSession).toHaveBeenCalledTimes(1)
    expect(screen.queryByRole('dialog', { hidden: true })).toBeNull()
  })

  it('reports a refused restore instead of leaving it unhandled', async () => {
    const services = mountWithArchive()
    services.unarchiveSession = vi.fn().mockRejectedValue(new Error('carrier down'))
    const warn = vi.spyOn(console, 'warn').mockImplementation(() => undefined)
    await screen.findByText('named')
    await chooseViewOption(messages.showArchived)
    const row = document.querySelector('[data-row-key="session:gone"]') as Element
    await userEvent.click(rowButtons(row)[0] as HTMLElement)
    await waitFor(() => {
      expect(warn).toHaveBeenCalledWith('workspace-organize: restore refused', 'gone', expect.any(Error))
    })
  })
})

/**
 * A `fetch` double whose writes are held until the test settles them.
 *
 * The GET the browser opens with answers directly; each POST is recorded and left
 * pending, so a test can decide the order the Host answers in — and see whether
 * the client got that far at all.
 * @returns the write bodies in issue order, and one settle function per write.
 */
function heldWrites() {
  const bodies: string[] = []
  const settles: Array<(ok: boolean) => void> = []
  vi.stubGlobal('fetch', vi.fn((_url: string, init?: RequestInit) => {
    if (init?.method !== 'POST') {
      return Promise.resolve({
        ok: true,
        json: async () => ({ version: 1, groups: [{ id: 'g1', name: 'Work', workspaceIds: ['repo'] }] }),
      })
    }
    bodies.push(String(init.body))
    return new Promise((resolve) => {
      settles.push(ok => resolve({
        ok,
        status: ok ? 200 : 500,
        text: async () => (ok ? '' : 'invalid group document'),
      }))
    })
  }))
  return { bodies, settles }
}

/** The group names of the writes issued so far, newest group of each document. */
function writeNames(bodies: readonly string[]): Array<string | undefined> {
  return bodies.map((body) => {
    const doc = JSON.parse(body) as { groups: Array<{ name: string }> }
    return doc.groups.at(-1)?.name
  })
}

describe('GroupedBrowser saves', () => {
  it('issues one write at a time, in the order the edits were made', async () => {
    // The Host serializes by arrival, not by edit order, so two POSTs racing each
    // other can commit an older document last. The second edit must wait.
    const { bodies, settles } = heldWrites()
    mountBrowser()
    await screen.findByText('Work')
    await createGroup('First')
    await createGroup('Second')
    expect(settles).toHaveLength(1)
    await act(async () => { settles[0]?.(true) })
    await waitFor(() => { expect(settles).toHaveLength(2) })
    expect(writeNames(bodies)).toEqual(['First', 'Second'])
  })

  it('stops saying "saving" only when the last write answers', async () => {
    const { settles } = heldWrites()
    mountBrowser()
    await screen.findByText('Work')
    await createGroup('First')
    await createGroup('Second')
    // The first answer says nothing about the edit still waiting behind it.
    await act(async () => { settles[0]?.(true) })
    await waitFor(() => { expect(settles).toHaveLength(2) })
    expect(document.querySelector('.dwo-saving')).not.toBeNull()
    await act(async () => { settles[1]?.(true) })
    await waitFor(() => { expect(document.querySelector('.dwo-saving')).toBeNull() })
  })

  it('shows a retry control when the last write fails', async () => {
    const { settles } = heldWrites()
    mountBrowser()
    await screen.findByText('Work')
    await createGroup('First')
    await createGroup('Second')
    await act(async () => { settles[0]?.(true) })
    await waitFor(() => { expect(settles).toHaveLength(2) })
    await act(async () => { settles[1]?.(false) })
    await waitFor(() => { expect(document.querySelector('.dwo-save-failed')).not.toBeNull() })
    expect(document.querySelector('.dwo-saving')).toBeNull()
    // The retry control says why the Host refused the document, not just that
    // it did: a bare "not saved" cannot be acted on.
    const label = document.querySelector('.dwo-save-failed')
      ?.closest('[data-tooltip]')?.getAttribute('data-tooltip') ?? ''
    expect(label).toContain('HTTP 500')
    expect(label).toContain('invalid group document')
  })
})

describe('GroupedBrowser rail', () => {
  it('renders the two rail controls instead of the tree', async () => {
    const props = propsFor(
      [workspaceView('repo', ['named'])],
      [sessionRow('named')],
      fakeServices(),
      new Map(),
      [],
      'ready',
      false,
    )
    render(<GroupedBrowser {...props} />)
    await waitFor(() => { expect(document.querySelector('.dwo-browse.rail')).not.toBeNull() })
    expect(screen.queryByRole('tree')).toBeNull()
    expect(screen.queryByText('repo')).toBeNull()
    await userEvent.click(screen.getByRole('button', { name: messages.addWorkspace }))
    await userEvent.click(screen.getByRole('button', { name: messages.search }))
    expect(props.expandSidebar).toHaveBeenCalledTimes(2)
  })
})

describe('GroupedBrowser loading', () => {
  it('does not offer a new group before the document arrives', async () => {
    vi.stubGlobal('fetch', vi.fn(() => new Promise(() => undefined)))
    render(<GroupedBrowser {...propsFor([], [], fakeServices())} />)
    await screen.findByText(messages.loading)
    await userEvent.click(document.querySelector('.dwo-head-actions .dwo-icon-btn') as HTMLElement)
    const item = await screen.findByText(messages.newGroup)
    expect((item.closest('button') as HTMLButtonElement).disabled).toBe(true)
  })
})

describe('GroupedBrowser labels', () => {
  it('shows Untitled for a session with no stored title and the default workspace name', async () => {
    const current = sessionRow('blank-current', {
      blank: true,
      retainedBy: { mainView: 1 } as SessionSummary['retainedBy'],
    })
    const auto = sessionRow('auto', { title: undefined })
    const workspace = workspaceView('default-workspace', ['auto', 'blank-current'])
    render(<GroupedBrowser {...propsFor([workspace], [current, auto], fakeServices())} />)
    expect(await screen.findByText(messages.defaultWorkspace)).toBeDefined()
    expect(await screen.findByText(messages.untitled)).toBeDefined()
  })

  it('renders the copy of the language the locale seat selects', async () => {
    const current = sessionRow('blank-current', {
      blank: true,
      retainedBy: { mainView: 1 } as SessionSummary['retainedBy'],
    })
    const repo = workspaceView('repo', ['blank-current'])
    const props = propsFor([repo], [current], fakeServices())
    render(<GroupedBrowser {...props} t={translate('zh')} />)
    expect(await screen.findByText('工作区')).toBeDefined()
    expect(await screen.findByText('新会话')).toBeDefined()
  })
})

describe('GroupedBrowser stop-and-archive consent', () => {
  it('warns about running sessions and only stops the ones it counted', async () => {
    const services = fakeServices()
    const warn = vi.spyOn(console, 'warn').mockImplementation(() => undefined)
    services.archiveSession = vi.fn((sessionId: string, options?: { stopActivity?: boolean }) => {
      if (options?.stopActivity === true) return Promise.resolve()
      // `run` was running when the dialog opened and may be stopped; `idle`
      // started running while it was up, so this refusal must not stop it.
      return Promise.reject(archiveRefusal(sessionId))
    })
    const current = sessionRow('blank-current', {
      blank: true,
      retainedBy: { mainView: 1 } as SessionSummary['retainedBy'],
    })
    const run = sessionRow('run')
    const idle = sessionRow('idle')
    const repo = workspaceView('repo', ['run', 'idle', 'blank-current'])
    const statuses: SessionStatusSnapshot = new Map([
      [id('run'), { running: true, pendingInteraction: undefined, completionUnread: false }],
      [id('idle'), { running: false, pendingInteraction: undefined, completionUnread: false }],
    ])
    render(<GroupedBrowser {...propsFor([repo], [current, run, idle], services, statuses)} />)
    await screen.findByText('Work')
    const groupRow = document.querySelector('[data-row-key="group:g1"]') as Element
    await userEvent.click(rowButtons(groupRow)[0] as HTMLElement)
    const menu = await screen.findByRole('menu', { hidden: true })
    await userEvent.click(within(menu).getByText(messages.archiveGroup))
    const dialog = await screen.findByRole('dialog', { hidden: true })
    expect(within(dialog).getByText(
      `${messages.archiveGroupBody(2)} ${messages.archiveGroupRunning(1)}`,
    )).toBeDefined()
    await userEvent.click(within(dialog).getByText(messages.ok))
    await waitFor(() => {
      expect(services.archiveSession).toHaveBeenCalledWith('run', { stopActivity: true })
    })
    expect(services.archiveSession).not.toHaveBeenCalledWith('idle', { stopActivity: true })
    expect(warn).toHaveBeenCalledWith('workspace-organize: archive refused', 'idle', expect.any(Error))
  })
})

describe('GroupedBrowser save retry', () => {
  it('re-sends the newest document from the header control', async () => {
    const { settles } = heldWrites()
    mountBrowser()
    await screen.findByText('Work')
    await createGroup('First')
    await act(async () => { settles[0]?.(false) })
    const retry = await screen.findByRole('button', { name: messages.retrySave })
    await userEvent.click(retry)
    await waitFor(() => { expect(settles).toHaveLength(2) })
    await act(async () => { settles[1]?.(true) })
    await waitFor(() => { expect(document.querySelector('.dwo-save-failed')).toBeNull() })
  })
})

describe('GroupedBrowser archived-only listing', () => {
  it('drops a workspace with no archived row', async () => {
    const current = sessionRow('blank-current', {
      blank: true,
      retainedBy: { mainView: 1 } as SessionSummary['retainedBy'],
    })
    const named = sessionRow('named')
    const gone = sessionRow('gone')
    const repo = workspaceView('repo', ['named', 'gone', 'blank-current'])
    const other = workspaceView('other', ['named'])
    render(<GroupedBrowser {...propsFor([repo, other], [current, named, gone], fakeServices(), new Map(), ['gone'])} />)
    await chooseViewOption(messages.onlyArchived)
    expect(await screen.findByText('repo')).toBeDefined()
    expect(screen.queryByText('other')).toBeNull()
  })
})
