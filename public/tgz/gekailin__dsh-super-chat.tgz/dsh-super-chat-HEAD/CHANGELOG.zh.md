# 更新日志

[English](CHANGELOG.md) | 简体中文

## Unreleased

- 「模型」入口从侧栏底部移到输入框底部、**发送**按钮左侧；窄面板只显示图标，标题和提示仍可见。
- 删除过时的 `docs/screenshot.png`，该图包含真实工作区名称。
- agent 回复支持常见 Markdown 渲染（标题、列表、引用、链接、围栏代码和行内代码）；每条回复的气泡角落有「原文」按钮可切回原始文本，用户消息保持原文。
- 面板新增「模型」对话框：从 profile 模型目录选择 orchestrator 模型和新 worker 的默认模型，复用 prototype 的 `eval.model` / `executor.model` 设置和保存历史；保存 orchestrator 模型时也会切换当前 orchestrator Session。
- 聊天消息可以只为一个新 worker 指定模型：`用 gemini-4-argon 模型启动一个新 worker 做…` 或 `use gemini-4-argon model to start a new worker for…`。模型在存储消息前解析，并在 worker Session 第一次请求前应用；生效后面板会显示一条短提示。
- worker 模型指令使用 DSH 公开的 `agent/created` 事件和 prototype 文档化的 `worker-<工单 id>` Session 命名；不修改 prototype 文件。未知或有歧义的模型名会报错且不发送消息；指令只影响新建的 worker。

## 0.2.0

- 面板先显示最新消息，上滚时再获取更早的分页，不再从顶部重放整条流；轮询保留已加载分页和阅读位置。
- 「<无主题>」视图改为读取时过滤，侧栏显示实时未打标签计数；其消息也按同样方式分页。
- 文档默认语言改为英文，中文版本使用 `.zh.md` 后缀。
- 面板新增「自动打标签」：在通用聊天里用 profile 默认模型判断未打标签的消息，只套用已有主题；不覆盖已有标签，不创建主题，agent 回复继承标签。
- 每条消息支持手动编辑标签：逐条增删标签并保存，可新建主题；只替换该消息的标签。
- 面板的“通用聊天”改名为“全部消息”，并新增“<无主题>”视图，只显示未打标签的消息。
- 工作区新增 Superagent 分组：装了 prototype 时，orchestrator 与各工单 worker 的 Workspace 合并为一组，orchestrator 置顶；只在浏览器侧合并展示，不改变 Session 工作目录。
- 修复代码审阅发现的数据一致性与竞态问题：主题上限按最旧空闲主题淘汰并保护同批创建的标签、SQLite 损坏/旧 schema 连同 `-wal`/`-shm` 隔离、`SuperagentChat.stop()` 与连接竞态时注销 Source、发送与停止纳入请求序列并同步主题状态、IME 选词回车不误触发、微信桥写接口 Origin/请求头校验与登录/登出/暂存队列竞态保护。

## 0.1.0

首个版本：面向 `dsh-superagent-prototype` 的 Super Chat 插件。

- 通过 prototype 公开的 `orchestrator` 服务注册 `super-chat` Source，把聊天消息变成 Ticket，回复写回同一聊天流。
- 单流聊天 + 多主题标签：通用聊天与主题视图共享一条流；主题是标签，首个标签作为 dispatch cue，无标签消息走 `general`，由 Superagent 自行判断。
- SQLite 存储：`message` / `topic` / `message_topic` 表和索引；旧 `chat.json` 一次性迁移。
- chat-only：GitHub 两项为空时，在内存中兼容 prototype 的 `Setup`，让纯 chat 部署也能接单；不修改 prototype 文件。
- 面板：通用聊天、主题视图、多重标签输入、新建主题、停止当前视图；Super Chat 入口作为 Superagent 行标题右侧的 chip。
- 微信：自然语言 + `@主题` 打标，单流轮询；打开接入时按需启动桥，登录态和游标存在 `stateDir/wechat`。
- 文档默认英文，中文版本为同目录 `.zh.md`。
