[CmdletBinding()]
param(
    [ValidatePattern('^[A-Za-z0-9][A-Za-z0-9._-]*$')]
    [string]$Profile = 'web',

    [ValidatePattern('^(?!.*\.\.)[A-Za-z0-9][A-Za-z0-9._/-]*$')]
    [string]$Ref = 'v0.3.3',

    [string]$DesktopRoot,

    [string]$WebUrl,

    [string]$Proxy,

    [string]$Registry,

    [ValidateRange(1, 20)]
    [int]$FetchRetries = 5,

    [switch]$SkipLiveMount,

    [switch]$DryRun
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$PluginName = 'dsh-harness-chat-control'
$Repository = '1985899182/dsh-harness-chat-control'
$SupportedHarnessVersion = '0.2.0-rc.2'
$SupportedPnpmMajors = @(10, 11)
$NodeRelativePath = 'resources\app\node_modules\node\bin\node.exe'
$DshRelativePath = 'resources\app\node_modules\@deepseek-ai\dsh\lib\bin.js'
$DshPackageRelativePath = 'resources\app\node_modules\@deepseek-ai\dsh\package.json'
$GenerationInstallerRelativePath = 'resources\app\node_modules\dsh-desktop-market-installer\index.js'
# DSH Desktop 0.11+ 将 CLI 与代际安装器打包进 app.asar，通过 Electron 二进制
# 的 Node 模式（ELECTRON_RUN_AS_NODE=1）运行，不再解包独立的 node.exe。
$HarnessEntryRelativePath = 'resources\harness-node-entry.mjs'
$AsarDshRelativePath = 'resources\app.asar\node_modules\@deepseek-ai\dsh\lib\bin.js'
$AsarDshPackageRelativePath = 'resources\app.asar\node_modules\@deepseek-ai\dsh\package.json'
$AsarGenerationInstallerRelativePath = 'resources\app.asar\node_modules\dsh-desktop-market-installer\index.js'
$ElectronExeName = 'DSH Desktop.exe'

function Resolve-DesktopInstallation {
    param(
        [string]$RequestedRoot
    )

    $candidates = @()
    if (-not [string]::IsNullOrWhiteSpace($RequestedRoot)) {
        $candidates += $RequestedRoot
    }
    if (-not [string]::IsNullOrWhiteSpace($env:DSH_DESKTOP_ROOT)) {
        $candidates += $env:DSH_DESKTOP_ROOT
    }
    $candidates += 'D:\DSH\DSH Desktop'
    foreach ($environmentVariable in @('LOCALAPPDATA', 'ProgramFiles', 'ProgramFiles(x86)')) {
        $basePath = [Environment]::GetEnvironmentVariable($environmentVariable)
        if (-not [string]::IsNullOrWhiteSpace($basePath)) {
            $candidates += (Join-Path $basePath 'DSH Desktop')
        }
    }

    $seen = @{}
    foreach ($candidate in $candidates) {
        if ([string]::IsNullOrWhiteSpace($candidate)) {
            continue
        }
        $root = [System.IO.Path]::GetFullPath($candidate)
        if ($seen.ContainsKey($root)) {
            continue
        }
        $seen[$root] = $true

        $nodePath = Join-Path $root $NodeRelativePath
        $dshPath = Join-Path $root $DshRelativePath
        $manifestPath = Join-Path $root $DshPackageRelativePath
        $generationInstallerPath = Join-Path $root $GenerationInstallerRelativePath
        if ((Test-Path -LiteralPath $nodePath -PathType Leaf) -and
            (Test-Path -LiteralPath $dshPath -PathType Leaf) -and
            (Test-Path -LiteralPath $manifestPath -PathType Leaf)) {
            return [PSCustomObject]@{
                Root = $root
                NodePath = $nodePath
                DshPath = $dshPath
                DshEntryPath = $null
                ManifestPath = $manifestPath
                GenerationInstallerPath = $generationInstallerPath
                AsarMode = $false
            }
        }

        # app.asar 布局：CLI 入口与代际安装器都封装在 asar 内，经
        # harness-node-entry.mjs 用 Electron 的 Node 模式调用。
        $asarPath = Join-Path $root 'resources\app.asar'
        $harnessEntryPath = Join-Path $root $HarnessEntryRelativePath
        $electronExe = Join-Path $root $ElectronExeName
        if ((Test-Path -LiteralPath $asarPath -PathType Leaf) -and
            (Test-Path -LiteralPath $harnessEntryPath -PathType Leaf) -and
            (Test-Path -LiteralPath $electronExe -PathType Leaf)) {
            return [PSCustomObject]@{
                Root = $root
                NodePath = $electronExe
                DshPath = $harnessEntryPath
                DshEntryPath = (Join-Path $root $AsarDshRelativePath)
                ManifestPath = (Join-Path $root $AsarDshPackageRelativePath)
                GenerationInstallerPath = (Join-Path $root $AsarGenerationInstallerRelativePath)
                AsarMode = $true
            }
        }
    }

    throw '未找到 DSH Desktop 内置 CLI。请使用 -DesktopRoot 指定 DSH Desktop 的安装目录。'
}

function Invoke-DesktopNode {
    param(
        [Parameter(Mandatory = $true)]
        [object]$Desktop,
        [Parameter(Mandatory = $true)]
        [string[]]$Arguments
    )

    $previous = $env:ELECTRON_RUN_AS_NODE
    try {
        if ($Desktop.AsarMode) {
            $env:ELECTRON_RUN_AS_NODE = '1'
        }
        & $Desktop.NodePath @Arguments
    } finally {
        $env:ELECTRON_RUN_AS_NODE = $previous
    }
}

function Invoke-DshPluginCli {
    param(
        [Parameter(Mandatory = $true)]
        [object]$Desktop,
        [Parameter(Mandatory = $true)]
        [string]$ProfileName,
        [Parameter(Mandatory = $true)]
        [string[]]$PluginArguments
    )

    $arguments = @($Desktop.DshPath)
    if ($Desktop.AsarMode) {
        $arguments += $Desktop.DshEntryPath
    }
    $arguments += @('plugin', '--profile', $ProfileName)
    $arguments += $PluginArguments
    Invoke-DesktopNode -Desktop $Desktop -Arguments $arguments
}

function Read-DesktopManifest {
    param(
        [Parameter(Mandatory = $true)]
        [object]$Desktop
    )

    if (-not $Desktop.AsarMode) {
        return Read-JsonFile -Path $Desktop.ManifestPath
    }

    # app.asar 内的 package.json 无法用 Get-Content 直接读取。经 Electron 的
    # Node 模式解析后打印 version 字段；Electron 的 stdout 属于异步写，直接
    # 用 `&` 捕获变量会触发 EPIPE，改用 Start-Process 的文件重定向可靠落盘。
    $outFile = Join-Path ([System.IO.Path]::GetTempPath()) ('dsh-manifest-' + [guid]::NewGuid().ToString('N') + '.json')
    $errFile = Join-Path ([System.IO.Path]::GetTempPath()) ('dsh-manifest-err-' + [guid]::NewGuid().ToString('N') + '.txt')
    try {
        $inlineScript = "const fs=require('fs');process.stdout.write(JSON.parse(fs.readFileSync(process.argv[1],'utf8')).version);"
        $quotedScript = '"' + $inlineScript + '"'
        $quotedPath = '"' + $Desktop.ManifestPath + '"'
        $previous = $env:ELECTRON_RUN_AS_NODE
        $env:ELECTRON_RUN_AS_NODE = '1'
        try {
            $process = Start-Process -FilePath $Desktop.NodePath -ArgumentList @('-e', $quotedScript, $quotedPath) -RedirectStandardOutput $outFile -RedirectStandardError $errFile -Wait -NoNewWindow -PassThru
        } finally {
            $env:ELECTRON_RUN_AS_NODE = $previous
        }
        if ($process.ExitCode -ne 0) {
            throw "无法读取 DSH Harness manifest（退出码：$($process.ExitCode)）。"
        }
        return [PSCustomObject]@{ version = (Get-Content -LiteralPath $outFile -Raw).Trim() }
    } finally {
        Remove-Item -LiteralPath $outFile -Force -ErrorAction SilentlyContinue
        Remove-Item -LiteralPath $errFile -Force -ErrorAction SilentlyContinue
    }
}

function Assert-CommandAvailable {
    param(
        [string]$CommandName,
        [string]$InstallHint
    )

    if ($null -eq (Get-Command $CommandName -ErrorAction SilentlyContinue)) {
        throw "未在 PATH 中找到 $CommandName。$InstallHint"
    }
}

function ConvertTo-HttpProxyUri {
    param(
        [string]$Candidate,
        [string]$Label = '代理'
    )

    if ([string]::IsNullOrWhiteSpace($Candidate)) {
        return $null
    }

    $value = $Candidate.Trim()
    if ($value -notmatch '^[A-Za-z][A-Za-z0-9+.-]*://') {
        $value = "http://$value"
    }
    $parsed = $null
    if (-not [System.Uri]::TryCreate($value, [System.UriKind]::Absolute, [ref]$parsed)) {
        throw "$Label 地址无效：$Candidate"
    }
    if ($parsed.Scheme -notin @('http', 'https') -or
        [string]::IsNullOrWhiteSpace($parsed.Host) -or
        -not [string]::IsNullOrWhiteSpace($parsed.UserInfo)) {
        throw "$Label 只支持不含账号密码的 http(s) 地址：$Candidate"
    }
    return $parsed
}

function Get-WinInetProxyUri {
    $settingsPath = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings'
    try {
        $settings = Get-ItemProperty -LiteralPath $settingsPath -ErrorAction Stop
        if ([int]$settings.ProxyEnable -ne 1) {
            return $null
        }
        $proxyServer = [string]$settings.ProxyServer
        if ([string]::IsNullOrWhiteSpace($proxyServer)) {
            return $null
        }

        $entries = @($proxyServer -split ';' | ForEach-Object { ([string]$_).Trim() } | Where-Object { $_ -ne '' })
        $selected = $null
        foreach ($preferredProtocol in @('https', 'http')) {
            $match = $entries | Where-Object { $_ -match "^(?i)$preferredProtocol=(?<server>.+)$" } | Select-Object -First 1
            if ($null -ne $match) {
                $selected = ([regex]::Match([string]$match, "^(?i)$preferredProtocol=(?<server>.+)$")).Groups['server'].Value.Trim()
                break
            }
        }
        if ([string]::IsNullOrWhiteSpace($selected)) {
            $selected = $entries | Select-Object -First 1
        }
        if ([string]::IsNullOrWhiteSpace($selected)) {
            return $null
        }
        try {
            return ConvertTo-HttpProxyUri -Candidate $selected -Label 'WinINET 代理'
        } catch {
            Write-Warning "WinINET 代理已启用但无法解析；请使用 -Proxy 明确指定代理。"
            return $null
        }
    } catch {
        return $null
    }
}

function Get-EnvironmentProxyUri {
    foreach ($name in @('HTTPS_PROXY', 'HTTP_PROXY', 'ALL_PROXY')) {
        $value = [Environment]::GetEnvironmentVariable($name, 'Process')
        if ([string]::IsNullOrWhiteSpace($value)) {
            continue
        }
        try {
            return ConvertTo-HttpProxyUri -Candidate $value -Label "$name 代理"
        } catch {
            Write-Warning "$name 环境变量不是可用的 http(s) 代理，将继续检查其他代理来源。"
        }
    }
    return $null
}

function Resolve-ChildProcessProxy {
    param(
        [string]$RequestedProxy
    )

    if (-not [string]::IsNullOrWhiteSpace($RequestedProxy)) {
        return [PSCustomObject]@{
            Uri = ConvertTo-HttpProxyUri -Candidate $RequestedProxy -Label '-Proxy'
            Source = '命令行'
        }
    }

    $environmentProxy = Get-EnvironmentProxyUri
    if ($null -ne $environmentProxy) {
        return [PSCustomObject]@{
            Uri = $environmentProxy
            Source = '环境变量'
        }
    }

    $winInetProxy = Get-WinInetProxyUri
    if ($null -ne $winInetProxy) {
        return [PSCustomObject]@{
            Uri = $winInetProxy
            Source = 'WinINET'
        }
    }

    return [PSCustomObject]@{
        Uri = $null
        Source = '未检测到'
    }
}

function Initialize-ChildProcessNetwork {
    param(
        [string]$RequestedProxy,
        [string]$RequestedRegistry,
        [int]$Retries
    )

    $names = @(
        'HTTP_PROXY',
        'HTTPS_PROXY',
        'ALL_PROXY',
        'NO_PROXY',
        'NPM_CONFIG_REGISTRY',
        'npm_config_registry',
        'NPM_CONFIG_FETCH_RETRIES',
        'npm_config_fetch_retries',
        'GIT_TERMINAL_PROMPT'
    )
    $state = [PSCustomObject]@{
        Names = $names
        Values = @{}
        Present = @{}
        ProxyUri = $null
        RegistryUri = $null
    }
    foreach ($name in $names) {
        $state.Present[$name] = Test-Path -LiteralPath "Env:$name"
        if ($state.Present[$name]) {
            $state.Values[$name] = [Environment]::GetEnvironmentVariable($name, 'Process')
        }
    }

    # Validate every user-supplied URL before mutating the caller's
    # environment.  The installer runs from an in-memory scriptblock, so a
    # validation error must not leave proxy variables behind in that shell.
    $proxy = Resolve-ChildProcessProxy -RequestedProxy $RequestedProxy
    $registryUri = $null
    if (-not [string]::IsNullOrWhiteSpace($RequestedRegistry)) {
        $registryUri = ConvertTo-HttpProxyUri -Candidate $RequestedRegistry -Label '-Registry'
    }

    if ($null -ne $proxy.Uri) {
        $proxyValue = $proxy.Uri.AbsoluteUri
        $env:HTTP_PROXY = $proxyValue
        $env:HTTPS_PROXY = $proxyValue
        $env:ALL_PROXY = $proxyValue
        $state.ProxyUri = $proxy.Uri
        Write-Host "已检测到 $($proxy.Source) 代理，并将传递给 pnpm、git、node 子进程。"
    } else {
        Write-Warning '未检测到可传递给子进程的 HTTP 代理；如需代理，请使用 -Proxy <http(s)://host:port>。'
    }

    $noProxyTokens = @()
    $existingNoProxy = [Environment]::GetEnvironmentVariable('NO_PROXY', 'Process')
    if (-not [string]::IsNullOrWhiteSpace($existingNoProxy)) {
        $noProxyTokens += @($existingNoProxy -split ',' | ForEach-Object { ([string]$_).Trim() } | Where-Object { $_ -ne '' })
    }
    $noProxyTokens += @('127.0.0.1', 'localhost', '[::1]')
    $env:NO_PROXY = (($noProxyTokens | Select-Object -Unique) -join ',')

    if ($null -ne $registryUri) {
        $env:NPM_CONFIG_REGISTRY = $registryUri.AbsoluteUri
        $env:npm_config_registry = $registryUri.AbsoluteUri
        $state.RegistryUri = $registryUri
        Write-Host '已为 pnpm/npm 子进程设置自定义 registry。'
    }

    if ($Retries -gt 0) {
        $retryValue = [string]$Retries
        $env:NPM_CONFIG_FETCH_RETRIES = $retryValue
        $env:npm_config_fetch_retries = $retryValue
    }
    $env:GIT_TERMINAL_PROMPT = '0'
    return $state
}

function Restore-ChildProcessNetwork {
    param(
        [object]$State
    )

    if ($null -eq $State) {
        return
    }
    foreach ($name in $State.Names) {
        if ($State.Present[$name]) {
            Set-Item -LiteralPath "Env:$name" -Value $State.Values[$name]
        } else {
            Remove-Item -LiteralPath "Env:$name" -ErrorAction SilentlyContinue
        }
    }
}

function Get-NetworkFailureHint {
    param(
        [object]$NetworkState
    )

    if ($null -eq $NetworkState -or $null -eq $NetworkState.ProxyUri) {
        return '未检测到可传递给子进程的 HTTP 代理；如需代理，请重试并加入 -Proxy <http(s)://host:port>。'
    }
    return '已向子进程传递代理；请确认该代理当前可访问 github.com 和 npm registry。'
}

function Get-SafeHttpErrorDetail {
    param(
        [object]$ErrorRecord
    )

    $statusCode = $null
    $body = $null
    try {
        $response = $ErrorRecord.Exception.Response
        if ($null -ne $response) {
            $statusProperty = $response.PSObject.Properties['StatusCode']
            if ($null -ne $statusProperty -and $null -ne $statusProperty.Value) {
                $statusCode = [int]$statusProperty.Value
            }

            # Windows PowerShell exposes WebResponse.GetResponseStream(),
            # while PowerShell 7 exposes HttpResponseMessage.Content.  Read
            # either shape without ever echoing the exception URL (which may
            # contain dshmarket's local auth token).
            $streamMethod = $response.PSObject.Methods['GetResponseStream']
            if ($null -ne $streamMethod) {
                $stream = $response.GetResponseStream()
                if ($null -ne $stream) {
                    $reader = New-Object System.IO.StreamReader($stream)
                    try {
                        $body = $reader.ReadToEnd()
                    } finally {
                        $reader.Dispose()
                        $stream.Dispose()
                    }
                }
            } else {
                $contentProperty = $response.PSObject.Properties['Content']
                $content = if ($null -ne $contentProperty) { $contentProperty.Value } else { $null }
                if ($null -ne $content) {
                    $readMethod = $content.PSObject.Methods['ReadAsStringAsync']
                    if ($null -ne $readMethod) {
                        $body = $content.ReadAsStringAsync().GetAwaiter().GetResult()
                    } else {
                        $body = [string]$content
                    }
                }
            }
        }
    } catch {
        # A malformed/non-standard response should not hide a status code
        # already read above, and the caller still gets a safe generic reason.
    }
    if (-not [string]::IsNullOrWhiteSpace($body)) {
        $body = [regex]::Replace($body, '(?i)([?&](?:token|access_token|auth_token|api_key)=)[^&\s"<>]+', '$1<redacted>')
        $body = [regex]::Replace($body, '(?i)("(?:token|access_token|auth_token|api_key|authorization)"\s*:\s*")[^"]*(")', '$1<redacted>$2')
        $body = [regex]::Replace($body, '(?i)bearer\s+[A-Za-z0-9._~+/-]+', 'Bearer <redacted>')
        $body = [regex]::Replace($body, '\s+', ' ').Trim()
        if ($body.Length -gt 500) {
            $body = $body.Substring(0, 500) + '…'
        }
    }
    return [PSCustomObject]@{
        StatusCode = $statusCode
        Body = $body
    }
}

function Get-ProfilePnpmVersion {
    param(
        [string]$ProfileRoot
    )

    $modulesManifestPath = Join-Path $ProfileRoot 'node_modules\.modules.yaml'
    if (-not (Test-Path -LiteralPath $modulesManifestPath -PathType Leaf)) {
        return $null
    }

    $modulesManifest = Read-JsonFile -Path $modulesManifestPath
    $packageManager = [string]$modulesManifest.packageManager
    $match = [regex]::Match($packageManager, '^pnpm@(?<version>\d+(?:\.\d+){1,2})$')
    if (-not $match.Success) {
        return $null
    }
    return [version]$match.Groups['version'].Value
}

function Get-ActivePnpmVersion {
    $versionText = (& pnpm --version 2>$null | Select-Object -First 1)
    $match = [regex]::Match([string]$versionText, '^\s*(?<version>\d+(?:\.\d+){1,2})')
    if (-not $match.Success) {
        return $null
    }
    return [version]$match.Groups['version'].Value
}

function Use-ProfilePnpm {
    param(
        [string]$ProfileRoot
    )

    $profileVersion = Get-ProfilePnpmVersion -ProfileRoot $ProfileRoot
    if ($null -eq $profileVersion) {
        return $null
    }

    $activeVersion = Get-ActivePnpmVersion
    if ($null -eq $activeVersion) {
        throw '无法读取 pnpm 版本。请确认 pnpm 10 或 11 已加入 PATH。'
    }
    if ($activeVersion.Major -notin $SupportedPnpmMajors) {
        throw "当前 pnpm 版本为 $activeVersion；本插件要求 pnpm 10.x 或 11.x。"
    }
    if ($profileVersion.Major -notin $SupportedPnpmMajors) {
        throw "当前 profile 记录的 pnpm 版本为 $profileVersion；本插件支持 pnpm 10.x 或 11.x。"
    }
    if ($activeVersion.Major -eq $profileVersion.Major) {
        Write-Host "使用 PATH 中的 pnpm $activeVersion（profile 已使用 pnpm $profileVersion）。"
        return $null
    }

    $corepack = Get-Command corepack -ErrorAction SilentlyContinue
    if ($null -eq $corepack) {
        throw "当前 profile 使用 pnpm $profileVersion，但 PATH 中是 pnpm $activeVersion，且未找到 Corepack。请安装 pnpm $profileVersion，或启用随 Node.js 提供的 Corepack。"
    }

    $temporaryRoot = Join-Path ([System.IO.Path]::GetTempPath()) ('dsh-harness-chat-control-pnpm-' + [guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Path $temporaryRoot | Out-Null
    $shimPath = Join-Path $temporaryRoot 'pnpm.cmd'
    $corepackPath = [System.IO.Path]::GetFullPath($corepack.Path)
    $shimContent = "@echo off`r`n`"$corepackPath`" pnpm@$profileVersion %*`r`n"
    Set-Content -LiteralPath $shimPath -Value $shimContent -Encoding ASCII

    $originalPath = $env:PATH
    $env:PATH = "$temporaryRoot;$originalPath"
    Write-Host "当前 profile 使用 pnpm $profileVersion，而 PATH 中是 pnpm $activeVersion；已临时切换到 Corepack 的 pnpm $profileVersion。"
    return [PSCustomObject]@{
        OriginalPath = $originalPath
        TemporaryRoot = $temporaryRoot
    }
}

function Read-JsonFile {
    param(
        [string]$Path
    )

    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) {
        throw "缺少预期文件：$Path"
    }
    return Get-Content -LiteralPath $Path -Raw | ConvertFrom-Json
}

function Get-ProfileDependencyVersion {
    param(
        [object]$ProfileManifest,
        [string]$PackageName
    )

    if ($null -eq $ProfileManifest -or $null -eq $ProfileManifest.dependencies) {
        return $null
    }
    $property = $ProfileManifest.dependencies.PSObject.Properties[$PackageName]
    if ($null -eq $property -or $null -eq $property.Value) {
        return $null
    }
    return [string]$property.Value
}

function Warn-IncompatibleBetterSidebar {
    param(
        [string]$ProfileManifestPath,
        [string]$HarnessVersion
    )

    if (-not (Test-Path -LiteralPath $ProfileManifestPath -PathType Leaf)) {
        return
    }
    try {
        $manifest = Read-JsonFile -Path $ProfileManifestPath
        $sidebarVersion = Get-ProfileDependencyVersion -ProfileManifest $manifest -PackageName 'dsh-better-sidebar'
        if ($HarnessVersion -eq $SupportedHarnessVersion -and -not [string]::IsNullOrWhiteSpace($sidebarVersion) -and $sidebarVersion -notmatch '^0\.24(?:\.|$)') {
            Write-Warning "当前 profile 使用 dsh-better-sidebar@$sidebarVersion，但 DSH Harness $HarnessVersion 只兼容 0.24.1；请先执行：dsh plugin --profile web add --save-exact dsh-better-sidebar@0.24.1"
        }
    } catch {
        Write-Warning "无法读取 $ProfileManifestPath 来检查 dsh-better-sidebar 版本；安装后请确认使用 0.24.1。"
    }
}

function ConvertTo-LoopbackWebUri {
    param(
        [string]$Candidate
    )

    if ([string]::IsNullOrWhiteSpace($Candidate)) {
        return $null
    }

    $parsed = $null
    if (-not [System.Uri]::TryCreate($Candidate, [System.UriKind]::Absolute, [ref]$parsed)) {
        return $null
    }
    if ($parsed.Scheme -ne 'http' -or -not $parsed.IsLoopback -or $parsed.Port -le 0) {
        return $null
    }
    return $parsed
}

function New-DshMarketRouteUri {
    param(
        [System.Uri]$WebUri,
        [string]$Path
    )

    # Keep the short-lived Harness token from the discovered Web URL while
    # replacing only the route path.  The token is never written to output.
    $authority = $WebUri.GetLeftPart([System.UriPartial]::Authority)
    $query = $WebUri.Query
    return New-Object -TypeName System.Uri -ArgumentList ("$authority$Path$query")
}

function Get-DshMarketStatus {
    param(
        [System.Uri]$WebUri
    )

    try {
        $statusUri = New-DshMarketRouteUri -WebUri $WebUri -Path '/dsh-market/installed'
        $response = Invoke-WebRequest -UseBasicParsing -Method Get -Uri $statusUri -TimeoutSec 4
        if ($response.StatusCode -lt 200 -or $response.StatusCode -ge 300) {
            return $null
        }
        $payload = $response.Content | ConvertFrom-Json
        if ($null -eq $payload -or $null -eq $payload.PSObject.Properties['profile']) {
            return $null
        }
        return [PSCustomObject]@{
            Uri = $WebUri
            Data = $payload
        }
    } catch {
        # Endpoint discovery is best effort.  A stale port/token or a DSH
        # build without dshmarket must fall back to the safe cold-start path.
        return $null
    }
}

function Get-RunningDshWebEndpoint {
    param(
        [string]$RequestedUrl,
        [string]$ProfileName
    )

    $candidates = @()
    $seen = @{}
    if (-not [string]::IsNullOrWhiteSpace($RequestedUrl)) {
        $requestedUri = ConvertTo-LoopbackWebUri -Candidate $RequestedUrl
        if ($null -eq $requestedUri) {
            throw '-WebUrl 只允许指向本机 DSH Web 地址（http://127.0.0.1、localhost 或 [::1]）。'
        }
        $candidates += $requestedUri
    }

    $logPath = $null
    if (-not [string]::IsNullOrWhiteSpace($env:APPDATA)) {
        $logPath = Join-Path $env:APPDATA 'dsh-desktop\logs\harness.log'
    }
    if ($null -ne $logPath -and (Test-Path -LiteralPath $logPath -PathType Leaf)) {
        $webPattern = 'dsh web:\s+(?<url>http://(?:127\.0\.0\.1|localhost|\[::1\]):\d+/\?token=[A-Za-z0-9_-]+)'
        $logLines = @(Get-Content -LiteralPath $logPath -Tail 4000)
        for ($index = $logLines.Count - 1; $index -ge 0; $index -= 1) {
            $match = [regex]::Match([string]$logLines[$index], $webPattern)
            if (-not $match.Success) {
                continue
            }
            $candidate = ConvertTo-LoopbackWebUri -Candidate $match.Groups['url'].Value
            if ($null -eq $candidate -or $seen.ContainsKey($candidate.AbsoluteUri)) {
                continue
            }
            $candidates += $candidate
            $seen[$candidate.AbsoluteUri] = $true
        }
    }

    foreach ($candidate in $candidates) {
        $status = Get-DshMarketStatus -WebUri $candidate
        if ($null -eq $status) {
            continue
        }
        $profileProperty = $status.Data.PSObject.Properties['profile']
        if ($null -ne $profileProperty -and [string]$profileProperty.Value -eq $ProfileName) {
            return $status
        }
    }
    return $null
}

function Get-InstalledPackageProperty {
    param(
        [object]$StatusData
    )

    if ($null -eq $StatusData -or $null -eq $StatusData.PSObject.Properties['installed']) {
        return $null
    }
    $installed = $StatusData.installed
    if ($null -eq $installed) {
        return $null
    }
    return $installed.PSObject.Properties[$PluginName]
}

function Get-ActivationState {
    param(
        [object]$StatusData
    )

    if ($null -eq $StatusData -or $null -eq $StatusData.PSObject.Properties['activation']) {
        return $null
    }
    $activation = $StatusData.activation
    if ($null -eq $activation) {
        return $null
    }
    $pluginActivation = $activation.PSObject.Properties[$PluginName]
    if ($null -eq $pluginActivation -or $null -eq $pluginActivation.Value) {
        return $null
    }
    $state = $pluginActivation.Value.PSObject.Properties['state']
    if ($null -eq $state) {
        return $null
    }
    return [string]$state.Value
}

function Get-ProfilePackageTarget {
    param(
        [string]$ProfileRoot
    )

    $packagePath = Join-Path $ProfileRoot (Join-Path 'node_modules' $PluginName)
    $packageItem = Get-Item -LiteralPath $packagePath -Force -ErrorAction SilentlyContinue
    if ($null -eq $packageItem) {
        return $null
    }

    # DSH Desktop projects generation packages as junctions.  Capture the
    # target before projection switches the profile to the new generation:
    # ClientModuleRegistry in an already-running Harness still watches this
    # old path, so the installer can copy only the Web Client artifact there
    # and let the built-in HMR deliver it without restarting DSH.
    $target = @($packageItem.Target) | Select-Object -First 1
    if ([string]::IsNullOrWhiteSpace([string]$target)) {
        return $null
    }
    try {
        return [System.IO.Path]::GetFullPath([string]$target)
    } catch {
        return $null
    }
}

function Normalize-ClientArtifactText {
    param(
        [string]$Text
    )

    if ($null -eq $Text) {
        return ''
    }

    # The /plugins route emits a source-map trailer and a final semicolon,
    # while the package file may use either LF or CRLF and has neither.  The
    # loader hashes executable bytes, so normalize these transport-only
    # differences before matching the running artifact to a generation.
    $normalized = $Text.Replace("`r`n", "`n").Replace("`r", "`n")
    $normalized = [regex]::Replace($normalized, '(?ms)\r?\n?//# sourceMappingURL=.*?\z', '')
    $normalized = $normalized.Trim()
    if ($normalized.EndsWith(';')) {
        $normalized = $normalized.Substring(0, $normalized.Length - 1).TrimEnd()
    }
    return $normalized
}

function Get-ClientArtifactHash {
    param(
        [string]$Text
    )

    $normalized = Normalize-ClientArtifactText -Text $Text
    $hashBytes = [System.Text.Encoding]::UTF8.GetBytes($normalized)
    $digest = [System.Security.Cryptography.SHA1]::Create()
    try {
        return (($digest.ComputeHash($hashBytes) | ForEach-Object ToString x2) -join '').ToLowerInvariant()
    } finally {
        $digest.Dispose()
    }
}

function Get-RunningClientPackageTarget {
    param(
        [System.Uri]$WebUri,
        [string]$ProfileRoot,
        [string]$FallbackTarget
    )

    # The profile junction can be newer than the long-lived Harness process:
    # an earlier install may have started the process from an older generation
    # and then projected a newer one for the next launch.  Ask the running Web
    # server for the exact client artifact it serves, then match those bytes to
    # the immutable live generations before projection changes the junction.
    $runningHash = $null
    if ($null -ne $WebUri) {
        $client = $null
        try {
            # The Harness Web endpoint requires the short-lived token carried
            # by the discovered page URL.  Keeping only the authority makes
            # this probe return 401, which forces the fallback junction and
            # can select a newer generation than the long-lived process is
            # actually serving.  Reuse the same route builder as dshmarket so
            # the running artifact is matched before projection switches the
            # profile link.
            $clientUri = New-DshMarketRouteUri -WebUri $WebUri -Path "/plugins/??$PluginName/client.js"
            $client = [System.Net.Http.HttpClient]::new()
            $bytes = $client.GetByteArrayAsync($clientUri).GetAwaiter().GetResult()
            $text = [System.Text.Encoding]::UTF8.GetString($bytes)
            $runningHash = Get-ClientArtifactHash -Text $text
        } catch {
            $runningHash = $null
        } finally {
            if ($null -ne $client) {
                $client.Dispose()
            }
        }
    }

    if (-not [string]::IsNullOrWhiteSpace($runningHash)) {
        $liveRoot = Join-Path $env:DSH_HOME 'profiles\.generations\live'
        if (Test-Path -LiteralPath $liveRoot -PathType Container) {
            $generations = Get-ChildItem -LiteralPath $liveRoot -Directory -Filter "$PluginName+*" -ErrorAction SilentlyContinue
            foreach ($generation in $generations) {
                $clientPath = Join-Path $generation.FullName (Join-Path 'node_modules' (Join-Path $PluginName 'lib\client.js'))
                if (-not (Test-Path -LiteralPath $clientPath -PathType Leaf)) {
                    continue
                }
                try {
                    $candidateText = [System.IO.File]::ReadAllText($clientPath, [System.Text.Encoding]::UTF8)
                    $candidateHash = Get-ClientArtifactHash -Text $candidateText
                    if ($candidateHash -eq $runningHash) {
                        return [System.IO.Path]::GetFullPath((Join-Path $generation.FullName (Join-Path 'node_modules' $PluginName)))
                    }
                } catch {
                    # An incomplete/removed generation is not a valid match;
                    # continue checking the remaining immutable generations.
                }
            }
        }
    }

    # Keep the pre-install junction as a safe fallback for hosts that do not
    # expose the bundle route or while the Web endpoint is starting up.
    if (-not [string]::IsNullOrWhiteSpace($FallbackTarget)) {
        try {
            return [System.IO.Path]::GetFullPath($FallbackTarget)
        } catch {
            return $null
        }
    }
    return $null
}

function Invoke-DshMarketHotMount {
    param(
        [System.Uri]$WebUri,
        [string]$ProfileName
    )

    # Generation projection and the running market are separate pieces of
    # state.  Wait briefly for the projected package to become visible before
    # asking dshmarket to mount it, otherwise a fast install can race its own
    # symlink publication.
    $installed = $false
    for ($attempt = 0; $attempt -lt 4; $attempt += 1) {
        $status = Get-DshMarketStatus -WebUri $WebUri
        if ($null -ne $status -and [string]$status.Data.profile -eq $ProfileName) {
            $installed = $null -ne (Get-InstalledPackageProperty -StatusData $status.Data)
            if ($installed) {
                if ((Get-ActivationState -StatusData $status.Data) -eq 'live') {
                    return [PSCustomObject]@{
                        Ok = $false
                        AlreadyLive = $true
                        NeedsRefresh = $false
                        Restart = $true
                        Reason = '插件已在当前 Harness 进程中运行,跳过重复热挂载'
                    }
                }
                break
            }
        }
        if ($attempt -lt 3) {
            Start-Sleep -Milliseconds 500
        }
    }
    if (-not $installed) {
        return [PSCustomObject]@{
            Ok = $false
            AlreadyLive = $false
            NeedsRefresh = $false
            Restart = $true
            Reason = '运行中的 dshmarket 尚未看到新安装的插件'
        }
    }

    try {
        $toggleUri = New-DshMarketRouteUri -WebUri $WebUri -Path '/dsh-market/toggle'
        $origin = $WebUri.GetLeftPart([System.UriPartial]::Authority)
        $body = @{ name = $PluginName; enabled = $true } | ConvertTo-Json -Compress
        $response = Invoke-WebRequest -UseBasicParsing -Method Post -Uri $toggleUri `
            -Headers @{ Origin = $origin } -ContentType 'application/json' -Body $body -TimeoutSec 20
        $result = $response.Content | ConvertFrom-Json

        $activationState = $null
        if ($null -ne $result.PSObject.Properties['activation'] -and $null -ne $result.activation) {
            $activationProperty = $result.activation.PSObject.Properties[$PluginName]
            if ($null -ne $activationProperty -and $null -ne $activationProperty.Value) {
                $stateProperty = $activationProperty.Value.PSObject.Properties['state']
                if ($null -ne $stateProperty) {
                    $activationState = [string]$stateProperty.Value
                }
            }
        }
        $live = $false
        if ($null -ne $result.PSObject.Properties['live'] -and $null -ne $result.live) {
            $live = @($result.live) -contains $PluginName
        }
        $ok = $false
        if ($null -ne $result.PSObject.Properties['ok']) {
            $ok = [bool]$result.ok
        }
        $ok = $ok -and ($activationState -eq 'live' -or $live)
        $refresh = $true
        if ($null -ne $result.PSObject.Properties['refresh']) {
            $refresh = [bool]$result.refresh
        }
        $restart = $false
        if ($null -ne $result.PSObject.Properties['restart']) {
            $restart = [bool]$result.restart
        }
        $reason = $null
        if (-not $ok -and $null -ne $result.PSObject.Properties['reason']) {
            $reason = [string]$result.reason
        }
        if ([string]::IsNullOrWhiteSpace($reason)) {
            $reason = 'dshmarket 未确认插件已热挂载'
        }
        return [PSCustomObject]@{
            Ok = $ok
            AlreadyLive = $false
            NeedsRefresh = $refresh
            Restart = $restart -or -not $ok
            Reason = $reason
            ActivationState = $activationState
        }
    } catch {
        $detail = Get-SafeHttpErrorDetail -ErrorRecord $_
        $reason = '调用运行中的 dshmarket 热挂载接口失败'
        if ($null -ne $detail.StatusCode) {
            $reason = "dshmarket 热挂载返回 HTTP $($detail.StatusCode)"
        }
        if (-not [string]::IsNullOrWhiteSpace($detail.Body)) {
            $reason += "；响应体：$($detail.Body)"
        }
        return [PSCustomObject]@{
            Ok = $false
            AlreadyLive = $false
            NeedsRefresh = $false
            Restart = $true
            Reason = $reason
        }
    }
}

function Remove-LegacyProfilePackage {
    param(
        [string]$ProfileRoot,
        [object]$ProfileManifest
    )

    $dependencies = @{}
    if ($null -ne $ProfileManifest.dependencies) {
        foreach ($property in $ProfileManifest.dependencies.PSObject.Properties) {
            $dependencies[$property.Name] = [string]$property.Value
        }
    }
    if (-not $dependencies.ContainsKey($PluginName)) {
        return
    }

    $projection = $null
    try {
        $projection = $ProfileManifest.dsh.desktop.generationProjection.plugins
    } catch {
        $projection = $null
    }
    if ($null -ne $projection -and $null -ne $projection.PSObject.Properties[$PluginName]) {
        Write-Host "$PluginName 已由 DSH Desktop 代际安装管理，跳过旧版清理。"
        return
    }

    $packagePath = Join-Path $ProfileRoot (Join-Path 'node_modules' $PluginName)
    $packageItem = Get-Item -LiteralPath $packagePath -Force -ErrorAction SilentlyContinue
    $isReparsePoint = $null -ne $packageItem -and (($packageItem.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0)
    if ($isReparsePoint) {
        Write-Host "$PluginName 当前是代际链接，跳过旧版清理。"
        return
    }

    Write-Host "$PluginName 是旧的共享 profile 安装，先移除后切换到 DSH Desktop 代际安装。"
    Invoke-DshPluginCli -Desktop $desktop -ProfileName $Profile -PluginArguments @('remove', $PluginName)
    if ($LASTEXITCODE -ne 0) {
        throw "无法移除旧的 $PluginName 安装（退出码：$LASTEXITCODE）。"
    }
}

$desktop = Resolve-DesktopInstallation -RequestedRoot $DesktopRoot
$dshManifest = Read-DesktopManifest -Desktop $desktop
if ($dshManifest.version -ne $SupportedHarnessVersion) {
    Write-Warning "当前 DSH Harness 版本为 $($dshManifest.version)，本插件仅在 $SupportedHarnessVersion 上完成验证；将继续安装，但请在重启后检查界面功能。"
}

Assert-CommandAvailable -CommandName 'pnpm' -InstallHint '请先安装 pnpm 10 或 11，并重新打开终端。'
Assert-CommandAvailable -CommandName 'git' -InstallHint 'GitHub 源码安装需要 Git，请先安装 Git 并重新打开终端。'

if ([string]::IsNullOrWhiteSpace($env:APPDATA)) {
    throw '无法读取 APPDATA，无法确定 DSH Desktop 的 Harness home。'
}
$env:DSH_HOME = Join-Path $env:APPDATA 'dsh-desktop\harness'
$packageSpec = "git+https://github.com/$Repository.git#$Ref"
$profileRoot = Join-Path $env:DSH_HOME (Join-Path 'profiles' $Profile)
$profileManifestPath = Join-Path $env:DSH_HOME (Join-Path 'profiles' (Join-Path $Profile 'package.json'))
Warn-IncompatibleBetterSidebar -ProfileManifestPath $profileManifestPath -HarnessVersion ([string]$dshManifest.version)

Write-Host "DSH Desktop：$($desktop.Root)"
Write-Host "Harness home：$env:DSH_HOME"
Write-Host "目标 profile：$Profile"
Write-Host "插件来源：$packageSpec"

if ($DryRun) {
    Write-Host 'Dry run：未修改 DSH profile。将执行：'
    if ($desktop.AsarMode) {
        Write-Host "若 profile 中存在旧的共享安装，将先执行：& '$($desktop.NodePath)' '$($desktop.DshPath)' '$($desktop.DshEntryPath)' plugin --profile $Profile remove $PluginName"
    } else {
        Write-Host "若 profile 中存在旧的共享安装，将先执行：& '$($desktop.NodePath)' '$($desktop.DshPath)' plugin --profile $Profile remove $PluginName"
    }
    Write-Host "然后通过 DSH Desktop 代际安装器安装：$packageSpec"
    if ($SkipLiveMount) {
        Write-Host '并跳过运行中 Harness 的 dshmarket 热挂载。'
    } else {
        Write-Host '首次代际安装或当前插件未 live 时会跳过热挂载并提示完全重启；只有已 live 插件升级才同步客户端并使用 HMR。'
    }
    return
}

# Capture the pre-install state before the profile is changed.  A package that
# is already live must not be mounted a second time under the same loader name:
# the running process would then contain two fibers and the new one could win
# only until the next refresh.  Fresh installs (or installed-but-not-live
# packages) require a cold projection, so only an already-live upgrade can use
# the running dshmarket route below.
$profileHadPlugin = $false
$previousLivePackageDirectory = $null
if (Test-Path -LiteralPath $profileManifestPath -PathType Leaf) {
    try {
        $beforeManifest = Read-JsonFile -Path $profileManifestPath
        $profileHadPlugin = $null -ne $beforeManifest.dependencies.PSObject.Properties[$PluginName]
    } catch {
        $profileHadPlugin = $false
    }
}
if ($profileHadPlugin) {
    $previousLivePackageDirectory = Get-ProfilePackageTarget -ProfileRoot $profileRoot
    if ($null -ne $previousLivePackageDirectory) {
        Write-Host "已记录当前运行代际客户端路径：$previousLivePackageDirectory"
    }
}
$runningEndpoint = $null
$runningPluginWasLive = $false
if (-not $SkipLiveMount) {
    $runningEndpoint = Get-RunningDshWebEndpoint -RequestedUrl $WebUrl -ProfileName $Profile
    if ($null -ne $runningEndpoint) {
        $runningPluginWasLive = (Get-ActivationState -StatusData $runningEndpoint.Data) -eq 'live'
        if ($profileHadPlugin -and $runningPluginWasLive) {
            $detectedLivePackageDirectory = Get-RunningClientPackageTarget `
                -WebUri $runningEndpoint.Uri `
                -ProfileRoot $profileRoot `
                -FallbackTarget $previousLivePackageDirectory
            if ($null -ne $detectedLivePackageDirectory) {
                if ($detectedLivePackageDirectory -ne $previousLivePackageDirectory) {
                    Write-Host "已按运行中的 Web Client 内容校正代际路径：$detectedLivePackageDirectory"
                }
                $previousLivePackageDirectory = $detectedLivePackageDirectory
            }
        }
        if ($profileHadPlugin -and $runningPluginWasLive) {
            Write-Host '已发现正在运行的 DSH Web 与 dshmarket；这是已 live 插件升级，安装后将同步客户端并触发 HMR。'
        } else {
            Write-Host '已发现正在运行的 DSH Web 与 dshmarket；这是首次代际安装或未 live 插件，安装后将暂存并提示完全重启。'
        }
    } else {
        Write-Host '未发现可用的运行中 dshmarket；安装会先安全暂存，随后按需提示重启。'
    }
}

$networkState = $null
$pnpmState = $null
$generationInstallUsed = $false
try {
    $networkState = Initialize-ChildProcessNetwork `
        -RequestedProxy $Proxy `
        -RequestedRegistry $Registry `
        -Retries $FetchRetries
    $pnpmState = Use-ProfilePnpm -ProfileRoot $profileRoot
    try {
        $existingManifest = Read-JsonFile -Path $profileManifestPath
        Remove-LegacyProfilePackage -ProfileRoot $profileRoot -ProfileManifest $existingManifest

        if (-not $desktop.AsarMode -and -not (Test-Path -LiteralPath $desktop.GenerationInstallerPath -PathType Leaf)) {
            Write-Warning '当前 DSH Desktop 未提供代际安装器，将回退到内置 CLI 安装。'
            Invoke-DshPluginCli -Desktop $desktop -ProfileName $Profile -PluginArguments @('add', '--save-exact', $packageSpec)
            if ($LASTEXITCODE -ne 0) {
                throw "DSH 插件安装失败（退出码：$LASTEXITCODE）。$(Get-NetworkFailureHint -NetworkState $networkState)"
            }
        } else {
            $generationInstallUsed = $true
            $helperUrl = "https://raw.githubusercontent.com/$Repository/$Ref/scripts/install-generation.mjs"
            $generationTemporaryRoot = Join-Path ([System.IO.Path]::GetTempPath()) ('dsh-harness-chat-control-generation-' + [guid]::NewGuid().ToString('N'))
            New-Item -ItemType Directory -Path $generationTemporaryRoot | Out-Null
            $helperPath = Join-Path $generationTemporaryRoot 'install-generation.mjs'
            try {
                $downloadParameters = @{
                    UseBasicParsing = $true
                    Uri = $helperUrl
                    OutFile = $helperPath
                }
                if ($null -ne $networkState.ProxyUri) {
                    $downloadParameters.Proxy = $networkState.ProxyUri.AbsoluteUri
                }
                try {
                    Invoke-WebRequest @downloadParameters
                } catch {
                    $detail = Get-SafeHttpErrorDetail -ErrorRecord $_
                    $reason = '网络请求失败'
                    if ($null -ne $detail.StatusCode) {
                        $reason = "HTTP $($detail.StatusCode)"
                    }
                    if (-not [string]::IsNullOrWhiteSpace($detail.Body)) {
                        $reason += "；响应体：$($detail.Body)"
                    }
                    throw "无法下载代际安装 helper：$reason。$(Get-NetworkFailureHint -NetworkState $networkState)"
                }
                $helperArguments = @(
                    '--desktop-root', $desktop.Root,
                    '--profile', $Profile,
                    '--repository', $Repository,
                    '--ref', $Ref
                )
                if ($null -ne $networkState.RegistryUri) {
                    $helperArguments += @('--registry', $networkState.RegistryUri.AbsoluteUri)
                }
                if ($null -ne $networkState.ProxyUri) {
                    $helperArguments += @('--proxy', $networkState.ProxyUri.AbsoluteUri)
                }
                if ($runningPluginWasLive -and $null -ne $previousLivePackageDirectory) {
                    $helperArguments += @(
                        '--sync-live-client',
                        '--previous-package-directory', $previousLivePackageDirectory
                    )
                    Write-Host '当前 Harness 已加载旧代际；安装后将把新的 Web Client 同步到该路径，触发 DSH 内置 HMR。'
                }
                Invoke-DesktopNode -Desktop $desktop -Arguments (@($helperPath) + $helperArguments)
                if ($LASTEXITCODE -ne 0) {
                    throw "DSH Desktop 代际安装失败（退出码：$LASTEXITCODE）。$(Get-NetworkFailureHint -NetworkState $networkState)"
                }
            } finally {
                if (Test-Path -LiteralPath $generationTemporaryRoot) {
                    Remove-Item -LiteralPath $generationTemporaryRoot -Recurse -Force
                }
            }
        }
    } finally {
        if ($null -ne $pnpmState) {
            $env:PATH = $pnpmState.OriginalPath
            $pnpmTemporaryRoot = [System.IO.Path]::GetFullPath($pnpmState.TemporaryRoot)
            $temporaryParent = [System.IO.Path]::GetFullPath([System.IO.Path]::GetTempPath())
            if ($pnpmTemporaryRoot.StartsWith($temporaryParent, [System.StringComparison]::OrdinalIgnoreCase) -and (Test-Path -LiteralPath $pnpmTemporaryRoot)) {
                Remove-Item -LiteralPath $pnpmTemporaryRoot -Recurse -Force
            }
        }
    }
} finally {
    Restore-ChildProcessNetwork -State $networkState
}

$profileManifest = Read-JsonFile -Path $profileManifestPath
$bundles = @($profileManifest.dsh.profile.bundles)
$dependencyNames = @()
if ($null -ne $profileManifest.dependencies) {
    $dependencyNames = @($profileManifest.dependencies.PSObject.Properties.Name)
}
if ($dependencyNames -notcontains $PluginName) {
    throw "安装后未在 $profileManifestPath 的 dependencies 中找到 $PluginName。"
}
if ($bundles -notcontains $PluginName) {
    throw "安装后未在 dsh.profile.bundles 中找到 $PluginName；DSH 未将该插件注册为 profile layer。"
}

Write-Host "安装并验证成功：$PluginName 已注册到 profile '$Profile'。"

if ($SkipLiveMount) {
    Write-Host '已按 -SkipLiveMount 跳过运行中热挂载；请完全退出并重新打开 DSH Desktop。'
    return
}

if ($generationInstallUsed -and (-not $profileHadPlugin -or -not $runningPluginWasLive)) {
    if (-not $profileHadPlugin) {
        Write-Host '首次代际安装已完成；运行中的 DSH 无法替换 profile 链接，本次已跳过热挂载。'
    } else {
        Write-Host '插件已完成代际安装，但当前 Harness 未加载旧版本，本次已跳过热挂载。'
    }
    Write-Warning '请完全退出并重新打开 DSH Desktop，让代际投影生效；这不是安装失败。'
    return
}

if ($null -eq $runningEndpoint) {
    # The app may have started between the preflight and this point.  Discover
    # it once more for a fresh install, but never risk a duplicate mount when
    # the profile already contained this plugin before the command ran.
    if (-not $profileHadPlugin) {
        $runningEndpoint = Get-RunningDshWebEndpoint -RequestedUrl $WebUrl -ProfileName $Profile
    }
}

if ($null -eq $runningEndpoint) {
    Write-Warning '安装已完成，但未找到运行中的 dshmarket 热挂载接口；请完全退出并重新打开 DSH Desktop。'
    return
}

if ($runningPluginWasLive) {
    if ($null -ne $previousLivePackageDirectory) {
        Write-Host '已同步当前运行 Harness 正在监视的 Web Client 文件；请刷新 DSH 页面（Ctrl+R），无需重启 DSH Desktop。'
        return
    }
    Write-Warning '当前运行中的 Harness 已加载旧版 dsh-harness-chat-control，但未能解析其代际客户端路径；为避免重复 Loader，更新将在下次完全重启 DSH Desktop 时生效。'
    return
}

$hotMount = Invoke-DshMarketHotMount -WebUri $runningEndpoint.Uri -ProfileName $Profile
if ($hotMount.AlreadyLive) {
    Write-Warning '插件在安装过程中已经由当前 Harness 加载；为避免重复 Loader，本次不再热挂载，更新将在下次完全重启时生效。'
} elseif ($hotMount.Ok) {
    Write-Host '已通过运行中的 dshmarket 热挂载插件；请刷新 DSH Web 页面即可启动/显示插件。'
    if ($hotMount.NeedsRefresh) {
        Write-Host '提示：刷新当前 DSH 页面（Ctrl+R）即可加载新的 Web Client 代码，无需重启 DSH Desktop。'
    }
} else {
    Write-Warning "安装已完成，但当前 DSH 未确认热挂载：$($hotMount.Reason)"
    Write-Warning '插件已安全暂存到 profile；请完全退出并重新打开 DSH Desktop 后再检查。'
}
