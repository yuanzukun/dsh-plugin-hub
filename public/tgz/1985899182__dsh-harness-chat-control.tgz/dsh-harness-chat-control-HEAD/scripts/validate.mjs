import { execFileSync } from 'node:child_process'
import { readFileSync, existsSync } from 'node:fs'
import { resolve } from 'node:path'
import vm from 'node:vm'
import { apply as applyHost } from '../lib/index.js'

const root = resolve(import.meta.dirname, '..')
// Session format v4 refuses the retired `{ kind: 'plugin', plugin }` wrapper
// ("format v4 message requires a producer-owned source kind") and its own
// V3->V4 migration lifts an unknown plugin to `plugin:<package>`, so the
// boundary injection must be stamped with that producer-owned kind.
const SIDECHAT_INJECTION_KIND = 'plugin:dsh-harness-chat-control'
const required = [
  'package.json',
  'cordis.patch.yml',
  'lib/index.js',
  'lib/client.js',
  'scripts/install.ps1',
  'scripts/install-generation.mjs',
  'README.md',
  'LICENSE',
  'vendor/dsh-better-sidebar-0.24.1/NOTICE.md',
  'vendor/dsh-better-sidebar-0.24.1/LICENSE',
  'vendor/dsh-better-sidebar-0.24.1/SOURCE-VERSION.txt'
]

for (const relative of required) {
  const absolute = resolve(root, relative)
  if (!existsSync(absolute)) throw new Error(`Missing required plugin file: ${relative}`)
}

const manifest = JSON.parse(readFileSync(resolve(root, 'package.json'), 'utf8'))
if (manifest.name !== 'dsh-harness-chat-control') throw new Error('Unexpected package name')
if (manifest.version !== '0.3.2') throw new Error(`Unexpected plugin version: ${manifest.version}`)
if (manifest.dsh?.bundle?.patch !== './cordis.patch.yml') throw new Error('Missing DSH bundle patch declaration')
if (manifest.dsh?.client?.platform !== 'web') throw new Error('Missing DSH Web client declaration')
if (manifest.exports?.['./client']?.default !== './lib/client.js') throw new Error('Missing client export')
if (manifest.exports?.['./runtime']?.default !== './lib/index.js') throw new Error('Missing versioned runtime export')
if (manifest.exports?.['./package.json'] !== './package.json') throw new Error('Missing package manifest export for Desktop discovery')
if (!manifest.files?.includes('scripts')) throw new Error('The distributable package must include its installer')
if (manifest.engines?.node !== '>=20' || manifest.engines?.pnpm !== '>=10 <12') {
  throw new Error('The package must declare the supported Node.js and pnpm ranges')
}

const desktopClientDependencies = [
  '@deepseek-ai/dsh-api-session-controller',
  '@deepseek-ai/dsh-client-ui-chat',
  '@deepseek-ai/dsh-client-ui-layout',
  '@deepseek-ai/dsh-client-ui-sidebar',
  '@deepseek-ai/dsh-client-ui-conversation',
  '@deepseek-ai/dsh-client-ui-input-trigger',
  '@deepseek-ai/dsh-client-ui-model-selection',
  '@deepseek-ai/dsh-client-ui-primitives',
  '@deepseek-ai/dsh-client-locale',
  '@deepseek-ai/dsh-client-ui-slots',
  '@deepseek-ai/dsh-client-modules',
  'dsh-better-sidebar'
]
if (JSON.stringify(manifest.dsh.client.inject) !== JSON.stringify(desktopClientDependencies)) {
  throw new Error('Client injection order does not match the DSH Desktop 0.2.0-rc.2 contract')
}
if (manifest.peerDependencies?.['@deepseek-ai/dsh-client-runtime'] !== undefined) {
  throw new Error('The obsolete dsh-client-runtime dependency must not be declared')
}
if (manifest.peerDependencies?.['@deepseek-ai/dsh-client-ui-input-trigger'] !== '0.2.0-rc.2') {
  throw new Error('The native reference-chip input trigger dependency is missing')
}
if (manifest.dependencies?.['dsh-better-sidebar'] !== '0.24.1') {
  throw new Error('The exact Better Sidebar 0.24.1 dependency is missing')
}
if (manifest.peerDependencies?.['@deepseek-ai/dsh-client-ui-primitives'] !== '0.2.0-rc.2'
  || manifest.peerDependencies?.['@deepseek-ai/dsh-client-locale'] !== '0.2.0-rc.2'
  || manifest.peerDependencies?.['@deepseek-ai/dsh-client-ui-slots'] !== '0.2.0-rc.2'
  || manifest.peerDependencies?.['@deepseek-ai/dsh-client-modules'] !== '0.2.0-rc.2'
  || manifest.peerDependencies?.['@deepseek-ai/dsh-client-ui-model-selection'] !== '0.2.0-rc.2'
  || manifest.peerDependencies?.['@deepseek-ai/dsh-llm'] !== '0.2.0-rc.2'
  || manifest.peerDependencies?.['@deepseek-ai/dsh-subagent'] !== '0.2.0-rc.2') {
  throw new Error('The owned sidechat host/client peers are missing')
}

const installerPath = resolve(root, 'scripts', 'install.ps1')
const installer = readFileSync(installerPath, 'utf8')
const generationInstaller = readFileSync(resolve(root, 'scripts', 'install-generation.mjs'), 'utf8')
if (!installer.includes("$Repository = '1985899182/dsh-harness-chat-control'") || !installer.includes('$packageSpec = "git+https://github.com/$Repository.git#$Ref"')) {
  throw new Error('Installer must use the explicit HTTPS GitHub package spec')
}
if (!installer.includes("[string]$Ref = 'v0.3.2'")) {
  throw new Error('Installer default ref must point at the published stable tag')
}
if (!generationInstaller.includes("ref: DEFAULT_REF") || !generationInstaller.includes('git+https://github.com/${repository}.git#${ref}')) {
  throw new Error('Generation installer default ref must point at the published stable tag')
}
if (!installer.includes('New-DshMarketRouteUri -WebUri $WebUri -Path "/plugins/??$PluginName/client.js"')) {
  throw new Error('Installer must preserve the authenticated Web token while matching the running client artifact')
}
if (!installer.includes('dsh.profile.bundles')) {
  throw new Error('Installer must verify DSH bundle registration')
}
for (const phrase of [
  'dsh-market/installed',
  'dsh-market/toggle',
  'ConvertTo-LoopbackWebUri',
  'Invoke-DshMarketHotMount',
  'runningPluginWasLive',
  '为避免重复 Loader',
  '[string]$WebUrl',
  '[switch]$SkipLiveMount',
  'Get-ProfilePackageTarget',
  'Get-RunningClientPackageTarget',
  '--sync-live-client',
  '--previous-package-directory',
  '内置 HMR',
  '无需重启 DSH Desktop',
  'Normalize-ClientArtifactText',
  'Get-ClientArtifactHash',
  'Warn-IncompatibleBetterSidebar',
  'dsh-better-sidebar@0.24.1',
  'ConvertTo-HttpProxyUri',
  'Get-WinInetProxyUri',
  'Initialize-ChildProcessNetwork',
  'Get-NetworkFailureHint',
  'Get-SafeHttpErrorDetail',
  'ReadAsStringAsync',
  'GetResponseStream',
  '-Proxy',
  '-Registry',
  'NPM_CONFIG_FETCH_RETRIES',
  '首次代际安装或当前插件未 live',
  '响应体：',
]) {
  if (!installer.includes(phrase)) throw new Error(`Installer is missing the live-install seam: ${phrase}`)
}
if (!readFileSync(resolve(root, 'cordis.patch.yml'), 'utf8').includes('inject: [clientModules, webServer, webRuntime')) {
  throw new Error('Host patch must wait for the clientModules service before mounting')
}
if (!readFileSync(resolve(root, 'cordis.patch.yml'), 'utf8').includes('webServer, webRuntime')) {
  throw new Error('Host patch must inject the web route services for sidechat model selection')
}
if (!readFileSync(resolve(root, 'cordis.patch.yml'), 'utf8').includes('sessionController, agents')) {
  throw new Error('Host patch must expose the live Agent service for in-place message replacement')
}
if (!readFileSync(resolve(root, 'README.md'), 'utf8').includes('dsh plugin --profile web add --save-exact --allow-build=node-pty')) {
  throw new Error('README must document the standard dsh plugin installer')
}
const readme = readFileSync(resolve(root, 'README.md'), 'utf8')
for (const phrase of ['1 条注释', 'dsh-better-sidebar@0.24.1', '侧边原生对话栏', '铅笔按钮', '卡死', 'README_EN.md', 'README_JA.md', 'README_KO.md']) {
  if (!readme.includes(phrase)) throw new Error(`README is missing the native reference/sidechat note: ${phrase}`)
}
for (const relative of ['README_EN.md', 'README_JA.md', 'README_KO.md']) {
  const translated = readFileSync(resolve(root, relative), 'utf8')
  for (const phrase of ['dsh plugin --profile web add --save-exact --allow-build=node-pty', 'main-conversation-quote.svg', 'sidebar-conversation-quote.svg', 'v0.3.2']) {
    if (!translated.includes(phrase)) throw new Error(`${relative} is missing translated install/example content: ${phrase}`)
  }
}
if (process.platform === 'win32') {
  const escapedInstallerPath = installerPath.replace(/'/g, "''")
  const parseCommand = [
    '$tokens = $null',
    '$parseErrors = $null',
    `[void][System.Management.Automation.Language.Parser]::ParseFile('${escapedInstallerPath}', [ref]$tokens, [ref]$parseErrors)`,
    'if ($parseErrors.Count -gt 0) { $parseErrors | ForEach-Object { Write-Error $_ }; exit 1 }'
  ].join('; ')
  execFileSync('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', parseCommand], { stdio: 'inherit' })
}

for (const relative of ['lib/index.js', 'lib/client.js']) {
  execFileSync(process.execPath, ['--check', resolve(root, relative)], { stdio: 'inherit' })
}
execFileSync(process.execPath, ['--check', resolve(root, 'scripts/install-generation.mjs')], { stdio: 'inherit' })

let registeredModule
const registeredModules = []
const registrations = []
const injectedSlots = []
const insertedReferences = []
const registeredSources = []
const editRequests = []
const sourcePrompts = []
const fakeReact = {
  Fragment: Symbol('Fragment'),
  createElement: (...args) => ({ args }),
  useState: (initial) => [initial, () => {}],
  useRef: (initial) => ({ current: initial }),
  useEffect: (effect) => { effect?.() },
  useSyncExternalStore: (_subscribe, getSnapshot) => getSnapshot()
}

const browserSandbox = {
  window: {
    __ModuleLoader__: {
      load(definition) {
        registeredModules.push(definition)
        if (definition?.id === 'dsh-harness-chat-control') registeredModule = definition
      }
    },
    getSelection: () => ({ toString: () => '' }),
    addEventListener: () => {},
    removeEventListener: () => {}
  },
  fetch: async (url, options = {}) => {
    editRequests.push({
      url,
      payload: JSON.parse(options.body || '{}')
    })
    return {
      ok: true,
      status: 200,
      json: async () => ({ ok: true, value: { sessionId: 'desktop-session-1', armed: true } })
    }
  },
  document: {
    querySelector: () => null,
    createElement: () => ({ dataset: {} }),
    head: { appendChild: () => {} }
  },
  console
}

const clientSource = readFileSync(resolve(root, 'lib/client.js'), 'utf8')
const hostSource = readFileSync(resolve(root, 'lib/index.js'), 'utf8')
if ((clientSource.match(/function referencePreview\(text\)/gu) || []).length !== 1) {
  throw new Error('Reference preview helper must be defined once at client module scope')
}
for (const obsolete of ['createSideChatDraftController', 'createSideChatModelController', 'function SidechatComposer']) {
  if (clientSource.includes(obsolete)) throw new Error(`Obsolete sidechat implementation remains: ${obsolete}`)
}
if (!clientSource.includes("const serviceOf = () => safeGet(ctx, 'betterSidebar')")) {
  throw new Error('Client must resolve betterSidebar through ctx.get; undeclared Cordis properties abort startup')
}
for (const obsolete of ['SIDECHAT_PERMISSION_ROUTE', 'PERMISSION_ROUTE', 'createSidechatPermissionRoute']) {
  if (clientSource.includes(obsolete) || hostSource.includes(obsolete)) {
    throw new Error(`Obsolete sidechat permission route remains: ${obsolete}`)
  }
}
if (!clientSource.includes('createSideChatDraftStore')
  || !clientSource.includes('sidechatReferenceAccessory')
  || !clientSource.includes('dshhc-sidechat-reference-remove')
  || !clientSource.includes("id: 'dsh-harness-chat-control-sidechat'")
  || !clientSource.includes('installOwnedSidechatView')) {
  throw new Error('Native sidechat draft/reference store is missing')
}
if (clientSource.includes('row.append(chip, remove)') || clientSource.includes('stopImmediatePropagation')) {
  throw new Error('Sidechat must not mutate the host composer DOM or intercept its event loop')
}
if (!clientSource.includes("const SIDECHAT_MODEL_ROUTE = '/dsh-harness-chat-control/sidechat-model'")) {
  throw new Error('Sidechat model selector route is missing')
}
if (!clientSource.includes("const SIDECHAT_HISTORY_ROUTE = '/dsh-harness-chat-control/sidechat-history'")) {
  throw new Error('Sidechat history compatibility route is missing')
}
if (!clientSource.includes('conversation.input.model')
  || !clientSource.includes('modelInjected?.directory')
  || !clientSource.includes('sideModelDirectory')
  || !clientSource.includes('selectSideModel')) {
  throw new Error('Sidechat model catalog selector seam is missing')
}
if (!clientSource.includes('overlaySnapshot') || !clientSource.includes('useSyncExternalStore')) {
  throw new Error('Sidechat model directory must cache its overlay snapshot for React stability')
}
for (const phrase of ['dshhc-sidechat-native-composer', 'dshhc-sidechat-view', 'dshhc-sidechat-native-view [class*="sidechatComposer"]', 'data-composer-card', 'JyqXLa_root', 'refreshSidechatSession', 'updateTab', 'Promise.allSettled', 'CONNECTION_STATE_BRIDGE', 'installConnectionStateBridge', 'connection.generation']) {
  if (!clientSource.includes(phrase)) throw new Error(`Native sidechat integration is missing: ${phrase}`)
}
for (const phrase of ['createSideChatDraftStore', 'NativeSidechatComposer', 'installOwnedSidechatView', 'dshhc-sidechat-view', 'dshhc-sidechat-native-view [class*="sidechatComposer"]', "callSidebarApi('sidechat.prompt'", "callSidebarApi('sidechat.cancel'"]) {
  if (!clientSource.includes(phrase)) throw new Error(`React sidechat composer seam is missing: ${phrase}`)
}
for (const phrase of ['NativeSidechatComposer', 'conversation.composer.bar', 'resolveNativeSessionBinding', 'data-dsh-harness-native-inputbar', 'new Proxy(target', 'useNativeSource']) {
  if (!clientSource.includes(phrase)) throw new Error(`The sidechat must reuse the native InputBar seam: ${phrase}`)
}
if (clientSource.includes('sideChatModels.start()')) throw new Error('The obsolete DOM-mutating sidechat model controller is still active')
if (clientSource.includes('stopImmediatePropagation')) throw new Error('Sidechat interception must not freeze the host event loop')
if (!clientSource.includes('return [serializeReferenceText(cleanReference), cleanQuestion]')) {
  throw new Error('Sidechat quote must not manufacture a visible question')
}
if (clientSource.includes('function quoteLines') || clientSource.includes(".map((line) => `> ${line}`")) {
  throw new Error('Quote serialization must not manufacture Markdown blockquotes')
}
for (const phrase of ['REFERENCE_CONTEXT_HEADER', 'REFERENCE_CONTEXT_START', 'REFERENCE_CONTEXT_END', 'REFERENCE_TOKEN_PATTERN', 'normalizeReferenceDraft', 'detectLength', '【引用开始】', '【引用结束】']) {
  if (!clientSource.includes(phrase)) throw new Error(`Plain-text quote boundary is missing: ${phrase}`)
}
if (!hostSource.includes("const MODEL_ROUTE = '/dsh-harness-chat-control/sidechat-model'")
  || !hostSource.includes('selectForNextRequest')
  || !hostSource.includes('trustedRequest')) {
  throw new Error('Host sidechat model route validation/selection seam is missing')
}
if (!hostSource.includes("const HISTORY_ROUTE = '/dsh-harness-chat-control/sidechat-history'")
  || !hostSource.includes('sessionPersistence')
  || !hostSource.includes('createSidechatHistoryRoute')) {
  throw new Error('Host sidechat history compatibility route is missing')
}
for (const phrase of ['buildSidechatApi', 'sidechat.start', 'sidechat.prompt', 'sidechat.cancel', 'sidechat.info', 'Sidechat engine copied from dsh-better-sidebar@0.17.1', "path: `/sidebar/api/${method}`"]) {
  if (!hostSource.includes(phrase)) throw new Error(`Owned sidechat API seam is missing: ${phrase}`)
}
if (!hostSource.includes("typeof payload?.childId === 'string'")
  || !hostSource.includes("requireField(payload, 'sessionId')")) {
  throw new Error('Host sidechat history route must accept the native sessionId payload')
}
for (const phrase of ['dshhc-message-edit', '编辑消息', 'data-composer-input', 'target.submit', 'inputActions', 'keyboard', 'replaceSession', 'armSessionEdit', 'SESSION_EDIT_ROUTE']) {
  if (!clientSource.includes(phrase)) throw new Error(`Native composer edit seam is missing: ${phrase}`)
}
for (const phrase of ['rewriteInfoForSession', 'rewriteNodeForSnapshot', 'conversation.chat.node', "original turn's position"]) {
  if (!clientSource.includes(phrase)) throw new Error(`In-place rewrite projection is missing: ${phrase}`)
}
for (const phrase of ['SESSION_EDIT_ROUTE', 'createSessionEditRoute', 'editedText', 'surfaceOp: { op: \'replace\'', 'sourceEventSeqs']) {
  if (!hostSource.includes(phrase)) throw new Error(`Host in-place edit route is missing: ${phrase}`)
}
for (const phrase of ['dshhc-revision-card', '上一条提问', 'dshhc-revision-editor']) {
  if (clientSource.includes(phrase)) throw new Error(`The obsolete standalone revision UI remains: ${phrase}`)
}
for (const label of ['添加到对话', '更多详情', '在侧边聊天中提问']) {
  if (!clientSource.includes(label)) throw new Error(`Selection toolbar label is missing: ${label}`)
}

// Exercise the host seam that makes an edited native prompt replace the
// existing surface range.  The durable events remain append-only, while the
// replacement event shadows the old user turn in the same Session.
const hostRoutes = new Map()
const hostEffects = []
const hostEvents = [
  {
    seq: 0,
    type: 'user/message',
    data: { source: { kind: 'user' }, content: [{ type: 'text', text: '原消息' }] }
  },
  {
    seq: 1,
    type: 'assistant/message',
    data: { source: { kind: 'assistant' }, content: [{ type: 'text', text: '原回答' }] }
  }
]
const hostAppends = []
const hostSession = {
  id: 'host-session',
  events: hostEvents,
  surface: { nodes: [0, 1] },
  header: { origin: 'user', cwd: 'D:/Study', agentPreset: 'default' },
  append(type, data, options) {
    const event = { seq: this.events.length, type, data, ...(options || {}) }
    this.events.push(event)
    hostAppends.push({ type, data, options })
    return event
  }
}
const hostAgent = { id: 'host-session', session: hostSession, status: 'idle', options: { provider: 'deepseek', model: 'v4' } }
const coldSession = {
  events: hostEvents.map((event) => ({ ...event, data: { ...event.data, content: [{ type: 'text', text: event.type === 'user/message' ? '冷会话原消息' : '冷会话原回答' }] } })),
  surface: { nodes: [0, 1] },
  header: { origin: 'user' },
  append(type, data, options) {
    const event = { seq: this.events.length, type, data, ...(options || {}) }
    this.events.push(event)
    hostAppends.push({ type, data, options, cold: true })
    return event
  }
}
const coldAgent = { session: coldSession, status: 'idle' }
const childAgents = new Map()
const hostAgents = {
  get: (sessionId) => sessionId === 'host-session' ? hostAgent : childAgents.get(sessionId),
  async serializeImageAdmission(_agent, operation) {
    return operation()
  },
  async create(options) {
    const childSession = {
      id: options.sessionId,
      events: [...options.seed],
      header: { ...options.meta, origin: 'subagent', parentSession: 'host-session' },
    }
    const child = {
      id: options.sessionId,
      session: childSession,
      status: 'idle',
      options: options.agentOptions,
      inject(message) {
        if (typeof message?.id !== 'string' || message.id === '') throw new Error('Sidechat injection message is missing a stable id')
        childSession.events.push({ seq: childSession.events.length, type: 'user/message', time: Date.now(), data: message, source: message.source })
      },
      followup(message) {
        if (typeof message?.id !== 'string' || message.id === '') throw new Error('Sidechat follow-up message is missing a stable id')
        childSession.events.push({ seq: childSession.events.length, type: 'user/message', time: Date.now(), data: message, source: message.source })
      },
      cancel() { child.status = 'idle' },
    }
    childAgents.set(options.sessionId, child)
    return { agent: child, dispose() { childAgents.delete(options.sessionId) } }
  }
}
const hostContext = {
  effect(callback) {
    const cleanup = callback()
    if (typeof cleanup === 'function') hostEffects.push(cleanup)
    return cleanup
  },
  get(name) {
    if (name === 'webServer') {
      return {
        register(route) {
          hostRoutes.set(route.path, route.handler)
          return () => hostRoutes.delete(route.path)
        }
      }
    }
    if (name === 'webRuntime') return { trustedHosts: [] }
    if (name === 'agents') return hostAgents
    if (name === 'attachments') {
      return {
        async saveImages(images) {
          return images.map((image, index) => ({
            attachmentId: `att-${index}`,
            mediaType: image.mediaType,
            bytes: image.data.byteLength,
            width: 1,
            height: 1,
            ...(image.name === undefined ? {} : { name: image.name })
          }))
        }
      }
    }
    if (name === 'llm') return {
      async resolveCallConfig(selection) { return { ...selection } },
      async resolveModelInfo() { return { inputModalities: ['text', 'image'] } }
    }
    if (name === 'sessionController') return {
      resolveAgent: async (sessionId) => sessionId === 'cold-session' ? { agent: coldAgent } : { error: { code: 'session-not-found' } },
      agents: {
        selectionFor(agent) {
          return { current: agent.selected || { provider: 'deepseek', model: 'v4' } }
        },
        selectForNextRequest(agent, selection) {
          agent.selected = selection
        },
        async serializeImageAdmission(_agent, operation) {
          return operation()
        }
      }
    }
    return undefined
  },
  logger: { warn() {} }
}
applyHost(hostContext)
const sessionEditHandler = hostRoutes.get('/dsh-harness-chat-control/session-edit')
if (typeof sessionEditHandler !== 'function') throw new Error('Host session-edit route was not registered')
const hostRequest = (payload) => ({
  method: 'POST',
  headers: { host: '127.0.0.1' },
  async *[Symbol.asyncIterator]() { yield JSON.stringify(payload) }
})
const hostResponse = () => {
  const response = {
    status: 0,
    body: undefined,
    writeHead(status) { this.status = status },
    end(body) { this.body = JSON.parse(body) }
  }
  return response
}
const editResponse = hostResponse()
await sessionEditHandler(hostRequest({
  sessionId: 'host-session',
  startSeq: 0,
  targetText: '原消息',
  text: '修改后的消息'
}), editResponse)
if (editResponse.status !== 200 || editResponse.body?.ok !== true) {
  throw new Error(`Host session-edit route did not arm the live session: ${JSON.stringify(editResponse)}`)
}
hostSession.append('user/message', {
  source: { kind: 'user' },
  content: [{ type: 'text', text: '修改后的消息' }]
}, { surfaceOp: 'append' })
const editAppend = hostAppends.at(-1)
// The host's `isReplaceOp` accepts only the exact positional-replacement shape
// `{ op, startSeq, endSeq }`; any extra or renamed key aborts the whole admission
// with `carries an invalid replace surfaceOp`.
const replaceOpShapeOf = (append) => JSON.stringify(Object.keys(append?.options?.surfaceOp ?? {}).sort())
if (editAppend?.options?.surfaceOp?.op !== 'replace'
  || editAppend.options.surfaceOp.startSeq !== 0
  || editAppend.options.surfaceOp.endSeq !== 1
  || replaceOpShapeOf(editAppend) !== JSON.stringify(['endSeq', 'op', 'startSeq'])
  || JSON.stringify(editAppend.options.sourceEventSeqs) !== JSON.stringify([0, 1])) {
  throw new Error(`Edited prompt was appended instead of replacing the original surface: ${JSON.stringify(editAppend)}`)
}

// Native Chat deliberately keeps the append-origin transcript row as the
// durable audit history, so a second click on that same row still reports its
// original anchor (0) even though the model surface now contains replacement
// node 2.  The host must follow that replacement lineage instead of returning
// the misleading message-not-found response.
hostSession.surface.nodes = [2]
const secondEditResponse = hostResponse()
await sessionEditHandler(hostRequest({
  sessionId: 'host-session',
  startSeq: 0,
  targetText: '原消息',
  text: '再次修改后的消息'
}), secondEditResponse)
if (secondEditResponse.status !== 200 || secondEditResponse.body?.ok !== true) {
  throw new Error(`A transcript row shadowed by a prior replacement could not be edited again: ${JSON.stringify(secondEditResponse)}`)
}
hostSession.append('user/message', {
  source: { kind: 'user' },
  content: [{ type: 'text', text: '再次修改后的消息' }]
}, { surfaceOp: 'append' })
const secondEditAppend = hostAppends.at(-1)
if (secondEditAppend?.options?.surfaceOp?.op !== 'replace'
  || secondEditAppend.options.surfaceOp.startSeq !== 2
  || secondEditAppend.options.surfaceOp.endSeq !== 2
  || replaceOpShapeOf(secondEditAppend) !== JSON.stringify(['endSeq', 'op', 'startSeq'])
  || JSON.stringify(secondEditAppend.options.sourceEventSeqs) !== JSON.stringify([2])) {
  throw new Error(`The second edit did not follow the current replacement node: ${JSON.stringify(secondEditAppend)}`)
}

const coldResponse = hostResponse()
await sessionEditHandler(hostRequest({
  sessionId: 'cold-session',
  startSeq: 0,
  targetText: '冷会话原消息',
  text: '冷会话修改后的消息'
}), coldResponse)
if (coldResponse.status !== 200 || coldResponse.body?.ok !== true) {
  throw new Error(`Cold-session edit was not resumed through sessionController: ${JSON.stringify(coldResponse)}`)
}
coldSession.append('user/message', {
  source: { kind: 'user' },
  content: [{ type: 'text', text: '冷会话修改后的消息' }]
}, { surfaceOp: 'append' })
const coldEditAppend = hostAppends.at(-1)
if (coldEditAppend?.options?.surfaceOp?.op !== 'replace') {
  throw new Error(`Cold-session prompt was not armed for surface replacement: ${JSON.stringify(coldEditAppend)}`)
}
const sidechatStartHandler = hostRoutes.get('/sidebar/api/sidechat.start')
const sidechatPromptHandler = hostRoutes.get('/sidebar/api/sidechat.prompt')
const sidechatInfoHandler = hostRoutes.get('/sidebar/api/sidechat.info')
if (typeof sidechatStartHandler !== 'function'
  || typeof sidechatPromptHandler !== 'function'
  || typeof sidechatInfoHandler !== 'function') {
  throw new Error('Owned /sidebar/api sidechat routes were not registered')
}
const sidechatStartResponse = hostResponse()
await sidechatStartHandler(hostRequest({ sessionId: 'host-session', question: '' }), sidechatStartResponse)
if (sidechatStartResponse.status !== 200 || sidechatStartResponse.body?.ok !== true) {
  throw new Error(`Owned sidechat start route failed: ${JSON.stringify(sidechatStartResponse)}`)
}
const childId = sidechatStartResponse.body.value.childId
if (typeof childId !== 'string' || childAgents.get(childId) === undefined) {
  throw new Error(`Owned sidechat did not create a child agent: ${JSON.stringify(sidechatStartResponse.body)}`)
}
const sidechatModelHandler = hostRoutes.get('/dsh-harness-chat-control/sidechat-model')
const sidechatModelResponse = hostResponse()
await sidechatModelHandler(hostRequest({
  childId,
  provider: 'deepseek',
  model: 'v4-vision',
  reasoningEffort: 'high'
}), sidechatModelResponse)
if (sidechatModelResponse.status !== 200
  || sidechatModelResponse.body?.value?.selected?.model !== 'v4-vision'
  || childAgents.get(childId).selected?.model !== 'v4-vision') {
  throw new Error(`Owned sidechat model selection was not applied to the child: ${JSON.stringify(sidechatModelResponse.body)}`)
}
const sidechatPromptResponse = hostResponse()
await sidechatPromptHandler(hostRequest({ childId, text: '请解释这段引用' }), sidechatPromptResponse)
if (sidechatPromptResponse.status !== 200 || sidechatPromptResponse.body?.ok !== true) {
  throw new Error(`Owned sidechat prompt route failed: ${JSON.stringify(sidechatPromptResponse)}`)
}
const childEvents = childAgents.get(childId).session.events
const firstAdmittedIndex = childEvents.findIndex((event) => event.type === 'user/message' && event.data?.source?.kind === SIDECHAT_INJECTION_KIND)
const admittedMessages = (firstAdmittedIndex < 0 ? [] : childEvents.slice(firstAdmittedIndex))
  .filter((event) => event.type === 'user/message' && event.data?.source?.kind !== undefined)
  .map((event) => event.data)
if (admittedMessages.length < 2
  || new Set(admittedMessages.map((message) => message.id)).size !== admittedMessages.length) {
  throw new Error(`Owned sidechat messages must carry unique stable ids: ${JSON.stringify(admittedMessages)}`)
}
if (!childEvents.some((event) => event.type === 'user/message' && event.data?.source?.kind === SIDECHAT_INJECTION_KIND)) {
  throw new Error('Owned sidechat did not record its context boundary injection')
}
if (childEvents.some((event) => event.type === 'user/message' && event.data?.source?.kind === 'plugin')) {
  throw new Error('Sidechat admission still stamps the retired V4 `plugin` source wrapper')
}
if (!childEvents.some((event) => event.type === 'user/message' && event.data?.source?.kind === 'user'
  && event.data?.content?.[0]?.text === '请解释这段引用')) {
  throw new Error('Owned sidechat did not admit the user follow-up')
}
const imagePromptResponse = hostResponse()
await sidechatPromptHandler(hostRequest({
  childId,
  text: '请识别这张图',
  images: [{ mediaType: 'image/png', data: 'aA==', name: 'sample.png' }]
}), imagePromptResponse)
if (imagePromptResponse.status !== 200 || imagePromptResponse.body?.ok !== true) {
  throw new Error(`Owned sidechat image prompt failed: ${JSON.stringify(imagePromptResponse)}`)
}
const imageMessage = childAgents.get(childId).session.events
  .map((event) => event.data)
  .find((message) => message?.source?.kind === 'user'
    && message?.content?.some((block) => block?.type === 'image'))
if (imageMessage?.content?.[0]?.type !== 'image'
  || imageMessage.content[0].attachment?.attachmentId !== 'att-0') {
  throw new Error(`Sidechat image was not admitted as a durable native image block: ${JSON.stringify(imageMessage)}`)
}
const sidechatInfoResponse = hostResponse()
await sidechatInfoHandler(hostRequest({ childId }), sidechatInfoResponse)
if (sidechatInfoResponse.status !== 200 || sidechatInfoResponse.body?.value?.provider !== 'deepseek') {
  throw new Error(`Owned sidechat info route lost the parent model identity: ${JSON.stringify(sidechatInfoResponse)}`)
}
for (const cleanup of hostEffects) cleanup()

vm.runInNewContext(readFileSync(resolve(root, 'lib/client.js'), 'utf8'), browserSandbox, {
  filename: 'lib/client.js'
})

if (registeredModule?.id !== 'dsh-harness-chat-control') throw new Error('Client loader registration failed')
const clientPlugin = registeredModule.factory((specifier) => {
  if (specifier === 'react') return fakeReact
  if (specifier === 'dsh-better-sidebar/client') return { apply() {} }
  if (specifier === 'dsh-harness-chat-control-sidechat') return { SideChatView: () => null }
  throw new Error(`Unexpected client dependency: ${specifier}`)
})

const fakeSlots = {
  inject(name, callback) {
    injectedSlots.push(name)
    return callback()
  },
  register(config, component) {
    registrations.push({ config, component })
    return () => {}
  }
}

let fakeInputSnapshot = { draft: '已有草稿', draftRev: 7 }
const fakeInput = {
  state: {
    getSnapshot: () => fakeInputSnapshot
  }
}
const fakeConversation = {
  input: {
    for: () => fakeInput
  }
}
const fakeSessionContext = {
  get(name) {
    return name === 'conversation' ? fakeConversation : undefined
  },
  bail: (_actx, event, payload) => {
    if (event !== 'slash/input-insert-reference') return false
    insertedReferences.push({ outcome: { insert: payload.reference }, span: payload.span })
    return true
  }
}
const fakeInputTriggers = {
  registerSource(source) {
    registeredSources.push(source)
    return () => {}
  },
  sessionOf: () => ({
    execute(outcome, span) {
      insertedReferences.push({ outcome, span })
      return true
    }
  })
}

const fakeSessionsById = new Map()
const sourceSession = {
  sessionId: 'desktop-session-1',
  getSnapshot: () => ({ running: false }),
  prompt: async (content) => {
    sourcePrompts.push(content)
    return { ok: true }
  }
}
fakeSessionsById.set('desktop-session-1', { session: sourceSession })

clientPlugin.apply({
  slots: fakeSlots,
  sessions: {
    binding: (id) => fakeSessionsById.get(String(id)),
    list: { getSnapshot: () => ({ byId: { 'desktop-session-1': { cwd: 'D:/Study' } } }) },
    scope: () => fakeSessionContext
  },
  effect(callback) {
    return callback()
  },
  get(name) {
    if (name === 'inputTriggers') return fakeInputTriggers
    if (name === 'conversation') return fakeConversation
    return undefined
  }
})

const expectedSlots = [
  'conversation.chat.assistant-actions',
  'conversation.input.dock',
  'sidebar.footer.action',
  'shell.overlay'
]
if (JSON.stringify(injectedSlots) !== JSON.stringify(expectedSlots)) {
  throw new Error(`Unexpected injected slots: ${JSON.stringify(injectedSlots)}`)
}
if (registrations.length !== expectedSlots.length) throw new Error('Expected four UI registrations')
if (!registrations.every(({ config }) => typeof config.id === 'string' && typeof config.inject === 'function')) {
  throw new Error('Every UI registration must have a stable id and injection factory')
}

const desktopChatSnapshot = {
  nodes: new Map([
    ['previous-tail', {
      key: 'previous-tail',
      kind: 'turn-tail',
      anchorSeq: 42,
      location: { kind: 'turn', turn: { turn: 1, end: { seq: 42 } } },
      data: { closing: { finalNode: { seq: 42 }, blocks: [] } }
    }],
    ['prompt', {
      key: 'prompt',
      kind: 'user',
      anchorSeq: 50,
      location: { kind: 'turn', turn: { turn: 2 } },
      data: { content: [{ type: 'text', text: '请把答案改短一些' }] }
    }],
    ['answer', {
      kind: 'assistant-step',
      data: {
        finalNode: { messageId: 'desktop-answer-1' },
        blocks: [{ kind: 'text', text: '这是 DSH Desktop 的回答。' }]
      }
    }]
  ])
}

// The current DSH Desktop TurnTailNodeView passes the completed answer as
// `node.data.closing.blocks`; `closing.finalNode` only carries message identity.
const desktopTurnTailSnapshot = {
  nodes: new Map([
    ['tail', {
      kind: 'turn-tail',
      data: {
        closing: {
          finalNode: { messageId: 'desktop-tail-answer-1', seq: 42 },
          blocks: [{ kind: 'text', text: '这是 TurnTail 中的 DSH Desktop 回答。' }]
        }
      }
    }]
  ])
}

const quoteRegistration = registrations.find(({ config }) => config.id === 'harness-quote-actions')
const revisionRegistration = registrations.find(({ config }) => config.id === 'harness-revision')
const shellRegistration = registrations.find(({ config }) => config.id === 'harness-selection-toolbar')
if (quoteRegistration === undefined || revisionRegistration === undefined) {
  throw new Error('Required Desktop UI registrations are missing')
}
if (shellRegistration === undefined) throw new Error('Selection toolbar shell registration is missing')
if (registeredSources.length !== 1 || registeredSources[0].name !== 'dsh-harness-chat-control') {
  throw new Error('The native annotation reference source was not registered')
}

const quoteProps = quoteRegistration.config.inject('desktop-session-1')
const sideCalls = []
const quoteView = quoteRegistration.component({
  ...quoteProps,
  messageId: 'desktop-answer-1',
  useChat: (select) => select(desktopChatSnapshot),
  useInput: (select) => select({ draft: '' }),
  inputActions: { setDraft: () => {} },
  openSideChat: (...args) => sideCalls.push(args)
})
if (quoteView === null) throw new Error('Assistant action cannot read the DSH Desktop chat snapshot')
quoteView.args[2].args[1].onClick({})
if (insertedReferences.length !== 1) throw new Error('Assistant quote did not insert one native reference chip')
const inserted = insertedReferences[0]
const reference = inserted.outcome?.insert
if (reference?.source !== 'dsh-harness-chat-control'
  || reference?.label !== '1 条注释'
  || reference?.appearance !== 'session'
  || inserted.span?.draftRev !== 7
  || inserted.span?.start !== 4
  || inserted.span?.end !== 4) {
  throw new Error(`Assistant quote did not produce the expected atomic reference: ${JSON.stringify(inserted)}`)
}
const serialized = await registeredSources[0].codec.serialize(reference.ref)
if (!serialized.includes('这是 DSH Desktop 的回答。')) throw new Error('Reference serializer lost the selected answer')
if (serialized.includes('\n---\n') || /(?:^|\n)>\s/u.test(serialized)) {
  throw new Error('Reference serializer must not add Markdown separators or blockquotes')
}
if (!serialized.includes('【引用开始】') || !serialized.includes('【引用结束】')) {
  throw new Error('Reference serializer must keep plain-text context boundaries')
}
if (registeredSources[0].codec.clipboardText(reference.ref) !== '@[1 条注释](dsh-chat-control:' + JSON.parse(reference.ref).id + ')') {
  throw new Error('Reference clipboard projection is not stable')
}

// A native chip is one character in DSH's detect projection but expands to a
// longer clipboard token in `input.draft`.  A second quote must therefore use
// the logical detect offset, otherwise the host rejects the span and a legacy
// bridge can leak the clipboard token into the user message.
const firstClipboard = registeredSources[0].codec.clipboardText(reference.ref)
fakeInputSnapshot = {
  draft: `已有草稿 ${firstClipboard}`,
  draftRev: 8,
  occurrences: [{ offset: 5, length: firstClipboard.length }]
}
const secondQuoteView = quoteRegistration.component({
  ...quoteProps,
  messageId: 'desktop-answer-1',
  useChat: (select) => select(desktopChatSnapshot),
  useInput: (select) => select({ draft: '' }),
  inputActions: { setDraft: () => {} },
  openSideChat: (...args) => sideCalls.push(args)
})
secondQuoteView.args[2].args[1].onClick({})
const secondInserted = insertedReferences.at(-1)
if (secondInserted?.span?.start !== 6 || secondInserted?.span?.end !== 6 || secondInserted?.span?.draftRev !== 8) {
  throw new Error(`Reference insertion did not fold clipboard offsets to the native detect projection: ${JSON.stringify(secondInserted)}`)
}

const tailQuoteView = quoteRegistration.component({
  ...quoteProps,
  messageId: 'desktop-tail-answer-1',
  useChat: (select) => select(desktopTurnTailSnapshot),
  useInput: (select) => select({ draft: '' }),
  inputActions: { setDraft: () => {} },
  openSideChat: (...args) => sideCalls.push(args)
})
if (tailQuoteView === null) throw new Error('Assistant action cannot read the current TurnTail snapshot')

let nativeDraft = '修改后的消息'
let nativeSubmitCalls = 0
const nativeKeyboard = {
  submit: (...args) => {
    nativeSubmitCalls += 1
    sourcePrompts.push([{ type: 'text', text: nativeDraft.trim() }])
    return args.length
  }
}
const nativeInputActions = {
  setDraft: (text) => { nativeDraft = text },
  // New DSH builds expose inputActions.submit as a thin delegate to the
  // keyboard face.  Keep that relationship in the fixture so a regression
  // cannot silently swallow the delegated native submit.
  submit: (...args) => nativeKeyboard.submit(...args)
}
const revisionProps = revisionRegistration.config.inject('desktop-session-1')
let normalizedLegacyDraft = ''
let legacySubmitted = ''
const legacyInputActions = {
  setDraft: (text) => { normalizedLegacyDraft = text },
  submit: () => { legacySubmitted = normalizedLegacyDraft }
}
fakeInputSnapshot = { draft: firstClipboard, draftRev: 9, occurrences: [] }
revisionRegistration.component({
  ...revisionProps,
  useChat: (select) => select(desktopChatSnapshot),
  useInput: (select) => select(fakeInputSnapshot),
  inputActions: legacyInputActions
})
legacyInputActions.submit()
if (!legacySubmitted.includes('【引用开始】') || legacySubmitted.includes('dsh-chat-control:')) {
  throw new Error(`Persisted reference token was sent as raw text instead of serialized context: ${JSON.stringify(legacySubmitted)}`)
}

revisionProps.revisionStore.request({
  sessionId: 'desktop-session-1',
  key: 'prompt',
  text: '请把答案改短一些'
})
const revisionView = revisionRegistration.component({
  ...revisionProps,
  useChat: (select) => select(desktopChatSnapshot),
  useInput: (select) => select({ draft: nativeDraft }),
  inputActions: nativeInputActions,
  keyboard: nativeKeyboard
})
if (revisionView !== null) throw new Error('Revision dock must not render a standalone edit card')
if (nativeDraft !== '请把答案改短一些') throw new Error('Edit request did not seed the native composer draft')
nativeDraft = '修改后的消息'
nativeInputActions.submit()
await new Promise((resolve) => setTimeout(resolve, 0))
if (editRequests[0]?.url !== '/dsh-harness-chat-control/session-edit'
  || editRequests[0]?.payload?.sessionId !== 'desktop-session-1'
  || editRequests[0]?.payload?.startSeq !== 50
  || editRequests[0]?.payload?.targetText !== '请把答案改短一些') {
  throw new Error(`In-place edit was not armed for the original message: ${JSON.stringify(editRequests)}`)
}
if (nativeSubmitCalls !== 1) throw new Error('Edited draft did not invoke the native composer submit action')
if (sourcePrompts[0]?.[0]?.text !== '修改后的消息') throw new Error('Edited draft was not sent through the original session')
if (nativeDraft !== '修改后的消息') throw new Error('Revision dock cleared the native draft before DSH accepted the send')
if (revisionProps.revisionStore.getSnapshot().pending !== null) throw new Error('Revision state was not cleared after replacement send')

const shellProps = shellRegistration.config.inject()
const selectionStore = shellProps.selectionStore
const shellRevisionBeforeRequest = shellProps.revisionStore?.getSnapshot?.().revision
if (shellProps.revisionStore.request({ sessionId: 'desktop-session-1', key: 'prompt', text: '待修改消息' }) === null) {
  throw new Error('ChatGPT-style edit request was rejected')
}
if (shellProps.revisionStore.getSnapshot().revision !== shellRevisionBeforeRequest + 1 || shellProps.revisionStore.getSnapshot().pending?.text !== '待修改消息') {
  throw new Error('ChatGPT-style edit request did not publish a pending native-composer edit')
}
const referenceCalls = []
selectionStore.show({
  text: '选中的回答片段',
  sessionId: 'desktop-session-1',
  rect: { left: 240, top: 80, width: 100, height: 20, right: 290, bottom: 100 },
  placement: 'above'
})
const shellView = shellRegistration.component({
  ...shellProps,
  insertReference: (...args) => referenceCalls.push(args),
  openSideChat: (...args) => sideCalls.push(args),
  useSessions: (select) => select({ current: 'desktop-session-1' })
})
const shellChildren = shellView?.args?.slice(2) || []
const selectionChild = shellChildren.find((child) => child?.args?.[0]?.name === 'SelectionToolbar')
if (selectionChild === undefined) throw new Error('Selection toolbar is not mounted in shell overlay')
if (!shellChildren.some((child) => child?.args?.[0]?.name === 'UserEditOverlay')) {
  throw new Error('ChatGPT-style user edit overlay is not mounted in shell overlay')
}
const selectionView = selectionChild.args[0](selectionChild.args[1])
const toolbar = selectionView?.args?.[2]
const buttons = toolbar?.args?.slice(2) || []
if (buttons.length !== 3) throw new Error('Selection toolbar must expose three actions')
buttons[0].args[1].onClick({})
if (referenceCalls.length !== 1 || referenceCalls[0][0] !== 'desktop-session-1' || referenceCalls[0][1] !== '选中的回答片段') {
  throw new Error('Selection toolbar did not request an atomic reference insertion')
}

selectionStore.show({
  text: '需要解释的片段',
  sessionId: 'desktop-session-1',
  rect: { left: 240, top: 80, width: 100, height: 20, right: 290, bottom: 100 },
  placement: 'above'
})
const detailView = selectionChild.args[0](selectionChild.args[1])
const detailButtons = detailView.args[2].args.slice(2)
detailButtons[1].args[1].onClick({})
if (sideCalls.at(-1)?.[0] !== 'desktop-session-1' || sideCalls.at(-1)?.[1] !== '需要解释的片段' || sideCalls.at(-1)?.[2] !== '') {
  throw new Error('The details action did not open native sidechat with an empty editable question')
}

selectionStore.show({
  text: '需要带入侧边聊天的片段',
  sessionId: 'desktop-session-1',
  rect: { left: 240, top: 80, width: 100, height: 20, right: 290, bottom: 100 },
  placement: 'above'
})
const sideView = selectionChild.args[0](selectionChild.args[1])
const sideButtons = sideView.args[2].args.slice(2)
sideButtons[2].args[1].onClick({})
if (sideCalls.at(-1)?.[0] !== 'desktop-session-1' || sideCalls.at(-1)?.[1] !== '需要带入侧边聊天的片段' || sideCalls.at(-1)?.[2] !== '') {
  throw new Error('The side-chat action did not carry the selected text with an empty editable question')
}

console.log('dsh-harness-chat-control: static and loader validation passed')
