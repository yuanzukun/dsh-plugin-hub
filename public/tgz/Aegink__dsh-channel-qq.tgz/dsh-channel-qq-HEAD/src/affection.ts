/** Affection system: durable score state + master-only floating window.
 *
 * The model books every change through the qq_set_affection tool; the state
 * lives in <dshHome>/affection.json and is served as a live dashboard on
 * 127.0.0.1:<port> (loopback-only, token-gated) for 学弟's floating window.
 */

import { readFileSync } from 'node:fs'
import * as fsp from 'node:fs/promises'
import * as http from 'node:http'
import * as path from 'node:path'
import { randomUUID } from 'node:crypto'
import { atomicWriteFile } from './adapters/fs-store/atomic.js'
import { JsonStore } from './adapters/fs-store/json-store.js'

export interface AffectionEvent {
  time: number
  delta: number
  reason: string
}

export interface StageChange {
  time: number
  from: string
  to: string
  event: string
}

export interface AffectionState {
  /** Dynamic 0-100; rises and falls with interactions. */
  score: number
  /** Fixed-ladder stage; only ascends via special events she confirms. */
  stage: string
  events: AffectionEvent[]
  stageHistory: StageChange[]
}

/** Stages are HERS: she defines the ladder from her own memory via qq_set_stage.
 * The system only records what she declares — ascents, descents, renames, all real. */

export class AffectionStore {
  private state: AffectionState = { score: 87, stage: '道侣未遂', events: [], stageHistory: [] }
  private readonly file: string
  private readonly store: JsonStore<unknown>
  private readonly token = randomUUID().replace(/-/g, '')
  private workspacePath: string | null = null
  private onSubmit: ((prompt: string) => void) | null = null
  /** The dashboard's live listener (kept so `relisten` can release it). */
  private server: http.Server | null = null

  constructor(dshHome: string, private readonly log: (line: string) => void) {
    this.file = path.join(dshHome, 'affection.json')
    this.store = new JsonStore<unknown>(this.file, { log })
  }

  /** Wire the master-only task injection and the workspace the diaries live in. */
  configure(opts: { workspacePath?: string | null; onSubmit?: (prompt: string) => void }): void {
    if (opts.workspacePath !== undefined) this.workspacePath = opts.workspacePath
    if (opts.onSubmit !== undefined) this.onSubmit = opts.onSubmit
  }

  async load(): Promise<void> {
    const raw = await this.store.load(null) as AffectionState | null
    if (raw === null) { await this.save(); return }
    if (typeof raw.score === 'number') {
      this.state = {
        score: raw.score,
        stage: typeof raw.stage === 'string' ? raw.stage : '道侣未遂',
        events: Array.isArray(raw.events) ? raw.events.slice(-100) : [],
        stageHistory: Array.isArray(raw.stageHistory) ? raw.stageHistory : [],
      }
    }
  }

  async save(): Promise<void> {
    await this.store.save(this.state).catch(() => {})
  }

  /** Book one score change (rises AND falls); stage is never touched here. */
  async book(delta: number, reason: string): Promise<AffectionState> {
    // NaN 会一路穿透 clamp（Math.min(30, NaN) 还是 NaN），把 score 写成 NaN；
    // JSON.stringify 再把它变成 null，重启后 `typeof score === 'number'` 不成立，
    // **整份状态（分数 + 全部事件史）被丢弃**（2026-10-19 排查）。入口直接拒绝。
    if (!Number.isFinite(delta)) throw new Error(`好感度变化必须是数字（收到 ${String(delta)}）`)
    const clamped = Math.max(-30, Math.min(30, delta))
    this.state.score = Math.max(0, Math.min(100, this.state.score + clamped))
    this.state.events.push({ time: Date.now(), delta: clamped, reason: reason.slice(0, 120) })
    if (this.state.events.length > 100) this.state.events = this.state.events.slice(-100)
    await this.save()
    this.log(`affection ${clamped >= 0 ? '+' : ''}${clamped} → ${this.state.score} (stage ${this.state.stage}) | ${reason}`)
    return this.state
  }

  /** Set the stage to whatever she declares — from her memory, her truth.
   * Ascents, descents, renames: all recorded honestly in stageHistory. */
  async setStage(stage: string, event: string): Promise<{ ok: boolean; note: string; state: AffectionState }> {
    const target = stage.trim()
    if (target === '') return { ok: false, note: '阶段名为空', state: this.state }
    const from = this.state.stage
    if (target === from) return { ok: false, note: `阶段已是"${from}"`, state: this.state }
    this.state.stage = target
    this.state.stageHistory.push({ time: Date.now(), from, to: target, event: event.slice(0, 300) })
    if (this.state.stageHistory.length > 50) this.state.stageHistory = this.state.stageHistory.slice(-50)
    await this.save()
    this.log(`STAGE: ${from} → ${target} | ${event}`)
    return { ok: true, note: `${from} → ${target}`, state: this.state }
  }

  /** Read-only view of the current state (admin panel / diagnostics). */
  read(): AffectionState {
    return this.state
  }

  /** Diary list or one diary file from workspace memory/. */
  private async serveDiary(params: URLSearchParams, res: http.ServerResponse): Promise<void> {
    const date = params.get('date')
    const dir = this.workspacePath !== null ? path.join(this.workspacePath, 'memory') : null
    if (dir === null) { res.writeHead(503).end(JSON.stringify({ error: 'workspace not configured' })); return }
    try {
      if (date !== null) {
        const safe = date.replace(/[^0-9-]/g, '')
        const content = await fsp.readFile(path.join(dir, `${safe}.md`), 'utf-8')
        res.writeHead(200, { 'content-type': 'application/json; charset=utf-8' })
        res.end(JSON.stringify({ date: safe, content }))
        return
      }
      const names: Array<{ date: string; mtime: number }> = []
      for (const f of await fsp.readdir(dir)) {
        if (!f.endsWith('.md') || !/^\d{4}-\d{2}-\d{2}/.test(f)) continue
        const st = await fsp.stat(path.join(dir, f))
        names.push({ date: f.slice(0, 10), mtime: st.mtimeMs })
      }
      names.sort((a, b) => b.date.localeCompare(a.date))
      res.writeHead(200, { 'content-type': 'application/json; charset=utf-8' })
      res.end(JSON.stringify({ diaries: names.slice(0, 60) }))
    } catch (error) {
      res.writeHead(500).end(JSON.stringify({ error: String(error).slice(0, 120) }))
    }
  }

  /** Trace: the outbound message log (what she sent, what it quoted). */
  private async serveTrace(params: URLSearchParams, res: http.ServerResponse): Promise<void> {
    const sentFile = path.dirname(this.file)
    try {
      const out: Record<string, unknown> = {}
      const names = await fsp.readdir(sentFile).catch(() => [] as string[])
      for (const n of names) {
        if (!n.startsWith('sent-') || !n.endsWith('.json')) continue
        // 单个坏文件（写了一半、被手工改坏）只跳过它自己：一个房间的日志坏了
        // 不该让整块「最近发过什么」都打不开（2026-10-19 排查）。
        try {
          const entries = JSON.parse(await fsp.readFile(path.join(sentFile, n), 'utf-8')) as unknown[]
          out[n.replace('sent-', '').replace('.json', '')] = entries.slice(-30)
        } catch (error) {
          this.log(`trace: 跳过坏文件 ${n}：${error instanceof Error ? error.message : String(error)}`)
        }
      }
      res.writeHead(200, { 'content-type': 'application/json; charset=utf-8' })
      res.end(JSON.stringify(out))
    } catch (error) {
      res.writeHead(500).end(JSON.stringify({ error: String(error).slice(0, 120) }))
    }
  }

  get customHtmlPath(): string {
    return path.join(path.dirname(this.file), 'affection-dashboard.html')
  }

  async writeCustomHtml(html: string): Promise<void> {
    await atomicWriteFile(this.customHtmlPath, html)
    this.log(`dashboard HTML updated by 诺诺 (${html.length} bytes)`)
  }

  get tokenValue(): string {
    return this.token
  }

  /** Master-only floating dashboard on loopback. */
  async serve(port: number, opts: { workspacePath?: string | null; onSubmit?: (prompt: string) => void } = {}): Promise<void> {
    this.configure(opts)
    const server = http.createServer((req, res) => {
      const url = new URL(req.url ?? '/', 'http://127.0.0.1')
      if (url.pathname === '/api/affection') {
        if (url.searchParams.get('key') !== this.token) {
          res.writeHead(403).end('forbidden')
          return
        }
        res.writeHead(200, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' })
        res.end(JSON.stringify({ ...this.state, stageHistory: this.state.stageHistory.slice(-10), token: this.token }))
        return
      }
      if (url.pathname === '/api/task') {
        if (url.searchParams.get('key') !== this.token) { res.writeHead(403).end('forbidden'); return }
        const prompt = url.searchParams.get('prompt') ?? ''
        if (prompt.trim() === '' || this.onSubmit === null) { res.writeHead(400).end('no prompt or no submitter'); return }
        this.onSubmit(prompt)
        res.writeHead(200, { 'content-type': 'application/json; charset=utf-8' })
        res.end(JSON.stringify({ ok: true, submitted: prompt.slice(0, 80) }))
        return
      }
      if (url.pathname === '/api/diary') {
        if (url.searchParams.get('key') !== this.token) { res.writeHead(403).end('forbidden'); return }
        void this.serveDiary(url.searchParams, res)
        return
      }
      if (url.pathname === '/api/trace') {
        if (url.searchParams.get('key') !== this.token) { res.writeHead(403).end('forbidden'); return }
        void this.serveTrace(url.searchParams, res)
        return
      }
      if (url.pathname !== '/' && url.pathname !== '/affection') {
        res.writeHead(404).end()
        return
      }
      // The page itself embeds the token so it can poll its own API.
      res.writeHead(200, { 'content-type': 'text/html; charset=utf-8' })
      // She owns the dashboard: serve her custom HTML when she wrote one,
      // with a live-refresh heartbeat appended (data-change-triggered reload).
      let custom: string | null = null
      try {
        custom = readFileSync(this.customHtmlPath, 'utf-8')
      } catch {}
      if (custom !== null) {
        if (!custom.includes('autorefresh-shim')) {
          custom = custom.replace(/<\/body>/i, `${REFRESH_SHIM}
</body>`)
        }
        res.end(custom)
      } else {
        res.end(renderPage(this.token))
      }
    })
    await new Promise<void>((resolve, reject) => {
      server.once('error', reject)
      server.listen(port, '127.0.0.1', () => {
        server.off('error', reject)
        resolve()
      })
    })
    this.server = server
    this.log(`affection dashboard: http://127.0.0.1:${port}/?key=${this.token} (学弟专属悬浮窗)`)
  }

  /**
   * Apply a new `affectionPort` to the live process.
   *
   * Same fail-safe shape as the admin panel: a same-port rebind must release
   * the socket first, so the listener is rebuilt rather than reused.
   */
  async relisten(port: number): Promise<string> {
    const previous = this.server
    this.server = null
    previous?.close()
    if (!Number.isFinite(port) || port <= 0) return '好感度悬浮窗已关闭'
    await this.serve(port)
    return `好感度悬浮窗已改到 127.0.0.1:${port}`
  }
}

const REFRESH_SHIM = `<script id="autorefresh-shim">
(function(){
  const KEY = new URLSearchParams(location.search).get('key') || '';
  let fp = '';
  async function check() {
    try {
      const a = await fetch('/api/affection?key=' + KEY, { cache: 'no-store' }).then(r => r.json()).catch(() => null);
      if (!a) return;
      const last = (a.events && a.events.length) ? a.events[a.events.length - 1].time + ':' + a.events[a.events.length - 1].delta : '';
      let dfp = '';
      try {
        const d = await fetch('/api/diary?key=' + KEY, { cache: 'no-store' }).then(r => r.json());
        if (d && d.diaries) dfp = d.diaries.length + ':' + (d.diaries[0] ? d.diaries[0].mtime : '');
      } catch {}
      const next = [a.score, a.stage, a.events ? a.events.length : 0, last, dfp].join('|');
      if (fp !== '' && next !== fp) { location.reload(); return; }
      fp = next;
    } catch {}
  }
  setInterval(check, 5000);
})();
</script>`

function renderPage(token: string): string {
  return `<!doctype html>
<html lang="zh">
<head>
<meta charset="utf-8">
<title>诺诺好感度</title>
<style>
  body { margin:0; background:#12101a; color:#f4e9ff; font-family:"Microsoft YaHei",sans-serif;
         overflow:hidden; user-select:none; }
  .wrap { padding:14px 16px; }
  .top { display:flex; align-items:baseline; gap:8px; }
  .name { font-size:15px; color:#ff9ecf; }
  .score { font-size:44px; font-weight:700; color:#ffd3ea; text-shadow:0 0 18px #ff5fb0aa; }
  .stage { font-size:13px; color:#b9a6d9; margin-top:2px; }
  .bar { height:10px; background:#2a2338; border-radius:6px; margin:10px 0 4px; overflow:hidden; }
  .fill { height:100%; border-radius:6px; transition:width .6s ease;
          background:linear-gradient(90deg,#ff5fb0,#b96bff); }
  .pct { font-size:11px; color:#8f7fae; text-align:right; }
  .log { margin-top:10px; max-height:200px; overflow-y:auto; font-size:12px; line-height:1.5; }
  .ev { padding:3px 0; border-bottom:1px dashed #2a2338; }
  .delta-pos { color:#7dffa8; } .delta-neg { color:#ff7d7d; }
  .t { color:#8f7fae; font-size:10px; margin-right:6px; }
  .reason { color:#d9cdea; }
</style>
</head>
<body>
<div class="wrap">
  <div class="top"><span class="name">诺诺 → 学弟</span><span class="score" id="score">--</span></div>
  <div class="stage" id="stage">…</div>
  <div class="bar"><div class="fill" id="fill" style="width:0%"></div></div>
  <div class="pct" id="pct"></div>
  <div class="log" id="log"></div>
</div>
<script>
const KEY = '${token}'
async function tick() {
  try {
    const r = await fetch('/api/affection?key=' + KEY, { cache: 'no-store' })
    if (!r.ok) return
    const d = await r.json()
    document.getElementById('score').textContent = d.score
    document.getElementById('stage').textContent = d.stage
    document.getElementById('fill').style.width = d.score + '%'
    document.getElementById('pct').textContent = d.score + ' / 100'
    document.getElementById('log').innerHTML = (d.events || []).slice(-30).reverse().map(e => {
      const t = new Date(e.time).toLocaleString('zh', { month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit' })
      const cls = e.delta >= 0 ? 'delta-pos' : 'delta-neg'
      const sign = e.delta >= 0 ? '+' : ''
      return '<div class="ev"><span class="t">' + t + '</span><span class="' + cls + '">' + sign + e.delta + '</span> <span class="reason">' + e.reason + '</span></div>'
    }).join('')
  } catch {}
}
tick()
setInterval(tick, 5000)
</script>
</body>
</html>`
}
