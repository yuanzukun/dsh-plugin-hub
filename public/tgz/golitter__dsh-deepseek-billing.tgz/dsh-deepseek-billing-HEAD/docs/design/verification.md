# 验证

> 对应原设计文档 §10。

## 10. 验证

### 静态检查

```bash
node --check lib/index.js
node --check lib/client.js
node -e "JSON.parse(require('fs').readFileSync('package.json'))"
node --test
npm run test:coverage
npm pack --dry-run
```

### 自动测试

```bash
npm test
# 或直接运行底层命令
node --test
```

测试使用 Node.js 内置 `node:test`，不依赖真实 DSH、真实 DeepSeek 服务或真实 API Key：

- `test/index.test.js`：宿主端用例覆盖凭据处理、五个固定错误码、上游响应阶段超时、卸载时取消活跃上游请求并阻止迟到凭据触发 fetch、提前拒绝时中止未读响应体、网络/HTTP 错误、非法响应、字段白名单与长度上限、64 KiB 响应体上限、空余额、Connection Fetch route 的 GET/405/429、Cookie 摘要分桶、并发合并、`redirect: 'manual'`、endpoint 校验、日志脱敏、`/deepseek-billing` 命令本地化与执行校验边界。配置用例直接调用 `apply()`，尚未覆盖 `Config` 与执行校验的一致性。认证前的 `401`/`403` 由 DSH Connection 集成验收，不在绕过 Connection 的单元夹具中伪造。
- `test/client.test.js`：4 个可独立定位的客户端契约用例，通过真实模块工厂验证模块 ID、`require('react')`、服务注入、词典命名空间、zh/en 键集、动态侧栏标签、命令行插槽，以及 `/deepseek-billing` 回执的可见空白会话限定、成功/错误提示、会话激活清除、60 秒到期、切换清除、后台引用与导航后过期回执丢弃、命令独占过渡帧和空白阶段历史命令隐藏。夹具的会话目录不提供旧 `current` 字段，通过 `retainInfo().retainedBy.mainView` 表达可见性；独立验证卸载时清理提示、两类订阅与定时器。
- `test/client-render.test.js`：9 个余额页行为用例，以轻量 React hook harness 执行真实 `BillingSection`，分别验证加载/取消/合法成功响应和 ARIA、最大长度币种与金额的完整显示、空余额与畸形响应、未知服务端错误码统一回退、刷新失败保留最近成功余额及即时翻译、响应头及正文阶段的客户端超时、宿主超时配置变大时不被旧值截断、正文迟到时不覆盖新余额或更新已卸载组件、首次失败与卸载取消。布局是否溢出由真实浏览器检查。
- `test/package.test.js`：发布元数据契约用例，验证 `0.3.1` 版本、Node.js 基线、DSH peer 范围、Connection 宿主依赖、schemastery、可选 settings peer、客户端新模块注入、入口/patch 标识、`repository`/`homepage`/`bugs` 及发布文件边界；另用 `semver.satisfies()` 验证两条受支持发布线的实际预发布版本匹配，并拒绝旧线、过早的 `0.2.1` 候选版和未经核对的 `0.2.2` / `0.3.0`。

轻量 hook harness 能验证组件状态和请求生命周期，但不包含真实 React DOM、浏览器 CSS/布局与 DSH 完整装配。因此明暗主题、窄屏布局、焦点与 ARIA 的最终呈现，以及真实宿主中的 session/input 协作仍由下方手动清单验证；项目接入浏览器 CI 后再考虑加入完整渲染级测试。

### 代码质量审查发现的测试盲点

2026-11-04 的 [代码质量审查](code-review-2026-11-04.md) 通过隔离复现确认以下四项问题，均待处理。现有用例通过不表示这些问题已修复。

| 问题 | 现有覆盖的边界 | 修复时应补充的验证 |
|---|---|---|
| R1（P2）凭据等待不结束 | 卸载后让凭据返回，再验证不发起 fetch；未覆盖凭据一直不返回 | 等待有确定期限，卸载能结束当前调用，旧引用不能复用永久 pending promise |
| R2（P3）配置校验不一致 | 直接运行 `apply()`，接受 `0.5`；真实 `Config` 拒绝该值 | 对同一组边界输入，配置声明、执行校验和文档结果一致 |
| R3（P3）语言订阅盲点 | 手动重新渲染后检查翻译；模拟忽略 `subscribe` | locale 事件驱动渲染，删除组件订阅时测试失败，卸载后退订 |
| R4（P3）夹具失败污染全局 | 仅成功创建夹具后才有调用方 cleanup | 导入、工厂、`apply()` 失败后仍恢复全局对象，后续夹具可正常创建 |

R3 的隔离变异验证中，删除实际语言订阅后 9 个余额页用例仍全部通过。因此即时切换目前仍依赖真实浏览器验收提供行为证据。R1 的逻辑取消、R4 的初始化回滚及上述新增断言尚未实施；详细复现和验收条件以审查记录为准。

### CI 与覆盖率基线

`.github/workflows/ci.yml` 将 Node.js `22.19.x` / `24.x` 与 DSH `0.2.0-rc.2` / `0.2.1-rc.5` 交叉为四组任务。每组从清单发现全部 DSH peer，以精确版本统一安装（包括可选 settings），并核验安装结果，随后运行 `npm test`、`npm run test:coverage`、两个入口语法检查、`package.json` 解析和 `npm pack --dry-run`。版本选择仅用于该任务的 `node_modules`，不改写 `package.json` 或生成 lockfile。覆盖率只用于观察趋势，当前不设置阻断阈值；测试过程不读取真实 DSH home、API Key 或 DeepSeek 服务。

这四组任务验证依赖安装及模拟环境中的测试结果，未自动执行 DSH 完整装配或真实 React 渲染，也未覆盖上表全部边界。真实装配的已验证范围见 [适配记录](upgrade-dsh-0.2.1-rc.5.md)。

### 浏览器与 DSH 装配自动化决策

本轮阶段 D 的可行性结论是：仓库没有锁定的浏览器测试依赖、浏览器运行时或本地 `dsh` 命令，且项目没有构建链和 lockfile。将 Playwright 与 DSH CLI 直接加入 PR 必跑流程会引入较大的浏览器缓存、网络下载、版本耦合和维护成本；当前采用“Node.js CI 必跑 + 隔离临时 home 的发布前真实装配手动检查”。轻量 harness 只证明模块和状态契约，不冒充真实 DOM/DSH 装配证明。未来若 DSH 提供稳定的测试装配入口，再把下方清单迁移为定时或发布任务，仍须使用临时 home、受控 loopback mock 和虚假凭据。

### DSH 0.2.1-rc.5 真实装配

使用隔离的 DSH home 和 `web` profile，确保验证不会修改日常 profile：

```bash
DSH_BILLING_CHECK_HOME="$(mktemp -d)"
DSH_HOME="$DSH_BILLING_CHECK_HOME" npx --yes @deepseek-ai/dsh@0.2.1-rc.5 plugin --profile web add "link:$PWD"
DSH_HOME="$DSH_BILLING_CHECK_HOME" npx --yes @deepseek-ai/dsh@0.2.1-rc.5 --profile web --no-open
```

确认实际 DSH 版本符合 peer 声明，启动日志没有 client module、missing service 或 pending fiber 错误，并检查“设置 → 计费 / Billing”、versioned credentials、余额状态、刷新取消、zh/en 切换、主题/窄屏布局和 `/deepseek-billing` 命令生命周期。通过 LAN/远程 authority 打开 Web UI 时，Connection 按配置决定信任与认证；未认证请求应为 `401`，不可信 authority 应为 `403`，认证后的请求才进入插件 handler。验证使用专用测试凭据或受控 loopback mock，不使用真实生产账户。结束后只清理本次 `mktemp` 创建且已核实的临时目录。

DSH profile 默认关闭 `autoInstallPeers`，宿主提供的包不一定出现在 profile 自身的依赖清单中，因此 pnpm 安装插件时可能报告 missing peers。应结合启动器版本、实际服务装配和上述精确版本测试确认这些依赖由宿主提供；真正的版本冲突或服务缺失仍需修复。

旧基线回归时，将上述两个命令的 DSH 版本都替换为 `0.2.0-rc.2`，并重新创建隔离 home。升级本地开发依赖前，如现有 `node_modules` 仍混有旧发布线，应先备份或移走该生成目录，再统一安装目标版本；不要用 `--force` 或 `--legacy-peer-deps` 隐藏版本冲突。

### 手动检查清单

- 正常余额：显示可用 / 充值 / 赠送余额与「最后更新」时间。
- 缺失凭据：显示「未配置 DeepSeek API 密钥」（zh）/ 对应英文（en），而非原始异常。
- 刷新：点击刷新，旧结果保留、按钮进入「刷新中…」；连续刷新或离开页面后，旧请求不得覆盖新状态。
- 刷新失败：已有余额时保留余额和最后更新时间，显示非阻塞的本地化提示；首次失败仍显示完整错误态；下一次成功后提示消失并更新时间。
- 中英文切换：导航、标题、按钮、加载/错误态、时间格式即时切换，无需刷新。
- 明暗主题：颜色跟随 `currentColor` 自动适配。
- 窄屏（≤620px）：header 与 breakdown 纵向布局正常。在 390px 视口、设置侧栏仍可见时，币种和金额可换行，计费区无横向溢出；另用 16 字符币种和 128 字符金额检查完整数值可读。
- 无障碍：section 的标题关联、加载/刷新期间 `aria-busy`、成功/空态/刷新提示的单一 polite live region、首次错误的 `role="alert"`、刷新按钮的键盘焦点与禁用语义均正确。
- 斜杠命令：`/deepseek-billing` 在宿主持久化语言为 zh/en 时使用对应菜单说明、主标签、空态和错误文案；切换语言后菜单说明无需重启即可更新；无可用偏好或设置读取失败时使用英文菜单说明及语言中性文本/稳定错误码。
- 空白会话命令：在全新空白会话中执行 `/deepseek-billing`，Hero 应保持不变，余额/错误显示在输入框旁的临时提示中，且只有一次上游查询；发送普通消息激活会话时提示应立即消失，空白阶段的命令历史卡不得出现；静置 60 秒后提示也应自动消失，切换到其他会话再返回新建会话时不得重新出现。已激活后执行 `/deepseek-billing` 时结果行仍应正常显示。
- 命令参数：输入 `/deepseek-billing` 并确认后正常查询；输入提示为对应语言的“无需参数”。附加任意非空参数时仍由宿主返回本地化用法错误，且不发起余额请求或转入模型对话。

### 验证约定

Web profile 挂载了客户端 HMR，会轮询当前已加载包的 `lib/client.js`；只有当该文件就是正在编辑的文件（例如本地链接安装）时，修改才能实时生效。GitHub 安装产生的是 profile 内副本，本仓库改动不会自动同步，需要重新安装/更新并重启 DSH Web；浏览器仍显示旧版本时再使用 `Ctrl+F5`。zh/en 键集一致性由客户端契约测试自动检查。
