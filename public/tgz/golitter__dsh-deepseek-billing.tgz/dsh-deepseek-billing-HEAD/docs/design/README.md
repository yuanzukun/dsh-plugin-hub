# dsh-deepseek-billing 设计文档

> 版本：对应 package.json `0.3.1`。适配基线为 DSH `0.2.1-rc.5`，保留 `0.2.0-rc.2` 兼容（peer 范围 `>=0.2.0-rc.0 <0.2.1-0 || >=0.2.1-rc.5 <0.2.2-0`），核对日期为 2026-11-04。本目录记录当前实现与设计取舍；运行契约以 `package.json`、`lib/index.js` 和 `lib/client.js` 为准。

本目录是设计文档的唯一入口，按主题拆分为以下文档：

| 文档 | 内容 |
|---|---|
| [overview.md](overview.md) | 概述、设计目标与非目标、整体架构与三条数据流 |
| [packaging.md](packaging.md) | 打包与分发模型：双端包声明、bundle patch、clientModules 发现、三类 inject |
| [host.md](host.md) | 宿主端设计（lib/index.js）：常量与错误码、余额服务、数据模型、HTTP 路由、斜杠命令 |
| [client.md](client.md) | 客户端设计（lib/client.js）：模块外壳、命令临时提示、命令行插槽（空白阶段命令隐藏）、状态机、请求生命周期、样式 |
| [i18n.md](i18n.md) | 国际化设计：locale 接入、词典键集、实时切换、时间格式 |
| [decisions.md](decisions.md) | 关键决策与权衡（13 条） |
| [security.md](security.md) | 安全与隐私：凭据、访问控制边界、日志脱敏 |
| [configuration-and-security.md](configuration-and-security.md) | 配置项说明、安全边界与本地代理示例 |
| [verification.md](verification.md) | 静态检查、自动测试、手动检查清单与验证约定 |
| [limitations.md](limitations.md) | 已知限制与后续方向 |
| [code-review-2026-11-04.md](code-review-2026-11-04.md) | 代码质量审查：1 项 P2、3 项 P3 的复现依据、待处理状态与验收要求 |
| [structure.md](structure.md) | 项目目录结构 |
| [upgrade-dsh-0.1.1-rc.2.md](upgrade-dsh-0.1.1-rc.2.md) | DSH `0.1.1-rc.2` 适配实施方案：依赖、凭据格式、安全文档、测试与真实装配验收 |
| [upgrade-dsh-0.1.5-rc.2.md](upgrade-dsh-0.1.5-rc.2.md) | DSH `0.1.5-rc.2` 兼容修复实施记录，以及 `0.1.6` 多 Session API 的前瞻适配边界 |
| [upgrade-dsh-0.2.0-rc.2.md](upgrade-dsh-0.2.0-rc.2.md) | DSH `0.2.x` 适配实施记录：`SettingsForms` describe() 读取、`settings/document-updated` 事件与 peer 范围平移 |
| [upgrade-dsh-0.2.1-rc.5.md](upgrade-dsh-0.2.1-rc.5.md) | DSH `0.2.1-rc.5` 适配：预发布范围、命令输入/可见性与图标、窄屏修复和版本矩阵验证 |

建议阅读顺序：`overview.md` → `packaging.md` → `host.md` → `client.md` → `i18n.md` → `decisions.md` → `security.md` → `verification.md` → `limitations.md`；配置与安全（`configuration-and-security.md`）可随时查阅。

当前审查的 R1–R4 均待处理，详见 [代码质量审查记录](code-review-2026-11-04.md)。此前适配测试与浏览器验收通过的结论，适用于实际执行过的场景。
