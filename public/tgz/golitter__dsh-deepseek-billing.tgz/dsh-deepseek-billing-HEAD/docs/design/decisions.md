# 关键决策与权衡

> 对应原设计文档 §8。安全相关决策的完整说明见 [security.md](security.md)。

## 8. 关键决策与权衡

1. **双端包而非两个包**：一个包同时声明 `dsh.bundle` 与 `dsh.client`，安装一次即完成宿主注入与客户端发现，避免用户分别安装。
2. **HTTP 路由只回错误码**：错误文案是客户端呈现层职责。若 HTTP 路由回本地化文案，英文界面会混入中文。稳定码 + 客户端翻译从根上消除该问题，代价是两端需维护一致的码表（`ERROR_CODES` ↔ `ERROR_KEY` ↔ 词典）。宿主斜杠命令没有客户端翻译层，因此直接按 Host-backed locale 返回可见文案。
3. **币种透传不做换算**：金额/币种是账户事实，任何「按语言换算」都会造成数据错误。代价是 `¥`/`$` 不按语言美化，改用 ISO 代码显示以保真。
4. **手动 `bind` + `useSyncExternalStore` 而非 slot 的 `locale:` 座位**：需要 `snapshot.active` 来按语言格式化时间，`useSyncExternalStore` 直接拿到 `active` 并驱动重渲染；slot 的 `locale:` 座位只注入 `t` 拿不到 `active`。
5. **`502` 作为统一失败态**：本地路由是上游代理，失败即「网关错误」，客户端不看具体 HTTP 状态码、只看 `code`。
6. **命令文案跟随 Host-backed locale**：`locale.preference` 存在宿主 `settings`，命令在宿主端直接读取它选择 zh/en 的发现菜单说明、主标签、空态、错误和用法提示；偏好更新时通过重新注册命令触发客户端目录刷新。`settings` 缺失、读取失败或偏好未知时回退英文菜单说明及语言中性文本/稳定错误码。命令不含「充值/赠送」明细，明细仍在设置页查看。
7. **超时覆盖完整响应**：把 `AbortController` 的生命周期延长到响应体读取、JSON 解析与校验完成之后，`clearTimeout` 只在最外层 `finally` 执行。否则服务器在返回响应头后可以无限缓慢地发送响应体，绕过「仅覆盖 fetch 阶段」的超时。
8. **受限读取 + 硬上限**：不直接 `response.json()` 不受限响应。先看 `Content-Length` 预拒绝，再流式读取并在 64 KiB 超限时中止，最后才 `JSON.parse()`；余额字段另设 16/128 字符长度上限。金额不做格式强校验，也不转 `Number`，避免精度损失。
9. **endpoint 收紧为「默认锁定官方地址」**：`allowCustomEndpoint: false`（默认）时 `endpoint` 必须等于官方 DeepSeek HTTPS 地址；设 `true` 才允许自定义（任意 `https:` 或 loopback 明文 HTTP 代理）。用户名/密码/fragment、非 `http(s):` 协议一律拒绝，`redirect: 'manual'` 保证跨域重定向不会把 `Authorization` 带到新目标。
10. **并发合并 + Cookie 摘要限流**：同一时刻多个 `getBalance()` 只共享一次上游请求；路由按 Cookie 的 SHA-256 摘要做每分钟固定窗口限流（默认 30 次），不保存原始 Cookie，超限在读取凭据之前直接返回 `429`。
11. **复用 Connection 认证边界**：余额路由使用 `ctx.connection.fetch.register()`，继承 DSH 的 Host/Origin trust fence、启动 token 和签名 Cookie 认证；不再注册精确 WebServer 路由或复制认证逻辑，认证前的 `401`/`403` 由 Connection 统一返回。
12. **空白会话使用临时命令提示**：不修改 DSH，也不把余额查询复制到客户端。插件只监听当前浏览器的 `command/executed` 回执，将自身命令文本送到当前空白会话的 composer notice；提示在会话激活、60 秒到期或离开会话时清除，导航后才返回的旧回执不再展示。DSH 仍照常持久化命令生命周期，但插件的命令行插槽隐藏首个普通内容之前的 `deepseek-billing` 节点，避免空白查询在会话激活后成批出现；已激活后执行的命令仍正常显示。
13. **客户端请求超时对齐宿主 `timeoutMs`**：宿主超时只覆盖上游段，本地连接挂起会让余额页永远停留在加载态、刷新按钮持续禁用。客户端为每个请求设置 `AbortController` 定时器，初始值为宿主上游超时上限（`HOST_MAX_TIMEOUT_MS` 镜像 `lib/index.js` 的 `MAX_TIMEOUT_MS` = 120s，跨文件契约，需同步修改）+ 5s 余量，保证首轮请求永不早于宿主超时；此后从每个通过 fence 的响应 envelope 附带的 `timeoutMs` 学习实际配置，对齐为 `timeoutMs + 5s` 并钳制在默认上限内（畸形值忽略，fence 前 `403` 不携带）。自身超时触发的 abort 呈现为稳定的 `balance_timeout` 错误态，被取代/卸载的 abort 仍静默。
