<h1 align="center">dsh-deepseek-billing</h1>

<p align="center"><a href="https://github.com/golitter/dsh-deepseek-billing/blob/main/README.md">简体中文</a> · English</p>

## Features

Adds a “Billing” page to the Web settings of [DeepSeek Harness](https://github.com/deepseek-ai/deepseek-harness), providing:

- DeepSeek API available, topped-up, and granted balance display
- Manual refresh plus loading, empty, and error states; a refresh failure keeps the last successful balance and timestamp
- Live switching between Chinese and English
- Light/dark theme and narrow-screen support; amounts wrap within narrow content areas without truncating their values
- Secure API Key access through the DSH credential store; the key is never sent to the browser
- A `/deepseek-billing` slash command for quickly checking the balance in a conversation; a new blank session stays on its current view and shows a transient notice, which is cleared when the session becomes active, after one minute, or when navigating away, and balance queries made while blank do not reappear after activation

## First Principles

This plugin solves one fundamental problem: **reliably showing the real DeepSeek account balance without exposing the API Key.**

The feature set is intentionally focused. The Host securely reads the credential and calls DeepSeek's official balance endpoint, while the Client only displays the returned balance, supports manual refresh, and presents stable error feedback. The plugin does not implement usage history, trend charts, consumption forecasts, balance alerts, automatic top-ups, or API Key management. Those features either lack a reliable data source or fall outside the core responsibility of querying the balance. Omitting them is a deliberate first-principles scope decision, rather than filling the interface with fabricated data.

## Installation and Usage

1. Install the plugin:

   ```bash
   dsh plugin --profile web add github:golitter/dsh-deepseek-billing
   ```

2. Configure the DeepSeek API Key in `$DSH_HOME/.credentials.yaml`:

   ```yaml
   version: 1

   refs:
     DEEPSEEK_API_KEY: sk-xxxxxxxxxxxxxxxx
   ```

   DSH migrates an existing legacy flat credentials document at startup; new documents should use the `version: 1` and `refs` format directly. On POSIX systems, restrict the file to the current user, for example with `chmod 600 "$DSH_HOME/.credentials.yaml"`; do not record a real key in documentation, logs, or screenshots.

3. Start DSH Web:

   ```bash
   dsh --profile web
   ```

4. Open “Settings → Billing” to view the balance. Click “Refresh” to fetch it again. An initial failure shows the full error state; after a successful load, a failed refresh keeps the old balance and shows a non-blocking notice.

   ![DeepSeek billing plugin Chinese interface](https://raw.githubusercontent.com/golitter/dsh-deepseek-billing/main/docs/image_zh.png)

   ![DeepSeek billing plugin English interface](https://raw.githubusercontent.com/golitter/dsh-deepseek-billing/main/docs/image_en.png)

5. Enter the argument-free `/deepseek-billing` command in a conversation and press Enter to confirm the query. Extra arguments return a localized usage message. In a new blank session, the result appears as a transient notice beside the input instead of entering the conversation history. The notice is cleared when the session becomes active, after one minute, or when navigating away; commands run while the session was blank do not later appear as history cards. When the Host has a saved `zh` or `en` preference, the slash-menu description, input hint, labels, empty state, errors, and usage message follow that language and update after it changes. If a remote browser only has an in-process language setting, or the Host preference is unavailable, the menu description and input hint fall back to English and results fall back to an unlabeled “currency + amount”, a fixed English usage message, or a stable error code.

   ![Querying the balance with the deepseek-billing slash command](https://raw.githubusercontent.com/golitter/dsh-deepseek-billing/main/docs/deepseek_billing_command_zh.png)

## Configuration and Security

See [Configuration and Security](https://github.com/golitter/dsh-deepseek-billing/blob/main/docs/design/configuration-and-security.md). In DSH configuration, `timeoutMs` must be a finite number from `1` through `120000` milliseconds, inclusive; fractional values are allowed. The upper limit prevents Node.js timer overflow. The Host bounds upstream requests by this value after credential resolution completes. The settings page separately limits connection waits to `125` seconds, so a stale value cannot cut requests short when the Host timeout is increased at runtime. Unknown server error codes display “Billing service is temporarily unavailable”.

The current plugin version is `0.3.1`, targeting DSH `0.2.1-rc.5` while retaining compatibility with DSH `0.2.0-rc.2`. The peer range is `>=0.2.0-rc.0 <0.2.1-0 || >=0.2.1-rc.5 <0.2.2-0`, with Node.js `^22.19.0 || >=24.0.0`. Prerelease lines must be explicitly included; an upper bound of `<0.3.0` alone does not admit newer prereleases. DSH `0.2.2` and above are not yet supported.

The balance route is registered through DSH Connection Fetch and inherits DSH Host/Origin trust checks and browser Cookie authentication; the plugin neither implements nor logs Cookies.
