<div align="center">

# dsh-token-usage

**更清晰、更美观的 DeepSeek Harness 会话界面 Token 用量条。**

[![GitHub stars](https://img.shields.io/github/stars/hashdiana/dsh-token-usage?style=flat-square&logo=github)](https://github.com/hashdiana/dsh-token-usage/stargazers)
[![License: MIT](https://img.shields.io/github/license/hashdiana/dsh-token-usage?style=flat-square&color=4EAA25)](https://github.com/hashdiana/dsh-token-usage/blob/main/LICENSE)
[![DSH Plugin](https://img.shields.io/badge/DSH%20Plugin-topic-3178C6?style=flat-square)](https://github.com/topics/dsh-plugin)

🌐 中文 · [English](README.md)

</div>

DeepSeek Harness 的 Web 界面默认只在输入框下方用一行挤在一起的纯文本展示 Token 统计。**dsh-token-usage 把它替换成**一目了然的胶囊用量条，外加一个可展开的明细面板——并且自动适配你的明暗主题。

🎯 Token 用量不该靠猜，应该一眼就读懂。

## 截图

<p align="center">
  <img src="p1.png" alt="输入框下方的 Token 用量条" height="260">
</p>
<p align="center"><em>输入框下方的 Token 用量条</em></p>

<p align="center">
  <img src="p2.png" alt="点击用量条展开的明细面板" height="340">
</p>
<p align="center"><em>点击用量条展开的明细面板</em></p>

<details>
<summary><b>目录</b></summary>

- [截图](#截图)
- [亮点](#亮点)
- [展示内容](#展示内容)
- [安装](#安装)
- [卸载 / 禁用](#卸载--禁用)
- [构建与开发](#构建与开发)
- [实现原理](#实现原理)
- [许可证](#许可证)

</details>

## 亮点

- **上下文一眼掌握** —— 细进度条随上下文占用从绿 → 黄 → 红变化。
- **输入 / 输出 / 缓存分开展示** —— 输入拆成缓存读取、缓存写入、未命中三段，命中率直接亮在条上。
- **速度就在眼前** —— 解码吞吐（`tok/s`）与平均首字延迟（TTFT）直接显示。
- **点击展开明细面板** —— 上下文占用与构成（系统提示 / 工具 / 对话）、输入构成堆叠条、会话轮次 / 步数 / 模型 / 工具耗时。
- **自然的边缘渐隐** —— 面板上下边缘在还有内容可滚时渐隐并高斯模糊，滚到顶/底自动消失。
- **主题自适应、中英双语** —— 样式只用 `--dsw-*` 主题变量（明暗皆宜），文案内置中英双语。

## 展示内容

输入框下方的用量条从左到右依次是：

| 胶囊 | 含义 |
|---|---|
| 上下文 | 已用 / 窗口 token，带按占用率变色的进度条 |
| 输入 | 计费输入总量（缓存读取 + 缓存写入 + 未命中） |
| 输出 | 服务商上报的输出 token |
| 命中率 | 缓存读取占计费输入的比例 |
| tok/s | 解码吞吐（按上报用量的步骤） |
| TTFT | 平均首字延迟 |

点击用量条展开面板：上下文占用与构成、输入分段堆叠条、吞吐 / TTFT、会话统计。没有任何数据时整行自动隐藏。

## 安装

**从 GitHub 安装（推荐）：**

```sh
npx -p @deepseek-ai/dsh dsh plugin --profile web add github:hashdiana/dsh-token-usage
```

**从本地目录安装：**

```sh
npx -p @deepseek-ai/dsh dsh plugin --profile web add <本仓库路径>
```

安装后重启目标 profile：

```sh
dsh web
```

> Git 安装路径直接使用仓库里已构建好的 `lib/`（见「构建与开发」），安装时不执行任何构建脚本。

## 卸载 / 禁用

临时禁用而无需卸载 —— 在 `$DSH_HOME/profiles/web/cordis.patch.yml` 中加入：

```yaml
- id: dsh-token-usage
  disabled: true
```

重启 `dsh web` 即恢复默认 stats 行；删除这几行即可重新启用。

## 构建与开发

```sh
pnpm install
pnpm typecheck   # tsc -b
pnpm build       # tsc -b + tsdown → lib/index.js（host）+ lib/client.js（浏览器）
pnpm test        # vitest：折叠纯函数、locale 配对、jsdom 渲染、slot 注册/销毁/重载
```

client bundle 以 `window.__ModuleLoader__.load({ id, factory })` 形式产出；CSS Modules 由 lightningcss 哈希后注入 `<style data-plugin="dsh-token-usage">` 标签。**务必提交 `lib/`** —— Git 安装使用的是构建产物，不是 `src/`。

## 实现原理

- **纯 client 插件** —— host 半只是空 `apply()`；浏览器半通过 `exports["./client"]` 下发。
- **插槽** —— 注册进 `conversation.composer.dock`（cell `id: "stats"`、`priority: -1`），遮蔽官方文本行；注册随插件 fiber 一并撤销。
- **数据** —— 读取持久投影 `tokenUsage`、`contextPressure`、`contextBreakdown`、`sessionStats`；仅在投影缺失时用窗口折叠兜底。
- **Locale** —— 自有 `tokenUsage` 命名空间，中英双语。

## 许可证

[MIT](LICENSE)
