/**
 * The token-usage dock bar: a click-to-open details panel plus a compact
 * chip row under the composer card showing context occupancy, billed
 * input/output tokens, cache-hit share, decode throughput, and first-token
 * latency. Registered into `conversation.composer.dock`, shadowing the
 * shipped plain-text stats line (cell id "stats", priority -1).
 *
 * All figures ride the durable whole-log projections (`sessionStats`,
 * `tokenUsage`, `contextPressure`, `contextBreakdown`); the window fold
 * serves only as the no-projection fallback.
 * @module dsh-token-usage/client/TokenUsageBar
 */

import { useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react'
import type { ConversationSnapshot } from '@deepseek-ai/dsh-client-runtime/client'
import type { UseProjection } from '@deepseek-ai/dsh-client-runtime/client'
import type { TranslateNS } from '@deepseek-ai/dsh-client-ui-slots'
import type { ContextBreakdownProjection } from '@deepseek-ai/dsh-token-meter/client'
import {
  billedInputTokens, cacheHitPercent, contextOccupancy, deriveStats,
  formatDuration, formatTokens, formatTokensPerSecond, tokensPerSecondOf,
  ttftAverageOf,
} from './derive.ts'
import css from './TokenUsageBar.module.css'

/** Component props: the framework standard kit subset this entry consumes. */
export interface TokenUsageBarProps {
  /** Owner-provided point-in-time conversation snapshot (InputZone share). */
  session: ConversationSnapshot
  /** The fifth framework hook seat: key-addressed projection reader. */
  useProjection: UseProjection
  /** Locale seat of the declared `tokenUsage` namespace. */
  t: TranslateNS<'tokenUsage'>
}

/** Occupancy tone by percentage: ok / warn / danger. */
function occupancyTone(percent: number): 'ok' | 'warn' | 'danger' {
  if (percent < 50) return 'ok'
  if (percent < 80) return 'warn'
  return 'danger'
}

/** Width percent for a stacked segment; clamps to keep every bucket visible. */
function segmentWidth(part: number, total: number): string {
  if (total <= 0) return '0%'
  return `${Math.max(2, Math.round((part / total) * 100))}%`
}

/**
 * Render the token-usage bar and its details panel.
 * @param props - framework props subset (see {@link TokenUsageBarProps}).
 * @returns the dock entry content, or null until any usage datum exists.
 */
export function TokenUsageBar({ session, useProjection, t }: TokenUsageBarProps) {
  const usage = useProjection('tokenUsage')
  const pressure = useProjection('contextPressure')
  const breakdown = useProjection('contextBreakdown')
  const projected = useProjection('sessionStats')

  const stats = useMemo(
    () => projected ?? deriveStats(session.chat.legacy.nodes),
    [projected, session.chat.legacy.nodes],
  )
  const occupancy = useMemo(() => contextOccupancy(pressure), [pressure])

  const inputTotal = usage === undefined ? 0 : billedInputTokens(usage)
  const hasUsage = usage !== undefined && (inputTotal > 0 || usage.outputTokens > 0)
  const hasStats = stats.steps > 0
  const tps = tokensPerSecondOf(stats)
  const ttft = ttftAverageOf(stats)
  const cacheHit = usage === undefined ? null : cacheHitPercent(usage)

  const [open, setOpen] = useState(false)
  const rootRef = useRef<HTMLDivElement>(null)
  const scrollRef = useRef<HTMLDivElement>(null)
  const [fadeTop, setFadeTop] = useState(false)
  const [fadeBottom, setFadeBottom] = useState(false)

  // Edge fades: show a top/bottom gradient only while the panel can scroll in
  // that direction. Runs after each render (content size may have changed) and
  // on every scroll; setting an unchanged boolean bails out of re-rendering.
  useLayoutEffect(() => {
    const el = scrollRef.current
    if (el === null) return
    const update = () => {
      setFadeTop(el.scrollTop > 1)
      setFadeBottom(el.scrollTop + el.clientHeight < el.scrollHeight - 1)
    }
    update()
    el.addEventListener('scroll', update, { passive: true })
    return () => { el.removeEventListener('scroll', update) }
  })

  // Close on outside pointer-down or Escape while the panel is open; the
  // listeners ride the fiber's React tree and are removed on unmount.
  useEffect(() => {
    if (!open) return
    const onPointerDown = (event: PointerEvent) => {
      if (rootRef.current !== null && !rootRef.current.contains(event.target as Node)) {
        setOpen(false)
      }
    }
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') setOpen(false)
    }
    document.addEventListener('pointerdown', onPointerDown)
    document.addEventListener('keydown', onKeyDown)
    return () => {
      document.removeEventListener('pointerdown', onPointerDown)
      document.removeEventListener('keydown', onKeyDown)
    }
  }, [open])

  const chips = []
  if (occupancy !== null) {
    chips.push(
      <span
        key="context"
        className={css.chip}
        title={`${t('panel.context')}: ${formatTokens(occupancy.usedTokens)} / ${formatTokens(occupancy.contextWindow)}`}
      >
        <span className={css.label}>{t('bar.context')}</span>
        <span className={css.contextBar} aria-hidden="true">
          <span
            className={css.contextFill}
            data-tone={occupancyTone(occupancy.percent)}
            style={{ width: `${occupancy.percent}%` }}
          />
        </span>
        <span className={css.value}>{occupancy.percent}%</span>
      </span>,
    )
  }
  if (hasUsage && inputTotal > 0) {
    const parts: string[] = []
    if (usage.cacheReadTokens > 0) parts.push(`${t('panel.cacheRead')} ${formatTokens(usage.cacheReadTokens)}`)
    if (usage.cacheWriteTokens > 0) parts.push(`${t('panel.cacheWrite')} ${formatTokens(usage.cacheWriteTokens)}`)
    if (usage.uncachedInputTokens > 0) parts.push(`${t('panel.uncached')} ${formatTokens(usage.uncachedInputTokens)}`)
    chips.push(
      <span key="input" className={css.chip} title={parts.join(' · ')}>
        <span className={`${css.swatch} ${css.swatchInput}`} aria-hidden="true" />
        <span className={css.label}>{t('bar.input')}</span>
        <span className={css.value}>{formatTokens(inputTotal)}</span>
      </span>,
    )
  }
  if (hasUsage && usage.outputTokens > 0) {
    chips.push(
      <span key="output" className={css.chip}>
        <span className={`${css.swatch} ${css.swatchOutput}`} aria-hidden="true" />
        <span className={css.label}>{t('bar.output')}</span>
        <span className={css.value}>{formatTokens(usage.outputTokens)}</span>
      </span>,
    )
  }
  if (cacheHit !== null && usage !== undefined) {
    chips.push(
      <span key="cache" className={css.chip} title={`${t('panel.cacheRead')}: ${formatTokens(usage.cacheReadTokens)}`}>
        <span className={`${css.swatch} ${css.swatchCache}`} aria-hidden="true" />
        <span className={css.value}>{t('bar.cacheHit', { percent: cacheHit })}</span>
      </span>,
    )
  }
  if (tps !== null) {
    chips.push(
      <span key="tps" className={css.chip}>
        <span className={css.value}>{t('bar.throughput', { tps: formatTokensPerSecond(tps) })}</span>
      </span>,
    )
  }
  if (ttft !== null) {
    chips.push(
      <span key="ttft" className={css.chip}>
        <span className={css.value}>{t('bar.ttft', { duration: formatDuration(ttft) })}</span>
      </span>,
    )
  }
  if (chips.length === 0) return null

  const tone = occupancy === null ? 'ok' : occupancyTone(occupancy.percent)

  return (
    <div className={css.root} ref={rootRef}>
      <button
        type="button"
        className={css.bar}
        aria-expanded={open}
        aria-label={t('aria.toggle')}
        onClick={() => { setOpen(!open) }}
      >
        {chips}
      </button>
      {open && (
        <div className={css.panel} role="region" aria-label={t('panel.title')}>
          <div className={css.panelScroll} ref={scrollRef}>
            <div className={css.panelTitle}>
              <span>{t('panel.title')}</span>
              {occupancy !== null && <span className={css.panelPercent}>{occupancy.percent}%</span>}
            </div>

          {occupancy !== null && (
            <div className={css.section}>
              <div className={css.sectionTitle}>{t('panel.context')}</div>
              <div className={css.panelBar} aria-hidden="true">
                <span
                  className={css.panelBarFill}
                  data-tone={tone}
                  style={{ width: `${occupancy.percent}%` }}
                />
              </div>
              <dl>
                <div className={css.row}>
                  <dt>{t('panel.contextUsed', { used: formatTokens(occupancy.usedTokens), window: formatTokens(occupancy.contextWindow) })}</dt>
                  <dd>{occupancy.percent}%</dd>
                </div>
              </dl>
            </div>
          )}

          {breakdown !== undefined && (breakdown.systemTokens + breakdown.toolsTokens + breakdown.messageTokens) > 0 && (
            <ContextBreakdownRows breakdown={breakdown} t={t} />
          )}

          {hasUsage && (
            <div className={css.section}>
              <div className={css.sectionTitle}>{t('panel.inputSplit')}</div>
              {inputTotal > 0 && (
                <div className={css.stack} aria-hidden="true">
                  <span className={`${css.stackSegment} ${css.stackCacheRead}`} style={{ width: segmentWidth(usage.cacheReadTokens, inputTotal) }} />
                  <span className={`${css.stackSegment} ${css.stackCacheWrite}`} style={{ width: segmentWidth(usage.cacheWriteTokens, inputTotal) }} />
                  <span className={`${css.stackSegment} ${css.stackUncached}`} style={{ width: segmentWidth(usage.uncachedInputTokens, inputTotal) }} />
                </div>
              )}
              <dl>
                {usage.cacheReadTokens > 0 && (
                  <div className={css.row}>
                    <dt><span className={`${css.legendDot} ${css.dotCacheRead}`} aria-hidden="true" />{t('panel.cacheRead')}</dt>
                    <dd>{formatTokens(usage.cacheReadTokens)}</dd>
                  </div>
                )}
                {usage.cacheWriteTokens > 0 && (
                  <div className={css.row}>
                    <dt><span className={`${css.legendDot} ${css.dotCacheWrite}`} aria-hidden="true" />{t('panel.cacheWrite')}</dt>
                    <dd>{formatTokens(usage.cacheWriteTokens)}</dd>
                  </div>
                )}
                {usage.uncachedInputTokens > 0 && (
                  <div className={css.row}>
                    <dt><span className={`${css.legendDot} ${css.dotUncached}`} aria-hidden="true" />{t('panel.uncached')}</dt>
                    <dd>{formatTokens(usage.uncachedInputTokens)}</dd>
                  </div>
                )}
                {inputTotal > 0 && (
                  <div className={css.row}>
                    <dt>{t('panel.inputTotal')}</dt>
                    <dd>{formatTokens(inputTotal)}</dd>
                  </div>
                )}
                <div className={css.row}>
                  <dt>{t('panel.output')}</dt>
                  <dd>{formatTokens(usage.outputTokens)}</dd>
                </div>
                {cacheHit !== null && (
                  <div className={css.row}>
                    <dt>{t('panel.cacheHit')}</dt>
                    <dd>{cacheHit}%</dd>
                  </div>
                )}
              </dl>
            </div>
          )}

          {(tps !== null || ttft !== null) && (
            <div className={css.section}>
              <div className={css.sectionTitle}>{t('panel.speed')}</div>
              <dl>
                {tps !== null && (
                  <div className={css.row}>
                    <dt>{t('panel.throughput')}</dt>
                    <dd>{t('bar.throughput', { tps: formatTokensPerSecond(tps) })}</dd>
                  </div>
                )}
                {ttft !== null && (
                  <div className={css.row}>
                    <dt>{t('panel.ttft')}</dt>
                    <dd>{formatDuration(ttft)}</dd>
                  </div>
                )}
              </dl>
            </div>
          )}

          {hasStats && (
            <div className={css.section}>
              <div className={css.sectionTitle}>{t('panel.session')}</div>
              <dl>
                <div className={css.row}>
                  <dt>{t('panel.turns', { turns: stats.turns })}</dt>
                  <dd>{t('panel.steps', { steps: stats.steps })}</dd>
                </div>
                {stats.llmMs > 0 && (
                  <div className={css.row}>
                    <dt>{t('panel.llmTime', { duration: formatDuration(stats.llmMs) })}</dt>
                    <dd />
                  </div>
                )}
                {stats.toolMs > 0 && (
                  <div className={css.row}>
                    <dt>{t('panel.toolTime', { duration: formatDuration(stats.toolMs) })}</dt>
                    <dd />
                  </div>
                )}
              </dl>
            </div>
          )}
          </div>
          <div className={css.fadeTop} data-visible={fadeTop || undefined} aria-hidden="true" />
          <div className={css.fadeBottom} data-visible={fadeBottom || undefined} aria-hidden="true" />
        </div>
      )}
    </div>
  )
}

/**
 * Heuristic context-composition rows (system prompt / tools / messages).
 * The figures are the meter's fixed density estimates — approximations of
 * composition, never a total (see the token-meter projection docs).
 */
function ContextBreakdownRows({ breakdown, t }: { breakdown: ContextBreakdownProjection; t: TranslateNS<'tokenUsage'> }) {
  const total = breakdown.systemTokens + breakdown.toolsTokens + breakdown.messageTokens
  return (
    <div className={css.section}>
      <div className={css.sectionTitle}>{t('panel.composition')}</div>
      <div className={css.stack} aria-hidden="true">
        <span className={`${css.stackSegment} ${css.stackSystem}`} style={{ width: segmentWidth(breakdown.systemTokens, total) }} />
        <span className={`${css.stackSegment} ${css.stackTools}`} style={{ width: segmentWidth(breakdown.toolsTokens, total) }} />
        <span className={`${css.stackSegment} ${css.stackMessages}`} style={{ width: segmentWidth(breakdown.messageTokens, total) }} />
      </div>
      <dl>
        <div className={css.row}>
          <dt><span className={`${css.legendDot} ${css.dotSystem}`} aria-hidden="true" />{t('panel.system')}</dt>
          <dd>{formatTokens(breakdown.systemTokens)}</dd>
        </div>
        <div className={css.row}>
          <dt><span className={`${css.legendDot} ${css.dotTools}`} aria-hidden="true" />{t('panel.tools')}</dt>
          <dd>{formatTokens(breakdown.toolsTokens)}</dd>
        </div>
        <div className={css.row}>
          <dt><span className={`${css.legendDot} ${css.dotMessages}`} aria-hidden="true" />{t('panel.messages')}</dt>
          <dd>{formatTokens(breakdown.messageTokens)}</dd>
        </div>
      </dl>
    </div>
  )
}
