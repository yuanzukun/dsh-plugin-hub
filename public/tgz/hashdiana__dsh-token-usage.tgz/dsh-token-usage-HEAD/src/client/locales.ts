/**
 * `tokenUsage` namespace dictionaries. The zh dictionary is the key-set
 * source of truth; `en` is checked complete against it at compile time.
 * @module dsh-token-usage/client/locales
 */

/** The dictionary namespace owned by this plugin. */
export const NS = 'tokenUsage'

/** Simplified Chinese dictionary (the key-set source of truth). */
export const zh = {
  'bar.context': '上下文',
  'bar.input': '输入',
  'bar.output': '输出',
  'bar.cacheHit': '命中率 {percent}%',
  'bar.throughput': '{tps} tok/s',
  'bar.ttft': 'TTFT {duration}',
  'panel.title': 'Token 用量明细',
  'panel.context': '上下文占用',
  'panel.contextUsed': '{used} / {window}',
  'panel.inputSplit': '输入构成',
  'panel.composition': '上下文构成',
  'panel.cacheRead': '缓存读取',
  'panel.cacheWrite': '缓存写入',
  'panel.uncached': '未命中输入',
  'panel.system': '系统提示',
  'panel.tools': '工具',
  'panel.messages': '对话',
  'panel.inputTotal': '输入总计',
  'panel.output': '输出',
  'panel.cacheHit': '缓存命中',
  'panel.throughput': '吞吐',
  'panel.ttft': '首字延迟',
  'panel.speed': '速度',
  'panel.session': '会话',
  'panel.turns': '{turns} 轮',
  'panel.steps': '{steps} 步',
  'panel.llmTime': '模型耗时 {duration}',
  'panel.toolTime': '工具耗时 {duration}',
  'aria.toggle': '展开或收起 Token 用量明细',
} as const

/** The tokenUsage namespace key union. */
export type TokenUsageKey = keyof typeof zh

declare module '@deepseek-ai/dsh-client-ui-slots' {
  interface LocaleNamespaceMap {
    /** This plugin's Token-usage copy. */
    tokenUsage: TokenUsageKey
  }
}

/** English dictionary, checked complete against the zh key set. */
export const en: Record<TokenUsageKey, string> = {
  'bar.context': 'context',
  'bar.input': 'input',
  'bar.output': 'output',
  'bar.cacheHit': 'hit rate {percent}%',
  'bar.throughput': '{tps} tok/s',
  'bar.ttft': 'TTFT {duration}',
  'panel.title': 'Token usage',
  'panel.context': 'Context',
  'panel.contextUsed': '{used} / {window}',
  'panel.inputSplit': 'Input split',
  'panel.composition': 'Context composition',
  'panel.cacheRead': 'Cache read',
  'panel.cacheWrite': 'Cache write',
  'panel.uncached': 'Uncached input',
  'panel.system': 'System',
  'panel.tools': 'Tools',
  'panel.messages': 'Messages',
  'panel.inputTotal': 'Input total',
  'panel.output': 'Output',
  'panel.cacheHit': 'Cache hit',
  'panel.throughput': 'Throughput',
  'panel.ttft': 'First token',
  'panel.speed': 'Speed',
  'panel.session': 'Session',
  'panel.turns': '{turns} turns',
  'panel.steps': '{steps} steps',
  'panel.llmTime': 'Model {duration}',
  'panel.toolTime': 'Tools {duration}',
  'aria.toggle': 'Toggle token usage details',
}
