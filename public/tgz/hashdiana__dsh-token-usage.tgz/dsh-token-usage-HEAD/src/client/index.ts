/**
 * dsh-token-usage plugin, browser half: one entry into the
 * `conversation.composer.dock` slot — the band under the composer card at the
 * bottom of the conversation — shadowing the shipped plain-text stats line
 * (cell id "stats", priority -1) with a visual token-usage bar and a
 * click-to-open details panel.
 * @module dsh-token-usage/client
 */

import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client'
// Type-only: pulls the ui-conversation SlotMap merge (the dock entry) through the Client assembly boundary.
import type {} from '@deepseek-ai/dsh-client-ui-conversation/client'
// Type-only: pulls the locale plugin's Context merge (ctx.locale).
import type {} from '@deepseek-ai/dsh-client-locale/client'
// Type-only: pulls the token-meter / session-stats SessionProjectionMap merges
// (tokenUsage, contextPressure, contextBreakdown, sessionStats keys).
import type {} from '@deepseek-ai/dsh-token-meter/client'
import type {} from '@deepseek-ai/dsh-session-stats/client'
import { NS, en, zh } from './locales.ts'
import { TokenUsageBar } from './TokenUsageBar.tsx'

/** Required services: the slot registry and the copy. */
export const inject = ['slots', 'locale']

/**
 * Client plugin body: register the token-usage dock entry once the dock slot
 * is declared.
 * @param ctx - client root context.
 */
export function apply(ctx: ClientContext): void {
  ctx.effect(() => ctx.locale.register(NS, { zh, en }), 'dsh-token-usage: dictionaries')

  // The dock slot is declared by ui-conversation; registering before the
  // declaration would throw, so wait for the inject hook. The returned
  // disposer withdraws the registration and collapses with the fiber.
  ctx.slots.inject('conversation.composer.dock', () =>
    ctx.slots.register({
      name: 'conversation.composer.dock',
      id: 'stats',
      // Shadow the shipped stats line: same cell, lower priority wins.
      priority: -1,
      locale: NS,
    }, TokenUsageBar),
  )
}
