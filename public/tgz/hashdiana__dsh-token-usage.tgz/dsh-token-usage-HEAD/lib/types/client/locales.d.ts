/**
 * `tokenUsage` namespace dictionaries. The zh dictionary is the key-set
 * source of truth; `en` is checked complete against it at compile time.
 * @module dsh-token-usage/client/locales
 */
/** The dictionary namespace owned by this plugin. */
export declare const NS = "tokenUsage";
/** Simplified Chinese dictionary (the key-set source of truth). */
export declare const zh: {
    readonly 'bar.context': "上下文";
    readonly 'bar.input': "输入";
    readonly 'bar.output': "输出";
    readonly 'bar.cacheHit': "命中率 {percent}%";
    readonly 'bar.throughput': "{tps} tok/s";
    readonly 'bar.ttft': "TTFT {duration}";
    readonly 'panel.title': "Token 用量明细";
    readonly 'panel.context': "上下文占用";
    readonly 'panel.contextUsed': "{used} / {window}";
    readonly 'panel.inputSplit': "输入构成";
    readonly 'panel.composition': "上下文构成";
    readonly 'panel.cacheRead': "缓存读取";
    readonly 'panel.cacheWrite': "缓存写入";
    readonly 'panel.uncached': "未命中输入";
    readonly 'panel.system': "系统提示";
    readonly 'panel.tools': "工具";
    readonly 'panel.messages': "对话";
    readonly 'panel.inputTotal': "输入总计";
    readonly 'panel.output': "输出";
    readonly 'panel.cacheHit': "缓存命中";
    readonly 'panel.throughput': "吞吐";
    readonly 'panel.ttft': "首字延迟";
    readonly 'panel.speed': "速度";
    readonly 'panel.session': "会话";
    readonly 'panel.turns': "{turns} 轮";
    readonly 'panel.steps': "{steps} 步";
    readonly 'panel.llmTime': "模型耗时 {duration}";
    readonly 'panel.toolTime': "工具耗时 {duration}";
    readonly 'aria.toggle': "展开或收起 Token 用量明细";
};
/** The tokenUsage namespace key union. */
export type TokenUsageKey = keyof typeof zh;
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** This plugin's Token-usage copy. */
        tokenUsage: TokenUsageKey;
    }
}
/** English dictionary, checked complete against the zh key set. */
export declare const en: Record<TokenUsageKey, string>;
//# sourceMappingURL=locales.d.ts.map