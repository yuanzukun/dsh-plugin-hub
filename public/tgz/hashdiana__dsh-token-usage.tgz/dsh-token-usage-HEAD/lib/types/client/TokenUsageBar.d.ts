/**
 * The token-usage dock bar: a click-to-open details panel plus a compact
 * chip row under the composer card showing context occupancy, billed
 * input/output tokens, cache-hit share, decode throughput, and first-token
 * latency. Registered into `conversation.composer.dock`, shadowing the
 * shipped plain-text stats line (cell id "stats", priority -1).
 *
 * All figures ride the durable whole-log projections (`sessionStats`,
 * `tokenUsage`, `contextPressure`, `contextBreakdown`); the window fold
 * serves only as the no-projection fallback.
 * @module dsh-token-usage/client/TokenUsageBar
 */
import type { ConversationSnapshot } from '@deepseek-ai/dsh-client-runtime/client';
import type { UseProjection } from '@deepseek-ai/dsh-client-runtime/client';
import type { TranslateNS } from '@deepseek-ai/dsh-client-ui-slots';
/** Component props: the framework standard kit subset this entry consumes. */
export interface TokenUsageBarProps {
    /** Owner-provided point-in-time conversation snapshot (InputZone share). */
    session: ConversationSnapshot;
    /** The fifth framework hook seat: key-addressed projection reader. */
    useProjection: UseProjection;
    /** Locale seat of the declared `tokenUsage` namespace. */
    t: TranslateNS<'tokenUsage'>;
}
/**
 * Render the token-usage bar and its details panel.
 * @param props - framework props subset (see {@link TokenUsageBarProps}).
 * @returns the dock entry content, or null until any usage datum exists.
 */
export declare function TokenUsageBar({ session, useProjection, t }: TokenUsageBarProps): import("react").JSX.Element | null;
//# sourceMappingURL=TokenUsageBar.d.ts.map