/**
 * Pure display derivation for the token-usage bar. All figures ride the
 * durable whole-log projections (`sessionStats`, `tokenUsage`,
 * `contextPressure`) because the conversation window is paged and compaction
 * rewrites it; the node fold below answers "what is on screen" only when no
 * projection value is served — its field names deliberately mirror the
 * official window fold (dsh-client-ui-conversation `deriveStats`) so the two
 * swap wholesale.
 * @module dsh-token-usage/client/derive
 */
import type { ConversationNode } from '@deepseek-ai/dsh-client-runtime/client';
import type { ContextPressureProjection, TokenUsageProjection } from '@deepseek-ai/dsh-token-meter/client';
import type { SessionStatsProjection } from '@deepseek-ai/dsh-session-stats/client';
/** Window-scoped display totals, mirroring the `sessionStats` projection shape. */
export interface WindowStats {
    turns: number;
    steps: number;
    /** Summed request wall time (step/start → assistant/message); 0 when no node carries timing. */
    llmMs: number;
    /** Summed tool wall time (tool/call → tool/result); 0 when no pair is in-window. */
    toolMs: number;
    /** Summed first-token latency over `ttftSteps`; 0 when no step records it. */
    ttftMs: number;
    /** Steps carrying a recorded TTFT. */
    ttftSteps: number;
    /** Summed decode wall time over steps that also report output tokens. */
    decodeMs: number;
    /** Summed output tokens over the same decode-timed steps. */
    decodeTokens: number;
}
/**
 * Fold assistant and tool-result nodes into window-scoped display totals —
 * the FALLBACK for assemblies without the `sessionStats` projection.
 * @param nodes - snapshot nodes.
 * @returns fallback counts and summed wall times.
 */
export declare function deriveStats(nodes: readonly ConversationNode[]): WindowStats;
/** Compact token count: 517 / 12.2K / 517K / 1.2M (one decimal under three digits). */
export declare function formatTokens(n: number): string;
/** Compact duration: 45.2s under a minute, 2m42s from there on. */
export declare function formatDuration(ms: number): string;
/** Compact decode throughput: one decimal under 10, integer from there on. */
export declare function formatTokensPerSecond(tps: number): string;
/** Sum the three disjoint prompt-side billing buckets. */
export declare function billedInputTokens(usage: TokenUsageProjection): number;
/** Cache-hit share of prompt-side input over the whole durable log. */
export declare function cacheHitPercent(usage: TokenUsageProjection): number | null;
/** Approximate context occupancy; null until both numerator and capacity are known. */
export interface ContextOccupancy {
    percent: number;
    usedTokens: number;
    contextWindow: number;
}
/**
 * Approximate context occupancy, using the same integer rounding and upper
 * clamp as the official display. The numerator is `projectedTokens` — the
 * provider sample carried forward over the surface's movement since — so
 * compaction shows immediately instead of waiting for the next request to
 * report usage; it falls back to the bare sample only for a log whose
 * projection predates that field.
 */
export declare function contextOccupancy(pressure: ContextPressureProjection | undefined): ContextOccupancy | null;
/** Whole-log stats either from the durable projection or the window fold. */
export type StatsSource = SessionStatsProjection | WindowStats;
/** Decode throughput over usage-reporting steps; null when no sampled step exists. */
export declare function tokensPerSecondOf(stats: StatsSource): number | null;
/** Mean first-token latency over steps that recorded one; null when none did. */
export declare function ttftAverageOf(stats: StatsSource): number | null;
//# sourceMappingURL=derive.d.ts.map