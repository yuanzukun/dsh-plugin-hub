/**
 * dsh-token-usage plugin, browser half: one entry into the
 * `conversation.composer.dock` slot — the band under the composer card at the
 * bottom of the conversation — shadowing the shipped plain-text stats line
 * (cell id "stats", priority -1) with a visual token-usage bar and a
 * click-to-open details panel.
 * @module dsh-token-usage/client
 */
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
/** Required services: the slot registry and the copy. */
export declare const inject: string[];
/**
 * Client plugin body: register the token-usage dock entry once the dock slot
 * is declared.
 * @param ctx - client root context.
 */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map