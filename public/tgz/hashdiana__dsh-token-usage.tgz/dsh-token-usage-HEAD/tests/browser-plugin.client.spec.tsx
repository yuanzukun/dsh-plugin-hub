// @vitest-environment jsdom
/**
 * dsh-token-usage browser half on a real cordis Context with the real
 * SlotRegistry and LocaleRuntime (evaluated through the loader contract):
 * the plugin registers the dock entry shadowing the shipped stats cell, and
 * registration rides the plugin fiber (HMR safety — dispose withdraws,
 * reload re-registers).
 */
import { Context } from '@deepseek-ai/cordis'
import { afterEach, describe, expect, it } from 'vitest'
import { cleanup } from '@testing-library/react'
import type { SlotRegistry as SlotRegistryType } from '@deepseek-ai/dsh-client-runtime/client'
import type { LocaleRuntime as LocaleRuntimeType } from '@deepseek-ai/dsh-client-locale/client'
import { apply, inject } from '../src/client/index.ts'
import { clientModule } from './loader-shim.ts'

afterEach(cleanup)

/** Boot the plugin over the real services; the dock slot is declared up front. */
async function bench() {
  const runtime = clientModule('@deepseek-ai/dsh-client-runtime')
  const locale = clientModule('@deepseek-ai/dsh-client-locale')
  const SlotRegistry = runtime.SlotRegistry as typeof SlotRegistryType
  const LocaleRuntime = locale.LocaleRuntime as typeof LocaleRuntimeType

  const ctx = new Context()
  await ctx.plugin(SlotRegistry).await()
  ctx.slots.register({
    name: 'root',
    children: { 'conversation.composer.dock': { kind: 'list', scope: 'session' } },
  } as never, (() => null) as never)
  ctx.provide('locale', new LocaleRuntime(ctx))
  const fiber = ctx.plugin({ inject: [...inject], apply })
  return {
    ctx,
    fiber,
    entry: () => ctx.slots.entries('conversation.composer.dock')[0],
  }
}

describe('dsh-token-usage browser plugin', () => {
  it('registers the dock entry with the documented id, priority, and locale', async () => {
    const b = await bench()
    await b.fiber.await()

    expect(b.entry()?.options).toMatchObject({ id: 'stats', priority: -1 })
    expect(b.entry()?.locale).toBe('tokenUsage')
  })

  it('registers its dictionary namespace on the locale service', async () => {
    const b = await bench()
    await b.fiber.await()

    const ctx = b.ctx as Context & { locale: LocaleRuntimeType }
    // The registered dictionaries surface through the locale snapshot revision.
    expect(ctx.locale.getLocale().revision).toBeGreaterThanOrEqual(1)
    // A bound translate resolves a key from the registered namespace.
    expect(ctx.locale.bind('tokenUsage')('bar.input')).toMatch(/输入|input/)
  })

  it('withdraws the registration when the plugin fiber is disposed', async () => {
    const b = await bench()
    await b.fiber.await()
    expect(b.ctx.slots.entries('conversation.composer.dock')).toHaveLength(1)

    await b.fiber.dispose()

    expect(b.ctx.slots.entries('conversation.composer.dock')).toHaveLength(0)
  })

  it('re-registers cleanly when the plugin is reloaded', async () => {
    const b = await bench()
    await b.fiber.await()
    await b.fiber.dispose()

    const reloaded = b.ctx.plugin({ inject: [...inject], apply })
    await reloaded.await()

    expect(b.ctx.slots.entries('conversation.composer.dock')).toHaveLength(1)
    expect(b.entry()?.options).toMatchObject({ id: 'stats', priority: -1 })
  })

  it('the node half applies without host-side behavior', async () => {
    const { apply: nodeApply } = await import('../src/index.ts')
    expect(() => { nodeApply() }).not.toThrow()
  })
})
