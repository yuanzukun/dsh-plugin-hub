/**
 * Locale dictionaries: the en dictionary must cover exactly the zh key set
 * (the registration requires every shipped locale complete).
 */
import { describe, expect, it } from 'vitest'
import { NS, en, zh, type TokenUsageKey } from '../src/client/locales.ts'

describe('tokenUsage dictionaries', () => {
  it('keeps en complete against the zh key set', () => {
    expect(Object.keys(en).sort()).toEqual(Object.keys(zh).sort())
  })
  it('keeps the namespace stable', () => {
    expect(NS).toBe('tokenUsage')
  })
  it('exposes every key as a string template', () => {
    for (const key of Object.keys(zh) as TokenUsageKey[]) {
      expect(typeof zh[key]).toBe('string')
      expect(typeof en[key]).toBe('string')
    }
  })
})
