// @vitest-environment jsdom
/**
 * TokenUsageBar rendering: chips derive from the projections, the bar hides
 * until any datum exists, and the details panel opens/closes on click,
 * Escape, and outside pointer-down.
 */
import { fireEvent, render, screen } from '@testing-library/react'
import { afterEach, describe, expect, it } from 'vitest'
import type { ConversationSnapshot } from '@deepseek-ai/dsh-client-runtime/client'
import type { UseProjection } from '@deepseek-ai/dsh-client-runtime/client'
import type { TranslateNS } from '@deepseek-ai/dsh-client-ui-slots'
import { en, type TokenUsageKey } from '../src/client/locales.ts'
import { TokenUsageBar } from '../src/client/TokenUsageBar.tsx'

afterEach(() => {
  document.body.innerHTML = ''
})

/** Translate through the real en dictionary with {name} interpolation. */
const t = ((key: string, params?: Record<string, unknown>): string => {
  const template = en[key as TokenUsageKey] ?? key
  return template.replace(/\{(\w+)\}/g, (_, name: string) => String(params?.[name] ?? ''))
}) as TranslateNS<'tokenUsage'>

/** Fake projection reader answering only the seeded keys. */
function reader(seeded: Record<string, unknown>): UseProjection {
  return ((key: string) => seeded[key]) as UseProjection
}

const EMPTY_SESSION = { chat: { legacy: { nodes: [] } } } as unknown as ConversationSnapshot

const seeded: Record<string, unknown> = {
  tokenUsage: { uncachedInputTokens: 4000, outputTokens: 3200, cacheReadTokens: 8400, cacheWriteTokens: 345 },
  contextPressure: { pressureTokens: 1000, projectedTokens: 23040, contextWindow: 128000 },
  contextBreakdown: { systemTokens: 1000, toolsTokens: 2000, messageTokens: 3000 },
  sessionStats: { turns: 3, steps: 5, llmMs: 45200, toolMs: 12000, ttftMs: 1800, ttftSteps: 1, decodeMs: 8000, decodeTokens: 79.2 },
}

describe('TokenUsageBar', () => {
  it('renders nothing before any usage datum exists', () => {
    const { container } = render(<TokenUsageBar session={EMPTY_SESSION} useProjection={reader({})} t={t} />)
    expect(container.firstChild).toBeNull()
  })

  it('renders the chip row with context, tokens, cache, and speed', () => {
    render(<TokenUsageBar session={EMPTY_SESSION} useProjection={reader(seeded)} t={t} />)
    const bar = screen.getByRole('button', { name: 'Toggle token usage details' })
    expect(bar.getAttribute('aria-expanded')).toBe('false')
    expect(bar.textContent).toContain('context')
    expect(bar.textContent).toContain('18%')
    expect(bar.textContent).toContain('input')
    expect(bar.textContent).toContain('12.7K')
    expect(bar.textContent).toContain('output')
    expect(bar.textContent).toContain('3.2K')
    expect(bar.textContent).toContain('hit rate 66%')
    expect(bar.textContent).toContain('9.9 tok/s')
    expect(bar.textContent).toContain('TTFT 1.8s')
  })

  it('opens the details panel on click and closes it on Escape', () => {
    render(<TokenUsageBar session={EMPTY_SESSION} useProjection={reader(seeded)} t={t} />)
    const bar = screen.getByRole('button', { name: 'Toggle token usage details' })
    fireEvent.click(bar)
    const panel = screen.getByRole('region', { name: 'Token usage' })
    // Edge fades render hidden when the panel content is not scrollable.
    expect(panel.querySelectorAll('[data-visible]')).toHaveLength(0)
    expect(panel.textContent).toContain('23K / 128K')
    expect(panel.textContent).toContain('Output')
    expect(panel.textContent).toContain('Throughput')
    expect(panel.textContent).toContain('First token')
    expect(panel.textContent).toContain('3 turns')
    expect(panel.textContent).toContain('5 steps')
    expect(panel.textContent).toContain('Model 45.2s')
    fireEvent.keyDown(document, { key: 'Escape' })
    expect(screen.queryByRole('region', { name: 'Token usage' })).toBeNull()
  })

  it('closes the panel on an outside pointer-down', () => {
    render(<TokenUsageBar session={EMPTY_SESSION} useProjection={reader(seeded)} t={t} />)
    fireEvent.click(screen.getByRole('button', { name: 'Toggle token usage details' }))
    expect(screen.getByRole('region', { name: 'Token usage' })).toBeTruthy()
    fireEvent.pointerDown(document.body)
    expect(screen.queryByRole('region', { name: 'Token usage' })).toBeNull()
  })

  it('shows the heuristic context composition rows', () => {
    render(<TokenUsageBar session={EMPTY_SESSION} useProjection={reader(seeded)} t={t} />)
    fireEvent.click(screen.getByRole('button', { name: 'Toggle token usage details' }))
    const panel = screen.getByRole('region', { name: 'Token usage' })
    expect(panel.textContent).toContain('Context composition')
    expect(panel.textContent).toContain('System')
    expect(panel.textContent).toContain('1K')
    expect(panel.textContent).toContain('Tools')
    expect(panel.textContent).toContain('2K')
    expect(panel.textContent).toContain('Messages')
    expect(panel.textContent).toContain('3K')
  })

  it('marks high occupancy with the danger tone', () => {
    const hot = reader({ ...seeded, contextPressure: { pressureTokens: 1000, projectedTokens: 110000, contextWindow: 128000 } })
    render(<TokenUsageBar session={EMPTY_SESSION} useProjection={hot} t={t} />)
    expect(document.querySelector('[data-tone="danger"]')).not.toBeNull()
  })

  it('falls back to the window fold when the sessionStats projection is absent', () => {
    const withoutStats = reader({ tokenUsage: seeded.tokenUsage, contextPressure: seeded.contextPressure })
    render(<TokenUsageBar session={EMPTY_SESSION} useProjection={withoutStats} t={t} />)
    // No nodes on screen: the fold yields zero steps, so only tokens show.
    expect(screen.getByRole('button', { name: 'Toggle token usage details' }).textContent).toContain('12.7K')
  })
})
