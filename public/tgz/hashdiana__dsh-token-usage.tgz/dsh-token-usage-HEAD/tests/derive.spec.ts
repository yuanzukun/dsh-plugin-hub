/**
 * Pure display derivation: formatters, occupancy math, and the window fold.
 * The fold must be deterministic — replaying the same nodes yields the same
 * totals — and mirror the `sessionStats` projection shape so the two swap
 * wholesale.
 */
import { describe, expect, it } from 'vitest'
import type { AssistantMessageNode, ConversationNode } from '@deepseek-ai/dsh-client-runtime/client'
import {
  billedInputTokens, cacheHitPercent, contextOccupancy, deriveStats,
  formatDuration, formatTokens, formatTokensPerSecond, tokensPerSecondOf,
  ttftAverageOf,
} from '../src/client/derive.ts'

describe('formatTokens', () => {
  it('keeps raw digits under a thousand', () => {
    expect(formatTokens(0)).toBe('0')
    expect(formatTokens(517)).toBe('517')
  })
  it('scales thousands with one decimal under three digits', () => {
    expect(formatTokens(12345)).toBe('12.3K')
    expect(formatTokens(517000)).toBe('517K')
    expect(formatTokens(1200000)).toBe('1.2M')
  })
})

describe('formatDuration', () => {
  it('renders sub-minute durations with one decimal', () => {
    expect(formatDuration(45200)).toBe('45.2s')
    expect(formatDuration(0)).toBe('0s')
  })
  it('renders minute durations compactly', () => {
    expect(formatDuration(162000)).toBe('2m42s')
    expect(formatDuration(60000)).toBe('1m0s')
  })
})

describe('formatTokensPerSecond', () => {
  it('keeps one decimal under ten and rounds from there', () => {
    expect(formatTokensPerSecond(9.94)).toBe('9.9')
    expect(formatTokensPerSecond(12.4)).toBe('12')
  })
  it('clamps negative readings to zero', () => {
    expect(formatTokensPerSecond(-5)).toBe('0')
  })
})

describe('token accounting', () => {
  const usage = { uncachedInputTokens: 20, outputTokens: 999, cacheReadTokens: 60, cacheWriteTokens: 20 }
  it('sums the three disjoint prompt-side buckets', () => {
    expect(billedInputTokens(usage)).toBe(100)
  })
  it('computes the cache-hit share of billed input', () => {
    expect(cacheHitPercent(usage)).toBe(60)
  })
  it('returns null when no input was billed', () => {
    expect(cacheHitPercent({ uncachedInputTokens: 0, outputTokens: 5, cacheReadTokens: 0, cacheWriteTokens: 0 })).toBeNull()
  })
})

describe('contextOccupancy', () => {
  it('prefers the projected numerator over the bare sample', () => {
    expect(contextOccupancy({ pressureTokens: 1000, projectedTokens: 2000, contextWindow: 10000 }))
      .toEqual({ percent: 20, usedTokens: 2000, contextWindow: 10000 })
  })
  it('clamps at 100 percent', () => {
    expect(contextOccupancy({ pressureTokens: 30000, contextWindow: 10000 })?.percent).toBe(100)
  })
  it('is null until both numerator and capacity are known', () => {
    expect(contextOccupancy(undefined)).toBeNull()
    expect(contextOccupancy({ pressureTokens: 1000 })).toBeNull()
    expect(contextOccupancy({ contextWindow: 10000 })).toBeNull()
  })
})

describe('deriveStats', () => {
  const assistant = (overrides: Partial<AssistantMessageNode> = {}): ConversationNode => ({
    kind: 'assistant',
    seq: 1,
    time: 1000,
    turn: 1,
    step: 1,
    blocks: [],
    timing: { stepStartTime: 1000, firstTokenTime: 1200, completedTime: 2000 },
    usage: { outputTokens: 100 },
    ...overrides,
  } as ConversationNode)

  it('folds turns, steps, wall times, ttft, and decode throughput', () => {
    const nodes: ConversationNode[] = [
      assistant(),
      {
        kind: 'tool-result',
        seq: 2,
        time: 3000,
        callId: 'c1',
        call: null,
        callTime: 2000,
        content: [],
        isError: false,
      } as ConversationNode,
    ]
    expect(deriveStats(nodes)).toEqual({
      turns: 1, steps: 1, llmMs: 1000, toolMs: 1000, ttftMs: 200, ttftSteps: 1,
      decodeMs: 800, decodeTokens: 100,
    })
  })

  it('skips unrecorded timing and usage parts', () => {
    const nodes: ConversationNode[] = [
      assistant({ timing: undefined }),
      assistant({ seq: 2, turn: 1, step: 2, timing: { stepStartTime: null, firstTokenTime: null, completedTime: 3000 }, usage: undefined }),
    ]
    expect(deriveStats(nodes)).toEqual({
      turns: 1, steps: 2, llmMs: 0, toolMs: 0, ttftMs: 0, ttftSteps: 0, decodeMs: 0, decodeTokens: 0,
    })
  })

  it('is deterministic: the same nodes always produce the same totals', () => {
    const nodes: ConversationNode[] = [assistant(), assistant({ seq: 2, turn: 2, step: 1 })]
    expect(deriveStats(nodes)).toEqual(deriveStats(nodes))
  })

  it('counts each distinct turn once', () => {
    const nodes: ConversationNode[] = [assistant(), assistant({ seq: 2, turn: 1, step: 2 }), assistant({ seq: 3, turn: 2, step: 1 })]
    expect(deriveStats(nodes).turns).toBe(2)
    expect(deriveStats(nodes).steps).toBe(3)
  })
})

describe('speed readings', () => {
  const stats = { turns: 1, steps: 1, llmMs: 1000, toolMs: 0, ttftMs: 1800, ttftSteps: 1, decodeMs: 8000, decodeTokens: 79.2 }
  it('divides decode tokens by decode wall seconds', () => {
    expect(tokensPerSecondOf(stats)).toBeCloseTo(9.9)
  })
  it('averages ttft over recorded steps', () => {
    expect(ttftAverageOf(stats)).toBe(1800)
  })
  it('returns null without sampled steps', () => {
    expect(tokensPerSecondOf({ ...stats, decodeMs: 0 })).toBeNull()
    expect(ttftAverageOf({ ...stats, ttftSteps: 0 })).toBeNull()
  })
})
