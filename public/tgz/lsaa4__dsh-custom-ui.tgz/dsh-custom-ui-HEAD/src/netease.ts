/**
 * NetEase Cloud Music integration (host half).
 * Routes: /netease/weapi, /netease/lyric,
 * /netease/account, /netease/logout, /netease/cookie, /netease/hot-playlists,
 * /netease/search, /netease/song-url.
 */
import { createCipheriv, createPublicKey, publicEncrypt, randomBytes, constants } from 'node:crypto'
import { existsSync, mkdirSync, readFileSync, renameSync, writeFileSync } from 'node:fs'
import { homedir } from 'node:os'
import { join } from 'node:path'
import type { IncomingMessage, ServerResponse } from 'node:http'
import type { Agent as HttpAgent } from 'node:http'
import fetch from 'node-fetch'
import { SocksProxyAgent } from 'socks-proxy-agent'
import { HttpProxyAgent } from 'http-proxy-agent'


let proxyAgentCache: { url: string; agent: HttpAgent } | null = null

function readProxy(): string {
  try {
    const home = process.env.DSH_HOME ?? join(homedir(), '.dsh')
    const raw = JSON.parse(readFileSync(join(home, 'data', 'glass-ui', 'config.json'), 'utf8')) as {
      neteaseProxy?: unknown
    }
    return typeof raw.neteaseProxy === 'string' ? raw.neteaseProxy.trim() : ''
  } catch {
    return ''
  }
}

function agentFor(proxyUrl: string): HttpAgent | undefined {
  if (proxyUrl === '') return undefined
  if (proxyAgentCache === null || proxyAgentCache.url !== proxyUrl) {
    proxyAgentCache?.agent.destroy()
    proxyAgentCache = {
      url: proxyUrl,
      agent: proxyUrl.startsWith('socks')
        ? new SocksProxyAgent(proxyUrl)
        : new HttpProxyAgent(proxyUrl),
    }
  }
  return proxyAgentCache.agent
}

/**
 * Address sent in `X-Real-IP` / `X-Forwarded-For` on every music.163.com call.
 *
 * NetEase's edge decides on the client address before it looks at the payload:
 * datacenter ranges, overseas addresses and addresses already associated with
 * automated traffic get challenged instead of served. The symptom is a login
 * that never confirms — the QR key is handed out but the scan stays at 801, and
 * weapi answers `-460` or `250` instead of data — while the very same cookie
 * works fine in a browser on the same account.
 *
 * Presenting a mainland address in those two headers is what the
 * NeteaseCloudMusicApi project calls `realIP`, and it is the first thing to try
 * when the QR flow stalls. An empty setting sends no headers at all and lets
 * the real client address speak for itself.
 */
const DEFAULT_REAL_IP = '118.88.88.88'

function readRealIp(): string {
  try {
    const home = process.env.DSH_HOME ?? join(homedir(), '.dsh')
    const raw = JSON.parse(readFileSync(join(home, 'data', 'glass-ui', 'config.json'), 'utf8')) as {
      neteaseRealIp?: unknown
    }
    // an explicitly empty value means "send nothing", so only a missing key
    // falls back to the default
    if (typeof raw.neteaseRealIp === 'string') return raw.neteaseRealIp.trim()
  } catch {
    /* fall through to the default */
  }
  return DEFAULT_REAL_IP
}

/** Headers every direct music.163.com request carries. */
function neteaseHeaders(extra: Record<string, string> = {}): Record<string, string> {
  const realIp = readRealIp()
  return {
    'user-agent': NETBASE_UA,
    'referer': 'https://music.163.com/',
    ...(realIp === '' ? {} : { 'x-real-ip': realIp, 'x-forwarded-for': realIp }),
    ...extra,
  }
}

/**
 * Upstream answers that mean "challenged / rate-limited / needs verification",
 * not "this session ended". Treating them as an invalid cookie is what made a
 * perfectly good Cookie look expired every time risk control kicked in.
 */
const RISK_CODES: ReadonlySet<number> = new Set([-460, -2, 250, 301, 882])

interface UpstreamVerdict {
  code: number | null
  message: string | null
  risk: boolean
}

/** Read the code/message out of a weapi body and classify it. */
function upstreamVerdict(json: unknown): UpstreamVerdict {
  const body = (json ?? {}) as { code?: unknown; message?: unknown; msg?: unknown }
  const code = typeof body.code === 'number' ? body.code : null
  const message = typeof body.message === 'string'
    ? body.message
    : typeof body.msg === 'string'
      ? body.msg
      : null
  return { code, message, risk: code !== null && RISK_CODES.has(code) }
}

/**
 * Legacy plain `/api/` transport.
 *
 * NetEase's edge answers `/weapi/*` with HTTP 200 and an *empty body* for
 * traffic it declines to serve — verified from a home network, all hosts and
 * header shapes alike, while `GET` requests and the legacy plain paths keep
 * answering normally. The old QR handshake is the same two steps in plain
 * form, so login falls back to it whenever the encrypted path comes back
 * empty.
 */
async function legacyJson(
  path: string,
  cookie: string,
): Promise<{ json: Record<string, unknown>; setCookie: string[] }> {
  const proxy = readProxy()
  const agent = agentFor(proxy)
  const res = await fetch(`${API_BASE}${path}`, {
    headers: neteaseHeaders(
      cookie === '' ? {} : { cookie: `os=pc; appver=2.9.7; ${cookie}` },
    ),
    ...(agent !== undefined ? { agent } : {}),
  })
  const text = await res.text()
  if (text === '') throw new Error(`legacy ${path} returned an empty response`)
  return {
    json: JSON.parse(text) as Record<string, unknown>,
    setCookie: setCookieList(res.headers),
  }
}

/**
 * Retry a blocked weapi call on the legacy transport.
 * @returns the legacy answer, or undefined when this path has no legacy form.
 */
async function legacyFallback(
  path: string,
  data: unknown,
  cookie: string,
): Promise<{ json: unknown; setCookie: string[] } | undefined> {
  const d = (data ?? {}) as Record<string, unknown>
  if (path === '/weapi/login/qrcode/unikey') {
    const { json } = await legacyJson('/api/login/qrcode/unikey?type=1', '')
    const unikey = (json as { unikey?: unknown }).unikey
    if (typeof unikey !== 'string' || unikey === '') return undefined
    return { json: { code: 200, unikey }, setCookie: [] }
  }
  if (path === '/weapi/login/qrcode/client/login') {
    const key = String(d.key ?? '')
    if (key === '') return undefined
    const { json, setCookie } = await legacyJson(
      `/api/login/qrcode/client/login?key=${encodeURIComponent(key)}&type=1`,
      '',
    )
    // A confirmed scan carries the session either as Set-Cookie headers (the
    // official endpoint) or as a `cookie` field in the body (the
    // NeteaseCloudMusicApi shape). Accept both: missing it means the scan is
    // never persisted and the UI can never see the login.
    const bodyCookie = (json as { cookie?: unknown }).cookie
    const extra = typeof bodyCookie === 'string' && bodyCookie !== ''
      ? bodyCookie
          .split(';')
          .map((pair) => pair.trim())
          .filter((pair) => pair.includes('=')
            && !/^(path|domain|expires|max-age|httponly|secure|samesite)=/i.test(pair))
      : []
    return { json, setCookie: [...setCookie, ...extra] }
  }
  if (path === '/weapi/w/nuser/account/get') {
    const { json } = await legacyJson('/api/nuser/account/get', cookie)
    return { json, setCookie: [] }
  }
  // Catalog calls are the ones a signed-in user hits immediately, and they are
  // blocked on the encrypted path just like login is.
  if (path === '/weapi/user/playlist') {
    const uid = Number(d.uid ?? 0)
    if (uid === 0) return undefined
    const limit = Number(d.limit ?? 60)
    const offset = Number(d.offset ?? 0)
    const { json } = await legacyJson(
      `/api/user/playlist?uid=${uid}&limit=${limit}&offset=${offset}&includeVideo=true`,
      cookie,
    )
    return { json, setCookie: [] }
  }
  if (path === '/weapi/v6/playlist/detail') {
    const id = Number(d.id ?? 0)
    if (id === 0) return undefined
    // the v6 plain endpoint already answers with ar/al/dt, so it passes through
    const { json } = await legacyJson(`/api/v6/playlist/detail?id=${id}&n=1000&s=8`, cookie)
    return { json, setCookie: [] }
  }
  if (path === '/weapi/v1/discovery/recommend/songs') {
    const { json } = await legacyJson('/api/v1/discovery/recommend/songs', cookie)
    const dailySongs = ((json as { data?: { dailySongs?: unknown[] } }).data?.dailySongs ?? [])
      .map(normalizeLegacySong)
    return { json: { code: 200, data: { dailySongs } }, setCookie: [] }
  }
  if (path === '/weapi/song/enhance/player/url') {
    const ids = Array.isArray(d.ids) ? d.ids : []
    const id = Number(ids[0] ?? 0)
    if (id === 0) return undefined
    const br = Number(d.br ?? 320000)
    const { json } = await legacyJson(
      `/api/song/enhance/player/url?ids=%5B${id}%5D&br=${br}`,
      cookie,
    )
    return { json, setCookie: [] }
  }
  return undefined
}

/**
 * The classic daily-recommend answer still uses pre-v6 field names while the
 * client half reads the v6 ones; map them here so only one side knows about the
 * difference.
 */
function normalizeLegacySong(raw: unknown): Record<string, unknown> {
  const song = (raw ?? {}) as Record<string, unknown> & {
    artists?: Array<{ name?: string }>
    album?: { name?: string; picUrl?: string }
    duration?: number
  }
  return {
    ...song,
    ar: song.ar ?? (song.artists ?? []).map((artist) => ({ name: artist.name })),
    al: song.al ?? { name: song.album?.name, picUrl: song.album?.picUrl },
    dt: song.dt ?? song.duration,
  }
}

function normalizeSetCookiePair(raw: string): string[] {
  return raw
    .split(';')
    .map((s) => s.trim())
    .filter((s) => s !== '' && s.includes('=') && !/^(path|domain|expires|max-age|httponly|secure|samesite)=/i.test(s))
}

function setCookieList(headers: import('node-fetch').Headers): string[] {
  const anyHeaders = headers as unknown as {
    raw?: () => Record<string, string[]>
    getSetCookie?: () => string[]
  }
  // Modern fetch / undici exposes getSetCookie(); prefer it when available.
  if (typeof anyHeaders.getSetCookie === 'function') {
    return anyHeaders.getSetCookie().flatMap(normalizeSetCookiePair)
  }
  if (typeof anyHeaders.raw === 'function') {
    return (anyHeaders.raw()['set-cookie'] ?? []).flatMap(normalizeSetCookiePair)
  }
  const single = headers.get('set-cookie')
  return single === null ? [] : normalizeSetCookiePair(single)
}


const AES_KEY = '0CoJUm6Qyw8W8jud'
const AES_IV = '0102030405060708'
const RSA_E = '010001'
const RSA_N =
  '00e0b509f6259df8642dbc35662901477df22677ec152b5ff68ace615bb7b725152b3ab17a876aea8a5aa76d2e417629ec4ee341f56135fccf695280104e0312ecbda92557c93870114af6c9d05c4f7f0c3685b7a46bee255932575cce10b424d813cfe4875d3e82047b97ddef52741d546b8e289dc6935b3ece0462db0a22b8e7'

function aesEncrypt(text: string, key: string): string {
  const cipher = createCipheriv('aes-128-cbc', Buffer.from(key), Buffer.from(AES_IV))
  return cipher.update(text, 'utf8', 'hex') + cipher.final('hex')
}

function rsaEncrypt(text: string): string {
  const reversed = Buffer.from(text).reverse()
  const key = createPublicKey({
    key: {
      kty: 'RSA',
      // JWK fields are base64url — convert from the hex literals
      n: Buffer.from(RSA_N, 'hex').toString('base64url'),
      e: Buffer.from(RSA_E, 'hex').toString('base64url'),
    },
    format: 'jwk',
  })
  return publicEncrypt({ key, padding: constants.RSA_PKCS1_PADDING }, reversed).toString('hex')
}

/** A 16-char random secret: AES-128 needs a 16-byte key (the scheme's own
 * alphabet, matching NeteaseCloudMusicApi's createSecretKey). */
function randomSecret(): string {
  const chars = 'abcdefghijklmnopqrstuvwxyz0123456789'
  let out = ''
  for (let i = 0; i < 16; i++) out += chars[randomBytes(1)[0]! % chars.length]
  return out
}

function weapiParams(data: unknown): { params: string; encSecKey: string } {
  const randomKey = randomSecret()
  const params = aesEncrypt(aesEncrypt(JSON.stringify(data), randomKey), AES_KEY)
  const encSecKey = rsaEncrypt(randomKey)
  return { params, encSecKey }
}


function cookiePath(): string {
  const home = process.env.DSH_HOME ?? join(homedir(), '.dsh')
  return join(home, 'data', 'glass-ui', 'netease-cookie.json')
}

function readCookie(): string {
  try {
    const raw = JSON.parse(readFileSync(cookiePath(), 'utf8')) as { cookie?: string }
    return raw.cookie ?? ''
  } catch {
    return ''
  }
}

function writeCookie(cookie: string): void {
  if (cookie === '') return
  mkdirSync(join(cookiePath(), '..'), { recursive: true })
  const tmp = cookiePath() + '.tmp'
  writeFileSync(tmp, JSON.stringify({ cookie }), 'utf8')
  renameSync(tmp, cookiePath())
}

export function clearCookie(): void {
  try {
    writeFileSync(cookiePath(), JSON.stringify({ cookie: '' }), 'utf8')
  } catch {
    /* ignore */
  }
}

function mergeCookies(saved: string, setCookie: readonly string[] | undefined): string {
  if (setCookie === undefined || setCookie.length === 0) return saved
  const parts = saved === '' ? [] : saved.split('; ').map((p) => p.trim())
  const map = new Map(parts.map((p) => [p.split('=')[0], p]))
  for (const raw of setCookie) {
    const first = raw.split(';')[0]?.trim()
    if (first === undefined || first === '') continue
    const name = first.split('=')[0]
    if (name !== undefined) map.set(name, first)
  }
  return [...map.values()].join('; ')
}


const API_BASE = 'https://music.163.com'
const NETBASE_UA =
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36'

/** Remote NeteaseCloudMusicApi server (public/self-hosted) from config.neteaseApiBase. */
function readApiBase(): string {
  try {
    const home = process.env.DSH_HOME ?? join(homedir(), '.dsh')
    const raw = JSON.parse(readFileSync(join(home, 'data', 'glass-ui', 'config.json'), 'utf8')) as {
      neteaseApiBase?: unknown
    }
    return typeof raw.neteaseApiBase === 'string' ? raw.neteaseApiBase.trim().replace(/\/+$/, '') : ''
  } catch {
    return ''
  }
}

async function remoteJson(url: string, headers: Record<string, string>): Promise<Record<string, unknown>> {
  // the remote server is reachable directly — no proxy (the proxy is only for
  // the official endpoints that are blocked from this network)
  const res = await fetch(url, {
    headers: { 'user-agent': NETBASE_UA, ...headers },
    signal: AbortSignal.timeout(20000),
  })
  const text = await res.text()
  if (text === '') throw new Error(`remote api ${url} returned empty response`)
  return JSON.parse(text) as Record<string, unknown>
}

/** Adapt one weapi-style call to a NeteaseCloudMusicApi-compatible server. */
async function remoteWeapiRequest(
  apiBase: string,
  path: string,
  data: Record<string, unknown>,
  cookie: string,
): Promise<{ json: Record<string, unknown>; setCookie: string[] }> {
  const headers: Record<string, string> = cookie !== '' ? { cookie } : {}
  const d = data as Record<string, unknown>
  switch (path) {
    case '/weapi/login/qrcode/unikey': {
      const j = await remoteJson(`${apiBase}/login/qr/key`, {})
      const key = (j.data as { unikey?: string } | undefined)?.unikey ?? (typeof j.unikey === 'string' ? j.unikey : '')
      let qrimg = ''
      if (key !== '') {
        try {
          const img = await remoteJson(
            `${apiBase}/login/qr/create?key=${encodeURIComponent(key)}&qrimg=true`,
            headers,
          )
          const data = img.data as { qrimg?: string } | undefined
          qrimg = typeof data?.qrimg === 'string' ? data.qrimg : (typeof img.qrimg === 'string' ? img.qrimg : '')
        } catch {
          qrimg = '' // client falls back to local rendering
        }
      }
      return { json: { code: 200, unikey: key, qrimg }, setCookie: [] }
    }
    case '/weapi/login/qrcode/client/login': {
      const key = String(d.key ?? '')
      const j = await remoteJson(`${apiBase}/login/qr/check?key=${encodeURIComponent(key)}`, {})
      const code = Number(j.code ?? 801)
        const qrData = (j.data ?? {}) as { cookie?: unknown; nickname?: unknown; avatarUrl?: unknown }
        const cookie = typeof j.cookie === 'string' && j.cookie !== ''
          ? j.cookie
          : typeof qrData.cookie === 'string'
            ? qrData.cookie
            : ''
        const nickname = typeof j.nickname === 'string' ? j.nickname : typeof qrData.nickname === 'string' ? qrData.nickname : undefined
        const avatarUrl = typeof j.avatarUrl === 'string' ? j.avatarUrl : typeof qrData.avatarUrl === 'string' ? qrData.avatarUrl : undefined
      // 803 = confirmed: NeteaseCloudMusicApi returns the session cookie inline
      if (code === 803 && cookie !== '') {
          // NeteaseCloudMusicApi returns a complete cookie string, not a
          // Set-Cookie header. Split it into individual `name=value` pairs so
          // mergeCookies keeps every session cookie instead of only the first.
          const cookies = cookie
            .split(';')
            .map((c) => c.trim())
            .filter((c) => c !== '' && c.includes('=') && !/^(path|domain|expires|max-age|httponly|secure|samesite)=/i.test(c))
        return {
          json: { code: 803, nickname, avatarUrl },
          setCookie: cookies,
        }
      }
      return { json: { code }, setCookie: [] }
    }
    case '/weapi/user/playlist': {
      const uid = Number(d.uid ?? 0)
      const limit = Number(d.limit ?? 60)
      const offset = Number(d.offset ?? 0)
      const j = await remoteJson(
        `${apiBase}/user/playlist?uid=${uid}&limit=${limit}&offset=${offset}`,
        headers,
      )
      return { json: { playlist: j.playlist }, setCookie: [] }
    }
    case '/weapi/w/nuser/account/get': {
      const j = await remoteJson(`${apiBase}/user/account`, headers)
      return { json: { profile: j.profile }, setCookie: [] }
    }
    case '/weapi/v6/playlist/detail': {
      const id = Number(d.id ?? 0)
      const j = await remoteJson(`${apiBase}/playlist/detail?id=${id}`, headers)
      return { json: { playlist: j.playlist }, setCookie: [] }
    }
    case '/weapi/v1/discovery/recommend/songs': {
      const j = await remoteJson(`${apiBase}/recommend/songs`, headers)
      const dailySongs = (j.data as { dailySongs?: unknown } | undefined)?.dailySongs ?? []
      return { json: { data: { dailySongs } }, setCookie: [] }
    }
    case '/weapi/song/enhance/player/url': {
      const ids = Array.isArray(d.ids) ? d.ids : []
      const id = Number(ids[0] ?? 0)
      const j = await remoteJson(`${apiBase}/song/url?id=${id}`, headers)
      const first = (j.data as Array<{ url?: string | null }> | undefined)?.[0]
      return { json: { data: [{ url: first?.url ?? null }] }, setCookie: [] }
    }
    default:
      throw new Error(`remote api: unsupported weapi path ${path}`)
  }
}

async function weapiRequest(path: string, data: unknown, cookie: string): Promise<{
  json: unknown
  setCookie: string[]
}> {
  const apiBase = readApiBase()
  if (apiBase !== '') {
      try {
    return await remoteWeapiRequest(apiBase, path, data as Record<string, unknown>, cookie)
      } catch (err) {
        // If the remote API server fails, fall back to the official endpoint.
        // This keeps cookie login / account checks working when the remote is down.
        console.warn(`[dsh-glass-ui] remote netease api failed, fallback to official: ${err instanceof Error ? err.message : String(err)}`)
      }
  }
  const form = new URLSearchParams()
  const enc = weapiParams(data)
  form.set('params', enc.params)
  form.set('encSecKey', enc.encSecKey)
    // QR login endpoints should not carry a stale saved cookie; a fresh login
    // must start from a clean state.
    const requestCookie = path.startsWith('/weapi/login/qrcode/') ? '' : cookie
  const proxy = readProxy()
  const agent = agentFor(proxy)
  const res = await fetch(`${API_BASE}${path}`, {
    method: 'POST',
    headers: neteaseHeaders({
      'content-type': 'application/x-www-form-urlencoded',
      ...(requestCookie !== ''
        ? { cookie: `os=pc; appver=2.9.7; ${requestCookie}` }
        : { cookie: 'os=pc; appver=2.9.7' }),
    }),
    body: form,
    ...(agent !== undefined ? { agent } : {}),
  })
  const text = await res.text()
  if (text === '') {
    // The edge answered instead of the application: retry the legacy plain
    // transport before reporting the network as unreachable.
    const fallback = await legacyFallback(path, data, cookie)
    if (fallback !== undefined) return fallback
    throw new Error('netease weapi unreachable from this network (empty response)')
  }
  const json = JSON.parse(text) as unknown
  const setCookie = setCookieList(res.headers)
  return { json, setCookie }
}

async function publicLyric(id: string): Promise<{ lrc?: string }> {
  const apiBase = readApiBase()
  const proxy = readProxy()
  const agent = agentFor(proxy)
  const url = apiBase !== ''
    ? `${apiBase}/lyric?id=${encodeURIComponent(id)}`
    : `${API_BASE}/api/song/lyric?id=${encodeURIComponent(id)}&lv=1&kv=1&tv=-1`
  const res = await fetch(url, {
    headers: neteaseHeaders(
      apiBase !== '' && readCookie() !== '' ? { cookie: readCookie() } : {},
    ),
    ...(agent !== undefined ? { agent } : {}),
  })
  const json = await res.json().catch(() => ({})) as { lrc?: { lyric?: string } }
  return { lrc: json.lrc?.lyric }
}

/** GET a public (unencrypted) music.163.com API path. */
async function publicJson(path: string): Promise<unknown> {
  const proxy = readProxy()
  const agent = agentFor(proxy)
  const res = await fetch(`${API_BASE}${path}`, {
    headers: neteaseHeaders(),
    ...(agent !== undefined ? { agent } : {}),
  })
  return res.json().catch(() => ({ code: -1 }))
}


function sendJson(res: ServerResponse, status: number, body: unknown): void {
  res.writeHead(status, {
    'content-type': 'application/json; charset=utf-8',
    'cache-control': 'no-store',
  })
  res.end(JSON.stringify(body))
}

function sendText(res: ServerResponse, status: number, text: string): void {
  res.writeHead(status, { 'content-type': 'text/plain; charset=utf-8' })
  res.end(text)
}

function readSmallBody(req: IncomingMessage, max = 128 * 1024): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    const chunks: Buffer[] = []
    let size = 0
    req.on('data', (chunk: Buffer) => {
      size += chunk.length
      if (size > max) {
        reject(new Error('payload too large'))
        req.destroy()
        return
      }
      chunks.push(chunk)
    })
    req.on('end', () => resolve(Buffer.concat(chunks)))
    req.on('error', reject)
  })
}


export interface NeteaseRoutesHost {
  register(route: {
    kind: 'exact' | 'prefix'
    path: string
    handler: (req: IncomingMessage, res: ServerResponse) => void | Promise<void>
  }): () => void
}

/** Register all /netease routes; returns a disposer for each registration. */
export function registerNeteaseRoutes(host: NeteaseRoutesHost): Array<() => void> {
  const disposers: Array<() => void> = []

  disposers.push(host.register({
    kind: 'exact',
    path: '/netease/weapi',
    handler: async (req, res) => {
      if (req.method !== 'POST') {
        sendText(res, 405, 'method not allowed')
        return
      }
      try {
        const body = JSON.parse((await readSmallBody(req)).toString('utf8')) as {
          path?: string
          data?: Record<string, unknown>
        }
        if (typeof body.path !== 'string' || !body.path.startsWith('/weapi/')) {
          sendText(res, 400, 'path must start with /weapi/')
          return
        }
        const cookie = readCookie()
        const { json, setCookie } = await weapiRequest(body.path, body.data ?? {}, cookie)
        writeCookie(mergeCookies(cookie, setCookie))
        sendJson(res, 200, json)
      } catch (err) {
        sendText(res, 502, err instanceof Error ? err.message : 'upstream failed')
      }
    },
  }))

  disposers.push(host.register({
    kind: 'exact',
    path: '/netease/lyric',
    handler: async (req, res) => {
      const url = new URL(req.url ?? '/netease/lyric', 'http://localhost')
      const id = url.searchParams.get('id') ?? ''
      if (id === '') {
        sendText(res, 400, 'missing id')
        return
      }
      try {
        const { lrc } = await publicLyric(id)
        sendJson(res, 200, { lrc: lrc ?? '' })
      } catch (err) {
        sendText(res, 502, err instanceof Error ? err.message : 'lyric failed')
      }
    },
  }))

  disposers.push(host.register({
    kind: 'exact',
    path: '/netease/hot-playlists',
    handler: async (_req, res) => {
      try {
        const apiBase = readApiBase()
        const json = apiBase !== ''
          ? await remoteJson(
              `${apiBase}/top/playlist?limit=20&order=hot`,
              readCookie() !== '' ? { cookie: readCookie() } : {},
            ) as {
              playlists?: Array<{ id?: number; name?: string; trackCount?: number }>
            }
          : await publicJson(
              '/api/playlist/highquality/list?cat=%E5%85%A8%E9%83%A8&limit=20',
            ) as {
              playlists?: Array<{ id?: number; name?: string; trackCount?: number }>
            }
        sendJson(res, 200, {
          playlists: (json.playlists ?? [])
            .filter((p) => typeof p.id === 'number' && typeof p.name === 'string')
            .map((p) => ({ id: p.id, name: p.name, trackCount: p.trackCount ?? 0 })),
        })
      } catch (err) {
        sendText(res, 502, err instanceof Error ? err.message : 'hot playlists failed')
      }
    },
  }))

  disposers.push(host.register({
    kind: 'exact',
    path: '/netease/search',
    handler: async (req, res) => {
      const url = new URL(req.url ?? '/netease/search', 'http://localhost')
      const q = (url.searchParams.get('q') ?? '').slice(0, 100)
      if (q === '') {
        sendText(res, 400, 'missing q')
        return
      }
      try {
        const apiBase = readApiBase()
        const json = apiBase !== ''
          ? await remoteJson(
              `${apiBase}/search?keywords=${encodeURIComponent(q)}&limit=20`,
              readCookie() !== '' ? { cookie: readCookie() } : {},
            ) as {
              result?: { songs?: Array<{
                id?: number
                name?: string
                artists?: Array<{ name?: string }>
                album?: { name?: string }
                  picUrl?: string
                duration?: number
              }> }
            }
          : await publicJson(
              `/api/search/get?type=1&s=${encodeURIComponent(q)}&limit=20`,
            ) as {
              result?: { songs?: Array<{
                id?: number
                name?: string
                artists?: Array<{ name?: string }>
                album?: { name?: string }
                duration?: number
                  picUrl?: string
              }> }
            }
        const songs = json.result?.songs ?? []
        sendJson(res, 200, {
          songs: songs
            .filter((s) => typeof s.id === 'number' && typeof s.name === 'string')
            .map((s) => ({
              id: s.id,
              name: s.name,
              artists: (s.artists ?? []).map((a) => a.name ?? '').filter((x) => x !== '').join(' / '),
              album: s.album?.name,
                cover: (s.album as unknown as { picUrl?: string } | undefined)?.picUrl,
              durationMs: s.duration,
            })),
        })
      } catch (err) {
        sendText(res, 502, err instanceof Error ? err.message : 'search failed')
      }
    },
  }))

  disposers.push(host.register({
    kind: 'exact',
    path: '/netease/song-url',
    handler: async (req, res) => {
      const url = new URL(req.url ?? '/netease/song-url', 'http://localhost')
      const id = url.searchParams.get('id') ?? ''
      if (id === '') {
        sendText(res, 400, 'missing id')
        return
      }
      try {
        const apiBase = readApiBase()
        if (apiBase !== '') {
          // remote mode: use the remote server's stream endpoint
          const j = await remoteJson(
            `${apiBase}/song/url?id=${encodeURIComponent(id)}`,
            readCookie() !== '' ? { cookie: readCookie() } : {},
          )
          const first = (j.data as Array<{ url?: string | null }> | undefined)?.[0]
          sendJson(res, 200, { url: first?.url ?? null })
          return
        }
        const proxy = readProxy()
        const agent = agentFor(proxy)
        const redirect = await fetch(
          `https://music.163.com/song/media/outer/url?id=${encodeURIComponent(id)}.mp3`,
          { redirect: 'manual', headers: neteaseHeaders(), ...(agent !== undefined ? { agent } : {}) },
        )
        const location = redirect.headers.get('location')
        // only hand out real CDN streams; copyright-restricted songs redirect
        // to a 404 page and must come back as null (client falls back / errors)
        const url = location !== null && location.includes('126.net') ? location : null
        sendJson(res, 200, { url })
      } catch (err) {
        sendText(res, 502, err instanceof Error ? err.message : 'song url failed')
      }
    },
  }))

  disposers.push(host.register({
    kind: 'exact',
    path: '/netease/account',
    handler: async (_req, res) => {
      const cookie = readCookie()
      if (cookie === '') {
        sendJson(res, 200, { loggedIn: false })
        return
      }
      try {
        const { json } = await weapiRequest('/weapi/w/nuser/account/get', {}, cookie)
        // the legacy transport answers `"profile": null` when anonymous, so a
        // missing key and a null one both mean "not signed in"
        const profile = (json as { profile?: { nickname?: string; avatarUrl?: string; userId?: number } | null })
          .profile
        if (profile === undefined || profile === null) {
          const verdict = upstreamVerdict(json)
          // A challenged answer is not a dead session: keep the cookie so the
          // user does not have to paste it again after risk control passes.
          if (!verdict.risk) clearCookie()
          sendJson(res, 200, {
            loggedIn: false,
            reason: verdict.risk ? 'risk' : 'cookie',
            code: verdict.code,
            message: verdict.message,
          })
          return
        }
        sendJson(res, 200, {
          loggedIn: true,
          uid: profile.userId,
          nickname: profile.nickname,
          avatarUrl: profile.avatarUrl,
        })
      } catch (err) {
        sendJson(res, 200, {
          loggedIn: false,
          reason: 'network',
          message: err instanceof Error ? err.message : String(err),
        })
      }
    },
  }))

  disposers.push(host.register({
    kind: 'exact',
    path: '/netease/logout',
    handler: (_req, res) => {
      clearCookie()
      sendJson(res, 200, { ok: true })
    },
  }))

  disposers.push(host.register({
    kind: 'exact',
    path: '/netease/cookie',
    handler: async (req, res) => {
      if (req.method !== 'POST') {
        sendText(res, 405, 'method not allowed')
        return
      }
      try {
        const body = JSON.parse((await readSmallBody(req)).toString('utf8')) as { cookie?: string }
        const cookie = String(body.cookie ?? '').trim().slice(0, 4000)
        if (cookie === '' || !cookie.includes('=')) {
          sendText(res, 400, 'cookie looks empty')
          return
        }
        // MUSIC_U is the session itself. Without it the paste is site
        // decoration — `document.cookie` cannot even see MUSIC_U, because it is
        // HttpOnly — so say that instead of reporting a rejected login.
        if (!/(?:^|;\s*)MUSIC_U=/.test(cookie)) {
          sendJson(res, 200, { ok: false, reason: 'no-session' })
          return
        }
        writeCookie(cookie)
        const { json } = await weapiRequest('/weapi/w/nuser/account/get', {}, cookie)
        const profile = (json as { profile?: { nickname?: string; userId?: number } | null }).profile
        if (profile === undefined || profile === null) {
          const verdict = upstreamVerdict(json)
          if (verdict.risk) {
            // keep the pasted cookie: risk control blocked the *check*, not the
            // session, so a retry from another network can still use it
            sendJson(res, 200, {
              ok: false,
              reason: 'risk',
              code: verdict.code,
              message: verdict.message,
            })
            return
          }
          clearCookie()
          sendJson(res, 200, { ok: false, reason: 'cookie' })
          return
        }
        sendJson(res, 200, { ok: true, nickname: profile.nickname, uid: profile.userId })
      } catch (err) {
        sendText(res, 502, err instanceof Error ? err.message : 'cookie login failed')
      }
    },
  }))

  // Login diagnosis: answers "is this risk control, a dead cookie, or a broken
  // network?" with the upstream's own code and message instead of a guess. The
  // QR probe matters most — when risk control blocks logins, the unikey call is
  // usually the first one to stop handing out keys.
  disposers.push(host.register({
    kind: 'exact',
    path: '/netease/diag',
    handler: async (_req, res) => {
      const cookie = readCookie()
      const report: Record<string, unknown> = {
        proxy: readProxy(),
        apiBase: readApiBase(),
        realIp: readRealIp(),
        hasCookie: cookie !== '',
        cookieNames: cookie === ''
          ? []
          : cookie.split('; ').map((pair) => pair.split('=')[0] ?? '').filter((name) => name !== ''),
        official: null,
        qrKey: null,
        legacy: null,
      }
      try {
        const { json } = await weapiRequest('/weapi/w/nuser/account/get', {}, cookie)
        const verdict = upstreamVerdict(json)
        report.official = {
          reachable: true,
          code: verdict.code,
          message: verdict.message,
          risk: verdict.risk,
          loggedIn: ((json as { profile?: unknown }).profile ?? null) !== null,
        }
      } catch (err) {
        report.official = {
          reachable: false,
          error: err instanceof Error ? err.message : String(err),
        }
      }
      try {
        const { json } = await weapiRequest('/weapi/login/qrcode/unikey', { type: 1 }, '')
        const verdict = upstreamVerdict(json)
        const key = (json as { unikey?: unknown }).unikey
        report.qrKey = {
          ok: typeof key === 'string' && key !== '',
          code: verdict.code,
          message: verdict.message,
        }
      } catch (err) {
        report.qrKey = { ok: false, error: err instanceof Error ? err.message : String(err) }
      }
      // the plain transport is the fallback the QR flow uses when the encrypted
      // path is refused, so report whether it hands out a key too
      try {
        const { json } = await legacyJson('/api/login/qrcode/unikey?type=1', '')
        const verdict = upstreamVerdict(json)
        const key = (json as { unikey?: unknown }).unikey
        report.legacy = {
          ok: typeof key === 'string' && key !== '',
          code: verdict.code,
          message: verdict.message,
        }
      } catch (err) {
        report.legacy = { ok: false, error: err instanceof Error ? err.message : String(err) }
      }
      sendJson(res, 200, report)
    },
  }))

  return disposers
}
