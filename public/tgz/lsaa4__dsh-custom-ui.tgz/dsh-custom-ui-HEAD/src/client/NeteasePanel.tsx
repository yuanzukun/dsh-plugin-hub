import { useEffect, useRef, useState } from 'react'
import QRCode from 'qrcode/lib/browser.js'
import { Button, Input, Pill, Toast } from '@deepseek-ai/dsh-client-ui-primitives'
import {
  fetchDailySongs,
  fetchHotPlaylists,
  fetchPlaylistTracks,
  fetchPlaylists,
  getAccount,
  getDiagnostics,
  hasSessionCookie,
  logout,
  pollQrLogin,
  requestQrKey,
  searchSongs,
  submitCookie,
  normalizeCookiePaste,
  type NeteaseAccount,
  type NeteaseDiagnostics,
  type NeteasePlaylist,
  type NeteaseSong,
  type QrStatus,
} from './netease.ts'
import { playback, type LyricPos } from './lyrics.ts'
import type { Translate } from './locales.ts'
import styles from './NeteasePanel.module.css'

export interface NeteasePanelProps {
  t: Translate
  lyricPos: LyricPos
  onLyricPos: (pos: LyricPos) => void
    mediaDisplay: boolean
    onMediaDisplay: (show: boolean) => void
  neteaseProxy: string
  onNeteaseProxy: (proxy: string) => void
  neteaseApiBase: string
  onNeteaseApiBase: (base: string) => void
  neteaseRealIp: string
  onNeteaseRealIp: (ip: string) => void
}

const LYRIC_POSITIONS: ReadonlyArray<{ id: LyricPos; labelKey: string }> = [
  { id: 'inline', labelKey: 'lyricPosInline' },
  { id: 'end', labelKey: 'lyricPosEnd' },
  { id: 'hidden', labelKey: 'lyricPosHidden' },
]

/** Where a pending QR login is remembered across settings-panel unmounts. */
const QR_STORE = 'dsh-glass-ui:netease-qr'
/** Older than this a key is not worth resuming — the code has expired anyway. */
const QR_TTL_MS = 3 * 60 * 1000

function fmtTime(ms: number | undefined): string {
  if (ms === undefined || !Number.isFinite(ms)) return ''
  const s = Math.floor(ms / 1000)
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`
}

export function NeteasePanel({ t, lyricPos, onLyricPos, mediaDisplay, onMediaDisplay, neteaseProxy, onNeteaseProxy, neteaseApiBase, onNeteaseApiBase, neteaseRealIp, onNeteaseRealIp }: NeteasePanelProps): JSX.Element {
  const [account, setAccount] = useState<NeteaseAccount | null | 'loading'>('loading')
  const [qrKey, setQrKey] = useState<string | null>(null)
  const [qrImg, setQrImg] = useState<string | null>(null)
  const [qrState, setQrState] = useState<string>('')
  const [polling, setPolling] = useState(false)
  const [playlists, setPlaylists] = useState<NeteasePlaylist[]>([])
  const [playlistId, setPlaylistId] = useState<number | null>(null)
  const [tracks, setTracks] = useState<NeteaseSong[]>([])
  const [daily, setDaily] = useState<NeteaseSong[] | null>(null)
  const [hotPlaylists, setHotPlaylists] = useState<NeteasePlaylist[]>([])
  const [hotTracks, setHotTracks] = useState<NeteaseSong[] | null>(null)
  const [searchQuery, setSearchQuery] = useState('')
  const [searchResults, setSearchResults] = useState<NeteaseSong[] | null>(null)
  const [busy, setBusy] = useState(false)
  const [cookieInput, setCookieInput] = useState('')
  const [toast, setToast] = useState<string | null>(null)
  const [diag, setDiag] = useState<NeteaseDiagnostics | null>(null)
  const [diagBusy, setDiagBusy] = useState(false)
  /** Last QR status code the poll saw, so a stalled login is visible. */
  const [qrLastCode, setQrLastCode] = useState<number | null>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const pollTimer = useRef<number | undefined>(undefined)
        const mountedRef = useRef(true)

  // current playback (for the small control row)
  const [playing, setPlaying] = useState(false)
  const [currentSongId, setCurrentSongId] = useState<number | null>(null)
        const [volume, setVolume] = useState(playback.getSnapshot().volume)
  useEffect(() => {
    const unsub = playback.subscribe(() => {
      const snap = playback.getSnapshot()
      setPlaying(snap.playing)
      setCurrentSongId(snap.song?.id ?? null)
                setVolume(snap.volume)
    })
    return unsub
  }, [])

  useEffect(() => {
    let cancelled = false
            mountedRef.current = true
    // hot playlists work without login (public API fallback)
    void fetchHotPlaylists().then((list) => {
      if (!cancelled) setHotPlaylists(list)
    }).catch(() => undefined)
    void getAccount().then((acc) => {
      if (cancelled) return
      setAccount(acc)
      if (acc.loggedIn && acc.uid !== undefined) {
        void fetchPlaylists(acc.uid).then((list) => {
          if (!cancelled) setPlaylists(list)
        })
      }
    })
    return () => {
                mountedRef.current = false
      cancelled = true
      if (pollTimer.current !== undefined) window.clearInterval(pollTimer.current)
    }
  }, [])

  function clearQrPoll(): void {
    if (pollTimer.current !== undefined) {
      window.clearTimeout(pollTimer.current)
      pollTimer.current = undefined
    }
    setPolling(false)
  }

  /** Remember the pending key so closing the settings panel does not lose the login. */
  function rememberQr(key: string): void {
    try {
      window.sessionStorage.setItem(QR_STORE, JSON.stringify({ key, at: Date.now() }))
    } catch {
      /* storage may be unavailable — the in-memory poll still runs */
    }
  }

  function forgetQr(): void {
    try {
      window.sessionStorage.removeItem(QR_STORE)
    } catch {
      /* ignore */
    }
  }

  /**
   * Draw the QR code once the canvas is actually in the document.
   *
   * The canvas only renders when `qrKey` is set, so drawing it from inside
   * startQrLogin() read `canvasRef.current === null` (state updates are not
   * flushed mid-handler) and the login box stayed blank forever. Keyed on the
   * key so a regenerated code is redrawn too, and skipped when the server
   * already returned a ready-made image.
   */
  useEffect(() => {
    const canvas = canvasRef.current
    if (canvas === null || qrKey === null || qrImg !== null) return
    let cancelled = false
    void QRCode
      .toCanvas(canvas, `https://music.163.com/login?codekey=${qrKey}`, { width: 168, margin: 1 })
      .catch((error: unknown) => {
        if (!cancelled && mountedRef.current) {
          setToast(t('lyricQrFail', { error: error instanceof Error ? error.message : String(error) }))
        }
      })
    return () => {
      cancelled = true
    }
  }, [qrKey, qrImg, t])

  /**
   * Resume a pending QR login after the panel was closed and reopened: the poll
   * lives in this component, so an unmount used to abandon a code the user had
   * already scanned.
   */
  useEffect(() => {
    let raw: string | null = null
    try {
      raw = window.sessionStorage.getItem(QR_STORE)
    } catch {
      return
    }
    if (raw === null) return
    try {
      const parsed = JSON.parse(raw) as { key?: unknown; at?: unknown }
      if (typeof parsed.key !== 'string' || parsed.key === '' || typeof parsed.at !== 'number') return
      if (Date.now() - parsed.at > QR_TTL_MS) {
        forgetQr()
        return
      }
      setQrKey(parsed.key)
      setQrState(t('lyricQrScan'))
      scheduleQrPoll(parsed.key)
    } catch {
      /* malformed state — nothing to resume */
    }
    // deliberately once per mount: later changes are driven by the poll itself
  }, [])

  async function fetchAccountAfterLogin(): Promise<NeteaseAccount> {
    // The session cookie may need a moment to propagate on the remote API side.
    for (let i = 0; i < 5; i++) {
      const acc = await getAccount()
      if (acc.loggedIn && acc.uid !== undefined) return acc
      await new Promise((resolve) => setTimeout(resolve, 500))
    }
    return getAccount()
  }

  /**
   * Apply one poll answer. Shared by the timer and the manual check so both
   * paths land the login identically.
   */
  async function applyQrStatus(key: string, status: QrStatus): Promise<void> {
    if (!mountedRef.current) return
    setQrLastCode(status.code)
    if (status.code === 803) {
      clearQrPoll()
      forgetQr()
      setQrKey(null)
      setAccount({ loggedIn: true, nickname: status.nickname })
      setToast(t('lyricLoginOk', { name: status.nickname ?? '' }))
      // Confirm the stored session and pick up the uid so playlists can load;
      // the optimistic account above keeps the UI signed in either way.
      const fresh = await fetchAccountAfterLogin()
      if (!mountedRef.current) return
      if (fresh.loggedIn) {
        setAccount(fresh)
        if (fresh.uid !== undefined) {
          void fetchPlaylists(fresh.uid).then((list) => {
            if (mountedRef.current) setPlaylists(list)
          })
        }
      }
      return
    }
    if (status.code === 802) {
      setQrState(t('lyricQrConfirm'))
      scheduleQrPoll(key)
      return
    }
    if (status.code === 800) {
      clearQrPoll()
      forgetQr()
      setQrState(t('lyricQrExpired'))
      return
    }
    scheduleQrPoll(key)
  }

  function scheduleQrPoll(key: string): void {
    if (!mountedRef.current) return
    if (pollTimer.current !== undefined) window.clearTimeout(pollTimer.current)
    setPolling(true)
    pollTimer.current = window.setTimeout(() => {
      pollTimer.current = undefined
      void (async () => {
        if (!mountedRef.current) return
        try {
          await applyQrStatus(key, await pollQrLogin(key))
        } catch {
          if (mountedRef.current) scheduleQrPoll(key)
        }
      })()
    }, 2000)
  }

  /**
   * Check the login on demand.
   *
   * Polling lives in this component, so closing the settings panel — or letting
   * the code expire — used to end it silently, and a scan confirmed afterwards
   * was never noticed. This re-asks both the pending code and the session.
   */
  async function checkLogin(): Promise<void> {
    setBusy(true)
    try {
      if (qrKey !== null) {
        try {
          await applyQrStatus(qrKey, await pollQrLogin(qrKey))
          if (account !== null && account !== 'loading' && account.loggedIn) return
        } catch {
          /* fall through to the session check */
        }
      }
      if (!mountedRef.current) return
      const acc = await getAccount()
      if (!mountedRef.current) return
      if (acc.loggedIn) {
        setAccount(acc)
        setToast(t('lyricLoginOk', { name: acc.nickname ?? '' }))
        if (acc.uid !== undefined) {
          void fetchPlaylists(acc.uid).then((list) => {
            if (mountedRef.current) setPlaylists(list)
          })
        }
      } else {
        setToast(acc.reason === 'risk'
          ? t('lyricRiskHint', { code: acc.code ?? '?' })
          : t('lyricCheckLoginFail'))
      }
    } finally {
      if (mountedRef.current) setBusy(false)
    }
  }

  async function startQrLogin(): Promise<void> {
    clearQrPoll()
    setQrKey(null)
    setQrImg(null)
      // Start from a clean cookie state so a stale/partial session cannot break
      // the new QR login.
      await logout().catch(() => undefined)
    setBusy(true)
    setQrState(t('lyricQrLoading'))
    try {
      const { key, qrimg } = await requestQrKey()
      if (!mountedRef.current) return
      setQrKey(key)
      setQrImg(qrimg ?? null)
      rememberQr(key)
      // the canvas draw happens in the effect above, once the box is mounted
      if (!mountedRef.current) return
      setQrState(t('lyricQrScan'))
      scheduleQrPoll(key)
    } catch (err) {
      if (mountedRef.current) {
        setToast(t('lyricQrFail', { error: err instanceof Error ? err.message : String(err) }))
      }
    } finally {
      if (mountedRef.current) setBusy(false)
    }
  }

  /*

  async function startQrLoginLegacy(): Promise<void> {
    try {
      setBusy(true)
      setQrState(t('lyricQrLoading'))
      const { key, qrimg } = await requestQrKey()
      setQrKey(key)
      setQrImg(qrimg ?? null)
      if (qrimg === undefined || qrimg === '') {
        // remote server gave no image — render locally as fallback
        const canvas = canvasRef.current
        if (canvas !== null) {
          await QRCode.toCanvas(canvas, `https://music.163.com/login?codekey=${key}`, {
            width: 168,
            margin: 1,
          })
        }
      }
      setQrState(t('lyricQrScan'))
      setPolling(true)
      if (pollTimer.current !== undefined) window.clearInterval(pollTimer.current)
      pollTimer.current = window.setInterval(async () => {
        try {
          const status = await pollQrLogin(key)
          if (status.code === 803) {
            if (pollTimer.current !== undefined) window.clearInterval(pollTimer.current)
            setPolling(false)
            setQrKey(null)
            const acc: NeteaseAccount = {
              loggedIn: true,
              nickname: status.nickname,
            }
            setAccount(acc)
            setToast(t('lyricLoginOk', { name: status.nickname ?? '' }))
            if (acc.uid === undefined) {
              const fresh = await fetchAccountAfterLogin().catch(() => null).catch(() => null)
              if (fresh !== null) setAccount(fresh.loggedIn ? fresh : acc)
              if (fresh.uid !== undefined) {
                void fetchPlaylists(fresh.uid).then(setPlaylists)
              }
            }
          } else if (status.code === 802) {
            setQrState(t('lyricQrConfirm'))
          } else if (status.code === 800) {
            setQrState(t('lyricQrExpired'))
            setPolling(false)
            if (pollTimer.current !== undefined) window.clearInterval(pollTimer.current)
          }
        } catch {
          // keep polling
        }
      }, 2000)
    } catch (err) {
      setToast(t('lyricQrFail', { error: err instanceof Error ? err.message : String(err) }))
    } finally {
      setBusy(false)
    }
  }
  */

  function cancelQr(): void {
    clearQrPoll()
    forgetQr()
    setQrKey(null)
    setQrImg(null)
    setQrLastCode(null)
  }

  /*
  function cancelQrLegacy(): void {
    if (pollTimer.current !== undefined) window.clearInterval(pollTimer.current)
    setPolling(false)
    setQrKey(null)
  }
  */

  async function doCookieLogin(): Promise<void> {
    // tolerate multi-line pastes and missing '=' separators (normalize repairs)
    const cookie = normalizeCookiePaste(cookieInput)
    if (cookie === '') {
      // e.g. only the value cell was copied: there is no name to pair it with
      setToast(t('lyricCookieUnparsed'))
      return
    }
    // MUSIC_U is HttpOnly, so `document.cookie` can never contain it; catching
    // that here beats sending a session-less string upstream and calling the
    // answer "cookie rejected".
    if (!hasSessionCookie(cookie)) {
      setToast(t('lyricCookieNoSession'))
      return
    }
    setBusy(true)
    try {
      const result = await submitCookie(cookie)
      if (result.ok) {
        const acc: NeteaseAccount = { loggedIn: true, nickname: result.nickname, uid: result.uid }
        setAccount(acc)
        setCookieInput('')
        setToast(t('lyricLoginOk', { name: result.nickname ?? '' }))
        if (acc.uid !== undefined) {
          void fetchPlaylists(acc.uid).then(setPlaylists)
        }
      } else if (result.reason === 'no-session') {
        setToast(t('lyricCookieNoSession'))
      } else if (result.reason === 'risk') {
        // The check itself was challenged — the cookie may well be valid, so say
        // what happened instead of claiming the cookie is bad.
        setToast(t('lyricRiskHint', { code: result.code ?? '?' }))
      } else {
        setToast(t('lyricCookieRejected'))
      }
    } catch (err) {
      setToast(t('lyricCookieFail', { error: err instanceof Error ? err.message : String(err) }))
    } finally {
      setBusy(false)
    }
  }

  /** Ask the host what the upstream actually answered (risk control vs dead cookie vs network). */
  async function runDiagnostics(): Promise<void> {
    setDiagBusy(true)
    try {
      setDiag(await getDiagnostics())
    } catch (err) {
      setToast(t('lyricDiagFail', { error: err instanceof Error ? err.message : String(err) }))
    } finally {
      setDiagBusy(false)
    }
  }

  async function doLogout(): Promise<void> {
    await logout()
    setAccount({ loggedIn: false })
    setPlaylists([])
    setTracks([])
    setDaily(null)
  }

  async function openPlaylist(id: number): Promise<void> {
    setPlaylistId(id)
    setDaily(null)
    setBusy(true)
    try {
      setTracks(await fetchPlaylistTracks(id))
    } catch (err) {
      setToast(t('lyricListFail', { error: err instanceof Error ? err.message : String(err) }))
    } finally {
      setBusy(false)
    }
  }

  async function openDaily(): Promise<void> {
    setDaily(null)
    setPlaylistId(null)
    setHotTracks(null)
    setSearchResults(null)
    setBusy(true)
    try {
      setDaily(await fetchDailySongs())
    } catch (err) {
      setToast(t('lyricListFail', { error: err instanceof Error ? err.message : String(err) }))
    } finally {
      setBusy(false)
    }
  }

  async function openHotPlaylist(id: number): Promise<void> {
    setHotTracks(null)
    setDaily(null)
    setPlaylistId(null)
    setSearchResults(null)
    setBusy(true)
    try {
      setHotTracks(await fetchPlaylistTracks(id))
    } catch (err) {
      setToast(t('lyricListFail', { error: err instanceof Error ? err.message : String(err) }))
    } finally {
      setBusy(false)
    }
  }

  async function doSearch(): Promise<void> {
    const q = searchQuery.trim()
    if (q === '') return
    setSearchResults(null)
    setDaily(null)
    setPlaylistId(null)
    setHotTracks(null)
    setBusy(true)
    try {
      setSearchResults(await searchSongs(q))
    } catch (err) {
      setToast(t('lyricListFail', { error: err instanceof Error ? err.message : String(err) }))
    } finally {
      setBusy(false)
    }
  }

  function playSong(song: NeteaseSong, queue?: NeteaseSong[]): void {
    void playback.play(song, queue)
  }

  const songList = searchResults ?? hotTracks ?? daily ?? tracks

  return (
    <section className={styles.card}>
      <h3 className={styles.cardTitle}>{t('lyricTitle')}</h3>

      {/* ---- proxy (VPN) for NetEase requests ---- */}
      <div className={styles.row}>
        <span className={styles.fieldLabel}>{t('lyricProxyLabel')}</span>
        <Input
          className={styles.grow}
          value={neteaseProxy}
          onChange={(e) => onNeteaseProxy(e.target.value.trim())}
        />
      </div>

      <div className={styles.row}>
        <span className={styles.fieldLabel}>{t('lyricApiLabel')}</span>
        <Input
          className={styles.grow}
          value={neteaseApiBase}
          onChange={(e) => onNeteaseApiBase(e.target.value.trim())}
        />
      </div>

      {/* risk control: NetEase decides on the source address before the payload */}
      <div className={styles.row}>
        <span className={styles.fieldLabel}>{t('lyricRealIpLabel')}</span>
        <Input
          className={styles.grow}
          value={neteaseRealIp}
          onChange={(e) => onNeteaseRealIp(e.target.value.trim())}
        />
      </div>

      <div className={styles.row}>
        <Button size="sm" variant="outline" disabled={diagBusy} onClick={() => void runDiagnostics()}>
          {diagBusy ? t('lyricDiagRunning') : t('lyricDiagButton')}
        </Button>
      </div>
      <p className={styles.hint}>{t('lyricRealIpHint')}</p>
      {diag !== null ? (
        <pre className={styles.diagBox}>{JSON.stringify(diag, null, 2)}</pre>
      ) : null}

      <div className={styles.row}>
        <span className={styles.fieldLabel}>{t('lyricPosLabel')}</span>
        <div className={styles.pills}>
          {LYRIC_POSITIONS.map((pos) => (
            <Pill
              key={pos.id}
              active={lyricPos === pos.id}
              onClick={() => onLyricPos(pos.id)}
            >
              {t(pos.labelKey)}
            </Pill>
          ))}
        </div>
      </div>

        <div className={styles.row}>
          <span className={styles.fieldLabel}>{t('mediaDisplayLabel')}</span>
          <div className={styles.pills}>
            <Pill
              active={mediaDisplay}
              onClick={() => onMediaDisplay(true)}
            >
              {t('mediaDisplayOn')}
            </Pill>
            <Pill
              active={!mediaDisplay}
              onClick={() => onMediaDisplay(false)}
            >
              {t('mediaDisplayOff')}
            </Pill>
          </div>
        </div>

      {/* ---- login / account ---- */}
      {account === 'loading' ? (
        <p className={styles.hint}>{t('lyricLoading')}</p>
      ) : account === null || !account.loggedIn ? (
        <div className={styles.loginBox}>
          {qrKey === null ? (
            <div className={styles.pills}>
              <Button variant="outline" disabled={busy} onClick={() => void startQrLogin()}>
                {t('lyricQrLogin')}
              </Button>
              <Button size="sm" variant="ghost" disabled={busy} onClick={() => void checkLogin()}>
                {t('lyricCheckLogin')}
              </Button>
            </div>
          ) : (
            <div className={styles.qrBox}>
              {qrImg !== null ? (
                // a broken data URL from a remote server must not leave a blank
                // box: fall back to the locally rendered canvas
                <img
                  src={qrImg}
                  width={168}
                  height={168}
                  alt="QR"
                  onError={() => setQrImg(null)}
                />
              ) : (
                <canvas ref={canvasRef} width={168} height={168} />
              )}
              <p className={styles.qrState}>{qrState}</p>
              {qrLastCode !== null ? (
                <p className={styles.qrState}>{t('lyricQrLastCode', { code: qrLastCode })}</p>
              ) : null}
              <div className={styles.pills}>
                <Button size="sm" variant="outline" disabled={busy} onClick={() => void checkLogin()}>
                  {t('lyricCheckLogin')}
                </Button>
                {polling ? (
                  <Button size="sm" variant="ghost" onClick={cancelQr}>
                    {t('lyricQrCancel')}
                  </Button>
                ) : null}
              </div>
            </div>
          )}

          <div className={styles.row}>
            <Input
              className={styles.grow}
              placeholder={t('lyricCookiePh')}
              value={cookieInput}
              onChange={(e) => setCookieInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') void doCookieLogin()
              }}
            />
            <Button
              size="sm"
              variant="outline"
              disabled={busy || cookieInput.trim() === ''}
              onClick={() => void doCookieLogin()}
            >
              {t('lyricCookieLogin')}
            </Button>
          </div>
        </div>
      ) : (
        <div className={styles.row}>
          <span className={styles.account}>
            {t('lyricLoggedIn', { name: account.nickname ?? '' })}
          </span>
          <Button size="sm" variant="ghost" onClick={() => void doLogout()}>
            {t('lyricLogout')}
          </Button>
        </div>
      )}

      {/* ---- browse: my playlists (logged in) / hot playlists + search ---- */}
      {account !== 'loading' && (
        <div className={styles.field}>
          <div className={styles.row}>
            {account !== null && account.loggedIn ? (
              <>
                <select
                  className={styles.select}
                  value={playlistId ?? ''}
                  onChange={(e) => {
                    const id = Number(e.target.value)
                    if (id > 0) void openPlaylist(id)
                  }}
                >
                  <option value="">{t('lyricPlaylists')}</option>
                  {playlists.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.name}（{p.trackCount}）
                    </option>
                  ))}
                </select>
                <Button size="sm" variant="outline" disabled={busy} onClick={() => void openDaily()}>
                  {t('lyricDaily')}
                </Button>
              </>
            ) : (
              <select
                className={styles.select}
                value=""
                onChange={(e) => {
                  const id = Number(e.target.value)
                  if (id > 0) void openHotPlaylist(id)
                }}
              >
                <option value="">{t('lyricHot')}</option>
                {hotPlaylists.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name}（{p.trackCount}）
                  </option>
                ))}
              </select>
            )}
            <Input
              className={styles.grow}
              placeholder={t('lyricSearchPh')}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') void doSearch()
              }}
            />
            <Button size="sm" variant="outline" disabled={busy} onClick={() => void doSearch()}>
              {t('lyricSearch')}
            </Button>
          </div>

          {busy && <p className={styles.hint}>{t('lyricLoading')}</p>}

          {!busy && songList !== null && songList.length > 0 && (
            <>
              <div className={styles.row}>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => void playback.play(songList[0]!, songList)}
                >
                  {t('lyricPlayAll')}
                </Button>
              </div>
              <ul className={styles.songList}>
                {songList.map((song) => (
                  <li key={song.id} className={styles.songRow}>
                    <button
                      type="button"
                      className={`${styles.songName}${currentSongId === song.id ? ` ${styles.songActive}` : ''}`}
                      onClick={() => playSong(song, songList)}
                      title={song.album ?? ''}
                    >
                      <span className={styles.songTitle}>{song.name}</span>
                      <span className={styles.songMeta}>
                        {song.artists}
                        {fmtTime(song.durationMs) !== '' && ` · ${fmtTime(song.durationMs)}`}
                      </span>
                    </button>
                  </li>
                ))}
              </ul>
            </>
          )}
        </div>
      )}

      {/* ---- playback control ---- */}
      <div className={styles.row}>
          <Button
            size="sm"
            variant="ghost"
            disabled={playback.getSnapshot().song === null || playback.getSnapshot().queueIndex <= 0}
            onClick={() => playback.previous()}
            title={t('prevTrack')}
              aria-label={t('prevTrack')}
          >
            ⏮
          </Button>
          <Button
            size="sm"
            variant="ghost"
            disabled={playback.getSnapshot().song === null || playback.getSnapshot().queueIndex < 0 || playback.getSnapshot().queueIndex >= playback.getSnapshot().queue.length - 1}
            onClick={() => playback.next()}
            title={t('nextTrack')}
              aria-label={t('nextTrack')}
          >
            ⏭
          </Button>
        <Button
          size="sm"
          variant="outline"
          disabled={!playing && playback.getSnapshot().song === null}
          onClick={() => playback.toggle()}
        >
          {playing ? t('lyricPause') : t('lyricPlay')}
        </Button>
        <Button
          size="sm"
          variant="ghost"
          disabled={playback.getSnapshot().song === null}
          onClick={() => playback.stop()}
        >
          {t('lyricStop')}
        </Button>
          <label className={styles.volume}>
            <span>{t('volumeLabel')}</span>
            <input
              type="range"
              min={0}
              max={1}
              step={0.05}
              value={volume}
              onChange={(e) => playback.setVolume(Number(e.target.value))}
              aria-label={t('volumeLabel')}
            />
          </label>
        <span className={styles.nowPlaying}>
          {playback.getSnapshot().song !== null
            ? `${playback.getSnapshot().song!.name} - ${playback.getSnapshot().song!.artists}`
            : t('lyricNone')}
        </span>
      </div>

      {toast !== null && <Toast text={toast} onDone={() => setToast(null)} />}
    </section>
  )
}
