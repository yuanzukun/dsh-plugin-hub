// annotation-for-dsh 的浏览器端 half（client bundle）。
//
// 手写 CJS + ModuleLoader 包装（同 omdsh-dev navbar/greeter 模式，零构建
// 步骤）：纯 DOM 自渲染，无任何 @deepseek-ai 值导入（bundle purity gate 合规）；
// cordis 服务经 exports.inject 的字符串名接入（sessions / conversation / locale）。
//
// v1.4.x · 自包含引用流（取代 v0.9 chip 设计与 v1.0 发送面板）：
//   1. 选中助手文字 → 工具条「引用」→ 写引用（可留空 = 仅标记原文）
//   2. 保存后原文亮蓝编号 + 高亮（纯视觉，不弹窗）；跨消息/跨回合连续累积
//   3. 输入框旁「引用 ×N」标签：悬浮可见全部内容、可逐条删除
//   4. 回车发送：capture 阶段拦截 Enter（IME 守卫对齐官方 InputBar：isComposing /
//      keyCode 229 + compositionend 后短延迟 latch）→ 引用块 prepend 进草稿
//      （setDraft，不覆盖用户文字）→ composer 正常提交；Cmd/Ctrl+Enter（含运行中
//      插队）同样拼稿，仅「纯引用空草稿」由插件接管直发
//   5. 用户气泡不显示引用块：MutationObserver 微任务阶段（绘制前）按最后一个
//      「提问：」切掉引用块、贴「引用 ×N」标签（hover 可见）；1s 轮询兜底 +
//      历史消息自动修复（用户气泡是 MessageText 单文本节点，非 markdown）
//   6. 回复逐条对照：引用块末尾注入格式指令，模型按「Annotation N：…」逐条
//      回应；回复渲染完成（data-streaming 移除）后把「Annotation N：」替换为
//      可悬浮芯片（数据取最近一条带标签用户消息的 tag.__annotationItems，刷新
//      自动重建；改 DOM 前先快照 TreeWalker 收集的文本节点再逐个替换，遍历
//      中途 replaceChild 会让 walker 指针失效）
//   7. 语言跟随 DSH locale 服务（v1.4）：UI 文案与协议块 zh/en 双语、实时切换，
//      隐藏手术与反解析同时兼容「提问：」/「Ask:」与「问题：」老格式
//
// 消息格式（zh）：我引用了以下 N 处内容…\n\n1. 原文\n   引用：…\n\n
//           请用「Annotation 1：…」…\n\n提问：
// （en 用 I annotated the following N passage(s)… + Note: … + Ask:；
//   zh 分隔标记用「提问：」而非「问题：」——标题行「回答我的问题：」里也含
//   它，气泡隐藏手术会误命中）
//
// 发送清空只认 watchInputDraft 的「草稿有→空」迁移（未就绪时订阅重试补齐）；
// 气泡装饰走 MutationObserver + 轮询，只负责隐藏/贴标签，绝不清空待发送引用
// （历史消息重装饰与刚发送在 DOM 上不可区分，见 decorateAll）。
//
// 判别式与 omdsh-dev/navbar 一致：助手行 = [data-time-hover-root] 且不含
// user bubble（[class*="bubble"]）。
// focus-chat（@dingyi222666/dsh-focus-chat）兼容：其会话视图挂载在
// [data-focus-flow] 内，助手行 = class 含 "assistant" 的容器（CSS Modules
// 哈希名形如 `<hash>_assistant`，流式期间行自带 data-streaming），用户行
// 沿用 data-time-hover-root；切换视图 tab 时主视图会卸载，故行判别必须
// 同时覆盖两种视图结构（见 assistantRows / allMessageRows / assistantRowOf）。
window.__ModuleLoader__.load({
  // 必须与 package.json "name" 完全一致，否则 client-modules 报：
  // bundle loaded without registering "@dsh-external/dsh-annotation-patched"
  id: '@dsh-external/dsh-annotation-patched',
  factory: (require) => {
    'use strict'
    var module = { exports: {} }
    var exports = module.exports

    // ============================== 样式 ==============================
    var STYLE_ID = 'annotation-for-dsh-style'
    if (document.getElementById(STYLE_ID) === null) {
      var style = document.createElement('style')
      style.id = STYLE_ID
      style.textContent = [
        '[data-annotation-for-dsh] { all: initial; }',
        '[data-annotation-for-dsh] * { box-sizing: border-box; }',
        '.dsh-ann-bar { position: fixed; z-index: 1200; display: flex; align-items: center;',
        '  gap: 2px; padding: 4px; border-radius: 12px;',
        '  border: 1px solid var(--dsw-alias-border-inverted);',
        '  background: var(--dsw-specific-menu, #2c2c2e);',
        '  box-shadow: var(--dsw-shadow-lv3);',
        '  font-family: var(--dsw-font-family, system-ui);',
        '  animation: dsh-ann-pop .12s var(--ds-ease-in-out, ease); }',
        '@keyframes dsh-ann-pop { from { opacity: 0; transform: translateY(3px); }',
        '  to { opacity: 1; transform: none; } }',
        '.dsh-ann-ghost { display: inline-flex; align-items: center; gap: 5px; height: 28px;',
        '  padding: 0 10px; border: none; border-radius: 14px; background: transparent;',
        '  color: var(--dsw-alias-label-primary); font-family: inherit;',
        '  font-size: 12px; line-height: 18px; cursor: pointer; }',
        '.dsh-ann-ghost:hover:not(:disabled) { background: var(--dsw-alias-interactive-bg-hover); }',
        '.dsh-ann-ghost:disabled { opacity: .45; cursor: default; }',
        '.dsh-ann-ghost svg { width: 14px; height: 14px; }',
        '.dsh-ann-action { display: inline-flex; align-items: center; gap: 5px; height: 28px;',
        '  padding: 0 12px; border: none; border-radius: 14px;',
        '  background: var(--dsw-alias-button-primary-fill);',
        '  color: var(--dsw-alias-label-primary-foreground);',
        '  font-family: inherit; font-size: 12px; line-height: 18px; cursor: pointer; }',
        '.dsh-ann-action:hover:not(:disabled) { background: var(--dsw-alias-button-primary-hover); }',
        '.dsh-ann-action:disabled { opacity: .4; cursor: default; }',
        '.dsh-ann-action svg { width: 14px; height: 14px; }',
        '.dsh-ann-icon { display: inline-flex; align-items: center; justify-content: center;',
        '  width: 28px; height: 28px; padding: 0; border: none; border-radius: 28px;',
        '  background: transparent; color: var(--dsw-alias-label-tertiary); cursor: pointer; }',
        '.dsh-ann-icon:hover { background: var(--dsw-alias-interactive-bg-hover);',
        '  color: var(--dsw-alias-label-secondary); }',
        '.dsh-ann-icon svg { width: 14px; height: 14px; }',
        '.dsh-ann-card { position: fixed; z-index: 1201; width: 400px;',
        '  max-width: calc(100vw - 16px); padding: 12px; border-radius: 12px;',
        '  border: 1px solid var(--dsw-alias-border-inverted);',
        '  background: var(--dsw-specific-menu, #2c2c2e);',
        '  box-shadow: var(--dsw-shadow-lv3);',
        '  font-family: var(--dsw-font-family, system-ui);',
        '  animation: dsh-ann-pop .12s var(--ds-ease-in-out, ease); }',
        '.dsh-ann-card-head { display: flex; align-items: center; justify-content: space-between;',
        '  margin-bottom: 8px; cursor: move; touch-action: none; user-select: none; }',
        '.dsh-ann-card-title { font-size: 13px; font-weight: 600;',
        '  color: var(--dsw-alias-label-primary); }',
        '.dsh-ann-quote { font-size: 12px; line-height: 1.55;',
        '  color: var(--dsw-alias-label-tertiary);',
        '  border-left: 2px solid var(--dsw-alias-border-inverted);',
        '  background: var(--dsw-alias-bg-layer-1);',
        '  border-radius: 0 8px 8px 0; padding: 6px 10px; margin-bottom: 8px;',
        '  max-height: 72px; overflow: hidden; word-break: break-word;',
        '  display: -webkit-box; -webkit-line-clamp: 3; -webkit-box-orient: vertical; }',
        '.dsh-ann-quotes { display: flex; flex-direction: column; gap: 4px; margin-bottom: 10px;',
        '  max-height: 150px; overflow-y: auto; }',
        '.dsh-ann-qitem { display: flex; align-items: flex-start; gap: 8px; padding: 6px 8px;',
        '  border-radius: 8px; background: var(--dsw-alias-bg-layer-1); }',
        '.dsh-ann-qnum { flex: none; display: inline-flex; align-items: center; justify-content: center;',
        '  width: 16px; height: 16px; margin-top: 1px; border-radius: 8px;',
        '  background: var(--dsw-alias-text-accent, #4c9aff); color: #fff;',
        '  font-size: 10px; font-weight: 700; }',
        '.dsh-ann-qbody { flex: 1; min-width: 0; }',
        '.dsh-ann-qtext { font-size: 12px; line-height: 1.5;',
        '  color: var(--dsw-alias-label-tertiary); max-height: 36px; overflow: hidden;',
        '  word-break: break-word; display: -webkit-box; -webkit-line-clamp: 2;',
        '  -webkit-box-orient: vertical; }',
        '.dsh-ann-qnote { font-size: 11px; line-height: 1.5; margin-top: 2px;',
        '  color: var(--dsw-alias-label-secondary); max-height: 34px; overflow: hidden;',
        '  word-break: break-word; white-space: pre-wrap; display: -webkit-box;',
        '  -webkit-line-clamp: 2; -webkit-box-orient: vertical; }',
        '.dsh-ann-qdel { flex: none; display: inline-flex; align-items: center; justify-content: center;',
        '  width: 18px; height: 18px; padding: 0; border: none; border-radius: 9px;',
        '  background: transparent; color: var(--dsw-alias-label-tertiary); cursor: pointer; }',
        '.dsh-ann-qdel:hover { background: var(--dsw-alias-interactive-bg-hover);',
        '  color: var(--dsw-alias-label-secondary); }',
        '.dsh-ann-qdel svg { width: 10px; height: 10px; }',
        '.dsh-ann-input { width: 100%; min-height: 64px; padding: 8px 10px;',
        '  border: 1px solid var(--dsw-alias-border-l2); border-radius: 8px;',
        '  background: var(--dsw-alias-bg-layer-1); color: var(--dsw-alias-label-primary);',
        '  font-family: inherit; font-size: 13px; line-height: 20px;',
        '  outline: none; resize: vertical; transition: border-color .15s ease; }',
        '.dsh-ann-input:focus { border-color: var(--dsw-alias-text-accent, #4c9aff); }',
        '.dsh-ann-input::placeholder { color: var(--dsw-alias-label-dimmed); }',
        '.dsh-ann-row { display: flex; gap: 8px; margin-top: 10px; justify-content: flex-end; }',
        '.dsh-ann-cancel { display: inline-flex; align-items: center; height: 28px; padding: 0 12px;',
        '  border: 1px solid var(--dsw-alias-border-l2); border-radius: 14px;',
        '  background: transparent; color: var(--dsw-alias-label-primary);',
        '  font-family: inherit; font-size: 12px; cursor: pointer; }',
        '.dsh-ann-cancel:hover { background: var(--dsw-alias-interactive-bg-hover); }',
        '.dsh-ann-error { color: var(--dsw-alias-state-error-primary, #ff7a7a);',
        '  font-size: 12px; margin-top: 8px; word-break: break-word; }',
        // PATCH(2026-08-14e): 高亮/编号盖输入栏的根因是 buildMarkers 把滚动后
        // 进入 composer 区域的 rect 也渲染成了 fixed 层——正解是「区域过滤」
        // （buildMarkers 跳过与输入栏重叠的 rect），而非压 z-index（压太低会被
        // 对话区元素盖住，chip 点不开、取消/删除失效）。z-index 恢复 900/940。
        '.dsh-ann-hl { position: fixed; z-index: 900; background: rgba(255, 195, 0, .15);',
        '  border-radius: 2px; pointer-events: none; animation: dsh-ann-fadein .15s ease; }',
        '.dsh-ann-num { position: fixed; z-index: 940; display: inline-flex; align-items: center;',
        '  justify-content: center; min-width: 16px; height: 16px; padding: 0 4px;',
        '  border-radius: 8px; border: 1px solid rgba(255, 255, 255, .3);',
        '  background: var(--dsw-alias-text-accent, #4c9aff); color: #fff;',
        '  font-family: var(--dsw-font-family, system-ui); font-size: 10px; font-weight: 700;',
        '  box-shadow: 0 1px 4px rgba(0,0,0,.35); pointer-events: auto; cursor: pointer;',
        '  transition: filter .12s ease; }',
        '.dsh-ann-num:hover { filter: brightness(1.15); }',
        'body:has([role="dialog"][aria-modal="true"]) [data-annotation-overlay] { display: none; }',
        '.dsh-ann-tip { animation: dsh-ann-pop .12s var(--ds-ease-in-out, ease); }',
        '@keyframes dsh-ann-fadein { from { opacity: 0; } to { opacity: 1; } }',
      ].join('\n')
      document.head.appendChild(style)
    }

    // ============================== i18n（zh / en） ==============================
    // UI 文案与引用协议块双语化：当前语言由 DSH 的 locale 服务驱动
    // （ctx.locale.getSnapshot().active + subscribe()），服务缺失时回退 zh。
    // 历史消息的隐藏手术与反解析同时兼容 zh/en 标记，跨语言切换不丢引用。
    var STR = {
      zh: {
        actions: {
          annotate: '引用',
          already: '已引用',
          annotateTitle: '为选中的内容写一条引用（可留空 = 仅引用原文）',
          alreadyTitle: '这段内容已在引用清单中',
        },
        edit: {
          addTitle: '添加引用',
          editTitle: '编辑引用',
          placeholder: '写下引用…（可留空，保存后仅标记原文）',
          save: '保存引用',
          delete: '删除引用',
        },
        common: { cancel: '取消' },
        error: { noSelection: '没有选中的内容' },
        chip: { count: '条引用' },
        tip: { title: '引用（{n} 条）', notePrefix: '引用：', del: '删' },
        bubble: { tag: '引用 ×{n}', title: '本消息携带引用（{n} 条）' },
        reply: {
          headWithQuote: '引用 {n} 的原文',
          headNoQuote: '引用 {n}',
          notePrefix: '你的引用：',
          missing: '（未找到对应引用条目）',
        },
        toast: {
          attachFail: '引用拼稿失败，消息将不带引用发送：',
          skipCommand: '本条是斜杠命令，未拼入引用；引用已保留，将随下一条消息发送',
        },
        block: {
          head: '我引用了以下 {n} 处内容（编号与原文对应），请针对它们回答我的问题：',
          notePrefix: '引用：',
          format: '请用「Annotation 1：…」到「Annotation {n}：…」的格式，逐条回应上面每一条引用，最后再回答我的问题。',
          headOnly: '我引用了以下内容，请逐条回应：',
          formatOnly: '请按「Annotation N：…」的格式，逐条回应以上引用。',
          marker: '提问：',
        },
      },
      en: {
        actions: {
          annotate: 'Annotate',
          already: 'Annotated',
          annotateTitle: 'Write a note about the selected text (leave empty to quote without a note)',
          alreadyTitle: 'This passage is already in your annotation list',
        },
        edit: {
          addTitle: 'Add annotation',
          editTitle: 'Edit annotation',
          placeholder: 'Write a note… (optional; saving only marks the passage)',
          save: 'Save annotation',
          delete: 'Delete annotation',
        },
        common: { cancel: 'Cancel' },
        error: { noSelection: 'No text selected' },
        chip: { count: ' annotation(s)' },
        tip: { title: 'Annotations ({n})', notePrefix: 'Note: ', del: 'Del' },
        bubble: { tag: 'Annotations ×{n}', title: 'This message carries {n} annotation(s)' },
        reply: {
          headWithQuote: 'Source of annotation {n}',
          headNoQuote: 'Annotation {n}',
          notePrefix: 'Your note: ',
          missing: '(no matching annotation found)',
        },
        toast: {
          attachFail: 'Failed to attach annotations; the message will be sent without them: ',
          skipCommand: 'Slash command detected — annotations stay pending and will attach to your next message',
        },
        block: {
          head: 'I annotated the following {n} passage(s) (the numbers match the quotes below); please respond to them when answering my question:',
          notePrefix: 'Note: ',
          format: 'Please respond to each annotation in the format "Annotation 1: …" through "Annotation {n}: …", then answer my question.',
          headOnly: 'I annotated the following passages; please respond to each annotation:',
          formatOnly: 'Please respond to each annotation above in the format "Annotation N: …".',
          marker: 'Ask:',
        },
      },
    }
    var currentLang = 'zh'
    function setLang(id) {
      currentLang = (id === 'en' || id === 'zh') ? id : 'zh'
    }
    function dictVal(lang, key) {
      var cur = STR[lang]
      var parts = key.split('.')
      for (var i = 0; i < parts.length; i++) {
        if (cur === undefined || cur === null) return undefined
        cur = cur[parts[i]]
      }
      return cur
    }
    /** @param {string} key @param {Object<string, string|number>} [params] */
    function t(key, params) {
      var s = dictVal(currentLang, key)
      if (s === undefined) s = dictVal('zh', key)
      if (s === undefined) s = key
      if (params !== undefined && params !== null) {
        for (var k in params) {
          if (Object.prototype.hasOwnProperty.call(params, k)) {
            s = s.split('{' + k + '}').join(String(params[k]))
          }
        }
      }
      return s
    }
    // 引用块头部哨兵（zh/en 都识别；兼容历史消息与跨语言切换）。
    var BLOCK_HEADS = { zh: '我引用了以下', en: 'I annotated the following' }
    function hasAnnotationBlock(text) {
      return text.indexOf(BLOCK_HEADS.zh) !== -1 || text.indexOf(BLOCK_HEADS.en) !== -1
    }
    // 气泡隐藏手术的分隔标记：当前语言优先，另保留另一语言与「问题：」老格式。
    var BLOCK_MARKERS = {
      zh: ['\n提问：', '提问：', '\n问题：', '问题：'],
      en: ['\nAsk:', 'Ask:'],
    }
    function blockMarkers() {
      return currentLang === 'en'
        ? BLOCK_MARKERS.en.concat(BLOCK_MARKERS.zh)
        : BLOCK_MARKERS.zh.concat(BLOCK_MARKERS.en)
    }
    // 反解析用的段落级分隔标记（引用块按协议生成，均以 \n\n 开头）。
    var PARSE_MARKERS = ['\n\n提问：', '\n\n问题：', '\n\nAsk:']

    // ============================== 工具 ==============================
    // 助手行判别：0810 snapshot 起助手消息行 = ChatNodeSeat 上的
    // data-chat-flow-kind="assistant-step"（旧版 data-time-hover-root 已不再
    // 出现在助手消息主体上，只留在用户行与 turn 尾节点）；保留旧判别式兜底
    // 兼容回滚旧 snapshot，并排除新版 data-turn-tail 误判。
    function isAssistantRow(el) {
      if (el.matches('[data-chat-flow-kind="assistant-step"]')) return true
      return el.hasAttribute('data-time-hover-root')
        && el.querySelector('[class*="bubble"]') === null
        && !el.hasAttribute('data-turn-tail')
    }

    // ---------- focus-chat（@dingyi222666/dsh-focus-chat）视图兼容 ----------
    // 该插件在 conversation.view 槽注册「聚焦会话」视图：挂载于
    // [data-focus-flow]（列容器）→ [data-focus-anchor-key]（行包装）→ 行。
    // 助手行 = class 含 "assistant" 的容器（CSS Modules 哈希名保留 local 名，
    // 形如 `<hash>_assistant`；流式期间行自带 data-streaming，停流后移除）。
    // 用户行保留 data-time-hover-root + [class*="bubble"]，与旧判别式一致。
    function isFocusFlow(el) {
      return el !== null && typeof el.closest === 'function'
        && el.closest('[data-focus-flow]') !== null
    }

    function isFocusAssistantRow(el) {
      if (el === null || !el.classList || !isFocusFlow(el)) return false
      for (var i = 0; i < el.classList.length; i++) {
        if (el.classList[i].indexOf('assistant') !== -1) return true
      }
      return false
    }

    /** focus 视图的全部消息行（用户 + 助手，DOM 顺序）。只保留最外层助手
     *  容器（markdown 内部子元素也可能带含 assistant 的类名）。 */
    function focusMessageRows() {
      var flow = document.querySelector('[data-focus-flow]')
      if (flow === null) return []
      var out = []
      var all = flow.querySelectorAll('[data-time-hover-root], [class*="assistant"]')
      for (var i = 0; i < all.length; i++) {
        var el = all[i]
        if (el.hasAttribute('data-time-hover-root')) {
          if (!isAssistantRow(el)) out.push(el)
          continue
        }
        if (!isFocusAssistantRow(el)) continue
        var p = el.parentElement
        if (p !== null && p !== flow && isFocusAssistantRow(p)) continue
        out.push(el)
      }
      return out
    }

    function assistantRowOf(node) {
      var el = (node instanceof Element) ? node : (node !== null ? node.parentElement : null)
      while (el !== null && el !== document.body) {
        if (el.hasAttribute('data-chat-flow-kind')) {
          return el.getAttribute('data-chat-flow-kind') === 'assistant-step' ? el : null
        }
        if (el.hasAttribute('data-time-hover-root')) {
          return isAssistantRow(el) ? el : null
        }
        if (isFocusAssistantRow(el)) {
          // 冒到最外层 focus 助手容器（内部子元素可能也含 assistant 类名）。
          while (el.parentElement !== null && el.parentElement !== document.body
            && isFocusAssistantRow(el.parentElement)) {
            el = el.parentElement
          }
          return el
        }
        el = el.parentElement
      }
      return null
    }

    // 只接管宿主的可选文本正文；标题、按钮、PDF 和 iframe 不属于此接口。
    var DOCUMENT_TEXT = '[data-textpreview-plain], [data-document-markdown], [data-code-preview] pre'

    function documentSourceOf(node) {
      var el = node instanceof Element ? node : node && node.parentElement
      if (el && el.closest('button, input, textarea, [contenteditable="true"]')) return null
      var root = el && el.closest(DOCUMENT_TEXT)
      var preview = root && root.closest('[data-textpreview-url]')
      if (!preview) return null
      var url = preview.getAttribute('data-textpreview-url') || ''
      var match = /^dsh-resource:\/\/file\/session\/([^/]+)\/(.+)$/.exec(url)
      if (!match) return null
      try {
        var sessionId = decodeURIComponent(match[1])
        var path = match[2].split('/').map(decodeURIComponent).join('/')
        if (/[\u0000-\u001f\u007f]/.test(path) || /[?#]/.test(url)) return null
        return { root: root, sourceUrl: url, sourcePath: path, sessionId: sessionId }
      } catch (_) { return null }
    }

    function annotationRootOf(node) {
      var source = documentSourceOf(node)
      return source !== null ? source.root : assistantRowOf(node)
    }

    function quoteRects(range, saved) {
      var rects = Array.from(range.getClientRects())
      if (!saved.sourceUrl) return rects
      var clip = { left: 0, top: 0, right: window.innerWidth, bottom: window.innerHeight }
      var node = range.commonAncestorContainer
      var el = node instanceof Element ? node : node.parentElement
      for (; el && el !== document.body; el = el.parentElement) {
        var style = getComputedStyle(el)
        var box = el.getBoundingClientRect()
        if (/auto|scroll|hidden|clip/.test(style.overflowX)) {
          clip.left = Math.max(clip.left, box.left); clip.right = Math.min(clip.right, box.right)
        }
        if (/auto|scroll|hidden|clip/.test(style.overflowY)) {
          clip.top = Math.max(clip.top, box.top); clip.bottom = Math.min(clip.bottom, box.bottom)
        }
      }
      return rects.map(function (r) {
        var left = Math.max(r.left, clip.left), top = Math.max(r.top, clip.top)
        return new DOMRect(left, top, Math.max(0, Math.min(r.right, clip.right) - left), Math.max(0, Math.min(r.bottom, clip.bottom) - top))
      }).filter(function (r) { return r.width > 0 && r.height > 0 })
    }

    function quoteWithSource(q) {
      return q.sourcePath ? '[' + q.sourcePath + ']\n' + q.text : q.text
    }

    function assistantRows() {
      var modern = document.querySelectorAll('[data-chat-flow-kind="assistant-step"]')
      if (modern.length > 0) return Array.prototype.slice.call(modern)
      var focus = focusMessageRows().filter(isFocusAssistantRow)
      if (focus.length > 0) return focus
      return Array.prototype.slice.call(document.querySelectorAll('[data-time-hover-root]'))
        .filter(isAssistantRow)
    }

    /** 全部消息行（用户 + 助手 + 其它节点）：新版走 data-chat-flow-kind，
     *  旧版回退 data-time-hover-root；focus-chat 视图单独按 DOM 顺序收集
     *  （会话视图 tab 切换时主视图会卸载，两种结构不同时存在）。
     *  用于气泡装饰、引用条目回溯。 */
    function allMessageRows() {
      var modern = document.querySelectorAll('[data-chat-flow-kind]')
      if (modern.length > 0) return Array.prototype.slice.call(modern)
      var focus = focusMessageRows()
      if (focus.length > 0) return focus
      return Array.prototype.slice.call(document.querySelectorAll('[data-time-hover-root]'))
    }

    /** 由字符偏移在元素内构造 Range（跨文本节点）。 */
    function rangeFromOffset(el, offset, length) {
      var nodes = []
      var walker = document.createTreeWalker(el, NodeFilter.SHOW_TEXT)
      var n
      while ((n = walker.nextNode()) !== null) nodes.push(n)
      var pos = 0
      for (var i = 0; i < nodes.length; i++) {
        var len = (nodes[i].nodeValue || '').length
        if (offset < pos + len) {
          var range = document.createRange()
          range.setStart(nodes[i], offset - pos)
          var remain = length
          var j = i
          var inner = offset - pos
          while (remain > 0) {
            var l = (nodes[j].nodeValue || '').length
            var take = Math.min(remain, l - inner)
            remain -= take
            if (remain === 0) { range.setEnd(nodes[j], inner + take); break }
            j++
            inner = 0
          }
          return range
        }
        pos += len
      }
      return null
    }

    function findRangeIn(el, quote) {
      var full = ''
      var walker = document.createTreeWalker(el, NodeFilter.SHOW_TEXT)
      var n
      while ((n = walker.nextNode()) !== null) full += n.nodeValue || ''
      var start = full.indexOf(quote)
      if (start === -1) return null
      return rangeFromOffset(el, start, quote.length)
    }

    /** 空白完全剥离匹配：返回 quote 在 full 中的所有原始偏移区间 [{start,end}]。
     *  解决选区文本跨块级元素（GenUI 表格单元格等）带出 \n、而 DOM textContent
     *  无此空白导致的匹配失败（此前会掉进宽松匹配命中旧轮次）。 */
    function allNormSpans(full, quote) {
      var nq = quote.replace(/\s+/g, '')
      if (nq === '') return []
      var nf = ''
      var map = []
      for (var i = 0; i < full.length; i++) {
        if (!/\s/.test(full[i])) { nf += full[i]; map.push(i) }
      }
      var out = []
      var idx = nf.indexOf(nq)
      while (idx !== -1) {
        out.push({ start: map[idx], end: map[idx + nq.length - 1] + 1 })
        idx = nf.indexOf(nq, idx + 1)
      }
      return out
    }

    function findNormSpan(full, quote) {
      var spans = allNormSpans(full, quote)
      return spans.length > 0 ? spans[0] : null
    }

    /** 引用芯片差异变体：选区文本里芯片是「Annotation N」（无冒号），而消息行
     *  渲染文本可能是「Annotation N：」（React 重渲染后冒号恢复）——匹配失败时
     *  用变体重试，抹平该差异。 */
    function quoteVariants(quote) {
      var out = [quote]
      var re = /Annotation[\s\u200b\u200c\u200d\u00ad]*(\d+)/gi
      var m
      while ((m = re.exec(quote)) !== null) {
        out.push(quote.slice(0, m.index) + 'Annotation ' + m[1] + '：' + quote.slice(m.index + m[0].length))
      }
      return out
    }

    function allPositionsOf(el, quote) {
      var full = el.textContent || ''
      var out = []
      var idx = full.indexOf(quote)
      while (idx !== -1) {
        out.push(idx)
        idx = full.indexOf(quote, idx + 1)
      }
      return out
    }

    function ctxScore(full, pos, len, ctx) {
      if (ctx === null) return 0
      var before = full.slice(Math.max(0, pos - 24), pos)
      var after = full.slice(pos + len, pos + len + 24)
      var s = 0
      for (var i = 0; i < Math.min(before.length, ctx.before.length); i++) {
        if (before[i] === ctx.before[i]) s++
      }
      for (var j = 0; j < Math.min(after.length, ctx.after.length); j++) {
        if (after[j] === ctx.after[j]) s++
      }
      return s
    }

    /** 由 Range 起点算出它在元素文本内的绝对字符偏移（真实位置）。 */
    function offsetOfRangeInRow(row, range) {
      try {
        var walker = document.createTreeWalker(row, NodeFilter.SHOW_TEXT)
        var n
        var pos = 0
        while ((n = walker.nextNode()) !== null) {
          var len = (n.nodeValue || '').length
          if (n === range.startContainer) return pos + range.startOffset
          pos += len
        }
      } catch (_) { /* fallthrough */ }
      return -1
    }

    /** 宽松定位：token 式匹配，双向容忍空白差异。 */
    function findRangeFlexible(el, quote) {
      var qNorm = quote.replace(/\s+/g, ' ').trim()
      if (qNorm === '') return null
      var tokens = qNorm.split(' ').filter(function (t) { return t !== '' })
      if (tokens.length === 0) return null
      var nodes = []
      var walker = document.createTreeWalker(el, NodeFilter.SHOW_TEXT)
      var n
      while ((n = walker.nextNode()) !== null) nodes.push(n)
      var stream = []
      for (var i = 0; i < nodes.length; i++) {
        var text = nodes[i].nodeValue || ''
        for (var k = 0; k < text.length; k++) stream.push({ node: nodes[i], offset: k, ch: text[k] })
      }
      var t = 0
      var ti = 0
      var startNode = null
      var startOff = 0
      var endNode = null
      var endOff = -1
      var seenGap = false
      for (var s = 0; s < stream.length && t < tokens.length; s++) {
        var ch = stream[s].ch
        var isWs = /\s/.test(ch)
        if (isWs) {
          if (ti === 0) seenGap = true
          continue
        }
        if (ti === 0) {
          if (t > 0 && !seenGap) seenGap = true
          if (ch === tokens[t][0]) {
            if (t === 0) { startNode = stream[s].node; startOff = stream[s].offset }
            ti = 1
          } else {
            seenGap = true
            continue
          }
          if (tokens[t].length === 1) {
            endNode = stream[s].node
            endOff = stream[s].offset
            t++
            ti = 0
            seenGap = false
          }
          continue
        }
        if (ch === tokens[t][ti]) {
          ti++
          if (ti === tokens[t].length) {
            endNode = stream[s].node
            endOff = stream[s].offset
            t++
            ti = 0
            seenGap = false
          }
        } else {
          ti = 0
          if (ch === tokens[t][0]) {
            if (t === 0) { startNode = stream[s].node; startOff = stream[s].offset }
            ti = 1
            if (tokens[t].length === 1) {
              endNode = stream[s].node
              endOff = stream[s].offset
              t++
              ti = 0
              seenGap = false
            }
          }
        }
      }
      if (t === tokens.length && startNode !== null) {
        var range = document.createRange()
        range.setStart(startNode, startOff)
        range.setEnd(endNode, endOff + 1)
        return range
      }
      return null
    }

    /** 定位引用的 Range：消息 seq 锚定优先，空白不敏感重搜兜底。 */
    function locateQuote(quote, saved) {
      if (saved && saved.sourceUrl) {
        var bodies = document.querySelectorAll(DOCUMENT_TEXT)
        for (var d = 0; d < bodies.length; d++) {
          var source = documentSourceOf(bodies[d])
          if (source === null || source.sourceUrl !== saved.sourceUrl || bodies[d].getClientRects().length === 0) continue
          if (saved.range && bodies[d].contains(saved.range.commonAncestorContainer)
            && saved.range.toString().trim() === quote) return saved.range
          if (saved.textOffset >= 0) {
            var exact = rangeFromOffset(bodies[d], saved.textOffset, quote.length)
            if (exact !== null && exact.toString() === quote) return exact
          }
          // 文件变化后只接受唯一匹配，避免标记重复代码中的另一处。
          var text = bodies[d].textContent || ''
          var at = text.indexOf(quote)
          if (at >= 0 && text.indexOf(quote, at + 1) === -1) return rangeFromOffset(bodies[d], at, quote.length)
        }
        return null
      }
      if (saved !== undefined && saved !== null && saved.range && saved.range.startContainer) {
        try {
          if (saved.range.startContainer.isConnected && saved.range.endContainer.isConnected) {
            var t = saved.range.toString()
            if (t.replace(/\s+/g, '') === quote.replace(/\s+/g, '')) {
              return saved.range
            }
          }
        } catch (_) { /* range 已失效 */ }
      }
      var rows = assistantRows()
      if (saved !== undefined && saved !== null && saved.seqKey !== '') {
        try {
          var item = document.querySelector('[data-chat-anchor-key="' + saved.seqKey + '"]')
          // focus-chat 视图的锚 key 属性名不同，值语义一致。
          if (item === null) {
            item = document.querySelector('[data-focus-anchor-key="' + saved.seqKey + '"]')
          }
          if (item !== null) {
            var itText = item.textContent || ''
            if (saved.textOffset >= 0) {
              var sp0 = findNormSpan(itText, quote)
              if (sp0 !== null && Math.abs(sp0.start - saved.textOffset) <= 2) {
                var itRange = rangeFromOffset(item, sp0.start, sp0.end - sp0.start)
                if (itRange !== null) return itRange
              }
            }
            if (saved.ctxBefore !== '') {
              var itIdx = itText.indexOf(saved.ctxBefore)
              if (itIdx !== -1) {
                var itNear = itIdx + saved.ctxBefore.length
                var sp1 = findNormSpan(itText.slice(itNear), quote)
                if (sp1 !== null) {
                  var itRange2 = rangeFromOffset(item, itNear + sp1.start, sp1.end - sp1.start)
                  if (itRange2 !== null) return itRange2
                }
              }
            }
            // 锚点消息内的全量扫描（空白不敏感 + 上下文评分）。
            var spansIt = allNormSpans(itText, quote)
            var bestIt = null
            var bestItScore = -1
            for (var pp2 = 0; pp2 < spansIt.length; pp2++) {
              var rngIt = rangeFromOffset(item, spansIt[pp2].start, spansIt[pp2].end - spansIt[pp2].start)
              if (rngIt === null) continue
              var scIt = ctxScore(itText, spansIt[pp2].start, spansIt[pp2].end - spansIt[pp2].start,
                { before: saved.ctxBefore || '', after: saved.ctxAfter || '' })
              if (scIt > bestItScore) { bestItScore = scIt; bestIt = rngIt }
            }
            if (bestIt !== null && (saved.ctxBefore === '' || bestItScore > 0)) return bestIt
            // 锚点消息还在但原文匹配不上：先试引用芯片差异变体（「Annotation N」
            // vs「Annotation N：」）在**同一条消息内**宽松重定位——绝不跨消息
            // 模糊搜索（那是「跳到旧轮次」的根源，v1.3.6 纪律）。
            var variants = quoteVariants(quote)
            for (var vi = 0; vi < variants.length; vi++) {
              var vsp = allNormSpans(itText, variants[vi])
              for (var vj = 0; vj < vsp.length; vj++) {
                var vrng = rangeFromOffset(item, vsp[vj].start, vsp[vj].end - vsp[vj].start)
                if (vrng !== null) return vrng
              }
              var vflex = findRangeFlexible(item, variants[vi])
              if (vflex !== null) return vflex
            }
            // 同消息内确实定位不到 → 放弃（脚标隐藏）。
            return null
          }
        } catch (_) { return null }
      }
      if (saved !== undefined && saved !== null && saved.rowHead !== '') {
        for (var r = 0; r < rows.length; r++) {
          var rowText = rows[r].textContent || ''
          if (rowText.slice(0, 24) !== saved.rowHead) continue
          if (saved.textOffset >= 0) {
            var spR = findNormSpan(rowText, quote)
            if (spR !== null && Math.abs(spR.start - saved.textOffset) <= 2) {
              var range = rangeFromOffset(rows[r], spR.start, spR.end - spR.start)
              if (range !== null) return range
            }
          }
          if (saved.ctxBefore !== '') {
            var bIdx = rowText.indexOf(saved.ctxBefore)
            if (bIdx !== -1) {
              var near = bIdx + saved.ctxBefore.length
              var spR2 = findNormSpan(rowText.slice(near), quote)
              if (spR2 !== null) {
                var range2 = rangeFromOffset(rows[r], near + spR2.start, spR2.end - spR2.start)
                if (range2 !== null) return range2
              }
            }
          }
          var spans = allNormSpans(rowText, quote)
          var bestRow = null
          var bestRowScore = -1
          for (var pp = 0; pp < spans.length; pp++) {
            var rng = rangeFromOffset(rows[r], spans[pp].start, spans[pp].end - spans[pp].start)
            if (rng === null) continue
            var sc = ctxScore(rowText, spans[pp].start, spans[pp].end - spans[pp].start,
              saved !== undefined && saved !== null
                ? { before: saved.ctxBefore || '', after: saved.ctxAfter || '' }
                : null)
            if (sc > bestRowScore) { bestRowScore = sc; bestRow = rng }
          }
          if (bestRow !== null) return bestRow
        }
      }
      var ctx = saved !== undefined && saved !== null
        ? { before: saved.ctxBefore || '', after: saved.ctxAfter || '' }
        : null
      var best = null
      var bestScore = -1
      for (var i = 0; i < rows.length; i++) {
        var full = rows[i].textContent || ''
        var spans = allNormSpans(full, quote)
        for (var p = 0; p < spans.length; p++) {
          var range = rangeFromOffset(rows[i], spans[p].start, spans[p].end - spans[p].start)
          if (range === null) continue
          var score = ctxScore(full, spans[p].start, spans[p].end - spans[p].start, ctx)
          if (score > bestScore) { bestScore = score; best = range }
        }
      }
      if (best !== null && (ctx === null || bestScore > 0)) return best
      var flow = document.querySelector('[data-chat-flow]')
      if (flow === null) flow = document.querySelector('[data-focus-flow]')
      if (flow !== null) {
        var full2 = flow.textContent || ''
        var positions2 = allPositionsOf(flow, quote)
        var best2 = null
        var bestScore2 = -1
        for (var q2 = 0; q2 < positions2.length; q2++) {
          var range2 = rangeFromOffset(flow, positions2[q2], quote.length)
          if (range2 === null) continue
          var score2 = ctxScore(full2, positions2[q2], quote.length, ctx)
          if (score2 > bestScore2) { bestScore2 = score2; best2 = range2 }
        }
        if (best2 !== null && (ctx === null || bestScore2 > 0)) return best2
      }
      return null
    }

    function truncate(s, n) {
      return s.length > n ? s.slice(0, n) + '…' : s
    }

    function placeAbove(rect, height) {
      var w = 400
      var left = rect.left + rect.width / 2 - w / 2
      left = Math.max(8, Math.min(left, window.innerWidth - w - 8))
      // 下方优先：原生选中菜单（移动端长按菜单、桌面 Copy/Search 浮层）锚定在选区
      // 上沿附近，且原生 UI 恒绘制在页面内容之上（z-index 无效），工具条放上方必被
      // 遮挡；因此下方放得下就放下方，放不下才回上方。
      var belowTop = rect.bottom + 8
      var belowFits = belowTop + height <= window.innerHeight - 8
      var top
      if (belowFits) {
        top = belowTop
      } else {
        top = rect.top - height - 8
        if (top < 8) top = Math.min(rect.bottom + 8, window.innerHeight - height - 8)
      }
      return { left: Math.round(left), top: Math.round(Math.max(8, top)) }
    }

    function svg(paths, viewBox) {
      var s = document.createElementNS('http://www.w3.org/2000/svg', 'svg')
      s.setAttribute('viewBox', viewBox)
      s.setAttribute('fill', 'none')
      s.setAttribute('xmlns', 'http://www.w3.org/2000/svg')
      for (var i = 0; i < paths.length; i++) {
        var p = document.createElementNS('http://www.w3.org/2000/svg', 'path')
        p.setAttribute('d', paths[i])
        p.setAttribute('fill', 'currentColor')
        s.appendChild(p)
      }
      return s
    }
    var ICONS = {
      plus: function () {
        return svg(['M8.64453 1.5V7.34961H14.5V8.65039H8.64453V14.5H7.34473V8.65039H1.5V7.34961H7.34473V1.5H8.64453Z'], '0 0 16 16')
      },
      check: function () {
        return svg([
          'M15.0498 3.92579L8.49512 12.3818C8.25774 12.6881 8.04517 12.9645 7.84668 13.1689C7.63957 13.3823 7.38732 13.5841 7.04492 13.6719C6.86373 13.7183 6.6757 13.7346 6.48926 13.7197C6.13666 13.6915 5.8528 13.5355 5.6123 13.3604C5.38201 13.1926 5.12573 12.9567 4.83984 12.6953L1.03125 9.21289L1.96875 8.1875L5.77734 11.6699C6.08684 11.9529 6.27773 12.1249 6.43066 12.2363C6.50183 12.2882 6.54699 12.3135 6.57324 12.3252C6.58525 12.3305 6.59269 12.3322 6.5957 12.333C6.59802 12.3336 6.59961 12.334 6.59961 12.334C6.63317 12.3367 6.66758 12.3335 6.7002 12.3252C6.7002 12.3252 6.70211 12.3251 6.7041 12.3242C6.70698 12.3229 6.71348 12.319 6.72461 12.3115C6.74849 12.2956 6.78843 12.2642 6.84961 12.2012C6.98138 12.0654 7.13957 11.8628 7.39648 11.5313L13.9502 3.07422L15.0498 3.92579Z',
        ], '0 0 16 16')
      },
      close: function () {
        return svg([
          'M14.1168 13.197L13.197 14.1167L1.8833 2.80303L2.80309 1.88324L14.1168 13.197Z',
          'M13.197 1.88326L14.1168 2.80305L2.80309 14.1168L1.8833 13.197L13.197 1.88326Z',
        ], '0 0 16 16')
      },
      send: function () {
        return svg([
          'M8.3125 0.981587C8.66767 1.0545 8.97902 1.20558 9.2627 1.43374C9.48724 1.61438 9.73029 1.85933 9.97949 2.10854L14.707 6.83608L13.293 8.25014L9 3.95717V15.0431H7V3.95717L2.70703 8.25014L1.29297 6.83608L6.02051 2.10854C6.26971 1.85933 6.51277 1.61438 6.7373 1.43374C6.97662 1.24126 7.28445 1.04542 7.6875 0.981587C7.8973 0.94841 8.1031 0.956564 8.3125 0.981587Z',
        ], '0 0 16 16')
      },
      trash: function () {
        return svg([
          'M14.4782 4.84067L14.2138 10.1152C14.1102 12.1872 14.067 13.0115 13.3866 13.9607C13.1044 14.3546 12.7498 14.6912 12.3424 14.9535C11.8239 15.2872 11.2415 15.4316 10.5585 15.4998C9.88727 15.5668 9.04946 15.5656 7.99998 15.5656C6.95051 15.5656 6.1127 15.5668 5.44142 15.4998C4.75851 15.4316 4.17602 15.2872 3.65753 14.9535C3.25012 14.6912 2.89559 14.3546 2.61332 13.9607C1.93296 13.0115 1.88979 12.1872 1.78619 10.1152L1.52179 4.84067L2.89006 4.77277L3.15343 10.0463C3.26221 12.2218 3.32452 12.6015 3.72646 13.1624C3.90825 13.4161 4.13686 13.6334 4.39927 13.8023C4.66204 13.9714 5.00263 14.0792 5.57825 14.1367C6.16562 14.1953 6.92298 14.1963 7.99998 14.1963C9.07699 14.1963 9.83434 14.1953 10.4217 14.1367C10.9973 14.0792 11.3379 13.9714 11.6007 13.8023C11.8631 13.6334 12.0917 13.4161 12.2735 13.1624C12.6755 12.6015 12.7378 12.2218 12.8465 10.0463L13.1099 4.77277L14.4782 4.84067ZM5.43011 6.22849H6.7994V11.3909H5.43011V6.22849ZM9.20056 6.22849H10.5699V11.3909H9.20056V6.22849ZM8.53597 0.434431C9.17976 0.434431 9.6522 0.426926 10.0966 0.571258C10.2357 0.616451 10.3717 0.672554 10.502 0.738948C10.9182 0.951107 11.2464 1.29099 11.7015 1.74612L12.4978 2.54136H15.3742V3.91169H0.625732V2.54136H3.50218L4.29845 1.74612C4.75358 1.29099 5.08174 0.951107 5.49801 0.738948C5.62831 0.672554 5.76425 0.616451 5.90334 0.571258C6.34776 0.426926 6.82021 0.434431 7.46399 0.434431H8.53597ZM7.46399 1.80476C6.73208 1.80476 6.51641 1.81187 6.32617 1.87369C6.25545 1.89667 6.18668 1.92533 6.12041 1.95907C5.96398 2.03878 5.82348 2.16253 5.44142 2.54136H10.5585C10.1765 2.16253 10.036 2.03878 9.87955 1.95907C9.81329 1.92533 9.74452 1.89667 9.6738 1.87369C9.48356 1.81187 9.26789 1.80476 8.53597 1.80476H7.46399Z',
        ], '0 0 16 16')
      },
    }

    var PENDING_STORAGE_PREFIX = 'dsh.annotation.pending.v1.'

    function pendingStorageKey(sessionId) {
      return PENDING_STORAGE_PREFIX + encodeURIComponent(String(sessionId))
    }

    function parsePendingQuotes(raw) {
      if (typeof raw !== 'string' || raw === '') return []
      try {
        var value = JSON.parse(raw)
        if (!Array.isArray(value)) return []
        return value.filter(function (q) {
          return q !== null && typeof q === 'object'
            && typeof q.id === 'string' && typeof q.text === 'string' && q.text !== ''
        }).map(function (q) {
          return {
            id: q.id,
            text: q.text,
            note: typeof q.note === 'string' ? q.note : '',
            ...(typeof q.sourceUrl === 'string' && typeof q.sourcePath === 'string'
              ? { sourceUrl: q.sourceUrl, sourcePath: q.sourcePath } : {}),
            range: null,
            seqKey: typeof q.seqKey === 'string' ? q.seqKey : '',
            rowHead: typeof q.rowHead === 'string' ? q.rowHead : '',
            textOffset: Number.isFinite(q.textOffset) ? q.textOffset : -1,
            ctxBefore: typeof q.ctxBefore === 'string' ? q.ctxBefore : '',
            ctxAfter: typeof q.ctxAfter === 'string' ? q.ctxAfter : '',
          }
        })
      } catch (_) {
        return []
      }
    }

    function stringifyPendingQuotes(quotes) {
      return JSON.stringify(quotes.map(function (q) {
        return {
          id: q.id,
          text: q.text,
          note: q.note || '',
          ...(q.sourceUrl ? { sourceUrl: q.sourceUrl, sourcePath: q.sourcePath } : {}),
          seqKey: q.seqKey || '',
          rowHead: q.rowHead || '',
          textOffset: Number.isFinite(q.textOffset) ? q.textOffset : -1,
          ctxBefore: q.ctxBefore || '',
          ctxAfter: q.ctxAfter || '',
        }
      }))
    }

    // ============================== 插件主体 ==============================
    function apply(ctx) {
      var sessions = ctx.sessions

      // PATCH(2026-09-17-current-session): DSH 0.1.6 起 sessions 服务不再暴露「当前会话」，
      // 线上 provider 已是 dsh-api-session-controller 的 ClientSessions（其 list 快照只有
      // ids/byId/phase/subagentsByParent/jobsBySession，源码注释写明 view selection remains
      // outside the Controller）。旧字段 .current 恒为 undefined 会让「回车拼稿 / 按会话落盘 /
      // 发送后清 chip」三处一起静默失效（既无日志也无 toast），表现为引用发不出去且 chip 常驻。
      // 这里做统一解析：① 老宿主快照 current；② 新宿主视图层保留的当前会话；③ uiWorkspace
      // 持久化选择单元；④ 宿主自己写在 localStorage 的 dsh.sessions.current。
      var sessionWarned = false
      function currentSessionId() {
        var snap = sessions.list.getSnapshot()
        if (snap !== null && snap !== undefined && snap.current !== undefined) return snap.current
        try {
          var ui = typeof ctx.get === "function" ? ctx.get("uiWorkspace") : undefined
          if (ui !== null && ui !== undefined) {
            var ref = ui.mainReference
            if (ref !== null && ref !== undefined
              && typeof ref.sessionId === "string" && ref.sessionId !== "") return ref.sessionId
            var sel = ui.selection
            if (sel !== null && sel !== undefined && typeof sel.getSnapshot === "function") {
              var picked = sel.getSnapshot()
              if (picked !== null && picked !== undefined
                && typeof picked.sessionId === "string" && picked.sessionId !== "") return picked.sessionId
            }
          }
        } catch (_) {}
        try {
          var raw = localStorage.getItem("dsh.sessions.current")
          if (typeof raw === "string" && raw !== "") {
            var parsed = JSON.parse(raw)
            if (parsed !== null && typeof parsed === "object"
              && typeof parsed.sessionId === "string" && parsed.sessionId !== ""
              && (snap === null || snap === undefined || !Array.isArray(snap.ids)
                || snap.ids.indexOf(parsed.sessionId) !== -1)) return parsed.sessionId
          }
        } catch (_) {}
        if (!sessionWarned) {
          sessionWarned = true
          console.warn("[annotation] 无法解析当前会话 id（宿主会话接口可能已变更）：引用拼稿与发送后清理不可用")
        }
        return undefined
      }

      var host = document.createElement('div')
      host.setAttribute('data-annotation-for-dsh', '')
      document.body.appendChild(host)
      var overlay = document.createElement('div')
      overlay.setAttribute('data-annotation-overlay', '')
      overlay.style.cssText = 'position:fixed;inset:0;pointer-events:none;z-index:900;'
      document.body.appendChild(overlay)

      var ui = {
        mode: 'closed',      // closed | actions | editing | composing
        editingId: null,     // 非空 = 正在编辑该 id 的已有引用（点角标进入）
        quote: '',
        quotes: [],          // [{ id, text, note, range, seqKey, rowHead, textOffset, ctxBefore, ctxAfter }]
        noteDraft: '',
        pos: { left: 0, top: 0 },
        error: null,
        busy: false,
        lastKey: '',
        pendingAnchor: null,
        el: null,
      }

      function readPendingQuotes(sessionId) {
        if (sessionId === undefined) return []
        try {
          return parsePendingQuotes(localStorage.getItem(pendingStorageKey(sessionId)))
        } catch (err) {
          console.warn('[annotation] 读取待发送引用失败：', err)
          return []
        }
      }

      function writePendingQuotes(sessionId) {
        if (sessionId === undefined) return
        try {
          var key = pendingStorageKey(sessionId)
          if (ui.quotes.length === 0) localStorage.removeItem(key)
          else localStorage.setItem(key, stringifyPendingQuotes(ui.quotes))
        } catch (err) {
          console.warn('[annotation] 保存待发送引用失败：', err)
        }
      }

      function writeCurrentPendingQuotes() {
        writePendingQuotes(currentSessionId())
      }

      var ignoreUntil = 0
      var settleTimer = null

      // ---------- IME 合成 latch（对齐官方 InputBar composingRef）----------
      // macOS / 豆包等：compositionend 之后才会到 keydown(Enter, isComposing=false,
      // keyCode=13)，仅查 isComposing / 229 挡不住「上屏确认 Enter」。若此时
      // attachAndSend → setDraft，会打断合成，表现为只能打出拼音字母。
      // 延迟清 latch 与 InputBar 一致（略放宽到 50ms，兼容第三方输入法时序）。
      var imeComposing = false
      var imeClearTimer = null
      var imeTouchedAt = 0
      function markImeComposing() {
        imeComposing = true
        imeTouchedAt = Date.now()
        if (imeClearTimer !== null) {
          clearTimeout(imeClearTimer)
          imeClearTimer = null
        }
      }
      function markImeEnded() {
        if (imeClearTimer !== null) clearTimeout(imeClearTimer)
        imeClearTimer = setTimeout(function () {
          imeComposing = false
          imeClearTimer = null
        }, 50)
      }
      /** @param {KeyboardEvent} e */
      function isImeKeyBlocked(e) {
        if (e.isComposing === true || e.keyCode === 229) {
          imeTouchedAt = Date.now()
          return true
        }
        // compositionend 偶尔会丢失。只在浏览器已明确报告「非合成」且 latch
        // 1.2 秒没有活动时复位，避免一次异常把之后所有 Enter 永久锁死。
        if (imeComposing && imeClearTimer === null && Date.now() - imeTouchedAt >= 1200) {
          imeComposing = false
        }
        return imeComposing
      }
      document.addEventListener('compositionstart', markImeComposing, true)
      document.addEventListener('compositionend', markImeEnded, true)

      // ---------- 轻提示 ----------
      var toastTimer = null
      function showToast(msg) {
        try {
          var old = document.querySelector('[data-annotation-toast]')
          if (old !== null) old.remove()
          var el = document.createElement('div')
          el.setAttribute('data-annotation-toast', '')
          el.textContent = msg
          el.style.cssText = 'position:fixed;z-index:1300;left:50%;bottom:88px;transform:translateX(-50%);max-width:min(420px,calc(100vw - 24px));padding:8px 14px;border-radius:10px;background:var(--dsw-specific-menu,#2c2c2e);border:1px solid var(--dsw-alias-border-inverted);box-shadow:var(--dsw-shadow-lv3);color:var(--dsw-alias-label-primary);font-family:var(--dsw-font-family,system-ui);font-size:12px;pointer-events:none;'
          document.body.appendChild(el)
          if (toastTimer !== null) clearTimeout(toastTimer)
          toastTimer = setTimeout(function () {
            toastTimer = null
            if (el.parentNode) el.parentNode.removeChild(el)
          }, 3000)
        } catch (_) { /* toast 失败忽略 */ }
      }

      // ---------- 选区监听 ----------
      function selectionKey(sel) {
        if (sel === null || sel.rangeCount === 0) return ''
        var r = sel.getRangeAt(0)
        return String(r.startContainer === r.endContainer ? 1 : 0)
          + ':' + r.startOffset + ':' + r.endOffset + ':' + sel.toString().length
      }

      function onSelection() {
        if (ui.mode !== 'closed' && host.childNodes.length === 0) {
          ui.mode = 'closed'
          ui.lastKey = ''
        }
        if (ui.mode === 'editing' || ui.mode === 'composing' || ignoreUntil > Date.now()) return
        var sel = window.getSelection()
        if (sel === null || sel.isCollapsed || sel.rangeCount === 0) {
          clearSettle()
          return
        }
        var range = sel.getRangeAt(0)
        var anc = range.commonAncestorContainer
        var ancEl = anc instanceof Element ? anc : (anc && anc.parentElement)
        if (ancEl !== null && ancEl.closest) {
          if (ancEl.closest('[data-annotation-for-dsh]') || ancEl.closest('[data-annotation-overlay]')
            || ancEl.closest('[data-composer-card]') || ancEl.closest('[data-input-scroll]')) {
            clearSettle()
            return
          }
        }
        if (host.contains(anc) || overlay.contains(anc)) {
          clearSettle()
          return
        }
        var text = sel.toString().trim()
        if (text.length === 0) { clearSettle(); return }
        var key = selectionKey(sel)
        var rootEl = annotationRootOf(range.commonAncestorContainer)
        var source = documentSourceOf(range.commonAncestorContainer)
        if (source !== null && source.sessionId !== currentSessionId()) rootEl = null
        if (rootEl === null) { clearSettle(); closeToolbar(); return }
        if (ui.mode === 'actions' && key === ui.lastKey && text === ui.quote && rootEl === ui.selectionRoot
          && (ui.source && ui.source.sourceUrl) === (source && source.sourceUrl)) { clearSettle(); return }
        clearSettle()
        settleTimer = setTimeout(function () {
          settleTimer = null
          if (ui.mode === 'editing' || ui.mode === 'composing') return
          var s = window.getSelection()
          if (s === null || s.isCollapsed || selectionKey(s) !== key) return
          var r = s.getRangeAt(0)
          if (annotationRootOf(r.commonAncestorContainer) !== rootEl) return
          var currentSource = documentSourceOf(r.commonAncestorContainer)
          if ((currentSource && currentSource.sourceUrl) !== (source && source.sourceUrl)
            || (source !== null && source.sessionId !== currentSessionId())) return
          var rect = r.getBoundingClientRect()
          if (rect.width === 0 || rect.height === 0) return
          var p = placeAbove(rect, 40)
          if (ui.mode === 'actions' && ui.quote === text && (ui.source && ui.source.sourceUrl) === (source && source.sourceUrl)) {
            ui.lastKey = key
            ui.pos = p
            if (ui.el !== null && ui.el.style) {
              ui.el.style.left = p.left + 'px'
              ui.el.style.top = p.top + 'px'
            }
            return
          }
          ui.lastKey = key
          ui.mode = 'actions'
          ui.quote = text
          ui.source = source
          ui.selectionRoot = rootEl
          ui.error = null
          ui.pos = p
          render()
        }, 250)
      }
      document.addEventListener('selectionchange', onSelection)

      function clearSettle() {
        if (settleTimer !== null) { clearTimeout(settleTimer); settleTimer = null }
      }

      function onHostPointerDown() { ignoreUntil = Date.now() + 80 }
      host.addEventListener('pointerdown', onHostPointerDown)

      function onDocPointerDown(e) {
        if (ui.mode === 'actions' && !host.contains(e.target) && !overlay.contains(e.target)) {
          closeToolbar()
        }
      }
      document.addEventListener('pointerdown', onDocPointerDown, true)

      var anchorRaf = false
      var lostSince = 0
      var ANCHOR_LOST_MS = 1000
      function onLayoutChange() {
        if (anchorRaf) return
        anchorRaf = true
        requestAnimationFrame(function () {
          anchorRaf = false
          // PATCH(2026-09-18-team-sessions): 卸载后不再装饰（renderMarkers/updateChip）
          if (disposed) return
          if (ui.quotes.length > 0) renderMarkers()
          updateChip()
          if (ui.mode === 'editing' && ui.el !== null) positionEditor(ui.el, ui.pos.left, ui.pos.top)
          if (ui.mode !== 'actions' || ui.quote === '') return
          var rect = null
          var sel = window.getSelection()
          if (sel !== null && !sel.isCollapsed && sel.rangeCount > 0) {
            var live = sel.getRangeAt(0)
            if (annotationRootOf(live.commonAncestorContainer) === ui.selectionRoot
              && (documentSourceOf(live.commonAncestorContainer)?.sourceUrl || '') === (ui.source && ui.source.sourceUrl || '')
              && sel.toString().trim() === ui.quote) {
              rect = live.getBoundingClientRect()
            }
          }
          if (rect === null) {
            var range = locateQuote(ui.quote, ui.source)
            if (range !== null) rect = range.getBoundingClientRect()
          }
          if (rect === null || rect.width === 0 || rect.height === 0) {
            if (lostSince === 0) lostSince = Date.now()
            if (Date.now() - lostSince > ANCHOR_LOST_MS) { lostSince = 0; closeToolbar() }
            return
          }
          lostSince = 0
          var p = placeAbove(rect, 40)
          if (Math.abs(p.left - ui.pos.left) + Math.abs(p.top - ui.pos.top) > 2) {
            ui.pos = p
            if (ui.el !== null && ui.el.style) {
              ui.el.style.left = p.left + 'px'
              ui.el.style.top = p.top + 'px'
            } else {
              render()
            }
          }
        })
      }
      window.addEventListener('scroll', onLayoutChange, true)
      window.addEventListener('resize', onLayoutChange)
      // composer 可能是 fixed/sticky 层，滚动或窗口尺寸变化时其 viewport 坐标也可能变。
      window.addEventListener('scroll', scheduleChipUpdate, true)
      window.addEventListener('resize', scheduleChipUpdate)

      function mutationRelevant(mutations) {
        for (var i = 0; i < mutations.length; i++) {
          var t = mutations[i].target
          var el = t instanceof Element ? t : (t && t.parentElement)
          if (el === null || !el.closest) return true
          if (el.closest('[data-composer-card]') || el.closest('[data-input-scroll]')
            || el.closest('[data-annotation-for-dsh]') || el.closest('[data-annotation-overlay]')
            || el.closest('[data-annotation-chip]') || el.closest('[data-annotation-tip-layer]')) {
            continue
          }
          return true
        }
        return false
      }
      // 内容 observer 只绑定当前消息流，避免 document.body 上任意属性/浮层变化
      // 都触发 O(全部消息行) 的 decorateAll。另用一个仅监听 childList 的轻量
      // rootObserver 处理 SPA 会话切换时消息流/composer 根节点整体替换。
      var observerTargets = []
      var observer = new MutationObserver(function (mutations) {
        if (!mutationRelevant(mutations)) return
        onLayoutChange()
        // 消息行插入/内容填充的瞬间同步执行气泡装饰（隐藏引用块 + 贴标签）：
        // 只有「消息行插入」批次才同步执行气泡装饰（隐藏引用块 + 贴标签）：
        // MutationObserver 回调在微任务阶段运行，早于浏览器绘制，
        // 用户看不到「先显示引用块再隐藏」的闪烁。
        // 流式输出期的主体 mutation 是 attributes/characterData（每个 token 帧一层
        // class/style/文本变更，实测 20s 内 245 批次 0 个 childList）：行插入本来
        // 就携带完整引用块，逐一触发全文档扫描（decorateAll 是 querySelectorAll +
        // 每行子树查询 + textContent，成本随会话长度线性增长）会在长会话上白白
        // 烧主线程；漏网场景由下方 1s 兜底轮询覆盖。
        var hasRowInsert = false
        for (var i = 0; i < mutations.length; i++) {
          if (mutations[i].type === 'childList') { hasRowInsert = true; break }
        }
        if (hasRowInsert) {
          decorateAll()
          return
        }
        // 流式批次: 只做助手回复芯片的限流装饰(行内 data-streaming 守卫已保证
        // 流式中不做替换, 结束后的首拍芯片滞后 ≤500ms), 不再逐批全文档扫描。
        scheduleAssistantDecorate()
        // PATCH(2026-09-25-redecorate)：宿主重建用户气泡文本属于 characterData/
        // attributes 批次，同样要对涉及的用户行定点修补（有块就重切），
        // 否则手术被覆盖后协议文本永久裸奔。
        repairRowsOf(mutations)
      })
      function messageFlowRoots() {
        return Array.prototype.slice.call(document.querySelectorAll('[data-chat-flow], [data-focus-flow]'))
      }
      function bindMessageObserver() {
        var next = messageFlowRoots()
        if (next.length === observerTargets.length && next.every(function (root, index) {
          return root === observerTargets[index]
        })) return false
        observer.disconnect()
        observerTargets = next
        next.forEach(function (root) {
          observer.observe(root, { childList: true, subtree: true, characterData: true })
        })
        return next.length > 0
      }
      var rootObserver = new MutationObserver(function () {
        // 新版页面包含多个消息流；重新挂载的历史内容也需要立即装饰。
        if (bindMessageObserver()) kickDecorate()
        // React 可能整体替换 composer；ResizeObserver 只绑定旧节点时，需重新取锚。
        if (ui.quotes.length > 0
          && document.querySelector('[data-composer-card]') !== chipComposerCard) {
          scheduleChipUpdate()
        }
      })
      rootObserver.observe(document.body, { childList: true, subtree: true })
      bindMessageObserver()

      // ---------- composer 输入面判别（textarea / Lexical contenteditable） ----------
      // PATCH(2026-09-01-lexical): 宿主 composer 从 <textarea> 换成 Lexical
      // contenteditable（ComposerContentEditable），判别必须同时认两种形态。
      // 旧 DSH snapshot 的 composer 是 <textarea>；新 snapshot（Lexical 化的
      // ComposerContentEditable）是 <div contenteditable="true">。只认 textarea 会让
      // 回车拼稿守卫永不成立：引用块不随消息发出，引用集也不被清空（chip 常驻）。
      /** @param {EventTarget|null} el @returns {boolean} 事件目标是否为 composer 输入面 */
      function isComposerEditor(el) {
        if (!(el instanceof Element)) return false
        if (typeof el.closest !== 'function') return false
        if (el.closest('[data-composer-card]') === null) return false
        if (el instanceof HTMLTextAreaElement) return true
        if (el.isContentEditable === true) return true
        // jsdom / 无 isContentEditable 的实现兜底：Lexical 根节点是 contenteditable="true"，
        // 事件目标可能是其内部段落/文本容器，向上找一次即可。
        return el.closest('[contenteditable="true"]') !== null
      }

      function onKeyDown(e) {
        if (e.key === 'Escape') {
          if (ui.mode !== 'closed') closeToolbar()
          return
        }
        // 【回车随输入框发送】在 composer 里按 Enter（且已收集引用、非输入法合成）：
        // 提交前一刻把引用块拼进草稿，composer 自己的 Enter 提交继续——模型收到
        // 引用清单 + 用户输入的问题。用户始终看不到文本被塞进去。
        // IME 铁律（v1.3.10 修了 nativeEvent.keyCode；v1.3.11 补 compositionend
        // 后 Enter keyCode=13 的时序洞）：合成期 / 上屏确认 Enter 绝不能 setDraft。
        // 修饰键守卫（v1.3.18 修 issue #10；PATCH(2026-09-25-queue-quote) 修订）：
        // Shift+Enter 换行、Alt+Enter 默认路径不触发拼稿；Cmd/Ctrl+Enter 与裸
        // Enter 一样拼稿——运行中 Cmd/Ctrl+Enter 插队发送此前不带引用（有文字时
        // 被 shouldAttachForEnter 整条交回 composer，引用块压根没拼进草稿）。
        // 拼稿与接管提交解耦：拼稿恒做；只有「纯引用空草稿」才由插件接管直发
        // （issue #17：composer 的 accelerated 空草稿路径在「运行中 + 有排队消息」
        // 时走 steerQueue 而不发送草稿，故 capture 阶段 setDraft 后 stopPropagation
        // 主动 submit('queue')）。带文字时放行 composer，由宿主 resolveSubmitMode
        // 决定 Queue / Steer（issue #10 的原意），引用块随草稿一起由宿主提交。
        if (e.key === 'Enter' && !e.shiftKey && !e.altKey
          && ui.quotes.length > 0 && !isImeKeyBlocked(e)) {
          var ta = e.target
          // PATCH(2026-09-01-lexical): 旧守卫只认 HTMLTextAreaElement → Lexical 下永不成立
          if (isComposerEditor(ta)) {
            var attached = attachAndSend(e)
            if (attached && attachWasPureQuote && (e.ctrlKey || e.metaKey)) {
              e.preventDefault()
              e.stopPropagation()
              submitAttached()
            }
          }
        }
      }
      // capture 阶段：必须先于 composer 自己的 Enter 处理（React 在容器层冒泡
      // 提交）——否则等我们执行时消息已提交，拼稿永远太迟。
      document.addEventListener('keydown', onKeyDown, true)

      function submitAttached() {
        var current = currentSessionId()
        if (current === undefined) return
        var scoped = sessions.scope(current)
        if (scoped === undefined) return
        try {
          ctx.conversation.input.for(scoped).submit('queue')
        } catch (err) {
          console.warn('[annotation] 引用直接提交失败：', err)
        }
      }

      function sendButtonOf(target) {
        if (!(target instanceof Element) || typeof target.closest !== 'function') return null
        var button = target.closest('button')
        if (!(button instanceof HTMLButtonElement)
          || button.closest('[data-composer-card]') === null) return null
        var label = button.getAttribute('aria-label')
        return label === '发送消息' || label === 'Send message' ? button : null
      }

      // 鼠标/触控发送不经过 textarea 的 Enter 路径。pointerdown 能覆盖宿主因
      // 空草稿而禁用的发送按钮；已有文字时只拼稿，后续 click 仍由宿主提交。
      function onSendPointerDown(e) {
        if (ui.quotes.length === 0 || e.button !== 0) return
        var button = sendButtonOf(e.target)
        if (button === null) return
        var wasDisabled = button.disabled
        if (!attachAndSend({ ctrlKey: false, metaKey: false }) || !wasDisabled) return
        e.preventDefault()
        e.stopPropagation()
        submitAttached()
      }

      // 键盘/辅助技术激活按钮时没有 pointerdown，以 detail=0 的 click 补齐。
      function onSendKeyboardClick(e) {
        if (e.detail !== 0 || ui.quotes.length === 0 || sendButtonOf(e.target) === null) return
        attachAndSend({ ctrlKey: false, metaKey: false })
      }
      document.addEventListener('pointerdown', onSendPointerDown, true)
      document.addEventListener('click', onSendKeyboardClick, true)

      // ---------- 渲染 ----------
      function iconButton(cls, icon, title, onClick) {
        var b = document.createElement('button')
        b.type = 'button'
        b.className = cls
        b.title = title
        b.appendChild(icon())
        b.addEventListener('click', function () { ignoreUntil = Date.now() + 80; onClick() })
        return b
      }

      function ghostButton(icon, label, title, disabled, onClick) {
        var b = document.createElement('button')
        b.type = 'button'
        b.className = 'dsh-ann-ghost'
        b.title = title
        if (icon !== null) b.appendChild(icon())
        b.appendChild(document.createTextNode(label))
        b.disabled = disabled === true
        b.addEventListener('click', function () { ignoreUntil = Date.now() + 80; onClick() })
        return b
      }

      function render() {
        host.textContent = ''
        ui.el = null
        if (ui.mode === 'actions') {
          var bar = document.createElement('div')
          bar.className = 'dsh-ann-bar'
          bar.style.left = ui.pos.left + 'px'
          bar.style.top = ui.pos.top + 'px'
          var already = ui.quotes.some(function (q) { return q.text === ui.quote && (q.sourceUrl || '') === (ui.source && ui.source.sourceUrl || '') })
          // PATCH(2026-08-14c): 单按钮制——图标恒无（v1.4.x i18n 适配：文案走
          // t()，「可留空 = 仅引用原文」提示见 annotateTitle 字典补充）。
          bar.appendChild(ghostButton(
            null,
            already ? t('actions.already') : t('actions.annotate'),
            already ? t('actions.alreadyTitle') : t('actions.annotateTitle'),
            already,
            enterEditing,
          ))
          host.appendChild(bar)
          ui.el = bar
        } else if (ui.mode === 'editing') {
          var card = document.createElement('div')
          card.className = 'dsh-ann-card'
          card.style.left = ui.pos.left + 'px'
          card.style.top = ui.pos.top + 'px'
          ui.el = card
          var head = document.createElement('div')
          head.className = 'dsh-ann-card-head'
          makeEditorDraggable(head, card)
          var title = document.createElement('div')
          title.className = 'dsh-ann-card-title'
          title.textContent = ui.editingId !== null ? t('edit.editTitle') : t('edit.addTitle')
          head.appendChild(title)
          head.appendChild(iconButton('dsh-ann-icon', ICONS.close, t('common.cancel'), closeToolbar))
          card.appendChild(head)
          var quote = document.createElement('div')
          quote.className = 'dsh-ann-quote'
          quote.textContent = truncate(quoteWithSource({ text: ui.quote, sourcePath: ui.source && ui.source.sourcePath }), 200)
          quote.title = quoteWithSource({ text: ui.quote, sourcePath: ui.source && ui.source.sourcePath })
          card.appendChild(quote)
          var ta = document.createElement('textarea')
          ta.className = 'dsh-ann-input'
          ta.placeholder = t('edit.placeholder')
          ta.value = ui.noteDraft
          ta.spellcheck = false
          ta.addEventListener('input', function () { ui.noteDraft = ta.value })
          ta.addEventListener('keydown', function (e) {
            if (e.key === 'Enter' && !e.shiftKey && !isImeKeyBlocked(e)) { e.preventDefault(); saveAnnotation() }
          })
          card.appendChild(ta)
          var row = document.createElement('div')
          row.className = 'dsh-ann-row'
          var cancel = document.createElement('button')
          cancel.className = 'dsh-ann-cancel'
          cancel.type = 'button'
          cancel.textContent = t('common.cancel')
          cancel.addEventListener('click', closeToolbar)
          var save = document.createElement('button')
          save.type = 'button'
          save.className = 'dsh-ann-action'
          save.appendChild(ICONS.check())
          save.appendChild(document.createTextNode(t('edit.save')))
          save.addEventListener('click', saveAnnotation)
          row.appendChild(cancel)
          row.appendChild(save)
          // PATCH(2026-08-14e): 编辑已有引用时提供「删除引用」（v2 加回）——删除入口
          // 平时在「输入框旁标签 → 悬浮面板」里，编辑态直接删更顺手。
          if (ui.editingId !== null) {
            var del = document.createElement('button')
            del.type = 'button'
            del.className = 'dsh-ann-cancel'
            del.style.cssText = 'color:#ff8a8a;border-color:rgba(255,107,107,.4);'
            del.textContent = t('edit.delete')
            del.addEventListener('click', function () {
              removeQuote(ui.editingId)
              closeToolbar()
            })
            row.appendChild(del)
          }
          card.appendChild(row)
          if (ui.error !== null) {
            var err = document.createElement('div')
            err.className = 'dsh-ann-error'
            err.textContent = ui.error
            card.appendChild(err)
          }
          host.appendChild(card)
          ta.focus()
          ta.setSelectionRange(ta.value.length, ta.value.length)
          requestAnimationFrame(function () {
            if (card.isConnected) positionEditor(card, ui.pos.left, ui.pos.top)
          })
        }
      }

      function positionEditor(card, left, top) {
        ui.pos = {
          left: Math.max(8, Math.min(left, window.innerWidth - card.offsetWidth - 8)),
          top: Math.max(8, Math.min(top, window.innerHeight - card.offsetHeight - 8)),
        }
        card.style.left = ui.pos.left + 'px'
        card.style.top = ui.pos.top + 'px'
      }

      function makeEditorDraggable(head, card) {
        var drag = null
        head.addEventListener('pointerdown', function (e) {
          if (e.button !== 0 || !e.isPrimary || e.target.closest('button')) return
          var r = card.getBoundingClientRect()
          drag = { id: e.pointerId, x: e.clientX - r.left, y: e.clientY - r.top }
          head.setPointerCapture(e.pointerId)
          e.preventDefault()
        })
        head.addEventListener('pointermove', function (e) {
          if (drag === null || e.pointerId !== drag.id) return
          positionEditor(card, e.clientX - drag.x, e.clientY - drag.y)
        })
        head.addEventListener('lostpointercapture', function () { drag = null })
      }

      // ---------- 引用标记 ----------
      var markersSig = null
      function markersSignature() {
        var parts = []
        for (var i = 0; i < ui.quotes.length; i++) {
          var q = ui.quotes[i]
          var range = locateQuote(q.text, q)
          if (range === null) { parts.push(q.id + ':gone'); continue }
          var rects = quoteRects(range, q)
          for (var c = 0; c < rects.length; c++) {
            var r = rects[c]
            if (r.width === 0 || r.height === 0) continue
            parts.push(q.id + ':' + Math.round(r.left) + ',' + Math.round(r.top) + ',' + Math.round(r.width) + ',' + Math.round(r.height))
          }
          if (rects.length > 0) parts.push(q.id + ':chip')
        }
        return parts.join('|')
      }

      function renderMarkers() {
        // 对整个标记层挖去输入框区域；滚动、尺寸变化时即使原文没动也要刷新。
        var composer = document.querySelector('[data-composer-card]')
        var r = composer !== null ? composer.getBoundingClientRect() : null
        overlay.style.clipPath = r !== null && r.width > 0 && r.height > 0
          ? 'polygon(evenodd, 0 0, 100% 0, 100% 100%, 0 100%, 0 0, '
            + r.left + 'px ' + r.top + 'px, ' + r.right + 'px ' + r.top + 'px, '
            + r.right + 'px ' + r.bottom + 'px, ' + r.left + 'px ' + r.bottom + 'px, '
            + r.left + 'px ' + r.top + 'px)'
          : 'none'
        var sig = markersSignature()
        if (sig !== markersSig) {
          markersSig = sig
          overlay.textContent = ''
          buildMarkers()
        }
      }

      function buildMarkers() {
        if (ui.quotes.length === 0) return
        // PATCH(2026-08-14e): 区域过滤——高亮/编号只渲染在对话可视区（composer 卡片
        // 顶部之上）。滚动后引用文本滚进输入栏区域时其 rect.top ≥ composerTop，
        // 跳过即可，fixed 层永远不落到输入栏上（z-index 高位也不会盖输入栏）。
        var composerTop = window.innerHeight
        var composerCard = document.querySelector('[data-composer-card]')
        if (composerCard !== null) {
          var cr = composerCard.getBoundingClientRect()
          if (cr.top > 0) composerTop = cr.top
        }
        var placed = []
        for (var i = 0; i < ui.quotes.length; i++) {
          var q = ui.quotes[i]
          var range = locateQuote(q.text, q)
          if (range === null) continue
          var rects = quoteRects(range, q)
          for (var c = 0; c < rects.length; c++) {
            var rect = rects[c]
            if (rect.width === 0 || rect.height === 0) continue
            if (rect.top >= composerTop) continue
            var hl = document.createElement('div')
            hl.className = 'dsh-ann-hl'
            hl.style.left = rect.left + 'px'
            hl.style.top = rect.top + 'px'
            hl.style.width = rect.width + 'px'
            hl.style.height = rect.height + 'px'
            overlay.appendChild(hl)
          }
          var anchor = null
          for (var k = 0; k < rects.length; k++) {
            var r = rects[k]
            if (r.width === 0 || r.height === 0) continue
            if (r.top > -8 && r.top < composerTop) { anchor = r; break }
          }
          // 引用文本整体滚出对话可视区（anchor 为 null）时不显示编号——
          // 不 fallback 到 rects[0]，否则编号会落到输入栏区域。
          if (anchor === null) continue
          if (anchor !== null) {
            var chip = document.createElement('div')
            chip.className = 'dsh-ann-num'
            chip.textContent = String(i + 1)
            var chipTop = anchor.top - 20
            if (chipTop < 4) chipTop = Math.min(anchor.top + 2, window.innerHeight - 22)
            if (chipTop < 4) chipTop = 4
            var chipLeft = Math.max(4, Math.min(anchor.left - 4, window.innerWidth - 24))
            var tries = 0
            while (tries < 12) {
              var clash = false
              for (var p = 0; p < placed.length; p++) {
                var bp = placed[p]
                if (Math.abs(bp.left - chipLeft) < 18 && Math.abs(bp.top - chipTop) < 18) {
                  clash = true
                  break
                }
              }
              if (!clash) break
              chipLeft += 18
              if (chipLeft > window.innerWidth - 24) { chipLeft = 4; chipTop += 18 }
              tries++
            }
            placed.push({ left: chipLeft, top: chipTop })
            chip.style.left = chipLeft + 'px'
            chip.style.top = chipTop + 'px'
            ;(function (q) {
              chip.addEventListener('click', function (ev) {
                ev.stopPropagation()
                openEditorFor(q)
              })
            })(q)
            overlay.appendChild(chip)
          }
        }
      }

      // ---------- 动作 ----------
      function captureAnchor(text) {
        var anchor = {
          range: null, seqKey: '', rowHead: '', textOffset: -1,
          ctxBefore: '', ctxAfter: '',
        }
        try {
          var sel = window.getSelection()
          if (sel === null || sel.isCollapsed || sel.rangeCount === 0) return anchor
          var live = sel.getRangeAt(0)
          var liveText = live.toString()
          // 选区文本与 settle 快照一致才持有 live range；不一致（选区微变、DOM
          // 被引用芯片等装饰改写）时也绝不返回全空锚——尽力抓行级锚点
          // （seqKey/rowHead），让 locateQuote 在锚点消息内宽松重定位。
          var textMatch = liveText.trim() === text
            || liveText.trim().replace(/\s+/g, ' ') === text.replace(/\s+/g, ' ')
          if (textMatch) {
            anchor.range = live.cloneRange()
          }
          var source = documentSourceOf(live.commonAncestorContainer)
          if (source !== null) {
            anchor.sourceUrl = source.sourceUrl
            anchor.sourcePath = source.sourcePath
            anchor.textOffset = offsetOfRangeInRow(source.root, live) + liveText.indexOf(text)
            return anchor
          }
          var node = live.commonAncestorContainer
          var el = node instanceof Element ? node : (node !== null ? node.parentElement : null)
          // 主视图锚 key 为 data-chat-anchor-key；focus-chat 视图为
          // data-focus-anchor-key，两者等价（消息 seq 锚定）。
          while (el !== null && el !== document.body
            && !el.hasAttribute('data-chat-anchor-key')
            && !el.hasAttribute('data-focus-anchor-key')) {
            el = el.parentElement
          }
          if (el !== null
            && (el.hasAttribute('data-chat-anchor-key') || el.hasAttribute('data-focus-anchor-key'))) {
            anchor.seqKey = el.getAttribute('data-chat-anchor-key')
              || el.getAttribute('data-focus-anchor-key') || ''
            if (textMatch) {
              var itemText = el.textContent || ''
              var realOff = offsetOfRangeInRow(el, live)
              if (realOff >= 0) {
                anchor.textOffset = realOff
                anchor.ctxBefore = itemText.slice(Math.max(0, realOff - 24), realOff)
                anchor.ctxAfter = itemText.slice(realOff + text.length, realOff + text.length + 24)
              }
            }
          }
          var row = assistantRowOf(live.commonAncestorContainer)
          if (row !== null) {
            anchor.rowHead = (row.textContent || '').slice(0, 24)
          }
        } catch (_) { /* 抓取失败则保持空锚 */ }
        return anchor
      }

      function enterEditing() {
        ui.mode = 'editing'
        ui.noteDraft = ''
        ui.error = null
        ui.editingId = null
        ui.pendingAnchor = captureAnchor(ui.quote)
        render()
      }

      /** 点击角标数字 → 重新打开该引用的编辑面板（预填引用内容，可修改后保存）。 */
      function openEditorFor(q) {
        ui.mode = 'editing'
        ui.quote = q.text
        ui.source = q
        ui.noteDraft = q.note !== undefined ? q.note : ''
        ui.error = null
        ui.editingId = q.id
        ui.pendingAnchor = null
        var range = locateQuote(q.text, q)
        var rect = range !== null ? range.getBoundingClientRect() : null
        ui.pos = rect !== null && rect.width > 0
          ? placeAbove(rect, 40)
          : { left: 8, top: 8 }
        render()
      }

      /** 组装引用块；只有附带正文时才添加「提问：」分隔标记。 */
      function buildBlock(hasQuestion) {
        var n = ui.quotes.length
        var parts = ui.quotes.map(function (q, i) {
          var s = (i + 1) + '. ' + quoteWithSource(q).replace(/\n/g, '\n   ')
          if (q.note !== undefined && q.note.trim() !== '') {
            s += '\n   ' + t('block.notePrefix') + q.note.replace(/\n/g, '\n    ')
          }
          return s
        })
        return t(hasQuestion ? 'block.head' : 'block.headOnly', { n: n }) + '\n\n'
          + parts.join('\n\n')
          + '\n\n' + t(hasQuestion ? 'block.format' : 'block.formatOnly', { n: n })
          + (hasQuestion ? '\n\n' + t('block.marker') : '')
      }

      // PATCH(2026-09-25-queue-quote)：原 shouldAttachForEnter（Cmd/Ctrl+Enter 有文字
      // 就不拼稿、整条交回 composer）随拼稿/接管解耦删除——它把插队消息的引用一并
      // 丢了。拼稿恒做，接管与否由 onKeyDown 按 attachWasPureQuote 判定。

      /** 裸斜杠开头的草稿按宿主约定是命令（/goal、/model 等）：
       *  宿主输入机靠「草稿以命令 token 开头」维持命令声明。 */
      function isCommandDraft(draft) {
        return draft.trimStart().charAt(0) === '/'
      }

      // PATCH(2026-09-18-skill-catalog): 「以 / 开头一律当宿主命令」的守卫过宽——技能的
      // /name 手势不是宿主命令。宿主 dsh-tool-skill 的 invokedSkillNames 用
      // SKILL_GESTURE = /(^|\s)\/([a-z0-9]+(?:-[a-z0-9]+)*)(?=\s|$)/g 扫描用户消息的每个
      // 文本块，引用块追加在命令之后不影响它识别；宿主输入机也只在
      // draft.trim().startsWith("/") 时才 adjudicate，未被认领（claim）的斜杠草稿最终
      // 原样作为普通消息发出（onAdjudicated → detachedEffects，token 留在文本里），
      // 技能照常加载。真命令（/goal、/model 等）与被 '/' 菜单认领的草稿依旧放行。
      // 清单取自 remote.skills，与官方 dsh-client-ui-skill 的 '/' 数据源同一个服务。
      // 该服务由 dsh-api-gateway 按命名空间动态挂载（new Service(ctx, 'remote.'+ns)），
      // 未连接或未挂载时压根不存在，所以用 ctx.get 可选查询而不是写进 exports.inject：
      // 硬注入会让整个引用插件在清单缺席时不加载（cordis「Required: the plugin does
      // not load while the service is absent」），代价远大于「这一条不带引用」的保守回退。
      var skillNames = null
      var skillNamesAt = 0
      var skillNamesFetching = false
      var skillNamesAbort = null
      var SKILL_TTL_MS = 60000
      // token 语法与宿主 SKILL_GESTURE 一致：这种形态之外宿主根本不认作技能手势。
      var SKILL_TOKEN = /^\s*\/([a-z0-9]+(?:-[a-z0-9]+)*)(?=\s|$)/

      /** 拉取本会话可调用的技能名（异步、TTL 内不重复请求、失败保留旧缓存）。
       *  卸载安全由 disposer 里的 skillNamesAbort 负责（op59）：回调只会写闭包内
       *  的两个变量，不碰 DOM，故这里不再引用 dispose 组的 disposed 标志。 */
      function refreshSkillNames() {
        if (skillNamesFetching) return
        if (skillNames !== null && Date.now() - skillNamesAt < SKILL_TTL_MS) return
        var remote
        try {
          remote = typeof ctx.get === 'function' ? ctx.get('remote.skills') : undefined
        } catch (_) { return }
        if (remote === null || remote === undefined || typeof remote.list !== 'function') return
        var sessionId = currentSessionId()
        if (typeof sessionId !== 'string' || sessionId === '') return
        var ctrl = typeof AbortController === 'function' ? new AbortController() : null
        skillNamesFetching = true
        skillNamesAbort = ctrl
        var done = function () {
          skillNamesFetching = false
          if (skillNamesAbort === ctrl) skillNamesAbort = null
        }
        try {
          Promise.resolve(
            remote.list({ sessionId: sessionId }, ctrl === null ? undefined : ctrl.signal),
          ).then(function (res) {
            done()
            var value = res !== null && res !== undefined && res.ok === true ? res.value : undefined
            var list = value !== null && value !== undefined ? value.skills : undefined
            if (!Array.isArray(list)) return
            var next = []
            for (var i = 0; i < list.length; i++) {
              var nm = list[i] !== null && list[i] !== undefined ? list[i].name : undefined
              if (typeof nm === 'string' && nm !== '' && next.indexOf(nm) === -1) next.push(nm)
            }
            skillNames = next
            skillNamesAt = Date.now()
            console.log('[annotation] 技能清单就绪（' + next.length + ' 个）')
          }, function () { done() })
        } catch (err) {
          done()
          console.warn('[annotation] 技能清单拉取异常：', err)
        }
      }

      /** 斜杠草稿能否携带引用：命中技能清单返回技能名，否则 null（= 原样放行）。 */
      function slashSkillName(st, draft) {
        if (st !== null && st !== undefined) {
          // 被 '/' 菜单认领的命令（beginCommand）或输入机正忙：草稿归宿主，不抢。
          if (st.claim !== null && st.claim !== undefined) return null
          if (st.phase === 'claimed' || st.phase === 'submitting' || st.phase === 'adjudicating') return null
        }
        var m = SKILL_TOKEN.exec(draft)
        if (m === null) return null
        // 清单还没回来：预热一次并保守放行（下一条消息即可携带）。
        if (skillNames === null) { refreshSkillNames(); return null }
        return skillNames.indexOf(m[1]) !== -1 ? m[1] : null
      }

      /** 剥掉「后置追加未遂」的纯引用块（headOnly + formatOnly，无「提问：」标记）。
       *  0.3.2 的补剥只锚草稿头部，覆盖不到技能拼稿产生的尾部形态。 */
      function stripTrailingBlock(draft) {
        return draft.replace(
          /\n*(?:我引用了以下|I annotated the following)[\s\S]*?(?:请按「Annotation N：…」的格式，逐条回应以上引用。|Please respond to each annotation above in the format "Annotation N: …".)\n*/g,
          '',
        )
      }

      /** 从草稿中剥离残留的旧引用块（"我引用了以下…提问：" / "I annotated the
       *  following…Ask:" 整块），保留用户自己的输入。残留来源：上次 setDraft 后
       *  提交失败/未触发，旧块留在草稿里而引用集已变——若不剥离，旧块会随下一条
       *  消息重复发出且内容过期。PATCH(2026-08-14c): 竞态修复——剥离替代跳过；
       *  全局替换一次剥净多个残留；双语哨兵适配 v1.4 i18n。非贪婪匹配到第一个
       *  块尾标记：块拼在草稿最前，用户输入在其后，第一个标记必属块尾。 */
      function stripOldBlock(draft) {
        if (!hasAnnotationBlock(draft)) return draft
        return draft.replace(
          /\n*(?:我引用了以下|I annotated the following)[\s\S]*?\n\n(?:提问：|Ask:)(?:\n+)?/g,
          '',
        )
      }

      /** 提交前把引用块拼进 composer 草稿（随回车一起发送）。
       *  返回 true 表示引用块已在草稿中（本次刚拼入，或之前已拼入未发送）。 */
      // PATCH(2026-09-18-attach-debug): 引用丢失排障。attachAndSend 的静默早退此前只
      // return false、不留任何痕迹，于是「气泡带『引用 ×N』标记、消息里却没有引用块」
      // 无从定位。仅在确有待发引用时告警，正常无引用路径不刷屏。
      // PATCH(2026-09-25-queue-quote)：本次拼稿前草稿是否为空（纯引用）。Cmd/Ctrl+Enter
      // 只有纯引用才由插件接管直发（issue #17）；带文字时放行 composer 走宿主
      // Queue / Steer，引用块随草稿一起由宿主提交。
      var attachWasPureQuote = false
      function annDbgAttach(why) {
        try {
          var n = (typeof ui !== 'undefined' && ui && ui.quotes && ui.quotes.length) ? ui.quotes.length : 0
          if (n > 0) console.warn('[annotation] 拼稿早退（待发引用 ' + n + ' 条）：' + why)
        } catch (_) {}
      }
      function attachAndSend(e) {
        attachWasPureQuote = false
        var current = currentSessionId()
        if (current === undefined) { annDbgAttach('currentSessionId() 解析不到当前会话 id'); return false }
        // PATCH(2026-09-18-team-sessions): 同屏可能出现多块 composer——Agent Team 面板把
        // teammate 换进主视图，右侧栏 ui-subagent 又渲染同一套 [data-composer-card]（对
        // continuable 子代理还可写）。而 currentSessionId() 只认主视图，宿主 DOM 又没有
        // 把 composer 卡片绑定到会话的标记（无 data-session/data-conversation），无法判定
        // 用户实际在敲哪一块。歧义时失败关闭：不拼稿、原样交回宿主发送——宁可少一次引用，
        // 也不把引用块写进错误会话的草稿。
        if (document.querySelectorAll('[data-composer-card]').length > 1) { annDbgAttach('同屏多块 composer，歧义失败关闭（op64 护栏）'); return false }
        try {
          var scoped = sessions.scope(current)
          if (scoped === undefined) { annDbgAttach('sessions.scope(current) 返回 undefined'); return false }
          var shell = ctx.conversation.input.for(scoped)
          var st = shell.state.getSnapshot()
          var draft = st.draft || ''
          // 斜杠命令不拼引用（issue #20）：引用块前置会破坏命令 token 前缀，
          // 宿主 watchClaim 释放声明后 /goal 被降级为普通消息；后置追加则会
          // 把块原样并入命令参数。命令草稿原样放行，引用保留待下一条消息。
          // PATCH(2026-09-18-skill-catalog): 例外是技能手势——/name 的参数是自由文本，
          // 引用块后置追加既不破坏 token 前缀（宿主服务端按全文扫描手势识别），也不会
          // 被当作宿主命令参数消费；只有首 token 命中技能清单才拼，未命中维持原行为。
          if (isCommandDraft(draft)) {
            var skillName = slashSkillName(st, draft)
            if (skillName !== null) {
              // 先剥残留（头部标记块 + 尾部纯引用块），再把 headOnly 纯引用块（无
              // 「提问：」标记）追加到命令之后——命令文本自身保持原样含 token 前缀。
              var cmd = stripTrailingBlock(stripOldBlock(draft)).replace(/\s+$/, '')
              shell.setDraft(cmd + '\n\n' + buildBlock(false))
              attachWasPureQuote = false
              annotationAttached = true
              console.log('[annotation] 斜杠技能 ' + skillName + ' 已随消息追加引用（' + ui.quotes.length + ' 条）')
              return true
            }
            showToast(t('toast.skipCommand'))
            annDbgAttach('isCommandDraft：斜杠命令不拼引用')
            return false
          }
          // PATCH(2026-08-14c): 残留块不跳过、剥离后重拼——上次追加未发送时草稿
          // 里的旧块可能已过期（引用集已变），stripOldBlock 剥旧块再拼新块，
          // 用户已输入文字保留在块后；发送确认制清理（watchInputDraft）不受影响。
          var clean = stripOldBlock(draft)
          // ab594842：上游 v1.4.11 纯引用块走 block.headOnly/formatOnly（无「提问：」
          // 标记），不在 stripOldBlock 的标记正则内，需按首尾文案补剥。
          // PATCH(2026-09-17-keep-question)：补剥只对「确实以引用块首句开头」的草稿生效，
          // 且剥不动就保持原样。此前写法对任何草稿（包括只有用户自己输入、根本没有残留块
          // 的正常情况）都会落到 else 分支把 clean 置空，结果是把用户输入整条吞掉，
          // 只发出一条纯引用（0.3.1 用户实测：前端里自己打的字消失）。
          if (clean === draft && /^\n*(?:我引用了以下|I annotated the following)/.test(draft)) {
            var peeled = draft.replace(
              /^\n*(?:我引用了以下|I annotated the following)[\s\S]*?(?:请按「Annotation N：…」的格式，逐条回应以上引用。|Please respond to each annotation above in the format "Annotation N: …".)\n*/,
              '',
            )
            if (peeled !== draft) clean = peeled
          }
          var hasQuestion = clean.trim() !== ''
          var block = buildBlock(hasQuestion)
          shell.setDraft(block + (hasQuestion ? '\n' + clean : ''))
          attachWasPureQuote = !hasQuestion
          annotationAttached = true
          console.log('[annotation] 引用块已拼入草稿，回车将随消息发送（' + ui.quotes.length + ' 条）')
          return true
        } catch (err) {
          console.warn('[annotation] 引用拼稿失败：', err)
          showToast(t('toast.attachFail') + (err && err.message ? err.message : err))
          return false
        }
      }

      // 引用保存/删除完成后把焦点还给 composer 输入框（光标在末尾），
      // 用户可直接回车发送，无需再点一下输入框。
      // preventScroll：长会话中选中文字时输入框可能在视口外，默认 focus
      // 会强制滚动页面（视觉上"卡一下"）；延迟一帧让卡片关闭动画先完成，
      // 焦点回归更平滑。
      function focusComposer() {
        var input = document.querySelector('[data-composer-card] [data-composer-input]')
        if (!(input instanceof HTMLElement) || !input.isContentEditable) return
        requestAnimationFrame(function () {
          // PATCH(2026-09-18-team-sessions): 插件自身卸载后 composer 仍 connected，
          // 原守卫拦不住——会 focus + selectAllChildren 改宿主焦点/选区。补 disposed 守卫。
          if (disposed || !input.isConnected) return
          input.focus({ preventScroll: true })
          var selection = window.getSelection()
          if (selection !== null) {
            selection.selectAllChildren(input)
            selection.collapseToEnd()
          }
        })
      }

      function saveAnnotation() {
        var text = ui.quote
        if (text === '') { ui.error = t('error.noSelection'); render(); return }
        var note = ui.noteDraft.trim()
        // 编辑已有引用（点击角标进入）：按 id 更新引用内容。
        if (ui.editingId !== null) {
          for (var ei = 0; ei < ui.quotes.length; ei++) {
            if (ui.quotes[ei].id === ui.editingId) {
              ui.quotes[ei].note = note
              ui.editingId = null
              ui.pendingAnchor = null
              ui.noteDraft = ''
              ui.error = null
              writeCurrentPendingQuotes()
              closeToolbar()
              updateChip()
              renderMarkers()
              focusComposer()
              return
            }
          }
          ui.editingId = null
        }
        if (!ui.quotes.some(function (q) { return q.text === text && (q.sourceUrl || '') === (ui.pendingAnchor && ui.pendingAnchor.sourceUrl || '') })) {
          var a = ui.pendingAnchor || { range: null, seqKey: '', rowHead: '', textOffset: -1, ctxBefore: '', ctxAfter: '' }
          ui.quotes.push({
            id: 'q-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 6),
            text: text,
            note: note,
            range: a.range,
            ...(a.sourceUrl ? { sourceUrl: a.sourceUrl, sourcePath: a.sourcePath } : {}),
            seqKey: a.seqKey,
            rowHead: a.rowHead,
            textOffset: a.textOffset,
            ctxBefore: a.ctxBefore,
            ctxAfter: a.ctxAfter,
          })
        }
        writeCurrentPendingQuotes()
        ui.pendingAnchor = null
        ui.noteDraft = ''
        ui.error = null
        closeToolbar()
        updateChip()
        renderMarkers()
        focusComposer()
      }

      function removeQuote(id) {
        ui.quotes = ui.quotes.filter(function (q) { return q.id !== id })
        writeCurrentPendingQuotes()
        updateChip()
        render()
        renderMarkers()
        // 面板正在显示时同步重建：否则删掉的条目还留在面板里，必须重新 hover 才消失。
        if (tipLayer.childNodes.length > 0) showChipTip()
      }

      function closeToolbar() {
        if (ui.mode === 'closed') return
        clearSettle()
        // PATCH(2026-08-14e): 塌缩残留选区——编辑已有引用时（chip 打开的编辑卡），
        // 原文本选区在保存后仍存在；若不塌缩，selectionchange 的 settle 会在关闭
        // 后 ~250ms 重新弹出工具条，表现为「取消/右上角 X 不生效」（新建引用时点
        // 「引用」按钮已塌缩选区，故无此问题）。
        try {
          var sel = window.getSelection()
          if (sel !== null && !sel.isCollapsed) sel.removeAllRanges()
        } catch (_) { /* 选区操作失败忽略 */ }
        ui.mode = 'closed'
        ui.error = null
        ui.busy = false
        ui.lastKey = ''
        ui.editingId = null
        render()
      }

      // ---------- 输入框旁的引用标签（N 条引用 · 悬浮看全部内容） ----------
      var chipLayer = document.createElement('div')
      chipLayer.setAttribute('data-annotation-chip', '')
      chipLayer.style.cssText = 'position:fixed;z-index:1150;display:none;align-items:center;gap:4px;height:22px;padding:0 10px;border-radius:11px;border:1px solid var(--dsw-alias-border-inverted);background:var(--dsw-specific-menu,#2c2c2e);box-shadow:var(--dsw-shadow-lv3);font-family:var(--dsw-font-family,system-ui);font-size:11px;color:var(--dsw-alias-label-primary);cursor:default;animation:dsh-ann-pop .12s var(--ds-ease-in-out, ease);'
      document.body.appendChild(chipLayer)
      // PATCH(2026-09-03): 悬浮卡右边溢出修复说明——三处 tip（showChipTip /
      // 气泡「引用 ×N」标签 / 回复「Annotation N」芯片）都 append 到这个
      // body 直下的 tipLayer；它不带 [data-annotation-for-dsh]，不继承
      // border-box，content-box 下 padding+border 让实际宽比标称大 26px，
      // 钳位按标称宽算 → 宽布局气泡贴右缘时卡片溢出屏幕右侧被裁。
      // 对策：cssText 补 box-sizing:border-box + 钳位用 offsetWidth 实测。
      var tipLayer = document.createElement('div')
      tipLayer.setAttribute('data-annotation-tip-layer', '')
      document.body.appendChild(tipLayer)

      // PATCH(2026-08-17): chipLayer 是 fixed 层，不能只在「引用数量变化」时定位一次。
      // DSH composer 的 textarea 多行增长时，composer card 会从底部向上变高；若不重新
      // 计算 card.top，标签就留在旧坐标，随后被输入框外壳「吞」进去并遮挡第一行内容。
      // ResizeObserver 负责捕获自动增高，input/DOM 监听负责覆盖无 ResizeObserver 或
      // composer 被 React 替换的情况；所有更新都合并到下一帧，避免输入时反复重排。
      var chipComposerCard = null
      var chipResizeObserver = null
      var chipPositionFrame = null

      function scheduleChipUpdate() {
        if (chipPositionFrame !== null) return
        chipPositionFrame = requestAnimationFrame(function () {
          chipPositionFrame = null
          updateChip()
        })
      }

      function observeChipComposer(card) {
        if (card === chipComposerCard) return
        if (chipResizeObserver !== null) {
          chipResizeObserver.disconnect()
          chipResizeObserver = null
        }
        chipComposerCard = card
        if (card !== null && typeof ResizeObserver === 'function') {
          chipResizeObserver = new ResizeObserver(function () {
            scheduleChipUpdate()
          })
          chipResizeObserver.observe(card)
          // 某些布局只改变输入滚动区/textarea 的尺寸，外层 card 的 ResizeObserver
          // 可能收不到变化；一并观察这两个节点，兼容不同 DSH snapshot。
          var inputScroll = card.querySelector('[data-input-scroll]')
          if (inputScroll !== null) chipResizeObserver.observe(inputScroll)
          // PATCH(2026-09-01-lexical): 输入面是 textarea 或 contenteditable，两者都观察
          var inputBox = card.querySelector('textarea')
            || card.querySelector('[contenteditable="true"]')
          if (inputBox !== null) chipResizeObserver.observe(inputBox)
        }
      }

      function onComposerInput(e) {
        var target = e.target
        if (!(target instanceof Element) || target.closest('[data-composer-card]') === null) return
        scheduleChipUpdate()
      }
      document.addEventListener('input', onComposerInput, true)

      function updateChip() {
        // PATCH(2026-09-18-skill-catalog): 引用集一变（保存成功／删除／按会话恢复）就
        // 预热技能清单——回车判定是同步的，等按下回车才去拉清单这一条必然错过。
        if (ui.quotes.length > 0) refreshSkillNames()
        var card = document.querySelector('[data-composer-card]')
        observeChipComposer(ui.quotes.length > 0 ? card : null)
        if (ui.quotes.length === 0) {
          chipLayer.style.display = 'none'
          tipLayer.textContent = ''
          return
        }
        chipLayer.textContent = ''
        var b = document.createElement('b')
        b.style.cssText = 'color:var(--dsw-alias-text-accent,#4c9aff);font-weight:700;'
        b.textContent = String(ui.quotes.length)
        chipLayer.appendChild(b)
        chipLayer.appendChild(document.createTextNode(t('chip.count')))
        if (card === null) { chipLayer.style.display = 'none'; return }
        var r = card.getBoundingClientRect()
        if (r.width === 0 || r.height === 0 || r.right <= 0 || r.bottom <= 0
          || r.left >= window.innerWidth || r.top >= window.innerHeight) {
          chipLayer.style.display = 'none'
          return
        }
        var w = chipLayer.offsetWidth || 80
        var h = chipLayer.offsetHeight || 22
        chipLayer.style.left = Math.max(8, r.right - w - 12) + 'px'
        chipLayer.style.top = Math.max(8, r.top - h - 8) + 'px'
        chipLayer.style.display = 'flex'
      }

      // 悬停宽限：标签与面板间有间隙，鼠标跨越间隙的瞬间不在任何元素上——
      // 离开后给 250ms 宽限期，期间进入面板则取消关闭（官方 HoverCard 的
      // pointer-grace 同款思路），同时杜绝闪烁循环。
      var hoverGrace = null
      function scheduleHide() {
        if (hoverGrace !== null) clearTimeout(hoverGrace)
        hoverGrace = setTimeout(function () {
          hoverGrace = null
          tipLayer.textContent = ''
        }, 250)
      }
      function cancelHide() {
        if (hoverGrace !== null) { clearTimeout(hoverGrace); hoverGrace = null }
      }
      chipLayer.addEventListener('mouseenter', function () { cancelHide(); showChipTip() })
      chipLayer.addEventListener('mouseleave', scheduleHide)
      tipLayer.addEventListener('mouseenter', cancelHide)
      tipLayer.addEventListener('mouseleave', scheduleHide)

      function showChipTip() {
        if (ui.quotes.length === 0) return
        tipLayer.textContent = ''
        var el = document.createElement('div')
        el.className = 'dsh-ann-tip'
        el.style.cssText = 'position:fixed;box-sizing:border-box;z-index:1160;width:300px;max-width:calc(100vw - 16px);padding:10px 12px;border-radius:12px;border:1px solid var(--dsw-alias-border-inverted);background:var(--dsw-specific-menu,#2c2c2e);box-shadow:var(--dsw-shadow-lv3);font-family:var(--dsw-font-family,system-ui);font-size:12px;color:var(--dsw-alias-label-primary);'
        var head = document.createElement('div')
        head.style.cssText = 'font-weight:600;margin-bottom:6px;'
        head.textContent = t('tip.title', { n: ui.quotes.length })
        el.appendChild(head)
        for (var i = 0; i < ui.quotes.length; i++) {
          var q = ui.quotes[i]
          var item = document.createElement('div')
          item.style.cssText = 'padding:6px 0;border-top:1px solid var(--dsw-alias-border-strong,#444);'
          var num = document.createElement('span')
          num.style.cssText = 'display:inline-flex;align-items:center;justify-content:center;min-width:16px;height:16px;margin-right:6px;border-radius:8px;background:var(--dsw-alias-text-accent,#4c9aff);color:#fff;font-size:10px;font-weight:700;'
          num.textContent = String(i + 1)
          var body = document.createElement('span')
          body.style.cssText = 'font-size:11px;line-height:1.5;color:var(--dsw-alias-label-tertiary);'
          body.textContent = truncate(quoteWithSource(q), 100)
          item.appendChild(num)
          item.appendChild(body)
          if (q.note !== undefined && q.note.trim() !== '') {
            var note = document.createElement('div')
            note.style.cssText = 'font-size:11px;color:var(--dsw-alias-label-secondary);margin:2px 0 0 22px;word-break:break-word;'
            note.textContent = t('tip.notePrefix') + truncate(q.note, 60)
            item.appendChild(note)
          }
          var del = document.createElement('button')
          del.type = 'button'
          del.textContent = t('tip.del')
          del.style.cssText = 'margin-left:8px;background:transparent;border:1px solid rgba(255,107,107,.4);color:#ff8a8a;border-radius:6px;font-size:10px;cursor:pointer;padding:1px 6px;'
          ;(function (qid) {
            del.addEventListener('click', function (ev) {
              ev.stopPropagation()
              removeQuote(qid)
            })
          })(q.id)
          item.appendChild(del)
          el.appendChild(item)
        }
        tipLayer.appendChild(el)
        var r2 = chipLayer.getBoundingClientRect()
        var w2 = el.offsetWidth || 300
        var h2 = el.offsetHeight || 120
        var left = Math.max(8, Math.min(r2.left, window.innerWidth - w2 - 8))
        var top = r2.top - h2 - 6
        if (top < 8) top = r2.bottom + 6
        el.style.left = left + 'px'
        el.style.top = Math.max(8, top) + 'px'
        el.style.width = w2 + 'px'
      }

      // ---------- 发送完成监听（草稿从有内容变空 → 清空引用集） ----------
      var inputUnsub = null
      // 仅当引用块真正拼入过草稿（用户按过回车）才在草稿清空时清除引用，
      // 避免普通草稿编辑（打字后删字）误触发「已发送」判定而清空引用集。
      var annotationAttached = false
      var inputWatchTimer = null
      function tryWatchInputDraft(id) {
        try {
          var sc = sessions.scope(id)
          if (sc === undefined) return false
          var sh = ctx.conversation.input.for(sc)
          if (sh === undefined || sh === null || typeof sh.state.subscribe !== 'function') return false
          var hadDraft = false
          inputUnsub = sh.state.subscribe(function () {
            var d = (sh.state.getSnapshot().draft || '').trim()
            var wasHad = hadDraft
            hadDraft = d !== ''
            if (ui.quotes.length === 0) return
            // 发送完成：草稿从有内容变空 → 脚标消失、编号下次从 1 开始；
            // 同时在刚发出的用户消息气泡上贴「N 条引用」标签。
            if (wasHad && d === '' && annotationAttached) {
              var sentItems = ui.quotes.map(function (q) {
                return { text: quoteWithSource(q), note: q.note || '' }
              })
              ui.quotes = []
              annotationAttached = false
              writeCurrentPendingQuotes()
              tipLayer.textContent = ''
              updateChip()
              renderMarkers()
              pendingDeco.push({ items: sentItems })
              kickDecorate()
            }
          })
          return true
        } catch (_) { inputUnsub = null; return false }
      }
      // 发送清空只认这里的「草稿有→空」迁移（装饰扫描不再兜底，见 decorateAll）。
      // 插件可能先于会话加载完成：current 未定、scope/input 尚不可用时订阅会失败，
      // 必须每秒重试直到挂上，否则一次发送的清空被漏掉，已发送的引用会永远留在
      // 待发送集里，之后每次 Enter 都重新拼进草稿。
      function watchInputDraft() {
        if (inputWatchTimer !== null) { clearInterval(inputWatchTimer); inputWatchTimer = null }
        if (typeof inputUnsub === 'function') { inputUnsub(); inputUnsub = null }
        var id = currentSessionId()
        if (id !== undefined && tryWatchInputDraft(id)) return
        inputWatchTimer = setInterval(function () {
          var cur = currentSessionId()
          if (cur !== undefined && tryWatchInputDraft(cur)) {
            clearInterval(inputWatchTimer)
            inputWatchTimer = null
          }
        }, 1000)
      }

      /** 把引用块文本从用户消息气泡里藏掉（模型消息内容不受影响）：
       *  用户气泡是纯文本渲染（MessageText，单个文本节点），
       *  找到最后一个「\n提问：」（老格式回退「\n问题：」），
       *  保留其后的用户问题，整块引用文本从 DOM 移除。
       *  返回是否成功（内容未渲染完时返回 false，轮询稍后重试）。 */
      function hideAnnotationBlock(row) {
        try {
          var bubble = row.querySelector('[class*="bubble"]')
          if (bubble === null) return false
          var nodes = []
          var full = ''
          var walker = document.createTreeWalker(bubble, NodeFilter.SHOW_TEXT)
          var n
          while ((n = walker.nextNode()) !== null) {
            // PATCH(2026-09-25-redecorate)：跳过插件自贴标签的文本节点。宿主重建
            // 文本后重手术时它会混进 full，破坏 annotationOnly 的 endsWith 判定
            // （尾部变成「引用 ×1」）与 marker 切块定位。
            var owner = n.parentElement
            if (owner !== null && owner.closest('[data-annotation-bubble-tag]') !== null) continue
            nodes.push(n)
            full += n.nodeValue || ''
          }
          // 纯引用用完整首尾文案识别，避免原文中的「提问：」被误当成正文分隔符。
          var annotationOnly = ['zh', 'en'].some(function (lang) {
            return full.indexOf(dictVal(lang, 'block.headOnly')) === 0
              && full.trimEnd().endsWith(dictVal(lang, 'block.formatOnly'))
          })
          if (annotationOnly) {
            nodes.forEach(function (node) { node.nodeValue = '' })
            return true
          }
          // 标记定位：当前语言优先（zh「提问：」/ en「Ask:」，均先带「\n」再裸匹配），
          // 另兼容另一语言与「问题：」老格式，保证历史消息跨语言切换可解析。
          var markers = blockMarkers()
          var marker = -1
          var markerStr = ''
          for (var p = 0; p < markers.length && marker === -1; p++) {
            var idx = full.lastIndexOf(markers[p])
            if (idx !== -1) { marker = idx; markerStr = markers[p] }
          }
          if (marker === -1) {
            // PATCH(2026-09-18-skill-catalog): 技能手势的引用块是「追加在命令之后」的
            // headOnly 形态（无「提问：」标记）：既不在 annotationOnly 的开头判据里，
            // 也没有 marker 可切。这里按「\n\n + headOnly 起、formatOnly 收尾」定位，
            // 切掉尾部块并保留命令文本——否则气泡会被裸协议文本占满，「引用 ×N」标签
            // 也贴不上（items 优先取发送暂存，历史行由 parseItemsFromBubble 兜底）。
            var cut = -1
            var cutLangs = ['zh', 'en']
            for (var ci = 0; ci < cutLangs.length; ci++) {
              var tailHead = '\n\n' + dictVal(cutLangs[ci], 'block.headOnly')
              var at = full.lastIndexOf(tailHead)
              if (at === -1) continue
              if (!full.trimEnd().endsWith(dictVal(cutLangs[ci], 'block.formatOnly'))) continue
              cut = at
              break
            }
            if (cut === -1) return false
            var cpos = 0
            var cutDone = false
            for (var cj = 0; cj < nodes.length && !cutDone; cj++) {
              var clen = (nodes[cj].nodeValue || '').length
              if (cut < cpos + clen) {
                nodes[cj].nodeValue = (nodes[cj].nodeValue || '').slice(0, cut - cpos).replace(/\s+$/, '')
                for (var ck = nodes.length - 1; ck > cj; ck--) {
                  if (nodes[ck].parentNode !== null) nodes[ck].parentNode.removeChild(nodes[ck])
                }
                cutDone = true
              }
              cpos += clen
            }
            if (!cutDone) return false
            var cutBubble = row.querySelector('[class*="bubble"]')
            if (cutBubble !== null) {
              var cEmpties = cutBubble.querySelectorAll('div,span,p')
              for (var ce = 0; ce < cEmpties.length; ce++) {
                var cel = cEmpties[ce]
                if (cel.parentNode !== null && (cel.textContent || '').trim() === '') cel.remove()
              }
            }
            return true
          }
          // 连同分隔标记一起切掉，保留其后的问题。
          var skip = markerStr.length
          // 定位到具体文本节点。
          var pos = 0
          var ti = -1
          var inner = 0
          for (var j = 0; j < nodes.length; j++) {
            var len = (nodes[j].nodeValue || '').length
            if (marker < pos + len) { ti = j; inner = marker - pos; break }
            pos += len
          }
          if (ti === -1) return false
          // 去掉标记及其前的所有内容，保留其后的问题。
          nodes[ti].nodeValue = (nodes[ti].nodeValue || '').slice(inner + skip).replace(/^\s+/, '')
          for (var m2 = ti - 1; m2 >= 0; m2--) {
            if (nodes[m2].parentNode !== null) nodes[m2].parentNode.removeChild(nodes[m2])
          }
          // 清理空元素。
          var empties = bubble.querySelectorAll('div,span,p')
          for (var e = 0; e < empties.length; e++) {
            var em = empties[e]
            if (em.parentNode !== null && (em.textContent || '').trim() === '') em.remove()
          }
          return true
        } catch (err) {
          console.warn('[annotation] 气泡隐藏手术失败：', err)
          return false
        }
      }

      /** 从气泡文本反解析引用条目（用于刷新后旧消息的 hover 内容）。 */
      function parseItemsFromBubble(row) {
        try {
          var b = row.querySelector('[class*="bubble"]')
          var text = (b ? b.textContent : '') || ''
          var mi = -1
          for (var mk = 0; mk < PARSE_MARKERS.length; mk++) {
            var pmi = text.lastIndexOf(PARSE_MARKERS[mk])
            if (pmi > mi) mi = pmi
          }
          if (mi !== -1) text = text.slice(0, mi)
          var nl = text.indexOf('\n\n')
          var body = nl === -1 ? '' : text.slice(nl + 2)
          var out = []
          var parts = body.split('\n\n')
          for (var i = 0; i < parts.length; i++) {
            var mm = /^(\d+)\.\s*([\s\S]*)$/.exec(parts[i])
            if (mm === null) continue
            var item = mm[2]
            var note = ''
            var nm = /\n\s*(?:引用：|Note:)\s*([\s\S]*)$/.exec(item)
            if (nm !== null) { note = nm[1].trim(); item = item.slice(0, nm.index) }
            out.push({ text: item.replace(/\n   /g, '\n').trim(), note: note })
          }
          return out
        } catch (_) { return [] }
      }

      /** 在用户气泡上贴「引用 ×N」标签（hover 显示条目内容）。 */
      function attachBubbleTag(row, items) {
        if (row.querySelector('[data-annotation-bubble-tag]') !== null) return
        var bubble = row.querySelector('[class*="bubble"]') || row
        var tag = document.createElement('span')
        tag.setAttribute('data-annotation-bubble-tag', '')
        tag.textContent = t('bubble.tag', { n: items.length })
        tag.style.cssText = 'display:inline-flex;align-items:center;height:18px;padding:0 8px;margin:4px 0 0 4px;border-radius:9px;border:1px solid var(--dsw-alias-border-inverted);background:var(--dsw-specific-menu,#2c2c2e);color:var(--dsw-alias-label-secondary);font-family:var(--dsw-font-family,system-ui);font-size:10px;cursor:default;'
        ;(function (list) {
          tag.addEventListener('mouseenter', function () {
            tipLayer.textContent = ''
            var el = document.createElement('div')
            el.className = 'dsh-ann-tip'
            el.style.cssText = 'position:fixed;box-sizing:border-box;z-index:1160;width:300px;max-width:calc(100vw - 16px);padding:10px 12px;border-radius:12px;border:1px solid var(--dsw-alias-border-inverted);background:var(--dsw-specific-menu,#2c2c2e);box-shadow:var(--dsw-shadow-lv3);font-family:var(--dsw-font-family,system-ui);font-size:12px;color:var(--dsw-alias-label-primary);'
            var head = document.createElement('div')
            head.style.cssText = 'font-weight:600;margin-bottom:6px;'
            head.textContent = t('bubble.title', { n: list.length })
            el.appendChild(head)
            for (var i = 0; i < list.length; i++) {
              var item = document.createElement('div')
              item.style.cssText = 'padding:6px 0;border-top:1px solid var(--dsw-alias-border-strong,#444);'
              var num = document.createElement('span')
              num.style.cssText = 'display:inline-flex;align-items:center;justify-content:center;min-width:16px;height:16px;margin-right:6px;border-radius:8px;background:var(--dsw-alias-text-accent,#4c9aff);color:#fff;font-size:10px;font-weight:700;'
              num.textContent = String(i + 1)
              var body = document.createElement('span')
              body.style.cssText = 'font-size:11px;line-height:1.5;color:var(--dsw-alias-label-tertiary);'
              body.textContent = truncate(list[i].text, 50)
              item.appendChild(num)
              item.appendChild(body)
              if (list[i].note !== '') {
                var note = document.createElement('div')
                note.style.cssText = 'font-size:11px;color:var(--dsw-alias-label-secondary);margin:2px 0 0 22px;word-break:break-word;'
                note.textContent = t('tip.notePrefix') + truncate(list[i].note, 60)
                item.appendChild(note)
              }
              el.appendChild(item)
            }
            tipLayer.appendChild(el)
            var r2 = tag.getBoundingClientRect()
            var w2 = el.offsetWidth || 300
            var h2 = el.offsetHeight || 120
            var left = Math.max(8, Math.min(r2.left, window.innerWidth - w2 - 8))
            var top = r2.bottom + 6
            if (top + h2 > window.innerHeight - 8) top = r2.top - h2 - 6
            el.style.left = left + 'px'
            el.style.top = Math.max(8, top) + 'px'
            el.style.width = w2 + 'px'
          })
          // PATCH(2026-09-18-hover-controller): 同 makeReplyChip——标签不再自带 grace
          // 定时器与 tipLayer 监听器，统一走单例 scheduleHide（共享 hoverGrace）。
          tag.addEventListener('mouseleave', scheduleHide)
        })(items)
        tag.__annotationItems = items
        bubble.appendChild(tag)
        console.log('[annotation] 气泡已贴引用标签 ×' + items.length)
      }

      /** 发送完成时暂存引用数据（供气泡 hover 面板使用）。 */
      var pendingDeco = []

      // ---------- 助手回复中的「Annotation N：」→ 悬浮引用芯片 ----------

      /** 找到该回复行之前最近一条携带引用标签的用户消息的条目数据。 */
      function findPrevAnnotationItems(row) {
        var rows = allMessageRows()
        var idx = rows.indexOf(row)
        if (idx === -1) return null
        for (var i = idx - 1; i >= 0; i--) {
          var tag = rows[i].querySelector('[data-annotation-bubble-tag]')
          if (tag !== null && Array.isArray(tag.__annotationItems) && tag.__annotationItems.length > 0) {
            return tag.__annotationItems
          }
        }
        return null
      }

      /** 一次性诊断（仅控制台，不打扰用户）：标记行 + 原因。 */
      function markRowDiag(row, msg) {
        if (row.hasAttribute('data-annotation-diag')) return
        row.setAttribute('data-annotation-diag', '')
        console.warn('[annotation] ' + msg, row)
      }

      /** PATCH(2026-09-05): 旧模型服务把思考过程以 think / thinking /
       *  thought 标签块内联进正文（没有独立 reasoning 通道），宿主按普通
       *  文本渲染——用户看到大段独白，芯片替换还可能误命中独白里的
       *  「Annotation N：」。停流后先把这些块从助手行文本节点剥掉；块被
       *  markdown 拆成多个文本节点时，用状态机跨节点续接。
       *  ponytail: 只认文本节点里的标签原文；若宿主渲染层把标签当 HTML
       *  吞掉、只剩独白文字，则无从识别（属宿主渲染层问题）。 */
      var THINK_OPEN_RE = /<\s*(?:think(?:ing)?|thought|reasoning)\s*>/i
      var THINK_CLOSE_RE = /<\s*\/\s*(?:think(?:ing)?|thought|reasoning)\s*>/i
      var THINK_BLOCK_RE = /<\s*(?:think(?:ing)?|thought|reasoning)\s*>[\s\S]*?<\s*\/\s*(?:think(?:ing)?|thought|reasoning)\s*>/gi
      function stripInlineThink(row) {
        var nodes = []
        var walker = document.createTreeWalker(row, NodeFilter.SHOW_TEXT)
        var n
        while ((n = walker.nextNode()) !== null) nodes.push(n)
        var inside = false
        for (var i = 0; i < nodes.length; i++) {
          n = nodes[i]
          if (n.parentNode === null) continue
          var v = n.nodeValue || ''
          if (v === '') continue
          if (!inside && v.indexOf('<') === -1) continue
          THINK_BLOCK_RE.lastIndex = 0
          var out = v.replace(THINK_BLOCK_RE, '')
          if (!inside) {
            var om = out.match(THINK_OPEN_RE)
            if (om !== null) { out = out.slice(0, om.index); inside = true }
          } else {
            var cm = out.match(THINK_CLOSE_RE)
            if (cm === null) out = ''
            else { out = out.slice(cm.index + cm[0].length); inside = false }
          }
          if (out !== v) n.nodeValue = out
        }
      }

      /** 扫描所有已结束流式输出的助手行：把「Annotation N：」替换为可悬浮芯片。 */
      /** 流式 mutation 批次的芯片装饰限流: 前导 + 500ms 拖尾, 每批次最多触发一次
       *  增量扫描(只扫助手行), 代替逐批全文档 decorateAll。 */
      var lastAssistantDecorate = 0
      var assistantDecorateTimer = null
      // PATCH(2026-09-18-dispose): fiber 卸载守卫。assistantDecorateTimer 是 ≤500ms 的
      // 拖尾限流，dispose 里不摘就会在卸载后把芯片插进宿主助手行——tipLayer 已被
      // remove，芯片 hover 无提示，且它的 data-annotation-reply-chip 标记会让重载后的
      // 新 fiber 跳过该行（热重载后个别回复行芯片失效）。decorateAll 兜底轮询同理。
      var disposed = false
      function scheduleAssistantDecorate() {
        if (disposed) return
        var now = performance.now()
        if (now - lastAssistantDecorate >= 500) {
          lastAssistantDecorate = now
          decorateAssistantAnnotations()
          return
        }
        if (assistantDecorateTimer !== null) return
        assistantDecorateTimer = setTimeout(function () {
          assistantDecorateTimer = null
          lastAssistantDecorate = performance.now()
          decorateAssistantAnnotations()
        }, 500 - (now - lastAssistantDecorate))
      }

      function decorateAssistantAnnotations() {
        if (disposed) return
        var rows = assistantRows()
        for (var i = 0; i < rows.length; i++) {
          var el = rows[i]
          if (!isAssistantRow(el) && !isFocusAssistantRow(el)) continue
          // 新版 data-streaming 标记在 AssistantMarkdown 内部元素上（行元素
          // 本身没有）——必须查行内，否则流式输出途中就把「Annotation N：」
          // 替换成芯片，与 React 正在更新的文本节点冲突，整条回复可能渲染
          // 异常（表现为看不到回复消息）。
          if (el.hasAttribute('data-streaming') || el.querySelector('[data-streaming]') !== null) continue
          stripInlineThink(el) // PATCH(2026-09-05): 先剥内联 think 块，再做芯片替换
          if (el.querySelector('[data-annotation-reply-chip]') !== null) continue
          if ((el.textContent || '').indexOf('Annotation') === -1) continue
          var items = findPrevAnnotationItems(el)
          if (items === null || items.length === 0) {
            // 拿不到条目数据也照样生成芯片（hover 显示占位），并一次性提示。
            items = []
            markRowDiag(el, '未找到引用条目数据，芯片将显示占位内容（可继续用）')
          }
          decorateAnnotationLabels(el, items)
        }
      }

      /** 在行内所有文本节点中找「Annotation N：」（不区分大小写），替换为芯片。 */
      function decorateAnnotationLabels(row, items) {
        var re = /Annotation[\s\u200b\u200c\u200d\u00ad]*(\d+)[\s\u200b\u200c\u200d\u00ad]*[:：]/gi
        // 先快照所有文本节点，再逐个处理：遍历中途修改树会让 TreeWalker
        // 指针失效（处理完第一个节点后遍历就断了）——这是「只有第一个
        // Annotation 变成芯片」的根因。
        var nodes = []
        var walker = document.createTreeWalker(row, NodeFilter.SHOW_TEXT)
        var n
        while ((n = walker.nextNode()) !== null) nodes.push(n)
        var done = 0
        for (var i = 0; i < nodes.length; i++) {
          n = nodes[i]
          if (n.parentNode === null) continue
          var v = n.nodeValue || ''
          re.lastIndex = 0
          if (!re.test(v)) continue
          var frag = document.createDocumentFragment()
          var last = 0
          re.lastIndex = 0
          var m
          while ((m = re.exec(v)) !== null) {
            if (m.index > last) frag.appendChild(document.createTextNode(v.slice(last, m.index)))
            frag.appendChild(makeReplyChip(parseInt(m[1], 10), items))
            last = m.index + m[0].length
            done++
          }
          if (last < v.length) frag.appendChild(document.createTextNode(v.slice(last)))
          n.parentNode.replaceChild(frag, n)
        }
        if (done > 0) {
          console.log('[annotation] 回复引用芯片 ×' + done, row.querySelectorAll('[data-annotation-reply-chip]').length + ' 个元素')
        } else {
          // 行内含 Annotation 但一个都没匹配上 → 文本节点里没有完整「Annotation N：」模式
          markRowDiag(row, '行内含 Annotation 但未匹配到「Annotation N：」模式')
        }
      }

      /** 构造「Annotation N」芯片（hover 显示该引用的原文与引用内容）。 */
      function makeReplyChip(num, items) {
        var chip = document.createElement('span')
        chip.setAttribute('data-annotation-reply-chip', '')
        chip.style.cssText = 'display:inline-flex;align-items:center;height:18px;padding:0 6px;margin:0 2px;border-radius:9px;border:1px solid var(--dsw-alias-border-inverted);background:var(--dsw-specific-menu,#2c2c2e);color:var(--dsw-alias-text-accent,#4c9aff);font-family:var(--dsw-font-family,system-ui);font-size:11px;font-weight:600;cursor:default;vertical-align:middle;'
        chip.textContent = 'Annotation ' + num
        var item = items[num - 1]
        // PATCH(2026-09-18-hover-controller): 每枚芯片一份 grace 定时器 + 一对 tipLayer
        // 监听器，而 tipLayer 是 fiber 级单例（只在 dispose 移除）——长会话里监听器与
        // 闭包保留的 items 随芯片数线性累积。悬停宽限统一交给单例的
        // scheduleHide/cancelHide（共享 hoverGrace），本处只管芯片自己的 mouseleave。
        chip.addEventListener('mouseenter', function () {
          tipLayer.textContent = ''
          var el = document.createElement('div')
          el.className = 'dsh-ann-tip'
          el.style.cssText = 'position:fixed;box-sizing:border-box;z-index:1160;width:320px;max-width:calc(100vw - 16px);padding:10px 12px;border-radius:12px;border:1px solid var(--dsw-alias-border-inverted);background:var(--dsw-specific-menu,#2c2c2e);box-shadow:var(--dsw-shadow-lv3);font-family:var(--dsw-font-family,system-ui);font-size:12px;color:var(--dsw-alias-label-primary);'
          var head = document.createElement('div')
          head.style.cssText = 'font-weight:600;margin-bottom:6px;'
          head.textContent = item !== undefined ? t('reply.headWithQuote', { n: num }) : t('reply.headNoQuote', { n: num })
          el.appendChild(head)
          if (item !== undefined) {
            var quote = document.createElement('div')
            quote.style.cssText = 'font-size:12px;line-height:1.5;color:var(--dsw-alias-label-secondary);word-break:break-word;padding:6px 8px;border-radius:8px;background:rgba(127,127,127,.12);'
            quote.textContent = truncate(item.text, 140)
            el.appendChild(quote)
            if (item.note !== '') {
              var note = document.createElement('div')
              note.style.cssText = 'font-size:11px;color:var(--dsw-alias-text-accent,#4c9aff);margin-top:6px;word-break:break-word;'
              note.textContent = t('reply.notePrefix') + truncate(item.note, 80)
              el.appendChild(note)
            }
          } else {
            var none = document.createElement('div')
            none.style.cssText = 'font-size:11px;color:var(--dsw-alias-label-tertiary);'
            none.textContent = t('reply.missing')
            el.appendChild(none)
          }
          tipLayer.appendChild(el)
          var r2 = chip.getBoundingClientRect()
          var w2 = el.offsetWidth || 320
          var h2 = el.offsetHeight || 100
          var left = Math.max(8, Math.min(r2.left, window.innerWidth - w2 - 8))
          var top = r2.bottom + 6
          if (top + h2 > window.innerHeight - 8) top = r2.top - h2 - 6
          el.style.left = left + 'px'
          el.style.top = Math.max(8, top) + 'px'
          el.style.width = w2 + 'px'
        })
        chip.addEventListener('mouseleave', scheduleHide)
        return chip
      }

      /** 单行装饰：气泡文本里还有引用块就切块 + 补标签。返回是否做了手术。
       *  PATCH(2026-09-25-redecorate)：完成判定以「文本里还有引用块」为准，不能以
       *  标签存在为准——运行中插队的消息在插入流程中会被宿主重建文本（MessageText
       *  重渲染），手术切掉的块随文本回来而标签幸存，旧判定会永远跳过该行，协议
       *  文本就此裸奔（用户实测两张截图）。重手术时条目优先取标签上挂的
       *  __annotationItems（发送暂存早已消费过），标签只补缺不重贴。 */
      function decorateRow(el, allowPending) {
        if (el.hasAttribute('data-pending-steering')) return false
        var b = el.querySelector('[class*="bubble"]')
        if (b === null) return false
        if (!hasAnnotationBlock(b.textContent || '')) return false
        var tag = el.querySelector('[data-annotation-bubble-tag]')
        var items = null
        var fromSend = false
        if (tag !== null) {
          items = tag.__annotationItems || []
        } else if (allowPending && pendingDeco.length > 0) {
          items = pendingDeco[0].items
          fromSend = true
        }
        if (items === null || items.length === 0) { items = parseItemsFromBubble(el); fromSend = false }
        if (!hideAnnotationBlock(el)) return false // 内容未渲染完 → 留给下轮（发送暂存数据不弹出）
        if (fromSend) pendingDeco.shift()
        if (tag === null) attachBubbleTag(el, items)
        // 这里绝不清空待发送引用：DOM 层面无法区分「刚发送的消息」与「会话
        // 切换/刷新后重新渲染的历史消息」，历史消息重装饰曾被误判为已发送而
        // 清空刚恢复的待发送引用（issue #28 复测）。发送清空的唯一权威是
        // watchInputDraft 的「草稿有→空」迁移，其初始化时序洞由订阅重试补齐。
        return true
      }

      /** 全局轮询装饰：找所有「携带引用块但未装饰」的用户气泡 → 隐藏引用块 + 贴标签。
       *  不依赖发送事件链：异步渲染、刷新后的历史消息都能被覆盖。 */
      function decorateAll() {
        if (disposed) return
        try {
          var rows = allMessageRows()
          for (var i = rows.length - 1; i >= 0; i--) {
            decorateRow(rows[i], i === rows.length - 1)
          }
          // 助手回复：把「Annotation N：」变为可悬浮的引用芯片（内容取自最近一条带引用的用户消息）。
          decorateAssistantAnnotations()
        } catch (err) {
          console.warn('[annotation] 装饰扫描失败：', err)
        }
      }

      /** PATCH(2026-09-25-redecorate)：对本批 mutation 涉及的用户行做定点修补。
       *  宿主重建用户气泡文本是 characterData/attributes 批次，走不到 childList
       *  全量扫描；兜底轮询又只有 5 秒窗口，漏网后协议文本永久裸奔。这里按
       *  mutation 目标回溯所属消息行重做手术，成本 O(批次数)。 */
      function repairRowsOf(mutations) {
        var seen = []
        for (var i = 0; i < mutations.length; i++) {
          var t = mutations[i].target
          var el = t instanceof Element ? t : (t && t.parentElement)
          if (el === null || el === undefined || typeof el.closest !== 'function') continue
          var row = el.closest('[data-chat-flow-kind], [data-time-hover-root]')
          if (row === null || seen.indexOf(row) !== -1) continue
          seen.push(row)
          decorateRow(row, false)
        }
      }

      // 发送/初次挂载后做一个最多 5 秒的有界兜底轮询；正常更新由消息流
      // MutationObserver 驱动。这样仍覆盖异步 hydration，同时不再永久每秒全量扫描。
      var decoTimer = null
      var decoDeadline = 0
      function scheduleDecoratePoll() {
        if (decoTimer !== null) return
        decoTimer = setTimeout(function tickDecorate() {
          decoTimer = null
          decorateAll()
          if (Date.now() < decoDeadline) {
            decoTimer = setTimeout(tickDecorate, 500)
          }
        }, 250)
      }
      function kickDecorate() {
        decorateAll()
        decoDeadline = Date.now() + 5000
        scheduleDecoratePoll()
      }

      // ---------- locale 服务（zh/en）订阅与实时回流 ----------
      // locale.subscribe() 触发时：重绘打开中的浮层、更新输入框旁计数与历史气泡标签。
      // 服务缺失（旧 host / 测试环境）时保持 zh，全部功能不变。
      var localeUnsub = null
      function applyLocale() {
        var next = 'zh'
        try {
          if (ctx.locale !== undefined && ctx.locale !== null
            && typeof ctx.locale.getSnapshot === 'function') {
            var snap = ctx.locale.getSnapshot()
            if (snap !== undefined && snap !== null && snap.active) next = String(snap.active)
          }
        } catch (_) { /* keep zh */ }
        if (next === currentLang) return
        setLang(next)
        if (ui.mode !== 'closed') render()
        updateChip()
        // 打开的悬浮面板按新语言关闭（下次 hover 以新语言重建）。
        tipLayer.textContent = ''
        var tags = document.querySelectorAll('[data-annotation-bubble-tag]')
        for (var i = 0; i < tags.length; i++) {
          var items = tags[i].__annotationItems
          if (Array.isArray(items)) tags[i].textContent = t('bubble.tag', { n: items.length })
        }
      }
      applyLocale()
      if (ctx.locale !== undefined && ctx.locale !== null
        && typeof ctx.locale.subscribe === 'function') {
        try { localeUnsub = ctx.locale.subscribe(applyLocale) } catch (_) { localeUnsub = null }
      }

      // ---------- 待发送引用按会话恢复 ----------
      var lastSessionId = currentSessionId()
      ui.quotes = readPendingQuotes(lastSessionId)
      // PATCH(2026-09-18-skill-catalog): fiber 启动即预热技能清单（异步、失败静默）。
      refreshSkillNames()
      var unsub = sessions.list.subscribe(function () {
        var cur = currentSessionId()
        if (cur === lastSessionId) return
        writePendingQuotes(lastSessionId)
        lastSessionId = cur
        // PATCH(2026-09-18-skill-catalog): 技能清单是按会话拉的，切会话必须重取。
        refreshSkillNames()
        if (ui.mode !== 'closed') closeToolbar()
        ui.quotes = readPendingQuotes(cur)
        annotationAttached = false
        // 旧会话未消费的发送暂存作废：留着会被新会话的历史消息误消费（错贴标签）；
        // 旧会话那条消息回切后会由气泡反解析路径重新装饰。
        pendingDeco.length = 0
        ui.noteDraft = ''
        tipLayer.textContent = ''
        updateChip()
        watchInputDraft()
        renderMarkers()
      })

      watchInputDraft()
      kickDecorate()
      updateChip()

      // ---------- 清理 ----------
      return function () {
        // PATCH(2026-09-18-dispose): 守卫先置位再逐项摘除——卸载期间任何 observer
        // 尾批、rAF 尾帧回调都必须立刻停手。
        disposed = true
        clearSettle()
        document.removeEventListener('selectionchange', onSelection)
        document.removeEventListener('pointerdown', onDocPointerDown, true)
        document.removeEventListener('keydown', onKeyDown, true)
        document.removeEventListener('pointerdown', onSendPointerDown, true)
        document.removeEventListener('click', onSendKeyboardClick, true)
        document.removeEventListener('compositionstart', markImeComposing, true)
        document.removeEventListener('compositionend', markImeEnded, true)
        if (imeClearTimer !== null) { clearTimeout(imeClearTimer); imeClearTimer = null }
        window.removeEventListener('scroll', onLayoutChange, true)
        window.removeEventListener('resize', onLayoutChange)
        window.removeEventListener('scroll', scheduleChipUpdate, true)
        window.removeEventListener('resize', scheduleChipUpdate)
        document.removeEventListener('input', onComposerInput, true)
        if (chipPositionFrame !== null) {
          cancelAnimationFrame(chipPositionFrame)
          chipPositionFrame = null
        }
        if (chipResizeObserver !== null) {
          chipResizeObserver.disconnect()
          chipResizeObserver = null
        }
        chipComposerCard = null
        host.removeEventListener('pointerdown', onHostPointerDown)
        observer.disconnect()
        rootObserver.disconnect()
        observerTargets = []
        if (typeof unsub === 'function') unsub()
        if (inputWatchTimer !== null) { clearInterval(inputWatchTimer); inputWatchTimer = null }
        if (typeof inputUnsub === 'function') inputUnsub()
        if (typeof localeUnsub === 'function') localeUnsub()
        if (decoTimer !== null) { clearTimeout(decoTimer); decoTimer = null }
        decoDeadline = 0
        // PATCH(2026-09-18-dispose): 补齐短定时器句柄（toast 3s／hover 宽限 250ms／
        // 芯片装饰拖尾 ≤500ms）。toast 的定时器摘掉后必须顺手删它自己的节点，否则
        // 提示条永久留在 body 上；in-flight 的技能清单请求用 abort 取消。
        if (toastTimer !== null) { clearTimeout(toastTimer); toastTimer = null }
        var strayToast = document.querySelector('[data-annotation-toast]')
        if (strayToast !== null) strayToast.remove()
        if (hoverGrace !== null) { clearTimeout(hoverGrace); hoverGrace = null }
        if (assistantDecorateTimer !== null) {
          clearTimeout(assistantDecorateTimer)
          assistantDecorateTimer = null
        }
        if (skillNamesAbort !== null) {
          skillNamesAbort.abort()
          skillNamesAbort = null
        }
        chipLayer.remove()
        tipLayer.remove()
        host.remove()
        overlay.remove()
      }
    }

    exports.name = '@dsh-external/dsh-annotation-patched'
    exports.inject = ['sessions', 'conversation', 'locale']
    exports.apply = apply

    return module.exports
  },
})
