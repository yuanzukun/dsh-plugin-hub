import { mkdtemp, rm } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { afterEach, describe, expect, it, vi } from 'vitest'
import { Context } from '@deepseek-ai/cordis'
import AttachmentLocal from '@deepseek-ai/dsh-attachment-local'
import { CallId } from '@deepseek-ai/dsh-llm'
import LlmRuntime from '@deepseek-ai/dsh-llm'
import ToolRuntime from '@deepseek-ai/dsh-tools'
import SystemPrompt from '@deepseek-ai/dsh-system-prompt'
import * as ClawRouters from '../src/index.ts'

const PNG_BASE64 = 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+A8AAQUBAScY42YAAAAASUVORK5CYII='
const roots: string[] = []

afterEach(async () => {
  vi.unstubAllGlobals()
  vi.unstubAllEnvs()
  await Promise.all(roots.splice(0).map(root => rm(root, { recursive: true, force: true })))
})

async function harness(fetcher: typeof fetch): Promise<Context> {
  const root = await mkdtemp(join(tmpdir(), 'dsh-clawrouters-'))
  roots.push(root)
  vi.stubEnv('CLAWROUTERS_API_KEY', 'test-key')
  vi.stubGlobal('fetch', fetcher)
  const ctx = new Context()
  await ctx.plugin(SystemPrompt, {})
  await ctx.plugin(LlmRuntime)
  await ctx.plugin(ToolRuntime)
  await ctx.plugin(AttachmentLocal, { dshHome: root })
  await ctx.plugin(ClawRouters, {
    baseURL: 'https://mock.clawrouters.test/api/v1',
    videoPollIntervalMs: 250,
  })
  return ctx
}

async function execute(ctx: Context, name: string, args: unknown) {
  return ctx.tools.execute({
    signal: new AbortController().signal,
    callId: CallId(`test-${name}`),
    name,
    arguments: args,
  })
}

describe('ClawRouters tools', () => {
  it('persists generated image bytes and returns a real image content block', async () => {
    const fetcher = vi.fn<typeof fetch>(async () => new Response(JSON.stringify({
      data: [{ b64_json: PNG_BASE64 }],
    }), { status: 200, headers: { 'content-type': 'application/json' } }))
    const ctx = await harness(fetcher)

    const result = await execute(ctx, 'clawrouters_image_generate', { prompt: 'a tiny pixel' })

    expect(result.isError).toBe(false)
    expect(result.content.map(block => block.type)).toEqual(['text', 'image'])
    expect(result.isError ? undefined : result.value).toMatchObject({
      model: 'auto',
      images: [{ mediaType: 'image/png', width: 1, height: 1 }],
    })
    const firstCall = fetcher.mock.calls[0]
    expect(firstCall?.[0]).toBe('https://mock.clawrouters.test/api/v1/images/generations')
    expect(new Headers(firstCall?.[1]?.headers).get('authorization')).toBe('Bearer test-key')
    await ctx.fiber.dispose()
  })

  it('polls video tasks and keeps search sources structured', async () => {
    let videoPolls = 0
    const fetcher = vi.fn<typeof fetch>(async (input) => {
      const url = input instanceof Request ? input.url : input instanceof URL ? input.href : input
      if (url.endsWith('/videos')) return new Response(JSON.stringify({ id: 'vid-1', status: 'queued' }))
      if (url.endsWith('/videos/vid-1')) {
        videoPolls += 1
        return new Response(JSON.stringify({ id: 'vid-1', status: 'ready', result_url: 'https://cdn.example/video.mp4' }))
      }
      if (url.endsWith('/search')) return new Response(JSON.stringify({
        query: 'DSH', provider: 'mock', cached: false, took_ms: 12,
        results: [{ title: 'DeepSeek Harness', url: 'https://example.com/dsh', snippet: 'Plugin-first agent harness.' }],
      }))
      return new Response('not found', { status: 404 })
    })
    const ctx = await harness(fetcher)

    const video = await execute(ctx, 'clawrouters_video_generate', { prompt: 'ocean waves', duration_seconds: 3 })
    const search = await execute(ctx, 'clawrouters_web_search', { query: 'DSH' })

    expect(video.isError ? undefined : video.value).toEqual({
      taskId: 'vid-1', status: 'ready', url: 'https://cdn.example/video.mp4', model: 'auto',
    })
    expect(videoPolls).toBe(1)
    expect(search.isError ? undefined : search.value).toEqual({
      query: 'DSH', provider: 'mock', cached: false, tookMs: 12,
      sources: [{ title: 'DeepSeek Harness', url: 'https://example.com/dsh', snippet: 'Plugin-first agent harness.' }],
    })
    await ctx.fiber.dispose()
  })
})
