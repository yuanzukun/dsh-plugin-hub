import { readFile } from 'node:fs/promises'
import { describe, expect, it } from 'vitest'

describe('installable DSH bundle', () => {
  it('declares a patch that adds the chat profile and tool plugin', async () => {
    const manifest = JSON.parse(await readFile(new URL('../package.json', import.meta.url), 'utf8')) as {
      name: string
      dsh?: { bundle?: { patch?: string } }
    }
    const patch = await readFile(new URL('../cordis.patch.yml', import.meta.url), 'utf8')

    expect(manifest.name).toBe('dsh-plugin-clawrouters')
    expect(manifest.dsh?.bundle?.patch).toBe('./cordis.patch.yml')
    expect(patch).toContain('id: llm-pi-ai')
    expect(patch).toContain('clawrouters:')
    expect(patch).toContain('apiKeyEnv: CLAWROUTERS_API_KEY')
    expect(patch).toContain('name: dsh-plugin-clawrouters')
  })
})
