# dsh-plugin-clawrouters

English | [简体中文](README.zh-CN.md)

[ClawRouters](https://www.clawrouters.com/) for [DeepSeek Harness](https://github.com/deepseek-ai/deepseek-harness): install one DSH bundle, configure one API key in the Web UI, and use chat, image generation, video generation, and web search.

## Why this plugin

ClawRouters exposes multiple AI capabilities behind one OpenAI-compatible API and one credential. This plugin maps those capabilities into DSH's plugin-native seams instead of adding a separate application:

- `clawrouters / auto` — OpenAI-compatible chat route, including image input.
- `clawrouters_image_generate` — generates images and stores them as durable DSH image attachments.
- `clawrouters_video_generate` — submits and polls a video task, then returns the signed result URL.
- `clawrouters_web_search` — returns structured titles, snippets, and source URLs without replacing DSH's existing generic `web_search` provider.

## Install

Requirements: DeepSeek Harness `0.1.0-rc.6` or newer and pnpm on `PATH`.

Install the tagged GitHub release into the Web profile:

```sh
dsh plugin --profile web add github:ropon/dsh-plugin-clawrouters#v0.1.1
dsh web
```

The repository commits its built `lib/` output, so a GitHub installation does not need pnpm `allowBuilds` or run an install-time build script.

To try a local checkout during development:

```sh
dsh plugin --profile web add .
dsh web
```

## Configure one key

1. Open DSH Web or Desktop.
2. Go to **Settings → Models → ClawRouters**.
3. Paste your ClawRouters API key and save.
4. Select **clawrouters / auto** in the conversation model picker.

The Web UI stores the secret through DSH's credential service under `CLAWROUTERS_API_KEY`; it is not written into `settings.yaml`. The chat route and all three tools resolve that same credential on every call, so key rotation applies without rebuilding the plugin.

You can also provide the key through the launch environment:

```sh
export CLAWROUTERS_API_KEY='...'
dsh web
```

## How it works

This repository is a DSH bundle. [`cordis.patch.yml`](cordis.patch.yml) does two things:

1. Adds a `clawrouters` provider profile to DSH's built-in generic `llm-pi-ai` adapter. Reusing its existing `llm-pi-ai` settings namespace makes the stock Models page render the ClawRouters credential card—no browser patch or fork is required.
2. Inserts the `dsh-plugin-clawrouters` function plugin, which registers the image, video, and search tools into `ctx.tools` and uses `ctx.attachments` when that optional service is present.

The default API base is `https://www.clawrouters.com/api/v1`. Tool deployment defaults can be overridden in a later profile patch by targeting `id: clawrouters-tools`.

```yaml
- id: clawrouters-tools
  config:
    apiKeyEnv: CLAWROUTERS_API_KEY
    baseURL: https://www.clawrouters.com/api/v1
    imageModel: auto
    videoModel: auto
    imageTimeoutMs: 600000
    videoTimeoutMs: 1800000
    searchTimeoutMs: 30000
    videoPollIntervalMs: 5000
```

## Endpoint mapping

| Capability | ClawRouters API |
|---|---|
| Chat | `POST /chat/completions` via DSH's pi-ai adapter |
| Image | `POST /images/generations` |
| Video | `POST /videos`, compatibility fallback to `POST /videos/generations`, then `GET /videos/{id}` |
| Search | `POST /search` |

Every direct provider request includes the DSH attribution `User-Agent` and the bearer credential. Image URLs are accepted only over HTTP(S), decoded, format-checked, validated by DSH's attachment policy, and persisted before the tool result is appended. Video result URLs are restricted to HTTP(S).

## Deferred capabilities

- **Embeddings / vector search:** ClawRouters can generate embeddings, but useful vector search also needs a store, indexing, metadata filtering, and similarity retrieval. This plugin will add it when DSH has a vector-store seam; returning large float arrays as a chat tool is intentionally avoided.
- **Text to speech / speech to text:** deferred until DSH has durable audio attachments, upload handling, and player/recorder UI. Returning base64 audio as text would be expensive and unusable.
- **Durable video:** DSH currently has no video attachment block, so the plugin returns the provider's signed URL rather than copying video bytes into session storage.

## Development

```sh
pnpm install
pnpm check
```

The test suite covers image persistence, video polling, structured search results, authentication headers, and a bundle-shape smoke check. Built output is committed because DSH supports installing bundles directly from GitHub.

## License

[MIT](LICENSE)
