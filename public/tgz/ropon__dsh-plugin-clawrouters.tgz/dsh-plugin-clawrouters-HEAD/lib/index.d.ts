import z from "@deepseek-ai/schemastery";
import { Context } from "@deepseek-ai/cordis";
//#region src/config.d.ts
declare const DEFAULT_BASE_URL = "https://www.clawrouters.com/api/v1";
declare const DEFAULT_API_KEY_ENV = "CLAWROUTERS_API_KEY";
/** One ClawRouters plugin instance: one credential and endpoint for every capability. */
interface Config {
  /** Credential reference resolved by chat and every tool. */
  apiKeyEnv?: string;
  /** ClawRouters OpenAI-compatible API root, without a trailing slash. */
  baseURL?: string;
  /** Default model for image generation tool calls. */
  imageModel?: string;
  /** Default model for video generation tool calls. */
  videoModel?: string;
  /** Image operation deadline in milliseconds. */
  imageTimeoutMs?: number;
  /** Video submission and polling deadline in milliseconds. */
  videoTimeoutMs?: number;
  /** Web-search operation deadline in milliseconds. */
  searchTimeoutMs?: number;
  /** Delay between video status requests in milliseconds. */
  videoPollIntervalMs?: number;
}
/** Deployment schema for the provider-specific generation and search tools. */
declare const Config: z<Config>;
/** Resolve defaults for direct mounts as well as Loader-created instances. */
declare function resolveConfig(config: Config): Required<Config>;
//#endregion
//#region src/http.d.ts
/** Provider error retaining the HTTP status for compatibility fallbacks. */
declare class ClawRoutersHttpError extends Error {
  readonly status: number;
  constructor(message: string, status: number);
}
//#endregion
//#region src/index.d.ts
/** Cordis diagnostic name. */
declare const name = "clawrouters";
/** The model-facing registry this plugin extends. */
declare const inject: string[];
/** Register ClawRouters image, video, and web-search tools. */
declare function apply(ctx: Context, config: Config): void;
//#endregion
export { type Config as ClawRoutersConfig, Config, ClawRoutersHttpError, DEFAULT_API_KEY_ENV, DEFAULT_BASE_URL, apply, inject, name, resolveConfig };