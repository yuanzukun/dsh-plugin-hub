import z from '@deepseek-ai/schemastery'

export const DEFAULT_BASE_URL = 'https://www.clawrouters.com/api/v1'
export const DEFAULT_API_KEY_ENV = 'CLAWROUTERS_API_KEY'

/** One ClawRouters plugin instance: one credential and endpoint for every capability. */
export interface Config {
  /** Credential reference resolved by chat and every tool. */
  apiKeyEnv?: string
  /** ClawRouters OpenAI-compatible API root, without a trailing slash. */
  baseURL?: string
  /** Default model for image generation tool calls. */
  imageModel?: string
  /** Default model for video generation tool calls. */
  videoModel?: string
  /** Image operation deadline in milliseconds. */
  imageTimeoutMs?: number
  /** Video submission and polling deadline in milliseconds. */
  videoTimeoutMs?: number
  /** Web-search operation deadline in milliseconds. */
  searchTimeoutMs?: number
  /** Delay between video status requests in milliseconds. */
  videoPollIntervalMs?: number
}

/** Deployment schema for the provider-specific generation and search tools. */
export const Config: z<Config> = z.object({
  apiKeyEnv: z.string().role('credential-ref').default(DEFAULT_API_KEY_ENV),
  baseURL: z.string().default(DEFAULT_BASE_URL),
  imageModel: z.string().default('auto'),
  videoModel: z.string().default('auto'),
  imageTimeoutMs: z.number().step(1).min(1).default(600_000),
  videoTimeoutMs: z.number().step(1).min(1).default(1_800_000),
  searchTimeoutMs: z.number().step(1).min(1).default(30_000),
  videoPollIntervalMs: z.number().step(1).min(250).default(5_000),
})

/** Resolve defaults for direct mounts as well as Loader-created instances. */
export function resolveConfig(config: Config): Required<Config> {
  return {
    apiKeyEnv: config.apiKeyEnv ?? DEFAULT_API_KEY_ENV,
    baseURL: (config.baseURL ?? DEFAULT_BASE_URL).replace(/\/+$/, ''),
    imageModel: config.imageModel ?? 'auto',
    videoModel: config.videoModel ?? 'auto',
    imageTimeoutMs: config.imageTimeoutMs ?? 600_000,
    videoTimeoutMs: config.videoTimeoutMs ?? 1_800_000,
    searchTimeoutMs: config.searchTimeoutMs ?? 30_000,
    videoPollIntervalMs: config.videoPollIntervalMs ?? 5_000,
  }
}
