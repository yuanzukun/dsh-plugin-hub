import { attributionHeaders } from '@deepseek-ai/dsh-llm'

/** Provider error retaining the HTTP status for compatibility fallbacks. */
export class ClawRoutersHttpError extends Error {
  constructor(message: string, readonly status: number) {
    super(message)
    this.name = 'ClawRoutersHttpError'
  }
}

function providerMessage(value: unknown): string | undefined {
  if (typeof value !== 'object' || value === null) return undefined
  const record = value as Record<string, unknown>
  if (typeof record.message === 'string') return record.message
  if (typeof record.error === 'string') return record.error
  if (typeof record.error === 'object' && record.error !== null) {
    const message = (record.error as Record<string, unknown>).message
    if (typeof message === 'string') return message
  }
  return undefined
}

/** POST one authenticated JSON operation and parse its JSON response. */
export async function postJson(
  url: string,
  apiKey: string,
  body: unknown,
  signal: AbortSignal,
): Promise<unknown> {
  const response = await fetch(url, {
    method: 'POST',
    headers: {
      ...attributionHeaders(),
      authorization: `Bearer ${apiKey}`,
      'content-type': 'application/json',
    },
    body: JSON.stringify(body),
    signal,
  })
  const text = await response.text()
  let parsed: unknown
  try {
    parsed = text.length === 0 ? {} : JSON.parse(text)
  } catch {
    throw new ClawRoutersHttpError(`ClawRouters returned non-JSON HTTP ${response.status}`, response.status)
  }
  if (!response.ok) {
    throw new ClawRoutersHttpError(
      `ClawRouters HTTP ${response.status}: ${providerMessage(parsed) ?? response.statusText}`,
      response.status,
    )
  }
  return parsed
}

/** GET one authenticated JSON operation. */
export async function getJson(url: string, apiKey: string, signal: AbortSignal): Promise<unknown> {
  const response = await fetch(url, {
    headers: { ...attributionHeaders(), authorization: `Bearer ${apiKey}` },
    signal,
  })
  const text = await response.text()
  let parsed: unknown
  try {
    parsed = text.length === 0 ? {} : JSON.parse(text)
  } catch {
    throw new ClawRoutersHttpError(`ClawRouters returned non-JSON HTTP ${response.status}`, response.status)
  }
  if (!response.ok) {
    throw new ClawRoutersHttpError(
      `ClawRouters HTTP ${response.status}: ${providerMessage(parsed) ?? response.statusText}`,
      response.status,
    )
  }
  return parsed
}
