/**
 * ClawRouters generation and search tools for DeepSeek Harness. Chat is
 * composed by the bundle's `llm-pi-ai` profile; this function plugin owns the
 * provider-specific tools and resolves the exact same credential reference.
 * @module dsh-plugin-clawrouters
 */

import type { Context } from '@deepseek-ai/cordis'
import { credentialRef } from '@deepseek-ai/dsh-credentials'
import { launchEnvironmentOf } from '@deepseek-ai/dsh-launch-environment'
import { assertUsableApiKey, LlmError } from '@deepseek-ai/dsh-llm'
import { Config, resolveConfig } from './config.ts'
import { registerImageTool, registerSearchTool, registerVideoTool } from './tools.ts'

export { Config, DEFAULT_API_KEY_ENV, DEFAULT_BASE_URL, resolveConfig } from './config.ts'
export type { Config as ClawRoutersConfig } from './config.ts'
export { ClawRoutersHttpError } from './http.ts'

/** Cordis diagnostic name. */
export const name = 'clawrouters'
/** The model-facing registry this plugin extends. */
export const inject = ['tools']

/** Register ClawRouters image, video, and web-search tools. */
export function apply(ctx: Context, config: Config): void {
  const current = (): Config => config
  const resolveKey = async (): Promise<string> => {
    const ref = credentialRef(resolveConfig(config).apiKeyEnv)
    const credentials = ctx.get('credentials')
    const value = credentials === undefined
      ? launchEnvironmentOf(ctx).get(ref)?.value
      : (await credentials.resolve(ref))?.value
    if (value !== undefined && value.length > 0) return assertUsableApiKey(value, name, ref)
    throw new LlmError(
      `clawrouters: no credential for ${ref}; save it in Settings > Models > ClawRouters or export ${ref}`,
      'MISSING_CREDENTIAL',
    )
  }

  registerVideoTool(ctx, current, resolveKey)
  registerSearchTool(ctx, current, resolveKey)
  ctx.inject(['attachments'], (sctx) => {
    registerImageTool(sctx, current, resolveKey)
  })
}
