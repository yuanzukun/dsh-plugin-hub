import type { Context } from '@deepseek-ai/cordis'
import { AttachmentId } from '@deepseek-ai/dsh-attachment'
import type { ImageAttachmentRef, ImageMediaType } from '@deepseek-ai/dsh-attachment'
import { createUserMessage } from '@deepseek-ai/dsh-llm'
import type { ContentBlock } from '@deepseek-ai/dsh-llm'
import { defineTool } from '@deepseek-ai/dsh-tools'
import type { GenericCallView } from '@deepseek-ai/dsh-tools'
import type { Config } from './config.ts'
import { resolveConfig } from './config.ts'
import { ClawRoutersHttpError, getJson, postJson } from './http.ts'

type CurrentConfig = () => Config
type ResolveKey = () => Promise<string>

interface CanonicalImage {
  attachmentId: string
  mediaType: ImageMediaType
  bytes: number
  width: number
  height: number
  name?: string
}

interface ImageGenerateValue {
  model: string
  images: CanonicalImage[]
}

interface SearchSource {
  url: string
  title?: string
  snippet?: string
  publishedAt?: string
}

interface SearchValue {
  query: string
  provider?: string
  cached?: boolean
  tookMs?: number
  sources: SearchSource[]
}

interface VideoGenerateValue {
  taskId?: string
  status: string
  url: string
  model: string
}

function recordOf(value: unknown): Record<string, unknown> | undefined {
  return typeof value === 'object' && value !== null && !Array.isArray(value)
    ? value as Record<string, unknown>
    : undefined
}

function nonEmpty(value: unknown): string | undefined {
  return typeof value === 'string' && value.trim().length > 0 ? value : undefined
}

function imageMediaType(bytes: Uint8Array, declared?: string): ImageMediaType {
  if (bytes.length >= 8 && bytes[0] === 0x89 && bytes[1] === 0x50 && bytes[2] === 0x4e && bytes[3] === 0x47) return 'image/png'
  if (bytes.length >= 3 && bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff) return 'image/jpeg'
  if (bytes.length >= 6 && String.fromCharCode(...bytes.slice(0, 6)).startsWith('GIF8')) return 'image/gif'
  if (bytes.length >= 12 && String.fromCharCode(...bytes.slice(0, 4)) === 'RIFF'
    && String.fromCharCode(...bytes.slice(8, 12)) === 'WEBP') return 'image/webp'
  const normalized = declared?.split(';', 1)[0]?.trim().toLowerCase()
  if (normalized === 'image/png' || normalized === 'image/jpeg' || normalized === 'image/webp' || normalized === 'image/gif') {
    return normalized
  }
  throw new Error('ClawRouters returned an unsupported image format; expected PNG, JPEG, WebP, or GIF')
}

function decodeDataUrl(value: string): { bytes: Uint8Array; mediaType: ImageMediaType } | undefined {
  const match = /^data:([^;,]+);base64,(.+)$/s.exec(value)
  if (match === null) return undefined
  const encoded = match[2]
  if (encoded === undefined) return undefined
  const bytes = Uint8Array.from(Buffer.from(encoded, 'base64'))
  return { bytes, mediaType: imageMediaType(bytes, match[1]) }
}

async function imageBytes(value: unknown, signal: AbortSignal): Promise<{ bytes: Uint8Array; mediaType: ImageMediaType }> {
  const item = recordOf(value)
  const direct = nonEmpty(value)
  const base64 = item === undefined ? undefined
    : nonEmpty(item.b64_json) ?? nonEmpty(item.image_base64) ?? nonEmpty(item.base64)
  if (base64 !== undefined) {
    const dataUrl = decodeDataUrl(base64)
    const bytes = dataUrl?.bytes ?? Uint8Array.from(Buffer.from(base64, 'base64'))
    return { bytes, mediaType: dataUrl?.mediaType ?? imageMediaType(bytes) }
  }
  const candidate = direct ?? (item === undefined ? undefined : nonEmpty(item.url) ?? nonEmpty(item.image_url))
  if (candidate === undefined) throw new Error('ClawRouters image response contained neither image bytes nor a URL')
  const embedded = decodeDataUrl(candidate)
  if (embedded !== undefined) return embedded
  const url = new URL(candidate)
  if (url.protocol !== 'https:' && url.protocol !== 'http:') throw new Error('ClawRouters returned a non-HTTP image URL')
  const response = await fetch(url, { signal })
  if (!response.ok) throw new Error(`ClawRouters image download failed with HTTP ${response.status}`)
  const bytes = new Uint8Array(await response.arrayBuffer())
  return { bytes, mediaType: imageMediaType(bytes, response.headers.get('content-type') ?? undefined) }
}

function canonicalImage(ref: ImageAttachmentRef): CanonicalImage {
  return {
    attachmentId: ref.attachmentId,
    mediaType: ref.mediaType,
    bytes: ref.bytes,
    width: ref.width,
    height: ref.height,
    ...ref.name === undefined ? {} : { name: ref.name },
  }
}

function imageRef(image: CanonicalImage): ImageAttachmentRef {
  return {
    attachmentId: AttachmentId(image.attachmentId),
    mediaType: image.mediaType,
    bytes: image.bytes,
    width: image.width,
    height: image.height,
    ...image.name === undefined ? {} : { name: image.name },
  }
}

function imageContent(value: ImageGenerateValue): ContentBlock[] {
  return [
    { type: 'text', text: `ClawRouters generated ${value.images.length} image(s) with model ${value.model}.` },
    ...value.images.map(image => ({ type: 'image' as const, attachment: imageRef(image) })),
  ]
}

function responseImages(value: unknown): unknown[] {
  const root = recordOf(value)
  const data = root?.data ?? root?.images
  if (Array.isArray(data)) return data
  if (data !== undefined) return [data]
  throw new Error('ClawRouters image response did not contain data or images')
}

/** Register image generation only while the durable attachment seam is present. */
export function registerImageTool(ctx: Context, current: CurrentConfig, resolveKey: ResolveKey): void {
  ctx.tools.register(defineTool({
    name: 'clawrouters_image_generate',
    description: 'Generate one or more images with ClawRouters and return the images directly.',
    parameters: {
      prompt: { type: 'string', required: true, description: 'A detailed image-generation prompt.' },
      model: { type: 'string', description: 'Optional ClawRouters image model; defaults to the plugin setting.' },
      count: { type: 'integer', description: 'Number of images, from 1 through 4.' },
      size: { type: 'string', enum: ['1024x1024', '1024x1536', '1536x1024', '1024x1792', '1792x1024', '2048x2048', '2048x1152', '3840x2160', '2160x3840'] },
      aspect_ratio: { type: 'string', enum: ['1:1', '3:4', '4:3', '9:16', '16:9'] },
    },
    output: {
      schema: {
        type: 'object', additionalProperties: false, properties: {
          model: { type: 'string', required: true },
          images: { type: 'array', required: true, items: {
            type: 'object', additionalProperties: false, properties: {
              attachmentId: { type: 'string', required: true },
              mediaType: { type: 'string', enum: ['image/png', 'image/jpeg', 'image/webp', 'image/gif'], required: true },
              bytes: { type: 'integer', required: true },
              width: { type: 'integer', required: true },
              height: { type: 'integer', required: true },
              name: { type: 'string' },
            },
          } },
        },
      },
      render: (_args, value) => imageContent(value),
    },
    timeoutMs: resolveConfig(current()).imageTimeoutMs,
    isConcurrencySafe: () => true,
    async execute(args, exec) {
      const prompt = args.prompt.trim()
      if (prompt.length === 0) throw new Error('prompt must be a non-empty string')
      if (prompt.length > 4_000) throw new Error('prompt must contain at most 4000 characters')
      const count = args.count ?? 1
      if (!Number.isSafeInteger(count) || count < 1 || count > 4) throw new Error('count must be an integer from 1 through 4')
      const config = resolveConfig(current())
      const signal = AbortSignal.any([exec.signal, AbortSignal.timeout(config.imageTimeoutMs)])
      const model = args.model?.trim() || config.imageModel
      const response = await postJson(`${config.baseURL}/images/generations`, await resolveKey(), {
        model, prompt, n: count,
        ...args.size === undefined ? {} : { size: args.size },
        ...args.aspect_ratio === undefined ? {} : { aspect_ratio: args.aspect_ratio },
      }, signal)
      const attachments = ctx.get('attachments')
      if (attachments === undefined) throw new Error('ClawRouters image generation requires an attachment store')
      const decoded = await Promise.all(responseImages(response).map(item => imageBytes(item, signal)))
      if (decoded.length === 0) throw new Error('ClawRouters returned no generated images')
      if (decoded.length > attachments.imageLimits.maxImagesPerMessage) {
        throw new Error(`ClawRouters returned ${decoded.length} images, but this deployment accepts at most ${attachments.imageLimits.maxImagesPerMessage}`)
      }
      await Promise.all(decoded.map((image, index) => attachments.validateImage({
        data: image.bytes, mediaType: image.mediaType, name: `clawrouters-${String(index + 1)}`,
      })))
      const refs = await Promise.all(decoded.map((image, index) => attachments.saveImage({
        data: image.bytes, mediaType: image.mediaType, name: `clawrouters-${String(index + 1)}`,
      })))
      const value: ImageGenerateValue = { model, images: refs.map(canonicalImage) }
      if (exec.parent !== undefined) {
        exec.deferContext(createUserMessage({ content: imageContent(value), source: { kind: 'plugin', plugin: 'clawrouters' } }))
      }
      return value
    },
    presentCall(args): GenericCallView {
      return { card: 'generic', title: `Generate image: ${args.prompt}`, kind: 'other', rawInput: args.prompt }
    },
  }))
}

function videoTask(value: unknown): { taskId?: string; status?: string; url?: string } {
  const root = recordOf(value)
  const data = recordOf(root?.data) ?? root
  if (data === undefined) return {}
  const result = recordOf(data.result)
  const taskId = nonEmpty(data.id) ?? nonEmpty(data.video_id) ?? nonEmpty(data.task_id)
  const status = nonEmpty(data.status)
  const url = nonEmpty(data.result_url) ?? nonEmpty(data.url) ?? nonEmpty(data.video_url)
    ?? nonEmpty(result?.url) ?? nonEmpty(result?.video_url)
  return {
    ...taskId === undefined ? {} : { taskId },
    ...status === undefined ? {} : { status },
    ...url === undefined ? {} : { url },
  }
}

function assertHttpUrl(value: string): string {
  const url = new URL(value)
  if (url.protocol !== 'https:' && url.protocol !== 'http:') throw new Error('ClawRouters returned a non-HTTP video URL')
  return url.href
}

async function delay(ms: number, signal: AbortSignal): Promise<void> {
  await new Promise<void>((resolve, reject) => {
    const abortError = (): Error => signal.reason instanceof Error
      ? signal.reason
      : new Error('ClawRouters operation aborted')
    if (signal.aborted) {
      reject(abortError())
      return
    }
    const timer = setTimeout(resolve, ms)
    signal.addEventListener('abort', () => {
      clearTimeout(timer)
      reject(abortError())
    }, { once: true })
  })
}

/** Register asynchronous video generation with provider-status polling. */
export function registerVideoTool(ctx: Context, current: CurrentConfig, resolveKey: ResolveKey): void {
  ctx.tools.register(defineTool({
    name: 'clawrouters_video_generate',
    description: 'Generate a video with ClawRouters, wait until it is ready, and return its signed result URL.',
    parameters: {
      prompt: { type: 'string', required: true, description: 'A detailed video-generation prompt.' },
      model: { type: 'string', description: 'Optional ClawRouters video model; defaults to the plugin setting.' },
      duration_seconds: { type: 'integer', description: 'Video duration from 2 through 10 seconds.' },
      aspect_ratio: { type: 'string', enum: ['16:9', '9:16', '1:1'] },
    },
    output: { schema: {
      type: 'object', additionalProperties: false, properties: {
        taskId: { type: 'string' }, status: { type: 'string', required: true },
        url: { type: 'string', required: true }, model: { type: 'string', required: true },
      },
    }, render: (_args, value) => [{ type: 'text', text: `ClawRouters video is ready: ${value.url}` }] },
    timeoutMs: resolveConfig(current()).videoTimeoutMs,
    isConcurrencySafe: () => true,
    async execute(args, exec): Promise<VideoGenerateValue> {
      const prompt = args.prompt.trim()
      if (prompt.length === 0) throw new Error('prompt must be a non-empty string')
      const duration = args.duration_seconds ?? 5
      if (!Number.isSafeInteger(duration) || duration < 2 || duration > 10) throw new Error('duration_seconds must be an integer from 2 through 10')
      const config = resolveConfig(current())
      const signal = AbortSignal.any([exec.signal, AbortSignal.timeout(config.videoTimeoutMs)])
      const apiKey = await resolveKey()
      const model = args.model?.trim() || config.videoModel
      const body = {
        model,
        prompt,
        duration_seconds: duration,
        ...args.aspect_ratio === undefined ? {} : { aspect_ratio: args.aspect_ratio },
      }
      let response: unknown
      try {
        response = await postJson(`${config.baseURL}/videos`, apiKey, body, signal)
      } catch (error: unknown) {
        if (!(error instanceof ClawRoutersHttpError) || (error.status !== 404 && error.status !== 405)) throw error
        response = await postJson(`${config.baseURL}/videos/generations`, apiKey, body, signal)
      }
      let task = videoTask(response)
      if (task.url !== undefined) return {
        ...task.taskId === undefined ? {} : { taskId: task.taskId },
        status: task.status ?? 'ready', url: assertHttpUrl(task.url), model,
      }
      if (task.taskId === undefined) throw new Error('ClawRouters video response contained neither a task id nor a result URL')
      const taskId = task.taskId
      const success = new Set(['ready', 'completed', 'complete', 'succeeded', 'success', 'done'])
      const failure = new Set(['failed', 'failure', 'cancelled', 'canceled', 'error'])
      while (true) {
        await delay(config.videoPollIntervalMs, signal)
        task = videoTask(await getJson(`${config.baseURL}/videos/${encodeURIComponent(taskId)}`, apiKey, signal))
        const status = (task.status ?? 'in_progress').toLowerCase()
        if (failure.has(status)) throw new Error(`ClawRouters video task ${taskId} ended with status ${status}`)
        if (task.url !== undefined && (success.has(status) || task.status === undefined)) {
          return { taskId, status, url: assertHttpUrl(task.url), model }
        }
      }
    },
    presentCall(args): GenericCallView {
      return { card: 'generic', title: `Generate video: ${args.prompt}`, kind: 'other', rawInput: args.prompt }
    },
  }))
}

function searchValue(value: unknown, query: string): SearchValue {
  const root = recordOf(value)
  const data = recordOf(root?.data) ?? root
  const rawResults = data?.results
  if (!Array.isArray(rawResults)) throw new Error('ClawRouters search response did not contain results')
  const sources = rawResults.map((item): SearchSource | undefined => {
    const result = recordOf(item)
    const url = nonEmpty(result?.url)
    if (url === undefined) return undefined
    assertHttpUrl(url)
    const title = nonEmpty(result?.title)
    const snippet = nonEmpty(result?.snippet)
    const publishedAt = nonEmpty(result?.published)
    return { url,
      ...title === undefined ? {} : { title },
      ...snippet === undefined ? {} : { snippet },
      ...publishedAt === undefined ? {} : { publishedAt },
    }
  }).filter((source): source is SearchSource => source !== undefined)
  const provider = nonEmpty(data?.provider)
  return {
    query: nonEmpty(data?.query) ?? query,
    ...provider === undefined ? {} : { provider },
    ...typeof data?.cached !== 'boolean' ? {} : { cached: data.cached },
    ...typeof data?.took_ms !== 'number' ? {} : { tookMs: data.took_ms },
    sources,
  }
}

function formatSearch(value: SearchValue): string {
  if (value.sources.length === 0) return 'No results found.'
  const lines = value.sources.map((source, index) => {
    const label = source.title ?? source.url
    return `${String(index + 1)}. [${label}](${source.url})${source.snippet === undefined ? '' : ` — ${source.snippet}`}`
  })
  return `ClawRouters search results:\n${lines.join('\n')}\n\nCite the relevant URLs above as markdown links.`
}

/** Register a named search tool so existing generic web providers remain unambiguous. */
export function registerSearchTool(ctx: Context, current: CurrentConfig, resolveKey: ResolveKey): void {
  ctx.tools.register(defineTool({
    name: 'clawrouters_web_search',
    description: 'Search the current web through ClawRouters. Returns source URLs, titles, and snippets.',
    parameters: {
      query: { type: 'string', required: true, description: 'The web search query.' },
      count: { type: 'integer', description: 'Number of results, from 1 through 10.' },
      search_depth: { type: 'string', enum: ['basic', 'advanced'] },
      language: { type: 'string', description: 'Optional result language such as zh or en.' },
      categories: { type: 'array', items: { type: 'string' }, description: 'Optional search categories.' },
    },
    output: { schema: {
      type: 'object', additionalProperties: false, properties: {
        query: { type: 'string', required: true }, provider: { type: 'string' }, cached: { type: 'boolean' }, tookMs: { type: 'number' },
        sources: { type: 'array', required: true, items: { type: 'object', additionalProperties: false, properties: {
          url: { type: 'string', required: true }, title: { type: 'string' }, snippet: { type: 'string' }, publishedAt: { type: 'string' },
        } } },
      },
    }, render: (_args, value) => [{ type: 'text', text: formatSearch(value) }] },
    timeoutMs: resolveConfig(current()).searchTimeoutMs,
    isConcurrencySafe: () => true,
    async execute(args, exec): Promise<SearchValue> {
      const query = args.query.trim()
      if (query.length === 0) throw new Error('query must be a non-empty string')
      if (query.length > 500) throw new Error('query must contain at most 500 characters')
      const count = args.count ?? 8
      if (!Number.isSafeInteger(count) || count < 1 || count > 10) throw new Error('count must be an integer from 1 through 10')
      const config = resolveConfig(current())
      const signal = AbortSignal.any([exec.signal, AbortSignal.timeout(config.searchTimeoutMs)])
      const response = await postJson(`${config.baseURL}/search`, await resolveKey(), {
        query, count,
        search_depth: args.search_depth ?? 'basic',
        ...args.language === undefined ? {} : { language: args.language },
        ...args.categories === undefined ? {} : { categories: args.categories },
      }, signal)
      return searchValue(response, query)
    },
    presentCall(args): GenericCallView {
      return { card: 'generic', title: args.query, kind: 'search', rawInput: args.query }
    },
  }))
}
