/**
 * dsh-task-stack — a persistent per-session task stack for DeepSeek Harness.
 *
 * This plugin gives an agent three explicit tools — `focus_task`,
 * `focus_complete`, and `read_focus` — that push, pop, and inspect a
 * last-in-first-out stack of multi-step work items, plus one human-facing
 * `/focus` command for inspecting and clearing that stack without spending a
 * model turn. The stack is persisted as a plain-text JSON document under the
 * session workspace (`<session-cwd>/<stateDir>/<sessionId>.json`), so it
 * survives context compaction and is recoverable when the session is resumed.
 *
 * The plugin is deliberately inert: it contributes **no** system-prompt text
 * and no automatic context injection, so it costs zero tokens until the model
 * calls one of its tools or a human types the command.
 *
 * @module dsh-task-stack
 */

import type { Context } from '@deepseek-ai/cordis'
import z from '@deepseek-ai/schemastery'
import { Store } from './store.ts'
import { registerFocusTools } from './tools.ts'
import { registerFocusCommand } from './commands.ts'
import { registerSnapshotRoute, type ComplianceGate, type WebRouteHost } from './http.ts'
import { resolveConfig, type PluginConfig } from './types.ts'

/**
 * Plugin display name; the fiber label and the logger name.
 *
 * Deliberately the SHORT name rather than the scoped package name: the scope
 * belongs to whoever publishes the package, while this label is what a user reads
 * in `[dsh-task-stack]` log lines. `check-build` and the probe derive the expected
 * label from `package.json` (scoped name minus its scope), so the two cannot
 * silently drift apart.
 */
export const name = 'dsh-task-stack'

/**
 * Required services: `tools` for the three model-facing tools, `commands` for
 * the `/focus` slash command. Both are provided by the base bundle of every
 * shipped profile, so the plugin stays loadable everywhere.
 */
export const inject = ['tools', 'commands']

/**
 * Configuration schema, validated by Cordis before {@link apply} runs.
 *
 * Each field is optional with a default, and Cordis's transform means `apply`
 * always receives a fully resolved config — a partial patch layer, an empty
 * `config:` block, and a missing block all behave the same. Out-of-range values
 * fail validation here (the plugin does not activate, and the boot log names the
 * offending field) instead of being silently coerced, because a silently
 * different policy is harder to diagnose than a refused plugin.
 */
export const Config = z.object({
  /** Directory for state files, relative to the session workspace. */
  stateDir: z
    .string()
    .min(1)
    .default('.dsh/task-stack')
    .description('Directory holding one JSON file per session, relative to the session workspace.'),
  /** Maximum number of frames on one stack. */
  maxStackDepth: z
    // `natural()` alone accepts 0, which would make every push fail.
    .natural()
    .min(1)
    .default(20)
    .description('Maximum number of open tasks on the stack; focus_task refuses to push past it.'),
  /** Maximum number of completed records kept per session. */
  historyLimit: z
    .natural()
    .min(1)
    .default(100)
    .description('Maximum number of completed tasks kept in history; the oldest records are trimmed first.'),
  /** Age in days after which an untouched session file is deleted on plugin load. */
  statePruneDays: z
    .natural()
    .default(0)
    .description(
      'Delete session state files not written for this many days, once per plugin load; 0 (the default) keeps every file.',
    ),
})

/**
 * Register the task-stack tools and the `/focus` command.
 *
 * The disposer returned by `ctx.tools.register()` is already Cordis-managed, so
 * unloading the plugin (including a hot reload) unregisters all three tools; the
 * extra effect here additionally releases the store's per-file lock map and
 * cannot leave an "already registered" error behind. Pruning is fire-and-forget:
 * its result only reaches the log, so a slow or failing scan never delays
 * activation or fails the plugin.
 *
 * @param ctx - the plugin context carrying the `tools` and `commands` services.
 * @param config - config resolved by {@link Config}; every field is present.
 */
export function apply(ctx: Context, config: PluginConfig): void {
  const logger = ctx.logger(name)
  const resolved = resolveConfig(config)
  const store = new Store(resolved, logger)

  ctx.effect(() => {
    const disposeTools = registerFocusTools(ctx, store)
    const disposeCommand = registerFocusCommand(ctx, store)
    // The HTTP surface is optional: `webServer` and `connection` exist in the Web
    // composition but not in a terminal or headless one. They are read with
    // `ctx.get` rather than declared in `inject`, because a missing optional
    // service must not stop the tools from loading.
    const disposeRoute = registerOptionalHttpSurface(ctx, store, logger)
    return () => {
      disposeRoute?.()
      disposeCommand()
      disposeTools()
      // The lock map is plugin state, not a Cordis registration; releasing it
      // here is the one thing the registry's own effects do not do.
      store.release()
    }
  }, 'dsh-task-stack')

  if (resolved.statePruneDays > 0) {
    // Fire-and-forget: pruning is housekeeping, so it never delays activation,
    // and it runs with no known session id — a file that old belongs to no live
    // session.
    void store
      .prune({ cwd: process.cwd(), days: resolved.statePruneDays })
      .then((result) => {
        if (result.removed.length > 0 || result.failed > 0) {
          logger.info(
            '%s',
            `pruned ${result.removed.length} stale state file(s), kept ${result.kept}, failed ${result.failed}`,
          )
        }
      })
      .catch((error: unknown) => {
        logger.warn('%s', `state prune failed: ${error instanceof Error ? error.message : String(error)}`)
      })
  }

  logger.info(
    '%s',
    `loaded — focus_task/focus_complete/read_focus + /focus registered; stateDir=${resolved.stateDir} maxStackDepth=${resolved.maxStackDepth} historyLimit=${resolved.historyLimit} statePruneDays=${resolved.statePruneDays}`,
  )
}

/**
 * Register the read-only snapshot endpoint once this composition has an HTTP
 * surface.
 *
 * Both services are optional and are therefore NOT declared in {@link inject}:
 * a terminal or headless profile has no `webServer`, and requiring it would leave
 * the whole plugin pending (no tools, no `/focus`).
 *
 * They must be **waited for**, not read once. In the shipped Web profile the
 * `webserver` row itself injects `webStartup`, so it activates after a plugin row
 * that only needs `tools`. Reading `ctx.get('webServer')` during `apply` returned
 * `undefined` there, and the endpoint silently never registered — which is exactly
 * what `ctx.inject` exists to avoid.
 *
 * A missing `connection` still registers the route, which then answers 503: the
 * data plane stays fail-closed rather than silently unauthenticated.
 *
 * @param ctx - plugin context, possibly carrying `webServer` and `connection`.
 * @param store - the plugin's store.
 * @param logger - plugin logger.
 * @returns a disposer reserving the route slot, if one is registered later.
 */
function registerOptionalHttpSurface(
  ctx: Context,
  store: Store,
  logger: { info: (format: unknown, ...params: unknown[]) => void; warn: (format: unknown, ...params: unknown[]) => void },
): () => void {
  let disposeRoute: (() => void) | undefined
  let dropped = false

  ctx.inject(['webServer'], (injected: Context) => {
    if (dropped) return
    const host = injected.get('webServer' as never) as WebRouteHost | undefined
    if (host === undefined) return
    // The fence is resolved per REQUEST, not here: `connection` may not exist yet
    // (both rows inject `webRuntime`, so their order is not guaranteed) and a
    // captured reference would also go stale across a `connection` reload.
    disposeRoute = registerSnapshotRoute(
      host,
      store,
      () => ctx.get('connection' as never) as ComplianceGate | undefined,
      (sessionId) => sessionWorkspace(ctx, sessionId),
      logger,
    )
  })

  return () => {
    dropped = true
    disposeRoute?.()
    disposeRoute = undefined
  }
}

/**
 * Read a session's workspace from the host's own session registry.
 *
 * Resolved per request, for the same reason the fence is: `sessions` is provided by
 * the host bundle rather than by this plugin, so it may arrive after the route is
 * registered, and a captured reference would go stale across a reload.
 *
 * Every step is defensive because this runs inside an HTTP handler: the registry's
 * shape is not this package's contract, and a handler that throws would surface as
 * an opaque 400 instead of a snapshot.
 *
 * @param ctx - plugin context, possibly carrying `sessions`.
 * @param sessionId - session whose `header.cwd` is wanted.
 * @returns the absolute workspace, or `undefined` when the host does not know it.
 */
function sessionWorkspace(ctx: Context, sessionId: string): string | undefined {
  let registry: unknown
  try {
    registry = ctx.get('sessions' as never)
  } catch {
    // An absent service raises rather than returning undefined in some Cordis
    // versions; treat that exactly like "not provided".
    return undefined
  }
  if (registry === null || typeof registry !== 'object') return undefined
  const get = (registry as { get?: (id: string) => unknown }).get
  if (typeof get !== 'function') return undefined
  let session: unknown
  try {
    session = get.call(registry, sessionId)
  } catch {
    return undefined
  }
  if (session === null || typeof session !== 'object') return undefined
  const cwd = (session as { header?: { cwd?: unknown } }).header?.cwd
  return typeof cwd === 'string' && cwd.length > 0 ? cwd : undefined
}
