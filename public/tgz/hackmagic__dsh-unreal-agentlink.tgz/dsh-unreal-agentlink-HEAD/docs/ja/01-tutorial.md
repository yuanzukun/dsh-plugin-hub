<div align="center">

[English](../01-tutorial.md) · [简体中文](../zh/01-tutorial.md) · [繁體中文](../zh-TW/01-tutorial.md) · **日本語** · [한국어](../ko/01-tutorial.md) · [Deutsch](../de/01-tutorial.md) · [Español](../es/01-tutorial.md) · [Français](../fr/01-tutorial.md) · [Русский](../ru/01-tutorial.md)

[README](../readme/README_ja.md) · **チュートリアル** · [プロトコル](02-protocol.md) · [アーキテクチャ](03-architecture.md) · [コマンドリファレンス](command-reference.md)

</div>

# チュートリアル：ゼロから動くブリッジまで

これは端から端までの手順だ。目標：DSH の中のエージェントが実際にローカルの Unreal Editor を駆動できるようにし、何をすべきか、何が詰まるのかを知ること。

推奨する読み順：このページ → [プロトコル](02-protocol.md) → [アーキテクチャ](03-architecture.md) → [コマンドリファレンス](command-reference.md)。

---

## 1. メンタルモデル：まず 4 つの事実

何かに触る前に、この 4 つの事実が後続のすべての操作の書き方を決める。これらは設計上の選択ではない —— UnrealAgentLink の既存の制約だ。

**① 向きが逆だ。** このプラグインはエディタにダイヤルしない。**エディタがダイヤルアウトする**。UnrealAgentLink C++ プラグインは `StartupModule` で無条件に `ws://127.0.0.1:17860` を開き、このプラグインがそのポートを待ち受ける。だから起動順序は関係ない：エディタが先に起きれば 5 秒ごとにリトライし、プラグインが現れた時点で接続できる。

**② 認証はない。** トークンもヘッダーもサブプロトコルもない。**ポートそのものが資格情報**だ —— 17860 に到達できる者は誰でもエディタを駆動できる。だからデフォルトではループバックにのみバインドし、`0.0.0.0` には変更すべきでない。

**③ コマンドはゲームスレッド上で直列に実行される。** エディタはコマンドを受け取ると、まだゲームスレッドにいなければそこへ再投稿し、**完了まで同期的に実行する**。2 つの帰結：

- 同じエディタへのコマンドは自然にキューイングし、このプラグインもエディタごとに直列に送信する。
- **ブロッキングコマンドの実行中、エディタは何も返さない** —— `sequence.render_status` のような進捗問い合わせすら返さない。その間に何かを送っても、ただ後ろに並ぶだけだ。

**④ 取り消しはない。** プロトコルに `query_task` / `cancel_task` は存在しない。`ual_task` のジョブを kill しても止まるのは**このプラグイン側の待機**だけだ。エンジンは動き続け、結果は依然として返ってくる。この文は、モデルが読めるように `ual_task` のツール説明に書き込まれている。

---

## 2. 前提条件

| 項目 | 要件 | 備考 |
|---|---|---|
| Unreal Engine | 5.0 – 5.8 | プラグインの `.uplugin` が宣言する範囲 |
| UnrealAgentLink | C++ プラグイン本体 | プロジェクトの `Plugins/` にコピーする |
| Node.js | `^22.19.0 \|\| >=24.0.0` | `package.json` の `engines` を参照 |
| DSH ランタイム | 動作するインストールなら何でも | このプラグインはバンドルとして読み込まれる |

**UEBox デスクトップアプリは不要。** 同じベンダーの別のクライアントで、たまたま同じ 17860 ポートを使っているだけなので、両方を同時に動かすとポート衝突になる。詳しくは [README の「UEBox は不要」](../readme/README_ja.md#uebox-は不要) を参照。

**Unreal Engine も要らない** —— このプラグインが動くところを見たいだけなら。UEBox はこのブリッジへ*外向きに*接続するので、偽のエディタは応答する WebSocket クライアントにすぎない：

```bash
npm run smoke     # 本物のサービス + 偽のエディタ：12 個のツールをすべて呼び、各結果を検証する
npm run mock:ue   # 偽のエディタだけを起動し、手で触ってみる
```

`tools/mock-ue-editor.mjs` は `ws://127.0.0.1:17860` に接続し、`project.info` と `system.heartbeat` をプッシュし、`log.entry` の行を転送し、`editor.screenshot` 用に本物の PNG を書き出し、カタログ化された 170 メソッドすべてに応答する。以下の手順はすべてこれに対して試せる。

### UE プロジェクトへの UnrealAgentLink のインストール

1. `UnrealAgentLink` ディレクトリ全体をプロジェクトの `Plugins/` にコピーする（グローバルに入れる場合はエンジンの `Plugins/`）。
2. プロジェクトファイルを再生成して開く。
3. **Edit → Plugins** で UnrealAgentLink が有効になっていることを確認する。

プラグインは 2 つのエンジン付属依存（`IKRig` と `PythonScriptPlugin`）を自動的に有効にする（`.uplugin` を参照）。エディタが起動すれば、設定なしで 17860 への接続を始める。

> ポートが埋まっている場合（UEBox デスクトップアプリなど）、エディタに別のポートを与える：
> `UnrealEditor.exe MyProject.uproject -UALServer=ws://127.0.0.1:17861`
> このプラグイン側の `port` 設定も合わせて変更する。

---

## 3. このプラグインのインストール

```bash
git clone <this-repo> dsh-unreal-agentlink
cd dsh-unreal-agentlink
npm install
npm run check      # typecheck (src + tests) + 189 tests + catalog + doc reconciliation, one command
```

先に進む前に `npm run check` が完全にグリーンでなければならない。それが確かめるのは 3 つ：ソースとテストの両方が型チェックを通ること、振る舞いのテストがすべて通ること、170 コマンドのカタログが C++ のレジストリと 1 件ずつ一致すること。

### DSH バンドルとしてインストールする

`package.json` は `dsh.bundle.patch: ./cordis.patch.yml` を宣言し、そのファイルがすることは 1 つだけ：

```yaml
- insert:
    - id: unreal-agentlink
      name: dsh-unreal-agentlink
```

**注意**：DSH の設定レイヤリングでは、後の層はこの行の `config` をディープマージではなく**全体置き換え**する。任意のキーを上書きするには、残したいキーをすべて書き直す必要がある。

#### インストールスクリプトを使う

DSH にはローカルの out-of-tree プラグインをインストールするコマンドが同梱されていない。だからこのリポジトリは 1 つ同梱している：

```bash
npm run status:dsh -- --profile web   # 現在登録されている内容（npm パススルー）
node scripts/install-dsh-plugin.mjs --profile web            # ミラー、manifest の編集、インストール、検証
```

動作中の DSH がまだ保持している manifest には触れず、成功を報告する前に layer が合成されていることを証明する —— `desktop` profile 以外ではどこでも `--dump-config` を使うが、その profile は CLI が合成しないので、代わりに `dsh plugin --profile desktop list` がそれを担う。宣言されたピア範囲は、このプラグインがビルド対象としているバージョンと、現在の dsh が出荷される元である `0.2.x` ラインの両方をカバーしているので、ピア依存のガードが通常のインストールを止めることはない。将来のランタイムがその範囲外になった場合は、リスクを受け入れるための正確なコマンドが dsh から出力される —— **その決定はあなたのものであって、スクリプトのものではない**。

#### 手動でインストールする

根底にある機構は 4 ステップだ。`<profile>` は `web`（または `desktop`、下記の注意を参照）とする：

```bash
npm run build    # ミラーには lib/ が入る。ビルド前のミラーは不完全なプラグインになる
cp -r lib cordis.patch.yml package.json LICENSE README.md "$DSH_HOME/profiles/<profile>/.vendor/"
dsh plugin --profile <profile> install
dsh --profile <profile> --dump-config | grep -A2 '# == dsh-unreal-agentlink'
```

加えて `<profile>/package.json` 内の 2 つのエントリ：

```json
"dependencies": { "dsh-unreal-agentlink": "file:C:/Users/you/.dsh/profiles/web/.vendor" },
"dsh": { "profile": { "bundles": ["@deepseek-ai/dsh-base", "dsh-unreal-agentlink"] } }
```

どちらも必須で、失敗のしかたが違う：`dsh.bundle` を宣言しない列挙されたパッケージは起動時に**大声で失敗する**が、インストールされているのに列挙されていないパッケージは**レイヤーをまったく提供しない**。そして `file:` は作業スペースではなくコピーを指さなければならない —— pnpm はインストール時に見つけたものをコピーするので、半分保存されたソースファイルが DSH が読み込むプラグインになってしまう。

`desktop` profile も同じ 4 ステップで、最後の 1 つだけが違う：`dsh --profile desktop …` は拒否され（`bin.js:112` が Electron profile を拒否する）、一方 `dsh plugin --profile desktop …` は意図的に除外されている（`bin.js:119`）ので、Desktop 同梱の CLI 自身が使う経路はこちらだ。だから先にアプリを終了すること —— 製品自身のメッセージがまさにそれを求めている。動作中のアプリはメモリ上のプラグイン一覧から manifest を書き戻すからだ —— その後でインストールを実行し、ステップ 4 の代わりに `dsh plugin --profile desktop list` で証明する。

AI エージェントがインストールを行う場合は、代わりに [INSTALL-ai.md](INSTALL-ai.md) を渡すこと —— それは同じ手順を、読み取りと検証ができるチェックリストとして書いたものだ。

---

## 4. 最初の接続

### ステップ 1：ブリッジが生きているか確認する

エージェントに `ual_status` を呼ばせる。4 つのフィールドを見る：

```
listening: true
url: ws://127.0.0.1:17860
editors: [ { sessionId: "ue-xxxxxxxx", project: "MyProject", ... } ]
```

- `listening: false` → プラグインが起動していないか、ポートが埋まっている。DSH のログで `EADDRINUSE` を探す。
- `listening: true` だが `editors: []` → ブリッジは待機中だ。UE プロジェクトが開いていて、UnrealAgentLink が有効になっていることを確認する。

エディタが接続した**最初の瞬間**、そのレコードには `sessionId` / `connectedAt` / `lastSeenAt` / `heartbeats` / `stale` しかない。`project` などのフィールドは、エディタが `project.info` をプッシュした後に初めて現れる。これは正常な状態で、エラーではない。

### ステップ 2：機能を発見する

コマンド名を推測してはならない。2 ステップで：

```
ual_tools  { filter: "material" }        → list the material family with a one-line summary each
ual_schema { method: "material.create" } → that command's param keys, required keys, result keys, status codes
```

`ual_schema` のキー名は C++ ハンドラから**逐語的に抽出**されている。このステップを飛ばさないこと：**UE は未知のキーや型の違うキーを黙って無視する** —— キー名のスペルミスはエラーにならず、何もしないまま「成功」してしまう。

### ステップ 3：最初の実呼び出し

```
ual_call { method: "level.get_current" }
```

純粋な読み取りで、副作用はない。エディタの `result` を**逐語的に**返す。このプラグインはそれを作り変えない。

### ステップ 4：レベルを見る

```
ual_screenshot { width: 1280, height: 720 }
```

返ってくるのはエージェントが直接見られる**本物の画像**だ。ファイルパスだけを返す `ual_call { method: "editor.screenshot" }` より優れている。

スクリーンショットの `pending_shaders` / `pending_assets` が 0 でない場合、ビューはまだコンパイル中かストリーミング中で、**最終的な見た目ではない**。それだけでマテリアルが壊れていると判断してはならない。

---

## 5. よく使うワークフロー

### アクターのプロパティを変更する

```
ual_schema { method: "actor.set_property" }        # check key names first
ual_call   { method: "actor.get_info", params: { targets: { names: ["Cube_1"] } } }
ual_call   { method: "actor.set_property", params: {
               targets: { names: ["Cube_1"] },
               properties: { Mobility: "Movable" } } }
```

プロパティ名のスペルを間違えると、エディタは 404 ではなく**候補を返す**。候補を読むこと。間違えた綴りを再試行してはならない。

### バッチ操作

既知の手順の連続には、1 往復で済ませるために `ual_batch` を使う：

```
ual_batch { calls: [
  { method: "actor.spawn", params: { asset_id: "cube", name: "A" } },
  { method: "actor.spawn", params: { asset_id: "cube", name: "B" } },
  { method: "actor.get_info", params: { targets: { names: ["A", "B"] } } }
] }
```

- 直列に実行される（エディタ自体が直列なので）し、デフォルトでは**最初の失敗で止まる**。`continueOnError: true` がそれを変える。
- 上限は `maxBatchCalls`（デフォルト 12）。
- **1 つでも危険な項目があれば、バッチ全体が承認を通過する。** 承認プロンプトにはどの項目だったかが書かれる。

### 長時間のタスク

ゲームスレッドをブロックするコマンドは `ual_task` を通さなければならない：

```
ual_task { method: "sequence.render", params: { sequence_path: "/Game/Seq/Main" }, label: "Render main sequence" }
```

`jobId` を即座に返し、会話は続行できる。結果は `job_output` で回収する。

どれが長いか：`sequence.render`、`cpp.compile`、`level.build`、`blueprint.compile_all`、`pcg.execute`、`pie.run`、アセットのインポート。`ual_schema` のタイムアウト列が "blocking" と印を付けている。

長時間タスクの実行中はエディタをポーリング**しないこと** —— 返事はない。

### ロールバック

```
ual_undo_history            # see what is in the buffer first
ual_undo { dryRun: true }   # rehearse
ual_undo                    # actually undo
```

UnrealAgentLink は**エディタごとに 1 つの独立したエージェント用アンドゥスタック**を保持しており、ユーザーの Ctrl+Z 履歴とは別物だ。このプラグインは各ステップがどの DSH セッションのものかを記録し、**このセッションのステップがバッファのきれいな LIFO サフィックスを形成する場合にのみロールバックする**。間に別のセッションがエディタを触っていた場合、このツールは**何も取り消さず**、他人の作業をこっそり捨てる代わりに両方のステップ一覧を報告する。

### アセットロックの取得

アセットへの複数ステップにわたる変更の前に：

```
ual_locks { claim: ["/Game/Materials/M_Rock"] }
... make changes ...
ual_locks { release: ["/Game/Materials/M_Rock"] }
```

エディタはコンテンツブラウザに「AI が編集中」バッジを描画し、ユーザーが手で編集し始めると警告される。複数セッションからの要求は、このプラグインが送信前に 1 つのテーブルにマージし、エディタの再接続後に再送する。

### ログを読む

```
ual_logs { level: "Warning", contains: "Niagara" }
```

ログリングはデフォルトで空だ —— UE 側のログ転送は**デフォルトで無効**で、エディタ内で `ual.ForwardLogs 1` を実行する必要がある（このプラグインはリモートで有効にできない）。何も返らないとき、`ual_logs` はその旨を伝える。

転送が無効な間は、代わりにエンジン自身のメッセージログを読む。これは**カテゴリツリー**であってフラットなリストではない：エンジンがどのカテゴリを保持しているかを尋ね、次にその中の行を要求する。

```
ual_logs { pullMessageLog: true }                     # エンジンが持つカテゴリ
ual_logs { pullMessageLog: true, category: "PIE" }    # その中の行
```

最初の形は `messagelog.list` を呼ぶ。これは**パラメータをまったく取らず**、`{categories: [{name, label}]}` で答える —— つまりカテゴリが存在することは教えてくれるが、それが何を言ったかは決して教えてくれない。行は `messagelog.get` から来る。これは `category` を 1 つ必要とし、2 番目の形が呼ぶのはこちらだ。どちらも生のペイロードが欲しければ `ual_call` 経由で到達できる。

---

## 6. 失敗を読む

このプラグインは**エラーテキストを決して解析しない**（テキストはエディタの言語設定によって中文と英文を行き来する）。分類は**エラークラス名とステータスコード**だけに基づき、16 種類に分ける。

| kind | 意味 | 対処 |
|---|---|---|
| `no-editor` | エディタが接続されていない | UE プロジェクトを開く。プラグインが有効か確認する |
| `timeout` | タイムアウト。**コマンドはまだ実行中の可能性がある** | **再送しない**。まず読み取りコマンドで実際の状態を確認する |
| `editor-lost` | エディタが切断した | 5 秒周期の再接続を待つ |
| `queue-stalled` | 先行コマンドがタイムアウトした | `ual_status` の `orphaned` を確認する |
| `circuit-open` | 繰り返す通信失敗でブレーカーが開いた | 止まってクールダウンを待つ。`ual_status` を確認する |
| `rate-limited` | レート制限のキューが満杯 | 間隔を空ける |
| `not-found` | そのようなメソッドまたはアセットは存在しない | `ual_tools` で実際のコマンド名を調べる |
| `bad-params` | パラメータが欠けているか型が違う | `ual_schema` でキー名を確認する |
| `precondition` | 事前条件の失敗（412/413/422） | `details` を読む。422 は「入力は正当だが何も書き込まれなかった」を意味する |
| `registry-busy` | アセットレジストリがまだスキャン中 | `content.registry_status` をポーリングする |
| `unsupported` | このエディタのバージョンでは非対応 | 例：`anim.*` は UE 5.5 以降が必要 |
| `engine-error` | エディタ自体が失敗した | `result.message`（人間向け）と `details`（機械向け）を読む |

**最も規律を必要とするのがタイムアウトだ。** プロトコルに取り消しはないので、タイムアウトは「このプラグインが待つことをやめた」ことだけを意味する —— コマンドはゲームスレッド上でまだ動いている可能性が高い。正しい対処：`ual_status` の `orphaned` を確認し、読み取り専用コマンドで実際の状態を確かめ、**再送しない**。

---

## 7. 設定

すべてのキーは変更可能で、デフォルト値は「動くが怠惰」だ。完全な表は [README の「設定」](../readme/README_ja.md#設定) にある。特筆すべきは：

- **`port`** —— ここで変えたら、UE 側でも `-UALServer=` が必要になる。
- **`rateLimitRps: 0`** —— レート制限を無効化する。
- **`rollbackOnDispose: false`** —— セッション終了時に自動では取り消さない。オンにすると破棄時にロールバックするようになり、たいていユーザーが求めていない驚きになる。
- **`logForwardingEnabled: false`** —— エディタ内で `ual.ForwardLogs 1` を実行した後にのみ `true` にする。

---

## 8. トラブルシューティング

**`ual_status` が `listening: true` を示すがエディタがいない**
UE プロジェクトが開かれていないか、UnrealAgentLink が有効になっていない。エディタのログで `LogUALNetwork` も確認できる：通常は `Connecting to ws://127.0.0.1:17860` と `Connected to` が見えるはずだ。

**起動時に `EADDRINUSE`**
17860 が埋まっている。多くは UEBox デスクトップアプリが原因だ。それを閉じるか、エディタとこのプラグインの両方を別のポートに移す。

**コマンドがすべて `unknown-method` を返す、あるいはその場で拒否される**
このプラグインは、カタログに実在する 170 コマンドだけを通す。`ual_tools` で名前を確認すること。非推奨のコマンド（`editor.play`、`take_screenshot` など）は、代わりに使うべきコマンドを返す。

**スクリーンショットが黒い、または未完成**
`pending_shaders` / `pending_assets` を確認する。0 でなければ、コンパイルまたはストリーミングが終わっていない。`warmup_frames` を増やして再試行する。

**`ual_undo` が実行を拒否する**
このセッションのステップがバッファのきれいな LIFO サフィックスになっていない —— 間に別のセッションがエディタを触った。これは**意図的な保護**であり、バグではない。`ual_undo_history` で実際の内容を見る。

**設定の変更が効かなかった**
DSH の設定レイヤリングはその行の `config` をディープマージではなく**全体置き換え**する。残したいキーはすべて書き出す必要がある。

**`ual_task` のジョブを kill したがエディタがまだビジー**
想定内だ。プロトコルに取り消しはない。終わるまで待つ —— あるいは、もっと実用的には、長時間タスクの実行中は他のコマンドを送らない。

---

## 9. 次のステップ

- [プロトコルリファレンス](02-protocol.md) — メッセージ構造、イベント、ステータスコード
- [アーキテクチャ](03-architecture.md) — ゲートチェーン、セッション分離、エラー翻訳の背景にある理由
- [コマンドリファレンス](command-reference.md) — 全 170 コマンドのパラメータと結果キー（自動生成）
