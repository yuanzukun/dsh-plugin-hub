//! dsh-screen —— dsh-computer-use 的原生屏幕捕获 helper。
//!
//! 为什么用 Rust 重写掉原来的 PowerShell helper：
//!   1. **无 shell 启动开销**：每次截图不再付出一次 powershell.exe 的启动代价
//!   2. **类型在编译期检查**：屏幕几何、坐标、结构体字段都是强类型，
//!      不会再出现「属性取到 null 却一路算下去」这类只在运行时才暴露的问题
//!   3. **屏幕几何由系统权威提供**：用 Win32 的显示器枚举与虚拟桌面矩形，
//!      而不是依赖某个脚本层的属性（那正是原实现踩坑的地方）
//!   4. **行为可复现**：直接跑这个 exe 就能看到输入输出，不依赖宿主环境
//!
//! 通信协议与原 PowerShell helper **完全一致**，方便宿主侧平滑替换：
//!   - 参数走 argv（`screenshot --display-id ... --x ...`）
//!   - 截图参数走 stdin：base64(UTF8 JSON)
//!   - 结果走 stdout：压缩 JSON
//!
//! 关键不变量（宿主侧依赖它做坐标换算）：**回传的 sourceBounds 必须等于实际截取的区域**。
//! 宿主用「sourceBounds + 图像尺寸」的比例关系把「截图坐标」还原成「屏幕坐标」
//! （见 src/tool.js 的 mapScreenshotPoint），所以区域裁剪只要如实回报边界，
//! 点击/拖拽/滚动的坐标就自动继续正确。

// 这是由宿主通过继承的 stdin/stdout 管道驱动的 helper。Windows 下分配或销毁
// 隐藏控制台仍可能改变前台并结束活动菜单；观察进程必须不创建控制台窗口。
#![cfg_attr(target_os = "windows", windows_subsystem = "windows")]

mod color_search;
mod image_match;
mod image_template;
mod input_sequence;
mod listview;
mod ocr;
mod visual;
mod window_control;
mod window_query;

use std::io::{Read, Write};
use std::path::Path;
use std::process::ExitCode;

use base64::Engine as _;
use serde::{Deserialize, Serialize};
use windows::core::PWSTR;
use windows::Win32::Foundation::{CloseHandle, BOOL, FALSE, HWND, LPARAM, RECT, TRUE};
use windows::Win32::Graphics::Gdi::{
    BitBlt, CreateCompatibleBitmap, CreateCompatibleDC, DeleteDC, DeleteObject,
    EnumDisplayMonitors, GetDC, GetDIBits, GetMonitorInfoW, GetPixel, ReleaseDC, SelectObject,
    BITMAPINFO, BITMAPINFOHEADER, BI_RGB, CLR_INVALID, DIB_RGB_COLORS, HBITMAP, HDC, HMONITOR,
    MONITORINFO, MONITORINFOEXW, ROP_CODE,
};
use windows::Win32::System::Threading::{
    AttachThreadInput, GetCurrentThreadId, OpenProcess, QueryFullProcessImageNameW,
    PROCESS_NAME_WIN32, PROCESS_QUERY_LIMITED_INFORMATION,
};
use windows::Win32::UI::HiDpi::{SetProcessDpiAwareness, PROCESS_PER_MONITOR_DPI_AWARE};
use windows::Win32::UI::Input::KeyboardAndMouse::{
    keybd_event, mouse_event, SendInput, SetFocus, INPUT, INPUT_0, INPUT_KEYBOARD, KEYBDINPUT,
    KEYBD_EVENT_FLAGS, KEYEVENTF_KEYUP, KEYEVENTF_UNICODE, MOUSEEVENTF_HWHEEL,
    MOUSEEVENTF_LEFTDOWN, MOUSEEVENTF_LEFTUP, MOUSEEVENTF_MIDDLEDOWN, MOUSEEVENTF_MIDDLEUP,
    MOUSEEVENTF_RIGHTDOWN, MOUSEEVENTF_RIGHTUP, MOUSEEVENTF_WHEEL, MOUSE_EVENT_FLAGS, VIRTUAL_KEY,
    VK_MENU,
};
use windows::Win32::UI::WindowsAndMessaging::{
    BringWindowToTop, EnumWindows, GetForegroundWindow, GetWindowRect, GetWindowTextLengthW,
    GetWindowTextW, GetWindowThreadProcessId, IsIconic, IsWindow, IsWindowVisible, SetCursorPos,
    SetForegroundWindow, ShowWindow, SW_RESTORE,
};

/* ------------------------------ 通信协议 ------------------------------ */

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
struct ScreenshotRequest {
    #[serde(default)]
    display_id: Option<String>,
    #[serde(default)]
    region: Option<Region>,
    #[serde(default)]
    scale: Option<f64>,
    #[serde(default)]
    max_dimension: Option<i64>,
    #[serde(default)]
    max_bytes: Option<i64>,
    /// 指名窗口：先把该窗口提到前台，再按它**聚焦之后**的实际边界截图。
    /// 为什么必须和截图挤在同一次进程调用里，见 `focus_window` 的说明。
    #[serde(default)]
    focus: Option<FocusTarget>,
    /// 显式后台捕获：PrintWindow，不提窗；和 focus / region / displayId 互斥。
    #[serde(default)]
    background: Option<FocusTarget>,
}

/// 「提到前台再截图」的目标窗口。
///
/// 只带身份信息（句柄 + 所属进程 + 标题），**故意不带边界**：
/// 边界是这次调用要**读出来**的结果，不是拿来做校验的输入。
#[derive(Debug, Clone, Deserialize)]
#[serde(rename_all = "camelCase")]
struct FocusTarget {
    /// 原生窗口句柄。
    /// 宿主侧一律以**十进制字符串**传递：HWND 在 64 位 Windows 上是指针宽度，
    /// 走 JS 的 number 会在超过 2^53 时丢精度，所以字符串是这条链路上既有的约定
    /// （`computer_windows` 返回的窗口记录里它同样是字符串）。
    handle: String,
    process_id: i32,
    title: String,
}

#[derive(Debug, Clone, Copy, Deserialize, Serialize)]
struct Region {
    x: i32,
    y: i32,
    width: i32,
    height: i32,
}

#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
struct DisplayInfo {
    id: String,
    name: String,
    primary: bool,
    bounds: Region,
}

#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
struct ScreenshotResponse {
    /// base64 PNG。文件模式下不回这个字段（大块数据走文件，不进 stdout 管道）
    #[serde(skip_serializing_if = "Option::is_none")]
    png: Option<String>,
    width: u32,
    height: u32,
    /// 实际截取的屏幕区域（可能与请求的区域不同：越界部分会被裁到虚拟桌面内）
    source_bounds: Region,
    capture_mode: String,
    #[serde(skip_serializing_if = "Option::is_none")]
    display_id: Option<String>,
}

/// 文件模式下 stdout 回的小 JSON：只给元信息，PNG 在磁盘上
#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
struct OutMeta {
    path: String,
    width: u32,
    height: u32,
    source_bounds: Region,
    capture_mode: String,
    #[serde(skip_serializing_if = "Option::is_none")]
    display_id: Option<String>,
    bytes: u64,
}

fn fail(message: impl std::fmt::Display) -> ExitCode {
    let _ = writeln!(std::io::stderr(), "dsh-screen: {message}");
    ExitCode::from(1)
}

fn write_json<T: Serialize>(value: &T) -> Result<(), String> {
    let text = serde_json::to_string(value).map_err(|e| format!("JSON 序列化失败：{e}"))?;
    let stdout = std::io::stdout();
    let mut lock = stdout.lock();
    lock.write_all(text.as_bytes())
        .map_err(|e| format!("写 stdout 失败：{e}"))?;
    lock.flush()
        .map_err(|e| format!("flush stdout 失败：{e}"))?;
    Ok(())
}

/* ------------------------------ 显示器枚举 ------------------------------ */

/// 显示器条目：设备名 + 该显示器在虚拟桌面里的矩形。
/// 用 `Raw*` 前缀是提醒调用方：这里的 HWND 只在回调期间有效，不可保存。
struct RawDisplay {
    device: String,
    bounds: RECT,
}

/// 把 Win32 里以 NUL 结尾的定长 UTF-16 缓冲转成 String。
fn utf16_z(raw: &[u16]) -> String {
    let end = raw.iter().position(|&unit| unit == 0).unwrap_or(raw.len());
    String::from_utf16_lossy(&raw[..end])
}

unsafe extern "system" fn monitor_enum_proc(
    monitor: HMONITOR,
    _hdc: HDC,
    _clip: *mut RECT,
    data: LPARAM,
) -> BOOL {
    let out = &mut *(data.0 as *mut Vec<RawDisplay>);
    let mut info = MONITORINFOEXW {
        monitorInfo: MONITORINFO {
            cbSize: std::mem::size_of::<MONITORINFOEXW>() as u32,
            ..Default::default()
        },
        ..Default::default()
    };
    if GetMonitorInfoW(monitor, &mut info.monitorInfo).as_bool() {
        out.push(RawDisplay {
            // 用系统给的设备名（`\\.\DISPLAY1`），不再从 HMONITOR 合成 id。
            // 理由：宿主侧 computer_status 走的是另一套枚举（PowerShell），返回的就是设备名。
            // 两边必须说同一种 id —— 早先那版合成 `\\?\DISPLAY<handle>`，
            // 结果就是 display_id 从 computer_status 拿到后传给截图，必然「找不到显示器」。
            device: utf16_z(&info.szDevice),
            bounds: info.monitorInfo.rcMonitor,
        });
    }
    TRUE
}

fn list_displays() -> Result<Vec<DisplayInfo>, String> {
    let mut raw: Vec<RawDisplay> = Vec::new();
    unsafe {
        EnumDisplayMonitors(
            None,
            None,
            // MONITORENUMPROC 是 Option<fn>，所以要包 Some
            Some(monitor_enum_proc),
            LPARAM(&mut raw as *mut _ as isize),
        )
        .ok()
        .map_err(|e| format!("EnumDisplayMonitors 失败：{e}"))?;
    }
    if raw.is_empty() {
        return Err("枚举不到任何显示器".into());
    }
    // 与「虚拟桌面」原点的关系用来判定主显示器：主显示器左上角通常就是原点
    let min_x = raw.iter().map(|d| d.bounds.left).min().unwrap_or(0);
    let min_y = raw.iter().map(|d| d.bounds.top).min().unwrap_or(0);
    Ok(raw
        .into_iter()
        .map(|d| DisplayInfo {
            name: d.device.clone(),
            id: d.device,
            primary: d.bounds.left == min_x && d.bounds.top == min_y,
            bounds: Region {
                x: d.bounds.left,
                y: d.bounds.top,
                width: d.bounds.right - d.bounds.left,
                height: d.bounds.bottom - d.bounds.top,
            },
        })
        .collect())
}

fn union_of(displays: &[DisplayInfo]) -> Result<Region, String> {
    let left = displays
        .iter()
        .map(|d| d.bounds.x)
        .min()
        .ok_or("没有显示器")?;
    let top = displays
        .iter()
        .map(|d| d.bounds.y)
        .min()
        .ok_or("没有显示器")?;
    let right = displays
        .iter()
        .map(|d| d.bounds.x + d.bounds.width)
        .max()
        .ok_or("没有显示器")?;
    let bottom = displays
        .iter()
        .map(|d| d.bounds.y + d.bounds.height)
        .max()
        .ok_or("没有显示器")?;
    Ok(Region {
        x: left,
        y: top,
        width: right - left,
        height: bottom - top,
    })
}

/// 按设备 id 找显示器；顺带回传它的矩形，用于「指定显示器整屏截图」
fn find_display(id: &str) -> Result<DisplayInfo, String> {
    let displays = list_displays()?;
    displays
        .into_iter()
        .find(|d| d.id == id)
        .ok_or_else(|| format!("找不到显示器 '{id}'"))
}

/// 决定这次要操作哪块屏幕：给了 region 就用它（虚拟桌面坐标，允许负值：副屏可能在原点左侧）；
/// 否则给了 display_id 就用那块屏的整屏；两者都没有则返回 `None`，由调用方填整个虚拟桌面。
///
/// 抽出来是因为截图与找图（find-image）走的是同一套决策 —— 两处各写一遍迟早会走偏，
/// 而「找图找错屏」这种错误在结果里看不出来（它会认真地给你另一个屏幕上的坐标）。
fn resolve_region(
    region: Option<&Region>,
    display_id: Option<&str>,
) -> Result<(Option<Region>, Option<String>), String> {
    match (region, display_id) {
        (Some(r), _) => Ok((Some(*r), None)),
        (None, Some(id)) => {
            let display = find_display(id)?;
            Ok((Some(display.bounds), Some(display.id)))
        }
        (None, None) => Ok((None, None)),
    }
}

/// 把请求的区域裁到虚拟桌面以内。
///
/// 越界部分直接 BitBlt 只会得到黑边，那不是「屏幕内容」；所以裁掉，并把**实际**区域回报出去
/// （宿主依赖这个回报做坐标换算）。截图与找图共用同一条规则 —— 找图如果少了这一步，
/// 越界时匹配会在黑边上进行，然后给出一个看起来很正常、但根本不在屏幕里的坐标。
fn clip_to_virtual(requested: Region, virtual_rect: Region) -> Result<Region, String> {
    let left = requested.x.max(virtual_rect.x);
    let top = requested.y.max(virtual_rect.y);
    let right = (requested.x + requested.width).min(virtual_rect.x + virtual_rect.width);
    let bottom = (requested.y + requested.height).min(virtual_rect.y + virtual_rect.height);
    if right <= left || bottom <= top {
        return Err(format!(
            "请求的区域完全落在虚拟桌面之外（虚拟桌面 {}x{} @ ({}, {})）",
            virtual_rect.width, virtual_rect.height, virtual_rect.x, virtual_rect.y
        ));
    }
    Ok(Region {
        x: left,
        y: top,
        width: right - left,
        height: bottom - top,
    })
}

/* ------------------------------ 找图（模板匹配） ------------------------------ */

/// 找图请求：拿一张模板图，看它出现在屏幕（或指定区域）的什么位置。
///
/// 模板走 base64 PNG，是因为宿主本来就在传 PNG —— 截图接口吐出来的就是它，
/// 直接拿来当模板，中间不需要任何格式转换。
#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
struct FindImageRequest {
    /// base64 PNG 的模板图。
    template_png: String,
    #[serde(default)]
    region: Option<Region>,
    #[serde(default)]
    display_id: Option<String>,
    /// 容差内参与像素比例的下限（默认 0.9）。点击还必须有完整覆盖与唯一聚类。
    #[serde(default)]
    threshold: Option<f64>,
    /// 每个所选颜色通道允许的偏差（整数 0-255，默认 12）。
    #[serde(default)]
    tolerance: Option<u8>,
    /// 默认沿用整数灰度亮度；RGB 模式要求三个通道都满足容差。
    #[serde(default)]
    color_mode: image_template::ColorMode,
    /// alpha 模式按 alphaMin 包含像素；none 模式完全忽略透明度。
    #[serde(default)]
    mask_mode: image_template::MaskMode,
    #[serde(default)]
    alpha_min: Option<u8>,
    /// 单个显式模板比例，最近邻插值，不做多尺度候选搜索。
    #[serde(default)]
    template_scale: Option<f64>,
    /// 从解码开始的匹配预算；阻塞的系统抓屏另受宿主进程截止保护。
    #[serde(default)]
    budget_ms: Option<u64>,
    /// 最多判定多少个合法模板左上角，耗尽时明确返回部分覆盖。
    #[serde(default)]
    max_positions: Option<u64>,
    /// 指名窗口：先把它提到前台，再按它**聚焦之后**的实际边界搜索。
    /// 与截图同一条理由 —— 聚焦与抓屏必须挤在同一次进程调用里，
    /// 否则第二次 spawn 冒出来的控制台窗口会盖住刚聚焦好的目标。
    #[serde(default)]
    focus: Option<FocusTarget>,
}

/// 一处匹配：它的屏幕坐标与相似度。
#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
struct MatchSpot {
    x: i32,
    y: i32,
    score: f64,
}

#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
struct FindImageResponse {
    /// 只说明已知有匹配；部分覆盖时不能据此判断唯一或缺席。
    found: bool,
    status: &'static str,
    coverage: &'static str,
    visited_positions: u64,
    total_positions: u64,
    #[serde(skip_serializing_if = "Option::is_none")]
    stop_reason: Option<&'static str>,
    cluster_rule: &'static str,
    /// 模板左上角在**虚拟桌面坐标**里的位置。没有已知匹配时省略。
    #[serde(skip_serializing_if = "Option::is_none")]
    x: Option<i32>,
    #[serde(skip_serializing_if = "Option::is_none")]
    y: Option<i32>,
    /// 最佳得分（0..1，1 = 完全一致）。找不到时是 0。
    score: f64,
    /// 远离最佳的次佳得分（也就是第二处的分数）。**屏幕上没有第二处像的地方时省略**。
    #[serde(skip_serializing_if = "Option::is_none")]
    runner_up: Option<f64>,
    /// 固定首匹配锚点、半模板矩形聚类的数量；部分覆盖时只是完整数量的下界。
    /// 聚类表达视觉位置，不证明业务对象身份。
    match_count: usize,
    /// 各处的位置与分数（按分数降序，最多 `image_match::DISPLAY_LIMIT` 个）。
    /// 不止一处时调用方需要知道**是哪些地方**像，才能自己决定下一步。
    matches: Vec<MatchSpot>,
    searched: Region,
    /// 点击与覆盖计数使用变换后的尺寸。
    template_width: u32,
    template_height: u32,
    source_template_width: u32,
    source_template_height: u32,
    color_mode: image_template::ColorMode,
    mask_mode: image_template::MaskMode,
    alpha_min: u8,
    template_scale: f64,
    resize_filter: &'static str,
    active_pixel_count: usize,
    /// 抓屏没有降采样，始终为 1；与显式 templateScale 是两个不同的量。
    scale: u32,
    elapsed_ms: u64,
}

/* ------------------------------ 输入注入与窗口 ------------------------------ */

/// `action` 命令的请求：一个动作 + 可选的目标窗口。
///
/// 与截图同一套聚焦逻辑：键盘注入只落得到前台窗口，而"提窗 + 注入"必须在**同一次**
/// 进程调用里完成 —— 分两次时第二次 spawn 冒出来的控制台窗口会抢走前台，
/// 按键就落到那个控制台去了（实测踩过）。
#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
struct ActionRequest {
    #[serde(default)]
    focus: Option<FocusTarget>,
    action: ActionSpec,
}

/// 六种桌面动作。变体名与字段名都按 camelCase 反序列化，
/// 与 JS 侧 `actionPayload` 构造的 payload 一一对应。
#[derive(Debug, Deserialize)]
#[serde(tag = "kind", rename_all = "camelCase")]
enum ActionSpec {
    #[serde(rename_all = "camelCase")]
    Sequence {
        steps: Vec<input_sequence::Step>,
        #[serde(default)]
        delay_ms: i64,
    },
    #[serde(rename_all = "camelCase")]
    Move {
        x: i32,
        y: i32,
        #[serde(default)]
        delay_ms: i64,
    },
    #[serde(rename_all = "camelCase")]
    Click {
        x: i32,
        y: i32,
        button: String,
        click_count: i32,
        #[serde(default)]
        delay_ms: i64,
    },
    #[serde(rename_all = "camelCase")]
    Drag {
        from_x: i32,
        from_y: i32,
        to_x: i32,
        to_y: i32,
        duration_ms: i32,
        #[serde(default)]
        delay_ms: i64,
    },
    #[serde(rename_all = "camelCase")]
    Scroll {
        x: i32,
        y: i32,
        delta_x: i32,
        delta_y: i32,
        #[serde(default)]
        delay_ms: i64,
    },
    #[serde(rename_all = "camelCase")]
    Type {
        text: String,
        #[serde(default)]
        delay_ms: i64,
    },
    #[serde(rename_all = "camelCase")]
    Key {
        key: i32,
        modifiers: Vec<i32>,
        #[serde(default)]
        delay_ms: i64,
    },
}

/// 一个可见的顶层窗口。字段与 JS 侧 `listWindows` 的期望一致。
#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
struct WindowRecord {
    /// 窗口句柄的十进制字符串 —— JS 侧按字符串传递，避免在 32 位平台上丢精度。
    id: String,
    title: String,
    process_id: u32,
    /// 类名和 UI 线程帮助审查新菜单/弹窗，线程相关性不等于 owner 关系。
    class_name: String,
    thread_id: u32,
    owner_id: Option<String>,
    owner_chain: Vec<String>,
    /// 进程名（不含 `.exe`）。取不到时是空串，与旧实现的行为一致。
    application: String,
    /// 是不是当前前台窗口。
    focused: bool,
    /// 保留最小化窗口，才能通过新列表恢复它；边界不是当前可点击区域。
    minimized: bool,
    bounds: Region,
}

/// `focus-window` 命令的请求。
///
/// 只带身份（句柄 / 进程 / 标题），**不带列出时刻的旧边界** —— 窗口被移动过
/// 并不代表换了一个窗口，而拿旧边界去校验会让一次本该成功的聚焦直接失败。
#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
struct FocusRequest {
    id: String,
    process_id: i32,
    title: String,
}

/// `action` / `focus-window` 这类"做完了"的命令的回执。
/// 宿主侧只检查调用有没有失败，但 stdout 必须是合法 JSON —— 否则 runJson 解析会报错。
#[derive(Debug, Serialize)]
struct ActionOutcome {
    ok: bool,
}

/// 从 stdin 读一个 base64(UTF8 JSON) 请求体 —— 与截图那条命令同一套协议。
fn read_body<T: for<'de> Deserialize<'de>>() -> Result<T, String> {
    let mut raw = String::new();
    std::io::stdin()
        .read_to_string(&mut raw)
        .map_err(|e| format!("读 stdin 失败：{e}"))?;
    let bytes = base64::engine::general_purpose::STANDARD
        .decode(raw.trim())
        .map_err(|e| format!("stdin base64 解码失败：{e}"))?;
    let text = String::from_utf8(bytes).map_err(|e| format!("stdin 不是合法 UTF-8：{e}"))?;
    serde_json::from_str(&text).map_err(|e| format!("请求 JSON 解析失败：{e}"))
}

/// 所选颜色通道的容差与有界扫描的默认预算。
const DEFAULT_TOLERANCE: u8 = 12;
const DEFAULT_FIND_BUDGET_MS: u64 = 5_000;
const DEFAULT_MAX_POSITIONS: u64 = 20_000_000;

/// 单/三通道静态分派，覆盖、预算、聚类与评分逻辑都在 scan_pixels 中共用。
fn scan_colors<const CHANNELS: usize>(
    pixels: &[u8],
    crop: Region,
    template: &image_template::Prepared,
    tolerance: u8,
    threshold: f64,
    max_positions: u64,
    expired: impl FnMut() -> bool,
) -> Result<image_match::ScanResult, String> {
    let screen_colors = image_template::colors::<CHANNELS>(pixels);
    let template_colors = image_template::colors::<CHANNELS>(template.image.as_raw());
    image_match::scan_pixels(
        image_match::PixelImage {
            pixels: &screen_colors,
            width: crop.width as u32,
            height: crop.height as u32,
        },
        image_match::PixelImage {
            pixels: &template_colors,
            width: template.image.width(),
            height: template.image.height(),
        },
        template.mask.as_deref(),
        tolerance,
        threshold,
        image_match::Limits {
            max_positions,
            max_clusters: image_match::MAX_CLUSTERS,
        },
        expired,
    )
}

fn find_image(request: &FindImageRequest) -> Result<FindImageResponse, String> {
    let started = std::time::Instant::now();
    let budget_ms = request.budget_ms.unwrap_or(DEFAULT_FIND_BUDGET_MS);
    let max_positions = request.max_positions.unwrap_or(DEFAULT_MAX_POSITIONS);
    let threshold = request.threshold.unwrap_or(0.9);
    if !(1..=120_000).contains(&budget_ms) || !(1..=100_000_000).contains(&max_positions) {
        return Err("budgetMs 必须是 1..120000，maxPositions 必须是 1..100000000".into());
    }
    if !threshold.is_finite() || threshold <= 0.0 || threshold > 1.0 {
        return Err("threshold 必须在 (0, 1] 内".into());
    }
    let template_options = image_template::Options {
        color_mode: request.color_mode,
        mask_mode: request.mask_mode,
        alpha_min: request.alpha_min.unwrap_or(1),
        template_scale: request.template_scale.unwrap_or(1.0),
    };
    template_options.validate()?;
    let budget = std::time::Duration::from_millis(budget_ms);
    // DPI 感知必须在任何坐标查询之前设置，理由同 capture：否则缩放屏上的坐标会整体偏一圈。
    unsafe {
        let _ = SetProcessDpiAwareness(PROCESS_PER_MONITOR_DPI_AWARE);
    }

    let png = base64::engine::general_purpose::STANDARD
        .decode(request.template_png.trim())
        .map_err(|e| format!("模板 base64 解码失败：{e}"))?;
    let template_image = image::load_from_memory_with_format(&png, image::ImageFormat::Png)
        .map_err(|e| format!("模板 PNG 解码失败：{e}"))?
        .to_rgba8();
    let template = image_template::prepare(template_image, template_options)?;
    let (template_w, template_h) = template.image.dimensions();

    let displays = list_displays()?;
    let virtual_rect = union_of(&displays)?;
    // 指名窗口时边界以**聚焦之后**读到的为准（同 capture 的理由：窗口被移动过并不代表
    // 换了一个窗口，边界本来就该是这里读出来的结果）。focus_window 内部已校验它确实到了前台，
    // 抢不到前台会直接报错 —— 否则匹配会在遮挡物上进行，再给出一个"看起来很自信"的坐标。
    let focused_bounds = match request.focus.as_ref() {
        Some(target) => Some(focus_window(target)?),
        None => None,
    };
    let (requested, _display_id) = resolve_region(
        request.region.as_ref().or(focused_bounds.as_ref()),
        request.display_id.as_deref(),
    )?;
    let crop = clip_to_virtual(requested.unwrap_or(virtual_rect), virtual_rect)?;

    let pixels = grab_screen(crop)?;
    let tolerance = request.tolerance.unwrap_or(DEFAULT_TOLERANCE);
    let expired = || started.elapsed() >= budget;
    let scan = match request.color_mode {
        image_template::ColorMode::Gray => scan_colors::<1>(
            &pixels,
            crop,
            &template,
            tolerance,
            threshold,
            max_positions,
            expired,
        ),
        image_template::ColorMode::Rgb => scan_colors::<3>(
            &pixels,
            crop,
            &template,
            tolerance,
            threshold,
            max_positions,
            expired,
        ),
    }?;
    let complete = scan.stop_reason.is_none();
    let best = scan.matches.first();
    Ok(FindImageResponse {
        found: scan.match_count > 0,
        status: if !complete {
            "incomplete"
        } else if best.is_some() {
            "found"
        } else {
            "not_found"
        },
        coverage: if complete { "complete" } else { "partial" },
        visited_positions: scan.visited_positions,
        total_positions: scan.total_positions,
        stop_reason: scan.stop_reason,
        cluster_rule: "row_major_fixed_anchor_half_template",
        x: best.map(|spot| crop.x + spot.x as i32),
        y: best.map(|spot| crop.y + spot.y as i32),
        score: best.map_or(0.0, |spot| spot.score),
        runner_up: scan.matches.get(1).map(|spot| spot.score),
        match_count: scan.match_count,
        matches: scan
            .matches
            .iter()
            .map(|spot| MatchSpot {
                x: crop.x + spot.x as i32,
                y: crop.y + spot.y as i32,
                score: spot.score,
            })
            .collect(),
        searched: crop,
        template_width: template_w,
        template_height: template_h,
        source_template_width: template.source_width,
        source_template_height: template.source_height,
        color_mode: template_options.color_mode,
        mask_mode: template_options.mask_mode,
        alpha_min: template_options.alpha_min,
        template_scale: template_options.template_scale,
        resize_filter: "nearest",
        active_pixel_count: template.active_pixels,
        scale: 1,
        elapsed_ms: started.elapsed().as_millis() as u64,
    })
}

/* ------------------------------ 屏幕捕获 ------------------------------ */

/// 阶段打点：只在设了 DSH_SCREEN_DEBUG 时输出到 stderr。
/// 这个 helper 出过一次「screenshot 挂死」，就是靠这些打点定位到具体阶段的，
/// 所以保留下来当常驻排查手段（默认静默，不影响正常使用）。
fn trace(label: &str) {
    if std::env::var_os("DSH_SCREEN_DEBUG").is_some() {
        let _ = writeln!(std::io::stderr(), "[dsh-screen] {label}");
    }
}

/* ------------------------------ 窗口聚焦 ------------------------------ */

/// 发一个孤立的 Alt 按下/抬起，用来解开 Windows 的前台锁。
///
/// 系统只允许「当前前台进程」或「刚收到过用户输入事件的进程」改变前台窗口。
/// 这一下假按键不产生任何字符、不改变任何状态，但足以让系统把我们算作"刚收到输入"。
/// 代价：如果恰好在某个程序里按着 Alt，可能会触发它的菜单 —— 因此只在提窗失败后才发。
fn unlock_foreground() {
    unsafe {
        keybd_event(VK_MENU.0 as u8, 0, KEYBD_EVENT_FLAGS(0), 0);
        keybd_event(VK_MENU.0 as u8, 0, KEYEVENTF_KEYUP, 0);
    }
}

/// 目标窗口是不是**当前的前台窗口**？
///
/// 判据只能是前台，**不能放宽成「Z-order 最上层也算」** —— 试过，反而更错：
/// `GetWindow(handle, GW_HWNDPREV)` 对 QQ 这类窗口永远非空（它上面总有别的窗口），
/// 于是补救路径明明成功了、判据仍然为假（实测踩过：窗口就在眼前，却一路报「未能提到前台」）。
/// 而且这里要回答的是「随后注入的按键/点击会落到谁身上」，那答案本来就是前台窗口。
fn is_on_top(handle: HWND) -> bool {
    unsafe { GetForegroundWindow() == handle }
}

/// 把窗口提到前台，并返回它**聚焦之后**的实际边界。
///
/// 只校验身份（句柄有效 + 属于该进程 + 标题一致），**不比对调用方手里的旧边界**：
/// 窗口在这中间被移动过并不代表换了一个窗口，而边界本来就该是这里「读出来的结果」。
///
/// 为什么这件事必须和截图挤在**同一次进程调用**里：
/// 宿主每 spawn 一次子进程，Windows 就可能把宿主所在的控制台窗口提到前台
/// （dsh-subprocess-local 的 Windows runner 启动路径没有 windowsHide）。
/// 若「聚焦」和「截图」分成两次调用，第二次启动时冒出来的控制台窗口
/// 会正好盖在刚被提到前面的目标上，截回来的就是那个控制台。
/// 合成一次之后，弹窗只发生在进程启动那一刻，紧接着目标被提到前台把它盖住，
/// 再抓屏拿到的就是目标本身。
fn focus_window(target: &FocusTarget) -> Result<Region, String> {
    unsafe {
        let handle_value: i64 = target
            .handle
            .parse()
            .map_err(|_| format!("窗口句柄不是合法的十进制整数：{}", target.handle))?;
        let handle = HWND(handle_value as *mut core::ffi::c_void);
        if !matches_window(handle, target) {
            return Err("目标窗口已不存在或身份不符（句柄 / 进程 / 标题）".into());
        }

        // 只恢复最小化窗口。已在使用的窗口不能每个按键前都 Restore，避免改变控件焦点/选择。
        if IsIconic(handle).as_bool() {
            let _ = ShowWindow(handle, SW_RESTORE);
        }
        // 判据只能是「目标现在是不是前台」，**不能**拿 SetForegroundWindow 的返回值当成败依据：
        // 窗口已经在前台时，系统认为没什么可做的，它会返回 false —— 而窗口状态完全正确。
        // 那样会把「本来就对」误判成失败，再跑去走补救路径、白折腾一场，
        // 最后报出「未能提到前台」而目标其实一直在前台（实测踩过，QQ 窗口）。
        if !is_on_top(handle) {
            let _ = SetForegroundWindow(handle);
        }
        // 前台锁只认「当前前台进程」或「**刚收到过用户输入事件**的进程」。一个孤立的
        // Alt 按下/抬起（不产生字符、不改变任何状态）会让系统认为我们刚收到输入，
        // 从而解开这把锁 —— 这是窗口自动化里通行的做法，微软 SetForegroundWindow 的
        // 文档也把「刚收到用户输入」列为允许改前台的情形。**只在首次失败后发一次**。
        if !is_on_top(handle) {
            unlock_foreground();
            let _ = SetForegroundWindow(handle);
        }
        if !is_on_top(handle) {
            // Windows 的前台锁会拒绝合法请求：临时把本线程接入前台线程与目标线程的
            // 输入队列，再试一次（与宿主侧 PowerShell 实现同样的手法）。
            let current = GetCurrentThreadId();
            let foreground = GetForegroundWindow();
            let foreground_thread = if foreground.0.is_null() {
                0
            } else {
                GetWindowThreadProcessId(foreground, None)
            };
            let target_thread = GetWindowThreadProcessId(handle, None);

            let mut attached_foreground = false;
            let mut attached_target = false;
            if foreground_thread != 0 && foreground_thread != current {
                attached_foreground = AttachThreadInput(current, foreground_thread, TRUE).as_bool();
            }
            if target_thread != 0 && target_thread != current && target_thread != foreground_thread
            {
                attached_target = AttachThreadInput(current, target_thread, TRUE).as_bool();
            }

            let _ = BringWindowToTop(handle);
            let _ = SetForegroundWindow(handle);
            let _ = SetFocus(handle);

            if attached_target {
                let _ = AttachThreadInput(current, target_thread, FALSE);
            }
            if attached_foreground {
                let _ = AttachThreadInput(current, foreground_thread, FALSE);
            }
        }

        if !is_on_top(handle) {
            return Err("未能把目标窗口提到前台".into());
        }
        if !matches_window(handle, target) {
            return Err("目标窗口在聚焦过程中发生了变化".into());
        }

        let mut rect = RECT::default();
        GetWindowRect(handle, &mut rect).map_err(|e| format!("读取窗口边界失败：{e}"))?;
        let bounds = Region {
            x: rect.left,
            y: rect.top,
            width: rect.right - rect.left,
            height: rect.bottom - rect.top,
        };
        if bounds.width < 1 || bounds.height < 1 {
            return Err("目标窗口的边界为空".into());
        }

        // 刚被提到前台的窗口要等 DWM 合成一帧才会体现在屏幕像素里，
        // 立刻抓屏有可能抓到它「还没画上去」的位置。
        std::thread::sleep(std::time::Duration::from_millis(120));
        Ok(bounds)
    }
}

/// 身份校验：句柄有效、可见、属于指定进程、标题一致。最小化状态由调用方决定是否恢复。
fn matches_window(handle: HWND, target: &FocusTarget) -> bool {
    unsafe {
        if !IsWindow(handle).as_bool() || !IsWindowVisible(handle).as_bool() {
            return false;
        }
        let mut process_id: u32 = 0;
        if GetWindowThreadProcessId(handle, Some(&mut process_id)) == 0 {
            return false;
        }
        if process_id != target.process_id as u32 {
            return false;
        }
        let length = GetWindowTextLengthW(handle);
        if length < 1 {
            return target.title.is_empty();
        }
        let mut buffer = vec![0u16; (length + 1) as usize];
        let written = GetWindowTextW(handle, &mut buffer);
        if written < 1 {
            return target.title.is_empty();
        }
        String::from_utf16_lossy(&buffer[..written as usize]) == target.title
    }
}

/* ------------------------------ 桌面动作 ------------------------------ */

/// `delayMs`：动作**之后**的等待，给界面留出反应时间。
fn sleep_ms(milliseconds: i64) {
    if milliseconds > 0 {
        std::thread::sleep(std::time::Duration::from_millis(milliseconds as u64));
    }
}

/// 虚拟键码：宿主侧已经把按键名映射成码，这里只守住取值范围。
fn virtual_key(code: i32) -> Result<VIRTUAL_KEY, String> {
    if !(1..=0xFE).contains(&code) {
        return Err(format!("虚拟键码超出范围：{code}"));
    }
    Ok(VIRTUAL_KEY(code as u16))
}

/// 鼠标键名 →（按下标志, 抬起标志）。
fn mouse_flags(button: &str) -> Result<(MOUSE_EVENT_FLAGS, MOUSE_EVENT_FLAGS), String> {
    match button {
        "left" => Ok((MOUSEEVENTF_LEFTDOWN, MOUSEEVENTF_LEFTUP)),
        "right" => Ok((MOUSEEVENTF_RIGHTDOWN, MOUSEEVENTF_RIGHTUP)),
        "middle" => Ok((MOUSEEVENTF_MIDDLEDOWN, MOUSEEVENTF_MIDDLEUP)),
        other => Err(format!("不支持的鼠标键 '{other}'")),
    }
}

/// 指针移到虚拟桌面坐标（多屏时允许负值）。
fn pointer_move(x: i32, y: i32) -> Result<(), String> {
    unsafe { SetCursorPos(x, y) }.map_err(|e| format!("SetCursorPos({x}, {y}) 失败：{e}"))
}

/// 点击：先把指针移到位，再按 `click_count` 次按下 / 抬起。
fn click_at(x: i32, y: i32, button: &str, click_count: i32) -> Result<(), String> {
    let (down, up) = mouse_flags(button)?;
    pointer_move(x, y)?;
    unsafe {
        for _ in 0..click_count.max(0) {
            mouse_event(down, 0, 0, 0, 0);
            mouse_event(up, 0, 0, 0, 0);
        }
    }
    Ok(())
}

/// 拖拽：按下左键，在 `duration_ms` 内**分步**插值移动到目标，最后一定抬起左键。
///
/// 分步而不是瞬移：画布类程序只认中间的移动轨迹。步数上限 120、时长上限 10 秒。
/// **无论中途出什么错，左键都必须抬起来** —— 否则整个桌面会一直处于"按住"状态。
fn drag(from_x: i32, from_y: i32, to_x: i32, to_y: i32, duration_ms: i32) -> Result<(), String> {
    pointer_move(from_x, from_y)?;
    unsafe { mouse_event(MOUSEEVENTF_LEFTDOWN, 0, 0, 0, 0) };
    let result = (|| -> Result<(), String> {
        let duration = duration_ms.clamp(0, 10_000);
        let steps = ((f64::from(duration) / 16.0).ceil() as i32).clamp(1, 120);
        let step_delay = duration / steps;
        for index in 1..=steps {
            let fraction = f64::from(index) / f64::from(steps);
            let x = (f64::from(from_x) + f64::from(to_x - from_x) * fraction).round() as i32;
            let y = (f64::from(from_y) + f64::from(to_y - from_y) * fraction).round() as i32;
            if step_delay > 0 {
                std::thread::sleep(std::time::Duration::from_millis(step_delay as u64));
            }
            unsafe { SetCursorPos(x, y) }
                .map_err(|e| format!("拖拽中 SetCursorPos({x}, {y}) 失败：{e}"))?;
        }
        Ok(())
    })();
    unsafe { mouse_event(MOUSEEVENTF_LEFTUP, 0, 0, 0, 0) };
    result
}

/// 滚轮：指针先移到位，再分别投递纵向 / 横向滚动。
/// `delta` 单位是 WHEEL_DELTA（120 = 一格），与宿主侧一致。
fn scroll_at(x: i32, y: i32, delta_x: i32, delta_y: i32) -> Result<(), String> {
    pointer_move(x, y)?;
    unsafe {
        if delta_y != 0 {
            mouse_event(MOUSEEVENTF_WHEEL, 0, 0, delta_y, 0);
        }
        if delta_x != 0 {
            mouse_event(MOUSEEVENTF_HWHEEL, 0, 0, delta_x, 0);
        }
    }
    Ok(())
}

/// 一个键盘输入事件（按下或抬起）。
fn key_input(scan: u16, flags: KEYBD_EVENT_FLAGS) -> INPUT {
    INPUT {
        r#type: INPUT_KEYBOARD,
        Anonymous: INPUT_0 {
            ki: KEYBDINPUT {
                wVk: VIRTUAL_KEY(0),
                wScan: scan,
                dwFlags: flags,
                time: 0,
                dwExtraInfo: 0,
            },
        },
    }
}

/// 用 `KEYEVENTF_UNICODE` 投递文本：不经过键盘布局，中文与符号都能原样送达。
///
/// **所有字符拼成一次 `SendInput`**：逐字符调用会给别的输入留下插进字符之间的机会。
/// 投递数量对不上就报错，不静默吞掉。
fn type_text(text: &str) -> Result<(), String> {
    let mut inputs: Vec<INPUT> = Vec::new();
    for character in text.chars() {
        // 增补平面字符编码成一对代理，两个 UTF-16 单元都要发。
        let mut buffer = [0u16; 2];
        for unit in character.encode_utf16(&mut buffer).iter() {
            inputs.push(key_input(*unit, KEYEVENTF_UNICODE));
            inputs.push(key_input(
                *unit,
                KEYBD_EVENT_FLAGS(KEYEVENTF_UNICODE.0 | KEYEVENTF_KEYUP.0),
            ));
        }
    }
    if inputs.is_empty() {
        return Ok(());
    }
    let expected = inputs.len();
    let sent = unsafe { SendInput(&inputs, std::mem::size_of::<INPUT>() as i32) };
    if sent as usize != expected {
        return Err(format!("SendInput 只投递了 {sent} / {expected} 个键盘事件"));
    }
    Ok(())
}

/// 按一下键，前后夹住修饰键。修饰键**逆序**抬起，且无论主键那步成不成功都要抬 ——
/// 否则会留下一个卡住的 Ctrl。
fn tap_key(key: i32, modifiers: &[i32]) -> Result<(), String> {
    input_sequence::tap(key, modifiers)
}

/// 执行一个动作，六种分支都把 `delay_ms` 放在动作之后等待。
fn perform_action(spec: &ActionSpec) -> Result<(), String> {
    match spec {
        ActionSpec::Sequence { steps, delay_ms } => {
            input_sequence::execute(steps, || Ok(()))?;
            sleep_ms(*delay_ms);
        }
        ActionSpec::Move { x, y, delay_ms } => {
            pointer_move(*x, *y)?;
            sleep_ms(*delay_ms);
        }
        ActionSpec::Click {
            x,
            y,
            button,
            click_count,
            delay_ms,
        } => {
            click_at(*x, *y, button, *click_count)?;
            sleep_ms(*delay_ms);
        }
        ActionSpec::Drag {
            from_x,
            from_y,
            to_x,
            to_y,
            duration_ms,
            delay_ms,
        } => {
            drag(*from_x, *from_y, *to_x, *to_y, *duration_ms)?;
            sleep_ms(*delay_ms);
        }
        ActionSpec::Scroll {
            x,
            y,
            delta_x,
            delta_y,
            delay_ms,
        } => {
            scroll_at(*x, *y, *delta_x, *delta_y)?;
            sleep_ms(*delay_ms);
        }
        ActionSpec::Type { text, delay_ms } => {
            type_text(text)?;
            sleep_ms(*delay_ms);
        }
        ActionSpec::Key {
            key,
            modifiers,
            delay_ms,
        } => {
            tap_key(*key, modifiers)?;
            sleep_ms(*delay_ms);
        }
    }
    Ok(())
}

/// `action` 命令：给了 focus 就先按身份提窗，再执行动作。
///
/// 提窗与注入挤在同一次进程调用里 —— 分两次时，第二次 spawn 冒出来的控制台窗口
/// 会抢走前台，按键就落到控制台去了（实测踩过）。
fn run_action(request: &ActionRequest) -> Result<(), String> {
    // 在提窗之前验证整条序列，后半段的参数错误也不能造成前半段副作用。
    if let ActionSpec::Sequence { steps, delay_ms } = &request.action {
        input_sequence::validate(steps)?;
        if !(0..=10_000).contains(delay_ms) {
            return Err("动作后等待必须 0..10000ms".into());
        }
    }
    if let Some(target) = request.focus.as_ref() {
        focus_window(target)?;
    }
    if let ActionSpec::Sequence { steps, delay_ms } = &request.action {
        input_sequence::execute(steps, || {
            if let Some(target) = request.focus.as_ref() {
                let handle = window_control::checked_window(target)?;
                if !is_on_top(handle) {
                    return Err("输入序列中目标失去前台，已停止并释放输入".into());
                }
            }
            Ok(())
        })?;
        sleep_ms(*delay_ms);
        return Ok(());
    }
    perform_action(&request.action)
}

/* ------------------------------ 窗口枚举 ------------------------------ */

/// 读窗口标题；取不到就是空串，调用方按"没有标题"处理。
fn window_title(handle: HWND) -> String {
    unsafe {
        let length = GetWindowTextLengthW(handle);
        if length < 1 {
            return String::new();
        }
        let mut buffer = vec![0u16; length as usize + 1];
        let written = GetWindowTextW(handle, &mut buffer);
        if written < 1 {
            return String::new();
        }
        utf16_z(&buffer[..written as usize])
    }
}

/// 进程名（不含扩展名）。取不到就返回空串：这只是给模型看的提示信息，
/// 不值得为它让整次枚举失败。
fn process_name(process_id: u32) -> String {
    unsafe {
        let Ok(handle) = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, FALSE, process_id) else {
            return String::new();
        };
        let mut buffer = [0u16; 512];
        let mut size = buffer.len() as u32;
        let queried = QueryFullProcessImageNameW(
            handle,
            PROCESS_NAME_WIN32,
            PWSTR(buffer.as_mut_ptr()),
            &mut size,
        );
        let _ = CloseHandle(handle);
        if queried.is_err() {
            return String::new();
        }
        // 只留文件名并去掉 .exe，与 .NET 的 Process.ProcessName 语义一致。
        Path::new(&utf16_z(&buffer[..size as usize]))
            .file_stem()
            .map(|stem| stem.to_string_lossy().into_owned())
            .unwrap_or_default()
    }
}

/// `EnumWindows` 的回调。回调不能捕获环境，待填的列表通过 `LPARAM` 递进来。
///
/// 保留可见、有面积的无标题窗口：标准菜单与 WPF Popup 的标题本来就可为空。
/// 普通目录保留原先跳过消失项的行为；related-windows 对观测失败显式报错。
unsafe extern "system" fn collect_visible_window(handle: HWND, parameter: LPARAM) -> BOOL {
    let records = &mut *(parameter.0 as *mut Vec<WindowRecord>);
    if let Ok(Some(record)) = window_query::observe(handle) {
        records.push(record);
    }
    TRUE
}

/// 枚举可见的顶层窗口，并标出哪一个是当前前台窗口。
fn list_windows() -> Result<Vec<WindowRecord>, String> {
    unsafe {
        let mut records: Vec<WindowRecord> = Vec::new();
        EnumWindows(
            Some(collect_visible_window),
            LPARAM(&mut records as *mut Vec<WindowRecord> as isize),
        )
        .map_err(|e| format!("EnumWindows 失败：{e}"))?;
        let foreground = GetForegroundWindow().0 as isize;
        for record in records.iter_mut() {
            record.focused = record.id == foreground.to_string();
        }
        Ok(records)
    }
}

/// `focus-window` 命令：把窗口提到前台。
/// 复用截图那条路径的同一个 `focus_window` —— 一处实现，不会出现"改了这份忘了那份"。
fn focus_by_request(request: &FocusRequest) -> Result<(), String> {
    focus_window(&FocusTarget {
        handle: request.id.clone(),
        process_id: request.process_id,
        title: request.title.clone(),
    })?;
    Ok(())
}

fn capture(request: &ScreenshotRequest) -> Result<ScreenshotResponse, String> {
    // DPI 感知必须在任何坐标查询之前设置：
    // 否则在缩放显示器（125%/150%）上，系统回报的是「逻辑像素」，
    // 会导致截到的区域比请求的小一圈 —— 这类偏差在截图上看不出来，但坐标会错。
    trace("1 设置 DPI 感知");
    unsafe {
        // 用 PER_MONITOR 而不是 SYSTEM：多屏不同缩放率时，前者按显示器各自换算，
        // 后者只按主屏算，副屏坐标会偏。返回 Err 说明感知已被设置过，属正常，忽略即可。
        let _ = SetProcessDpiAwareness(PROCESS_PER_MONITOR_DPI_AWARE);
    }

    trace("2 枚举显示器");
    let displays = list_displays()?;
    let virtual_rect = union_of(&displays)?;
    trace(&format!(
        "  虚拟桌面 {}x{} @ ({}, {})，共 {} 块屏",
        virtual_rect.width,
        virtual_rect.height,
        virtual_rect.x,
        virtual_rect.y,
        displays.len()
    ));

    let (crop, pixels, display_id, capture_mode) = if let Some(target) = request.background.as_ref()
    {
        if request.focus.is_some() || request.region.is_some() || request.display_id.is_some() {
            return Err("background 只能单独指定窗口，不能与 focus/region/displayId 混用".into());
        }
        let (region, pixels) = window_control::capture(target)?;
        (region, pixels, None, "print-window")
    } else {
        let (requested, display_id) = if let Some(target) = request.focus.as_ref() {
            (Some(focus_window(target)?), None)
        } else {
            resolve_region(request.region.as_ref(), request.display_id.as_deref())?
        };
        let requested = requested.unwrap_or(virtual_rect);
        if requested.width < 1 || requested.height < 1 {
            return Err("截图区域的宽高必须 >= 1".into());
        }
        let crop = clip_to_virtual(requested, virtual_rect)?;
        (crop, grab_screen(crop)?, display_id, "screen")
    };
    trace(&format!("4 抓屏完成，像素 {} 字节", pixels.len()));

    // 缩放两段算，而不是合并成一个倍率：
    // 先应用调用方要求的 scale（放大看小字），再受 maxDimension 限制缩小。
    // 分开算的好处是「请求 2 倍放大」在尺寸允许时真的得到 2 倍，而不是被悄悄改成别的倍率。
    let user_scale = request.scale.filter(|s| *s > 0.0).unwrap_or(1.0);
    let after_user_w = ((crop.width as f64 * user_scale).round() as u32).max(1);
    let after_user_h = ((crop.height as f64 * user_scale).round() as u32).max(1);

    let max_dimension = request.max_dimension.unwrap_or(1920).max(1) as u32;
    let clamp = (max_dimension as f64 / after_user_w as f64)
        .min(max_dimension as f64 / after_user_h as f64)
        .min(1.0);
    let out_w = ((after_user_w as f64 * clamp).round() as u32).max(1);
    let out_h = ((after_user_h as f64 * clamp).round() as u32).max(1);

    let rgba = image::RgbaImage::from_raw(crop.width as u32, crop.height as u32, pixels)
        .ok_or("位图缓冲区尺寸与区域不符")?;
    trace(&format!(
        "5 组装 RgbaImage 完成，输出目标 {}x{}",
        out_w, out_h
    ));
    let final_image = if out_w != crop.width as u32 || out_h != crop.height as u32 {
        let r = image::imageops::resize(&rgba, out_w, out_h, image::imageops::FilterType::Lanczos3);
        trace("6 缩放完成");
        r
    } else {
        rgba
    };

    trace("7 开始 PNG 编码");
    let mut png: Vec<u8> = Vec::new();
    image::DynamicImage::ImageRgba8(final_image)
        .write_to(&mut std::io::Cursor::new(&mut png), image::ImageFormat::Png)
        .map_err(|e| format!("PNG 编码失败：{e}"))?;
    trace(&format!("8 PNG 编码完成，{} 字节", png.len()));

    if let Some(max_bytes) = request.max_bytes {
        if png.len() as i64 > max_bytes {
            return Err(format!(
                "截图 PNG 体积 {} 字节，超过上限 {} 字节",
                png.len(),
                max_bytes
            ));
        }
    }

    Ok(ScreenshotResponse {
        png: Some(base64::engine::general_purpose::STANDARD.encode(&png)),
        width: out_w,
        height: out_h,
        source_bounds: crop,
        capture_mode: capture_mode.into(),
        display_id,
    })
}

/// 用 GDI 抓取指定区域的像素，返回 RGBA8。
fn grab_screen(crop: Region) -> Result<Vec<u8>, String> {
    unsafe {
        let screen_dc = GetDC(None);
        if screen_dc.is_invalid() {
            return Err("GetDC 失败".into());
        }
        // 用闭包包住是为了保证异常路径也释放 GDI 对象：GDI 句柄泄漏在长驻进程里会累积成故障
        let result = (|| -> Result<Vec<u8>, String> {
            trace("  3.1 GetDC 完成");
            let mem_dc = CreateCompatibleDC(screen_dc);
            if mem_dc.is_invalid() {
                return Err("CreateCompatibleDC 失败".into());
            }
            trace("  3.2 CreateCompatibleDC 完成");
            let bitmap = CreateCompatibleBitmap(screen_dc, crop.width, crop.height);
            if bitmap.is_invalid() {
                let _ = DeleteDC(mem_dc);
                return Err("CreateCompatibleBitmap 失败".into());
            }
            trace("  3.3 CreateCompatibleBitmap 完成");
            let previous = SelectObject(mem_dc, bitmap);

            // ROP 用纯 SRCCOPY（0x00CC0020）。
            //
            // 刻意**不加 CAPTUREBLT**：它文档上的用途是「把分层窗口也抓进来」，
            // 但在部分 GPU/DWM 组合下会让 BitBlt 静默产出全黑位图（GetDIBits 拿回全 0，
            // 而同一时刻 GetPixel 逐点读屏幕却有内容 —— 这个现象就是本机实测到的）。
            // 参考实现 xland/ScreenCapture（MIT）三处抓屏一律只用 SRCCOPY，以它为准。
            let rop = ROP_CODE(0x00CC_0020);
            trace("  3.4 开始 BitBlt");
            let blit = BitBlt(
                mem_dc,
                0,
                0,
                crop.width,
                crop.height,
                screen_dc,
                crop.x,
                crop.y,
                rop,
            );
            trace(&format!("  3.5 BitBlt 返回 ok={}", blit.is_ok()));

            let pixels = if blit.is_err() {
                Err("BitBlt 失败".into())
            } else {
                let r = read_bitmap_pixels(mem_dc, bitmap, crop.width, crop.height);
                trace(&format!("  3.6 GetDIBits 完成 ok={}", r.is_ok()));
                r
            };

            // 清理顺序：先恢复原对象，再删位图与 DC
            SelectObject(mem_dc, previous);
            // HBITMAP 实现了 CanInto<HGDIOBJ>，DeleteObject 是泛型参数，直接传即可
            let _ = DeleteObject(bitmap);
            let _ = DeleteDC(mem_dc);
            pixels
        })();

        let _ = ReleaseDC(None, screen_dc);
        result
    }
}

/// 从 DIB 读出像素并转成 RGBA8（GDI 给的是 BGRA）
fn read_bitmap_pixels(
    dc: HDC,
    bitmap: HBITMAP,
    width: i32,
    height: i32,
) -> Result<Vec<u8>, String> {
    let stride = width * 4;
    let mut info = BITMAPINFO {
        bmiHeader: BITMAPINFOHEADER {
            biSize: std::mem::size_of::<BITMAPINFOHEADER>() as u32,
            biWidth: width,
            // 负高度 = 请求自上而下排列的 DIB，省掉手工翻行
            biHeight: -height,
            biPlanes: 1,
            biBitCount: 32,
            biCompression: BI_RGB.0,
            // biSizeImage 对 BI_RGB 不是必需，但显式给上更稳（有些驱动会读它）
            biSizeImage: (stride * height) as u32,
            ..Default::default()
        },
        ..Default::default()
    };
    let mut buffer = vec![0u8; (stride * height) as usize];

    let scanned = unsafe {
        GetDIBits(
            // 传内存 DC（xland 的参考实现也是这么传的，实测在本机可用）。
            // 注意 MSDN 文档说的是「lpvBits 非空时 hdc 必须为 NULL」，
            // 但实测传 NULL 会直接返回 0（失败），而传创建该位图的内存 DC 才能读到像素。
            // 以实测为准 —— 这类 GDI 行为在不同驱动上确实存在差异。
            dc,
            bitmap,
            0,
            height as u32,
            Some(buffer.as_mut_ptr() as *mut _),
            &mut info,
            DIB_RGB_COLORS,
        )
    };
    if scanned == 0 {
        return Err("GetDIBits 失败".into());
    }

    trace(&format!(
        "  3.6.1 GetDIBits 扫描行数={scanned}，首像素 BGRA=({},{},{},{})",
        buffer[0], buffer[1], buffer[2], buffer[3]
    ));

    // BGRA -> RGBA，同时把 alpha 强制为不透明：
    // 屏幕像素的 alpha 通道在 GDI 里通常是 0，直接当 alpha 用会得到全透明图。
    for pixel in buffer.chunks_exact_mut(4) {
        pixel.swap(0, 2);
        pixel[3] = 255;
    }

    trace(&format!(
        "  3.6.2 转换后首像素 RGBA=({},{},{},{})",
        buffer[0], buffer[1], buffer[2], buffer[3]
    ));
    Ok(buffer)
}

/* ------------------------------ 入口 ------------------------------ */

/// 解析 `--key value` 形式的位置参数，返回 (命令, 参数表)
fn parse_args(argv: Vec<String>) -> (String, std::collections::HashMap<String, String>) {
    let mut iter = argv.into_iter();
    let command = iter.next().unwrap_or_default();
    let mut flags = std::collections::HashMap::new();
    let mut pending: Option<String> = None;
    for token in iter {
        if let Some(key) = pending.take() {
            flags.insert(key, token);
            continue;
        }
        if let Some(key) = token.strip_prefix("--") {
            pending = Some(key.to_string());
        }
    }
    (command, flags)
}

fn flag_i32(flags: &std::collections::HashMap<String, String>, key: &str) -> Option<i32> {
    flags.get(key).and_then(|v| v.parse().ok())
}

fn flag_f64(flags: &std::collections::HashMap<String, String>, key: &str) -> Option<f64> {
    flags.get(key).and_then(|v| v.parse().ok())
}

/// 从 stdin 读请求（base64(UTF8 JSON)），再用 argv 里的同名参数覆盖。
///
/// 为什么保留 stdin 这条路：宿主在只需小参数时直接管道传很省事；
/// 但**大块结果（PNG）绝不要走 stdout 管道** —— 那条路在 Windows 上会因
/// 管道缓冲区被填满且读取方状态不明而挂死（这个坑真实踩过，见 PROGRESS 记录）。
/// 所以截图的大数据一律落文件，stdout 只回小 JSON。
fn read_request(
    flags: &std::collections::HashMap<String, String>,
) -> Result<ScreenshotRequest, String> {
    let mut raw = String::new();
    std::io::stdin()
        .read_to_string(&mut raw)
        .map_err(|e| format!("读取 stdin 失败：{e}"))?;

    let trimmed = raw.trim();
    let mut request: ScreenshotRequest = if trimmed.is_empty() {
        // 允许完全不传 stdin（全部参数走 argv）
        ScreenshotRequest {
            display_id: None,
            region: None,
            scale: None,
            max_dimension: None,
            max_bytes: None,
            focus: None,
            background: None,
        }
    } else {
        let decoded = base64::engine::general_purpose::STANDARD
            .decode(trimmed)
            .map_err(|e| format!("stdin 不是合法 base64：{e}"))?;
        let text =
            String::from_utf8(decoded).map_err(|e| format!("base64 解出的内容不是 UTF-8：{e}"))?;
        serde_json::from_str(&text)
            .map_err(|e| format!("请求 JSON 解析失败：{e}（原文：{text}）"))?
    };

    // argv 覆盖 stdin：这样宿主可以「stdin 传大对象、argv 微调单个字段」
    if let (Some(x), Some(y), Some(w), Some(h)) = (
        flag_i32(flags, "x"),
        flag_i32(flags, "y"),
        flag_i32(flags, "width"),
        flag_i32(flags, "height"),
    ) {
        request.region = Some(Region {
            x,
            y,
            width: w,
            height: h,
        });
    }
    if let Some(id) = flags.get("display-id") {
        request.display_id = Some(id.clone());
    }
    if let Some(scale) = flag_f64(flags, "scale") {
        request.scale = Some(scale);
    }
    if let Some(max) = flag_i32(flags, "max-dimension") {
        request.max_dimension = Some(max as i64);
    }
    if let Some(max) = flag_i32(flags, "max-bytes") {
        request.max_bytes = Some(max as i64);
    }
    Ok(request)
}

/// 文件模式：PNG 直接写进 `--out`，stdout 只回小 JSON。
/// 这是宿主应该用的模式 —— 大块二进制不进管道，从根上避开挂死。
fn screenshot_to_files(flags: &std::collections::HashMap<String, String>) -> ExitCode {
    let request = match read_request(flags) {
        Ok(r) => r,
        Err(e) => return fail(e),
    };
    let out_path = match flags.get("out") {
        Some(p) => p.clone(),
        None => return fail("文件模式需要 --out <png 路径>"),
    };

    // capture 内统一处理前台/后台窗口，文件和 stdout 两种出口的语义一致。

    let response = match capture(&request) {
        Ok(r) => r,
        Err(e) => return fail(e),
    };

    // 先解码再写文件：写盘失败要如实报错，不能留下半截文件
    let png_b64 = match response.png.as_deref() {
        Some(s) => s,
        None => return fail("内部错误：capture 没有返回 PNG 数据"),
    };
    let bytes = match base64::engine::general_purpose::STANDARD.decode(png_b64) {
        Ok(b) => b,
        Err(e) => return fail(format!("PNG base64 解码失败：{e}")),
    };
    if let Err(e) = std::fs::write(&out_path, &bytes) {
        return fail(format!("写入 {out_path} 失败：{e}"));
    }
    trace(&format!("9 已写盘 {out_path}（{} 字节）", bytes.len()));

    // stdout 只回小 JSON（不含 png 字段）
    let meta = OutMeta {
        path: out_path,
        width: response.width,
        height: response.height,
        source_bounds: response.source_bounds,
        capture_mode: response.capture_mode,
        display_id: response.display_id,
        bytes: bytes.len() as u64,
    };
    match write_json(&meta) {
        Ok(()) => ExitCode::SUCCESS,
        Err(e) => fail(e),
    }
}

/// 标准模式：PNG 以 base64 放进 stdout 的 JSON 里（供小图/兼容老调用方使用）
fn screenshot_to_stdout(flags: &std::collections::HashMap<String, String>) -> ExitCode {
    let request = match read_request(flags) {
        Ok(r) => r,
        Err(e) => return fail(e),
    };
    match capture(&request) {
        Ok(response) => match write_json(&response) {
            Ok(()) => ExitCode::SUCCESS,
            Err(e) => fail(e),
        },
        Err(e) => fail(e),
    }
}

fn json_command<T: for<'de> Deserialize<'de>, R: Serialize>(
    operation: impl FnOnce(&T) -> Result<R, String>,
) -> ExitCode {
    match read_body::<T>()
        .and_then(|request| operation(&request))
        .and_then(|response| write_json(&response))
    {
        Ok(()) => ExitCode::SUCCESS,
        Err(error) => fail(error),
    }
}

fn main() -> ExitCode {
    let (command, flags) = parse_args(std::env::args().skip(1).collect());
    // 所有窗口/输入坐标都使用物理像素，不能只在截图命令里设置感知。
    unsafe {
        let _ = SetProcessDpiAwareness(PROCESS_PER_MONITOR_DPI_AWARE);
    }
    match command.as_str() {
        "find-color" => json_command(visual::find_color),
        "ocr" => json_command(visual::recognize),
        "ocr-languages" => match ocr::languages().and_then(|result| write_json(&result)) {
            Ok(()) => ExitCode::SUCCESS,
            Err(error) => fail(error),
        },
        "related-windows" => json_command(window_query::related),
        "read-listview" => json_command(listview::read),
        "child-windows" => json_command(window_control::children),
        "window-message" => json_command(window_control::perform_message),
        "manage-window" => json_command(window_control::manage),
        "list-displays" => {
            unsafe {
                // 用 PER_MONITOR 而不是 SYSTEM：多屏不同缩放率时，前者按显示器各自换算，
        // 后者只按主屏算，副屏坐标会偏。返回 Err 说明感知已被设置过，属正常，忽略即可。
        let _ = SetProcessDpiAwareness(PROCESS_PER_MONITOR_DPI_AWARE);
            }
            match list_displays() {
                Ok(displays) => match write_json(&displays) {
                    Ok(()) => ExitCode::SUCCESS,
                    Err(e) => fail(e),
                },
                Err(e) => fail(e),
            }
        }
        "screenshot" => {
            let use_files = flags.contains_key("out") || flags.contains_key("out-meta");
            if use_files {
                return screenshot_to_files(&flags);
            }
            screenshot_to_stdout(&flags)
        }
        "probe-pixels" => {
            // 排查用：拿 GetPixel 直接读几个点，与 GetDIBits 的缓冲区对比。
            // 用途：区分「屏幕真的是黑的」和「缓冲区里全是 0（读法/格式不对）」。
            // GetPixel 是逐点查询、不依赖 DIB 布局，所以它是可信的对照组。
            unsafe {
                let _ = SetProcessDpiAwareness(PROCESS_PER_MONITOR_DPI_AWARE);
                let dc = GetDC(None);
                if dc.is_invalid() {
                    return fail("GetDC 失败");
                }
                let points = [
                    (200, 200), (900, 400), (60, 20), (1000, 1000),
                    (2000, 500), (2700, 400), (-1800, 500),
                ];
                for (x, y) in points {
                    // GetPixel 返回 ColorRef 包装类型，.0 取出裸 u32；CLR_INVALID 本身就是 u32
                    let raw = GetPixel(dc, x, y).0;
                    if raw == CLR_INVALID {
                        println!("({x},{y}) GetPixel=CLR_INVALID");
                    } else {
                        let r = raw & 0xFF;
                        let g = (raw >> 8) & 0xFF;
                        let b = (raw >> 16) & 0xFF;
                        println!("({x},{y}) GetPixel rgb=({r},{g},{b}) raw=0x{raw:08X}");
                    }
                }
                let _ = ReleaseDC(None, dc);
            }
            ExitCode::SUCCESS
        }
        "find-image" => match read_body::<FindImageRequest>() {
            Ok(request) => match find_image(&request) {
                Ok(response) => match write_json(&response) {
                    Ok(()) => ExitCode::SUCCESS,
                    Err(e) => fail(e),
                },
                Err(e) => fail(e),
            },
            Err(e) => fail(e),
        },
        "action" => match read_body::<ActionRequest>() {
            Ok(request) => match run_action(&request) {
                Ok(()) => match write_json(&ActionOutcome { ok: true }) {
                    Ok(()) => ExitCode::SUCCESS,
                    Err(e) => fail(e),
                },
                Err(e) => fail(e),
            },
            Err(e) => fail(e),
        },
        "list-windows" => match list_windows() {
            Ok(windows) => match write_json(&windows) {
                Ok(()) => ExitCode::SUCCESS,
                Err(e) => fail(e),
            },
            Err(e) => fail(e),
        },
        "focus-window" => match read_body::<FocusRequest>() {
            Ok(request) => match focus_by_request(&request) {
                Ok(()) => match write_json(&ActionOutcome { ok: true }) {
                    Ok(()) => ExitCode::SUCCESS,
                    Err(e) => fail(e),
                },
                Err(e) => fail(e),
            },
            Err(e) => fail(e),
        },
        "" => fail(
            "用法：dsh-screen <list-displays|screenshot|find-image|find-color|ocr|ocr-languages|action|list-windows|focus-window|child-windows|read-listview|window-message|manage-window|probe-pixels> \
             [--x N --y N --width N --height N]",
        ),
        other => fail(format!(
            "未知命令 '{other}'（支持 list-displays / screenshot / find-image / find-color / ocr / ocr-languages / action / list-windows / focus-window / child-windows / read-listview / window-message / manage-window / probe-pixels）"
        )),
    }
}
