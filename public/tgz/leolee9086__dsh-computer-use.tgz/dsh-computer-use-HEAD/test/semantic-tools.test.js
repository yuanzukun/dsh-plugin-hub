import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import test from 'node:test';
import { apply as applyTools } from '../src/tool.js';

function pngBytes() {
  const data = Buffer.alloc(24);
  data.set([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]);
  new DataView(data.buffer, data.byteOffset, data.byteLength).setUint32(16, 100);
  new DataView(data.buffer, data.byteOffset, data.byteLength).setUint32(20, 50);
  return data;
}

function normalizedPngBytes() {
  const data = pngBytes();
  new DataView(data.buffer, data.byteOffset, data.byteLength).setUint32(16, 50);
  new DataView(data.buffer, data.byteOffset, data.byteLength).setUint32(20, 25);
  return data;
}

function toolContext() {
  const tools = [];
  const semanticTree = {
    element_id: 'uia:42,2',
    role: 'Window',
    name: 'Example',
    enabled: true,
    offscreen: false,
    patterns: [],
    children: [{
      element_id: 'uia:42,9',
      role: 'Button',
      name: 'Save',
      automation_id: 'saveButton',
      process_id: 321,
      enabled: true,
      offscreen: false,
      patterns: ['invoke'],
      bounds: { x: 20, y: 20, width: 80, height: 24 },
      children: [],
    }, {
      element_id: 'uia:42,10',
      role: 'ListItem',
      name: 'Archived result',
      process_id: 321,
      enabled: true,
      offscreen: true,
      patterns: ['scroll_item'],
      children: [],
    }],
  };
  const calls = [];
  // 单独记：抓语义树时宿主传下来的窗口句柄。
  // 不塞进 `calls`——那里是"元素动作"的流水，其余用例按它断 `at(-1)`。
  const accessibilityHandles = [];
  const computer = {
    capabilities: {},
    async screenshot() {
      return {
        data: pngBytes(),
        sourceBounds: { x: 0, y: 0, width: 100, height: 50 },
        capturedAt: Date.now(),
      };
    },
    // 指名窗口的截图走这条路：聚焦与截图在宿主侧是同一次调用，
    // 返回的 sourceBounds 是**聚焦之后**实时读到的边界，不是列表时刻的旧值。
    async captureWindow(target, request) {
      calls.push({ kind: 'capture_window', target, request });
      return {
        data: pngBytes(),
        sourceBounds: { x: 100, y: 200, width: 300, height: 150 },
        capturedAt: Date.now(),
      };
    },
    async accessibilitySnapshot(windowHandle) { accessibilityHandles.push(windowHandle); return semanticTree; },
    async perform(action) { calls.push(action); },
    async listWindows() { return [{ id: 'native-41', title: 'Example Window', processId: 99, bounds: { x: 0, y: 0, width: 100, height: 50 }, focused: true }]; },
    async focusWindow(target) { calls.push({ kind: 'focus_window', target }); },
    async performAccessibility(action) { calls.push(action); },
  };
  const ctx = {
    tools: {
      register(definition) { tools.push(definition); return () => {}; },
      guard() { return () => {}; },
    },
    attachments: {
      async saveImage() {
        return { attachmentId: 'image-1', mediaType: 'image/png', bytes: 24, width: 50, height: 25, originalDimensions: { width: 100, height: 50 } };
      },
      async readImage(ref) {
        return { ref, data: normalizedPngBytes() };
      },
    },
    on() { return () => {}; },
    inject(_names, callback) { callback(this); },
    get(name) {
      if (name === 'computer') return computer;
      if (name === 'attachments') return ctx.attachments;
      if (name === 'llm') return { resolveModelInfo: async () => ({ inputModalities: ['image'] }) };
      return undefined;
    },
  };
  return { ctx, tools, calls, accessibilityHandles, computer, semanticTree };
}

const agent = {
  session: { requestHeader() { return { config: { provider: 'test', model: 'vision-test' } }; } },
  options: {},
};

function toolByName(tools, name) {
  const tool = tools.find((entry) => entry.name === name);
  assert.ok(tool, `missing ${name}`);
  return tool;
}

test('semantic tools bind element actions to fresh image and accessibility observations', async () => {
  const { ctx, tools, calls } = toolContext();
  applyTools(ctx, {
    observeApproval: 'allow',
    controlApproval: 'allow',
    maxObservationAgeMs: 120_000,
    maxObservationsPerAgent: 8,
    maxSemanticSnapshots: 8,
    maxSemanticMatches: 20,
  });
  const exec = { agent };
  const screenshot = await toolByName(tools, 'computer_screenshot').execute({}, exec);
  assert.equal(screenshot.image.width, 50);
  assert.equal(screenshot.image.height, 25);
  assert.equal(screenshot.content_hash, createHash('sha256').update(normalizedPngBytes()).digest('hex'));
  const rendered = toolByName(tools, 'computer_screenshot').output.render({}, screenshot);
  assert.equal(rendered[0].type, 'text');
  assert.equal(rendered[1].type, 'image');
  assert.equal(rendered[1].attachment.attachmentId, 'image-1');
  const accessibility = JSON.parse(await toolByName(tools, 'computer_accessibility').execute({ screenshot_id: screenshot.screenshot_id }, exec));
  assert.match(accessibility.snapshot_id, /^semantic-/);
  assert.equal(accessibility.screenshot_id, screenshot.screenshot_id);
  assert.equal(accessibility.screenshot_hash, screenshot.content_hash);
  const matches = JSON.parse(await toolByName(tools, 'computer_find').execute({
    snapshot_id: accessibility.snapshot_id,
    name: 'save',
    automation_id: '',
    match: 'contains',
  }, exec));
  assert.deepEqual(matches.matches.map((element) => element.element_id), ['uia:42,9']);
  const result = await toolByName(tools, 'computer_element').execute({
    screenshot_id: screenshot.screenshot_id,
    snapshot_id: accessibility.snapshot_id,
    element_id: 'uia:42,9',
    operation: 'invoke',
    value: '',
  }, exec);
  assert.match(result, /Performed invoke/);
  assert.equal(calls.length, 1);
  assert.equal(calls[0].kind, 'invoke');
  assert.equal(calls[0].elementId, 'uia:42,9');
  assert.equal(calls[0].element.process_id, 321);
  await assert.rejects(() => toolByName(tools, 'computer_element').execute({
    screenshot_id: screenshot.screenshot_id,
    snapshot_id: accessibility.snapshot_id,
    element_id: 'uia:42,9',
    operation: 'invoke',
  }, exec), /was consumed by an action affecting/);
  assert.equal(calls.length, 1);
});

test('computer_screenshot(window_id) raises that window and captures it in one step', async () => {
  const { ctx, tools, calls } = toolContext();
  applyTools(ctx, {
    observeApproval: 'allow',
    controlApproval: 'allow',
    maxObservationAgeMs: 120_000,
    maxObservationsPerAgent: 8,
    maxSemanticSnapshots: 8,
    maxSemanticMatches: 20,
  });
  const exec = { agent };
  const screenshot = toolByName(tools, 'computer_screenshot');

  const listed = JSON.parse(await toolByName(tools, 'computer_windows').execute({ operation: 'list' }, exec));
  const windowId = listed.windows[0].id;

  const capture = await screenshot.execute({ window_id: windowId }, exec);
  assert.equal(capture.window.id, windowId);
  assert.equal(capture.window.title, 'Example Window');
  // 边界来自聚焦之后的实时读取，只有走 captureWindow 才拿得到这组值。
  assert.deepEqual(capture.source_bounds, { x: 100, y: 200, width: 300, height: 150 });
  assert.equal(calls.filter((call) => call.kind === 'capture_window').length, 1);

  // 模型可见文本必须说明这张图是"把该窗口提到前台"换来的。
  const rendered = screenshot.output.render({}, capture);
  assert.equal(rendered[0].type, 'text');
  assert.match(rendered[0].text, /Raised for this capture: "Example Window"/);

  // window_id 是独立形态：不能再叠加区域或显示器。
  await assert.rejects(
    () => screenshot.execute({ window_id: windowId, x: 1, y: 1, width: 10, height: 10 }, exec),
    /window_id captures that window on its own/,
  );
});

test('语义树从**截图那个窗口**扎根，而不是"当前焦点窗口"', async () => {
  // 这条盯的是一个很难发现的 bug：截图和抓树用的是同一个 screenshot_id，
  // 看起来完全自洽，但抓树那一刻问的是"谁在前台"——多窗口/多屏时会拿到
  // 另一个窗口的树。两条证据互相矛盾，却没有任何迹象提示调用方。
  const { ctx, tools, accessibilityHandles } = toolContext();
  applyTools(ctx, {
    observeApproval: 'allow',
    controlApproval: 'allow',
    maxObservationAgeMs: 120_000,
    maxObservationsPerAgent: 8,
    maxSemanticSnapshots: 8,
    maxSemanticMatches: 20,
  });
  const exec = { agent };

  const listed = JSON.parse(await toolByName(tools, 'computer_windows').execute({ operation: 'list' }, exec));
  const windowId = listed.windows[0].id;

  // 1) 截一个**窗口**，再抓树：句柄必须传下去。
  const capture = await toolByName(tools, 'computer_screenshot').execute({ window_id: windowId }, exec);
  await toolByName(tools, 'computer_accessibility').execute({ screenshot_id: capture.screenshot_id }, exec);
  assert.equal(
    accessibilityHandles.at(-1),
    'native-41',
    '窗口截图的句柄必须一路传到后端，否则它会从"当前焦点窗口"抓——那是另一个窗口',
  );

  // 2) 整屏截图没有窗口，句柄应当是空的：由后端决定回退，而不是宿主假装知道。
  const plain = await toolByName(tools, 'computer_screenshot').execute({}, exec);
  await toolByName(tools, 'computer_accessibility').execute({ screenshot_id: plain.screenshot_id }, exec);
  assert.equal(accessibilityHandles.at(-1), undefined);
});

test('control consumes affected image evidence while focus keeps reusable window identities', async () => {
  const { ctx, tools, calls } = toolContext();
  applyTools(ctx, {
    observeApproval: 'allow',
    controlApproval: 'allow',
    maxObservationAgeMs: 120_000,
    maxObservationsPerAgent: 8,
    maxSemanticSnapshots: 8,
    maxSemanticMatches: 20,
  });
  const exec = { agent };
  const first = await toolByName(tools, 'computer_screenshot').execute({}, exec);
  const concurrent = await toolByName(tools, 'computer_screenshot').execute({}, exec);
  await toolByName(tools, 'computer_click').execute({
    screenshot_id: first.screenshot_id,
    x: 20,
    y: 10,
  }, exec);
  await assert.rejects(() => toolByName(tools, 'computer_type').execute({
    screenshot_id: concurrent.screenshot_id,
    text: 'stale',
  }, exec), /was consumed by an action affecting/);
  await assert.rejects(() => toolByName(tools, 'computer_click').execute({
    screenshot_id: first.screenshot_id,
    x: 20,
    y: 10,
  }, exec), /was consumed by an action affecting/);
  const second = await toolByName(tools, 'computer_screenshot').execute({}, exec);
  const listed = JSON.parse(await toolByName(tools, 'computer_windows').execute({ operation: 'list' }, exec));
  assert.equal(listed.windows.length, 1);
  assert.match(listed.windows[0].id, /^window-/);
  assert.notEqual(listed.windows[0].id, 'native-41');
  assert.equal('processId' in listed.windows[0], true);
  await toolByName(tools, 'computer_windows').execute({ operation: 'focus', window_id: listed.windows[0].id }, exec);
  assert.equal(calls.find((call) => call.kind === 'focus_window').target.id, 'native-41');
  assert.equal(calls.find((call) => call.kind === 'focus_window').target.processId, 99);
  await toolByName(tools, 'computer_windows').execute({ operation: 'focus', window_id: listed.windows[0].id }, exec);
  await toolByName(tools, 'computer_type').execute({ window_id: listed.windows[0].id, text: 'identity still current' }, exec);
  await assert.rejects(() => toolByName(tools, 'computer_windows').execute({ operation: 'focus', window_id: 'native-41' }, exec), /is unavailable in this session/);
  await assert.rejects(() => toolByName(tools, 'computer_type').execute({
    screenshot_id: second.screenshot_id,
    text: 'stale',
  }, exec), /was consumed by an action affecting/);
  assert.deepEqual(calls.map((call) => call.kind), ['click', 'focus_window', 'focus_window', 'type']);
});

test('semantic element action rejects a pattern unsupported by the observed element', async () => {
  const { ctx, tools } = toolContext();
  applyTools(ctx, {
    observeApproval: 'allow',
    controlApproval: 'allow',
    maxObservationAgeMs: 120_000,
    maxObservationsPerAgent: 8,
    maxSemanticSnapshots: 8,
    maxSemanticMatches: 20,
  });
  const exec = { agent };
  const screenshot = await toolByName(tools, 'computer_screenshot').execute({}, exec);
  const accessibility = JSON.parse(await toolByName(tools, 'computer_accessibility').execute({ screenshot_id: screenshot.screenshot_id }, exec));
  await assert.rejects(() => toolByName(tools, 'computer_element').execute({
    screenshot_id: screenshot.screenshot_id,
    snapshot_id: accessibility.snapshot_id,
    element_id: 'uia:42,9',
    operation: 'toggle',
  }, exec), /does not support toggle/);
});

test('semantic element action requires the screenshot bound to its snapshot', async () => {
  const { ctx, tools } = toolContext();
  applyTools(ctx, {
    observeApproval: 'allow',
    controlApproval: 'allow',
    maxObservationAgeMs: 120_000,
    maxObservationsPerAgent: 8,
    maxSemanticSnapshots: 8,
    maxSemanticMatches: 20,
  });
  const exec = { agent };
  const screenshot = await toolByName(tools, 'computer_screenshot').execute({}, exec);
  const accessibility = JSON.parse(await toolByName(tools, 'computer_accessibility').execute({ screenshot_id: screenshot.screenshot_id }, exec));
  const newerScreenshot = await toolByName(tools, 'computer_screenshot').execute({}, exec);
  await assert.rejects(() => toolByName(tools, 'computer_element').execute({
    screenshot_id: newerScreenshot.screenshot_id,
    snapshot_id: accessibility.snapshot_id,
    element_id: 'uia:42,9',
    operation: 'invoke',
  }, exec), /is not bound to screenshot/);
});

test('semantic element action permits scroll_into_view for an offscreen matching pattern', async () => {
  const { ctx, tools, calls } = toolContext();
  applyTools(ctx, {
    observeApproval: 'allow',
    controlApproval: 'allow',
    maxObservationAgeMs: 120_000,
    maxObservationsPerAgent: 8,
    maxSemanticSnapshots: 8,
    maxSemanticMatches: 20,
  });
  const exec = { agent };
  const screenshot = await toolByName(tools, 'computer_screenshot').execute({}, exec);
  const accessibility = JSON.parse(await toolByName(tools, 'computer_accessibility').execute({ screenshot_id: screenshot.screenshot_id }, exec));
  const result = await toolByName(tools, 'computer_element').execute({
    screenshot_id: screenshot.screenshot_id,
    snapshot_id: accessibility.snapshot_id,
    element_id: 'uia:42,10',
    operation: 'scroll_into_view',
  }, exec);
  assert.match(result, /Performed scroll_into_view/);
  assert.equal(calls[0].kind, 'scroll_into_view');
});

test('text-only agents observe, read and invoke without a screenshot or llm route', async () => {
  const { ctx, tools, calls, accessibilityHandles, computer } = toolContext();
  const originalGet = ctx.get;
  ctx.get = (name) => name === 'llm' ? undefined : originalGet(name);
  computer.performAccessibility = async (action) => { calls.push(action); return { text: 'Native readable content' }; };
  applyTools(ctx, { observeApproval: 'allow', controlApproval: 'allow' });
  const exec = { agent: { session: {}, options: {} } };
  const list = JSON.parse(await toolByName(tools, 'computer_windows').execute({ operation: 'list' }, exec));
  const observed = JSON.parse(await toolByName(tools, 'computer_accessibility').execute({ window_id: list.windows[0].id }, exec));
  assert.equal(observed.screenshot_id, undefined);
  assert.equal(accessibilityHandles.at(-1), 'native-41');
  const read = JSON.parse(await toolByName(tools, 'computer_read').execute({ snapshot_id: observed.snapshot_id, element_id: 'uia:42,9' }, exec));
  assert.equal(read.result.text, 'Native readable content');
  assert.equal(calls.at(-1).hwnd, 'native-41');
  await toolByName(tools, 'computer_element').execute({ snapshot_id: observed.snapshot_id, element_id: 'uia:42,9', operation: 'invoke' }, exec);
  await assert.rejects(() => toolByName(tools, 'computer_read').execute({ snapshot_id: observed.snapshot_id, element_id: 'uia:42,9' }, exec), /was consumed/);
  assert.deepEqual(calls.map((call) => call.kind), ['read', 'invoke']);
});

test('frozen continuations preserve result identity and cannot restore consumed control evidence', async () => {
  const { ctx, tools, computer, semanticTree, calls } = toolContext();
  computer.capabilities = { semanticPaging: true, semanticSnapshots: true };
  const acquired = [];
  const finished = Date.now();
  computer.accessibilitySnapshot = async (_window, _signal, options) => {
    acquired.push(options);
    const tree = structuredClone(semanticTree);
    Object.defineProperty(tree, 'acquisition', { value: {
      backend: 'uia', result_id: 'fixed-result', next_cursor: options.cursor ? undefined : 'next-fixed-page',
      worker_generation: 'generation', coverage: { status: options.cursor ? 'complete' : 'partial' },
      consistency: { mode: 'snapshot', status: 'frozen', result_id: 'fixed-result', sha256: 'stable-digest', capture_finished_at: finished, source_atomic: false },
    } });
    return tree;
  };
  applyTools(ctx, { observeApproval: 'allow', controlApproval: 'allow' });
  const exec = { agent: { session: agent.session, options: {} } };
  const screenshot = await toolByName(tools, 'computer_screenshot').execute({}, exec);
  const readPage = (args) => toolByName(tools, 'computer_accessibility').execute(args, exec).then(JSON.parse);
  const first = await readPage({ screenshot_id: screenshot.screenshot_id });
  assert.equal(acquired[0].consistency, 'snapshot');
  assert.equal(first.result_id, 'fixed-result');
  assert.equal(first.consistency.source_atomic, false);
  const continuation = { snapshot_id: first.snapshot_id, cursor: first.next_cursor };
  await assert.rejects(() => readPage({ ...continuation, consistency: 'live' }), /cursor consistency changed/);
  await toolByName(tools, 'computer_element').execute({ snapshot_id: first.snapshot_id, element_id: 'uia:42,9', operation: 'invoke' }, exec);
  const second = await readPage(continuation);
  assert.equal(second.result_id, first.result_id); assert.equal(second.captured_at, finished);
  assert.equal(second.consistency.sha256, first.consistency.sha256);
  assert.equal(acquired[1].consistency, 'snapshot');
  await assert.rejects(() => toolByName(tools, 'computer_element').execute({ snapshot_id: second.snapshot_id, element_id: 'uia:42,9', operation: 'invoke' }, exec), /was consumed/);
  assert.equal(calls.length, 1, 'reading archived pages cannot grant new action permission');
});

test('match limits require a native snapshot query before any provider acquisition', async () => {
  const { ctx, tools, computer, accessibilityHandles } = toolContext();
  computer.capabilities.semanticPaging = true;
  applyTools(ctx, { observeApproval: 'allow', controlApproval: 'allow' });
  const exec = { agent: { session: {}, options: {} } };
  const find = args => toolByName(tools, 'computer_find').execute(args, exec);
  await assert.rejects(find({ name: 'Save', max_matches: 1 }), /requires source:native/);
  await assert.rejects(find({ source: 'native', name: 'Save', max_matches: 1 }), /requires a native query with snapshot consistency/);
  computer.capabilities.semanticSnapshots = true;
  await assert.rejects(find({ source: 'native', name: 'Save', consistency: 'live', max_matches: 1 }), /requires a native query with snapshot consistency/);
  for (const max_matches of [0, 20001, 1.5, '3', null]) {
    await assert.rejects(find({ source: 'native', name: 'Save', max_matches }), /max_matches must be 1\.\.20000/);
  }
  assert.equal(accessibilityHandles.length, 0);
});

test('semantic observations are isolated across agents and mismatched window/image is rejected', async () => {
  const { ctx, tools } = toolContext();
  applyTools(ctx, { observeApproval: 'allow', controlApproval: 'allow' });
  const exec = { agent: { session: {}, options: {} } };
  const observed = JSON.parse(await toolByName(tools, 'computer_accessibility').execute({}, exec));
  await assert.rejects(() => toolByName(tools, 'computer_element').execute({ snapshot_id: observed.snapshot_id, element_id: 'uia:42,9', operation: 'invoke' }, { agent: { session: {} } }), /unavailable in this session/);
  await assert.rejects(() => toolByName(tools, 'computer_read').execute({ snapshot_id: observed.snapshot_id, screenshot_id: 'unbound', element_id: 'uia:42,9' }, exec), /no screenshot binding/);
});
