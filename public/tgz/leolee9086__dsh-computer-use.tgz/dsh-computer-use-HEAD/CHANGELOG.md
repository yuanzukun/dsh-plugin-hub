# 变更记录

## 0.5.16 — 2026-10-09

- Windows locator 的每个 step 增加候选相对后代 `has` / `has_not`，可与顶层 selector 和同节点 `where` AND。内层支持 selector、where、inclusion、children/subtree 与 max_depth，严格排除候选自身；多个后代见证只算一个候选，内层不允许 window、nth 或嵌套关系。
- 关系与外层共享每 step 的 64 表达式节点 / 32 属性比较及整轮节点、时间和总深度预算；所有 path 和关系分支在遍历前编译，隐藏无效正则或 MSAA 不支持字段仍直接报错。outer scope:children 只限制候选层级，关系继续受从外层根计算的总深度限制。
- 找到后代可证明 has；has_not 仅在声明范围完整遍历且无匹配时通过。节点、时间或可达深度截断保留未知，返回 incomplete 并清空目标，不跳过未知候选选择后续 nth。来源属性/正则错误不转成缺席或重试。
- 候选、选中目标与已选祖先实时复查全部使用同一共享预算；重复访问也计数，避免复查或重试扩张预算。保留窗口/节点身份、source_atomic:false、一次动作与不重放合同，Rust helper 内容保持已验收版本。
- 默认 WPF 真实 provider 通过正负/AND、多个见证、自身排除、相对 children、共享节点/深度截断、未知 nth 和隐藏错误零动作验收；替换等待、写值/动作确认的原路径携带关系复查。既有并发编辑、惰性树、虚拟项、Grid 和弹窗任务也通过。
- 实际系统声音窗口先观察 List 父节点和五个无子节点的 ListItem，再用 has 设备 / has_not 缺失后代定位；叶子自身不算后代，多个负关系叶子保持歧义。一轮 Select 后独立 selected 读回，Cancel 后新目录确认关闭；WPF/声音联合在 23,912ms 内完成并核对清理后标记和当前源哈希。
- 共享遍历预算影响的树/滚动子集回归通过，另存 fullAcceptance:false 的 0.5.16 证据；无安装真实 Loader 验收确认所有行、27 工具、提示词与观察允许/控制拒绝。组合指标按实际包版本命名，保留原 0.5.15 / 0.5.14 记录。
- 更新关系示例、工作流提示词和版本清单；91 个 JavaScript 文件语法检查、124 项 Node/ToolRuntime 测试通过。工具总数仍为 27，实测范围与预算边界见 [EVIDENCE.md](EVIDENCE.md)。

## 0.5.15 — 2026-10-09

- Windows locator 增加同节点 `where` 的 all/any/not 与 exact/contains/.NET regex 属性叶子。顶层属性仍与 where AND，重叠 OR 对同一节点只计一次，不同节点仍要求消歧；step 的范围、深度、nth 和 inclusion 合同保留，基础 `computer_find` 不变。
- JS 与生产 C# 双重验证深度 4、64 表达式节点、32 属性比较及 all/any 的 1–16 项预算。每轮访问窗口前编译全部 path/分支，正则默认 IgnoreCase + CultureInvariant、允许 inline flags，每次匹配限 25ms、输入限 16,000 UTF-16 单元；语法、超时和输入上限错误不转为缺席或重试。
- 缺失/null 属性保持未知，NOT 未知不会制造命中；最终未知返回 `locator_property_unavailable`，已能证明的 any true / all false 可短路。MSAA 在遍历前拒绝任意分支中的 automation ID / framework ID。遍历、chosen 和 ancestor 复读使用同一 matcher，继续保持身份、覆盖、总节点/时间及不重放规则。
- 新增生产编译 matcher 的 24 项反射合同检查，以及默认 WPF 的布尔链、隐藏无效正则、MSAA 不支持分支和真实长名称正则超时零动作验收。原有替换等待、并发编辑/切窗、惰性树、虚拟项、Grid 和独立 HWND 弹窗任务通过。
- 新 `smoke:locators:electron` 顺序验收默认 WPF 与实际系统声音设备：跨节点 OR 歧义、同节点重叠 OR 唯一、NOT 排除另节点、一次 Select 与独立 selected 读回，再 Cancel 并确认自己新开的窗口关闭。清理后标记、本轮指标时间与 accepted source 哈希全部核对。
- `verify:profile` 改为无安装的本地组合验收：读取实际 bundle patch、应用官方 overlay 语义，解析本地 package exports，再通过真实 Loader/Include 检查逐行激活、27 工具、提示词与观察允许/控制拒绝。验收前后清理临时组合，不把此路径写成 CLI 安装或当前 GUI 升级。
- 受影响的树/滚动任务定向回归通过，另存带版本的子集证据并标明非完整联合验收；0.5.14 原始应用证据保留。工作流提示词、正则示例与运行入口更新，工具总数仍为 27，Rust helper 内容保持已验收版本。实测范围及来源错误见 [EVIDENCE.md](EVIDENCE.md)。

## 0.5.14 — 2026-10-09

- 新增 Windows `computer_tree` 和 `computer_scroll_find`，共 27 工具。树路径按直属 TreeItem 逐层展开、重定位与确认，所需祖先各展开一次、末项选择一次；窗口、容器与已观察分支身份固定，移除/替换停止并保留已发生步骤，缺失分支有界超时且零选择。
- 显式滚动查找使用固定 ScrollPattern 容器、页/次数/总截止预算，每次滚动后读实际百分比确认变化。返回项须与新读视口有正面积交集；默认 WPF peer 的 offscreen:false 单独不能证明在视口。流程不激活项，partial 不算缺失，达到滚动边界/次数不证明虚拟数据全局不存在。
- 新增真实 WPF 默认 peers、生产 WindowsComputer、Cordis ToolRuntime 和官方 runner 数据任务验收：惰性树及缺失/替换，600 项 ItemContainer 精确查找/Realize/选择，非首屏 Grid 独立 cell 引用选择与业务状态核对，ScrollPattern 查找后单次 Invoke 和实际 Click 计数；不支持、截断、滚动次数与 200ms 取消均检查。
- 真实系统信息两轮从收拢的系统摘要按三层路径选择显示/声音设备，每轮仅展开根与组件各一次、选择一次；独立 SelectionItem 和树选择集核对，无关分支保持收拢。真正系统 PowerShell Out-GridView 的 600 行任务独立读取 579/480 cell、重新定位行选择并核对唯一选择集，一次 ValuePattern 写入后确认筛选只剩指定行。Text cell 的 grid_item 不被猜成 selection_item。
- `smoke:data` 默认顺序联合夹具、真实树应用和真实 Grid 应用，清理后完成标记及源证据时间/SHA-256 均核对。子集与结构探查不冒充完整验收；Grid 筛选测试的定位、读取和轮询共用真实总截止。
- 保留实际 MMC ordinary spawn EACCES、启动期只读来源变化及一次零动作 ancestor_changed 的失败证据；未提升权限或重放未知动作。更新工作流提示词与真实 Loader 名单，原生源码/二进制保持 0.5.13 已验收内容。详细结果及应用范围见 [EVIDENCE.md](EVIDENCE.md)。

## 0.5.13 — 2026-10-09

- Windows 顶层目录保留有可见面积的无标题菜单/Popup，增加 native class、thread 和实际 owner 链；`computer_windows:related` 从固定 HWND/PID/标题查询 owned、same_thread 或 same_process 范围。owned 允许跨进程，线程/进程相关性不冒充归属；工具总数仍为 25。
- `computer_locate` / `computer_wait` / `computer_act` 支持 `window_query` 每轮发现新根；`after.window_query` 可直接确认动作创建的菜单、Popup 或对话框。报告实际候选和新 window/semantic ID，多根歧义停止，partial 零项/一项不证明缺席/唯一。
- 原 anchor 身份变化和来源错误立即上报；仅明确候选新根替换的只读 not_started 变化在同一截止内重新枚举。前置、一次动作和后置共用截止，unknown/失败动作不重放。显式 `after.window_id` 且无新查询时清除继承查询，直接回已列窗口读结果。
- Rust helper 改 Windows GUI subsystem；语义 worker 以 winexe 编译并将目标纳入缓存哈希，通过 GetStdHandle 的继承管道读取/写入 UTF-8 协议，避免新控制台干扰菜单前台。
- 真实 Electron/ToolRuntime/官方 runner 四类验收通过：TrackPopupMenu、ToolStripDropDown、真正 WPF Primitives.Popup 及不同 PID 的 owned 对话框各两轮，实际业务计数精确增长。原生菜单另核对 WM_COMMAND、菜单进入/退出及返回计数；Forms/WPF 禁用根替换后新引用执行第三次动作。
- 同名 owned 根歧义不动作、截断不能证明缺席、等待取消、anchor 改名源错误、关闭后的完整缺席及旧引用拒绝均有真实验收。新 `smoke:popups` 顺序运行四类夹具和真正系统声音属性查看；子集指标独立标明非完整验收。
- 系统声音窗口两轮使用已观测的 Alt+P 打开属性，以真实 owner 链确认新 HWND、读标签页、Cancel 并重新定位原设备名称；没有 Apply/OK 或设置写入。首次属性 UIA Invoke 阻塞至截止返回 unknown 的失败保留，随后另起新实例走明确的助记键路径。
- 原生菜单 UIA Invoke 曾无业务结果，成功路径显式使用 MSAA 默认动作；一次 WPF Open 定位超时的原因仍未确定。没有将这些失败称为稳定路径，详细证据及实际边界见 [EVIDENCE.md](EVIDENCE.md)。

## 0.5.12 — 2026-10-09

- 新增 Windows `computer_read_control`，共 25 工具。使用新子 HWND 目录身份，有界读取标准 SysListView32 / WinForms ListView 的指定列、行文本和选择/焦点状态，不聚焦、选择或滚动；owner-data 虚拟控件和未知类明确拒绝。
- 行、单元格、UTF-16 文本、消息与总截止独立受限，返回完整行前缀、尾行部分内容、nextRow、实际计数和来源错误。容量边界保守标 incomplete；截断代理对缩短为合法前缀，其它畸形 UTF-16 报错。末尾行数复核不提供源程序事务保证。
- 64 位 helper 按目标 32/64 位编码 LVITEMW；分配前将具名 guard 交给目标，固定 8192 字节缓冲及一个目标事件句柄。超时/取消/kill 或未确认文本时保留至目标退出，跨 helper 路径、版本和会话拒绝后续分配。ReplyMessage 可早回复，回调后继续校验长度、首个 NUL 和 UTF-16；恶意控件先写正确文本再继续使用指针的行为不能由此证明安全。
- 修复 Explorer 零尺寸 SysHeader32 导致整份子 HWND 目录失败的问题：保留零尺寸辅助 HWND，负尺寸仍拒绝，原捕获和动作边界检查保留。
- 真实 Electron、ToolRuntime 与官方 subprocess 的 32/64 位夹具验收通过，包括标准/托管类、中文与代理对、各类预算、禁用/遮挡读取、选择焦点与前台保持、延迟回调、早回复 0/777 隔离、后续分配拒绝及取消/总截止。实际系统声音应用的五行逐字匹配独立 UIA 证据，重复读取内容、选择和焦点一致；测试进程结束后完成清理。
- 实际 Explorer 桌面 owner-data 拒绝、服务窗口 Win32 access denied、声音整树 MSAA 枚举失败如实保留。增加 smoke:listview 的夹具/app 入口、25 工具 Loader 名单、提示词、原生协议与风险文档；证据与复现范围见 [EVIDENCE.md](EVIDENCE.md)。

## 0.5.11 — 2026-10-08

- 新增 Windows `computer_find_color`、`computer_ocr`、`computer_wait_visual`，共 24 工具。必填有界区域支持虚拟桌面绝对坐标或完整窗口相对坐标，固定窗口身份并每轮重读边界；screen 要求已在前台，PrintWindow 读取后台渲染，均不暗中提窗或输入。
- 独立 RGB 找色支持包含边界的逐通道容差、正向/反向逐像素扫描与独立样本上限；匹配像素数和覆盖范围分开报告。部分命中可证明出现，部分零匹配不能证明消失，像素数量不作为控件唯一性。
- 系统 Windows OCR 返回字/行、绝对字框和实际取整缩放后的图内字框，报告已安装语言与完整/截断输出；字、行文本共享字符预算。此引擎不暴露置信分数，confidence 为 null，任何 min_confidence（包括 0）明确拒绝。
- 视觉等待重新捕获固定来源，共享单调总截止、每轮剩余预算及取消；来源错误立即停止，不伪装为缺席。独立 visual_id 只标识像素观测，不能授权截图或语义动作。
- 真实 Electron、正式 ToolRuntime、官方 subprocess 和自绘 WinForms 的 24 项检查通过（原始结果含末态共 26 条记录）：方向/容差/完整计数、缩放字框、字/字符截断、定时变化、超时/失焦、完全遮挡后台读取和移动后相对区域；点击数保持零。当前真实 SketchUp 2024 的 R/空格工具切换通过，中文状态 OCR 和选择按钮高亮等待确认变化并恢复原 Select；无画布输入或模型保存。
- 27 项 Rust、14 项区域视觉 JS 测试及新产物的原生捕获/输入和 Electron 桥回归通过。中文状态仍存在误字及漏符号，OCR 完整输出不等于文字识别准确，现场工具切换不代表通用应用任务成功率。协议、复现入口及完整限制见 [EVIDENCE.md](EVIDENCE.md)。

## 0.5.10 — 2026-10-08

- 找图新增 `color_mode:"rgb"`：每个像素的三个通道都满足容差才计为匹配，保留灰度默认。灰度、RGB 和 alpha 共用逐位置扫描、覆盖、固定锚点聚类及预算核心。
- 新增 `mask_mode:"alpha"` 与包含边界的 `alpha_min`（1–255）：排除低于 cutoff 的像素，评分分母使用实际参与数量；不合成背景或作 alpha 加权。仅参与像素决定对比度，全排除或只有隐藏颜色有结构的模板明确拒绝。
- 新增单个显式 `template_scale`（0.1–4），最近邻变换且正尺寸 .5 向上；源及变换后都限制为 1,048,576 像素，零尺寸拒绝。没有自动多尺度搜索，覆盖与点击中心使用变换后尺寸。
- 原生结果明确确认颜色/遮罩/cutoff/比例，返回源和实际模板尺寸、滤波方式与参与数量；抓屏 `scale:1` 单独表示未降采样。宿主严格校验请求、尺寸、分母和位置预算，旧 helper 不能静默忽略新选项；部分零/一候选仍拒绝点击。
- 真实 Electron、生产 WindowsComputer、官方 subprocess 和 Cordis ToolRuntime 图像任务通过：同亮度颜色消歧、透明环 cutoff、显式 0.5/2 倍变换、组合模式、无效遮罩和部分覆盖拒点。实际 MouseUp 共五次，均核对应用坐标和新窗口证据；144 个 alpha 参与像素的独立屏幕读取无差异。原生捕获/输入和桥回归也通过。
- 22 项 Rust 与 12 项图像 JS 测试通过，协议与证据文档更新。半透明原色可能不同于屏幕合成色；视觉聚类和找图后的点击间隙仍不提供业务身份或事务保证。验收属于受控像素任务，宏观应用任务继续，详情见 [EVIDENCE.md](EVIDENCE.md)。

## 0.5.9 — 2026-10-08

- 修复粗筛仅保留八候选、局部精算后把候选数当成全部匹配数的问题。Windows 找图改为原分辨率、步长一像素的全位置灰度扫描，单位置只在已无法达到阈值时提前淘汰；阈值计算修正 0.9/0.95 浮点边界误拒。
- 新增 `timeout_ms` / `max_positions` 预算及 `coverage/status/visitedPositions/totalPositions/stopReason`。时间、位置或聚类资源截断明确报告 incomplete/partial；零匹配不冒充缺席，一处匹配不冒充唯一。八处展示上限不截断 `matchCount`。
- 聚类明确为按行首匹配固定锚点、半模板矩形内归最早锚点；空间索引保持有界邻域查找，部分扫描计数为完整计数下界。该规则描述视觉位置，不等于业务对象身份。
- `computer_click_image` 仅在完整覆盖且一处聚类时点击，缺少覆盖协议的旧 helper 直接拒绝。提窗失败也使受影响的旧观测失效；tolerance 统一为整数灰度亮度偏差。移除旧算法隐含的 16×16 最小模板限制，保留低对比模板拒绝，增加 1,048,576 像素模板上限。
- 新增真实 WinForms 像素、生产 WindowsComputer、官方 subprocess 和 Cordis ToolRuntime 的实际 Electron 验收。同画面旧产物漏掉远处目标并报一处，新产物完整扫描报两处；末尾匹配、真正无匹配、部分零/一处拒点击和完整唯一实际 MouseUp 一次均通过。原生输入/后台捕获及运行时桥定向回归通过；夹具明确建立遮挡前台，并只对明确 not_started 的快照变化有界重读。
- 原生搜索仍比较灰度，不提供 RGB 色相、透明掩码、模板缩放或应用业务身份；找图与输入间的界面变化仍须确认结果。新增 `smoke:images` 定向验收入口；详情见 [EVIDENCE.md](EVIDENCE.md)。

## 0.5.8 — 2026-10-08

- 新增 Windows `computer_locate`、`computer_wait`、`computer_act`，共 21 工具。1–16 级窗口/容器定位支持 name、role、automation ID、class/framework、exact/contains 与 children/subtree；每级唯一或显式 nth，歧义和预算截断分别报告，部分覆盖不证明缺失。
- 等待每轮重新解析固定 HWND/PID/标题内的全部容器和目标，读取 enabled/disabled、值/文本、选择、展开/切换与稳定边界等条件；前置、一次动作和可选后置检查共用截止。动作执行状态与后置确认分开，未知或失败动作不重放。
- 修复默认 WPF 虚拟项无法读取 runtime ID/普通属性时的 FindItem：只将明确的 ElementNotAvailable 或 `UIA_E_ELEMENTNOTAVAILABLE`（`0x80040201`）且有 VirtualizedItem 模式的结果保存为准确对象占位引用，允许 Realize 后重新观察。其它 COM 错误继续上报。Grid.GetItem 返回独立可操作的 `cell_snapshot_id`；SelectionItem 选中状态可按需读回。
- 增加真实默认 WPF、生产 worker 与 Cordis ToolRuntime 任务验收：同名消歧、整个容器替换、读回结果、后置超时仅一次动作、取消、惰性树、600 项虚拟列表、Grid 和独立 HWND 弹窗。执行期间模拟人工编辑、切窗和原控件替换，检查窗口绑定及另一个同名窗口未被操作；动作后的人工值改变会使确认失败，工具不重写该值。源 UI 条件与动作之间仍不具有事务保证。
- 修复移除后的 WPF peer 仍可读属性、保留父链并执行模式的问题：UIA 动作前有界复核父节点当前直属子列表中的准确 runtime ID，从两端只查身份，避免先读尾部目标前的全部兄弟属性。虚拟占位仍检查准确来源容器，窗口标题变化同样拒绝旧引用。
- 将定位验收加入实际 Electron 回归，维护手工 C# 编译入口和完整工具名单。旧 ToolRuntime 恢复用例按真实进度页有界续取同一代次，核对最终匹配及累计重采次数，避免依赖一次调用内完成的机器速度假设。

## 0.5.7 — 2026-10-07

- `computer_find(source:"native")` 新增可选 `max_matches`（1–20,000）：snapshot 查询达到指定匹配数后，完整复读已覆盖前缀的命中项、未命中项及顺序，再封存并分页。默认不设置时保留原有范围搜索；匹配上限与每页输出预算分开。
- 达到匹配上限报告 `coverage.source_status:"partial"` / `source_reason:"match_limit"`，最后一页仍标记未覆盖的源范围。续页继承上限，改绑、非法数值、live 查询和已缓存页过滤在执行前拒绝。前缀校验完成后立即封存，避免继续导航未搜索的尾部。
- 增加真实 UIA/MSAA 提供者验收：相邻及远端 getter 阻塞时仍在预算内取得首个目标；三个匹配分三页，封存续页零采集；前缀中未命中项变更及重排会丢弃未发布代次。真实 ToolRuntime 将 41 个匹配按默认每页 20 项读取三页，覆盖参数继承、改绑拒绝和源变化后的固定结果。

## 0.5.6 — 2026-10-07

- 修复 Electron 原生验收仅凭退出码判定通过的问题：每个测试模块及清理完成后必须交付完成标记；加载失败、提前退出或迟到的异常保留失败证据，即使外层退出码为 0 也拒绝通过。
- 增加真实 DSH ToolRuntime 与生产 WindowsComputer、Cordis 子进程服务、UIA/MSAA 提供者的组合验收：未封存代次遇到静默变化后丢弃；封存后插删、重排、改名不改变续页，同一结果及摘要、零原生采集；默认 8 条观测上限下各续读 13 页。
- 组合验收覆盖历史页继承动作消耗状态、跨 agent 证据隔离、改名目标的原生实时拒绝和新观测一次重采。源范围覆盖与输出页覆盖分别检查；固定分页的保证保持原有范围。

## 0.5.5 — 2026-10-07

- 按 pywinauto、FlaUI、AutoHotkey 和 UIA-v2 实际源码改进通用采集：UIA runtime ID 随导航缓存取得，查询未命中项只取匹配字段；命中项仍获取完整摘要、边界和模式。MSAA 未命中项省去位置与默认动作 getter；完整复读仍包含所有已覆盖项的匹配字段和树顺序。
- 新 snapshot 观测在未发布元素时遇到明确采集变化，可在原工具截止内重采最多两次，绑定失败代次的 HWND/PID/标题；返回 `capture_restarts`。显式采集游标不暗换结果，动作、未知执行状态、资源/时效错误和取消不自动重试。
- 增加真实 UIA/MSAA 静默变化恢复验收：一次变化恢复、持续变化三次尝试后有界失败、旧游标丢弃、改名后的引用拒绝动作；相同覆盖下的稀疏查询与完整摘要读取比较加入实际 Electron 回归。
- 源码对照和采用理由见 [桌面自动化实现](references/DESKTOP-AUTOMATION-IMPLEMENTATIONS.md)，测量与验收见 [EVIDENCE.md](EVIDENCE.md)。普通第三方应用无需先接入新的源协议；固定结果分页、采集变化恢复、实时动作身份与额外的源事务保证分别描述。

## 0.5.4 — 2026-10-07

- 修复采集代次只在原生分段入口检查时效的问题：慢速提供者读取在分段内跨过120秒时，原先仍可能封存并交付；现在在读取后、封存前及输出页构造前后检查时效，到期丢弃代次、游标及其注册引用。
- 采集/封存时效及固定结果池的淘汰顺序改用单调时钟，展示时间戳继续使用UTC；机器校时不会延长固定结果的有效期。
- 增加真实UIA/MSAA慢属性读取验收：仅在测试入口移动私有代次起点，保留生产120秒常量，覆盖分段内到期、旧游标不能恢复、引用清除、同进程继续采集，以及未来展示时间戳不能延长封存时效；加入实际Electron回归。
- 固定结果分页保证与源UI全树原子性继续分别报告；本次时效补修不提供源UI事务保证。

## 0.5.3 — 2026-10-07

- 修复大型动态树逐页读取活树造成的结果混用：Windows 默认 `consistency:"snapshot"`，在有界范围采集、复读全部已覆盖节点的字段与顺序后封存固定结果集，再从同一 `result_id` / SHA-256 分页。原生查询校验包含未命中节点；未完成采集/校验只返回进度及游标，不交付元素。
- UIA 属性事件与 MSAA 属性 WinEvent 纳入采集代次校验，属性版本与动作引用的结构版本分开。采集/复读发现变化时，丢弃未交付结果及其游标；封存后源 UI 的插删、重排、改名不混入后续页，续页不再调用原生提供者。
- 每个工作进程最多保留 4 个结果，每个最多覆盖 20,000 节点、保留数据估算预算 32 MB、合计 64 MB，采集及封存各有 120 秒绝对时效。范围/深度/保留预算截断返回 partial，输出页大小与采集覆盖分别报告。
- 多个原生分段共用一次工具调用的截止，包含排队与启动；接近截止返回无元素的进度页，允许继续同一代次。固定结果的首屏采集/复读成本增加，显式 `consistency:"live"` 保留逐页活树读取并报告 unverified。
- 只读续页可访问被动作影响的历史封存结果，保留原采集完成时间及动作失效状态，不能凭续页重新获得控制证据。动作仍复核实时原生目标。
- 明确区分固定结果的页间一致性与源 UI 全树原子性：`source_atomic:false` / `semanticSourceAtomic:false`；两次相符读取和事件校验不提供源程序某一瞬间的全树事务保证。这一强保证尚未实现。
- 增加真实 UIA/MSAA 万节点固定分页、采集中静默变化丢弃、查询未命中节点复核、封存后零提供者调用和旧目标动作拒绝验收，并加入实际 Electron 回归。首屏测量及成本见 [EVIDENCE.md](EVIDENCE.md)。

## 0.5.2 — 2026-10-07

- 清理操作提示中的固定语义优先级、只能用已见名称查询、逐动作报告证据编号、每次控制后无条件重新观测等要求。保留真实身份、坐标绑定、模式/只读/禁用状态、资源预算和权限检查。
- 窗口及子 HWND 身份在有效期内可复用，图像和语义状态按受影响窗口及前台变化失效。明确 `not_started` 的失败保留观测；未知执行结果使相关状态失效且不自动重试。
- 截图新增 `output:"file"`：要求 `save_to`，保存 PNG 并返回路径、尺寸、时间与哈希，不要求图像路由或附件服务，不注册坐标证据。默认图像模式保留原有校验；截图卡显示文件模式文字结果。
- Windows UIA/MSAA 增加浅层概览、已观测分支展开、直属子节点浏览和真正的续页；原生查询可检索尚未采集的部分。返回覆盖范围、预算原因及游标，部分覆盖不证明全局不存在。
- UIA 缓存只覆盖当前元素基本字段和模式可用性，完整文本与模式状态按需读取；精确条件在每个预算内节点执行原生条件查询。正常动作使用注册原生引用，不从根扫描目标。
- 将 UIA/MSAA 同步 COM 调用迁至插件管理的独立 .NET Framework 常驻进程，通过官方子进程服务运行。工作进程池默认 2、范围 1..4；截止包含排队/启动，阻塞终止后确认退出再重建，旧代次引用失效。
- 游标和引用绑定会话、HWND/PID、工作进程代次及结构版本；结构事件和有界导航锚点帮助检测变化，但多页动态树仍不是原子快照。MSAA 缺少同属性替换的代际保证。
- 屏幕外语义操作按实际模式和状态判断；提供显式 ItemContainer 项目查找与 VirtualizedItem Realize，概览不自动实例化全部虚拟项。MSAA 可选字段只将明确“未实现”记为缺失，保留其它 COM 错误。
- macOS AX、Linux AT-SPI 落实逐次节点、深度和时间预算；尚无原生分支、续页、原生查询和 Windows 常驻工作进程隔离，相关请求在执行前明确拒绝。
- 新增真实 Cordis 本地子进程服务的万节点 UIA/MSAA 验收、故意阻塞及未知动作恢复、同一提供者的新旧工作量测量，并将语义验收加入实际 Electron 运行时回归。详细测量及验证边界见 [EVIDENCE.md](EVIDENCE.md)。

## 0.5.1 — 2026-10-06

- 修复 DSH 桌面端 Electron 44 中 UIA、MSAA 和讲述人状态无法加载的问题：普通 Node 使用 `edge-js`，Electron 使用匹配其原生 ABI 的 `electron-edge-js`，保留进程内 C# 调用。
- 从实际桥依赖作用域解析 `edge-cs`，兼容 pnpm 隔离和 profile 提升布局。编译器搬迁同时保留 `edge-cs-base.dll`，内容哈希目录避免覆盖正在使用的版本。
- 原生桥加载错误现在包含桥名称、运行时、平台、架构、ABI 和原始错误；修复 `ComputerUseError` 丢失 cause、把 options 对象误当 code 的问题。
- 新增实际 Electron 可执行文件回归命令，检查桥选择、伴随程序集、讲述人只读状态、并发调用及 UIA/MSAA 控件结果。预编译 Windows .NET Framework 路径已验证不需要运行依赖的 CoreCLR 安装构建。

验证：当前桌面端可执行文件的 Electron 44.0.0 / Node 24.18.1 / ABI 149 下，UIA 8 项、MSAA 5 项和原生桥 4 项检查通过。普通 Node 兼容性及交付检查见 [EVIDENCE.md](EVIDENCE.md)。

## 0.5.0 — 2026-10-04

- 无障碍路径独立于图像：允许焦点应用或 Windows 窗口的语义快照，新增有界 `computer_read`，保留可选截图的精确绑定。文本模型可使用 UIA/MSAA 观测、读取、动作及窗口证据键盘。
- UIA 增加 TextPattern 文档/范围/选择读取、多选增删、范围值、scroll、window 与 transform 操作。新增独立 MSAA IAccessible 后端及身份复核。
- 视觉输入增加 move/hover、三击、modifier、hold/repeat、路径拖动，以及最多 256 步、显式等待/按住总和最多 10 秒的原生输入序列。全条预校验、失焦首错停止、正常结束/处理到的错误释放本次取得的输入。
- Windows 增加显式 PrintWindow 后台捕获、子 HWND 目录、限定客户区点击/滚轮消息，以及移动/缩放/最小化/最大化/恢复/关闭请求。最小化窗口现在能通过新列表发现并恢复。后台消息报告实际 `foregroundChanged`，不把投递当作应用结果确认。
- 新增 `computer_narrator`：当前登录会话的只读运行状态与 Microsoft Standard 布局固定命令，支持 Insert/CapsLock。不会启动讲述人或改设置；语音/虚拟光标输出未捕获、未实测。
- macOS AX 与 Linux AT-SPI 接好内容读取；不支持的 Windows 后端和扩展输入参数明确报错。Linux 修复把操作参数误当身份字段的问题。
- 控制提供者报错时也消耗旧证据，避免部分输入后复用过期状态。修复显式 helper 路径被全局缓存/静默回退、拖动插值超过步数预算的问题。
- 工具总数从 13 增至 18；补充工作流、能力矩阵、边界与验收记录。使用 pnpm 12 构建许可配置；打包前运行回归，并核对 release exe 与版本/源码哈希清单。

验证：55 项 JavaScript 回归（含真实 DSH ToolRuntime）、5 项 Python 纯读取/身份合同、3 项 Rust 校验测试通过；WPF UIA 8 项、WinForms MSAA 5 项及原生扩展 10 项有真机证据。macOS/Linux 原生运行时与讲述人语音验收仍未进行。

## 0.4.0

### 变更

**Windows 后端整合：PowerShell 层整体移除。**

原来 Windows 侧是三层语言混在一起：一段 C# 源码躺在 JS 模板字符串里，由每次 spawn 出来的
PowerShell 用 `Add-Type` **现场编译**，再由它转发调用；而截图和找图另有一个 Rust helper。
后果是同一件事有两份实现（提窗判据就是），改一份忘一份；每次动作都要起一个解释器进程，
它弹出的控制台还会抢走前台。现在按能力分工：

- **能直接调 Win32 的进 Rust**（`native/dsh-screen.exe`）：截图、找图、指针与键盘注入、
  窗口枚举、提窗、显示器枚举。新增 `action` / `list-windows` / `focus-window` 三个命令，
  提窗判据收敛到**一处**实现。
- **必须依赖 .NET 的走 C#，但改为进程内调用**：UI Automation 的语义树与语义动作
  放进 `src/windows-uia.cs`，由 `src/csharp.js`（通用 C# 桥，基于 edge-js）在 Node 进程内
  编译并调用 —— 不再 spawn、不再现场编译 C#。

`src/csharp.js` 是**通用桥**：只负责把任意 `.cs` 变成可调用函数（GAC 程序集路径解析、
编译缓存、并发池化、回调包 Promise），具体能力由 `.cs` 自己按 `input.kind` 分发。
它**不是**「一个 `.cs` 配一个 js」—— 那样每加一个 C# 能力都要再写一个桥文件。

**为什么池化是必须的**：一个 edge 函数实例不能并发调用，而同一个会话里可能同时有多个
工具调用在飞。池化保证它们不互相阻塞（实测并发两次 225ms；共用单实例会串行成两倍）。

**从 SAC 项目迁移的做法**：把 edge-cs 的原生 DLL 复制到纯 ASCII 路径，再用
`EDGE_CS_NATIVE` 指过去（那边的原注释：「解决 Windows 下非 ASCII 字符路径问题」）——
插件可能被装在 `C:\Users\<中文用户名>\.dsh\...` 下，不这样做每次编译都会失败。

### 移除

- `src/windows.js` 里约 540 行的 `POWER_SHELL_HELPER`（内嵌 C# + PowerShell 脚本）、
  `commandPayload` / `powershellScript` / `withPowerShellFile`，以及 `WindowsComputer.run()`。
- 对 `pwsh.exe` 的探测与依赖。**平台限定的 PowerShell 路线不再存在**，
  并由单测 `Windows backend carries no PowerShell route` 钉住。

## 0.3.0

### 新增

- **`find-image`（原生 helper 新命令）：在一屏里找一张小图，返回它的位置与相似度。**

  路由是**两层金字塔**，这是被实测逼出来的：
  - **粗筛**：降采样 4 倍 + 相似度阈值 0.7（**故意放松**）。降采样会把像素平均掉，
    逐像素对上是不可能的 —— 拿严格阈值去筛，只会一个候选都不剩。
  - **精算**：回到原分辨率，只在每个候选周围 ±4 像素的窗口里滑窗，用严格阈值。
    **只有这一层的分数进判据。**

  分数是**容差内像素数 / 总像素数**，与按键精灵、大漠插件里那个「相似度」同义 ——
  0.9 就是「九成像素对上了」。这个语义能用，恰恰因为它**不归一化**：先前用过相关系数（ZNCC），
  它先减去均值、除以标准差，于是「布局一样、内容不同」的两块区域也能拿 0.99，
  而 UI 截图里这种地方遍地都是，判据直接失效。

  其他要点：
  - **灰度化**（省掉 2/3 的比较）。
  - 模板灰度标准差低于 3 视为**纯色，当场拒绝**：纯色模板会在任何同色区域拿满分，
    那等于碰运气，而且返回的分数看起来还很自信 —— 比找不到更糟。
  - **提前退出 + 按区分度排序**：先比模板里最有辨识力的像素，不匹配数超上限就立刻换下一个位置。
  - **「找不到」是正常结果**（`found:false`、省略坐标），不是错误；错误留给「请求本身有问题」。
  - 实测：2560×1080 里找 140×140 模板 **287ms**、坐标零误差。同一任务在改成两层之前的实现下是 **158627ms**。
  - 还会回报**通过门槛的不同位置有几个**（按「距离不超过半个模板」聚类）——
    `computer_click_image` 的硬约束直接建立在这个数上。

- **三个工具把找图接到了模型手上**：`computer_screenshot` 新增 `save_to`，新增 `computer_find_image` 与 `computer_click_image`。

  - **`computer_screenshot` 的 `save_to`**：把截图写到指定路径。存下来的是**原始 PNG**，
    不是附件系统里那份给模型看的重编码副本 —— 拿副本当模板会平白掉分。
    这是三个工具串成一条链的前提：模型给不了 base64，只能给路径。
    指名窗口截图（`window_id`）同样支持它。
  - **`computer_find_image`（观测类）**：给一张模板图，回报它在哪、相似度多少、有几处。
    **找不到是正常结果**（`found:false`），不是错误。可选 `window_id`：给了就把那个窗口提到前台、
    按它此刻的实际边界搜索；这一形态会改变前台，因此算**控制类**。
  - **`computer_click_image`（控制类）**：**必须传 `window_id`**；找到、且**只找到一处**才点。
    「只找到一处」是**硬约束** —— 不止一处就**什么都不做**，把各处位置报回去，让调用方自己决定。
    刻意不做「那就取最好的那个」的降级：一个会自己拿主意去点的工具，比一个不会点的工具危险得多。
    门槛也默认更严（0.95 对 0.9）：find 看错了无非白看一眼，click 按错了就是点错东西。
    点击坐标由原生 helper 当场算出来、紧接着用掉，不存在「坐标过期」的问题。

  **唯一性的参照系是窗口内**，不是全屏：两个同型窗口并排时全屏看永远不止一处，
  而在指定窗口里就是唯一的 —— 那正是该允许点的情况。

- `computer_screenshot` 支持 `window_id`：**一步完成「把窗口提到前台 + 按它此刻的实际边界截图」**，
  所以被别的窗口盖住的窗口也能正确截到。该形态会改变前台，因此按**控制类**审批，
  而不是沿用「观测」那一档。返回值带 `window`（id / 标题），模型可见文本会写明「这张图是把该窗口提到前台换来的」。

  聚焦时只校验身份（窗口句柄 + 进程 + 标题），**不比对列出时的边界** —— 窗口被移动过不代表换了一个窗口；
  原来的做法拿列表时刻的边界做校验，会让一次本该成功的截图直接失败。边界改为在聚焦之后实时读取。

  聚焦与抓屏**在同一次原生 helper 调用内完成**（`dsh-screen.exe screenshot` 新增 `focus` 参数），刻意不拆成两步：
  宿主每 spawn 一次子进程，Windows 就会把宿主所在的控制台窗口提到前台；拆成两次调用时，
  第二次启动冒出来的控制台窗口会正好盖住刚被提到前面的目标，截回来的就是那个控制台。合并成一次后，
  弹窗只发生在进程启动那一刻，紧接着目标被提到前台把它盖住，抓到的就是目标本身（Windows 上实测通过）。

  平台支持：**Windows 可用**。macOS / Linux 的后端目前只能截取整个虚拟桌面（没有区域截图能力），
  调用会明确报错，不会静默交回一张整屏图。

### 修复

- **`computer_screenshot` 的 `display_id` 从加入起就没工作过**：两套显示器枚举各说各话 ——
  `computer_status` 走的是 PowerShell 分支（`src/windows.js` 的 `{ kind: 'displays' }`），返回
  `\\.\DISPLAY1`（Windows 标准设备名）；而截图走的原生 helper 从 HMONITOR **合成**了一个 id
  （`\\?\DISPLAY<handle>`），`find_display()` 又是精确匹配 —— 于是从 `computer_status` 拿到的
  id 传过去，**必然**报「找不到显示器」。之前的验证只覆盖了 `region` + `scale`
  （它们和 `display_id` 走同一条 payload 通道，所以那条通道"看起来"是通的），把这条路径漏了。
  现在原生改用 `MONITORINFOEXW.szDevice`，id 直接就是 `\\.\DISPLAY1`，与另一套天然一致。
  实测：`display_id="\\.\DISPLAY1"` → 1920×1080，`sourceBounds = {-1920, 0, 1920, 1080}`。

- **`computer_screenshot` 的整条工具消息在 GUI 里不显示**：`src/client.js` 全程用大写 `React.*`，
  而该模块只定义了 `let react = require("react")`，渲染时抛 `ReferenceError`，整张工具卡连带整条消息一起消失。
  现已统一为小写并加注释（`3f5da40` 引入）。
- **原生 helper 收到的 payload 恒为空，`region` / `display_id` / `scale` 三个参数全部静默失效**：
  `src/runner.js` 把批式 stdin 写成 `{ text }`，而 DSH 的 `SubprocessStdinMode` 是
  `'ignore' | 'pipe' | { readonly data: string }`，实现侧执行 `stdin.end(stdinMode.data)` ——
  `data` 是 `undefined`，管道被立刻关闭。此前「整屏截图一直正常」只是因为整屏本来就是默认行为
  （同样是 `3f5da40` 引入）。已补 `test/runner.test.js` 断言 `stdio.stdin` 形态的回归测试。

## 0.2.0

### 新增：区域截图与原生截图 helper

- `computer_screenshot` 支持 **截取屏幕的一部分**，不再只能整屏／整显示器：
  - `x` / `y` / `width` / `height` —— 捕获区域（虚拟桌面坐标，允许负值）
  - `scale` —— 裁剪后缩放倍数，用于放大看清小字
  - 越界区域自动裁到虚拟桌面内，并**如实回报真实边界**
- Windows 截图改为调用原生 helper `native/dsh-screen.exe`（Rust + Win32 GDI，单文件约 390KB）：
  - 不必再为每次截图付一次 `powershell.exe` 的启动代价
  - 屏幕几何与像素读取进入强类型代码，消除「脚本层属性取到 null 却继续运算」这类问题
  - 移除旧的 PowerShell 截图脚本分支（**不做回退**：两条实现都要维护、测试覆盖不到，
    用户也不知道自己实际在用哪个）

### 内部

- `runner.run()` 支持向子进程写入 stdin（原生 helper 用它传请求参数）
- 新增 `native/README.md`：协议说明、`sourceBounds` 不变量、两个 GDI 坑、调试与构建方式

### 需要留意的行为变化

- **找不到原生 helper 时截图会直接报错**，并提示构建方式；不再静默回退。
  从源码安装的用户需要先 `cd native && cargo build --release`。
- 抓屏 ROP 改为纯 `SRCCOPY`（去掉 `CAPTUREBLT`）：修掉了部分 GPU/DWM 组合下
  **整张截图全黑**的问题。代价是极少数分层窗口（个别悬浮窗／输入法候选框）
  可能不出现在截图里。

## 0.1.0

- 初始版本：Windows / macOS / Linux 三平台桌面自动化的独立 Cordis 插件集合。
- 观察类工具：`computer_screenshot`、`computer_status`、`computer_windows`、
  `computer_accessibility`、`computer_find`。
- 控制类工具：`computer_click`、`computer_drag`、`computer_scroll`、`computer_type`、
  `computer_key`、`computer_element`。
