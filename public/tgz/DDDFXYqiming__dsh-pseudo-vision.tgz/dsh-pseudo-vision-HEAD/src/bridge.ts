/**
 * Image→text bridge.
 *
 * When a turn carries an `image` block AND the routed model does not declare
 * image input, swap that block for a structured text block built from the
 * four vision tools (ocr / color-stats / pixel-scan / meta). This is the
 * exact local evidence pipeline used to make text-only DeepSeek models process images
 * by hand with bash + Python; here it is fixed and reproducible.
 *
 * The bridge never modifies image bytes; the model still receives pure text.
 * OCR now runs on a preprocessed copy (budget resize + dark-mode inversion +
 * greyscale/contrast/sharpen + white border, see vision/preprocess.ts), while
 * colour analysis keeps using the ORIGINAL bytes. The only persistence side
 * effect is an on-disk cache keyed by the image hash, resolved budget, and
 * complete OCR pipeline version/parameters, so different preprocessing choices
 * never share a stale result.
 */

import { createHash } from 'node:crypto';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { join } from 'node:path';

import sharp from 'sharp';

import {
    decodeAndColorStats,
    formatColorStatsBlock,
} from './vision/color-stats.js';
import { readMeta, formatMetaBlock } from './vision/meta.js';
import {
    formatDigitFixBlock,
    formatOcrBlock,
    formatOcrRetryBlock,
    ocrWithLowConfidenceRetry,
} from './vision/ocr.js';
import {
    formatUniversalScanBlock,
    pixelScanUniversal,
} from './vision/pixel-scan.js';
import { chunkedOcr, type ChunkOcrResult } from './vision/chunk-ocr.js';
import {
    BUDGETS,
    isDarkModeFromStats,
    preprocessForOcr,
} from './vision/preprocess.js';

export interface ImageBlockInput {
    attachment: {
        attachmentId: string;
        mediaType: string;
        bytes?: number;
    };
}

export interface ResolvedImage {
    attachmentId: string;
    bytes: Buffer;
    mediaType: string;
    sha256: string;
}

export interface BridgeOptions {
    /** Cache root (per profile). */
    cacheDir: string;
    /** Force re-computation even when a cached result exists. */
    bypassCache?: boolean;
    /** OCR 分辨率预算：'auto' | 'small' | 'normal' | 'large' | 'mega'（缺省 auto）。 */
    ocrBudget?: string;
    /** Tesseract language pack, defaulting to chi_sim+eng. */
    langs?: string;
    /** Skip budget resize/upscale while retaining OCR enhancement. */
    ocrNoResize?: boolean;
}

/** 缓存里存的元数据；budget/尺寸/块数供调用方追溯实际用了什么。 */
interface CacheEntry {
    text: string;
    budget: string;
    width: number;
    height: number;
    chunkCount: number;
    retryCount: number;
    ocrBytes?: number;
}

/** 原图高度超过该值走分块 OCR。 */
const CHUNK_HEIGHT_THRESHOLD = 3000;
const CHUNK_TARGET_HEIGHT = 2000;
const CHUNK_OVERLAP = 100;
const OCR_CONFIDENCE_THRESHOLD = 60;
// 2026-08-26: 3→8 regions (icon noise lines no longer exhaust the budget —
// lowConfidenceRegions now ranks text-like lines first) and 2→3× upscale
// (small CJK UI glyphs need ≥ ~35-40px height per tesseract best practice).
const OCR_MAX_RETRY_REGIONS = 8;
const OCR_RETRY_UPSCALE = 3;

/** 'auto' 预算下超过该像素数切到 large（>210 万像素）。 */
const AUTO_LARGE_THRESHOLD = 2_100_000;

/**
 * 证据文本封顶（v0.5.4）：本地管线允许 16M 像素的图，但 OCR 全文可能
 * 达几万字把上下文撑爆。返回给模型的证据统一截断到约 8K tokens
 * （32K 字符，按 CJK≈1 token/字保守估），并显式标注被截断。
 */
export const MAX_EVIDENCE_CHARS = 32_000;

let evidenceCharCap = MAX_EVIDENCE_CHARS;

/** Config entry point: lower/raise the evidence cap (non-positive keeps the default). */
export function setEvidenceCharCap(maxChars: number): void {
    if (Number.isFinite(maxChars) && maxChars > 0) evidenceCharCap = maxChars;
}

export function capEvidence(text: string): string {
    if (text.length <= evidenceCharCap) return text;
    return (
        text.slice(0, evidenceCharCap)
        + `\n[证据已截断：${text.length} 字符 > ${evidenceCharCap}（约 ${Math.ceil(text.length / 4)} tokens），仅保留前 ${evidenceCharCap} 字符]`
    );
}

/**
 * Cache namespace for every OCR-affecting knob. Keep old cache files on disk,
 * but never let a result made by the old fixed pipeline satisfy a new request.
 * v2: universal row+col pixel scan (non-background buckets, focusX) joined
 * the evidence set, so results produced by the red-only scan must not be
 * served from cache.
 * v3: digit verification pass (whitelist re-OCR of IP/URL/port tokens)
 * corrects OCR line text, so pre-digit-pass cache entries are stale.
 * v4 (2026-08-26): CJK post-process (space merge + leading icon strip),
 * retry replace-main (higher-confidence rereads overwrite the first pass),
 * text-like line priority in low-confidence regions, PSM.SINGLE_BLOCK retry
 * crops, sharpen 0.8→0.3 + median(3) after normalize, maxRegions 3→8 and
 * upscale 2→3. Bump again whenever any of these knobs changes.
 */
export const OCR_CACHE_PIPELINE =
    'ocr-v5-min224-factor28-up800-border10-dark-condmedian-enhance-chunk3000-2000-100-retry60-8x3-cjkfix-replacemain-textfirst-psm6num-scan-rowcol-v1-digitverify-v1';

export function buildVisionCacheKey(
    sha256: string,
    budget: string,
    params: { langs?: string; noResize?: boolean } = {},
): string {
    const langs = (params.langs ?? 'chi_sim+eng').replace(/[^a-zA-Z0-9+_-]/g, '_');
    const resize = params.noResize === true ? 'original' : 'budget';
    return `${sha256}-${budget}-${resize}-${langs}-${OCR_CACHE_PIPELINE}.json`;
}

function resolveOcrBudget(
    budget: string | undefined,
    width: number,
    height: number,
): string {
    if (budget !== undefined && budget !== 'auto' && Object.hasOwn(BUDGETS, budget)) {
        return budget;
    }
    // auto：小图/常规图用 normal（小图会被放大），超大图用 large。
    return width * height > AUTO_LARGE_THRESHOLD ? 'large' : 'normal';
}

function formatChunkedOcrBlock(result: ChunkOcrResult): string {
    if (result.chunks.length === 0) {
        return `[OCR 整图]\n${result.fullText}`;
    }
    return `[OCR 分块 ${result.chunkCount}]\n${result.fullText}`;
}

/**
 * Convert an image buffer into the structured text block the text-only model
 * will actually consume. Returns a single string with all four blocks
 * concatenated; the caller decides how to splice it into the message stream.
 */
export async function imageToText(
    image: ResolvedImage,
    options: BridgeOptions,
): Promise<string> {
    const origMeta = await sharp(image.bytes).metadata();
    const origWidth = origMeta.width ?? 1;
    const origHeight = origMeta.height ?? 1;
    const budget = resolveOcrBudget(options.ocrBudget, origWidth, origHeight);
    const langs = options.langs ?? 'chi_sim+eng';

    const cacheKey = buildVisionCacheKey(image.sha256, budget, {
        langs,
        noResize: options.ocrNoResize,
    });
    const cachePath = join(options.cacheDir, cacheKey);

    if (!options.bypassCache) {
        try {
            const cached = JSON.parse(await readFile(cachePath, 'utf-8')) as CacheEntry;
            // 缓存命中同样过封顶（旧缓存条目可能由封顶前的管线产出）。
            return capEvidence(cached.text);
        } catch {
            // fall through to recompute
        }
    }

    // 颜色统计 / 像素扫描 / 元信息：颜色与扫描共用【同一次 512px 降采样】，
    // 保证两阶段看到的是同一张图；元信息仍读原图字节。
    // 背景桶 = 颜色统计中 share >= 30% 的桶，通用扫描对其使用 [threshold, cap)
    // 区间上报，纯背景带被抑制而交替条纹仍可见。
    const [decoded, meta] = await Promise.all([
        decodeAndColorStats(image.bytes).catch((error) => {
            console.error('[dsh-pseudo-vision] color decode failed:', error);
            return null;
        }),
        readMeta(image.bytes).catch((error) => {
            console.error('[dsh-pseudo-vision] meta failed:', error);
            return null;
        }),
    ]);

    let colors: import('./vision/color-stats.js').ColorStats | null = null;
    let scan: import('./vision/pixel-scan.js').UniversalScanResult | null = null;
    if (decoded !== null) {
        colors = decoded.stats;
        const backgroundBuckets = decoded.stats.buckets
            .filter((bucket) => bucket.share >= 0.30)
            .map((bucket) => bucket.name);
        scan = await pixelScanUniversal(decoded.raw, {
            backgroundBuckets,
            threshold: 0.15,
            backgroundCap: 0.9,
            maxHitsPerBucket: 5,
        }).catch((error) => {
            console.error('[dsh-pseudo-vision] pixel scan failed:', error);
            return null;
        });
    }

    const darkMode = colors !== null && isDarkModeFromStats(colors);
    const focusY = scan?.hits
        .filter((hit) => hit.axis === 'row')
        .map((hit) => hit.pos) ?? [];
    const focusX = scan?.hits
        .filter((hit) => hit.axis === 'col')
        .map((hit) => hit.pos) ?? [];

    let ocrBlock: string | null = null;
    let ocrError: string | null = null;
    let chunkCount = 0;
    let retryCount = 0;
    let ocrWidth = origWidth;
    let ocrHeight = origHeight;
    let ocrBytes = 0;
    let preprocessSummary = `${origWidth}×${origHeight}（原图分块）`;

    if (origHeight > CHUNK_HEIGHT_THRESHOLD) {
        // Important: crop the ORIGINAL tall image first. Resizing the whole
        // screenshot to a visual-token budget would erase the small text that
        // chunking is meant to preserve.
        const chunked = await chunkedOcr(image.bytes, {
            targetHeight: CHUNK_TARGET_HEIGHT,
            overlap: CHUNK_OVERLAP,
            langs,
            focusY,
            focusX,
            confidenceThreshold: OCR_CONFIDENCE_THRESHOLD,
            maxRetryRegions: OCR_MAX_RETRY_REGIONS,
            preprocessChunk: async (bytes) => (
                await preprocessForOcr(bytes, budget, darkMode, options.ocrNoResize)
            ).bytes,
        }).catch((error) => {
            console.error('[dsh-pseudo-vision] chunked OCR failed:', error);
            // 失败必须可见：证据块会带上失败原因，模型不会误判"图里没文字"。
            ocrError = String((error as Error)?.message ?? error);
            return null;
        });
        if (chunked !== null) {
            chunkCount = chunked.chunkCount;
            retryCount = chunked.retryCount;
            ocrBlock = [
                formatChunkedOcrBlock(chunked),
                formatDigitFixBlock(chunked.digitFixes),
            ].filter((block) => block.length > 0).join('\n');
            preprocessSummary = `${origWidth}×${origHeight}（每块预算预处理）`;
        }
    } else {
        // Normal images use the complete budget pipeline once, then crop and
        // retry only low-confidence OCR lines at 2× resolution.
        const pre = await preprocessForOcr(
            image.bytes,
            budget,
            darkMode,
            options.ocrNoResize,
        );
        ocrWidth = pre.width;
        ocrHeight = pre.height;
        ocrBytes = pre.bytes.length;
        preprocessSummary = `${pre.width}×${pre.height} ${pre.bytes.length}B`;
        const ocr = await ocrWithLowConfidenceRetry(
            pre.bytes,
            langs,
            {
                threshold: OCR_CONFIDENCE_THRESHOLD,
                maxRegions: OCR_MAX_RETRY_REGIONS,
                upscale: OCR_RETRY_UPSCALE,
                focusY,
                focusX,
            },
        ).catch((error) => {
            console.error('[dsh-pseudo-vision] OCR failed:', error);
            // 失败必须可见：证据块会带上失败原因，模型不会误判"图里没文字"。
            ocrError = String((error as Error)?.message ?? error);
            return null;
        });
        if (ocr !== null) {
            retryCount = ocr.retries.length;
            const retryBlock = formatOcrRetryBlock(ocr);
            ocrBlock = [
                formatOcrBlock(ocr.initial),
                retryBlock,
                formatDigitFixBlock(ocr.digitFixes),
            ]
                .filter((block) => block.length > 0)
                .join('\n');
        }
    }

    if (ocrBlock === null && ocrError !== null) {
        ocrBlock = `[OCR 失败: ${ocrError}]`;
    }

    const enhancement = darkMode ? '灰度+反色' : '灰度';
    const blocks: string[] = [];
    blocks.push(
        `[dsh-pseudo-vision] sha256=${image.sha256.slice(0, 12)} budget=${budget} `
        + `原图:${image.mediaType} ${image.bytes.length}B 预处理:${enhancement} ${preprocessSummary}`,
    );
    if (ocrBlock !== null) blocks.push(ocrBlock);
    if (colors !== null) blocks.push(formatColorStatsBlock(colors));
    if (scan !== null) blocks.push(formatUniversalScanBlock(scan));
    if (meta !== null) blocks.push(formatMetaBlock(meta));
    const text = capEvidence(blocks.join('\n\n'));

    await mkdir(options.cacheDir, { recursive: true }).catch(() => undefined);
    await writeFile(
        cachePath,
        JSON.stringify({
            text,
            budget,
            width: ocrWidth,
            height: ocrHeight,
            chunkCount,
            retryCount,
            ocrBytes,
            scanRowHits: scan?.rowHitCount ?? 0,
            scanColHits: scan?.colHitCount ?? 0,
        }),
        'utf-8',
    ).catch(() => undefined);

    return text;
}

/** Options for the compact (history-tier) evidence path. */
export interface CompactVisionOptions {
    /**
     * Absolute host path of the normalized attachment (from
     * `AttachmentStore.imageHostPath`), used for the fold pointer line so the
     * agent can re-read the full OCR with `vision_ocr` on demand.
     */
    hostPath?: string;
}

/**
 * Compact evidence for history-turn images: header + metadata + colour
 * statistics + pixel scan, and NO tesseract pass. Sharp-only work costs tens
 * of milliseconds and a few hundred characters, so dozens of old images stay
 * negligible while the OCR body remains re-fetchable through the pointer.
 */
export async function imageToCompactText(
    image: ResolvedImage,
    options: CompactVisionOptions = {},
): Promise<string> {
    const [decoded, meta] = await Promise.all([
        decodeAndColorStats(image.bytes).catch((error) => {
            console.error('[dsh-pseudo-vision] compact color decode failed:', error);
            return null;
        }),
        readMeta(image.bytes).catch((error) => {
            console.error('[dsh-pseudo-vision] compact meta failed:', error);
            return null;
        }),
    ]);

    const blocks: string[] = [];
    blocks.push(
        `[dsh-pseudo-vision·紧凑] sha256=${image.sha256.slice(0, 12)} `
        + `原图:${image.mediaType} ${image.bytes.length}B（历史轮次，OCR 已折叠）`,
    );
    if (options.hostPath !== undefined && options.hostPath !== '') {
        blocks.push(`[OCR 已折叠] 需要这张图的文字内容时，调用 vision_ocr(file_path="${options.hostPath}") 回读全图。`);
    } else {
        blocks.push('[OCR 已折叠] 需要这张图的文字内容时，请请用户重新发送该图片。');
    }

    if (decoded !== null) {
        blocks.push(formatColorStatsBlock(decoded.stats));
        const backgroundBuckets = decoded.stats.buckets
            .filter((bucket) => bucket.share >= 0.30)
            .map((bucket) => bucket.name);
        const scan = await pixelScanUniversal(decoded.raw, {
            backgroundBuckets,
            threshold: 0.15,
            backgroundCap: 0.9,
            maxHitsPerBucket: 5,
        }).catch((error) => {
            console.error('[dsh-pseudo-vision] compact scan failed:', error);
            return null;
        });
        if (scan !== null) blocks.push(formatUniversalScanBlock(scan));
    }
    if (meta !== null) blocks.push(formatMetaBlock(meta));
    return blocks.join('\n\n');
}

/**
 * Compute the sha256 of a buffer; reused by callers that want to dedupe
 * images across the bridge before doing any heavy work.
 */
export function sha256Of(bytes: Buffer): string {
    return createHash('sha256').update(bytes).digest('hex');
}
