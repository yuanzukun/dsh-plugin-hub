/**
 * Tests for invalidateProjectCache skip logic: without a known server the
 * probe must not fire; with OCTIE_SERVER_URL it must fire.
 */

import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest';
import { mkdirSync, rmSync, writeFileSync, existsSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { v4 as uuidv4 } from 'uuid';

let homedirTarget = '';

vi.doMock('node:os', async () => {
  const actual = await vi.importActual<typeof import('node:os')>('node:os');
  return { ...actual, homedir: () => homedirTarget };
});

describe('invalidateProjectCache', () => {
  let invalidateProjectCache: typeof import('../../../src/service/engine.js').invalidateProjectCache;
  let fetchCalls: number;
  const realFetch = globalThis.fetch;

  beforeAll(async () => {
    vi.resetModules();
    homedirTarget = join(tmpdir(), `octie-cache-home-${uuidv4()}`);
    mkdirSync(homedirTarget, { recursive: true });
    invalidateProjectCache = (await import('../../src/service/engine.js')).invalidateProjectCache;
  });

  afterAll(() => {
    try { rmSync(homedirTarget, { recursive: true, force: true }); } catch { /* ignore */ }
  });

  beforeEach(() => {
    fetchCalls = 0;
    globalThis.fetch = (async () => {
      fetchCalls += 1;
      return new Response('ok', { status: 200 });
    }) as typeof fetch;
    delete process.env.OCTIE_SERVER_URL;
    delete process.env.OCTIE_CACHE_INVALIDATE_TIMEOUT_MS;
  });

  afterEach(() => {
    globalThis.fetch = realFetch;
    delete process.env.OCTIE_SERVER_URL;
  });

  it('skips the probe when no server has ever run', async () => {
    await invalidateProjectCache('C:/fake/project');
    expect(fetchCalls).toBe(0);
  });

  it('fires the probe when OCTIE_SERVER_URL is set', async () => {
    process.env.OCTIE_SERVER_URL = 'http://localhost:3999';
    await invalidateProjectCache('C:/fake/project');
    expect(fetchCalls).toBe(1);
  });

  it('fires the probe when the server-url file exists', async () => {
    mkdirSync(join(homedirTarget, '.octie'), { recursive: true });
    writeFileSync(join(homedirTarget, '.octie', '.last-server-url'), 'http://localhost:3999\n');
    await invalidateProjectCache('C:/fake/project');
    expect(fetchCalls).toBe(1);
  });
});

describe('invalidateProjectCache failure modes', () => {
  let invalidateProjectCache: typeof import('../../../src/service/engine.js').invalidateProjectCache;
  const realFetch = globalThis.fetch;
  const serverUrlFile = () => join(homedirTarget, '.octie', '.last-server-url');
  let warnCalls: string[];

  beforeAll(async () => {
    vi.resetModules();
    invalidateProjectCache = (await import('../../src/service/engine.js')).invalidateProjectCache;
  });

  beforeEach(() => {
    warnCalls = [];
    vi.spyOn(console, 'warn').mockImplementation((msg?: unknown) => { warnCalls.push(String(msg)); });
    delete process.env.OCTIE_SERVER_URL;
    delete process.env.OCTIE_CACHE_INVALIDATE_TIMEOUT_MS;
    mkdirSync(join(homedirTarget, '.octie'), { recursive: true });
    writeFileSync(serverUrlFile(), 'http://localhost:3999\n');
  });

  afterEach(() => {
    globalThis.fetch = realFetch;
    vi.restoreAllMocks();
    delete process.env.OCTIE_SERVER_URL;
  });

  const rejectsWith = (err: unknown) => {
    globalThis.fetch = (async () => { throw err; }) as typeof fetch;
  };

  it('connection-refused skips silently AND deletes the stale server-url file', async () => {
    rejectsWith(new TypeError('fetch failed', { cause: { code: 'ECONNREFUSED' } }));
    await invalidateProjectCache('C:/fake/project');
    expect(warnCalls).toHaveLength(0);
    expect(existsSync(serverUrlFile())).toBe(false);
  });

  it('timeout skips silently and keeps the file (server may be busy, not gone)', async () => {
    const err = new Error('timed out'); err.name = 'TimeoutError';
    rejectsWith(err);
    await invalidateProjectCache('C:/fake/project');
    expect(warnCalls).toHaveLength(0);
    expect(existsSync(serverUrlFile())).toBe(true);
  });

  it('env-sourced URL: connection-refused is silent but the file is NOT deleted', async () => {
    process.env.OCTIE_SERVER_URL = 'http://localhost:3999';
    rejectsWith(new TypeError('fetch failed', { cause: { code: 'ECONNREFUSED' } }));
    await invalidateProjectCache('C:/fake/project');
    expect(warnCalls).toHaveLength(0);
    expect(existsSync(serverUrlFile())).toBe(true);
  });

  it('a live server answering non-OK still warns with the status code', async () => {
    globalThis.fetch = (async () => new Response('nope', { status: 500, statusText: 'Server Error' })) as typeof fetch;
    await invalidateProjectCache('C:/fake/project');
    expect(warnCalls.some(m => m.includes('500'))).toBe(true);
  });

  it('unexpected (non-network) errors still warn', async () => {
    rejectsWith(new Error('boom'));
    await invalidateProjectCache('C:/fake/project');
    expect(warnCalls.some(m => m.includes('boom'))).toBe(true);
  });

  afterAll(() => {
    // Unmock only after BOTH describes have imported — unmocking earlier makes
    // re-imported engine bind the REAL homedir and hit the real registry files
    vi.doUnmock('node:os');
    try { rmSync(homedirTarget, { recursive: true, force: true }); } catch { /* ignore */ }
  });
});
