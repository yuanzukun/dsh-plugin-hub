/**
 * Shared constants and wire types for dsh-router.
 *
 * Pure values — no framework imports — so the host (tsdown ESM) and the
 * client (vite CJS browser bundle) can both inline them safely.
 */

/** The sidebar entry / panel dataset attribute family name. */
export const ROUTER_ENTRY_SELECTOR = '[data-dsh-router-entry]'

/** The center-column takeover panel attribute. */
export const ROUTER_VIEW_SELECTOR = '[data-dsh-router-view]'

/** Active-state attribute on <html> that shows the panel. */
export const ROUTER_ACTIVE_ATTR = 'data-dsh-router-active'

/** The panel's visible title (also the sidebar entry label). */
export const ROUTER_TITLE = '路由'

/** Same-origin API base the client panel fetches (host half serves it). */
export const ROUTER_API_BASE = '/router/api'

/** One account row from `/router/api/status`. */
export interface RouterAccount {
  uid: string
  nickname?: string
  credits: number
  /**
   * 插件解读上游信号后的语义状态（`quota` = 额度/积分用完，`session_dead` = 凭证失效）。
   * 核心选号会跳过这些号，所以面板必须显示出来——否则界面写着「健康」，而路由
   * 永远不选它，用户无从知道为什么。
   */
  state?: string
  cooling: boolean
  until?: string
  reason?: string
  err_count?: number
  /** 所属供应商 id。 */
  supplier?: string
}

/** `/router/api/status` response. */
export interface RouterStatusResponse {
  ok: boolean
  error?: string
  accounts?: RouterAccount[]
}

/** `/router/api/models` response. */
export interface RouterModelsResponse {
  ok: boolean
  error?: string
  models?: Array<{ id: string; context_length?: number }>
}

/** 一键签到：单个供应商的汇总结果（`/suppliers/:id/checkin` 的响应体）。 */
export interface RouterCheckinResponse {
  ok: boolean
  error?: string
  total: number
  /** 真正 claim 成功的链接数。 */
  succeeded: number
  /** 今日已签到的链接数（幂等成功）。 */
  already: number
  /** 失败/未开放的链接数。 */
  failed: number
  results?: Array<{ uid: string; ok: boolean; status?: string; message?: string }>
}

/** `/router/api/health` response. */
export interface RouterHealthResponse {
  ok: boolean
  /** 宿主 DSH 版本（读不到为空串）。 */
  hostVersion?: string
  /** 「最近命中」徽章是否受支持（宿主 >= 0.1.7 才有 composer.dock 正确位置）。 */
  lastHitDock?: boolean
  suppliers?: Array<{
    id: string
    name: string
    /** 图标（URL 或 SVG data URI）。 */
    icon?: string
    /** 「添加 API key」弹窗提示文案（缺省前端用通用文案）。 */
    apiKeyHint?: string
    /** 面板能力集合（登录/签到/连接池/模型管理等，按存在性）。 */
    capabilities?: string[]
    /** 来源：内置 / 用户目录 / 外部插件。 */
    source?: 'builtin' | 'user' | 'external'
    /**
     * 供应商开关（是否参与路由）。**关掉的仍出现在这个列表里** —— 否则关掉之后
     * 就没有可指的对象、再也开不回来。缺省按开启读（老版本核心没有这个字段）。
     */
    enabled?: boolean
  }>
  error?: string
}

/** 组合。models = 该组合命中的模型列表（裸模型 id，展示时动态拼前缀）。
 *  路由时作为降级链按序尝试，无策略字段。 */
export interface RouterCombo {
  id: string
  name: string
  models: string[]
}

/** `/router/api/combos` response. */
export interface RouterCombosResponse {
  ok: boolean
  error?: string
  combos?: RouterCombo[]
  /** 可用模型（按供应商分组，仅启用），面板加模型用。 */
  groups?: RouterComboSupplierGroup[]
  /** 供应商前缀信息（组合模型全名 = alias/id，展示时动态拼接）。 */
  aliases?: RouterComboAlias[]
}

/** 组合页供应商前缀信息。 */
export interface RouterComboAlias {
  id: string
  name: string
  alias: string
}

/** 组合页可用模型分组（一个供应商一组）。 */
export interface RouterComboSupplierGroup {
  supplier: { id: string; name: string; alias: string }
  models: RouterSupplierModel[]
}

/** 库内一条 key（列表含完整 key，客户端脱敏显示）。 */
export interface RouterKey {
  id: string
  name: string
  key: string
  masked: string
  isActive: boolean
  createdAt: string
}

/** `/router/api/keys` response. */
export interface RouterKeysResponse {
  ok: boolean
  error?: string
  keys?: RouterKey[]
}

/** `/router/api/settings` response. */
export interface RouterSettingsResponse {
  ok: boolean
  error?: string
  requireApiKey?: boolean
}

/** 一条扩展器（`/router/api/ext`）。 */
export interface RouterExtItem {
  id: string
  name: string
  description?: string
  /** 卡片/详情图标 logo URL（可选）。 */
  icon?: string
  /** 是否启用改写（面板开关）。 */
  enabled?: boolean
  /** 运行时是否就绪（如 RTK 二进制是否可用）。 */
  ready?: boolean
  /** 一句话状态说明（如「本机未装 rtk」）。 */
  detail?: string
  /**
   * 来源：随核心分发的内置扩展标 `builtin`，独立安装的不标（= plugin）。
   *
   * 插件页那个自绘的「路由组件」节据此**只列独立安装的**：内置的已经在原生
   * 「包含的组件」里占一行了，两处都列就是同一个东西显示两遍（与内置供应商同理）。
   */
  source?: 'builtin'
  /**
   * 扩展自带的子开关（如准则的每一条）。**由扩展自报**，核心只搬运。
   *
   * ⚠️ 与 `enabled`（总开关）不同：子开关**不改变扩展是否被加载**，只改它
   *   自己的行为。总开关关时这些子开关一并失效（面板上禁用，不隐藏）。
   */
  controls?: ExtControlItem[]
}

/** `/router/api/ext` 里的一条子开关（与 `router.ext` 契约的 `ExtControl` 对应）。 */
export interface ExtControlItem {
  /** 稳定 id（持久化键；改名会丢用户已保存的选择）。 */
  id: string
  title: string
  /** 当前是否开启（扩展自算：默认值 + 用户已存选择）。 */
  on: boolean
  /** 一句话说明（面板副行，可选）。 */
  detail?: string
  /** 原文（面板点开即可读到；不给出就是在盲切，见 `ExtControl.body`）。 */
  body?: string
  /** 文本可编辑（缺省 = 只读；见 `ExtControl.editable`）。 */
  editable?: boolean
  /**
   * 分组名（可选；缺省 = 无组）—— 详情页按它分节渲染，组间插组标题行；
   * 无组照旧平铺（见 `ExtControl.group`）。
   */
  group?: string
  /**
   * 参与拖动排序（可选；缺省 = 参与）—— `false` 的条目不给拖把手
   * （见 `ExtControl.sortable`）。⚠️ 服务端**带值透传**，`false` 也会收到；
   * 判断必须写 `sortable !== false`，`!sortable` 会把缺省（参与）当不参与。
   */
  sortable?: boolean
  /**
   * 自建条目（可删）还是内置（不可删、只有开关与还原）。
   *
   * ⚠️ **必填，不给可选**（2026-09-30 实测踩过）：曾声明成 `custom?: boolean`，
   *   而服务端只在 `custom === true` 时才带这个字段 ⇒ 内置条目拿到的是
   *   `undefined`，面板判 `c.custom === true` 为假，**恰好是对的** ——
   *   但那条正确性建立在"缺省恰好等于 false"上，改任何一边的默认值都会翻转。
   *   ⇒ 让服务端**总是**给显式布尔，两边不必猜。
   */
  custom: boolean
  /** 文本被改过（决定「还原」是否可点）。必填，理由同 `custom`。 */
  overridden: boolean
}

/** `/router/api/ext` response（扩展插件列表 + 开关）。 */
export interface RouterExtResponse {
  ok: boolean
  error?: string
  enhancers?: RouterExtItem[]
}

/** 供应商模型（含启用状态）。 */
export interface RouterSupplierModel {
  id: string
  /** 可读名（上游写的，只用于显示；缺省 = id）。见 `ModelInfo.name`。 */
  name?: string
  context_length?: number
  enabled: boolean
  /** 是否为自定义（手动添加 / 拉取）模型，可删除。 */
  custom?: boolean
}

/** `/router/api/suppliers/:id/models` response. */
export interface RouterSupplierModelsResponse {
  ok: boolean
  error?: string
  /** 供应商前缀（模型全名 = alias/id）。 */
  alias?: string
  models?: RouterSupplierModel[]
}

/** `/router/api/suppliers/:id/login` response. */
export interface RouterLoginResponse {
  ok: boolean
  error?: string
  loginUrl?: string
}

/* ---------------- 概览看板（用量统计） ---------------- */

/** 面板周期。 */
export type RouterPeriod = 'today' | '24h' | '7d' | '30d'

/** 一条请求明细（面板「最近请求」）。 */
export interface RouterUsageRecord {
  ts: number
  supplier: string
  model: string
  /** 客户端原始请求的 model（组合场景下就是组合名）。 */
  requested: string
  ok: boolean
  promptTokens: number
  completionTokens: number
  cachedTokens: number
  /** 输入是估算的（上游没发 usage）。 */
  inputEstimated: boolean
  /** 输出是估算的。 */
  outputEstimated: boolean
  durationMs: number
  /** 首字节延迟（ms）；非流式为 0。 */
  ttfbMs: number
  /**
   * 连接名（uid → 显示别名，后端解析好）。空串 = 无连接（失败/未服务）。
   * 「最近请求」的「连接」列用它，而不是 supplier。
   */
  connection?: string
  /** 实际服务的连接 uid（成功且有账号时）。 */
  uid?: string
  error?: string
}

/** Top 榜一行。 */
export interface RouterRankRow {
  name: string
  requests: number
  ok: number
  failed: number
  promptTokens: number
  completionTokens: number
  lastTs: number
}

/** `/router/api/stats` response. */
export interface RouterStatsResponse {
  ok: boolean
  error?: string
  period?: RouterPeriod
  requests?: number
  okCount?: number
  failed?: number
  promptTokens?: number
  completionTokens?: number
  cachedTokens?: number
  /** 平均耗时（ms）。 */
  avgDurationMs?: number
  /** 平均首字节延迟（ms）。 */
  avgTtfbMs?: number
  /** 输入/输出为估算的请求数（面板据此提示）。 */
  estimatedInputs?: number
  estimatedOutputs?: number
  /** 累计请求数（不受周期影响）。 */
  lifetime?: number
  bySupplier?: RouterRankRow[]
  byModel?: RouterRankRow[]
  byRequested?: RouterRankRow[]
  recent?: RouterUsageRecord[]
}

/** `/router/api/stats/chart` 一桶。 */
export interface RouterChartBucket {
  label: string
  requests: number
  tokens: number
}

/** `/router/api/stats/chart` response. */
export interface RouterChartResponse {
  ok: boolean
  error?: string
  chart?: RouterChartBucket[]
}

/**
 * 外部 OpenAI 兼容客户端的归因标签（`/v1` 没有宿主内部头 `x-dsh-router-session`
 * 时的兜底）——否则 usage 记录里全是匿名流量，出事反查不出是谁在打
 * （2026-10-15 实测：296 条匿名记录对不上任何会话）。
 *
 * 取值优先级：`user`（OpenAI 标准终端用户字段）→ `prompt_cache_key`
 * （Zed 等客户端的缓存键，常带线程粒度）→ `User-Agent`（保底到客户端粒度）。
 * 值截断到 64 字符；三者皆无返回 undefined（保持匿名）。
 */
export function clientIdentityOf(
  body: { user?: unknown; prompt_cache_key?: unknown },
  userAgent: string | undefined,
): string | undefined {
  const tag = (kind: string, v: unknown): string | undefined =>
    typeof v === 'string' && v !== '' ? `ext/${kind}:${v.slice(0, 64)}` : undefined
  return (
    tag('user', body.user)
    ?? tag('cache', body.prompt_cache_key)
    ?? (userAgent !== undefined && userAgent !== '' ? `ext/ua:${userAgent.slice(0, 64)}` : undefined)
  )
}
