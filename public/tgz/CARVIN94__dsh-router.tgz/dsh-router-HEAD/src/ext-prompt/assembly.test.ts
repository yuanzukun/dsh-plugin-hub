/**
 * 提示词**装配结果**的断言 —— 回答「我关掉的分类，真的没进 prompt 吗」。
 *
 * 为什么单独一个文件：这不是某个函数的单测，而是**跨模块的合成事实** ——
 *   content.ts（内容）→ render.ts（按开关拼）→ mount.ts（注册 provider）
 *   → ctx.systemPrompt（平台装配）→ renderPrompt（最终文本）
 * 任何一环坏了，单测都绿而 prompt 里没有。
 *
 * ⚠️ 全部用**真 cordis + 真 dsh-system-prompt**。假 systemPrompt 会立即回调、
 * 立刻返回，`assemble()` 返回什么全凭我写 —— 那就是自己给自己判分
 * （2026-09-29 刚栽过：假 ctx 的 inject 立即回调，恰好把「准则没挂上」这个
 * 真 bug 完美掩盖）。
 */
import test from 'node:test'
import assert from 'node:assert/strict'
import { Context } from '@deepseek-ai/cordis'
import { SystemPrompt, renderPrompt, type PromptAssembly } from '@deepseek-ai/dsh-system-prompt'
import { mountPromptSection, PROMPT_SECTION_NAME } from './mount.ts'
import { renderPromptText } from './render.ts'
import { PROMPT_CATEGORIES } from './content.ts'
import { createSectionCache, disabledSectionNames, filterSections } from './sections.ts'

/** 起一个真 systemPrompt 并挂上本扩展。 */
async function assemble(
  opts: { masterOn?: boolean; data?: unknown } = {},
): Promise<PromptAssembly> {
  const ctx = new Context()
  new SystemPrompt(ctx, {})
  let enabled = true
  const data = opts.data
  const dispose = mountPromptSection({
    getSystemPrompt: () => ctx.systemPrompt,
    isEnabled: () => (opts.masterOn ?? enabled),
    readData: () => data as never,
  })
  void enabled
  void dispose
  await new Promise((r) => setTimeout(r, 10))
  return ctx.systemPrompt.assemble({})
}

test('★ 装配结果里真的有准则段落（不是「我以为我挂了」）', async () => {
  const a = await assemble()
  const mine = a.sections.find((s) => s.name === PROMPT_SECTION_NAME)
  assert.ok(mine, `装配里没有 ${PROMPT_SECTION_NAME} 段落；现有：${a.sections.map((s) => s.name).join(', ')}`)
  const text = renderPrompt(a)
  // ⚠️ 断言用**正文里真有的串**，不用分类的**显示名** ——
  //   `懒人梯子` 只是分类的 title，它的 body 开头是「梯子：停在第一个成立的档」。
  //   我原先断言 '懒人梯子'，而那个串**只存在于旧标题**里 ⇒
  //   2026-09-29 把标题改成 `[准则 v5]` 后，这断言红了 —— 它一直在测标题，
  //   从来没测过正文。判据钉错了东西，改成钉正文里稳定的片段。
  assert.ok(text.includes('停在第一个成立的档'), '最终 prompt 文本里没有准则正文')
  assert.ok(text.includes('准则 v5'), '标题不在（拆分时最容易丢的就是它）')
})

test('★ 关掉某条分类 ⇒ 装配结果里那条真的不在', async () => {
  const a = await assemble({ data: { categories: { structure: false } } })
  const text = renderPrompt(a)
  const body = PROMPT_CATEGORIES.find((c) => c.id === 'structure')!.body
  assert.equal(text.includes(body), false, `「结构」关了却仍在 prompt 里：${body.slice(0, 20)}`)
  // 反向：没关的必须在
  const keep = PROMPT_CATEGORIES.find((c) => c.id === 'delivery')!.body
  assert.ok(text.includes(keep), '没关的分类被误删了')
})

test('★ 总开关关 ⇒ 整个段落被丢弃（空文本不产出任何内容）', async () => {
  const a = await assemble({ masterOn: false })
  const mine = a.sections.find((s) => s.name === PROMPT_SECTION_NAME)
  // 平台对空 section 的处理是「不产出文本」——断言**文本**里没有，而不是
  // 「section 不存在」：section 仍注册着，只是 text 为空。
  assert.equal(renderPrompt(a).includes('懒人梯子'), false, '总开关关了准则还在')
  void mine
})

test('装配结果与 renderPromptText 的内容一致（渲染逻辑只有一处实现）', async () => {
  const a = await assemble()
  const text = renderPrompt(a)
  const expected = renderPromptText(true, undefined)
  assert.ok(text.includes(expected), '装配结果里找不到 renderPromptText 的输出 ⇒ 两处实现漂移了')
})

// ── 段落总控：真宿主装配链上的"关了就没了"（2026-10-21）──────────
/**
 * ⚠️ 这里才是段落总控的**终局判据**。前面 `section-filter.test.ts` 验的是
 * "监听器按规则返回了什么"，而"宿主真把那个返回值当成最终装配"是**另一件事**
 * —— 宿主源码里 waterfall 之后还有 complete-section 恢复、runtime-context
 * 抑制等收尾，任何一处改动都可能让我们删的段回来。只有跑真 `assemble()`
 * 才能钉住。
 */
async function assembleWithSections(
  opts: { masterOn?: boolean; data?: unknown },
): Promise<{ names: string[]; text: string; dispose: () => void }> {
  const ctx = new Context()
  new SystemPrompt(ctx, { includeHarnessIdentity: true, personaPrefix: 'PERSONA-PREFIX-SENTINEL' })
  let enabled = true
  const cache = createSectionCache()
  // 与 index.ts 的监听器**同一形状**：先 next()、喂清单、再按落盘过滤
  const offAssemble = ctx.on('system-prompt/assemble', async (assembly, _c, next) => {
    const result = await next()
    cache.update(result.sections)
    if ((opts.masterOn ?? enabled) !== true) return result
    const off = disabledSectionNames(opts.data as never)
    if (off.size === 0) return result
    return { ...result, sections: filterSections(result.sections, off) }
  })
  // 本扩展自己的准则段（带正文哨兵，便于断言它没被段开关删掉）
  const dispose = mountPromptSection({
    getSystemPrompt: () => ctx.systemPrompt,
    isEnabled: () => true,
    readData: () => undefined,
  })
  await new Promise((r) => setTimeout(r, 10))
  const a = await ctx.systemPrompt.assemble({})
  return {
    names: a.sections.map((s) => s.name),
    text: renderPrompt(a),
    dispose: () => { offAssemble(); dispose(); void ctx },
  }
}

test('★ 真装配链：关掉某段落 ⇒ 它真的不在最终 prompt 里', async () => {
  const on = await assembleWithSections({})
  // 宿主自带的段（关掉 includeHarnessIdentity 也仍在表里的话更好，但优先用我们自己的）
  assert.ok(on.names.includes(PROMPT_SECTION_NAME), `准则段不在装配里：${on.names.join(', ')}`)
  const target = on.names.find((n) => n === 'deployment:persona-prefix')
  assert.ok(target !== undefined, `找不到宿主 persona 段，实际段名：${on.names.join(', ')}`)
  on.dispose()

  const off = await assembleWithSections({ data: { sections: { [target]: false } } })
  assert.equal(off.names.includes(target), false, `真装配链里 ${target} 关了却还在`)
  assert.equal(off.text.includes('PERSONA-PREFIX-SENTINEL'), false, '段没了但正文还在 ⇒ 过滤没生效')
  // 反向：别的段与准则不能陪葬
  assert.ok(off.names.includes(PROMPT_SECTION_NAME), '关别人的段时把准则段一起删了')
  off.dispose()
})

test('★ 真装配链：总开关关 ⇒ 一个段都不动（扩展关 = 不干预宿主）', async () => {
  const r = await assembleWithSections({ masterOn: false, data: { sections: { 'deployment:persona-prefix': false } } })
  assert.ok(r.names.includes('deployment:persona-prefix'), '总开关关掉后仍在过滤 ⇒ 关了还生效')
  assert.ok(r.text.includes('PERSONA-PREFIX-SENTINEL'), '总开关关掉后 persona 正文不见了')
  r.dispose()
})
