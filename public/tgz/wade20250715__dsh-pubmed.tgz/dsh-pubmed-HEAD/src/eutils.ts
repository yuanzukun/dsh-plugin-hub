/**
 * NCBI E-utilities 封装层 —— dsh-pubmed 的网络核心。
 *
 * 只用公共免费接口 eutils.ncbi.nlm.nih.gov，不需要任何 API key。
 * 内置限速（NCBI 要求每秒 ≤3 次请求），全部请求支持 AbortSignal 取消。
 */
const BASE = 'https://eutils.ncbi.nlm.nih.gov/entrez/eutils/'

let lastRequestAt = 0

/** 全局节流：每次请求间隔 ≥ 350ms，避免触发 NCBI 限速封禁。 */
async function throttle(): Promise<void> {
  const now = Date.now()
  const wait = Math.max(0, 350 - (now - lastRequestAt))
  if (wait > 0) await new Promise((r) => setTimeout(r, wait))
  lastRequestAt = Date.now()
}

async function eutilsJson(
  path: string,
  params: Record<string, string>,
  signal?: AbortSignal,
): Promise<any> {
  await throttle()
  const qs = new URLSearchParams(params).toString()
  const url = `${BASE}${path}?${qs}`
  const res = await fetch(url, { signal })
  if (!res.ok) {
    throw new Error(`E-utilities 请求失败：HTTP ${res.status}（${path}）`)
  }
  return res.json()
}

async function eutilsText(
  path: string,
  params: Record<string, string>,
  signal?: AbortSignal,
): Promise<string> {
  await throttle()
  const qs = new URLSearchParams(params).toString()
  const url = `${BASE}${path}?${qs}`
  const res = await fetch(url, { signal })
  if (!res.ok) {
    throw new Error(`E-utilities 请求失败：HTTP ${res.status}（${path}）`)
  }
  return res.text()
}

/** 论文元数据（esummary 返回的字段子集）。 */
export type PaperMeta = {
  pmid: string
  title: string
  journal: string
  year: string
  authors: string[]
  doi: string
}

/** esearch：按检索式返回 PMID 列表与命中总数。 */
export type SearchResult = {
  count: number
  pmids: string[]
}

export async function esearch(
  query: string,
  opts: { retmax?: number; sort?: string; mindate?: string; maxdate?: string } = {},
  signal?: AbortSignal,
): Promise<SearchResult> {
  const params: Record<string, string> = {
    db: 'pubmed',
    term: query,
    retmax: String(opts.retmax ?? 20),
    retmode: 'json',
    sort: opts.sort ?? 'relevance',
  }
  if (opts.mindate) params.mindate = opts.mindate
  if (opts.maxdate) params.maxdate = opts.maxdate
  const data = await eutilsJson('esearch.fcgi', params, signal)
  const r = data?.esearchresult ?? {}
  return {
    count: Number(r.count ?? 0),
    pmids: Array.isArray(r.idlist) ? r.idlist : [],
  }
}

/** esummary：批量取文献元数据（标题/期刊/年份/作者缩写/DOI）。 */
export async function esummary(
  pmids: string[],
  signal?: AbortSignal,
): Promise<PaperMeta[]> {
  if (!pmids.length) return []
  // esummary 一次最多 200 个 id
  const chunks: string[][] = []
  for (let i = 0; i < pmids.length; i += 200) chunks.push(pmids.slice(i, i + 200))

  const out: PaperMeta[] = []
  for (const chunk of chunks) {
    const data = await eutilsJson('esummary.fcgi', {
      db: 'pubmed',
      retmode: 'json',
      id: chunk.join(','),
    }, signal)
    const result = data?.result ?? {}
    const uids: string[] = Array.isArray(result.uids) ? result.uids : []
    for (const uid of uids) {
      const d = result[uid]
      if (!d) continue
      out.push({
        pmid: uid,
        title: String(d.title ?? '').replace(/\s+/g, ' ').trim(),
        journal: String(d.fulljournalname ?? d.source ?? ''),
        year: String(d.pubdate ?? '').slice(0, 4),
        authors: Array.isArray(d.authors)
          ? d.authors.map((a: any) => String(a.name ?? '')).filter(Boolean)
          : [],
        doi: String(d.elocationid ?? '').replace(/^doi:\s*/i, ''),
      })
    }
  }
  return out
}

/** 完整作者记录（efetch XML 解析结果）。 */
export type AuthorFull = {
  name: string
  forename: string
  lastname: string
  affiliations: string[]
}

/** 带完整作者信息的论文（efetch XML 解析结果）。 */
export type PaperFull = {
  pmid: string
  title: string
  journal: string
  year: string
  authors: AuthorFull[]
  abstract: string
}

/**
 * efetch：批量取完整作者全名 + 机构 + 摘要。
 * 用轻量正则解析 XML，避免引入额外依赖（保持零依赖）。
 */
export async function efetch(
  pmids: string[],
  signal?: AbortSignal,
): Promise<PaperFull[]> {
  if (!pmids.length) return []
  // efetch 每批建议 ≤ 50 个，避免超时
  const chunks: string[][] = []
  for (let i = 0; i < pmids.length; i += 50) chunks.push(pmids.slice(i, i + 50))

  const out: PaperFull[] = []
  for (const chunk of chunks) {
    const xml = await eutilsText('efetch.fcgi', {
      db: 'pubmed',
      retmode: 'xml',
      id: chunk.join(','),
    }, signal)
    out.push(...parseEfetchXml(xml))
  }
  return out
}

/** 解析 efetch 的 XML，提取每篇论文的完整作者与摘要。 */
function parseEfetchXml(xml: string): PaperFull[] {
  const papers: PaperFull[] = []
  // 按 <PubmedArticle> 切块
  const articleRe = /<PubmedArticle>[\s\S]*?<\/PubmedArticle>/g
  let m: RegExpExecArray | null
  while ((m = articleRe.exec(xml)) !== null) {
    const block = m[0]
    papers.push(parseArticleBlock(block))
  }
  return papers
}

function parseArticleBlock(block: string): PaperFull {
  const grab = (re: RegExp): string => {
    const mm = re.exec(block)
    return mm ? mm[1].trim() : ''
  }

  const pmid = grab(/<PMID[^>]*>([^<]+)<\/PMID>/)
  const title = grab(/<ArticleTitle>(.*?)<\/ArticleTitle>/s).replace(/<[^>]+>/g, '')
  const journal = grab(/<Journal>\s*<Title>([^<]+)<\/Title>/)
  const year =
    grab(/<PubDate>\s*<Year>([^<]+)<\/Year>/) ||
    grab(/<ArticleDate[^>]*>\s*<Year>([^<]+)<\/Year>/)

  const authors: AuthorFull[] = []
  const authorRe = /<Author[^>]*>(.*?)<\/Author>/gs
  let am: RegExpExecArray | null
  while ((am = authorRe.exec(block)) !== null) {
    const ab = am[1]
    const lastname = grabOn(ab, /<LastName>([^<]*)<\/LastName>/)
    const forename = grabOn(ab, /<ForeName>([^<]*)<\/ForeName>/)
    const affs: string[] = []
    const affRe = /<Affiliation>([^<]*)<\/Affiliation>/g
    let fm: RegExpExecArray | null
    while ((fm = affRe.exec(ab)) !== null) affs.push(fm[1].trim())
    authors.push({
      name: [forename, lastname].filter(Boolean).join(' '),
      forename,
      lastname,
      affiliations: affs,
    })
  }

  const absParts: string[] = []
  const absRe = /<AbstractText[^>]*>([\s\S]*?)<\/AbstractText>/g
  let dm: RegExpExecArray | null
  while ((dm = absRe.exec(block)) !== null) {
    absParts.push(dm[1].replace(/<[^>]+>/g, ' ').trim())
  }
  const abstract = absParts.join(' ').replace(/\s+/g, ' ').trim()

  return { pmid, title, journal, year, authors, abstract }
}

function grabOn(text: string, re: RegExp): string {
  const m = re.exec(text)
  return m ? m[1].trim() : ''
}
