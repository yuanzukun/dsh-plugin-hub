/**
 * dsh-pubmed —— DeepSeek Harness 的 PubMed 深度检索工具集。
 *
 * 7 个工具，全部走 NCBI E-utilities 公共接口（零 API key）：
 *   pubmed_search        文献检索
 *   pubmed_fetch         批量拉取文献详情
 *   pubmed_author        作者发文调查
 *   pubmed_disambiguate  同名作者消歧
 *   pubmed_institution   机构发文统计
 *   pubmed_mentor_match  导师-学生挂名匹配
 *   pubmed_retraction    撤稿/学术不端核查
 *
 * 依赖 @deepseek-ai/cordis 与 @deepseek-ai/dsh-tools（peerDependencies）。
 */
import type { Context } from '@deepseek-ai/cordis'
import { defineTool } from '@deepseek-ai/dsh-tools'
import { esearch, esummary, efetch } from './eutils.js'

export const name = 'dsh-pubmed'
export const inject = ['tools']

/** 把任意 JSON 值序列化成人类可读文本（模型看到的输出）。 */
function fmt(v: unknown): string {
  return typeof v === 'string' ? v : JSON.stringify(v, null, 2)
}

export function apply(ctx: Context): void {
  // ============ 1. pubmed_search：文献检索 ============
  ctx.tools.register(defineTool({
    name: 'pubmed_search',
    description:
      'Search PubMed for biomedical literature by a query string. ' +
      'Returns the total hit count and a list of PMIDs. ' +
      'Use this first, then pass the PMIDs to pubmed_fetch for details.',
    parameters: {
      query: {
        type: 'string',
        required: true,
        description:
          'PubMed query. Supports field tags like [Author], [Affiliation], [Title/Abstract], [Journal], ' +
          'boolean AND/OR/NOT, and quotes for exact phrases. Example: "Zhang Wei"[Author] AND epilepsy',
      },
      retmax: { type: 'number', description: 'Max PMIDs to return (default 20, max 500).' },
      sort: { type: 'string', description: "Sort order: 'relevance' (default) or 'pub_date'." },
      mindate: { type: 'string', description: "Earliest date filter, format YYYY or YYYY/MM/DD. Example: '2020'." },
      maxdate: { type: 'string', description: "Latest date filter, format YYYY or YYYY/MM/DD. Example: '2026/08/15'." },
    },
    output: {
      schema: { type: 'json' },
      render: (_args, value: any) => [{
        type: 'text',
        text:
          `PubMed 检索完成，命中 ${value.count} 篇。\n` +
          `PMID 列表（前 ${Array.isArray(value.pmids) ? value.pmids.length : 0} 个）：\n` +
          `${Array.isArray(value.pmids) ? value.pmids.join(', ') : ''}`,
      }],
    },
    execute: async (args: any, exec) => {
      const r = await esearch(
        args.query,
        {
          retmax: args.retmax ?? 20,
          sort: args.sort ?? 'relevance',
          mindate: args.mindate,
          maxdate: args.maxdate,
        },
        exec.signal,
      )
      return r
    },
    timeoutMs: 20000,
  }))

  // ============ 2. pubmed_fetch：批量拉取文献详情 ============
  ctx.tools.register(defineTool({
    name: 'pubmed_fetch',
    description:
      'Fetch metadata (title, journal, year, authors, DOI) for a list of PMIDs. ' +
      'Feed it PMIDs obtained from pubmed_search, pubmed_author, or pubmed_institution.',
    parameters: {
      pmids: {
        type: 'string',
        required: true,
        description: 'Comma-separated PMID list. Example: "36180952,38703872,42526547".',
      },
    },
    output: {
      schema: { type: 'json' },
      render: (_args, value: any) => {
        const papers: any[] = Array.isArray(value.papers) ? value.papers : []
        const lines = papers.map((p, i) =>
          `${i + 1}. [PMID ${p.pmid}] (${p.year}) ${p.title}\n   期刊: ${p.journal} | 作者: ${p.authors.join('; ')}` +
          (p.doi ? ` | DOI: ${p.doi}` : ''),
        )
        return [{ type: 'text', text: `共 ${papers.length} 篇文献：\n\n${lines.join('\n')}` }]
      },
    },
    execute: async (args: any, exec) => {
      const pmids = String(args.pmids).split(',').map((s) => s.trim()).filter(Boolean)
      const papers = await esummary(pmids, exec.signal)
      return { papers }
    },
    timeoutMs: 30000,
  }))

  // ============ 3. pubmed_author：作者发文调查 ============
  ctx.tools.register(defineTool({
    name: 'pubmed_author',
    description:
      'Investigate an author\'s publication record by full pinyin name. ' +
      'Optionally restrict to one affiliation. Returns paper count and metadata. ' +
      'For Chinese names, use the full pinyin (e.g. "Zhang Wei", surname first), not abbreviations.',
    parameters: {
      fullname: {
        type: 'string',
        required: true,
        description: "Author full name in pinyin. Example: 'Zhang Wei' (surname first).",
      },
      affiliation: {
        type: 'string',
        description: "Optional affiliation to filter. Example: 'Sichuan University'.",
      },
      retmax: { type: 'number', description: 'Max papers to return (default 30).' },
    },
    output: {
      schema: { type: 'json' },
      render: (_args, value: any) => {
        const papers: any[] = Array.isArray(value.papers) ? value.papers : []
        const lines = papers.map((p, i) =>
          `${i + 1}. [PMID ${p.pmid}] (${p.year}) ${p.title} — ${p.journal}`,
        )
        return [{
          type: 'text',
          text:
            `${value.fullname} 在 PubMed 命中 ${value.count} 篇（展示 ${papers.length} 篇）：\n\n` +
            lines.join('\n'),
        }]
      },
    },
    execute: async (args: any, exec) => {
      const fullname = String(args.fullname).trim()
      let query = `"${fullname}"[Author]`
      if (args.affiliation) query += ` AND "${args.affiliation}"[Affiliation]`
      const s = await esearch(query, { retmax: args.retmax ?? 30, sort: 'pub_date' }, exec.signal)
      const papers = await esummary(s.pmids, exec.signal)
      return { fullname, count: s.count, papers }
    },
    timeoutMs: 30000,
  }))

  // ============ 4. pubmed_disambiguate：同名作者消歧 ============
  ctx.tools.register(defineTool({
    name: 'pubmed_disambiguate',
    description:
      'Disambiguate papers by one pinyin name across institutions. ' +
      'Fetches full author records (forename + affiliation) and separates papers that match ' +
      'the given affiliation from those belonging to other same-name authors.',
    parameters: {
      fullname: {
        type: 'string',
        required: true,
        description: "Author full pinyin name. Example: 'Zhang Wei'.",
      },
      affiliation: {
        type: 'string',
        required: true,
        description: "Affiliation keyword that identifies THIS person. Example: 'Sichuan University'.",
      },
      retmax: { type: 'number', description: 'Max papers to analyze (default 50).' },
    },
    output: {
      schema: { type: 'json' },
      render: (_args, value: any) => {
        const matched: any[] = Array.isArray(value.matched) ? value.matched : []
        const others: any[] = Array.isArray(value.others) ? value.others : []
        const mlines = matched.map((p) =>
          `- [PMID ${p.pmid}] (${p.year}) ${p.title} — ${p.journal}`,
        )
        const olines = others.map((p) =>
          `- [PMID ${p.pmid}] 机构: ${Array.isArray(p.affiliations) ? p.affiliations.join('; ') : p.affiliations}`,
        )
        return [{
          type: 'text',
          text:
            `同名消歧结果（${value.fullname}）：\n` +
            `  共 ${value.total} 篇，其中 ${value.matched_count} 篇属于「${value.affiliation}」，` +
            `其余 ${others.length} 篇是其他同名者。\n\n` +
            `【属于 ${value.affiliation}】\n${mlines.join('\n') || '(无)'}\n\n` +
            `【其他同名者】\n${olines.join('\n') || '(无)'}`,
        }]
      },
    },
    execute: async (args: any, exec) => {
      const fullname = String(args.fullname).trim()
      const affil = String(args.affiliation).trim().toLowerCase()
      const query = `"${fullname}"[Author]`
      const s = await esearch(query, { retmax: args.retmax ?? 50, sort: 'pub_date' }, exec.signal)
      const fulls = await efetch(s.pmids, exec.signal)

      const matched: any[] = []
      const others: any[] = []
      for (const p of fulls) {
        // 找到匹配 fullname 的作者，看其机构是否含目标机构
        const target = p.authors.find((a) => {
          const nm = `${a.forename} ${a.lastname}`.trim().toLowerCase()
          return nm === fullname.toLowerCase() || `${a.lastname} ${a.forename}`.trim().toLowerCase() === fullname.toLowerCase()
        })
        const affs = target ? target.affiliations : []
        const isMatch = affs.some((af) => af.toLowerCase().includes(affil))
        if (isMatch) {
          matched.push({ pmid: p.pmid, year: p.year, title: p.title, journal: p.journal })
        } else {
          others.push({ pmid: p.pmid, year: p.year, affiliations: affs })
        }
      }
      return { fullname, total: s.count, matched_count: matched.length, matched, others }
    },
    timeoutMs: 60000,
  }))

  // ============ 5. pubmed_institution：机构发文统计 ============
  ctx.tools.register(defineTool({
    name: 'pubmed_institution',
    description:
      'Count and list PubMed papers affiliated with an institution, optionally within a date range. ' +
      'Returns total count, the paper list, and a per-year breakdown.',
    parameters: {
      institution: {
        type: 'string',
        required: true,
        description: "Institution name. Example: 'Sichuan University'.",
      },
      mindate: { type: 'string', description: "Earliest date, format YYYY. Example: '2024'." },
      maxdate: { type: 'string', description: "Latest date, format YYYY. Example: '2026'." },
      retmax: { type: 'number', description: 'Max papers to return (default 50).' },
    },
    output: {
      schema: { type: 'json' },
      render: (_args, value: any) => {
        const papers: any[] = Array.isArray(value.papers) ? value.papers : []
        const byYear = value.by_year ?? {}
        const yearLines = Object.entries(byYear).sort().map(([y, c]) => `${y}: ${c} 篇`)
        const plines = papers.slice(0, 20).map((p, i) =>
          `${i + 1}. [PMID ${p.pmid}] (${p.year}) ${p.title} — ${p.journal}`,
        )
        return [{
          type: 'text',
          text:
            `机构「${value.institution}」在 PubMed 共 ${value.count} 篇。\n\n` +
            `按年份分布：\n${yearLines.join('\n')}\n\n` +
            `论文列表（前 ${papers.length} 篇）：\n${plines.join('\n')}`,
        }]
      },
    },
    execute: async (args: any, exec) => {
      const query = `"${args.institution}"[Affiliation]`
      const s = await esearch(
        query,
        { retmax: args.retmax ?? 50, sort: 'pub_date', mindate: args.mindate, maxdate: args.maxdate },
        exec.signal,
      )
      const papers = await esummary(s.pmids, exec.signal)
      const by_year: Record<string, number> = {}
      for (const p of papers) by_year[p.year] = (by_year[p.year] ?? 0) + 1
      return { institution: args.institution, count: s.count, papers, by_year }
    },
    timeoutMs: 30000,
  }))

  // ============ 6. pubmed_mentor_match：导师-学生挂名匹配 ============
  ctx.tools.register(defineTool({
    name: 'pubmed_mentor_match',
    description:
      'Check whether two authors (e.g. a mentor and a student) co-authored papers. ' +
      'Searches each name, then finds the PMIDs they share. ' +
      'Useful to verify an advisor-student publication relationship.',
    parameters: {
      mentor: {
        type: 'string',
        required: true,
        description: "Mentor's full pinyin name. Example: 'Hong Shen'.",
      },
      student: {
        type: 'string',
        required: true,
        description: "Student's full pinyin name. Example: 'Zhang Wei'.",
      },
      affiliation: {
        type: 'string',
        description: "Optional affiliation to narrow both searches. Example: 'Nanjing University of Chinese Medicine'.",
      },
    },
    output: {
      schema: { type: 'json' },
      render: (_args, value: any) => {
        const shared: any[] = Array.isArray(value.shared_papers) ? value.shared_papers : []
        const lines = shared.map((p, i) =>
          `${i + 1}. [PMID ${p.pmid}] (${p.year}) ${p.title} — ${p.journal}`,
        )
        return [{
          type: 'text',
          text:
            `导师「${value.mentor}」发文 ${value.mentor_count} 篇，学生「${value.student}」发文 ${value.student_count} 篇。\n` +
            `两人共同署名 ${shared.length} 篇：\n\n${lines.join('\n') || '(无共同论文)'}`,
        }]
      },
    },
    execute: async (args: any, exec) => {
      const mk = (name: string) => {
        let q = `"${name}"[Author]`
        if (args.affiliation) q += ` AND "${args.affiliation}"[Affiliation]`
        return q
      }
      const m = await esearch(mk(args.mentor), { retmax: 500, sort: 'pub_date' }, exec.signal)
      const st = await esearch(mk(args.student), { retmax: 500, sort: 'pub_date' }, exec.signal)
      const mSet = new Set(m.pmids)
      const sharedPmids = st.pmids.filter((p) => mSet.has(p))
      const shared_papers = await esummary(sharedPmids, exec.signal)
      return {
        mentor: args.mentor,
        student: args.student,
        mentor_count: m.count,
        student_count: st.count,
        shared_count: sharedPmids.length,
        shared_papers,
      }
    },
    timeoutMs: 40000,
  }))

  // ============ 7. pubmed_retraction：撤稿/学术不端核查 ============
  ctx.tools.register(defineTool({
    name: 'pubmed_retraction',
    description:
      'Check for retracted or withdrawn papers related to a person or topic. ' +
      'Returns a list of retraction notices and their linked original papers.',
    parameters: {
      query: {
        type: 'string',
        required: true,
        description: 'Author name or topic to vet. Example: "Xicai Liang" or "Xicai Liang"[Author].',
      },
      retmax: { type: 'number', description: 'Max records to return (default 30).' },
    },
    output: {
      schema: { type: 'json' },
      render: (_args, value: any) => {
        const items: any[] = Array.isArray(value.retracted) ? value.retracted : []
        const lines = items.map((p, i) =>
          `${i + 1}. [PMID ${p.pmid}] (${p.year}) ${p.title} — ${p.journal}`,
        )
        return [{
          type: 'text',
          text:
            `撤稿核查完成，共 ${value.count} 条记录：\n\n` +
            `${lines.join('\n') || '(未发现撤稿记录)'}`,
        }]
      },
    },
    execute: async (args: any, exec) => {
      const q = String(args.query).trim()
      // 补上 [Author] 标签（如果用户给的是纯人名）
      const term = q.includes('[') ? q : `"${q}"[Author]`
      const query = `${term} AND ("Retraction of Publication"[Publication Type] OR "Retracted Publication"[Publication Type])`
      const s = await esearch(query, { retmax: args.retmax ?? 30, sort: 'pub_date' }, exec.signal)
      const papers = await esummary(s.pmids, exec.signal)
      return { count: s.count, retracted: papers }
    },
    timeoutMs: 30000,
  }))
}
