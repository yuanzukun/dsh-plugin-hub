/**
 * dsh-pubmed —— DeepSeek Harness 的 PubMed 深度检索工具集。
 *
 * 7 个工具，全部走 NCBI E-utilities 公共接口（零 API key）：
 *   pubmed_search        文献检索
 *   pubmed_fetch         批量拉取文献详情
 *   pubmed_author        作者发文调查
 *   pubmed_disambiguate  同名作者消歧
 *   pubmed_institution   机构发文统计
 *   pubmed_mentor_match  导师-学生挂名匹配
 *   pubmed_retraction    撤稿/学术不端核查
 *
 * 依赖 @deepseek-ai/cordis 与 @deepseek-ai/dsh-tools（peerDependencies）。
 */
import type { Context } from '@deepseek-ai/cordis';
export declare const name = "dsh-pubmed";
export declare const inject: string[];
export declare function apply(ctx: Context): void;
