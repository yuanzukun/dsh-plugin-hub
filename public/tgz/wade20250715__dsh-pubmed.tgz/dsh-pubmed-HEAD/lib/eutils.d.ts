/** 论文元数据（esummary 返回的字段子集）。 */
export type PaperMeta = {
    pmid: string;
    title: string;
    journal: string;
    year: string;
    authors: string[];
    doi: string;
};
/** esearch：按检索式返回 PMID 列表与命中总数。 */
export type SearchResult = {
    count: number;
    pmids: string[];
};
export declare function esearch(query: string, opts?: {
    retmax?: number;
    sort?: string;
    mindate?: string;
    maxdate?: string;
}, signal?: AbortSignal): Promise<SearchResult>;
/** esummary：批量取文献元数据（标题/期刊/年份/作者缩写/DOI）。 */
export declare function esummary(pmids: string[], signal?: AbortSignal): Promise<PaperMeta[]>;
/** 完整作者记录（efetch XML 解析结果）。 */
export type AuthorFull = {
    name: string;
    forename: string;
    lastname: string;
    affiliations: string[];
};
/** 带完整作者信息的论文（efetch XML 解析结果）。 */
export type PaperFull = {
    pmid: string;
    title: string;
    journal: string;
    year: string;
    authors: AuthorFull[];
    abstract: string;
};
/**
 * efetch：批量取完整作者全名 + 机构 + 摘要。
 * 用轻量正则解析 XML，避免引入额外依赖（保持零依赖）。
 */
export declare function efetch(pmids: string[], signal?: AbortSignal): Promise<PaperFull[]>;
