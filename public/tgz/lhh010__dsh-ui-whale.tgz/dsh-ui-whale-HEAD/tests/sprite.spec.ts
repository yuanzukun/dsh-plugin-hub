/**
 * Sprite layering invariants: the body/eye/tail/fin/spout/heart layers must
 * tile the source frames exactly. Composing any pure pose (resting, one tail
 * frame, one fin frame, one spout frame, one heart frame, eyes closed)
 * reproduces that source frame cell-for-cell, and the motion regions are
 * pairwise disjoint.
 */
import { describe, expect, it } from 'vitest'
import { FRAMES, SPRITE_HEIGHT, SPRITE_WIDTH } from '../src/client/sprite-data.ts'
import { framePixelsFor, LAYER_SIZES, RESTING_FRAME, type WhaleFrame } from '../src/client/sprite.ts'

/** Reconstruct the full pixel grid of a composed frame (x,y → palette). */
function gridOf(frame: ReturnType<typeof framePixelsFor>): Map<string, number> {
  const grid = new Map<string, number>()
  for (const p of frame) grid.set(`${p.x},${p.y}`, p.c)
  return grid
}

/** Parse an "x,y" grid key back into coordinates. */
function keyXY(key: string): [number, number] {
  const [xs, ys] = key.split(',')
  return [Number(xs ?? 0), Number(ys ?? 0)]
}

/** Assert the composed frame paints exactly the source frame. */
function expectEqualsSource(frame: WhaleFrame, source: readonly string[]): void {
  const grid = gridOf(framePixelsFor(frame))
  expect(grid.size, `composed ${JSON.stringify(frame)} paints ${grid.size} cells`).toBeGreaterThan(0)
  for (let y = 0; y < SPRITE_HEIGHT; y += 1) {
    for (let x = 0; x < SPRITE_WIDTH; x += 1) {
      const expected = Number(source[y]?.[x])
      const actual = grid.get(`${x},${y}`) ?? 0
      expect(actual, `cell (${x},${y}) of ${JSON.stringify(frame)}`).toBe(expected)
    }
  }
}

describe('sprite layers', () => {
  it('resting pose equals STANDARD exactly', () => {
    expectEqualsSource(RESTING_FRAME, FRAMES.STANDARD)
  })

  it('each tail pose equals its TAIL_k frame exactly', () => {
    expectEqualsSource({ tail: 1, fin: 0, spout: 0, heart: 0, sleep: 0, blink: false }, FRAMES.TAIL_1)
    expectEqualsSource({ tail: 2, fin: 0, spout: 0, heart: 0, sleep: 0, blink: false }, FRAMES.TAIL_2)
    expectEqualsSource({ tail: 3, fin: 0, spout: 0, heart: 0, sleep: 0, blink: false }, FRAMES.TAIL_3)
    expectEqualsSource({ tail: 4, fin: 0, spout: 0, heart: 0, sleep: 0, blink: false }, FRAMES.TAIL_4)
  })

  it('each fin pose equals its FIN_k frame exactly', () => {
    expectEqualsSource({ tail: 0, fin: 1, spout: 0, heart: 0, sleep: 0, blink: false }, FRAMES.FIN_1)
    expectEqualsSource({ tail: 0, fin: 2, spout: 0, heart: 0, sleep: 0, blink: false }, FRAMES.FIN_2)
  })

  it('each spout pose equals its SPOUT_k frame exactly', () => {
    expectEqualsSource({ tail: 0, fin: 0, spout: 1, heart: 0, sleep: 0, blink: false }, FRAMES.SPOUT_1)
    expectEqualsSource({ tail: 0, fin: 0, spout: 3, heart: 0, sleep: 0, blink: false }, FRAMES.SPOUT_3)
    expectEqualsSource({ tail: 0, fin: 0, spout: 6, heart: 0, sleep: 0, blink: false }, FRAMES.SPOUT_6)
  })

  it('each heart pose equals its HEART_k frame exactly', () => {
    expectEqualsSource({ tail: 0, fin: 0, spout: 0, heart: 1, sleep: 0, blink: false }, FRAMES.HEART_1)
    expectEqualsSource({ tail: 0, fin: 0, spout: 0, heart: 2, sleep: 0, blink: false }, FRAMES.HEART_2)
    expectEqualsSource({ tail: 0, fin: 0, spout: 0, heart: 3, sleep: 0, blink: false }, FRAMES.HEART_3)
  })

  it('each sleep pose equals its SLEEP_k frame exactly', () => {
    expectEqualsSource({ tail: 0, fin: 0, spout: 0, heart: 0, sleep: 1, blink: false }, FRAMES.SLEEP_1)
    expectEqualsSource({ tail: 0, fin: 0, spout: 0, heart: 0, sleep: 3, blink: false }, FRAMES.SLEEP_3)
    expectEqualsSource({ tail: 0, fin: 0, spout: 0, heart: 0, sleep: 5, blink: false }, FRAMES.SLEEP_5)
  })

  it('blink pose equals the BLINK frame exactly', () => {
    expectEqualsSource({ tail: 0, fin: 0, spout: 0, heart: 0, sleep: 0, blink: true }, FRAMES.BLINK)
  })

  it('tail poses differ from STANDARD only outside the resting pose', () => {
    const rest = gridOf(framePixelsFor(RESTING_FRAME))
    const tail1 = gridOf(framePixelsFor({ tail: 1, fin: 0, spout: 0, heart: 0, sleep: 0, blink: false }))
    let diffCells = 0
    for (const [key, c] of tail1) {
      if (rest.get(key) !== c) diffCells += 1
    }
    expect(diffCells).toBeGreaterThan(0)
    // The wag only touches the tail region (the right side of the canvas).
    for (const key of tail1.keys()) {
      if (rest.get(key) !== tail1.get(key)) {
        const [x] = keyXY(key)
        expect(x).toBeGreaterThanOrEqual(23)
      }
    }
  })

  it('spout poses add droplets above the blowhole without touching the body', () => {
    const rest = gridOf(framePixelsFor(RESTING_FRAME))
    const spout6 = gridOf(framePixelsFor({ tail: 0, fin: 0, spout: 6, heart: 0, sleep: 0, blink: false }))
    const added: string[] = []
    for (const [key, c] of spout6) {
      if (rest.get(key) !== c) added.push(key)
    }
    expect(added.length).toBeGreaterThan(0)
    // Droplets sit in the top rows (above the body, y < 7) and STANDARD is empty there.
    for (const key of added) {
      const [x, y] = keyXY(key)
      expect(y).toBeLessThan(7)
      expect(FRAMES.STANDARD[y]?.[x]).toBe('0')
    }
  })

  it('heart poses add only pink cells in the top-left over STANDARD-empty cells', () => {
    const rest = gridOf(framePixelsFor(RESTING_FRAME))
    const heart3 = gridOf(framePixelsFor({ tail: 0, fin: 0, spout: 0, heart: 3, sleep: 0, blink: false }))
    const added: string[] = []
    for (const [key, c] of heart3) {
      if (rest.get(key) !== c) added.push(key)
    }
    expect(added.length).toBeGreaterThan(0)
    // The heart sits in the top-left corner (x < 9, y < 7) where STANDARD is empty.
    for (const key of added) {
      const [x, y] = keyXY(key)
      expect(x).toBeLessThan(9)
      expect(y).toBeLessThan(7)
      expect(FRAMES.STANDARD[y]?.[x]).toBe('0')
      expect(heart3.get(key)).toBe(5)
    }
  })

  it('sleep poses add only gray Z cells above the head over STANDARD-empty cells', () => {
    const rest = gridOf(framePixelsFor(RESTING_FRAME))
    const sleep1 = gridOf(framePixelsFor({ tail: 0, fin: 0, spout: 0, heart: 0, sleep: 1, blink: false }))
    const added: string[] = []
    for (const [key, c] of sleep1) {
      if (rest.get(key) !== c) added.push(key)
    }
    expect(added.length).toBeGreaterThan(0)
    // The Z floats above the body (y < 7) where STANDARD is empty, in gray (6).
    for (const key of added) {
      const [x, y] = keyXY(key)
      expect(y).toBeLessThan(7)
      expect(FRAMES.STANDARD[y]?.[x]).toBe('0')
      expect(sleep1.get(key)).toBe(6)
    }
  })

  it('reports consistent layer sizes', () => {
    expect(LAYER_SIZES.body).toBeGreaterThan(0)
    expect(LAYER_SIZES.tailFrames).toBe(5)
    expect(LAYER_SIZES.finFrames).toBe(3)
    expect(LAYER_SIZES.spoutFrames).toBe(7)
    expect(LAYER_SIZES.heartFrames).toBe(4)
    expect(LAYER_SIZES.sleepFrames).toBe(6)
    // Heart layer: no heart, then the three growing hearts (6/16/27 pixels).
    expect(LAYER_SIZES.heart).toEqual([0, 6, 16, 27])
    // Sleep layer: no Z, then the Z rising/shrinking/fading (14/14/15/12/15).
    expect(LAYER_SIZES.sleep).toEqual([0, 14, 14, 15, 12, 15])
    expect(LAYER_SIZES.eyeOpen).toBeGreaterThan(0)
    expect(LAYER_SIZES.eyeClosed).toBeGreaterThan(0)
    // The resting pose is index 0 in every animated layer.
    expect(RESTING_FRAME.tail).toBe(0)
    expect(RESTING_FRAME.fin).toBe(0)
    expect(RESTING_FRAME.spout).toBe(0)
    expect(RESTING_FRAME.heart).toBe(0)
    expect(RESTING_FRAME.sleep).toBe(0)
    expect(RESTING_FRAME.blink).toBe(false)
  })
})
