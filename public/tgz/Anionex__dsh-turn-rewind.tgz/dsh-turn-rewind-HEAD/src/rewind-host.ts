import { randomUUID } from 'node:crypto'
import type { Context } from '@deepseek-ai/cordis'
import { createDeadline } from './deadline.js'
import { ChangeLedgerError, errorMessage } from './errors.js'
import type { ChangeLedgerEngine } from './engine.js'
import { discoverWorkspaceRoot } from './workspace.js'

interface SessionEventLike {
  readonly type: string
  readonly seq: number
  readonly data: Record<string, unknown>
}

interface SessionHeaderLike {
  readonly cwd?: string
  readonly parentSession?: string
  /**
   * Fork-inherited prefix length on DSH releases before 0.1.5. 0.1.5 deleted the
   * field — a stored header that still carries it is rejected outright — and moved
   * the same quantity to {@link SessionLike.inheritedEventCount}.
   */
  readonly seedLength?: number
}

interface SessionLike {
  readonly id: string
  readonly header: SessionHeaderLike
  /**
   * Exact number of leading events inherited from the fork parent, as reported by
   * DSH 0.1.5+ on the live session and on the stored session-log snapshot. `0` —
   * never `undefined` — for a session with no inherited prefix.
   */
  readonly inheritedEventCount?: number
  readonly events?: readonly SessionEventLike[]
  snapshotEvents?(fromSeq?: number, toSeqExclusive?: number): readonly SessionEventLike[]
}

interface AgentLike {
  readonly id: string
  readonly status: 'idle' | 'running'
  readonly session: SessionLike
}

interface ToolExecutionLike {
  readonly agent?: AgentLike
  readonly parent?: symbol
  readonly signal: AbortSignal
}

interface AgentsLike {
  list(): AgentLike[]
}

interface SessionsLike {
  get(id: string): SessionLike | undefined
}

interface SessionQueryLike {
  readSession(id: string): Promise<{
    readonly session: SessionHeaderLike
    readonly events: readonly SessionEventLike[]
    readonly inheritedEventCount?: number
  }>
}

interface HttpRequestLike {
  method?: string
  url?: string
  on(event: 'data', listener: (chunk: Uint8Array | string) => void): this
  on(event: 'end', listener: () => void): this
  on(event: 'error', listener: (error: unknown) => void): this
}

interface HttpResponseLike {
  writeHead(status: number, headers?: Record<string, string>): unknown
  end(body?: string): void
}

interface HttpServerLike {
  register(route: {
    kind: 'exact'
    path: string
    handler: (request: HttpRequestLike, response: HttpResponseLike) => void | Promise<void>
  }): () => void
}

interface ApiProxyLike {
  readonly sessions: {
    create(request: {
      readonly rpcId: string
      readonly payload: { readonly cwd: string }
    }): Promise<{
      readonly result:
        | { readonly ok: true; readonly value: { readonly sessionId: string } }
        | { readonly ok: false; readonly error: { readonly message: string } }
    }>
    fork(request: {
      readonly rpcId: string
      readonly payload: { readonly sessionId: string; readonly atSeq: number }
    }): Promise<{
      readonly result:
        | { readonly ok: true; readonly value: { readonly sessionId: string } }
        | { readonly ok: false; readonly error: { readonly message: string } }
    }>
  }
}

/**
 * Conversation create/fork capability of the Session controller service.
 *
 * DSH 0.1.2-alpha replaced the `apiProxy` RPC envelope with this plain service,
 * so carriers without `apiProxy` (DSH Desktop 2.x) reach the same capability here.
 */
interface SessionControllerLike {
  create(request: { readonly cwd?: string; readonly workspaceId?: string }): Promise<{ readonly sessionId: string }>
  fork(request: { readonly sessionId: string; readonly atSeq?: number }): Promise<{ readonly sessionId: string }>
}

/** Services a conversation restart can be built on, in either carrier shape. */
type ConversationRestartContext = Pick<Context, 'sessions' | 'sessionQuery' | 'get'> & {
  readonly apiProxy?: ApiProxyLike
  readonly sessionController?: SessionControllerLike
}

function getSessionEvents(session: SessionLike | undefined): readonly SessionEventLike[] {
  if (!session) return []
  if (typeof session.snapshotEvents === 'function') {
    return session.snapshotEvents()
  }
  return session.events ?? []
}

declare module '@deepseek-ai/cordis' {
  interface Context {
    agents: AgentsLike
    sessions: SessionsLike
    sessionQuery: SessionQueryLike
    webServer: HttpServerLike
    apiProxy: ApiProxyLike
    sessionController: SessionControllerLike
  }

  interface Events {
    'agent/pre-step'(
      payload: {
        readonly agent: AgentLike
        readonly turn: number
        readonly step: number
        readonly signal: AbortSignal
      },
      next: () => Promise<unknown>,
    ): Promise<unknown>
    'tools/execute'(
      exec: ToolExecutionLike,
      next: () => Promise<unknown>,
    ): Promise<unknown>
  }
}

export const REWIND_HTTP_PATH = '/turn-rewind'
const BODY_LIMIT = 64 * 1024
const INITIAL_CHANGE_PREVIEW_LIMIT = 8
const MAX_CHANGE_PAGE_SIZE = 200

/** Capture each turn beside model work and gate root tool side effects on its bounded outcome. */
export class TurnCheckpointCoordinator {
  private readonly captures = new Map<string, Promise<void>>()
  private readonly pending = new Set<string>()
  private readonly failures = new Map<string, string>()
  private readonly skips = new Map<string, string>()
  private readonly workspaceTails = new Map<string, Promise<void>>()

  constructor(private readonly engine: ChangeLedgerEngine) {}

  /** Keep sidecar checkpoint work out of the Agent response waterfall. */
  install(ctx: Context): void {
    ctx.on('agent/pre-step', async ({ agent, turn, step, signal }, next) => {
      if (step === 1) this.startCapture(ctx, agent, turn, signal)
      return next()
    }, { prepend: true })

    ctx.on('tools/execute', async (exec, next) => {
      if (exec.agent !== undefined && exec.parent === undefined) {
        await this.waitForOpenTurn(exec.agent, exec.signal)
      }
      return next()
    }, { prepend: true })
  }

  /** Current capture state for a session turn when no durable checkpoint exists yet. */
  state(sessionId: string, turn: number): { readonly status: 'pending' | 'failed' | 'skipped' | 'missing'; readonly error?: string; readonly reason?: string } {
    const key = checkpointKey(sessionId, turn)
    if (this.pending.has(key)) return { status: 'pending' }
    const reason = this.skips.get(key)
    if (reason !== undefined) return { status: 'skipped', reason }
    const error = this.failures.get(key)
    return error === undefined ? { status: 'missing' } : { status: 'failed', error }
  }

  private startCapture(
    ctx: Pick<Context, 'logger'>,
    agent: AgentLike,
    turn: number,
    signal: AbortSignal,
  ): void {
    const key = checkpointKey(agent.id, turn)
    if (this.captures.has(key)) return
    const capture = this.capture(ctx, agent, turn, signal).catch(async (error: unknown) => {
      await this.recordFailure(ctx, agent.id, turn, error)
    })
    this.captures.set(key, capture)
  }

  private async capture(
    ctx: Pick<Context, 'logger'>,
    agent: AgentLike,
    turn: number,
    signal: AbortSignal,
  ): Promise<void> {
    const key = checkpointKey(agent.id, turn)
    const cwd = agent.session.header.cwd
    if (cwd === undefined) return
    const events = getSessionEvents(agent.session)
    const start = events.findLast(event => event.type === 'turn/start' && event.data.turn === turn)
    if (start === undefined) {
      await this.recordFailure(ctx, agent.id, turn, new Error('turn/start is unavailable before the first step'))
      return
    }
    const timeoutMs = this.engine.config.turnCheckpointTimeoutMs
    const outcomeDeadline = createDeadline(timeoutMs)
    const outcomeSignal = AbortSignal.any([signal, outcomeDeadline.signal])
    const reserveMs = Math.min(250, Math.max(10, Math.ceil(timeoutMs / 5)))
    const captureDeadline = createDeadline(Math.max(1, timeoutMs - reserveMs))
    const captureSignal = AbortSignal.any([signal, captureDeadline.signal])
    try {
      this.pending.add(key)
      this.failures.delete(key)
      this.skips.delete(key)
      const capture = (async () => {
        try {
          const workspace = await discoverWorkspaceRoot(cwd, captureSignal)
          await this.serializeWorkspace(workspace, captureSignal, async () => {
            try {
              await this.engine.createTurnCheckpoint({
                cwd: workspace,
                sessionId: agent.id,
                turn,
                turnStartSeq: start.seq,
                signal: captureSignal,
              })
            } catch (error) {
              await this.recordFailure(
                ctx,
                agent.id,
                turn,
                checkpointTimeoutError(error, timeoutMs, captureDeadline.signal, signal),
                { cwd: workspace, turnStartSeq: start.seq },
              )
            }
          })
        } catch (error) {
          await this.recordFailure(
            ctx,
            agent.id,
            turn,
            checkpointTimeoutError(error, timeoutMs, captureDeadline.signal, signal),
            { cwd, turnStartSeq: start.seq },
          )
        } finally {
          this.pending.delete(key)
        }
      })()
      try {
        await waitWithSignal(capture, outcomeSignal)
      } catch (error) {
        const bounded = checkpointTimeoutError(error, timeoutMs, outcomeDeadline.signal, signal)
        const message = errorMessage(bounded)
        this.pending.delete(key)
        if (bounded instanceof ChangeLedgerError && isCheckpointSkip(bounded.code)) {
          this.skips.set(key, message)
        } else {
          this.failures.set(key, message)
        }
      }
    } finally {
      captureDeadline.cancel()
      outcomeDeadline.cancel()
    }
  }

  /** Wait only for the bounded checkpoint outcome of the Agent's open turn. */
  private async waitForOpenTurn(agent: AgentLike, signal: AbortSignal): Promise<void> {
    if (signal.aborted) return
    const events = getSessionEvents(agent.session)
    const boundary = events.findLast(event => event.type === 'turn/start' || event.type === 'turn/end')
    if (boundary?.type !== 'turn/start') return
    const turn = boundary.data.turn
    if (!Number.isSafeInteger(turn) || (turn as number) < 0) return
    const capture = this.captures.get(checkpointKey(agent.id, turn as number))
    if (capture === undefined) return
    try {
      await waitWithSignal(capture, signal)
    } catch (error) {
      // Delegate caller cancellation so the DSH tool runtime preserves its
      // canonical ABORTED_BEFORE_DISPATCH result instead of a wrapper error.
      if (!signal.aborted) throw error
    }
  }

  private async serializeWorkspace(workspace: string, signal: AbortSignal, task: () => Promise<void>): Promise<void> {
    const previous = this.workspaceTails.get(workspace) ?? Promise.resolve()
    const current = (async () => {
      await waitWithSignal(previous.catch(() => undefined), signal)
      signal.throwIfAborted()
      await task()
    })()
    this.workspaceTails.set(workspace, current)
    try {
      await current
    } finally {
      if (this.workspaceTails.get(workspace) === current) this.workspaceTails.delete(workspace)
    }
  }

  private async recordFailure(
    ctx: Pick<Context, 'logger'>,
    sessionId: string,
    turn: number,
    error: unknown,
    skipContext?: { readonly cwd: string; readonly turnStartSeq: number },
  ): Promise<void> {
    const message = errorMessage(error)
    if (error instanceof ChangeLedgerError && isCheckpointSkip(error.code)) {
      this.skips.set(checkpointKey(sessionId, turn), message)
      if (skipContext !== undefined) {
        try {
          await this.engine.recordTurnCheckpointSkip({
            cwd: skipContext.cwd,
            sessionId,
            turn,
            turnStartSeq: skipContext.turnStartSeq,
            reason: message,
          })
        } catch (persistError) {
          ctx.logger.warn(`[turn-rewind] could not persist checkpoint skip for ${sessionId} turn ${String(turn)}: ${errorMessage(persistError)}`)
        }
      }
      ctx.logger.warn(`[turn-rewind] checkpoint skipped for ${sessionId} turn ${String(turn)}: ${message}`)
      return
    }
    this.failures.set(checkpointKey(sessionId, turn), message)
    ctx.logger.warn(`[turn-rewind] checkpoint failed for ${sessionId} turn ${String(turn)}: ${message}`)
  }
}

function isCheckpointSkip(code: string): boolean {
  return code === 'TURN_CHECKPOINT_DISABLED'
    || code === 'TURN_CHECKPOINT_TIMEOUT'
    || code === 'TURN_CHECKPOINT_NEW_CONTENT_LIMIT'
    || code === 'GIT_OBJECT_STORE_UNSUPPORTED'
    || code === 'GIT_INDEX_UNSUPPORTED'
}

async function waitWithSignal<T>(promise: Promise<T>, signal: AbortSignal): Promise<T> {
  signal.throwIfAborted()
  let rejectAbort: ((reason?: unknown) => void) | undefined
  const aborted = new Promise<never>((_resolve, reject) => { rejectAbort = reject })
  const onAbort = () => rejectAbort?.(signal.reason)
  signal.addEventListener('abort', onAbort, { once: true })
  try {
    return await Promise.race([promise, aborted])
  } finally {
    signal.removeEventListener('abort', onAbort)
  }
}

function checkpointTimeoutError(
  error: unknown,
  timeoutMs: number,
  deadline: AbortSignal,
  callerSignal: AbortSignal,
): unknown {
  if (!callerSignal.aborted && deadline.aborted) {
    return new ChangeLedgerError('TURN_CHECKPOINT_TIMEOUT', `automatic checkpoint exceeded ${timeoutMs} ms`, { cause: error })
  }
  return error
}

/** Register the same-origin preview/apply endpoint consumed by the browser half. */
export function installRewindHttp(
  ctx: Context,
  engine: ChangeLedgerEngine,
  coordinator: TurnCheckpointCoordinator,
): void {
  ctx.effect(() => ctx.webServer.register({
    kind: 'exact',
    path: REWIND_HTTP_PATH,
    handler: createRewindHttpHandler(ctx, engine, coordinator),
  }), 'change-ledger.rewindHttp')
}

/** Build the exact-route handler as a testable unit. */
export function createRewindHttpHandler(
  ctx: ConversationRestartContext & { readonly agents?: AgentsLike },
  engine: ChangeLedgerEngine,
  coordinator: TurnCheckpointCoordinator,
): (request: HttpRequestLike, response: HttpResponseLike) => Promise<void> {
  return async (request, response) => {
    try {
      if (request.method === 'GET') {
        const url = new URL(request.url ?? REWIND_HTTP_PATH, 'http://dsh.local')
        const sessionId = requiredText(url.searchParams.get('sessionId'), 'sessionId')
        const messageSeq = nonNegativeInteger(url.searchParams.get('messageSeq'), 'messageSeq')
        const detailsOnly = url.searchParams.get('details') === '1'
        const offset = nonNegativeInteger(url.searchParams.get('offset') ?? '0', 'offset')
        const limit = pageSize(url.searchParams.get('limit'), detailsOnly ? MAX_CHANGE_PAGE_SIZE : INITIAL_CHANGE_PREVIEW_LIMIT)
        const { target, checkpoint } = await resolveMessageCheckpoint(ctx, engine, sessionId, messageSeq)
        if (checkpoint === undefined) {
          const durableSkip = await engine.findTurnCheckpointSkip({
            cwd: target.cwd,
            sessionId,
            turn: target.turn,
            turnStartSeq: target.turnStartSeq,
          })
          json(response, 200, durableSkip === undefined
            ? coordinator.state(sessionId, target.turn)
            : { status: 'skipped', reason: durableSkip.reason })
          return
        }
        const inspection = await engine.inspect({ cwd: checkpoint.cwd, restorePointId: checkpoint.id })
        const activeSessionIds = await sharedWorkspaceSessions(ctx.agents, checkpoint.cwd)
        const changes = inspection.changes.slice(offset, offset + limit)
        const common = {
          status: 'ready', sessionId, messageSeq, turn: checkpoint.turn, checkpointId: checkpoint.id,
          // A restore point that could not store every eligible path stays usable;
          // the browser shows what was left out instead of blocking the rewind.
          skippedCount: inspection.restorePoint.skippedCount,
          ...(inspection.restorePoint.skipped === undefined ? {} : { skipped: inspection.restorePoint.skipped }),
          ...(inspection.restorePoint.truncated === undefined ? {} : { captureTruncated: inspection.restorePoint.truncated }),
          turnStartSeq: checkpoint.turnStartSeq,
          totalChanges: inspection.changes.length,
          changes: changes.map(change => ({ path: change.path, kind: change.kind })),
          offset,
          truncated: offset + changes.length < inspection.changes.length,
          headChanged: inspection.headChanged,
          operationChanged: inspection.operationChanged,
          checkpointHead: inspection.restorePoint.head,
          checkpointBranch: inspection.restorePoint.branch,
          checkpointOperation: inspection.restorePoint.operation,
          currentHead: inspection.currentHead,
          currentBranch: inspection.currentBranch,
          currentOperation: inspection.currentOperation,
          activeSessionIds,
          restoreBlocked: activeSessionIds.length > 0 || inspection.operationChanged,
        } as const
        if (inspection.changes.length === 0) {
          json(response, 200, common)
          return
        }
        if (detailsOnly || activeSessionIds.length > 0 || inspection.operationChanged) {
          json(response, 200, common)
          return
        }
        const plan = await engine.planRestore({
          cwd: checkpoint.cwd,
          restorePointId: checkpoint.id,
          sessionId,
          allowHeadChange: inspection.headChanged,
          expectedCurrentTreeHash: inspection.currentTreeHash,
          expectedRepository: inspection.currentRepository,
        })
        json(response, 200, { ...common, planId: plan.id, confirmation: plan.confirmation })
        return
      }
      if (request.method === 'POST') {
        const body = objectBody(await readBody(request))
        const mode = body.mode
        if (mode !== 'code' && mode !== 'both' && mode !== 'messages') {
          throw new ChangeLedgerError('INVALID_ARGUMENTS', 'mode must be "code", "both", or "messages"')
        }
        const sessionId = requiredText(body.sessionId, 'sessionId')
        const messageSeq = nonNegativeInteger(body.messageSeq, 'messageSeq')
        // Messages-only rewind never reads or writes project files, so it needs
        // neither a checkpoint nor an exclusive workspace: it resolves the turn
        // boundary straight from the Session log and forks there.
        if (mode === 'messages') {
          const target = messageTarget(await readSession(ctx, sessionId), messageSeq)
          const fork = await createConversationRestart(ctx, sessionId, target)
          json(response, 200, { status: 'completed', mode, sessionId: fork.sessionId })
          return
        }
        const checkpointId = requiredText(body.checkpointId, 'checkpointId')
        const checkpoint = await checkpointForRequest(ctx, engine, sessionId, messageSeq, checkpointId)
        const activeSessionIds = await sharedWorkspaceSessions(ctx.agents, checkpoint.cwd)
        if (activeSessionIds.length > 0) {
          throw new ChangeLedgerError(
            'WORKSPACE_IN_USE',
            `project files are also used by active sessions: ${activeSessionIds.slice(0, 5).join(', ')}`,
          )
        }
        const planId = optionalText(body.planId, 'planId')
        const confirmation = optionalText(body.confirmation, 'confirmation')
        if (planId === undefined || confirmation === undefined) {
          throw new ChangeLedgerError('NO_CHANGES', 'the selected turn has no project files to restore')
        }
        const restoreResult = await engine.applyRestore({ planId, confirmation, sessionId })
        if (mode === 'code') {
          json(response, 200, { status: 'completed', mode, ...restoreResult })
          return
        }

        try {
          const fork = await createConversationRestart(ctx, sessionId, checkpoint)
          json(response, 200, { status: 'completed', mode, sessionId: fork.sessionId, ...restoreResult })
        } catch (forkError) {
          if (restoreResult === undefined) throw forkError
          try {
            const rollbackPlan = await engine.planRestore({
              cwd: checkpoint.cwd,
              restorePointId: restoreResult.rescuePointId,
              sessionId,
            })
            await engine.applyRestore({
              planId: rollbackPlan.id,
              confirmation: rollbackPlan.confirmation,
              sessionId,
            })
          } catch (rollbackError) {
            throw new AggregateError([forkError, rollbackError], 'conversation fork failed and code compensation also failed')
          }
          throw new ChangeLedgerError(
            'RESTORE_FAILED_ROLLED_BACK',
            `conversation fork failed; code was recovered from ${restoreResult.rescuePointId}: ${errorMessage(forkError)}`,
            { cause: forkError },
          )
        }
        return
      }
      json(response, 405, { error: 'method not allowed' })
    } catch (error) {
      const status = error instanceof ChangeLedgerError && error.code === 'RESTORE_POINT_NOT_FOUND' ? 404 : 409
      json(response, status, { error: errorMessage(error), code: error instanceof ChangeLedgerError ? error.code : 'REWIND_FAILED' })
    }
  }
}

async function readSession(
  ctx: Pick<Context, 'sessions' | 'sessionQuery'>,
  sessionId: string,
): Promise<SessionLike> {
  const live = ctx.sessions.get(sessionId)
  if (live !== undefined) return live
  const stored = await ctx.sessionQuery.readSession(sessionId)
  return {
    id: sessionId,
    header: stored.session,
    events: stored.events,
    ...(stored.inheritedEventCount === undefined ? {} : { inheritedEventCount: stored.inheritedEventCount }),
  }
}

/**
 * Fork-inherited prefix length reported by the host, or `undefined` when the host
 * exposes no such datum.
 *
 * DSH releases before 0.1.5 carried it as `header.seedLength`; 0.1.5 deleted that
 * field (a stored header still carrying it is rejected) and publishes the same
 * quantity as `inheritedEventCount` on the live session and on its stored snapshot.
 * @param session - live or stored session to read the lineage boundary from.
 * @returns the inherited prefix length in events.
 */
function lineageBoundary(session: SessionLike): number | undefined {
  const legacy = session.header.seedLength
  if (typeof legacy === 'number') return legacy
  const current = session.inheritedEventCount
  return typeof current === 'number' ? current : undefined
}

interface MessageTarget {
  readonly messageSeq: number
  readonly turn: number
  readonly turnStartSeq: number
  readonly previousTurnEndSeq?: number
  readonly cwd: string
}

interface MessageCheckpoint extends MessageTarget {
  readonly id: string
}

async function resolveMessageCheckpoint(
  ctx: Pick<Context, 'sessions' | 'sessionQuery'>,
  engine: ChangeLedgerEngine,
  sessionId: string,
  messageSeq: number,
): Promise<{ readonly target: MessageTarget; readonly checkpoint?: MessageCheckpoint }> {
  let current = await readSession(ctx, sessionId)
  const target = messageTarget(current, messageSeq)
  const direct = await engine.findTurnCheckpoint({ cwd: target.cwd, sessionId, turn: target.turn })
  if (direct !== undefined) {
    if (direct.turnStartSeq !== target.turnStartSeq) {
      throw new ChangeLedgerError('PLAN_STALE', 'the message checkpoint no longer matches its turn start')
    }
    return { target, checkpoint: { ...target, id: direct.id } }
  }

  const seen = new Set<string>([sessionId])
  while (true) {
    const parentId = current.header.parentSession
    // A session is lineage-bound exactly when it declares a parent, and only then is
    // the inherited-prefix length meaningful. 0.1.5 reports `0` — not `undefined` —
    // for a session with no inherited prefix, so the datum must never be consulted
    // for a root session or this guard inverts and rejects every unforked session.
    const boundary = parentId === undefined ? undefined : lineageBoundary(current)
    if ((parentId === undefined) !== (boundary === undefined)) {
      throw new ChangeLedgerError('PLAN_STALE', 'session fork lineage has incomplete parent metadata')
    }
    if (parentId === undefined || boundary === undefined
      || target.messageSeq >= boundary || target.turnStartSeq >= boundary) {
      return { target }
    }
    if (seen.has(parentId)) {
      throw new ChangeLedgerError('PLAN_STALE', 'session fork lineage contains a cycle')
    }
    seen.add(parentId)
    try {
      current = await readSession(ctx, parentId)
    } catch (error) {
      throw new ChangeLedgerError('PLAN_STALE', `parent session ${parentId} is unavailable`, { cause: error })
    }
    const parentTarget = messageTarget(current, messageSeq)
    if (parentTarget.turn !== target.turn
      || parentTarget.turnStartSeq !== target.turnStartSeq
      || parentTarget.previousTurnEndSeq !== target.previousTurnEndSeq) {
      throw new ChangeLedgerError('PLAN_STALE', 'session fork lineage no longer matches the inherited message boundary')
    }
    const inherited = await engine.findTurnCheckpoint({ cwd: target.cwd, sessionId: parentId, turn: target.turn })
    if (inherited === undefined) continue
    if (inherited.turnStartSeq !== target.turnStartSeq) {
      throw new ChangeLedgerError('PLAN_STALE', 'the inherited message checkpoint no longer matches the fork boundary')
    }
    return { target, checkpoint: { ...target, id: inherited.id } }
  }
}

async function checkpointForRequest(
  ctx: Pick<Context, 'sessions' | 'sessionQuery'>,
  engine: ChangeLedgerEngine,
  sessionId: string,
  messageSeq: number,
  requestedId: string,
): Promise<MessageCheckpoint> {
  const { target, checkpoint } = await resolveMessageCheckpoint(ctx, engine, sessionId, messageSeq)
  if (checkpoint === undefined) {
    throw new ChangeLedgerError('RESTORE_POINT_NOT_FOUND', `message ${String(target.messageSeq)} has no rewind checkpoint`)
  }
  if (requestedId !== checkpoint.id) {
    throw new ChangeLedgerError('PLAN_STALE', 'the selected message checkpoint changed; reopen the rewind dialog')
  }
  return checkpoint
}

async function createConversationRestart(
  ctx: ConversationRestartContext,
  sourceId: string,
  checkpoint: MessageTarget,
): Promise<{ readonly sessionId: string }> {
  const source = await readSession(ctx, sourceId)
  const current = messageTarget(source, checkpoint.messageSeq)
  if (current.turn !== checkpoint.turn
    || current.turnStartSeq !== checkpoint.turnStartSeq
    || current.previousTurnEndSeq !== checkpoint.previousTurnEndSeq) {
    throw new ChangeLedgerError('PLAN_STALE', 'the session no longer contains the selected message boundary')
  }
  // Cordis throws when a context reads a service property it did not inject, and
  // no single inject list covers both carriers: 0.1.1 provides `apiProxy` while
  // 0.1.2-alpha provides `sessionController`. `ctx.get` is the optional accessor
  // that returns undefined instead of failing the request.
  const controller = ctx.get('sessionController') as SessionControllerLike | undefined
  if (controller !== undefined) {
    // Modern hosts require workspace membership independently of Session cwd.
    // Preserve the source association; never guess a workspace from its path.
    const registry = ctx.get('workspaceRegistry') as {
      list(): readonly { readonly id: string; readonly sessionIds: readonly string[] }[]
    } | undefined
    const workspace = registry?.list().find(candidate => candidate.sessionIds.includes(sourceId))
    const created = checkpoint.previousTurnEndSeq === undefined
      ? await controller.create(workspace === undefined ? { cwd: checkpoint.cwd } : { workspaceId: workspace.id })
      : await controller.fork({ sessionId: sourceId, atSeq: checkpoint.previousTurnEndSeq })
    return { sessionId: requiredText(created.sessionId, 'sessionController sessionId') }
  }
  const apiProxy = ctx.get('apiProxy') as ApiProxyLike | undefined
  if (apiProxy === undefined) {
    throw new ChangeLedgerError(
      'CONVERSATION_REWIND_FAILED',
      'this DSH host exposes neither sessionController nor apiProxy, so a new conversation cannot be created',
    )
  }
  const response = checkpoint.previousTurnEndSeq === undefined
    ? await apiProxy.sessions.create({
        rpcId: randomUUID(),
        payload: { cwd: checkpoint.cwd },
      })
    : await apiProxy.sessions.fork({
        rpcId: randomUUID(),
        payload: { sessionId: sourceId, atSeq: checkpoint.previousTurnEndSeq },
      })
  if (!response.result.ok) {
    throw new ChangeLedgerError('CONVERSATION_REWIND_FAILED', response.result.error.message)
  }
  return { sessionId: requiredText(response.result.value.sessionId, 'fork sessionId') }
}

function messageTarget(session: SessionLike, messageSeq: number): MessageTarget {
  const cwd = session.header.cwd
  if (cwd === undefined) throw new ChangeLedgerError('WORKSPACE_REQUIRED', `session ${session.id} has no workspace`)
  const events = getSessionEvents(session)
  const message = events.find(event => event.type === 'user/message' && event.seq === messageSeq && isDirectUserMessage(event))
  if (message === undefined) {
    throw new ChangeLedgerError('RESTORE_POINT_NOT_FOUND', `session ${session.id} has no user message at ${String(messageSeq)}`)
  }
  const start = events.findLast(event => event.type === 'turn/start' && event.seq < messageSeq)
  const turn = start?.data.turn
  if (start === undefined || !Number.isSafeInteger(turn) || (turn as number) < 0) {
    throw new ChangeLedgerError('PLAN_STALE', 'the selected user message has no valid turn start')
  }
  const openingMessage = events.find(event => (
    event.type === 'user/message'
    && event.seq > start.seq
    && event.seq <= messageSeq
    && isDirectUserMessage(event)
  ))
  if (openingMessage?.seq !== messageSeq) {
    throw new ChangeLedgerError('RESTORE_POINT_NOT_FOUND', 'rewind is available only for the opening user message of a turn')
  }
  const interveningEnd = events.find(event => event.type === 'turn/end' && event.seq > start.seq && event.seq < messageSeq)
  if (interveningEnd !== undefined) {
    throw new ChangeLedgerError('PLAN_STALE', 'the selected user message is outside its recorded turn')
  }
  const previousEnd = events.findLast(event => event.type === 'turn/end' && event.seq < start.seq)
  return {
    messageSeq,
    turn: turn as number,
    turnStartSeq: start.seq,
    ...(previousEnd === undefined ? {} : { previousTurnEndSeq: previousEnd.seq }),
    cwd,
  }
}

function isDirectUserMessage(event: SessionEventLike): boolean {
  const source = event.data.source
  return source !== null && typeof source === 'object' && !Array.isArray(source)
    && (source as Record<string, unknown>).kind === 'user'
}

function checkpointKey(sessionId: string, turn: number): string {
  return `${sessionId}\0${String(turn)}`
}

function requiredText(value: unknown, name: string): string {
  if (typeof value !== 'string' || value === '') throw new ChangeLedgerError('INVALID_ARGUMENTS', `${name} must be a non-empty string`)
  return value
}

function optionalText(value: unknown, name: string): string | undefined {
  return value === undefined ? undefined : requiredText(value, name)
}

function nonNegativeInteger(value: unknown, name: string): number {
  const parsed = typeof value === 'string' && /^\d+$/.test(value) ? Number(value) : value
  if (!Number.isSafeInteger(parsed) || (parsed as number) < 0) {
    throw new ChangeLedgerError('INVALID_ARGUMENTS', `${name} must be a non-negative safe integer`)
  }
  return parsed as number
}

function pageSize(value: unknown, fallback: number): number {
  if (value === null || value === undefined) return fallback
  const parsed = nonNegativeInteger(value, 'limit')
  if (parsed < 1 || parsed > MAX_CHANGE_PAGE_SIZE) {
    throw new ChangeLedgerError('INVALID_ARGUMENTS', `limit must be between 1 and ${String(MAX_CHANGE_PAGE_SIZE)}`)
  }
  return parsed
}

async function sharedWorkspaceSessions(
  agents: AgentsLike | undefined,
  cwd: string,
): Promise<readonly string[]> {
  const listed = agents?.list() ?? []
  if (listed.length === 0) return []
  const root = await discoverWorkspaceRoot(cwd)
  const shared: string[] = []
  for (const agent of listed) {
    if (agent.status !== 'running') continue
    const session = agent.session
    if (session.header.cwd === undefined) continue
    try {
      if (await discoverWorkspaceRoot(session.header.cwd) === root) shared.push(session.id)
    } catch {
      // A live Session whose cwd cannot be resolved cannot share this workspace.
    }
  }
  return shared.sort()
}

function objectBody(value: unknown): Record<string, unknown> {
  if (value === null || typeof value !== 'object' || Array.isArray(value)) {
    throw new ChangeLedgerError('INVALID_ARGUMENTS', 'request body must be an object')
  }
  return value as Record<string, unknown>
}

async function readBody(request: HttpRequestLike): Promise<unknown> {
  const chunks: Buffer[] = []
  let size = 0
  await new Promise<void>((resolve, reject) => {
    request.on('data', (chunk) => {
      const bytes = Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk)
      size += bytes.length
      if (size > BODY_LIMIT) {
        reject(new ChangeLedgerError('INVALID_ARGUMENTS', 'request body is too large'))
        return
      }
      chunks.push(bytes)
    })
    request.on('end', resolve)
    request.on('error', reject)
  })
  try {
    return JSON.parse(Buffer.concat(chunks).toString('utf8')) as unknown
  } catch (error) {
    throw new ChangeLedgerError('INVALID_ARGUMENTS', 'request body must be valid JSON', { cause: error })
  }
}

function json(response: HttpResponseLike, status: number, value: unknown): void {
  response.writeHead(status, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' })
  response.end(`${JSON.stringify(value)}\n`)
}

export const MANAGE_HTTP_PATH = '/turn-rewind/manage'

/** Register the same-origin storage-management endpoint consumed by the settings card. */
export function installManageHttp(ctx: Context, engine: ChangeLedgerEngine): void {
  ctx.effect(() => ctx.webServer.register({
    kind: 'exact',
    path: MANAGE_HTTP_PATH,
    handler: createManageHttpHandler(engine),
  }), 'change-ledger.manageHttp')
}

/** Build the storage-management route as a testable unit. */
export function createManageHttpHandler(
  engine: ChangeLedgerEngine,
): (request: HttpRequestLike, response: HttpResponseLike) => Promise<void> {
  return async (request, response) => {
    try {
      if (request.method === 'GET') {
        const workspaces = await engine.listWorkspaces()
        json(response, 200, {
          storageDir: engine.config.storageDir,
          totalBytes: workspaces.reduce((total, workspace) => total + workspace.totalBytes, 0),
          workspaces: workspaces.map((workspace) => ({
            workspace: workspace.workspace,
            totalBytes: workspace.totalBytes,
            recoveryCount: workspace.recoveryCount,
            restorePoints: workspace.restorePoints.map((point) => ({
              id: point.id,
              kind: point.kind,
              format: point.format,
              createdAt: point.createdAt,
              totalBytes: point.totalBytes,
              fileCount: point.fileCount,
              ...(point.sessionId === undefined ? {} : { sessionId: point.sessionId }),
              ...(point.turn === undefined ? {} : { turn: point.turn }),
              ...(point.label === undefined ? {} : { label: point.label }),
            })),
          })),
        })
        return
      }
      if (request.method === 'POST') {
        const body = objectBody(await readBody(request))
        const action = requiredText(body.action, 'action')
        if (action === 'delete') {
          const workspace = requiredText(body.workspace, 'workspace')
          const restorePointId = requiredText(body.restorePointId, 'restorePointId')
          const report = await engine.purgeWorkspace({ workspace, restorePointIds: [restorePointId] })
          if (report.deletedRestorePoints === 0) {
            throw new ChangeLedgerError(
              report.retainedRestorePoints > 0 ? 'RECOVERY_REFERENCE' : 'RESTORE_POINT_NOT_FOUND',
              report.retainedRestorePoints > 0
                ? 'restore point is required by an incomplete recovery journal'
                : `restore point ${restorePointId} does not exist`,
            )
          }
          json(response, 200, { status: 'completed', action, ...report })
          return
        }
        throw new ChangeLedgerError('INVALID_ARGUMENTS', `unsupported manage action ${action}`)
      }
      response.writeHead(405, { allow: 'GET, POST' })
      response.end()
    } catch (error) {
      const status = error instanceof ChangeLedgerError && error.code === 'RESTORE_POINT_NOT_FOUND' ? 404 : 409
      json(response, status, { error: errorMessage(error), code: error instanceof ChangeLedgerError ? error.code : 'MANAGE_FAILED' })
    }
  }
}
