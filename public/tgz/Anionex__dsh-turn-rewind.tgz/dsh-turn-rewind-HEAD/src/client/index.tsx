import { useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState, useSyncExternalStore, type ReactNode } from 'react'
import { createPortal } from 'react-dom'
import {
  Button,
  Modal,
  Tooltip,
} from '@deepseek-ai/dsh-client-ui-primitives'

/** Durable reference carried by one `image` / `file` content block. */
interface AttachmentRefLike {
  readonly attachmentId?: string
  readonly name?: string
  readonly mediaType?: string
  readonly bytes?: number
}

interface ConversationNodeLike {
  readonly kind: string
  readonly seq: number
  readonly content?: readonly {
    readonly type: string
    readonly text?: string
    readonly attachment?: AttachmentRefLike
  }[]
}

interface ConversationChatNodeLike {
  readonly key: string
  readonly kind: string
  readonly data: ConversationNodeLike
}

/**
 * Chat node store exposed by the Chat target. DSH 0.1.2+ publishes a mutable
 * keyed store; older clients published a Map with the same `get` contract.
 */
interface ChatNodeStoreLike {
  get(key: string): RewindNodeLike | undefined
  values?(): Iterable<RewindNodeLike>
}

/** Chat projection shared by `session.chat` (0.1.1) and the `useChat` hook (0.1.2+). */
interface ChatSnapshotLike {
  readonly order?: readonly string[]
  readonly nodes?: ChatNodeStoreLike | readonly RewindNodeLike[]
}

/**
 * Snapshot seen by a session-scoped slot entry. 0.1.1 exposes the chat
 * projection as `snapshot.chat`; 0.1.2+ moved it to the separate `useChat`
 * hook, so the same snapshot is the chat projection itself.
 */
interface ConversationSnapshotLike extends ChatSnapshotLike {
  readonly chat?: ChatSnapshotLike
}

/** Selector hook shape shared by `useSession` and `useChat`. */
type SnapshotSelectorHook = <T>(selector: (snapshot: ConversationSnapshotLike) => T) => T

type RewindNodeLike = ConversationNodeLike | ConversationChatNodeLike

/** One durable attachment that the restart has to hand back to the composer. */
interface RewindAttachment {
  readonly kind: 'image' | 'file'
  readonly attachmentId: string
  readonly name: string
  readonly mediaType: string
  readonly sourceSessionId?: string
  readonly messageSeq?: number
}

interface RewindMatch {
  readonly messageSeq: number
  readonly promptText: string
  /** Present only when the message carried attachments; absent keeps older doubles valid. */
  readonly attachments?: readonly RewindAttachment[]
}

interface RewindMessageActionProps {
  readonly matched: RewindMatch
  readonly sessionId: string
  readonly openRestoredSession: (
    sessionId: string,
    promptText: string,
    attachments?: readonly RewindAttachment[],
  ) => Promise<void>
}

interface RewindPortalBridgeProps {
  readonly sessionId: string
  readonly openRestoredSession: (
    sessionId: string,
    promptText: string,
    attachments?: readonly RewindAttachment[],
  ) => Promise<void>
  /**
   * Legacy 0.1.x chat snapshot hooks kept optional for older test doubles and
   * hosts; DSH 0.2.0 stopped injecting them, so the bridge reads the Host turn
   * anchor endpoint instead.
   */
  readonly useSession?: SnapshotSelectorHook
  readonly useChat?: SnapshotSelectorHook
}

interface RewindPortalTarget {
  readonly container: HTMLElement
  readonly matched: RewindMatch
}

interface SlotsLike {
  inject(name: string, install: () => unknown): void
  register<I, P>(
    entry: {
      readonly name: string
      readonly id?: string
      readonly key?: string
      readonly order?: number
      readonly label?: string | (() => string)
      readonly locale?: string
      readonly inject?: () => I
    },
    component: (props: P) => ReactNode,
  ): () => void
}

/** Immutable locale state published by `@deepseek-ai/dsh-client-locale`. */
interface LocaleSnapshotLike {
  /** Active locale id, a BCP 47-style tag such as `zh` or `en`. */
  readonly active: string
}

/** The part of the Host locale service this plugin reads. */
interface LocaleRuntimeLike {
  getSnapshot(): LocaleSnapshotLike
}

interface ClientContextLike {
  readonly slots: SlotsLike
  readonly sessions: {
    open?(sessionId: string): void
    scope(sessionId: string): unknown | undefined
  }
  readonly conversation: {
    readonly input: {
      for(scope: unknown): { setDraft(text: string): void; addAttachments?(ids: readonly string[]): boolean; notify?(level: 'info' | 'error', text: string): void }
    }
  }
  get?(name: string): unknown
  effect(setup: () => (() => void), label?: string): unknown
  /**
   * Cordis's un-injected service read: the service value, or `undefined` when
   * the profile mounts none. Optional because older clients and the test
   * doubles expose no such method.
   */
  get?(name: 'locale'): LocaleRuntimeLike | undefined
  /** Cordis's event subscription; the result is a disposer when it is one. */
  on?(name: 'locale/change', listener: (snapshot: LocaleSnapshotLike) => void): unknown
}

type RewindMode = 'both' | 'code' | 'messages'
type ChangeKind = 'added' | 'deleted' | 'modified' | 'mode-changed' | 'type-changed'

interface ReadyPreview {
  readonly status: 'ready'
  readonly sessionId: string
  readonly messageSeq: number
  readonly turn: number
  readonly checkpointId: string
  readonly turnStartSeq: number
  readonly totalChanges: number
  readonly changes: readonly { readonly path: string; readonly kind: ChangeKind }[]
  readonly offset: number
  readonly truncated: boolean
  /** Eligible paths the checkpoint could not store; a restore never touches them. */
  readonly skippedCount: number
  readonly skipped: readonly { readonly path: string; readonly reason: string }[]
  /** Set when limits stopped the capture before every eligible path was read. */
  readonly captureTruncated?: 'file-limit' | 'snapshot-limit'
  readonly headChanged: boolean
  readonly operationChanged: boolean
  readonly checkpointHead?: string
  readonly checkpointBranch?: string
  readonly checkpointOperation?: string
  readonly currentHead?: string
  readonly currentBranch?: string
  readonly currentOperation?: string
  readonly activeSessionIds: readonly string[]
  readonly restoreBlocked: boolean
  readonly planId?: string
  readonly confirmation?: string
}

type Preview = ReadyPreview
  | { readonly status: 'pending' }
  | { readonly status: 'missing' }
  | { readonly status: 'skipped'; readonly reason: string }
  | { readonly status: 'failed'; readonly error: string }

/** Runtime-tunable Turn Rewind settings mirrored from the `turn-rewind` namespace. */
export interface TurnRewindSettingsValue {
  readonly maxRestorePoints: number
  readonly maxTurnCheckpointsPerSession: number
  readonly maxFiles: number
  readonly maxFileBytes: number
  readonly maxSnapshotBytes: number
  readonly planTtlMs: number
  readonly staleLockMs: number
  readonly turnCheckpointMode: 'off' | 'auto' | 'git-native' | 'legacy'
  readonly turnCheckpointTimeoutMs: number
  readonly turnCheckpointMaxNewBytes: number
  readonly turnCheckpointTrust: 'fast' | 'strict'
}

/** Browser settings transport shared by the old namespace and new Config form. */
export interface SettingsScopeLike<T> {
  getSnapshot(): SettingsScopeSnapshotLike<T>
  subscribe(listener: () => void): () => void
  set(field: string, value: unknown): Promise<void>
  unset(field: string): Promise<void>
}

/** Sync snapshot shape shared by every settings scope. */
export interface SettingsScopeSnapshotLike<T> {
  readonly status: 'loading' | 'ready' | 'unavailable'
  readonly value: T | undefined
  readonly base: unknown
  readonly user: unknown
  readonly revision: number | undefined
  readonly writable: boolean
  readonly mode: 'host' | 'memory'
}

/** One checkpoint row in the storage-management overview. */
export interface ManageRestorePoint {
  readonly id: string
  readonly kind: string
  readonly format: number
  readonly createdAt: number
  readonly totalBytes: number
  readonly fileCount: number
  readonly sessionId?: string
  readonly label?: string
}

/** One workspace group in the storage-management overview. */
export interface ManageWorkspace {
  readonly workspace: string
  readonly totalBytes: number
  readonly recoveryCount: number
  readonly restorePoints: readonly ManageRestorePoint[]
}

/** Storage-management overview served by `/turn-rewind/manage`. */
export interface ManageOverview {
  readonly storageDir: string
  readonly totalBytes: number
  readonly workspaces: readonly ManageWorkspace[]
}

const PATH = '/turn-rewind'
const MANAGE_PATH = '/turn-rewind/manage'
/** Same-origin route mapping each rendered turn number to its Session user-message seq. */
const TURNS_PATH = '/turn-rewind/turns'
/** Same-origin route that replays one stored attachment's bytes. */
const ATTACHMENT_BYTES_PATH = '/turn-rewind/attachment-bytes'

/** One draft descriptor returned by the conversation service. */
interface DraftAttachmentLike {
  readonly kind?: string
  readonly id: string
}

const STYLE_ID = '@anionex/dsh-turn-rewind'
const styles = `
.dcl-rewind-tail{display:inline-flex;align-items:center;align-self:center;order:0;height:24px;margin-left:2px}
.dcl-rewind-trigger{display:inline-flex;align-items:center;justify-content:center;width:24px;height:24px;padding:0;border:0;border-radius:6px;background:transparent;color:var(--dsw-alias-label-tertiary);cursor:pointer}
.dcl-rewind-trigger:hover{background:var(--dsw-alias-interactive-bg-hover);color:var(--dsw-alias-label-secondary)}
.dcl-rewind-dialog{box-sizing:border-box;width:min(560px,100%);max-height:calc(100dvh - 48px)}
.dcl-rewind-content{min-width:0;min-height:0;overflow-y:auto;overscroll-behavior:contain}
.dcl-rewind-body{display:flex;flex-direction:column;gap:14px;width:100%;min-width:0;max-width:100%;box-sizing:border-box}
.dcl-rewind-options{display:flex;flex-direction:column;gap:8px;min-width:0;max-width:100%}
.dcl-rewind-option{display:flex;align-items:flex-start;gap:10px;width:100%;min-width:0;box-sizing:border-box;padding:12px;border:1px solid var(--dsw-alias-border-l2);border-radius:12px;background:var(--dsw-alias-bg-layer-1);cursor:pointer}
.dcl-rewind-option[data-selected="true"]{border-color:var(--dsw-alias-state-business-primary)}
.dcl-rewind-option[data-disabled="true"]{cursor:not-allowed;opacity:.52}
.dcl-rewind-option input{flex:none;margin:2px 0 0}
.dcl-rewind-option-content{display:block;flex:1;min-width:0}
.dcl-rewind-option strong{display:block;color:var(--dsw-alias-label-primary);font-size:14px}
.dcl-rewind-option-description{display:block;margin-top:3px;overflow-wrap:anywhere;word-break:break-word;color:var(--dsw-alias-label-tertiary);font-size:12px}
.dcl-rewind-summary{display:flex;flex-wrap:wrap;column-gap:16px;row-gap:4px;min-width:0;color:var(--dsw-alias-label-secondary);font-size:13px}
.dcl-rewind-files{min-width:0;max-width:100%;box-sizing:border-box;max-height:220px;overflow:auto;border:1px solid var(--dsw-alias-border-l2);border-radius:10px}
.dcl-rewind-file{display:flex;justify-content:space-between;gap:16px;min-width:0;padding:8px 10px;border-bottom:1px solid var(--dsw-alias-border-l1);font-size:12px}
.dcl-rewind-file:last-child{border-bottom:0}.dcl-rewind-file code{min-width:0;overflow:hidden;text-overflow:ellipsis;color:var(--dsw-alias-label-secondary)}
.dcl-rewind-kind{flex:none;color:var(--dsw-alias-label-tertiary)}
.dcl-rewind-file-actions{display:flex;justify-content:flex-start}
.dcl-rewind-status{margin:0;overflow-wrap:anywhere;color:var(--dsw-alias-label-secondary);font-size:13px;line-height:20px}
.dcl-rewind-warning,.dcl-rewind-error{box-sizing:border-box;max-width:100%;margin:0;padding:10px 12px;overflow-wrap:anywhere;word-break:break-word;border-radius:10px;font-size:12px;line-height:18px}
.dcl-rewind-warning{background:var(--dsw-alias-state-warn-tertiary);color:var(--dsw-alias-state-warn-primary)}
.dcl-rewind-error{border:1px solid color-mix(in srgb,var(--dsw-alias-state-error-primary) 30%,transparent);color:var(--dsw-alias-state-error-primary)}
.dcl-rewind-backup{box-sizing:border-box;margin:0;padding:10px 12px;border-radius:10px;background:var(--dsw-alias-bg-layer-2);color:var(--dsw-alias-label-secondary);font-size:12px;line-height:18px}
.dcl-rewind-retry{align-self:flex-start}
.dcl-trs-card{border:1px solid var(--dsw-alias-border-l2);background:var(--dsw-alias-bg-layer-3);border-radius:12px;transition:border-color .16s,background .16s}
.dcl-trs-card[data-open="true"]{background:var(--dsw-alias-bg-layer-2);border-color:var(--dsw-alias-label-dimmed)}
.dcl-trs-card-head{appearance:none;width:100%;font:inherit;color:inherit;text-align:left;cursor:pointer;background:0 0;border:0;border-radius:12px;align-items:center;gap:12px;padding:14px 16px;display:flex}
.dcl-trs-card-heading{flex-direction:column;flex:1;gap:4px;min-width:0;display:flex}
.dcl-trs-card-heading strong{color:var(--dsw-alias-label-primary);font-size:15px;font-weight:600;line-height:1.4}
.dcl-trs-card-description{color:var(--dsw-alias-label-tertiary);font-size:13px;line-height:1.5}
.dcl-trs-card-chevron{color:var(--dsw-alias-label-tertiary);flex:none;transition:transform .16s}
.dcl-trs-card[data-open="true"] .dcl-trs-card-chevron{transform:rotate(180deg)}
.dcl-trs-card-body{border-top:1px solid var(--dsw-alias-border-l2);margin:0 16px;padding:12px 0 8px;display:flex;flex-direction:column;gap:16px;min-width:0}
.dcl-trs-section-title{display:flex;align-items:center;justify-content:space-between;gap:12px;min-width:0}
.dcl-trs-section-title strong{color:var(--dsw-alias-label-primary);font-size:14px}
.dcl-trs-section-title-actions{display:inline-flex;align-items:center;gap:8px}
.dcl-trs-field{display:flex;flex-wrap:wrap;align-items:center;gap:8px 12px;padding:8px 0;border-bottom:1px solid var(--dsw-alias-border-l1);font-size:13px}
.dcl-trs-field:last-child{border-bottom:0}
.dcl-trs-field-label{flex:1 1 200px;min-width:0}
.dcl-trs-field-label strong{display:block;color:var(--dsw-alias-label-primary);font-size:13px;font-weight:600}
.dcl-trs-field-desc{display:block;margin-top:2px;color:var(--dsw-alias-label-tertiary);font-size:12px}
.dcl-trs-field-control{display:inline-flex;align-items:center;gap:8px;flex:none}
.dcl-trs-field-control input,.dcl-trs-field-control select{box-sizing:border-box;min-width:140px;padding:4px 8px;border:1px solid var(--dsw-alias-border-l2);border-radius:8px;background:var(--dsw-alias-bg-layer-1);color:var(--dsw-alias-label-primary);font-size:13px}
.dcl-trs-field-control input:disabled,.dcl-trs-field-control select:disabled{opacity:.52;cursor:not-allowed}
.dcl-trs-override{flex:none;padding:1px 8px;border-radius:999px;background:var(--dsw-alias-state-business-primary);color:var(--dsw-alias-bg-layer-0);font-size:11px;line-height:18px}
.dcl-trs-manage-total{margin:0;color:var(--dsw-alias-label-secondary);font-size:12px;overflow-wrap:anywhere}
.dcl-trs-workspace{display:flex;flex-direction:column;gap:6px;padding:10px 12px;border:1px solid var(--dsw-alias-border-l2);border-radius:10px;background:var(--dsw-alias-bg-layer-1)}
.dcl-trs-workspace-head{display:flex;flex-wrap:wrap;align-items:center;gap:6px 12px;min-width:0}
.dcl-trs-workspace-path{flex:1 1 auto;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:var(--dsw-alias-label-primary);font-size:12px}
.dcl-trs-workspace-meta{flex:none;color:var(--dsw-alias-label-tertiary);font-size:12px}
.dcl-trs-badge{flex:none;padding:1px 8px;border-radius:999px;background:var(--dsw-alias-state-warn-tertiary);color:var(--dsw-alias-state-warn-primary);font-size:11px;line-height:18px}
.dcl-trs-points{display:flex;flex-direction:column;gap:4px;min-width:0;margin:0;padding:0;list-style:none}
.dcl-trs-point{display:flex;flex-wrap:wrap;align-items:center;gap:4px 12px;padding:6px 8px;border:1px solid var(--dsw-alias-border-l1);border-radius:8px;font-size:12px}
.dcl-trs-point time{flex:1 1 140px;min-width:0;color:var(--dsw-alias-label-secondary)}
.dcl-trs-point-kind,.dcl-trs-point-size,.dcl-trs-point-files{flex:none;color:var(--dsw-alias-label-tertiary)}
.dcl-trs-point code{flex:1 1 140px;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:var(--dsw-alias-label-tertiary)}
.dcl-trs-status{margin:0;color:var(--dsw-alias-label-secondary);font-size:13px;line-height:20px}
.dcl-trs-notice{box-sizing:border-box;max-width:100%;margin:0;padding:8px 10px;overflow-wrap:anywhere;border-radius:8px;background:var(--dsw-alias-bg-layer-2);color:var(--dsw-alias-label-secondary);font-size:12px;line-height:18px}
.dcl-trs-notice[data-warning="true"]{background:var(--dsw-alias-state-warn-tertiary);color:var(--dsw-alias-state-warn-primary)}
.dcl-trs-error{box-sizing:border-box;max-width:100%;margin:0;padding:10px 12px;overflow-wrap:anywhere;word-break:break-word;border:1px solid color-mix(in srgb,var(--dsw-alias-state-error-primary) 30%,transparent);border-radius:10px;color:var(--dsw-alias-state-error-primary);font-size:12px;line-height:18px}
.dcl-trs-storage{margin:0;padding:8px 10px;border-radius:8px;background:var(--dsw-alias-bg-layer-2);color:var(--dsw-alias-label-tertiary);font-size:12px;overflow-wrap:anywhere}
`

/** UI languages this plugin ships copy for. */
type UiLocale = 'zh' | 'en'

/** Label and help text for one numeric settings field. */
interface FieldText {
  readonly label: string
  readonly description: string
}

/** Every user-facing string the rewind surface renders, in one language. */
interface RewindText {
  readonly rewindTooltip: string
  readonly dialogClose: string
  readonly dialogDescription: string
  readonly cancel: string
  readonly applying: string
  readonly done: string
  readonly actionRestoreAndRestart: string
  readonly actionRestoreFiles: string
  readonly actionMessagesOnly: string
  readonly checkingFiles: string
  readonly previewPending: string
  readonly previewMissing: string
  readonly modeBothTitle: string
  readonly modeBothDescription: string
  readonly modeCodeTitle: string
  readonly modeCodeDescription: string
  readonly modeMessagesTitle: string
  readonly modeMessagesDescription: string
  readonly filesUnchanged: string
  readonly filesToRestore: (count: number) => string
  readonly summaryBoth: string
  readonly summaryCode: string
  readonly summaryMessages: string
  readonly sharedBlocked: string
  readonly branchChanged: string
  readonly headAdvanced: string
  readonly driftBlocked: string
  readonly planMissing: string
  readonly stale: string
  readonly nothingToRestore: string
  readonly loadingAllFiles: string
  readonly viewAllFiles: (count: number) => string
  readonly backupNote: string
  readonly recheck: string
  readonly completedMessages: string
  readonly completedCode: string
  readonly completedBoth: string
  readonly openFailed: (reason: string) => string
  readonly restoredButOpenFailed: (reason: string) => string
  readonly modeMismatch: (mode: string) => string
  readonly listChangedWhileExpanding: string
  readonly incompleteFileList: string
  readonly fileKinds: Readonly<Record<ChangeKind, string>>
  /** Keyed by the Host error code, which stays the same in every language. */
  readonly errors: Readonly<Record<string, string>>
  readonly captureSnapshotLimit: string
  readonly captureFileLimit: string
  readonly captureSkipped: (count: number, example: string | undefined) => string
  readonly skipTimeout: string
  readonly skipDisabled: string
  readonly skipNewContentLimit: string
  readonly skipOther: (reason: string) => string
  readonly failureNotGitRepository: string
  readonly failureGitStatus: (message: string) => string
  readonly failureSizeOrCount: string
  readonly failureUnsupportedType: string
  readonly failureIgnoreFileInvalid: string
  readonly failureInvalidPath: string
  readonly failureOther: (message: string) => string
  readonly settingsCardTitle: string
  readonly settingsCardDescription: string
  readonly autoCheckpointSection: string
  readonly settingsLoading: string
  readonly settingsUnavailable: string
  readonly settingsReadOnly: string
  readonly autoCheckpointLabel: string
  readonly autoCheckpointDescription: string
  readonly trustLabel: string
  readonly trustDescription: string
  readonly overridden: string
  readonly resetToDefault: string
  readonly positiveInteger: (field: string) => string
  readonly storageDir: (directory: string) => string
  readonly manageSection: string
  readonly refreshing: string
  readonly refresh: string
  readonly clearing: string
  readonly confirmClearAll: string
  readonly clearAll: string
  readonly manageLoading: string
  readonly manageTotal: (workspaces: number, points: number, size: string) => string
  readonly workspacePoints: (count: number) => string
  readonly pendingRecoveries: (count: number) => string
  readonly expand: string
  readonly collapse: string
  readonly clearWorkspace: string
  readonly fileCount: (count: number) => string
  readonly deleting: string
  readonly remove: string
  readonly noCheckpoints: string
  readonly clearedAll: (deleted: number, retained: number, failures: number) => string
  readonly cleared: (deleted: number, retained: number) => string
  readonly checkpointModes: Readonly<Record<TurnRewindSettingsValue['turnCheckpointMode'], string>>
  readonly trustOptions: Readonly<Record<TurnRewindSettingsValue['turnCheckpointTrust'], string>>
  /** Keyed by the durable restore-point kind, which is not a display value. */
  readonly pointKinds: Readonly<Record<string, string>>
  readonly numberFields: Readonly<Record<NumberSettingsField, FieldText>>
  readonly manageMissingWorkspaces: string
  readonly manageMissingRestorePoints: string
  readonly clearMissingReports: string
  readonly previewMissingChanges: string
  readonly previewMissingActiveSessionIds: string
  readonly invalidField: (name: string) => string
  readonly invalidObject: string
  readonly unknownStatus: (status: string) => string
  readonly sessionNotReady: string
  readonly attachmentsFailed: (names: string) => string
  readonly unparsableResponse: (status: string) => string
  readonly requestFailed: (status: string) => string
  readonly emptyResponse: string
}

/** Chinese copy — the language this plugin shipped in before English existed. */
const ZH: RewindText = {
  rewindTooltip: '恢复到发送这条消息之前',
  dialogClose: '关闭',
  dialogDescription: '查看恢复的文件，选择适合你的回退方式。当前会话不受影响。',
  cancel: '取消',
  applying: '正在恢复…',
  done: '已完成',
  actionRestoreAndRestart: '恢复并从这里继续',
  actionRestoreFiles: '恢复文件',
  actionMessagesOnly: '只回溯消息',
  checkingFiles: '正在检查可以恢复的项目文件…',
  previewPending: '这条消息发送前的文件还在保存，请稍后再试。',
  previewMissing: '没有保存这条消息发送前的文件。可能是当时还没启用回退功能、记录已超过保留期限，或已关闭自动检查点。仍可只回溯消息。',
  modeBothTitle: '恢复文件并从这里继续',
  modeBothDescription: '创建一个从这里开始的新会话（当前对话会保留）',
  modeCodeTitle: '只恢复文件',
  modeCodeDescription: '恢复这条消息发送前的文件，当前对话保持不变。',
  modeMessagesTitle: '只回溯消息（不动文件）',
  modeMessagesDescription: '创建一个从这里开始的新会话，项目文件保持当前状态。',
  filesUnchanged: '项目文件保持不变',
  filesToRestore: count => `将恢复 ${String(count)} 个文件`,
  summaryBoth: '恢复后在新对话里继续',
  summaryCode: '当前对话保持不变',
  summaryMessages: '仅创建从这里继续的新对话',
  sharedBlocked: '这个项目目录还有别的对话正在运行。恢复文件会影响到它们，因此本次操作已被阻止。请等那些对话结束或停止后，再重新检查。',
  branchChanged: '当前所在的 Git 分支和发送这条消息时不同。恢复不会切换分支，只会把当时的文件内容恢复到当前分支。',
  headAdvanced: '这条消息之后有了新的 Git 提交。恢复只会改文件，不会撤销提交；完成后这些文件会显示为未提交修改。',
  driftBlocked: 'Git 正在进行合并、变基或类似操作。请先完成或取消这次 Git 操作，再重新检查。',
  planMissing: '恢复信息已经失效，请重新检查。',
  stale: '项目文件在检查后又发生了变化。为避免覆盖新修改，这次恢复已失效，请重新检查。',
  nothingToRestore: '项目文件已经是这条消息发送前的状态，无需恢复文件。可选择「只回溯消息」重新开始这段对话。',
  loadingAllFiles: '正在读取全部文件…',
  viewAllFiles: count => `查看全部 ${String(count)} 个文件`,
  backupNote: '恢复前会自动备份当前文件；若恢复失败会自动还原，项目不会停留在只恢复了一部分的状态。',
  recheck: '重新检查',
  completedMessages: '已创建从这里开始的新对话；项目文件保持不变。',
  completedCode: '项目文件已恢复；当前对话保持不变。恢复前的文件已自动备份。',
  completedBoth: '项目文件已恢复，并已创建新对话。恢复前的文件已自动备份。',
  openFailed: reason => `新对话已创建，但没能自动打开：${reason}`,
  restoredButOpenFailed: reason => `文件已经恢复，新对话也已创建，但没能自动打开：${reason}`,
  modeMismatch: mode => `服务器返回了不匹配的回退模式：${mode}`,
  listChangedWhileExpanding: '项目文件在展开列表时发生了变化。',
  incompleteFileList: '无法读取完整的文件列表。',
  fileKinds: {
    added: '移除后来新增的文件',
    deleted: '找回文件',
    modified: '恢复之前的版本',
    'mode-changed': '恢复文件权限',
    'type-changed': '恢复之前的文件类型',
  },
  errors: {
    REWIND_ENDPOINT_UNAVAILABLE: '回退服务没有响应。请确认 @anionex/dsh-turn-rewind 已挂载到当前 DSH，并重启 DSH 后重试。',
    REWIND_INVALID_RESPONSE: '回退服务返回了无法解析的内容。请重启 DSH 后重试。',
    PLAN_STALE: '项目文件在检查后又发生了变化。为避免覆盖新修改，请重新检查后再恢复。',
    PLAN_STALE_WORKSPACE: '项目文件在检查后又发生了变化。为避免覆盖新修改，请重新检查后再恢复。',
    PLAN_STALE_REPOSITORY: 'Git 状态在检查后又发生了变化，恢复已失效。请重新检查后再试。',
    WORKSPACE_IN_USE: '这个项目目录还有别的对话正在运行。请等那些对话结束或停止后，再重新检查。',
    WORKSPACE_LOCKED: '另一个恢复操作正在处理这个项目目录。请等待它完成后重新检查。',
    WORKSPACE_CHANGED: '这个项目目录已经不在原来的位置，旧的回退点无法再使用。',
    WORKSPACE_MODE_CHANGED: '这个项目目录的工作区类型变了（例如从普通目录变成了 Git 仓库）。旧的回退点不再适用，请重新发送一条消息生成新的回退点。',
    HEAD_CHANGED: '项目的提交或分支已发生变化。为避免覆盖新改动，请重新检查后再恢复。',
    REPOSITORY_CHANGED: '这个项目目录已不属于原来的 Git 工作区，无法恢复。',
    GIT_OPERATION_CHANGED: 'Git 正在执行其他操作。请先完成或取消该操作，再重新检查。',
    RESTORE_POINT_NOT_FOUND: '没有找到对应的文件状态，可能已被清理。',
    NO_CHANGES: '项目文件已经是这条消息发送前的状态，无需恢复文件。可选择「只回溯消息」重新开始这段对话。',
    RESTORE_FAILED_ROLLED_BACK: '恢复未能完成，项目文件已自动还原到操作前的状态。',
    CONVERSATION_REWIND_FAILED: '文件已恢复，但无法创建新对话；项目文件已自动还原。',
  },
  captureSnapshotLimit: '本轮要保存的文件总量超过上限，剩下的文件没有纳入检查点。恢复时不会改动它们。',
  captureFileLimit: '本轮文件数量超过上限，多出来的文件没有纳入检查点。恢复时不会改动它们。',
  captureSkipped: (count, example) => `有 ${String(count)} 个文件因为超过单文件大小上限或类型不受支持，没有纳入检查点${example === undefined ? '' : `（例如 ${example}）`}。恢复时不会改动它们。`,
  skipTimeout: '这个项目目录太大，在检查点时间上限内没保存完文件快照，所以本轮没有回退点（消息本身没有受影响）。可以在插件设置里调大「检查点时间上限」，或在目录根用 .dsh-rewindignore 排除大目录（例如 node_modules、构建产物、数据集）。仍可只回溯消息。',
  skipDisabled: '自动文件检查点已在设置里关闭，本轮没有回退点。仍可只回溯消息。',
  skipNewContentLimit: '这一轮新增的内容超过检查点预算，没有保存文件快照。仍可只回溯消息。',
  skipOther: reason => `本轮没有保存文件检查点：${reason}仍可只回溯消息。`,
  failureNotGitRepository: '这个项目目录不是 Git 仓库，回退功能无法保存文件检查点。仍可只回溯消息。',
  failureGitStatus: message => `无法读取这个项目目录的 Git 状态：${message}仍可只回溯消息。`,
  failureSizeOrCount: '本轮有文件超过检查点的大小或数量上限，没有保存文件检查点。仍可只回溯消息。',
  failureUnsupportedType: '项目目录里有无法保存的特殊文件（如 socket、设备文件、FIFO），没有保存文件检查点。仍可只回溯消息。',
  failureIgnoreFileInvalid: '项目目录里的 .dsh-rewindignore 内容无效，没有保存文件检查点。修正该文件后可重新发送消息。',
  failureInvalidPath: '项目目录里有无法安全保存的路径（例如嵌套的独立 Git 仓库），没有保存文件检查点。仍可只回溯消息。',
  failureOther: message => `没能保存这条消息发送前的文件：${message}仍可只回溯消息。`,
  settingsCardTitle: 'Turn Rewind 回退设置',
  settingsCardDescription: '自动文件检查点、信任策略与检查点保留上限；回退按钮在各条用户消息上',
  autoCheckpointSection: '自动文件检查点',
  settingsLoading: '正在加载设置…',
  settingsUnavailable: '当前部署未提供设置服务，以下选项不可用。',
  settingsReadOnly: '设置为只读（当前浏览器进程内保存），修改不可用。',
  autoCheckpointLabel: '自动文件检查点',
  autoCheckpointDescription: '关闭后不再为每条消息保存文件检查点；回退弹窗仍可只回溯消息',
  trustLabel: '检查点信任策略',
  trustDescription: '快速信任 Git/stat 元数据；严格会逐一重读文件内容',
  overridden: '已覆盖',
  resetToDefault: '恢复默认',
  positiveInteger: field => `${field} 必须是正整数。`,
  storageDir: directory => `存储目录（在 cordis.patch.yml 中配置，不可在线修改）：${directory}`,
  manageSection: '检查点管理',
  refreshing: '正在刷新…',
  refresh: '刷新',
  clearing: '正在清理…',
  confirmClearAll: '确认清空全部',
  clearAll: '一键清空全部',
  manageLoading: '正在读取检查点占用…',
  manageTotal: (workspaces, points, size) => `共 ${String(workspaces)} 个工作区，${String(points)} 个检查点，约 ${size}（Git 原生检查点的实际磁盘占用以 Git 回收为准）。`,
  workspacePoints: count => `${String(count)} 个检查点`,
  pendingRecoveries: count => `${String(count)} 个恢复待处理`,
  expand: '展开',
  collapse: '收起',
  clearWorkspace: '清空此项目',
  fileCount: count => `${String(count)} 个文件`,
  deleting: '正在删除…',
  remove: '删除',
  noCheckpoints: '还没有任何已保存的检查点。',
  clearedAll: (deleted, retained, failures) => `已删除 ${String(deleted)} 个检查点${retained > 0 ? `，${String(retained)} 个受保护检查点未删除` : ''}${failures > 0 ? `，${String(failures)} 个工作区清理失败` : ''}。`,
  cleared: (deleted, retained) => `已删除 ${String(deleted)} 个检查点${retained > 0 ? `，${String(retained)} 个受保护检查点未删除` : ''}。`,
  checkpointModes: {
    off: '关闭（不创建文件检查点）',
    auto: '自动（推荐）',
    'git-native': 'Git 原生（大仓库）',
    legacy: '完整快照（兼容模式）',
  },
  trustOptions: {
    fast: '快速',
    strict: '严格',
  },
  pointKinds: {
    user: '手动',
    rescue: '救援',
    turn: '轮次',
  },
  numberFields: {
    maxRestorePoints: { label: '用户/救援恢复点上限', description: '每个工作区保留的最大手动与救援恢复点数量' },
    maxTurnCheckpointsPerSession: { label: '轮次检查点上限', description: '每个会话保留的最大自动轮次检查点数量（最旧的先清理）' },
    maxFiles: { label: '单恢复点文件数上限', description: '一个恢复点最多纳入的文件数量' },
    maxFileBytes: { label: '单文件大小上限', description: '读取单个普通文件的最大字节数' },
    maxSnapshotBytes: { label: '快照总量上限', description: '单个恢复点读取的最大字节总量' },
    planTtlMs: { label: '恢复计划有效期（毫秒）', description: '回溯计划从创建到失效的时间' },
    staleLockMs: { label: '锁回收时长（毫秒）', description: '锁属主消失多久后允许回收该锁' },
    turnCheckpointTimeoutMs: { label: '检查点超时（毫秒）', description: '单次自动检查点最多阻塞消息发送的时间，超时记录跳过' },
    turnCheckpointMaxNewBytes: { label: '检查点读取上限', description: '单次 Git 原生检查点最多读取的未缓存字节数' },
  },
  manageMissingWorkspaces: '管理数据缺少 workspaces',
  manageMissingRestorePoints: '管理数据缺少 restorePoints',
  clearMissingReports: '清理结果缺少 reports',
  previewMissingChanges: '回退预览缺少 changes',
  previewMissingActiveSessionIds: '回退预览缺少 activeSessionIds',
  invalidField: name => `${name} 无效`,
  invalidObject: '服务器返回了无效对象',
  unknownStatus: status => `未知回退状态：${status}`,
  sessionNotReady: '新对话还没有准备好',
  attachmentsFailed: names => `文字已恢复，但以下附件未恢复，请重新添加：${names}`,
  unparsableResponse: status => `回退服务返回了无法解析的内容（HTTP ${status}）。`,
  requestFailed: status => `请求失败：${status}`,
  emptyResponse: '回退服务返回了空响应。',
}

/**
 * Count one English noun, used only by the English copy.
 * @param count - the quantity to render.
 * @param singular - the noun in its singular form.
 * @param plural - the plural form, when adding `s` is wrong.
 * @returns the counted phrase.
 */
function counted(count: number, singular: string, plural = `${singular}s`): string {
  return `${String(count)} ${count === 1 ? singular : plural}`
}

/** English copy, used when the Host reports a non-Chinese UI language. */
const EN: RewindText = {
  rewindTooltip: 'Return to before sending this message',
  dialogClose: 'Close',
  dialogDescription: 'Review the files that would be restored and pick the rewind mode you want. The current session is unaffected.',
  cancel: 'Cancel',
  applying: 'Restoring…',
  done: 'Done',
  actionRestoreAndRestart: 'Restore and continue from here',
  actionRestoreFiles: 'Restore files',
  actionMessagesOnly: 'Rewind messages only',
  checkingFiles: 'Checking which project files can be restored…',
  previewPending: 'The files from before this message are still being saved. Try again in a moment.',
  previewMissing: 'No files were saved from before this message. Rewind may not have been enabled yet, the record may have passed its retention limit, or automatic checkpoints may be turned off. You can still rewind messages only.',
  modeBothTitle: 'Restore files and restart',
  modeBothDescription: 'Creates a new session starting here (the current conversation is kept)',
  modeCodeTitle: 'Restore files only',
  modeCodeDescription: 'Restores the files from before this message and leaves the current conversation unchanged.',
  modeMessagesTitle: 'Rewind messages only (files untouched)',
  modeMessagesDescription: 'Creates a new session starting here and leaves the project files exactly as they are.',
  filesUnchanged: 'Project files stay unchanged',
  filesToRestore: count => `Will restore ${counted(count, 'file')}`,
  summaryBoth: 'Continue in a new conversation after restoring',
  summaryCode: 'The current conversation stays unchanged',
  summaryMessages: 'Only creates a new conversation continuing from here',
  sharedBlocked: 'Another conversation is still running in this project directory. Restoring files would affect it, so this operation is blocked. Wait for those conversations to finish or stop them, then check again.',
  branchChanged: 'The current Git branch is not the one you were on when this message was sent. Restoring never switches branches; it only restores that file content onto the current branch.',
  headAdvanced: 'There are new Git commits after this message. Restoring only changes files and never undoes commits; afterwards those files appear as uncommitted changes.',
  driftBlocked: 'Git is in the middle of a merge, rebase, or similar operation. Finish or cancel that Git operation, then check again.',
  planMissing: 'The restore information has expired. Check again.',
  stale: 'The project files changed again after the check. To avoid overwriting the newer edits, this restore is no longer valid. Check again.',
  nothingToRestore: 'The project files already match the state from before this message, so no files need restoring. Choose “Rewind messages only” to restart this conversation from here.',
  loadingAllFiles: 'Loading all files…',
  viewAllFiles: count => `View all ${counted(count, 'file')}`,
  backupNote: 'The current files are backed up automatically before a restore; if the restore fails they are rolled back, so the project is never left partly restored.',
  recheck: 'Check again',
  completedMessages: 'A new conversation starting here has been created; the project files are unchanged.',
  completedCode: 'The project files have been restored; the current conversation is unchanged. The files from before the restore were backed up automatically.',
  completedBoth: 'The project files have been restored and a new conversation was created. The files from before the restore were backed up automatically.',
  openFailed: reason => `The new conversation was created but could not be opened automatically: ${reason}`,
  restoredButOpenFailed: reason => `The files were restored and the new conversation was created, but it could not be opened automatically: ${reason}`,
  modeMismatch: mode => `The server returned a rewind mode that does not match: ${mode}`,
  listChangedWhileExpanding: 'The project files changed while the full list was being loaded.',
  incompleteFileList: 'Could not read the complete file list.',
  fileKinds: {
    added: 'Remove the file added later',
    deleted: 'Bring the file back',
    modified: 'Restore the earlier version',
    'mode-changed': 'Restore the file permissions',
    'type-changed': 'Restore the earlier file type',
  },
  errors: {
    REWIND_ENDPOINT_UNAVAILABLE: 'The rewind service did not respond. Check that @anionex/dsh-turn-rewind is mounted in this DSH, restart DSH, and try again.',
    REWIND_INVALID_RESPONSE: 'The rewind service returned content that could not be parsed. Restart DSH and try again.',
    PLAN_STALE: 'The project files changed again after the check. To avoid overwriting the newer edits, check again before restoring.',
    PLAN_STALE_WORKSPACE: 'The project files changed again after the check. To avoid overwriting the newer edits, check again before restoring.',
    PLAN_STALE_REPOSITORY: 'The Git state changed after the check, so the restore is no longer valid. Check again and retry.',
    WORKSPACE_IN_USE: 'Another conversation is still running in this project directory. Wait for those conversations to finish or stop them, then check again.',
    WORKSPACE_LOCKED: 'Another restore is already working on this project directory. Wait for it to finish, then check again.',
    WORKSPACE_CHANGED: 'This project directory is no longer in its original location, so the earlier restore points cannot be used.',
    WORKSPACE_MODE_CHANGED: 'The workspace type of this project directory changed (for example from an ordinary directory to a Git repository). The earlier restore points no longer apply; send a new message to create a new one.',
    HEAD_CHANGED: 'The commits or branch of this project changed. To avoid overwriting newer work, check again before restoring.',
    REPOSITORY_CHANGED: 'This project directory no longer belongs to its original Git worktree, so it cannot be restored.',
    GIT_OPERATION_CHANGED: 'Git is running another operation. Finish or cancel it, then check again.',
    RESTORE_POINT_NOT_FOUND: 'No matching file state was found; it may already have been cleaned up.',
    NO_CHANGES: 'The project files already match the state from before this message, so no files need restoring. Choose “Rewind messages only” to restart this conversation from here.',
    RESTORE_FAILED_ROLLED_BACK: 'The restore did not finish; the project files were rolled back to their state before the operation.',
    CONVERSATION_REWIND_FAILED: 'The files were restored but the new conversation could not be created; the project files were rolled back.',
  },
  captureSnapshotLimit: 'The files in this turn exceeded the total size limit, so the remaining files were left out of the checkpoint. A restore will not touch them.',
  captureFileLimit: 'This turn had more files than the limit allows, so the extra files were left out of the checkpoint. A restore will not touch them.',
  captureSkipped: (count, example) => `${counted(count, 'file')} ${count === 1 ? 'was' : 'were'} left out of the checkpoint for exceeding the per-file size limit or having an unsupported type${example === undefined ? '' : ` (for example ${example})`}. A restore will not touch them.`,
  skipTimeout: 'This project directory is too large to finish a file snapshot within the checkpoint time limit, so this turn has no restore point (the message itself was unaffected). Raise “Checkpoint timeout (ms)” in the plugin settings, or exclude large directories with a .dsh-rewindignore in the directory root (for example node_modules, build output, datasets). You can still rewind messages only.',
  skipDisabled: 'Automatic file checkpoints are turned off in settings, so this turn has no restore point. You can still rewind messages only.',
  skipNewContentLimit: 'This turn added more content than the checkpoint budget allows, so no file snapshot was saved. You can still rewind messages only.',
  skipOther: reason => `No file checkpoint was saved for this turn: ${reason} You can still rewind messages only.`,
  failureNotGitRepository: 'This project directory is not a Git repository, so rewind cannot save file checkpoints. You can still rewind messages only.',
  failureGitStatus: message => `Could not read the Git state of this project directory: ${message} You can still rewind messages only.`,
  failureSizeOrCount: 'Files in this turn exceeded the checkpoint size or count limit, so no file checkpoint was saved. You can still rewind messages only.',
  failureUnsupportedType: 'The project directory contains special files that cannot be saved (such as sockets, device files, or FIFOs), so no file checkpoint was saved. You can still rewind messages only.',
  failureIgnoreFileInvalid: 'The .dsh-rewindignore in the project directory is invalid, so no file checkpoint was saved. Fix that file and send the message again.',
  failureInvalidPath: 'The project directory contains paths that cannot be saved safely (for example a nested standalone Git repository), so no file checkpoint was saved. You can still rewind messages only.',
  failureOther: message => `Could not save the files from before this message: ${message} You can still rewind messages only.`,
  settingsCardTitle: 'Turn Rewind settings',
  settingsCardDescription: 'Automatic file checkpoints, trust policy, and checkpoint retention limits; the rewind button sits on each user message',
  autoCheckpointSection: 'Automatic file checkpoints',
  settingsLoading: 'Loading settings…',
  settingsUnavailable: 'This deployment provides no settings service, so the options below are unavailable.',
  settingsReadOnly: 'Settings are read-only (kept inside this browser process), so changes are unavailable.',
  autoCheckpointLabel: 'Automatic file checkpoints',
  autoCheckpointDescription: 'When off, no file checkpoint is saved for each message; the rewind dialog can still rewind messages only',
  trustLabel: 'Checkpoint trust policy',
  trustDescription: 'Fast trusts Git/stat metadata; Strict re-reads every file’s content',
  overridden: 'Overridden',
  resetToDefault: 'Reset to default',
  positiveInteger: field => `${field} must be a positive integer.`,
  storageDir: directory => `Storage directory (configured in cordis.patch.yml, not editable here): ${directory}`,
  manageSection: 'Checkpoint management',
  refreshing: 'Refreshing…',
  refresh: 'Refresh',
  clearing: 'Clearing…',
  confirmClearAll: 'Confirm clear all',
  clearAll: 'Clear all',
  manageLoading: 'Reading checkpoint usage…',
  manageTotal: (workspaces, points, size) => `${counted(workspaces, 'workspace')}, ${counted(points, 'checkpoint')}, about ${size} (disk use for Git-native checkpoints follows Git garbage collection).`,
  workspacePoints: count => counted(count, 'checkpoint'),
  pendingRecoveries: count => `${counted(count, 'recovery', 'recoveries')} pending`,
  expand: 'Expand',
  collapse: 'Collapse',
  clearWorkspace: 'Clear this project',
  fileCount: count => counted(count, 'file'),
  deleting: 'Deleting…',
  remove: 'Delete',
  noCheckpoints: 'No checkpoints have been saved yet.',
  clearedAll: (deleted, retained, failures) => `Deleted ${counted(deleted, 'checkpoint')}${retained > 0 ? `; ${counted(retained, 'protected checkpoint')} kept` : ''}${failures > 0 ? `; ${counted(failures, 'workspace')} failed to clear` : ''}.`,
  cleared: (deleted, retained) => `Deleted ${counted(deleted, 'checkpoint')}${retained > 0 ? `; ${counted(retained, 'protected checkpoint')} kept` : ''}.`,
  checkpointModes: {
    off: 'Off (no file checkpoints)',
    auto: 'Auto (recommended)',
    'git-native': 'Git-native (large repositories)',
    legacy: 'Full snapshot (compatibility mode)',
  },
  trustOptions: {
    fast: 'Fast',
    strict: 'Strict',
  },
  pointKinds: {
    user: 'Manual',
    rescue: 'Rescue',
    turn: 'Turn',
  },
  numberFields: {
    maxRestorePoints: { label: 'User/rescue restore point limit', description: 'Most manual and rescue restore points kept per workspace' },
    maxTurnCheckpointsPerSession: { label: 'Turn checkpoint limit', description: 'Most automatic turn checkpoints kept per session (oldest pruned first)' },
    maxFiles: { label: 'Files per restore point', description: 'Most files one restore point may include' },
    maxFileBytes: { label: 'Maximum file size', description: 'Most bytes read from a single regular file' },
    maxSnapshotBytes: { label: 'Maximum snapshot size', description: 'Most bytes read in total for one restore point' },
    planTtlMs: { label: 'Restore plan lifetime (ms)', description: 'How long a rewind plan stays valid after it is created' },
    staleLockMs: { label: 'Stale lock timeout (ms)', description: 'How long after its owner disappears a lock may be reclaimed' },
    turnCheckpointTimeoutMs: { label: 'Checkpoint timeout (ms)', description: 'How long one automatic checkpoint may hold up sending a message before it is recorded as skipped' },
    turnCheckpointMaxNewBytes: { label: 'Checkpoint read limit', description: 'Most uncached bytes one Git-native checkpoint may read' },
  },
  manageMissingWorkspaces: 'The management data is missing workspaces',
  manageMissingRestorePoints: 'The management data is missing restorePoints',
  clearMissingReports: 'The clear result is missing reports',
  previewMissingChanges: 'The rewind preview is missing changes',
  previewMissingActiveSessionIds: 'The rewind preview is missing activeSessionIds',
  invalidField: name => `${name} is invalid`,
  invalidObject: 'The server returned an invalid object',
  unknownStatus: status => `Unknown rewind status: ${status}`,
  sessionNotReady: 'The new conversation is not ready yet',
  attachmentsFailed: names => `The text was restored, but these attachments need to be added again: ${names}`,
  unparsableResponse: status => `The rewind service returned content that could not be parsed (HTTP ${status}).`,
  requestFailed: status => `Request failed: ${status}`,
  emptyResponse: 'The rewind service returned an empty response.',
}

const TEXT: Readonly<Record<UiLocale, RewindText>> = { zh: ZH, en: EN }

/**
 * Active UI language, and the listeners rendering it.
 *
 * One browser runs one copy of this plugin, so the active language is module
 * state rather than React context: the pure helpers below (`friendlyError`,
 * `explainCheckpointSkip`, and the decoders) produce user-facing sentences
 * outside any render and would otherwise need their exported signatures
 * changed.
 */
let uiLocale: UiLocale = 'zh'
const localeListeners = new Set<() => void>()

/**
 * Resolve one Host locale id to a language this plugin ships copy for.
 *
 * An absent, empty, or unreadable id means the Host published no UI language —
 * DSH releases without the locale plugin, and profiles that do not mount it —
 * and keeps Chinese, so an existing install never changes language on upgrade.
 * Any other registered language resolves to English, mirroring the Host's own
 * per-key fallback chain, which terminates at English rather than Chinese.
 * @param active - the Host's active locale id, when it publishes one.
 * @returns the language whose copy to render.
 */
export function resolveUiLocale(active: string | undefined): UiLocale {
  if (typeof active !== 'string' || active === '') return 'zh'
  return /^zh(?:[-_]|$)/i.test(active) ? 'zh' : 'en'
}

/** Current UI copy. Chinese until the Host publishes another language. */
function uiText(): RewindText {
  return TEXT[uiLocale]
}

/** Adopt one Host locale id and re-render everything currently mounted. */
function adoptLocale(active: string | undefined): void {
  const next = resolveUiLocale(active)
  if (next === uiLocale) return
  uiLocale = next
  for (const listener of localeListeners) listener()
}

/** `useSyncExternalStore` subscribe half for the active language. */
function subscribeLocale(listener: () => void): () => void {
  localeListeners.add(listener)
  return () => { localeListeners.delete(listener) }
}

/** Read the current copy and re-render this component when the language changes. */
function useText(): RewindText {
  return useSyncExternalStore(subscribeLocale, uiText, uiText)
}

/**
 * Follow the Host's UI language for as long as the plugin is mounted.
 *
 * The locale service is read through `ctx.get`, Cordis's un-injected read, and
 * not declared in `inject`: an injected service the profile does not mount
 * holds the fiber inactive, which would stop the rewind button appearing at all
 * on a profile without the locale plugin. Late arrival is covered by the
 * `locale/change` event, which is emitted on the context rather than on the
 * service, so a listener registered here sees a switch even when the locale
 * plugin loads after this one.
 * @param ctx - the client context this plugin was applied to.
 * @returns the teardown restoring the default language.
 */
function followHostLocale(ctx: ClientContextLike): () => void {
  adoptLocale(hostLocale(ctx))
  // Client plugin apply() order is not guaranteed, and `locale` is read
  // un-injected (see the doc comment above) so this plugin never forces it
  // to load first. When `dsh-client-locale` mounts after this plugin, the
  // read above returns `undefined` and the surface falls back to Chinese;
  // nothing then corrects it, because a stored preference that was already
  // settled before this plugin mounted never fires another `locale/change`
  // event. Re-checking once on the next microtask and once on the next
  // macrotask catches both same-tick and deferred registration without
  // adding a hard dependency; `adoptLocale` is a no-op when the language
  // has not actually changed, so the extra calls are always safe.
  const recheck = (): void => adoptLocale(hostLocale(ctx))
  // `Promise` is an ECMAScript built-in present in every realm, unlike the
  // host-provided `queueMicrotask`, which a constrained embedding (this
  // plugin's own test sandbox included) need not supply.
  void Promise.resolve().then(recheck)
  const timeoutId = setTimeout(recheck, 0)
  let off: unknown
  try {
    off = ctx.on?.('locale/change', (snapshot: LocaleSnapshotLike) => {
      adoptLocale(typeof snapshot?.active === 'string' ? snapshot.active : hostLocale(ctx))
    })
  } catch {
    off = undefined
  }
  return () => {
    clearTimeout(timeoutId)
    if (typeof off === 'function') off()
    adoptLocale(undefined)
  }
}

/**
 * Read the Host's active locale id.
 *
 * The locale service belongs to the Host, so its presence and shape are not
 * this plugin's to guarantee: a language that cannot be read leaves the rewind
 * surface in Chinese instead of failing the effect that installs the button.
 * @param ctx - the client context this plugin was applied to.
 * @returns the active locale id, or `undefined` when none can be read.
 */
function hostLocale(ctx: ClientContextLike): string | undefined {
  try {
    const active = ctx.get?.('locale')?.getSnapshot().active
    return typeof active === 'string' ? active : undefined
  } catch {
    return undefined
  }
}

/** Return the rewind anchor, editable text, and durable attachments owned by one direct user message. */
export function selectRewindMessage(node: ConversationNodeLike): RewindMatch | null {
  if (node.kind !== 'user' || !Number.isSafeInteger(node.seq) || node.seq < 0) return null
  const promptText = (node.content ?? [])
    .filter((block): block is { readonly type: string; readonly text: string } => block.type === 'text' && typeof block.text === 'string')
    .map(block => block.text)
    .join('\n')
  const attachments = selectRewindAttachments(node)
  return attachments.length === 0
    ? { messageSeq: node.seq, promptText }
    : { messageSeq: node.seq, promptText, attachments }
}

/**
 * Collect the durable `image` / `file` references carried by one user message.
 *
 * Keep missing references so restoration can report unavailable attachments.
 * @param node - the direct user-message node the rewind anchors on.
 * @returns attachments in message order; empty when the message has none.
 */
export function selectRewindAttachments(node: ConversationNodeLike): readonly RewindAttachment[] {
  const attachments: RewindAttachment[] = []
  for (const block of node.content ?? []) {
    if (block.type !== 'image' && block.type !== 'file') continue
    const attachment = block.attachment
    const fallbackName = block.type === 'image' ? 'image' : 'file'
    const mediaType = typeof attachment?.mediaType === 'string' && attachment.mediaType !== ''
      ? attachment.mediaType
      : 'application/octet-stream'
    attachments.push({
      kind: block.type,
      attachmentId: typeof attachment?.attachmentId === 'string' ? attachment.attachmentId : '',
      name: typeof attachment?.name === 'string' && attachment.name !== '' ? attachment.name : fallbackName,
      mediaType,
    })
  }
  return attachments
}

/**
 * Browser plugin entry: bridge every direct user-message action row to the rewind UI.
 *
 * Every service read on `ctx` must be declared here: Cordis throws while reading an
 * undeclared service off the context proxy, before optional chaining can apply.
 * The settings transport is read through `ctx.get`: older Hosts expose
 * `settingsScope`, while DSH 0.1.7 exposes `configForms`.
 */
export const inject = ['slots', 'sessions', 'conversation']
export function apply(ctx: ClientContextLike): void {
  ctx.effect(() => followHostLocale(ctx), 'turn-rewind: locale')
  ctx.effect(() => {
    if (document.querySelector(`style[data-plugin-css="${STYLE_ID}"]`) !== null) return () => {}
    const tag = document.createElement('style')
    tag.dataset.plugin = '@anionex/dsh-turn-rewind'
    tag.dataset.pluginCss = STYLE_ID
    tag.textContent = styles
    document.head.appendChild(tag)
    return () => { tag.remove() }
  }, 'turn-rewind: styles')
  ctx.slots.inject('conversation.session.header.actions', () => ctx.slots.register({
    name: 'conversation.session.header.actions',
    id: 'turn-rewind-portals',
    order: 100,
    inject: () => ({
      openRestoredSession: async (
        sessionId: string,
        promptText: string,
        attachments?: readonly RewindAttachment[],
      ) => {
        await openSessionWithDraft(ctx, sessionId, promptText, attachments)
      },
    }),
  }, RewindMessagePortals))
  ctx.slots.inject('settings.plugin.item', () => ctx.slots.register({
    name: 'settings.plugin.item',
    key: 'turn-rewind',
    inject: () => ({
      scope: settingsFormScope(ctx),
    }),
  }, TurnRewindSettingsCard))
  // DSH 0.1.7 replaced the per-plugin item seat with feature-owned Settings tabs.
  ctx.slots.inject('settings.plugins.tab', () => ctx.slots.register({
    name: 'settings.plugins.tab',
    id: 'turn-rewind',
    order: 80,
    label: () => uiText().settingsCardTitle,
    inject: () => ({ scope: settingsFormScope(ctx) }),
  }, TurnRewindSettingsCard))
}

/** Read whichever settings transport this Host supplies without requiring both services. */
function settingsFormScope(ctx: ClientContextLike): SettingsScopeLike<TurnRewindSettingsValue> | undefined {
  const forms = ctx.get?.('configForms') as { get<T>(entryId: string): SettingsScopeLike<T> } | undefined
  if (forms !== undefined) return forms.get<TurnRewindSettingsValue>('turn-rewind')
  const legacy = ctx.get?.('settingsScope') as { bind<T>(spec: { readonly namespace: string }): SettingsScopeLike<T> } | undefined
  return legacy?.bind<TurnRewindSettingsValue>({ namespace: 'turn-rewind' })
}

/** Narrow a chat node source to the keyed store form. */
function isNodeStore(value: ChatNodeStoreLike | readonly RewindNodeLike[]): value is ChatNodeStoreLike {
  return typeof (value as ChatNodeStoreLike).get === 'function'
}

/**
 * Resolve the ordered chat node list from one chat projection.
 *
 * Both inputs keep a stable identity across renders: `order` is republished only
 * when the node set changes and the store is a mutable handle, so the caller can
 * memoize the list instead of allocating a new array on every render (a fresh
 * array per render makes `useSyncExternalStore` loop forever).
 * @param order - ordered node keys, or null when the projection is absent.
 * @param store - keyed node store, a legacy node array, or null.
 * @returns the chat nodes in render order.
 */
export function collectChatNodes(
  order: readonly string[] | null,
  store: ChatNodeStoreLike | readonly RewindNodeLike[] | null,
): readonly RewindNodeLike[] {
  if (store === null) return []
  if (Array.isArray(store)) return store as readonly RewindNodeLike[]
  if (order !== null && isNodeStore(store)) {
    const nodes: RewindNodeLike[] = []
    for (const key of order) {
      const node = store.get(key)
      if (node !== undefined) nodes.push(node)
    }
    return nodes
  }
  return typeof store.values === 'function' ? Array.from(store.values() as Iterable<RewindNodeLike>) : []
}

/** Read the Host turn anchors that map a rendered `data-chat-turn` row to an event seq. */
async function fetchTurnAnchors(sessionId: string, signal: AbortSignal): Promise<ReadonlyMap<number, RewindMatch>> {
  const query = new URLSearchParams({ sessionId })
  const response = await fetch(`${TURNS_PATH}?${query.toString()}`, {
    headers: { accept: 'application/json' },
    cache: 'no-store',
    signal,
  })
  if (!response.ok) return new Map()
  return parseTurnAnchors(await response.json() as unknown)
}

/** Narrow the turn-anchor payload into per-turn {@link RewindMatch} entries. */
function parseTurnAnchors(body: unknown): ReadonlyMap<number, RewindMatch> {
  const anchors = new Map<number, RewindMatch>()
  if (body === null || typeof body !== 'object') return anchors
  const turns = (body as { turns?: unknown }).turns
  if (!Array.isArray(turns)) return anchors
  for (const value of turns) {
    if (value === null || typeof value !== 'object') continue
    const record = value as Record<string, unknown>
    const turn = record.turn
    const userSeq = record.userSeq
    if (!Number.isSafeInteger(turn) || !Number.isSafeInteger(userSeq)) continue
    const promptText = typeof record.promptText === 'string' ? record.promptText : ''
    const attachments = parseTurnAttachments(record.attachments)
    anchors.set(turn as number, {
      messageSeq: userSeq as number,
      promptText,
      ...(attachments.length === 0 ? {} : { attachments }),
    })
  }
  return anchors
}

/** Narrow one Host attachment reference; malformed entries are dropped. */
function parseTurnAttachments(value: unknown): readonly RewindAttachment[] {
  if (!Array.isArray(value)) return []
  const attachments: RewindAttachment[] = []
  for (const item of value) {
    if (item === null || typeof item !== 'object') continue
    const record = item as Record<string, unknown>
    if (record.kind !== 'image' && record.kind !== 'file') continue
    const kind = record.kind
    attachments.push({
      kind,
      attachmentId: typeof record.attachmentId === 'string' ? record.attachmentId : '',
      name: typeof record.name === 'string' && record.name !== '' ? record.name : kind,
      mediaType: typeof record.mediaType === 'string' && record.mediaType !== '' ? record.mediaType : 'application/octet-stream',
    })
  }
  return attachments
}

/**
 * Map every rendered user-message row onto its Host turn anchor.
 *
 * DSH 0.2.x flow rows carry `data-chat-flow-kind="user"` and `data-chat-turn` but
 * no event seq; the Host endpoint supplies the seq and the message text the
 * restart dialog needs. Duplicate grouped rows keep the first portal target.
 * @param anchors - per-turn rewind matches loaded from the Host.
 * @returns one portal target per direct user message, in document order.
 */
function sessionRows(sessionId: string): HTMLElement[] {
  return Array.from(document.querySelectorAll<HTMLElement>('[data-conversation-session]'))
    .filter(root => root.dataset.conversationSession === sessionId)
    .flatMap(root => Array.from(root.querySelectorAll<HTMLElement>('[data-chat-flow-kind="user"][data-chat-turn]')))
}

function collectDomPortalTargets(anchors: ReadonlyMap<number, RewindMatch>, sessionId: string): readonly RewindPortalTarget[] {
  if (anchors.size === 0) return []
  const targets: RewindPortalTarget[] = []
  const seen = new Set<number>()
  for (const row of sessionRows(sessionId)) {
    const turn = Number(row.dataset.chatTurn)
    if (!Number.isSafeInteger(turn)) continue
    const matched = anchors.get(turn)
    if (matched === undefined || seen.has(matched.messageSeq)) continue
    const actions = findActionsContainer(row)
    if (!(actions instanceof HTMLElement)) continue
    seen.add(matched.messageSeq)
    targets.push({ container: actions, matched })
  }
  return targets
}

/** 0.2.x bridge: rendered DOM rows matched through Host-provided turn anchors. */
function DomRewindMessagePortals({ sessionId, openRestoredSession }: RewindPortalBridgeProps): ReactNode {
  const [targets, setTargets] = useState<readonly RewindPortalTarget[]>([])
  const anchors = useRef<ReadonlyMap<number, RewindMatch>>(new Map())

  useLayoutEffect(() => {
    let active = true
    let queued = false
    let loading = false
    let retry: ReturnType<typeof setTimeout> | undefined
    const controller = new AbortController()
    anchors.current = new Map()
    const refresh = (): void => {
      if (!active) return
      const next = collectDomPortalTargets(anchors.current, sessionId)
      setTargets(current => samePortalTargets(current, next) ? current : next)
      const missing = sessionRows(sessionId).some(row => Number.isSafeInteger(Number(row.dataset.chatTurn)) && !anchors.current.has(Number(row.dataset.chatTurn)))
      if (missing && !loading && retry === undefined) void load()
    }
    const queueRefresh = (): void => {
      if (queued || !active) return
      queued = true
      queueMicrotask(() => {
        queued = false
        refresh()
      })
    }
    const load = async (): Promise<void> => {
      if (!active || loading) return
      loading = true
      try {
        const loaded = await fetchTurnAnchors(sessionId, controller.signal)
        if (!active) return
        anchors.current = loaded
      } catch {
        // A transient failure is retried only while a rendered turn lacks an anchor.
      } finally {
        loading = false
        if (active) {
          // Bound retries when the DOM precedes persistence, and avoid fetching
          // again for every streamed token or portal insertion.
          retry = setTimeout(() => {
            retry = undefined
            queueRefresh()
          }, 1000)
          queueRefresh()
        }
      }
    }
    void load()
    refresh()
    const observer = new MutationObserver(queueRefresh)
    observer.observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ['data-chat-turn'] })
    return () => {
      active = false
      controller.abort()
      clearTimeout(retry)
      observer.disconnect()
    }
  }, [sessionId])

  return targets.map(target => createPortal(
    <RewindMessageAction matched={target.matched} sessionId={sessionId} openRestoredSession={openRestoredSession} />,
    target.container,
    `${sessionId}:${String(target.matched.messageSeq)}`,
  ))
}

/** Legacy bridge for 0.1.x hosts that still inject a chat snapshot hook. */
function LegacyRewindMessagePortals({ sessionId, openRestoredSession, readSnapshot }: RewindPortalBridgeProps & { readonly readSnapshot: SnapshotSelectorHook }): ReactNode {
  const chatOf = (snapshot: ConversationSnapshotLike): ChatSnapshotLike => snapshot.chat ?? snapshot
  const chatOrder = readSnapshot<readonly string[] | null>(snapshot => chatOf(snapshot).order ?? null)
  const chatStore = readSnapshot<ChatNodeStoreLike | readonly RewindNodeLike[] | null>(
    snapshot => chatOf(snapshot).nodes ?? null,
  )
  const nodes = useMemo(() => collectChatNodes(chatOrder, chatStore), [chatOrder, chatStore])
  const [targets, setTargets] = useState<readonly RewindPortalTarget[]>([])

  useLayoutEffect(() => {
    let active = true
    let queued = false
    const refresh = (): void => {
      if (!active) return
      const next = collectPortalTargets(nodes)
      setTargets(current => samePortalTargets(current, next) ? current : next)
    }
    const queueRefresh = (): void => {
      if (queued || !active) return
      queued = true
      queueMicrotask(() => {
        queued = false
        refresh()
      })
    }
    refresh()
    const observer = new MutationObserver(queueRefresh)
    observer.observe(document.body, { childList: true, subtree: true })
    return () => {
      active = false
      observer.disconnect()
    }
  }, [nodes])

  return targets.map(target => createPortal(
    <RewindMessageAction matched={target.matched} sessionId={sessionId} openRestoredSession={openRestoredSession} />,
    target.container,
    `${sessionId}:${String(target.matched.messageSeq)}`,
  ))
}

/**
 * Session-scoped bridge that portals rewind controls into direct user-message action rows.
 *
 * DSH 0.1.x passes chat snapshot hooks; DSH 0.2.0 stopped injecting them, so the
 * bridge falls back to DOM rows plus the Host turn-anchor endpoint.
 */
export function RewindMessagePortals(props: RewindPortalBridgeProps): ReactNode {
  const readSnapshot = props.useChat ?? props.useSession
  if (readSnapshot === undefined) {
    return <DomRewindMessagePortals key={props.sessionId} sessionId={props.sessionId} openRestoredSession={props.openRestoredSession} />
  }
  return <LegacyRewindMessagePortals {...props} readSnapshot={readSnapshot} />
}

/** User-message action and its review-first file/conversation restore dialog. */
export function RewindMessageAction({ matched, sessionId, openRestoredSession }: RewindMessageActionProps): ReactNode {
  const t = useText()
  const [open, setOpen] = useState(false)
  const [loading, setLoading] = useState(false)
  const [preview, setPreview] = useState<Preview | null>(null)
  const [mode, setMode] = useState<RewindMode>('both')
  const [applying, setApplying] = useState(false)
  const [loadingDetails, setLoadingDetails] = useState(false)
  const [stale, setStale] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [completed, setCompleted] = useState<string | null>(null)
  const loadAbort = useRef<AbortController | null>(null)
  const applyPending = useRef(false)
  const modeTouched = useRef(false)

  useEffect(() => () => {
    loadAbort.current?.abort()
    loadAbort.current = null
  }, [])

  const load = useCallback(async () => {
    loadAbort.current?.abort()
    const controller = new AbortController()
    loadAbort.current = controller
    setLoading(true)
    setStale(false)
    setError(null)
    setCompleted(null)
    try {
      const response = await fetch(`${PATH}?sessionId=${encodeURIComponent(sessionId)}&messageSeq=${String(matched.messageSeq)}`, {
        method: 'GET', headers: { accept: 'application/json' }, cache: 'no-store', signal: controller.signal,
      })
      const decoded = decodePreview(await responseJson(response))
      if (loadAbort.current === controller) {
        setPreview(decoded)
        if (!modeTouched.current) {
          setMode(decoded.status === 'ready' && decoded.totalChanges > 0 ? 'both' : 'messages')
        }
      }
    } catch (caught) {
      if (!controller.signal.aborted) {
        setPreview({ status: 'failed', error: friendlyError(caught) })
        if (!modeTouched.current) setMode('messages')
      }
    } finally {
      if (loadAbort.current === controller) {
        loadAbort.current = null
        setLoading(false)
      }
    }
  }, [matched.messageSeq, sessionId])

  const show = (): void => {
    setOpen(true)
    setPreview(null)
    setMode('both')
    modeTouched.current = false
    setStale(false)
    void load()
  }
  const close = (): void => {
    if (applying) return
    loadAbort.current?.abort()
    loadAbort.current = null
    setLoading(false)
    setOpen(false)
  }
  const chooseMode = (next: RewindMode): void => {
    if (applying) return
    modeTouched.current = true
    setMode(next)
    setError(null)
    setCompleted(null)
  }
  const ready = preview?.status === 'ready' ? preview : null
  const hasFileChanges = ready !== null && ready.totalChanges > 0
  const driftBlocked = hasFileChanges && ready?.operationChanged === true
  const sharedBlocked = (ready?.activeSessionIds.length ?? 0) > 0
  const planMissing = hasFileChanges && ready !== null && !sharedBlocked && !driftBlocked
    && (ready.planId === undefined || ready.confirmation === undefined)
  const canApply = preview !== null
    && !loading
    && !applying
    && !loadingDetails
    && completed === null
    && (mode === 'messages'
      ? true
      : ready !== null && hasFileChanges && !driftBlocked && !sharedBlocked && !planMissing && !stale)

  const loadAllChanges = async (): Promise<void> => {
    if (ready === null || loadingDetails || !ready.truncated) return
    setLoadingDetails(true)
    setError(null)
    try {
      const collected = [...ready.changes]
      let offset = collected.length
      while (offset < ready.totalChanges) {
        const response = await fetch(`${PATH}?sessionId=${encodeURIComponent(sessionId)}&messageSeq=${String(matched.messageSeq)}&details=1&offset=${String(offset)}&limit=200`, {
          method: 'GET', headers: { accept: 'application/json' }, cache: 'no-store',
        })
        const page = decodePreview(await responseJson(response))
        if (page.status !== 'ready'
          || page.checkpointId !== ready.checkpointId
          || page.totalChanges !== ready.totalChanges
          || page.offset !== offset) {
          throw new RewindRequestError('PLAN_STALE', t.listChangedWhileExpanding)
        }
        collected.push(...page.changes)
        offset += page.changes.length
        if (page.changes.length === 0) break
      }
      if (offset !== ready.totalChanges) throw new RewindRequestError('PLAN_STALE', t.incompleteFileList)
      setPreview({ ...ready, changes: collected, truncated: false })
    } catch (caught) {
      if (caught instanceof RewindRequestError && caught.code === 'PLAN_STALE') setStale(true)
      setError(friendlyError(caught))
    } finally {
      setLoadingDetails(false)
    }
  }

  const applyRestore = async (): Promise<void> => {
    if (preview === null || !canApply || applyPending.current) return
    const body: Record<string, unknown> = {
      mode,
      sessionId,
      messageSeq: matched.messageSeq,
    }
    if (mode !== 'messages') {
      if (ready === null || ready.planId === undefined || ready.confirmation === undefined) return
      body.checkpointId = ready.checkpointId
      body.planId = ready.planId
      body.confirmation = ready.confirmation
    }
    applyPending.current = true
    setApplying(true)
    setError(null)
    try {
      const response = await fetch(PATH, {
        method: 'POST',
        headers: { accept: 'application/json', 'content-type': 'application/json' },
        body: JSON.stringify(body),
      })
      const result = recordOf(await responseJson(response))
      const resultMode = requiredString(result.mode, 'mode')
      if (resultMode !== mode) throw new Error(t.modeMismatch(resultMode))
      if (mode === 'messages') {
        const childSessionId = requiredString(result.sessionId, 'sessionId')
        setCompleted(t.completedMessages)
        try {
          await openRestoredSession(childSessionId, matched.promptText, matched.attachments?.map(attachment => ({ ...attachment, sourceSessionId: sessionId, messageSeq: matched.messageSeq })))
          setOpen(false)
        } catch (navigationError) {
          setError(t.openFailed(messageOf(navigationError)))
        }
        return
      }
      if (mode === 'code') {
        requiredString(result.rescuePointId, 'rescuePointId')
        setCompleted(t.completedCode)
        return
      }
      const childSessionId = requiredString(result.sessionId, 'sessionId')
      requiredString(result.rescuePointId, 'rescuePointId')
      setCompleted(t.completedBoth)
      try {
        await openRestoredSession(childSessionId, matched.promptText, matched.attachments?.map(attachment => ({ ...attachment, sourceSessionId: sessionId, messageSeq: matched.messageSeq })))
        setOpen(false)
      } catch (navigationError) {
        setError(t.restoredButOpenFailed(messageOf(navigationError)))
      }
    } catch (caught) {
      if (caught instanceof RewindRequestError && (caught.code === 'PLAN_STALE' || caught.code === 'WORKSPACE_IN_USE')) {
        setStale(true)
      }
      setError(friendlyError(caught))
    } finally {
      applyPending.current = false
      setApplying(false)
    }
  }

  const captureNotice = describeCaptureNotice(ready)
  const actionLabel = mode === 'both' ? t.actionRestoreAndRestart : mode === 'code' ? t.actionRestoreFiles : t.actionMessagesOnly
  const radioName = `dcl-rewind-${sessionId}-${String(matched.messageSeq)}`
  const branchChanged = ready !== null && ready.checkpointBranch !== ready.currentBranch

  return (
    <div className="dcl-rewind-tail">
      <Tooltip label={t.rewindTooltip} side="bottom">
        <button type="button" className="dcl-rewind-trigger" onClick={show} aria-label={t.rewindTooltip}>
          <RewindIcon size={16} />
        </button>
      </Tooltip>
      <Modal
        open={open}
        onClose={close}
        title={t.rewindTooltip}
        closeLabel={t.dialogClose}
        description={t.dialogDescription}
        className="dcl-rewind-dialog"
        contentClassName="dcl-rewind-content"
        footer={(
          <>
            <Button variant="outline" onClick={close} disabled={applying}>{t.cancel}</Button>
            <Button variant="primary" onClick={() => { void applyRestore() }} disabled={!canApply}>
              {applying ? t.applying : completed === null ? actionLabel : t.done}
            </Button>
          </>
        )}
      >
        <div className="dcl-rewind-body">
          {loading && <p className="dcl-rewind-status">{t.checkingFiles}</p>}
          {preview?.status === 'pending' && <p className="dcl-rewind-status">{t.previewPending}</p>}
          {preview?.status === 'missing' && <p className="dcl-rewind-error">{t.previewMissing}</p>}
          {preview?.status === 'skipped' && <p className="dcl-rewind-status">{explainCheckpointSkip(preview.reason)}</p>}
          {preview?.status === 'failed' && <p className="dcl-rewind-error">{explainCheckpointFailure(preview.error)}</p>}
          {preview !== null && (
            <div className="dcl-rewind-options">
              <label className="dcl-rewind-option" data-selected={mode === 'both'} data-disabled={applying || !hasFileChanges}>
                <input type="radio" name={radioName} checked={mode === 'both'} disabled={applying || !hasFileChanges} onChange={() => { chooseMode('both') }} />
                <span className="dcl-rewind-option-content"><strong>{t.modeBothTitle}</strong><span className="dcl-rewind-option-description">{t.modeBothDescription}</span></span>
              </label>
              <label className="dcl-rewind-option" data-selected={mode === 'code'} data-disabled={applying || !hasFileChanges}>
                <input type="radio" name={radioName} checked={mode === 'code'} disabled={applying || !hasFileChanges} onChange={() => { chooseMode('code') }} />
                <span className="dcl-rewind-option-content"><strong>{t.modeCodeTitle}</strong><span className="dcl-rewind-option-description">{t.modeCodeDescription}</span></span>
              </label>
              <label className="dcl-rewind-option" data-selected={mode === 'messages'} data-disabled={applying}>
                <input type="radio" name={radioName} checked={mode === 'messages'} disabled={applying} onChange={() => { chooseMode('messages') }} />
                <span className="dcl-rewind-option-content"><strong>{t.modeMessagesTitle}</strong><span className="dcl-rewind-option-description">{t.modeMessagesDescription}</span></span>
              </label>
            </div>
          )}
          {ready !== null && (
            <>
              {captureNotice !== null && <p className="dcl-rewind-warning">{captureNotice}</p>}
              <div className="dcl-rewind-summary">
                {mode === 'messages'
                  ? <strong>{t.filesUnchanged}</strong>
                  : <strong>{t.filesToRestore(ready.totalChanges)}</strong>}
                <span>{mode === 'both' ? t.summaryBoth : mode === 'code' ? t.summaryCode : t.summaryMessages}</span>
              </div>
              {sharedBlocked && (
                <p className="dcl-rewind-error">{t.sharedBlocked}</p>
              )}
              {ready.headChanged && !ready.operationChanged && (
                <p className="dcl-rewind-warning">{branchChanged ? t.branchChanged : t.headAdvanced}</p>
              )}
              {driftBlocked && <p className="dcl-rewind-warning">{t.driftBlocked}</p>}
              {planMissing && <p className="dcl-rewind-error">{t.planMissing}</p>}
              {stale && <p className="dcl-rewind-error">{t.stale}</p>}
              {ready.totalChanges === 0 && <p className="dcl-rewind-status">{t.nothingToRestore}</p>}
              {ready.changes.length > 0 && (
                <div className="dcl-rewind-files">
                  {ready.changes.map(change => <div className="dcl-rewind-file" key={change.path}><code>{change.path}</code><span className="dcl-rewind-kind">{fileRecoveryLabel(change.kind)}</span></div>)}
                </div>
              )}
              {ready.truncated && (
                <div className="dcl-rewind-file-actions"><Button variant="outline" size="sm" onClick={() => { void loadAllChanges() }} disabled={loadingDetails}>{loadingDetails ? t.loadingAllFiles : t.viewAllFiles(ready.totalChanges)}</Button></div>
              )}
            </>
          )}
          {completed !== null && <p className="dcl-rewind-status">{completed}</p>}
          {error !== null && <p className="dcl-rewind-error">{error}</p>}
          {error !== null && <p className="dcl-rewind-backup">{t.backupNote}</p>}
          {!loading && (preview?.status !== 'ready' || stale || planMissing || sharedBlocked || driftBlocked) && <Button className="dcl-rewind-retry" variant="outline" size="sm" onClick={() => { void load() }}>{t.recheck}</Button>}
        </div>
      </Modal>
    </div>
  )
}

interface TurnRewindSettingsCardProps {
  readonly scope: SettingsScopeLike<TurnRewindSettingsValue> | undefined
}

interface ManageActionNotice {
  readonly warning: boolean
  readonly message: string
}

const EMPTY_SETTINGS_SNAPSHOT: SettingsScopeSnapshotLike<TurnRewindSettingsValue> = {
  status: 'unavailable', value: undefined, base: undefined, user: undefined, revision: undefined, writable: false, mode: 'host',
}

type NumberSettingsField = keyof Pick<TurnRewindSettingsValue,
  'maxRestorePoints' | 'maxTurnCheckpointsPerSession' | 'maxFiles' | 'maxFileBytes' | 'maxSnapshotBytes'
  | 'planTtlMs' | 'staleLockMs' | 'turnCheckpointTimeoutMs' | 'turnCheckpointMaxNewBytes'>

/** Numeric settings fields, in the order the card renders them. */
const NUMBER_FIELDS: readonly NumberSettingsField[] = [
  'maxRestorePoints', 'maxTurnCheckpointsPerSession', 'maxFiles', 'maxFileBytes', 'maxSnapshotBytes',
  'planTtlMs', 'staleLockMs', 'turnCheckpointTimeoutMs', 'turnCheckpointMaxNewBytes',
]

/** Checkpoint modes, in the order the select offers them. */
const CHECKPOINT_MODES: readonly TurnRewindSettingsValue['turnCheckpointMode'][] = ['off', 'auto', 'git-native', 'legacy']

/** Checkpoint trust policies, in the order the select offers them. */
const TRUST_MODES: readonly TurnRewindSettingsValue['turnCheckpointTrust'][] = ['fast', 'strict']

/** Settings card for the `turn-rewind` namespace: runtime options plus checkpoint management. */
export function TurnRewindSettingsCard({ scope }: TurnRewindSettingsCardProps): ReactNode {
  const t = useText()
  const snapshot = useSyncExternalStore(
    useCallback((notify: () => void) => scope?.subscribe(notify) ?? (() => {}), [scope]),
    useCallback(() => scope?.getSnapshot() ?? EMPTY_SETTINGS_SNAPSHOT, [scope]),
  )
  const [manage, setManage] = useState<ManageOverview | null>(null)
  const [manageLoading, setManageLoading] = useState(false)
  const [manageError, setManageError] = useState<string | null>(null)
  const [manageNotice, setManageNotice] = useState<ManageActionNotice | null>(null)
  const [formError, setFormError] = useState<string | null>(null)
  const [busy, setBusy] = useState<string | null>(null)
  const [drafts, setDrafts] = useState<Partial<Record<NumberSettingsField, string>>>({})
  const [confirmClearAll, setConfirmClearAll] = useState(false)
  const [collapsed, setCollapsed] = useState<ReadonlySet<string>>(new Set())
  // Official plugin cards collapse behind a disclosure row; this card keeps the
  // same reading gesture so the settings page stays one row per plugin.
  const [cardOpen, setCardOpen] = useState(false)

  const refreshManage = useCallback(async (): Promise<void> => {
    setManageLoading(true)
    setManageError(null)
    try {
      const response = await fetch(MANAGE_PATH, { method: 'GET', headers: { accept: 'application/json' }, cache: 'no-store' })
      setManage(decodeManageOverview(await responseJson(response)))
    } catch (caught) {
      setManageError(messageOf(caught))
    } finally {
      setManageLoading(false)
    }
  }, [])

  useEffect(() => { void refreshManage() }, [refreshManage])

  const userLayer = snapshot.user !== null && typeof snapshot.user === 'object' ? snapshot.user as Record<string, unknown> : {}
  const value = snapshot.value
  const writable = snapshot.writable && snapshot.status === 'ready'

  const commitEnum = (field: string, next: string): void => {
    if (scope === undefined || !writable) return
    setFormError(null)
    void scope.set(field, next).catch((caught: unknown) => { setFormError(messageOf(caught)) })
  }

  const commitNumber = (field: NumberSettingsField): void => {
    if (scope === undefined || !writable) return
    const draft = drafts[field]
    if (draft === undefined) return
    setDrafts((current) => { const next = { ...current }; delete next[field]; return next })
    if (draft.trim() === '') {
      void scope.unset(field).catch((caught: unknown) => { setFormError(messageOf(caught)) })
      return
    }
    const parsed = Number.parseInt(draft, 10)
    if (!Number.isSafeInteger(parsed) || parsed <= 0) {
      setFormError(t.positiveInteger(field))
      return
    }
    if (parsed === value?.[field]) return
    setFormError(null)
    void scope.set(field, parsed).catch((caught: unknown) => { setFormError(messageOf(caught)) })
  }

  const runManageAction = async (body: Record<string, unknown>, key: string): Promise<void> => {
    if (busy !== null) return
    setBusy(key)
    setManageError(null)
    setManageNotice(null)
    setConfirmClearAll(false)
    try {
      const result = await responseJson(await fetch(MANAGE_PATH, {
        method: 'POST',
        headers: { accept: 'application/json', 'content-type': 'application/json' },
        body: JSON.stringify(body),
      }))
      setManageNotice(decodeManageActionNotice(result))
      await refreshManage()
    } catch (caught) {
      setManageError(messageOf(caught))
    } finally {
      setBusy(null)
    }
  }

  const toggleWorkspace = (workspace: string): void => {
    setCollapsed((current) => {
      const next = new Set(current)
      if (next.has(workspace)) next.delete(workspace)
      else next.add(workspace)
      return next
    })
  }

  return (
    <div className="dcl-trs-card" data-open={cardOpen}>
      <button
        type="button"
        className="dcl-trs-card-head"
        aria-expanded={cardOpen}
        onClick={() => { setCardOpen(value => !value) }}
      >
        <span className="dcl-trs-card-heading">
          <strong>{t.settingsCardTitle}</strong>
          <span className="dcl-trs-card-description">{t.settingsCardDescription}</span>
        </span>
        <svg className="dcl-trs-card-chevron" width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden="true">
          <path d="M4.5 6.5 8 10l3.5-3.5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      </button>
      {cardOpen && (
      <div className="dcl-trs-card-body">
      <section className="dcl-trs-section">
        <div className="dcl-trs-section-title">
          <strong>{t.autoCheckpointSection}</strong>
        </div>
        {snapshot.status === 'loading' && <p className="dcl-trs-status">{t.settingsLoading}</p>}
        {snapshot.status === 'unavailable' && <p className="dcl-trs-status">{t.settingsUnavailable}</p>}
        {snapshot.status === 'ready' && !snapshot.writable && <p className="dcl-trs-status">{t.settingsReadOnly}</p>}
        {value !== undefined && (
          <>
            <div className="dcl-trs-field">
              <span className="dcl-trs-field-label"><strong>{t.autoCheckpointLabel}</strong>
                <span className="dcl-trs-field-desc">{t.autoCheckpointDescription}</span></span>
              <span className="dcl-trs-field-control">
                <select
                  value={value.turnCheckpointMode}
                  disabled={!writable || busy !== null}
                  onChange={(event) => { commitEnum('turnCheckpointMode', event.target.value) }}
                >
                  {CHECKPOINT_MODES.map((option) => (
                    <option key={option} value={option}>{t.checkpointModes[option]}</option>
                  ))}
                </select>
                {userLayer.turnCheckpointMode !== undefined && <span className="dcl-trs-override">{t.overridden}</span>}
                {userLayer.turnCheckpointMode !== undefined && (
                  <Button variant="ghost" size="sm" disabled={!writable || busy !== null}
                    onClick={() => { setFormError(null); void scope?.unset('turnCheckpointMode').catch((caught: unknown) => { setFormError(messageOf(caught)) }) }}>{t.resetToDefault}</Button>
                )}
              </span>
            </div>
            <div className="dcl-trs-field">
              <span className="dcl-trs-field-label"><strong>{t.trustLabel}</strong>
                <span className="dcl-trs-field-desc">{t.trustDescription}</span></span>
              <span className="dcl-trs-field-control">
                <select
                  value={value.turnCheckpointTrust}
                  disabled={!writable || busy !== null}
                  onChange={(event) => { commitEnum('turnCheckpointTrust', event.target.value) }}
                >
                  {TRUST_MODES.map((option) => (
                    <option key={option} value={option}>{t.trustOptions[option]}</option>
                  ))}
                </select>
                {userLayer.turnCheckpointTrust !== undefined && <span className="dcl-trs-override">{t.overridden}</span>}
                {userLayer.turnCheckpointTrust !== undefined && (
                  <Button variant="ghost" size="sm" disabled={!writable || busy !== null}
                    onClick={() => { setFormError(null); void scope?.unset('turnCheckpointTrust').catch((caught: unknown) => { setFormError(messageOf(caught)) }) }}>{t.resetToDefault}</Button>
                )}
              </span>
            </div>
            {NUMBER_FIELDS.map((field) => (
              <div className="dcl-trs-field" key={field}>
                <span className="dcl-trs-field-label"><strong>{t.numberFields[field].label}</strong>
                  <span className="dcl-trs-field-desc">{t.numberFields[field].description}</span></span>
                <span className="dcl-trs-field-control">
                  <input
                    type="number" min={1} step={1}
                    value={drafts[field] ?? String(value[field])}
                    disabled={!writable || busy !== null}
                    onChange={(event) => { setDrafts((current) => ({ ...current, [field]: event.target.value })) }}
                    onBlur={() => { commitNumber(field) }}
                    onKeyDown={(event) => { if (event.key === 'Enter') commitNumber(field) }}
                  />
                  {userLayer[field] !== undefined && <span className="dcl-trs-override">{t.overridden}</span>}
                  {userLayer[field] !== undefined && (
                    <Button variant="ghost" size="sm" disabled={!writable || busy !== null}
                      onClick={() => { setFormError(null); void scope?.unset(field).catch((caught: unknown) => { setFormError(messageOf(caught)) }) }}>{t.resetToDefault}</Button>
                  )}
                </span>
              </div>
            ))}
          </>
        )}
        {formError !== null && <p className="dcl-trs-error">{formError}</p>}
        <p className="dcl-trs-storage">{t.storageDir(manage?.storageDir ?? '…')}</p>
      </section>
      <section className="dcl-trs-section">
        <div className="dcl-trs-section-title">
          <strong>{t.manageSection}</strong>
          <span className="dcl-trs-section-title-actions">
            <Button variant="outline" size="sm" onClick={() => { void refreshManage() }} disabled={manageLoading}>
              {manageLoading ? t.refreshing : t.refresh}
            </Button>
            {manage !== null && manage.workspaces.length > 0 && (
              confirmClearAll
                ? (
                  <>
                    <Button variant="outline" size="sm" onClick={() => { setConfirmClearAll(false) }} disabled={busy !== null}>{t.cancel}</Button>
                    <Button variant="primary" size="sm" onClick={() => { void runManageAction({ action: 'clear-all' }, 'clear-all') }} disabled={busy !== null}>
                      {busy === 'clear-all' ? t.clearing : t.confirmClearAll}
                    </Button>
                  </>
                )
                : <Button variant="outline" size="sm" onClick={() => { setConfirmClearAll(true) }} disabled={busy !== null}>{t.clearAll}</Button>
            )}
          </span>
        </div>
        <p className="dcl-trs-manage-total">
          {manage === null
            ? t.manageLoading
            : t.manageTotal(
                manage.workspaces.length,
                manage.totalBytes >= 0 ? manage.workspaces.reduce((total, workspace) => total + workspace.restorePoints.length, 0) : 0,
                formatBytes(manage.totalBytes),
              )}
        </p>
        {manageNotice !== null && <p className="dcl-trs-notice" data-warning={manageNotice.warning}>{manageNotice.message}</p>}
        {manageError !== null && <p className="dcl-trs-error">{manageError}</p>}
        {manage?.workspaces.map((workspace) => (
          <div className="dcl-trs-workspace" key={workspace.workspace}>
            <div className="dcl-trs-workspace-head">
              <span className="dcl-trs-workspace-path" title={workspace.workspace}>{workspace.workspace}</span>
              <span className="dcl-trs-workspace-meta">{t.workspacePoints(workspace.restorePoints.length)} · {formatBytes(workspace.totalBytes)}</span>
              {workspace.recoveryCount > 0 && <span className="dcl-trs-badge">{t.pendingRecoveries(workspace.recoveryCount)}</span>}
              <Button variant="ghost" size="sm" onClick={() => { toggleWorkspace(workspace.workspace) }}>
                {collapsed.has(workspace.workspace) ? t.expand : t.collapse}
              </Button>
              <Button variant="outline" size="sm"
                onClick={() => { void runManageAction({ action: 'clear-workspace', workspace: workspace.workspace }, `clear:${workspace.workspace}`) }}
                disabled={busy !== null || workspace.restorePoints.length === 0}>
                {busy === `clear:${workspace.workspace}` ? t.clearing : t.clearWorkspace}
              </Button>
            </div>
            {!collapsed.has(workspace.workspace) && workspace.restorePoints.length > 0 && (
              <ul className="dcl-trs-points">
                {workspace.restorePoints.map((point) => (
                  <li className="dcl-trs-point" key={point.id}>
                    <time>{formatTime(point.createdAt)}</time>
                    <span className="dcl-trs-point-kind">{t.pointKinds[point.kind] ?? point.kind}</span>
                    <span className="dcl-trs-point-size">{formatBytes(point.totalBytes)}</span>
                    <span className="dcl-trs-point-files">{t.fileCount(point.fileCount)}</span>
                    {point.sessionId !== undefined && <code>{point.sessionId}</code>}
                    <Button variant="ghost" size="sm"
                      onClick={() => { void runManageAction({ action: 'delete', workspace: workspace.workspace, restorePointId: point.id }, `delete:${point.id}`) }}
                      disabled={busy !== null}>
                      {busy === `delete:${point.id}` ? t.deleting : t.remove}
                    </Button>
                  </li>
                ))}
              </ul>
            )}
          </div>
        ))}
        {manage !== null && manage.workspaces.length === 0 && <p className="dcl-trs-status">{t.noCheckpoints}</p>}
      </section>
      </div>
      )}
    </div>
  )
}

function decodeManageOverview(value: unknown): ManageOverview {
  const record = recordOf(value)
  const workspacesValue = record.workspaces
  if (!Array.isArray(workspacesValue)) throw new Error(uiText().manageMissingWorkspaces)
  return {
    storageDir: requiredString(record.storageDir, 'storageDir'),
    totalBytes: requiredInteger(record.totalBytes, 'totalBytes'),
    workspaces: workspacesValue.map((entry) => {
      const workspace = recordOf(entry)
      const pointsValue = workspace.restorePoints
      if (!Array.isArray(pointsValue)) throw new Error(uiText().manageMissingRestorePoints)
      return {
        workspace: requiredString(workspace.workspace, 'workspace'),
        totalBytes: requiredInteger(workspace.totalBytes, 'totalBytes'),
        recoveryCount: requiredInteger(workspace.recoveryCount, 'recoveryCount'),
        restorePoints: pointsValue.map((pointEntry) => {
          const point = recordOf(pointEntry)
          return {
            id: requiredString(point.id, 'id'),
            kind: requiredString(point.kind, 'kind'),
            format: requiredInteger(point.format, 'format'),
            createdAt: requiredInteger(point.createdAt, 'createdAt'),
            totalBytes: requiredInteger(point.totalBytes, 'totalBytes'),
            fileCount: requiredInteger(point.fileCount, 'fileCount'),
            ...optionalRecordString(point, 'sessionId'),
            ...optionalRecordString(point, 'label'),
          }
        }),
      }
    }),
  }
}

function decodeManageActionNotice(value: unknown): ManageActionNotice {
  const record = recordOf(value)
  const action = requiredString(record.action, 'action')
  if (action === 'clear-all') {
    if (!Array.isArray(record.reports)) throw new Error(uiText().clearMissingReports)
    const totals = record.reports.reduce((current, entry) => {
      const report = recordOf(entry)
      return {
        deleted: current.deleted + requiredInteger(report.deletedRestorePoints, 'deletedRestorePoints'),
        retained: current.retained + requiredInteger(report.retainedRestorePoints, 'retainedRestorePoints'),
      }
    }, { deleted: 0, retained: 0 })
    const failures = Array.isArray(record.failures) ? record.failures.length : 0
    const warning = record.status === 'partial' || totals.retained > 0 || failures > 0
    return {
      warning,
      message: uiText().clearedAll(totals.deleted, totals.retained, failures),
    }
  }
  const deleted = requiredInteger(record.deletedRestorePoints, 'deletedRestorePoints')
  const retained = requiredInteger(record.retainedRestorePoints, 'retainedRestorePoints')
  return {
    warning: retained > 0,
    message: uiText().cleared(deleted, retained),
  }
}

/** Format one byte count with human-friendly units. */
export function formatBytes(bytes: number): string {
  if (!Number.isFinite(bytes) || bytes < 0) return '0 B'
  const units = ['B', 'KB', 'MB', 'GB', 'TB']
  let value = bytes
  let unit = 0
  while (value >= 1024 && unit < units.length - 1) {
    value /= 1024
    unit += 1
  }
  return `${unit === 0 ? String(Math.round(value)) : value.toFixed(value >= 100 ? 0 : 1)} ${units[unit]}`
}

function formatTime(timestamp: number): string {
  const date = new Date(timestamp)
  return Number.isNaN(date.getTime()) ? String(timestamp) : date.toLocaleString()
}

function decodePreview(value: unknown): Preview {
  const record = recordOf(value)
  const status = requiredString(record.status, 'status')
  if (status === 'pending' || status === 'missing') return { status }
  if (status === 'skipped') return { status, reason: requiredString(record.reason, 'reason') }
  if (status === 'failed') return { status, error: requiredString(record.error, 'error') }
  if (status !== 'ready') throw new Error(uiText().unknownStatus(status))
  const changesValue = record.changes
  if (!Array.isArray(changesValue)) throw new Error(uiText().previewMissingChanges)
  const changes = changesValue.map((entry) => {
    const change = recordOf(entry)
    return { path: requiredString(change.path, 'path'), kind: requiredString(change.kind, 'kind') as ChangeKind }
  })
  const activeSessionIdsValue = record.activeSessionIds
  if (!Array.isArray(activeSessionIdsValue) || !activeSessionIdsValue.every(value => typeof value === 'string')) {
    throw new Error(uiText().previewMissingActiveSessionIds)
  }
  return {
    status,
    sessionId: requiredString(record.sessionId, 'sessionId'),
    messageSeq: requiredInteger(record.messageSeq, 'messageSeq'),
    turn: requiredInteger(record.turn, 'turn'),
    checkpointId: requiredString(record.checkpointId, 'checkpointId'),
    turnStartSeq: requiredInteger(record.turnStartSeq, 'turnStartSeq'),
    totalChanges: requiredInteger(record.totalChanges, 'totalChanges'),
    changes,
    offset: requiredInteger(record.offset, 'offset'),
    truncated: requiredBoolean(record.truncated, 'truncated'),
    skippedCount: typeof record.skippedCount === 'number' ? record.skippedCount : 0,
    skipped: Array.isArray(record.skipped)
      ? record.skipped.map((entry) => {
          const skip = recordOf(entry)
          return { path: requiredString(skip.path, 'path'), reason: requiredString(skip.reason, 'reason') }
        })
      : [],
    ...(record.captureTruncated === 'file-limit' || record.captureTruncated === 'snapshot-limit'
      ? { captureTruncated: record.captureTruncated as 'file-limit' | 'snapshot-limit' }
      : {}),
    headChanged: requiredBoolean(record.headChanged, 'headChanged'),
    operationChanged: requiredBoolean(record.operationChanged, 'operationChanged'),
    ...optionalRecordString(record, 'checkpointHead'),
    ...optionalRecordString(record, 'checkpointBranch'),
    ...optionalRecordString(record, 'checkpointOperation'),
    ...optionalRecordString(record, 'currentHead'),
    ...optionalRecordString(record, 'currentBranch'),
    ...optionalRecordString(record, 'currentOperation'),
    activeSessionIds: activeSessionIdsValue as string[],
    restoreBlocked: requiredBoolean(record.restoreBlocked, 'restoreBlocked'),
    ...(typeof record.planId === 'string' ? { planId: record.planId } : {}),
    ...(typeof record.confirmation === 'string' ? { confirmation: record.confirmation } : {}),
  }
}

/** Resolve one conversation node to its DOM row key and rewind match. */
export function selectRewindMessageTarget(value: RewindNodeLike): { readonly matched: RewindMatch; readonly rowKey: string } | null {
  const node = 'key' in value && 'data' in value ? value.data : value
  const matched = selectRewindMessage(node)
  if (matched === null) return null
  return {
    matched,
    rowKey: 'key' in value && 'data' in value ? value.key : `node:${String(node.seq)}`,
  }
}

/** CSS-module class every DSH message action row matches (`<hash>_actions`). */
const ACTIONS_SELECTOR = '[class*="actions"]'
/**
 * Wrapper that owned the hover chrome and the action row before DSH 0.1.5. The
 * attribute is gone in 0.1.5 — the message row itself is the hover root now — so it
 * is only a fallback for older clients.
 */
const LEGACY_HOVER_ROOT_SELECTOR = '[data-time-hover-root="true"]'

/** Query one descendant, tolerating a row double that implements no `querySelector`. */
function queryInside(root: Element, selector: string): Element | null {
  const query = (root as Partial<Element>).querySelector
  return typeof query === 'function' ? query.call(root, selector) : null
}

/**
 * Resolve the container one rewind button is portalled into.
 *
 * DSH 0.1.5 renders the copy/branch icon row (`MessageIconActions`, class
 * `<hash>_actions`) as a direct child of the user-message row and dropped
 * `data-time-hover-root`; older clients nested that row under the removed wrapper.
 * Both shapes are tried, current first. There is no official slot for user-message
 * actions in 0.1.5 — only `conversation.chat.assistant-actions`, for finalized
 * assistant turns — so this bridge stays DOM-based.
 * @param row - the `[data-chat-flow-kind="user"]` row owning one message.
 * @returns the actions container, or null when the row exposes none.
 */
function findActionsContainer(row: Element): Element | null {
  const direct = queryInside(row, ACTIONS_SELECTOR)
  if (direct !== null) return direct
  const legacy = queryInside(row, LEGACY_HOVER_ROOT_SELECTOR)
  if (legacy === null) return null
  return queryInside(legacy, ACTIONS_SELECTOR) ?? legacy.lastElementChild
}

/**
 * Legacy chat-snapshot bridge kept for 0.1.x hosts and test doubles.
 * DSH 0.2.0 uses {@link collectDomPortalTargets} instead.
 */
export function collectPortalTargets(nodes: readonly RewindNodeLike[]): readonly RewindPortalTarget[] {
  const rows = new Map<string, HTMLElement>()
  for (const element of Array.from(document.querySelectorAll<HTMLElement>(
    '[data-chat-flow-kind="user"][data-chat-anchor-key]',
  ))) {
    const key = element.dataset.chatAnchorKey
    if (key !== undefined) rows.set(key, element)
  }
  const targets: RewindPortalTarget[] = []
  for (const value of nodes) {
    const target = selectRewindMessageTarget(value)
    if (target === null) continue
    const row = rows.get(target.rowKey)
    const actions = row === undefined ? null : findActionsContainer(row)
    if (!(actions instanceof HTMLElement)) continue
    targets.push({ container: actions, matched: target.matched })
  }
  return targets
}

/** Compare two attachment lists by identity: order and durable id both matter. */
function sameAttachments(
  left: readonly RewindAttachment[] | undefined,
  right: readonly RewindAttachment[] | undefined,
): boolean {
  const leftList = left ?? []
  const rightList = right ?? []
  return leftList.length === rightList.length && leftList.every((attachment, index) => {
    const other = rightList[index]
    return other !== undefined
      && attachment.kind === other.kind
      && attachment.attachmentId === other.attachmentId
      && attachment.name === other.name
      && attachment.mediaType === other.mediaType
  })
}

function samePortalTargets(
  left: readonly RewindPortalTarget[],
  right: readonly RewindPortalTarget[],
): boolean {
  return left.length === right.length && left.every((target, index) => {
    const other = right[index]
    return other !== undefined
      && target.container === other.container
      && target.matched.messageSeq === other.matched.messageSeq
      && target.matched.promptText === other.matched.promptText
      && sameAttachments(target.matched.attachments, other.matched.attachments)
  })
}

/**
 * Re-upload one durable attachment as a fresh draft attachment.
 *
 * The stored bytes are read back from the Host, wrapped in a `File`, and handed
 * to the composer bridge, because the composer only understands browser files.
 * @param attachment - durable reference taken from the rewound message.
 * @returns the rebuilt file, or `undefined` when the Host cannot serve it.
 */
export async function readAttachmentFile(attachment: RewindAttachment): Promise<File> {
  const query = new URLSearchParams({
    attachmentId: attachment.attachmentId,
    kind: attachment.kind,
    mediaType: attachment.mediaType,
    sessionId: attachment.sourceSessionId ?? '',
    messageSeq: String(attachment.messageSeq ?? ''),
  })
  const response = await fetch(`${ATTACHMENT_BYTES_PATH}?${query.toString()}`, {
    headers: { accept: 'application/json' },
    signal: AbortSignal.timeout(30_000),
  })
  const value = await responseJson(response) as { readonly data?: unknown }
  if (typeof value.data !== 'string') throw new Error(uiText().attachmentsFailed(attachment.name))
  const binary = atob(value.data)
  const bytes = new Uint8Array(binary.length)
  for (let index = 0; index < binary.length; index += 1) bytes[index] = binary.charCodeAt(index)
  return new File([bytes], attachment.name, { type: attachment.mediaType })
}

/**
 * Hand a rewound message's attachments back to the composer.
 *
 * Draft attachments are browser-owned `File`s with upload receipts, so the
 * durable references are read back from the Host and registered exactly the way
 * the composer's own picker does it: `createDrafts` allocates the drafts,
 * `input.for(scope).addAttachments` adopts their draft IDs.
 *
 * Use the public session input facade, which exists before the visual editor
 * mounts. Failures are surfaced to the rewind dialog and refused drafts are released.
 * @param ctx - client context carrying the conversation service.
 * @param sessionId - Session whose composer receives the files.
 * @param attachments - durable references carried by the rewound message.
 * @returns number of attachments actually restored.
 */
export async function restoreComposerAttachments(
  ctx: ClientContextLike,
  sessionId: string,
  attachments: readonly RewindAttachment[],
  prepared?: readonly PromiseSettledResult<File>[],
): Promise<number> {
  if (attachments.length === 0) return 0
  const conversation = ctx.conversation as unknown as {
    createDrafts?(sessionId: string, files: readonly File[]): readonly DraftAttachmentLike[]
    releaseDraftAttachments?(drafts: readonly DraftAttachmentLike[]): void
  }
  const scope = ctx.sessions.scope(sessionId)
  const input = scope === undefined ? undefined : ctx.conversation.input.for(scope)
  const failed = (items: readonly RewindAttachment[]) => {
    const error = new Error(uiText().attachmentsFailed(items.map(item => item.name).join(', ')))
    // Navigation can unmount the originating dialog; retain the warning in the
    // destination session's composer instead of relying on that dialog alone.
    input?.notify?.('error', error.message)
    return error
  }
  if (typeof input?.addAttachments !== 'function' || typeof conversation.createDrafts !== 'function') throw failed(attachments)
  const results = prepared ?? await Promise.allSettled(attachments.map(readAttachmentFile))
  const files = results.flatMap(result => result.status === 'fulfilled' ? [result.value] : [])
  const missing = attachments.filter((_attachment, index) => results[index]?.status !== 'fulfilled')
  if (files.length === 0) throw failed(attachments)
  let drafts: readonly DraftAttachmentLike[]
  try { drafts = conversation.createDrafts(sessionId, files) } catch { throw failed(attachments) }
  let adopted = false
  try {
    adopted = drafts.length === files.length && input.addAttachments(drafts.map(draft => draft.id))
  } catch {
    adopted = false
  }
  if (!adopted) {
    // The composer refused the insertion (busy or locked); release the uploads
    // instead of leaving orphaned drafts behind.
    conversation.releaseDraftAttachments?.(drafts)
    throw failed(attachments)
  }
  if (missing.length !== 0) throw failed(missing)
  return drafts.length
}

/**
 * Open the rewound Session and put the message back into its composer.
 * @param ctx - client context carrying the Session navigation service.
 * @param sessionId - target Session.
 * @param promptText - message text to restore.
 * @param attachments - attachments carried by that message.
 */
export async function openSessionWithDraft(
  ctx: ClientContextLike,
  sessionId: string,
  promptText: string,
  attachments: readonly RewindAttachment[] = [],
): Promise<void> {
  // Read before navigation so the new draft is not submitted while bytes are
  // still in flight, and never append attachments to a later user message.
  const prepared = await Promise.allSettled(attachments.map(readAttachmentFile))
  if (typeof ctx.sessions.open === 'function') ctx.sessions.open(sessionId)
  else {
    const navigation = ctx.get?.('uiWorkspace') as { openSession(id: string): void } | undefined
    if (navigation === undefined) throw new Error(uiText().sessionNotReady)
    navigation.openSession(sessionId)
  }
  let lastError: unknown = new Error(uiText().sessionNotReady)
  for (let attempt = 0; attempt < 20; attempt += 1) {
    try {
      const scope = ctx.sessions.scope(sessionId)
      if (scope !== undefined) {
        ctx.conversation.input.for(scope).setDraft(promptText)
        await restoreComposerAttachments(ctx, sessionId, attachments, prepared)
        return
      }
      lastError = new Error(uiText().sessionNotReady)
    } catch (error) {
      if (prepared.length !== 0 && ctx.sessions.scope(sessionId) !== undefined) throw error
      lastError = error
    }
    await new Promise<void>(resolve => { setTimeout(resolve, 50) })
  }
  throw lastError
}

/**
 * Read one rewind response body without ever leaking a raw parse error.
 *
 * A missing route, a restarted Host, or a proxy answering before the plugin
 * loads all produce a body that is not the plugin's JSON envelope; those must
 * surface as an explained failure instead of `Failed to execute 'json' …`.
 * @param response - fetch response from the rewind endpoint.
 * @returns the decoded JSON body.
 */
export async function responseJson(response: Response): Promise<unknown> {
  const text = await response.text()
  let value: unknown
  try {
    value = text === '' ? undefined : JSON.parse(text) as unknown
  } catch {
    throw new RewindRequestError(
      response.ok ? 'REWIND_INVALID_RESPONSE' : 'REWIND_ENDPOINT_UNAVAILABLE',
      uiText().unparsableResponse(String(response.status)),
    )
  }
  const record = value !== null && typeof value === 'object' && !Array.isArray(value)
    ? value as Record<string, unknown>
    : undefined
  if (!response.ok) {
    throw new RewindRequestError(
      typeof record?.code === 'string'
        ? record.code
        : response.status === 404 ? 'REWIND_ENDPOINT_UNAVAILABLE' : 'REWIND_FAILED',
      typeof record?.error === 'string' ? record.error : uiText().requestFailed(String(response.status)),
    )
  }
  if (value === undefined) {
    throw new RewindRequestError('REWIND_INVALID_RESPONSE', uiText().emptyResponse)
  }
  return value
}

class RewindRequestError extends Error {
  constructor(readonly code: string, message: string) {
    super(message)
  }
}

function recordOf(value: unknown): Record<string, unknown> {
  if (value === null || typeof value !== 'object' || Array.isArray(value)) throw new Error(uiText().invalidObject)
  return value as Record<string, unknown>
}

function requiredString(value: unknown, name: string): string {
  if (typeof value !== 'string' || value === '') throw new Error(uiText().invalidField(name))
  return value
}

function requiredInteger(value: unknown, name: string): number {
  if (!Number.isSafeInteger(value) || (value as number) < 0) throw new Error(uiText().invalidField(name))
  return value as number
}

function requiredBoolean(value: unknown, name: string): boolean {
  if (typeof value !== 'boolean') throw new Error(uiText().invalidField(name))
  return value
}

function optionalRecordString(record: Record<string, unknown>, name: string): Record<string, string> {
  const value = record[name]
  if (value === undefined) return {}
  return { [name]: requiredString(value, name) }
}

/** Describe the user-visible result of restoring one changed file. */
export function fileRecoveryLabel(kind: ChangeKind): string {
  return uiText().fileKinds[kind]
}

function RewindIcon({ size }: { readonly size: number }): ReactNode {
  return (
    <svg width={size} height={size} viewBox="0 0 16 16" fill="none" aria-hidden="true">
      <path d="M6.35 3.25 2.75 7l3.6 3.75M3.1 7h5.15a4.25 4.25 0 0 1 4.25 4.25v1.25" stroke="currentColor" strokeWidth="1.45" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  )
}

function friendlyError(error: unknown): string {
  if (!(error instanceof RewindRequestError)) return messageOf(error)
  return uiText().errors[error.code] ?? error.message
}

/**
 * Describe what a checkpoint could not store, in one user-facing sentence.
 *
 * Limits leave a restore point partial rather than failing it, so the dialog has
 * to say which files stay untouched when the restore runs.
 * @param ready - decoded ready preview, or null.
 * @returns the warning text, or null when the checkpoint is complete.
 */
export function describeCaptureNotice(ready: ReadyPreview | null): string | null {
  if (ready === null) return null
  const example = (ready.skipped ?? [])[0]?.path
  if (ready.captureTruncated === 'snapshot-limit') return uiText().captureSnapshotLimit
  if (ready.captureTruncated === 'file-limit') return uiText().captureFileLimit
  if (ready.skippedCount > 0) return uiText().captureSkipped(ready.skippedCount, example)
  return null
}

/**
 * Explain one recorded checkpoint skip in user terms.
 *
 * A skip is not a failure of the message: the turn ran normally and only the
 * file snapshot is missing, so the text names the actual cause and the two
 * levers that fix it.
 * @param reason - reason recorded by the Host, usually a `[CODE] detail` line.
 * @returns one user-facing sentence.
 */
export function explainCheckpointSkip(reason: string): string {
  const code = /^\[([A-Z_]+)\]/.exec(reason)?.[1]
  const t = uiText()
  if (code === 'TURN_CHECKPOINT_TIMEOUT') return t.skipTimeout
  if (code === 'TURN_CHECKPOINT_DISABLED') return t.skipDisabled
  if (code === 'TURN_CHECKPOINT_NEW_CONTENT_LIMIT') return t.skipNewContentLimit
  return t.skipOther(reason)
}

/**
 * Explain one recorded checkpoint failure in user terms.
 *
 * The Host records the raw `[CODE] diagnostic` line; a non-Git project
 * directory is the common case and deserves a plain sentence instead of a
 * `git rev-parse` transcript.
 * @param message - recorded checkpoint failure message.
 * @returns one user-facing sentence.
 */
export function explainCheckpointFailure(message: string): string {
  const code = /^\[([A-Z_]+)\]/.exec(message)?.[1]
  const t = uiText()
  switch (code) {
    case 'GIT_COMMAND_FAILED':
      return /not a git repository/i.test(message) ? t.failureNotGitRepository : t.failureGitStatus(message)
    case 'FILE_TOO_LARGE':
    case 'SNAPSHOT_TOO_LARGE':
    case 'TOO_MANY_FILES':
      return t.failureSizeOrCount
    case 'UNSUPPORTED_FILE_TYPE':
      return t.failureUnsupportedType
    case 'IGNORE_FILE_INVALID':
      return t.failureIgnoreFileInvalid
    case 'INVALID_PATH':
      return t.failureInvalidPath
    default:
      return t.failureOther(message)
  }
}

function messageOf(error: unknown): string {
  return error instanceof Error ? error.message : String(error)
}
