/**
 * Build the dsh-memory-evolve client bundle.
 *
 * Produces lib/client.js in the exact wire format the DSH web shell expects:
 * a CJS factory handed to window.__ModuleLoader__.load({ id, factory }), with
 * platform modules resolved through the injected require (the loader module
 * table) and everything else inlined. CSS files are imported as text and
 * injected as a <style> tag by the entry's apply().
 *
 * esbuild is resolved from the DSH source checkout (the only place it is
 * installed); the plugin package itself has zero runtime dependencies.
 * Set DSH_SOURCE to the DSH checkout root when it is not the default
 * ~/.dsh/source/current (or wherever $DSH_HOME points).
 */
import { createRequire } from 'node:module'
import { fileURLToPath } from 'node:url'
import { homedir } from 'node:os'
import { dirname, join } from 'node:path'
import { existsSync, readFileSync, readdirSync } from 'node:fs'

const ROOT = join(dirname(fileURLToPath(import.meta.url)), '..')
/** DSH source checkout root; override with $DSH_SOURCE when not the default. */
const CHECKOUT = process.env.DSH_SOURCE ?? join(homedir(), '.dsh/source/current')

/**
 * Loader entry name — must equal the patch row `name` EXACTLY.
 *
 * 自 DSH 08-06 起插件采用标准安装（`dsh plugin --profile <name> add <pkg>`，
 * 包装进 profile 的 node_modules），加载器（client-modules）按 loader entry
 * 的 name 解析 client bundle 的注册 ID，而 loader entry 的 name 即
 * package.json 的 `name`。旧机制（`~/node_modules/@dsh-local/` 软链 +
 * `~/.dsh/config.yaml`）依赖 `@dsh-local/` 命名空间前缀，08-06 起已废弃
 * （config.yaml 不再被读取）。因此这里从 package.json 动态读取，避免硬编码
 * 前缀导致标准安装下 "loaded without registering"（见 issue #3）。
 */
const MANIFEST = JSON.parse(readFileSync(join(ROOT, 'package.json'), 'utf8'))
const PLUGIN_ID = MANIFEST.name

/** Platform module table (must stay aligned with packages/client/web/src/platform.ts + the runtime exemption). */
const EXTERNALS = [
  'react',
  'react/jsx-runtime',
  'react-dom',
  'react-dom/client',
  'cordis',
  '@deepseek-ai/dsh-client-ui-slots',
  '@deepseek-ai/dsh-client-web-react',
  '@deepseek-ai/dsh-client-ui-primitives',
  '@deepseek-ai/dsh-client-schema-form',
  '@deepseek-ai/dsh-client-runtime/client',
]

/** Locate the esbuild package inside a pnpm checkout (store or hoisted). */
function resolveEsbuild(checkout) {
  const store = join(checkout, 'node_modules/.pnpm')
  if (existsSync(store)) {
    const entries = readdirSync(store).filter((name) => name.startsWith('esbuild@')).sort()
    for (let i = entries.length - 1; i >= 0; i -= 1) {
      const candidate = join(store, entries[i], 'node_modules/esbuild/package.json')
      if (existsSync(candidate)) return candidate
    }
  }
  const hoisted = join(checkout, 'node_modules/esbuild/package.json')
  if (existsSync(hoisted)) return hoisted
  throw new Error(`esbuild not found under ${checkout} (set DSH_SOURCE to the DSH checkout root)`)
}

const require = createRequire(resolveEsbuild(CHECKOUT))
const esbuild = require('esbuild')

const banner = [
  `window.__ModuleLoader__.load({ id: ${JSON.stringify(PLUGIN_ID)}, factory: (require) => {`,
  'var module = { exports: {} }; var exports = module.exports;',
].join('\n')
const footer = 'return module.exports; } });'

// ⚠ 产物格式敏感点（2026-09-08 实测，esbuild 0.28.1，issue #40 修复时踩到）：
// text loader 把每个 CSS 文件内联成字符串时，会在「模板字符串（真实换行，
// 可读、仓库现状）」与「双引号字符串（\n 转义、整体一行）」两种格式间按
// 内容自动切换——当被内联的 CSS **含超过 2 个反引号** 时改用双引号格式，
// 于是 lib/client.js 整体重排（约 2150 行 diff，功能等价但提交噪声极大、
// 与仓库历史产物不再可比）。src/client/styles.css 目前正好只有 2 个反引号
// （首行注释里的 `me-`）：**新增 CSS 注释请勿再引入反引号**（用普通引号或
// 直接写类名即可）；若哪天必须超过 2 个，请连同重建后的产物一起提交并说明。
await esbuild.build({
  entryPoints: [join(ROOT, 'src/client/index.ts')],
  outfile: join(ROOT, 'lib/client.js'),
  bundle: true,
  format: 'cjs',
  platform: 'browser',
  target: 'es2022',
  external: EXTERNALS,
  define: {
    'process.env.NODE_ENV': '"production"',
    'import.meta.env.MODE': '"production"',
    'import.meta.env': '{"MODE":"production"}',
  },
  loader: { '.css': 'text' },
  banner: { js: banner },
  footer: { js: footer },
})

console.log('lib/client.js built')
