# DSH Prompt Rail

English | [中文](README.zh.md)

**Prompt Rail** is a compact vertical quick-jump rail for the DeepSeek Harness Web conversation view. One mark represents one **loaded ordinary user prompt**. Hover or keyboard focus shows its preview; clicking scrolls to that prompt.

![Prompt Rail](assets/screenshots/message-jump-rail.png)

## Behavior

- The rail stays vertically centered beside the session sidebar.
- Every mark has a 10px high hit slot, while its default visible mark is an 8px by 3px light line.
- Hover/focus makes the current mark 28px wide and dark; nearby marks taper to 20px, 14px, and 10px.
- Clicking records the selected prompt. When the pointer leaves, all marks return to their default length while the selected mark stays dark.
- Assistant, tool, command, steering, and injected-context rows are excluded. A one-prompt conversation still renders one mark.

## Install

Clone or copy this repository into the Harness root `plugins` directory:

```text
deepseek-harness/
└─ plugins/
   └─ dsh-prompt-rail/
```

Then open a terminal in the `deepseek-harness` root and run:

**Windows**

```bat
.\plugins\dsh-prompt-rail\install-and-restart.bat
```

**macOS / Linux**

```sh
node ./plugins/dsh-prompt-rail/compat/install.mjs
pnpm dsh web
```

Keep the `plugins/dsh-prompt-rail` directory after installation.
## Development

The development layout expects sibling checkouts:

```text
workspace/
├─ dsh/                       # DeepSeek Harness checkout
└─ dsh-prompt-rail/
```

Then run:

```sh
pnpm install
pnpm run check
```

`lib/` is committed because profile installation loads the prebuilt Host and browser files without running package build scripts.

## Release checklist

1. Add an exact compatibility patch for every supported pre-slot Harness revision.
2. Run `pnpm run check` and exercise `node compat/install.mjs --apply-only` in a clean matching checkout.
3. Commit source, `lib/`, `compat/`, README files, screenshot, and lockfile.
4. Push a `v0.1.0` tag and create a GitHub Release from that tag.
5. State the compatible Harness versions and revision hashes in the release notes.

## License

MIT
