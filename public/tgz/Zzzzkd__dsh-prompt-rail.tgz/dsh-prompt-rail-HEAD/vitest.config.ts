import { fileURLToPath } from 'node:url'
import { defineConfig } from 'vitest/config'

const dsh = (relative: string) => fileURLToPath(new URL(`../dsh/${relative}`, import.meta.url))

export default defineConfig({
  resolve: {
    alias: {
      '@deepseek-ai/dsh-client-runtime/client': dsh('packages/client/runtime/src/client/index.ts'),
      '@deepseek-ai/dsh-client-ui-conversation/client': dsh('packages/client/ui-conversation/src/client/index.ts'),
      '@deepseek-ai/dsh-client-ui-slots': dsh('packages/client/ui-slots/src/index.ts'),
      '@deepseek-ai/dsh-client-locale/client': dsh('packages/client/locale/src/client/index.ts'),
    },
  },
  test: {
    environment: 'node',
    include: ['tests/**/*.spec.{ts,tsx}'],
  },
})
