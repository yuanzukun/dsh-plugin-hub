/** Product copy for the message-jump rail. */
/** Simplified Chinese dictionary (the key-set source of truth). */
export declare const zh: {
    'navigator.aria': string;
    'navigator.item': string;
};
/** English dictionary mirroring the Chinese key set. */
export declare const en: typeof zh;
/** Plugin locale namespace. */
export declare const NS = "message-jump-rail";
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** This plugin's message navigation copy. */
        [NS]: keyof typeof zh;
    }
}
