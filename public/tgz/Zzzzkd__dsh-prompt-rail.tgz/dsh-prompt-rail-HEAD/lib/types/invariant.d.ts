/** Invariant companion for the browser-only message-jump rail package. */
import type { Context } from '@deepseek-ai/cordis';
/** Cordis companion-plugin name. */
export declare const name = "dsh-prompt-rail-invariant";
/** The invariant registry owns package registration. */
export declare const inject: string[];
/**
 * Register the package's invariant companion.
 * @param ctx - Context carrying the invariant registry.
 * @returns the registration disposer.
 */
export declare const apply: (ctx: Context) => Promise<() => void>;
