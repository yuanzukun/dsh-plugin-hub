# DSH Prompt Rail（消息跳转条）

[English](README.md) | 中文

**Prompt Rail** 是 DeepSeek Harness Web 会话页的紧凑纵向提示词快速跳转条。每一条横杠对应一条**当前已加载的普通用户提示词**。悬停或键盘聚焦会展示预览；点击会滚动跳转到对应提示词。

<img width="259" height="267" alt="image" src="https://github.com/user-attachments/assets/4052b9da-5e8d-4cf7-9269-793d225d46f0" />
<img width="963" height="920" alt="image" src="https://github.com/user-attachments/assets/ec47a665-44b6-4e96-8e3c-7257e6a1a69b" />
<img width="656" height="284" alt="image" src="https://github.com/user-attachments/assets/cd045c3c-b80f-4541-85b1-a905ff4f3958" />


## 效果

- 跳转条贴近会话侧边栏并保持上下居中。
- 每条都有 10px 高的可点击吸附区域；默认可见横杠为 8px × 3px 的浅色线。
- 悬停／聚焦项为深色 28px，附近横杠依次递减为 20px、14px、10px。
- 点击会记录当前选中提示词。鼠标离开后，全部横杠恢复默认长度，但选中项保持深色。
- assistant、工具、命令、steering 和注入上下文行不会进入导航；仅有一条提示词时也会显示。

## 安装

将本仓库 clone 或复制到 Harness 根目录的 `plugins` 目录：

```text
deepseek-harness/
└─ plugins/
   └─ dsh-prompt-rail/
```

然后在 `deepseek-harness` 根目录打开终端并执行：

**Windows**

```bat
.\plugins\dsh-prompt-rail\install-and-restart.bat
```

**macOS / Linux**

```sh
node ./plugins/dsh-prompt-rail/compat/install.mjs
pnpm dsh web
```

安装后请保留 `plugins/dsh-prompt-rail` 目录。
## 开发

开发时目录应为同级 checkout：

```text
workspace/
├─ dsh/                       # DeepSeek Harness checkout
└─ dsh-prompt-rail/
```

然后执行：

```sh
pnpm install
pnpm run check
```

`lib/` 会提交到仓库，因为 profile 安装时不会运行构建脚本，而是直接加载预构建的 Host 与浏览器文件。

## 发布检查清单

1. 为每一个要支持但未声明 slot 的 Harness 提交添加精确兼容补丁。
2. 执行 `pnpm run check`，并在干净的匹配 checkout 中运行 `node compat/install.mjs --apply-only`。
3. 提交源码、`lib/`、`compat/`、README、截图和 lockfile。
4. 推送 `v0.1.0` 标签，并以该标签创建 GitHub Release。
5. 在 Release 说明中写明兼容的 Harness 版本和提交哈希。

## 许可证

MIT
