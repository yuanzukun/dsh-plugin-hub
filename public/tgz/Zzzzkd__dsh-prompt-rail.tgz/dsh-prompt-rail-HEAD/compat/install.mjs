/**
 * Install DSH Prompt Rail into a DeepSeek Harness source checkout.
 *
 * Older Harness revisions receive the small navigator-slot patch before the
 * ordinary profile bundle installation. The patch map is intentionally exact:
 * an unknown revision fails before any source file changes.
 */
import { existsSync, readFileSync, realpathSync } from 'node:fs'
import { resolve, join } from 'node:path'
import { fileURLToPath } from 'node:url'
import { execFileSync, execSync } from 'node:child_process'

const PACKAGE_NAME = 'dsh-prompt-rail'
const SLOT = 'conversation.chat.navigator'
const pluginRoot = realpathSync(resolve(fileURLToPath(new URL('..', import.meta.url))))
const patches = new Map([
  ['fe2dc3101960bcb17ce4c6f7204b68a70200ed3d', 'patches/harness-fe2dc3101960.patch'],
])

/** Print the command line without losing argument boundaries. */
function display(command, args) {
  return [command, ...args].map(value => JSON.stringify(value)).join(' ')
}

/** Run a checked external command in the Harness checkout. */
function run(command, args, cwd, env = process.env) {
  console.log(`> ${display(command, args)}`)
  execFileSync(command, args, { cwd, env, stdio: 'inherit' })
}

/** Return one command's trimmed UTF-8 output. */
function output(command, args, cwd) {
  return execFileSync(command, args, { cwd, encoding: 'utf8' }).trim()
}

/** Stop with one clear command-line error. */
function fail(message) {
  throw new Error(`${PACKAGE_NAME}: ${message}`)
}

/** Quote one argument for cmd.exe without turning it into a command fragment. */
function quoteForCmd(value) {
  if (value === '--') return value
  return `"${value.replace(/"/g, '""')}"`
}

/** Invoke pnpm through cmd.exe on Windows because a .cmd shim is not executable by execFileSync. */
function runPnpm(args, cwd) {
  const env = { ...process.env, CI: process.env.CI ?? 'true' }
  if (process.platform !== 'win32') {
    run('pnpm', args, cwd, env)
    return
  }
  const command = `pnpm ${args.map(quoteForCmd).join(' ')}`
  console.log(`> ${command}`)
  execSync(command, { cwd, env, shell: process.env.ComSpec ?? 'cmd.exe', stdio: 'inherit' })
}

/** Parse the few installer options without adding a runtime dependency. */
function parseArgs(argv) {
  const options = { harnessRoot: process.cwd(), profile: 'web', applyOnly: false }
  for (let index = 0; index < argv.length; index += 1) {
    const arg = argv[index]
    if (arg === '--harness-root') {
      const value = argv[++index]
      if (value === undefined) fail('--harness-root needs a directory')
      options.harnessRoot = value
    } else if (arg === '--profile') {
      const value = argv[++index]
      if (value === undefined || !/^[A-Za-z0-9_-]+$/.test(value)) fail('--profile needs letters, digits, hyphens, or underscores')
      options.profile = value
    } else if (arg === '--apply-only') {
      options.applyOnly = true
    } else if (arg === '--help' || arg === '-h') {
      console.log(`Usage: node compat/install.mjs [options]\n\nOptions:\n  --harness-root <path>  DeepSeek Harness checkout (default: current directory)\n  --profile <name>       Profile that receives ${PACKAGE_NAME} (default: web)\n  --apply-only           Apply only the compatibility patch; do not install or build\n  -h, --help             Show this help`)
      process.exit(0)
    } else {
      fail(`unknown option ${JSON.stringify(arg)}`)
    }
  }
  return options
}

/** Confirm that this directory is exactly the root of a Harness checkout. */
function resolveHarnessRoot(candidate) {
  const root = realpathSync(resolve(candidate))
  if (!existsSync(join(root, 'package.json')) || !existsSync(join(root, 'packages', 'client', 'ui-conversation'))) {
    fail(`${JSON.stringify(root)} is not a DeepSeek Harness source checkout`)
  }
  const gitRoot = realpathSync(output('git', ['rev-parse', '--show-toplevel'], root))
  if (gitRoot !== root) fail(`${JSON.stringify(root)} is not the Git checkout root`)
  return root
}

/** True when the selected source version already exposes the required UI slot. */
function hasNavigatorSlot(harnessRoot) {
  const slotsFile = join(harnessRoot, 'packages', 'client', 'ui-conversation', 'src', 'client', 'contract', 'slots.ts')
  return readFileSync(slotsFile, 'utf8').includes(`'${SLOT}'`)
}

/** Apply the exact source patch for a known clean pre-slot Harness revision. */
function applyCompatibilityPatch(harnessRoot) {
  if (hasNavigatorSlot(harnessRoot)) {
    console.log(`✓ ${SLOT} already exists; no compatibility patch is needed.`)
    return false
  }
  if (output('git', ['status', '--porcelain'], harnessRoot) !== '') {
    fail('the Harness checkout has uncommitted changes; commit or stash them before applying the compatibility patch')
  }
  const revision = output('git', ['rev-parse', 'HEAD'], harnessRoot)
  const relativePatch = patches.get(revision)
  if (relativePatch === undefined) {
    fail(`Harness revision ${revision} has no supported compatibility patch. Update DSH Prompt Rail or use a Harness build that already declares ${SLOT}.`)
  }
  const patchFile = join(pluginRoot, 'compat', relativePatch)
  run('git', ['apply', '--check', '--whitespace=nowarn', patchFile], harnessRoot)
  run('git', ['apply', '--whitespace=nowarn', patchFile], harnessRoot)
  console.log(`✓ Applied ${relativePatch}.`)
  return true
}

const options = parseArgs(process.argv.slice(2))
const harnessRoot = resolveHarnessRoot(options.harnessRoot)
const patched = applyCompatibilityPatch(harnessRoot)

if (options.applyOnly) {
  console.log(patched ? 'Compatibility patch applied. Run the installer again without --apply-only to build and install the plugin.' : 'No patch was needed.')
  process.exit(0)
}

runPnpm(['install'], harnessRoot)
runPnpm(['run', 'gen-client-catalog'], harnessRoot)
runPnpm(['run', 'build'], harnessRoot)
runPnpm(['dsh', 'plugin', 'add', '--profile', options.profile, pluginRoot], harnessRoot)
console.log(`\n✓ DSH Prompt Rail is installed in the ${JSON.stringify(options.profile)} profile.`)
console.log('A running dsh web server does not reload its profile plugin list. Stop it first, then start:')
console.log('  pnpm dsh web')
console.log('Finally, hard-refresh the browser (Ctrl+F5).')
