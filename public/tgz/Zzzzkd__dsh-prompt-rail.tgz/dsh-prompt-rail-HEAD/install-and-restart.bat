@echo off
setlocal EnableExtensions DisableDelayedExpansion

rem DSH Prompt Rail: install, stop the old dsh web server, then restart it.
rem Run from a DeepSeek Harness source checkout:
rem   .\plugins\dsh-prompt-rail\install-and-restart.bat
rem Optional arguments: [Harness root] [profile name]

set "SCRIPT_DIR=%~dp0"
set "HARNESS_ROOT=%CD%"
set "PROFILE=web"

if not "%~1"=="" set "HARNESS_ROOT=%~f1"
if not "%~2"=="" set "PROFILE=%~2"

if not exist "%HARNESS_ROOT%\package.json" goto :not_harness
if not exist "%HARNESS_ROOT%\packages\client\ui-conversation" goto :not_harness
if not exist "%SCRIPT_DIR%compat\install.mjs" goto :missing_installer

where node >nul 2>nul
if errorlevel 1 goto :missing_node

rem Stop only a dsh web Node process. Do not take over port 3080 from another app.
powershell.exe -NoProfile -Command "$listeners = @(Get-NetTCPConnection -LocalPort 3080 -State Listen -ErrorAction SilentlyContinue); foreach ($listener in $listeners) { $process = Get-CimInstance Win32_Process -Filter ('ProcessId = ' + $listener.OwningProcess); if ($process.Name -ne 'node.exe' -or $process.CommandLine -notmatch 'apps[/\\]cli[/\\]src[/\\]bin\.ts.*web') { Write-Error ('Port 3080 is in use by ' + $process.Name + ' (PID ' + $listener.OwningProcess + '). Refusing to stop a process that is not dsh web.'); exit 2 }; Stop-Process -Id $listener.OwningProcess -Force }; exit 0"
if errorlevel 1 goto :stop_failed

pushd "%HARNESS_ROOT%"
node "%SCRIPT_DIR%compat\install.mjs" --harness-root "%HARNESS_ROOT%" --profile "%PROFILE%"
if errorlevel 1 goto :install_failed

start "DeepSeek Harness Server" /min "%ComSpec%" /d /s /c "pnpm dsh web"
popd

powershell.exe -NoProfile -Command "$deadline = [DateTime]::UtcNow.AddSeconds(30); do { if (Get-NetTCPConnection -LocalPort 3080 -State Listen -ErrorAction SilentlyContinue) { exit 0 }; Start-Sleep -Milliseconds 500 } while ([DateTime]::UtcNow -lt $deadline); exit 1"
if errorlevel 1 goto :start_failed

start "" "http://127.0.0.1:3080/"
echo.
echo [OK] DSH Prompt Rail is installed and dsh web has restarted.
echo If an existing browser tab was open, press Ctrl+F5 once.
exit /b 0

:not_harness
echo [ERROR] "%HARNESS_ROOT%" is not a DeepSeek Harness source checkout.
echo Run this script from the Harness root, or pass that root as the first argument.
exit /b 1

:missing_installer
echo [ERROR] The Prompt Rail installer was not found next to this batch file.
exit /b 1

:missing_node
echo [ERROR] Node.js was not found on PATH.
exit /b 1

:stop_failed
echo [ERROR] Could not safely stop the process on port 3080.
echo Close the existing server manually, then run this script again.
exit /b 1

:install_failed
popd
echo [ERROR] Prompt Rail was not installed. The web server was not restarted.
exit /b 1

:start_failed
echo [ERROR] dsh web did not start on http://127.0.0.1:3080 within 30 seconds.
echo Check the minimized "DeepSeek Harness Server" window for its error output.
exit /b 1
