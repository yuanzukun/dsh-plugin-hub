// @vitest-environment jsdom
import { afterEach, describe, expect, it, vi } from 'vitest'
import { cleanup, fireEvent, render } from '@testing-library/react'
import type { ChatNavigationKey, ChatNavigatorItem } from '@deepseek-ai/dsh-client-ui-conversation/client'
import { makeTranslate } from '@deepseek-ai/dsh-client-test-runtime'
import { MessageJumpRail, type MessageJumpRailProps } from '../src/client/MessageJumpRail.tsx'
import { apply } from '../src/client/index.ts'
import { NS, en, zh } from '../src/client/locales.ts'
import { STYLE_ID, adoptStyles } from '../src/client/styles.ts'

afterEach(() => { cleanup(); document.getElementById(STYLE_ID)?.remove() })

const item = (key: string, summary: string): ChatNavigatorItem => ({
  key: key as ChatNavigationKey, summary,
})

function props(items: readonly ChatNavigatorItem[], jumpTo = vi.fn()): MessageJumpRailProps {
  return {
    items,
    jumpTo,
    sessionId: 's1' as never,
    useSession: (() => undefined) as never,
    useSessions: (() => undefined) as never,
    t: ((key: string, values?: Record<string, string>) => {
      const template = zh[key as keyof typeof zh] ?? en[key as keyof typeof en] ?? key
      return values === undefined ? template : template.replace('{summary}', values.summary ?? '')
    }) as never,
  } as MessageJumpRailProps
}

describe('MessageJumpRail', () => {
  it('uses a larger hit slot, previews the closest message, and tapers nearby marks', () => {
    const jumpTo = vi.fn()
    const view = render(<MessageJumpRail {...props([
      item('1', 'first'), item('2', 'second'), item('3', 'third'), item('4', 'fourth'),
    ], jumpTo)} />)
    const nav = view.getByLabelText('消息跳转')
    const buttons = view.getAllByRole('button')
    expect(buttons).toHaveLength(4)

    fireEvent.pointerEnter(buttons[1]!)
    expect(buttons.map(button => button.getAttribute('data-distance'))).toEqual(['1', '0', '1', '2'])
    expect(buttons[1]?.getAttribute('data-preview-active')).toBe('true')

    fireEvent.click(buttons[1]!)
    fireEvent.pointerLeave(nav)
    expect(jumpTo).toHaveBeenCalledWith('2')
    expect(buttons[1]?.getAttribute('aria-current')).toBe('true')
    expect(buttons[1]?.getAttribute('data-selected')).toBe('true')
    expect(buttons.map(button => button.getAttribute('data-distance'))).toEqual([null, null, null, null])
    expect(buttons[1]?.getAttribute('data-preview-active')).toBeNull()
  })

  it('renders nothing for an empty loaded window', () => {
    const view = render(<MessageJumpRail {...props([])} />)
    expect(view.container.childElementCount).toBe(0)
  })

  it('registers its localized navigator entry through the public slot', () => {
    const localeRegister = vi.fn(() => () => {})
    const slotsRegister = vi.fn(() => () => {})
    const slotsInject = vi.fn((_name: string, register: () => unknown) => register())
    const effect = vi.fn((run: () => unknown) => run())

    apply({
      effect,
      locale: { register: localeRegister },
      slots: { inject: slotsInject, register: slotsRegister },
    } as never)

    expect(effect).toHaveBeenCalledTimes(1)
    expect(localeRegister).toHaveBeenCalledWith(NS, { zh, en })
    expect(slotsInject).toHaveBeenCalledWith('conversation.chat.navigator', expect.any(Function))
    expect(slotsRegister).toHaveBeenCalledWith(expect.objectContaining({
      name: 'conversation.chat.navigator',
      id: 'message-jump-rail',
      order: 0,
      locale: NS,
    }), MessageJumpRail)
  })
  it('installs its stylesheet once', () => {
    adoptStyles()
    adoptStyles()
    const style = document.getElementById(STYLE_ID)
    expect(style).not.toBeNull()
    expect(style?.textContent).toContain('flex: 0 0 10px')
    expect(document.querySelectorAll(`#${STYLE_ID}`)).toHaveLength(1)
  })
})
