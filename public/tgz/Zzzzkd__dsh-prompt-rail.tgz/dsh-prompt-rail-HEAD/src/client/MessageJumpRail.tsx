/** Compact vertical navigator for the loaded user-message rows in one chat view. */
import { useState } from 'react'
import type { PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots'
import type { ChatNavigationKey, ChatNavigatorOwnerProps } from '@deepseek-ai/dsh-client-ui-conversation/client'

/** Full props delivered by the conversation navigator slot. */
export type MessageJumpRailProps = PropsRuntime<'conversation.chat.navigator'>
  & ChatNavigatorOwnerProps & PropsLocale<'message-jump-rail'>

/**
 * Render the message rail. Hover/focus controls the temporary tapered state;
 * the last activated message remains selected after that temporary state ends.
 * @param props - Navigator owner currency and plugin locale seat.
 * @returns the rail, or null when the loaded window has no user messages.
 */
export function MessageJumpRail({ items, jumpTo, t }: MessageJumpRailProps) {
  const [activeKey, setActiveKey] = useState<ChatNavigationKey | null>(null)
  const [selectedKey, setSelectedKey] = useState<ChatNavigationKey | null>(null)
  if (items.length === 0) return null
  const activeIndex = activeKey === null ? -1 : items.findIndex(item => item.key === activeKey)

  return (
    <nav
      className="dsh_messageJumpRail_nav"
      aria-label={t('navigator.aria')}
      onPointerLeave={() => { setActiveKey(null) }}
    >
      <div className="dsh_messageJumpRail_items">
        {items.map(({ key, summary }, index) => {
          const distance = activeIndex < 0 ? undefined : Math.min(3, Math.abs(index - activeIndex))
          return (
            <button
              key={key}
              type="button"
              className="dsh_messageJumpRail_item"
              data-distance={distance}
              data-preview-active={activeKey === key || undefined}
              data-selected={selectedKey === key || undefined}
              aria-label={t('navigator.item', { summary })}
              aria-current={selectedKey === key || undefined}
              onPointerEnter={() => { setActiveKey(key) }}
              onFocus={() => { setActiveKey(key) }}
              onBlur={() => { setActiveKey(null) }}
              onClick={() => { setSelectedKey(key); jumpTo(key) }}
            >
              <span className="dsh_messageJumpRail_mark" aria-hidden />
              <span className="dsh_messageJumpRail_preview" data-message-preview={summary} aria-hidden />
            </button>
          )
        })}
      </div>
    </nav>
  )
}
