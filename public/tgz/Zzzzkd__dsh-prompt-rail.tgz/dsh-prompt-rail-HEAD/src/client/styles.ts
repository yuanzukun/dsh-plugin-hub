/**
 * One injected stylesheet: web client plugins are served as a single bundle.
 * Class names use the plugin prefix to avoid collisions in the assembled app.
 */

/** Stable style id; idempotent across HMR re-runs. */
export const STYLE_ID = 'dsh-prompt-rail-style'

/** Visual treatment for the compact, enlarged-hit-area message rail. */
export const cssText = `
.dsh_messageJumpRail_nav {
  position: sticky;
  z-index: 9;
  top: 50%;
  left: 8px;
  width: 56px;
  height: 0;
  display: flex;
  flex-direction: column;
  gap: 0;
  align-items: flex-start;
  pointer-events: none;
}
.dsh_messageJumpRail_items {
  display: flex;
  flex-direction: column;
  width: 100%;
  transform: translateY(-50%);
  pointer-events: none;
}
.dsh_messageJumpRail_item {
  position: relative;
  display: flex;
  align-items: center;
  justify-content: flex-start;
  width: 56px;
  height: 10px;
  flex: 0 0 10px;
  padding: 0;
  border: 0;
  background: transparent;
  cursor: pointer;
  pointer-events: auto;
}
.dsh_messageJumpRail_mark {
  display: block;
  width: 8px;
  height: 3px;
  border-radius: 1px;
  background: var(--dsw-alias-label-caption);
  transition: width 120ms ease, background-color 120ms ease;
}
.dsh_messageJumpRail_preview {
  position: absolute;
  top: 50%;
  left: 36px;
  z-index: 1;
  width: min(300px, calc(100vw - 96px));
  max-height: 72px;
  overflow: hidden;
  padding: 12px 14px;
  border: 1px solid var(--dsw-alias-border-l1);
  border-radius: 12px;
  color: var(--dsw-alias-label-primary);
  font-size: 13px;
  line-height: 20px;
  text-align: left;
  background: var(--dsw-specific-tip);
  box-shadow: var(--dsw-shadow-lv1);
  opacity: 0;
  pointer-events: none;
  transform: translate(-4px, -50%);
  transition: opacity 120ms ease, transform 120ms ease;
}
.dsh_messageJumpRail_preview::after { content: attr(data-message-preview); }
.dsh_messageJumpRail_item[data-distance='0'] .dsh_messageJumpRail_mark { width: 28px; }
.dsh_messageJumpRail_item[data-distance='1'] .dsh_messageJumpRail_mark { width: 20px; }
.dsh_messageJumpRail_item[data-distance='2'] .dsh_messageJumpRail_mark { width: 14px; }
.dsh_messageJumpRail_item[data-distance='3'] .dsh_messageJumpRail_mark { width: 10px; }
.dsh_messageJumpRail_item[data-distance='0'] .dsh_messageJumpRail_mark,
.dsh_messageJumpRail_item[data-selected] .dsh_messageJumpRail_mark {
  background: var(--dsw-alias-label-primary);
}
.dsh_messageJumpRail_item[data-preview-active] .dsh_messageJumpRail_preview {
  opacity: 1;
  transform: translate(0, -50%);
}
.dsh_messageJumpRail_item:focus-visible { outline: none; }
@media (max-width: 980px) {
  .dsh_messageJumpRail_preview { left: 28px; }
}
@media (prefers-reduced-motion: reduce) {
  .dsh_messageJumpRail_mark,
  .dsh_messageJumpRail_preview { transition: none; }
}
`

/** Inject the stylesheet once. */
export function adoptStyles(): void {
  if (document.getElementById(STYLE_ID) !== null) return
  const style = document.createElement('style')
  style.id = STYLE_ID
  style.textContent = cssText
  document.head.appendChild(style)
}
