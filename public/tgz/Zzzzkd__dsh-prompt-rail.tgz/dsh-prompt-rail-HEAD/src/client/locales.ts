/** Product copy for the message-jump rail. */

/** Simplified Chinese dictionary (the key-set source of truth). */
export const zh = {
  'navigator.aria': '消息跳转',
  'navigator.item': '跳转到消息：{summary}',
}

/** English dictionary mirroring the Chinese key set. */
export const en: typeof zh = {
  'navigator.aria': 'Message navigation',
  'navigator.item': 'Jump to message: {summary}',
}

/** Plugin locale namespace. */
export const NS = 'message-jump-rail'
declare module '@deepseek-ai/dsh-client-ui-slots' {
  interface LocaleNamespaceMap {
    /** This plugin's message navigation copy. */
    [NS]: keyof typeof zh
  }
}