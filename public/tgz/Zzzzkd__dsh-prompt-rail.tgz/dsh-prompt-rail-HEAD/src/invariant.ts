/** Invariant companion for the browser-only message-jump rail package. */
import type { Context } from '@deepseek-ai/cordis'
import type { InvariantInstaller } from '@deepseek-ai/dsh-invariants'

const PACKAGE_NAME = 'dsh-prompt-rail'

/** Cordis companion-plugin name. */
export const name = 'dsh-prompt-rail-invariant'
/** The invariant registry owns package registration. */
export const inject = ['invariants']

/**
 * No runtime invariant: the plugin owns only local browser presentation state.
 * The conversation view owns the loaded-row relation and scroll operation that
 * it publishes through its navigator slot.
 */
const install: InvariantInstaller = () => {}

/**
 * Register the package's invariant companion.
 * @param ctx - Context carrying the invariant registry.
 * @returns the registration disposer.
 */
export const apply = (ctx: Context): Promise<() => void> =>
  Promise.resolve(ctx.invariants.register(PACKAGE_NAME, install))
