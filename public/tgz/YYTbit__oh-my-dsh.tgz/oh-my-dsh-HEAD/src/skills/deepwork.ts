/**
 * Deepwork skill: focused, uninterrupted work session.
 * @module oh-my-dsh/skills/deepwork
 */

export const SKILL_CONTENT = `---
name: deepwork
description: >-
  Deep focus work mode. Minimizes context switching, maintains a working
  memory of decisions and progress, and produces a comprehensive summary
  at the end. Use for complex, multi-file changes.
argument-hint: "<what to work on>"
---

# Deepwork

A focused work session for complex tasks.

## Process

1. **Load Context**: Read all relevant files upfront
2. **Build Mental Model**: Understand the full picture before making changes
3. **Execute Systematically**: Make changes in logical order
4. **Track Decisions**: Record every decision and its rationale
5. **Verify End-to-End**: Test the complete flow, not just individual changes

## Working Memory

Maintain a running summary:

\\\`\\\`\\\`
## Current State
- What's been done
- What's in progress
- What's next

## Decisions Made
- Decision 1: rationale
- Decision 2: rationale

## Key Files
- file.ts:42 - what's there
- config.yaml - relevant setting
\\\`\\\`\\\`

## Rules

- Read before writing
- One logical change at a time
- Test after each significant change
- Update working memory after each step
- Don't lose context - if session is long, summarize periodically
`
