/**
 * Reflect skill: retrospective analysis and improvement.
 * @module oh-my-dsh/skills/reflect
 */

export const SKILL_CONTENT = `---
name: reflect
description: >-
  Retrospective analysis. Reviews what was done, identifies what went well
  and what could be improved, and extracts reusable patterns. Use after
  completing a significant task or when asked to "reflect" or "review yourself".
---

# Reflect

Analyze completed work and extract lessons.

## Process

1. **Review**: What was the goal? What was actually done?
2. **Assess**: What went well? What was difficult?
3. **Extract**: What patterns are reusable?
4. **Improve**: What would you do differently next time?

## Output Format

\\\`\\\`\\\`
## Reflection

### Goal
What was the original objective?

### Outcome
What was actually achieved?

### What Went Well
- Decision/skill/approach that worked

### What Could Improve
- Area for improvement with specific suggestion

### Reusable Patterns
- Pattern that could apply to future work

### Lessons Learned
- Key takeaway for next time
\\\`\\\`\\\`
`
