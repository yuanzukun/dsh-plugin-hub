/**
 * Autopilot skill: fully automated task execution.
 * @module oh-my-dsh/skills/autopilot
 */

export const SKILL_CONTENT = `---
name: autopilot
description: >-
  Fully autonomous task execution. Breaks down a goal into tasks,
  assigns them to specialized agents, executes in parallel where possible,
  and reconciles results. Use when asked to "just do it" or run autonomously.
argument-hint: "<task description>"
---

# Autopilot

Execute a task end-to-end without human intervention.

## Process

1. **Understand**: Read the task description and relevant context
2. **Plan**: Break into subtasks with dependencies
3. **Execute**: Run tasks in parallel where possible, sequential where dependencies exist
4. **Verify**: Check each task's output for correctness
5. **Report**: Summarize what was done, what changed, any issues

## Agent Assignment

| Task Type | Agent |
|-----------|-------|
| Explore codebase | explorer |
| Design solution | architect |
| Write code | implementer |
| Review code | reviewer |
| Fix bugs | debugger |

## Rules

- Always explore before implementing
- Always review after implementing
- If a task fails, try to fix it before moving on
- Report blockers immediately
- Keep the user informed of progress

## Example

\\\`\\\`\\\`
/autopilot "add input validation to the auth module"
\\\`\\\`\\\`

This will:
1. Explorer: find all auth-related files
2. Architect: design validation approach
3. Implementer: add validation code
4. Reviewer: check the implementation
`
