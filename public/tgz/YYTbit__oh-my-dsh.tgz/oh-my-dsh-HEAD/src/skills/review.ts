/**
 * Review skill: systematic code review.
 * @module oh-my-dsh/skills/review
 */

export const SKILL_CONTENT = `---
name: review
description: >-
  Systematic code review. Checks correctness, security, performance,
  style, and test coverage. Outputs structured findings with severity.
argument-hint: "<file or description of what to review>"
---

# Review

Structured code review process.

## Checklist

### Correctness
- Logic errors, off-by-one, null handling
- Edge cases not covered
- Race conditions, concurrency issues
- Error handling completeness

### Security
- Input validation
- Authentication/authorization
- Secrets in code
- Injection vulnerabilities

### Performance
- Unnecessary loops, repeated computations
- Missing caching
- N+1 queries
- Blocking operations

### Style
- Naming conventions
- Function complexity
- Dead code
- Missing documentation

### Testing
- Coverage adequacy
- Edge case testing
- Test quality

## Output Format

\\\`\\\`\\\`
[SEVERITY] file:line - description

Severity: CRITICAL | WARNING | SUGGESTION | NIT
\\\`\\\`\\\`
`
