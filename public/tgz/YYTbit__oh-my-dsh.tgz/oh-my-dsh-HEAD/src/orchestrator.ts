/**
 * Task orchestrator: decomposes goals into tasks, dispatches to agents,
 * tracks progress, and reconciles results.
 * @module oh-my-dsh/orchestrator
 */

import type { Plan, Task, TaskStatus } from './types.js'

/** Generate a short random id. */
function taskId(): string {
  return Math.random().toString(36).slice(2, 8)
}

/** Create a new plan from a goal description. */
export function createPlan(goal: string): Plan {
  return {
    goal,
    tasks: [],
    phase: 'planning',
  }
}

/** Add a task to a plan. */
export function addTask(
  plan: Plan,
  description: string,
  agent: string,
  dependsOn: string[] = [],
): Task {
  const task: Task = {
    id: taskId(),
    description,
    agent,
    status: 'pending',
    dependsOn,
  }
  plan.tasks.push(task)
  return task
}

/** Get tasks that are ready to run (all dependencies done). */
export function getReadyTasks(plan: Plan): Task[] {
  return plan.tasks.filter(t => {
    if (t.status !== 'pending') return false
    return t.dependsOn.every(depId => {
      const dep = plan.tasks.find(t2 => t2.id === depId)
      return dep?.status === 'done'
    })
  })
}

/** Get running tasks. */
export function getRunningTasks(plan: Plan): Task[] {
  return plan.tasks.filter(t => t.status === 'running')
}

/** Mark a task as running. */
export function startTask(plan: Plan, taskId: string): void {
  const task = plan.tasks.find(t => t.id === taskId)
  if (task) {
    task.status = 'running'
    task.startedAt = Date.now()
  }
}

/** Mark a task as done with result. */
export function completeTask(plan: Plan, taskId: string, result: string): void {
  const task = plan.tasks.find(t => t.id === taskId)
  if (task) {
    task.status = 'done'
    task.result = result
    task.endedAt = Date.now()
  }
}

/** Mark a task as failed. */
export function failTask(plan: Plan, taskId: string, error: string): void {
  const task = plan.tasks.find(t => t.id === taskId)
  if (task) {
    task.status = 'failed'
    task.error = error
    task.endedAt = Date.now()
  }
}

/** Check if plan is complete. */
export function isPlanComplete(plan: Plan): boolean {
  return plan.tasks.every(t => t.status === 'done' || t.status === 'failed')
}

/** Get plan progress summary. */
export function getProgress(plan: Plan): string {
  const total = plan.tasks.length
  const done = plan.tasks.filter(t => t.status === 'done').length
  const failed = plan.tasks.filter(t => t.status === 'failed').length
  const running = plan.tasks.filter(t => t.status === 'running').length
  const pending = plan.tasks.filter(t => t.status === 'pending').length

  const lines = [
    `## Plan: ${plan.goal}`,
    `Progress: ${done}/${total} done${failed > 0 ? `, ${failed} failed` : ''}`,
    '',
  ]

  for (const task of plan.tasks) {
    const icon = statusIcon(task.status)
    const duration = task.startedAt && task.endedAt
      ? ` (${Math.round((task.endedAt - task.startedAt) / 1000)}s)`
      : ''
    lines.push(`${icon} [${task.agent}] ${task.description}${duration}`)
    if (task.error) lines.push(`  Error: ${task.error}`)
  }

  return lines.join('\n')
}

function statusIcon(status: TaskStatus): string {
  switch (status) {
    case 'done': return '[x]'
    case 'running': return '[~]'
    case 'failed': return '[!]'
    case 'blocked': return '[-]'
    default: return '[ ]'
  }
}
