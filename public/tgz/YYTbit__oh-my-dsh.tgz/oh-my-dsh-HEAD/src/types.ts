/**
 * oh-my-dsh types.
 * @module oh-my-dsh/types
 */

/** Agent role definition. */
export interface AgentRole {
  /** Unique agent name. */
  name: string
  /** Agent description shown to orchestrator. */
  description: string
  /** System prompt additions for this agent. */
  systemPrompt: string
  /** Skills this agent can use. */
  skills: string[]
  /** Model override for this agent. */
  model?: string
}

/** Task status. */
export type TaskStatus = 'pending' | 'running' | 'done' | 'failed' | 'blocked'

/** A task dispatched by the orchestrator. */
export interface Task {
  /** Task id. */
  id: string
  /** Task description. */
  description: string
  /** Assigned agent. */
  agent: string
  /** Current status. */
  status: TaskStatus
  /** Dependencies (task ids that must complete first). */
  dependsOn: string[]
  /** Result text (when done). */
  result?: string
  /** Error text (when failed). */
  error?: string
  /** Start time. */
  startedAt?: number
  /** End time. */
  endedAt?: number
}

/** Orchestrator plan. */
export interface Plan {
  /** Goal description. */
  goal: string
  /** Ordered task list. */
  tasks: Task[]
  /** Current execution phase. */
  phase: 'planning' | 'executing' | 'reviewing' | 'done'
}

/** Preset configuration. */
export interface Preset {
  /** Preset name. */
  name: string
  /** Description. */
  description: string
  /** Agent overrides. */
  agents: Partial<Record<string, { model?: string }>>
}

/** Plugin configuration. */
export interface Config {
  /** Enable autopilot skill. Default: true. */
  enableAutopilot?: boolean
  /** Enable deepwork skill. Default: true. */
  enableDeepwork?: boolean
  /** Enable review skill. Default: true. */
  enableReview?: boolean
  /** Enable reflect skill. Default: true. */
  enableReflect?: boolean
  /** Default model for agents. */
  defaultModel?: string
  /** Max parallel tasks. Default: 3. */
  maxParallel?: number
}
