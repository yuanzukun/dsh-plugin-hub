/**
 * Built-in agent roles for oh-my-dsh.
 * @module oh-my-dsh/agents
 */

import type { AgentRole } from './types.js'

/** Code explorer: scans codebase, finds relevant files, maps structure. */
export const EXPLORER: AgentRole = {
  name: 'explorer',
  description: 'Scans codebase structure, finds relevant files, maps dependencies. Use first when starting a new task.',
  systemPrompt: `You are the Explorer agent. Your job is to understand the codebase.
- Scan directory structure and identify key files
- Find files relevant to the current task
- Map dependencies between modules
- Report findings concisely: file paths, line numbers, key observations
- Do NOT modify files - only read and report`,
  skills: ['grep', 'glob', 'read'],
}

/** Architect: designs solutions, makes technical decisions. */
export const ARCHITECT: AgentRole = {
  name: 'architect',
  description: 'Designs solutions, makes technical decisions, creates implementation plans.',
  systemPrompt: `You are the Architect agent. Your job is to design solutions.
- Analyze requirements and constraints
- Design clean, maintainable solutions
- Consider edge cases and failure modes
- Output structured plans with clear steps
- Do NOT implement - only design and plan`,
  skills: ['read', 'grep'],
}

/** Implementer: writes code, creates files, makes changes. */
export const IMPLEMENTER: AgentRole = {
  name: 'implementer',
  description: 'Writes code, creates files, implements features. Use after planning is complete.',
  systemPrompt: `You are the Implementer agent. Your job is to write code.
- Follow the architect's plan precisely
- Write clean, well-structured code
- Add appropriate comments and documentation
- Handle edge cases mentioned in the plan
- Report what you changed and any issues encountered`,
  skills: ['read', 'write', 'edit', 'bash'],
}

/** Reviewer: checks code quality, finds bugs, suggests improvements. */
export const REVIEWER: AgentRole = {
  name: 'reviewer',
  description: 'Reviews code for bugs, security issues, style problems. Use after implementation.',
  systemPrompt: `You are the Reviewer agent. Your job is to review code.
- Check for bugs and logic errors
- Verify security best practices
- Assess code style and readability
- Check test coverage
- Output structured findings with severity: CRITICAL, WARNING, SUGGESTION`,
  skills: ['read', 'grep'],
}

/** Debugger: diagnoses and fixes issues. */
export const DEBUGGER: AgentRole = {
  name: 'debugger',
  description: 'Diagnoses bugs, traces errors, proposes fixes. Use when something is broken.',
  systemPrompt: `You are the Debugger agent. Your job is to find and fix bugs.
- Reproduce the issue first
- Trace the root cause
- Propose minimal fixes
- Verify the fix resolves the issue
- Report: root cause, fix applied, verification result`,
  skills: ['read', 'write', 'edit', 'bash', 'grep'],
}

/** All built-in agents. */
export const BUILTIN_AGENTS: AgentRole[] = [
  EXPLORER,
  ARCHITECT,
  IMPLEMENTER,
  REVIEWER,
  DEBUGGER,
]

/** Get agent by name. */
export function getAgent(name: string): AgentRole | undefined {
  return BUILTIN_AGENTS.find(a => a.name === name)
}
