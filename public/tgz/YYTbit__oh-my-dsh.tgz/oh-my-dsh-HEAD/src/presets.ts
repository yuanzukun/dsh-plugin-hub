/**
 * Preset configurations for oh-my-dsh.
 * @module oh-my-dsh/presets
 */

import type { Preset } from './types.js'

/** Built-in presets. */
export const PRESETS: Preset[] = [
  {
    name: 'balanced',
    description: 'Mix of quality and speed. Default configuration.',
    agents: {},
  },
  {
    name: 'quality',
    description: 'Maximum quality. Uses strongest models for all agents.',
    agents: {
      explorer: { model: 'deepseek-v4' },
      architect: { model: 'deepseek-v4' },
      implementer: { model: 'deepseek-v4' },
      reviewer: { model: 'deepseek-v4' },
      debugger: { model: 'deepseek-v4' },
    },
  },
  {
    name: 'speed',
    description: 'Maximum speed. Uses fast models for all agents.',
    agents: {
      explorer: { model: 'deepseek-v4-flash' },
      architect: { model: 'deepseek-v4-flash' },
      implementer: { model: 'deepseek-v4-flash' },
      reviewer: { model: 'deepseek-v4-flash' },
      debugger: { model: 'deepseek-v4-flash' },
    },
  },
  {
    name: 'cost',
    description: 'Minimum cost. Uses cheapest models for all agents.',
    agents: {
      explorer: { model: 'deepseek-v4-flash' },
      architect: { model: 'deepseek-v4-flash' },
      implementer: { model: 'deepseek-v4-flash' },
      reviewer: { model: 'deepseek-v4-flash' },
      debugger: { model: 'deepseek-v4-flash' },
    },
  },
]

/** Get preset by name. */
export function getPreset(name: string): Preset | undefined {
  return PRESETS.find(p => p.name === name)
}
