/**
 * oh-my-dsh: Multi-agent orchestration for DeepSeek Harness.
 *
 * Provides specialized agents, task orchestration, and workflow skills
 * that turn dsh into a multi-agent development environment.
 *
 * @module oh-my-dsh
 */

import type { Config } from './types.js'
import { BUILTIN_AGENTS } from './agents.js'
import { PRESETS } from './presets.js'
import { SKILL_CONTENT as AUTOPilot_SKILL } from './skills/autopilot.js'
import { SKILL_CONTENT as DEEPWORK_SKILL } from './skills/deepwork.js'
import { SKILL_CONTENT as REVIEW_SKILL } from './skills/review.js'
import { SKILL_CONTENT as REFLECT_SKILL } from './skills/reflect.js'

export const name = 'oh-my-dsh'
export const inject = ['systemPrompt']

/** Render agent catalog for system prompt. */
function renderAgentCatalog(): string {
  const lines = [
    '# oh-my-dsh Agents',
    '',
    'Specialized agents available for task delegation:',
    '',
  ]
  for (const agent of BUILTIN_AGENTS) {
    lines.push(`- **${agent.name}**: ${agent.description}`)
  }
  lines.push('')
  lines.push('Delegate tasks to the most appropriate agent based on the work type.')
  return lines.join('\n')
}

/** Render preset catalog. */
function renderPresets(): string {
  const lines = [
    '# Available Presets',
    '',
    'Switch presets with: /preset <name>',
    '',
  ]
  for (const preset of PRESETS) {
    lines.push(`- **${preset.name}**: ${preset.description}`)
  }
  return lines.join('\n')
}

export function apply(ctx: any, config: Config = {}): void {
  const enableAutopilot = config.enableAutopilot !== false
  const enableDeepwork = config.enableDeepwork !== false
  const enableReview = config.enableReview !== false
  const enableReflect = config.enableReflect !== false

  // Inject agent catalog
  ctx.systemPrompt.section({
    name: 'oh-my-dsh:agents',
    order: 170,
    text: renderAgentCatalog(),
  })

  // Inject presets info
  ctx.systemPrompt.section({
    name: 'oh-my-dsh:presets',
    order: 171,
    text: renderPresets(),
  })

  // Register skills as system prompt sections
  if (enableAutopilot) {
    ctx.systemPrompt.section({
      name: 'oh-my-dsh:autopilot',
      order: 172,
      text: AUTOPilot_SKILL,
    })
  }

  if (enableDeepwork) {
    ctx.systemPrompt.section({
      name: 'oh-my-dsh:deepwork',
      order: 173,
      text: DEEPWORK_SKILL,
    })
  }

  if (enableReview) {
    ctx.systemPrompt.section({
      name: 'oh-my-dsh:review',
      order: 174,
      text: REVIEW_SKILL,
    })
  }

  if (enableReflect) {
    ctx.systemPrompt.section({
      name: 'oh-my-dsh:reflect',
      order: 175,
      text: REFLECT_SKILL,
    })
  }

  // Register shell environment
  if (ctx.shellEnv?.register) {
    ctx.shellEnv.register({
      name: 'oh-my-dsh',
      variables: {
        'DSH_OMD_PRESET': { description: 'Current oh-my-dsh preset name' },
      },
      resolve() {
        return { 'DSH_OMD_PRESET': config.defaultModel ?? 'balanced' }
      },
    })
  }
}

export { BUILTIN_AGENTS, getAgent } from './agents.js'
export { PRESETS, getPreset } from './presets.js'
export * as orchestrator from './orchestrator.js'

export default { name, inject, apply }
