# oh-my-dsh

Multi-agent orchestration for DeepSeek Harness.

## What it does

Turns dsh into a multi-agent development environment with:
- **5 specialized agents**: Explorer, Architect, Implementer, Reviewer, Debugger
- **4 workflow skills**: Autopilot, Deepwork, Review, Reflect
- **Preset system**: Switch model configurations at runtime
- **Task orchestration**: Parallel execution with dependency tracking

## Install

```sh
dsh plugin --profile your-profile add oh-my-dsh
```

## Agents

| Agent | Role | Best For |
|-------|------|----------|
| explorer | Scans codebase | Starting new tasks, finding relevant code |
| architect | Designs solutions | Planning, technical decisions |
| implementer | Writes code | Implementation, file changes |
| reviewer | Reviews code | Quality checks, security audits |
| debugger | Fixes bugs | Diagnosing issues, tracing errors |

## Skills

### autopilot
Fully autonomous execution. Breaks down a goal, assigns to agents, executes in parallel.

```sh
/autopilot "add input validation to auth module"
```

### deepwork
Focused work session for complex, multi-file changes.

```sh
/deepwork "refactor the database layer"
```

### review
Systematic code review with structured findings.

```sh
/review src/auth.ts
```

### reflect
Retrospective analysis after completing work.

```sh
/reflect
```

## Presets

Switch model configurations:

| Preset | Description |
|--------|-------------|
| balanced | Mix of quality and speed (default) |
| quality | Strongest models for all agents |
| speed | Fastest models for all agents |
| cost | Cheapest models for all agents |

## Configuration

```yaml
- id: oh-my-dsh
  name: oh-my-dsh
  config:
    enableAutopilot: true
    enableDeepwork: true
    enableReview: true
    enableReflect: true
    defaultModel: deepseek-v4
    maxParallel: 3
```

## License

MIT -- YYTbit
