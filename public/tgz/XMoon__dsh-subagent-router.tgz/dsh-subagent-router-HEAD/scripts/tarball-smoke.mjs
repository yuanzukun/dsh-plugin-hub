#!/usr/bin/env node
/**
 * @xmoon76/dsh-subagent-router/scripts/tarball-smoke — verify a packed
 * `@xmoon76/dsh-subagent-router` tarball end to end, so a fresh checkout
 * can never publish a broken or leaky artifact:
 *
 *   1. structure — every `exports` file exists, cordis.patch.yml is
 *      included, nothing else leaks in (no tests, no backups, no nested
 *      tarballs, no absolute paths);
 *   2. content — no workspace absolute paths anywhere (dynamic repo-root
 *      detection plus generic absolute-path patterns);
 *   3. parse — every `.js` passes `node --check`;
 *   4. install — the tarball installs standalone (`npm install --omit=dev`
 *      in a fresh temp project), both `exports` entries import, and the
 *      plugin surface (name/inject/apply/Config) is present.
 *
 * Usage: node scripts/tarball-smoke.mjs [path-to-tgz]
 * The tarball path defaults to the newest `xmoon76-dsh-subagent-router-*.tgz`
 * in the current directory (npm strips the `@` scope from tarball filenames).
 *
 * Env: TARBALL_SMOKE_SKIP_INSTALL=1 skips the npm install step (offline
 * dev runs); TARBALL_SMOKE_KEEP=1 keeps the temp dirs for inspection.
 * @module tarball-smoke
 */

import { spawnSync } from 'node:child_process'
import {
  existsSync,
  mkdirSync,
  mkdtempSync,
  readFileSync,
  readdirSync,
  realpathSync,
  rmSync,
  statSync,
} from 'node:fs'
import { tmpdir } from 'node:os'
import { basename, dirname, join, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'

const SCRIPT_DIR = dirname(fileURLToPath(import.meta.url))
/** The package root (the checkout). */
const PACKAGE_ROOT = join(SCRIPT_DIR, '..')

const failures = []
const checks = []

/** Record a passing check or a hard failure (failures exit non-zero at the end). */
function check(name, ok, detail = '') {
  checks.push(`${ok ? 'ok  ' : 'FAIL'} ${name}${detail === '' ? '' : ` — ${detail}`}`)
  if (!ok) failures.push(`${name}${detail === '' ? '' : `: ${detail}`}`)
}

/** Run a command; returns the spawn result. */
function run(cmd, args, opts = {}) {
  return spawnSync(cmd, args, { encoding: 'utf8', ...opts })
}

/** Resolve the tarball: explicit arg, else the newest matching tgz in the
 * current directory, its parent, or the package's dist/ (where
 * `npm pack --pack-destination dist` leaves it). */
function resolveTarball(explicit) {
  if (explicit) {
    // Absolutize BEFORE any subprocess uses it: `npm install` below runs
    // with cwd=probeDir, so a relative arg would resolve against the temp
    // dir and fail with ENOENT.
    const absolute = resolve(process.cwd(), explicit)
    if (!existsSync(absolute)) throw new Error(`tarball not found: ${explicit}`)
    return absolute
  }
  const dirs = [process.cwd(), join(process.cwd(), '..'), join(PACKAGE_ROOT, 'dist')]
  const candidates = []
  for (const dir of dirs) {
    if (!existsSync(dir)) continue
    for (const name of readdirSync(dir)) {
      if (/^xmoon76-dsh-subagent-router-.*\.tgz$/.test(name)) {
        candidates.push({ name, dir, mtime: statSync(join(dir, name)).mtimeMs })
      }
    }
  }
  if (candidates.length === 0) {
    throw new Error(`no xmoon76-dsh-subagent-router-*.tgz in ${process.cwd()}, its parent, or dist/; pass the tarball path`)
  }
  candidates.sort((a, b) => b.mtime - a.mtime)
  const { name, dir } = candidates[0]
  console.log(`tarball-smoke: using ${name} from ${dir}`)
  return join(dir, name)
}

/** Extract an npm tarball; returns the `package/` directory. */
function extract(tarball, workDir) {
  const result = run('tar', ['-xzf', tarball, '-C', workDir])
  if (result.status !== 0) throw new Error(`tar extraction failed: ${result.stderr}`)
  const extracted = join(workDir, 'package')
  if (!existsSync(extracted)) throw new Error('tarball has no package/ root (not an npm tarball?)')
  return extracted
}

/** Walk a directory tree; returns relative paths. */
function walkFiles(dir) {
  const out = []
  const walk = (cur) => {
    for (const name of readdirSync(cur)) {
      const full = join(cur, name)
      if (statSync(full).isDirectory()) walk(full)
      else out.push(full)
    }
  }
  walk(dir)
  return out.map((full) => full.slice(dir.length + 1).split('\\').join('/'))
}

function main() {
  const tarball = resolveTarball(process.argv[2])
  const keep = process.env.TARBALL_SMOKE_KEEP === '1'
  const skipInstall = process.env.TARBALL_SMOKE_SKIP_INSTALL === '1'
  const workDir = mkdtempSync(join(tmpdir(), 'tarball-smoke-'))
  const probeDir = join(workDir, 'probe')
  try {
    check('tarball exists', existsSync(tarball), basename(tarball))
    const extracted = extract(tarball, workDir)
    const pkg = JSON.parse(readFileSync(join(extracted, 'package.json'), 'utf8'))
    check('package name', pkg.name === '@xmoon76/dsh-subagent-router', pkg.name)
    check('published package is not private', pkg.private !== true, `private=${String(pkg.private)}`)

    // --- structure ---
    const files = walkFiles(extracted)
    const has = (path) => files.includes(path)
    check('exports entry lib/index.js', has('lib/index.js'))
    check('exports entry lib/invariant.js', has('lib/invariant.js'))
    check('types lib/types/index.d.ts', has('lib/types/index.d.ts'))
    check('types lib/types/invariant.d.ts', has('lib/types/invariant.d.ts'))
    check('cordis.patch.yml included', has('cordis.patch.yml'))
    check('README included', has('README.md'))
    const leaks = files.filter((name) => name.includes('test/')
      || name.includes('tests/')
      || name.includes('coverage/')
      || name.endsWith('.bak')
      || name.endsWith('.tgz')
      || /^\//.test(name)
      || name.includes('..'))
    check('no tests / fixtures / backups / nested tarballs / absolute paths', leaks.length === 0,
      leaks.length === 0 ? '' : leaks.join(', '))

    // --- content ---
    const textFiles = files
      .filter((name) => /\.(js|ts|yml|yaml|json|md)$/.test(name))
      .map((name) => join(extracted, name))
    // Leak detection is DYNAMIC, not tied to this machine: the runtime-
    // resolved repo root (realpath) catches THIS checkout's absolute paths
    // on any machine, and the generic patterns catch the common
    // absolute-path shapes everywhere. The smoke script itself is exempt:
    // its source deliberately assembles markers at runtime (the literal
    // would otherwise trip the check on its own file).
    const repoRoot = realpathSync(PACKAGE_ROOT)
    const absolutePathPatterns = [
      /\/home\/[^/"']+/,
      /\/Users\/[^/"']+/,
      /\/home\/runner\/work\//,
      /[A-Za-z]:\\(?:[^\\"']*\\)+/,
    ]
    const workspaceLeaks = textFiles.filter((file) => {
      const text = readFileSync(file, 'utf8')
      if (repoRoot.length > 1 && text.includes(repoRoot)) return true
      if (basename(file) === 'tarball-smoke.mjs') return false
      return absolutePathPatterns.some((pattern) => pattern.test(text))
    })
    check('no workspace absolute paths in packaged files', workspaceLeaks.length === 0,
      workspaceLeaks.length === 0 ? '' : workspaceLeaks.join(', '))

    // --- parse ---
    const jsFiles = files.filter((name) => /\.js$/.test(name)).map((name) => join(extracted, name))
    const badJs = jsFiles.filter((file) => run(process.execPath, ['--check', file]).status !== 0)
    check('every .js parses (node --check)', badJs.length === 0,
      badJs.length === 0 ? '' : badJs.join(', '))

    // --- install + runtime ---
    if (skipInstall) {
      checks.push('skip npm install (TARBALL_SMOKE_SKIP_INSTALL=1)')
    } else {
      mkdirSync(probeDir, { recursive: true })
      run('npm', ['init', '-y'], { cwd: probeDir })
      const install = run('npm', [
        'install', '--omit=dev', '--no-save', '--no-audit', '--no-fund',
        tarball,
      ], { cwd: probeDir, timeout: 300000 })
      check('tarball installs standalone (npm install --omit=dev)', install.status === 0,
        install.status === 0 ? '' : (install.stderr.split('\n').slice(-3).join(' ')))
      if (install.status === 0) {
        const installed = join(probeDir, 'node_modules', '@xmoon76', 'dsh-subagent-router')
        check('installed package contains lib/index.js', existsSync(join(installed, 'lib', 'index.js')))
        const imports = run(process.execPath, ['-e', `
          Promise.all([
            import('@xmoon76/dsh-subagent-router'),
            import('@xmoon76/dsh-subagent-router/invariant'),
          ]).then(([main, invariant]) => {
            const surface = ['name', 'inject', 'apply'].every(k => k in main)
              && ['name', 'inject', 'apply'].every(k => k in invariant)
              && 'Config' in main
            if (!surface) { console.error('missing plugin surface'); process.exit(2) }
            console.log('main exports:', Object.keys(main).sort().join(','))
            console.log('invariant exports:', Object.keys(invariant).sort().join(','))
          }).catch((e) => { console.error(e.message); process.exit(1) })
        `], { cwd: probeDir, timeout: 60000 })
        check('both exports entries import and expose the plugin surface',
          imports.status === 0, imports.status === 0 ? '' : imports.stderr)
      }
    }

    // --- summary ---
    console.log(checks.join('\n'))
    if (failures.length > 0) {
      console.error(`\ntarball-smoke FAILED (${failures.length}):\n- ${failures.join('\n- ')}`)
      process.exitCode = 1
    } else {
      console.log(`\ntarball-smoke OK (${checks.length} checks)`)
    }
  } finally {
    if (!keep) rmSync(workDir, { recursive: true, force: true })
  }
}

main()
