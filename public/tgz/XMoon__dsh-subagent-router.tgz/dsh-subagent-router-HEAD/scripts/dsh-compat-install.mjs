#!/usr/bin/env node
/**
 * DSH compatibility install for CI lanes (plan section 25): installs EVERY
 * `@deepseek-ai/dsh-*` dependency from ONE consistent version family, so a
 * lane never mixes dsh-subagent rc.10 with dsh-agent rc.8.
 *
 * Usage:
 *   node scripts/dsh-compat-install.mjs minimum          # declared minimum
 *   node scripts/dsh-compat-install.mjs latest-compatible  # newest rc family
 *
 * `minimum` pins the lowest DSH release family this package declares
 * (peer/dev ranges all start at 0.1.0-rc.8, so rc.8 IS the minimum today).
 * `latest-compatible` resolves the newest published `0.1.0-rc.x` family
 * across all installed @deepseek-ai/dsh-* packages (they must share one
 * family; a package with no matching rc falls back to its declared range).
 *
 * After the install, the caller runs the normal gates:
 *   npm run typecheck && npm run test && npm run build
 */
import { execSync } from 'node:child_process'
import { readFileSync } from 'node:fs'

const MINIMUM_FAMILY = '0.1.0-rc.8'

const lane = process.argv[2]
if (lane !== 'minimum' && lane !== 'latest-compatible') {
  console.error('usage: node scripts/dsh-compat-install.mjs <minimum|latest-compatible>')
  process.exit(2)
}

const manifest = JSON.parse(readFileSync(new URL('../package.json', import.meta.url), 'utf8'))
const ranges = {
  ...manifest.dependencies ?? {},
  ...manifest.devDependencies ?? {},
}
const dshPackages = Object.keys(ranges).filter(name => name.startsWith('@deepseek-ai/dsh-'))

if (dshPackages.length === 0) {
  console.error('no @deepseek-ai/dsh-* packages found in dependencies/devDependencies')
  process.exit(2)
}

/** Resolve the newest 0.1.0-rc.x family every dsh package can share. */
function resolveLatestFamily() {
  const seen = new Set()
  for (const name of dshPackages) {
    const versions = JSON.parse(
      execSync(`npm view ${name} versions --json`, { encoding: 'utf8', stdio: ['ignore', 'pipe', 'inherit'] }),
    )
    const rcs = versions
      .filter(v => /^0\.1\.0-rc\.\d+$/.test(v))
      .sort((a, b) => {
        const na = Number(a.slice('0.1.0-rc.'.length))
        const nb = Number(b.slice('0.1.0-rc.'.length))
        return nb - na
      })
    if (rcs.length === 0) {
      console.error(`${name}: no 0.1.0-rc.x family found; cannot pin a shared family`)
      process.exit(2)
    }
    seen.add(rcs[0])
  }
  if (seen.size !== 1) {
    console.error(`inconsistent rc families across dsh packages: ${[...seen].join(', ')}`)
    process.exit(2)
  }
  return [...seen][0]
}

const family = lane === 'minimum' ? MINIMUM_FAMILY : resolveLatestFamily()
console.log(`[dsh-compat:${lane}] pinning @deepseek-ai/dsh-* to ${family}`)

const spec = dshPackages.map(name => `${name}@${family}`).join(' ')
execSync(`npm install --save-dev ${spec}`, { stdio: 'inherit' })
console.log(`[dsh-compat:${lane}] installed; run the gates now`)
