/**
 * Publication layout: tsc emits the package's own JS + declarations into
 * lib/types/ (matching the DSH convention for declarations), and the runtime
 * entry bundles are copied to lib/index.js and lib/invariant.js so the
 * manifest's `main`/`exports`/`files` contract holds without a bundler.
 */

import { copyFileSync, mkdirSync } from 'node:fs'
import { dirname, resolve } from 'node:path'

const root = resolve(import.meta.dirname, '..')
const pairs = [
  ['lib/types/index.js', 'lib/index.js'],
  ['lib/types/invariant.js', 'lib/invariant.js'],
]

for (const [source, target] of pairs) {
  const from = resolve(root, source)
  const to = resolve(root, target)
  mkdirSync(dirname(to), { recursive: true })
  copyFileSync(from, to)
}
console.log('copy-lib: staged lib/index.js and lib/invariant.js')
