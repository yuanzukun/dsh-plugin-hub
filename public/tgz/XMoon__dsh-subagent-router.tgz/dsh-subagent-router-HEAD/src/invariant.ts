/**
 * Package-owned invariant companion for `@xmoon76/dsh-subagent-router`.
 * @module @xmoon76/dsh-subagent-router/invariant
 */

/* jscpd:ignore-start */
import type { Context } from '@deepseek-ai/cordis'
import type { InvariantInstaller } from '@deepseek-ai/dsh-invariants'

const PACKAGE_NAME = '@xmoon76/dsh-subagent-router'

/** Cordis companion plugin name. */
export const name = 'tool-subagent-router-invariant'
/** Service required before the companion can reserve package ownership. */
export const inject = ['invariants']

/**
 * No runtime invariant: this model-facing consumer owns no independent
 * lifecycle relation; child lifecycle, ownership, and authority belong to
 * `@deepseek-ai/dsh-subagent` and its continuation manager.
 */
const install: InvariantInstaller = () => {}

/**
 * Register this package's invariant companion.
 * @param ctx - context carrying the invariant service.
 * @returns the registration disposer after setup succeeds.
 */
export const apply = (ctx: Context): Promise<() => void> =>
  Promise.resolve(ctx.invariants.register(PACKAGE_NAME, install))
/* jscpd:ignore-end */
