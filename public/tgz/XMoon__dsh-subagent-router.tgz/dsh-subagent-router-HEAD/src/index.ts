/**
 * Model-facing delegation tool that routes a child subagent to a
 * model-selected configured LLM provider/model. The subagent backend is
 * deployment-owned (`subagentProvider`, default `spawn`); the plugin instance's
 * `backgroundMode` selects the default scheduling policy between a durable
 * continuable child (`ctx.subagents.startContinuable()`) and a one-shot run
 * (`ctx.subagents.start()`). The model never selects the backend or the mode;
 * it may only override the per-call scheduling with the optional
 * `run_in_background` parameter, exactly like the official
 * `@deepseek-ai/dsh-tool-subagent` tools.
 *
 * Scheduling matrix (mirrors the official tools):
 * - `backgroundMode: 'continuable'` (default): `run_in_background` defaults
 *   to `true` — the call returns a durable subagent id immediately after the
 *   initial prompt is accepted; later turns use the official `send_message` /
 *   `list_agents` / `interrupt_agent` tools from
 *   `@deepseek-ai/dsh-tool-subagent-control`. `run_in_background: false`
 *   waits for the child's final output instead.
 * - `backgroundMode: 'one-shot'`: `run_in_background` defaults to `false` —
 *   the call waits and returns the run's final output. `run_in_background:
 *   true` registers a background Task (`ctx.jobs`) and returns a job id;
 *   collect with `job_output` and stop with `job_kill`.
 * @module @xmoon76/dsh-subagent-router
 */

import type { Context } from '@deepseek-ai/cordis'
import z from '@deepseek-ai/schemastery'
import { defineTool } from '@deepseek-ai/dsh-tools'
import type { AgentOptions } from '@deepseek-ai/dsh-agent'
import type { ContentBlock } from '@deepseek-ai/dsh-llm'
import type { JsonValue } from '@deepseek-ai/dsh-session'
import { assertSubagentMaxDepth, settleRun } from '@deepseek-ai/dsh-subagent'
import type {
  SubagentProvider,
  SubagentResult,
  SubagentRun,
} from '@deepseek-ai/dsh-subagent'
import type { JobOutcome } from '@deepseek-ai/dsh-jobs'

export const name = 'tool-subagent-router'
export const inject = ['tools', 'subagents', 'systemPrompt']

/** Prompt order after bounded delegation policy and before child reporting. */
const SUBAGENT_SECTION_ORDER = 116.5

/**
 * DSH official subagent/control tool names this plugin must never shadow.
 * A router instance configured with one of these fails loud at mount time
 * with a dedicated diagnostic (see {@link assertToolNameAvailable}), because
 * the official tools are deployment-owned and the registry would otherwise
 * reject the duplicate registration with a less helpful error.
 */
export const OFFICIAL_SUBAGENT_TOOL_NAMES = new Set([
  'subagent',
  'subagent_fork',
  'send_message',
  'interrupt_agent',
  'list_agents',
])

/**
 * Which child lifecycle this plugin instance establishes as its default
 * scheduling policy. Never exposed to the model: the model selects only the
 * LLM route (provider/model) and may override one call's scheduling with
 * `run_in_background`.
 */
export type ExecutionMode = 'continuable' | 'one-shot'

/** Config: backend selection, scheduling policy, and deployment-side route policy. */
export interface Config {
  /**
   * The `ctx.subagents` provider name to delegate to (default `spawn`).
   * Continuable mode requires a provider with `prepareContinuable`; one-shot
   * mode requires a start-capable provider (fork is the supported one-shot
   * backend).
   */
  subagentProvider?: string
  /**
   * Default scheduling policy (canonical name, default `continuable`).
   * `continuable` calls `startContinuable()` and returns a durable subagent
   * id; `one-shot` calls `start()` and returns the run's final output.
   * `run_in_background` overrides the default per call.
   */
  backgroundMode?: ExecutionMode
  /**
   * Legacy alias for {@link Config.backgroundMode}. Configured together with
   * `backgroundMode` they must agree, otherwise the plugin fails loud at
   * startup.
   * @deprecated use `backgroundMode`
   */
  executionMode?: ExecutionMode
  /**
   * Whether the model-facing `run_in_background` parameter exists and is
   * honored (default `true`). When `false`, every call runs in the foreground
   * and a forged `run_in_background: true` argument is rejected in `execute`.
   */
  enableRunInBackground?: boolean
  /**
   * Model-facing tool name (default `subagent_route`). Each loaded instance
   * must use a distinct name; never use the official `subagent` /
   * `subagent_fork` / control names (mount fails loud).
   */
  toolName?: string
  /**
   * Maximum child depth: a non-negative safe integer (default `3`; `0` forbids
   * delegation), or `'provider-managed'` to send no cap. A numeric cap requires
   * the provider's `depthLimit` capability (mount fails loud otherwise).
   */
  maxDepth?: number | 'provider-managed'
  /** Per-child persona that shadows `deployment:persona`. */
  persona?: string
  /** Tool filter applied to every child; unknown names fail startup. */
  toolFilter?: {
    /** Global tool names the child keeps; everything else is removed. */
    allow?: string[]
    /** Global tool names removed from the child. */
    deny?: string[]
  }
  /**
   * Deployment-side LLM provider allowlist (executor-level enforcement).
   * Omitted = any already-registered DSH LLM provider may be selected;
   * explicit `[]` denies every provider.
   */
  allowedProviders?: string[]
}

export const Config: z<Config> = z.object({
  subagentProvider: z.string().default('spawn'),
  // Preserve omission of both mode keys: the canonical `backgroundMode` and
  // the legacy `executionMode` alias resolve together in `resolveConfig`, and
  // a schema default on either would turn a legacy-only config into a
  // spurious disagreement.
  backgroundMode: z.union(['continuable', 'one-shot'] as const),
  executionMode: z.union(['continuable', 'one-shot'] as const),
  enableRunInBackground: z.boolean().default(true),
  toolName: z.string().default('subagent_route'),
  maxDepth: z.union([
    z.natural().max(Number.MAX_SAFE_INTEGER),
    z.const('provider-managed' as const),
  ]).default(3),
  persona: z.string(),
  // Preserve omission: Schemastery's `{ allow: [] }` default would deny every tool.
  toolFilter: z.object({
    allow: z.array(z.string()).default(undefined as unknown as string[]),
    deny: z.array(z.string()).default(undefined as unknown as string[]),
  }).default(undefined as unknown as { allow: string[]; deny: string[] }),
  allowedProviders: z.array(z.string()).default(undefined as unknown as string[]),
})

/** Reject a provider route the deployment allowlist forbids, before any child work. */
function assertProviderAllowed(provider: string, allowedProviders: string[] | undefined): void {
  if (allowedProviders !== undefined && !allowedProviders.includes(provider)) {
    throw new Error(`LLM provider "${provider}" is not allowed for this delegation tool`)
  }
}

/**
 * Reject a tool name the registry already serves, before the router registers
 * anything. Checked at the real provider-mount boundary (not only in
 * `apply()`), because the router supports late provider registration: the
 * true collision moment can be `subagent/provider-added`. The check never
 * shadows an existing tool — the registry itself would fail the duplicate,
 * but a dedicated diagnostic at this boundary gives the deployment a clear
 * fix. DSH official subagent/control names get their own message.
 */
function assertToolNameAvailable(toolName: string, existing: unknown): void {
  if (existing === undefined) return
  if (OFFICIAL_SUBAGENT_TOOL_NAMES.has(toolName)) {
    throw new Error(
      `tool-subagent-router: tool name "${toolName}" conflicts with a DSH built-in subagent/control tool — `
      + 'choose a unique toolName',
    )
  }
  throw new Error(
    `tool-subagent-router: tool name "${toolName}" is already registered — choose a unique toolName`,
  )
}

/** A non-`completed` stop reason means the child did not finish cleanly. */
function stopReasonError(result: SubagentResult): string | undefined {
  switch (result.stopReason) {
    case 'completed':
      return undefined
    case 'aborted':
      return 'subagent run was cancelled'
    case 'error':
      return 'subagent run failed'
    case 'max-tokens':
      return 'subagent run hit its token limit before finishing'
    case 'refusal':
      return 'subagent declined the task'
    default:
      return `subagent run ended abnormally (${String(result.stopReason)})`
  }
}

/**
 * Append provider-authored failure detail and the child's preserved partial
 * answer to a stop-reason error, keeping diagnostic text separate from the
 * child's assistant output.
 * @param error - the stop-reason headline.
 * @param result - the child's terminal result.
 * @returns the headline, diagnostic, and partial text that are present.
 */
function withDiagnosticAndPartialText(error: string, result: SubagentResult): string {
  const diagnostic = result.diagnostic === undefined ? '' : `\nDiagnostic: ${result.diagnostic}`
  const text = result.output
    .filter((block): block is Extract<ContentBlock, { type: 'text' }> => block.type === 'text')
    .map(block => block.text)
    .join('')
  return `${error}${diagnostic}${text.length === 0 ? '' : `\nPartial output before the run ended:\n${text}`}`
}

/** Render text blocks from the canonical JSON block array. */
function outputValueText(values: JsonValue[]): string {
  return values
    .filter((value): value is { type: 'text'; text: string } =>
      typeof value === 'object' && value !== null && !Array.isArray(value)
      && value.type === 'text' && typeof value.text === 'string')
    .map(value => value.text)
    .join('')
}

/**
 * Model-facing wording from the provider's conversation-history descriptor
 * ({@link SubagentProvider.inheritsParentContext}). A fresh child needs a
 * standalone prompt; a forked child already sees the conversation's completed
 * turns. Every description also contrasts this router tool with the official
 * `subagent`/`subagent_fork` tools: the official instances bind one fixed
 * deployment route, while this tool lets the model select the child's
 * provider/model on every call.
 */
function providerWording(inheritsConversation: boolean): { description: string; promptDescription: string } {
  const routeContrast =
    ' Unlike the official `subagent_fork` tool, which uses a deployment-fixed child model route, '
    + 'this tool lets you select the child provider/model with every call.'
  if (inheritsConversation) {
    return {
      description:
        'Delegate a task to a subagent that inherits this conversation: a child agent seeded with all '
        + 'completed turns so far (it does not see the current in-flight turn). Use this when the subtask '
        + 'builds on this conversation\'s context — a follow-up analysis, '
        + 'a review, a continuation — without consuming this conversation\'s context for the work itself. '
        + 'You receive its result, not its intermediate steps.'
        + routeContrast,
      promptDescription:
        'The task for the subagent. It already sees this conversation\'s completed turns, so build on them '
        + 'freely and state only what is new.',
    }
  }
  return {
    description:
      'Delegate a self-contained task to a subagent (a separate agent that works in its own context) '
      + 'to offload focused, independent work — research, a scoped '
      + 'implementation, an analysis — so it does not consume this conversation\'s context. The subagent '
      + 'returns its result, not its intermediate steps. Give it a '
      + 'complete, standalone prompt: it does not see this conversation.'
      + routeContrast.replace('`subagent_fork`', '`subagent`'),
    promptDescription:
      'The complete, self-contained task for the subagent. It does not share this '
      + 'conversation\'s context, so include everything it needs.',
  }
}

/** The foreground run's canonical output. */
interface ForegroundToolResult {
  readonly kind: 'foreground'
  readonly runId: SubagentRun['id']
  readonly output: JsonValue[]
}

/**
 * Collect and release one foreground run without letting disposal replace an
 * independent result failure.
 */
async function settleForegroundRun(run: SubagentRun): Promise<ForegroundToolResult> {
  const [execution] = await Promise.allSettled([
    run.result.then((result): ForegroundToolResult => {
      const error = stopReasonError(result)
      if (error !== undefined) {
        throw new Error(withDiagnosticAndPartialText(error, result))
      }
      return {
        kind: 'foreground',
        runId: run.id,
        output: result.output as unknown as JsonValue[],
      }
    }),
  ])
  const [disposal] = await Promise.allSettled([Promise.resolve().then(() => run.dispose())])
  if (execution.status === 'rejected') {
    if (disposal.status === 'rejected') {
      throw new AggregateError(
        [execution.reason, disposal.reason],
        `subagent run failed: ${String(execution.reason)}; dispose failed: ${String(disposal.reason)}`,
      )
    }
    throw execution.reason
  }
  if (disposal.status === 'rejected') throw disposal.reason
  return execution.value
}

/**
 * Settle a background one-shot run into a Task outcome without rejecting the
 * task producer contract. Startup and cleanup failures become `failed`;
 * a cancellation that aborted the child (and was not itself an
 * `AggregateError`) becomes `killed`.
 */
async function settleStart(start: Promise<SubagentRun>, signal: AbortSignal): Promise<JobOutcome> {
  try {
    return await settleRun(await start)
  } catch (error) {
    return signal.aborted && !(error instanceof AggregateError)
      ? { status: 'killed' }
      : { status: 'failed', detail: String(error) }
  }
}

/** Resolved instance options derived once from validated config. */
interface ResolvedConfig {
  readonly subagentProvider: string
  readonly backgroundMode: ExecutionMode
  readonly enableRunInBackground: boolean
  readonly toolName: string
  readonly maxDepth?: number | 'provider-managed'
  readonly persona?: string
  readonly toolFilter?: Config['toolFilter']
  readonly allowedProviders?: string[]
}

function resolveConfig(config: Config): ResolvedConfig {
  if (config.maxDepth !== 'provider-managed') assertSubagentMaxDepth(config.maxDepth)
  if (config.toolFilter !== undefined
    && config.toolFilter.allow === undefined && config.toolFilter.deny === undefined) {
    throw new Error(
      'tool-subagent-router: `toolFilter` is configured but names neither `allow` nor `deny` '
      + '— remove the key or fill the filter',
    )
  }
  const backgroundMode = config.backgroundMode ?? config.executionMode ?? 'continuable'
  if (config.backgroundMode !== undefined && config.executionMode !== undefined
    && config.backgroundMode !== config.executionMode) {
    throw new Error(
      'tool-subagent-router: `backgroundMode` and legacy `executionMode` disagree '
      + `(${config.backgroundMode} vs ${config.executionMode}) — remove one of them`,
    )
  }
  return {
    subagentProvider: config.subagentProvider ?? 'spawn',
    backgroundMode,
    enableRunInBackground: config.enableRunInBackground !== false,
    toolName: config.toolName ?? 'subagent_route',
    ...config.maxDepth !== undefined ? { maxDepth: config.maxDepth } : {},
    ...config.persona !== undefined ? { persona: config.persona } : {},
    ...config.toolFilter !== undefined ? { toolFilter: config.toolFilter } : {},
    ...config.allowedProviders !== undefined ? { allowedProviders: config.allowedProviders } : {},
  }
}

/** The model's optional scheduling request. */
interface DelegationRunRequest {
  run_in_background?: boolean
}

/** The resolved execution route for one call. */
interface DelegationRunSpec {
  runInBackground: boolean
}

/**
 * Resolve the model's optional scheduling request into one execution route,
 * mirroring the official `@deepseek-ai/dsh-tool-subagent` policy: with
 * background enabled, `run_in_background` defaults to the instance's
 * `backgroundMode` (`continuable` → background, `one-shot` → foreground);
 * with background disabled, every call is foreground and a forged
 * `run_in_background: true` is rejected.
 */
function resolveDelegationRun(
  request: DelegationRunRequest,
  options: { backgroundEnabled: boolean; continuable: boolean },
): DelegationRunSpec {
  if (!options.backgroundEnabled) {
    if (request.run_in_background === true) {
      throw new Error('run_in_background is disabled for this tool instance (enableRunInBackground: false)')
    }
    return { runInBackground: false }
  }
  return { runInBackground: request.run_in_background ?? options.continuable }
}

/**
 * Register the `subagent_route` tool (or the configured `toolName`) while the
 * configured backend provider is
 * available, mirroring the provider lifecycle so sibling load order and HMR
 * replacement cannot leave a dead tool registered. Continuable instances also
 * contribute a `tool:<toolName>` system-prompt guidance section while the tool
 * is live.
 * @param ctx - context carrying the tool registry, subagent service, and
 *   system-prompt registry.
 * @param config - validated plugin configuration.
 */
export function apply(ctx: Context, config: Config): void {
  const resolved = resolveConfig(config)
  const backgroundEnabled = resolved.enableRunInBackground
  const continuable = resolved.backgroundMode === 'continuable'
  let disposeTool: (() => void) | undefined

  const mount = (provider: SubagentProvider): void => {
    // Fail fast before registering anything: the registry would reject a
    // duplicate name, but a dedicated diagnostic here also covers the
    // late-provider path (provider added after another tool took the name).
    assertToolNameAvailable(resolved.toolName, ctx.tools.get(resolved.toolName))
    if (typeof resolved.maxDepth === 'number' && !provider.capabilities.depthLimit) {
      throw new Error(
        `tool-subagent-router: provider "${provider.name}" cannot enforce maxDepth (no depthLimit capability) — `
        + 'set maxDepth: \'provider-managed\' to leave the recursion budget to the provider',
      )
    }
    if (continuable && provider.prepareContinuable === undefined) {
      throw new Error(
        `tool-subagent-router: provider "${provider.name}" does not support continuable children `
        + '(no prepareContinuable capability)',
      )
    }
    const wording = providerWording(provider.inheritsParentContext)

    disposeTool = ctx.tools.register(defineTool({
      name: resolved.toolName,
      description: wording.description
        + (backgroundEnabled
          ? continuable
            ? ' This tool runs in the background by default, immediately returns a durable subagent id, '
              + 'and keeps the child conversation available for later turns. When that run settles, the '
              + 'runtime sends the parent a notice containing its outcome and any final assistant message; '
              + '`send_message` starts a later turn in the same child conversation. Set '
              + '`run_in_background: false` only when your next action depends on receiving the result.'
            : ' This call waits for the result by default. Set `run_in_background: true` to return a job '
              + 'id; collect with `job_output` and stop with `job_kill`.'
          : ' This call waits for the subagent and returns its result.'),
      parameters: {
        description: {
          type: 'string',
          required: true,
          description: 'A short (3-5 word) label describing the delegated task.',
        },
        prompt: {
          type: 'string',
          required: true,
          description: wording.promptDescription,
        },
        provider: {
          type: 'string',
          required: true,
          description: 'The configured DSH LLM provider route for the child.',
        },
        model: {
          type: 'string',
          required: true,
          description: 'The model id to use for this child conversation.',
        },
        ...backgroundEnabled ? {
          run_in_background: {
            type: 'boolean',
            description: continuable
              ? 'Whether to run in the background and return a durable subagent id immediately. '
                + 'Defaults to true. Set false to wait for the result when your next action depends on it.'
              : 'Whether to run as a background job and return its id. Defaults to false; '
                + 'collect with job_output or stop with job_kill.',
          },
        } : {},
      },
      output: {
        schema: {
          oneOf: [
            {
              type: 'object',
              additionalProperties: false,
              properties: {
                kind: { type: 'string', required: true, const: 'background' },
                jobId: { type: 'string', required: true },
              },
            },
            {
              type: 'object',
              additionalProperties: false,
              properties: {
                kind: { type: 'string', required: true, const: 'continuable' },
                subagentId: { type: 'string', required: true },
              },
            },
            {
              type: 'object',
              additionalProperties: false,
              properties: {
                kind: { type: 'string', required: true, const: 'foreground' },
                runId: { type: 'string', required: true },
                output: { type: 'array', required: true, items: { type: 'json' } },
              },
            },
          ],
        },
        render: (_args, value) => [{
          type: 'text',
          text: value.kind === 'background'
            ? `started background subagent job ${value.jobId}`
            : value.kind === 'continuable'
              ? `started subagent ${value.subagentId}`
              : outputValueText(value.output),
        }],
      },
      // Children never mutate the parent session. The continuable path's only
      // parent-owned write is the synchronous startContinuable inbox insertion;
      // the foreground path's child-session creation is serialized by the
      // subagent service, and the background path's only parent-owned write is
      // the synchronous jobs.start() registration (DSH's own parallel-delegation
      // tests cover both), so sibling delegations may overlap under the loop's
      // rolling pool.
      isConcurrencySafe: () => true,
      async execute(args, exec) {
        const parent = exec.agent
        if (parent === undefined) {
          throw new Error('this delegation tool requires a live parent agent (exec.agent was undefined)')
        }
        assertProviderAllowed(args.provider, resolved.allowedProviders)

        const maxDepth = typeof resolved.maxDepth === 'number' ? resolved.maxDepth : undefined
        const request = {
          label: args.description,
          prompt: [{ type: 'text', text: args.prompt }] as ContentBlock[],
          parent,
          agentOptions: {
            provider: args.provider,
            model: args.model,
          } satisfies AgentOptions,
          ...resolved.persona !== undefined ? { persona: resolved.persona } : {},
          ...resolved.toolFilter !== undefined ? { toolFilter: resolved.toolFilter } : {},
          ...maxDepth !== undefined ? { maxDepth } : {},
        }

        if (resolveDelegationRun(args, { backgroundEnabled, continuable }).runInBackground) {
          if (continuable) {
            const started = await ctx.subagents.startContinuable({
              provider: resolved.subagentProvider,
              label: args.description,
              request,
              signal: exec.signal,
            })
            return { kind: 'continuable' as const, subagentId: started.childId }
          }

          const jobs = ctx.get('jobs')
          if (jobs === undefined) {
            throw new Error('background jobs unavailable: load @deepseek-ai/dsh-jobs and @deepseek-ai/dsh-tool-jobs')
          }
          return {
            kind: 'background' as const,
            jobId: jobs.start({
              kind: 'subagent',
              label: args.description,
              owner: parent,
              run: () => {
                const controller = new AbortController()
                return {
                  cancel: (reason) => {
                    controller.abort(reason ?? 'background subagent task killed')
                  },
                  done: settleStart(
                    ctx.subagents.start(resolved.subagentProvider, {
                      ...request,
                      signal: controller.signal,
                    }),
                    controller.signal,
                  ),
                }
              },
            }),
          }
        }

        const run: SubagentRun = await ctx.subagents.start(resolved.subagentProvider, {
          ...request,
          signal: exec.signal,
        })
        return settleForegroundRun(run)
      },
    }))
  }

  // Register listeners before checking presence so no synchronous change is missed.
  ctx.on('subagent/provider-added', (provider) => {
    if (provider.name === resolved.subagentProvider && disposeTool === undefined) mount(provider)
  })
  ctx.on('subagent/provider-removed', (name) => {
    if (name !== resolved.subagentProvider || disposeTool === undefined) return
    disposeTool()
    disposeTool = undefined
  })
  const present = ctx.subagents.getProvider(resolved.subagentProvider)
  if (present !== undefined) {
    mount(present)
  } else {
    ctx.logger.info(`subagent provider "${resolved.subagentProvider}" not registered yet; the "${resolved.toolName}" tool will register when it appears`)
  }

  // Continuable instances guide the model toward background-by-default
  // delegation, mirroring the official tool's system-prompt section. The
  // section renders empty while the tool is absent (provider not yet
  // registered or already removed), so HMR cannot leave stale guidance.
  if (backgroundEnabled && continuable) {
    ctx.systemPrompt.section({
      name: `tool:${resolved.toolName}`,
      order: SUBAGENT_SECTION_ORDER,
      text: (context) => disposeTool === undefined
        || ctx.tools.get(resolved.toolName, context.scope) === undefined
        ? ''
        : `Use ${resolved.toolName} in the background by default. Start independent delegations together `
          + 'in one assistant message and continue useful work while they run. Set '
          + '`run_in_background: false` only when your next action depends on that subagent\'s result. '
          + 'When a background run settles, the runtime sends you a notice containing its outcome and any '
          + 'final assistant message.',
    })
  }
}
