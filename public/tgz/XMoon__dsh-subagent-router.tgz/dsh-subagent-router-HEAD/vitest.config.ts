import { defineConfig } from 'vitest/config'

// Dependencies resolve through node_modules (npm registry @deepseek-ai/dsh-*
// packages) — no paths plugin needed. Tests import our src/ directly.
// pool: 'forks' matches the DSH repo's vitest setup, which avoids worker-thread
// coverage-attribution gaps for event-callback lines.
export default defineConfig({
  test: {
    include: ['tests/**/*.spec.ts'],
    pool: 'forks',
    coverage: {
      provider: 'v8',
      include: ['src/**/*.ts'],
      reporter: ['text', 'html'],
    },
  },
})
