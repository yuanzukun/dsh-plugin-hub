/**
 * Package integration suite for `@xmoon76/dsh-subagent-router`. Boots the
 * REAL continuation graph (agent loop, tool registry, subagent runtime, spawn
 * provider, JSONL persistence) with a scripted LLM adapter and drives the
 * registered `subagent_route` tool through `ctx.tools.execute` — everything
 * downstream of the child boundary is the shipping code path.
 */

import { afterEach, describe, expect, it, vi } from 'vitest'
import { Context } from '@deepseek-ai/cordis'
import { CallId } from '@deepseek-ai/dsh-llm'
import { SessionId } from '@deepseek-ai/dsh-session'
import * as tool from '../src/index.ts'
import { bootHarness, cleanupRoots, textResponse, type Harness } from './harness.ts'

const testToolSignal = new AbortController().signal

let callCounter = 0
function callStart(ctx: Context, args: unknown, over: { agent?: unknown; signal?: AbortSignal; name?: string } = {}) {
  const agent = 'agent' in over ? over.agent : undefined
  return ctx.tools.execute({
    signal: over.signal ?? testToolSignal,
    callId: CallId(`call-${++callCounter}`),
    name: over.name ?? 'subagent_route',
    arguments: args,
    ...agent !== undefined ? { agent: agent as never } : {},
  })
}

function text(result: { content: { type: string; text?: string }[] }): string {
  return result.content.filter(block => block.type === 'text').map(block => block.text).join('')
}

/** Wait until a child's Activation released its handle (child settled). */
async function waitNoActivation(ctx: Context, childId: string): Promise<void> {
  await vi.waitFor(() => {
    expect(ctx.agents.get(SessionId(childId))).toBeUndefined()
  }, { timeout: 5_000 })
}

/** Load the durable child session and return its continuation descriptor. */
async function loadDescriptor(ctx: Context, childId: string) {
  const loaded = await ctx.sessionPersistence.load(SessionId(childId))
  const event = loaded.events.find(event => event.type === 'subagent/descriptor')
  return event?.type === 'subagent/descriptor' ? event.data : undefined
}
async function mountTool(h: Harness, config: Partial<tool.Config> = {}) {
  await h.ctx.plugin(tool, { executionMode: 'continuable', subagentProvider: 'spawn', ...config })
}

afterEach(() => {
  cleanupRoots()
})

describe('dsh-subagent-router plugin export shape', () => {
  it('has the namespace-plugin export shape (no stray default) so the Loader keeps name/inject/Config/apply', () => {
    expect('default' in tool).toBe(false)
    expect(tool.name).toBe('tool-subagent-router')
    expect(tool.inject).toEqual(['tools', 'subagents', 'systemPrompt'])
    expect(typeof tool.apply).toBe('function')
    expect(tool.Config).toBeDefined()
  })
})

describe('provider lifecycle / HMR', () => {
  it('registers when the provider appears later, and disposes it on removal', async () => {
    const ctx = new Context()
    try {
      const { mountAgentLoopTestDependencies } = await import('@deepseek-ai/dsh-agent-loop-testkit')
      await mountAgentLoopTestDependencies(ctx)
      const SubagentRuntime = (await import('@deepseek-ai/dsh-subagent')).default
      await ctx.plugin(SubagentRuntime)

      // Capture the waiting-note log emitted while the provider is absent.
      const messages: string[] = []
      ctx.logger.exporter({
        export(entry) { messages.push(entry.args.map(String).join(' ')) },
      })
      // Direct apply (schema bypass): the tool must be absent while the
      // provider is missing, then appear when the backend registers.
      tool.apply(ctx, { executionMode: 'continuable', subagentProvider: 'late-spawn' })
      expect(ctx.tools.schemas().some(s => s.name === 'subagent_route')).toBe(false)
      expect(messages.some(message => message.includes('late-spawn'))).toBe(true)

      const SubagentSpawn = await import('@deepseek-ai/dsh-subagent-spawn-in-process')
      const fiber = await ctx.plugin(SubagentSpawn, { providerName: 'late-spawn' })
      expect(ctx.tools.schemas().some(s => s.name === 'subagent_route')).toBe(true)

      await fiber.dispose()
      expect(ctx.tools.schemas().some(s => s.name === 'subagent_route')).toBe(false)
    } finally {
      await ctx.fiber.dispose()
    }
  })

  it('re-registers after a provider HMR cycle (added → removed → added)', async () => {
    const ctx = new Context()
    try {
      const { mountAgentLoopTestDependencies } = await import('@deepseek-ai/dsh-agent-loop-testkit')
      await mountAgentLoopTestDependencies(ctx)
      const SubagentRuntime = (await import('@deepseek-ai/dsh-subagent')).default
      await ctx.plugin(SubagentRuntime)
      const SubagentSpawn = await import('@deepseek-ai/dsh-subagent-spawn-in-process')

      const fiber = await ctx.plugin(tool, { executionMode: 'continuable', subagentProvider: 'hmr-spawn' })
      expect(ctx.tools.schemas().some(s => s.name === 'subagent_route')).toBe(false)

      const providerFiber = await ctx.plugin(SubagentSpawn, { providerName: 'hmr-spawn' })
      expect(ctx.tools.schemas().some(s => s.name === 'subagent_route')).toBe(true)

      // HMR: provider replaced.
      await providerFiber.dispose()
      expect(ctx.tools.schemas().some(s => s.name === 'subagent_route')).toBe(false)

      const providerFiber2 = await ctx.plugin(SubagentSpawn, { providerName: 'hmr-spawn' })
      expect(ctx.tools.schemas().some(s => s.name === 'subagent_route')).toBe(true)

      await providerFiber2.dispose()
      await fiber.dispose()
      expect(ctx.tools.schemas().some(s => s.name === 'subagent_route')).toBe(false)
    } finally {
      await ctx.fiber.dispose()
    }
  })

  it('ignores a provider-removed event that arrives after the tool is already unregistered', async () => {
    const ctx = new Context()
    try {
      const { mountAgentLoopTestDependencies } = await import('@deepseek-ai/dsh-agent-loop-testkit')
      await mountAgentLoopTestDependencies(ctx)
      const SubagentRuntime = (await import('@deepseek-ai/dsh-subagent')).default
      await ctx.plugin(SubagentRuntime)
      const SubagentSpawn = await import('@deepseek-ai/dsh-subagent-spawn-in-process')

      const fiber = await ctx.plugin(tool, { executionMode: 'continuable', subagentProvider: 'gone-spawn' })
      const providerFiber = await ctx.plugin(SubagentSpawn, { providerName: 'gone-spawn' })
      expect(ctx.tools.schemas().some(s => s.name === 'subagent_route')).toBe(true)

      // A re-added event while the tool is already registered is a no-op
      // (disposeTool is defined, so mount must not run again).
      const liveProvider = ctx.subagents.getProvider('gone-spawn')
      if (liveProvider === undefined) throw new Error('expected the registered provider')
      ctx.emit('subagent/provider-added', liveProvider)
      expect(ctx.tools.schemas().filter(s => s.name === 'subagent_route')).toHaveLength(1)

      // First removal unregisters the tool (disposeTool becomes undefined).
      await providerFiber.dispose()
      expect(ctx.tools.schemas().some(s => s.name === 'subagent_route')).toBe(false)

      // A second removal with no re-add finds disposeTool already undefined and
      // must be a no-op (no double-dispose, no throw).
      ctx.emit('subagent/provider-removed', 'gone-spawn')
      expect(ctx.tools.schemas().some(s => s.name === 'subagent_route')).toBe(false)

      await fiber.dispose()
    } finally {
      await ctx.fiber.dispose()
    }
  })

  it('disposes the tool with its own plugin fiber (HMR safety)', async () => {
    const h = await bootHarness()
    try {
      const fiber = await h.ctx.plugin(tool, { executionMode: 'continuable', subagentProvider: 'spawn' })
      expect(h.ctx.tools.schemas().some(s => s.name === 'subagent_route')).toBe(true)
      await fiber.dispose()
      expect(h.ctx.tools.schemas().some(s => s.name === 'subagent_route')).toBe(false)
    } finally {
      await h.ctx.fiber.dispose()
      h.cleanup()
    }
  })

  it('fails mount when the continuable provider lacks prepareContinuable', async () => {
    const ctx = new Context()
    try {
      const { mountAgentLoopTestDependencies } = await import('@deepseek-ai/dsh-agent-loop-testkit')
      await mountAgentLoopTestDependencies(ctx)
      const SubagentRuntime = (await import('@deepseek-ai/dsh-subagent')).default
      await ctx.plugin(SubagentRuntime)
      ctx.subagents.registerProvider({
        name: 'no-continuable',
        capabilities: { outputSchema: false, depthLimit: true, toolFilter: true, persona: true },
        inheritsParentContext: false,
        start: async () => { throw new Error('unused') },
      })
      await expect(ctx.plugin(tool, {
        executionMode: 'continuable',
        subagentProvider: 'no-continuable',
      })).rejects.toThrow(/does not support continuable children/)
    } finally {
      await ctx.fiber.dispose()
    }
  })

  it('fails mount when a numeric maxDepth exceeds provider depthLimit capability', async () => {
    const ctx = new Context()
    try {
      const { mountAgentLoopTestDependencies } = await import('@deepseek-ai/dsh-agent-loop-testkit')
      await mountAgentLoopTestDependencies(ctx)
      const SubagentRuntime = (await import('@deepseek-ai/dsh-subagent')).default
      await ctx.plugin(SubagentRuntime)
      ctx.subagents.registerProvider({
        name: 'no-depth',
        capabilities: { outputSchema: false, depthLimit: false, toolFilter: false, persona: false },
        inheritsParentContext: false,
        start: async () => { throw new Error('unused') },
      })
      await expect(ctx.plugin(tool, {
        backgroundMode: 'one-shot',
        subagentProvider: 'no-depth',
        maxDepth: 3,
      })).rejects.toThrow(/cannot enforce maxDepth/)
    } finally {
      await ctx.fiber.dispose()
    }
  })

  it('fails loud when a late provider-added event triggers an unsupported mount, leaving no tool behind', async () => {
    const ctx = new Context()
    try {
      const { mountAgentLoopTestDependencies } = await import('@deepseek-ai/dsh-agent-loop-testkit')
      await mountAgentLoopTestDependencies(ctx)
      const SubagentRuntime = (await import('@deepseek-ai/dsh-subagent')).default
      await ctx.plugin(SubagentRuntime)
      // Tool first: the provider is absent, so the tool registers its
      // provider-added listener and waits.
      await ctx.plugin(tool, { executionMode: 'continuable', subagentProvider: 'late-no-continuable' })
      expect(ctx.tools.schemas().some(s => s.name === 'subagent_route')).toBe(false)

      // A provider WITHOUT prepareContinuable arrives later: the event-driven
      // mount must fail loud (the registration rejects), and no tool may be
      // left registered.
      await expect(ctx.plugin({
        name: 'late-provider',
        inject: ['subagents'],
        apply(pluginCtx: Context): void {
          pluginCtx.subagents.registerProvider({
            name: 'late-no-continuable',
            capabilities: { outputSchema: false, depthLimit: true, toolFilter: true, persona: true },
            inheritsParentContext: false,
            start: async () => { throw new Error('unused') },
          })
        },
      })).rejects.toThrow(/does not support continuable children/)
      expect(ctx.tools.schemas().some(s => s.name === 'subagent_route')).toBe(false)
    } finally {
      await ctx.fiber.dispose()
    }
  })
})

describe('Config', () => {
  it('defaults subagentProvider to spawn, enableRunInBackground to true, toolName to subagent_route, maxDepth to 3', () => {
    const config = tool.Config({}) as unknown as Record<string, unknown>
    expect(config.subagentProvider).toBe('spawn')
    expect(config.enableRunInBackground).toBe(true)
    expect(config.toolName).toBe('subagent_route')
    expect(config.maxDepth).toBe(3)
  })

  it('preserves omission of the mode keys, toolFilter, and allowedProviders (no materialized defaults)', () => {
    const config = tool.Config({}) as unknown as Record<string, unknown>
    expect(config.backgroundMode).toBeUndefined()
    expect(config.executionMode).toBeUndefined()
    expect(config.toolFilter).toBeUndefined()
    expect(config.allowedProviders).toBeUndefined()
  })

  it('resolves backgroundMode ?? executionMode ?? continuable, and rejects disagreement', () => {
    // Canonical name wins when only it is set.
    expect(tool.Config({ backgroundMode: 'one-shot' } as never).backgroundMode).toBe('one-shot')
    // Legacy alias still works alone.
    expect(tool.Config({ executionMode: 'one-shot' } as never).executionMode).toBe('one-shot')
    // Both set and agreeing is fine.
    expect(() => tool.Config({ backgroundMode: 'one-shot', executionMode: 'one-shot' } as never)).not.toThrow()
    // Both set and disagreeing fails loud at apply (schema keeps both).
    const h = new Context()
    expect(() => tool.apply(h, {
      backgroundMode: 'continuable',
      executionMode: 'one-shot',
      subagentProvider: 'spawn',
    })).toThrow(/backgroundMode.*executionMode.*disagree/)
  })

  it('rejects an invalid maxDepth', () => {
    expect(() => tool.Config({ maxDepth: -1 } as never)).toThrow()
  })

  it('rejects a toolFilter that names neither allow nor deny', async () => {
    const h = await bootHarness()
    try {
      await expect(mountTool(h, { toolFilter: {} } as never)).rejects.toThrow(/names neither `allow` nor `deny`/)
    } finally {
      await h.ctx.fiber.dispose()
      h.cleanup()
    }
  })

  it('applies built-in defaults when apply() receives an empty config', async () => {
    const h = await bootHarness({ script: [textResponse('defaults')] })
    try {
      // Direct apply bypasses Schemastery defaults; the fallbacks must hold.
      tool.apply(h.ctx, {})
      expect(h.ctx.tools.schemas().some(s => s.name === 'subagent_route')).toBe(true)
      const result = await callStart(h.ctx, {
        description: 'd',
        prompt: 'p',
        provider: 'mock',
        model: 'mock',
      }, { agent: h.parent })
      expect(result.isError).toBe(false)
    } finally {
      await h.ctx.fiber.dispose()
      h.cleanup()
    }
  })
})

describe('tool schema', () => {
  it('exposes description/prompt/provider/model plus optional run_in_background, no secret or mode params', async () => {
    const h = await bootHarness()
    try {
      await mountTool(h)
      const schema = h.ctx.tools.schemas().find(s => s.name === 'subagent_route')
      expect(schema).toBeDefined()
      const props = (schema!.parameters as { properties?: Record<string, unknown> }).properties ?? {}
      expect(Object.keys(props).sort()).toEqual(['description', 'model', 'prompt', 'provider', 'run_in_background'])
      const required = (schema!.parameters as { required?: string[] }).required ?? []
      expect(required.sort()).toEqual(['description', 'model', 'prompt', 'provider'])
      for (const forbidden of ['api_key', 'base_url', 'max_tokens', 'subagent_provider', 'execution_mode', 'background_mode']) {
        expect(Object.keys(props)).not.toContain(forbidden)
      }
      // Continuable mode documents the durable-id contract and the
      // background-by-default scheduling.
      expect(schema!.description).toContain('send_message')
      expect(schema!.description).toContain('durable subagent id')
      expect(schema!.description).toContain('run_in_background: false')
      const runInBackground = props.run_in_background as { description?: string }
      expect(runInBackground.description).toContain('Defaults to true')
    } finally {
      await h.ctx.fiber.dispose()
      h.cleanup()
    }
  })

  it('one-shot mode documents the foreground default and job collection', async () => {
    const h = await bootHarness({ withFork: true })
    try {
      await h.ctx.plugin(tool, { backgroundMode: 'one-shot', subagentProvider: 'fork', toolName: 'subagent_fork_route' })
      const schema = h.ctx.tools.schemas().find(s => s.name === 'subagent_fork_route')
      expect(schema).toBeDefined()
      if (schema === undefined) throw new Error('expected the fork schema')
      expect(schema.description).toContain('job_output')
      expect(schema.description).toContain('job_kill')
      const props = (schema.parameters as { properties?: Record<string, { description?: string }> }).properties ?? {}
      expect(props.run_in_background?.description).toContain('Defaults to false')
    } finally {
      await h.ctx.fiber.dispose()
      h.cleanup()
    }
  })

  it('enableRunInBackground: false removes run_in_background from the schema', async () => {
    const h = await bootHarness()
    try {
      await mountTool(h, { enableRunInBackground: false })
      const schema = h.ctx.tools.schemas().find(s => s.name === 'subagent_route')
      expect(schema).toBeDefined()
      const props = (schema!.parameters as { properties?: Record<string, unknown> }).properties ?? {}
      expect(Object.keys(props).sort()).toEqual(['description', 'model', 'prompt', 'provider'])
      expect(schema!.description).toContain('waits for the subagent and returns its result')
    } finally {
      await h.ctx.fiber.dispose()
      h.cleanup()
    }
  })

  it('wording follows provider.inheritsParentContext: spawn says standalone prompt, fork says inherits', async () => {
    const h = await bootHarness({ withFork: true })
    try {
      await h.ctx.plugin(tool, { backgroundMode: 'one-shot', subagentProvider: 'fork', toolName: 'subagent_fork_route' })
      const forkSchema = h.ctx.tools.schemas().find(s => s.name === 'subagent_fork_route')
      expect(forkSchema).toBeDefined()
      if (forkSchema === undefined) throw new Error('expected the fork schema')
      expect(forkSchema.description).toContain('inherits this conversation')
      const forkPrompt = (forkSchema.parameters as { properties: Record<string, { description: string }> }).properties.prompt
      if (forkPrompt === undefined) throw new Error('expected the fork prompt description')
      expect(forkPrompt.description).toContain('already sees this conversation')
    } finally {
      await h.ctx.fiber.dispose()
      h.cleanup()
    }
  })
})

describe('execution: continuable start', () => {
  it('creates a continuable child with the model-selected provider/model recorded in its descriptor', async () => {
    const h = await bootHarness({ script: [textResponse('first answer')] })
    try {
      await mountTool(h)
      const result = await callStart(h.ctx, {
        description: 'Review diff',
        prompt: 'Inspect the diff.',
        provider: 'mock',
        model: 'mock',
      }, { agent: h.parent })
      expect(result.isError).toBe(false)
      const match = /^started subagent (\S+)$/.exec(text(result))
      expect(match).not.toBeNull()
      const childId = match![1] as string

      await waitNoActivation(h.ctx, childId)
      const descriptor = await loadDescriptor(h.ctx, childId)
      expect(descriptor).toMatchObject({
        mode: 'continuable',
        provider: 'spawn',
        agentProvider: 'mock',
        agentModel: 'mock',
        label: 'Review diff',
      })

      // The child produced a turn and its session is durable.
      const loaded = await h.ctx.sessionPersistence.load(SessionId(childId))
      expect(loaded.events.some(event => event.type === 'assistant/message')).toBe(true)
    } finally {
      await h.ctx.fiber.dispose()
      h.cleanup()
    }
  })

  it('continues the SAME child through the official send_message tool', async () => {
    const h = await bootHarness({ script: [textResponse('first'), textResponse('second')] })
    try {
      await mountTool(h)
      const started = await callStart(h.ctx, {
        description: 'long work',
        prompt: 'dig in',
        provider: 'mock',
        model: 'mock',
      }, { agent: h.parent })
      const childId = /started subagent (\S+)/.exec(text(started))![1] as string

      const follow = await h.ctx.tools.execute({
        signal: testToolSignal,
        callId: CallId('follow-1'),
        name: 'send_message',
        arguments: { subagent_id: childId, message: 'and then?' },
        agent: h.parent,
      })
      expect(follow.isError).toBe(false)
      expect(text(follow)).toBe(`message queued as the next turn for subagent ${childId}`)

      await waitNoActivation(h.ctx, childId)
      const loaded = await h.ctx.sessionPersistence.load(SessionId(childId))
      const prompts = loaded.events.flatMap(event =>
        event.type === 'user/message' && event.data.source.kind !== 'plugin'
          ? event.data.content.flatMap(block => block.type === 'text' ? [block.text] : [])
          : [])
      // Both turns reached the same durable child conversation.
      expect(prompts).toEqual(['dig in', 'and then?'])
    } finally {
      await h.ctx.fiber.dispose()
      h.cleanup()
    }
  })

  it('cold-resumes a settled child and keeps the creation-time provider/model', async () => {
    const h = await bootHarness({ script: [textResponse('first'), textResponse('resumed')] })
    try {
      await mountTool(h)
      const started = await callStart(h.ctx, {
        description: 'cold work',
        prompt: 'initial task',
        provider: 'mock',
        model: 'mock',
      }, { agent: h.parent })
      const childId = /started subagent (\S+)/.exec(text(started))![1] as string
      await waitNoActivation(h.ctx, childId)

      const follow = await h.ctx.tools.execute({
        signal: testToolSignal,
        callId: CallId('cold-1'),
        name: 'send_message',
        arguments: { subagent_id: childId, message: 'resume me' },
        agent: h.parent,
      })
      expect(follow.isError).toBe(false)

      await waitNoActivation(h.ctx, childId)
      const descriptor = await loadDescriptor(h.ctx, childId)
      expect(descriptor).toMatchObject({
        mode: 'continuable',
        provider: 'spawn',
        agentProvider: 'mock',
        agentModel: 'mock',
      })
    } finally {
      await h.ctx.fiber.dispose()
      h.cleanup()
    }
  })

  it('cancels before initial inbox acceptance and leaves no child behind', async () => {
    const h = await bootHarness()
    try {
      await mountTool(h)
      const controller = new AbortController()
      const pending = callStart(h.ctx, {
        description: 'cancel me',
        prompt: 'long running',
        provider: 'mock',
        model: 'mock',
      }, { agent: h.parent, signal: controller.signal })
      // Abort before the child accepts: the tool call must reject and roll back.
      controller.abort()
      const result = await pending
      expect(result.isError).toBe(true)
    } finally {
      await h.ctx.fiber.dispose()
      h.cleanup()
    }
  })

  it('fails loud without a calling agent and creates no child', async () => {
    const h = await bootHarness()
    try {
      await mountTool(h)
      const result = await callStart(h.ctx, {
        description: 'no parent',
        prompt: 'x',
        provider: 'mock',
        model: 'mock',
      })
      expect(result.isError).toBe(true)
      expect(text(result)).toContain('requires a live parent agent')
    } finally {
      await h.ctx.fiber.dispose()
      h.cleanup()
    }
  })

  it('forwards persona into the child system prompt and applies toolFilter to its schema', async () => {
    const h = await bootHarness({ script: [textResponse('with persona')] })
    try {
      await mountTool(h, {
        persona: 'You are an independent code reviewer.',
        toolFilter: { deny: ['send_message'] },
      })
      const result = await callStart(h.ctx, {
        description: 'review',
        prompt: 'review the diff',
        provider: 'mock',
        model: 'mock',
      }, { agent: h.parent })
      expect(result.isError).toBe(false)
      await waitNoActivation(h.ctx, /started subagent (\S+)/.exec(text(result))![1] as string)

      const childRequest = h.adapter.requests[0]
      expect(childRequest).toBeDefined()
      if (childRequest === undefined) throw new Error('expected a child model request')
      expect(childRequest.system).toContain('You are an independent code reviewer.')
      // The child's tool schema excludes the denied tool.
      const names = childRequest.tools?.map(t => t.name) ?? []
      expect(names).not.toContain('send_message')
    } finally {
      await h.ctx.fiber.dispose()
      h.cleanup()
    }
  })

  it('classifies subagent_route calls as concurrency-safe (sibling delegations overlap)', async () => {
    const h = await bootHarness()
    try {
      await mountTool(h)
      const mode = h.ctx.tools.executionMode({
        signal: testToolSignal,
        callId: CallId('concurrency-check'),
        name: 'subagent_route',
        arguments: { description: 'd', prompt: 'p', provider: 'mock', model: 'mock' },
        agent: h.parent,
      })
      expect(mode).toEqual({ kind: 'parallel' })
    } finally {
      await h.ctx.fiber.dispose()
      h.cleanup()
    }
  })
})

describe('execution: one-shot mode', () => {
  it('returns the child final output for a one-shot fork run', async () => {
    const h = await bootHarness({ withFork: true, script: [textResponse('fork child output')] })
    try {
      await h.ctx.plugin(tool, { backgroundMode: 'one-shot', subagentProvider: 'fork', toolName: 'subagent_fork_route' })
      const result = await callStart(h.ctx, {
        description: 'fork task',
        prompt: 'analyze the completed turns',
        provider: 'mock',
        model: 'mock',
      }, { agent: h.parent, name: 'subagent_fork_route' })
      expect(result.isError).toBe(false)
      expect(result.value).toMatchObject({
        kind: 'foreground',
        runId: expect.any(String),
        output: [{ type: 'text', text: 'fork child output' }],
      })
      expect(text(result)).toBe('fork child output')
    } finally {
      await h.ctx.fiber.dispose()
      h.cleanup()
    }
  })

  it('maps a non-completed stop reason to an errored result with partial output', async () => {
    const h = await bootHarness({ withFork: true })
    try {
      await h.ctx.plugin(tool, { backgroundMode: 'one-shot', subagentProvider: 'fork', toolName: 'subagent_fork_route' })
      // No script entry: the child's model call fails, which settles the run
      // with stopReason error and no output.
      const result = await callStart(h.ctx, {
        description: 'failing task',
        prompt: 'do something',
        provider: 'mock',
        model: 'mock',
      }, { agent: h.parent, name: 'subagent_fork_route' })
      expect(result.isError).toBe(true)
      expect(text(result)).toContain('subagent run failed')
    } finally {
      await h.ctx.fiber.dispose()
      h.cleanup()
    }
  })

  it.each([
    { stopReason: 'aborted' as const, fragment: 'cancelled' },
    { stopReason: 'error' as const, fragment: 'failed' },
    { stopReason: 'max-tokens' as const, fragment: 'token limit' },
    { stopReason: 'refusal' as const, fragment: 'declined' },
    { stopReason: 'frobnicated' as const, fragment: 'abnormally' },
  ])('maps stop reason $stopReason to an isError result with partial text', async ({ stopReason, fragment }) => {
    const ctx = new Context()
    try {
      const { mountAgentLoopTestDependencies } = await import('@deepseek-ai/dsh-agent-loop-testkit')
      await mountAgentLoopTestDependencies(ctx)
      const SubagentRuntime = (await import('@deepseek-ai/dsh-subagent')).default
      await ctx.plugin(SubagentRuntime)
      const { mountScriptedOneShotProvider } = await import('./harness.ts')
      mountScriptedOneShotProvider(ctx, { name: 'scripted', reply: 'partial answer', stopReason })
      await ctx.plugin(tool, { backgroundMode: 'one-shot', subagentProvider: 'scripted', toolName: 'subagent_fork_route', maxDepth: 'provider-managed' })

      const result = await ctx.tools.execute({
        signal: testToolSignal,
        callId: CallId('stop-reason'),
        name: 'subagent_fork_route',
        arguments: { description: 'd', prompt: 'p', provider: 'mock', model: 'mock' },
        agent: { id: SessionId('parent') } as never,
      })
      expect(result.isError).toBe(true)
      expect(text(result)).toContain(fragment)
      // The preserved partial answer still reaches the parent model.
      expect(text(result)).toContain('partial answer')
    } finally {
      await ctx.fiber.dispose()
    }
  })

  it('preserves both diagnostics when result and dispose both fail', async () => {
    const ctx = new Context()
    try {
      const { mountAgentLoopTestDependencies } = await import('@deepseek-ai/dsh-agent-loop-testkit')
      await mountAgentLoopTestDependencies(ctx)
      const SubagentRuntime = (await import('@deepseek-ai/dsh-subagent')).default
      await ctx.plugin(SubagentRuntime)
      const { mountScriptedOneShotProvider } = await import('./harness.ts')
      mountScriptedOneShotProvider(ctx, { name: 'double-fail', stopReason: 'error', disposeFails: true })
      await ctx.plugin(tool, { backgroundMode: 'one-shot', subagentProvider: 'double-fail', toolName: 'subagent_fork_route', maxDepth: 'provider-managed' })

      const result = await ctx.tools.execute({
        signal: testToolSignal,
        callId: CallId('double-fail'),
        name: 'subagent_fork_route',
        arguments: { description: 'd', prompt: 'p', provider: 'mock', model: 'mock' },
        agent: { id: SessionId('parent') } as never,
      })
      expect(result.isError).toBe(true)
      expect(text(result)).toContain('dispose failed')
    } finally {
      await ctx.fiber.dispose()
    }
  })

  it('surfaces a disposal failure even when the child result succeeded', async () => {
    const ctx = new Context()
    try {
      const { mountAgentLoopTestDependencies } = await import('@deepseek-ai/dsh-agent-loop-testkit')
      await mountAgentLoopTestDependencies(ctx)
      const SubagentRuntime = (await import('@deepseek-ai/dsh-subagent')).default
      await ctx.plugin(SubagentRuntime)
      const { mountScriptedOneShotProvider } = await import('./harness.ts')
      mountScriptedOneShotProvider(ctx, { name: 'dispose-only-fail', reply: 'good output', disposeFails: true })
      await ctx.plugin(tool, { backgroundMode: 'one-shot', subagentProvider: 'dispose-only-fail', toolName: 'subagent_fork_route', maxDepth: 'provider-managed' })

      const result = await ctx.tools.execute({
        signal: testToolSignal,
        callId: CallId('dispose-only-fail'),
        name: 'subagent_fork_route',
        arguments: { description: 'd', prompt: 'p', provider: 'mock', model: 'mock' },
        agent: { id: SessionId('parent') } as never,
      })
      expect(result.isError).toBe(true)
      expect(text(result)).toContain('dispose failed')
    } finally {
      await ctx.fiber.dispose()
    }
  })

  it('does not append partial text when the child produced no output', async () => {
    const ctx = new Context()
    try {
      const { mountAgentLoopTestDependencies } = await import('@deepseek-ai/dsh-agent-loop-testkit')
      await mountAgentLoopTestDependencies(ctx)
      const SubagentRuntime = (await import('@deepseek-ai/dsh-subagent')).default
      await ctx.plugin(SubagentRuntime)
      const { mountScriptedOneShotProvider } = await import('./harness.ts')
      mountScriptedOneShotProvider(ctx, { name: 'no-output', stopReason: 'refusal' })
      await ctx.plugin(tool, { backgroundMode: 'one-shot', subagentProvider: 'no-output', toolName: 'subagent_fork_route', maxDepth: 'provider-managed' })

      const result = await ctx.tools.execute({
        signal: testToolSignal,
        callId: CallId('no-output'),
        name: 'subagent_fork_route',
        arguments: { description: 'd', prompt: 'p', provider: 'mock', model: 'mock' },
        agent: { id: SessionId('parent') } as never,
      })
      expect(result.isError).toBe(true)
      expect(text(result)).toContain('declined')
      expect(text(result)).not.toContain('Partial output')
    } finally {
      await ctx.fiber.dispose()
    }
  })

  it('appends the provider-authored diagnostic to a stop-reason error', async () => {
    const ctx = new Context()
    try {
      const { mountAgentLoopTestDependencies } = await import('@deepseek-ai/dsh-agent-loop-testkit')
      await mountAgentLoopTestDependencies(ctx)
      const SubagentRuntime = (await import('@deepseek-ai/dsh-subagent')).default
      await ctx.plugin(SubagentRuntime)
      const { mountScriptedOneShotProvider } = await import('./harness.ts')
      mountScriptedOneShotProvider(ctx, {
        name: 'with-diagnostic',
        reply: 'partial answer',
        stopReason: 'error',
        diagnostic: 'provider connection reset',
      })
      await ctx.plugin(tool, { backgroundMode: 'one-shot', subagentProvider: 'with-diagnostic', toolName: 'subagent_fork_route', maxDepth: 'provider-managed' })

      const result = await ctx.tools.execute({
        signal: testToolSignal,
        callId: CallId('with-diagnostic'),
        name: 'subagent_fork_route',
        arguments: { description: 'd', prompt: 'p', provider: 'mock', model: 'mock' },
        agent: { id: SessionId('parent') } as never,
      })
      expect(result.isError).toBe(true)
      expect(text(result)).toContain('subagent run failed')
      expect(text(result)).toContain('Diagnostic: provider connection reset')
      expect(text(result)).toContain('partial answer')
    } finally {
      await ctx.fiber.dispose()
    }
  })
})

describe('execution: scheduling matrix (run_in_background)', () => {
  it('continuable + run_in_background: false waits and returns the final output (foreground)', async () => {
    const h = await bootHarness({ script: [textResponse('sync answer')] })
    try {
      await mountTool(h)
      const result = await callStart(h.ctx, {
        description: 'sync task',
        prompt: 'answer now',
        provider: 'mock',
        model: 'mock',
        run_in_background: false,
      }, { agent: h.parent })
      expect(result.isError).toBe(false)
      expect(result.value).toMatchObject({
        kind: 'foreground',
        runId: expect.any(String),
        output: [{ type: 'text', text: 'sync answer' }],
      })
      expect(text(result)).toBe('sync answer')
      // The foreground child is a one-shot run, not a continuable child:
      // the official discovery tool does not list it.
      const runId = (result.value as { runId: string }).runId
      const listing = await h.ctx.tools.execute({
        signal: testToolSignal,
        callId: CallId('sync-list'),
        name: 'list_agents',
        arguments: {},
        agent: h.parent,
      })
      expect(listing.isError).toBe(false)
      expect(text(listing)).not.toContain(runId)
    } finally {
      await h.ctx.fiber.dispose()
      h.cleanup()
    }
  })

  it('continuable + run_in_background: true returns the durable subagent id (same as omitted)', async () => {
    const h = await bootHarness({ script: [textResponse('bg answer')] })
    try {
      await mountTool(h)
      const result = await callStart(h.ctx, {
        description: 'bg task',
        prompt: 'work in background',
        provider: 'mock',
        model: 'mock',
        run_in_background: true,
      }, { agent: h.parent })
      expect(result.isError).toBe(false)
      expect(result.value).toMatchObject({ kind: 'continuable', subagentId: expect.any(String) })
      expect(text(result)).toMatch(/^started subagent \S+$/)
    } finally {
      await h.ctx.fiber.dispose()
      h.cleanup()
    }
  })

  it('one-shot + run_in_background: false waits and returns the final output', async () => {
    const h = await bootHarness({ withFork: true, script: [textResponse('fork sync answer')] })
    try {
      await h.ctx.plugin(tool, { backgroundMode: 'one-shot', subagentProvider: 'fork', toolName: 'subagent_fork_route' })
      const result = await callStart(h.ctx, {
        description: 'fork sync',
        prompt: 'analyze',
        provider: 'mock',
        model: 'mock',
        run_in_background: false,
      }, { agent: h.parent, name: 'subagent_fork_route' })
      expect(result.isError).toBe(false)
      expect(result.value).toMatchObject({ kind: 'foreground', runId: expect.any(String) })
      expect(text(result)).toBe('fork sync answer')
    } finally {
      await h.ctx.fiber.dispose()
      h.cleanup()
    }
  })

  it('one-shot + run_in_background: true registers a background job and returns its id', async () => {
    const h = await bootHarness({ withFork: true, withJobs: true, script: [textResponse('job answer')] })
    try {
      await h.ctx.plugin(tool, { backgroundMode: 'one-shot', subagentProvider: 'fork', toolName: 'subagent_fork_route' })
      const result = await callStart(h.ctx, {
        description: 'fork job',
        prompt: 'work in background',
        provider: 'mock',
        model: 'mock',
        run_in_background: true,
      }, { agent: h.parent, name: 'subagent_fork_route' })
      expect(result.isError).toBe(false)
      expect(result.value).toMatchObject({ kind: 'background', jobId: expect.any(String) })
      const jobId = (result.value as { jobId: string }).jobId
      expect(jobId).toMatch(/^subagent-\d+$/)
      expect(text(result)).toBe(`started background subagent job ${jobId}`)
    } finally {
      await h.ctx.fiber.dispose()
      h.cleanup()
    }
  })

  it('enableRunInBackground: false rejects a forged run_in_background: true in execute', async () => {
    const h = await bootHarness({ script: [textResponse('foreground only')] })
    try {
      await mountTool(h, { enableRunInBackground: false })
      const result = await callStart(h.ctx, {
        description: 'forged',
        prompt: 'x',
        provider: 'mock',
        model: 'mock',
        run_in_background: true,
      }, { agent: h.parent })
      expect(result.isError).toBe(true)
      expect(text(result)).toContain('run_in_background is disabled for this tool instance')
      // No child work happened.
      expect(h.adapter.requests).toHaveLength(0)
    } finally {
      await h.ctx.fiber.dispose()
      h.cleanup()
    }
  })

  it('enableRunInBackground: false still runs every call in the foreground', async () => {
    const h = await bootHarness({ script: [textResponse('foreground answer')] })
    try {
      await mountTool(h, { enableRunInBackground: false })
      const result = await callStart(h.ctx, {
        description: 'foreground',
        prompt: 'answer',
        provider: 'mock',
        model: 'mock',
      }, { agent: h.parent })
      expect(result.isError).toBe(false)
      expect(result.value).toMatchObject({ kind: 'foreground', runId: expect.any(String) })
      expect(text(result)).toBe('foreground answer')
    } finally {
      await h.ctx.fiber.dispose()
      h.cleanup()
    }
  })

  it('fails loud when a background one-shot call finds no jobs service', async () => {
    const h = await bootHarness({ withFork: true })
    try {
      await h.ctx.plugin(tool, { backgroundMode: 'one-shot', subagentProvider: 'fork', toolName: 'subagent_fork_route' })
      const result = await callStart(h.ctx, {
        description: 'no jobs',
        prompt: 'x',
        provider: 'mock',
        model: 'mock',
        run_in_background: true,
      }, { agent: h.parent, name: 'subagent_fork_route' })
      expect(result.isError).toBe(true)
      expect(text(result)).toContain('background jobs unavailable')
    } finally {
      await h.ctx.fiber.dispose()
      h.cleanup()
    }
  })
})

describe('background one-shot jobs', () => {
  it('collects the child output with job_output after settlement', async () => {
    const h = await bootHarness({ withFork: true, withJobs: true, script: [textResponse('job answer')] })
    try {
      await h.ctx.plugin(tool, { backgroundMode: 'one-shot', subagentProvider: 'fork', toolName: 'subagent_fork_route' })
      const started = await callStart(h.ctx, {
        description: 'fork job',
        prompt: 'work in background',
        provider: 'mock',
        model: 'mock',
        run_in_background: true,
      }, { agent: h.parent, name: 'subagent_fork_route' })
      const jobId = (started.value as { jobId: string }).jobId

      const read = await h.ctx.tools.execute({
        signal: testToolSignal,
        callId: CallId('job-read-1'),
        name: 'job_output',
        arguments: { job_id: jobId, wait: true, timeout_ms: 5_000 },
        agent: h.parent,
      })
      expect(read.isError).toBe(false)
      expect(text(read)).toContain('job answer')
      expect(text(read)).toContain('[status: completed]')
    } finally {
      await h.ctx.fiber.dispose()
      h.cleanup()
    }
  })

  it('settles a failing child as a failed job', async () => {
    const ctx = new Context()
    try {
      const { mountAgentLoopTestDependencies } = await import('@deepseek-ai/dsh-agent-loop-testkit')
      await mountAgentLoopTestDependencies(ctx)
      const AgentLoop = (await import('@deepseek-ai/dsh-agent-loop')).default
      await ctx.plugin(AgentLoop, { agents: [] })
      const SubagentRuntime = (await import('@deepseek-ai/dsh-subagent')).default
      await ctx.plugin(SubagentRuntime)
      const LocalJobRegistry = (await import('@deepseek-ai/dsh-jobs-local')).default
      await ctx.plugin(LocalJobRegistry)
      const toolJobs = await import('@deepseek-ai/dsh-tool-jobs')
      await ctx.plugin(toolJobs)
      const { mountScriptedOneShotProvider } = await import('./harness.ts')
      mountScriptedOneShotProvider(ctx, { name: 'failing-job', stopReason: 'error' })
      await ctx.plugin(tool, { backgroundMode: 'one-shot', subagentProvider: 'failing-job', toolName: 'subagent_fork_route', maxDepth: 'provider-managed' })

      const parent = ctx.agentLoop.create(SessionId('job-parent'), { provider: 'mock', model: 'mock' })
      const started = await ctx.tools.execute({
        signal: testToolSignal,
        callId: CallId('job-fail-start'),
        name: 'subagent_fork_route',
        arguments: { description: 'd', prompt: 'p', provider: 'mock', model: 'mock', run_in_background: true },
        agent: parent,
      })
      expect(started.isError).toBe(false)
      const jobId = (started.value as { jobId: string }).jobId

      const read = await ctx.tools.execute({
        signal: testToolSignal,
        callId: CallId('job-fail-read'),
        name: 'job_output',
        arguments: { job_id: jobId, wait: true, timeout_ms: 5_000 },
        agent: parent,
      })
      expect(read.isError).toBe(false)
      expect(text(read)).toContain('[status: failed')
    } finally {
      await ctx.fiber.dispose()
    }
  })

  it('job_kill aborts the child and settles the job as killed', async () => {
    const h = await bootHarness({ withFork: true, withJobs: true, script: ['hang'] })
    try {
      await h.ctx.plugin(tool, { backgroundMode: 'one-shot', subagentProvider: 'fork', toolName: 'subagent_fork_route' })
      const started = await callStart(h.ctx, {
        description: 'kill me',
        prompt: 'hang forever',
        provider: 'mock',
        model: 'mock',
        run_in_background: true,
      }, { agent: h.parent, name: 'subagent_fork_route' })
      const jobId = (started.value as { jobId: string }).jobId

      // The child is in flight (hanging on the adapter) before the kill.
      await vi.waitFor(() => {
        expect(h.adapter.requests.length).toBe(1)
      }, { timeout: 5_000 })

      const killed = await h.ctx.tools.execute({
        signal: testToolSignal,
        callId: CallId('job-kill-1'),
        name: 'job_kill',
        arguments: { job_id: jobId, reason: 'test kill' },
        agent: h.parent,
      })
      expect(killed.isError).toBe(false)
      expect(text(killed)).toContain('cancellation')

      const read = await h.ctx.tools.execute({
        signal: testToolSignal,
        callId: CallId('job-kill-read'),
        name: 'job_output',
        arguments: { job_id: jobId, wait: true, timeout_ms: 5_000 },
        agent: h.parent,
      })
      expect(read.isError).toBe(false)
      expect(text(read)).toContain('[status: killed]')
    } finally {
      await h.ctx.fiber.dispose()
      h.cleanup()
    }
  })

  it('maps a startup rejection to a killed job when the task signal aborted', async () => {
    const ctx = new Context()
    try {
      const { mountAgentLoopTestDependencies } = await import('@deepseek-ai/dsh-agent-loop-testkit')
      await mountAgentLoopTestDependencies(ctx)
      const AgentLoop = (await import('@deepseek-ai/dsh-agent-loop')).default
      await ctx.plugin(AgentLoop, { agents: [] })
      const SubagentRuntime = (await import('@deepseek-ai/dsh-subagent')).default
      await ctx.plugin(SubagentRuntime)
      const LocalJobRegistry = (await import('@deepseek-ai/dsh-jobs-local')).default
      await ctx.plugin(LocalJobRegistry)
      const toolJobs = await import('@deepseek-ai/dsh-tool-jobs')
      await ctx.plugin(toolJobs)
      // A provider whose start() rejects when the task-owned signal fires:
      // the startup-cancellation path of the background task.
      ctx.subagents.registerProvider({
        name: 'abort-start',
        capabilities: { outputSchema: false, depthLimit: true, toolFilter: true, persona: true },
        inheritsParentContext: false,
        start: async (request) => {
          await new Promise<void>((_resolve, reject) => {
            if (request.signal.aborted) { reject(new Error('aborted')); return }
            request.signal.addEventListener('abort', () => reject(new Error('aborted')), { once: true })
          })
          throw new Error('unreachable')
        },
      })
      await ctx.plugin(tool, { backgroundMode: 'one-shot', subagentProvider: 'abort-start', toolName: 'subagent_fork_route', maxDepth: 'provider-managed' })

      const parent = ctx.agentLoop.create(SessionId('job-parent-kill'), { provider: 'mock', model: 'mock' })
      const started = await ctx.tools.execute({
        signal: testToolSignal,
        callId: CallId('job-kill-start'),
        name: 'subagent_fork_route',
        arguments: { description: 'd', prompt: 'p', provider: 'mock', model: 'mock', run_in_background: true },
        agent: parent,
      })
      expect(started.isError).toBe(false)
      const jobId = (started.value as { jobId: string }).jobId

      const killed = await ctx.tools.execute({
        signal: testToolSignal,
        callId: CallId('job-kill-2'),
        name: 'job_kill',
        arguments: { job_id: jobId },
        agent: parent,
      })
      expect(killed.isError).toBe(false)

      const read = await ctx.tools.execute({
        signal: testToolSignal,
        callId: CallId('job-kill-read-2'),
        name: 'job_output',
        arguments: { job_id: jobId, wait: true, timeout_ms: 5_000 },
        agent: parent,
      })
      expect(read.isError).toBe(false)
      expect(text(read)).toContain('[status: killed]')
    } finally {
      await ctx.fiber.dispose()
    }
  })

  it('maps a startup rejection to a failed job when no cancellation happened', async () => {
    const ctx = new Context()
    try {
      const { mountAgentLoopTestDependencies } = await import('@deepseek-ai/dsh-agent-loop-testkit')
      await mountAgentLoopTestDependencies(ctx)
      const AgentLoop = (await import('@deepseek-ai/dsh-agent-loop')).default
      await ctx.plugin(AgentLoop, { agents: [] })
      const SubagentRuntime = (await import('@deepseek-ai/dsh-subagent')).default
      await ctx.plugin(SubagentRuntime)
      const LocalJobRegistry = (await import('@deepseek-ai/dsh-jobs-local')).default
      await ctx.plugin(LocalJobRegistry)
      const toolJobs = await import('@deepseek-ai/dsh-tool-jobs')
      await ctx.plugin(toolJobs)
      // A provider whose start() rejects immediately: the startup-failure
      // path of the background task (no cancellation involved).
      ctx.subagents.registerProvider({
        name: 'explode-start',
        capabilities: { outputSchema: false, depthLimit: true, toolFilter: true, persona: true },
        inheritsParentContext: false,
        start: async () => { throw new Error('startup exploded') },
      })
      await ctx.plugin(tool, { backgroundMode: 'one-shot', subagentProvider: 'explode-start', toolName: 'subagent_fork_route', maxDepth: 'provider-managed' })

      const parent = ctx.agentLoop.create(SessionId('job-parent-fail'), { provider: 'mock', model: 'mock' })
      const started = await ctx.tools.execute({
        signal: testToolSignal,
        callId: CallId('job-fail-start-2'),
        name: 'subagent_fork_route',
        arguments: { description: 'd', prompt: 'p', provider: 'mock', model: 'mock', run_in_background: true },
        agent: parent,
      })
      expect(started.isError).toBe(false)
      const jobId = (started.value as { jobId: string }).jobId

      const read = await ctx.tools.execute({
        signal: testToolSignal,
        callId: CallId('job-fail-read-2'),
        name: 'job_output',
        arguments: { job_id: jobId, wait: true, timeout_ms: 5_000 },
        agent: parent,
      })
      expect(read.isError).toBe(false)
      expect(text(read)).toContain('[status: failed')
      expect(text(read)).toContain('startup exploded')
    } finally {
      await ctx.fiber.dispose()
    }
  })

  it('enforces allowedProviders before any job is created on the background path', async () => {
    const h = await bootHarness({ withFork: true, withJobs: true })
    try {
      await h.ctx.plugin(tool, {
        backgroundMode: 'one-shot',
        subagentProvider: 'fork',
        toolName: 'subagent_fork_route',
        allowedProviders: ['allowed'],
      })
      const result = await callStart(h.ctx, {
        description: 'denied job',
        prompt: 'x',
        provider: 'denied',
        model: 'mock',
        run_in_background: true,
      }, { agent: h.parent, name: 'subagent_fork_route' })
      expect(result.isError).toBe(true)
      expect(text(result)).toContain('"denied" is not allowed')
      // No job was registered.
      const listing = await h.ctx.tools.execute({
        signal: testToolSignal,
        callId: CallId('job-denied-list'),
        name: 'job_list',
        arguments: {},
        agent: h.parent,
      })
      expect(listing.isError).toBe(false)
      expect(text(listing)).toBe('(no background jobs)')
    } finally {
      await h.ctx.fiber.dispose()
      h.cleanup()
    }
  })
})

describe('system prompt guidance', () => {
  it('continuable + background contributes a tool:<name> section telling the model to delegate in the background by default', async () => {
    const h = await bootHarness()
    try {
      await mountTool(h)
      const assembly = await h.ctx.systemPrompt.assemble()
      const section = assembly.sections.find(s => s.name === 'tool:subagent_route')
      expect(section).toBeDefined()
      expect(section!.text).toContain('Use subagent_route in the background by default')
      expect(section!.text).toContain('run_in_background: false')
    } finally {
      await h.ctx.fiber.dispose()
      h.cleanup()
    }
  })

  it('one-shot mode contributes no system-prompt section', async () => {
    const h = await bootHarness({ withFork: true })
    try {
      await h.ctx.plugin(tool, { backgroundMode: 'one-shot', subagentProvider: 'fork', toolName: 'subagent_fork_route' })
      const assembly = await h.ctx.systemPrompt.assemble()
      expect(assembly.sections.some(s => s.name === 'tool:subagent_fork_route')).toBe(false)
    } finally {
      await h.ctx.fiber.dispose()
      h.cleanup()
    }
  })

  it('enableRunInBackground: false contributes no system-prompt section', async () => {
    const h = await bootHarness()
    try {
      await mountTool(h, { enableRunInBackground: false })
      const assembly = await h.ctx.systemPrompt.assemble()
      expect(assembly.sections.some(s => s.name === 'tool:subagent_route')).toBe(false)
    } finally {
      await h.ctx.fiber.dispose()
      h.cleanup()
    }
  })

  it('renders empty while the provider is absent, and follows provider HMR (appears, then disappears)', async () => {
    const ctx = new Context()
    try {
      const { mountAgentLoopTestDependencies } = await import('@deepseek-ai/dsh-agent-loop-testkit')
      await mountAgentLoopTestDependencies(ctx)
      const SubagentRuntime = (await import('@deepseek-ai/dsh-subagent')).default
      await ctx.plugin(SubagentRuntime)
      const SubagentSpawn = await import('@deepseek-ai/dsh-subagent-spawn-in-process')

      // Provider absent: the section exists but renders empty.
      tool.apply(ctx, { subagentProvider: 'guidance-spawn' })
      let assembly = await ctx.systemPrompt.assemble()
      let section = assembly.sections.find(s => s.name === 'tool:subagent_route')
      expect(section).toBeDefined()
      expect(section!.text).toBe('')

      // Provider appears: the tool registers and the guidance renders.
      const providerFiber = await ctx.plugin(SubagentSpawn, { providerName: 'guidance-spawn' })
      assembly = await ctx.systemPrompt.assemble()
      section = assembly.sections.find(s => s.name === 'tool:subagent_route')
      expect(section!.text).toContain('background by default')

      // Provider removed: the tool unregisters and the guidance goes empty
      // again (no stale HMR guidance).
      await providerFiber.dispose()
      assembly = await ctx.systemPrompt.assemble()
      section = assembly.sections.find(s => s.name === 'tool:subagent_route')
      expect(section!.text).toBe('')
    } finally {
      await ctx.fiber.dispose()
    }
  })
})

describe('allowedProviders policy', () => {
  it('rejects a provider outside the allowlist before any child work', async () => {
    const h = await bootHarness()
    try {
      await mountTool(h, { allowedProviders: ['allowed'] })
      const result = await callStart(h.ctx, {
        description: 'denied',
        prompt: 'x',
        provider: 'denied',
        model: 'mock',
      }, { agent: h.parent })
      expect(result.isError).toBe(true)
      expect(text(result)).toContain('"denied" is not allowed')
      // No child session, no descriptor, no accepted message.
      expect(h.adapter.requests).toHaveLength(0)
    } finally {
      await h.ctx.fiber.dispose()
      h.cleanup()
    }
  })

  it('accepts a provider on the allowlist', async () => {
    const h = await bootHarness({ script: [textResponse('ok')] })
    try {
      await mountTool(h, { allowedProviders: ['mock'] })
      const result = await callStart(h.ctx, {
        description: 'allowed',
        prompt: 'go',
        provider: 'mock',
        model: 'mock',
      }, { agent: h.parent })
      expect(result.isError).toBe(false)
    } finally {
      await h.ctx.fiber.dispose()
      h.cleanup()
    }
  })

  it('treats an explicit empty allowlist as deny-all', async () => {
    const h = await bootHarness()
    try {
      await mountTool(h, { allowedProviders: [] })
      const result = await callStart(h.ctx, {
        description: 'denied all',
        prompt: 'x',
        provider: 'mock',
        model: 'mock',
      }, { agent: h.parent })
      expect(result.isError).toBe(true)
      expect(text(result)).toContain('not allowed')
    } finally {
      await h.ctx.fiber.dispose()
      h.cleanup()
    }
  })
})

describe('toolName collision defense', () => {
  it('fails loud at mount when the tool name is already registered, leaving the existing tool untouched', async () => {
    const ctx = new Context()
    try {
      const { mountAgentLoopTestDependencies } = await import('@deepseek-ai/dsh-agent-loop-testkit')
      await mountAgentLoopTestDependencies(ctx)
      const SubagentRuntime = (await import('@deepseek-ai/dsh-subagent')).default
      await ctx.plugin(SubagentRuntime)
      const SubagentSpawn = await import('@deepseek-ai/dsh-subagent-spawn-in-process')
      await ctx.plugin(SubagentSpawn, { providerName: 'spawn' })

      // Another plugin already owns the target name.
      ctx.tools.register({
        name: 'occupied',
        description: 'someone else',
        parameters: {},
        output: {
          schema: { type: 'string' },
          render: (_args, value) => [{ type: 'text', text: String(value) }],
        },
        execute: async () => 'other',
      })

      await expect(ctx.plugin(tool, {
        executionMode: 'continuable',
        subagentProvider: 'spawn',
        toolName: 'occupied',
      })).rejects.toThrow(/already registered/)
      // The existing tool survives untouched.
      expect(ctx.tools.schemas().filter(s => s.name === 'occupied')).toHaveLength(1)
      expect(ctx.tools.schemas().some(s => s.name === 'occupied')).toBe(true)
    } finally {
      await ctx.fiber.dispose()
    }
  })

  it('gives DSH official subagent/control names a dedicated diagnostic', async () => {
    const ctx = new Context()
    try {
      const { mountAgentLoopTestDependencies } = await import('@deepseek-ai/dsh-agent-loop-testkit')
      await mountAgentLoopTestDependencies(ctx)
      const SubagentRuntime = (await import('@deepseek-ai/dsh-subagent')).default
      await ctx.plugin(SubagentRuntime)
      const SubagentSpawn = await import('@deepseek-ai/dsh-subagent-spawn-in-process')
      await ctx.plugin(SubagentSpawn, { providerName: 'spawn' })

      for (const official of ['subagent', 'subagent_fork', 'send_message', 'interrupt_agent', 'list_agents']) {
        // Occupy the official name with a placeholder, as a deployment with
        // the official tool would; the router must then fail loud with the
        // dedicated diagnostic.
        ctx.tools.register({
          name: official,
          description: 'official placeholder',
          parameters: {},
          output: {
            schema: { type: 'string' },
            render: (_args, value) => [{ type: 'text', text: String(value) }],
          },
          execute: async () => 'official',
        })
        await expect(ctx.plugin(tool, {
          executionMode: 'continuable',
          subagentProvider: 'spawn',
          toolName: official,
        })).rejects.toThrow(/conflicts with a DSH built-in subagent\/control tool/)
        // The placeholder survives untouched (no shadowing, no replacement).
        expect(ctx.tools.schemas().filter(s => s.name === official)).toHaveLength(1)
      }
    } finally {
      await ctx.fiber.dispose()
    }
  })

  it('fails loud on the late-provider path when another tool took the target name (router waits, then collides)', async () => {
    const ctx = new Context()
    try {
      const { mountAgentLoopTestDependencies } = await import('@deepseek-ai/dsh-agent-loop-testkit')
      await mountAgentLoopTestDependencies(ctx)
      const SubagentRuntime = (await import('@deepseek-ai/dsh-subagent')).default
      await ctx.plugin(SubagentRuntime)
      // Router first: provider absent, so the router waits.
      await ctx.plugin(tool, {
        executionMode: 'continuable',
        subagentProvider: 'late-collision-spawn',
        toolName: 'late_target',
      })
      expect(ctx.tools.schemas().some(s => s.name === 'late_target')).toBe(false)

      // Another plugin takes the target name while the router waits.
      ctx.tools.register({
        name: 'late_target',
        description: 'occupier',
        parameters: {},
        output: {
          schema: { type: 'string' },
          render: (_args, value) => [{ type: 'text', text: String(value) }],
        },
        execute: async () => 'occupied',
      })
      expect(ctx.tools.schemas().some(s => s.name === 'late_target')).toBe(true)

      // The provider appears: the event-driven mount must fail loud and leave
      // the existing tool untouched.
      const SubagentSpawn = await import('@deepseek-ai/dsh-subagent-spawn-in-process')
      await expect(ctx.plugin(SubagentSpawn, { providerName: 'late-collision-spawn' }))
        .rejects.toThrow(/already registered/)
      expect(ctx.tools.schemas().filter(s => s.name === 'late_target')).toHaveLength(1)
      expect(ctx.tools.schemas().some(s => s.name === 'subagent_route')).toBe(false)
    } finally {
      await ctx.fiber.dispose()
    }
  })

  it('fails loud on the late-provider path when the target name is a DSH official name', async () => {
    const ctx = new Context()
    try {
      const { mountAgentLoopTestDependencies } = await import('@deepseek-ai/dsh-agent-loop-testkit')
      await mountAgentLoopTestDependencies(ctx)
      const SubagentRuntime = (await import('@deepseek-ai/dsh-subagent')).default
      await ctx.plugin(SubagentRuntime)
      // Router first, waiting for the provider, with an official target name.
      await ctx.plugin(tool, {
        executionMode: 'continuable',
        subagentProvider: 'late-official-spawn',
        toolName: 'subagent',
      })
      expect(ctx.tools.schemas().some(s => s.name === 'subagent')).toBe(false)

      // While the router waits, the official `subagent` tool is mounted by
      // the deployment — the real collision scenario.
      ctx.tools.register({
        name: 'subagent',
        description: 'official placeholder',
        parameters: {},
        output: {
          schema: { type: 'string' },
          render: (_args, value) => [{ type: 'text', text: String(value) }],
        },
        execute: async () => 'official',
      })

      const SubagentSpawn = await import('@deepseek-ai/dsh-subagent-spawn-in-process')
      await expect(ctx.plugin(SubagentSpawn, { providerName: 'late-official-spawn' }))
        .rejects.toThrow(/conflicts with a DSH built-in subagent\/control tool/)
      // The official placeholder survives untouched.
      expect(ctx.tools.schemas().filter(s => s.name === 'subagent')).toHaveLength(1)
    } finally {
      await ctx.fiber.dispose()
    }
  })

  it('exposes the official-name set for deployments and tests', () => {
    expect([...tool.OFFICIAL_SUBAGENT_TOOL_NAMES].sort()).toEqual([
      'interrupt_agent',
      'list_agents',
      'send_message',
      'subagent',
      'subagent_fork',
    ])
  })
})
