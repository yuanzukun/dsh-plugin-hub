/**
 * Invariant companion suite: the companion must mount through the invariant
 * service, register exactly its own package name, and expose the plugin
 * namespace shape the Loader requires.
 */

import { describe, expect, it } from 'vitest'
import { Context } from '@deepseek-ai/cordis'
import InvariantRegistry from '@deepseek-ai/dsh-invariants'
import * as invariant from '../src/invariant.ts'

describe('tool-subagent-router invariant companion', () => {
  it('has the namespace-plugin export shape (no stray default)', () => {
    expect('default' in invariant).toBe(false)
    expect(invariant.name).toBe('tool-subagent-router-invariant')
    expect(invariant.inject).toEqual(['invariants'])
    expect(typeof invariant.apply).toBe('function')
  })

  it('registers exactly its own package name through the invariant service', async () => {
    const ctx = new Context()
    try {
      await ctx.plugin(InvariantRegistry, { enabled: true })
      await ctx.plugin(invariant)
      // The service reserves one ownership per package name; the registration
      // resolving without throwing proves the companion claimed its name.
      expect(ctx.invariants).toBeDefined()
    } finally {
      await ctx.fiber.dispose()
    }
  })
})
