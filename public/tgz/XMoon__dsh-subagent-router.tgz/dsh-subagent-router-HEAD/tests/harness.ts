/**
 * Shared suite harness: boots the REAL continuation graph (agent loop, tool
 * registry, subagent runtime, spawn/fork providers, JSONL persistence) with a
 * package-local scripted LLM adapter, and keeps the stand-in parent out of the
 * model corpus.
 * @module tests/harness
 */

import { mkdtempSync, rmSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { Context } from '@deepseek-ai/cordis'
import type { Agent } from '@deepseek-ai/dsh-agent'
import AgentLoop from '@deepseek-ai/dsh-agent-loop'
import { mountAgentLoopTestDependencies } from '@deepseek-ai/dsh-agent-loop-testkit'
import type { GenerateOptions, LlmResolvedModelInfo, StreamChunk } from '@deepseek-ai/dsh-llm'
import { LlmAdapter } from '@deepseek-ai/dsh-llm'
import LocalJobRegistry from '@deepseek-ai/dsh-jobs-local'
import { SessionId } from '@deepseek-ai/dsh-session'
import JsonlSessionPersistence from '@deepseek-ai/dsh-session-persistence-jsonl'
import SubagentRuntime from '@deepseek-ai/dsh-subagent'
import type { SubagentResult } from '@deepseek-ai/dsh-subagent'
import * as SubagentFork from '@deepseek-ai/dsh-subagent-fork-in-process'
import * as SubagentSpawn from '@deepseek-ai/dsh-subagent-spawn-in-process'
import * as control from '@deepseek-ai/dsh-tool-subagent-control'
import * as listAgents from '@deepseek-ai/dsh-tool-subagent-control/list-agents'
import * as officialToolSubagent from '@deepseek-ai/dsh-tool-subagent'
import * as toolJobs from '@deepseek-ai/dsh-tool-jobs'
import SessionProjectionRegistry from '@deepseek-ai/dsh-session-projection'

/** Scripted text-only model response. */
export function textResponse(text: string): StreamChunk[] {
  return [
    { type: 'block-start', index: 0, blockType: 'text' },
    ...Array.from(text, (char): StreamChunk => ({ type: 'text-delta', index: 0, text: char })),
    { type: 'block-end', index: 0, block: { type: 'text', text } },
    { type: 'usage', usage: { inputTokens: 10, outputTokens: text.length } },
    { type: 'finish', reason: { kind: 'stop' } },
  ]
}

/**
 * Mock adapter driven by a script: each model call consumes the next entry.
 * Records every request for assertions. An entry may be a function to compute
 * chunks from the request, or a 'hang' marker that streams one chunk then
 * waits until aborted.
 */
export class MockAdapter extends LlmAdapter {
  requests: GenerateOptions[] = []

  constructor(private script: (StreamChunk[] | ((options: GenerateOptions) => StreamChunk[]) | 'hang')[]) {
    super()
  }

  override resolveModel(provider: string, model: string): Promise<LlmResolvedModelInfo> {
    return Promise.resolve({ provider, id: model, name: model })
  }

  async * stream(options: GenerateOptions): AsyncIterable<StreamChunk> {
    this.requests.push(options)
    const entry = this.script.shift()
    if (entry === undefined) throw new Error('MockAdapter: script exhausted')
    if (entry === 'hang') {
      yield { type: 'block-start', index: 0, blockType: 'text' }
      yield { type: 'text-delta', index: 0, text: 'partial' }
      await new Promise<void>((_resolve, reject) => {
        if (options.signal?.aborted) { reject(new Error('aborted')); return }
        options.signal?.addEventListener('abort', () => { reject(new Error('aborted')) }, { once: true })
      })
      return
    }
    const chunks = typeof entry === 'function' ? entry(options) : entry
    for (const chunk of chunks) {
      if (options.signal?.aborted) throw new Error('aborted')
      yield chunk
    }
  }
}

/** Options for one booted harness. */
export interface HarnessOptions {
  /** Scripted model responses for the parent/child turns. */
  script?: ConstructorParameters<typeof MockAdapter>[0]
  /** Whether to mount the official continuation control tools. */
  withControl?: boolean
  /** Whether to mount the fork provider under its default name. */
  withFork?: boolean
  /**
   * Whether to mount the background-job registry (`ctx.jobs`) and the
   * official `job_output` / `job_kill` / `job_list` tools, so one-shot
   * background delegations can be collected and stopped.
   */
  withJobs?: boolean
  /**
   * Whether to keep the stand-in parent's own turns out of the model corpus
   * (default true). Tests that need the parent to form REAL completed turns
   * (fork inheritance) set this to false and size the script accordingly.
   */
  parkParent?: boolean
  /**
   * Official `@deepseek-ai/dsh-tool-subagent` instances, mounted before the
   * router so coexistence tests exercise the real registry collision surface.
   * Each entry names the delegation tool and its fixed child route.
   */
  officialTools?: {
    toolName: string
    provider: 'spawn' | 'fork'
    backgroundMode?: 'one-shot' | 'continuable'
    agentOptions?: { provider: string; model: string }
  }[]
}

/** One booted harness: context, parent agent, adapter, and persistence root. */
export interface Harness {
  ctx: Context
  parent: Agent
  adapter: MockAdapter
  root: string
  /** Remove the temp persistence root. */
  cleanup(): void
}

const roots: string[] = []

/** Remove every registered temp root (call in afterEach). */
export function cleanupRoots(): void {
  for (const root of roots.splice(0)) {
    rmSync(root, { recursive: true, force: true, maxRetries: 10, retryDelay: 100 })
  }
}

/**
 * Boot the real continuation stack: agent-loop prerequisites, JSONL
 * persistence, agent loop, subagent runtime, spawn (and optionally fork)
 * providers, the session-projection registry, and optionally the official
 * continuation control tools (`send_message` / `interrupt_agent` /
 * `list_agents`) and official delegation tools (`subagent` / `subagent_fork`).
 * Registers the scripted adapter under the `mock` route and creates one
 * stand-in parent agent whose turns are rejected so its settlement wake never
 * consumes model script entries.
 */
export async function bootHarness(options: HarnessOptions = {}): Promise<Harness> {
  const ctx = new Context()
  await mountAgentLoopTestDependencies(ctx)
  const root = mkdtempSync(join(tmpdir(), 'dsh-subagent-router-'))
  roots.push(root)
  await ctx.plugin(JsonlSessionPersistence, { root })
  await ctx.plugin(AgentLoop, { agents: [] })
  await ctx.plugin(SubagentRuntime)
  await ctx.plugin(SubagentSpawn, { providerName: 'spawn' })
  if (options.withFork !== false) await ctx.plugin(SubagentFork, { providerName: 'fork' })
  if (options.withJobs === true) {
    await ctx.plugin(LocalJobRegistry)
    await ctx.plugin(toolJobs)
  }
  // The session-projection registry backs the official `list_agents` control
  // tool's durable enumeration (dsh-subagent registers its projection units
  // when the registry appears).
  await ctx.plugin(SessionProjectionRegistry)
  if (options.withControl !== false) await ctx.plugin(control)
  if (options.withControl !== false) await ctx.plugin(listAgents)
  for (const official of options.officialTools ?? []) {
    // Official default `enableRunInBackground: true` stays intact: the
    // `subagent`/`subagent_fork` tools then run in the background by default
    // (continuable id / one-shot job), matching a real deployment. Tests that
    // want a foreground official call pass `run_in_background: false`.
    await ctx.plugin(officialToolSubagent, {
      provider: official.provider,
      toolName: official.toolName,
      backgroundMode: official.backgroundMode ?? 'one-shot',
      ...official.agentOptions !== undefined ? { agentOptions: official.agentOptions } : {},
    })
  }
  const adapter = new MockAdapter(options.script ?? [])
  ctx.llm.registerAdapter(['mock'], adapter)
  const parent = ctx.agentLoop.create(SessionId('parent'), { provider: 'mock', model: 'mock' })
  if (options.parkParent !== false) parkParent(ctx, parent)
  return {
    ctx,
    parent,
    adapter,
    root,
    cleanup: () => {
      for (const [index, candidate] of roots.entries()) {
        if (candidate === root) roots.splice(index, 1)
      }
      rmSync(root, { recursive: true, force: true, maxRetries: 10, retryDelay: 100 })
    },
  }
}

/**
 * Reject every step of the stand-in parent. Each child settlement wakes its
 * parent, and these suites size their scripts for child turns only; the tests
 * assert on delivery rather than on the parent's own turn.
 * @param ctx - the booted test context.
 * @param parent - the stand-in parent whose turns must not reach the model.
 */
export function parkParent(ctx: Context, parent: { id: SessionId }): void {
  ctx.on('agent/pre-step', async ({ agent: subject }, next) => {
    if (subject.id !== parent.id) return next()
    return { kind: 'reject' as const }
  })
}

/** Await quiescence of the parent so the driver is idle before follow-ups. */
export function parkParentGuard(): void {
  // No-op retained for symmetry; parkParent handles wake rejection.
}

/** Options for one scripted one-shot provider fixture. */
export interface ScriptedProviderOptions {
  /** Registry name to register under. */
  name: string
  /** Final text returned by the scripted child. */
  reply?: string
  /** Terminal result reason; `'frobnicated'` exercises the unknown-reason arm. */
  stopReason?: 'completed' | 'aborted' | 'error' | 'max-tokens' | 'refusal' | 'frobnicated'
  /** Provider-authored failure detail appended to stop-reason errors. */
  diagnostic?: string
  /** Whether `dispose()` rejects. */
  disposeFails?: boolean
}

/**
 * Scripted one-shot provider whose result and disposal can be forced to fail,
 * for covering the tool's stop-reason and disposal error branches.
 */
export function mountScriptedOneShotProvider(ctx: Context, options: ScriptedProviderOptions): void {
  ctx.subagents.registerProvider({
    name: options.name,
    capabilities: { outputSchema: false, depthLimit: true, toolFilter: true, persona: true },
    inheritsParentContext: false,
    start: async () => {
      const output = options.reply === undefined ? [] : [{ type: 'text' as const, text: options.reply }]
      return {
        id: SessionId(`scripted:${options.name}`),
        localAgent: undefined,
        result: Promise.resolve({
          output,
          stopReason: (options.stopReason ?? 'completed') as SubagentResult['stopReason'],
          ...options.diagnostic !== undefined ? { diagnostic: options.diagnostic } : {},
        }),
        dispose: options.disposeFails
          ? async () => { throw new Error('scripted dispose failed') }
          : async () => {},
      }
    },
  })
}