/**
 * Official-tool coexistence suite for `@xmoon76/dsh-subagent-router`: mounts
 * the REAL official delegation tools (`subagent` / `subagent_fork` from
 * `@deepseek-ai/dsh-tool-subagent`), the REAL official continuation controls
 * (`send_message` / `interrupt_agent` / `list_agents` from
 * `@deepseek-ai/dsh-tool-subagent-control`), and the router in one context,
 * and locks the coexistence contract from the plan (P0):
 *
 * - every official tool stays registered beside `subagent_route`, each exactly
 *   once (no replacement, no duplicate registration);
 * - official schemas are unchanged before and after the router loads (the
 *   router never shadows, replaces, or mutates them);
 * - official delegation still executes after the router is mounted, and the
 *   continuation controls still resolve the children the official tools made;
 * - the router's own schema stays independent;
 * - the router executes BOTH of its modes (spawn/continuable and
 *   fork/one-shot) beside the official tools.
 */

import { afterEach, describe, expect, it, vi } from 'vitest'
import { CallId } from '@deepseek-ai/dsh-llm'
import { SessionId } from '@deepseek-ai/dsh-session'
import * as tool from '../src/index.ts'
import { bootHarness, cleanupRoots, textResponse, type Harness } from './harness.ts'

const testToolSignal = new AbortController().signal

let callCounter = 0
/** Execute one tool call through the real registry (the shipping path). */
function callTool(h: Harness, name: string, args: Record<string, unknown>) {
  return h.ctx.tools.execute({
    signal: testToolSignal,
    callId: CallId(`coexist-${++callCounter}`),
    name,
    arguments: args,
    agent: h.parent,
  })
}

function text(result: { content: { type: string; text?: string }[] }): string {
  return result.content.filter(block => block.type === 'text').map(block => block.text).join('')
}

/**
 * Deep-compare the model-facing schema of one tool before/after router load.
 * The compared fields are exactly what the registry serves to the model
 * (name, description, parameters); other registry-internal fields are not
 * part of the model-visible contract this suite pins.
 */
function schemaOf(h: Harness, name: string) {
  const schema = h.ctx.tools.schemas().find(s => s.name === name)
  if (schema === undefined) throw new Error(`expected tool schema "${name}"`)
  return {
    name: schema.name,
    description: schema.description,
    parameters: schema.parameters,
  }
}

/** The complete official tool set the harness mounts by default. */
const OFFICIAL_NAMES = ['subagent', 'subagent_fork', 'send_message', 'interrupt_agent', 'list_agents'] as const

/** The two official delegation instances the coexistence tests mount. */
const OFFICIAL_TOOLS = [
  { toolName: 'subagent', provider: 'spawn' as const, backgroundMode: 'continuable' as const, agentOptions: { provider: 'mock', model: 'mock' } },
  { toolName: 'subagent_fork', provider: 'fork' as const, backgroundMode: 'one-shot' as const, agentOptions: { provider: 'mock', model: 'mock' } },
]

/** Wait until a child's Activation released its handle (child settled). */
async function waitNoActivation(h: Harness, childId: string): Promise<void> {
  await vi.waitFor(() => {
    expect(h.ctx.agents.get(SessionId(childId))).toBeUndefined()
  }, { timeout: 5_000 })
}

afterEach(() => {
  cleanupRoots()
})

describe('official tool coexistence', () => {
  it('registers every official tool and the router tool side by side, each exactly once', async () => {
    const h = await bootHarness({ officialTools: OFFICIAL_TOOLS })
    try {
      await h.ctx.plugin(tool, { executionMode: 'continuable', subagentProvider: 'spawn' })
      const names = h.ctx.tools.schemas().map(s => s.name).sort()
      for (const official of OFFICIAL_NAMES) {
        expect(names.filter(name => name === official)).toHaveLength(1)
      }
      expect(names.filter(name => name === 'subagent_route')).toHaveLength(1)
      // No tool from the router shadows an official name.
      const routerOnly = h.ctx.tools.schemas().filter(s => !OFFICIAL_NAMES.includes(s.name as (typeof OFFICIAL_NAMES)[number]))
      expect(routerOnly.map(s => s.name).sort()).toEqual(['subagent_route'])
    } finally {
      await h.ctx.fiber.dispose()
    }
  })

  it('does not mutate official tool schemas when the router loads', async () => {
    const h = await bootHarness({ officialTools: OFFICIAL_TOOLS })
    try {
      const before = new Map(OFFICIAL_NAMES.map(name => [name, schemaOf(h, name)]))
      await h.ctx.plugin(tool, { executionMode: 'continuable', subagentProvider: 'spawn' })
      for (const name of OFFICIAL_NAMES) {
        expect(schemaOf(h, name)).toEqual(before.get(name))
      }
      // The router added exactly one tool to the registry.
      expect(h.ctx.tools.schemas().filter(s => s.name === 'subagent_route')).toHaveLength(1)
    } finally {
      await h.ctx.fiber.dispose()
    }
  })

  it('keeps official delegation executable after the router is mounted, and the controls see their children', async () => {
    const h = await bootHarness({
      officialTools: OFFICIAL_TOOLS,
      script: [textResponse('official spawn answer'), textResponse('official fork answer')],
    })
    try {
      await h.ctx.plugin(tool, { executionMode: 'continuable', subagentProvider: 'spawn' })
      // Official spawn (continuable, fixed route) — returns a durable id.
      const spawn = await callTool(h, 'subagent', { description: 'official spawn', prompt: 'go' })
      expect(spawn.isError).toBe(false)
      const spawnMatch = /^started subagent (\S+)$/.exec(text(spawn))
      expect(spawnMatch).not.toBeNull()
      const childId = spawnMatch![1] as string
      await waitNoActivation(h, childId)

      // Official fork (one-shot, fixed route) — returns the final output.
      const fork = await callTool(h, 'subagent_fork', { description: 'official fork', prompt: 'analyze' })
      expect(fork.isError).toBe(false)
      expect(text(fork)).toBe('official fork answer')
      const forkRunId = (fork.value as { runId?: string }).runId
      expect(forkRunId).toBeTypeOf('string')

      // The continuation control sees the official spawn child as continuable.
      const listing = await callTool(h, 'list_agents', {})
      expect(listing.isError).toBe(false)
      expect(text(listing)).toContain(childId)
      // ...and does NOT list the one-shot fork child.
      expect(text(listing)).not.toContain(forkRunId)

      // Both children ran through the official tools — the router did not
      // hijack their routes.
      await vi.waitFor(() => {
        expect(h.adapter.requests.length).toBe(2)
      }, { timeout: 5_000 })
      for (const request of h.adapter.requests) {
        expect(request.provider).toBe('mock')
        expect(request.model).toBe('mock')
      }
    } finally {
      await h.ctx.fiber.dispose()
    }
  })

  it('keeps the router schema independent of the official tools', async () => {
    const h = await bootHarness({ officialTools: OFFICIAL_TOOLS })
    try {
      await h.ctx.plugin(tool, { executionMode: 'continuable', subagentProvider: 'spawn' })
      const router = h.ctx.tools.schemas().find(s => s.name === 'subagent_route')
      expect(router).toBeDefined()
      // The router schema exposes description/prompt/provider/model plus the
      // optional run_in_background scheduling override.
      const props = (router!.parameters as { properties?: Record<string, unknown> }).properties ?? {}
      expect(Object.keys(props).sort()).toEqual(['description', 'model', 'prompt', 'provider', 'run_in_background'])
      // It does not expose official-only parameters.
      for (const forbidden of ['subagent_id', 'agent_id', 'scope', 'message']) {
        expect(Object.keys(props)).not.toContain(forbidden)
      }
    } finally {
      await h.ctx.fiber.dispose()
    }
  })

  it('executes BOTH router modes beside the official tools: spawn continuable and fork one-shot', async () => {
    const h = await bootHarness({
      officialTools: OFFICIAL_TOOLS,
      script: [textResponse('router spawn answer'), textResponse('router fork answer')],
    })
    try {
      // Router instance 1: spawn + continuable (the bundle default).
      await h.ctx.plugin(tool, { executionMode: 'continuable', subagentProvider: 'spawn' })
      const spawn = await callTool(h, 'subagent_route', {
        description: 'router spawn',
        prompt: 'go',
        provider: 'mock',
        model: 'mock',
      })
      expect(spawn.isError).toBe(false)
      const spawnMatch = /^started subagent (\S+)$/.exec(text(spawn))
      expect(spawnMatch).not.toBeNull()
      const childId = spawnMatch![1] as string
      await waitNoActivation(h, childId)

      // The continuation control lists the router's continuable child.
      const listing = await callTool(h, 'list_agents', {})
      expect(listing.isError).toBe(false)
      expect(text(listing)).toContain(childId)

      // Router instance 2: fork + one-shot under a distinct name.
      await h.ctx.plugin(tool, { executionMode: 'one-shot', subagentProvider: 'fork', toolName: 'subagent_fork_route' })
      const fork = await callTool(h, 'subagent_fork_route', {
        description: 'router fork',
        prompt: 'review',
        provider: 'mock',
        model: 'mock',
      })
      expect(fork.isError).toBe(false)
      expect(text(fork)).toBe('router fork answer')
      const runId = (fork.value as { runId?: string }).runId
      expect(runId).toBeTypeOf('string')

      // The one-shot fork child is NOT a continuable child: list_agents must
      // not list its run id.
      const afterFork = await callTool(h, 'list_agents', {})
      expect(afterFork.isError).toBe(false)
      expect(text(afterFork)).not.toContain(runId)

      // Both router children ran on the model-selected route.
      await vi.waitFor(() => {
        expect(h.adapter.requests.length).toBe(2)
      }, { timeout: 5_000 })
      for (const request of h.adapter.requests) {
        expect(request.provider).toBe('mock')
        expect(request.model).toBe('mock')
      }
    } finally {
      await h.ctx.fiber.dispose()
    }
  })
})
