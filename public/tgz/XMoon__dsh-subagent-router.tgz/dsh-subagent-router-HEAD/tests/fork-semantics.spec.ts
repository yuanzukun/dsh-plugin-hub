/**
 * Fork one-shot semantics suite (plan P0, sections 6/7/19/20/21/29): locks
 * the complete product contract of the router's `fork + one-shot` path:
 *
 * - the child inherits the parent's COMPLETED turns;
 * - the current IN-FLIGHT parent turn is excluded from the fork seed;
 * - the child uses the model-selected provider/model (dynamic route);
 * - the one-shot final output is returned and the run disposed;
 * - the run id cannot be continued with the official `send_message`;
 * - `list_agents` does not list the one-shot child as continuable;
 * - persona / toolFilter / maxDepth flow into the child (maxDepth rejects a
 *   fork whose resolved child depth exceeds the cap, before any child work);
 * - allowedProviders is enforced before ANY child work;
 * - cancellation settles the run and leaves no dangling agent;
 * - concurrent sibling forks provably overlap in flight, share the stable
 *   completed prefix, and never cross routes or results.
 *
 * Two scripted adapters serve the parent (`mock` route) and the fork child
 * (`child-mock` route), so parent and child NEVER share a model corpus.
 */

import { afterEach, describe, expect, it, vi } from 'vitest'
import { CallId } from '@deepseek-ai/dsh-llm'
import { createUserMessage } from '@deepseek-ai/dsh-llm'
import type { GenerateOptions, LlmResolvedModelInfo, StreamChunk } from '@deepseek-ai/dsh-llm'
import { LlmAdapter } from '@deepseek-ai/dsh-llm'
import { SessionId } from '@deepseek-ai/dsh-session'
import * as tool from '../src/index.ts'
import {
  bootHarness,
  cleanupRoots,
  MockAdapter,
  textResponse,
  type Harness,
} from './harness.ts'

/**
 * Scripted adapter whose stream parks on a gate after recording the request:
 * tests open the gate to prove two runs were BOTH in flight before either
 * finished (real concurrency, not serialized execution).
 */
class GateAdapter extends LlmAdapter {
  requests: GenerateOptions[] = []
  private gates: Promise<void>[] = []
  private openers: (() => void)[] = []

  constructor(private reply: string) {
    super()
  }

  override resolveModel(provider: string, model: string): Promise<LlmResolvedModelInfo> {
    return Promise.resolve({ provider, id: model, name: model })
  }

  async * stream(options: GenerateOptions): AsyncIterable<StreamChunk> {
    this.requests.push(options)
    const gate = new Promise<void>((resolve) => { this.openers.push(resolve) })
    this.gates.push(gate)
    await gate
    if (options.signal?.aborted) throw new Error('aborted')
    const text = this.reply
    yield { type: 'block-start', index: 0, blockType: 'text' }
    for (const char of text) {
      if (options.signal?.aborted) throw new Error('aborted')
      yield { type: 'text-delta', index: 0, text: char }
    }
    yield { type: 'block-end', index: 0, block: { type: 'text', text } }
    yield { type: 'usage', usage: { inputTokens: 10, outputTokens: text.length } }
    yield { type: 'finish', reason: { kind: 'stop' } }
  }

  /** Open the i-th request's gate; undefined opens every pending gate. */
  open(index?: number): void {
    if (index === undefined) {
      for (const opener of this.openers.splice(0)) opener()
      return
    }
    this.openers[index]?.()
  }
}

const testToolSignal = new AbortController().signal

let callCounter = 0
function callStart(h: Harness, args: Record<string, unknown>, over: { signal?: AbortSignal } = {}) {
  return h.ctx.tools.execute({
    signal: over.signal ?? testToolSignal,
    callId: CallId(`fork-${++callCounter}`),
    name: 'subagent_fork_route',
    arguments: args,
    agent: h.parent,
  })
}

function text(result: { content: { type: string; text?: string }[] }): string {
  return result.content.filter(block => block.type === 'text').map(block => block.text).join('')
}

function textOf(block: unknown): string {
  return typeof block === 'object' && block !== null && (block as { type?: string }).type === 'text'
    ? ((block as { text: string }).text)
    : ''
}

/**
 * Boot the fork harness: a real parent turn completes (unparked, own script
 * entry on the `mock` route), and the fork child is served by a separate
 * `child-mock` adapter so the dynamic route is observable in isolation.
 */
async function bootForkHarness(options: { parentTurn?: boolean } = {}) {
  const childAdapter = new MockAdapter([textResponse('fork child answer')])
  const h = await bootHarness({
    withFork: true,
    parkParent: false,
    script: options.parentTurn === false ? [] : [textResponse('Understood.')],
  })
  h.ctx.llm.registerAdapter(['child-mock'], childAdapter)
  if (options.parentTurn !== false) {
    h.parent.followup(createUserMessage({
      content: [{ type: 'text', text: 'The project uses Redis for cache.' }],
      source: { kind: 'user' },
    }))
    await h.parent.whenIdle()
  }
  return { h, childAdapter }
}

async function mountForkTool(h: Harness, config: Partial<tool.Config> = {}) {
  // The fork instance always registers under its product name.
  config = { toolName: 'subagent_fork_route', ...config }
  await h.ctx.plugin(tool, { backgroundMode: 'one-shot', subagentProvider: 'fork', ...config })
}

afterEach(() => {
  cleanupRoots()
})

describe('fork one-shot semantics', () => {
  it('inherits completed parent turns and uses the model-selected child route', async () => {
    const { h, childAdapter } = await bootForkHarness()
    try {
      await mountForkTool(h)
      const result = await callStart(h, {
        description: 'fork task',
        prompt: 'Review the cache design.',
        provider: 'child-mock',
        model: 'child-model',
      })
      expect(result.isError).toBe(false)
      expect(text(result)).toBe('fork child answer')
      expect(result.value).toMatchObject({
        kind: 'foreground',
        runId: expect.any(String),
        output: [{ type: 'text', text: 'fork child answer' }],
      })

      // The child request carries the completed parent prefix PLUS the new prompt.
      await vi.waitFor(() => {
        expect(childAdapter.requests.length).toBe(1)
      }, { timeout: 5_000 })
      const request = childAdapter.requests[0]!
      expect(request.provider).toBe('child-mock')
      expect(request.model).toBe('child-model')
      const userTexts = request.messages
        .filter(m => m.role === 'user')
        .map(m => m.content.map(textOf).join(''))
      expect(userTexts).toContain('The project uses Redis for cache.')
      expect(userTexts).toContain('Review the cache design.')
      const assistantTexts = request.messages
        .filter(m => m.role === 'assistant')
        .map(m => m.content.map(textOf).join(''))
      expect(assistantTexts).toContain('Understood.')
    } finally {
      await h.ctx.fiber.dispose()
    }
  })

  it('excludes the current in-flight parent turn from the fork seed', async () => {
    const childAdapter = new MockAdapter([textResponse('fork child answer')])
    const h = await bootHarness({
      withFork: true,
      parkParent: false,
      script: ['hang'],
    })
    h.ctx.llm.registerAdapter(['child-mock'], childAdapter)
    try {
      // Parent turn starts and hangs mid-request (in-flight).
      h.parent.followup(createUserMessage({
        content: [{ type: 'text', text: 'IN-FLIGHT QUESTION?' }],
        source: { kind: 'user' },
      }))
      await vi.waitFor(() => {
        expect(h.parent.status).toBe('running')
      }, { timeout: 5_000 })

      await mountForkTool(h)
      const result = await callStart(h, {
        description: 'fork task',
        prompt: 'Review.',
        provider: 'child-mock',
        model: 'child-model',
      })
      expect(result.isError).toBe(false)

      // The child sees only the new prompt — the in-flight parent turn is
      // not part of the completed prefix.
      const request = childAdapter.requests[0]!
      const userTexts = request.messages
        .filter(m => m.role === 'user')
        .map(m => m.content.map(textOf).join(''))
      expect(userTexts).not.toContain('IN-FLIGHT QUESTION?')
      expect(userTexts).toContain('Review.')
    } finally {
      await h.ctx.fiber.dispose()
    }
  })

  it('cannot be resumed with the official send_message and is not listed as a continuable child', async () => {
    const { h } = await bootForkHarness()
    try {
      await mountForkTool(h)
      const result = await callStart(h, {
        description: 'fork task',
        prompt: 'Review the cache design.',
        provider: 'child-mock',
        model: 'child-model',
      })
      expect(result.isError).toBe(false)
      const runId = (result.value as { runId: string }).runId

      // Official continuation control: send_message on the one-shot run id
      // must fail (no supported continuation state).
      const follow = await h.ctx.tools.execute({
        signal: testToolSignal,
        callId: CallId('fork-follow'),
        name: 'send_message',
        arguments: { subagent_id: runId, message: 'continue' },
        agent: h.parent,
      })
      expect(follow.isError).toBe(true)
      const followText = text(follow)
      // Assert a stable fragment only (not the whole upstream wording).
      expect(followText).toMatch(/cannot be resumed|NOT_RESUMABLE|no supported continuation state/i)

      // Official discovery: list_agents must NOT list the one-shot child.
      const listing = await h.ctx.tools.execute({
        signal: testToolSignal,
        callId: CallId('fork-list'),
        name: 'list_agents',
        arguments: {},
        agent: h.parent,
      })
      expect(listing.isError).toBe(false)
      expect(text(listing)).not.toContain(runId)
    } finally {
      await h.ctx.fiber.dispose()
    }
  })

  it('forwards persona into the child system prompt and applies toolFilter to its schema', async () => {
    const { h, childAdapter } = await bootForkHarness()
    try {
      await mountForkTool(h, {
        persona: 'You are an independent code reviewer.',
        toolFilter: { deny: ['send_message'] },
      })
      const result = await callStart(h, {
        description: 'fork task',
        prompt: 'Review the cache design.',
        provider: 'child-mock',
        model: 'child-model',
      })
      expect(result.isError).toBe(false)

      const request = childAdapter.requests[0]!
      expect(request.system).toContain('You are an independent code reviewer.')
      const names = request.tools?.map(t => t.name) ?? []
      expect(names).not.toContain('send_message')
    } finally {
      await h.ctx.fiber.dispose()
    }
  })

  it('enforces allowedProviders before any child work on the fork path', async () => {
    const childAdapter = new MockAdapter([textResponse('unused')])
    const h = await bootHarness({
      withFork: true,
      parkParent: false,
      script: [],
    })
    h.ctx.llm.registerAdapter(['child-mock'], childAdapter)
    try {
      await mountForkTool(h, { allowedProviders: ['allowed'] })
      const result = await callStart(h, {
        description: 'denied',
        prompt: 'x',
        provider: 'child-mock',
        model: 'child-model',
      })
      expect(result.isError).toBe(true)
      expect(text(result)).toContain('"child-mock" is not allowed')
      // No child session, no fork seed publication, no model request.
      expect(childAdapter.requests).toHaveLength(0)
      const listing = await h.ctx.tools.execute({
        signal: testToolSignal,
        callId: CallId('fork-denied-list'),
        name: 'list_agents',
        arguments: {},
        agent: h.parent,
      })
      expect(text(listing)).toBe('(no subagents)')
    } finally {
      await h.ctx.fiber.dispose()
    }
  })

  it('settles aborted and disposes without a dangling agent when the tool signal aborts', async () => {
    const childAdapter = new MockAdapter(['hang'])
    const h = await bootHarness({
      withFork: true,
      parkParent: false,
      script: [],
    })
    h.ctx.llm.registerAdapter(['child-mock'], childAdapter)
    try {
      await mountForkTool(h)
      const controller = new AbortController()
      const pending = callStart(h, {
        description: 'cancel me',
        prompt: 'long running',
        provider: 'child-mock',
        model: 'child-model',
      }, { signal: controller.signal })
      // Let the child start its hang, then abort the tool call.
      await vi.waitFor(() => {
        expect(childAdapter.requests.length).toBe(1)
      }, { timeout: 5_000 })
      controller.abort()
      const result = await pending
      expect(result.isError).toBe(true)
      // No dangling agent: the child session is gone from the live registry.
      await vi.waitFor(() => {
        expect(h.ctx.agents.get(SessionId('parent'))).toBeDefined()
      }, { timeout: 1_000 })
      expect(h.ctx.agents.list().map(a => String(a.id))).toEqual(['parent'])
    } finally {
      await h.ctx.fiber.dispose()
    }
  })

  it('runs concurrent sibling forks with provably overlapping lifecycles, without crossing routes, seeds, or disposals', async () => {
    const childAdapterA = new GateAdapter('answer A')
    const childAdapterB = new GateAdapter('answer B')
    const h = await bootHarness({
      withFork: true,
      parkParent: false,
      script: [textResponse('Understood.')],
    })
    h.ctx.llm.registerAdapter(['child-mock-a'], childAdapterA)
    h.ctx.llm.registerAdapter(['child-mock-b'], childAdapterB)
    try {
      // Form one real completed parent turn BEFORE the sibling forks.
      h.parent.followup(createUserMessage({
        content: [{ type: 'text', text: 'The project uses Redis for cache.' }],
        source: { kind: 'user' },
      }))
      await h.parent.whenIdle()
      await mountForkTool(h)

      // Start both forks; each child parks on its gate after its first
      // request. Both calls must still be in flight BEFORE either gate opens.
      const pending = Promise.all([
        callStart(h, {
          description: 'fork A',
          prompt: 'Review A.',
          provider: 'child-mock-a',
          model: 'child-model-a',
        }),
        callStart(h, {
          description: 'fork B',
          prompt: 'Review B.',
          provider: 'child-mock-b',
          model: 'child-model-b',
        }),
      ])
      // Both children reached their model request while both forks are
      // pending — the two runs genuinely overlapped.
      await vi.waitFor(() => {
        expect(childAdapterA.requests.length).toBe(1)
        expect(childAdapterB.requests.length).toBe(1)
      }, { timeout: 5_000 })
      // Neither call has settled while both children are still parked.
      const settledEarly = await Promise.race([
        pending.then(() => true),
        new Promise<boolean>(resolve => setTimeout(() => resolve(false), 300)),
      ])
      expect(settledEarly).toBe(false)

      // Release both gates, then both fork calls complete with their own
      // outputs.
      childAdapterA.open()
      childAdapterB.open()
      const [a, b] = await pending
      expect(a.isError).toBe(false)
      expect(b.isError).toBe(false)
      expect(text(a)).toBe('answer A')
      expect(text(b)).toBe('answer B')

      // Both children inherited the same completed prefix (the parent turn),
      // and each received exactly its own new prompt.
      const requestA = childAdapterA.requests[0]!
      const requestB = childAdapterB.requests[0]!
      const userA = requestA.messages.filter(m => m.role === 'user').map(m => m.content.map(textOf).join(''))
      const userB = requestB.messages.filter(m => m.role === 'user').map(m => m.content.map(textOf).join(''))
      for (const texts of [userA, userB]) {
        expect(texts).toContain('The project uses Redis for cache.')
      }
      expect(userA).toContain('Review A.')
      expect(userB).toContain('Review B.')
      expect(userA).not.toContain('Review B.')
      expect(userB).not.toContain('Review A.')
      // Routes did not cross.
      expect(requestA.provider).toBe('child-mock-a')
      expect(requestA.model).toBe('child-model-a')
      expect(requestB.provider).toBe('child-mock-b')
      expect(requestB.model).toBe('child-model-b')
      // Both runs disposed: no dangling child agents.
      expect(h.ctx.agents.list().map(a => String(a.id))).toEqual(['parent'])
    } finally {
      await h.ctx.fiber.dispose()
    }
  })

  it('rejects a fork whose resolved child depth exceeds maxDepth, before any child work', async () => {
    const childAdapter = new MockAdapter([textResponse('unused')])
    const h = await bootHarness({
      withFork: true,
      parkParent: false,
      script: [],
    })
    h.ctx.llm.registerAdapter(['child-mock'], childAdapter)
    try {
      // Parent is top-level (delegation depth 0); a fork child would resolve
      // to depth 1. maxDepth 0 must reject the fork before any child request.
      await mountForkTool(h, { maxDepth: 0 })
      const result = await callStart(h, {
        description: 'too deep',
        prompt: 'x',
        provider: 'child-mock',
        model: 'child-model',
      })
      expect(result.isError).toBe(true)
      expect(text(result)).toMatch(/depth/i)
      // No child session, no fork seed publication, no model request.
      expect(childAdapter.requests).toHaveLength(0)
      const listing = await h.ctx.tools.execute({
        signal: testToolSignal,
        callId: CallId('fork-depth-list'),
        name: 'list_agents',
        arguments: {},
        agent: h.parent,
      })
      expect(text(listing)).toBe('(no subagents)')
    } finally {
      await h.ctx.fiber.dispose()
    }
  })
})
