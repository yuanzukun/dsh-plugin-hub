/**
 * Bundle-patch suite for `@xmoon76/dsh-subagent-router`: validates the
 * shipped `cordis.patch.yml` against the DSH bundle contract the way
 * `verify-cordis-config` does in the harness repo — every patch row's plugin
 * package must resolve from the bundle manifest's own `dependencies` (a
 * bundle may mount itself without declaring itself), and the file must parse
 * as a Loader entry list.
 * @module tests/bundle-patch
 */

import { readFileSync } from 'node:fs'
import { resolve } from 'node:path'
import { entryListSchema } from '@deepseek-ai/cordis-plugin-include'
import * as yaml from 'js-yaml'
import { describe, expect, it } from 'vitest'

const ROOT = resolve(import.meta.dirname, '..')
const PATCH_PATH = resolve(ROOT, 'cordis.patch.yml')

interface PackageManifest {
  name?: string
  dependencies?: Record<string, string>
  files?: string[]
  dsh?: { bundle?: { patch?: string } }
}

function readManifest(): PackageManifest {
  return JSON.parse(readFileSync(resolve(ROOT, 'package.json'), 'utf8')) as PackageManifest
}

interface PatchRow {
  id?: string
  insert?: unknown[]
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return value !== null && typeof value === 'object'
}

function parsePatch(): unknown[] {
  const source = readFileSync(PATCH_PATH, 'utf8')
  const document = yaml.load(source, { schema: entryListSchema })
  if (!Array.isArray(document)) throw new Error('cordis.patch.yml: root must be a patch list')
  return document
}

/** Collect every row `name` across a patch document, including inside `insert` lists. */
function rowNames(entries: unknown[]): string[] {
  const names: string[] = []
  const walk = (value: unknown): void => {
    if (Array.isArray(value)) {
      for (const item of value) walk(item)
      return
    }
    if (!isRecord(value)) return
    if (typeof value.name === 'string') names.push(value.name)
    for (const child of Object.values(value)) walk(child)
  }
  walk(entries)
  return names
}

describe('cordis.patch.yml bundle contract', () => {
  it('parses with the Loader entry-list dialect', () => {
    const document = parsePatch()
    expect(document.length).toBeGreaterThan(0)
  })

  it('inserts exactly the two router rows, uniquely, with distinct tool names', () => {
    const rows = parsePatch().flatMap(entry => {
      const record = entry as PatchRow
      return record.insert !== undefined && Array.isArray(record.insert)
        ? record.insert
        : [entry]
    })
    expect(rows.map(row => isRecord(row) ? row.id : undefined))
      .toEqual(['tool-subagent-router', 'tool-subagent-router-fork'])
    // The two instances use distinct non-official tool names.
    const toolNames = rows
      .map(row => isRecord(row) && row.config ? (row.config as { toolName?: unknown }).toolName : undefined)
    expect(toolNames).toEqual(['subagent_route', 'subagent_fork_route'])
  })

  it('declares every inserted plugin package in the bundle dependencies (self allowed)', () => {
    const manifest = readManifest()
    const dependencies = manifest.dependencies ?? {}
    const names = rowNames(parsePatch())
    expect(names.length).toBeGreaterThan(0)
    for (const name of names) {
      if (name === manifest.name) continue
      expect(name in dependencies, `${name} must be declared in dependencies`).toBe(true)
    }
  })

  it('keeps the patch layer free of rows the dsh-base layer already mounts', () => {
    // The spawn/fork backends and the `subagents` registry are dsh-base rows;
    // re-inserting them here would collide with the base layer.
    const names = new Set(rowNames(parsePatch()))
    expect(names.has('@deepseek-ai/dsh-subagent')).toBe(false)
    expect(names.has('@deepseek-ai/dsh-subagent-spawn-in-process')).toBe(false)
    expect(names.has('@deepseek-ai/dsh-subagent-fork-in-process')).toBe(false)
    expect(names.has('@deepseek-ai/dsh-tool-subagent-control')).toBe(false)
  })

  it('never touches or modifies official row ids', () => {
    // The bundle is a pure overlay: it must not patch, replace, or rename any
    // row id owned by the official base/tool layers.
    const patch = parsePatch()
    const targetedIds = patch
      .filter(entry => isRecord(entry) && typeof entry.id === 'string')
      .map(entry => (entry as { id: string }).id)
    expect(targetedIds).toEqual([])
    // Every patch entry is a pure insert (no row replacement).
    for (const entry of patch) {
      expect(isRecord(entry)).toBe(true)
      const record = entry as { id?: unknown; insert?: unknown }
      expect(record.id).toBeUndefined()
      expect(record.insert).toBeDefined()
    }

    // Official row ids the dsh-base/tool layers own in a real profile: the
    // bundle must never insert a row under one of them (which would duplicate
    // or shadow the official row).
    const officialRowIds = new Set([
      'tool-subagent',
      'tool-subagent-fork',
      'tool-subagent-control',
      'tool-subagent-list-agents',
      'subagent-runtime',
      'subagent-spawn',
      'subagent-fork',
    ])
    const insertedIds = patch.flatMap(entry => {
      const record = entry as { insert?: unknown[] }
      return Array.isArray(record.insert)
        ? record.insert.filter(isRecord).map(row => row.id).filter((id): id is string => typeof id === 'string')
        : []
    })
    for (const id of insertedIds) {
      expect(officialRowIds.has(id), `bundle must not insert a row under official id "${id}"`).toBe(false)
    }
  })

  it('lists cordis.patch.yml in the package files so the tarball carries it', () => {
    const manifest = readManifest()
    const files = manifest.files ?? []
    expect(files).toContain('cordis.patch.yml')
  })

  it('keeps the dsh bundle patch pointer intact', () => {
    const manifest = readManifest()
    expect(manifest.dsh).toMatchObject({ bundle: { patch: './cordis.patch.yml' } })
  })
})
