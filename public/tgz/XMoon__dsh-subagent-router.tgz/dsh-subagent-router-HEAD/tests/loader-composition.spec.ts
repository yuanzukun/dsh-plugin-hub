/**
 * REAL Loader composition suite: boots a test-only `cordis.yml` through the
 * Cordis Loader (the same entry the DSH host uses), mounting the real plugin
 * package by name, and verifies the plugin loads, its tool schema is visible,
 * and a routed continuable child can be created through it. Only the LLM
 * boundary is scripted; everything downstream is the shipping path.
 */

import { mkdtemp, rm, writeFile } from 'node:fs/promises'
import { readFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join, resolve } from 'node:path'
import { pathToFileURL } from 'node:url'
import { afterEach, describe, expect, it, vi } from 'vitest'
import { Context } from '@deepseek-ai/cordis'
import Loader from '@deepseek-ai/cordis-plugin-loader'
import Include, { entryListSchema, type PatchOptions } from '@deepseek-ai/cordis-plugin-include'
import * as yaml from 'js-yaml'
import AgentRegistry from '@deepseek-ai/dsh-agent'
import AgentLoop from '@deepseek-ai/dsh-agent-loop'
import { CallId, LlmAdapter, LlmRuntime } from '@deepseek-ai/dsh-llm'
import type { GenerateOptions, StreamChunk } from '@deepseek-ai/dsh-llm'
import { SessionId } from '@deepseek-ai/dsh-session'
import SessionStore from '@deepseek-ai/dsh-session'
import JsonlSessionPersistence from '@deepseek-ai/dsh-session-persistence-jsonl'
import SubagentRuntime from '@deepseek-ai/dsh-subagent'
import * as SubagentSpawn from '@deepseek-ai/dsh-subagent-spawn-in-process'
import * as SubagentFork from '@deepseek-ai/dsh-subagent-fork-in-process'
import * as officialToolSubagent from '@deepseek-ai/dsh-tool-subagent'
import * as control from '@deepseek-ai/dsh-tool-subagent-control'
import * as listAgents from '@deepseek-ai/dsh-tool-subagent-control/list-agents'
import SessionProjectionRegistry from '@deepseek-ai/dsh-session-projection'
import SystemPrompt from '@deepseek-ai/dsh-system-prompt'
import ToolRuntime from '@deepseek-ai/dsh-tools'
import { textResponse } from './harness.ts'

/** The shipped bundle patch, parsed with the Loader entry-list dialect. */
function bundlePatch(): PatchOptions[] {
  const source = readFileSync(resolve(import.meta.dirname, '..', 'cordis.patch.yml'), 'utf8')
  const document = yaml.load(source, { schema: entryListSchema })
  if (!Array.isArray(document)) throw new Error('cordis.patch.yml: root must be a patch list')
  return document as PatchOptions[]
}

/** Scripted adapter whose requests are recorded for assertions. */
class RecordingAdapter extends LlmAdapter {
  requests: GenerateOptions[] = []

  constructor(private script: StreamChunk[][]) {
    super()
  }

  override resolveModel(provider: string, model: string) {
    return Promise.resolve({ provider, id: model, name: model })
  }

  async * stream(options: GenerateOptions): AsyncIterable<StreamChunk> {
    this.requests.push(options)
    const entry = this.script.shift()
    if (entry === undefined) throw new Error('RecordingAdapter: script exhausted')
    for (const chunk of entry) {
      if (options.signal?.aborted) throw new Error('aborted')
      yield chunk
    }
  }
}

let root: string | undefined
let context: Context | undefined
let adapter: RecordingAdapter | undefined

afterEach(async () => {
  await context?.fiber.dispose()
  context = undefined
  adapter = undefined
  if (root !== undefined) await rm(root, { recursive: true, force: true })
  root = undefined
})

async function loadYaml(lines: readonly string[], patches?: PatchOptions[]): Promise<Context> {
  root = await mkdtemp(join(tmpdir(), 'dsh-subagent-router-loader-'))
  const configPath = join(root, 'cordis.yml')
  await writeFile(configPath, [...lines, ''].join('\n'))

  const ctx = new Context()
  ctx.baseUrl = pathToFileURL(root).href + '/'
  await ctx.plugin(Loader)
  ctx.loader.builtins.include = Include
  const modules = new Map<string, unknown>([
    ['@deepseek-ai/dsh-agent', AgentRegistry],
    ['@deepseek-ai/dsh-agent-loop', AgentLoop],
    ['@deepseek-ai/dsh-llm', LlmRuntime],
    ['@deepseek-ai/dsh-session', SessionStore],
    ['@deepseek-ai/dsh-session-persistence-jsonl', JsonlSessionPersistence],
    ['@deepseek-ai/dsh-session-projection', SessionProjectionRegistry],
    ['@deepseek-ai/dsh-subagent', SubagentRuntime],
    ['@deepseek-ai/dsh-subagent-fork-in-process', SubagentFork],
    ['@deepseek-ai/dsh-subagent-spawn-in-process', SubagentSpawn],
    ['@deepseek-ai/dsh-system-prompt', SystemPrompt],
    ['@deepseek-ai/dsh-tool-subagent', officialToolSubagent],
    ['@deepseek-ai/dsh-tool-subagent-control', control],
    ['@deepseek-ai/dsh-tool-subagent-control/list-agents', listAgents],
    ['@deepseek-ai/dsh-tools', ToolRuntime],
    ['@xmoon76/dsh-subagent-router', (await import('../src/index.ts'))],
  ])
  ctx.loader.internal = {
    version: 'v2',
    async import(specifier: string) {
      if (!modules.has(specifier)) throw new Error(`unexpected Loader import: ${specifier}`)
      return modules.get(specifier)
    },
  } as unknown as NonNullable<typeof ctx.loader.internal>
  await ctx.loader.create({
    name: 'cordis:include',
    config: {
      path: pathToFileURL(configPath).href,
      ...patches !== undefined ? { patches } : {},
    },
  })
  await ctx.loader.await()
  return ctx
}

const testToolSignal = new AbortController().signal

/** The minimal service topology a routed subagent needs behind the Loader. */
const SERVICE_TOPOLOGY = [
  "- name: '@deepseek-ai/dsh-llm'",
  "- name: '@deepseek-ai/dsh-session'",
  "- name: '@deepseek-ai/dsh-system-prompt'",
  '  config: {}',
  "- name: '@deepseek-ai/dsh-tools'",
  '  config: {}',
  "- name: '@deepseek-ai/dsh-agent'",
  "- name: '@deepseek-ai/dsh-agent-loop'",
  '  config:',
  '    agents: []',
  "- name: '@deepseek-ai/dsh-session-persistence-jsonl'",
  '  config:',
  '    root: ./sessions',
  "- name: '@deepseek-ai/dsh-session-projection'",
  "- name: '@deepseek-ai/dsh-subagent'",
  "- name: '@deepseek-ai/dsh-subagent-spawn-in-process'",
] as const

/**
 * The dsh-base analogue PLUS the official delegation/control rows: the
 * composition a real profile loads when the official tools are mounted.
 */
const OFFICIAL_TOPOLOGY = [
  ...SERVICE_TOPOLOGY,
  "- name: '@deepseek-ai/dsh-subagent-fork-in-process'",
  "- name: '@deepseek-ai/dsh-tool-subagent'",
  '  config:',
  '    provider: spawn',
  '    toolName: subagent',
  '    backgroundMode: continuable',
  '    agentOptions:',
  '      provider: mock',
  '      model: mock',
  "- name: '@deepseek-ai/dsh-tool-subagent'",
  '  config:',
  '    provider: fork',
  '    toolName: subagent_fork',
  '    backgroundMode: one-shot',
  '    agentOptions:',
  '      provider: mock',
  '      model: mock',
  "- name: '@deepseek-ai/dsh-tool-subagent-control'",
  "- name: '@deepseek-ai/dsh-tool-subagent-control/list-agents'",
] as const

describe('real Loader composition', () => {
  it('loads the plugin by name and exposes the subagent_route schema', async () => {
    context = await loadYaml([
      ...SERVICE_TOPOLOGY,
      "- name: '@xmoon76/dsh-subagent-router'",
      '  config:',
      // Legacy `executionMode` alias still loads through the real Loader.
      '    executionMode: continuable',
      '    subagentProvider: spawn',
    ])

    const ctx = context
    if (ctx === undefined) throw new Error('expected a loaded context')
    const unloaded = [...ctx.loader.entries()]
      .filter(entry => entry.fiber === undefined && !entry.disabled)
      .map(entry => entry.options.name)
    expect(unloaded).toEqual([])

    const schema = ctx.tools.schemas().find(s => s.name === 'subagent_route')
    expect(schema).toBeDefined()
    const props = (schema!.parameters as { properties?: Record<string, unknown> }).properties ?? {}
    expect(Object.keys(props).sort()).toEqual(['description', 'model', 'prompt', 'provider', 'run_in_background'])
  })

  it('creates a routed continuable child through the loaded composition', async () => {
    adapter = new RecordingAdapter([textResponse('loader child answer')])
    context = await loadYaml([
      ...SERVICE_TOPOLOGY,
      "- name: '@xmoon76/dsh-subagent-router'",
      '  config:',
      '    backgroundMode: continuable',
      '    subagentProvider: spawn',
    ])
    // Register the scripted route after boot (the Loader composition carries
    // no real LLM adapter).
    const ctx = context
    if (ctx === undefined) throw new Error('expected a loaded context')
    ctx.llm.registerAdapter(['mock'], adapter)

    // The composition pre-creates no agent; create a stand-in parent whose
    // turns are rejected so its settlement wake never consumes the script.
    const parent = ctx.agentLoop.create(SessionId('loader-parent'), { provider: 'mock', model: 'mock' })
    ctx.on('agent/pre-step', async ({ agent: subject }, next) => {
      if (subject.id !== parent.id) return next()
      return { kind: 'reject' as const }
    })

    const result = await ctx.tools.execute({
      signal: testToolSignal,
      callId: CallId('loader-1'),
      name: 'subagent_route',
      arguments: {
        description: 'loader task',
        prompt: 'do the thing',
        provider: 'mock',
        model: 'mock',
      },
      agent: parent,
    })
    expect(result.isError).toBe(false)
    const match = /^started subagent (\S+)$/.exec(
      result.content.filter(b => b.type === 'text').map(b => b.text).join(''),
    )
    expect(match).not.toBeNull()
    const childId = match![1] as string

    // The child ran one model turn on the selected route.
    await vi.waitFor(() => {
      expect(adapter!.requests).toHaveLength(1)
    }, { timeout: 5_000 })
    expect(adapter!.requests[0]!.provider).toBe('mock')
    expect(adapter!.requests[0]!.model).toBe('mock')

    // The durable child session carries the continuation descriptor with the
    // routed provider/model.
    await vi.waitFor(() => {
      expect(ctx.agents.get(SessionId(childId))).toBeUndefined()
    }, { timeout: 5_000 })
    const loaded = await ctx.sessionPersistence.load(SessionId(childId))
    const descriptor = loaded.events.find(event => event.type === 'subagent/descriptor')
    expect(descriptor?.type === 'subagent/descriptor' && descriptor.data).toMatchObject({
      mode: 'continuable',
      provider: 'spawn',
      agentProvider: 'mock',
      agentModel: 'mock',
    })
  })

  it('rejects a route outside the deployment allowlist through the loader', async () => {
    context = await loadYaml([
      ...SERVICE_TOPOLOGY,
      "- name: '@xmoon76/dsh-subagent-router'",
      '  config:',
      '    backgroundMode: continuable',
      '    subagentProvider: spawn',
      '    allowedProviders:',
      '      - allowed',
    ])

    const ctx = context
    if (ctx === undefined) throw new Error('expected a loaded context')
    const parent = ctx.agentLoop.create(SessionId('loader-parent2'), { provider: 'mock', model: 'mock' })
    const result = await ctx.tools.execute({
      signal: testToolSignal,
      callId: CallId('loader-2'),
      name: 'subagent_route',
      arguments: {
        description: 'denied',
        prompt: 'x',
        provider: 'denied',
        model: 'mock',
      },
      agent: parent,
    })
    expect(result.isError).toBe(true)
    expect(result.content.filter(b => b.type === 'text').map(b => b.text).join(''))
      .toContain('not allowed')
  })

  it('mounts both router rows from the shipped bundle patch layer', async () => {
    // The profile composes a base topology (the dsh-base layer analogue) and
    // the bundle's patch on top — the same layered mechanism the profile
    // composer uses (applyEntryPatches over the base entry list). The bundle's
    // own cordis.patch.yml supplies both router rows; the fork backend row is
    // a dsh-base row a real profile has, added here for the minimal topology.
    context = await loadYaml(
      [...SERVICE_TOPOLOGY, "- name: '@deepseek-ai/dsh-subagent-fork-in-process'"],
      bundlePatch(),
    )

    const ctx = context
    if (ctx === undefined) throw new Error('expected a loaded context')
    expect([...ctx.loader.entries()].filter(entry => entry.options.name === '@xmoon76/dsh-subagent-router').length)
      .toBe(2)

    // Both bundle instances registered under their distinct tool names.
    const names = ctx.tools.schemas().map(s => s.name).sort()
    expect(names).toContain('subagent_route')
    expect(names).toContain('subagent_fork_route')
    // Same model-facing parameter set on both (description/prompt/provider/
    // model plus the optional run_in_background scheduling override).
    for (const toolName of ['subagent_route', 'subagent_fork_route']) {
      const schema = ctx.tools.schemas().find(s => s.name === toolName)
      expect(schema).toBeDefined()
      const props = (schema!.parameters as { properties?: Record<string, unknown> }).properties ?? {}
      expect(Object.keys(props).sort()).toEqual(['description', 'model', 'prompt', 'provider', 'run_in_background'])
    }
  })

  it('coexists with the official tools at the Loader level: schemas unchanged, official subagent + subagent_fork + router fork all executable', async () => {
    // Load the official composition WITHOUT the router row first, so the
    // official schemas can be captured before the router joins.
    context = await loadYaml([...OFFICIAL_TOPOLOGY])
    const ctx = context
    if (ctx === undefined) throw new Error('expected a loaded context')
    const officialSchemaOf = (name: string) => {
      const schema = ctx.tools.schemas().find(s => s.name === name)
      if (schema === undefined) throw new Error(`expected tool schema "${name}"`)
      return { name: schema.name, description: schema.description, parameters: schema.parameters }
    }
    const before = new Map(
      ['subagent', 'subagent_fork', 'send_message', 'interrupt_agent', 'list_agents']
        .map(name => [name, officialSchemaOf(name)]),
    )

    // The router joins the SAME context afterwards (as bundle rows would be
    // mounted by the profile composer): BOTH default instances.
    const router = await import('../src/index.ts')
    await ctx.plugin(router, { subagentProvider: 'spawn', backgroundMode: 'continuable' })
    await ctx.plugin(router, { subagentProvider: 'fork', backgroundMode: 'one-shot', toolName: 'subagent_fork_route' })

    const names = ctx.tools.schemas().map(s => s.name).sort()
    expect(names).toContain('subagent')
    expect(names).toContain('subagent_route')
    expect(names).toContain('subagent_fork')
    expect(names).toContain('subagent_fork_route')
    expect(names).toContain('send_message')
    expect(names).toContain('interrupt_agent')
    expect(names).toContain('list_agents')

    // Official schemas are deep-equal before/after the router joined.
    for (const name of ['subagent', 'subagent_fork', 'send_message', 'interrupt_agent', 'list_agents']) {
      expect(officialSchemaOf(name)).toEqual(before.get(name))
    }

    // Register the scripted route and drive ALL FOUR delegation tools.
    adapter = new RecordingAdapter([
      textResponse('official spawn answer'),
      textResponse('official fork answer'),
      textResponse('router spawn answer'),
      textResponse('router fork answer'),
    ])
    ctx.llm.registerAdapter(['mock'], adapter)
    const parent = ctx.agentLoop.create(SessionId('loader-parent-fork'), { provider: 'mock', model: 'mock' })
    ctx.on('agent/pre-step', async ({ agent: subject }, next) => {
      if (subject.id !== parent.id) return next()
      return { kind: 'reject' as const }
    })

    // Official spawn (continuable, background by default) still executes
    // through its own path: it returns a durable subagent id.
    const officialSpawn = await ctx.tools.execute({
      signal: testToolSignal,
      callId: CallId('loader-official-spawn'),
      name: 'subagent',
      arguments: { description: 'official spawn', prompt: 'go' },
      agent: parent,
    })
    expect(officialSpawn.isError).toBe(false)
    const spawnText = officialSpawn.content.filter(b => b.type === 'text').map(b => b.text).join('')
    expect(spawnText).toMatch(/^started subagent \S+$/)
    const spawnChildId = /^started subagent (\S+)$/.exec(spawnText)![1] as string
    // The child actually ran (its durable session exists and produced a turn).
    await vi.waitFor(() => {
      expect(adapter!.requests.length).toBeGreaterThanOrEqual(1)
    }, { timeout: 5_000 })
    expect(spawnChildId).toBeTruthy()

    // Official fork (one-shot) still executes through its own path.
    const officialFork = await ctx.tools.execute({
      signal: testToolSignal,
      callId: CallId('loader-official-fork'),
      name: 'subagent_fork',
      arguments: { description: 'official fork', prompt: 'analyze' },
      agent: parent,
    })
    expect(officialFork.isError).toBe(false)
    expect(officialFork.content.filter(b => b.type === 'text').map(b => b.text).join(''))
      .toBe('official fork answer')

    // Router spawn (continuable) executes with the dynamic route.
    const routedSpawn = await ctx.tools.execute({
      signal: testToolSignal,
      callId: CallId('loader-router-spawn'),
      name: 'subagent_route',
      arguments: {
        description: 'router spawn',
        prompt: 'go',
        provider: 'mock',
        model: 'mock',
      },
      agent: parent,
    })
    expect(routedSpawn.isError).toBe(false)
    const routedSpawnText = routedSpawn.content.filter(b => b.type === 'text').map(b => b.text).join('')
    expect(routedSpawnText).toMatch(/^started subagent \S+$/)
    const routedSpawnChildId = /^started subagent (\S+)$/.exec(routedSpawnText)![1] as string
    await vi.waitFor(() => {
      expect(adapter!.requests.length).toBeGreaterThanOrEqual(2)
    }, { timeout: 5_000 })
    expect(routedSpawnChildId).toBeTruthy()

    // Router fork (one-shot) still executes.
    const routed = await ctx.tools.execute({
      signal: testToolSignal,
      callId: CallId('loader-router-fork'),
      name: 'subagent_fork_route',
      arguments: {
        description: 'router fork',
        prompt: 'review',
        provider: 'mock',
        model: 'mock',
      },
      agent: parent,
    })
    expect(routed.isError).toBe(false)
    expect(routed.content.filter(b => b.type === 'text').map(b => b.text).join('')).toBe('router fork answer')
  })

  it('bundle + official composition: all seven tools coexist and both router instances execute', async () => {
    // The shipped bundle patch (both router rows) over the official base
    // topology: the full real-profile surface.
    context = await loadYaml([...OFFICIAL_TOPOLOGY], bundlePatch())

    const ctx = context
    if (ctx === undefined) throw new Error('expected a loaded context')
    // Requirement: final tool set contains ALL of
    // subagent / subagent_route / subagent_fork / subagent_fork_route /
    // send_message / interrupt_agent / list_agents.
    const names = ctx.tools.schemas().map(s => s.name).sort()
    for (const expected of [
      'subagent',
      'subagent_route',
      'subagent_fork',
      'subagent_fork_route',
      'send_message',
      'interrupt_agent',
      'list_agents',
    ]) {
      expect(names.filter(name => name === expected)).toHaveLength(1)
    }

    // Both router instances execute with the dynamic route:
    // subagent_route -> startContinuable(spawn), subagent_fork_route -> start(fork).
    adapter = new RecordingAdapter([
      textResponse('router spawn answer'),
      textResponse('router fork answer'),
    ])
    ctx.llm.registerAdapter(['mock'], adapter)
    const parent = ctx.agentLoop.create(SessionId('loader-bundle-coexist'), { provider: 'mock', model: 'mock' })
    ctx.on('agent/pre-step', async ({ agent: subject }, next) => {
      if (subject.id !== parent.id) return next()
      return { kind: 'reject' as const }
    })

    const spawnResult = await ctx.tools.execute({
      signal: testToolSignal,
      callId: CallId('bundle-spawn'),
      name: 'subagent_route',
      arguments: { description: 'bundle spawn', prompt: 'go', provider: 'mock', model: 'mock' },
      agent: parent,
    })
    expect(spawnResult.isError).toBe(false)
    const spawnText = spawnResult.content.filter(b => b.type === 'text').map(b => b.text).join('')
    expect(spawnText).toMatch(/^started subagent \S+$/)
    const spawnChildId = /^started subagent (\S+)$/.exec(spawnText)![1] as string
    await vi.waitFor(() => {
      expect(adapter!.requests.length).toBeGreaterThanOrEqual(1)
    }, { timeout: 5_000 })
    expect(spawnChildId).toBeTruthy()

    const forkResult = await ctx.tools.execute({
      signal: testToolSignal,
      callId: CallId('bundle-fork'),
      name: 'subagent_fork_route',
      arguments: { description: 'bundle fork', prompt: 'review', provider: 'mock', model: 'mock' },
      agent: parent,
    })
    expect(forkResult.isError).toBe(false)
    expect(forkResult.content.filter(b => b.type === 'text').map(b => b.text).join(''))
      .toBe('router fork answer')
  })

  it('lets a profile overlay override the bundle default router config', async () => {
    // The profile's own patch overrides the bundle row's whole config
    // (patch semantics: replace config for the row id).
    context = await loadYaml([...SERVICE_TOPOLOGY], [
      ...bundlePatch(),
      {
        id: 'tool-subagent-router',
        config: {
          subagentProvider: 'spawn',
          backgroundMode: 'continuable',
          toolName: 'subagent_route',
          maxDepth: 5,
          allowedProviders: ['deepseek-official'],
        },
      },
    ])

    const ctx = context
    if (ctx === undefined) throw new Error('expected a loaded context')
    // The override replaced the bundle row's config WHOLESALE: the final
    // Loader entry carries the profile's full config (maxDepth 5,
    // allowedProviders) and none of the bundle's defaults.
    const entry = [...ctx.loader.entries()].find(e => e.options.name === '@xmoon76/dsh-subagent-router')
    expect(entry).toBeDefined()
    const finalConfig = entry!.options.config as Record<string, unknown>
    expect(finalConfig.maxDepth).toBe(5)
    expect(finalConfig.allowedProviders).toEqual(['deepseek-official'])
    expect(finalConfig.subagentProvider).toBe('spawn')
    expect(finalConfig.toolName).toBe('subagent_route')
    // The bundle's default maxDepth 3 must NOT survive (full replacement).
    expect('maxDepth' in finalConfig ? finalConfig.maxDepth === 3 : false).toBe(false)

    const schema = ctx.tools.schemas().find(s => s.name === 'subagent_route')
    expect(schema).toBeDefined()
    // Executing with a provider outside the override allowlist must fail.
    const parent = ctx.agentLoop.create(SessionId('loader-override'), { provider: 'mock', model: 'mock' })
    const result = await ctx.tools.execute({
      signal: testToolSignal,
      callId: CallId('loader-override-1'),
      name: 'subagent_route',
      arguments: { description: 'denied', prompt: 'x', provider: 'mock', model: 'mock' },
      agent: parent,
    })
    expect(result.isError).toBe(true)
    expect(result.content.filter(b => b.type === 'text').map(b => b.text).join(''))
      .toContain('not allowed')
  })

  it('executes the bundle\'s default fork instance (subagent_fork_route) through the Loader', async () => {
    // The bundle patch ships BOTH instances; the fork backend row comes from
    // the dsh-base layer in a real profile, added here for the minimal
    // topology. This proves the bundle's own fork+one-shot row works
    // end-to-end (not just the spawn default).
    context = await loadYaml([...SERVICE_TOPOLOGY, "- name: '@deepseek-ai/dsh-subagent-fork-in-process'"], [
      ...bundlePatch(),
    ])

    const ctx = context
    if (ctx === undefined) throw new Error('expected a loaded context')
    // Both router instances registered under their distinct tool names.
    const names = ctx.tools.schemas().map(s => s.name).sort()
    expect(names).toContain('subagent_route')
    expect(names).toContain('subagent_fork_route')

    // Both Loader rows exist with their distinct ids, and the fork row's
    // final config binds fork + one-shot + subagent_fork_route.
    const rows = [...ctx.loader.entries()].filter(e => e.options.name === '@xmoon76/dsh-subagent-router')
    expect(rows.map(r => r.options.id)).toEqual(
      expect.arrayContaining(['tool-subagent-router', 'tool-subagent-router-fork']),
    )
    const forkRow = rows.find(r => r.options.id === 'tool-subagent-router-fork')
    expect(forkRow).toBeDefined()
    const forkConfig = forkRow!.options.config as Record<string, unknown>
    expect(forkConfig.subagentProvider).toBe('fork')
    expect(forkConfig.backgroundMode).toBe('one-shot')
    expect(forkConfig.enableRunInBackground).toBe(true)
    expect(forkConfig.toolName).toBe('subagent_fork_route')
    expect(forkConfig.maxDepth).toBe(3)

    // The fork instance executes a one-shot fork through the Loader.
    adapter = new RecordingAdapter([textResponse('second instance answer')])
    ctx.llm.registerAdapter(['mock'], adapter)
    const parent = ctx.agentLoop.create(SessionId('loader-second'), { provider: 'mock', model: 'mock' })
    ctx.on('agent/pre-step', async ({ agent: subject }, next) => {
      if (subject.id !== parent.id) return next()
      return { kind: 'reject' as const }
    })
    const result = await ctx.tools.execute({
      signal: testToolSignal,
      callId: CallId('loader-second-1'),
      name: 'subagent_fork_route',
      arguments: { description: 'second', prompt: 'review', provider: 'mock', model: 'mock' },
      agent: parent,
    })
    expect(result.isError).toBe(false)
    expect(result.content.filter(b => b.type === 'text').map(b => b.text).join(''))
      .toBe('second instance answer')
  })
})
