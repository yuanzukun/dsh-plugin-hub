# DSH 动态模型 Continuable Subagent 插件实施计划

> 目标：为 DeepSeek Harness（DSH）实现一个符合现有插件/包开发规范的 model-facing 工具插件，使主 Agent 可以在创建子 Agent 时动态指定 **LLM provider + model**，并创建 **continuable** 子 Agent；后续继续对话、列出和中断子 Agent 复用 DSH 官方 `@deepseek-ai/dsh-tool-subagent-control` 的 `send_message` / `list_agents` / `interrupt_agent`。
>
> 本计划按 2026-08-19 当前 `deepseek-ai/deepseek-harness` master 架构编写，参考代码快照主要落在提交 `99f6f02fecdb7dff40c3fbc9470f5907c29f74ca` 附近。实现时应再次对照当前 master，避免复制已经发生变化的私有实现。

> **2026-08-20 名称迁移注记**：本历史计划写作时的默认工具名 `subagent_route`
> 已按最终产品决策改为 `subagent_route`（见
> `2026-08-20-002-dsh-subagent-router-final-optimization-plan.md` §10）。
> 本文档中所有 `subagent_route` 已统一替换为 `subagent_route`，仅作历史
> 记录一致性处理。

---

## 1. 项目结论

该插件可以在 **不修改 `dsh-subagent` core、不新增 Subagent Provider、不复制 continuation manager** 的前提下实现。

推荐实现方式：

```text
Main Agent
   │
   │ subagent_route(...)
   ▼
自定义 model-facing Consumer plugin
   │
   │ ctx.subagents.startContinuable(...)
   ▼
@deepseek-ai/dsh-subagent
   │
   ├─ stable child Session ID
   ├─ descriptor persistence
   ├─ continuation manager
   ├─ cold resume
   ├─ direct-parent authorization
   └─ FIFO Agent inbox
   │
   ▼
subagent backend: spawn
   │
   ▼
Child Agent
   ├─ LLM provider = tool 参数 provider
   └─ LLM model    = tool 参数 model
```

后续继续对话：

```text
Main Agent
   │
   │ send_message(subagent_id, message)
   ▼
@deepseek-ai/dsh-tool-subagent-control
   │
   ▼
ctx.subagents.followup(...)
   │
   ▼
同一个 durable child Session
   │
   ├─ resident -> 同一个 Activation 的下一轮
   └─ cold     -> 从 Session 恢复后下一轮
```

### 核心设计原则

1. **插件只做 Consumer，不重新实现能力层。**
2. **子 Agent backend 固定/由部署配置决定，模型只选择 LLM provider/model。**
3. **provider/model 只在 child 创建时指定，continue 时不允许切换模型。**
4. **不把 API Key、Base URL、endpoint 等凭证或基础设施参数暴露给模型。**
5. **continue 复用官方 control tool，不重复注册 `send_message`。**
6. **首版只实现 continuable background 创建，不人为模拟 foreground result。**
7. **不持久化或承诺 `maxTokens`，因为 DSH 当前 continuable descriptor 明确不持久化该 per-activation 参数。**
8. **严格遵循 DSH function plugin 的 named-export、测试、README、invariant、HMR cleanup 和 workspace constraint 规范。**

---

# 2. 需求定义

## 2.1 必须实现

插件必须提供一个新的 model-facing tool，建议默认命名：

```text
subagent_route
```

示例：

```json
{
  "description": "Review current changes",
  "prompt": "Inspect the current git diff and review correctness, regressions and missing tests.",
  "provider": "openai",
  "model": "gpt-5.6"
}
```

成功后返回：

```json
{
  "kind": "continuable",
  "subagentId": "ses_xxxxxxxxx"
}
```

主 Agent 随后可以使用 DSH 官方：

```text
send_message
list_agents
interrupt_agent
```

继续操作该 child。

---

## 2.2 必须支持的生命周期

### 创建

```text
subagent_route
  -> startContinuable()
  -> child Session 创建
  -> 初始 prompt 被 inbox 接受
  -> 返回 durable subagentId
```

注意：

`startContinuable()` 返回的成功边界是 **初始消息被 child inbox 接受**，不是子 Agent 已经执行完任务。

这是正确语义，不要在插件里伪造“子 Agent 已执行完成”。

### 执行完成

continuation manager 会负责 child Activation 的生命周期，并向 parent 发送 settlement notice。

### Continue

后续：

```text
send_message(
  subagent_id="ses_xxx",
  message="Now focus on concurrency races."
)
```

应成为 child 的下一轮 FIFO turn。

### Cold Resume

如果 child 已不在内存中，但 Session persistence 中存在：

```text
send_message
  -> ctx.subagents.followup()
  -> cold resume
  -> 根据 persisted descriptor 重建 child
  -> 继续同一 Session
```

插件本身不参与恢复逻辑。

---

# 3. 明确的非目标

首版不要实现以下功能：

- 不修改 `@deepseek-ai/dsh-subagent`
- 不修改 continuation manager
- 不实现自定义 Session 数据库
- 不自己创建 `AgentHandle`
- 不自己 cold resume
- 不自己管理 child FIFO
- 不复制 `send_message`
- 不注册另一个 `list_agents`
- 不注册另一个 `interrupt_agent`
- 不支持 continue 时切换 provider/model
- 不支持从 tool 参数传 API key
- 不支持从 tool 参数传 baseURL
- 不支持动态添加新的 LLM adapter
- 不支持任意 subagent backend 由模型选择
- 不把 `spawn` / `fork` / ACP 等 transport 暴露给模型
- 不把 `maxTokens` 暴露为 durable child 属性
- 不实现 one-shot 模式
- 不实现 `outputSchema`
- 不实现 workflow / Ralph 语义
- 不重新发明任务状态机或 job system

如果未来确有需求，再进入 V2。

---

# 4. DSH 当前架构依据

实现前必须阅读并对照：

```text
packages/AGENTS.md
docs/testing.md
docs/cookbook/adding-a-package.md
docs/user/develop/basic/index.md
docs/user/develop/basic/tool.md

packages/subagent/subagent/src/index.ts
packages/subagent/subagent/src/types.ts
packages/subagent/subagent/src/continuation.ts
packages/subagent/subagent/src/descriptor.ts

packages/subagent/tool-subagent/src/index.ts
packages/subagent/tool-subagent/README.md

packages/subagent/tool-subagent-control/README.md

packages/subagent/subagent-spawn-in-process/src/index.ts
```

尤其不要脱离现有实现自己推断 continuation contract。

---

# 5. 为什么 `startContinuable()` 正好满足需求

DSH 当前公开 contract：

```ts
interface ContinuableStartSpec {
  provider: string
  label: string
  request: Omit<
    SubagentStartRequest,
    'label' | 'signal' | 'outputSchema'
  >
  signal: AbortSignal
}
```

而：

```ts
interface SubagentStartRequest {
  prompt: ContentBlock[]
  parent: Agent
  signal: AbortSignal
  agentOptions?: AgentOptions
  maxDepth?: number
  toolFilter?: ToolRestriction
  persona?: string
  // ...
}
```

因此插件可以合法构造：

```ts
await ctx.subagents.startContinuable({
  provider: config.subagentProvider,
  label: args.description,
  request: {
    parent: exec.agent,
    prompt: [
      {
        type: 'text',
        text: args.prompt,
      },
    ],
    agentOptions: {
      provider: args.provider,
      model: args.model,
    },
    maxDepth: config.maxDepth,
    persona: config.persona,
    toolFilter: config.toolFilter,
  },
  signal: exec.signal,
})
```

这不是 hack，而是公开 Service Definition 明确支持的 Consumer 用法。

---

# 6. Provider 的两个不同概念

这是插件实现中最重要的命名问题。

## 6.1 Subagent Provider

属于：

```text
ctx.subagents
```

例如：

```text
spawn
fork
acp
codex
claude-code
dsh-sdk
```

它表示 child 的创建/transport/composition backend。

插件配置里建议明确叫：

```text
subagentProvider
```

默认：

```yaml
subagentProvider: spawn
```

---

## 6.2 LLM Provider

属于 child 的：

```text
agentOptions.provider
```

例如：

```text
deepseek
openai
anthropic
xai
...
```

它由模型调用 `subagent_route` 时传入：

```json
{
  "provider": "openai",
  "model": "gpt-5.6"
}
```

因此内部映射必须清楚：

```text
config.subagentProvider
        ↓
ctx.subagents backend

args.provider
        ↓
child AgentOptions.provider

args.model
        ↓
child AgentOptions.model
```

禁止把这三个字段混为一谈。

---

# 7. 推荐包名与目录

如果作为 DSH fork / upstream-style workspace package 开发，建议：

```text
packages/subagent/tool-subagent-router/
```

manifest：

```text
@deepseek-ai/dsh-tool-subagent-router
```

插件 Cordis name：

```ts
export const name = 'tool-subagent-router'
```

默认 model-facing tool：

```text
subagent_route
```

这里的 “router” 指本 Consumer 负责把模型选择的 LLM route 放入 child composition，而不是新建一个 Subagent Runtime。

如果最终作为第三方 npm 包发布，不应冒用 `@deepseek-ai` scope，应改为：

```text
@your-scope/dsh-tool-subagent-router
```

但源代码结构和设计保持一致。

---

# 8. 建议文件结构

```text
packages/subagent/tool-subagent-router/
├── package.json
├── tsconfig.json
├── README.md
├── src/
│   ├── index.ts
│   └── invariant.ts
└── tests/
    ├── tool-subagent-router.spec.ts
    ├── real-composition.e2e.ts
    ├── harness.ts
    └── fixtures/
        └── cordis.yml
```

不要：

```text
src/__tests__/
```

DSH 当前规范要求测试位于包级 `tests/`。

---

# 9. Function Plugin 导出规范

必须使用 function plugin 的 named exports：

```ts
export const name = 'tool-subagent-router'
export const inject = ['tools', 'subagents']

export interface Config {
  // ...
}

export const Config = ...

export function apply(ctx: Context, config: Config): void {
  // ...
}
```

**禁止添加 default export。**

不要写：

```ts
export default {
  name,
  inject,
  apply,
}
```

更不要同时存在 named plugin exports 和 default export。

DSH 当前 `packages/AGENTS.md` 明确要求：

- function plugins：named-export `name` / `inject` / `Config` / `apply`
- no default export

这是 Loader 兼容性要求，不只是风格偏好。

---

# 10. 插件 Config 设计

建议首版：

```ts
export interface Config {
  /**
   * ctx.subagents backend.
   * Defaults to spawn.
   */
  subagentProvider?: string

  /**
   * Model-facing tool name.
   * Defaults to subagent_route.
   */
  toolName?: string

  /**
   * Absolute delegation depth cap.
   * Defaults to 3.
   */
  maxDepth?: number | 'provider-managed'

  /**
   * Optional child persona controlled by deployment.
   */
  persona?: string

  /**
   * Optional child tool restriction controlled by deployment.
   */
  toolFilter?: {
    allow?: string[]
    deny?: string[]
  }

  /**
   * Optional deployment-side LLM provider allowlist.
   * Omitted = any already-registered DSH LLM provider may be selected.
   */
  allowedProviders?: string[]
}
```

### Schemastery

必须声明 runtime `Config`：

```ts
export const Config: z<Config> = z.object({
  subagentProvider: z.string().default('spawn'),
  toolName: z.string().default('subagent_route'),
  maxDepth: z.union([
    z.natural().max(Number.MAX_SAFE_INTEGER),
    z.const('provider-managed' as const),
  ]).default(3),

  persona: z.string(),

  toolFilter: z.object({
    allow: z.array(z.string()).default(undefined as unknown as string[]),
    deny: z.array(z.string()).default(undefined as unknown as string[]),
  }).default(
    undefined as unknown as {
      allow: string[]
      deny: string[]
    },
  ),

  allowedProviders: z.array(z.string())
    .default(undefined as unknown as string[]),
})
```

实现时应参考当前 `dsh-tool-subagent` 对 Schemastery omission 的处理，不要让：

```yaml
toolFilter: {}
```

被意外 materialize 成：

```yaml
allow: []
```

从而把 child 所有工具全部过滤掉。

---

# 11. 为什么 `allowedProviders` 应该是部署配置

主模型选择：

```text
provider/model
```

本身是本插件的目标。

但是模型不应该因此获得：

```text
API key
endpoint
base URL
adapter registration
```

的控制权。

因此信任边界应为：

```text
部署管理员先配置 DSH LLM adapters/routes
                    ↓
插件只允许模型在这些已注册 route 中选择
```

`allowedProviders` 进一步允许部署限制：

```yaml
allowedProviders:
  - openai
  - deepseek
```

执行路径必须再次检查：

```ts
if (
  config.allowedProviders !== undefined
  && !config.allowedProviders.includes(args.provider)
) {
  throw new Error(...)
}
```

不能只通过 tool description 告诉模型“不要用”。

DSH 规范要求：

> 决策必须在真正做出该决策的 operation 中 enforce。

因此 allowlist 是 executor-level enforcement。

---

# 12. Tool Schema

建议：

```ts
ctx.tools.register(defineTool({
  name: toolName,

  description:
    'Start a continuable subagent using a selected configured LLM provider '
    + 'and model. The child runs in its own conversation and returns a durable '
    + 'subagent id immediately after its initial message is accepted. '
    + 'Use send_message with that id for later turns.',

  parameters: {
    description: {
      type: 'string',
      required: true,
      description:
        'A short 3-5 word label describing the delegated task.',
    },

    prompt: {
      type: 'string',
      required: true,
      description:
        'A complete standalone task for the child. The spawned child does not '
        + 'inherit this conversation.',
    },

    provider: {
      type: 'string',
      required: true,
      description:
        'The configured DSH LLM provider route for the child.',
    },

    model: {
      type: 'string',
      required: true,
      description:
        'The model id to use for this child conversation.',
    },
  },

  // ...
}))
```

---

# 13. 为什么 tool 参数不包含 `maxTokens`

DSH 当前 continuable descriptor 会持久化：

```text
agentProvider
agentModel
persona
toolFilter
```

但明确 **不会持久化**：

```text
maxTokens
```

这是因为 `maxTokens` 属于 per-activation budget。

如果首轮：

```text
maxTokens = 32768
```

然后 child settle，之后 cold resume：

```text
send_message(...)
```

恢复后的 activation 不保证继续使用这个值。

因此首版不要暴露：

```text
max_tokens
```

否则 tool schema 会暗示它属于整个 continuable conversation，而实际不是。

如未来需要该功能，应先确认 DSH upstream 是否已经改变 descriptor contract。

---

# 14. 为什么 continue 时不允许切 provider/model

创建时：

```text
provider = openai
model = gpt-5.6
```

DSH 会在 continuable descriptor 中保存：

```text
agentProvider
agentModel
```

因此 child 的 durable identity 实际包含其声明的 composition。

正确语义：

```text
ses_123
├─ initial turn   -> openai / gpt-5.6
├─ send_message  -> openai / gpt-5.6
└─ cold resume   -> openai / gpt-5.6
```

不要设计：

```text
send_message(
  subagent_id,
  provider="...",
  model="..."
)
```

也不要创建：

```text
subagent_continue(
  subagent_id,
  provider,
  model,
  ...
)
```

如果真的需要 mid-session model migration，应作为独立设计议题进入 `dsh-subagent`/descriptor 层，而不是在 Consumer plugin 偷换 durable composition。

---

# 15. Continuation 直接复用官方 control tools

插件本身只注册：

```text
subagent_route
```

不要注册：

```text
send_message
interrupt_agent
list_agents
```

这些已经由：

```text
@deepseek-ai/dsh-tool-subagent-control
```

负责。

官方 control tool 的语义：

```text
send_message(subagent_id, message)
    -> ctx.subagents.followup()
```

特点：

- direct-parent authorization 由 Subagent Runtime 执行
- message 成为 child 下一轮 FIFO turn
- child 正在执行时不会中途 steering 当前 turn
- child 已 cold 时自动恢复
- 返回 acceptance，不返回 child reply
- child 最终输出保存在自己的 durable transcript
- settlement/report 使用现有 DSH 机制

这样避免重复 control tool、工具名冲突和两套权限实现。

---

# 16. `subagent_route` 的执行逻辑

推荐核心逻辑：

```ts
async execute(args, exec) {
  const parent = exec.agent
  if (parent === undefined) {
    throw new Error(
      'subagent_route requires an agent-owned tool execution context',
    )
  }

  assertProviderAllowed(args.provider, config.allowedProviders)

  const started = await ctx.subagents.startContinuable({
    provider: subagentProvider,

    label: args.description,

    request: {
      parent,

      prompt: [
        {
          type: 'text',
          text: args.prompt,
        },
      ],

      agentOptions: {
        provider: args.provider,
        model: args.model,
      },

      ...(numericMaxDepth
        ? { maxDepth: config.maxDepth }
        : {}),

      ...(config.persona !== undefined
        ? { persona: config.persona }
        : {}),

      ...(config.toolFilter !== undefined
        ? { toolFilter: config.toolFilter }
        : {}),
    },

    signal: exec.signal,
  })

  return {
    kind: 'continuable',
    subagentId: started.childId,
  }
}
```

注意：

实际 TypeScript 写法要严格按当前 API 类型修正，不要为了让示例编译而使用 `as any`。

---

# 17. 输出 Contract

Canonical output：

```ts
{
  type: 'object',
  additionalProperties: false,
  properties: {
    kind: {
      type: 'string',
      required: true,
      const: 'continuable',
    },
    subagentId: {
      type: 'string',
      required: true,
    },
  },
}
```

建议 render：

```text
Started continuable subagent <id> with <provider>/<model>.
Use send_message with this subagent id for later turns.
```

注意：

provider/model 可以只存在 render，不一定进入 canonical value。

为了尽量贴近现有 `tool-subagent` contract，也可以保持：

```json
{
  "kind": "continuable",
  "subagentId": "..."
}
```

不增加其它字段。

---

# 18. 不应该伪造 foreground

首版不提供：

```text
run_in_background: false
```

原因：

公开 `startContinuable()` contract 返回的是：

```text
childId + messageId
```

其成功点是初始 inbox acceptance。

它没有直接返回“当前 child turn 的最终结果”。

官方 `tool-subagent` 内部可以有自己的完整组合策略，但第三方 Consumer 没有必要复制其中所有 foreground/background handling。

首版采用最真实、最稳定的 contract：

```text
continuable child = asynchronous durable conversation
```

如果调用方下一步必须依赖子 Agent 完成结果，应使用现有 settlement/report/transcript 模型，或以后设计明确的 wait/collect 能力。

不要用 polling Session 日志去模拟同步 RPC。

---

# 19. Spawn Backend

默认：

```yaml
subagentProvider: spawn
```

原因：

当前：

```text
@deepseek-ai/dsh-subagent-spawn-in-process
```

明确实现：

```ts
prepareContinuable(): Promise<ContinuableCreateSpec>
```

因此支持 `startContinuable()`。

而且 fresh spawn child：

```text
不继承 parent conversation
```

所以 tool prompt 文案必须要求：

```text
complete standalone prompt
```

不要告诉模型 child 能看到当前 parent conversation。

---

# 20. Fork 不作为首版默认

当前 fork 虽然源码中存在 `prepareContinuable()`，但 upstream 明确有注释说明 shipped composition 仍把 fork 当 one-shot 使用，涉及 prefix reuse / prompt schema 稳定性问题。

因此：

```text
subagentProvider = spawn
```

作为官方支持路径。

如果未来允许用户配置：

```yaml
subagentProvider: fork
```

必须在 mount 时验证该 provider 当前确实支持 continuable，并对当前 DSH 版本重新测试。

不要因为接口“看起来存在”就宣称 fork continuable 是产品级支持路径。

---

# 21. Provider 生命周期 / HMR

现有 `dsh-tool-subagent` 会跟随 Subagent Provider 生命周期：

```text
subagent/provider-added
subagent/provider-removed
```

自定义插件应参考并复用同样模式。

目标：

```text
configured backend available
        ↓
register subagent_route

backend removed / HMR
        ↓
dispose tool registration

backend re-added
        ↓
register again
```

不要长期暴露一个必然失败的 dead tool。

实现 Agent 应直接参考当前：

```text
packages/subagent/tool-subagent/src/index.ts
```

中的 mount/unmount lifecycle。

不要重新设计 provider registry。

---

# 22. LLM route 校验策略

## 首选行为

不使用：

```text
ctx.llm.listModels()
```

作为硬 whitelist。

DSH LLM 文档明确：

```text
model catalog != routing whitelist
```

adapter 可以支持不在 listModels() 中出现的动态 model id。

因此：

```text
provider/model 是否真正有效
```

最终应该交给 DSH LLM/Agent 的 authoritative resolution。

---

## 可选 preflight

如果后续认为错误提示过晚，可以注入：

```text
llm
```

然后使用：

```ts
ctx.llm.resolveModelInfo(
  args.provider,
  args.model,
  exec.signal,
)
```

但这属于可选优化，不是首版必须。

不要：

```text
if (!listModels().includes(model)) reject
```

这会破坏 DSH 当前动态 model route contract。

---

# 23. 错误处理原则

必须 fail loud。

典型错误：

### 无 Agent execution context

```text
subagent_route requires an agent-owned tool execution context
```

### provider 被 deployment allowlist 拒绝

```text
LLM provider "xxx" is not allowed by this tool deployment
```

### subagent backend 不支持 continuable

在 tool mount / provider attach 的最早可靠时间失败：

```text
configured subagent provider "xxx" does not support continuable children
```

### child route/model 无效

保留 DSH authoritative error chain，不要把它吞掉后返回：

```json
{
  "ok": false
}
```

Tool registry 会把 throw 归一化为 errored tool result。

---

# 24. Cancellation

必须把：

```ts
exec.signal
```

传给：

```ts
ctx.subagents.startContinuable(...)
```

该 signal 的 ownership 到：

```text
initial child inbox acceptance
```

为止。

一旦 child 已接受 initial prompt：

```text
parent tool call 后续取消
```

不应该把已经接受的 child turn 擅自撤销。

不要再加第二套 AbortController，除非有一个明确独立生命周期 owner。

---

# 25. Persona / Tool Filter

这些参数不应该由主模型动态指定。

建议作为 deployment config：

```yaml
persona: |
  You are an independent code reviewer.
```

以及：

```yaml
toolFilter:
  deny:
    - some_mutating_tool
```

continuable descriptor 当前会持久化：

```text
persona
toolFilter
```

因此 cold resume 可以保持 child composition。

---

# 26. Max Depth

保持与官方 `tool-subagent` 一致的概念：

```yaml
maxDepth: 3
```

或者：

```yaml
maxDepth: provider-managed
```

实现：

```ts
if (config.maxDepth !== 'provider-managed') {
  assertSubagentMaxDepth(config.maxDepth)
}
```

numeric maxDepth 只在 backend 声明支持 `depthLimit` 时使用。

对于 `spawn` 当前支持该能力。

不要只靠 prompt 写：

```text
do not create more subagents
```

真正 recursion cap 要在 operation/backend 能 enforce 的层实现。

---

# 27. Model-facing 文案

工具文案不要泄露无关内部实现。

模型需要知道：

- 它可以创建独立 continuable child
- provider 是已经配置的 DSH LLM provider route
- model 是该 route 的 model id
- child 是 fresh conversation
- initial prompt 必须 self-contained
- 调用后返回 durable subagent id
- 后续通过 `send_message`

模型不需要知道：

- Activation
- AgentHandle
- continuation manager
- descriptor version
- Session persistence backend
- Cordis fiber
- transport rollback
- `prepareContinuable()`

---

# 28. 是否需要 System Prompt 插件贡献

首版建议 **不额外注册 system prompt section**。

原因：

tool description 已足以说明：

```text
如何启动
如何 continue
provider/model 含义
```

这样：

- 少一段固定请求 token
- 减少 KV prefix 变化
- 减少 prompt 与 tool schema 重复
- 避免以后工具隐藏但 guidance 仍可见

只有测试证明模型无法可靠使用时，再考虑稳定 system prompt guidance。

---

# 29. README 必须按 DSH Model Experience 格式

README 不能只写“Usage”。

至少包括：

```markdown
# @deepseek-ai/dsh-tool-subagent-router

## Contract

## Config

## Routing policy

## Continuation behavior

## Model Experience

### Tool schema

#### What the model sees

...

#### Token effect

Fixed schema cost per request where the tool is visible.

#### KV Cache effect

Prefix-stable while the registered tool schema is unchanged.

### Tool result

#### What the model sees

...

#### Token effect

One short result appended per accepted creation.

#### KV Cache effect

Append-only after the reusable request prefix.

## Known Limitations and Deferred Work

- ...
```

### README limitations 至少写明

- no mid-session model switching
- no model discovery tool
- no synchronous collection of continuable child result
- `maxTokens` not durable
- only configured LLM adapters/routes can be used
- continuation controls require separately mounted official control tool
- provider/model validity may fail only when child route is resolved unless preflight is enabled

---

# 30. `src/invariant.ts`

DSH 当前要求每个 package 拥有：

```text
./invariant
```

该插件本身没有独立 lifecycle stream，可以按 `tool-subagent` 当前模式写：

```ts
import type { Context } from '@deepseek-ai/cordis'
import type { InvariantInstaller } from '@deepseek-ai/dsh-invariants'

const PACKAGE_NAME =
  '@deepseek-ai/dsh-tool-subagent-router'

export const name =
  'tool-subagent-router-invariant'

export const inject = ['invariants']

const install: InvariantInstaller = () => {
  // No runtime invariant:
  // lifecycle relations are owned by ctx.subagents.
}

export const apply = (
  ctx: Context,
): Promise<() => void> =>
  Promise.resolve(
    ctx.invariants.register(
      PACKAGE_NAME,
      install,
    ),
  )
```

说明必须具体：

```text
No runtime invariant: this model-facing consumer owns no
independent lifecycle relation; child lifecycle belongs to
@deepseek-ai/dsh-subagent.
```

不要写无解释的空 installer。

---

# 31. package.json

如果放进 DSH workspace：

以当前：

```text
packages/subagent/tool-subagent/package.json
```

为模板。

建议最小 peer dependencies：

```json
{
  "peerDependencies": {
    "@deepseek-ai/cordis": "workspace:^",
    "@deepseek-ai/dsh-invariants": "workspace:^",
    "@deepseek-ai/dsh-subagent": "workspace:^",
    "@deepseek-ai/dsh-tools": "workspace:^"
  },
  "dependencies": {
    "@deepseek-ai/schemastery": "workspace:^"
  }
}
```

如果实现直接 import：

```text
AgentOptions
ContentBlock
```

再添加对应 peer/dev dependencies。

所有 dsh peer dependency 必须在 devDependencies 中镜像。

---

## 当前 workspace manifest 约束

实现时以：

```text
scripts/check-workspace-constraints.ts
```

为准。

当前 release member：

```text
packages/<group>/<pkg>
```

要求：

- 不得 `"private": true`
- `publishConfig.access = "public"`
- repository metadata 指向正确目录
- version 与 root version 一致
- `"type": "module"`
- `"main": "lib/index.js"`
- `"types": "lib/types/index.d.ts"`
- root export 指向：
  - `./lib/index.js`
  - `./lib/types/index.d.ts`
- `./invariant` export 正确
- `@deepseek-ai/cordis` 同时在 peerDependencies / devDependencies
- peer/dev range 一致
- files 必须符合 publication policy

不要机械照抄旧文档中的 `"private": true`；当前 constraints 脚本是 CI source of truth。

---

# 32. files / exports

典型：

```json
{
  "main": "lib/index.js",
  "types": "lib/types/index.d.ts",
  "exports": {
    ".": {
      "types": "./lib/types/index.d.ts",
      "default": "./lib/index.js"
    },
    "./invariant": {
      "types": "./lib/types/invariant.d.ts",
      "default": "./lib/invariant.js"
    },
    "./src/*": "./src/*",
    "./package.json": "./package.json"
  },
  "files": [
    "lib/index.js",
    "lib/invariant.js",
    "lib/types/**/*.d.ts"
  ]
}
```

最终以仓库当前 constraints 输出为准。

---

# 33. tsconfig.json

建议：

```json
{
  "extends": "../../../tsconfig.base.json",
  "compilerOptions": {
    "rootDir": "src",
    "outDir": "lib/types"
  },
  "include": [
    "src"
  ],
  "references": [
    {
      "path": "../../../vendor/cosmokit"
    },
    {
      "path": "../../../vendor/cordis"
    },
    {
      "path": "../../../vendor/schemastery"
    },
    {
      "path": "../../core/tools"
    },
    {
      "path": "../subagent"
    },
    {
      "path": "../../runtime-diagnostics/invariants"
    }
  ]
}
```

如果源码 import 其它 workspace package，再增加对应 reference。

不要添加没有真实 import/contract 需要的 dependency。

---

# 34. Root TypeScript Aggregate

如果作为 DSH workspace package：

在：

```text
tsconfig.host.json
```

增加：

```json
{
  "path": "./packages/subagent/tool-subagent-router"
}
```

普通 Host package 只能进入正确 aggregate，不要同时加到 client aggregate。

---

# 35. Cordis 配置示例

假设包已在 workspace：

```yaml
- insert:
    - id: tool-subagent-router
      name: '@deepseek-ai/dsh-tool-subagent-router'
      config:
        subagentProvider: spawn
        toolName: subagent_route
        maxDepth: 3
        allowedProviders:
          - openai
          - deepseek
```

必须确保 composition 中已有：

```text
@deepseek-ai/dsh-subagent
@deepseek-ai/dsh-subagent-spawn-in-process
@deepseek-ai/dsh-tool-subagent-control
```

如果需要 `list_agents` 对模型可见，还要挂载 control package 的 list-agents consumer。

---

# 36. 不要默认塞进 shipped bundle

首版作为 opt-in package。

不要直接修改：

```text
packages/bundle/base/cordis.patch.yml
packages/bundle/web-app/cordis.patch.yml
```

把新工具变成默认工具。

DSH 测试政策明确要求 product-visible opt-ins 不要无意进入 shipped defaults。

先让用户通过：

```text
profile patch
agent preset
test composition
```

显式启用。

---

# 37. Web / Preset 集成注意事项

Web 当前是 preset-owned agent-plane tool composition。

因此如果用户最终要在 Web 某个 preset 里使用：

```text
subagent_route
```

仍需将插件放在该 Agent 可见的 composition scope。

本插件本身不应绕过 preset/tool visibility 设计去“强制注入所有 agent”。

如果后续希望 global exposure，应单独评估当前 host/global tool merge 行为，而不是让本插件偷偷突破 preset 边界。

---

# 38. 单元测试计划

文件：

```text
tests/tool-subagent-router.spec.ts
```

至少覆盖：

### Plugin export contract

- 有 `name`
- 有 `inject`
- 有 `Config`
- 有 `apply`
- **没有 default export**

---

### Config

- 默认 `subagentProvider = spawn`
- 默认 `toolName = subagent_route`
- 默认 `maxDepth = 3`
- omission 不把 `toolFilter` 变成 empty allowlist
- invalid maxDepth 被拒绝

---

### Tool registration

- backend 可用时注册 tool
- provider 移除时 tool 被 dispose
- provider HMR/re-add 后重新注册
- plugin fiber dispose 后 tool 不再存在

这是 DSH registry contribution 的 HMR-safety 要求。

---

### Tool schema

断言稳定：

```text
description
prompt
provider
model
```

都是 required。

断言 **不存在**：

```text
api_key
base_url
subagent_provider
max_tokens
run_in_background
```

---

### Successful start

mock 最小外部边界，但保留真实：

```text
tools registry
subagent runtime
spawn provider
agent creation
session
```

执行：

```json
{
  "description": "Review diff",
  "prompt": "...",
  "provider": "test-provider",
  "model": "test-model"
}
```

验证 child durable descriptor：

```text
mode = continuable
provider = spawn
agentProvider = test-provider
agentModel = test-model
label = Review diff
```

不要只断言 tool 返回字符串。

---

### Allowlist

配置：

```yaml
allowedProviders:
  - allowed
```

调用：

```text
provider = denied
```

必须在 child 创建前拒绝。

验证：

```text
没有 child session
没有 descriptor
没有已接受 inbox message
```

---

### Missing exec.agent

直接在无 Agent owner context 调用时：

```text
errored tool result
```

且无 child 创建副作用。

---

### Cancellation before acceptance

验证：

```text
exec.signal abort
```

发生在 initial inbox acceptance 之前：

- tool 失败
- 不返回 subagent id
- rollback child
- 不残留 Activation/Session publication（按 DSH contract 可观测范围验证）

---

### Continue

创建成功后用 **官方**：

```text
send_message
```

发送第二轮。

验证：

```text
同一个 child session id
```

出现第二个 user turn / child response。

不要自己调用内部 continuation manager 私有 API 来代替真实入口。

---

### Cold Resume

启用 JSONL/session persistence 测试组合。

流程：

```text
create child
wait settle
dispose resident activation / restart suitable scope
send_message
```

验证：

```text
same child id
same persisted provider/model
next turn accepted
```

这是本插件最重要的端到端行为之一。

---

# 39. 100% Coverage Gate

DSH 当前 gating policy：

```text
pnpm run test:coverage
```

要求：

```text
packages/*/*/src
```

per-file 100%。

因此：

```text
src/index.ts
src/invariant.ts
```

必须全部覆盖。

不要为了覆盖率添加没有产品意义的分支。

如果一个分支难以测试，应先问：

```text
这个分支是否真的需要存在？
```

---

# 40. REAL Composition Test

DSH 当前要求 product-visible plugin 必须有非 unit 的真实 composition test。

不能只做：

```ts
ctx.plugin(plugin)
```

然后声称集成完成。

必须通过 Loader 启动 test-only：

```text
cordis.yml
```

示例测试 topology：

```text
Loader
├─ tools
├─ agents
├─ sessions
├─ session persistence
├─ llm scripted/mock adapter
├─ subagents
├─ spawn provider
├─ tool-subagent-router
└─ tool-subagent-control
```

只 mock：

```text
真实 LLM / 网络
```

其它 downstream 尽量真实。

---

# 41. Snapshot Requirement

这是 model-visible 新 tool schema，因此属于 non-trivial model-visible change。

按当前 DSH testing policy，应增加 keyless snapshot scenario。

建议优先选择：

```text
examples/acp-agent/tests/snapshots/
```

或仓库当前最适合的 headless snapshot harness。

snapshot 至少 pin：

```text
tool name
tool description
parameters
result rendering
subagent id/result envelope
```

如果 schema 被加入请求 header，应确认现有 pinned-header scenario 是否已经覆盖；否则增加专用 scenario。

不要手工编辑生成快照结果而不走 record/refresh 流程。

---

# 42. Model-facing 行为测试

至少准备一个 scripted mock model 流程：

```text
User:
Delegate this review to openai/gpt-5.6.

Parent Agent:
calls subagent_route

Tool:
returns subagent id

Parent Agent:
uses send_message on same child

Child:
accepts second turn
```

测试世界状态：

```text
child Session descriptor
child Session events
accepted messages
tool calls
```

不要只检查模型最后回答中是否出现：

```text
success
```

---

# 43. 实际 Provider API e2e（可选但推荐）

如果该插件最终长期使用在真实 DSH 环境，应增加 with-key smoke：

```text
DSH_TEST_PROVIDER
DSH_TEST_MODEL
```

或者使用仓库已有测试 provider 环境。

流程：

```text
start child
child 完成一个简单任务
send_message
child 完成第二轮
```

测试可 self-skip when credential absent。

这符合 DSH 当前“真实 API 测试不应因成本被回避”的 policy。

---

# 44. 文档同步

代码完成后：

```sh
pnpm run doc-sync
```

不要手写生成的：

```text
docs/tool-catalog.md
docs/config-catalog.md
```

除非当前生成系统明确要求源文件修改。

tool schema / Config 变化必须让 generator 生成 catalog。

---

# 45. 完整验证命令

至少：

```sh
pnpm install

pnpm run doc-sync

pnpm run constraints
pnpm run typecheck
pnpm run lint

pnpm run test
pnpm run test:coverage

pnpm run build
pnpm run hygiene
```

如果新增 snapshot：

```sh
pnpm run test:snapshot
```

需要 record 时使用仓库当前对应：

```sh
pnpm run test:snapshot:record
```

或：

```sh
pnpm run test:snapshot:refresh
```

Web snapshot 只有在 Web 可见行为变化时再按仓库 policy 执行：

```sh
pnpm run test:web
```

---

# 46. 实施阶段

## Phase 0 — 对齐当前 upstream

实现 Agent 首先执行：

```sh
git status
git rev-parse HEAD
```

并重新阅读：

```text
packages/AGENTS.md
docs/testing.md
packages/subagent/tool-subagent/src/index.ts
packages/subagent/subagent/src/continuation.ts
packages/subagent/subagent/src/descriptor.ts
scripts/check-workspace-constraints.ts
```

任何本计划与当前源码冲突时：

```text
当前源码 + constraints + tests
```

优先。

不要为了符合本计划去逆改 upstream。

---

## Phase 1 — Package skeleton

创建：

```text
packages/subagent/tool-subagent-router/
```

完成：

```text
package.json
tsconfig.json
src/index.ts
src/invariant.ts
README.md
tests/
```

加入：

```text
tsconfig.host.json
```

project reference。

运行：

```sh
pnpm install
pnpm run constraints
pnpm run typecheck
```

先保证空 skeleton 正确。

---

## Phase 2 — Tool registration

实现：

```text
Config
apply
provider lifecycle mount/unmount
defineTool
```

先不启动 child。

单测：

```text
schema
HMR dispose
provider add/remove
```

---

## Phase 3 — Continuable creation

接入：

```ts
ctx.subagents.startContinuable()
```

只支持：

```text
spawn
continuable
background
```

传：

```text
parent
prompt
agentOptions.provider
agentOptions.model
maxDepth
persona
toolFilter
signal
```

返回：

```text
kind=continuable
subagentId
```

---

## Phase 4 — Routing policy

加入：

```text
allowedProviders
```

executor-level enforce。

测试：

```text
allowed
denied
omitted
empty list
```

需要明确：

```text
allowedProviders: []
```

是：

```text
deny all
```

还是 invalid config。

推荐：

```text
显式 [] = deny all
```

因为这是清晰的部署策略；如果认为无实际用途，也可以在 load 时拒绝空列表，但必须 README/测试一致。

---

## Phase 5 — Official continue integration

test composition 加：

```text
@deepseek-ai/dsh-tool-subagent-control
```

通过：

```text
send_message
```

进行第二轮。

不要在本 package 创建 `subagent_continue`。

---

## Phase 6 — Persistence / Cold Resume

加 JSONL persistence。

验证：

```text
agentProvider
agentModel
```

已落入 descriptor。

cold resume 后仍走同 route。

---

## Phase 7 — Docs / Snapshot / Gates

补：

```text
README
Model Experience
Known Limitations
JSDoc
snapshot
```

最后跑全套 gate。

---

# 47. 推荐 `src/index.ts` 结构

不要把整个 implementation 塞在一个 500 行 `apply()`。

建议：

```ts
// Config
export interface Config { ... }
export const Config = ...

// Pure validation helpers
function assertAllowedProvider(...) { ... }
function assertToolFilter(...) { ... }

// Tool definition factory
function createSubagentStartTool(
  ctx: Context,
  config: ResolvedConfig,
) {
  return defineTool(...)
}

// Provider-specific lifecycle mount
function mountForProvider(...) { ... }

// Plugin entry
export function apply(
  ctx: Context,
  config: Config,
): void {
  ...
}
```

但也不要为了“架构漂亮”过度抽象。

DSH 当前规范要求每个 abstraction 有实际 owner / need。

如果 helper 只调用一次且没有独立语义，优先内联。

---

# 48. 推荐错误信息

错误信息要从 model perspective 写。

好：

```text
LLM provider "foo" is not allowed for this delegation tool.
```

好：

```text
Configured child backend "spawn" is unavailable.
```

好：

```text
This tool requires a live parent agent.
```

不要：

```text
ContinuationManager.materialize() returned undefined
```

不要：

```text
Fiber scope missing service proxy
```

不要把 Cordis/runtime 内部术语暴露给模型，除非是诊断日志而非 tool result。

---

# 49. Logging

首版不要自行做新的 logging subsystem。

依赖现有：

```text
tool execution events
subagent/start
subagent/end
session log
LLM request logging
```

如需要插件特定 debug：

```text
ctx.logger(...)
```

应只记录：

```text
tool startup
routing choice
backend lifecycle
error summary
```

绝不记录：

```text
credentials
完整 secret header
API key
```

---

# 50. 安全边界

必须确保 model-facing args 中没有：

```text
apiKey
api_key
token
authorization
baseURL
base_url
endpoint
headers
```

模型只能选：

```text
provider route name
model id
```

也就是说：

```text
模型负责 routing choice
部署负责 credential / endpoint / adapter ownership
```

这是合理的权限边界。

---

# 51. Tool Filter 的安全注意

如果部署要把 child 用作 reviewer，可以：

```yaml
toolFilter:
  deny:
    - <mutating tools>
```

但不要在计划中硬编码未知工具名。

实现时通过当前 DSH tool catalog /实际部署确认 model-facing tool name。

toolFilter 是 runtime enforcement，不只是 prompt hint。

---

# 52. 代码审查重点

完成后 reviewer 必须检查：

### Ownership

- 谁拥有 child lifecycle？
- 插件是否意外持有 `AgentHandle`？
- 插件是否实现了第二套 queue？
- 插件是否在 inbox acceptance 后错误取消 child？

正确答案应该是：

```text
ctx.subagents owns it
```

---

### Persistence

- provider/model 是否由官方 descriptor 持久化？
- 插件有没有私自写 session event？
- cold resume 是否走官方路径？

正确：

```text
插件不写自定义 descriptor
```

---

### Authority

- continue 是否复用 `send_message`？
- 有没有绕过 direct-parent authority？
- 有没有直接从 session id 找 child Agent 后调用私有方法？

正确：

```text
没有
```

---

### HMR

- tool registration 是否随 plugin fiber cleanup？
- backend provider HMR 后是否出现重复 tool name？
- provider remove 后是否残留 dead tool？

---

### Model contract

- schema 是否只暴露当前需求字段？
- 有没有泄漏内部 runtime vocabulary？
- provider/model 是否解释清楚？
- child fresh-context 说明是否真实？

---

# 53. Acceptance Criteria

只有全部满足才算完成。

## Functional

- [ ] `subagent_route` 可以动态指定 LLM provider
- [ ] `subagent_route` 可以动态指定 model
- [ ] child 使用 `spawn` continuable backend
- [ ] 返回 durable `subagentId`
- [ ] child descriptor 保存 `agentProvider`
- [ ] child descriptor 保存 `agentModel`
- [ ] 官方 `send_message` 可以继续同一 child
- [ ] child cold resume 后仍可继续
- [ ] cold resume 仍使用创建时 provider/model
- [ ] `list_agents` 能看到 child（若对应 consumer 已挂载）
- [ ] `interrupt_agent` 仍使用官方 authority path

## Security

- [ ] tool args 不接受 API key
- [ ] tool args 不接受 Base URL
- [ ] tool args 不接受 arbitrary headers
- [ ] optional provider allowlist 在 executor enforce
- [ ] 无 bypass route

## Architecture

- [ ] 不修改 `dsh-subagent`
- [ ] 不复制 continuation manager
- [ ] 不复制 `send_message`
- [ ] 不自建 session persistence
- [ ] 不自建 child lifecycle state machine
- [ ] 不持有 child AgentHandle
- [ ] 无 default export

## DSH Quality Gates

- [ ] workspace constraints pass
- [ ] typecheck pass
- [ ] lint pass
- [ ] unit tests pass
- [ ] per-file 100% coverage
- [ ] REAL composition test pass
- [ ] snapshot test pass
- [ ] build pass
- [ ] hygiene pass
- [ ] README Model Experience 合规
- [ ] README Known Limitations 合规
- [ ] invariant companion 合规

---

# 54. 最终用户体验

用户可以给主 Agent 指令：

```text
使用 openai/gpt-5.6 创建一个子 Agent，
审查当前 git diff。
```

主 Agent：

```json
subagent_route({
  "description": "Review current diff",
  "prompt": "Review the current git diff for correctness, regressions, security issues and missing tests.",
  "provider": "openai",
  "model": "gpt-5.6"
})
```

返回：

```text
Started continuable subagent ses_123...
```

之后：

```json
send_message({
  "subagent_id": "ses_123...",
  "message": "Now focus specifically on concurrency and race conditions."
})
```

之后即使 child 已 cold：

```json
send_message({
  "subagent_id": "ses_123...",
  "message": "Re-check the latest diff after my fixes."
})
```

仍恢复同一个 durable child conversation。

---

# 55. V2 可选方向

首版稳定后再考虑。

## Route aliases

例如部署配置：

```yaml
routes:
  fast:
    provider: deepseek
    model: deepseek-v4-flash

  review:
    provider: openai
    model: gpt-5.6
```

模型调用：

```json
{
  "route": "review"
}
```

这可以降低模型拼错 provider/model 的概率。

但它与“模型自由选择 provider/model”的当前需求不同，应单独增加，不要首版同时做两套 API。

---

## Model discovery tool

未来可增加只读：

```text
list_subagent_models
```

但必须遵守 DSH：

```text
catalog != whitelist
```

语义。

不要用 `listModels` 返回值作为 route hard gate。

---

## Per-route policy

未来可以：

```yaml
policies:
  openai:
    maxDepth: 2
  deepseek:
    maxDepth: 3
```

但除非出现真实需求，不要首版加入。

---

## Foreground wait

如果以后确实需要：

```text
start and wait for first turn
```

应先调查 upstream 是否已经提供 public continuation wait/result API。

不要通过监听内部 event + polling session 拼一个隐式同步 RPC。

---

## Mid-session model migration

如果以后要求：

```text
ses_123:
  turn 1 -> model A
  turn 2 -> model B
```

这已经不是简单 Consumer 插件问题。

需要重新设计：

```text
descriptor
cold resume composition
request headers
model replay state
session semantics
```

必须在 DSH capability seam 层处理。

首版明确不做。

---

# 56. 给实现 Agent 的执行指令

可直接把以下内容作为实施约束附在任务前：

```text
Implement this as a new DSH model-facing Consumer plugin over the existing
ctx.subagents seam. Do not modify dsh-subagent core or implement a second
continuation/session lifecycle.

Use the current deepseek-harness master as the source of truth. Before coding,
read packages/AGENTS.md, docs/testing.md, the current tool-subagent consumer,
SubagentRuntime.startContinuable(), ContinuableStartSpec, descriptor.ts, and
tool-subagent-control.

The new tool must start a continuable child with a model-selected configured
LLM provider/model by passing them through request.agentOptions. The subagent
backend is deployment-owned and defaults to spawn. Continue/list/interrupt must
reuse the official dsh-tool-subagent-control tools.

Do not expose credentials, endpoints, headers, maxTokens, outputSchema, or
subagent transport selection to the model. Do not permit model switching during
continue. Do not add a new state machine, queue, polling loop, or persistence
format.

Follow DSH function-plugin named exports with no default export. Add the package
invariant companion, canonical README Model Experience / Known Limitations,
HMR-safety coverage, a REAL Loader composition test, model-visible snapshot
coverage, and satisfy current constraints/typecheck/lint/test:coverage/build/
hygiene gates.

When this plan conflicts with current source or current constraints, current
source/constraints/tests win. Update the implementation plan rather than
forcing old assumptions into the repository.
```

---

# 57. Source Checklist

实现时至少对照以下当前源码：

```text
packages/AGENTS.md
docs/testing.md
docs/cookbook/adding-a-package.md
docs/user/develop/basic/index.md
docs/user/develop/basic/tool.md

scripts/check-workspace-constraints.ts

packages/subagent/subagent/src/index.ts
packages/subagent/subagent/src/types.ts
packages/subagent/subagent/src/continuation.ts
packages/subagent/subagent/src/descriptor.ts

packages/subagent/subagent-spawn-in-process/src/index.ts

packages/subagent/tool-subagent/src/index.ts
packages/subagent/tool-subagent/package.json
packages/subagent/tool-subagent/tsconfig.json
packages/subagent/tool-subagent/src/invariant.ts
packages/subagent/tool-subagent/README.md

packages/subagent/tool-subagent-control/README.md
```

---

# 58. 最终推荐

第一版坚持“小而正”的实现：

```text
一个新 tool：
  subagent_route

四个核心参数：
  description
  prompt
  provider
  model

一个官方创建 API：
  ctx.subagents.startContinuable()

一个默认 backend：
  spawn

一套官方 continuation controls：
  send_message
  list_agents
  interrupt_agent

一个 durable identity：
  subagentId
```

不要把 `tool-subagent` 整包复制后再逐渐魔改。

这个插件真正新增的能力只有：

```text
把 child 的 LLM provider/model 从 deployment-fixed
变成 model-call-selected
```

其它能力全部复用 DSH 已有 owner。

这既满足需求，也最符合 DeepSeek Harness 当前插件开发与 capability-seam 设计规范。

