# dsh-subagent-router 修复与进一步优化计划

> 仓库：`XMoon/dsh-subagent-router`
>
> 目标：在**保留 `dsh-bundle` 作为正式安装/分发方式**的前提下，进一步强化 `subagent_fork` one-shot 语义、与 DSH 官方 `subagent` / `subagent_fork` / control tools 的共存性、配置冲突防御、真实组合测试、文档准确性与跨版本兼容性。
>
> 当前核心架构不推翻。本轮工作重点是“补齐产品入口、锁死语义、强化共存与兼容性验证”。

---

## 1. 总体结论

当前实现的核心方向正确，应继续保留：

```text
dynamic provider/model routing
        ↓
@xmoon76/dsh-subagent-router
        ↓
ctx.subagents
        ↓
spawn / fork / other provider
```

其中：

```text
spawn + continuable
    -> ctx.subagents.startContinuable()

fork + one-shot
    -> ctx.subagents.start()
```

当前已经正确做到：

- 模型动态选择 LLM provider/model；
- backend 与 execution mode 由部署配置控制；
- spawn continuable；
- fork one-shot；
- fork 使用官方 `dsh-subagent-fork-in-process`；
- one-shot 等待子 Agent 最终结果并 dispose run；
- continuable 复用官方 `send_message` / `list_agents` / `interrupt_agent`；
- cold resume、Session persistence、continuation manager 均由 DSH 官方 runtime 管理；
- 不修改 DSH core；
- provider lifecycle/HMR 已有处理；
- Loader composition test、README 双语、package invariant 已经存在。

因此本轮**不要重写主体**。

---

# 2. 明确保留 dsh-bundle

`dsh-bundle` 是既定正式分发方案，不作为问题处理。

继续保留：

```json
{
  "dsh": {
    "bundle": {
      "patch": "./cordis.patch.yml"
    }
  }
}
```

以及：

```sh
dsh plugin --profile <profile> add @xmoon76/dsh-subagent-router
```

作为主安装体验。

本轮不要：

- 删除 `cordis.patch.yml`；
- 删除 `dsh.bundle.patch`；
- 要求用户手工修改 DSH 官方 preset 才能安装；
- 改成裸 `ctx.plugin()` 才能使用；
- 要求用户 fork DeepSeek Harness。

本轮对 bundle 的工作是：

```text
保留 bundle
+
强化 bundle 与官方 composition 的共存测试
+
完善 profile overlay / 第二实例示例
```

---

# 3. 本轮优先级

```text
P0  官方 subagent 工具共存验证
P0  fork one-shot 语义完整锁死
P1  toolName 冲突防御
P1  fork 动态路由的正式产品入口/示例
P1  bundle overlay 与双实例验证
P2  route preflight（可选）
P2  DSH 兼容性 CI
P2  README / Model Experience 修正
```

---

# 4. P0 — 官方工具共存测试

当前 router 已证明自己能工作，但还需要锁定真实用户环境：

```text
官方 subagent
官方 subagent_fork
官方 send_message
官方 interrupt_agent
官方 list_agents
+
router
```

同时加载时必须互不影响。

建议新增：

```text
tests/official-coexistence.spec.ts
```

或并入 Loader composition suite，但独立文件更清晰。

## 4.1 真实 composition

加载：

```text
@deepseek-ai/dsh-subagent
@deepseek-ai/dsh-subagent-spawn-in-process
@deepseek-ai/dsh-subagent-fork-in-process

@deepseek-ai/dsh-tool-subagent
@deepseek-ai/dsh-tool-subagent-control
@deepseek-ai/dsh-tool-subagent-control/list-agents

@xmoon76/dsh-subagent-router
```

官方实例：

```yaml
- name: '@deepseek-ai/dsh-tool-subagent'
  config:
    provider: spawn
    toolName: subagent
    backgroundMode: continuable

- name: '@deepseek-ai/dsh-tool-subagent'
  config:
    provider: fork
    toolName: subagent_fork
    backgroundMode: one-shot
```

router：

```yaml
- name: '@xmoon76/dsh-subagent-router'
  config:
    subagentProvider: spawn
    executionMode: continuable
    toolName: subagent_route
```

## 4.2 必须断言工具集合

至少确认以下同时存在：

```text
subagent
subagent_fork
subagent_route
send_message
interrupt_agent
list_agents
```

## 4.3 必须断言官方 schema 不变

加载 router 前记录：

```text
subagent
subagent_fork
send_message
interrupt_agent
list_agents
```

的 schema；加载 router 后重新读取并断言深度相等。

目的：确保 router 不 shadow、不 replace、不 mutate 官方定义。

## 4.4 必须断言官方行为仍可执行

至少执行一次官方：

```text
subagent
subagent_fork
```

验证实际行为没有被 router 劫持。

---

# 5. P0 — 完整锁死 fork one-shot 需求

当前已有：

```yaml
executionMode: one-shot
subagentProvider: fork
```

且代码真实走：

```text
ctx.subagents.start('fork', ...)
```

这一点正确。

下一步要把需求从“能跑”提升为：

```text
它确实 fork
+
确实 one-shot
+
确实使用动态 provider/model
+
确实不能 continue
```

---

# 6. Fork inheritance + dynamic route 联合测试

新增测试：

```text
fork inherits completed parent turns and uses the selected child route
```

## 6.1 Parent 必须有真实 completed turn

不要用空 parent。

让 parent 先形成：

```text
user: The project uses Redis for cache.
assistant: Understood.
turn/end
```

然后调用 router fork：

```text
Review the cache design.
```

## 6.2 Parent / child 使用不同模型路由

测试必须避免都用同一个 `mock/mock`。

例如：

```text
parent:
  provider = parent-mock
  model    = parent-model

fork child:
  provider = child-mock
  model    = child-model
```

断言：

```ts
expect(childRequest.provider).toBe('child-mock')
expect(childRequest.model).toBe('child-model')
```

## 6.3 验证 fork history

child request 应包含：

```text
The project uses Redis for cache.
Understood.
```

但不能包含 parent 当前尚未完成的 in-flight turn。

这一条测试一次锁定：

```text
fork semantics
+
completed-turn prefix
+
dynamic provider/model routing
```

---

# 7. Fork 必须不可 continue

新增测试：

```text
one-shot fork cannot be resumed with send_message
```

流程：

```text
router fork one-shot
    ↓
得到 { kind: 'one-shot', runId }
    ↓
run 完成并 dispose
    ↓
send_message(runId, 'continue')
```

预期：失败。

错误文本只断言稳定 fragment，不绑定整段 wording，例如：

```text
not delivered
unknown
not continuable
```

具体按当前 DSH contract 选最稳定 fragment。

同时验证：

```text
list_agents
```

不会把该 one-shot fork 列成 continuable child。

这条测试用于锁死最初产品要求：

```text
fork 是 non-continue one-shot
```

防止后续因为 fork provider 出现 `prepareContinuable()` 而误改产品语义。

---

# 8. Support Matrix 正式化

README 和测试应正式定义支持等级：

| Backend | Mode | 状态 | 说明 |
|---|---|---|---|
| `spawn` | `continuable` | ✅ 推荐 | Fresh child，可 `send_message`、cold resume |
| `fork` | `one-shot` | ✅ 推荐 | 继承 parent completed turns，一次执行后结束 |
| `spawn` | `one-shot` | ⚪ 兼容 | Fresh child 的一次性执行 |
| `fork` | `continuable` | ⚠️ 非推荐 | Upstream 暂未作为正式 shipped fork 模式 |

不要硬拒绝 `fork + continuable`，因为 router 本身是通用 provider Consumer；只要 provider 暴露 `prepareContinuable()` 可以保留技术兼容。

但产品文档必须明确：

```text
fork + one-shot
```

才是正式推荐路径。

---

# 9. P1 — toolName 冲突防御

当前：

```ts
toolName?: string
```

允许用户配置任意名字。

如果用户配置：

```yaml
toolName: subagent
```

或：

```yaml
toolName: subagent_fork
```

会与官方工具同层重复注册。

虽然 ToolRuntime 会 fail，而不是静默覆盖，但错误体验不好。

## 9.1 推荐通用检查

在真正的 `mount(provider)` 中：

```ts
const existing = ctx.tools.get(resolved.toolName)
if (existing !== undefined) {
  throw new Error(
    `tool-subagent-router: tool name "${resolved.toolName}" is already registered; `
    + 'choose a unique toolName'
  )
}
```

这样同时保护：

```text
官方工具
router 多实例
其它第三方工具
```

## 9.2 官方名字给更明确错误

可以维护：

```ts
const OFFICIAL_SUBAGENT_TOOL_NAMES = new Set([
  'subagent',
  'subagent_fork',
  'send_message',
  'interrupt_agent',
  'list_agents',
])
```

命中时：

```text
tool name "subagent_fork" conflicts with a DSH built-in subagent/control tool
```

否则：

```text
tool name "foo" is already registered
```

## 9.3 必须在 provider mount 时检查

不能只在 `apply()` 检查，因为 router 支持：

```text
router 先加载
provider 后注册
```

真正 collision 时点可能发生在 `subagent/provider-added`。

新增测试：

```text
router waiting for provider
↓
other tool occupies target name
↓
provider appears
↓
router fails loud
↓
existing tool remains untouched
```

---

# 10. P1 — Fork 动态路由的正式用户入口

> **2026-08-20 产品决策（用户确认）**：默认产品形态调整为 bundle 同时挂载
> 两个 router 实例，替代原先"只插一个 + README 第二实例方案"的最小默认：
> `subagent_route`（spawn + continuable，原 `subagent_start` 改名统一路由
> 命名）与 `subagent_fork_route`（fork + one-shot）。两个实例保持相同
> model-facing 参数（description / prompt / provider / model），工具描述
> 主动区分官方工具（官方 = 部署固定 route；router = 每次调用动态选择
> provider/model）。原"避免扩大 tool catalog"的考虑让位于产品完整性。

当前 bundle 默认（实现后）：

```yaml
subagentProvider: spawn
executionMode: continuable
toolName: subagent_route
```

以及：

```yaml
subagentProvider: fork
executionMode: one-shot
toolName: subagent_fork_route
```

（原 `subagent_start` 名字退役；已安装用户需把 profile 覆盖里的
`toolName` 改为 `subagent_route`。）

推荐（bundle 已默认提供，无需用户插入）：

```yaml
- insert:
    - id: tool-subagent-router-fork
      name: '@xmoon76/dsh-subagent-router'
      config:
        subagentProvider: fork
        executionMode: one-shot
        toolName: subagent_fork_route
        maxDepth: 3
```

不要推荐：

```text
toolName: subagent_fork
```

因为这是官方名字。

推荐最终用户看到：

```text
subagent_route      -> router spawn continuable
subagent_fork_route -> router fork one-shot

subagent            -> 官方
subagent_fork       -> 官方
```

这样最清晰。

> 2026-08-20 补充：`subagent_start` 改名 `subagent_route`，见上文产品决策。

---

# 11. P1 — Bundle overlay / 双实例真实验证

当前 `bundle-patch.spec.ts` 已验证：

- patch 可解析；
- 只插 router row；
- 不重复插官方 `subagent` runtime/provider/control。

这些保留。

新增真实 Loader test：

```text
base composition
+
router bundle patch
+
profile/user overlay
```

覆盖两类场景。

## 11.1 覆盖默认 router 配置

例如 profile patch：

```yaml
- id: tool-subagent-router
  config:
    subagentProvider: spawn
    executionMode: continuable
    toolName: subagent_route
    maxDepth: 3
    allowedProviders:
      - deepseek-official
```

验证最终 config 生效。

## 11.2 第二 router instance(bundle 默认,2026-08-20 起不再需要 profile insert)

> 2026-08-20 产品决策后,`tool-subagent-router-fork`(fork + one-shot,
> `subagent_fork_route`)已由 bundle 默认插入;profile 只需在需要覆盖时
> patch 该 row id。原"通过 profile patch insert"的示例保留如下供参考:

```yaml
- insert:
    - id: tool-subagent-router-fork
      name: '@xmoon76/dsh-subagent-router'
      config:
        subagentProvider: fork
        executionMode: one-shot
        toolName: subagent_fork_route
        maxDepth: 3
```

最终 schemas 必须同时存在：

```text
subagent_route
subagent_fork_route
```

---

# 12. Web / agent preset：保留 bundle，不做反架构改造

这里以用户已经确认的前提处理：

```text
dsh-bundle 是官方推荐的第三方插件安装路径
```

因此**不要把“删除 bundle / 改成必须手写 preset”作为修复建议**。

本轮只做：

1. 验证 bundle/global tool 在当前 Web preset composition 下的真实可见性；
2. README 准确记录该行为；
3. 如果需要限制某 preset，给出 DSH 官方 scope/restrict 的做法；
4. 不在 router 内部自动探测 Web 或偷偷修改 preset。

建议增加一个 Web-style scoped visibility test：

```text
global router
+
standard-like agent scope
+
minimal/restricted agent scope
```

验证 router 在不同 scope 下的真实可见性。

如果 DSH 的：

```ts
agent.ctx.tools.restrict({ deny: ['subagent_route'] })
```

能够可靠限制 global router，则 README 给出这种官方能力控制方式。

重点：

```text
不要为了 agent-preset purity 牺牲 bundle 安装体验；
也不要在插件内部自行重造 preset ownership。
```

---

# 13. P2 — README 修正

当前 README 有一个明确错误：

`subagent_fork` 不属于：

```text
@deepseek-ai/dsh-tool-subagent-control
```

正确分组：

## 官方 continuation controls

来自：

```text
@deepseek-ai/dsh-tool-subagent-control
```

包括：

```text
send_message
interrupt_agent
list_agents
```

## 官方 delegation tools

由：

```text
@deepseek-ai/dsh-tool-subagent
```

不同实例注册：

```text
subagent
subagent_fork
```

README.md / README.zh.md / README.i18n.yaml 必须同步修改。

---

# 14. README 增加官方共存说明

明确写：

```text
本插件不会替换官方 subagent / subagent_fork。
```

并说明默认名字：

```text
router: subagent_route
official: subagent / subagent_fork
```

多实例时推荐：

```text
subagent_fork_route
```

明确警告不要把 router 的 `toolName` 配成官方名字。

---

# 15. README fork prompt 语义

必须保持和 `provider.inheritsParentContext` 文案一致。

spawn：

```text
prompt 必须 self-contained；child 不继承 parent conversation。
```

fork：

```text
child 继承 parent 已完成 turns；
prompt 只需要写新增任务；
当前 in-flight turn 不在 fork seed 中。
```

---

# 16. P2 — Route preflight（可选，不作为本轮硬要求）

当前 continuable：

```text
startContinuable()
```

成功边界是 initial inbox acceptance。

因此 provider/model 配错时可能：

```text
router 先返回 child id
↓
child 首次 LLM request 时 route resolve 失败
```

这是 DSH 当前 contract 下合理行为。

可选未来新增：

```ts
validateRoute?: boolean
```

若启用：

```ts
await ctx.llm.resolveModelInfo(
  args.provider,
  args.model,
  exec.signal,
)
```

成功后再创建 child。

不要使用：

```text
listModels()
```

作为 hard whitelist，因为 DSH model catalog 不等于 route whitelist。

本轮建议：**暂不实现，先保留为 Deferred Optimization。**

---

# 17. P2 — `settleOneShotRun()` 与 upstream helper 对齐

当前 router 自己实现：

```text
await run.result
stopReason mapping
dispose
result + dispose 双错误保留
```

逻辑整体合理。

但 DSH 当前公开了 `settleRun` helper。

实现 Agent 应重新对照当前 `@deepseek-ai/dsh-subagent`：

- 如果 `settleRun` 能完整满足当前 one-shot contract，优先复用官方 helper；
- 如果不能满足当前 canonical output/error reporting，需要保留现有 `settleOneShotRun()`，但加注释说明为什么不能复用 `settleRun`。

目标：减少未来 DSH stop reason / disposal contract 漂移风险。

---

# 18. P2 — Fork cancellation

补测试：

```text
fork one-shot 正在运行
↓
parent tool signal abort
↓
child cancel
↓
run.result settles aborted
↓
run.dispose 完成
↓
tool 返回 error
↓
无 dangling Agent
```

使用已有 `hang` MockAdapter 即可。

---

# 19. P2 — Fork concurrency

当前 tool 声明：

```ts
isConcurrencySafe: () => true
```

补真实测试：

```text
同一个 parent 当前 turn
并发发起两个 router fork one-shot
```

验证：

- 两个 child 都成功；
- 两个 route 不串；
- 两个 run dispose 不串；
- 两个 fork 都只继承当前 turn 之前的 completed prefix；
- fork A 不应看到 fork B 的 tool result，反之亦然。

这条测试很重要，因为 fork 的价值之一就是共享稳定 parent prefix。

---

# 20. P2 — persona / toolFilter / maxDepth 的 fork 路径

当前这些能力主要在 continuable 测试中验证。

补 one-shot fork：

```text
persona
  -> child system prompt

toolFilter
  -> child tool schema

maxDepth
  -> child delegation depth
```

这样确保共同 request builder 在 `ctx.subagents.start()` 路径也没有遗漏。

---

# 21. P2 — allowedProviders 的 fork 路径

补：

```text
fork one-shot + denied provider
```

必须保证：

```text
没有 child session
没有 fork seed publication
没有 model request
```

证明 allowlist 真正在任何 child 工作之前 enforce。

---

# 22. P2 — Provider removal lifecycle

补两类测试。

## one-shot

```text
start fork run
↓
provider 被卸载
↓
router tool 从 registry 消失
↓
已创建的 run 按 DSH holder contract 自己 settle/dispose
```

不要假设 provider remove 自动杀现存 run；按真实 DSH contract 断言。

## continuable

```text
start child
↓
spawn provider remove
↓
router tool 消失
```

之后 cold child 是否还能 `send_message` 取决于 provider 是否重新出现；测试真实行为并在 README 说明。

---

# 23. Model-facing schema 保持不变

继续只暴露：

```text
description
prompt
provider
model
```

不要新增：

```text
execution_mode
subagent_provider
api_key
token
base_url
endpoint
headers
max_tokens
run_in_background
```

backend/mode 继续由插件实例配置控制。

---

# 24. 不新增 system prompt section

继续保持：

```ts
export const inject = ['tools', 'subagents']
```

不要加入 `systemPrompt`。

router 使用说明继续由：

```text
tool description
providerWording
result render
README
```

表达。

---

# 25. P2 — DSH Compatibility CI

当前 peer 依赖为 rc.8 family。

router 直接依赖多个 DSH public contracts，因此建议增加：

```text
minimum-supported
latest-compatible
```

两条 CI lane。

## Minimum

固定当前声明的最低支持 DSH release family，例如：

```text
0.1.0-rc.8
```

运行：

```sh
npm ci
npm run typecheck
npm run test
npm run build
```

## Latest compatible

先解析一个统一：

```text
DSH_VERSION
```

然后所有：

```text
@deepseek-ai/dsh-*
```

都安装同一 release family。

不要混用：

```text
dsh-subagent rc.10
dsh-agent rc.8
dsh-tools rc.9
```

---

# 26. package dependency 规则保持现状

Runtime peers：

```text
@deepseek-ai/cordis
@deepseek-ai/dsh-agent
@deepseek-ai/dsh-invariants
@deepseek-ai/dsh-llm
@deepseek-ai/dsh-session
@deepseek-ai/dsh-subagent
@deepseek-ai/dsh-tools
```

测试专用：

```text
dsh-agent-loop
dsh-agent-loop-testkit
dsh-session-persistence*
dsh-subagent-fork-in-process
dsh-subagent-spawn-in-process
dsh-tool-subagent-control
```

继续放 `devDependencies`。

不要把 backend implementation 提升成 runtime peer，因为 router runtime 只按 provider name 消费 `ctx.subagents` seam。

---

# 27. 测试文件建议

建议新增：

```text
tests/official-coexistence.spec.ts
tests/fork-semantics.spec.ts
```

现有继续保留：

```text
tests/tool-subagent-router.spec.ts
tests/loader-composition.spec.ts
tests/bundle-patch.spec.ts
tests/harness.ts
tests/invariant.spec.ts
```

---

# 28. `official-coexistence.spec.ts` 必须覆盖

- 官方 `subagent` 与 router 同时存在；
- 官方 `subagent_fork` 与 router 同时存在；
- control tools 同时存在；
- 官方 schema 不变；
- router schema 独立；
- 官方 spawn delegation 可执行；
- 官方 fork delegation 可执行；
- router spawn 可执行；
- router fork 可执行；
- router toolName collision fail-fast。

---

# 29. `fork-semantics.spec.ts` 必须覆盖

- completed-turn inheritance；
- in-flight exclusion；
- selected provider；
- selected model；
- one-shot final output；
- run dispose；
- `send_message` 不可继续；
- `list_agents` 不列 one-shot；
- persona；
- toolFilter；
- maxDepth；
- allowedProviders；
- cancellation；
- concurrent sibling forks。

---

# 30. Loader composition 补强

现有 Loader REAL composition test 保留。

新增至少一条：

```text
Loader
+
official tool-subagent fork instance
+
router fork one-shot instance
```

在 Loader 层证明：

```text
官方 subagent_fork
+
router subagent_fork_route
```

可以同时存在并执行。

不能只在 `ctx.plugin()` integration suite 中验证 fork。

---

# 31. Bundle test 补强

现有 `bundle-patch.spec.ts` 保留。

新增：

- bundle 不修改官方 row id；
- bundle + official base composition 可一起加载；
- profile override 生效；
- profile 可以 insert 第二 router instance；
- 第二实例可绑定 `fork + one-shot`；
- tarball 包含 `cordis.patch.yml`。

---

# 32. README 最终结构建议

至少增加：

```text
Installation
Default bundle behavior
Dynamic spawn example
Dynamic fork example
Official tool coexistence
Support matrix
Continuation behavior
Fork one-shot behavior
Tool name collision rules
Known limitations
```

同时修正 control tools ownership。

---

# 33. 推荐动态 fork 示例

```yaml
- insert:
    - id: tool-subagent-router-fork
      name: '@xmoon76/dsh-subagent-router'
      config:
        subagentProvider: fork
        executionMode: one-shot
        toolName: subagent_fork_route
        maxDepth: 3
```

模型调用：

```json
{
  "description": "review prior design",
  "prompt": "Review the design discussed above and identify correctness or maintainability risks.",
  "provider": "openai",
  "model": "gpt-5.6"
}
```

---

# 34. Acceptance Criteria

## Fork

- [ ] router fork 使用官方 `fork` provider；
- [ ] router fork 走 `ctx.subagents.start()`；
- [ ] child 继承 parent completed turns；
- [ ] child 不继承 current in-flight turn；
- [ ] child 使用参数中的 provider；
- [ ] child 使用参数中的 model；
- [ ] one-shot 返回最终 child output；
- [ ] run 正确 dispose；
- [ ] one-shot 不可 `send_message`；
- [ ] one-shot 不作为 continuable child 出现在 `list_agents`。

## 官方共存

- [ ] 官方 `subagent` 同时存在；
- [ ] 官方 `subagent_fork` 同时存在；
- [ ] `send_message` 同时存在；
- [ ] `interrupt_agent` 同时存在；
- [ ] `list_agents` 同时存在；
- [ ] router 不修改官方 schema；
- [ ] router 不覆盖官方 tool；
- [ ] router 不重注册官方 provider；
- [ ] router 不重注册 `SubagentRuntime`。

## Bundle

- [ ] 保留 `dsh.bundle.patch`；
- [ ] `dsh plugin --profile ... add` 仍为主安装方式；
- [ ] bundle patch 只插 router 自身 row；
- [ ] 不复制官方 runtime/backend/control rows；
- [ ] profile override 可修改默认 router；
- [ ] profile 可新增第二 router fork instance；
- [ ] tarball 正确携带 `cordis.patch.yml`。

## 配置安全

- [ ] toolName collision fail-fast；
- [ ] 官方 tool name 给清晰错误；
- [ ] allowedProviders executor-level enforce；
- [ ] model schema 不暴露 credentials/backend/mode。

## Tests / CI

- [ ] package integration；
- [ ] Loader real composition；
- [ ] official coexistence；
- [ ] fork semantics；
- [ ] fork non-continuable；
- [ ] cancellation；
- [ ] concurrency；
- [ ] bundle overlay；
- [ ] 100% source coverage；
- [ ] minimum DSH CI lane；
- [ ] latest-compatible DSH CI lane。

---

# 35. 建议实施顺序

## Phase 1 — 官方共存

1. 增加 `official-coexistence.spec.ts`；
2. 暂不改生产代码；
3. 验证当前官方工具确实没有被覆盖；
4. 记录 collision 场景。

## Phase 2 — Collision 防御

1. 在 `mount(provider)` 检查 `ctx.tools.get(toolName)`；
2. 官方名字给专用错误；
3. provider late-add 路径也覆盖；
4. 补 HMR/race tests。

## Phase 3 — Fork semantics

1. completed-turn inheritance；
2. different parent/child route；
3. one-shot cannot continue；
4. list_agents 不显示 one-shot；
5. persona/toolFilter/maxDepth；
6. cancellation；
7. concurrent fork。

## Phase 4 — Loader + Bundle

1. Loader 增加官方共存 case；
2. Loader 增加 router fork case；
3. bundle + profile override；
4. bundle + second router instance。

## Phase 5 — 文档

1. 修 control tool 归属；
2. 增加 support matrix；
3. 增加动态 fork 示例；
4. 增加 official coexistence 说明；
5. 增加 toolName collision 说明；
6. 保持 bundle 安装流程为主路径。

## Phase 6 — Compatibility CI

1. minimum DSH；
2. latest-compatible DSH；
3. 全部 DSH packages 使用统一 version family；
4. tarball smoke 保持。

---

# 36. 给实现 Agent 的最终执行指令

```text
Do not redesign the plugin and do not remove the DSH Bundle packaging path.
`dsh plugin --profile <name> add @xmoon76/dsh-subagent-router` remains the
primary installation experience.

Keep the current architecture:
- continuable -> ctx.subagents.startContinuable()
- one-shot -> ctx.subagents.start()
- provider/model -> request.agentOptions
- official SubagentRuntime/providers/control tools remain the owners

Focus this iteration on compatibility and verification.

Required work:

1. Add REAL coexistence coverage with the official `subagent`,
   `subagent_fork`, `send_message`, `interrupt_agent`, and `list_agents`.
   Assert the router does not replace or mutate their schemas or behavior.

2. Add complete fork-one-shot semantics tests:
   - completed parent turns are inherited
   - the current in-flight parent turn is not inherited
   - the child actually uses the model-selected provider/model
   - the one-shot final output is returned and the run is disposed
   - its run id cannot be continued with `send_message`
   - it is not listed as a continuable child
   - persona/toolFilter/maxDepth/cancellation/concurrent fork behavior work

3. Add fail-fast tool-name collision handling in the provider mount path.
   Never shadow existing tools. Give DSH official subagent/control names a
   specific diagnostic and generic existing tool names a clear collision error.
   Cover late provider registration/HMR races.

4. Keep the shipped bundle patch. Strengthen bundle/profile-overlay tests:
   - the bundle inserts only the router row
   - it does not duplicate DSH subagent/runtime/backend/control rows
   - user/profile overrides work
   - a second router instance can be added for `fork + one-shot`

5. Document the supported matrix:
   spawn+continuable = recommended
   fork+one-shot = recommended
   spawn+one-shot = compatible
   fork+continuable = not recommended / upstream-experimental semantics

6. Fix README ownership wording:
   `send_message`, `interrupt_agent`, `list_agents` are control-package tools;
   official `subagent` / `subagent_fork` are separate
   `@deepseek-ai/dsh-tool-subagent` instances.

7. Add an official fork-router example using a non-conflicting name such as
   `subagent_fork_route`; never recommend configuring the router tool as
   `subagent` or `subagent_fork`.

8. Preserve the existing model-facing schema:
   description / prompt / provider / model only.
   Do not expose backend, execution mode, credentials, maxTokens, endpoint,
   or headers.

9. Keep route validation authoritative. Do not use listModels() as a whitelist.
   `resolveModelInfo()` may be considered only as a later optional preflight.

10. Add a DSH compatibility CI lane for the minimum supported release and the
    latest compatible release, installing all @deepseek-ai/dsh-* packages from
    one consistent version family.

Current DSH source/contracts win over this plan if upstream has changed.
Do not modify DSH core to satisfy the router.
```

---

# 37. 最终判断

本轮应把项目从：

```text
“功能已经实现”
```

提升到：

```text
“功能、fork 语义、官方共存、bundle 安装、升级兼容都由测试保证”
```

最值得投入的是：

```text
fork one-shot semantics
+
official coexistence
+
toolName collision protection
+
bundle/profile overlay tests
```

而不是重写当前已经正确的 SubagentRuntime Consumer 架构。

