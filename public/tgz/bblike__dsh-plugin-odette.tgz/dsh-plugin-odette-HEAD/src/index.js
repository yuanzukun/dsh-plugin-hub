/**
 * Host half for dsh-plugin-odette.
 *
 * The browser half contains the actual theme. This host half only serves the
 * theme's static assets (backgrounds, cursor, spinner) through the existing
 * dsh web server so the injected CSS can reference them with stable URLs.
 */
import { readFile } from 'node:fs/promises'
import { extname, join } from 'node:path'
import { fileURLToPath } from 'node:url'

const MIME = {
  '.svg': 'image/svg+xml; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.gif': 'image/gif',
  '.webp': 'image/webp',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
}

export const name = 'dsh-plugin-odette'

export function apply(ctx) {
  ctx.inject(['webServer'], (hostCtx) => {
    const assetsDir = fileURLToPath(new URL('../assets/', import.meta.url))
    hostCtx.effect(() => hostCtx.webServer.register({
      kind: 'prefix',
      path: '/odette-theme',
      handler: async (req, res) => {
        if (req.method !== 'GET' && req.method !== 'HEAD') {
          res.writeHead(405)
          res.end()
          return
        }
        let pathname
        try {
          pathname = decodeURIComponent(new URL(req.url ?? '/', 'http://dsh').pathname)
        } catch {
          res.writeHead(400)
          res.end()
          return
        }
        // Strip the asset prefix (route prefix is /odette-theme; client CSS
        // references /odette-theme/assets/*) and reject path traversal.
        const rel = pathname.startsWith('/odette-theme/assets/')
          ? pathname.slice('/odette-theme/assets/'.length)
          : ''
        if (rel === '' || rel.includes('\0') || rel.split('/').some(part => part === '..')) {
          res.writeHead(404)
          res.end()
          return
        }
        const file = join(assetsDir, rel)
        try {
          const body = await readFile(file)
          res.writeHead(200, {
            'content-type': MIME[extname(file).toLowerCase()] ?? 'application/octet-stream',
            'cache-control': 'no-cache',
            'x-content-type-options': 'nosniff',
          })
          res.end(body)
        } catch {
          res.writeHead(404)
          res.end()
        }
      },
    }), 'dsh-plugin-odette: static assets')
  })
}
