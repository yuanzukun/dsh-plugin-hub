/**
 * Browser half for dsh-plugin-odette (source).
 *
 * Built by scripts/build-client.mjs into lib/client.js in the DSH web module
 * format (window.__ModuleLoader__.load). Registers the "odette" theme and
 * injects the theme CSS (backgrounds, cursor, spinner, quote wash). The CSS
 * references assets served by the host half under /odette-theme/assets/*.
 */
export const inject = ['theme']

    export function apply(ctx) {
      // Idempotent injection: a live style tag means this plugin already ran
      // (double-apply without dispose), so skip the whole body.
      if (document.querySelector('style[data-plugin-css="dsh-plugin-odette"]') !== null) {
        return
      }

      // The Snezhnaya palette, reused for the theme registration and for the
      // CSS override layer that wins against sibling skins (liang-intensity).
      var odetteTokens = {
        '--dsw-alias-bg-base': '#0a0e1a',
          '--dsw-alias-bg-layer-1': '#101626',
          '--dsw-alias-bg-layer-2': '#151c30',
          '--dsw-alias-bg-layer-3': '#1b243c',
          '--dsw-alias-bg-overlay': '#1b243c',
          '--dsw-alias-bg-module-platform': '#101626',
          '--dsw-alias-bg-multi-select': '#151c30',
          '--dsw-alias-bg-skeleton': 'rgba(255,255,255,0.06)',
          '--dsw-alias-border-l1': 'rgba(180,210,255,0.10)',
          '--dsw-alias-border-l2': 'rgba(180,210,255,0.18)',
          '--dsw-alias-border-l3': 'rgba(180,210,255,0.26)',
          '--dsw-alias-border-l4': 'rgba(180,210,255,0.34)',
          '--dsw-alias-brand-primary': '#e8f4ff',
          '--dsw-alias-brand-text': '#e8f4ff',
          '--dsw-alias-brand-primary-invert': '#0a0e1a',
          '--dsw-alias-label-primary-inverted': '#0a0e1a',
          '--dsw-alias-label-primary': '#eef6ff',
          '--dsw-alias-label-secondary': '#b9c8e6',
          '--dsw-alias-label-tertiary': '#8396ba',
          '--dsw-alias-label-caption': '#6d7fa3',
          '--dsw-alias-label-dimmed': '#53617f',
          '--dsw-alias-state-business-primary': '#8fc7ff',
          '--dsw-alias-state-business-tertiary': '#14233d',
          '--dsw-alias-button-elevated-fill': '#16203a',
          '--dsw-alias-button-floating-hover': '#1a2745',
          '--dsw-specific-sidebar-fill': '#0d1322',
          '--dsw-specific-sidebar-nav-item-active': '#16203a',
          '--dsw-specific-sidebar-nav-item-active-accent': '#1c2b4a',
          '--dsw-specific-sidebar-nav-item-hover': '#131b31',
          '--dsw-specific-bubble': '#111a30',
          '--dsw-specific-bubble-highlight': '#1a2745',
          '--dsw-specific-input-major': '#101626',
          '--dsw-specific-menu': '#1b243c',
          '--dsw-specific-selector': '#151c30',
          '--dsw-specific-tip': '#111a30',
          // Markdown family: the app defaults these to LIGHT-mode values, which
          // turns inline code into white-on-light-grey when the preference is
          // not dark — Odette pins them to the Snezhnaya dark palette.
          '--dsw-alias-markdown-citation': 'rgba(143, 199, 255, 0.85)',
          '--dsw-alias-markdown-inline-code': 'rgba(143, 199, 255, 0.14)',
          '--dsw-alias-markdown-code-block': '#0d1424',
          '--dsw-alias-markdown-code-block-banner': '#131c33',
          '--dsw-alias-markdown-code-segment-selected': '#1a2745',
          '--dsw-alias-markdown-code-segment-unselected': '#0d1424',
          '--dsw-alias-markdown-placeholder': 'rgba(255, 255, 255, 0.06)',
          '--dsw-alias-markdown-tag': 'rgba(143, 199, 255, 0.14)'
      }

      // Register the dark Snezhnaya palette theme.
      var disposeTheme = ctx.theme.register({
        id: 'odette',
        colorScheme: 'dark',
        tokens: odetteTokens
      })

      // Activate the Odette theme on every boot. Custom theme ids are not part
      // of the built-in settings schema, so this in-process selection is
      // re-applied automatically when the plugin loads. Sibling skins call
      // setTheme themselves (e.g. liang-intensity forces light); pin the
      // preference here so Odette always wins.
      ctx.theme.setTheme('odette')

      // Force the dark palette regardless of the durable preference: the app's
      // token stylesheets key off body[data-ds-dark-theme], and sibling
      // plugins (e.g. ui-skin-center) may setTheme('light') over our pin.
      document.body.setAttribute('data-ds-dark-theme', '')
      document.documentElement.style.colorScheme = 'dark'

      // Tab favicon: the same snowflake as the default cursor.
      var icon = document.createElement('link')
      icon.rel = 'icon'
      icon.type = 'image/svg+xml'
      icon.href = '/odette-theme/assets/favicon.svg'

      var style = document.createElement('style')
      style.dataset.pluginCss = 'dsh-plugin-odette'
      style.textContent = [
        '/* Odette theme — Snezhnaya / winter skin */',
        'body[data-ds-dark-theme] {',
        '  background-color: #0a0e1a;',
        '  background-image: url("/odette-theme/assets/homepage-bg.jpg");',
        '  background-size: cover;',
        '  background-position: center;',
        '  background-attachment: fixed;',
        '}',
        '',
        '/* HARNESS badge plate in the sidebar wordmark: the plate follows',
        '   currentColor (grey in light mode) and the glyphs follow',
        '   --dsw-alias-label-primary-inverted. Pin both so it is always an',
        '   ice-blue plate with dark glyphs, never grey-on-white. */',
        'svg rect[width="52"][height="14"] {',
        '  fill: #8fc7ff !important;',
        '}',
        'svg [clip-path*="dsh-wordmark-badge-clip"] path {',
        '  fill: #0a0e1a !important;',
        '}',
        '',
        '/* Quote/emphasis: Snezhnaya translucent wash hugging the right edge and',
        '   fading left — never the grey liang box. */',
        'blockquote {',
        '  background: linear-gradient(to left, rgba(143,199,255,0.18), rgba(143,199,255,0.05) 55%, rgba(143,199,255,0) 100%) !important;',
        '  border-left-color: rgba(143,199,255,0.55) !important;',
        '  border-radius: 0 8px 8px 0 !important;',
        '  padding: 4px 12px 4px 14px !important;',
        '  color: #eef6ff !important;',
        '}',
        '',
        '/* Phase transitions (new session, session switch): fade in over 0.5s',
        '   instead of hard-swapping. Fires on element mount and on data-phase',
        '   change; the JS flow observer replays it for same-phase session',
        '   switches. */',
        '[data-phase] {',
        '  animation: dsh-odette-phase-fade 0.5s ease;',
        '}',
        '@keyframes dsh-odette-phase-fade {',
        '  from { opacity: 0.15; }',
        '  to { opacity: 1; }',
        '}',
        '',
        '/* Homepage (new-session hero) background */',
        '[data-phase="hero"] {',
        '  background-image: linear-gradient(rgba(8,12,24,0.35), rgba(8,12,24,0.55)), url("/odette-theme/assets/homepage-bg.jpg") !important;',
        '  background-size: cover !important;',
        '  background-position: center !important;',
        '}',
        '',
        '/* Conversation background while an agent turn is active or the session is replaying */',
        '[data-phase="active"], [data-phase="settling"] {',
        '  background-image: linear-gradient(rgba(8,12,24,0.55), rgba(8,12,24,0.75)), url("/odette-theme/assets/chat-bg.jpg") !important;',
        '  background-size: cover !important;',
        '  background-position: center !important;',
        '}',
        '',
        '/* Custom cursor: snowflake pointer everywhere, ballet-shoe only over',
        '   genuinely interactive surfaces. Plain text and whitespace keep the',
        '   default arrow; text inputs keep the I-beam caret. */',
        'html, body, * {',
        '  cursor: url("/odette-theme/assets/cursor.svg") 4 4, auto !important;',
        '}',
        'a:hover, button:hover, summary:hover, select:hover, label:hover,',
        'input[type="submit"]:hover, input[type="button"]:hover, input[type="checkbox"]:hover, input[type="radio"]:hover,',
        '[role="button"]:hover, [role="option"]:hover, [role="link"]:hover, [role="tab"]:hover,',
        '[role="menuitem"]:hover, [role="checkbox"]:hover, [role="radio"]:hover, [role="switch"]:hover,',
        '[role="treeitem"]:hover, [role="combobox"]:hover, [role="slider"]:hover, [role="gridcell"]:hover,',
        '[data-disclosure-row="true"]:hover {',
        '  cursor: url("/odette-theme/assets/cursor-hover.svg") 8 4, pointer !important;',
        '}',
        '/* Cursor does not inherit: let the children of interactive surfaces',
        '   (icons, spans) follow their parent so hovering a button shows the',
        '   shoe on the whole button, not just the text. */',
        'button *, a *, summary *, select *, label *,',
        '[role="button"] *, [role="option"] *, [role="link"] *, [role="tab"] *,',
        '[role="menuitem"] *, [role="treeitem"] *, [role="combobox"] *,',
        '[data-disclosure-row="true"] * {',
        '  cursor: inherit !important;',
        '}',
        '/* Keep the text caret where typing happens — at rest and while hovered. */',
        'input:not([type="submit"]):not([type="button"]):not([type="reset"]):not([type="checkbox"]):not([type="radio"]),',
        'textarea, [contenteditable="true"], [role="textbox"], [class*="cm-content"], [class*="ProseMirror"], [class*="xterm-rows"] {',
        '  cursor: text !important;',
        '}',
        'input:not([type="submit"]):not([type="button"]):not([type="reset"]):not([type="checkbox"]):not([type="radio"]):hover,',
        'textarea:hover, [contenteditable="true"]:hover, [role="textbox"]:hover, [class*="cm-content"]:hover,',
        '[class*="ProseMirror"]:hover, [class*="xterm-rows"]:hover {',
        '  cursor: text !important;',
        '}',
        '',
        '/* Thinking indicator: the running-turn status row (Deep diving...) — the',
        '   direct child of the chat flow. Deliberately NOT every role="status"',
        '   (retry countdowns, errors, picker loaders) and NOT every *spinner*:',
        '   those would each get a ballerina. */',
        '[data-chat-flow] > [role="status"]::before {',
        '  content: "";',
        '  display: inline-block;',
        '  width: 26px;',
        '  height: 26px;',
        '  margin-right: 8px;',
        '  vertical-align: -7px;',
        '  background: url("/odette-theme/assets/odette-spin.svg") 0 0 / 800% 100% no-repeat;',
        '  image-rendering: pixelated;',
        '  image-rendering: crisp-edges;',
        '  animation: dsh-odette-ballet-spin 1.6s steps(7) infinite;',
        '}',
        '@keyframes dsh-odette-ballet-spin {',
        '  from { background-position: 0 0; }',
        '  to { background-position: 100% 0; }',
        '}',
        '',
        '@media (prefers-reduced-motion: reduce) {',
        '  [data-chat-flow] > [role="status"]::before,',
        '  [data-phase] {',
        '    animation: none !important;',
        '  }',
        '}'
      ].join('\n')
      document.head.appendChild(style)
      // The app ships its own favicon link; insert ours first so browsers pick it.
      document.head.insertBefore(icon, document.head.firstChild)

      ctx.effect(function setup() {
        // Pin the theme: another installed skin (dsh-client-liang-intensity-skin)
        // forces light/native themes on its own; every change re-asserts Odette.
        var offTheme = ctx.on('theme/change', function onThemeChange(snapshot) {
          // Re-assert the dark attribute and palette even when another skin
          // switched the preference; the presenter would otherwise drop it.
          document.body.setAttribute('data-ds-dark-theme', '')
          document.documentElement.style.colorScheme = 'dark'
          if (snapshot.preference !== 'odette') {
            ctx.theme.setTheme('odette')
          }
        })

        // Belt-and-braces: any code path that removes the dark attribute
        // (presenter switching to a light snapshot) gets it restored.
        var darkObserver = new MutationObserver(function onDarkAttrChange() {
          if (!document.body.hasAttribute('data-ds-dark-theme')) {
            document.body.setAttribute('data-ds-dark-theme', '')
          }
        })
        darkObserver.observe(document.body, { attributes: true, attributeFilter: ['data-ds-dark-theme'] })

        // Replay the 0.5s phase fade when the chat flow is bulk-replaced
        // (session switch keeps data-phase="active" on the same element, so the
        // CSS animation alone would not fire). Streaming appends are small
        // and skipped; only batch swaps (>=4 nodes) trigger the fade.
        var fadeRoot = function fadeRoot() {
          var root = document.querySelector('[data-phase]')
          if (root === null) return
          root.style.animation = 'none'
          void root.offsetWidth
          root.style.animation = ''
        }
        var flowObserver = new MutationObserver(function onFlowChange(mutations) {
          // One batch of DOM writes arrives as many single-node records, so
          // sum them: a session switch swaps many nodes in one batch, while
          // streaming appends stay small.
          var total = 0
          for (var i = 0; i < mutations.length; i++) {
            var m = mutations[i]
            if (m.type !== 'childList') continue
            total += m.addedNodes.length + m.removedNodes.length
          }
          if (total >= 4) fadeRoot()
        })
        flowObserver.observe(document.body, { subtree: true, childList: true })

        // Override layer: same specificity + !important as the liang skin's
        // rules but loaded after them, so Odette backgrounds and tokens win.
        var tokensCss = Object.keys(odetteTokens)
          .map(function (name) { return name + ': ' + odetteTokens[name] + ' !important' })
          .join('; ')
        var override = document.createElement('style')
        override.dataset.pluginCss = 'dsh-plugin-odette-override'
        override.textContent = [
          '/* Odette wins against sibling skins (liang-intensity). */',
          'html {',
          '  color-scheme: dark !important;',
          '}',
          '/* Unconditional dark base: even when the durable preference is light',
          '   (another plugin or a manual switch) Odette stays dark. */',
          'body {',
          '  background-color: #0a0e1a !important;',
          '  background-image: url("/odette-theme/assets/homepage-bg.jpg") !important;',
          '  background-size: cover !important;',
          '  background-position: center !important;',
          '  background-attachment: fixed !important;',
          '  ' + tokensCss + ';',
          '}',
          'body[data-liang-skin="on"] {',
          '  background-color: #0a0e1a !important;',
          '  background-image: url("/odette-theme/assets/homepage-bg.jpg") !important;',
          '  background-size: cover !important;',
          '  background-position: center !important;',
          '  background-attachment: fixed !important;',
          '  ' + tokensCss + ';',
          '}',
          'body[data-liang-skin="on"] .liang-skin-backdrop {',
          '  display: none !important;',
          '}'
        ].join('\n')
        document.head.appendChild(override)

        return function cleanup() {
          offTheme()
          darkObserver.disconnect()
          flowObserver.disconnect()
          override.remove()
          style.remove()
          icon.remove()
          disposeTheme()
        }
      }, 'dsh-plugin-odette: styles and theme registry')
    }

    