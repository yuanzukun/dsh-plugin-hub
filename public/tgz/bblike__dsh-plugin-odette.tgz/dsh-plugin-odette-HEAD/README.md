# dsh-plugin-odette

DeepSeek Harness Web 的「奥黛塔 / 至冬」主题皮肤插件。

![主界面预览](assets/preview.png)

## 安装

在宿主终端执行：

```bash
dsh plugin --profile web add github:bblike/dsh-plugin-odette
```

安装后重启 `dsh web`，自动启用 `odette` 深色主题，无需手动切换。

## 包含内容

- 主页与对话背景
- 雪花 / 芭蕾舞鞋鼠标样式
- Agent 思考时的奥黛塔 Q 版芭蕾舞者转圈动画
- 冰蓝深色配色与标签页图标

## 开发

```bash
pnpm install
pnpm build   # 构建浏览器端产物 lib/client.js
pnpm test    # 冒烟测试
```

## License

MIT
