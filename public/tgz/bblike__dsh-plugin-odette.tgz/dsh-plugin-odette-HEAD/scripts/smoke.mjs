import { strict as assert } from 'node:assert'
import { fileURLToPath, pathToFileURL } from 'node:url'

const pluginDir = fileURLToPath(new URL('../', import.meta.url))

// ---------- Host half ----------
const host = await import(pathToFileURL(pluginDir + '/src/index.js'))
assert.equal(host.name, 'dsh-plugin-odette')

const routes = []
let hostEffectRan = false
const fakeHostCtx = {
  inject(deps, cb) {
    assert.deepEqual(deps, ['webServer'])
    const webServer = {
      register(opts) {
        routes.push(opts)
        return () => {}
      },
    }
    const effect = (fn) => { hostEffectRan = true; return fn() }
    cb({ webServer, effect })
  },
}
host.apply(fakeHostCtx)
assert.equal(routes.length, 1)
assert.equal(routes[0].kind, 'prefix')
assert.equal(routes[0].path, '/odette-theme')
assert.ok(hostEffectRan, 'host effect ran')

// Exercise the asset handler for every asset referenced by client.js.
const assets = ['homepage-bg.jpg', 'chat-bg.jpg', 'cursor.svg', 'cursor-hover.svg', 'odette-spin.svg', 'favicon.svg']
for (const asset of assets) {
  const res = { status: 0, headers: {}, body: null }
  const req = { method: 'GET', url: '/odette-theme/assets/' + asset }
  await new Promise((resolve) => {
    res.writeHead = (status, headers) => { res.status = status; res.headers = headers }
    res.end = (body) => { res.body = body; resolve() }
    routes[0].handler(req, res)
  })
  assert.equal(res.status, 200, asset + ' served')
  assert.ok(String(res.headers['content-type']).startsWith('image/'), asset + ' typed')
  assert.equal(res.headers['x-content-type-options'], 'nosniff')
  assert.ok(res.body.length > 0, asset + ' non-empty')
}
// Traversal + malformed percent-encoding rejected.
{
  const res = { writeHead(s) { this.status = s }, end() {} }
  await routes[0].handler({ method: 'GET', url: '/odette-theme/assets/../lib/index.js' }, res)
  assert.equal(res.status, 404)
  const res2 = { writeHead(s) { this.status = s }, end() {} }
  await routes[0].handler({ method: 'GET', url: '/odette-theme/assets/%E0%A4%A' }, res2)
  assert.equal(res2.status, 400)
}
console.log('host half OK: route prefix registered; 6 assets; traversal + malformed guarded')

// ---------- Browser half ----------
let loadedDef = null
const styles = []
const icons = []
globalThis.window = {
  __ModuleLoader__: { load(def) { loadedDef = def } },
}
globalThis.MutationObserver = class {
  constructor(cb) { this.cb = cb }
  observe() {}
  disconnect() {}
}

globalThis.document = {
  body: {
    _attrs: {},
    dataset: {},
    setAttribute(n, v) { this._attrs[n] = v },
    hasAttribute(n) { return n in this._attrs },
    getAttribute(n) { return n in this._attrs ? this._attrs[n] : null },
    removeAttribute(n) { delete this._attrs[n] },
    style: { setProperty() {} },
  },
  documentElement: { style: { colorScheme: '' } },
  querySelector() { return styles.length > 0 ? { isStyle: true } : null },
  createElement(tag) {
    if (tag === 'style') {
      const el = { tagName: 'STYLE', dataset: {}, textContent: '', remove() { const i = styles.indexOf(el); if (i >= 0) styles.splice(i, 1) } }
      return el
    }
    if (tag === 'link') {
      return { tagName: 'LINK', remove() { const i = icons.indexOf(this); if (i >= 0) icons.splice(i, 1) } }
    }
    throw new Error('unexpected tag ' + tag)
  },
  head: {
    appendChild(el) {
      if (el.tagName === 'STYLE') styles.push(el)
      if (el.tagName === 'LINK') icons.push(el)
    },
    insertBefore(el) {
      if (el.tagName === 'STYLE') styles.push(el)
      if (el.tagName === 'LINK') icons.push(el)
    },
  },
}
await import(pathToFileURL(pluginDir + '/lib/client.js'))
assert.ok(loadedDef, 'client module registered')
assert.equal(loadedDef.id, 'dsh-plugin-odette')

const mod = loadedDef.factory((id) => { throw new Error('unexpected require ' + id) })
assert.deepEqual(mod.inject, ['theme'])
assert.equal(typeof mod.apply, 'function')

let registered = null
let setTo = null
let disposed = false
let offCalled = false
const effects = []
const listeners = []
const clientCtx = {
  theme: {
    register(def) { registered = def; return () => { disposed = true } },
    setTheme(id) { setTo = id },
  },
  effect(fn, name) { effects.push({ fn, name }) },
  on(ev, cb) { listeners.push({ ev, cb }); return () => { offCalled = true } },
}
mod.apply(clientCtx)
assert.equal(registered.id, 'odette')
assert.equal(registered.colorScheme, 'dark')
assert.equal(setTo, 'odette')
assert.equal(styles.length, 1)
assert.equal(icons.length, 1)
assert.equal(icons[0].rel, 'icon')
assert.equal(icons[0].href, '/odette-theme/assets/favicon.svg')
const css = styles[0].textContent
for (const needle of [
  'url("/odette-theme/assets/homepage-bg.jpg")',
  'url("/odette-theme/assets/chat-bg.jpg")',
  'url("/odette-theme/assets/cursor.svg")',
  'url("/odette-theme/assets/cursor-hover.svg")',
  'url("/odette-theme/assets/odette-spin.svg")',
  '[data-phase="hero"]',
  '[data-phase="active"], [data-phase="settling"]',
  'background: url("/odette-theme/assets/odette-spin.svg") 0 0 / 800% 100% no-repeat',
  'animation: dsh-odette-ballet-spin 1.6s steps(7) infinite',
  '@keyframes dsh-odette-ballet-spin',
  'background-position: 100% 0',
  'prefers-reduced-motion',
]) {
  assert.ok(css.includes(needle), 'CSS includes ' + needle)
}
assert.equal(effects.length, 1)
// Run the setup effect: registers the pin listener and the override style.
const setupCleanup = effects[0].fn()
assert.ok(listeners.some(l => l.ev === 'theme/change'), 'theme/change pin listener registered')
const pinned = listeners.find(l => l.ev === 'theme/change')
pinned.cb({ preference: 'light' })
assert.equal(setTo, 'odette', 'theme pinned back to odette')
assert.equal(styles.length, 2, 'override style appended')
assert.ok(styles[1].textContent.includes('body[data-liang-skin="on"]'), 'liang override layer present')
assert.ok(styles[1].textContent.includes('!important'), 'override uses !important')
// Idempotency: a second apply while the style is still live must be a no-op.
let themeCalls = 0
const clientCtx2 = {
  theme: { register() { themeCalls++ }, setTheme() { themeCalls++ } },
  effect() {},
}
mod.apply(clientCtx2)
assert.equal(themeCalls, 0, 'double-apply is a no-op')
console.log('browser half OK: theme odette registered + set; 6 asset URLs; favicon; idempotent apply')

// Cleanup path: dispose removes style + icon + theme.
const cleanup = setupCleanup
cleanup()
assert.ok(disposed)
assert.ok(offCalled)
assert.equal(styles.length, 0)
assert.equal(icons.length, 0)
console.log('cleanup OK: styles/icon/theme/listener disposed')

console.log('SMOKE PASS')
