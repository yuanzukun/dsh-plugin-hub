# 🌐 DSH 屏幕即时翻译插件 (DSH Screen Translator)

[![GitHub License](https://img.shields.io/badge/license-MIT-blue.svg)](LICENSE)
[![DSH Compatibility](https://img.shields.io/badge/dsh->=0.1.2-green.svg)](https://github.com/deepseek-ai/deepseek-harness)
[![Topic](https://img.shields.io/badge/topic-dsh--plugin-orange.svg)](https://github.com/topics/dsh-plugin)

> **专为 DeepSeek Harness Web UI 打造的全屏全域自动翻译插件。**  
> 实时翻译界面文本、导航菜单、设置项、侧边栏、MCP 连接器、嵌套 iframe 及 Shadow DOM 组件，支持 **45+ 种语言**，无需外部 API 密钥，免受频控限制。

---

## 📖 [English](./README.md) | 中文说明

---

## ✨ 核心特性

- **🌍 支持 45+ 种语言** — 覆盖英语、简体中文、繁体中文、粤语、日语、韩语、西班牙语、法语、德语、俄语、阿拉伯语等全球主流语言。
- **⚡ 多端节点自动轮询引擎** — 自动在 `dict-chrome-ex`、`clients5`、`single-at`、`web-at` 节点间故障转移，规避 `429 Too Many Requests` 限流。
- **🔍 全维度 DOM 节点覆盖**:
  - 普通文本节点与 SVG 矢量文字（`<text>`、`<tspan>`）。
  - 常见输入与交互属性（`placeholder`、`title`、`alt`、`aria-label`、`aria-placeholder`）。
  - Open 模式的 Shadow DOM 组件根节点。
  - 同源及嵌套 iframe 视窗（MCP 面板、弹窗浮层等）。
- **🚀 极致性能与无感加载**:
  - **双层缓存架构**（内存 LRU + LocalStorage 持久化）— 二次访问已翻译词条 `0ms` 命中。
  - **智能防抖 MutationObserver** — 仅监听并处理新挂载的增量 DOM 树，无死循环扫描。
  - **标点断句智能拆分** — 依照中英文句号与断句符（`。`、`！`、`？`、`.`、`!`、`?`）分块，保留行文语境。
  - **防循环污染机制** — 严格跳过代码块、语法高亮区、输入框与带有 `[data-no-translate]` 标记的元素。
- **🎛️ 原生界面风格融合**:
  - 适配 **设置 → 通用** 面板，遵循 DSH 原生主题样式规范。
  - 包含状态实时监控、目标语言选择、一键全屏翻译与缓存一键清除功能。

---

## 📦 安装指南

### 方法 1：通过 DSH 插件管理器安装（推荐）

在终端或 DSH 会话中执行：

```bash
dsh plugin add mustakimabdullah25-tech/dsh-screen-translator
```

### 方法 2：源码安装

克隆仓库至本地 DSH 插件目录：

```bash
cd "path/to/dsh-workspace/plugins"
git clone https://github.com/mustakimabdullah25-tech/dsh-screen-translator.git
```

在当前 profile 中启用该 bundle：

```bash
dsh plugin add ./plugins/dsh-screen-translator
```

---

## ⚙️ 配置与使用

安装并启用后：

1. 打开 **设置 (Settings)** → **通用 (General)**。
2. 找到 **Screen Translator (Auto-Translate Everywhere)** 配置行。
3. 在下拉菜单中选择目标语言（如中文或英文）。
4. 点击 **Enabled** 按钮即可开启实时界面翻译。
5. 如需立即刷新视窗内全部文本，可点击 **⚡ Translate now**；点击 **Clear Cache** 可重置本地缓存。

---

## 📁 目录结构

```
dsh-screen-translator/
├── client.js          # 客户端 Bundle：DOM 翻译引擎、缓存控制与设置面板 UI
├── index.js           # 宿主入口文件（Cordis apply 挂载点）
├── cordis.patch.yml   # Cordis 编排补丁配置文件
├── package.json       # 插件清单与包元数据
├── README.md          # 英文文档
├── README_ZH.md       # 中文文档
└── LICENSE            # MIT 开源协议
```

---

## 📄 开源协议

本项目采用 [MIT License](LICENSE) 开源协议。
