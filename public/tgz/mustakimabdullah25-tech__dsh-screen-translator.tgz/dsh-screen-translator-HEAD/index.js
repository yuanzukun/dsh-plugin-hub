export function apply(ctx) {
  // Host plugin registration for dsh-screen-translator
}
