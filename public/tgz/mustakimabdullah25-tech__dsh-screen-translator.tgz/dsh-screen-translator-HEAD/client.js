// @local/dsh-screen-translator — fast, clean, universal screen translator v3.0.0
//
// Key Features:
//  - 45+ languages with instant searchable picker.
//  - Multi-endpoint Google fallback (dict-chrome-ex + clients5 + single-at + web-at) — eliminates 429 rate limit blocks.
//  - Translates EVERYTHING on screen:
//      * Visible text nodes & SVG text (<text>, <tspan>)
//      * All attributes (placeholder, title, alt, aria-label, aria-placeholder) on inputs/buttons
//      * Open Shadow DOM roots
//      * Same-origin and nested iframes (MCP panels, modals)
//      * Long text chunks naturally at sentence boundaries
//  - High Performance:
//      * Memory + LocalStorage LRU caching (instant 0ms on repeat visits)
//      * Debounced MutationObserver (only translates newly added DOM, no polling loops)
//      * Concurrency limiter & exponential backoff on errors
//      * requestIdleCallback initial scanning
//  - Clean & Universal Compatibility:
//      * Works with AND without DSH Codex Desktop / plain Web UI / headless
//      * All slots registered independently with try/catch
//      * Proper cleanup via ctx.effect
//      * [data-no-translate] on self UI to prevent self-translation loops

function createTranslatorFactory() {
  return function(require) {
      const React = require('react');
      const { useState, useEffect } = React;
      const h = React.createElement;

      const hasDOM = () =>
        typeof window !== 'undefined' && typeof document !== 'undefined';

      function onIdle(fn, fallbackMs) {
        try {
          if (typeof requestIdleCallback !== 'undefined') {
            requestIdleCallback(fn, { timeout: 2000 });
            return;
          }
        } catch (e) {}
        setTimeout(fn, fallbackMs == null ? 300 : fallbackMs);
      }

      // ---------------------------------------------------------- config ---
      const TARGET_LANGUAGES = [
        { code: 'en', name: 'English (US / UK)' },
        { code: 'en-GB', name: 'English (UK)' },
        { code: 'zh-CN', name: '简体中文 (Chinese Simplified)' },
        { code: 'zh-TW', name: '繁體中文 (Chinese Traditional)' },
        { code: 'zh-HK', name: '粵語 (Cantonese)' },
        { code: 'ja', name: '日本語 (Japanese)' },
        { code: 'ko', name: '한국어 (Korean)' },
        { code: 'es', name: 'Español (Spanish)' },
        { code: 'fr', name: 'Français (French)' },
        { code: 'de', name: 'Deutsch (German)' },
        { code: 'ru', name: 'Русский (Russian)' },
        { code: 'it', name: 'Italiano (Italian)' },
        { code: 'pt', name: 'Português (Portuguese)' },
        { code: 'ar', name: 'العربية (Arabic)' },
        { code: 'hi', name: 'हिन्दी (Hindi)' },
        { code: 'vi', name: 'Tiếng Việt (Vietnamese)' },
        { code: 'th', name: 'ไทย (Thai)' },
        { code: 'id', name: 'Bahasa Indonesia (Indonesian)' },
        { code: 'ms', name: 'Bahasa Melayu (Malay)' },
        { code: 'fil', name: 'Filipino' },
        { code: 'tr', name: 'Türkçe (Turkish)' },
        { code: 'nl', name: 'Nederlands (Dutch)' },
        { code: 'pl', name: 'Polski (Polish)' },
        { code: 'uk', name: 'Українська (Ukrainian)' },
        { code: 'el', name: 'Ελληνικά (Greek)' },
        { code: 'he', name: 'עברית (Hebrew)' },
        { code: 'fa', name: 'فارسی (Persian)' },
        { code: 'ur', name: 'اردو (Urdu)' },
        { code: 'bn', name: 'বাংলা (Bengali)' },
        { code: 'ta', name: 'தமிழ் (Tamil)' },
        { code: 'te', name: 'తెలుగు (Telugu)' },
        { code: 'mr', name: 'मराठी (Marathi)' },
        { code: 'sw', name: 'Kiswahili (Swahili)' },
        { code: 'sv', name: 'Svenska (Swedish)' },
        { code: 'no', name: 'Norsk (Norwegian)' },
        { code: 'da', name: 'Dansk (Danish)' },
        { code: 'fi', name: 'Suomi (Finnish)' },
        { code: 'cs', name: 'Čeština (Czech)' },
        { code: 'ro', name: 'Română (Romanian)' },
        { code: 'hu', name: 'Magyar (Hungarian)' },
        { code: 'bg', name: 'Български (Bulgarian)' },
        { code: 'hr', name: 'Hrvatski (Croatian)' },
        { code: 'sr', name: 'Српски (Serbian)' },
        { code: 'sk', name: 'Slovenčina (Slovak)' },
        { code: 'sl', name: 'Slovenščina (Slovenian)' }
      ];

      const KEY_ENABLED = 'dsh_auto_translate_enabled';
      const KEY_TARGET = 'dsh_auto_translate_target_lang';
      const KEY_CACHE = 'dsh_auto_translate_cache_v10';
      const KEY_CACHE_OLD = 'dsh_auto_translate_cache_v9';
      const READY_FLAG = '__dshTranslatorReady';

      const MAX_TEXT_LEN = 4000;
      const CHUNK_AT = 900;
      const CHUNK_MAX = 4;
      const BATCH_SIZE = 32;
      const CHUNK_CAP = 64;
      const CONCURRENCY = 8;
      const FETCH_TIMEOUT_MS = 4000;
      const MAX_RETRIES = 3;
      const RETRY_BASE_MS = 600;
      const QUEUE_CAP = 600;
      const APPLIER_CAP = 50;
      const SCAN_NODE_CAP = 3000;
      const SCAN_EL_CAP = 3000;
      const CACHE_CAP = 8000;

      const ATTR_NAMES = ['placeholder', 'title', 'alt', 'aria-label', 'aria-placeholder'];

      const isBadTranslation = (str) => {
        if (!str || typeof str !== 'string') return true;
        const s = str.trim().toUpperCase();
        if (s.includes('PLEASE SELECT TWO DISTINCT LANGUAGES')) return true;
        if (s.includes('PLEASE SELECT')) return true;
        if (s.startsWith('MYMEMORY')) return true;
        if (s.includes('INVALID LANGUAGE')) return true;
        if (s.includes('QUERY LENGTH LIMIT')) return true;
        if (s.includes('YOU HAVE USED ALL')) return true;
        if (s.includes('NO QUERY SPECIFIED')) return true;
        if (s.includes('AUTODETECT')) return true;
        if (s.startsWith('<!DOCTYPE') || s.startsWith('<HTML')) return true;
        return false;
      };

      // Curated seed dictionary for instantaneous UI render on first launch
      const CORE_PAIRS = [
        ['全局技能', 'Global skills', '全局技能'],
        ['项目技能', 'Project skills', '项目技能'],
        ['回收站', 'Trash', '回收站'],
        ['搜索技能名称或描述', 'Search skill names or descriptions', '搜索技能名称或描述'],
        ['搜索设置...', 'Search settings...', '搜索设置...'],
        ['公共 Agent', 'Shared Agent', '公共 Agent'],
        ['共享 Agent', 'Shared Agent', '共享 Agent'],
        ['调用状态', 'Invocation status', '调用状态'],
        ['全部状态', 'All statuses', '全部状态'],
        ['已启用', 'Enabled', '已启用'],
        ['已禁用', 'Disabled', '已禁用'],
        ['检查更新', 'Check for updates', '检查更新'],
        ['创建技能', 'Create skill', '创建技能'],
        ['导入到全局 DSH', 'Import to global DSH', '导入到全局 DSH'],
        ['对话', 'Chat', '对话'],
        ['轨迹', 'Trajectory', '轨迹'],
        ['上下文', 'Context', '上下文'],
        ['市场', 'Market', '市场'],
        ['已安装', 'Installed', '已安装'],
        ['工具', 'Tools', '工具'],
        ['搜索连接器...', 'Search connectors...', '搜索连接器...'],
        ['+ 添加连接', '+ Add Connection', '+ 添加连接'],
        ['添加连接', 'Add Connection', '添加连接'],
        ['刷新连接器目录', 'Refresh Catalog', '刷新连接器目录'],
        ['全部', 'All', '全部'],
        ['推荐', 'Recommended', '推荐'],
        ['企业数据', 'Enterprise Data', '企业数据'],
        ['金融投资', 'Finance & Stocks', '金融投资'],
        ['法律合规', 'Legal & Compliance', '法律合规'],
        ['开发工具', 'Developer Tools', '开发工具'],
        ['办公协作', 'Office Collaboration', '办公协作'],
        ['调研分析', 'Research & Analysis', '调研分析'],
        ['设计创意', 'Design & Creative', '设计创意'],
        ['效率工具', 'Productivity Tools', '效率工具'],
        ['其他', 'Other', '其他'],
        ['详情', 'Details', '详情'],
        ['连接', 'Connect', '连接'],
        ['已连接', 'Connected', '已连接'],
        ['未连接', 'Disconnected', '未连接'],
        ['本地运行', 'Local Runtime', '本地运行'],
        ['连接器', 'Connectors', '连接器'],
        ['自定义配置', 'Custom Configuration', '自定义配置'],
        ['导入 JSON', 'Import JSON', '导入 JSON'],
        ['导出配置', 'Export Config', '导出配置'],
        ['连接状态', 'Connection Status', '连接状态'],
        ['重新授权', 'Re-authorize', '重新授权'],
        ['工具清单', 'Tools List', '工具清单'],
        ['健康检查', 'Health Check', '健康检查'],
        ['工作区', 'Workspace', '工作区'],
        ['你好', 'Hello', '你好'],
        ['今日消耗金额', "Today's Usage Cost", '今日消耗金额'],
        ['暂无会话', 'No chats', '暂无会话'],
        ['暂无对话', 'No chats', '暂无对话'],
        ['新建会话', 'New Chat', '新建会话'],
        ['会话列表', 'Sessions', '会话列表'],
        ['已置顶', 'Pinned', '已置顶'],
        ['置顶', 'Pinned', '置顶'],
        ['项目', 'Projects', '项目'],
        ['最近', 'Recents', '最近'],
        ['设置', 'Settings', '设置'],
        ['通用设置', 'General', '通用设置'],
        ['外观主题', 'Appearance', '外观主题'],
        ['界面语言', 'Language', '界面语言'],
        ['模型提供商', 'Models', '模型提供商'],
        ['完全权限', 'Full access', '完全权限'],
        ['只读权限', 'Read only', '只读权限'],
        ['工作区写入', 'Workspace write', '工作区写入'],
        ['创作者模式', 'Creator mode', '创作者模式'],
        ['权限模式', 'Permissions', '权限模式'],
        ['新建任务', 'New task', '新建任务'],
        ['扩展功能', 'Extensions', '扩展功能'],
        ['专家团队', 'Experts', '专家团队'],
        ['技能库', 'Skills', '技能库'],
        ['插件', 'Plugins', '插件'],
        ['计划任务', 'Scheduled Tasks', '计划任务'],
        ['任务', 'Tasks', '任务'],
        ['浅色', 'Light', '浅色'],
        ['深色', 'Dark', '深色'],
        ['跟随系统', 'System', '跟随系统'],
        ['返回应用', 'Back to app', '返回应用'],
        ['翻译', 'Translate', '翻译'],
        ['语音朗读', 'Read Aloud', '语音朗读'],
        ['复制', 'Copy', '复制'],
        ['清空', 'Clear', '清空'],
        ['关闭', 'Close', '关闭']
      ];

      // ---------------------------------------------------------- storage ---
      const safeGet = (k) => {
        try {
          return typeof localStorage !== 'undefined' ? localStorage.getItem(k) : null;
        } catch (e) { return null; }
      };
      const safeSet = (k, v) => {
        try {
          if (typeof localStorage !== 'undefined') localStorage.setItem(k, v);
        } catch (e) {}
      };
      const safeDel = (k) => {
        try {
          if (typeof localStorage !== 'undefined') localStorage.removeItem(k);
        } catch (e) {}
      };

      // ---------------------------------------------------------- cache ---
      const cache = new Map();
      for (const [src, en, zh] of CORE_PAIRS) {
        cache.set(`en:::${src}`, en);
        cache.set(`zh-CN:::${src}`, zh);
      }
      function purgePoisonedStorage() {
        try {
          if (typeof localStorage === 'undefined') return;
          const keys = ['dsh_auto_translate_cache_v10', 'dsh_auto_translate_cache_v9', 'dsh_auto_translate_cache_v8'];
          for (const key of keys) {
            const raw = localStorage.getItem(key);
            if (!raw) continue;
            try {
              const parsed = JSON.parse(raw);
              let changed = false;
              for (const k of Object.keys(parsed)) {
                if (isBadTranslation(parsed[k])) {
                  delete parsed[k];
                  changed = true;
                }
              }
              if (changed) localStorage.setItem(key, JSON.stringify(parsed));
            } catch (e) {}
          }
        } catch (e) {}
      }
      purgePoisonedStorage();

      function importSaved(raw) {
        if (!raw) return 0;
        try {
          const parsed = JSON.parse(raw);
          let n = 0;
          for (const k of Object.keys(parsed)) {
            if (typeof parsed[k] !== 'string' || isBadTranslation(parsed[k])) continue;
            if (!cache.has(k)) { cache.set(k, parsed[k]); n++; }
            if (cache.size >= CACHE_CAP) break;
          }
          return n;
        } catch (e) { return 0; }
      }
      importSaved(safeGet(KEY_CACHE));
      if (!safeGet(KEY_CACHE)) {
        importSaved(safeGet(KEY_CACHE_OLD));
      }

      let persistTimer = null;
      function persistNow() {
        persistTimer = null;
        try {
          const obj = {};
          let n = 0;
          for (const [k, v] of cache) {
            if (n++ >= CACHE_CAP) break;
            obj[k] = v;
          }
          safeSet(KEY_CACHE, JSON.stringify(obj));
        } catch (e) {}
      }
      function persistSoon() {
        if (persistTimer) return;
        try {
          persistTimer = setTimeout(persistNow, 1500);
        } catch (e) {}
      }

      const cacheKey = (lang, text) => `${lang}:::${text}`;
      function getCached(lang, text) {
        const k = cacheKey(lang, text);
        const v = cache.get(k);
        if (v !== undefined) {
          cache.delete(k);
          cache.set(k, v);
        }
        return v;
      }
      function setCached(lang, text, translated) {
        if (isBadTranslation(translated)) return;
        const k = cacheKey(lang, text);
        if (cache.has(k)) cache.delete(k);
        cache.set(k, translated);
        while (cache.size > CACHE_CAP) {
          const oldest = cache.keys().next().value;
          cache.delete(oldest);
        }
        persistSoon();
      }

      // ---------------------------------------------------------- language detection ---
      const RE_CJK = /[\u4e00-\u9fff\u3400-\u4dbf\uf900-\ufaff\u3007]/;
      const RE_JA = /[\u3040-\u30ff]/;
      const RE_KO = /[\uac00-\ud7af\u1100-\u11ff]/;
      const RE_CYR = /[\u0400-\u04ff]/;
      const RE_ARAB = /[\u0600-\u06ff]/;
      const RE_HEBR = /[\u0590-\u05ff]/;
      const RE_DEVA = /[\u0900-\u097f]/;
      const RE_BENG = /[\u0980-\u09ff]/;
      const RE_TAMIL = /[\u0b80-\u0bff]/;
      const RE_TELU = /[\u0c00-\u0c7f]/;
      const RE_THAI = /[\u0e00-\u0e7f]/;
      const RE_GREEK = /[\u0370-\u03ff]/;
      const RE_NON_LATIN_SCRIPTS = /[\u4e00-\u9fff\u3400-\u4dbf\uf900-\ufaff\u3040-\u30ff\uac00-\ud7af\u0400-\u04ff\u0600-\u06ff\u0590-\u05ff\u0900-\u097f\u0b80-\u0bff\u0c00-\u0c7f\u0e00-\u0e7f\u0370-\u03ff]/;
      const RE_FOREIGN_ACCENTS = /[áàâäãåçéèêëíìîïñóòôöõúùûüýÿæœß¿¡]/i;

      const ALREADY = {
        fr: /[çœæêèàâîôûëï]/i,
        de: /[äöüß]/i,
        es: /[ñáéíóúü¿¡]/i,
        pt: /[ãõçáéíóúâêôà]/i,
        it: /[àèéìíîòóù]/i,
        nl: /[ëïéèê]/i,
        pl: /[ąćęłńóśźż]/i,
        tr: /[çğıöşü]/i,
        cs: /[áčďéěíňóřšťúůýž]/i,
        ro: /[ăâîșț]/i,
        hu: /[áéíóöőúüű]/i,
        vi: /[àáạảãâầấậẩẫăằắặẳẵèéẹẻẽêềếệểễìíịỉĩòóọỏõôồốộổỗơờớợởỡùúụủũưừứựửữỳýỵỷỹđ]/i,
        sv: /[åäö]/i,
        no: /[åæø]/i,
        da: /[åæø]/i,
        fi: /[äö]/i,
        id: /[a-z]/i,
        ms: /[a-z]/i,
        fil: /[a-z]/i,
        sw: /[a-z]/i,
        hr: /[čćđšž]/i,
        sk: /[áäčďéíĺľňóôŕšťúýž]/i,
        sl: /[čšž]/i
      };

      function stripCJK(t) {
        return t.replace(/[\u4e00-\u9fff\u3400-\u4dbf\uf900-\ufaff\u3007]/g, '');
      }

      function needsTranslation(text, targetLang) {
        if (!text || typeof text !== 'string') return false;
        const t = text.trim();
        if (!t || t.length > MAX_TEXT_LEN) return false;
        if (!/\p{L}/u.test(t)) return false;
        if (/^\d+(\.\d+)?\s*(MB|GB|KB|Mbps|Kbps|bps|tok|tok\/s|ms|s|min|hr|%)\b/i.test(t)) return false;
        if (/^(https?:\/\/|wss?:\/\/|[A-Za-z]:\\|\/|mailto:|tel:)/.test(t)) return false;
        if (/^[a-f0-9]{32,64}$/i.test(t)) return false;
        if (/^[a-zA-Z0-9_-]+\.(json|ya?ml|js|ts|tsx|jsx|css|html|md|png|jpe?g|gif|svg|zstd|lock)$/i.test(t)) return false;
        if (isBadTranslation(t)) return false;

        const base = String(targetLang).split('-')[0];

        if (base === 'en') {
          if (RE_NON_LATIN_SCRIPTS.test(t)) return true;
          if (RE_FOREIGN_ACCENTS.test(t)) return true;
          return false;
        }

        if (base === 'zh' || targetLang === 'yue') {
          if (!RE_CJK.test(t) && !RE_JA.test(t) && !RE_KO.test(t)) {
            return /[a-zA-Z]{2,}/.test(t);
          }
          const rest = stripCJK(t);
          if (RE_JA.test(rest) || RE_KO.test(rest)) return true;
          const latin = (rest.match(/[a-zA-Z]/g) || []).length;
          return latin >= 4;
        }

        if (base === 'ja') {
          if (RE_JA.test(t)) return false;
          return true;
        }

        if (base === 'ko') return !RE_KO.test(t);
        if (base === 'ru' || base === 'uk' || base === 'bg' || base === 'sr') return !RE_CYR.test(t);
        if (base === 'ar' || base === 'fa' || base === 'ur') return !RE_ARAB.test(t);
        if (base === 'he') return !RE_HEBR.test(t);
        if (base === 'hi' || base === 'mr') return !RE_DEVA.test(t);
        if (base === 'bn') return !RE_BENG.test(t);
        if (base === 'ta') return !RE_TAMIL.test(t);
        if (base === 'te') return !RE_TELU.test(t);
        if (base === 'th') return !RE_THAI.test(t);
        if (base === 'el') return !RE_GREEK.test(t);

        const already = ALREADY[base];
        if (already && already.test(t) && !RE_NON_LATIN_SCRIPTS.test(t)) return false;
        return true;
      }

      // Exclusion rules for text nodes vs attribute nodes
      function isNodeExcludedFromText(el) {
        if (!el || !el.tagName) return true;
        const tag = el.tagName.toLowerCase();
        if (['script', 'style', 'pre', 'code', 'textarea', 'input', 'select', 'option',
             'noscript', 'canvas', 'video', 'audio', 'iframe'].includes(tag)) return true;
        if (el.closest) {
          try {
            if (el.closest('pre, code, textarea, input, select, option, [contenteditable="true"], ' +
                '[data-no-translate], [translate="no"], .hljs, [data-syntax], ' +
                '.xterm, [data-dsh-pet-overlay], [aria-hidden="true"], .dssm-source-chevron, .lucide, svg')) return true;
          } catch (e) {}
        }
        return false;
      }

      function isElementExcludedFromAttrs(el) {
        if (!el || !el.tagName) return true;
        const tag = el.tagName.toLowerCase();
        if (['script', 'style', 'noscript'].includes(tag)) return true;
        if (el.closest) {
          try {
            if (el.closest('[data-no-translate], [translate="no"], .hljs, [data-syntax], .xterm')) return true;
          } catch (e) {}
        }
        return false;
      }

      function chunkLong(text) {
        if (!text || text.length <= CHUNK_AT) return [text];
        let parts = null;
        try {
          parts = text.match(/[^。？！.!?\n]+[。？！.!?\n]*/g);
        } catch (e) { parts = null; }
        if (!parts || parts.length < 2) {
          const out = [];
          for (let i = 0; i < text.length; i += CHUNK_AT) out.push(text.slice(i, i + CHUNK_AT));
          return out.slice(0, CHUNK_MAX);
        }
        const out = [];
        let cur = '';
        for (const p of parts) {
          if ((cur + p).length <= CHUNK_AT + 200) {
            cur += p;
          } else {
            if (cur.trim()) out.push(cur);
            cur = p;
            if (out.length >= CHUNK_MAX - 1) break;
          }
        }
        if (cur.trim()) out.push(cur);
        return out.slice(0, CHUNK_MAX);
      }

      // ---------------------------------------------------------- multi-endpoint network ---
      function fetchWithTimeout(url, ms) {
        const ctrl = typeof AbortController !== 'undefined' ? new AbortController() : null;
        let timer = null;
        if (ctrl) {
          try { timer = setTimeout(() => { try { ctrl.abort(); } catch (e) {} }, ms); } catch (e) {}
        }
        const p = (typeof fetch !== 'undefined')
          ? fetch(url, ctrl ? { signal: ctrl.signal } : undefined)
          : Promise.reject(new Error('fetch unavailable'));
        const done = () => { if (timer) { try { clearTimeout(timer); } catch (e) {} } };
        return p.then((r) => { done(); return r; }, (e) => { done(); throw e; });
      }

      // Multi-provider translation function that avoids 429 rate limit blocks
      async function fetchChunk(text, lang) {
        if (!text || isBadTranslation(text)) return '';

        const providers = [
          {
            url: `https://translate.googleapis.com/translate_a/single?client=dict-chrome-ex&sl=auto&tl=${encodeURIComponent(lang)}&dt=t&q=${encodeURIComponent(text)}`,
            parse: (d) => {
              if (Array.isArray(d) && Array.isArray(d[0])) {
                return d[0].map((p) => (Array.isArray(p) ? p[0] : (typeof p === 'string' ? p : ''))).join('').trim();
              }
              return '';
            }
          },
          {
            url: `https://clients5.google.com/translate_a/t?client=dict-chrome-ex&sl=auto&tl=${encodeURIComponent(lang)}&q=${encodeURIComponent(text)}`,
            parse: (d) => {
              if (!Array.isArray(d)) return '';
              if (typeof d[0] === 'string') return d[0].trim();
              if (Array.isArray(d[0])) {
                return d.map((item) => (Array.isArray(item) ? item[0] : (typeof item === 'string' ? item : ''))).join(' ').trim();
              }
              return '';
            }
          },
          {
            url: `https://translate.googleapis.com/translate_a/single?client=at&sl=auto&tl=${encodeURIComponent(lang)}&dt=t&q=${encodeURIComponent(text)}`,
            parse: (d) => {
              if (Array.isArray(d) && Array.isArray(d[0])) {
                return d[0].map((p) => (Array.isArray(p) ? p[0] : (typeof p === 'string' ? p : ''))).join('').trim();
              }
              return '';
            }
          },
          {
            url: `https://translate.google.com/translate_a/single?client=at&sl=auto&tl=${encodeURIComponent(lang)}&dt=t&q=${encodeURIComponent(text)}`,
            parse: (d) => {
              if (Array.isArray(d) && Array.isArray(d[0])) {
                return d[0].map((p) => (Array.isArray(p) ? p[0] : (typeof p === 'string' ? p : ''))).join('').trim();
              }
              return '';
            }
          }
        ];

        for (const p of providers) {
          try {
            const res = await fetchWithTimeout(p.url, FETCH_TIMEOUT_MS);
            if (!res || !res.ok) continue;
            const data = await res.json();
            const t = p.parse(data);
            if (t && t !== text && !isBadTranslation(t)) return t;
          } catch (e) {}
        }
        return '';
      }

      async function translateTexts(list, lang, stats) {
        const uniq = Array.from(new Set(list)).filter((t) => t && !getCached(lang, t));
        if (uniq.length === 0) {
          if (stats) stats.hits += list.length;
          return new Map();
        }

        const plan = [];
        let chunkBudget = CHUNK_CAP;
        for (const full of uniq) {
          if (plan.length >= BATCH_SIZE) break;
          const chunks = chunkLong(full).filter((c) => c && c.trim());
          if (chunks.length === 0) continue;
          if (chunks.length > chunkBudget) break;
          chunkBudget -= chunks.length;
          plan.push({ full, chunks });
        }

        const need = [];
        for (const { chunks } of plan) {
          for (const c of chunks) {
            if (!getCached(lang, c) && need.indexOf(c) === -1) need.push(c);
          }
        }

        const fresh = new Map();
        for (let i = 0; i < need.length; i += CONCURRENCY) {
          const slice = need.slice(i, i + CONCURRENCY);
          await Promise.all(slice.map(async (c) => {
            try {
              const t = await fetchChunk(c, lang);
              if (t && t !== c) {
                setCached(lang, c, t);
                fresh.set(c, t);
                if (stats) stats.net++;
              } else if (stats) stats.fails++;
            } catch (e) {
              if (stats) stats.fails++;
            }
          }));
        }

        const out = new Map();
        for (const { full, chunks } of plan) {
          const parts = [];
          let ok = true;
          for (const c of chunks) {
            const t = getCached(lang, c);
            if (!t) { ok = false; break; }
            parts.push(t);
          }
          if (ok) {
            const joined = parts.join('');
            if (joined && joined !== full) {
              setCached(lang, full, joined);
              out.set(full, joined);
              if (stats) stats.nodes++;
            }
          }
        }
        return out;
      }

      // ---------------------------------------------------------- core engine ---
      class ScreenTranslatorCore {
        constructor() {
          this.enabled = safeGet(KEY_ENABLED) !== 'false';
          this.targetLang = safeGet(KEY_TARGET) || 'en';
          this.listeners = new Set();
          this.pending = new Map();
          this.failCount = new Map();
          this.flushScheduled = false;
          this.flushing = false;
          this.retryTimer = null;
          this.observedDocs = new WeakSet();
          this.nodeState = new WeakMap();
          this.touchedNodes = new Set();
          this.disposers = [];
          this.scanTimer = null;
          this.selfEdit = false;
          this.stats = { nodes: 0, hits: 0, net: 0, fails: 0 };
          this.notifyTimer = null;
        }

        subscribe(fn) {
          this.listeners.add(fn);
          return () => { this.listeners.delete(fn); };
        }

        snapshot() {
          return {
            enabled: this.enabled,
            targetLang: this.targetLang,
            cacheSize: cache.size,
            pending: this.pending.size,
            translated: this.stats.nodes,
            net: this.stats.net
          };
        }

        notify() {
          const snap = this.snapshot();
          this.listeners.forEach((fn) => { try { fn(snap); } catch (e) {} });
        }

        notifySoon() {
          if (this.notifyTimer) return;
          try {
            this.notifyTimer = setTimeout(() => {
              this.notifyTimer = null;
              this.notify();
            }, 350);
          } catch (e) {}
        }

        setEnabled(val) {
          this.enabled = !!val;
          safeSet(KEY_ENABLED, this.enabled ? 'true' : 'false');
          this.notify();
          if (this.enabled) this.scheduleScan(30);
        }

        setTargetLang(lang) {
          if (!lang || this.targetLang === lang) return;
          this.restoreOriginals();
          this.targetLang = lang;
          safeSet(KEY_TARGET, lang);
          this.pending.clear();
          this.failCount.clear();
          this.notify();
          if (this.enabled) this.scheduleScan(30);
        }

        clearCache() {
          cache.clear();
          safeDel(KEY_CACHE);
          safeDel(KEY_CACHE_OLD);
          safeDel('dsh_auto_translate_cache_v9');
          safeDel('dsh_auto_translate_cache_v8');
          this.healPoisonedDom();
          for (const [src, en, zh] of CORE_PAIRS) {
            cache.set(`en:::${src}`, en);
            cache.set(`zh-CN:::${src}`, zh);
          }
          this.stats = { nodes: 0, hits: 0, net: 0, fails: 0 };
          this.notify();
          if (this.enabled) this.scheduleScan(30);
        }

        translateNow() {
          if (!this.enabled || !hasDOM()) return;
          this.scanEverything();
        }

        healPoisonedDom() {
          if (!hasDOM() || !document.body) return;
          try {
            const showText = typeof NodeFilter !== 'undefined' ? NodeFilter.SHOW_TEXT : 4;
            const walker = document.createTreeWalker(document.body, showText, null);
            let node;
            while ((node = walker.nextNode())) {
              if (node.nodeValue && node.nodeValue.includes('PLEASE SELECT TWO DISTINCT LANGUAGES')) {
                const parent = node.parentElement;
                if (parent && parent.classList && parent.classList.contains('dssm-source-chevron')) {
                  node.nodeValue = '\u25B8';
                } else {
                  node.nodeValue = node.nodeValue.replace(/PLEASE SELECT TWO DISTINCT LANGUAGES\s*/g, '');
                }
              }
            }
            const attrs = ['placeholder', 'title', 'alt', 'aria-label', 'aria-placeholder'];
            const allElements = document.querySelectorAll('*');
            allElements.forEach((el) => {
              for (const a of attrs) {
                const val = el.getAttribute(a);
                if (val && val.includes('PLEASE SELECT TWO DISTINCT LANGUAGES')) {
                  const orig = el.getAttribute(`data-dsh-o-${a}`);
                  if (orig) {
                    el.setAttribute(a, orig);
                  } else {
                    el.setAttribute(a, val.replace(/PLEASE SELECT TWO DISTINCT LANGUAGES\s*/g, ''));
                  }
                  el.removeAttribute(`data-dsh-l-${a}`);
                  el.removeAttribute(`data-dsh-q-${a}`);
                }
              }
            });
          } catch (e) {}
        }

        // ---- lifecycle ----
        start() {
          if (!hasDOM()) return () => {};
          this.healPoisonedDom();
          this.attachDoc(document);
          onIdle(() => this.scheduleScan(0), 250);
          try { window[READY_FLAG] = true; } catch (e) {}

          const onNav = () => this.scheduleScan(120);
          const onMsg = (e) => {
            if (!e || !e.target || !e.target.closest) return;
            try {
              if (e.target.closest('a, button, [role="tab"], [role="button"], [data-slot]')) onNav();
            } catch (err) {}
          };
          try {
            window.addEventListener('popstate', onNav, true);
            window.addEventListener('hashchange', onNav, true);
            window.addEventListener('click', onMsg, true);
            window.addEventListener('pagehide', persistNow);
            this.disposers.push(() => {
              try {
                window.removeEventListener('popstate', onNav, true);
                window.removeEventListener('hashchange', onNav, true);
                window.removeEventListener('click', onMsg, true);
                window.removeEventListener('pagehide', persistNow);
              } catch (e) {}
            });
          } catch (e) {}

          const onExtTranslate = (e) => {
            const text = e && e.detail && e.detail.text;
            if (text) this.translateAndCopy(text);
          };
          try {
            window.addEventListener('dsh:translate', onExtTranslate);
            this.disposers.push(() => { try { window.removeEventListener('dsh:translate', onExtTranslate); } catch (e) {} });
          } catch (e) {}

          return () => this.stop();
        }

        stop() {
          try { if (typeof window !== 'undefined') window[READY_FLAG] = false; } catch (e) {}
          if (this.scanTimer) { try { clearTimeout(this.scanTimer); } catch (e) {} this.scanTimer = null; }
          if (this.retryTimer) { try { clearTimeout(this.retryTimer); } catch (e) {} this.retryTimer = null; }
          if (this.notifyTimer) { try { clearTimeout(this.notifyTimer); } catch (e) {} this.notifyTimer = null; }
          try { persistNow(); } catch (e) {}
          const ds = this.disposers.splice(0);
          ds.forEach((d) => { try { d(); } catch (e) {} });
          this.pending.clear();
          this.failCount.clear();
          this.flushing = false;
          this.flushScheduled = false;
        }

        scheduleScan(delayMs) {
          if (!this.enabled || !hasDOM()) return;
          if (this.scanTimer) { try { clearTimeout(this.scanTimer); } catch (e) {} }
          const ms = Math.max(0, delayMs == null ? 100 : delayMs);
          try {
            this.scanTimer = setTimeout(() => {
              this.scanTimer = null;
              this.scanEverything();
            }, ms);
          } catch (e) {}
        }

        scanEverything() {
          if (!this.enabled || !hasDOM() || !document.body) return;
          this.walkAndQueue(document.body, 0);
          try {
            const frames = document.querySelectorAll('iframe');
            for (const f of frames) this.scanIframe(f, 0, false);
          } catch (e) {}
          this.scheduleFlush(15);
        }

        attachDoc(doc) {
          if (!doc || !doc.body || this.observedDocs.has(doc)) return;
          this.observedDocs.add(doc);
          try {
            const Observer = (doc.defaultView && doc.defaultView.MutationObserver) ||
              (typeof MutationObserver !== 'undefined' ? MutationObserver : null);
            if (!Observer) return;
            const observer = new Observer((mutations) => {
              if (!this.enabled || this.selfEdit) return;
              let dirty = false;
              for (const mut of mutations) {
                if (mut.type !== 'childList' || !mut.addedNodes) continue;
                for (const node of mut.addedNodes) {
                  if (!node) continue;
                  if (node.nodeType === 1) {
                    if (node.tagName && node.tagName.toLowerCase() === 'iframe') {
                      this.scanIframe(node, 0, true);
                      dirty = true;
                    } else {
                      this.walkAndQueue(node, 0);
                      if (node.querySelectorAll) {
                        const iframes = node.querySelectorAll('iframe');
                        for (const f of iframes) this.scanIframe(f, 0, true);
                      }
                      dirty = true;
                    }
                  } else if (node.nodeType === 3) {
                    const t = (node.nodeValue || '').trim();
                    if (t && needsTranslation(t, this.targetLang) && !getCached(this.targetLang, t)) {
                      this.walkAndQueue(node.parentElement || doc.body, 0);
                      dirty = true;
                    }
                  }
                }
              }
              if (dirty) this.scheduleFlush(20);
            });
            observer.observe(doc.body, { childList: true, subtree: true });
            this.disposers.push(() => { try { observer.disconnect(); } catch (e) {} });
          } catch (e) {}
        }

        scanIframe(iframe, depth, fromObserver) {
          if (!iframe || depth > 2) return;
          const run = () => {
            let frameDoc = null;
            try { frameDoc = iframe.contentDocument || (iframe.contentWindow && iframe.contentWindow.document); } catch (e) {}
            if (frameDoc && frameDoc.body) {
              this.attachDoc(frameDoc);
              this.walkAndQueue(frameDoc.body, depth + 1);
              try {
                const nested = frameDoc.querySelectorAll('iframe');
                for (const f of nested) this.scanIframe(f, depth + 1, false);
              } catch (e) {}
              this.scheduleFlush(20);
            }
          };
          if (fromObserver) {
            try {
              const ready = iframe.contentDocument && iframe.contentDocument.readyState === 'complete';
              if (ready) run();
              else iframe.addEventListener('load', run, { once: true });
            } catch (e) {}
          } else {
            run();
            try {
              setTimeout(() => {
                if (this.enabled && iframe.isConnected) run();
              }, 1200);
            } catch (e) {}
          }
        }

        walkAndQueue(root, depth) {
          if (!this.enabled || !root) return false;
          const lang = this.targetLang;
          const doc = root.ownerDocument || document;
          const showEl = typeof NodeFilter !== 'undefined' ? NodeFilter.SHOW_ELEMENT : 1;
          const showText = typeof NodeFilter !== 'undefined' ? NodeFilter.SHOW_TEXT : 4;

          // Pass 1: Translate attributes (placeholder, title, alt, aria-label) & collect shadow roots
          const shadowRoots = [];
          try {
            const ew = doc.createTreeWalker(root, showEl, null);
            let seen = 0;
            let el;
            while ((el = ew.nextNode())) {
              if (seen++ > SCAN_EL_CAP) break;
              if (!isElementExcludedFromAttrs(el)) {
                this.translateAttrs(el, lang);
              }
              try {
                if (el.shadowRoot) shadowRoots.push(el.shadowRoot);
              } catch (e) {}
            }
          } catch (e) {}

          // Pass 2: Translate text nodes (including SVG <text> and <tspan>)
          let capped = false;
          try {
            const tw = doc.createTreeWalker(root, showText, null);
            let seen = 0;
            let node;
            while ((node = tw.nextNode())) {
              if (seen++ > SCAN_NODE_CAP) { capped = true; break; }
              const parent = node.parentElement;
              if (!parent || isNodeExcludedFromText(parent)) continue;
              const st = this.nodeState.get(node);
              if (st && st.lang === lang) continue;
              const raw = node.nodeValue || '';
              const text = raw.trim();
              if (!text || !needsTranslation(text, lang)) continue;
              const cached = getCached(lang, text);
              if (cached) {
                this.stats.hits++;
                this.applyTextNode(node, raw, text, cached, lang);
              } else {
                const target = node;
                const original = raw;
                this.enqueue(text, (t) => {
                  if (target.isConnected) this.applyTextNode(target, original, text, t, lang);
                });
              }
            }
          } catch (e) {}

          // Pass 3: Open Shadow DOM recursion
          if ((depth || 0) < 3) {
            for (const sr of shadowRoots.slice(0, 200)) {
              try { this.walkAndQueue(sr, (depth || 0) + 1); } catch (e) {}
            }
          }
          return capped;
        }

        translateAttrs(el, lang) {
          for (const name of ATTR_NAMES) {
            let orig = null;
            try { orig = el.getAttribute(name); } catch (e) {}
            if (!orig || !needsTranslation(orig, lang)) continue;
            let done = null;
            try { done = el.getAttribute(`data-dsh-l-${name}`); } catch (e) {}
            if (done === lang) continue;
            try {
              if (el.getAttribute(`data-dsh-q-${name}`) === orig) continue;
            } catch (e) {}

            const cached = getCached(lang, orig);
            if (cached) {
              this.stats.hits++;
              this.applyAttr(el, name, orig, cached, lang);
            } else {
              try { el.setAttribute(`data-dsh-q-${name}`, orig); } catch (e) {}
              this.enqueue(orig, (t) => {
                try { el.removeAttribute(`data-dsh-q-${name}`); } catch (e) {}
                if (el.isConnected) this.applyAttr(el, name, orig, t, lang);
              });
            }
          }
        }

        applyAttr(el, name, orig, translated, lang) {
          try {
            if (!el.isConnected) return;
            if (el.getAttribute(`data-dsh-l-${name}`) === lang) return;
            if (el.getAttribute(`data-dsh-o-${name}`) == null) {
              el.setAttribute(`data-dsh-o-${name}`, orig);
            }
            this.selfEdit = true;
            try { el.setAttribute(name, translated); } finally { this.selfEdit = false; }
            el.setAttribute(`data-dsh-l-${name}`, lang);
          } catch (e) {
            try { this.selfEdit = false; } catch (err) {}
          }
        }

        applyTextNode(node, originalRaw, trimmedText, translated, lang) {
          try {
            if (!node.isConnected || !node.nodeValue) return;
            if (isBadTranslation(translated)) return;
            const st = this.nodeState.get(node);
            if (st && st.lang === lang) return;
            if (!st) this.nodeState.set(node, { lang, orig: originalRaw });
            else { st.lang = lang; }
            this.selfEdit = true;
            try {
              if (node.nodeValue.indexOf(trimmedText) !== -1) {
                node.nodeValue = node.nodeValue.replace(trimmedText, translated);
              } else {
                node.nodeValue = translated;
              }
            } finally { this.selfEdit = false; }
            this.touchedNodes.add(node);
            if (this.touchedNodes.size > 5000) {
              const oldest = this.touchedNodes.values().next().value;
              this.touchedNodes.delete(oldest);
            }
            this.stats.nodes++;
            this.notifySoon();
          } catch (e) {
            try { this.selfEdit = false; } catch (err) {}
          }
        }

        enqueue(text, applyFn) {
          if (!this.pending.has(text)) this.pending.set(text, []);
          const arr = this.pending.get(text);
          if (arr.length < APPLIER_CAP) arr.push(applyFn);
          if (this.pending.size > QUEUE_CAP) {
            const oldest = this.pending.keys().next().value;
            this.pending.delete(oldest);
            this.failCount.delete(oldest);
          }
        }

        scheduleFlush(delayMs) {
          if (this.flushScheduled || this.flushing || this.pending.size === 0) return;
          this.flushScheduled = true;
          try {
            setTimeout(() => {
              this.flushScheduled = false;
              this.flush();
            }, delayMs == null ? 20 : delayMs);
          } catch (e) {
            this.flushScheduled = false;
          }
        }

        async flush() {
          if (this.flushing || this.pending.size === 0) return;
          this.flushing = true;
          const batch = Array.from(this.pending.keys()).slice(0, BATCH_SIZE);
          const lang = this.targetLang;
          try {
            const out = await translateTexts(batch, lang, this.stats);
            let worstFails = 0;
            for (const text of batch) {
              const t = out.get(text);
              if (t) {
                const appliers = this.pending.get(text) || [];
                this.pending.delete(text);
                this.failCount.delete(text);
                appliers.forEach((fn) => { try { fn(t); } catch (e) {} });
              } else {
                const n = (this.failCount.get(text) || 0) + 1;
                if (n >= MAX_RETRIES) {
                  this.pending.delete(text);
                  this.failCount.delete(text);
                  this.stats.fails++;
                } else {
                  this.failCount.set(text, n);
                  if (n > worstFails) worstFails = n;
                }
              }
            }
            this.notifySoon();
            if (this.pending.size > 0) {
              const wait = worstFails > 0 ? RETRY_BASE_MS * worstFails : 25;
              if (this.retryTimer) { try { clearTimeout(this.retryTimer); } catch (e) {} }
              try {
                this.retryTimer = setTimeout(() => {
                  this.retryTimer = null;
                  this.flush();
                }, wait);
              } catch (e) {}
            }
          } catch (e) {
            if (this.retryTimer) { try { clearTimeout(this.retryTimer); } catch (e2) {} }
            try {
              this.retryTimer = setTimeout(() => {
                this.retryTimer = null;
                this.flushing = false;
                this.flush();
              }, RETRY_BASE_MS);
            } catch (e2) {}
            return;
          } finally {
            this.flushing = false;
          }
          if (this.pending.size > 0 && !this.retryTimer) this.scheduleFlush(20);
        }

        restoreOriginals() {
          this.selfEdit = true;
          try {
            for (const node of this.touchedNodes) {
              try {
                const st = this.nodeState.get(node);
                if (node.isConnected && st && st.orig != null && node.nodeValue !== st.orig) {
                  node.nodeValue = st.orig;
                }
                this.nodeState.delete(node);
              } catch (e) {}
            }
            this.touchedNodes.clear();
            if (hasDOM()) {
              const els = document.querySelectorAll('[data-dsh-o-placeholder], [data-dsh-o-title], [data-dsh-o-alt], [data-dsh-o-aria-label], [data-dsh-o-aria-placeholder]');
              els.forEach((el) => {
                for (const name of ATTR_NAMES) {
                  try {
                    const orig = el.getAttribute(`data-dsh-o-${name}`);
                    if (orig != null && el.getAttribute(name) !== orig) {
                      el.setAttribute(name, orig);
                    }
                    el.removeAttribute(`data-dsh-l-${name}`);
                    el.removeAttribute(`data-dsh-q-${name}`);
                  } catch (e) {}
                }
              });
            }
          } finally {
            this.selfEdit = false;
          }
        }

        async translateAndCopy(text) {
          const lang = this.targetLang;
          const short = String(text).slice(0, MAX_TEXT_LEN);
          try {
            const out = await translateTexts([short], lang, this.stats);
            const translated = out.get(short) || getCached(lang, short) || short;
            copyText(translated);
            toast(`Translated to ${lang} — copied to clipboard`);
            this.notifySoon();
          } catch (e) {
            try { copyText(short); } catch (err) {}
          }
        }
      }

      function copyText(text) {
        try {
          if (typeof navigator !== 'undefined' && navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(text).catch(() => {});
            return;
          }
        } catch (e) {}
        try {
          const ta = document.createElement('textarea');
          ta.value = text;
          ta.style.cssText = 'position:fixed;opacity:0;pointer-events:none;';
          ta.setAttribute('data-no-translate', 'true');
          document.body.appendChild(ta);
          ta.select();
          document.execCommand('copy');
          ta.remove();
        } catch (e) {}
      }

      function toast(msg) {
        try {
          if (!hasDOM()) return;
          const el = document.createElement('div');
          el.setAttribute('data-no-translate', 'true');
          el.style.cssText = 'position:fixed;bottom:24px;left:50%;transform:translateX(-50%);' +
            'background:#1e1e24;color:#34d399;border:1px solid rgba(255,255,255,0.15);' +
            'border-radius:20px;padding:8px 16px;font-size:13px;font-weight:600;' +
            'box-shadow:0 8px 24px rgba(0,0,0,0.4);z-index:99999;pointer-events:none;';
          el.textContent = msg;
          document.body.appendChild(el);
          setTimeout(() => { try { el.remove(); } catch (e) {} }, 2500);
        } catch (e) {}
      }

      // ---------------------------------------------------------- UI components ---
      function langName(code) {
        const found = TARGET_LANGUAGES.filter((l) => l.code === code)[0];
        return found ? found.name : code;
      }

      function AutoTranslateSettingsItem() {
        const core = AutoTranslateSettingsItem.core;
        const [state, setState] = useState({
          enabled: core.enabled,
          targetLang: core.targetLang,
          cacheSize: cache.size,
          pending: 0,
          translated: 0
        });

        useEffect(() => core.subscribe((s) => setState((prev) => Object.assign({}, prev, s))), []);

        return h('div', {
          id: 'dsh-auto-translate-settings-row',
          'data-no-translate': 'true',
          style: {
            padding: '16px 0',
            borderBottom: '0.5px solid var(--dsw-alias-border-l2, rgba(255,255,255,0.08))',
            fontFamily: 'inherit'
          }
        },
          h('div', {
            style: {
              display: 'flex', alignItems: 'center', justifyContent: 'space-between',
              gap: '16px'
            }
          },
            h('div', { style: { flex: 1, minWidth: 0, paddingRight: '24px' } },
              h('div', {
                style: {
                  fontWeight: 500, fontSize: '14px', lineHeight: '22px',
                  color: 'var(--dsw-alias-label-primary, #ffffff)',
                  display: 'flex', alignItems: 'center', gap: '8px'
                }
              },
                h('span', { style: { fontSize: '15px' } }, '🌐'),
                'Screen Translator (Auto-Translate Everywhere)'
              ),
              h('div', {
                style: {
                  fontSize: '12px', color: 'var(--dsw-alias-label-secondary, #a1a1aa)',
                  marginTop: '4px', lineHeight: '1.4'
                }
              }, 'Translates on-screen UI (menus, sidebars, Settings, MCP Connectors, nested iframes, Shadow DOM panels) into your target language.')
            ),
            h('div', { style: { display: 'flex', alignItems: 'center', gap: '10px', flexShrink: 0 } },
              h('div', {
                style: {
                  position: 'relative',
                  display: 'inline-flex',
                  alignItems: 'center'
                }
              },
                h('select', {
                  value: state.targetLang,
                  'aria-label': 'Select target language',
                  onChange: (e) => core.setTargetLang(e.target.value),
                  style: {
                    background: 'var(--dsw-alias-bg-module-platform, #26262b)',
                    color: 'var(--dsw-alias-label-primary, #ffffff)',
                    border: '1px solid var(--dsw-alias-border-l1, #3f3f46)',
                    borderRadius: '18px',
                    height: '36px',
                    padding: '0 32px 0 14px',
                    fontSize: '13px',
                    fontWeight: 500,
                    cursor: 'pointer',
                    outline: 'none',
                    appearance: 'none',
                    WebkitAppearance: 'none',
                    MozAppearance: 'none',
                    minWidth: '200px'
                  }
                },
                  TARGET_LANGUAGES.map((l) => h('option', {
                    key: l.code,
                    value: l.code,
                    style: { background: '#26262b', color: '#ffffff', padding: '6px' }
                  }, l.name))
                ),
                h('span', {
                  'aria-hidden': true,
                  style: {
                    position: 'absolute',
                    right: '12px',
                    pointerEvents: 'none',
                    color: 'var(--dsw-alias-label-secondary, #a1a1aa)',
                    fontSize: '11px'
                  }
                }, '▾')
              ),
              h('button', {
                type: 'button',
                onClick: () => core.setEnabled(!state.enabled),
                style: {
                  height: '36px',
                  background: state.enabled ? '#10b981' : 'var(--dsw-alias-bg-module-platform, #26262b)',
                  color: state.enabled ? '#ffffff' : 'var(--dsw-alias-label-secondary, #9ca3af)',
                  border: state.enabled ? '1px solid #059669' : '1px solid var(--dsw-alias-border-l1, #3f3f46)',
                  borderRadius: '18px', padding: '0 16px', fontSize: '13px', fontWeight: 600,
                  cursor: 'pointer', whiteSpace: 'nowrap', transition: 'all 0.15s ease'
                }
              }, state.enabled ? '✓ Enabled' : 'Disabled')
            )
          ),
          h('div', {
            style: {
              display: 'flex', alignItems: 'center', justifyContent: 'space-between',
              marginTop: '10px', paddingTop: '8px'
            }
          },
            h('div', {
              style: { fontSize: '11px', color: '#34d399', fontWeight: 500 }
            }, state.pending > 0
              ? '⏳ ' + state.pending + ' queued · ' + state.cacheSize + ' cached · ' + state.translated + ' translated'
              : '✓ ' + state.cacheSize + ' cached phrases · 0ms instant loading'),
            h('div', { style: { display: 'flex', alignItems: 'center', gap: '8px' } },
              h('button', {
                type: 'button',
                title: 'Translate everything currently on screen right now',
                onClick: () => core.translateNow(),
                style: {
                  background: 'var(--dsw-alias-bg-module-platform, #26262b)',
                  color: 'var(--dsw-alias-label-primary, #ffffff)',
                  border: '1px solid var(--dsw-alias-border-l1, #3f3f46)',
                  borderRadius: '6px', padding: '4px 10px', fontSize: '11px', fontWeight: 600,
                  cursor: 'pointer', whiteSpace: 'nowrap'
                }
              }, state.pending > 0 ? '⏳ Translating (' + state.pending + ')' : '⚡ Translate now'),
              h('button', {
                type: 'button',
                title: 'Clear translation cache and re-scan',
                onClick: () => core.clearCache(),
                style: {
                  background: 'transparent',
                  color: 'var(--dsw-alias-label-secondary, #a1a1aa)',
                  border: '1px solid var(--dsw-alias-border-l1, #3f3f46)',
                  borderRadius: '6px', padding: '4px 8px', fontSize: '11px', cursor: 'pointer',
                  whiteSpace: 'nowrap'
                }
              }, 'Clear Cache')
            )
          )
        );
      }

      function AssistantTranslateAction(props) {
        const core = AssistantTranslateAction.core;
        const messageId = props && props.messageId;
        if (!messageId) return null;

        const onClick = async (e) => {
          if (e) { try { e.preventDefault(); e.stopPropagation(); } catch (err) {} }
          let messageText = '';
          try {
            const btn = e && e.currentTarget;
            const msgEl = btn && (btn.closest('[data-node-kind="assistant-step"]') ||
              btn.closest('.lc-chat-message') || btn.closest('[data-message-id]'));
            if (msgEl) {
              const textEl = msgEl.querySelector('.markdown-body') || msgEl.querySelector('.prose') || msgEl;
              messageText = ((textEl.innerText || textEl.textContent) || '').trim().slice(0, MAX_TEXT_LEN);
            }
          } catch (err) {}
          if (!messageText) return;
          const out = await translateTexts([messageText], core.targetLang, core.stats);
          copyText(out.get(messageText) || getCached(core.targetLang, messageText) || messageText);
          core.notifySoon();
          try {
            const btn = e.currentTarget;
            const orig = btn.textContent;
            btn.textContent = '✓ Copied!';
            setTimeout(() => { try { btn.textContent = orig; } catch (err) {} }, 1800);
          } catch (err) {}
        };

        return h('button', {
          type: 'button',
          title: 'Translate message and copy',
          'aria-label': 'Translate message',
          'data-no-translate': 'true',
          onClick,
          style: {
            display: 'inline-flex', alignItems: 'center', gap: '4px',
            background: 'transparent', border: 'none',
            color: 'var(--dsw-alias-label-secondary, #9ca3af)',
            fontSize: '12px', padding: '3px 6px', borderRadius: '4px', cursor: 'pointer'
          }
        },
          h('span', { style: { fontSize: '13px' } }, '🌐'),
          h('span', null, 'Translate')
        );
      }

      // ---------------------------------------------------------- plugin entry ---
      return {
        inject: ['slots'],
        apply(ctx) {
          const core = new ScreenTranslatorCore();
          AutoTranslateSettingsItem.core = core;
          AssistantTranslateAction.core = core;

          const disposers = [];
          const onDispose = (fn) => {
            if (typeof fn !== 'function') return;
            if (ctx && typeof ctx.effect === 'function') {
              try { ctx.effect(() => fn); return; } catch (e) {}
            }
            disposers.push(fn);
          };

          try {
            const stopCore = core.start();
            if (stopCore) onDispose(stopCore);
          } catch (e) {}

          const trySlot = (slotName, options, component) => {
            try {
              if (!ctx || !ctx.slots || typeof ctx.slots.inject !== 'function') return;
              const dispose = ctx.slots.inject(slotName, () => {
                try {
                  return ctx.slots.register(Object.assign({ name: slotName }, options), component);
                } catch (e) { return null; }
              });
              if (typeof dispose === 'function') onDispose(dispose);
            } catch (e) {}
          };

          trySlot('settings.general.item',
            { id: 'dsh-screen-translator-settings', order: 50 },
            AutoTranslateSettingsItem);
          trySlot('conversation.chat.assistant-actions',
            { id: 'dsh-screen-translator-action', order: 25 },
            AssistantTranslateAction);

          if (disposers.length > 0) {
            return () => { disposers.forEach((d) => { try { d(); } catch (e) {} }); };
          }
          return undefined;
        }
      };
    };
}

// Register for both standard package ID and local workspace link ID
if (typeof window !== 'undefined' && window && window.__ModuleLoader__) {
  const factory = createTranslatorFactory();
  try {
    window.__ModuleLoader__.load({
      id: 'dsh-screen-translator',
      factory
    });
  } catch (e) {}
  try {
    window.__ModuleLoader__.load({
      id: '@local/dsh-screen-translator',
      factory
    });
  } catch (e) {}
}