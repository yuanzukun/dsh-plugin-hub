/**
 * dsh-force-compact's own one-shot summarization, modeled on the official
 * `compaction-basic` summarizer. Builds a compaction directive as the final user
 * message after the replayed region (so the provider's KV cache is reused),
 * streams it through `ctx.llm`, and returns the condensed checkpoint.
 *
 * This is a pre-commit preview + shrink gate: the durable surface mutation is
 * delegated to the `compaction` service's `compactRegion` (read live via
 * `ctx.get('compaction')`), which is the authoritative summarizer. See
 * `engine/checkpoint.js` for the orchestration.
 *
 * @module @falling-ts/dsh-force-compact/summarizer
 */

import { guardFn } from '../core/crashnet.js'
import { sessionEventAt } from '../core/session-events.js'
import { MAX_TIMEOUT_MS, MIN_TIMEOUT_MS } from '../core/settings.js'

/** Tag opening the structured summary block inside a landed checkpoint node.
 *  (The matching close tag is the symmetric `</compacted-summary>`; it is kept
 *  as a literal where emitted rather than a second constant, since the open tag
 *  is the sole anchor referenced elsewhere — by the prior-checkpoint rule in
 *  `COMPACTION_INSTRUCTION`.) */
export const SUMMARY_OPEN_TAG = '<compacted-summary>'

/** Closing counterpart of {@link SUMMARY_OPEN_TAG}; wraps the structured
 *  summary body inside a landed checkpoint (aligned with the official
 *  `compaction-basic` `frameSummary`, which emits both tags around the body). */
export const SUMMARY_CLOSE_TAG = '</compacted-summary>'

/**
 * Hard wall-clock cap for ONE summarization stream, in milliseconds.
 *
 * Why a timeout exists at all: `llm.stream` is a composed async iterable, and
 * a silent provider (or a poisoned composition listener) can yield ZERO chunks
 * and never terminate. If summarization never resolves, the caller
 * (`runTransaction`) stays parked at its `await summarize(...)` and the
 * `compaction/start` lock it opened is never closed by a matching
 * `compaction/end` — every later compaction (idle auto-run, `/force-compact`)
 * is then rejected with "a prior compaction transaction is still open" until
 * the process restarts. Observed live 2026-08-30 on opencode-go/
 * deepseek-v4-flash: the wire-fields audit line fired, then nothing — the
 * stream simply hung. Fail-closed is cheaper than a permanently leaked lock:
 * when the cap fires, the caller closes the bracket with an `error`, arming
 * the existing failure cooldown instead of livelocking. The cap is enforced
 * with `AbortSignal.timeout` racing the collection (`Promise.race`), because
 * an abort alone cannot interrupt an iterator stuck inside its own `await`.
 *
 * This is the DEFAULT cap. The effective timeout is resolved per-call from the
 * caller's `config.summarizationTimeoutMs` (the `falling-ts-force-compact`
 * `settings.summarizationTimeoutMs` GUI knob, floored at 5000ms on read);
 * this constant is the fallback when the callers passes no such field.
 */
export const SUMMARIZATION_TIMEOUT_MS = 90_000

/**
 * The harness LLM adapters' OWN stream-idle watchdog default
 * (`DEFAULT_STREAM_IDLE_TIMEOUT_MS`, shared by `@deepseek-ai/dsh-llm-pi-ai`
 * and the other shipping adapters). Each adapter arms a per-`next()` watchdog
 * during stream iteration; when IT expires before our wall-clock cap, the
 * failure surfaces as a provider-side `TIMEOUT` error (CRASH-HARNESS) instead
 * of our clean labeled `timeout` abort. This constant is the fallback bound
 * used by the timeout-race diagnostic when the target route's configured
 * `streamIdleTimeoutMs` cannot be read back from settings.
 */
export const ADAPTER_STREAM_IDLE_TIMEOUT_MS = 300_000

/**
 * The compaction directive, delivered as the FINAL user message after the
 * replayed conversation rather than as a distinct summarizer system prompt.
 * Keeping the conversation's own system prompt, tools, and message prefix in
 * front of it makes the auxiliary call a genuine prefix of the last routed
 * request, so the provider's KV cache is reused instead of invalidated.
 */
export const COMPACTION_INSTRUCTION = [
  '你现在担任本次 AI 编程助手会话的压缩引擎。把上面的对话浓缩成一份结构化检查点，让另一个模型能够无损失地接续这项工作。',
  '',
  '严格按下面的 Markdown 结构输出：保留每一节及其顺序。用简短的条目，不要写成散文段落。空的节写「（无）」，任何一节都不得省略。',
  '',
  '## 原始请求与意图',
  '- [用户最初的目标及其演变；措辞本身重要时逐字引用]',
  '',
  '## 关键技术概念',
  '- [涉及的各项技术、框架、模式与约定]',
  '',
  '## 文件与代码',
  '- [精确路径：为什么重要、关键改动或片段]',
  '',
  '## 错误与修复',
  '- [错误：如何解决的，以及相关的用户反馈]',
  '',
  '## 待办事项',
  '- [用户明确要求但尚未完成的工作]',
  '',
  '## 当前工作',
  '- [本次检查点时刻正在进行的精确内容]',
  '',
  '## 下一步',
  '- [紧接最近一次请求的那个下一步动作，或「（无）」]',
  '',
  '## 关键上下文',
  '- [决策及其理由、约束、用户偏好、待决问题、继续所需的数据]',
  '',
  '规则：',
  '- 正文用中文书写。文件路径、命令、错误字符串、标识符、数值、函数签名与语法片段一律保持原样、逐字保留，不翻译、不改写。',
  '- 忠实记录用户反馈与明确指令，尤其是纠正。',
  '- 不要提及本次摘要请求，也不要提到上下文被压缩过。',
  '- 只输出检查点正文：不要调用任何工具，也不要采取任何其他动作。',
  `- 如果对话中已经存在 ${SUMMARY_OPEN_TAG} 块，那是更早的检查点。不要逐字照搬：保留仍然成立的事实、丢弃已经过时的，把更新的信息并入同一结构下的一份统一摘要。`,
].join('\n')

/** Framing that makes the replacement user message established context. */
export const CHECKPOINT_PREAMBLE =
  '这是一份自动生成的检查点，用于浓缩较早的一段对话以释放上下文。把其中捕获的内容当作既定的背景，在此基础上继续，不要复述。直接从后面的消息继续任务，不要提及这份检查点。'

/**
 * Frame summarized content blocks for landing as a `user/message` — aligned with
 * the official `compaction-basic` `frameSummary` (a BLOCK-LEVEL wrap, NOT a
 * text splice): the first block carries the preamble and the OPEN
 * `<compacted-summary>` tag, the summary's own text blocks pass through VERBATIM
 * (preserving their exact content), and a trailing block carries the CLOSE tag.
 * Wrapping as discrete blocks (rather than joining into one string) keeps each
 * fragment individually addressable and matches the durable event shape exactly.
 * So a later compression recognizing the `<compacted-summary>` anchor applies the
 * instruction's "merge, don't copy forward" rule correctly.
 * @param {Array<{type:'text', text:string}>} textBlocks the condensed checkpoint blocks.
 * @returns {Array<{type:'text', text:string}>} the framed node blocks.
 */
export function frameSummary(textBlocks) {
  const blocks = Array.isArray(textBlocks) ? textBlocks.filter(b => b && b.type === 'text' && typeof b.text === 'string') : []
  return [
    { type: 'text', text: `${CHECKPOINT_PREAMBLE}\n\n${SUMMARY_OPEN_TAG}` },
    ...blocks,
    { type: 'text', text: SUMMARY_CLOSE_TAG },
  ]
}

/**
 * The replayed conversation surface the summarizer condenses. Reproducing the
 * last routed request's system prompt, tools, and leading messages verbatim
 * lets the auxiliary call reuse the provider's warm prefix cache; the trailing
 * compaction instruction is then the only novel input.
 */
/**
 * @typedef {{ system?: string, tools?: ReadonlyArray<object>, messages: Array<object> }} SummarizationInput
 *   Replayed prefix for the summarization call. `system` and `tools` come from
 *   the session's latest request header (prefix-cache alignment); `messages` is
 *   the shadowed region in surface order.
 */

/**
 * @typedef {{ provider: string, model: string }|undefined} Target
 */

/**
 * Run the cache-reusing `ctx.llm.stream()` summarization call.
 *
 * Aligned with the official `compaction-basic` summarizer (single-source-of-
 * truth pattern):
 *  1. target resolution order: **configured** (`config.summarizationProvider` /
 *     `config.summarizationModel`, optional) → **latest routed header**
 *     (`agent.session.requestHeader().config`) → **agent.options**
 *     (`provider` / `model`). The first candidate with BOTH fields wins.
 *  2. The replayed prefix (system + tools from the request header, plus the
 *     shadowed-region messages) is passed VERBATIM so the auxiliary call is a
 *     genuine prefix of the last routed request — the provider's warm KV
 *     cache is reused instead of invalidated. The compaction instruction is
 *     then the only novel input.
 *  3. `purpose: 'compaction'` tags the call for adapter-side routing policy.
 *  4. All chunk kinds are accumulated; a terminal `finish` of `error` /
 *     `aborted` / `max-tokens` throws a typed error (caller closes the
 *     transaction via `closeWithError`); image output is refused (image
 *     content can never safely become a checkpoint).
 *  5. Usage is surfaced when the provider reports it.
 *
 * @param {import('@deepseek-ai/cordis').Context} ctx
 * @param {Readonly<object>} config backend config (may carry `maxSummaryTokens`,
 *   `summarizationTimeoutMs`, and the optional `summarizationProvider` /
 *   `summarizationModel` override pair)
 * @param {import('@deepseek-ai/dsh-agent').Agent} agent provides the session
 *   (routed-header lookup) and fallback target.
 * @param {SummarizationInput} input replayed prefix + region messages.
 * @param {AbortSignal} [signal]
 * @param {{ reasoningEffort?: 'off' | 'low' | 'high' | 'max', maxTokens?: number }} [extra]
 *   optional generation overrides: `reasoningEffort` maps to the LLM
 *   adapter's thinking toggle; `maxTokens` OVERRIDES the `config.maxSummaryTokens`
 *   base value when present (callers route through the `settings.maxSummaryTokens`
 *   runtime knob without changing the static default).
 * @returns {Promise<object>} NEVER rejects. A discriminated result object the
 *   caller branches on by `status`:
 *   • `{ status: 'ok', summary, provider, model, maxTokens?, usage? }` —
 *     `summary` is the condensed text-only checkpoint blocks.
 *   • `{ status: 'no-target' }` / `{ status: 'no-llm' }` — the call was never
 *     made; caller silently skips (nothing to cool down).
 *   • `{ status: '<failure>', reason: string }` — the call was made but no
 *     usable summary resulted. Failure labels: `not-iterable`, `no-finish`,
 *     `provider-error`, `image-offload-required` (the route refused the replayed
 *     images, upstream 0.1.6-alpha.1 `IMAGE_OFFLOAD_REQUIRED`), `aborted`,
 *     `truncated-empty`, `image-content`,
 *     `empty-text`, `timeout` (hard wall-clock cap hit: stream aborted,
 *     presumed hung). Caller arms the per-session cooldown and closes the
 *     transaction with `error`.
 *   No throw path exists: a malformed chunk/finish/object degrades to a
 *   labeled failure, so a bad provider response can never surface a TypeError
 *   nor trap the idle path in an uncaught-exception retry loop.
 */
/**
 * Reasoning efforts in ascending cost order. `disableThinking` asks for the
 * cheapest one (`off`); a route that cannot express it degrades to the cheapest
 * level it does declare.
 */
const EFFORT_LADDER = Object.freeze(['off', 'minimal', 'low', 'medium', 'high', 'xhigh', 'max'])

/**
 * Extra `maxTokens` granted to a summary that has to THINK. A thinking trace is
 * billed against the same cap as the summary text, so a thinking route needs
 * headroom on top of `maxSummaryTokens` (documented as the cap on the summary
 * text itself). Sized for a multi-thousand-token trace over a compacted region.
 */
const REASONING_ALLOWANCE_TOKENS = 4096

/**
 * Recognize the LLM service's "this route has no such effort" rejection. It
 * throws `LlmError` with code `UNSUPPORTED_REASONING_EFFORT` before any provider
 * I/O; the message is matched as well because a wrapped or aggregated error may
 * arrive without the code.
 * @param {unknown} error - the rejection value.
 * @returns {boolean} whether the route refused the requested effort.
 */
function isUnsupportedEffort(error) {
  if (error === null || typeof error !== 'object') return false
  if (readProp(error, 'code') === 'UNSUPPORTED_REASONING_EFFORT') return true
  const message = readProp(error, 'message')
  return typeof message === 'string' && message.includes('does not support reasoning effort')
}

/** Routes already told about an effort they cannot honor (one warning per route+effort). */
const effortDowngradeWarned = new Set()

/**
 * Report a route's inability to honor the requested effort exactly once.
 * @param {object} ctx - plugin context (logger only).
 * @param {{provider: string, model: string}} target - resolved summary route.
 * @param {string} requested - the effort the caller asked for.
 * @param {string|undefined} substitute - the accepted level, or `undefined` when
 *   the model declares no reasoning support at all.
 * @returns {void}
 */
function warnEffortDowngrade(ctx, target, requested, substitute) {
  const key = `${target.provider}/${target.model}:${requested}`
  if (effortDowngradeWarned.has(key)) return
  effortDowngradeWarned.add(key)
  try {
    ctx.logger.warn(`[force-compact] summarization route ${target.provider}/${target.model} does not support reasoning effort '${requested}' — `
      + (substitute === undefined
        ? 'the model declares no reasoning support, so the summary call omits the field (route default applies); compaction continues'
        : `using the cheapest supported level '${substitute}' instead; compaction continues`))
  } catch { /* logging must never escape the summarizer */ }
}

/**
 * Resolve the effort this route actually accepts, starting from the requested
 * level and walking {@link EFFORT_LADDER} upward. `llm.resolveCallConfig` is a
 * detached capability lookup — no provider I/O and no binding to a later
 * dispatch — so probing costs nothing next to a doomed compaction call.
 *
 * Why this exists: `disableThinking` asks for `reasoningEffort: 'off'`, but a
 * catalog model may declare no `off` level at all (a pi-ai `thinkingLevelMap`
 * entry of `null`, as `opencode-go/deepseek-v4.1-flash` does). The LLM service
 * then rejects the call up front and the WHOLE compaction transaction fails —
 * observed 2026-09-23 as 15 consecutive failures with zero checkpoints once the
 * session moved onto that route. Degrading to the cheapest accepted level keeps
 * compaction working while still minimizing thinking cost.
 * @param {object} llm - the `llm` service (`ctx.get('llm')`).
 * @param {{provider: string, model: string}} target - resolved summary route.
 * @param {string} requested - the caller's requested effort.
 * @param {object} ctx - plugin context (for the one-shot downgrade warning).
 * @returns {Promise<string|undefined>} an accepted effort, or `undefined` when
 *   the model declares no reasoning support at all (omit the field entirely).
 */
async function resolveEffectiveEffort(llm, target, requested, ctx) {
  // Older harnesses expose no capability query: keep the requested effort and
  // let the call report the failure itself.
  if (typeof llm.resolveCallConfig !== 'function') return requested
  const accepts = async (effort) => {
    try {
      await llm.resolveCallConfig({ provider: target.provider, model: target.model, reasoningEffort: effort })
      return true
    } catch (error) {
      // Any failure that is NOT the effort rejection must not be swallowed here:
      // treat it as "accepted" and let the real call surface the real error.
      return !isUnsupportedEffort(error)
    }
  }
  if (await accepts(requested)) return requested
  for (const candidate of EFFORT_LADDER) {
    if (candidate === requested) continue
    if (await accepts(candidate)) {
      warnEffortDowngrade(ctx, target, requested, candidate)
      return candidate
    }
  }
  warnEffortDowngrade(ctx, target, requested, undefined)
  return undefined
}

// Internal body of `summarize` — routed through the crash-net wrapper. The
// documented contract is "NEVER THROWS", but a genuinely novel throw shape
// (e.g. a `JSON.stringify` on a cycle, an exotic iterator) escapes into the
// crash net, leaving a durable trace and propagating the original value
// unchanged (existing callers keep their semantics).
async function __summarizeBody(ctx, config, agent, input, signal, extra) {
  // NEVER THROWS. Always resolves to a structured result the caller branches on
  // by `status`:
  //   { status: 'ok',        summary[], provider, model, maxTokens?, usage? }
  //   { status: 'no-target' }            — no resolvable provider/model (call never made)
  //   { status: 'no-llm' }               — ctx has no `llm.stream` service (call never made)
  //   { status: '<failure>', reason: string } — the call was MADE but produced no usable
  //                                              summary. Failures:
  //     'not-iterable' (returned stream not an async iterable),
  //     'no-finish' (stream consumed but delivered no terminal finish chunk),
  //     'provider-error' (terminal finish kind:'error'),
  //     'aborted' (terminal finish kind:'aborted'),
  //     'truncated-empty' (kind:'max-tokens' with no text),
  //     'image-content' (image blocks present — unsafe as a checkpoint),
  //     'empty-text' (terminated successfully but emitted no text),
  //     'timeout' (hard wall-clock cap hit; stream aborted, presumed hung).
  // The caller (builtin.js runTransaction) maps 'ok' → commit; 'no-target'/
  // 'no-llm' → silent skip (nothing to cool down); any other status → arm the
  // per-session failure cooldown + close the transaction with `error`. No throw
  // path exists, so a malformed chunk/finish/object can never propagate a
  // TypeError and the idle path can never loop on an uncaught exception.
  const target = resolveTarget(config, agent)
  if (target === undefined) return { status: 'no-target' }

  const llm = ctx.get('llm')
  if (llm === undefined || typeof llm.stream !== 'function') return { status: 'no-llm' }

  // Backwards-compatible call signature: a bare `messages` array (the old
  // 4-arg form) is treated as an input with no system/tools prefix. New
  // callers pass `{ messages, system?, tools? }`.
  const normalized = Array.isArray(input) ? { messages: input } : input
  const regionMessages = normalized.messages || []

  const request = [
    ...regionMessages,
    // No `source`: harness 0.1.7 removed the `plugin` message-source kind, and the
    // official compaction-basic summarizer likewise appends a bare
    // `{ role: 'user', content: [...] }` directive (compaction-basic/summarizer.ts).
    { role: 'user', content: [{ type: 'text', text: COMPACTION_INSTRUCTION }] },
  ]
  const options = {
    provider: target.provider,
    model: target.model,
    messages: request,
    maxTokens: config.maxSummaryTokens,
  }
  // Prefix-cache alignment: feed the conversation's own system prompt and tool
  // schemas into the auxiliary call so the provider's warm KV cache for the
  // last routed request is REUSED rather than invalidated. Absent headers
  // (system-less session or a tool-free request) omit the field entirely.
  if (normalized.system !== undefined && typeof normalized.system === 'string' && normalized.system.length > 0) {
    options.system = normalized.system
  }
  if (Array.isArray(normalized.tools) && normalized.tools.length > 0) {
    options.tools = [...normalized.tools]
  }
  // The force-compact "disable thinking" setting maps to a per-request
  // `reasoningEffort: 'off'`, which the adapter turns into
  // `thinking: { type: 'disabled' }` (provider thinking off for the call).
  // The route may not declare that level at all (see `resolveEffectiveEffort`):
  // `effectiveEffort` is what the call actually carries, and `undefined` omits
  // the field so the route default applies instead of failing the transaction.
  const requestedEffort = (extra !== undefined && typeof extra.reasoningEffort === 'string')
    ? extra.reasoningEffort
    : undefined
  const effectiveEffort = requestedEffort === undefined
    ? undefined
    : await resolveEffectiveEffort(llm, target, requestedEffort, ctx)
  if (effectiveEffort !== undefined) {
    options.reasoningEffort = effectiveEffort
  }
  // Callers may override the static `config.maxSummaryTokens` via the
  // `extra.maxTokens` knob (e.g., to honor the `settings.maxSummaryTokens`
  // runtime setting without changing the compile-time default). Only apply
  // when the caller supplied a positive numeric override — otherwise keep the
  // static `config` value.
  if (extra !== undefined && Number.isFinite(extra.maxTokens) && extra.maxTokens > 0) {
    options.maxTokens = extra.maxTokens
  }
  // THINKING HEADROOM: a route that could not express `off` (see
  // `resolveEffectiveEffort`) still reasons while summarizing, and the reasoning
  // trace is billed against the SAME `maxTokens` cap. With the shipped
  // 1024-token default the trace consumed the entire budget and the call ended
  // `truncated-empty` (max-tokens finish, zero text) — observed on
  // `opencode-go/deepseek-v4.1-flash` immediately after the effort downgrade.
  // `maxSummaryTokens` is documented as the cap on the summary TEXT, so when
  // thinking is on, add a fixed reasoning allowance on top of it instead of
  // silently shrinking the summary (or failing the transaction).
  if (effectiveEffort !== undefined && effectiveEffort !== 'off' && Number.isFinite(options.maxTokens)) {
    options.maxTokens += REASONING_ALLOWANCE_TOKENS
  }
  // HUNG-STREAM GUARD: pin the summarization stream to a hard wall-clock
  // timeout ON TOP OF the caller's signal. `AbortSignal.timeout` + `AbortSignal.any`
  // (Node >= 20.3) fire the abort on THEIR OWN schedule, so a silent provider
  // stream (zero chunks, never a terminal finish) cannot leave the caller's
  // `await summarize(...)` pending forever and leak the `compaction/start`
  // lock. The caller's own signal keeps working normally (an external abort
  // still cancels earlier); only when the TIMEOUT fires does the caller
  // receive a labeled `timeout` failure instead of an open-ended hang.
  // The cap is CONFIGURABLE via `config.summarizationTimeoutMs` (the settings
  // `summarizationTimeoutMs` GUI knob); this constant is the default. A
  // non-finite/absent field falls back to the default, and the resolved value is
  // clamped to `[MIN_TIMEOUT_MS, MAX_TIMEOUT_MS]` and truncated to an integer
  // HERE — at the single site that SCHEDULES it. `readSettings` already
  // normalizes the stored preference, but `summarize` accepts a plain `config`
  // object from any caller, and `AbortSignal.timeout` throws `ERR_OUT_OF_RANGE`
  // on a fractional delay while silently degrading a 2^31..2^32-1 delay to 1ms
  // (see `MAX_TIMEOUT_MS`): both would break every summarization.
  const configuredTimeoutMs = (config !== null && typeof config === 'object'
    && Number.isFinite(config.summarizationTimeoutMs) && config.summarizationTimeoutMs > 0)
    ? config.summarizationTimeoutMs
    : SUMMARIZATION_TIMEOUT_MS
  const timeoutMs = Math.trunc(Math.min(Math.max(configuredTimeoutMs, MIN_TIMEOUT_MS), MAX_TIMEOUT_MS))
  // TIMEOUT-RACE DIAGNOSTIC (2026-09): warn BEFORE firing the call when this
  // plugin's own wall-clock cap cannot win the race against the target
  // adapter's stream-idle watchdog. The adapters arm their OWN
  // `streamIdleTimeoutMs` watchdog (default 300000ms) during stream iteration;
  // if our `timeoutMs` is not strictly below it (defaults compare equal → warn),
  // the adapter's watchdog expires first and the failure surfaces as a
  // provider-side `TIMEOUT` error (CRASH-HARNESS) rather than our clean labeled
  // `timeout` abort. The bound is read best-effort from BOTH adapter settings
  // places (`llm-pi-ai.providers.<provider>.streamIdleTimeoutMs` and
  // `llm-deepseek.streamIdleTimeoutMs`), keeping the tightest confirmed one —
  // the tightest watchdog is the one that decides the race; when neither can be
  // confirmed, the known platform default is assumed (marked as such in the
  // line). Never throws and never escapes `summarize`.
  emitTimeoutRaceDiagnostic(ctx, target.provider, timeoutMs)
  const timeoutSignal = AbortSignal.timeout(timeoutMs)
  const mergedSignal = (signal !== undefined && signal !== null && typeof signal.aborted === 'boolean')
    ? AbortSignal.any([signal, timeoutSignal])
    : timeoutSignal
  options.signal = mergedSignal
  const session = agent.session
  if (session !== undefined && session !== null && typeof session.id === 'string') {
    options.sessionId = session.id
  }
  // This one-shot call IS the compaction: tag it with the closed-union
  // `purpose` the LLM service understands (adapters may map it to
  // purpose-specific generation policy). The agent's free-form purpose string
  // is NOT a valid `GenerateOptions.purpose` value.
  options.purpose = 'compaction'
  // LLAMA.CPP COMPATIBILITY WIRE FIELD (2026-08 addition): when the caller
  // requested "thinking off" for this compaction (extra.reasoningEffort === 'off',
  // which `engine/builtin.js` sets whenever `settings.disableThinking` is true),
  // ALSO emit the OPENAI-COMPATIBLE top-level wire field
  // `reasoning_effort: 'none'` alongside the camelCase `reasoningEffort`
  // (line 225 above). The DeepSeek adapter's wire mapping translates the
  // camelCase into `thinking: { type: 'disabled' }`, which the real DeepSeek
  // API honors but llama.cpp's OAI parsing path (tools/server/server-common.
  // cpp) ignores (top-level `thinking` is not in its schema — it is forwarded
  // opaquely into `llama_params` and silently dropped). llama.cpp DOES natively
  // parse a TOP-LEVEL `reasoning_effort: "none"` keyword into
  // `inputs.enable_thinking = false` UNCONDITIONALLY (server-common.cpp:1295-
  // 1304), independent of jinja-template capability. By emitting BOTH fields
  // on the same options object we cover both endpoints simultaneously:
  //   - Real DeepSeek endpoint: reads `reasoningEffort` → emits
  //     `thinking: { type: 'disabled' }`; ignores the unknown
  //     `reasoning_effort` top-level key (silent no-op, no 400).
  //   - llama.cpp / OpenAI-compatible endpoint: reads the top-level
  //     `reasoning_effort: "none"` → enables the native
  //     `enable_thinking = false` path; the adapter's `thinking` field
  //     (still present in the body) is tolerated-but-ignored there.
  // Because `builtin.js` gates `extra.reasoningEffort` on
  // `settings.disableThinking`, this compatibility field rides the EXACT
  // same scoping rule as the primary one — only emitted on compaction calls
  // where the user has turned thinking OFF AND the route actually accepted
  // `'off'` (a route that could not is never asked to think "none" either).
  if (effectiveEffort === 'off') {
    options.reasoning_effort = 'none'
  }
  // AUDIT LOG (2026-08 addition): the LLAMA.CPP-COMPATIBILITY stamp site. One
  // line per summarization attempt recording BOTH wire fields that leave the
  // options object and the resolved provider/model they head to — the durable
  // answer to "did this compaction's thinking-off actually land on the wire?".
  // Defensive envelope: a missing/non-function `ctx.logger.debug` degrades to
  // silence (never escapes `summarize`). NOTE (2026-08 guard fix): `ctx.logger`
  // is a CALLABLE LoggerService façade (`createCallable` — `typeof 'function'`,
  // not 'object'), so the original `typeof ctx.logger === 'object'` guard was
  // ALWAYS false and this line never fired. The guard below mirrors
  // engine/builtin.js's working `info()` envelope instead: presence check +
  // duck-typed `.debug`, wrapped in try/catch.
  {
    const _auditPrimary = options.reasoningEffort === undefined ? '(absent — machine default)' : `'${options.reasoningEffort}'`
    const _auditCompat = options.reasoning_effort === undefined ? '(absent — thinking rides machine default)' : `"${options.reasoning_effort}" (llama.cpp-native wire field)`
    const _auditWho = session !== undefined && session !== null && typeof session.id === 'string' ? session.id + ': ' : ''
    const _auditLogger = (ctx === undefined || ctx === null) ? null : ctx.logger
    try {
      if (_auditLogger !== null && _auditLogger !== undefined && typeof _auditLogger.debug === 'function') {
        _auditLogger.debug('[force-compact] ' + _auditWho + 'summarization wire-fields → ' + target.provider + '/' + target.model + ': reasoningEffort=' + _auditPrimary + ' + reasoning_effort=' + _auditCompat)
      }
    } catch {}
  }

  // Assemble ALL chunk kinds (text + reasoning + images). Reasoning deltas are
  // dropped later by `extractTextOnly`; a terminal finish decides whether the
  // call succeeded. Accumulating the full stream mirrors the official
  // `compaction-basic` `BlockAssembler` shape — the difference is that this
  // plugin does not depend on `@deepseek-ai/dsh-llm` symbols (it ships as
  // plain JS outside the DSH workspace), so the assembly logic is inlined here
  // against the documented `StreamChunk` shape.
  // Bind the stream ONCE (rather than inline in the collectChunks call) so the
  // missing-finish diagnostic below can describe the ACTUAL object we were given
  // — distinguishing "not async-iterable (swapped by a waterfall listener)" from
  // "iterated cleanly but never delivered a finish chunk".
  const stream = llm.stream(options)
  // `collectChunks` performs the up-front async-iterability assertion and, if the
  // returned value is NOT a real async iterable (a `llm/stream` waterfall
  // listener swapped it for a Promise/plain object), it RESOLVES to
  // `{ _rejected: true, _rejectReason, ... }` rather than throwing. Any other
  // shape is treated as a degenerate collection (zero chunks, no finish) below.
  // We therefore wrap in try/catch as belt-and-braces: even a stray iteration
  // error degrades to a labeled failure instead of escaping `summarize`.
  let collected
  try {
    // HUNG-STREAM RACE: an `AbortSignal.timeout` abort alone cannot interrupt a
    // stream whose async iterator is stuck INSIDE an `await` (the `for await`
    // loop only re-checks `signal.aborted` when the NEXT chunk arrives — a
    // stream parked on `await new Promise(() => {})` never notices). So race
    // the collection against the timeout signal's own settlement: whichever
    // fires first wins. When the timeout wins, the labeled `timeout` failure
    // below lets `runTransaction` close the `compaction/start` lock instead of
    // leaking it forever; the abort is ALSO fired at the transport, so a
    // fetch/undici-backed stream tears down instead of burning provider time.
    // The abandoned collection loop (if any) keeps running in the background
    // but its result is discarded — releasing the lock is the contract.
    const hangRace = new Promise((resolve) => {
      timeoutSignal.addEventListener('abort', () => resolve({ _hungByTimeout: true }), { once: true })
    })
    collected = await Promise.race([
      collectChunks(stream, mergedSignal),
      hangRace,
    ])
  } catch (err) {
    // `for await` threw mid-iteration (generator fault, network reset, a
    // poisoned composed stream, …). Record it and fall through to the shared
    // failure handling — never let it escape this function.
    collected = {
      blocks: [], text: '', hasImage: false, finish: undefined, usage: undefined,
      _chunkCount: 0, _rejected: true,
      _rejectReason: (err && err.message) ? err.message : String(err),
    }
  }
  if (collected && typeof collected === 'object' && collected._hungByTimeout === true) {
    // The hang race won: the stream never delivered a terminal fact within the
    // cap. Labeled timeout failure — the caller closes the lock with an error.
    return {
      status: 'timeout',
      reason: `summarization stream exceeded ${timeoutMs}ms without a terminal finish (race won; stream presumed hung: ${describeStream(stream)})`,
    }
  }
  if (!collected || typeof collected !== 'object') {
    collected = { blocks: [], text: '', hasImage: false, finish: undefined, usage: undefined, _chunkCount: 0, _rejected: true, _rejectReason: 'collectChunks returned a non-object' }
  }
  // HUNG-STREAM TERMINATION (checked BEFORE the `_rejected` branch): the hard
  // timeout — not the caller's own signal — aborted the stream. The provider
  // (or a composed listener) delivered no terminal chunk within the cap. Report
  // a labeled `timeout` failure so `runTransaction` closes the `compaction/start`
  // lock with an error instead of leaving it open forever. An external abort
  // (caller signal) is NOT this case and keeps its existing classification.
  if (mergedSignal.aborted && !(signal !== undefined && signal !== null && signal.aborted)) {
    return {
      status: 'timeout',
      reason: `summarization stream exceeded ${timeoutMs}ms without a terminal finish and was aborted (${describeStream(stream)})`,
    }
  }
  if (collected._rejected) {
    // The stream value was not a usable async iterable (see collectChunks).
    return { status: 'not-iterable', reason: 'llm.stream() did not return an async iterable: ' + (collected._rejectReason || describeStream(stream)) }
  }

  // ---- Defensive read of the terminal `finish` ---------------------------
  // We do NOT trust that `finish` is a well-formed object. Every property is
  // read behind an explicit validity guard; any anomaly degrades to a labeled
  // failure instead of throwing.
  const finish = collected.finish
  const finishIsObject = finish !== null && typeof finish === 'object'
  const finishKind = finishIsObject ? (typeof finish.kind === 'string' ? finish.kind : undefined) : undefined

  // No terminal finish chunk (or the chunk carried no recognizable `kind`):
  // the stream stopped without telling us it completed. Report the observed
  // facts and give up — never assume success.
  if (finish === undefined) {
    const n = (typeof collected._chunkCount === 'number') ? collected._chunkCount : '?'
    // DISAMBIGUATE the two sub-classes of a missing terminator: a stream that
    // observed a trailing `usage` chunk reached a NORMAL end (and would have
    // been synthesized into a `stop` by `collectChunks` — so landing here
    // MEANS it died mid-way before any usage), versus a silent/hung stream
    // that yielded chunks but never signalled completion at all. The two point
    // at entirely different upstream causes.
    const explicit = collected._explicitFinish
    const suffix = explicit === undefined
      ? ''
      : (explicit
        ? `; an explicit finish WAS observed earlier but a later phase lost it — investigate the composed stream chain`
        : `; no usage chunk preceded the end either — the stream simply went silent`)
    return {
      status: 'no-finish',
      reason: `stream ended without a terminal finish chunk (collected ${n} chunks; stream was ${describeStream(stream)}${suffix})`,
    }
  }
  if (!finishIsObject || finishKind === undefined) {
    // A `finish` chunk was seen but its payload was not the expected
    // `FinishReason` object (e.g. `chunk.reason` was undefined/null or a
    // primitive). Treat as an incomplete termination.
    return {
      status: 'no-finish',
      reason: `terminal finish chunk lacked a valid kind (finish rendered as ${renderFinish(finish)})`,
    }
  }

  // Official `FinishReason.kind` closed union (upstream types.ts):
  //   'stop' | 'tool-calls' | 'max-tokens' | 'aborted' | 'error'.
  if (finishKind === 'error') {
    // TEMPORARY CRASH-HARNESS PROBE: the recurring terminal failure
    // `provider failure: Cannot read properties of undefined (reading 'kind')`
    // (code UNKNOWN) tells us SOMEWHERE inside the composed stream chain a
    // harness/middleware reader dereferenced `undefined.kind`. To finally root-
    // cause it, dump EVERYTHING observable about the failure fact on the single
    // branch where such a crash lands. Self-limiting: writes at most one line
    // per errored call, logging never propagates, removable once root-caused.
    try {
      const f = readProp(finish, 'failure')
      const stackTop = (() => {
        const st = f && typeof f.stack === 'string' ? f.stack : (new Error('probe-no-stack-on-failure')).stack
        // Keep the frames INSIDE the harness/adapter (skip this probe's own
        // frames): drop lines mentioning this file, keep the rest, max 6.
        const frames = st.split('\n').filter(line => !line.includes('summarizer.js'))
        return frames.slice(0, 6).map(line => line.trim()).join(' <- ')
      })()
      const causeChain = []
      let cursor = f && f.cause
      for (let depth = 0; depth < 4 && cursor !== undefined && cursor !== null; depth++) {
        causeChain.push(typeof cursor === 'object'
          ? { ctor: (cursor.constructor && cursor.constructor.name) || '?', message: cursor.message, name: cursor.name, code: cursor.code }
          : { primitive: cursor })
        cursor = (typeof cursor === 'object') ? cursor.cause : undefined
      }
      const failJson = (() => {
        try { return JSON.stringify({ kind: finish.kind, msg: f && f.message, code: f && f.code }).slice(0, 400) } catch { return '<unserializable>' }
      })()
      console.log(`[force-compact] CRASH-HARNESS: failureFact=${JSON.stringify(f && typeof f === 'object' ? { ctor: f.constructor && f.constructor.name, protoKeys: Object.getOwnPropertyNames(Object.getPrototypeOf(f)).slice(0, 12), ownKeys: Object.keys(f).slice(0, 12) } : f, (k, v) => (k === 'stack' ? '<omitted>' : v)) } `
        + `failJson=${failJson} causeChain=${JSON.stringify(causeChain).slice(0, 600)} `
        + `stackInsideHarness=[${stackTop}] optionsShape={provider:${options.provider},model:${options.model},msgs:${options.messages.length},tools:${options.tools !== undefined ? options.tools.length : 'absent'},system:${typeof options.system},purpose:${options.purpose},effort:${options.reasoningEffort}}`)
    } catch { /* the probe itself must never mask the original outcome */ }
    const failureCode = (() => {
      const fact = readProp(finish, 'failure')
      return (fact !== null && typeof fact === 'object' && typeof fact.code === 'string') ? fact.code : undefined
    })()
    if (failureCode === 'IMAGE_OFFLOAD_REQUIRED') {
      // Upstream 0.1.6-alpha.1 replaced silent request-image offloading with a
      // REFUSAL: the adapter throws this code when the replayed span carries more
      // images than the route budget allows, and its only recovery listeners are
      // `agent/request-error` and `compaction/summary-error` — a direct
      // `ctx.llm.stream` call from this plugin passes through neither. Name the
      // cause explicitly so the operator gets an actionable line instead of a
      // generic provider error, and so the fix (a smaller span, or a durable
      // `image/offload` decision) is obvious.
      return {
        status: 'image-offload-required',
        reason: 'route image budget exceeded — the selected span carries images this route cannot send; '
          + 'compact a smaller span, or let a durable image/offload decision drop them first ('
          + (failureText(readProp(finish, 'failure')) || 'IMAGE_OFFLOAD_REQUIRED') + ')',
      }
    }
    return { status: 'provider-error', reason: 'provider failure: ' + (failureText(readProp(finish, 'failure')) || 'unknown provider error') }
  }
  if (finishKind === 'aborted') {
    return { status: 'aborted', reason: 'aborted during generation: ' + (failureText(readProp(finish, 'failure')) || '(caller abort)') }
  }
  if (finishKind === 'max-tokens') {
    // Truncation at the token cap. Empty → useless (report); non-empty → a
    // partial summary we ACCEPT, letting the downstream shrink gate arbitrate.
    if (measuredLength(safeText(collected.text)) === 0) {
      return { status: 'truncated-empty', reason: 'truncated at the token cap with no output' }
    }
    // fall through to extraction (partial accept)
  }
  // `stop` / `tool-calls` / any unrecognized kind are treated as a normal
  // termination — fall through to extracting whatever text was produced. An
  // unrecognized `kind` is NOT fatal: we still surface any text and let the
  // shrink gate decide usefulness.

  // ---- Text extraction --------------------------------------------------
  // `collected.blocks` is expected to be an array; a missing/non-array value
  // simply yields an empty extraction (handled by the empty-text branch).
  const extracted = extractTextOnly(Array.isArray(collected.blocks) ? collected.blocks : [])

  // Image output can never safely become a checkpoint user-message.
  if (collected.hasImage === true) {
    return { status: 'image-content', reason: 'output contained image content — refusing to land as a checkpoint' }
  }

  const usableText = extracted.some(b => b != null && typeof b === 'object' && typeof b.text === 'string' && b.text.trim().length > 0)
  if (!usableText) {
    return { status: 'empty-text', reason: 'produced no usable text' }
  }

  const result = {
    status: 'ok',
    summary: extracted,
    provider: target.provider,
    model: target.model,
    maxTokens: options.maxTokens,
  }
  // Surface provider-reported usage when the adapter carried it; callers can
  // record it alongside `compaction/summary` for observability.
  const usage = collected.usage
  if (usage !== undefined && usage !== null) result.usage = usage
  return result
}

/**
 * Read a single property defensively. Never throws regardless of `obj` shape.
 * Returns `undefined` for non-objects or missing/invalid values. Used wherever
 * we read into a structure we do not control (chunk payloads, finish reasons).
 * @param {*} obj
 * @param {string} key
 * @returns {*}
 */
function readProp(obj, key) {
  try {
    if (obj === null || typeof obj !== 'object') return undefined
    return obj[key]
  } catch {
    return undefined
  }
}

/** Coerce a possibly-missing text field to a safe string for measurement. */
function safeText(value) {
  return typeof value === 'string' ? value : ''
}

/** Render a possibly-malformed `finish` value for diagnostics without throwing. */
function renderFinish(finish) {
  try {
    if (finish === undefined) return 'undefined'
    if (finish === null) return 'null'
    if (typeof finish !== 'object') return typeof finish
    const k = typeof finish.kind === 'string' ? `kind='${finish.kind}'` : 'kind=<missing>'
    return `an object (${k})`
  } catch {
    return '<undescribable>'
  }
}

/**
 * Best-effort read of the stream-idle watchdog bound the target ADAPTER will
 * actually arm, used by the timeout-race diagnostic to decide whether our own
 * wall-clock cap can win the race against it. The two shipping adapters keep
 * that watchdog in DIFFERENT settings places, so both are consulted:
 *
 *   - `llm-pi-ai.providers.<provider>.streamIdleTimeoutMs` — per-ROUTE (pi-ai
 *     adapts many providers, each with its own profile), and
 *   - `llm-deepseek.streamIdleTimeoutMs` — one TOP-LEVEL field for the whole
 *     plugin (it owns a single provider family, so it has no route key).
 *
 * Exactly one of them describes the route in play, but which one is not
 * determinable from here (the route-to-adapter mapping lives in the LLM
 * service), so the TIGHTEST confirmed bound is returned: the tightest watchdog
 * is the one that decides the race. Read-only and total: any missing/weird
 * shape (settings service absent, namespace absent, route absent, field
 * absent/non-numeric) contributes nothing, and `undefined` means no bound could
 * be confirmed — the caller then substitutes the platform default.
 *
 * @param {import('@deepseek-ai/cordis').Context} ctx
 * @param {string} provider the resolved target provider (route key)
 * @returns {{ms: number, origin: string}|undefined} tightest confirmed bound, else `undefined`
 */
export function adapterIdleBound(ctx, provider) {
  try {
    const settings = ctx === undefined || ctx === null ? undefined : ctx.get('settings')
    if (settings === undefined || settings === null) return undefined
    // Harness 0.1.7 removed `settings.get(ns)`. Another plugin's namespace is now
    // reachable only through `describe()`, whose descriptors carry the resolved
    // `value`; any failure here degrades to the platform default, which the
    // caller already handles (it is a diagnostic bound, never a control input).
    const section = (ns) => {
      if (typeof settings.describe !== 'function') return undefined
      let descriptors
      try {
        descriptors = settings.describe()
      } catch {
        return undefined
      }
      if (!Array.isArray(descriptors)) return undefined
      const found = descriptors.find(entry => entry !== null && typeof entry === 'object' && entry.ns === ns)
      const value = found === undefined ? undefined : found.value
      return (value !== undefined && value !== null && typeof value === 'object') ? value : undefined
    }
    const piAi = section('llm-pi-ai')
    const route = (piAi !== undefined && piAi.providers !== undefined && piAi.providers !== null
      && typeof piAi.providers === 'object') ? piAi.providers[provider] : undefined
    const deepseek = section('llm-deepseek')
    const confirmed = [
      {
        value: (route !== undefined && route !== null && typeof route === 'object')
          ? route.streamIdleTimeoutMs
          : undefined,
        origin: `llm-pi-ai.providers.${provider}.streamIdleTimeoutMs`,
      },
      {
        value: deepseek === undefined ? undefined : deepseek.streamIdleTimeoutMs,
        origin: 'llm-deepseek.streamIdleTimeoutMs',
      },
    ].filter((candidate) => Number.isFinite(candidate.value) && candidate.value > 0)
    if (confirmed.length === 0) return undefined
    let tightest = confirmed[0]
    for (const candidate of confirmed) {
      if (candidate.value < tightest.value) tightest = candidate
    }
    return { ms: tightest.value, origin: tightest.origin }
  } catch {
    return undefined
  }
}

/**
 * Emit the timeout-race WARN (or a clean-race DEBUG note) BEFORE the
 * summarization call fires. Compares our plugin wall-clock cap (`timeoutMs`)
 * against the adapter stream-idle watchdog bound resolved by
 * `adapterIdleBound` (falling back to the platform-wide 300000ms when no bound
 * can be confirmed from settings). When `timeoutMs >= bound`, the adapter's idle
 * watchdog is guaranteed to win the race and the failure would surface as a
 * provider-side `TIMEOUT` error (CRASH-HARNESS) instead of our clean labeled
 * `timeout` abort — the WARN carries the actionable fix (raise the watchdog
 * above `timeoutMs` via `llm-pi-ai.providers.<provider>.streamIdleTimeoutMs` for
 * a pi-ai route or `llm-deepseek.streamIdleTimeoutMs` for a DeepSeek route, or
 * lower `falling-ts-force-compact.summarizationTimeoutMs`). Total: never throws,
 * never escapes `summarize`.
 *
 * @param {import('@deepseek-ai/cordis').Context} ctx
 * @param {string} provider the resolved target provider (route key)
 * @param {number} timeoutMs the effective plugin wall-clock cap for this call
 */
export function emitTimeoutRaceDiagnostic(ctx, provider, timeoutMs) {
  const logger = (ctx === undefined || ctx === null) ? null : ctx.logger
  try {
    if (logger === null || logger === undefined || typeof logger.warn !== 'function') {
      // No usable logger — the diagnostic is best-effort only.
      return
    }
    const confirmed = adapterIdleBound(ctx, provider)
    const bound = confirmed !== undefined ? confirmed.ms : ADAPTER_STREAM_IDLE_TIMEOUT_MS
    const origin = confirmed !== undefined
      ? `configured ${confirmed.origin}`
      : `adapter default streamIdleTimeoutMs (${ADAPTER_STREAM_IDLE_TIMEOUT_MS} — no bound confirmed in config)`
    const prefix = `[force-compact] summarization timeout-race: summarizationTimeoutMs=${timeoutMs}ms vs ${origin}=${bound}ms`
    if (timeoutMs >= bound) {
      logger.warn(
        `${prefix} — plugin cap NOT below the adapter idle watchdog; the adapter's ` +
        `stream idle expiry fires FIRST and a timed-out/hung provider surfaces as a ` +
        `provider 'TIMEOUT' error (CRASH-HARNESS) instead of a clean labeled 'timeout' abort. ` +
        `Fix: raise the watchdog above ${timeoutMs}ms — llm-pi-ai.providers.${provider}.streamIdleTimeoutMs ` +
        `for a pi-ai route, llm-deepseek.streamIdleTimeoutMs for a DeepSeek route — ` +
        `(or lower falling-ts-force-compact.summarizationTimeoutMs), keeping ` +
        `summarizationTimeoutMs < streamIdleTimeoutMs so THIS cap is the only one that counts.`,
      )
    } else if (logger.debug !== undefined && typeof logger.debug === 'function') {
      logger.debug(`${prefix} — clean (plugin cap fires first; the only timeout in effect for this compaction)`)
    }
  } catch {
    // Diagnostic must never disturb the summarization path.
  }
}

/**
 * Resolve the provider/model for the summarization call, in priority order
 * (mirroring the official summarizer's three-tier target resolution):
 *
 *   1. CONFIGURED target: `config.summarizationProvider` /
 *      `config.summarizationModel` — an operator-declared override (both
 *      fields must be non-empty strings to count as a target).
 *   2. Latest ROUTED HEADER: `agent.session.requestHeader().config` — the
 *      session's most recent routed request; the model the conversation is
 *      actually running on.
 *   3. AGENT OPTIONS: `agent.options.provider` / `agent.options.model` —
 *      the Agent's configured fallback.
 *
 * @param {Readonly<object>} config
 * @param {import('@deepseek-ai/dsh-agent').Agent} agent
 * @returns {Target}
 */
function resolveTarget(config, agent) {
  const cfgProvider = typeof config.summarizationProvider === 'string' ? config.summarizationProvider : ''
  const cfgModel = typeof config.summarizationModel === 'string' ? config.summarizationModel : ''
  if (cfgProvider.length > 0 && cfgModel.length > 0) {
    return { provider: cfgProvider, model: cfgModel }
  }
  const session = agent.session
  if (session !== undefined && typeof session.requestHeader === 'function') {
    try {
      const header = session.requestHeader()
      const hconfig = header && header.config
      if (hconfig !== undefined
          && typeof hconfig.provider === 'string' && hconfig.provider.length > 0
          && typeof hconfig.model === 'string' && hconfig.model.length > 0) {
        return { provider: hconfig.provider, model: hconfig.model }
      }
    } catch {
      // requestHeader is best-effort: a malformed header folds to undefined;
      // fall through to the agent-options fallback below.
    }
  }
  const opts = agent.options || {}
  if (typeof opts.provider === 'string' && opts.provider.length > 0
    && typeof opts.model === 'string' && opts.model.length > 0) {
    return { provider: opts.provider, model: opts.model }
  }
  return undefined
}

/** Public entry — wrapped by the universal crash net. */
export const summarize = guardFn('summarizer.summarize', __summarizeBody)

/**
 * Read the session's latest request header and project the prefix-cache
 * alignment fields (`system` prompt + `tools` schemas) out of it. Used by
 * callers that want to reproduce the last routed request's verbatim prefix so
 * the auxiliary summarization call hits the provider's warm KV cache.
 *
 * NEVER throws: any receiver shape (including a header whose `config` is
 * absent) degrades gracefully to `{ system: undefined, tools: undefined }`.
 *
 * @param {import('@deepseek-ai/dsh-agent').Session|undefined} session
 * @returns {{ system?: string, tools?: object[] }}
 */
export function headerPrefix(session) {
  const result = {}
  if (session === undefined || session === null) return result
  let header
  if (typeof session.requestHeader === 'function') {
    try {
      header = session.requestHeader()
    } catch {
      header = undefined
    }
  }
  if (header !== undefined && header !== null) {
    if (typeof header.system === 'string' && header.system.length > 0) result.system = header.system
    if (Array.isArray(header.tools) && header.tools.length > 0) result.tools = [...header.tools]
  }
  // Harness 0.1.5 (session format V3): the system prompt is no longer carried
  // by `EpochHeader.system` — it lives in the `system/message` event at surface
  // node 0. Derive it there when the header does not supply one, so the
  // auxiliary summarization call still reproduces the routed request's verbatim
  // system prefix (provider KV-cache alignment).
  if (result.system === undefined) {
    const derived = systemHeadText(session)
    if (derived !== undefined) result.system = derived
  }
  return result
}

/**
 * The rendered system-prompt text held by surface node 0's `system/message`
 * (harness 0.1.5 session format), or `undefined` when the surface has no
 * system head or it projects no text. Never throws.
 * @param {import('@deepseek-ai/dsh-agent').Session|undefined} session
 * @returns {string|undefined}
 */
function systemHeadText(session) {
  const surfaceNodes = (session && session.surface && Array.isArray(session.surface.nodes)) ? session.surface.nodes : []
  if (surfaceNodes.length === 0) return undefined
  const head = sessionEventAt(session, surfaceNodes[0])
  if (head === null || typeof head !== 'object' || head.type !== 'system/message') return undefined
  const data = (head.data && typeof head.data === 'object') ? head.data : {}
  const message = (data.message && typeof data.message === 'object') ? data.message : {}
  const content = Array.isArray(message.content) ? message.content : []
  let text = ''
  for (const block of content) {
    if (block && typeof block === 'object' && typeof block.text === 'string') text += block.text
  }
  return text.length > 0 ? text : undefined
}

/**
 * Collect EVERY chunk kind from the stream into a small accumulator that
 * mimics the official `BlockAssembler`: ordered content blocks, a boolean
 * `hasImage` flag, the terminal `finish` fact, and the provider-reported
 * `usage` (when the adapter carried it).
 *
 * Inline against the documented `StreamChunk` shape — this plugin ships as
 * plain JS outside the DSH workspace and must not import `@deepseek-ai/dsh-llm`
 * symbols (they are not resolvable at plugin load time).
 *
 * `finish` is stored AS-IS as the raw `FinishReason` object (`{ kind,
 * failure? }`) — the same thing the official `BlockAssembler` retains — so the
 * caller switches on `finish.kind` and reads `finish.failure` per protocol.
 *
 * @param {AsyncIterable<object>} stream
 * @param {AbortSignal} [signal]
 * @param {{recordOnEmpty?: boolean}} [opts]
 * @returns {Promise<{ blocks: Array, text: string, hasImage: boolean, finish: object|undefined, usage: object|undefined }> }
 */
async function collectChunks(stream, signal, opts) {
  // UP-FRONT ITERABILITY CHECK: `ctx.llm.stream()` is contractually an
  // `AsyncIterable<StreamChunk>` (direct `for await`, no outer await /
  // `.values()`). But `llm.stream` COMPOSES every `llm/stream` waterfall
  // listener, and a listener that `return`s a Promise or a plain (non-
  // async-iterable) object poisons the composition — turning the stream into
  // exactly the unstable "sometimes throws not-async-iterable, sometimes
  // yields nothing" we observed. Detect it HERE with a precise, actionable
  // message naming the offending constructor, instead of letting a confusing
  // `yield* (intermediate value)…` TypeError leak out later.
  const asyncIterFn = (stream && typeof stream === 'object')
    ? (stream[Symbol.asyncIterator]?.bind(stream))
    : undefined
  if (typeof asyncIterFn !== 'function') {
    // The returned value is NOT a usable async iterable (a `llm/stream`
    // waterfall listener swapped the generator for a Promise/plain object, or
    // the value was undefined/null). Rather than THROWING — which would bubble
    // an opaque `yield*`-style TypeError far up the stack — RESOLVE to a
    // marked failure result so the caller can report it as a labeled
    // `not-iterable` summarization failure and recover normally. No partial
    // result is possible (nothing could be consumed), so nothing is salvaged.
    const detail = describeStream(stream)
    return {
      blocks: [], text: '', hasImage: false, finish: undefined, usage: undefined,
      _chunkCount: 0, _rejected: true,
      _rejectReason: `did NOT return an async iterable (got ${detail}); a llm/stream waterfall listener likely replaced the generator with another object`,
    }
  }
  const blocks = []
  let text = ''
  let hasImage = false
  let finish
  let usage

  // Accumulators keyed by BLOCK INDEX, mirroring the official `BlockAssembler`:
  // a `block-start` opens a slot; `*-delta`s fill it; `block-end` closes it.
  // When no `block-start` precedes a delta (some adapters omit it), we lazily
  // open the slot on first delta using the chunk's own index. This keeps streamed
  // output and the final assembled blocks in agreement regardless of whether the
  // adapter emits explicit delimiters.
  const partials = new Map()
  const order = []

  const ensure = (index, blockType) => {
    let p = partials.get(index)
    if (!p) {
      p = { blockType, text: '', toolCallId: undefined, toolCallName: '', toolCallArgs: '' }
      partials.set(index, p)
      order.push(index)
    }
    return p
  }

  const finalizeSlot = (index) => {
    const p = partials.get(index)
    if (!p) return
    if (p.assembled) return // block-end already settled it
    if (p.blockType === 'text') {
      blocks.push({ type: 'text', text: p.text })
      text += p.text
    } else if (p.blockType === 'reasoning') {
      if (p.text !== '') blocks.push({ type: 'reasoning', text: p.text })
    } else if (p.blockType === 'tool-call') {
      blocks.push({
        type: 'tool-call',
        toolCallId: p.toolCallId,
        name: p.toolCallName,
        arguments: p.toolCallArgs,
      })
    }
    p.assembled = true
  }

  const flushOpenSlots = () => {
    // Close any slot that received content but never got a `block-end`
    // (lenient tail-handling). Only slots that actually hold data matter.
    for (const idx of order) {
      const p = partials.get(idx)
      if (p && !p.assembled && (p.text !== '' || p.toolCallArgs !== '')) finalizeSlot(idx)
    }
  }

  // TEMPORARY CHUNK-SHAPE PROBE: when a stream finishes yet produced NO text
  // blocks, record the raw shape (type + keys + first 160 chars) of the FIRST
  // few chunks. Self-limiting to ≤3 chunks so it cannot spam on a long stream.
  // Guarded: logging never propagates.
  let probeBuf = []
  const recording = Boolean(opts && opts.recordOnEmpty)
  let chunkCount = 0
  // Tracks whether a REAL terminal `finish` chunk was observed (vs. the
  // end-of-stream synthesis below). Consumed by the caller to keep its
  // diagnostics honest: "clean natural termination with no explicit finish
  // marker" vs. "explicit finish marker present" is a materially different
  // failure class for debugging.
  let sawExplicitFinish = false

  for await (const rawChunk of stream) {
    if (signal !== undefined && signal.aborted) break
    // Defensive: a malformed stream may yield null/undefined/non-object items.
    // Count them (so the "consumed N chunks" diagnostic stays accurate) but skip
    // their processing — reading `.type` on a non-object would throw.
    const chunk = (rawChunk !== null && typeof rawChunk === 'object') ? rawChunk : undefined
    chunkCount++
    if (chunk === undefined) continue
    if (recording && probeBuf.length < 3 && chunkCount <= 3) {
      // Best-effort shape capture; a non-serializable chunk must not abort the
      // collection, so stringify is guarded and falls back to a placeholder.
      let sample
      try { sample = JSON.stringify(chunk).slice(0, 160) } catch { sample = '<unserializable>' }
      probeBuf.push({ type: chunk.type, keys: Object.keys(chunk).join(','), sample })
    }
    switch (chunk.type) {
      case 'block-start':
        ensure(chunk.index, chunk.blockType)
        break
      case 'text-delta': {
        const p = ensure(chunk.index, 'text')
        if (!p.assembled) p.text += typeof chunk.text === 'string' ? chunk.text : ''
        break
      }
      case 'reasoning-delta': {
        const p = ensure(chunk.index, 'reasoning')
        if (!p.assembled) p.text += typeof chunk.text === 'string' ? chunk.text : ''
        break
      }
      case 'tool-call-delta': {
        const p = ensure(chunk.index, 'tool-call')
        if (!p.assembled) {
          if (chunk.id !== undefined) p.toolCallId = chunk.id
          if (chunk.name) p.toolCallName = chunk.name
          if (typeof chunk.argumentsDelta === 'string') p.toolCallArgs += chunk.argumentsDelta
        }
        break
      }
      case 'block-end': {
        // Authoritative settlement: the adapter hands the COMPLETE block. Take
        // it verbatim rather than trusting accumulated deltas.
        const b = chunk.block
        if (b && b.type) {
          if (b.type === 'text' && typeof b.text === 'string') text += b.text
          if (b.type === 'image' || b.mediaType !== undefined) hasImage = true
          blocks.push(b)
        }
        const p = ensure(chunk.index, b && b.type ? b.type : 'text')
        p.assembled = true
        break
      }
      case 'usage':
        // THE STREAM CHARTER IS THE SOURCE OF TRUTH FOR TERMINATION (the
        // protocol's invariant spec tests pin chunk-order violations like
        // "usage after terminal finish", implying a well-formed stream always
        // ends with a `finish` chunk). BUT `collectChunks` ALSO accepts streams
        // that terminate WITHOUT one (its `no-finish` branch), so treat the
        // END-OF-STREAM AS A TERMINAL FACT too: if the provider (typically a
        // proxy that relays the upstream's `finish_reason`/`usage` verbatim)
        // delivers a `usage` chunk and then simply CLOSES — the exact
        // observed live symptom of an all-reasoning summary arriving as
        // `reasoning-delta`s followed by `usage` and then silence — record it
        // as a NORMAL completion rather than a protocol violation. This
        // converts what used to be classified `no-finish` (→ arming the
        // failure cooldown and burning the locked bracket) into a chance for
        // the TEXT-EXTRACTION layer to salvage whatever usable output the
        // stream DID produce. A genuine hung stream (never reaching the end,
        // hence never seeing a `usage` chunk either) still surfaces as
        // `no-finish`.
        usage = chunk.usage
        break
      // `response-metadata`: OPENAI-compatible adapters emit this near the end
      // of a response to carry provider-level facts (request id, completion
      // details, …). It is neither block nor terminal information — count and
      // ignore it explicitly so the default branch never masks a future
      // chunk-kind addition that we silently drop.
      case 'response-metadata':
        break
      case 'finish':
        // The RAW `finish` chunk carries `reason` — a `FinishReason`
        // `{ kind, failure? }` — directly (NOT a nested re-wrap). Store it as-is
        // so the caller can read `finish.kind` / `finish.failure` per the
        // protocol, matching the official `BlockAssembler` (`_finish =
        // chunk.reason`). Previously this branch re-wrapped into a synthetic
        // `{kind, reason, failure}` shape, losing the discriminator and making
        // every terminal finish classify as SUCCESS → spurious "no usable text".
        finish = chunk.reason
        sawExplicitFinish = true
        break
      case 'reasoning-chunks':
        // Legacy/aggregate reasoning variant (not in the core protocol but seen
        // on some routes): fold each element into a reasoning block.
        if (Array.isArray(chunk.chunks)) {
          for (const c of chunk.chunks) {
            if (typeof c === 'string') blocks.push({ type: 'reasoning', text: c })
            else if (c && typeof c.text === 'string') blocks.push({ type: 'reasoning', text: c.text })
          }
        }
        break
      default:
        break
    }
  }
  flushOpenSlots()
  // SYNTHESIZED TERMINATION (see the `usage` case): a stream that ran to the
  // very end — evidenced by an OBSERVED trailing `usage` chunk — yet never
  // delivered an explicit `finish` chunk terminated NORMALLY (a provider or
  // relay chose to close without the marker, typically right after handing
  // over usage). Record it as a clean `stop` so the text-extraction layer
  // gets a chance to salvage real output, instead of the caller classifying
  // the run as a protocol-violating `no-finish` and arming the failure
  // cooldown on top. The explicit `note` marks the distinction for
  // diagnostics without lying about where the terminator came from. A truly
  // HUNG stream (never reaching the end, hence never observing a `usage`
  // chunk either) still falls through as a bona-fide `no-finish`.
  if (finish === undefined && usage !== undefined) {
    finish = { kind: 'stop', note: 'synthesized: stream closed after a usage chunk without an explicit finish chunk' }
  }
  // CHUNK-SHAPE PROBE emission: only when the caller asked to record AND this
  // run yielded zero text blocks — i.e. the exact failure signature ("produced
  // no usable text"). Fully self-contained and guarded: NOTHING in this block
  // may throw out of `collectChunks`, so serialization is try/catch'd and the
  // whole emission is a no-op on any anomaly.
  // NOTE: the bulk CHUNK-SHAPE emission that used to live here was REMOVED —
  // it fired on every no-text run with byte-identical payloads (the upstream
  // error is deterministic) and flooded the dev-server log. The raw chunk
  // shapes are STILL recorded into `probeBuf`; a targeted probe can be
  // re-enabled via `recordOnEmpty` should a genuinely NEW failure shape ever
  // appear. The persistent `CRASH-HARNESS` line emitted on terminal
  // `kind:'error'` finishes (in `summarize`) now carries the discriminating
  // detail instead.
  // `_chunkCount` is exposed (underscore-prefixed, internal) purely so a
  // missing-finish diagnostic can distinguish "consumed N chunks but never a
  // terminal finish" from "consumed ZERO chunks (silent/lazy/no-op stream)";
  // `_explicitFinish` additionally lets the caller tell a SYNTHESIZED
  // terminator apart from a real terminal finish chunk when rendering its
  // diagnostics.
  return { blocks, text, hasImage, finish, usage, _chunkCount: chunkCount, _explicitFinish: sawExplicitFinish }
}

/**
 * Render a terse, human-readable description of whatever object `stream` actually
 * is — used ONLY in error paths to identify who replaced the expected async
 * iterable. Never throws: any inspection failure degrades to a generic tag.
 * @param {*} stream the object passed where an `AsyncIterable` was expected.
 * @returns {string} e.g. `a Promise (constructor Promise)`, `a Generator`, `undefined`, `an array of length 3`.
 */
function describeStream(stream) {
  try {
    if (stream === undefined) return 'undefined'
    if (stream === null) return 'null'
    const ctor = (stream.constructor && stream.constructor.name) || typeof stream
    if (ctor === 'Promise') return 'a Promise (constructor Promise) — a listener likely wrapped the stream in an async fn'
    if (Array.isArray(stream)) return `an array of length ${stream.length} — a listener likely returned a pre-materialized chunk array`
    const hasAsyncIter = typeof stream[Symbol.asyncIterator] === 'function'
    const hasSyncIter = typeof stream[Symbol.iterator] === 'function'
    const keys = Object.prototype.toString.call(stream)
    return `constructor=${ctor} ${keys} asyncIterable=${hasAsyncIter} syncIterable=${hasSyncIter}`
  } catch {
    return `<undescribable object (${typeof stream})>`
  }
}

/**
 * Filter the assembled content blocks down to TEXT ONLY and refuse anything
 * that is structurally unsafe to land as a checkpoint (images). Reasoning
 * blocks are dropped intentionally: they are collapsible UI regions, never
 * durable checkpoint content.
 * @param {Array} blocks
 * @returns {Array<{type:'text', text:string}>}
 */
function extractTextOnly(blocks) {
  return (blocks || []).filter(b => b && b.type === 'text' && typeof b.text === 'string')
}

/** Coerce a provider failure fact to a short human-readable message. */
function failureText(failure) {
  if (failure === undefined || failure === null) return ''
  if (typeof failure === 'string') return failure
  return failure.message || failure.description || ''
}

/** Length of the concatenated text blocks (0 when none). */
function measuredLength(text) {
  return typeof text === 'string' ? text.length : 0
}
