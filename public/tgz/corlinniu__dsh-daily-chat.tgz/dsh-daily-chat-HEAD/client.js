/**
 * Client half of the daily-chat plugin.
 *
 * The product idea: DSH's New Session has one meaning — the full coding agent.
 * This plugin splits it into two, the way ChatGPT splits chat from work:
 *
 *   日常  a lightweight conversation agent. Its own agent preset (`daily`) is
 *         composed of a chat persona, the web tools, local file read/write
 *         (read/write/edit/glob/grep), the question tool and compaction — no
 *         shell, no plan mode, no subagents. The loop is
 *         用户消息 → 模型 → 工具调用 → 回复.
 *   工作  exactly the shipped behaviour, untouched.
 *
 * Five contributions hold that up:
 *
 * 1. Three labeled rows. The shipped New Session button is hand-written JSX
 *    inside the sidebar shell and is wrapped by no slot, so nothing can be added
 *    beside it; the sidebar's own additive seats are the only places a plugin
 *    may appear. The one that renders a full-width icon + label row is
 *    `sidebar.panellist`, so 「日常聊天」, 「开始工作」 and 「更多」 live there,
 *    ordered above 「插件」 by a negative `order` (the shell sorts by it
 *    ascending, and panels default to 0). The third of them is conditional: a
 *    panel list of three rows or fewer needs no fold, so 「更多」 is registered
 *    only while a fourth menu is there to hide. A panellist row's click is the
 *    shell's and is fixed to `selectPanel(id)`, which is why contribution 2
 *    exists.
 * 2. Three `main` panels under those ids, one per row. All are transient: a row
 *    ACTS rather than navigates, so the panel performs the action and hands the
 *    centre column straight back to the conversation. That is what makes the
 *    mode rows land in the composer, with no page in between. 「更多」 instead
 *    folds the rest of the panel list away by flipping one attribute on
 *    `<html>`: the rule that reads it hides every row whose glyph does not carry
 *    this plugin's marker, so rows other plugins add are folded too, and no
 *    foreign registration is touched.
 * 3. The daily session list in `sidebar.workspaces`. Work mode leaves that slot
 *    completely alone: our entry is registered with `priority: -1`, and for a
 *    `single` slot the LOWEST live priority renders, so ours wins while it is
 *    registered and the shipped browser returns the moment it is disposed. A
 *    row is that browser's own row minus what a daily chat cannot do: status
 *    dot, title, and the same trailing relative age (`relativeTime` plus the
 *    same thresholds), refreshed on a clock because this list can sit idle.
 * 4. A prototype patch of `uiWorkspace.startSession` — the one method every New
 *    Session entry point calls, the sidebar shell's own button included — so
 *    that button starts a daily chat instead of a work session while 日常 is
 *    the active mode.
 * 5. The elapsed line in a settled Turn's footer. DSH measures a Turn's duration
 *    already — `turn.end.time - turn.start.time`, floored at a second — but
 *    paints it only inside the Turn process header, which every shipped display
 *    mode except 「完全展开」 folds away the moment the Turn settles, so the
 *    figure is unreadable exactly when it is wanted. `conversation.chat.turnTail`
 *    is the one seat a settled Turn always paints, and the `turn` prop it hands
 *    over is the same location the header reads, so the line moves an existing
 *    number instead of measuring a second time. The seat that would hold it on
 *    the row with the usage figure and the clock is the row's own, and the only
 *    way into that row is its `extraActions`, fed by
 *    `conversation.chat.assistant-actions` — so the figure is published from the
 *    first seat and painted by the second, which is what {@link TurnDuration}
 *    and {@link TurnElapsed} are. It is not mode-gated on purpose: the question
 *    it answers does not depend on the mode.
 *
 * Daily chats are Sessions in a dedicated workspace, so "daily" is a durable
 * place rather than a UI flag: the history survives, and the lists are just the
 * sessions accounted to that workspace.
 *
 * The mode is remembered in `localStorage`, the same mechanism the shipped
 * client plugins use for their own UI preferences.
 */

window.__ModuleLoader__.load({
  id: '@local/dsh-daily-chat',
  factory(require) {
    const React = require('react');
    const h = React.createElement;
    const primitives = require('@deepseek-ai/dsh-client-ui-primitives');

    /** Locale namespace for this plugin's own copy. */
    const LOCALE_NS = 'dailyChat';
    /** The single localStorage key holding the active mode. */
    const MODE_KEY = 'dsh.daily-chat.mode';
    /** The `<html>` attribute the mode-scoped chrome rules hang off. */
    const MODE_ATTRIBUTE = 'data-dsc-mode';
    /** The agent preset a daily chat runs on. */
    const DAILY_PRESET = 'daily';
    /** The workspace directory basename that identifies the daily workspace. */
    const DAILY_DIRECTORY = 'daily-chat';
    /** The title the Host half registers the daily workspace with. */
    const DAILY_TITLE = '日常聊天';
    /** The `main` panel the 「日常聊天」 sidebar row opens. */
    const DAILY_PANEL = 'daily-chat';
    /** The `main` panel the 「开始工作」 sidebar row transiently opens. */
    const WORK_PANEL = 'daily-chat-work';
    /** The `main` panel the 「更多」 sidebar row transiently opens. */
    const MORE_PANEL = 'daily-chat-more';
    /** Where 「更多」 sits between the two mode rows (`-20`/`-10`) and 「插件」 (0). */
    const MORE_ORDER = -5;
    /**
     * How many panel rows the list may hold before 「更多」 earns a row of its
     * own. Three fit: the two mode rows plus the shipped 「插件」 — the panel
     * list a stock deployment has — and the fourth row is where a fold starts
     * paying for itself.
     */
    const PANEL_ROW_LIMIT = 3;
    /** The single localStorage key holding whether the extra panel rows show. */
    const PANELS_KEY = 'dsh.daily-chat.panels';
    /** The `<html>` attribute the folded panel-list rule hangs off. */
    const PANELS_ATTRIBUTE = 'data-dsc-panels';
    /** The glyph marker that tells this plugin's rows from every other one. */
    const ROW_MARKER = 'data-dsc-keep';
    /** The glyph marker the 「更多」 chevron turns over on. */
    const MORE_MARKER = 'data-dsc-more';
    /** The class the elapsed line and its two parts carry. */
    const TURN_CLASS = 'dsc-took';
    /** The line as the turnTail seat paints it: under the action row, on its own. */
    const TURN_FALLBACK_CLASS = 'dsc-took-fallback';
    /** The line as the action row paints it: in-row, after the usage figure. */
    const TURN_INLINE_CLASS = 'dsc-took-inline';
    /** The hidden carrier the turnTail seat publishes its numbers through. */
    const TURN_FACT_CLASS = 'dsc-took-facts';
    /** The attribute a settled Turn's container carries. */
    const TURN_ROOT_MARKER = 'data-turn-tail';
    /** Milliseconds this Turn took, on the carrier. */
    const TURN_FACT_ELAPSED = 'data-dsc-elapsed';
    /** Why this Turn ended (`aborted` / `error` / empty), on the carrier. */
    const TURN_FACT_REASON = 'data-dsc-reason';
    /** When this Turn started, epoch ms, on the carrier. */
    const TURN_FACT_START = 'data-dsc-start';
    /** When this Turn ended, epoch ms, on the carrier. */
    const TURN_FACT_END = 'data-dsc-end';
    /** The turnTail seat's contribution id — the carrier, not the painted line. */
    const TURN_CONTRIBUTION = 'daily-chat-turn-took';
    /** The action row's contribution id — the painted line. */
    const TURN_INLINE_CONTRIBUTION = 'daily-chat-turn-took-inline';
    /**
     * Where the elapsed line sits among its seat's contributions: last, so it
     * comes after another plugin's block instead of splitting the reply from it.
     * Which of the two seats it ends up painting in is not this number's doing —
     * see {@link TURN_CSS} and {@link TurnElapsed}.
     */
    const TURN_ORDER = 20;

    const zh = {
      dismiss: '知道了',
      dailyChats: '日常聊天',
      startWork: '开始工作',
      more: '更多',
      newChat: '新建日常聊天',
      lockedProject: '日常聊天固定在自己的工作区，不能切换项目。要开始工作，请点侧边栏的「开始工作」。',
      starting: '正在打开日常聊天…',
      startingWork: '正在切换到工作模式…',
      empty: '还没有日常聊天，点上面开始第一句。',
      needWorkspace: '没能准备好日常聊天目录，请在弹出的选择框里挑一个文件夹。',
      failed: '打开日常聊天失败',
      turnTook: '用时',
      turnStopped: '已中断，用时',
      turnFailed: '已出错，用时',
      timeNow: '刚刚',
      timeMinutes: '{n}分钟',
      timeHours: '{n}小时',
      timeDays: '{n}天',
      timeMonths: '{n}个月',
      timeYears: '{n}年',
      hourUnit: '小时',
      minuteUnit: '分',
      secondUnit: '秒',
    };

    const en = {
      dismiss: 'Dismiss',
      dailyChats: 'Chats',
      startWork: 'Start working',
      more: 'More',
      newChat: 'New chat',
      lockedProject: 'A chat stays in its own workspace — use “Start working” in the sidebar to open a project.',
      starting: 'Opening chat…',
      startingWork: 'Switching to work…',
      empty: 'No chats yet. Start one above.',
      needWorkspace: 'Could not prepare the chat folder — pick one in the dialog.',
      failed: 'Could not open the chat',
      turnTook: 'Took',
      turnStopped: 'Stopped after',
      turnFailed: 'Failed after',
      timeNow: 'now',
      timeMinutes: '{n}min',
      timeHours: '{n}h',
      timeDays: '{n}d',
      timeMonths: '{n}mo',
      timeYears: '{n}y',
      hourUnit: 'h ',
      minuteUnit: 'm ',
      secondUnit: 's',
    };

    const CSS = [
      // The mode rows are `sidebar.panellist` entries, which the shell renders
      // as icon + label (the shape of 「插件」). What is left here for the centre
      // column is the one-frame placeholder a transient mode panel paints.
      '.dsc-panel{display:flex;flex-direction:column;min-height:0;height:100%;padding:28px 24px 24px;overflow-y:auto}',
      '.dsc-panelInner{display:flex;flex-direction:column;gap:14px;width:100%;max-width:720px;margin:0 auto}',
      '.dsc-panelHint{font-size:13px;line-height:20px;color:var(--dsw-alias-label-secondary)}',

      // The overlay layer itself is click-through, so an occupant opts back in.
      '.dsc-toast{position:fixed;bottom:18px;left:18px;z-index:60;pointer-events:auto;display:flex;align-items:flex-start;gap:10px;max-width:360px;padding:10px 12px;font-size:12.5px;line-height:18px;color:var(--dsw-alias-label-primary);background:var(--dsw-alias-bg-overlay);border:1px solid var(--dsw-alias-border-l2);border-radius:10px;box-shadow:0 8px 24px rgba(0,0,0,.18)}',
      '.dsc-toast-text{min-width:0;word-break:break-word}',
      '.dsc-toast-close{flex:none;padding:0;font:inherit;font-size:12px;color:var(--dsw-alias-label-secondary);cursor:pointer;background:transparent;border:0}',
      '.dsc-toast-close:hover{color:var(--dsw-alias-label-primary)}',

      // The region and its section header mirror the shipped browser's own
      // geometry, declaration for declaration. `.bhn1Oq_root` insets itself by
      // `--dsh-sidebar-inline-padding`, which `regionArea` has already handed
      // back to the sidebar's own gutter; `.bhn1Oq_sectionHeader` is a 36px row
      // with `margin-bottom:4px` and `padding-left:4px`; and its label carries no
      // type of its own — it inherits the sidebar's 14px and the header's
      // tertiary ink, with `max-width:45%` so it can never crowd the controls.
      //
      // One rule in that stylesheet is NOT mirrored, because it does not land:
      // `.bhn1Oq_root:not(.bhn1Oq_rail) .bhn1Oq_sectionHeader` also declares
      // `margin-right:-4px`, yet measuring a 工作 capture puts the shipped add
      // button's right edge flush with the sidebar's content box (18.5px inside
      // the sidebar's outer edge), not 4px past it. Copying the declaration
      // instead of the measurement left 「日常聊天」's own control 4px tighter
      // than 工作's, which is exactly what this row's right margin must not be.
      // The three numbers the shipped browser publishes on its own root and the
      // list spends. Declared here for the same reason: our list has to reserve
      // exactly the same room for its scrollbar.
      '.dsc-region{--dsh-session-list-edge-inset:var(--dsh-sidebar-inline-padding,12px);--dsh-session-list-scrollbar-width:8px;--dsh-session-list-scrollbar-offset:2px;display:flex;flex-direction:column;min-height:0;height:100%;padding:0 var(--dsh-sidebar-inline-padding,12px) 0 0}',
      '.dsc-region.dsc-rail{padding-right:0}',
      // One deliberate difference from the shipped rail header: that one drops
      // its actions entirely, while this header always has the add control to
      // place. With the label hidden in the rail the single remaining child sits
      // at the start either way, so the distribution needs no rail override.
      '.dsc-head{box-sizing:border-box;display:flex;align-items:center;justify-content:space-between;gap:4px;height:36px;margin-top:2px;margin-bottom:4px;padding-left:4px;color:var(--dsw-alias-label-tertiary);border-radius:12px;flex:none;overflow:hidden}',
      '.dsc-title{white-space:nowrap;min-width:0;max-width:45%;flex:none;line-height:20px;overflow:hidden}',
      // A rail is for picking a mode, not for browsing or for starting one. The
      // shipped browser renders neither its label nor its list when collapsed;
      // 日常's one remaining control in the section would be the add button, and
      // measured against a rail capture it sat 4px left of the icon column the
      // mode rows above it share — so the header goes with the list instead of
      // leaving one misaligned glyph behind it.
      '.dsc-rail .dsc-head{display:none}',
      '.dsc-rail .dsc-listArea{display:none}',
      // The section header's add control is the shipped workspace browser's icon
      // button, declaration for declaration (`.bhn1Oq_iconButton` in
      // @deepseek-ai/dsh-client-ui-workspace): a bare 28px round button that
      // only paints on hover. 日常 replaces that browser in the sidebar, so its
      // own header has to carry the same affordance in the same clothes.
      '.dsc-new{flex:none;display:inline-flex;align-items:center;justify-content:center;width:28px;height:28px;padding:0;font:inherit;color:var(--dsw-alias-label-secondary);cursor:pointer;background:transparent;border:0;border-radius:50%;corner-shape:round}',
      '.dsc-new:hover{background:var(--dsw-alias-interactive-bg-hover)}',
      // The list sits in a wrapper that mirrors `.bhn1Oq_listArea`, and that
      // wrapper is what decides where the scrollbar ends up: it pulls back out
      // by the same inset the root added, so the list's box reaches the sidebar's
      // outer edge and the list's own 2px offset then lands the gutter 2px inside
      // it. Leave the wrapper out and the scrollbar — and every row's right edge
      // — sits a whole inset too far in; that is exactly the miss this plugin
      // made twice before a side-by-side capture settled it (工作: thumb ends 2px
      // inside the sidebar edge; 日常 had 14px).
      '.dsc-listArea{min-height:0;margin-left:-4px;margin-right:calc(-1 * var(--dsh-session-list-edge-inset));flex-direction:column;flex:1;padding-left:4px;display:flex;overflow:visible}',
      // ...and the scroll container is the list inside it, mirroring
      // `.bhn1Oq_list`: a 2px offset margin, a gutter reserved even when nothing
      // overflows (`scrollbar-gutter:stable`, so the rows never jump when the
      // list starts or stops scrolling), and a right padding of edge-inset minus
      // scrollbar minus offset — 2px — which puts the rows' right edge where
      // 工作's rows put theirs.
      '.dsc-list{display:flex;flex-direction:column;gap:1px;flex:1;min-height:0;margin-left:-4px;margin-right:var(--dsh-session-list-scrollbar-offset);padding-left:4px;padding-right:calc(var(--dsh-session-list-edge-inset) - var(--dsh-session-list-scrollbar-width) - var(--dsh-session-list-scrollbar-offset));padding-bottom:16px;scrollbar-gutter:stable;overflow-y:auto}',
      // The row keeps 工作's own session-row height. `YDXeBa_sessionRow` in the
      // workspace browser is a fixed 32px; this row is that row minus its slot
      // and its hover actions, so it spends those 32px the same way — the
      // title's 20px line box (below) plus 6px of vertical padding.
      // The row's hover paint is 工作's own: the same
      // `--dsw-alias-interactive-bg-hover` (a translucent ink, not a solid
      // layer) inside the same `--dsw-radius-md` corner. A daily row has no
      // hover actions to show, but the highlight it sits under is the one the
      // session row next to it uses.
      '.dsc-row{display:flex;align-items:center;gap:8px;width:100%;padding:6px 8px;font:inherit;text-align:left;color:var(--dsw-alias-label-primary);cursor:pointer;background:transparent;border:0;border-radius:var(--dsw-radius-md)}',
      '.dsc-row:hover{background:var(--dsw-alias-interactive-bg-hover)}',
      '.dsc-dot{flex:none;width:6px;height:6px;border-radius:50%;background:var(--dsw-alias-border-l2)}',
      '.dsc-dot-on{background:var(--dsw-alias-state-success-primary)}',
      // The title is the workspace browser's `.title`, declaration for
      // declaration (see @deepseek-ai/dsh-client-ui-workspace's
      // Rows.module.css): 14px/20px — the one type size this column draws its
      // session names in. The 13px/18px this replaces was a leftover of the
      // once-tried whole-column 13px (reverted), which left this list a size
      // smaller than the list it stands in for, in the same column.
      '.dsc-rowtitle{flex:1;min-width:0;overflow:hidden;font-size:14px;line-height:20px;text-overflow:ellipsis;white-space:nowrap}',
      // The trailing age cell is the workspace browser's `.time`, declaration
      // for declaration (see @deepseek-ai/dsh-client-ui-workspace's
      // Rows.module.css): 10px/16px in the tertiary ink, taking no width from
      // the title. One deliberate difference: the workspace row swaps this cell
      // for its hover actions, while a daily row has no actions to swap in, so
      // the age stays put in every row state.
      '.dsc-rowtime{flex:none;font-size:10px;line-height:16px;color:var(--dsw-alias-label-tertiary)}',
      // The page trigger. It is neither a row nor a control: a 1px strip at the
      // end of the painted window that only the observer looks at. It needs a
      // box — a zero-area target is not reliably reported as intersecting —
      // takes no pointer, paints nothing, and as a `<div>` stays out of the tab
      // order. Scrolling it into view is what asks for the next page.
      '.dsc-pager{flex:none;height:1px;pointer-events:none}',
      '.dsc-empty{padding:10px 8px;font-size:12.5px;line-height:18px;color:var(--dsw-alias-label-secondary)}',
    ].join('');

    /**
     * Chrome adjustments that no additive seat can express.
     *
     * The sidebar shell's own New Session button is hand-written JSX inside a
     * shipped plugin and is wrapped by no slot, so it cannot be unregistered,
     * configured away or replaced from the outside — hiding it is the only lever
     * an additive plugin has. Three facts make this selector safe rather than a
     * blind guess:
     *
     * - `newSession` is the CSS-module LOCAL name of exactly that one button in
     *   `@deepseek-ai/dsh-client-ui-sidebar`, and that package is the only place
     *   in this deployment that defines it (verified across every installed
     *   bundle);
     * - the macOS window-chrome control that does the same job lives in a
     *   different module and uses a different class, so it is NOT caught here —
     *   it stays available when the sidebar is hidden;
     * - if a future version renames the class the rule simply stops matching and
     *   the button comes back. The failure mode is "visible again", never
     *   "something else disappeared".
     *
     * (The one place this over-hides is a Windows titlebar rail, where the shell
     * hides the panel list and this button would be the remaining affordance.
     * This profile runs macOS.)
     *
     * The second rule is mode-scoped: it hangs off an attribute this plugin puts
     * on `<html>` while 日常 is the active mode, and the attribute goes away with
     * the mode, so the rule only exists for a daily chat. It hides the new-chat
     * row the conversation renders above the composer — 「项目」 and 「Agent 模式」,
     * the two choices a daily chat does not get to make, because its workspace
     * and its preset are what make it a daily chat. Typing into either is refused
     * on the service side as well (the `openWorkspace` patch below, and the
     * Host's preset lock), so this rule is what the operator sees rather than
     * the only thing standing in the way. As with the button rule, a renamed
     * class means the row simply comes back.
     *
     * The third rule drops the icon from the session header's Agent-preset chip
     * while 日常 is active, leaving its text. The chip is the shipped
     * `AgentPresetLabel` in `@deepseek-ai/dsh-client-ui-agent-preset`, and its
     * icon says "this session runs a preset"; in 日常 the answer is always the
     * same one, so the glyph is noise. It is anchored on the slot key — the same
     * `conversation.session.header.actions` this deployment registers into, and
     * the anchor DSH's own stylesheets use — rather than on the chip's hashed
     * class, and then on the chip's SHAPE: a root `<span>` carrying the preset's
     * description as its `title`, with the glyph as its own first child. The
     * other occupants of that slot (jobs, schedule, terminal, cost meter) are
     * buttons or `<div>`s, so the shape selects exactly one element.
     *
     * The last rules are the 「更多」 fold. The sidebar paints one row per
     * `sidebar.panellist` entry, and a row's only handles are its hashed classes,
     * its localized `aria-label` and `aria-current` — no entry id, so this plugin
     * cannot name the rows it does not own. It can mark its own: every glyph it
     * registers carries `data-dsc-keep`, and the fold hides every row whose
     * button holds no such marker. That keeps working when another plugin adds a
     * row later, and the whole fold is one attribute on `<html>`, so no entry has
     * to be unmounted or re-registered. The failure mode is the one above: if the
     * panel list's class or shape changes, nothing matches and every row is
     * simply visible again. `:has()` needs Chromium 105+, which every Electron
     * and browser this deployment runs on is well past.
     *
     * One more rule hides the provisional New Session row. Every New Session
     * entry — 「日常聊天」, 「开始工作」, the shell's own button — opens a Session
     * that has no content yet, and until the first prompt is accepted DSH paints
     * exactly that Session in the tree as the selected 「新会话」 placeholder: its
     * title is localized, and it carries no timestamp. That row is there from the
     * click, so a workspace browser shows a conversation the user has not had;
     * this rule is what keeps the list to conversations that exist.
     *
     * It is identified by SHAPE, not by name. `data-row-key="session:…"` is the
     * tree row's own non-hashed handle, and the timestamp cell and the row-actions
     * cell are both rendered `!row.blank && …`, so the placeholder is the only
     * Session row that carries neither. Both anchors have to be missing to match,
     * which is also what bounds the failure: renaming ONE class leaves the other
     * anchor in place, so the rule still hides the placeholder and still skips
     * every real row (a real row keeps the other cell). Only a release that
     * changes BOTH suffixes — or drops both cells — would read a real row as the
     * placeholder and hide it; the shared `!row.blank` gate is what rules that out
     * today. Nothing has to bring the row back either: `blank` clears when
     * the first prompt is ACCEPTED (a refused prompt leaves it set), and the next
     * render paints an ordinary row. The two workspace and session projections
     * above are deliberately left alone by this: DSH reuses a blank Session when
     * the same entry point is clicked again, and that reuse reads the very ids a
     * projection would have to hide.
     */
    const CHROME_CSS = [
      'button[class*="newSession"]{display:none !important}',
      `html[${MODE_ATTRIBUTE}="daily"] [class*="heroWorkspaceRow"]{display:none !important}`,
      `html[${MODE_ATTRIBUTE}="daily"] [data-slot="conversation.session.header.actions"] > span[title] > svg{display:none !important}`,
      `html[${PANELS_ATTRIBUTE}="more"] nav[class*="panelList"] button:not(:has([${ROW_MARKER}])){display:none !important}`,
      `[${MORE_MARKER}]{transition:transform .15s ease}`,
      `html:not([${PANELS_ATTRIBUTE}="more"]) [${MORE_MARKER}]{transform:rotate(180deg)}`,
      '[data-row-key^="session:"]:not(:has(> [class*="_time"])):not(:has(> [class*="_rowActions"])){display:none !important}',
    ].join('');

    /**
     * The elapsed line's own rules, shipped with the components rather than with
     * {@link CHROME_CSS} so the line carries its styling to whichever surface
     * paints it, and the same colour ramp as the shipped footer chrome around it.
     *
     * The line has two faces. The one that normally paints is {@link TurnElapsed},
     * inside the copy/branch/time row, where `order: 1` puts it after that row's
     * own usage figure and clock — the row is a flex line and the slot's anchor
     * div is `display: contents`, so this rule lands on the flex item itself. The
     * other face, {@link TurnDuration}'s, is the stand-in used when the row is not
     * there to paint into (a Turn the chat view has not finalized, a surface that
     * renders the seat without a row): it stays on its own line under the row,
     * where the negative top margin shaves the column's 16px gap down to the same
     * 4px the row's own `margin-top: 4px` sets. The first face, once painted,
     * retires the second — no surface shows both.
     */
    const TURN_CSS = [
      `.${TURN_FACT_CLASS}{display:none}`,
      `.${TURN_FALLBACK_CLASS}{order:1;display:flex;align-items:baseline;gap:6px;margin:-12px 0 0;font-size:12px;line-height:18px;color:var(--dsw-alias-label-tertiary);font-variant-numeric:tabular-nums}`,
      `.${TURN_INLINE_CLASS}{order:1;display:inline-flex;align-items:center;gap:6px;white-space:nowrap;font-size:calc(var(--dsh-content-font-size-secondary,13px) - 1px);line-height:calc(24px + var(--dsh-content-font-delta,0px));color:var(--dsw-alias-label-tertiary);font-variant-numeric:tabular-nums}`,
      `[${TURN_ROOT_MARKER}]:has(.${TURN_INLINE_CLASS}) .${TURN_FALLBACK_CLASS}{display:none}`,
      `.${TURN_CLASS}-label{color:var(--dsw-alias-label-secondary)}`,
      `.${TURN_CLASS}-value{color:var(--dsw-alias-label-tertiary)}`,
    ].join('');

    /* ── relative time ────────────────────────────────────────────────────── */

    /**
     * The workspace browser's own bucketing, when primitives ships it: below a
     * minute reads 「刚刚」, then minutes below the hour, hours below the day,
     * days below 30, months below the year, then years. Sharing the helper is
     * what makes a daily row and a 工作 row age in the same words at the same
     * thresholds instead of two similar-but-not-equal ladders.
     */
    const bucketOf = typeof primitives.relativeTime === 'function'
      ? primitives.relativeTime
      : fallbackBucket;

    /**
     * Local bucketing used only when the primitives module carries no helper.
     * Same thresholds and units as `relativeTime`, so the fallback changes
     * nothing about what a row reads — only where the number came from.
     * @param at - the row's `updatedAt`, epoch ms.
     * @param now - current epoch ms.
     * @returns the bucket unit and its magnitude.
     */
    function fallbackBucket(at, now) {
      const diff = Math.max(0, now - at);
      const minutes = Math.floor(diff / 60000);
      if (minutes < 1) return { unit: 'now', n: 0 };
      if (minutes < 60) return { unit: 'minutes', n: minutes };
      const hours = Math.floor(minutes / 60);
      if (hours < 24) return { unit: 'hours', n: hours };
      const days = Math.floor(hours / 24);
      if (days < 30) return { unit: 'days', n: days };
      const months = Math.floor(days / 30);
      if (months < 12) return { unit: 'months', n: months };
      return { unit: 'years', n: Math.floor(months / 12) };
    }

    /** The dictionary key for one bucket; the magnitude stays a number. */
    const UNIT_KEYS = {
      minutes: 'timeMinutes',
      hours: 'timeHours',
      days: 'timeDays',
      months: 'timeMonths',
      years: 'timeYears',
    };

    /**
     * Localize one row's age in the compact form the workspace rows use —
     * `5分钟` / `3小时` / `22天`, never a trailing 「前」: the cell sits beside
     * the title, not in a sentence. The magnitude goes through the dictionary
     * rather than a hand-built number + word pair, so a language pack can put
     * the number anywhere in its own template.
     * @param at - the row's `updatedAt`, epoch ms; anything non-finite paints nothing.
     * @param now - current epoch ms.
     * @param t - this plugin's bound translator.
     * @returns the trailing label, or an empty string when there is no usable time.
     */
    function timeLabel(at, now, t) {
      if (typeof at !== 'number' || !Number.isFinite(at)) return '';
      const bucket = bucketOf(at, now);
      if (bucket.unit === 'now') return t('timeNow');
      const key = UNIT_KEYS[bucket.unit];
      return key === undefined ? '' : t(key, { n: bucket.n });
    }

    /**
     * How often the rows re-read the clock. A relative label names whole
     * minutes (or hours / days), so half a minute keeps it correct to its own
     * granularity without repainting a mounted sidebar on every frame.
     */
    const RELATIVE_CLOCK_PERIOD_MS = 30000;

    /**
     * Current epoch ms, re-sampled on {@link RELATIVE_CLOCK_PERIOD_MS}.
     *
     * The workspace browser samples `Date.now()` while it renders and gets away
     * with it: that tree repaints on every session and workspace event. The
     * daily list can sit untouched for hours — a chat opened at 09:00 and never
     * touched again would keep saying `5分钟` — so it owns a clock instead. The
     * cost is one callback per period while the region is mounted, and the
     * region only exists in 日常: switching to 工作 unmounts it and the timer
     * goes with it.
     * @returns epoch milliseconds, updated once per period.
     */
    function useRelativeClock() {
      const [now, setNow] = React.useState(() => Date.now());
      React.useEffect(() => {
        const timer = setInterval(() => { setNow(Date.now()); }, RELATIVE_CLOCK_PERIOD_MS);
        return () => { clearInterval(timer); };
      }, []);
      return now;
    }

    /* ── mode store ───────────────────────────────────────────────────────── */

    /** Read the persisted mode; anything unreadable means work. */
    function readMode() {
      try {
        if (typeof localStorage === 'undefined') return 'work';
        return localStorage.getItem(MODE_KEY) === 'daily' ? 'daily' : 'work';
      } catch (reason) {
        console.warn('[daily-chat] reading the saved mode failed:', reason);
        return 'work';
      }
    }

    /**
     * Read the persisted panel-list state. Anything unreadable — and anything a
     * previous version wrote — means unfolded, which is also what an unloaded
     * plugin leaves behind: every row visible.
     */
    function readPanels() {
      try {
        if (typeof localStorage === 'undefined') return false;
        return localStorage.getItem(PANELS_KEY) === 'more';
      } catch (reason) {
        console.warn('[daily-chat] reading the saved panel list failed:', reason);
        return false;
      }
    }

    let state = { mode: readMode(), panelsFolded: readPanels(), busy: false, error: null };
    const listeners = new Set();

    /**
     * Reflect the active mode onto the document, which is what the mode-scoped
     * chrome rules key off. The CSS this plugin injects is static, so the mode
     * has to be readable from the DOM rather than from React state; anything
     * other than `daily` means the attribute is absent and every rule that
     * depends on it is inert.
     * @param mode - the mode to publish.
     */
    function syncModeAttribute(mode) {
      try {
        if (typeof document === 'undefined') return;
        if (mode === 'daily') document.documentElement.setAttribute(MODE_ATTRIBUTE, 'daily');
        else document.documentElement.removeAttribute(MODE_ATTRIBUTE);
      } catch (reason) {
        console.warn('[daily-chat] publishing the active mode to the document failed:', reason);
      }
    }

    /**
     * Reflect whether the extra panel rows are folded away. Same contract as
     * {@link syncModeAttribute}: the CSS this plugin injects is static, so the
     * state has to be readable from the DOM. Unfolded means the attribute is
     * absent, which is what the page starts as and what an unloaded plugin
     * leaves behind — every sidebar row visible.
     * @param folded - whether the rows other than this plugin's own are hidden.
     */
    function syncPanelsAttribute(folded) {
      try {
        if (typeof document === 'undefined') return;
        if (folded) document.documentElement.setAttribute(PANELS_ATTRIBUTE, 'more');
        else document.documentElement.removeAttribute(PANELS_ATTRIBUTE);
      } catch (reason) {
        console.warn('[daily-chat] publishing the panel list to the document failed:', reason);
      }
    }

    /**
     * Whether the 「更多」 row is on the panel list right now. The fold is only
     * published while it is: a persisted fold whose row never appeared (or left
     * with the last third-party plugin) would hide those rows with nothing left
     * to unfold them.
     */
    let moreRowPresent = false;

    /**
     * Publish the fold, gated on the row that undoes it. Every writer goes
     * through here — the apply effect, {@link setState} and the registration
     * controller all have to agree on that gate.
     */
    function syncFoldAttribute() {
      syncPanelsAttribute(state.panelsFolded && moreRowPresent);
    }

    /** Fold the other sidebar panel rows away, or bring them back. */
    function togglePanels() {
      setState({ panelsFolded: !state.panelsFolded });
    }

    /** Merge one state patch, persist the mode, and notify every reader. */
    function setState(patch) {
      state = Object.assign({}, state, patch);
      if (patch.mode !== undefined) {
        try {
          if (typeof localStorage !== 'undefined') localStorage.setItem(MODE_KEY, patch.mode);
        } catch (reason) {
          console.warn('[daily-chat] saving the mode failed:', reason);
        }
        syncModeAttribute(patch.mode);
      }
      if (patch.panelsFolded !== undefined) {
        try {
          if (typeof localStorage !== 'undefined') {
            localStorage.setItem(PANELS_KEY, patch.panelsFolded ? 'more' : 'all');
          }
        } catch (reason) {
          console.warn('[daily-chat] saving the panel list failed:', reason);
        }
        syncFoldAttribute();
      }
      for (const listener of [...listeners]) listener();
    }

    /** Subscribe one reader to the mode state. */
    function subscribeState(listener) {
      listeners.add(listener);
      return () => {
        listeners.delete(listener);
      };
    }

    /** Read the current state; identity-stable between mutations. */
    function readState() {
      return state;
    }

    /** The component-side reader. */
    function useChatState() {
      return React.useSyncExternalStore(subscribeState, readState, readState);
    }

    /* ── fallback snapshots ───────────────────────────────────────────────── */

    // The standard-prop hooks come from plugins this one does not own. Using a
    // stable empty snapshot instead of guessing keeps the hook order fixed and
    // degrades to an empty list rather than a crash when a source is absent.
    const EMPTY_WORKSPACES = {
      items: [], archivedSessionIds: [], state: 'idle', phase: 'pending', error: null,
    };
    const EMPTY_SESSIONS = {
      ids: [], byId: {}, phase: 'pending', subagentsByParent: {}, jobsBySession: {},
    };

    /** A short human-readable reason for a failed start. */
    function describe(reason) {
      if (reason === null || reason === undefined) return 'unknown error';
      if (typeof reason === 'string') return reason;
      if (typeof reason.message === 'string' && reason.message !== '') return reason.message;
      if (typeof reason.code === 'string') return reason.code;
      try {
        return JSON.stringify(reason);
      } catch (ignored) {
        return String(reason);
      }
    }

    /* ── artwork ──────────────────────────────────────────────────────────── */

    /**
     * The 「add」 glyph the shipped workspace browser draws in its section
     * header. Taken from the primitives module rather than hand-drawn, because
     * the point of the control is that it looks like the one 日常 replaced; a
     * deployment whose primitives predate it falls back to a bare plus.
     */
    const AddGlyph = typeof primitives.IconProjectAddOutline16 === 'function'
      ? primitives.IconProjectAddOutline16
      : null;

    /**
     * A chat bubble. The seat decides the size: the sidebar asks a
     * `sidebar.panellist` occupant for 16px wide and 18px in the rail.
     */
    function ChatGlyph(props) {
      const size = typeof props.size === 'number' ? props.size : 16;
      return h('svg', {
        viewBox: '0 0 24 24', width: size, height: size, 'aria-hidden': true,
        fill: 'none', stroke: 'currentColor', strokeWidth: 1.8,
        strokeLinecap: 'round', strokeLinejoin: 'round',
        [ROW_MARKER]: '',
      }, h('path', {
        d: 'M4.5 6.4A2.4 2.4 0 0 1 6.9 4h10.2a2.4 2.4 0 0 1 2.4 2.4v6a2.4 2.4 0 0 1-2.4 2.4h-5.2L7.6 18.6v-3.8H6.9a2.4 2.4 0 0 1-2.4-2.4z',
      }));
    }

    /** A terminal window, same seat contract as {@link ChatGlyph}. */
    function WorkGlyph(props) {
      const size = typeof props.size === 'number' ? props.size : 16;
      return h('svg', {
        viewBox: '0 0 24 24', width: size, height: size, 'aria-hidden': true,
        fill: 'none', stroke: 'currentColor', strokeWidth: 1.8,
        strokeLinecap: 'round', strokeLinejoin: 'round',
        [ROW_MARKER]: '',
      }, [
        h('rect', { key: 'frame', x: 3.4, y: 4.4, width: 17.2, height: 15.2, rx: 2.4 }),
        h('path', { key: 'caret', d: 'M7.6 10.2l2.3 2.1-2.3 2.1' }),
        h('path', { key: 'line', d: 'M12.6 14.6h4' }),
      ]);
    }

    /**
     * A chevron, for the row that folds the others away. Same seat contract as
     * {@link ChatGlyph}, plus the two markers the frame-wide rules key off: this
     * is a row the plugin owns, and this is the glyph that turns over.
     */
    function MoreGlyph(props) {
      const size = typeof props.size === 'number' ? props.size : 16;
      return h('svg', {
        viewBox: '0 0 24 24', width: size, height: size, 'aria-hidden': true,
        fill: 'none', stroke: 'currentColor', strokeWidth: 1.8,
        strokeLinecap: 'round', strokeLinejoin: 'round',
        [ROW_MARKER]: '', [MORE_MARKER]: '',
      }, h('path', { d: 'M7.6 10.2l4.4 4.2 4.4-4.2' }));
    }

    /* ── settled-turn elapsed line ────────────────────────────────────────── */

    /**
     * Render an elapsed span the way the shipped Turn process header does.
     *
     * The units and their trailing spacing are copied from DSH's own `duration.*`
     * messages rather than invented: the shipped header prints hours only past an
     * hour, minutes only past a minute, and always prints the seconds — so 90s is
     * 「1分30秒」 and 3600s is 「1小时0分0秒」. English units carry a trailing space
     * ("1h 2m 5s"); Chinese ones do not ("1小时2分5秒").
     *
     * @param ms - elapsed milliseconds; negatives clamp and fractions floor.
     * @param t - translate seat bound to {@link LOCALE_NS}.
     * @returns the figure as text, ready to concatenate onto its label.
     */
    function formatElapsed(ms, t) {
      const total = Math.max(0, Math.floor(ms / 1000));
      const hours = Math.floor(total / 3600);
      const minutes = Math.floor(total / 60) % 60;
      const seconds = total % 60;
      let text = '';
      if (hours > 0) text += String(hours) + t('hourUnit');
      if (total >= 60) text += String(minutes) + t('minuteUnit');
      return text + String(seconds) + t('secondUnit');
    }

    /**
     * Which of the three labels a Turn's elapsed line opens with.
     *
     * Aborted and failed Turns DO keep their figure here, unlike in the shipped
     * header, where the two are labelled 「已停止」/「失败」 with no number: the
     * question this line answers is how long the Turn took, and an interrupted
     * Turn took exactly as long as it took. The label says which happened so the
     * number is not read as a completed answer.
     */
    function turnLabel(reason, t) {
      if (reason === 'aborted') return t('turnStopped');
      if (reason === 'error') return t('turnFailed');
      return t('turnTook');
    }

    /** The absolute span a Turn's elapsed line summarizes, for its tooltip. */
    function turnTitle(start, end) {
      if (start === undefined || end === undefined) return undefined;
      return `${new Date(start).toLocaleString()} → ${new Date(end).toLocaleString()}`;
    }

    /** Whether two readings off the carrier are the same reading. */
    function sameTurnFacts(left, right) {
      if (left === right) return true;
      if (left === undefined || right === undefined) return false;
      return left.elapsed === right.elapsed
        && left.reason === right.reason
        && left.start === right.start
        && left.end === right.end;
    }

    /**
     * Read back the numbers {@link TurnDuration} published for the Turn this
     * action row closes.
     *
     * The action row's seat is told which *message* it belongs to, not which
     * Turn, and the chat store keeps no message-to-Turn index (the only way
     * across is a walk of every node in the session). The carrier makes the
     * crossing free instead of merely cheap: both seats are rendered by DSH into
     * the same `[data-turn-tail]` box, the carrier is already in the DOM by the
     * time this row's layout effect runs, and one `closest` plus one `querySelector`
     * is all it takes to get from the row to the numbers.
     *
     * @param element - the row's own node, or null before it exists.
     * @returns the reading, or undefined when this Turn has no carrier to read.
     */
    function readTurnFacts(element) {
      if (element === null || element === undefined) return undefined;
      const container = element.closest('[' + TURN_ROOT_MARKER + ']');
      if (container === null) return undefined;
      const carrier = container.querySelector('.' + TURN_FACT_CLASS);
      if (carrier === null) return undefined;
      const elapsed = Number(carrier.getAttribute(TURN_FACT_ELAPSED));
      if (!Number.isFinite(elapsed)) return undefined;
      const reason = carrier.getAttribute(TURN_FACT_REASON);
      const start = Number(carrier.getAttribute(TURN_FACT_START));
      const end = Number(carrier.getAttribute(TURN_FACT_END));
      return {
        elapsed: elapsed,
        reason: reason === null || reason === '' ? undefined : reason,
        start: Number.isFinite(start) ? start : undefined,
        end: Number.isFinite(end) ? end : undefined,
      };
    }

    /**
     * The elapsed figure of a settled Turn, published for whichever of the two
     * faces ends up painting it.
     *
     * DSH already measures this — `turn.end.time - turn.start.time`, floored at
     * one second — but paints it only inside the Turn process header, and every
     * shipped display mode except 「完全展开」 folds that header away the moment a
     * Turn settles. A settled Turn therefore shows no duration at all anywhere.
     * This component is the carrier half: it reads the two timestamps off the
     * `conversation.chat.turnTail` seat, states them on a hidden node, and keeps
     * a visible line of its own only as a fallback for the surfaces where
     * {@link TurnElapsed} cannot reach that node.
     *
     * Nothing is invented and nothing is faked: a Turn whose `turn/start` fell
     * outside the loaded window carries no `start`, and one that never settled
     * carries no `end` — both draw nothing rather than a zero.
     *
     * @param props.turn - the settled Turn location, straight from the seat.
     * @param props.t - translate seat bound to {@link LOCALE_NS}.
     * @returns the carrier and its fallback line, or null when there is nothing
     *   to show.
     */
    function TurnDuration(props) {
      const turn = props.turn;
      const t = props.t;
      if (turn === undefined || turn.status !== 'closed') return null;
      if (turn.start === undefined || turn.end === undefined) return null;
      const reason = turn.end.data === undefined || turn.end.data.reason === undefined
        ? undefined
        : turn.end.data.reason.kind;
      // The shipped header's floor, for the same reason: a pause that took less
      // than a second reads as 0, and 0 reads as a bug.
      const elapsed = Math.max(1000, turn.end.time - turn.start.time);
      return h(React.Fragment, null, [
        h('style', { key: 'css' }, TURN_CSS),
        h('span', {
          key: 'facts',
          className: TURN_FACT_CLASS,
          [TURN_FACT_ELAPSED]: String(elapsed),
          [TURN_FACT_REASON]: reason === undefined ? '' : reason,
          [TURN_FACT_START]: String(turn.start.time),
          [TURN_FACT_END]: String(turn.end.time),
        }),
        h('span', {
          key: 'fallback',
          className: `${TURN_CLASS} ${TURN_FALLBACK_CLASS}`,
          title: turnTitle(turn.start.time, turn.end.time),
        }, [
          h('span', { key: 'label', className: `${TURN_CLASS}-label` }, turnLabel(reason, t)),
          h('span', { key: 'value', className: `${TURN_CLASS}-value` }, formatElapsed(elapsed, t)),
        ]),
      ]);
    }

    /**
     * The same figure, painted on the action row's own line.
     *
     * This contribution lives in `conversation.chat.assistant-actions`, the seat
     * DSH hands to the row's `extraActions` — the only way into that row — and
     * `order: 1` in {@link TURN_CSS} is what moves it past the row's own usage
     * figure and clock rather than leaving it in front of the branch button.
     *
     * It paints nothing until it has read the carrier: a Turn that never settled,
     * or a row DSH rendered without its Turn's tail, has no figure to show, and a
     * row that quietly shows none is better than one that shows a guess.
     *
     * @param props - standard seat props; only `t` is needed.
     */
    function TurnElapsed(props) {
      const t = props.t;
      const holder = React.useRef(null);
      const retried = React.useRef(false);
      const [facts, setFacts] = React.useState(undefined);
      // The carrier lands in the same commit as this row, so a layout effect
      // reads it a paint early and the line never flashes in late.
      React.useLayoutEffect(() => {
        const found = readTurnFacts(holder.current);
        setFacts((previous) => (sameTurnFacts(previous, found) ? previous : found));
        // Carrier and row come from two different seats, so a surface that gains
        // one of them a commit later would strand the figure on the fallback
        // line. One deferred re-read covers that, and a read that stays empty
        // changes nothing — the fallback line is already showing.
        if (found !== undefined || retried.current) return;
        retried.current = true;
        requestAnimationFrame(() => {
          setFacts((previous) => {
            const late = readTurnFacts(holder.current);
            return sameTurnFacts(previous, late) ? previous : late;
          });
        });
      });
      if (facts === undefined) {
        // Not hidden by CSS: the class is what the fallback watches for, so an
        // empty first pass must not wear it.
        return h('span', { key: 'anchor', ref: holder, style: { display: 'none' } });
      }
      return h('span', {
        key: 'line',
        ref: holder,
        className: `${TURN_CLASS} ${TURN_INLINE_CLASS}`,
        title: turnTitle(facts.start, facts.end),
      }, [
        h('span', { key: 'label', className: `${TURN_CLASS}-label` }, turnLabel(facts.reason, t)),
        h('span', { key: 'value', className: `${TURN_CLASS}-value` }, formatElapsed(facts.elapsed, t)),
      ]);
    }

    return {
      inject: [
        'slots',
        'locale',
        'layout',
        'remote',
        'remote.agentPresets',
        'uiWorkspace',
        'workspaces',
        'sessions',
      ],

      apply(ctx) {
        ctx.effect(
          () => ctx.locale.register(LOCALE_NS, { zh, en }),
          'daily-chat: dictionaries',
        );
        const t = ctx.locale.bind(LOCALE_NS);

        // Publish the mode the page loaded with, and take the mark away when
        // this plugin unloads: the chrome rules it drives belong to the plugin,
        // so nothing of them may outlive it.
        ctx.effect(() => {
          syncModeAttribute(state.mode);
          return () => syncModeAttribute('work');
        }, 'daily-chat: mode-scoped chrome');

        // Same contract for the panel-list fold: publish what the page loaded
        // with (the 「更多」 row itself may not exist yet — that is the gate), and
        // leave every row visible when this plugin unloads.
        ctx.effect(() => {
          syncFoldAttribute();
          return () => {
            moreRowPresent = false;
            syncPanelsAttribute(false);
          };
        }, 'daily-chat: folded panel rows');

        /** The shipped `startSession`, restored on unload. */
        let originalStartSession = undefined;
        /** The model's own workspace read, before the work-mode projection. */
        let readRawWorkspaces = undefined;
        /** Re-entrancy guard: starting a chat must not re-enter through the patch. */
        let starting = false;
        /** Bumped by every mode action so a slow start cannot land after a newer one. */
        let startTicket = 0;

        /** The harness home as the Host reports it, when it does. */
        function hostHome() {
          try {
            const facts = ctx.remote.$host;
            if (facts !== undefined && typeof facts.home === 'string' && facts.home !== '') {
              return facts.home.replace(/\/+$/, '');
            }
          } catch (reason) {
            console.warn('[daily-chat] reading host facts failed:', reason);
          }
          return undefined;
        }

        /** Find the daily workspace among the registered ones. */
        function pickDailyWorkspace(items) {
          const home = hostHome();
          if (home !== undefined) {
            const expected = home + '/.dsh/' + DAILY_DIRECTORY;
            for (const item of items) {
              if (item.path === expected) return item;
            }
          }
          for (const item of items) {
            const segments = item.path.split(/[\\/]/);
            if (segments[segments.length - 1] === DAILY_DIRECTORY) return item;
          }
          return undefined;
        }

        /* ── the work-mode view ───────────────────────────────────────────────── */

        /**
         * Whether one registered workspace is 日常聊天 itself rather than a
         * project.
         *
         * Deliberately stricter than {@link pickDailyWorkspace}, which may fall
         * back to the directory basename alone: a wrong "yes" here deletes a
         * real project from the work-mode sidebar, while a wrong "no" only
         * leaves the daily row in place. The basename fallback therefore also
         * asks for the title the Host half registered the workspace with.
         * @param item - one workspace record.
         * @param expected - the path the Host half registers, when it is known.
         * @returns whether work mode should keep this row out of the sidebar.
         */
        function isDailyWorkspace(item, expected) {
          if (expected !== undefined && item.path === expected) return true;
          const segments = item.path.split(/[\\/]/);
          return segments[segments.length - 1] === DAILY_DIRECTORY && item.title === DAILY_TITLE;
        }

        /** The path the Host half registers the daily workspace under, when it is known. */
        function expectedDailyPath() {
          const home = hostHome();
          return home === undefined ? undefined : home + '/.dsh/' + DAILY_DIRECTORY;
        }

        // A Workspace registration carries no `hidden` flag, so work mode can
        // only keep the daily row out of the sidebar by filtering the snapshot
        // the sidebar renders from. The projection is cached per raw snapshot:
        // the browser reads through `useWorkspaces`, whose selector hook
        // compares snapshots by IDENTITY, and a fresh object on every call would
        // re-render forever.
        /** raw workspace snapshot → its work-mode projection. */
        const workModeViews = new WeakMap();

        /**
         * The workspace snapshot the sidebar may see for the active mode.
         *
         * Chat mode sees everything — that is the mode the daily workspace
         * belongs to, and resolving it reads this very snapshot. Work mode sees
         * every OTHER workspace: 日常聊天 is not a project, and a project row
         * that switches the whole product back into chat mode reads as one.
         * @param snapshot - the model's own snapshot.
         * @returns the snapshot to publish.
         */
        function visibleWorkspaces(snapshot) {
          if (state.mode !== 'work') return snapshot;
          const items = snapshot === null || typeof snapshot !== 'object' ? undefined : snapshot.items;
          if (!Array.isArray(items)) return snapshot;
          const expected = expectedDailyPath();
          if (!items.some((item) => isDailyWorkspace(item, expected))) return snapshot;
          const cached = workModeViews.get(snapshot);
          if (cached !== undefined) return cached;
          const filtered = Object.assign({}, snapshot, {
            items: items.filter((item) => !isDailyWorkspace(item, expected)),
          });
          workModeViews.set(snapshot, filtered);
          return filtered;
        }

        /* ── the work-mode session list ───────────────────────────────────────── */

        /** Shared empty answer for the ordinary "no daily workspace yet" case. */
        const NO_DAILY_IDS = new Set();

        /** raw workspace snapshot → the ids its daily workspace accounts for. */
        const dailyIdViews = new WeakMap();

        /**
         * The session ids the daily workspace accounts for.
         *
         * Read from the model's OWN workspace snapshot, which the projection
         * above deliberately leaves alone: a daily chat is hidden because of
         * what it is, so the question has to be asked of the unfiltered list.
         * @returns the ids, empty while the baseline has not landed yet.
         */
        function dailySessionIds() {
          const snapshot = readRawWorkspaces === undefined ? undefined : readRawWorkspaces();
          const items = snapshot === null || snapshot === undefined ? undefined : snapshot.items;
          if (!Array.isArray(items)) return NO_DAILY_IDS;
          const cached = dailyIdViews.get(snapshot);
          if (cached !== undefined) return cached;
          const expected = expectedDailyPath();
          const ids = new Set();
          for (const item of items) {
            if (!isDailyWorkspace(item, expected)) continue;
            for (const id of item.sessionIds) ids.add(id);
          }
          dailyIdViews.set(snapshot, ids);
          return ids;
        }

        // Hiding the daily WORKSPACE is not enough on its own: the browser
        // builds its 未分组 group out of every Session that no VISIBLE Workspace
        // accounts for, so the daily chats would simply move into that bucket.
        // Work mode therefore drops them from the session list too, which is
        // what "the two modes cannot see each other" means in practice. The
        // projection is cached per raw snapshot for the same identity reason as
        // the workspace one.
        /** raw session-list snapshot → its work-mode projection. */
        const workModeSessionViews = new WeakMap();

        /**
         * Whether one session belongs to the daily workspace.
         * @param id - the session id.
         * @param byId - the raw snapshot's session table.
         * @param accounted - ids the daily workspace accounts for.
         * @param expected - the path the Host half registers, when it is known.
         * @returns whether work mode should keep this session out of the list.
         */
        function isDailySession(id, byId, accounted, expected) {
          if (accounted.has(id)) return true;
          const row = byId[id];
          return row !== undefined && expected !== undefined && row.cwd === expected;
        }

        /**
         * The session-list snapshot the sidebar may see for the active mode.
         *
         * Chat mode sees everything; work mode sees neither the daily workspace
         * nor its chats. Only `ids` is projected — `byId` stays complete, so a
         * session still open in the main column keeps its summary and its
         * status while its row is gone from the list.
         * @param snapshot - the store's own snapshot.
         * @returns the snapshot to publish.
         */
        function visibleSessions(snapshot) {
          if (state.mode !== 'work') return snapshot;
          const ids = snapshot === null || typeof snapshot !== 'object' ? undefined : snapshot.ids;
          const byId = snapshot === null || typeof snapshot !== 'object' ? undefined : snapshot.byId;
          if (!Array.isArray(ids) || byId === null || typeof byId !== 'object') return snapshot;
          const accounted = dailySessionIds();
          const expected = expectedDailyPath();
          const hidden = (id) => isDailySession(id, byId, accounted, expected);
          if (!ids.some(hidden)) return snapshot;
          const cached = workModeSessionViews.get(snapshot);
          if (cached !== undefined) return cached;
          const filtered = Object.assign({}, snapshot, { ids: ids.filter((id) => !hidden(id)) });
          workModeSessionViews.set(snapshot, filtered);
          return filtered;
        }

        /**
         * Whether opening one workspace would stay inside the daily workspace.
         *
         * Project switching is the one navigation a daily chat does not get: its
         * workspace is what makes it a daily chat, and every other workspace
         * belongs to the work half of the product. The daily workspace is
         * resolved on each call rather than remembered, so this holds on a page
         * that is still waiting for the Host's first workspace baseline — an
         * unresolved daily workspace lets the navigation through rather than
         * breaking it outright.
         * @param workspaceId - the workspace the navigation targets.
         * @returns whether the target is the daily workspace.
         */
        function staysDaily(workspaceId) {
          const daily = pickDailyWorkspace(ctx.workspaces.list.getSnapshot().items);
          return daily !== undefined && workspaceId === daily.workspaceId;
        }

        /** Resolve once the Host's first workspace baseline lands, or on timeout. */
        function waitForWorkspaceBaseline(timeoutMs) {
          const source = ctx.workspaces.list;
          if (source.getSnapshot().phase === 'ready') return Promise.resolve();
          return new Promise((resolve) => {
            let settled = false;
            let timer = null;
            function finish() {
              if (settled) return;
              settled = true;
              off();
              if (timer !== null) clearTimeout(timer);
              resolve();
            }
            const off = source.subscribe(() => {
              if (source.getSnapshot().phase === 'ready') finish();
            });
            timer = setTimeout(finish, timeoutMs);
          });
        }

        /** Adopt one directory as the daily workspace, creating it when missing. */
        async function adopt(path) {
          try {
            return await ctx.workspaces.create({ path });
          } catch (reason) {
            const cut = path.lastIndexOf('/');
            if (cut <= 0) return undefined;
            try {
              await ctx.uiWorkspace.createDirectory(path.slice(0, cut), path.slice(cut + 1));
              return await ctx.workspaces.create({ path });
            } catch (retry) {
              console.warn(`[daily-chat] adopting ${path} failed:`, retry);
              return undefined;
            }
          }
        }

        /** The daily workspace, creating or adopting one when nothing matches. */
        async function resolveDailyWorkspace() {
          let found = pickDailyWorkspace(ctx.workspaces.list.getSnapshot().items);
          if (found !== undefined) return found;

          await waitForWorkspaceBaseline(4000);
          found = pickDailyWorkspace(ctx.workspaces.list.getSnapshot().items);
          if (found !== undefined) return found;

          const home = hostHome();
          const candidates = [];
          if (home !== undefined) {
            candidates.push(home + '/.dsh/' + DAILY_DIRECTORY);
            candidates.push(home + '/' + DAILY_DIRECTORY);
          }
          for (const candidate of candidates) {
            const adopted = await adopt(candidate);
            if (adopted !== undefined) return adopted;
          }

          const picked = await ctx.uiWorkspace.pickDirectory();
          if (typeof picked === 'string' && picked !== '') {
            return await ctx.workspaces.create({ path: picked });
          }
          throw new Error(t('needWorkspace'));
        }

        /** Open an existing session and make sure the sidebar shows chat mode. */
        function openDaily(sessionId) {
          setState({ mode: 'daily', error: null });
          ctx.layout.selectPanel(null);
          ctx.uiWorkspace.openSession(sessionId);
        }

        /**
         * The Host code a failed create carried, when it carried one.
         *
         * The client hands a create failure over as a `SessionCreateError` whose
         * own `rpcError` holds the Host's code, so the code is the difference
         * between "this deployment has no `daily` preset" and every other
         * failure.
         * @param reason - the thrown create failure.
         * @returns the code, or undefined.
         */
        function hostErrorCode(reason) {
          if (reason === null || typeof reason !== 'object') return undefined;
          if (typeof reason.code === 'string') return reason.code;
          const rpc = reason.rpcError;
          if (rpc === null || typeof rpc !== 'object' || typeof rpc.code !== 'string') return undefined;
          return rpc.code;
        }

        /**
         * Whether the daily workspace already holds the blank Session a create
         * would reuse.
         *
         * Answered from a FRESH snapshot, with the predicate DSH's own
         * `createInWorkspace` picks its blank with, because that fact decides
         * whether the fallback below may run: a blank means the create will
         * compose a Session that already exists, and no blank means it mints a
         * new one. Re-resolving the workspace here rather than reading the item
         * `resolveDailyWorkspace` handed over keeps both reads on one snapshot
         * version — the create re-resolves its workspace too.
         *
         * Anything it cannot read counts as "there is something to reuse": the
         * caller's conservative answer is to keep the original failure.
         * @param workspaceId - the daily workspace's id.
         * @returns whether a reuse is possible.
         */
        function hasReusableBlank(workspaceId) {
          try {
            const registry = ctx.workspaces.list.getSnapshot();
            const items = registry === null || registry === undefined ? undefined : registry.items;
            if (!Array.isArray(items)) return true;
            const workspace = items.find((item) => item.workspaceId === workspaceId);
            if (workspace === undefined) return false;
            const sessions = ctx.sessions.list.getSnapshot();
            const byId = sessions === null || sessions === undefined ? undefined : sessions.byId;
            const ids = sessions === null || sessions === undefined ? undefined : sessions.ids;
            if (byId === null || typeof byId !== 'object' || !Array.isArray(ids)) return true;
            const archived = Array.isArray(registry.archivedSessionIds) ? registry.archivedSessionIds : [];
            return ids.some((id) => {
              const row = byId[id];
              return row !== undefined
                && row.blank
                && row.cwd === workspace.path
                && workspace.sessionIds.indexOf(id) !== -1
                && archived.indexOf(id) === -1;
            });
          } catch (reason) {
            console.warn('[daily-chat] reading the workspace for a reusable blank Session failed:', reason);
            return true;
          }
        }

        /**
         * Open the daily workspace's blank Session, asking for the daily preset
         * as part of the request instead of composing it afterwards.
         *
         * `connectWorkspace` opens the blank Session a workspace already has —
         * its second argument is what puts it in that reuse branch at all — and
         * DSH composes a reused or minted blank with the preset the create
         * request NAMES, falling back to the deployment default when it names
         * none. That default is what a daily chat may not run on (see the Host
         * half's preset lock), so the unnamed request is refused and the whole
         * create fails with `failed to create session: … 日常聊天固定使用 daily
         * 预设…`. Clicking 「日常聊天」 a second time is exactly that request: the
         * first click already put the blank on `daily`, so the second one asked
         * to put it back on the default. Naming `daily` makes the request agree
         * with the Session it reuses, and a workspace with no blank mints the new
         * Session on `daily` directly rather than composing it on the default and
         * switching afterwards.
         *
         * The fallback keeps the degradation this plugin documents elsewhere — a
         * deployment whose roster lost `daily` still opens the chat on its default
         * preset, with a warning — and it retries ONLY when both halves of that
         * case hold: the create failed because the preset could not be resolved
         * (every other failure is reported instead of retried, which also keeps a
         * half-finished create from being run twice), and the workspace has
         * nothing to reuse. The reuse branch is precisely the one that cannot
         * reach the default: it composes the Session it reuses, the Host lock
         * refuses every non-daily preset for a Session in the daily directory,
         * and retrying through it would hand the user back the very error this
         * function exists to avoid.
         * @param workspace - the resolved daily workspace.
         * @returns the Session the workspace opened.
         */
        async function connectDailySession(workspace) {
          try {
            return await ctx.uiWorkspace.connectWorkspace(workspace.workspaceId, { agentPreset: DAILY_PRESET });
          } catch (reason) {
            const code = hostErrorCode(reason);
            const missingPreset = code === 'agent-preset/not-found' || code === 'agent-preset/invalid';
            if (!missingPreset || hasReusableBlank(workspace.workspaceId)) throw reason;
            console.warn(`[daily-chat] the "${DAILY_PRESET}" preset is unavailable; opening on the deployment default instead:`, reason);
            return await ctx.uiWorkspace.connectWorkspace(workspace.workspaceId);
          }
        }

        /**
         * Start (or reuse the blank) daily session and compose it on the daily
         * preset.
         *
         * Resolving the workspace is asynchronous, and the two mode rows are one
         * click apart: without the ticket below, picking 「开始工作」 while a
         * daily start is still in flight would let that start land afterwards
         * and drag the UI back into chat mode. A start that loses the ticket
         * also leaves the mode alone — the newer action already set it.
         *
         * Chat mode is published BEFORE the workspace is resolved, because work
         * mode hides the daily workspace from the snapshot (see
         * {@link visibleWorkspaces}) and both the resolution and the connect
         * below read that snapshot. A start that fails puts the previous mode
         * back and hands the centre column back with it, so a refusal leaves the
         * sidebar and the composer exactly as they were instead of parking the
         * middle column on the placeholder line a transient panel paints.
         */
        async function startDailyChat() {
          if (starting) return;
          starting = true;
          const ticket = ++startTicket;
          const previous = state.mode;
          setState({ mode: 'daily', busy: true, error: null });
          try {
            const workspace = await resolveDailyWorkspace();
            if (ticket !== startTicket) return;
            const sessionId = await connectDailySession(workspace);
            if (ticket !== startTicket) return;
            setState({ busy: false, error: null });
            ctx.layout.selectPanel(null);
            ctx.uiWorkspace.openSession(sessionId);
            try {
              await ctx.remote.agentPresets.select(sessionId, DAILY_PRESET);
            } catch (reason) {
              console.warn(`[daily-chat] composing the "${DAILY_PRESET}" preset failed:`, reason);
            }
          } catch (reason) {
            console.warn('[daily-chat] starting a daily chat failed:', reason);
            if (ticket !== startTicket) return;
            setState({ mode: previous, busy: false, error: `${t('failed')}：${describe(reason)}` });
            ctx.layout.selectPanel(null);
          } finally {
            starting = false;
          }
        }

        /** The shipped New Session behaviour. */
        function startWorkSession() {
          startTicket += 1;
          setState({ mode: 'work', error: null });
          ctx.layout.selectPanel(null);
          if (typeof originalStartSession === 'function') {
            originalStartSession.call(ctx.uiWorkspace);
          } else {
            ctx.uiWorkspace.startSession();
          }
        }

        /* ── the entry row, and the daily home it opens ───────────────────── */

        /**
         * Conversations accounted to the daily workspace, newest first.
         * @param workspaces - the workspace snapshot.
         * @param sessions - the session-list snapshot.
         * @returns the rows both daily surfaces render.
         */
        function dailyRows(workspaces, sessions) {
          const workspace = pickDailyWorkspace(workspaces.items);
          if (workspace === undefined || sessions.phase !== 'ready') return [];
          const archived = workspaces.archivedSessionIds;
          const rows = [];
          for (const id of workspace.sessionIds) {
            if (archived.indexOf(id) !== -1) continue;
            const row = sessions.byId[id];
            if (row === undefined || row.blank === true || row.origin === 'subagent') continue;
            rows.push(row);
          }
          rows.sort((left, right) => right.updatedAt - left.updatedAt);
          return rows;
        }

        /**
         * How many rows one page adds to the daily list.
         *
         * The rows are all in the snapshot already — this window decides what
         * gets painted, not what gets fetched. An account with hundreds of
         * conversations therefore mounts one page of buttons on open and one
         * more page each time the list reaches its end, instead of mounting
         * every row before the first paint.
         */
        const ROW_PAGE = 20;

        /**
         * The sliding window of daily rows the mounted list has painted.
         *
         * The window belongs to the list, not to the snapshot: a row arriving,
         * leaving or being renamed re-cuts the same window and must never push
         * rows below it back out of reach. Entering 日常 remounts the region, so
         * the window starts over at one page there.
         *
         * The end of the list is a 1px `.dsc-pager` strip watched by an
         * IntersectionObserver rooted at the scroll container. That is one
         * browser-maintained comparison instead of a scroll handler, and it also
         * covers a viewport tall enough to show the whole page: the strip is in
         * view on mount, so the next page loads even though no wheel event can
         * ever reach the bottom of a list that does not overflow yet.
         *
         * The effect re-arms after every page (`visible` is a dependency)
         * because a viewport may be tall enough to show two or three pages: an
         * observer kept on the same node only fires on threshold CROSSINGS, so
         * once the strip stays inside the viewport it would never ask again.
         * Re-observing publishes the current state instead, and the window keeps
         * growing until the list overflows or runs out — never leaving a
         * non-scrollable list with rows stranded behind it.
         *
         * @param rows - the rows the list would paint without a window.
         * @returns `visible` (rows to paint), `more` (whether any wait behind
         *   them), `listRef` (the scroll container) and `sentinelRef` (the
         *   trigger strip).
         */
        function usePagedRows(rows) {
          const [visible, setVisible] = React.useState(ROW_PAGE);
          const listRef = React.useRef(null);
          const sentinelRef = React.useRef(null);
          const total = rows.length;
          const more = total > visible;

          React.useEffect(() => {
            if (!more) return undefined;
            const scroll = listRef.current;
            const sentinel = sentinelRef.current;
            if (scroll === null || sentinel === null) return undefined;
            if (typeof IntersectionObserver !== 'function') {
              // No observer (an old webview): paint everything. A window that
              // can never grow would hide rows with nothing left to reveal them.
              setVisible(total);
              return undefined;
            }
            const observer = new IntersectionObserver((entries) => {
              if (!entries.some((entry) => entry.isIntersecting)) return;
              setVisible((painted) => Math.min(painted + ROW_PAGE, total));
            }, { root: scroll, rootMargin: '120px 0px' });
            observer.observe(sentinel);
            return () => { observer.disconnect(); };
          }, [more, total, visible]);

          return { visible, more, listRef, sentinelRef };
        }

        /**
         * The standard-prop workspace reader, with a stable empty fallback so an
         * absent source degrades to an empty list instead of a crash.
         * @param props - the composed slot props.
         * @returns the workspace snapshot.
         */
        function useWorkspacesOf(props) {
          const read = typeof props.useWorkspaces === 'function'
            ? props.useWorkspaces
            : () => EMPTY_WORKSPACES;
          return read((snapshot) => snapshot);
        }

        /**
         * The standard-prop session-list reader, same fallback contract.
         * @param props - the composed slot props.
         * @returns the session-list snapshot.
         */
        function useSessionsOf(props) {
          const read = typeof props.useSessions === 'function'
            ? props.useSessions
            : () => EMPTY_SESSIONS;
          return read((snapshot) => snapshot);
        }

        /**
         * Build one transient mode panel — the surface behind a sidebar mode row.
         *
         * A `sidebar.panellist` row's click belongs to the shell and can only
         * `selectPanel(id)`, so a row that ACTS has to be a panel that hands
         * control straight back: it performs its action once and returns the
         * centre column to the conversation. Both mode rows work this way, which
         * is what makes 「日常聊天」 and 「开始工作」 land in the composer instead
         * of on an intermediate page. The line rendered below is what the centre
         * paints for the frame before the effect runs.
         *
         * @param panelId - the `main` key this panel answers for.
         * @param textKey - locale key for the placeholder line.
         * @param action - what the row does.
         * @returns the slot component.
         */
        function makeStarter(panelId, textKey, action) {
          return function Starter(props) {
            // Gated on the panel actually being the dispatched key: a keyed slot
            // may keep an entry mounted while another key renders, and mounting
            // is not selecting — acting on mount alone would fire the action just
            // for having the plugin loaded.
            const active = typeof props.usePanelInfo === 'function'
              ? props.usePanelInfo((info) => info.activePanelId === panelId)
              : true;

            React.useEffect(() => {
              if (active) action();
            }, [active]);

            return h('div', { className: 'dsc-panel' }, [
              h('style', { key: 'css' }, CSS),
              h('div', { className: 'dsc-panelInner', key: 'inner' },
                h('div', { className: 'dsc-panelHint', key: 'hint' }, props.t(textKey))),
            ]);
          };
        }

        /** 「日常聊天」: enter chat mode and land in the blank chat's composer. */
        const DailyStarter = makeStarter(DAILY_PANEL, 'starting', () => {
          void startDailyChat();
        });

        /** 「开始工作」: enter work mode and land in the work session. */
        const WorkStarter = makeStarter(WORK_PANEL, 'startingWork', () => {
          startWorkSession();
        });

        /**
         * 「更多」: fold the other sidebar rows away, then hand the centre column
         * straight back. Like the two mode rows this is a row that ACTS — the
         * shell owns the click and only knows `selectPanel(id)` — so it answers
         * for its own `main` key. It paints nothing: the swap is a flip of one
         * `<html>` attribute, and the single frame it costs is not worth a
         * placeholder line.
         */
        function MoreStarter(props) {
          const active = typeof props.usePanelInfo === 'function'
            ? props.usePanelInfo((info) => info.activePanelId === MORE_PANEL)
            : false;

          React.useEffect(() => {
            if (!active) return;
            togglePanels();
            ctx.layout.selectPanel(null);
          }, [active]);

          return null;
        }

        /**
         * Carries the chrome adjustments, mounted unconditionally on the
         * frame-wide overlay layer so they apply in every mode. Rendering a
         * `<style>` element means unmounting the plugin takes the rules away
         * with it.
         */
        function ChromeStyle() {
          return h('style', null, CHROME_CSS);
        }

        /**
         * A failed start has no room to print itself in a sidebar row, so it
         * surfaces as a transient card on the frame-wide overlay layer.
         */
        function ErrorToast(props) {
          const t = props.t;
          const chat = useChatState();
          if (chat.error === null) return null;

          return h('div', { className: 'dsc-toast', role: 'status' }, [
            h('style', { key: 'css' }, CSS),
            h('div', { className: 'dsc-toast-text', key: 'text' }, chat.error),
            h('button', {
              key: 'close',
              type: 'button',
              className: 'dsc-toast-close',
              onClick: () => setState({ error: null }),
            }, t('dismiss')),
          ]);
        }

        /* ── the daily browsing region ────────────────────────────────────── */

        /**
         * The session list that stands in for the workspace browser in chat mode.
         *
         * A row is that browser's row minus everything a daily chat cannot do:
         * the status dot (running), the title, and the trailing relative age —
         * same words, same thresholds and same 10px tertiary cell as 工作's own
         * rows, because the two lists sit one mode apart and must not disagree
         * about how old a conversation is. No row actions, so nothing takes the
         * age cell's place on hover.
         */
        function DailyRegion(props) {
          const t = props.t;
          const wide = props.wide !== false;
          const workspaces = useWorkspacesOf(props);
          const sessions = useSessionsOf(props);
          const chat = useChatState();
          // One clock for the whole list: every row's age is read against the
          // same instant, so two rows that are the same age never disagree.
          const now = useRelativeClock();

          const rows = dailyRows(workspaces, sessions);
          // The list paints one page at a time and adds a page whenever its
          // 1px end strip scrolls into view; see {@link usePagedRows}.
          const paged = usePagedRows(rows);

          return h('div', { className: 'dsc-region' + (wide ? '' : ' dsc-rail') }, [
            h('style', { key: 'css' }, CSS),
            h('div', { className: 'dsc-head', key: 'head' }, [
              h('div', { className: 'dsc-title', key: 'title' }, t('dailyChats')),
              // The shipped header's add control: same glyph, same two sizes
              // (16 in the expanded sidebar, 18 in the collapsed rail), same
              // hover-only paint — a text button here would be the one row of
              // the sidebar that speaks a different language.
              h('button', {
                key: 'new',
                type: 'button',
                className: 'dsc-new',
                title: t('newChat'),
                'aria-label': t('newChat'),
                onClick: () => {
                  void startDailyChat();
                },
              }, AddGlyph === null ? '＋' : h(AddGlyph, { size: wide ? 16 : 18 })),
            ]),
            // The wrapper the shipped browser wraps its own list in; see the
            // `.dsc-listArea` rule for why the scrollbar needs it.
            h('div', { className: 'dsc-listArea', key: 'listArea' },
              h('div', { className: 'dsc-list', key: 'list', ref: paged.listRef }, rows.length === 0
                ? h('div', { className: 'dsc-empty', key: 'empty' }, chat.busy ? t('starting') : t('empty'))
                : rows.slice(0, paged.visible).map((row) => h('button', {
                  key: row.id,
                  type: 'button',
                  className: 'dsc-row',
                  title: row.displayTitle,
                  onClick: () => openDaily(row.id),
                }, [
                  h('span', {
                    key: 'dot',
                    className: 'dsc-dot' + (row.running ? ' dsc-dot-on' : ''),
                  }),
                  h('span', { key: 'title', className: 'dsc-rowtitle' }, row.displayTitle || row.id),
                  // Trailing age, the way a workspace row carries it: the title
                  // cell keeps `flex:1` and clips, so the label never squeezes
                  // the title to nothing and never wraps.
                  h('span', {
                    key: 'time',
                    className: 'dsc-rowtime',
                  }, timeLabel(row.updatedAt, now, t)),
                ])).concat(paged.more ? [h('div', {
                  key: 'more',
                  className: 'dsc-pager',
                  ref: paged.sentinelRef,
                  'aria-hidden': 'true',
                })] : []))),
          ]);
        }

        /* ── registration ─────────────────────────────────────────────────── */

        // The labeled entry points: three full-width rows at the TOP of the
        // sidebar's global panel list — above 「插件」, which sits at order 0 —
        // rendered by the shell as icon + label like every other panel row. The
        // shell owns the buttons and calls `selectPanel(id)`, so each panellist
        // id MUST address a registered `main` panel or that call throws; each
        // pair of registrations is therefore one unit.
        ctx.slots.inject('sidebar', () => ctx.slots.register({
          name: 'sidebar.panellist',
          id: DAILY_PANEL,
          order: -20,
          label: () => t('dailyChats'),
          locale: LOCALE_NS,
        }, ChatGlyph));

        ctx.slots.inject('main', () => ctx.slots.register({
          name: 'main',
          key: DAILY_PANEL,
          locale: LOCALE_NS,
        }, DailyStarter));

        // The other half of the mode switch, as a sibling row: 「开始工作」.
        // Same seat, same constraint — the row needs a panel to address, and
        // that panel is the one that actually performs the switch.
        ctx.slots.inject('sidebar', () => ctx.slots.register({
          name: 'sidebar.panellist',
          id: WORK_PANEL,
          order: -10,
          label: () => t('startWork'),
          locale: LOCALE_NS,
        }, WorkGlyph));

        ctx.slots.inject('main', () => ctx.slots.register({
          name: 'main',
          key: WORK_PANEL,
          locale: LOCALE_NS,
        }, WorkStarter));

        /**
         * Whether the panel list is long enough to want 「更多」.
         *
         * The count is over every row the list would show without it — this
         * plugin's two mode rows included, because those are rows the operator
         * reads — and only past {@link PANEL_ROW_LIMIT} of them does the fold
         * earn its place. Up to the limit the rows are all left standing; the
         * shrunken list stays honest about what is there. `entries` is the raw
         * ledger and stays readable before the slot is declared (an unknown key
         * reads as empty), so this may probe ahead of plugin load order.
         */
        function needsMoreRow() {
          try {
            return ctx.slots.entries('sidebar.panellist')
              .filter((entry) => entry.options.id !== MORE_PANEL)
              .length > PANEL_ROW_LIMIT;
          } catch (reason) {
            console.warn('[daily-chat] reading the panel list failed:', reason);
            return false;
          }
        }

        // The third row of the same seat, between the mode rows and 「插件」:
        // 「更多」 folds away every row this plugin does not own. Same pair
        // contract as above — the row addresses a `main` panel, and that panel
        // is what performs the fold.
        //
        // It only earns its place past {@link PANEL_ROW_LIMIT} rows. Other
        // plugins register later than this one (and can be enabled at runtime),
        // so the decision is re-taken on every panel-list mutation instead of
        // once at load — which also means the row appears when the fourth menu
        // arrives and leaves again when one goes. The `main` panel below stays
        // registered either way: while the row is absent nothing can activate
        // it, and a `panellist` id with no `main` panel behind it would make
        // `selectPanel` throw.
        ctx.slots.inject('sidebar', () => {
          /** Disposers for the entries registered right now, if any. */
          let disposers = [];
          /** Whether 「更多」 is registered at this instant. */
          let showing = false;

          const settle = () => {
            const wanted = needsMoreRow();
            // Guarded so the register/dispose calls below — which notify this
            // very subscription — settle instead of recursing.
            if (wanted === showing) return;
            showing = wanted;
            for (const dispose of disposers.splice(0)) dispose();
            if (wanted) {
              disposers = [ctx.slots.register({
                name: 'sidebar.panellist',
                id: MORE_PANEL,
                order: MORE_ORDER,
                label: () => t('more'),
                locale: LOCALE_NS,
              }, MoreGlyph)];
            }
            moreRowPresent = showing;
            syncFoldAttribute();
          };

          const unsubscribe = ctx.slots.subscribe('sidebar.panellist', settle);
          settle();

          return () => {
            unsubscribe();
            for (const dispose of disposers.splice(0)) dispose();
            moreRowPresent = false;
            syncFoldAttribute();
          };
        });

        ctx.slots.inject('main', () => ctx.slots.register({
          name: 'main',
          key: MORE_PANEL,
          locale: LOCALE_NS,
        }, MoreStarter));

        ctx.slots.inject('shell.overlay', () => ctx.slots.register({
          name: 'shell.overlay',
          id: 'daily-chat-chrome',
          order: 1,
        }, ChromeStyle));

        ctx.slots.inject('shell.overlay', () => ctx.slots.register({
          name: 'shell.overlay',
          id: 'daily-chat-error',
          order: 50,
          locale: LOCALE_NS,
        }, ErrorToast));

        // Only one entry renders a `single` slot, and it is the LOWEST live
        // priority — so `-1` takes the region over for chat mode and giving the
        // registration back puts the shipped workspace browser in charge again.
        let region = null;
        function refreshRegion() {
          if (state.mode === 'daily') {
            if (region === null) {
              region = ctx.slots.register({
                name: 'sidebar.workspaces',
                priority: -1,
                locale: LOCALE_NS,
              }, DailyRegion);
            }
            return;
          }
          if (region !== null) {
            region();
            region = null;
          }
        }

        ctx.slots.inject('sidebar.workspaces', () => {
          refreshRegion();
          listeners.add(refreshRegion);
          return () => {
            listeners.delete(refreshRegion);
            if (region !== null) {
              region();
              region = null;
            }
          };
        });

        // The elapsed line in a settled Turn's footer — its two faces.
        //
        // `conversation.chat.turnTail` is the seat DSH paints once per settled
        // Turn; the `turn` it hands over is the same Turn location the shipped
        // process header reads its duration from, so nothing has to be
        // subscribed to, stored or recomputed here. What is registered on it is
        // the carrier: the numbers, plus the line as it looks when the action
        // row below is not there to paint into.
        //
        // `conversation.chat.assistant-actions` is the other face, and the only
        // seat DSH renders *inside* the copy/branch/time row itself. Reading the
        // carrier back from there is what puts the figure on the row's own line,
        // after the usage figure and the clock, instead of on a line of its own.
        // Both seats are registered for both modes on purpose: the figure is
        // DSH's own and the line only ever repeats what the shipped header would
        // have shown had the default display modes not folded it away.
        ctx.slots.inject('conversation.chat.turnTail', () => ctx.slots.register({
          name: 'conversation.chat.turnTail',
          id: TURN_CONTRIBUTION,
          order: TURN_ORDER,
          locale: LOCALE_NS,
        }, TurnDuration));
        ctx.slots.inject('conversation.chat.assistant-actions', () => ctx.slots.register({
          name: 'conversation.chat.assistant-actions',
          id: TURN_INLINE_CONTRIBUTION,
          order: TURN_ORDER,
          locale: LOCALE_NS,
        }, TurnElapsed));

        // Two shipped navigation methods carry chat mode's two refusals.
        //
        // `startSession` is where every New Session entry point lands — the
        // sidebar shell's own button included — so that is where 日常 has to be
        // honoured. `openWorkspace` is where every project switch lands: the
        // new-chat row's 项目 chip, the empty composer's workspace prompt and
        // the directory picker all funnel into it, and a daily chat may not
        // leave its own workspace through any of them. Both patches live on the
        // service PROTOTYPE: Cordis hands each consumer a fresh traceable proxy
        // of one shared instance, and the sidebar captured its proxy long
        // before this plugin loaded.
        ctx.inject(['uiWorkspace'], (workspaceCtx) => {
          workspaceCtx.effect(() => {
            const proto = Object.getPrototypeOf(workspaceCtx.uiWorkspace);
            const original = proto === null ? undefined : proto.startSession;
            if (typeof original !== 'function') return undefined;
            const originalOpenWorkspace = proto.openWorkspace;

            originalStartSession = original;
            proto.startSession = function startSession(workspaceId) {
              if (state.mode === 'daily' && !starting) {
                void startDailyChat();
                return undefined;
              }
              return original.call(this, workspaceId);
            };

            // Refused rather than redirected: the caller asked for another
            // project, and the honest answer is that a daily chat does not have
            // one. The rejection is also what puts the pickers back in step —
            // they clear the choice they optimistically showed on a rejection —
            // and the toast is the only place the reason can be read, since the
            // pickers swallow their own failure.
            if (typeof originalOpenWorkspace === 'function') {
              proto.openWorkspace = function openWorkspace(workspaceId, beforeOpen) {
                if (state.mode === 'daily' && !staysDaily(workspaceId)) {
                  const refusal = new Error(t('lockedProject'));
                  setState({ error: refusal.message });
                  return Promise.reject(refusal);
                }
                return originalOpenWorkspace.call(this, workspaceId, beforeOpen);
              };
            }

            return () => {
              proto.startSession = original;
              if (typeof originalOpenWorkspace === 'function') {
                proto.openWorkspace = originalOpenWorkspace;
              }
              originalStartSession = undefined;
            };
          }, 'daily-chat: New Session routing and the project lock');
        });

        // Work mode does not list the daily workspace.
        //
        // The filter sits on the model PROTOTYPE for the same reason the two
        // navigation patches do: Cordis hands each consumer a fresh traceable
        // proxy of one shared model, and the sidebar published its own proxy as
        // the `workspaces` hook long before this plugin loaded. Only the shared
        // prototype reaches it — and the hook calls `getSnapshot()` through that
        // proxy on every read, so the projection needs no resubscription to take
        // effect.
        ctx.inject(['workspaces'], (workspaceCtx) => {
          workspaceCtx.effect(() => {
            const model = workspaceCtx.workspaces.list;
            const proto = model === null || model === undefined ? null : Object.getPrototypeOf(model);
            const original = proto === null ? undefined : proto.getSnapshot;
            if (typeof original !== 'function') return undefined;
            // The session projection below needs the daily workspace's own
            // account, so keep a way back to the unfiltered read.
            readRawWorkspaces = () => original.call(model);
            proto.getSnapshot = function getSnapshot() {
              return visibleWorkspaces(original.call(this));
            };
            return () => {
              proto.getSnapshot = original;
              readRawWorkspaces = undefined;
            };
          }, 'daily-chat: work mode hides the daily workspace');
        });

        // The daily chats go with the workspace.
        //
        // This store is an OBJECT, not a class instance — `createSnapshotStore`
        // hands back an object literal with `getSnapshot` on it — so unlike the
        // three patches above this one replaces the method on the object itself.
        // That is enough: the browser publishes this very object as the
        // `sessions` hook (`provideRoot({ hooks: { sessions: sessions.list } })`),
        // so every `useSessions` reader sees the projection.
        ctx.inject(['sessions'], (sessionCtx) => {
          sessionCtx.effect(() => {
            const store = sessionCtx.sessions.list;
            if (store === null || store === undefined) return undefined;
            const original = store.getSnapshot;
            if (typeof original !== 'function') return undefined;
            try {
              store.getSnapshot = function getSnapshot() {
                return visibleSessions(original.call(this));
              };
            } catch (reason) {
              console.warn('[daily-chat] hiding the daily chats from work mode failed:', reason);
              return undefined;
            }
            return () => {
              try {
                store.getSnapshot = original;
              } catch (reason) {
                console.warn('[daily-chat] restoring the session list failed:', reason);
              }
            };
          }, 'daily-chat: work mode hides the daily chats');
        });
      },
    };
  },
});
