window.__ModuleLoader__.load({
  id: 'dsh-visio',
  factory(require) {
    const React = require('react')
    const h = React.createElement
    const { useCallback, useEffect, useMemo, useRef, useState } = React

    const NS = 'dsh-visio'
    const ROUTE = 'dsh-visio'
    const PANEL_ID = 'dsh-visio'
    const POLL_MS = 2500
    // Bumped with every release: the footer shows it, so a stale bundle is obvious.
    const CLIENT_BUILD = '1.24.0'

    /* ------------------------------------------------------------- locale */

    const zh = {
      nav: 'Visio 图纸',
      title: 'Visio 图纸',
      subtitle: '读取、创建、修改 .vsdx，并实时预览',
      files: '图纸文件',
      shapes: '形状',
      pages: '页面',
      folder: '文件夹',
      chooseFolder: '选择文件夹',
      refresh: '刷新',
      newFile: '新建',
      openFile: '打开',
      noFiles: '这个文件夹里没有 .vsdx 文件',
      noDocTitle: '还没有打开图纸',
      noDocBody: '从左侧选择一个 .vsdx，或者新建一张空白图纸。预览、修改和保存都在这里完成，不需要安装 Visio。',
      emptyFolder: '（未选择文件夹）',
      page: '页',
      shape: '形状',
      connector: '连接线',
      textShape: '文本',
      noShapes: '这一页还没有形状',
      selectShape: '在预览或列表里点一个形状来编辑。',
      text: '文本',
      textPlaceholder: '形状文字（支持多行）',
      geometry: '位置与大小',
      outOfPage: '已超出页面范围',
      lineKind: '直线',
      rotation: '旋转 °',
      lineToolOn: '直线工具：在画布上按住拖动画一条线',
      lineToolOff: '已退出直线工具',
      lineDrawn: '已画一条直线',
      linkFromPort: '已选起点，拖到另一个图形完成连线',
      connectHint: '从图形边上的圆点拖到另一个图形即可连线',
      occlusion: '遮挡',
      route: '走线',
      routeHint: '拖动线上的蓝色手柄：横线上下移、竖线左右移，端点不动',
      route_up: '上方',
      route_down: '下方',
      route_left: '左侧',
      route_right: '右侧',
      route_auto: '自动',
      linkTool: '连线工具',
      needTarget: '没有对准任何形状，端点未移动',
      linkPickTarget: '已选起点 #{id}，再点目标形状完成连线',
      textBg: '文字背景遮挡',
      textBgHint: '打开后文本框带白底，会遮住下面的连线',
      snapBack: '拉回页面',
      x: 'X',
      y: 'Y',
      width: '宽',
      height: '高',
      style: '外观',
      fill: '填充',
      line: '线条',
      weight: '线宽',
      shapeData: '形状数据',
      addProp: '添加属性',
      propName: '属性名',
      propValue: '值',
      deleteShape: '删除形状',
      connectTo: '连接到',
      connect: '加连接线',
      connectedTo: '已连接到 #{id}',
      duplicatedAs: '已复制并连接 #{id}',
      connectLabel: '连接线文字',
      tools: '添加形状',
      addRect: '矩形',
      addEllipse: '椭圆',
      addLine: '直线',
      addText: '文本',
      createTitle: '新建 Visio 图纸',
      createName: '文件名',
      createNameHint: '可以省略 .vsdx 后缀',
      createPage: '页面',
      createTitleField: '标题（可选）',
      createTitleHint: '会作为文本形状放在页面顶部',
      createCustom: '自定义',
      createIn: '保存到',
      create: '创建',
      cancel: '取消',
      sizeA4L: 'A4 横向 11.69 × 8.27',
      sizeA4P: 'A4 纵向 8.27 × 11.69',
      sizeA3L: 'A3 横向 16.54 × 11.69',
      sizeLetterL: 'Letter 横向 11 × 8.5',
      deleteConfirm: '删除形状 #{id}？这会同时删除与它相连的连接线。',
      saved: '已保存',
      busy: '正在处理…',
      refreshing: '正在刷新…',
      readOnlyHint: '每次保存都会在旁边留一份 .bak-时间戳 备份（保留最近 20 份）。',
      loadError: '无法读取图纸',
      createFailed: '新建失败',
      retry: '重试',
      pythonMissing: '找不到 Python 解释器，图纸引擎无法运行。请确认 python 在 PATH 中，或在插件配置里设置 pythonPath。',
      folderMissing: '默认文件夹不存在，请选择一个文件夹。',
      shapesCount: '{count} 个形状',
      pageOf: '第 {page} / {total} 页',
      selected: '已选中 #{id}',
      deselect: '取消选择',
      unnamed: '（未命名）',
      preview: '实时预览',
      lang: 'zh',
      stencil: '模具（.vssx）',
      stencilPlaceholder: '模具文件路径',
      stencilHint: '填一个 .vssx/.vstx 路径后点载入，即可把里面的母版插进图纸。',
      load: '载入',
      gridToggle: '网格：显示/隐藏（导出跟随此开关）',
      export: '导出',
      validate: '检查关系',
      validateClean: '关系检查通过：没有空关系或悬空端点',
      validateIssues: '关系检查：',
      exportPng: '导出 PNG',
      exported: '已导出',
      undo: '撤销',
      redo: '重做',
      undoHint: '撤销上一步 (Ctrl+Z)',
      shortcutHint: 'Del 删除 · Ctrl+Z 撤销 · Ctrl+Y 重做 · 右键拖动平移',
      redoHint: '重做 (Ctrl+Shift+Z / Ctrl+Y)',
      zoomIn: '放大（Ctrl+滚轮）',
      zoomOut: '缩小（Ctrl+滚轮）',
      zoomFit: '适应',
      handTool: '抓手（拖动平移）',
      toggleTree: '显示/隐藏左侧列表',
      toggleInspector: '显示/隐藏右侧属性',
      floatTip: '打开浮动画布窗口（可拖动、可改大小）',
      floatTitle: 'Visio 图纸 · 浮动画布',
      floatMove: '拖动移动',
      floatReset: '复位位置（Esc 关闭）',
      floatClose: '收起窗口',
      fixUnits: '修复单位',
      fixUnitsTip: '把文件里标错的单位（U=MM/PT）改回 Visio 内部单位，修正 Visio 打开时页面/字号/线宽异常',
      autosave: '自动保存',
      externalChanged: '文件已在别处更新，预览已刷新',
      opFailed: '操作失败',
    }

    const en = {
      nav: 'Visio drawings',
      title: 'Visio drawings',
      subtitle: 'Read, create and edit .vsdx with a live preview',
      files: 'Drawings',
      shapes: 'Shapes',
      pages: 'Pages',
      folder: 'Folder',
      chooseFolder: 'Choose folder',
      refresh: 'Refresh',
      newFile: 'New',
      openFile: 'Open',
      noFiles: 'No .vsdx files in this folder',
      noDocTitle: 'No drawing open',
      noDocBody: 'Pick a .vsdx on the left, or create a blank drawing. Preview, edits and saves all happen here — Visio is not required.',
      emptyFolder: '(no folder selected)',
      page: 'Page',
      shape: 'Shape',
      connector: 'Connector',
      textShape: 'Text',
      noShapes: 'This page has no shapes yet',
      selectShape: 'Click a shape in the preview or the list to edit it.',
      text: 'Text',
      textPlaceholder: 'Shape text (multi-line)',
      geometry: 'Position and size',
      outOfPage: 'Outside the page',
      lineKind: 'Line',
      rotation: 'Rotation °',
      lineToolOn: 'Line tool: drag on the canvas to draw a line',
      lineToolOff: 'Line tool off',
      lineDrawn: 'Line drawn',
      linkFromPort: 'Start point set, drag to another shape',
      connectHint: 'Drag from a dot on a shape edge to another shape to connect',
      occlusion: 'Occlusion',
      route: 'Routing',
      routeHint: 'Drag the blue handles: a horizontal run moves up/down, a vertical one moves sideways; the ends stay put',
      route_up: 'Over',
      route_down: 'Under',
      route_left: 'Left',
      route_right: 'Right',
      route_auto: 'Auto',
      linkTool: 'Connect tool',
      needTarget: 'Not aligned with any shape; the end was not moved',
      linkPickTarget: 'Start #{id} picked, now click the target shape',
      textBg: 'Opaque text background',
      textBgHint: 'Paints a white block behind the text so it hides lines underneath',
      snapBack: 'Bring back',
      x: 'X',
      y: 'Y',
      width: 'W',
      height: 'H',
      style: 'Appearance',
      fill: 'Fill',
      line: 'Line',
      weight: 'Weight',
      shapeData: 'Shape data',
      addProp: 'Add property',
      propName: 'Name',
      propValue: 'Value',
      deleteShape: 'Delete shape',
      connectTo: 'Connect to',
      connect: 'Add connector',
      connectedTo: 'Connected to #{id}',
      duplicatedAs: 'Duplicated and linked #{id}',
      connectLabel: 'Connector text',
      tools: 'Add shape',
      addRect: 'Rectangle',
      addEllipse: 'Ellipse',
      addLine: 'Line',
      addText: 'Text',
      createTitle: 'New Visio drawing',
      createName: 'File name',
      createNameHint: '.vsdx is added when omitted',
      createPage: 'Page',
      createTitleField: 'Title (optional)',
      createTitleHint: 'Drawn as a text shape at the top of the page',
      createCustom: 'Custom',
      createIn: 'Save to',
      create: 'Create',
      cancel: 'Cancel',
      sizeA4L: 'A4 landscape 11.69 × 8.27',
      sizeA4P: 'A4 portrait 8.27 × 11.69',
      sizeA3L: 'A3 landscape 16.54 × 11.69',
      sizeLetterL: 'Letter landscape 11 × 8.5',
      deleteConfirm: 'Delete shape #{id}? Its connectors are removed too.',
      saved: 'Saved',
      busy: 'Working…',
      refreshing: 'Refreshing…',
      readOnlyHint: 'Every save keeps a .bak-<timestamp> copy beside the file (last 20 kept).',
      loadError: 'Cannot read the drawing',
      createFailed: 'Create failed',
      retry: 'Retry',
      pythonMissing: 'Python was not found, so the drawing engine cannot run. Make python available on PATH or set pythonPath in the plugin config.',
      folderMissing: 'The default folder does not exist; choose one.',
      shapesCount: '{count} shapes',
      pageOf: 'Page {page} of {total}',
      selected: 'Selected #{id}',
      deselect: 'Clear selection',
      unnamed: '(unnamed)',
      preview: 'Live preview',
      lang: 'en',
      stencil: 'Stencil (.vssx)',
      stencilPlaceholder: 'Path to a .vssx',
      stencilHint: 'Load a .vssx/.vstx to insert its masters into the drawing.',
      load: 'Load',
      gridToggle: 'Grid on/off (export follows this)',
      export: 'Export',
      validate: 'Audit',
      validateClean: 'Relationship check passed: no empty links or floating endpoints',
      validateIssues: 'Relationship check: ',
      exportPng: 'Export PNG',
      exported: 'Exported',
      undo: 'Undo',
      redo: 'Redo',
      undoHint: 'Undo last step (Ctrl+Z)',
      shortcutHint: 'Del remove · Ctrl+Z undo · Ctrl+Y redo · right-drag pan',
      redoHint: 'Redo (Ctrl+Shift+Z / Ctrl+Y)',
      zoomIn: 'Zoom in (Ctrl+wheel)',
      zoomOut: 'Zoom out (Ctrl+wheel)',
      zoomFit: 'Fit',
      handTool: 'Hand tool (drag to pan)',
      toggleTree: 'Show or hide the file/shape list',
      toggleInspector: 'Show or hide the inspector',
      floatTip: 'Open the floating Visio canvas (drag and resize)',
      floatTitle: 'Visio drawing · floating canvas',
      floatMove: 'Drag to move',
      floatReset: 'Reset position (Esc closes)',
      floatClose: 'Close window',
      fixUnits: 'Fix units',
      fixUnitsTip: 'Rewrite mislabelled cell units (U=MM/PT) to Visio internal units so page size, font size and line weight match',
      autosave: 'Auto-save',
      externalChanged: 'The file changed elsewhere; preview refreshed',
      opFailed: 'Operation failed',
    }

    /* -------------------------------------------------------------- helpers */

    function apiPath(path) {
      const relative = String(path).replace(/^\/+/, '')
      return new URL(relative, document.baseURI).pathname
    }

    async function getJson(path) {
      const response = await fetch(apiPath(path), {
        headers: { accept: 'application/json' },
        credentials: 'same-origin',
      })
      const payload = await response.json().catch(() => null)
      if (!response.ok) throw new Error(payload?.error ?? `HTTP ${response.status}`)
      return payload
    }

    async function postJson(path, body) {
      const response = await fetch(apiPath(path), {
        method: 'POST',
        headers: { 'content-type': 'application/json', accept: 'application/json' },
        credentials: 'same-origin',
        body: JSON.stringify(body),
      })
      const payload = await response.json().catch(() => null)
      if (!response.ok || payload?.ok === false) {
        throw new Error(payload?.error ?? `HTTP ${response.status}`)
      }
      return payload
    }

    function fmtInches(value) {
      const n = Number(value)
      if (!Number.isFinite(n)) return '0'
      return String(Math.round(n * 1000) / 1000)
    }

    function shapeKindLabel(shape, t) {
      if (shape.connector) return t('connector')
      if (shape.line) return t('lineKind')
      if (!shape.geometry || shape.geometry.length === 0) return t('textShape')
      if (shape.geometry.some((g) => String(g).includes('Ellipse'))) return 'Ellipse'
      if (shape.master) return shape.master
      if (shape.geometry.some((g) => String(g).includes('LineTo'))) return 'Rectangle'
      return t('shape')
    }

    function shapeTitle(shape, t) {
      const text = (shape.text || '').replace(/\s+/g, ' ').trim()
      return text || t('unnamed')
    }

    const SIZES = [
      { id: 'a4l', w: 11.6929, h: 8.2677, label: 'sizeA4L' },
      { id: 'a4p', w: 8.2677, h: 11.6929, label: 'sizeA4P' },
      { id: 'a3l', w: 16.5354, h: 11.6929, label: 'sizeA3L' },
      { id: 'letterl', w: 11, h: 8.5, label: 'sizeLetterL' },
    ]

    /* ------------------------------------------------------------------ CSS */

    const CSS_POLISH = `
/* ---- canvas: block scroller so zooming past the viewport can reach every edge */
.dshv-canvasOuter{min-width:0;overflow:hidden}
.dshv-canvasWrap{display:block;padding:0;overflow:auto;min-width:0;
  scrollbar-gutter:stable;
  background-color:var(--dsw-alias-bg-layer-2);
  background-position:0 0;
  background-attachment:local}
.dshv-canvasWrap::-webkit-scrollbar{width:12px;height:12px}
.dshv-canvasWrap::-webkit-scrollbar-thumb{background:var(--dsw-alias-border-l2);border-radius:6px;border:3px solid transparent;background-clip:content-box}
.dshv-canvasInner{display:flex;align-items:flex-start;justify-content:center;
  width:max-content;height:max-content;min-width:100%;min-height:100%;
  /* bottom room for the floating zoom bar: without it the bar sits on the page
     edge and can cover a connector handle near the bottom */
  padding:24px 24px 76px;box-sizing:border-box}
.dshv-page svg{overflow:visible}
/* One continuous grid over the whole scrollable workspace.  It is inside the
   scrolling content (so it pans with the shapes) and behind the page (so it
   shows through the transparent page).  5000px is a multiple of every grid size
   we emit, which puts a cell boundary exactly on the page's SVG origin. */
.dshv-gridLayer{position:absolute;pointer-events:none;z-index:0}
.dshv-page{position:relative;z-index:1}
/* The svg sits above the grid: opaque shape fills hide the grid, empty paper
   shows it through.  Without this the grid painted OVER every node. */
.dshv-svgHost{position:relative;z-index:2}
.dshv-page{margin:0 auto;max-width:none;box-shadow:0 8px 26px rgba(0,0,0,.16);border-radius:2px;background:transparent}

/* ---- header */
.dshv-head{padding:10px 16px;background:var(--dsw-alias-bg-layer-1);border-bottom:1px solid var(--dsw-alias-border-l2)}
.dshv-title{font-size:14px;font-weight:650;letter-spacing:.01em}
.dshv-sub{font-size:11.5px;color:var(--dsw-alias-label-secondary);margin-top:2px}
.dshv-actions{gap:8px;align-items:center}

/* ---- buttons */
.dshv-btn{height:30px;padding:0 12px;border-radius:7px;font-size:12.5px;font-weight:500;
  border-color:var(--dsw-alias-border-l2);background:var(--dsw-alias-bg-base);transition:background .12s,border-color .12s}
.dshv-btn:hover{background:var(--dsw-alias-bg-layer-2);border-color:var(--dsw-alias-brand-primary)}
.dshv-btn.ghost{color:var(--dsw-alias-label-secondary)}
.dshv-btn.ghost:hover{color:var(--dsw-alias-label-primary)}
.dshv-btn.primary{background:var(--dsw-alias-brand-primary);color:#fff;font-weight:600;box-shadow:0 1px 2px rgba(0,0,0,.12)}
.dshv-btn.small{height:26px;padding:0 9px;font-size:12px}

/* ---- panes */
.dshv-left{width:246px;flex:0 0 246px;background:var(--dsw-alias-bg-layer-1);border-right:1px solid var(--dsw-alias-border-l2)}
.dshv-right{width:308px;flex:0 0 308px;background:var(--dsw-alias-bg-layer-1);border-left:1px solid var(--dsw-alias-border-l2)}
.dshv-section{padding:12px 14px;border-bottom:1px solid var(--dsw-alias-border-l1)}
.dshv-sectionTitle{font-size:10.5px;letter-spacing:.08em;color:var(--dsw-alias-label-secondary);margin-bottom:8px}
.dshv-hint{font-size:11px;color:var(--dsw-alias-label-secondary);line-height:1.5}

/* ---- tabs + list */
.dshv-tabs{gap:2px;padding:6px 8px 0;border-bottom:1px solid var(--dsw-alias-border-l1)}
.dshv-tab{height:26px;padding:0 10px;border-radius:6px 6px 0 0;font-size:12px;color:var(--dsw-alias-label-secondary)}
.dshv-tab.active{color:var(--dsw-alias-label-primary);background:var(--dsw-alias-bg-base);border:1px solid var(--dsw-alias-border-l1);border-bottom-color:transparent}
.dshv-file{padding:6px 10px;border-radius:6px;margin:2px 6px;cursor:pointer}
.dshv-file:hover{background:var(--dsw-alias-bg-layer-2)}
.dshv-file.active{background:var(--dsw-alias-brand-primary);color:#fff}
.dshv-file.active .dshv-fileMeta{color:rgba(255,255,255,.8)}

/* ---- inputs */
.dshv-input{height:28px;border-radius:6px;border-color:var(--dsw-alias-border-l2);background:var(--dsw-alias-bg-base);font-size:12.5px}
.dshv-input:focus{outline:2px solid var(--dsw-alias-brand-primary);outline-offset:-1px}

/* ---- zoom toolbar */
.dshv-zoom{right:16px;bottom:16px;gap:2px;padding:4px;border-radius:11px;background:var(--dsw-alias-bg-base);
  border:1px solid var(--dsw-alias-border-l2);box-shadow:0 6px 20px rgba(0,0,0,.18)}
.dshv-zbtn{min-width:32px;height:30px;border-radius:7px;font-size:15px;font-weight:600;color:var(--dsw-alias-label-primary)}
.dshv-zbtn:hover{background:var(--dsw-alias-bg-layer-2)}
.dshv-zfit{min-width:64px;font-size:12px;font-weight:600;font-variant-numeric:tabular-nums;letter-spacing:.02em}
.dshv-zbtn.on{background:var(--dsw-alias-brand-primary);color:#fff}
.dshv-toggle{width:30px;height:30px;font-size:14px;border-color:var(--dsw-alias-border-l2);background:var(--dsw-alias-bg-base)}
.dshv-toggle.on{background:var(--dsw-alias-bg-layer-2);color:var(--dsw-alias-label-primary);border-color:var(--dsw-alias-border-l2)}
`

    const CSS = `
.dshv-root{display:flex;flex-direction:column;height:100%;min-height:0;background:var(--dsw-alias-bg-base);color:var(--dsw-alias-label-primary);outline:none;
  font-family:system-ui,-apple-system,"Segoe UI","Microsoft YaHei",sans-serif;font-size:13px;line-height:1.45}
.dshv-head{display:flex;align-items:center;gap:10px;padding:12px 16px 10px;border-bottom:1px solid var(--dsw-alias-border-l1);flex:0 0 auto}
.dshv-headText{min-width:0;flex:1}
.dshv-title{font-size:15px;font-weight:600;letter-spacing:.01em;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.dshv-sub{font-size:12px;color:var(--dsw-alias-label-secondary);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.dshv-actions{display:flex;align-items:center;gap:6px;flex:0 0 auto}
.dshv-btn{display:inline-flex;align-items:center;gap:6px;height:28px;padding:0 10px;border-radius:6px;border:1px solid var(--dsw-alias-border-l2);
  background:var(--dsw-alias-bg-layer-1);color:var(--dsw-alias-label-primary);font:inherit;font-size:12px;cursor:pointer;white-space:nowrap}
.dshv-btn:hover{background:var(--dsw-alias-bg-layer-2)}
.dshv-btn:disabled{opacity:.5;cursor:default}
.dshv-btn.primary{background:var(--dsw-alias-brand-primary);border-color:transparent;color:#fff}
.dshv-btn.primary:hover{filter:brightness(1.06)}
.dshv-btn.ghost{border-color:transparent;background:transparent}
.dshv-btn.ghost:hover{background:var(--dsw-alias-bg-layer-2)}
.dshv-btn.danger{color:var(--dsw-alias-state-error-primary);border-color:var(--dsw-alias-border-l2)}
.dshv-btn.small{height:24px;padding:0 8px;font-size:11px}
.dshv-body{flex:1;display:flex;min-height:0}
.dshv-pane{display:flex;flex-direction:column;min-height:0;background:var(--dsw-alias-bg-base)}
.dshv-pane.dshv-left{overflow-y:auto;overflow-x:hidden}
.dshv-pane.dshv-left>*{flex:0 0 auto}
.dshv-pane.dshv-left .dshv-shapeList{flex:0 0 auto;max-height:34vh}
.dshv-pane.dshv-left .dshv-files{flex:0 0 auto}
.dshv-tabs{flex:0 0 auto;min-height:34px}
.dshv-tab{white-space:nowrap}
.dshv-left{width:238px;flex:0 0 238px;border-right:1px solid var(--dsw-alias-border-l1)}
.dshv-right{width:300px;flex:0 0 300px;border-left:1px solid var(--dsw-alias-border-l1);overflow:auto}
.dshv-center{flex:1;min-width:0;display:flex;flex-direction:column;background:var(--dsw-alias-bg-layer-2)}
.dshv-section{padding:10px 12px;border-bottom:1px solid var(--dsw-alias-border-l1)}
.dshv-sectionTitle{display:flex;align-items:center;justify-content:space-between;font-size:11px;font-weight:600;letter-spacing:.06em;
  text-transform:uppercase;color:var(--dsw-alias-label-secondary);margin-bottom:6px}
.dshv-field{display:flex;align-items:center;gap:6px;margin-bottom:6px}
.dshv-field label{flex:0 0 62px;font-size:12px;color:var(--dsw-alias-label-secondary)}
.dshv-input{flex:1;min-width:0;height:26px;padding:0 7px;border-radius:5px;border:1px solid var(--dsw-alias-border-l1);
  background:var(--dsw-alias-bg-layer-1);color:var(--dsw-alias-label-primary);font:inherit;font-size:12px}
.dshv-input:focus{outline:none;border-color:var(--dsw-alias-brand-primary)}
textarea.dshv-input{width:100%;box-sizing:border-box;height:auto;min-height:74px;padding:7px 8px;resize:vertical;line-height:1.5}
.dshv-check{display:flex;align-items:center;gap:6px;font-size:12px;margin-bottom:6px;cursor:pointer}
.dshv-check input{accent-color:var(--dsw-alias-brand-primary)}
.dshv-miniLabel{font-size:11px;color:var(--dsw-alias-label-secondary);min-width:56px}
.dshv-routeRow{display:flex;flex-wrap:wrap;gap:4px;margin-bottom:4px}
.dshv-warn{display:flex;align-items:center;gap:8px;margin-top:6px;font-size:12px;color:var(--dsw-alias-state-error)}
.dshv-row{display:flex;gap:6px;align-items:center}
.dshv-grid4{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:6px;align-items:end}
.dshv-col{min-width:0;flex:1 1 0}
.dshv-col .dshv-input{width:100%;box-sizing:border-box}
.dshv-col{flex:1;min-width:0}
.dshv-grow{flex:1}
.dshv-hint{font-size:11px;color:var(--dsw-alias-label-secondary);line-height:1.5}
.dshv-files{overflow:auto;flex:1;min-height:0}
.dshv-file{display:flex;align-items:center;gap:8px;padding:6px 12px;cursor:pointer;border-left:2px solid transparent}
.dshv-file:hover{background:var(--dsw-alias-bg-layer-2)}
.dshv-file.active{border-left-color:var(--dsw-alias-brand-primary);background:var(--dsw-alias-bg-layer-2)}
.dshv-fileName{flex:1;min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-size:12px}
.dshv-fileMeta{font-size:10px;color:var(--dsw-alias-label-secondary)}
.dshv-shapeList{overflow:auto;flex:1;min-height:0}
.dshv-shapeRow{display:flex;align-items:center;gap:8px;padding:5px 12px;cursor:pointer;border-left:2px solid transparent}
.dshv-shapeRow:hover{background:var(--dsw-alias-bg-layer-2)}
.dshv-shapeRow.active{border-left-color:var(--dsw-alias-brand-primary);background:var(--dsw-alias-bg-layer-2)}
.dshv-shapeId{font:11px ui-monospace,Consolas,monospace;color:var(--dsw-alias-label-secondary);flex:0 0 24px}
.dshv-shapeText{flex:1;min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.dshv-shapeKind{font-size:10px;color:var(--dsw-alias-label-secondary);flex:0 0 auto}
.dshv-canvasOuter{position:relative;flex:1;min-height:0;min-width:0;display:flex;
  flex-direction:column;overflow:hidden}
.dshv-canvasWrap{flex:1;min-height:0;min-width:0;overflow:auto;padding:20px;display:flex;justify-content:center;align-items:center;position:relative}
.dshv-page{position:relative;background:transparent;box-shadow:0 8px 26px rgba(0,0,0,.16);border-radius:2px;max-width:100%}
.dshv-page svg{display:block;width:100%;height:auto}
.dshv-page [data-shape-id]{cursor:pointer}
.dshv-page [data-shape-id]:hover>*:first-child{stroke:var(--dsw-alias-brand-primary);stroke-width:.024}
.dshv-page [data-shape-id]:hover>rect[fill="transparent"]{stroke:none}
.dshv-overlay{position:absolute;inset:0;width:100%;height:100%;pointer-events:none;overflow:visible}
.dshv-empty{flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:10px;padding:40px;text-align:center;color:var(--dsw-alias-label-secondary)}
.dshv-empty h2{margin:0;font-size:16px;color:var(--dsw-alias-label-primary)}
.dshv-empty p{margin:0;max-width:380px;font-size:12px;line-height:1.6}
.dshv-badge{display:inline-flex;align-items:center;gap:4px;height:18px;padding:0 6px;border-radius:9px;font-size:10px;
  background:var(--dsw-alias-bg-layer-2);color:var(--dsw-alias-label-secondary)}
.dshv-status{flex:0 0 auto;display:flex;align-items:center;gap:10px;padding:5px 14px;border-top:1px solid var(--dsw-alias-border-l1);
  font-size:11px;color:var(--dsw-alias-label-secondary);background:var(--dsw-alias-bg-base);min-height:28px}
.dshv-status .err{color:var(--dsw-alias-state-error-primary)}
.dshv-status .dshv-ver{font-size:10.5px;color:var(--dsw-alias-label-secondary);opacity:.75}
.dshv-status .ok{color:var(--dsw-alias-state-success-primary)}
.dshv-spinner{width:11px;height:11px;border-radius:50%;border:2px solid var(--dsw-alias-border-l2);border-top-color:var(--dsw-alias-brand-primary);
  animation:dshv-spin .8s linear infinite;display:inline-block}
@keyframes dshv-spin{to{transform:rotate(360deg)}}
.dshv-overlayDialog{position:absolute;inset:0;background:rgba(0,0,0,.35);display:flex;align-items:center;justify-content:center;z-index:20}
.dshv-dialog{width:420px;max-width:calc(100% - 40px);background:var(--dsw-alias-bg-overlay);border:1px solid var(--dsw-alias-border-l1);
  border-radius:10px;box-shadow:0 12px 36px rgba(0,0,0,.3);padding:16px 18px}
.dshv-dialog h3{margin:0 0 12px;font-size:14px}
.dshv-dialog .dshv-field label{flex-basis:76px}
.dshv-dialogActions{display:flex;justify-content:flex-end;gap:8px;margin-top:14px}
.dshv-swatch{width:26px;height:24px;padding:0;border:1px solid var(--dsw-alias-border-l1);border-radius:5px;background:none;cursor:pointer}
.dshv-propRow{display:flex;gap:6px;align-items:center;margin-bottom:5px}
.dshv-propName{flex:0 0 96px;font-size:11px;color:var(--dsw-alias-label-secondary);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.dshv-tabs{display:flex;gap:2px;padding:8px 10px 0;border-bottom:1px solid var(--dsw-alias-border-l1)}
.dshv-tab{flex:1;height:26px;border:none;border-bottom:2px solid transparent;background:none;color:var(--dsw-alias-label-secondary);
  font:inherit;font-size:12px;cursor:pointer}
.dshv-tab.active{color:var(--dsw-alias-label-primary);border-bottom-color:var(--dsw-alias-brand-primary)}
`

    /* -------------------------------------------------------------- widgets */

    function Btn(props) {
      const { variant, small, children, ...rest } = props
      const cls = ['dshv-btn']
      if (variant) cls.push(variant)
      if (small) cls.push('small')
      return h('button', { type: 'button', ...rest, className: cls.join(' ') }, children)
    }

    function Field(props) {
      const { label, children } = props
      return h('div', { className: 'dshv-field' }, h('label', null, label), children)
    }

    /** Number input that only commits on blur / Enter. */
    function NumberField({ label, value, onCommit, step = 0.05 }) {
      const [draft, setDraft] = useState(fmtInches(value))
      const [focused, setFocused] = useState(false)
      useEffect(() => {
        if (!focused) setDraft(fmtInches(value))
      }, [value, focused])
      const commit = () => {
        const raw = String(draft).trim().replace(',', '.')
        const n = Number(raw)
        if (raw === '' || !Number.isFinite(n)) {
          setDraft(fmtInches(value))
          return
        }
        if (fmtInches(n) !== fmtInches(value)) onCommit(n)
        else setDraft(fmtInches(n))
      }
      return h('div', { className: 'dshv-col' },
        h('div', { style: { fontSize: 10, color: 'var(--dsw-alias-label-secondary)', marginBottom: 2 } }, label),
        h('input', {
          className: 'dshv-input',
          type: 'number',
          step,
          value: draft,
          onChange: (e) => setDraft(e.target.value),
          onFocus: () => setFocused(true),
          onBlur: () => { setFocused(false); commit() },
          onKeyDown: (e) => { if (e.key === 'Enter') e.currentTarget.blur() },
        }))
    }

    function ColorField({ label, value, onCommit }) {
      const hex = /^#[0-9a-fA-F]{6}$/.test(String(value ?? '')) ? String(value) : '#FFFFFF'
      const [draft, setDraft] = useState(hex)
      const timer = useRef(null)
      useEffect(() => { setDraft(hex) }, [hex])
      const change = (next) => {
        setDraft(next)
        if (timer.current) clearTimeout(timer.current)
        timer.current = setTimeout(() => onCommit(next), 250)
      }
      useEffect(() => () => { if (timer.current) clearTimeout(timer.current) }, [])
      return h(Field, { label },
        h('input', { className: 'dshv-swatch', type: 'color', value: draft, onChange: (e) => change(e.target.value) }),
        h('input', {
          className: 'dshv-input',
          value: draft,
          onChange: (e) => {
            const next = e.target.value
            setDraft(next)
            if (/^#[0-9a-fA-F]{6}$/.test(next)) change(next)
          },
          onBlur: () => { if (!/^#[0-9a-fA-F]{6}$/.test(draft)) setDraft(hex) },
        }))
    }

    function Icon(props) {
      const { size = 16 } = props
      return h('svg', {
        width: size,
        height: size,
        viewBox: '0 0 24 24',
        fill: 'none',
        stroke: 'currentColor',
        strokeWidth: 1.7,
        strokeLinejoin: 'round',
        strokeLinecap: 'round',
        'aria-hidden': 'true',
      },
      h('rect', { x: 3.2, y: 3.2, width: 7.6, height: 5.6, rx: 1.2 }),
      h('rect', { x: 13.2, y: 15.2, width: 7.6, height: 5.6, rx: 1.2 }),
      h('path', { d: 'M6.8 8.9v4.1h10.4v2.2' }),
      h('path', { d: 'M17.2 13.2l1.9 2 1.9-2' }))
    }

    function VisioIcon({ size }) {
      return h('span', { style: { display: 'inline-flex' } }, h(Icon, { size: size ?? 16 }))
    }

  /* ----------------------------------------------------------------- panel */

    function withSelection(svg, shape, pageHeight) {
      // A line is a 1-D shape: it gets two end dots and nothing else.  Drawing the
      // usual dashed box plus eight scale handles around it was the giveaway that a
      // line was being treated as a rectangle with a diagonal inside.
      if (svg && shape && shape.line && shape.bbox) {
        const pts = (shape.points && shape.points.length >= 2) ? shape.points
          : [[shape.bbox.x, shape.bbox.y], [shape.bbox.x + shape.bbox.w, shape.bbox.y + shape.bbox.h]]
        const [ax, ay] = pts[0]
        const [bx, by] = pts[pts.length - 1]
        let handles = ''
        handles += '<line x1="' + ax + '" y1="' + (pageHeight - ay) + '" x2="' + bx + '" y2="' + (pageHeight - by) + '"'
          + ' stroke="transparent" stroke-width="14" vector-effect="non-scaling-stroke"'
          + ' data-line-body="' + shape.id + '" style="cursor:move" pointer-events="stroke"/>'
        for (const [tag, pt] of [['start', [ax, ay]], ['end', [bx, by]]]) {
          handles += '<g data-line-end="' + shape.id + '" data-end="' + tag + '" style="cursor:crosshair">'
            + '<circle cx="' + pt[0] + '" cy="' + (pageHeight - pt[1]) + '" r="0.1"'
            + ' fill="#2F6FBF" fill-opacity="0.95" stroke="#FFFFFF" stroke-width="2"'
            + ' vector-effect="non-scaling-stroke"/></g>'
        }
        // a short tick at the middle so a selected line is obvious
        handles += '<circle cx="' + ((ax + bx) / 2) + '" cy="' + (pageHeight - (ay + by) / 2) + '" r="0.05"'
          + ' fill="#2F6FBF" fill-opacity="0.6" pointer-events="none"/>'
        const cut = svg.lastIndexOf('</svg>')
        if (cut < 0) return svg
        return svg.slice(0, cut) + handles + svg.slice(cut)
      }
      // Connector bounding boxes span their endpoints; a box around them would
      // cover half the page.  They get a stroke highlight instead (see CSS).
      if (svg && shape && shape.connector && shape.bbox) {
        // one handle per run, drawn at the run's middle: dragging it slides that run
        const pts = (shape.points && shape.points.length >= 2)
          ? shape.points
          : [[shape.bbox.x, shape.bbox.y], [shape.bbox.x + shape.bbox.w, shape.bbox.y + shape.bbox.h]]
        let handles = ''
        // a fat invisible band over the whole line: grabbing the line itself moves the
        // whole run, which is what people try first
        let band = ''
        for (let i = 0; i < pts.length - 1; i += 1) {
          const [ax, ay] = pts[i]
          const [bx, by] = pts[i + 1]
          band += '<line x1="' + ax + '" y1="' + (pageHeight - ay) + '" x2="' + bx + '" y2="' + (pageHeight - by) + '"'
            + ' stroke="transparent" stroke-width="14" vector-effect="non-scaling-stroke"'
            + ' data-route-band="' + shape.id + '" data-seg="' + i + '"'
            // pointer-events must be an attribute, not a CSS property: a style= rule
            // with a transparent stroke would otherwise make the band invisible to
            // hit-testing, and the line itself could not be grabbed.
            + ' style="cursor:move" pointer-events="stroke"/>'
        }
        handles += band
        // the two ends: dragging one re-glues that end to the nearest shape
        for (const [tag, idx] of [['start', 0], ['end', pts.length - 1]]) {
          const [ex, ey] = pts[idx]
          // an end handle must stay visible at any zoom, so its outline is drawn in
          // screen pixels and it is bigger than the segment dots
          // A connector end is a point, not a box: a round dot says "grab me and
          // drop me on a port", a square reads like a shape handle.
          handles += '<g data-route-end="' + shape.id + '" data-end="' + tag + '" style="cursor:pointer">'
            + '<circle cx="' + ex + '" cy="' + (pageHeight - ey) + '" r="0.115"'
            + ' fill="#E5484D" fill-opacity="0.95" stroke="#FFFFFF" stroke-width="2"'
            + ' vector-effect="non-scaling-stroke"/></g>'
        }
        for (let i = 0; i < pts.length - 1; i += 1) {
          const [ax, ay] = pts[i]
          const [bx, by] = pts[i + 1]
          const run = Math.hypot(bx - ax, by - ay)
          // Three handles on a short run leave no room to grab the line itself:
          // the two red ends plus this blue dot cover the whole band, so any
          // drag on the line silently became a segment adjustment.  Only draw
          // the dot when there is a real stretch of line left to grab; segment
          // adjustment stays available on long runs and via the inspector.
          if (run < 0.5) continue
          const mx = (ax + bx) / 2
          const my = (ay + by) / 2
          const vertical = Math.abs(bx - ax) < Math.abs(by - ay)
          handles += '<g data-route-handle="' + shape.id + '" data-seg="' + i + '"'
            + ' data-axis="' + (vertical ? 'x' : 'y') + '" style="cursor:' + (vertical ? 'ew-resize' : 'ns-resize') + '">'
            + '<circle cx="' + mx + '" cy="' + (pageHeight - my) + '" r="0.105"'
            + ' fill="#2F6FBF" fill-opacity="0.9" stroke="#FFFFFF" stroke-width="2"'
            + ' vector-effect="non-scaling-stroke"/></g>'
        }
        // must go *inside* the svg element, otherwise the browser never renders it
        const close = svg.lastIndexOf('</svg>')
        if (close < 0) return svg
        return svg.slice(0, close) + handles + svg.slice(close)
      }
      if (!svg || !shape || !shape.bbox || shape.connector) return svg
      const box = shape.bbox
      const rect = '<rect x="' + box.x + '" y="' + (pageHeight - box.y - box.h).toFixed(4)
        + '" width="' + box.w + '" height="' + box.h
        + '" fill="none" stroke="#2F6FBF" stroke-width="1.6" vector-effect="non-scaling-stroke"'
        + ' stroke-dasharray="5 3" pointer-events="none"/>'
      // Guide arrows on the four sides: click = connect to an aligned neighbour,
      // or duplicate in that direction when nothing is there yet.
      const cx = box.x + box.w / 2
      const cy = box.y + box.h / 2
      const top = pageHeight - box.y - box.h
      const gap = 0.30
      const arm = 0.30
      const guides = [
        { dir: 'left', x: box.x - gap, y: top + box.h / 2, dx: -arm, dy: 0 },
        { dir: 'right', x: box.x + box.w + gap, y: top + box.h / 2, dx: arm, dy: 0 },
        { dir: 'up', x: cx, y: top - gap, dx: 0, dy: -arm },
        { dir: 'down', x: cx, y: top + box.h + gap, dx: 0, dy: arm },
      ].map((g) => {
        const tip = 'M ' + g.x + ' ' + g.y + ' L ' + (g.x - g.dx) + ' ' + (g.y - g.dy)
        const a = 'M ' + g.x + ' ' + g.y + ' L ' + (g.x - g.dx * 0.45 - g.dy * 0.32) + ' ' + (g.y - g.dy * 0.45 - g.dx * 0.32)
        const b = 'M ' + g.x + ' ' + g.y + ' L ' + (g.x - g.dx * 0.45 + g.dy * 0.32) + ' ' + (g.y - g.dy * 0.45 + g.dx * 0.32)
        return '<g data-guide="' + g.dir + '" data-guide-shape="' + shape.id + '" style="cursor:pointer">'
          + '<circle cx="' + g.x + '" cy="' + g.y + '" r="0.16" fill="#FFFFFF" fill-opacity="0.9" stroke="#8A94A6" stroke-width="1" vector-effect="non-scaling-stroke"/>'
          + '<path d="' + tip + '" stroke="#8A94A6" stroke-width="1.4" vector-effect="non-scaling-stroke" fill="none"/>'
          + '<path d="' + a + '" stroke="#8A94A6" stroke-width="1.2" vector-effect="non-scaling-stroke" fill="none"/>'
          + '<path d="' + b + '" stroke="#8A94A6" stroke-width="1.2" vector-effect="non-scaling-stroke" fill="none"/>'
          + '</g>'
      }).join('')
      // Eight scale handles plus one rotate handle: without them a shape could only
      // be moved and resized through the numeric fields on the right.
      const midX = box.x + box.w / 2
      const midY = top + box.h / 2
      const corner = (dir, hx, hy, cursor) => '<g data-resize="' + shape.id + ':' + dir + '" style="cursor:' + cursor + '">'
        + '<rect x="' + (hx - 0.05) + '" y="' + (hy - 0.05) + '" width="0.1" height="0.1"'
        + ' fill="#FFFFFF" stroke="#2F6FBF" stroke-width="1.5" vector-effect="non-scaling-stroke"/></g>'
      const handles = [
        corner('nw', box.x, top, 'nwse-resize'),
        corner('n', midX, top, 'ns-resize'),
        corner('ne', box.x + box.w, top, 'nesw-resize'),
        corner('w', box.x, midY, 'ew-resize'),
        corner('e', box.x + box.w, midY, 'ew-resize'),
        corner('sw', box.x, top + box.h, 'nesw-resize'),
        corner('s', midX, top + box.h, 'ns-resize'),
        corner('se', box.x + box.w, top + box.h, 'nwse-resize'),
        // rotate handle hangs off the top edge, on a short stem
        '<line x1="' + midX + '" y1="' + (top - 0.06) + '" x2="' + midX + '" y2="' + (top - 0.56) + '"'
        + ' stroke="#2F6FBF" stroke-width="1" vector-effect="non-scaling-stroke" pointer-events="none"/>',
        '<g data-rotate="' + shape.id + '" style="cursor:grab">'
        + '<circle cx="' + midX + '" cy="' + (top - 0.62) + '" r="0.085" fill="#FFFFFF"'
        + ' stroke="#2F6FBF" stroke-width="1.5" vector-effect="non-scaling-stroke"/></g>',
      ].join('')
      // Draw the overlay OUTSIDE the shape's own group and apply the rotation
      // ourselves.  Appending it inside the group looked right only while the
      // group actually carried the transform: for a rotated ellipse the dashed
      // box stayed on the unrotated bbox and the handles sat off the shape.
      const ang = Number(shape.angle) || 0
      const gcx = box.x + box.w / 2
      const gcy = pageHeight - (box.y + box.h / 2)
      const open = ang ? '<g transform="rotate(' + (-ang).toFixed(4) + ' ' + gcx.toFixed(4) + ' ' + gcy.toFixed(4) + ')">' : '<g>'
      const cut = svg.lastIndexOf('</svg>')
      if (cut < 0) return svg
      return svg.slice(0, cut) + open + rect + guides + handles + '</g>' + svg.slice(cut)
    }

    const LAST_DOC = 'dshv:lastDoc'

    const SHAPE_KINDS = [
      { kind: 'rect', glyph: '\u25AD', zh: '矩形', en: 'Process' },
      { kind: 'roundrect', glyph: '\u25A2', zh: '圆角', en: 'Rounded' },
      { kind: 'terminator', glyph: '\u2B2D', zh: '端点', en: 'Terminator' },
      { kind: 'ellipse', glyph: '\u25CB', zh: '椭圆', en: 'Ellipse' },
      { kind: 'diamond', glyph: '\u25C7', zh: '判定', en: 'Decision' },
      { kind: 'triangle', glyph: '\u25B3', zh: '三角', en: 'Triangle' },
      { kind: 'parallelogram', glyph: '\u25B1', zh: '数据', en: 'Data' },
      { kind: 'trapezoid', glyph: '\u23E2', zh: '梯形', en: 'Trapezoid' },
      { kind: 'hexagon', glyph: '\u2B21', zh: '六边形', en: 'Hexagon' },
      { kind: 'chevron', glyph: '\u276F', zh: '燕尾', en: 'Chevron' },
      { kind: 'arrow_right', glyph: '\u2794', zh: '右箭头', en: 'Arrow right' },
      { kind: 'arrow_left', glyph: '\u2B05', zh: '左箭头', en: 'Arrow left' },
      { kind: 'arrow_up', glyph: '\u2B06', zh: '上箭头', en: 'Arrow up' },
      { kind: 'arrow_down', glyph: '\u2B07', zh: '下箭头', en: 'Arrow down' },
      { kind: 'text', glyph: 'T', zh: '文本', en: 'Text' },
      { kind: 'line', glyph: '\u2571', zh: '直线', en: 'Line' },
    ]

    function VisioPanel(props) {
      const { t, pickFolder } = props
      const [config, setConfig] = useState(null)
      const [configError, setConfigError] = useState('')
      const [folder, setFolder] = useState(() => {
        try { return window.localStorage.getItem('dsh-visio.folder') || '' } catch (err) { return '' }
      })
      const [folderDraft, setFolderDraft] = useState('')
      const [files, setFiles] = useState([])
      const [filesBusy, setFilesBusy] = useState(false)
      const [filesError, setFilesError] = useState('')
      const [doc, setDoc] = useState(null)
      const [selected, setSelected] = useState(null)
      const [busy, setBusy] = useState(false)
      const [error, setError] = useState('')
      const [notice, setNotice] = useState('')
      const [tab, setTab] = useState('shapes')
      const [showGrid, setShowGrid] = useState(true)
      const [stencilOpen, setStencilOpen] = useState(false)
      const [createOpen, setCreateOpen] = useState(false)
      const [treeOpen, setTreeOpen] = useState(true)
      const [inspectorOpen, setInspectorOpen] = useState(true)
      const [pane, setPane] = useState({ w: 0, h: 0 })
      const isZh = t('lang') === 'zh'
      const [stencilPath, setStencilPath] = useState('')
      const [stencilFile, setStencilFile] = useState('')
      const [stencilMasters, setStencilMasters] = useState([])
      const [stencilError, setStencilError] = useState('')
      const [zoom, setZoom] = useState(null)
      const [tool, setTool] = useState('select')
      const [linkFrom, setLinkFrom] = useState(null)
      const toolRef = useRef('select')
      toolRef.current = tool
      const pageRef = useRef(null)
      const panRef = useRef(null)
      const tipRef = useRef(null)
      const rootRef = useRef(null)
      const canvasBox = useRef(null)
      useEffect(() => {
        // Measure the outer frame, never the scroller: its content box shrinks
        // when a scrollbar appears, which would feed back into the fit size.
        const node = canvasBox.current && (canvasBox.current.parentElement || canvasBox.current)
        if (!node || typeof ResizeObserver === 'undefined') return undefined
        const observer = new ResizeObserver((entries) => {
          const rect = entries[0].contentRect
          const w = Math.round(rect.width)
          const h = Math.round(rect.height)
          // A scrollbar appearing/disappearing must not re-fit the page, or the
          // layout oscillates: fit -> overflow -> scrollbar -> smaller fit -> ...
          setPane((prev) => (Math.abs(prev.w - w) < 2 && Math.abs(prev.h - h) < 2 ? prev : { w, h }))
        })
        observer.observe(node)
        return () => observer.disconnect()
      }, [doc])

      useEffect(() => {
        const wrap = canvasBox.current
        if (!wrap) return undefined
        const onWheel = (event) => {
          const hand = toolRef.current === 'hand'
          if (!event.ctrlKey && !event.metaKey && !hand) return
          event.preventDefault()
          const page = pageRef.current
          const before = page ? page.getBoundingClientRect() : null
          const fx = before && before.width ? (event.clientX - before.left) / before.width : 0.5
          const fy = before && before.height ? (event.clientY - before.top) / before.height : 0.5
          setZoom((value) => {
            const base = value ?? 1
            const next = Math.min(8, Math.max(0.15, base * (event.deltaY > 0 ? 0.9 : 1.1)))
            return Math.round(next * 1000) / 1000
          })
          if (before) {
            requestAnimationFrame(() => {
              const after = pageRef.current
              if (!after) return
              const rect = after.getBoundingClientRect()
              wrap.scrollLeft += rect.left + fx * rect.width - event.clientX
              wrap.scrollTop += rect.top + fy * rect.height - event.clientY
            })
          }
        }
        wrap.addEventListener('wheel', onWheel, { passive: false })
        return () => wrap.removeEventListener('wheel', onWheel)
      }, [doc])
      const seqRef = useRef(0)
      const docRef = useRef(null)
      const selectedRef = useRef(null)
      useEffect(() => { docRef.current = doc }, [doc])
      useEffect(() => { selectedRef.current = selected }, [selected])

      const runOp = useCallback(async (payload, options = {}) => {
        const seq = ++seqRef.current
        if (!options.quiet) setBusy(true)
        setError('')
        try {
        try { window.__lastPayload = payload } catch (e) {}
          const state = await postJson(`${ROUTE}/op`, payload)
          if (seq !== seqRef.current) return null
          if (options.light && state && state.svg === undefined) {
            setDoc((prev) => (prev ? {
              ...prev,
              mtime: state.mtime ?? prev.mtime,
              canUndo: state.canUndo ?? prev.canUndo,
              canRedo: state.canRedo ?? prev.canRedo,
              saved: true,
            } : prev))
            setNotice(state.notice || '')
            return state
          }
          setDoc(state)
          setNotice(state.notice || options.notice || '')
          if (state.detail) setSelected(state.detail.id)
          else if (payload.action === 'delete') setSelected(null)
          return state
        } catch (err) {
          if (seq === seqRef.current) setError(err instanceof Error ? err.message : String(err))
          return null
        } finally {
          if (seq === seqRef.current) setBusy(false)
        }
      }, [])

      const undoTo = useCallback((action) => {
        const current = docRef.current
        if (!current) return
        runOp({ action, path: current.path, page: current.page })
      }, [runOp])

      const endDirection = useCallback((end, direction) => {
        const current = docRef.current
        if (!current || !selectedRef.current) return
        runOp({ action: 'set_end_direction', path: current.path, page: current.page,
          shape_id: selectedRef.current, end, direction })
      }, [runOp])


      const loadFolder = useCallback(async (target) => {
        if (!target) return
        setFilesBusy(true)
        setFilesError('')
        try {
          const result = await postJson(`${ROUTE}/op`, { action: 'list', dir: target })
          setFiles(result.files || [])
          const next = result.dir || target
          setFolder(next)
          try { window.localStorage.setItem('dsh-visio.folder', next) } catch (err) { /* ignore */ }
          setFolderDraft(result.dir || target)
          try { window.localStorage.setItem('dsh-visio.folder', result.dir || target) } catch { /* ignore */ }
        } catch (err) {
          setFiles([])
          setFilesError(err instanceof Error ? err.message : String(err))
        } finally {
          setFilesBusy(false)
        }
      }, [])

      useEffect(() => {
        let cancelled = false
        ;(async () => {
          try {
            const result = await getJson(`${ROUTE}/config`)
            if (cancelled) return
            setConfig(result)
            let last = result.defaultFolder
            try { last = window.localStorage.getItem('dsh-visio.folder') || last } catch { /* ignore */ }
            setFolderDraft(last || '')
            if (last) await loadFolder(last)
          } catch (err) {
            if (!cancelled) setConfigError(err instanceof Error ? err.message : String(err))
          }
        })()
        return () => { cancelled = true }
      }, [loadFolder])

      const openFile = useCallback(async (path, page) => {
        try { window.localStorage.setItem(LAST_DOC, path) } catch (err) { /* ignore */ }
        setSelected(null)
        const state = await runOp({ action: 'open', path, page: page ?? 1 })
        if (state) {
          setDoc(state)
          try { window.localStorage.setItem('dsh-visio.folder', state.folder) } catch { /* ignore */ }
          if (state.folder !== folder) setFolder(state.folder)
        }
        return state
      }, [runOp, folder])

      const openSelected = useCallback(async (shapeId, page) => {
        const current = docRef.current
        if (!current) return
        setSelected(shapeId)
        const state = await runOp({ action: 'render', path: current.path, page: page ?? current.page, selected: shapeId }, { quiet: true })
        if (state) setDoc(state)
      }, [runOp])

      // Another panel instance (the floating window) starts empty: reopen the
      // drawing this profile last had open, so both windows show the same file.
      useEffect(() => {
        if (doc) return
        let last = ''
        try { last = window.localStorage.getItem(LAST_DOC) || '' } catch (err) { last = '' }
        if (last) openFile(last, 1)
      }, [doc, openFile])

      // Keep the preview honest when the file is edited by the agent or another app.
      useEffect(() => {
        if (!doc) return undefined
        const timer = setInterval(async () => {
          if (busy || !docRef.current) return
          const active = typeof document !== 'undefined' ? document.activeElement : null
          if (active && active.closest && active.closest('.dshv-right')) return
          try {
            const stat = await postJson(`${ROUTE}/op`, { action: 'stat', path: docRef.current.path })
            if (stat.mtime && docRef.current && Math.abs(stat.mtime - docRef.current.mtime) > 0.5) {
              const page = docRef.current.page
              const keep = selectedRef.current
              const fresh = await postJson(`${ROUTE}/op`, {
                action: 'render', path: docRef.current.path, page, selected: keep ?? undefined,
              })
              setDoc(fresh)
              setNotice(t('externalChanged'))
            }
          } catch {
            /* polling is best-effort */
          }
        }, POLL_MS)
        return () => clearInterval(timer)
      }, [doc?.path, busy, t])

      const chooseFolder = useCallback(async () => {
        try {
          const picked = await pickFolder()
          if (picked) await loadFolder(picked)
        } catch (err) {
          setFilesError(err instanceof Error ? err.message : String(err))
        }
      }, [pickFolder, loadFolder])

      const shape = useMemo(() => {
        if (!doc || !selected) return null
        return (doc.shapes || []).find((s) => s.id === selected) || null
      }, [doc, selected])

      const detail = doc?.detail && doc.detail.id === selected ? doc.detail : null

      const commitText = useCallback((text) => {
        const current = docRef.current
        if (!current || !selectedRef.current) return
        runOp({ action: 'set_text', path: current.path, page: current.page, shape_id: selectedRef.current, text })
      }, [runOp])

      const commitCell = useCallback((cells) => {
        const current = docRef.current
        if (!current || !selectedRef.current) return
        runOp({ action: 'set_cells', path: current.path, page: current.page, shape_id: selectedRef.current, cells })
      }, [runOp])

      const commitMove = useCallback((geometry) => {
        const current = docRef.current
        if (!current || !selectedRef.current) return
        runOp({ action: 'move', path: current.path, page: current.page, shape_id: selectedRef.current, ...geometry })
      }, [runOp])

      const commitLine = useCallback((start, end) => {
        const current = docRef.current
        if (!current || !selectedRef.current) return
        runOp({ action: 'set_line', path: current.path, page: current.page, shape_id: selectedRef.current, start, end })
      }, [runOp])

      // Drop a new shape where it can actually be seen.  Every insert used to land on
      // the exact centre of the page, so a second rectangle sat perfectly on top of
      // the first: the canvas did not change and the click looked like it had failed.
      const freeSpot = (current, w, h) => {
        const { w: pageW, h: pageH } = current.pageSize
        const boxes = (current.shapes || []).filter((s) => !s.connector && s.bbox).map((s) => s.bbox)
        const hits = (bx) => boxes.some((b) => bx.x < b.x + b.w - 0.02 && bx.x + bx.w > b.x + 0.02
          && bx.y < b.y + b.h - 0.02 && bx.y + bx.h > b.y + 0.02)
        let x = (pageW - w) / 2
        let y = (pageH - h) / 2
        for (let i = 0; i < 40; i += 1) {
          if (!hits({ x, y, w, h })) break
          x += 0.3
          y -= 0.3
          if (x + w > pageW - 0.1) { x = 0.4; y -= 0.3 }
          if (y < 0.1) { y = pageH - h - 0.4; x += 0.3 }
        }
        return {
          x: Math.round(Math.max(0.05, Math.min(x, Math.max(0.05, pageW - w - 0.05))) * 1000) / 1000,
          y: Math.round(Math.max(0.05, Math.min(y, Math.max(0.05, pageH - h - 0.05))) * 1000) / 1000,
        }
      }

      const addShape = useCallback((kind) => {
        const current = docRef.current
        if (!current) return
        const { w: pageW, h: pageH } = current.pageSize
        const base = { action: 'add_shape', path: current.path, page: current.page, kind }
        const land = (state) => {
          // select it straight away: the handles should be there without a second click
          if (state && state.detail) {
            setDoc(state)
            setSelected(state.detail.id)
          }
        }
        if (kind === 'text') {
          const spot = freeSpot(current, Math.max(2, pageW - 1.2), 0.7)
          runOp({ ...base, x: spot.x, y: spot.y, w: Math.max(2, pageW - 1.2), h: 0.7, text: t('textShape') }).then(land)
        } else if (kind === 'line') {
          runOp({ ...base, x: pageW / 2 - 1, y: pageH / 2, w: 2, h: 1.2 }).then(land)
        } else {
          const spot = freeSpot(current, 1.8, 0.9)
          runOp({ ...base, x: spot.x, y: spot.y, w: 1.8, h: 0.9,
            text: kind === 'ellipse' ? 'Ellipse' : 'Rectangle' }).then(land)
        }
      }, [runOp, t])

      const audit = useCallback(async () => {
        const current = docRef.current
        if (!current) return
        setError('')
        try {
          const result = await postJson(`${ROUTE}/op`, { action: 'validate', path: current.path, page: current.page })
          if (!result.ok) throw new Error(result.error || 'validate failed')
          const bad = (result.issues || []).filter((item) => item.level !== 'info')
          if (!bad.length) {
            setNotice(t('validateClean'))
          } else {
            const head = bad.slice(0, 3).map((item) => `#${item.shape} ${item.message}`).join('；')
            setError(`${t('validateIssues')}${bad.length} · ${head}`)
          }
        } catch (cause) {
          setError(messageOf(cause))
        }
      }, [postJson, t])

      const exportPng = useCallback(async () => {
        const current = docRef.current
        if (!current) return
        try {
          const result = await postJson(`${ROUTE}/op`, {
            action: 'export', path: current.path, page: current.page, format: 'png', grid: showGrid,
          })
          setNotice(`${t('exported')}: ${result.path}`)
          setError('')
        } catch (error) {
          setError(error instanceof Error ? error.message : String(error))
        }
      }, [showGrid, t])

      const loadStencil = useCallback(async () => {
        const file = stencilPath.trim()
        if (!file) return
        setStencilError('')
        try {
          const result = await postJson(`${ROUTE}/op`, { action: 'stencils', file })
          setStencilMasters(result.masters || [])
          setStencilFile(result.file || file)
        } catch (error) {
          setStencilMasters([])
          setStencilError(error instanceof Error ? error.message : String(error))
        }
      }, [stencilPath])

      const insertMaster = useCallback((master) => {
        const current = docRef.current
        if (!current || !stencilFile) return
        const { w: pageW, h: pageH } = current.pageSize
        runOp({
          action: 'stencil_add',
          path: current.path,
          page: current.page,
          file: stencilFile,
          master: master.id,
          x: pageW / 2 - 1,
          y: pageH / 2 - 0.6,
        })
      }, [runOp, stencilFile])

      const removeShape = useCallback((options = {}) => {
        const current = docRef.current
        if (!current || !selectedRef.current) return
        if (options.confirm !== false && !window.confirm(t('deleteConfirm', { id: selectedRef.current }))) return
        runOp({ action: 'delete', path: current.path, page: current.page, shape_id: selectedRef.current })
      }, [runOp, t])

      useEffect(() => {
        const onKey = (event) => {
          const root = rootRef.current
          if (!root) return
          const path = typeof event.composedPath === 'function' ? event.composedPath() : []
          const active = document.activeElement
          // The DSH shell keeps focus on its own body, and a panel wrapped in a
          // shadow root retargets event.target to the host: both made the old
          // "is the event inside the panel" test fail, so shortcuts died in the
          // app while still working in the standalone harness.  composedPath()
          // plus the focused-root check covers both cases.
          const inside = path.includes(root) || root.contains(event.target)
            || root === active || (active && root.contains(active))
          if (!inside) return
          const tag = active ? active.tagName : ''
          const typing = tag === 'INPUT' || tag === 'TEXTAREA' || (active && active.isContentEditable)
          if (typing) return
          const key = String(event.key || '').toLowerCase()
          const take = () => { event.preventDefault(); event.stopPropagation() }
          if ((event.ctrlKey || event.metaKey) && (key === 'z' || key === 'y')) {
            take()
            // Ctrl+Z undo, Ctrl+Shift+Z / Ctrl+Y redo (both conventions).
            undoTo(key === 'y' || event.shiftKey ? 'redo' : 'undo')
            return
          }
          if ((event.ctrlKey || event.metaKey) && key === 'd') {
            // duplicate the selection: a common companion to Del
            take()
            if (selectedRef.current) setNotice(t('selectShape'))
            return
          }
          if (event.ctrlKey || event.metaKey || event.altKey) return
          if (key === 'delete' || key === 'backspace') {
            if (!selectedRef.current) return
            take()
            removeShape({ confirm: false })
            return
          }
          if (key === 'escape') {
            take()
            setSelected(null)
          }
        }
        // Capture phase: DSH installs its own document-level shortcuts, and a
        // bubbling listener loses Ctrl+Z to them before the panel sees it.
        document.addEventListener('keydown', onKey, true)
        return () => document.removeEventListener('keydown', onKey, true)
      }, [undoTo, removeShape])

      const useGuide = useCallback(async (direction) => {
        const current = docRef.current
        const id = selectedRef.current
        if (!current || !id) return
        setBusy(true)
        try {
          const probe = await postJson(`${ROUTE}/op`, {
            action: 'probe', path: current.path, page: current.page, shape_id: id, direction,
          })
          if (probe && probe.target) {
            await postJson(`${ROUTE}/op`, {
              action: 'connect', path: current.path, page: current.page,
              from: id, to: probe.target,
            })
            setNotice(t('connectedTo', { id: probe.target }))
          } else {
            const made = await postJson(`${ROUTE}/op`, {
              action: 'duplicate', path: current.path, page: current.page,
              shape_id: id, direction, connect: true,
            })
            setNotice(t('duplicatedAs', { id: made && made.shape_id ? made.shape_id : '' }))
          }
          const fresh = await runOp({
            action: 'render', path: current.path, page: current.page, selected: id,
          }, { quiet: true })
          if (fresh) setDoc(fresh)
        } catch (err) {
          setError(String(err && err.message ? err.message : err))
        } finally {
          setBusy(false)
        }
      }, [runOp, t])

      const routeStyle = useCallback((style) => {
        const current = docRef.current
        if (!current || !selectedRef.current) return
        runOp({ action: 'route_style', path: current.path, page: current.page,
          shape_id: selectedRef.current, style })
      }, [runOp])

      const connectTo = useCallback((targetId, label) => {
        const current = docRef.current
        if (!current || !selectedRef.current || !targetId) return
        runOp({ action: 'connect', path: current.path, page: current.page, from: selectedRef.current, to: targetId, label })
      }, [runOp])

      const setProp = useCallback((name, value) => {
        const current = docRef.current
        if (!current || !selectedRef.current) return
        runOp({ action: 'set_prop', path: current.path, page: current.page, shape_id: selectedRef.current, name, value })
      }, [runOp])

      const viewBox = doc ? `0 0 ${doc.pageSize.w} ${doc.pageSize.h}` : '0 0 1 1'

      const onCanvasClick = (event) => {
        const node = event.target instanceof Element ? event.target.closest('[data-shape-id]') : null
        const id = node ? node.getAttribute('data-shape-id') : null
        if (tool === 'link') {
          const current = docRef.current
          const target = current && id ? current.shapes.find((item) => item.id === id) : null
          if (!target || target.connector) return
          if (!linkFrom) {
            setLinkFrom(id)
            setNotice(t('linkPickTarget', { id }))
            return
          }
          if (linkFrom === id) return
          runOp({ action: 'connect', path: current.path, page: current.page, from: linkFrom, to: id })
            .then((state) => { if (state) setDoc(state) })
          setLinkFrom(null)
          setNotice(t('connectedTo', { id }))
          return
        }
        if (node) {
          if (id) openSelected(id)
          return
        }
        setSelected(null)
      }

      const dragRef = useRef(null)

      const SNAP = 0.35           // inches; about one grid cell at 100% zoom
      // A connector run needs a much finer magnet than a whole shape: 0.35in
      // covered a whole grid cell, so a small drag jumped between two nearby
      // alignment lines instead of following the pointer.
      const SNAP_FINE = 0.05

      // Four connection points of a box, in sheet coordinates.  The engine ships the
      // real Connection rows when a shape has them; the side midpoints are the
      // fallback Visio itself uses.
      const portsOf = (item) => {
        if (!item) return []
        if (item.ports && item.ports.length) return item.ports
        const b = item.bbox
        if (!b) return []
        return [
          [b.x, b.y + b.h / 2],
          [b.x + b.w, b.y + b.h / 2],
          [b.x + b.w / 2, b.y],
          [b.x + b.w / 2, b.y + b.h],
        ]
      }

      const snapEdges = (bbox, shapes, id) => {
        const xs = []
        const ys = []
        const ports = []
        for (const other of (shapes || [])) {
          if (other.id === id || other.connector || other.line || !other.bbox) continue
          const o = other.bbox
          xs.push(o.x, o.x + o.w, o.x + o.w / 2)
          ys.push(o.y, o.y + o.h, o.y + o.h / 2)
          // Connection points are a second pair of alignment dimensions on top of
          // the box edges: their x lines up vertically, their y horizontally.
          for (const p of portsOf(other)) ports.push({ x: p[0], y: p[1], id: other.id })
        }
        return { xs, ys, ports }
      }

      const nearest = (value, list) => {
        let best = null
        let dist = SNAP
        for (const v of list) {
          const d = Math.abs(v - value)
          if (d <= dist) { best = v; dist = d }
        }
        return best
      }

      /** Dashed guide line inside the page svg: the visible half of snapping. */
      const guideLine = (svgEl, id, x1, y1, x2, y2, color) => {
        if (!svgEl) return
        let el = svgEl.querySelector('#' + id)
        if (!el) {
          el = document.createElementNS('http://www.w3.org/2000/svg', 'line')
          el.setAttribute('id', id)
          el.setAttribute('stroke-width', '1')
          el.setAttribute('vector-effect', 'non-scaling-stroke')
          el.setAttribute('stroke-dasharray', '4 3')
          el.setAttribute('pointer-events', 'none')
          svgEl.appendChild(el)
        }
        el.setAttribute('stroke', color || '#E5484D')
        el.setAttribute('x1', Number(x1).toFixed(4)); el.setAttribute('y1', Number(y1).toFixed(4))
        el.setAttribute('x2', Number(x2).toFixed(4)); el.setAttribute('y2', Number(y2).toFixed(4))
        el.style.display = ''
      }

      const hideGuide = (svgEl, id) => {
        const el = svgEl && svgEl.querySelector('#' + id)
        if (el) el.style.display = 'none'
      }

      const moveDrag = (event) => {
        const drag = dragRef.current
        if (!drag) return
        const dxPx = event.clientX - drag.startX
        const dyPx = event.clientY - drag.startY
        if (!drag.moved && Math.abs(dxPx) + Math.abs(dyPx) < 3) return
        drag.moved = true
        drag.dx = dxPx / drag.scale
        drag.dy = dyPx / drag.scale
        // Alignment snapping, in two tiers.
        //
        // Tier 1 (new) is connection points: when one of this box's ports lands on
        // the same x or the same y as a port of another shape, the box sticks there
        // and a blue guide joins the two ports.  That is what makes a pair of boxes
        // line up so the connector between them comes out perfectly straight.
        // Tier 2 (unchanged) is the box edges and centre lines, drawn in red.
        if (!drag.isConn && drag.cands) {
          const b = drag.bbox
          drag.portX = null
          drag.portY = null
          if (!event.altKey && drag.cands.ports && drag.cands.ports.length) {
            const ownPorts = (tx, ty) => ([
              [tx, ty + b.h / 2], [tx + b.w, ty + b.h / 2],
              [tx + b.w / 2, ty], [tx + b.w / 2, ty + b.h],
            ])
            let bestX = null
            let bestY = null
            for (const own of ownPorts(b.x + drag.dx, b.y - drag.dy)) {
              for (const p of drag.cands.ports) {
                const dX = Math.abs(p.x - own[0])
                if (dX <= SNAP && (!bestX || dX < bestX.d)) {
                  bestX = { d: dX, shift: p.x - own[0], from: own[1], to: p.y, at: p.x }
                }
                const dY = Math.abs(p.y - own[1])
                if (dY <= SNAP && (!bestY || dY < bestY.d)) {
                  bestY = { d: dY, shift: p.y - own[1], from: own[0], to: p.x, at: p.y }
                }
              }
            }
            if (bestX) {
              drag.dx += bestX.shift
              drag.portX = { at: bestX.at, from: bestX.from, to: bestX.to }
            }
            if (bestY) {
              drag.dy -= bestY.shift
              drag.portY = { at: bestY.at, from: bestY.from, to: bestY.to }
            }
          }
          const nx = b.x + drag.dx
          const ny = b.y - drag.dy
          // tier 2 only fills the axis tier 1 left free, so the two never fight
          const leftHit = drag.portX ? null : nearest(nx, drag.cands.xs)
          const rightHit = drag.portX ? null : nearest(nx + b.w, drag.cands.xs)
          const centreXHit = drag.portX ? null : nearest(nx + b.w / 2, drag.cands.xs)
          if (!drag.portX) {
            if (leftHit !== null) drag.dx = leftHit - b.x
            else if (rightHit !== null) drag.dx = rightHit - b.w - b.x
            else if (centreXHit !== null) drag.dx = centreXHit - b.w / 2 - b.x
          }
          const topHit = drag.portY ? null : nearest(ny + b.h, drag.cands.ys)
          const bottomHit = drag.portY ? null : nearest(ny, drag.cands.ys)
          const centreYHit = drag.portY ? null : nearest(ny + b.h / 2, drag.cands.ys)
          if (!drag.portY) {
            if (topHit !== null) drag.dy = b.y + b.h - topHit
            else if (bottomHit !== null) drag.dy = b.y - bottomHit
            else if (centreYHit !== null) drag.dy = b.y + b.h / 2 - centreYHit
          }
          drag.snapped = (leftHit !== null || rightHit !== null || centreXHit !== null
            || topHit !== null || bottomHit !== null || centreYHit !== null
            || drag.portX !== null || drag.portY !== null)
          drag.snapX = drag.portX ? drag.portX.at
            : ((leftHit !== null) ? leftHit : ((rightHit !== null) ? rightHit
              : ((centreXHit !== null) ? centreXHit : null)))
          drag.snapY = drag.portY ? drag.portY.at
            : ((topHit !== null) ? topHit : ((bottomHit !== null) ? bottomHit
              : ((centreYHit !== null) ? centreYHit : null)))
          // nothing aligned: fall back to the 0.25in grid, unless Alt is held
          if (!event.altKey) {
            if (drag.snapX === null) {
              const gx = Math.round((b.x + drag.dx) * 4) / 4
              if (Math.abs(gx - (b.x + drag.dx)) < 0.13) {
                drag.dx = gx - b.x
                drag.snapX = gx
              }
            }
            if (drag.snapY === null) {
              const gy = Math.round((b.y - drag.dy) * 4) / 4
              if (Math.abs(gy - (b.y - drag.dy)) < 0.13) {
                drag.dy = b.y - gy
                drag.snapY = gy
              }
            }
          }
          const svgEl = drag.svg
          if (svgEl) {
            const H = drag.pageH || 0
            // A connection-point guide only spans the two ports it joins, which is
            // what makes it read as "these two points line up" rather than as a
            // page-wide ruler.
            if (drag.portX) {
              guideLine(svgEl, 'dshv-portguide-x', drag.portX.at, H - Math.max(drag.portX.from, drag.portX.to),
                drag.portX.at, H - Math.min(drag.portX.from, drag.portX.to), '#2F6FBF')
            } else hideGuide(svgEl, 'dshv-portguide-x')
            if (drag.portY) {
              guideLine(svgEl, 'dshv-portguide-y', Math.min(drag.portY.from, drag.portY.to), H - drag.portY.at,
                Math.max(drag.portY.from, drag.portY.to), H - drag.portY.at, '#2F6FBF')
            } else hideGuide(svgEl, 'dshv-portguide-y')
            // A connection-point match already draws its own short blue guide, so the
            // page-wide red ruler would only clutter it.
            if (drag.snapX !== null && !drag.portX) guideLine(svgEl, 'dshv-snap-x', drag.snapX, 0, drag.snapX, H)
            else hideGuide(svgEl, 'dshv-snap-x')
            if (drag.snapY !== null && !drag.portY) guideLine(svgEl, 'dshv-snap-y', 0, H - drag.snapY, drag.pageW, H - drag.snapY)
            else hideGuide(svgEl, 'dshv-snap-y')
          }
        }
        const label = drag.isConn && drag.textNode
        if (label) {
          // dx/dy are screen pixels; svg user space is inches.  Divide by the
          // on-screen scale so the live preview matches what move_label commits.
          drag.textNode.setAttribute('transform',
            `translate(${(drag.dx / drag.scale).toFixed(4)} ${(drag.dy / drag.scale).toFixed(4)})`)
        } else {
          drag.node.setAttribute('transform',
            `translate(${(drag.base.x + drag.dx).toFixed(4)} ${(drag.base.y + drag.dy).toFixed(4)})`)
          drag.node.style.opacity = '0.85'
        }
        const tip = tipRef.current
        if (tip && tip.parentElement) {
          const box = tip.parentElement.getBoundingClientRect()
          tip.style.display = 'block'
          tip.style.left = `${event.clientX - box.left + 14}px`
          tip.style.top = `${event.clientY - box.top - 30}px`
          const tipX = (drag.bbox.x + drag.dx).toFixed(3)
          const tipY = (drag.bbox.y - drag.dy).toFixed(3)
          tip.textContent = `X ${tipX}   Y ${tipY}${drag.snapped ? '   [snap]' : ''}`
        }
      }

      const upDrag = () => {
        const drag = dragRef.current
        dragRef.current = null
        window.removeEventListener('pointermove', moveDrag)
        window.removeEventListener('pointerup', upDrag)
        window.removeEventListener('pointercancel', upDrag)
        window.removeEventListener('blur', upDrag)
        if (tipRef.current) tipRef.current.style.display = 'none'
        const svgEl = drag && drag.svg
        if (svgEl) {
          for (const gid of ['dshv-snap-x', 'dshv-snap-y', 'dshv-portguide-x', 'dshv-portguide-y']) {
            const el = svgEl.querySelector('#' + gid)
            if (el) el.remove()
          }
        }
        if (!drag) return
        drag.node.style.opacity = ''
        if (!drag.moved) {
          drag.node.removeAttribute('transform')
          if (drag.textNode) drag.textNode.removeAttribute('transform')
          return
        }
        const current = docRef.current
        if (!current) return
        if (drag.isConn && drag.textNode) {
          runOp({
            action: 'move_label', path: current.path, page: current.page, shape_id: drag.id,
            // drag.dy is screen pixels (down positive); TxtPinY is drawing inches
            // (up positive).  Convert by the on-screen scale and flip the sign here.
            dx: Math.round(drag.dx * 1000) / 1000, dy: Math.round((-drag.dy / drag.scale) * 1000) / 1000,
          }).then((saved) => {
            if (drag.textNode) drag.textNode.removeAttribute('transform')
            return saved
          })
          return
        }
        const pageSize = current.pageSize || { w: 11, h: 8.5 }
        const x = Math.round(Math.min(Math.max(0, drag.bbox.x + drag.dx), Math.max(0, pageSize.w - drag.bbox.w)) * 1000) / 1000
        const y = Math.round(Math.min(Math.max(0, drag.bbox.y - drag.dy), Math.max(0, pageSize.h - drag.bbox.h)) * 1000) / 1000
        // Commit through the normal path so the response carries BOTH the new
        // geometry and the matching svg.  A previous "light" commit updated only
        // the shape list and reconciled the picture in a second request: between
        // the two, handles were placed from the new coordinates into the old
        // picture, so a handle could sit inches away from the line it belonged to.
        runOp({ action: 'move', path: current.path, page: current.page,
          shape_id: drag.id, x, y }).catch(() => {})
      }

      const hoverRef = useRef(null)
      // Any in-progress gesture.  The hover handler rebuilds the four connection
      // dots on every shape change; during a drag those dots both cost a DOM rebuild
      // per frame and sit under elementFromPoint, which made connector drags judder
      // and mis-pick their drop target.
      const draggingRef = useRef(false)

      // Hovering a shape reveals its connection points.  Dragging from one of those
      // dots to another shape draws a connector between them: one gesture instead of
      // arming a tool and clicking two shapes.
      const onCanvasPointerMove = (event) => {
        if (draggingRef.current) return
        const current = docRef.current
        const svgEl = event.currentTarget.querySelector('svg')
        if (!current || !svgEl) return
        if (tool !== 'select') {
          const stale = svgEl.querySelector('#dshv-ports')
          if (stale) stale.remove()
          hoverRef.current = null
          return
        }
        const node = event.target instanceof Element ? event.target.closest('[data-shape-id]') : null
        const id = node ? node.getAttribute('data-shape-id') : null
        if (id === hoverRef.current) return
        hoverRef.current = id
        const old = svgEl.querySelector('#dshv-ports')
        if (old) old.remove()
        const item = id ? (current.shapes || []).find((s) => s.id === id) : null
        if (!item || item.connector || item.line || !item.bbox) return
        const pts = portsOf(item)
        if (!pts.length) return
        const H = current.pageSize.h
        const ns = 'http://www.w3.org/2000/svg'
        const g = document.createElementNS(ns, 'g')
        g.setAttribute('id', 'dshv-ports')
        pts.forEach((p, i) => {
          const c = document.createElementNS(ns, 'circle')
          c.setAttribute('cx', p[0])
          c.setAttribute('cy', H - p[1])
          c.setAttribute('r', '0.075')
          c.setAttribute('fill', '#2FBF71')
          c.setAttribute('data-port-role', 'start')
          c.setAttribute('title', '起点 · 拖到另一个图形')
          c.setAttribute('fill-opacity', '0.95')
          c.setAttribute('stroke', '#FFFFFF')
          c.setAttribute('stroke-width', '2')
          c.setAttribute('vector-effect', 'non-scaling-stroke')
          c.setAttribute('data-port', item.id + ':' + i)
          c.setAttribute('class', 'dshv-portDot')
          g.appendChild(c)
        })
        svgEl.appendChild(g)
      }

      const onCanvasPointerLeave = (event) => {
        const svgEl = event.currentTarget.querySelector('svg')
        hoverRef.current = null
        const g = svgEl && svgEl.querySelector('#dshv-ports')
        if (g) g.remove()
      }

      const onCanvasPointerDown = (event) => {
        // A gesture is starting: stop the hover handler from rebuilding dots and
        // stealing hit-tests until the pointer is released anywhere.
        draggingRef.current = true
        const endDragFlag = () => { draggingRef.current = false }
        window.addEventListener('pointerup', endDragFlag, { once: true, capture: true })
        window.addEventListener('pointercancel', endDragFlag, { once: true, capture: true })
        window.addEventListener('contextmenu', endDragFlag, { once: true, capture: true })
        // Right button always pans the canvas, whatever tool is active.  This is
        // the one gesture that must not be swallowed by a shape under the cursor.
        if (event.button === 2) {
          const wrap0 = canvasBox.current
          if (!wrap0) return
          event.preventDefault()
          const p0 = { x: event.clientX, y: event.clientY, left: wrap0.scrollLeft, top: wrap0.scrollTop }
          const move0 = (e) => {
            wrap0.scrollLeft = p0.left - (e.clientX - p0.x)
            wrap0.scrollTop = p0.top - (e.clientY - p0.y)
          }
          const up0 = () => {
            window.removeEventListener('pointermove', move0)
            window.removeEventListener('pointerup', up0)
            window.removeEventListener('pointercancel', up0)
          }
          window.addEventListener('pointermove', move0)
          window.addEventListener('pointerup', up0)
          window.addEventListener('pointercancel', up0)
          return
        }
        if (event.button !== 0) return
        if (tool === 'hand') {
          const wrap = canvasBox.current
          if (!wrap) return
          event.preventDefault()
          panRef.current = { x: event.clientX, y: event.clientY, left: wrap.scrollLeft, top: wrap.scrollTop }
          const move = (e) => {
            const pan = panRef.current
            if (!pan) return
            wrap.scrollLeft = pan.left - (e.clientX - pan.x)
            wrap.scrollTop = pan.top - (e.clientY - pan.y)
          }
          const up = () => {
            panRef.current = null
            window.removeEventListener('pointermove', move)
            window.removeEventListener('pointerup', up)
          }
          window.addEventListener('pointermove', move)
          window.addEventListener('pointerup', up)
          return
        }
        const sheetOf = (current, svgEl, cx, cy) => {
          const box = svgEl.getBoundingClientRect()
          const vb = svgEl.viewBox && svgEl.viewBox.baseVal ? svgEl.viewBox.baseVal : null
          if (!vb || !box.width) return null
          const scale = box.width / vb.width
          const pageH = (current.pageSize && current.pageSize.h) || vb.height
          return {
            pt: { x: vb.x + (cx - box.left) / scale, y: pageH - vb.y - (cy - box.top) / scale },
            scale, pageH, vb,
          }
        }
        /** Dashed rectangle that follows a resize drag (the svg is server-rendered). */
        const previewBox = (svgEl, box, pageH) => {
          const nsx = 'http://www.w3.org/2000/svg'
          let el = svgEl.querySelector('#dshv-box-preview')
          if (!el) {
            el = document.createElementNS(nsx, 'rect')
            el.setAttribute('id', 'dshv-box-preview')
            el.setAttribute('fill', 'none')
            el.setAttribute('stroke', '#2F6FBF')
            el.setAttribute('stroke-dasharray', '4 3')
            el.setAttribute('vector-effect', 'non-scaling-stroke')
            el.setAttribute('pointer-events', 'none')
            svgEl.appendChild(el)
          }
          el.setAttribute('x', Number(box.x).toFixed(4))
          el.setAttribute('y', Number(pageH - box.y - box.h).toFixed(4))
          el.setAttribute('width', Number(box.w).toFixed(4))
          el.setAttribute('height', Number(box.h).toFixed(4))
          el.style.display = ''
        }
        /** Dashed preview with an arrow head and a distinct start/end marker.
         *  The engine's own marker defs are keyed by colour; we draw the head as a
         *  small filled triangle so the preview works for any colour and always
         *  shows which end is the target. */
        const previewLine = (svgEl, id, a, b, pageH, color) => {
          const stroke = color || '#2F6FBF'
          let g = svgEl.querySelector('#' + id)
          if (!g) {
            g = document.createElementNS('http://www.w3.org/2000/svg', 'g')
            g.setAttribute('id', id)
            g.setAttribute('pointer-events', 'none')
            g.innerHTML = '<line stroke-width="1.5" stroke-dasharray="5 3" vector-effect="non-scaling-stroke"/>'
              + '<circle class="pv-start" r="0.085" fill="#FFFFFF" stroke-width="2" vector-effect="non-scaling-stroke"/>'
              + '<path class="pv-head" stroke-linejoin="round"/>'
              + '<circle class="pv-end" r="0.055" fill="#FFFFFF" stroke-width="2" vector-effect="non-scaling-stroke"/>'
            svgEl.appendChild(g)
          }
          const x1 = a.x, y1 = pageH - a.y, x2 = b.x, y2 = pageH - b.y
          const ln = g.querySelector('line')
          ln.setAttribute('stroke', stroke)
          ln.setAttribute('x1', x1.toFixed(4)); ln.setAttribute('y1', y1.toFixed(4))
          ln.setAttribute('x2', x2.toFixed(4)); ln.setAttribute('y2', y2.toFixed(4))
          // start = hollow blue dot, end = arrow head + small green dot
          const st = g.querySelector('.pv-start')
          st.setAttribute('cx', x1.toFixed(4)); st.setAttribute('cy', y1.toFixed(4))
          st.setAttribute('stroke', stroke)
          const en = g.querySelector('.pv-end')
          en.setAttribute('cx', x2.toFixed(4)); en.setAttribute('cy', y2.toFixed(4))
          en.setAttribute('stroke', stroke)
          const dx = x2 - x1, dy = y2 - y1
          const len = Math.hypot(dx, dy) || 1
          const ux = dx / len, uy = dy / len
          const size = 0.16
          const bx = x2 - ux * size, by = y2 - uy * size
          const px = -uy, py = ux
          const head = g.querySelector('.pv-head')
          head.setAttribute('d', `M ${x2.toFixed(4)} ${y2.toFixed(4)} L ${(bx + px * size * 0.5).toFixed(4)} ${(by + py * size * 0.5).toFixed(4)} L ${(bx - px * size * 0.5).toFixed(4)} ${(by - py * size * 0.5).toFixed(4)} Z`)
          head.setAttribute('fill', stroke)
          g.style.display = ''
        }
        // ---- resize a shape from one of its eight handles ----------------------
        const resizeHandle = event.target instanceof Element ? event.target.closest('[data-resize]') : null
        if (resizeHandle) {
          event.preventDefault()
          event.stopPropagation()
          const current = docRef.current
          const svgEl = event.currentTarget.querySelector('svg')
          const [id, dir] = String(resizeHandle.getAttribute('data-resize')).split(':')
          const item = current && (current.shapes || []).find((s) => s.id === id)
          const hit = current && svgEl ? sheetOf(current, svgEl, event.clientX, event.clientY) : null
          if (!item || !hit || !svgEl) return
          const b0 = { ...item.bbox }
          const start = { x: event.clientX, y: event.clientY }
          let box = { ...b0 }
          const move = (e) => {
            const dx = (e.clientX - start.x) / hit.scale
            const dy = -(e.clientY - start.y) / hit.scale
            let x = b0.x; let y = b0.y; let w = b0.w; let h = b0.h
            if (dir.includes('e')) w = b0.w + dx
            if (dir.includes('w')) { x = b0.x + dx; w = b0.w - dx }
            if (dir.includes('n')) h = b0.h + dy
            if (dir.includes('s')) { y = b0.y + dy; h = b0.h - dy }
            w = Math.max(0.12, w)
            h = Math.max(0.12, h)
            if (e.shiftKey && dir.length === 2) {
              // Shift keeps the aspect ratio on a corner handle
              const k = Math.max(w / b0.w, h / b0.h)
              w = b0.w * k
              h = b0.h * k
              if (dir.includes('w')) x = b0.x + b0.w - w
              if (dir.includes('s')) y = b0.y + b0.h - h
            }
            box = { x, y, w, h }
            previewBox(svgEl, box, hit.pageH)
            const tip = tipRef.current
            if (tip && tip.parentElement) {
              const host = tip.parentElement.getBoundingClientRect()
              tip.style.display = 'block'
              tip.style.left = `${e.clientX - host.left + 14}px`
              tip.style.top = `${e.clientY - host.top - 30}px`
              tip.textContent = `${box.w.toFixed(2)} × ${box.h.toFixed(2)} in`
            }
          }
          const up = () => {
            window.removeEventListener('pointermove', move)
            window.removeEventListener('pointerup', up)
            const el = svgEl.querySelector('#dshv-box-preview')
            if (el) el.remove()
            if (tipRef.current) tipRef.current.style.display = 'none'
            if (Math.abs(box.w - b0.w) < 0.005 && Math.abs(box.h - b0.h) < 0.005) return
            runOp({ action: 'move', path: current.path, page: current.page, shape_id: id,
              x: box.x, y: box.y, w: box.w, h: box.h })
              .then((state) => { if (state) setDoc(state) })
          }
          window.addEventListener('pointermove', move)
          window.addEventListener('pointerup', up)
          return
        }
        // ---- rotate a shape ---------------------------------------------------
        const rotateHandle = event.target instanceof Element ? event.target.closest('[data-rotate]') : null
        if (rotateHandle) {
          event.preventDefault()
          event.stopPropagation()
          const current = docRef.current
          const svgEl = event.currentTarget.querySelector('svg')
          const id = rotateHandle.getAttribute('data-rotate')
          const item = current && (current.shapes || []).find((s) => s.id === id)
          const hit = current && svgEl ? sheetOf(current, svgEl, event.clientX, event.clientY) : null
          if (!item || !hit || !svgEl) return
          const cx = item.bbox.x + item.bbox.w / 2
          const cy = item.bbox.y + item.bbox.h / 2
          const cxSvg = cx
          const cySvg = hit.pageH - cy
          const a0 = Math.atan2(hit.pt.y - cy, hit.pt.x - cx) * 180 / Math.PI
          const base0 = item.angle || 0
          const node = svgEl.querySelector('[data-shape-id="' + id + '"]')
          let deg = base0
          const move = (e) => {
            const p = sheetOf(current, svgEl, e.clientX, e.clientY)
            if (!p) return
            const a1 = Math.atan2(p.pt.y - cy, p.pt.x - cx) * 180 / Math.PI
            deg = base0 + (a1 - a0)
            if (e.shiftKey) deg = Math.round(deg / 15) * 15
            deg = ((deg % 360) + 360) % 360
            if (node) node.setAttribute('transform', `rotate(${(-deg).toFixed(4)} ${cxSvg} ${cySvg})`)
            const tip = tipRef.current
            if (tip && tip.parentElement) {
              const host = tip.parentElement.getBoundingClientRect()
              tip.style.display = 'block'
              tip.style.left = `${e.clientX - host.left + 14}px`
              tip.style.top = `${e.clientY - host.top - 30}px`
              tip.textContent = `${deg.toFixed(1)}°`
            }
          }
          const up = () => {
            window.removeEventListener('pointermove', move)
            window.removeEventListener('pointerup', up)
            if (tipRef.current) tipRef.current.style.display = 'none'
            if (Math.abs(deg - base0) < 0.2) return
            runOp({ action: 'move', path: current.path, page: current.page, shape_id: id, angle: deg })
              .then((state) => { if (state) setDoc(state) })
          }
          window.addEventListener('pointermove', move)
          window.addEventListener('pointerup', up)
          return
        }
        if (tool === 'line') {
          event.preventDefault()
          const current = docRef.current
          const svgEl = event.currentTarget.querySelector('svg')
          if (!current || !svgEl) return
          const hit = sheetOf(current, svgEl, event.clientX, event.clientY)
          if (!hit) return
          const from = hit.pt
          let to = from
          const move = (e) => {
            const p = sheetOf(current, svgEl, e.clientX, e.clientY)
            if (!p) return
            to = p.pt
            if (e.shiftKey) {
              // hold Shift for a perfectly horizontal or vertical line
              if (Math.abs(to.x - from.x) >= Math.abs(to.y - from.y)) to = { x: to.x, y: from.y }
              else to = { x: from.x, y: to.y }
            }
            previewLine(svgEl, 'dshv-line-preview', from, to, hit.pageH)
            const tip = tipRef.current
            if (tip && tip.parentElement) {
              const host = tip.parentElement.getBoundingClientRect()
              tip.style.display = 'block'
              tip.style.left = `${e.clientX - host.left + 14}px`
              tip.style.top = `${e.clientY - host.top - 30}px`
              tip.textContent = `${to.x.toFixed(2)}, ${to.y.toFixed(2)}  长 ${Math.hypot(to.x - from.x, to.y - from.y).toFixed(2)} in`
            }
          }
          const up = () => {
            window.removeEventListener('pointermove', move)
            window.removeEventListener('pointerup', up)
            const el = svgEl.querySelector('#dshv-line-preview')
            if (el) el.remove()
            if (tipRef.current) tipRef.current.style.display = 'none'
            if (Math.hypot(to.x - from.x, to.y - from.y) < 0.1) { setTool('select'); return }
            runOp({ action: 'add_line', path: current.path, page: current.page,
              start: [from.x, from.y], end: [to.x, to.y] })
              .then((state) => { if (state) setDoc(state) })
            setTool('select')
            setNotice(t('lineDrawn'))
          }
          window.addEventListener('pointermove', move)
          window.addEventListener('pointerup', up)
          return
        }
        // ---- drag from a connection dot to another shape ----------------------
        const portDot = event.target instanceof Element ? event.target.closest('[data-port]') : null
        if (portDot) {
          event.preventDefault()
          event.stopPropagation()
          const current = docRef.current
          const svgEl = event.currentTarget.querySelector('svg')
          const [fromId, idx] = String(portDot.getAttribute('data-port')).split(':')
          const src = current && (current.shapes || []).find((s) => s.id === fromId)
          const hit0 = current && svgEl ? sheetOf(current, svgEl, event.clientX, event.clientY) : null
          if (!src || !hit0) return
          const fromPt = portsOf(src)[Number(idx)] || [hit0.pt.x, hit0.pt.y]
          const from = { x: fromPt[0], y: fromPt[1] }
          let to = from
          // Cache the shape groups once.  Walking every group on each pointermove
          // (and toggling a class on all of them) was the main source of lag.
          const groups = Array.from(svgEl.querySelectorAll('[data-shape-id]'))
          let lastTarget = null
          const move = (e) => {
            const p = sheetOf(current, svgEl, e.clientX, e.clientY)
            if (!p) return
            to = p.pt
            // highlight the shape under the cursor so the drop target is obvious
            const under = document.elementFromPoint(e.clientX, e.clientY)
            const node = under && under.closest ? under.closest('[data-shape-id]') : null
            const targetId = node && node.getAttribute('data-shape-id') !== fromId
              ? node.getAttribute('data-shape-id') : null
            if (targetId !== lastTarget) {
              if (lastTarget) {
                const prev = groups.find((g) => g.getAttribute('data-shape-id') === lastTarget)
                if (prev) prev.classList.remove('dshv-dropTarget')
              }
              if (targetId) {
                const next = groups.find((g) => g.getAttribute('data-shape-id') === targetId)
                if (next) next.classList.add('dshv-dropTarget')
              }
              lastTarget = targetId
            }
            previewLine(svgEl, 'dshv-line-preview', from, to, hit0.pageH)
            const tip = tipRef.current
            if (tip && tip.parentElement) {
              const host = tip.parentElement.getBoundingClientRect()
              const id2 = node && node.getAttribute('data-shape-id')
              tip.style.display = 'block'
              tip.style.left = `${e.clientX - host.left + 14}px`
              tip.style.top = `${e.clientY - host.top - 30}px`
              tip.textContent = id2 && id2 !== fromId
                ? `起点 #${fromId} → 终点 #${id2}`
                : t('connectHint')
            }
          }
          const up = (e) => {
            window.removeEventListener('pointermove', move)
            window.removeEventListener('pointerup', up)
            const el = svgEl.querySelector('#dshv-line-preview')
            if (el) el.remove()
            svgEl.querySelectorAll('[data-shape-id]').forEach((n) => n.classList.remove('dshv-dropTarget'))
            if (tipRef.current) tipRef.current.style.display = 'none'
            const under = document.elementFromPoint(e.clientX, e.clientY)
            const node = under && under.closest ? under.closest('[data-shape-id]') : null
            const toId = node && node.getAttribute('data-shape-id')
            if (!toId || toId === fromId) return
            const dst = (current.shapes || []).find((s) => s.id === toId)
            if (!dst || dst.connector || dst.line) return
            // glue to the port nearest the release point, not to a random edge
            const drop = sheetOf(current, svgEl, e.clientX, e.clientY)
            const dports = portsOf(dst)
            let bestPort = null
            for (const p of dports) {
              const d = (p[0] - drop.pt.x) ** 2 + (p[1] - drop.pt.y) ** 2
              if (!bestPort || d < bestPort.d) bestPort = { d, p }
            }
            runOp({ action: 'connect', path: current.path, page: current.page,
              from: fromId, to: toId,
              from_port: [from.x, from.y],
              to_port: bestPort ? [bestPort.p[0], bestPort.p[1]] : undefined })
              .then((state) => { if (state) setDoc(state) })
            setNotice(t('connectedTo', { id: toId }))
          }
          window.addEventListener('pointermove', move)
          window.addEventListener('pointerup', up)
          return
        }
        // ---- drag one end of a line -------------------------------------------
        const lineEnd = event.target instanceof Element ? event.target.closest('[data-line-end]') : null
        if (lineEnd) {
          event.preventDefault()
          event.stopPropagation()
          const current = docRef.current
          const svgEl = event.currentTarget.querySelector('svg')
          const id = lineEnd.getAttribute('data-line-end')
          const which = lineEnd.getAttribute('data-end')
          const item = current && (current.shapes || []).find((s) => s.id === id)
          const hit = current && svgEl ? sheetOf(current, svgEl, event.clientX, event.clientY) : null
          if (!item || !hit || !item.points || item.points.length < 2) return
          const fixed = which === 'start' ? item.points[item.points.length - 1] : item.points[0]
          const startPt = { x: fixed[0], y: fixed[1] }
          let moving = which === 'start' ? item.points[0] : item.points[item.points.length - 1]
          const move = (e) => {
            const p = sheetOf(current, svgEl, e.clientX, e.clientY)
            if (!p) return
            moving = p.pt
            if (e.shiftKey) {
              if (Math.abs(moving.x - startPt.x) >= Math.abs(moving.y - startPt.y)) moving = { x: moving.x, y: startPt.y }
              else moving = { x: startPt.x, y: moving.y }
            }
            previewLine(svgEl, 'dshv-line-preview', startPt, moving, hit.pageH)
            const tip = tipRef.current
            if (tip && tip.parentElement) {
              const host = tip.parentElement.getBoundingClientRect()
              tip.style.display = 'block'
              tip.style.left = `${e.clientX - host.left + 14}px`
              tip.style.top = `${e.clientY - host.top - 30}px`
              tip.textContent = `${moving.x.toFixed(2)}, ${moving.y.toFixed(2)}`
            }
          }
          const up = () => {
            window.removeEventListener('pointermove', move)
            window.removeEventListener('pointerup', up)
            const el = svgEl.querySelector('#dshv-line-preview')
            if (el) el.remove()
            if (tipRef.current) tipRef.current.style.display = 'none'
            const a = which === 'start' ? moving : startPt
            const b = which === 'start' ? startPt : moving
            if (Math.hypot(a.x - b.x, a.y - b.y) < 0.05) return
            runOp({ action: 'set_line', path: current.path, page: current.page, shape_id: id,
              start: [a.x, a.y], end: [b.x, b.y] })
              .then((state) => { if (state) setDoc(state) })
          }
          window.addEventListener('pointermove', move)
          window.addEventListener('pointerup', up)
          return
        }
        const endHandle = event.target instanceof Element ? event.target.closest('[data-route-end]') : null
        if (endHandle) {
          event.preventDefault()
          event.stopPropagation()
          const current = docRef.current
          const svgEl = event.currentTarget.querySelector('svg')
          if (!current || !svgEl) return
          const box = svgEl.getBoundingClientRect()
          const vb = svgEl.viewBox && svgEl.viewBox.baseVal ? svgEl.viewBox.baseVal : null
          if (!vb || !box.width) return
          const scale = box.width / vb.width
          const start = { x: event.clientX, y: event.clientY }
          const shapeId = endHandle.getAttribute('data-route-end')
          const which = endHandle.getAttribute('data-end')

          // The engine ships the real Connection points of every shape.  Guessing
          // four bbox midpoints here made the green drop marker sit somewhere other
          // than where the end actually landed on shapes with their own ports.
          const portsOf = (item) => {
            if (item && item.ports && item.ports.length) return item.ports
            const b = item && item.bbox
            if (!b) return []
            return [
              [b.x, b.y + b.h / 2],
              [b.x + b.w, b.y + b.h / 2],
              [b.x + b.w / 2, b.y],
              [b.x + b.w / 2, b.y + b.h],
            ]
          }

          const nearestPort = (wx, wy) => {
            let best = null
            for (const item of current.shapes) {
              if (item.connector || !item.bbox) continue
              for (const port of portsOf(item)) {
                const d = (port[0] - wx) ** 2 + (port[1] - wy) ** 2
                if (!best || d < best.d) best = { id: item.id, port, d }
              }
            }
            return best
          }

          const ghost = (id) => {
            let g = svgEl.querySelector('#' + id)
            if (!g) {
              g = document.createElementNS('http://www.w3.org/2000/svg', 'g')
              g.setAttribute('id', id)
              g.setAttribute('pointer-events', 'none')
              g.innerHTML = '<circle r="0.14" fill="#2FBF71" fill-opacity="0.9" stroke="#FFFFFF"'
                + ' stroke-width="2" vector-effect="non-scaling-stroke"/>'
                + '<line stroke="#2FBF71" stroke-width="1.5" stroke-dasharray="4 3"'
                + ' vector-effect="non-scaling-stroke"/>'
              svgEl.appendChild(g)
            }
            return g
          }

          // Svg user space *is* sheet space with y flipped: the renderer emits
          // (x, pageH - y) for every point, and the viewBox only says which slice
          // of that space is on screen.  Mixing the viewBox origin into this was
          // what made the green drop marker sit 0.25in away from the port it named,
          // so the line never landed where the marker promised.
          const pageH = (current.pageSize && current.pageSize.h) || vb.height
          const toSheet = (clientX, clientY) => ({
            x: vb.x + (clientX - box.left) / scale,
            y: pageH - vb.y - (clientY - box.top) / scale,
          })
          const toViewX = (x) => x
          const toViewY = (y) => pageH - y

          const move = (e) => {
            const world = toSheet(e.clientX, e.clientY)
            const wx = world.x
            const wy = world.y
            const near = nearestPort(wx, wy)
            // 0.25in magnet: close enough to a port and the end snaps there,
            // otherwise the end follows the pointer exactly.  Alt forces a free
            // drop even when a port is under the cursor.
            const magnet = near && Math.sqrt(near.d) <= 0.25 && !e.altKey
            const g = ghost('dshv-drop')
            const circle = g.querySelector('circle')
            const line = g.querySelector('line')
            const px = magnet ? near.port[0] : wx
            const py = magnet ? near.port[1] : wy
            circle.setAttribute('cx', toViewX(px))
            circle.setAttribute('cy', toViewY(py))
            line.setAttribute('x1', toViewX(px))
            line.setAttribute('y1', toViewY(py))
            line.setAttribute('x2', toViewX(wx))
            line.setAttribute('y2', toViewY(wy))
            g.style.display = ''
            circle.setAttribute('fill', magnet ? '#2FBF71' : '#2F6FBF')
            const tip = tipRef.current
            if (tip && tip.parentElement) {
              const host = tip.parentElement.getBoundingClientRect()
              tip.style.display = 'block'
              tip.style.left = `${e.clientX - host.left + 14}px`
              tip.style.top = `${e.clientY - host.top - 30}px`
              tip.textContent = magnet
                ? `${which === 'start' ? '新起点' : '新终点'} → #${near.id} (${near.port[0].toFixed(2)}, ${near.port[1].toFixed(2)})`
                : `${which === 'start' ? '新起点' : '新终点'} ${wx.toFixed(2)}, ${wy.toFixed(2)}${near ? '  (Alt 自由放置)' : ''}`
            }
          }

          const up = (e) => {
            window.removeEventListener('pointermove', move)
            window.removeEventListener('pointerup', up)
            const drop = svgEl.querySelector('#dshv-drop')
            if (drop) drop.remove()
            if (tipRef.current) tipRef.current.style.display = 'none'
            if (Math.abs(e.clientX - start.x) + Math.abs(e.clientY - start.y) < 3) return
            const world = toSheet(e.clientX, e.clientY)
            const near = nearestPort(world.x, world.y)
            const snapped = near && Math.sqrt(near.d) <= 0.25 && !e.altKey
            if (snapped) {
              runOp({ action: 'reglue', path: current.path, page: current.page,
                shape_id: shapeId, end: which, to: near.id, x: near.port[0], y: near.port[1] })
              return
            }
            // No port within 0.25in: drop the end exactly where the pointer is and
            // detach its glue, instead of refusing the drag with 未对准任何形状.
            runOp({ action: 'move_endpoint', path: current.path, page: current.page,
              shape_id: shapeId, end: which, x: world.x, y: world.y })
          }
          window.addEventListener('pointermove', move)
          window.addEventListener('pointerup', up)
          return
        }
        const band = event.target instanceof Element ? event.target.closest('[data-route-band]') : null
        const dot = band ? null : (event.target instanceof Element ? event.target.closest('[data-route-handle]') : null)
        // Grabbing the line BODY translates the whole connector; only the blue dot
        // adjusts a single run.  Previously both fell into the same handler, so a
        // plain click-and-drag on an existing line silently bent it into a jog.
        if (band && !dot) {
          event.preventDefault()
          event.stopPropagation()
          const current = docRef.current
          const svgEl = event.currentTarget.querySelector('svg')
          const id = band.getAttribute('data-route-band')
          const item = current && (current.shapes || []).find((s) => s.id === id)
          const hit = current && svgEl ? sheetOf(current, svgEl, event.clientX, event.clientY) : null
          if (!item || !hit || !svgEl) return
          const b0 = { ...item.bbox }
          const start = { x: event.clientX, y: event.clientY }
          let moved = false
          let dx = 0, dy = 0
          const node = svgEl.querySelector('[data-shape-id="' + id + '"]')
          const move = (e) => {
            dx = (e.clientX - start.x) / hit.scale
            dy = -(e.clientY - start.y) / hit.scale
            if (!moved && Math.hypot(dx, dy) < 0.04) return
            moved = true
            if (node) node.setAttribute('transform', `translate(${dx.toFixed(4)} ${(-dy).toFixed(4)})`)
            const tip = tipRef.current
            if (tip && tip.parentElement) {
              const host = tip.parentElement.getBoundingClientRect()
              tip.style.display = 'block'
              tip.style.left = `${e.clientX - host.left + 14}px`
              tip.style.top = `${e.clientY - host.top - 30}px`
              tip.textContent = `Δ ${dx.toFixed(2)}, ${dy.toFixed(2)} in`
            }
          }
          const up = () => {
            window.removeEventListener('pointermove', move)
            window.removeEventListener('pointerup', up)
            if (tipRef.current) tipRef.current.style.display = 'none'
            if (node) node.removeAttribute('transform')
            if (!moved) return
            runOp({ action: 'move', path: current.path, page: current.page, shape_id: id,
              x: b0.x + dx, y: b0.y + dy })
              .then((state) => { if (state) setDoc(state) })
          }
          window.addEventListener('pointermove', move)
          window.addEventListener('pointerup', up)
          return
        }
        const handle = dot
        if (handle) {
          event.preventDefault()
          const current = docRef.current
          const svgEl = event.currentTarget.querySelector('svg')
          if (!current || !svgEl) return
          const box = svgEl.getBoundingClientRect()
          const vb = svgEl.viewBox && svgEl.viewBox.baseVal ? svgEl.viewBox.baseVal : null
          if (!vb || !box.width) return
          const scale = box.width / vb.width
          const start = { x: event.clientX, y: event.clientY }
          const segIndex = Number(handle.getAttribute('data-seg') || 0)
          // Both handles name the connector the same way; the grab band used to read
          // data-route-handle and send shape_id:null, which the engine rejects, so
          // dragging the line itself silently did nothing.
          const shapeId = handle.getAttribute('data-route-band') || handle.getAttribute('data-route-handle')
          let axis = handle.getAttribute('data-axis')
          if (!axis) {
            const item = (current.shapes || []).find((x) => x.id === shapeId)
            const pts0 = (item && item.points && item.points.length >= 2) ? item.points : null
            if (pts0 && pts0[segIndex] && pts0[segIndex + 1]) {
              const a = pts0[segIndex]
              const b2 = pts0[segIndex + 1]
              axis = Math.abs(b2[0] - a[0]) < Math.abs(b2[1] - a[1]) ? 'x' : 'y'
            } else {
              axis = 'y'
            }
          }
          // Alignment assistance for the run being slid: a connector should line up
          // with the edges and centre lines of the shapes around it, exactly like a
          // dragged shape does.  Candidates are the same edges snapEdges collects.
          const item = (current.shapes || []).find((x) => x.id === shapeId)
          const pts0 = (item && item.points && item.points.length >= 2) ? item.points : []
          const seg0 = pts0[segIndex] && pts0[segIndex + 1]
            ? { a: pts0[segIndex], b: pts0[segIndex + 1] } : null
          const cands = snapEdges(item ? item.bbox : null, current.shapes, shapeId)
          const H = current.pageSize ? current.pageSize.h : 0
          const vertical = axis === 'x'
          // The run moves along one axis: horizontal runs slide up/down (their y
          // changes), vertical runs slide sideways (their x changes).
          const baseAt = vertical ? (seg0 ? seg0.a[0] : 0) : (seg0 ? seg0.a[1] : 0)
          let snapped = null
          // Magnetic, not sticky: a run only jumps when a reference line is within
          // SNAP_FINE.  The old 0.35in magnet covered a whole grid cell, so a small
          // drag landed on one of two nearby alignments and felt like two coarse
          // positions instead of a continuous move.  Shift disables the magnet.
          const snapRun = (raw, magnet = true) => {
            snapped = null
            if (!magnet) return raw
            const want = baseAt + raw
            const list = vertical ? cands.xs : cands.ys
            let best = null
            let dist = SNAP_FINE
            for (const v of list) {
              const d = Math.abs(v - want)
              if (d <= dist) { best = v; dist = d }
            }
            if (best === null) return raw
            snapped = best
            return best - baseAt
          }
          const drawSnap = (value) => {
            hideGuide(svgEl, 'dshv-conn-snap')
            if (value === null || !seg0) return
            if (vertical) {
              guideLine(svgEl, 'dshv-conn-snap', value, 0, value, H, '#2F6FBF')
            } else {
              guideLine(svgEl, 'dshv-conn-snap', 0, H - value, current.pageSize.w, H - value, '#2F6FBF')
            }
          }
          const move = (e) => {
            const dx = (e.clientX - start.x) / scale
            const dy = (e.clientY - start.y) / scale
            const raw = vertical ? dx : -dy
            const magnet = !e.shiftKey
            const value = snapRun(raw, magnet)
            drawSnap(magnet ? snapped : null)
            const tip = tipRef.current
            if (!tip || !tip.parentElement) return
            const host = tip.parentElement.getBoundingClientRect()
            tip.style.display = 'block'
            tip.style.left = `${e.clientX - host.left + 14}px`
            tip.style.top = `${e.clientY - host.top - 30}px`
            const label = axis === 'y' ? `竖直偏移 ${(-dy).toFixed(3)} in` : `水平偏移 ${dx.toFixed(3)} in`
            tip.textContent = magnet ? (snapped !== null ? `${label}   [对齐]` : label) : `${label}   [精细]`
          }
          const up = (e) => {
            window.removeEventListener('pointermove', move)
            window.removeEventListener('pointerup', up)
            if (tipRef.current) tipRef.current.style.display = 'none'
            hideGuide(svgEl, 'dshv-conn-snap')
            const dx = (e.clientX - start.x) / scale
            const dy = (e.clientY - start.y) / scale
            // pick the axis the run itself can move on: horizontal runs slide vertically,
            // vertical runs slide sideways.  Using the raw mouse axis made a horizontal
            // line ignore a sideways drag, which felt like "nothing moves".
            const raw = vertical ? dx : -dy
            const delta = snapRun(raw, !e.shiftKey)
            if (Math.abs(delta) < 0.004) return
            runOp({ action: 'move_segment', path: current.path, page: current.page,
              shape_id: shapeId, index: segIndex, delta })
          }
          window.addEventListener('pointermove', move)
          window.addEventListener('pointerup', up)
          return
        }
        const guide = event.target instanceof Element ? event.target.closest('[data-guide]') : null
        if (guide) {
          event.preventDefault()
          event.stopPropagation()
          useGuide(guide.getAttribute('data-guide'))
          return
        }
        const current = docRef.current
        const node = event.target instanceof Element ? event.target.closest('[data-shape-id]') : null
        if (!current || !node) return
        const id = node.getAttribute('data-shape-id')
        const target = current.shapes.find((item) => item.id === id)
        const svg = event.currentTarget.querySelector('svg')
        if (!target || !svg) return
        const box = svg.getBoundingClientRect()
        const vbBox = svg.viewBox && svg.viewBox.baseVal ? svg.viewBox.baseVal : null
        const viewWidth = vbBox ? vbBox.width : 0
        const scale = viewWidth > 0 && box.width > 0 ? box.width / viewWidth : 96
        event.preventDefault()
        const applied = node.getAttribute('transform') || ''
        const matched = /translate\(([-\d.]+)[ ,]+([-\d.]+)\)/.exec(applied)
        dragRef.current = {
          id, node, bbox: target.bbox,
          startX: event.clientX, startY: event.clientY,
          base: matched ? { x: Number(matched[1]), y: Number(matched[2]) } : { x: 0, y: 0 },
          scale, dx: 0, dy: 0, moved: false,
          isConn: !!target.connector,
          cands: (target.connector || target.line) ? null : snapEdges(target.bbox, current.shapes, id),
          svg: svg,
          pageH: current.pageSize ? current.pageSize.h : 0,
          pageW: current.pageSize ? current.pageSize.w : 0,
          onText: event.target instanceof Element && event.target.tagName.toLowerCase() === 'text',
          textNode: event.target instanceof Element && event.target.tagName.toLowerCase() === 'text' ? event.target : null,
        }
        window.addEventListener('pointermove', moveDrag)
        window.addEventListener('pointerup', upDrag)
        // A release outside the window (or an OS-level cancel) used to leave the
        // shape at 0.85 opacity, mid-transform, with a stale selection box.
        window.addEventListener('pointercancel', upDrag)
        window.addEventListener('blur', upDrag)
      }

      // The engine pads the SVG viewBox by 0.25in and may extend it to fit shapes
      // that spill past the page.  The drawing therefore scales by the VIEWBOX
      // size, not by the paper size.  Both the page element and the grid must use
      // that same factor, otherwise cells look square locally but drift against
      // the shapes (and stretch if the viewBox aspect differs from the paper).
      const vb = (() => {
        if (!doc || !doc.svg) return { x: 0, y: 0, w: doc ? doc.pageSize.w : 11, h: doc ? doc.pageSize.h : 8.5 }
        const m = /viewBox="([-\d.]+)\s+([-\d.]+)\s+([-\d.]+)\s+([-\d.]+)"/.exec(doc.svg)
        return m ? { x: +m[1], y: +m[2], w: +m[3], h: +m[4] }
          : { x: 0, y: 0, w: doc.pageSize.w, h: doc.pageSize.h }
      })()
      const viewRatio = vb.h / vb.w
      const availW = pane.w > 0 ? pane.w - 40 : 0
      const availH = pane.h > 0 ? pane.h - 40 : 0
      const naturalW = doc ? Math.round(vb.w * 96) : 0
      const fitW = availW > 80 ? availW : naturalW
      const fitH = availH > 80 && viewRatio > 0 ? Math.round(availH / viewRatio) : fitW
      const fitBox = doc ? Math.max(120, Math.round(Math.min(fitW, fitH, naturalW))) : 0
      // pageBox is the WIDTH OF THE SVG (viewBox), not the paper width.
      const pageBox = Math.round(fitBox * (zoom ?? 1))
      // Pixels per drawing inch, measured from the SVG, valid on BOTH axes.
      const pxPerIn = pageBox / vb.w
      // One cell is 0.25 drawing inch, using the SAME px/inch as the shapes.
      let gridStepIn = 0.25
      let gridUnit = pxPerIn * gridStepIn
      while (gridUnit < 6 && gridStepIn < 4) {
        gridStepIn *= 2
        gridUnit = pxPerIn * gridStepIn
      }
      while (gridUnit > 48 && gridStepIn > 0.0625) {
        gridStepIn /= 2
        gridUnit = pxPerIn * gridStepIn
      }
      // The grid is a reference, not decoration: at 0.22/0.42 grey it competed
      // with the connector lines drawn over it.  Fine cells also disappear when
      // they would be denser than ~12px, so a zoomed-out map keeps only the 4x
      // rhythm instead of turning into graph paper.
      const showMinorGrid = gridUnit >= 12
      const gridSize = (showMinorGrid
        ? `${gridUnit}px ${gridUnit}px, ${gridUnit}px ${gridUnit}px, `
        : '') + `${gridUnit * 4}px ${gridUnit * 4}px, ${gridUnit * 4}px ${gridUnit * 4}px`
      // A multiple of BOTH the small and the large cell, so extending the grid
      // left/up by this amount keeps every line in phase with the page origin.
      const gridPad = Math.ceil(5000 / (gridUnit * 4)) * (gridUnit * 4)
      const gridLayers = (showMinorGrid ? [
        'linear-gradient(to right, rgba(120,132,150,0.07) 1px, transparent 1px)',
        'linear-gradient(to bottom, rgba(120,132,150,0.07) 1px, transparent 1px)',
      ] : [])
      gridLayers.push(
        'linear-gradient(to right, rgba(120,132,150,0.15) 1px, transparent 1px)',
        'linear-gradient(to bottom, rgba(120,132,150,0.15) 1px, transparent 1px)',
      )
      const gridImage = gridLayers.join(',')

      const pythonBroken = config && config.pythonOk === false
      const nothingOpen = !doc

      return h('div', { className: 'dshv-root', ref: rootRef, tabIndex: 0,
          // Keyboard shortcuts need a focus owner: clicking any control in the
          // panel focuses the root, so keydown targets the panel instead of the
          // host shell.  tabIndex also makes it reachable with Tab.
          onPointerDownCapture: () => { try { rootRef.current && rootRef.current.focus({ preventScroll: true }) } catch (e) { /* ignore */ } },
        },
        h('style', null, CSS),
        h('style', null, CSS_POLISH),
        h('style', null, CSS_FLOAT),
        h('div', { className: 'dshv-head' },
          h('div', { className: 'dshv-headText' },
            h('div', { className: 'dshv-title' }, doc ? doc.name : t('title')),
            h('div', { className: 'dshv-sub' },
              doc
                ? `${doc.path} · ${t('pageOf', { page: doc.page, total: doc.pageCount })} · ${t('shapesCount', { count: doc.shapes.length })}`
                : t('subtitle'))),
          h('div', { className: 'dshv-actions' },
            h('button', { type: 'button',
              className: `dshv-toggle${treeOpen ? ' on' : ''}`,
              title: t('toggleTree'),
              onClick: () => setTreeOpen((value) => !value),
            }, '☰'),
            h('button', { type: 'button',
              className: `dshv-toggle${inspectorOpen ? ' on' : ''}`,
              title: t('toggleInspector'),
              onClick: () => setInspectorOpen((value) => !value),
            }, '▤'),
            h(Btn, {
              variant: 'ghost',
              onClick: () => undoTo('undo'),
              title: t('undoHint'),
              disabled: busy || !(doc && doc.canUndo),
            }, `${String.fromCharCode(8630)} ${t('undo')}`),
            h(Btn, {
              variant: 'ghost',
              onClick: () => undoTo('redo'),
              title: t('redoHint'),
              disabled: busy || !(doc && doc.canRedo),
            }, `${String.fromCharCode(8631)} ${t('redo')}`),
            doc ? h(Btn, { variant: 'ghost', onClick: exportPng, title: t('exportPng'), disabled: busy }, t('export')) : null,
            h(Btn, {
              variant: 'ghost',
              onClick: () => loadFolder(folder || folderDraft),
              title: t('refresh'),
              disabled: !folder,
            }, t('refresh')),
            doc ? h(Btn, { variant: 'ghost', onClick: audit, title: t('validate') }, t('validate')) : null,
            doc ? h(Btn, {
              variant: 'ghost',
              title: t('fixUnitsTip'),
              onClick: () => runOp({ action: 'normalize', path: doc.path, page: doc.page }),
            }, t('fixUnits')) : null,
            h(Btn, { onClick: () => setCreateOpen(true), disabled: !folder && !config?.defaultFolder }, t('newFile')))),
        h('div', { className: 'dshv-body' },
          h('div', { className: 'dshv-pane dshv-left', style: treeOpen ? undefined : { display: 'none' } },
            h('div', { className: 'dshv-section' },
              h('div', { className: 'dshv-sectionTitle' }, t('folder')),
              h('div', { className: 'dshv-row' },
                h('input', {
                  className: 'dshv-input',
                  value: folderDraft,
                  spellCheck: false,
                  onChange: (e) => setFolderDraft(e.target.value),
                  onKeyDown: (e) => { if (e.key === 'Enter') loadFolder(e.currentTarget.value) },
                }),
                h(Btn, { small: true, onClick: chooseFolder, title: t('chooseFolder') }, '…'),
                h(Btn, { small: true, onClick: () => loadFolder(folderDraft), disabled: filesBusy }, t('openFile')))),
            h('div', { className: 'dshv-tabs' },
              h('button', { type: 'button', className: `dshv-tab${tab === 'shapes' ? ' active' : ''}`, onClick: () => setTab('shapes') }, t('shapes')),
              h('button', { type: 'button', className: `dshv-tab${tab === 'pages' ? ' active' : ''}`, onClick: () => setTab('pages') }, `${t('pages')}${doc && Array.isArray(doc.pages) ? ` (${doc.pages.length})` : ''}`)),
            tab === 'pages'
              ? h('div', { className: 'dshv-files' },
                  doc && Array.isArray(doc.pages) && doc.pages.length
                    ? doc.pages.map((page) => h('div', {
                        key: page.index,
                        className: `dshv-file${page.index === doc.page ? ' active' : ''}`,
                        onClick: () => openFile(doc.path, page.index),
                      },
                      h('div', { className: 'dshv-fileName' }, `${page.index}. ${page.name || t('page')}`),
                      h('div', { className: 'dshv-fileMeta' }, `${fmtInches(page.width)}×${fmtInches(page.height)}`)))
                    : h('div', { className: 'dshv-hint', style: { padding: 12 } }, t('noDocBody')))
              : h('div', { className: 'dshv-shapeList' },
                  doc
                    ? (doc.shapes.length
                        ? doc.shapes.map((item) => h('div', {
                            key: item.id,
                            className: `dshv-shapeRow${item.id === selected ? ' active' : ''}`,
                            onClick: () => openSelected(item.id),
                            title: `${shapeKindLabel(item, t)} #${item.id}`,
                          },
                          h('span', { className: 'dshv-shapeId' }, `#${item.id}`),
                          h('span', { className: 'dshv-shapeText' }, shapeTitle(item, t)),
                          h('span', { className: 'dshv-shapeKind' }, shapeKindLabel(item, t))))
                        : h('div', { className: 'dshv-hint', style: { padding: 12 } }, t('noShapes')))
                    : h('div', { className: 'dshv-hint', style: { padding: 12 } }, t('emptyFolder'))),
            h('div', { className: 'dshv-section', style: { marginTop: 'auto' } },
              h('div', { className: 'dshv-sectionTitle' }, t('files')),
              h('div', { className: 'dshv-files', style: { maxHeight: 180 } },
                filesBusy
                  ? h('div', { className: 'dshv-hint' }, t('refreshing'))
                  : files.length
                    ? files.map((file) => h('div', {
                        key: file.path,
                        className: `dshv-file${doc && doc.path === file.path ? ' active' : ''}`,
                        onClick: () => openFile(file.path, 1),
                        title: file.path,
                      },
                      h('div', { className: 'dshv-fileName' }, file.name),
                      h('div', { className: 'dshv-fileMeta' }, `${Math.max(1, Math.round(file.size / 1024))} KB`)))
                    : h('div', { className: 'dshv-hint' }, filesError || t('noFiles'))),
              h('div', { className: 'dshv-hint', style: { marginTop: 6 } }, t('readOnlyHint'))),
            h('div', { className: 'dshv-section' },
              h('div', { className: 'dshv-sectionTitle' }, t('tools')),
              h('div', { className: 'dshv-kinds' },
                SHAPE_KINDS.map((item) => h('button', { type: 'button',
                  key: item.kind,
                  title: isZh ? item.zh : item.en,
                  disabled: !doc,
                  // A line is drawn on the canvas instead of being dropped in the
                  // middle of the page as a box: picking the tool arms the canvas,
                  // the next drag decides where it starts and ends.
                  onClick: () => {
                    if (item.kind === 'line') {
                      setTool((v) => (v === 'line' ? 'select' : 'line'))
                      setNotice(t(tool === 'line' ? 'lineToolOff' : 'lineToolOn'))
                      return
                    }
                    addShape(item.kind)
                  },
                  className: 'dshv-kind' + (item.kind === 'line' && tool === 'line' ? ' on' : ''),
                }, h('span', { className: 'dshv-kindGlyph' }, item.glyph), h('span', null, isZh ? item.zh : item.en))))),
            h('div', { className: 'dshv-section' },
              h('button', { type: 'button',
                className: 'dshv-sectionTitle dshv-fold',
                onClick: () => setStencilOpen((v) => !v),
              },
              h('span', { className: 'dshv-foldIcon' }, stencilOpen ? '\u25BE' : '\u25B8'),
              h('span', null, t('stencil'))),
              stencilOpen ? h('div', null,
              h('div', { className: 'dshv-row' },
                h('input', {
                  className: 'dshv-input',
                  placeholder: t('stencilPlaceholder'),
                  value: stencilPath,
                  onChange: (event) => setStencilPath(event.target.value),
                }),
                h(Btn, { small: true, disabled: !stencilPath.trim(), onClick: loadStencil }, t('load'))),
              stencilMasters.length
                ? h('div', { className: 'dshv-kinds', style: { marginTop: 8 } },
                    stencilMasters.map((master) => h('button', { type: 'button',
                      key: master.id,
                      className: 'dshv-kind',
                      title: `${master.name} (#${master.id})`,
                      disabled: !doc,
                      onClick: () => insertMaster(master),
                    }, h('span', { className: 'dshv-kindGlyph' }, '\u25C8'), h('span', null, master.name))))
                : h('div', { className: 'dshv-hint', style: { marginTop: 6 } }, t('stencilHint'))) : null)),

          h('div', { className: 'dshv-pane dshv-center' },
            nothingOpen
              ? h('div', { className: 'dshv-empty' },
                  h(Icon, { size: 40 }),
                  h('h2', null, t('noDocTitle')),
                  h('p', null, pythonBroken ? t('pythonMissing') : t('noDocBody')),
                  h('div', { className: 'dshv-row', style: { marginTop: 8 } },
                    h(Btn, { onClick: () => setCreateOpen(true), disabled: !folder && !config?.defaultFolder }, t('newFile')),
                    h(Btn, { variant: 'ghost', onClick: chooseFolder }, t('chooseFolder'))))
              : h('div', { className: 'dshv-canvasOuter' },
                  h('div', {
                    className: `dshv-canvasWrap${tool === 'hand' ? ' dshv-hand' : ''}`,
                    ref: canvasBox,
                    style: { backgroundColor: '#F3F5F8' },
                  },
                    h('div', { className: 'dshv-canvasInner' },
                      h('div', { ref: pageRef, className: 'dshv-page', style: {
                        aspectRatio: `${vb.w} / ${vb.h}`,
                        width: `${pageBox}px`,
                        // The page carries its OWN grid as a CSS background so the
                        // SVG (opaque shape fills) is always painted on top of it.
                        // A separate grid layer only covers the area OUTSIDE the page;
                        // putting it above the svg made grid lines show through nodes.
                        backgroundColor: '#FFFFFF',
                        backgroundImage: showGrid ? gridImage : 'none',
                        backgroundSize: gridSize,
                        // The page box starts at the SVG's (vb.x, vb.y), not at the
                        // drawing origin; without this shift the page net sits 0.25in
                        // off the workspace net at the page border.
                        backgroundPosition: (-vb.x * pxPerIn).toFixed(2) + 'px ' + (-vb.y * pxPerIn).toFixed(2) + 'px',
                        boxShadow: '0 0 0 1.5px rgba(53,86,148,0.75), 0 10px 30px rgba(0,0,0,0.18)',
                        flex: '0 0 auto',
                        maxWidth: 'none',
                      } },

                      showGrid ? h('div', {
                        className: 'dshv-gridLayer',
                        style: {
                          // Anchored INSIDE the page box, so the page's padding is part of
                          // the same coordinate system: the net outside the paper is the
                          // continuation of the net on it, to the pixel.
                          left: `calc(${-gridPad}px + ${(-vb.x * pxPerIn).toFixed(4)}px)`,
                          top: `calc(${-gridPad}px + ${(-vb.y * pxPerIn).toFixed(4)}px)`,
                          width: `calc(100% + ${gridPad * 2}px)`,
                          height: `calc(100% + ${gridPad * 2}px)`,
                          backgroundImage: gridImage,
                          backgroundSize: gridSize,
                          backgroundPosition: `${gridPad}px ${gridPad}px`,
                        },
                      }) : null,
                      h('div', {
                        className: 'dshv-svgHost',
                        onClick: onCanvasClick,
                        onPointerDown: onCanvasPointerDown,
                        onPointerMove: onCanvasPointerMove,
                        onPointerLeave: onCanvasPointerLeave,
                        onContextMenu: (e) => e.preventDefault(),
                        dangerouslySetInnerHTML: { __html: withSelection(doc.svg, shape, doc.pageSize.h) },
                        style: { width: '100%', height: '100%' },
                      }),
                      ))),
                  h('div', { className: 'dshv-dragtip', ref: tipRef, style: { display: 'none' } }),
                  h('div', { className: 'dshv-dock' }, h('div', { className: 'dshv-zoom' },
                    h('button', { type: 'button', className: 'dshv-zbtn', title: t('zoomOut'), onClick: () => setZoom((v) => Math.max(0.15, Math.round((v ?? 1) * 0.8 * 1000) / 1000)) }, '\u2212'),
                    h('button', { type: 'button', className: 'dshv-zbtn dshv-zfit', title: t('zoomFit'), onClick: () => setZoom(null) }, zoom ? `${Math.round(zoom * 100)}%` : t('zoomFit')),
                    h('button', { type: 'button', className: 'dshv-zbtn', title: t('zoomIn'), onClick: () => setZoom((v) => Math.min(8, Math.round((v ?? 1) * 1.25 * 1000) / 1000)) }, '+'),
                    h('button', { type: 'button',
                      className: `dshv-zbtn${tool === 'link' ? ' on' : ''}`,
                      title: t('linkTool'),
                      onClick: () => { setTool((v) => (v === 'link' ? 'select' : 'link')); setLinkFrom(null) },
                    }, '\u2192'),
                    h('button', { type: 'button',
                      className: `dshv-zbtn${tool === 'hand' ? ' on' : ''}`,
                      title: t('handTool'),
                      onClick: () => setTool((v) => (v === 'hand' ? 'select' : 'hand')),
                    }, '\u270B'),
                    h('button', { type: 'button',
                      className: `dshv-zbtn${showGrid ? ' on' : ''}`,
                      title: t('gridToggle'),
                      onClick: () => setShowGrid((v) => !v),
                    }, '▦'))))),

          h('div', { className: 'dshv-pane dshv-right', style: inspectorOpen ? undefined : { display: 'none' } },
            detail
              ? h(ShapeInspector, {
                  t,
                  doc,
                  shape,
                  detail,
                  onCommitText: commitText,
                  onCommitCell: commitCell,
                  onCommitMove: commitMove,
                  onCommitLine: commitLine,
                  onSetProp: setProp,
                  onDelete: removeShape,
                  onConnect: connectTo,
              onRouteStyle: routeStyle, onEndDirection: endDirection,
                  onDeselect: () => setSelected(null),
                })
              : h('div', { className: 'dshv-empty', style: { padding: 24 } },
                  h('p', null, doc ? t('selectShape') : t('noDocBody'))))),

        h('div', { className: 'dshv-status' },
          busy ? h('span', { className: 'dshv-row' }, h('span', { className: 'dshv-spinner' }), t('busy')) : null,
          error ? h('span', { className: 'err' }, error) : null,
          !error && notice ? h('span', { className: 'ok' }, notice) : null,
          !error && !notice && !busy ? h('span', null, doc ? doc.path : t('preview')) : null,
          config && config.pythonOk === false ? h('span', { className: 'err' }, t('pythonMissing')) : null,
          configError ? h('span', { className: 'err' }, configError) : null,
          h('span', { className: 'dshv-grow' }),
          doc ? h('span', { className: 'dshv-ver', title: t('shortcutHint') }, t('shortcutHint')) : null,
          h('span', { className: 'dshv-ver', title: 'client build' }, 'v' + CLIENT_BUILD),
          doc ? h('span', { className: 'dshv-badge' }, t('autosave')) : null),

        createOpen
          ? h(CreateDialog, {
              t,
              initialFolder: folder || folderDraft || config?.defaultFolder || '',
              pickFolder,
              onCancel: () => setCreateOpen(false),
              onCreate: async (payload) => {
                const state = await runOp({ action: 'create', ...payload })
                if (state) {
                  setCreateOpen(false)
                  setFolder(state.folder)
                  setFolderDraft(state.folder)
                  await loadFolder(state.folder)
                }
              },
              error,
            })
          : null)
    }

    /* ------------------------------------------------------------ inspector */

    function ShapeInspector({ t, doc, shape, detail, onCommitText, onCommitCell, onCommitMove, onCommitLine, onSetProp, onDelete, onConnect, onRouteStyle, onEndDirection, onDeselect }) {
      const [text, setText] = useState(detail.text || '')
      const [propName, setPropName] = useState('')
      const [propValue, setPropValue] = useState('')
      const [connectTarget, setConnectTarget] = useState('')
      const [connectLabel, setConnectLabel] = useState('')
      const textTimer = useRef(null)
      const shapeId = detail.id

      useEffect(() => {
        setText(detail.text || '')
        setPropName('')
        setPropValue('')
        setConnectTarget('')
        setConnectLabel('')
      }, [shapeId])

      // Commit on blur only: a debounce used to fire mid-IME-composition and the
      // controlled textarea then dropped characters while the user was typing.
      const commitText = () => {
        if (text !== (detail.text || '')) onCommitText(text)
      }

      const bbox = shape?.bbox || { x: 0, y: 0, w: 0, h: 0 }
      // A line has no width/height worth editing: show its two end points instead.
      const linePts = (shape && shape.line && shape.points && shape.points.length >= 2) ? shape.points : null
      const page = (doc && doc.pageSize) || { w: 11, h: 8.5 }
      const clampBox = (patch) => {
        const w = Math.min(Math.max(0.05, patch.w ?? bbox.w), page.w)
        const h = Math.min(Math.max(0.05, patch.h ?? bbox.h), page.h)
        return {
          w,
          h,
          x: Math.min(Math.max(0, patch.x ?? bbox.x), Math.max(0, page.w - w)),
          y: Math.min(Math.max(0, patch.y ?? bbox.y), Math.max(0, page.h - h)),
        }
      }
      const outOfPage = bbox.x < -0.001 || bbox.y < -0.001
        || bbox.x + bbox.w > page.w + 0.001 || bbox.y + bbox.h > page.h + 0.001
      const style = detail.style || {}
      const candidates = (doc.shapes || []).filter((item) => item.id !== shapeId && !item.connector)
      const props = Object.entries(detail.props || {})

      return h('div', null,
        h('div', { className: 'dshv-section' },
          h('div', { className: 'dshv-sectionTitle' },
            h('span', null, `${t('shape')} #${detail.id}`),
            h(Btn, { small: true, variant: 'ghost', onClick: onDeselect }, t('deselect'))),
          h('div', { className: 'dshv-hint' },
            [detail.master || (shape ? shapeKindLabel(shape, t) : ''),
             detail.type,
             shape && shape.connects && shape.connects.length ? `→ ${shape.connects.map((c) => '#' + c.to).join(', ')}` : '']
              .filter(Boolean).join(' · '))),

        h('div', { className: 'dshv-section' },
          h('div', { className: 'dshv-sectionTitle' }, t('text')),
          h('textarea', {
            className: 'dshv-input',
            rows: 3,
            value: text,
            placeholder: t('textPlaceholder'),
            onChange: (e) => setText(e.target.value),
            onBlur: commitText,
            onKeyDown: (e) => { if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) e.currentTarget.blur() },
          })),

        detail.type === 'Shape' && shape && shape.connector
          ? h('div', { className: 'dshv-section' },
              h('div', { className: 'dshv-sectionTitle' }, t('route')),
              h('div', { className: 'dshv-hint' }, t('routeHint')),
              h('div', { className: 'dshv-routeRow' },
                h('span', { className: 'dshv-miniLabel' }, '起点方向'),
                ...[['top', '↑'], ['bottom', '↓'], ['left', '←'], ['right', '→']].map(([dir, glyph]) =>
                  h(Btn, { key: 'start-' + dir, small: true, variant: 'ghost',
                    title: '从 ' + dir + ' 侧引出', onClick: () => onEndDirection('start', dir) }, glyph))),
              h('div', { className: 'dshv-routeRow' },
                h('span', { className: 'dshv-miniLabel' }, '终点方向'),
                ...[['top', '↑'], ['bottom', '↓'], ['left', '←'], ['right', '→']].map(([dir, glyph]) =>
                  h(Btn, { key: 'end-' + dir, small: true, variant: 'ghost',
                    title: '从 ' + dir + ' 侧进入', onClick: () => onEndDirection('end', dir) }, glyph))),
              h('div', { className: 'dshv-routeRow' },
                h(Btn, { small: true, variant: 'ghost', onClick: () => onRouteStyle('auto') }, t('route_auto'))))
          : null,

        h('div', { className: 'dshv-section' },
          h('div', { className: 'dshv-sectionTitle' }, t('geometry')),
          linePts
            ? h('div', { className: 'dshv-grid4' },
                h(NumberField, { label: 'X1', value: linePts[0][0], onCommit: (v) => onCommitLine([v, linePts[0][1]], [linePts[1][0], linePts[1][1]]) }),
                h(NumberField, { label: 'Y1', value: linePts[0][1], onCommit: (v) => onCommitLine([linePts[0][0], v], [linePts[1][0], linePts[1][1]]) }),
                h(NumberField, { label: 'X2', value: linePts[1][0], onCommit: (v) => onCommitLine([linePts[0][0], linePts[0][1]], [v, linePts[1][1]]) }),
                h(NumberField, { label: 'Y2', value: linePts[1][1], onCommit: (v) => onCommitLine([linePts[0][0], linePts[0][1]], [linePts[1][0], v]) }))
            : h('div', { className: 'dshv-grid4' },
                h(NumberField, { label: t('x'), value: bbox.x, onCommit: (x) => onCommitMove(clampBox({ x })) }),
                h(NumberField, { label: t('y'), value: bbox.y, onCommit: (y) => onCommitMove(clampBox({ y })) }),
                h(NumberField, { label: t('width'), value: bbox.w, onCommit: (w) => onCommitMove(clampBox({ w })) }),
                h(NumberField, { label: t('height'), value: bbox.h, onCommit: (h) => onCommitMove(clampBox({ h })) })),
          linePts ? null : h('div', { className: 'dshv-grid4', style: { marginTop: 6 } },
            h(NumberField, { label: t('rotation'), value: shape.angle || 0, step: 15,
              onCommit: (v) => onCommitMove({ angle: v }) }),
            h('div'), h('div'), h('div')),
          outOfPage
            ? h('div', { className: 'dshv-warn' },
                h('span', null, t('outOfPage')),
                h(Btn, { small: true, variant: 'ghost', onClick: () => onCommitMove(clampBox({})) }, t('snapBack')))
            : null),

        h('div', { className: 'dshv-section' },
          h('div', { className: 'dshv-sectionTitle' }, t('style')),
          h('label', { className: 'dshv-check', title: t('textBgHint') },
            h('input', {
              type: 'checkbox',
              checked: Number(detail.cells && detail.cells.TextBkgnd ? detail.cells.TextBkgnd : 0) !== 0,
              onChange: (e) => onCommitCell({ TextBkgnd: e.target.checked ? 1 : 0 }),
            }),
            h('span', null, t('textBg'))),
          h(ColorField, { label: t('fill'), value: style.fill, onCommit: (v) => onCommitCell({ FillForegnd: v, FillBkgnd: v }) }),
          h(ColorField, { label: t('line'), value: style.line, onCommit: (v) => onCommitCell({ LineColor: v }) }),
          h(Field, { label: t('weight') },
            h('input', {
              className: 'dshv-input',
              type: 'number',
              step: 0.25,
              defaultValue: (() => {
                const weight = Number(style.weight)
                return Number.isFinite(weight) && weight > 0 ? Math.round(weight * 72 * 4) / 4 : 0.75
              })(),
              key: `${shapeId}-weight`,
              onBlur: (e) => {
                const pt = Number(e.target.value)
                if (Number.isFinite(pt) && pt >= 0) onCommitCell({ LineWeight: pt / 72 })
              },
              onKeyDown: (e) => { if (e.key === 'Enter') e.currentTarget.blur() },
            }))),
            h('div', { className: 'dshv-routeRow', style: { marginTop: 6 } },
              h('span', { className: 'dshv-miniLabel' }, '线型'),
              ...[['实线', 1], ['虚线', 2], ['点线', 3], ['点划线', 4], ['无', 0]].map(([label, value]) =>
                h(Btn, { key: 'lp-' + value, small: true,
                  variant: Number((detail.cells && detail.cells.LinePattern) || 1) === value ? 'primary' : 'ghost',
                  onClick: () => onCommitCell({ LinePattern: value }) }, label))),

        h('div', { className: 'dshv-section' },
          h('div', { className: 'dshv-sectionTitle' }, t('shapeData')),
          props.length
            ? props.map(([name, value]) => h('div', { className: 'dshv-propRow', key: name },
                h('span', { className: 'dshv-propName', title: name }, name),
                h('input', {
                  className: 'dshv-input',
                  defaultValue: value,
                  onBlur: (e) => { if (e.target.value !== value) onSetProp(name, e.target.value) },
                  onKeyDown: (e) => { if (e.key === 'Enter') e.currentTarget.blur() },
                })))
            : h('div', { className: 'dshv-hint' }, '—'),
          h('div', { className: 'dshv-propRow', style: { marginTop: 6 } },
            h('input', { className: 'dshv-input', placeholder: t('propName'), value: propName, onChange: (e) => setPropName(e.target.value) }),
            h('input', { className: 'dshv-input', placeholder: t('propValue'), value: propValue, onChange: (e) => setPropValue(e.target.value) }),
            h(Btn, {
              small: true,
              disabled: !propName.trim(),
              onClick: () => {
                onSetProp(propName.trim(), propValue)
                setPropName('')
                setPropValue('')
              },
            }, t('addProp')))),

        h('div', { className: 'dshv-section' },
          h('div', { className: 'dshv-sectionTitle' }, t('connectTo')),
          h('div', { className: 'dshv-row' },
            h('select', {
              className: 'dshv-input',
              value: connectTarget,
              onChange: (e) => setConnectTarget(e.target.value),
            },
            h('option', { value: '' }, '—'),
            candidates.map((item) => h('option', { key: item.id, value: item.id }, `#${item.id} ${shapeTitle(item, t)}`))),
            h(Btn, { small: true, disabled: !connectTarget, onClick: () => onConnect(connectTarget, connectLabel) }, t('connect'))),
          h('input', {
            className: 'dshv-input',
            style: { marginTop: 6 },
            placeholder: t('connectLabel'),
            value: connectLabel,
            onChange: (e) => setConnectLabel(e.target.value),
          })),

        h('div', { className: 'dshv-section' },
          h(Btn, { variant: 'danger', onClick: onDelete }, t('deleteShape'))))
    }

    /* --------------------------------------------------------------- dialog */

    function CreateDialog({ t, initialFolder, pickFolder, onCancel, onCreate, error }) {
      const [name, setName] = useState('drawing')
      const [sizeId, setSizeId] = useState('a4l')
      const [customW, setCustomW] = useState('11')
      const [customH, setCustomH] = useState('8.5')
      const [title, setTitle] = useState('')
      const [folder, setFolder] = useState(initialFolder || '')
      const [busy, setBusy] = useState(false)

      const submit = async () => {
        const preset = SIZES.find((item) => item.id === sizeId)
        const width = preset ? preset.w : Number(customW)
        const height = preset ? preset.h : Number(customH)
        if (!Number.isFinite(width) || !Number.isFinite(height) || width <= 0 || height <= 0) return
        setBusy(true)
        try {
          await onCreate({ dir: folder, name: name.trim() || 'drawing', width, height, title: title.trim() })
        } finally {
          setBusy(false)
        }
      }

      return h('div', { className: 'dshv-overlayDialog', onMouseDown: (e) => { if (e.target === e.currentTarget) onCancel() } },
        h('div', { className: 'dshv-dialog' },
          h('h3', null, t('createTitle')),
          h(Field, { label: t('createName') },
            h('input', { className: 'dshv-input', value: name, onChange: (e) => setName(e.target.value), autoFocus: true })),
          h('div', { className: 'dshv-hint', style: { margin: '-2px 0 8px 82px' } }, t('createNameHint')),
          h(Field, { label: t('createPage') },
            h('select', { className: 'dshv-input', value: sizeId, onChange: (e) => setSizeId(e.target.value) },
              SIZES.map((item) => h('option', { key: item.id, value: item.id }, t(item.label))),
              h('option', { value: 'custom' }, t('createCustom')))),
          sizeId === 'custom'
            ? h('div', { className: 'dshv-row', style: { marginLeft: 82, marginBottom: 6 } },
                h('input', { className: 'dshv-input', type: 'number', value: customW, onChange: (e) => setCustomW(e.target.value) }),
                h('span', { className: 'dshv-hint' }, '×'),
                h('input', { className: 'dshv-input', type: 'number', value: customH, onChange: (e) => setCustomH(e.target.value) }))
            : null,
          h(Field, { label: t('createTitleField') },
            h('input', { className: 'dshv-input', value: title, onChange: (e) => setTitle(e.target.value) })),
          h('div', { className: 'dshv-hint', style: { margin: '-2px 0 8px 82px' } }, t('createTitleHint')),
          h(Field, { label: t('createIn') },
            h('input', { className: 'dshv-input', value: folder, onChange: (e) => setFolder(e.target.value) }),
            h(Btn, {
              small: true,
              onClick: async () => {
                const picked = await pickFolder()
                if (picked) setFolder(picked)
              },
            }, '…')),
          error ? h('div', { className: 'dshv-hint', style: { color: 'var(--dsw-alias-state-error-primary)', marginTop: 8 } }, error) : null,
          h('div', { className: 'dshv-dialogActions' },
            h(Btn, { variant: 'ghost', onClick: onCancel }, t('cancel')),
            h(Btn, { variant: 'primary', disabled: busy || !folder, onClick: submit }, t('create')))))
    }

    /* ------------------------------------------------------------------ css */

    const FLOAT_GEOM = 'dsh-visio.float.geom.v2'

    const CSS_FLOAT = `
.dshv-fab{pointer-events:auto;position:fixed;right:20px;bottom:20px;z-index:2147482000;display:flex;align-items:center;gap:6px;
  padding:8px 13px;border-radius:999px;background:var(--dsw-alias-bg-overlay);color:var(--dsw-alias-label-primary);
  border:1px solid var(--dsw-alias-border-l2);box-shadow:0 8px 22px rgba(0,0,0,.18);cursor:pointer;font-size:12px;
  font-weight:600;font-family:inherit;user-select:none}
.dshv-fab:hover{border-color:var(--dsw-alias-brand-primary)}
.dshv-fab.active{background:var(--dsw-alias-brand-primary);color:#fff;border-color:transparent}
.dshv-float{pointer-events:auto;position:fixed;z-index:2147482100;display:flex;flex-direction:column;background:var(--dsw-alias-bg-base);
  border:1px solid var(--dsw-alias-border-l2);border-radius:12px;overflow:hidden;
  box-shadow:0 24px 60px rgba(0,0,0,.26), 0 2px 8px rgba(0,0,0,.12)}
.dshv-floatBar{height:34px;flex:0 0 34px;display:flex;align-items:center;justify-content:space-between;gap:8px;
  padding:0 6px 0 12px;background:var(--dsw-alias-bg-layer-2);border-bottom:1px solid var(--dsw-alias-border-l1);
  cursor:move;user-select:none;touch-action:none}
.dshv-floatTitle{font-size:12px;font-weight:600;color:var(--dsw-alias-label-primary);overflow:hidden;white-space:nowrap;text-overflow:ellipsis}
.dshv-floatClose{width:24px;height:24px;border:0;border-radius:6px;background:transparent;color:var(--dsw-alias-label-secondary);
  font-size:16px;line-height:1;cursor:pointer}
.dshv-floatClose:hover{background:var(--dsw-alias-bg-layer-1);color:var(--dsw-alias-label-primary)}
.dshv-floatBtns{display:flex;align-items:center;gap:2px}
.dshv-floatBody{flex:1;min-height:0;overflow:hidden;display:flex}
.dshv-floatBody > .dshv-root{flex:1;min-width:0;height:100%}
.dshv-floatMove{position:absolute;left:0;top:50%;transform:translateY(-50%);width:6px;height:56px;
  display:flex;align-items:center;justify-content:center;font-size:0;line-height:1;
  color:var(--dsw-alias-label-secondary);opacity:0;cursor:move;user-select:none;touch-action:none;
  border-radius:0 6px 6px 0;transition:opacity .12s ease}
.dshv-float:hover .dshv-floatMove{opacity:.6}
.dshv-floatMove:hover{opacity:1;background:var(--dsw-alias-brand-primary)}
.dshv-floatGrip{position:absolute;right:0;bottom:0;width:18px;height:18px;cursor:nwse-resize;touch-action:none;
  background:linear-gradient(135deg, transparent 50%, var(--dsw-alias-border-l2) 50%)}
.dshv-svgHost [data-shape-id]{cursor:move}
.dshv-svgHost .dshv-portDot:hover{fill:#1B4F8F;r:.095}
.dshv-svgHost [data-shape-id].dshv-dropTarget>*:first-child{stroke:var(--dsw-alias-brand-primary);stroke-width:.028}
.dshv-hand .dshv-svgHost [data-shape-id],.dshv-hand .dshv-svgHost{cursor:grab}
/* The toolbar lives in its own row under the canvas instead of floating over the
   page: a floating bar sat on the drawing and could swallow clicks meant for a
   connector handle near the bottom edge. */
.dshv-dock{flex:0 0 46px;display:flex;align-items:center;justify-content:flex-end;
  padding:0 14px 8px;background:var(--dsw-alias-bg-layer-2)}
.dshv-zoom{display:flex;gap:4px;padding:4px;border-radius:9px;
  background:var(--dsw-alias-bg-overlay);border:1px solid var(--dsw-alias-border-l2);box-shadow:0 4px 14px rgba(0,0,0,.16)}
.dshv-zbtn{min-width:28px;height:26px;padding:0 8px;border:0;border-radius:6px;background:transparent;cursor:pointer;
  color:var(--dsw-alias-label-primary);font-size:12px;font-family:inherit}
.dshv-zbtn:hover{background:var(--dsw-alias-bg-layer-1)}
.dshv-zbtn.on{background:var(--dsw-alias-brand-primary);color:#fff}
.dshv-zfit{min-width:52px}
.dshv-kinds{display:grid;grid-template-columns:repeat(3,1fr);gap:5px;margin-top:6px}
.dshv-fold{display:flex;align-items:center;gap:5px;width:100%;border:none;background:none;padding:0;cursor:pointer;font-family:inherit;text-align:left}
.dshv-foldIcon{font-size:9px;color:var(--dsw-alias-label-secondary)}
.dshv-kind{display:flex;flex-direction:column;align-items:center;gap:2px;padding:6px 2px;border-radius:7px;
  border:1px solid var(--dsw-alias-border-l1);background:var(--dsw-alias-bg-base);cursor:pointer;
  color:var(--dsw-alias-label-secondary);font-size:10.5px;font-family:inherit;line-height:1.1}
.dshv-kind:hover:not(:disabled){border-color:var(--dsw-alias-brand-primary);color:var(--dsw-alias-label-primary)}
.dshv-kind:disabled{opacity:.45;cursor:default}
.dshv-kind.on{border-color:var(--dsw-alias-brand-primary);background:color-mix(in srgb,var(--dsw-alias-brand-primary) 12%,transparent);color:var(--dsw-alias-brand-primary)}
.dshv-kindGlyph{font-size:15px;line-height:1;color:var(--dsw-alias-label-primary)}
.dshv-dragtip{position:absolute;pointer-events:none;z-index:6;padding:3px 8px;border-radius:6px;
  background:var(--dsw-alias-bg-overlay);border:1px solid var(--dsw-alias-border-l2);font-size:11px;
  color:var(--dsw-alias-label-primary);box-shadow:0 2px 8px rgba(0,0,0,.16);white-space:nowrap}
.dshv-toggle{width:26px;height:26px;border-radius:6px;border:1px solid var(--dsw-alias-border-l1);background:transparent;
  color:var(--dsw-alias-label-secondary);cursor:pointer;font-size:13px;line-height:1;padding:0}
.dshv-toggle.on{color:var(--dsw-alias-label-primary);background:var(--dsw-alias-bg-layer-1)}
`

    const FAB_POS = 'dsh-visio.fab.pos.v1'

    function FloatingVisio(props) {
      const { t } = props
      const [open, setOpen] = useState(false)
      // the launcher itself is draggable; a drag must not toggle the window
      const [fab, setFab] = useState(() => {
        try {
          const saved = JSON.parse(window.localStorage.getItem(FAB_POS) || 'null')
          if (saved && Number.isFinite(saved.x) && Number.isFinite(saved.y)) return saved
        } catch (err) { /* ignore */ }
        return null
      })
      const fabRef = useRef(fab)
      const moveFab = (next) => {
        fabRef.current = next
        setFab(next)
        try { window.localStorage.setItem(FAB_POS, JSON.stringify(next)) } catch (err) { /* ignore */ }
      }
      const startFabDrag = (event) => {
        if (event.button !== 0) return
        const start = { x: event.clientX, y: event.clientY, fab: fabRef.current, moved: false }
        const move = (e) => {
          const dx = e.clientX - start.x
          const dy = e.clientY - start.y
          if (!start.moved && Math.abs(dx) + Math.abs(dy) < 4) return
          start.moved = true
          const vw = window.innerWidth || 1280
          const vh = window.innerHeight || 800
          const w = 96
          const h = 34
          moveFab({
            x: Math.min(Math.max(8, (start.fab ? start.fab.x : vw - w - 20) + dx), vw - w - 8),
            y: Math.min(Math.max(8, (start.fab ? start.fab.y : vh - h - 20) + dy), vh - h - 8),
          })
        }
        const up = () => {
          window.removeEventListener('pointermove', move)
          window.removeEventListener('pointerup', up)
          if (!start.moved) setOpen((value) => !value)
        }
        window.addEventListener('pointermove', move)
        window.addEventListener('pointerup', up)
      }
      const [geom, setGeom] = useState(() => {
        let saved = null
        try { saved = JSON.parse(window.localStorage.getItem(FLOAT_GEOM) || 'null') } catch (err) { saved = null }
        if (saved && Number(saved.w) >= 360 && Number(saved.h) >= 280) return saved
        const vw = window.innerWidth || 1280
        const vh = window.innerHeight || 800
        const w = Math.min(1280, Math.max(620, Math.round(vw * 0.66)))
        const h = Math.min(840, Math.max(460, Math.round(vh * 0.82)))
        return { x: Math.max(16, vw - w - 24), y: 72, w, h }
      })
      const geomRef = useRef(geom)
      const remember = (next) => {
        geomRef.current = next
        setGeom(next)
        try { window.localStorage.setItem(FLOAT_GEOM, JSON.stringify(next)) } catch (err) { /* ignore */ }
      }
      const track = (event, build) => {
        if (event.button !== 0) return
        // Buttons inside the bar keep their own click: preventDefault() on pointerdown
        // would swallow the following click event.
        if (event.target instanceof Element && event.target.closest('button')) return
        event.preventDefault()
        event.stopPropagation()
        const start = { x: event.clientX, y: event.clientY, geom: geomRef.current }
        const move = (e) => remember(build(start, e))
        const up = () => {
          window.removeEventListener('pointermove', move)
          window.removeEventListener('pointerup', up)
        }
        window.addEventListener('pointermove', move)
        window.addEventListener('pointerup', up)
      }
      const [restoreGeom, setRestoreGeom] = useState(null)
      const maximize = () => {
        const vw = window.innerWidth || 1280
        const vh = window.innerHeight || 800
        if (!restoreGeom) {
          setRestoreGeom(geomRef.current)
          remember({ x: 18, y: 18, w: vw - 36, h: vh - 36 })
        } else {
          remember(restoreGeom)
          setRestoreGeom(null)
        }
      }
      const clampGeom = (g) => {
        const vw = window.innerWidth || 1280
        const vh = window.innerHeight || 800
        // keep the title bar (and its close button) inside the viewport at all times,
        // and never let the window slide under the app chrome
        const w = Math.min(Math.max(360, g.w), vw - 16)
        const h = Math.min(Math.max(280, g.h), vh - 16)
        return {
          w,
          h,
          x: Math.min(Math.max(8, g.x), Math.max(8, vw - Math.min(w, 220) - 8)),
          y: Math.min(Math.max(48, g.y), vh - 56),
        }
      }
      const resetGeom = () => {
        const vw = window.innerWidth || 1280
        const vh = window.innerHeight || 800
        const w = Math.min(1280, Math.max(620, Math.round(vw * 0.66)))
        const h = Math.min(840, Math.max(460, Math.round(vh * 0.82)))
        remember(clampGeom({ x: Math.max(16, vw - w - 24), y: 72, w, h }))
        setRestoreGeom(null)
      }

      useEffect(() => {
        if (!open) return undefined
        const fixed = clampGeom(geomRef.current)
        if (fixed.x !== geomRef.current.x || fixed.y !== geomRef.current.y
            || fixed.w !== geomRef.current.w || fixed.h !== geomRef.current.h) {
          remember(fixed)
        }
        const onKey = (event) => {
          if (event.key === 'Escape') setOpen(false)
        }
        window.addEventListener('keydown', onKey)
        return () => window.removeEventListener('keydown', onKey)
      }, [open])
      const startDrag = (event) => track(event, (start, e) => clampGeom({
        ...start.geom,
        x: start.geom.x + e.clientX - start.x,
        y: start.geom.y + e.clientY - start.y,
      }))
      const startResize = (event) => track(event, (start, e) => ({
        ...start.geom,
        w: Math.max(460, Math.min(window.innerWidth - 16, start.geom.w + e.clientX - start.x)),
        h: Math.max(340, Math.min(window.innerHeight - 16, start.geom.h + e.clientY - start.y)),
      }))

      return h(React.Fragment, null,
        h('style', null, CSS_FLOAT),
        h('div', {
          className: `dshv-fab${open ? ' active' : ''}`,
          title: t('floatTip'),
          style: fab ? { left: fab.x, top: fab.y, right: 'auto', bottom: 'auto' } : undefined,
          onPointerDown: startFabDrag,
        }, h(Icon, { size: 15 }), h('span', null, t('nav'))),
        open
          ? h('div', { className: 'dshv-float', style: { left: geom.x, top: geom.y, width: geom.w, height: geom.h } },
              h('div', { className: 'dshv-floatBar', onPointerDown: startDrag, onDoubleClick: maximize },
                h('span', { className: 'dshv-floatTitle' }, t('floatTitle')),
                h('div', { className: 'dshv-floatBtns' },
                  h('button', { type: 'button',
                    className: 'dshv-floatClose',
                    title: t('floatReset'),
                    onClick: (event) => { event.stopPropagation(); resetGeom() },
                  }, '\u2316'),
                  h('button', { type: 'button',
                    className: 'dshv-floatClose',
                    title: t('floatClose'),
                    onClick: (event) => { event.stopPropagation(); setOpen(false) },
                  }, '\u00d7'))),
              h('div', { className: 'dshv-floatBody' }, h(VisioPanel, props)),
              h('div', { className: 'dshv-floatMove', title: t('floatMove'), onPointerDown: startDrag },
                '\u22ee\u22ee'),
              h('div', { className: 'dshv-floatGrip', onPointerDown: startResize }))
          : null)
    }

    return {

      inject: ['slots', 'locale'],
      apply(ctx) {
        ctx.effect(() => ctx.locale.register(NS, { zh, en }), `${NS}: dictionaries`)
        const t = ctx.locale.bind(NS)

        const pickFolder = async () => {
          const uiWorkspace = ctx.get('uiWorkspace')
          if (uiWorkspace && typeof uiWorkspace.pickDirectory === 'function') {
            return await uiWorkspace.pickDirectory()
          }
          return null
        }

        ctx.slots.inject('main', () => ctx.slots.inject('sidebar.panellist', () => {
          const stopMain = ctx.slots.register({
            name: 'main',
            key: PANEL_ID,
            locale: NS,
            inject: () => ({ t, pickFolder }),
          }, VisioPanel)
          let stopIcon
          try {
            stopIcon = ctx.slots.register({
              name: 'sidebar.panellist',
              id: PANEL_ID,
              order: 33,
              label: () => t('nav'),
              locale: NS,
            }, VisioIcon)
          } catch (error) {
            stopMain?.()
            throw error
          }
          return () => {
            stopIcon?.()
            stopMain?.()
          }
        }))

        ctx.slots.inject('shell.overlay', () => ctx.slots.register({
          name: 'shell.overlay',
          id: 'dsh-visio-float',
          order: 40,
          locale: NS,
          inject: () => ({ t, pickFolder }),
        }, FloatingVisio))
      },
    }
  },
})
