# Changelog

## 0.9.44 - 2026-10-26

### Fixed
- **Dictation Chunk Separator in Composer Insertion (#13, #297)**: Fixed consecutive dictation chunks gluing together without spaces (e.g. `hello` + `world` -> `helloworld`) when using token span insertion or `actions.insertText` in DSH 0.2.1-rc.3+. `insertDraftText` in `lib/client-src/30-core.js` now contextually prepends a separator space when the preceding draft does not end with whitespace or opening brackets, and the incoming chunk does not begin with whitespace or punctuation. Thanks to `@masteor` (GitHub PR #13).

### Added
- **Configurable Low-Volume Threshold (#14, #298)**: Added `lowVolumeThreshold` option (range `0..1`, default `0.08`) to `lib/schema.js` and `GET /dsh-voice/status`. In `lib/client-src/40-recording.js`, the quiet audio level indicator checks against `voice.settings.lowVolumeThreshold` rather than a hardcoded `0.08`, allowing users with quiet headsets or built-in microphones to tune sensitivity or set `0` to disable the hint. Thanks to `@masteor` (GitHub PR #14).

## 0.9.43 - 2026-10-26

### Fixed
- **Desktop Shell & Loopback Origin Compatibility (#12, #295)**: Fixed `forbidden source origin` 403 rejection in `isTrustedCaller` and `hasSameOrigin` (`lib/http-util.js`) when recording audio from DeepSeek Desktop (Electron, Tauri, `dsh-app://app`), sandboxed desktop views (`Origin: null`), or loopback hostname aliases (`localhost:3080` vs `127.0.0.1:3080`). Non-HTTP desktop app schemes and authenticated DSH sessions with `dsh-auth-` cookie are now recognized as trusted callers while preserving strict fail-closed cross-site (`Sec-Fetch-Site: cross-site`) and LAN reverse bridge protections. Thanks to `@StatedFast` for reporting (GitHub #12).

## 0.9.42 - 2026-10-22

### Security
- **Reverse Bridge & LAN Origin Authorization Enforcement (#292)**: Enhanced `isTrustedCaller` and added `hasSameOrigin` in `lib/http-util.js`. Disallowed unauthenticated mutating requests (`PUT /config`, `POST /transcribe`, `POST /polish`) and WebSocket stream upgrades over loopback reverse bridges (such as `dsh-lanmode`) when missing valid `Origin`/`Referer` headers matching `Host`. Programmatic LAN requests must present a valid `x-dsh-voice-token`.
- **Session Token Leak Mitigation & Auto-Rotation (#292)**: Restricted `GET /dsh-voice/status` to only emit `sessionToken` when `hasSameOrigin(req)` is verified, preventing unauthorized LAN clients from harvesting WebSocket session tokens. Added automatic session token rotation upon successful configuration persistence in `PUT /dsh-voice/config`.

### Fixed
- **Streaming Dictation Audio Quota & Engine Bounding (#293)**: Fixed `interim` WebSocket streaming in `lib/host-routes.js` to process strictly the latest audio chunk (`streamChunks[streamChunks.length - 1]`) instead of concatenating the cumulative audio history since session start ($O(N)$ linear byte consumption instead of quadratic $O(N^2)$ accumulation).
- **Interim Local Engine Enforcement (#293)**: Restricted real-time `interim` transcription strictly to local/free zero-cost STT engines (`local-whisper`, `sensevoice`, `browser-webgpu`) with active daemon liveness verification. Disallowed calling paid cloud providers (Deepgram, Groq, OpenAI) during interim stream ticks, eliminating unintended cloud quota burn and duplicate HTTP transcription billing.

## 0.9.41 - 2026-10-21

### Fixed
- **Preview Pill Missing Icons (#11, #290)**: Defined `editIcon` and `sendIcon` SVG builders in `lib/client-src/30-core.js`. Resolves `ReferenceError: editIcon is not defined` when rendering editable preview pill (`renderEditablePreviewPill`) after recording a voice message (🌊), preventing the dock slot from crashing and vanishing. Thanks to `@Lordos-dot` for reporting (GitHub #11).

## 0.9.40 - 2026-10-20

### Fixed
- **Credentials String Ref Unwrapping (#10, #288)**: Fixed `resolveKey` in `lib/index.js` where checking `ref.type` on a primitive string reference caused immediate short-circuiting, and resolved credential objects `{ value, source }` from `ctx.credentials.resolve()` were returned directly instead of extracting `.value`. Resolves all cloud STT providers failing with `no <ENV>` error. Thanks to `@masteor` for reporting and initial PR (GitHub #10).

## 0.9.39 - 2026-10-19

### Added
- **Neural Silero VAD In-Browser Module (#279)**: Added neural voice activity detection (`lib/client-src/36-silero-vad.js`) filtering out mechanical keyboard switches, mouse clicks, sighs, and fan noise via harmonic energy estimation and zero-crossing rate (ZCR). Configurable via `vadEngine: 'silero' | 'amplitude'` in `lib/schema.js` and Hardware Settings card (`72-hardware.js`), with dedicated `/dsh-voice/vad/status` health check.
- **Ultra-Low Latency Streaming WebSocket Channel (#282)**: Implemented bidirectional streaming WebSocket protocol (`lib/ws-framer.js`, `lib/client-src/37-ws-stream.js`, `lib/host-routes.js`) under `/dsh-voice/ws/stream` with RFC 6455 framing and handshake key calculation, session token authentication, live interim preview streaming, and seamless HTTP fallback when WebSocket connection is unavailable.
- **Bundle Size Optimization & Fragment Modernization**: Modernized settings and UI fragments with shorthand element factory and destructuring, ensuring `lib/client.js` is compacted to 249 KB (< 250 KB warning limit, 0 warnings in `pack:check`).

## 0.9.34

### Added
- **Per-Recognition Diagnostics & Breakdown Telemetry (#266)**: Added per-recognition latency breakdown metrics (`vadMs`, `sttMs`, `polishMs`, `totalTookMs`), audio payload byte count, recognized word count, provider attempt status, and failure error reasons in `lib/stats.js` and `lib/host-routes.js`.
- **Anonymized Diagnostic Report Export (#266)**: Added 1-click JSON report export button in Provider Dashboard (`ProviderDashboard` in `lib/client-src/72-dashboard.js`) via dedicated endpoint `GET /dsh-voice/diagnostics/export`, redacting all raw audio streams, base64 payloads, and spoken transcript texts while preserving timing metrics, MIME types, and provider error codes.
- **Comprehensive Audit Completion & Verification (#216)**: Finalized all architectural recommendations, security controls (IPv6 ULA, link-local, supply-chain checks), modularity caps (<600 lines per source fragment), full test coverage (281/281 PASS), and zero-Cyrillic source code integrity across the codebase.

## 0.9.33

### Added
- **First-Run Onboarding & Diagnostics Wizard (#265)**: Integrated interactive first-run wizard (`FirstRunWizard` in `lib/client-src/72-wizard.js`) verifying secure context / HTTPS status, browser audio API support, microphone permission state with direct access request, device selector, live visual volume level meter (RMS signal test), active STT provider & processing area indicator (browser, local server, cloud), and 3-second sample transcription round-trip test. Includes launch button in connection card and full canonical EN + ZH translation parity.

### Fixed
- **IPv6 ULA & CIDR Private LAN Protection (#269)**: Extended `isPrivateLan` in `lib/updater.js` to recognize IPv6 Unique Local Addresses (`fc00::/7` including `fd00::/8`), IPv6 Link-Local (`fe80::/10`), IPv4 Link-Local (`169.254.0.0/16`), IPv4-mapped IPv6, and CIDR subnet notation (`/prefix`), hardening update origin trust verification on local IPv6 and hybrid LAN deployments.

## 0.9.32

### Added
- **4 Dictation Post-Processing Modes (#264)**: Developed 4 distinct post-processing modes: `verbatim` (exact STT output, strictly 0 LLM calls, preserving all code symbols), `clean` (tidy punctuation and filler-word removal without altering facts), `task` (structured into Problem/Goal, Expected Outcome, Constraints, Acceptance Criteria without inventing details), and `note` (extracting key thoughts and action points from dictation).
- **Snapshot Isolation & Pre-Recording Mode Selector (#264)**: Added composer mode cycler pill and recording pill badges. The active mode is captured as an immutable snapshot at recording start; in-flight mode changes apply to subsequent recordings while the current recording is processed using its snapshot.
- **Configurable Dictation Prompt Templates (#264)**: Added settings card in plugin configuration allowing custom prompt templates per mode with `{text}` variable substitution and a 1-click restore to built-in defaults.
- **Dynamic Context-Aware Lexicon Boosting (#167)**: Enhanced `extractContextKeywords()` to inspect composer draft, recent session messages, and open DOM code blocks, forwarding technical tokens and code terms to all STT providers (Deepgram `&keywords=...`, Groq `prompt`, local-whisper `prompt`, SenseVoice, and custom OpenAI providers).
- **Voice Action Macros (#167)**: Added voice macros system (`lib/macros.js`) expanding spoken trigger phrases (exact and prefix matches with `{text}` template interpolation) into structured prompts, complete with settings card to add, edit, and delete user macros.
- **Strict `localOnly` Compliance & Fallback Guarantee (#264)**: Enforced strict loopback-only isolation under `localOnly` mode without cloud leakage; in the event of LLM timeout or failure, the verbatim transcription is preserved and presented with a clear fallback indicator.

## 0.9.31

### Added
- **Editable Preview Before Send (`editablePreview`) (#170)**: Interactive confirmation pill displaying recognized STT transcript before submitting to the agent, with inline editing, Raw vs Polished comparison tabs when `polishSend` is enabled, and complete draft restoration on cancel.
- **Auto-Send Countdown Freeze (#170)**: Clicking Edit immediately stops the auto-send countdown timer, allowing deliberate text adjustments without racing the timer.
- **Conversation Session Pinning & Guard (#170)**: Binds recognition preview state to the active conversation session ID. Switching chats pauses auto-send and triggers a `sessionMismatch` warning, eliminating transcript leakage across conversations.

## 0.9.30

### Fixed
- **DSH 0.2 Persistent Shell `timeoutMs` Validation (GH #9, #261)**: Fixed autostart failure with error `"bash-local: request.timeoutMs must be a positive finite number"` on DSH 0.2.x by setting positive finite `timeoutMs: 60000` on both Whisper and SenseVoice daemon specs in `lib/local-daemon.js`, eliminating `timeoutMs: 0` which is rejected by `@deepseek-ai/dsh-tools` shell execution schema.
- **LAN Same-Origin Updater Trust (#258)**: Updated `isTrustedUpdateRequest` in `lib/updater.js` to accept private LAN same-origin requests (`192.168.x.x`, `10.x.x.x`, `172.16-31.x.x`) matching host header, bringing one-click updater security policy into parity with `isTrustedCaller` on `PUT /config` and other administrative endpoints.
- **Client Updater Status Kind & Color Heuristic (#259)**: Replaced fragile substring heuristics (`updaterMsg.includes('fail') || updaterMsg.includes('失败')`) in `lib/client-src/72-updater.js` with structured status state `updaterMsgKind` (`'ok' | 'err' | 'warn'`) in `lib/client-src/72-hooks.js`, ensuring update failure messages correctly render in warning color under Russian and other non-English locales.
- **Stray Release Artifacts Cleaned from Working Tree (#260)**: Removed stray release archive files from repository root and verified clean packaging without unversioned artifacts.

### Added
- **Repository Standard Root Files (#256)**: Added canonical `index.md`, `AGENTS.md`, and executable `deploy.sh` to repository root and tracked them in version control.
- **Browser Secure Context Microphone Documentation (#257)**: Documented browser Secure Context (HTTPS or localhost) requirement for `navigator.mediaDevices.getUserMedia` across `README.md`, `README.ru.md`, and `README.zh.md`, explaining browser security restrictions when accessing DSH over LAN without HTTPS.

## 0.9.29

### Fixed
- **In-Browser WASM Whisper Offline Fallback (#168)**: Implemented graceful fallback to `@huggingface/transformers` with `{ device: 'wasm', dtype: 'q8' }` in `lib/client-src/35-webgpu.js` when `navigator.gpu` is absent or WebGPU pipeline initialization fails. Exposed `isWasmSupported` and `isOfflineSupported` on `voice.webGpu`.
- **Physical RKNN Model Existence Guard (#168)**: Enforced strict physical filesystem check (`existsSync(modelPath)`) in `resolveSensevoiceProvider` and `buildSensevoiceArgs` (`lib/sensevoice-installer.js`) before enabling `--provider=rknn`. Missing or non-existent `.rknn` files truthfully fall back to CPU (`cpu`) rather than claiming an active hardware accelerator. Documented that physical RK3588 NPU acceleration requires compatible RK3588 hardware.

## 0.9.28

### Fixed
- **Truthful Effective Provider & RKNN Fallback (#221)**: Implemented `resolveSensevoiceProvider` in `lib/sensevoice-installer.js` ensuring hardware acceleration configurations (`rknn`/`rknpu`) are backed by compatible `.rknn` model files; automatically and safely falls back to CPU when standard ONNX models are detected. Exposed `effectiveSensevoiceProvider` in `GET /dsh-voice/status` for truthful runtime introspection.
- **Volatile Configuration Box Unwrapping on Live Path (#227)**: Added `isVolatileRef` and `plainConfig` in `lib/index.js` to unwrap Schemastery volatile boxes (`{ get: [Function] }`) on the `live(sctx)` path prior to `BaseConfig` validation and before returning to callers, preserving reactivity while eliminating raw box leakage. Added fallback to `describeRow()?.config`.
- **Linguistic Processing Data Boundary Formalization (#122)**: Documented functional linguistic data boundaries in `docs/design/DESIGN.md`, defining Russian tokens strictly as functional linguistic processing data (voice triggers, stop-words, numerals, punctuation). Enforced zero Cyrillic comments codebase-wide with automated regression test `test/linguistic-data.test.mjs`.
- **Client & Autostart Test Suite Algorithm Deduplication (#214)**: Exported client production utility implementations (`waitStop`, `currentLevel`, `accentColor`, `softColor`) under `exports._test` in `lib/client-src/90-close.js` and rebuilt client bundle. Refactored `test/client-logic.test.mjs` and `test/autostart.test.mjs` to execute real production code rather than local duplicate mock algorithms.

## 0.9.27

### Fixed
- **Parameterized Lock Paths Across All Documentation (#205)**: Replaced personal user path examples in `README.md`, `README.ru.md`, and `README.zh.md` with canonical parameterized profile paths (`~/.dsh/profiles/<profile>/package.json.lock`).
- **Complete Controlled Operator Recovery Workflow (#205)**: Fully documented the 4-step controlled operator recovery procedure: establishing an exclusive maintenance window, verifying process quiescence and non-ownership via system tooling (`ps`/`pgrep`/`lsof`/`fuser`), removing only confirmed orphan lockfiles without recursive/force flags, and resuming operations. Explicitly noted that filesystem errors (`EACCES`/`EIO`) require filesystem inspection rather than lockfile deletion.
- **Controlled Recovery Directives in Diagnostics (#205)**: Updated `formatLockDiagnostic` and EN/ZH client localization strings to direct operators to the documented controlled recovery workflow instead of isolated deletion instructions.

## 0.9.26

### Fixed
- **Neutral Profile Lock Diagnostics & Error Code Preservation (#205, #216)**: Added `formatLockDiagnostic` in `lib/updater.js` providing neutral diagnostics when `package.json.lock` is present (identifying the active PID or specifying operator manual recovery requirements). Ensured filesystem access error codes (such as `EACCES` or `EIO`) are preserved and exposed in `installExact` errors and HTTP 409 API responses.
- **Client Error Formatting & Localization (#205, #216)**: Added localized EN/ZH diagnostic messages in `10-locale.js` and `72-hooks.js` for profile locks and filesystem error codes, rebuilding `lib/client.js`.
- **Documentation of Operator-Recovery Lock Policy (#205, #216)**: Added documentation across `README.md`, `README.ru.md`, and `README.zh.md` detailing the profile lock policy (*contenders never remove existing locks*) and manual operator recovery instructions (`rm <profile-dir>/package.json.lock`).
- **Persisted Install Lifecycle & Fail-Closed Test Suite (#205, #216)**: Added actual sandbox execution tests in `test/updater.test.mjs` verifying fail-closed `checkProfileLock` behavior for `EACCES`/`EIO` and all 4 child lifecycle states in `installExact` (success, nonzero exit, spawn error, timeout SIGTERM->SIGKILL escalation) with foreign lock preservation (245 passing tests).

## 0.9.25

### Fixed
- **Canonical Read-Only Profile Lock Policy (#205, #216)**: Transitioned `checkProfileLock(profileDir)` to a strict read-only lock verification policy adhering to the DSH canonical rule: the contender never removes an existing lock; orphan lock recovery is strictly an operator action. Eliminated sequential PID polling and removed `unlinkSync` entirely, closing the fundamental TOCTOU vulnerability demonstrated by audit probe 83719.
- **Fail-Closed Lock Error Handling (#205, #216)**: Any filesystem error accessing the lockfile (such as `EACCES` or `EIO`) returns `{ locked: true, pid: null, error: err.code }`, fail-closing instead of misinterpreting access errors as an unlocked profile.
- **Child Exit Cleanup Decoupling (#205, #216)**: Removed redundant `checkProfileLock` invocation in `installExact` child process error/exit handlers, ensuring the parent does not touch foreign profile locks on process termination.

## 0.9.24

### Fixed
- **Post-Fifth-Read Lockfile Verification (#205)**: Added post-fifth-read attribute check (`statSync: mtimeMs, size`) and confirmatory PID observation (`readLockPid`) in `checkProfileLock` before removing stale lockfiles. If a concurrent process writes a live successor lock during or after the fifth PID read (reproducing comment #83598 `live_successor_after_final_fifth_read`), the lockfile is preserved on disk, live PID is returned, and `unlinkSync` is aborted. Unlinking now requires unanimous agreement across all five observation steps (`p1 === pid && p2 === pid && p3 === pid && finalPid === pid && postPid === pid`).
- **Audit Probe Coverage for Fifth-Read Seams (#214)**: Added regression coverage in `test/audit-fixes.test.mjs` reproducing the exact `live_successor_after_final_fifth_read` probe from comment #83598 (242 passing tests).

## 0.9.23

### Fixed
- **Profile Lock Final Observation Gap Closure (#205)**: Added immediate pre-unlink PID verification (`finalPid = readLockPid(lockPath)`) in `checkProfileLock`. Eliminates the observation window between `statSync` and `unlinkSync`, preventing successor lockfile deletion when a concurrent installer writes after the final stat check or writes with identical file metadata. Requires unanimous verification across all inspection reads before unlinking stale lockfiles.
- **Audit Probe Coverage for Concurrent Stat Seams (#214)**: Added regression coverage in `test/audit-fixes.test.mjs` reproducing both `after-final-stat` and `same-stat-after-final-read` audit probe scenarios from comments #83241 and #83244 (241 passing tests).

## 0.9.22

### Fixed
- **Lockfile Stat Verification & TOCTOU Elimination (#205)**: Added filesystem metadata verification (`statSync: mtimeMs, size`) in `checkProfileLock` before removing stale lockfiles. If a concurrent writer modifies or acquires `package.json.lock` at any point during inspection (including on final reads), the lockfile is preserved, live PID is re-read, and `{ locked: true, pid }` is reported.
- **Comprehensive Audit Probe Suite (#214)**: Added regression coverage in `test/audit-fixes.test.mjs` matching the final-lock audit probe for 4th-read concurrent lock acquisition (239 passing tests).

## 0.9.21

### Fixed
- **Daemon Readiness Polling Unblocked (#191)**: Guard `child.result()` awaiting in local daemon health polling loops so it only executes when the child process enters a terminal status (`killed`, `completed`, `exited`, `failed` or non-null `exitCode`). When status is `'running'`, polling proceeds unimpeded to verify HTTP readiness without waiting for the process to terminate.
- **Sequential Successor Lock Protection (#205)**: Perform verified sequential reads in `checkProfileLock` before unlinking stale lockfiles. If a concurrent writer claims the lock with a living PID on subsequent checks, preserve the file and report `{ locked: true, pid }`.
- **Audit Probe Regression Coverage (#214)**: Added regression tests verifying daemon startup completion without blocking running processes and successor lock retention across sequential write intervals (238 passing tests).

## 0.9.20

### Fixed
- **Native Multiphase Dictation TokenSpan Refresh (#198)**: Refresh `target.span` via `actions.captureInsertion()` on each successful text insertion in multiphase dictation, ensuring subsequent cut segments and the final tail chunk receive advancing `draftRev` revisions rather than stale revision 1.
- **Rejected Insertion Auto-Send Suppression (#198)**: Suppress transition to `phase: 'pending'` and keep `voice.pending` null when `appendDraft` fails (e.g. revision rejected due to concurrent user edits), preventing `submitPending()` from auto-submitting uninserted voice drafts over user input.
- **Concurrent Live Lock Cleanup Guard (#205)**: Perform a follow-up confirmation read of `readLockPid(lockPath)` before unlinking in `checkProfileLock`; preserve the lockfile and report `{ locked: true, pid }` if a concurrent successor process acquired the lock during stale inspection.
- **Local Daemon Stderr Diagnostics & Result Rejection (#191)**: Call `child.readOutput()` (with fallback to `read()`) and catch `child.result()` rejections across Whisper and SenseVoice daemons, exposing underlying spawn and termination stderr diagnostics instead of masking them behind generic exit messages.
- **Comprehensive Audit Verification Suite (#214)**: Added regression tests in `test/audit-fixes.test.mjs` verifying multiphase TokenSpan progression, rejected-insert pending suppression, successor lock retention, and spawn stderr propagation across 236 passing tests.

## 0.9.19

### Fixed
- **Native TokenSpan & Draft Revision Protection (#198)**: Pass captured native `TokenSpan` into `actions.insertText(text, span)` and eliminate fallback to `setDraft` when `insertText` rejects or throws on revision mismatch, ensuring user draft edits made during recognition are never overwritten.
- **Composer Session Isolation on Chat Switch (#198)**: Bind initiating session target across all pending phases (`message`, `dictation`, browser recognition), ensuring `submitPending()` and spoken composer actions strictly submit to the initiating session rather than the switched active session.
- **Race-Free Profile Lock Cleanup (#205)**: Remove destructive rename coordination in `checkProfileLock` and verify dead PID before unlinking in-place on-disk, completely eliminating the file-absence race window where concurrent successor lockfiles were hidden and overwritten.
- **Modern DSH ShellExecution Async Result Contract (#191)**: Correctly await async `child.result(): Promise<ShellRunResult>` in local daemon handling, extracting exit code and provider `stderr` output instead of masking crashes behind generic failure messages.
- **Sherpa-ONNX RKNN Runtime Guard (#221)**: Guard against passing `--provider=rknn` when loading ordinary `.onnx` models, automatically switching to sibling `.rknn` models if present or falling back to CPU execution to prevent runtime crashes.
- **Authentic Audit Probes Regression Test Suite (#214)**: Added regression tests matching Codex audit probes covering native TokenSpan revision guards, session switch submission isolation, concurrent lock race protection, daemon exitcode/stderr parsing, and RKNN ONNX guards (232 tests passing).

## 0.9.18

### Fixed
- **Browser STT Stop Lifecycle & Final Result Insertion (#225)**: Keep `activeOpId` active during normal `SpeechRecognition.stop()` by transitioning to `phase: 'finishing'`, ensuring the trailing final transcript chunk is safely appended to the initiating composer and queued for dispatch.
- **Microphone Stream & Web Audio Node Leaks (#226)**: Wrap post-`getUserMedia` stream initialization in `openMic` with defensive try/catch, immediately terminating all tracks and closing partially created audio context nodes if `MediaRecorder` or audio graph construction fails.
- **Strict FIFO Dictation Queue (#197)**: Sequentialize phrase chunk processing and tail segment insertion through an unbroken `dictationQueue` promise chain, preventing out-of-order text insertion when cutting long utterances.
- **Composer Session Isolation (#198)**: Bind transcription results to the initiating composer target and insertion span, preventing late STT callbacks from leaking into switched active sessions.
- **Post-Disposal Audio Dispatch Prevention (#203)**: Add strict disposal guards before and after `MediaRecorder.stop()` completion, preventing late stop events from triggering network requests or mutating plugin phase.
- **Modern DSH 0.2 ShellExecution Contract (#191)**: Handle process state (`running`, `completed`, `killed`, `exited`, `failed`) and `done` promise in daemon management without false 30s timeouts, configuring `onExpiry: 'none'`.
- **Middle-Chain WebGPU Fallback & Empty Result Fallthrough (#220)**: Execute head providers via host STT before delegating to in-browser WebGPU, falling through to remaining host providers if WebGPU returns empty text or errors.
- **Concurrent In-Flight Model Load Deduplication (#222)**: Share in-flight model loading Promises in `_webGpuPipelines` across concurrent invocations to prevent redundant network downloads and memory allocations.
- **Atomic Profile Lock Coordination (#205)**: Employ atomic file renaming (`renameSync`) during stale lock inspection to eliminate TOCTOU race windows against live successor processes.
- **Modular Route & Hotkey Decomposition (#180)**: Extract HTTP endpoints to `lib/host-routes.js` (bringing `lib/index.js` to 201 lines) and extract hotkey matching to `lib/client-src/42-hotkey.js`, keeping all source files strictly under project limits.
- **Strict Quality Enforcement & Force Flag Elimination (#214)**: Eliminate `force: true` options across file system operations and tests, verifying clean execution across 227 authentic behavioral tests.

## 0.9.17

### Fixed
- **VoiceSection Render TDZ ReferenceError (#218)**: Reordered state and status fetch declarations before initializing `useSensevoiceInstaller`, eliminating crash on settings view load.
- **VAD Dictation cutPhrase opId ReferenceError (#219)**: Correctly preserved and resolved `opId` in `openMic` and `cutPhrase`, preventing speech segment cutting crashes.
- **WebGPU Chain Ordering & Empty Transcription Fallthrough (#220)**: Respected exact `_activeChain` priority, falling through to host STT on empty WebGPU recognition and querying host STT first when WebGPU is placed as fallback.
- **Sherpa-ONNX RKNN Integration (#221)**: Standardized RK3588 NPU acceleration flags to official `--provider=rknn` and automatically normalized legacy `rknpu` values.
- **Multi-Model WebGPU Pipeline Caching (#222)**: Replaced single pipeline reference with multi-model cache Map keyed by model name, correctly syncing `webgpuModel` and `localOnly` through `modeChain`.
- **Modular Server Daemon Extraction (#180)**: Decomposed daemon process management into `lib/local-daemon.js`, keeping `lib/index.js` and all library modules strictly under 600 lines.
- **Asynchronous Daemon Shell Execution (#191)**: Awaited `ctx.shell.execute` and handled process spawn failures immediately without incurring 30s timeout delays.
- **Browser STT & Disposal Lifecycle Guards (#198, #203)**: Bound recognition actions to operation IDs and set `voice.disposed = true` on unmount to block late insertions.
- **Updater Lock Removal Race Protection (#205)**: Re-verified lock file PID before unlinking stale lock files, preventing deletion of active locks held by successor processes.
- **Local-Only Policy Enforcement (#209)**: Preserved `localOnly` setting in client `modeChain` and filtered out external cloud-based browser recognition when enabled.
- **Authentic Behavioral Execution Tests (#214)**: Added comprehensive Node.js VM execution test suite covering real client components and daemon lifecycle.

## 0.9.13

### Fixed
- **HTTP 413 Connection Teardown (#207)**: Deliver clean HTTP 413 JSON responses with `Connection: close` and gracefully drain/close sockets on oversized request bodies, eliminating premature socket destruction and client `ECONNRESET`.
- **UI Localization Coverage (#212)**: Localize previously hardcoded interface strings (`Voice input`, `Assistant speaking (gated mode)`, `Update completed successfully.`, `(spoken -> replacement)`, `Error:`) through the locale registry `t()` helper, adding symmetric translations to English and Chinese dictionaries.
- **Web Speech Privacy Disclosures (#210)**: Update documentation across `README.md`, `README.ru.md`, and `README.zh.md` to accurately reflect Web Speech API network transmission (vendor cloud processing in Chrome) versus true offline engines (`whisper`, `sensevoice`).
- **Design Contract Synchronization (#187)**: Align `docs/design/DESIGN.md` with live production endpoints (`/config`, `/sensevoice-installer`, `/api/dsh-voice/update`) and modern UI slots (`plugins.item`, `plugins.row.config`).
- **Syntax Gate & Packaging Enforcement (#103)**: Introduce dedicated `scripts/lint.mjs` checking syntax across all files in `lib/`, `scripts/`, and `test/`, and enforce `pack:check` size limits and linting in `pretest`.
- **Behavioral Route & Production Logic Testing (#97, #214)**: Add full behavioral test coverage for host routes (`/status`, `/polish`, `/transcribe`), and eliminate duplicate algorithms in tests by testing real production modules (`tool.js`, `transcribe-core.js`, `client._test`).

## 0.9.12

### Fixed
- **Settings Persistence & Error Propagation (#204)**: Propagate failures when persisting via legacy `scope.set` instead of suppressing them, and prevent duplicate writes when modern `settingsService` has already persisted.
- **Optimistic Concurrency (#215)**: Return revision on `GET /config` and enforce `expectedRevision` checks on save, returning HTTP 409 Conflict on revision mismatch to prevent parallel form submissions from silently overwriting concurrent changes.
- **Canonical Language & Chinese Selector (#208)**: Represent auto-detect as canonical empty string `''` and add Chinese (`zh`) to the language selector, preserving unknown/custom language codes.
- **Web Speech Language Policy (#201)**: Resolve browser recognizer language using document/interface and navigator language when set to auto instead of hardcoding `ru-RU`, documenting Web Speech limitations.
- **Truthful Updater Status (#213)**: Distinguish loading, unknown, check failure, and up-to-date states in `UpdaterCard`, eliminating hardcoded version fallback and false positive success badges.
- **Plugin Lifecycle Event Listeners (#203)**: Encapsulate TTS listeners (`dsh:tts:start`, `dsh:tts:stop`), `settings-saved`, `pagehide`, and `beforeunload` in `ctx.effect` with symmetric disposal and teardown on unmount.
- **Settings CSS Scoping (#211)**: Scope all `.cb-*` style rules to `.dvo-settings-root` and manage the `<style>` tag lifecycle via `ctx.effect` to prevent styles from leaking into adjacent plugin cards.

## 0.9.11

### Fixed
- **Push-to-Talk Hold Gesture (#195)**: Keep `VoiceButtons` mounted during hold, retain pointer capture (`setPointerCapture`), and bind global window listeners for `pointerup`, `pointercancel`, and `blur` to prevent stuck recording states.
- **Modifier-First Hotkey Release (#196)**: Detect modifier key release (`Control`, `Alt`, `Shift`, `Meta`) in compound hotkeys to cleanly terminate push-to-talk holds when the modifier is released before the main key.
- **Dictation FIFO Tail Ordering (#197)**: Sequence the final audio chunk through `dictationQueue` to guarantee strict FIFO text insertion and prevent out-of-order text fragments.
- **Browser Recognizer Lifecycle (#202)**: Set `stopped = true` and call `recognition.abort()` on fatal errors to prevent infinite restart loops, abort previous recognizer on wake-word transition, and await completion of the final audio segment upon stop.
- **Spoken Action Handlers (#199)**: Unify spoken actions (`send`, `clear`) using standard `InputActions` contract (`submit()`, `setDraft('')`), reporting an error if the composer is unavailable.
- **Spoken Newline Formatting (#200)**: Preserve newlines (`
`, `

`) across `tidyPhrase`, `applyVoiceCommands`, and `insertDraftText` without stripping whitespace or inserting spurious spaces.

## 0.9.10

### Fixed
- **ASR Shell Compatibility (#191)**: Support modern DSH 0.2 `ctx.shell.execute` and `ShellExecution` lifecycle for local Whisper and SenseVoice engine autostart.
- **ASR Start Latch (#192)**: Ensure `startingWhisper` and `startingSensevoice` latches are unconditionally released via try/finally across all early exit paths.
- **SenseVoice Settings Persistence (#193)**: Persist SenseVoice installer model path and autostart configuration via modern `SettingsForms` `settingsService` adapter.
- **Composer Reload Settings Sync (#194)**: Synchronize `vadSilenceMs` and `autoSendMs` from host `/status` on page reload without requiring the user to open the settings card.

## 0.9.9

### Fixed
- **Settings Form State (#190)**: Lift jargon state to parent form to prevent `ReferenceError: jargonInput is not defined` when saving settings.
- **Privacy Enforcement (#209)**: Enforce strict `localOnly` mode across Web Speech ASR and text polish helpers to block cloud fallbacks when privacy is enabled.
- **Async STT Cancellation (#198)**: Track active operation ID across async STT processing to prevent late insertion or auto-sending of canceled speech.
- **Updater Lock Hygiene (#205)**: Preserve unparsed or empty lockfiles during atomic lock checks in plugin updater to prevent premature lock deletion.
- **Updater Timeout Escalation (#206)**: Await child process exit on updater timeout and escalate SIGTERM to SIGKILL after 1s grace period.

## 0.9.8

### Fixed
- **Peer gate on DSH 0.2.0-rc.1** (#58): DSH skips a profile bundle whose `peerDependencies` exclude the running version, so this plugin was absent from the profile with no error in the UI. Every `@deepseek-ai/dsh-*` peer now names both the 0.1.7-rc.2 and 0.2.0-rc.1 lines, because semver does not admit a prerelease of the next minor into a range that does not name it.

Notable changes to `@goodandready/dsh-voice`.

## 0.9.7

### Fixed
- **Lifecycle effect disposal.** Wrap client slot injections (`conversation.input.right`, `conversation.input.dock`, `plugins.item`, `plugins.row.config`, `settings.plugin.item`) and host volatile event listeners (`loader/volatile-update`, `settings/document-updated`, `config`) in `ctx.effect` returning disposers to prevent listener and slot leaks across plugin reloads (#183).
- **Localization translator prop inheritance.** Pass `t` prop to `ChainEditor` and `CustomEditor` to ensure nested components utilize the contextual translator, preventing variable shadowing and untranslated labels (#185).

### Refactored
- **Client code modularity.** Decompose monolithic 1023-line `72-voice-section.js` down to 540 lines across 7 modular fragments: `72-status-card.js`, `72-hardware.js`, `72-hooks.js`, `72-sensevoice.js`, `72-jargon.js`, `72-dashboard.js`, and `72-updater.js` (#184).
- **Dead import elimination.** Remove 11 unused imports in `lib/index.js` and `lib/sensevoice-installer.js` (#186).

### Documentation
- **Design contract completeness.** Update `docs/design/DESIGN.md` to document all live HTTP endpoints (`/config`, `/sensevoice-installer`, `/update`), tool schemas (`transcribe_audio`), and client slot seats (#187).

## 0.9.6

### Fixed
- **SenseVoice installer archive path validation & auto-extraction.** Robust archive extraction and cleanup (#178, #179).
- **Language detection & audio architecture enhancements.** Enhanced language detection fallback and robust ffmpeg conversion (#180, #181).

## 0.9.4

### Security
- **Route caller verification hardening.** Evaluate `Sec-Fetch-Site: cross-site | same-site` rejection and `Origin`/`Referer` validation against `Host` prior to loopback address checking in `isTrustedCaller`, and enforce `Content-Type: application/json` or `application/octet-stream` for POST/PUT/PATCH mutations to prevent simple cross-site form CSRF behind reverse proxies (#173).

### Fixed
- **Base64-expanded payload body limit and 413 error status.** Expand body read cap in `/dsh-voice/transcribe` to `Math.ceil((maxFileBytes * 4) / 3) + 64 KiB` to support base64-encoded audio up to 25 MiB, and return structured HTTP 413 (`code: 'too-large'`) when body size limit is exceeded (#174).
- **Public recognition language default & conditional Russian normalization.** Decouple default `language` in `dictation` and `message` configurations to `''` (`auto`), enabling automatic language detection across providers. Gate Russian numeric parsing (`wordsToDigits`) and tech slang replacements (`applyJargonDictionary`) behind `isRussianLang` checks, activating them only when language is Russian or contains Cyrillic characters (#175).
- **Self-updater lockfile resilience & supply-chain policy preservation.** Retain pnpm supply-chain verification by removing `--config.minimumReleaseAge=0` from updater arguments. Add `checkProfileLock` to return HTTP 409 when `package.json.lock` is held by a running PID, and clean up abandoned lockfiles on timeout or process exit (#176).

## 0.9.3

### Fixed
- **Hotkey lifecycle cleanup singleton.** Ensure existing `keydown`/`keyup` document event listeners are cleaned up across plugin reloads, hotkey rebinds, and composer unmounts using a dedicated singleton (`clearGlobalHotkey` / `window.__dsh_voice_hotkey_cleanup`) (#171).
- **Composer editable key filtering.** Allow multi-key combinations (e.g. `Ctrl+Space`, `Alt+V`) and function keys (`F1`-`F12`) to trigger voice recording inside textareas and contenteditable inputs, while preventing accidental triggers on standard typing and suppressing character insertion (#171).
- **Immediate hotkey persistence & multi-key combo capture.** Capture key combinations in Settings UI, update active listener immediately upon key binding without requiring manual save, and synchronize persisted settings (#171).

## 0.9.2

### Fixed
- **Voice actions client delivery.** Forward `action` from `sendAudio` in `lib/client-src/30-core.js` so hands-free spoken actions (`send`, `cancel`, `clear`, `newline`) execute properly in the client recording loop (#156).
- **Jargon editor input state decoupling.** Maintain distinct raw editing state `[jargonInput, setJargonInput]` in `VoiceSection` to prevent partial keystrokes from being wiped out before delimiters are typed (#157).
- **SenseVoice mandatory tokens parameter.** Wire `findTokensFile` into `startSensevoice` in `lib/index.js`, passing mandatory `--tokens` to `sherpa-onnx-offline-http-server` on startup (#158).
- **SenseVoice installer archive cleanup.** Unlink `sensevoice.tar.bz2` immediately after extraction and on download failure, reclaiming ~150 MB disk space (#159).
- **Status fetch recovery.** Reset `chainsPromise = null` on error in `modeChain()`, preventing temporary network hiccups from permanently disabling voice recording (#160).
- **Chinese voice commands & structured prompts.** Add Chinese speech commands to `extractVoiceActions` (`发送`, `取消`, `清空`, `换行`) and `submitToStructuredPrompt` (`是`, `好`, `确认`, `同意`, `不`, `否`, `取消`) (#163).

### Refactored
- **Lifecycle tool disposal.** Wrap `ctx.tools.register(transcribe_audio)` in `ctx.effect`, ensuring clean tool unregistration during plugin reload (#161).
- **Code hygiene & deduplication.** Remove duplicate `isAutoLang` definition in `lib/index.js`, importing the canonical helper from `./provider-http.js` (#162).
- **Client build parity check.** Add `scripts/build-client.mjs --check`, `npm run build:check`, and `test/build-parity.test.mjs` to ensure generated `lib/client.js` stays in sync with `lib/client-src/` (#164).

## 0.9.1

### Security
- **Route source authorization hardening.** Strictly reject `sec-fetch-site: same-site` cross-origin requests on POST routes (`/dsh-voice/transcribe`, `/dsh-voice/polish`, `/dsh-voice/config`, `/dsh-voice/sensevoice-installer`), enforcing strict same-origin or loopback caller verification (#117).
- **SenseVoice installer status protection & path redaction.** Guard `/dsh-voice/sensevoice-installer` GET and POST with trusted caller verification (403 for untrusted requests) and redact absolute filesystem paths from model and token status responses to prevent server directory layout disclosure (#153).
- **Audio tool path boundary & magic-byte validation.** Enforce strict boundary validation (`isPathUnderRoots`) against allowed roots (`allowedAudioDirs`, `~/.dsh`, `tmpdir`, `cwd`) before `stat`/`read` in `transcribe_audio` tool, protect against realpath symlink traversal escapes, and validate audio magic bytes independently of file extension (#152).

### Fixed
- **Jargon editor placeholder localization.** Localize user dictionary placeholder examples in English and Chinese locale dictionaries (`jargonPlaceholder`) instead of hardcoding Russian literals (#151).
- **Release artifact hygiene & package verification.** Relocate release archives outside the source tree, exclude `*.tgz` and `.worktrees/` via `.gitignore`, and update `npm run pack:check` to guard against stray tarballs and support npm 12 pack JSON output (#154).

## 0.9.0

### Added
- **Host settings persistence route (`/dsh-voice/config`).** Added dedicated host route for reading (`GET`) and updating (`PUT`/`POST`) plugin configuration directly on the server, solving DSH network limitations where client-side settings persistence is blocked in non-loopback environments (Gitea #149).
- **Security & validation for config routes.** Implemented fail-closed caller verification (`isTrustedCaller`), allowed HTTP method enforcement, 503 handling when settings service is unavailable, and full schema validation against `BaseConfig`.

### Changed
- **Client settings card (`VoiceSection`) network-ready.** Fetches `/dsh-voice/config` on mount to render and populate settings even when kernel `configForms` reports `unavailable` or `writable: false` over the network. Saves directly via HTTP `PUT /dsh-voice/config` with clear error toasts on failure and loopback `scope.set` best-effort sync.

### Fixed
- **Hotkey typing collision guard.** In `installHotkey`, non-modifier hotkeys (such as letter keys) no longer trigger voice recording when typing inside text inputs, textareas, or `contenteditable` elements.

## 0.8.38

### Fixed
- **whisper-server & SenseVoice autostart on deferred settings loading.** Autostart is wired to trigger once Cordis `settings` service finishes deferred initialization, on `scope.watch()` settings updates, and on `loader/volatile-update`, `settings/document-updated`, and `config` events (GooDAnDReaDY/dsh-voice#8, Gitea #147).
- **Extended autostart healthcheck timeout.** Increased healthcheck timeout from 10s to 30s to reliably support cold model loading on Apple Silicon (Metal) and CPU.
- **Premature child process exit detection.** Added immediate exit code check so failed binary launches fail fast with a descriptive error instead of waiting for the full timeout.

## 0.8.37

### Fixed
- **Settings form appears on DSH 0.1.7-rc.1.** Config fields are declared with `.volatile()` so `@deepseek-ai/dsh-settings` recognizes the plugin's editable configuration schema and announces the `dsh-voice` namespace to client forms (GooDAnDReaDY/dsh-voice#7, Gitea #145).
- **Volatile configuration decoding.** `createConfigReader` unwraps volatile `.get()` nodes on modern DSH cores while caching resolved values across requests.
- **Client slot cleanup.** Removed dead `settings.plugin.item` registration while preserving `plugins.item` and `plugins.row.config`.

## 0.8.36

### Fixed
- Settings no longer wait on the removed settingsScope service. The client uses configForms (#143).

## 0.8.35

### Fixed
- **Windows: hide console windows for spawned processes.** Pass `{ windowsHide: true }` to `ffmpeg` audio conversion in `lib/wav.js` and `tar` archive extraction in `lib/sensevoice-installer.js`. On Windows under Electron (DSH Desktop GUI), this prevents the brief black console window (`conhost.exe`) flash when invoking child processes (GooDAnDReaDY/dsh-voice#6, Gitea #141).

## 0.8.34

### Fixed
- **localOnly accepts SenseVoice.** A chain that uses only the local SenseVoice engine no longer fails closed with a whisper-only error.
- **SenseVoice installer lifecycle.** The download waits for disk backpressure and closes the file if the transfer fails. Reloading the plugin removes the installer route.
- **Health checks no longer leave timers behind** when whisper.cpp or SenseVoice is down.
- **Jargon replacements reuse compiled expressions** instead of building a new RegExp for every phrase.
- **Docs no longer advertise `/dsh-voice/realtime`.** That WebSocket route is not implemented.
- **GitHub mirror keeps `lib/*.js`.** The publication allowlist expands npm `files` globs, so the plugin sources are part of the sanitized tree.

## 0.8.33

### Fixed
- **Settings reachable again on the plugin's own page**: the current DSH core
  (0.1.6-alpha.2) renders a plugin's configuration page only for entries registered
  in the plugin-list seat `plugins.item` — that is how `dsh-agentrouter` and
  `dsh-agent-orchestrator` show their settings, while the row seat and the legacy
  card alone leave the page without the form. The view-aware `PluginCard` is now
  registered there too (`id: 'dsh-voice'`, order 60, static label); the row seat and
  `settings.plugin.item` stay as fallbacks. The change lives in
  `lib/client-src/73-plugin-card.js` and `lib/client.js` was rebuilt.

## 0.8.32

### Added
- **1-Click SenseVoice-Small Installer**: On-demand download and unpacking of the ultra-fast local SenseVoice-Small ONNX model (`model.int8.onnx`, `tokens.txt`) to `~/.dsh/models/sensevoice` via loopback endpoint `/dsh-voice/sensevoice-installer`.
- **Gated Turn-Taking & Echo Prevention**: Automatically mutes the microphone input when the assistant is speaking (`dsh:tts:start` and `dsh:tts:stop`), avoiding acoustic echo and feedback into transcripts.
- **Barge-In Speech Interruption**: True voice barge-in support allowing immediate interruption of ongoing assistant speech when the user begins talking.
- **Live Ghost Text Interim Preview**: Dynamic interim transcript preview inside the recording pill before the final sentence chunk is finalized.
- **SVG Silence Ring Timer**: Visual circular SVG timer animation in the composer dock during the pending auto-send delay.
- **Hands-free Voice Action Commands**: Voice-triggered control commands ("send", "cancel", "clear", "new line") executing directly without cluttering draft text.
- **Interactive Structured Prompt Voice Answers**: Spoken phrases can automatically select and trigger options in active modal question prompts.
- **Developer Lexicon & IT Jargon Correction**: Phonetic auto-correction of programming slang and technical terms (GitHub, Docker, Kubernetes, pnpm, etc.) with customizable dictionary editing in Settings.
- **Individual Toggle Switches**: Every enhancement feature can be independently toggled on or off directly in the Settings Card.

## 0.8.31

### Fixed
- **The plugin no longer breaks the whole client layer**: the two composer
  registrations (`conversation.input.right`, `conversation.input.dock`) declared
  `label` but no `locale`, so the core resolved the label through an empty inject
  face and threw `cannot get property "t" without inject` while building the slot
  snapshot. That exception aborted the client batch, which is why the Settings
  sections and every plugin settings card disappeared. Both entries now declare
  `locale: NS`.
- **Settings reachable again**: the settings card registered into
  `settings.plugin.item`, a slot the current DSH core (0.1.6-alpha.2) no longer
  renders. The surface now registers into the Plugins page row seat
  `plugins.row.config` first, keyed `@goodandready/dsh-voice#dsh-voice`
  (`rowConfigKey(package, rowId)`): the plugin's row gains a configure control whose
  page is the settings form (`view: 'page'`, open and without our card chrome) plus
  a one-line state for `view: 'summary'`. The legacy seat stays as a fallback.

### Added
- This changelog.


## [0.9.38] - 2026-10-19

### Added
- **Visual Microphone Clipping & Low Volume Indicator (#283)**:
  - Real-time time-domain analysis in `currentLevel(rec)` using `AnalyserNode.getByteTimeDomainData` detecting digital clipping (samples reaching <= 1 or >= 254 on 8-bit scale).
  - Weak signal detection when speech was present (`hadSpeech`) but RMS amplitude is below 0.08 (< -38 dBFS).
  - Smooth 800ms decay smoothing to prevent rapid UI flickering.
  - Dynamic visualizer wave/orb tinting using DSH CSS variable tokens (`var(--dsw-alias-state-warning-primary)` for clipping and `var(--dsw-alias-label-secondary)` for weak signal).
  - Status indicator badges in recording pill with tooltips: `Clipping` / `Low signal`.
  - Diagnostic metrics tracking in `statsTracker.recordDiagnostic` and `/dsh-voice/transcribe` (`clipping`, `lowVolume`).
- **Undo Last Chunk via Voice Command & Shift+Tab (#285)**:
  - Spoken undo triggers in Russian, English, and Chinese: `отмени последнее`, `сотри последнее`, `удали последнее`, `откати последнее`, `undo`, `undo last`, `undo chunk`, `撤销`, `撤销上一句` in `extractVoiceActions` (`lib/normalize.js`) and `SESSION_COMMANDS` (`lib/transcribe-core.js`).
  - Supports both standalone voice command and trailing trigger syntax without inserting aborted speech.
  - Global hotkey `Shift+Tab` during active dictation / recording immediately rolls back the last inserted text chunk and focuses the composer.
  - Interactive undo button next to Stop in dictation recording pill when history is available.
  - Rich feedback badge in composer pill displaying the rolled-back chunk text: `Insert undone: "[chunk]"`.

## [0.9.37] - 2026-10-18

### Added
- **Bilingual Developer Context Prompt (#280)**:
  - Added `bilingualDeveloperPrompt` and `bilingualCustomPrompt` in `lib/schema.js` and `buildTranscriptionPrompt()` in `lib/transcribe-core.js`.
  - Injects bilingual developer primer (git, docker, npm, pnpm, PR, API, JSON, async/await) into STT prompts (Groq, OpenAI, local-whisper, SenseVoice, Deepgram keywords) for Russian and mixed-language dictation.
  - Eliminates Cyrillic transliteration of English CLI commands, package names, and technical terms.
  - Settings UI toggle in hardware options card with customizable prompt support.
- **1-Click Microphone Noise Floor Auto-Calibration (#281)**:
  - Added 2-second ambient noise calibration tool (`calibrateNoise` in `lib/client-src/72-hooks.js` and `72-hardware.js`).
  - Measures room background noise level using Web Audio API `AnalyserNode` and automatically calculates optimal `noiseGateDb` threshold (RMS ambient + 5 dB, clamped to [-55 dB, -25 dB]).
  - Provides visual progress feedback, success badge, and automatic settings persistence.

## [0.9.36] - 2026-10-14

### Security & Hardening (#277)
- **LAN Access Protection & Session Tokens**:
  - Mutating and quota-consuming endpoints (`/transcribe`, `/polish`) require a cryptographically secure session auth token (`x-dsh-voice-token`) for non-loopback LAN callers, preventing unauthorized STT/LLM quota burn.
  - Model installer (`/dsh-voice/sensevoice-installer`) and express hardware benchmark (`/dsh-voice/benchmark`) strictly enforced to `loopbackOnly: true`.
- **Model Checksum Pinning & Secure Extraction**:
  - Pinned SHA-256 digests verified for SenseVoice and Whisper Large-v3-Turbo model archives before extraction. Mismatched downloads are immediately rejected and purged.
  - Added `--no-same-owner` flag to tar extraction to prevent permission/symlink exploitation.
- **Daemon Command Sanitization**:
  - Strictly sanitized language and parameter arguments in `lib/local-daemon.js` to eliminate shell argument injection vectors.
- **Dead Code Cleanup**:
  - Removed duplicate listener blocks and legacy settings registration attempts in `lib/index.js`.

## [0.9.35] - 2026-10-13

### Added
- **1-Click Whisper Large-v3-Turbo Installer (#274)**:
  - Automated download and extraction of quantized `sherpa-onnx-whisper-turbo.tar.bz2` models (`turbo-encoder.int8.onnx`, `turbo-decoder.int8.onnx`, `turbo-tokens.txt`) to `~/.dsh/models/whisper-turbo`.
  - Intelligent dual-architecture argument builder in `buildSensevoiceArgs`: dynamically detects Whisper vs SenseVoice models and passes appropriate flags (`--whisper-encoder` / `--whisper-decoder` vs `--sense-voice-model`).
  - Model preset switcher in settings card UI (`SenseVoice-Small` vs `Whisper Large-v3-Turbo`).
- **Hardware Acceleration Backends & Express Benchmark (#275)**:
  - Added native support for `coreml` (Apple Silicon), `openvino` (Intel), and `cuda` (NVIDIA) execution providers in `resolveSensevoiceProvider` and settings select dropdown.
  - Dedicated express hardware benchmark endpoint `POST /dsh-voice/benchmark` testing Real-Time Factor (RTF) and inference latency on a 1.0s synthetic 16kHz WAV sample.
  - Instant hardware benchmark trigger button and metrics card in settings UI showing RTF, latency (ms), hardware platform and CPU cores.

