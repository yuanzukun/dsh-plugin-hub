// dsh-permgate — 命令结构化分解与段级判定（纯函数，不依赖 DSH 运行时）
//
// 为什么独立成文件：命令解析是自成一体的纯函数，不依赖 permgate 的任何闭包状态，
// 可独立单元测试；index.js 已近 4800 行 / 310 KB，逼近可维护上限。
//
// 本文件存在的理由（核心安全属性）：
//   allow 例外是「对某个命令形态的授权」，它的作用范围必须精确等于用户写下的那一条命令 ——
//   不能因为命令里还串了别的段，就顺带放行那些段。
//   旧实现用【整条命令串】匹配例外，于是 `git status *` 编译出的 `^git status( .*)?$` 里的 `.*`
//   吞掉了 `;` `|` `&&` `` ` `` `$()` 之后的一切，实测 11 条命令被静默执行（含 `rm -rf ~/.dsh`）。
//   本文件把匹配对象从「整条命令串」改为「单个命令段」，这是唯一的根因修复点。
//
// 失败方向一律 fail-closed：读不懂的构造标段级 opaque，整行读不懂则返回 ok:false，
// 由调用方落回分类默认值 —— 绝不猜测 shell 语义（那是参考工程 3600 行的深度，不在本次范围）。

// 命令工具 → shell 方言：index.js 的 COMMAND_TOOLS 由它派生，保证「工具属于哪个 shell」只有一份定义
export const SHELL_OF_TOOL = { pwsh: 'pwsh', bash: 'bash' }

/**
 * 查找表构造单点：**必须**产出不继承 `Object.prototype` 的字典。
 *
 * 本文件所有 `NAME: 1` 形式的表都经此构造。理由：表的键来自**命令文本**（命令名、
 * 选项、子命令），而查表处多数用真值判断（`if (!WRAPPERS[name]) break`、
 * `if (NESTED_EVAL[base])`、`PRIV_VALUE_IS_COMMAND[prevPrefix]`）。用对象字面量时
 * 表会继承 `Object.prototype`，于是下面这些**恒为真值**：
 *
 *     WRAPPERS['constructor']              = function Object() { [native code] }
 *     NESTED_SHELLS['constructor']         = 同上
 *     STATEMENT_KEYWORDS['constructor']    = 同上
 *     PRIV_VALUE_IS_COMMAND['constructor'] = 同上
 *
 * 这不是理论问题，三条路径都已实测复现（`commandNameOf` 会小写化，故只有
 * `constructor` 与 `__proto__` 两个名字逃得掉 —— 其余原型名如 `toString` 变成
 * `tostring` 就安全了）：
 *
 *   ① **误报**：`constructor rm -rf /` 被当成「`constructor` 是嵌套 shell，`rm` 是它的
 *      内联程序」→ 判 deny。而 `constructor` 不是 shell，`rm` 只是它的参数。
 *      对照同形状的普通命令名 `foo rm -rf /` 是 allow —— 两者结论不同才是问题。
 *      带扩展名的脚本同样触发：`constructor.cmd rm -rf /` / `.exe` / `.bat` / `.ps1`。
 *   ② **候选死结**：`constructor x` 的 label 被吃成 `x`，候选生成器产出 `x *`，
 *      而它**匹配不上原命令**（`matchCommand('x *', 'constructor x')` = false）——
 *      用户点「允许并记住」写入的例外永不生效，命令照旧弹窗，判重又让该候选下次消失。
 *   ③ **例外被吞**：裸 `constructor` 的 label 成了空串 → 判 `unparsable` →
 *      按设计跳过 allow 例外，用户写的 `constructor`=allow 静默失效。
 *
 * 为什么改**表的构造**而不是逐处加 `=== 1`：一处改动覆盖该表全部查表点，日后新增
 * 查表处不会漏；而本文件已有 11 处真值判断，逐处改既易漏又会被后人写回真值形式。
 * 这与 `blastRadiusOfSegment` 里 `skip` 用 `Object.create(null)` 是同一条纪律
 * （那里早已写明「不能用 `{}`」），现在统一到同一个单点上。
 *
 * 代价：无原型对象没有 `hasOwnProperty` 等方法。本文件对这些表只做 `t[k]` 取值与
 * `for...in` 之外的遍历，不用其原型方法，故无影响。
 *
 * @param {object} src 字面量表
 * @returns {object} 同内容、原型为 null 的字典
 */
const dict = (src) => Object.assign(Object.create(null), src)

/**
 * 共享的**只读**空字典，用于「表里没有这一项」的兜底。
 *
 * 为什么不用 `|| {}`：本文件已确立「查表用的对象不得继承 `Object.prototype`」这条纪律，
 * 而 `|| {}` 会在兜底路径上悄悄退回有原型的对象 —— 当前那两处的键必以 `-` 开头
 * （见 `unwrapWords` 里的 `token.startsWith('-')`），原型属性名无一以 `-` 开头，
 * 故今天不可达；但留着它就是给后人一个「`{}` 也能用」的错误示范。
 * 冻结是为了让误写立刻抛错（ESM 默认严格模式），而不是静默污染共享对象。
 */
const EMPTY_DICT = Object.freeze(dict({}))

/**
 * 破坏性命令名单 —— `command` 分类下「破坏性命令」子设置（destructive）的内置内容。
 *
 * 名单**固定，不开放用户增删**：用户能改的只有子设置的 action（询问/允许/拒绝）与 reason。
 * 理由：判定内容一旦可编辑，就会出现「名单被清空后用户以为还有保护」的假象；
 * 而名单本身是内置知识，不是用户策略。
 *
 * 匹配对象是**段首 label**（由 segmentLabel 归一化：去路径前缀、去 .exe、小写），
 * 不是整条命令串的子串 —— 旧实现用整串正则匹配，于是 `format` 这个词出现在任何位置都算危险：
 * `git log --format=oneline`、`docker ps --format json`、`npm run format`、`echo "takeown"`
 * 全被判危险，用户配的 `git log *`、`Get-Process *` allow 例外永远走不到免审通道。
 *
 * 刻意**不列入**默认名单（避免误伤日常操作）：
 *   mv / cp / Set-Content / Out-File / New-Item / Copy-Item / tee / git push / npm publish
 * 它们都能造成破坏，但都是高频日常操作，列入会让默认体验变成「每两步一弹窗」。
 */
export const DESTRUCTIVE_LABELS = new Set([
  // 删除 / 销毁
  'rm', 'rmdir', 'del', 'erase', 'rd', 'remove-item', 'ri',
  'dd', 'mkfs', 'shred', 'truncate', 'wipefs',
  // 磁盘 / 分区
  'format', 'diskpart', 'fdisk', 'parted',
  // 进程 / 电源
  'taskkill', 'kill', 'pkill', 'killall', 'stop-process', 'stop-computer',
  'shutdown', 'reboot', 'halt', 'poweroff',
  // 提权
  'sudo', 'doas', 'su', 'pkexec', 'runas', 'gsudo',
  // 权限 / 属主
  'icacls', 'takeown', 'chmod', 'chown', 'chgrp', 'set-executionpolicy',
  // 注册表 / WMI
  'reg delete', 'wmic',
])

// 提权前缀：在 DESTRUCTIVE_LABELS 里、但**不在 WRAPPERS 里**（它们改变权限，不是透明包装）。
// 命令头解析必须能穿过它们，否则「提权 + 真命令」的组合会被当成「提权命令 + 目标实参」。
//
// 本表是「哪些命令算提权前缀」的唯一来源；`GROUP_MEMBERS.priv` 由它的键派生，不手写第二份。
// 两份手写表会静默漂移，方向 fail-open：只改其中一份时，新提权命令缺档，
// `kill *`=deny 这类例外也会被绕过。
//
// 位置在 GROUP_MEMBERS **之前**是必须的：后者要用 `Object.keys(PRIV_PREFIXES)` 派生 priv 组。
const PRIV_PREFIXES = dict({ sudo: 1, doas: 1, su: 1, pkexec: 1, runas: 1, gsudo: 1 })

// 导出本表供测试断言「分组表由它派生」。**用 `export {}` 列表而不是 `export const`**：
// regressions.mjs 有一条结构断言按 `^const PRIV_PREFIXES = ` 取定义行（要求以 `dict(` 开头），
// 加上 `export ` 前缀会让那条断言找不到定义而红灯。
export { PRIV_PREFIXES }

/**
 * 破坏性名单的**分组** —— 组决定「伤害落在哪」，因而决定该用哪套判据。
 *
 * 分组本身不是新知识：上面 `DESTRUCTIVE_LABELS` 的注释从一开始就分了六组，
 * 但**代码里没有任何一处消费它**，于是下面四条走的是同一条路（同一个布尔值 → 同一个动作）：
 *
 *     rm test.txt          目标在工作区内
 *     sudo ls              无目标
 *     taskkill /im x.exe   无路径目标
 *     rm -rf B:\           目标是一整个盘
 *
 * 后果不是「少一条警告」，而是设置会被关掉：大分类设 allow 后 `rm test.txt` / `sudo ls`
 * 每次弹窗，用户被吵到就把子设置也设成 allow —— `rm -rf B:\` 从此静默放行。
 * 意图（D-6「大分类 allow 时破坏性命令仍按子设置走」）没错，**错的是粒度**：
 * 它假设「破坏性命令」是同质类别，而实际上「删工作区内一个构建目录」与「删盘根」
 * 除了都叫 rm 之外没有任何共同点。
 *
 * 组的第二个作用：`proc` / `power` / `reg` 三组**结构性地判不出爆炸半径** ——
 * 它们的伤害对象是进程 / 电源状态 / 注册表，而半径判据找的是**文件系统路径**，找错了东西。
 * 无论怎么带参数都是 null（`kill 1234` / `kill -9 /tmp/x` / `shutdown /s` 全部 null；
 * 硬塞 `kill -9 C:/Windows` 才有输出，但那是无意义输入）。故这三组走**组档**，
 * 判据是「label 属不属于这一组」，不看目标。
 *
 * 双向一致（并集 = `DESTRUCTIVE_LABELS`、无重复、无遗漏）由测试断言守住：
 * 新增 label 忘了分组时该命令会静默落 `inside` 档 —— 这正是最需要防的漂移，
 * 不能靠人记得，必须让断言红灯。
 */
export const GROUP_MEMBERS = dict({
  // 删除 / 销毁 —— 走半径档
  del: ['rm', 'rmdir', 'del', 'erase', 'rd', 'remove-item', 'ri', 'dd', 'mkfs', 'shred', 'truncate', 'wipefs'],
  // 磁盘 / 分区 —— 走半径档
  disk: ['format', 'diskpart', 'fdisk', 'parted'],
  // 进程 / 电源 —— 走组档（半径判据恒 null）
  proc: ['taskkill', 'kill', 'pkill', 'killall', 'stop-process'],
  power: ['stop-computer', 'shutdown', 'reboot', 'halt', 'poweroff'],
  // 提权 —— **两套都走**（见 RADIUS_GROUPS 的注释）。
  // 成员由 `PRIV_PREFIXES` 的键派生（顺序即该表的声明顺序，稳定）：本组与那张表是
  // 同一语义规则，手写两份必然漂移，而漂移方向 fail-open（见 PRIV_PREFIXES 的注释）。
  priv: Object.keys(PRIV_PREFIXES),
  // 权限 / 属主 —— 走半径档。注意它与 priv 是**两件事**（用户 2026-09-28 澄清）：
  //   提权改的是「当前进程以什么权限运行」（`sudo rm -rf /` 提升的是自己），
  //   权限变更改的是「目标文件的权限位」（`chmod 777 x.sh` 改的是 x.sh）。
  //   故 perm 不归 priv 档 —— 它天然适配半径判据（带系统目标判 system、带区内目标判 null）。
  perm: ['icacls', 'takeown', 'chmod', 'chown', 'chgrp', 'set-executionpolicy'],
  // 注册表 / WMI —— 走组档
  reg: ['reg delete', 'wmic'],
})

/**
 * label → 组 的反向表，由 `GROUP_MEMBERS` **派生**（不是第二份手写清单）。
 *
 * 为什么必须是派生：两张手写的表迟早漂移，而漂移的后果是某个命令落进错的组、
 * 拿错判据、静默落 `inside`。这与 `BLAST_ORDER` 那条纪律同源
 * （`:1614` 注释：曾在三处手抄，漂移时消费侧静默跳过）。
 */
export const GROUP_OF_LABEL = (() => {
  const m = Object.create(null)
  for (const g of Object.keys(GROUP_MEMBERS)) {
    for (const l of GROUP_MEMBERS[g]) m[l] = g
  }
  return m
})()

// 组 → 档 的映射单点（**不在多处 if/else 里重复**，理由同 GROUP_OF_LABEL）。
// 只有「半径判据不适用」的组才需要自己的档；del / disk / perm 三组的差异**恰恰是半径**，
// 给它们各自一个档就等于让用户配六个「删除类」开关才能表达「区内静默、区外拦」——
// 而半径档一个开关就表达了，且跨组一致（删文件与改权限在工作区内同样无害）。
const GROUP_TIER = dict({ proc: 'proc', power: 'power', priv: 'priv', reg: 'reg' })

// 走**半径档**的组。`priv` 两套都走：提权命令的 blast 反映的是**内部命令**的半径
// （`sudo rm -rf /etc` 的 system 来自 /etc，不是来自 sudo 本身），而提权这件事本身
// 也需要一个档 —— 故两者并存、取最严：
//     sudo ls          → 只命中 priv（无内部目标）
//     sudo rm -rf /etc → 命中 priv + wide，取 wide
// 副作用必须写进面板：把「提权」设为 allow 后 `sudo rm -rf /` 仍然 ask（被 wide 压过），
// 不说明白会被当成 bug。
const RADIUS_GROUPS = dict({ del: 1, disk: 1, perm: 1, priv: 1 })

/**
 * `PURE_RADIUS_GROUPS` —— 纯半径组：走半径档、且没有自己的组档的那些组。
 *
 * 定义 = `RADIUS_GROUPS` 的键 − `GROUP_TIER` 的键（= `del` / `disk` / `perm`）。
 *
 * 必须是派生而不是第三份手写清单：两份清单漂移后，新增半径组会静默落 `inside`
 * （fail-open），而测试仍按旧名单遍历、不会报错。
 *
 * `priv` 被排除：它虽然在 `RADIUS_GROUPS` 里，但只在 `seg.blast` 非 null 时才并半径档；
 * 提权命令自己没有目标、blast 恒 null，故 `sudo ls` 只命中 `priv`、没有 `inside` 档。
 */
export const PURE_RADIUS_GROUPS = Object.keys(RADIUS_GROUPS).filter((g) => GROUP_TIER[g] === undefined)

/**
 * `BARE_INTERACTIVE` —— 无实参时会进入自己的交互 shell 或阻塞等 stdin 的命令。
 *
 * 为什么归 `unknown` 而不是 `inside`：在 DSH 的非交互执行环境下它们要么挂住调用、
 * 要么读到 EOF 后退出，**不会真的动磁盘** —— 但后果**读不出**，与「目标读不出」
 * 同性质（都是「无法判定实际会发生什么」）。fail-closed 方向是问一次。
 *
 * 注意这是**形态**判据（看有没有非选项实参），不是 label 判据：
 *     parted /dev/sda    有实参 → 走半径档 → system|/dev/sda   ✅
 *     parted             无实参 → 归 unknown                    ✅
 *     dd of=/dev/sda     有实参 → 走半径档 → system|/dev/sda   ✅
 *     dd                 无实参 → 归 unknown                    ✅
 * 若按 label 判（只要叫 parted 就归 unknown），`parted /dev/sda` 那条**真实的 system
 * 警告会被降级成「无法判定」** —— 那是把已知的更严重结论换成更模糊的结论，方向错了。
 *
 * `shutdown` / `reboot` 这类「裸跑 = 真的会执行」（shutdown 裸跑即一分钟后关机，
 * man shutdown(8)：`If no time argument is specified, "+1" is implied`）**不在此表**：
 * 它们属 power 组，组档判据不看有没有目标，已被完整覆盖 —— 不需要第二条规则。
 */
export const BARE_INTERACTIVE = dict({ diskpart: 1, parted: 1, dd: 1 })

/**
 * `NON_PATH_ARG` —— 实参是**策略名**而非路径，故 `blastRadiusOf` 恒返回 null 的命令。
 *
 * 与 `BARE_INTERACTIVE` 的区别是判据类型：那个看「有没有实参」，这个看「是谁」——
 * `set-executionpolicy` 无论带不带实参，blast 恒 null（裸跑 / 带策略名 / 带 -scope 四种
 * 形态实测全 null），因为它根本没有路径参数可判。
 *
 * 为什么必须单独处理：它在 `perm` 组（走半径档），实参不是路径 → blast 恒 null
 * → 落 `inside` → 大分类 allow 时**静默**。而它的真实效果是
 * `Set-ExecutionPolicy unrestricted` 让任何脚本无签名运行 —— **降低整机安全限制**，
 * 与 `rm -rf ./build`（区内删个构建目录）完全是两回事。
 *
 * 这是「无参数 = 默认动作」那条论证的延伸：判据不该按**组**划，
 * 该按「**该组的判据能否处理它的所有成员**」划。`perm` 是唯一半径判据覆盖不全的组。
 */
export const NON_PATH_ARG = dict({ 'set-executionpolicy': 1 })

/**
 * `diskpart` 的 `/s <脚本>` 形态。
 *
 * 它**有**实参，故不命中 `BARE_INTERACTIVE` 的形态判据；而那个实参是**脚本文件**
 * 而非操作目标 —— 半径判据判不出脚本内容的影响（实测 `diskpart /s script.txt` 的 blast
 * 是 null：`script.txt` 被当成路径判为「区内」）→ 落 inside 档 → 大分类 allow 时静默。
 *
 * 而它比裸跑**危险得多**：裸跑只进交互、读到 EOF 就退出，`/s` 会真的执行脚本里的分区操作。
 * 故按「后果读不出」归 `unknown`，与 `NON_PATH_ARG` 同性质。
 */
export const DISKPART_SCRIPT_FLAGS = dict({ '/s': 1, '-s': 1 })

// 语句关键字：段首是它们时，真正的命令还在后面（`foreach ($x in $y) { Remove-Item $x }`）。
//
// 两张表分开维护，判定时**任一张命中**就继续向后找 —— 因为本模块不知道这段属于哪个 shell
// （`segmentLabel` 只拿词元列表，方言在词法器那一层才用得上）。合表的代价是极小的：
// 这些词在任何一门语言里都不是可执行命令名，多跳过一个是无害的。
//
// bash 侧曾经完全缺失（本表只有 PowerShell 词汇），后果是 `;` 分段之后
// `if true; then rm -rf ~/.dsh; fi` 的 `then rm -rf ~/.dsh` 这一段把 `then` 当成命令名，
// 真正的 `rm` 再也不会被看到 —— 破坏性子设置整个跳过（实测：大分类 allow + 子设置 deny 时，
// `rm -rf ~/.dsh` 是 deny，而包在 if/then/fi 里就是 allow）。`do` 恰好在 PS 表里，
// 所以 `while ...; do rm ...; done` 反而是 deny —— 这种「同一构造换个关键字就失效」正是遗漏的特征。
const PS_KEYWORDS = dict({ foreach: 1, if: 1, else: 1, elseif: 1, for: 1, while: 1, do: 1, until: 1, switch: 1, return: 1, function: 1, filter: 1, param: 1, begin: 1, process: 1, end: 1, try: 1, catch: 1, finally: 1, throw: 1, break: 1, continue: 1, trap: 1, in: 1, not: 1, and: 1, or: 1, class: 1, enum: 1, using: 1, exit: 1, dynamicparam: 1, data: 1 })
// bash 语句关键字与保留字：then/elif/fi/done/esac 是 if/for/while/case 的分段结果，
// time 与 ! 是命令前缀，case/select/coproc 开启新语句。
const BASH_KEYWORDS = dict({ then: 1, elif: 1, fi: 1, done: 1, esac: 1, time: 1, '!': 1, case: 1, select: 1, coproc: 1, '{': 1, '}': 1 })
const STATEMENT_KEYWORDS = dict(Object.assign({}, PS_KEYWORDS, BASH_KEYWORDS))

// 导出仅供测试按全表穷举（路径 basename 不得被当关键字）；**判定逻辑不消费本导出**。
export { STATEMENT_KEYWORDS }

// 子命令路由器命令族：label 细化到「git status」这一粒度，而不是一放全放「git *」。
// reg 也在此列：`reg delete` 是破坏性的而 `reg query` 不是，不细分就无法区分。
const ROUTER_CMDS = dict({ git: 1, npm: 1, pnpm: 1, yarn: 1, docker: 1, kubectl: 1, dotnet: 1, cargo: 1, go: 1, gh: 1, pip: 1, uv: 1, conda: 1, reg: 1 })

// 路由器命令的「带值选项」：跳过选项本身后还要跳过它的值（git -c key=val / npm --prefix ./x）
const ROUTER_OPT_VALUE = dict({ '-c': 1, '-C': 1, '--config': 1, '--config-env': 1, '--git-dir': 1, '--work-tree': 1, '--namespace': 1, '--exec-path': 1, '-H': 1, '--prefix': 1, '--cwd': 1, '--project': 1, '--registry': 1 })

// `routerSubLabelOf` 向后扫描的**上限**（见该函数注释里那段平方退化实测）。
//
// 为什么需要它：该函数的调用方 `isTargetEatingNameIn` 是**逐词元**调用的
// （`isPrivOperandWord` 在贪婪扫描里每个词元各问一次），而无上界的向后扫描与它相乘
// 即 O(n²)。实测 `su (/reg --config)*n`（路径形态的路由器名）n=8000 时
// `segmentLabels` 556.8 ms、`blastRadiusOfSegment` 1120.5 ms（倍率均 ≈4.0）。
//
// ⚠️ **上限是 load-bearing 的，不能按「改用无上限的 router 分支」修**：实测把本上限
// 去掉后，`su root (-/reg --config)*8000` 的 `segmentLabels` 由 8.1 ms 涨到 **551 ms**
// （倍率 3.89，标准平方）—— 那个词元既是「操作数形态」（`-` 开头）又按 basename 命中
// `ROUTER_CMDS` 的 `reg`，是唯一能同时走进贪婪扫描与向后扫描的形态。
//
// 计数口径：**两个维度各一个上限**，不是二选一。
//   · 词元维度 `ROUTER_SUB_SCAN_MAX * 2 + 8` —— 纯词元数的硬上界（防病态输入打转）；
//   · 带值选项维度 `ROUTER_SUB_SCAN_MAX` —— 跳过的**带值选项次数**上限。
// 为什么必须补第二个维度：只按词元计数时，**同一个键重复出现**会击穿上限 ——
// `su root reg (-c v)*n delete …` 每对占 2 个词元，n≥32 就越过 64，`delete` 扫不到、
// `reg delete` label 丢失、`headEnd` 由 3 掉回 1。原注释用「13 个键全用上也才 26 个词元」
// 论证上限不会误伤，那个论证**漏了同键重复**（13 是**去重后**的键数，重复出现不受它约束）。
// 补上次数维度后：13 个不同键仍远在 64 次之内，而同键重复到 64 次也能扫到子命令。
//
// 两个上限都只对**病态输入**生效：真实调用里带值选项从不超过个位数。
const ROUTER_SUB_SCAN_MAX = 64

// 前缀包装器：它们不改变后面命令的语义，但会占住「命令名」的位置，
// 使有效命令名判错 —— `env -u FOO rm -rf /` 剥之前有效命令名是 `FOO`，破坏性判定整个跳过。
//
// 除常见的 4 个之外，这里补了 4 个同样常见且不改语义的前缀：
//   command / builtin / exec —— shell 内建的前缀，后面跟的才是真命令
//   nohup / setsid            —— 只改信号与会话，不改命令
//   stdbuf / ionice           —— 只改缓冲与 IO 优先级
// 不加它们的后果与「wrapper 漏剥」完全同类（子设置 deny、大分类 allow）：
//   `find . -delete` → deny，而 `nohup find . -delete` / `command find . -delete` → allow，
//   `nohup rm -rf /x` 同样绕过破坏性判定。它们不是「罕见形态」，是日常写法。
// 代价：这些名字若真被当作命令调用（例如某个叫 `time` 的可执行文件），会被跳过一层 ——
// 但它们都是 shell 保留字或系统自带工具名，不存在同名用户命令的正常用法。
const WRAPPERS = dict({ env: 1, timeout: 1, nice: 1, xargs: 1, command: 1, builtin: 1, exec: 1, nohup: 1, setsid: 1, stdbuf: 1, ionice: 1 })
// 各 wrapper 的「带值 flag」：`-u FOO` 里的 FOO 是值不是命令。
// 只认精确拼写（`--unset=FOO` 自带值，不消耗下一个词元）。
const WRAPPER_VALUE_FLAGS = dict({
  env: dict({ '-u': 1, '-C': 1, '-S': 1, '--unset': 1, '--chdir': 1, '--split-string': 1, '--argv0': 1 }),
  timeout: dict({ '-s': 1, '-k': 1, '--signal': 1, '--kill-after': 1 }),
  nice: dict({ '-n': 1, '--adjustment': 1 }),
  xargs: dict({ '-n': 1, '-I': 1, '-i': 1, '-P': 1, '-L': 1, '-s': 1, '-d': 1, '-E': 1, '-a': 1, '--max-args': 1, '--replace': 1, '--max-procs': 1, '--max-lines': 1, '--max-chars': 1, '--delimiter': 1, '--eof': 1, '--arg-file': 1 }),
  stdbuf: dict({ '-i': 1, '-o': 1, '-e': 1, '--input': 1, '--output': 1, '--error': 1 }),
  ionice: dict({ '-c': 1, '-n': 1, '-p': 1, '-P': 1, '-u': 1, '--class': 1, '--classdata': 1, '--pid': 1, '--pgid': 1, '--uid': 1 }),
})

// 嵌套解释器：带内联程序时整段不可静态解析（程序正文是我们读不懂的另一门语言）。
// 不带内联程序的不算（`node --check x.js`、`python script.py` 都是可读的常规调用）。
const NESTED_INTERPRETERS = dict({ node: 1, deno: 1, bun: 1, python: 1, python3: 1, perl: 1, ruby: 1, php: 1, lua: 1, osascript: 1 })
const NESTED_SHELLS = dict({ sh: 1, bash: 1, zsh: 1, fish: 1, ksh: 1, dash: 1, cmd: 1, powershell: 1, pwsh: 1 })
// eval 族必然执行字符串，没有「不带程序」的形态
const NESTED_EVAL = dict({ eval: 1, iex: 1, 'invoke-expression': 1 })
// 解释器的内联程序 flag：`-e` / `-c` / `--eval` …，以及融合短选项（`node -pe` / `bash -lc`）。
//
// 融合形态必须覆盖：`bash -lc 'rm -rf x'` 与 `bash -c 'rm -rf x'` 完全等价（实测 Git Bash 两者
// 都执行字符串），但旧实现只认精确拼写与「以 e 结尾」，于是 `-lc` / `-ec` / `-ic` / `-uc` 全被
// 判成「可读的普通调用」—— 既不标 unparsable，也就**可以被 allow 例外授权**，
// 直接推翻「读不懂的内容不可被授权」这条底线（实测：例外 `bash *` 能放行 `bash -lc "rm -rf ~/.dsh"`，
// 却放行不了 `bash -c "..."`，只因后者被判 unparsable）。
//
// 判据放宽为「短选项串里含 c 或 e」：`c` 覆盖 shell 的 -c 与 python 的 -c，`e` 覆盖
// perl/ruby/node 的 -e。宁可多判 opaque（方向是收紧、只多弹一次窗），也不能漏判（方向是静默放行）。
const INLINE_PROGRAM_FLAG = /^(?:-c|-e|-E|--eval|--exec|--command|--print|-[A-Za-z]*[ceE])$/

// 命令名里出现这些字符即视为「认不出」（变量、通配符、shell 元字符）
const BAD_LABEL_CHARS = /[$%{}()'"`*?<>|;&=]/

/**
 * PowerShell 的转义表（反引号 + 一个字符）。真值由**官方解析器实测**逐格核对
 * （`[System.Management.Automation.Language.Parser]::ParseInput` + 实际执行取值）：
 *
 *     `n → LF(0x0A)   `r → CR(0x0D)   `t → TAB(0x09)   `0 → NUL(0x00)
 *     `a → BEL(0x07)  `b → BS(0x08)   `e → 字面 e       `f → FF(0x0C)   `v → VT(0x0B)
 *     `` → 字面反引号  `" → 字面双引号   `z → z（**未知转义 = 字符本身**，不是错误）
 *
 * ⚠️ `` `e `` 是**版本相关**的一格：PS 5.1 里它是**未知转义**、取字符本身 `e`
 * （实测 `ExpandString('"a`eb"')` → `aeb`），ESC(0x1B) 是 PowerShell 6.0 才加入的。
 * 本表按**宿主实际解析器（5.1）**取值：若这里写成 `\x1b`，以 `e` 开头的命令名会被
 * 写成 `<ESC>xxx`，破坏性名单与用户 deny 例外双双看不见 —— 实测 `erase`（`Remove-Item`
 * 的别名）与 `r`emove-item -Recurse -Force C:/x` 都会由 deny 变 **allow**（fail-open）。
 *
 * ⚠️ 与 bash 的 `\` **不同构**的地方（这正是本表必须存在、而不能照搬 bash 分支的原因）：
 *   · bash 的 `\` 后跟未知字符时保留反斜杠（`\z` → `\z`），pwsh 的 `` ` `` 后跟未知字符
 *     是**丢掉反引号**（`` `z `` → `z`）。实测执行结果分别为 `azb` 与 `a\zb`。
 *   · `` ` `` + 换行是**续行**，但它转义出的是**字面换行字符**：实测 `Write-Output one`+`` ` ``+NL+`two`
 *     的 token 是**一个** `Generic|one<NL>two`（不是两个词元）。词法器按「词元边界」处理它
 *     （见那里的说明）—— 命令名里含换行的形态无法执行，按边界处理只会让参数被切细，
 *     方向是收紧，不会放宽。
 *
 * 键是**单字符**（`next`），故用 `dict`（无原型）而不是 `{}`：`` `constructor `` 这类
 * 转义在 `{}` 上会读到原型方法、把「未知转义」误判成「已知转义」。
 */
const PWSH_ESCAPES = dict({
  n: '\n', r: '\r', t: '\t', 0: '\0', a: '\x07', b: '\b', e: 'e', f: '\f', v: '\v',
})

/**
 * 「这个词元到此为止」的分隔字符集 —— 供 `readPwshEscape` 的**行尾**分支判
 * 「行尾反引号是字面字符还是语法错误」。
 *
 * ⚠️ **只有这一个消费方**（全文件唯一的代码引用在 `readPwshEscape` 里）。第十轮把词法器中
 *    「`` ` `` + 换行」那处续行判据整体换成**词元维度**（`wordText` / `tokenTyped` /
 *    `lastGroupClose`）后，它**不再**引用本表 —— 两处判据不同维度，不得互相套用
 *    （见词法器引号外那条 pwsh 转义分支里「那处用的是 `PWSH_TOKEN_BREAK`（**字符**维度）」
 *    的说明：那处是对的，因为行尾没有「下一个词元」可言）。
 *    此前这里写的是「两个判据共用…故共用一张表」，那句话在第十轮之后已经过期。
 *
 * 逐格实测（官方解析器，`abc` + 该字符 + 反引号，看 `ParseInput` 报不报错）：
 *   报 `IncompleteString`（= 分隔符，反引号另起词元、后面什么都没有）：空白 `;` `|` `&`
 *     `(` `)` `{` `}` `,` `"` `'`
 *   报 `OK`（= **不是**分隔符，反引号紧贴词元、是**字面**反引号）：字母 数字 `.` `-` `_`
 *     `/` `:` `\` `~` `+` `=` `%` `@` `#` `!` `<` `>` `*` `?` `[` `]`
 * ⚠️ `<` `>` `[` `]` **不在**集合里（实测合法）—— 参数模式下它们不是运算符，凭直觉加进去会误判。
 * ⚠️ 引号也算分隔符：`"abc"` + 反引号实测 `IncompleteString`（与引号内的判据不同，见 `readPwshEscape`）。
 */
const PWSH_TOKEN_BREAK = /[\s;|&(){},'"]/

/**
 * pwsh **Parameter 词元**的整词形态（`-NoNewline` / `-Recurse` / `-NoEnumerate` / `-Verbose`
 * / `-Force` / `-rf` …）—— 供反引号续行守卫判「前一个词元是否已完结」。
 *
 * ⚠️ 与下面那个「带冒号收尾」的形态**必须分开**，因为两者在真实 PS 里的边界**不同级**：
 *   · 整词 `-NoNewline` + `` ` `` + 换行 → `Parameter[-NoNewline`]` + `NewLine`，
 *     `[Parser]` 报 **2 条 PipelineAst** = **语句边界**（必须 `flushSegment()`）；
 *   · 带冒号收尾的 `-Confirm:` + `` ` `` + 换行 → `Parameter[-Confirm:]` + `LineContinuation`
 *     = **词元边界、同一条语句**（只需 `flushWord()`）。
 * 把两者合并成一条判据（都用 `flushWord()` 或都用 `flushSegment()`）实测各错一族 ——
 * 前者实测仍然 `allow`（等于没修），后者会把同一句话切成语义独立的两段。
 *
 * 逐格实测（官方解析器 + 实参绑定，见 `decomposeCommand` 里反引号分支的完整论证）。
 *
 * ── 字符类：`33..126` 全字符两轮扫描（本轮修复，字符类此前窄 17 格）────────────────────
 * 判据是「PS 把 `-x<c>y` + `` ` `` + 换行 整体吃成一个 `Parameter[-x<c>y`]`、随后报 `NewLine`
 * （`stmts=2`，第二行**独立执行**）」。逐字符扫描官方解析器（本机 PowerShell 5.1，
 * `[Parser]::ParseInput` 的 token 表 + `PipelineAst` 语句数）：
 *
 *   · **STMT（语句边界，81 格，必须命中）**：词身
 *     `` ! # $ % * + - / 0-9 < = > ? @ A-Z \ ] ^ _ ` a-z ~ ``
 *   · **STICK（粘住，PS 判 `LineContinuation` / 一个 `Generic` 词元）**：
 *     `"` `&` `'` `(` `)` `,` `.` `:` `;` `[` `{` `|` `}`
 *   · 首字符 PS **还**允许 `?`：`-?y` 实测 `Parameter[-?y`]` + `NewLine`、`stmts=2`
 *
 * 旧字符类 `[A-Za-z_]` / `[A-Za-z0-9_/-]` 因此**漏判 16 格词身 + 1 格首字符、误判 0 格**。
 * 后果是端到端 fail-open（实测 `cmd /c ver -Path$p` + `` ` `` + NL +
 * `Remove-Item -Recurse -Force C:/Windows`：HEAD `deny` → 旧字符类 **`allow`**；
 * 用户显式配的 deny 例外 `remove-item *` 下同样 `deny` → `allow`）——
 * `-Path$p` / `-Filter*` / `-Name$n`（无空格紧跟取值）是 AI 生成 pwsh 的常见写法。
 *
 * ⚠️ **不要顺手扩 `PWSH_PARAMETER_COLON_TAIL`**：`-x!y:` / `-x$y:` 实测是
 *    `Parameter[-x!y:]` + `LineContinuation`（**词元**边界、`stmts=1`），与那条 COLON 正则
 *    的现行行为一致，扩它是无收益的改动。
 * ⚠️ 必须仍为 `false`（PS 实测 STICK / 非 Parameter）：`-x[y` `-x.y` `-x:y` `-1` `-` `--force`。
 */
const PWSH_PARAMETER_TOKEN = /^-[?A-Za-z_][A-Za-z0-9_/\-!#$%*+<=>?@\\\]^`~]*$/

/** pwsh Parameter 词元中**带冒号收尾**的那一族（`-Confirm:` / `-WhatIf:` …）：词元边界。 */
const PWSH_PARAMETER_COLON_TAIL = /^-[A-Za-z_][A-Za-z0-9_/-]*:$/

/**
 * 词元尾部是**成员访问 / 下标访问 / 静态成员访问**（`.Name` / `[0]` / `[k]` / `::y`，或
 * 以裸 `.` 收尾）—— 这类词元在 PS 里是**已完结的完整词元**，后面的反引号+换行是
 * `LineContinuation`（词元边界，同一条语句）。
 *
 * ⚠️ **必须与 `tokenTyped` 合取**：`a.b` / `x$y.y` 的尾部同样命中本判据，但官方解析器实测
 * 它们是**一个** `Generic` 词元（两行粘住）—— 差别只在词元的**首个字符**：
 *   · `$x.Name` / `$a[0]` / `"abc".Length` / `(Get-Item x).Name` → 首字符是变量/引号/分组块 ⇒ 切；
 *   · `a.b` / `x$y.y` / `abc]` → 首字符是普通字符 ⇒ **粘住**。
 * 只看尾部会多切 `a.b` 族（新误报）；只看首字符会漏掉 `.Name` 族（fail-open）。
 *
 * ⚠️ **本正则现在只作为「形态影子」的字符类来源**（见 `CHAR_CLASS`：`CC_WORD` / `CC_ALPHA_U`
 *    都由它逐码探针生成）—— 运行时判据走 `accessorTailOf(shape)`，**不再**对词元原文跑本正则
 *    （读 `wordText` 会触发 rope 扁平化，O(n²)，见 `newWordShape` 那段说明）。
 *    三支逐条对应关系写在 `accessorTailOf` 的说明里。
 *
 * ⚠️ 其中「下标访问」支（`(?<!\.)\[[^\]]*\]$`）**不能**放回本正则：它没有左锚定，失配时对
 *    每个起始位置各回溯一遍，退化成 O(n²)（实测端到端 `'"x"' + '['*64k + '`\n'` → 919 ms，
 *    HEAD 同形态 1.2 ms）。其余三支都以 `$` 结尾、无歧义分支，不存在同类回溯。
 *    下标支由影子的 `lastOpenIdx` / `closeBeforeLast` 两格承担（等价性证明见
 *    `bracketAccessorTailOf`）。
 */
const PWSH_ACCESSOR_TAIL = /(?<!\.)(?:\.[A-Za-z_]\w*|(?<!\.)\.|::[A-Za-z_]\w*)$/

/**
 * 词元尾部是**闭合引号**（引号串已完结）—— 与 `PWSH_ACCESSOR_TAIL` 同族，都是「typed 词元
 * 已完结」的尾部证据，同样**必须与 `tokenTyped` 合取**。
 *
 * ⚠️ 这一条是**必须的**，不是冗余：判据从「反引号前一个字符」改成「前一个词元」后，
 *    引号串**不再**由 `PWSH_TOKEN_BREAK`（它含 `'"`）覆盖 —— 少了本判据，第七轮已修的
 *    `"C:/Windows"` + `` ` `` + NL + `-Confirm:$false` 会**回退**成两行粘住
 *    （实测：`words` 由两个变回一个 `C:/Windows-Confirm:$false`，`blast` 由 `system`
 *    掉成 `unknown` ⇒ 用户显式配的 `wide=deny` 失明，fail-open 复发）。
 *
 * ⚠️ 判据对象是 **`segText`（段原文）而不是 `wordText`**：闭合引号**只进 segText**
 *    （引号分支是 `pushText(char)`，不写 `wordText`）—— 对 `wordText` 判恒不命中。
 *    而 `segText` 的尾部就是当前词元的尾部（两者逐字符同步写入，只有闭合引号例外，
 *    而那正是本判据要找的字符）。
 *
 * ⚠️ 该判据**不再**以 `PWSH_QUOTED_TAIL.test(segText)` 的形式直接跑正则（那会读 `segText`，
 *    见下），而是由 `segLastIsQuote` 这个 O(1) 增量标记回答；标记在 `pushText` 里**用本正则
 *    判刚追加的那一小段 `s`** 置位 —— 判据原文仍只有这一份，没有第二份定义。
 *
 *    为什么不直接读 `segText`：`segText += s` 只建 rope，任何内容读取（含正则）都要先
 *    扁平化成连续串（O(n) 拷贝），于是每个「反引号 + 换行」都触发一次全长拷贝，
 *    整段分解退化为 O(n²) —— 与 `segEndsWithSpace` 那条注释里的坑**完全同一个**
 *    （那是第一处，这是第二处）。
 *    实测 `'New-Item -Path $base' + ('`\n  -Name $n<i>')*N` 端到端
 *    20.2/365.1/1749.6 ms（N=8k/16k/32k）→ 改用标记后 6.0/4.8/10.9 ms；
 *    真实入口 `assessCommand` N=32000（520 KB）→ 1752 ms 降到同量级个位数毫秒
 *    （HEAD 同形态 59 ms）。900 格语料对拍判定分歧 **0 格**。
 *    ⚠️ 判 `s`（刚追加的那一段）与判 `segText` 末字符**恒同值**：`segText` 的末字符就是
 *    最后一次非空 `s` 的末字符，而空串不改变 `segText`（标记保持原值）。
 *    `/["']$/` 无嵌套量词、失配时每个位置只看一个字符 ⇒ 对 `s` 是线性的。
 */
const PWSH_QUOTED_TAIL = /["']$/

/**
 * 「文本尾部是一段连字符串、其后只跟空白」的**线性**判定 —— 等价于 `/-{min,}\s*$/`
 * 的「命中与否 / 命中起始下标」，但不回溯。
 *
 * ⚠️ 为什么必须手写而不能用正则：`/-{2,}\s*$/` **没有左锚定**，贪婪量词 + 可选空白 + `$`
 *    在**失配**时要对每个起始位置各回溯一遍，退化成 O(n²)。而词元长度无上界、内容完全
 *    由 AI 生成的命令决定，本判据又在词法器的**每一段**、`pushHeadLabels` 的**每个 head
 *    位置**都会经 `labelTokenIsQuotedLiteral` 走到。实测（本机 Node v24.19，取多次最小值）：
 *      · 纯正则 n=8k/16k/32k/64k → 56.2/221.5/904.0/3536.5 ms（倍率 ≈4.0，标准平方）；
 *        以连字符结尾（快速命中）时 0.0015–0.0120 ms/次。
 *      · 端到端 `segmentLabel(['my tools/' + '-'.repeat(n) + 'x'])` 同量级
 *        （54.0/217.8/875.7/3518.8 ms）；`assessCommand` 单次 n=100k（命令 98 KB）→ 8632 ms。
 *      · 放大器 `find . -exec sudo "<病态词元>" {} +` 以 ` ; ` 连接 n 段（词元
 *        `"my tools/" + "-"*8192 + "x"`）：n=25/50/100 → 1460/2904/5806 ms，
 *        同形 ASCII 对照 7.3/12.5/29.2 ms（约 200 倍）。触发面**不依赖引号**（双引号、
 *        单引号、pwsh 反引号转义空格、bash 反斜杠转义空格四种形态各 n=40k 均 ≈1.4 s）。
 *    判定卡死则 `tools/pre-execute` 不返回、审批弹窗不出现 —— 本文件在 `globMatch`、
 *    `flagEmbeddedPath` 两处已明确处置过同类缺陷（留有「旧实现组合爆炸/挂死」注释），
 *    这里是第三处，写法与它们同一种（线性反向扫描）。
 *    修好后实测：n=64000 时 `segmentLabel` 由 3518.8 ms 降到 0.27 ms；同一病态词元
 *    （n=100k）的 `assessCommand` 由 8632 ms 降到 1.67 ms。判定结果对拍分歧 **0 格**。
 *
 * 等价性（是证明，不是近似）：设 `end` = 剥掉尾部 `\s` 后的下标，`start` = 从 `end` 往前
 * 数的连字符串起点。正则命中于 `i` ⟺ `text[i…end]` 全是连字符（≥ `min` 个）且
 * `text[end…]` 全是空白 ⟺ `start ≤ i`；而 `i` 处必须先是连字符，若 `i < start` 则
 * `text[i]` 不是连字符（`start` 是连续段的左端）⇒ `i = start`。
 * 故「命中 ⟺ `end - start >= min`，且命中下标恒为 `start`」—— 与 `.exec()` 的 `index` 同值。
 *
 * ⚠️ 空白用 `\s` **逐字符**判，不要换成 `trimEnd()`：两者在本机 Node 下实测集合相同
 *    （25 个字符），但那是实现细节而非语言保证；判据按原文写，不引入第二套空白定义。
 *
 * @param {string} text 待判文本
 * @param {number} min 连字符串的最少个数（`/-{2,}\s*$/` 取 2，`/-+\s*$/` 取 1）
 * @returns {number} 命中时返回匹配起始下标（= `.exec()` 的 `index`），否则 -1
 */
function trailingDashRunAt(text, min) {
  let end = text.length
  while (end > 0 && /\s/.test(text.charAt(end - 1))) end -= 1
  let start = end
  while (start > 0 && text.charCodeAt(start - 1) === 45) start -= 1   // 45 = '-'
  return end - start >= min ? start : -1
}

/**
 * `PWSH_ACCESSOR_TAIL` 里那条「下标访问」支（`(?<!\.)\[[^\]]*\]$`）的**线性**判定。
 *
 * ⚠️ 为什么必须手写而不能用正则：`\[[^\]]*\]$` **没有左锚定**，失配时对每个起始位置
 *    各回溯一遍，退化成 O(n²)。与 `trailingDashRunAt` 上面那条注释同一个坑（这是第四处，
 *    另两处是 `globMatch` 与 `flagEmbeddedPath`）。
 *    实测（本机 Node v24.19，取多次最小值）：孤立正则 n=8k/16k/32k/64k →
 *    14.7/57.5/229.6/919.4 ms（倍率 ≈4.0，标准平方）；端到端
 *    `decomposeCommand('"x"' + '['*n + '`\n', 'pwsh')` 同量级 18.9/230.9/926.3 ms
 *    （HEAD 该形态 1.1/1.0/1.2 ms —— HEAD 走 bash 命令替换分支、根本不做词元判据，
 *    故这是第十轮引入的**真回归**）。放大器 `find . -exec … ' ; '` 连接 n 段时 n=1600
 *    （19 KB）→ **31 秒**。判定卡死则 `tools/pre-execute` 不返回、审批弹窗不出现。
 *
 * 等价性（是证明，不是近似）：设 `n = text.length`。该支要求
 *   ① 尾部恰是一个 `]`（`\]$`），且 ② 存在一个 `[`，它**不在** `.` 之后（`(?<!\.)`），
 *      且 `[ … ]` 之间不含 `]`（`[^\]]*`）—— 即该 `[` 必须落在**最后一个** `]` 之后。
 * 故：末字符不是 `]` ⇒ 恒不命中；否则取 `c` = 倒数第二个字符起往前找的最后一个 `]`
 * （= 最后一个满足 `i < n-1` 的 `]`，没有则 -1），再线性扫 `c+1 … n-2` 找第一个
 * 「前一字符不是 `.`」的 `[`。两处扫描都只前进不回头，整体 O(n)。
 *
 * ⚠️ 不要图省事改成 `[^\[\]]*`：那会改变语义 —— `"_.xx][xx.[x]"` / `"x[a0.[.]"` 这类
 *    嵌套形态由 true 变 false（仲裁实测分歧 **0.3996%**）。
 *
 * ⚠️ 上面那两处扫描现由**形态影子**的两格增量维护（`lastOpenIdx` = 最近一个
 *    「前一字符不是 `.`」的 `[`；`closeBeforeLast` = `word[0 .. len-2]` 里最近一个 `]`），
 *    判据即 `bracketAccessorTailOf`：末字符是 `]` 且 `lastOpenIdx > closeBeforeLast`。
 *    这与本函数的线性扫描**同判据**（`c` 就是 `closeBeforeLast`，扫的就是
 *    `c+1 … n-2` 里第一个满足条件的 `[`，取「最近一个」与取「第一个」在「都在 `c` 之后」
 *    的前提下同值）。穷举对拍见测试文件（419330 格分歧 0）。
 */

// ── pwsh 词元「形态影子」：`pwshEscapeBoundaryAt` 的 O(1) 判据 ──────────────────────
//
// ⚠️ **为什么不能直接读 `wordText`**（与 `globMatch` / `flagEmbeddedPath` /
//    `trailingDashRunAt` 同族，这是第五处）：`wordText += s`
//    在 V8 里只建 **rope（O(1)）**，而**任何内容读取**（正则、下标、`slice`）都必须先把
//    rope 扁平化成连续串（**O(n) 拷贝**）。续行守卫在**每个** pwsh 反引号处都要问一次
//    词元形态，于是整段分解退化为 O(n²)。
//    实测靶形态 `-x` + (`` ` `` + `a`)×n（Parameter 词元一路增长）：
//      n = 4k / 8k / 16k / 32k / 64k → **14.5 / 56.7 / 220 / 867 / 3451 ms**
//      （倍率 3.92 / 3.88 / 3.94 / 3.98，**严格平方**），而 HEAD 同形态
//      0.20 / 0.28 / 0.55 / 1.13 / 2.29 ms（倍率 ≈2，线性）—— 放大 **1500 倍**。
//      真实入口 `assessCommand` 同形态 n=16k 为 221 ms；`-Path` / `-Recurse` /
//      `-LiteralPath` 等**任何** Parameter 前缀 + 若干 `` ` ``+字母 即可触发，
//      **不需要畸形输入**。判定卡死 ⇒ `tools/pre-execute` 不返回、审批弹窗不出现。
//
// 修法与 `segEndsWithSpace` / `segLastIsQuote` **同一手法**：把「必须读整串才能回答的问题」
// 换成随追加**增量更新**的 O(1) 标量。影子与正则**同源** —— 每个字符类都由 `PWSH_*`
// 正则本身在**定长探针串**上求值后建成查找表（`CHAR_CLASS`），不另写一份字符类。
//
// ⚠️ 影子必须与 `wordText` **严格同步**：追加只走 `addWord()`、复位只走 `resetWord()`
//    （`decomposeCommand` 内那两个唯一入口）。漏一处即与词元分叉 —— 判据直接错。

/** 字符类位（`CHAR_CLASS` 的取值）。 */
const CC_PARAM_FIRST = 1   // `PWSH_PARAMETER_TOKEN` 的首字符类 `[?A-Za-z_]`
const CC_PARAM_BODY = 2    // `PWSH_PARAMETER_TOKEN` 的词身类
const CC_COLON_BODY = 4    // `PWSH_PARAMETER_COLON_TAIL` 的词身类 `[A-Za-z0-9_/-]`
const CC_WORD = 8          // `\w`（`PWSH_ACCESSOR_TAIL` 用的那个类）
const CC_ALPHA_U = 16      // `[A-Za-z_]`（`PWSH_ACCESSOR_TAIL` 的 `.Name` / `::name` 支）
const CC_SPACE = 32        // `\s`（`pwshEscapeBoundaryAt` 的 `/\s$/` 支）

/**
 * `0..127` 的字符类查找表 —— **由上面那些正则逐码生成**，故字符类仍只有一份定义
 * （探针串是定长的，每个码一次，模块加载时算完）。
 *
 * 为什么必须是查找表而不是每次调 `test`：本表在**每个追加字符**上被读（见 `pushWordShape`），
 * 而正则调用有固定开销 —— 逐字符调 `test` 会把判定热路径拖慢一个量级。
 *
 * ⚠️ `\w` 与 `[A-Za-z_]` 这两格也**由 `PWSH_ACCESSOR_TAIL` 本身**探出来（不手抄类）。
 *    三支里只有第一支 `(?<!\.)\.[A-Za-z_]\w*$` 能被这两种探针命中，故探针串都刻意
 *    不含 `:`（第三支要 `::`）、末字符都不是 `.`（第二支要 `(?<!\.)\.$`）：
 *      · `'.' + ch + 'a'` ⇒ 命中 ⟺ `ch ∈ [A-Za-z_]`（`.` 只在串首 ⇒ `(?<!\.)` 成立；
 *        `ch` 若不在该类则第一支在第二个字符处即失配）；
 *      · `'.a' + ch + 'a'` ⇒ 命中 ⟺ `ch ∈ \w`，**唯一例外是 `ch === '.'`** ——
 *        那时探针串是 `.a.a`，第二个 `.` 自己就能充当第一支的那个 `.`（它前面是 `a`、
 *        满足 `(?<!\.)`）⇒ 恒命中。故 `.` 必须**显式排除**（它是唯一一个既能当
 *        「分支自己的 `.`」、又能出现在尾部的字符）。
 *    这两种探针的逐码结果已与 `\w` / `[A-Za-z_]` 对拍一致（各 128 码，0 分歧）。
 *
 * ⚠️ `\s` **不是**纯 ASCII（还有 `\u00a0` `\u1680` `\u2000-\u200a` `\u2028` `\u2029`
 *    `\u202f` `\u205f` `\u3000` `\ufeff`），故它单独走 `NON_ASCII_SPACE`，且那一份同样是
 *    **由 `/\s/` 正则本身扫出来**的（不手抄字符表 —— 抄一份就是同一概念写两遍）。
 */
const CHAR_CLASS = (() => {
  const t = new Uint8Array(128)
  for (let c = 0; c < 128; c += 1) {
    const ch = String.fromCharCode(c)
    let bits = 0
    if (PWSH_PARAMETER_TOKEN.test('-' + ch)) bits |= CC_PARAM_FIRST
    if (PWSH_PARAMETER_TOKEN.test('-a' + ch)) bits |= CC_PARAM_BODY
    if (PWSH_PARAMETER_COLON_TAIL.test('-a' + ch + ':')) bits |= CC_COLON_BODY
    if (ch !== '.' && PWSH_ACCESSOR_TAIL.test('.a' + ch + 'a')) bits |= CC_WORD
    if (PWSH_ACCESSOR_TAIL.test('.' + ch + 'a')) bits |= CC_ALPHA_U
    if (/\s/.test(ch)) bits |= CC_SPACE
    t[c] = bits
  }
  return t
})()

/**
 * `>= 128` 里属于 `\s` 的码元 —— 由 `/\s/` 扫整个 BMP 得到（不手抄字符表，见上）。
 * 只在「词元末字符是非 ASCII」时被查一次（每个追加字符至多一次）。
 */
const NON_ASCII_SPACE = (() => {
  const s = new Set()
  const re = /\s/g
  const CHUNK = 4096
  for (let base = 128; base < 0x10000; base += CHUNK) {
    const n = Math.min(CHUNK, 0x10000 - base)
    let chunk = ''
    for (let i = 0; i < n; i += 1) chunk += String.fromCharCode(base + i)
    re.lastIndex = 0
    let m = re.exec(chunk)
    while (m !== null) {
      s.add(base + m.index)
      re.lastIndex = m.index + 1
      m = re.exec(chunk)
    }
  }
  return s
})()

/** 单个 UTF-16 码元是否属于某个字符类。 */
const charHas = (code, bit) => code >= 0 && (code < 128
  ? (CHAR_CLASS[code] & bit) !== 0
  : bit === CC_SPACE && NON_ASCII_SPACE.has(code))

/**
 * 空词元形态影子的**唯一一份**默认值表（字段说明见上；`-1` 一律表示「不存在」）。
 *
 * ⚠️ 构造侧（`newWordShape`）与复位侧（`resetWordShape`）**必须**共用这一张表：
 *    两处各抄一份时，本影子以后**加字段**必然漏掉其中一处 —— 漏构造侧是 `undefined`
 *    参与比较，漏复位侧更糟：**上一个词元的残值跨词元泄漏到下一个词元**（复位漏一格
 *    ⇒ 新词元带着旧词元的 `lastOpenIdx` / `cLast` 等），而 `pwshEscapeBoundaryAt`
 *    正是逐格读这些字段判「反引号前面那个词元完结到什么级别」⇒ 续行切分结论直接错。
 *    这与 `paramTokenWithNext` 那处的处置**同源**（那里用 `Object.assign(t, s)` 整体覆盖，
 *    就是为了加字段时自动跟上）；此处同样整体覆盖，不再逐字段抄。
 *    实测：漏掉复位侧任一格时，测试套件**全部 exit 0 全绿**（无断言守护），
 *    而漏 `lastOpenIdx` 一格即让 12 格判定由 `deny` 变 `allow`。
 */
const EMPTY_WORD_SHAPE = {
  len: 0,
  c0: -1, c1: -1, cLast: -1, cSecondLast: -1,
  bodyOk: true, colonOk: true,
  runW: 0, runFirst: -1, preRun: -1, prePreRun: -1,
  dblColonPrev: -1,
  lastOpenIdx: -1, lastCloseAny: -1, closeBeforeLast: -1,
}

/** 建一个空的词元形态影子（字段说明见上；`-1` 一律表示「不存在」）。 */
function newWordShape () {
  return Object.assign({}, EMPTY_WORD_SHAPE)
}

/** 复位（`wordText = ''` 的同步动作）。 */
function resetWordShape (s) {
  Object.assign(s, EMPTY_WORD_SHAPE)
}

/**
 * 追加**一个 UTF-16 码元**（`addWord` 逐码调用）。
 *
 * 每条更新都由 `pwshEscapeBoundaryAt` 那几个判据的等价性反推而来（穷举对拍见测试文件）：
 *   · `bodyOk` / `colonOk` —— 新进入「中间段 `2 .. len-2`」的下标是 `L-1`（旧末字符），
 *     它存在当且仅当 `L-1 >= 2`（即 `L >= 3`），故只在 `L >= 3` 时收窄；
 *   · `runW` / `runFirst` / `preRun` / `prePreRun` —— 末尾 `\w` 连续段的长度、段首字符、
 *     段前两字符（`PWSH_ACCESSOR_TAIL` 的三支只看这四格）；
 *   · `dblColonPrev` —— 追加出 `::` 的那一刻记下**它前面**那个字符（`::name` 支的
 *     `(?<!\.)` 要看它）；之后段内继续追加不影响它（`::` 的位置已固定）；
 *   · `lastOpenIdx` —— 最近一个「前一字符不是 `.`」的 `[`（即 `(?<!\.)\[`；`L === 0`
 *     时 `oldLast` 为 `-1`，自动满足「前面没有字符」）；
 *   · `lastCloseAny` / `closeBeforeLast` —— 全词 / `word[0 .. len-2]` 里最近一个 `]`。
 *     `closeBeforeLast` 的新值恰是**追加前**的 `lastCloseAny`（新词的 `0 .. len-2`
 *     就是旧词全体）⇒ 这两条赋值**有先后顺序要求**，不得调换。
 */
function pushWordShape (s, code) {
  const L = s.len
  const oldLast = s.cLast
  const oldSecondLast = s.cSecondLast
  if (L === 0) s.c0 = code
  else if (L === 1) s.c1 = code
  s.cSecondLast = oldLast
  s.cLast = code
  if (L >= 3) {
    s.bodyOk = s.bodyOk && charHas(oldLast, CC_PARAM_BODY)
    s.colonOk = s.colonOk && charHas(oldLast, CC_COLON_BODY)
  }
  if (charHas(code, CC_WORD)) {
    if (s.runW === 0) { s.runFirst = code; s.preRun = oldLast; s.prePreRun = oldSecondLast }
    s.runW += 1
  } else {
    s.runW = 0
    s.runFirst = -1
    s.preRun = -1
    s.prePreRun = -1
  }
  if (code === 58 && oldLast === 58) s.dblColonPrev = oldSecondLast   // 58 = ':'
  if (code === 91 && oldLast !== 46) s.lastOpenIdx = L                // 91 = '['，46 = '.'
  s.closeBeforeLast = s.lastCloseAny
  if (code === 93) s.lastCloseAny = L                                 // 93 = ']'
  s.len = L + 1
}

/** `PWSH_PARAMETER_TOKEN.test(word)` —— 由影子 O(1) 回答。 */
function paramTokenOf (s) {
  if (s.len < 2 || s.c0 !== 45 || !charHas(s.c1, CC_PARAM_FIRST)) return false   // 45 = '-'
  return s.len < 3 || (s.bodyOk && charHas(s.cLast, CC_PARAM_BODY))
}

/** `PWSH_PARAMETER_COLON_TAIL.test(word)`。 */
function colonTailOf (s) {
  return s.len >= 3 && s.c0 === 45 && charHas(s.c1, CC_ALPHA_U) && s.colonOk && s.cLast === 58
}

/**
 * `PWSH_ACCESSOR_TAIL.test(word)`（三支逐条对应，见该常量的说明）。
 *
 * `/(?<!\.)(?:\.[A-Za-z_]\w*|(?<!\.)\.|::[A-Za-z_]\w*)$/` 的三支都**只能**落在末尾
 * `\w` 连续段上（`\w*` 必须一路吃到 `$`），故段首位置唯一：`L - runW`。于是
 * 「段前那个字符」就是 `preRun`、再前一个是 `prePreRun` —— 两支各自只差这一点。
 */
function accessorTailOf (s) {
  if (s.runW >= 1 && charHas(s.runFirst, CC_ALPHA_U)) {
    // `\.[A-Za-z_]\w*$`：`.` 紧贴段首，且它前面不是 `.`
    if (s.preRun === 46 && s.prePreRun !== 46) return true
    // `::[A-Za-z_]\w*$`：`::` 紧贴段首，且 `::` 前面不是 `.`
    if (s.preRun === 58 && s.prePreRun === 58 && s.dblColonPrev !== 46) return true
  }
  // `(?<!\.)\.$`
  return s.cLast === 46 && s.cSecondLast !== 46
}

/** `bracketAccessorTailAt(word)`（线性版，见该函数）。 */
function bracketAccessorTailOf (s) {
  return s.cLast === 93 && s.lastOpenIdx > s.closeBeforeLast   // 93 = ']'
}

/**
 * `word.charCodeAt(word.length - 1) === 58 && PWSH_PARAMETER_TOKEN.test(word.slice(0, -1))`
 * —— 即「去掉末字符后仍是一个整词 Parameter」。
 *
 * 去尾后长度是 `len-1`，其词身段是 `2 .. len-2`，**正好**是 `bodyOk` 覆盖的那一段
 * （这正是影子里存 `bodyOk` 而不是「含末字符」那一段的原因）。
 */
function paramColonTailOf (s) {
  if (s.len < 3 || s.cLast !== 58 || s.c0 !== 45 || !charHas(s.c1, CC_PARAM_FIRST)) return false
  return s.bodyOk
}

/** `paramTokenWithNext` 的暂存影子（模块级复用，免每次分配）。 */
const SCRATCH_SHAPE = newWordShape()

/**
 * `PWSH_PARAMETER_TOKEN.test(word + next)` —— `readPwshEscape` 的 `'segment'` 支用它。
 *
 * ⚠️ **不得直接写 `PWSH_PARAMETER_TOKEN.test(word + next)`**：`word` 是 `wordText`，读它
 *    要先把 rope 扁平化（O(n)），而本判据在**每个**落在 Parameter 词元内的反引号处求值，
 *    词元又随 `` ` ``+字母 一路增长 ⇒ Σ O(i) = **O(n²)**（缺陷 2 的第二处，见影子那段说明）。
 *    实测只把本行改成 O(1) 后，`-x` + (`` ` ``+`a`)×n 由 220 ms 降到 112 ms（n=16k，
 *    另一半平方在 `pwshEscapeBoundaryAt`），两处都改才回到线性。
 *
 * 等价性不是近似：影子与 `PWSH_PARAMETER_TOKEN` **逐格等价**（穷举 419330 格分歧 0），
 * 故「把 `next` 追加到影子上再问」与「把 `next` 拼到 `word` 上再跑正则」恒同值 ——
 * 且这里**不依赖**「调用方已保证 `word` 本身命中」这条跨函数不变量（那会让本判据在
 * `pwshEscapeBoundaryAt` 改动时静默漂移）。复制字段数是固定的 ⇒ O(1)。
 *
 * @param {object} s 当前词元的形态影子
 * @param {number} code 紧跟反引号那个字符的码元
 * @returns {boolean} `word + next` 是否仍是一个整词 Parameter
 */
function paramTokenWithNext (s, code) {
  const t = SCRATCH_SHAPE
  // ⚠️ 用 `Object.assign` 而不是逐字段抄：本影子以后**加字段**时，逐字段抄会静默漏掉
  //    新字段（读到上一轮的残值）⇒ 判据漂移。整体覆盖则新字段自动跟上。
  Object.assign(t, s)
  pushWordShape(t, code)
  return paramTokenOf(t)
}

/**
 * 反引号（pwsh 转义符）**前面**那个词元完结到什么级别 —— 续行判据的**唯一实现**。
 *
 * 三态（完整实测论证见主循环里那段「已完结的完整词元 ⇒ 必须切 / 首字符是普通字符 ⇒ 必须粘住」）：
 *   · `'segment'` —— 整词 Parameter（`-NoNewline` / `-Recurse` / `-Path$p` …）：`[Parser]` 报
 *     **2 条 PipelineAst**（第二行是**新命令**）⇒ 调用方必须 `flushSegment()`；
 *   · `'word'`    —— 其余**已完结**词元（`-Confirm:` / `$x.Name` / `"abc"` / `@(x)` / 孤立 `)` `}`）：
 *     `LineContinuation`（**词元**边界、同一条语句）⇒ `flushWord()`；
 *     也包含**没有词元在写**（`word === ''`）这一格 —— 反引号落在空白 / 行首 / 操作符之后，
 *     同样是词元边界（`flushWord()` 在那种状态下是空操作，只顺带复位 `tokenTyped`，
 *     而那正是既有设计要求的复位点）。归到本态而不是 `'none'` 是**必需的**：CRLF 支要
 *     按它区分「词元内」与「词元边界」（见下）。
 *   · `'none'`    —— 词元**还在写**（裸词 / 简单变量 / `abc]` / `a.b` / `x$y.y`）：反引号是
 *     **字面**字符，两行粘住。
 *
 * ⚠️ **两个消费方共用这一份判据**：
 *   ① 主循环的续行守卫 —— 据此决定「切段 / 切词 / 什么都不切」（用 `level`）；
 *   ② `readPwshEscape` 的 **CRLF 支** —— 据此决定 `` ` ``+`\r\n` 是**整体续行**还是
 *      「字面 CR + 真换行符」（用 `open`）。
 *   两个字段**同源同判据**（同一套正则），只是回答的问题不同：`level` 问「词元完结到什么
 *   级别」，`open` 问「反引号是否落在**未完结**词元内」（PS 只在前者成立时把 `` ` ``+`\r`
 *   当转义、把 `\n` 留给换行符）。既有三段式对 `closedLoose` 两种形态给 `'none'`（段级
 *   行为是既有的，不得改动），而它们其实是已完结词元 ⇒ `open` 必须为 false。
 * （为一次判定在每次迭代里新建闭包不值得），故不能靠闭包取用。
 *
 * ⚠️ 词元形态**不读 `wordText`**，只读调用方同步维护的**形态影子** `shape`（见
 *    `newWordShape` 那段说明）：直接对 `wordText` 跑正则要先把 rope 扁平化（O(n)），
 *    而本函数在**每个** pwsh 反引号处被调用 ⇒ O(n²)。影子与那几个正则**逐格等价**
 *    （穷举 419330 格分歧 0，见测试文件），且每个字符类都由正则本身生成，不是另写一份。
 *
 * @param {object} shape 当前词元的形态影子（`wordShape`，与 `wordText` 严格同步）
 * @param {boolean} typed 当前词元是否以 typed 构造开头（`tokenTyped`）
 * @param {boolean} lastIsQuote 段文本末字符是不是引号（`segLastIsQuote`）
 * @param {number} groupClose 最近一个分组块收尾符的下标（`lastGroupClose`）
 * @param {number} at 反引号在 `input` 里的下标
 * @returns {{level: 'segment'|'word'|'none', open: boolean}} 完结级别 + 反引号是否在未完结词元内
 */
function pwshEscapeBoundaryAt(shape, typed, lastIsQuote, groupClose, at) {
  if (shape.len === 0) return { level: 'word', open: false }   // 没有词元在写 ⇒ 词元边界（见该态说明）
  if (paramTokenOf(shape)) return { level: 'segment', open: true }
  const closed = colonTailOf(shape)
    // 下标访问支走影子的两格（`lastOpenIdx` / `closeBeforeLast`，见 `bracketAccessorTailOf`）；
    // 引号支走 O(1) 标记（见 `segLastIsQuote` / `PWSH_QUOTED_TAIL`）—— 两处都不得改回
    // 直接对 `word` / `segText` 跑正则（前者 O(n²)，后者触发 rope 扁平化）。
    // ⚠️ 现在前两支也走影子（`accessorTailOf` / `bracketAccessorTailOf`），理由同上。
    || (typed && (accessorTailOf(shape) || bracketAccessorTailOf(shape) || lastIsQuote))
    || groupClose === at - 1
  if (closed) return { level: 'word', open: false }
  // 尾部挂着**转义空白**（`$x.Name ` / `-Confirm: `：反引号转义出的那个空白把词元终结了）
  // 或**反引号已并入参数名的 Parameter 冒号形**（`-x`:`：PS 在冒号处终结该词元，实测
  // `Parameter[-x`:]` + `LineContinuation`）：两者 PS 都判**词元边界**。
  // ⚠️ 既有三段式对它们给 `'none'` —— 那是**段级**既有行为，本次不动（改它会改 LF/CR 语料）；
  //    但 `open` 必须为 false，否则 CRLF 支会把 `` ` ``+`\r` 当转义、把 `\n` 留成真换行，
  //    凭空多切一段（实测新引入 18 格反向误差）。
  const closedLoose = charHas(shape.cLast, CC_SPACE) || paramColonTailOf(shape)
  return { level: 'none', open: !closedLoose }
}

/**
 * 「这个词元是不是**引号包裹的字符串字面量**」—— label 提取的入口守卫之一。
 *
 * ── 判据：含空白 + 含路径分隔符 + 不以路径形态开头 + 剥路径后 basename 仍非命令名，
 *    适用范围两格（满足其一）：「连字符串 + 空白开头 + 连字符串收尾」或「装饰性开栏 + 装饰性收栏」。
 *   · 适用范围①（`/^-+\s/` 且连字符串收尾）只拦分隔注释串（`"--- 编码/换行校验 ---"`、
 *     `"-- 步骤 1/3 --"`），其余含空格的相对路径一律放行。少了收栏那半会把「目录名本身
 *     是连字符串 + 空格」的真实命令（`"--- x/My App"`）判成引号串；少了开栏那半则误伤
 *     `"-x/rm ---"` 这类真实命令。
 *   · 适用范围②（装饰性开栏 + 装饰性收栏）管①漏掉的子族：连字符串后不跟空白、空白落在
 *     basename 里（`---编码/换行校验 ---`）。
 *   · 去掉「含空白」—— `a/b/c`（相对路径命令）被误伤；
 *   · 去掉「含分隔符」—— `"reg delete" HKLM\X /f` 的两词命令名被误伤；
 *   · 去掉「不以路径形态开头」—— `"C:/Program Files/My Tool.exe"` 被误伤；
 *   · 去掉「剥路径后仍非命令名」—— `"my tools/rm.exe" -rf /data` 这类含空格的相对路径
 *     命令会被判成字符串字面量 → label 变空 → 段级 `unparsable` → 破坏性子设置与全部
 *     例外匹配双双跳过 → 落大分类。故最后一格按**剥路径后的 basename** 判。
 *
 * 命中形态：`"--- 编码/换行校验 ---"` —— 词法器剥掉引号后留下含空格与 `/` 的整串，
 * `commandNameOf` 取最后一个 `/` 之后得到 `换行校验 ---`，弹窗据此给出「允许此项」按钮，
 * 而写进配置的例外**永不命中**。
 *
 * ⚠️ **坏字符判据只落在剥路径之后的 basename 上，不落在原词元上**：`$x/rm -rf /etc`、
 * `$env:TEMP/rm.exe`、`C:/my=dir/rm.exe` 的 `$` 与 `=` 都在路径前缀里，是货真价实的命令；
 * `segmentLabelFrom` 里另有一句同口径的 `BAD_LABEL_CHARS.test(head)`。
 *
 * 残余（有意保留）：两格之外一律放行，共四类 —— ①不含路径分隔符的引号串（与真命令名在
 * 词元粒度不可区分）；②含分隔符但不以 `-` 开头（与真实含空格相对路径命令逐字同形）；
 * ③含分隔符、以 `-` 开头但 basename 恰是已知命令名（有意的取舍）；④空白落在目录段
 * （与②同为固有的不可区分性）。要堵①②必须让词法器交回引号状态（`words` 是 `string[]`，
 * 改结构会波及全部消费方），代价与收益不成比例，且危害只是多一个候选按钮，不构成授权面问题。
 *
 * @param {string} text 词元**原文**（未经 `commandNameOf` 剥离）
 * @returns {boolean} 为真表示该词元是引号包裹的字符串字面量
 */
function labelTokenIsQuotedLiteral(text) {
  const t = String(text == null ? '' : text)
  if (!t) return false
  if (!/\s/.test(t) || !/[\\/]/.test(t)) return false
  // 显式路径形态早退（`"C:/Program Files/rm.exe"`、`"./my tools/rm.exe"`）：
  // 它们**是**命令，剥路径后 basename 含空白也不得拒。
  if (looksLikeExplicitPath(t)) return false
  // 其余按**剥路径后的 basename**判「是否仍是合法命令名」：`x/my tools` 剥完是
  // `my tools`（含空白、且不是已知命令名）→ 判真（引号串）；而 `my tools/rm.exe`
  // 这类**相对路径命令**剥完是 `rm.exe` → 合法命令名 → 判假（不是字符串字面量），守卫放行。

  //
  // ⚠️ 「basename 含空白」**单独不足以判引号串**：`DESTRUCTIVE_LABELS` 里
  //     有**两词命令名**（`reg delete`），路由器命令的 label 本来就拼成两词，含空白是
  //     **正常形态**而不是「引号串」的特征。于是「含空格的相对路径 + 两词命令名」被误判：
  //       `"a b/reg delete" HKLM\X /f`   → head = `reg delete` → 误判引号串 → label 变空
  //       `-x/reg delete HKLM\X /f`      → 同上（剥路径后 basename 就是 `reg delete`）
  //       `"-x/reg delete" HKLM\X /f`    → 同上
  //     ⇒ 段级 `unparsable` ⇒ labels 为空 ⇒ `destructive=false` ⇒ 破坏性子设置与全部
  //     例外匹配双双跳过 ⇒ 落大分类。实测（大分类 allow + reg 档 deny）：
  //     三格 bash / pwsh **HEAD=deny → 只加引号守卫时 allow**（共 8 格，见对拍）。
  //     该形态真实可执行：bash 实测 `"a b/reg delete" HKLM/X /f` 真的执行了
  //     `a b/reg delete`（无害替代目标，rc=0）。
  //     故「含空白」这一格必须再排除**已知的多词命令名**（判据直接问 `DESTRUCTIVE_LABELS`，
  //     不另写第二份两词表 —— 那正是本文件反复警告的漂移源）。
  //     ⚠️ 作者注释声明的残余范围（「**不含**路径分隔符的引号串」）并未覆盖此形态：
  //     它含分隔符，走的是本行而不是上面那条早退。
  // ⚠️ **守卫只对「trim 后以连字符串 + 空白开头」（`/^-+\s/`）的词元成立**：
  // 该格此前对所有含空白 + 含分隔符的词元生效，于是「含空格的相对路径 + basename 既非
  // 破坏性命令名、也非两词命令名」被整族误判成字符串字面量（`"Program Files/My Tool.exe"`
  // → head `my tool` → 判真 → label 变空 ⇒ 段级 `unparsable` ⇒ 落大分类），
  // 两个方向都会失明：allow 例外反复弹窗、显式 deny 例外被静默绕过。
  // 收窄到 `/^-+\s/` 的依据：真实目录名紧跟连字符串的必是字母/数字（`-x`、`-rf`、`-x y`），
  // 而分隔线的连字符串后面才是空白。
  // ⚠️ 判据用 `t.trim()`：词法器**保留**引号内的首尾空白（实测 `"  --- 编码/换行校验 ---"`
  //     → 词元 `  --- 编码/换行校验 ---`），不 trim 时前导空白让 `/^-+\s/` 失配、
  //     该形态 label 变 `换行校验 ---`（假候选复活，实测）。
  // 适用范围**两格**（满足其一即进入判据）：
  //   ① 「**连字符串 + 空白**开头」**且**「**连字符串收尾**」（`/^-+\s/` + 线性收栏扫描）
  //      —— `--- 标题 ---` 这类分隔注释串。
  //      ⚠️ 收栏那一格是**本轮补的**：缺它则「目录名本身就是连字符串 + 空格」的真实命令
  //      （`"--- x/My App"`、`"- x/My App"`、`"-- x/My App"`、`"---- x/My App"`、
  //      `"--- x/My Tool.exe"`、`"--- tools/My App"`）被整族判成引号串 —— 它们
  //      `tailAt < 0`（basename 不以连字符串收尾）、`fenced === false`，**只**被①拦下。
  //      即①此前比②**宽半格**，本轮是与②**对齐**（同一语义），不是新增判据。
  //   ② 「**装饰性开栏 + 装饰性收栏**」—— 开栏 = 连字符串开头、后面不紧跟路径分隔符、
  //      且**不是**「`-` + 字母/数字」的真实目录名（`-x`、`-rf`、`-x y`）；收栏 =
  //      **剥路径后的 basename** 以连字符串收尾，**且剥掉收栏后剩下的不是命令名**
  //      （`…换行校验 ---`、`…my check ---` 剥完是 `换行校验` / `my check`，都不是命令名；
  //      而 `--x/rm ---` 剥完是 `rm`，是 —— 故它不算收栏，见下）。
  //
  // ⚠️ ② 是必需的：① 只认「连字符串后紧跟空白」，而这一族的空白落在 basename 里、
  //     连字符串后面紧跟的是字母或汉字（`---编码/换行校验 ---`），于是① 失配、守卫整族放行
  //     ⇒ label 非空 ⇒ 弹窗产出假候选（例外永不命中，按钮消失后命令照旧弹窗）。
  //     真正的区分点是**收栏**（basename 自身以连字符串收尾）。
  //
  // ⚠️ 开栏那一格**不能省**（只按「basename 以连字符串收尾」判会 fail-open）：`"-x/rm ---"`
  //     的 basename 同样以连字符串收尾，而它剥路径后是**真实可执行文件** —— 实测（无害
  //     替代目标，本机 pwsh，临时目录内）`-x/rm ---.cmd` 真的跑起来了（rc=0，PATHEXT 解析），
  //     即它与 A 族 `"-x/My Tool.exe"` 同族、只是 basename 尾巴多几个连字符。少了开栏条件，
  //     它会被判成引号串 ⇒ label 变空 ⇒ 段级 `unparsable` ⇒ `destructive=false` ⇒
  //     落大分类，用户显式写的 `rm *`=deny 例外随之失明（实测：大分类 allow + `rm *`=deny
  //     时 HEAD/PRE 均为 **deny** → 少了开栏条件变 **allow**，fail-open）。
  //     故开栏判据取「连字符串开头、后面不紧跟路径分隔符、且不是『`-` + 字母/数字』的
  //     真实目录名」：`-x`、`-rf`、`-x y` 这些真实目录名紧跟的是字母/数字，被排除；
  //     `---编码`、`--note`、`-编码` 才落入。
  //     ⚠️ 这一格**只对 `dash === 1` 成立**：`dash > 1` 时 `next` 必然是
  //     `-` 而不是目录名首字符，信息量为零。此前写作 `dash > 1 || !/[A-Za-z0-9]/.test(next)`，
  //     即 `dash > 1` 时**整格恒真**、把这一格短路掉 —— 于是「2+ 连字符开头的真实目录 +
  //     收栏 basename」（`"--x/rm ---"`、`"--tools/Remove-Item ---"`、`"--bin/del ---"`、
  //     `"--x y/rm ---"`、`"--9/rm ---"`）整族被判成引号串 ⇒ label 变空 ⇒ 段级
  //     `unparsable` ⇒ `destructive=false` ⇒ 落大分类，用户显式写的 `rm *`=deny 例外
  //     随之失明。实测（无害替代目标，TEMP 内，PATHEXT 解析，rc=0）：本机 pwsh
  //     `& "--x/rm ---"`、`& "--x y/rm ---"`、`& "--x/tool ---"` 都真的跑起来了
  //     （`--x\rm ---.cmd` 等），故这一族与 `"-x/rm ---"` 同族、是真命令。
  //     三态对拍（大分类 allow + `rm *`=deny，bash/pwsh 各一格）：
  //       HEAD=deny → PRE=allow → 修复后=deny（label 由 `""` 回到 `rm ---`）。
  //     故本轮把 `dash > 1` 那半段的判据换成**收栏剥除后的残名**（见下），而不是恒真。
  //     另排除「连字符串后**紧跟路径分隔符**」（`-/rm ---`、`--/rm ---`）：那说明连字符串
  //     本身是**目录名**（目录就叫 `-` 或 `--`），不是装饰性开栏 —— 这两格 HEAD/PRE
  //     都给得出 `rm ---`，不收窄会白白多丢 20 格保护（实测）。
  //     ⚠️ 收栏那一格**也必须带「剥掉收栏后不是命令名」**：`"--x/rm ---"` 的 basename
  //     同样以连字符串收尾，但它剥完是 `rm` —— 真实命令名。少了这格，上面那族会**再次**
  //     被判成引号串（实测：只放开开栏而不带这格，`"--x/rm ---"` label 仍为空）。
  //     判据取「剥掉收栏后**仍是可打印 ASCII 的单个词**」即视为命令名（`rm`、`tool`、
  //     `reg delete` 都命中；`换行校验`、`my check`、`编码 check` 因含非 ASCII 或空白而不命中）。
  //     不另写命令名白名单：`DESTRUCTIVE_LABELS` 只覆盖破坏性命令，非破坏性的真实命令
  //     （`--x/tool ---`、`--x/git ---`）会漏；「是不是命令名」在这里的正解是**词形**
  //     （无空白、无不可打印字符），不是「在不在某张表里」。
  // 为什么不是「以 `-` 开头」：后者会把「`-` 开头的目录」整族误伤（见上）。
  //
  // ── ⚠️ 残余范围是两类（含空格的纯 ASCII 残名同样中招）──
  // 剥掉收栏后的残名含空白或含非 ASCII，都过不了「是命令名」那一格，于是被判成
  // 装饰性收栏 ⇒ 引号串 ⇒ label 变空（`"--x/my tool ---"`、`"--x/换行校验 ---"`），
  // 用户为该命令写的 deny 例外随之失明。
  // 无任何词法判据能分开两族：残余族与装饰串族在词元粒度上逐字同形。故判定为
  // 「不值得继续修补」，不是 TO-DO；要真正分开只能引入文件系统存在性判断，而本文件是纯函数。
  //    ⚠️ 本条评述只针对 **`--` 开头目录**那一残余族（`--x/my tool ---`，`tailAt >= 0`、
  //    走 `fenced` / `bareIsCommand`）。「**目录名本身就是连字符串 + 空格**」那一族
  //    （`--- x/My App`）与它**路径分离**：那族 `tailAt < 0`、`fenced === false`，**只**被
  //    适用范围①拦下，故由①的收栏格修好（见下），不在「不值得继续修补」之列。
  //    触发面**四重叠加**：`--` 开头目录 + 含空格或非 ASCII 名 + basename 以 `---` 收尾
  //    + 用户为该命令写了 deny 例外。
  const s = t.trim()
  const head = commandNameOf(t)
  let dash = 0
  while (dash < s.length && s.charCodeAt(dash) === 45) dash += 1   // 45 = '-'
  const next = s.charAt(dash)
  // 「真实目录名开栏」：`dash === 1` 且紧跟 ASCII 字母/数字（`-x`、`-rf`、`-x y`）。
  // ⚠️ `dash === 1` 这一半不能省：`dash > 1` 时整格恒真会短路这一格，于是「2+ 连字符开头的
  //    真实目录 + 收栏 basename」（`"--x/rm ---"` 等）整族被判成引号串（label 变空 ⇒ fail-open）。
  // ⚠️ 反过来也不能只留 `!/[A-Za-z0-9]/.test(next)`：`--note`、`--encoding` 这些装饰性开栏
  //    首字符同样是字母，一刀切会让它们漏回假候选。故 `dash > 1` 时不按首字符判，
  //    改由下面的收栏 + 残名判（那里才有区分力）。
  const plainDirLead = dash === 1 && /[A-Za-z0-9]/.test(next)
  const decorLead = dash > 0 && next !== '/' && next !== '\\' && !plainDirLead
  // 装饰性收栏：basename 以连字符串收尾，**且剥掉收栏后剩下的不是命令名**。
  //   `"--x/rm ---"`    剥完 `rm`          → 是命令名 ⇒ **不是**装饰性收栏（真命令，放行）
  //   `"--x/reg delete ---"` 剥完 `reg delete` → 两词命令名 ⇒ 同上
  //   `"---编码/换行校验 ---"` 剥完 `换行校验`   → 含非 ASCII ⇒ 装饰性收栏（判引号串）
  //   `"---encoding/my check ---"` 剥完 `my check` → 含空白 ⇒ 装饰性收栏
  // 「是命令名」= 单个可打印 ASCII 词（无空白、无控制/非 ASCII 字符）**或**在
  // `DESTRUCTIVE_LABELS` 里。为什么必须带上后者：那张表里有**两词命令名**（`reg delete`），
  // 它含空白、过不了「单个词」那格，而它确实是命令名（该表是全文件唯一的命令名权威来源，
  // 不另写第二份两词表 —— 那正是本文件反复警告的漂移源）。
  // 为什么不反过来写成「在 DESTRUCTIVE_LABELS 里才算命令名」：那张表只收**破坏性**命令，
  // `--x/tool ---`、`--x/git ---` 这些非破坏性的真实命令会漏判成引号串（实测，label 变空
  // ⇒ 同一条 fail-open 链）。「是不是命令名」在这里的正解是**词形**，不是「在不在某张表里」。
  // ⚠️ 这里与下面的①都必须走 `trailingDashRunAt`（**线性反向扫描**），不要写回正则：
  //    未锚定的 `/-{2,}\s*$/` 失配时是 O(n²)（实测数字见该函数的注释），而 `head` 是
  //    词元原文、长度无上界、内容由 AI 生成的命令决定。
  //    ⚠️ 也**不要**把它「锚定」成 `/^-{2,}\s*$/` 了事：`tail.index` 参与 `bare` 的计算，
  //    不是可以随手锚定的中间变量 —— 锚定版让 `--note/my check ---` 这类词元的
  //    `bare` 由 `''` 变回 `my check ---`（`fenced` 随之翻转），实测 85068 形态的对拍中
  //    740 格全部方向为「拦→放行」，并直接弄红测试套件。
  const tailAt = trailingDashRunAt(head, 2)
  const bare = tailAt >= 0 ? head.slice(0, tailAt).trim() : ''
  const bareIsCommand = /^[\x21-\x7E]+$/.test(bare) || DESTRUCTIVE_LABELS.has(bare)
  const fenced = decorLead && tailAt >= 0 && !bareIsCommand
  // 适用范围两格（满足其一即进入判据）：
  //   ① 「**连字符串 + 空白**开头」**且**「**连字符串收尾**」**且**「**残名不是
  //      破坏性命令名**」—— 分隔注释串（`--- 标题 ---`）。
  //      ⚠️ 收栏那一格是必需的：此前①只要求「连字符串 + 空白开头」，比②宽半格，
  //      于是「目录名本身就是连字符串 + 空格」的真实命令被整族判成引号串
  //      （`"--- x/My App"` 等）：它们 `tailAt < 0`、`fenced === false`，只被①拦下。
  //      故①与②是同一语义（装饰性开栏 + 装饰性收栏），这里是与②对齐，不是新增一格。
  //      ⚠️ 第三格（残名不是破坏性命令名）同样必需：只补收栏那一格是「只补了一半」——
  //      「目录名＝连字符串+空格 + basename 以连字符串收尾 + 残名 ∈ `DESTRUCTIVE_LABELS`」
  //      这一子族（`"--- x/rm ---"` 等）仍被①判成引号串 ⇒ label 变空 ⇒ 破坏性判定与用户例外双双失效。
  //      ⚠️ **不要**改用 `!bareIsCommand`（候选A）：那会复活装饰串假候选 —— `"-- 步骤 1/3 --"`、
  //      `"-- 1/3 --"`、`"--- a/b ---"`、`"-- x/3 --"` 等**13 格**装饰串的残名 `3`/`b`/`1`
  //      同样是单 ASCII 词，`bareIsCommand` 为真、被放行（实测候选A 13 格 / 候选B 0 格）。
  //      ⚠️ 已知残余（**不要试图一并修**）：残名 ∉ `DESTRUCTIVE_LABELS` 且为单 ASCII 词的
  //      子族（`"--- x/git ---"`、`"--- x/tool ---"`、`"--- x/3 ---"`）与装饰串残名**逐字同形**，
  //      词法上不可区分，已判定并入已忽略族，保持现状不动。
  //      ⚠️ 相邻子族「单连字符收栏」（`"--- x/rm -"`）：收栏判据用 min=1，而 `bare` 取自
  //      `trailingDashRunAt(head, 2)`（min=2）—— 单连字符收栏时后者返回 -1 ⇒ `bare === ''`
  //      ⇒ 第三个合取项恒真（等于没补）。故这里另算一个 min=1 的残名（`bareAt1`）与①对齐。
  //      ⚠️ 成因②（basename 整个是连字符串，如 `"--- x/--"`）无需处理：`tailAt = 0`
  //      ⇒ `bare === ''` ⇒ `fenced === true`，已被双路径冗余覆盖。
  //      ⚠️ 举例只用**含空白**的形态：`"--x/--"`、`"-x/---"` 这类**不含空白**的形态在守卫
  //      第一格（`!/\s/.test(t) || !/[\\/]/.test(t)` 即早退）就返回 false 了，**根本走不到**
  //      本格，拿它们当「成因②」的例子会把下一个读者引到错误的位置。
  //   ② 「装饰性开栏 + 装饰性收栏」（见上 `decorLead` / `fenced`）。
  //   ① 的收栏那一格必须与②**同一套线性写法**：照抄正则 `/-+\s*$/` 会与上面那个正则
  //   **同类**（同一张「未锚定贪婪量词 + 可选空白 + `$`」的写法），在
  //   「含分隔符 + 连字符串+空白开头」的病态输入上叠加。实测 `'- /' + '-'*n + 'x'`：
  //   n=8k/16k/32k → 正则收栏版 52.8/220.9/888.1 ms（与修改前 56.3/220.0/864.4 ms 同量级），
  //   而线性版 0.076/0.104/0.121 ms；判定等价性在 20328 格上分歧 0。
  const tail1At = trailingDashRunAt(head, 1)   // ⚠️ min=1：与①的收栏判据**同一把尺子**
  const bareAt1 = tail1At >= 0 ? head.slice(0, tail1At).trim() : ''
  if (!(/^-+\s/.test(s) && trailingDashRunAt(s, 1) >= 0 && !DESTRUCTIVE_LABELS.has(bareAt1)) && !fenced) return false
  return !head || (/\s/.test(head) && !DESTRUCTIVE_LABELS.has(head)) || BAD_LABEL_CHARS.test(head)
}

/**
 * 「这个词元是**赋值**（`NAME=value` / `$name=value`）」—— label 提取的另一条入口判据。
 *
 * ⚠️ 与 `LEAD_ASSIGN` **不同**：那个不认 `$` 前缀（`unwrapWordsFrom` 用它剥的是
 * **shell 风格**的赋值），而 PowerShell 的赋值恰恰写作 `$d=…`。两处判据服务的对象不同
 * （一个管「剥前缀」，一个管「认命令名」），故各自成表而不是硬凑成一张。
 *
 * ⚠️ 本常量（`LABEL_ASSIGN`，认 `$` 前缀的宽口径）**当前已无消费方** —— 它是
 * 「bash 侧认 `NAME=`」的**错口径**：bash 的赋值前缀不允许 `$`（`$A=/bin/rm` 展开成
 * `=/bin/rm`，是真命令）。bash 分支已改用 `LEAD_ASSIGN`（见 `bashLeftIsAssign` 的
 * 缺陷 3 实测表）。保留常量只是不扩大本次改动面，**不要**再把它接回 label 判据。
 *
 * ── ⚠️ 这条判据**必须带方言维度**────────────────────────────────
 * 同一个形态在两门方言里**语义相反**，故**不存在**一个不分方言的正确判据：
 *
 *   · **bash**：`NAME=value` 是赋值（`LEAD_ASSIGN` 的口径，值可含 `/`）⇒ 不执行任何命令。
 *   · **pwsh**：赋值**必须**写作 `$name=…`；**不带 `$` 的 `NAME=…` 是真命令**。
 *
 * 本机 PS 5.1 实测（`[Parser]::ParseInput`，与「实执行」双向确认）：
 *     `A=/bin/rm`              → PipelineAst、**cmdAst=1**、assignAst=0
 *     `my=dir/rm`              → PipelineAst、**cmdAst=1**、assignAst=0
 *     `FOO=/usr/local/bin/myapp` → PipelineAst、**cmdAst=1**、assignAst=0
 *     `$d='X:/ws/x'`           → AssignmentStatementAst、cmdAst=0、**assignAst=1**
 *   实执行（无害替代目标，临时目录内建 `A=\bin\rm.cmd` / `my=dir\rm.cmd` /
 *   `FOO=\usr\local\bin\myapp.cmd` / `x=1\diskpart.cmd` 后 `& '<原文>'`）：
 *     `A=/bin/rm` / `my=dir/rm` / `FOO=/usr/local/bin/myapp` / `x=1/diskpart`
 *     **四个全部 RAN=True、rc=0** —— 即 pwsh 侧它们是**真会跑起来**的命令。
 *
 * 故：bash 侧用 `LEAD_ASSIGN`（认 `NAME=`，**不认 `$` 前缀** —— `$A=/bin/rm` 在 bash 下
 * 展开成 `=/bin/rm`、是真命令，见 `bashLeftIsAssign` 的缺陷 3 实测表），pwsh 侧用
 * `LABEL_ASSIGN_PWSH`（只认 `$NAME=`）。
 * 不分方言一刀切会让**其中一门方言必然判错**：按 bash 判 ⇒ pwsh 侧真命令 label 变空 ⇒
 * 段级 `unparsable` ⇒ `destructive=false` ⇒ 破坏性子设置与**全部例外匹配**双双跳过 ⇒
 * 落大分类（**fail-open**，实测大分类 allow + 八档全 deny 下由 deny 变 allow）。
 */
const LABEL_ASSIGN = /^\$?[A-Za-z_][A-Za-z0-9_]*=/
// pwsh 侧同一判据的**左半**：赋值必须带 `$`（见上「PS 5.1 实测」）。不带 `$` 的
// `NAME=…` 在 pwsh 里是命令名的一部分，交给下面的 `commandNameOf` 正常剥路径取 label。
// ⚠️ 只认左半**不够**：右侧是裸词/路径时它仍是**真命令**，见下。
const LABEL_ASSIGN_PWSH = /^\$[A-Za-z_][A-Za-z0-9_]*=/

/**
 * pwsh 侧「`$NAME=右侧` 到底是不是**真赋值**」的判据（`LABEL_ASSIGN_PWSH` 的**右半**）。
 *
 * ── 为什么只看左半不够 ──────────────────────────────────────────────────────
 * `$NAME=` 的右侧是**裸词 / 路径**时，PS 把它当**命令**执行，不是赋值
 * （`$A=/bin/rm`、`$A=rm`、`$A=1/rm` 的 cmdAst 均为 1）。
 * 只按左半判 ⇒ 整段判「没有命令要执行」⇒ label 空 ⇒ 段级 `unparsable` ⇒
 * `destructive=false` ⇒ 破坏性子设置与全部例外匹配双双跳过 ⇒ 落大分类（**fail-open**）。
 *
 * ── 判据（右侧形态白名单，方向 fail-closed）──────────────────────────────────
 * 只有右侧**确实是值**时才判赋值；其余一律不拦，交给 `commandNameOf` 剥路径取 label。
 * 白名单逐条来自上表实测的 **cmdAst=0** 那一列：
 *     `$A=1` / `$A=3.14` / `$A=.5` / `$A=1kb` / `$A=0x10` / `$A=1e5` / `$A=1..5` / `$A=1+2`
 *     `$A=$OTHER` / `$A=$null` / `$A=$true` / `$A=$A.foo` / `$A=$A::foo` / `$A=${env:TEMP}`
 *     `$A='X:/ws/x'` / `$A="X:/ws/x"` / `$A=-1` / `$A=+1` / `$A=-$A` / `$A=+$A` / `$A=--1`
 *     `$A=(1)` / `$A=(1+2)` / `$A=@(1,2)` / `$A=@{a=1}` / `$A=[int]1` / `$A=[int]` / `$A=!$true`
 *     `$A=`（空右侧：实测是 `ErrorStatementAst`，判「认不出」是保守方向）
 *   收敛成：空 / 引号开头 / `$ ( @ [ ! , .` / 数字 / `-`·`+`·`~` 后跟值起始字符。
 * ⚠️ 「右侧含路径分隔符」单独排除：`$A=$env:TEMP/x` 与 `$A=1/rm` 实测都是 **cmdAst=1**
 *    （变量或数字后面拼上路径就成了命令名）。引号串里的 `/` 不算 —— 上一条先返回。
 *
 * ── 为什么要读**段原文**（`SEG_TEXT`）而不是词元 ────────────────────────────────
 * 词法器**剥引号**后，`$d='X:/ws/x'`（赋值）与 `$d=X:/ws/x`（真命令）的词元**逐字相同**
 * （实测都是 `$d=X:/ws/x`）—— 词元粒度上不可区分，原文里那对引号是唯一判据。
 * 该形态是用户真实弹窗缺陷的钉桩（写下的例外永不命中），不能为了修缺陷 1 把它回退。
 * 无原文戳时（手搓的词元数组、`unwrapWords` 的 slice 视图）退化为「只用词元判」，
 * 方向仍是 fail-closed（认不出 ⇒ 不产出候选按钮，命令照旧弹窗）。
 *
 * @param {string[]} words 段词元数组（可能带 `SEG_TEXT` 戳）
 * @param {string} token 剥完前缀后的命令头词元（守卫已保证它是段内**唯一**词元）
 * @returns {boolean} 为真表示这是真赋值（没有命令要执行）
 */
function pwshRightIsValue(words, token) {
  const raw = Array.isArray(words) ? words[SEG_TEXT] : undefined
  const text = typeof raw === 'string' && raw ? raw : String(token == null ? '' : token)
  const m = LABEL_ASSIGN_PWSH.exec(text)
  if (!m) return false
  const right = text.slice(m[0].length).replace(/^\s+/, '')
  if (!right) return true
  const c = right[0]
  // 引号串：**必须最先判**（引号内可以含 `/`，而下面那条分隔符判据会把它误判成命令）
  if (c === "'" || c === '"') return true
  if (/[\\/]/.test(right)) return false
  if (c >= '0' && c <= '9') return true
  // `$` 变量 / `(` 子表达式 / `@` 数组与哈希 / `[` 类型字面量 / `!` 非 / `,` 一元逗号 / `.5`
  if ('$(@[!,.'.indexOf(c) !== -1) return true
  // `-1` / `+1` / `~1` / `--1` / `-$A` 是值；而 `-abc` / `+abc` 实测 cmdAst=1（命令）。
  // ⚠️ 本格**恒真**：外层守卫已保证
  //    `c ∈ {-,+,~}`，而 `right[0]` 就是 `c` 本身、必然命中紧随其后的必选字符类
  //    `[-+~$(@[!,.0-9]`（可选组 `[-+~]?` 的字符集是它的**真子集**，恒可省略）。
  //    故下面的 `return false` 在本分支**永不进入**，等价于直接 `return true`。
  //    实测行为不可观测（恒 false 变体 81 词元 × 2 方言 × 4 观测点分歧 0），
  //    故只做等价化简，**不为它补断言**。
  if (c === '-' || c === '+' || c === '~') return true
  return false
}

/**
 * bash 侧「`NAME=右侧` 到底是不是**真赋值**」的判据（`LEAD_ASSIGN` 的补充条件）。
 *
 * ── 为什么只看词元不够 ──────────────────────────────────────────────────────
 * 词法器**剥引号**后，`'A=/bin/rm'`（整体引号）与 `A=/bin/rm`（无引号）的词元**逐字相同**
 * —— 词元粒度上不可区分，原文里那对引号是唯一判据。bash 下 `NAME=` 整段必须是字面量
 * （未加引号、未转义）才算赋值前缀；`"A=/bin/rm"` 与 `'A=/bin/rm'` 都是**真命令**。
 * 只按词元判 ⇒ 引号形态被判成赋值 ⇒ label 空 ⇒ 段级 `unparsable` ⇒ `destructive=false`
 * ⇒ 破坏性子设置与全部例外匹配双双跳过 ⇒ 落大分类（**fail-open**）。
 *
 * ── 判据（段原文里存在**词首且非重定向目标位**的字面 `NAME=`）─────────────────────
 * 取词元上 `LEAD_ASSIGN` 已匹配出的字面前缀（如 `A=`），在**段原文**里逐处 `indexOf`，
 * 命中处的**前一字符是空白（或该处就是段首）**、**且向前跳过空白后不落在操作符上**，
 * 才算数 —— 那正是 bash 认赋值前缀的位置。
 * 于是前缀重定向形态仍判赋值（实测真值都是赋值，四格全对）：
 *     `> /tmp/x A=1` / `2>/dev/null A=1` / `> '/tmp/z z' A=1` / `A=1 > /tmp/x`
 * 而引号/转义插进名字或 `=` 时，字面 `NAME=` 在原文里**要么根本不存在**
 * （`'A=/bin/rm'` 里 `A=` 的前一字符是 `'`，不是空白），**要么前一字符是引号或反斜杠**
 * （`A'='/bin/rm`、`A\=/bin/rm`）—— 两种都不满足「词首」，判「不是赋值」。
 * **重定向目标位**那一格（`'A=/bin/rm' > A=x`）由「操作符」那半格拦下，见函数体内说明。
 *
 * ⚠️ 判据只用「字面前缀 + 词首位置」，**不做「原文偏移 + 词元长度」的切片**：
 * 词法器会**拼接**词元（`'A=''/bin/rm'` 的词元是 `A=/bin/rm`，而它在原文里
 * `indexOf` 返回 -1、长度差 4），段原文与词元之间**没有保序的字符对应**，
 * 按长度切片会切错位置、切出错误的判据对象。
 *
 * ⚠️ 无原文戳时（`rawCommandNamesInto` 的文本粗提、手搓的词元数组）判「**不是**赋值」
 * —— 见函数体内「本轮缺陷 2 的修法」那一段。方向 fail-closed（保留命令名只收紧不放宽）。
 * 载荷族（`segmentLabelsCore` 的 `-exec`）**不经过本函数**：`segmentLabelFrom` 的守卫是
 * `if (w.length === 1 && …)`，而载荷族的词元数组长度是完整段长。实测（本机插桩计数）：
 * 32 格载荷语料（`-exec` / `-execdir` / `-ok` × `{} ;` / `{} +` × 两门方言 × 4 种载荷）
 * 调用次数 **0**，且 HEAD / PRE / NOW 三态分歧 **0**、三种单缺陷修法在载荷族上分歧 **0**。
 *
 * @param {string[]} words 段词元数组（可能带 `SEG_TEXT` 戳）
 * @param {string} token 命令头词元（守卫已保证它是段内**唯一**词元）
 * @returns {boolean} 为真表示这是真赋值（没有命令要执行）
 */
function bashLeftIsAssign(words, token) {
  // ⚠️ 判据对象是 `LEAD_ASSIGN`（**不认 `$` 前缀**），不是 `LABEL_ASSIGN`。
  //    bash 的赋值前缀不允许 `$`：`$A=/bin/rm` 会先把 `$A` 展开成**空串**，词成了
  //    `=/bin/rm` —— 那是一次**真命令**执行。Git Bash 5.3.15 实测（`mktemp -d` 内建
  //    `=/bin/rm` / `X=/bin/rm` 可执行文件，整行**写进文件再 source**，故赋值语义与真跑
  //    完全一致；RAN 证据写进独立日志，不受该行自身重定向影响）：
  //        `unset A; $A=/bin/rm`  → **RAN[=/bin/rm]**（A 仍 unset）      ⇒ 真命令
  //        `A=X;     $A=/bin/rm`  → **RAN[X=/bin/rm]**                    ⇒ 真命令
  //        `unset A; $A=ver`      → rc=127（`=ver` 不存在）               ⇒ 真命令
  //        `unset A; $A='/bin/rm'` / `$A="/bin/rm"` → **RAN[=/bin/rm]**   ⇒ 真命令
  //        `$_A=/bin/rm` / `$A_1=/bin/rm` / `$BIN=/usr/bin/rm` / `$CMD=/bin/dd`
  //                              → **全部 RAN**                          ⇒ 真命令
  //        `2>/dev/null $A=/bin/rm` → **RAN[=/bin/rm]**（先前被误判为「破坏」的那一格，
  //                                   其实是 stderr 文本探针被 `2>/dev/null` 吞掉的伪影）
  //        对照 `A=/bin/rm`（字面量）→ **RAN=<none>**、`A` 被设为 `/bin/rm` ⇒ 真赋值
  //    带 `$` 前缀的 `LABEL_ASSIGN` 会把上面整族判成赋值 ⇒ label 空 ⇒ 段级 `unparsable`
  //    ⇒ `destructive=false` ⇒ 破坏性子设置与全部例外匹配双双跳过 ⇒ 落大分类（**fail-open**）。
  //    实测（大分类 allow + 八档全 deny）端到端 14/14 格 HEAD=deny → PRE=**allow**。
  const m = LEAD_ASSIGN.exec(String(token))
  if (!m) return false
  const raw = Array.isArray(words) ? words[SEG_TEXT] : undefined
  // ── 无原文戳 → 判「**不是**赋值」（本轮缺陷 2 的修法，方向与原先相反）────────────────
  // 原先这里写 `return true`（退化到「只用词元判」），而 `rawCommandNamesInto` 走的正是
  // 这条路径：它把原文按 `/[\n\r;|&(){}<>]+/` 切分、`tokens` 是**自建的新数组**（:4880），
  // 上面没有词法器的 `SEG_TEXT` 戳 ⇒ 该函数**恒走退化支**。
  // 而词法器会**拼接**词元（`''A=/bin/rm` 的 token 是 `A=/bin/rm`，与无引号逐字相同），
  // 文本路径却看到原文 `''A=/bin/rm` ⇒ 旧判据判「非赋值」是**对的**；但无戳时它退回
  // 「只看词元」⇒ 判成赋值 ⇒ 认不出 `rm`。
  // 后果（整行 `ok:false` 路径与 opaque 段并集路径上丢命令名 ⇒ 用户显式 deny 例外与
  // 破坏性子设置双双失明，fail-open）。Git Bash 实测（同上手法，真值列）：
  //     `''A=/bin/rm <<EOF…EOF`          → **RAN[A=/bin/rm]**       ⇒ 真命令（HEAD=deny）
  //     `A=/bin/rm>out rm -rf /etc <<EOF`→ 真命令（`rm` 在原文里）  ⇒ HEAD=deny
  //     `BIN=/usr/bin/rm; $BIN -rf / <<EOF` → 真命令（`$BIN` 展开） ⇒ HEAD=deny
  //     `chmod 777 /etc/passwd $(A=/bin/rm)` / `shutdown /s $(A=/bin/rm)` ⇒ 真命令
  //     ⚠️ 纯 `A=/bin/rm <<EOF…EOF` 在 bash 下**确是赋值**（RAN=<none>），但它**不走这条
  //        路径**：带戳主路径照旧判赋值（label 空），此处只影响「无戳」的文本粗提路径。
  // 方向 fail-closed：不判赋值 ⇒ **保留**命令名 ⇒ 该名字只会让更多档参与「取最严」、
  // 让用户写下的 deny 例外照常命中，绝不放宽任何东西。
  // 实测（本机三态对拍，1830 格含两门方言、真值按 Git Bash 实测表逐格标注）：
  // PRE→NOW 放宽 0 / 收紧 353；真值=COMMAND 的 1539 格里 NOW=allow 的 360 格与 HEAD、PRE
  // **逐格相同**（即本次未新增任何「真命令却放行」）。
  if (typeof raw !== 'string' || !raw) return false
  const nameEq = m[0]
  for (let at = raw.indexOf(nameEq); at !== -1; at = raw.indexOf(nameEq, at + nameEq.length)) {
    if (at === 0 || /\s/.test(raw.charAt(at - 1))) {
      // ── 词首命中还不够：**重定向目标位**的 `NAME=` 不是赋值前缀───
      // 判据原先只问「段原文里**任何位置**有没有前一字符是空白的字面 `NAME=`」，而重定向
      // 目标位恰好就是这个位置 ⇒ `'A=/bin/rm' > A=x` 这类**真命令**被整段判成赋值。
      // Git Bash 实测（同上手法；`A=x` 等目标文件已在 cwd 内建好，故重定向本身会成功）：
      //     `'A=/bin/rm' > A=x`        → **RAN[A=/bin/rm]** ⇒ 真命令
      //     `> A=x 'A=/bin/rm'`        → **RAN[A=/bin/rm]** ⇒ 真命令（重定向在命令词之前）
      //     `'A=/bin/rm' >| A=x` / `2>` / `&>` / `<>` / `3>` / `>>` / `2>>` / `&>>` / `<`
      //                                → **全部 RAN**       ⇒ 真命令（`> A=` 那格因目标是
      //                                  已存在的目录而 rc=1，但**命令同样被启动**）
      //     `'A=/bin/rm' > A=1` / `> A=` → **RAN[A=/bin/rm]** ⇒ 真命令
      //     `$( A=x ) 'A=/bin/rm'`      → **RAN[A=/bin/rm]** ⇒ 真命令
      //     `echo hi > A=x; 'A=/bin/rm'`→ **RAN[A=/bin/rm]** ⇒ 真命令
      //     ⚠️ `{ A=x; } 'A=/bin/rm'` 在 bash 里是**语法错误**（rc=2，命令未启动）——
      //        但解析器认不出它，该格落大分类，两侧一致，不在本判据的可达面上。
      // 判据：命中处向前跳过空白，若落在**操作符字符类**上，则该处不是赋值前缀。
      // ⚠️ 字符类必须是**完整操作符集** `[\n\r;|&(){}<>]`，不能只判 `>` / `<`：只判
      //    `>`/`<` 的简化版在三族上仍有残留（本机实测，命令词侧取整体引号 `NAME=path`）：
      //      · `>|`  —— 前一字符是 `|`，不在 `>`/`<` 里；
      //      · `{ A=x; }` / `$( A=x )` —— 前一字符是 `{` / `(`（**开**括号，不是闭括号；
      //        取 `SEG_TEXT` 戳逐格实测，命中处的前一非空白字符确为 `{` / `(` ——
      //        原写 `}` / `)` 与实测不符，已按实测订正）。
      //    简化版：33 格真值表错 **2**、1092 格枚举里 **66** 格与 HEAD 不同
      //    （`>|` 22 + 分组 22 + 命令替换 22，三族各占 22 格）；
      //    完整字符类：真值表错 **0/33**、同一枚举 HEAD≠修法 = **0**、两套件全绿。
      // 真赋值正例**必须**保持判赋值（实测真值都是赋值，RAN=<none>）：
      //     `> /tmp/x A=1` / `2>/dev/null A=1` / `> '/tmp/z z' A=1` / `A=1 > /tmp/x`
      //     / `A=/bin/rm > A=x`（`A=` 在段首、`A=x` 在 `>` 之后 —— 前者命中即返回真）
      // ── 前提：命中处**之前**不能已有 opaque 构造占住命令词位────
      // 上面那两格判据（词首 + 非重定向目标位）对**带具名目标的重定向**仍不够：`> out A=x`
      // 里 `A=` 的前一非空白字符是目标词 `out` 的 `t`，**不是**操作符 ⇒ 判「是赋值」。
      // 单看这一格是对的（`> out A=x` 在 bash 下确是真赋值，实测 `A` 被设为 `x`）；
      // 但**同一段里若命令词位已被 opaque 构造占据**，该 `NAME=path` 在 bash 里是**真命令**，
      // 而词元数组只剩 1 个词元 ⇒ 进得了 `segmentLabelFrom` 的 `w.length === 1` 守卫
      // ⇒ 整段判「没有命令要执行」。
      // Git Bash 5.3.15 实测（marker 真被执行、rc=0、`X` 仍 unset ⇒ **真命令**）：
      //     `$(true) > out X=/bin/marker` / `$(true) >out …` / `$(true) 2> out …`
      //     / `$(true) > out > out2 …` / `` `true` > out … `` / `$(true) >> out …`
      //     / `$(true) >| out …` / `$(true) &> out …` / `$(true) < out …`
      //     / `> out $(true) X=/bin/marker`（opaque 在目标**之后**、命令词位）
      //       → **全部 RAN[X=/bin/marker]**、`X` 仍 unset ⇒ 真命令
      // 对照（真值仍是**赋值**，故判据不得误伤）：
      //     `> out X=/bin/marker`（无 opaque）→ `X=/bin/marker`（赋值，marker **未**执行）
      //     `> $(true) X=/bin/marker`（opaque 在**重定向目标位**）→ 同上，真赋值
      //       （只有 `ambiguous redirect` 警告，重定向失败但赋值照做）
      //     `X=1 $(true)`（赋值在 opaque **之前**）→ `X=1` ⇒ 真赋值
      // ⇒ 判据必须是「命中处之前有**命令词位**的 opaque 构造」，**不是**「段里有 opaque」。
      // `SEG_OPAQUE_AT` 正是词法器按 `pending === undefined` 记下的那个位置（见其说明）。
      // 方向 fail-closed：不判赋值 ⇒ **保留**命令名 ⇒ 更多档参与「取最严」、用户写下的
      // deny 例外照常命中，绝不放宽任何东西。
      const opaqueHeadAt = words[SEG_OPAQUE_AT]
      if (typeof opaqueHeadAt === 'number' && opaqueHeadAt < at) return false
      // ── 前提 ②：命中处**之前**不能已有 opaque 构造占过**重定向目标位** ──────────────
      // 这种构造不产出词元，`flushWord` 的 `pending = undefined` 复位被跳过：命令词被吞进
      // `writeTargets`、`words` 里只剩 `A=/bin/rm` ⇒ 进得了 `segmentLabelFrom` 的
      // `w.length === 1` 守卫 ⇒ 判「是赋值」⇒ label 空 ⇒ 落大分类（fail-open）。
      // 判据**只看 `SEG_OPAQUE_TARGET` 是否存在**，**不做位置比较**：`NAME=path` 在段首时
      // `at === 0`、`k = -1`，位置比较会因「OT < 0」恒假而**根本没被咨询**，落到
      // `k < 0` 无条件判赋值，反而新开一族 fail-open。与 `SEG_OPAQUE_AT` 的差别见该常量的
      // 注释：那个要问「命中处之前有没有」，本戳是段级事实、与下标无关。
      const opaqueTargetAt = words[SEG_OPAQUE_TARGET]
      if (typeof opaqueTargetAt === 'number') return false
      // ── 前提 ③：占目标位的 opaque 构造**带内联程序**时同样不是赋值──
      // 上面两条判据都**不过问构造里装了什么**，而下面这一族里装的是**真会执行的载荷**：
      //     `> $(sh -c "rm -rf /tmp/zzz") > out A=/bin/rm`
      // Git Bash 5.3.15 实测（载荷无害化为 stub，只写独立日志）：**stub 被调用**、`A` 仍
      // unset ⇒ 真命令；HEAD 给 `deny`，而仅靠上面两条的标记链给 `allow`（**fail-open**）。
      // ⚠️ 本前提**不能**并入上面那条：`SEG_OPAQUE_TARGET` 在「被吞的词是赋值词」时**故意
      //    不成立**（`> $(mktemp) A=/bin/rm B=/bin/rm` 真值 ASSIGN），而本前提要覆盖的
      //    正是「构造带载荷」—— 两者的判据对象不同（一个是位置事实、一个是构造内容）。
      // ⚠️ 顺序无妨（两条都是 `return false`），但**必须并列存在**：删掉上面那条会让
      //    `> $(mktemp) r"m" A=/bin/rm` 回退，删掉本条的后果见下。
      // ⚠️ 本戳在 `noteOpaqueText` 里记，**不受「新重定向作废未定案候选」那处影响** —— 原因见
      //    `SEG_OPAQUE_PAYLOAD` 的说明（定案分支在本族里根本不会执行）。
      if (words[SEG_OPAQUE_PAYLOAD] === 1) return false
      let k = at - 1
      while (k >= 0 && /\s/.test(raw.charAt(k))) k -= 1
      if (k < 0 || !/[\n\r;|&(){}<>]/.test(raw.charAt(k))) return true
    }
  }
  return false
}

// ── 段词元数组上的**方言戳** ─────────────────────────────────────────────────────
// 存在的理由：方言维度必须一路透传到 `segmentLabelFrom` 的那条赋值守卫，而**消费侧并不
// 总能显式传方言** —— `index.js` 的候选生成（`segmentLabel(seg.words)`）、破坏性判定
// （`isDestructiveSegment(seg.words)`）与例外标注（`canCarryDestructivePayload(seg.words)`）
// 拿到的只是**段词元数组**，它们不知道方言，也不该为此各存一份（那正是本文件反复修的
// 「同一份知识写两遍必然漂移」）。
//
// 而**词法器是唯一确知方言的地方**（`decomposeCommand(source, shell)` 的第二个形参），
// 故由它在产出段时把方言戳在词元数组上，消费侧原样把数组传回来即可 —— 零接口变更。
//
// ⚠️ 用 **Symbol** 而不是普通属性/`defineProperty`：`Object.keys` / `JSON.stringify` /
// 展开 / `for…in` / 深比较**都看不到** Symbol 键，故 `seg.words` 对既有全部消费方
// （含 `test/regressions.mjs` 的结构断言与快照）**逐字不变**；且 `words[k] = sh` 是
// 普通赋值，没有 `defineProperty` 的每次调用开销（词法器在判定热路径上）。
// ⚠️ 数组的 `slice` / `concat` **不复制** Symbol 键 —— 故只在「原数组」上取戳；
// `segmentLabelFrom` 内部的两条 opaque 出口都直接返回 `''`，不受影响。
const SEG_SHELL = Symbol('dshSegmentShell')

// ── 段词元数组上的**原文戳** ─────────────────────────────────────────────────────
// 存在的理由：pwsh 侧 `$NAME=右侧` 的**引号**是「真赋值 vs 真命令」
// 的唯一判据，而词法器剥引号后两者的词元**逐字相同**（实测 `$d='X:/ws/x'` 与
// `$d=X:/ws/x` 的词元都是 `$d=X:/ws/x`）—— 词元粒度上不可区分，只有段原文还留着引号。
// 与 `SEG_SHELL` 同一手法（Symbol 键对 `Object.keys` / `JSON.stringify` / 展开 /
// `for…in` / 深比较全部不可见，故 `seg.words` 对既有消费方逐字不变）。
// ⚠️ 与 `SEG_SHELL` 的**一处差别**：`seg.text` 是 `segText.trim()` 的结果，而词元在
//    `segText` 里是**原文**（引号保留）—— 故两者同源、只是 trim 与否，判据只用前缀，
//    不受 trim 影响。`slice` / `concat` 同样不复制 Symbol 键，消费侧必须传**原数组**。
const SEG_TEXT = Symbol('dshSegmentText')

// ── 段词元数组上的 **opaque 起点戳** ─────────────────────────────────────────────
// 存**段原文里第一个 opaque 构造的起始下标**（无构造时缺席）。与 `SEG_SHELL` / `SEG_TEXT`
// 同一手法（Symbol 键对 `Object.keys` / `JSON.stringify` / 展开 / `for…in` / 深比较全部
// 不可见，故 `seg.words` 对既有消费方逐字不变）。
//
// 存在的理由（本轮缺陷 4 的修法）：`bashLeftIsAssign` 判「`NAME=` 是不是赋值前缀」时，
// 除了「词首 + 非重定向目标位」，还缺一个前提 —— **命令词位没被 opaque 构造占据**。
// 反例（Git Bash 5.3.15 实测，marker 真被执行、rc=0、`X` 仍 unset ⇒ **真命令**）：
//     `$(true) > out X=/bin/marker` → RAN[X=/bin/marker]
// 该段词元数组只剩 `['X=/bin/marker']`，`X=` 在原文里前面是空白、跳过空白落在目标词
// `out` 的 `t` 上（不是操作符）⇒ 现行判据判「是赋值」⇒ label 空 ⇒ 段级 `unparsable`
// ⇒ `destructive=false` ⇒ 破坏性子设置与全部例外失配 ⇒ 落大分类（**fail-open**）。
//
// ⚠️ 为什么**不能**直接问 `seg.opaque`：那是**段级第一个原因字符串**（如
//    `'command substitution cannot be read statically'`），只回答「有没有」、**判不了位置**
//    —— 而本判据要的正是「命中处**之前**有没有」。`seg.opaqueTexts` 虽是数组，但要拿它
//    在段原文里 `indexOf` 反推位置，那等于把「原文与构造的对应关系」再算一遍（该数组记的是
//    构造原文、不含下标，且**同一个构造可以重复出现**，`indexOf` 只能给首个命中）。
//    故由**唯一确知位置**的词法器在产出段时把下标戳下，判定侧 O(1) 直读。
// ⚠️ 下标是**段原文**（`SEG_TEXT`，即 `segText.trim()`）坐标系里的值，与 `bashLeftIsAssign`
//    里 `raw.indexOf(nameEq)` 的坐标系**同一个** —— 两者都取自 `words[SEG_TEXT]`。
const SEG_OPAQUE_AT = Symbol('dshSegmentOpaqueAt')

// ── 段词元数组上的 **opaque 占过重定向目标位** 戳（粘性）──────────────────────────
// 存**段原文里第一个「占过重定向目标位」的 opaque 构造**的起始下标；没有时缺席。
// 与 `SEG_SHELL` / `SEG_TEXT` / `SEG_OPAQUE_AT` 同一手法（Symbol 键对 `Object.keys` /
// `JSON.stringify` / 展开 / `for…in` / 深比较全部不可见）。
//
// 存在的理由：`SEG_OPAQUE_AT` 只记「**命令词位**的 opaque 构造」，而这里 opaque 落在
// **重定向目标位**（`pending !== undefined`），按设计不记 `SEG_OPAQUE_AT`。这种构造不产出
// 词元（`$( )` / 反引号 / 分组块都只 `pushText`），命令词被吞进 `writeTargets`，
// `words` 里只剩 `A=/bin/rm` ⇒ 进得了 `segmentLabelFrom` 的 `w.length === 1` 守卫 ⇒
// `bashLeftIsAssign` 会判「是赋值」。`> $(mktemp) r"m" A=/bin/rm` 与 `> out A=/bin/rm`
// 的 `words` 逐字相同，差别只在本戳有没有（前者 =2、后者缺席）⇒ 判据必须落在
// 「本段有没有 opaque 构造占过重定向目标位」这条只有词法器知道的信息上。
//
// ⚠️ 必须是**粘性**的（不在遇到新重定向时复位，见 `noteOpaqueTarget`）：形如
// `> $(mktemp) r"m" A=/bin/rm > out2` 的尾部还有重定向，复位式标记会漏掉它们。
// ⚠️ 与 `SEG_OPAQUE_AT` 的关键差别：那个要比较位置（`< at`，问「命中处之前有没有」），
// 本戳记的是段级事实，判定侧只问「有没有」（`typeof … === 'number'`），与下标无关。
const SEG_OPAQUE_TARGET = Symbol('dshSegmentOpaqueTarget')

// ── 段词元数组上的 **占目标位的 opaque 构造带内联程序** 戳 ─────────────────────────
// 存 `1`（命中时）／缺席（未命中）。与 `SEG_SHELL` / `SEG_TEXT` / `SEG_OPAQUE_AT` /
// `SEG_OPAQUE_TARGET` 同一手法（Symbol 键对 `Object.keys` / `JSON.stringify` / 展开 /
// `for…in` / 深比较全部不可见，故 `seg.words` 对既有消费方逐字不变）。
//
// 存在的理由（批次 A 的修法）：`SEG_OPAQUE_TARGET` 只回答「opaque 构造占过重定向
// 目标位」，而它从不过问那个构造里装了什么 —— 于是下面这一族被静默放行：
//     `> $(sh -c "rm -rf /tmp/zzz") > out A=/bin/rm`
// 该行 bash 真值是**真命令**且**载荷真的执行**；HEAD 给 `deny`，而标记链给 `allow`（fail-open）。
//
// ⚠️ 为什么不能「在**定案**时加一问」（这是本缺陷最容易走错的地方）：
//    定案发生在 `flushWord`，而「新重定向作废未定案候选」那处（`>` 分支里
//    `opaqueTargetSwallow = false` 那一行）会**先把
//    `opaqueTargetSwallow` 置 false** —— 上面那一行里 `$(sh -c …)` 之后紧跟 `> out`，
//    于是**定案根本不会发生**（时序：`noteOpaqueTarget` 置位 → `noteOpaqueText` 记文本 →
//    `>` 分支作废 `swallow` ⇒ `flushWord` 的定案分支不执行）。故任何「在定案处加判据」
//    的修法**一行都不会执行**。
// ⚠️ 所以本戳在 `noteOpaqueText` 里记 —— 那一刻 `opaqueTargetSwallow` **仍为 true**
//    （`>` 分支尚未到达），是唯一还能拿到「这个构造正占着目标位」的时机；且本戳**不参与
//    定案**、不受那处作废影响，判定侧与 `SEG_OPAQUE_TARGET` **并列**读它。
// ⚠️ 判据复用 `nestedInlineProgram` **单点**（不另写一份「什么算内联程序」）：
//    本文件反复记录的那类缺陷正是「同一份知识写两遍必然漂移」。
//
// ⚠️ **已知边界（刻意不扩，勿为它叠第二层判据）**：**首词认不出解释器的族** ——
//    ① 管道 `… | sh`：分段后第二段只有 `["sh"]` 一个词元、`nestedInlineProgram` 为 false
//       （`-c` 缺席），第一段首词是 `base64` ⇒ 两段都不命中。
//    ② 变量头 `$SHELL -c` / `${SHELL} -c`：`headCommandNameOf` 取到的是变量名而非解释器名。
//    ③ 分段里只有单名、没有 `-c` 的形态（`$(true; sh)` 这类）：同样不命中。
//    ⇒ 三族同一个根因：判据以「首词是解释器名」为前提。
//    ⚠️ 要覆盖它们得动 `nestedInlineProgram` 的语义（承重函数，`assessCommand` 的
//      `unparsable` 判定与 index.js 的候选守卫都在用），收益与风险不成比例 ⇒ 记为已知残余。
const SEG_OPAQUE_PAYLOAD = Symbol('dshSegmentOpaquePayload')

/**
 * 方言归一化：**显式实参 > 词元数组上的戳 > `'bash'`**。
 *
 * 默认 `'bash'` 与文件内既有口径一致（`decomposeCommand` / `assessCommand` 都写
 * `shell === 'pwsh' ? 'pwsh' : 'bash'`），且对**手搓的裸词元数组**（测试里大量存在）
 * 保持「按 bash 判赋值」的既有行为 —— 那是保守方向（认不出 ⇒ 不产出候选按钮）。
 */
function shellOfWords(words, shell) {
  if (shell === 'pwsh' || shell === 'bash') return shell
  if (Array.isArray(words)) {
    const s = words[SEG_SHELL]
    if (s === 'pwsh' || s === 'bash') return s
  }
  return 'bash'
}

// `decomposeCommand` 对「整行没有任何命令」返回的 reason。单独抽成常量是因为
// `assessCommand` 要按它把 code 分成 'empty' 与 'unparsable' 两种 —— 这两者排查方向不同
// （前者是调用方发了空串，后者是解析器覆盖不足），不该混成一个标注。
const EMPTY_COMMAND_REASON = 'the command line contains no command'

// 绝对路径直扫（绕过词法器）：bash 词法器把 `\` 当转义符，未加引号的
// `cat C:\Users\u\.ssh\id_rsa` 到达词元列表时已变成 `B:Usersu.sshid_rsa` ——
// 正好是这条规则要拦的那次读取的盘符形态。Windows 上的轻量实现必然复现同一个 bug，
// 1 行正则 + 5 行循环即可补上。这不是第二套词法器：只扫字面量绝对路径拼写，
// 加进候选后由同一套解析判定。
export const RAW_ABSOLUTE_PATH = /(?:^|[^A-Za-z0-9_])((?:[A-Za-z]:[\\/]|\\\\[^\s"'|&;<>()]+)[^\s"'|&;<>()]*)/g

// 双语文案（与 index.js 的 bi 同形；本文件不依赖宿主，自带一份 3 行实现）
const bi = (zh, en) => ({ zh, en })

function matchAt(re, input, index) {
  re.lastIndex = index
  const m = re.exec(input)
  return m === null ? undefined : m[0]
}

/**
 * 从一个词元取出「命令名」：剥路径前缀（两种分隔符都算）与可执行后缀，转小写。
 * 这是修好「命令名提取器认不出路径形态」的关键 —— 旧实现显式丢弃任何含 `:` `\` `/` 的词元，
 * 于是 `C:\Windows\System32\rm.exe -rf x`、`/usr/bin/rm -rf x`、`./rm -rf x` 全部提取为空，
 * 破坏性判定对它们完全不设防。
 *
 * ── ⚠️ 入口守卫在**调用方**（`segmentLabelFrom`），不在本函数 ──────────────────────
 * 本函数**不得**加「坏字符即拒绝」的守卫：它同时被 blast / 命令头判据当**分类器**用，
 * 而那些路径上有**刻意**依赖「赋值词元也解析出名字」的既有口径 —— 实测钉在 60j5：
 *     `sudo A=/bin/rm`  的 tiers/blast 必须与 `sudo rm` 逐字同值（`outside,priv`）
 * 即 `commandNameOf('A=/bin/rm') === 'rm'` 是**承重**的。label 侧要拒绝的是「这个词元
 * 根本不是命令」，而分类器侧要的是「这个词元里的命令名是什么」—— 两个问题不同，
 * 判据因此不能共用一处（这正是本轮第一版把守卫放错位置、弄红 14 组断言的原因）。
 */
function commandNameOf(text) {
  let t = String(text == null ? '' : text).trim()
  if (!t) return ''
  const idx = Math.max(t.lastIndexOf('/'), t.lastIndexOf('\\'))
  if (idx >= 0) t = t.slice(idx + 1)
  t = t.replace(/\.(?:exe|cmd|bat|com|ps1)$/i, '')
  return t.toLowerCase()
}

/**
 * 通配匹配的**线性**实现（`*` 任意长、`?` 恰好一个字符），两边都必须已转小写。
 *
 * 为什么不用正则：旧实现把用户写的 glob 逐字符翻成 `^…$` 正则，每个 `*` 变成 `.*`。
 * 多个 `.*` 夹在固定字面量之间、且整体**不匹配**时，回溯是组合爆炸 ——
 * 实测 `matchCommand('*a*a*a*a*a*a*a*a*a*a*b', 'a'.repeat(40))` 耗时 25 秒，
 * 长度 200 时直接挂死进程（探针跑满 180 秒未结束）。而段文本由 AI 完全控制、
 * 每条例外每个段都要匹配一次，判定挂起意味着 `tools/pre-execute` 不返回。
 *
 * 这里是经典的「记住最后一个星号」单趟扫描：最坏 O(n·m)，但**没有指数项**，
 * 且真实输入下基本是线性的。语义与旧正则一致（`*` 可匹配空串、`?` 匹配任意单字符）。
 *
 * ⚠️ **星号必须判在「字符相等」之前**（下面的顺序不能调换）：
 * 曾经的写法是先 `pat[p] === hay[h]` 再判 `*`，于是 pattern 里的 `*` 一旦撞上
 * haystack 里的**字面 `*`**，就走「字符相等」分支 —— `p`/`h` 同步前进、`star` 回退点
 * 从未记录，模式的 `*` 彻底丧失「任意长」语义。这是 AI 可轻易利用的绕过：
 *   例外 `rm -rf *` = deny 时，`rm -rf /data` 是 deny，而 `rm -rf *.log` 是 **allow**
 *   （haystack 里的字面 `*` 把模式的星号「吃掉」了）。
 * 随机对拍（字母表 `a*?`）下与旧正则实现的不一致率高达 21%，全部集中在
 * 「haystack 含 `*`/`?`」这一类 —— 而 AI 写的命令里带通配符是极常见的形态。
 * 让星号优先即可：先记录回退点，再让字符相等/`?` 走正常前进。
 */
function globMatch(pat, hay) {
  let p = 0
  let h = 0
  let star = -1
  let mark = 0
  while (h < hay.length) {
    // 星号优先：必须先于字符相等判断，否则会与 haystack 里的字面 `*` 相撞而失效
    if (p < pat.length && pat[p] === '*') { star = p; p += 1; mark = h; continue }
    if (p < pat.length && (pat[p] === '?' || pat[p] === hay[h])) { p += 1; h += 1; continue }
    // 失配：回退到最后一个星号，让它多吞一个字符（只有这一处回退，故不爆炸）
    if (star !== -1) { p = star + 1; mark += 1; h = mark; continue }
    return false
  }
  while (p < pat.length && pat[p] === '*') p += 1
  return p === pat.length
}

/**
 * 命令例外的模式匹配（单一来源：index.js 的例外判定与本文件的测试共用这一份）。
 *
 * 无通配符 → **词边界精确**（段 === pat，或段以 `pat ` 开头）。
 *   旧实现是 `indexOf !== -1`（非锚定子串），于是例外 `log` 会命中 `dialog --msgbox "rm -rf /"`，
 *   例外 `npm` 会命中 `echo hi > /tmp/x; npm publish`。
 *   不用「整串相等」是因为 `git commit -m` 这类例外必须能匹配带参数的实际命令
 *   （`git commit -m "fix bug"`）—— 词边界精确两者兼得。
 *
 * 有通配符 → 锚定整段的通配匹配（线性算法，见 globMatch）。
 *   `cmd *` 尾随通配保留「也匹配无参数原命令」的语义：`git status *` 同时覆盖 `git status`。
 *   这个通配现在安全了：匹配对象已经是单个命令段，它再也吞不到别的段。
 */
// 小写化的单条目 memo：段级判定里同一段文本会被**每条例外**各匹配一次
// （`resolveCategory` 遍历例外列表 → 每条例外一次 `matchCommand`），
// 而 `toLowerCase` 必须遍历整个 hay —— 段长 × 例外数就是纯重复劳动。
// 实测 399 KB 段上 toLowerCase 占单次匹配的 97.2%；200 条例外时真实链路
// 从 16.0 ms 涨到 34.1 ms（+44.7%），而 HEAD 的 `/i` 正则不做小写化、无此增长。
// 单条目足够：调用方总是拿同一段文本连续匹配多条例外，命中率接近 100%。
// 只缓存 hay（调用方的 pattern 每次都在变，缓存它没有收益）。
let memoHay = null
let memoLow = ''

export function matchCommand(pat, hay) {
  const p = String(pat == null ? '' : pat)
  const h = String(hay == null ? '' : hay)
  // 空 pattern 不匹配任何命令（否则空串恒真，等于放行所有命令）
  if (!p) return false
  if (h !== memoHay) { memoHay = h; memoLow = h.toLowerCase() }
  const lh = memoLow
  if (p.indexOf('*') === -1 && p.indexOf('?') === -1) {
    const lp = p.toLowerCase()
    return lh === lp || lh.startsWith(lp + ' ')
  }
  const lp = p.toLowerCase()
  // 「cmd *」尾随通配：`git status *` 既要匹配 `git status --short`，也要匹配 `git status`
  // （正则时代是 `( .*)?` 那个可选组）。两种形态取并集，语义等价。
  if (lp.endsWith(' *')) {
    const body = lp.slice(0, -2)
    return globMatch(body, lh) || globMatch(body + ' *', lh)
  }
  return globMatch(lp, lh)
}

/** 是否为丢弃输出的空汇（`> /dev/null`、pwsh `> $null` / `> NUL`）。不排除会让日常命令全部误报。 */
export function isNullSink(text, shell) {
  const t = String(text == null ? '' : text).trim().toLowerCase()
  return t === '/dev/null' || (shell === 'pwsh' && (t === '$null' || t === 'nul'))
}

/** `~user/…` 是**他人**家目录，任何已配置 root 都包含不了（普通 `~` 与 `~/` 不在此列）。 */
export function tildeUserTarget(text) {
  const t = String(text == null ? '' : text)
  return t.length > 1 && t.startsWith('~') && !t.startsWith('~/') && !t.startsWith('~\\')
}

/**
 * 裸词元是否显式路径。两个易漏项：点开头（`.git/config`、`.env`）与中段 `..`
 * （`b/../../../../Users/…` 只以普通名字开头，却能爬出工作区，与开头的 `../` 等价）。
 */
export function looksLikeExplicitPath(token) {
  const t = String(token == null ? '' : token)
  if (!t) return false
  if (t.startsWith('/') || t.startsWith('.') || t.startsWith('~')
    || /^[A-Za-z]:[\\/]/.test(t) || /^\\\\/.test(t)) return true
  // 中段 `..` 判定：单趟扫描，不分配数组。
  // 曾用 `t.split(/[\\/]/).includes('..')` —— 它每次调用都要切分并建一个数组，
  // 而这个函数在 flagEmbeddedPath 的循环里被反复调用（热路径）。语义完全等价：
  // 存在某个被分隔符（或串首/串尾）包住的、内容恰为 `..` 的片段即为真。
  //   `b/../x`、`a\..\b`、`x/..`、`..` → true；`..x`、`x..`、`x..y` → false
  for (let i = 0; i + 1 < t.length; i += 1) {
    if (t.charCodeAt(i) !== 46 || t.charCodeAt(i + 1) !== 46) continue  // 两个 '.'
    const before = i === 0 || t.charCodeAt(i - 1) === 47 || t.charCodeAt(i - 1) === 92
    if (!before) continue
    const after = i + 2 === t.length || t.charCodeAt(i + 2) === 47 || t.charCodeAt(i + 2) === 92
    if (after) return true
  }
  return false
}

/**
 * 从 flag 词元里撬出路径值：长选项在 `=` 后（`--output=B:/abs`），
 * 融合短选项把值接在选项字母后（`-oB:/abs`，GNU sort/tree 风格）。
 * 只取「显式路径拼写」的值，所以 `--pretty=format:%h`、`--parallel=2` 不会被误取。
 */
export function flagEmbeddedPath(text) {
  const t = String(text == null ? '' : text)
  const eq = t.indexOf('=')
  if (eq > 1) {
    const value = t.slice(eq + 1)
    return value !== '' && looksLikeExplicitPath(value) ? value : undefined
  }
  // 融合短选项：从每个可能的切点向后扫，贪婪匹配选项字母会吞掉盘符而藏起值。
  //
  // 性能：曾无条件 `t.slice(cut)` 再交给 looksLikeExplicitPath，切片拷贝量累加为
  // Σ(L−cut) = **O(L²)** —— 实测 L=128000 时 264 ms、L=256000 时 1034 ms（倍率趋近 4.0）；
  // 端到端 `'echo -' + 'a'.repeat(399000)` 单次判定 2551 ms，而等长的带 `=` 形态仅 18.2 ms。
  // 这段代码在 collectWritePaths 里对**每一段**都跑，段文本由 AI 控制且无长度上界。
  //
  // 优化：切片前先做 O(1) 的必要条件预筛，只在可能命中时才切片。
  // looksLikeExplicitPath(tail) 为真的必要条件有两条（任一成立即可）：
  //   ① tail 首字符 ∈ { '/', '.', '~', '\' }，或构成盘符 `X:` + 分隔符；
  //   ② tail 含 `..`（它的 `split(/[\\/]/).includes('..')` 分支）。
  // ② 与首字符无关（`a\..` 的 tail 首字符是字母也能命中），故不能只按首字符预筛 ——
  // 对拍时踩过：漏掉 ② 会让 `baa\..\~` 这类输入在更晚的切点才命中、返回值随之改变。
  // 「tail 从 cut 起是否含 `..`」等价于「**最后一次** `..` 出现的位置 ≥ cut」，
  // 所以只需从串尾反向扫一次求出该位置，之后每个 cut 都是 O(1) 判断。
  // 预筛只跳过必然为假的切点，不改变任何切点的判定结果与顺序，返回值与原实现逐字等价。
  let lastDotDot = -1
  for (let i = t.length - 2; i >= 0; i -= 1) {
    if (t.charCodeAt(i) === 46 && t.charCodeAt(i + 1) === 46) { lastDotDot = i; break }
  }
  for (let cut = 2; cut < t.length; cut += 1) {
    const c = t.charCodeAt(cut)
    let couldBePath = c === 47 || c === 46 || c === 126 || c === 92
    if (!couldBePath && lastDotDot >= cut) couldBePath = true
    if (!couldBePath) {
      // 盘符分支 `/^[A-Za-z]:[\\/]/`：字母 + ':' + 分隔符
      if ((c >= 65 && c <= 90) || (c >= 97 && c <= 122)) {
        if (t.charCodeAt(cut + 1) === 58) {
          const d = t.charCodeAt(cut + 2)
          couldBePath = d === 47 || d === 92
        }
      }
    }
    if (!couldBePath) continue
    const tail = t.slice(cut)
    if (looksLikeExplicitPath(tail)) return tail
  }
  return undefined
}

/**
 * 展开 `~` / `~/x` 为 home。返回：
 *   · 展开后的路径 —— 普通形态；
 *   · `null` —— 无法判定为「在已配置根之内」（`~user/…` 是他人 home；home 解析不出时 `~/x` 也无从展开）。
 *     调用方据此按「工作区外」处理，方向 fail-closed。
 */
export function expandTilde(target, home) {
  const t = String(target == null ? '' : target)
  if (tildeUserTarget(t)) return null
  if (t === '~' || t.startsWith('~/') || t.startsWith('~\\')) {
    const h = String(home == null ? '' : home)
    if (!h) return null
    return h + t.slice(1).replace(/\\/g, '/')
  }
  return t
}

/** 把 glob 目标归约到「它逃不出去的最深目录」，使 `/*` 按 `/` 判而不是按相对路径判。 */
export function globRootOf(target) {
  const t = String(target == null ? '' : target)
  const parts = t.split(/[\\/]/)
  const index = parts.findIndex((part) => /[*?]/.test(part))
  if (index < 0) return t
  const kept = parts.slice(0, index)
  if (kept.length === 0) {
    // 盘符段自身含通配（`B:*`）仍指盘根：交回盘符，而不是塌成当前目录
    const drive = /^([A-Za-z]):/.exec(parts[0] || '')
    return drive !== null ? drive[1].toUpperCase() + ':' : '.'
  }
  if (kept.length === 1 && kept[0] === '') return t.startsWith('\\') ? '\\' : '/'
  return kept.join(t.includes('\\') && !t.includes('/') ? '\\' : '/')
}

// 前导 `NAME=value` 赋值前缀的判据（**单一来源**）。两处读它：`unwrapWordsFrom` 的游标推进、
// 以及同一个循环里 `env` 自己的赋值前缀（`unwrapWords` 是 `unwrapWordsFrom` + 一次 slice，
// 故也走这一份）。两处若各写一份正则，漂移会让「命令头到哪儿」与「label 是什么」分叉，
// 方向 fail-open（与 `PRIV_PREFIXES` / `GROUP_OF_LABEL` 那几处「单一来源」是同一条纪律）。
const LEAD_ASSIGN = /^[A-Za-z_][A-Za-z0-9_]*=/

/**
 * 剥离前缀包装器与前导 `NAME=value`，使有效命令名归位。
 *
 * 不剥的后果（参考工程记录的三个真实绕过）：
 *   `env -u FOO rm -rf /`       → 有效命令名成了 flag 的值 `FOO`
 *   `timeout -s KILL 5 sudo ls` → 成了 `KILL`
 *   `BLAH=0 sudo ls`            → 成了 `blah=0`
 * 三者的提权/破坏性判定都会整个跳过。空值形态 `FOO= sudo ls` 同样要剥
 * （要求值非空会漏掉它），故 `=` 后的值部分是可选的。
 *
 * @returns {{ words: string[], opaque: boolean }} opaque 为真表示剥出来的形态读不懂
 *   （目前只有 `env -S/--split-string VALUE`：它的值是一整条命令行）。
 */
export function unwrapWords(words) {
  const arr = Array.isArray(words) ? words : []
  const r = unwrapWordsFrom(arr, 0)
  // 两个出口的契约不同，故分开处理：
  //   · opaque 出口 —— 内核已把 `words` 物化成「**剥到本层**」的视图（与逐层 slice 的原实现
  //     逐字同契约），直接交回，**不能再切**（它已经不含 `base`）。
  //   · 正常出口 —— 内核只回游标 `base`，在这里切一次。`base === 0` 时切出等长拷贝，
  //     复现原实现「开头就 `words.slice()`」的契约（返回值不与入参共享引用）。
  if (r.opaque) return { words: r.words, opaque: true }
  return { words: arr.slice(r.base), opaque: false }
}

/**
 * `unwrapWords` 的**纯下标**内核—— 全程按下标推进，不复制任何数组。
 *
 * 存在的理由：`pushHeadLabels` 的链尾要问「从下标 `i` 起这条链的命令头 label 是什么」，
 * 而它此前写 `segmentLabel(w.slice(i))` —— 切片是 O(剩余词元数)，而 `segmentLabelsCore`
 * 对**每个** `-exec` 都调一次 `headLabelAt` → `pushHeadLabels`，段内 n 个
 * `-exec sudo cmd_i {} +` 于是累计 Σ(n−j) = **O(n²)**。
 * 实测 `isDestructiveSegment`（index.js 的 buildCandidates 对每段调一次、同步早于弹窗）：
 *   n=1000 → 2.3 ms、2000 → 6.9、4000 → 84.7、**8000 → 599 ms**（倍率 2.9/12.4/7.1）；
 *   对照**无前缀**的 `-exec cmd_i {} +`（`headLabelAt` 立即 return、不切片）同规模
 *   0.6/0.9/1.8/3.7 ms（倍率 1.5/2.0/2.1，线性）—— 平方因子就是那次 `w.slice(i)`。
 * 触发形态 `find . -exec sudo … {} +` 是 AI 常写的常规写法，不是构造输入。
 *
 * ⚠️ **不是第二份剥法**：`unwrapWords` 就是本函数 + 一次 `slice`，两者共用同一份判据
 * （`LEAD_ASSIGN` / `WRAPPERS` / `WRAPPER_VALUE_FLAGS`，同一批表）。两处若各写一份
 * 「什么算前缀」，命令头与 label 必然分叉 —— 那正是本文件反复要修的那类缺陷。
 *
 * ⚠️ **本函数内不得出现任何 `slice`**（否则调用方一多就又是 O(n²)，见上）：推进一律用
 * 游标 `base`，opaque 出口直接回入参（那一支的 `words` 是死值，见 `unwrapWords`）。
 *
 * @param {string[]} current 词元列表（参数名保持 `current`：opaque 出口的返回字面形态
 *   被 `test/regressions.mjs` 的结构断言按名锁定，改名会让该断言变红）
 * @param {number} start 起点下标（`0` 时与 `unwrapWords(current)` 的剥法逐字等价）
 * @returns {{ words: string[], base: number, opaque: boolean }} `current[base …]` 才是剥完的词元；
 *   `opaque` 为真时调用方按原契约整个放弃解析（此时 `base` 无意义、`words` 是入参本身）。
 */
function unwrapWordsFrom(current, start) {
  const w = current
  let base = start > 0 ? start : 0
  // 前导 NAME=value（值可为空）。用游标推进而不是逐次 slice：后者每剥一个词元就复制一次
  // 整个数组，前缀多时是 O(k²)。实测 32000 个 `A=1` 前缀：逐次 slice 946 ms，游标写法 ~1 ms
  // —— 而它在 segmentLabel 里被逐段调用、segmentLabel 又在 assessCommand 的每段循环里跑。
  while (w.length - base > 1 && LEAD_ASSIGN.test(String(w[base]))) base += 1
  for (let depth = 0; depth < 4; depth += 1) {
    const name = commandNameOf(w[base])
    if (!WRAPPERS[name]) break
    let index = base + 1
    while (index < w.length) {
      const token = String(w[index])
      // env 自身也接受 NAME=value 形态的赋值前缀
      if (name === 'env' && LEAD_ASSIGN.test(token)) { index += 1; continue }
      if (!token.startsWith('-')) break
      // ── 两个 opaque 出口 ─────────────────────────────────────────────────────────
      // 返回的是「**剥到本层**」的词元（`current`），与原实现逐字同契约。
      // 游标版把「本层」表达为 `base`，故这里**只在确实要 opaque 返回时**把它物化一次
      // （`w.slice(base)`）——正常路径（`-exec sudo cmd` 的链尾）`w[base]` 不是 wrapper、
      // 循环直接 break，一次都不切。这是本函数不引入 O(n²) 的前提（见上面的说明）。
      // 判据 `base > 0`：`base === 0` 时 `current` 已经就是本层视图，不必复制。
      //
      // ⚠️ 下面两个 `if` 的**字面形态**被 `test/regressions.mjs:2235` 的结构断言锁定
      // （`/…return \{ words: current, opaque: true \}/`），故不能把它们合并成一个
      // `if (isOpaqueHere) return …` —— 那会让该断言变红。物化动作因此单列在上面一行。
      if (base > 0 && ((name === 'env' && (token === '-S' || token === '--split-string'))
        || (name === 'command' && (token === '-v' || token === '-V')))) current = w.slice(base)
      // `-S/--split-string` 的值是一整条命令行：本裁剪版不做拼接，直接判不可解析
      if (name === 'env' && (token === '-S' || token === '--split-string')) return { words: current, opaque: true }
      // `command -v X` / `command -V X` 是**查询** X 的位置，不执行它 ——
      // 剥掉前缀会把 X 当成命令，于是 `echo $(command -v rm)` 被判成破坏性命令（实测误报）。
      // 这不是 wrapper 语义，直接判「读不懂」：调用方会落回大分类，而不是拿 X 去做判定。
      if (name === 'command' && (token === '-v' || token === '-V')) return { words: current, opaque: true }
      // 表里没有该 wrapper 的条目时不能直接取属性 —— 会抛 TypeError。
      // 这里曾漏掉：`command`/`builtin`/`exec`/`nohup`/`setsid` 没有带值选项，
      // 于是 `WRAPPER_VALUE_FLAGS[name][token]` 对 `undefined` 取下标而崩溃。
      // 崩溃点在 tools/pre-execute 的判定链上，异常被上层 catch 后返回 deny ——
      // 后果是**该次调用被误拒**（可用性损失）。用 EMPTY_DICT 兜住
      //（不用 `{}` —— 那会退回有原型对象，见 EMPTY_DICT 的说明）。
      const valueFlags = WRAPPER_VALUE_FLAGS[name] || EMPTY_DICT
      if (valueFlags[token]) index += 1
      index += 1
    }
    // timeout 的时长位置参数（`timeout 5 sudo ls`）
    if (name === 'timeout' && /^[0-9]+(?:\.[0-9]+)?[smhd]?$/.test(String(w[index] == null ? '' : w[index]))) index += 1
    // 剥到空（`env` 单独成段）→ **保留当前游标**：原实现在这里返回的是**剥之前**那一层，
    // 故不能把 `base` 推到 `index`。判据 `index >= w.length` 与原来的 `next.length === 0`
    // 逐字等价（`next` 的长度就是 `w.length - index`）。
    if (index >= w.length) break
    base = index
  }
  return { words: current, base, opaque: false }
}

/**
 * 从段的词元提取「命令 label」（小写，路由器命令含子命令如 `git status`）：
 *   · 剥掉路径前缀与 .exe（`C:\Windows\System32\rm.exe` → `rm`；`/usr/bin/rm` → `rm`）
 *   · 剥掉前导 NAME=value 与 wrapper（见 unwrapWords）
 *   · 是 router 时继续取子命令（跳过选项与带值选项）
 *   · PowerShell 关键字（foreach/if/…）继续向后找真正的命令
 *   · 认不出（变量开头、纯表达式、空段、wrapper 形态读不懂）→ 返回 ''
 */
export function segmentLabel(words, shell) {
  return segmentLabelFrom(words, 0, shell)
}

/**
 * `segmentLabel` 的**唯一下标入口**（`segmentLabel(words)` 就是 `segmentLabelFrom(words, 0)`）。
 *
 * 存在的理由：`pushHeadLabels` 的链尾要问「从下标 `i` 起这条链的命令头 label 是
 * 什么」，而它此前写 `segmentLabel(w.slice(i))`。改成下标入口后**一次拷贝都不做** ——
 * 语义与 `segmentLabel(words.slice(start))` **逐字等价**（本函数体就是原 `segmentLabel` 的
 * 函数体，只是把内部的相对下标 `w[k]` 一律换成绝对下标 `w[base + k]`，把内部的
 * `unwrapWords(w.slice(k))` 换成 `unwrapWordsFrom(words, k)` —— 后者本来就只回游标）。
 *
 * ⚠️ 不要用 `segmentLabel(words.slice(start))` 代替它：那正是本轮要消除的那次 O(n) 拷贝。
 * ⚠️ `start` 必须落在**词元边界**上（`pushHeadLabels` 的推进步保证这一点）。
 *
 * @param {string[]} words 段词元
 * @param {number} start 命令头起点下标（0 = 与 `segmentLabel` 逐字同值）
 * @param {'pwsh'|'bash'} [shell] 方言（决定赋值判据，见 `LABEL_ASSIGN` 的说明）
 * @returns {string} label（认不出时为空串）
 */
function segmentLabelFrom(words, start, shell) {
  const sh = shellOfWords(words, shell)
  const u = unwrapWordsFrom(Array.isArray(words) ? words : [], start)
  if (u.opaque) return ''
  const w = u.words
  let idx = u.base
  if (idx >= w.length) return ''
  // ── 入口守卫：引号字符串字面量 / 纯赋值段，都不是命令 ────────────────────────
  // 判据必须落在**原始词元**上、且在 `commandNameOf` **剥路径之前** —— 后者的剥离是无条件
  // 的（取最后一个分隔符之后的部分），于是 `"--- 编码/换行校验 ---"` 的引号与
  // `$d='X:/ws/demo/_tmp/file-test'` 的 `$` `=` 都被连路径前缀一起切掉了。这类假 label
  // 会产出「允许此项」按钮，而写下的例外**永不命中**。
  //
  // ⚠️ **赋值那一条必须带方言维度**：`FOO=/usr/local/bin/myapp` 只在 **bash** 下是赋值；
  // pwsh 下它是真命令（赋值必须写 `$FOO=…`）。不分方言一刀切会让 pwsh 侧真命令的 label
  // 变空 ⇒ 段级 `unparsable` ⇒ `destructive=false` ⇒ 落大分类（fail-open）。
  //
  // ⚠️ 两条判据的位置**不同**，不能混成一条：
  //   · 引号字面量是**词元级**（`labelTokenIsQuotedLiteral`）—— 只看当前这个词元；
  //   · 赋值是**段级** —— `sudo A=/bin/rm` 的 `A=/bin/rm` 是赋值词元，但它不是命令头
  //     （命令头是 `sudo`），故不能按词元拒绝；只有整个段只有一个赋值词元时才判「认不出」。
  //     「没有任何命令要执行」只在 **bash** 成立：pwsh 下 `FOO=/…` 有命令要执行。
  if (labelTokenIsQuotedLiteral(w[idx])) return ''
  // ⚠️ pwsh 侧必须走**两侧**判据（`LABEL_ASSIGN_PWSH` 的左半 + `pwshRightIsValue` 的右半）：
  //    只看左半会把 `$A=/bin/rm` 这类**真命令**判成赋值 ⇒ label 空 ⇒ 段级 `unparsable`
  //    ⇒ `destructive=false` ⇒ 破坏性子设置与全部例外匹配双双跳过 ⇒ 落大分类（fail-open）。
  //    见 `pwshRightIsValue` 里 PS 5.1 官方解析器的实测表。
  // ⚠️ bash 侧同样**不能只看词元**：`'A=/bin/rm'`（整体引号）的词元与无引号的
  //    `A=/bin/rm` 逐字相同，而 bash 真值前者是**真命令**（实测真的执行了该路径文件、
  //    `A` 仍 unset）。故 bash 分支也必须带原文维度，见 `bashLeftIsAssign` 的实测表。
  //    ⚠️ 两个分支的判据对象**相反**（pwsh 读原文是找「引号在」，bash 读原文是找
  //    「引号不在」），故各自成函数、不得合并 —— 合并必然让其中一门方言判错。
  //    ⚠️ 两侧的判据正则也不同：pwsh 用 `LABEL_ASSIGN_PWSH`（只认 `$NAME=`），bash 用
  //    `LEAD_ASSIGN`（**不认 `$` 前缀**，见 `bashLeftIsAssign` 的缺陷 3 说明）。
  if (w.length === 1 && (sh === 'pwsh' ? pwshRightIsValue(words, w[0]) : bashLeftIsAssign(words, w[0]))) return ''
  // 前导 `-` 的**原始**词元不是命令名，是**选项**。
  //
  // 为什么单列这一条：`"--- encoding check ---"` 这类字符串不含路径分隔符，上面那条
  // 引号判据（要求「含分隔符」）**拦不住**它，于是整串成了 label、弹窗给出「允许此项」
  // 按钮 —— 而那样一条例外永不命中（同名可执行文件不存在）。
  //
  // ⚠️ 判据必须落在**原始词元**上，不能落在 `commandNameOf` 剥完的结果上：
  //     `./-foo` 剥路径后是 `-foo`，那是**合法**的可执行文件（`./` 前缀正是调用它的
  //     正确写法），不能因为剥完以 `-` 开头就拒掉；只有用户**裸写** `-…` 时，
  //     shell 才把它当选项而不是命令名。
  //
  // ⚠️ 判据还必须**同时要求不含路径分隔符**：「`-` 开头 **且含分隔符**」的
  //     `-x/rm`、`-rf/rm`、`--force/rm` 是**真实可执行的相对路径命令**（目录名以 `-`
  //     开头），不是选项。实测（无害替代目标，临时目录内）：
  //       pwsh：`-x/Remove-Item -Recurse -Force C:/Windows` → 真的执行了
  //             `-x\Remove-Item.cmd`（裸写与 `&` 两种写法都执行，rc=0）
  //       bash：`"a b/reg" delete HKLM/X /f` → 真的执行了 `a b/reg`（rc=0）；
  //             裸写 `-x/rm …` 在 bash 里会被当成自己的选项（rc=2），但**引号包裹**
  //             与「含空格的相对路径」两种写法照常执行 —— 故这一族不能整体判「认不出」。
  //     只按「以 `-` 开头」判会让这一族 label 变空 ⇒ 段级 `unparsable` ⇒
  //     `segmentLabelsCore` 的 labels 为空 ⇒ `destructive=false` ⇒ 破坏性子设置与
  //     全部例外匹配双双跳过 ⇒ 落大分类。实测（大分类 allow + 八档逐档 deny）：
  //       `-x/rm -rf /etc`、`-rf/rm -rf /`、`-x/reg delete HKLM\X /f`、`-a/taskkill`、
  //       `-a/chmod`、`-x/del`、`-x/stop-process`、`-x/format C:`、`-x/diskpart`
  //       一律 HEAD=deny → 只加 `-` 守卫时变 **allow**（bash / pwsh 两门方言、
  //       `timeout 5 …` / `A=1 …` / `sudo A=1 …` / `"-x/rm" …` 等前缀形态共 44 格）。
  //     含分隔符时交给下面的 `commandNameOf` 剥路径判定（`-x/rm` → `rm`），
  //     与 `./-foo` / `X:/-foo` / `/usr/bin/-foo` 走同一条路径。
  //
  // 方向 fail-closed：判「认不出」只是不产出候选按钮，命令照旧弹窗，不会静默放行。
  //     ——但**这一格不成立**：label 为空会连带关掉破坏性子设置（见上），
  //     故判据必须收窄到「裸选项」，不能覆盖真实可执行的相对路径命令。
  const rawHead = String(w[idx])
  if (/^-/.test(rawHead) && !/[\\/]/.test(rawHead)) return ''
  let head = commandNameOf(w[idx])
  if (!head || BAD_LABEL_CHARS.test(head)) return ''
  // 语句关键字：向后找真正的命令。**必须循环**，因为跳过一个关键字后遇到的可能是
  //   ① 又一个关键字（`case x in a) rm …` 的 `in` 也是关键字）；
  //   ② 一个 wrapper（`then nohup rm …` 的 `nohup` —— 它在关键字之后，unwrapWords 没机会剥它，
  //      因为 unwrapWords 只看词元序列的**开头**，而开头是 `then`）。
  // 曾经这里只扫一趟、取第一个非关键字词元就收工，于是上面两种形态的 label 分别是
  // `x` / `nohup` —— 破坏性子设置整个跳过（实测：`rm -rf ~/.dsh` 是 deny，
  // 而 `case x in a) rm -rf ~/.dsh;; esac` 与 `if true; then nohup rm -rf ~/.dsh; fi` 是 allow）。
  // 循环上限 8：关键字与 wrapper 不会嵌套那么深，纯粹防病态输入下打转。
  for (let guard = 0; guard < 8; guard += 1) {
    if (!STATEMENT_KEYWORDS[head]) break
    { let nx = idx + 1; try { const s = skipPrefixArgs(w, idx + 1, head); if (s > nx) nx = s } catch (e) {} if (nx > idx + 1) { idx = nx - 1; head = commandNameOf(w[idx]) } }
    let found = -1
    for (let j = idx + 1; j < w.length; j++) {
      const t = commandNameOf(w[j])
      if (!t || BAD_LABEL_CHARS.test(t)) continue
      // 关键字继续跳过（`case x in` 的 `in`、`for i in` 的 `in`）
      //
      // ── ⚠️ 但「继续跳过」**必须同时跨过该关键字自身的选项**──────────
      // 上面 `:775` 那一轮已经用 `skipPrefixArgs` 跨过**段首关键字**的选项，而本分支此前
      // 只写 `idx = j` —— 于是**第 2 轮起** `head` 由内层 `found` 循环重新赋值时**不再**跨过
      // 新关键字的选项：`! time -p rm -rf ~/.dsh` 的 `-p` 占掉下一轮的位置，
      // `segmentLabelFrom` 返回 **`'-p'`**（既不是命令名、也不在破坏性名单里）
      // ⇒ `isDestructiveSegment = false` ⇒ 破坏性子设置整个跳过、半径档与组档全丢。
      //
      // 方向 **fail-open**，且是「只修了段首那一轮」造成的**同族分叉**：实测
      // （`category=allow` + destructive 八档全 deny）：
      //     time -p rm -rf ~/.dsh                 → **deny** ✅（走段首那一轮）
      //     ! time -p rm -rf ~/.dsh               → **allow** ❌
      //     then time -p … / if true; then … / while … do … / until … / for …  → **allow** ❌
      // 判据族其余成员对同形态**都正确**（`['!','time','-p','rm','-rf','/tmp']`：
      // `headFull=4`、`headCommandNameOf='rm'`、`hasNoOperand=false`）⇒ 只有本函数未对齐。
      //
      // ⚠️ 落点**必须是内层 `j`**（不是 `idx`）：本循环的推进量由 `j` 决定，
      // 写 `idx = nx - 1` 只改一个马上会被 `found` 覆盖的变量，**实测无效**。
      // 判据复用 `skipPrefixArgs` **单点** —— 与 `:775`（段首那一轮）、
      // `commandHeadEndFull` 的关键字分支、`pushHeadLabels` 同源，四处不各写一份
      // 「什么算关键字自己的选项」。O(1)、无正则、无分配。
      if (STATEMENT_KEYWORDS[t]) {
        let nx = j + 1
        try { const s = skipPrefixArgs(w, j + 1, t); if (s > nx) nx = s } catch (e) {}
        j = nx - 1
        continue
      }
      found = j
      break
    }
    if (found < 0) return ''
    idx = found
    head = commandNameOf(w[idx])
    // 关键字之后可能是 wrapper（`then nohup rm …`）：就地剥掉它及其选项/带值选项，
    // 否则 label 会停在 wrapper 上。复用同一份剥法（`unwrapWordsFrom`）保证与主路径一致。
    //
    // 下标版：原写法 `unwrapWords(w.slice(idx))` 的返回值长度是 `w.length - rest.base`，
    // 故原来的 `advance = w.length - idx - rest.words.length` 恰好等于 `rest.base - idx` ——
    // 直接取 `rest.base` 即可，省掉那次 O(剩余词元数) 的切片。
    const rest = unwrapWordsFrom(w, idx)
    if (!rest.opaque && rest.base < w.length && commandNameOf(w[rest.base]) !== head) {
      idx = rest.base
      head = commandNameOf(w[idx])
    }
  }
  if (!ROUTER_CMDS[head]) return head
  // 路由器命令：跳过选项（含带值选项的值），取第一个非选项词元作子命令。
  // 子命令位不做关键字过滤 —— 子命令属于路由器自己的词汇表（`git switch` 是真子命令）。
  for (let j = idx + 1; j < w.length; j++) {
    const raw = String(w[j])
    if (raw.startsWith('-')) {
      if (ROUTER_OPT_VALUE[raw]) j++
      continue
    }
    const sub = commandNameOf(raw)
    if (!sub || BAD_LABEL_CHARS.test(sub)) continue
    return head + ' ' + sub
  }
  return head
}

// find 的「执行动作」选项：其后的词元才是真正被执行的命令，而 label 恒为 `find`。
// 不展开它们的后果与「前缀包装器」完全同类（§ 见 WRAPPERS 的注释）：有效命令名判错，
// 破坏性判定整个跳过。实测（大分类 allow + 子设置 deny）：
//   `rm -rf ~/.dsh` → deny，而 `find . -exec rm -rf {} +` / `find . -delete` → allow。
const FIND_EXEC_FLAGS = dict({ '-exec': 1, '-execdir': 1, '-ok': 1, '-okdir': 1 })
// `-delete` 本身就是破坏性动作，没有后续命令可看，直接给一个命中名单的合成 label。
const FIND_DELETE_FLAG = '-delete'

/**
 * 从下标 `start` 起，**跳过整条前缀链**，取出命令头位置上的命令名（单个 label）。
 *
 * 判据与 `pushHeadLabels` 的推进循环**逐字同源**（同一张转移表：语句关键字 → wrapper →
 * 提权前缀，各自用 `skipPrefixArgs` / `privOperandSkip` 跳过选项与操作数），
 * 只做**纯下标推进 + 链尾一次 `segmentLabel`**，故是 O(链长) 而不是 O(剩余词元数)²。
 *
 * 存在的理由：`segmentLabelsCore` 的 `find -exec` 载荷族此前只取 `-exec` 之后
 * 的第一个词元，于是载荷里的提权前缀被当成命令名收下、真命令名永不进 labels ——
 * `find . -exec sudo kill {} ;` 的 tiers 只剩 `['priv']`、动作 allow。
 * 修法就是复用主路径那套推进，而不是在这里另写一份「什么算前缀」。
 *
 * ⚠️ 与 `pushHeadLabels` 的分工：那个负责**链上每一层的名字**都进 labels（收紧方向），
 * 这个只回答「链尾的命令名是谁」—— `-exec` 载荷族的既有口径就是**单个单词** label
 * （见 `test/shell-parse.mjs` 的 54s：「`reg delete` 不在语料里，该分支合成的是单词 label」）。
 * 故本函数在把链尾 label 追加进 `out` 时**取首词**（`reg delete` → `reg`），与修复前的
 * 「取第一个词元」在粒度上逐字一致 —— 本修法只该修「前缀链不推进」，不得顺手改粒度。
 *
 * @param {string[]} w 词元列表（完整段词元，下标以它为基准）
 * @param {number} start 载荷起点（`-exec` 之后、已剥掉 wrapper 与赋值前缀的位置）
 * @param {Function} addWidened `widened` 的 O(1) 写入单点
 * @param {Function} addLabel `out` 的 O(1) 写入单点
 * @param {string} headPrefix **本段命令头的提权前缀名**（空串 = 命令头不带提权前缀）。
 *   只用于「载荷链首那一层是否该进 `widened`」—— 同名时不进，见 `pushHeadLabels` 的说明。
 * @returns {void} 无返回值（此前声明 `{string}` 并返回「命令头位置上的**单词** label」，
 *   但**两个调用点都是语句位置裸调用、结果被丢弃**，且该函数**未导出** —— 全文件没有任何
 *   消费方，属死返回值。删除它同时去掉了 `:918` 那次 `String(head).split(' ')[0]` 的分配。）
 *   ⚠️ `widened` 的登记是**本函数内部的副作用**（`pushHeadLabels` 对链上每一层扩展名
 *   都会调 `widen`）—— 调用方**不需要**再补一遍，实测补的那一遍是死代码（见
 *   `segmentLabelsCore` 里 `-exec` 分支的说明）。
 *   ⚠️ 形参 `out` / `widened` 已删（第 8 圈删掉两条兜底后，它们在本函数体内**只剩签名行
 *   一处**——`out` / `widened` 的写入全部经 `addLabel` / `addWidened` 单点）。详见
 *   `pushHeadLabels` 的说明。
 */
function headLabelAt(w, start, addWidened, addLabel, headPrefix, shell) {
  // ── 复用 `pushHeadLabels`（**不另写一份前缀链推进**）────────────────────────────────
  // 这正是发现 1 的修法：载荷族的命令名提取必须与主路径**同源**，否则「命令头到哪儿」
  // 与「labels 有哪些」必然再次分叉。`pushHeadLabels` 的语义恰好两件事都做：
  //   · 把 `w[start]` 的名字 push 进 `out`（与修复前「取第一个词元」逐字一致）；
  //   · 若是提权前缀则**循环推进**，链上每一层的名字都进 `out` / `widened`，
  //     最后返回命令头 label。
  //
  // ⚠️ 前缀名**必须也进 labels**（不是只取链尾那个名字）：`priv` 组是**半径组**，
  // `tierSetOf` 的 ① 分支靠 `GROUP_OF_LABEL` 里有没有 priv 组成员来决定「要不要并半径档」
  // （`hasPrivGroup && seg.blast`）。只取链尾名字时 `find . -exec sudo kill {} ;` 的 labels
  // 是 `['find','kill']`（无 priv 组成员）→ **不并半径档** → 档集 `['proc','priv']`，
  // 而对照 `sudo find . -exec kill {} ;` 是 `['sudo','find','kill']` → 并半径档
  // → `['outside','proc','priv']`。实测两者**不同值**，正是本函数要避免的分叉。
  // ── 链尾 label 的**单词化**由 `pushHeadLabels` 单点完成──────────────
  // `pushHeadLabels` 的链尾走 `segmentLabel`，对路由器命令会给**两词** label
  // （`sudo reg delete …` → `reg delete`），而载荷族的既有口径是**单词** label
  // （54s 原文：`find . -exec reg delete …` 只得 `reg`）。故写入时统一取**首词**：
  // 链上**前缀名**（`sudo` / `su`）本来就是单词，取首词对它们无影响；两词 label 只有
  // 路由器命令会产生，取首词正是修复前的粒度。判据用词法（有没有空格）而非名单。
  // ⚠️ 首词化由 `pushHeadLabels` 的第 7 个形参 `headWordOnly` 在**返回之前**完成
  // （见那里的 `:1265`）—— 本函数**不再**参与首词化，也**不把结果交回调用方**（无返回值）。
  //
  // ⚠️ **首词化必须发生在 `out` 与 `widened` 的同一个写入点上**：此前只有
  // `addLabel` 被包了一层首词化、`addWidened` 没有，于是 `labels=['find','sudo','git']`
  // 而 `widened=['git status']` —— 授权面（`assessCommand` 的
  // `labels.filter(l => !widenedSet.has(l))`）里 `git` **不在** `widenedSet` 中，存活下来
  // 被用户为普通 `git` 写下的 `git *`=allow 命中。实测（例外 `<router> *`=allow、其余 ask）：
  //     find . -exec sudo git status {} ;           → **allow**
  //     find . -exec sudo git push --force {} ;     → **allow**
  //     find . -exec sudo reg delete HKLM\X /f {} ; → **allow**
  //     find . -execdir sudo reg delete … ;         → **allow**
  //     find . -exec sudo docker rm -f x {} ;       → **allow**
  //     find . -exec sudo su root reg delete … ;    → **allow**
  // 而主路径 `sudo git status` 是 ask —— 同一条前缀语义两个结论（不变量分叉）。
  // 对照：单词 label（`rm` / `kill` / `shutdown` / `wmic`）两处形态天然一致，故 54z 的语料
  // **结构性照不出**这一格（这正是它漏网的原因）。
  // 修法是让 `widened` 与 `labels` 走**同一份首词化** —— 即由 `pushHeadLabels` 的
  // `headWordOnly` 在**返回之前**截断，两个写入点拿到的就是同一个已截断的值。
  // 第 7 个参数 `headWordOnly = true`：载荷族只要链尾 label 的**首词**；它同时使链尾走
  // 纯下标版（不复制后缀），那是本轮 F2 的 O(n²) 修法。
  // 第 8 个参数 `headPrefix`：**本段命令头的提权前缀名**（`sudo` / `doas` / …；段首无提权
  // 前缀时为空串）。它只影响**载荷链首那一层**是否进 `widened` —— 见 `pushHeadLabels` 里的说明。
  const PH = (t) => t === '{}' || t === ';' || t === '+'
  // ── 跳过载荷首部的**占位符**，但判据必须按**词元原文**而非「是不是占位符」──────────────
  // 原写法 `while (st < w.length && PH(commandNameOf(w[st]))) st += 1` 只在**认出占位符**时
  // 前进；而 `commandNameOf` 对**空 basename 词元**（`/`、`./`、`../`、`bin/`、`C:/`、`~/`、
  // `$X/`、`//`、`.exe`、`x.exe/` …）返回**空串**，`PH('')` 为假 → 循环**立即停下** →
  // `pushHeadLabels` 的 `if (!first) return ''` 提前返回 → **整个 `-exec` 载荷族 label 合成
  // 被放弃**（fail-open）。实测（HEAD 用 `continue` 继续向后扫，不受影响）：
  //     `find . -exec / rm -rf / {} +`  HEAD labels=['find','rm']/destructive=true
  //                                     CUR  labels=['find']/destructive=false
  // 语料 = 10 个空 basename 词元 × 4 flag × 6 载荷 × 4 tail = 960 格，**960 格全差异**。
  // 修法 = 按词元原文跳过：「空 basename」与「占位符」都**不是命令名**，都该继续向后扫；
  // 只有「认得出且不是占位符」才停。空串与占位符都进不了 `labels`（既有口径不变），
  // 而 54s 的单词粒度（`-exec reg delete …` → `['find','reg']`）与 F82b 的「占位符不进
  // labels」两条口径也都保住（占位符仍走 `st += 1` 跳过，不会被 `pushHeadLabels` 写进 `out`）。
  // 收敛性：每轮至少前进一个下标，`st >= w.length` 时照旧返回 ''（整段都是占位符/空 basename）。
  let st = start
  // `cn` 顺带留住在**有效命令名**上的那次取值，供下面的畸形名守卫复用（零额外调用）。
  let cn = ''
  while (st < w.length) { cn = commandNameOf(w[st]); if (!PH(cn) && cn) break; st += 1 }
  if (st >= w.length) return ''
  // ── ⚠️ 畸形命令名的守卫**必须前移到写入之前**（HEAD 的 `break` 语义）────────────────────
  // 下面 `:952` 那句 `if (BAD_LABEL_CHARS.test(head)) return ''` **拦不住写入**：它只阻止
  // **返回** `head`，而 `pushHeadLabels` 的 `push(first)`（`:1064`）早于它执行 —— 畸形名已经
  // 落进 `out`（= labels），回滚不了。于是载荷首词元含 `=`/`*`/`?`/`$`/`%`/`&` 等字符时，
  // **畸形名被当成命令名写进 labels**，方向是 **fail-open**。
  //
  // HEAD 的两条 `-exec` 分支都在 push **之前** `break`（`git show HEAD:shell-parse.js` 的
  // `:605` / `:617`：`const cand = commandNameOf(w[k])` → `if (BAD_LABEL_CHARS.test(cand)) break`
  // → `out.push(cand)`），故 HEAD **从不**把畸形名写进 labels。本条是 HEAD 与实现之间的
  // 新分叉（不是「`}` 闭合花括号族」那种语法非法形态，那族三基线同值）。
  //
  // 实测（14 畸形名 × 4 flag × 3 载荷 × 2 tail = 336 格，与 HEAD 逐字对拍）：
  //     `find . -exec a-b=c rm -rf / {} +`   HEAD labels=['find']  分叉前 labels=['find','a-b=c']
  //     `find . -exec x*y kill 1234 {} +`    HEAD labels=['find']  分叉前 labels=['find','x*y']
  // 336 格中 **216 格 labels 分叉**（9 个走快路径的畸形名 × 4 × 3 × 2；`a&b`/`a|b`/`a<b`/`a>b`
  // 被词法器分段、`a=b=c` 走慢路径被 `unwrapWordsFrom` 当赋值前缀剥掉，这 5 个本就与 HEAD 同值）。
  // 端到端同 216 格由 HEAD=ask 变 allow（例外 `a*`=allow 时 `matchCommand('a*','a-b=c')` 为 true，
  // 整段被这条**宽泛**例外命中）。
  //
  // ⚠️ 判据必须是**写进 `out` 的那个名字**（即 `commandNameOf(w[st])`，与 `pushHeadLabels` 的
  // `first` 逐字同值），且必须落在 `pushHeadLabels` **之前** —— 放在它之后（无论判 `head` 还是
  // 判 `cn`）都只能阻止返回值，堵不住已经写进 `out` 的畸形名。
  // ⚠️ 用循环里已算出的 `cn`，不重算 `commandNameOf`：判据仍是「查表 + `indexOf`」形态，
  // 复用既有正则常量 `BAD_LABEL_CHARS`，无新分配、无正则构造（O(1) 性能纪律）。
  // ⚠️ 方向是**收紧**：只让载荷族少写一个畸形名，主路径（`segmentLabelsCore` 的调用点）不经
  // 本函数，故 `segmentLabel` / `commandHeadEnd` 的既有行为逐字不变。
  if (BAD_LABEL_CHARS.test(cn)) return ''
  const head = pushHeadLabels(w, st, addWidened, addLabel, true, headPrefix, shell)
  if (!head || PH(head)) return ''
  // 兜底：链尾 label（可能被 `headWordOnly` 截断，也可能是 `pushHeadLabels` 推进后才认出的名字）
  // 同样不得是畸形名 —— 与 HEAD 的 `break` 语义对齐，也与上面那道前置守卫同源。
  if (BAD_LABEL_CHARS.test(head)) return ''
  // ── 链尾那个名字**必须补登记进 `widened`**（判据 = **本段命令头带提权前缀**）──────────
  // `pushHeadLabels` 的 `widen` 只覆盖**链上每一层前缀名**（`sudo` / `su`），**不含链尾**：
  // 它的写法是「推进到链尾后返回 label」，链尾 label 由调用方 `segmentLabelsCore` 的主路径
  // 那一支单独 `widen(head)`。载荷族此前没有这一步 —— 实测：
  //     `sudo find / -exec rm -rf {} +`  → widened=['find']（`rm` 缺席）❌
  //     `find . -exec sudo rm -rf {} +`  → widened=['rm'] ✅（起点是前缀，链尾 `rm` 被补上）
  // 缺了它的后果是**授权方向被放宽**：例外 `rm *`=allow 时 `sudo find / -exec rm -rf {} +`
  // 由 **ask → allow**（54u 正钉这条，实测本修法第一版把它弄红了）。
  //
  // ⚠️ 判据**不是**「链尾名字与载荷首层那个名字是否相同」（那样 `sudo find / -exec rm`
  // 的起点 `rm` 就不补了，而它恰恰是被放宽的那一格）。正确判据是**本段命令头带提权前缀**
  // （`synthWidened`，即段首/命令头是提权前缀）—— 与 `-delete` 那一支**同一条判据**，
  // 两处口径一致：
  //     `find . -exec rm -rf {} +`      → 无前缀 → 不补（`rm` 可被 `rm *`=allow 授权，HEAD 亦然）✅
  //     `sudo find / -exec rm -rf {} +` → 有前缀 → 补（不得被 `rm *`=allow 授权）✅
  //
  // ── ⚠️ 登记的值必须是**实际写进 `out` 的那个形态**，不是它的首词 ─────────────
  // 若登记首词而 `out` 拿原值（`reg delete` vs `reg`），授权面里 `reg delete` 就不在
  // `widenedSet` 中，被用户为普通 `reg` 写下的 `reg *`=allow 命中（例外 `<首词> *`=allow 时
  // 整族由 ask 变 allow）。修法：登记 `head` 本身 —— `pushHeadLabels` 的返回值恒等于它写进
  // `out` 的那个形态，于是两个集合不可能再分叉，`widened ⊆ labels` 恒成立。
  //
  // 修法：**登记 `head` 本身**（`pushHeadLabels` 的返回值恒等于它写进 `out` 的那个形态 ——
  // 早退三处返回的都是 `push` 过的 `first`，链尾那一支返回的是已按 `headWordOnly` 截断、
  // 且同样 `push` 过的 `head`），于是两个集合不可能再分叉，`widened ⊆ labels` 恒成立。
  // ⚠️ **不得**改成「把首词化下沉到 `:954` 的写点」（即让 `out` 也拿首词）—— 那样
  // `out` 里的 `reg delete` 会退化成 `reg`，而 `reg delete`（不是 `reg`）才是
  // `DESTRUCTIVE_LABELS` 的成员与 `GROUP_OF_LABEL` 的键：实测 `find . -exec "reg delete" HKLM\X /f {} ;`
  // 的 `destructive` 由 true 变 **false**、`reg` 档整体丢失，`reg`=deny + 大分类 allow 时
  // 由 ask 变 **allow**（方向是放宽，比本缺陷更糟）。
  //
  // ── ⚠️ 还必须排除「**同名**」那一格（与链首那一支 `:1063` 同一条判据，本轮 F5）───────────
  // 上面那段判据「本段命令头带提权前缀」对**链尾**来说**不够**：链尾**认不出**时
  // （`head === first`，即 `-exec <前缀名> {} ;` / `;` / `+` 这一族 —— 载荷里只有前缀名、
  // 没有命令名）`pushHeadLabels` 的 `:1238` 会 `return first`，于是这里拿到的 `head`
  // **恒等于载荷首层那个前缀名**。当它与命令头前缀**同名**时（`env sudo find . -exec sudo {} ;`），
  // `addWidened(head)` 挪出授权面的其实是**命令头那个名字** —— 正是 `:1054-1062` 断言
  // 「必须排除、否则过度收紧」的那一格，而该断言当时只落到了 `:1063` 这一支。
  // 实测（例外 `sudo *`=allow、其余 ask，修复前）：
  //     env sudo find . -exec sudo {} ;          HEAD=allow  **ask**   widened=['find','sudo']
  //     env sudo find . -exec sudo ;             HEAD=allow  **ask**
  //     env sudo find . -exec sudo {} +          HEAD=allow  **ask**
  //     timeout 5 sudo find . -exec sudo {} ;    HEAD=allow  **ask**
  //     time sudo find . -exec sudo {} ;         HEAD=allow  **ask**
  //     env doas find . -exec doas {} ;          HEAD=allow  **ask**
  // 而**同一条前缀语义**的主路径 `env sudo sudo rm -rf /etc` / `env sudo sudo` 是 allow
  // —— 同一条前缀语义两个结论（不变量分叉），方向是**过度收紧**（非 fail-open）。
  // 覆盖面：4 flag × 6 载荷前缀 × 10 外层前缀 × 7 tail = 240 格中 144 格过度收紧
  // （按 inner：sudo 72 / doas 48 / pkexec 24；按 tail 均匀分布 24×6；与主路径分叉 144 格）。
  //
  // 同名时**保持既有行为**：授权面里那个名字是命令头前缀本身，用户写 `sudo *`=allow
  // 正是要授权它（HEAD / PRE 亦然）。`widened` 按**名字**判定，同名时两个来源不可区分，
  // 故这一格不能收紧 —— 与 `:1063` 对链首那一层的处置**逐字同源**。
  // 判据因此与 `:1063` 对齐：「命令头**有**提权前缀」且「链尾名字与它**不同名**」。
  if (head && headPrefix && head !== headPrefix) addWidened(head)
  // ⚠️ 此处**没有返回值**：链尾 label 的**首词化**由 `pushHeadLabels` 的 `headWordOnly`
  // 在它返回之前单点完成（两个写入点拿到的就是同一个已截断的值，见上面的说明）。
  // 曾经这里 `return String(head).split(' ')[0]`，而两个调用点都是语句位置裸调用、
  // 结果被丢弃 —— 死返回值，已删。
}

/**
 * @param {string[]} w 词元列表（完整段词元，下标以它为基准）
 * @param {number} start 载荷起点（`-exec` 之后、已剥掉 wrapper 与赋值前缀的位置）
 * @param {Function} addWidened `widened` 的 O(1) 写入单点
 * @param {Function} addLabel `out` 的 O(1) 写入单点
 * @param {boolean} [headWordOnly] 载荷族才传 `true`（链尾 label 取首词），见函数体说明。
 * @param {string} [headPrefix] **本段命令头的提权前缀名**（`sudo` / `doas` / …；命令头不带提权
 *   前缀时为空串）。载荷族由 `headLabelAt` 透传；主路径 `segmentLabelsCore` 的调用点**不传**，
 *   故为 `undefined`。它只放宽一件事：载荷链首那一层名字是否也进 `widened` ——
 *   见函数体内发现 1 的说明。
 *   ⚠️ 主路径不传是**刻意**的：`sudo rm -rf /etc` 必须继续被 `sudo *`=allow 授权
 *   （既有行为，54c2 的对照就钉在这一点上）。
 *
 * ⚠️ 形参 `out` / `widened` 已删────────────────────────
 * 那两个形参在本函数体内**唯一的消费者**是「缺省时退化成按数组查重」的三元兜底
 * （`out.indexOf(x)` / `widened.indexOf(x)`）。第 8 圈把两条兜底都删了（改为直接
 * `const widen = addWidened` / `const push = addLabel`），而签名与 4 个调用点仍原样传参 ——
 * 属「第 8 圈修了一半」：删掉兜底却没删形参，于是 `out` / `widened` 在本函数体内
 * **一次都不再被读**（实测 CODE 命中数 = 1，就是签名行本身；`headLabelAt` 是 2 = 签名 +
 * 转发调用），而调用点仍在计算并传入它们。
 * 删掉是**零行为变更**：本函数未导出、无 `arguments` / `.apply(` / `.call(`（全 0，
 * 无动态逃逸），4 个调用点的实参恒为 function（见下），故形参位与实参位的对应关系不变。
 */
function pushHeadLabels(w, start, addWidened, addLabel, headWordOnly, headPrefix, shell) {
  // `addWidened` = `segmentLabelsCore` 的 O(1) 写入单点（同时维护 `widened` 数组与其并行
  // `Set`，见那里的发现 2 说明）。**直接当函数用**：本函数未导出、独立调用方为零，
  // 四个调用点（`:948` / `:1445` / `:1581` / `:1597`）的实参恒为 function。
  // 曾经这里有一条「缺省时退化成按数组查重」的三元兜底，而它**在全部三套件里一次都没
  // 执行过**（V8 coverage：`pushHeadLabels` 本体 count=844445、兜底函数体 count=0）——
  // 删掉它反而 **fail-fast**：漏传实参时立刻 `TypeError`，而不是静默退化到本批刚消除的
  // O(len) `indexOf` 路径。
  const widen = addWidened
  // `out` 的写入同样必须走 O(1) 单点—— 理由同上，同样是删兜底。
  // `out.indexOf(x)` 是 O(len)，而**载荷族对每个 `-exec` 都调一次本函数**
  // （`find . (-exec sudo c_i {} +)×n`）—— 逐条不同名时就是 O(n²)。
  // 实测（`sudo find . (-exec sudo cmd_i {} +)×n`、`segmentLabels` 单次）：
  // n=4000 → 6.64 ms、**8000 → 23.83 ms**（倍率 3.59，标准平方），
  // 而同名形态 n=8000 仅 2.26 ms（线性）。故与 `widened` 同处置：由调用方传 O(1) 写入单点。
  const push = addLabel
  const first = commandNameOf(w[start])
  if (!first) return ''
  // ⚠️ `push(first)` 写的是**未截断**的 `commandNameOf(w[start])`——
  // 当 `w[start]` 本身含空格（引号包住的多词词元，如 `-exec "reg delete" …`）时它是两词。
  // **不得**在这里补一层首词化：`out` 是破坏性判定与组档的判据（`reg delete` 在
  // `DESTRUCTIVE_LABELS` 里、是 `GROUP_OF_LABEL` 的键），截成 `reg` 会让
  // `find . -exec "reg delete" HKLM\X /f {} ;` 的 `destructive` 由 true 变 **false**
  // （实测：`reg=deny` + 大分类 allow 时由 ask 变 **allow**）—— 那是把漏判换成放宽。
  // 两个集合的**形态一致**由 `headLabelAt` 在 `widened` 那一侧对齐（见那里的说明）。
  push(first)
  // ── ⚠️ **链首那一层也必须进 `widened`** ───────────────────────────────────
  // 下面 `if (cur !== first) { push(cur); widen(cur) }` 把链上第一层排除在 `widen` 之外 ——
  // 那对主路径是对的（`sudo rm -rf /etc` 的 `sudo` 就是段首前缀，`sudo *`=allow 要授权它），
  // 但载荷族的 `w[start]` 是 `-exec` 之后的载荷首词元，不是段首。载荷首词元恰是提权前缀名、
  // 而段首是另一个提权前缀时，该名字只进 `out` 不进 `widened` → 留在授权面 → 被用户为
  // 普通该前缀写下的 `<前缀名> *`=allow 命中（`sudo find . -exec doas rm -rf /etc {} ;` 变 allow）。
  // 判据必须是显式的 `headPrefix`（命令头那个提权前缀叫什么名字），不能用局部条件区分。
  // 主路径的调用点刻意不传这个参数，故 `sudo rm -rf /etc` 的既有行为逐字不变。
  //
  // ⚠️ 还必须排除「同名」那一格（`first === headPrefix`）：`widened` 按名字判定，
  // 命令头那个前缀名本来就该留在授权面里，同名时 `widen(first)` 会把命令头那个名字一并
  // 挪出授权面 —— 过度收紧（`env sudo find . -exec sudo rm -rf /etc {} ;` 由 allow 变 ask）。
  // 同名时放宽本来就不存在：两者在 `widened` 里是同一个字符串，无法区分。
  if (headPrefix && first !== headPrefix && PRIV_PREFIXES[first] === 1) widen(first)
  if (PRIV_PREFIXES[first] !== 1) return first
  // 命令头推进下标：从段首（或语句关键字之后）的提权前缀开始。
  let i = start
  // ── 推进必须**循环**，不能只做一层 ──────────────────────────────────────────
  // 一层提权前缀之后可能又是一层（`sudo su root kill 1234`、`sudo doas kill 1234`）。
  // 单步推进时 `privOperandSkip` 停在第二个前缀名上、`segmentLabel` 把它当作命令头 label
  // 返回，labels 收束成前缀名 —— 组档（proc / power / reg）整体丢失、用户显式写的
  // `kill *`=deny 例外同样被绕过。方向是 fail-open。故复用同一批推进步
  // （`skipPrefixArgs` + `privOperandSkip`）循环推进到真命令名。
  //
  // 收敛性：每轮至少推进一个词元，故 `guard <= w.length` 不可能漏判。
  //
  // ── ⚠️ 每轮**不得**调 `segmentLabel`（那是 O(剩余词元数) 的切片，链长 n 时整体 O(n²)）──
  // 循环内只做 O(1) 判据：`commandNameOf(w[i])` 查 `PRIV_PREFIXES`；命令头 label 只在链尾
  // 取一次 `segmentLabel`。该函数在 `segmentLabels` 热路径上，会被逐段调用、同步早于弹窗。
  for (let guard = 0; guard <= w.length && i < w.length; guard += 1) {
    const cur = commandNameOf(w[i])
    // ── 推进判据：**提权前缀与 wrapper 都要继续** ──────────────────────────────
    // 只认 `PRIV_PREFIXES` 时，夹在两层提权前缀之间的 wrapper 会让链提前截断 → 真命令名
    // 永不进 labels → 组档（proc / power / reg）整体丢失、用户写的 deny 例外同样被绕过。
    // 方向是 fail-open。判档侧（`commandHeadEnd` 的 ① 分支）本来就把 wrapper 与提权前缀
    // 同处置，故这是「label 侧与判档侧各持一份口径」的分叉，修法是让两侧同源。
    //
    // ⚠️ 边界：`time` 是语句关键字（不在 WRAPPERS 里）、`timeout` 的时长位置参数由
    // `skipPrefixArgs` 自己处理，两者都要覆盖。
    //
    // ⚠️ 性能纪律：不得在循环内调 `segmentLabel`。本判据只有 `commandNameOf` + 两次查表，
    // 全是 O(1)，命令头 label 仍只在链尾取一次。
    // ── 前导 `NAME=value`：**不是**命令名，跳过后继续（E2 判据族第 7 个成员）────────────
    // 上面那个 break 判据只认三类（提权前缀 / wrapper / 语句关键字），而赋值词元三类都
    // 不是 ⇒ 循环**立即 break**、前缀链被截断、真命令名永不进 labels。
    // 触发形态是「**两层前缀之间**夹赋值」：`i=0` 的 `sudo` 把链推进到 `i=1`，循环第二轮
    // 就在 break 判据上撞到 `FOO=1`。两个兄弟函数的同源推进循环**都有这一支**
    // （`commandHeadEndFull:2874`、`headCommandNameOf:4124`）—— 本处是漏掉的第三个。
    // 实测（win32，八档同动作、proc/power/reg=deny、priv=allow，修复前）：
    //     sudo su root kill 1234        → deny  labels=['sudo','su','kill'] tiers=['proc','priv']
    //     sudo FOO=1 su root kill 1234  → **allow** labels=['sudo','su']  tiers=['priv'] ← 组档整族丢失
    // 且**不需要 `priv=allow`**：`index.js` 的真实档位缺省值
    // （八档一律「项目显式 → 全局显式 → ask」，见 destructiveTiers）+ 一条常规 deny 例外下
    // 就已分叉 —— 例外 `kill *`=deny 时
    // 本形态是 **ask**、对照是 **deny**；`diskpart*`=deny 同理 ⇒ 用户写的 deny 例外
    // 被「多写一个 `FOO=1`」降级。方向是 **fail-open**。
    //
    // ⚠️ 与已定案的赋值族**不重叠**：`ignored.md:122` / `design-issues.md` I4 / 测试 60j2
    // 记的是**单个前缀之后**夹赋值（走 label 侧 / `privOperandSkip` 操作数路径）；本条是
    // **第二层前缀之前**夹赋值、落在**链推进循环**上。实测 60j2 那六条**无第二层前缀**
    // （4 条 labels `[]`、2 条 `['su']`/`['runas']`）⇒ 两族不同源。
    //
    // ⚠️ 本行**必须放在 break 判据之前**：放在之后完全无效（labels 仍 `['sudo','su']`）——
    // 那时 `cur` 已经是赋值词元、break 先命中。
    //
    // ── ⚠️ 守卫 `i + 1 < w.length`：赋值词元**恰在链尾**时必须放行─────────────
    // 少了这个守卫，`<前缀链> <尾随赋值词元>`（`sudo A=/bin/rm`、`su A=/bin/rm`、
    // `sudo timeout 5 PATH=/usr/bin/rm` …）会跨过**最后一个**词元：循环因 `i >= w.length`
    // 退出、链尾那次 `segmentLabelFrom` 落空 ⇒ `return first` ⇒ 第二个 label **整体丢掉**。
    // 实测（`derived allow` + 例外 `rm *`=deny）：`sudo A=/bin/rm` 无守卫是
    // **`ask`/`['priv']`**（PRE 是 `deny`/`['inside','priv']`）；再加 `priv=allow` 时
    // 更从 PRE 的 `deny` 变成 **`allow`**。
    // 面（本处**自测**，对拍 PRE 基线 `9D3800EF…`）：52,908 格语料（4,409 条 × 12 配置）
    // 中动作放宽 **1,653** 格、档位移除 **9,648** 格、收紧 48 格 —— 且放宽格
    // **1,653/1,653 全部**满足「赋值词元是最后一个词元」（0 格例外）。
    // （上一轮验证者另用 4 元组全枚举报出 labels 收缩 57,228 / 档位移除 224,280 /
    // 动作放宽 68,724 格，同一族、方向一致；两组数字口径不同，不可混用。）
    //
    // ⚠️ **口径更正（不得再写「只收紧」）**：上一条 F1 报告里的
    // 「loosen 0 / tierRemoved 0 / labels 只增不减（CUR ⊄ FIX = 0）」在**该族上不成立**；
    // 且触发条件比报告更宽 —— **不需要 `priv=allow`**，派生默认 + 一条常规 deny 例外下
    // 就是 `deny → ask`。本守卫补上后该族回到 PRE **逐字同值**。
    //
    // ⚠️ PRE 那个第二 label（`rm`）本身是 `unwrapWordsFrom` 把**赋值右侧的 basename**
    // 当命令名产生的**假警告**（`sudo A=/bin/rm` 之后没有命令，shell 语义下不执行 `rm`）——
    // 但**不该由本行顺手消除**：赋值**恰在链尾**（`sudo A=/bin/rm`）与**不在链尾**
    // （`sudo A=/bin/rm kill 1234`、`sudo FOO=1 su root kill 1234`）是两种不同语义，
    // 无守卫的版本把前者**也**当成「链已到尾」而截断，属误伤（后者是本行要修的 fail-open 族）。
    // 「链尾赋值」族由 `test/shell-parse.mjs` 的 60j5 钉住（此前该族 grep `sudo A=` 命中 0、
    // 套件零鉴别力 ⇒ 会静默漂移）。
    //
    // 判据复用模块级 `LEAD_ASSIGN` **单点**（`:621`），与 `commandHeadEndFull` /
    // `headCommandNameOf` 两个兄弟推进循环里那一行**同形**（跨文件/跨版本引用一律用
    // 函数名而不是行号 —— 行号随实现漂移，函数名才是稳定锚点，与
    // `test/regressions.mjs:6927` 记的纪律同源）：
    // 无新正则、无分配、O(1)；`i + 1 < w.length` 只是一次整数比较，同为 O(1)。
    if (i + 1 < w.length && LEAD_ASSIGN.test(String(w[i]))) { i += 1; continue }
    if (!cur || (PRIV_PREFIXES[cur] !== 1 && WRAPPERS[cur] !== 1 && STATEMENT_KEYWORDS[cur] !== 1)) break
    // ── 语句关键字：跳过它继续（`time` / `!` / `then` …）──────────────────────────────
    // 任务点名 `time` 这一夹层：`sudo time sudo kill 1234` 与 `sudo timeout 5 sudo kill 1234`
    // **两类都要覆盖**。前者是关键字（`BASH_KEYWORDS.time`，**不在** `WRAPPERS` 里）、
    // 后者是 wrapper（`timeout` 的**时长位置参数**由 `skipPrefixArgs` 自己处理，见 `:1184`）。
    //
    // 为什么不能只靠链尾 `segmentLabel` 跳关键字：链尾只取**一次** label，
    // `segmentLabel(['time','sudo','kill','1234'])` 跳掉 `time` 后落在**第二个 `sudo`** 上，
    // 于是 `head === first` → `return first` → 链被截断（实测 labels=['sudo']、
    // tiers=['priv']、`sudo time sudo kill 1234` 在 proc=deny 下 **allow**）。
    // 故关键字必须在**推进阶段**就跨过去，与 wrapper 同一处置。
    //
    // 关键字**不进 labels**（它不是命令名）—— 这正是与上面「链上每层前缀名都进 labels」
    // 那一支分开写的原因：前缀名是收紧方向的证据（`su *`=deny 要能命中），
    // 而关键字是纯语法噪声（`time *`=deny 没有语义）。
    // 推进方式复用 `skipPrefixArgs`（处理 `time -p cmd` 的 `-p`），与 wrapper 分支同源。
    if (STATEMENT_KEYWORDS[cur] === 1) {
      let nx = i + 1
      try { const s = skipPrefixArgs(w, i + 1, cur); if (s > nx) nx = s } catch (e) {}
      i = nx > i ? nx : i + 1
      continue
    }
    // 链上**每一层**前缀名都进 labels（不只是第一层）：这是**收紧**方向 ——
    // 用户写的 `su *`=deny 在 `sudo su root kill 1234` 上照旧命中。第一层已由上面推过。
    //
    // ── ⚠️ 但**同名**那一层**不得**进 `widened` ────────────────────────────────
    // `push(cur)` 不动：链上每一层名字都进 labels 是收紧方向（deny 例外要看得见 `su` / `doas`）。
    // `widen(cur)` 则必须与链尾、链首**同一条判据**：`widened` 按名字判定，而命令头那个
    // 前缀名本来就该留在授权面里（用户写 `sudo *`=allow 正是要授权它）。当链上某一层的名字
    // 与命令头前缀同名时，`widen` 挪出授权面的其实是命令头那个名字 —— 过度收紧、与主路径分叉。
    // 故判据是名字比较（`cur !== headPrefix`）。
    // ⚠️ 主路径的调用点**刻意不传** `headPrefix`，故为 `undefined`，
    // `cur !== undefined` 恒真 → `sudo rm -rf /etc` 的既有行为逐字不变。
    if (cur !== first) {
      push(cur)
      if (cur !== headPrefix) widen(cur)
    }
    const at = skipPrefixArgs(w, i + 1, cur)
    let next = at
  // ── `su` / `runas`：**操作数不是命令名**，推进步必须与命令头解析同源 ────────────────
  // 这两个前缀的带值选项表刻意留空（值本身可能是命令也可能是目标），故 `skipPrefixArgs`
  // 停在**操作数**上（`su root kill 1234` 的 `root`、`runas /user:admin …` 的 `/user:admin`），
  // 而真命令名还在它之后。只调 `skipPrefixArgs` 会让同一件提权语义因前缀不同而分叉
  // （`sudo kill 1234` 能扩展出 `kill`、`su root kill 1234` 不能）—— 方向 fail-open。
  // 修法是复用 `commandHeadEnd` / `headCommandNameOf` 共用的 `privOperandSkip`。
  //
  // **只在确实跨过操作数时才扩展**：`privOperandSkip` 仅在「操作数之后确实是命令头元素」
  // 时才跨（`su root` / `su root ls` / `su -c C:/Windows` 一律不跨），未跨过时保持原行为
  // —— 否则 `segmentLabel(['root'])` 会把操作数本身当成 label 加进来。
  //
  // ── ⚠️ 但「没跨过」**不等于**「链到此为止」────────────────────────────────────
  // `privOperandSkip` 返回 `at` 有两种成因，此前被当成了同一种：
  //   ① `at` 位置**确实是操作数**，只是它后面没有命令头元素 → 链到此为止，不把操作数/值当 label；
  //   ② `at` 位置**根本不是操作数**，它本身就是命令头元素（`su kill 1234` 的 `kill`、
  //      `su sudo kill 1234` 的 `sudo`、`su env kill 1234` 的 `env`）—— 这一支必须**继续推进**，
  //      否则整条链被提前截断、真命令名永不进 labels → 组档整体丢失（fail-open）。
  //
  // 判据复用 `isPrivOperandWord` 单点（与 `privOperandSkip` 的入口判据同源），且它是 O(1)。
  // **必须用 `isPrivOperandWord` 而不是 `isPrivOperandToken`**：后者会因 `-c` 而返回 false，
  // 于是 `su -c C:/Windows` 的值会被当成命令名加进 labels（`windows`）。
  // 推进的收敛性不变：`at >= i + 1 > i`，故 `i` 每轮至少推进一个词元。
    if (PRIV_VALUE_IS_COMMAND[cur] === 1) {
      if (next < w.length) { try { const s = privOperandSkip(w, cur, i + 1, next); if (s > next) next = s } catch (e) {} }
      if (next <= at) {
        let operand = false
        try { operand = isPrivOperandWord(w, cur, at) } catch (e) {}
        // ① 操作数 → 链到此为止，保持原行为（不把操作数/值当成 label）
        if (operand) return first
        // ② 命令头元素 → 继续推进（`i = at`），交给循环按前缀/wrapper 继续剥或到链尾取 label
        next = at
      }
    }
    if (next >= w.length) return first
    i = next
  }
  // ── 链尾取**一次**命令头 label（`i` 已推进到「不再是提权前缀」的位置）───────────────
  //
  // ── ⚠️ 必须走**下标入口**，不得写 `segmentLabel(w.slice(i))`──────────
  // 切片是 O(剩余词元数)，而 `segmentLabelsCore` 对**每个** `-exec` 都调一次本函数 ——
  // 段内 n 个 `-exec sudo cmd_i {} +` 累计 Σ(n−j) = **O(n²)**。实测 `isDestructiveSegment`
  // （index.js 的 buildCandidates 对每段调一次、同步早于弹窗）：
  //   n=1000 → 2.3 ms、2000 → 6.9、4000 → 84.7、**8000 → 599 ms**（倍率 2.9/12.4/7.1）；
  //   而**无前缀**的 `-exec cmd_i {} +`（本函数立刻 `return first`、根本不走这里）同规模
  //   0.6/0.9/1.8/3.7 ms（倍率 1.5/2.0/2.1，线性）—— 平方因子就是这次 `w.slice(i)`。
  // 触发形态 `find . -exec sudo … {} +` 是 AI 常写的常规写法，不是构造输入。
  // `segmentLabelFrom` 是 `segmentLabel` 的**唯一下标入口**（`segmentLabel(w)` 就是
  // `segmentLabelFrom(w, 0)`），语义与 `segmentLabel(w.slice(i))` 逐字等价 —— 同一份剥法
  // （`unwrapWordsFrom`），只是全程按下标推进、一次拷贝都不做。
  //
  // ⚠️ `headWordOnly` 是**载荷族**（`headLabelAt`）才传的：那条路径的既有口径是**单词**
  // label（54s），首词化在本函数内**只发生一次**（下面 `:1265` 的
  // `headWordOnly ? String(headRaw).split(' ')[0] : headRaw`）—— `out` 与 `widened`
  // 两个写入点拿到的都是这个已截断的值（**不是**由调用方的 `addLabel` 包装取首词：
  // 那个描述已失效，且 `addLabel` 是 `out` 的单点写入器，不该再叠一层语义）。
  // 主路径（`segmentLabelsCore` 那一支）不传，故 `reg delete` 的粒度照旧。
  // ⚠️ `shell` 必须透传：链尾 label 与主 label 走的是**同一道赋值守卫**，漏传会让
  //    `find . -exec A=/bin/rm {} ;` 这类载荷在 pwsh 侧仍被误判成赋值（与主路径分叉）。
  const headRaw = segmentLabelFrom(w, i, shell)
  const head = headWordOnly ? String(headRaw).split(' ')[0] : headRaw
  // 认不出（`su root` 只有操作数、`su -c C:/Windows` 的值是目标）→ 保持原行为，不扩展。
  if (!head || head === first) return first
  // **不把「已见过」当停止条件** —— `sudo sudo kill 1234` 的第二个 `sudo` 与第一个同名，
  // 但它**不是**命令头（真命令名 `kill` 还在后面）；在那里停下等于把发现 2 的缺陷换个
  // 形态留下（该形态实测正是 allow）。去重交给 `out` / `widened` 各自判。
  push(head)
  // **同时**进 `out`（并集：破坏性判定与组档照旧看得见它）与 `widened`（授权方向不认它）。
  // 链上的每一层扩展名都算 `widened`：`sudo su root kill 1234` 里 `su` 与 `kill` 都是
  // 「前缀之后才看得见的名字」，用户为普通 `kill` / `su` 写下的 allow 不得因此被放大。
  widen(head)
  return head
}

/**
 * 从一个段里提取**全部**参与破坏性判定的 label（主 label 在前）。
 *
 * 绝大多数段只返回一个（就是 segmentLabel 的结果）；只有 `find` 这类
 * 「选项携带命令」的形态会多返回。判定侧按「任一 label 命中即算命中」处理。
 *
 * **导出的理由**（原本刻意不导出）：档位判据 `tierSetOf` 的第二个参数就是它 ——
 * 「哪一档在管这一段」完全由 label 集合决定（组档看 label 属于哪一组），
 * 而调用方（宿主与测试）必须能拿到**与判定侧同一份** label 才能验证这一点。
 * 让调用方各自取 `segmentLabel` 的主 label 会漏掉合成 label（`find -delete` → `rm`）
 * 与提权前缀扩展（`sudo kill` → 额外一个 `kill`），正是本函数存在的意义。
 */
export function segmentLabels(words, shell) {
  return segmentLabelsCore(words, shell).labels
}

/**
 * `segmentLabels` 的**单一实现**，并把「前缀扩展出的 label」单独交回给调用方。
 *
 * 为什么要分开（安全）：前缀扩展（`sudo kill 1234` → 额外一个 `kill`）只论证了**收紧**方向
 * ——让破坏性名单与 deny 例外看得见 `sudo` 之后的真命令。但这份 labels 同时被**例外匹配**
 * 消费，而例外有 **allow** 动作：`resolveException` 拿扩展出的 label 去问宿主，用户为普通
 * `rm` 写下的 `rm *`=allow 就会命中 `sudo rm -rf /` —— 一条「允许删工作区内的文件」被静默
 * 提升成「允许经 sudo 删任意路径」。实测（两侧子设置动作完全等价，只有 label 扩展不同）：
 *
 *     sudo rm -rf /etc   → 改前 ask，改后 **allow**（source=exception，命中用户的 `rm *`=allow）
 *     sudo rm -rf /      → 同上
 *     sudo -u root rm …  → 同上
 *
 * 故**前缀扩展出的名字不得用于 allow 方向的授权**：调用方拿到 `widened` 后按方向取用
 * （deny/ask 可以用，allow 不可以）——`assessCommand` 的 `resolveException` 就是这么做的。
 * 破坏性判定（`isDestructiveSegment` / `tierSetOf` 的组档）与 `rawCommandNames` 用的是
 * 并集，两者都只往**收紧**方向走，故照旧用 `labels`。
 *
 * @returns {{ labels: string[], widened: string[], widenedSet: Set<string> }} `labels` = 主 label +
 *   全部扩展名（并集，去重）；`widened` = 其中**仅由提权前缀扩展**得来的那些（是 `labels` 的
 *   子集）；`widenedSet` = 同一集合的 `Set` 视图（**发现 2 的 O(1) 查询面**，见函数体内说明）——
 *   调用方一律用它判「某名字是不是扩展来的」，不得再对 `widened` 数组做 `indexOf`。
 *
 * ⚠️ **导出的理由**（原本刻意不导出，与 `segmentLabels` 同处置）：`widened ⊆ labels` 是授权方向
 * 的**安全不变量** —— `assessCommand` 的授权面是 `labels.filter(l => !widenedSet.has(l))`，
 * 若某个名字只进了 `widened` 而没进 `labels`，它就从两个集合里**同时消失**（判档与 deny 例外
 * 都看不见它）；反之若某个**扩展来的**名字漏进 `labels` 而没进 `widened`，它就会留在授权面里
 * 被用户为普通命令写下的 allow 命中（那正是本轮 F1 / F3 / F4 反复修的同一族缺陷）。
 * 两个集合由本函数**单点产出**，故这条不变量只能在这里被观测 —— 测试必须能同时拿到
 * `labels` 与 `widened`，`segmentLabels` 只交回前者。
 */
export function segmentLabelsCore(words, shell) {
  // 方言归一化**一次**，此后本函数体内全部调用都显式透传它 —— 赋值守卫在 `segmentLabelFrom`
  // 里，而载荷族（`headLabelAt` → `pushHeadLabels`）会绕过 `segmentLabel` 直接调下标内核，
  // 漏传任何一处都会让「主 label 有、载荷 label 无」（或反之）在 pwsh 侧重新分叉。
  const sh = shellOfWords(words, shell)
  const main = segmentLabel(words, sh)
  const out = main ? [main] : []
  // 仅由「提权前缀之后」得来的名字。**与 out 分开维护**：见上面那段 allow 方向的安全说明。
  const widened = []
  // ── `widened` 的**并行 Set**────────────────────────────────────
  // `widened.indexOf(x)` 是 O(len)，而 `find -exec` 载荷族会为**每个** `-exec` 各推一个
  // 名字 —— 逐条**不同名**时段内 n 个 `-exec` 就是 O(n²)。实测（`sudo find . (-exec c_i {} +)×n`、
  // 逐条不同名、`segmentLabels` 单次）：n=1000 → 0.52 ms、2000 → 1.62、4000 → 5.50、
  // **8000 → 21.04 ms**（倍率 4.91，标准平方）；而同一个 payload 名时 `widened` 长度恒 1、
  // `indexOf` 退化成 O(1)，n=8000 仅 **1.42 ms**（线性）—— 平方因子就是 `indexOf`。
  // 本批改动**新引入** `widened` 概念（HEAD 无它），故这是本批的退化，不是既有问题。
  // 触发需 n ≥ 1000 个逐条不同名的 `-exec`（真实命令几乎不达），但修法**零行为变更**、
  // 且 `isDestructiveSegment` 在 index.js 的候选生成循环里对每段调一次、同步早于弹窗。
  // 维护纪律：**只经 `addWidened` 写入**（两处并行结构不可能漂移），读取一律用 `widenedSet.has`。
  const widenedSet = new Set()
  const addWidened = (name) => { if (name && !widenedSet.has(name)) { widenedSet.add(name); widened.push(name) } }
  // `out` 的 O(1) 写入单点（与 `addWidened` 同处置，见 `pushHeadLabels` 里发现 2 的说明）：
  // `out` 会随 `-exec` 个数线性增长，故查重**不得**用 `indexOf`。
  const outSet = new Set(main ? [main] : [])
  const addLabel = (name) => { if (name && !outSet.has(name)) { outSet.add(name); out.push(name) } }
  const u = unwrapWords(words)
  if (u.opaque || !u.words.length) return { labels: out, widened, widenedSet }
  const w = u.words
  // 判据用 `main`（segmentLabel 已解析出的命令名），**不是** `w[0]`。
  // segmentLabel 会跳过 STATEMENT_KEYWORDS（`time`/`!`/`then`…）与 ROUTER 选项找到真正的命令，
  // 而 unwrapWords 只剥 WRAPPERS（env/timeout/nice/xargs）。若这里看 w[0]，
  // `time find . -delete` 的 w[0] 是 `time` → find 分支不进入 → -delete 不被识别 →
  // 大分类 allow 时静默放行（实测：`find . -delete` 是 deny，`time find . -delete` 是 allow）。
  // ── 提权前缀之后的真命令名（§5.2）───────────────────────────────────────────
  //
  // `segmentLabel` 遇到提权前缀就**停在前缀上**，其后的真命令名进不了 labels：
  //     sudo kill 1234   → labels 只有 ['sudo']，kill 不可见   ❌
  //     nice kill 1234   → labels ['kill']                     ✅（unwrapWords 剥了 wrapper）
  //     env FOO=1 kill 1234 → labels ['kill']                  ✅（剥了赋值前缀）
  // 差别在于：wrapper 是**透明包装**（unwrapWords 会剥），而提权前缀不是（它改变权限）。
  //
  // 后果不只是组档漏判（`sudo kill 1234` 只命中 priv、漏掉 proc），还有一个**既有漏洞**：
  // 例外匹配用的是同一份 labels，于是用户写的 `kill *`=deny 拦不住 `sudo kill 1234`
  // （实测：大分类与子设置都设 allow、只靠例外拦时，`kill 1234` 是 deny 而
  //  `sudo kill 1234` 是 allow —— 用户显式写的拒绝被绕过）。这不是本计划引入的。
  //
  // `su` / `runas` 由 `pushHeadLabels` 内部经 `privOperandSkip` 跨过**操作数**后照常扩展
  // （54h / 54t2）—— 它们**不再被排除**。该排除曾经存在，理由是「值本身可能是命令或目标，
  // 照搬会取到 `root`、`user:admin` 这类非命令名，让例外误命中（方向是放宽）」；本次修复把
  // 「操作数」与「命令头元素」分开处理（`isPrivOperandWord` 单点判据），操作数照旧不进 labels、
  // 而操作数之后的真命令名**必须**进 —— 否则组档整体丢失、deny 例外被绕过（fail-open）。
  // 实测：`segmentLabels(['su','root','kill','1234'])` = `['su','kill']`、
  // `segmentLabels(['runas','/user:a','kill','1234'])` = `['runas','kill']`；
  // 而 54b 的反例仍然成立（`su root` → `['su']`、`su -c C:/Windows` → `['su']`）。
  //
  // **扫描位置是命令头**，不是段首固定下标：`time sudo kill 1234` 的 `w[0]` 是
  // 语句关键字 `time`，而 `main` 是 `sudo`（segmentLabel 已跳过关键字）。
  // 故按 `main` 的实际下标定位 —— 段首与语句关键字之后各试一次。
  //
  // `headLabel` = `pushHeadLabels` 交回的**命令头 label**（无扩展时为空串，下面回退到 `main`）。
  // 它只在上面那一支里被赋值，故「不新增调用」—— 见 find 闸门处的说明。
  let headLabel = ''
  {
    // ── 廉价预筛：**只有提权前缀才可能扩展出 label** ──────────────────────────────
    // `pushHeadLabels` 的第一步是 `commandNameOf(w[start])`，第二步是
    // `if (PRIV_PREFIXES[first] !== 1) return first`（现实现，见 `:841`）——
    // 即非提权前缀时它什么都不做。
    //
    // ⚠️ 这里曾经把判据引作 `if (PRIV_PREFIXES[first] !== 1 || PRIV_VALUE_IS_COMMAND[first]) return`
    // —— `|| PRIV_VALUE_IS_COMMAND[first]` 那一半已被本批修复**删除**（`su` / `runas` 现在
    // 照常扩展，见上面那段说明），引文已按现实现更正。结论「非提权前缀不会扩展」仍然正确
    // （`PRIV_VALUE_IS_COMMAND` 的两个键 `su` / `runas` 本身就在 `PRIV_PREFIXES` 里）。
    //
    // 而下面的 `findIndex` 是**对整段的全量扫描**，且对路由器命令**恒返回 -1**：
    // 它的判据是 `commandNameOf(词元) === main`，而路由器命令的 `main` 是**两词** label
    // （`git add`、`npm run`、`git commit`），`commandNameOf(任一词元)` 永远不等于它。
    // 于是这趟扫描是纯浪费，且每次 `segmentLabels` 都要重付一遍 —— 而
    // `isDestructiveSegment`（index.js 的 buildCandidates 对**每一段**调用一次）
    // 同步执行在 `pendingApprovals.set` 之前，直接推迟弹窗。
    // 实测 `isDestructiveSegment`（纯词元构造，200 次取均值）：
    //     git add + 200/1000/4000/10000 个文件 → 33.7 / 82.6 / 257.4 / 616.5 µs
    // 加守卫后这趟扫描完全不发生（`main` 不在表里即跳过），26 条判定对拍逐字一致。
    //
    // 判据用 `PRIV_PREFIXES[main]`（与 `pushHeadLabels` 内部第一步同表同判据），
    // 故守卫**不可能**跳过本会扩展的段；`su` / `runas` 的排除仍在函数内部（单一来源）。
    if (PRIV_PREFIXES[main] === 1) {
      const at = w.findIndex((t) => commandNameOf(t) === main)
      if (at >= 0) headLabel = pushHeadLabels(w, at, addWidened, addLabel, undefined, undefined, sh)
    }
  }
  // ── find 分支的闸门必须看**命令头 label**，不是段首 label ──────────────────────
  // 闸门原先写 `main !== 'find'`，而 `main` 是 `segmentLabel` 的结果 —— 段首是提权前缀时
  // 它就是前缀名，于是这里立刻早退，下面 `find -exec` / `-delete` 的载荷族 label 合成整段
  // 被跳过。而 `tierSetOf` 的组档（proc / power / reg）判据完全依赖这份 label，于是这三档
  // 在带前缀时静默消失（fail-open）。故闸门改用 `headLabel`（`pushHeadLabels` 的返回值）——
  // 不新增调用、不额外遍历（无条件先调 `headCommandNameOf(w)` 会给每段加一次前缀链遍历）。
  //
  // ⚠️ 放宽闸门**必须**同时把下面合成的 label 计入 `widened`（见那里的说明），否则
  // `sudo find / -delete` 会拿到 `['sudo','find','rm']` 而 `rm` 不在 `widened` 里 ——
  // 授权方向可见，用户为普通 `rm` 写的 `rm *`=allow 被提升成「允许经 sudo 删盘根」。
  const findHead = headLabel || main
  if (findHead !== 'find') return { labels: out, widened, widenedSet }
  // 从 main 对应的位置开始扫（跳过被剥掉的关键字前缀），避免把 `time` 之前的词元当成 find 的参数
  let start = 0
  for (let i = 0; i < w.length; i += 1) {
    if (commandNameOf(w[i]) === 'find') { start = i; break }
  }
  // ── 廉价预筛：整段里没有任何 `-exec` 族或 `-delete` 时直接返回 ────────────────
  // 下面的循环对**每个** `-exec` 都做一次 `w.slice(j + 1)`（O(n) 拷贝）再 unwrapWords，
  // 于是段内有 n 个 `-exec` 时整体 O(n²)。它在判定侧早就存在，但本次改动把
  // `isDestructiveSegment` 加进了候选生成循环（index.js 对每个段调一次），于是
  // **弹窗出现前**也要付这笔钱。实测直接构造词元（`-exec echo i ;` 重复 n 组）：
  //   n=500 → 1.53 ms、1000 → 2.20、2000 → 5.91、4000 → 20.60、8000 → **406.72 ms**
  // 而 buildCandidates 是同步执行、早于 pendingApprovals.set，直接推迟弹窗。
  // 预筛本身是 O(n) 的单次扫描（无切片、无分配），实测 20000 词元约 0.0002 ms ——
  // 只有真正含这些 flag 的段才会走下面的循环。判据与下面循环读取的常量同源，
  // 不会因为新增 flag 而漏（FIND_EXEC_FLAGS / FIND_DELETE_FLAG 是唯二判据）。
  let hasFindAction = false
  for (let j = start + 1; j < w.length; j += 1) {
    const tk = String(w[j])
    if (tk === FIND_DELETE_FLAG || FIND_EXEC_FLAGS[tk]) { hasFindAction = true; break }
  }
  if (!hasFindAction) return { labels: out, widened, widenedSet }
  // ── 前缀之后合成的载荷族 label 必须计入 `widened`──────────────
  // 上面那一段把闸门放宽到「命令头 label 是 find」之后，`sudo find / -delete` 会得到
  // `['sudo','find','rm']`，而这个 `rm` 是**载荷族合成**出来的（原词元里根本没有 `rm`）。
  // 若它不进 `widened`，授权方向（`resolveException` 的 allow 分支用 `labels` 滤掉 `widened`）
  // 就会看见它 —— 用户为普通 `rm` 写下的 `rm *`=allow 被**提升**成「允许经 sudo 删盘根/系统
  // 目录」。实测（例外 `rm *`=allow、其余全 ask）：`sudo find / -delete` 与
  // `sudo find C:/Windows -delete` 由 **ask → allow**，与 54c2 钉住的方向不变量直接冲突。
  // 判据是「这段确实带提权前缀」（`headLabel` 非空即说明扩展发生过），**不是**「find 之前
  // 有词元」：不带前缀时 `find . -delete` 的 `rm` 与 HEAD 逐字一致，不该被挪出授权面。
  // 不带前缀时 `find -delete` 的 `rm` 本来就该可被 `rm *`=allow 授权 —— 那是用户写下的
  // 真实意图（HEAD 亦然）。
  const synthWidened = !!headLabel
  // ── 命令头那个提权前缀**叫什么名字**（F4 的判据，空串 = 命令头不带提权前缀）────────────
  // 载荷族链首那一层是否进 `widened` 要按**名字**判：只有当它与命令头前缀**不同名**时，
  // 那个名字才是「因前缀之后才可见」的（= 该进 `widened`）。同名时授权面里那个名字
  // **就是命令头前缀本身**，`widen` 会把用户正当的授权一并挪走（过度收紧，见 `pushHeadLabels`）。
  //
  // 取值用 `main`（= `segmentLabel(words)`，段首主 label）：它在**五种**命令头形态下都恰好
  // 给出提权前缀名，且与 `headLabel` 的推进同源（实测）：
  //     `sudo find …`             → sudo      `env sudo find …`       → sudo
  //     `timeout 5 sudo find …`   → sudo      `sudo su root find …`   → sudo
  //     `su root find …`          → su        `runas /user:a find …`  → runas
  //     `time sudo find …`        → sudo（`time` 是语句关键字，segmentLabel 会跳过）
  //     `find …`（无前缀）        → find      → 查表不中 → 空串
  // 用 `PRIV_PREFIXES[main] === 1` 判据（与 `:1300` 的闸门同表同判据），故不会引入第二份口径。
  const headPrefixOf = PRIV_PREFIXES[main] === 1 ? main : ''
  for (let j = start + 1; j < w.length; j += 1) {
    const token = String(w[j])
    if (token === FIND_DELETE_FLAG) {
      addLabel('rm')
      if (synthWidened) addWidened('rm')
      continue
    }
    if (!FIND_EXEC_FLAGS[token]) continue
    // `-exec` 之后跟的是**一条完整命令行**，同样可以有前缀包装器 —— 必须复用 unwrapWords，
    // 否则 `find . -exec env rm -rf {} \;` 的 label 会取到 `env`，真正的 rm 不可见
    // （实测：`find . -exec rm` 是 deny，而 `-exec env rm` / `timeout 5 rm` / `nice rm` → allow）。
    // 这与主 label 路径（segmentLabel 靠 unwrapWords 剥前缀）口径一致。
    //
    // ── ⚠️ 但只剥 wrapper 是**不够**的：提权前缀链也必须推进─────────────────
    // 原实现只取「`-exec` 之后的第一个命令名」，于是 `-exec` 载荷里的**提权前缀**被当成
    // 命令名收下、真命令名永不进 labels：
    //     find . -exec kill {} ;          labels=['find','kill']  tiers=['proc']        → deny
    //     find . -exec sudo kill {} ;     labels=['find','sudo']  tiers=['priv']        → **allow**
    //     find . -exec env sudo kill {} ; labels=['find','sudo']  tiers=['priv']        → **allow**
    //     find . -execdir doas kill {} ;  labels=['find','doas']  tiers=['priv']        → **allow**
    //     find . -exec su root kill {} ;  labels=['find','su']    tiers=['priv']        → **allow**
    // 对照 `sudo find . -exec kill {} ;` 是 `['proc','priv']`/deny（54s 已修）。
    // power / reg 两组同样，且**用户写的 deny 例外同样被绕过**（例外 `kill *`=deny 时
    // `find . -exec kill {} ;` 是 deny、`find . -exec sudo kill {} ;` 是 allow）。
    // 方向是 **fail-open**。触发需用户按 §3.3 单独把 `priv` 设 allow（与 54s/54t 同前提）。
    //
    // 修法：**复用主路径的前缀链推进**（`skipPrefixArgs` + `privOperandSkip`，与
    // `commandHeadEnd` 的 ① 分支 / `pushHeadLabels` 同源）—— 五处若各写一份，
    // 「命令头到哪儿」与「labels 有哪些」必然再次分叉（那正是本文件反复要修的那类缺陷）。
    // 从 `j + 1` 起推进到链尾，再取命令头 label。
    //
    // ── 只在**可能剥掉前缀**时才复制后缀 ────────────────────────────────────────
    // `w.slice(j + 1)` 是 O(剩余词元数)，而段里有 n 个 `-exec` 时整体退化成 O(n²)。
    // 实测（`-exec echo i ;` 重复 n 组）：n=2000 → 6.8 ms、4000 → 17.1 ms、8000 → **469 ms**、
    // 16000 → 2041 ms。它在**候选生成**路径上（本次改动把 isDestructiveSegment 加进了
    // index.js 的候选循环），而 buildCandidates 同步执行、早于 pendingApprovals.set ——
    // 直接推迟弹窗，而命令文本由 AI 生成、长度无上界。
    //
    // 快路径的**等价性**：unwrapWords 只在两种情况下剥词元（或判 opaque）——
    // ① 前导 `NAME=value`；② 首词元是 WRAPPERS 里的名字。两者都不成立时它原样返回，
    // 于是「从 j+1 起找第一个有效命令名」与「先 slice 再 unwrapWords 再找」结论完全相同。
    // 用词元**本身**判断（不看后面），故不存在窗口截断导致漏判的可能。
    //
    // ⚠️ 前缀链推进**必须也走快路径之外**（下面两条分支共用同一个「取命令头 label」的
    // 推进步 `headLabelAt`）：否则 `-exec sudo kill` 这类**无 wrapper 但带提权前缀**的
    // 形态（正是发现 1 的主角）会落回「只取第一个词元」。
    const firstTok = String(w[j + 1] == null ? '' : w[j + 1])
    // ── `widened` 的登记**全部由 `pushHeadLabels` 内部完成**（这里不再补一遍）────────────
    // 曾经的写法是「这里再判一次『载荷链是否发生了前缀扩展』并 `addWidened(cand)`」，
    // 而那是**冗余**的：`pushHeadLabels` 对链上每一层扩展名都会调 `widen(...)`
    // （`find . -exec sudo rm -rf {} +` 的 `rm` 在推进到链尾时已进 `widened`）。
    // 实测（变异消融：把那一行改成 `if (cand && synthWidened) …`）**0 断言失败** ——
    // 正说明它是死代码。故删掉，让授权方向只有一个守卫点（`pushHeadLabels` 的 `widen`），
    // 避免「两处判据看似都在守、实则只有一处生效」的假守卫。
    // ⚠️ 被删掉的那个判据当时写作「`headLabelAt` 的返回值 `advanced`」—— 而 `headLabelAt`
    // 的 `@returns` 是 `{string}`、**从未**返回过 `advanced`（该标识符全文件仅此一处，
    // HEAD 为 0 处）：那是对一个不存在的返回值的引用。`pushHeadLabels` 内部既已按
    // 「链上每一层扩展名」逐个 `widen`，这里也就不再需要那个标志位。
    // ⚠️ 唯一**不**经 `pushHeadLabels` 的是 `-delete` 合成的 `rm`（原词元里根本没有 `rm`），
    // 它由上面 `synthWidened` 那一支单独登记 —— 那条是必需的（54u 钉住的方向不变量）。
    if (!/^[A-Za-z_][A-Za-z0-9_]*=/.test(firstTok) && WRAPPERS[commandNameOf(firstTok)] !== 1) {
      // 快路径：首个词元不是赋值前缀、也不是 wrapper。仍然要推进**提权前缀链**
      // （`-exec sudo kill` / `-exec su root kill`）—— 判据与主路径同源，且是纯下标推进。
      headLabelAt(w, j + 1, addWidened, addLabel, headPrefixOf, sh)
    } else {
      // 慢路径：首个词元是赋值前缀或 wrapper，必须先剥掉它们（`-exec env sudo kill`、
      // `-exec timeout 5 sudo kill`）再推进前缀链。
      //
      // ── ⚠️ 走**下标内核**，不得写 `w.slice(j + 1)` 再 `unwrapWords(...)`──
      // 那两处切片各是 O(剩余词元数)，段内 n 个 `-exec env sudo cmd_i {} +` 累计 **O(n²)**。
      // 实测 `isDestructiveSegment`（`-exec env sudo cmd_i {} +`×n）：
      //   n=1000 → 8.5 ms、2000 → 31.3、4000 → 350.2、**8000 → 1925 ms**（倍率 3.7/11.2/5.5）；
      //   改成下标版后同规模 2.4/8.9/142.4/764.6 ms —— 剩下的平方来自别处（见下），
      //   而这两处切片本身已归零。
      // `unwrapWordsFrom(w, j + 1).base` 与原来 `j + 1 + (rest.length - u2.words.length)`
      // **逐字同值**：被剥掉的词元数就是游标相对 `j + 1` 的位移（两者共用同一份剥法，
      // 见该函数的说明）。opaque 与「剥到空」两种出口照旧 `continue`。
      const u2 = unwrapWordsFrom(w, j + 1)
      if (u2.opaque || u2.base >= w.length) continue
      headLabelAt(w, u2.base, addWidened, addLabel, headPrefixOf, sh)
    }
  }
  return { labels: out, widened, widenedSet }
}

/** 该 label 是否命中破坏性名单（空 label 恒 false —— 认不出就不下判断）。 */
export function isDestructiveLabel(label) {
  const l = String(label == null ? '' : label).trim().toLowerCase()
  return !!l && DESTRUCTIVE_LABELS.has(l)
}

/**
 * 该段是否为「破坏性命令段」—— 判据与 assessCommand **完全同源**（同一份 segmentLabels）。
 *
 * 导出给 index.js 复用（候选生成、例外列表标注）：那两处都必须用这一份，不能各自取
 * `segmentLabel` 的主 label 再判名单 —— 两者对 `find` 族结论**相反**：
 * `segmentLabels` 会为 `find -delete` / `find -exec rm` 合成一个 `rm` label（见该函数注释），
 * 而主 label 恒为 `find`（不在 DESTRUCTIVE_LABELS 里）。
 *
 * 分叉的后果（实测）：`find . -delete` 在判定侧是 destructive（落破坏性子设置），
 * 候选侧却按非破坏性生成通配候选 `find *`；用户点一次「允许并记住」写入该例外后，
 * `find . -delete` 在 destructive=deny 下由 **deny 变 allow** —— 正是候选侧收紧
 * 通配（index.js 的「破坏性命令不给通配候选」）要堵的那个洞，只是换了个命令族。
 *
 * @param {string[]} words 段词元（与 assessCommand 的 seg.words 同源）
 * @param {'pwsh'|'bash'} [shell] 方言；缺省时取词元数组上的**方言戳**（见 `SEG_SHELL`），
 *   再无则按 `'bash'` —— 故 `index.js` 只需原样传 `seg.words` 即可拿到正确方言。
 */
export function isDestructiveSegment(words, shell) {
  return segmentLabels(words, shell).some((l) => isDestructiveLabel(l))
}

// 提权命令的「带值选项」：`-u FOO` 里的 FOO 是值不是命令。
// 与 WRAPPER_VALUE_FLAGS 同性质，但按提权命令单独维护（两族的选项集不同）。
// 只认精确拼写（`--user=FOO` 自带值，不消耗下一个词元）。
//
// **`su -c` / `--command` 刻意不在表里**：它的值**本身就是一条命令**
// （`su -c "rm -rf /"`、`su -c rm -rf /` 都会真的执行 rm），跳过值等于把真正的
// 命令名一起吃掉。实测（A/B 对拍）：把它当带值选项时 `su -c rm -rf /` 的爆炸半径
// 从 drive-root 退化成 null —— 删盘根的警告被静默吃掉，是本文件反复警告的那类漏报。
// 不跳则 `-c` 之后的值被当作「命令名」继续吃（`rm` 在破坏性名单里，正确判档）。
const PRIV_VALUE_FLAGS = dict({
  sudo: dict({ '-u': 1, '-g': 1, '-p': 1, '-C': 1, '-U': 1, '-h': 1, '-r': 1, '-t': 1, '--user': 1, '--group': 1, '--prompt': 1, '--close-from': 1, '--other-user': 1, '--host': 1, '--role': 1, '--type': 1 }),
  doas: dict({ '-u': 1, '-C': 1 }),
  pkexec: dict({ '--user': 1 }),
  gsudo: dict({ '-u': 1, '--user': 1 }),
  runas: dict({}),
  su: dict({}),
})

// 前缀命令里「**值本身就是命令或目标**」的那几个 —— 上面两张表刻意留空（`su: {}` / `runas: {}`）
// 正是这个意思，此处给它一个名字供 commandHeadEnd 查询。
//
// 为什么单列：`su -c <值>` 的值是一条命令行（`su -c "rm -rf /"`），也可能是**目标**
// （`su -c C:/Windows`、`su -c of=/dev/sda`、`su -c ~`）。命令头解析若「因为前面有前缀，
// 就把下一个词元一律当命令名吃掉」，这些目标会被整段吞掉、段级 blast 归 null ——
// 实测 7 种形态（system / home 档）的警告消失，是把闸开过头造成的新漏报。
// 故这几个前缀**不吃**其后的词元，退回「只有命中破坏性名单才吃」的判据
// （`su -c rm -rf /` 的值是 `rm`，在名单里，照吃；`su -c C:/Windows` 不在名单里，留给目标判档）。
const PRIV_VALUE_IS_COMMAND = dict({ su: 1, runas: 1 })

/**
 * 跳过某个前缀命令（提权 / wrapper）自己的选项与带值选项，返回下一个「可能是命令」的下标。
 *
 * 存在的理由：`sudo -u root rm -rf *` 的命令头里夹着 `-u root`，而「遇到 `-` 就停」的判据
 * 会让命令头停在 `sudo` 上，真正的 `rm` 被当成**目标实参** —— 实测该例外的爆炸半径
 * 返回 null（`sudo rm -rf *` 则正确判 broad），而 `matchCommand('sudo -u root rm -rf *',
 * 'sudo -u root rm -rf /')` 为 true：一条能放行删盘根的 allow 例外在面板上零标注。
 *
 * 只吃「选项 + 它的值」，遇到第一个非选项词元就停（那就是下一个命令名或目标）。
 *
 * @param {string[]} w 词元列表
 * @param {number} start 前缀命令名之后的下标
 * @param {string} name 前缀命令名（小写，已过 commandNameOf）
 */
function skipPrefixArgs(w, start, name) {
  let j = start
  const valueFlags = PRIV_VALUE_FLAGS[name] || WRAPPER_VALUE_FLAGS[name] || EMPTY_DICT
  while (j < w.length) {
    const token = String(w[j])
    // env 的 `NAME=value` 赋值前缀不是选项，但同样不是命令
    if (name === 'env' && /^[A-Za-z_][A-Za-z0-9_]*=/.test(token)) { j += 1; continue }
    // **只有 `-` 开头才是前缀命令的选项**。
    //
    // 这里曾经把 `/` 开头也一并当选项（`!== 45 && !== 47`），而 POSIX 上 `/` 开头是**路径**：
    // `nice /usr/bin/find / -delete` 的前缀循环会把 `/usr/bin/find`、`/`、`-delete` 一路吃光
    // 直到词元耗尽，`commandHeadEnd` 返回词元总数，`i < headEnd` 于是把**整段**跳空 ——
    // 实测 `blastRadiusOfSegment(['nice','/usr/bin/find','/','-delete'], posix)` = null，
    // 而把命令名写成裸名 `['nice','find','/','-delete']` = drive-root|/。
    // 覆盖全部 6 个 wrapper + 6 个提权前缀：`sudo /usr/bin/find /etc -delete`、
    // `sudo /usr/bin/find / -exec rm -rf {} +` 这些真删盘根/系统目录的命令
    // `code=destructive` 而弹窗零警告。用绝对路径调用 `find`/`xargs` 是脚本常规写法，
    // 不是构造输入。注意 `sudo /bin/rm -rf /` 侥幸正确只是因为 basename 在破坏性名单里
    // （见下面那行 break），`find`/`xargs` 族的破坏性来自后续 flag 而非命令名，没有这层保护。
    //
    // `/s` 这类 cmd 风格开关不属于此处：它们是 `rmdir`/`del` 这类**破坏性命令自己**的选项，
    // 而本函数只跳过 wrapper/提权命令的参数（那些命令没有 `/x` 形态的选项），
    // 且段级判档侧另有 isCmdStyleSwitch 负责它们。
    if (token.charCodeAt(0) !== 45) break
    if (FIND_EXEC_FLAGS[token] === 1) break
    if (valueFlags[token]) j += 1
    j += 1
  }
  // timeout 的时长位置参数（`timeout 5 sudo rm -rf /`）
  if (name === 'timeout' && /^[0-9]+(?:\.[0-9]+)?[smhd]?$/.test(String(w[j] == null ? '' : w[j]))) j += 1
  return j
}

// `su` / `runas` 的选项里，**值本身可能是命令或目标**的那几个（见 PRIV_VALUE_IS_COMMAND 与
// PRIV_VALUE_FLAGS 里刻意留空的 `su: {}` / `runas: {}`）。`skipPrefixArgs` 因此**不会**吃掉
// 它们的值，于是那个值会停在「前缀之后」的位置上 —— 判据必须能认出「这是值，不是操作数」。
const PRIV_COMMAND_VALUE_FLAGS = dict({ '-c': 1, '--command': 1 })

/**
 * `t` 是否是这个「值本身即命令或目标」的选项（`-c` / `--command` / `--command=…`）。
 *
 * 两处调用点的**极性相反**（`privValueFlagBetween` 命中即返 true，`isPrivOperandWord`
 * 命中即返 false），那是**两个不同问题共用一条判据**的正常结果 —— 但判据本身只有一份，
 * 故抽成单点：往 `PRIV_COMMAND_VALUE_FLAGS` 里加一项（如 `-C`）时两处自动同时生效。
 *
 * ── ⚠️ 但「一份判据」**不等于「两个极性收同样宽窄」**（此处一度按后者收敛，是 fail-open）──
 * `--command=<值>` 这种**等号连写**形态只对 `privValueFlagBetween`（门控侧）成立：
 *   · 门控侧问的是「前缀的选项里有没有『值即命令』的那一项」—— 连写形态的**值就在词元里**，
 *     是同一件事的另一种写法，故**必须**认（`su --command=x C:/Windows` 的值是 `x`）。
 *   · 操作数侧问的是「这个词元是不是**值选项自身**」—— 判据的用途是让贪婪扫描**停下**。
 *     连写形态在这里停下是**错的**：它后面那个词元才是真命令，扫描一停 `privOperandSkip`
 *     就收束、`commandHeadEnd` 停在 **1**，真命令与真目标**一起**被排除在命令头之外，
 *     段级 blast 归 `null` → 半径档落 `inside`。
 *
 * 实测（win32，语料 = `-c`/`--command`/`--command=<值>` 全族 × {`su` / `sudo su` / `runas` /
 * `runas … /noprofile`} × 8 目标 + 同形态对照，共 915 条 × 8 组档位配置 = **7320 格**；
 * 对拍基线 = 本文件**仅把本行改回窄判据**的副本，SHA256 `C4B30241…`，逐格比 blast/tiers/动作）：
 * 把连写形态带进操作数侧后，**放宽方向 540 格、收紧方向 0 格** —— 全部是
 * `su root --command=<任意值> …` 一族：`priv=allow` 下由 ask 变 **allow**、
 * `outside=deny` 下由 deny 变 **ask**、`outside=deny+unknown=deny` 下由 deny 变 **allow**。
 * 触发形态**不限于空值**：`--command=x`、`--command=rm`、`--command==`、`--command=rm ` 全部命中
 * （实测 `commandHeadEnd`：`su root --command=x rm -rf /tmp` 窄判据 **4** → 宽判据 **1**）。
 * 同族还有 `sudo su root --command=…`（`headEnd` 5→2）与 `runas /user:a --command=…`（4→1）。
 *
 * ⚠️ **「两个极性收不同宽窄」现在由调用点各自判连写形态承担，本函数只留窄判据** ──────────────
 * 曾经本函数带一个**布尔形参 `joined`** 来区分调用点，而**两个真实调用点全传 `false`**
 * （唯一一处 `true` 在注释里，描述「原实现」）—— 于是 `joined && t.indexOf('--command=') === 0`
 * **恒不可达**，形参与 `@param` 的「仅门控侧为真」都与实现不符（死形参）。
 * 门控侧的连写支现在由 `privValueFlagBetween` **自己**判（它另有 `mayYieldRadiusTier` 守卫，
 * 见那里的说明），操作数侧照旧只认精确的 `-c` / `--command`。
 * ⚠️ **不得**改成「操作数侧也传 `true`」（即恢复无条件认连写形态）：实测三套件 FAIL(1)，
 * `badTiers3` 14 条 + `badCross3` 8 条由 ask 变 **allow**（`su --command=x root kill 1234` 一族），
 * 是**重新引入 fail-open**。
 *
 * **必须保持「查表 + 一次 `indexOf`」的 O(1) 形态**：`isPrivOperandWord` 在
 * `privOperandSkip` 的贪婪扫描里**逐词元**调用（见那里的性能注释），故此处
 * **不得引正则、不得分配**（`String(t)` 由调用方各做一次，本函数只收字符串）。
 * 去掉死形参后两处调用点各少一次实参求值，形态比收敛前更窄。
 *
 * @param {string} t 已 `String()` 过的词元
 * @returns {boolean}
 */
const isPrivCommandValueFlag = (t) => PRIV_COMMAND_VALUE_FLAGS[t] === 1

/**
 * `runas` 的**不含 `:` 开关**白名单（`isRunasSwitchShapedWord` 的第二条判据）。
 *
 * ── 为什么需要一张白名单 ─────────────────────────────────────────────────────
 * `runas` 的开关里只有 `/user:`（与 `/trustlevel:`）带 `:`，其余 8 个**不含 `:`**
 * —— 于是它们与**单段 POSIX 路径**（`/etc`、`/tmp`）**词法完全同形**，词法层面无法区分：
 *     runas /profile /savecred /user:admin rm -rf /tmp   ← `/savecred` 是开关，该跨
 *     runas /noprofile /etc rm                           ← `/etc` 是目标，**不该跨**
 * 上一版按「单段 `/x` 一律算开关」处理，把后者也跨了 → 真目标被跨过 → 段级 blast 归 null
 * → 档位落 `inside`（fail-open，实测见 `isRunasSwitchShapedWord`）。
 *
 * 故只能**枚举**：本表就是 `runas` 官方语法里全部不含 `:` 的开关
 * （`runas [/noprofile | /profile] [/env] [/netonly | /savecred] [/showtrustlevels]
 * [/trustlevel:<n>] /user:<名> <程序>`）。
 *
 * ── ⚠️ 漏加一项的方向是 **fail-open**（此处注释一度写成「偏保守」，实测为误）──────────
 * 本表的成员在命令头推进里是**必跨**项：漏掉一项**不会**「停在开关上」（那不是偏保守），
 * 而是让 `privOperandSkip` 的扫描在那一项上提前收束、`commandHeadEnd` 停在 **1** ——
 * 真命令与真目标**一起**被排除在命令头之外，段级 blast 归 `null` → 半径档落 `inside`。
 * 实测（win32，插桩 `commandHeadEnd`）：
 *     `runas /noprofile /savecred /user:a rm -rf /tmp`
 *       现状 `headEnd=5`、`blast=outside|/tmp`；
 *       删掉 `/savecred` 一项后 `headEnd=1`、`blast=null`（与「整段判不出」同值）。
 * 逐项删除本表 8 个成员实测：**7 项**（`/noprofile` `/profile` `/savecred` `/netonly`
 * `/smartcard` `/showtrustlevels` `/trustlevel`）删掉后都产生**新的静默放行** ——
 * 端到端 `priv=allow` 时由 `ask` 变 `allow`、`outside=deny` 时由 `deny` 退成 `ask`；
 * 只有 `/env` 无影响：它与 `WRAPPERS` 同名，`runas` 支在它上面本就走 wrapper 路径
 * （HEAD 即如此，属既有行为，不是本表的功劳）。
 * `/trustlevel` 在官方语法里写作 `/trustlevel:<n>`（带 `:`，由 `:` 支覆盖），
 * 但不带 `:` 的写法只有本表能覆盖 —— 实测删掉它同样 fail-open，故**不是**冗余项。
 *
 * 故「新增开关必须同步本表」是**硬约束**，且必须由测试守护：
 * `test/shell-parse.mjs` 的 **54r** 按**官方开关全表 × 非首位**穷举断言
 * （54o 只覆盖首位形态，靠 `privOperandSkip` 的 `k === at` 那一支通过，**照不出非首位的漏项** ——
 * 实测删掉 `/env` `/smartcard` `/showtrustlevels` `/trustlevel` 四项时旧语料仍全绿）。
 *
 * ⚠️ **不能改成「凡是不在已知路径名单里的单段 `/x` 都算开关」**：那是把本表的语义反过来。
 * 本表是**有限枚举**（漏一项 = 漏一个开关，且可由 54r 穷举守护），
 * 而路径空间**无上界**（`/zzz`、`/myapp`）—— 名单永远补不全，漏一个就是把**真目标**
 * 当开关跨过。该替代方案实测是本批引入的硬回归（见 `isRunasSwitchShapedWord` 里
 * 「上一版按单段 `/x` 一律算开关」那组：posix 侧 `runas /noprofile /etc rm` 由 HEAD 的
 * `system|/etc` 变 `null`）。两个方向**都是 fail-open**，取舍依据是「可枚举、可穷举守护」
 * 对「不可枚举」—— 不是「一个保守、一个不保守」。
 *
 * 大小写：`runas` 开关本身大小写不敏感（`/NOPROFILE` 同样合法），故查表前统一 `toLowerCase()`。
 */
const RUNAS_SWITCHES = dict({
  '/noprofile': 1, '/profile': 1, '/savecred': 1, '/netonly': 1,
  '/env': 1, '/smartcard': 1, '/showtrustlevels': 1, '/trustlevel': 1,
})

/**
 * `su` / `runas` 之后那个词元是不是**操作数**（用户名 / cmd 风格开关）而不是命令名？
 *
 * ── 为什么必须单独判 ──────────────────────────────────────────────────────────
 * `PRIV_VALUE_IS_COMMAND` 把这两个前缀标成「值本身可能是命令或目标」，故 `commandHeadEnd`
 * 对它们只在值命中 `isDestructiveLabel` 时才吃掉。那条判据对**判档**是对的，而命令名解析
 * （`headCommandNameOf`）若停在同一位置，就会把**操作数**当成命令名返回：
 *     su root rm -rf /data      → 查到 `root`
 *     runas /user:admin rm -rf /data → 查到 `user:admin`
 * 下游 `isCmdStyleSwitch` 认不出这个名字 → 走「认不出命令名 ⇒ 不消费半径 ⇒ 当开关」的兜底
 * → `/data` 被当开关跳过 → 段级 blast 归 null → 档位 `inside` → 提权档设为 allow 时
 * **静默放行**。实测（win32、priv=allow）：上面两条与 `runas /user:admin del /data` 全部
 * allow，而对照 `sudo -u root rm -rf /data` 是 ask —— 同一件事只因前缀不同就分叉。
 *
 * 影响面**不含盘根**：`su root rm -rf /` 仍是 ask（`/` 的 `charAt(1)` 为空，不命中
 * `/[a-z]/i` 那条开关判据，交回判档 → drive-root → wide）。失效的是**多字母单段路径**
 * （`/data`、`/zzz`）这一类。
 *
 * 判据（四条同时成立才算操作数）：
 *   · 前缀是 `su` / `runas`（`PRIV_VALUE_IS_COMMAND` 的成员）；
 *   · `skipPrefixArgs` 停在 `next`，且途中**没有**吃掉 `-c` / `--command` ——
 *     那些选项的值本身就是命令或目标（`su -c C:/Windows` 的值就是目标），跳掉它会把
 *     system 警告整个吃掉（该函数的注释里记着 7 种形态的实测）；
 *   · `w[next]` 不是命令头元素（wrapper / 提权前缀 / 语句关键字）—— 那些由各自的判据处理
 *     （`su env FOO=1 rm -rf /data` 的 `env` 必须继续走 wrapper 分支）；
 *   · `w[next]` 不是破坏性命令名（`su rm -rf /data` 的 `rm` 就是命令，必须留在命令头里）。
 *
 * **本判据由 `commandHeadEnd` 与 `headCommandNameOf` 共用**：两处若各写一份，
 * 「命令头到哪儿」与「命令名是谁」必然再次分叉 —— 那正是本次缺陷的成因。
 *
 * @param {string[]} w 词元列表
 * @param {number} from `skipPrefixArgs` 的起点（前缀命令名之后的下标）
 * @param {number} upto `skipPrefixArgs` 的返回值（停在哪儿）
 */
function privValueFlagBetween(w, from, upto) {
  // ── 连写支（`--command=<值>`）的**守卫**：只在「确有目标可保护」时才认它 ──────────────
  //
  // 本函数返 `true` ⇒ `isPrivOperandToken` 返 `false` ⇒ `privOperandSkip` **不跨**操作数
  // ⇒ 命令头停在 `at` ⇒ `at` 及其后词元留在命令头**之外**参与判档。
  //
  // 无条件认连写形态时，`commandHeadEnd` 会停在 `2`、`headCommandNameOf` 取回那个值选项
  // 词元本身（`--command=x`）→ `isCmdStyleSwitch` 认不出命令名 ⇒ 真目标（`/tmp`）被当
  // cmd 开关跳过 ⇒ 段级 blast 归 null ⇒ 半径档落 `inside` ⇒ `priv=allow` 时静默放行。
  //
  // ── 但**不能**简单地改回 `joined = false`（那是把这条闸开过头）──────────────────
  // 直接不认连写形态 ⇒ 操作数无条件被跨过 ⇒ 而 `upto` 位置可能正是**真路径目标**：
  //     `su --command=x C:/Windows rm`  连写不认 ⇒ 跨过 `C:/Windows` ⇒ 它落进命令头、
  //     不再判档 ⇒ blast 由 `system|C:/Windows` 变 `null|inside` —— 方向 fail-open。
  // 故判据取「该位置本来会不会被判档」，给出「放宽 = 0」的结构性保证。
  //
  // ── 故判据是「**该位置本来会不会被判档**」——它给出「放宽 = 0」的**结构性**保证 ─────────
  // 守卫取 `mayYieldRadiusTier(w[upto], undefined)`（判据本身在 `mayNeedBlastCheck` 旁边，
  // 与判档循环的三条产档路径同源）。
  //
  // ── ⚠️ 本守卫**不能**只取 `mayNeedBlastCheck`（那是真实放宽）────────────────────
  // `mayNeedBlastCheck` 返假**推不出**「跨过它不丢半径档」：判档循环里 `continue` 不是第一条
  // 产档路径，它前面还有「含空格词元的引号命令行递归支」与「`NAME=value` 取右侧值再判档」两条，
  // 它们对纯词元形态照样成立。守卫返假 ⇒ `privOperandSkip` 跨过 `upto` ⇒ 该词元落进命令头、
  // 不再判档（`su --command=x "rm -rf Windows" rm` 由 ask 变 allow）。
  //
  // 修法是补上那两条产档路径：`mayYieldRadiusTier` 把三条路径合并成一条**上界**判据 ——
  // 含空格词元一律视为「会判档」（引号支收窄需要 split + 逐词查表，与 O(1) 纪律冲突）、
  // `NAME=value` 取右侧值再问同一个预筛、其余照旧走预筛。上界判据返真 ⇒ 更少跨越 ⇒ 只会收紧。
  //
  // `platform` 传 `undefined` 是**有意的 fail-safe 方向**：`privValueFlagBetween` 拿不到
  // `opts`（签名与调用链 `privOperandSkip` ← `commandHeadEnd` ← `blastRadiusOfSegment`
  // 都不传平台，与 `isOperandShapedWord` 同一处境），而平台未知时 `mayNeedBlastCheck`
  // **两张表都查** ⇒ 判据比 win32 / posix 任一分支都**更宽** ⇒ 更多词元走「确有目标」支
  // ⇒ 更少跨越 ⇒ 更接近现状（放宽方向的错误恰是「该守的没守」，故这里宁宽勿窄）。
  //
  // ⚠️ 这一支**不得**带到 `isPrivOperandWord` —— 见 `isPrivCommandValueFlag` 的说明。
  //
  // ── ⚠️ 如实记录：本口径与**真实 `su` 语义**不一致（本实现**故意**取保守侧）──────────────
  // 真实 `su` 里 `--command=<值>` 的值**就是**要执行的命令，故
  //     su --command=x root rm -rf /tmp
  // 的真实语义是「以 `root` 身份执行 `x`，把 `rm -rf /tmp` 当作 `x` 的**参数**」——
  // `rm` **不会**被执行，因此「CUR 判 `null`」按真实语义读**并非漏报**。
  // 本实现仍按「连写形态后面那个词元才是真命令」的口径处理（即 finding 的口径），
  // 理由是**同一文件里另一处已经这样承诺**：操作数侧（`isPrivOperandWord`，见
  // `isPrivCommandValueFlag` 的注释）只认精确的 `-c` / `--command`，且写着「连写形态在这里
  // 停下是**错的**：它后面那个词元才是真命令」。两处口径相反会比本缺陷更糟 ——
  // 「命令头到哪儿」与「命令名是谁」必然分叉，那正是本文件反复要修的那类缺陷。
  // 故本支的方向是**故意偏保守**：真实语义下该形态会被**多问一次**（收紧方向，
  // 永不违反策略）；代价是畸形写法会弹窗，收益是「同一文件只有一份口径」。
  // 若日后决定改用真实 `su` 语义，需要动的是**这一处**与操作数侧那一处（两处必须同时改，
  // 否则又回到分叉状态）。
  //
  // 成本：`mayYieldRadiusTier` 在一次调用里**至多算一次**（`joinedProtects` 记忆化），
  // 且只在真的遇到连写词元时才求值；无正则新增、无分配 —— 与 `isPrivOperandWord` 的
  // 「查表 + 一次 `indexOf`」同一条 O(1) 纪律（见 `isPrivCommandValueFlag` 的性能段）。
  let joinedProtects = -1
  for (let k = from; k < upto; k += 1) {
    const t = String(w[k])
    if (isPrivCommandValueFlag(t)) return true
    if (t.indexOf('--command=') === 0) {
      if (joinedProtects < 0) {
        joinedProtects = upto < w.length && mayYieldRadiusTier(String(w[upto]), undefined) ? 1 : 0
      }
      if (joinedProtects === 1) return true
    }
  }
  return false
}

/**
 * 路由器命令的**两词 label**（`reg` + `delete` → `reg delete`）—— 与 `segmentLabel`
 * 的 router 分支同口径：跳过选项与带值选项，取第一个非选项词元作子命令。
 *
 * 为什么单独抽出来（而不是留在 `privOperandSkip` 里当闭包）：`isPrivOperandWord`
 * 也要用它 —— 见 `isTargetEatingNameIn` 的说明。两处若各写一份「什么算两词 label」，
 * 「操作数跨到哪儿」与「label 有哪些」必然分叉，那正是本次缺陷的成因。
 *
 * 与 `segmentLabel` 的 router 分支的**唯一**差别：那里只看选项**形态**
 * （`raw.startsWith('-')`），这里额外滤掉含空白的词元与认不出的词元（与
 * `commandHeadEnd` / `segmentLabel` 对「引号包起来的整条命令行」的判据一致），
 * 故 `su root reg "a b"` 不会拼出假 label。
 *
 * 成本：首行即有 `ROUTER_CMDS` 守卫（非路由器命令立即返回空串），
 * 且下面的扫描有**常数上限**（见 `ROUTER_SUB_SCAN_MAX`）—— 故调用方在任何输入下都是 O(1)。
 *
 * ── 为什么必须加上限：调用方是**逐词元**的贪婪扫描────────────────────────
 * `isTargetEatingNameIn` 由 `isPrivOperandWord` 对**每一个**词元各调一次，而本函数此前
 * 从该下标**向后扫到段尾**（`for (let t = idx + 1; t < w.length; …)`）—— 两者相乘即 O(n²)。
 * 触发形态是「`su` 后跟『路由器名 + `ROUTER_OPT_VALUE` 带值选项』的重复序列」，
 * 且**路由器名必须写成路径形态**（`/reg --config /reg --config …`）：裸名 `reg` 会被
 * 操作数扫描的上界（`isOperandShapedWord`）提前挡住，故只有路径形态能一路走到这里。
 * 实测（`segmentLabels` 单次调用、修复前）：
 *   `su (/reg --config)*n` → n=4000 **138.5 ms**、n=8000 **556.8 ms**（倍率 4.02，标准平方），
 *   同形态的 `blastRadiusOfSegment` n=8000 → **1120.5 ms**（倍率 3.95）。
 *   对照裸名 `su (reg --config)*n` 修复后 n=8000 仅 **0.6 ms**（线性）。
 * 该路径在 `index.js` 的 buildCandidates 里**同步**执行、早于 `pendingApprovals.set`，
 * 词元由 AI 生成、长度无上界 —— 直接推迟弹窗。
 *
 * @param {string[]} w 词元列表
 * @param {number} idx `w[idx]` 是路由器命令名（小写，已过 `commandNameOf`）
 * @returns {string} 两词 label（拼不出时为空串）
 */
function routerSubLabelOf(w, idx) {
  const n = commandNameOf(w[idx])
  if (!ROUTER_CMDS[n]) return ''
  // 扫描上限：**两个维度各一个**（见 `ROUTER_SUB_SCAN_MAX` 的注释）。
  //   · 词元维度 —— 纯词元数的硬上界，防病态输入下打转（与 `segmentLabel` 里
  //     `guard < 8` 那条是同一类纪律）；
  //   · 带值选项维度 —— 跳过的带值选项**次数**上限。少了它，**同一个键重复出现**
  //     会击穿词元上界（`su root reg (-c v)*32 delete …` 有 70 个词元，`delete` 扫不到，
  //     `reg delete` label 丢失、`headEnd` 由 3 掉回 1）。
  const stop = Math.min(w.length, idx + 1 + ROUTER_SUB_SCAN_MAX * 2 + 8)
  let valueOpts = 0
  for (let t = idx + 1; t < stop; t += 1) {
    const rawTok = String(w[t])
    if (/\s/.test(rawTok)) return ''
    if (rawTok.charAt(0) === '-') {
      if (ROUTER_OPT_VALUE[rawTok]) {
        valueOpts += 1
        if (valueOpts > ROUTER_SUB_SCAN_MAX) return ''
        t += 1
      }
      continue
    }
    const sub = commandNameOf(rawTok)
    if (!sub || BAD_LABEL_CHARS.test(sub)) continue
    return n + ' ' + sub
  }
  return ''
}

/**
 * `w[idx]` 是不是「**吃目标的命令名**」—— 破坏性名单 ∪ 载荷族 ∪ **两词 label**。
 *
 * ── 为什么必须单列成模块级函数（单一来源）─────────────────────────────────────
 * 这个判据同时被两处消费，而两处**必须**逐字同源：
 *   · `privOperandSkip` —— 决定「`su` / `runas` 的操作数该不该跨过」；
 *   · `isPrivOperandWord` —— 决定「某个词元算不算操作数」。
 * 后者是前者的**入口判据与贪婪扫描判据**，两者分叉的后果是**结构性漏判**：
 * 贪婪扫描把真命令名本身当成操作数吃掉，于是推进步根本停不到它上面 ——
 * 只修 `privOperandSkip` 的跨越理由救不回来（它压根没机会被问到）。
 *
 * ── 实测（八档、proc/power/reg=deny、priv=allow，修复前）─────────────────────────
 * 只认 `isDestructiveLabel`（不认载荷族与两词 label）时：
 *     su root reg delete HKLM\X /f   → **allow**（labels 只有 ['su']，reg delete 不可见）
 *     su root find /data -delete     → **allow**（labels 只有 ['su']，find 不可见）
 * 而对照 `sudo reg delete …` 是 deny、`sudo find /data -delete` 是 ask ——
 * 同一件事只因前缀不同就分叉，方向是 **fail-open**。这两条覆盖的正是 `segmentLabel`
 * 里**既有**的两条识别口径（router 两词 label、`find -exec`/`-delete` 载荷族），
 * 故本判据与 `segmentLabel` 同源，不新造分类。
 *
 * @param {string[]} w 词元列表
 * @param {number} idx 待判词元的下标
 * @param {string} name `commandNameOf(w[idx])`（调用方已算出，避免重复解析）
 */
function isTargetEatingNameIn(w, idx, name) {
  if (isDestructiveLabel(name)) return true
  if (PAYLOAD_CARRIERS[name] === 1) return true
  return isDestructiveLabel(routerSubLabelOf(w, idx))
}

/**
 * 单个词元 `w[next]` 本身是不是操作数（**O(1)**，不做区间扫描）。
 *
 * 与 `isPrivOperandToken` 的分工：那个额外检查「前缀的选项里有没有 `-c`」（要看一整段），
 * 这个只看一个词元。拆开是**性能要求**：`privOperandSkip` 要连续扫完一整段操作数，
 * 若每轮都重扫区间，`su u1 u2 … un`（n 个操作数）就是 O(n²) —— 实测 n=16000 时
 * 单次判定 3028 ms（倍率≈4.0/倍，标准平方）。本文件其他几处平方退化（`unwrapWords(w.slice(j))`、
 * 尾部斜杠的 `replace(/\/+$/)`）都是同一类问题：词元由 AI 生成、长度无上界，
 * 而这是判定热路径。拆开后整段扫描是 O(n)。
 *
 * ── 「吃目标的命令名」**不算操作数**（否则贪婪扫描会把它自己吃掉）─────────────────
 * 判据复用 `isTargetEatingNameIn` 单点。缺了这一条的后果实测（修复前）：
 *     su root find /data -delete     → allow（`find` 被当操作数吃掉；`/data` 又因 `data`
 *                                      是语句关键字而停下；链推进看到 `-delete` 不是
 *                                      吃目标的命令名 → 不跨 → `find` 整个不可见）
 *     su root reg delete HKLM\X /f   → allow（`reg` 单名不在名单里，连 `delete` 一起被吃光）
 * 两者都与 `sudo` 对照分叉，方向 fail-open。这条判据同时也让 `su find …`（无操作数）
 * 保持原行为：入口即判「不是操作数」→ 不跨 → 命令头照旧停在 `su` 之后，
 * 与修复前逐字一致（`privOperandSkip` 在那里本来也返回 `at`）。
 */
function isPrivOperandWord(w, prefix, next) {
  if (PRIV_VALUE_IS_COMMAND[prefix] !== 1) return false
  if (next >= w.length) return false
  // 值选项自身（`-c` / `--command`）不是操作数：它的值才是命令或目标。
  //
  // ⚠️ 此处**只认精确的 `-c` / `--command`**（窄判据；`isPrivCommandValueFlag` 已无
  // `joined` 形参，连写形态由门控侧 `privValueFlagBetween` 自己判）：
  // `--command=<值>` 连写形态**不是**「值选项自身」—— 它的值已经在词元里，
  // 它后面那个词元才是真命令。若在此把它也算命中，贪婪扫描会在第二个词元就收束
  // （`su root --command=x rm -rf /tmp` 的 `commandHeadEnd` 由 **4 停在 1**），
  // 真命令与真目标一起被排除在命令头之外 → 段级 blast 归 `null` → 半径档落 `inside`
  // → `priv=allow` 时**静默放行**（实测放宽 540 格 / 收紧 0 格，见
  // `isPrivCommandValueFlag` 的实测段）。窄判据即本行修复前的行为，此处恢复它。
  const t = String(w[next])
  if (isPrivCommandValueFlag(t)) return false
  const name = commandNameOf(w[next])
  if (!name) return false
  if (WRAPPERS[name] === 1 || PRIV_PREFIXES[name] === 1 || STATEMENT_KEYWORDS[name]) return false
  return !isTargetEatingNameIn(w, next, name)
}

/**
 * `w[i]` 是否**长得像操作数的一部分**（`privOperandSkip` 的扫描上界，见那里的说明）。
 *
 * 判据只有一条：**选项形态** —— `-x`（`-` 开头）或 `/x:y`（`/` 开头、第二个字符是字母、
 * **含 `:`**，即 Windows 风格开关的实际词法特征）。
 *
 * 为什么是「选项形态」而不是「是不是用户名」：`su` / `runas` 的操作数**没有**统一词法形态
 * （`su root` 的 `root` 是用户名、`runas /user:admin` 的 `/user:admin` 是开关），
 * 而 `skipPrefixArgs` 刻意**不吃 `/` 开头**（POSIX 上 `/` 是路径分隔符，见其注释里
 * `nice /usr/bin/find / -delete` 那组实测）—— 于是 `/user:admin` 之类会停在「操作数」位置上。
 * 故扫描只能跨「第一个词元」+「选项形态的词元」，其余一律停：
 * `su root ls C:/Windows` 的 `ls`、`su root cat /etc/hosts` 的 `cat` 都不是选项形态，
 * 扫描停在那里，真命令与真目标留在命令头之外参与判档。
 *
 * ⚠️ **`/x` 形态是必需的**：`runas /noprofile /user:admin rm -rf /data` 的第二个操作数
 * 是 `/user:admin`，少了这一支就跨不过去 —— 而该形态实测在 HEAD 下判 null（漏报），
 * 54d 钉的正是它。注意第一个操作数（`/noprofile`）**不靠本判据**：`privOperandSkip`
 * 的 `k === at` 那一支无条件认它（见那里的说明），故「含 `:`」不会把 54d 弄丢。
 *
 * ── ⚠️ 本判据**只对 `su` 成立**：`runas` 的开关恒为**不含 `:`** 的单段 `/x` ────────────
 * 见 `isRunasSwitchShapedWord`（`privOperandSkip` 按前缀分派到它）。本函数要求 `/x` 含 `:`，
 * 是因为 `su` 是 POSIX 命令，`/etc`、`/tmp` 这类**单段 POSIX 路径**必须留在外面（下面的
 * 113 条实测）；而 `runas` 是 Windows 命令，其开关（`/noprofile` `/savecred` `/netonly`
 * `/profile` `/env` `/smartcard` `/showtrustlevels`）**全部不含 `:`**，`/user:admin` 反而是
 * 唯一带 `:` 的那个 —— 把本判据套到 `runas` 上会让扫描停在第二个开关上、真命令与真目标
 * 留在命令头之外（方向同样是 fail-open，实测见 `isRunasSwitchShapedWord`）。
 *
 * ── ⚠️ 本判据**不是** `isCmdStyleSwitch` 的同口径副本（曾如此自称，已分叉）──────────
 * 两者形似而**判据不同**，`isCmdStyleSwitch` 是**平台感知**的：
 *     `if (!(opts && opts.platform === 'win32')) return false`   // posix 恒 false
 * 而本函数**拿不到 opts**（签名只有 `token`，调用链 `privOperandSkip` ← `commandHeadEnd`
 * ← `blastRadiusOfSegment` 都不传平台），故改用**词法**判据替代平台判据：Windows 的
 * cmd 风格开关几乎都带 `:`（`/user:admin`、`/grant:r`、`/pid:1234`），而 POSIX 绝对路径
 * 的**单段**形态（`/etc`、`/tmp`、`/root`、`/data`、`/opt`、`/home`）与 Windows 盘符路径
 * （`D:/data`）都不含 `:`。
 *
 * 少了这条 `:` 判据的后果（**本批新引入的 fail-open 回归**，实测）：
 *     `su root /etc rm`、`su - cat /etc rm`、`su - ls /tmp rm`、`su - ls /etc -exec rm -rf {} +`
 * 的单段路径被当成「Windows 开关」跨过 → 命令头越过真命令与真目标 → 段级 blast 归 null
 * → 半径档落 `inside` → `priv=allow` 时由 HEAD 的 **ask** 变 **allow**。
 * 三方差分（本文件对拍语料 3772 条叉乘、逐条比段级 blast）：无 `:` 判据时
 * HEAD 有值而本版为 null 的 **113 条**里，**95 条 `blast.path` 是真实路径目标**
 * （`/etc` `/tmp` `/root` `/opt` `/home` `/usr` `/var` `/etc/hosts` `/data` `C:/data`
 * `D:/data` `C:/Windows` `C:/Users/me`），其余 18 条才是 `runas` 操作数自身的假警告。
 * 该形态**恰好落在「多段/含冒号」的缝外**（`C:/Windows`、`/usr/bin/rm` 有第二个 `/`
 * 而不被误判），故 54j/54k/54l 三套断言全绿也照不出它 —— 见 54n 的守卫。
 *
 * @param {string} token 待判词元
 */
function isOperandShapedWord(token) {
  const t = String(token == null ? '' : token)
  if (!t) return false
  if (t.charCodeAt(0) === 45) return true          // `-x` / `--long`
  // `/x:y`（Windows 风格开关）。单字符 `/`、多段路径（`/usr/bin`）与**单段 POSIX 路径**
  // （`/etc`、`/tmp`）都不算：前者第二个字符不是字母，中者含分隔符，后者不含 `:`。
  return t.charCodeAt(0) === 47 && /^\/[a-z]/i.test(t) && t.indexOf('/', 1) === -1
    && t.indexOf(':') !== -1
}

/**
 * `w[i]` 是不是 `runas` 的**开关**（`privOperandSkip` 扫描上界的 `runas` 支）。
 *
 * ── 为什么必须与 `isOperandShapedWord` 分开：两个前缀的操作数**词法不同** ────────────
 * `isOperandShapedWord` 那条「含 `:`」的守卫是为 `su` 立的 —— `su` 是 POSIX 命令，其后
 * 的单段路径（`/etc`、`/tmp`、`/root`、`/data`）必须**留在命令头之外**参与判档（少了这条
 * 守卫的实测：HEAD 有值而本版为 null 的 113 条里 95 条 `blast.path` 是真实路径目标）。
 *
 * 而 `runas` 是 **Windows** 命令，它的开关与 POSIX 路径的**词法恰好相反**：
 *     · 开关 —— `/noprofile` `/savecred` `/netonly` `/profile` `/env` `/smartcard`
 *       `/showtrustlevels`：**单段、不含 `:`**（官方语法里 `/user:` 是唯一带 `:` 的）；
 *     · 操作数 —— `/user:<名>`：单段、**含 `:`**。
 * 把「含 `:`」的守卫套到 `runas` 上，于是**第二个及以后的不含 `:` 开关**被判成「不是开关」
 * → 扫描停在那里 → 命令头停在下标 1 → 真命令与真目标全留在命令头之外 → 段级 blast 归 null
 * → 半径档落 `inside`。方向是 **fail-open**，且触发形态**符合 `runas` 官方语法顺序**
 * （`/user:` 写在最后）：`runas /profile /savecred /user:admin rm -rf /tmp`。
 * 实测（win32，A = 去掉该守卫、B = 加守卫后；`blast.level|blast.path`）：
 *     `runas /noprofile /user:admin rm -rf /tmp`   A=`outside|/tmp`  B=`outside|/tmp`（首位靠 `k === at`）
 *     `runas /profile /savecred /user:admin rm -rf /tmp`   A=`outside|/tmp`  B=**`null`**
 *     `runas /profile /netonly /user:admin rm -rf /tmp`    A=`outside|/tmp`  B=**`null`**
 * 因果钉死：把 `/savecred` 改成 `/savecred:x`（**只加一个冒号**）即恢复 `outside|/tmp`。
 * 端到端（用户可见后果，B 相对 A）：显式 deny 例外 `rm *` 由 **deny 变 ask**（用户写的拒绝
 * 失效）、组档 `reg=deny` 的 `… reg delete HKLM\X /f` 由 deny 变 **inherit**、`proc=deny` 的
 * `… kill 1234` 由 deny 变 **inherit**、`outside=deny` 由 deny 变 **inherit**、
 * `outside=ask+priv=allow` 由 ask 变 **allow**。
 * 覆盖面：win32「非首位不含 `:` 开关」形态里 **45 条动作相对修复前改变**。
 *
 * ── ⚠️ 判据**不能**放宽到「单段 `/x` 一律算开关候选」（曾经如此，是 fail-open 回归）──────
 * 上一版把 `runas` 支写成「单段 `/x` 一律算开关」，理由是「`runas` 的位置参数就是命令，
 * `runas /profile /etc rm` 本就不是合法调用，且 blast 仍由真命令与真目标决定」。
 * **实测该理由不成立 —— 真目标恰恰被跨过了**（`runas /noprofile /etc rm` 的 `/etc`）：
 * 单段 `/x` 这个形态里**同时**住着两类词元，而它们**必须分开**：
 *     · `runas` 的开关 —— `/noprofile` `/profile` `/savecred` …（该跨）；
 *     · **单段 POSIX 路径目标** —— `/etc` `/tmp` `/usr` `/var` `/opt` `/root` `/srv`（不该跨）。
 * 两者词法完全同形（单段、`/` 开头、第二个字符是字母、不含第二个 `/`），故「一律算开关」
 * 等于把**真目标**当开关跨过 → `privOperandSkip` 越过真目标、`commandHeadEnd` 把整段跳空
 * → 段级 blast 归 `null` → 半径档落 `inside`（方向 fail-open）。
 *
 * 实测（插桩 `commandHeadEnd` 的返回值，`runas /noprofile /etc rm`）：
 *     HEAD 与修复前 `headEnd=1`（`/etc` 留在命令头外当目标）；**放宽版 `headEnd=4`**
 *     （`/etc` 与 `rm` 全被吃进命令头）。逐条比段级 `blast.level|blast.path`：
 *     · **posix 侧相对 HEAD 是硬回归**：`runas /noprofile /etc rm`、`runas /user:a /etc rm`、
 *       `runas /profile /etc rm` 由 HEAD 的 `system|/etc` 变 `null`；触发面覆盖
 *       `/etc` `/tmp` `/usr` `/var` `/opt` `/root` `/srv` `/etc/hosts` 等单段路径。
 *     · win32 侧由修复前的 `outside|/etc` 变 `null`（HEAD 本就是 null）—— 中间态回归。
 *     · 端到端（`category=allow`、`priv=allow`）：`runas /user:a /etc rm`、
 *       `runas /noprofile /etc rm`、`runas /profile /etc rm` 在八档默认下 **ask→allow**、
 *       `outside=deny` 下 **deny→allow**；`runas /user:a /etc rmdir /data` 在
 *       `outside=deny` 下 **deny→ask**。
 *
 * ── 收窄后的判据：**含 `:` 的 cmd 风格开关** ∪ **`runas` 已知开关白名单** ──────────────
 * 两类合起来正好覆盖 `runas` 官方语法的**全部**开关与操作数，而单段 POSIX 路径两条都不满足：
 *     · 含 `:` —— `/user:<名>`、`/trustlevel:<n>`（cmd 风格开关的实际词法特征）；
 *     · 白名单 —— `RUNAS_SWITCHES` 里那 8 个**不含 `:`** 的开关（`/noprofile` `/savecred` …）。
 * 该收窄**不需要牺牲 54o 的收益**（实测：`runas /profile /savecred /user:admin rm -rf /tmp`
 * 仍是 `outside|/tmp` —— 第 2 个开关走白名单、`/user:admin` 走 `:` 支）。
 * **收窄只对本函数（`runas` 支）生效** —— `su` 支仍是 `isOperandShapedWord` 的 `:` 判据
 * （它连白名单都不需要：`su` 的操作数是**裸用户名**，本来就靠 `k === at` 那一支通过）。
 *
 * 上界仍是**两条**（与 `isOperandShapedWord` 支同构，只是判据换成下面这一条）：
 *   · `k === at` —— `skipPrefixArgs` 停下的第一个操作数，无条件算候选；
 *   · 其后**只有** `runas` 开关形态（cmd 风格开关或 `-x`）才可能是操作数的一部分。
 *
 * @param {string} token 待判词元
 */
function isRunasSwitchShapedWord(token) {
  const t = String(token == null ? '' : token)
  if (!t) return false
  if (t.charCodeAt(0) === 45) return true          // `-x` / `--long`
  // 单段 `/x`。多段路径（`/usr/bin/find`）与单字符 `/` 不算 —— 这一条与 `isOperandShapedWord` 同。
  if (t.charCodeAt(0) !== 47 || !/^\/[a-z]/i.test(t) || t.indexOf('/', 1) !== -1) return false
  // 含 `:`（`/user:admin`、`/trustlevel:2`）或在已知开关白名单里（`/noprofile`）。
  // **单段 POSIX 路径（`/etc`、`/tmp`）两条都不满足** → 留在命令头之外当目标参与判档。
  return t.indexOf(':') !== -1 || RUNAS_SWITCHES[t.toLowerCase()] === 1
}

function isPrivOperandToken(w, prefix, from, next) {
  if (PRIV_VALUE_IS_COMMAND[prefix] !== 1) return false
  if (next < from || next >= w.length) return false
  if (privValueFlagBetween(w, from, next)) return false
  return isPrivOperandWord(w, prefix, next)
}

/**
 * `su` / `runas` 的**操作数**该不该被跨过 —— 命令头推进的单点。
 *
 * `skipPrefixArgs` 对这两个前缀的带值选项表刻意留空（值可能是命令也可能是目标，
 * 见 `PRIV_VALUE_FLAGS`），于是它停在**操作数**上：`su root rm -rf /data` 停在 `root`、
 * `runas /user:admin rm -rf /data` 停在 `/user:admin`。命令头若到此为止，真命令名
 * 就留在外面被当成**目标实参**，而门控侧（`headCommandNameOf`）还会把操作数当命令名
 * 交去查命令域 → `/data` 被当开关跳过 → 段级 blast 归 null → 档位 `inside`
 * → 提权档设为 allow 时**静默放行**。实测（win32、priv=allow）：`su root rm -rf /data`、
 * `runas /user:admin rm -rf /data`、`runas /user:admin del /data` 全部 allow，
 * 而对照 `sudo -u root rm -rf /data` 是 ask —— 同一件事只因前缀不同就分叉。
 *
 * **只在「操作数之后确实是命令名」时才跨过它**，判据与 `commandHeadEnd` 的 ② 分支逐字同源
 * （对 `su` / `runas`，② 只在 `isDestructiveLabel(base)` 成立时吃掉那个词元）。少了这条限制，
 * `su root`（后面没有命令）会停在 `root` 上、`headCommandNameOf` 随即把操作数当命令名返回
 * —— 正是要修的那个形态。`su -c C:/Windows` 一族（值就是目标）同样靠它保住既有行为：
 * `-c` 之后那个词元不是破坏性命令名，命令头照旧停在前缀处。
 *
 * **本函数是 `commandHeadEnd` 与 `headCommandNameOf` 的共用推进步**：两处若各写一份，
 * 「命令头到哪儿」与「命令名是谁」必然再次分叉 —— 那正是本次缺陷的成因。
 *
 * @param {string[]} w 词元列表
 * @param {string} prefix 前缀命令名（小写，已过 commandNameOf）
 * @param {number} from 前缀命令名之后的下标（`skipPrefixArgs` 的起点）
 * @param {number} at `skipPrefixArgs` 的返回值（停在哪儿）
 * @returns {number} 推进后的下标（未跨过时与 `at` 相同）
 */
function privOperandSkip(w, prefix, from, at) {
  if (at >= w.length || !isPrivOperandToken(w, prefix, from, at)) return at
  // 操作数**可能不止一个**：`runas /noprofile /user:admin rm -rf /data` 里
  // `/noprofile` 与 `/user:admin` 都是操作数，真命令名在第三个词元上。只跨一个词元仍会漏，
  // 故连续扫完操作数，再判断它后面跟的是不是命令头元素。
  //
  // 这一段用 **O(1)** 的 `isPrivOperandWord`（而不是 `isPrivOperandToken`）：后者要扫
  // 「前缀选项里有没有 `-c`」，若每轮都重扫区间，`su u1 u2 … un` 就是 O(n²)。`-c` 那件事
  // 在进入本循环前已由上面那次 `isPrivOperandToken` 判过，循环内的词元都不是值选项。
  //
  // ── 扫描**必须有上界**：只有「第一个词元」与「选项形态的词元」才可能是操作数 ────────
  // 无条件贪婪会让扫描一路吞到段内那个恰好叫破坏性命令名的词元，把真命令与真目标一起吞进
  // 命令头（`su root ls C:/Windows kill` 使 `commandHeadEnd` 返回 5、段级 blast 归 null、
  // 半径档落 `inside`），方向是 fail-open。
  //
  // 上界的两条判据都是「操作数**形态**」，与 `skipPrefixArgs` 停在哪儿同源：
  //   ① `k === at` —— `skipPrefixArgs` 停下的那个词元就是第一个操作数
  //      （`su root` 的 `root`、`runas /user:admin` 的 `/user:admin`），无条件算候选；
  //   ② 其后**只有选项形态**（`/x` / `-x`）才可能是操作数的一部分 ——
  //      `runas /noprofile /user:admin rm -rf /data` 的两个 `/x` 都在这一支里（54d 依赖它），
  //      而 `su root ls …` 的 `ls`、`su root cat …` 的 `cat` 都不是，扫描就此停住，
  //      真命令与真目标留在命令头之外参与判档（这正是本函数要恢复的行为）。
  //
  // ── ⚠️ ② 的判据**必须按前缀分派**（曾经全局共用一条，是本批修复内部的收窄倒退）──────
  // `su` 与 `runas` 的操作数**词法不同**：`su` 是 POSIX 命令，其后单段路径（`/etc`、`/tmp`）
  // 必须留在外面，故要「含 `:`」的守卫；`runas` 是 Windows 命令，开关恒为**不含 `:`** 的
  // 单段 `/x`（`/noprofile` `/savecred` `/netonly` `/profile` `/env` `/smartcard`
  // `/showtrustlevels`），而操作数 `/user:<名>` 才是唯一带 `:` 的那个 —— 全局套用「含 `:`」
  // 会把**第二个及以后的不含 `:` 开关**判成扫描终点。
  // 实测（win32，A = 无该守卫、B = 有该守卫，`blast.level|blast.path`）：
  //     `runas /noprofile /user:admin rm -rf /tmp`          A=`outside|/tmp` B=`outside|/tmp`
  //       （首位那支靠 `k === at` 通过，故 54n 只钉首位形态时照不出这个倒退）
  //     `runas /profile /savecred /user:admin rm -rf /tmp`  A=`outside|/tmp` B=**`null`**
  //     `runas /profile /netonly /user:admin rm -rf /tmp`   A=`outside|/tmp` B=**`null`**
  //     `runas /netonly /savecred /user:admin rm -rf /tmp`  A=`outside|/tmp` B=**`null`**
  // 因果钉死：`/savecred` → `/savecred:x`（**只加一个冒号**）即恢复 `outside|/tmp`。
  // 触发形态符合 `runas` **官方语法顺序**（`/user:` 写在最后）。
  // 端到端（B 相对 A，用户可见后果）：显式 deny 例外 `rm *` 由 **deny 变 ask**（用户写的
  // 拒绝失效）、组档 `reg=deny` + `… reg delete HKLM\X /f` 由 deny 变 **inherit**、
  // `proc=deny` + `… kill 1234` 由 deny 变 **inherit**、`outside=deny` 由 deny 变
  // **inherit**、`outside=ask+priv=allow` 由 ask 变 **allow**。
  // 覆盖面：win32「非首位不含 `:` 开关」形态里 **45 条动作相对修复前改变**。
  // 故 ② 分派到 `isRunasSwitchShapedWord`（`runas`）与 `isOperandShapedWord`（其余）。
  //
  // ── ⚠️ 已知残余 ─────────────────────────────────────────────────────────
  // `su root <路径> <破坏性名>`（`su root /data kill`）仍会跨过那个路径词元（HEAD 判
  // `outside|/data`，本版为 null —— 方向 fail-open）。触发它的不是 `isOperandShapedWord`
  // 的 `/x` 分支，而是本函数下面另两处判据，两者都独立于 `/x`：
  //   ① `k === at` 那一支**无条件**认第一个操作数 —— `su - /etc rm` 的 `skipPrefixArgs`
  //      已把 `-` 吃掉，`at` 指向的是目标 `/etc`，却被当操作数跨过；
  //   ② 关键字链（③ 分支）按 `commandNameOf` 的 basename 认关键字 —— 全部
  //      `STATEMENT_KEYWORDS` 名都可被路径形态触发（`/data` `/in` `/for` …），于是目标
  //      词元被当关键字跳过，链一直推进到末尾的破坏性名。
  // 只给关键字链（③ 分支）加「路径形态不当关键字」守卫是可行修法（已落地）；给 `k === at`
  // 加路径形态守卫不行：`runas` 的首位开关 `/noprofile` 本身就是路径形态，会被挡在门外。
  //
  // ── ⚠️ 上面那个「LOST=0」只是 **blast 口径**；**tiers 口径并非 0**（措辞已按实测更正）──
  // 本批的 label 修复（`pushHeadLabels` 的「`at` 位置确实是操作数才终止」，它复用了本函数
  // 的推进步）让 `diskpart` 这类**真命令名首次进入 labels**，于是 `isUnknownTierSegment`
  // 的 `diskpart` + `/s` 支**首次命中**，posix 侧多出 **74 条 `outside → unknown`**
  // （验证者语料 10560 段比较、逐条打印 `tiers` 复核）：
  //     posix  `su diskpart /s script.txt`   PRE=`[outside,priv]` → CUR=`[unknown,priv]`
  //     win32  同形态                        PRE=`[priv]`         → CUR=`[unknown,priv]`
  // **该变化确属「与 sudo / 裸形态对齐」，不是新分叉**（实测三方差分：
  // CUR 的 `su …` == PRE 的 `sudo …` == CUR 的 `sudo …` == `[unknown,priv]`；
  // 裸形态 `diskpart /s script.txt` 的 PRE/CUR 均为 `[unknown]`）—— 即修掉的是 PRE 侧的
  // **异类**。win32 侧在这一形态下没有 `outside→unknown`（`/s script.txt` 的 blast 恒 null、
  // 本就没有半径档），只是由 `priv` 变成 `unknown,priv` —— 但**「win32 侧 blast 恒 null」
  // 只对这一形态成立**：`/s` 之后换成 win32 判得出半径的目标时，win32 侧同样有
  // `outside→unknown`（见下面的方向表，勿把它读成平台属性）。
  //
  // ⚠️ **方向随配置而变，不能只记「对齐」** —— 且**每一格都带条件**（见下表；此处曾把
  // 条件省略成「win32 allow→ask」「两侧都是 allow→deny」，实测那两格在 54w2 的配置下
  // 分别是 **ask→ask**、**ask→deny**，措辞已按 27 配置 × 2 平台的穷举实测更正）。
  //
  // 判据是「该形态**替换掉的半径档**是否原本在管它」：**在 `su diskpart /s script.txt`
  // 这一形态下**，PRE 的 tiers 为 posix `[outside,priv]` / win32 `[priv]`，CUR 一律
  // `[unknown,priv]`。故变化形态由 **`outside` 与 `unknown` 的相对严格度**决定，而 `priv`
  // 只在「PRE 侧根本没有半径档」时才会**顶上来决定动作**：
  //
  //   `outside=deny + unknown=ask`（54w2#1）：
  //     · posix —— `priv` 取 `ask` / `allow` 时都是 **deny→ask**（放宽方向：
  //       deny 来自 `outside`、ask 来自替换它的 `unknown`）；`priv=deny` 时 deny **反超**
  //       二者 → **deny→deny**（无变化）。故「posix 恒 deny→ask」是**过度概括**。
  //     · win32（仅 `script.txt` 形态）—— **视 `priv` 档**：`priv=ask` **无变化**
  //       （ask→ask，PRE 的动作本来就由 `priv` 决定）、`priv=allow` 时 **allow→ask**（收紧）、
  //       `priv=deny` 时 deny→deny。
  //   `unknown=deny`：
  //     · win32（仅 `script.txt` 形态）—— `priv=allow` 时 **allow→deny**、`priv=ask` 时
  //       **ask→deny**（都收紧，`unknown=deny` 比 `priv` 的任一档都严，故 `priv` 不改变结论）。
  //     · posix —— 需**同时** `outside=allow` 才是 **allow→deny**；`outside=ask` 时是
  //       **ask→deny**；`outside=deny` 时 **无变化**（deny→deny，两侧都严）。
  //   **八档缺省（`inside=allow`、其余 `ask`）下两平台均无任何变化**。
  //
  // ── 穷举实测（`su diskpart /s script.txt`，`(outside,unknown,priv) ∈ {allow,ask,deny}³` ──
  // = 27 配置 × 2 平台）：posix 变化 **10/27**、win32 变化 **9/27**，且**在这一形态下**
  // win32 侧的变化形态只有 `allow→ask`×3 / `allow→deny`×3 / `ask→deny`×3
  // （**无任何放宽方向**），posix 侧才有 `deny→ask`×3 与 `deny→allow`×1 这类放宽格。
  //
  // ⚠️ **「win32 侧无任何放宽方向」只是这一形态的结论，不是平台属性**（此处曾经那样写，
  // 属**过度概括**）。win32 的 PRE 档位集合**随 `/s` 之后的目标而变**，并不恒为 `[priv]`：
  // PRE 的档位集合是「半径档（仅当 blast 判得出时）∪ priv」，而 win32 的 blast **只在
  // `/s` 的目标判不出半径时为 null** —— 换成 win32 判得出半径的路径，PRE 就带上半径档，
  // 于是与 posix 同形，win32 侧**同样出现放宽**。实测（PRE = 把本函数「`at` 位置确实是
  // 操作数才终止」那一圈修复回退掉的副本，CUR = 本文件；27 配置逐格）：
  //
  //   `/s` 之后的目标        | win32 PRE.blast        | win32 PRE.tiers  | CUR.tiers      | 变化/27 | 收紧 | 放宽
  //   ----------------------|------------------------|------------------|----------------|--------|-----|----
  //   `script.txt`（锚点）    | null                   | `[priv]`         | `[unknown,priv]`|  9     |  9  | **0**
  //   `build/out.txt`        | null                   | `[priv]`         | `[unknown,priv]`|  9     |  9  | **0**
  //   `C:/scripts/d.txt`     | outside|C:/scripts/d.txt| `[outside,priv]` | `[unknown,priv]`| 10     |  5  | **5**
  //   `D:/scripts/d.txt`     | outside|D:/scripts/d.txt| `[outside,priv]` | `[unknown,priv]`| 10     |  5  | **5**
  //   `C:/Windows/Temp/d.txt`| system|…                | `[wide,priv]`    | `[unknown,priv]`|  9     |  6  | **3**
  //   `/etc/hosts`           | outside|/etc/hosts      | `[outside,priv]` | `[unknown,priv]`| 10     |  5  | **5**
  //   `/tmp/x`               | outside|/tmp/x          | `[outside,priv]` | `[unknown,priv]`| 10     |  5  | **5**
  //   `~/x`                  | outside|C:/Users/me/x  | `[outside,priv]` | `[unknown,priv]`| 10     |  5  | **5**
  //   `/`                    | drive-root|/           | `[wide,priv]`    | `[unknown,priv]`|  9     |  6  | **3**
  //   `C:/data` / `D:/data`  | outside|…              | `[outside,priv]` | `[unknown,priv]`| 10     |  5  | **5**
  //
  // **最小反例（自然形态）**：win32、`su diskpart /s C:/scripts/d.txt`、
  // `outside=deny, unknown=allow, priv=allow` → **PRE=deny、CUR=allow**
  // （PRE tiers `[outside,priv]` → CUR `[unknown,priv]`，blast 两侧同为
  // `outside|C:/scripts/d.txt`，即变化**不来自 blast**）。同类放宽格还有
  // `o=ask,u=allow,p=allow: ask→allow` 与 `o=deny,u=ask,p=allow: deny→ask` 等（共 5/27）。
  //
  // ⚠️ **「`wide` 恒 ask 不影响本族」同样不成立**（此处曾经那样写）：`wide` 是不是 ask
  // 由用户配置决定，而 win32 的 PRE **确实会带上 `wide` 档** ——
  // `su diskpart /s C:/Windows/Temp/d.txt` 的 win32 PRE 就是 `[wide,priv]`（blast=system）。
  // 实测（win32、`outside=ask,unknown=ask,priv=allow`、目标 `C:/Windows/Temp/d.txt`）：
  // `wide=ask` → PRE=ask；`wide=deny` → PRE=**deny**；`wide=allow` → PRE=**allow**，
  // 而 CUR 三种配置下恒为 ask（`[unknown,priv]` 不含 wide）。故 `wide` 在反例形态上
  // **确实参与决定 PRE 的动作**。
  //
  // **这不是新的根因**（与 F2 同源）：CUR 侧 `su` 与 `sudo` 在所有反例形态上**仍然同值**
  // （实测逐格 `su.tiers == sudo.tiers == [unknown,priv]`），对齐性质成立。
  // 但「win32 侧无需决策」的读法会**低估放宽面** —— 该族在 win32 上的放宽格数与 posix 同级
  // （`C:/scripts/d.txt` 一族 5/27、`wide` 一族 3/27），不是「只有 posix 才放宽」。
  // 「`outside=deny + unknown=ask` 下是否接受这个 deny→ask」属**设计侧决策**（记在
  // 项目外的设计笔记里），本函数不表态 —— 现状由 `test/shell-parse.mjs`
  // 的 **54w** 钉住（钉的是「与 sudo / 裸形态**同值**」这条对齐性质，不是某个动作值）。
  // 残余 ①（`k === at` 无条件认第一个操作数）**不在本次改动面内**：按「路径形态」守卫
  // 它同样会让上面 6 条断言变红，故如实记录、不掩盖残余。
  let k = at
  const operandShaped = prefix === 'runas' ? isRunasSwitchShapedWord : isOperandShapedWord
  while (k < w.length && isPrivOperandWord(w, prefix, k)
    && (k === at || operandShaped(w[k]))) k += 1
  if (k >= w.length) return at
  const after = String(w[k])
  // 含空白的词元是引号包起来的整条命令行（`su root -c "rm -rf /"`），不是命令名 ——
  // 与 commandHeadEnd / headCommandNameOf 同判据，留给子命令行递归。
  const afterName = after && !/\s/.test(after) ? commandNameOf(after) : ''
  if (!afterName) return at
  // ── 跨过操作数的条件是「它后面确实是**命令头的一部分**」────────────────────────
  // 三种形态都算，缺一不可：
  //   ① 破坏性命令名 —— `su root rm -rf /data`（判档要看的就是它后面的目标）；
  //   ② 另一个命令头元素（wrapper / 提权前缀）—— `su root env FOO=1 rm -rf /data`、
  //      `su root sudo rm -rf /data`：跨过操作数后由循环自己的 ① 分支接着往下剥；
  //   ③ **语句关键字** —— `su root time rm -rf /data`、`su root ! rm -rf /data`：
  //      `commandHeadEnd` 刻意**不认识**关键字（见其注释），跨到关键字就会**停在那里**
  //      （`sawPrefix` 分支被 PRIV_VALUE_IS_COMMAND 挡住、关键字也不在破坏性名单里），
  //      于是 `headEnd` 指向关键字、`headCommandNameOf` 取 `w[headEnd-1]` 拿回**操作数**。
  //      故这一支必须把「操作数 → 关键字/wrapper/前缀 链 → 破坏性命令名」整段走完，
  //      返回**破坏性命令名本身的下标**（而不是关键字的下标）—— 循环落在它上面即命中 ②
  //      并吃掉它，`headEnd - 1` 正是那个命令名。
  //      实测（win32、priv=allow）：①②③ 三种形态此前段级 blast 全是 null、动作 allow，
  //      而同目标的 `time rm -rf /data` 是 outside/ask —— 与本函数要修的 ① 是同一根因，
  //      只是操作数与真命令名之间多夹了一层。
  // 都不是时**不跨**：`su root`（后面没有命令）、`su root ls`、`su root x` 保持原状，
  // 否则 `headCommandNameOf` 会把操作数后面的任意词元当命令名返回（`su root x` 的 `x`）。
  //
  // ── 这里**不能**再写「后跟 wrapper / 提权前缀就跨」的无条件分支（曾经有，是个漏报）────
  // 曾经是：`if (isDestructiveLabel(afterName)) return k` 之后紧跟
  // `if (WRAPPERS[afterName] === 1 || PRIV_PREFIXES[afterName] === 1) return k` ——
  // 于是「操作数 + wrapper + **纯路径目标**」（`su root env /etc`、`su root sudo C:/Windows`）
  // 也把操作数跨过去了。而 wrapper/前缀之后并没有命令名，`commandHeadEnd` 的循环于是
  // 落进 ① 分支、`prevPrefix` 被改写成那个 wrapper，`!PRIV_VALUE_IS_COMMAND[prevPrefix]`
  // 成立（该表只登记 su/runas）→ **真目标被当命令名吃掉** → 段级 blast 归 null
  // → 档位 inside → `priv=allow` 时**静默放行**。实测（win32、priv=allow）：
  //     `su root sudo C:/Windows` 由 HEAD 的 ask 变成 allow，
  //     而同目标的 `su root C:/Windows` 仍是 ask —— 同一件事只因多一个 wrapper 就分叉；
  //     HEAD 判 system/home/drive-root 的 130 条形态（posix 247 条）全部失去警告。
  // 方向与本函数的 ①（该跨没跨）相反：这里是**不该跨却跨了**。
  //
  // 判据收敛为一条：**只有链上真的出现「吃目标的命令名」才跨**（①②③ 合并成下面
  // 那个循环）。注意 `isDestructiveLabel(afterName)` **也不能**单独提前返回 ——
  // 提权名本身就在 `DESTRUCTIVE_LABELS` 里（§9.4），`su root sudo C:/Windows` 的
  // `afterName` 正是 `sudo`，提前返回等于又变回无条件跨过（实测该形态仍判 null）。
  //
  // ── 「吃目标的命令名」= 破坏性名单 ∪ 载荷族（不只是 `isDestructiveLabel`）──────────
  // 只认破坏性名单会**漏掉载荷族**（`find` / `env` / `xargs` …，见 PAYLOAD_CARRIERS）：
  // `su root env find /data -delete` 的操作数之后是 `env`（wrapper，链推进里处理）再是
  // `find` —— `find` **不在** `DESTRUCTIVE_LABELS` 里（它的破坏性来自后续 `-delete` /
  // `-exec`），于是判成「不跨」→ 命令头停在操作数上 → `headCommandNameOf` 取回 `root`
  // → `isCmdStyleSwitch('/data', …, 'root')` 认不出命令域 → **`/data` 被当 cmd 开关跳过**
  // → 段级 blast 归 null → 档位 `inside` → 真删除命令静默。
  // 实测（端到端、win32、priv=allow）：`su root env find /data -delete` 与
  // `su root sudo find /data -delete` 由 **ask** 变成 **allow**，而对照的
  // `env find /data -delete` 仍是 ask —— 同一件事只因多一个 `su` 操作数就分叉，
  // 正是本文件反复要修的那类分叉（方向是**漏报**，比假警告严重）。
  // 故跨越理由必须与 `commandHeadEnd` 的 ② 同口径地覆盖载荷族：那里是
  // `sawPrefix && !PRIV_VALUE_IS_COMMAND[prevPrefix]`（前缀之后一律当命令名），
  // 本处更保守 —— 只有确认「是命令域成员」才跨，故 `su root /etc`（纯路径）仍不跨。
  // 复用 `PAYLOAD_CARRIERS` 单点（与 `isPayloadCarrierLabel` / `canCarryDestructivePayload`
  // 同一份表），不另抄一份「什么算载荷族」。链推进里 wrapper 已由上一支处理，
  // 故这一支实际贡献的是 `find` 这类**非 wrapper 的载荷族**。
  //
  // ── 判据必须与 `segmentLabel` 的**两词 label** 口径对齐（`reg delete`）─────────────
  // 这里一度只看**单个**词元（`isDestructiveLabel(n)`），而 `DESTRUCTIVE_LABELS` 里有
  // **两词**成员（`reg delete`，见注册表组），路由器命令的子命令正是靠 `segmentLabel`
  // 的 router 分支拼成两词的。于是 `su root reg delete HKLM\X /f` 判成「操作数之后不是
  // 吃目标的命令名」（`reg` 单独不在名单里）→ 不跨 → 命令头停在 `root` 上 → `reg delete`
  // 整个不可见：实测（八档、reg=deny、priv=allow）该形态 **allow**，而对照
  // `reg delete HKLM\X /f` 与 `sudo reg delete HKLM\X /f` 都是 deny —— 与上面那条
  // 前缀分叉同源，只是分叉点在「两词 label」上。
  //
  // 判据收敛到 `isTargetEatingNameIn` **单点**（与 `isPrivOperandWord` 共用同一份）：
  // 两处若各写一份，贪婪扫描仍会把 `reg` / `find` 当操作数吃掉、推进步根本停不到它们
  // 上面，本处的跨越理由再对也没机会被问到 —— 实测那正是 `su root reg delete …` 与
  // `su root find /data -delete` 在只改本处时**仍然 allow** 的原因。
  // ── 跨越判据同样只认**裸命令名**（与 commandHeadEnd 的 ② 分支同一份判据）──────────
  // `commandNameOf` 按 basename 取尾段，于是**路径目标**也会解出命令名：
  // `runas /user:a C:/Windows/System32/taskkill.exe` 的 `taskkill`、`su -c /usr/bin/rm`
  // 的 `rm` 都在破坏性名单里 —— 跨过操作数去「吃」一个**目标**，命令头随即把整段跳空
  // → 段级 blast 归 null → 半径档 `inside`。
  //
  // ── ⚠️ 归因更正：这一族**不全是** `runas` 操作数自身的假警告 ──────────────────────
  // 本处注释与 `test/shell-parse.mjs` 的 54j 曾把「HEAD 有值 → 变 null」的残余 LOST
  // **整体**归因为「`runas` 的操作数被当成目标」（`head.path` 是 `/user:a` / `/noprofile`）。
  // 逐条打印 `blast.path` 复核后该归因**不成立**，必须按 `head.path` 一分为二
  // （对拍语料 3648 条叉乘 × 逐条比段级 blast；数字为**本次修复前 / 后**）：
  //   · **操作数自身**（`/user:a`、`/noprofile`）—— HEAD 的**假警告**：HEAD 把 `runas`
  //     的操作数当成了目标路径，警告指错对象。修复前 30 条、修复后 18 条。
  //   · **真实路径目标** —— **真漏报**（方向 fail-open）：`head.path` 是 `/etc`、`/tmp`、
  //     `/root`、`/opt`、`/home`、`/usr`、`/var`、`/etc/hosts`、`/data`、`C:/data`、
  //     `D:/data`、`C:/Windows`、`C:/Users/me`。修复前 177 条、修复后 88 条。
  // 两类混在一起时只看计数会把真漏报当成假警告抹掉 —— 故 54n 按**形态**逐条钉住
  // 「单段 POSIX 路径」那一族（`su root /etc rm`、`su - cat /etc rm`），而不是只数总数。
  // 残余的 88 条**不是** `/x` 分支造成的（见本函数「已知残余」段：`k === at` 支与
  // 关键字链），故 54n 只钉 `/x` 分支修好的那些形态。
  // 判据用词法（有没有路径分隔符），不依赖任何名单 —— 故不会与名单漂移。
  const isTargetEatingName = (n, idx) => !/[/\\]/.test(String(w[idx])) && isTargetEatingNameIn(w, idx, n)
  // ── ④ `at` 之后的第一个词元是**值选项**（`-c` / `--command`），其值是**裸命令名** ──────
  // 前三支（①`k === at` 操作数、②选项形态、③关键字链）都停在**操作数**上，而 `su` 的
  // 操作数之后紧跟的第一个词元可能正是值选项 `-c`（`su root -c <cmd>`，GNU getopt 参数
  // 置换下的**常规写法**）。此时 `k` 停在 `-c` 上，`afterName` 是 `-c` 本身 —— 既不是
  // 关键字也不是前缀，快速路径判「不是吃目标的命令名」→ 返回 `at`（**不跨**）。
  //
  // 后果是**整条链停在 `su` 上、真命令名永不进 labels**（判档侧与 label 侧同时失效，
  // 因为两处共用本函数这一推进步）：
  //     段级（win32、真实宿主钩子口径）：
  //         su -c kill 1234        → labels=["su","kill"] blast=null T=[proc,priv]  ✅
  //         su root kill 1234      → labels=["su","kill"] blast=null T=[proc,priv]  ✅
  //         su root -c kill 1234   → labels=["su"]        blast=null T=[**priv**]   ❌ proc 档整个丢失
  //     端到端（八档默认 inside=allow 其余 ask）：
  //         su -c kill 1234 / su root kill 1234 / sudo kill 1234 → ask（proc 档在管）
  //         su root -c kill 1234                                → 同上形态却只剩 priv 档
  //     用户显式写的 deny 例外同样被绕过（例外 `kill *`=deny）：
  //         三条对照全 **deny**，`su root -c kill 1234` 是 **ask**（`source=destructive`）。
  //     组档三族（proc / power / reg）全部如此，且**默认配置下即触发**（不需要用户放宽任何档）。
  //
  // 归属：HEAD 上同样是 ask（非本批回归）——`su root -c <cmd>` 是 `su` 指定用户后执行命令
  // 的常规写法，与 `ignored.md:115` 记的 `NAME=value` 赋值词元**形态不同**（那是赋值词元，
  // 这是值选项词元），但同属「`privOperandSkip` 在操作数之后收束、链停在 `su`」这一根因家族。
  //
  // 判据 = **值选项自身** ∪ **值是裸的吃目标命令名**（复用 `isPrivCommandValueFlag` 与
  // `isTargetEatingName` 两个既有单点，不新造判据）：
  //   · 「值选项自身」用**窄**判据（精确 `-c` / `--command`）—— 与 `isPrivOperandWord` 同源。
  //     连写形态（`--command=<值>`）在本位置**不可达**（此时 `w[k]` 就是操作数本身，
  //     走上面 `k === at` 那一支），故本处不判它。
  //   · 「裸」= **不含路径分隔符**：`commandNameOf` 按 basename 取尾段，于是 `/usr/bin/rm`、
  //     `C:/Windows/System32/taskkill.exe` 这类**路径目标**也会解出命令名，跨过它们等于把
  //     真目标排除在命令头之外。**这一条不在这里重写一遍** —— `isTargetEatingName` 内部
  //     已有 `!/[/\\]/.test(w[idx])` 这半（与 `privOperandSkip` 的 ③ 链共用同一份），
  //     两处各写一份必然漂移。实测：把该条件在这里再写一遍与不写，输出**逐字相同**（冗余）。
  //   · 含**空白**的值是引号包起来的整条命令行 / 多词 label（`su root -c "reg delete" …`），
  //     跨过它会让 `segmentLabelFrom` 把 `reg delete` 截成首词 `reg` —— 而 `reg` 不在
  //     `GROUP_OF_LABEL` 里，`reg` 档随之丢失。故这一条**必须**在这里判（`isTargetEatingName`
  //     不含它）。
  //   · 值本身是**语句关键字**（`su root -c time kill 1234`）时必须跨过它，理由见下。
  //
  // ── ⚠️ 值即**语句关键字**是一整个独立子形态────────────────────────────
  // `isTargetEatingNameIn` 的三个来源 = 破坏性名单 ∪ `PAYLOAD_CARRIERS` ∪ 两词 label，
  // 而 `isPrivOperandWord`（`:2091`）**显式把关键字排除在操作数之外** —— 于是
  // `STATEMENT_KEYWORDS` 与 `isTargetEatingNameIn` 的**交集结构性为空**：关键字既不是
  // 「吃目标的命令名」（本支判假）、也不是操作数（`k` 停不到它上面），两侧都接不住它。
  // 后果：`su root -c time kill 1234` 的 `k` 停在 `-c` 上、`vn='time'` 判假 → 落到下面那条
  // 快速路径（`afterName` 是 `-c`，既非关键字也非前缀）→ `return at`（**不跨**）→ 链停在
  // `su` 上、**真命令名 `kill` 永不进 labels**（判档侧与 label 侧共用本函数这一推进步，
  // 同时失效）。实测（win32、真实宿主钩子口径）：
  //     su -c time kill 1234        labels=["su","kill"] T=[proc,priv]   ✅
  //     su root -c time kill 1234   labels=["su"]        T=[**priv**]    ❌ proc 档整个丢失
  //     su root time kill 1234      labels=["su","kill"] T=[proc,priv]   ✅（无值选项那一路正常）
  // 端到端（**纯出厂默认**下两侧 action 都是 ask，差异只在 tiers/labels；要在 action 层显现
  // 需用户写了 deny 例外或把 `proc`/`power`/`reg` 设成非 ask —— 两者都是常规配置）：
  //     例外 `kill *`=deny：`su -c time kill 1234` = **deny**、`su root -c time kill 1234` = **ask** ❌
  //     `proc/power/reg=deny` + `priv=allow`：前者 **deny**、后者 **allow** ❌（静默放行）
  // 触发面：`STATEMENT_KEYWORDS` **45** 条里 **43** 条分叉；两条不分叉的**原因并不相同**，
  // 不可混为一谈 ——
  //   · `{`：被词法器当**未闭合花括号**，`-c { …` 整段解不出（两侧同为 `DECOMP-FAIL`）。
  //   · `}`：被词法器当**闭合花括号**处理 —— **不进 words**（只留在段原文里并置 opaque），
  //     整段照常解得出，两侧 words 都少了那个 `}`、**本就同值**：
  //     `su root -c } kill 1234` → words `["su","root","-c","kill","1234"]`、
  //     `su -c } kill 1234` → words `["su","-c","kill","1234"]`，tiers 两侧同为
  //     `[proc,priv]`、blast 两侧同为 null；**不构成分叉**。
  // 判据 parity（`su root -c <kw> <tail>` vs `su -c <kw> <tail>`，43 关键字 × 24 tail）
  // 由 **1032 → 0**。
  //
  // 判据**复用既有 `STATEMENT_KEYWORDS` 导出**（不新造表、O(1) 查表 + 既有 `isTargetEatingName`）：
  // 关键字**永远不是可执行命令名**（见 `STATEMENT_KEYWORDS` 的注释），故它出现在「值」位置上
  // 时唯一合理的解释就是「真命令还在它后面」—— 与下面 ③ 分支对关键字链的处置**同源**。
  //
  // **只可能收紧**：`w[k]` 是值选项时，原路径必然走到下面那条快速路径并返回 `at`
  // （`afterName` 是 `-c` / `--command`，既不是关键字也不是前缀，`isTargetEatingName` 恒假），
  // 故本支只把「必然不跨」换成「跨到那个裸命令名」—— 不存在任何「原本跨、现在不跨」的格。
  //
  // **「值即目标」族逐字保住**（`su -c C:/Windows`、`su root -c /etc`、`su root -c ~`、
  // `su root -c of=/dev/sda`、`su root -c "rm -rf /"`、`su root -c /usr/bin/rm`）：它们的值
  // 要么含分隔符（由 `isTargetEatingName` 拦）、要么含空白、要么解不出吃目标的命令名
  // （`~`、`of=/dev/sda`），三条守卫各自拦住，`k` 照旧停在值选项上、返回 `at`。
  // **「值即关键字」与 `isTargetEatingName` 不重复不冲突**（两集合交集为空，见上），故这里是
  // `||` 而不是替换。**⚠️ 不要给关键字加「路径形态」守卫**：实测加了之后 parity 反而留下
  // **2580** 个残余失败（`/time`、`C:/if` 这类路径值被挡在门外，退回「该跨没跨」那一族）。
  if (isPrivCommandValueFlag(String(w[k])) && k + 1 < w.length) {
    const vt = String(w[k + 1])
    if (!/\s/.test(vt)) {
      const vn = commandNameOf(w[k + 1])
      if (vn && (isTargetEatingName(vn, k + 1) || STATEMENT_KEYWORDS[vn])) return k + 1
    }
  }
  // ── 关键字判据同样要「**路径形态不当关键字**」守卫（残余 ② 的修法）────────────────
  // `commandNameOf` 按 basename 取尾段，于是**路径目标**也会解出关键字名：`/data`、`C:/data`、
  // `D:/data` 的 basename 恰是 PowerShell 关键字 `data`，目标词元被当关键字跳过、链一路推进到
  // 末尾的破坏性名 → 跨过操作数 → 命令头把整段跳空 → 段级 blast 归 null → 档位 `inside`。
  //
  // **范围远大于原注释所举的 `data` 一族**：`STATEMENT_KEYWORDS` 的 **33/33** 个名字全部可被
  // 路径形态触发 —— `/in` `/for` `/do` `/end` `/try` `/switch` `/class` `/begin` `/process`
  // `/not` `/if` `/else` `/then` `/exit` `/return` `/function` `/catch` `/finally` `/and`
  // `/or` `/while` `/foreach` … 每一个 `/<关键字>`（以及 `C:/<关键字>`、`D:/<关键字>`）都命中。
  //
  // ── ⚠️ 原注释给的修法方向**不可行**（已实测否决）────────────────────────────────
  // 原注释写「要修需给 `k === at` 加『路径形态』守卫」—— 按此变异后仓库测试 **6 条断言变红**
  // （54d / 54h / 54h2 / 54h3 / 54n / 54l）：`runas` 的**首位**开关 `/noprofile` 本身就是路径
  // 形态，加守卫会把它挡在门外，退回「该跨没跨」那一族。
  // **可行修法就是本处这一条**（只给关键字链加守卫，不动 `k === at`）：单独变异实测
  // **0 断言失败**；全语料 273420 条**段级 blast** **LOST=0、GAIN=290**，290 条**全部与
  // HEAD 同值**（即纯回归基线 —— 把 HEAD 本来判对、本批改动弄丢的结论收回来，不引入新结论）。
  // ⚠️ 同 `:1665` 那处的更正：这只是 **blast 口径**；**tiers 口径另有 posix 74 条
  // `outside → unknown`**（成因与方向见上文「已知残余」段末尾的更正段，性质是与 sudo/裸对齐）。
  const isKeywordWord = (n, idx) => STATEMENT_KEYWORDS[n] && !/[/\\]/.test(String(w[idx]))
  // 快速路径：afterName 既不是关键字也不是任何前缀时，结论只取决于它是不是吃目标的命令名。
  if (!isKeywordWord(afterName, k) && WRAPPERS[afterName] !== 1 && PRIV_PREFIXES[afterName] !== 1) {
    return isTargetEatingName(afterName, k) ? k : at
  }
  // ③：跳过关键字/wrapper/前缀链，找那个吃目标的命令名。
  // 每轮至少推进一个词元，guard 取词元数即不可能漏判（与 commandHeadEnd 同纪律）。
  //
  // ⚠️ **「前缀 / 关键字推进」必须排在 `isTargetEatingName` 之前**，否则本修复整个失效：
  //    `su root sudo X` 的链首 `sudo` **本身就在 `DESTRUCTIVE_LABELS` 里**（提权名全在名单里，
  //    见 §9.4），先判破坏性就会在链首 return k —— 那正是被删掉的那条无条件跨过，
  //    于是 `su root sudo C:/Windows` 依旧判 null。实测（win32、priv=allow）：
  //    先判破坏性 → 该形态 allow（漏报）；先判前缀 → 不跨、目标正常参与判档（与 HEAD 一致）。
  let m = k
  for (let guard = 0; guard <= w.length && m < w.length; guard += 1) {
    const t = String(w[m])
    const tn = /\s/.test(t) ? '' : commandNameOf(t)
    if (!tn) return at
    if (isKeywordWord(tn, m)) {
      // 关键字**自身的选项**必须一并跨过（`su root time -p <cmd>` 的 `-p`）—— 判据与
      // `headCommandNameOf` / `commandHeadEndFull` / `pushHeadLabels` / `segmentLabelFrom`
      // 的同名分支**同源**（复用 `skipPrefixArgs`）。只推一个词元时 `-p` 会停在链上，
      // 于是 `isTargetEatingName` 问到的是 `-p`（既非命令名也不在名单里）→ 判「不跨」
      // → 命令头停在操作数上 → 真命令与真目标一起被排除 → 段级 blast 归 null
      // → 半径档落 `inside` → `priv=allow` 时**静默放行**。
      // 实测（win32、priv=allow、其余档 ask）：`su root rm -rf /tmp` = ask、
      // `su root time rm -rf /tmp` = ask、`su root time -p rm -rf /tmp` = **allow**。
      let nx = m + 1
      try { const s = skipPrefixArgs(w, m + 1, tn); if (s > nx) nx = s } catch (e) {}
      m = nx > m ? nx : m + 1
      continue
    }
    if (WRAPPERS[tn] === 1 || PRIV_PREFIXES[tn] === 1) {
      // 前缀链交给 `skipPrefixArgs`（与 commandHeadEnd 的 ① 分支同源，不另写一份剥法）
      let nx = m + 1
      try { const s = skipPrefixArgs(w, m + 1, tn); if (s > nx) nx = s } catch (e) {}
      m = nx > m ? nx : m + 1
      continue
    }
    // 走到这里说明它不是关键字也不是前缀 —— 此时才问「是不是吃目标的命令名」。
    // 是（`rm` / `dd` / `find` / `xargs`…）→ 跨过操作数，命令头从它开始继续
    // （判档要看的就是它后面的目标）；
    // 否（纯路径目标 `su root env /etc`、`su root sudo C:/Windows`）→ **不跨**，
    // 让那个词元留在命令头之外参与判档（这正是本函数要恢复的行为）。
    if (isTargetEatingName(tn, m)) return m
    return at
  }
  return at
}

/**
 * 命令头的**完整**结束下标：在 `commandHeadEnd` 之上补上「语句关键字」这一层。
 *
 * ── 为什么必须单列一个函数（而不是改 `commandHeadEnd`）──────────────────────────
 * `commandHeadEnd` **刻意不认识语句关键字**（见其注释：关键字既不是前缀也不是破坏性命令，
 * 走 ② 时会被当成命令名一并吃掉）。它的消费方 `blastRadiusOfSegment` 靠另一条预筛
 * （`mayNeedBlastCheck`）处理关键字，两者不是同一个判据 —— 故不能就地改它，
 * 否则 `time diskpart` 一类的段级 blast 结论会跟着变（那是既有断言钉住的）。
 *
 * ── 为什么必须有它：语句关键字 × 透明 wrapper × 裸跑交互命令 ─────────────────────
 * `hasNoOperand` 的「按命令头位置跳过命令名」此前只看 `commandHeadEnd`，而后者对
 * `['time','env','diskpart']` 返回 **0**（首词元 `time` 是关键字 → 既非前缀也非破坏性命令）。
 * 于是 `i < headEnd` 一个词元都盖不住，`skip` 里又只登记了 `w[0]`(`time`)、
 * `unwrapWords[0]`(`time`)、`cmdName`(`diskpart`) 三项 —— 中间的 `env` 落进循环被当成
 * **非选项实参** → `hasNoOperand` 返回 false → 该段不归 `unknown` → 落半径档 `inside`
 * → 大分类 mode=allow 时**静默放行**。而 `diskpart` 裸跑会阻塞等 stdin（DSH 非交互环境），
 * 静默放行后该次工具调用直接挂住。
 *
 * 实测（45 个 STATEMENT_KEYWORDS × 9 个 wrapper × 3 个命令，真实档位表、mode=allow）：
 * 修复前 **1161/1215 allow**，而三组对照（仅关键字 / 仅 wrapper / 裸跑）各 **0/1215**。
 * 生产形态同样命中：`if true; then env diskpart; fi`、`while true; do env parted; done`。
 *
 * ── 判据：只在 `commandHeadEnd` **确实吃到命令名**时早退──────────────
 * 此前早退写的是 `if (end > 0) return end`，理由（已实测推翻）是「返回 >0 ⇒ 它已吃掉前缀链
 * + 命令名，关键字不可能出现在那个位置之前」。反例有两族（`PRIV_VALUE_IS_COMMAND` 的前缀
 * 只吃前缀名就停、`sudo` 会把关键字当命令名吃掉），详见函数体内那段注释。
 *
 * ⚠️ 注释曾称「不早退时 `parted /dev/sda` 的 `/dev/sda` 会被当成关键字之后的前缀链吃进
 * 命令头、tiers 由 `outside` 变 `unknown`」—— 该反例**实测不成立**：按修法放开早退后，
 * 12012 条语料 **0 放宽、0 半径档降级**（387 条全为 `inside→unknown` 收紧），
 * `parted /dev/sda`、`dd of=/dev/sda`、`diskpart /s script.txt` 的 tiers **逐字不变**。
 * 原因是下面那个循环的 ③ 分支只吃**一个**词元就 break（`/dev/sda` 进不了命令头），
 * 而 `hasNoOperand` 取 `max(headEnd, headFull)` 只影响「按位置跳过」的范围。
 *
 * 推进方式与 `headCommandNameOf` 的交替循环**同源**（复用 `skipPrefixArgs` /
 * `privOperandSkip`，不另写一份剥法）：关键字 → 前缀链 → 关键字 …… 交替前进，
 * 每轮至少推进一个词元，故 `guard <= n` 不可能漏判。
 *
 * @param {string[]} words 段词元
 * @returns {number} 结束下标（0 表示命令头没吃到任何命令名）
 */
function commandHeadEndFull(words) {
  const w = Array.isArray(words) ? words : []
  const n = w.length
  let end = 0
  try { end = commandHeadEnd(w) } catch (e) { end = 0 }
  // ── 早退：只在 `commandHeadEnd` **确实吃到了命令名**时 ──────────────────────
  // ⚠️ 「返回 >0」**不等于**「吃到了命令名」，把两者当成同一件事是 fail-open 的根因：
  //   · `su` / `runas`（`PRIV_VALUE_IS_COMMAND`）只吃前缀名就停 ——
  //     `commandHeadEnd(['su','time','diskpart'])` = 1（`privOperandSkip` 在关键字 `time` 上
  //     收束，② 分支又因 `PRIV_VALUE_IS_COMMAND['su']` 不吃那个词元）；
  //   · `sudo time X` 走 ② 的 `sawPrefix && !PRIV_VALUE_IS_COMMAND['sudo']`，把语句关键字
  //     `time` 当命令名吃掉 —— `commandHeadEnd(['sudo','time','diskpart'])` = 2。
  // 两种情形下真命令名都还在 `end` 之后，早退让下面的循环拿不到机会，于是关键字/wrapper/
  // 真命令名全部落进 `hasNoOperand` 的词元循环被当成非选项实参 → 该段不归 `unknown` →
  // 落半径档 `inside` → 大分类 mode=allow 时静默放行（`diskpart` 裸跑会阻塞等 stdin）。
  // 判据与 `headCommandNameOf` 同源：末个被吃掉的词元既不是语句关键字、也不是前缀时，
  // 它才是命令名。两个否分支都落回下面的循环，由它按同一张转移表续判。
  //
  // ── ⚠️ 判据必须与 `headCommandNameOf` **逐字同源** ──────────────────────────
  // 此前这里少一项 `!LEAD_ASSIGN.test(...)`，而 `headCommandNameOf` 有它 —— 两份守卫漂移后，
  // 同一个 `NAME=value` 词元在两侧结论相反：`commandHeadEnd` 的 ② 里
  // `sawPrefix && !PRIV_VALUE_IS_COMMAND[prevPrefix]` 对 `sudo` / `doas` / `pkexec` / `gsudo`
  // 恒真且先于 `isTargetEatingNameIn` 命中，会把前缀之后的第一个词元无条件当命令名吃掉，
  // 而那个词元可能正是 `FOO=1`；这里缺守卫就会把 `FOO=1` 当「真命令名」提前 return，
  // 真命令名（`diskpart`）落进 `hasNoOperand` 的实参循环 → 该段不归 `unknown` → 静默放行。
  //
  // ⚠️ 严重度**不在「权限宽松」而在硬故障**：`diskpart` 裸跑会阻塞等 stdin，而 DSH 是非交互
  // 执行环境 —— 工具调用直接挂住。加一个环境变量赋值即可触发。
  // 判据复用模块级 `LEAD_ASSIGN` 单点（与 `headCommandNameOf`、`unwrapWordsFrom`、
  // `commandHeadEnd` 的前导赋值剥离同源），不新造正则 —— 四处若各写一份「什么算赋值」必然漂移。
  //
  // ── ⚠️ 同一漂移的**第二项**：值选项词元 ─────────────────────────────────────
  // `privOperandSkip` 的 ④ 支在「值选项的值是语句关键字」时返回 `k + 1`（值选项自身的下标），
  // 而这个返回值同时是 `commandHeadEnd` 的推进结果 ⇒ `commandHeadEnd` 停在值选项上、
  // `w[end - 1]` 就是 `-c` / `--command`。早退判据只拒收「关键字 / wrapper / 提权前缀 /
  // `LEAD_ASSIGN`」四类、不含值选项时，同样会提前 `return end`，后果与上一条相同。
  // 故复用 `isPrivCommandValueFlag` 单点（O(1) 查表）。
  // 复用 `isPrivCommandValueFlag` **单点**（`:1769`，O(1) 查表，在 `:2725` 之前，无 TDZ）。
  if (end > 0) {
    const last = commandNameOf(w[end - 1])
    // ── ⚠️ 同一漂移的**第三项**：前缀自身的**普通选项**词元 ────────────────────
    // 与「值选项」同族但不同形态：`commandHeadEnd` 的 ① 分支经 `skipPrefixArgs` 会把 `-l`
    // 这类普通选项吃掉并**停在其上** ⇒ `w[end - 1]` 是 `-l` 而非命令名 ⇒ 五项判据全过 ⇒
    // 提前 `return end`。`-l` 确不在任何一类里：`STATEMENT_KEYWORDS` false、非 `WRAPPERS`、
    // 非 `PRIV_PREFIXES`、`isPrivCommandValueFlag('-l')` false、不匹配 `LEAD_ASSIGN`。
    // 后果：该段不归 `unknown` ⇒ 落半径档 `inside` ⇒ `priv=allow` 下静默 allow（`diskpart`
    // 裸跑阻塞 stdin，是硬故障）。可见面只在 `priv=allow` 一族。
    //
    // ⚠️ **只补这一处，不要同步补 `headCommandNameOf`**：两处都补会让它在
    // `su --command=x /user:a …` 形态上退成 `'su'` 并引入新的 blast 假警告。判据同源但后果不同。
    //
    // 判据复用 `skipPrefixArgs` 的同一判据（`token.charCodeAt(0) !== 45`）：O(1)、无正则、无分配。
    if (last && !STATEMENT_KEYWORDS[last] && WRAPPERS[last] !== 1 && PRIV_PREFIXES[last] !== 1
      && !isPrivCommandValueFlag(String(w[end - 1]))
      && !(String(w[end - 1]).charCodeAt(0) === 45)
      && !LEAD_ASSIGN.test(String(w[end - 1]))) return end
  }
  let start = 0
  // 前导 NAME=value（与 commandHeadEnd / unwrapWords 同判据：至少留一个词元）
  while (n - start > 1 && /^[A-Za-z_][A-Za-z0-9_]*=/.test(String(w[start]))) start += 1
  for (let guard = 0; guard <= n && start < n; guard += 1) {
    // 含空白的词元是引号包起来的整条命令行，不是命令名 —— 与 commandHeadEnd 同判据。
    if (/\s/.test(String(w[start]))) break
    const name = commandNameOf(w[start])
    if (!name) break
    // ① 语句关键字：关键字**永远不是可执行命令名**，跳过后继续（`time` → `env` → `diskpart`）。
    if (STATEMENT_KEYWORDS[name]) {
      // 跳关键字后**不能**就地取下一个词元：它可能又是一个关键字或前缀（`time ! env diskpart`）。
      // 故只推进一个词元，交给下一轮按同一张转移表继续判。
      //
      // ── 但关键字**自身的选项**必须先跨过（`time -p <cmd>` 的 `-p`）────────────────────
      // 只推一个词元时 `-p` 会占掉下一轮的位置，于是 `headFull` **少覆盖一个词元**：
      // `time -p env diskpart` 的 `headFull` 由 4 掉到 2，中间的 `env` 落进
      // `hasNoOperand` 的实参循环被当成**非选项实参** → 该段不归 `unknown` → 落半径档
      // `inside` → 大分类 mode=allow 时**静默放行**（而 `time env diskpart` 是 unknown）。
      // 推进方式复用 `skipPrefixArgs` —— 与 `segmentLabelFrom` 的关键字分支（`:775`）和
      // `pushHeadLabels`（`:1149`）**同源**，三处不各写一份「什么算关键字自己的选项」。
      //
      // 影响面**只在「关键字紧跟 `-` 开头词元」时**：`skipPrefixArgs` 遇到第一个非选项
      // 词元即停，故 `time rm …` / `then nohup rm …` 一族逐字不变（`nx === start + 1`）。
      let nx = start + 1
      try { const s = skipPrefixArgs(w, start + 1, name); if (s > nx) nx = s } catch (e) {}
      start = nx > start ? nx : start + 1
      continue
    }
    // ② 前缀（wrapper / 提权命令）：与 commandHeadEnd 的 ① 分支同源，复用 skipPrefixArgs
    //    与 privOperandSkip（后者处理 `su` / `runas` 的操作数）。
    if (WRAPPERS[name] === 1 || PRIV_PREFIXES[name] === 1) {
      let next = start + 1
      try { const nx = skipPrefixArgs(w, start + 1, name); if (nx > next) next = nx } catch (e) {}
      if (next <= start) break
      if (next < n) { try { next = privOperandSkip(w, name, start + 1, next) } catch (e) {} }
      start = next
      continue
    }
    // ── 进入 ③ 之前：前导 `NAME=value` **不是命令名**，跳过后继续──────
    // 上面那个早退守卫（`:2681`）只盖住「`commandHeadEnd` 已把赋值当命令名吃掉」的形态；
    // 这一支走的是**推进循环**，守卫够不到 —— 同一个 `NAME=value` 词元在两处结论相反：
    //   · `commandHeadEnd(['sudo','FOO=1','env','diskpart'])` = **2**：② 分支的
    //     `sawPrefix && !PRIV_VALUE_IS_COMMAND['sudo']` 对 `sudo` 恒真且**先于**
    //     `isTargetEatingNameIn` 命中，于是把前缀之后的第一个词元 `FOO=1` 当命令名吃掉；
    //   · 这里若把 `FOO=1` 当「命令头位置上的命令名」→ ③ 直接 `break`，`headFull` 停在 2。
    // 后果：真命令名（`diskpart`）与中间的 wrapper（`env`）落进 `hasNoOperand` 的词元循环
    // 被当成**非选项实参** → 该段不归 `unknown` → 落半径档 `inside` → 大分类 mode=allow 时
    // **静默放行**（而 `diskpart` 裸跑会阻塞等 stdin，DSH 非交互环境下工具调用直接挂住）。
    // 实测（`priv=allow` + `unknown=deny`、其余 ask）：
    //     sudo env diskpart        → deny `['unknown','priv']` ✅
    //     sudo FOO=1 env diskpart  → **ask** `['inside','priv']` ❌（多写一个赋值前缀）
    //     sudo FOO=1 time env diskpart / sudo FOO=1 nohup diskpart / sudo -u root FOO=1 env diskpart 同 ❌
    // 插桩：`commandHeadEndFull(['sudo','FOO=1','env','diskpart'])` = **2**（正确值 4）、
    // `w[1]="FOO=1"` → 三项全过 → 早退；而 `headCommandNameOf(同)` = `'diskpart'`
    // —— `:2659` 那句「与 `headCommandNameOf` 逐字同源」在该形态上此前**并未成立**。
    //
    // 判据复用模块级 `LEAD_ASSIGN` **单点**（`:621`，与 `headCommandNameOf:3868` 的早退守卫、
    // `commandHeadEnd:2785` 的前导赋值剥离同源），**不新造正则** —— 四处若各写一份「什么算
    // 赋值」必然漂移，而漂移方向正是本条缺陷。
    //
    // ⚠️ 只修这一支，**不动 `commandHeadEnd` 本体**：它的消费方 `blastRadiusOfSegment`
    // 靠 skip 判据处理赋值（改它会波及段级 blast 结论）。另外两支同族缺陷
    // （`nohup FOO=1 …`、`su root FOO=1 …`）走**不同代码路径**，本轮刻意不修 ——
    // 实测本行（`commandHeadEndFull` 的推进循环）对那两支**零影响**（前后逐字同值：
    // 10 个 wrapper 族 + `su`/`runas` 两族 × 45 关键字 × 2 平台，段级 blast / labels /
    // tiers 变化 0；4320 格 action 变化 0）。
    //
    // ⚠️ 但「走不同代码路径」**不等于**「wrapper 族走 label 侧」——此处曾如此归因，是错的：
    // wrapper 族的**半径档**由 `headCommandNameOf` 那一对行（该函数的早退守卫 +
    // 其推进循环的 `LEAD_ASSIGN` 步）修好，属**半径档侧**；真正留在 label 侧的只是它的
    // 另一半（`segmentLabels` 恒空 ⇒ `tiers` 空、`action` 不变，`ignored.md:115` 的缺陷
    // 本身仍在）。归因写错会让后来人去 label 侧找 wrapper 族的半径档问题。
    // 详见 `headCommandNameOf` 里推进循环那一行上方的实测记录。
    //
    // 收敛性：每轮 `start += 1` 至少推进一个词元，`guard <= n` 不可能死循环（与 ①② 同）。
    if (LEAD_ASSIGN.test(String(w[start]))) { start += 1; continue }
    // ③ 既不是关键字也不是前缀 → 这就是命令头位置上的命令名，吃掉它后停。
    start += 1
    break
  }
  return start
}

/**
 * 命令头在词元列表里的**结束下标**（不含）：提权前缀链 + wrapper 链 + 最终的命令名。
 *
 * 与 `segmentLabel` 的分工：那个回答「这段叫什么」（路由器命令 `git status` 是**一个** label，
 * 词数是 2），这个回答「命令头到哪儿为止」（哪些词元不是目标实参）。两者不可互相替代 ——
 * `sudo` 的 label 是 `sudo`（词数 1），而它的命令头到 `rm` 为止（`sudo -u root rm` 是 4 个词元）。
 *
 * 判据：从段首开始**连续**吃掉前缀（提权命令与 wrapper，含各自的选项与带值选项），
 * 直到遇到一个「不是前缀、但在破坏性名单里」的命令名 —— 那就是真正吃目标的那个，吃掉它后停。
 * 首词元就不是前缀也不是破坏性命令时返回 0（`git status *` 走这条，调用方保持 label 词数）。
 *
 * @param {string[]} words 段词元
 * @returns {number} 结束下标（0 表示没吃到任何命令名）
 */
function commandHeadEnd(words) {
  const w = Array.isArray(words) ? words : []
  const n = w.length
  let j = 0
  // 是否已经吃掉过至少一个前缀（wrapper / 提权命令）。决定「命令名」要不要一并吃掉 ——
  // 见下面 ② 的说明。
  let sawPrefix = false
  // 最后吃掉的**前缀命令名**（小写）：`su` / `runas` 的值本身即命令或目标，
  // 其后词元不能一律当命令名吃掉（见 PRIV_VALUE_IS_COMMAND 与 ② 的说明）。
  let prevPrefix = ''
  // 前导 NAME=value（`FOO=1 rm -rf /`）：与 unwrapWords 同判据（至少留一个词元）。
  while (n - j > 1 && /^[A-Za-z_][A-Za-z0-9_]*=/.test(String(w[j]))) j += 1
  // **纯下标推进，不复制数组**：这里曾经每轮 `unwrapWords(w.slice(j))` —— slice 是 O(n)，
  // 而轮数也是 O(n)，于是整条链退化成 O(n²)。实测 16000 个 `sudo` 前缀：n=8000 → 20 ms、
  // n=16000 → 79 ms（倍率≈4.0，标准平方），而它在破坏性段的判档路径上、词元由 AI 生成、
  // 长度无上界 —— 与本文件其他几处平方退化是同一类问题，故一并按线性写。
  //
  // 每轮至少吃掉一个词元（前缀吃掉自己、命令名吃掉自己），故 guard 取词元数即不可能漏判。
  for (let guard = 0; guard <= n && j < n; guard += 1) {
    const raw = String(w[j])
    // **含空白的词元不是命令名**，命令头到此为止。
    //
    // 词法器把引号内容并成一个词元，于是 `su -c "rm -rf /etc"` 的第三个词元是
    // `rm -rf /etc` —— 它是一条**被引号包起来的命令行**，不是命令名。若照常交给
    // commandNameOf（内部按路径 basename 取尾段），会得出荒谬的结果：`rm -rf /etc`
    // 的 basename 是 `etc`、`rm -rf /` 的 basename 是空串，于是同一构造只因目标不同
    // 就分叉 —— 实测 `su -c "rm -rf /"` 的 headEnd=2（侥幸正确），而
    // `su -c "rm -rf /etc"` 的 headEnd=**3**，把整个引号词元当命令名吃掉，
    // 段级判档最终返回 null（删系统目录零警告）。
    // 交回给调用方：blastRadiusOfSegment 会识别「含空白的词元」并按子命令行递归判档。
    if (/\s/.test(raw)) break
    const base = commandNameOf(w[j])
    if (!base) break
    // ① 前缀：wrapper 与提权命令**同处置** —— skipPrefixArgs 已按名字查两张带值选项表，
    //    故不需要再调 unwrapWords（那条路径有 depth<4 的层数上限，深链本就会漏）。
    if (WRAPPERS[base] === 1 || PRIV_PREFIXES[base] === 1) {
      const next = skipPrefixArgs(w, j + 1, base)
      const at = next > j ? next : j + 1
      // `su` / `runas` 的操作数不是命令名，跨过它继续推进 —— 判据与门控侧共用
      // `privOperandSkip` 一处（见其注释：`su root rm -rf /data` 的 `root`）。
      j = at < n ? privOperandSkip(w, base, j + 1, at) : at
      sawPrefix = true
      prevPrefix = base
      continue
    }
    // ② 命令名：吃掉它后停。这就是吃目标的那个。
    //
    // 判据含 `sawPrefix`：**前缀之后的那一个词元通常是命令名**，不管它在不在破坏性名单里。
    // 只认破坏性名单会让 `sudo /usr/bin/find /etc -delete` 的 `/usr/bin/find`（命令名，
    // 只是 `find` 本身不在名单里 —— 它的破坏性来自后续 `-delete`）留在 rest 里被当成
    // **目标实参**判档：实测弹窗写「目标是系统目录（/usr/bin/find）」，而真目标 `/etc`
    // 被遮蔽；`sudo /usr/bin/find /tmp/x -delete` 更糟 —— 命令名判 system 盖过真目标的
    // outside，变成一条指错对象的警告。
    //
    // ── 但 `su` / `runas` 不适用：它们的值**本身就是命令或目标** ──────────────────
    // `su -c <值>` 的值是一条命令行（`su -c "rm -rf /"`），而 `su -c C:/Windows` 里
    // 它就是**目标**。无条件吃掉下一个词元会把目标当命令名吞掉 —— 实测（与加 sawPrefix
    // 的版本对拍）`su -c C:/Windows` 的 system 警告、`su -c C:/Users/me` 与 `su -c ~`
    // 的 home 警告、`su -c of=/dev/sda` 与 `su -c C:/$Recycle.Bin` 的 system 警告
    // 全部消失（7 种形态 × 两个平台）—— 那是把这条闸开过头造成的**新漏报**。
    //
    // 故 `su` / `runas` 退回纯「吃目标的命令名」判据（`su -c rm -rf /` 的值是 `rm`，
    // 在名单里，照吃；`su -c C:/Windows` 的值不在名单里，留给目标判档）。
    //
    // ── 判据必须覆盖**载荷族**与**两词 label**，不能只认 `isDestructiveLabel` ──────────
    // 只认破坏性名单会让 `su root find /data -delete` 的 `find` 不被吃掉（`find` **不在**
    // `DESTRUCTIVE_LABELS` 里 —— 它的破坏性来自后续 `-delete` / `-exec`），于是命令头停在
    // `root` 上、`headCommandNameOf` 取回操作数 `root` → `isCmdStyleSwitch('/data', …, 'root')`
    // 认不出命令域 → `/data` 被当 cmd 开关跳过 → 段级 blast 归 null → 半径档 `inside`
    // → `priv=allow` 时**静默放行**。实测：`su root find /data -delete` 与
    // `su root find /data -exec rm -rf {} +` 的段级 blast 是 null，而同目标的
    // `su root env find /data -delete`（wrapper 分支把它推进过去了）是 outside
    // —— 同一件事只因少一个 wrapper 就分叉。
    // 判据收敛到 `isTargetEatingNameIn` **单点**（与 `privOperandSkip` / `isPrivOperandWord`
    // 共用同一份）：那正是「哪些名字吃目标」的唯一来源（破坏性名单 ∪ 载荷族 ∪ 两词 label），
    // 三处若各写一份必然再次分叉 —— 那正是本文件反复要修的那类缺陷。
    //
    // ── 但载荷族/两词 label 的扩展**只对裸命令名**成立（`su` / `runas` 分支）──────────
    // `su` / `runas` 的值**本身就是命令或目标**（见上），而 `commandNameOf` 会按 basename
    // 取尾段 —— 于是 `/usr/bin/find`、`C:/Windows/System32/taskkill.exe` 这类**路径目标**
    // 也会解出 `find` / `taskkill`，命中载荷族而被当成命令名吃掉。
    // 实测（win32/posix、三方差分 136412 条）：不加守卫时 `su root /usr/bin/find`、
    // `su -c /usr/bin/find`、`runas /user:a /usr/bin/find` 等 **18 条**由 system 变 null
    // —— 那是把这条闸开过头造成的**新漏报**（方向最坏）。
    // 故**扩展部分**（载荷族 ∪ 两词 label）只认**裸名**：含路径分隔符的词元在
    // `su`/`runas` 之后一律当**目标**，留给判档（这正是 HEAD 的行为：
    // `su root /usr/bin/rm` 判 system —— 破坏性名单那一支照旧无条件生效，故不在此列）。
    //
    // 判据用「有没有路径分隔符」而不是再抄一份名单：裸名与路径的区分是**词法**的，
    // 不依赖任何表。`su -c rm -rf /` 的 `rm` 是裸名、照吃（`isDestructiveLabel` 本来就命中）；
    // `su -c C:/Windows` 含 `:`/`/`，不吃 —— 两条都保住。
    const bare = !/[/\\]/.test(String(w[j]))
    if ((sawPrefix && !PRIV_VALUE_IS_COMMAND[prevPrefix])
      || isDestructiveLabel(base)
      || (bare && isTargetEatingNameIn(w, j, base))) j += 1
    break
  }
  return j
}

/**
 * 该段的**命令头位置**上是否出现过提权前缀（`sudo` / `doas` / `su` / `pkexec` / `runas` / `gsudo`）。
 *
 * 判据 = **命令头位置链** + **`find -exec` 族递归**，复用既有的 `PRIV_PREFIXES`（不新造表）：
 *
 *     byHeadChain(words):
 *       剥前导 NAME=value
 *       沿前缀链走：
 *         当前词元是提权名 → true
 *         是 WRAPPERS → 跳过它与其选项，继续
 *         否则 → break（遇到真命令名）
 *     segmentPrivilege(words):
 *       byHeadChain(words) || 任一 -exec/-execdir/-ok/-okdir 之后的子链 byHeadChain
 *
 * ── 为什么必须是「命令头位置」而不是「扫段内全部词元」 ──────────────────────────
 * 两种朴素判据都有误报，且实测都能构造出来：
 *     rm sudo                  删一个名叫 sudo 的文件 → 被当成提权 ❌
 *     rm -rf ./sudo            同上 ❌
 *     mv sudo /tmp             同上 ❌
 *     find . -name sudo -delete 同上 ❌
 * 位置判据把这四种全部正确排除（反例 9 条实测全 false）。判据走的是**下标推进**，
 * 不复制数组 —— 与本文件其他几处一样避开 O(n²)（词元由 AI 生成、长度无上界）。
 *
 * ── 为什么递归 `find -exec` ────────────────────────────────────────────────────
 * `find . -exec sudo rm {} ;` 的提权前缀在 `-exec` **之后**，只看段首会漏。
 * 复用 FIND_EXEC_FLAGS（与 segmentLabels 同一份表），不另抄一份。
 *
 * @param {string[]} words 段词元
 */
export function segmentPrivilege(words) {
  const w = Array.isArray(words) ? words : []
  if (!w.length) return false
  // 命令头位置链：返回 true 当且仅当**在遇到真命令名之前**碰到了提权前缀。
  //
  // 本函数曾经收一个 `from` 起始下标形参 —— 参数化它是为了**不复制数组**：
  // 调用方曾在每个 `-exec` 上做一次 `uw.slice(i + 1)`（O(剩余词元) 拷贝），
  // 段内有 n 个 flag 时整体退化成 O(n²)（实测 n=8000 → 134 ms、16000 → 745 ms，
  // 端到端 `assessCommand` 769 ms）。而本函数在 `tierSetOf` 里对**每个破坏性段**
  // 被调用，属 tools/pre-execute 的判定热路径，且 buildCandidates 同步执行、
  // 早于 pendingApprovals.set —— 直接推迟弹窗，命令文本由 AI 生成、长度无上界。
  // ⚠️ `from` 形参**已删除**：唯一调用点传的是 `0`，故 `from > 0 ? from : 0` 恒取 `0`
  // —— 死形参。`-exec` 载荷族现在走下面 `chainTrue` 的反向 DP 表（读 `chainTrue[i + 1]`），
  // **已不再调用本函数**，因此「不切片」这条纪律由那张表承担，本函数只需从 0 起走。
  // 全程仍按下标推进，一次拷贝都不做（与 commandHeadEnd 同纪律）。
  const byHeadChain = (list) => {
    const a = Array.isArray(list) ? list : []
    const n = a.length
    let j = 0
    // 前导 NAME=value（`FOO=1 sudo rm -rf /`）：与 unwrapWords 同判据（至少留一个词元）
    while (n - j > 1 && /^[A-Za-z_][A-Za-z0-9_]*=/.test(String(a[j]))) j += 1
    // 每轮至少吃掉一个词元，故 guard 取词元数即不可能漏判
    for (let guard = 0; guard <= n && j < n; guard += 1) {
      const raw = String(a[j])
      // 含空白的词元不是命令名（引号并成的整条命令行）：命令头到此为止，
      // 与 commandHeadEnd 同判据 —— 不猜引号里是什么语言写的。
      if (/\s/.test(raw)) return false
      const base = commandNameOf(a[j])
      if (!base) return false
      if (PRIV_PREFIXES[base] === 1) return true
      // wrapper 是透明包装：跳过它与其选项，继续找真命令名（`nohup sudo rm -rf /`）
      if (WRAPPERS[base] === 1) {
        const next = skipPrefixArgs(a, j + 1, base)
        j = next > j ? next : j + 1
        continue
      }
      // 遇到真命令名（既不是提权也不是 wrapper）→ 头链结束，其后的词元都是实参
      return false
    }
    return false
  }
  if (byHeadChain(w)) return true
  // `find` 族：`-exec` / `-execdir` / `-ok` / `-okdir` 之后跟的是**一条完整命令行**，
  // 它的命令头里可能有提权前缀。`-delete` 没有后续命令，不参与。
  const u = (() => { try { return unwrapWords(w) } catch (e) { return null } })()
  const uw = (u && Array.isArray(u.words) && u.words.length) ? u.words : w
  let start = -1
  for (let i = 0; i < uw.length; i += 1) {
    if (commandNameOf(uw[i]) === 'find') { start = i; break }
  }
  if (start < 0) return false
  // 廉价预筛：整段没有任何 `-exec` 族 flag 时不必进入下面的回填循环（与 segmentLabels
  // 同纪律）。它**只决定是否进入循环**，不消除循环内的开销 —— 平方退化曾出在「每个 flag
  // 重走一遍前缀链」上，修法是下面 `chainTrue` 的反向 DP 表（按 `i + 1` 读表，不切片），
  // **不是**这个预筛（本预筛与 `byHeadChain` 的起始下标无关：后者已不收 `from`）。
  let hasExec = false
  for (let i = start + 1; i < uw.length; i += 1) {
    if (FIND_EXEC_FLAGS[String(uw[i])]) { hasExec = true; break }
  }
  if (!hasExec) return false
  // ── 自段尾向前把「从该下标起跳的头链结论」一次算出来，让每个 flag 的判定 O(1) ──────
  //
  // 这里曾经对**每个** `-exec` 都从该处向后重走一遍前缀链（当时的 `byHeadChain` 收起始
  // 下标，写作 `byHeadChain(uw, i + 1)`），
  // 而链在「载荷是 wrapper、其后又没有真命令名」时会一路走到段尾 —— 于是 N 个 flag
  // × O(N) 行走 = O(N²)。触发形态是常规写法，不是构造输入：
  //     find . (-exec env)×N -exec rm {} +
  // `skipPrefixArgs` 会把紧随其后的 `-exec` 当成 env 的选项吃掉，链因此永不终止。
  // 实测 `segmentPrivilege`（纯词元构造）：
  //     N=500 → 13.9 ms、1000 → 54.1、2000 → **217.9 ms**（每翻倍 ×4.00，标准平方，
  //     输入仅 20 KB）；`-exec timeout` 同形（210.3 ms）。
  // 端到端 `assessCommand` N=2000 时 251.07 ms —— 而它在 tools/pre-execute 的判定热路径上，
  // 命令文本由 AI 生成、长度无上界。
  //
  // **等价性**：`byHeadChain` 每轮只按「当前词元」决定去哪个下标（前导 `NAME=value`
  // 前进一步、wrapper 走 `skipPrefixArgs`、提权名返 true、其余返 false），且每轮**至少
  // 前进一个下标** —— 于是它是这张有向无环图上的确定性行走，可以自尾向前按同一张
  // 转移表回填。转移判据与 `byHeadChain` 内部**同源**（同一个 commandNameOf / WRAPPERS /
  // PRIV_PREFIXES / skipPrefixArgs），不另写一份「什么算 wrapper」的名单。
  // 每个下标的 `skipPrefixArgs` 只调用一次，且各次行走的选项段互不重叠，故整体 O(n)。
  const chainTrue = new Uint8Array(uw.length + 1)
  for (let i = uw.length - 1; i >= 0; i -= 1) {
    const raw = String(uw[i])
    // 前导 NAME=value：剥掉它继续（与 byHeadChain 的 while 同判据：至少留一个词元）。
    //
    // **这一条必须排在下面的空白检查之前**：词法器把 `FOO="a b"` 输出成**含空白的单个
    // 词元** `FOO=a b`，若先查空白，这条链就停在赋值前缀上 —— `-exec FOO="a b" env … sudo rm`
    // 的提权前缀整个漏判。实测（priv=deny、wide=allow）：
    //     find . -delete -exec FOO="a b" env env env env env sudo rm -rf / {} +
    // 顺序颠倒时 segmentPrivilege=false → tiers=['wide'] → allow，用户显式设的
    // 「提权=拒绝」被绕过；同族的 `-exec A="x y" command -v sudo rm {} +` 则由 ask 变 allow。
    // byHeadChain 的 while 与 unwrapWords 都是**先剥再判**，这里同序才与它们等价。
    if (uw.length - i > 1 && /^[A-Za-z_][A-Za-z0-9_]*=/.test(raw)) { chainTrue[i] = chainTrue[i + 1]; continue }
    // 含空白的词元不是命令名（引号并成的整条命令行）：命令头到此为止 —— 与 byHeadChain 同判据
    if (/\s/.test(raw)) continue
    const base = commandNameOf(uw[i])
    if (!base) continue
    if (PRIV_PREFIXES[base] === 1) { chainTrue[i] = 1; continue }
    if (WRAPPERS[base] === 1) {
      const next = skipPrefixArgs(uw, i + 1, base)
      chainTrue[i] = next < uw.length ? chainTrue[next] : 0
      continue
    }
    // 遇到真命令名（既不是提权也不是 wrapper）→ 头链结束
  }
  for (let i = start + 1; i < uw.length; i += 1) {
    if (!FIND_EXEC_FLAGS[String(uw[i])]) continue
    // **按下标推进，不复制后缀**：这里曾是 `byHeadChain(uw.slice(i + 1))` ——
    // 每个 flag 一次 O(剩余词元) 拷贝，n 个 flag 即 O(n²)（实测见上面的性能段）。
    if (chainTrue[i + 1]) return true
  }
  return false
}

// 「可携带破坏性载荷」的命令族：**自身**不是破坏性命令，但后面接的东西可能让整段变成删除。
//   · 前缀包装器（`env` / `xargs` / `nohup` / `timeout` …）—— `env FOO=1 rm -rf /`、
//     `xargs rm -rf /`、`nohup rm -rf /`；
//   · `find` —— `find / -delete`、`find / -exec rm -rf {} +`（`-delete` / `-exec` 由
//     segmentLabels 合成 `rm` label，故**展开后**的段是 destructive，但例外模式
//     `find *` 本身不含这些选项，`isDestructiveSegment(['find','*'])` 为 false）。
//
// 存在的理由：例外列表的标注判据若只认 `isDestructiveSegment`，则存量里由**旧候选生成器**
// 写下的 `find *` / `env *` / `xargs *` 全部零标注 —— 而它们实测能放行
// `find / -delete`、`env FOO=1 rm -rf /`、`xargs rm -rf /`（在 destructive=deny 下由 deny 变
// allow）。`find *` 正是 HEAD 对 `find . -delete` 弹窗给出的候选，属必然存在的存量配置，
// 而例外列表自陈是「唯一能让人事后发现『我什么时候放行了删盘根』的地方」。
//
// 判据只收「载荷可能变成破坏性」的族，不含普通命令：`git status *` 不在此列。
const PAYLOAD_CARRIERS = dict(Object.assign({ find: 1 }, WRAPPERS))

/**
 * 该 **label** 的命令族是否可能携带破坏性载荷（`find` / `env` / `xargs` …，见 PAYLOAD_CARRIERS）。
 *
 * 与 canCarryDestructivePayload 的区别：那个看**段的词元**（含 wrapper 与选项），
 * 这个只看**归约后的 label**（`git status`、`find`、`rm`）—— 候选生成需要后者，
 * 因为它决定「`label + ' *'` 这条通配候选会放开多大范围」：
 *   · label `find` → `find *` 实测匹配 `find / -delete`，是能放行删盘根的通配候选；
 *   · label `git status` → `git status *` 匹配不到任何删除动作，通配候选安全。
 * 注意 `env FOO=1 git status` 的 label 是 `git status`（wrapper 已被剥掉），
 * 其通配候选 `git status *` 同样安全 —— 故这里判 label 而不是判段首词元。
 *
 * @param {string} label segmentLabel 的返回值
 */
export function isPayloadCarrierLabel(label) {
  const l = String(label == null ? '' : label).trim().toLowerCase()
  if (!l) return false
  return l.split(/\s+/).some((n) => PAYLOAD_CARRIERS[n] === 1)
}

/**
 * 该段的**命令族**是否可能携带破坏性载荷（见 PAYLOAD_CARRIERS）。
 *
 * 与 isDestructiveSegment 的分工：后者问「这一段**就是**破坏性的吗」（判定侧用），
 * 本函数问「这一段**可能变成**破坏性的吗」（例外列表的审计标注用，模式里的 `*`
 * 可能被真实命令的 `-delete` / `rm -rf` 填上）。
 *
 * @param {string[]} words 段词元
 */
export function canCarryDestructivePayload(words, shell) {
  const w = Array.isArray(words) ? words : []
  if (!w.length) return false
  // ① 段首命令名（**未剥 wrapper**）：`env *`、`xargs *`、`find *` 的载荷族正是段首那个名字。
  //    不能只看 segmentLabels —— 它剥掉 wrapper 后剩下 `*`，认不出命令名而返回空。
  let head = ''
  try { head = String(commandNameOf(w[0]) || '').trim().toLowerCase() } catch (e) { head = '' }
  if (PAYLOAD_CARRIERS[head] === 1) return true
  // ② 剥掉 wrapper/赋值后的全部 label：覆盖 `FOO=1 find *`、语句关键字之后等形态，
  //    以及 `find / -delete` 这类合成 label（`-delete` 合成 `rm`，命中破坏性名单）。
  let names = []
  try { names = segmentLabels(w, shell) } catch (e) { return false }
  return names.some((l) => {
    const n = String(l || '').trim().toLowerCase()
    return PAYLOAD_CARRIERS[n] === 1 || isDestructiveLabel(n)
  })
}

/**
 * 递归展开一段文本里的命令替换，返回「自身 + 所有内层内容」的扁平列表。
 *
 * 命令替换可以嵌套：`$(echo \`rm -rf /x\`)`、`` `echo \`rm -rf /x\`` ``、
 * `$(echo $(rm -rf /x))` —— 每一层的内容都会被 shell 执行，所以每层都要展开。
 * 只展开一层会让内层命令不可见（实测那两条曾是 allow，而 rm 真的会跑）。
 *
 * @param {string} text 待展开文本
 * @param {number} depth 剩余递归深度（防病态输入下打转）
 * @returns {string[]} 文本自身 + 逐层摘出的内容
 */
function expandSubstitution(text, depth) {
  const out = [text]
  if (depth <= 0) return out
  // 先把 `\`` 还原成裸反引号**再**摘取：反引号内的 `\`` 是「嵌套一层」的定界符，
  // 还原后它才是可被识别的定界符。不还原的话，`echo \`rm -rf /x\`` 里
  // 全是 `\``、没有裸反引号，replaceCommandSubstitution 找不到配对 → 内层永远摘不出来
  // （实测 `` `echo \`rm -rf /x\`` `` 曾是 allow，而 rm 真的会跑）。
  const normalized = text.replace(/\\`/g, '`')
  const inner = []
  replaceCommandSubstitution(normalized, inner)
  for (const item of inner) {
    for (const sub of expandSubstitution(item, depth - 1)) out.push(sub)
  }
  return out
}

/**
 * 把命令替换（`$(...)` / 反引号）的**内容摘出来**，原位置留一个空格。
 *
 * 命令替换里的内容会被 shell 真正执行，所以提取命令名时必须看到它；
 * 但摘出的内容要交给调用方在**剥完双引号之后**再拼回 —— 否则它会被双引号剥离一起吃掉
 *（`echo "\`rm -rf /x\`"` 里的内容在双引号内部，实测只换定界符会丢）。
 *
 * 只处理**成对**的定界符：找不到配对的 `)` 或反引号时原样保留
 *（那种输入本身语法不完整，交给「整行 ok:false」那条路径处理，不在这里猜）。
 * `$(` 的配对按括号深度算，且跳过其中的引号内容（`$(echo ")")` 不该在第一个 `)` 处截断）。
 *
 * @param {string} text 待处理文本（单引号内容应已剥离）
 * @param {string[]} extracted 摘出的命令替换内容追加到此数组
 * @returns {string} 摘掉命令替换后的文本（原位置留空）
 */
function replaceCommandSubstitution(text, extracted) {
  let rest = ''
  for (let i = 0; i < text.length; i += 1) {
    const c = text[i]
    // 反引号：找配对的收尾反引号。
    // `\``（反斜杠 + 反引号）在反引号**内部**表示「嵌套一层」——`` `echo \`rm -rf /x\`` ``
    // 里内层的 `rm` 会被执行。所以扫描时**不能**把 `\`` 当普通转义直接跳过：
    // 那样 `\`` 会被当成「转义的反引号」（字面量），永远找不到收尾定界符，
    // 于是整段被原样留下、内层内容摘不出来（实测该形态曾是 allow）。
    // 这里的处理是：把 `\`` 当作**内层定界符**，只跳到它后面继续找收尾反引号，
    // 内容原样收进 extracted（其中的 `\`` 由 expandSubstitution 还原后再递归展开）。
    if (c === '`') {
      let end = -1
      for (let j = i + 1; j < text.length; j += 1) {
        if (text[j] === '\\' && text[j + 1] === '`') { j += 1; continue }
        if (text[j] === '`') { end = j; break }
      }
      if (end < 0) { rest += c; continue }
      extracted.push(text.slice(i + 1, end))
      i = end
      continue
    }
    // `$(`：按括号深度找配对的 `)`，跳过引号内的内容
    if (c === '$' && text[i + 1] === '(') {
      let depth = 0
      let end = -1
      for (let j = i + 1; j < text.length; j += 1) {
        const d = text[j]
        if (d === '\\') { j += 1; continue }
        if (d === "'") {
          const e = text.indexOf("'", j + 1)
          if (e < 0) break
          j = e
          continue
        }
        if (d === '"') {
          let e = -1
          for (let k = j + 1; k < text.length; k += 1) {
            if (text[k] === '\\') { k += 1; continue }
            if (text[k] === '"') { e = k; break }
          }
          if (e < 0) break
          j = e
          continue
        }
        if (d === '(') depth += 1
        else if (d === ')') { depth -= 1; if (depth === 0) { end = j; break } }
      }
      if (end < 0) { rest += c; continue }
      extracted.push(text.slice(i + 2, end))
      i = end
      continue
    }
    rest += c
  }
  return rest
}

/**
 * heredoc opener 的**唯一定义**：`<<` / `<<-` + 可选转义 + 标签词。
 *
 * 标签词可以是由引号块与裸词**任意拼接**而成（`EOF` / `'EOF'` / `a"b<<c"` /
 * `"a"b` / `'a'\"b\"`）：bash 的 delimiter 就是这个词做 quote removal 的结果，
 * 引号只影响是否做参数展开，**不属于分隔符本身**。
 *
 * 为什么必须收敛成一个常量：这个正则有两处消费方，且**必须给出同一个标签**——
 *   · `stripHeredocBody`：按它找 opener、按 `heredoc[1]` 剥引号得到终止符；
 *   · `maskFakeHeredocOpeners`：按它判断「这段 `<<` 是不是真 opener」，从而跳过整个标签。
 * 两处一旦不一致，掩码就会改掉真标签（`cat <<a"b<<c"` 的 delimiter 是 `ab<<c`，
 * 掩码后成 `ab <c`）⇒ 终止符找不到 ⇒ 其后整段真命令被截掉（fail-open，已实测）。
 *
 * `(?<!<)` 排除 here-string 的 `<<<`；字符类排除 `\n`，因为标签不会跨行。
 */
const HEREDOC_OPENER_RE = /(?<!<)<<-?[ \t]*\\?((?:'[^'\n]*'|"[^"\n]*"|[^\s;|&()<>'"\\])+)/

/**
 * 把**引号 / 注释 / 算术展开**里的 `<<` 打成字面量（第一个 `<` 换成空格）。
 *
 * 为什么需要它：`stripHeredocBody` 的 opener 正则只看字符、不看上下文，于是
 * `echo "a<<b"` / `# 用 heredoc（<<DOC）写配置` / `echo $((1<<2))` 里的 `<<` 会被
 * 当成 heredoc 的开头。那个「标签」（`b` / `DOC` / `2`）在正文里当然找不到单独成行的
 * 终止符，于是走 `!end` 分支 —— 而该分支在 `stripped === 0` 时把其后**所有行**整段
 * 丢掉，连真命令一起丢（fail-open）。实测（bash，八档全 deny）：
 *     echo "a<<b"
 *     rm -rf /data <<EOF
 *     body
 *     EOF
 *   修复前 `rawCommandNames` 只看到 `echo` ⇒ 整条 allow；而真 bash 会执行那个
 *   `rm -rf /data`（第一行是独立命令、第二行是合法 heredoc）。
 *
 * 做法是**只改喂给 opener 正则的那份文本**：假 opener 的第一个 `<` 换成空格
 * （长度与换行都不变），于是正则只在命令上下文里命中，而 `heredoc.index` 与标签在
 * 原文本里仍然对得上（调用方用原文本切片）。没有假 opener 时**原样返回**。
 *
 * 上下文判据与 bash 一致，也与本文件词法器同源：
 *   · 单引号块 / 注释块：内部一切是字面量（注释到行尾为止，`\` 不延长它）；
 *   · 双引号块：`\` 转义、`<<` 是字面量，但 `$(` 与反引号是**命令替换**
 *     （真会执行，里面的 `<<` 是真 heredoc）—— 那两段递归回命令上下文；
 *   · 算术展开 `$(( … ))`：`<<` 是左移（字面量）；其中的 `$(` 极罕见，按字面量处理
 *     （与「少扫」同向，不新增放宽）；
 *   · 命令替换（`$( … )` / 反引号）在命令上下文里同样是命令上下文。
 *
 * 递归深度上限 8：与 `expandSubstitution` 同一条纪律（防病态输入下打转）。
 *
 * @param {string} src 原始文本
 * @returns {string} 等长文本：假 opener 的第一个 `<` 已换成空格；没有假 opener 时原样返回
 */
function maskFakeHeredocOpeners(src) {
  // 快速路径：没有 `<<` 就既没有 heredoc 也没有假 opener（绝大多数命令走这里，
  // 判定热路径不因本函数多付一次逐字符扫描）。
  if (src.indexOf('<<') < 0) return src
  const hits = []
  // `#` 只在**词首**才是注释（与词法器的 `char === '#' && !started` 同判据）。
  // 误判方向的取舍与 `stripLineContinuations` 相同：把「其实不是注释」的位置当成注释
  // ⇒ 少掩码 ⇒ 退回改动前的行为（不放宽）；反过来才会把命令藏进注释。
  const isWordBreak = (c) => c === ' ' || c === '\t' || c === '\n' || c === '\r'
    || c === ';' || c === '|' || c === '&' || c === '(' || c === ')' || c === '<' || c === '>'
  // 把 [from, to) 里的 `<<` 全部记下（字面量上下文：单引号内 / 注释内 / 算术内）
  const markRun = (from, to) => {
    for (let k = from; k + 1 < to; k += 1) if (src[k] === '<' && src[k + 1] === '<') hits.push(k)
  }
  // 扫**命令上下文** [from, to)；`to < 0` 表示扫到文本末尾。
  const scanCmd = (from, to, depth) => {
    if (depth > 8) return
    let i = from
    let wordStart = true
    while (i < src.length && (to < 0 || i < to)) {
      const c = src[i]
      // 转义：连同被转义的那个字符一起跳过（`\<` 不是 `<`、`\'` 不开启引号）
      if (c === '\\') { i += 2; wordStart = false; continue }
      if (c === "'") {
        const e = src.indexOf("'", i + 1)
        // 单引号内**一切**是字面量（`$` / `\` / `<<` 都不特殊），不需要递归
        markRun(i + 1, e < 0 ? src.length : e)
        i = e < 0 ? src.length : e + 1
        wordStart = false
        continue
      }
      if (c === '"') {
        // ── 双引号块：**按区间**掩码，不逐对匹配 ─────────────────────────────────
        // 逐对匹配（`if (d === '<' && src[k+1] === '<') { push(k); k += 2 }`）会漏掉
        // **重叠**的 `<<`：`"a<<<b"` 只掩第一对、残留第二对 `<<b`，opener 正则照样命中，
        // 于是 `!end` 分支又把其后整段真命令截掉（与 M1 同一族 fail-open，只是数量不同）。
        // 实测该族：双引号内连续 3/5/7/9/11 个 `<`、`"a<<<b<<<c"`、`"a <<< b"` 全部触发。
        // 区间掩码（`markRun` 逐个 push，不跳过）对任意数量与位置都成立，与单引号/注释/
        // 算术三个分支用**同一份**判据 —— 少写一份「配对逻辑」就少一处会漏的地方。
        // 转义不需要特判：`markRun` 覆盖整段字面量区间，`"\<<"` 里的两个 `<` 照样被掩。
        // 唯一要排除的是**命令替换**区间（`$( )` / 反引号，真会执行，里面可能是真 heredoc），
        // 故遇到它们时先把前面的字面量段掩掉，再递归回命令上下文。
        let k = i + 1
        let end = -1
        let segStart = k
        while (k < src.length) {
          const d = src[k]
          if (d === '\\') { k += 2; continue }
          if (d === '"') { end = k; break }
          if (d === '$' && src[k + 1] === '(' && src[k + 2] !== '(') {
            const e2 = skipBalanced(src, k + 1, '(', ')')
            if (e2 < 0) { k = src.length; break }
            markRun(segStart, k)
            scanCmd(k + 2, e2, depth + 1)
            k = e2 + 1
            segStart = k
            continue
          }
          if (d === '`') {
            const e2 = src.indexOf('`', k + 1)
            if (e2 < 0) { k = src.length; break }
            markRun(segStart, k)
            scanCmd(k + 1, e2, depth + 1)
            k = e2 + 1
            segStart = k
            continue
          }
          k += 1
        }
        markRun(segStart, end < 0 ? src.length : end)
        i = end < 0 ? src.length : end + 1
        wordStart = false
        continue
      }
      if (c === '#' && wordStart) {
        const nl = src.indexOf('\n', i)
        const stop = nl < 0 ? src.length : nl
        markRun(i + 1, stop)
        i = stop
        wordStart = true
        continue
      }
      if (c === '$' && src[i + 1] === '(' && src[i + 2] === '(') {
        const e = skipBalanced(src, i + 1, '(', ')')
        if (e < 0) { i = src.length; break }
        markRun(i + 3, e)
        i = e + 1
        wordStart = false
        continue
      }
      // 算术**命令** `(( … ))`：与 `$(( … ))` 同一种上下文（`<<` 是左移），只是没有 `$`。
      // 不认它时 `((x<<2))` 打头的行会让 opener 正则把 `<<2` 读成 heredoc，标签 `2`
      // 找不到终止符 ⇒ `!end` 把其后整段真命令截掉（与 M1 同一族）。
      // 判据要求**紧邻** `((`（`( (cmd) )` 有空格、不是算术）且能配平 `))`；
      // 配不平的按普通字符继续扫（`(` 是词界），不猜。
      if (c === '(' && src[i + 1] === '(') {
        const e = skipBalanced(src, i, '(', ')')
        if (e > i + 1) {
          markRun(i + 2, e)
          i = e + 1
          wordStart = false
          continue
        }
      }
      if (c === '$' && src[i + 1] === '(') {
        const e = skipBalanced(src, i + 1, '(', ')')
        if (e < 0) { i = src.length; break }
        scanCmd(i + 2, e, depth + 1)
        i = e + 1
        wordStart = false
        continue
      }
      if (c === '`') {
        const e = src.indexOf('`', i + 1)
        if (e < 0) { i = src.length; break }
        scanCmd(i + 1, e, depth + 1)
        i = e + 1
        wordStart = false
        continue
      }
      // ── 命令上下文里的 `<<`：**不掩码**，跳过**整个标签词** ─────────────────────
      // 它要么是真 heredoc（`stripHeredocBody` 自己会剥离），要么是 here-string 的
      // `<<<`（下面用 `src[i + 2] !== '<'` 排除，与 opener 正则的 `(?<!<)` 同向）。
      //
      // ⚠️ 标签词里可能**含有 `<<`**，而它属于分隔符本身、不是假 opener。必须按
      // opener 正则**同一个定义**跳过整段标签，否则 `stripHeredocBody` 读到的标签会被掩码
      // 改掉（`cat <<a"b<<c"` 的 delimiter 是 `ab<<c`，掩码后变成 `ab <c`）⇒ 找不到终止符
      // ⇒ 走 `!end` 分支把其后整段真命令截掉（fail-open，实测 HEAD=deny → 现在 allow）。
      //
      // 曾经这里只「跳过开头的连续引号块」（`while (src[k] === "'" || '"')`），于是
      // **裸词在前、引号块在后**的标签（`a"b<<c"`）被当成「裸词标签 `a` + 一个普通引号串」：
      // 裸词部分按「`<` 是标签终止字符」处理（对），但**后面那个引号块**接着被双引号分支
      // 当字面量掩码了（错）—— 于是同一个标签的两半用了两套判据。实测受影响的五个形态：
      // `a"b<<c"` / `a'b<<c'` / `a"<<"b` / `a"b<<c"d` / `E"O<<F"`，全部 HEAD=deny → 现在 allow。
      //
      // 修法是**判据同源**而不是再补一段「跳过引号块」的循环：正则本来就知道标签到哪结束，
      // 直接复用它（`HEREDOC_OPENER_RE`，与 `stripHeredocBody` 用的是同一份字面量），
      // 少写一份「标签词由哪些片段组成」的知识就少一处会漂移的地方。
      if (c === '<' && src[i + 1] === '<' && src[i - 1] !== '<' && src[i + 2] !== '<') {
        const m = HEREDOC_OPENER_RE.exec(src.slice(i))
        // 配不上时（例如 `<<` 后面直接是行尾）按最短步进 —— 只跳过这两个字符，
        // 与「少掩码」同向（不放宽）。
        i = m ? i + m[0].length : i + 2
        wordStart = false
        continue
      }
      wordStart = isWordBreak(c)
      i += 1
    }
  }
  scanCmd(0, -1, 0)
  if (!hits.length) return src
  // 等长替换：只把假 opener 的**第一个** `<` 换成空格（长度与换行都不变，
  // 故 `heredoc.index` 在原文本里仍然对得上）
  const chars = src.split('')
  for (const k of hits) chars[k] = ' '
  return chars.join('')
}

/**
 * 从**读不懂的原文**里粗提「可能是命令名」的候选，仅供整行 ok:false 时查 deny 例外。
 *
 * 为什么需要它：整行 ok:false（heredoc / 未闭合引号 / 悬空操作符）时没有段可判，
 * 而用户显式写的 deny 例外不该因为「命令换了个语法形态」就失效 ——
 * 实测 `rm -rf /data <<EOF\nx\nEOF`（合法 heredoc，会真实执行）绕过了 `rm *`=deny 例外。
 *
 * 这是**粗提**，不是第二次解析：按空白与操作符切分，取每个片段的首词并归一化。
 * 多提几个名字是安全的（调用方只用它查 deny，方向只会收紧），
 * 但绝不能反过来用它授权 —— 所以 allow/ask 例外在这条路径上一律不认。
 *
 * **必须丢掉 heredoc 正文**：`<<EOF` 之后到终止符之间的内容是**数据**，不是命令。
 * 不丢的后果是误判 —— 实测 `cat > doc.txt <<EOF\nrm -rf is dangerous\nEOF`
 * 会因为正文里出现 `rm` 而被判成破坏性命令（正文只是要写进文件的文本）。
 * 终止符取 `<<` 后紧跟的那个词（`<<EOF` / `<<'EOF'` / `<<-EOF` 都算），
 * 从它首次单独成行的位置截断；找不到终止符就只保留 `<<` 之前的部分
 * （正文范围不确定时宁可少扫，方向仍是「命令部分照常查」，不会因此放行真命令）。
 */
/**
 * 丢掉 heredoc 正文，只留下**命令行**部分。
 *
 * 终止符取 `<<` 后紧跟的那个词（`<<EOF` / `<<'EOF'` / `<<-EOF` 都算），
 * 从它首次单独成行的位置截断；找不到终止符就只保留 `<<` 之前的部分
 * （正文范围不确定时宁可少扫，方向仍是「命令部分照常查」，不会因此放行真命令）。
 *
 * **提成单点**：`rawCommandNames` 与 `outsideTargetInUnparsable` 都要问「命令部分到哪为止」。
 * 判据分叉的后果是把 heredoc 正文（**数据**，不是命令）当成命令扫 ——
 * `cat > doc.txt <<EOF\nrm -rf is dangerous\nEOF` 会因为正文里出现 `rm` 而被判成破坏性命令。
 *
 * @param {string} source 原始文本
 * @returns {string} 已丢掉 heredoc 正文的文本
 */
function stripHeredocBody(source) {
  // 正则的三处细节都是**实测**逼出来的（各有一个方向）：
  //
  // ① `(?<!<)` 排除 here-string（`<<<x`）。它不是 heredoc —— 正文就是同一行的那个词，
  //    **不吞后续行**。不排除时 `[A-Za-z_]` 会从 `<<<x` 的第三个 `<` 之后读到标签 `x`，
  //    把其后整段当正文吞掉。真 bash 实测 `cat <<<x\nrm -rf v` → **v 被删**（会被放行）。
  // ② `\\?` 必须放在捕获组**外**。`<<\EOF` 的反斜杠转义分隔符是**合法 heredoc**
  //    （真 bash 实测 `cat <<\EOF\nrm -rf v\nEOF` → v **不被删**，正文是数据），
  //    但把反斜杠放进组内（`(['"\\]?)`）会让反向引用 `\1` 去匹配那个反斜杠：
  //    `<<\EOF` 上直接 NO-MATCH（实测），于是正文被当命令 → 八档全 deny 的**误拦**。
  // ③ 分隔符类必须是 bash **真正的**分隔符集合，且**不靠反向引用**配对引号：
  //    只允许引号**整体包住**分隔符（`(['"]?)([A-Za-z_][A-Za-z0-9_]*)\1`）时，引号夹在
  //    分隔符**中间**的写法（`<<E"OF"`）被读成 `<<E`、标签取 `E` ⇒ 找不到终止符 `EOF`
  //    ⇒ 走 `!end` 分支把终止符**之后**的真命令整段丢掉。真 bash 实测
  //    `cat <<E"OF"\nbody\nEOF\nrm -rf v` → v **被删**（八档全 deny 下被放行）。
  //    同族漏网还有 `<<END-OF` / `<<END.OF` / `<<""` / `<< E"OF"` / `<<\E"OF"`。
  //    引号内的**换行**在真 bash 里是**语法错误**（实测 `cat <<'E` + 换行 + `OF'` →
  //    syntax error），故字符类排除 `\n`：那种形态本就不执行，NO-MATCH 只走 `!end`（收紧）。
  //    标签由 `heredoc[1]` 剥掉引号得到（bash 语义：引号只影响是否做参数展开，不属分隔符本身）。
  let out = ''
  let rest = source
  // ── 循环剥离**每一个** heredoc──────────────────────────────────────
  // 只处理第一个 opener 时，`slice(0, heredoc.index)` 把第一个 opener 之后的**一切**丢掉 ——
  // 第二个 heredoc 的正文被顺带丢掉（错误理由下的正确结果）。新写法把终止符之后的整段接回，
  // 于是第二个 heredoc 的头与正文重新进入被扫文本。
  //
  // ⚠️ 但**不能**无条件循环：真 heredoc 剥离后，下一个「opener」可能是引号/注释里的
  // **假 opener**（`echo "x<<y"`、`# a<<b`、`$((x<<y))`），它的 `!end` 分支会把其后整段
  // 真命令截掉 ⇒ 六处 fail-open（真 bash 实测这些命令**会执行**）。故加**方向守卫**：
  // `!end` 时若 `stripped === 0` 保持既有截断（与 HEAD 同向，不引入新放宽），否则 `break`
  // 返回当前已剥离的文本（**不**截断后续）。
  //
  // ⚠️ 方向守卫只覆盖「真 heredoc 之后又出现假 opener」；**第一个 opener 就是假的**
  // （`echo "a<<b"` 打头，后面才是真命令）同样会被 `!end` 整段截掉。故 opener 的匹配
  // 必须先过 `maskFakeHeredocOpeners`：它把引号/注释/算术里的 `<<` 打成字面量，
  // 于是这里的正则只在**命令上下文**命中。两者长度一致，故 `heredoc.index` 在
  // `rest` 里仍然对得上（下面用 `rest.slice` 取原文本）。
  for (let stripped = 0; ; stripped += 1) {
    const heredoc = HEREDOC_OPENER_RE.exec(maskFakeHeredocOpeners(rest))
    if (!heredoc) break
    const tag = heredoc[1].replace(/['"]/g, '')
    const afterTag = heredoc.index + heredoc[0].length
    // ① `<<TAG` **同一行**的剩余部分是命令行，必须保留 —— 操作符之后照常执行。
    //    真 bash 实测 `rm -rf ./build <<EOF ; rm -rf v\nbody\nEOF` → v **被删**
    //    （`&&` / `|` / `&` 同；`||` 因左侧成功而不执行，保留它只会多扫，方向是收紧）。
    const nl = rest.indexOf('\n', afterTag)
    const lineEnd = nl < 0 ? rest.length : nl
    const sameLine = rest.slice(afterTag, lineEnd)
    const body = rest.slice(lineEnd)
    // 从 `<<TAG` 之后找首次「单独成行」的 TAG（允许前置制表符，兼容 `<<-`）。
    // 标签可能含 `.` / `-` 等正则元字符，必须转义后再拼进终止符正则。
    const tagRe = tag.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
    const end = new RegExp('^[ \\t]*' + tagRe + '[ \\t]*$', 'm').exec(body)
    if (!end) {
      // 找不到终止符：正文范围不确定，只保留 `<<TAG` 之前的部分 + 同行剩余（宁可少扫）。
      // 只对**第一个** opener 保持这个截断（与既有行为同向）；后续 opener 是假 opener 的
      // 可能性很高，截断它会吞掉真命令，故 break 交回当前文本。
      if (stripped === 0) return out + rest.slice(0, heredoc.index) + sameLine
      break
    }
    // ② **终止符之后**的整段也是命令行。真 bash 实测
    //    `rm -rf ./build <<EOF\nbody\nEOF\nrm -rf v` → v **被删**。
    //    终止符行上的尾随内容（`EOF ; rm -rf v`）不是命令（实测**不**执行），
    //    故从终止符行之后的第一个换行起截取，只丢正文。
    const nl2 = body.indexOf('\n', end.index + end[0].length)
    out += rest.slice(0, heredoc.index) + sameLine
    if (nl2 < 0) { rest = ''; break }
    rest = body.slice(nl2)
  }
  return out + rest
}

/**
 * 引号感知分词器：引号内的**空白与操作符**都不算分隔符，token 内的引号按 bash 语义剥掉。
 *
 * 为什么必须是**一份**实现（而不是「先原切分、判不出再合并」的两份）：原实现先用
 * `body.split(/[\n\r;|&(){}<>]+/)` 切，而这个正则**对引号无感知** —— 引号**内**的
 * `& | ; ( ) { } < >` 同样被切开，切碎后的两片各自都不含完整引号对，而
 * `mergeQuotedWords` 只在**引号内的空白**上合并，无从恢复。于是判不出目标 ⇒
 * `outside` 档失明。真 bash 实测这些形态**会执行**（`outside=deny`、其余七档 allow 下
 * 裸命令 deny、带构造 allow）：`rm -rf "D:/R&D"`、`"D:/my project (old)"`、`"D:/a|b"`、
 * `"D:/a;b"`、`"D:/a&b"`、`"D:/my project"/sub`、`"D:/data;backup"`、
 * `"D:/Project {old}"`；对照 `"/data/my project"`（无操作符字符）本就判 deny ——
 * 同一语义两个结论，正是本文件反复要修的那类漂移。
 *
 * 两份实现合并成一份后**没有第二候选**（调用方只用它）：方向说明见
 * `outsideTargetInUnparsable`（多认目标只会让更多档参与「取最严」，不放宽任何东西）。
 *
 * 返回**段数组**（每个操作符切出一段）而不是拉平成一维：调用方按段调
 * `blastRadiusOfSegment`，拉平会让后一段的命令名被前一段当成目标实参。
 *
 * @param {string} text 已丢掉 heredoc 正文的文本
 * @returns {string[][]} 每段的词元（引号已剥）
 */
function splitQuotedTokens(text) {
  const out = []
  let seg = []
  let cur = ''
  let quote = null
  // `has` 区分「空词元」与「还没有词元」：`cat ""` 的第二个词元是**空串**而不是不存在。
  let has = false
  const flushTok = () => { if (cur || has) { seg.push(cur); cur = ''; has = false } }
  const flushSeg = () => { flushTok(); if (seg.length) { out.push(seg); seg = [] } }
  for (const ch of String(text)) {
    if (quote) {
      // 引号**内**：一切字符都是普通字符（空白与操作符都不切），但引号本身按 bash 语义剥掉
      if (ch === quote) quote = null
      else cur += ch
      has = true
    } else if (ch === '"' || ch === "'") {
      quote = ch
      has = true
    } else if (ch === '\n' || ch === '\r' || ch === ';' || ch === '|' || ch === '&'
      || ch === '(' || ch === ')' || ch === '{' || ch === '}' || ch === '<' || ch === '>') {
      flushSeg()
    } else if (ch === ' ' || ch === '\t' || ch === '\f' || ch === '\v') {
      flushTok()
    } else {
      cur += ch
      has = true
    }
  }
  flushSeg()
  return out
}

/**
 * 整行读不懂时，原文里是否**读得出一个 `outside` 目标**（工作区外）。
 *
 * 为什么需要它：整行 `ok:false`（heredoc / 悬空操作符 / 未闭合引号）时没有词元可判，
 * 那条路径的档位集合由 `groupTiersOf(names) + priv + RADIUS_TIERS_WHEN_UNREADABLE` 拼成，
 * 而 `RADIUS_TIERS_WHEN_UNREADABLE` 是 `wide ∪ unknown ∪ inside` —— **不含 `outside`**。
 * 于是用户显式配的 `outside=deny` 在这条路径上整个失明（fail-open）：
 *     rm -rf /etc              → deny（段级 outside 档）
 *     rm -rf /etc <<EOF…EOF    → **allow** ← 同一命令，只因多了个 heredoc
 *
 * ── 为什么不能「无条件并入 `outside`」──────────────────────────────────────────
 * `outside` 是「工作区**外**」这一**具体**档，而这条路径上「读不出目标」的语义是
 * 「可能区内、可能大范围」—— 不是「确定在区外」。无条件并入会让**八档全 allow** 的
 * 用户也拿到一个 `outside` 档，`test/shell-parse.mjs` 的 58d / 58e3 正是钉这一点
 * （那两条断言用的目标是 `C:/Windows` 与 `./build`，**都不是** `outside`）。
 *
 * 故判据收窄为：**只有原文里真的读得出一个落在工作区外的目标时**才并入 ——
 * 这与段级路径对同一目标给出的结论同源（`blastRadiusOfSegment` + `radiusTierOf`），
 * 不是另造一套「哪里算区外」的知识。
 *
 * ⚠️ 目标**可能属于另一个段**（`rm -rf ./build && echo /etc <<EOF` 的 `/etc` 属于 `echo`）——
 * 那是**假阳性**，方向是收紧（多一个档参与取最严），与 `rawCommandNames` 的粗提同一条
 * 取舍：多认几个只会让更多档参与「取最严」，不会放宽任何东西。
 *
 * ⚠️ 必须丢掉 heredoc 正文（`stripHeredocBody`）：正文是**数据**，不是命令，
 * 拿它判档会让 `cat > doc.txt <<EOF\nrm -rf /etc\nEOF` 凭空多出一个 `outside` 档。
 *
 * ── 反引号按**段分隔符**处置（不是逐词元剥掉）────────────────────────────────────
 * 词法器**不吞**反引号：`` `rm -rf /data` `` 是带引号的**字面词元**，
 * `blastRadiusOfSegment(['echo', '`rm', '-rf', '/data`'])` 的命令头是 `echo`、`/data`
 * 只是它的实参 ⇒ `blast=null` ⇒ `outside` 档失明（方向 fail-open）。
 * 而**剥掉**反引号（`replace(/`/g, '')`）只堵住「构造独立成段」那一半：整段变成
 * `echo rm -rf /data`，段首仍是 `echo`，同样判不出 —— 实测 `` echo `rm -rf /data` `` 的
 * 四种读不懂形态里**两种仍 allow**。故这里把反引号当**分隔符**（与 `$()` 的 `(` `)`
 * 同待遇）：`` echo `rm -rf /data` `` 切成 `echo` 与 `rm -rf /data` 两段，后一段的段首
 * 就是 `rm`，判档与裸命令同源。方向仍是收紧（多认目标只会让更多档参与取最严）。
 *
 * @param {string} source 整行原文
 * @param {object} [opts] 判档选项（`home` / `userHome` / `platform` / `isOutsideWorkspace`）
 * @returns {boolean} 原文里读得出工作区外的目标时为真
 */
function outsideTargetInUnparsable(source, opts) {
  // ⚠️ 顺序不可交换：必须**先**剥 heredoc 正文，**再**把反引号换成换行。
  // 反过来（先换反引号）会把 opener 与终止符拆到不同行 ⇒ `stripHeredocBody` 找不到终止符
  // ⇒ 走 `!end` 分支截断 ⇒ 反引号之后的真命令整段被丢弃（`outside=deny` 下 fail-open）。
  const body = stripHeredocBody(String(source == null ? '' : source)).replace(/`/g, '\n')
  // 切分与 `rawCommandNames` **同一份判据**（空白与操作符），不另写一套 ——
  // 两条路径对「哪一段是命令」的认识必须一致，否则同一个 heredoc 在
  // 「查 deny 例外」与「判 outside 档」两处看到不同的命令集合。
  //
  // ⚠️ 但切分**必须引号感知**：`body.split(/[\n\r;|&(){}<>]+/)` 对引号无感知，引号**内**的
  // `& | ; ( ) { } < >` 同样被切开，而两片各自都不含完整引号对 ⇒ 判不出目标 ⇒
  // `outside` 档失明（真 bash 实测 `rm -rf "D:/R&D"` 等会执行）。故改用
  // `splitQuotedTokens`（引号内空白与操作符都不切、token 内引号按 bash 语义剥掉）。
  // 词元已剥引号，无需再套一层「剥成对首尾引号」的正则。
  for (const tokens of splitQuotedTokens(body)) {
    let b = null
    try { b = blastRadiusOfSegment(tokens, opts) } catch (e) { b = null }
    // 判据问的是**档**（`radiusTierOf`）而不是 blast level：`outside` 档只由
    // `level === 'outside'` 产出（`system` / `home` 那一族归 `wide`，不归 `outside`）。
    if (b && radiusTierOf(b) === 'outside') return true
  }
  return false
}

export function rawCommandNames(text) {
  const out = []
  // 去重集合无原型：键是 label（来自命令文本）。用 `{}` 时 `constructor` / `__proto__`
  // 这类名字恒判「已见过」而被丢弃 —— 它们恰是本函数要抓出来的命令名。
  const seen = Object.create(null)
  rawCommandNamesInto(text, 'bash', out, seen)
  return out
}

/**
 * `rawCommandNames` 的**带方言姊妹出口**。
 *
 * 保留 `rawCommandNames(text)` 的单参签名与调用点字面形态不变（`test/regressions.mjs`
 * 有三条结构断言把签名行与「opaque 段并集那一行」逐字锁定），方言维度由本出口承担。
 *
 * @param {string} text 原文
 * @param {'pwsh'|'bash'} [shell] 方言（决定赋值判据，见 `rawCommandNamesInto`）
 * @returns {string[]} 去重后的命令名（顺序与 `rawCommandNames` 同）
 */
export function rawCommandNamesWithShell(text, shell) {
  const out = []
  const seen = Object.create(null)
  rawCommandNamesInto(text, shell === 'pwsh' ? 'pwsh' : 'bash', out, seen)
  return out
}

/**
 * `rawCommandNames` 族的**单一实现**（带方言维度）—— 两个出口都只是它的薄壳，
 * 故「文本粗提」这件事只有一份判据。
 *
 * ── 为什么必须带方言（本轮缺陷 2：PRE 引入、第二批未修，相对 HEAD 是真回归）──────
 * 本函数走的是**文本**：下面 `tokens` 是它自己 `split` 出来的新数组，上面没有词法器的
 * 方言戳（`SEG_SHELL`），故方言只能由调用方显式传进来。而赋值守卫是**方言相对**的
 * （见 `LABEL_ASSIGN` 的说明）——按 bash 判会让 **pwsh 侧藏在 opaque 构造里的靶形态**
 * 认不出命令名，于是破坏性判定与 deny 例外双双失明（**fail-open**）：
 *     `echo $(A=/bin/rm)` / `(A=/bin/rm)` / `{ A=/bin/rm; }` / `` echo `A=/bin/rm` ``
 *   实测（大分类 allow + 八档全 deny，两门方言共 96 格）：HEAD=deny → PRE=NOW=**allow**。
 *   ⚠️ bash 侧该形态**本来就没有命令要执行**（`$(A=/bin/rm)` 是赋值），label 为空是对的
 *   —— 故方言按出口分列，而不是让 bash 侧跟着变。
 *
 * @param {string} text 原文
 * @param {'pwsh'|'bash'} shell 方言（决定赋值判据）
 * @param {string[]} out 累加器（去重后的命令名，按出现次序）
 * @param {Record<string, number>} seen 去重集合（**必须无原型**，见 `rawCommandNames` 的说明）
 */
function rawCommandNamesInto(text, shell, out, seen) {
  // 丢掉 heredoc 正文（`<<TAG` 之后到终止符之间的内容是数据，不是命令 —— 见函数注释）
  const body = stripHeredocBody(String(text == null ? '' : text))
  // 命令替换（`$(...)` 与反引号）**必须先于引号剥离**处理。
  //
  // 为什么：命令替换里的内容**会被执行**，而它经常出现在双引号内
  //（`echo "$(rm -rf /x)"` 在 bash 里真的会执行 `rm`）。
  // 早期实现先剥双引号、再处理反引号，于是双引号内的命令替换被连内容一起剥掉：
  //   `echo "$(rm -rf /x)"`   → raw=["echo"]，rm 不可见
  //   `echo "\`rm -rf /x\`"`  → raw=["echo"]，同上
  //   `echo $(rm -rf /x)`     → raw=["echo","rm"]（无引号时才对）
  // 而单引号内的命令替换**不会执行**（`'$(rm -rf /x)'` 是纯文本），必须保持被剥掉。
  //
  // 处理顺序（每步都只把「会被执行的内容」留下）：
  //   ① 剥单引号（整块丢弃 —— 单引号内一切都不执行）
  //   ② **摘出**命令替换的内容（`$(` … `)` 与 `` ` `` … `` ` ``），从原位置移走
  //   ③ 剥双引号（此时双引号里已不含命令替换，剥掉是安全的）
  //   ④ 把 ② 摘出的内容拼回来参与切分
  //
  // 为什么 ② 必须「摘出」而不是「换定界符」：`echo "\`rm -rf /x\`"` 若只把反引号换成 `;`，
  // 得到 `echo ";rm -rf /x;"` —— 内容仍在双引号**内部**，③ 剥双引号时整块被替换成空格，
  // 内容照样丢失（实测踩过）。摘出来放到末尾才不受 ③ 影响。
  const noSingle = body.replace(/'(?:[^']*)'/g, ' ')
  const extracted = []
  const withoutSubst = replaceCommandSubstitution(noSingle, extracted)
  // 摘出的内容里可能还有**内层**命令替换，必须递归展开：
  //   `echo $(echo \`rm -rf /x\`)`   → 外层摘出 `echo \`rm -rf /x\``，内层反引号还要再摘一次
  //   `echo \`echo \`rm -rf /x\`\``  → 反引号内的转义反引号同理
  // 不递归的后果是内层命令不可见（实测这两条在 command=allow + destructive=deny 下曾是 allow，
  // 而它们在 bash 里是**合法可执行**的，rm 真的会跑）。
  // 深度上限 8：命令替换不会嵌那么深，纯粹防病态输入下打转。
  const expanded = []
  for (const item of extracted) expanded.push(...expandSubstitution(item, 8))
  const stripped = withoutSubst.replace(/"(?:[^"\\]|\\.)*"/g, ' ') + ' ; ' + expanded.join(' ; ')
  for (const piece of stripped.split(/[\n\r;|&(){}<>]+/)) {
    const tokens = piece.trim().split(/\s+/).filter(Boolean)
    if (!tokens.length) continue
    // 用 segmentLabels 而非 commandNameOf(首词) 取名字：前者会剥掉前缀包装器
    // （env/timeout/nice/command/nohup…）、展开 find -exec/-delete、跳过语句关键字。
    // 只用首词会让这些形态在这条路径上失效 —— 实测 `env rm -rf /x <<EOF` 与
    // `find . -delete <<EOF` 都因为首词是 env/find 而被判成非破坏性（allow），
    // 而同样两条命令不带 heredoc 时是 deny。
    // 这是「单一来源」的又一次应用：归一化只该有一份实现。
    //
    // 注意**不要**按 heredoc 标签过滤名字：标签与真命令同名是合法的
    //（`rm -rf /x <<rm` 的标签就叫 rm），过滤会把真命令一起丢掉（漏判方向是放行）。
    // 正文与终止符已经在上面按位置切掉了，标签本身不会作为片段出现。
    // ⚠️ 方言**必须显式传**：`tokens` 是本函数自己 `split` 出来的
    //    新数组，上面没有词法器的方言戳（`SEG_SHELL`），不传就退回 `'bash'` ——
    //    而 pwsh 侧藏在 opaque 构造里的靶形态（`echo $(A=/bin/rm)` / `(A=/bin/rm)` /
    //    `` echo `A=/bin/rm` ``）在 bash 判据下是**赋值** ⇒ 认不出命令名 ⇒ 破坏性判定
    //    与 deny 例外双双失明（fail-open，实测 HEAD=deny → PRE=**allow**）。
    //    bash 侧该形态**本来就没有命令要执行**（`$(A=/bin/rm)` 是赋值），label 为空是对的。
    const labels = segmentLabels(tokens, shell)
    for (const name of labels) {
      if (!name || seen[name]) continue
      seen[name] = 1
      out.push(name)
    }
  }
  return out
}

// ── 词法器 ────────────────────────────────────────────────────────────────────

const BASH_EXPANSION = /\$[A-Za-z_][A-Za-z0-9_]*/y
const PWSH_EXPANSION = /\$(?:env:)?[A-Za-z_][A-Za-z0-9_]*/y
const CMD_VARIABLE = /%[A-Za-z_][A-Za-z0-9_()]*%/y
// 同一判据的**非 sticky** 视图（判档侧要的是「这个词元是不是 cmd 风格变量」，
// 不是「从某个下标起能不能读到它」）。从 CMD_VARIABLE 派生，不另写一份正则 ——
// 两份手写必然漂移，而漂移的后果是某类变量重新被判成「工作区内的相对路径」。
const CMD_VARIABLE_RE = new RegExp(CMD_VARIABLE.source)
const DESCRIPTOR_DUPLICATION = /[<>]&\s*(?:[0-9]+|-)/y
const REDIRECT_OPERATOR = /(?:>>|>\||>&|<&|>|<)/y

/**
 * 读一个 `$` 展开并返回它的书写形态；返回 undefined 表示这个构造**执行嵌套命令**而不是命名变量。
 * 只做「是不是可静态读懂的变量」这一个判断，不求值 —— 变量展开后的值一律不解析。
 */
function readExpansion(input, index, shell) {
  const next = input[index + 1]
  if (next === '(' || next === "'" || next === '"') return undefined
  if (next === '{') {
    const end = input.indexOf('}', index + 2)
    if (end < 0) return undefined
    const body = input.slice(index + 2, end)
    if (/[($`]/.test(body)) return undefined
    return input.slice(index, end + 1)
  }
  const m = matchAt(shell === 'pwsh' ? PWSH_EXPANSION : BASH_EXPANSION, input, index)
  return m === undefined ? '$' : m
}

/**
 * 读一个 PowerShell 转义（反引号 + 一个字符），返回 `{ raw, value, continuation }`。
 *
 * `raw` 是**原文**（含反引号，供 segText 保留用户写法）、`value` 是**转义后的真实字符**
 * （供 wordText —— 判定与 label 要按实际执行的命令看）、`continuation` 表示这是续行。
 *
 * 返回 `null` = 这不是一个合法转义（按 `ok:false` 处理，fail-closed）。
 *
 * ⚠️ 转义表 `PWSH_ESCAPES` 的说明里有逐格实测值；本函数只负责「查表 / 续行 / 行尾 / 未知」四分：
 *   · 表内命中          → `value` = 表里的字符；
 *   · `` ` `` + 换行     → `continuation`（**不产生词元**，把两行接起来）；
 *   · 其余（含未知字母） → `value` = **该字符本身**（`` `z `` → `z`，实测如此，
 *     与 bash 的 `\z` → `\z` **不同构** —— 这正是不能照搬 bash 分支的原因）。
 *
 * ⚠️ `` ` `` + `\r\n` 要整体吃掉：CRLF 换行在 Windows 上由 AI 生成时很常见，
 * 只吃 `` ` ``+`\r` 会把 `\n` 留成下一轮的分段符，凭空多切一段。
 *
 * ⚠️ 但**词元内**（`ctx === 'bareword'`）恰恰相反：PS 只把 `` ` ``+`\r` 当转义（字面 CR），
 *    `\r\n` 里的那个 `\n` **仍是换行符**（`NewLine` ⇒ 语句边界）。官方解析器实测：
 *      `Write-Output abcz` + `` ` `` + **CRLF** + `zd`
 *        → `Generic[abcz`<CR>]` + `NewLine[<LF>]` + `Identifier[zd]`，**stmts=2**（切开）
 *      `Write-Output abcz` + `` ` `` + **LF**   + `zd`
 *        → **一个** `Generic[abcz`<LF>zd]`，stmts=1（粘住）
 *      `Write-Output abcz` + `` ` `` + **CR**   + `zd`
 *        → **一个** `Generic[abcz`<CR>zd]`，stmts=1（粘住）
 *    故 `ctx === 'bareword'` 时 CR 支只吃 `` ` ``+`\r`、`value` 取 `'\r'`，把 `\n` 留给主循环
 *    的换行分支去切语句。缺这一支时 CRLF 形态下两行粘成一个词元，第二行的破坏性命令
 *    不再单独判档 —— 实测（大分类 allow + `wide`=deny + 用户 deny 例外 `remove-item *`）
 *    由 `deny` 变 **`allow`**（fail-open）。
 *
 * ── Parameter 词元内：反引号是**字面字符**，不是转义符──────────────────
 * `ctx === 'parameter'` 时直接返回字面反引号（`value` 也是反引号）。官方解析器实测
 * （AST 的 `CommandParameterAst.Argument.Value` 是求值后的真值，token 表看不出差别）：
 *      `Write-Output -xz` + `` ` `` + `n` + `zd` → 参数名 `-xz`nzd`（反引号与 `n` **都原样保留**）
 *      `Write-Output abcz` + `` ` `` + `n` + `zd` → 词元求值 `abcz<LF>zd`（反引号消失、`n` → LF）
 * 即**表内字符在 Parameter 词元内同样不转义**，故本支必须排在查表之前，且不能按
 * 「表内 / 表外」分（那会漏掉 `` `n `` 这一族）。判据 `PWSH_PARAMETER_TOKEN` 由调用方算好传入。
 *
 * ── 行尾反引号：**紧贴词元是字面字符，另起词元才是语法错误**──────────
 * 这里此前一律返回 `null`（当语法错误），**过严** —— 于是「反引号在行尾」的合法命令
 * 整行 `ok:false`，而 `ok:false` 路径只认 deny 例外，用户配的 allow/ask 例外集体失明
 * （与本轮修的那个缺陷同一种失效模式，只是触发条件换成了行尾）。
 *
 * 官方解析器逐格实测（`[Parser]::ParseInput` + 实际求值）：
 *     `` `date` ``      → 词元 `date` + **字面反引号**，求值 `date` + `` ` ``  ✅ 合法
 *     `Write-Output abc` `` ` `` → 词元 `abc`` `` `，求值 `abc` + `` ` ``       ✅ 合法
 *     其余全部（`abc,` / `abc;` / `abc|` / `abc&` / `abc{` / `abc(` / `abc)` / `abc}` /
 *     `abc"` / `abc'` / 空白后 / 行首 / **引号内**）→ `IncompleteString`（真错误）
 * 即判据是「反引号**紧贴**在词元字符之后」：前一字符存在且不是**词元分隔符**
 * （空白、`;` `|` `&` `(` `)` `{` `}` `,` 与引号）时，它是**字面反引号**。
 * ⚠️ `[` `]` 不在分隔符集里 —— 实测 `abc]`+`` ` `` 合法（词元 `abc]`` `` `）。
 *
 * ⚠️ **引号内**没有这条规则：`"abc` + `` ` `` 实测是 `TerminatorExpectedAtEndOfString`
 * （字符串没闭合），故 `inQuote` 为真时行尾反引号一律算错误。两个上下文判据不同，
 * 靠调用方传入的 `inQuote` 区分，而不是在函数里猜。
 *
 * @param {string} input 命令行
 * @param {number} index 反引号的下标
 * @param {boolean} [inQuote] 是否在双引号内（判据不同，见上）
 * @param {{level: string, open: boolean}} [boundary] `pwshEscapeBoundaryAt` 的结果
 *   （**单一判据**，见该函数说明）：`level === 'segment'` = 反引号落在 Parameter 词元内
 *   （是字面字符，见上）；`open === true` = 词元**未完结**（`` ` ``+CRLF 只吃 CR，见上）；
 *   其余（词元边界处 / 引号内）`` ` ``+换行一律整体续行。
 * @param {object} [shape] 当前词元的**形态影子**（`wordShape`，与 `wordText` 严格同步）
 *   —— 只有 `'segment'` 支用它：判「反引号后面那个字符是否仍构成参数名」
 *   （`paramTokenWithNext`，见上）。⚠️ 不传 `wordText` 本身：那会把 rope 扁平化，O(n²)。
 * @returns {{raw: string, value: string, continuation: boolean}|null}
 */
function readPwshEscape(input, index, inQuote, boundary, shape) {
  const next = input[index + 1]
  const open = boundary !== undefined && boundary !== null && boundary.open === true
  // ⚠️ `next !== undefined` **必须**在条件里：行尾反引号（`next === undefined`）
  //    走下面那条**行尾分支**（按 `PWSH_TOKEN_BREAK` 判「紧贴词元 ⇒ 字面反引号 / 否则语法错误」），
  //    不能落进本支。缺这一格时下面 `paramTokenWithNext` 会拿到 `undefined` —— 那时旧实现
  //    求值的是 `PWSH_PARAMETER_TOKEN.test(word + undefined)`（**字符串拼接**），
  //    把字面量 `undefined` 连同反引号一起写进词元文本：
  //      `Remove-Item -Recurse` + `` ` `` → 词元 `-Recurse`undefined`（PS 真值是 `-Recurse`` `` `）
  //    实测 34 格中 **32 格**末词元与 `[Parser]` 真值不符，且 `wordText` / `segText` 双双被污染。
  //    后果是**用户显式写的精确 deny 例外失配**（例外 = 该命令原文时 PRE `deny` → `allow`，
  //    实测 5/5 格），同时面板候选值（用 `seg.text`）落盘成含 `undefined` 的模式，
  //    而 `matchCommand(真实原文, 污染串)` = false ⇒ 该例外**永不命中真实命令**（死规则）。
  if (boundary && boundary.level === 'segment'
    && next !== undefined && next !== '\n' && next !== '\r') {
    // Parameter 词元内：反引号是**字面字符**。后面那个字符归谁，由**同一个** `PWSH_PARAMETER_TOKEN`
    // 回答 —— 「`word + next` 还算不算一个合法 Parameter 词元」：
    //   · 还算（`<` `>` `n` `a` `]` `$` … 都是参数名字符）⇒ 两个字符**都**留在词元里。
    //     官方解析器实测：`cmd /c ver -x` + `` ` `` + `<` + `` ` `` + LF + `RemoveXyz`
    //       → `Parameter[-x`<`]` + `NewLine[<LF>]` + `Identifier[RemoveXyz]`、**stmts=2**。
    //     只吃反引号会让 `<` 落进重定向分支 ⇒ 两行被粘成一段（实测新引入 12 格反向误差）。
    //   · 不再算（`;` `|` `&` `,` `.` `[` `(` 空白 …）⇒ **只吃反引号**，该字符留给主循环按
    //     正常运算符处理。实测 `cmd /c ver -x` + `` ` `` + `;` + `` ` `` + LF + `RemoveXyz`
    //       → `Parameter[-x`]` + **`Semi[;]`** + `LineContinuation` + `Identifier[RemoveXyz]`、`stmts=2`
    //     —— `;` **仍是真语句分隔符**；把它当「转义的一部分」吞掉会让第二行的破坏性命令与
    //     第一行同判（实测由 `deny` 变 **`allow`**，fail-open）。
    // 用 `PWSH_PARAMETER_TOKEN` 自身做这个判定，是为了**不另写一份参数名字符类**
    // （本文件反复记录过「同一概念两处各写一份必然漂移」那类缺陷）—— 现由形态影子承担
    // （`paramTokenWithNext`，逐格等价，见该函数），**不得**改回 `word + next`（O(n²)）。
    // 表内字符同样不转义（实测 `Write-Output -xz` + `` ` `` + `n` + `zd` 的参数名是 `-xz`nzd`，
    // 而普通词元同形态求值成 `abcz<LF>zd`）⇒ 本支必须排在查表之前，且不能按「表内 / 表外」分。
    // ⚠️ 换行**不**走本支：`` ` ``+换行在 PS 里同样是真换行（`Parameter[-NoNewline`]` + `NewLine`），
    //    由下面的续行分支处置（调用方 `flushSegment()` 后整体吞掉）—— 那一族改前就是对的。
    return paramTokenWithNext(shape, next.charCodeAt(0))
      ? { raw: '`' + next, value: '`' + next, continuation: false }
      : { raw: '`', value: '`', continuation: false }
  }
  if (next === undefined) {
    if (inQuote) return null
    const prev = input[index - 1]
    if (prev === undefined || PWSH_TOKEN_BREAK.test(prev)) return null
    return { raw: '`', value: '`', continuation: false }
  }
  if (next === '\n') return { raw: '`\n', value: '\n', continuation: true }
  if (next === '\r') {
    // 词元**未完结**（`open`）PS 只把 `` ` ``+`\r` 当转义（字面 CR），`\r\n` 里的 `\n` **仍是**
    // 换行符（`NewLine` ⇒ 语句边界，实测 `stmts=2`）。故这里只吃 `` ` ``+`\r`、`value` 取
    // `'\r'`，把 `\n` 留给主循环的换行分支去切语句。
    // 其余上下文（词元边界 / 引号内）`` ` ``+`\r\n` 是**整体**续行，必须一起吃掉
    // ——只吃 `` ` ``+`\r` 会把 `\n` 留成下一轮的分段符，凭空多切一段。
    if (open) return { raw: '`\r', value: '\r', continuation: true }
    const raw = input[index + 2] === '\n' ? '`\r\n' : '`\r'
    return { raw, value: '\n', continuation: true }
  }
  const mapped = PWSH_ESCAPES[next]
  return { raw: '`' + next, value: mapped === undefined ? next : mapped, continuation: false }
}

/** 从 start（指向 open 字符）跳到配对的 close，返回 close 的下标；找不到返回 -1。 */
function skipBalanced(input, start, open, close) {
  let depth = 0
  for (let i = start; i < input.length; i += 1) {
    const c = input[i]
    if (c === '\\') { i += 1; continue }
    if (c === "'") {
      const e = input.indexOf("'", i + 1)
      if (e < 0) return -1
      i = e
      continue
    }
    if (c === '"') {
      let e = -1
      for (let j = i + 1; j < input.length; j += 1) {
        if (input[j] === '\\') { j += 1; continue }
        if (input[j] === '"') { e = j; break }
      }
      if (e < 0) return -1
      i = e
      continue
    }
    if (c === open) depth += 1
    else if (c === close) {
      depth -= 1
      if (depth === 0) return i
    }
  }
  return -1
}

/**
 * 删掉 bash 的**续行符**（`\` + 换行）—— 必须在**分词之前**做。
 *
 * 为什么必须在分词之前：bash 在词法阶段就删掉续行符，**早于**识别多字符操作符。于是
 * `>\<NL>&2` 在 bash 里就是 `>&2`（描述符复制，不需要目标），而本文件的词法器是边扫
 * 边匹配操作符的：它先看到 `>`、把 `REDIRECT_OPERATOR` 匹配成单字符 `>`，随后 `\`+换行
 * 被转义分支吃掉，再随后那个 `&` 落进 `&` 分支 → `ampNoTarget` 置位 → 整行 `ok:false`。
 *
 * 后果不是「少分一段」而是**整条命令的判定路径被换掉**：`ok:false` 路径的档位集合不含
 * `outside`、且只认 deny 例外 —— 用户显式配的 `outside=deny` 与全部 ask 例外在这条路径上
 * 整个失明（fail-open）。`rm -rf /tmp/pgx >\<NL>&2` 会由 deny 变 allow。
 *
 * ── 为什么不写成「无条件 `input.replace(/\\\n/g, '')`」───────────────────────────
 * bash 的续行符**不是**在任何位置都生效，本函数必须与 bash 的边界一致：
 *   · **注释内不生效** —— 注释在换行处结束，`\` 不延长它。无条件剥离会把两行粘成一条注释、
 *     把 `rm` 藏进注释里（`echo hi # c\` + NL + `rm -rf victim` 里 victim 真的被删）。
 *   · **单引号内不生效** —— 那里 `\` 是字面量。
 *   · **双引号内生效** —— `"a\<NL>b"` 输出 `ab`。
 * 故本函数做一次**轻量词法扫描**：单引号块 / 双引号块 / 注释块原样搬运，只删块外的续行符。
 * 扫描只认「块」，不解析命令 —— 与 `decomposeCommand` 本体保持同一粒度。
 *
 * ── ⚠️ 唯一一处**不删**的续行符：夹在两个 `<` 之间的那一个 ─────────────────────────
 * bash 的词法真值确实是 `<\<NL><` ≡ `<<`（heredoc 操作符），但本文件的词法器认出 heredoc
 * 就整行 `ok:false`，而 `ok:false` 路径的档位集合不含 `outside`、且只认 deny 例外 ⇒
 * 用户显式配的 `outside=deny` 在这条路径上整个失明（fail-open）。故这里取「与 HEAD 相同」：
 * 不删这个续行符，词法器的转义分支会原样跳掉 `\`+换行、把两个 `<` 当独立重定向。
 * 判据只排除两侧都是 `<` 的那一种：其余形态（`>\<NL>&` / `>\<NL>>` / `<\<NL>&` …）的
 * 剥离是本函数存在的理由，一格都不能退。
 *
 * ⚠️ 方向：本函数只删字符、不新增任何段边界；它把「被劈开的操作符」拼回去，而拼回去的形态
 * 在 bash 里本来就合法（`bash -n` = OK）。故只会让判定从「读不懂」回到「读得懂」。
 *
 * @param {string} src 原始命令行
 * @param {'bash'|'pwsh'} sh 方言（pwsh 的续行是反引号，由词法器自身处理，本函数不介入）
 * @returns {string} 已删掉续行符的命令行
 */
function stripLineContinuations(src, sh) {
  // pwsh 的续行不是 `\`；没有续行符时原样返回（**零分配**，判定热路径）
  if (sh !== 'bash' || src.indexOf('\\\n') < 0) return src
  const isWordBreak = (c) => c === ' ' || c === '\t' || c === '\n' || c === '\r'
    || c === ';' || c === '|' || c === '&' || c === '(' || c === ')' || c === '<' || c === '>'
  const out = []
  // `#` 只在**词首**才是注释（与词法器的 `char === '#' && !started` 同判据）。
  // 误判方向的取舍：把「其实不是注释」的位置当成注释 ⇒ **少删** ⇒ 退回改动前的行为
  // （不放宽）；反过来才会把命令藏进注释。故词界判定宁可**偏宽**。
  let wordStart = true
  for (let i = 0; i < src.length; i += 1) {
    const c = src[i]
    // ── 单引号块：原样搬运（`\` 在里面是字面量，**不删**）──
    if (c === "'") {
      out.push(c)
      for (i += 1; i < src.length; i += 1) { out.push(src[i]); if (src[i] === "'") break }
      wordStart = false
      continue
    }
    // ── 双引号块：`\`+换行 **要删**（bash 在双引号内照样续行），其余 `\x` 原样 ──
    if (c === '"') {
      out.push(c)
      for (i += 1; i < src.length; i += 1) {
        const d = src[i]
        if (d === '\\') {
          if (src[i + 1] === '\n') { i += 1; continue }
          out.push(d)
          if (i + 1 < src.length) { i += 1; out.push(src[i]) }
          continue
        }
        out.push(d)
        if (d === '"') break
      }
      wordStart = false
      continue
    }
    // ── 注释块：到换行为止原样搬运（`\` **不延长**注释，见函数头实测）──
    if (c === '#' && wordStart) {
      for (; i < src.length; i += 1) { out.push(src[i]); if (src[i] === '\n') break }
      wordStart = true
      continue
    }
    // ── 续行符：删掉（本函数存在的理由）──
    //
    // ⚠️ **例外**：夹在两个 `<` 之间的续行符**不删** —— 删了会把它粘成 heredoc 操作符 `<<`，
    // 而词法器认出 heredoc 就整行 `ok:false`，于是丢掉 `outside` 档与全部 ask 例外
    // （fail-open，详见函数头「唯一一处不删的续行符」）。判据只看**紧邻的两个字符**：
    // 本分支一次只删一个 `\`+换行，故「粘成 `<<`」当且仅当 `\` 的前一个字符与换行之后的
    // 那个字符**都是** `<`。其余形态（`>\<NL>&` / `>\<NL>>` / `<\<NL>&` / `>\<NL>|` …）
    // 照旧剥离 —— 那正是本函数存在的理由，一格都不退。
    //
    // 不删时**落到下面的转义分支**：它把 `\`+换行 原样搬进结果，于是词法器看到的就是
    // HEAD 看到的那串文本（HEAD 的转义分支同样只跳过这两个字符），逐格回到 HEAD 的行为。
    const splitHeredoc = c === '\\' && src[i + 1] === '\n'
      && out[out.length - 1] === '<' && src[i + 2] === '<'
    if (c === '\\' && src[i + 1] === '\n' && !splitHeredoc) { i += 1; continue }
    out.push(c)
    // 转义字符：连同被转义的那一个一起搬运，且它不构成词界
    if (c === '\\' && i + 1 < src.length) { i += 1; out.push(src[i]); wordStart = false; continue }
    wordStart = isWordBreak(c)
  }
  return out.join('')
}


/**
 * 把一个命令行分解为段、重定向与词元元数据。
 *
 * 与旧实现的根本区别：操作符必须【在引号外】才生效，且解析不了的构造一律标 opaque，
 * 由调用方失败关闭 —— 绝不猜测 shell 语义。
 *
 * 段的边界由 `;` `|` `||` `&&` `&` 与换行决定（换行也是分隔符：pwsh -Command 与 bash -c
 * 都接受多行脚本，实测 `git status\nrm -rf ~/.dsh` 当前被静默放行）。
 * 重定向（`>` `>>` `<` `2>` `2>&1` `&>`）记入 writeTargets/readTargets，**不作为段**。
 *
 * 段级 opaque 用于「这一段里有读不懂的构造，但段边界仍可确定」：
 * `$(...)`、反引号、heredoc、括号/花括号分组、`env -S`。
 * 整行 ok:false 用于「连段边界都定不了」：未闭合引号、重定向无目标、空命令、悬空操作符。
 *
 * @param {string} source 命令原文
 * @param {'pwsh'|'bash'} shell 决定转义、注释与变量规则
 * @returns {{ ok: true, segments: object[] } | { ok: false, reason: string }}
 */
export function decomposeCommand(source, shell) {
  const sh = shell === 'pwsh' ? 'pwsh' : 'bash'
  // 续行符必须在**分词之前**删掉（发现 3 的修法，理由与边界见 `stripLineContinuations`）。
  // ⚠️ `assessCommand` 的整行 `ok:false` 分支仍用**原始 source** 粗提命令名（那里不做本
  // 替换），故「读不懂」路径的 deny 例外匹配面不受本行影响。
  const input = stripLineContinuations(String(source == null ? '' : source), sh)
  const segments = []
  let words = []
  let writeTargets = []
  let readTargets = []
  let segText = ''
  let wordText = ''
  // 词元形态**影子**：`wordText` 的 O(1) 派生状态，供 `pwshEscapeBoundaryAt` /
  // `readPwshEscape` 判词元形态（**不得**直接读 `wordText` —— rope 扁平化致 O(n²)，
  // 见 `newWordShape` 那段说明）。⚠️ 必须与 `wordText` **严格同步**：
  // 追加只走 `addWord()`、复位只走 `resetWord()`（本函数内两个唯一入口）。
  const wordShape = newWordShape()
  let started = false
  let dynamic = false
  // 「当前词元的**首个**字符是不是 typed 构造（引号串 / 变量展开 / `$( )` / `( )` / `{ }`）」
  // —— 只供反引号续行守卫判「前一个词元是否已完结的完整词元」用（见 `PWSH_ACCESSOR_TAIL`）。
  //
  // 为什么必须有它，而不能只看词元尾部：`$x.Name` 与 `a.b` 的尾部**同形**（都命中
  // `PWSH_ACCESSOR_TAIL`），但官方解析器实测前者是 `LineContinuation`（切开）、后者是
  // **一个** `Generic` 词元（粘住）—— 唯一差别就是首个字符。少这一维会多切 `a.b` / `x$y.y`
  // 族（新误报），少 `PWSH_ACCESSOR_TAIL` 那一维会漏掉 `$x.Name` 族（fail-open）。
  //
  // 置位点：各 typed 入口在**词元首**（`!started`）时置位 —— `x$y.y` 的 `$y` 不在词元首，
  // 故不置位（与 PS 实测一致）。复位点：`flushWord()`（**含 `!started` 的早退路径** ——
  // `(Get-Item x) .Name` 里 opaque 构造不设 `started`，只在早退里复位才能挡住泄漏）。
  let tokenTyped = false
  // 最近一个**分组块**（`( … )` / `{ … }`，含 `@( )` / `@{ }` 前缀形）的**收尾符在 `input` 里的
  // 下标**；没有分组块时为 -1。只供反引号续行守卫判「反引号是不是紧贴着一个已完结的分组块」。
  //
  // ⚠️ 为什么必须是**位置**，而不是「词元尾部是不是 `)` / `}`」：分组块只写 `segText`、
  //    **不写 `wordText`**（见分组分支），于是 `wordText` 里只剩词元首的前缀（`@` / `a` /
  //    `Get-Item`），两个尾部判据**都看不到它** —— 这一族因此回退成「粘住」。实测前缀形
  //    `@(x)` / `a(x)` / `@{a=1}`：`words` 由 `['Remove-Item','-Recurse','-Force','@','C:/Windows']`
  //    变成 `['Remove-Item','-Recurse','-Force','@C:/Windows']`（`blast` 由 `system` 掉成
  //    `unknown` ⇒ 破坏性子设置与 deny 例外双双失明）。
  //    而**裸判 `segText` 尾部是不是 `)` / `}` 会误伤**：`${x}` / `${a}${b}` 的尾部同样是 `}`，
  //    但官方解析器实测它们是**一个** `Generic` 词元（粘住，见下方 B 族）。位置判据天然区分
  //    两者 —— `${…}` 走变量分支，**从不**写本变量。
  //    也不需要任何复位点：它是 `input` 的绝对下标，`index` 一前进等式自然不成立
  //    （`(x)y` / `@(x)z` / `(x)${y}` 三个粘住族即由此自动排除）。
  let lastGroupClose = -1
  let segDynamic = false
  let segOpaque = null
  // opaque 构造的**原文**（`$( … )` / 反引号 / `( … )` / `{ … }` 整块，含定界符），按出现次序。
  //
  // 存在的理由（发现 1 的修法）：判定侧要问「**opaque 构造自己有没有藏一个破坏性命令**」，
  // 而 `seg.words` 只包含构造**之外**的可读词元 —— 构造里那个命令名在词元列表里根本不存在。
  // 词法器是**唯一**知道「哪一段文本被判成了 opaque」的地方，故由它把原文记下来交给判定侧：
  // 判定侧再拿别的东西（`seg.text` 前缀切片之类）去反推，就是同一份知识写两遍，
  // 而本文件反复记录的那类缺陷正是「两处各写一份判据必然漂移」。
  //
  // ⚠️ 与 `segOpaque`（只记**第一个**原因）不同，这里是**全部**构造：一段里可以出现多个
  // （`rm -rf ./x $(a) $(rm -rf /)`），漏记任何一个都可能漏掉真正的载荷。
  let segOpaqueTexts = []
  // 段原文里**第一个「命令词位」opaque 构造**的起始下标；没有时为 -1。
  //
  // 存在的理由（见 `SEG_OPAQUE_AT` 的说明）：`bashLeftIsAssign` 要问「`NAME=` 命中处
  // **之前**是不是已经有 opaque 构造占掉了命令词位」—— 那是**位置**信息，只有词法器知道。
  //
  // ⚠️ 「命令词位」的判据是 `pending === undefined`（没有等着目标的重定向）。
  //    这一条**不可放宽成「段里任何 opaque 构造」**：
  //    `> $(true) A=1` 里 `$(true)` 是**重定向目标**，该行在 bash 下仍是**真赋值**
  //    （Git Bash 5.3.15 实测：`A` 被设为 `1`、无 RAN，只有 `ambiguous redirect` 警告），
  //    按「任何位置」记会把这一族**真赋值**误判成真命令（引入新过收）。
  //    ⚠️ 判据**不能**再加 `!started`（本轮订正：原措辞与 `noteOpaqueHead` 处的说明
  //    互相矛盾，且**按原措辞改会把真命令判成赋值**）：引号分支（`'` / `"`）在读到
  //    引号时就置 `started = true`，而引号里的 opaque 构造仍属**命令词位** ——
  //    加上 `!started` 会让 `"$(sh -c 'rm -rf /tmp/zzz')"2> out A=/bin/rm` 的 label
  //    由 `"rm"` 掉成 `""` ⇒ 段级 `unparsable` ⇒ `destructive=false` ⇒ 破坏性子设置
  //    与全部例外失配 ⇒ 落大分类（fail-open；`test/shell-parse.mjs` 的 AL 组会红）。
  //    判据与 `noteOpaqueHead` 处**同口径**：只有 `pending === undefined`。
  let segOpaqueHeadAt = -1
  // 段原文里**第一个「占过重定向目标位」的 opaque 构造**的起始下标（候选）；没有时为 -1。
  // 与上面那个的差别是**粘性**（不在遇到新重定向时复位）—— 见 `SEG_OPAQUE_TARGET` 的说明。
  let segOpaqueTargetCand = -1
  // 上面那个候选**定案**后的值（-1 = 未定案 / 不成立）。
  // 定案判据：opaque 占住目标位之后产出的**第一个真词元不是赋值词** —— 只有那时它才真的
  // 顶掉了命令词位。反例（Git Bash 5.3.15 实测真值 **ASSIGN**，`A`/`B` 都被设上、无 RAN）：
  //     `> $(mktemp) A=/bin/rm B=/bin/rm`  → 被吞的是 `A=/bin/rm`，是**赋值词** ⇒ 不顶掉
  //     `> $(mktemp) A=1 B=2`              → 同上
  // 若不看这一点（纯「占过目标位」即定案），这一族会被误判成真命令（新过收，实测 32 格）。
  let segOpaqueTargetAt = -1
  // 本词元是「紧跟在一个占住目标位的 opaque 构造之后」产出的第一个真词元 ⇒ 它的赋值性
  // 决定上面那个候选能不能定案。由 `noteOpaqueTarget` 置位、`flushWord` 消费并复位。
  let opaqueTargetSwallow = false
  // 「本段有 opaque 构造**占着重定向目标位、且该构造是嵌套解释器带内联程序**」——
  // 段级、**不参与定案**、不受「新重定向作废未定案候选」那处影响（见 `SEG_OPAQUE_PAYLOAD` 的说明）。
  let segOpaquePayloadInline = false
  let pending
  let nextOp = 'start'
  // 「最后那个 `&` 前面**有内容**吗」—— 供行尾悬空检查区分「合法的异步列表收尾」与
  // 「真悬空」。**只在 `&` 分支写入**，而 `nextOp = '&'` 也只在那个分支出现，
  // 故 `nextOp === '&'` 时本标记必然描述的是**最后那个** `&`（两者严格配对，不会串台）。
  // 见行尾检查处的说明：`echo a &` 合法而 `echo a & &` / `echo a | &` 不是。
  let ampAfterContent = false
  // 「最后那个 `&` **前面**有一个等着目标的重定向」—— `echo a > & (b)` / `> & $(b)` /
  // `> & { b; }` / `> & )` / `echo a > & b` 在 bash 里都是
  // `syntax error near unexpected token '&'`（`&` 不是 `>` 的目标）。
  //
  // ⚠️ **不能复用 `ampNoTarget`**：那个是**局部 const**、只在 `&` 分支里
  // 活着，而 `&` 分支的 `flushSegment()` 会把 `pending` 复位 —— 行尾那条保留的词元级判据
  // `pending !== undefined && !started`（约 `:3987`）于是看不到 `&` **之前**的那个 `>`。
  // 且 `ampNoTarget` 只写进 `ampOk`，而 `ampOk` 仅在「段无内容」时才决定是否报错：
  // `&` 后面还有内容时 `segHasContent` 为真 → 短路 → 整行照旧 `ok:true`。
  //
  // 故另立一个**跨段存活**的标记：`nextOp = '&'` 只在 `&` 分支出现，而本标记在该分支内
  // 按「**有任何一个** `&` 满足条件」置位（粘性，见该分支内的说明）—— 故它描述的是
  // 「行内存在一个前面挂着无目标重定向的 `&`」，不限于最后那个。
  // 在 `flushSegment()` **之前**取值（它会把 `pending` / `started` 复位）。
  //
  // 实测（修复前 → 修复后，`echo a > & b` 同形）：
  //     echo a > & (b) / > & $(b) / > & { b; } / > & )   ok:true → **ok:false**
  // 而合法形态**不得误伤**（三格的 `ampNoTarget` 均为 false，故本标记为 false）：
  //     echo a > b & / echo a 2>&1 & / echo a > $f &   → 照旧 ok:true
  let ampTargetMissing = false
  // 「当前这个等着目标的重定向，它的目标是不是一个 **opaque 构造**」—— `'none'` / `'word'`
  // / `'not-word'` 三态，供 `&` 分支的 `ampNoTarget` 排除**误判**（见那里的完整论证）。
  //
  // ── 为什么必须是**逐重定向**的标记，而不是「本段出现过 opaque 构造」（`segOpaque`）──
  // 后者**过宽**：`echo a $(b) > & c` 的 `$(b)` 是**命令参数**、与后面的 `>` 毫无关系，
  // 而该形态在 bash 里仍是 `syntax error`（`bash -n` 实测）。按 `segOpaque` 口径会把它
  // 一并放行 —— 那是**新开的 fail-open**（实测：`echo a $(b) > & c` / `echo a {b} > & c` /
  // `echo a "x$(y)" > & c` / `echo a \`b\` > & c` / `echo $(a) > & b` 五格由 ok:false 变
  // ok:true，`outside=deny` 下同一批命令由 deny 变 allow）。故本标记只在
  // 「**opaque 构造紧跟在待读重定向之后**」时置位，`echo a > $(b) > & c` 里第二个 `>`
  // 会把它复位（那个 `>` 确实没有目标，仍是语法错误）。
  //
  // 三态而非布尔：同一重定向后可能跟**多个** opaque 构造（`echo a > (c) $(b) & d`），
  // bash 只在「全部可作字面词」时才合法，故只要**出现过一个**不可作词的构造，
  // 结论就锁定为 `'not-word'`（`word` 只在仍是 `'none'` 时写入）。
  let redirectOpaqueTarget = 'none'
  let quote
  // 段文本末尾是否已是空格。**不能用 segText.endsWith(' ')**：`segText += s` 在 V8 里
  // 只建 rope（O(1)），而 endsWith / 下标读取都必须先把 rope 扁平化成连续串（O(n) 拷贝），
  // 于是每遇到一个引号外空白就触发一次全长拷贝，整个分解退化为 O(n²)。
  // 实测真实命令形态：`git add` 带 20000 个文件参数（399 KB）→ 1049 ms（改标记后 ~20 ms）。
  // 这是每次工具调用都要跑的判定热路径，词元数由 AI 生成的命令决定，不是理论问题。
  let segEndsWithSpace = true
  // 段文本**末字符是不是引号**（`"` / `'`）—— 语义等价于 `PWSH_QUOTED_TAIL.test(segText)`。
  // 与上面 `segEndsWithSpace` **同一个理由、同一个手法**（那是第一处，这是第二处）：
  // 直接读 `segText` 会触发 rope 扁平化，而本标记在反引号续行守卫里被**每个「反引号+换行」**
  // 读到一次 —— 实测 `'New-Item -Path $base' + ('`\n  -Name $n<i>')*N`（N=8k/16k/32k）
  // 由 20.2/365.1/1749.6 ms 降到 6.0/4.8/10.9 ms。
  //
  // 三个写入点，与 `segText` 严格同步（漏一个就会与正则判据分叉）：
  //   · `pushText`  —— 段文本唯一的追加口，取 `s` 的**末字符**（空串时保持原值：`segText`
  //     不变，末字符自然也不变）；
  //   · `pushSpace` —— 追加的是空格，**必须复位**（否则 `"abc" -Force ` 这种尾随空白会
  //     让标记停在 `true`，而 `segText` 的末字符已是空格 ⇒ 分叉）；
  //   · `flushSegment` —— 与 `segText = ''` 同步复位。
  // 初值与 `segEndsWithSpace` 同理：空段「末字符是引号」为假。
  let segLastIsQuote = false

  const pushText = (s) => {
    segText += s
    segEndsWithSpace = false
    // 末字符是不是引号 —— 判据原文即 `PWSH_QUOTED_TAIL`，此处只把它跑在刚追加的 `s` 上
    // （与跑在 `segText` 上恒同值，但不触发 rope 扁平化，见该常量的说明）。
    if (s) segLastIsQuote = PWSH_QUOTED_TAIL.test(s)
  }

  // `wordText` 的**唯一两个写入口**（影子与它严格同步，见 `wordShape` 的说明）。
  //
  // ⚠️ 不要绕过它们直接 `wordText += …` / `wordText = ''`：影子会与词元分叉，而
  //    `pwshEscapeBoundaryAt` 直接读影子 ⇒ 判据错。逐字符入口的调用方传的是
  //    **单个 UTF-16 码元**（`next` / `char` / `esc.value` 都是单字符），多字符块
  //    （`raw` / `expansion`）由 `addWord` 自己拆 —— 拆分只发生在**追加点**，
  //    故不需要在别处再拆一次。
  const addWord = (s) => {
    wordText += s
    for (let i = 0; i < s.length; i += 1) pushWordShape(wordShape, s.charCodeAt(i))
  }
  const resetWord = () => {
    wordText = ''
    resetWordShape(wordShape)
  }
  // 引号外的空白归一化为单个空格：例外匹配用的是段全文，`git  status`（双空格）
  // 不该因为排版差异匹配不上用户写的 `git status`。引号内的空白原样保留。
  const pushSpace = () => {
    if (segText && !segEndsWithSpace) {
      segText += ' '
      segEndsWithSpace = true
      segLastIsQuote = false   // 追加的是空格 ⇒ 段末字符不再是引号（见 `segLastIsQuote`）
    }
  }

  const flushWord = () => {
    // ⚠️ 复位必须在 `!started` 的**早退之前**：`(Get-Item x) .Name` 的 opaque 构造不设
    // `started`，若只在正常路径复位，`tokenTyped` 会跨过空白泄漏到下一个词元上。
    if (!started) { tokenTyped = false; return }
    const w = wordText
    // ── opaque 占目标位的**定案**────────────────────────────────
    // opaque 构造**不产出词元**，故「占住重定向目标位」之后产出的**第一个真词元**就是
    // 它顶掉的那个位置上的词。只有该词**不是赋值词**时，命令词位才真的被它顶掉。
    // 反例（Git Bash 5.3.15 实测真值 **ASSIGN**，`A`/`B` 都被设上、无 RAN、rc=0）：
    //     `> $(mktemp) A=/bin/rm B=/bin/rm` → 被吞的是赋值词 ⇒ 命令词位**没有**被顶掉
    // 正例（同法实测真值 **COMMAND**，RAN[rm]）：
    //     `> $(mktemp) rm A=/bin/rm`         → 被吞的是命令词 ⇒ 顶掉了命令词位
    // ⚠️ 判据复用模块级 `LEAD_ASSIGN` **单点**（与 `bashLeftIsAssign` 的入口同源），
    //    不在这里另写一份「什么算赋值词」。
    if (opaqueTargetSwallow) {
      opaqueTargetSwallow = false
      if (segOpaqueTargetAt < 0 && !LEAD_ASSIGN.test(String(w))) segOpaqueTargetAt = segOpaqueTargetCand
    }
    if (pending === 'write') writeTargets.push(w)
    else if (pending === 'read') readTargets.push(w)
    else words.push(w)
    pending = undefined
    resetWord()
    started = false
    dynamic = false
    tokenTyped = false
  }

  // 「本段到目前为止有没有内容」—— **单一实现**，两个调用方问的是同一个问题：
  //   · flushSegment      —— 本段值不值得产出一个段；
  //   · 行尾悬空操作符检查 —— 上一个操作符后面到底有没有东西（段边界可不可信）。
  //
  // 曾经两处各写一份：flushSegment 写全了，行尾检查只写 `started` —— 于是同一个概念
  // 有两个修改点，而其中一份是错的。
  //
  // ⚠️ `started` 必须在里面，且不能反过来只写它：
  //   · 不能去掉 —— 行尾 `echo a | cat` 结束时 `cat` 还在 wordText 里没进 words，
  //     只看数组会把这条合法命令判成悬空操作符；
  //   · 不能只有它 —— `started` 是**词元级**状态，遇到引号外空白就被 flushWord 复位，
  //     而分组块 / 命令替换这类构造**产不出词元**（它们被标记 opaque），于是
  //     `Get-Content x | ForEach-Object { $_ }` 的行尾被判成「| 后面什么都没有」，
  //     整行 ok:false → 段边界全部丢失 → **弹窗没有分段**，且 allow/ask 例外一律不认
  //     （ok:false 路径只认 deny 例外），「默认放行 + 个别命令要求确认」这个配置下
  //     末尾挂一个括号就等于把那条确认规则抹掉（fail-open）。
  //
  // 保留条件含 segOpaque：`(git status)` 这类分组段有文本但提取不出词元，
  // 它必须成为一个「读不懂的段」（code: unparsable）而不是被静默丢弃 ——
  // 丢弃会让整行变成 ok:false，虽然同样落分类默认值，但段级展示与 code 就没了。
  // 但**不**按 segText 保留：`printf x >\n~/.ssh/keys` 的换行处文本是 `printf x >`，
  // 按文本保留会凭空多出一个「只有重定向操作符」的段。
  const segHasContent = () => started || words.length > 0 || writeTargets.length > 0 || readTargets.length > 0 || segOpaque !== null

  // 返回值 = 「本段有没有内容」（与 `segHasContent` 同判据，供 `&` 分支在复位**之前**取用）：
  // `&` 的合法性取决于它**前面**有没有内容，而本函数会把状态全部复位，故只能由它带回。
  const flushSegment = () => {
    flushWord()
    const text = segText.trim()
    const hasContent = segHasContent()
    if (hasContent) {
      // ── 方言戳：词法器是**唯一确知方言**的地方，故由它把方言记在词元数组上 ──────────
      // 消费侧（`index.js` 的候选生成 / 破坏性判定 / 例外标注）只拿得到 `seg.words`，
      // 而赋值守卫**必须带方言维度**（见 `LABEL_ASSIGN` 的说明）—— 在这里戳一次，
      // 那三条路径原样把数组传回 `segmentLabel` / `isDestructiveSegment` /
      // `canCarryDestructivePayload` 即可拿到正确的方言，**零接口变更**。
      // Symbol 键对 `Object.keys` / `JSON.stringify` / 展开 / `for…in` 全部不可见，
      // 故 `seg.words` 对既有消费方逐字不变（见 `SEG_SHELL` 的说明）。
      words[SEG_SHELL] = sh
      // 原文戳（见 `SEG_TEXT` 的说明）：pwsh 侧 `$NAME=右侧` 的引号只在原文里，
      // 词法器是唯一持有它的地方。与 `SEG_SHELL` 同一处戳、同一份可见性纪律。
      words[SEG_TEXT] = text
      // opaque 起点戳（见 `SEG_OPAQUE_AT` 的说明）：`bashLeftIsAssign` 要问「命中处**之前**
      // 有没有 opaque 构造」，而这是**位置**信息 —— 只有词法器知道，故在这里戳一次。
      // 无构造时**不戳**（保持缺席，消费侧 `undefined` 即「没有」）。
      if (segOpaqueHeadAt >= 0) words[SEG_OPAQUE_AT] = segOpaqueHeadAt
      // opaque 占重定向目标位的粘性戳（见 `SEG_OPAQUE_TARGET` 的说明）：与上一条同一处戳、
      // 同一份可见性纪律；无构造时**不戳**（保持缺席，消费侧 `undefined` 即「没有」）。
      if (segOpaqueTargetAt >= 0) words[SEG_OPAQUE_TARGET] = segOpaqueTargetAt
      // opaque 占目标位**且带内联程序**的戳（见 `SEG_OPAQUE_PAYLOAD` 的说明）：
      // 与上一条同一处戳、同一份可见性纪律；未命中时**不戳**。
      if (segOpaquePayloadInline) words[SEG_OPAQUE_PAYLOAD] = 1
      segments.push({
        op: nextOp,
        text,
        words,
        writeTargets,
        readTargets,
        dynamic: segDynamic,
        opaque: segOpaque,
        opaqueTexts: segOpaqueTexts,
      })
    }
    words = []
    writeTargets = []
    readTargets = []
    segText = ''
    // 与 segText 同步重置：新段还没有任何内容，pushSpace 的「已有内容才补空格」判据靠它
    segEndsWithSpace = true
    // 同上：新段的末字符不是引号（与 `segLastIsQuote` 的初值一致）
    segLastIsQuote = false
    segDynamic = false
    segOpaque = null
    segOpaqueTexts = []
    segOpaqueHeadAt = -1
    segOpaqueTargetCand = -1
    segOpaqueTargetAt = -1
    opaqueTargetSwallow = false
    segOpaquePayloadInline = false
    pending = undefined
    nextOp = 'start'
    return hasContent
  }

  const markOpaque = (reason) => { if (segOpaque === null) segOpaque = reason }
  // 记下**命令词位**的第一个 opaque 构造在段原文里的起始下标（见 `SEG_OPAQUE_AT` 的说明）。
  //
  // ⚠️ 判据**只有** `pending === undefined`（此刻没有等着目标的重定向），**不能**再要求
  //    `!started`：引号分支（`'` / `"`）在读到引号时就置 `started = true`，而引号里的
  //    opaque 构造仍属**命令词位**。加上 `!started` 会让 `"$(true)" > out X=/bin/rm`
  //    漏记（实测真值 COMMAND：`X` 仍 unset），而该形态正是本缺陷的同族。
  //    `pending` 由 `flushWord` 在消费掉重定向目标后复位，故 `> "$(true)" X=…` 里
  //    `$(true)` 仍在目标位上（`pending === 'write'`）⇒ 不记 ⇒ 保持判赋值（真值 ASSIGN）。
  // 只记**第一个**：`bashLeftIsAssign` 问的是「命中处之前有没有」，多记无益。
  const noteOpaqueHead = () => {
    if (segOpaqueHeadAt < 0 && pending === undefined) segOpaqueHeadAt = segText.length
  }
  // 记下 opaque 构造的原文（见 `segOpaqueTexts` 的说明）。与 `markOpaque` **分开**：
  // 前者只认第一个原因（段级语义），本函数每个构造都要记（判定侧要逐块查载荷）。
  //
  // ── 顺带判「占目标位的构造是不是嵌套解释器带内联程序」────────────────────────
  // ⚠️ 守卫**只**要 `pending !== undefined`（此刻有等着目标的重定向），不能再要求
  //    `!started` —— 引号分支（`'` / `"`）在读到引号时就置 `started = true`，而引号里的
  //    opaque 构造仍占着**重定向目标位**。加上 `!started` 会让下面这一族永远进不了判据：
  //      `> "$(sh -c "…")" > out A=/bin/rm`（`$()` 落在引号内、仍在目标位上）
  //    该形态载荷真的执行、`A` 仍 unset ⇒ 真命令，而加 `!started` 时判 allow（fail-open）。
  // ⚠️ 本判据**不复用 `noteOpaqueTarget`**：它要的只是「此刻构造在目标位上」这个瞬时事实，
  //    而 `noteOpaqueTarget` 会顺带置位 `segOpaqueTargetCand` / `opaqueTargetSwallow`
  //    （那是 `SEG_OPAQUE_TARGET` 的候选机制）—— 反引号构造**产出词元**，不是「吞掉词元」
  //    那一族，套用会让 `> \`true\` > out A=/bin/rm`（真值 ASSIGN）被定案成真命令（新过收）。
  // ⚠️ 必须在本函数里判、不能挪到 `flushWord` 的定案处：`opaqueTargetSwallow` 此刻仍为 true，
  //    而「新重定向作废未定案候选」那处会在此之后把它置 false —— 构造后紧跟 `>` 时定案分支
  //    根本不会执行。见 `SEG_OPAQUE_PAYLOAD` 的说明（那里有时序推演）。
  // ⚠️ 判据复用 `nestedInlineProgram` **单点**，且**入参构造与既有调用点同源** ——
  //    既有调用点（`assessCommand` 与 index.js 候选守卫）拿到的 `label` 与 `words` 是
  //    **词法器产出 + 已剥引号 + 已归一化**的形态：
  //      · **切分**必须走 `splitQuotedTokens`（引号感知），不能 `split(/\s+/)`：
  //        朴素切分不剥引号 ⇒ 当标志词元自身被引号包裹时（`sh "-c" x` / `"sh" -c x`）
  //        `INLINE_PROGRAM_FLAG` 不命中。
  //      · **首词**必须归一化（剥路径/后缀 + 小写），承重的是 `headCommandNameOf`
  //        （穿过 wrapper / 提权前缀取真命令头）：`/bin/sh` / `env sh` / `nohup sh` 由它处理正确。
  //      · **兜底 `|| commandNameOf(rawHead)`** 是防御性对齐，不是必要项（主路径为空 ⇒ 兜底必空）；
  //        保留它是因为删的收益是 0、留的风险不是 0。
  //      · `rawHead` 的**剥外层引号正则**同样保留：方向正确（把 `"sh"` 归一成 `sh`）。
  //      · **必须遍历 `segs` 的全部分段**：既有的 opaque 载荷机制（`rawCommandNames`）扫的就是
  //        所有分片，只取 `segs[0]` 会让 `> $(true; sh -c "…") > out A=/bin/rm` 这一族漏判
  //        （真值 COMMAND、载荷真执行，而 HEAD 给 deny ⇒ 真 fail-open）。
  //      ⚠️ **已知边界（如实记录，勿为它加判据）**：遍历分段后仍有两族认不出 ——
  //        ① **首词认不出解释器**：管道 `… | sh`（第二段只有 `["sh"]`、`nestedInlineProgram`
  //           为 false，`-c` 缺席）、变量头 `$SHELL -c` / `${SHELL} -c`（取到的是变量名）。
  //        ② **短路族会过收**：`$(true || sh -c …)` / `$(false && sh -c …)` 真值 ASSIGN 却判 deny
  //           —— 但 HEAD 也是 deny ⇒ 恢复的是既有行为，方向 fail-closed。
  //           ⚠️ **不要试图按连接符区分**：`splitQuotedTokens` 丢掉了连接符信息，而
  //           `cd /tmp && sh -c …` 这类 `&&` 形态真值是 COMMAND ⇒ 一刀切会把它一起漏掉。
  //      ⚠️ **不改 `nestedInlineProgram` 的语义**（承重函数：`assessCommand` 的 `unparsable`
  //        与 index.js 候选守卫都在用）—— 只在调用处归一化入参。
  const noteOpaqueText = (raw) => {
    if (!raw) return
    const s = String(raw)
    segOpaqueTexts.push(s)
    if (!segOpaquePayloadInline && pending !== undefined) {
      const inner = stripOpaqueDelimiters(s)
      if (inner) {
        for (const parts of splitQuotedTokens(inner)) {
          if (parts.length === 0) continue
          const rawHead = String(parts[0]).replace(/^["']|["']$/g, '')
          const head = headCommandNameOf(parts) || commandNameOf(rawHead)
          if (head && nestedInlineProgram(head, parts)) { segOpaquePayloadInline = true; break }
        }
      }
    }
  }

  // ── opaque 构造是否可以充当**当前待读重定向的目标**（bash 语法真值，`bash -n` 实测）──
  // 判据只在「本段正等着一个重定向目标、且还没产出任何词元」时才有意义 ——
  // 其余情形下这个构造与重定向无关，不得影响 `redirectOpaqueTarget`。
  //
  //   · `$( )` / 反引号 / 双引号内的 `$( )` → **可作词**（`echo a > $(mktemp) & echo done` OK）
  //   · `( )` 子 shell                → **不可作词**（`echo a > (mktemp) & echo done` SYNTAX-ERR）
  //   · `{ }` 花括号组                → 看内容，见 `braceIsCommandGroup`
  //   · 孤立 `}`                      → 可作词（`echo a > } & echo done` OK，是字面词）
  //   · 孤立 `)`                      → **不可作词**（`echo a > ) & echo done` SYNTAX-ERR）
  //
  // 为何 `(` 与 `)` 不同：bash 里 `)` 只可能是**闭合**一个 `(`；既然 `(` 形态非法，
  // 孤立的 `)` 同样非法。而 `{` / `}` 在 bash 里是**保留字**，只有「作为独立词」时才是
  // 分组定界符 —— `}` 单独出现只是一个普通词（实测合法），故两者也不对称。
  //
  // ⚠️ 本函数**只**在 `pending !== undefined && !started` 时写入：`started` 为真意味着
  // 重定向目标已经产出（或该构造是命令参数），与「无目标」无关，不得参与。
  //
  // ── 顺带记下**粘性**位置戳 `segOpaqueTargetAt`────────────────
  // 判据与 `redirectOpaqueTarget` 完全同源（同一次调用、同一个守卫），故在同一处写，
  // 不另开一份「什么算占了目标位」的判据（本文件反复记录的那类缺陷正是两处各写一份）。
  // 与那个三态的**唯一差别**是**粘性**：三态会在遇到新重定向时被复位（`>` 分支），
  // 而本标记一旦**定案**就保留到段尾 —— 见 `SEG_OPAQUE_TARGET` 的说明（复位式只修好
  // 57/169，粘性修好 169/169）。
  //
  // ⚠️ 这里记的是**候选**，不是定案：本函数只确知「opaque 占住了重定向目标位」，
  //    而「**命令词位**是否因此被占据」还要看 opaque **之后第一个真词元**是不是赋值词 ——
  //    该词元要到 `flushWord` 才产出，故定案在那边做（见 `flushWord` 里的说明）。
  const noteOpaqueTarget = (isWord) => {
    if (pending === undefined || started) return
    if (!isWord) redirectOpaqueTarget = 'not-word'
    else if (redirectOpaqueTarget === 'none') redirectOpaqueTarget = 'word'
    // 只记**第一个**（与 `noteOpaqueHead` 同一纪律）：粘性标记只需回答「**有没有**」，
    // 与下标无关（见 `SEG_OPAQUE_TARGET` 的说明 —— 本戳的**读侧不做位置比较**）。
    // ⚠️ 这句曾经写成「判定侧问的是『命中处**之前**有没有』」—— 那是从 `noteOpaqueHead`
    //    抄过来的，而**只对那个戳成立**：`SEG_OPAQUE_AT` 的读侧确实带 `< at`
    //    （`bashLeftIsAssign` 里那行），本戳的读侧是纯 `typeof … === 'number'`
    //    （第 8 圈修法 Z 撤回位置比较之后如此）。按抄来的那句理解并给读侧加回位置比较，
    //    实测会让 117/227 格行为改变、`test/shell-parse.mjs` FAIL(1)，且方向是
    //    **fail-open**（label 由 `rm` 掉成 `""`）—— 正是修法 Z 撤回的那个族。
    // ⚠️ 位置仍取 `segText.length`（此刻构造尚未 `pushText`，故正是它的起始下标）：
    //    读侧当前不用它，但词法器本就持有该值，记下来比布尔省一次判断，日后若真需要
    //    位置信息也不必再改词法器。
    if (segOpaqueTargetCand < 0) segOpaqueTargetCand = segText.length
    // 置位「下一个真词元要定案」——即使候选已经记过（粘性），**每个**占位构造都要重新置位：
    // `> $(a) A=1 > $(b) B=2` 里第二个 `$(b)` 之后同样有一个词元被吞。
    opaqueTargetSwallow = true
  }
  // 花括号是**分组**（不可作重定向目标）还是**字面词 / 花括号展开**（可作）：
  // bash 的分组要求「以 `;` 或换行收尾」，否则整个 `{…}` 只是一个词 —— `bash -n` 实测：
  //     `> {mktemp} & …` OK、`> { b } & …` OK、`> {a,b} & …` OK、`> } & …` OK
  //     `> { b; } & …` SYNTAX-ERR、`> {b;} & …` SYNTAX-ERR、`> {;} & …` SYNTAX-ERR
  //     `> { b; c } & …` OK ← 注意：**只有末尾**的 `;` 才定分组，中间的 `;` 不定
  // 故判据是「**最后一个**分隔符之后只剩空白」，不是「内容里有 `;`」。
  //
  // ── ⚠️ 判据必须在**词法层面**做，不能直接在原始文本上跑正则 ────────────────────
  // 旧实现是 `/;[\s]*$/.test(content) || /[\n\r]/.test(content)` —— 它问的是「文本里有没有
  // 换行 / 结尾有没有分号」，而 bash 问的是「词法上有没有一个未转义、未被引号包裹的分隔符」。
  // 两者在两族上分叉（`bash -n` = OK、真实执行会跑）：
  //   ① **引号内的换行**：`{ "a` NL `b" }` 里的换行在双引号内，是字面字符 —— 整个 `{…}`
  //      只是一个词。旧判据看到 NL 就判成分组 → `&` 触发 → 整行 `ok:false` → 丢 `outside` 档。
  //   ② **转义分号 `\;`**：`{ a\; }` 里的 `;` 被转义，是字面字符，同样只是一个词。
  // 误判的后果：整行 `ok:false` 路径的档位集合不含 `outside`、且只认 deny 例外，于是用户
  // 显式配的 `outside=deny` 与全部 ask 例外在这条路径上整个失明（fail-open）。
  // 故扫描把引号与转义一并跳过，只认**顶层**分隔符。
  //
  // ⚠️ 判据方向是 **fail-closed 优先**：只在「确实读到一个顶层分隔符、且其后只剩空白」时
  // 才判分组（`{a&&}` / `{a|}` 这类内容自身非法的形态判词，与 bash 的窄偏差方向安全）。
  const braceIsCommandGroup = (content) => {
    let quote
    let last = -1
    for (let i = 0; i < content.length; i += 1) {
      const c = content[i]
      if (quote === 'single') { if (c === "'") quote = undefined; continue }
      if (quote === 'double') {
        // 双引号内 `\` 转义下一个字符（含 `\` 与 `"`），转义目标不参与判据
        if (c === '\\') { i += 1; continue }
        if (c === '"') quote = undefined
        continue
      }
      // 引号外：`\` 转义下一个字符 —— `\;` 的 `;` 是**字面**分号，不得计入
      if (c === '\\') { i += 1; continue }
      if (c === "'") { quote = 'single'; continue }
      if (c === '"') { quote = 'double'; continue }
      if (c === ';' || c === '\n' || c === '\r') last = i
    }
    if (last < 0) return false
    return /^[\s]*$/.test(content.slice(last + 1))
  }

  // ── 进程替换 `>( )` / `<( )` 是**词**（可作重定向目标），与子 shell `( )` 相反 ─────────
  // `bash -n` 实测：
  //     OK   `echo a > >(cat)` / `echo a > <(cat x)` / `echo a >(cat)` / `echo a 2>(cat)`
  //     ERR  `echo a > (cat)` / `echo a >>(cat)` / `echo a >|(cat)` / `echo a >&(cat)`
  //     ERR  `echo a &>(cat)` / `echo a <>(cat)` / `echo a <<(cat)`
  // 词法器里 `>` 先被 `REDIRECT_OPERATOR` 吃掉、`(` 单独进 `(` 分支，故这里只能**回看**
  // 判断这个 `(` 是不是进程替换的开头。
  //
  // ⚠️ **不能只看「`(` 的前一个字符是 `>` 或 `<`」**（本判据的初版，实测过宽）：
  // `>>(cat)` / `>|(cat)` / `>&(cat)` / `&>(cat)` / `&>>(cat)` / `<>(cat)` / `<<(cat)`
  // 的 `(` 同样紧贴 `>` / `<`，但那个字符是**更长操作符的一部分**，bash 实测全是语法错误。
  // 按「紧贴即算词」会把这一族一起放行 —— 那是**新开的 fail-open**
  // （`rm -rf /etc >> >(tee log) & echo done` 由 deny 变 allow）。
  //
  // 故判据 = **把 `(` 之前那串操作符字符按 bash 的规则切成词元，要求最后一个词元恰好是
  // 裸 `>` 或 `<`**（即 `(` 紧跟在一个独立的单字符重定向操作符之后）。这正是 bash 的
  // 判定条件：`>(` / `<( ` 只在 `>` / `<` 是**独立操作符**时才是进程替换的开头。
  // 逐格核对（`bash -n` 真值，本判据与 bash 在 1170 条「`(` 紧贴操作符」样本上**零误收紧**）：
  //     true   `>(cat)` `<(cat)` `2>(cat)` `> >(cat)` `><(cat)` `>|>(cat)` `>&>(cat)`
  //            `&&>(cat)` `>>>(cat)` `>><(cat)` `<>>(cat)`
  //     false  `>>(cat)` `>|(cat)` `>&(cat)` `&>(cat)` `&>>(cat)` `<>(cat)` `<<(cat)`
  //
  // 为什么要**切词**而不是只看「前一个字符」或「前两个字符」：`<>` 是 bash 的操作符
  // （`<>(cat)` 非法），而 `><` **不是**（`><(cat)` 合法）—— 两个字符的先后次序决定结论，
  // 任何「看固定长度前缀」的判据都会把其中一边判错（实测：只看 1 个字符误放行 537 条，
  // 只看 2 个字符仍误放行 296 条且误收紧 207 条）。
  //
  // ⚠️ 操作符表按**最长优先**排列，与 bash 的词法一致（`<<<` / `&>>` 三元，其余二元，
  // 最后是单字符）。`OPERATOR_RUN` 只含重定向与控制操作符字符 —— 空白 / `2` / `;` 都会
  // 终止回看，故 `> (cat)`（有空格）与 `2>(cat)`（fd 号）都落回「单字符操作符」这一支。
  // `;` 不在其中是有意的：`>;<(cat)` 的错在于**前一个 `>` 没有目标**（bash 报错），
  // 与本判据无关，且那条缺口在 HEAD 上同样存在（`echo a > ; echo done` 也是 ok:true）。
  const OPERATOR_RUN = '<>&|'
  const OPERATOR_TOKENS = ['<<<', '&>>', '&&', '||', '<<', '>>', '<&', '>&', '<>', '>|', '&>', '|&', '>', '<', '&', '|']

  const parenIsProcessSub = (text, i) => {
    if (text[i - 1] !== '>' && text[i - 1] !== '<') return false
    let start = i - 1
    while (start > 0 && OPERATOR_RUN.includes(text[start - 1])) start -= 1
    let p = start
    let bare = false
    while (p < i) {
      let hit = null
      for (const op of OPERATOR_TOKENS) { if (text.startsWith(op, p)) { hit = op; break } }
      if (hit === null) { p += 1; bare = false; continue }
      p += hit.length
      bare = hit === '>' || hit === '<'
    }
    return p === i && bare
  }

  for (let index = 0; index < input.length; index += 1) {
    const char = input[index]

    // ── 单引号内：原样，无转义（两种 shell 一致）──
    if (quote === 'single') {
      pushText(char)
      if (char === "'") { quote = undefined; continue }
      addWord(char)
      continue
    }

    // ── 双引号内：bash 用 `\` 转义，pwsh 用反引号 ──
    if (quote === 'double') {
      if (sh === 'bash' && char === '\\') {
        const next = input[index + 1]
        if (next === undefined) return { ok: false, reason: 'the command line ends inside an escape' }
        if ('\\"$`\n'.includes(next)) {
          pushText(char + next)
          addWord(next)
          index += 1
          continue
        }
        pushText(char)
        addWord(char)
        continue
      }
      // ── pwsh 转义（反引号）：**读得出**，故不标 opaque ────────────────────────────
      // 必须在 `char === '"'` 之前：`` `" `` 是**字面双引号**，不结束字符串
      // （官方解析器实测 `"a`"b"` 是**一个** StringExpandable 词元）。
      // 也必须在下面那条 bash 命令替换分支之前 —— 反引号在 pwsh 里**不是**命令替换定界符。
      if (sh === 'pwsh' && char === '`') {
        const esc = readPwshEscape(input, index, true)
        if (esc === null) return { ok: false, reason: 'the command line ends inside an escape' }
        // 行尾字面反引号（`` `abc` `` 的收尾那个）：进词元，不进 segText 的转义处理
        if (esc.continuation) { pushText(esc.raw); index += esc.raw.length - 1; continue }
        // segText 保留**用户写的原文**（例外匹配的对象是原文，与 bash 的 `\x` 分支同处置），
        // wordText 收**转义后的真实字符**（判定与 label 要按实际执行的命令看）。
        pushText(esc.raw)
        addWord(esc.value)
        index += esc.raw.length - 1
        continue
      }
      // ⚠️ 到这里 `char === '`'` 只可能是 **bash** 的命令替换定界符（pwsh 已在上一个分支返回）。
      // 与引号外那条同处置：显式写方言守卫，且 `markOpaque` 不再带方言三元 ——
      // 那个三元在此处的 else 臂**恒不可达**（pwsh 走不到这里），留着等于给「两处各判一次
      // 方言」留了个假入口，正是本文件反复警告的那种双份判据。
      if (sh === 'bash' && char === '`') {
        const end = input.indexOf('`', index + 1)
        if (end < 0) return { ok: false, reason: 'the command line ends inside an unbalanced quote' }
        markOpaque('command substitution cannot be read statically')
        noteOpaqueHead()
        // 原文同时进 wordText：若替换式就是段首词，label 会因含反引号而被判「认不出」
        // （BAD_LABEL_CHARS），方向 fail-closed；不写 wordText 则会产出一个空词元。
        const raw = input.slice(index, end + 1)
        noteOpaqueText(raw)
        pushText(raw)
        addWord(raw)
        index = end
        continue
      }
      if (char === '"') { pushText(char); quote = undefined; continue }
      if (char === '$') {
        const expansion = readExpansion(input, index, sh)
        if (expansion === undefined) {
          const end = skipBalanced(input, index + 1, '(', ')')
          if (end < 0) return { ok: false, reason: 'the command line ends inside an unbalanced quote' }
          markOpaque('command substitution cannot be read statically')
          noteOpaqueHead()
          const sub = input.slice(index, end + 1)
          noteOpaqueText(sub)
          pushText(sub)
          index = end
          continue
        }
        pushText(expansion)
        addWord(expansion)
        segDynamic = true
        // 当前词元含变量展开 → 标记为「动态」。这个标记供下面 `2>` 的 fd 号判定使用：
        // `echo $N> f` 里的 `$N` 是**词元**（值为 N 的展开），不是 fd 号，不能当 `2>` 那样丢掉。
        // 曾经这里只置 segDynamic（段级）而漏了 dynamic（词元级），于是 746 行的 `!dynamic`
        // 恒为真、注释声称的这层保护从未生效 —— 虽然实测各形态结果恰好正确
        // （变量展开后 wordText 含 `$`，本就不匹配 /^[0-9]+$/），但那是巧合而非设计。
        dynamic = true
        index += expansion.length - 1
        continue
      }
      pushText(char)
      addWord(char)
      continue
    }

    // ── 换行：段分隔符（CRLF 只算一次）──
    if (char === '\n' || char === '\r') {
      if (char === '\r' && input[index + 1] === '\n') continue
      // 待读的重定向目标可跨换行：bash 接受 `printf x >\n~/.ssh/keys` 为**一条**命令。
      // 此时不能分段 —— 分段会把目标甩进下一段，凭空造出一个「只有重定向、没有命令」的段。
      if (pending !== undefined && !started) { pushSpace(); continue }
      flushSegment()
      nextOp = 'newline'
      continue
    }

    // ── 引号外空白 ──
    if (/\s/.test(char)) {
      flushWord()
      pushSpace()
      continue
    }

    // ── pwsh 数组运算符 `,`：**词分隔符**，不是普通字符 ──────────────────────────
    //
    // PowerShell 里 `,` 是**运算符**，不是标点。用官方词法分析器测定
    // （`[System.Management.Automation.Language.Parser]::ParseInput`，PowerShell 5.1）：
    //     Remove-Item "a", "b"      → … [StringExpandable:"a"] [Comma:,] [StringExpandable:"b"]
    //     Remove-Item "a","b"       → 同上（**引号紧贴也一样**，逗号仍是独立 token）
    //     Remove-Item "C:\tmp\a,b"  → … [StringExpandable:"C:\tmp\a,b"]（引号内是字面量）
    // 即它与空格无关、与引号边界无关（只与「在不在引号内」有关）。
    // 语义验证：`Remove-Item <两个文件>` 的 `-WhatIf` 输出两条 "Remove File"，确认是两个目标。
    //
    // ── 为什么必须在这里切词，而不是在判档侧剥尾逗号 ────────────────────────────
    // 逗号粘在词元尾部会让**精确匹配**的档位判据全部落空：`B:\` 判 `drive-root`、
    // `C:\Windows` 判 `system`，而 `B:\,` / `C:\Windows,` 两个判据都不匹配，只剩「工作区外」。
    // 实测档位**降级**（BLAST_ORDER 数字越小越严重）：
    //     B:\          drive-root → B:\,         outside   ★ 降级
    //     /            drive-root → /,           outside   ★ 降级
    //     C:/Windows   system     → C:/Windows,  outside   ★ 降级
    // 端到端（`wide=deny`、其余 ask）：
    //     Remove-Item "B:\" -Recurse -Force          → deny
    //     Remove-Item "B:\", "D:\x" -Recurse -Force  → **ask**  ← 一个逗号绕过显式 deny
    // 这就是为什么修在词法器：**判据没有错，是喂给它的词元错了**。在判档侧剥逗号属于
    // 给下游补丁，且会与「引号内的逗号是字面量」这条正确行为打架。
    //
    // ⚠️ 只在 pwsh 生效：bash 里 `,` 是**普通字符**（`rm -rf /tmp/a,b` 删的是名字里带
    // 逗号的那**一个**文件），照切会凭空造出一个不存在的目标。花括号展开 `{a,b}` 由下面的
    // 分组分支处理（标 opaque），与本分支无关 —— 两条路径不会同时命中。
    //
    // 逗号**保留在 segText**（例外匹配的对象是用户写的原文，`Remove-Item "a", "b"` 必须
    // 仍能命中 `Remove-Item *`），但**不进 wordText** —— 它是运算符，不是词元的一部分。
    if (sh === 'pwsh' && char === ',') {
      flushWord()
      pushText(char)
      continue
    }

    if (char === "'") { pushText(char); quote = 'single'; if (!started) tokenTyped = true; started = true; continue }
    if (char === '"') { pushText(char); quote = 'double'; if (!started) tokenTyped = true; started = true; continue }

    // ── 转义：bash 用 `\`，pwsh 用反引号 ──
    if (sh === 'bash' && char === '\\') {
      const next = input[index + 1]
      if (next === undefined) return { ok: false, reason: 'the command line ends inside an escape' }
      index += 1
      if (next === '\n') continue
      pushText('\\' + next)
      addWord(next)
      started = true
      continue
    }
    // ── pwsh 转义（反引号）：与 bash 的 `\` 分支**同构**，只是一张不同的转义表 ─────────
    //
    // ── 为什么必须在这里拦下（本轮修复，用户实测）────────────────────────────────
    // 此前反引号**没有方言守卫**，无条件落进下面那条「bash 命令替换」分支去找**配对**反引号。
    // 于是 pwsh 的转义符被当成 bash 的定界符，后果由**反引号个数的奇偶**决定：
    //
    //     0 个 → ok:true   1 个 → **ok:false**   2 个 → ok:true   3 个 → **ok:false**
    //
    // 用户两条命令各只有 1 个（`"`n--- … ---"`），整行 `ok:false`。而 `ok:false` 路径
    // **只认 deny 例外**（见 `assessCommand` 的整行分支）—— 用户配的 23 条 allow 例外
    // 与全部 ask 例外在这一行上**集体失明**。实测（command=allow + 例外 `Remove-Item *`=ask）：
    //     带 1 个反引号 → **allow**（用户的确认规则被静默绕过，fail-open）
    //     不带反引号     → ask   ✅
    // 而 PowerShell 官方解析器对同两条命令报 **0 错误**、共 4 / 6 条语句 —— 它们完全合法。
    //
    // 方向：本分支把「读不懂」变成「读得懂」，故**只会让判定回到段级路径**，
    // 而段级路径比整行路径**更严**（认全部例外、认全部档位）。不会放宽任何东西。
    if (sh === 'pwsh' && char === '`') {
      // 词法上下文由**调用方**给出（判据本体是 `pwshEscapeBoundaryAt`，单一实现）：
      //   · `level === 'segment'` —— 反引号落在一个 Parameter 词元内：PS 把它当**字面字符**，
      //     既不转义（连 `` `n `` 都原样保留）、也**不吞掉后面的运算符**。缺这一支时
      //     `cmd /c ver -x` + `` ` `` + `;` + `` ` `` + NL + `Remove-Item …` 的 `;` 被吞进
      //     词元，第二行的破坏性命令与第一行同判 ⇒ 实测由 `deny` 变 **`allow`**（fail-open）。
      //   · `open === true` —— 反引号落在一个**未完结**词元内：`` ` ``+CRLF 只吃 CR。
      //   · 否则（词元边界处）—— `` ` ``+换行一律整体续行。
      const boundary = pwshEscapeBoundaryAt(wordShape, tokenTyped, segLastIsQuote, lastGroupClose, index)
      const esc = readPwshEscape(input, index, false, boundary, wordShape)
      if (esc === null) return { ok: false, reason: 'the command line ends inside an escape' }
      // 续行（`` ` `` + 换行）：本分支**一律**把它当续行消费（`pushText(esc.raw)`，两行接成
      // 一条命令），差别只在「要不要在这里切一刀」—— 这一刀由下面的守卫决定。
      //
      // ⚠️ 判据的维度是**词元**（`wordText` / `tokenTyped`），不是「反引号前一个字符是不是
      // 分隔符」。`readPwshEscape` 判「行尾反引号是字面字符还是语法错误」用的是
      // `PWSH_TOKEN_BREAK`（**字符**维度）—— 那处是对的（行尾没有「下一个词元」可言），
      // 两处判据不同维度，不得互相套用。
      //
      //   ── A. 已完结的完整词元 ⇒ **必须切**（旧字符判据全部漏判，是真 fail-open）──
      //   · **Parameter 词元**（`-NoNewline` / `-Recurse` / …）：token 是
      //     `Parameter[-NoNewline`]`（反引号并进参数名）、没有 LineContinuation，但
      //     `[Parser]` 报 2 条 PipelineAst = **语句边界** ⇒ 用 `flushSegment()`。
      //     只能用它：改用 `flushWord()` 两行同段，第二行的破坏性命令与第一行同判。
      //   · **成员 / 下标 / 静态成员访问**（`$x.Name` / `$a[0]` / `$env:TEMP.Length` …）：
      //     官方解析器判 `LineContinuation`（同一条语句）⇒ `flushWord()`，且判据必须与
      //     `tokenTyped` 合取（见 `PWSH_ACCESSOR_TAIL`）。
      //   · `-Confirm:` 这类**带冒号收尾**的 Parameter：同样是 `LineContinuation`、同一条语句
      //     ⇒ `flushWord()`。**Parameter 族是语句边界，`-Confirm:` 是词元边界**。
      //   · **分组块**（`( … )` / `{ … }` / `@( … )` / `@{ … }`）：`stmts=1`、词元边界 ⇒
      //     `flushWord()`。判据必须是**位置**（`lastGroupClose === index - 1`），不能对
      //     `segText` 裸判 `/[)}]$/`：后者会命中 `${x}` / `${a}${b}`（PS 实测粘住），也会
      //     命中 `(x)y` / `@(x)z` 这类收尾符之后还有字符的形态。
      //
      //   ── B. 首字符是普通字符 ⇒ **必须粘住**（旧判据此处本就正确，不得改动）──
      //   裸词 `C:/Windows`、简单变量 `$TARGET` / `${x}` / `$env:TEMP`、`abc]`、`a.b`、
      //   `x$y.y`：都是**一个** `Generic` 词元（反引号是字面字符）。尤其不得把 `$TARGET`
      //   这类简单变量切开 —— 那是把方向从 fail-open 翻成误报。
      //
      //   ⚠️ 已知反向误差（既有，不在本次范围）：`${x}` / `${a}${b}` / `(x)${y}` 单独出现时
      //   PS 粘住而本实现切开；重定向目标处的续行同样判词元边界。
      //   ⚠️ 引号**内**的那处（`readPwshEscape(input, index, true)` 的调用点）判据不同，不要动。
      if (esc.continuation) {
        // 前一个词元的**整词文本**（`wordText`，不是 `input[index - 1]`）—— 判据取词元维度。
        // 三段式：语句边界 → 词元边界 → 真续行（什么都不切）。判据本体是
        // `pwshEscapeBoundaryAt`（**单一实现**：CRLF 支也要问同一个问题，见该函数说明），
        // 且**只在本分支问一次** —— `boundary` 就是本分支开头算好的那一个，五个输入
        // （`wordShape` / `tokenTyped` / `segLastIsQuote` / `lastGroupClose` / `index`）
        // 在两次调用之间一个都没被修改（`readPwshEscape` 全程只读、不写传入的 shape）。
        //
        // ⚠️ **语句边界处不得把续行标记写进任何段**（本轮修复，用户实测）。此前这里是
        //    「先 `flushSegment()` 再 `pushText(esc.raw)`」的**无条件**写法，于是 `` ` ``+换行
        //    被记到**下一个段**（它真正续行的那一段已经切走了），且 `nextOp` 没置 `'newline'`
        //    ⇒ 新段仍带 `'start'`。实测（pwsh，`cmd /c ver -x` + `` ` `` + LF + `Remove-Item …`）：
        //      输入                op          段 text
        //      `` ` `` + **LF**    `start`❌   `` `\nRemove-Item -Recurse -Force C:/Windows ``（污染）
        //      `` ` `` + **CRLF**  `newline`✅ `Remove-Item -Recurse -Force C:/Windows`（干净）
        //    两者是**同一条命令**（`[Parser]` 对 LF / CRLF 都给 `Parameter[-x`]` + 2 条
        //    PipelineAst），判定的段文本却不同 ⇒ 用户手写的**干净精确 deny 例外失明**：
        //      大分类 allow + 八档全 allow + 例外 `Remove-Item -Recurse -Force C:/Windows`=deny
        //        `` ` ``+LF   → **allow**（段文本带着 `` ` ``+换行，例外匹配不上）
        //        `` ` ``+CRLF → deny（e1）   裸 LF → deny（e1）   `;` → deny（e1）   `&&` → deny（e1）
        //    另一个后果是弹窗标签：`start` 的语义是**首段**，出现在第 2 段（`index.js` 的
        //    「段 N <op>」）自相矛盾。
        //    修法与**本函数 CRLF 支**、以及 **bash** 的 `\`+换行 处置一致（续行符不保留）：
        //    实测 `rm -rf /tmp/pgx >\<NL>&2` 的段文本是 `rm -rf /tmp/pgx >&2`。
        //    ⚠️ 另一变体「先 `pushText` 再 flush」也能消掉 text 污染，但会把标记留在**上一段**
        //    （`cmd -x``` ），与 CRLF 支不一致，**不要用**。
        if (boundary.level === 'segment') {
          flushSegment()
          // 与换行分支（`flushSegment()` 后紧跟的那行）同口径：新段由**换行**开始。
          nextOp = 'newline'
        } else {
          pushText(esc.raw)
          if (boundary.level === 'word') flushWord()
        }
        index += esc.raw.length - 1
        continue
      }
      pushText(esc.raw)
      addWord(esc.value)
      started = true
      index += esc.raw.length - 1
      continue
    }
    // ⚠️ 到这里 `char === '`'` 只可能是 **bash** 的命令替换定界符（pwsh 已在上一个分支返回）。
    // 显式写出方言守卫而不是靠「上面拦住了」：本分支的语义是 bash 专有的，
    // 而它此前**没有**守卫 —— 那正是上面那个缺陷的成因，不该再留一次同样的机会。
    if (sh === 'bash' && char === '`') {
      const end = input.indexOf('`', index + 1)
      if (end < 0) return { ok: false, reason: 'the command line ends inside an unbalanced quote' }
      markOpaque('command substitution cannot be read statically')
      noteOpaqueHead()
      const raw = input.slice(index, end + 1)
      noteOpaqueText(raw)
      pushText(raw)
      addWord(raw)
      started = true
      index = end
      continue
    }

    // ── 变量展开：只标记，不求值 ──
    if (char === '$') {
      const expansion = readExpansion(input, index, sh)
      if (expansion === undefined) {
        const end = skipBalanced(input, index + 1, '(', ')')
        if (end < 0) return { ok: false, reason: 'the command line ends inside an unbalanced quote' }
        markOpaque('command substitution cannot be read statically')
        noteOpaqueHead()
        noteOpaqueTarget(true)
        const sub = input.slice(index, end + 1)
        noteOpaqueText(sub)
        pushText(sub)
        index = end
        continue
      }
      pushText(expansion)
      addWord(expansion)
      // 变量展开在**词元首** ⇒ typed 词元（`$x.Name` 族据此切开；`x$y.y` 不置位）
      if (!started) tokenTyped = true
      started = true
      segDynamic = true
      dynamic = true
      index += expansion.length - 1
      continue
    }
    if (sh === 'pwsh' && char === '%') {
      const m = matchAt(CMD_VARIABLE, input, index)
      if (m !== undefined) {
        pushText(m)
        addWord(m)
        if (!started) tokenTyped = true
        started = true
        segDynamic = true
        dynamic = true
        index += m.length - 1
        continue
      }
    }

    // ── 注释：仅词首（bash 与 pwsh 同规则）──
    if (char === '#' && !started) {
      while (index + 1 < input.length && input[index + 1] !== '\n') index += 1
      continue
    }

    // ── 操作符 ──
    if (char === '&') {
      if (input[index + 1] === '&') {
        flushSegment()
        nextOp = '&&'
        index += 1
        continue
      }
      // `&>` / `&>>` 是合并重定向，不是后台执行
      if (input[index + 1] === '>') {
        flushWord()
        pushText(input[index + 2] === '>' ? '&>>' : '&>')
        pending = 'write'
        redirectOpaqueTarget = 'none'
        index += input[index + 2] === '>' ? 2 : 1
        continue
      }
      // ⚠️ 两条都必须在 `flushSegment()` **之前**取 —— 它会把 `pending` / `words` /
      // `started` / `segOpaque` 全部复位，之后再问恒为「空段」。
      //   · `noTarget`：重定向还等着目标（`echo a > &` 的 `&` **不是** `>` 的目标，
      //     bash 判语法错误）。少了这一条，`&` 的豁免会把「重定向无目标」一起放行 ——
      //     判据与下面行尾那条 `pending !== undefined && !started` 同源（都是词元级）。
      //   · `flushSegment()` 的返回值：本段有没有内容（异步列表的 list 部分）。
      //
      // ── ⚠️ 第三个合取项 `redirectOpaqueTarget !== 'word'`：`!started` 的**误判**修正 ──
      // `!started` 对「重定向目标是 **opaque 构造**」是**误判**：`$( )` / `( )` / `{ }` /
      // 反引号四条分支**都不设 `started`**（只 `markOpaque` + `pushText` + 跳过配对），
      // 而其中一部分在 bash 里是**合法**的重定向目标（`bash -n` 实测）：
      //     OK          `echo a > $(mktemp) & echo done` / `2> $(mktemp) & …` / `>> …` / `< …`
      //     OK          `echo a > {mktemp} & …`（字面词） / `echo a > } & …`
      //     SYNTAX-ERR  `echo a > (mktemp) & …` / `echo a > ) & …` / `echo a > { b; } & …`
      // 即 `$( )` / 字面花括号形态**合法**，而 `( )` / `)` / 花括号**分组**形态非法 ——
      // 这个区分本就不该由 `started` 承担，故由 `redirectOpaqueTarget` 精确判（三态见其注释）。
      //
      // 为什么必须在这里修：`&` 分支的 `flushSegment()` 本来会把这个误判随 `pending` 一起
      // 清掉，故 HEAD 上不显形；**粘性**（下面那行）把它保留到行尾后，**合法命令被推进
      // `ok:false`** —— 而 `ok:false` 路径（`assessCommand` 的 `if (!d.ok)` 支，约 `:6600`）
      // 只认 deny 例外，档位集合是 `groupTiersOf + priv + RADIUS_TIERS_WHEN_UNREADABLE`、
      // **不含 `outside`**，于是用户显式配的 `outside=deny` 与**全部 ask 例外**在这条路径上
      // 整个失明（fail-open，本项目最高风险方向）。实测（`outside=deny`、其余七档 allow）：
      //     rm -rf /tmp/x                            → deny
      //     rm -rf /tmp/x > $(mktemp) & echo done    → HEAD **deny** / 仅加粘性 **allow** ❌
      //     rm -rf /tmp/x 2> $(mktemp) & echo done   → HEAD deny / 仅加粘性 allow ❌
      // （例外侧同形：分类 allow + 例外 `curl *`=ask 时 `curl … > $(mktemp) & echo done`
      //   由 ask 变 allow。）
      //
      // ⚠️ 读取位置必须在 `flushSegment()` **之前**（与 `pending` / `started` 同处），
      // 且**粘性的全部收益都保住**：`echo a > & (b) &` 的第一个 `&` 处 `(b)` 尚未被解析、
      // `redirectOpaqueTarget` 仍是 `'none'` ⇒ 照旧置位 ⇒ 照旧 `ok:false`。
      const ampNoTarget = pending !== undefined && !started && redirectOpaqueTarget !== 'word'
      // ⚠️ **粘性**（`||`，不是覆盖）：`echo a > & (b) &` 里第一个 `&` 满足条件、第二个
      // （行尾那个）不满足，覆盖式写入会把结论抹掉。语义上只要**有任何一个** `&` 前面
      // 挂着没目标的重定向，整行在 bash 里就是语法错误，故一旦置位就不再复位。
      ampTargetMissing = ampTargetMissing || ampNoTarget
      ampAfterContent = flushSegment() && !ampNoTarget
      nextOp = '&'
      continue
    }
    if (char === '|') {
      // ── `|&`（管道 + stderr）必须被本分支**整体消费**────────────────
      // bash 里 `|&` 是**一个**操作符（`cmd 2>&1 | cmd` 的简写），与 `|` 同为管道分隔符。
      // 本分支此前只看 `||`，于是 `|&` 的 `|` 被当分隔符、`&` 落到下面的 `&` 分支 ——
      // 而那个分支按「异步列表的 `&`」处理，于是 `echo a |&>& log & echo b` 走
      // `&` 的悬空检查 → 整行 `ok:false`。
      //
      // ⚠️ 后果不是「少分一段」而是**整条命令的判定路径被换掉**：`ok:false` 路径
      // （`assessCommand` 的 `if (!d.ok)` 支）档位集合不含 `outside`、且**只认 deny 例外**
      // —— 用户显式配的 `outside=deny` 与**全部 ask 例外**在这条路径上整个失明（fail-open）。
      // 实测（分类 allow + 例外 `curl *`=ask）：
      //     curl -s http://example.com |&>& log & echo done   HEAD ask → 当前 **allow** ❌
      // 而这两条在 bash 里 `-n` = OK、真实执行**真的写出 `log` 文件**（已用真 bash 复核）。
      //
      // ⚠️ **报告者建议的修法（删 `OPERATOR_TOKENS` 里的 `|&`）实测无效**：靶格无括号，
      // `parenIsProcessSub` 根本不参与。真正的原因在这里 —— 是**主循环**没消费 `|&`。
      // 且实测删 `|&` 只翻转 4 格，而删 `<>` 会翻转 26 格并使套件 FAIL：`<>` 承重，不能动。
      //
      // `|&` 的 `&` **必须一并跳过**（`index += 1`）：留给下一轮的话，`&` 分支会把它当
      // 异步列表的分隔符 —— 于是 `echo a |& log & echo b` 会**凭空多出一个段边界**。
      // 判据顺序：先判 `||`（`|&` 不以 `|` 开头，两者不可能同时命中）。
      const isOr = input[index + 1] === '|'
      const isPipeErr = !isOr && input[index + 1] === '&'
      flushSegment()
      nextOp = isOr ? '||' : '|'
      if (isOr || isPipeErr) index += 1
      continue
    }
    if (char === ';') {
      flushSegment()
      nextOp = ';'
      continue
    }
    if (char === '>' || char === '<') {
      // heredoc：正文在后续行，段边界因此不可信（正文里可以出现任何东西，
      // 包括看起来像命令的行）。找不到终止符就无法确定正文范围 —— 不猜，整行判读不懂。
      if (input.startsWith('<<', index)) {
        return { ok: false, reason: 'here-document input cannot be read statically' }
      }
      // `2>` 里的 `2` 是 fd 号不是词元；但引号/变量/通配形态的 `2` 是真词元
      if (started && !dynamic && /^[0-9]+$/.test(wordText)) {
        resetWord()
        started = false
        // ⚠️ 本分支**绕过 `flushWord()`**（它只清 `wordText` / `started`），故必须自己复位
        // `tokenTyped` —— 漏了它，标记会跨过重定向泄漏到**目标**上：`"5">out.txt` 的 `out.txt`
        // 会被 `PWSH_ACCESSOR_TAIL` 的 `\.[A-Za-z_]\w*$` 误判成成员访问 ⇒ 多切一刀。
        // 实测（`"5">out.txt` + 反引号 + NL + `Remove-Item …`）：
        //   `writeTargets` 由 `['out.txtRemove-Item']` 变成 `['out.txt']`，第二行另起一段；
        //   官方解析器实测该行是**一个** `Generic[out.txt`+NL+`Remove-Item]`（**粘住**）
        //   ⇒ 这一刀是**误切**，且方向是放宽：`category=deny` + `destructive={wide:allow}`
        //   实测由 `deny` 变 **`allow`**。
        //   ⚠️ 复位后回到「粘住」，那是**既有的**反向误差（PRE 同值），不是本次引入的；
        //   要连它一起修得另立判据（重定向目标处的续行语义），不在本次范围。
        tokenTyped = false
      } else {
        flushWord()
      }
      // `2>&1` / `>&2` 是描述符复制，不是文件目标
      const dup = matchAt(DESCRIPTOR_DUPLICATION, input, index)
      if (dup !== undefined) {
        pushText(dup)
        index += dup.length - 1
        continue
      }
      const op = matchAt(REDIRECT_OPERATOR, input, index)
      pushText(op)
      pending = char === '>' ? 'write' : 'read'
      // 新开一个待读目标 ⇒ 上一个重定向的 opaque 结论作废（见 `redirectOpaqueTarget` 的注释）
      redirectOpaqueTarget = 'none'
      // ⚠️ 同上，但只作废**尚未定案**的候选：`opaqueTargetSwallow`
      //    仍为真意味着上一个 opaque 构造占的那个目标位**还没被任何词元消费**就被本次
      //    新重定向取代了 ⇒ 它没有顶掉任何词元，命令词位自然也未被它占据。
      //    实测（Git Bash 5.3.15，真 `mktemp`）：`> $(true) > out A=/bin/rm` → `A` 被设为
      //    `/bin/rm`、无 RAN、rc=1 ⇒ **真赋值**；不作废会把它误判成真命令（新过收）。
      //    ⚠️ **已定案**的 `segOpaqueTargetAt` 不在这里复位 —— 那正是「粘性」的承重之处
      //    （`> $(mktemp) r"m" A=/bin/rm > out2` 这类尾部还有重定向的形态靠它才修得好）。
      if (opaqueTargetSwallow) { opaqueTargetSwallow = false; segOpaqueTargetCand = -1 }
      index += op.length - 1
      continue
    }

    // ── 分组与花括号展开：读不懂，标 opaque 并跳过配对 ──
    // 例外：`find -exec … {} \;` 的 `{}` 是精确字面量占位符，不是花括号展开 ——
    // 把它当展开会让常规只读巡检无法进行。
    if (char === '{' && input[index + 1] === '}' && !started && (input[index + 2] === undefined || /\s/.test(input[index + 2]))) {
      pushText('{}')
      resetWord()
      addWord('{}')
      started = true
      index += 1
      continue
    }
    if (char === '(' || char === '{') {
      const close = char === '(' ? ')' : '}'
      const end = skipBalanced(input, index, char, close)
      if (end < 0) return { ok: false, reason: 'the command line ends inside an unbalanced group' }
      markOpaque('shell grouping or brace expansion cannot be read statically')
      noteOpaqueHead()
      noteOpaqueText(input.slice(index, end + 1))
      // `(` 分支必须再分一次：**进程替换** `>( )` / `<( )` 是可作词的（见 `parenIsProcessSub`），
      // 而**子 shell** `( )` 不可作词。少了这一分，`>(tee log)` 会被记成 `not-word`
      // → `ampNoTarget` 置位 → 整行 `ok:false` → 用户显式配的 `outside=deny` 与全部 ask 例外
      // 在这条路径上失明（fail-open，与 `$( )` / `{ }` / `}` 同族，见 `redirectOpaqueTarget`）。
      noteOpaqueTarget(char === '{'
        ? !braceIsCommandGroup(input.slice(index + 1, end))
        : parenIsProcessSub(input, index))
      // 分组块在**词元首** ⇒ typed 词元（`(Get-Item x).Name` 族据此切开）
      if (!started) tokenTyped = true
      pushText(input.slice(index, end + 1))
      // 记下收尾符位置，供反引号续行守卫判「紧贴着一个已完结的分组块」（见 `lastGroupClose`）
      lastGroupClose = end
      index = end
      continue
    }
    if (char === ')' || char === '}') {
      markOpaque('shell grouping or brace expansion cannot be read statically')
      noteOpaqueHead()
      // 孤立 `}` 是普通词（可作目标），孤立 `)` 不可能合法（见 `noteOpaqueTarget` 的注释）
      noteOpaqueTarget(char === '}')
      pushText(char)
      // 与分组块分支同处置：孤立闭合符同样在 `PWSH_TOKEN_BREAK` 里，故第十轮前**也是切开的**。
      // 官方解析器实测 `abc)` + `` ` `` + NL + `C:/Windows` → `Identifier[abc] RParen[)]`
      // `LineContinuation`（词元边界；该行另有 1 处 `UnexpectedToken`，但 token 表与
      // `a)` / `a}` / `abc}` 同形）。少了本行，这一族在第十轮由「切开」回退成「粘住」——
      // 与分组块族同一条根因、同一个方向（fail-open）。
      lastGroupClose = index
      continue
    }

    pushText(char)
    addWord(char)
    started = true
  }

  if (quote !== undefined) return { ok: false, reason: 'the command line ends inside an unbalanced quote' }
  // 重定向目标缺失。⚠️ 这里的判据是 `started`（**词元级**），与下面那条段级的
  // segHasContent **不是**同一个问题，不得合并：
  //   · 本行问「`>` 后面有没有**词元**」—— `echo a > (b)` 的分组块不是有效目标
  //     （bash 里这是语法错误），`echo a > $f` 的变量展开才是；
  //   · 下面那条问「上一个操作符后面有没有**东西**」—— 它必须接受 opaque 构造
  //     （`Get-Content x | ForEach-Object { $_ }` 的末尾就是分组块）。
  // 实测合并的后果（把本行改成 segHasContent）：`echo a > (b)` 与 `echo a >`
  // 双双由 ok:false 变 ok:true —— 重定向无目标被静默放行，是 fail-open。
  if (pending !== undefined && !started) return { ok: false, reason: 'a redirection has no target' }
  // 悬空操作符：`git status |` / `a &&` 在 shell 里是语法错误，段边界不可信。
  //
  // ── 允许尾随的操作符，两个判据（缺一即为误判）────────────────────────────────
  //   · `;` 与换行 —— 两种 shell 都接受 `echo a;` / `echo a\n`，与方言无关。
  //   · `&` —— **仅 bash**。POSIX 异步列表（`list &`）的尾随 `&` 是**合法语法**
  //     （`sleep 5 &` / `echo a &`），而 pwsh 的 `&` 是保留的调用运算符、**不接受**
  //     尾随（用官方解析器实测 `echo a &` → `AmpersandNotAllowed`）。故按方言分流。
  //
  // ⚠️ 曾经把 `&` 与 `|` / `&&` / `||` 一同当作语法错误，后果是**fail-open**：
  // 整行 ok:false 只认 **deny** 例外（见 `assessCommand` 的 `if (!d.ok)` 那一支），
  // 于是用户写的 **ask** 例外被一个 ` &` 抹掉。实测（分类默认 allow + 例外 `curl *`=ask）：
  //     curl -s http://example.com    → ask
  //     curl -s http://example.com &  → **allow** ← 用户写的确认规则被规避
  //     curl -s http://example.com ;  → ask（`;` 早已在豁免列表里，故这是不一致，不是设计）
  //
  // ⚠️ 放行 `&` **只放行「合法的异步列表收尾」这一个形态**，不是「`&` 一律不算悬空」：
  //   · **pwsh 恒不放行** —— 它的 `&` 是保留的调用运算符，尾随一律是语法错误。
  //     这一条由 `ampOk` 的 `sh === 'bash'` 项承担（不另写判据）：pwsh 时 `ampOk` 恒假
  //     ⇒ `!ampOk` 恒真 ⇒ 尾随 `&` 照旧落 `ok:false`。
  //   · **bash 下 `&` 前面必须有内容**（`ampAfterContent`）—— `echo a & &` / `echo a | &`
  //     的第二个 `&` 前面空无一物，仍是语法错误；
  //   · 本行整体仍受上面的 `nextOp !== 'start'` 约束（空命令行早由 `EMPTY_COMMAND_REASON` 拦下）。
  // 这三条守卫使 `&` 的豁免面**恰好**等于 bash 真正接受的形态。
  const ampOk = nextOp === '&' && sh === 'bash' && ampAfterContent
  // ── `&` 之前那个 `>` 没有目标：`&` 的豁免**不得**把它一起放行─────────
  // 上面那条 `pending !== undefined && !started` 是**保留的**词元级判据，但它读的是**当前**
  // 的 `pending` —— `&` 分支的 `flushSegment()` 已经把它复位，故 `&` **之前**的那个 `>`
  // 它看不到。本行补的正是这个盲区，两者**互补而非重复**（去掉上面那条会让 `echo a > &`
  // 由 FAIL 变 ok，测试 Z2 红灯；去掉本行则下面四种形态仍被放行）。
  //
  // 只对 `nextOp === '&'` 生效：其它操作符下 `pending` 不会被 `flushSegment` 吃掉
  // （`|` / `;` / `&&` / `||` 分支同样调 `flushSegment()`，但那些操作符的尾随悬空
  // 已由上面那条 `!ampOk` 的判据拦下，无需本行）。
  //
  // ⚠️ **bash 与 pwsh 都拦**：`echo a > & b` 在 bash 是
  // `syntax error near unexpected token '&'`（exit=2），在 pwsh 里 `&` 是保留的调用
  // 运算符、同样不接受「重定向后紧跟 `&`」。故本行**不带** `sh === 'bash'` 守卫 ——
  // 它与 `ampOk` 的方向相反（`ampOk` 是放行，本行是收紧），收紧方向不按方言分流。
  if (ampTargetMissing) return { ok: false, reason: 'a redirection has no target' }
  if (nextOp !== 'start' && nextOp !== ';' && nextOp !== 'newline' && !ampOk && !segHasContent()) {
    return { ok: false, reason: 'the command line ends with a dangling operator' }
  }
  flushSegment()
  if (segments.length === 0) return { ok: false, reason: EMPTY_COMMAND_REASON }
  return { ok: true, segments }
}

// ── 段级判定 ──────────────────────────────────────────────────────────────────

/**
 * 从段的词元与重定向目标收集「可能被写入的路径」候选。
 * 用途只有两个：弹窗展示、`code: 'write-outside'` 标注 —— **不参与动作选择**。
 * 所以这里宁可多收（flag 内嵌路径、原始行直扫的绝对路径），不做选项语义解析。
 */
function collectWritePaths(seg, shell) {
  const out = []
  for (const w of seg.writeTargets) out.push(w)
  for (const w of seg.words) {
    if (String(w).startsWith('-')) {
      const p = flagEmbeddedPath(w)
      if (p) out.push(p)
    }
  }
  // 绝对路径直扫：bash 词法器会吃掉 `\`，盘符形态的路径到不了词元列表
  const re = new RegExp(RAW_ABSOLUTE_PATH.source, 'g')
  let m
  while ((m = re.exec(seg.text)) !== null) {
    if (m[1]) out.push(m[1])
  }
  return [...new Set(out)].filter((p) => p && !isNullSink(p, shell))
}

/** 该段是否有重定向目标落在工作区之外（含 `~user` 这类必然在外的形态）。 */
function writeOutsideOf(seg, shell, h) {
  const paths = collectWritePaths(seg, shell)
  if (!paths.length) return false
  for (const raw of paths) {
    const expanded = expandTilde(globRootOf(raw), h.home)
    if (expanded === null) return true
    try { if (h.isOutsideWorkspace && h.isOutsideWorkspace(expanded)) return true } catch (e) {}
  }
  return false
}

// ── 爆炸半径（blast radius）：这一段的删除/销毁目标有多大 ─────────────────────
//
// 问题：判定链只回答「要不要问」，不回答「这一下有多重」—— 而审批人恰恰只能靠后者
// 决定点不点。下面两个目标的动作与候选完全相同，面板上看起来毫无区别：
//     rmdir /s /q B:\                      ← 整个盘
//     rmdir /s /q B:\demo-app\build   ← 一个构建目录
// 本函数把目标分档，供弹窗与例外列表显示警告。
//
// 本函数只做**分类**，不改动作（动作仍由判定链决定）：把目标归到一档，供弹窗与列表
// 显示警告。分档的依据是「一次误操作会造成多大范围不可逆损失」，故顺序即严重度。
//
// 为什么不做成「危险目标 → 强制 deny」：那会把「用户确实想清空某个系统临时目录」
// 这类合法操作一并堵死，且盘根判定必然有边界情形（junction/挂载点）。显示警告让**人**
// 来判断，与「审批」这件事的定位一致：机器负责把信息摆全，人负责决定。
//
// 系统目录名单刻意只收「删了必然出大事且几乎不可能是本意」的路径，不追求穷尽（名单越长，误报越多）。
//
// **必须锚定到根**（盘符 `C:` 或前导分隔符），不能匹配相对路径：`lib`、`bin`、`etc`、
// `var`、`opt`、`dev`、`sys` 在工作区里是极常见的目录名（前端项目几乎必有 `lib`/`bin`），
// 而按本函数契约工作区内的相对目标应判 `inside`、不警告 —— 旧判据（`[\\/]*` 可匹配空串）
// 把 `rm -rf lib` 判成 system，弹窗写「目标是系统目录（lib）—— 删除后系统或软件可能无法启动」，
// 正是注释里说的狼来了。实测旧判据下 `lib`/`bin`/`etc`/`var`/`opt`/`dev`/`sys`/`boot`/
// `lib64`/`sbin`/`usr` 全部误报为 system，而 `src`/`build`/`dist` 正常。
//
// 名单拆两张表，差别只在「要不要前导分隔符」：
//   · 根锚定表 —— 含 `etc`/`usr`/`bin` 这类短通用名。它们**只有落在根下**
//     才是系统目录（`/etc`、`C:\Windows`），作为相对路径则是普通项目目录。
//   · BARE 表 —— 只收「在项目里几乎不可能出现的独特名」。
//     既有测试 L11 要求 `Windows\System32` 判 system，而 `Windows` 不会是一个项目目录名，
//     故这类名字不必要求前导分隔符；`lib`/`etc` 则必须要求。
//
// ── 名单必须按**操作系统**分开，不能混在一张表里 ──────────────────────────────
//
// 曾经把两套系统的名字混装在一张表里，于是两个方向都错：
//   · Linux/macOS 上 `C:\Windows`、`C:\Program Files` 被判 system ——
//     它们在 POSIX 上只是「名字里带反斜杠和冒号」的普通相对路径，根本不是系统目录（误报）。
//   · Windows 上 `/etc`、`/usr` 被判 system —— 它们在 Windows 上是「当前盘根下的 etc」，
//     同样不是系统目录（误报）。
// 混装的代价是双向误报。
//
// 平台由调用方通过 `opts.platform` 传入（'win32' | 'posix'）。**这是必须显式传的信息**：
// 本模块是纯解析器（不访问 process），且**方言不等于平台** —— Linux 上跑 PowerShell Core
// （pwsh 工具）时路径仍是 POSIX 的 `/etc`，把方言当平台会让 `/etc` 被当成 cmd 开关而静默。
// 平台未知（旧调用方/测试）时**两张表都查**：宁可多警告，不可漏警告（方向 fail-safe）。
const WIN_SYSTEM_ROOT_RE = /^(?:[a-z]:)?[\\/]+(?:windows|winnt|program files(?: \(x86\))?|programdata|system32|syswow64|applications|recovery|perflogs|\$recycle\.bin)(?:[\\/]|$)/i
const WIN_SYSTEM_BARE_RE = /^(?:windows|winnt|program files(?: \(x86\))?|programdata|system32|syswow64|applications|recovery|perflogs|\$recycle\.bin)(?:[\\/]|$)/i
// POSIX 系统目录：只收「删了必然出大事」的根级目录。
// **不含 `home` / `Users`** —— 它们不是系统目录本身，而是「用户目录的父目录」，
// 与 Windows 的 `C:\Users` 同理：删 `C:\Users` 是大事，但 `C:\Users\me\code\proj\build`
// 只是工作区内的一个目录。把它们整片收进名单会让「工作区位于家目录下」这一常态
// （Linux 的 `/home/<user>/...`、macOS 的 `/Users/<user>/...`）**所有工作区内绝对路径**
// 都被误报成 system —— 实测 `rm -rf /home/u/code/webapp/build` 曾被判 system，
// 而同样目标写成 `./build` 就是 inside，即同一件事因写法不同结论相反。
// 家目录**本身**由 home 档负责（`~` / userHome 比对），不需要系统目录名单来兜。
const POSIX_SYSTEM_ROOT_RE = /^\/(?:etc|usr|bin|sbin|lib|lib64|lib32|boot|dev|proc|sys|var|opt|root|srv|mnt|media|run|private)(?:[\\/]|$)/i

// `users` / `documents and settings` 单独收窄到「根 + 至多一层」：
//   `C:\Users`、`C:\Users\me` 是删用户配置，算系统级；
//   但 `C:\Users\me\code\proj\node_modules` 只是工作区内的一个目录 —— 旧判据把它判成
//   system，而「工作区放在 `C:/Users/<user>/` 下」是 Windows 上的常态，于是工作区内
//   **所有绝对路径**都被误报（实测 `rm -rf C:/Users/x/code/webapp/node_modules` → system，
//   而同样目标写成 `./node_modules` → inside，即同一件事因为写法不同结论相反）。
const USER_ROOT_RE = /^(?:[a-z]:)?[\\/]+(?:users|documents and settings)(?:[\\/][^\\/]+)?[\\/]?$/i

/**
 * 该路径是否落在**当前操作系统**的系统目录名单里。
 *
 * @param {string} p 已归一为 `/` 分隔、去掉尾部分隔符的路径
 * @param {string|undefined} platform 'win32' | 'posix'；未知时两张表都查（fail-safe）
 */
function isSystemDir(p, platform) {
  const bare = p.replace(/^[a-z]:/i, '').replace(/^\/+/, '')
  if (platform === 'win32') return WIN_SYSTEM_ROOT_RE.test(p) || WIN_SYSTEM_BARE_RE.test(bare) || USER_ROOT_RE.test(p)
  if (platform === 'posix') return POSIX_SYSTEM_ROOT_RE.test(p)
  // 未知：两张表都查 + Windows 的 users 收窄表，最大化警告覆盖
  return WIN_SYSTEM_ROOT_RE.test(p) || WIN_SYSTEM_BARE_RE.test(bare)
    || POSIX_SYSTEM_ROOT_RE.test(p) || USER_ROOT_RE.test(p)
}

/**
 * 段首**命令名**（剥掉 wrapper 链与提权前缀链）—— 供 `isCmdStyleSwitch` 的命令域判据用。
 *
 * 为什么不能用 `w[0]`：提权前缀（`sudo`/`doas`/…）不在 WRAPPERS 里，`sudo rmdir /s /q`
 * 的 `w[0]` 是 `sudo` —— 按它查命令域会把这条命令判成「不吃 `/x` 的命令」，
 * 于是 `/s` `/q` 被当成路径、凭空造出「目标在工作区外」的假警告。
 * 实测（只看 `w[0]` 的第一版探针）：`sudo reg delete … /f` 判 outside，既有断言红灯。
 * 这是本判据**唯一会静默漏判**的接线点，故必须按命令头位置取名字。
 *
 * 判据统一走 `commandHeadEnd`（与 `blastRadiusOfSegment` 的 skip 同源，见该函数注释），
 * 它已覆盖「提权前缀链 + wrapper 链 + 最终命令名」全部位置：
 *   · 返回 >0 时，命令名就是它吃掉的最后一个词元（`w[headEnd - 1]`）；
 *   · 返回 0 表示首词元既不是前缀也不是破坏性命令（`robocopy …` / `git status …`）。
 *     此时**不能**拿 `w[0]` 当命令名，也不能拿 `unwrapWords` 的结果当 —— 段首还可能是
 *     **语句关键字**（`time` / `!` / `then`…，见 STATEMENT_KEYWORDS），
 *     而 `unwrapWords` 不跳关键字、`segmentLabel` 跳（两者的判据就此分叉）。
 *     故跳关键字后再问一次 `commandHeadEnd`；仍取不到才退回 `segmentLabel`
 *     —— 那是判定侧**实际消费半径判据**的同一份解析。
 *
 * `headEndHint` 让调用方把**已经算过的** `commandHeadEnd` 结果传进来，避免在判定热路径上
 * 把同一趟 O(n) 扫描做两遍（`blastRadiusOfSegment` 等四处都已各自算过一次）。
 *
 * @param {string[]} words 段词元
 * @param {number} [headEndHint] 调用方已算出的 `commandHeadEnd(words)`
 * @returns {string} 小写命令名（认不出时为空串）
 */
function headCommandNameOf(words, headEndHint) {
  const w = Array.isArray(words) ? words : []
  let headEnd = 0
  if (typeof headEndHint === 'number') headEnd = headEndHint
  else { try { headEnd = commandHeadEnd(w) } catch (e) { headEnd = 0 } }
  if (headEnd > 0) {
    const name = commandNameOf(w[headEnd - 1])
    // `commandHeadEnd` **不认识语句关键字**：`sudo time rm -rf /tmp` 里它吃掉 `sudo` 之后
    // 把 `time` 当成命令名（关键字既不是前缀也不是破坏性命令，走 ② 被一并吃掉），
    // 于是门控又查到了关键字 —— 与段首形态同一处分叉，只是关键字在提权前缀之后。
    // 关键字**永远不是可执行命令名**（见 STATEMENT_KEYWORDS 的注释），取到它即说明
    // 命令头多吃了词元，真命令名在它之后，故落回下面的关键字重解析而不是返回它。
    //
    // **前缀名同样不是命令名**，此处一并拒收：`commandHeadEnd` 在 `su` / `runas` 上会
    // **停在提权名本身**（它们的值可能是命令也可能是目标，见 PRIV_VALUE_IS_COMMAND），
    // 于是 `w[headEnd - 1]` 就是 `su`/`runas`。返回它等于把 `isCmdStyleSwitch` 的命令域
    // 判据钉在前缀上：实测 `su robocopy X:\ws\a X:\ws\b /mir` 查到 `su` → `/mir` 被当路径
    // → 段级 blast 判 outside（假警告），而 `time su robocopy …` 走的是关键字重解析、
    // 判 null —— **同一形态只因多一个关键字就分叉**，正是本次要堵的那类分叉。
    if (!STATEMENT_KEYWORDS[name] && PRIV_PREFIXES[name] !== 1 && WRAPPERS[name] !== 1
      // ── 提权前缀之后的 `NAME=value` **赋值词元**同样不是命令名 ────────────────────
      // `commandHeadEnd` 的 ② 里，`sawPrefix && !PRIV_VALUE_IS_COMMAND[prevPrefix]` 对
      // `sudo` / `doas` / `pkexec` / `gsudo` **恒真**且**先于** `isTargetEatingNameIn` 命中
      // —— 于是它把前缀之后的**第一个**词元无条件当命令名吃掉，而那个词元可能正是
      // `FOO=1` 这样的赋值前缀。本函数的早退只拒收「关键字 / 前缀 / wrapper」，
      // 赋值词元一概放行 → 返回 `foo=1`。
      //
      // 下游 `isCmdStyleSwitch` 查 `GROUP_OF_LABEL['foo=1']` 不中 → 走「认不出命令名
      // ⇒ 不消费半径」兜底 → `/tmp` 被当 cmd 开关跳过 → 段级 blast 归 null → 档落 inside。
      //
      // 插桩实测：`commandHeadEnd(['sudo','FOO=1','rm','-rf','/tmp'])` = **2**、
      // `headCommandNameOf(…)` = `"foo=1"`（正确值 `"rm"`）。
      //
      // ⚠️ 严重度**带配置条件**（默认 priv=ask 时缺陷被掩盖）：
      //     | 配置                          | `sudo rm -rf /tmp` | `sudo FOO=1 rm -rf /tmp` |
      //     | §6.1 默认（priv=ask）         | ask                | ask（掩盖）              |
      //     | **priv=allow**（§3.3 预期）   | ask                | **allow** ❌             |
      //     | outside=deny + unknown=deny   | deny               | **ask** ❌               |
      // 即用户按计划把 `priv` 设为 allow 后，`sudo FOO=1 rm -rf /tmp`（**多写一个环境变量
      // 赋值**）静默 allow、`blast=null`、弹窗 0 次，`outside` 档被整档绕过。
      // 同口径对拍 HEAD（2744 条叉乘）：CUR 放宽 **0** 条 → 不是本批回归，而是「新增的
      // priv 档可独立放宽后暴露出的既有判据分叉」。
      //
      // 判据复用模块级 `LEAD_ASSIGN` **单点**（与 `unwrapWordsFrom`、`commandHeadEnd`
      // 的前导赋值剥离同源），**不新造正则** —— 三处若各写一份「什么算赋值」必然漂移。
      //
      // ⚠️ 只修这一支：`su root FOO=1` / `runas /user:a FOO=1`（走 `privOperandSkip`
      // 操作数路径）在 HEAD 上同样是 allow，属另一支**既有**缺陷，本轮刻意不修
      // （修它会扩散到 `privOperandSkip`）。
      //
      // ⚠️ 而 wrapper 一族（`nohup`/`nice`/`timeout 5`/`xargs FOO=1 …`）**不能记成
      // 「走 label 侧、与本节无关」**：它的**半径档**恰恰由本节这道守卫与推进循环的
      // `LEAD_ASSIGN` 步（本函数内、见下方那行）**共同**修好 —— 二者缺一即回退
      // （实测：只留守卫删推进步 → `null`；只留推进步删守卫 → 同样 `null`；
      // 两道齐备 → `outside`，与同形无赋值 `nohup time rm -rf /tmp` 一致）。
      // 走 label 侧的只是该族**剩下的那一半**：`segmentLabels` 恒空 ⇒ `tierSetOf` ①
      // 的门控不放开 ⇒ `tiers` 仍为空、`action` 不变 ⇒ `ignored.md:115` 记录的
      // 「wrapper 侧 allow」缺陷**本身仍未修**（详见推进循环那行上方的实测记录）。
      && !LEAD_ASSIGN.test(String(w[headEnd - 1]))) return name
    headEnd -= 1
  }
  // ── 段首（或提权前缀之后）是语句关键字时，命令头在关键字**之后** ────────────────
  // `commandHeadEnd` 从段首起扫，而关键字既不是前缀也不是破坏性命令 → 它返回 0，
  // 于是这里若直接看段首（`w[0]` 或 `unwrapWords` 的结果）就会查到**关键字本身**：
  //     time rm -rf /tmp  → 查到 `time` → 门控判「不是半径组命令、也不是载荷族」
  //     → `/tmp` 被当 cmd 开关 → 段级 blast 归 null → 档位 inside → mode=allow 下**静默放行**。
  // 实测（platform win32、真实宿主档位表）：33 个 STATEMENT_KEYWORDS × 12 个破坏性动词
  // × 6 个单段词 = 1980 条组合**全部** fail-open，而同一形态的 `rm -rf /tmp` 正确 ask。
  // 而 `segmentLabels(['time','rm','-rf','/tmp'])` = `['rm']` —— 半径判据**确实被消费**，
  // 只是门控把它排除在外，故这是「消费侧与门控侧判据分叉」而不是「设计取舍」。
  // 跳关键字后**再问一次 `commandHeadEnd`**（而不是就地取第一个非关键字词元）：
  // 关键字之后仍可能是前缀链（`then nohup rm …`、`time sudo rm …`），
  // 只有 `commandHeadEnd` 知道前缀吃到哪儿、哪个词元才是命令名。
  //
  // ── 但只跳关键字不够：跳完落到的可能正是**前缀本身** ──────────────────────────
  // `time sudo rm -rf /tmp` 解出 `start` 指向 `sudo`、`time nohup rm …` 指向 `nohup`，
  // 而前缀**不是命令名** —— 提权前缀本身就在 `DESTRUCTIVE_LABELS` 里（见其「提权」组），
  // wrapper 在 `WRAPPERS` 里。把前缀当命令名交给 `isCmdStyleSwitch` 查命令域，
  // 判据就钉在了前缀上：实测 `time sudo icacls X:\ws\x /grant Users:F` 查到 `sudo`
  // （提权组、不在 `WIN_SLASH_SWITCH_CMDS` 里）→ `/grant` 被当路径 → 段级 blast 由 null
  // 变 **outside**（假警告），而对照的 `sudo icacls … /grant` 正确判 null；
  // `time nohup time icacls … /grant` 查到 `nohup` 同理。
  // 反向也成立：剥完前缀之后可能又是关键字（`time env then taskkill …` 的 `then`）——
  // 故两者必须**交替推进**，直到落在「既不是关键字、也不是前缀」的词元上，
  // 那才是命令头位置上的命令名。
  //
  // 剥前缀复用 `skipPrefixArgs`（与 `commandHeadEnd` 的 ① 分支**同源**，不另写一份剥法）——
  // 否则「门控查到的命令名」与「判档侧剥掉的命令头」会再次分叉，正是本次缺陷的成因。
  //
  // 收敛性：每轮**至少推进一个词元**（关键字分支取 `found > start`，前缀分支取
  // `next >= start + 1`），故 `guard <= w.length` 不可能漏判。
  let start = headEnd
  for (let guard = 0; guard <= w.length && start < w.length; guard += 1) {
    // 含空白的词元是**引号包起来的整条命令行**（`su -c "rm -rf /"`），不是命令名 ——
    // 与 `commandHeadEnd` 同判据，交回下面的兜底（它按子命令行递归判档）。
    if (/\s/.test(String(w[start]))) break
    const head = commandNameOf(w[start])
    if (!head) break
    if (STATEMENT_KEYWORDS[head]) {
      // ── 关键字**自身的选项**必须先跨过（`time -p <cmd>` 的 `-p`）────────────────────
      // 只取「第一个有效词元」时 `-p` 会当上命令名，而它不是命令名 —— 门控于是把命令域
      // 钉在 `-p` 上：`isCmdStyleSwitch` 查不到组、也认不出载荷族 → 走「按不消费半径处理」
      // 的兜底 → `/tmp` 被当 cmd 开关跳过 → 段级 blast 归 null → 半径档落 `inside`
      // → 大分类 mode=allow 时**静默放行**。而对照的 `time rm -rf /tmp` 正确判
      // `outside|/tmp` —— 同一语义只因多一个 `-p` 就分叉，方向是 **fail-open**。
      // 实测（win32、八档、inside=allow 其余 ask）：`rm -rf /tmp` = ask、
      // `time rm -rf /tmp` = ask、`time -p rm -rf /tmp` = **allow**；
      // 同样放宽的还有 `time -p diskpart` / `time -p parted`（win32 + posix 均放宽）。
      //
      // 推进方式复用 `skipPrefixArgs` —— 与 `segmentLabelFrom` 的关键字分支（`:775`）
      // 和 `pushHeadLabels`（`:1149`）**同源**。三处若各写一份「什么算关键字自己的选项」，
      // 「命令头到哪儿」「命令名是谁」「label 是谁」必然再次分叉，那正是本文件反复要修的
      // 那类缺陷。
      //
      // 只在「关键字紧跟 `-` 开头词元」时才推进：`skipPrefixArgs` 遇到第一个非选项词元
      // 即停，故 `time rm …` / `then nohup rm …` 一族逐字不变（`nx === start + 1`）。
      let nx = start + 1
      try { const s = skipPrefixArgs(w, start + 1, head); if (s > nx) nx = s } catch (e) {}
      let found = -1
      for (let j = (nx > start ? nx : start + 1); j < w.length; j += 1) {
        const t = commandNameOf(w[j])
        if (!t || BAD_LABEL_CHARS.test(t)) continue
        found = j
        break
      }
      if (found < 0) { start = w.length; break }
      start = found
      continue
    }
    // ── 进入下一轮之前：前导 `NAME=value` **不是命令名**，跳过后继续 ─────────────────
    // 上面那个交替循环只在「关键字 / wrapper / 提权前缀」三类上推进，赋值词元一概落到本行
    // —— 若本行直接 `break`，`start` 就停在赋值词元上，下面 `tailEnd` 那一支取到的是赋值
    // 而不是真命令名。
    //
    // 两个入口都命中同一行（故是一条缺陷、不是两条）：
    //   · 前缀之后：`commandHeadEnd(['sudo','FOO=1','time','rm','-rf','/tmp'])` = 2 ——
    //     ② 分支的 `sawPrefix && !PRIV_VALUE_IS_COMMAND['sudo']` 恒真且先于
    //     `isTargetEatingNameIn` 命中，把 `FOO=1` 当命令名吃掉；早退又被 `!LEAD_ASSIGN` 挡住
    //     → `headEnd -= 1` → `start` 正是那个赋值词元；
    //   · 段首前导：`['FOO=1','B=2','time','rm','-rf','/tmp']` 剥掉后 `headEnd = 2`，
    //     `start` 落在 `B=2` 上。两条都返回 `'foo=1'` / `'b=2'`（正确值 `'rm'`）。
    //
    // 下游后果按形态分两半，两半都由本行从根归位：
    //   · `hasNoOperand` 的 BARE 那一半由 `commandHeadEndFull` 的推进循环兜住（闸门有效）；
    //   · **半径档那一半此前无人修**：`blastRadiusOfSegment` 把 `headCommandNameOf` 的结果当
    //     `cmdName` 交给 `isCmdStyleSwitch`，而 `'foo=1'` 在 `GROUP_OF_LABEL` 里查不到 →
    //     走「认不出命令名 ⇒ 不消费半径」兜底 → `/tmp` 被当 cmd 开关跳过 → 段级 blast 归 null。
    //
    // 判据复用模块级 `LEAD_ASSIGN` 单点、与 `commandHeadEndFull` 那行逐字同源
    // （查表 + `test`，无正则新建、无分配）：四处若各写一份「什么算赋值」必然漂移。
    //
    // ⚠️ 修法范围：`su root FOO=1 …` / `runas /user:a FOO=1 …` 走 `privOperandSkip` 操作数
    // 路径，本行对它们零影响；**wrapper 一族**（`nohup`/`nice`/`timeout 5`/`xargs`/`setsid`/
    // `stdbuf`/`ionice`/`command`/`builtin`/`exec`）的半径档恰是被本行修好的，且它不走 label 侧
    // （本行所在的 `headCommandNameOf` 正是 `blastRadiusOfSegment` 取 `cmdName` 的那一处）。
    // 但该族 `segmentLabels` 恒空 ⇒ `tierSetOf` ① 的门控不放开 ⇒ `tiers` 仍为空、`action` 不变。
    // 可见面只有半径档：例外模式面板与弹窗侧（后者只在段仍被判破坏性时才看得到）。
    //
    // 收敛性：每轮 `start += 1` 至少推进一个词元，`guard <= w.length` 不可能死循环。
    if (LEAD_ASSIGN.test(String(w[start]))) { start += 1; continue }
    if (WRAPPERS[head] !== 1 && PRIV_PREFIXES[head] !== 1) break
    let next = start + 1
    try { const nx = skipPrefixArgs(w, start + 1, head); if (nx > next) next = nx } catch (e) {}
    if (next <= start) break
    // `su` / `runas` 的操作数不是命令名，跨过它继续推进 —— 与 `commandHeadEnd` 的 ① 分支
    // **共用同一个推进步**（`privOperandSkip`）。两处若各写一份，命令头与命令名必然分叉，
    // 而分叉的后果实测是 `su root rm -rf /data` 在 priv=allow 下静默放行（见该函数注释）。
    if (next < w.length) { try { next = privOperandSkip(w, head, start + 1, next) } catch (e) {} }
    start = next
  }
  if (start > 0 && start < w.length) {
    // 短路（纯优化）：`w[start]` 本身就在破坏性名单里时，`commandHeadEnd(w.slice(start))`
    // 必然 = 1（首词元既不是关键字也不是前缀 → 第一轮就命中 ② 的 `isDestructiveLabel`，
    // 吃掉该词元后停），故结果恒为 `commandNameOf(w[start])` —— 与下面那趟扫描逐字相同。
    //
    // **这条等价性依赖「`w[start]` 绝不是前缀」这个前提**，而上面那个交替推进循环
    // 恰好保证它（循环只在「既不是关键字、也不是前缀」时退出）。原注释声称的
    // 「`isDestructiveLabel(w[start])` ⇒ `commandHeadEnd` 恒为 1」**并不成立**：
    // 提权前缀本身就在破坏性名单里，而 `commandHeadEnd` 对它们走 ① 的 `skipPrefixArgs`
    // 继续吃 —— 实测 `commandHeadEnd(['sudo','rm','-rf','/tmp'])` = **2**（吃掉 `sudo`
    // **和** `rm`）。这正是本次缺陷的成因：短路在提权前缀上恒命中并**返回前缀本身**，
    // 实测 `headCommandNameOf(['time','sudo','rm','-rf','/tmp'])` 返回 `sudo` 而正确值是 `rm`。
    // 故这里**加显式前缀守卫**，让前提从「上游保证」变成「本处自证」——
    // 即使日后有人改坏了上面的循环，本短路也只会失效（落回扫描）而不会返回前缀。
    // 另必须带 `!/\s/` 守卫：`commandHeadEnd` 对**含空白的词元**一律 break 返回 0
    // （那是引号包起来的整条命令行，见该函数里的说明），而 `commandNameOf('rm ')` 经 trim
    // 仍会得到 `rm` —— 少了这个守卫就在该形态上与它分叉。
    // 收益：`time rm -rf /tmp` 这类最常见形态省掉一次 `slice` + 一趟 `commandHeadEnd`。
    const rawStart = String(w[start])
    const startName = commandNameOf(rawStart)
    if (!/\s/.test(rawStart) && PRIV_PREFIXES[startName] !== 1 && WRAPPERS[startName] !== 1
      && isDestructiveLabel(startName)) return startName
    let tailEnd = 0
    try { tailEnd = commandHeadEnd(w.slice(start)) } catch (e) { tailEnd = 0 }
    if (tailEnd > 0) {
      const tailName = commandNameOf(w[start + tailEnd - 1])
      if (!STATEMENT_KEYWORDS[tailName]) return tailName
    }
    // 关键字/前缀链之后既没有前缀链、也没有破坏性命令名（`time robocopy … /mir`）：
    // 真命令名就是那个位置上的词元 —— 与 `segmentLabel`「跳关键字后取第一个
    // 非关键字词元」同判据（上面那个循环已保证它不是关键字、也不含 BAD_LABEL_CHARS）。
    // **前缀过滤不能省**：`commandHeadEnd` 返回 0 也可能是「首词元是前缀、其后没有命令名」
    // （`timeout 5 sudo` 这类词元被前缀吃光的情形），此时 `w[start]` 是 wrapper / 提权名。
    // 返回它等于把命令域判据钉在前缀上：实测 `time nohup time icacls … /grant` 查到 `nohup`
    // → `/grant` 被当路径 → 段级 blast 由 null 变 outside（假警告）。
    // 滤掉后落下面的兜底（`segmentLabel`，与判定侧同源）。
    const first = commandNameOf(w[start])
    if (first && !STATEMENT_KEYWORDS[first] && !BAD_LABEL_CHARS.test(first)
      && PRIV_PREFIXES[first] !== 1 && WRAPPERS[first] !== 1) return first
  }
  // ── 兜底：与判定侧**同源** ────────────────────────────────────────────────────
  // 走到这里说明命令头没吃到任何前缀或破坏性命令（`robocopy … /mir`、`git status …`、
  // `time robocopy … /mir`）。判据取 `segmentLabel` —— 它就是判定侧消费半径判据时
  // 用的那一份解析，故门控查到的命令名与「实际消费半径判据的 label」**不可能再分叉**。
  // （`unwrapWords` 兜底正是不够的那一份：它不跳语句关键字，而 `segmentLabel` 跳。）
  //
  // **短路（纯优化，不改变结论）**：`segmentLabel` 与 `unwrapWords` 的差异只在
  // 「跳不跳关键字」与「router 要不要取子命令」。下面这个条件恰好是
  // `segmentLabel` **原样返回 `head`** 的那一支（见其 `if (!ROUTER_CMDS[head]) return head`），
  // 此时两者的返回值逐字相同，故可直接返回而省掉 `segmentLabel` 那一趟 ——
  // 它是判定热路径，实测非关键字段上 `segmentLabel` 兜底比 `unwrapWords` 慢 42%。
  // 条件不满足（关键字 / router / 认不出 / opaque）时**一律交给 `segmentLabel` 本体**，
  // 那是同源解析，也是本次修复真正依赖的那一支。
  try {
    const u = unwrapWords(w)
    if (u && !u.opaque && u.words.length) {
      const first = commandNameOf(u.words[0])
      if (first && !BAD_LABEL_CHARS.test(first)
        && !STATEMENT_KEYWORDS[first] && !ROUTER_CMDS[first]) return first
    }
  } catch (e) {}
  try {
    const label = segmentLabel(w)
    if (label) return String(label).split(/\s+/)[0]
  } catch (e) {}
  return w.length ? commandNameOf(w[0]) : ''
}

/**
 * 吃 `/x` 形态开关的**命令域** —— 判据不是「这个词是不是开关」，而是「这条命令吃不吃 `/x`」。
 *
 * ── 为什么必须换判据 ──────────────────────────────────────────────────────────
 * `/x` 与 POSIX 绝对路径在语法上完全同形，唯一的区别是**名字**。而按名字枚举
 * POSIX 路径在原理上不可能收敛：实测**任意** `/` + 字母的单段词都命中开关判据
 * （`/myapp` `/backup` `/logs` `/zzz` `/notaswitch` 全部被判开关），
 * 故「POSIX 系统目录名单」只是把漏报从几个名字缩到「除名单外全部」——
 * `rm -rf /tmp` 静默放行，而 `rm -rf /etc` 弹窗：同一类操作只因名字不同，一个静默一个询问。
 * `/tmp` 在 Windows 上是**真的会删东西**的（Git Bash 方言下它映射到真实 `%TEMP%`）。
 *
 * 反过来，按开关名枚举同样无界（短开关 26+、长开关 20+，第三方安装器还在增长），
 * 且按合理规模建表会造出 `schtasks /create`、`compact /c`、`cipher /w` 三条新的假警告。
 *
 * 有界的那一侧是**命令域**：`rm`/`chmod`/`shred`/`find`/`dd` 是 POSIX 命令，
 * **没有** `/x` 形态的选项，其 `/x` 实参必是路径；`rmdir`/`del`/`icacls`/`format`/
 * `diskpart` 是 Windows 原生命令，`/x` 是开关。本表就是后者的名单。
 *
 * ── 为什么这张表是有界的 ──────────────────────────────────────────────────────
 * 本判据只在**半径判据真正被消费**的命令上生效（见 `isCmdStyleSwitch` 的 ④），
 * 而那些命令来自 `DESTRUCTIVE_LABELS`（40 项）与载荷族 —— 两者都是固定的小集合。
 * 实测 `DESTRUCTIVE_LABELS` ∩ 吃 `/x` 的命令恰好就是下面这些，无一遗漏、无一多余。
 *
 * **双向一致由测试断言守住**：本表每一项都必须在 `DESTRUCTIVE_LABELS` 里 ——
 * 往表里塞无关命令会让断言红灯（与 `GROUP_MEMBERS` 那条纪律同源）。
 *
 * 刻意**不在表里**：`taskkill` / `shutdown` / `stop-computer` / `reg delete` / `wmic`。
 * 它们走**组档**（proc/power/reg），`tierSetOf` 里 blast 恒 null、不消费本判据 ——
 * 列进来只会让「表 = 吃 /x 的破坏性命令」这句话失真。
 */
export const WIN_SLASH_SWITCH_CMDS = dict({
  rmdir: 1, rd: 1, del: 1, erase: 1, format: 1, diskpart: 1, fdisk: 1, icacls: 1, takeown: 1, runas: 1,
})

/**
 * 该词元是否为 cmd 风格的 `/x` 开关（`/s` `/q` `/grant` `/pid`）。
 *
 * **只在 Windows 上成立**：POSIX 上 `/etc`、`/usr/bin` 是路径，不是开关。按方言判会让
 * Linux 上跑 PowerShell Core 时的 `/etc` 被当开关跳过、段级 blast 静默。
 *
 * 平台未知时**不跳**（返回 false）：把路径当开关会漏掉警告（静默），把开关当路径最多
 * 多一条警告 —— 两者代价不对称，故未知时选后者。
 *
 * Windows 上 `/Windows`、`/ProgramData`、`/Users` 是当前盘根的绝对路径，与 cmd 开关
 * 在语法上完全同形 —— 无条件按开关跳过会把最该警告的目标整个吃掉。故判据收窄为四道：
 *   ① POSIX 系统目录名单里的项不是开关（`/etc`、`/usr`…），复用 `POSIX_SYSTEM_ROOT_RE`；
 *   ② 含第二段的 `/a/b` 不是开关（cmd 开关是单段词）；只把 `/` 算分段符，
 *      `/user:DOMAIN\admin` 是 runas 的真开关；
 *   ③ 1–2 字母的短开关（`/s` `/q` `/f` `/im`）与命令无关，是保住既有断言的取舍；
 *   ④ 3+ 字母的 `/x` 取决于**这条命令吃不吃 `/x`**（见 `WIN_SLASH_SWITCH_CMDS`）。
 *
 * 已知残余：`/x` 单字母形态（③ 的取舍）。
 *
 * @param {string} token 待判词元
 * @param {object} [opts] 判档选项（只读 `platform`）
 * @param {string} [cmdName] 段首命令名（小写，见 `headCommandNameOf`）——
 *   缺省时按「不是命令域成员」处理（多一条可见警告，方向 fail-safe）
 */
function isCmdStyleSwitch(token, opts, cmdName) {
  if (token.charCodeAt(0) !== 47) return false
  if (!/[a-z]/i.test(token.charAt(1))) return false      // `/` 与 `/*` 是路径，不是开关
  if (!(opts && opts.platform === 'win32')) return false // 只在明确是 Windows 时才当开关
  const slashed = token.replace(/\\/g, '/')
  // `/Windows`、`/ProgramData` 是当前盘根下的系统目录，不是开关：交回判档。
  if (isSystemDir(slashed, 'win32')) return false
  // ① POSIX 系统目录名同样不是开关（判据与 isSystemDir 的 posix 分支同源，不手抄名单）
  if (POSIX_SYSTEM_ROOT_RE.test(slashed)) return false
  // ② 含第二段的不是开关：cmd 开关是单段词
  if (token.indexOf('/', 1) !== -1) return false
  // ③ 1–2 字母的短开关与命令无关（保住既有断言 `seg(['rm','-rf','/s']) === null`）——
  //    单个字母的 POSIX 根目录实践中不存在，代价可接受，是**有意**保留的残余。
  if (/^\/[a-z]{1,2}$/i.test(token)) return true
  // ④ 命令域判据：命令名不在表里 → 不是开关 → 交回判档（`rm -rf /tmp` 的 `/tmp` 是路径）。
  //    只对**半径判据真正被消费**的命令生效（半径组的破坏性命令 + 载荷族）：
  //    其余命令（`robocopy` / `net` / `taskkill` / `wmic` …）的 `/x` 一律照旧当开关，
  //    否则 `robocopy … /mir`、`net user … /delete` 会被当路径、凭空造出假警告（实测）。
  //    认不出命令名时按「不消费半径」处理，方向 fail-safe。
  const grp = GROUP_OF_LABEL[cmdName]
  if (!(grp && RADIUS_GROUPS[grp] === 1) && !isPayloadCarrierLabel(cmdName)) return true
  return !!WIN_SLASH_SWITCH_CMDS[cmdName]
}

// 爆炸半径档位的**严重度顺序**（越小越严重）—— 全模块唯一一份，index.js 直接引用
// （曾经在 index.js 里手抄一份，键集合已经不同，且消费方式是「未知档静默跳过」）。
// broad = 例外模式的目标是不可判定的顶层通配（`rm -rf *`），它能匹配到盘根，
// 故排在 system 之前、drive-root 之后。
// 爆炸半径档位的**严重度顺序**（越小越严重）—— 全模块唯一一份，index.js 直接引用
// （曾经在 index.js 里手抄一份，键集合已经不同，且消费方式是「未知档静默跳过」）。
//
// 各档的位置理由：
//   drive-root      最严重：整个盘
//   workspace-root  整个项目 —— 比盘根轻，比其余都重（`rm -rf .` 删掉的是这个仓库）
//   broad           规则可能匹配盘根（覆盖面已知但极宽）—— 一条 `rm -rf *`=allow 实测
//                   能放行 `rm -rf /`
//   unknown         目标**读不出**（覆盖面未知）—— 与 broad 同类，紧随其后。
//                   它排在这里而不是「按最轻处理」：读不出后果的操作必须问，
//                   与 `rm -rf $TARGET` 的真实覆盖面可能是任意路径是同一件事。
//   system/home/outside  明确的越界目标（知道自己在删什么，只是不该删）
//   inside          工作区内，不警告
//
// `unknown` 与 `broad` 的先后只影响 worstBlast 显示取哪一条，两者极少同时出现。
export const BLAST_ORDER = {
  'drive-root': 0, 'workspace-root': 1, broad: 2, unknown: 3,
  system: 4, home: 5, outside: 6, inside: 7,
}

// ── 档位（tier）：把「伤害落在哪」与「命令属于哪一类」合成一张可配置的表 ──────────
//
// 八个档 = **半径档 ∪ 组档**（见 GROUP_MEMBERS 的注释）。两侧判据不同，各用各的：
//   半径档 —— 看目标范围（`rm -rf ./build` 是 inside，`rm -rf /etc` 是 wide）
//   组档   —— 看命令属于哪一组（`kill` 恒 proc，与目标无关，因为半径判据对它恒 null）
//
// **不在多处 if/else 里重复组 → 档的映射**：那是 GROUP_OF_LABEL / GROUP_TIER 两个单点的职责，
// 理由与 BLAST_ORDER 的既有纪律一致（曾在三处手抄，漂移时消费侧静默跳过）。

/** 全部档位名（固定顺序见 TIER_ORDER）。宿主与客户端都按这份清单下发/渲染。 */
export const TIERS = ['inside', 'outside', 'wide', 'unknown', 'proc', 'power', 'priv', 'reg']

/**
 * 档位的**固定顺序**（排序键，**不是严重度**）。
 *
 * 为什么必须固定而不能「按严格度排序」：严格度取决于**用户的配置动作**，而配置是变的：
 *     用户 A: wide=ask,  priv=deny  → 最严是 priv → ['priv','wide']
 *     用户 B: wide=deny, priv=ask   → 最严是 wide → ['wide','priv']
 *     用户 C: wide=ask,  priv=ask   → 同严 → 顺序无定义
 * 同一份代码在三个用户那里给出三种顺序，`assert(tiers[0] === 'wide')` 会随机失败，
 * 而 UI 的渲染顺序会随配置抖动。
 *
 * **排序键是档位名，不是 blast level**：半径侧的五个 level
 * （`drive-root` / `workspace-root` / `broad` / `home` / `system`）经 `radiusTierOf`
 * **合并成同一个 `wide` 档** —— 档位是「用户能分别配置的粒度」，而盘根与系统目录
 * 在配置上是同一个开关（拆开会让面板多出四个用户无从选择的选项）。
 * 严重度的区分留在 `blast` 字段里（弹窗文案按 level 分档显示），不进入 `tiers`。
 *
 * 顺序 = 半径档（按 BLAST_ORDER 严重度降序，合并后去重）+ 组档（固定次序）。
 * **必须写清「顺序不代表严重度」**：`['proc','priv']` 不表示 proc 比 priv 严重，
 * 只是 proc 在排序键里靠前。真正决定动作的是**用户配置 + 取最严**
 * （strictestTierAction），与 tiers 的排列顺序无关。
 */
export const TIER_ORDER = [
  'wide', 'unknown', 'outside', 'inside',      // 半径档
  'proc', 'power', 'priv', 'reg',              // 组档（固定次序）
]

/** 排序键（越小越靠前）。与 TIER_ORDER 同源，不另写一份下标表。 */
const TIER_RANK = (() => {
  const m = Object.create(null)
  for (let i = 0; i < TIER_ORDER.length; i += 1) m[TIER_ORDER[i]] = i
  return m
})()

/**
 * 半径档：blast level → tier。
 *
 * | blast level | tier |
 * |---|---|
 * | `inside` | `inside` |
 * | `outside` | `outside` |
 * | `home` / `system` / `drive-root` / `workspace-root` / `broad` | `wide` |
 * | `unknown` | `unknown` |
 * | `null` | 无目标 → `inside`（见下） |
 *
 * `null` 归 `inside` 的理由：它表示「这一段没有路径目标」（`rm` 裸跑报错、
 * `rm test.txt` 的目标在工作区内），不是「读不出」—— 读不出已经由
 * `blastRadiusOfSegment` 改判成 `unknown` level 了。两者在 §4 之前是同一个 `null`，
 * 分开之后这条映射才是正确的。
 *
 * `broad` 归 `wide` 而不是单列一档：它是**例外模式**的档位（`rm -rf *` 这条规则覆盖到盘根），
 * 而例外不是「一段命令」，没有「这一段该用哪档」的问题。段级永远拿不到 broad。
 */
export function radiusTierOf(blast) {
  if (!blast || !blast.level) return 'inside'
  const l = blast.level
  if (l === 'inside') return 'inside'
  if (l === 'outside') return 'outside'
  if (l === 'unknown') return 'unknown'
  // home / system / drive-root / workspace-root / broad：都是「范围大到不该默认放行」
  return 'wide'
}

/**
 * 组档：label 集合 → 命中的全部组档（已排序、去重）。
 *
 * 判据用 **`segmentLabels`**（不是主 label）—— 与 `isDestructiveSegment` 同源，
 * 于是 `find . -exec kill {} ;` 这类间接形态也能识别。
 *
 * 一个段可以命中多个组档（实测 `sudo kill 1234` → priv + proc、`sudo reg delete` → priv + reg），
 * 故返回集合。
 */
export function groupTiersOf(labels) {
  const list = Array.isArray(labels) ? labels : []
  const out = []
  for (const l of list) {
    const g = GROUP_OF_LABEL[String(l == null ? '' : l).trim().toLowerCase()]
    if (!g) continue
    const t = GROUP_TIER[g]
    if (t && out.indexOf(t) === -1) out.push(t)
  }
  return out
}

/**
 * 「**半径侧读不出**」时该并入的档位集合 —— **单一实现**，两个调用方共用：
 *
 *   · `assessCommand` 的整行读不懂分支 —— 连段边界都定不了、根本没有词元；
 *   · `tierSetOf` ① 里「破坏性命令本身藏在 opaque 构造里」那一族
 *     （守卫是 `destructiveHeadReadable`）。
 *
 * 两处的处境相同：**半径侧没有任何结论**。而「读不出」既可能落在工作区内、也可能落在
 * 盘根，故 `inside` / `wide` / `unknown` **同时**参与「取最严」—— 读不出半径不等于半径安全。
 *
 * ⚠️ `inside` **必须在集合里**：整行分支早已并它，而段级 opaque 支一度只并 `wide ∪ unknown`
 * —— 于是同一个「目标读不出」在两条路径上给出两个答案：用户显式配的 `inside=deny`
 * 在段级路径上被静默丢弃（`echo a | (rm -rf ./build)` 由 deny 变 allow）。
 *
 * ⚠️ 提成单点是为了消除**同一句「读不出」在两个路径上给出两个答案**的分叉：否则用户显式配的
 * `wide=deny` 会在段级路径上被静默丢弃（fail-open）。
 *
 * ⚠️ **不是「凡 opaque 段都并这三档」**：命令可读、构造只是参数的那一族
 * （`rm -rf ./tmp/{a,b,c}`：段首 label 是 `rm`）半径判据已按可读前缀判过档，
 * 并 `wide` 等于把已知结论抬成「可能很大」，是凭空收紧。
 */
const RADIUS_TIERS_WHEN_UNREADABLE = ['wide', 'unknown', 'inside']

/**
 * 段首的**主 label** 是否读得出一个破坏性命令名 —— 「真命令在段内、还是藏在构造里」。
 *
 * 与「目标读不出」是**两个不同的问题**，判据必须分开（见 `tierSetOf` ① 的说明）：
 *   · 读得出（`rm -rf ./tmp/{a,b,c}` 的 label 是 `rm`）—— 命令可读，构造只是**参数**，
 *     半径判据已按可读前缀（`./tmp/`）判过档。并 `wide` 等于把已知结论抬成「可能很大」，
 *     是凭空收紧，60g ④b/⑤b 把这一族（合法常用命令）钉死为「只有 `unknown`」。
 *   · 读不出（`(rm -rf C:/Windows)` / `` `rm -rf C:/Windows` `` /
 *     `{ Remove-Item C:/Windows -Recurse -Force }`：`words` 里连命令名都没留下）——
 *     真命令在构造里，半径侧**没有**任何结论。
 *
 * ⚠️ 判据用 `segmentLabel`（**主 label**）而不是 `segmentLabels`：后者会为
 * `find -exec rm {} +` 合成 `rm` 这种**间接** label，而那一族的词元齐全、半径判据正常
 * 工作（`find` 的路径目标可判），不属于本判据要覆盖的形态。
 *
 * ⚠️ **提权前缀必须单独排除**：`sudo` / `doas` / `su` / `pkexec` /
 * `runas` / `gsudo` **六个名字全部在 `DESTRUCTIVE_LABELS` 里**（那一行的注释明禁把它们
 * 移出名单，见 `assessCommand` 的 `priv` 分支），于是「提权前缀 + 真命令藏在 opaque 构造里」
 * 会被本判据误判成「命令可读」→ 走 `else` 支只并 `unknown` → 用户显式配的
 * `wide=deny` / `inside=deny` 被静默丢弃。
 *
 * 语义上提权前缀**不是命令头**：它只是权限包装，段首读出 `sudo` 恰恰说明**真命令在别处**
 * （`sudo $(rm -rf C:/Windows)` 的真命令在构造里）。故 `PRIV_PREFIXES[head] === 1` 时必须
 * 返回「读不出」——这与 `commandHeadEnd` 穿过提权前缀取真命令头是同一条口径。
 *
 * 实测（`wide=deny` + 其余七档 allow）：`echo a | sudo $(rm -rf C:/Windows)` 由
 * **allow**（tiers=`['unknown','priv']`）变 **deny**（tiers=`['wide','unknown','inside','priv']`）；
 * 而 `sudo rm -rf /etc` 与 `sudo ls` 逐字不变（它们的 `head` 是 `sudo`，但 `seg.opaque`
 * 为空 / `blast` 已有结论，走不到本守卫）。
 *
 * ⚠️ **`:4932` 那条提权兜底不可删**（发现 8 的报告者建议删掉它，实测会让
 * `sudo $(rm -rf C:/Windows)` 由 deny 变 **allow**）：`sudo` 本身就在 `DESTRUCTIVE_LABELS`
 * 里，故「段首是提权前缀、真命令在构造里」这一格只有它能挡住。它承重，不是冗余。
 *
 * ── 判据问的是「**opaque 构造自己有没有藏一个破坏性命令**」─────────────
 * 本函数此前问的是「**段首**是不是破坏性命令」，于是「段首本身是破坏性命令、而构造里
 * **另有一个**真破坏性命令」这一族判错：`echo a | rm -rf /tmp/x $(rm -rf /)` 的段首 label
 * 确实是 `rm`，判据说「命令可读」→ 走 `else` 支只并 `unknown` → 用户显式配的 `wide=deny`
 * 与 `inside=deny` 静默消失（实测 tiers=`['unknown','outside']`，**allow**）。
 *
 * ⚠️ 而这一格在 bash 里 `-n` = OK、**可执行**，`$(rm -rf /)` 真会跑。故它不是「构造只是参数」，
 * 而是**两个破坏性命令**：段首那个可读、构造里那个读不出。判据必须把两者**都**问一遍 ——
 * 只问段首就会漏掉后半句，只问构造就会把 `rm -rf ./build $(date)`（构造里是 `date`）
 * 一起误伤（60g ④b/⑤b 把它钉死为「恰好 `['unknown']`」）。
 *
 * ⚠️ **换 label 取法修不好这一格**：靶格的 `headCommandNameOf` 与 `segmentLabel` 同值
 * （都是 `rm`）—— 病因不在「取哪个 label」，而在**问错了问题**。故本判据=「段首可读
 * **且**构造里没有第二个破坏性命令名」。
 *
 * 构造原文由词法器按块记在 `seg.opaqueTexts`（见该字段的说明）：判定侧若拿 `seg.text`
 * 自己反推「哪段是构造」，就是同一份知识写两遍 —— 那正是本文件反复要修的那类分叉。
 *
 * @param {{words?: string[], opaqueTexts?: string[]}} seg 段
 * @returns {boolean} 段首 label 确实是破坏性命令名、且 opaque 构造里没有另一个时为真
 */
function destructiveHeadReadable(seg) {
  const w = seg && Array.isArray(seg.words) ? seg.words : []
  let head = ''
  // 判据用 `headCommandNameOf`（穿过提权前缀 / wrapper / 语句关键字取**真命令头**），
  // 不用 `segmentLabel`：后者不跳提权前缀，`segmentLabel(['sudo','rm',…])` = `'sudo'`
  // —— 于是「段首是 `sudo`」被无条件判成「命令读不出」，**即使紧跟其后的就是可读的 `rm`**：
  // `sudo rm -rf ./build $(date)` 由 allow 变 deny（tiers=`['wide','unknown','inside','priv']`），
  // 形态极常见，属误拦。`headCommandNameOf` 是文件里已有的单一来源（它的注释明写必须穿过
  // 提权前缀取真命令头），本判据与它同源后，`sudo rm …` 的 head 就是 `rm`。
  try { head = headCommandNameOf(w) } catch (e) { head = '' }
  // 空 label = 读不出（`(rm -rf /)` 的 `words` 是 `[]`）。
  // ⚠️ 这一行**是冗余的防御**：`isDestructiveLabel('')` 本身就返回 false（它先 `!!l`），
  //    且 `PRIV_PREFIXES` 是 `Object.create(null)` 的字典，`PRIV_PREFIXES['']` 是
  //    `undefined` 而非 `1`。保留它是为了让「空 label 算读不出」这条语义在**本函数里**
  //    显式可见（不依赖被调函数的内部实现），实测去掉它行为完全不变（变异测试无红灯）。
  if (!head) return false
  // 提权前缀不是命令头 —— 真命令在它后面（可能在 opaque 构造里）。
  if (PRIV_PREFIXES[head] === 1) return false
  // ── 段首那个**不是**真载荷：opaque 构造里另有破坏性命令 ────────────────────────────
  // 逐块问「这一块构造自己有没有藏一个破坏性命令」。命中即返回「读不出」——语义是
  // **段首那个可读的破坏性命令不是全部载荷**，构造里还有一个读不出的。
  //
  // ⚠️ 只对**构造原文**取 `rawCommandNames`，不整段取：整段取会把段首那个命令名本身
  // 也算进来（`rm -rf ./build $(date)` 的原文里就有 `rm`），于是**每一格**都命中、
  // 承重格 `rm -rf ./tmp/{a,b,c}` 被误伤成 `['wide','unknown','inside']`（60g ④b/⑤b 红灯）。
  // 判据必须问「构造**里**」，不能问「段里」—— 这正是发现 1 的病根（问错了范围）。
  //
  // ⚠️ `opaqueTexts` 缺席时（旧调用方 / 手搓的 `seg` 字面量）本判据**整个不生效**，
  // 退化为改动前的行为（只问段首）—— 方向是保守而非放宽。生产调用点已补传（见
  // `assessCommand` 的 `tierSetOf` 调用），故真实路径上恒生效。
  const texts = seg && Array.isArray(seg.opaqueTexts) ? seg.opaqueTexts : null
  if (texts) {
    // 方言取自词元数组上的戳（`SEG_SHELL`）：本函数只拿到 `seg`，而 `seg.words` 是词法器
    // 盖过戳的那一份（生产路径恒如此）。不传方言会让 pwsh 侧构造里的靶形态按 bash 判
    // ⇒ 认不出真命令 ⇒ 本判据误判「段首就是全部载荷」（fail-open，见 `rawCommandNamesWithShell`）。
    const segSh = shellOfWords(w)
    for (const raw of texts) {
      let names = null
      try { names = segSh === 'pwsh' ? rawCommandNamesWithShell(raw, segSh) : rawCommandNames(raw) } catch (e) { names = null }
      if (!names) continue
      for (const n of names) { if (isDestructiveLabel(n)) return false }
    }
  }
  return isDestructiveLabel(head)
}

/**
 * 档位集合的**固定顺序**（`TIER_RANK` 的**唯一**比较实现）。
 *
 * 三个产出点共用它：`tierSetOf`、`assessCommand` 的整行读不懂分支，
 * 以及 `tierVerdict` 里「并列在最严档上的其余命中档」那一次排序。
 * 后两处曾经各自**手抄**了一份逐字相同的比较函数 —— 而 `decisiveTierOf` 的稳定性论证
 * 依赖「`tiers` 已按 `TIER_RANK` 排过」，抄漏一处的后果是**动作不变、拒绝理由随书写
 * 形态漂移**；`tierVerdict` 那一份更直接：它就是用户看到的拒绝理由。
 * 三处现在只剩这一个比较实现（发现 5 的修法：把 `tierVerdict` 的副本也换成本函数）。
 *
 * 原地排序并返回同一数组（调用方都要的就是排好序的那一份）。
 */
function sortTiersByRank(tiers) {
  return tiers.sort((a, b) => {
    const ra = TIER_RANK[a]
    const rb = TIER_RANK[b]
    return (ra === undefined ? 99 : ra) - (rb === undefined ? 99 : rb)
  })
}

/**
 * 该段命中的**全部档位**（半径档 ∪ 组档），按 TIER_ORDER 排序。
 *
 * 组合规则（§3.3）：
 *     档位集合 = 半径档(blast，仅当该组的判据是半径) ∪ 组档(label 所属组) ∪ (priv ? {'priv'} : {})
 *
 * 三处细节：
 *   · **半径档只在需要时算**：`proc`/`power`/`reg` 三组的 blast 恒 null，算出来只会是
 *     `inside` —— 把它并进去等于给 `kill 1234` 白送一个 inside 档，而 `inside` 是
 *     「跟随大分类」的那一档，混进来会让「命中档位」这句话失去意义（每个段都命中 inside）。
 *     判据 = 该段的**任一** label 属于半径组（`RADIUS_GROUPS`）。
 *     ⚠️ **这个门控只管「半径档并还是不并」，不管 `unknown`** —— 两条口径互相独立：
 *     半径档回答「目标在区内/区外」，`unknown` 回答「后果读不出」。此前 `unknown` 的
 *     三条产出判据被写在门控**之内**，于是**纯组档段**（段内无 del/disk/perm/priv 组
 *     label）整段跳过它们 —— 同一条「目标读不出」的结论，只因命令属组档就静默 allow。
 *     实测（`unknown=deny`、其余七档 allow，修复前）：
 *         kill $T / shutdown $T / reg delete $T /f / taskkill /pid $T
 *         pkill / killall / reboot / halt / poweroff / stop-computer / stop-process / wmic
 *         (kill 1234) / kill $(cat p) / shutdown $(date)   → **全部 allow**（tiers 只有组档）
 *         对照 sudo kill $T → deny（tiers=['unknown','proc','priv']）、rm -rf $T → deny
 *     方向 fail-open，且是「同一语义两个结论」的不变量分叉。故门控外**必须**照常
 *     求值那三条判据 —— 见 ① 的 `else` 分支。
 *   · **`priv` 档另算**：提权前缀可能不出现在 labels 里（`su`/`runas` 的 segmentLabels
 *     扩展被刻意排除），故用 `segmentPrivilege` 的**位置判据**兜底。
 *     `sudo ls` 的 labels 是 ['sudo','ls']（扩展后），`sudo` 在 priv 组里，两条路都命中；
 *     而 `su -c "rm -rf /"` 的 label 是 `su`（也在 priv 组里）。两条路互为冗余而非重复 ——
 *     冗余的那一侧（位置判据）覆盖的是 `segmentLabels` 刻意不扩展的形态。
 *   · **`unknown` 覆盖半径档**：`diskpart` 裸跑 / `set-executionpolicy` / `diskpart /s <脚本>`
 *     的半径判据**覆盖不到**（前者进交互、后两者实参不是路径），它们的 `blast` 也是 null，
 *     但含义不是「目标在区内」而是「后果读不出」。故这一支**替换**半径档而不是叠加 ——
 *     叠加会同时给出 `inside`（等于宣称无害）与 `unknown`（宣称读不出），自相矛盾。
 *
 * @param {{words: string[], blast?: object|null, opaque?: string|null}} seg 段（blast 由调用方算好）
 *   `opaque` 是词法器给出的「这一段里有读不懂的构造」标记（`decomposeCommand` 的段字段），
 *   必须一并传入 —— 见 ① 的 opaque 分支：漏传它会让「目标被 opaque 构造吞掉」重新变回 `inside`。
 * @param {string[]} labels segmentLabels(seg.words) 的结果
 * @param {object} [opts] 判档选项（`isCmdStyleSwitch` 判 cmd 开关需要 platform）
 */
export function tierSetOf(seg, labels, opts) {
  const list = Array.isArray(labels) ? labels : []
  const set = []
  const add = (t) => { if (t && set.indexOf(t) === -1) set.push(t) }
  // ① 半径档。**两种「并」法**，取决于段内是哪种半径组：
  //
  //   · 段内有**纯半径组**（del / disk / perm）的 label → **恒并**，`null` 按 §5.1 归 `inside`。
  //     这三种命令的判据**就是**目标范围，`null` 的含义是「判过档、目标在区内」
  //     （`rm -rf ./build` 实测 null），故 `inside` 是对它唯一正确的档。
  //
  //   · 段内**只有提权**（priv 组）→ **仅在 `blast` 非 null 时并**。提权的半径档来自
  //     **内部命令**的目标（`sudo rm -rf /etc` 的 system 来自 /etc，不是来自 sudo），
  //     没有可判目标时半径判据应当**弃权**，而不是并一个 `inside`：
  //     `inside` 是关于**目标位置**的断言，而 `sudo ls` 根本没有目标 ——
  //     断言它「目标在区内」等于把「无从判断」说成了「判断为安全」。
  //     计划 §2.3 的实测结论正是这条：「`sudo ls` 只命中 `priv`」，
  //     而 `sudo rm -rf /` 命中 `priv` + `wide`。
  //
  // 这个区分有可观察的行为差异：用户把 `inside` 设为 deny、`priv` 设为 allow 时，
  // `sudo ls` 应当是 allow（用户显式放行了提权），而不是被一个凭空多出来的 `inside` 档拒绝。
  let hasPureRadius = false
  let hasPrivGroup = false
  for (const l of list) {
    const g = GROUP_OF_LABEL[String(l == null ? '' : l).trim().toLowerCase()]
    if (!g || RADIUS_GROUPS[g] !== 1) continue
    if (g === 'priv') hasPrivGroup = true
    else hasPureRadius = true
  }
  // ── 门控的第三个合取项：**破坏性命令藏在 opaque 构造里**──────────────
  // 前两项都只覆盖「半径组 label」：`hasPureRadius` 要求段内有 del/disk/perm 组的 label，
  // `hasPrivGroup` 要求有 priv 组。而**纯组档段**（`kill` / `pkill` / `reboot` / `shutdown` /
  // `taskkill` / `stop-computer` / `reg delete` / `stop-process`）的 `GROUP_OF_LABEL` 是
  // `proc` / `power` / `reg` —— **既非 pureRadius 也非 privGroup**，于是整个门控不进入，
  // 下面那个 `opaqueHiddenPayload` 守卫**从不被求值**，同一条「真命令藏在构造里」的结论
  // 只因命令属组档就静默 allow（fail-open）。
  //
  // 实测（`wide=deny` + 其余七档 allow，修复前）：
  //     echo a | (rm -rf ./build)  → deny tiers=['wide','unknown','inside'] ✅（del 族进门控）
  //     echo a | (kill 1234)       → **allow** tiers=['unknown','proc']      ❌（proc 族被跳过）
  //     echo a | (reboot)          → **allow** tiers=['unknown','power']     ❌
  //     echo a | (reg delete HKCU\\X /f) → **allow** tiers=['unknown','reg'] ❌
  // 可达面 = 8 个组档命令 × `|` / `&&` / `||` / `&` 四种分隔符。
  //
  // ⚠️ 第三个合取项**必须**是「opaque 且命令读不出」，不能放宽成 `seg.opaque`：
  // 后者会把「命令可读、构造只是参数」的那一族也拉进门控，改掉 `diskpart /s a.txt`
  // 这类承重格的「替换」语义（`:4244-4245` 明禁）。判据与门控内那两条守卫同源。
  const opaqueHiddenPayload = !!(seg && seg.opaque && !destructiveHeadReadable(seg))
  if (hasPureRadius || (hasPrivGroup && seg && seg.blast) || opaqueHiddenPayload) {
    // ── opaque 段：目标被读不懂的构造吞掉，`null` 的含义**不是**「在区内」────────────
    // 词法器把 opaque 构造（子 shell `( )`、命令替换 `$( )` / 反引号、花括号分组 `{ }`）
    // 整块吞掉，段级词元只剩构造**之外**的部分：
    //     (rm -rf /etc)          → words 是 []（连命令名都没留下）
    //     rm -rf $(echo /etc)    → words 是 ['rm','-rf']（目标整个在构造里）
    // 于是 `blastRadiusOfSegment` 没有任何目标词元可判、返回 `null`，而 §5.1 把 `null`
    // 映射成 `inside` —— 「目标读不出」被当成了「目标在工作区内」。
    //
    // `sawUnjudgeable` 这条保护在这里**结构性失效**：它只在「非空词元被判为读不出」时
    // 置位（见该函数的置位表），而 opaque 段一个目标词元都没留下 —— 前一种形态连词元
    // 都没有，后一种的目标根本不在词元里。实测（默认配置 mode=allow：inside=allow、
    // 其余七档=ask）：
    //     (rm -rf /etc) / { rm -rf /etc; } / `rm -rf /etc` / rm -rf $(echo /etc)
    //     echo $(rm -rf /etc) / (rm -rf .) / (rm -rf ~) / (rm -rf C:/Windows)
    // 八种写法全部 allow。这与「整行读不懂」分支同口径：**读不出就归 `unknown`**，
    // 不归 `inside`（§4「三种 null 必须分开」）。
    //
    // 只在 `blast` 为 null 时替换 —— 已有结论时那个结论更具体，不该被降级成更模糊的
    // 说法：`rm -rf C:/Windows $(x)` 实测 blast=wide（真目标是系统目录，判得出来）。
    // ⚠️ 但「不**替换**」不等于「不并 `unknown`」——`blast` 非空时那条结论照样要并进来，
    // 只是走的是**门控外**的判据 ③（`seg.opaque`，并列补档），故此处守卫保持不变。
    //
    // ⚠️ **门控内保持「替换」语义逐字不变**（本批只把 `unknown` 侧判据移出门控）：
    // `diskpart /s a.txt` 走的就是这一支（`isUnknownTierSegment` 为真 → 只给 `unknown`，
    // 半径档 `outside` 被替换掉），改成叠加会白送一个半径档，而 `:4207-4208` 明禁。
    const opaqueUnjudgeable = !!(seg && seg.opaque && !seg.blast)
    // ── 门控修正：`!seg.blast` **不是**「半径侧读不出」的完整判据 ─────────────────
    // `blast` 非空也可能是 `{level:'unknown'}` —— 那同样是「半径侧没有结论」，只是走另一条
    // 产出路径：词法器不吞反引号，命令替换作为字面词元留在 `words` 里，该词元被判为「读不出」
    // → `sawUnjudgeable` 置位 → 段级 blast 是 `{level:'unknown'}` 而非 `null`。
    // 于是旧门控 `seg.opaque && !seg.blast` 对反引号形态恒假，本守卫整个不被求值，落到
    // `else` 支只并 `unknown`、`wide` 被静默丢弃（同一构造的四种写法里只有反引号漏网）。
    //
    // ⚠️ 两条守卫**缺一不可**，且都不可放宽：
    //   · `!destructiveHeadReadable(seg)` —— 命令可读、构造只是参数的那一族
    //     （`rm -rf ./build $(date)`）必须留在 `else` 支，否则会凭空收紧；
    //   · `seg.opaque` —— 没有 opaque 构造的段不参与（`kill 1234` 那族不得凭空多档）。
    //
    // ⚠️ 只把「半径侧读不出」的判据补齐，**不动** `else` 支的「替换」语义：
    // `diskpart /s a.txt`（`opaque` 为空、`isUnknownTierSegment` 为真）照旧恰好 `['unknown']`。
    //
    // ⚠️ 判据是「命令读不出」，而**不是**「`blast` 空或为 `unknown`」—— 后者在 opaque 段里
    // 另有一个可读目标、且其 blast 恰为 `outside` 时（`cat /etc/hosts $(rm -rf C:/Windows)`）
    // 会落进 `else` 支只并 `outside`，`wide` 与 `inside` 从 `tiers` 静默消失（诱饵把判据骗开）。
    // 故用 `opaqueHiddenPayload`（= `seg.opaque && !destructiveHeadReadable(seg)`）作为唯一判据：
    // 真命令藏在构造里这件事与诱饵目标无关，诱饵档由下面 `add(radiusTierOf(seg.blast))` 显式保留。
    //
    // ⚠️ 两个方向都不能少：只并三档、不保留诱饵档会丢掉用户可能显式配过的 `outside=deny`；
    // 只保留诱饵档、不并三档则是原来的 fail-open（`wide=deny` 被静默丢弃）。
    if (opaqueHiddenPayload) {
      // ── 「**破坏性命令本身藏在 opaque 构造里**」：与「整行读不懂」分支取同一口径 ──────
      // 判据 = 段首读出来的命令名**不是**破坏性命令（空 label 也算读不出），而这一段却被
      // 判成破坏性段 —— 那只可能是 `rawCommandNames` 在构造里认出了真命令。此时：
      //   · 半径判据**没有**任何可判目标（`blast` 是 null，**或**是 `{level:'unknown'}`，
      //     两者都不是「判过、在区内」）；
      //   · 构造里藏着的既可能是无害命令、也可能是删盘根 —— **读不出半径不等于半径安全**。
      // 故并 `wide ∪ unknown ∪ inside` 三档参与取最严（`inside` 见 `RADIUS_TIERS_WHEN_UNREADABLE`
      // 的注释：整行分支一直并它，丢掉它就等于丢掉用户可能显式配过的 `inside=deny`），
      // 档位集合与整行分支**单点共用**（`RADIUS_TIERS_WHEN_UNREADABLE`），不再两处各写一份。
      //
      // ⚠️ 修的是一个 fail-open：用户**显式配置的 `wide=deny`** 曾在段级路径上被静默丢弃。
      // 实测（`wide=deny` + `unknown=allow` + `category=allow`）：
      //     echo a | (rm -rf C:/Windows)  ← 行尾悬空检查放宽前 ok:false，走整行分支 → deny
      //                                     放宽后 ok:true、末段 opaque → 只命中 unknown → **allow**
      // `|` / `&&` / `||` / `&` 四种分隔符同形（`;` 与换行分隔的同形态在放宽前**已经是**
      // allow，早就走段级路径）—— 即缺陷面正是这次放宽新打开的。
      //     Get-ChildItem | ForEach-Object { Remove-Item C:/Windows -Recurse -Force }
      //     同理：段首 label 是 `foreach-object`，真命令 `remove-item` 只在构造里。
      //
      // ⚠️ **不得放宽成「凡 opaque 且半径侧读不出就并 wide」**（仲裁的初版修法）：
      // 那会连带改掉「命令可读、构造只是**参数**」的一族，而它们是合法常用命令、
      // 半径判据已按可读前缀判过档，并 `wide` 等于把已知结论抬成「可能很大」——
      // `test/shell-parse.mjs` 的 60g ④b/⑤b 把这一族钉死为「恰好 `['unknown']`」
      // （`rm -rf ./tmp/{a,b,c}`、`rm -rf ./build $(date)`：段首 label 是 `rm`，
      // 命中本行的 `destructiveHeadReadable` 守卫 → 不并 `wide`/`inside`，行为逐字不变）。
      for (const t of RADIUS_TIERS_WHEN_UNREADABLE) add(t)
      // 诱饵目标已判出的半径档（`outside` / `home` 那一族）**显式保留**，见本支开头。
      add(radiusTierOf(seg && seg.blast))
      // ── 构造里**读得出的区外目标** → 并入 `outside` 档 ─────────────────────────
      // 上面那三档（`wide ∪ unknown ∪ inside`）是「半径侧读不出」的通用口径，**不含
      // `outside`**（该常量也不能加 `outside`：整行分支同样消费它，加了会把
      // `rm -rf ./build <<EOF` 那一族从 allow 变 deny —— 过度收紧）。于是用户显式配的
      // `outside=deny`（「工作区外的破坏性操作一律拒绝」）在这条路径上整个失明：
      //     rm -rf /data     → deny（段级 `outside` 档）
      //     (rm -rf /data)   → allow ← 同一命令，只因整个包进了 opaque 构造
      // 判据与整行读不懂分支**同一个函数**：只有构造原文里真的读得出区外目标时才并入，
      // 不是「凡 opaque 就并 `outside`」—— 后者会给八档全 allow 的用户凭空多一档。
      //
      // ⚠️ 取 `seg.opaqueTexts` 而**不是** `seg.text`：`tierSetOf` 的入参只有
      // `{words, blast, opaque, opaqueTexts}`，没有 `text` —— 用 `seg.text` 会恒 `undefined`。
      // ⚠️ 反引号由 `outsideTargetInUnparsable` **内部**统一处置（当段分隔符，与 `$( )` 的
      // `(` `)` 同待遇）—— 调用处**不再**自己剥一遍：逐词元剥反引号会把
      // `echo `rm -rf /data`` 变成 `echo rm -rf /data`，段首仍是 `echo` ⇒ 判不出目标。
      for (const t of (seg && Array.isArray(seg.opaqueTexts) ? seg.opaqueTexts : [])) {
        if (outsideTargetInUnparsable(String(t), opts)) { add('outside'); break }
      }
    } else {
      add((opaqueUnjudgeable || isUnknownTierSegment(list, seg && seg.words, opts))
        ? 'unknown'
        : radiusTierOf(seg && seg.blast))
    }
  }
  // ── 并列补档行：`unknown` 侧的三条产出判据（**移出门控**，见 `tierSetOf` 的 ① 说明）──
  // 上面那一支是「半径档 / unknown **二选一**」的替换语义，而它整个被门控包着 —— 于是
  // **纯组档段**（proc / power / reg）整段跳过，同一条「目标读不出」的结论只因命令属组档
  // 就静默 allow（fail-open）。
  //
  // 门控存在的唯一正当理由是「不给 `kill 1234` 白送 inside 档」（`radiusTierOf(null)` 会把
  // 「没判过」当成「判过且在区内」）。它不该连带挡住 `unknown` 的产出判据 —— 三条判据都自带
  // 「确实读不出」的守卫，不会凭空产档：
  //   ① `blast.level === 'unknown'`  —— `blastRadiusOfSegment` 判过、结论就是读不出；
  //   ② `blast.unjudgeable`          —— 已知目标 + 读不出目标同段共存：
  //      `blastRadiusOfSegment` 会返回**带 `unjudgeable` 标志的已知档**（`worst` 仍用于
  //      `blast` 显示），两个结论是并列关系而非二选一，故这一支是补（与半径档并列取最严）。
  //   ③ `seg.opaque`                  —— 目标被 opaque 构造吞掉（`(kill 1234)` /
  //      `kill $(cat p)`：`words` 里一个目标词元都没留下，另两条判据够不到）。
  //
  // ── ⚠️ 判据 ③ 是 `seg.opaque`，**不带** `&& !seg.blast` 守卫 ─────────────────
  // 初版写作 `seg.opaque && !seg.blast`，把「opaque」与「有半径档」当成二选一。但
  // `$(...)` / 反引号形态下词法器把构造整块吞掉、目标词元不进 `words`，于是三条判据对
  // 「有半径档的 opaque 段」全部够不到：`rm -rf /etc $(rm -rf /)` 只剩 `['outside']` 而
  // 同义的反引号写法是 `['unknown','outside']` —— 同一语义两个结论，方向 fail-open。
  //
  // ⚠️ 代价只在「外层目标可判出半径档 + opaque」这一族，且方向是收紧：`rm -rf /etc $(date)`
  // 多并 `unknown` 档；`rm -rf ./build $(date)`（blast=null）本来就是 `['unknown']`，零差异。
  // `rm -rf ./{dist,build}` 在带 `isWorkspaceRoot` 钩子时多并一个 `unknown`（默认配置下
  // wide=ask 与 unknown=ask 同值，action 不变）。
  //
  // ⚠️ 三条**缺一不可**：只补 ① ② 时第 ③ 族仍是 allow。此处对已门控的段是空操作
  // （`add` 去重），对纯组档段与「有半径档的 opaque 段」才是收益。
  // ⚠️ `isUnknownTierSegment` 对组档段**恒假**（表里只有 del/disk/perm 成员），
  // 故它留在门控内、不随本条移出 —— 移出会改变 `diskpart` 那一族（承重格，见上）。
  if (seg && ((seg.blast && (seg.blast.level === 'unknown' || seg.blast.unjudgeable))
    || seg.opaque)) add('unknown')
  // ② 组档
  for (const t of groupTiersOf(list)) add(t)
  // ③ 提权（位置判据）。与 ② 的 `priv` 组档互为冗余而非重复 ——
  // 冗余的那一侧（位置判据）覆盖的是 `segmentLabels` 刻意不扩展的形态（`su` / `runas`）。
  if (seg && segmentPrivilege(seg.words)) add('priv')
  // 排序：固定顺序，与用户配置无关（见 TIER_ORDER 的注释）。
  // 与整行读不懂分支共用 `sortTiersByRank`（同一条纪律：排序键只有一份）。
  return sortTiersByRank(set)
}

/**
 * 段级动作的严格度序：allow < ask < deny（越大越严）。
 *
 * **与 index.js 的 MODE_STRICTNESS 是同一个序**，但两处不能合并 —— 那个在宿主闭包里、
 * 这个在纯解析器里，解析器不能依赖宿主（它要能独立单元测试）。
 * 两处都只有一行，且都由测试断言钉住，漂移风险低于「把解析器耦合到宿主」的代价。
 *
 * ── `auto` 为什么必须在这里，且取值与 `ask` 相同 ─────────────────────────────────
 * 破坏性命令的八个档位与其余分类同域（宿主的 MODES/ALL_MODES），故用户**可以**把某一档
 * 设成 `auto`。本表缺这个键时 `TIER_STRICTNESS[ds[t]]` 是 `undefined`，`decisiveTierOf`
 * 会 `continue` 跳过该档 —— 而它跳过的后果分两种：
 *   · 别的档有具体动作 → 那些档里取最严，auto 那一档被**静默忽略**；
 *   · 命中的档全是 auto → 返回 null → `strictestTierAction` 返回 `'inherit'`
 *     → 落**大分类 mode**。大分类若是 allow，用户写的「这一档交给模型判」就变成了
 *     **直接放行**（fail-open，且没有任何提示）。
 * 取值 1 的理由与 MODE_STRICTNESS 处同源：auto 与 ask 一样是「要过一道关」的档位
 * （ask 过关的是人，auto 过关的是模型）。并列时**不能**一律由 `tiers` 的排列决定 ——
 * 那会让「提权要问人」被降级成「问模型」（`wide` 恒排在 `priv` 之前），故
 * `decisiveTierOf` 对 `ask` 与 `auto` 的并列另有 tie-break：显式 ask 压过 auto、
 * 缺省 ask 让位给 auto（同为 ask 的并列另见该函数第三支；详见该函数的注释）。
 */
export const TIER_STRICTNESS = { allow: 0, ask: 1, deny: 2, auto: 1 }
/**
 * **回落值**（`autoFallback`）的严格度序：allow < ask < deny（越大越严）。
 *
 * 回落值与动作是**两个域**，不能共用上面那张表：动作域含 `auto`（与 `ask` 同为 1，
 * 表示「还要再过一道关」），而回落值的值域被 `normalizeAutoFallback` / `autoFallbackOf`
 * 锁死在**三值** —— 它就是「模型失败后最终执行什么」，`auto` 在这里没有意义
 * （回落值不可能再回落一次，见计划 §2.2.1）。拿含 `auto: 1` 的动作表去比回落值，
 * 正确性依赖「值域已被上游锁死」这条**隐式**契约；一旦某处漏了归一化，`auto` 会
 * 以 1 的身份参与比较、与 `ask` 并列 —— 那时取谁取决于实现细节。
 *
 * 故回落值有自己的一张表，且**全仓只有这一张**：本模块的 `strictestFallbackOf`
 * （段内多档 / 段与段合并）与宿主的 `out()`（doom 合并）、`outsideMatrix`（两道区外闸）
 * 共用它。三处原先各写一份三键表 / 借动作表，其中两处的注释对同一原则给出**相反**指令，
 * 那种「表述冲突 + 值域隐式契约」正是漂移的温床。
 */
export const AF_STRICTNESS = { allow: 0, ask: 1, deny: 2 }
/**
 * 命中档位 → 动作：取**最严**（deny > ask > allow）。
 *
 * 与既有设计同构 —— 段之间就是这么合并的（`shell-parse.js` 的 fail-closed 合并注释）：
 * 「段之间是**并列**关系……只能整体从严」。
 *
 * `inherit` 的处理：它表示「该档没有表态」，不参与比较；**若所有命中档都是 inherit**
 * 则返回 `inherit`，让调用方按既有语义落大分类。`undefined`（配置里根本没有这一档，
 * 老配置升级路径）同样跳过 —— 缺档由宿主的 `destructiveTiers` 补齐，补不到才落到这里。
 *
 * ── 「选档」只有一份实现：本函数**必须**基于 `decisiveTierOf` ──────────────────────
 * 这里曾经自己再写一遍「查 TIER_STRICTNESS + `r > bestRank` 循环 + 跳过 undefined」，
 * 与 `decisiveTierOf` 逐行同构、只差返回 `ds[t]` 还是 `t`。两者必须**永远选中同一档**：
 * `decisiveTierOf` 选出的那一档正是调用方取 `reasons[tier]` 用的那一档
 * （见 `assessCommand` 的拒绝理由）。各留一份的后果是「日后只改一处」——动作来自 A 档、
 * 拒绝理由取自 B 档，而两者都不会报错，只会让弹窗解释与实际裁决不一致。
 * 故把选档收敛到 `decisiveTierOf` 一处，本函数只负责把档位翻译成动作。
 *
 * @param {object|null} ds 宿主的档位表（`{inside, outside, wide, …, reasons?}`）
 * @param {string[]} tiers 命中的档位
 * @param {boolean} [noDefaultYield] 见 `decisiveTierOf` 的同名参数；本函数只负责转发，
 *   保证「选档」与「翻译动作」用的是**同一个**判据（否则动作与 decisive 档分叉）
 * @returns {'allow'|'ask'|'deny'|'inherit'}
 */
export function strictestTierAction(ds, tiers, noDefaultYield) {
  const t = decisiveTierOf(ds, tiers, noDefaultYield)
  // ── 全部命中档都「选不出动作」时，**不能**一律返回 inherit ─────────────────────────
  // `decisiveTierOf` 跳过两种档：`inherit` / `undefined`（该档未表态，**应当**落大分类）
  // 与本版**不认识的值**（手改配置的尾空格、大小写、更高版本写入的动作）。
  // 前者落大分类是对的；后者落大分类是 **fail-open** —— 大分类常态 allow
  // （read / undo / subagent / outsideRead 四类的默认值就是 allow），于是
  // 「用户写了条拒绝规则」变成**静默放行**。
  //
  // 判据：命中档里**是否有任何一个**带了本版不认识的值。有 → 折 ask。
  // 语义：有人要求表态，只是本版读不懂它要什么 —— 退化成「问人」最接近原意，
  // 且方向安全（弹窗拦一次）。折 deny 会让降级期间所有此类规则变成硬拒绝。
  // 全部档都是 inherit / undefined → 仍是 inherit（既有语义**不变**）。
  //
  // 「认识与否」用 `TIER_STRICTNESS` 判：它是动作域的**唯一一份表**，`decisiveTierOf`
  // 选档时用的也是它，两处同源 —— 不会出现「选档时认、返回时不认」的分叉，
  // 也不新增第二份合法动作清单。
  // ⚠️ 必须用 `hasOwnProperty`：那张表是对象字面量，`TIER_STRICTNESS['toString']` /
  // `['constructor']` / `['valueOf']` 会命中原型链返回**函数**而不是 undefined，
  // 于是把动作写成 `toString` 就能绕过本闸（实测确认这三个键都返回 function）。
  const known = (v) => Object.prototype.hasOwnProperty.call(TIER_STRICTNESS, v)
  const list = Array.isArray(tiers) ? tiers : []
  // 命中档里是否有**本版读不懂**的值。注意不能只在 `t === null` 时判：
  // 未知档会被 `decisiveTierOf` 跳过，于是「wide=未知 + priv=allow」里
  // priv 的 allow 会成为 decisive → 整条命令**静默放行**，未知那一档的
  // 表态（可能是用户写的 deny 笔误）被完全吃掉。实测该形态在只补 `t === null`
  // 的版本下仍是 `allow`（fail-open）。
  const hasUnknown = list.some((u) => {
    const v = ds ? ds[u] : undefined
    return typeof v === 'string' && !known(v) && v !== 'inherit'
  })
  if (t === null) return hasUnknown ? 'ask' : 'inherit'
  const a = ds[t]
  // 未知档在场时折 ask，但**不越过更严的落点**：把 deny 降成 ask 是放宽。
  // 「更严」按**最终动作**判，与 `finalActionOf` / B 项 `noDefaultYield` 是同一条判据：
  // `auto` 是**两层**的（第一层交给模型，第二层 `autoFallbacks[档]` 才是模型失败后
  // 真正执行的动作），`auto/deny` 的最终动作就是 deny —— 与裸 deny 在执行侧同形
  // （同一条 kind:'deny' 通道）。折 ask 等于把用户显式配的「失败后拒绝」降级成
  // 「问人」，那是反向放宽。
  // ⚠️ 判据必须看**全部命中的 auto 档**，不能只看 decisive 档 `t`：`tierVerdict` 给出的
  // `autoFallback` 本来就是全部 auto 档取最严（见 `assessCommand` 里 `strictestFallbackOf`
  // 的说明）。只看 `t` 时，deny 落在**非 decisive** 的 auto 档上就被折成 ask：
  //     sudo rm -rf /etc $TARGET   tiers=['wide','unknown','priv']
  //     wide=auto/ask + priv=auto/deny + unknown 档是本版读不懂的值
  //   → 只看 `t`（`wide`）得 ask，取全部 auto 档最严得 auto/deny（正确）。
  // 其余（allow / 全部 auto 档的回落最严值不严于 ask）一律折 ask：这些形态的最终落点
  // 不严于 ask，而未知档可能是用户写的 deny 笔误 —— 折 ask 才是收紧。
  if (hasUnknown) {
    if (a === 'deny') return a
    // `autoFallbacks` 可能是 undefined / null / 非对象（调用方允许），归一成 null。
    const afs = (ds && ds.autoFallbacks && typeof ds.autoFallbacks === 'object') ? ds.autoFallbacks : null
    if (a === 'auto') {
      // 全部**命中的 auto 档**取最严回落值（缺省 / 非法值按 `ask` 参与，与
      // `strictestFallbackOf` 同一条判据 —— 那个是 `assessCommand` 内的局部 const，
      // 本函数调不到，故内联；两处判据必须同步改）。
      let worst = 'ask'
      for (const u of list) {
        if (ds[u] !== 'auto') continue
        const raw = afs === null ? undefined : afs[u]
        // 回落值域只有三个键；`AF_STRICTNESS` 是对象字面量，直接索引会命中原型链
        // （`'constructor'` 等返回函数），故先限定字符串再用 hasOwnProperty 判。
        const f = (typeof raw === 'string' && Object.prototype.hasOwnProperty.call(AF_STRICTNESS, raw)) ? raw : 'ask'
        if (AF_STRICTNESS[f] > AF_STRICTNESS[worst]) worst = f
      }
      if (worst === 'deny') return a
    }
    return 'ask'
  }
  return a
}

/**
 * 命中档位里**决定动作**的那一个（用于取该档的拒绝理由）。
 *
 * 判据与 `strictestTierAction` 同源（同一个严格度序 + 同一个「取最严」）；
 * 同严格度并列时按「**显式**表态压过缺省值」定（`source[tier] === 'default'` 才算缺省，
 * 没有 `source` 表时一律按非缺省处理）：
 *   · 显式 `ask` 压过 `auto` —— 故 `ask` 与 `auto` 双方都**显式**时取 `ask`
 *     （安全方向：人比模型更该被问）；
 *   · **缺省** `ask` 让位给 `auto` —— 用户显式配置的 `auto` 不得被宿主的缺省值吃掉；
 *     但在**读不懂**的路径上（`noDefaultYield`），只让位给**最终不会放行**的 `auto`（见下）。
 * `deny` / `allow` 与同动作 `auto` 的并列取 `tiers` 里**靠前**的那个 —— 先到先得；
 * 同动作 `ask` 不适用「先到先得」，按「显式压缺省」定（见下面第三支）。
 * 见下面循环里的 tie-break。
 *
 * ⚠️ 「靠前」的稳定性**由调用方保证**：本函数不看 `TIER_ORDER`，只认 `tiers` 的**排列**，
 * 故稳定性对**已排序**的 `tiers` 成立 ——
 *   · `tierSetOf` 的产物（返回前按 `TIER_RANK` 排过）；
 *   · `assessCommand` 整行读不懂分支那条**手工拼接**路径（已按**同一个** `TIER_RANK` 排过，
 *     见那里的说明：不排的话动作不变、理由会随书写形态漂移）。
 * 传进未排序的 `tiers` 时本函数仍然正确选出**最严档**，只是并列时取哪个由传入顺序决定。
 * 没有任何档给出具体动作时返回 `null`。
 *
 * ── `noDefaultYield`：读不懂路径上不许「缺省让位」把授权带进来（D-4）────────────────
 * 由 `assessCommand` 的**两个读不懂调用点**传 `true`（整行读不懂 / 段级 opaque），可读段不传。
 * 理由：读不懂的段/整行的 `tiers` 恒含 `RADIUS_TIERS_WHEN_UNREADABLE`（`wide ∪ unknown ∪ inside`，
 * 见该常量），而 `inside` 在 `TIER_ORDER` 里排**最后**。于是「`inside=auto` 显式 + 其余缺省 ask」时，
 * 缺省的 `wide`（ask）先占住 `best`、第二支再让位给 `inside` 的 auto —— 裁决从 ask 变 auto。
 * 若那一档的回落值是 `allow`，模型失败后就是**无人在环放行**（`timeoutMs=0` 连弹窗都没有）：
 * 一条 `rm -rf C:/Windows` 只要包一层 `( )` / `$()` 就能拿到它。实测（工作区，其余七档全缺省 ask）：
 *     rm -rf C:/Windows           → ask
 *     (rm -rf C:/Windows)         → auto/allow ❌（HEAD 是 ask）
 *     echo $(rm -rf C:/Windows)   → auto/allow ❌
 * 故读不懂路径上**只阻止让位给「最终会放行」的 auto**（即 `autoFallbacks[t] === 'allow'`）：
 *   · `auto/deny`、`auto/ask` 的最终动作不松于 ask，让位它们不产生放宽；
 *     `auto/deny` 还比 ask 更严 —— 一并堵掉等于把用户显式配的「失败后拒绝」降级成「问人」；
 *   · 判据是「让位目标的**最终落点**」而不是「它是不是因读不懂才并入的档」：`priv` 这类
 *     **读得出**的组档同样会走到第二支（`sudo rm -rf /etc "unclosed` 的 tiers 含 `priv`），
 *     只堵并入档的修法对它无效（实测仍放宽）；
 *   · 可读路径**不受影响**（不传该参数）：那里 `inside` / `priv` 是**真的**命中，
 *     用户显式配置的 auto 应当生效。
 */
export function decisiveTierOf(ds, tiers, noDefaultYield) {
  // ── 来源表 / 回落值表 / 「是否缺省」判据**全部建在循环外**（性能）──────────────────
  // 同一次调用里 `ds` 不变，而原先「来源表」与「是否缺省」的判据建在 for 体内 —— 每次同档比较都重建
  // 一个闭包；而闭包**调用**本身也是逐档开销，故判据直接内联、不写成小函数。
  // `ds[t]` 同理：原先每档至少读一次（算严格度）、同档比较时再读一次，现在只读一次。
  // 实测（min-of-15、200k iter、四档全 ask，ns/次）：
  //     工作区 178~186（闭包在循环内 + `ds[t]` 重复读）
  //   → 只把两行提出循环外 105~111
  //   → 提出 + 内联判据 + `ds[t]` 只读一次 72~77
  // 三件事都要做：提出、内联、缓存。
  //
  // `ds` 可能为 null / 非对象（调用方允许），故先归一成「没有来源表」的 null —— 语义与
  // 原先的 `src && typeof src === 'object'` 逐字相同：没有来源表时一律按**非缺省**处理。
  const src = (ds && ds.source && typeof ds.source === 'object') ? ds.source : null
  // 回落值表同样取一次：读不懂路径上的让位判据要看「这一档 auto 的**最终落点**」。
  // 只有 `allow` 才阻止让位（理由见下面第二支），其余（ask / deny / 没配 / 垃圾值）都放行。
  const afs = (ds && ds.autoFallbacks && typeof ds.autoFallbacks === 'object') ? ds.autoFallbacks : null
  const list = Array.isArray(tiers) ? tiers : []
  let best = null
  let bestRank = -1
  for (const t of list) {
    // `ds[t]` 每档只读一次：它既用来算严格度、又要进 tie-break 的三支
    const at = ds ? ds[t] : null
    const r = TIER_STRICTNESS[at]
    if (r === undefined) continue
    if (r > bestRank) { bestRank = r; best = t; continue }
    // ── 同档 tie-break：`ask` 压过 `auto`（§13）──────────────────────────────────
    // `ask` 与 `auto` 同为 1，而 `TIER_ORDER` 里 `wide` 恒在 `priv` 之前 —— 严格大于
    // 的比较就成了「先到先得」，于是同一组 `tiers` 的结论取决于哪一档被设成 auto：
    //     `sudo rm -rf /etc`（tiers = ['wide','priv']）
    //       wide=auto + priv=ask → auto   ← 用户显式要求的「提权要问人」被降级成「问模型」
    //       wide=ask  + priv=auto → ask
    // 那是**放宽**（模型可能直接放行）。故并列时的判据是「**显式**表态压过缺省值」，
    // 且**两个方向都必须堵** —— 只堵一个方向会留下镜像缺陷（`TIER_ORDER` 把
    // `proc/power/priv/reg` 全排在 `wide/unknown/outside/inside` 之后，于是「后置档单独
    // 设成 auto」这一整族配置会被缺省 ask 吃掉，面板显示 priv=auto 而裁决是 ask）：
    //     wide=auto 显式 + priv=ask 缺省 → auto（缺省 ask 不得压过显式 auto）
    //     wide=ask 缺省 + priv=auto 显式 → auto（同上，镜像方向）
    // 双方都**显式**时仍取 `ask`：安全方向不得被上面两条翻转（人比模型更该被问）。
    // `deny`（2）与 `allow`（0）不同档，不受影响；同动作的并列仍先到先得（`ask` 除外，见第三支）。
    //
    // ⚠️ **不要**为此改 `TIER_STRICTNESS` 的值（把 auto 改成 2）：`doom` 合并、段间
    // 合并、`warnSubMismatch` 三处共同消费那张表，改成 2 会让 doom 的 ask 盖不过 auto
    // —— 正是 §9B 记的那个 bug。
    //
    // ── 「ask」必须是**用户显式**的表态，缺省值不算 ───────────────────────────────
    // 宿主的 `destructiveTiers` 对**未配置**的档下发 `'ask'` + `source[t] = 'default'`
    // （见 index.js：「八档同一套规则：项目显式 → 全局显式 → ask」），而这张表原样流到这里。
    // 于是「wide=auto 显式 + priv 未配置」被 tie-break 当成「用户要求提权问人」，
    // 把用户显式配置的 auto 降级成 ask —— 用户的意图被**缺省值**压掉（实测 wide=auto
    // 单档配置下，`tiers = ['wide','priv']` 的语料整族从 auto 变 ask：`sudo rm -rf /`、
    // `sudo chmod 777 …`、`su -c "rm -rf /"` …）。
    // 故 tie-break 只在 ask 那一档**有显式来源**时生效。
    //
    // ⚠️ 反方向同样成立：`tiers` 里 `ask` 在前、`auto` 在后时（`TIER_ORDER` 把
    // `proc/power/priv/reg` 全排在 `wide/unknown/outside/inside` 之后，这种排列是常态），
    // 循环因 `r > bestRank` 严格大于而什么都不做、`best` 停在前面的 ask 上 —— 于是
    // 「`priv=auto` 显式 + 其余缺省 ask」下 `sudo rm -rf /etc`（['wide','priv']）得 ask，
    // 而「`wide=auto` 显式」同形态得 auto：同一个判据在两个方向给出相反结论，
    // 与本段标题自相矛盾（面板显示 priv=auto、实际裁决 ask）。
    // 故第二支的判据是「**best** 是缺省值」—— 只有缺省 ask 才让位给显式 auto。
    // 写成 `if (!(src && src[t] === 'default')) best = t` 是**错的**：那会让双方都显式时 auto 压 ask，
    // 把安全方向（显式 ask 仍压显式 auto）翻转，正是本条要守的东西。
    // ── 第三支：`best` 与 `t` **都是 ask** 时，显式 ask 仍须压过缺省 ask ─────────────
    // 前两支互为镜像、只覆盖「一边 ask 一边 auto」，故两者都是 ask 时**都不匹配**、
    // `best` 原地不动 —— 「已见过显式 ask」这个事实没被记下。随后再来一个显式 auto，
    // 第二支只看 `src[best] === 'default'`，而 `best` 恰是排最前的**缺省 ask** → auto 接管，
    // 中间那个显式 ask 被跳过（方向放宽）：
    //     {proc: 显式 ask, priv: 显式 auto}，其余缺省 ask
    //       `sudo kill 1234`（['proc','priv']）           → ask ✅
    //       `sudo kill -9 /etc/passwd`（['wide','proc','priv']） → 修复前 auto ❌
    // `TIER_ORDER` 把 `wide/unknown/outside/inside` 排在 `proc/power/priv/reg` 之前，
    // 故「缺省 ask 在前、显式 ask 居中、显式 auto 在后」正是生产常态。
    //
    // 两个守卫**缺一不可**：
    //   · 缺 `src[best] === 'default'` → 后面的显式 ask 会覆盖前面的显式 ask，decisive 档漂移
    //     （动作不变、理由换人，弹窗解释与实际裁决不一致）；
    //   · 缺 `!(src[t] === 'default')` → 缺省 ask 会顶掉前面的显式 ask，理由归因同样劣化。
    // 于是缺省+显式 → 取显式；显式+缺省、显式+显式 → 不动（先到先得）。
    if (r === bestRank && best && ds) {
      // `at` 已在循环头取过；`ds[best]` 每轮至多读一次（三支都要用）
      const ab = ds[best]
      if (at === 'ask' && ab === 'auto') { if (!(src && src[t] === 'default')) best = t }
      else if (ab === 'ask' && at === 'auto') {
        // ── 读不懂路径（`noDefaultYield`）上，缺省 ask 只让位给「最终不会放行」的 auto ──
        // `auto` 是**两层**的：第一层「交给模型」，第二层 `autoFallbacks[t]` 才是模型失败后
        // 真正执行的动作。让位给 `auto/allow` 等于让「模型失败后无人在环放行」拿走裁决 ——
        // 正是 D-4「读不懂的内容不可被授权」要堵的（`timeoutMs=0` 时连弹窗都没有）。
        // 而 `auto/ask`、`auto/deny` 的最终动作不松于 ask，让位它们不产生放宽；`auto/deny`
        // 甚至比 ask 更严 —— 一并堵掉会把用户显式配的「失败后拒绝」降级成「问人」，那是反向放宽。
        // 缺省 / 非法值按 ask 处理（与 `assessCommand` 的 `autoFallbackOf`、index.js 的
        // `normalizeAutoFallback` 同源）：没配回落值的 auto 档，最终落点就是 ask。
        if (src && src[best] === 'default' && !(noDefaultYield && afs !== null && afs[t] === 'allow')) best = t
      }
      else if (at === 'ask' && ab === 'ask') { if (src && src[best] === 'default' && !(src && src[t] === 'default')) best = t }
    }
  }
  return best
}

/**
 * 段级「命令头位置上的命令名」—— **判据单点**，供 `hasNoOperand` 与
 * `blastRadiusOfSegment` 两个消费点共用。
 *
 * ── 为什么必须单点 ──────────────────────────────────────────────────────────
 * `commandHeadEnd` 的 ① 分支经 `skipPrefixArgs` 把 `su -l` 这类**普通选项**吃掉并
 * **停在其上** ⇒ `w[headEnd - 1]` 是 `-l` 而不是命令名 ⇒ 直接把它当 `cmdName` 传给
 * `isCmdStyleSwitch`，会因 `GROUP_OF_LABEL['-l']` 查不到而走「认不出命令名 ⇒ 不消费
 * 半径」兜底 ⇒ 真正的目标实参被当成 cmd 风格开关跳过。
 *
 * 该判据此前在上述两个消费点各存一份**逐字副本**，而这一族**历史上已两次漂移**
 * （两处各自的注释都记录了漂移本身）。抽成单点后两个消费点由**同一个**函数钉住：
 * 改这一处即两处同时生效，结构上不再可能「只改一处」。
 *
 * ── 守卫三项（缺一不可）────────────────────────────────────────────────────
 *   · `headEnd` 是有效下标（`> 0 && < w.length`）—— 否则 `w[headEnd - 1]` 无意义；
 *   · `w[headEnd - 1]` 以 `-` 开头（`charCodeAt(0) === 45`，与 `skipPrefixArgs` 同判据）；
 *   · **不是值选项**（`isPrivCommandValueFlag`，O(1) 查表）—— `-c` / `--command` 的值
 *     **本身就是命令或目标**（`PRIV_VALUE_IS_COMMAND`），`commandHeadEnd` 停在值选项上
 *     是**刻意的**，命令头**不该**继续推进。删掉这一项会在值选项形态上引入新的放宽：
 *     `su -c C:/data parted /data` 由 `unknown,priv` 变 `outside,priv`、
 *     `su -c /data parted /data` 由 `unknown,priv` 变 `inside,priv`。
 *
 * 三项全过 ⇒ 命令名改从 `commandHeadEndFull` 取（它额外认识语句关键字，推进得更远）；
 * **取两者较大者**而非无条件取 `headFull`：两者在少数形态上不同向，取大者与两个消费点
 * 循环里的 `i < headEnd || i < headFull` 并集口径一致。
 *
 * ── 惰性（性能纪律，勿退化成无条件求值）──────────────────────────────────────
 * `commandHeadEndFull` 是 O(n) 推进循环，**只在守卫命中时才调**：第三个形参是调用方
 * 已算好的 `headFull`（`hasNoOperand` 本来就要算它，传进来即可）；**不传**时本函数才
 * 惰性去调（`blastRadiusOfSegment` 走这条，它没有现成的 `headFull`）。无条件先算实测
 * 多花约 0.31 µs/段。守卫本身 O(1)、无正则、无分配。
 *
 * @param {string[]} words 段词元
 * @param {number} headEnd `commandHeadEnd(words)` 的结果
 * @param {number} [headFullHint] 调用方已算好的 `commandHeadEndFull(words)`；缺省时惰性求值
 */
function headCmdNameForSegment(words, headEnd, headFullHint) {
  const w = Array.isArray(words) ? words : []
  // 守卫三项**逐字**取自原先两份副本（`headEnd > 0 && headEnd < w.length` 的写法也一并
  // 保留：`commandHeadEnd` 恒返回 number，但逐字保留可让「非数字 headEnd」这类异常输入
  // 上的行为也与改动前**逐字相同**，不必依赖「不可达」这一论证）。
  if (headEnd > 0 && headEnd < w.length
    && String(w[headEnd - 1]).charCodeAt(0) === 45
    && !isPrivCommandValueFlag(String(w[headEnd - 1]))) {
    let headFull = 0
    // `Number.isNaN` 一并挡掉：`typeof NaN === 'number'` 为真，不挡会把 NaN 当合法提示用
    // （取大式随即得 NaN ⇒ 落回段首解析），而调用方违约时正确的退化是**走惰性**。
    if (typeof headFullHint === 'number' && !Number.isNaN(headFullHint)) headFull = headFullHint
    else { try { headFull = commandHeadEndFull(w) } catch (e) { headFull = 0 } }
    return headCommandNameOf(w, headEnd > headFull ? headEnd : headFull)
  }
  return headCommandNameOf(w, headEnd)
}

/**
 * 裸跑交互类判据（`BARE_INTERACTIVE`）—— **形态**判据：该段没有任何非选项实参。
 *
 * 「非选项实参」= 不是 `-`/`--` 开头、不是 cmd 风格开关（`/s`，仅 Windows）、
 * 不是重定向、不是 `NAME=value` 赋值形态、也不是命令名自身。
 *
 * 判据必须与 blastRadiusOfSegment 的循环同源（那里就是按这几条跳过非目标的），
 * 否则会出现「判档认为没有目标、形态判据认为有目标」的分叉。
 */
function hasNoOperand(words, opts) {
  const w = Array.isArray(words) ? words : []
  let headEnd = 0
  try { headEnd = commandHeadEnd(w) } catch (e) { headEnd = 0 }
  // 命令头的**完整**结束下标（额外认识语句关键字）—— 见 commandHeadEndFull。
  // 为什么两处都要：`headEnd` 是 blastRadiusOfSegment 消费的那一份（它不跳关键字，
  // 靠 mayNeedBlastCheck 预筛处理），`headFull` 是本判据真正需要的「命令头到哪儿为止」。
  // 取两者**较大者**：两个判据都是「这些位置不是操作数」，取并集只会更保守地跳过命令头。
  let headFull = 0
  try { headFull = commandHeadEndFull(w) } catch (e) { headFull = 0 }
  const skip = Object.create(null)
  // ── 三处写入统一**小写**，查表处双侧归一（见下面的 `skip[token] || skip[token.toLowerCase()]`）
  // `headCommandNameOf` 返回的命令名是**已小写**的（`commandNameOf` 末尾 toLowerCase），
  // 而循环里查表用的是**原始词元**。`['time','Diskpart']` 的 skip 里是 `diskpart`、
  // 查表查 `Diskpart` → 不命中 → 判 false（该段不归 unknown）。Windows 命令名大小写不敏感，
  // `Diskpart` / `PARTED` 是日常写法。实测（45 关键字 × 3 命令 × {小写,首字母大写} = 270 条）：
  // 小写 0/135 allow、**大写 129/135 allow**，而 `time diskpart` 是 ask。
  try {
    const un = unwrapWords(w)
    if (un && Array.isArray(un.words) && un.words.length) skip[String(un.words[0]).toLowerCase()] = 1
  } catch (e) {}
  if (w.length) skip[String(w[0]).toLowerCase()] = 1
  // 命令域判据要的是**命令头位置上的命令名**（剥 wrapper 与提权前缀）—— 见 headCommandNameOf。
  // 复用已算出的 headEnd，避免在判定热路径上把同一趟扫描做两遍。
  //
  // ── ⚠️ 但 `headEnd` **不等于**「命令头结束位置」：普通选项词元上必须改用 `headFull` ────
  // `commandHeadEnd` 的 ① 分支经 `skipPrefixArgs` 把 `-l` 这类**普通选项**吃掉并**停在其上**
  // ⇒ `w[headEnd - 1]` 是 `-l` 而不是命令名 ⇒ 本行把 `'-l'` 当 `cmdName` 传给
  // `isCmdStyleSwitch`。而 `GROUP_OF_LABEL['-l']` 查不到 → 走「认不出命令名 ⇒ **不消费半径**」
  // 兜底 ⇒ **目标实参被当成 cmd 风格开关跳过**（`/data` 命中 `/^[/-]/` 那条）⇒ 循环里
  // `i < headFull` 之外再无「非选项实参」⇒ 本函数由 false 变 **true** ⇒ 该段由半径档
  // `outside` 被替换成 `unknown`。
  //
  // ⚠️ 触发条件**比「22 个普通选项 × 任意操作数」窄得多**，唯一成因是
  // 「`su`/`runas` 的**操作数** basename 恰好命中 `STATEMENT_KEYWORDS`」：
  // `su` 的操作数由 `privOperandSkip` 的 `isPrivOperandWord` 判，而该判据对
  // 「basename 在关键字表里」的词元返回 false（不跨）⇒ 段首 `su` 走 ② 只推 1 个词元，
  // 下一轮 `C:/data` 的 basename `data` **命中 ① 关键字支** ⇒ 命令头越过操作数、
  // 把 `parted` 当命令名吃掉，`headFull = 4`（段长 5）—— 而 `headEnd` 仍停在 2 的 `-l`。
  // 实测 8,220 格扫描：分叉 4,816 格、涉及 86 个操作数，**「分叉但 basename 不命中
  // 关键字表」= 0**。同值（不触发）：`C:/etc`、`/etc`、`C:/tmp`、`/tmp`、`C:/Windows`、
  // `C:/users`、`root`、`x`、`A=/etc`、`A=/bin/rm`、`of=/dev/sda`、`A=C:/Windows`、
  // `A=../other` —— 全部逐字同值。**但 `C:/data` / `/data` 是现实中极常见的路径**（数据盘），
  // 且 45 个关键字里 `data`/`do`/`in`/`for`/`end`/`if`/`then`/`else`/`case`/`class`/`return`/
  // `exit`/`while`/`not`/`and`/`or`/`try`/`catch`/`finally`/`begin`/`process`/`switch`/
  // `function`/`until`/`foreach` 一大批「像目录名/用户名」⇒ 严重度仍是 **high**。
  //
  // 实测（win32、`outside=deny` 单档）：PRE `deny` → CUR `ask`（放宽）；加
  // `unknown=allow`+`priv=allow` 则由 `deny` 退化成 **allow**。同口径对拍
  // `su <操作数> <命令> <目标>`（**不带选项**）：PRE/CUR 都是 `deny` ⇒ 纯属新增分叉。
  //
  // ── 判据：`w[headEnd - 1]` 是**普通选项**时，命令名改从 `headFull` 取 ──────────────
  // **判据已抽成单点** `headCmdNameForSegment`（守卫三项、取大式、惰性说明都在那里）——
  // 本处只传已算好的 `headFull`；`blastRadiusOfSegment` 是同一函数的另一个消费点。
  // 该族历史上两次漂移都出在「同一判据两份副本、只改了一处」，故此处**不再内联**。
  const cmdName = headCmdNameForSegment(w, headEnd, headFull)
  // ── 命令名本身**必须**进 skip，否则语句关键字前缀会让整个判据 fail-open ────────────
  // 上面两个 `skip[...] = 1` 只登记 `w[0]` 与 `unwrapWords` 的首词元，而两者都**不跳语句
  // 关键字**：`['time','diskpart']` 登记的是 `time`（两次），真正的命令名 `diskpart`
  // 落进下面的循环被当成**非选项实参** → 本函数返回 false → 该段不归 `unknown`
  // → 落半径档的 `inside` → 大分类 allow 时**静默放行**。而 `diskpart` 裸跑实测是
  // `unknown`（ask）—— 加一个语句关键字就把 §5.6① 整类关掉，方向是**放宽**。
  // 实测（真实档位表、mode=allow）：42 个 STATEMENT_KEYWORDS × {diskpart,parted,dd}
  // = 129/129 全部 allow；`if true; then diskpart; fi`、`while true; do diskpart; done`
  // 整行同样 allow，而 HEAD 下 `time diskpart` 与 `diskpart` 都是 ask。
  //
  // `cmdName` 正是为此存在的：`headCommandNameOf` **会**跳语句关键字与整条前缀链
  // （见其注释），故它给出的就是命令头位置上的命令名。此前它只被传给
  // `isCmdStyleSwitch`（命令域判据），没有用来跳过命令名本身 —— 这一处补上。
  //
  // 为什么不能靠「与 `blastRadiusOfSegment` 同源」来省掉这一步：那里 `time diskpart`
  // 的段级 blast 为 null 是**预筛**（`mayNeedBlastCheck` 对纯词元直接 continue）的功劳，
  // 与「按命令名跳过」不是同一个判据，两者不同源。
  //
  // 误判面：只有「操作数恰好与命令名同名」（`diskpart diskpart`）会被多跳一个词元
  // → 返回 true → 归 `unknown`。方向是**收紧**（多问一次），可接受。
  if (cmdName) skip[cmdName] = 1
  for (let i = 0; i < w.length; i += 1) {
    // 命令头（含语句关键字之后的整条前缀链 + 命令名）按**位置**跳过 —— 见 headFull 的注释。
    // 只按词元值跳过是不够的：`time env diskpart` 里的 `env` 不在 skip 表里，
    // 而它既不是选项也不是赋值，会被当成**非选项实参**。
    if (i < headEnd || i < headFull) continue
    const token = String(w[i])
    // 双侧查表：写入侧已统一小写，这里再对原始词元做一次小写归一，
    // 故 `Diskpart` / `PARTED` 与 `diskpart` 同结论（Windows 命令名大小写不敏感）。
    if (skip[token] || skip[token.toLowerCase()]) continue
    if (token.charCodeAt(0) === 45) continue
    if (isCmdStyleSwitch(token, opts, cmdName)) continue
    if (/^[<>]/.test(token)) continue
    // ── `NAME=value` 在**命令名之后**是普通实参，不是赋值前缀 ────────────────────
    // 与 `blastRadiusOfSegment` 的循环同判据（那里有对应注释）：删除类命令恰恰用
    // 这种形态表达目标 —— `dd of=/dev/sda` 的 `of=/dev/sda` **就是**操作数。
    // 把它当赋值前缀跳过会让 `dd of=/dev/sda` 判成「没有实参」→ 归 `unknown`，
    // 而它的目标明明判得出来（实测 system|/dev/sda）—— 那是**把已知的更严重结论
    // 换成更模糊的结论**，方向错了（与「parted 有实参时不归 unknown」同一条理由）。
    //
    // 「命令名之前」已由上面的 `i < headEnd` 满足：前导赋值前缀都在命令头范围内。
    if (/^[A-Za-z_][A-Za-z0-9_]*=/.test(token)) {
      if (token.slice(token.indexOf('=') + 1)) return false
      continue
    }
    return false
  }
  return true
}

/**
 * 该段是否属于「裸跑交互 / 参数非路径」那一类 —— 归 `unknown` 档的补充判据（§5.6）。
 *
 * 三种形态，各按各的判据：
 *   · `BARE_INTERACTIVE`（diskpart / parted / dd）—— **形态**判据：无非选项实参时归 unknown。
 *     有实参则走半径档（`parted /dev/sda` 正确判 system，不被降级成「无法判定」）。
 *   · `DISKPART_SCRIPT_FLAGS` —— `diskpart /s <脚本>`：有实参，但那个实参是**脚本文件**
 *     而非操作目标，半径判据判不出脚本内容的影响。**label + flag** 判据。
 *   · `NON_PATH_ARG`（set-executionpolicy）—— **label** 判据，不看实参形态
 *     （它四种形态 blast 全 null，因为没有路径参数可判）。
 *
 * **刻意不导出**：唯一的消费方是同文件的 `tierSetOf`（与 `hasNoOperand` 同处置）——
 * 少一个公开面就少一份漂移，导出它只会让「档位判据有几处」这个问题多一个答案。
 *
 * @param {string[]} labels segmentLabels(words) 的结果
 * @param {string[]} words 段词元
 */
function isUnknownTierSegment(labels, words, opts) {
  const list = Array.isArray(labels) ? labels : []
  const w = Array.isArray(words) ? words : []
  // ── 惰性记忆化：下面两件事都**只依赖 (w, opts)**，与 label 完全无关 ──────────────
  // 它们此前写在 label 循环**内部**，于是每个 label 各算一次；而 `segmentLabels` 对
  // 每个 `find -exec <cmd>` 都 push 一个 label 且**不去重**（去重只在 seg.opaque 分支做），
  // 故 `labels.length` 随 `-exec` 个数线性增长 —— 两趟 O(词元数) 的扫描 × O(labels)
  // = **O(n²)**。触发形态是常规写法，不是构造输入：
  //     find . (-exec diskpart {} +) × N
  // 实测（`tierSetOf` 单次调用，posix 钩子）：diskpart N=1000 → 49 ms、2000 → 179、
  // 4000 → 698、8000 → **3577 ms**（每翻倍 ×4.0，标准平方）；`-exec dd` × 8000 → 864 ms。
  // 对照 `-exec rm {} +`（`rm` 不在 BARE_INTERACTIVE）N=8000 仅 **4 ms**（线性）——
  // 确认平方因子就是「每个 BARE label 一次 hasNoOperand」。
  //
  // **提到循环外与「命令头结束下标」完全兼容**：`commandHeadEnd` / `commandHeadEndFull`
  // 同样只吃 (w)，故修复 1 的前缀链登记不需要（也不能）在 label 循环内做 —— 若做在循环内，
  // 就与「提到循环外」直接冲突。两处判据各自内部记忆化，循环内只剩查表。
  let noOperandMemo = null
  const bareHasNoOperand = () => {
    if (noOperandMemo === null) {
      try { noOperandMemo = hasNoOperand(w, opts) } catch (e) { noOperandMemo = false }
    }
    return noOperandMemo
  }
  let scriptFlagMemo = null
  const hasScriptFlag = () => {
    if (scriptFlagMemo === null) {
      scriptFlagMemo = false
      // diskpart /s <脚本>：实参里有 /s。
      // **查表前先小写**：Windows cmd 的开关**大小写不敏感**，而本表只登记了小写形态，
      // 于是同一个「执行分区脚本」的操作只因开关大小写不同就绕过 §5.6① 的闸门。
      // 实测（默认配置）：
      //     diskpart /s script.txt → unknown（ask）
      //     diskpart /S script.txt → inside（**allow**）← 闸门被绕过
      //     diskpart -S script.txt → 同上
      // 口径与同文件的 isCmdStyleSwitch 一致（那里用 `/[a-z]/i` 判开关）。
      for (let i = 1; i < w.length; i += 1) {
        if (DISKPART_SCRIPT_FLAGS[String(w[i]).toLowerCase()]) { scriptFlagMemo = true; break }
      }
    }
    return scriptFlagMemo
  }
  for (const l of list) {
    const n = String(l == null ? '' : l).trim().toLowerCase()
    if (!n) continue
    if (NON_PATH_ARG[n]) return true
    if (BARE_INTERACTIVE[n] && bareHasNoOperand()) return true
    // diskpart /s <脚本>：label 是 diskpart（或路径形态归一后同名），实参里有 /s
    if (n === 'diskpart' && hasScriptFlag()) return true
  }
  return false
}

/**
 * 档位 → 双语短标签（弹窗用）。与 `codeLabel` **并列，语义不同**：
 *   `codeLabel` 回答「为什么被标出来」（破坏性命令 / 无法解析 / 重定向到工作区外）；
 *   `tierLabel` 回答「**哪一档在管它**」（大范围 / 提权 / 结束进程…）。
 *
 * 为什么必须分开（而不是扩 `codeLabel`）——三个冲突：
 *   ① **基数不同构**：`code` 是单值，档位是集合（`sudo rm -rf /etc` 同时命中 wide + priv），
 *      填哪个都会漏掉另一个。
 *   ② **`code` 还承担非档位语义**：`destructive` 是**类别**、`unparsable` 是**解析状态**、
 *      `write-outside` 是**另一维度**。混进档位后消费方必须写成
 *      「若 code 是 unparsable → 按解析状态处理；否则若 code 是 write-outside → 按另一维度处理；
 *        剩下的才当档位」—— 那个 if 链本身就是「字段混了两种东西」的信号。
 *   ③ **改动面**：`test/shell-parse.mjs` 有 37 处 `.code` 断言，它们把 `code` 当作判定结果的
 *      **稳定标识**在做回归。改语义不是改数字，是逐条判断每条断言原本在守什么。
 *
 * 判据用「未来新增一档」衡量维护成本：扩 `code` 要逐条检查所有消费方（37 处断言 + 2 处调用点
 * + 决策日志），独立 `tiers` 只需加一个档位名 + 一句文案。**扩 `code` 的成本随档位数增长，
 * 独立字段不增长** —— 这是选后者的理由。
 */
export function tierLabel(tier) {
  if (tier === 'wide') return bi('大范围', 'Wide')
  if (tier === 'outside') return bi('工作区外', 'Outside')
  if (tier === 'unknown') return bi('无法判定', 'Unknown')
  if (tier === 'proc') return bi('结束进程', 'Kill process')
  if (tier === 'power') return bi('关机/重启', 'Power')
  if (tier === 'priv') return bi('提权', 'Privilege')
  if (tier === 'reg') return bi('注册表', 'Registry')
  // `inside` 返回 null —— 它不该出现在弹窗上：它是唯一跟随大分类的档，
  // 区内无害操作被问了才需要标注，而那种情况本来就不该弹窗。
  return null
}

// 「可能逃出工作区」的词元形态：分隔符、盘符、家目录、变量、通配符，或以 `.` 开头
// （`.`、`..`、`.git`）。纯词元（`build`、`lib`、`file.js`）在工作区内判档恒为 inside，
// 用于判档前的廉价预筛 —— 见 blastRadiusOfSegment 的循环。
const MAY_ESCAPE_RE = /[\\/:~$*?]|^\./

// 预筛**不能**只看 MAY_ESCAPE_RE：BARE 系统目录名（`Windows`、`System32`、`ProgramData`…）
// 刻意不含分隔符（那正是该表存在的理由，见 WIN_SYSTEM_BARE_RE 的注释与测试 L11），
// 于是它们会被预筛跳过、判档静默 —— 实测 `blastRadiusOf('Windows')` = system，而
// `blastRadiusOfSegment(['rm','-rf','Windows'])` = null，即该表唯一的调用点上被预筛抵消。
// 预筛是**纯性能优化**，绝不能改变结论：凡可能被任何判据判出非 inside 的词元都必须走完整判档。
//
// ── 预筛**不得**自带一份名单 ────────────────────────────────────────────────────
// 这里曾手抄一份 BARE 名单（`/^(?:windows|winnt|program files|programdata|…)/`），
// 与 WIN_SYSTEM_BARE_RE 漂移了一项：判档表写的是 `program files(?: \(x86\))?`，
// 手抄时写成裸 `program files`，于是 `Program Files (x86)` 被判档表判 system、
// 却被预筛跳过 —— 该表唯一的段级调用点上判档静默。实测（平台 win32）：
//   blastRadiusOf('Program Files (x86)')                  = system
//   blastRadiusOfSegment(['rm','-rf','Program Files (x86)']) = null
// 端到端 `rm -rf "Program Files (x86)"`（pwsh/bash 两个词法器都把它并成单个词元）
// 段 code=destructive 而 blast=null：删 Windows 最典型的系统目录之一，弹窗零警告；
// 仅差一个词的 `"Program Files"` 却有 system 警告。
//
// 两份名单必然再次漂移，故判据改为**直接问判档表**：复用 isSystemDir，预筛不再持有名单。
// 代价是每词元多一次正则（原预筛那一次正则同样要跑），量级不变。

/**
 * 「**可能**是工作区根」的形态判据（`blastRadiusOfSegment` 问 `isWorkspaceRoot` 钩子前的预筛）。
 *
 * 与 `mayNeedBlastCheck` 同性质：纯性能优化，**不得改变结论**，故宁可放行（多问一次钩子）
 * 也不漏判 —— 但放行的形态必须真的**可能**归一到根。判据（逐条都有实测依据）：
 *   · 绝对形态（前导分隔符 / 盘符）—— 可能恰好就是根（§5.5 覆盖表里的绝对路径写法）；
 *   · 末段是点段（`.` / `..`）—— `pathResolve` 会把点段消掉，可能一路抵消回根
 *     （`a/..` 归一后**就是**根，而它此前只在「末段是点段」这条上被放行）；
 *   · 整串只由分隔符与点段组成（`.` / `./` / `.\` / `./.`）—— 归约结果就是 `.`；
 *   · **每一段都是点段/空段或整段纯星号，且至少有一段是纯星号**（`*` / `./*` / `.\*` /
 *     两段纯星号）—— 只有这种形态的展开结果才覆盖到「根下的全部条目」。
 *
 * ── 为什么不能再放行「任意含通配符的词元」（原判据的 `|| /[*?]/.test(token)`）────────
 * `globRootOf` 把 `*.log` / `build*` / `?` / `a?.txt` **一律**归约成 `.`（第一个含通配的
 * 段之前什么都不剩），于是宿主 `isWorkspaceRoot('.')` 恒真 —— 判成 `workspace-root` →
 * `radiusTierOf` 映射到 `wide` 档。实测：`rm -rf *.log` / `rm -rf build*` / `rm -rf ?` /
 * `rm -rf ./*.log` / `del /f /s /q *.tmp` 全部 `action=ask`、`tiers=["wide"]`、
 * `blast={level:'workspace-root',path:'.'}`，而 `rm -rf ./build`、`rm -rf node_modules`
 * 仍是 allow/inside。把 `wide` 设为 deny 的用户，`rm -rf *.log` 会被**直接拒绝**。
 * 这与 §5.5 的覆盖表（命中仅 `.` / `./` / `*` / `./*` / `.\*` 与绝对根；`./build`、`build`、
 * `src/tmp` 明确不命中）以及 client.js 文案 `app.blast.workspaceRoot`（「目标是本项目根目录
 * —— 整个项目的文件都会被删除」）都矛盾 —— `rm -rf *.log` 删不掉整个项目，那条文案对它
 * 就是假话，而假警告会让真警告被忽略。
 *
 * 判据的关键是**看段本身是否纯通配**，而不是「词元里含不含通配符」：带锚点的通配
 * （`*.log`、`build*`、`a?.txt`）归约结果同样是 `.`，但展开结果只覆盖部分条目。
 * 顺带收益：`./x` 一族（`./build`、`./b/f1`…）不再白问一次钩子 —— 宿主那份
 * `isWorkspaceRoot` 要做 norm + pathResolve + 两次 toLowerCase，而归一后它们必然带一个
 * 非空普通段、钩子恒 false。
 *
 * @param {string} token 待判词元
 */
function mayBeWorkspaceRootShape(token) {
  const t = String(token == null ? '' : token)
  if (!t) return false
  // 绝对形态：可能恰好就是根（`<root>`、`/`、`C:\`、`X:/*`）
  if (/^[/\\]/.test(t) || /^[A-Za-z]:/.test(t)) return true
  const segs = t.split(/[\\/]/)
  // ── ① 末段是点段（`a/..`、`x/./..`）→ pathResolve 消掉后可能一路抵消回根 ─────────────
  // **必须先跳过尾随空段再取末段**：`globRootOf` 不剥尾随分隔符，故
  // `'a/../'.split(/[\\/]/)` = `['a','..','']` —— 末段是**空串**。此前只认「末段**恰好等于**」，
  // 于是 `a/../` / `a/..//` 被判 allDots=false、无纯星号段 → 预筛返 false → **钩子根本不被调用**
  // → 段级 blast 落 inside。而 `blastRadiusOf('a/../')` 归一后是 `{level:'inside', path:'a/..'}`，
  // 宿主 `isWorkspaceRoot('a/..')` 本会判真 —— 即**整个工作区**：实测 mode=allow 下
  // `rm -rf a/../` 静默放行，而 `resolve('a/../')` 就是工作区根（后果与 `rm -rf .` 同）。
  // 只跳过**尾随**空段（不是忽略全部空段），故普通尾斜杠路径（`build/`、`./b/f0/`）的末个
  // 非空段仍是普通段 → 不放行，不会白问钩子。
  let end = segs.length - 1
  while (end >= 0 && segs[end] === '') end -= 1
  if (end >= 0 && (segs[end] === '.' || segs[end] === '..')) return true
  // ── ② `..` 弹栈归约：归约后**为空或全是纯星号段**才放行 ───────────────────────────
  // ① 只认「末个非空段是点段」，救不到末段是通配的形态：`a/../*` 的末段是 `*` 而非空串
  // 也非点段，但它归约后就是 `*`（= 根下全部条目），与 `rm -rf *` 同义，必须放行。
  // 判据必须**带 `..` 弹栈**，不能只看「各段自身是不是点段/纯星号」：`a/../*` 里的 `a`
  // 既非点段也非纯星号，只有被 `..` 弹掉之后才看得出栈上只剩 `*`。
  // 带**锚点**的通配（`*.log`、`build*`、`a?.txt`）会留在栈上 → 不满足「全是纯星号段」→
  // 不放行，故本趟不会重蹈「含通配就放行」的误判（`*.log/../*` 是例外：`*.log` 被 `..`
  // 弹掉后栈上确实只剩 `*`，那本来就是根下全部条目）。
  const stack = []
  for (const s of segs) {
    if (s === '' || s === '.') continue
    if (s === '..') {
      // 只在栈顶是普通段时弹；栈顶已是 `..` 时再压一个（`../../` 指向根之外，不是根）
      if (stack.length && stack[stack.length - 1] !== '..') stack.pop()
      else stack.push('..')
      continue
    }
    stack.push(s)
  }
  if (stack.length === 0) return true
  // ── ③ `..` 抵消后**回到根**的一族（`../<rootName>`、`sub/../../<rootName>`）──────────
  // ①② 都救不到这一族：末个非空段是**普通段**（`<rootName>`，不是点段也不是纯星号），
  // 而 `..` 弹栈归约后栈上仍留着那个普通段（`['dsh-permgate']`）—— 于是本函数返 false
  // → **钩子根本不被调用** → 段级 blast 落 inside。
  //
  // 而它**恰恰就是工作区根**：`root = <root>` 时，`../<basename>` 归约后
  // 正是 `<root>` 本身。宿主那两条钩子对同一路径给出的正是那个「既不算外、
  // 也不算根」的组合 —— `isOutside` 判 `a === r` 返 **false**（等于根 → 不算「外」），
  // 于是它落进 inside 静默档，而不是 outside。这是 §5.5 注释里点名要防的那一类分叉。
  //
  // 实测（root = `<root>`、八档 inside=allow 其余 ask、真实宿主钩子口径）：
  //     rm -rf .                → ask  tiers=['wide']            blast=workspace-root  hookCalls=1
  //     rm -rf ../other         → ask  tiers=['outside']         blast=outside         hookCalls=0
  //     rm -rf ../dsh-permgate  → **allow** tiers=['inside']     blast=null            hookCalls=0  ← 缺陷
  // 同族（`./../<root>`、`sub/../../<root>`、`..//<root>`、`../<root>/`）**全部** allow。
  // 后果：mode=allow 下在子目录/兄弟目录里回删项目（`rm -rf ../dsh-permgate` 是自然写法）
  // **静默删除整个项目** —— 弹窗 0 次、日志无记录，而 `rm -rf .` 会 ask。
  //
  // ── 为什么判据必须带 `!/[*?]/` ─────────────────────────────────────────────────
  // 单纯的「含 `..` 段即放行」会**打破既有测试 34c**：`*.log/../../*`、`build*/../../*`、
  // `?/../../*` 归约后栈上只剩 `*`，会被 `allStarStack` 那一支（本行之上）判成 workspace-root
  // —— 而它们是**越出根之外**（`../..` 指向根的上两级），实测 34c 的三条会全部变红。
  // 根因是 `globRootOf` 在**首个通配段**截断（`design-issues.md` B1 的设计张力），
  // 故含通配的子族不在此处放行，交由既有判据处理（34c 保持绿）。
  //
  // 判据用「`segs` 里有没有 `..` 段」而不是「`t` 里含 `..` 子串」：`a..b` 这种**普通名字**
  // 不含 `..` 段，不该被放行（那是白问一次钩子的纯开销）。
  // 过度收紧扫描实测**零变化**：`./build`、`build`、`src/tmp`、`../other`、`..`、`../../other`、
  // `*.log`、`build*`、`a/../b`、`x/../y/z`、`./a/./b`、`a/b/c` 全部与改前逐字同值。
  if (segs.indexOf('..') !== -1 && !/[*?]/.test(t)) return true
  // ── ④ `..` 弹栈后**末段是纯星号**、且末段之前无通配的一族（`../<rootName>/*`）────────
  // ③ 那条 `!/[*?]/` 守卫是为保 34c（`*.log/../../*` 归约后栈上只剩 `*`）而设，而它把
  // **同族的通配形态**也一并挡在门外：`../<rootName>/*` 归约后栈是 `['..','<rootName>','*']`，
  // 其展开结果**就是**根下的全部条目 —— 与 `rm -rf *` 同义。
  //
  // 实测（root = `X:/ws`、八档 inside=allow 其余 ask、win32、真实宿主钩子口径）：
  //     rm -rf ../ws          → ask  tiers=['wide']    blast=workspace-root  hookCalls=1
  //     rm -rf ../ws/*        → **allow** tiers=['inside'] blast=null       hookCalls=**0**  ← 缺陷
  // 同族（`./../ws/*`、`sub/../../ws/*`、`..//ws/*`、`../ws/*//`、`rmdir /s /q ../ws/*`、
  // `Remove-Item -Recurse -Force ../ws/*`）**全部** allow —— 即「在子目录里用 `../<项目名>/*`
  // 回删整个项目」静默删除，而只少一个 `*` 的 `rm -rf ../ws` 会 ask。
  // 第二后果：`blastRadiusOfCommandPattern('rmdir /s /q ../ws/*')` 也是 null（对照
  // `rm -rf *` = broad、`rm -rf a/../*` = workspace-root），即**例外标注**（面板事后发现
  // 「我放行了删项目根」的唯一入口）对该族零标注。
  //
  // 判据的两半**都不可省**（各自有实测依据）：
  //   · **栈顶是纯星号段** —— 与 ③ 的 `allStarStack` 同口径、同一条 `/^\*+$/`；带锚点的
  //     通配（`*.log`、`build*`、`a?.txt`）不满足，故 `rm -rf ../ws/*.log` 仍不判根。
  //   · **末段之前无通配段** —— 少了它，`*.log/../../*` 一族（34c）会被误判成
  //     workspace-root：`*.log` 被两个 `..` 弹掉后栈上同样只剩 `*`（实测按原报告者字面
  //     建议构造的版本让 34c 三条**全部变红**）。34c 是「归约越出根之外」，与「回到根」相反。
  // 末段取**末个非空段**（`end`，上面已算出）：`../ws/*//` 的末个非空段是 `*` 而非空串。
  //
  // 扫描用 `indexOf` 而不是正则：与 ③ 的 `!/[*?]/.test(t)` 同判据（只判「含不含」，
  // 不判位置），且本函数在**逐词元**的判档热路径上，保持「查表 + indexOf」形态。
  if (segs.indexOf('..') !== -1 && end >= 0 && stack.length
    && /^\*+$/.test(stack[stack.length - 1])) {
    let starOnly = true
    for (let k = 0; k < end; k += 1) {
      const s = segs[k]
      if (s.indexOf('*') !== -1 || s.indexOf('?') !== -1) { starOnly = false; break }
    }
    if (starOnly) return true
  }
  let allStarStack = true
  for (const s of stack) {
    if (!/^\*+$/.test(s)) { allStarStack = false; break }
  }
  if (allStarStack) return true
  let sawStar = false
  let allDots = true
  for (const s of segs) {
    if (s === '' || s === '.' || s === '..') continue
    allDots = false
    // 带锚点的通配（`*.log`、`build*`、`a?.txt`、`?`）不是纯通配 → 展开结果到不了根
    if (!/^\*+$/.test(s)) return false
    sawStar = true
  }
  return allDots || sawStar
}

/** 该词元是否必须先走完整判档（预筛为「可能危险/可能非 inside」时返回 true）。 */
function mayNeedBlastCheck(token, platform) {
  if (MAY_ESCAPE_RE.test(token)) return true
  // ── cmd 风格变量（`%TEMP%` / `%USERPROFILE%` / `%SystemRoot%`）────────────────
  // 它既不含 `$`、也不含反引号，故 MAY_ESCAPE_RE 不命中；而它的**形态是纯词元**
  // （字母 + 两个 `%`），于是预筛把它当「工作区内的相对路径」跳过 —— 判档静默。
  // 实测（修复前）`blastRadiusOf('%USERPROFILE%')` = `{level:'inside'}`，
  // 且 win32 分支只查 isSystemDir，两条路都不放行 → 段级 blast 为 null、tier 为 inside
  // → 默认配置下 **allow**。而 `%USERPROFILE%` 展开后正是用户家目录（对应 home 档），
  // 即「删自己的用户配置目录」被判成「工作区内删个文件」。`del %USERPROFILE%` 改前是 ask。
  // 判据与 blastRadiusOf 的短路同源（同一个 CMD_VARIABLE 正则），故不会两处漂移。
  if (CMD_VARIABLE_RE.test(token)) return true
  // 非 Windows 平台不会命中 BARE 表（isSystemDir 在 posix 下只查 POSIX 表），无需放行
  if (platform === 'posix') return false
  // 平台未知时两张表都查（与 isSystemDir 的 fail-safe 方向一致）：宁可多判一次档，
  // 不可把一条系统目录警告静默吃掉。
  if (platform !== 'win32') {
    return WIN_SYSTEM_BARE_RE.test(token.replace(/^[a-z]:/i, '').replace(/^\/+/, ''))
      || POSIX_SYSTEM_ROOT_RE.test(token.replace(/\\/g, '/'))
  }
  // 判据与 isSystemDir 完全同源：不再各写一份名单。
  return isSystemDir(token.replace(/\\/g, '/'), 'win32')
}

/**
 * 该词元在 `blastRadiusOfSegment` 的判档循环里**会不会产出半径档**（预筛 + 两条
 * 「预筛之前」的产档路径合并成一条**上界**判据）。
 *
 * ── 为什么不能只问 `mayNeedBlastCheck` ─────────────────────────────────────────
 * `mayNeedBlastCheck` 是 `:4996` 那条廉价预筛的判据，而那条预筛在循环里**不是第一条
 * 产档路径** —— 它前面还有两条同样会产出半径档、且对「纯词元」形态照样成立的分支：
 *   · 含空格词元的**引号命令行递归支**（`:4922-4963`）：`token.indexOf(' ') !== -1` 且
 *     切分后首词是破坏性命令名或解释器（`NESTED_SHELLS`）时递归判档；
 *   · **`NAME=value` 支**（`:4975-4986`）：取 `=` **右侧值**再判档。
 * 两者都 `continue`，**都在预筛之前**，故「`mayNeedBlastCheck` 返假」**推不出**
 * 「该词元不产半径档」。把它当必要条件用会得到**真实放宽**（实测见 `privValueFlagBetween`）。
 *
 * ── 判据：三条路径的**上界**（返真 ⇒ 更保守 ⇒ 只会收紧）──────────────────────────
 *   · 含空格的词元 —— 一律视为「会判档」。引号支的精确判据需要 `split(/\s+/)` + 逐词
 *     `commandNameOf`/`isDestructiveLabel`/`NESTED_SHELLS` 查表，而本函数的调用点是
 *     **逐词元**的贪婪扫描（`isPrivOperandWord`）与守卫（每次调用至多一次），
 *     O(1) 纪律不允许分配；且**收窄方向是放宽**（少认一次 ⇒ 多跨一次），
 *     而多认的代价只是畸形写法多问一次（收紧方向，永不违反策略）。
 *     注意 `indexOf(' ')` 是既有形态（`:4922` 同一判据），不新造正则。
 *   · `NAME=value` —— 取 `=` 右侧值再问同一个预筛（与 `:4976` 的 `token.slice(indexOf('=') + 1)`
 *     同源）。空值（`FOO=`）不是目标，与 `:4978` 的 `if (!rhs) continue` 同处置。
 *   · 其余 —— 原样交给 `mayNeedBlastCheck`（纯词元）。
 *
 * @param {string} token 已 `String()` 过的词元
 * @param {'win32'|'posix'|undefined} platform 同 `mayNeedBlastCheck`；`undefined` = 两张表都查
 */
function mayYieldRadiusTier(token, platform) {
  if (token.indexOf(' ') !== -1) return true
  const eq = token.indexOf('=')
  if (eq > 0 && LEAD_ASSIGN.test(token)) {
    const rhs = token.slice(eq + 1)
    return !!rhs && mayNeedBlastCheck(rhs, platform)
  }
  return mayNeedBlastCheck(token, platform)
}

/**
 * 判定一个路径目标的爆炸半径档位。
 *
 * @param {string} raw 目标路径原文（未展开；本函数内部做 `~` 展开与 glob 归约）
 * @param {{ home?: string, userHome?: string, platform?: 'win32'|'posix', isOutsideWorkspace?: (p:string)=>boolean }} opts
 *   home     —— DSH home，仅供 expandTilde 展开 `~` 用；
 *   userHome —— **用户家目录**（`~` 的真实落点），`home` 档的判据用它；缺省时回落 home；
 *   platform —— 决定查哪一套系统目录名单、以及 `/x` 是不是 cmd 开关（**方言不能代替它**）；
 *   isOutsideWorkspace —— 宿主注入的「工作区外」判据（口径唯一，本模块不自己算）。
 * @returns {{ level: 'drive-root'|'system'|'home'|'outside'|'inside', path: string }|null}
 *   null = 该目标不是路径形态（如 `*`、变量），无从判断 —— 此时**不猜**，返回 null。
 *   level 含义：drive-root（整盘）> system（系统目录）> home（家目录）> outside（工作区外）
 *   > inside（工作区内，无警告）。
 */
export function blastRadiusOf(raw, opts) {
  const o = opts || {}
  const t = String(raw == null ? '' : raw).trim()
  if (!t) return null
  // 变量 / 命令替换 / 未展开的 glob 顶层：读不出具体位置，不猜（返回 null 而不是硬套一档）。
  // 注意 glob 要**先归约再判**：`B:\*` 的归约结果是盘根 B:，正是最危险的那一档，
  // 若因为「含通配符所以不判」跳过它，恰好漏掉最该警告的形态。
  //
  // ── 但 `$` 短路**不得吞掉系统目录名单里的项** ─────────────────────────────────
  // 名单里明确收了 `$Recycle.Bin`（WIN_SYSTEM_ROOT_RE / WIN_SYSTEM_BARE_RE 的
  // `\$recycle\.bin`），而它在 cmd/PowerShell 里是**字面目录名**、不是变量 ——
  // 短路写在系统目录判定之前，那个名单条目就永远判不出来（实测修复前
  // `blastRadiusOf('C:/$Recycle.Bin')`、`blastRadiusOfSegment(['rm','-rf','C:/$Recycle.Bin'])`
  // 全为 null，删回收站零警告）。故先给系统目录一次机会，再走变量短路。
  //
  // 只对「整串就是系统目录形态」放行（与 isSystemDir 同源），故 `$env:TEMP`、`${x}`、
  // `` `pwd` `` 这些真变量照旧返回 null —— 它们的形态不可能命中系统目录名单。
  //
  // **判据必须直接问 isSystemDir，不能在这里手抄一份平台分派**：这里曾写着
  //   `o.platform === 'posix' ? POSIX_SYSTEM_ROOT_RE.test(...) : (WIN_ROOT || WIN_BARE)`
  // 与 isSystemDir 已经不是同一个判据，两个方向都漏：
  //   · 非 posix 分支漏掉 win32 下还会查的 `USER_ROOT_RE` —— 实测
  //     `blastRadiusOf('C:/Users/$env:USERNAME')` = null，而 `blastRadiusOf('C:/Users/me')`
  //     = system；`rm -rf C:/Users/$env:USERNAME`（pwsh 里正是「删自己的用户配置目录」）
  //     零警告，而同义的字面写法有警告。
  //   · 漏掉「平台未知时查 POSIX 表」这条 fail-safe —— 实测平台未知时
  //     `blastRadiusOf('/etc/x')` = system 而 `blastRadiusOf('/etc/$x')` = null。
  // 这与本文件 1477-1489 行「预筛不得自带一份名单…判据改为直接问判档表：复用 isSystemDir」
  // 是同一种漂移，只是当时漏改了这一处。isSystemDir 内部已处理 bare 与前缀剥离，
  // 故这里直接传 dollarFree 即可。
  const dollarFree = t.replace(/\\/g, '/')
  if (/[$`]/.test(t)) {
    if (!isSystemDir(dollarFree, o.platform)) return null
  }
  // ── cmd 风格变量（`%TEMP%` / `%USERPROFILE%` / `%SystemRoot%`）────────────────
  // 与 `$` / 反引号**同处置**：它的值在本模块里读不出（本模块不做求值），故不能拿字面量
  // 去判「工作区内还是外」。不放行的后果实测：`blastRadiusOf('%USERPROFILE%')` 返回
  // `{level:'inside'}` —— 而 `%USERPROFILE%` 展开后是**用户家目录**（home 档），
  // `rm -rf %USERPROFILE%` / `del %USERPROFILE%` 于是落 inside 档、默认配置下静默放行。
  // 这是「不猜」（与 `$TARGET` 同一条契约：返回 null，由段级汇总改判 `unknown`）。
  //
  // 与上面 `$` 分支同一形状：**先给系统目录一次机会**（`%SystemRoot%` 这种形态若整串命中
  // 名单则照旧判 system），再走变量短路 —— 否则名单条目会被短路吃掉。
  // 注意正则与词法器共用同一个 `CMD_VARIABLE`（见 CMD_VARIABLE_RE），不手抄一份。
  //
  // ── 但这条短路**只在 cmd 语义下成立**，必须按平台门控 ─────────────────────────
  // `%` 在 POSIX 上根本不是变量语法（bash 里 `%` 是普通字符），`a%b%c`、`x%y%z.txt`、
  // `foo%bar%baz` 就是普通文件名。而 `CMD_VARIABLE_RE` 是**非 sticky 的 `.test()`**：
  // 只要串里**任意位置**有两个 `%` 夹一个字母就命中，与「整串是不是一个变量」无关 ——
  // 于是 posix 下这一族文件名全被判成「读不出」→ 段级 blast 由 inside 改判 unknown
  // （实测 `rm -rf a%b%c` 由 allow 变 ask）。方向虽是收紧，但这是「把合法路径误判为
  // 读不出」的可用性回归，根因是 `o.platform` 就在手边却没参与判据。
  //
  // 门控口径与 mayNeedBlastCheck / isCmdStyleSwitch 一致：**只有明确 posix 才关掉**
  // 这条 Windows 专有判据；平台未知时保留它 —— 与 isSystemDir「未知时两张表都查」
  // 同向（fail-safe）：宁可多问一次，不可把 `%USERPROFILE%` 放回 inside 档。
  if (o.platform !== 'posix' && CMD_VARIABLE_RE.test(t) && !isSystemDir(dollarFree, o.platform)) return null
  // `~` 展开必须用**用户家目录**（`userHome`）：`rm -rf ~` 删的是 `C:/Users/me`，
  // 不是 DSH home `C:/Users/me/.dsh`。旧实现直接用 `o.home`，而宿主传的是 DSH home
  // （`homeFromEnv()` 返回 `<家目录>/.dsh`），于是警告条把删除目标显示成
  // `C:/Users/me/.dsh`、`~/Documents` 显示成不存在的 `C:/Users/me/.dsh/Documents` ——
  // 审批人看到的是一个与实际删除目标不符的路径。未提供 userHome 时回落 home（兼容）。
  const expanded = expandTilde(t, o.userHome || o.home)
  if (expanded === null) return { level: 'outside', path: t }   // `~user/...` 必然是他人 home
  const g = globRootOf(expanded)
  // 统一成 `/` 分隔并去掉尾部分隔符（保留盘根形态 `c:`）。
  //
  // 尾部剥离**必须用线性 while**，不能写 `.replace(/\/+$/, '')`：V8 对该正则在
  // 「一段连续斜杠 + 非斜杠结尾」的输入上呈平方增长（`\/+$` 在每个起点回退后重新扫描
  // 整段连续斜杠）。实测单次 replace：n=5000 → 5.6 ms、10000 → 21.6 ms、20000 → 87.3 ms、
  // 40000 → 350.9 ms（倍率≈4.0，标准平方），而本函数在破坏性段的**每个词元**上都会被调用，
  // 词元内容由 AI 生成、长度无上界 —— 端到端 `rm -rf <40000 个斜杠>x`（仅 39 KB）
  // 单次判定 354 ms，同规模在本次改动前约 5 ms。这是判定热路径（tools/pre-execute），
  // 挂起即该次调用不返回。while 版本实测等价且 n=80000 时 0.005 ms。
  let p = String(g).replace(/\\/g, '/')
  let end = p.length
  while (end > 0 && p.charCodeAt(end - 1) === 47) end -= 1
  if (end !== p.length) p = p.slice(0, end)
  if (p === '') p = '/'   // `//`、`\` 归约后为空 → POSIX 根
  // ① 盘根：`B:` / `B:/` / `/`。这是最严重的一档，必须先判。
  //    注意判据是「归一后只剩盘符或为空」——`B:/proj` 不是盘根，但 `B:` 是。
  if (/^[a-z]:$/i.test(p)) return { level: 'drive-root', path: p }
  if (p === '/') return { level: 'drive-root', path: p }
  // ② 家目录本身（`~` 或它的绝对展开形态）—— 删家目录等于删用户所有配置与文档。
  //    **必须排在系统目录之前**：USER_ROOT_RE 里有 `users`，而 `C:/Users/user`（我自己的
  //    家目录）同时匹配 `users` 那一条，先判系统目录会把家目录误标成「系统目录」——
  //    实测复现（want=home got=system）。更具体的判据必须先跑，这与 glob 归约的取向一致。
  //
  //    home 的语义是**用户家目录**（`~` 展开的落点），不是 DSH home（`<家目录>/.dsh`）。
  //    调用方传错会让这一档整个失效并显示错误路径：实测传 DSH home 时 `rm -rf ~`
  //    （真删 `C:/Users/me`）显示 `C:/Users/me/.dsh`，而 `rm -rf C:/Users/me`（真删家目录）
  //    落到 system 档。`o.userHome` 优先，未提供时才回落 `o.home`（兼容旧调用方）。
  const homeAbs = String(o.userHome || o.home || '').replace(/\\/g, '/').replace(/\/+$/, '')
  if (homeAbs && p.toLowerCase() === homeAbs.toLowerCase()) return { level: 'home', path: p }
  // ③ 系统目录 —— **按操作系统查对应的名单**（见 isSystemDir 的注释：
  //    混装两套系统的名字会在两个方向上误报）。
  if (isSystemDir(p, o.platform)) return { level: 'system', path: p }
  // ④ 工作区外（复用宿主的 isOutsideWorkspace，口径唯一）
  try {
    if (o.isOutsideWorkspace && o.isOutsideWorkspace(g)) return { level: 'outside', path: p }
  } catch (e) {}
  return { level: 'inside', path: p }
}

/**
 * 一段命令里所有「删除/销毁类」目标的爆炸半径汇总。
 *
 * 只在**该段命中破坏性名单**时才调用（调用方保证）：`echo B:\` 不是删除，不该警告。
 * 目标来源是该段词元里所有像路径的实参，与 collectWritePaths 的取向一致：
 * 宁可多提几个候选去判档 —— 多判一个只会多显示一条警告，方向 fail-safe。
 *
 * **必须跳过命令名本身**（`w[0]`，以及 wrapper 之后的有效命令名）：`rm` 这个字符串
 * 会被 blastRadiusOf 当成一个相对路径，而 `isOutsideWorkspace('rm')` 对相对路径通常
 * 返回 true（它不在工作区的绝对前缀下）—— 于是 `rm -rf ./build` 会被误报成
 * 「工作区外」（实测：want=null got=outside）。命令名不是目标，这是本函数唯一容易
 * 搞错的地方，故单独用 unwrapWords 求出有效命令名并跳过。
 *
 * @returns {{ level: string, path: string }|null} 最严重的那一档（无路径目标时 null）
 */
export function blastRadiusOfSegment(words, opts) {
  const w = Array.isArray(words) ? words : []
  // 有效命令名（剥掉 wrapper 与前导赋值）：它自己不是删除目标。
  // 取整个词元集合里出现过的命令名，而不是只取 w[0] —— `env FOO=1 rm -rf /` 的有效
  // 命令名是 `rm`（第 3 个词元），只跳 w[0] 仍会把 `rm` 当成路径。
  //
  // skip 用 **Object.create(null)**，不能用 `{}`：后者继承 Object.prototype，于是
  // `skip['constructor']`、`skip['toString']`、`skip['valueOf']`、`skip['__proto__']`
  // 全部真值 —— 命令 `rm -rf constructor` 的目标会被当成「命令名」跳过，判档静默丢失。
  const skip = Object.create(null)
  // 命令头在 w 里的**结束下标**（不含）：这些位置一律不是目标。
  //
  // 为什么必须按**位置**跳而不是只按**词元值**跳：提权前缀（`sudo`/`doas`/…）不在 WRAPPERS 里，
  // 于是 `sudo /bin/rm -rf /tmp/x` 的 un.words[0] 是 `sudo`，真正的命令名 `/bin/rm`
  // 不在 skip 里 —— 它会被当成一个路径目标判档，实测得到
  // `{level:'system', path:'/bin/rm'}`：弹窗写「目标是系统目录（/bin/rm）」，
  // 而真目标 `/tmp/x` 被遮蔽（Windows 侧 `C:/Windows/System32/rm.exe` 同样误报）。
  // commandHeadEnd 已覆盖「提权前缀链 + wrapper 链 + 最终命令名」全部位置，故用它。
  let headEnd = 0
  try { headEnd = commandHeadEnd(w) } catch (e) { headEnd = 0 }
  // 有效命令名（剥掉 wrapper 与前导赋值）也登记进 skip：`env FOO=1 rm -rf /` 的有效
  // 命令名是 `rm`（第 3 个词元），只跳 w[0] 仍会把 `rm` 当成路径。
  //
  // **不再另算「命令名下标」**：这里曾经有一个 cmdNameEnd（= w.length - uw.length），
  // 配合循环里的 `if (i < cmdNameEnd) continue` 用来区分「命令名之前的 NAME=value 前缀」
  // 与「之后的 NAME=value 实参」（`dd of=/dev/sda`）。但 `headEnd > 0` 时它被赋成
  // `headEnd - 1`，而循环开头的 `if (i < headEnd) continue` 已经先吃掉了全部 i < headEnd
  // —— 那个分支恒为假，是死代码（插桩实测：62 次循环进入、命中 0 次；追踪 headEnd 与
  // cmdNameEnd 的取值，`headEnd === 0` 时 cmdNameEnd 恒为 0，故不存在「headEnd 为 0
  // 但 cmdNameEnd > 0」的可达情形）。NAME=value 的处置由下面循环里那一处判据负责，
  // 位置判据统一走 headEnd。
  try {
    const un = unwrapWords(w)
    if (un && Array.isArray(un.words) && un.words.length) skip[String(un.words[0])] = 1
  } catch (e) {}
  if (w.length) skip[String(w[0])] = 1
  // 命令域判据要的是**命令头位置上的命令名**（剥 wrapper 与提权前缀）—— 见 headCommandNameOf。
  // 复用上面已算出的 headEnd，避免在判定热路径上把同一趟 O(n) 扫描做两遍。
  //
  // ── ⚠️ 但 `headEnd` **不等于**「命令头结束位置」：普通选项词元上必须改用 `headFull` ────
  // 判据已抽成**单点** `headCmdNameForSegment`（本处与 `hasNoOperand` 共用同一个函数，
  // 那里详述了根因）；此处补的是同一处
  // 漂移的**第二个消费点**：`commandHeadEnd` 的 ① 分支经 `skipPrefixArgs` 把 `-l` 这类
  // 普通选项吃掉并**停在其上** ⇒ `w[headEnd - 1]` 是 `-l` 而不是命令名 ⇒ 本行把 `'-l'`
  // 传给 `isCmdStyleSwitch` ⇒ `GROUP_OF_LABEL['-l']` 查不到 ⇒ 走 ④ 的「认不出命令名
  // ⇒ 不消费半径」兜底 ⇒ **目标实参被当成 cmd 风格开关跳过**（`/data` 命中
  // `isCmdStyleSwitch:4413` 那条 `/` + 字母；`C:/data` 那种带第二段的词元则由 `:4422`
  // 那条拦下、本就到不了这里）⇒ 循环里再无「有警告意义」的目标 ⇒ 段级 blast 归 **null**
  // ⇒ `radiusTierOf(null)` = `inside`。
  //
  // ⚠️ 后果是**同一段两处给出不同答案**：`su -l data rm -rf /data` 在 `hasNoOperand` 侧
  // 拿到的命令名是 `rm`（`/data` 是目标 ⇒ 判 `outside`），在本函数拿到的是 `-l`
  // （`/data` 是开关 ⇒ 判 `null`）。端到端（§3.3 明文设想的 `inside=allow +
  // outside=deny + priv=allow`）：
  //     su -l data rm -rf /data   → **allow**、blast=null、弹窗 0 次
  //     su    data rm -rf /data   → **deny**（同义、只是没写那个普通选项）
  // 即用户显式写的 `outside=deny` 被一个普通选项绕过（fail-open）。
  // 实测（本文件 54584 格语料、7 配置）：tiers 差异 3084 格、blast 由 `null` 恢复为
  // `outside|…`、**有值→null = 0**；`outside=deny` 系列各 3084 格**全部由放宽转收紧**、
  // 放宽 = 0；默认配置（两侧都 ask）**0 差异**。
  //
  // 触发条件（三重合取、缺一不可）：`su`/`runas` 的**普通选项** × **操作数 basename 命中
  // `STATEMENT_KEYWORDS`** × **单段 POSIX 目标**。第一条成因与 `hasNoOperand` 的实测段
  // 一致（`su` 的操作数由 `privOperandSkip`/`isPrivOperandWord` 判，对「basename 在关键字
  // 表里」的词元返回 false ⇒ 命令头越过操作数、`headFull` 推进到 4，而 `headEnd` 仍停在 2）。
  //
  // 判据的守卫三项（含「非值选项」那一项）与取大式见 `headCmdNameForSegment` 单点，
  // 此处**不复述** —— 复述就是第二份描述，正是本族漂移的形态。
  //
  // ⚠️ **判据已抽成单点**：`headCmdNameForSegment`（守卫三项、取大式、**惰性**说明都在
  // 那里）。本处是第二个消费点，**不传**第三参 ⇒ 惰性求值路径保住：`commandHeadEndFull`
  // 是 O(n) 推进循环，只在守卫命中时才调（无条件先算实测多花 0.31 µs/段；160000 段：
  // 342.0ms → 429.7ms，惰性版 379.9ms），而两者在 24768 格上**逐格同值**。
  // 该族历史上两次漂移都出在「同一判据两份副本、只改了一处」，故此处**不再内联**。
  const cmdName = headCmdNameForSegment(w, headEnd)
  let worst = null
  // ── 三种 `null` 必须分开（§4）──────────────────────────────────────────────────
  // `blastRadiusOf` 对读不出的目标返回 `null` 是「不猜」（合理），但本函数汇总时
  // `if (!r) continue` 把三种语义**折成了一个 null**：
  //     rm -rf ./build     段级 null  ← 判过档，确认 inside —— **安全**
  //     rm -rf $TARGET     段级 null  ← 含变量，**读不出** —— **可能任意目标**
  //     diskpart           段级 null  ← 根本没有路径目标 —— 进交互
  // 前两种都落 `inside` 档（大分类 allow 时不弹窗），第三种也是。
  // **不区分就接线 = 制造新漏报**，故这里维护一个标志：非空词元被判为「读不出」时置位，
  // 最终没有任何 worst 时改判 `unknown`（而不是 null）。
  //
  // 预筛与它不冲突：`mayNeedBlastCheck` 跳过的是纯词元，`blastRadiusOf` 对它们恒返回
  // `inside`，走不到置位分支。
  let sawUnjudgeable = false
  for (let i = 0; i < w.length; i += 1) {
    const token = String(w[i])
    // 命令头（提权前缀 / wrapper / 命令名自身）都不是删除目标 —— 按位置跳，
    // 不依赖词元值相等（见 headEnd 的注释）。
    if (i < headEnd) continue
    if (skip[token]) continue
    // 跳过选项开关（`/s` `/q` `-Recurse` `-Force` …）：它们不是目标。
    //
    // 判据是**平台**（opts.platform），不是方言 —— 两者不是一回事：
    //   · `-` 开头 —— 两门方言、两个平台都是开关（POSIX `-rf`、PowerShell `-Recurse`），无条件跳过。
    //   · `/` + 字母 —— **只在 Windows 上**才是 cmd 风格开关（`/s` `/q` `/grant` `/pid`）。
    //     POSIX 上 `/` 是路径分隔符，`/etc`、`/usr/bin` 都是目标。
    //
    // 这里曾经按**方言**判（pwsh 就跳 `/xxx`），根因是把方言当成了平台的替身：
    // Linux/macOS 上跑 PowerShell Core（pwsh 工具）时方言是 pwsh、路径却是 POSIX 的，
    // 于是 `rm -rf /etc`、`/usr/bin`、`/home/u` 全部被当开关跳过、段级 blast 静默 ——
    // 而同一台机器用 bash 工具就正确判 system。判据现在只看 `opts.platform`，
    // 平台未知时 isCmdStyleSwitch 返回 false（**不跳**，方向 fail-safe：把路径当开关会漏警告）。
    if (token.charCodeAt(0) === 45) continue                       // `-x` / `--long`：无条件开关
    if (isCmdStyleSwitch(token, opts, cmdName)) continue           // Windows 的 `/s` `/grant`；POSIX 上恒 false
    if (/^[<>]/.test(token)) continue
    // ── 引号包裹的**整条命令** ────────────────────────────────────────────────────
    // `su -c "rm -rf /"`、`runas /user:X "Remove-Item -Recurse -Force C:/Windows"`：
    // 词法器把引号内容并成**一个**词元，而它本身是一条完整的命令行。
    //
    // 直接把它当路径判档会得出错误结论。实测（真实 isOutside 语义）：
    //   `su -c "rm -rf /"`、`su -c "rm -rf /etc"`、`su --command "rm -rf /"`、
    //   `sudo su -c "rm -rf /"` 全部 `destructive=true` 而 blast=**null**（弹窗零警告）；
    //   而**未加引号**的 `su -c rm -rf /` 正确给 `drive-root|/`。加引号才是日常写法，
    //   于是最该警告的形态恰好静默。Windows 侧 `runas … "Remove-Item …"` 同理。
    //
    // 判据刻意收得很紧，**两条同时满足**才递归：
    //   ① 按空白切分后首词是「一条命令的开头」—— 破坏性命令名（`rm` / `Remove-Item` / `rd`…）
    //      或命令解释器（`cmd` / `powershell` / `sh`…，即 `cmd /c rd /s /q C:\` 这种，
    //      判据复用 NESTED_SHELLS —— 那份表就是「哪些名字是 shell」的既有单点）；
    //   ② 递归判档得出了结论（否则回退到原样判档，不丢警告）。
    // 收紧的理由：无条件递归会**制造新的漏报** —— `rm -rf "C:/Program Files/app"` 的词元
    // 也含空格，切分后成了 `C:/Program` + `Files/app`，两个都不是系统目录，system 警告
    // 会被抹掉；而原样判档本来是对的（WIN_SYSTEM_ROOT_RE 认 `program files`）。
    // 条件 ① 恰好排除这种情形：首词 `C:/Program` 既不是破坏性命令名也不是解释器。
    // 递归深度有界：split 出的子词元不含空格，故最多一层。
    if (token.indexOf(' ') !== -1) {
      const sub = token.split(/\s+/).filter(Boolean)
      const head = sub.length > 1 ? commandNameOf(sub[0]) : ''
      if (head && (isDestructiveLabel(head) || NESTED_SHELLS[head] === 1)) {
        // 递归结果**优先**（它才是「这条被引号包起来的命令行」的真实目标）；
        // 递归读不出结论时**不 continue**，落回下面的原样判档 —— 保证任何情况下都不比改动前少警告。
        const rs = blastRadiusOfSegment(sub, opts)
        if (rs) {
          const ssev = BLAST_ORDER[rs.level]
          if (ssev !== undefined) {
            // ── 内层的「读不出」必须**带上来**────────────────────
            // 内层结论可能是**并列**的两种（见 blastRadiusOfSegment 尾部的说明）：
            //   · `rs.level === 'unknown'`（空 path）—— 内层只有读不出的目标；
            //   · `rs.unjudgeable === true`          —— 内层既有已知目标、又有读不出的。
            // 两者都表示「这条被引号包起来的命令行里有读不出的目标」，故必须置位 ——
            // 否则下面 `worst = rs` 只是把**对象**换掉，内层那个事实随之丢失。
            //
            // 实测（`unknown=deny`、`wide=allow`、`priv=allow`，修复前 → 修复后）：
            //     su -c "rm -rf $T"        deny/['unknown','priv'] → deny（不变）
            //     su -c "rm -rf $T" /      **allow**/['wide','priv'] → **deny**
            //       ← 内层 unknown 被外层更严重的 `/`（drive-root）整个顶替，
            //         于是「加一个读不出的内层目标」反而把结论从 deny 放宽成 allow
            //     su -c "rm -rf $T" C:/Windows → 同上（外层 system 顶替内层 unknown）
            // 置位方向**只会收紧**：新增的 `unknown` 档参与取最严，不改变 `blast` 的显示
            // （`worst` 仍是外层那个更严重的已知档，弹窗文案不变）。
            if (rs.level === 'unknown' || rs.unjudgeable) sawUnjudgeable = true
            if (!worst || ssev < BLAST_ORDER[worst.level]) worst = rs
            continue
          }
        }
        // 递归返回 `null` 时**不置位**：`null` 的两种含义里，「确认在区内」正是最常见的一种
        // （`blastRadiusOfSegment(['rm','./build'])` === null），而真正「读不出」的内层目标
        // （`['rm','-rf','$T']`）返回的是 `{level:'unknown'}` —— 它在上面 `if (rs)` 里已经
        // `continue`，走不到这里。曾经这里无条件置位，把前一种误标成后一种：实测
        // `sudo rm ./build` 是 inside+priv（正确），而 `su -c "rm ./build"` 是
        // unknown+priv —— 两者目标相同，只因引号写法不同就分了叉（方向虽仍是收紧，
        // 但那是**判据错误**：用户把 unknown 设为 deny 时，`su -c "rm ./build"` 会被拒
        // 而 `sudo rm ./build` 放行）。
        // 这里的原意（`else` 挂在与 `if (rs)` 配对的 `if (ssev !== undefined)` 上）本就是
        // 「rs 非空但 level 不认识」—— 那个集合**恒为空**（rs 的 level 只有 BLAST_ORDER
        // 的八个键，非空 blast 必在其中），故该分支不可达，直接删除。
      }
    }
    // `NAME=value` 只在**命令名之前**是「env 赋值前缀」（`FOO=1 rm -rf /` 里的 `FOO=1`），
    // 在命令名之后它就是普通实参 —— 而删除类命令恰恰用这种形态表达目标：
    // `dd of=/dev/sda`、`dd if=/dev/zero of=/dev/sda`（`dd` 本身在 DESTRUCTIVE_LABELS 里）。
    // 无条件跳过会把承载破坏性目标的操作数整个丢掉：实测 `['dd','of=/dev/sda']` 判 null，
    // 而对照组 `['shred','/dev/sda']` 正确判 system。
    //
    // 「命令名之前」这一条件**已由循环开头的 `i < headEnd` 满足**：赋值前缀（含前导的
    // `FOO=1`）都在命令头范围内，走不到这里；能走到这里的 NAME=value 必然在命令名之后，
    // 故取 `=` 右侧的值继续判档（左侧是参数名，不是路径）。
    // 这里曾另有一个 `if (i < cmdNameEnd) continue`，但它是死分支（见 headEnd 处的说明）。
    if (/^[A-Za-z_][A-Za-z0-9_]*=/.test(token)) {
      const rhs = token.slice(token.indexOf('=') + 1)
      // `NAME=` 空值不是目标（`FOO= rm -rf x` 的 FOO 没有值可言），**不置位** —— 见 §4.2 置位表
      if (!rhs) continue
      if (!mayNeedBlastCheck(rhs, opts && opts.platform)) continue
      const rv = blastRadiusOf(rhs, opts)
      // 右侧值读不出（`dd of=$DEV`）→ 置位：这是**目标**读不出，不是「没有目标」
      if (!rv) { sawUnjudgeable = true; continue }
      const rsev = BLAST_ORDER[rv.level]
      if (rsev === undefined) continue
      if (!worst || rsev < BLAST_ORDER[worst.level]) worst = rv
      continue
    }
    // 廉价预筛：不含分隔符/盘符/家目录/变量/通配符、也不以 `.` 开头、且不是 BARE 系统目录名
    // 的**纯词元**，在工作区内判档恒为 inside。跳过它们省掉每词元一次的 expandTilde +
    // globRootOf + 正则 + 宿主回调 —— 实测破坏性段带 20000 个相对路径参数时，判定从 38.2 ms
    // 涨到 73.8 ms，而这些词元全部判为 inside、最终 worst 为 null、不产生任何警告：
    // 付出 100% 判档代价换来零信息。含上述字符的词元照常走完整判档（不漏报）。
    //
    // 判据走 mayNeedBlastCheck：预筛是纯优化，**不得改变结论** —— 它必须把 BARE 系统目录名
    // （`Windows`/`System32`…）也放行去判档，否则会与紧邻它定义的 WIN_SYSTEM_BARE_RE 矛盾。
    if (!mayNeedBlastCheck(token, opts && opts.platform)) continue
    const r = blastRadiusOf(token, opts)
    // 非空词元返回 null = **读不出**（变量 / 命令替换 / 读不懂的形态）→ 置位。
    // 判据是「返回了 null」，而不是「词元里有没有 $」—— 后者是手抄一份 blastRadiusOf
    // 的短路条件，两处必然漂移（该函数的短路条件改过一次：`$Recycle.Bin` 是字面目录名
    // 却被变量短路吃掉）。这里只认它的返回值，判据天然同源。
    if (!r) { sawUnjudgeable = true; continue }
    // ── 工作区根（§5.5）──────────────────────────────────────────────────────────
    // `blastRadiusOf` 把 `rm -rf .` / `rm -rf *` / `rm -rf ./*` 的目标经 globRootOf
    // 归约为 `.`，再由 isOutsideWorkspace 判为 inside → 段级 blast 为 null →
    // 大分类 allow 时**删掉整个项目不弹窗**（一族五种写法实测全落 inside）。
    //
    // 解析器判不了「这是工作区根」——它不知道根在哪，故由宿主注入钩子。判据必须与宿主的
    // isOutside **同口径**（相对路径先拼根、再 pathResolve 归一），否则两者会在边界上打架：
    // 同一路径可能既不算「外」（isOutside 返 false）又不算「根」（钩子返 false），
    // 落进 inside 静默。这与 blastRadiusOf 里「判据必须直接问 isSystemDir，不能手抄一份
    // 平台分派」是同一类纪律。
    //
    // 钩子收的是 **globRootOf 的结果**（`r.path`），不是原始词元 —— 故 `*`、`./*`、
    // `.\*` 与绝对路径写法都能命中，而 `..`、`./build`、`src/tmp` 不会误判。
    //
    // 为什么用独立 level 名而非直接返回 `wide`：`home`/`system`/`drive-root` 都是
    // 「工作区之外」的概念，而 `workspace-root` 在区内。独立 level 让弹窗文案能区分
    // 「删整个项目」与「删盘根」—— 两者后果差一个量级。
    //
    // ── 钩子调用前的**形态预筛**：宿主每问一次都要把同一个目标重新归一一遍 ──────────
    // 落在这一支的目标都已被 `isOutsideWorkspace` 判为「区内」，而宿主那份
    // `isWorkspaceRoot` 要做 norm + pathResolve + 两次 toLowerCase —— 对**每一个**
    // inside 目标各一次，且与 `blastRadiusOf` 里刚问过的 `isOutsideWorkspace`
    // 是两遍独立归一（同一份 norm/pathResolve 各做一次）。
    //
    // 预筛是纯优化，**不得改变结论**，故判据取「该形态**是否可能**归一到工作区根」，
    // 且**宁可放行**（放行的代价只是多问一次钩子，结论由钩子给）。判据在
    // `mayBeWorkspaceRootShape` 里单点维护（四种形态与实测依据都记在那里）。
    //
    // **`|| /[*?]/.test(token)` 那条已删**：它对**任意**含通配符的词元放行，而
    // `globRootOf('*.log')` = `globRootOf('build*')` = `'.'`，宿主 `isWorkspaceRoot('.')`
    // 恒真 —— 于是 `rm -rf *.log` 被判成「删整个项目」（`wide` 档）。§5.5 的覆盖表只列了
    // `*` / `./*` / `.\*` 这类**整段纯通配**，带锚点的通配不在表内。判据改为看**段本身**。
    if (r.level === 'inside' && opts && typeof opts.isWorkspaceRoot === 'function'
      && mayBeWorkspaceRootShape(token)) {
      let isRoot = false
      try { isRoot = !!opts.isWorkspaceRoot(r.path) } catch (e) { isRoot = false }
      // 钩子抛错时**不置位也不改判**：保持既有的 inside 行为（与 isOutsideWorkspace 的
      // try/catch 同处置）。方向仍是 fail-safe —— 钩子是宿主的纯函数，抛错意味着宿主有 bug，
      // 那种情况下静默保持原判比把每条命令都标成「删整个项目」更可诊断。
      if (isRoot) {
        const wr = { level: 'workspace-root', path: r.path }
        const wsev = BLAST_ORDER[wr.level]
        if (!worst || wsev < BLAST_ORDER[worst.level]) worst = wr
        continue
      }
    }
    // 只保留「有警告意义」的档位：inside 不需要警告，但它可以作为兜底（全 inside → null）。
    // 顺序取自模块级的 BLAST_ORDER（唯一一份）—— 曾在函数内手抄一份、index.js 再抄一份，
    // 三份漂移时消费侧是「静默跳过未知档」，只会让警告整体失效而不报错。
    const sev = BLAST_ORDER[r.level]
    if (sev === undefined) continue
    if (!worst || sev < BLAST_ORDER[worst.level]) worst = r
  }
  if (!worst || worst.level === 'inside') {
    // 没有任何「有警告意义」的目标：若途中见过读不出的目标，后果就是**读不出**，
    // 不能报 null（那等于宣称「确认无害」）。空 path 表示没有具体目标可显示。
    return sawUnjudgeable ? { level: 'unknown', path: '' } : null
  }
  // ── 「读不出」与「已知最严重目标」是**并列**结论，不是二选一─────────
  // 上面那一支只在**没有任何已知目标**时兜底成 `unknown`；一旦同段里还有一个读得出的目标，
  // `unknown` 就被整条丢掉了（`return worst`）。而两者是**并列**的：
  //     `rm -rf /etc $TARGET`  既确定会删 `/etc`（outside），又可能删任意路径（unknown）
  // 这与 §7.2 整行读不懂分支的 `wide ∪ unknown` 同构 —— 那里正是「两个都并入」。
  //
  // 丢掉的后果是 **fail-open**：用户把 `unknown` 设得比胜出的已知档更严时，整条结论被
  // 已知档顶替。实测（`unknown=deny`、`outside=allow`、`wide=allow`）：
  //     rm -rf $TARGET        → deny  tiers=['unknown']         blast=unknown:
  //     rm -rf /etc $TARGET   → **allow** tiers=['outside']      blast=outside:/etc  ← 顺序无关
  //     rm -rf $TARGET /etc   → **allow** tiers=['outside']      blast=outside:/etc
  //     dd of=$DEV of=/dev/sda → **allow** tiers=['outside']     blast=outside:/dev/sda
  // 即「同一条命令里加一个读不出的目标，反而把 deny 放宽成 allow」。
  //
  // 修法：`worst` **保持原样**（`blast` 仍显示已知最严重的那一档，弹窗文案不变），
  // 只把「本段还有读不出的目标」这个事实挂在返回值上，由 `tierSetOf` ① 恒并上 `unknown` 档。
  // 取最严对**新增**档是单调的，故只会收紧，不会放宽任何东西。
  //
  // ⚠️ 标志挂在**返回对象**上（而不是另设一个并列的布尔出口），故递归引号分支
  // （`:4698` 的 `blastRadiusOfSegment(sub, opts)`）天然把它带上来 —— 那里 `rs` 是
  // **整个对象**被赋给 `worst` 的，标志随之传播，不需要额外处理。
  if (sawUnjudgeable) return { level: worst.level, path: worst.path, unjudgeable: true }
  return worst
}

/**
 * 例外模式（`match`）的爆炸半径：宽泛顶层通配返回 `broad` 档，其余交给 blastRadiusOfSegment。
 *
 * 为什么需要 `broad` 这一档：`rm -rf *`、`rm *`、`rmdir *`、`del *`、`Remove-Item *`
 * 这类例外的目标经 globRootOf 归约为 `.`（相对当前目录）→ isOutsideWorkspace 判 inside
 * → 返回 null → **完全不标注**。但它们实测能放行 `rm -rf /`、`rm -rf /etc`、
 * `rm -rf C:/Windows`（matchCommand('rm -rf *', …) 三者均为 true），
 * 即一条「看起来只是放行某类操作」的例外实际覆盖到盘根。面板的例外列表按设计是
 * 「唯一能让人**事后**发现『我什么时候放行了删盘根』的地方」，此处静默等于把审计点关掉。
 *
 * 判据：match 去掉命令前缀后若**只剩通配符**（`*`/`?`/空白），即该例外不限定任何目标。
 *
 * @param {string[]} words 段词元
 * @param {{ home?: string, userHome?: string, platform?: 'win32'|'posix', isOutsideWorkspace?: (p:string)=>boolean }} opts
 * @returns {{ level: string, path: string }|null}
 */
export function blastRadiusOfCommandPattern(words, opts) {
  const w = Array.isArray(words) ? words : []
  const un = (() => { try { return unwrapWords(w) } catch (e) { return null } })()
  const uw = (un && Array.isArray(un.words) && un.words.length) ? un.words : w
  // 跳过**命令名本身**，而不是只跳一个词元：命令名可能是多词的（`git status`、
  // `reg delete` —— 路由器命令的 label 细化到这一粒度）。只 slice(1) 会把 `status`
  // 当成目标实参，于是 `git status *` 被判成「目标被限定」而走常规判档，
  // 结果随宿主 isOutsideWorkspace 对 `.` 的口径漂移（实测 inside-host 下 null、
  // outside-host 下 outside，同一份配置两种结论）。
  //
  // ── 提权前缀：命令头要一路吃到**真正吃目标的那个命令名** ──────────────────────
  // `sudo`/`doas`/`pkexec`/`runas`/`gsudo` 在 DESTRUCTIVE_LABELS 里、却**不在 WRAPPERS 里**
  // （它们改变权限，不是透明包装），于是 `segmentLabel(['sudo','rm','-rf','*'])` 返回 `sudo`
  // —— 词数是 1，而真正吃目标的 `rm` 留在 rest 里被当成**目标实参**：
  // `rest.some(非通配)` 为真 → 不走 broad → 转交 blastRadiusOfSegment → 那里按词元值
  // 跳过所有命令名 → 最终 null。实测 `sudo rm -rf *` 零标注，而
  // `matchCommand('sudo rm -rf *', 'sudo rm -rf /')` 为 true —— 正是 broad 档要堵的
  // 「一条例外静默放行删盘根」，只是加了个提权前缀。`doas`/`pkexec` 同样。
  //
  // 判据统一走 commandHeadEnd（与 blastRadiusOfSegment 的 skip 同源，见该函数注释）。
  // 它同时覆盖了这里曾经漏掉的两种形态：
  //   · 提权命令**带选项** —— `sudo -u root rm -rf *`：旧判据「遇到 `-` 就 break」把命令头
  //     停在 `sudo` 上，`rm` 被当成目标实参 → 不走 broad → 零标注（实测）；
  //   · 提权命令**后接 wrapper** —— `sudo env rm -rf *` / `sudo nohup rm -rf *`：同上。
  // 两者 `matchCommand` 均实测为 true，即「一条能放行删盘根的例外」在面板上零标注。
  const label = (() => { try { return segmentLabel(w) } catch (e) { return '' } })()
  const headEnd = (() => { try { return commandHeadEnd(w) } catch (e) { return 0 } })()
  // ── 两个下标空间：`headEnd` 是 **w** 的，`rest` 却要切 **uw** ──────────────────
  // commandHeadEnd 返回的是**原始词元数组 w** 的下标，而下面的 rest 从 uw 切 ——
  // 而 uw 是 unwrapWords(w).words，**已经剥掉了 wrapper 与前导 NAME=value**，比 w 短。
  // 直接 `uw.slice(headEnd)` 会多吃掉 (w.length - uw.length) 个真实实参，于是「目标是否
  // 被限定」判错，两个方向都错（实测 win32，13 个候选形态中 9 个与段级结论不一致）：
  //   · 少警告：`env FOO=1 rm -rf C:/Windows`、`timeout 5 rm -rf C:/Windows`、
  //     `nice -n 5 rm -rf C:/Windows`、`stdbuf -o0 …`、`xargs -0 …`、`env -i …` 的 rest
  //     被切空 → 落到 broad，而真实档位是 system；`timeout 5 rm -rf C:/`、`nice -5 rm -rf C:/`
  //     真实是 drive-root 也被标成 broad。broad 的文案是「这条规则**不限**删除目标」，
  //     与事实相反；且 BLAST_ORDER 里 broad 比 system 更严重，会把真实目标整个盖掉。
  //   · 多警告：`env FOO=1 rm -rf ./build`（工作区内，真实档位 null）被判 broad 假警告。
  // 换算：w 比 uw 多出的前缀数 = w.length - uw.length，减掉它才是 uw 空间的下标。
  const prefixLen = Math.max(0, w.length - uw.length)
  // 只在确实吃到了命令名时才用 commandHeadEnd 的结果：`0` 表示首词元既不是前缀也不是
  // 破坏性命令，此时保持 label 词数（路由器命令 `git status` 走这条）。
  const headLen = Math.max(0,
    (headEnd > 0 ? headEnd : (label ? label.split(/\s+/).length : 1)) - prefixLen)
  // 判断「这条例外是否限定了目标」时**必须把开关排除掉**，判据与 blastRadiusOfSegment
  // **同一份**（isCmdStyleSwitch / `-` 前缀）：
  //   · `-` 开头 —— 无条件开关。
  //   · `/` + 字母 —— 只在 Windows 上是 cmd 风格开关。**这一条不能按方言门控**：
  //     `rmdir /s /q *` 是 cmd 风格例外，其 `/s` `/q` 在 Windows 上就是开关；若按方言滤，
  //     POSIX 侧会把 `/s` `/q` 当成目标实参 → 「全是通配」判断失败 → 这条**能放行
  //     `rmdir /s /q B:\`（删盘根）** 的例外在面板上零标注。
  //   · 其余 `/` 开头（`/etc`、`/`、`/*`）—— POSIX 上是目标，交给 blastRadiusOfSegment 判档。
  //
  // 两个判断曾经耦合在同一个数组上，于是「滤开关」与「判目标是否受限」互相干扰：
  // 按方言滤 → 限定目标的例外（`rmdir /s /q /`）被滤空而误标成 broad；
  // 不滤 → 带开关的宽泛例外（`rmdir /s /q *`）判不出 broad 而静默。
  // 拆开后两者各自正确：开关一律不算目标，`/` 的路径歧义才交给平台。
  // 命令域判据要的是**命令头位置上的命令名**（剥 wrapper 与提权前缀）—— 见 headCommandNameOf。
  // 复用上面已算出的 headEnd（它是 **w** 空间的下标，而命令名取值与下标空间无关）。
  const cmdName = headCommandNameOf(w, headEnd)
  const rest = uw.slice(headLen).filter((t) => String(t).charCodeAt(0) !== 45 && !isCmdStyleSwitch(String(t), opts, cmdName))
  // 还有非通配的实参 → 目标被限定了，按常规逐词元判档
  if (rest.some((t) => !/^[*?\s]+$/.test(String(t)))) return blastRadiusOfSegment(w, opts)
  // 剩下的实参全是通配（或一个都没有）→ 目标不被限定，归宽泛档。
  //
  // ── 但「没有实参」不等于「不限定目标」────────────────────────────────────────
  // `nohup ./server.sh`、`env FOO=1 ls` 的 rest 都为空，可它们的**字面前缀**是
  // `nohup ./server.sh ` / `env FOO=1 ls `，匹配不到任何删除命令 —— 判 broad 就是假警告。
  // 根因是这里的比较基准：`rest` 按 unwrapWords **剥掉 wrapper 之后**的词元切分，
  // 而 matchCommand 匹配的是**原始文本**（wrapper 还在里面），两者不是同一个东西。
  //
  // 故还要求二者之一，才判 broad：
  //   · 模式里**确实有通配符**（目标位就是通配，如 `env *`、`find *`、`rmdir /s /q *`）；
  //   · 或命令头本身就是删除类（`rm -rf` 没有目标实参，却按前缀匹配到 `rm -rf /`，
  //     这一档必须留着）；
  //   · 或命令头是**载荷族**（`find` / `env` / `xargs` …）且**没有任何实参** ——
  //     此时它就是一条裸前缀，后面接什么由真实命令决定。
  // 第三条是必须的：`find`（裸，无实参）实测 `matchCommand('find','find / -delete')` = true，
  // 而它**正是候选生成器写下的值**（index.js 的 useExactText 分支对载荷族用整段原文，
  // 而 `find` 段的 seg.text 就是 `find`）。只认前两条时该例外标注 null：用户对「找一下文件」
  // 点一次「允许并记住」，`find / -delete` 在 destructive=deny 下由 deny 变 allow，
  // 而面板例外列表零标注 —— 那正是本功能声称要守住的「唯一能事后发现我什么时候放行了
  // 删盘根的地方」。`env` / `xargs` 同理（实测分别放行 `env FOO=1 rm -rf /`、`xargs rm -rf /`）。
  //
  // 只对「裸」（无实参）成立：`find . -name x` 有实参，目标被限定，走常规判档。
  // 判据用 isPayloadCarrierLabel(headName)（与 index.js 候选侧同一份表），
  // 不另抄一份名单。
  const hasWildcard = /[*?]/.test(w.join(' '))
  const headName = (() => { try { return String(commandNameOf(uw[0]) || '').toLowerCase() } catch (e) { return '' } })()
  if (!hasWildcard && !isDestructiveLabel(headName)) {
    // rest 为空 = 命令名之后**没有任何非开关实参**（`find`、`env`、`find -delete`）→ 不限目标。
    //
    // rest 是**滤掉开关之后**的数组，故 `find -delete`、`xargs -delete`、`env of=/dev/sda`
    // 的 rest 也是空的 —— 这是**正确**的，不是误判：这些模式都不限定目标，实测分别放行
    // `find -delete /`、`xargs -delete rm -rf /`、`env of=/dev/sda rm -rf /`
    // （matchCommand 是词边界前缀匹配，追加实参即命中）。
    //
    // 曾经想改成「按未滤开关的原始实参判空」来消除所谓的假警告，但那是**误判** ——
    // 当时用的危险命令集不含「模式 + 追加实参」的形态（如 `xargs -delete rm -rf /`），
    // 于是把真警告当成了假警告；改完 `find -delete` 反而由 broad 退化成 null（漏报）。
    // 判据保持「rest 为空」。
    if (isPayloadCarrierLabel(headName) && !rest.length) {
      const gb = globRootOf('*')
      return { level: 'broad', path: String(gb) }
    }
    return blastRadiusOfSegment(w, opts)
  }
  // ── broad 必须再加一道「命令族是否危险」的过滤 ──────────────────────────────
  // 本函数在 index.js 的 exceptionBlast 里被调用，而那条路径的入口过滤是
  // canCarryDestructivePayload —— 它对「提权/wrapper 前缀 + 普通命令」返回 **true**
  // （前缀名 `sudo`/`env`/`nohup`… 本身就在 PAYLOAD_CARRIERS 里），于是这些模式
  // 会走到这里被判 broad：
  //     sudo ls *   doas cat *   pkexec echo *   env ls *   nohup ls *
  //     timeout 5 ls *   xargs ls *   stdbuf -o0 ls *   sudo -u root ls *
  // 而 broad 的文案是「这条规则**不限**删除目标 —— 它同样放行删除盘根与系统目录」。
  // 这类形态**放行不了任何一条**删除命令：`matchCommand('sudo ls *', 'sudo rm -rf /')` = false，
  // 它只匹配 `sudo ls ...`，标 broad 就是假警告。
  //
  // 无前缀的形态（`ls *`、`git status *`）到不了这里 —— canCarryDestructivePayload
  // 对它们返回 false（`ls`/`git` 既不在破坏性名单也不在 PAYLOAD_CARRIERS 里）。
  // 所以漏的恰好是「前缀 + 普通命令」这一类。
  //
  // 判据用**真实命令名**，不能用 `headName`（= `uw[0]`）：前缀形态下它是前缀名本身
  // —— 实测 `sudo ls *` 与 `sudo rm -rf *` 的 headName 都是 `sudo`（在破坏性名单里），
  // 于是前者被误判成危险。真实命令名 = **命令头最后一个词元** `uw[headLen - 1]`
  // （headLen 是命令头词数，已含「前缀链 + 命令名」全部位置）：
  //   `sudo ls *` → `ls`（普通）  `sudo rm -rf *` → `rm`（危险）  `find *` → `find`（载荷族）
  // 路由器命令（`git status *`）取到的是子命令 `status`，同样不是危险族 —— 结论一致。
  //
  // 两条都不是时交回 blastRadiusOfSegment：普通命令一律得 null（不标注）。
  // 危险族三类，缺一不可（每一类都是实测出来的）：
  //   · 破坏性命令（`rm` / `rmdir` / `del` / `format` …）—— `rm -rf *` 能放行 `rm -rf /`；
  //   · 载荷族（`find` / `env` / `xargs` …）—— `find *` 能放行 `find / -delete`；
  //   · **嵌套解释器 / shell**（`sh` / `bash` / `cmd` / `pwsh` / `eval` …）——
  //     `sh *` 能放行 `sh -c "rm -rf /"`。这一类**最初漏了**，实测造成 32 个真漏报
  //     （`sh *`、`bash *`、`sudo sh *`、`nohup bash *` … 由 broad 退化成 null）。
  //
  // 判据：在命令头范围内找**真正吃目标的命令名** —— 即命令头里**最后一个
  // 「既不是 wrapper、也不是提权前缀」**的词元。不能简单扫全部词元，因为
  // `sudo` / `doas` / `su` / `pkexec` / `runas` / `gsudo` **本身就在
  // DESTRUCTIVE_LABELS 里**（它们确实是危险动作），扫全表会把 `sudo ls *` 里的
  // `sudo` 当成危险族 → 假警告依旧（实测）。
  //
  // 也不能只看 `uw[headLen - 1]`：unwrapWords 会把 wrapper 剥掉，`xargs *` 的 `uw`
  // 只剩 `["*"]`，那个位置是 `*`（认不出），而 `xargs` 本身是载荷族 ——
  // 实测只看单个位置会漏掉 `xargs *` / `env *` / `nohup xargs *` 等 32 个真警告。
  //
  // 故：扫命令头，**跳过纯前缀名**，取最后一个非前缀词元。若全部都是前缀
  // （`env *` / `xargs *` / `sudo *`），则**回退到这些前缀名本身**判 —— 因为
  // 「裸前缀 + 通配」正是 `xargs *`（能放行 `xargs rm -rf /`）这类形态。
  //
  // 危险族三类，缺一不可（每一类都是实测出来的）：
  //   · 破坏性命令（`rm` / `rmdir` / `del` / `format` …）—— `rm -rf *` 能放行 `rm -rf /`；
  //   · 载荷族（`find` / `env` / `xargs` …）—— `find *` 能放行 `find / -delete`；
  //   · 嵌套 shell / 解释器（`sh` / `bash` / `cmd` / `pwsh` / `eval` …）——
  //     `sh *` 能放行 `sh -c "rm -rf /"`（这一类最初漏了，实测 32 个真漏报）。
  // 后两类的名单复用既有单点（isPayloadCarrierLabel / NESTED_SHELLS / NESTED_EVAL），
  // 不另抄一份。
  const headIsDangerous = (() => {
    const isDanger = (n) => isDestructiveLabel(n) || isPayloadCarrierLabel(n)
      || NESTED_SHELLS[n] === 1 || NESTED_EVAL[n] === 1
    // `last` 收敛到「命令头里最后一个**像命令名**的词元」：
    //   `sudo rm *`  → `rm`（判危险 → broad）
    //   `sudo ls *`  → `ls`（判普通 → 交回判档 → null）
    //   `env *`      → `env`（`*` 不算命令名，故 last 保持前缀名 → 载荷族 → broad）
    //   `xargs *`    → `xargs`（同上，这一族是**真警告**：`xargs *` 放行 `xargs rm -rf /`）
    //
    // 扫描范围用 `Math.max(headEnd, headLen)`：
    //   · `headEnd > 0`（有前缀链）时两者一致，取到命令名；
    //   · `headEnd === 0`（首词元既非前缀也非破坏性命令）时 headEnd 不表示命令头，
    //     必须回退到 `headLen`（label 词数）—— 否则 span 只含第一个词元。
    //     实测该回退是必需的：`/usr/bin/rm *` 的 headEnd=0、headLen=1，只取 `w[0]`
    //     本应够用，但 `isCmdStyleSwitch('/usr/bin/rm', win32)` 为 **true**
    //     （`/` + 字母，且 basename 不在系统目录名单里），于是它被当开关跳过 →
    //     last 为空 → 判 null。而 `/usr/bin/rm *` 实测能放行 `/usr/bin/rm -rf /`
    //     （18 个真漏报：`/usr/bin/rm *`、`/usr/bin/find *`、`/usr/bin/sh *` …）。
    //     故**路径形态的命令名不能被 isCmdStyleSwitch 吃掉**：它含分隔符，
    //     是路径而不是 `/s` 那样的 cmd 开关。
    const span = w.slice(0, Math.max(1, headEnd, headLen))
    // 命令域判据要的是**命令头位置上的命令名**（剥 wrapper 与提权前缀）—— 见 headCommandNameOf。
    // 复用已算出的 headEnd（与 span 的上界同源）。
    const cmdName = headCommandNameOf(w, headEnd)
    let last = ''
    for (const t of span) {
      const s = String(t)
      if (!s) continue
      // 通配 / 开关 / 重定向 / NAME=value 都不是命令名
      if (/^[*?\s]+$/.test(s)) continue
      if (s.charCodeAt(0) === 45 || s.charCodeAt(0) === 60 || s.charCodeAt(0) === 62) continue
      // 纯数字时长参数也不是命令名：`timeout 5 *` 的 `5` 若被当成命令名，
      // `last` 就停在 `5` 上，而 `timeout` 是载荷族（`timeout 5 *` 实测能放行
      // `timeout 5 rm -rf /`）—— 实测那是 1 个真漏报。
      if (/^[0-9]+(?:\.[0-9]+)?[smhd]?$/.test(s)) continue
      // 路径形态（含分隔符）是命令名的一种写法，不能按 cmd 开关跳过
      const isPathForm = s.indexOf('/') !== -1 || s.indexOf('\\') !== -1
      if (!isPathForm && isCmdStyleSwitch(s, opts, cmdName)) continue
      if (/^[A-Za-z_][A-Za-z0-9_]*=/.test(s)) continue
      const n = String(commandNameOf(s) || '').toLowerCase()
      if (n) last = n
    }
    return isDanger(last)
  })()
  // ── 普通命令：**不标注**（`return null`，不是交回判档）────────────────────────────
  // `headIsDangerous` 为假 ⟹ 该模式放行不了任何删除命令 ⟹ 它没有「爆炸半径」可言，
  // 标 `null` 才是对的 —— 这正是上面那句「普通命令一律得 `null`（不标注）」的字面实现。
  //
  // 不能写成 `return blastRadiusOfSegment(w, opts)`：那条路会把 `isWorkspaceRoot` 钩子接进来，
  // `sudo ls *` / `env ls *` / `nohup ls *` / `git status *` 的 `*` 经 `globRootOf` 归约为 `.`，
  // 宿主 `isWorkspaceRoot('.')` 恒真 → 得到 `{level:'workspace-root', path:'.'}`，于是
  // 一条放行不了任何删除命令的 allow 例外被标成「目标是本项目根目录」—— 面板假警告。
  //
  // ⚠️ 归因**不是** `isCmdStyleSwitch` 的命令域判据（`cmdName`）：把那段换回 HEAD 写法后
  // `sudo ls *` 仍然得到 workspace-root（实测）。真因就是这条兜底把钩子接了进来。
  //
  // ⚠️ 带**具体**目标的形态（`sudo cat /etc`、`sudo ls /*`）走的是上面
  // `rest.some(非通配)` 那条早退，**不经过本行** —— 它们的标注不受本行影响。
  if (!headIsDangerous) return null
  // `rm -rf /`、`rm -rf /*`、`rm -rf B:\*` 这类**绝对/盘根形态的通配**不在此列：
  // 它们的目标是确定的盘根（最严重的一档），不能因为「只剩通配」被归到 broad 而降级。
  // 它们不会被 isCmdStyleSwitch 滤掉（`/` 与 `/*` 都不是 1–2 字母开关），故上面那行会走常规判档。
  const g = globRootOf('*')
  return { level: 'broad', path: String(g) }
}

/**
 * 剥掉 opaque 构造的**外层定界符**，返回其中的正文（剥不出时返回空串）。
 *
 * 存在的理由：词法器把整个构造的**原文**（含定界符）交给
 * `noteOpaqueText`，而 `nestedInlineProgram` 要的是「命令 + 词元数组」——
 * 直接拿 `$(sh -c "…")` 去问，首词会是 `$(sh` 而不是 `sh`，判据恒假。
 * 故先把定界符剥掉再问，**不**在调用处另写一份「什么算解释器」。
 *
 * 覆盖四种定界符（与词法器里产生 opaque 构造的分支一一对应）：
 *   `$( … )` / `` ` … ` `` / `( … )` / `{ … }`
 * ⚠️ 只剥**成对**的外层：`$(a) $(b)` 这类多构造文本由调用方逐个传（`noteOpaqueText`
 *    本就是每个构造调一次），故这里不做切分。
 * ⚠️ **本函数只判首尾字符，不做任何配对检查**（`$(a) $(b)` 这类文本若整串传进来，
 *    首字符 `$`、末字符 `)`，会被剥成 `a) $(b` —— 但那不是本函数的输入形态）。
 *    成对性由**词法器**保证：它先 `skipBalanced` 成功跳过配对（`end >= 0`）才会调
 *    `noteOpaqueText`，故传进来的原文首尾必然成对。这里**不**用 `skipBalanced`
 *    重做一遍配对检查 —— 那既多余，也会与调用方对「输入是什么」的约定重复一份。
 *
 * @param {string} raw opaque 构造原文
 * @returns {string} 剥掉定界符后的正文（未命中任何定界符时返回空串）
 */
function stripOpaqueDelimiters(raw) {
  const s = String(raw).trim()
  if (s.length < 2) return ''
  const first = s.charAt(0)
  const last = s.charAt(s.length - 1)
  if (first === '$' && s.charAt(1) === '(' && last === ')') return s.slice(2, -1).trim()
  if ((first === '(' || first === '{') && last === (first === '(' ? ')' : '}')) return s.slice(1, -1).trim()
  if (first === '`' && last === '`' && s.length > 1) return s.slice(1, -1).trim()
  return ''
}

/**
 * 该段是否为「嵌套解释器带内联程序」——程序正文是另一门语言，读不懂。
 *
 * 导出给 index.js 的候选生成复用：候选守卫必须与判定侧同源，否则会产出
 * 「判定侧根本不采纳」的候选（用户点了写入成功、命令仍弹窗，而判重让候选下次消失 —— 死结）。
 */
export function nestedInlineProgram(label, words) {
  const base = String(label || '').split(' ')[0]
  if (!base) return false
  if (NESTED_EVAL[base]) return true
  const w = Array.isArray(words) ? words : []
  if (NESTED_INTERPRETERS[base]) {
    for (let j = 1; j < w.length; j += 1) {
      const t = String(w[j])
      if (INLINE_PROGRAM_FLAG.test(t)) return true
      if (base === 'node' && /^-p(?:e)?$/.test(t)) return true
      if (base === 'php' && t === '-r') return true
      if (base === 'deno' && t === 'eval') return true
    }
    return false
  }
  if (NESTED_SHELLS[base]) {
    for (let j = 1; j < w.length; j += 1) {
      const t = String(w[j])
      // cmd 的 /c 与 /k 大小写不敏感：`cmd /C "..."` 是 Windows 上的标准写法，
      // 只比小写会让大写形态落到「可读的普通调用」，从而可被 `cmd *` 例外静默放行。
      if (base === 'cmd') { if (/^[/-][ck]$/i.test(t)) return true; continue }
      if (base === 'powershell' || base === 'pwsh') {
        // PowerShell 接受 `-Command` 的任意长度≥2 的前缀（`-Com` / `-Co` …），`-c` 单独也算；
        // `-EncodedCommand` 同样携带程序（只是编码过，更读不懂），其任意前缀也在此列。
        const lower = t.toLowerCase()
        if (lower === '/c' || lower === '-c') return true
        if (lower.startsWith('-') && lower.length >= 3
          && ('command'.startsWith(lower.slice(1)) || 'encodedcommand'.startsWith(lower.slice(1)))) return true
        continue
      }
      // 其余 shell 复用与解释器同一份判据（覆盖 `-lc` / `-ec` / `-xc` 等融合短选项）
      if (t === '--command' || INLINE_PROGRAM_FLAG.test(t)) return true
    }
    return false
  }
  return false
}

/**
 * 对一整条命令行做段级判定（本计划的核心修复）。
 *
 * 判定流程：
 *   1. 分解；读不懂整行 → 落 command 分类默认值
 *   2. 逐段求动作：用户例外 → destructive 子设置 → command 分类默认值
 *      但**读不懂的段**（opaque / 提取不出 label / 嵌套解释器带内联程序）跳过**例外面**，
 *      破坏性子设置仍照常生效 —— 「读不懂的内容不可被授权」是 fail-closed 的底线，
 *      否则 `git status $(任意代码)` 会因为一条 `git status *` 例外被静默放行；
 *      而「段首已经认出是 rm」这个事实不受同段内 opaque 构造影响，没有理由被关掉。
 *   3. fail-closed 合并：任一段 deny → deny；否则任一段 ask → ask；否则全部 allow → allow
 *      全部段都无判定（inherit）→ 返回 inherit，由调用方落兜底策略
 *
 * 顺序要点：
 *   · **例外先于子设置** —— 用户例外是显式表态，高于子设置（D-5）
 *   · **子设置先于分类默认值** —— 更细的判定优先于更粗的判定（D-6），
 *     所以大分类设为 allow 时，破坏性命令仍按子设置走
 *
 * `unparsable` 不是动作来源，只是 code 标注：解析不出的段没有额外信息可判，
 * 它该做的就是落回大分类（D-4）。为它单列子设置会凭空造一个与大分类重复的概念。
 *
 * `inherit` 是契约上可能的返回值（三层都未配置时），但**当前宿主不会产出它**：
 * `destructiveTiers` 恒返回具体动作、`resolveCategory` 对 command 分类也只会返回具体 mode
 * （项目层 inherit 已在读取时穿透到全局）。调用方 commandDecision 里的 inherit 分支因此不可达，
 * 那里有对应注释；此处保留该语义是为了让本模块不依赖宿主的默认值策略。
 *
 * 重定向只标注不设闸（D-8）：`git status > ~/.dsh/AGENTS.md` 命中例外即放行，code 仅用于展示。
 *
 * @param {string} source 命令原文
 * @param {'pwsh'|'bash'} shell
 * @param {{
 *   home?: string,
 *   userHome?: string,
 *   platform?: 'win32'|'posix',
 *   matchException?: (segmentText: string, label: string) => ({action:string, autoFallback?:'ask'|'allow'|'deny', ruleId?:string, reason?:string, note?:string}|null),
 *   destructive?: () => ({inside:string, outside:string, wide:string, unknown:string,
 *                         proc:string, power:string, priv:string, reg:string,
 *                         reasons?: {[tier:string]: string}}|null),
 *   category?: () => ({action:string, autoFallback?:'ask'|'allow'|'deny', reason?:string}|null),
 *   isOutsideWorkspace?: (path: string) => boolean,
 *   isWorkspaceRoot?: (path: string) => boolean,
 * }} hooks 注入判定回调，使本模块保持纯函数、可独立测试
 *
 * `destructive` 的契约从「给我一个动作」改为「给我**档位表**」——**合并逻辑留在解析器**
 * （单一来源）：解析器按 `tierSetOf` 选出适用档位、按 `strictestTierAction` 取最严、
 * 得出动作与 `source`。宿主只回答「每一档用户配的是什么」，不参与「哪一档更严」的判断。
 * 这样档位语义（哪些档、怎么组合、取严规则）只有一份定义，宿主改配置不会与解析器分叉。
 *
 * 兼容旧契约：钩子返回 `{action, reason}`（无档位键）时**展开成八档全等于该 `action`**
 * （旧契约的忠实翻译：一个动作管住全部破坏性命令）；`null` → 空表（所有档未表态）。
 * 于是所有既有调用方与测试钩子照常工作，且语义与旧行为逐格一致。
 *
 * ⚠️ **不得**把它读成「只取 `inside` 一档、其余档未表态」：那会让其余七档落到大分类，
 * 而大分类常态是 allow —— `sudo ls`（priv 档）/ `kill 1234`（proc 档）当场变成
 * 「大分类说了算」，D-6「大分类设为 allow 时破坏性命令仍按子设置走」随之失效（fail-open）。
 * 生产路径上 `index.js` 的 `destructiveTiers` 恒返回八档表，`{action}` 只出现在旧/测试钩子。
 * 归一化只在 `tierTableOf` 做一次，下游（段级与整行分支）只认档位表。
 *
 * @returns {{ action: 'allow'|'ask'|'deny'|'inherit', code: string, segments: object[],
 *            matched: string|null, reason: string|null, note: string|null }}
 */
export function assessCommand(source, shell, hooks) {
  const h = hooks || {}
  const sh = shell === 'pwsh' ? 'pwsh' : 'bash'
  // 分类默认值钩子的返回**原样转发 `autoFallback`**：宿主 `resolveCategory` 经 `pick()`
  // 返回的对象本来就带着它（见 index.js 的 pick），丢掉它等于让「执行命令分类设为
  // 自动审批 + 失败后拒绝」在裁决侧退化成缺省 ask —— 面板显示与实际裁决分叉。
  // 只认三个合法值，其余（含 undefined / 手改配置塞进来的垃圾）一律当「没给」，
  // 由 commandDecision 的 `|| 'ask'` 兜底（缺省仍是 ask，方向保守）。
  const autoFallbackOf = (v) => ((v === 'ask' || v === 'allow' || v === 'deny') ? v : null)
  // 「这一格**最终**会执行哪个动作」——`auto` 是两层的，回落值缺失/非法时按缺省 ask。
  // 与 index.js 的 finalActionOf 是同一条判据的两个实现（宿主与解析器分处两个模块），
  // 改一处必须同步改另一处。本模块内只用这一份，不再各处分写三元式。
  const finalActionOf = (action, af) => (action === 'auto' ? (autoFallbackOf(af) || 'ask') : action)
  /**
   * 一组回落值 → **最严**的那个（deny > ask > allow）。
   *
   * 回落值**是**权限判据 —— 它就是「模型超时 / 熔断 / 协议错时最终执行什么」。
   * 两个地方必须用它，且判据只能是这一份（段内多档、段与段）：
   *   · `tierVerdict`：同一段内**多个档**都是 auto 时（`sudo rm -rf /etc` 命中
   *     `tiers = ['wide','priv']`），各档可以各配一个回落值；
   *   · `assessCommand` 末尾的段间合并：多段命令的每个 auto 段各带一个回落值。
   * 任一处按「档位/书写顺序取第一个有值的」，用户为**更严的那一档**显式配的
   * 「失败后拒绝」就会被另一档的 allow 吞掉（fail-open）：
   *     wide=auto/回落 allow + priv=auto/回落 deny → 旧实现得 **allow**
   * 缺省值按 `ask` 参与合并（与 index.js 的 normalizeAutoFallback 缺省同源）：某个 auto 档
   * 没配回落值时，它自己的最终落点就是 ask，跳过它会让另一档的 allow 独占结果 —— 那是放宽。
   *
   * 空数组返回 `null`（没有 auto 档），由调用方决定兜底值。
   *
   * 比较用 `AF_STRICTNESS`（**回落值专用**的三值表），不借 `TIER_STRICTNESS` ——
   * 后者含 `auto: 1`，是**动作**域的序；拿它比回落值等于依赖「值域已被上游锁死」。
   */
  const strictestFallbackOf = (values) => {
    let best = null
    for (const v of (Array.isArray(values) ? values : [])) {
      const f = autoFallbackOf(v) || 'ask'
      if (best === null || AF_STRICTNESS[f] > AF_STRICTNESS[best]) best = f
    }
    return best
  }
  const catOf = () => {
    const c = h.category ? h.category() : null
    return {
      action: (c && c.action) || 'inherit',
      reason: (c && c.reason) || null,
      autoFallback: c ? autoFallbackOf(c.autoFallback) : null,
    }
  }
  /**
   * 把钩子返回值归一成**档位表**（§7.2 的契约）。
   *
   * 两条兼容路径，都是「让既有调用方不改也能跑」：
   *   · `{action, reason}`（旧契约 / 测试钩子）→ **展开成八档全等于该 action**。
   *     这不是权宜之计，而是旧契约的**忠实翻译**：旧的 `destructive` 子设置就是
   *     「一个动作管住全部破坏性命令」，而新模型里「全部档位同一个动作」正是它的原义。
   *     若只把它当成 `inside` 一档，其余七档会变成「未表态」→ 落到大分类，
   *     而「大分类 allow 时破坏性命令仍按子设置走」（D-6）当场失效。
   *   · `null` → 空表（所有档未表态）。
   * 归一化在这里做一次，下游（段级与整行分支）只认档位表，不再各自判断形状。
   */
  const tierTableOf = () => {
    const ds = h.destructive ? h.destructive() : null
    if (!ds) return null
    if (typeof ds.action !== 'string') return ds
    const t = {}
    const reasons = {}
    for (const tier of TIERS) t[tier] = ds.action
    // 理由同样展开：旧契约的 `reason` 是「整个破坏性类别」的理由，故每一档都能给出它
    if (ds.reason) for (const tier of TIERS) reasons[tier] = ds.reason
    if (ds.reason) t.reason = ds.reason
    if (ds.reason) t.reasons = reasons
    // autoFallbacks 必须一起搬过来：这个分支会**重建**表对象，漏搬等于把回落值丢了。
    // 后果不报错、不告警 —— auto 动作照常生效，但模型失败后按缺省 ask 处理，
    // 与用户配的 deny 不符（且只在这条「旧契约 + auto」的组合下出现，日常测不出来）。
    // 按档取同名键；旧契约的裸形态没有逐档回落值，故不回填（缺省由 tierVerdict 补 ask）。
    if (ds.autoFallbacks && typeof ds.autoFallbacks === 'object') {
      const afs = {}
      for (const tier of TIERS) {
        const v = ds.autoFallbacks[tier]
        if (v === 'ask' || v === 'allow' || v === 'deny') afs[tier] = v
      }
      if (Object.keys(afs).length) t.autoFallbacks = afs
    }
    return t
  }
  /**
   * 命中档位 → `{action, reason}`。
   *
   * `reason` 按档取（§7.1 的 per-tier reason）：由 `decisiveTierOf` 找出决定动作的那一档，
   * 再取该档的理由。老配置的 `reason` 字符串由宿主归入 `inside` 档（读取侧兼容），
   * 故这里只需要认 `reasons[tier]`；`ds.reason`（旧契约）作为 `inside` 档的兜底。
   *
   * ── decisive 档**没有**理由时，回落到**并列在同一严格度上**的其余命中档 ──────────────
   * 根因：`tierSetOf` 对「读得出的目标 + 读不出的目标」同段共存会**并列**并入 `unknown`
   * （见那里的 ③），而 `TIER_ORDER` 里 `unknown` 排第 1、`outside` 排第 3 —— 并列时
   * `decisiveTierOf` 取**靠前者**，于是 decisive 档从 `outside` 变成 `unknown`。
   * 而 `unknown` 档常常**没有**用户写下的理由 —— 它可能是显式设成 deny 却没填理由的档，
   * 也可能是命中「读不出的目标」才并进来的档，而用户只为 `outside` 那档写过理由 ——
   * 于是**动作仍是 deny、用户写的那句拒绝理由整句丢失**：
   *     rm -rf /etc          → deny，理由「删工作区外文件」✅
   *     rm -rf /etc $TARGET  → deny，理由 **null** ❌（tiers = ['unknown','outside']）
   * 这不是 fail-open（动作不变），但 AI 收到的拒绝指令是空的，而面板上那句理由仍显示在
   * `outside` 档（`explicitReasonsOf` 的口径）—— 「看得见理由、AI 收不到理由」，
   * 与「面板说谎」同族。
   *
   * 回落**只在同一严格度内**进行（deny 时即「也投了 deny 票」的那些档），故：
   *   · 动作与 `strictestTierAction` 的选择**永远一致**（绝不跨严格度取档 ——
   *     更松的档本来就不是 deny，它们的理由不属于这次裁决）；
   *   · 理由一定来自一个**用户确实为它写过拒绝理由**的档，不会凭空造出理由
   *     （没有任何命中档写过理由时仍然是 `null`）。
   * 次序与 `decisiveTierOf` 同源（同严格度时按 `TIER_ORDER` 靠前者优先）：`tiers` 已按
   * `TIER_RANK` 排过（`decisiveTierOf` 的注释声明该顺序由调用方保证）。`auto` 与 `ask`
   * 同为严格度 1，但 tie-break 保证「命中档含 `ask` 时 decisive 必为 `ask`」——此时
   * `action` 是 `ask`、下面整个 auto 分支不执行；故 `same` 里只可能是同为 `auto` 的其余档，
   * 本回落是在多个 auto 档之间选回落值（见下面的 `strictestFallbackOf`）。
   */
  const tierVerdict = (ds, tiers, noDefaultYield) => {
    const action = strictestTierAction(ds, tiers, noDefaultYield)
    // 决定动作的那一档（动作就是它定的，回落值与理由都**先取它**）
    const t = ds ? decisiveTierOf(ds, tiers, noDefaultYield) : null
    // ── auto：回落值在**全部 auto 档**之间取最严（deny > ask > allow）──────────────
    // 判据是 `ds[u] === 'auto'`（**不是** decisive 档）：同一段里可以有多个 auto 档
    // （`sudo rm -rf /etc` 命中 `tiers = ['wide','priv']`），而回落值**是**权限判据 ——
    // 用户为 priv 档显式配的「模型失败后拒绝」不能被 wide 档的 allow 吞掉：
    //     wide=auto/回落 allow + priv=auto/回落 deny → 旧实现得 **allow**（fail-open）
    // 旧实现有两条路径，**都不是从严合并**：①decisive 档有值就直接返回、并列档根本不看；
    // ②只有 decisive 档没值时才扫并列档，且按 `TIER_RANK` 取**第一个**有值的。
    // 第二条路径同样独立 fail-open：`sudo rm -rf /data $Y`（tiers 含 unknown/outside/priv）
    // 在 priv=auto/回落 deny、其余无值时也得 allow。
    // 缺省 ask：与 index.js 的 normalizeAutoFallback 同源（模型失败后问人，方向安全）；
    // 没配回落值的 auto 档按 ask 参与合并（跳过它会让另一档的 allow 独占结果 —— 放宽）。
    let autoFallback = null
    if (action === 'auto' && ds) {
      const afs = (ds.autoFallbacks && typeof ds.autoFallbacks === 'object') ? ds.autoFallbacks : null
      autoFallback = strictestFallbackOf((Array.isArray(tiers) ? tiers : [])
        .filter((u) => ds[u] === 'auto')
        .map((u) => (afs ? afs[u] : null))) || 'ask'
    }
    // ── 拒绝理由：判据是「**最终**会执行哪个动作」，不是「第一层动作是什么」──────────
    // `auto` 是两层的（action + autoFallback），而 `auto + 回落 deny` 在执行侧就是一次
    // 拒绝 —— 与裸 `deny` 走同一条 kind:'deny' 通道回给 AI。此前这里只判
    // `action === 'deny'`，于是那一支的 `reasons[tier]` **永远取不到**：用户给某一档配了
    // 「自动审批、失败后拒绝」并写了理由，AI 收到的却是空的。
    //
    // 这与 index.js 的 finalActionOf 是同一条判据的两个实现（宿主与解析器分处两个模块、
    // 无法共用函数），改一处必须同步改另一处。
    const finalAction = finalActionOf(action, autoFallback)
    if (finalAction === 'deny' && ds) {
      const reasons = ds.reasons
      const reasonOfTier = (u) => {
        const r = (u && reasons && typeof reasons === 'object') ? reasons[u] : null
        if (r) return r
        // 旧契约的裸 `reason` 字符串 → `inside` 档的兜底（见 tierTableOf 与宿主的读取侧）
        return u === 'inside' ? (ds.reason || null) : null
      }
      // 第一顺位：决定动作的那一档（动作就是它定的，理由理应先取它）
      const r = t ? reasonOfTier(t) : null
      if (r) return { action, reason: r, autoFallback }
      // 第二顺位：与它**并列在最严档**上的其余命中档，按 `TIER_RANK` 的次序逐个试。
      //
      // 并列的判据用「决定动作那一档的动作严格度」而不是 `TIER_STRICTNESS[action]`：
      // action 可能是 auto（严格度 1），而最终动作是 deny —— 用 action 的严格度去比，
      // 会把 ask 档也当成并列（ask 与 auto 同为 1），把**没在拒绝的档**的理由取出来。
      const rank = t ? TIER_STRICTNESS[ds[t]] : TIER_STRICTNESS[finalAction]
      const same = []
      for (const u of (Array.isArray(tiers) ? tiers : [])) {
        if (u !== t && TIER_STRICTNESS[ds[u]] === rank) same.push(u)
      }
      // 排序键复用 `sortTiersByRank`（与 `tierSetOf` / 整行分支**同一个**函数）。
      // 这里曾经手抄一份逐字相同的比较函数，而「抄漏一处」正是发现 3 的成因：
      // 同一份 `TIER_RANK` 出现在两处时，改一处而漏另一处的后果是**动作不变、
      // 拒绝理由随书写形态漂移**，且这一处直接决定用户可见的拒绝理由。
      // `same` 是本函数内的局部新数组，原地排序无副作用。
      sortTiersByRank(same)
      for (const u of same) {
        const ru = reasonOfTier(u)
        if (ru) return { action, reason: ru, autoFallback }
      }
    }
    return { action, reason: null, autoFallback }
  }
  const base = (action, code, reason, ruleId, note) => ({
    action,
    code,
    segments: [],
    matched: ruleId || null,
    reason: reason || null,
    note: note || null,
    // 这条 base 用于「整行读不懂 / 空命令」等**没有段**的路径，动作来自大分类（catOf）。
    // catOf 的契约**含 `autoFallback`**（见那里的注释），整行分支在下面按判定链补上；
    // 这里仍不给 —— 走到 base 时尚未判定，动作若是 auto 由 commandDecision 回落缺省 ask
    // （与 normalizeAutoFallback 的缺省一致，方向安全：问人）。
    autoFallback: undefined,
  })

  const d = decomposeCommand(source, sh)
  // 整行读不懂（未闭合引号 / 重定向无目标 / 悬空操作符 / 空命令）：没有段可判，落分类默认值。
  // 「空命令」与「有构造读不懂」分开标注：排查时的下一步不同 —— 前者要看调用方为什么发了空串，
  // 后者要看解析器覆盖缺了什么。注意 `decomposeCommand` 对「无段可产出」返回的也是 ok:false
  // （reason 见下），所以这里按 reason 分流；下面**不再**需要 segments.length 的兜底分支
  // （ok:true 时 segments 恒非空，那条分支曾经是不可达的死代码）。
  //
  // 但**deny 例外要照常查**：整行读不懂不等于「用户可以拒绝的命令就不算数」。
  // 实测漏洞：例外 `rm *`=deny 时 `rm -rf /data` 是 deny，而合法 heredoc
  // `rm -rf /data <<EOF\nx\nEOF` 因为整行 ok:false 直接落分类默认值 —— 用户显式写的拒绝被绕过。
  // 这里用「原文粗提命令名」查例外：只认 deny（收紧方向，多认几个名字是安全的），
  // allow/ask 一律不认（读不懂的内容不可被授权）。
  // 整行读不懂时同样要走**完整的判定链**：deny 例外 → 破坏性子设置 → 分类默认值。
  // 之前这里只查 deny 例外、然后直接落分类默认值，**完全没调用 h.destructive()** ——
  // 于是给破坏性命令套一个 heredoc 就能绕过子设置（而子设置正是「大分类设为 allow 时
  // 保护破坏性命令」的唯一一道闸）：
  //   `rm -rf /data` → deny，而 `rm -rf /data <<EOF\nx\nEOF`（合法 heredoc，会真实执行）→ allow。
  // 这与段级那条修复（`destructive` 不再依赖 `unparsable`）是同一个道理：
  // 「原文里认得出 rm」这个事实不受「整行还有读不懂的构造」影响。
  //
  // 命令名仍用 rawCommandNames 粗提（只用于**收紧方向**：查例外与破坏性名单）；
  // allow 例外在这条路径上不认（读不懂的内容不可被授权）；deny / ask / auto 照常生效，
  // 且**取最严**（TIER_STRICTNESS，并列时显式 ask 压过 auto）—— 与段级 opaque 路径
  // （`ex.action !== 'allow'`）同一条判据。丢弃 ask 不是「不授权」而是「不问人」，
  // 那是**放宽**：`git status $(x)` 是 ask，加个 heredoc 却变 allow。
  if (!d.ok) {
    const c = catOf()
    const code = d.reason === EMPTY_COMMAND_REASON ? 'empty' : 'unparsable'
    let action = c.action
    let reason = c.reason
    let ruleId = null
    let note = null
    // 初值取分类默认值那一份：`code === 'empty'` 时判定链整段不执行，动作就是 `c.action`，
    // 回落值必须同源带上。下面每个分支都会**显式重设**它（不留残值）。
    //
    // ── 但「整行读不懂」时同样只保留收紧方向（D-4，与下面 opaque 段 ③ 同一条判据）──────
    // 分类默认值可以是 auto，其回落值是 auto 的第二层：`allow` 回落 = 模型失败后无人在环
    // 放行（`timeoutMs=0` 不弹窗直接放行）。原样带出等于把第一层刚堵掉的授权从第二层
    // 放回来：分类 `auto/allow` 时 `git status $(curl evil)` 修复前 auto/ask、改后 auto/allow。
    //
    // **空命令不适用 D-4**：它不是「读不懂」，是「没有内容可读」（`decomposeCommand` 用
    // `EMPTY_COMMAND_REASON` 单独分流），故 `code === 'empty'` 保持原样带上整份回落值。
    // 曾把这一支也改成只留 deny，空命令当场从 `auto/allow` 变 `auto/ask` —— 那是过度收紧。
    let autoFallback = code === 'empty'
      ? c.autoFallback
      : ((c.action === 'auto' && autoFallbackOf(c.autoFallback) === 'deny') ? 'deny' : null)
    if (code !== 'empty') {
      // 方言维度（本轮缺陷 2 的修法）：`rawCommandNames` 只收文本、内部按 bash 判赋值，
      // 而赋值判据是**方言相对**的（见 `rawCommandNamesWithShell`）——pwsh 侧不传方言
      // 会让构造里的靶形态（`echo $(A=/bin/rm)`）认不出命令名 ⇒ 用户显式写的 deny
      // 例外被静默绕过（fail-open）。这条路径**只认 deny**（收紧方向），故传方言安全。
      // ⚠️ else 分支保持 `rawCommandNames(...)` 的字面形态：`test/regressions.mjs` 的
      //    结构断言要求它出现在 `if (!d.ok) {` 之后（见 `rawCommandNamesWithShell`）。
      const src = String(source == null ? '' : source)
      const names = sh === 'pwsh' ? rawCommandNamesWithShell(src, sh) : rawCommandNames(src)
      // ① 例外（deny / ask / auto 生效；allow 不认）
      //
      // **必须取最严，不能「命中即 break」**：`h.matchException` 是「单条返回、首条命中」
      // （见宿主的 matchSegmentException：项目层 → 全局层、层内按数组顺序），它**不做**
      // deny > ask 排序 —— 那个排序在段级路径上由 resolveException 自己做。整行路径是
      // 按 names 逐个调用，若命中 ask 就 break，后面那个 name 的 deny 就再也不会被问。
      // 实测（例外 `curl *`=ask 在前、`rm *`=deny 在后）：
      //     curl https://example.com && rm -rf /data <<EOF…EOF
      //       命中即 break → **ask**（用户的 deny 被丢掉 = 放宽）；取最严 → deny。
      // 并列（TIER_STRICTNESS 同为 1）时显式 ask 压过 auto，与 decisiveTierOf 的 tie-break 同源。
      let denied = false
      let bestEx = null
      // 未知动作的例外（手改配置的笔误 / 更高版本写入的动作）：**不短路判定链**，
      // 只在最后给一个 `ask` 的**下界**。见下面 `unknownEx` 的用法。
      let unknownEx = null
      // ── 未知动作：按 ask **参与排序**，并列时**不得顶掉**本版认识的动作 ────────────
      // 上一轮只给段级 `resolveException` 加了 unknown 槽（`ask || unknown || auto || allow`），
      // 本分支却用 `TIER_STRICTNESS[ex.action]` 查不到就 `continue` —— 未知动作的例外
      // 在整行读不懂时**整个消失**，于是「未知动作折 ask」这条闸被绕过（fail-open）：
      //     例外 `git *`=atuo（手改配置的笔误）、子设置八档 ask、分类 allow
      //     git status -s   → ask（段级 segment-unknown-action）
      //     git status <<EOF→ **allow**（整行分支：例外被丢 → 破坏性子设置未命中 → 分类）
      // 故未知动作按 `ask` 的严格度（1）参与比较，最后再折成 `ask` 输出（与段级
      // `anyUnknown → 'ask'` 同形）。**不是** `?? 1` 那种只改第一处查表的写法：
      // 那样 tie-break 里的 `TIER_STRICTNESS[bestEx.action]` 仍是 `undefined`，
      // `s > undefined` 恒假 ⇒ 已选中的未知动作**永远顶不掉**，实测
      // 「未知 `git status*` 在前 + deny `rm*` 在后」的 `git status && rm -rf /data <<EOF`
      // 由 deny 变 **atuo**（放宽）。
      //
      // ⚠️ 并列时**认识的动作优先**：未知动作折 ask 的语义是「没人表态，问人」，
      // 而一个已知的 `auto/deny` 例外（最终动作 deny）是**更强**的表态 —— 让未知动作
      // 在并列时胜出会把它顶成 ask，那是 deny→ask 的放宽（实测：例外 `rm *`=atuo 在前、
      // `git status *`=auto/回落 deny 在后，`rm -rf /data && git status <<EOF` 由
      // auto/deny 变 ask，而段级合并给的是 auto/deny）。方向与段级
      // `ask || unknown || auto || allow` 一致：未知动作只在没有更强表态时才折 ask。
      const knownAction = (v) => Object.prototype.hasOwnProperty.call(TIER_STRICTNESS, v)
      const rankOfEx = (v) => (knownAction(v) ? TIER_STRICTNESS[v] : 1)
      if (h.matchException) {
        for (const name of names) {
          let ex = null
          try { ex = h.matchException(name, name) } catch (e) { ex = null }
          if (!ex || ex.action === 'allow') continue
          const s = rankOfEx(ex.action)
          const sb = bestEx === null ? -1 : rankOfEx(bestEx.action)
          if (bestEx === null || s > sb
            || (s === sb && ex.action === 'ask' && bestEx.action === 'auto')
            || (s === sb && knownAction(ex.action) && !knownAction(bestEx.action))) bestEx = ex
        }
      }
      if (bestEx && knownAction(bestEx.action)) {
        action = bestEx.action
        reason = bestEx.reason || null
        note = bestEx.note || null
        ruleId = bestEx.ruleId || null
        // auto 的第二层：读不懂时**只保留收紧方向**（D-4，与段级 opaque 的 9868 同形）。
        // 其余回落值（allow / ask / 缺省）一律不建键，由 commandDecision 末尾的 `|| 'ask'` 补。
        autoFallback = (bestEx.action === 'auto' && autoFallbackOf(bestEx.autoFallback) === 'deny') ? 'deny' : null
        denied = true
      } else if (bestEx) {
        // ── 未知动作：`ask` 是**下界**，不是「命中即定案」（与上面 known 支分开）──────────
        // 不能像 known 支那样 `denied = true` 直接短路破坏性子设置 —— 那会让一条
        // **笔误的例外**顶掉用户为这一档显式配的 `deny`。实测（`outside=deny`、
        // 例外 `git *`=atuo）：
        //     git status && rm -rf /data <<EOF
        //       base（例外被丢）      → **deny**（子设置命中 rm 的 outside 档）
        //       短路子设置            → **ask** ← deny 被一条读不懂的例外顶掉（放宽）
        //       取下界（本实现）       → **deny** ✅
        // 而下界仍堵住本项要修的那个洞：判定链给出 allow 时一律抬到 ask。
        // 与段级 `resolveException` 的 `ask || unknown || auto || allow` 同向 ——
        // 那里 unknown 也只是「排在 allow 之前」，不越过 deny / ask。
        unknownEx = bestEx
      }
      // ② 破坏性子设置（更细的判定，优先于分类默认值）
      if (!denied && names.some((n) => isDestructiveLabel(n))) {
        const ds = tierTableOf()
        // ── 整行读不懂时的档位集合 ─────────────────────────────────────────────
        // 这条路径**没有词元**，故 `segmentLabels` 用不上，退化为「原文粗提的名字是否命中组表」
        // ——方向仍是收紧：多认几个名字只会让更多档参与「取最严」，不会放宽任何东西。
        //
        // 半径档在这条路径上取不到（没有词元可判），故半径侧由 `wide` 与 `unknown` **同时**
        // 参与「取较严」；组档是额外的收紧来源。
        //
        // **不得回落到 `inside`**：`inside` 是八档里唯一**跟随大分类**的那一档，而大分类常态是
        // allow —— 回落到它等于「给破坏性命令追加一个读不懂的构造即可静默放行」
        // （`rm -rf C:/Windows <<EOF` 由 ask 变 allow）。
        //
        // ── 为什么是两个都并入，而不是只取较严的那一个或只在没组档时回落 ──────────
        // ① 不能只取单值：`BLAST_ORDER` 是**严重度序**，而用户配置的是**动作**，两者不同构。
        //    取单值时 wide=deny + unknown=allow 会让 `rm -rf C:/Windows <<EOF` 变 allow；
        //    并入两者只会让结果不松于现状（取最严对新增档是单调的）。
        // ② 不能只在「一个组档都没命中」时才回落：那样命中组档的命令反而更松 ——
        //    `priv=allow` 时 `sudo rm -rf /` 是 ask，加个 heredoc 反而变 allow。
        //    半径侧在这条路径上读不出，但**读不出不等于不存在**。
        //
        // 注意这条路径上并 `wide` 并不是「凭空多一个档」：能走到这里的前提是
        // `names.some(isDestructiveLabel)`（原文里确实认出了一个破坏性命令名）。
        //
        // ⚠️ 上面的 `push` 顺序不是 `TIER_ORDER`（组档在前、半径档在后），故拼完之后
        // **必须排一次序** —— 否则**动作不变、拒绝理由随书写形态漂移**（`decisiveTierOf` 的
        // 稳定性论证只对 `tierSetOf` 已排序的产物成立）。排序键复用同一个 `TIER_RANK`。
        const tiers = groupTiersOf(names)
        if (segmentPrivilege(names)) tiers.push('priv')
        // 半径侧读不出 —— 档位集合与段级 opaque 段**单点共用**
        // （`RADIUS_TIERS_WHEN_UNREADABLE`：`wide ∪ unknown ∪ inside`，见该常量的注释）。
        // ⚠️ `inside` 照旧**并入**（不是「回落到它」）：它跟随大分类，但用户可能显式
        // 配了 `inside=deny`，丢掉它就等于丢掉一条显式表态。
        //
        // ⚠️ 裸 push 即可：本处的 `tiers` 只有两个产出者（`groupTiersOf(names)` 与上面那行
        // 字面量 `'priv'`），与 `RADIUS_TIERS_WHEN_UNREADABLE` 的值域无交集，去重条件恒真。
        // 不能删掉整行：三档仍须并入（`inside` 见上，用户可能显式配了 `inside=deny`），
        // 删掉才是 fail-open。
        for (const t of RADIUS_TIERS_WHEN_UNREADABLE) tiers.push(t)
        // ── `outside` 档：**只在原文里读得出区外目标时**才并入──────────
        // 上面那三档是「半径侧读不出」的通用口径，而 `outside` 是**具体**档 ——
        // 无条件并入会让 58d / 58e3（八档全 allow 的用户）凭空多出一个档。
        // 判据见 `outsideTargetInUnparsable`：与段级路径对同一目标给出的结论同源。
        if (outsideTargetInUnparsable(source, h)) tiers.push('outside')
        // 排序键与段级路径**同一个**函数（`sortTiersByRank` 复用 `TIER_RANK`）——
        // 这里曾经手抄一份逐字相同的比较函数，而「抄漏一处」正是发现 3 的成因。
        sortTiersByRank(tiers)
        const v = tierVerdict(ds, tiers, true)
        if (v.action !== 'inherit') {
          action = v.action
          reason = v.reason
          // 显式重设（不是「有值才覆盖」）：inherit 时保留分类默认值那一份，
          // 有具体动作时回落值必须与动作**同源**，不得残留上一步的值。
          // ② 的回落值同样**不适用 D-4**（allow 来自用户为这一档显式配置的表，理由见段级 opaque 分支 ②）
          autoFallback = v.autoFallback
        }
      }
      // ── 未知动作例外的 `ask` 下界（本项修法的落点）───────────────────────────────
      // 放在整条判定链**之后**：子设置可能给出更严的 `deny`（或 `auto` + 回落 `deny`，
      // 后者最终动作也是 deny），那些表态比一条本版读不懂的例外更具体，不得被顶掉。
      // 只在最终落点**比 ask 松**时抬到 ask。
      //
      // 判据必须问**最终动作**（`finalActionOf`）而不是第一层动作：`auto` 是两层的，
      // `auto/allow` 的最终动作是 **allow** —— 模型失败后无人在环放行，比 ask 松。
      // 只看 `action === 'auto'` 会把它漏掉（实测：例外 `rm *`=atuo + 子设置八档
      // `auto/回落 allow`，`rm -rf /data <<EOF` 给 **auto/allow**，而同一命令的段级
      // 结论是 **ask**（`resolveException` 的 unknown 槽折 ask）—— 同一语义两个结论，
      // 且松的那一侧正是本项要修的方向）。
      // 抬升时把归因指向那条例外（`ruleId` / `note` 一起搬）—— 弹窗上要能看出
      // 「这次弹窗是因为一条读不懂的例外」，而不是一条无主的 ask。
      if (unknownEx && TIER_STRICTNESS[finalActionOf(action, autoFallback)] < TIER_STRICTNESS.ask) {
        action = 'ask'
        reason = null
        note = unknownEx.note || null
        ruleId = unknownEx.ruleId || null
        autoFallback = null
      }
    }
    const r = base(action, code, reason, ruleId, note)
    // auto 的回落值：base() 恒返回 undefined（它服务的是无段的路径），故在这里补 ——
    // 整行读不懂但子设置 / 分类默认值给出了 auto 时，仍要有回落值。
    // 只有 auto 才建这个字段（与 reason 仅 deny / note 仅 ask 同一条纪律）；缺省 ask。
    if (action === 'auto') r.autoFallback = autoFallback || 'ask'
    return r
  }

  const out = []
  let anyDeny = false
  let anyAsk = false
  let anyAuto = false
  let anyInherit = false
  let anyUnknown = false

  // 例外匹配单点（opaque 段与可读段共用，避免两份实现漂移）。
  //
  // 试哪些对象：段原文 → 全部 label（主 label + 并集提取出的额外名字）。
  // 只试「段原文 + 主 label」会让「子设置能拦、用户的 deny 例外却拦不住」形成不对称 ——
  // 实测（例外 `rm *`=deny + 子设置 allow）：
  //   `rm -rf /x`                → deny（例外命中）
  //   `find . -exec rm -rf {} +` → **allow**（主 label 是 `find`，`rm` 在额外 label 里）
  //   `find . -delete`           → **allow**（同上）
  // 即用户显式写的「rm 一律拒绝」被 find 的间接执行绕过。
  //
  // 优先级：**deny > ask > allow**。allow 命中后不能立即收工，否则
  // 「外层命令的 allow 例外」会短路「内层命令的 deny/ask 例外」——
  // 实测（例外 `echo *`=allow + `rm *`=deny）：`echo $(rm -rf /x)` 曾 allow，
  // 而用户显式写了 rm 的拒绝；`rm *`=ask 时同样被规避。
  // 这与段级合并「拒绝面取并集、放行面取交集」是同一条原则。
  //
  // 每个对象试两次（原文与 label 都传同一个值）是**有意**的：宿主的 matchException 内部
  // 会拿「段原文」与「归一化 label」各匹配一次，这里传什么它就试什么 —— 传原文即让它
  // 用原文口径匹配，传 label 即让它用 label 口径匹配。两个口径都需要。
  //
  // ── 两个方向用**不同的** label 集合（本次修复的安全要点）────────────────────────
  // `allLabels` 是并集，其中可能含**提权前缀扩展出的**名字（`sudo kill 1234` → `kill`）。
  // 那个扩展只论证了**收紧**方向（让破坏性名单与 deny 例外看得见 `sudo` 之后的真命令），
  // 而例外同时有 **allow** 动作 —— 同一份 labels 若也用于授权，用户为普通 `rm` 写的
  // `rm *`=allow 就会命中 `sudo rm -rf /`：「允许删工作区内的文件」被静默提升成
  // 「允许经 sudo 删任意路径」。实测（两侧子设置动作完全等价、只有 label 扩展不同）：
  //     sudo rm -rf /etc / sudo rm -rf / / sudo -u root rm -rf /etc
  //     改前 ask → 改后 allow（source=exception）
  // 故授权方向只查 `allowLabels`（= 并集滤掉前缀扩展出的名字，由每个段在调用前设置）。
  // 收紧方向（deny/ask）照旧查全部 `allLabels` —— 那条既有漏洞的修法不能被削掉。
  let allowLabels = null
  // 授权面的 `Set` 视图：与 `allowLabels` 同源、同一次计算产出，避免在
  // `resolveException` 的 label 循环里对数组做 `indexOf`（那是 O(n²)）。
  let allowLabelSet = null
  const resolveException = (segText, allLabels) => {
    if (!h.matchException) return null
    const tryOne = (t) => {
      try { return h.matchException(t, t) || null } catch (e) { return null }
    }
    let allow = null
    let ask = null
    let auto = null
    // 未知动作（手改配置 / 未来版本的动作）在 `first` 那一支原先靠 `else` 落进 allow 槽。
    // 加了 auto 槽之后，auto 排在 allow 之前，于是「段原文命中未知动作 + label 命中 auto」
    // 会从折 ask（anyUnknown）变成 auto/allow —— 那是**放宽**。
    // 故未知动作必须有**自己的**槽，并保持它原有的位置（在 auto 之前、仍折 ask）。
    let unknown = null
    // 多个 auto 候选之间回落值**取严**（deny > ask > allow，缺省按 ask 参与）——
    // 与 tierVerdict / 段间合并同一条纪律。只取第一个会让回落值取决于 label 顺序：
    // 实测（例外 `find *`=auto/allow + `rm *`=auto/deny 同段命中）第一个是 find → allow。
    const takeAuto = (r) => {
      if (!auto) { auto = r; return }
      const a = autoFallbackOf(auto.autoFallback) || 'ask'
      const b = autoFallbackOf(r.autoFallback) || 'ask'
      if (AF_STRICTNESS[b] > AF_STRICTNESS[a]) auto = r
    }
    const first = tryOne(segText)
    if (first && first.action === 'deny') return first
    if (first && first.action === 'ask') ask = first
    else if (first && first.action === 'auto') takeAuto(first)
    else if (first && first.action === 'allow') allow = first
    else if (first) unknown = first
    // 收紧方向：`ask` 不是授权、`deny` 只会收紧，两者用扩展出的 label 都安全 ——
    // 这正是「用户写的 `kill *`=deny 拦不住 `sudo kill 1234`」那条既有漏洞的修法。
    //
    // ── 两个方向合并成**一趟**，不把同一批 label 查两遍宿主匹配器 ──────────────────
    // 拆成两轮时第二轮遍历的是 `allowLabels`，而它（= 并集滤掉前缀扩展名）除极少数
    // `widened` 项外与 `allLabels` **逐项相同** —— 同一批 label 被原样问了第二遍宿主
    // 匹配器，是纯重复工作。实测宿主的 `matchException` 调用次数：
    //     单 label 段（`git status -s`）  3 → 6（+100%）
    //     带提权扩展的段（`sudo rm -rf /etc`）  4 → 8（+100%）
    // 墙钟（60 条例外、命令不命中）：`git status -s` 38.7 → 71.5 µs。
    //
    // 合并后**语义逐字不变**，两处细节：
    //   · 授权候选仍**只**取 `allowed`（= `allowLabels`，并集滤掉前缀扩展出的名字）
    //     —— 这是上一轮的安全修复，不得回退：`rm *`=allow 不得命中 `sudo rm -rf /etc`，
    //     而 `rm *`=deny 仍须命中。判据直接问那个集合（由 `segmentLabelsCore` 单点产出），
    //     不另算一份「哪些 label 是扩展来的」。
    //   · `segText` 那一趟仍在最前（它优先，且 `deny` 立即返回），保持原有优先级。
    //   · 授权面判据用 **`Set`**（`allowSet`）而不是数组 `indexOf`：逐项 `indexOf`
    //     在「labels 多且逐条不同名」时是 O(n²)。语义逐字不变（同一个集合、同样的判据）。
    const allowed = allowLabels || allLabels
    const allowSet = allowLabelSet || new Set(allowed)
    for (let i = 0; i < allLabels.length; i += 1) {
      const r = tryOne(allLabels[i])
      if (!r) continue
      if (r.action === 'deny') return r
      if (r.action === 'ask' && !ask) ask = r
      // auto 与 allow 一样是**授权方向**（auto 只是把判断交给模型，不是收紧），
      // 故用同一个 `allowSet` 判据；前缀扩展出的名字在这一轮同样不可见。
      // ⚠️ **不要**为了「让 `sudo rm` 也命中」改成 allLabels：实测那会让
      // `rm *`=auto/allow 命中 `sudo rm -rf /` / `doas` / `pkexec` / `sudo -u root`，
      // 而 `rm *`=allow 对同样形态是 ask —— 把上一轮「授权不得穿过提权前缀」的修复回退掉。
      if (r.action === 'auto' && allowSet.has(allLabels[i])) takeAuto(r)
      // 授权方向：前缀扩展出的名字（`sudo kill 1234` → `kill`）在这一轮不可见。
      // 判据按**值**查 `allowed`（= `allowLabels`，即并集滤掉扩展名）：labels 已去重，
      // 故与原先「遍历 allowed 数组」逐项等价，且顺序也一致（filter 保序）。
      if (r.action === 'allow' && !allow && allowSet.has(allLabels[i])) allow = r
    }
    // 顺序 = 「deny > ask > auto > allow」：deny 已在上面的循环里立即返回；
    // ask 代表「问人」、auto 代表「问模型」，人优先于模型，故 ask 在 auto 前。
    // unknown（未知动作）与 ask 同列：它只会让人多确认一次，方向 fail-closed。
    return ask || unknown || auto || allow
  }

  for (const seg of d.segments) {
    const labelSet = segmentLabelsCore(seg.words)
    // 前缀扩展出的名字（`sudo kill 1234` → `kill`）。**例外匹配按方向取用**：
    // 收紧方向（deny/ask）可以用，授权方向（allow）不可以 —— 见 segmentLabelsCore 的注释。
    // 读取一律走 `labelSet.widenedSet`（O(1)），不再用数组 `widened`。
    let labels = labelSet.labels
    // opaque 段（或提取不出词元的段）**额外**用原文粗提命令名，取并集。
    //
    // 为什么是并集而不是「提不出词元时才回退」：opaque 构造会把**段内**的真实命令藏起来，
    // 而词元列表只包含 opaque 构造**之外**的部分 —— 于是两种漏判各有一条路径：
    //   · 提不出词元（`(rm -rf ~/.dsh)` 的 words 是空的）→ label 为空 → 破坏性判定恒 false；
    //   · 提得出词元但真命令在 opaque 构造里（`echo $(rm -rf ~/.dsh)` 的 label 是 `echo`）
    //     → 破坏性判定看的是 `echo`，`rm` 根本不在视野里。
    // 两者是同一件事（读不懂的构造里藏着命令），必须一起堵。实测（command=allow + destructive=deny）：
    //   `(rm -rf ~/.dsh)` / `{ rm -rf ~/.dsh; }` / `(cd /tmp; rm -rf ~/.dsh)` → 曾全部 allow
    //   `echo $(rm -rf ~/.dsh)` / `case x in a) rm -rf ~/.dsh;; esac`     → 曾全部 allow
    //
    // 只对 **opaque 段**做并集，可读的段不加：可读段的词元已经是权威答案，
    // 再拿原文粗提只会引入噪音（`git log --format=...` 之类参数里的词）。
    // 方向始终 fail-closed：多提几个名字只会让 deny 例外与破坏性名单更容易命中，不会放宽。
    if (seg.opaque) {
      // 方言**一次取定**：`rawCommandNamesWithShell` 就是那个带方言维度的出口，两门方言各取各的。
      //
      // 原先写「先按 bash 算一份、pwsh 时再整体覆盖」，那份中间结果在 pwsh 路径上是**死值** ——
      // 而 `rawCommandNamesInto` 是这条路径上最重的一步（剥 heredoc 正文 + 剥单引号 +
      // 逐字符扫出命令替换并递归展开 + 按分隔符 `split` + 每片一次 `segmentLabels`），
      // 等于把同一份原文白解析了两遍。实测 pwsh `echo $(…)` ×13000 单段（143 KB）：
      // 37.6 ms → 18.4 ms（相对同形 bash 对照 ×2.01 → ×0.97）；真实形态 5.7 KB 同为两倍量级。
      //
      // 取值与旧写法**逐字相同**：pwsh 支取的就是同一个调用；bash 支的
      // `rawCommandNamesWithShell(t, 'bash')` 与 `rawCommandNames(t)` 是**同一个**内部调用
      // —— 两个出口都只是 `rawCommandNamesInto(text, 'bash', …)` 的薄壳。
      const names = rawCommandNamesWithShell(seg.text, sh)
      if (names.length) {
        // 无原型：键是 label（来自命令文本），`{}` 会让原型属性名恒判「已见过」而漏合并。
        const seen = Object.create(null)
        const merged = []
        for (const l of labels.concat(names)) { if (l && !seen[l]) { seen[l] = 1; merged.push(l) } }
        labels = merged
      }
    }
    const label = labels[0] || ''
    // 授权方向可用的 label 集合 = 并集滤掉**前缀扩展出的**名字（见 resolveException 的注释）。
    // 放在 opaque 并集**之后**算：rawCommandNames 补进来的名字同样可能含扩展名，
    // 而它走的是「收紧方向」（只用于查 deny 例外与破坏性名单），故不该进授权面。
    // 判据用 `labelSet.widenedSet`（**O(1)**）而不是对 `widened` 数组做 `indexOf`：
    // 同一个集合、同一个判据，只是查询复杂度从 O(len) 降到 O(1)。
    allowLabels = labels.filter((l) => !labelSet.widenedSet.has(l))
    allowLabelSet = new Set(allowLabels)
    const unparsable = !!seg.opaque || !label || nestedInlineProgram(label, seg.words)
    // 破坏性判定**不依赖** unparsable：段首 label 已经认出来是 rm，这个事实不受
    // 「同一段里还带了个 $(...)」影响。曾经写成 `!unparsable && isDestructiveLabel(label)`，
    // 于是段内任意 opaque 构造（`$()`、反引号、`( )`/`{ }` 分组、`{a,b}` 展开、`env -S`）
    // 都会让该段跳过子设置、直接落大分类 —— 大分类为 allow 时破坏性命令即被静默放行
    // （实测：`rm -rf ~/.dsh` 是 deny，`rm -rf ~/.dsh $(true)` 是 allow；
    //  同一机制还能绕开用户显式写的 deny 例外）。
    // opaque 只该影响「能否被例外授权」，不该影响「是否走子设置」。
    const destructive = labels.some((l) => isDestructiveLabel(l))
    const writeOutside = writeOutsideOf(seg, sh, h)

    // 爆炸半径：**只在破坏性段上算**（`echo B:\` 不是删除，警告它就是噪音）。
    // 与 code 分开下发、不参与动作选择 —— 它只回答「这一下有多重」，供弹窗与列表展示。
    //
    // 开关判据（cmd 的 `/s` 是开关、POSIX 的 `/etc` 是路径）只看 `opts.platform`，
    // **不看方言**：方言不等于平台（Linux 上跑 PowerShell Core 时方言是 pwsh、路径是 POSIX 的），
    // 故这里不再传 `shell`（曾经传了但全模块无人读取，是死参数）。
    //
    // **位置必须在这里**（而不是原处的 code 之后）：档位集合要读 `seg.blast`
    // （`tierSetOf` 的第一个参数），而档位决定动作 —— 先算档位再算半径就晚了。
    const blast = destructive ? blastRadiusOfSegment(seg.words, h) : null
    // 命中的全部档位（§3.3）。**只在破坏性段上算**，非破坏性段恒为空数组 ——
    // 它们没有档位可言（落大分类），填一个 `inside` 反而会让「命中档位」失去意义。
    //
    // `opaque` 必须一起传：`(rm -rf /etc)` 的 words 是空的（词法器把分组整块吞掉），
    // `blastRadiusOfSegment` 因此返回 `null`，而 `null` 在 §5.1 里映射成 `inside`
    // —— 「目标读不出」会被当成「目标在区内」。`tierSetOf` 靠这个字段把它改判 `unknown`。
    //
    // `opaqueTexts` 同样必须一起传：`destructiveHeadReadable` 要问
    // 「**opaque 构造自己**有没有藏一个破坏性命令」，而构造里的命令名不在 `words` 里
    // （词法器把构造整块吞掉），只能由词法器记下的构造原文回答。**漏传这一项会让该判据
    // 恒不生效**（`opaqueTexts` 缺席时按旧行为退化），靶格照旧 allow。
    const tiers = destructive
      ? tierSetOf({ words: seg.words, blast: blast, opaque: seg.opaque, opaqueTexts: seg.opaqueTexts }, labels, h)
      : []

    let action
    let source
    let reason = null
    let note = null
    let ruleId = null
    // auto 的回落值：只有 action 最终是 auto 时才会被赋值（见各分支）。
    // 与 reason（仅 deny）/ note（仅 ask）同一条纪律 —— 其它动作时不建这个字段。
    let autoFallback = null

    if (unparsable) {
      // 读不懂的段：只跳过**授权方向**的例外（allow），其余照常生效。
      //
      // 三条规则，按「会不会放宽」划界：
      //   · **allow 例外跳过** —— 读不懂的内容不可被授权。
      //     否则 `git status $(任意代码)` 会因为一条 `git status *` 例外被静默放行。
      //   · **deny 例外保留** —— 它只会收紧。跳过它等于让 opaque 构造成为
      //     「绕开用户显式拒绝」的手段（实测：例外 `rm *`=deny 时 `rm -rf /data` 是 deny，
      //     而 `rm -rf /data $(true)` 因为 opaque 跳过了例外面，反而落到大分类）。
      //   · **ask 例外保留** —— 它**不是授权，是「要求确认」**。曾经把它和 allow 一起跳过，
      //     后果是「每次都要问我」被降级为「静默放行」：实测（例外 `rm *`=ask、子设置/大分类均 allow）
      //     `rm -rf /data` 是 ask，而 `rm -rf /data $(true)` 是 allow —— 用户写的确认规则被规避。
      //     保留它不会放宽任何东西（ask 只会让人多确认一次），方向始终 fail-closed。
      //   · 子设置与分类默认值在下面照常生效（子设置比大分类「知道得更多」，见上）。
      //
      // 例外匹配：见 resolveException（与可读段共用同一份实现）。
      const ex = resolveException(seg.text, labels)
      if (ex && ex.action !== 'allow') {
        action = ex.action
        source = 'exception'
        reason = ex.reason || null
        // note 是 ask 例外的备注（弹窗上给人看「当初为什么特意拦它」），opaque 段同样要带上
        note = ex.note || null
        ruleId = ex.ruleId || null
        // 例外也可以是 auto（「这类命令交给模型判」），它的回落值是用户配置的一部分，
        // 必须随动作一起带出 —— 否则模型失败后按缺省 ask 处理，与配置不符。
        //
        // ── 但读不懂的段上**只保留收紧方向**（D-4「读不懂的内容不可被授权」）──────────
        // 上面的 `ex.action !== 'allow'` 只把 allow 排除在**第一层**（动作）之外，理由是
        // 「auto 只是委托模型、不是授权」。回落值是 auto 的**第二层**：模型超时 / 协议错 /
        // 熔断时按它执行，`allow` 回落 = 无人在环的放行（`timeoutMs=0` 不弹窗直接放行；
        // 默认 20 秒无人应答即放行）。原样带出等于把第一层刚堵掉的授权从第二层放回来：
        //     例外 `git status *`=auto/allow → `git status $(curl evil)` 修复前 auto/allow
        // 故这里只让 `deny` 通过，其余（allow / ask / 缺省）一律由 `commandDecision`
        // 末尾的 `|| 'ask'` 补成 ask。**不能删整行、也不能无条件 'ask'**：前者丢掉用户
        // 显式配的 deny 回落、后者同样把 deny 变成 ask，两者都是放宽。
        // 可读段分支（下面 ①）**不动** —— 用户要 allow 回落只能用在可读段上。
        if (ex.action === 'auto' && autoFallbackOf(ex.autoFallback) === 'deny') autoFallback = 'deny'
      } else if (destructive) {
        // ② destructive 子设置 —— 与可读段**同一份**档位判定（见下面那段注释）
        const v = tierVerdict(tierTableOf(), tiers, true)
        action = v.action
        source = 'destructive'
        reason = v.reason
        // auto 的回落值：与动作同源（v 已在全部 auto 档之间按 deny > ask > allow 从严合并，见 tierVerdict）
        // ② **不适用 D-4**：这里的 allow 来自用户**为这一档显式配置**的表，
        // 且已由 tierVerdict 在全部命中的 auto 档间从严合并；D-4 要堵的是 ①③ 那种从**不相干的授权源继承**来的 allow。
        // 可读的 `rm -rf /`（真 wide 目标）同得 auto/allow，不是新洞；收紧前先对齐整行读不懂分支的档位
        // 集合说明（`RADIUS_TIERS_WHEN_UNREADABLE`，见该常量的注释；本分支的 tiers 来自上面的 `tierSetOf`）。
        if (v.autoFallback) autoFallback = v.autoFallback
      } else {
        // ③ command 分类默认值 —— **读不懂的段上只保留收紧方向**（D-4，与 ① 的例外守卫同一条）。
        // 分类 `auto/allow` 的 `allow` 是 auto 的第二层：模型失败后无人在环放行。原样带出
        // 等于把 ① 刚堵掉的授权从第二层放回来（`git status $(curl evil)` → auto/allow）。
        // 可读段分支的 ③（下面 `} else {` 之后那一支）**不动** —— 用户要 allow 回落
        // 只能用在可读段上（与 ① 的例外守卫同一条边界）。
        const c = catOf()
        action = c.action
        source = 'category'
        reason = c.reason
        autoFallback = (c.action === 'auto' && autoFallbackOf(c.autoFallback) === 'deny') ? 'deny' : null
      }
    } else {
      // ① 用户例外（段级匹配）—— 显式表态，优先于子设置（D-5）。
      // 与 opaque 分支共用 resolveException：试段原文 + 全部 label，deny > ask > allow。
      // **allow 只认 allowLabels**（前缀扩展出的名字不参与授权）——见 resolveException 的注释。
      const ex = resolveException(seg.text, labels)
      if (ex) {
        action = ex.action
        source = 'exception'
        reason = ex.reason || null
        note = ex.note || null
        ruleId = ex.ruleId || null
        // 同 opaque 分支：例外上的回落值必须随动作带出（缺省仍由 commandDecision 补 ask）
        autoFallback = autoFallbackOf(ex.autoFallback)
      } else if (destructive) {
        // ② destructive 子设置 —— 更细的判定，优先于分类默认值（D-6）。
        //
        // ── 从「一个动作」改为「按命中的档位取最严」（§3.3 / §5.4）────────────────
        // 档位集合 = 半径档(blast) ∪ 组档(label 所属组) ∪ (提权 ? {'priv'} : {})，
        // 由 `tierSetOf` 选出、`strictestTierAction` 取最严。
        //
        // **`priv` 判据加在这个既有分支内部，不新开并列分支**：6 个提权名
        // （sudo/doas/su/pkexec/runas/gsudo）**全部在 DESTRUCTIVE_LABELS 里**（实测 19/19），
        // 故 `segmentPrivilege(words) === true` 时 `destructive` 必然也为 true ——
        // 新开分支只会得到一个恒不可达的并列分支，而它看起来像「提权有独立处理」。
        //
        // **不要为了「概念干净」把提权名移出 DESTRUCTIVE_LABELS**：提权名确实属于
        // 「权限」维度，摘掉看起来更干净 —— 但会打断解析器的既有依赖：
        // `commandHeadEnd` 用 `isDestructiveLabel(base)` 决定「吃掉命令名后停」，
        // `blastRadiusOfSegment` 用 `isDestructiveLabel(head)` 决定「引号内容是否递归」。
        // 提权名不在名单里，这些判据全部失效（实测现值依赖它们）：
        //   sudo rm -rf /                 → drive-root|/
        //   su -c rm -rf /                → drive-root|/
        //   sudo /usr/bin/find / -delete  → drive-root|/
        // **结论：名单不动。** 两个维度「正交」指的是**可独立配置**，
        // 不是「要拆到互斥的分支里」。
        const v = tierVerdict(tierTableOf(), tiers)
        action = v.action
        source = 'destructive'
        reason = v.reason
        // auto 的回落值：与动作同源（v 已在全部 auto 档之间按 deny > ask > allow 从严合并，见 tierVerdict）
        if (v.autoFallback) autoFallback = v.autoFallback
      } else {
        // ③ command 分类默认值
        const c = catOf()
        action = c.action
        source = 'category'
        reason = c.reason
        // 分类默认值也可以是 auto（面板上「执行命令」整类设为自动审批），
        // 它的回落值同样要随动作带出（catOf 已按合法值域归一）。
        autoFallback = c.autoFallback
      }
    }
    // 拒绝理由只在**最终会拒绝**时下发：allow 不弹窗用不上，ask 有自己的备注。
    // 这与 normalizeCategory / normalizeException 的存储侧口径一致（那边只在
    // `finalActionOf(...) === 'deny'` 时存 reason），这里是第二道闸 —— 存储侧的口径
    // 不该是唯一的保证。
    //
    // 判据是**最终动作**而不是第一层动作：`auto + 回落 deny` 在执行侧就是一次拒绝
    // （同一条 kind:'deny' 通道回给 AI），它的 reasons[tier] 必须留下。
    // 此前这里写 `action !== 'deny'`，那一支的理由被这一行**当场清空**。
    const finalAction = finalActionOf(action, autoFallback)
    if (finalAction !== 'deny') reason = null

    // 段级 code 仅供弹窗展示与决策日志（不参与动作选择）。
    // 优先级：确定的危险（label 精确命中名单）> 读不懂 > 写向工作区外。
    // 一个段可能同时是「破坏性」且「读不懂」（`rm -rf $(x)`）：报 destructive —— 那是
    // 用户更需要看到的信息，也是该段实际走子设置的原因。
    //
    // **`code` 与 `codeLabel` 的语义完全不动**（§7.2b）：档位走独立的 `tiers` 字段。
    // 理由见 tierLabel 的注释（三个冲突 + 维护成本对比）。test/shell-parse.mjs 有 37 处
    // `.code` 断言把它们当作判定结果的稳定标识 —— 改语义不是改数字。
    const code = destructive ? 'destructive' : (unparsable ? 'unparsable' : (writeOutside ? 'write-outside' : null))

    if (action === 'deny') anyDeny = true
    else if (action === 'ask') anyAsk = true
    else if (action === 'auto') anyAuto = true
    else if (action === 'inherit') anyInherit = true
    else if (action !== 'allow') anyUnknown = true

    // `words` / `opaque` 随段一起交回：判定内部已经算出了它们（`segmentLabelsCore(seg.words)`
    // 就在上面几行），而**消费侧此前拿不到** —— 宿主生成弹窗候选时只能把同一条命令
    // 再 `decomposeCommand` 一遍，于是同一条命令被解析两次、两次的段各带一半字段
    // （判定那份有 action 没有 words，分解那份有 words 没有 action）。
    // 后果是候选侧**无法知道某一段已经被放行**：`Get-ChildItem *` 已配成 allow 时，
    // 弹窗仍然给出 `get-childitem *` 候选，点一次就往配置里再写一条语义重复的例外。
    // 交回 words 后消费侧不必再解析，判定与候选看到的是**同一批段对象**。
    out.push({ op: seg.op, text: seg.text, words: seg.words, opaque: seg.opaque, label, action, source, code, ruleId, reason, note, dynamic: seg.dynamic, blast, tiers,
      // 只有 auto 段才有回落值：与 reason（仅 deny）/ note（仅 ask）同一条纪律。
      // 别的动作上带一个回落值既无意义，又会让「段间从严合并」误读一个不属于它的值。
      // 非 auto 时保持改前的 `null`（字段形状不变），auto 且钩子没给值时按缺省 ask 补齐。
      autoFallback: action === 'auto' ? (autoFallback || 'ask') : null })
  }

  // fail-closed 合并：拒绝面取并集、放行面取交集。
  // 注意这与「自定义规则首条命中」**不是**同一条原则，两者也不该统一：
  //   · 段之间是**并列**关系（一条命令里同时存在多个段，必须全部被授权才算授权），
  //     所以这里取并集/交集 —— 段没有「谁更具体」之分，只能整体从严；
  //   · 规则之间是**优先级**关系（用户用列表顺序表达「哪条更具体」），
  //     所以那边按顺序取首条，让「具体覆盖宽泛」可表达（见 decide() 的规则循环）。
  // 曾经把两者统一成「取最严」，结果是规则侧失去了表达力（实测：具体 allow 被宽泛 deny 吃掉）。
  //
  // ── 段间 autoFallback 从严合并（deny > ask > allow）──────────────────────────────
  // 回落值**是**权限判据 —— 它就是「模型超时 / 熔断 / 协议错时最终执行什么」。
  // 此前直接取 `decisive` 那一段的值，而 `decisive` 是 `out.find(...)` 的**第一个**匹配段，
  // 于是多段命令的回落值由**书写顺序**决定，把危险段写在后面即可绕过：
  //     `kill 1234; rm -rf /`（proc=auto/回落 allow、wide=auto/回落 deny）
  //     → 整条 auto，回落值取第一段的 allow ⇒ `rm -rf /` 在模型失败后被放行。
  // 段之间是**并列**关系（与上面 fail-closed 合并同一条原则），故回落值也只能整体从严；
  // 这与 index.js 的 outsideMatrix 在两道闸的回落值冲突时取更严是同构的。
  //
  // 严格度表用 **`AF_STRICTNESS`**（回落值专用域：allow < ask < deny 三键）——
  // 回落值不可能再是 `auto`（见该表的注释），故**不**复用含 `auto: 1` 的
  // `TIER_STRICTNESS`（那是动作域的序）。合并实现复用 `strictestFallbackOf`
  // （段内多档用的是同一个），缺省 ask 的规则也在那里。
  const mergedAutoFallback = strictestFallbackOf(out.filter((s) => s.action === 'auto').map((s) => s.autoFallback))
  let action
  let code
  if (anyDeny) { action = 'deny'; code = 'segment-deny' }
  else if (anyAsk) { action = 'ask'; code = 'segment-ask' }
  // ── 未知动作**必须排在 auto 与 inherit 之前**（两处 fail-open 的同一条修法）─────────
  // 槽序与段级 `resolveException`（`ask || unknown || auto || allow`）**同构**：
  // 未知动作折 ask，而 ask 是「要问人」、auto 是「问模型」，人比模型更该被问。
  //
  // 排在 auto 之前：反了时（HEAD 的 `anyAuto` 无条件优先）一条命令里只要有一段命中
  // auto 例外，其余段「本版读不懂的动作」就被整体吞掉。实测（例外 `rm -rf /data`=读不懂
  // 的值、`rm -rf /tmp`=auto/回落 deny）：
  //     `rm -rf /data`                      → ask（segment-unknown-action，弹窗）✅
  //     `rm -rf /data; rm -rf /tmp`         → auto/deny ❌ 未知段被完全忽略
  // 于是「把读不懂的那一段和任意一条 auto 例外拼在一起」就成了绕过未知动作闸门的手段，
  // 模型判 allow 时那条本应弹窗的段**无人在环**被执行。
  //
  // ⚠️ `auto/回落 deny` 也不例外 —— 这一格是**段间**与**段内**的分界，不能类比
  // `strictestTierAction` 的 `hasUnknown`：那里多档作用在**同一个段**上，用户对该段有
  // auto 授权，回落 deny 是它自己的第二层；段间是**不同段**，未知那一段没有 auto 授权，
  // 整条走 auto 等于把「问人」的要求换成「问模型」。`finalActionOf('auto','deny')` 只描述
  // 模型失败后的落点，不描述模型成功放行那条路径 —— 而那正是放宽发生的地方。
  // （同一条判据见 index.js 的 out()：未知 base 不被 `doom=auto`（含回落 deny）接管。）
  //
  // 排在 inherit 之前：反了时一条命令里只要有一段落 `inherit`，其余段的「本版读不懂的
  // 动作」就被整体吞掉，整条回 `inherit` —— 而宿主把 inherit 折算成大分类默认值
  // （command 分类常态是 allow）。实测：
  //     git status; echo hi   （例外 `git status`=未知动作，分类 inherit）
  //       → inherit → 宿主折算 allow   ❌
  //     单段 `git status` 同配置 → ask ✅（顺序只影响多段，正是本条要堵的）
  // 语义依据与 auto 那一条同源：`inherit` 表示「**该段**没有表态」，而未知动作
  // 是「有表态、只是本版读不懂」—— 有表态必须压过无表态。
  // 注意不能把 unknown 并进 anyAsk：那样 `code` 会变成 `segment-ask`，
  // 而弹窗/日志要靠 `segment-unknown-action` 区分「有人要求确认」与「配置读不懂」。
  else if (anyUnknown) { action = 'ask'; code = 'segment-unknown-action' }
  // ── auto 的合并位置：**deny / ask / 未知动作之后、inherit 之前** ────────────────────
  // 一条命令里若有段是 deny，整条就该 deny（模型不该有机会放行一个用户明确拒绝的段）；
  // 有段是 ask 或未知动作时同理 —— 那两者都是「要问人」，人比模型更该被问。
  // 都不在时才轮到 auto：此时没有任何段要求人来定，而至少有一段要求模型看。
  // 放在 inherit 之前：inherit 表示「该段没有表态」，auto 是**有**表态，故优先。
  // 若把 auto 放到 inherit 之后（或漏掉），auto 段会被当成「无表态」→ 落到
  // `all-allow` 分支**静默放行**（fail-open，正是 §9A.4 警告的那一类）。
  else if (anyAuto) { action = 'auto'; code = 'segment-auto' }
  else if (anyInherit) { action = 'inherit'; code = 'all-inherit' }
  else { action = 'allow'; code = 'all-allow' }

  // 决定最终动作的那一段：它的 reason/ruleId/note 随判定一起下发。
  //
  // ⚠️ 未知动作折 ask 时，**没有任何段的 `action` 等于 `'ask'`**（那一段的 `action`
  // 是那个读不懂的原值）—— 于是 `find` 落空、归因退化成 `out[0]`（第一段，可能是
  // 毫不相关的 `echo`）。故这一支要单独找「动作既不在四档值域、也不是 inherit」的那一段。
  // ⚠️ 必须排除 `inherit`：它同样不在 `TIER_STRICTNESS` 里，但它表示「该段没表态」，
  // 不是「读不懂的动作」。不排除时 `echo hi; git status` 会选中 `echo hi` 那一段
  // （实测 matched=null），归因仍然错位。
  const decisive = (action === 'ask' && code === 'segment-unknown-action')
    ? (out.find((s) => s.action !== 'inherit' && !Object.prototype.hasOwnProperty.call(TIER_STRICTNESS, s.action)) || out[0])
    : (out.find((s) => s.action === action) || out[0])
  // ── 归因段：`matched` / `reason` / `note` 必须指向**真正产生最终动作**的那一段 ──────────
  // 非 auto 动作：产生该动作的段就是 `decisive`（`out.find` 的第一个同动作段），本来正确。
  // auto 不同 —— 整条的动作由**回落值**落地（模型失败时执行 `autoFallback`），而回落值已按
  // 上面的从严合并取了全段最严，真正决定结局的是**回落值等于合并结果的那一段**，不一定是
  // 第一个 auto 段。仍取 `decisive` 的后果（实测：`git push` 命中 auto 例外，`wide` 档
  // auto/回落 deny 的 `rm -rf /` 在后）：
  //     action=auto + autoFallback=deny ⇒ 整条被拒绝，
  //     但 matched/reason 指向**回落 ask、已被放行**的 `git push` 段（reason=null），
  //     真正拒绝的那一段的理由（`rm -rf /` 是删根）一个字都没传达。
  // 宿主拿 `matched` 生成「（例外 e-git）」文案（index.js 的 exReason / ruleId），于是 AI
  // 收到「被 e-git 拒绝」，会去改一条与该次拒绝无关的例外。段里的 `autoFallback` 在 push 时
  // 已归一（`action === 'auto' ? (autoFallback || 'ask') : null`），故这里直接比字符串。
  // 找不到匹配段时退回 `decisive`（不让归因变成 null、理由凭空丢失）。
  const attributed = action === 'auto'
    ? (out.find((s) => s.action === 'auto' && s.autoFallback === (mergedAutoFallback || 'ask')) || decisive)
    : decisive
  return {
    action,
    code,
    segments: out,
    matched: attributed ? attributed.ruleId : null,
    reason: attributed ? attributed.reason : null,
    note: attributed ? attributed.note : null,
    // auto 的回落值：只有动作是 auto 时才有意义（宿主的 commandDecision 据此下发，
    // 其它动作时宿主的 `a.action === 'auto' ? … : undefined` 一律不建键）。
    // 值来自**全部 auto 段**的从严合并（见上），不是某一段的值；整条是 auto 却一个 auto 段
    // 都没有时（理论上不可达：`anyAuto` 由段置位）按缺省 ask —— 方向安全，不留 null。
    autoFallback: action === 'auto' ? (mergedAutoFallback || 'ask') : null,
  }
}

/** 段级 code → 双语短标签（弹窗与决策日志共用，避免两处各写一份文案）。 */
export function codeLabel(code) {
  if (code === 'destructive') return bi('破坏性命令', 'Destructive command')
  if (code === 'unparsable') return bi('无法解析', 'Cannot be parsed')
  if (code === 'write-outside') return bi('重定向到工作区外', 'Redirects outside workspace')
  return null
}
