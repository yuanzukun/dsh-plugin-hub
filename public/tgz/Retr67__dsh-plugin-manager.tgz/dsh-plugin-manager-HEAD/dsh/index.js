// DeepSeek Harness (dsh) plugin manager — host half.
//
// Provides a small HTTP API for the browser half (dsh/client.js) to:
//   - GET  /plugin-manager/list     -> enumerate loader entries (id, name,
//                                      enabled/disabled, managed/core)
//   - POST /plugin-manager/toggle   -> { id, enabled }  hot-toggle one plugin
//   - POST /plugin-manager/reset    -> re-enable everything we had persisted
//
// How toggling works (mirrors dsh-market's theme toggling):
//   - Bundle layers are in-memory; we flip `disabled` on the live loader entry
//     via `entry.update({ disabled })` (no file writes, no restart).
//   - Groups (`@deepseek-ai/cordis-plugin-group`) cannot be disabled directly,
//     so we toggle their child entries instead.
//   - The set of persisted-disabled ids lives in
//     <profile>/.plugin-manager/state.json and is replayed at boot + kept
//     off through a self-healing `internal/plugin` guard (same approach as
//     dsh-market's disabled themes).
//
// Host-side fingerprints: `name`, `inject`, `apply(ctx, config)` — a plain
// Cordis plugin, dependency-free (node builtins only).

import {
  existsSync,
  mkdirSync,
  readFileSync,
  readdirSync,
  writeFileSync,
} from 'node:fs'
import { homedir } from 'node:os'
import { join } from 'node:path'

export const name = 'dsh-plugin-manager'
export const inject = []

/** The in-box bundles that make up the harness itself (never user plugins). */
const INBOX_BUNDLES = new Set([
  '@deepseek-ai/dsh-base',
  '@deepseek-ai/dsh-web-app',
  '@deepseek-ai/dsh-headless',
])

const SELF_ID = 'plugin-manager'
const SEP = ':'

// ---------------------------------------------------------------------------
// profile / state helpers
// ---------------------------------------------------------------------------

function argvProfile() {
  const argv = process.argv
  const flag = argv.indexOf('--profile')
  if (flag !== -1 && flag + 1 < argv.length && !argv[flag + 1].startsWith('-'))
    return argv[flag + 1]
  return undefined
}

function resolveProfileDir(profile) {
  const home = process.env.DSH_HOME || join(homedir(), '.dsh')
  return join(home, 'profiles', profile)
}

function stateFileOf(dir) {
  return join(dir, '.plugin-manager', 'state.json')
}

function readPersistedIds(dir) {
  try {
    const parsed = JSON.parse(readFileSync(stateFileOf(dir), 'utf8'))
    if (Array.isArray(parsed?.disabled)) return new Set(parsed.disabled)
  } catch {}
  return new Set()
}

function writePersistedIds(dir, ids) {
  mkdirSync(join(dir, '.plugin-manager'), { recursive: true })
  writeFileSync(
    stateFileOf(dir),
    JSON.stringify({ disabled: [...ids].sort() }, null, 2) + '\n',
  )
}

/** Read a file, returning '' on any failure (missing / unreadable). */
function readFileSafe(file) {
  try {
    return readFileSync(file, 'utf8')
  } catch {
    return ''
  }
}

/**
 * Collect the entry ids a patch file inserts. Only simple `- id:` rows (the
 * shape dsh's own bundle layers use) are recognized — enough to tell which
 * loader entries belong to a user package. Mirrors dsh-market's parser.
 */
function collectInsertIds(patchText) {
  const ids = new Set()
  let insideInsert = false
  for (const raw of patchText.split('\n')) {
    const line = raw.replace(/#.*$/, '').trimEnd()
    const trimmed = line.trim()
    if (trimmed === '') continue
    if (/^-\s*insert:\s*$/.test(trimmed)) {
      insideInsert = true
      continue
    }
    if (!insideInsert) continue
    if (line.startsWith(' ') || line.startsWith('\t')) {
      const idMatch = /^\s+-\s+id:\s*(\S+)\s*$/.exec(line)
      if (idMatch) ids.add(idMatch[1])
      continue
    }
    // A non-indented, non-insert line ends the insert block.
    insideInsert = false
  }
  return ids
}

/**
 * Figure out which loader entries are "user plugins" worth managing:
 *   - ids inserted by profile `cordis.patch.yml` (e.g. user MCP bridges)
 *   - ids inserted by each dependencies' own bundle patch
 *   - any entry whose package name appears in `package.json` dependencies
 */
function computeUserOwned(dir) {
  const ids = new Set()
  const names = new Set()
  collectInsertIds(readFileSafe(join(dir, 'cordis.patch.yml'))).forEach((id) => ids.add(id))

  let manifest
  try {
    manifest = JSON.parse(readFileSync(join(dir, 'package.json'), 'utf8'))
  } catch {
    return { ids, names }
  }
  const deps = manifest.dependencies ?? {}
  for (const depName of Object.keys(deps)) {
    if (INBOX_BUNDLES.has(depName)) continue
    names.add(depName)
    const depDir = join(dir, 'node_modules', depName)
    if (!existsSync(join(depDir, 'package.json'))) continue
    let patchRel = 'cordis.patch.yml'
    try {
      const depManifest = JSON.parse(readFileSync(join(depDir, 'package.json'), 'utf8'))
      if (depManifest?.dsh?.bundle?.patch) patchRel = depManifest.dsh.bundle.patch
    } catch {}
    collectInsertIds(readFileSafe(join(depDir, patchRel))).forEach((id) => ids.add(id))
  }
  return { ids, names }
}

// ---------------------------------------------------------------------------
// loader helpers (live, hot)
// ---------------------------------------------------------------------------

function loadEntries(host) {
  return [...host.loader.entries()]
}

/**
 * True when a live loader entry is a top-level entry, not nested inside a
 * group. At runtime every entry id is prefixed by the root include entry
 * (`include:` via EntryTree.sep), so top-level ids look like
 * `include:desk-pet` (one separator), nested group children look like
 * `include:openviking-memory:openviking-memory-runtime` (two separators) and
 * the root include entry itself has no separator.
 */
function isTopLevelEntry(entry) {
  const full = entry.id
  if (typeof full !== 'string') return false
  const first = full.indexOf(SEP)
  if (first === -1) return false // the root include itself
  return full.indexOf(SEP, first + 1) === -1
}

/**
 * Resolve a top-level entry by its RAW options id (e.g. `desk-pet`, not the
 * runtime-prefixed `include:desk-pet`). A group root is returned as-is;
 * callers that want to disable must expand children (groups ignore
 * `disabled`).
 */
function findTopLevelEntry(host, id) {
  return (
    loadEntries(host).find((entry) => entry.options?.id === id) || null
  )
}

/** The entries a toggle actually targets: group roots expand to children. */
function toggleTargets(host, id) {
  const entry = findTopLevelEntry(host, id)
  if (!entry) return []
  if (entry.options.group && entry.subtree) return [...entry.subtree.entries()]
  return [entry]
}

/**
 * Hot-toggle (dis)enabling of a top-level entry id.
 * @returns {Promise<boolean>} true when at least one live entry was updated.
 */
async function setEntryDisabled(host, id, flag) {
  const targets = toggleTargets(host, id)
  if (!targets.length) return false
  let ok = false
  for (const entry of targets) {
    for (let attempt = 0; attempt < 3; attempt++) {
      try {
        await entry.update({ disabled: flag ? true : null }, false, true)
        ok = true
      } catch {
        break
      }
      const live = entry.fiber !== undefined
      if (live !== flag) break
      await new Promise((resolve) => setTimeout(resolve, 200))
    }
  }
  return ok
}

/** Current on/off state for one top-level entry (group => any child live). */
function entryEnabled(entry) {
  if (entry.options.group && entry.subtree) {
    return [...entry.subtree.entries()].some((child) => child.fiber !== undefined)
  }
  return entry.fiber !== undefined
}

/** Build the API-facing plugin list. */
function listPlugins(host, dir, persistedIds) {
  const owned = computeUserOwned(dir)
  const rows = []
  for (const entry of loadEntries(host)) {
    const rawId = entry.options?.id
    if (!rawId || !isTopLevelEntry(entry)) continue
    const enabled = entryEnabled(entry)
    const managed =
      owned.ids.has(rawId) || owned.names.has(entry.options?.name)
    const core =
      !managed &&
      entry.options?.name !== undefined &&
      entry.options?.name !== SELF_ID
    const protectedEntry = !managed || rawId === SELF_ID
    rows.push({
      id: rawId,
      name: entry.options?.name ?? rawId,
      group: Boolean(entry.options?.group),
      enabled,
      disabled: !enabled,
      managed,
      core,
      protected: protectedEntry,
      persisted: persistedIds.has(rawId),
    })
  }
  // User plugins first, then the rest; within a group alphabetical by id.
  rows.sort((a, b) => {
    if (a.managed !== b.managed) return a.managed ? -1 : 1
    return a.id.localeCompare(b.id)
  })
  return rows
}

// ---------------------------------------------------------------------------
// HTTP routes
// ---------------------------------------------------------------------------

function sameOrigin(request) {
  const origin = request.headers.origin
  const host = request.headers.host
  if (origin === undefined || host === undefined) return false
  try {
    return new URL(origin).host === host
  } catch {
    return false
  }
}

async function readJsonBody(request) {
  const chunks = []
  let size = 0
  for await (const chunk of request) {
    const buffer = Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk)
    size += buffer.length
    if (size > 4096) throw new Error('request body too large')
    chunks.push(buffer)
  }
  return JSON.parse(Buffer.concat(chunks).toString('utf8'))
}

function sendJson(response, status, payload) {
  response.writeHead(status, {
    'cache-control': 'no-store',
    'content-type': 'application/json; charset=utf-8',
  })
  response.end(JSON.stringify(payload))
}

/** Register routes + boot-replay/self-heal; returns a disposer. */
function mount(host, dir) {
  const persisted = readPersistedIds(dir)
  // Ids currently being toggled by an explicit user action. The self-healing
  // guard below must not fight an explicit re-enable: re-enabling an entry
  // re-inits its fiber, which emits `internal/plugin` while the id may still
  // be present in `persisted` — without this guard the guard would re-disable
  // the very plugin the user just turned on (an off-by-one where a second
  // click only clears the badge but not re-enable).
  const inFlight = new Set()
  const disposers = []

  // Replay persisted disables at boot. Entries may not exist yet, so the
  // self-healing guard below finishes the job when they come up.
  for (const id of persisted) void setEntryDisabled(host, id, true)

  // Self-heal: re-assert every persisted disable whenever any plugin fiber
  // comes up (a config reload or a racing init can otherwise bring a
  // persisted-disabled plugin back). setEntryDisabled is idempotent and
  // expands groups to their children, so re-asserting the full set is safe.
  const onPlugin = () => {
    for (const id of persisted) {
      if (inFlight.has(id)) continue
      void setEntryDisabled(host, id, true)
    }
  }
  if (typeof host.on === 'function') host.on('internal/plugin', onPlugin)

  disposers.push(
    host.webServer.register({
      kind: 'exact',
      path: '/plugin-manager/list',
      handler: (request, response) => {
        // GET list is read-only and served on the loopback-bound web server,
        // so it needs no Origin header. (A same-origin GET fetch sends no
        // Origin at all; requiring one would 403 the panel itself — that was
        // the original "untrusted origin" bug.)
        if (request.method !== 'GET') {
          response.writeHead(405, { allow: 'GET' })
          response.end()
          return
        }
        try {
          sendJson(response, 200, {
            profile: dir,
            self: SELF_ID,
            plugins: listPlugins(host, dir, persisted),
          })
        } catch (error) {
          sendJson(response, 500, {
            error: error instanceof Error ? error.message : String(error),
          })
        }
      },
    }),
  )

  disposers.push(
    host.webServer.register({
      kind: 'exact',
      path: '/plugin-manager/toggle',
      handler: async (request, response) => {
        if (request.method !== 'POST') {
          response.writeHead(405, { allow: 'POST' })
          response.end()
          return
        }
        if (!sameOrigin(request)) {
          sendJson(response, 403, { error: 'untrusted origin' })
          return
        }
        let body
        try {
          body = await readJsonBody(request)
        } catch (error) {
          sendJson(response, 400, { error: 'bad json body' })
          return
        }
        const id = typeof body.id === 'string' ? body.id : ''
        const enabled = Boolean(body.enabled)
        const target = findTopLevelEntry(host, id)
        if (!id || !target || !isTopLevelEntry(target)) {
          sendJson(response, 404, { error: 'plugin entry not found' })
          return
        }
        if (id !== SELF_ID && !ownedCheck(host, dir, id)) {
          sendJson(response, 404, {
            error: 'plugin is not manageable (core component)',
          })
          return
        }
        // Never disable the manager itself — you'd lose the panel mid-use.
        if (id === SELF_ID) {
          sendJson(response, 200, { ok: true, plugin: { id, enabled: true } })
          return
        }
        try {
          inFlight.add(id)
          const ok = await setEntryDisabled(host, id, !enabled)
          if (!ok) {
            sendJson(response, 502, { error: 'no live loader entry to toggle' })
            return
          }
          if (enabled) persisted.delete(id)
          else persisted.add(id)
          writePersistedIds(dir, persisted)
          sendJson(response, 200, { ok: true, flipped: !enabled, plugin: { id, enabled } })
        } catch (error) {
          sendJson(response, 500, {
            error: error instanceof Error ? error.message : String(error),
          })
        } finally {
          inFlight.delete(id)
        }
      },
    }),
  )

  disposers.push(
    host.webServer.register({
      kind: 'exact',
      path: '/plugin-manager/reset',
      handler: async (request, response) => {
        if (request.method !== 'POST') {
          response.writeHead(405, { allow: 'POST' })
          response.end()
          return
        }
        if (!sameOrigin(request)) {
          sendJson(response, 403, { error: 'untrusted origin' })
          return
        }
        try {
          const ids = [...persisted]
          for (const id of ids) inFlight.add(id)
          for (const id of ids) await setEntryDisabled(host, id, false)
          persisted.clear()
          writePersistedIds(dir, persisted)
          sendJson(response, 200, { ok: true, cleared: true })
        } catch (error) {
          sendJson(response, 500, {
            error: error instanceof Error ? error.message : String(error),
          })
        } finally {
          inFlight.clear()
        }
      },
    }),
  )

  return () => {
    if (typeof host.off === 'function') host.off('internal/plugin', onPlugin)
    for (const dispose of disposers) {
      if (typeof dispose === 'function') dispose()
      else if (typeof dispose?.then === 'function') void dispose.then((d) => d?.())
    }
  }
}

function ownedCheck(host, dir, id) {
  const owned = computeUserOwned(dir)
  const entry = findTopLevelEntry(host, id)
  return (
    owned.ids.has(id) ||
    (entry ? owned.names.has(entry.options?.name) : false)
  )
}

// ---------------------------------------------------------------------------
// entry
// ---------------------------------------------------------------------------

export function apply(ctx, config = {}) {
  const profile = config?.profile ?? argvProfile() ?? 'web'
  const dir = resolveProfileDir(profile)

  ctx.inject(['webServer', 'loader'], (hostContext) => {
    hostContext.effect(
      () => mount(hostContext, dir),
      'dsh-plugin-manager: http routes',
    )
  })
}
