// DeepSeek Harness (dsh) plugin manager — browser half.
//
// Registers a "插件管理" tab inside the existing web Settings → 插件
// (the `settings.plugins.tab` slot). The tab lists the profile's plugins with
// on/off switches and talks to the host half through:
//   GET  /plugin-manager/list
//   POST /plugin-manager/toggle
//   POST /plugin-manager/reset
//
// Written in the lazy-CJS bundle protocol (window.__ModuleLoader__.load with a
// factory returning cordis-plugin exports). Requires only the platform seed
// word "react" — no build step, no imports from dsh client packages.

window.__ModuleLoader__.load({
  id: 'dsh-plugin-manager',
  factory: function (require) {
    var module = { exports: {} }
    var exports = module.exports

    var React = require('react')
    var useState = React.useState
    var useEffect = React.useEffect
    var useCallback = React.useCallback

    // ---- display helpers -------------------------------------------------

    var LABELS = {
      'desk-pet': '桌面宠物',
      'better-sidebar': '侧边栏增强',
      'dsh-at-file': '@文件工具',
      'message-edit': '消息编辑',
      'chameleon-session-delete': '会话删除',
      'usage-stats': '用量统计',
      'dsh-market': '插件市场',
      'modlens': '模型供应商',
      'openviking-memory': '记忆插件',
      'mcp-godot': 'Godot MCP',
      'mcp-blender': 'Blender MCP',
      'plugin-manager': '插件管理器（本插件）',
    }

    function labelFor(p) {
      return LABELS[p.id] || p.name || p.id
    }

    function subtextFor(p) {
      var parts = []
      if (p.name && p.name !== p.id) parts.push(p.name)
      if (p.group) parts.push('分组')
      if (p.persisted) parts.push('保持关闭')
      return parts.join(' · ')
    }

    // A scoped <style> so the tab carries its own toggle styling without
    // leaking global rules. Reuses the harness theme variables where possible.
    var CSS = [
      '.dpm-scope{font:13px/1.6 system-ui,-apple-system,"Segoe UI","Microsoft YaHei",sans-serif;color:var(--dsw-alias-label-primary,#e6e6e6);}',
      '.dpm-scope h3{margin:0 0 4px;font-size:15px;font-weight:600;}',
      '.dpm-scope .dpm-hint{color:var(--dsw-alias-label-tertiary,#9aa0aa);margin:0 0 12px;font-size:12px;}',
      '.dpm-scope .dpm-err{color:var(--dsw-alias-state-error-primary,#f16a6a);white-space:pre-wrap;margin:8px 0;font-size:12px;}',
      '.dpm-scope .dpm-row{display:flex;align-items:center;gap:10px;padding:9px 12px;background:var(--dsw-alias-bg-layer-2,#f3f4f6);border:1px solid var(--dsw-alias-border-l1,#e5e7eb);border-radius:10px;margin-bottom:6px;}',
      '.dpm-scope .dpm-row[data-core="true"]{opacity:.55;}',
      '.dpm-scope .dpm-meta{flex:1;min-width:0;}',
      '.dpm-scope .dpm-name{font-weight:600;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}',
      '.dpm-scope .dpm-sub{color:var(--dsw-alias-label-tertiary,#9aa0aa);font-size:11px;margin-top:1px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}',
      '.dpm-scope .dpm-switch{position:relative;width:40px;height:22px;flex:none;cursor:pointer;background:rgba(127,127,127,.35);border:1px solid rgba(255,255,255,.08);border-radius:999px;transition:background .16s;font-size:0;padding:0;}',
      '.dpm-scope .dpm-switch[data-on="true"]{background:rgba(70,150,255,.65);}',
      '.dpm-scope .dpm-switch::after{content:"";position:absolute;top:2px;left:2px;width:16px;height:16px;border-radius:50%;background:#fff;transition:transform .16s;}',
      '.dpm-scope .dpm-switch[data-on="true"]::after{transform:translateX(18px);}',
      '.dpm-scope .dpm-switch[data-locked="true"]{opacity:.35;cursor:not-allowed;}',
      '.dpm-scope .dpm-switch[data-busy="true"]{opacity:.6;cursor:wait;}',
      '.dpm-scope .dpm-group{color:var(--dsw-alias-label-secondary,#8b93a1);margin:14px 2px 6px;font-size:12px;font-weight:600;}',
      '.dpm-scope .dpm-sep{border-top:1px dashed var(--dsw-alias-border-l2,#e5e7eb);margin:14px 0 6px;}',
      '.dpm-scope .dpm-btn{appearance:none;font:inherit;cursor:pointer;color:var(--dsw-alias-label-primary,#e6e6e6);border:1px solid var(--dsw-alias-border-l1,#e5e7eb);background:var(--dsw-alias-bg-layer-2,#f3f4f6);border-radius:8px;padding:6px 14px;}',
      '.dpm-scope .dpm-btn:hover{background:var(--dsw-alias-bg-layer-1,#fff);}',
      '.dpm-scope .dpm-btn:disabled{opacity:.4;cursor:default;}',
      '.dpm-scope .dpm-bar{display:flex;gap:8px;margin:14px 0 0;align-items:center;}',
      '.dpm-scope .dpm-empty{color:var(--dsw-alias-label-secondary,#8b93a1);padding:18px 4px;font-size:13px;}',
      '.dpm-scope .dpm-mode{display:flex;align-items:center;gap:8px;margin:2px 0 12px;padding:8px 12px;background:var(--dsw-alias-bg-layer-2,#f3f4f6);border:1px solid var(--dsw-alias-border-l1,#e5e7eb);border-radius:10px;font-size:12px;}',
      '.dpm-scope .dpm-mode-label{color:var(--dsw-alias-label-secondary,#8b93a1);}',
      '.dpm-scope .dpm-mode-hint{color:var(--dsw-alias-label-primary,#e6e6e6);font-weight:600;}',
      '.dpm-scope .dpm-note{color:var(--dsw-alias-state-success-primary,#2f9e6e);margin:8px 0;font-size:12px;}',
    ].join('\n')

    function PluginManagerSection() {
      var [plugins, setPlugins] = useState(null)
      var [error, setError] = useState('')
      var [note, setNote] = useState('')
      var [working, setWorking] = useState(null)
      var [autoReload, setAutoReload] = useState(function () {
        var v = '1'
        try {
          var saved = window.localStorage.getItem('dsh-plugin-manager.autoreload')
          if (saved !== null) v = saved
        } catch (_) {}
        return v === '1'
      })

      function setRefreshMode(stepToAuto) {
        setAutoReload(stepToAuto)
        try {
          window.localStorage.setItem(
            'dsh-plugin-manager.autoreload',
            stepToAuto ? '1' : '0',
          )
        } catch (_) {}
        setNote(stepToAuto ? '已切换到自动刷新模式' : '已切换到手动刷新模式（开关后请手动刷新页面）')
      }

      var load = useCallback(function () {
        setError('')
        fetch('/plugin-manager/list', { headers: { Accept: 'application/json' } })
          .then(function (res) { return res.json() })
          .then(function (data) {
            if (!data || data.error) throw new Error((data && data.error) || 'unknown error')
            setPlugins(data.plugins || [])
          })
          .catch(function (err) { setError('加载失败：' + err.message) })
      }, [])

      useEffect(function () { load() }, [load])

      // The toggle is applied on the host loader immediately, but a plugin's
      // already-rendered browser half (e.g. a pet, a sidebar tweak) only clears
      // or restores on a page reload. Reload once after a successful switch so
      // the UI genuinely reflects the new state immediately.
      function reloadSoon(message) {
        setError('')
        setPlugins(null)
        // Show a transient full-screen overlay, then reload the page so the
        // plugin's browser half fully reflects the new (de)activated state.
        var fade = document.createElement('div')
        fade.style.cssText =
          'position:fixed;inset:0;z-index:2147483647;display:flex;align-items:center;justify-content:center;' +
          'background:rgba(8,10,14,.6);color:#fff;font:14px/1.6 system-ui,"Microsoft YaHei",sans-serif;' +
          'letter-spacing:.02em;'
        fade.textContent = message
        try { document.body.appendChild(fade) } catch (_) {}
        setTimeout(function () { window.location.reload() }, 700)
      }

      function toggle(p) {
        if (working) return
        var target = !p.enabled
        setWorking(p.id)
        setError('')
        fetch('/plugin-manager/toggle', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ id: p.id, enabled: target }),
        })
          .then(function (res) { return res.json() })
          .then(function (data) {
            if (!data || data.error) throw new Error((data && data.error) || 'unknown error')
            if (autoReload) {
              reloadSoon('已生效，正在刷新页面…')
            } else {
              setNote('已切换，请手动刷新页面（或点「刷新」）使界面完全生效')
              return load()
            }
          })
          .catch(function (err) { setError('操作失败：' + err.message) })
          .finally(function () { setWorking(null) })
      }

      function resetAll() {
        if (working) return
        setWorking('__reset__')
        setError('')
        fetch('/plugin-manager/reset', { method: 'POST' })
          .then(function (res) { return res.json() })
          .then(function (data) {
            if (!data || data.error) throw new Error((data && data.error) || 'unknown error')
            if (autoReload) {
              reloadSoon('已全部恢复开启，正在刷新页面…')
            } else {
              setNote('已全部恢复开启，请手动刷新页面（或点「刷新」）')
              return load()
            }
          })
          .catch(function (err) { setError('恢复失败：' + err.message) })
          .finally(function () { setWorking(null) })
      }

      var managed = (plugins || []).filter(function (p) { return p.managed })
      var others = (plugins || []).filter(function (p) { return !p.managed })

      function switchFor(p) {
        var locked = Boolean(p.protected || working === p.id)
        return React.createElement('button', {
          className: 'dpm-switch',
          role: 'switch',
          'aria-checked': String(p.enabled),
          'aria-label': (p.enabled ? '关闭' : '打开') + ' ' + labelFor(p),
          'data-on': String(p.enabled),
          'data-locked': String(Boolean(p.protected)),
          'data-busy': String(working === p.id),
          disabled: p.protected ? true : undefined,
          onClick: function () { toggle(p) },
        })
      }

      function rowFor(p) {
        return React.createElement('div', {
          key: p.id,
          className: 'dpm-row',
          'data-core': String(!p.managed),
        }, React.createElement('div', { className: 'dpm-meta' },
          React.createElement('div', { className: 'dpm-name' }, labelFor(p)),
          subtextFor(p) ? React.createElement('div', { className: 'dpm-sub' }, subtextFor(p)) : null,
        ), switchFor(p))
      }

      var body
      if (plugins === null) {
        body = React.createElement('div', { className: 'dpm-empty' }, '加载中…')
      } else if (!managed.length && !others.length) {
        body = React.createElement('div', { className: 'dpm-empty' }, '暂无可管理的插件')
      } else {
        body = [
          React.createElement('div', { key: 'g-user', className: 'dpm-group' }, '用户插件（可开关）'),
          managed.map(rowFor),
          others.length ? [
            React.createElement('div', { key: 'sep', className: 'dpm-sep' }),
            React.createElement('div', { key: 'g-core', className: 'dpm-group' }, '系统组件（只读，避免误关）'),
            others.map(rowFor),
          ] : null,
        ]
      }

      var modeRow = React.createElement('div', { className: 'dpm-mode' },
        React.createElement('span', { className: 'dpm-mode-label' }, '切换后刷新页面'),
        React.createElement('button', {
          className: 'dpm-switch',
          role: 'switch',
          'aria-checked': String(autoReload),
          'aria-label': autoReload ? '自动刷新（切换后自动刷新页面）' : '手动刷新（切换后不自动刷新）',
          'data-on': String(autoReload),
          onClick: function () { setRefreshMode(!autoReload) },
        }),
        React.createElement('span', { className: 'dpm-mode-hint' },
          autoReload ? '自动' : '手动'),
      )

      return React.createElement('div', { className: 'dpm-scope' },
        React.createElement('style', null, CSS),
        React.createElement('h3', null, '插件管理'),
        React.createElement('p', { className: 'dpm-hint' },
          '查看并临时打开/关闭插件：默认自动刷新页面使前端界面完全生效（无需重启 dsh）；可切到手动刷新；关闭状态会跨重启保持。'),
        modeRow,
        note ? React.createElement('div', { className: 'dpm-note' }, note) : null,
        error ? React.createElement('div', { className: 'dpm-err' }, error) : null,
        body,
        React.createElement('div', { className: 'dpm-bar' },
          React.createElement('button', {
            className: 'dpm-btn',
            disabled: working ? true : undefined,
            onClick: function () { resetAll() },
          }, '全部恢复开启'),
          React.createElement('button', {
            className: 'dpm-btn',
            disabled: working ? true : undefined,
            onClick: function () { load() },
          }, '刷新'),
        ),
      )
    }

    var inject = ['slots']

    function apply(ctx) {
      ctx.slots.inject('settings.plugins.tab', function () {
        return ctx.slots.register({
          name: 'settings.plugins.tab',
          id: 'plugin-manager',
          order: 50,
          label: function () { return '插件管理' },
        }, function () { return React.createElement(PluginManagerSection) })
      })
    }

    exports.apply = apply
    exports.inject = inject
    return module.exports
  },
})
