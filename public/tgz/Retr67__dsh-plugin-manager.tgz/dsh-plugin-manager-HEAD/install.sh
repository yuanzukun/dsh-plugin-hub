#!/usr/bin/env sh
# One-command installer for dsh-plugin-manager into a DeepSeek Harness profile.
#
# Uses the standard dsh plugin install command:
#   npx -y @deepseek-ai/dsh plugin --profile <profile> add <repo-url>
#
# Usage:
#   ./install.sh                 # install into profile 'web' from the GitHub repo
#   ./install.sh -p myprofile    # pick a different profile
#   ./install.sh -s "github:Retr67/dsh-plugin-manager"   # custom source spec
#
# After installation, restart dsh web and refresh the browser, then open
# Settings -> Plugins -> Plugin Manager.

set -e

PROFILE="web"
REPO="https://github.com/Retr67/dsh-plugin-manager.git"
SPEC=""

while [ "$#" -gt 0 ]; do
  case "$1" in
    -p|--profile)
      PROFILE="$2"
      shift 2
      ;;
    -s|--spec|--source)
      SPEC="$2"
      shift 2
      ;;
    *)
      echo "unknown argument: $1" >&2
      exit 2
      ;;
  esac
done

if [ -n "$SPEC" ]; then
  SOURCE="$SPEC"
else
  SOURCE="$REPO"
fi

echo "Installing dsh-plugin-manager into profile '$PROFILE' from: $SOURCE"

npx -y @deepseek-ai/dsh plugin --profile "$PROFILE" add "$SOURCE"

echo ""
echo "OK: dsh-plugin-manager installed into profile '$PROFILE'."
echo "Next steps:"
echo "  1. Restart dsh web."
echo "  2. Refresh the browser page."
echo "  3. Open Settings -> Plugins -> Plugin Manager to manage plugins."
