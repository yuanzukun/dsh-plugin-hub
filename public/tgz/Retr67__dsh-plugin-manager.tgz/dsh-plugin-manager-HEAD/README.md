# dsh-plugin-manager

DeepSeek Harness (DSH) 插件管理器：在 WebUI **设置 → 插件 → 插件管理** 里可视化**查看、临时打开、关闭**其他插件。

- **用户插件**（可开关）：你在 `profile/package.json` 里安装的社区插件 + 你自己在 `cordis.patch.yml` 里加的条目（如 MCP 桥梁）。
- **系统组件**（只读）：DSH 自带的 host/web 基础设施，只展示、不提供开关，避免误关导致 Harness 起不来。
- 开关**无需重启 dsh**：走的是 Cordis loader 的 `entry.update({ disabled })`（与官方 dsh-market 主题开关同一条路）。默认在切换后**自动刷新网页**，让带前端界面的插件（桌宠、侧边栏等）也立即完全生效；也可在面板里切到**手动刷新**模式（选择保存在浏览器 localStorage）。
- **跨重启保持**：被关闭的插件 id 会记在 `<profile>/.plugin-manager/state.json`，下次启动时自动回放为关闭，直到你把它打开。
- 「全部恢复开启」按钮一键清空所有保持关闭的插件。

## 环境要求

- [DeepSeek Harness (dsh)](https://github.com/deepseek-ai/deepseek-harness)
- Node.js（含 `npx`）
- Windows / macOS / Linux 均可

## 安装（一行命令）

在任意终端执行（默认安装到 `web` profile）：

```bash
npx -y @deepseek-ai/dsh plugin --profile web add https://github.com/Retr67/dsh-plugin-manager.git
```

> 该命令会：① 安装依赖；② 检测到包声明了 `dsh.bundle`，自动把插件加进 `dsh.profile.bundles`（下次启动自动加载）。

如果你的 `dsh` 已全局可用，也可以直接：

```bash
dsh plugin --profile web add https://github.com/Retr67/dsh-plugin-manager.git
```

### 安装到其他 profile

把 `web` 换成你的 profile 名：

```bash
npx -y @deepseek-ai/dsh plugin --profile myprofile add https://github.com/Retr67/dsh-plugin-manager.git
```

## 使用

1. **重启 dsh**：安装后重启一次 `dsh web`（让插件加载），并**刷新浏览器页面**。
2. 打开 **设置（⚙️ / Settings）→ 插件 → 插件管理**。
3. 你会看到：
   - **用户插件（可开关）**：每个插件一行，右侧有开关，点击即可**打开 / 关闭**。
   - **系统组件（只读）**：只展示，不提供开关，防止误关导致 Harness 起不来。
4. 刷新模式：
   - 默认**自动刷新**：开关后页面自动刷新，带前端界面的插件也会立即完全生效。
   - 可切到**手动刷新**：开关后不自动刷新，点面板里的「刷新」或手动刷新网页后生效（选择会保存在浏览器 localStorage）。

## 卸载

```bash
npx -y @deepseek-ai/dsh plugin --profile web remove dsh-plugin-manager
```

## 目录结构

```
dsh-plugin-manager/
├── package.json        # dsh.bundle + dsh.client 声明
├── cordis.patch.yml    # 挂载 plugin-manager 主机条目
├── dsh/
│   ├── index.js        # 主机端：HTTP API + loader 枚举/开关 + 状态持久化
│   └── client.js       # 浏览器端：注册 设置→插件→插件管理 标签页（React）
├── install.ps1         # Windows 一键安装脚本（内部即标准 npx 命令）
├── install.sh          # POSIX 一键安装脚本（内部即标准 npx 命令）
├── README.md
└── LICENSE             # MIT
```

> install.ps1 / install.sh 只是标准命令的便捷封装，默认安装源是上面的 GitHub 仓库；不以自定义 `file:` 路径作为主安装方式。

## 与官方机制的关系

- 不对 `package.json` 的 `dsh.profile.bundles` 做热增删（那需要重启生效），而是对**运行中的 loader entry** 做热开关——这是 dsh-market 主题切换验证过的做法。
- 状态持久化、启动回放、自愈守卫（`internal/plugin` 事件）同样移植自 dsh-market。
- group 插件（如把某个插件包包裹成 group 的宿主）无法直接置 `disabled`，管理器会自动改为开关其子条目。

## HTTP API（同源校验）

| 方法 | 路径 | 说明 |
|---|---|---|
| GET  | `/plugin-manager/list`  | 返回插件列表与开关状态 |
| POST | `/plugin-manager/toggle` | `{ id, enabled }` 热开关某个插件 |
| POST | `/plugin-manager/reset`  | 恢复所有被保持关闭的插件 |

POST 接口（`toggle`/`reset`）做了 Origin === Host 的同源校验；GET 列表是只读、且只暴露在回环地址绑定的 web server 上，不再要求 Origin 头（同源 GET fetch 默认不携带 Origin，要求它会导致面板报 `untrusted origin`）。

## 安全

- 主机端仅使用 node 内置模块（fs/os/path），无网络调用、无子进程、无 eval。
- 客户端用 React 渲染插件名（自动转义，无 XSS），所有请求都是同源 fetch。
- 管理器自己（`plugin-manager`）不会被关闭；系统组件不会提供开关。

## License

MIT
