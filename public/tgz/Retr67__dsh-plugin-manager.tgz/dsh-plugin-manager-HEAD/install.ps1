<#
.SYNOPSIS
  One-command installer for dsh-plugin-manager into a DeepSeek Harness profile.

.DESCRIPTION
  Runs the standard dsh plugin install command:

    npx -y @deepseek-ai/dsh plugin --profile <profile> add <repo-url>

  Default repo is the public GitHub repository. Default profile is "web".
  You can override both. After installation, restart dsh web and refresh the
  browser, then open Settings -> Plugins -> Plugin Manager.

.EXAMPLE
  .\install.ps1
  .\install.ps1 -Profile myprofile
  .\install.ps1 -Repo "https://github.com/Retr67/dsh-plugin-manager.git"
  .\install.ps1 -Spec "github:Retr67/dsh-plugin-manager"
#>
[CmdletBinding()]
param(
  [string]$Profile = "web",
  [string]$Repo = "https://github.com/Retr67/dsh-plugin-manager.git",
  [string]$Spec = ""
)

$ErrorActionPreference = "Stop"

if ($Spec) {
  $Source = $Spec
} else {
  $Source = $Repo
}

Write-Host "Installing dsh-plugin-manager into profile '$Profile' from: $Source" -ForegroundColor Cyan

npx -y @deepseek-ai/dsh plugin --profile $Profile add $Source

if ($LASTEXITCODE -ne 0) {
  Write-Error "dsh plugin add failed with exit code $LASTEXITCODE"
  exit $LASTEXITCODE
}

Write-Host ""
Write-Host "✔ dsh-plugin-manager installed into profile '$Profile'." -ForegroundColor Green
Write-Host "Next steps:"
Write-Host "  1. Restart dsh web."
Write-Host "  2. Refresh the browser page."
Write-Host "  3. Open Settings -> Plugins -> Plugin Manager to manage plugins."
