#!/usr/bin/env node
// dsh-deepseek-monitor / proxy.mjs
//
// 本地用量监控代理：把 DSH 的 claude-code 子代理（headless Claude Code）
// 发往 DeepSeek Anthropic 兼容端点的请求截获并记账。
//
// 原理：
//   child claude ──ANTHROPIC_BASE_URL=http://127.0.0.1:8899──▶ 本代理
//        ◀──SSE / JSON（原样转发，同时解析 usage）─────────────┘
//   本代理 ──▶ https://api.deepseek.com/anthropic（原样转发）
//
// 环境变量：
//   DS_MONITOR_PORT      监听端口，默认 8899
//   DS_MONITOR_HOST      监听地址，默认 127.0.0.1
//   DS_MONITOR_UPSTREAM  上游 DeepSeek Anthropic 兼容端点，默认 https://api.deepseek.com/anthropic
//   DS_MONITOR_LOG       记账 JSONL 路径，默认 ~/.dsh/deepseek-monitor/usage.jsonl
//
// 运行：node proxy.mjs

import http from "node:http";
import https from "node:https";
import { randomUUID } from "node:crypto";
import { StringDecoder } from "node:string_decoder";
import { pathToFileURL } from "node:url";
import { appendRecord, defaultLogPath } from "./lib/logger.mjs";
import { modelPricing, computeCost } from "./lib/pricing.mjs";

const UPSTREAM = process.env.DS_MONITOR_UPSTREAM ?? "https://api.deepseek.com/anthropic";
const HOST = process.env.DS_MONITOR_HOST ?? "127.0.0.1";
const PORT = Number(process.env.DS_MONITOR_PORT ?? 8899);
const LOG_FILE = defaultLogPath();

/** 转发前缓冲的请求体上限，防止单个超大请求把代理内存吃满。 */
const MAX_BODY_BYTES = 32 * 1024 * 1024;

const STARTED_AT = new Date().toISOString();

// ── SSE 事件解析器：从流式响应中抽取 usage ────────────────────────────────

function createSseExtractor(onEvent) {
  // 用 StringDecoder 承接被 chunk 切断的多字节字符，否则含中文的
  // content_block_delta 行会变成乱码，JSON.parse 失败被静默丢掉。
  const decoder = new StringDecoder("utf8");
  let buffer = "";
  let eventType = null;
  const handleDataLine = (data) => {
    const text = data.trim();
    if (!text || text === "[DONE]") return;
    try {
      onEvent(eventType, JSON.parse(text));
    } catch {
      /* 非 JSON 数据行忽略 */
    }
  };
  const drain = () => {
    let idx;
    while ((idx = buffer.indexOf("\n")) !== -1) {
      const line = buffer.slice(0, idx).replace(/\r$/, "");
      buffer = buffer.slice(idx + 1);
      if (line === "") {
        eventType = null;
        continue;
      }
      if (line.startsWith("event:")) {
        eventType = line.slice(6).trim();
      } else if (line.startsWith("data:")) {
        handleDataLine(line.slice(5));
      }
    }
  };
  return {
    push(chunk) {
      buffer += typeof chunk === "string" ? chunk : decoder.write(chunk);
      drain();
    },
    end() {
      buffer += decoder.end();
      drain();
      if (buffer.trim()) handleDataLine(buffer);
      buffer = "";
    },
  };
}

const USAGE_KEYS = ["input_tokens", "output_tokens", "cache_creation_input_tokens", "cache_read_input_tokens"];

function extractUsageFromSse() {
  const start = {};
  const delta = {};
  let error = null;
  const extractor = createSseExtractor((eventType, ev) => {
    if (eventType === "error" && ev?.error?.message) error = ev.error.message;
    if (eventType === "message_start" && ev?.message?.usage) {
      for (const k of USAGE_KEYS) if (typeof ev.message.usage[k] === "number") start[k] = ev.message.usage[k];
    }
    if (eventType === "message_delta" && ev?.usage) {
      for (const k of USAGE_KEYS) if (typeof ev.usage[k] === "number") delta[k] = ev.usage[k];
    }
  });
  return {
    extractor,
    get usage() {
      return {
        input_tokens: start.input_tokens ?? 0,
        output_tokens: Math.max(delta.output_tokens ?? 0, start.output_tokens ?? 0),
        cache_creation_input_tokens: start.cache_creation_input_tokens ?? 0,
        cache_read_input_tokens: start.cache_read_input_tokens ?? 0,
      };
    },
    get error() {
      return error;
    },
  };
}

// ── 请求转发与记账 ─────────────────────────────────────────────────────────

/** 只取 pathname 判类型：带 query（如 /v1/messages?beta=true）时不能退化成 "other"。 */
function pathOf(rawUrl) {
  const s = rawUrl ?? "/";
  const q = s.indexOf("?");
  return q === -1 ? s : s.slice(0, q);
}

function kindFor(rawUrl) {
  const pathname = pathOf(rawUrl);
  if (pathname === "/v1/messages") return "messages";
  if (pathname === "/v1/messages/count_tokens") return "count_tokens";
  if (pathname === "/v1/models") return "models";
  return "other";
}

function createProxyServer() {
  const transport = new URL(UPSTREAM).protocol === "https:" ? https : http;

  return http.createServer((req, res) => {
    const pathname = pathOf(req.url);
    if (req.method === "GET" && (pathname === "/" || pathname === "/healthz")) {
      res.writeHead(200, { "content-type": "application/json; charset=utf-8" });
      res.end(JSON.stringify({ ok: true, upstream: UPSTREAM, log: LOG_FILE, startedAt: STARTED_AT }));
      return;
    }

    const runId = randomUUID();
    const startedMs = Date.now();
    const kind = kindFor(req.url);
    const streaming = String(req.headers.accept ?? "").includes("text/event-stream");

    // 一个请求只记一笔账：流式 / 非流式 / 上游出错 / 客户端断开这几条路径可能先后触发，
    // 谁先到谁写，既避免重复记录，也避免断开那条路径漏记。
    let recorded = false;
    let streamTrack = null;
    let upstreamRes = null;
    const recordOnce = (fields) => {
      if (recorded) return;
      recorded = true;
      record(fields);
    };

    // 「上游前缀 + 客户端可控的 req.url」未必拼得出合法 URL：当前缀带端口且没有路径时
    // （例如 DS_MONITOR_UPSTREAM=http://127.0.0.1:8899），遇到 absolute-form 请求目标
    // （GET http://host/x）或 `OPTIONS *` 会让端口后接上非数字字符而抛 Invalid URL。
    // 这个回调里抛异常就是未捕获异常 = 代理进程退出，所以必须在此拦下。
    let target;
    try {
      target = new URL(UPSTREAM + req.url);
    } catch {
      recordOnce({ model: null, status: 400, usage: {}, error: "invalid request target", kind, startedMs, runId, streaming });
      res.writeHead(400, { "content-type": "text/plain; charset=utf-8" });
      res.end("proxy: invalid request target");
      return;
    }

    // 收集请求体以读取 model（同时用于转发）
    const chunks = [];
    let bodyBytes = 0;
    let bodyTooLarge = false;
    req.on("data", (c) => {
      if (bodyTooLarge) return;
      bodyBytes += c.length;
      if (bodyBytes > MAX_BODY_BYTES) {
        bodyTooLarge = true;
        chunks.length = 0;
        return;
      }
      chunks.push(c);
    });
    req.on("end", () => {
      if (bodyTooLarge) {
        recordOnce({
          model: null,
          status: 413,
          usage: {},
          error: "request body too large",
          kind,
          startedMs,
          runId,
          streaming,
        });
        res.writeHead(413, { "content-type": "text/plain; charset=utf-8" });
        res.end("proxy: request body too large");
        return;
      }
      const body = Buffer.concat(chunks);
      let model = null;
      if (kind === "messages" || kind === "count_tokens") {
        try {
          model = JSON.parse(body.toString("utf8") || "{}")?.model ?? null;
        } catch {
          /* 非 JSON 请求体，仍照常转发 */
        }
      }

      const upstreamHeaders = {
        ...req.headers,
        host: target.host,
        "accept-encoding": "identity", // 强制原文，便于解析 SSE
      };
      delete upstreamHeaders["transfer-encoding"];
      delete upstreamHeaders["content-length"];
      if (streaming) upstreamHeaders.accept = "text/event-stream";

      const upstreamReq = transport.request(
        target,
        { method: req.method, headers: upstreamHeaders },
        (upRes) => {
          const status = upRes.statusCode ?? 502;
          upstreamRes = upRes;

          if (streaming && kind === "messages") {
            // 流式：边转发边解析 usage
            const track = extractUsageFromSse();
            streamTrack = track;
            res.writeHead(status, {
              "content-type": upRes.headers["content-type"] ?? "text/event-stream",
              "cache-control": upRes.headers["cache-control"] ?? "no-cache",
            });
            upRes.on("data", (c) => {
              res.write(c);
              track.extractor.push(c);
            });
            upRes.on("end", () => {
              track.extractor.end();
              recordOnce({ model, status, usage: track.usage, error: track.error, kind, startedMs, runId, streaming: true });
              res.end();
            });
            upRes.on("error", (e) => {
              recordOnce({ model, status: 502, usage: {}, error: e.message, kind, startedMs, runId, streaming: true });
              res.destroy();
            });
            return;
          }

          // 非流式：缓存响应体，解析 usage 后一次回写
          const outChunks = [];
          upRes.on("data", (c) => outChunks.push(c));
          upRes.on("end", () => {
            const outBody = Buffer.concat(outChunks);
            let usage = {};
            let error = null;
            try {
              const json = JSON.parse(outBody.toString("utf8") || "{}");
              if (json?.usage) usage = json.usage;
              else if (kind === "count_tokens" && typeof json?.input_tokens === "number") usage = { input_tokens: json.input_tokens };
              if (json?.error?.message) error = json.error.message;
            } catch {
              /* 非 JSON（例如纯文本错误页），原样转发 */
            }
            recordOnce({ model, status, usage, error, kind, startedMs, runId, streaming: false });
            const headers = { ...upRes.headers };
            delete headers["transfer-encoding"];
            headers["content-length"] = String(outBody.length);
            res.writeHead(status, headers);
            res.end(outBody);
          });
          upRes.on("error", (e) => {
            recordOnce({ model, status: 502, usage: {}, error: e.message, kind, startedMs, runId, streaming: false });
            if (!res.headersSent) res.writeHead(502, { "content-type": "text/plain; charset=utf-8" });
            res.end(`proxy upstream error: ${e.message}`);
          });
        }
      );

      upstreamReq.on("error", (e) => {
        recordOnce({ model, status: 502, usage: {}, error: e.message, kind, startedMs, runId, streaming });
        if (!res.headersSent) res.writeHead(502, { "content-type": "text/plain; charset=utf-8" });
        res.end(`proxy upstream error: ${e.message}`);
      });

      if (body.length) upstreamReq.write(body);
      upstreamReq.end();

      // 客户端真正断开（而非请求体读完）时才终止上游；正常完成后 writableEnded 为 true。
      // 断开这条路径之后不会再有任何 end/error 回调，必须在这里补记账，
      // 否则这段已消耗的 token 完全不计入（流式断开时用已解析到的部分 usage）。
      res.on("close", () => {
        if (res.writableEnded) return;
        recordOnce({
          model,
          status: 499,
          usage: streamTrack ? streamTrack.usage : {},
          error: "client disconnected",
          kind,
          startedMs,
          runId,
          streaming,
        });
        upstreamReq.destroy();
        if (upstreamRes) upstreamRes.destroy();
      });
    });
  });
}

function record({ model, status, usage, error, kind, startedMs, runId, streaming }) {
  const pricing = modelPricing(model ?? "");
  const cost = computeCost(usage, pricing);
  appendRecord(LOG_FILE, {
    ts: new Date().toISOString(),
    runId,
    kind,
    streaming,
    model: model ?? null,
    status,
    ...cost,
    error: error ?? null,
    durationMs: Date.now() - startedMs,
  });
}

// ── 入口 ───────────────────────────────────────────────────────────────────

function main() {
  const server = createProxyServer();
  server.listen(PORT, HOST, () => {
    const actual = server.address();
    const port = typeof actual === "object" && actual ? actual.port : PORT;
    console.log(`[dsh-deepseek-monitor] listening on http://${HOST}:${port}`);
    console.log(`[dsh-deepseek-monitor] upstream: ${UPSTREAM}`);
    console.log(`[dsh-deepseek-monitor] log: ${LOG_FILE}`);
    console.log(`[dsh-deepseek-monitor] 把它作为子 Claude Code 的 ANTHROPIC_BASE_URL，例如 http://127.0.0.1:${port}`);
  });
  return server;
}

const isDirectRun =
  process.argv[1] !== undefined && import.meta.url === pathToFileURL(process.argv[1]).href;

if (isDirectRun) main();

export { createProxyServer, record, kindFor, UPSTREAM, HOST, PORT, LOG_FILE };
