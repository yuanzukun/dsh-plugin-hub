/**
 * dsh-input-history browser half: terminal-style input recall for the
 * conversation composer. Ctrl+Up fills the newest sent message into the
 * composer and walks older entries; Ctrl+Down walks back toward live and
 * restores the draft that was being edited when recall started. Both keys
 * are captured at the document level (capture phase) so they win over the
 * composer's own key handling, while bare ArrowUp/ArrowDown — and every
 * other chord — pass through untouched, so multi-line cursor movement and
 * the slash menu keep their native behavior (dsh-external/issues#153).
 *
 * History is derived from the live chat view snapshot (user messages in
 * the current window): no server round-trip, no duplicated state, and it
 * survives page refresh. Export discipline: packages/client/AGENTS.md — only
 * the cordis apply surface leaves this package.
 */
import type { Context as ClientContext } from '@deepseek-ai/cordis'
// Type-only: ISessions plus the ctx.sessions Context merge.
import type { ISessions } from '@deepseek-ai/dsh-api-session-controller/client'
// Type-only: IConversation/SessionInput/ConversationNode plus the
// ctx.conversation / ctx.uiConversation Context merges.
import type {
  ConversationNode, IConversation, SessionInput,
} from '@deepseek-ai/dsh-client-ui-conversation/client'
// Type-only: merges the 'chat' key into ConversationViewSnapshotMap so
// views.get('chat') resolves to ChatSnapshot.
import type {} from '@deepseek-ai/dsh-client-ui-chat/client'
import { down, extractHistory, IDLE, resync, up, type HistoryBrowse } from './history.ts'
import { applyWithCompat } from './compat.ts'
import { startUpdateChip } from './update-chip.ts'

/** Stable Cordis plugin name (matches the manifest id). */
export const name = 'dsh-input-history'

/**
 * Required services: the sessions face (current session + scope reads), the
 * target-neutral Conversation assembly (chat view nodes), and the
 * scope-addressed conversation face (input machine writes). All are
 * root-level services provided by the stock web app.
 */
export const inject = ['sessions', 'uiSession', 'uiConversation', 'conversation']

/**
 * Whether the keydown/input target is inside the conversation composer
 * surface. The composer is a contenteditable div hosted inside the
 * `data-input-scroll` frame, so the check stays robust against CSS-module
 * class hashing and contenteditable host changes.
 * @param target - the event target.
 * @returns true when the target is inside the composer.
 */
function isComposerTarget(target: EventTarget | null): boolean {
  if (!(target instanceof HTMLElement)) return false
  return target.closest('[data-input-scroll]') !== null
}

/** The per-press session resolution: current session, its input facade and chat nodes. */
interface ResolvedSession {
  readonly input: SessionInput
  readonly nodes: readonly ConversationNode[]
}

const EMPTY_NODES: readonly ConversationNode[] = []

/**
 * Browser plugin body: capture Ctrl+Up / Ctrl+Down on the composer and drive
 * the input machine's draft through the pure history state machine. A live
 * composer edit or a session switch drops the browse state (the input event
 * re-sync covers both, plus sends clearing the draft).
 * @param ctx - client root context.
 */
function applyBody(ctx: ClientContext): void {
  let browse: HistoryBrowse = IDLE
  let lastSessionId: string | undefined

  const sessions: ISessions = ctx.sessions

  /**
   * dsh 0.1.6-alpha.2: the main session moved to the uiSession service
   * ({ key: sessionId, ctx: session scope } per the multi-instance
   * refactor); alpha.1 exposed it as sessions.list 'current'. Both paths
   * resolve to { sessionId, scope }.
   */
  const currentSession = (): { sessionId: string; scope: ClientContext } | null => {
    if (ctx.uiSession !== undefined) {
      const snap = (ctx.uiSession as { adapter: { current: { getSnapshot(): { key?: string; ctx?: ClientContext } | undefined } } }).adapter.current.getSnapshot()
      if (snap !== undefined && snap.key !== undefined && snap.ctx !== undefined) return { sessionId: snap.key, scope: snap.ctx }
      return null
    }
    const id = sessions.list.getSnapshot().current
    if (id === undefined) return null
    const scope = sessions.scope(id)
    return scope === undefined ? null : { sessionId: id, scope }
  }

  const resolve = (): ResolvedSession | null => {
    const current = currentSession()
    if (current === null) return null
    const { sessionId: id, scope } = current
    if (id !== lastSessionId) {
      // Session switch: recall must start fresh on the new session.
      browse = IDLE
      lastSessionId = id
    }
    const conversation = scope.get('conversation') as IConversation | undefined
    if (conversation === undefined) return null
    // dsh 0.1.6-alpha.2 hardening: every projection hop is optional — the
    // multi-instance refactor moved the composer host and reshaped view
    // registration, so a missing hop degrades to "no history" (with one
    // console line) instead of a thrown error inside the capture listener.
    let chat: { readonly legacy: { readonly nodes: readonly ConversationNode[] } } | undefined
    try {
      chat = ctx.uiConversation.binding(id as unknown as Parameters<typeof ctx.uiConversation.binding>[0]).snapshot.getSnapshot().views.get('chat')
    } catch (cause) {
      console.warn('[dsh-input-history] chat view unavailable:', cause)
      return null
    }
    const nodes = chat === undefined ? EMPTY_NODES : chat.legacy.nodes
    const input = conversation.input.for?.(scope)
    if (input === undefined) { console.warn('[dsh-input-history] conversation.input.for unavailable'); return null }
    return { input, nodes }
  }

  const onKeyDown = (e: KeyboardEvent): void => {
    // Only the plain Ctrl+ArrowUp/ArrowDown chord; every other key (bare
    // arrows, Ctrl+Z/Y undo/redo, IME composition, slash-menu chords) is
    // left to the composer.
    if (!e.ctrlKey || e.altKey || e.metaKey) return
    if (e.key !== 'ArrowUp' && e.key !== 'ArrowDown') return
    if (e.isComposing) return
    if (!isComposerTarget(e.target)) return
    const resolved = resolve()
    if (resolved === null) return
    const history = extractHistory(resolved.nodes)
    const draft = resolved.input.state.getSnapshot().draft
    const step = e.key === 'ArrowUp'
      ? up(history, draft, browse)
      : down(history, browse)
    const text = step.text
    if (text === null) return
    e.preventDefault()
    e.stopPropagation()
    browse = step.browse
    // The Lexical-backed facade replaces the whole draft and places the
    // caret at the end itself (terminal recall semantics).
    resolved.input.setDraft(text)
  }

  // Any composer change not caused by our own recall drops the browse
  // state: typing, pasting, a send clearing the draft, or a recalled text
  // the user is now editing. The draft is read from the input machine's
  // published state (the clipboard projection), not the DOM: the
  // contenteditable host carries chips that a text read cannot reconstruct.
  const onInput = (e: Event): void => {
    if (!isComposerTarget(e.target)) return
    const resolved = resolve()
    if (resolved === null) return
    browse = resync(
      extractHistory(resolved.nodes),
      resolved.input.state.getSnapshot().draft,
      browse,
    )
  }

  ctx.effect(() => {
    window.addEventListener('keydown', onKeyDown, true)
    window.addEventListener('input', onInput, true)
    return () => {
      window.removeEventListener('keydown', onKeyDown, true)
      window.removeEventListener('input', onInput, true)
    }
  }, 'dsh-input-history: composer keyboard capture')
}

/**
 * Client plugin entry: run {@link applyBody} behind a graceful-compatibility
 * guard — when the running DSH lacks the client APIs this plugin needs, a
 * remediation banner renders instead of a thrown activation error.
 * @param ctx - client root context.
 */
export function apply(ctx: ClientContext): void {
  startUpdateChip()
  applyWithCompat(
    '@dsh-external/dsh-input-history',
    '当前 DSH 客户端 API 与插件不匹配',
    [
      '将 DSH 升级到已适配的版本（dsh-v0.1.2-alpha.1，源码构建安装）。',
      '或将插件更新到适配当前 DSH 的版本（仓库最新 tag）。',
      '如仍显示，请在插件目录执行 pnpm run build 后刷新页面。',
    ],
    [
      ['sessions.list', ctx?.sessions?.list],
      ['sessions.scope', ctx?.sessions?.scope],
      ['sessions.sessionOf', ctx?.sessions?.sessionOf],
      ['uiConversation.binding', ctx?.uiConversation?.binding],
    ],
    () => { applyBody(ctx) },
  )
}
