import { existsSync, mkdirSync, symlinkSync, realpathSync, readFileSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { createRequire } from 'node:module';

const root = resolve(process.argv[2] || '');
if (!process.argv[2] || !existsSync(join(root, 'tools/dshx/src/client-build.js'))) throw new Error('Pass a prepared Harness checkout.');
const local = resolve('node_modules');
mkdirSync(local, { recursive: true });
const shared = {
  '@deepseek-ai/cordis': 'vendor/cordis',
  '@deepseek-ai/dsh-client-runtime': 'packages/client/runtime',
  '@deepseek-ai/dsh-client-ui-conversation': 'packages/client/ui-conversation',
  '@deepseek-ai/dsh-client-ui-primitives': 'packages/client/ui-primitives',
  '@deepseek-ai/dsh-client-ui-slots': 'packages/client/ui-slots',
  '@deepseek-ai/dsh-attachment': 'packages/attachment/attachment',
};
function link(name, target) {
  const destination = join(local, name);
  mkdirSync(dirname(destination), { recursive: true });
  if (existsSync(destination)) {
    if (realpathSync(destination) !== realpathSync(target)) throw new Error(`Dependency mismatch: ${name}`);
    return;
  }
  symlinkSync(target, destination);
}
for (const [name, path] of Object.entries(shared)) link(name, join(root, path));
const require = createRequire(join(root, 'packages/client/ui-conversation/package.json'));
const rootRequire = createRequire(join(root, 'package.json'));
for (const name of ['react', '@types/react']) link(name, dirname(require.resolve(`${name}/package.json`)));
for (const name of ['@types/node', 'typescript', 'tsdown', 'tsx']) link(name, dirname(rootRequire.resolve(`${name}/package.json`)));
for (const name of ['@types/mdast', 'clsx', 'katex', 'mdast-util-from-markdown', 'mdast-util-gfm', 'mdast-util-math', 'micromark-core-commonmark', 'micromark-extension-gfm', 'micromark-extension-math', 'micromark-factory-space', 'micromark-util-character', 'micromark-util-classify-character', 'micromark-util-sanitize-uri', 'micromark-util-symbol', 'micromark-util-types']) {
  link(name, join(root, 'packages/client/ui-primitives/node_modules', name));
}
mkdirSync(join(local, '.bin'), { recursive: true });
for (const name of ['typescript', 'tsdown']) {
  const pkg = JSON.parse(readFileSync(join(local, name, 'package.json'), 'utf8'));
  const bins = typeof pkg.bin === 'string' ? { [name]: pkg.bin } : pkg.bin;
  for (const [command, path] of Object.entries(bins)) {
    const target = join(local, '.bin', command);
    if (!existsSync(target)) symlinkSync(join(local, name, path), target);
  }
}
console.log('Development dependencies linked to the selected Harness; no package download or Harness mutation.');
