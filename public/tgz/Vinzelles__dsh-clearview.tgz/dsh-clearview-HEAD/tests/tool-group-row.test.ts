import './support/dom.ts';
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import React, { createElement } from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import { PROCESS_TAIL_SLACK, followDecision, followFrame, followsTail, groupOpen, holdsWritten, keyReleasesFollow, nestedOwnsWheel, processOverflow, releasesFollow, tailOffset, ToolGroupRow, ToolGroupRowView, sameToolGroupProps, type ToolGroupRowProps, type GroupEntry } from '../src/client/ToolGroupRow.tsx';

const group = (running: boolean, failed = 0): GroupEntry => ({
  kind: 'group', key: 'group:reader-tool:1',
  items: [{ kind: 'record', key: 'r1', nodeKey: 'r1', step: 1 }, { kind: 'record', key: 'r2', nodeKey: 'r2', step: 1 }],
  facts: { counts: { command: 2 }, order: ['command'], running, failed },
});
const render = (entry: GroupEntry) => renderToStaticMarkup(createElement(ToolGroupRow, { group: entry, motion: true, onRead: () => {}, renderItem: item => createElement('i', { 'data-member': item.key }) }));

test('the reader’s choice wins; otherwise open exactly while running', () => {
  assert.equal(groupOpen(null, true), true);
  assert.equal(groupOpen(null, false), false);
  assert.equal(groupOpen(true, false), true, 'opened while running, stays open after it settles');
  assert.equal(groupOpen(false, true), false);
  assert.equal(groupOpen(null, false, true), true, 'a live tail stays open between steps');
  assert.equal(groupOpen(false, false, true), false, 'an explicit close still wins over a live tail');
});

test('a capped body follows its tail only until the reader scrolls away from it', () => {
  assert.equal(PROCESS_TAIL_SLACK, 24);
  assert.equal(followsTail(0), true);
  assert.equal(followsTail(PROCESS_TAIL_SLACK), true, 'a few px of rounding still counts as the tail');
  assert.equal(followsTail(PROCESS_TAIL_SLACK + 1), false);
  assert.equal(followsTail(1200), false, 'a reader who scrolled up keeps their place');
  assert.equal(processOverflow(400, 320), true);
  assert.equal(processOverflow(320, 320), false);
  assert.equal(processOverflow(321, 320), false, 'a single px below the cap is not a scroll region');
  assert.equal(processOverflow(322, 320), true);
  assert.equal(tailOffset(500, 320), 180, 'the tail is the bottom of a capped body');
  assert.equal(tailOffset(200, 320), 0, 'a body shorter than the cap cannot scroll');
  assert.equal(followDecision(180, 180, 500, 320), null, 'our own follow write never releases the follow');
  assert.equal(followDecision(100, 180, 500, 320), false, 'the reader scrolled away from the tail');
  assert.equal(followDecision(176, 0, 500, 320), true, 'a reader within the slack distance has returned');
  assert.equal(followFrame({ scrollTop: 0, scrollHeight: 500, clientHeight: 320 }, true), 180, 'a growing body is pinned to its tail');
  assert.equal(followFrame({ scrollTop: 180, scrollHeight: 500, clientHeight: 320 }, true), null, 'an already pinned body is not written again');
  assert.equal(followFrame({ scrollTop: 0, scrollHeight: 500, clientHeight: 320 }, false), null, 'a detached body is never moved');
  assert.equal(holdsWritten(180, 180), true, 'a body still parked at our own offset is ours to move');
  assert.equal(holdsWritten(180.4, 180), true, 'sub-pixel rounding still counts as our own write');
  assert.equal(holdsWritten(120, 180), false, 'any other offset was written by the reader, not us');
  assert.equal(holdsWritten(120, -1), false, 'a released body never matches a stale offset');
  assert.equal(releasesFollow(-120), true, 'an upward wheel step is the reader taking the body over');
  assert.equal(releasesFollow(0), false, 'a horizontal or zero step says nothing about the tail');
  assert.equal(releasesFollow(120), false, 'a downward step leaves the follow intact');
  // A nested viewport (an opened detail's raw block) keeps the wheel only while it can move.
  assert.equal(nestedOwnsWheel(120, 700, 360, -120), true, 'a nested body with room upward keeps the wheel');
  assert.equal(nestedOwnsWheel(0, 700, 360, -120), false, 'at its top the wheel is the capped body\'s again');
  assert.equal(nestedOwnsWheel(340, 700, 360, 120), false, 'at its bottom a downward step leaves it');
  assert.equal(nestedOwnsWheel(120, 700, 360, 120), true, 'a downward step with room belongs to it');
  assert.equal(nestedOwnsWheel(0, 360, 360, -120), false, 'a viewport without overflow never owns the wheel');
  assert.equal(keyReleasesFollow('ArrowUp'), true);
  assert.equal(keyReleasesFollow('PageUp'), true);
  assert.equal(keyReleasesFollow('Home'), true);
  assert.equal(keyReleasesFollow('ArrowDown'), false);
  assert.equal(keyReleasesFollow('PageDown'), false);
});

test('the grouped body is capped and scrolls, so its fold line stays reachable', () => {
  const css = readFileSync(new URL('../src/client/ToolGroupRow.module.css', import.meta.url), 'utf8');
  const bodies = [...css.matchAll(/\.group\[data-expanded="true"\] > \.members:not\(\[data-single="true"\]\)\s*\{([^}]*)\}/g)].map(match => match[1]!);
  assert.ok(bodies.length > 0, 'the expanded grouped body has its own rule');
  const capped = bodies.find(body => /max-height/.test(body));
  assert.ok(capped, 'one of its rules caps the body');
  assert.match(capped, /max-height:\s*var\(--cv-process-max-height,\s*320px\)/);
  assert.match(capped, /overflow-y:\s*auto/);
  assert.match(capped, /overscroll-behavior-y:\s*contain/);
  assert.match(capped, /overflow-anchor:\s*none/);
  assert.match(capped, /scrollbar-width:\s*thin/);
  assert.doesNotMatch(css, /max-height[^}]*data-single/, 'a singleton row never caps');
  const reader = readFileSync(new URL('../src/client/Reader.module.css', import.meta.url), 'utf8');
  assert.match(reader, /--cv-process-max-height:\s*320px/);
});

test('a settled live tail keeps its members open without claiming activity', () => {
  const html = renderToStaticMarkup(createElement(ToolGroupRow, {
    group: group(false), motion: true, onRead: () => {}, live: true,
    renderItem: item => createElement('i', { 'data-member': item.key }),
  }));
  assert.match(html, /data-group-state="settled"[^>]*data-expanded="true"/);
  assert.match(html, /data-member="r1"/);
  assert.doesNotMatch(html, /data-shimmer="true"/);
});

test('a running group is open, shimmering and shows its members', () => {
  const html = render(group(true));
  assert.match(html, /data-reader-group="group:reader-tool:1"[^>]*data-group-state="running"[^>]*data-expanded="true"/);
  assert.match(html, /运行 2 条命令/);
  assert.match(html, /data-shimmer="true"/);
  assert.match(html, /data-member="r1"[\s\S]*data-member="r2"/);
  assert.doesNotMatch(html, /data-reader-line-hint|>收起</);
});

test('a settled group is one closed line; failures add a red count', () => {
  const html = render(group(false, 1));
  assert.match(html, /data-group-state="settled"[^>]*data-expanded="false"/);
  assert.match(html, /· 1 次失败/);
  assert.match(html, /data-tone="failed"/);
  assert.doesNotMatch(html, /data-reader-line-hint|>展开</);
  assert.doesNotMatch(html, /data-reader-group-hint|展开详情|收起详情/);
});

test('group styling only supplies member indentation, with no state-specific row appearance', () => {
  const css = readFileSync(new URL('../src/client/ToolGroupRow.module.css', import.meta.url), 'utf8');
  assert.doesNotMatch(css, /data-group-state|data-reader-line|disclosureHint|background|font-weight|box-shadow/);
  assert.match(css, /var\(--cv-indent, 28px\)/);
  assert.match(css, /var\(--cv-rail-offset, 22px\)/);
});

// Drive the component's hooks and callbacks without adding a browser-test dependency.
function groupInteraction() {
  const slots: unknown[] = [];
  let cursor = 0;
  const dispatcher = {
    useState(initial: unknown) {
      const index = cursor++;
      if (!(index in slots)) slots[index] = typeof initial === 'function' ? initial() : initial;
      return [slots[index], (next: unknown) => { slots[index] = typeof next === 'function' ? next(slots[index]) : next; }];
    },
    useCallback: (callback: unknown) => callback,
    useRef(initial: unknown) {
      const index = cursor++;
      if (!(index in slots)) slots[index] = { current: typeof initial === 'function' ? (initial as () => unknown)() : initial };
      return slots[index];
    },
    useEffect: () => {},
    useLayoutEffect: () => {},
    useId: () => 'group-detail',
  };
  const internals = (React as any).__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED;
  let memberChange: ((key: string, open: boolean) => void) | undefined;
  return (running: boolean, items = group(running).items, renderMedia?: (item: GroupEntry['items'][number]) => React.ReactNode,
    retain = false, onCloseThoughts?: ToolGroupRowProps['onCloseThoughts']) => {
    cursor = 0;
    const previous = internals.ReactCurrentDispatcher.current;
    internals.ReactCurrentDispatcher.current = dispatcher;
    try {
      const row = ToolGroupRowView({ group: { ...group(running), items }, motion: false, onRead: () => {}, renderMedia, retain, onCloseThoughts, renderItem: (_item, onOpenChange) => { memberChange = onOpenChange; return null; } });
      const line = row.props.children[0];
      return { row, open: row.props['data-expanded'], toggle: line && line.props.onToggle, member: (key: string, open: boolean) => memberChange!(key, open) };
    } finally { internals.ReactCurrentDispatcher.current = previous; }
  };
}

test('opening a member in an auto-open running group preserves it when the group settles', () => {
  const render = groupInteraction();
  render(true).member('r1', true);
  assert.equal(render(false).open, true);
  render(false).member('r1', false);
  assert.equal(render(false).open, false);
});

test('reading grace holds a settled group, but an explicit close releases its retained thought seats', () => {
  const draw = groupInteraction();
  const thought = { kind: 'reasoning' as const, key: 'thought:0', nodeKey: 'thought', start: 0, step: 1 };
  const items = [thought, group(false).items[0]!];
  let released: readonly GroupEntry['items'][number][] | undefined;
  const release = (value: readonly GroupEntry['items'][number][]) => { released = value; };
  assert.equal(draw(false, items, undefined, true, release).open, true);
  draw(false, items, undefined, true, release).toggle();
  assert.deepEqual(released, items);
  assert.equal(draw(false, items, undefined, true, release).open, false, 'explicit close wins over grace');
});

test('a thought-only group has a header and preserves its keyed member seat when a tool arrives', () => {
  const draw = groupInteraction();
  const thought = { kind: 'reasoning' as const, key: 'thought:0', nodeKey: 'thought', start: 0, step: 1 };
  const first = draw(true, [thought]);
  const next = draw(true, [thought, group(true).items[0]!]);
  assert.equal(first.row.props['data-reader-group'], next.row.props['data-reader-group']);
  assert.equal(first.row.props.children[1].props.children[0].key, next.row.props.children[1].props.children[0].key);
  assert.equal(first.row.props.children[1].props['data-single'], false);
});

test('multiple open members, removed members and an explicit group close retain distinct intent', () => {
  const render = groupInteraction();
  render(true).member('r1', true);
  render(true).member('r2', true);
  render(false).member('r1', false);
  assert.equal(render(false).open, true);
  assert.equal(render(false, [group(false).items[0], { kind: 'record', key: 'r3', nodeKey: 'r3', step: 1 }]).open, false, 'removed open member does not pin the group');
  render(false).toggle();
  assert.equal(render(false).open, false, 'explicit group close overrides an open member');
  render(true).toggle();
  assert.equal(render(false).open, true, 'explicit group reopen survives settlement');
});

test('a settled singleton shows its member without a group header or group marker', () => {
  const entry = group(false, 1);
  entry.items = entry.items.slice(0, 1);
  const html = render(entry);
  assert.match(html, /data-member="r1"/);
  assert.doesNotMatch(html, /data-reader-group=|运行了|次失败/);
});

test('media stays visible after settlement and follows each member in source order', () => {
  const draw = (running: boolean) => renderToStaticMarkup(createElement(ToolGroupRow, {
    group: group(running), motion: false, onRead: () => {},
    renderItem: item => createElement('i', { 'data-member': item.key }),
    renderMedia: item => createElement('b', { 'data-media': item.key }),
  }));
  const opened = draw(true);
  assert.match(opened, /data-member="r1"[\s\S]*data-media="r1"[\s\S]*data-member="r2"[\s\S]*data-media="r2"/);
  const settled = draw(false);
  assert.doesNotMatch(settled, /data-member=/);
  assert.match(settled, /data-expanded="false"[\s\S]*data-media="r1"[\s\S]*data-media="r2"/);
});

test('singleton growth retains its keyed member parent and its open-detail intent', () => {
  const draw = groupInteraction();
  const items = group(true).items;
  const one = draw(true, items.slice(0, 1));
  assert.equal(one.open, true);
  assert.equal(one.row.props['data-reader-group'], undefined);
  const oneMembers = one.row.props.children[1];
  assert.equal(oneMembers.type, 'div');
  const oneSeat = oneMembers.props.children[0];
  assert.equal(oneSeat.key, 'r1');
  one.member('r1', true);
  const two = draw(true);
  const twoMembers = two.row.props.children[1];
  const twoSeat = twoMembers.props.children[0];
  assert.equal(twoMembers.type, oneMembers.type);
  assert.equal(twoMembers.props.id, oneMembers.props.id);
  assert.equal(twoSeat.type, oneSeat.type);
  assert.equal(twoSeat.key, oneSeat.key);
  assert.equal(twoSeat.props.children[0].type, oneSeat.props.children[0].type);
  assert.equal(twoSeat.props.children[0].props.open, true);
  assert.equal(draw(false).open, true, 'the detail opened before the group grew still pins it after settlement');
});

test('late media and explicit group closing keep the members container and keyed slots stable', () => {
  const draw = groupInteraction();
  const before = draw(true);
  const after = draw(true, undefined, item => createElement('b', { 'data-media': item.key }));
  const membersBefore = before.row.props.children[1];
  const membersAfter = after.row.props.children[1];
  assert.equal(membersAfter.type, 'div');
  assert.equal(membersAfter.props.id, membersBefore.props.id);
  assert.deepEqual(membersAfter.props.children.map((seat: React.ReactElement) => seat.key), ['r1', 'r2']);
  for (let index = 0; index < 2; index++) {
    const oldSeat = membersBefore.props.children[index];
    const newSeat = membersAfter.props.children[index];
    assert.equal(newSeat.type, oldSeat.type);
    assert.equal(newSeat.props.children[0].type, oldSeat.props.children[0].type);
    assert.equal(newSeat.props.children[1].props['data-media'], newSeat.key);
  }
  after.toggle();
  const closed = draw(true, undefined, item => createElement('b', { 'data-media': item.key }));
  assert.equal(closed.open, false);
  for (const seat of closed.row.props.children[1].props.children) {
    assert.equal(seat.props.children[0].props.open, false);
    assert.equal(seat.props.children[1].props['data-media'], seat.key);
  }
  const singleton = draw(false, group(false).items.slice(0, 1));
  assert.equal(singleton.open, true, 'a singleton stays visible even after an explicit group close');
  assert.equal(singleton.row.props.children[1].type, 'div');
});

test('a closed group without media leaves an empty members container covered by the empty CSS rule', () => {
  const html = renderToStaticMarkup(createElement(ToolGroupRow, {
    group: group(false), motion: false, onRead: () => {},
    renderItem: item => createElement('i', { 'data-member': item.key }),
    renderMedia: () => null,
  }));
  assert.match(html, /<div[^>]*class="members"[^>]*><\/div>/);
  assert.doesNotMatch(html, /data-member=/);
  const css = readFileSync(new URL('../src/client/ToolGroupRow.module.css', import.meta.url), 'utf8');
  assert.match(css, /\.members:empty\s*\{\s*display:\s*none\s*\}/);
});


test('memo skips recreated wrappers around the same ordered immutable tool payloads', () => {
  const block = { kind: 'tool-call', callId: 'a', call: { name: 'bash', argsRaw: '{"command":"pwd"}' }, subCalls: [], content: [], isError: false, time: 1 } as any;
  const item = { kind: 'tool' as const, key: 'reader-tool:a', step: 1, entry: { kind: 'tool' as const, key: 'reader-tool:a', callId: 'a', step: 1, order: 1, block } };
  const props: ToolGroupRowProps = { group: { ...group(false), items: [item, { ...item, key: 'reader-tool:b', entry: { ...item.entry, key: 'reader-tool:b', callId: 'b', order: 2 } }] }, motion: true, onRead: () => {}, renderItem: () => null, renderMedia: () => null };
  const copied = () => ({ ...props, group: { ...props.group, facts: { ...props.group.facts, order: [...props.group.facts.order], counts: { ...props.group.facts.counts } }, items: props.group.items.map(row => row.kind === 'tool' ? { ...row, entry: { ...row.entry } } : { ...row }) } });
  assert.equal(sameToolGroupProps(props, copied()), true);
  for (const field of ['motion', 'onRead', 'renderItem', 'renderMedia'] as const) {
    const next = copied();
    if (field === 'motion') next.motion = false;
    else next[field] = () => null;
    assert.equal(sameToolGroupProps(props, next), false, field);
  }
  assert.equal(sameToolGroupProps(props, { ...copied(), live: true }), false, 'live');
  for (const change of ['block', 'draft', 'step', 'key', 'order', 'running', 'failed', 'counts', 'kindOrder']) {
    const next = copied(), row = next.group.items[0];
    if (row.kind !== 'tool') throw Error('tool fixture');
    if (change === 'block') row.entry.block = { ...block, content: [{ type: 'image', attachment: { attachmentId: 'late-image' } }] };
    if (change === 'draft') row.entry.draft = { kind: 'tool-call', callId: 'a', name: 'bash', argsRaw: '{"command":"pwd"}' } as any;
    if (change === 'step') row.entry.step = 2;
    if (change === 'key') row.key = 'different-seat';
    if (change === 'order') next.group.items.reverse();
    if (change === 'running') next.group.facts.running = true;
    if (change === 'failed') next.group.facts.failed = 1;
    if (change === 'counts') next.group.facts.counts.command = 3;
    if (change === 'kindOrder') next.group.facts.order = ['read', 'command'];
    assert.equal(sameToolGroupProps(props, next), false, change);
  }
});
