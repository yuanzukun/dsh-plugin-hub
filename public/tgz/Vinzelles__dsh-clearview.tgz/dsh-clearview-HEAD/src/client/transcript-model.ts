import type { AssistantChatData, ChatConversationViewNode } from '@deepseek-ai/dsh-client-ui-chat/client';
import type { PanelItem, ReasoningItem } from './process-steps.js';
import { assistantSegments } from './projection.js';
import { activityPhase, activitySummary, objectValue } from './tool-activity.js';

type Getter = (key: string) => ChatConversationViewNode | undefined;
export type GroupKind = 'thinking' | 'command' | 'read' | 'write' | 'edit' | 'search' | 'web' | 'skill' | 'tool' | 'operation';
export interface GroupFacts { counts: Partial<Record<GroupKind, number>>; order: GroupKind[]; running: boolean; failed: number }
export interface PlanTodo { content: string; status: 'pending' | 'in_progress' | 'completed' }
export type ToolItem = Extract<PanelItem, { kind: 'tool' }>;
export type PlanTone = 'idle' | 'running' | 'failed' | 'interrupted';
/** One card per turn, at the first nonempty plan call's position. Calls retain their original args/results. */
export interface PlanEntry {
  kind: 'plan'; key: string;
  /** Latest call, including malformed, failed and unfinished updates. */
  item: ToolItem;
  calls: ToolItem[];
  /** Only a successfully returned, parseable call can replace the checklist. */
  successfulCall: ToolItem | null;
  todos: PlanTodo[];
}
// PanelItem declares record and input as one variant (kind: 'record' | 'input'), so Extract on 'input' alone would be never.
export type InputItem = Extract<PanelItem, { kind: 'record' | 'input' }>;
export type TranscriptEntry =
  | { kind: 'narration'; key: string; item: Extract<PanelItem, { kind: 'narration' }> }
  | { kind: 'thought'; key: string; item: ReasoningItem }
  | { kind: 'input'; key: string; item: InputItem }
  | PlanEntry
  | { kind: 'item'; key: string; item: PanelItem; facts?: GroupFacts }
  | { kind: 'group'; key: string; items: PanelItem[]; facts: GroupFacts };

const STANDALONE_TOOLS = new Set(['todo_write', 'dispatch', 'ask_user_question']);
const STATUSES = new Set(['pending', 'in_progress', 'completed']);
const WORDS: Record<GroupKind, (count: number) => string> = {
  thinking: () => '思考',
  command: n => `运行 ${n} 条命令`, read: n => `读取 ${n} 个文件`, write: n => `写入 ${n} 个文件`, edit: n => `编辑 ${n} 个文件`,
  search: n => `搜索 ${n} 次`, web: n => `访问 ${n} 次网页`, skill: n => `使用 ${n} 个技能`, tool: n => `调用 ${n} 次工具`, operation: n => `执行 ${n} 个操作`,
};

export function parseTodos(argsRaw: string): PlanTodo[] | null {
  let parsed: unknown;
  try { parsed = JSON.parse(argsRaw); } catch { return null; }
  const list = objectValue(parsed)?.todos;
  // The host treats [] as a successful whole-list replacement (clear), not a missing payload.
  if (!Array.isArray(list)) return null;
  const todos: PlanTodo[] = [];
  for (const raw of list) {
    const item = objectValue(raw);
    if (typeof item?.content !== 'string' || typeof item.status !== 'string' || !STATUSES.has(item.status)) return null;
    todos.push({ content: item.content, status: item.status as PlanTodo['status'] });
  }
  return todos;
}

export function diffStat(oldText: string | null, newText: string): { added: number; removed: number } {
  const before = oldText === null || oldText === '' ? [] : oldText.replace(/\n$/, '').split('\n');
  const after = newText === '' ? [] : newText.replace(/\n$/, '').split('\n');
  let head = 0;
  while (head < before.length && head < after.length && before[head] === after[head]) head++;
  let tail = 0;
  while (tail < before.length - head && tail < after.length - head && before[before.length - 1 - tail] === after[after.length - 1 - tail]) tail++;
  return { added: after.length - head - tail, removed: before.length - head - tail };
}

function toolKind(item: ToolItem): GroupKind {
  const facts = activitySummary(item.entry);
  if (facts.name === 'skill') return 'skill';
  switch (facts.category) {
    case 'terminal': return 'command';
    case 'read': return 'read';
    case 'search': return 'search';
    case 'web': return 'web';
    case 'write': return facts.name === 'write' || (facts.name === 'str_replace_editor' && facts.args.command === 'create') ? 'write' : 'edit';
    default: return 'tool';
  }
}

function recordData(node: ChatConversationViewNode) {
  return node.data as { outcome?: { kind?: string } | null; compaction?: unknown; command?: { outcome?: { kind?: string } | null } | null } | null;
}

export function isOperational(item: PanelItem, get: Getter): boolean {
  if (item.kind === 'tool') return !STANDALONE_TOOLS.has(activitySummary(item.entry).name);
  if (item.kind !== 'record') return false;
  const node = get(item.nodeKey);
  if (!node) return false;
  const data = recordData(node);
  if (node.kind === 'command') return data?.outcome?.kind !== 'error';
  if (node.kind === 'manual-compaction') return data?.command?.outcome?.kind !== 'error';
  return false;
}

function factsOf(items: readonly PanelItem[], get: Getter, turnClosed: boolean): GroupFacts {
  const facts: GroupFacts = { counts: {}, order: [], running: false, failed: 0 };
  const count = (kind: GroupKind) => {
    if (!(kind in facts.counts)) facts.order.push(kind);
    facts.counts[kind] = (facts.counts[kind] ?? 0) + 1;
  };
  for (const item of items) {
    if (item.kind === 'reasoning') {
      count('thinking');
      if (isLiveThought(item, get, !turnClosed)) facts.running = true;
      continue;
    }
    if (item.kind === 'tool') {
      count(toolKind(item));
      const phase = activityPhase(item.entry, turnClosed);
      if (phase === 'preparing' || phase === 'running') facts.running = true;
      if (phase === 'failed') facts.failed++;
      continue;
    }
    const node = item.kind === 'record' ? get(item.nodeKey) : undefined;
    if (!node) continue;
    const data = recordData(node);
    if (node.kind === 'command') {
      count('command');
      if (data?.outcome?.kind === 'error') facts.failed++;
      if (!turnClosed && data?.outcome == null) facts.running = true;
    } else {
      count('operation');
      if (data?.command?.outcome?.kind === 'error') facts.failed++;
      if (!turnClosed && data?.command?.outcome == null && data?.compaction == null) facts.running = true;
    }
  }
  return facts;
}

export function groupSummary(facts: GroupFacts): string {
  return facts.order.map(kind => WORDS[kind](facts.counts[kind]!)).join('，');
}

/** Presentation derived from the latest call; a rejected update never masquerades as a saved checklist. */
export function planStatus(plan: PlanEntry, turnClosed: boolean): { tone: PlanTone; detail: string } {
  const phase = activityPhase(plan.item.entry, turnClosed);
  const retained = plan.successfulCall ? '显示上次成功清单' : '尚无成功清单';
  if (phase === 'preparing') return { tone: 'running', detail: `正在生成计划更新 · ${retained}` };
  if (phase === 'running') return { tone: 'running', detail: `正在更新计划 · ${retained}` };
  if (phase === 'failed') return { tone: 'failed', detail: `计划更新失败 · ${retained}` };
  if (phase === 'interrupted') return { tone: 'interrupted', detail: `计划更新已中断 · ${retained}` };
  if (plan.successfulCall !== plan.item) return { tone: 'idle', detail: `计划条目无法解析 · ${retained}` };
  return { tone: 'idle', detail: plan.todos.length === 0 ? '计划已清空' : '计划已更新' };
}

export function buildTranscript(items: readonly PanelItem[], get: Getter, turnClosed: boolean): TranscriptEntry[] {
  const entries: TranscriptEntry[] = [];
  const calls = items.filter((item): item is ToolItem => item.kind === 'tool' && activitySummary(item.entry).name === 'todo_write');
  // Earlier empty/malformed calls keep their own seats. History starts at the first nonempty,
  // parseable call, so establishing a later card never unmounts those earlier disclosures.
  const firstPlanIndex = calls.findIndex(call => (parseTodos(activitySummary(call.entry).raw)?.length ?? 0) > 0);
  const firstPlanCall = calls[firstPlanIndex];
  const history = firstPlanIndex < 0 ? [] : calls.slice(firstPlanIndex);
  const plan: PlanEntry | null = firstPlanCall
    ? { kind: 'plan', key: firstPlanCall.key, item: history.at(-1)!, calls: history, successfulCall: null, todos: [] }
    : null;
  for (const call of calls) {
    const todos = parseTodos(activitySummary(call.entry).raw);
    const phase = activityPhase(call.entry, turnClosed);
    if (plan && todos && (phase === 'returned' || phase === 'succeeded')) {
      plan.todos = todos;
      plan.successfulCall = call;
    }
  }
  let run: PanelItem[] = [];
  const flush = () => {
    if (run.length === 1 && run[0]!.kind !== 'reasoning') entries.push({ kind: 'item', key: run[0]!.key, item: run[0]!, facts: factsOf(run, get, turnClosed) });
    else if (run.length > 0) entries.push({ kind: 'group', key: `group:${run[0]!.key}`, items: run, facts: factsOf(run, get, turnClosed) });
    run = [];
  };
  for (const item of items) {
    if (item.kind === 'reasoning' || isOperational(item, get)) { run.push(item); continue; }
    flush();
    if (item.kind === 'narration') entries.push({ kind: 'narration', key: item.key, item });
    else if (item.kind === 'input') entries.push({ kind: 'input', key: item.key, item });
    else if (item.kind === 'tool' && activitySummary(item.entry).name === 'todo_write') {
      if (!plan || !history.includes(item)) entries.push({ kind: 'item', key: item.key, item });
      else if (item === firstPlanCall) entries.push(plan);
    } else entries.push({ kind: 'item', key: item.key, item });
  }
  flush();
  return entries;
}

function isLiveThought(item: ReasoningItem, get: Getter, open: boolean): boolean {
  if (!open) return false;
  const node = get(item.nodeKey);
  if (node?.kind !== 'assistant-step') return false;
  const data = node.data as AssistantChatData;
  return data.status === 'running' && data.blocks.at(-1)?.kind === 'reasoning'
    && assistantSegments(data.blocks).at(-1)?.start === item.start;
}

/** Reading/grace seats are keyed to the thought itself, independently of its containing process group. */
export function transcriptThoughts(entries: readonly TranscriptEntry[]): ReasoningItem[] {
  return entries.flatMap(entry => entry.kind === 'thought' ? [entry.item] : entry.kind === 'group'
    ? entry.items.filter((item): item is ReasoningItem => item.kind === 'reasoning') : []);
}

/** Only source-trailing reasoning is live, including when it belongs to a mixed process group. */
export function liveThoughtKey(entries: readonly TranscriptEntry[], get: Getter, open: boolean): string | null {
  const last = entries.at(-1);
  const item = last?.kind === 'group' ? last.items.at(-1) : last?.kind === 'thought' ? last.item : undefined;
  return item?.kind === 'reasoning' && isLiveThought(item, get, open) ? item.key : null;
}
