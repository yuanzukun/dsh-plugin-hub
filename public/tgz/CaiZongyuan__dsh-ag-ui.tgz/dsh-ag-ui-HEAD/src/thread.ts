import type {} from '@deepseek-ai/dsh-fs'
import type {} from '@deepseek-ai/dsh-agent-preset-registry'
import { isPresentedEvent } from './deliverables.ts'
import type { Context } from '@deepseek-ai/cordis'
import { mkdir, realpath } from 'node:fs/promises'
import { join } from 'node:path'
import {
  EventType,
  type InputContent,
  type RunAgentInput,
  type Tool as AgUiTool,
  type ToolMessage as AgUiToolMessage,
  type UserMessage as AgUiUserMessage,
} from '@ag-ui/core'
import type { Agent, AgentHandle, AgentSetup } from '@deepseek-ai/dsh-agent'
import type {
  AdmittedPromptContentPart,
  AttachmentStore,
  ImageMediaType,
  AttachmentAdmissionPart,
  FileAttachmentRef,
} from '@deepseek-ai/dsh-attachment'
import { createUserMessage, errorChain, freezeMessage, MessageId, ToolCallId, type UserMessage, type ContextFormed } from '@deepseek-ai/dsh-llm'
import { SessionId, type SessionEvent } from '@deepseek-ai/dsh-session'
import { SessionPersistenceNotFoundError } from '@deepseek-ai/dsh-session-persistence'
import type {} from '@deepseek-ai/dsh-session-projection'
import {
  assertObjectJsonSchema,
  validateJsonSchemaValue,
  type ObjectJsonSchema,
  type ToolDefinition,
  type ToolRunContext,
} from '@deepseek-ai/dsh-tools'
import { isJsonValue, type JsonValue } from '@deepseek-ai/dsh-util-values'
import { isDeepStrictEqual } from 'node:util'
import type { FileUploads, FileUploadReceiptId, FileUploadValue } from '@deepseek-ai/dsh-client-file-upload'
import { signedFileUrl, verifiedFileUrl } from './files.ts'
import { frontendResultDigest, frontendResultMeta } from './frontend-result.ts'
import { AgUiGatewayError } from './errors.ts'
import { jsonBytes, valueDigest } from './json.ts'
import { consumedMessages, durableUserId, SessionProjection, STATE_TOOL_NAME } from './projection.ts'
import { agentPresetsOf, sessionPresetOf } from './presets.ts'
import { PendingInterrupts, type PreparedResume } from './interrupts.ts'
import { RunController, type RunRecord } from './run.ts'
import type { ToolPresenter } from './tool-view.ts'
import type { AgUiPrincipal, AgUiThreadIdentity } from './types.ts'

declare module '@deepseek-ai/dsh-llm' {
  interface MessageSourceMap {
    'ag-ui': { readonly kind: 'ag-ui' } & ContextFormed
  }
}

export type RunAdmission = RunController | { replay: RunRecord }

/** Synthetic context Tool used by the official A2UI middleware for user actions. */
const A2UI_ACTION_TOOL_NAME = 'log_a2ui_event'
/** Default name of the render Tool the official A2UI middleware injects into a run. */
const A2UI_RENDER_TOOL_NAME = 'render_a2ui'
/** The result the middleware would synthesize for a render call; the Gateway returns it inside the run instead. */
const A2UI_RENDERED_RESULT = JSON.stringify({ status: 'rendered' })
const FRONTEND_TOOL_NAME = /^[A-Za-z_][A-Za-z0-9_-]{0,63}$/
const IMAGE_MEDIA_TYPES = new Set<string>(['image/png', 'image/jpeg', 'image/webp', 'image/gif'])

/** Fixed identity for registry scheduling probes that never dispatch. */
const SCHEDULING_PROBE = {
  callId: ToolCallId('ag-ui-scheduling-probe'),
  arguments: {},
  signal: new AbortController().signal,
}

/** Runtime limits and model route resolved from Gateway config. */
export interface ThreadOptions {
  readonly provider: string
  readonly model: string
  /** Absolute root containing the deterministic thread workspace. */
  readonly workspaceRoot: string
  /** Preset id composed into the thread's agents; absent keeps the host composition. */
  readonly presetId?: string
  /** Server-granted canonical ids for this binding's authenticated tenant. */
  readonly selectablePresetIds?: ReadonlySet<string>
  readonly humanInteractionTimeoutMs?: number
  readonly maxPendingInterrupts?: number
  readonly frontendToolTimeoutMs: number
  readonly threadIdleMs: number
  readonly maxRunEvents: number
  readonly maxRunEventBytes: number
  readonly maxRunsPerThread: number
  readonly maxStateBytes: number
  readonly maxFilesPerMessage: number
  readonly fileSecret?: string
  /** Gateway route prefix used in declared file URLs. */
  readonly path?: string
}

interface AcceptedMessage {
  readonly role: 'user' | 'tool'
  readonly digest: string
}

interface A2UIUserAction {
  readonly name?: string
  readonly surfaceId?: string
  readonly sourceComponentId?: string
  readonly context?: Record<string, unknown>
  readonly timestamp?: string
}

interface A2UIActionContinuation {
  readonly action: A2UIUserAction
  readonly result: AgUiToolMessage
}

interface FrontendToolRegistration {
  readonly dispose: () => void
  readonly fingerprint: string
}

interface PendingFrontendCall {
  readonly turn: number
  resolve(value: FrontendToolResultValue): void
  reject(error: Error): void
}

type FrontendToolResultValue = {
  readonly content: string
  readonly presentationMeta?: JsonValue
}

interface PreparedFrontendTool {
  readonly tool: AgUiTool
  readonly fingerprint: string
  readonly schema: ObjectJsonSchema & Record<string, unknown>
}

interface SharedStateBaseline {
  readonly active: boolean
  readonly value: unknown
}

interface WorkspaceRegistryLike {
  create(path: string, title?: string): Promise<unknown>
}

/** One authenticated process-local AG-UI thread and its owned DSH Agent. */
export class ThreadBinding {
  /** Deterministic durable DSH session identity, derived from the authenticated thread tuple. */
  readonly sessionId: SessionId
  /** Authenticated principal and client thread tuple owning this binding. */
  readonly identity: AgUiThreadIdentity
  /** Pure session-event to wire-event translation owned by this thread. */
  private readonly projection: SessionProjection
  /** Presenter seam: definitions resolve in the owning Agent's scope; client Tools present themselves. */
  private readonly presenter: ToolPresenter = {
    resolve: (name) => this.ctx.tools.get(name, this.liveAgent),
    isFrontendTool: (name) => this.frontendTools.has(name),
  }
  /** Whether an announced Tool would still start while a parked call holds the pool. */
  private readonly startsWhileParked = (name: string): boolean =>
    this.ctx.tools.executionMode({ ...SCHEDULING_PROBE, name, agent: this.liveAgent }).kind === 'parallel'

  private handle: AgentHandle | undefined
  private agent: Agent | undefined
  private disposed = false
  private interrupted = false
  private activeRun: RunController | undefined
  private nativeTurn: number | undefined
  private readonly interrupts: PendingInterrupts
  private waitingRuns = 0
  private idleTimer: ReturnType<typeof setTimeout> | undefined
  private activeFileOperations = 0
  private readonly acceptedMessages = new Map<string, AcceptedMessage>()
  private readonly frontendTools = new Map<string, FrontendToolRegistration>()
  private stagedTools: AgUiTool[] | undefined
  /** Render Tool the A2UI middleware flagged for the current run; its calls settle without a browser result. */
  private a2uiRenderTool: string | undefined
  private toolResultMetadata: Readonly<Record<string, JsonValue>> = {}
  private readonly pendingCalls = new Map<string, PendingFrontendCall>()
  private readonly runLedger = new Map<string, RunController>()
  private readonly userMessageIds = new Map<string, string>()
  private sharedStateActive = false
  private stateToolDispose: (() => void) | undefined

  constructor(
    private readonly ctx: Context,
    principal: AgUiPrincipal,
    threadId: string,
    sessionId: SessionId,
    private readonly options: ThreadOptions,
    private readonly onExpired: (binding: ThreadBinding) => void,
  ) {
    this.identity = { principal, threadId }
    this.sessionId = sessionId
    this.projection = new SessionProjection(sessionId, this.presenter, (seq, index) =>
      `${options.path ?? '/ag-ui'}/threads/${encodeURIComponent(threadId)}/deliverables/${String(seq)}/files/${String(index)}`)
    this.interrupts = new PendingInterrupts(options.humanInteractionTimeoutMs ?? 300_000, options.maxPendingInterrupts ?? 16,
      () => { this.clearIdleExpiry(); this.finishWaitingRun() },
      (turn, reason) => {
        /* v8 ignore next -- registration is synchronous; turn completion removes all timers and abort listeners before ownership changes. */
        if (this.nativeTurn === turn) this.liveAgent.cancel({ kind: 'hook', reason })
        this.scheduleIdleExpiry()
      }, message => { this.ctx.logger.warn(message) })
  }

  /** Create the Agent — resuming a persisted session when the host configured one — and install scoped listeners before publication. */
  async initialize(): Promise<void> {
    const handle = await this.restoreOrCreate()
    this.handle = handle
    this.agent = handle.agent
    this.scheduleIdleExpiry()
  }

  private async restoreOrCreate(): Promise<AgentHandle> {
    const agentOptions = { provider: this.options.provider, model: this.options.model }
    const create = () => this.create(agentOptions)
    if (this.ctx.get('sessionPersistence') === undefined) return create()
    try {
      const handle = await this.ctx.agents.resume({ resumeSessionId: this.sessionId, agentOptions, setup: this.agentSetup() })
      try {
        const recordedCwd = handle.agent.session.header.cwd
        if (recordedCwd === undefined) {
          this.ctx.logger.warn(`ag-ui: resumed legacy session ${String(this.sessionId)} without a workspace cwd`)
        } else {
          const cwd = await this.prepareWorkspace()
          if (recordedCwd !== cwd) {
            throw new AgUiGatewayError(
              'SESSION_CWD_MISMATCH',
              'The persisted session workspace does not match the configured thread workspace.',
              409,
            )
          }
        }
        this.recover(handle.agent.session.snapshotEvents())
        return handle
      } catch (error) {
        await handle.dispose()
        throw error
      }
    } catch (error) {
      // A missing log permits creation; corruption, format refusal, and setup failures do not.
      if (!(error instanceof SessionPersistenceNotFoundError)) throw error
      return create()
    }
  }

  private async create(agentOptions: { provider: string; model: string }): Promise<AgentHandle> {
    const cwd = await this.prepareWorkspace()
    const registry = workspaceRegistryOf(this.ctx)
    if (registry !== undefined) await registry.create(cwd, String(this.sessionId))
    const meta = {
      cwd,
      ...(this.options.presetId === undefined ? {} : { agentPreset: this.options.presetId }),
    }
    return this.ctx.agents.create({
      sessionId: this.sessionId,
      meta,
      agentOptions,
      setup: this.agentSetup(),
    })
  }

  private async prepareWorkspace(): Promise<string> {
    // named by the durable session id so the client thread id stays off disk
    const directory = join(this.options.workspaceRoot, String(this.sessionId))
    await mkdir(directory, { recursive: true })
    return realpath(directory)
  }

  private agentSetup(): AgentSetup {
    return async (agentCtx, agent) => {
      this.agent = agent
      agentCtx.on('user-questions/request', (request, next) =>
        request.agent === agent && this.ownsHumanTurn(agent)
          ? this.interrupts.questions(request, this.nativeTurn!) : next())
      agentCtx.on('approval/request', (request, next) =>
        request.agent === agent && this.ownsHumanTurn(agent)
          ? this.interrupts.approval(request, this.nativeTurn!) : next())
      agentCtx.on('session/event', (session, event) => {
        /* v8 ignore next -- the Agent-scoped listener receives only its exact owned Session. */
        if (session === agent.session) this.onSessionEvent(event)
      })
      agentCtx.on('agent/assistant-stream', ({ agent: subject, frame }) => {
        /* v8 ignore next -- the Agent-scoped stream belongs to this exact Agent. */
        if (subject !== agent) return
        const active = this.activeRun
        const step = this.projection.projectStream(frame, this.nativeTurn)
        if (active?.record.state !== 'active' || active.turn === undefined || active.turn !== this.nativeTurn) return
        for (const event of step.events) active.emit(event)
      })
      agentCtx.on('agent/inbox/claimed', ({ agent: subject, message, turn }) => {
        const active = this.activeRun
        if (subject === agent && active?.messageId === String(message.id)) {
          active.turn = turn
          this.nativeTurn = turn
        }
      })
      agentCtx.on('agent/error', ({ agent: subject, error }) => {
        /* v8 ignore next -- scope-filtered Agent errors carry this exact Agent. */
        if (subject === agent) this.onAgentError(error)
      })
      agentCtx.on('tools/change', () => { this.checkGlobalCollisions() })
      // mounting inside the setup window rolls a broken preset back with the whole creation
      await this.mountPreset(agentCtx, agent)
    }
  }

  private ownsHumanTurn(agent: Agent): boolean {
    return !this.disposed && this.nativeTurn !== undefined && this.ctx.agents.get(agent.id) === agent
      && this.ctx.agents.roots().includes(agent)
  }

  /** Compose the agent from its preset; a thread resumes the composition its own log recorded. */
  private async mountPreset(agentCtx: Context, agent: Agent): Promise<void> {
    const presets = agentPresetsOf(this.ctx)
    if (presets === undefined) {
      if (this.options.presetId === undefined) return
      // a roster that vanished after activation stays loud instead of composing from host tools
      throw new Error('ag-ui: the configured agent preset cannot mount because no agent-presets roster is active')
    }
    const presetId = sessionPresetOf(agent.session) ?? this.options.presetId
    if (presetId !== undefined) await presets.mount(agentCtx, presetId)
  }

  /** Rebuild idempotency bookkeeping from one recovered durable log. */
  private recover(events: readonly SessionEvent[]): void {
    const recovery = this.projection.recoverFrom(events)
    for (const user of recovery.users) {
      this.userMessageIds.set(durableUserId(user.clientId), user.clientId)
      this.acceptedMessages.set(user.clientId, { role: 'user', digest: messageDigest(user.clientId, user.content) })
    }
    for (const result of recovery.frontendResults) {
      this.acceptedMessages.set(result.id, { role: 'tool', digest: frontendResultDigest(result) })
    }
    this.interrupted = recovery.interrupted
  }

  /** The live Agent after successful initialization. */
  get liveAgent(): Agent {
    if (this.agent === undefined || this.handle === undefined || this.disposed) {
      throw new AgUiGatewayError('AGENT_NOT_AVAILABLE', 'The AG-UI thread Agent is unavailable.', 410)
    }
    return this.agent
  }

  /**
   * Read one retained run for duplicate handling.
   * @param runId - client run identity.
   * @returns active or completed record, or undefined for a fresh id.
   */
  getRun(runId: string, digest?: string): RunRecord | undefined {
    const record = this.runLedger.get(runId)?.record
    if (record !== undefined && digest !== undefined && record.digest !== digest) {
      throw new AgUiGatewayError('RUN_ID_CONFLICT', 'The runId was reused with different input.', 409)
    }
    return record
  }

  /**
   * Admit one run. A history-only run is served at once, even beside an active run, because it
   * only reads the session log. Any other run waits until this thread is free and reserves it in
   * the same tick, so two queued runs never race for one reservation.
   * @param signal - aborted once the waiting client is gone; that run is never admitted.
   */
  async admit(input: RunAgentInput, digest: string, signal: AbortSignal): Promise<RunAdmission> {
    const disconnected = new AgUiGatewayError('CLIENT_DISCONNECTED', 'The AG-UI client left before its queued run started.', 409)
    if (signal.aborted) throw disconnected
    this.assertLive()
    const prior = this.getRun(input.runId, digest)
    if (prior !== undefined) return { replay: prior }
    if (this.classifyMessages(input).kind === 'sync' && (input.resume?.length ?? 0) === 0) {
      await this.preparePreset(input, true)
      if (signal.aborted) throw disconnected
      this.assertLive()
      const replay = this.getRun(input.runId, digest)
      return replay === undefined ? this.retainRun(input, digest) : { replay }
    }
    if (this.waitingRuns >= this.options.maxRunsPerThread) {
      throw new AgUiGatewayError('RUN_QUEUE_FULL', 'The AG-UI thread run queue is full.', 429)
    }
    this.waitingRuns++
    this.clearIdleExpiry()
    const runId = input.runId
    const session = String(this.sessionId)
    const left = Promise.withResolvers<never>()
    const onAbort = (): void => {
      this.ctx.logger.debug(`ag-ui: run ${runId} left the queue of session ${session}`)
      left.reject(disconnected)
    }
    signal.addEventListener('abort', onAbort, { once: true })
    left.promise.catch(() => {})
    try {
      for (;;) {
        // Settlement and disconnect can happen in the same tick; the race alone is insufficient.
        if (signal.aborted) throw disconnected
        if (this.activeRun !== undefined) {
          this.ctx.logger.debug(`ag-ui: run ${runId} waits for the active run of session ${session}`)
          await Promise.race([this.activeRun.done, left.promise])
        } else if (this.pendingCalls.size === 0 && !this.interrupts.waiting && this.liveAgent.status !== 'idle') {
          // a settled run may leave its finishing or cancelled turn converging; parked calls keep a turn open on purpose
          this.ctx.logger.debug(`ag-ui: run ${runId} waits for the Agent of session ${session} to settle`)
          await Promise.race([this.liveAgent.whenIdle(), left.promise])
        } else {
          const replay = this.getRun(input.runId, digest)
          if (replay !== undefined) return { replay }
          this.prepareResume(input, this.classifyMessages(input).kind)
          const controller = this.reserveRun(input, digest)
          try {
            await this.preparePreset(input, false)
            if (signal.aborted) throw disconnected
            this.assertLive()
            // Native selection can replace the inherited Tool names while admission awaits.
            this.assertStateToolAvailable(this.prepareSharedState(input))
            this.prepareFrontendTools(input.tools)
            return controller
          } catch (error) {
            // A rejected HTTP admission never becomes a replayable SSE run.
            this.runLedger.delete(input.runId)
            this.failRunAdmission(controller, error)
            throw error
          }
        }
      }
    } finally {
      signal.removeEventListener('abort', onAbort)
      this.waitingRuns--
      this.scheduleIdleExpiry()
    }
  }

  /** Authorize a selector locally; native selection owns composition and its durable record. */
  private async preparePreset(input: RunAgentInput, readOnly: boolean): Promise<void> {
    const props: unknown = input.forwardedProps
    if (typeof props !== 'object' || props === null || !('agentPreset' in props)) return
    const requested = props.agentPreset
    if (typeof requested !== 'string' || requested.length === 0) {
      throw new AgUiGatewayError('INVALID_AGENT_PRESET', 'forwardedProps.agentPreset must be a non-empty preset id.')
    }
    if (requested === sessionPresetOf(this.liveAgent.session)) return
    if (!this.options.selectablePresetIds?.has(requested)) {
      throw new AgUiGatewayError('PRESET_NOT_ALLOWED', 'This tenant may not select the requested agent preset.', 403)
    }
    // Read the native boundary so history can report a mismatch without calling select.
    const boundary = this.ctx.get('sessionProjections')?.stateOf(this.liveAgent.session, 'turnBoundary')
    if (boundary !== undefined && (boundary.openTurnStartSeq !== null || boundary.lastTurn > 0)) {
      throw new AgUiGatewayError('PRESET_LOCKED', 'The thread has started; choose a new thread to use another agent preset.', 409)
    }
    if (readOnly || this.classifyMessages(input).kind === 'sync') return
    this.assertUserRunReady()
    this.prepareSharedState(input)
    const presets = agentPresetsOf(this.ctx)
    if (presets === undefined) {
      throw new AgUiGatewayError('PRESET_UNAVAILABLE', 'The agent-preset roster is unavailable.', 503)
    }
    try {
      await presets.select(this.liveAgent, requested)
    } catch (error) {
      if (typeof error === 'object' && error !== null && 'code' in error) {
        if (error.code === 'agent-preset/locked') {
          throw new AgUiGatewayError('PRESET_LOCKED', 'The thread has started; choose a new thread to use another agent preset.', 409, error)
        }
        if (error.code === 'agent-preset/not-found' || error.code === 'agent-preset/invalid') {
          throw new AgUiGatewayError('PRESET_UNAVAILABLE', 'The requested agent preset cannot compose this thread.', 400, error)
        }
      }
      throw error
    }
  }

  /**
   * Reserve one run before accepting DSH input; HTTP callers serialize through {@link admit}.
   * @param input - validated AG-UI request.
   * @param digest - exact request-body digest.
   * @returns the sole active controller for this thread.
   */
  reserveRun(input: RunAgentInput, digest: string): RunController {
    this.assertLive()
    const existing = this.getRun(input.runId, digest)
    if (existing !== undefined) {
      throw new AgUiGatewayError(
        existing.state === 'active' ? 'RUN_IN_PROGRESS' : 'RUN_ALREADY_COMPLETED',
        existing.state === 'active' ? 'The AG-UI run is still active.' : 'The AG-UI run already completed.',
        409,
      )
    }
    if (this.activeRun !== undefined) {
      throw new AgUiGatewayError('RUN_IN_PROGRESS', 'This AG-UI thread already has an active run.', 409)
    }
    const controller = this.retainRun(input, digest)
    this.activeRun = controller
    return controller
  }

  /**
   * Start an admitted run after its SSE sink is attached.
   * @param controller - exact controller returned by {@link admit} or {@link reserveRun}; history runs retain their identity without reserving the Agent.
   */
  drive(controller: RunController): void {
    if (controller.record.state !== 'active' || this.runLedger.get(controller.input.runId) !== controller
      || (this.activeRun !== controller && (this.classifyMessages(controller.input).kind !== 'sync' || (controller.input.resume?.length ?? 0) !== 0))) {
      throw new AgUiGatewayError('RUN_NOT_ACTIVE', 'The AG-UI run lost its reservation.', 409)
    }
    controller.start()
    // a restarted thread reports its interrupted turn once, after its history, so the client can drop parked calls
    if (this.interrupted) {
      this.interrupted = false
      this.emitHistory(controller, [])
      controller.error('THREAD_INTERRUPTED', 'The AG-UI thread was interrupted by a restart; its pending frontend Tool calls are closed.')
      return
    }
    try {
      const admission = this.classifyMessages(controller.input)
      const resume = this.prepareResume(controller.input, admission.kind)
      if (admission.kind === 'sync' && resume?.turn === undefined) {
        resume?.apply()
        this.commitServerEchoes(admission.echoes)
        this.emitHistory(controller, [])
        this.finishHistory(controller)
        return
      }
      const props = controller.input.forwardedProps
      const metadata: unknown = isUnknownRecord(props) ? props.toolResultMetadata : undefined
      if (metadata !== undefined && (!isUnknownRecord(metadata) || !isJsonValue(metadata))) {
        throw new AgUiGatewayError('INVALID_TOOL_RESULT_METADATA', 'Configured Tool result metadata must be a JSON object.')
      }
      this.toolResultMetadata = metadata === undefined ? {} : structuredClone(metadata) as Record<string, JsonValue>
      this.a2uiRenderTool = a2uiRenderToolName(props)
      if (admission.kind === 'user') {
        this.assertUserRunReady()
        const text = admission.messages.flatMap(message => typeof message.content === 'string'
          ? [{ message, content: [{ type: 'text' as const, text: message.content }] }]
          : [])
        if (text.length === admission.messages.length) this.commitUserMessages(controller, text, admission.echoes)
        else void this.driveContentParts(controller, admission.messages, admission.echoes)
        return
      }

      if (admission.kind === 'action') {
        this.driveA2UIAction(controller, admission.action, admission.echoes)
        return
      }

      const tools = admission.kind === 'tools' ? admission.messages : []
      const turn = resume?.turn ?? this.continuationTurn(tools)
      for (const message of tools) {
        if (message.error === undefined && message.metadata !== undefined && !isJsonValue(message.metadata)) {
          throw new AgUiGatewayError('INVALID_TOOL_RESULT_METADATA', 'Frontend Tool result metadata must be lossless JSON.')
        }
      }
      this.emitHistory(controller, tools)
      /* v8 ignore next -- a continuation whose history snapshot overflowed the run budget is already settled; the user path covers the same guard. */
      if (controller.record.state !== 'active') return
      const baseline = this.prepareSharedState(controller.input)
      this.assertStateToolAvailable(baseline)
      this.prepareFrontendTools(controller.input.tools)
      controller.turn = turn
      this.stagedTools = controller.input.tools
      this.injectContext(controller.input, baseline)
      if (admission.kind === 'tools' && admission.action !== undefined) this.injectA2UIAction(admission.action)
      this.commitSharedStateBaseline(baseline)
      this.commitServerEchoes(admission.echoes)
      resume?.apply()
      for (const message of tools) {
        const pending = this.pendingCalls.get(message.toolCallId)
        /* v8 ignore next 3 -- continuationTurn synchronously verified the identical pending entries. */
        if (pending === undefined) {
          throw new AgUiGatewayError('UNKNOWN_TOOL_RESULT', 'The frontend Tool result has no pending call.', 409)
        }
        this.acceptedMessages.set(message.id, { role: 'tool', digest: frontendResultDigest(message) })
        this.projection.markAwaitingResult(message.toolCallId)
        if (message.error === undefined) {
          pending.resolve({
            content: message.content,
            presentationMeta: frontendResultMeta(message),
          })
        }
        else pending.reject(new Error(`Frontend Tool failed: ${message.error}`))
      }
      // a partial resolution leaves calls parked; finish so the client can answer the rest
      if (!this.finishWaitingRun() && this.pendingCalls.size !== 0) controller.success()
    } catch (error) {
      this.failRunAdmission(controller, error)
    }
  }

  private assertUserRunReady(): void {
    if (this.liveAgent.status !== 'idle' || this.pendingCalls.size !== 0) {
      throw new AgUiGatewayError('AGENT_BUSY', 'The thread Agent is not ready for a new user run.', 409)
    }
  }

  /**
   * Emit the durable transcript beside the messages this run has just
   * admitted; the DSH log records those only once the driver claims them
   * (user messages) or the parked call resolves (frontend Tool results).
   * A snapshot that left them out would make the client drop its copies.
   * @param accepted - new client user or Tool messages, in arrival order.
   */
  private emitHistory(controller: RunController, accepted: readonly (AgUiUserMessage | AgUiToolMessage)[]): void {
    const events = this.liveAgent.session.snapshotEvents()
    controller.emit({
      type: EventType.MESSAGES_SNAPSHOT,
      messages: [
        ...this.projection.messagesSnapshot(events, id => this.userMessageIds.get(id)),
        ...accepted.map(message => message.role === 'user'
          ? { id: message.id, role: 'user' as const, content: message.content }
          : { id: message.id, role: 'tool' as const, toolCallId: message.toolCallId, content: message.content }),
      ],
    })
    // the transcript's settled cards ride beside the snapshot, re-derived from the same durable log
    for (const view of this.projection.toolViewEvents(events)) controller.emit(view)
  }

  private async driveContentParts(controller: RunController, messages: readonly AgUiUserMessage[], echoes: readonly AgUiToolMessage[]): Promise<void> {
    try {
      const admitted = []
      for (const message of messages) {
        const receipts: FileUploadReceiptId[] = []
        const content = await this.admitUserContent(typeof message.content === 'string'
          ? [{ type: 'text', text: message.content }]
          : message.content as InputContent[], receipts)
        admitted.push({ message, content, receipts })
      }
      if (controller.record.state !== 'active') return
      this.commitUserMessages(controller, admitted, echoes)
    } catch (error) {
      this.failRunAdmission(controller, error)
    }
  }

  /** Queue every admitted user message into one DSH turn, in arrival order. */
  private commitUserMessages(
    controller: RunController,
    admitted: ReadonlyArray<{ message: AgUiUserMessage, content: AdmittedPromptContentPart[], receipts?: FileUploadReceiptId[] }>,
    echoes: readonly AgUiToolMessage[],
  ): void {
    const baseline = this.prepareSharedState(controller.input)
    this.assertStateToolAvailable(baseline)
    this.prepareFrontendTools(controller.input.tools)
    this.emitHistory(controller, admitted.map(item => item.message))
    // A snapshot that overflowed the run budget already settled the run.
    if (controller.record.state !== 'active') return
    this.applyFrontendTools(controller.input.tools)
    const durable = admitted.map(({ message: admission, content }) => freezeMessage({
      id: MessageId(durableUserId(admission.id)),
      role: 'user',
      content,
      source: typeof admission.content === 'string'
        ? { kind: 'user' as const, rpcId: durableUserId(admission.id) }
        : { kind: 'user' as const, rpcId: durableUserId(admission.id), agUiContent: admission.content },
    }))
    try {
      this.injectContext(controller.input, baseline)
      this.commitSharedStateBaseline(baseline)
      this.commitServerEchoes(echoes)
      // A turn claims one next-turn message plus all pending next-step messages.
      durable.forEach((message, index) => {
        const { message: admission, receipts = [] } = admitted[index]!
        controller.messageId = String(message.id)
        this.userMessageIds.set(String(message.id), admission.id)
        using binding = receipts.length === 0 ? undefined : this.fileUploads.bindPrompt(this.liveAgent, receipts, String(message.id))
        if (index < durable.length - 1) this.liveAgent.send(message, 'next-step', false)
        else this.liveAgent.followup(message)
        if (controller.record.state !== 'active') throw new Error('Native admission settled the AG-UI run')
        binding?.commit()
        this.acceptedMessages.set(admission.id, { role: 'user', digest: messageDigest(admission.id, admission.content) })
      })
    } catch (error) {
      // Native append may succeed before a notification throws. Cancel pending work,
      // then retain only messages already claimed into the durable transcript.
      this.liveAgent.cancel({ kind: 'hook', reason: 'AG-UI user admission failed' })
      const claimed = new Set(consumedMessages(this.liveAgent.session.snapshotEvents()).map(message => String(message.id)))
      for (const { message: admission } of admitted) {
        if (claimed.has(durableUserId(admission.id))) {
          this.acceptedMessages.set(admission.id, { role: 'user', digest: messageDigest(admission.id, admission.content) })
        } else this.acceptedMessages.delete(admission.id)
      }
      throw error
    }
  }

  private async admitUserContent(content: InputContent[], receipts: FileUploadReceiptId[]): Promise<AdmittedPromptContentPart[]> {
    if (content.filter(part => part.type !== 'text').length > this.options.maxFilesPerMessage) {
      throw new AgUiGatewayError('FILE_LIMIT_EXCEEDED', 'The user message contains too many non-text content parts.', 413)
    }
    const prompt: AttachmentAdmissionPart[] = []
    for (const part of content) {
      if (part.type === 'text') {
        prompt.push({ type: 'text', text: part.text })
      } else if (part.type === 'binary' || part.source.type !== 'url') {
        // only references round-trip through MESSAGES_SNAPSHOT unchanged; inline bytes belong in a thread file
        throw new AgUiGatewayError('UNSUPPORTED_CONTENT_PART', 'Only text parts and thread file URLs are accepted; upload the file to the thread first.')
      } else {
        prompt.push(await this.admitFilePart(part, receipts))
      }
    }
    if (prompt.every(part => part.type === 'text')) return prompt
    const attachments = this.attachments
    const attachment = await import('@deepseek-ai/dsh-attachment')
    try {
      return await attachments.admitPromptContent(prompt)
    } catch (error) {
      if (error instanceof attachment.AttachmentError) {
        throw new AgUiGatewayError(error.code, error.message, 400, error)
      }
      throw error
    }
  }

  /** Official service, optional for hosts that only accept text. */
  private get fileUploads(): FileUploads {
    const uploads = this.ctx.get('fileUploads')
    if (uploads === undefined) throw new AgUiGatewayError('FILES_UNSUPPORTED', 'This Host does not provide native file uploads.', 409)
    return uploads
  }

  private get attachments(): AttachmentStore {
    const attachments = this.ctx.get('attachments')
    if (attachments === undefined) throw new AgUiGatewayError('FILES_UNSUPPORTED', 'This Host does not provide attachment storage.', 409)
    return attachments
  }

  async uploadFile(data: AsyncIterable<Uint8Array>, name: string, signal?: AbortSignal): Promise<FileUploadValue> {
    const uploads = this.fileUploads
    using _activity = this.holdFileActivity()
    return await uploads.uploadStream({ sessionId: this.sessionId, data, name, ...(signal === undefined ? {} : { signal }) })
  }

  fileUrl(path: string, upload: FileUploadValue): string {
    if (this.options.fileSecret === undefined) throw new Error('ag-ui: file URL signing is not configured')
    return signedFileUrl(path, this.identity.threadId, String(this.sessionId), this.options.fileSecret, upload)
  }

  fileFromUrl(value: string): FileUploadValue {
    if (this.options.fileSecret === undefined) throw new AgUiGatewayError('FILE_NOT_FOUND', 'The requested file was not found.', 404)
    return verifiedFileUrl(value, this.identity.threadId, String(this.sessionId), this.options.fileSecret)
  }

  async *readFile(file: FileAttachmentRef): AsyncIterable<Uint8Array> {
    const attachments = this.attachments
    using _activity = this.holdFileActivity()
    yield* attachments.readFileStream(file)
  }

  /** Read only a file declared in this exact Session, using its scoped native filesystem. */
  async readDeliverable(seq: number, index: number, maxBytes: number, signal: AbortSignal): Promise<{ path: string, bytes: Uint8Array }> {
    using _activity = this.holdFileActivity()
    const agent = this.liveAgent
    const event = agent.session.snapshotEvents().find(event => event.seq === seq)
    const file = event !== undefined && isPresentedEvent(event) ? event.data.files[index] : undefined
    const missing = (): AgUiGatewayError => new AgUiGatewayError('FILE_NOT_FOUND', 'The presented file was not found.', 404)
    if (file === undefined) throw missing()
    const fs = this.ctx.get('agentPresets')?.serviceFor(agent, 'fs') ?? agent.ctx.get('fs')
    const cwd = agent.session.header.cwd
    if (fs === undefined || cwd === undefined) {
      throw new AgUiGatewayError('FILES_UNSUPPORTED', 'This Session does not provide a workspace filesystem.', 409)
    }
    try {
      signal.throwIfAborted()
      const entry = await fs.lstat(file.path, { cwd }, signal)
      if (entry !== undefined && entry.type !== 'file') throw missing()
      const target = await fs.resolve(file.path, { cwd, signal })
      const info = await fs.stat(target, signal)
      if (info === undefined || info.type !== 'file') throw missing()
      if (info.size !== undefined && info.size > maxBytes) {
        throw new AgUiGatewayError('FILE_TOO_LARGE', 'The presented file exceeds its byte limit.', 413)
      }
      const bytes = await fs.readBytes(target, signal, maxBytes)
      signal.throwIfAborted()
      return { path: file.path, bytes }
    } catch (error) {
      if (error instanceof Error && 'code' in error) {
        if (error.code === 'FS_NOT_FOUND' || error.code === 'FS_NOT_REGULAR_FILE') throw missing()
        if (error.code === 'FS_TOO_LARGE') throw new AgUiGatewayError('FILE_TOO_LARGE', 'The presented file exceeds its byte limit.', 413, error)
        if (error.code === 'FS_PERMISSION_DENIED' || error.code === 'FS_SANDBOX_DENIED') throw new AgUiGatewayError('FILE_ACCESS_DENIED', 'The Session filesystem denied this read.', 403, error)
      }
      throw error
    }
  }

  /** Keep the native Session and its receipts alive until every concurrent file operation settles. */
  private holdFileActivity(): Disposable {
    this.assertLive()
    this.activeFileOperations += 1
    this.clearIdleExpiry()
    return {
      [Symbol.dispose]: () => {
        this.activeFileOperations -= 1
        this.scheduleIdleExpiry()
      },
    }
  }

  private async admitFilePart(part: Exclude<InputContent, { type: 'text' | 'binary' }>, receipts: FileUploadReceiptId[]): Promise<AttachmentAdmissionPart> {
    const upload = this.fileFromUrl(part.source.value)
    if (this.fileUploads.resolve(this.liveAgent, upload.receiptId) === undefined) {
      throw new AgUiGatewayError('FILE_NOT_STAGED', 'Upload the file again before attaching it to a new prompt.', 400)
    }
    receipts.push(upload.receiptId)
    const mediaType = part.source.mimeType ?? 'application/octet-stream'
    if (part.type === 'image' || isImageMediaType(mediaType)) {
      if (!isImageMediaType(mediaType)) throw new AgUiGatewayError('UNSUPPORTED_MEDIA_TYPE', 'The image media type is not supported.')
      if (upload.file.bytes > this.attachments.imageLimits.maxImageBytes) {
        throw new AgUiGatewayError('ATTACHMENT_TOO_LARGE', 'The image exceeds its byte limit.', 413)
      }
      const chunks: Uint8Array[] = []
      for await (const chunk of this.readFile(upload.file)) chunks.push(chunk)
      return { type: 'image', mediaType, data: Buffer.concat(chunks).toString('base64'), name: upload.file.name }
    }
    return { type: 'file', attachment: upload.file }
  }

  private failRunAdmission(controller: RunController, error: unknown): void {
    const failure = error instanceof AgUiGatewayError ? error : new AgUiGatewayError('AGENT_EXECUTION_ERROR', 'The AG-UI run could not start.', 500, error)
    controller.error(failure.code, failure.message)
    const terminal = controller.record.events.at(-1)!
    if (terminal.code !== 'AG_UI_EVENT_BUFFER_OVERFLOW' && this.activeRun === controller
      && controller.turn !== undefined && this.liveAgent.status === 'running') {
      this.liveAgent.cancel({ kind: 'hook', reason: `AG-UI run admission failed: ${failure.code}` })
    }
  }

  /**
   * Settle the disconnected run and cancel only its owned Agent work.
   * @param controller - disconnected controller; stale controllers are ignored.
   */
  disconnect(controller: RunController): void {
    if (this.runLedger.get(controller.input.runId) !== controller || controller.record.state !== 'active') return
    // An unopened response has no replayable run; retries must start with RUN_STARTED.
    if (controller.record.events.length === 0) this.runLedger.delete(controller.input.runId)
    controller.error('CLIENT_DISCONNECTED', 'The AG-UI client disconnected before the run completed.')
    if (this.activeRun === controller && this.liveAgent.status === 'running') {
      this.liveAgent.cancel({ kind: 'hook', reason: 'AG-UI client disconnected' })
    }
  }

  /** Reject pending calls and dispose the owned Agent to quiescence. */
  async dispose(): Promise<void> {
    if (this.disposed) return
    this.disposed = true
    this.clearIdleExpiry()
    this.interrupts.cancel()
    for (const controller of this.runLedger.values()) {
      controller.error('AGENT_NOT_AVAILABLE', 'The AG-UI thread was disposed.')
    }
    for (const pending of this.pendingCalls.values()) {
      pending.reject(new Error('AG-UI thread disposed'))
    }
    this.pendingCalls.clear()
    this.stateToolDispose?.()
    this.stateToolDispose = undefined
    this.projection.sharedState = undefined
    this.sharedStateActive = false
    for (const registration of this.frontendTools.values()) registration.dispose()
    this.frontendTools.clear()
    const handle = this.handle
    this.handle = undefined
    /* v8 ignore next -- initialized live bindings own a handle; repeated disposal returned above. */
    if (handle !== undefined) await handle.dispose()
  }

  /** Retain each HTTP run under the same bounds, independently of native turn ownership. */
  private retainRun(input: RunAgentInput, digest: string): RunController {
    this.evictCompletedRuns()
    if (this.runLedger.size >= this.options.maxRunsPerThread) {
      throw new AgUiGatewayError('RUN_LEDGER_FULL', 'The AG-UI thread run ledger is full.', 429)
    }
    const record: RunRecord = { digest, events: [], state: 'active', bytes: 0 }
    const controller = new RunController(input, record, this.options.maxRunEvents, this.options.maxRunEventBytes, owner => {
      if (this.activeRun === owner && owner.turn !== undefined && this.agent?.status === 'running') {
        this.agent.cancel({ kind: 'hook', reason: 'AG-UI run event buffer overflow' })
      }
    })
    this.runLedger.set(input.runId, controller)
    this.clearIdleExpiry()
    void controller.done.then(() => {
      if (this.activeRun === controller) this.activeRun = undefined
      this.scheduleIdleExpiry()
    })
    return controller
  }

  private assertLive(): void {
    if (this.disposed || this.handle === undefined) {
      throw new AgUiGatewayError('AGENT_NOT_AVAILABLE', 'The AG-UI thread Agent is unavailable.', 410)
    }
  }

  /** Sort a run's new messages: user messages open a turn, Tool results continue one, none at all only synchronizes history. */
  private classifyMessages(input: RunAgentInput):
    | { kind: 'sync'; echoes: AgUiToolMessage[] }
    | { kind: 'user'; messages: AgUiUserMessage[]; echoes: AgUiToolMessage[] }
    | { kind: 'action'; action: A2UIActionContinuation; echoes: AgUiToolMessage[] }
    | { kind: 'tools'; messages: AgUiToolMessage[]; action?: A2UIActionContinuation; echoes: AgUiToolMessage[] } {
    const continuation = a2uiActionContinuation(input)
    const action = continuation === undefined ? undefined : this.pendingA2UIAction(continuation)
    const users: AgUiUserMessage[] = []
    const tools: AgUiToolMessage[] = []
    const echoes: AgUiToolMessage[] = []
    const ids = new Set<string>()
    const callIds = new Set<string>()
    for (const message of input.messages) {
      if (message.role !== 'user' && message.role !== 'tool') continue
      if (ids.has(message.id)) throw new AgUiGatewayError('INVALID_MESSAGE_BATCH', 'Message ids must be unique within a run.')
      ids.add(message.id)
      const digest = message.role === 'user' ? messageDigest(message.id, message.content) : frontendResultDigest(message)
      const accepted = this.acceptedMessages.get(message.id)
      if (accepted !== undefined) {
        if (accepted.role !== message.role || accepted.digest !== digest) {
          throw new AgUiGatewayError('MESSAGE_ID_CONFLICT', 'A message id was reused with different content.', 409)
        }
        continue
      }
      if (message.role === 'tool') {
        if (callIds.has(message.toolCallId)) throw new AgUiGatewayError('INVALID_TOOL_RESULT_BATCH', 'A Tool call must be answered once.')
        callIds.add(message.toolCallId)
        if (continuation?.result.id === message.id) continue
        if (this.pendingCalls.has(message.toolCallId)) tools.push(message)
        else if (this.projection.hasServerResult(message.toolCallId)) {
          echoes.push(message)
        } else {
          throw new AgUiGatewayError('UNKNOWN_TOOL_RESULT', 'The Tool result has no pending or completed server call.', 409)
        }
      } else {
        users.push(message)
      }
    }
    if (users.length > 0 && tools.length > 0) {
      throw new AgUiGatewayError('INVALID_MESSAGE_BATCH', 'A run cannot mix new user messages with new frontend Tool results.')
    }
    if (users.length > 0 && action !== undefined) {
      throw new AgUiGatewayError('INVALID_MESSAGE_BATCH', 'A run cannot mix new user messages with an A2UI user action.')
    }
    if (users.length > 0) return { kind: 'user', messages: users, echoes }
    if (tools.length > 0) return { kind: 'tools', messages: tools, echoes, ...(action === undefined ? {} : { action }) }
    if (action !== undefined) return { kind: 'action', action, echoes }
    return { kind: 'sync', echoes }
  }

  private commitServerEchoes(echoes: readonly AgUiToolMessage[]): void {
    for (const echo of echoes) {
      this.projection.consumeServerResult(echo.toolCallId)
      this.acceptedMessages.set(echo.id, { role: 'tool', digest: frontendResultDigest(echo) })
    }
  }

  /** Start a new DSH turn for one validated middleware user action. */
  private driveA2UIAction(controller: RunController, action: A2UIActionContinuation, echoes: readonly AgUiToolMessage[]): void {
    this.assertUserRunReady()
    this.emitHistory(controller, [])
    /* v8 ignore next -- the shared history-budget tests cover this guard; the action path reuses the same controller settlement. */
    if (controller.record.state !== 'active') return
    const baseline = this.prepareSharedState(controller.input)
    this.assertStateToolAvailable(baseline)
    this.applyFrontendTools(controller.input.tools)
    const message = this.a2uiActionMessage(action)
    try {
      this.injectContext(controller.input, baseline)
      this.commitSharedStateBaseline(baseline)
      this.commitServerEchoes(echoes)
      controller.messageId = String(message.id)
      this.liveAgent.followup(message)
      if (controller.record.state !== 'active') throw new Error('Native admission settled the AG-UI run')
    } catch (error) {
      // A durable append can succeed before an inbox notification throws.
      this.liveAgent.cancel({ kind: 'hook', reason: 'AG-UI action admission failed' })
      throw error
    }
  }

  /** Add an action to the next step of the still-open render turn. */
  private injectA2UIAction(action: A2UIActionContinuation): void {
    this.liveAgent.inject(this.a2uiActionMessage(action))
  }

  /** Native inbox and consumed input own action admission, including after restart. */
  private pendingA2UIAction(action: A2UIActionContinuation): A2UIActionContinuation | undefined {
    const message = this.a2uiActionMessage(action)
    const accepted = [
      ...this.liveAgent.inbox.nextTurn,
      ...this.liveAgent.inbox.nextStep,
      ...consumedMessages(this.liveAgent.session.snapshotEvents()),
    ].find(candidate => candidate.id === message.id)
    if (accepted === undefined) return action
    if (!isDeepStrictEqual(accepted, message)) {
      throw new AgUiGatewayError('MESSAGE_ID_CONFLICT', 'An A2UI action id was reused with different content.', 409)
    }
    return undefined
  }

  /** Materialize one action as durable DSH plugin context with its producer identity. */
  private a2uiActionMessage(action: A2UIActionContinuation): UserMessage {
    return freezeMessage({
      id: MessageId(`ag-ui:a2ui:${action.result.id}`),
      role: 'user',
      // forwardedProps is already bounded at HTTP admission; keep its complete validated action in durable model context
      content: [{
        type: 'text',
        text: `${action.result.content}\n\nA2UI user action JSON: ${canonicalJsonStringify(action.action)}`,
      }],
      source: {
        kind: 'ag-ui',
        form: 'notice',
        summary: 'A2UI user action',
      },
    })
  }

  /** Validate human responses without consuming answers or accepted message identities. */
  private prepareResume(input: RunAgentInput, kind: ReturnType<ThreadBinding['classifyMessages']>['kind']): PreparedResume | undefined {
    const hasResume = (input.resume?.length ?? 0) !== 0
    if (hasResume && kind !== 'sync' && kind !== 'tools') {
      throw new AgUiGatewayError('INVALID_MESSAGE_BATCH', 'A run cannot mix user messages and interrupt responses.')
    }
    if (!hasResume && this.interrupts.visible.length !== 0 && kind !== 'sync') {
      throw new AgUiGatewayError('INCOMPLETE_INTERRUPT_RESPONSE', 'Answer the pending interrupts before continuing the turn.', 409)
    }
    return hasResume ? this.interrupts.prepare(input.resume!) : undefined
  }

  /** A readonly history request repeats exactly the previously published questions. */
  private finishHistory(controller: RunController): void {
    if (this.sharedStateActive) controller.emit({ type: EventType.STATE_SNAPSHOT, snapshot: structuredClone(this.projection.sharedState) })
    const interrupts = this.interrupts.publish()
    if (interrupts.length !== 0) controller.interrupt(interrupts)
    else controller.success()
  }

  /** Approval can suspend scheduler prepare, so it must not wait for later tools to start. */
  private finishWaitingRun(): boolean {
    const active = this.activeRun
    if (active === undefined || active.record.state !== 'active' || active.turn !== this.nativeTurn || !this.interrupts.waiting) return false
    const interrupts = this.interrupts.publish()
    this.emitFinalSnapshot(active)
    active.interrupt(interrupts)
    return true
  }

  private continuationTurn(messages: AgUiToolMessage[]): number {
    let turn: number | undefined
    for (const message of messages) {
      const pending = this.pendingCalls.get(message.toolCallId)
      if (pending === undefined) {
        throw new AgUiGatewayError('UNKNOWN_TOOL_RESULT', 'The frontend Tool result has no pending call.', 409)
      }
      if (turn !== undefined && pending.turn !== turn) {
        throw new AgUiGatewayError('INVALID_TOOL_RESULT_BATCH', 'Frontend Tool results belong to different DSH turns.', 409)
      }
      turn = pending.turn
    }
    if (turn === undefined) throw new AgUiGatewayError('INVALID_TOOL_RESULT_BATCH', 'No frontend Tool result was supplied.')
    return turn
  }

  private injectContext(input: RunAgentInput, baseline: SharedStateBaseline): void {
    const sections = input.context.map(item => ({ name: item.description, text: item.value }))
    if (baseline.active) {
      sections.push({
        name: 'Current Shared State',
        text: `${JSON.stringify(baseline.value)}\n\nTo update this state, call ${STATE_TOOL_NAME} with a state_updates object.`,
      })
    }
    if (sections.length === 0) return
    const text = sections.map(section => `## ${section.name}\n${section.text}`).join('\n\n')
    this.liveAgent.inject(createUserMessage({
      content: [{ type: 'text', text }],
      source: { kind: 'ag-ui', form: 'snapshot', sections },
    }))
  }

  private prepareSharedState(input: RunAgentInput): SharedStateBaseline {
    if (!this.sharedStateActive
      && (input.state === undefined || input.state === null || isEmptyStateContainer(input.state))) {
      return { active: false, value: undefined }
    }
    const value = input.state === undefined ? this.projection.sharedState : structuredClone(input.state)
    if (jsonBytes(value, 'state') > this.options.maxStateBytes) {
      throw new AgUiGatewayError('STATE_LIMIT_EXCEEDED', 'state exceeds its limit.', 413)
    }
    const active = this.activeRun
    /* v8 ignore next -- prepareSharedState runs only while drive owns the active controller. */
    if (active === undefined) throw new Error('Shared state has no active AG-UI run')
    active.assertCanEmit({ type: EventType.STATE_SNAPSHOT, snapshot: value })
    return { active: true, value }
  }

  private assertStateToolAvailable(baseline: SharedStateBaseline): void {
    if (!baseline.active) return
    const global = this.ctx.tools.get(STATE_TOOL_NAME)
    const inherited = this.stateToolDispose === undefined
      ? this.ctx.tools.get(STATE_TOOL_NAME, this.liveAgent)
      : undefined
    if (global !== undefined || inherited !== undefined) {
      throw new AgUiGatewayError(
        'SHARED_STATE_TOOL_COLLISION',
        `The reserved shared-state Tool ${STATE_TOOL_NAME} collides with an inherited Tool.`,
        409,
      )
    }
  }

  private commitSharedStateBaseline(baseline: SharedStateBaseline): void {
    if (!baseline.active) return
    const active = this.activeRun
    /* v8 ignore next -- run admission owns the active controller through baseline commit. */
    if (active === undefined) throw new Error('Shared state has no active AG-UI run')
    this.ensureStateTool()
    this.projection.sharedState = structuredClone(baseline.value)
    this.sharedStateActive = true
    active.emit({ type: EventType.STATE_SNAPSHOT, snapshot: structuredClone(baseline.value) })
  }

  private ensureStateTool(): void {
    if (this.stateToolDispose !== undefined) return
    const definition: ToolDefinition = {
      name: STATE_TOOL_NAME,
      description: 'Shallow-merge top-level fields into shared application state. Omitted top-level keys remain; supplied nested values replace their previous values.',
      parameters: {
        type: 'object',
        properties: {
          state_updates: { type: 'object', additionalProperties: true },
        },
        required: ['state_updates'],
        additionalProperties: false,
      },
      output: {
        schema: { type: 'string' },
        render(_args, value) {
          return [{ type: 'text', text: typeof value === 'string' ? value : JSON.stringify(value) }]
        },
      },
      presentCall: args => ({ card: 'generic', title: 'Update shared state', rawInput: args }),
      isConcurrencySafe: () => true,
      execute: (args, exec) => Promise.resolve(this.prepareSharedStateUpdate(args, exec)),
    }
    this.stateToolDispose = this.liveAgent.ctx.tools.register(definition)
  }

  private prepareSharedStateUpdate(args: unknown, exec: ToolRunContext): string {
    if (!this.sharedStateActive) throw new Error('Shared state is not active for this AG-UI thread')
    const callId = String(exec.callId)
    const lifecycle = this.projection.lifecycleOf(callId)
    if (lifecycle?.kind !== 'state' || lifecycle.turn !== this.nativeTurn) throw new Error('Shared-state update has no DSH call position')
    if (lifecycle.commit !== undefined) throw new Error('Shared-state update is already pending')
    const updates = readStateUpdates(args)
    const current = this.projection.sharedState
    const next = isUnknownRecord(current)
      ? { ...current, ...updates }
      : { ...updates }
    if (jsonBytes(next, 'state') > this.options.maxStateBytes) {
      throw new Error('Shared-state update exceeds the configured state byte limit')
    }
    const changed = !isDeepStrictEqual(next, current)
    const active = this.activeRun
    // A native turn may outlive its HTTP response; only a live response has a wire budget.
    if (changed && active?.record.state === 'active' && active.turn === lifecycle.turn) {
      active.assertCanEmit({ type: EventType.STATE_SNAPSHOT, snapshot: next })
    }
    this.projection.stageCommit(callId, { value: structuredClone(next), changed })
    return JSON.stringify({ status: changed ? 'updated' : 'unchanged', state: next })
  }

  private prepareFrontendTools(tools: AgUiTool[]): PreparedFrontendTool[] {
    const prepared: PreparedFrontendTool[] = []
    const names = new Set<string>()
    for (const tool of tools) {
      if (!FRONTEND_TOOL_NAME.test(tool.name)) {
        throw new AgUiGatewayError('INVALID_FRONTEND_TOOL_NAME', 'Frontend Tool names must use a supported ASCII identifier.')
      }
      if (tool.name === STATE_TOOL_NAME) {
        throw new AgUiGatewayError('RESERVED_FRONTEND_TOOL_NAME', `${STATE_TOOL_NAME} is reserved for shared state.`)
      }
      if (names.has(tool.name)) throw new AgUiGatewayError('DUPLICATE_FRONTEND_TOOL', 'Frontend Tool names must be unique.')
      names.add(tool.name)
      assertObjectJsonSchema(tool.parameters)
      const schema = structuredClone(tool.parameters) as ObjectJsonSchema & Record<string, unknown>
      const fingerprint = valueDigest({ name: tool.name, description: tool.description, parameters: schema })
      const own = this.frontendTools.get(tool.name)
      if (own === undefined && this.ctx.tools.get(tool.name, this.liveAgent) !== undefined) {
        throw new AgUiGatewayError('FRONTEND_TOOL_NAME_COLLISION', `Frontend Tool ${tool.name} collides with an inherited Tool.`, 409)
      }
      prepared.push({ tool, fingerprint, schema })
    }
    return prepared
  }

  private applyFrontendTools(tools: AgUiTool[]): void {
    const prepared = this.prepareFrontendTools(tools)
    const incoming = new Map(prepared.map(item => [item.tool.name, item]))
    for (const [name, registration] of this.frontendTools) {
      const next = incoming.get(name)
      if (next !== undefined && next.fingerprint === registration.fingerprint) continue
      registration.dispose()
      this.frontendTools.delete(name)
    }
    for (const item of prepared) {
      if (this.frontendTools.has(item.tool.name)) continue
      const definition = this.definitionFor(item)
      const dispose = this.liveAgent.ctx.tools.register(definition)
      this.frontendTools.set(item.tool.name, {
        dispose,
        fingerprint: item.fingerprint,
      })
    }
  }

  private definitionFor(item: PreparedFrontendTool): ToolDefinition {
    return {
      name: item.tool.name,
      description: item.tool.description,
      parameters: item.schema,
      output: {
        schema: {
          type: 'object',
          properties: {
            content: { type: 'string' },
            presentationMeta: { type: 'object', additionalProperties: true },
          },
          required: ['content'],
          additionalProperties: false,
        },
        render(_args, value) {
          const result = value as FrontendToolResultValue
          return [{ type: 'text', text: result.content }]
        },
        presentationMeta(_args, value) {
          const result = value as FrontendToolResultValue
          return result.presentationMeta ?? null
        },
      },
      presentCall: args => ({ card: 'generic', title: item.tool.description, rawInput: args }),
      // parking holds no server-side resource, so calls of one step may overlap
      isConcurrencySafe: () => true,
      execute: (args, exec) => item.tool.name === this.a2uiRenderTool
        ? settleA2UIRender(item.schema, args, this.toolResultMetadata[item.tool.name])
        : this.parkFrontendTool(item.tool.name, item.schema, args, exec),
    }
  }

  private parkFrontendTool(
    name: string,
    schema: ObjectJsonSchema,
    args: unknown,
    exec: ToolRunContext,
  ): Promise<FrontendToolResultValue> {
    assertFrontendToolArgs(schema, args)
    const callId = String(exec.callId)
    const lifecycle = this.projection.lifecycleOf(callId)
    if (lifecycle?.kind !== 'backend' || lifecycle.name !== name || lifecycle.turn !== this.nativeTurn) throw new Error('Frontend Tool call has no DSH call position')
    const active = this.activeRun
    this.projection.markParked(callId, lifecycle)

    const deferred = Promise.withResolvers<FrontendToolResultValue>()
    let settled = false
    const settle = (operation: () => void): void => {
      /* v8 ignore next -- late timeout, abort, or browser completion is an idempotent no-op. */
      if (settled) return
      settled = true
      clearTimeout(timer)
      exec.signal.removeEventListener('abort', onAbort)
      this.pendingCalls.delete(callId)
      operation()
      if (this.activeRun === undefined && this.pendingCalls.size === 0) this.scheduleIdleExpiry()
    }
    const pending: PendingFrontendCall = {
      turn: lifecycle.turn,
      resolve: (value) => { settle(() => { deferred.resolve(value) }) },
      reject: (error) => { settle(() => { deferred.reject(error) }) },
    }
    const onAbort = (): void => { pending.reject(new Error('Frontend Tool call aborted')) }
    const timer = setTimeout(() => {
      pending.reject(new Error('Frontend Tool result timed out'))
      /* v8 ignore next -- a pending Tool Promise keeps its owning Agent turn running until settlement. */
      if (this.liveAgent.status === 'running') {
        this.liveAgent.cancel({ kind: 'hook', reason: 'AG-UI frontend Tool timeout' })
      }
    }, this.options.frontendToolTimeoutMs)
    exec.signal.addEventListener('abort', onAbort, { once: true })
    this.pendingCalls.set(callId, pending)
    this.clearIdleExpiry()
    if (active?.record.state === 'active' && active.turn === lifecycle.turn
      && this.projection.parkSettleReady(lifecycle.turn, lifecycle.step, this.startsWhileParked)) {
      this.emitFinalSnapshot(active)
      active.success()
    }
    return deferred.promise
  }

  private onSessionEvent(event: SessionEvent): void {
    const active = this.activeRun
    const ownsTurn = active?.record.state === 'active' && active.turn !== undefined && active.turn === this.nativeTurn
    const step = this.projection.project(event, this.nativeTurn)
    if (event.type === 'step/end' && this.stagedTools !== undefined && this.nativeTurn === event.data.turn) {
      const staged = this.stagedTools
      this.stagedTools = undefined
      try {
        this.applyFrontendTools(staged)
      } catch (error) {
        if (ownsTurn) active.error('FRONTEND_TOOL_SYNC_FAILED', 'The frontend Tool set could not be updated.')
        this.liveAgent.cancel({ kind: 'hook', reason: `AG-UI frontend Tool sync failed: ${errorChain(error)}` })
      }
    }
    if (step.outcome !== undefined) {
      this.nativeTurn = undefined
      this.interrupts.cancel()
      this.scheduleIdleExpiry()
    }
    if (!ownsTurn) return
    if (step.outcome !== undefined) {
      // This durable turn is over; a large final snapshot must not cancel a later turn.
      active.turn = undefined
      this.emitFinalSnapshot(active)
      if (step.outcome.kind === 'success') active.success()
      else active.error(step.outcome.code, step.outcome.message)
      return
    }
    for (const wireEvent of step.events) active.emit(wireEvent)
    // a server call completing the announced set settles a run parked earlier;
    // a frontend call settles at its own park instead
    if (event.type === 'tool/call'
      && this.projection.parkSettleReady(event.data.turn, event.data.step, this.startsWhileParked)) {
      this.emitFinalSnapshot(active)
      active.success()
    }
  }

  private emitFinalSnapshot(controller: RunController): void {
    controller.emit({
      type: EventType.MESSAGES_SNAPSHOT,
      messages: this.projection.messagesSnapshot(this.liveAgent.session.snapshotEvents(), id => this.userMessageIds.get(id)),
    })
  }

  private onAgentError(error: unknown): void {
    const active = this.activeRun
    if (active?.record.state !== 'active') return
    // A dispatched user message owns startup errors even before its first inbox claim.
    if (active.turn === undefined ? active.messageId === undefined : active.turn !== this.nativeTurn) return
    this.emitFinalSnapshot(active)
    active.error('AGENT_EXECUTION_ERROR', errorChain(error))
  }

  private checkGlobalCollisions(): void {
    if (this.disposed) return
    if (this.stateToolDispose !== undefined && this.ctx.tools.get(STATE_TOOL_NAME) !== undefined) {
      this.activeRun?.error(
        'SHARED_STATE_TOOL_COLLISION',
        `The reserved shared-state Tool ${STATE_TOOL_NAME} now collides with a global Tool.`,
      )
      if (this.agent?.status === 'running') {
        this.agent.cancel({ kind: 'hook', reason: `AG-UI shared-state Tool ${STATE_TOOL_NAME} collided with a global Tool` })
      }
      return
    }
    for (const name of this.frontendTools.keys()) {
      if (this.ctx.tools.get(name) === undefined) continue
      this.activeRun?.error('FRONTEND_TOOL_NAME_COLLISION', `Frontend Tool ${name} now collides with a global Tool.`)
      if (this.agent?.status === 'running') {
        this.agent.cancel({ kind: 'hook', reason: `AG-UI frontend Tool ${name} collided with a global Tool` })
      }
      return
    }
  }

  private evictCompletedRuns(): void {
    for (const [runId, controller] of this.runLedger) {
      if (this.runLedger.size < this.options.maxRunsPerThread) break
      if (controller.record.state === 'completed') this.runLedger.delete(runId)
    }
  }

  private clearIdleExpiry(): void {
    if (this.idleTimer === undefined) return
    clearTimeout(this.idleTimer)
    this.idleTimer = undefined
  }

  private scheduleIdleExpiry(): void {
    this.clearIdleExpiry()
    if (this.disposed || this.interrupts.waiting || this.activeFileOperations !== 0 || this.nativeTurn !== undefined || this.pendingCalls.size !== 0 || this.activeRun !== undefined || this.waitingRuns !== 0
      || [...this.runLedger.values()].some(controller => controller.record.state === 'active')) return
    this.idleTimer = setTimeout(() => { this.onExpired(this) }, this.options.threadIdleMs)
  }
}

/** Ignore default empty client state until a thread has activated shared state. */
function isEmptyStateContainer(value: unknown): boolean {
  if (Array.isArray(value)) return value.length === 0
  return isUnknownRecord(value) && Object.keys(value).length === 0
}

/** Digest one accepted user message in a fixed field order, stable across cold resume. */
function messageDigest(clientId: string, content: AgUiUserMessage['content']): string {
  return valueDigest({ id: clientId, role: 'user', content })
}

/** Resolve the optional host workspace registry without requiring the package. */
function workspaceRegistryOf(ctx: Context): WorkspaceRegistryLike | undefined {
  return (ctx as Context & { get(name: string): unknown }).get('workspaceRegistry') as WorkspaceRegistryLike | undefined
}

/** Narrow a JSON object without accepting arrays or null. */
function isUnknownRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value)
}

function assertFrontendToolArgs(schema: ObjectJsonSchema, args: unknown): void {
  const violations = validateJsonSchemaValue(schema, args, '')
  if (violations.length > 0) throw new Error(`Invalid frontend Tool arguments: ${violations.join('; ')}`)
}

/** Answer a middleware-injected render call at once: the middleware renders from the streamed arguments and never sends a browser result. */
function settleA2UIRender(schema: ObjectJsonSchema, args: unknown, presentationMeta: JsonValue | undefined): Promise<FrontendToolResultValue> {
  assertFrontendToolArgs(schema, args)
  return Promise.resolve({ content: A2UI_RENDERED_RESULT, ...(presentationMeta === undefined ? {} : { presentationMeta }) })
}

/** Name of the render Tool A2UIMiddleware flags in forwardedProps; `true` selects its default name. */
function a2uiRenderToolName(forwardedProps: RunAgentInput['forwardedProps']): string | undefined {
  if (!isUnknownRecord(forwardedProps) || !Object.hasOwn(forwardedProps, 'injectA2UITool')) return undefined
  const value = forwardedProps.injectA2UITool
  if (value === true) return A2UI_RENDER_TOOL_NAME
  return typeof value === 'string' ? value : undefined
}

/** Validate the exact synthetic pair appended by the official A2UI middleware. */
function a2uiActionContinuation(input: RunAgentInput): A2UIActionContinuation | undefined {
  const action = readA2UIUserAction(input.forwardedProps)
  if (action === undefined) return undefined
  const assistant = input.messages.at(-2)
  const result = input.messages.at(-1)
  const call = assistant?.role === 'assistant' && assistant.toolCalls?.length === 1
    ? assistant.toolCalls[0]
    : undefined
  if (assistant?.role !== 'assistant'
    || assistant.content !== ''
    || call?.type !== 'function'
    || call.function.name !== A2UI_ACTION_TOOL_NAME
    || result?.role !== 'tool'
    || result.toolCallId !== call.id) {
    throw new AgUiGatewayError(
      'INVALID_A2UI_ACTION',
      'The A2UI user action is missing its official synthetic Tool-call pair.',
    )
  }
  let argumentsValue: unknown
  try {
    argumentsValue = JSON.parse(call.function.arguments)
  } catch (error) {
    throw new AgUiGatewayError('INVALID_A2UI_ACTION', 'The A2UI user action arguments are invalid.', 400, error)
  }
  if (!isDeepStrictEqual(argumentsValue, action) || result.content !== formatA2UIActionResult(action)) {
    throw new AgUiGatewayError('INVALID_A2UI_ACTION', 'The A2UI user action does not match its synthetic Tool-call pair.')
  }
  return { action, result }
}

/** Read the bounded user-action shape carried in forwardedProps by A2UIMiddleware. */
function readA2UIUserAction(forwardedProps: RunAgentInput['forwardedProps']): A2UIUserAction | undefined {
  if (!isUnknownRecord(forwardedProps) || !Object.hasOwn(forwardedProps, 'a2uiAction')) return undefined
  const envelope = forwardedProps.a2uiAction
  if (!isUnknownRecord(envelope)
    || !Object.hasOwn(envelope, 'userAction')
    || Object.keys(envelope).some(key => key !== 'userAction')) {
    throw new AgUiGatewayError('INVALID_A2UI_ACTION', 'The A2UI action envelope is invalid.')
  }
  const value = envelope.userAction
  const allowed = new Set(['name', 'surfaceId', 'sourceComponentId', 'context', 'timestamp'])
  if (!isUnknownRecord(value) || Object.keys(value).some(key => !allowed.has(key))) {
    throw new AgUiGatewayError('INVALID_A2UI_ACTION', 'The A2UI user action is invalid.')
  }
  for (const field of ['name', 'surfaceId', 'sourceComponentId', 'timestamp'] as const) {
    if (value[field] !== undefined && typeof value[field] !== 'string') {
      throw new AgUiGatewayError('INVALID_A2UI_ACTION', `The A2UI user action ${field} must be a string.`)
    }
  }
  if (value.context !== undefined && !isUnknownRecord(value.context)) {
    throw new AgUiGatewayError('INVALID_A2UI_ACTION', 'The A2UI user action context must be an object.')
  }
  const name = typeof value.name === 'string' ? value.name : undefined
  const surfaceId = typeof value.surfaceId === 'string' ? value.surfaceId : undefined
  const sourceComponentId = typeof value.sourceComponentId === 'string' ? value.sourceComponentId : undefined
  const context = isUnknownRecord(value.context) ? value.context : undefined
  const timestamp = typeof value.timestamp === 'string' ? value.timestamp : undefined
  return {
    ...(name === undefined ? {} : { name }),
    ...(surfaceId === undefined ? {} : { surfaceId }),
    ...(sourceComponentId === undefined ? {} : { sourceComponentId }),
    ...(context === undefined ? {} : { context: structuredClone(context) }),
    ...(timestamp === undefined ? {} : { timestamp }),
  }
}

/** Match the official middleware's model-facing Tool result text exactly. */
function formatA2UIActionResult(action: A2UIUserAction): string {
  const actionName = action.name ?? 'unknown_action'
  const surfaceId = action.surfaceId ?? 'unknown_surface'
  let message = `User performed action "${actionName}" on surface "${surfaceId}"`
  if (action.sourceComponentId) message += ` (component: ${action.sourceComponentId})`
  message += `. Context: ${action.context === undefined ? '{}' : JSON.stringify(action.context)}`
  return message
}

/** Serialize JSON with recursively sorted object keys and locale-independent ordering. */
function canonicalJsonStringify(value: unknown): string {
  const encoded = writeCanonicalJson(value)
  /* v8 ignore next -- admitted A2UI actions and contexts are objects, which the writer always encodes. */
  if (encoded === undefined) throw new TypeError('A2UI action values must be JSON-serializable')
  return encoded
}

function writeCanonicalJson(value: unknown): string | undefined {
  if (Array.isArray(value)) {
    const items = Array.from(value, item => {
      const encoded = writeCanonicalJson(item)
      /* v8 ignore next -- parsed AG-UI JSON arrays cannot contain undefined, but canonical JSON represents sparse JS values as null. */
      return encoded ?? 'null'
    })
    return `[${items.join(',')}]`
  }
  if (!isUnknownRecord(value)) return JSON.stringify(value)
  const entries: string[] = []
  const keys = Object.keys(value).sort((left, right) => left < right ? -1 : 1)
  for (const key of keys) {
    const encoded = writeCanonicalJson(value[key])
    /* v8 ignore next -- parsed AG-UI JSON objects cannot contain undefined, but canonical JSON omits such JS properties. */
    if (encoded === undefined) continue
    entries.push(`${JSON.stringify(key)}:${encoded}`)
  }
  return `{${entries.join(',')}}`
}

/** Read the state-management Tool input after model-boundary validation. */
function readStateUpdates(args: unknown): Record<string, unknown> {
  if (!isUnknownRecord(args) || !isUnknownRecord(args.state_updates)) {
    throw new Error('Shared-state updates must contain a state_updates object')
  }
  return structuredClone(args.state_updates)
}

/** Narrow the four image formats accepted by prompt attachment admission. */
function isImageMediaType(value: string): value is ImageMediaType {
  return IMAGE_MEDIA_TYPES.has(value)
}
