/**
 * dsh-anydoc-markdown — DSH host plugin
 *
 * Converts a document (Word, PowerPoint, Excel, OpenDocument, RTF, EPUB, CSV or
 * PDF) into clean GitHub-Flavored Markdown using the Rust `firecrawl-anydoc`
 * crate, and describes every embedded image with a vision model so a text-only
 * model can reason about the document's imagery.
 *
 * The plugin exposes one model-facing tool, `convert_document`. It shells out to
 * a bundled, self-contained Python wrapper (`converter/anydoc_vlm.py`), which is
 * where the real conversion + vision work happens:
 *
 *   - `anydoc.to_document()` returns the full document model plus the embedded
 *     binary assets (images, MIME types, source part / alt text) on
 *     `Document.assets`. This is the seam this wrapper uses — the same
 *     `llm_client` + `llm_model` pattern MarkItDown pioneered, re-implemented
 *     for anydoc, which is a pure local Rust converter with no native VLM hook.
 *   - Images are described in BATCHES: no single vision request carries more
 *     than `maxImagesPerRequest` images (default 10), and many requests are made
 *     for large documents, so vision performance is not degraded by a giant
 *     multi-image prompt. This is a hard requirement of the design.
 *   - Each image's `![alt text]` placeholder in the Markdown is substituted with
 *     the vision description. Images the converter dropped (empty alt text) are
 *     appended as a described list so nothing is lost.
 *
 * Design notes (aligned with the dsh-file-upload reference plugin):
 *   - It is BOTH a host and a client plugin. The host half registers the
 *     `convert_document` tool and an `/dsh-anydoc` RPC channel; the client half
 *     (`lib/client.js`) shows dropped documents as attachment CARDS in the
 *     composer's input dock strip. Documents attach through the SAME whole-page
 *     drop the harness natively uses for images, so the plugin no longer adds a
 *     composer tool-row button or a competing drag overlay (both of which
 *     conflicted with the harness's built-in image drop). Images keep the
 *     harness's built-in image path.
 *   - Documents are NEVER converted on attach. `attach.upload` writes each upload
 *     to `attachmentsDir` and returns a source file path; a pre-step listener
 *     hands the model those source path(s) once, and the agent calls
 *     `convert_document` on each. `convert_document` converts, creates a subfolder
 *     inside `markdownOutputDir` named after the Markdown file, saves BOTH the
 *     `.md` file and every extracted embedded image (as a PNG) into it, and
 *     returns the `.md` file path (`savedPath`).
 *   - It uses only official seams (`ctx.tools.register`, `ctx.connection.rpc`)
 *     and places config in `cordis.patch.yml`; every knob is overridable, none
 *     are hardcoded.
 *   - It FAILS CLOSED and never breaks boot or a step. If the Python interpreter
 *     is missing, anydoc is not installed, or the conversion errors, the tool
 *     returns an error result for that call; the harness keeps working.
 *   - The module is deliberately self-contained (no `@deepseek-ai/*` imports)
 *     and hand-builds the `ToolDefinition` shape, so it can never fail to load
 *     from module resolution. `ctx.tools.register` validates only `output`,
 *     `timeoutMs` and the name, so the hand-built definition is sufficient.
 */

import { spawn } from 'node:child_process'
import { existsSync, readFileSync } from 'node:fs'
import { mkdir, writeFile, rm } from 'node:fs/promises'
import { randomUUID } from 'node:crypto'
import { tmpdir } from 'node:os'
import { fileURLToPath } from 'node:url'
import path from 'node:path'

/** Cordis plugin name. */
export const name = 'dsh-anydoc-markdown'

/**
 * Services the plugin registers against. `connection` exposes the generic RPC
 * channel used by the browser composer; `sessions` reaches the live session so
 * a converted document can be appended to the conversation durably.
 */
export const inject = ['tools', 'connection', 'sessions']

/** Module directory, computed once so config can point at the bundled wrapper. */
const MODULE_DIR = path.dirname(fileURLToPath(import.meta.url))

/** Default configuration; every field is overridable from cordis.patch.yml. */
export const DEFAULTS = Object.freeze({
  /** Python interpreter used to run the bundled converter. */
  converterPython: 'python',
  /** Path to `converter/anydoc_vlm.py`; defaults to the bundled copy. */
  converterPath: path.join(MODULE_DIR, 'converter', 'anydoc_vlm.py'),
  /** Max embedded images sent in one vision request (default 10). */
  maxImagesPerRequest: 10,
  /** Unicode path to the conversion temp/out — not used; markdown returns in-band. */
  maxChars: 60000,
  /** Cooperative tool-call timeout (ms) budget. */
  timeoutMs: 120000,
  /** OpenAI-compatible vision endpoint; empty = offline metadata descriptions. */
  visionEndpoint: '',
  /** Vision model id (e.g. gpt-4o); empty = offline metadata descriptions. */
  visionModel: '',
  /** Environment variable that supplies the vision API key. */
  visionApiKeyEnv: 'OPENAI_API_KEY',
  /** Generic RPC channel the browser composer uses to attach documents. */
  attachmentChannel: '/dsh-anydoc',
  /**
   * Directory uploaded SOURCE documents are written to (the path the agent is
   * handed and then converts via `convert_document`). Empty (default) resolves to
   * `<DSH_HOME>/attachments`.
   */
  attachmentsDir: '',
  /**
   * Directory `convert_document` saves the converted Markdown into. When set,
   * the tool creates a subfolder here named after the Markdown file (e.g.
   * `report/`) and saves BOTH the `.md` file and every extracted embedded image
   * as a PNG inside it, returning `savedPath` (the saved `.md` file) plus
   * `imageDir`/`savedImages`. When empty, the tool returns the Markdown inline
   * and saves nothing.
   */
  markdownOutputDir: '',
  /** Per-upload byte cap for document attachments (decoded size). */
  maxFileBytes: 25 * 1024 * 1024,
  /** File extensions the composer accepts as documents. */
  allowedAttachExtensions: [
    '.docx', '.doc', '.pdf', '.pptx', '.ppt', '.xlsx', '.xls',
    '.odt', '.rtf', '.epub', '.csv', '.txt', '.md', '.html', '.htm',
  ],
})

const PLUGIN_SOURCE = name

/** Human offset-timeout helper: keep `timeoutMs` clamped to a positive finite number. */
function clampTimeout(value, fallback) {
  const n = Number(value)
  return Number.isFinite(n) && n > 0 ? n : fallback
}

/**
 * Read one named credential from the dsh credentials YAML store
 * (`<DSH_HOME>/.credentials.yaml`, block `refs:`). Used as a fallback when the
 * API key is not already on `process.env`, so the plugin reuses the harness's
 * own key without duplicating a secret in its config.
 * @param {string} envVarName - the credential ref name (e.g. `DEEPSEEK_API_KEY`).
 * @returns {string | undefined} the value, or undefined when not found.
 */
function readCredentialFromFile(envVarName) {
  const dshHome = process.env.DSH_HOME
  if (!dshHome) return undefined
  const file = path.join(dshHome, '.credentials.yaml')
  let text
  try {
    text = readFileSync(file, 'utf8')
  } catch {
    return undefined
  }
  const escaped = envVarName.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
  const pattern = new RegExp(`^\\s*${escaped}:\\s*"?([^"\\s]+)"?\\s*$`, 'm')
  const match = text.match(pattern)
  return match ? match[1] : undefined
}

/**
 * Run the bundled Python converter and capture its JSON envelope.
 * @param {string} python - the interpreter command.
 * @param {string} script - path to anydoc_vlm.py.
 * @param {string[]} args - the converter CLI arguments.
 * @param {number} timeoutMs - kill after this many milliseconds.
 * @param {AbortSignal} [signal] - caller cancellation.
 * @param {Record<string,string>} [extraEnv] - extra child environment variables.
 * @returns {Promise<{code:number, stdout:string, stderr:string}>} the captured output.
 */
function runConverter(python, script, args, timeoutMs, signal, extraEnv = {}) {
  return new Promise((resolve, reject) => {
    const child = spawn(python, [script, ...args], {
      stdio: ['ignore', 'pipe', 'pipe'],
      windowsHide: true,
      // Force UTF-8 on the child's stdout so non-ASCII document content and VLM
      // descriptions reach the plugin cleanly (Windows pipes default to the ANSI
      // code page otherwise).
      env: { ...process.env, ...extraEnv, PYTHONIOENCODING: 'utf-8', PYTHONUTF8: '1' },
    })
    let stdout = ''
    let stderr = ''
    child.stdout.on('data', chunk => { stdout += chunk })
    child.stderr.on('data', chunk => { stderr += chunk })

    let timer
    if (Number.isFinite(timeoutMs) && timeoutMs > 0) {
      timer = setTimeout(() => {
        child.kill('SIGKILL')
        reject(new Error(`converter timed out after ${timeoutMs}ms`))
      }, timeoutMs)
    }
    if (signal) {
      if (signal.aborted) {
        child.kill('SIGKILL')
        reject(signal.reason instanceof Error ? signal.reason : new Error('aborted'))
        return
      }
      signal.addEventListener('abort', () => child.kill('SIGKILL'), { once: true })
    }

    child.on('close', code => {
      if (timer) clearTimeout(timer)
      resolve({ code, stdout, stderr })
    })
    child.on('error', error => {
      if (timer) clearTimeout(timer)
      reject(error)
    })
  })
}

/**
 * Parse the converter's JSON envelope, throwing a descriptive error on failure.
 * @param {{code:number, stdout:string, stderr:string}} captured - the process result.
 * @returns {{markdown:string, meta:object}} the parsed envelope.
 */
function parseEnvelope(captured) {
  if (captured.code !== 0) {
    const detail = (captured.stderr || captured.stdout || '').trim()
    throw new Error(`converter exited ${captured.code}: ${detail.slice(0, 800)}`)
  }
  let parsed
  try {
    parsed = JSON.parse(captured.stdout)
  } catch (error) {
    throw new Error(`converter did not emit valid JSON: ${String(error && error.message ? error.message : error)}`)
  }
  if (!parsed || typeof parsed.markdown !== 'string') {
    throw new Error('converter envelope missing "markdown"')
  }
  return { markdown: parsed.markdown, meta: parsed.meta || {} }
}

/**
 * Build an immutable plugin-attributed user message mirroring `createUserMessage`.
 * Plain `plugin` source (no form) renders as a context row with its content
 * directly visible, and the model always sees the content blocks.
 * @param {string} text - the model-facing text.
 * @returns {object} a frozen user-role plugin message.
 */
function pluginMessage(text) {
  return Object.freeze({
    id: randomUUID(),
    role: 'user',
    content: [{ type: 'text', text }],
    source: { kind: 'plugin', plugin: PLUGIN_SOURCE },
  })
}

/** Document extensions accepted by the composer, lowercased with leading dot. */
function normalizeExtensions(values) {
  const set = new Set()
  for (const value of values ?? []) {
    const ext = String(value).trim().toLowerCase()
    if (ext) set.add(ext.startsWith('.') ? ext : `.${ext}`)
  }
  return set
}

/** Whether a file name is a document the composer handles. */
function isDocumentFile(filename, extensions) {
  const dot = String(filename || '').lastIndexOf('.')
  if (dot === -1) return false
  return extensions.has(String(filename).slice(dot).toLowerCase())
}

/** anydoc format name for signature-less documents (auto-detected otherwise). */
function attachFormat(name) {
  const ext = path.extname(String(name || '')).toLowerCase()
  return ext === '.csv' ? 'csv' : undefined
}

/** Coerce a raw upload name to a safe filesystem basename (no path traversal). */
function safeBasename(name) {
  const base = path.basename(String(name || 'document').replace(/[/\\]+/g, '/'))
  const cleaned = base.replace(/[<>:"/\\|?*\u0000-\u001f]/g, '_').trim()
  return cleaned || 'document'
}

/**
 * Decode a base64 payload into a Buffer, rejecting empty or malformed input.
 * @param {string} base64 - the payload.
 * @returns {Buffer} the decoded bytes.
 */
function decodeBase64(base64) {
  const data = Buffer.from(String(base64 || ''), 'base64')
  if (data.length === 0) throw new Error('uploaded file is empty or not valid base64')
  return data
}

/**
 * Reserve a fresh subfolder inside `outputDir` for one conversion.
 *
 * The subfolder is named after the Markdown file it will contain (the source
 * document's stem, e.g. `report` -> `report/`), and the Markdown file inside is
 * named the same (`report/report.md`) so the subfolder's name always matches the
 * `.md` file inside it — the same layout the extracted image PNGs share. A
 * collision (a subfolder of that name already exists) gets a numeric suffix
 * (`report-2/`), mirroring `writeUpload`'s collision handling.
 *
 * @param {string} outputDir - the configured `markdownOutputDir`.
 * @param {string} sourceName - the source document file name (used for the stem).
 * @returns {Promise<{dir:string, markdownName:string}>} the created subfolder and the Markdown file name.
 */
async function resolveOutputBundle(outputDir, sourceName) {
  const stem = safeBasename(sourceName).replace(/\.[^.]+$/, '') || 'document'
  await mkdir(outputDir, { recursive: true })
  for (let n = 1; ; n += 1) {
    const name = n === 1 ? stem : `${stem}-${n}`
    const dir = path.join(outputDir, name)
    if (!existsSync(dir)) {
      await mkdir(dir, { recursive: true })
      return { dir, markdownName: `${name}.md` }
    }
  }
}

/** Write the converted Markdown into a resolved output bundle, avoiding a clash. */
async function writeOutputBundle(pkg, markdown) {
  const target = path.join(pkg.dir, pkg.markdownName)
  await writeFile(target, markdown, { encoding: 'utf8', flag: 'wx' })
  return target
}

/** Write raw bytes to `dir` under a safe name, avoiding collisions. */
async function writeUpload(dir, sourceName, data) {
  await mkdir(dir, { recursive: true })
  const base = safeBasename(sourceName)
  let target = path.join(dir, base)
  for (let n = 2; ; n += 1) {
    try {
      await writeFile(target, data, { flag: 'wx' })
      return target
    } catch (error) {
      if (!error || error.code !== 'EEXIST') throw error
      const dot = base.lastIndexOf('.')
      const stem = dot === -1 ? base : base.slice(0, dot)
      const ext = dot === -1 ? '' : base.slice(dot)
      target = path.join(dir, `${stem}-${n}${ext}`)
    }
  }
}

/**
 * Compose the model-facing text for an attached SOURCE-document batch. The agent
 * is handed the saved file path(s) and is expected to call `convert_document` on
 * each — the plugin never injects the converted Markdown itself.
 * @param {Array<{name:string, path:string}>} ok - uploaded source files.
 * @returns {string} the message body.
 */
function composeAttachPathMessage(ok) {
  const lines = ok.map(entry => `- ${entry.path}`)
  return [
    'The following document(s) were attached to this conversation:',
    ...lines,
    '',
    'Use the `convert_document` tool on each saved file path above to convert it',
    'to Markdown (the tool saves the Markdown to the output folder and returns the path).',
  ].join('\n')
}

/**
 * Register the `convert_document` tool and the document-attach RPC channel for
 * the lifetime of `ctx`.
 * @param {import('@deepseek-ai/cordis').Context} ctx - plugin context.
 * @param {object} [config] - plugin config; see {@link DEFAULTS}.
 */
export function apply(ctx, config = {}) {
  const cfg = { ...DEFAULTS, ...(config ?? {}) }
  const python = String(cfg.converterPython || DEFAULTS.converterPython)
  const script = String(cfg.converterPath || DEFAULTS.converterPath)
  const timeoutMs = clampTimeout(cfg.timeoutMs, DEFAULTS.timeoutMs)
  const maxChars = Number(cfg.maxChars) > 0 ? Number(cfg.maxChars) : DEFAULTS.maxChars

  const dshHome = process.env.DSH_HOME || tmpdir()
  const uploadsDir = String(cfg.attachmentsDir || '').trim() || path.join(dshHome, 'attachments')
  const outputDir = String(cfg.markdownOutputDir || '').trim()
  const extensions = normalizeExtensions(cfg.allowedAttachExtensions)
  const maxFileBytes = Number(cfg.maxFileBytes) > 0 ? Number(cfg.maxFileBytes) : DEFAULTS.maxFileBytes

  // Per-session list of attached SOURCE documents awaiting conversion. Keyed by
  // session id (== agent id); the pre-step listener hands their paths to the
  // model so it can call `convert_document` — we never inject the converted
  // Markdown ourselves.
  const pendingAttachments = new Map()

  // Resolve the vision API key: from the configured env var first, then the dsh
  // credentials store, so the plugin reuses the harness's own DeepSeek key
  // without duplicating it in config or on the command line.
  const apiKey = () => {
    if (!cfg.visionApiKeyEnv) return undefined
    const fromEnv = process.env[cfg.visionApiKeyEnv]
    return fromEnv || readCredentialFromFile(cfg.visionApiKeyEnv)
  }

  const tool = {
    name: 'convert_document',
    description: 'Convert a document (Word, PowerPoint, Excel, OpenDocument, RTF, EPUB, CSV or PDF) to clean Markdown, describing every embedded image with a vision model. Use this when the agent needs to read an office document or PDF that it cannot open as text.',
    parameters: {
      type: 'object',
      properties: {
        file_path: {
          type: 'string',
          description: 'Path to the document file to convert.',
        },
        max_images_per_request: {
          type: 'number',
          description: `Max embedded images sent in one vision request. Defaults to ${cfg.maxImagesPerRequest}.`,
        },
      },
      required: ['file_path'],
    },
    output: {
      schema: {
        type: 'object',
        additionalProperties: false,
        properties: {
          markdown: { type: 'string' },
          path: { type: 'string' },
          savedPath: { type: 'string' },
          imageDir: { type: 'string' },
          savedImages: { type: 'array', items: { type: 'string' } },
          images: { type: 'integer' },
          images_described: { type: 'integer' },
          vision_requests: { type: 'integer' },
          truncated: { type: 'boolean' },
        },
        required: ['markdown', 'path', 'savedPath', 'images', 'images_described', 'vision_requests', 'truncated'],
      },
      render: (_args, value) => {
        const note = value.markdown
        const body = value.truncated ? `${note}\n\n…[truncated]` : note
        const header = value.savedPath ? `Saved Markdown: ${value.savedPath}\n\n` : ''
        return [{ type: 'text', text: header + body }]
      },
      presentationMeta: (_args, value) => ({
        path: value.path,
        savedPath: value.savedPath,
        imageDir: value.imageDir || '',
        savedImages: value.savedImages || [],
        markdown: value.markdown,
        images: value.images,
        images_described: value.images_described,
        vision_requests: value.vision_requests,
        truncated: value.truncated,
      }),
    },
    timeoutMs,
    isConcurrencySafe: () => true,
    async execute(args, exec) {
      const filePath = String(args.file_path || '').trim()
      if (!filePath) throw new Error('file_path must be a non-empty string')

      const maxPerRequest = Number.isFinite(Number(args.max_images_per_request)) && Number(args.max_images_per_request) > 0
        ? Number(args.max_images_per_request)
        : Number(cfg.maxImagesPerRequest)

      // Reserve the output bundle (a fresh subfolder + the name of the `.md` file
      // it will contain) BEFORE running the converter, so the converted Markdown
      // and its extracted image PNGs land in the same on-disk subfolder. When
      // `markdownOutputDir` is unset, nothing is persisted and the converter is
      // told nothing (it returns the Markdown inline as before).
      const outputBundle = outputDir
        ? await resolveOutputBundle(outputDir, path.basename(filePath))
        : null

      // `runConverter` prepends `script`; these are the converter's OWN args.
      const cliArgs = [filePath, '--max-images', String(maxPerRequest), '--json']
      if (cfg.visionEndpoint) cliArgs.push('--vision-endpoint', String(cfg.visionEndpoint))
      if (cfg.visionModel) cliArgs.push('--vision-model', String(cfg.visionModel))
      if (outputBundle) cliArgs.push('--save-images-dir', outputBundle.dir)
      const fmt = attachFormat(filePath)
      if (fmt) cliArgs.push('--format', fmt)
      // Pass the key to the child via env (the wrapper reads OPENAI_API_KEY) so it
      // never appears on the process command line.
      const key = apiKey()
      const extraEnv = key ? { OPENAI_API_KEY: key } : {}

      const captured = await runConverter(python, script, cliArgs, timeoutMs, exec.signal, extraEnv)
      const { markdown, meta } = parseEnvelope(captured)

      const truncated = markdown.length > maxChars
      const bounded = truncated ? markdown.slice(0, maxChars) : markdown
      // The converter already wrote the PNGs into `outputBundle.dir` (fixed
      // relative file names); write the Markdown next to them.
      const savedPath = outputBundle ? await writeOutputBundle(outputBundle, markdown) : ''
      return {
        path: filePath,
        markdown: bounded,
        savedPath,
        imageDir: outputBundle?.dir || '',
        savedImages: Array.isArray(meta.saved_images) ? meta.saved_images : [],
        images: Number(meta.images || 0),
        images_described: Number(meta.images_described || 0),
        vision_requests: Number(meta.vision_requests || 0),
        truncated,
      }
    },
    presentCall(args) {
      return {
        card: 'generic',
        title: `Convert document ${args.file_path}`,
        kind: 'terminal',
        locations: [{ path: args.file_path, line: 1 }],
      }
    },
  }

  ctx.tools.register(tool)

  // ---- Document attach (composer) -------------------------------------- //
  // The browser composer shows documents as attachment CARDS and streams the
  // bytes over the generic RPC channel below. The host writes each upload to
  // `attachmentsDir` and hands the model the SOURCE FILE PATH (via the pre-step
  // listener) so the agent calls `convert_document` itself — the converted
  // Markdown is never injected as context.
  const handler = async (endpoint, payload) => {
    const { sessionId } = payload ?? {}

    if (endpoint === 'attach.remove') {
      const id = payload?.id
      const list = pendingAttachments.get(sessionId) ?? []
      const index = list.findIndex(entry => entry.id === id)
      if (index !== -1) {
        const [removed] = list.splice(index, 1)
        await rm(removed.path, { force: true }).catch(() => {})
        if (list.length === 0) pendingAttachments.delete(sessionId)
      }
      return { ok: true, value: { removed: index !== -1 } }
    }

    if (endpoint !== 'attach.upload') {
      return { ok: false, error: { code: 'bad-request', message: `Unknown endpoint: ${endpoint}` } }
    }
    if (!sessionId) {
      return { ok: false, error: { code: 'bad-request', message: 'sessionId is required' } }
    }
    if (!Array.isArray(payload?.files) || payload.files.length === 0) {
      return { ok: false, error: { code: 'bad-request', message: 'files must be a non-empty array' } }
    }
    if (!ctx.sessions.get(sessionId)) {
      return { ok: false, error: { code: 'session-not-found', message: `session "${sessionId}" not found` } }
    }

    const results = []
    const okResults = []
    for (const file of payload.files) {
      const name = String(file?.name || '').trim()
      try {
        const data = decodeBase64(file?.base64)
        if (data.length > maxFileBytes) throw new Error(`file exceeds ${maxFileBytes} bytes`)
        if (!isDocumentFile(name, extensions)) throw new Error('unsupported document type')
        const path = await writeUpload(uploadsDir, name, data)
        const entry = { id: randomUUID(), name, path, size: data.length }
        results.push({ ...entry, ok: true })
        okResults.push(entry)
      } catch (error) {
        results.push({ name, ok: false, error: String(error && error.message ? error.message : error) })
      }
    }

    if (okResults.length > 0) {
      const existing = pendingAttachments.get(sessionId) ?? []
      pendingAttachments.set(sessionId, [...existing, ...okResults])
    }

    return { ok: true, value: { files: results } }
  }

  ctx.connection.rpc.handle(String(cfg.attachmentChannel || DEFAULTS.attachmentChannel), handler, { authority: 'loopback' })

  // Hand the attached SOURCE file path(s) to the model exactly once, at the next
  // step — the agent then converts them via `convert_document`. This is a plain
  // pre-step plugin message (durable session event), never the converted Markdown.
  ctx.on('agent/pre-step', async ({ agent }, next) => {
    const decision = await next()
    if (decision.kind !== 'enter') return decision
    const list = pendingAttachments.get(agent?.id)
    if (!list || list.length === 0) return decision
    const fresh = list.filter(entry => !entry.delivered)
    if (fresh.length === 0) return decision
    for (const entry of fresh) entry.delivered = true
    const text = composeAttachPathMessage(fresh)
    ctx.logger?.debug?.(`[${PLUGIN_SOURCE}] handing ${fresh.length} attached document(s) to agent ${agent?.id}`)
    return { kind: 'enter', messages: [...decision.messages, pluginMessage(text)] }
  }, { prepend: true })

  ctx.logger?.info?.(`[${PLUGIN_SOURCE}] active (converter ${script}, python "${python}", maxImagesPerRequest ${cfg.maxImagesPerRequest}, uploads ${uploadsDir}, attach ${String(cfg.attachmentChannel || DEFAULTS.attachmentChannel)})`)
}
