#!/usr/bin/env python3
"""Offline tests for the anydoc + vision pipeline (no HTTP, no API key needed).

Run:  python -m unittest discover -s <plugin>/converter -p 'test_*.py'
Deps: firecrawl-anydoc (installed) and, for the end-to-end docx case, python-docx.
"""

import io
import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import anydoc_vlm as A  # noqa: E402


def make_docx_with_images(image_count: int, alt_prefix: str = "img"):
    """Build an in-memory .docx with `image_count` embedded PNG images."""
    import docx
    from docx.shared import Inches

    d = docx.Document()
    d.add_heading("Test Heading", level=1)
    d.add_paragraph("Text before images.")
    for i in range(image_count):
        p = d.add_paragraph()
        p.add_run().add_picture(io.BytesIO(make_png((i * 40 % 255, 60, 90))), width=Inches(0.5))
        # alt text on the picture
        from docx.oxml.ns import qn
        for run in p.runs:
            for docpr in run._r.iter(qn("wp:docPr")):
                docpr.set("descr", f"{alt_prefix}_{i}")
    d.add_paragraph("Text after images.")
    buf = io.BytesIO()
    d.save(buf)
    return buf.getvalue()


def make_png(color):
    from PIL import Image

    img = Image.new("RGB", (8, 8), color)
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    return buf.getvalue()


class BatchingTests(unittest.TestCase):
    def test_batches_never_exceed_default_and_make_multiple_requests(self):
        """23 images, max 10 -> 3 requests, batch sizes [10, 10, 3]."""
        batches = []
        client = A.VisionClient(
            endpoint=None, model=None, api_key=None, max_per_request=10, timeout=10,
            describe_batch=lambda batch: (batches.append(len(batch)) or ["desc"] * len(batch)),
        )
        images = [{"data": b"xx", "media_type": "image/png"} for _ in range(23)]
        descs = client.describe_many(images)
        self.assertEqual(client.requests, 3)
        self.assertEqual(client.batch_sizes, [10, 10, 3])
        self.assertEqual(len(descs), 23)

    def test_larger_batch_limit_increases_request_count(self):
        """max 4 -> 6 requests, last batch holds the remainder."""
        client = A.VisionClient(
            endpoint=None, model=None, api_key=None, max_per_request=4, timeout=10,
            describe_batch=lambda batch: ["d"] * len(batch),
        )
        images = [{"data": b"xx", "media_type": "image/png"} for _ in range(23)]
        client.describe_many(images)
        self.assertEqual(client.requests, 6)
        self.assertEqual(client.batch_sizes, [4, 4, 4, 4, 4, 3])


class SubstitutionTests(unittest.TestCase):
    def test_substitutes_alt_paragraphs_and_appends_dropped(self):
        md = "# H\n\nbefore\n\nchart_1\n\nmid\n\nchart_2\n\nend\n"
        entries = [
            {"asset_id": 0, "origin_part": "image1.png", "media_type": "image/png", "data": b"x", "alt": "chart_1", "desc": "a red chart"},
            {"asset_id": 1, "origin_part": "image2.png", "media_type": "image/png", "data": b"x", "alt": "chart_2", "desc": "a blue chart"},
        ]
        out = A.substitute(md, entries)
        self.assertIn("![a red chart](asset://0)", out)
        self.assertIn("![a blue chart](asset://1)", out)
        # original alt paragraphs gone
        self.assertNotIn("\nchart_1\n", out)
        self.assertNotIn("\nchart_2\n", out)

    def test_empty_alt_is_not_lost(self):
        md = "# H\n\nhello\n"
        entries = [{"asset_id": 5, "origin_part": "i5.png", "media_type": "image/png", "data": b"x", "alt": "", "desc": "a dropped image"}]
        out = A.substitute(md, entries)
        self.assertIn("a dropped image", out)


class ExtractionTests(unittest.TestCase):
    def test_extract_images_in_document_order(self):
        data = make_docx_with_images(3, alt_prefix="pic")
        doc = A.anydoc.to_document(data)
        images = A.extract_images(doc)
        self.assertEqual(len(images), 3)
        self.assertEqual([img["alt"] for img in images], ["pic_0", "pic_1", "pic_2"])
        self.assertIsNotNone(images[0]["data"])


class ConvertTests(unittest.TestCase):
    def test_convert_describes_and_substitutes(self):
        import tempfile

        data = make_docx_with_images(3)
        with tempfile.NamedTemporaryFile(suffix=".docx", delete=False) as fh:
            fh.write(data)
            path = fh.name
        try:
            client = A.VisionClient(
                endpoint=None, model=None, api_key=None, max_per_request=2, timeout=10,
                describe_batch=lambda batch: [f"desc {i}" for i in range(len(batch))],
            )
            result = A.convert(path, max_images_per_request=2, vision=client)
            self.assertEqual(result["meta"]["images"], 3)
            self.assertEqual(result["meta"]["images_described"], 3)
            self.assertEqual(result["meta"]["vision_requests"], 2)  # ceil(3/2)
            self.assertIn("desc 0", result["markdown"])
            self.assertIn("![", result["markdown"])
        finally:
            os.unlink(path)


class SaveImagesTests(unittest.TestCase):
    """The converter persists every embedded image as a PNG into a save dir and
    rewrites the Markdown image references to point at those files.

    The save dir is a fresh folder under the converter's own directory (created
    by the converter via ``os.makedirs``) rather than ``tempfile`` so the tests
    are portable to sandboxed environments that restrict temp-file writes. It is
    removed on teardown.
    """

    _converter_dir = os.path.dirname(os.path.abspath(__file__))

    def _save_dir(self):
        import shutil
        import uuid

        d = os.path.join(self._converter_dir, ".save-" + uuid.uuid4().hex[:10])
        self.addCleanup(shutil.rmtree, d, True)
        return d

    def _convert_docx(self, image_count, save_dir, max_per_request=2):
        import tempfile

        data = make_docx_with_images(image_count, alt_prefix="pic")
        with tempfile.NamedTemporaryFile(suffix=".docx", delete=False) as fh:
            fh.write(data)
            path = fh.name
        try:
            client = A.VisionClient(
                endpoint=None, model=None, api_key=None,
                max_per_request=max_per_request, timeout=10,
                describe_batch=lambda batch: [f"desc {i}" for i in range(len(batch))],
            )
            return A.convert(path, max_images_per_request=max_per_request,
                             vision=client, save_images_dir=save_dir)
        finally:
            os.unlink(path)

    def test_saves_each_embedded_image_as_png_and_rewrites_references(self):
        # The directory does not exist yet; `convert` creates it on the spot.
        save_dir = self._save_dir()
        result = self._convert_docx(3, save_dir)
        meta = result["meta"]
        self.assertEqual(meta["images"], 3)
        self.assertEqual(meta["images_saved"], 3)
        self.assertEqual(len(meta["saved_images"]), 3)
        self.assertEqual(meta["image_dir"], save_dir)

        # Every saved image exists on disk as a real PNG and the Markdown
        # references it by a relative file name (not asset://).
        for i, fname in enumerate(meta["saved_images"], start=1):
            self.assertEqual(fname, f"image_{i:04d}.png")
            p = os.path.join(save_dir, fname)
            self.assertTrue(os.path.exists(p))
            from PIL import Image
            with Image.open(p) as im:
                self.assertEqual(im.format, "PNG")
            self.assertIn(f"({fname})", result["markdown"])

        # The asset:// pointer is gone because a real file was substituted.
        self.assertNotIn("asset://", result["markdown"])

    def test_writes_pngs_into_an_explicit_dir_and_creates_it(self):
        import shutil

        top = os.path.join(self._converter_dir, ".save-" + os.urandom(5).hex())
        nested = os.path.join(top, "sub", "dir")
        self.addCleanup(shutil.rmtree, top, True)
        result = self._convert_docx(2, nested)
        self.assertEqual(result["meta"]["images_saved"], 2)
        self.assertTrue(os.path.isdir(nested))
        for fname in result["meta"]["saved_images"]:
            self.assertTrue(os.path.exists(os.path.join(nested, fname)))

    def test_no_save_dir_leaves_asset_references_intact(self):
        # Backward compatibility: without save_images_dir the Markdown still uses
        # asset:// ids and nothing is persisted.
        import tempfile

        data = make_docx_with_images(2, alt_prefix="pic")
        with tempfile.NamedTemporaryFile(suffix=".docx", delete=False) as fh:
            fh.write(data)
            path = fh.name
        try:
            client = A.VisionClient(
                endpoint=None, model=None, api_key=None, max_per_request=2, timeout=10,
                describe_batch=lambda batch: [f"desc {i}" for i in range(len(batch))],
            )
            result = A.convert(path, max_images_per_request=2, vision=client)
            self.assertEqual(result["meta"]["images_saved"], 0)
            self.assertEqual(result["meta"]["saved_images"], [])
            self.assertIn("asset://", result["markdown"])
        finally:
            os.unlink(path)


class VisionRetryTests(unittest.TestCase):
    """Offline tests for the retry + tolerant-parse logic (no HTTP/API key)."""

    def _fake_response(self, body):
        class _Resp:
            def __init__(self, b):
                self._b = b
            def read(self):
                return self._b
            def __enter__(self):
                return self
            def __exit__(self, *a):
                return False
        return _Resp(body)

    def test_extract_json_array_tolerates_prose(self):
        import json as _json
        # Fenced json block.
        self.assertEqual(A._extract_json_array('```json\n["a","b"]\n```'), ["a", "b"])
        # Prose before/after the array.
        self.assertEqual(A._extract_json_array('Here: ["x", "y"]  done'), ["x", "y"])
        # A clean array still parses.
        self.assertEqual(A._extract_json_array('["p","q"]'), ["p", "q"])
        # Not an array -> None.
        self.assertIsNone(A._extract_json_array("not json at all"))
        self.assertIsNone(A._extract_json_array(""))

    def test_parse_descriptions_requires_exact_length(self):
        batch = [{"data": b"x"}, {"data": b"y"}]
        client = A.VisionClient(endpoint="https://x", model="m", api_key="k",
                                max_per_request=10, timeout=5)
        # exact length -> accepted and capped
        self.assertEqual(client._parse_descriptions('["one","two"]', batch), ["one", "two"])
        # wrong length -> None (so the caller retries / degrades, never misaligns)
        self.assertIsNone(client._parse_descriptions('["one"]', batch))
        self.assertIsNone(client._parse_descriptions("garbage", batch))
        self.assertIsNone(client._parse_descriptions(None, batch))

    def test_openai_batch_retries_then_recovers(self):
        import json as _json
        import urllib.error
        from unittest import mock

        calls = []

        def fake_urlopen(request, timeout=None):
            calls.append(1)
            if len(calls) < 3:
                raise urllib.error.HTTPError(request.full_url, 429, "rate limit", {}, None)
            payload = {"choices": [{"message": {"content": _json.dumps(["a", "b"])}}]}
            return self._fake_response(_json.dumps(payload).encode("utf-8"))

        client = A.VisionClient(endpoint="https://x", model="m", api_key="k",
                                max_per_request=10, timeout=5, attempts=3, retry_backoff=0)
        batch = [{"data": b"x", "media_type": "image/png"}, {"data": b"y", "media_type": "image/png"}]
        with mock.patch("urllib.request.urlopen", side_effect=fake_urlopen):
            descs = client._openai_batch(batch)
        self.assertEqual(descs, ["a", "b"])
        self.assertEqual(client.retries, 2)  # 3 attempts, 2 retries

    def test_openai_batch_gives_up_and_reports_offline(self):
        import urllib.error
        from unittest import mock

        def always_fail(request, timeout=None):
            raise urllib.error.HTTPError(request.full_url, 500, "err", {}, None)

        client = A.VisionClient(endpoint="https://x", model="m", api_key="k",
                                max_per_request=10, timeout=5, attempts=3, retry_backoff=0)
        batch = [{"data": b"x", "media_type": "image/png"}]
        with mock.patch("urllib.request.urlopen", side_effect=always_fail):
            descs = client._openai_batch(batch)
        self.assertEqual(len(descs), 1)
        self.assertIn("Offline metadata description", descs[0])
        self.assertIn("vision request failed after retries", descs[0])
        self.assertEqual(client.retries, 2)

    def test_offline_message_carries_honest_reason(self):
        img = {"media_type": "image/png", "origin_part": "page 3", "data": b"1234", "alt": ""}
        self.assertIn("no vision model was configured", A._metadata_description(img))
        self.assertIn("vision request failed after retries",
                      A._metadata_description(img, "vision request failed after retries"))


if __name__ == "__main__":
    unittest.main()
