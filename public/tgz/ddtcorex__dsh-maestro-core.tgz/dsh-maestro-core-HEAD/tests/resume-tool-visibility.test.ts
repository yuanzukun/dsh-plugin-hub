/**
 * C1 — post-resume tool-view observability probe.
 *
 * After a dsh web restart + auto-resume, a resumed session sometimes loses
 * core tools (`Error: unknown tool "bash"`, and `cordis_inspect_query`) while
 * plugin tools keep working. These tests pin the probe that makes that loss
 * caller-visible: it reads the resumed session's SCOPED tool view right after
 * the recovery followup and logs `bash=true/false`, the visible tool count and
 * the missing critical names.
 *
 * The stubs deliberately model the exact split C1 targets — the host layer
 * keeps bash registered (so the existing readiness poll passes instantly) while
 * the resumed session's per-session scoped view may or may not still expose it.
 */
import { describe, it, expect, vi, beforeEach } from 'vitest'
import {
  resumeInterrupted,
  createResumeRpcHandler,
  probeToolView,
  CRITICAL_TOOLS,
  warnCoreToolLoss,
  resetResumeToolHealthState,
  snapshotResumeToolHealth,
  createResumeToolHealthRpcHandler,
  buildToolInventoryMessage,
  type ToolsLike,
} from '../src/host/plugin.js'
import { probeToolView, summarizeToolView } from '../src/host/tool-view.js'

function makeCtx(overrides: Record<string, any> = {}) {
  const logs: string[] = []
  return {
    logger: {
      info: (msg: string) => logs.push(`info:${msg}`),
      warn: (msg: string) => logs.push(`warn:${msg}`),
    },
    get: (key: string) => (overrides[key] !== undefined ? overrides[key] : undefined),
    _logs: logs,
    ...overrides,
  }
}

/**
 * ToolsLike stub that models the split MEASURED on 2026-09-14: the deployment
 * global layer holds only host-composition tools and never `bash` — the preset's
 * standing mount is what contributes bash, read, write and the rest. `scopeTools`
 * is therefore the preset/agent view; reading without a scope answers nothing.
 *
 * The previous stub had it backwards (a global view that always held bash), which
 * is why the suite could not see a preset-less agent for what it was: the old
 * pre-delivery gate polled that global view and always "passed".
 */
function scopedTools(scopeTools: Record<string, unknown>): ToolsLike & { calls: [string, unknown][] } {
  const calls: [string, unknown][] = []
  return {
    calls,
    get: (name: string, scope?: unknown) => {
      calls.push([name, scope])
      if (scope === undefined) return undefined // no preset layer contributes here
      return scopeTools[name]
    },
    schemas: (scope?: unknown) => (scope === undefined ? [] : Object.keys(scopeTools).map((name) => ({ name }))),
  }
}

describe('C1 — resumed-session tool-view probe', () => {
  it('flags bash as missing when the resumed session scope hides it', async () => {
    const followup = vi.fn()
    const tools = scopedTools({ read: {} }) // session scope: no bash
    const ctx = makeCtx({ agents: { get: () => ({ followup }) }, tools })

    const resumed = await resumeInterrupted(ctx, ['proj/session-resumed-1'], {
      // C2 mitigation fires on this loss case — keep the test hermetic by
      // injecting the notify/message seams (defaults would hit the real
      // notifier + session push).
      notify: vi.fn(async () => {}),
      injectSessionMessage: vi.fn(),
    })
    expect(resumed).toEqual(['proj/session-resumed-1'])

    // Caller-visible probe result: missing bash in the resumed session's view.
    const probe = probeToolView(tools, 'session-resumed-1')
    expect(probe.missing).toEqual(['bash'])
    expect(probe.visible).toBe(1)

    // Journal log line pins the observation: the missing name, the count, and
    // the fact that the registry answered at all.
    const line = ctx._logs.find((l: string) => l.startsWith('info:[supervisor] resumed ')) as string
    expect(line).toContain('missing=bash')
    expect(line).toContain('visible=1')
    expect(line).toContain('registry=reachable')

    // The probe read the SCOPED view (session id), not just the global registry.
    expect(tools.calls.some(([name, scope]) => name === 'bash' && scope === 'session-resumed-1')).toBe(true)
  })

  it('reports no missing core tools when the resumed session scope keeps bash', async () => {
    const followup = vi.fn()
    const tools = scopedTools({ bash: {}, read: {} })
    const ctx = makeCtx({ agents: { get: () => ({ followup }) }, tools })

    const resumed = await resumeInterrupted(ctx, ['proj/session-resumed-2'])
    expect(resumed).toEqual(['proj/session-resumed-2'])

    expect(probeToolView(tools, 'session-resumed-2').missing).toEqual([])
    const line = ctx._logs.find((l: string) => l.startsWith('info:[supervisor] resumed ')) as string
    expect(line).toContain('missing=none')
    expect(line).toContain('registry=reachable')
  })

  it('reports an unreadable registry instead of a healthy-looking empty probe', async () => {
    const followup = vi.fn()
    const ctx = makeCtx({ agents: { get: () => ({ followup }) } }) // no tools service at all

    const resumed = await resumeInterrupted(ctx, ['proj/session-resumed-3'])
    expect(resumed).toEqual(['proj/session-resumed-3'])
    // No journal line (there is nothing to observe), but the recorded probe must
    // say the registry was unreachable — never "nothing missing".
    const recorded = snapshotResumeToolHealth(ctx).lastResumeProbe
    expect(recorded).toMatchObject({ missing: [], registry: 'unreachable' })
  })

  it('uses an injected probeToolView and scope resolver through deps', async () => {
    const followup = vi.fn()
    const tools = scopedTools({ bash: {} })
    const injectedProbe = vi.fn(() => ({ missing: [] as string[], visible: 0 }))
    const resolveScope = (_ctx: any, id: string) => `agent:${id}`
    const ctx = makeCtx({ agents: { get: () => ({ followup }) }, tools })

    const resumed = await resumeInterrupted(ctx, ['proj/session-resumed-4'], {
      probeToolView: injectedProbe,
      resolveToolScope: resolveScope,
    })
    expect(resumed).toEqual(['proj/session-resumed-4'])
    expect(injectedProbe).toHaveBeenCalledTimes(1)
    expect(injectedProbe.mock.calls[0][1]).toBe('agent:session-resumed-4')
  })

  it('exposes the probe through the loopback resume RPC path', async () => {
    const followup = vi.fn()
    const tools = scopedTools({ read: {} }) // session scope: no bash
    const ctx = makeCtx({ agents: { get: () => ({ followup }) }, tools })

    const handler = createResumeRpcHandler(ctx, { notify: vi.fn(async () => {}), injectSessionMessage: vi.fn() })
    const res = await handler('resume', { ids: ['proj/session-resumed-5'] }, new AbortController().signal)
    expect(res).toEqual({ ok: true, value: { resumed: ['proj/session-resumed-5'] } })
    expect(ctx._logs.some((l: string) => l.includes('missing=bash') && l.includes('registry=reachable'))).toBe(true)
  })

  it('probeToolView reports an unreadable registry as unreachable, never as healthy', () => {
    expect(probeToolView(undefined, 'session-x')).toEqual({ missing: [], visible: 0, registry: 'unreachable' })
    expect(probeToolView({ schemas: () => [] } as unknown as ToolsLike, 'session-x')).toEqual({
      missing: [],
      visible: 0,
      registry: 'unreachable',
    })
  })

  it('pins bash in CRITICAL_TOOLS (the Part C loss target)', () => {
    expect(CRITICAL_TOOLS).toContain('bash')
  })
})

describe('C2 — resumed-session core-tool-loss mitigation', () => {
  beforeEach(() => {
    // Module-level mitigation state (parked set + lastResumeProbe) is shared
    // across tests in this file — reset so each spec starts clean.
    resetResumeToolHealthState()
  })

  it('warn policy: notifies once with [bash], injects tool-inventory message, records nothing parked', async () => {
    const notify = vi.fn(async () => {})
    const injected: { sessionId: string; content: string }[] = []
    const injectSessionMessage = vi.fn((sessionId: string, content: string) => { injected.push({ sessionId, content }) })
    const followup = vi.fn()
    const tools = scopedTools({ read: {} }) // resumed scope hides bash; only 'read' is available
    const ctx = makeCtx({ agents: { get: () => ({ followup }) }, tools })

    const resumed = await resumeInterrupted(ctx, ['proj/session-core-1'], { notify, injectSessionMessage })
    expect(resumed).toEqual(['proj/session-core-1'])

    expect(notify).toHaveBeenCalledTimes(1)
    expect(notify.mock.calls[0][0]).toContain('[bash]')
    expect(notify.mock.calls[0][0]).toContain('reopen session if it persists')
    expect(notify.mock.calls[0][0]).not.toContain('manual reopen required')

    expect(injectSessionMessage).toHaveBeenCalledTimes(1)
    expect(injected[0].sessionId).toBe('session-core-1')
    expect(injected[0].content).toContain('bash tool is unavailable')
    expect(injected[0].content).toContain('Available tools: read')
    expect(injected[0].content).toContain('Do not call bash')

    // warn policy: no parking, but the real observation is recorded.
    const health = snapshotResumeToolHealth(ctx)
    expect(health.parked).toEqual([])
    expect(health.lastResumeProbe).toEqual({ missing: ['bash'], visible: 1, registry: 'reachable' })
  })

  it('park policy: notifies with manual-reopen marker and records the id in parked', async () => {
    const notify = vi.fn(async () => {})
    const injectSessionMessage = vi.fn()
    const followup = vi.fn()
    const tools = scopedTools({ read: {} })
    const ctx = makeCtx({ agents: { get: () => ({ followup }) }, tools })

    const resumed = await resumeInterrupted(ctx, ['proj/session-core-2'], {
      notify,
      injectSessionMessage,
      config: { resumeCoreToolPolicy: 'park' },
    })
    expect(resumed).toEqual(['proj/session-core-2'])

    expect(notify).toHaveBeenCalledTimes(1)
    expect(notify.mock.calls[0][0]).toContain('[bash]')
    expect(notify.mock.calls[0][0]).toContain('manual reopen required')

    const health = snapshotResumeToolHealth(ctx)
    expect(health.parked).toEqual(['session-core-2'])
  })

  it('no missing core tools -> no notify and no session message', async () => {
    const notify = vi.fn(async () => {})
    const injectSessionMessage = vi.fn()
    const followup = vi.fn()
    const tools = scopedTools({ bash: {}, read: {} })
    const ctx = makeCtx({ agents: { get: () => ({ followup }) }, tools })

    const resumed = await resumeInterrupted(ctx, ['proj/session-core-3'], { notify, injectSessionMessage })
    expect(resumed).toEqual(['proj/session-core-3'])
    expect(notify).not.toHaveBeenCalled()
    expect(injectSessionMessage).not.toHaveBeenCalled()
  })

  it('maestro_resume_tool_health RPC returns lastResumeProbe + parked (probe stubbed by scoped tools)', async () => {
    const notify = vi.fn(async () => {})
    const injectSessionMessage = vi.fn()
    const followup = vi.fn()
    const tools = scopedTools({ read: {} })
    const ctx = makeCtx({ agents: { get: () => ({ followup }) }, tools })

    await resumeInterrupted(ctx, ['proj/session-core-4'], {
      notify,
      injectSessionMessage,
      config: { resumeCoreToolPolicy: 'park' },
    })

    const handler = createResumeToolHealthRpcHandler(ctx)
    const res = await handler('health', {}, new AbortController().signal)
    expect(res).toEqual({
      ok: true,
      value: {
        lastResumeProbe: { missing: ['bash'], visible: 1, registry: 'reachable' },
        lastComposition: null,
        parked: ['session-core-4'],
      },
    })
  })

  it('warnCoreToolLoss is a no-op when bash is not among the missing tools', async () => {
    const notify = vi.fn(async () => {})
    const injectSessionMessage = vi.fn()
    const followup = vi.fn()
    const tools = scopedTools({ bash: {}, read: {} })
    const ctx = makeCtx({ agents: { get: () => ({ followup }) }, tools })

    await warnCoreToolLoss(ctx, 'session-core-5', 'session-core-5', { missing: ['cordis_inspect_query'], visible: 2 }, 'warn', {
      notify,
      injectSessionMessage,
      tools,
    })
    expect(notify).not.toHaveBeenCalled()
    expect(injectSessionMessage).not.toHaveBeenCalled()
  })

  it('buildToolInventoryMessage joins the available tools into the System: inventory line', () => {
    const msg = buildToolInventoryMessage(['bash'], ['read', 'write'])
    expect(msg).toContain('bash tool is unavailable')
    expect(msg).toContain('Available tools: read, write')
    expect(msg).toContain('Do not call bash')
  })
})

describe('C3 — resume→probe→warn orchestration contract (public resume path)', () => {
  // C3 pins the plugin-layer orchestration contract (controller ruling): the
  // resume flow MUST (a) always run the tool-view probe, (b) when bash (or any
  // CRITICAL_TOOLS name) is missing fire the notifier + inject the tool-
  // inventory message governed by `resumeCoreToolPolicy`, and (c) surface the
  // last probe result + parked ids through the maestro_resume_tool_health
  // RPC/tool. These specs drive the PUBLIC `createResumeRpcHandler` `resume`
  // endpoint (the same path the loopback RPC uses) with stub seams so a future
  // config refactor, dependency shuffle, or harness interaction that changes
  // or drops any leg of this contract fails the suite. deepseek-harness
  // internals (scope layers) are intentionally NOT depended on from this
  // plugin — the stubs only model the split the harness exposes (global view
  // always has every tool; the resumed session's SCOPED view may not).
  beforeEach(() => {
    resetResumeToolHealthState()
  })

  it('resumes → probes → warns + injects inventory on bash loss; default warn policy parks nothing', async () => {
    const notify = vi.fn(async () => {})
    const injected: { sid: string; content: string }[] = []
    const injectSessionMessage = vi.fn((sid: string, content: string) => { injected.push({ sid, content }) })
    const followup = vi.fn()
    const tools = scopedTools({ read: {} }) // resumed scope hides bash
    const ctx = makeCtx({ agents: { get: () => ({ followup }) }, tools })

    // Drive the public resume RPC endpoint — the mitigation runs inside the
    // real resumeInterrupted (notify + injectSessionMessage seams only).
    const handler = createResumeRpcHandler(ctx, { notify, injectSessionMessage })
    const res = await handler('resume', { ids: ['proj/session-c3-1'] }, new AbortController().signal)
    expect(res).toEqual({ ok: true, value: { resumed: ['proj/session-c3-1'] } })

    // (a) always probe → warn fired with the lost core-tool name.
    expect(notify).toHaveBeenCalledTimes(1)
    expect(notify.mock.calls[0][0]).toContain('[bash]')
    expect(notify.mock.calls[0][0]).toContain('reopen session if it persists')
    expect(notify.mock.calls[0][0]).not.toContain('manual reopen required')

    // (b) tool-inventory message injected into the session, scoped to what's
    //     actually available (never the global view).
    expect(injectSessionMessage).toHaveBeenCalledTimes(1)
    expect(injected[0].sid).toBe('session-c3-1')
    expect(injected[0].content).toContain('bash tool is unavailable')
    expect(injected[0].content).toContain('Available tools: read')
    expect(injected[0].content).toContain('Do not call bash')

    // (c) default 'warn' policy → the session is NOT parked.
    expect(snapshotResumeToolHealth(ctx).parked).toEqual([])
  })

  it('health RPC surfaces lastResumeProbe + parked after the public resume path', async () => {
    const notify = vi.fn(async () => {})
    const injectSessionMessage = vi.fn()
    const followup = vi.fn()
    const tools = scopedTools({ read: {} })
    const ctx = makeCtx({ agents: { get: () => ({ followup }) }, tools })

    await createResumeRpcHandler(ctx, { notify, injectSessionMessage })(
      'resume',
      { ids: ['proj/session-c3-2'] },
      new AbortController().signal,
    )

    const healthHandler = createResumeToolHealthRpcHandler(ctx)
    const res = await healthHandler('health', {}, new AbortController().signal)
    expect(res.ok).toBe(true)
    expect(res.value.lastResumeProbe).toEqual({ missing: ['bash'], visible: 1, registry: 'reachable' })
    expect(res.value.parked).toEqual([])
  })

  it('probe disabled (injected seam missing:[]) → no warn, no injection, nothing parked', async () => {
    const notify = vi.fn(async () => {})
    const injectSessionMessage = vi.fn()
    const followup = vi.fn()
    const tools = scopedTools({ read: {} }) // would hide bash, but the probe seam reports nothing missing
    const ctx = makeCtx({ agents: { get: () => ({ followup }) }, tools })

    const resumed = await resumeInterrupted(ctx, ['proj/session-c3-3'], {
      notify,
      injectSessionMessage,
      probeToolView: vi.fn(() => ({ missing: [] as string[], visible: 0 })),
    })
    expect(resumed).toEqual(['proj/session-c3-3'])
    expect(notify).not.toHaveBeenCalled()
    expect(injectSessionMessage).not.toHaveBeenCalled()
    expect(snapshotResumeToolHealth(ctx).parked).toEqual([])
  })
})

describe('probe reports registry reachability', () => {
  it('marks an unreadable registry unreachable instead of healthy', () => {
    expect(probeToolView(undefined, 'session-x')).toEqual({ missing: [], visible: 0, registry: 'unreachable' })
    expect(probeToolView({ schemas: () => [] } as unknown as ToolsLike, 'session-x'))
      .toEqual({ missing: [], visible: 0, registry: 'unreachable' })
  })

  it('reports reachable with the scoped count and the missing critical names', () => {
    const tools: ToolsLike = {
      get: (name: string, scope?: unknown) => (scope === 'S' && name === 'read' ? { name } : undefined),
      schemas: (scope?: unknown) => (scope === 'S' ? [{ name: 'read' }] : []),
    }
    expect(probeToolView(tools, 'S')).toEqual({ missing: ['bash'], visible: 1, registry: 'reachable' })
  })

  it('reports unreachable when the registry read throws instead of claiming health', () => {
    const tools = {
      get: () => { throw new Error('boom') },
      schemas: () => { throw new Error('boom') },
    } as unknown as ToolsLike
    expect(probeToolView(tools, 'S')).toEqual({ missing: [], visible: 0, registry: 'unreachable' })
  })

  it('renders both facts for the operator', () => {
    expect(summarizeToolView({ missing: ['bash'], visible: 1, registry: 'reachable' }))
      .toBe('missing=bash visible=1 registry=reachable')
    expect(summarizeToolView({ missing: [], visible: 0, registry: 'unreachable' }))
      .toBe('missing=none visible=0 registry=unreachable')
  })
})
