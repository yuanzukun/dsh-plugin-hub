import { describe, it, expect, vi, beforeEach, afterEach, afterAll } from 'vitest'
import { mkdtempSync, rmSync, readFileSync } from 'node:fs'
import { dirname, join } from 'node:path'
import { tmpdir } from 'node:os'
import { fileURLToPath } from 'node:url'
import {
  buildKillStalePortsCommand,
  clearPlannedRestart,
  checkPlannedRestart,
  isPlannedRestartFresh,
  readRestartRequest,
  writePlannedRestart,
  writeRestartRequest,
  markBootBoundary,
  BOOT_BOUNDARY_MARKER,
} from '../src/host/restart-guards.js'

// Point os.homedir() at a per-file temp home so every restart marker (the
// planned-restart.json JSON) lands under the temp
// dir instead of the real ~/.dsh. Without this the restart-guards tests
// collided with the LIVE dsh-web-supervisor daemon: under parallel vitest it
// reads/writes the real ~/.dsh/.supervisor/planned-restart.json at the same
// moment the daemon's health poll checks it, producing intermittent failures
// that blocked pushes.
let fakeHome = ''
beforeEach(() => {
  fakeHome = mkdtempSync(join(tmpdir(), 'dsh-restart-guards-home-'))
})
afterEach(() => {
  vi.unstubAllGlobals()
})
afterAll(() => {
  if (fakeHome) {
    try { rmSync(fakeHome, { recursive: true, force: true }) } catch {}
  }
})

vi.mock('node:os', async (importOriginal) => {
  const actual = await importOriginal<typeof import('node:os')>()
  return {
    ...actual,
    homedir: () => fakeHome,
  }
})

describe('buildKillStalePortsCommand', () => {
  it('only kills :3080, never :3000', () => {
    const cmd = buildKillStalePortsCommand()
    expect(cmd).toContain('sport = :3080')
    expect(cmd).not.toContain('sport = :3000')
  })

  it('scopes the ss filter to the given ports only', () => {
    const cmd = buildKillStalePortsCommand([3080, 3000])
    expect(cmd).toContain('sport = :3080')
    expect(cmd).toContain('sport = :3000')
  })

  it('never runs an unfiltered ss -tlnp (would match every listening process on the host)', () => {
    const cmd = buildKillStalePortsCommand([3080, 3000])
    // "ss -tlnp" must always be followed immediately by a port filter expression,
    // never piped straight into sed/kill unscoped (regression: killed unrelated
    // host services like redis/horizon on every restart).
    expect(cmd).not.toMatch(/ss -tlnp\s+2>\/dev\/null \| sed/)
  })

  it('defaults to the dsh web port when called with no args', () => {
    const cmd = buildKillStalePortsCommand()
    expect(cmd).toContain(':3080')
    expect(cmd).not.toContain(':3000')
  })
})

describe('isPlannedRestartFresh', () => {
  it('is fresh when mtime is recent', () => {
    expect(isPlannedRestartFresh(1000, 1000 + 60_000, 180_000)).toBe(true)
  })

  it('is stale once mtime is older than the TTL', () => {
    expect(isPlannedRestartFresh(0, 200_000, 180_000)).toBe(false)
  })

  it('treats the exact TTL boundary as stale (strictly less-than)', () => {
    expect(isPlannedRestartFresh(0, 180_000, 180_000)).toBe(false)
  })
})

describe('planned restart marker 30s', () => {
  it('writes/reads the marker under the temp home only (never the real ~/.dsh)', () => {
    clearPlannedRestart()
    expect(checkPlannedRestart()).toBe(false)
    writePlannedRestart(30000)
    expect(checkPlannedRestart()).toBe(true)
    const marker = join(fakeHome, '.dsh/.supervisor/planned-restart.json')
    const j = JSON.parse(readFileSync(marker, 'utf8'))
    expect(j.ttl).toBe(30000)
    expect(typeof j.ts).toBe('number')
    clearPlannedRestart()
    expect(checkPlannedRestart()).toBe(false)
  })
})

describe('restart-request marker', () => {
  it('persists caller metadata and reads it back; TTL expiry returns undefined', () => {
    clearPlannedRestart()
    expect(readRestartRequest()).toBeUndefined()
    writeRestartRequest({ callerSessionId: 'proj/s-1', reason: 'applied plugin v2' }, 180_000)
    const req = readRestartRequest()
    expect(req?.callerSessionId).toBe('proj/s-1')
    expect(req?.reason).toBe('applied plugin v2')
    expect(req?.ttl).toBe(180_000)
    // the marker really lives under the temp home — prove no real ~/.dsh touch
    expect(readFileSync(join(fakeHome, '.dsh/.supervisor/planned-restart.json'), 'utf8')).toContain('proj/s-1')
    clearPlannedRestart()
  })

  it('treats an expired marker as absent', () => {
    writeRestartRequest({ callerSessionId: 'x' }, -1) // ttl already elapsed
    expect(readRestartRequest()).toBeUndefined()
    clearPlannedRestart()
  })

  it('carries oldPid through the marker round-trip', () => {
    clearPlannedRestart()
    writeRestartRequest({ callerSessionId: 'proj/s-1', reason: 'r', oldPid: 4242 }, 180_000)
    expect(readRestartRequest()?.oldPid).toBe(4242)
    clearPlannedRestart()
  })
})

const restartScriptPath = join(
  dirname(fileURLToPath(import.meta.url)),
  '..',
  'skills',
  'dsh-safe-restart',
  'scripts',
  'restart-dsh-web.sh',
)

describe('restart-dsh-web.sh pre-flight', () => {
  const script = readFileSync(restartScriptPath, 'utf8')

  it('runs the session-log health scan before the fresh boot when SESSIONS_ROOT exists', () => {
    const preFlightIdx = script.indexOf('# Pre-flight')
    expect(preFlightIdx).toBeGreaterThan(-1)
    // The heal must happen BEFORE any (re)launch of dsh web — while the old
    // tree is stopped — so a live writer can never race the repair.
    const startIdx = script.indexOf('systemctl --user start dsh-web.service')
    expect(startIdx).toBeGreaterThan(-1)
    expect(preFlightIdx).toBeLessThan(startIdx)
    const guard = /# Pre-flight[\s\S]*?^\s*fi\s*$/m.exec(script)?.[0] ?? ''
    expect(guard.length).toBeGreaterThan(0)
    expect(guard).toMatch(/-n "\$SESSIONS_ROOT"/)
    expect(guard).toMatch(/-d "\$SESSIONS_ROOT"/)
    expect(guard).toContain('session-health.js')
    expect(guard).toContain('runSessionHealthCheck')
    expect(guard).toContain('repair: true, quarantine: false')
    expect(guard).toContain('process.env.SESSIONS_ROOT')
  })

  it('keeps the session-health pre-flight non-fatal so a transient scan error never blocks a restart', () => {
    const guard = /# Pre-flight[\s\S]*?^\s*fi\s*$/m.exec(script)?.[0] ?? ''
    expect(guard).toContain('|| true')
    // The pre-flight itself never aborts the script — the fatal paths
    // (fail '...' / exit <n>) belong to the gated restart steps, never to an
    // opportunistic heal.
    expect(guard).not.toContain("fail '")
    expect(guard).not.toMatch(/\bexit\s+[0-9]+/)
  })
})

describe('restart-dsh-web.sh port topology (local-pin-gate)', () => {
  const script = readFileSync(restartScriptPath, 'utf8')

  it('detects the dsh-web process on the new topology ports 3080/3081/3082 too', () => {
    expect(script).toContain("':(3000|3080|3081|3082)(")
    expect(script).not.toContain("':(3000|3080)(")
  })

  it('checks all topology ports are free before the fresh boot', () => {
    const loop = /for port in [^\n]+/m.exec(script)?.[0] ?? ''
    expect(loop).toContain('3000')
    expect(loop).toContain('3080')
    expect(loop).toContain('3081')
    expect(loop).toContain('3082')
  })

  it('accepts the PIN-proxy / raw-webserver health surfaces (200/401/303)', () => {
    // :3080 is the maestro PIN proxy (303 -> login flow, 200 when authed)
    // :3082 is the raw webserver under the local-pin-gate topology.
    expect(script).toMatch(/code_3080=.*3080/)
    expect(script).toMatch(/code_3082=.*3082/)
    expect(script).toMatch(/"\$code_3080" == 200 \|\| "\$code_3080" == 401 \|\| "\$code_3080" == 303/)
    expect(script).toMatch(/"\$code_3082" == 200 \|\| "\$code_3082" == 401/)
  })
})

describe('boot boundary sentinel', () => {
  it('appends a parseable boundary line so the poller can scope the log', () => {
    const logPath = join(fakeHome, 'dsh-web.log')
    markBootBoundary(logPath)
    const text = readFileSync(logPath, 'utf8')
    expect(text).toContain(BOOT_BOUNDARY_MARKER)
    const iso = text.replace(BOOT_BOUNDARY_MARKER, '').trim()
    expect(Number.isNaN(Date.parse(iso))).toBe(false)
  })

  it('never writes to the real dsh-web.log when no path is given', () => {
    // The default path is the operator's log; under VITEST markBootBoundary
    // must be a no-op so a unit test can never touch it.
    expect(() => markBootBoundary()).not.toThrow()
  })

  it('marks the boundary as part of writing the planned-restart marker', () => {
    // The boundary belongs to the restart: every sanctioned restart path writes
    // the planned-restart marker first, so the scan can scope to the new boot.
    const logPath = join(fakeHome, 'dsh-web.log')
    process.env.DSH_WEB_LOG = logPath
    try {
      writePlannedRestart(30000)
    } finally {
      delete process.env.DSH_WEB_LOG
    }
    expect(readFileSync(logPath, 'utf8')).toContain(BOOT_BOUNDARY_MARKER)
  })
})
