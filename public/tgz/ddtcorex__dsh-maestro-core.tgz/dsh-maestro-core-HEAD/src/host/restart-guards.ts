import * as fs from 'node:fs'
import * as path from 'node:path'
import * as os from 'node:os'

// Regression guard: PR #17 added a "kill stale pid holding :3080/:3000 before
// restart" step (EADDRINUSE recovery), but the original `ss -tlnp` call had no
// port filter — it matched every listening process on the host, so every
// restart also killed unrelated services (redis, php-fpm, horizon, ssh, ...).
// The dsh-web MainThread holds both 3080 and 3000 (see AGENTS.md Known Issues),
// so filtering `ss` itself to those ports is both correct and sufficient.
export function buildKillStalePortsCommand(ports: number[] = [3080]): string {
  const filter = ports.map(p => `sport = :${p}`).join(' or ')
  return `pids=$(ss -tlnp '( ${filter} )' 2>/dev/null | sed -n 's/.*pid=\\([0-9]*\\).*/\\1/p' | sort -u); if [ -n "$pids" ]; then echo "[supervisor] killing stale pids $pids"; kill $pids 2>/dev/null || true; sleep 2; fi`
}

/**
 * Sentinel appended to dsh-web.log immediately before a supervised restart.
 *
 * The log is append-only and carries no timestamps, so this line is the only
 * durable ordering between "the previous boot's crash" and "this boot's
 * output". Without it the health scan inherited the previous, failed boot's
 * `EADDRINUSE` stack and rolled back a healthy, still-booting instance
 * (incident 2026-09-13).
 */
export const BOOT_BOUNDARY_MARKER = '[supervisor] boot-boundary'

/** The production dsh-web log (override with DSH_WEB_LOG for tests/tools). */
export function dshWebLogPath(): string {
  return process.env.DSH_WEB_LOG ?? path.join(os.homedir(), '.dsh/dsh-web.log')
}

/**
 * Append the boot-boundary sentinel. Pass an explicit `logPath` in tests, or
 * redirect with DSH_WEB_LOG. With no destination at all under VITEST this is a
 * deliberate no-op so a unit test can never append to the operator's real log.
 */
export function markBootBoundary(logPath?: string): void {
  const explicit = logPath ?? process.env.DSH_WEB_LOG
  if (explicit === undefined && process.env.VITEST) return
  const p = explicit ?? dshWebLogPath()
  try {
    fs.mkdirSync(path.dirname(p), { recursive: true })
    fs.appendFileSync(p, `${BOOT_BOUNDARY_MARKER} ${new Date().toISOString()}\n`)
  } catch {}
}

// Coordination contract with dsh-safe-web-update's restart-dsh-web.sh (see
// <workspace-root>/docs/specs/2026-09-13-supervisor-restart-resilience-design.md):
// that script writes this marker right before it intentionally takes dsh-web
// down, so the supervisor's own health poll does not mistake a deliberate
// restart (kill -> dry-boot -> relaunch, up to ~130s) for a crash and race it
// with its own restartWeb(). The marker is the JSON {ts, ttl}
// document at planned-restart.json; a plain mtime-only file is no longer read.
export const PLANNED_RESTART_TTL_MS = 180_000

export function isPlannedRestartFresh(mtimeMs: number, nowMs: number, ttlMs: number = PLANNED_RESTART_TTL_MS): boolean {
  return nowMs - mtimeMs < ttlMs
}

export function plannedRestartPath(): string {
  return path.join(os.homedir(), '.dsh/.supervisor/planned-restart.json')
}

export function writePlannedRestart(ttlMs = 30000): void {
  const p = plannedRestartPath()
  fs.mkdirSync(path.dirname(p), { recursive: true })
  fs.writeFileSync(p, JSON.stringify({ ts: Date.now(), ttl: ttlMs }), { mode: 0o600 })
  try { fs.chmodSync(p, 0o600) } catch {}
  // The boundary belongs to the restart, not to the poller: every sanctioned
  // restart path already writes this marker first.
  markBootBoundary()
}

export function checkPlannedRestart(): boolean {
  // New JSON marker with {ts, ttl}
  try {
    const raw = fs.readFileSync(plannedRestartPath(), 'utf8')
    const j = JSON.parse(raw) as { ts?: unknown; ttl?: unknown }
    if (typeof j.ts === 'number' && typeof j.ttl === 'number') {
      return Date.now() - j.ts < j.ttl
    }
  } catch {}
  return false
}

export function clearPlannedRestart(): void {
  try { fs.unlinkSync(plannedRestartPath()) } catch {}
}

// Restart-request variant of planned-restart.json: carries the caller's
// identity and intent so the dsh_web_restart tool (Task 3) and the daemon
// (Task 4) can attribute a restart to the session that requested it. Reuses
// the same marker path — writePlannedRestart/checkPlannedRestart keep working
// on {ts, ttl} only, while this adds callerSessionId + reason for later tasks.
export interface RestartRequest { ts: number; ttl: number; callerSessionId?: string; reason?: string; oldPid?: number }

export function writeRestartRequest(caller: { callerSessionId?: string; reason?: string; oldPid?: number }, ttlMs = 180_000): void {
  const p = plannedRestartPath()
  fs.mkdirSync(path.dirname(p), { recursive: true })
  const body: RestartRequest = { ts: Date.now(), ttl: ttlMs, ...caller }
  fs.writeFileSync(p, JSON.stringify(body), { mode: 0o600 })
  try { fs.chmodSync(p, 0o600) } catch {}
}

export function readRestartRequest(): RestartRequest | undefined {
  try {
    const raw = fs.readFileSync(plannedRestartPath(), 'utf8')
    const j = JSON.parse(raw) as Partial<RestartRequest>
    if (typeof j.ts === 'number' && typeof j.ttl === 'number') {
      if (Date.now() - j.ts >= j.ttl) return undefined
      return { ts: j.ts, ttl: j.ttl, callerSessionId: j.callerSessionId, reason: j.reason, oldPid: j.oldPid }
    }
  } catch {}
  return undefined
}
