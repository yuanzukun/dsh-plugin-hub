import * as lib from '../store/index.js'
// Guard and guardBlacklist writes through the Settings card must always be validated.
import '../guard/validators.js'

export interface MaestroConfigService {
  /** Union of schema-registered domains and domains present in the store file. */
  listDomains(): Promise<string[]>
  get(domain: string): Promise<unknown>
  /** Deep-merges the patch into the domain (same semantics as the lib). */
  set(domain: string, patch: object): Promise<void>
  /** Deletes one top-level key of a domain; false when there was nothing to delete. */
  unset(domain: string, key: string): Promise<boolean>
  onChange(cb: (domain: string) => void): () => void
}

/**
 * Thin facade over the embedded settings store (`../store`). `dshHome` defaults to the
 * the store's resolution (explicit > DSH_HOME env > ~/.dsh); tests inject a tmpdir.
 */
export function createMaestroConfigService(opts?: { dshHome?: string }): MaestroConfigService {
  const libOpts = opts?.dshHome ? { dshHome: opts.dshHome } : undefined
  return {
    async listDomains() {
      const doc = await lib.load(libOpts)
      return [...new Set([...lib.definedDomains(), ...Object.keys(doc.domains)])]
    },
    async get(domain) {
      return lib.get(domain, libOpts)
    },
    async set(domain, patch) {
      await lib.set(domain, patch, libOpts)
    },
    async unset(domain, key) {
      return lib.unset(domain, key, libOpts)
    },
    onChange(cb) {
      return lib.onChange(cb)
    },
  }
}
