import { classifyFetchFailure, type HealthState } from './health-poller.js'
import { runDebugAgent } from './debug-agent.js'
import { findInterrupted as defaultFindInterrupted, parseDuration } from './resume.js'
import * as fs from 'node:fs'
import * as path from 'node:path'
import * as os from 'node:os'
import { resolveHarnessRoot, readSettingsDocSync } from './paths.js'
import { readSupervisorConfig } from './config.js'
import { writePlannedRestart as defaultWritePlannedRestart, checkPlannedRestart as defaultCheckPlannedRestart, clearPlannedRestart } from './restart-guards.js'
import type { RestartRequest } from './restart-guards.js'
import { writeRestartOutcome as defaultWriteOutcome, type RestartOutcome } from './intents.js'
import { execFileSync } from 'node:child_process'
import { mintDshSessionCookie, type MintCookieOpts } from './dsh-session.js'

export interface SupervisorDeps {
  pollHealth: () => Promise<HealthState>;
  writeReport: (opts: { ts: string; health: HealthState; action: string; logTail?: string; gitDiff?: string }) => Promise<string>;
  restartWeb?: () => Promise<void>;
  notify: (msg: string) => Promise<void>
  intervalMs?: number
  debounceMs?: number
  // Number of consecutive "down" polls required before a crash is confirmed
  // and restart fires. A single transient poll failure (e.g. a
  // fetch timeout while the plugin tree is still booting) must not trigger
  // a restart — that restart itself produces transient errors on the
  // next poll, which would otherwise re-trigger endlessly. Default 3 (at the
  // daemon's 3s interval, ~9s of continuous down before acting).
  downThreshold?: number
  // Boot budget in ms (default 180_000). A boot younger than this that has not
  // printed its own success marker is unproven: weak failures and degraded
  // verdicts must not advance the counters (incident 2026-09-13).
  bootGraceMs?: number
  getTime?: () => number
  // Checks the dsh-safe-web-update marker (see
  // <workspace-root>/docs/specs/2026-09-13-supervisor-restart-resilience-design.md): a down poll
  // while this resolves true is an intentional restart in progress, not a
  // crash — skip restartWeb entirely rather than racing it.
  isPlannedRestartActive?: () => boolean | Promise<boolean>
  // 30s planned-restart marker (restart-guards.ts): single owner for restart
  // decisions. Injected for tests so tick/restartWeb can be verified without
  // touching the filesystem.
  writePlannedRestart?: (ttlMs?: number) => void
  checkPlannedRestart?: () => boolean
  // Clears the restart-request/planned-restart marker; injectable for tests so
  // the re-arm decision after a self-restart can be verified without fs.
  clearPlannedRestart?: () => void
  // injectable for test / LLM wiring
  runDebugAgent?: (opts: { reportPath: string; health: HealthState }) => Promise<{ fixed: boolean; reason: string }>
  findInterrupted?: () => Promise<{ scanned: number; interrupted: string[] }>
  resumeSessions?: (ids: string[]) => Promise<{ resumed: string[] }>
  // dsh_web_restart hand-off (restart-tool.ts): the daemon is the restart
  // owner. Reads the caller marker and, after a ~5s grace, restarts dsh web
  // once (single-flight per marker), notifies, then clears the marker.
  readRestartRequest?: () => RestartRequest | undefined
  onRestartRequestHandled?: (req: RestartRequest) => void
  // Outcome sink for supervised restarts (intents.ts sidecar); injectable so
  // tick() tests never touch the real ~/.dsh.
  writeOutcome?: (sessionId: string, outcome: RestartOutcome) => void
  // PID of the process listening on a port (ss parse); injectable for tests.
  listenerPid?: (port: number) => number | undefined
}

/** PID holding a 127.0.0.1 listener on the port, or undefined. Never throws. */
export function defaultListenerPid(port: number): number | undefined {
  try {
    const out = execFileSync('ss', ['-tlnp'], { encoding: 'utf8' })
    for (const line of out.split('\n')) {
      const m = new RegExp(`127\\.0\\.0\\.1:${port}\\s[^]*?pid=(\\d+)`).exec(line)
      if (m) return Number(m[1])
    }
  } catch {}
  return undefined
}

export async function resumeViaRpc(
  ids: string[],
  fetchFn: (url: string, init: RequestInit) => Promise<Response> = globalThis.fetch,
  extraHeaders: Record<string, string> = {},
): Promise<{ resumed: string[] }> {
  const rpcId = crypto.randomUUID()
  const response = await fetchFn('http://127.0.0.1:3080/dsh-maestro-supervisor-resume/resume', {
    method: 'POST',
    headers: { 'content-type': 'application/json', ...extraHeaders },
    body: JSON.stringify({ type: 'client-request', rpcId, method: 'resume', payload: { ids } }),
  })
  if (!response.ok) throw new Error(`resume RPC returned HTTP ${response.status}`)

  const envelope = await response.json() as any
  const resumed = envelope?.type === 'server-response'
    && envelope?.rpcId === rpcId
    && envelope?.result?.ok === true
    && Array.isArray(envelope?.result?.value?.resumed)
    ? envelope.result.value.resumed.filter((id: unknown): id is string => typeof id === 'string')
    : undefined
  if (resumed === undefined) throw new Error('resume RPC returned an invalid result')
  return { resumed }
}

/**
 * Daemon default resume path: mint the `dsh-auth-*` session cookie first (the
 * `/resume` RPC sits behind the raw webserver's browser-trust fence, which 401s
 * cookie-less loopback calls since the local-pin-gate topology moved the
 * webserver behind the PIN proxies) and attach it to the POST. Falls back to an
 * unauthenticated POST when no boot token is readable — old behavior preserved.
 */
export async function resumeViaRpcWithSession(
  ids: string[],
  fetchFn: (url: string, init: RequestInit) => Promise<Response> = globalThis.fetch,
  opts: MintCookieOpts = {},
): Promise<{ resumed: string[] }> {
  let cookie: string | undefined
  try { cookie = await mintDshSessionCookie(fetchFn, opts) } catch { cookie = undefined }
  return resumeViaRpc(ids, fetchFn, cookie === undefined ? {} : { cookie })
}

export class Supervisor {
  private deps: SupervisorDeps
  private lastRestart = 0
  private restarting = false
  private lastDegradedNotify = 0
  private consecutiveDown = 0
  private consecutiveDegraded = 0
  private timer: ReturnType<typeof setInterval> | null = null
  private restartRequestHandled = false
  private restartRequestTimer: ReturnType<typeof setTimeout> | null = null
  private awaitingHealthyBoot = false
  private pendingRestartRequest: RestartRequest | undefined

  constructor(deps: SupervisorDeps) {
    this.deps = deps
  }

  private getWritePlannedRestart(): (ttlMs?: number) => void {
    return this.deps.writePlannedRestart ?? defaultWritePlannedRestart
  }

  private getCheckPlannedRestart(): () => boolean {
    return this.deps.checkPlannedRestart ?? defaultCheckPlannedRestart
  }

  private getClearPlannedRestart(): () => void {
    return this.deps.clearPlannedRestart ?? clearPlannedRestart
  }

  async restartWeb(): Promise<void> {
    const grace = await this.getEffectiveBootGraceMs()
    // Marker first, and its TTL is the boot budget — not 30 s. The observed
    // boot took 1m52s: after +30 s every poll was judged as a crash, which is
    // exactly how the 2026-09-13 crash report was produced (D5).
    this.getWritePlannedRestart()(grace)
    if (this.deps.restartWeb) {
      // Injected implementation (cli.ts daemon wiring, tests): it owns the
      // boot lock, so the single-flight guarantee stays in one place.
      await this.deps.restartWeb()
      return
    }
    const { performSingleBootRestart } = await import('./restart-web.js')
    const res = await performSingleBootRestart({ bootGraceMs: grace })
    if (!res.restarted) {
      await this.deps.notify(`restart skipped: ${res.reason ?? 'boot lock held'}`).catch(() => {})
    }
  }

  private getRunDebugAgent() {
    return this.deps.runDebugAgent ?? runDebugAgent
  }

  private getFindInterrupted() {
    return this.deps.findInterrupted ?? defaultFindInterrupted
  }

  private getResumeSessions() {
    return this.deps.resumeSessions ?? resumeViaRpcWithSession
  }

  private getAutoResumeEnabled(): boolean {
    // Priority: env > supervisor config.json > maestro settings.json > default true (enabled)
    // Configures whether interrupted sessions are auto-resumed after restart (vs only notify).
    // For Settings UI: boolean toggle — true = auto-resume within window, false = notify only.
    const env = process.env.DSH_SUPERVISOR_AUTO_RESUME
    if (env !== undefined) {
      const v = env.trim().toLowerCase()
      if (['1','true','yes','on','enabled'].includes(v)) return true
      if (['0','false','no','off','disabled'].includes(v)) return false
    }
    try {
      const cfgPath = path.join(os.homedir(), '.dsh/.supervisor/config.json')
      if (fs.existsSync(cfgPath)) {
        const cfg = JSON.parse(fs.readFileSync(cfgPath, 'utf-8'))
        const raw = (cfg as any).autoResumeEnabled ?? (cfg as any).autoResume
        if (typeof raw === 'boolean') return raw
        if (typeof raw === 'string') {
          const v = raw.trim().toLowerCase()
          if (['1','true','yes','on'].includes(v)) return true
          if (['0','false','no','off'].includes(v)) return false
        }
      }
      const j = readSettingsDocSync()
      if (j) {
        const raw = j?.domains?.supervisor?.autoResumeEnabled ?? j?.supervisor?.autoResumeEnabled ?? j?.domains?.supervisor?.autoResume ?? j?.supervisor?.autoResume
        if (typeof raw === 'boolean') return raw
        if (typeof raw === 'string') {
          const v = raw.trim().toLowerCase()
          if (['1','true','yes','on'].includes(v)) return true
          if (['0','false','no','off'].includes(v)) return false
        }
      }
    } catch {}
    return true // default enabled
  }

  private getResumeWithinMs(): number {
    // Priority: env > supervisor config.json > maestro settings.json > default 5 (minutes)
    // Note: config value is in MINUTES (number 5 = 5 minutes). String "5m"/"30s"/"1h" also supported via parseDuration.
    const env = process.env.DSH_SUPERVISOR_RESUME_WITHIN
    if (env) {
      // Bare number in env like "5" → treat as minutes for ergonomics
      if (/^\d+$/.test(env.trim())) {
        const n = parseInt(env.trim(), 10)
        if (!isNaN(n)) return n * 60 * 1000
      }
      const v = parseDuration(env)
      if (v !== undefined) return v
      const n = parseInt(env, 10)
      if (!isNaN(n)) return n
    }
    try {
      const cfgPath = path.join(os.homedir(), '.dsh/.supervisor/config.json')
      if (fs.existsSync(cfgPath)) {
        const cfg = JSON.parse(fs.readFileSync(cfgPath, 'utf-8'))
        const raw = (cfg as any).autoResumeWithin ?? (cfg as any).resumeWithin
        if (typeof raw === 'string') {
          if (/^\d+$/.test(raw.trim())) return parseInt(raw.trim(), 10) * 60 * 1000 // bare string digits → minutes
          const v = parseDuration(raw)
          if (v !== undefined) return v
        } else if (typeof raw === 'number') return raw * 60 * 1000 // number is MINUTES
      }
      const j = readSettingsDocSync()
      if (j) {
        const raw = j?.domains?.supervisor?.autoResumeWithin ?? j?.supervisor?.autoResumeWithin
        if (typeof raw === 'string') {
          if (/^\d+$/.test(raw.trim())) return parseInt(raw.trim(), 10) * 60 * 1000
          const v = parseDuration(raw)
          if (v !== undefined) return v
        } else if (typeof raw === 'number') return raw * 60 * 1000
      }
    } catch {}
    return 5 * 60 * 1000 // default 5 minutes
  }

  private async getEffectiveIntervalMs(): Promise<number> {
    if (this.deps.intervalMs !== undefined) return this.deps.intervalMs
    try {
      const cfg = await readSupervisorConfig()
      if (typeof (cfg as any).intervalMs === 'number' && (cfg as any).intervalMs > 0) return (cfg as any).intervalMs
    } catch {}
    return 5000
  }

  private async getEffectiveDownThreshold(): Promise<number> {
    if (this.deps.downThreshold !== undefined) return this.deps.downThreshold
    try {
      const cfg = await readSupervisorConfig()
      if (typeof (cfg as any).downThreshold === 'number' && (cfg as any).downThreshold > 0) return (cfg as any).downThreshold
    } catch {}
    return 6
  }

  private async getEffectiveDegradedThreshold(): Promise<number> {
    try {
      const cfg = await readSupervisorConfig()
      if (typeof (cfg as any).degradedThreshold === 'number' && (cfg as any).degradedThreshold > 0) return (cfg as any).degradedThreshold
    } catch {}
    return 5
  }

  private async getEffectiveBootGraceMs(): Promise<number> {
    if (this.deps.bootGraceMs !== undefined) return this.deps.bootGraceMs
    try {
      const cfg = await readSupervisorConfig()
      if (typeof (cfg as any).bootGraceMs === 'number' && (cfg as any).bootGraceMs > 0) return (cfg as any).bootGraceMs
    } catch {}
    return 180_000
  }

  private async findInterruptedRecent(withinMs?: number): Promise<{ scanned: number; interrupted: string[] }> {
    const ms = withinMs ?? this.getResumeWithinMs()
    // Prefer injected mock for testability
    if (this.deps.findInterrupted) {
      try {
        const res = await this.deps.findInterrupted()
        // If mock doesn't filter by time, we still return as-is (test expects all)
        // For real filtering when mock is not time-aware, try to filter via resume module if possible
        if (ms !== undefined && res.interrupted.length) {
          try {
            const { findInterrupted } = await import('./resume.js')
            // Re-query with time filter for real filesystem; if mock was used for test, keep mock result
            if (process.env.VITEST) return res
            return findInterrupted(undefined, { withinMs: ms })
          } catch {}
        }
        return res
      } catch {
        // fallback to real
      }
    }
    try {
      const { findInterrupted } = await import('./resume.js')
      return findInterrupted(undefined, { withinMs: ms })
    } catch {
      return this.getFindInterrupted()()
    }
  }

  private async collectGitDiff(): Promise<string> {
    try {
      const { execSync } = await import('node:child_process')
      const ws = resolveHarnessRoot()
      try {
        const out = execSync(`git -C ${JSON.stringify(ws)} status --porcelain 2>/dev/null | head -n 50`, { encoding: 'utf-8', timeout: 2000 })
        if (out.trim()) {
          const diff = execSync(`git -C ${JSON.stringify(ws)} diff 2>/dev/null | head -n 200`, { encoding: 'utf-8', timeout: 2000 })
          return diff || out
        }
      } catch {}
      const diff = execSync('git diff 2>/dev/null | head -n 200', { encoding: 'utf-8', timeout: 2000 })
      return diff.trim() ? diff : ''
    } catch {
      return ''
    }
  }

  private async attemptAutoResume(ids: string[]): Promise<void> {
    if (!ids.length) return
    if (!this.getAutoResumeEnabled()) {
      await this.deps.notify(`RESUME: ${ids.length} interrupted sessions (${ids.slice(0, 3).join(', ')}) — auto-resume disabled`).catch(() => {})
      return
    }
    try {
      const { resumed } = await this.getResumeSessions()(ids)
      if (!resumed.length) {
        await this.deps.notify(`RESUME SKIPPED: no interrupted sessions could be re-attached (${ids.slice(0, 3).join(', ')})`).catch(() => {})
        return
      }
      await this.deps.notify(`RESUME: ${resumed.length} interrupted sessions — continue triggered (${resumed.slice(0, 3).join(', ')})`).catch(() => {})
    } catch (e: any) {
      await this.deps.notify(`RESUME FAILED: ${ids.length} interrupted sessions (${ids.slice(0, 3).join(', ')}) — ${e?.message ?? String(e)}`).catch(() => {})
    }
  }

  private handleDebugResult(reportPath: string, res: { fixed: boolean; reason: string }): void {
    if (res.fixed) {
      void this.deps.notify(`FIXED: debug-agent fixed ${reportPath} — ${res.reason}`).catch(() => {})
      // After fix, try to resume interrupted sessions (only recent, default 5 from config, in minutes)
      void this.findInterruptedRecent().then(r => {
        if (r.interrupted.length) void this.attemptAutoResume(r.interrupted).catch(() => {})
      }).catch(() => {})
    } else if (res.reason.includes('max attempts')) {
      void this.deps.notify(`FIX FAILED after 3 attempts — needs human (report: ${reportPath}, reason: ${res.reason})`).catch(() => {})
    } else if (res.reason.includes('cooldown')) {
      // silent — cooldown, no notify
    } else {
      // non-fixed but not max attempts — still surface for visibility
      void this.deps.notify(`FIX FAILED: ${res.reason} (report: ${reportPath})`).catch(() => {})
    }
  }

  async tick(): Promise<void> {
    const health = await this.deps.pollHealth()

    // dsh_web_restart hand-off: the tool wrote a caller marker and handed the
    // restart to the daemon (out-of-band). Honor one request per marker — one
    // grace timer → restartWeb once → notify. The suppression marker and the
    // single-flight latch are held until a post-restart health.up tick clears
    // them, so the in-flight down of our own restart can never be mistaken for
    // a crash and raced with a second restart by the crash path.
    const restartReq = this.deps.readRestartRequest ? this.deps.readRestartRequest() : undefined
    if (restartReq?.callerSessionId && !this.restartRequestHandled) {
      this.restartRequestHandled = true
      this.restartRequestTimer = setTimeout(() => {
        void (async () => {
          try {
            // Debounce crash handling from the moment the restart is issued —
            // the crash path sets lastRestart the same way. A slow boot must
            // not be classified as a crash even after the suppression marker's
            // own 30s TTL runs out.
            this.lastRestart = this.deps.getTime ? this.deps.getTime() : Date.now()
            await this.restartWeb()
            // restartWeb() already wrote the marker with the boot budget as its
            // TTL; the marker is cleared on the first healthy poll instead.
            await this.deps.notify(`restarted dsh-web after self-restart by session ${restartReq.callerSessionId}`)
          } catch (e: any) {
            await this.deps.notify(`self-restart dsh-web failed: ${e?.message ?? String(e)}`).catch(() => {})
            if (restartReq.callerSessionId) {
              try {
                ;(this.deps.writeOutcome ?? defaultWriteOutcome)(restartReq.callerSessionId, {
                state: 'failed',
                oldPid: restartReq.oldPid,
                swappedAt: this.deps.getTime ? this.deps.getTime() : Date.now(),
                error: e?.message ?? String(e),
              })
            } catch {}
            }
          } finally {
            // Hold the marker and latch until health.up: clearing here would
            // drop crash suppression mid-restart, and re-arming here would let
            // a still-present marker re-fire into a second restart.
            this.awaitingHealthyBoot = true
            this.pendingRestartRequest = restartReq
            this.restartRequestTimer = null
          }
        })()
      }, 5000)
      return
    }

    // DEGRADED: http 200 but log has plugin error → report + notify, restart after consecutive threshold
    if (health.degraded) {
      this.consecutiveDown = 0
      // D1: a degraded verdict while the current boot is unproven is a boot
      // transient, not a plugin error — the incident's report line
      // "restart — degraded: This operation was aborted" was produced exactly
      // here, five polls after a slow boot.
      if (health.bootPhase === 'booting') {
        this.consecutiveDegraded = 0
        return
      }
      // Check suppression first — don't count degraded during planned restart grace
      let suppressedByMarkerDeg = false
      try { suppressedByMarkerDeg = this.getCheckPlannedRestart()() } catch { suppressedByMarkerDeg = false }
      if (suppressedByMarkerDeg) {
        this.consecutiveDegraded = 0
        return
      }
      if (this.deps.isPlannedRestartActive) {
        let planned = false
        try { planned = await Promise.resolve(this.deps.isPlannedRestartActive()) } catch { planned = false }
        if (planned) { this.consecutiveDegraded = 0; return }
      }
      const now = this.deps.getTime ? this.deps.getTime() : Date.now()
      // degraded needs consecutive hits to avoid flapping — Option A 2026-09-03: 3→5 (via config)
      const degradedThreshold = await this.getEffectiveDegradedThreshold()
      this.consecutiveDegraded++
      if (this.consecutiveDegraded < degradedThreshold) {
        if (now - this.lastDegradedNotify < 60000) return
        this.lastDegradedNotify = now
        try {
          const ts = new Date().toISOString().replace(/[:.]/g, '-')
          const logTail = (health as any).logTail ?? ''
          const gitDiff = await this.collectGitDiff().catch(() => '')
          const reportPath = await this.deps.writeReport({ ts, health, action: `degraded — ${health.error ?? 'plugin'}`, logTail, gitDiff }).catch(() => '')
          await this.deps.notify(`DEGRADED: ${health.error ?? 'plugin'} (report: ${reportPath})`).catch(() => {})
          const runner = this.getRunDebugAgent()
          const isInjected = !!this.deps.runDebugAgent
          if (isInjected) {
            void runner({ reportPath, health }).then(res => this.handleDebugResult(reportPath, res)).catch(() => {})
            setTimeout(() => {
              this.findInterruptedRecent().then(r => {
                if (r.interrupted.length) void this.attemptAutoResume(r.interrupted).catch(() => {})
              }).catch(() => {})
            }, 0)
          } else if (!process.env.VITEST) {
            void runner({ reportPath, health }).then(res => this.handleDebugResult(reportPath, res)).catch(() => {})
            setTimeout(() => {
              this.findInterruptedRecent().then(r => {
                if (r.interrupted.length) void this.attemptAutoResume(r.interrupted).catch(() => {})
              }).catch(() => {})
            }, 0)
          }
        } catch {}
        return
      }
      // consecutive degraded threshold reached → treat as down: report + restart
      this.consecutiveDegraded = 0
      const degradedError = health.error ?? 'degraded plugin error'
      if (this.restarting) return
      const now2 = this.deps.getTime ? this.deps.getTime() : Date.now()
      const debounceMs2 = this.deps.debounceMs ?? 60000
      if (now2 - this.lastRestart < debounceMs2) return
      this.restarting = true
      this.lastRestart = now2
      try {
        const ts2 = new Date().toISOString().replace(/[:.]/g, '-')
        const logTail2 = (health as any).logTail ?? ''
        const gitDiff2 = await this.collectGitDiff().catch(() => '')
        const degradedHealth: HealthState = { up: false, httpCode: health.httpCode, error: `degraded → down: ${degradedError}`, logTail: logTail2, degraded: false }
        const reportPath2 = await this.deps.writeReport({ ts: ts2, health: degradedHealth, action: `restart — degraded: ${degradedError}`, logTail: logTail2, gitDiff: gitDiff2 }).catch(() => '')
        if (this.deps.restartWeb) {
          try { await this.deps.restartWeb(); await this.deps.notify(`restarted dsh-web (report: ${reportPath2})`).catch(() => {}) } catch (e: any) { await this.deps.notify(`restart dsh-web failed: ${e?.message ?? String(e)} (report: ${reportPath2})`).catch(() => {}) }
        }
        await this.deps.notify(`DEGRADED → restart (report: ${reportPath2}, error: ${degradedError})`).catch(() => {})
        try { await this.deps.notify(`🔄 dsh web auto-restart — degraded: ${degradedError} — ${new Date().toISOString()}`).catch(() => {}) } catch {}
      } finally { this.restarting = false }
      return
    }

    if (health.up) {
      this.consecutiveDown = 0
      this.consecutiveDegraded = 0
      // D5: a healthy poll is the authoritative "the restart succeeded"
      // signal — clear the suppression marker here instead of waiting for its
      // TTL, so a stale marker can never mute a later real crash.
      let markerClearedThisTick = false
      try {
        if (this.getCheckPlannedRestart()()) {
          this.getClearPlannedRestart()()
          markerClearedThisTick = true
        }
      } catch {}
      // Post-self-restart boot proved healthy: run the post-restart
      // session-scan hook and re-arm the single-flight latch. A failed clear
      // keeps the latch set so the same marker is never re-handled into a
      // second restart.
      if (this.awaitingHealthyBoot) {
        this.awaitingHealthyBoot = false
        const req = this.pendingRestartRequest
        this.pendingRestartRequest = undefined
        let cleared = markerClearedThisTick
        if (!cleared) {
          try { this.getClearPlannedRestart()(); cleared = true } catch {}
        }
        if (cleared) this.restartRequestHandled = false
        if (req) {
          try { this.deps.onRestartRequestHandled?.(req) } catch {}
          if (req.callerSessionId) {
            try {
              const listen = this.deps.listenerPid ?? defaultListenerPid
              ;(this.deps.writeOutcome ?? defaultWriteOutcome)(req.callerSessionId, {
                state: 'ok',
                oldPid: req.oldPid,
                newPid: listen(3082),
                httpStatus: (health as any)?.httpCode ?? 200,
                swappedAt: this.deps.getTime ? this.deps.getTime() : Date.now(),
              })
            } catch {}
          }
        }
      }
      return
    }

    // Single-owner 30s marker: planned restart in progress — suppress crash
    // handling entirely for 30s (no writeReport/restart).
    // Check both the new JSON marker (writePlannedRestart) and the legacy
    // isPlannedRestartActive (dsh-safe-web-update plain file) for compat.
    let suppressedByMarker = false
    try { suppressedByMarker = this.getCheckPlannedRestart()() } catch { suppressedByMarker = false }
    if (suppressedByMarker) {
      this.consecutiveDown = 0
      return
    }

    // Down while an intentional restart (e.g. dsh-safe-web-update) is in
    // flight is expected, not a crash — never race it with our own
    // restartWeb.
    if (this.deps.isPlannedRestartActive) {
      let planned = false
      try { planned = await Promise.resolve(this.deps.isPlannedRestartActive()) } catch { planned = false }
      if (planned) {
        this.consecutiveDown = 0
        return
      }
    }

    // Down — require consecutive confirmations before treating as a crash.
    // A lone timed-out poll (e.g. a slow plugin-tree boot) must not trigger
    // restart: that restart produces its own transient errors on
    // the next poll, which would otherwise re-trigger this same path forever.
    // D1/D2: while the boot is unproven only a refused connection may advance
    // the down counter — nothing is listening, so the process is gone. A
    // timeout/abort (or anything unattributable) is a slow boot, not a crash.
    if (health.bootPhase === 'booting' && classifyFetchFailure(health.error) !== 'refused') {
      this.consecutiveDown = 0
      return
    }
    this.consecutiveDown++
    let downThreshold = await this.getEffectiveDownThreshold()
    // When a planned restart marker is active, double the threshold (3→6 at
    // 3s interval ≈ 9s→18s). Health-poller already suppresses fetch failed in
    // this window, but supervisor also doubles so a transient that escapes
    // health still needs longer to trigger. The early return above already
    // suppresses fully for 30s; doubling remains for the legacy
    // isPlannedRestartActive path and for any race where the marker was
    // written between the early check and this line.
    try {
      if (this.getCheckPlannedRestart()()) downThreshold *= 2
    } catch {}
    if (this.consecutiveDown < downThreshold) return

    // Down — check debounce and restarting state
    if (this.restarting) return
    const now = this.deps.getTime ? this.deps.getTime() : Date.now()
    const debounceMs = this.deps.debounceMs ?? 60000
    if (now - this.lastRestart < debounceMs) return

    this.restarting = true
    this.consecutiveDown = 0
    this.lastRestart = now

    try {
      const ts = new Date().toISOString().replace(/[:.]/g, '-')
      const logTail = (health as any).logTail ?? ''
      const gitDiff = await this.collectGitDiff().catch(() => '')
      const reportPath = await this.deps.writeReport({ ts, health, action: `restart — ${health.error ?? 'down'}`, logTail, gitDiff }).catch(() => '')
      // Always attempt to (re)start dsh web — survives reboot even when the previous boot left nothing behind
      if (this.deps.restartWeb) {
        try {
          await this.deps.restartWeb()
          await this.deps.notify(`restarted dsh-web (report: ${reportPath})`).catch(() => {})
        } catch (e: any) {
          await this.deps.notify(`restart dsh-web failed: ${e?.message ?? String(e)} (report: ${reportPath})`).catch(() => {})
        }
      }
      await this.deps.notify(`CRASH detected → restart (report: ${reportPath}, error: ${health.error ?? 'down'})`).catch(() => {})
      const runner = this.getRunDebugAgent()
      const isInjected = !!this.deps.runDebugAgent
      if (isInjected) {
        void runner({ reportPath, health }).then(res => this.handleDebugResult(reportPath, res)).catch(() => {})
        setTimeout(() => {
          this.findInterruptedRecent().then(r => {
            if (r.interrupted.length) void this.attemptAutoResume(r.interrupted).catch(() => {})
          }).catch(() => {})
        }, 0)
      } else if (!process.env.VITEST) {
        void runner({ reportPath, health }).then(res => this.handleDebugResult(reportPath, res)).catch(() => {})
        setTimeout(() => {
          this.findInterruptedRecent().then(r => {
            if (r.interrupted.length) void this.attemptAutoResume(r.interrupted).catch(() => {})
          }).catch(() => {})
        }, 0)
      }
    } finally {
      this.restarting = false
    }
  }

  async start(): Promise<void> {
    if (this.timer) return
    const intervalMs = await this.getEffectiveIntervalMs()
    this.timer = setInterval(() => { this.tick().catch(() => {}) }, intervalMs)
    // Immediate tick so a reboot is recovered in ~0-3s, not 3s
    this.tick().catch(() => {})
  }

  // Synchronous start wrapper for callers that do not await (daemon cli fire-and-forget)
  startSync(): void {
    // The caller never observes this promise: an escaping rejection would reach
    // the host's unhandled-rejection path and exit the daemon.
    void this.start().catch((err) => {
      console.error('dsh-web-supervisor: start failed:', err instanceof Error ? err.message : err)
    })
  }

  stop(): void {
    if (this.timer) {
      clearInterval(this.timer)
      this.timer = null
    }
    if (this.restartRequestTimer) {
      clearTimeout(this.restartRequestTimer)
      this.restartRequestTimer = null
    }
  }
}
