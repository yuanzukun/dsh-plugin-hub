// src/host/remote-manifest.ts — one-pass remote inventory of eligible files.
//
// The fixed remote script walks only the eligible subtrees (same prune rules
// as transport.list), emits "sha<TAB>size<TAB>mtime<TAB>rel\0" per file, and
// the parser validates every relative path via normalizeEligiblePath before it
// can enter a plan. NUL framing keeps any discovered name safe on the wire;
// the parser sorts deterministically. mtimeSec is informational only — it is
// never an equality proof (equality uses sha256+size).
import { normalizeEligiblePath } from './validation.js';
import { remoteCachePath } from './remote-cache.js';

export interface RemoteManifestEntry {
  path: string;
  sha256: string;
  size: number;
  mtimeSec: number;
}

/**
 * Raised when the peer has not moved its store to the 4.0 root yet.
 *
 * Before this guard the peer's `find` simply matched nothing, the plan read as
 * "the peer has no memory", and the next push would have looked like the first
 * one. A named refusal is worth more than a silent empty inventory.
 */
/**
 * Raised when the peer has moved its store out of the DSH home.
 *
 * Sync still addresses memory as `<dshRoot>/maestro-memory` on the sending side, so a
 * push to a moved peer writes into the directory that peer no longer reads, and the
 * transfer reports success. Until the remote scripts learn a second base path, the only
 * honest thing is to refuse: a named refusal is worth more than memories that vanish.
 */
export class PeerStoreMovedError extends Error {
  readonly code = 'PEER_STORE_MOVED'
  constructor(readonly remotePath: string) {
    super(
      `peer store moved to ${remotePath}: this sync can only write <dshRoot>/maestro-memory, so publishing would be lost. Upgrade this machine's sync before transferring`,
    )
    this.name = 'PeerStoreMovedError'
  }
}

export class StoreNotMigratedError extends Error {
  readonly code = 'STORE_NOT_MIGRATED'
  constructor(readonly remotePath: string) {
    super(`remote store not migrated: ${remotePath} has no migrated-v4 marker; run the new build on that machine first`)
    this.name = 'StoreNotMigratedError'
  }
}

export function buildRemoteManifestScript(dshRoot: string): string {
  // Fixed script; dshRoot is the validated absolute root (same trust rule as transport.list).
  // Cache-aware, READ-ONLY (spec §4.7 clarification, decision C): it consults
  // <root>/.maestro-sync/fp.tsv and reuses a cached sha256 when the file's
  // ino+size+mtimeNs+ctimeNs triple (GNU stat '%.Y'/'%.Z' ns fractions) still
  // matches, skipping sha256sum for unchanged files. The cache is loaded ONCE
  // in a single awk pass, read straight from the file inside awk (getline — a
  // `-v cache=...` copy exceeds the 128 KiB per-arg limit once fp.tsv grows,
  // E2BIG "Argument list too long", measured 2026-09-02); only MISS records are
  // sha256sum'd in the bash loop. NEVER writes.
  // Every loop-body statement must end with ';' — space-separated assignments
  // inside a `do...done` one-liner break bash's parser (verified 2026-09-02).
  const cache = remoteCachePath(dshRoot);
  return [
    // Preflight sentinel: no 4.0 marker means the peer still holds the old
    // root, so an empty inventory must not be mistaken for an empty store.
    `if [ ! -f ${dshRoot}/maestro-memory/.maestro-memory/migrated-v4 ] && [ -d ${dshRoot}/dsh-maestro-memory ]; then printf 'STORE_NOT_MIGRATED\\t0\\t0\\t%s\\0' ${dshRoot}/dsh-maestro-memory; exit 0; fi;`,
    // 5.0 moved the store out of the DSH home on the peer. Its `find` below would match
    // nothing and read as "the peer has no memory", exactly the failure the v4 sentinel
    // above exists to prevent.
    `mem_root=${dshRoot}/maestro-memory; if [ -f "$HOME/.maestro-memory/.maestro-memory/migrated-v5.json" ]; then mem_root="$HOME/.maestro-memory"; fi;`,
    `find "$mem_root" ${dshRoot}/sessions`,
    `\\( -name node_modules -o -name .git -o -name .supervisor -o -name profiles \\) -prune -o -type f -print0`,
    `| xargs -0 stat --printf='%i %s %.Y %.Z\\t%n\\n' 2>/dev/null`,
    `| awk -F '\\t' -v root='${dshRoot}/' -v cachefile='${cache}' 'BEGIN{while((getline line < cachefile) > 0){if(line=="")continue; m=split(line,a,"\\t"); if(m>=6){c[a[1]]=(a[2]" "a[3]" "a[4]" "a[5])"\\t"a[6]"\\t"a[3]"\\t"a[4];}} close(cachefile);} {st=$1; rel=$2; sub(root,"",rel); if(rel in c){split(c[rel],e,"\\t"); if(e[1]==st){print "H\\t"rel"\\t"e[2]"\\t"e[3]"\\t"e[4]; next;}} print "M\\t"rel"\\t"st;}'`,
    `| while IFS= read -r rec; do`,
    `tag=\${rec%%$'\\t'*}; rest=\${rec#*$'\\t'};`,
    `if [ "$tag" = "H" ]; then`,
    `rel=\${rest%%$'\\t'*}; rest=\${rest#*$'\\t'}; sha=\${rest%%$'\\t'*}; rest=\${rest#*$'\\t'}; size=\${rest%%$'\\t'*}; mtime=\${rest#*$'\\t'};`,
    `printf '%s\\t%s\\t%s\\t%s\\0' "$sha" "$size" "$mtime" "$rel";`,
    `else`,
    `rel=\${rest%%$'\\t'*}; st=\${rest#*$'\\t'};`,
    `case "$rel" in maestro-memory/*) if [ "$mem_root" != "${dshRoot}/maestro-memory" ]; then full="$mem_root/\${rel#maestro-memory/}"; else full="${dshRoot}/$rel"; fi;; *) full="${dshRoot}/$rel";; esac;`,
    `sha=$(sha256sum -- "$full" 2>/dev/null | awk '{print $1}');`,
    `set -- $st;`,
    `printf '%s\\t%s\\t%s\\t%s\\0' "$sha" "$2" "$3" "$rel";`,
    `fi;`,
    `done`,
  ].join(' ');
}

export function parseRemoteManifest(buf: Buffer): RemoteManifestEntry[] {
  const out: RemoteManifestEntry[] = [];
  const parts = buf.toString('utf-8').split('\0');
  for (const part of parts) {
    if (!part) continue;
    if (part.startsWith('STORE_NOT_MIGRATED\t')) {
      throw new StoreNotMigratedError(part.split('\t').slice(3).join('\t'));
    }
    if (part.startsWith('PEER_STORE_MOVED\t')) {
      throw new PeerStoreMovedError(part.split('\t').slice(3).join('\t'));
    }
    const [sha, sizeRaw, mtimeRaw, ...rest] = part.split('\t');
    const p = rest.join('\t');
    const size = Number(sizeRaw);
    const mtimeSec = Number(mtimeRaw);
    if (!sha || !p || !Number.isFinite(size) || !Number.isFinite(mtimeSec)) continue;
    try {
      normalizeEligiblePath(p);
    } catch {
      continue; // ineligible — never enters the plan
    }
    out.push({ path: p, sha256: sha, size, mtimeSec });
  }
  return out.sort((a, b) => a.path.localeCompare(b.path));
}