# Changelog

## [0.15.0] - 2026-11-09

### Added

- `resolveStoreRoot` in `src/host/sync/store-root.ts` mirrors the plugin's rules, and
  `tests/sync/store-root-parity.spec.ts` runs the shared fixture against it so the two
  implementations cannot drift silently.
- `PEER_NOT_MOVED`: sync refuses a peer whose store has not moved, because the wire paths
  are unchanged and a mixed pair would otherwise write into a dead directory and report
  success with zero files.

### Fixed

- Store reads and writes map through the resolved root (`localPathForWirePath`), including
  pull publish and restore in place. A missed write site recreated `~/.dsh/maestro-memory`
  and made every later boot refuse.
- Backup walks the resolved store root, and restore in place lands there.

## [0.14.0] - 2026-10-28

### Changed

- **BREAKING: the systemd templates run the packaged dsh runtime.** `scripts/install-systemd.sh` now installs a `dsh-web.service` that runs `node "$DSH_BIN" web --no-open` with `DSH_BIN=~/.local/share/dsh/current/bin/dsh` and `WorkingDirectory=~/.local/share/dsh`, instead of booting a `deepseek-harness` checkout through tsx. Install `@deepseek-ai/dsh` under `~/.local/share/dsh/<version>` and link `current` before running the installer. The supervisor unit passes the same `DSH_BIN`. The working directory holds no `.env`, which dsh would otherwise load as a project env layer.
- `restart-dsh-web.sh` no longer requires `--repo`: a systemd-managed unit needs no checkout, and without systemd the helper launches `DSH_BIN`. `--repo` / `DSH_REPO` remain as the source-launch fallback.

### Fixed

- Every path that boots `dsh web` follows `DSH_BIN` when it is set (`resolveDshLaunch`): the `dsh_web_restart` / `dsh_web_dryboot` gate, the `dsh_web_gc` orphan fingerprint, the daemon nohup fallback and the debug-agent dry-boot. They previously always booted the source checkout, so on a packaged host the gate verified code the host does not run. Without `DSH_BIN` the source launch is unchanged.

## [0.13.0] - 2026-10-21

### Removed

- Last-known-good snapshots and crash rollback are gone. The supervisor daemon no longer writes `~/.dsh/.supervisor/lkg/` snapshots and no longer restores files on crash — a broken boot surfaces through the crash report (`reports/report-<ts>.md`) instead of an automatic restore. Health polling, restart on crash, Telegram notify, session auto-resume and the debug-agent still run as before. The `dsh_web_restart` gate now always dry-boots since there is no snapshot baseline to compare against.

## [0.12.1] - 2026-10-20

### Removed

- The guard no longer lists `maestro_read_file` and `maestro_write_file` as file tools. No plugin has registered them since the monolith was retired; the generic `read_file`, `write_file`, `fs_read` and `fs_write` names stay covered.

## [0.12.0] - 2026-10-10

### Removed

- **BREAKING: schema v1 guard config is no longer translated.** `mapLegacyConfig`, `loadGuardConfigWithMigration`, `journalConfigMigration` and the `config-legacy` journal note are gone. A persisted `domains.guard` that still carries `gitProtection`, `publishBlocked`, `cwdContainment` or `credentialPaths` now has those keys ignored, so protection falls back to the built-in defaults until the schema v2 keys (`rules`, `protectedBranches`, `protectedPaths`) are set. The Settings tab no longer renders a "legacy" tier source.
- **BREAKING: the retired ticket store is no longer moved aside.** `retireLegacyStore` and `guard/migrate.ts` are removed; `pending.json` is left where it is. The guard still treats `legacy-pending.json` as a protected path.
- **BREAKING: `<dsh home>/maestro/settings.json` is no longer read.** The supervisor consults only `<dsh home>/dsh-maestro-config/settings.json`.
- **BREAKING: the mtime-only `~/.dsh/.supervisor/planned-restart` file is no longer honoured.** Only the JSON `planned-restart.json` marker counts. `restart-dsh-web.sh` now writes that JSON marker (default path `planned-restart.json`, 180s ttl); a custom `DSH_SUPERVISOR_MARKER` must point at a JSON marker too.
- **BREAKING: `SyncService.pull()` and `SyncService.push()` and the `PullResult` and `PushResult` types.** Use `preview({ direction })` then `apply({ previewId, direction, confirm: true })`.
- **BREAKING: the `maestro_sync_pull` and `maestro_sync_push` tools and the `pull` and `push` sync RPC methods.** They were preview-only aliases that never wrote. Agents call `maestro_sync_preview` then `maestro_sync_apply`; the Sync tab already uses `previewStart` and `apply`.
- The duplicate `MaestroMark` in the sync UI kit; the sync surface imports the one in `config/components/BrandMark.tsx`.

### Fixed

- **Connection row injects webStartup.** DSH 0.2.1-alpha.x removed the webRuntime service; a connection entry still injecting it waits for a service that never mounts and dsh web never boots.
- **Journal stays silent on the rotation chmod race.** Boot-time rotation can rename the live file away between appendFile and the hardening chmod; the entry is already preserved, so only ENOENT is tolerated and any other chmod failure still reports.

## [0.11.2] - 2026-10-07

### Fixed

- **RPC rows activate on DSH 0.2.x.** The bundle patch declares `webServer` on the `connection` entry, so rows that call `rpc.handle` no longer fail with `cannot get property "webServer" without inject` and their channels no longer answer 405.

## [0.11.1] - 2026-10-06

### Fixed

- **Settings fields share one box.** Fields adopt the host's own `ConfigField` declaration plus a 44px touch floor, so the dialog no longer shows several geometries. The SSH target buttons stay on a row of their own below the field, the Maestro tab dropdowns keep 13px text, and the SSH label states a whole-pixel line-height so the hairline border cannot land on a half pixel.

## [0.11.0] - 2026-10-05

### Security

- **The `/dsh-maestro-config` channel no longer serves other plugins' secrets.**
  `list`/`get`/`set`/`unset` read and wrote **every** domain of the shared
  settings store, so any logged-in browser session — including one arriving
  through the PIN-gated public tunnel — could read the GitLab token, the
  webhook secret, the Telegram bot token and the tunnel credentials path in
  clear text, and could write or unset another plugin's keys without that
  plugin's validator. All four endpoints now accept only `guard`,
  `guardBlacklist` and `supervisor`, the domains this package's Settings card
  uses; `list` no longer reveals foreign domain names. In-process consumers of
  `ctx.maestroConfig` keep the full service.

### Fixed

- **The boot resume scan fires at boot, not minutes later** (0.10.0 and earlier).
  The window was anchored on `Date.now() - withinMs`, which drifts minutes into
  the session, so a session interrupted right before a restart was excluded from
  its own recovery scan. The anchor is now the process start time, and
  `runAutoResume` takes the boundary as an injectable option so the behaviour is
  testable rather than clock-dependent.
- **The Maestro Settings card renders again** (0.10.0 and earlier). A refactor
  trimmed the tab set and removed the `error` state its surviving handlers still
  called, so the whole section threw at render time and came up empty.

### Changed

- **The store cache validates mtime, inode and size.** Two copies writing inside
  one filesystem timestamp tick, or an out-of-band edit that restored the mtime,
  served a stale document.
- **Lock stealing is safe.** A lock carries an owner token and is released only
  by its owner; a stale lock must be older than 30s (longer than the 5s acquire
  timeout) and is stolen with an atomic rename that is rolled back if the moved
  file turns out to be a different inode. The settings directory is created 0700
  and the lock 0600.
- **A throwing `onChange` callback can no longer fail a write** that already
  landed, or drop a sibling listener.
- **`fs.watch` has an `error` listener**, so a watcher failure is logged instead
  of crashing the process.
- **A failed store write removes its temp file** instead of leaving it behind.

### Added

- **`systemd/` and `scripts/` ship in the npm tarball.** The manifest's `files`
  list excluded them, so a fresh `npm install @ddtcorex/dsh-maestro-core` could
  not install the supervisor daemon it publishes — `scripts/install-systemd.sh`
  was reachable only from a git checkout.

## [0.10.0] - 2026-10-05

### Changed

- **One package, four host rows.** The settings store, the Maestro settings
  card service, the guard and the sync engine now live in this repository as
  `src/host/{store,config,guard,sync}`, loaded by four rows in
  `cordis.patch.yml` instead of four separately installed packages. Each
  repository's history is preserved and its changelog is kept under
  `docs/history/`.
- **The store registers no domain validator.** `store/index.ts` is the file
  and the atomic write; the legacy flat-key adapter moved to `store/legacy.ts`
  and each domain owner registers its own validator through `defineDomain`.
  The guard validators ship with the guard module; the review and notifier
  validators are declared by those plugins.
- **`onChange` fires for writes made by another copy.** An embedded store copy
  watches the settings file while it has listeners, so a module that embeds the
  store keeps hearing Settings writes. The watcher starts with the first
  listener and stops with the last.
- **One client bundle.** `src/client/index.tsx` composes the auto-reload, the
  settings card and the Sync card, each guarded so one failure cannot cost the
  others their registration.

### Added

- `scripts/vendor-store.mjs` generates a consumer's embedded store copy with a
  body hash, and `verifyVendored` rejects a hand-edited or stale copy.
- `exports["./store"]` publishes the store as a subpath.

### Removed

- The `@ddtcorex/dsh-maestro-config-lib` dependency, the sibling checkout in
  `pnpm-workspace.yaml` and the `sibling-repos` entry in CI.

### Changed

- **The package is published as `@ddtcorex/dsh-maestro-core`** — renamed from
  `@ddtcorex/dsh-maestro-supervisor` in one sweep, because a profile carrying
  half the rename resolves nothing. The repository and the workspace directory
  were renamed with it. The three subpath row `name` values in
  `cordis.patch.yml`, the client loader `id`, the source-kind label the
  supervisor persists into session logs, and every runnable path in `README.md`
  and `AGENTS.md` moved in the same commit. The RPC channel names
  (`/dsh-maestro-supervisor-resume`, `-session-health`, `-reload`) and the
  `dsh-web-supervisor` binary name are wire protocol and did **not** change, so
  the earlier sections of this file keep the old spelling on purpose.

## [0.9.0] - 2026-09-22

### Fixed

- **Supervisor fallback reads the shared settings store** — the four
  `domains.supervisor.*` reads pointed at `~/.dsh/maestro/settings.json`,
  which never exists on a real install where the config lib writes
  `~/.dsh/dsh-maestro-config/settings.json`; they now resolve the shared
  path honouring `DSH_HOME` (#91).
- **A fresh install defers to the store** — the hardcoded
  `autoResumeEnabled: true` left `cordis.patch.yml`, so the UI toggle is no
  longer silently overridden (#91).

### Added

- `isAutoResumePinned()` and a status RPC endpoint, so a settings UI can
  render an honest locked/disabled toggle when an install-supplied Cordis
  config pins the value (#91).

### Changed

- Follow `@ddtcorex/dsh-maestro-config-lib` to `^0.3.0`.

## [0.8.4] - 2026-09-14

### Fixed

- **A resumed session keeps its agent preset** — `agents.resume()` composes an
  agent's scoped world only through `ResumeAgentOptions.setup`, and the resume
  path passed none, so every auto-resumed session was published joined to no
  preset: its tool view collapsed to the deployment-global layer and every
  preset tool (`bash`, `read`, `write`, `edit`, `glob`, `grep`, `subagent`,
  `skill`, `todo_write`, `workflow`, `cordis_*`, goal/plan/jobs) answered
  `Error: unknown tool "bash"` for the rest of that agent's life. Measured on
  the live incident: the resume header carried 76 tools instead of 110, and
  `agentPresets.composedPreset(agent.ctx)` was `undefined` where a healthy
  session answers `cordis`. Activation now delegates to
  `sessionController.resolveAgent` — the entry point the Web API itself uses,
  which composes the preset, de-duplicates concurrent resumes and returns the
  live agent when the browser already re-opened the session — and falls back to
  `agents.resume` with `setup: agentPresets.mount(agentCtx, presetId)`, reading
  the preset the session records (projection, then persisted header, then raw
  log header). A session that records no preset still resumes bare, which is
  correct for agents created outside the Web app.
- **A preset that cannot be composed no longer degrades into a preset-less
  resume** — the `setup` failure is wrapped in `PresetComposeError`, that one
  session is skipped with a `resume-failed` journal entry and an operator
  notification, and the remaining sessions still resume.
- **An unreadable tool registry is no longer reported as healthy** — the probe
  returned `{missing: [], visible: 0}` both when nothing was missing and when it
  could not read the registry at all, which is how the loss above stayed
  invisible (`maestro_resume_tool_health` printed `missing=none visible=0`).
  Probes now carry `registry: reachable | unreachable`, and the health output
  renders `registry=… composed=… repaired=…` beside the tool view.
- **Removed the pre-delivery `bash` readiness wait** — it polled the global
  registry for `bash`, which never holds a preset tool (measured), so it could
  only exhaust its budget and continue anyway; composition is now verified
  against the preset roster instead.

### Added

- **`maestro_repair_session_preset`** — re-links one live session's agent to the
  preset that session records (`agentPresets.recompose`, which for an agent with
  no binding is its first bind). It repairs an agent that lost its preset before
  this release without waiting for a restart, and reports `repaired`,
  `already-composed`, `no-preset-recorded`, `no-live-agent` or
  `recompose-failed`.
- **Automatic repair on resume (`resumeAutoRepair`, default `true`)** — after a
  resumed agent is activated the roster is asked
  (`composedPreset(agent.ctx)`) and a preset-less agent is re-linked before the
  recovery prompt is delivered, so the turn the prompt starts already carries
  the preset's tools. The check is skipped when it cannot be made (no roster
  service, or an agent without its own context), and the config key is the kill
  switch for this live re-link (`setup`/`tools/change`); with it off the loss is
  still notified and parked.

## [0.8.3] - 2026-09-14

### Fixed

- **A restarted host now continues the interrupted session** — the
  post-restart scan looked for the `turn/end interrupted` closer that the
  harness only writes when something next loads the session, and it re-checked
  the resume window against the open turn's own start time. A turn that had
  been running longer than the window was therefore judged too old and skipped
  (live case: a 21-minute turn, `{"scanned":1288,"interrupted":[]}`), so a
  restart mid-turn resumed nothing. The window now follows the session log's
  mtime — an append is the only evidence a session was live recently (#83).
- **A resume that loses a race with the reconnecting browser is retried** —
  when a restart interrupts a turn, the browser re-opens that session and holds
  its write handle while it loads and repairs it, so `agents.resume` fails with
  `SessionAlreadyOwnedError`. That contention is transient (the same session
  accepted an agent seconds later), so the resume is retried with a bounded
  backoff (2s/4s/8s), each attempt recorded as `resume-retry` in the resume
  audit log; a failure that is not an ownership conflict still fails
  immediately (#84).
- **The session the browser already has open can now be continued** — retrying
  is not enough for the session the operator is actually watching: the open
  page keeps its write handle for as long as it is open, so `agents.resume`
  never succeeds on it and the retries only logged three `resume-retry` lines
  before giving up. Once the retries are exhausted the recovery prompt is
  delivered through `sessionController.prompt`, the Host API the UI itself
  uses, which resolves the session's agent; the session is recorded as resumed
  and parked for the tool-health probe. When that service is absent or refuses
  the prompt, the original ownership failure is reported as before (#85).
- **Both delivery paths wait for `bash` before sending the prompt** — a resume
  admitted before the preset and shell plugins finish mounting attaches the
  agent with a request header that has no `bash`, so every shell call in that
  turn fails with `unknown tool "bash"`. The followup path had always waited;
  the owned-session path added above did not. The wait is now one shared,
  injectable `waitForCriticalTools()` with the same 5s budget, and that path
  also runs the post-delivery tool-view probe, so a lost core tool is reported
  to the operator and to `maestro_resume_tool_health` instead of staying
  invisible (#86).
- **`maestro_resume_tool_health` answers on a freshly restarted host** — the
  tool declared `lastResumeProbe` as a plain object, but a host that has not
  probed anything yet reports `null`, so the harness tool-output validator
  rejected the whole call with `"value.lastResumeProbe" must be an object`
  — on exactly the host state an operator inspects after a restart. The field
  is declared nullable, and a test pins the schema inside the validator's
  supported subset (#82).

## [0.8.2] - 2026-09-13

### Fixed

- **The package can be published again** — three outage comments named the
  operator's private tunnel machines, which the Release workflow's leak guard
  rejects in a public repo. The `v0.8.1` tag died on that gate before the
  publish step, so no `0.8.1` ever reached the registry; `0.8.2` carries the
  same changes as `0.8.1` plus this fix.

## [0.8.1] - 2026-09-13

### Fixed

- **A slow boot is no longer judged down** — a poll failure while the boot is
  unproven stays `booting` instead of counting as a crash, which stopped the
  daemon from rolling `dsh web` back in a loop every ~90s while the port
  answered in 1.4ms (#73).
- **The rollback actually restores** — unreadable or mode-`0400` entries are
  made writable or skipped with a reason instead of aborting the whole restore
  (#74).
- Serialize restarts so overlapping boots cannot crash-loop on EADDRINUSE
  (#71).
- Resume scan reads v3 session logs, so `continue` triggers again (#72).
- The restart helper reloads a stale supervisor daemon before swapping
  `dsh web`, aborting the swap if it cannot (#76).

### Changed

- Stop tracking `lib/` build output (#69); cover v3 session logs in the health
  classifier (#70); rehearse a rollback end to end on an isolated home (#75).

## [0.8.0] - 2026-09-08

### Added

- **`dsh_web_dryboot` tool** — standalone dry-boot gate on an ephemeral
  port with isolated `DSH_HOME`; validates the plugin tree without
  scheduling anything (#67).
- **`dsh_web_gc` tool** — preview-first orphan reaper for dry-boot
  processes (conjunctive fingerprint: temp `DSH_HOME` + ephemeral
  listener; never self, live ports, or real-home processes) (#67).
- **`dsh_web_restart_status` tool** — pending/ok/failed outcome query
  from the intent sidecar (#67).
- **Restart evidence** — `dsh_web_restart` returns
  `{ ok, detail, oldPid, intentPath }`; the marker carries `oldPid` and
  the daemon writes `{ state, oldPid, newPid, httpStatus, swappedAt }`
  after a supervised swap (#67).

### Changed

- Skill docs: in-session validation flows, settings-staging rule,
  `NODE_EXTRA_CA_CERTS` birth-environment note; stale `:3000`
  troubleshooting row replaced with the `dsh_web_gc` flow (#67).

## [0.7.10] - 2026-09-08

### Fixed

- **Dry-boot profile copy repairs relative `link:` symlinks** — the
  recursive copy left `link:` installs dangling under the temp DSH_HOME,
  failing the dry-boot gate with loader errors. Dangling links are now
  rewritten to their absolute live targets via `copyProfileForDryBoot()`
  (#65).

## [0.7.9] - 2026-09-03

### Fixed

- **Resume route recovery via the handle seam** — route recovery called the
  removed `persistence.load(id)` API (gone since DSH's handle-based
  persistence seam in 0.1.2-rc.1), so `agentOptions` was always `undefined`
  and every resumed agent lost its provider/model, failing the next turn
  with `prompt variable "{{model}}" has no value for this assembly (section
  "deployment:persona")`. The route is now read through `open(id, 'read')` +
  `read(0)`, falling back to the first `request/context` line of the raw
  session log; skip-with-audit remains only for genuinely routeless sessions
  (#63).

## [0.7.8] - 2026-09-03

### Fixed

- **Configurable degraded/down thresholds** — high load (loadavg ~12 from docker +
  horizon) made the 3s health poll read short fetch stalls as degraded and
  self-restart dsh web needlessly. Health fetch timeout 12s→20s, poll interval
  3s→5s, down threshold 5→6, degraded threshold 3→5; all four are now readable
  from supervisor config (`intervalMs`, `downThreshold`, `degradedThreshold`,
  `pollTimeoutMs`) via `getEffective*` helpers, so tuning needs no code change
  (#61).


## [0.7.7] - 2026-09-03

### Fixed

- **Resume full-scan maxBuffer** — `findDanglingOpenTurns` dropped every session
  whose decompressed log exceeds execSync's 1MB default (real worker logs decode to
  8–23MB): `readSessionAllLines` threw ENOBUFS and the per-session catch silently
  skipped it, so a big session's open turn after restart was never detected (#59).

### Added

- **Durable out-of-band resume audit log** — the in-tree auto-resume now appends
  one JSONL entry per step to `~/.dsh/.supervisor/resume.log.jsonl` (mode 600):
  `scan` (scanned + ids), `no-agent`, `resume-failed` (error), `resumed` (intent vs
  idle prompt). `ctx.logger` never reached `dsh-web.log`, so `agents.resume`
  failures were previously invisible (#59).


## [0.7.6] - 2026-09-02

### Fixed

- **Skill symlink** — resolve the skill symlink before deriving PLUGIN_DIR (#57).


## [0.7.5] - 2026-09-02

### Fixed

- Daemon resume RPC now mints the `dsh-auth-*` session cookie first (parses the
  newest boot launch line from `~/.dsh/dsh-web.log`, trades the token on the raw
  webserver) before POSTing to `/dsh-maestro-supervisor-resume/resume`. On the
  local-pin-gate topology the RPC sits behind the browser-trust fence and 401s
  without the cookie (`RESUME FAILED`). Falls back to the old unauthenticated
  call when no boot token is readable.

## [0.7.4] - 2026-09-02

### Fixed

- `dsh-safe-restart` recipe now detects the local-pin-gate topology (3000/3080/3081/3082) and health-checks :3080 (200/401/303) with a :3082 raw-webserver fallback, instead of hard-failing "no listeners found" whenever :3080 was unbound (the 2026-09-02 outage shape).

All notable changes to this project are documented in this file. Format follows
[Keep a Changelog](https://keepachangelog.com/en/1.1.0/); this project uses
[Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.7.3] - 2026-09-01

### Added

- Session-log health scan (`session-health`): detects a session log whose first
  zstd frame is not exactly one header line, re-encodes the recoverable
  single-whole-file-frame layout back to canonical multi-frame (payload
  preserved byte-for-byte, `.corrupt-singleframe.bak` sidecar), and quarantines
  garbage. Wired as a non-fatal pre-flight in the `dsh-safe-restart` recipe,
  a loopback RPC (`/dsh-maestro-supervisor-session-health`), and the
  `maestro_session_health` host tool — one corrupt log can no longer brick the
  whole plugin-tree boot (2026-09-01 crash-loop incident).
- Resume core-tool probe (`resume-tools`): after an auto-resume, the plugin
  probes the resumed session's tool view for `bash`, logs
  `[supervisor] resumed <id>: bash=<bool> …`, and on loss notifies + injects a
  tool-inventory system message (the model stops calling the missing tool).
  `resumeCoreToolPolicy: 'warn' | 'park'` (default warn; park flags a manual
  reopen) + `maestro_resume_tool_health` RPC/tool.

### Changed

- **LLM auto-debug removed entirely**: the supervisor never calls a model.
  Rule-based `autoFixKnownPatterns` + dry-boot transient detection + attempt/
  cooldown gating are kept; failure `reason` strings are LLM-free.

### Fixed

- Session-health classifier is stack-safe on many-frame logs (bounded 64KiB
  first-frame probe) and skips whole-file decode for healthy first-frame logs
  (~17s vs ~6–8min for 843 session logs).

## [0.7.2] - 2026-09-01

### Fixed

- Self-kill guard matches the executed command surface, not raw text: quoted
  spans and heredoc bodies (including backslash-escaped quotes) are treated as
  data, so analysis scripts, echoes and node -e bodies that merely mention
  kill-family words are no longer denied. Real invocations (a kill-family verb
  at the command position, targeted restart patterns, pid-targeted kills of the
  dsh-web tree) stay denied, and a command that is JUST `kill <unrelated-pid>`
  stays allowed.

## [0.7.1] - 2026-09-01

### Fixed

- Declare `tools` in the host plugin's inject so `ctx.tools` resolves and `dsh_web_restart` actually registers at runtime (previously the registration threw silently inside the wrapped effect and agents could not find the tool).
- Auto-resume reads the durable restart-intent sidecar written by `dsh_web_restart` and resumes a self-restart caller with a contextual message ("you requested a dsh web restart … do NOT call dsh_web_restart again") instead of the generic TOOL_OUTCOME_UNKNOWN recovery prompt, then consumes the sidecar.
- Self-kill guard scopes `kill` denials to the dsh web process tree only (any-listener pid over-denial removed).
- `isPluginTreeChanged` also detects `cordis.patch.yml`-only edits.
- `restart-guards` tests are hermetic (homedir-mocked) — no longer contend with the live supervisor daemon's marker under parallel vitest.
- `dryBootVerify` reports EADDRINUSE collisions explicitly.

## [0.7.0] - 2026-09-01

### Added

- `dsh-safe-restart` skill shipped via `ctx.skills` provider — the single guidance surface for restarting/updating `dsh web` (in-session agents call `dsh_web_restart`; external agents/humans use the bundled systemd-aware `restart-dsh-web.sh` helper).
- `dsh_web_restart` tool: dry-boot gate (copies `profiles/web` into an ephemeral DSH_HOME and boots on a temp port), restart-request marker with caller session + reason, durable intent sidecar; never restarts in-tree.
- Supervisor daemon handles caller restart-requests: grace → `restartWeb()` → marker held until post-restart `health.up` → session scan; rollback debounce honored across the boot window.
- In-session self-kill guard: `tools/pre-execute` denies `systemctl` restart / `pkill` / own-pid `kill` of `dsh web`, pointing to `dsh_web_restart`.
- `StartLimitIntervalSec=60` + `StartLimitBurst=3` in the systemd unit template to stop crash loops.
- Post-restart session scan (zstd decode) reporting torn session logs.

### Changed

- LKG rollback no longer restores `sessions/` (append-only live truth wins).
- `isPluginTreeChanged` uses the snapshot `manifest.json` mtime baseline with an injectable stat reader (CI-deterministic).

### Fixed

- Skill provider object now carries its own `name` (`maestro-supervisor`) — without it every turn failed with `skill provider "undefined" returned skill ... for provider "maestro-supervisor"`.

## [0.6.8] - 2026-08-31

### Added

- Pass through `reasoningEffort` from supervisor config to the debug-agent LLM provider/model selection (`AI_REASONING_EFFORT` → `supervisor.model.reasoningEffort` → `review.model.reasoningEffort` → settings), closing the unified model picker gap.

### Fixed

- Stop false-positive rollback/restart caused by the overly broad `JSON`/`YAML` log matchers: benign log lines whose payload merely contained those substrings (e.g. maestro-sync status JSON listing `session.jsonl.zstd` / `settings.json` paths) were treated as boot errors, turning a healthy `HTTP 401` into a rollback + `dsh-web` restart. The health-poller now matches only specific parse/boot errors (`SyntaxError`, `YAMLParseError`, `ParseError`, …), with a regression test asserting JSON status logs stay healthy.

## [0.6.6] - 2026-08-30

### Fixed

- Suppress `http 404`/`fetch failed` within 30s of `ActiveEnterTimestamp` even without marker (via wall-clock check, VITEST-safe) to eliminate extra restart after manual `systemctl start`.
- Degraded (`http 200` + plugin log error) now auto-rolls back after 3 consecutive polls (~9s) and notifies `🔄 auto-restart — degraded: <reason>`; also handles `401` with log error as degraded → down.
- Increase `vitest` timeout to 10s for `plugin.test.ts` flaky `autoResumeWithin` case.

## [0.6.5] - 2026-08-30

### Fixed

- Single-owner restart 30s suppression (planned-restart marker + flock) to prevent 2–3 systemd restarts per 1 client request.
- Suppress `http 404`/`fetch failed` within 30s of `ActiveEnterTimestamp` even without marker to eliminate extra restart during boot.
- Degraded (`http 200` + plugin log error) now auto-rolls back after 3 consecutive polls (~9s) and notifies `🔄 auto-restart — degraded: <reason>`.

## [0.6.4] - 2026-08-28

### Added

- Read `supervisorModel` from `~/.dsh/maestro/settings.json` for the debug-agent LLM provider/model selection.

## [0.6.2] - 2026-08-28

### Fixed

- Prevent spurious auto-reload on normal WebSocket close — only reload when the server is actually down (`offline` / WS close for DSH origin + `HEAD /` confirms down).

## [0.6.1] - 2026-08-28

### Fixed

- Handle `EADDRINUSE` as down and kill stale pid before restart (resolve tree pid via `ss -tlnp`, single `MainThread` holds `:3000` + `:3080`).

## [0.6.0] - 2026-08-28

### Added

- Hybrid auto-reload (client `auto-reload.ts` polling `HEAD /` 1s on `offline`/WS-close + host health recovery).
- Subagent-aware dangling detection: `findDanglingOpenTurns` now does full scan for recent sessions (mtime pre-filter) instead of tail window — fixes missed `b6487e33` where `turn/start` was at seq 6 of a 1906-line log.

### Fixed

- Tail window increased for `findInterrupted` and `pollHealth` debounce/rolling guard hardening.

## [0.5.4] - 2026-08-27

### Fixed

- Enforce bounded snapshot retention (count/age/size) and dedupe LKG store.

## [0.5.3] - 2026-08-27

### Fixed

- Add `muse-spark` LLM provider support for the debug agent.

## [0.5.2] - 2026-08-27

### Added

- Support custom AI provider for the debug-agent LLM (`supervisorModel` / provider selection).

## [0.5.1] - 2026-08-27

### Fixed

- Correct `dryBoot` shell escaping for nested `bash -c` invocations.

## [0.5.0] - 2026-08-27

### Added

- Wire LLM debug-agent with systematic-debugging and supervisor `FIXED` handling (spawn on-demand after LKG rollback, max 3 attempts).

## [0.4.0] - 2026-08-27

### Added

- Debug-agent build scaffolding and `supervisorModel` wiring.

## [0.3.0] - 2026-08-27

### Added

- Phase 3 resume: `resumeInterrupted` + `agents.resume` + `followup('continue')` with provider/model recovery from `request/context`.

## [0.2.0] - 2026-08-27

### Added

- Phase 2 degraded handling and systemd service wiring for `dsh-web-supervisor.service`.

## [0.1.0] - 2026-08-27

### Added

- Initial release of `@ddtcorex/dsh-maestro-supervisor` — standalone daemon (`dsh-web-supervisor` binary, systemd unit), in-tree host plugin (`runAutoResume`, loopback RPC `/dsh-maestro-supervisor-resume`), and client plugin (`auto-reload.ts` via `window.__ModuleLoader__.load`). Polls `:3080` every 3s, LKG rotation (3), `sha256` verify, `df` guard, reports, Telegram notifier (loose).

[0.6.6]: https://github.com/ddtcorex/dsh-maestro-supervisor/releases/tag/v0.6.6
[0.6.5]: https://github.com/ddtcorex/dsh-maestro-supervisor/releases/tag/v0.6.5
[0.6.4]: https://github.com/ddtcorex/dsh-maestro-supervisor/releases/tag/v0.6.4
[0.6.2]: https://github.com/ddtcorex/dsh-maestro-supervisor/releases/tag/v0.6.2
[0.6.1]: https://github.com/ddtcorex/dsh-maestro-supervisor/releases/tag/v0.6.1
[0.6.0]: https://github.com/ddtcorex/dsh-maestro-supervisor/releases/tag/v0.6.0
[0.5.4]: https://github.com/ddtcorex/dsh-maestro-supervisor/releases/tag/v0.5.4
[0.5.3]: https://github.com/ddtcorex/dsh-maestro-supervisor/releases/tag/v0.5.3
[0.5.2]: https://github.com/ddtcorex/dsh-maestro-supervisor/releases/tag/v0.5.2
[0.5.1]: https://github.com/ddtcorex/dsh-maestro-supervisor/releases/tag/v0.5.1
[0.5.0]: https://github.com/ddtcorex/dsh-maestro-supervisor/releases/tag/v0.5.0
[0.4.0]: https://github.com/ddtcorex/dsh-maestro-supervisor/releases/tag/v0.4.0
[0.3.0]: https://github.com/ddtcorex/dsh-maestro-supervisor/releases/tag/v0.3.0
[0.2.0]: https://github.com/ddtcorex/dsh-maestro-supervisor/releases/tag/v0.2.0
[0.1.0]: https://github.com/ddtcorex/dsh-maestro-supervisor/releases/tag/v0.1.0
