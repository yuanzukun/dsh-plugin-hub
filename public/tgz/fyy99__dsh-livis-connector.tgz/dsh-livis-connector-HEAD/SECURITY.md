# 安全策略

## 报告安全问题

请通过 GitHub 的 [Private vulnerability reporting](https://github.com/fyy99/dsh-livis-connector/security/advisories/new) 私下报告安全问题。

不要在公开 Issue、日志或截图中提交 access token、refresh token、授权码、完整 Agent ID、消息内容、本机路径或 API Key。报告中请提供：

- 受影响版本或 commit SHA
- 可复现步骤与预期影响
- 已做脱敏的日志或最小复现

## 支持范围

当前仅维护默认分支上的最新版本。DeepSeek Harness 仍处于 developer preview；若问题只在较旧的 DSH 版本出现，请先用 README 标注的兼容版本复核。

## 安全边界

本插件不会把 Livis token 下发到浏览器，但同一操作系统用户下运行的进程可能读取该用户可读的 DSH 凭据。请使用专用低权限 API Key、可信插件和无敏感数据的工作区，并保持 DSH Web 仅监听 loopback。
