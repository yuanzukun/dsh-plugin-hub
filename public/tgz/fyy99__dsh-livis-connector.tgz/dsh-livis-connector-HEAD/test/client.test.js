import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'
import test from 'node:test'
import vm from 'node:vm'

const root = new URL('../', import.meta.url)

test('客户端 bundle 注册 Livis 三步设置页并只调用 loopback RPC', async () => {
  const pkg = JSON.parse(await readFile(new URL('package.json', root), 'utf8'))
  assert.equal(pkg.exports['./client'], './lib/client.js')
  assert.equal(pkg.dsh.client.platform, 'web')
  assert.ok(pkg.dsh.client.inject.includes('@deepseek-ai/dsh-client-connection'))
  assert.ok(pkg.dsh.client.inject.includes('@deepseek-ai/dsh-client-ui-settings-plugins'))

  const source = await readFile(new URL('lib/client.js', root), 'utf8')
  assert.match(source, /将您的 Livis 接入到 DSH/)
  assert.match(source, /您的 Livis 已接入到 DSH/)
  assert.match(source, /t\(bindingVerifiedAt \? 'subtitleConnected' : 'subtitle'\)/)
  assert.match(source, /暂时无法读取 Livis 状态，正在自动重试。/)
  assert.match(source, /aria-current/)
  assert.match(source, /@media \(max-width:560px\)/)
  assert.match(source, /\[role="dialog"\]:has\(\[role="tabpanel"\]:not\(\[hidden\]\) \.livis-page\)>nav\+div/)
  assert.match(source, /\.livis-button\{min-height:44px\}/)
  assert.match(source, /\.livis-steps\{display:grid;grid-template-columns:minmax\(0,1fr\)/)
  assert.doesNotMatch(source, /repeat\(3,minmax\(0,1fr\)\)/)
  assert.match(source, /void copyValue\(auth\.userCode, 'authorization'\)/)
  assert.match(source, /data-copied/)
  assert.match(source, /setTimeout\(\(\) => setCopiedTarget\(''\), 2000\)/)
  assert.match(source, /prefers-reduced-motion:reduce/)
  assert.match(source, /'aria-atomic': 'true'/)
  assert.match(source, /state: bindingVerifiedAt \? 'done'/)
  assert.match(source, /function maskAgentId\(value\)/)
  assert.match(source, /bindingVerifiedAt && !agentIdRevealed \? maskAgentId\(snapshot\.agentId\)/)
  assert.match(source, /h\(EyeIcon, \{ revealed: agentIdRevealed \}\)/)
  assert.match(source, /h\(CopyIcon, \{ copied: copiedTarget === 'agent' \}\)/)
  assert.match(source, /'aria-pressed': agentIdRevealed \? 'true' : 'false'/)
  assert.match(source, /setAgentIdRevealed\(\(value\) => !value\)/)
  assert.match(source, /\.livis-icon-button\{width:44px;height:44px/)
  assert.doesNotMatch(source, /appVerified:/)
  assert.doesNotMatch(source, /verifiedAt:/)
  assert.doesNotMatch(source, /t\('appVerified'\)/)
  assert.doesNotMatch(source, /const \[notice, setNotice\]/)
  assert.match(source, /copied = document\.execCommand\('copy'\)/)
  assert.match(source, /if \(!copied\) throw new Error\('copy failed'\)/)
  assert.doesNotMatch(source, /DSH × LiVIS/)
  assert.doesNotMatch(source, /公开协议/)
  assert.doesNotMatch(source, /invoke\('unlink'/)
  assert.doesNotMatch(source, /dangerTitle/)
  assert.doesNotMatch(source, /relayTitle/)
  assert.doesNotMatch(source, /livis-card/)
  let registration
  const sandbox = {
    window: {
      __ModuleLoader__: {
        load(value) { registration = value },
      },
    },
    Intl,
    URL,
    console,
  }
  vm.runInNewContext(source, sandbox, { filename: 'lib/client.js' })
  assert.equal(registration.id, 'dsh-livis-connector')

  const fakeReact = {
    createElement() {},
    Fragment: Symbol('Fragment'),
    useEffect() {},
    useRef() { return { current: undefined } },
    useState(value) { return [value, () => {}] },
  }
  const client = registration.factory((id) => {
    assert.equal(id, 'react')
    return fakeReact
  })
  assert.deepEqual(Array.from(client.inject), ['slots', 'locale', 'connection'])

  let slot
  const rpcCalls = []
  const ctx = {
    effect(factory) { return factory() },
    locale: {
      register(namespace, dictionaries) {
        assert.equal(namespace, 'settings.livis')
        assert.equal(dictionaries.zh.tab, 'Livis')
        return () => {}
      },
      bind() { return (key) => key },
    },
    connection: {
      isLoopback: true,
      rpc: {
        async call(...args) {
          rpcCalls.push(args)
          return { ok: true, value: { relay: {} } }
        },
      },
    },
    slots: {
      inject(name, factory) {
        assert.equal(name, 'settings.plugins.tab')
        factory()
      },
      register(options, component) {
        slot = { options, component }
        return () => {}
      },
    },
  }
  client.apply(ctx)
  assert.equal(slot.options.id, 'livis')
  assert.equal(slot.options.order, 20)
  assert.equal(typeof slot.component, 'function')

  const injected = slot.options.inject()
  assert.equal(injected.isLoopback, true)
  await injected.call('status', {})
  assert.deepEqual(rpcCalls, [['/livis', 'status', {}]])
})
