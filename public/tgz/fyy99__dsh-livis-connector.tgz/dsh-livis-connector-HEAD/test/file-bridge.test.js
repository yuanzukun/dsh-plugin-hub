import assert from 'node:assert/strict'
import { createServer } from 'node:http'
import { mkdirSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
import { test } from 'node:test'
import { FileBridge } from '../lib/file-bridge.js'
import { tempDirectory } from './helpers.js'

test('文件回传只允许 uploadRoot 内的白名单文件', async () => {
  const temporary = tempDirectory('dsh-livis-connector-file-')
  const root = join(temporary.path, 'workspace')
  mkdirSync(root)
  writeFileSync(join(root, 'report.md'), '# report\n')
  const server = createServer(async (request, response) => {
    assert.equal(request.headers.authorization, 'Bearer access')
    const url = new URL(request.url, 'http://localhost')
    assert.equal(url.searchParams.get('client'), 'openclaw')
    assert.equal(url.searchParams.get('job_id'), 'job-file')
    for await (const _chunk of request) {}
    response.setHeader('content-type', 'application/json')
    response.end(JSON.stringify({
      objectKey: 'bucket/path/report.md',
      expiresAt: 123,
      fileInfo: { fileName: 'report', fileSuffix: 'md', fileType: 'text/markdown', fileSize: 9 },
    }))
  })
  await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve))
  try {
    const bridge = new FileBridge({
      uploadRoot: root,
      relayHttpUrl: `http://127.0.0.1:${server.address().port}`,
    }, { getAccessToken: async () => 'access' })
    const result = await bridge.upload('report.md', 'job-file')
    assert.equal(result.objectKey, 'bucket/path/report.md')
    assert.equal(result.file_path, '/path')
    await assert.rejects(() => bridge.upload('../outside.md', 'job-file'), /ENOENT|uploadRoot/)
  } finally {
    await new Promise((resolve) => server.close(resolve))
    temporary.cleanup()
  }
})
