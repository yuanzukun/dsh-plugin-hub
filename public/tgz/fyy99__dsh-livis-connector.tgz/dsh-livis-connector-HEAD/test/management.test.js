import assert from 'node:assert/strict'
import { test } from 'node:test'
import { LivisManagementController } from '../lib/management.js'
import { IdentityStore, TokenStore } from '../lib/state.js'
import { JobStore } from '../lib/job-store.js'
import { tempDirectory, waitFor } from './helpers.js'

function relayStub() {
  return {
    paused: false,
    pauseCalls: 0,
    resumeCalls: 0,
    checkCalls: 0,
    snapshot() {
      return {
        phase: this.paused ? 'paused' : 'signed-out',
        socketOpen: false,
        relayAcknowledged: false,
        paused: this.paused,
        reconnectAttempts: 0,
      }
    },
    async pause() { this.paused = true; this.pauseCalls += 1 },
    async resume() { this.paused = false; this.resumeCalls += 1 },
    async checkState() { this.checkCalls += 1 },
    async reconnectNow() {},
  }
}

function controllerFixture(path, overrides = {}) {
  const tokenStore = new TokenStore(path)
  const identityStore = new IdentityStore(path)
  identityStore.ensureDeviceId()
  const jobStore = new JobStore(path)
  const relay = relayStub()
  const adapter = {
    disposeCalls: 0,
    async dispose() { this.disposeCalls += 1 },
    ...overrides.adapter,
  }
  const tokenManager = {
    invalidate() {},
    ...overrides.tokenManager,
  }
  const controller = new LivisManagementController({
    config: {
      clientId: 'client',
      audience: 'audience',
      scope: 'super',
      idaasEndpoint: 'https://id.lixiang.com/api',
    },
    tokenStore,
    identityStore,
    tokenManager,
    jobStore,
    adapter,
    relay,
    logger: { info() {}, warn() {}, error() {} },
    createDeviceFlow: overrides.createDeviceFlow,
  })
  return { controller, tokenStore, identityStore, jobStore, relay, tokenManager, adapter }
}

test('管理页 Device Flow 不向浏览器暴露 device_code/token，并生成全新绑定身份', async () => {
  const temporary = tempDirectory('dsh-livis-connector-management-')
  try {
    let transient
    const fixture = controllerFixture(temporary.path, {
      createDeviceFlow(store) {
        transient = store
        return {
          async requestDeviceCode() {
            return {
              device_code: 'device-secret',
              verification_uri_complete: 'https://account.lixiang.com/verify?auth_session=public-handoff',
              interval: 0,
              expires_in: 60,
            }
          },
          async pollForToken(code, { onPending }) {
            assert.equal(code, 'device-secret')
            onPending({ kind: 'pending' })
            transient.setRefreshToken('refresh-secret')
            return { accessToken: 'access-secret', refreshToken: 'refresh-secret' }
          },
        }
      },
    })

    const started = await fixture.controller.startLogin()
    const publicJson = JSON.stringify(started)
    assert.equal(publicJson.includes('device-secret'), false)
    assert.equal(publicJson.includes('refresh-secret'), false)
    assert.equal(publicJson.includes('access-secret'), false)
    assert.match(started.status.auth.verificationUrl, /^https:\/\/account\.lixiang\.com\//)

    await waitFor(() => fixture.controller.status().auth?.phase === 'authorized')
    const status = fixture.controller.status()
    assert.equal(status.loggedIn, true)
    assert.match(status.agentId, /^openclaw-/)
    assert.match(status.sessionId, /^[0-9a-f-]+$/)
    assert.equal(fixture.relay.checkCalls, 1)
    assert.equal(fixture.adapter.disposeCalls, 1)
    assert.equal(JSON.stringify(status).includes('refresh-secret'), false)
  } finally {
    temporary.cleanup()
  }
})

test('本机已登出但仍有待投递结果时禁止新授权，避免把旧结果发给新账号', async () => {
  const temporary = tempDirectory('dsh-livis-connector-management-')
  try {
    const fixture = controllerFixture(temporary.path)
    fixture.jobStore.createError('old-ready-job', '旧账号请求')
    await assert.rejects(fixture.controller.startLogin(), /正在处理/)
    assert.equal(fixture.adapter.disposeCalls, 0)
  } finally {
    temporary.cleanup()
  }
})
test('管理页不再暴露解绑状态或解绑 RPC', async () => {
  const temporary = tempDirectory('dsh-livis-connector-management-')
  try {
    const fixture = controllerFixture(temporary.path)
    fixture.tokenStore.setRefreshToken('refresh-secret')
    const binding = fixture.identityStore.beginBinding()
    const status = fixture.controller.status()

    assert.equal(typeof fixture.controller.unlink, 'undefined')
    assert.equal(Object.hasOwn(status, 'browserLogoutUrl'), false)
    assert.equal(Object.hasOwn(status, 'revocationStatus'), false)

    const response = await fixture.controller.handle('unlink', {
      expectedAgentId: binding.agentId,
      expectedSessionId: binding.sessionId,
    })
    assert.match(response.value.actionError, /未知 Livis 管理操作/)
    assert.equal(fixture.tokenStore.exists(), true)
    assert.equal(fixture.identityStore.read().agentId, binding.agentId)
  } finally {
    temporary.cleanup()
  }
})
