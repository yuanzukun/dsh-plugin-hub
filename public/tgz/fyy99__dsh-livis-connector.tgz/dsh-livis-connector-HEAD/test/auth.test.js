import assert from 'node:assert/strict'
import { createServer } from 'node:http'
import { getEventListeners } from 'node:events'
import { after, before, test } from 'node:test'
import { DeviceFlowClient, TokenManager } from '../lib/auth.js'
import { IdentityStore, TokenStore } from '../lib/state.js'
import { tempDirectory } from './helpers.js'

const temporary = tempDirectory('dsh-livis-connector-auth-')
let server
let baseUrl
let devicePolls = 0

before(async () => {
  server = createServer(async (request, response) => {
    const chunks = []
    for await (const chunk of request) chunks.push(chunk)
    const form = new URLSearchParams(Buffer.concat(chunks).toString('utf8'))
    response.setHeader('content-type', 'application/json')
    if (request.url === '/api/aux') {
      assert.equal(form.get('scope'), 'super offline_access')
      assert.equal(form.get('audience'), 'audience')
      assert.equal(form.get('offline_access'), 'true')
      response.end(JSON.stringify({
        device_code: 'device-secret',
        verification_uri_complete: 'https://id.example/verify',
        interval: 0,
        expires_in: 60,
      }))
      return
    }
    if (request.url === '/api/token' && form.get('grant_type')?.includes('device_code')) {
      devicePolls += 1
      if (devicePolls === 1) {
        // Livis 生产 IDaaS 使用 428 表示 authorization_pending。
        response.statusCode = 428
        response.end(JSON.stringify({ error: 'authorization_pending' }))
      } else {
        response.end(JSON.stringify({ audience: { access_token: 'access-1', refresh_token: 'refresh-1', expires_in: 3600 } }))
      }
      return
    }
    if (request.url === '/api/token' && form.get('grant_type') === 'refresh_token') {
      assert.equal(form.get('refresh_token'), 'refresh-1')
      response.end(JSON.stringify({ audience: { access_token: 'access-2', refresh_token: 'refresh-2', expires_in: 3600 } }))
      return
    }
    response.statusCode = 404
    response.end('{}')
  })
  await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve))
  baseUrl = `http://127.0.0.1:${server.address().port}/api`
})

after(async () => {
  await new Promise((resolve) => server.close(resolve))
  temporary.cleanup()
})

test('Device Flow 与 refresh rotation 保持协议字段并安全落盘', async () => {
  const tokens = new TokenStore(temporary.path)
  const config = { clientId: 'client', audience: 'audience', scope: 'super', idaasEndpoint: baseUrl }
  const flow = new DeviceFlowClient(config, tokens, { sleep: async () => {} })
  const device = await flow.requestDeviceCode()
  const token = await flow.pollForToken(device.device_code, {
    interval: device.interval,
    expiresIn: device.expires_in,
  })
  assert.equal(token.accessToken, 'access-1')
  assert.equal(tokens.getRefreshToken(), 'refresh-1')
  const manager = new TokenManager(config, tokens)
  assert.equal(await manager.getAccessToken(), 'access-2')
  assert.equal(tokens.getRefreshToken(), 'refresh-2')
  assert.equal(typeof manager.revoke, 'undefined')
})

test('身份前缀与 session 状态是稳定的', () => {
  const identity = new IdentityStore(temporary.path)
  assert.match(identity.ensureDeviceId(), /^pc_[0-9a-f-]+$/)
  const agent = identity.ensureAgentId()
  assert.match(agent, /^openclaw-[0-9a-f-]+$/)
  assert.equal(identity.ensureAgentId(), agent)
  const session = identity.ensureSessionId()
  identity.markSessionReady(session)
  assert.equal(identity.read().sessionReady, true)

  const binding = identity.beginBinding()
  assert.match(binding.agentId, /^openclaw-[0-9a-f-]+$/)
  assert.notEqual(binding.agentId, agent)
  assert.notEqual(binding.sessionId, session)
  assert.equal(identity.read().sessionReady, false)
  identity.markBindingVerified(123)
  assert.equal(identity.read().bindingVerifiedAt, 123)

  assert.equal(typeof identity.clearBinding, 'undefined')
})

test('Device Flow 取消后立即停止，不会在已 abort 的 signal 上继续轮询', async () => {
  const tokens = new TokenStore(temporary.path)
  const controller = new AbortController()
  controller.abort(new Error('用户取消'))
  const flow = new DeviceFlowClient({
    clientId: 'client',
    audience: 'audience',
    scope: 'super',
    idaasEndpoint: baseUrl,
  }, tokens)
  await assert.rejects(
    flow.pollForToken('unused', {
      interval: 30,
      expiresIn: 600,
      signal: controller.signal,
    }),
    /用户取消/,
  )
})

test('Device Flow 拒绝非有限轮询参数，且正常 sleep 不残留 abort listener', async () => {
  const delays = []
  const memoryStore = { setRefreshToken() {} }
  const flow = new DeviceFlowClient({
    clientId: 'client',
    audience: 'audience',
    scope: 'super',
    idaasEndpoint: baseUrl,
  }, memoryStore, {
    sleep: async (ms) => { delays.push(ms) },
  })
  await flow.pollForToken('device-secret', {
    interval: 'not-a-number',
    expiresIn: 'not-a-number',
  })
  assert.equal(delays[0], 5_000)

  const defaultSleep = new DeviceFlowClient({}, memoryStore)
  const controller = new AbortController()
  for (let index = 0; index < 12; index += 1) {
    await defaultSleep.sleep(0, controller.signal)
  }
  assert.equal(getEventListeners(controller.signal, 'abort').length, 0)
})
