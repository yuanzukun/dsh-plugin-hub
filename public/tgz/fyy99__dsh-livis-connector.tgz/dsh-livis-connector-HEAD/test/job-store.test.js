import assert from 'node:assert/strict'
import { test } from 'node:test'
import { JobStore } from '../lib/job-store.js'
import { tempDirectory } from './helpers.js'

test('job_id 严格幂等且 crash 后不自动重放已开始任务', () => {
  const temporary = tempDirectory('dsh-livis-connector-job-')
  try {
    const store = new JobStore(temporary.path)
    const input = { jobId: 'job-1', msgId: 'm-1', fromNodeId: 'phone', content: 'do something' }
    assert.equal(store.create(input).created, true)
    assert.equal(store.create(input).created, false)
    store.markRunning('job-1')

    const recovered = new JobStore(temporary.path)
    const job = recovered.get('job-1')
    assert.equal(job.status, 'ready')
    assert.match(JSON.parse(job.result).text, /避免重复执行/)
  } finally {
    temporary.cleanup()
  }
})

test('结果状态按 ready → delivering → completed 迁移', () => {
  const temporary = tempDirectory('dsh-livis-connector-job-')
  try {
    const store = new JobStore(temporary.path)
    store.create({ jobId: 'job-2', content: 'x' })
    assert.deepEqual(store.active().map((job) => job.jobId), ['job-2'])
    store.markReady('job-2', JSON.stringify({ text: 'ok' }))
    assert.deepEqual(store.active().map((job) => job.jobId), ['job-2'])
    assert.equal(store.markDelivering('job-2').deliveryAttempts, 1)
    store.markCompleted('job-2')
    assert.equal(store.get('job-2').status, 'completed')
    assert.deepEqual(store.active(), [])
  } finally {
    temporary.cleanup()
  }
})

test('远端保留属性名不能命中原型或污染 Object.prototype', () => {
  const temporary = tempDirectory('dsh-livis-connector-job-')
  const originalStatus = Object.prototype.status
  try {
    const store = new JobStore(temporary.path)
    assert.equal(store.get('__proto__'), undefined)
    assert.equal(store.get('constructor'), undefined)
    store.create({ jobId: '__proto__', content: 'x' })
    store.markCompleted('__proto__')
    store.create({ jobId: 'constructor', content: 'y' })
    store.markCanceled('constructor')

    const recovered = new JobStore(temporary.path)
    assert.equal(recovered.get('__proto__').status, 'completed')
    assert.equal(recovered.get('constructor').status, 'canceled')
    assert.equal(Object.prototype.status, originalStatus)
  } finally {
    temporary.cleanup()
  }
})
