import assert from 'node:assert/strict'
import { createServer } from 'node:http'
import { test } from 'node:test'
import { WebSocketServer } from 'ws'
import { resolvePluginConfig } from '../lib/config.js'
import { TokenManager } from '../lib/auth.js'
import { IdentityStore, TokenStore } from '../lib/state.js'
import { JobStore } from '../lib/job-store.js'
import { LivisRelayClient } from '../lib/relay-client.js'
import { DshCancelledError } from '../lib/dsh-adapter.js'
import { tempDirectory, waitFor } from './helpers.js'

test('模拟 Livis relay 完成握手、ACK、执行、结果确认与重复 job 去重', async () => {
  const temporary = tempDirectory('dsh-livis-connector-relay-')
  let adapterCalls = 0
  let ackCount = 0
  let cancelAckCount = 0
  let cancelCalls = 0
  let cancelReject
  let resultEnvelope
  const server = createServer(async (request, response) => {
    if (request.url === '/api/token') {
      for await (const _chunk of request) {}
      response.setHeader('content-type', 'application/json')
      response.end(JSON.stringify({
        audience: {
          access_token: 'access',
          refresh_token: 'refresh-rotated',
          expires_in: 3600,
        },
      }))
      return
    }
    response.statusCode = 404
    response.end()
  })
  const websocket = new WebSocketServer({ server, path: '/api/v1/ws' })
  await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve))
  const port = server.address().port
  const config = resolvePluginConfig({
    stateDir: temporary.path,
    workspaceRoot: temporary.path,
    uploadRoot: temporary.path,
    clientId: 'client',
    audience: 'audience',
    scope: 'super',
    idaasEndpoint: `http://127.0.0.1:${port}/api`,
    relayWsUrl: `ws://127.0.0.1:${port}/api/v1/ws`,
    relayHttpUrl: `http://127.0.0.1:${port}`,
    heartbeatMs: 1_000,
    pongTimeoutMs: 3_000,
    ackTimeoutMs: 100,
    statePollMs: 1_000,
  })
  const tokens = new TokenStore(temporary.path)
  tokens.setRefreshToken('refresh')
  const identity = new IdentityStore(temporary.path)
  identity.ensureDeviceId()
  identity.ensureAgentId()
  const jobs = new JobStore(temporary.path)
  const adapter = {
    async execute(job) {
      adapterCalls += 1
      if (job.jobId === 'job-cancel') {
        return new Promise((_resolve, reject) => { cancelReject = reject })
      }
      assert.equal(job.content, 'hello')
      return { text: 'world', files: [] }
    },
    cancel(jobId) {
      if (jobId !== 'job-cancel' || !cancelReject) return false
      cancelCalls += 1
      cancelReject(new DshCancelledError())
      return true
    },
    async dispose() {},
  }
  const logger = { info() {}, warn() {}, error() {} }
  const client = new LivisRelayClient({
    config,
    tokenStore: tokens,
    identityStore: identity,
    tokenManager: new TokenManager(config, tokens),
    jobStore: jobs,
    adapter,
    logger,
  })

  websocket.on('connection', (socket) => {
    socket.on('message', (buffer) => {
      const message = JSON.parse(buffer.toString('utf8'))
      if (message.type === 'connect') {
        assert.equal(message.payload.client, 'openclaw')
        assert.equal(message.payload.refresh_token, 'refresh-rotated')
        socket.send(JSON.stringify({ type: 'connected', payload: {} }))
        socket.send(JSON.stringify({
          type: 'send_message',
          metadata: { msg_id: 'remote-1', job_id: 'job-1' },
          payload: { from_node_id: 'phone', data: { type: 'exec', content: 'hello' } },
        }))
      } else if (message.type === 'ack_send_message') {
        ackCount += 1
      } else if (message.type === 'send_result') {
        resultEnvelope = message
        socket.send(JSON.stringify({
          type: 'ack_send_result',
          metadata: { job_id: 'job-1' },
          payload: { ref_msg_id: 'job-1' },
        }))
      } else if (message.type === 'ack_cancel_chat') {
        cancelAckCount += 1
      }
    })
  })

  try {
    await client.start()
    await waitFor(() => jobs.get('job-1')?.status === 'completed')
    assert.equal(adapterCalls, 1)
    assert.equal(ackCount, 1)
    assert.deepEqual(JSON.parse(resultEnvelope.payload.data), { text: 'world' })
    assert.equal(resultEnvelope.metadata.client, 'openclaw')
    assert.equal(resultEnvelope.payload.nodeType, 'personl-device')
    assert.equal(tokens.getRefreshToken(), 'refresh-rotated')
    assert.equal(client.connectedRefreshToken, 'refresh-rotated')
    await client.checkState()
    assert.equal(client.isOpen(), true)

    const socket = [...websocket.clients][0]
    socket.send(JSON.stringify({
      type: 'send_message',
      metadata: { msg_id: 'remote-duplicate', job_id: 'job-1' },
      payload: { from_node_id: 'phone', data: JSON.stringify({ type: 'exec', content: 'hello' }) },
    }))
    await waitFor(() => ackCount === 2)
    assert.equal(adapterCalls, 1)

    socket.send(JSON.stringify({
      type: 'send_message',
      metadata: { msg_id: 'remote-cancel', job_id: 'job-cancel' },
      payload: { from_node_id: 'phone', data: { type: 'exec', content: 'wait' } },
    }))
    await waitFor(() => Boolean(cancelReject))
    socket.send(JSON.stringify({
      type: 'cancel_chat',
      metadata: { msg_id: 'remote-cancel-request', job_id: 'job-cancel' },
      payload: {},
    }))
    await waitFor(() => cancelCalls === 1 && cancelAckCount === 1)
    assert.equal(jobs.get('job-cancel').status, 'canceled')
  } finally {
    await client.stop()
    await new Promise((resolve) => websocket.close(resolve))
    await new Promise((resolve) => server.close(resolve))
    temporary.cleanup()
  }
})

test('token refresh 未返回时 pause 不会留下永久 pending 的连接', async () => {
  const temporary = tempDirectory('dsh-livis-connector-relay-pause-')
  let resolveAccessToken
  let tokenRequested = false
  const config = resolvePluginConfig({
    stateDir: temporary.path,
    workspaceRoot: temporary.path,
    uploadRoot: temporary.path,
    idaasEndpoint: 'http://127.0.0.1:9/api',
    relayWsUrl: 'ws://127.0.0.1:9/api/v1/ws',
    relayHttpUrl: 'http://127.0.0.1:9',
    statePollMs: 60_000,
  })
  const tokens = new TokenStore(temporary.path)
  tokens.setRefreshToken('refresh')
  const identity = new IdentityStore(temporary.path)
  identity.ensureDeviceId()
  identity.ensureAgentId()
  const jobs = new JobStore(temporary.path)
  class UnexpectedSocket {
    static OPEN = 1
    constructor() {
      throw new Error('pause 后不应再创建 WebSocket')
    }
  }
  const client = new LivisRelayClient({
    config,
    tokenStore: tokens,
    identityStore: identity,
    tokenManager: {
      async getAccessToken() {
        tokenRequested = true
        return new Promise((resolve) => { resolveAccessToken = resolve })
      },
      invalidate() {},
    },
    jobStore: jobs,
    adapter: { async dispose() {} },
    logger: { info() {}, warn() {}, error() {} },
    WebSocketImpl: UnexpectedSocket,
  })

  try {
    const starting = client.start()
    await waitFor(() => tokenRequested)
    const pausing = client.pause('test pause')
    resolveAccessToken('access')
    await Promise.race([
      pausing,
      new Promise((_, reject) => setTimeout(() => reject(new Error('pause 超时')), 500)),
    ])
    await starting
    assert.equal(client.snapshot().phase, 'paused')
    assert.equal(client.connecting, undefined)
  } finally {
    await client.stop()
    temporary.cleanup()
  }
})
