import assert from 'node:assert/strict'
import { test } from 'node:test'
import { DshSessionAdapter } from '../lib/dsh-adapter.js'
import { IdentityStore } from '../lib/state.js'
import { tempDirectory } from './helpers.js'

test('DSH adapter 使用默认模型、挂载 standard preset、提交事件并 flush session', async () => {
  const temporary = tempDirectory('dsh-livis-connector-adapter-')
  try {
    const listeners = new Map()
    const tools = []
    const restrictions = []
    const approvalPolicies = []
    const flushes = []
    const mounts = []
    let createOptions
    let resumeCalls = 0
    let disposed = false
    const session = { header: { id: 'session' } }
    let agent
    const ctx = {
      on(name, listener) {
        const group = listeners.get(name) || []
        group.push(listener)
        listeners.set(name, group)
      },
      agentDefaultModel: { currentSelection: () => ({ provider: 'deepseek-official', model: 'deepseek-v4-flash' }) },
      approval: { setPolicy: (subject, policy) => approvalPolicies.push({ subject, policy }) },
      agentPresets: {
        resolve: async () => ({ id: 'standard' }),
        mount: async (_agentCtx, id) => { mounts.push(id) },
      },
      sessions: { flush: async (value) => { flushes.push(value); return true } },
      sessionPersistence: { list: async () => [] },
      agents: {
        get: () => undefined,
        async resume() {
          resumeCalls += 1
          throw new Error('session not found')
        },
        async create(options) {
          createOptions = options
          await options.setup({
            tools: {
              get: (name) => ['ask_user_question', 'exit_plan_mode'].includes(name) ? { name } : undefined,
              register: (tool) => tools.push(tool),
              restrict: (filter) => restrictions.push(filter),
            },
          })
          agent = {
            session,
            followup(message) {
              for (const listener of listeners.get('agent/inbox/claimed') || []) listener({ agent, message, turn: 1 })
              for (const listener of listeners.get('session/event') || []) {
                listener(session, {
                  type: 'assistant/message',
                  data: { turn: 1, step: 1, message: { content: [{ type: 'text', text: 'intermediate' }] } },
                })
                listener(session, {
                  type: 'assistant/message',
                  data: { turn: 1, step: 2, message: { content: [{ type: 'text', text: 'DSH ' }, { type: 'text', text: 'reply' }] } },
                })
                listener(session, { type: 'turn/end', data: { turn: 1, reason: { kind: 'completed' } } })
              }
            },
            whenIdle: async () => {},
            cancel() {},
          }
          return { agent, dispose: async () => { disposed = true } }
        },
      },
    }
    const identity = new IdentityStore(temporary.path)
    const missingSessionId = identity.ensureSessionId()
    identity.markSessionReady(missingSessionId, 'standard')
    const adapter = new DshSessionAdapter(ctx, {
      workspaceRoot: temporary.path,
      uploadRoot: temporary.path,
    }, identity, { upload: async () => ({ name: 'x' }) }, { warn() {}, info() {}, error() {} })

    const result = await adapter.execute({ jobId: 'job', content: 'hello' })
    assert.deepEqual(result, { text: 'DSH reply', files: [] })
    assert.equal(resumeCalls, 1)
    assert.deepEqual(createOptions.agentOptions, { provider: 'deepseek-official', model: 'deepseek-v4-flash' })
    assert.equal(createOptions.meta.cwd, temporary.path)
    assert.equal(createOptions.meta.agentPreset, 'standard')
    assert.deepEqual(mounts, ['standard'])
    assert.deepEqual(restrictions, [{ deny: ['ask_user_question', 'exit_plan_mode'] }])
    assert.deepEqual(approvalPolicies, [{ subject: agent, policy: 'never' }])
    assert.equal(tools[0].name, 'livis_upload_file')
    assert.equal(flushes.length, 3)
    assert.equal(identity.read().sessionReady, true)
    assert.equal(identity.read().agentPreset, 'standard')
    await adapter.dispose()
    assert.equal(disposed, true)
    assert.equal(flushes.length, 4)
  } finally {
    temporary.cleanup()
  }
})
