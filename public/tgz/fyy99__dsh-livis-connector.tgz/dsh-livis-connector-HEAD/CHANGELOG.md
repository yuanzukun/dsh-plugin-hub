# Changelog

本项目遵循 [Semantic Versioning](https://semver.org/lang/zh-CN/)。

## [0.1.0] - 2026-08-14

- 提供 Livis OAuth Device Flow 授权与 DSH 设置页连接引导。
- 提供 WebSocket relay、心跳、重连、取消、结果确认和幂等恢复。
- 提供持久 DSH Agent session 与受限文档上传。
- 提供自动化测试、发布打包元数据和安全说明。
