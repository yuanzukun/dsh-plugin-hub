import Schema from '@deepseek-ai/schemastery'
import { resolvePluginConfig } from './lib/config.js'
import { TokenStore, IdentityStore } from './lib/state.js'
import { TokenManager } from './lib/auth.js'
import { JobStore } from './lib/job-store.js'
import { FileBridge } from './lib/file-bridge.js'
import { DshSessionAdapter } from './lib/dsh-adapter.js'
import { LivisRelayClient } from './lib/relay-client.js'
import { LivisManagementController } from './lib/management.js'

export const name = 'dsh-livis-connector'
export const inject = ['agentDefaultModel', 'agentPresets', 'agents', 'approval', 'sessions', 'tools', 'sessionPersistence']

export const Config = Schema.object({
  enabled: Schema.boolean().default(true).description('是否启用 Livis 连接'),
  stateDir: Schema.string().description('令牌、身份和幂等任务状态目录（必须为绝对路径）'),
  workspaceRoot: Schema.string().description('Livis Agent 的 DSH 工作区（必须为绝对路径）'),
  uploadRoot: Schema.string().description('允许回传到 Livis 的文件根目录（必须为绝对路径）'),
  provider: Schema.string().description('可选的 DSH provider 覆盖'),
  model: Schema.string().description('可选的 DSH model 覆盖'),
  agentPreset: Schema.string().description('DSH Agent 预设；省略时使用当前默认预设'),
  idaasEndpoint: Schema.string().description('Livis IDaaS endpoint'),
  relayWsUrl: Schema.string().description('Livis WebSocket relay endpoint'),
  relayHttpUrl: Schema.string().description('Livis HTTP relay endpoint'),
})

export async function apply(ctx, rawConfig = {}) {
  const config = resolvePluginConfig(rawConfig)
  if (!config.enabled) {
    ctx.logger.info('dsh-livis-connector: 插件已禁用')
    return
  }
  await ctx.effect(async () => {
    const tokenStore = new TokenStore(config.stateDir)
    const identityStore = new IdentityStore(config.stateDir)
    identityStore.ensureDeviceId()
    const tokenManager = new TokenManager(config, tokenStore)
    const jobStore = new JobStore(config.stateDir, { terminalTtlMs: config.terminalJobTtlMs })
    const fileBridge = new FileBridge(config, tokenManager)
    const adapter = new DshSessionAdapter(ctx, config, identityStore, fileBridge, ctx.logger)
    const relay = new LivisRelayClient({
      config,
      tokenStore,
      identityStore,
      tokenManager,
      jobStore,
      adapter,
      logger: ctx.logger,
    })
    const management = new LivisManagementController({
      config,
      tokenStore,
      identityStore,
      tokenManager,
      jobStore,
      adapter,
      relay,
      logger: ctx.logger,
    })
    // Web profile 存在 connection 时才挂管理 RPC；headless 可使用已有授权继续运行 relay。
    ctx.inject(['connection'], (rpcCtx) => {
      rpcCtx.effect(
        () => rpcCtx.connection.rpc.handle(
          '/livis',
          (endpoint, payload) => management.handle(endpoint, payload),
          { authority: 'loopback' },
        ),
        'dsh-livis-connector.management-rpc',
      )
    })
    await relay.start()
    return async () => {
      await management.dispose()
      await relay.stop()
    }
  }, 'dsh-livis-connector.relay')
}
