/**
 * 文案字典（zh / en）。
 *
 * `t()` 只接受 key、返回字符串本身，不带插值；需要插值处用 {@link tpl}。
 * namespace 与 client 注册时使用的 NS 保持一致。
 */

export const NS = 'dsh-plugin-zotero'

export type Translate = (key: string) => string

/** 极简占位符替换：`{name}` → 变量值。 */
export function tpl(template: string, vars: Record<string, string | number>): string {
  return template.replace(/\{(\w+)\}/gu, (_, key: string) => {
    const value = vars[key]
    return value === undefined ? '' : String(value)
  })
}

const zh: Record<string, string> = {
  'tab.title': 'Zotero 文献库',
  'guide.title': 'Zotero 文献库',
  'guide.desc': '浏览本地 Zotero 文库，把条目、摘录或整个目录加入当前会话',

  'action.refresh': '刷新',
  'action.insertItem': '添加条目引用',
  'action.insertExcerpt': '添加摘录',
  'action.insertCollection': '添加整目录引用',

  'status.zoteroOn': 'Zotero 已连接',
  'status.zoteroOff': 'Zotero 未连接',
  'status.mcpOn': '模型工具可用',
  'status.mcpOff': '模型工具不可用',
  'status.loading': '加载中…',

  'tree.library': '我的文库',
  'tree.publications': '我的出版物',
  'tree.unfiled': '未分类条目',
  'tree.trash': '回收站',
  'tree.searchPlaceholder': '搜索标题 / 摘要',
  'tree.count': '{n} 条',
  'tree.empty': '这个分类下没有条目',

  'detail.empty': '从左侧选择分类或条目',
  'detail.creators': '作者',
  'detail.year': '年份',
  'detail.source': '出处',
  'detail.doi': 'DOI',
  'detail.url': '链接',
  'detail.abstract': '摘要',
  'detail.tags': '标签',
  'detail.attachments': '附件',
  'detail.fulltext': '全文',
  'detail.noFulltext': '该附件没有可用的全文索引',
  'detail.fulltextTruncated': '（已按长度截断）',
  'detail.collectionSummary': '分类：{name}',
  'detail.collectionCount': '共 {n} 条条目',
  'detail.bibTitle': '参考文献（APA）',
  'detail.noBib': '该分类没有可导出的引用条目（裸 PDF 附件不产生引用）',

  'error.noEditor': '当前面板不在会话上下文中，无法插入到输入框',
  'error.draftChanged': '输入框草稿已变化，未插入；请避免在插入期间编辑草稿',
  'error.empty': '没有可插入的内容',

  'toast.inserted': '已添加到会话草稿',

  'card.title': 'Zotero 连接设置',
  'card.desc': 'Zotero 本地 API 与集成 MCP 的连接参数',
  'group.api': 'API 设置',
  'group.mcp': 'MCP 设置',
  'tools.title': 'MCP 工具',
  'tools.loading': '正在读取工具列表…',
  'tools.reload': '重新读取',
  'tools.empty': '集成 MCP 未返回任何工具',
  'tools.error': '读取工具列表失败：{message}',
  'tools.summary': '共 {total} 个工具，已禁用 {off} 个',
  'tools.on': '已启用',
  'tools.off': '已禁用',
  'tools.toggleLabel': '启用或禁用工具 {name}',
  'field.zoteroBaseUrl': 'Zotero 地址',
  'field.zoteroBaseUrlHint': '本地 API 根地址，默认 http://127.0.0.1:23119；需在 Zotero「设置 → 高级 → 其他」中允许本机通信',
  'field.mcpUrl': '集成 MCP 地址',
  'field.mcpUrlHint': 'Zotero 集成 MCP 的 Streamable HTTP 端点，默认 http://127.0.0.1:23120/mcp',
  'field.requestTimeoutMs': '请求超时（毫秒）',
  'field.requestTimeoutMsHint': '单次 Zotero 本地 API 请求的超时，默认 5000',
  'field.mcpProbeTimeoutMs': 'MCP 探活超时（毫秒）',
  'field.mcpProbeTimeoutMsHint': 'TCP 探活集成 MCP 端口的超时，默认 800',
  'field.fulltextMaxBytes': '全文上限（字节）',
  'field.fulltextMaxBytesHint': '单条附件全文最大返回字节数，超出会被截断，默认 204800',
  'field.defaultLimit': '默认条目数',
  'field.defaultLimitHint': '面板条目列表默认拉取条数，默认 50',
  'form.unavailable': '该插件当前未加载，暂时无法配置。',
  'form.readOnly': '本部署的设置为只读。',
  'form.saveFailed': '本部署没有接受这些值，已保留供你修改。',
  'form.save': '保存',
  'form.saving': '保存中…',
  'form.overridden': '已覆盖',
  'form.reset': '恢复默认',
  'form.invalidNumber': '请填数字；留空表示使用默认值。',
  'form.invalidText': '请填字符串；留空表示使用默认值。',

  'cmp.item.header': '【Zotero 条目｜{key}】{title}',
  'cmp.item.creators': '作者：{value}',
  'cmp.item.year': '年份：{value}',
  'cmp.item.source': '出处：{value}',
  'cmp.item.doi': 'DOI：{value}',
  'cmp.item.url': '链接：{value}',
  'cmp.item.tags': '标签：{value}',
  'cmp.item.abstract': '摘要：{value}',
  'cmp.excerpt.header': '【Zotero 摘录｜{title}｜{key}】',
  'cmp.excerpt.quote': '“{value}”',
  'cmp.collection.header': '【Zotero 目录｜{name}｜{key}】共 {n} 条',
  'cmp.collection.line': '- {title}（{meta}）',
  'cmp.collection.more': '……（仅列出前 {n} 条；完整清单可用 mcp__zotero__get_collection_items 获取）',
}

const en: Record<string, string> = {
  'tab.title': 'Zotero Library',
  'guide.title': 'Zotero Library',
  'guide.desc': 'Browse the local Zotero library and add items, excerpts or whole collections to this conversation',

  'action.refresh': 'Refresh',
  'action.insertItem': 'Add item citation',
  'action.insertExcerpt': 'Add excerpt',
  'action.insertCollection': 'Add collection citations',

  'status.zoteroOn': 'Zotero connected',
  'status.zoteroOff': 'Zotero not connected',
  'status.mcpOn': 'Model tools available',
  'status.mcpOff': 'Model tools unavailable',
  'status.loading': 'Loading…',

  'tree.library': 'My Library',
  'tree.publications': 'My Publications',
  'tree.unfiled': 'Unfiled Items',
  'tree.trash': 'Trash',
  'tree.searchPlaceholder': 'Search title / abstract',
  'tree.count': '{n} items',
  'tree.empty': 'No items in this collection',

  'detail.empty': 'Select a collection or item on the left',
  'detail.creators': 'Creators',
  'detail.year': 'Year',
  'detail.source': 'Source',
  'detail.doi': 'DOI',
  'detail.url': 'URL',
  'detail.abstract': 'Abstract',
  'detail.tags': 'Tags',
  'detail.attachments': 'Attachments',
  'detail.fulltext': 'Full text',
  'detail.noFulltext': 'No full-text index available for this attachment',
  'detail.fulltextTruncated': '(truncated by length)',
  'detail.collectionSummary': 'Collection: {name}',
  'detail.collectionCount': '{n} items',
  'detail.bibTitle': 'Bibliography (APA)',
  'detail.noBib': 'Nothing citable here (bare PDF attachments produce no citation)',

  'error.noEditor': 'This panel is not in a conversation context; cannot insert into the composer',
  'error.draftChanged': 'The draft changed; nothing was inserted. Avoid editing while inserting.',
  'error.empty': 'Nothing to insert',

  'toast.inserted': 'Added to the conversation draft',

  'card.title': 'Zotero connection',
  'card.desc': 'Connection parameters for the local Zotero API and the integration MCP',
  'group.api': 'API settings',
  'group.mcp': 'MCP settings',
  'tools.title': 'MCP tools',
  'tools.loading': 'Loading tool list…',
  'tools.reload': 'Reload',
  'tools.empty': 'The integration MCP returned no tools',
  'tools.error': 'Failed to load the tool list: {message}',
  'tools.summary': '{total} tools, {off} disabled',
  'tools.on': 'Enabled',
  'tools.off': 'Disabled',
  'tools.toggleLabel': 'Enable or disable tool {name}',
  'field.zoteroBaseUrl': 'Zotero URL',
  'field.zoteroBaseUrlHint': 'Local API root, default http://127.0.0.1:23119; allow local communication in Zotero "Settings → Advanced → Other"',
  'field.mcpUrl': 'Integration MCP URL',
  'field.mcpUrlHint': 'Streamable HTTP endpoint of the Zotero integration MCP, default http://127.0.0.1:23120/mcp',
  'field.requestTimeoutMs': 'Request timeout (ms)',
  'field.requestTimeoutMsHint': 'Timeout of one local Zotero API request, default 5000',
  'field.mcpProbeTimeoutMs': 'MCP probe timeout (ms)',
  'field.mcpProbeTimeoutMsHint': 'TCP connect timeout when probing the integration MCP port, default 800',
  'field.fulltextMaxBytes': 'Full-text cap (bytes)',
  'field.fulltextMaxBytesHint': 'Max bytes returned for one attachment full text; longer content is truncated, default 204800',
  'field.defaultLimit': 'Default item count',
  'field.defaultLimitHint': 'Default number of items a page loads, default 50',
  'form.unavailable': 'This plugin is not loaded, so it cannot be configured right now.',
  'form.readOnly': 'This deployment stores settings read-only.',
  'form.saveFailed': 'This deployment did not accept these values; they were kept for you to fix.',
  'form.save': 'Save',
  'form.saving': 'Saving…',
  'form.overridden': 'Overridden',
  'form.reset': 'Reset to default',
  'form.invalidNumber': 'Enter a number; leave blank to use the default.',
  'form.invalidText': 'Enter text; leave blank to use the default.',

  'cmp.item.header': '[Zotero item | {key}] {title}',
  'cmp.item.creators': 'Creators: {value}',
  'cmp.item.year': 'Year: {value}',
  'cmp.item.source': 'Source: {value}',
  'cmp.item.doi': 'DOI: {value}',
  'cmp.item.url': 'URL: {value}',
  'cmp.item.tags': 'Tags: {value}',
  'cmp.item.abstract': 'Abstract: {value}',
  'cmp.excerpt.header': '[Zotero excerpt | {title} | {key}]',
  'cmp.excerpt.quote': '“{value}”',
  'cmp.collection.header': '[Zotero collection | {name} | {key}] {n} items',
  'cmp.collection.line': '- {title} ({meta})',
  'cmp.collection.more': '… (first {n} only; use mcp__zotero__get_collection_items for the full list)',
}

export const dicts = { zh, en }
