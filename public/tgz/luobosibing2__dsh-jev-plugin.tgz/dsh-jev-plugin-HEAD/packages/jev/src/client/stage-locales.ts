/** Copy for the Session stage navigation view. */

export type StageLocaleKey =
  | 'title' | 'navigation' | 'showNavigation' | 'hideNavigation' | 'refresh'
  | 'loading' | 'loadFailed' | 'emptySession' | 'emptyTurn' | 'emptySearch'
  | 'turn' | 'step' | 'steps' | 'request' | 'source' | 'search' | 'clearSearch'
  | 'analyzeTurn' | 'analyzeAll' | 'retryFailed' | 'reanalyzeTurn' | 'cancel'
  | 'analyzing' | 'analyzeFailed' | 'cancelFailed' | 'scopeTurn'
  | 'scopeAll' | 'scopeHint' | 'pendingCount' | 'batchProgress'
  | 'missingTurnCount' | 'missingAllCount' | 'retryTurnCount' | 'refreshTurnCount' | 'refreshWarning'
  | 'stageInputParsing' | 'stageProblemUnderstanding' | 'stageSolutionPlanning'
  | 'stageImplementation' | 'stageReviewValidation' | 'stageDeliveryFinalization'
  | 'stageMixed' | 'stageUnknown' | 'unanalysed' | 'stale' | 'failed' | 'unavailable'
  | 'cancelled' | 'pending' | 'succeeded' | 'interrupted' | 'running' | 'completed' | 'aborted' | 'endedWithError'
  | 'unknownEnd' | 'reasoning' | 'assistantText' | 'assistantOther' | 'tools'
  | 'toolArguments' | 'toolResult' | 'toolError' | 'missingResult' | 'notDispatched' | 'attempts'
  | 'analysis' | 'analysisStatus' | 'confidence' | 'probabilities' | 'notProvided'
  | 'connection' | 'connectionJev' | 'connectionLunaOpenRouter' | 'connectionLunaOpenAI' | 'providerRequests' | 'usageIncomplete'
  | 'model' | 'configuredModel' | 'details' | 'closeDetails' | 'detailFailed' | 'requestSent' | 'previousSavedResult' | 'viewPreviousRecord'
  | 'rawResponse' | 'parsedResponse' | 'redactionNote' | 'uncalibrated' | 'sourceStep'
  | 'noReasoning' | 'noText' | 'noTools' | 'notComplete' | 'terminalPartial' | 'staleNotice' | 'noMaterial' | 'materialTooLarge'
  | 'blocked' | 'maxTokens' | 'forked'

export const stageEn: Record<StageLocaleKey, string> = {
  connection: 'Judgment connection', connectionJev: 'Jev', connectionLunaOpenRouter: 'Luna Decisions / OpenRouter', connectionLunaOpenAI: 'Luna Decisions / OpenAI', providerRequests: 'Actual provider requests and responses', usageIncomplete: 'Reported usage is incomplete.',
  title: 'Stage navigation', navigation: 'Turns and stages', showNavigation: 'Show navigation', hideNavigation: 'Hide navigation', refresh: 'Refresh',
  loading: 'Loading session history…', loadFailed: 'Could not load session history.', emptySession: 'No turns are recorded in this session.', emptyTurn: 'No steps are recorded in this turn.', emptySearch: 'No source steps match this search.',
  turn: 'Turn', step: 'Step', steps: 'steps', request: 'User request', source: 'Original step records', search: 'Search this turn’s source', clearSearch: 'Clear search',
  analyzeTurn: 'Analyze this turn', analyzeAll: 'Analyze unanalysed steps', retryFailed: 'Retry failed steps', reanalyzeTurn: 'Reanalyze this turn', cancel: 'Cancel analysis',
  analyzing: 'Analyzing…', analyzeFailed: 'Could not start analysis.', cancelFailed: 'Could not cancel analysis.', scopeTurn: 'Selected completed turn',
  scopeAll: 'All completed turns', scopeHint: 'Only recorded step material is sent to the selected judgment connection. Input is redacted; the original Session is unchanged.', pendingCount: 'Eligible steps', batchProgress: 'Analysis progress', missingTurnCount: 'Missing in this turn', missingAllCount: 'Missing in this session', retryTurnCount: 'Retryable in this turn', refreshTurnCount: 'Reanalysis in this turn', refreshWarning: 'Reanalysis makes new judgment requests',
  stageInputParsing: 'Input parsing', stageProblemUnderstanding: 'Problem understanding', stageSolutionPlanning: 'Solution planning', stageImplementation: 'Implementation and debugging', stageReviewValidation: 'Review and validation', stageDeliveryFinalization: 'Delivery and finalization', stageMixed: 'Mixed', stageUnknown: 'Unknown',
  unanalysed: 'Unanalysed', stale: 'Outdated', failed: 'Failed', unavailable: 'Material unavailable', cancelled: 'Cancelled', pending: 'Pending', succeeded: 'Classified', interrupted: 'Interrupted', running: 'Running', completed: 'Completed', aborted: 'Aborted', endedWithError: 'Ended with error', unknownEnd: 'Ended',
  reasoning: 'Think / reasoning', assistantText: 'Assistant text', assistantOther: 'Other assistant block', tools: 'Tool calls and results', toolArguments: 'Arguments', toolResult: 'Result', toolError: 'Tool reported an error', missingResult: 'No result recorded', notDispatched: 'Call was not dispatched', attempts: 'Attempts and retries',
  analysis: 'Stage classification', analysisStatus: 'Classification status', confidence: 'Confidence', probabilities: 'Probabilities', notProvided: 'Not provided', model: 'Reported model', configuredModel: 'Configured model', details: 'Classification input and response', closeDetails: 'Close details', detailFailed: 'Could not load the classification record.', requestSent: 'Redacted judgment input', previousSavedResult: 'Previous saved result', viewPreviousRecord: 'View previous record', rawResponse: 'Raw response', parsedResponse: 'Normalized answer', redactionNote: 'Classification input is redacted before it is sent and saved. Source records below remain original.', uncalibrated: 'Uncalibrated signal', sourceStep: 'Source step',
  noReasoning: 'No reasoning block was recorded.', noText: 'No assistant text was recorded.', noTools: 'This step has no tool call.', notComplete: 'This step is still in progress and cannot be classified.', terminalPartial: 'The turn ended before this step closed. Recorded material is shown; some results may be missing.', staleNotice: 'This saved classification is outdated and is excluded from the stage sequence.', noMaterial: 'No classifiable material was recorded.', materialTooLarge: 'The complete step exceeds the request limit and was not truncated.', blocked: 'Blocked', maxTokens: 'Output limit reached', forked: 'Fork boundary',
}

export const stageZh: Record<StageLocaleKey, string> = {
  connection: '判断连接', connectionJev: 'Jev', connectionLunaOpenRouter: 'Luna Decisions / OpenRouter', connectionLunaOpenAI: 'Luna Decisions / OpenAI', providerRequests: '实际提供方请求与响应', usageIncomplete: '服务报告用量不完整',
  title: '阶段导航', navigation: '轮次与阶段', showNavigation: '展开导航', hideNavigation: '收起导航', refresh: '刷新',
  loading: '正在读取会话历史…', loadFailed: '无法读取会话历史', emptySession: '本会话尚无已记录轮次', emptyTurn: '本轮尚无已记录步骤', emptySearch: '本轮原文没有匹配的步骤',
  turn: '第', step: '步骤', steps: '步', request: '用户请求', source: '完整步骤原文', search: '搜索本轮原文', clearSearch: '清除搜索',
  analyzeTurn: '分析本轮', analyzeAll: '补齐未分析步骤', retryFailed: '重试失败步骤', reanalyzeTurn: '重新分析本轮', cancel: '取消分析',
  analyzing: '分析中…', analyzeFailed: '无法启动分析', cancelFailed: '无法取消分析', scopeTurn: '选中的已结束轮',
  scopeAll: '本会话全部已结束轮', scopeHint: '只向所选判断连接发送已记录的步骤材料；输入先脱敏，原始 Session 不变', pendingCount: '可处理步骤', batchProgress: '分析进度', missingTurnCount: '本轮待补齐', missingAllCount: '本会话待补齐', retryTurnCount: '本轮可重试', refreshTurnCount: '本轮可重分析', refreshWarning: '重分析将再次发起判断请求',
  stageInputParsing: '输入解析', stageProblemUnderstanding: '问题理解澄清', stageSolutionPlanning: '方案规划', stageImplementation: '实现与调试', stageReviewValidation: '审查验证', stageDeliveryFinalization: '交付收尾', stageMixed: '混合', stageUnknown: '未知',
  unanalysed: '未分析', stale: '已过期', failed: '失败', unavailable: '材料不可用', cancelled: '已取消', pending: '等待中', succeeded: '已分类', interrupted: '已中断', running: '进行中', completed: '已结束', aborted: '用户中止', endedWithError: '错误结束', unknownEnd: '已结束',
  reasoning: '完整 Think / reasoning', assistantText: '对外文本', assistantOther: '其他助手内容', tools: '全部工具调用与返回', toolArguments: '完整参数', toolResult: '完整返回', toolError: '工具报告错误', missingResult: '未记录返回', notDispatched: '工具调用未派发', attempts: '尝试与重试',
  analysis: '阶段分类', analysisStatus: '分类状态', confidence: 'Confidence', probabilities: 'Probabilities', notProvided: '未提供', model: '返回模型', configuredModel: '配置模型', details: '分类输入与返回', closeDetails: '收起详情', detailFailed: '无法读取分类记录', requestSent: '脱敏判断输入', previousSavedResult: '之前保存的有效结果', viewPreviousRecord: '查看旧记录', rawResponse: '原始回答', parsedResponse: '统一答案', redactionNote: '分类输入在发送和保存前已脱敏；下方来源记录保持原文', uncalibrated: '未经校准', sourceStep: '来源步骤',
  noReasoning: '本步骤未记录 reasoning 内容', noText: '本步骤未记录对外文本', noTools: '本步骤没有工具调用', notComplete: '本步骤仍在进行中，不能分类', terminalPartial: '本轮在步骤闭合前结束；这里展示已记录材料，部分返回可能缺失', staleNotice: '这条保存的分类已过期，不参与当前阶段合并', noMaterial: '没有可分类的已记录材料', materialTooLarge: '完整步骤超过请求上限，未截断发送', blocked: '已阻塞', maxTokens: '达到输出上限', forked: '派生会话边界',
}
