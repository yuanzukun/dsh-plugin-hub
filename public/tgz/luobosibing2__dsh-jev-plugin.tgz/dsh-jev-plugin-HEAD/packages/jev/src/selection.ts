/** Jev selectors at the existing skill catalog and glob tool seams. */
import { createHash } from 'node:crypto'
import type { Context, Volatile } from '@deepseek-ai/cordis'
import s from '@deepseek-ai/schemastery'
import type { Agent, PreStepDecision } from '@deepseek-ai/dsh-agent'
import { createUserMessage, type Message, type UserMessage } from '@deepseek-ai/dsh-llm'
import { isModelInvocable, escapeText, type SkillSummary } from '@deepseek-ai/dsh-skill'
import { trySaveFormattedResult } from '@deepseek-ai/dsh-tool-fs-search'
import { defineTool, type ToolExecution, type ToolExecutionResult } from '@deepseek-ai/dsh-tools'
import type {} from '@deepseek-ai/dsh-settings'
import type {} from '@deepseek-ai/dsh-tool-skill'
import type {} from '@deepseek-ai/dsh-working-directory'
import { JevError } from './index.ts'
import type { SelectionConfigValues } from './selection-types.ts'
import type { JevRequest, JevResponse } from './types.ts'

/** Live skill-selection and glob-ranking settings for the current profile. */
export interface Config {
  skillLimit: Volatile<number>
  skillMinProbability: Volatile<number>
  fileCandidates: Volatile<number>
  fileLimit: Volatile<number>
}

export const Config: s<SelectionConfigValues, Config> = s.object({
  skillLimit: s.number().step(1).min(1).max(Number.MAX_SAFE_INTEGER).default(5).volatile(),
  skillMinProbability: s.transform(s.number().min(0).max(1), value => {
    if (!Number.isFinite(value)) throw new Error('skillMinProbability must be finite')
    return value
  }).default(0.5).volatile(),
  fileCandidates: s.number().step(1).min(1).max(Number.MAX_SAFE_INTEGER).default(40).volatile(),
  fileLimit: s.number().step(1).min(1).max(Number.MAX_SAFE_INTEGER).default(12).volatile(),
})

interface CatalogEntry { name: string; description: string }
interface SelectedCatalogSource {
  kind: 'jev-skill-catalog'
  form: 'catalog'
  /** Exactly the entries rendered in this model-visible message. */
  entries: CatalogEntry[]
  /** Identity of the complete model-invocable directory at publication. */
  fullFingerprint: string
  /** Effective settings for this judgment; absent in catalogs recorded before probability filtering. */
  selection?: Pick<SelectionConfigValues, 'skillMinProbability' | 'skillLimit'>
}

declare module '@deepseek-ai/dsh-llm' {
  interface MessageSourceMap {
    'jev-skill-catalog': SelectedCatalogSource
    'jev-file-ranking': { kind: 'jev-file-ranking'; form: 'notice'; summary: string }
  }
}

interface Ranked<T> { item: T; index: number; probability: number; confidence?: number }
interface GlobValue { root: string; paths: string[] }
interface GlobRanking { scores: Ranked<string>[]; limit: number }
class RankingConditionsChanged extends Error {}

function positive(value: number, name: string): number {
  if (!Number.isSafeInteger(value) || value < 1) throw new Error(name + ' must be a positive safe integer')
  return value
}

function liveRoot(ctx: Context, agent: Agent | undefined): agent is Agent {
  return agent !== undefined && ctx.agents.get(agent.id) === agent && ctx.agents.roots().includes(agent)
}

/** Use the native live directory when available; legacy providers receive the Session's original directory or their default. */
async function skillDirectory(ctx: Context, agent: Agent | undefined, signal: AbortSignal): Promise<string | undefined> {
  if (agent === undefined) return undefined
  const directory = ctx.get('workingDirectory')
  return directory === undefined ? agent.session.header.cwd : directory.ensure(agent, signal)
}

function textOf(message: Message): string {
  return message.content.filter(block => block.type === 'text').map(block => block.text).join('\n').trim()
}

/** Direct user and visible assistant text, selected and trimmed from newest to oldest. */
function taskContext(agent: Agent, pending: readonly UserMessage[] = []): { role: 'user' | 'assistant'; text: string }[] {
  const history = agent.session.deriveMessages()
  const all = [...history, ...pending.filter(item => !history.some(old => old.id === item.id))]
  const recent: { position: number; role: 'user' | 'assistant'; text: string }[] = []
  let users = 0
  let assistants = 0
  for (let position = all.length - 1; position >= 0; position--) {
    const item = all[position]!
    if (item.role === 'user' && item.source.kind === 'user' && users < 2) {
      const text = textOf(item)
      if (text) { recent.push({ position, role: 'user', text }); users++ }
    } else if (item.role === 'assistant' && assistants < 1) {
      const text = textOf(item)
      if (text) { recent.push({ position, role: 'assistant', text }); assistants++ }
    }
    if (users === 2 && assistants === 1) break
  }
  let remaining = 2_000
  return recent.sort((a, b) => b.position - a.position).map(item => {
    const text = remaining === 0 ? '' : item.text.slice(-remaining)
    remaining -= text.length
    return { ...item, text }
  }).filter(item => item.text.length > 0).sort((a, b) => a.position - b.position)
    .map(({ role, text }) => ({ role, text }))
}

function fingerprint(entries: readonly CatalogEntry[]): string {
  return createHash('sha256').update(JSON.stringify(entries)).digest('hex')
}

function latestSelectedCatalog(agent: Agent): SelectedCatalogSource | undefined {
  for (const message of agent.session.deriveMessages().reverse()) {
    if (message.role !== 'user') continue
    if (message.source.kind === 'skill-catalog') return undefined
    if (message.source.kind !== 'jev-skill-catalog') continue
    if (typeof message.source.fullFingerprint === 'string' && Array.isArray(message.source.entries)) return message.source
  }
  return undefined
}

/** Latest descriptions from catalogs still visible to this Agent after compaction and replay. */
function visibleSkillDescriptions(agent: Agent): Map<string, string> {
  const descriptions = new Map<string, string>()
  for (const message of agent.session.deriveMessages()) {
    if (message.role !== 'user') continue
    if (message.source.kind !== 'skill-catalog' && message.source.kind !== 'jev-skill-catalog') continue
    const entries: unknown = message.source.entries
    if (!Array.isArray(entries)) continue
    for (const entry of entries) {
      if (typeof entry === 'object' && entry !== null
        && 'name' in entry && typeof entry.name === 'string'
        && 'description' in entry && typeof entry.description === 'string') {
        descriptions.set(entry.name, entry.description)
      }
    }
  }
  return descriptions
}

function validAnswers(items: readonly unknown[], response: JevResponse): boolean {
  return response.answers.length === items.length && response.answers.every((answer, index) =>
    answer.id === 'candidate-' + index && answer.kind === 'noul')
}

function scored<T>(items: readonly T[], response: JevResponse): Ranked<T>[] {
  return items.map((item, index) => {
    const answer = response.answers[index]
    if (answer?.id !== 'candidate-' + index || answer.kind !== 'noul') throw new Error('Jev returned an incomplete ranking')
    return { item, index, probability: answer.probability,
      ...answer.confidence === undefined ? {} : { confidence: answer.confidence } }
  })
}

function byProbability<T>(a: Ranked<T>, b: Ranked<T>): number {
  return b.probability - a.probability || a.index - b.index
}

function question(index: number, prompt: string) {
  return { id: 'candidate-' + index, kind: 'noul' as const, prompt }
}

function selectedCatalog(
  items: readonly Ranked<SkillSummary>[], fullFingerprint: string, total: number, selectedCount: number,
  selection: NonNullable<SelectedCatalogSource['selection']>,
): UserMessage {
  const entries = items.map(({ item }) => ({ name: item.name, description: item.description }))
  const lines = items.map(({ item, probability, confidence }) =>
    '- ' + item.name + ': ' + escapeText(item.description) + ' (relevance probability ' + probability
      + (confidence === undefined ? '' : ', confidence ' + confidence) + ')')
  return createUserMessage({
    source: { kind: 'jev-skill-catalog', form: 'catalog', entries, fullFingerprint, selection },
    content: [{ type: 'text', text: [
      '<system-reminder>',
      selectedCount === 0
        ? 'No skill reached the minimum relevance probability in this judgment. Continue the task.'
        : 'Jev selected the top ' + selectedCount + ' of ' + total + ' model-invocable skills. These ' + items.length + ' new summaries supplement the catalogs already visible in this session. Use the latest summary for any repeated skill name. Probabilities estimate relevance, not task success.',
      '<available_skills>', ...lines, '</available_skills>',
      'Call the skill tool with an exact name before following its instructions. This is a partial catalog; call skill_catalog to see every currently model-invocable skill summary. A user may invoke an eligible skill directly.',
      '</system-reminder>',
    ].join('\n') }],
  })
}

function hostCatalog(decision: PreStepDecision): UserMessage | undefined {
  return decision.kind === 'reject' ? undefined : decision.messages.find(message => message.source.kind === 'skill-catalog')
}

function replaceCatalog(decision: PreStepDecision, original: UserMessage | undefined, replacement?: UserMessage): PreStepDecision {
  if (decision.kind === 'reject') return decision
  const messages = original === undefined ? decision.messages : decision.messages.filter(message => message.id !== original.id)
  return { ...decision, messages: replacement === undefined ? messages : [...messages, replacement] }
}

function globValue(result: ToolExecutionResult): GlobValue | undefined {
  if (result.isError || typeof result.value !== 'object' || result.value === null || Array.isArray(result.value)) return undefined
  const value = result.value
  if (typeof value.root !== 'string' || !Array.isArray(value.paths) || !value.paths.every(path => typeof path === 'string')) return undefined
  return { root: value.root, paths: value.paths }
}

function globArgs(value: unknown): { pattern: string; path?: string } | undefined {
  if (typeof value !== 'object' || value === null || !('pattern' in value) || typeof value.pattern !== 'string') return undefined
  return { pattern: value.pattern,
    ...'path' in value && typeof value.path === 'string' ? { path: value.path } : {} }
}

function rankLines(scores: readonly Ranked<string>[]): string[] {
  return scores.map(({ item, probability, confidence }) =>
    probability + (confidence === undefined ? '' : ' (confidence ' + confidence + ')') + ' ' + item)
}

function rankingText(scores: readonly Ranked<string>[], limit: number, recovery?: string): string {
  const shown = Math.min(scores.length, limit)
  return [...rankLines(scores.slice(0, shown)),
    'Jev evaluated ' + scores.length + ' of ' + scores.length + ' candidate paths; showing ' + shown
      + '; omitted ' + (scores.length - shown) + '. Scores estimate path relevance only.',
    ...shown === scores.length ? [] : [recovery ?? 'The complete ranked result could not be saved; narrow the glob pattern to inspect the rest.'],
  ].join('\n')
}

/** Register selectors and an ordinary complete skill-catalog recovery tool. */
export function apply(ctx: Context, config: Config): void {
  ctx.effect(() => ctx.jev.registerFeature({
    id: 'skill-selection', name: 'Skill selection', description: 'Rank model-invocable skill summaries for the current task',
  }))
  ctx.effect(() => ctx.jev.registerFeature({
    id: 'file-ranking', name: 'File path ranking', description: 'Rank paths returned by glob',
  }))
  ctx.effect(() => ctx.settings.configure({ auto: false }, ctx.fiber), 'jev-selection.settings')

  ctx.tools.register(defineTool({
    name: 'skill_catalog',
    description: 'Show every currently model-invocable skill name and summary. Load one with the skill tool using its exact name.',
    parameters: {},
    output: {
      schema: { type: 'object', additionalProperties: false, properties: {
        skills: { type: 'array', required: true, items: { type: 'object', additionalProperties: false, properties: {
          name: { type: 'string', required: true }, description: { type: 'string', required: true },
        } } },
      } },
      render: (_args, value) => [{ type: 'text', text: value.skills.map(skill =>
        '- ' + skill.name + ': ' + skill.description).join('\n') || 'No model-invocable skills are available.' }],
    },
    async execute(_args, exec) {
      const cwd = await skillDirectory(ctx, exec.agent, exec.signal)
      const snapshot = await ctx.skills.snapshot({ cwd, signal: exec.signal, scope: exec.agent })
      if (!snapshot.complete) throw new Error('Skill catalog is incomplete')
      return { skills: snapshot.skills.filter(isModelInvocable).map(({ name, description }) => ({ name, description })) }
    },
  }))

  const checkedDirectories = new WeakMap<Agent, { fingerprint: string; replaceGeneration: number }>()
  ctx.on('agent/pre-step', async ({ agent, messages, signal }, next): Promise<PreStepDecision> => {
    const decision = await next()
    if (decision.kind === 'reject' || !liveRoot(ctx, agent)) return decision
    const original = hostCatalog(decision)
    if (!(await ctx.jev.listFeatures()).some(feature => feature.id === 'skill-selection' && feature.enabled)) {
      checkedDirectories.delete(agent)
      return decision
    }
    if (ctx.tools.get('skill', agent) === undefined) return decision
    signal.throwIfAborted()
    const cwd = await skillDirectory(ctx, agent, signal)
    const snapshot = await ctx.skills.snapshot({ cwd, signal, scope: agent })
    if (!snapshot.complete) return decision
    const skills = snapshot.skills.filter(isModelInvocable)
    if (skills.length === 0) return decision
    const fullFingerprint = fingerprint(skills.map(({ name, description }) => ({ name, description })))
    const prior = latestSelectedCatalog(agent)
    const checked = checkedDirectories.get(agent)
    const hasNewUser = messages.some(message => message.source.kind === 'user' && textOf(message))
    const alreadyChecked = checked?.fingerprint === fullFingerprint
      && checked.replaceGeneration === agent.session.surface.replaceGeneration
    if (!hasNewUser && (alreadyChecked || (checked === undefined
      && agent.session.surface.replaceGeneration === 0 && prior?.fullFingerprint === fullFingerprint))) {
      return replaceCatalog(decision, original)
    }
    const context = taskContext(agent, messages)
    if (context.length === 0) return decision
    let current = skills
    let currentFingerprint = fullFingerprint
    let currentLimit = positive(config.skillLimit.get(), 'skillLimit')
    let currentMinProbability = config.skillMinProbability.get()
    const makeRequest = (): JevRequest => ({ state: { context: taskContext(agent, messages) },
      questions: current.map((skill, index) => question(index,
        'Would this skill help the task? Skill: ' + skill.name + '. Description: ' + skill.description)) })
    const initial = makeRequest()
    let first = true
    const outcome = await ctx.jev.judge({
      featureId: 'skill-selection', agent, signal, link: { sessionId: agent.session.id },
      refresh: async retrySignal => {
        if (first) { first = false; return initial }
        const cwd = await skillDirectory(ctx, agent, retrySignal)
        const refreshed = await ctx.skills.snapshot({ cwd, signal: retrySignal, scope: agent })
        if (!refreshed.complete) throw new Error('Skill catalog is incomplete')
        current = refreshed.skills.filter(isModelInvocable)
        if (current.length === 0) throw new Error('No skills remain available')
        currentFingerprint = fingerprint(current.map(({ name, description }) => ({ name, description })))
        currentLimit = positive(config.skillLimit.get(), 'skillLimit')
        currentMinProbability = config.skillMinProbability.get()
        return makeRequest()
      },
      interpret: response => validAnswers(current, response)
        ? { usable: true } : { usable: false, reason: 'Jev returned an incomplete skill ranking' },
    })
    if (outcome.kind !== 'ok') throw new JevError('CANCELLED', 'Skill selection was cancelled or could not be adopted')
    const chosen = scored(current, outcome.response).filter(item => item.probability >= currentMinProbability)
      .sort(byProbability).slice(0, currentLimit)
    const existing = visibleSkillDescriptions(agent)
    const additions = chosen.filter(({ item }) => existing.get(item.name) !== item.description)
    checkedDirectories.set(agent, {
      fingerprint: currentFingerprint, replaceGeneration: agent.session.surface.replaceGeneration,
    })
    await ctx.jev.writeReceipt(outcome.operationId, {
      id: chosen.length === 0 ? 'skill-catalog-no-relevant'
        : additions.length === 0 ? 'skill-catalog-no-new' : 'skill-catalog-published',
      status: 'observed', at: new Date().toISOString(),
      ...chosen.length === 0 ? { reason: 'No skill reached the minimum relevance probability in this judgment' }
        : additions.length === 0 ? { reason: 'All selected summaries match the latest visible session catalogs' } : {},
    })
    return replaceCatalog(decision, original, chosen.length > 0 && additions.length === 0
      ? undefined : selectedCatalog(additions, currentFingerprint, current.length, chosen.length, {
        skillMinProbability: currentMinProbability, skillLimit: currentLimit,
      }))
  }, { prepend: true })

  const globRankings = new Map<ToolExecution['token'], GlobRanking>()
  ctx.on('tools/result', exec => { globRankings.delete(exec.token) })
  ctx.on('tools/execute', async (exec, next) => {
    if (exec.name !== 'glob') return next()
    const result = await next()
    const value = globValue(result)
    if (result.isError || value === undefined || value.paths.length === 0 || !liveRoot(ctx, exec.agent)) return result
    if (!(await ctx.jev.listFeatures()).some(feature => feature.id === 'file-ranking' && feature.enabled)) return result
    if (value.paths.length > positive(config.fileCandidates.get(), 'fileCandidates')) return result
    const agent = exec.agent
    if (taskContext(agent).length === 0) return result
    const args = globArgs(exec.arguments)
    if (args === undefined) return result
    exec.signal.throwIfAborted()
    let limit = positive(config.fileLimit.get(), 'fileLimit')
    let first = true
    const makeRequest = (): JevRequest => ({ state: {
      context: taskContext(agent), pattern: args.pattern, path: args.path ?? '.',
    }, questions: value.paths.map((path, index) => question(index, 'Is this path relevant to the task? Path: ' + path)) })
    const initial = makeRequest()
    const outcome = await ctx.jev.judge({
      featureId: 'file-ranking', agent, signal: exec.signal, link: { sessionId: agent.session.id },
      refresh: () => {
        if (first) { first = false; return initial }
        if (value.paths.length > positive(config.fileCandidates.get(), 'fileCandidates')) {
          throw new RankingConditionsChanged('Glob results now exceed the Jev candidate setting')
        }
        limit = positive(config.fileLimit.get(), 'fileLimit')
        return makeRequest()
      },
      interpret: response => validAnswers(value.paths, response)
        ? { usable: true } : { usable: false, reason: 'Jev returned an incomplete path ranking' },
    }).catch(error => {
      if (error instanceof RankingConditionsChanged) return undefined
      throw error
    })
    if (outcome === undefined) return result
    if (outcome.kind !== 'ok') throw new JevError('CANCELLED', 'File ranking was cancelled or could not be adopted')
    const scores = scored(value.paths, outcome.response).sort(byProbability)
    await ctx.jev.writeReceipt(outcome.operationId, { id: 'glob-paths-ranked', status: 'observed', at: new Date().toISOString() })
    globRankings.set(exec.token, { scores, limit })
    return { ...result, value: { root: value.root, paths: scores.map(score => score.item) } }
  })

  ctx.on('tools/post-execute', async (exec, result, next) => {
    const decision = await next()
    const ranking = globRankings.get(exec.token)
    if (ranking === undefined) return decision
    globRankings.delete(exec.token)
    if (result.isError || decision.kind !== 'accept' || decision.value !== undefined) return decision
    const complete = rankLines(ranking.scores).join('\n')
    const spill = ranking.scores.length > ranking.limit
      ? await trySaveFormattedResult(ctx, exec, 'jev-glob-ranked.txt', complete)
      : undefined
    const recovery = spill === undefined ? undefined : 'Full ranked result stored at: ' + spill.locator + '. ' + spill.retrievalHint
    const storageUnavailable = spill === undefined && ranking.scores.length > ranking.limit
    const summary = rankingText(ranking.scores, storageUnavailable ? ranking.scores.length : ranking.limit, recovery)
      + (storageUnavailable ? '\nComplete ranked list shown inline because result storage is unavailable.' : '')
    const context = createUserMessage({ source: {
      kind: 'jev-file-ranking', form: 'notice', summary: 'Jev ranked glob call ' + exec.callId,
    }, content: [{ type: 'text', text: 'Glob call ' + exec.callId + ', pattern ' + globArgs(exec.arguments)?.pattern + '\n' + summary }] })
    return { kind: 'accept', content: [{ type: 'text', text: summary }], additionalContexts: [
      ...decision.additionalContexts ?? [], ...exec.parent === undefined ? [] : [context],
    ] }
  }, { prepend: true })
}

export const inject = ['jev', 'tools', 'skills', 'settings', 'agents']
export const name = 'jev-selection'
