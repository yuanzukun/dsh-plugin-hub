# Validation / 验证说明

[English](../README.md) · [简体中文](../README.zh-CN.md)

The checked-in source and tests are public. Raw live-session captures, personal screenshots, credentials, runtime installations, and machine-specific experiments are not part of the public source history.

公开源码包含实现和可复测测试；真实会话原始抓取、个人截图、凭据、运行环境和绑定本机的实验资料不随源码公开。

Existing live completion-check results use the earlier recorded-evidence semantics; lightweight report checks have no real-task effectiveness evidence yet.

已有完成核查实测使用此前的已有证据核查语义；轻量报告核查尚无真实任务效果证据。

The [2026-10-30 Harness compatibility report](testing/2026-10-30-harness-compatibility/README.md) covers the DSH 0.2.1-rc.5 upgrade with deterministic official-package, Host and Web integration checks and zero live model calls.

The [2026-10-29 Harness compatibility report](testing/2026-10-29-harness-compatibility/README.md) covers the DSH 0.2.1-rc.3 upgrade on Windows with deterministic official-package, Host and Web integration checks and zero live model calls.

The [2026-10-21 Harness compatibility report](testing/2026-10-21-harness-compatibility/README.md) covers the earlier DSH 0.2.1-rc.2 upgrade with deterministic official-package, Host and Web integration checks and zero live model calls.

[2026-10-30 Harness 兼容报告](testing/2026-10-30-harness-compatibility/README.md)记录 DSH 0.2.1-rc.5 升级，检查正式包、Host 与 Web 的确定性接入，真实模型调用为 0。

[2026-10-29 Harness 兼容报告](testing/2026-10-29-harness-compatibility/README.md)记录 Windows 上 DSH 0.2.1-rc.3 升级，检查正式包、Host 与 Web 的确定性接入，真实模型调用为 0。

[2026-10-21 Harness 兼容报告](testing/2026-10-21-harness-compatibility/README.md)记录此前 DSH 0.2.1-rc.2 升级，检查正式包、Host 与 Web 的确定性接入，真实模型调用为 0。

The [2026-10-09–10 Harness compatibility report](testing/2026-10-09-harness-compatibility/README.md) covers the earlier DSH 0.2.1-alpha.2 revision: the old package's actual installation rejection, the adapted package's official installation and Web client, new real DeepSeek Flash / Jev tasks, and scoped lifecycle tests. The older reports below retain their original runtime versions and experiment conditions.

[2026-10-09–10 Harness 兼容报告](testing/2026-10-09-harness-compatibility/README.md)验证此前 DSH 0.2.1-alpha.2 适配：旧包的实际安装拒绝、适配包的正式安装与 Web 客户端、新一轮真实 DeepSeek Flash / Jev 任务及有界生命周期测试。下面的历史报告保留各自原始版本和实验条件。

The [Jev / Luna public report](testing/2026-10-07-luna-decisions/public-results.md) separates fixed protocol/installation checks, controlled live samples, and real main-model tasks. Both Luna APIs are supported in `main`; the executed official samples and the failed OpenRouter access attempt retain different conclusions.

[Jev / Luna 公开报告](testing/2026-10-07-luna-decisions/public-results.zh-CN.md)分别记录固定协议及安装、受控真实样例与真实主模型任务。`main`支持两种Luna API；官方执行样例与OpenRouter访问失败保留不同结论。

| Area / 范围 | Evidence / 证据 | Limit / 边界 |
| --- | --- | --- |
| Shared service; skill/glob selection / 公共服务与选择 | [Public selection results](testing/jev-selection/public-results.zh-CN.md): deterministic service tests and DSH Web installation checks / [公开选择结果](testing/jev-selection/public-results.zh-CN.md)：确定性测试与 Web 安装验证 | No broad task-success or performance claim / 不声明大规模任务效果 |
| Supervision and correction hooks / 监督与纠正 | [Public result summary](testing/2026-09-27-jev-hooks/public-results.zh-CN.md): 152-test integration run and limited real-model cases / [公开结果摘要](testing/2026-09-27-jev-hooks/public-results.zh-CN.md)：152项集成及有限真实样例 | Completion false negative; drift reminder delivery not observed in the live sample; cross-form shared duplicates remain / 保留完成漏检、跑偏未验到实际送达及共享重复 |
| Workspace approval / 工作区审批 | Native DSH integration, six deterministic Host/UI cases, three real DeepSeek tasks and four Jev judgments / 原生集成、6个Host/UI场景、3个真实主任务及4次Jev判断 | Two real approvals executed, one forbidden case returned to human rejection, one explicitly authorized case was misclassified / 两个批准执行、一个禁止负例转人工拒绝、一个明确授权样例误判 |
| Tool-output admission / 工具输出准入 | [Real-profile report](reports/2026-09-27-tool-output-admission.md) / [真实 profile 报告](reports/2026-09-27-tool-output-admission.zh-CN.md): deterministic integration plus one genuine build log reduced by 75.7%; native full-log spill was recovered / 确定性集成、真实构建日志缩短75.7%、原生完整日志spill回读 | One synthetic project; a neutral 180-test run was judged but fully retained below the 0.8 threshold, so test-log reduction was not shown; no same-result Jev-plus-native-spill case / 单个合成项目；中性180项测试触发判断但低于0.8而完整保留，未观察到测试日志净缩减；未验同一结果同时触发Jev与原生spill |
| Jev / Luna connections and records / Jev 与 Luna 连接及记录 | [Wire](../packages/jev/tests/wire.test.ts), [Host](../packages/jev/tests/host.test.ts), [Client](../packages/jev/tests/client-ui.test.tsx), [business integration](../packages/jev/tests/luna-business-integration.test.ts), and stage tests; final local suite: 27 files / 300 tests. Built tarball installed in two isolated official DSH 0.1.7-rc.2 Web profiles; eight fixed localhost requests cover all three connections, saved settings, native refusal, and original-versus-normalized records / 协议、Host、Client、业务接线及阶段测试；最终本地集合为27文件/300用例。构建包已安装到两个隔离的官方Web profile，8次固定本地请求覆盖三连接、正常设置保存、官方拒绝及原始和统一答案展示 | Integrated in main; deterministic localhost providers establish installation and protocol behavior, not real API availability, Luna quality, or actual cost / 已集成到main；固定本地服务验证安装及协议行为，不代表真实API可用性、Luna判断质量或实际费用 |
| Live Luna / OpenRouter attempt / Luna的OpenRouter真实尝试 | [Controlled API report](testing/2026-10-07-luna-decisions/public-results.md#controlled-live-api-samples): built plugin sent one fixed Choice/Score/Noul diagnostic to the native Decisions endpoint for `openai/gpt-6-luna-decisions`; HTTP 403 reported a provider Terms Of Service prohibition. Key-information GET separately returned HTTP 200. The failed attempt, original response, no normalized answers, and no action receipts were checked / 构建插件执行1次固定三题真实诊断，提供方以服务条款限制返回403；独立Key信息GET返回200。已核对失败记录、原始响应、无统一答案及无动作回执 | No OpenRouter business samples executed or successful model answers; no reported usage/cost, retry or fallback. The user subsequently stopped this channel and authorized official OpenAI validation / OpenRouter未执行业务样例、无成功答案及用量费用报告、无重试或回退。用户随后停止处理此渠道并授权官方OpenAI验真 |
| Live Luna / OpenAI validation / Luna的OpenAI真实验真 | [Controlled samples](testing/2026-10-07-luna-decisions/public-results.md#controlled-live-api-samples): six real requests through the built plugin returned HTTP 200 and `gpt-6-luna`. The Choice/Score/Noul diagnostic preserved IDs, fractional Score and raw arrays. File ranking placed the target first; one synthetic log retained all 2,351 characters below the original 0.8 omission threshold, another reduced to 440 characters with exact original recovery. Explicit single-write approval returned `unauthorized` both before and after a native read established absence; native delegation and sandbox protection remained effective. Reported input/output tokens total 6,541/0 / 构建插件6次真实请求均返回200及指定模型；三题转换保留ID、小数分数和原始数组。目标文件排首；一份合成日志低于原0.8门槛完整保留，另一份由2,351缩至440字符且原文回读一致。明确授权写入在原生读取确认不存在前后均被判unauthorized，原生转交与sandbox保护有效。报告用量为6,541/0 tokens | One diagnostic and five business fixtures; fixed main-model/tool material, real auxiliary Luna answers and native approval/read/write. Log trigger length was 1,500 only in the fixture; product defaults, omission threshold and wait were unchanged. This phase established no automatic approval positive case, natural-task accuracy, cold-stage coverage or actual cost / 1个诊断与5个业务夹具；固定主模型及工具材料，真实Luna判断和原生审批/read/write。仅夹具日志触发长度为1,500，产品默认值、省略门槛及等待未改。该阶段未观察到自动批准正例，未验证自然任务准确率、cold stage或实际费用 |
| Real main-model tasks with official Luna / 真实主模型与官方Luna任务 | [Real-task report](testing/2026-10-07-luna-decisions/public-results.md#real-main-model-tasks-and-session-continuation): same tarball installed in an isolated official DSH 0.1.7-rc.2 headless profile; 82 runtime files matched. Two real DeepSeek Flash tasks and one continuation in the first Session used 14 main-model requests and three Luna requests, all HTTP 200. Actual TypeScript build: 160 modules, sum 12,880, independently checked hash; refund tests: 3/3. Five paths were judged but all scored 1, preserving order. The initial 7,127-character log had no recognized candidates and stayed intact. A supported numeric-progress build reduced 8,407 to 2,122 characters (74.76%), with exact native spill recovery and the reduced text observed in the next real main request. One explicitly authorized external write received Luna `approve`, native `allowed-once`, an executed receipt and exact file contents / 同包安装到独立官方headless profile，82文件一致。两个真实DeepSeek Flash任务及首个Session续验，共14次主模型和3次Luna请求，均200；实际构建160模块、sum12880、哈希独立一致，退款测试3/3。五路径均得1分，原序不变；首份7,127字符日志无可识别候选而保留。支持的数字进度日志由8,407缩至2,122字符（74.76%），原生spill回读一致，下一次真实主请求实际收到缩短文本；一个明确授权外部写得到approve、原生allowed-once、执行回执及准确内容 | Disposable task materials and extra QA tool limits; no production question, 6,000-character trigger, 0.8 threshold, four-second wait or permission change. The successful approval does not erase the prior two controlled misses or establish reliability; no ranking improvement, full feature coverage, cold stage or natural-task accuracy claim. Actual cost was not returned / 可丢弃任务材料及额外QA工具限制；生产题、6,000触发长度、0.8门槛、4秒等待和权限未变。成功审批不抹去前两个受控未达预期结果，不证明稳定性；不声明排序改善、全功能覆盖、cold stage或自然任务准确率。费用未返回 |
| Native web branch / 网页分支 | Local and limited Native integration checks / 本地及限定Native验证 | Paused after unsatisfactory ordinary-site use; do not treat as accepted / 普通网站效果不佳后暂停，未验收通过 |

Counts describe particular executed test sets, not a live badge, total unique-case count, or accuracy rate. Real-model replies vary. Tests and traces distinguish an approval from an executed effect; a model's final narrative is not execution evidence.

以上数量是特定已执行集合，不是持续集成徽章、全部去重用例数或准确率。真实模型答案可变化；批准与实际执行分别记录，模型最终自述不能替代操作证据。

Workspace approval has a checked-in [QA case guide](../packages/jev/tests/workspace-approval-qa.md). Run paid-provider examples only with explicit authorization and a bounded budget; use disposable workspaces and keep service credentials outside Git.

工作区审批的[QA用例](../packages/jev/tests/workspace-approval-qa.md)已入库。真实服务复测需明确授权和预算，使用可丢弃工作区，不将服务凭据纳入Git。
