"""Repository-local evaluation tools."""
