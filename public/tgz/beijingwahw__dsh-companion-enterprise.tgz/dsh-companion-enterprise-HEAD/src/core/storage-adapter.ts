/**
 * 存储适配层：桥接插件内部存储契约与真实 Harness 存储 API。
 *
 * 插件内部使用的存储接口（Domain / KvTable / defineDomain）与
 * `@deepseek-ai/dsh-storage-domain` 的真实 API 存在以下差异：
 * - 表名：插件使用连字符（如 'usage-daily'），真实 API 要求 UNIT_NAME_RE（仅小写字母/数字/下划线）
 * - keys()/entries()：插件期望数组，真实 API 返回迭代器
 * - delete()：插件期望 Promise<void>，真实 API 返回 Promise<boolean>
 * - update()：插件回调返回 V|undefined（undefined=删除），真实 API 回调返回 V（键不存在则抛错）
 * - Domain.global：插件期望 KvTable，真实 API 是 DomainGlobal<G>
 * - defineDomain：插件仅传 name/version，真实 API 要求声明所有表及 zod schema
 *
 * 本模块提供适配函数，使插件代码无需修改即可运行在真实 Harness 上。
 */
import {
  defineDomain as realDefineDomain,
  domainTable,
  type Domain as RealDomain,
  type DomainSpec as RealDomainSpec,
  type KvTable as RealKvTable,
} from '@deepseek-ai/dsh-storage-domain'
import { z } from 'zod'

// ---------------------------------------------------------------------------
// 插件内部存储契约类型（与原 storage.d.ts 一致）
// ---------------------------------------------------------------------------

/** 存储域规格：名称 + 单调递增的 schema 版本。 */
export interface DomainSpec {
  readonly name: string
  readonly version: number
  readonly description?: string
}

/** 类型化键值表：读同步（权威内存状态），写排入每域写链。 */
export interface KvTable<V = unknown> {
  get(key: string): V | undefined
  keys(): string[]
  entries(): [string, V][]
  readonly size: number
  put(key: string, value: V): Promise<void>
  delete(key: string): Promise<void>
  /** 原子读-改-写；回调返回 undefined 表示删除该键。 */
  update(key: string, fn: (prev: V | undefined) => V | undefined): Promise<void>
}

/** 打开后的存储域。 */
export interface Domain {
  readonly spec: DomainSpec
  table<V = unknown>(name: string): KvTable<V>
  readonly global: KvTable
}

/** 域设施（ctx.storageDomain）。 */
export interface DomainFacility {
  open(spec: DomainSpec): Promise<Domain>
  get(name: string): Domain | undefined
  closeAll(): Promise<void>
}

// ---------------------------------------------------------------------------
// 表名转换：连字符 → 下划线（满足 UNIT_NAME_RE）
// ---------------------------------------------------------------------------

/** 将插件内部表名（可含连字符）转换为 Harness 合法表名（仅下划线）。 */
function toUnitName(name: string): string {
  return name.replace(/-/g, '_')
}

// ---------------------------------------------------------------------------
// 插件使用的全部表名清单（用于 defineDomain 声明）
// ---------------------------------------------------------------------------

/** 插件所有模块使用的表名（连字符形式）。 */
const ALL_TABLE_NAMES = [
  // core
  'vault-meta', 'vault', 'usage-daily',
  // handoff
  'templates', 'handoff-armed', 'handoff-receipts', 'handoff-structured',
  // cost
  'cost-extra', 'budget-state', 'cost-bandit', 'semantic-cache',
  // search
  'tags', 'search-clicks',
  // arena
  'arena-custom-models', 'arena-canary', 'arena-elo-matches', 'arena-elo-ratings',
  'arena-glicko-matches', 'arena-glicko-ratings',
  // trace
  'traces', 'trace-stats-daily',
  // prompt
  'prompt-versions', 'prompt-templates', 'prompt-ratings', 'prompt-bandit',
  // orchestrator
  'pipelines', 'pipeline-runs', 'queue-tasks', 'scheduled-jobs', 'scheduled-runs',
  // team
  'team-prefs', 'team-snapshots', 'experience-cards', 'distilled-cards',
  'review-requests', 'review-comments', 'review-decisions', 'experience-feedback',
  'team-experts',
  // security
  'named-keys', 'audit-log', 'dlp-rules', 'dlp-builtin-overrides',
  'dlp-settings', 'dlp-blocks-daily', 'audit-alerts', 'sentinel-profiles',
  // export
  'custody-key', 'custody-records', 'export-merkle', 'export-dp-budget',
] as const

// ---------------------------------------------------------------------------
// defineDomain：创建真实 Harness DomainSpec
// ---------------------------------------------------------------------------

/**
 * 声明存储域规格。内部将所有表以 z.unknown() schema 注册到真实 DomainSpec，
 * 使 Harness 存储层能正确打开域。插件自行负责记录级校验。
 */
export function defineDomain(spec: DomainSpec): DomainSpec {
  return spec
}

/**
 * 从插件 DomainSpec 构建真实 Harness DomainSpec（含全部表声明）。
 * 在 openDomain 时调用。
 */
function buildRealSpec(spec: DomainSpec): RealDomainSpec {
  const tables: Record<string, ReturnType<typeof domainTable>> = {}
  for (const name of ALL_TABLE_NAMES) {
    tables[toUnitName(name)] = domainTable(z.unknown())
  }
  return realDefineDomain({
    name: spec.name,
    version: spec.version,
    tables,
  })
}

// ---------------------------------------------------------------------------
// KvTable 适配
// ---------------------------------------------------------------------------

/** 将真实 KvTable 包装为插件期望的 KvTable 接口。 */
function wrapTable<V>(real: RealKvTable<string, unknown>): KvTable<V> {
  return {
    get: (key) => real.get(key) as V | undefined,
    keys: () => [...real.keys()],
    entries: () => [...real.entries()] as [string, V][],
    get size() { return real.size },
    put: (key, value) => real.put(key, value),
    delete: async (key) => { await real.delete(key) },
    update: async (key, fn) => {
      const current = real.get(key) as V | undefined
      const next = fn(current)
      if (next === undefined) {
        // 回调返回 undefined → 删除该键
        await real.delete(key)
      } else if (current === undefined) {
        // 键不存在 → 新增
        await real.put(key, next)
      } else {
        // 键存在 → 原子更新
        await real.update(key, () => next)
      }
    },
  }
}

// ---------------------------------------------------------------------------
// Domain 适配
// ---------------------------------------------------------------------------

/** 将真实 Domain 包装为插件期望的 Domain 接口。 */
function wrapDomain(real: RealDomain<RealDomainSpec>, spec: DomainSpec): Domain {
  const tableCache = new Map<string, KvTable<unknown>>()
  return {
    spec,
    table<V>(name: string): KvTable<V> {
      if (!tableCache.has(name)) {
        tableCache.set(name, wrapTable<V>(real.table(toUnitName(name))))
      }
      return tableCache.get(name) as KvTable<V>
    },
    get global(): KvTable {
      // 插件未使用 domain.global；提供空实现以满足接口。
      throw new Error('companion storage: domain.global is not used by this plugin')
    },
  }
}

// ---------------------------------------------------------------------------
// DomainFacility 适配
// ---------------------------------------------------------------------------

/** 真实 DomainFacility 的类型（来自 @deepseek-ai/dsh-storage-domain）。 */
export interface RealDomainFacility {
  open<S extends RealDomainSpec>(spec: S): Promise<RealDomain<S>>
  get(name: string): unknown
  closeAll(): Promise<void>
}

/**
 * 将真实 DomainFacility 包装为插件期望的 DomainFacility 接口。
 * 在 CompanionCoreService 初始化时调用。
 */
export function wrapFacility(real: RealDomainFacility): DomainFacility {
  const openDomains = new Map<string, Domain>()
  return {
    async open(spec: DomainSpec): Promise<Domain> {
      const realSpec = buildRealSpec(spec)
      const realDomain = await real.open(realSpec)
      const wrapped = wrapDomain(realDomain as RealDomain<RealDomainSpec>, spec)
      openDomains.set(spec.name, wrapped)
      return wrapped
    },
    get(name: string): Domain | undefined {
      return openDomains.get(name)
    },
    async closeAll(): Promise<void> {
      await real.closeAll()
      openDomains.clear()
    },
  }
}
