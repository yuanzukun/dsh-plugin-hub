﻿# Desktop pet window (WPF) - HTTP architecture + floating bubble strip above character
# Usage: powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -WindowStyle Hidden -File pet-window.ps1 -Image <png> -Name <name> -Port <dsh-port> [-Config <json>]
param(
  [string]$Image = (Join-Path $PSScriptRoot 'lihui.png'),
  [string]$Name = '桌宠',
  [int]$Port = 3080,
  [string]$Config = (Join-Path $PSScriptRoot 'config.json')
)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName PresentationFramework, PresentationCore, WindowsBase
Add-Type -AssemblyName System.Windows.Forms | Out-Null

# 单实例互斥: 防止 DSH 重启后旧窗口进程(孤儿)与新进程并存 → 重复立绘窗口
$mutex = New-Object System.Threading.Mutex($false, 'Local\DSHRoleplayPetWindow')
$hasLock = $false
try { $hasLock = $mutex.WaitOne(0) } catch { $hasLock = $true }
if (-not $hasLock) { exit }
# 版本自检: deskpet 每次启动前写 window-version.txt; 本脚本版本比标记旧 → 自退让位(防旧进程永久霸占)
$script:windowVersion = '1.5.10'
$verTimer = New-Object System.Windows.Threading.DispatcherTimer
$verTimer.Interval = [TimeSpan]::FromSeconds(10)
$verTimer.Add_Tick({
  try {
    $vf = Join-Path $PSScriptRoot 'window-version.txt'
    if (Test-Path -LiteralPath $vf) {
      $v = (Get-Content -LiteralPath $vf -Raw -Encoding UTF8).Trim()
      if ($v -and $v -ne $script:windowVersion) {
        try { $mutex.ReleaseMutex() } catch { }
        exit
      }
    }
  } catch { }
})
$verTimer.Start()

$base = "http://127.0.0.1:$Port/pet"
$utf8 = New-Object System.Text.UTF8Encoding($false)
$script:cfg = $null
$script:cfgWin = $null

function Post-Json([string]$path, $obj) {
  try {
    $body = $obj | ConvertTo-Json -Compress
    return Invoke-RestMethod -Uri ($base + $path) -Method Post -ContentType 'application/json; charset=utf-8' -Body $body -TimeoutSec 5
  } catch {
    return $null
  }
}
function Get-Json([string]$path) {
  try {
    return Invoke-RestMethod -Uri ($base + $path) -Method Get -TimeoutSec 4
  } catch {
    return $null
  }
}

# ---------- config ----------
function Read-Config {
  $def = @{
    enabled = $true
    scale = 0.4
    opacity = 0.95
    topmost = $true
    animate = $true
    position = 'bottom-right'
  }
  try {
    if (Test-Path -LiteralPath $Config) {
      $raw = Get-Content -LiteralPath $Config -Raw -Encoding UTF8 | ConvertFrom-Json
      if ($raw) {
        if ($null -ne $raw.enabled) { $def.enabled = [bool]$raw.enabled }
        if ($null -ne $raw.scale) { $def.scale = [double]$raw.scale }
        if ($null -ne $raw.opacity) { $def.opacity = [double]$raw.opacity }
        if ($null -ne $raw.topmost) { $def.topmost = [bool]$raw.topmost }
        if ($null -ne $raw.animate) { $def.animate = [bool]$raw.animate }
        if ($raw.position) { $def.position = [string]$raw.position }
      }
    }
  } catch { }
  return $def
}
function Save-Config {
  try {
    [System.IO.File]::WriteAllText($Config, ($script:cfg | ConvertTo-Json -Compress), $utf8)
  } catch { }
}

$script:cfg = Read-Config

# ---------- window ----------
$win = New-Object System.Windows.Window
$win.Title = $Name
$win.WindowStyle = [System.Windows.WindowStyle]::None
$win.AllowsTransparency = $true
$win.Background = [System.Windows.Media.Brushes]::Transparent
$win.Topmost = [bool]$script:cfg.topmost
$win.ShowInTaskbar = $false
$win.ResizeMode = [System.Windows.ResizeMode]::NoResize
$win.WindowStartupLocation = [System.Windows.WindowStartupLocation]::Manual
$win.Opacity = [double]$script:cfg.opacity

$bmp = New-Object System.Windows.Media.Imaging.BitmapImage
$bmp.BeginInit()
$bmp.UriSource = New-Object System.Uri($Image)
$bmp.CacheOption = [System.Windows.Media.Imaging.BitmapCacheOption]::OnLoad
$bmp.EndInit()

# 精确点击穿透(借鉴 dsh-pet): 把立绘透明区域采样成低分辨率网格, 鼠标落在透明区 → WS_EX_TRANSPARENT(点穿), 落在角色身上 → 正常交互
Add-Type -TypeDefinition @'
using System;
using System.IO;
using System.Windows.Media;
using System.Windows.Media.Imaging;
public static class PetAlpha {
  public static byte[] Grid(string path, int cols) {
    try {
      var dec = BitmapDecoder.Create(new Uri(path), BitmapCreateOptions.IgnoreColorProfile, BitmapCacheOption.OnLoad);
      var fr = dec.Frames[0];
      var cv = new FormatConvertedBitmap(fr, PixelFormats.Pbgra32, null, 0);
      int w = cv.PixelWidth, h = cv.PixelHeight;
      int rows = Math.Max(1, (int)Math.Round((double)h * cols / w));
      var px = new byte[w * h * 4];
      cv.CopyPixels(px, w * 4, 0);
      var grid = new byte[rows * cols];
      for (int r = 0; r < rows; r++) for (int c = 0; c < cols; c++) {
        int x0 = c * w / cols, x1 = (c + 1) * w / cols, y0 = r * h / rows, y1 = (r + 1) * h / rows;
        int sum = 0, n = 0;
        for (int y = y0; y < y1; y += 2) for (int x = x0; x < x1; x += 2) {
          int i = (y * w + x) * 4 + 3;
          sum += px[i]; n++;
        }
        grid[r * cols + c] = (n > 0 && sum / n > 40) ? (byte)1 : (byte)0;
      }
      return grid;
    } catch (Exception) { return null; }
  }
}
'@ -ReferencedAssemblies @('PresentationCore', 'WindowsBase', 'System.Xaml')
$script:alphaGrid = $null
$script:alphaCols = 40
$script:alphaRows = 0
try {
  if (Test-Path -LiteralPath $Image) {
    $script:alphaGrid = [PetAlpha]::Grid($Image, $script:alphaCols)
    if ($script:alphaGrid) { $script:alphaRows = [int]($script:alphaGrid.Length / $script:alphaCols) }
  }
} catch { $script:alphaGrid = $null }

function Set-PetTransparent([bool]$on) {
  try {
    $hwnd = (New-Object System.Windows.Interop.WindowInteropHelper($win)).Handle
    if ($hwnd -eq [IntPtr]::Zero) { return }
    $ex = [PetAlphaNative]::GetWindowLong($hwnd, -20)
    if ($on) { [PetAlphaNative]::SetWindowLong($hwnd, -20, $ex -bor 0x20) }
    else { [PetAlphaNative]::SetWindowLong($hwnd, -20, $ex -band (-bnot 0x20)) }
  } catch { }
}
Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public static class PetAlphaNative {
  [DllImport("user32.dll")] public static extern int GetWindowLong(IntPtr hWnd, int nIndex);
  [DllImport("user32.dll")] public static extern int SetWindowLong(IntPtr hWnd, int nIndex, int dwNewLong);
}
'@

$work = [System.Windows.SystemParameters]::WorkArea
$script:stripH = 110

# ── 姿势集(借鉴 dsh-whale-musume 状态机姿势): 立绘同目录下 lihui-<mode>.png →
#    工作/空闲/待确认; 缺省回退 lihui.png ──
$script:mode = 'idle'
$script:lastMode = ''
function Load-Image([string]$path) {
  try {
    $b2 = New-Object System.Windows.Media.Imaging.BitmapImage
    $b2.BeginInit()
    $b2.UriSource = New-Object System.Uri($path)
    $b2.CacheOption = [System.Windows.Media.Imaging.BitmapCacheOption]::OnLoad
    $b2.EndInit()
    return $b2
  } catch { return $null }
}
function Set-Pose([string]$mode) {
  $base = [System.IO.Path]::GetFileNameWithoutExtension($Image)
  $map = @{ working = 'working'; idle = 'idle'; pending = 'pending' }
  $suffix = $map[$mode]
  $cand = $null
  if ($suffix) {
    $p = Join-Path (Split-Path $Image) ($base + '-' + $suffix + '.png')
    if (Test-Path -LiteralPath $p) { $cand = $p }
  }
  if ($cand) {
    $nb = Load-Image $cand
    if ($nb) { $script:bmpPose = $nb; $img.Source = $nb; Apply-Scale }
  }
}

function Apply-Scale {
  $cur = [System.Windows.Media.ImageSource]$img.Source
  $pw = 1; $ph = 1
  try { $pw = $cur.Width; $ph = $cur.Height } catch { $pw = $bmp.PixelWidth; $ph = $bmp.PixelHeight }
  if ($ph -lt 1) { return }
  $imgH = [int]($work.Height * [double]$script:cfg.scale)
  $ratio = $imgH / $ph
  $win.Width = [int]($pw * $ratio)
  $win.Height = $imgH + $script:stripH
  $inputBox.Width = [Math]::Max(120, $win.Width - 96)
  Apply-Position
}
function Apply-Position {
  $m = 12
  switch ([string]$script:cfg.position) {
    'bottom-left' { $win.Left = $work.Left + $m; $win.Top = $work.Bottom - $win.Height - $m }
    'top-right' { $win.Left = $work.Right - $win.Width - $m; $win.Top = $work.Top + $m }
    'top-left' { $win.Left = $work.Left + $m; $win.Top = $work.Top + $m }
    default { $win.Left = $work.Right - $win.Width - $m; $win.Top = $work.Bottom - $win.Height - $m }
  }
}
function Apply-Opacity { $win.Opacity = [double]$script:cfg.opacity }
function Apply-Topmost { $win.Topmost = [bool]$script:cfg.topmost }
function Apply-Animate {
  if ([bool]$script:cfg.animate) { if (-not $bobTimer.IsEnabled) { $bobTimer.Start() } }
  else { $bobTimer.Stop() }
}

# ---------- layout: bubble strip / character / input ----------
$grid = New-Object System.Windows.Controls.Grid
$rowBubble = New-Object System.Windows.Controls.RowDefinition
$rowBubble.Height = [System.Windows.GridLength]::new($script:stripH, [System.Windows.GridUnitType]::Pixel)
$rowImg = New-Object System.Windows.Controls.RowDefinition
$rowImg.Height = [System.Windows.GridLength]::new(1, [System.Windows.GridUnitType]::Star)
$rowInput = New-Object System.Windows.Controls.RowDefinition
$rowInput.Height = [System.Windows.GridLength]::Auto
$null = $grid.RowDefinitions.Add($rowBubble)
$null = $grid.RowDefinitions.Add($rowImg)
$null = $grid.RowDefinitions.Add($rowInput)

# bubble: anchored to the BOTTOM of the strip, right side -> floats just above the head
$bubbleBorder = New-Object System.Windows.Controls.Border
$bubbleBorder.Background = New-Object System.Windows.Media.SolidColorBrush([System.Windows.Media.Color]::FromArgb(240, 255, 255, 255))
$bubbleBorder.CornerRadius = New-Object System.Windows.CornerRadius(12)
$bubbleBorder.Padding = New-Object System.Windows.Thickness(10, 6, 10, 6)
$bubbleBorder.Margin = New-Object System.Windows.Thickness(10, 0, 46, 4)
$bubbleBorder.MaxWidth = 270
$bubbleBorder.HorizontalAlignment = [System.Windows.HorizontalAlignment]::Right
$bubbleBorder.VerticalAlignment = [System.Windows.VerticalAlignment]::Bottom
$bubbleBorder.Visibility = [System.Windows.Visibility]::Collapsed
$bubbleText = New-Object System.Windows.Controls.TextBlock
$bubbleText.TextWrapping = [System.Windows.TextWrapping]::Wrap
$bubbleText.FontSize = 13
$bubbleText.Foreground = [System.Windows.Media.Brushes]::Black
$bubbleScroll = New-Object System.Windows.Controls.ScrollViewer
$bubbleScroll.VerticalScrollBarVisibility = [System.Windows.Controls.ScrollBarVisibility]::Auto
$bubbleScroll.HorizontalScrollBarVisibility = [System.Windows.Controls.ScrollBarVisibility]::Disabled
$bubbleScroll.MaxHeight = $script:stripH - 14
$bubbleScroll.Content = $bubbleText
$bubbleBorder.Child = $bubbleScroll
[System.Windows.Controls.Grid]::SetRow($bubbleBorder, 0)
$null = $grid.Children.Add($bubbleBorder)

$img = New-Object System.Windows.Controls.Image
$img.Source = $bmp
$img.Stretch = [System.Windows.Media.Stretch]::Uniform
$eff = New-Object System.Windows.Media.Effects.DropShadowEffect
$eff.BlurRadius = 18
$eff.ShadowDepth = 3
$eff.Opacity = 0.45
$eff.Color = [System.Windows.Media.Colors]::Black
$img.Effect = $eff
[System.Windows.Controls.Grid]::SetRow($img, 1)
$null = $grid.Children.Add($img)

# 状态角标: 立绘右上角小徽章(读 /pet/mood 的 label 文本, 每 10s 刷新; 不用 emoji, 避免显示乱码)
$moodBadge = New-Object System.Windows.Controls.Border
$moodBadge.CornerRadius = New-Object System.Windows.CornerRadius(10)
$moodBadge.Background = New-Object System.Windows.Media.SolidColorBrush([System.Windows.Media.Color]::FromArgb(244, 30, 34, 43))
$moodBadge.BorderBrush = New-Object System.Windows.Media.SolidColorBrush([System.Windows.Media.Color]::FromArgb(90, 255, 255, 255))
$moodBadge.BorderThickness = New-Object System.Windows.Thickness(1)
$moodBadge.Padding = New-Object System.Windows.Thickness(8, 3, 8, 3)
$moodBadge.Margin = New-Object System.Windows.Thickness(0, 6, 10, 0)
$moodBadge.HorizontalAlignment = [System.Windows.HorizontalAlignment]::Right
$moodBadge.VerticalAlignment = [System.Windows.VerticalAlignment]::Top
$moodText = New-Object System.Windows.Controls.TextBlock
$moodText.FontSize = 11
$moodText.FontWeight = [System.Windows.FontWeights]::Medium
$moodText.Foreground = [System.Windows.Media.Brushes]::White
$moodText.Text = '未开演'
$moodBadge.Child = $moodText
[System.Windows.Controls.Grid]::SetRow($moodBadge, 1)
$null = $grid.Children.Add($moodBadge)

$inputPanel = New-Object System.Windows.Controls.StackPanel
$inputPanel.Orientation = [System.Windows.Controls.Orientation]::Horizontal
$inputPanel.Visibility = [System.Windows.Visibility]::Collapsed
$inputPanel.Margin = New-Object System.Windows.Thickness(6, 2, 6, 8)
$inputBox = New-Object System.Windows.Controls.TextBox
$inputBox.Width = 200
$inputBox.Height = 24
$inputBox.FontSize = 13
$inputBox.Background = New-Object System.Windows.Media.SolidColorBrush([System.Windows.Media.Color]::FromArgb(235, 255, 255, 255))
$sendBtn = New-Object System.Windows.Controls.Button
$sendBtn.Content = '说'
$sendBtn.Width = 46
$sendBtn.Height = 24
$sendBtn.Margin = New-Object System.Windows.Thickness(4, 0, 0, 0)
$null = $inputPanel.Children.Add($inputBox)
$null = $inputPanel.Children.Add($sendBtn)
[System.Windows.Controls.Grid]::SetRow($inputPanel, 2)
$null = $grid.Children.Add($inputPanel)

$win.Content = $grid

# ---------- animations ----------
$translate = New-Object System.Windows.Media.TranslateTransform
$scale = New-Object System.Windows.Media.ScaleTransform
$rotate = New-Object System.Windows.Media.RotateTransform
$tgroup = New-Object System.Windows.Media.TransformGroup
$null = $tgroup.Children.Add($scale)
$null = $tgroup.Children.Add($rotate)
$null = $tgroup.Children.Add($translate)
$grid.RenderTransform = $tgroup
$grid.RenderTransformOrigin = New-Object System.Windows.Point(0.5, 1.0)

$bobTimer = New-Object System.Windows.Threading.DispatcherTimer
$bobTimer.Interval = [TimeSpan]::FromMilliseconds(50)
$script:bobPhase = 0
$bobTimer.Add_Tick({
  $script:bobPhase += $(if ($script:mode -eq 'pending') { 0.15 } elseif ($script:mode -eq 'working') { 0.08 } else { 0.055 })
  $translate.Y = [Math]::Sin($script:bobPhase) * 7
})

# 触摸动画: 弹跳(bounce) + 生气抖动(shake)
function Play-TouchAnim([string]$kind) {
  $frames = 0
  $animTimer = New-Object System.Windows.Threading.DispatcherTimer
  $animTimer.Interval = [TimeSpan]::FromMilliseconds(40)
  $animTimer.Add_Tick({
    $frames++
    $f = $frames / 12.0
    if ($f -ge 1) { $animTimer.Stop(); $scale.ScaleX = 1; $scale.ScaleY = 1; return }
    $s = 1 + [Math]::Sin($f * [Math]::PI) * 0.18
    $scale.ScaleX = $s
    $scale.ScaleY = $s
  })
  $animTimer.Start()
  if ($kind -eq 'pout') {
    $shake = New-Object System.Windows.Threading.DispatcherTimer
    $shake.Interval = [TimeSpan]::FromMilliseconds(35)
    $script:shakePhase = 0
    $shake.Add_Tick({
      $script:shakePhase++
      if ($script:shakePhase -gt 8) { $shake.Stop(); $translate.X = 0; return }
      $translate.X = [Math]::Sin($script:shakePhase) * 4
    })
    $shake.Start()
  }
}

# ---------- interaction state ----------
$script:reqSeq = 0
$script:dragging = $false
$script:downPos = $null
$script:winPos = $null
$script:moved = $false
$script:lastTouch = 0
$script:pollId = $null
$script:thinking = $false
$script:reqTime = 0
$script:lastUserText = $null
$script:hideTimer = $null

function New-ReqId {
  $script:reqSeq++
  return ('r' + [DateTime]::UtcNow.Ticks.ToString() + '-' + $script:reqSeq)
}

function Show-Bubble([string]$text) {
  $bubbleText.Text = $text
  $bubbleBorder.Visibility = [System.Windows.Visibility]::Visible
  if ($script:hideTimer) { $script:hideTimer.Stop() }
  $script:hideTimer = New-Object System.Windows.Threading.DispatcherTimer
  $script:hideTimer.Interval = [TimeSpan]::FromSeconds(16)
  $script:hideTimer.Add_Tick({
    $bubbleBorder.Visibility = [System.Windows.Visibility]::Collapsed
    $script:hideTimer.Stop()
  })
  $script:hideTimer.Start()
}

function Start-Request([string]$id) {
  $script:pollId = $id
  $script:thinking = $true
  $script:reqTime = [DateTime]::UtcNow.Ticks
}

function Send-Touch([string]$kind) {
  $now = [DateTime]::UtcNow.Ticks
  if (($now - $script:lastTouch) -lt 9000000) { return }
  $script:lastTouch = $now
  $anim = New-Object System.Windows.Media.Animation.DoubleAnimation(1.12, (New-Object System.Windows.Duration([TimeSpan]::FromMilliseconds(140))))
  $anim.AutoReverse = $true
  $scale.BeginAnimation([System.Windows.Media.ScaleTransform]::ScaleXProperty, $anim)
  $scale.BeginAnimation([System.Windows.Media.ScaleTransform]::ScaleYProperty, $anim)
  $rot = New-Object System.Windows.Media.Animation.DoubleAnimation(-3, (New-Object System.Windows.Duration([TimeSpan]::FromMilliseconds(160))))
  $rot.AutoReverse = $true
  $rotate.BeginAnimation([System.Windows.Media.RotateTransform]::AngleProperty, $rot)
  if ($kind -eq 'pout') { Play-TouchAnim 'pout' }
  Show-Bubble '……'
  $id = New-ReqId
  $resp = Post-Json '/touch' @{ kind = $kind; id = $id }
  if ($resp -and $resp.ok) {
    Start-Request $id
  } else {
    Show-Bubble '（连不上桌宠服务，戳不动啦）'
  }
}

function Send-Chat {
  $text = $inputBox.Text.Trim()
  if ($text.Length -eq 0) { return }
  $script:lastUserText = $text
  $inputBox.Text = ''
  $inputPanel.Visibility = [System.Windows.Visibility]::Collapsed
  Show-Bubble ("你：$text`n……")
  $id = New-ReqId
  $resp = Post-Json '/chat' @{ text = $text; id = $id }
  if ($resp -and $resp.ok) {
    Start-Request $id
  } else {
    Show-Bubble '（连不上桌宠服务，发不出去）'
  }
}

# ---------- events (window-level drag in screen coords; click-on-image = touch) ----------
$script:downPos = $null
$script:winPos = $null
$script:downOnImage = $false

$win.Add_MouseLeftButtonDown({
  param($s, $e)
  $script:dragging = $true
  $script:moved = $false
  $script:downPos = $win.PointToScreen($e.GetPosition($win))
  $script:winPos = New-Object System.Windows.Point($win.Left, $win.Top)
  $p = $e.GetPosition($img)
  $script:downOnImage = ($p.X -ge 0 -and $p.Y -ge 0 -and $p.X -le $img.ActualWidth -and $p.Y -le $img.ActualHeight)
  $null = $win.CaptureMouse()
})
$win.Add_MouseMove({
  param($s, $e)
  if ($script:dragging) {
    $scr = $win.PointToScreen($e.GetPosition($win))
    $dx = $scr.X - $script:downPos.X
    $dy = $scr.Y - $script:downPos.Y
    if ([Math]::Abs($dx) -gt 4 -or [Math]::Abs($dy) -gt 4) { $script:moved = $true }
    $win.Left = $script:winPos.X + $dx
    $win.Top = $script:winPos.Y + $dy
  }
})
$win.Add_MouseLeftButtonUp({
  param($s, $e)
  $script:dragging = $false
  $win.ReleaseMouseCapture()
  if (-not $script:moved -and $script:downOnImage -and $e.ClickCount -lt 2) { Send-Touch 'pat' }
})
$img.Add_MouseRightButtonUp({
  param($s, $e)
  $ctxMenu.IsOpen = $true
})
$img.Add_MouseLeftButtonDown({
  param($s, $e)
  if ($e.ClickCount -ge 2) {
    if ($inputPanel.Visibility -eq [System.Windows.Visibility]::Visible) {
      $inputPanel.Visibility = [System.Windows.Visibility]::Collapsed
    } else {
      $inputPanel.Visibility = [System.Windows.Visibility]::Visible
      $null = $inputBox.Focus()
    }
  }
})

$sendBtn.Add_Click({ Send-Chat })
$inputBox.Add_KeyDown({
  param($s, $e)
  if ($e.Key -eq [System.Windows.Input.Key]::Enter) { Send-Chat }
})

# ---------- settings window ----------
function Open-Settings {
  if ($script:cfgWin -and $script:cfgWin.IsVisible) {
    $script:cfgWin.Activate()
    return
  }
  $cw = New-Object System.Windows.Window
  $cw.Title = '桌宠设置'
  $cw.Width = 340
  $cw.Height = 330
  $cw.WindowStyle = [System.Windows.WindowStyle]::ToolWindow
  $cw.ResizeMode = [System.Windows.ResizeMode]::NoResize
  $cw.Topmost = $true
  $cw.WindowStartupLocation = [System.Windows.WindowStartupLocation]::CenterOwner
  $cw.Owner = $win
  $cw.ShowInTaskbar = $false

  $panel = New-Object System.Windows.Controls.StackPanel
  $panel.Margin = New-Object System.Windows.Thickness(14)
  $panel.VerticalAlignment = [System.Windows.VerticalAlignment]::Top

  $chkEnabled = New-Object System.Windows.Controls.CheckBox
  $chkEnabled.Content = '启用桌宠'
  $chkEnabled.IsChecked = [bool]$script:cfg.enabled
  $chkEnabled.FontSize = 13
  $chkEnabled.Margin = New-Object System.Windows.Thickness(0, 0, 0, 10)
  $null = $panel.Children.Add($chkEnabled)

  $lblScale = New-Object System.Windows.Controls.TextBlock
  $lblScale.Text = '大小'
  $lblScale.Margin = New-Object System.Windows.Thickness(0, 4, 0, 2)
  $null = $panel.Children.Add($lblScale)
  $sldScale = New-Object System.Windows.Controls.Slider
  $sldScale.Minimum = 0.3
  $sldScale.Maximum = 0.8
  $sldScale.TickFrequency = 0.05
  $sldScale.IsSnapToTickEnabled = $true
  $sldScale.Value = [double]$script:cfg.scale
  $null = $panel.Children.Add($sldScale)

  $lblOpacity = New-Object System.Windows.Controls.TextBlock
  $lblOpacity.Text = '透明度'
  $lblOpacity.Margin = New-Object System.Windows.Thickness(0, 8, 0, 2)
  $null = $panel.Children.Add($lblOpacity)
  $sldOpacity = New-Object System.Windows.Controls.Slider
  $sldOpacity.Minimum = 0.5
  $sldOpacity.Maximum = 1.0
  $sldOpacity.TickFrequency = 0.05
  $sldOpacity.IsSnapToTickEnabled = $true
  $sldOpacity.Value = [double]$script:cfg.opacity
  $null = $panel.Children.Add($sldOpacity)

  $chkTop = New-Object System.Windows.Controls.CheckBox
  $chkTop.Content = '窗口置顶'
  $chkTop.IsChecked = [bool]$script:cfg.topmost
  $chkTop.Margin = New-Object System.Windows.Thickness(0, 10, 0, 0)
  $null = $panel.Children.Add($chkTop)

  $chkAnim = New-Object System.Windows.Controls.CheckBox
  $chkAnim.Content = '待机动画（呼吸浮动）'
  $chkAnim.IsChecked = [bool]$script:cfg.animate
  $chkAnim.Margin = New-Object System.Windows.Thickness(0, 4, 0, 0)
  $null = $panel.Children.Add($chkAnim)

  $lblPos = New-Object System.Windows.Controls.TextBlock
  $lblPos.Text = '初始位置'
  $lblPos.Margin = New-Object System.Windows.Thickness(0, 10, 0, 2)
  $null = $panel.Children.Add($lblPos)
  $cmbPos = New-Object System.Windows.Controls.ComboBox
  $cmbPos.Width = 160
  $cmbPos.HorizontalAlignment = [System.Windows.HorizontalAlignment]::Left
  $items = @(
    @{ Key = 'bottom-right'; Label = '右下角' },
    @{ Key = 'bottom-left'; Label = '左下角' },
    @{ Key = 'top-right'; Label = '右上角' },
    @{ Key = 'top-left'; Label = '左上角' }
  )
  foreach ($it in $items) {
    $null = $cmbPos.Items.Add($it.Label)
  }
  $sel = -1
  for ($i = 0; $i -lt $items.Count; $i++) { if ($items[$i].Key -eq [string]$script:cfg.position) { $sel = $i } }
  if ($sel -lt 0) { $sel = 0 }
  $cmbPos.SelectedIndex = $sel
  $null = $panel.Children.Add($cmbPos)

  $btnSave = New-Object System.Windows.Controls.Button
  $btnSave.Content = '保存设置'
  $btnSave.Width = 100
  $btnSave.Height = 28
  $btnSave.HorizontalAlignment = [System.Windows.HorizontalAlignment]::Left
  $btnSave.Margin = New-Object System.Windows.Thickness(0, 16, 0, 0)
  $null = $panel.Children.Add($btnSave)

  $cw.Content = $panel

  $btnSave.Add_Click({
    $wasEnabled = [bool]$script:cfg.enabled
    $script:cfg.enabled = [bool]$chkEnabled.IsChecked
    $script:cfg.scale = [double]$sldScale.Value
    $script:cfg.opacity = [double]$sldOpacity.Value
    $script:cfg.topmost = [bool]$chkTop.IsChecked
    $script:cfg.animate = [bool]$chkAnim.IsChecked
    if ($cmbPos.SelectedIndex -ge 0 -and $cmbPos.SelectedIndex -lt $items.Count) {
      $script:cfg.position = $items[$cmbPos.SelectedIndex].Key
    }
    Save-Config
    Apply-Scale
    Apply-Opacity
    Apply-Topmost
    Apply-Animate
    $cw.Close()
    if (-not [bool]$script:cfg.enabled -and $wasEnabled) {
      $win.Close()
    }
  })

  $script:cfgWin = $cw
  $cw.Add_Closed({ $script:cfgWin = $null })
  $cw.ShowDialog() | Out-Null
}

# ---------- context menu ----------
$ctxMenu = New-Object System.Windows.Controls.ContextMenu
function Add-Menu([string]$header, [scriptblock]$action) {
  $mi = New-Object System.Windows.Controls.MenuItem
  $mi.Header = $header
  $mi.Add_Click($action)
  $null = $ctxMenu.Items.Add($mi)
}
Add-Menu '聊天' { $inputPanel.Visibility = [System.Windows.Visibility]::Visible; $null = $inputBox.Focus() }
Add-Menu '投喂' { try { $null = Post-Json '/feed' (@{} | ConvertTo-Json); Show-Bubble '（你喂她吃了点东西……）' } catch { Show-Bubble '（投喂失败，再试一次？）' } }
Add-Menu '摸头' { Send-Touch 'pat' }
Add-Menu '挠痒痒' { Send-Touch 'tickle' }
Add-Menu '戳一戳' { Send-Touch 'poke' }
Add-Menu '梳头发' { Send-Touch 'brush' }
Add-Menu '握握手' { Send-Touch 'handshake' }
Add-Menu '亲一下' { Send-Touch 'kiss' }
Add-Menu '逗生气' { Send-Touch 'pout' }
Add-Menu '设置' { Open-Settings }
Add-Menu '退出（并停用桌宠）' {
  $script:cfg.enabled = $false
  Save-Config
  $win.Close()
}
# 动态状态项(借鉴 xiuxian 场景化菜单): 只读展示, 随 /pet/state 更新
$menuState = New-Object System.Windows.Controls.MenuItem
$menuState.Header = '状态: —'
$menuState.IsEnabled = $false
$null = $ctxMenu.Items.Insert(0, $menuState)
$ctxMenu.Add_Opened({ $script:menuOpen = $true; Set-PetTransparent $false })
$ctxMenu.Add_Closed({ $script:menuOpen = $false })
$img.ContextMenu = $ctxMenu

# ---------- reply poll (HTTP) ----------
$pollTimer = New-Object System.Windows.Threading.DispatcherTimer
$pollTimer.Interval = [TimeSpan]::FromMilliseconds(600)
$pollTimer.Add_Tick({
  if (-not $script:thinking -or -not $script:pollId) { return }
  $resp = Get-Json ('/poll?id=' + [uri]::EscapeDataString([string]$script:pollId))
  if ($resp -and $resp.status -eq 'done') {
    $script:thinking = $false
    $script:pollId = $null
    if ($script:lastUserText) {
      Show-Bubble ("你：$($script:lastUserText)`n$($resp.text)")
      $script:lastUserText = $null
    } else {
      Show-Bubble ([string]$resp.text)
    }
  } elseif ($resp -and $resp.status -eq 'none') {
    # request was lost (plugin restarted / pending cleared): give up after a short grace
    $elapsed = ([DateTime]::UtcNow.Ticks - $script:reqTime) / 10000000
    if ($elapsed -gt 20) {
      $script:thinking = $false
      $script:pollId = $null
      Show-Bubble '（请求丢失，再试一次？）'
    }
  } else {
    $elapsed = ([DateTime]::UtcNow.Ticks - $script:reqTime) / 10000000
    if ($elapsed -gt 300) {
      $script:thinking = $false
      $script:pollId = $null
      Show-Bubble '（她好像睡着了……）'
    }
  }
})
$pollTimer.Start()

# ---------- bubble murmur poll（角色没来得及说出口的念头） ----------
$bubblePollTimer = New-Object System.Windows.Threading.DispatcherTimer
$bubblePollTimer.Interval = [TimeSpan]::FromSeconds(20)
$bubblePollTimer.Add_Tick({
  if ($script:thinking) { return }
  try {
    $resp = Get-Json '/bubble'
    if ($resp -and $resp.text) { Show-Bubble ([string]$resp.text) }
  } catch { }
})
$bubblePollTimer.Start()

# ---------- mood badge poll（状态角标: 读 /pet/mood 的 label 文字, 不显示 emoji 防乱码） ----------
$moodTimer = New-Object System.Windows.Threading.DispatcherTimer
$moodTimer.Interval = [TimeSpan]::FromSeconds(10)
$moodTimer.Add_Tick({
  try {
    $resp = Get-Json '/mood'
    if ($resp -and $resp.ok -and $resp.mood) {
      $m = $resp.mood
      $label = [string]$m.label
      if (-not $label) { $label = [string]$m.emoji }
      if ($moodText.Text -ne $label) { $moodText.Text = $label }
      $el = New-Object System.Windows.Controls.ToolTip
      $el.Content = [string]$m.label
      $moodBadge.ToolTip = $el
      $hexTxt = '#C8CCD4'
      switch ([string]$m.tone) {
        'red' { $hexTxt = '#E88A8A' } 'orange' { $hexTxt = '#E8B088' } 'yellow' { $hexTxt = '#E4D07C' }
        'pink' { $hexTxt = '#EFA4BC' } 'green' { $hexTxt = '#93D4A0' }
      }
      $moodText.Foreground = [System.Windows.Media.Brushes]::White
      $c = [System.Windows.Media.ColorConverter]::ConvertFromString($hexTxt)
      $moodText.Foreground = New-Object System.Windows.Media.SolidColorBrush($c)
    }
  } catch { }
})
$moodTimer.Start()

# ---------- 状态机轮询(借鉴 dsh-whale-musume/dsh-pet): /pet/state → 姿势 + 呼吸 + 菜单状态 + 低打扰提示 ----------
$stateTimer = New-Object System.Windows.Threading.DispatcherTimer
$stateTimer.Interval = [TimeSpan]::FromMilliseconds(1500)
$stateTimer.Add_Tick({
  try {
    $st = Get-Json '/state'
    if ($st -and $st.ok -and $st.state) {
      $m = [string]$st.state.mode
      $label = [string]$st.state.label
      if (-not $label) { $label = '空闲' }
      $script:mode = $m
      if ($m -ne $script:lastMode) {
        $wasMode = $script:lastMode
        $script:lastMode = $m
        Set-Pose $m
        $menuState.Header = '状态: ' + $label
        if ($m -eq 'pending' -and $wasMode -ne 'pending') { Show-Bubble '（有任务等你确认呢……）' }
        elseif ($m -eq 'working' -and $wasMode -eq 'idle') { Show-Bubble '（她在认真工作了……）' }
        elseif ($m -eq 'idle' -and $wasMode -eq 'working') { Show-Bubble '（忙完啦～）' }
      } else {
        $menuState.Header = '状态: ' + $label
      }
      # mood 角标: 工作/待确认优先展示, idle 时交回 mood 轮询显示心情
      if ($m -eq 'pending') { $moodText.Text = '待确认'; $moodText.Foreground = [System.Windows.Media.Brushes]::White }
      elseif ($m -eq 'working') { $moodText.Text = '工作中'; $moodText.Foreground = [System.Windows.Media.Brushes]::White }
    }
  } catch { }
})
$stateTimer.Start()

# ---------- 精确点击穿透(借鉴 dsh-pet): 30ms 轮询鼠标位置, 透明区置 WS_EX_TRANSPARENT ----------
$hitTimer = New-Object System.Windows.Threading.DispatcherTimer
$hitTimer.Interval = [TimeSpan]::FromMilliseconds(30)
$script:prevHit = $true
$hitTimer.Add_Tick({
  if ($script:menuOpen) { return }
  try {
    $sp = [System.Windows.Forms.Cursor]::Position
    $local = $win.PointFromScreen((New-Object System.Windows.Point($sp.X, $sp.Y)))
    $x = $local.X; $y = $local.Y
    $hit = $true
    if (-not $script:alphaGrid -or $script:alphaRows -le 0) {
      $hit = $true
    } elseif ($y -lt $script:stripH) {
      $hit = $true   # 顶部气泡/输入区始终可交互
    } else {
      $iy = $y - $script:stripH
      $imgH = $img.ActualHeight; $imgW = $img.ActualWidth
      if ($imgH -le 0 -or $imgW -le 0) { $hit = $true }
      else {
        $c = [Math]::Floor($x / $imgW * $script:alphaCols)
        $r = [Math]::Floor($iy / $imgH * $script:alphaRows)
        if ($c -lt 0 -or $c -ge $script:alphaCols -or $r -lt 0 -or $r -ge $script:alphaRows) { $hit = $true }
        else { $hit = ($script:alphaGrid[$r * $script:alphaCols + $c] -eq 1) }
      }
    }
    if ($hit -ne $script:prevHit) {
      $script:prevHit = $hit
      Set-PetTransparent (-not $hit)
    }
  } catch { }
})
$hitTimer.Start()

$win.Add_Closed({
  $bobTimer.Stop()
  $pollTimer.Stop()
  $bubblePollTimer.Stop()
  $moodTimer.Stop()
  $stateTimer.Stop()
  $hitTimer.Stop()
})

Apply-Scale
Apply-Animate
$win.ShowDialog() | Out-Null
