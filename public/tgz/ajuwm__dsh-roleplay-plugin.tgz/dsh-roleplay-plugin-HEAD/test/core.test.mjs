// roleplay 引擎核心路径自动化测试（免框架，node 直接跑）
// 用法: node test/core.test.mjs
// 覆盖: 卡库旧/新格式兼容 · 角色切换不丢卡 · progress 隔离(亲密度) · 朋友向轴 · OC 空白 ·
//       养成/商城开关门卫 · start 恢复 · 记忆隔离
import { mkdtempSync, rmSync, writeFileSync, mkdirSync, readFileSync, readdirSync, existsSync } from 'node:fs';
import { join } from 'node:path';
import { tmpdir } from 'node:os';
import { pathToFileURL, fileURLToPath } from 'node:url';
import { spawnSync } from 'node:child_process';

// 测试隔离：稳定版开关在 0.2.0 下落盘到 %DSH_HOME%/.roleplay-switches.json ——
// 单测绝不允许读到或写到用户真实 home（踩过一次：T50 的读路径把迁移结果写进了真实 %DSH_HOME%）。
// 在任何模块加载前把它指到临时目录。
process.env.DSH_ROLEPLAY_SWITCHES = join(mkdtempSync(join(tmpdir(), 'rp-switch-iso-')), 'switches.json');
// ⚠️ DSH_HOME 也必须隔离:switch-store 的一次性迁移会去读 %DSH_HOME%/settings.yaml(.imported),
// 那是**用户真实**的 0.1.1 设置文档 —— 不隔离的话它会把用户偏好(storyEnabled:false 等)搬进测试,
// 表现为「测试受本机配置影响」的假失败(2026-10-07 踩到:T22 因为用户关了剧情档案而挂)。
process.env.DSH_HOME = mkdtempSync(join(tmpdir(), 'rp-home-iso-'));

const ENGINE_URL = new URL('../agent-presets/roleplay/roleplay-host.mjs', import.meta.url).href;

let PASS = 0, FAIL = 0;
const failures = [];
// CI 可读性：失败时额外输出 GitHub 注记(::error::)，这样不用登录也能在
// check-run 的 annotations 里看到**具体是哪些断言挂了**——否则远程排查只能看到 "exit code 1"。
const ANNOTATE = !!(process.env.GITHUB_ACTIONS || process.env.RP_TEST_ANNOTATE);
function annotate(msg) { if (ANNOTATE) console.log('::error::' + String(msg).replace(/\r?\n/g, ' ')) }
function ok(cond, name) {
  if (cond) { PASS++; console.log('  ✅ ' + name); }
  else { FAIL++; failures.push(name); console.log('  ❌ ' + name); annotate(name); }
}
// 崩溃也要能被 CI 看见具体原因（否则同样只有 exit code 1）
process.on('uncaughtException', (e) => { annotate('uncaughtException: ' + (e && e.stack ? e.stack.split('\n').slice(0, 3).join(' | ') : e)); console.error(e); process.exit(1) });
process.on('unhandledRejection', (e) => { annotate('unhandledRejection: ' + (e && e.stack ? e.stack.split('\n').slice(0, 3).join(' | ') : e)); console.error(e); process.exit(1) });

// ─── T0 语法门: 仓库内全部 JS/MJS 静态检查(与 CI 同源; 防止"本地测试全绿但语法已坏"再发生) ───
console.log('\nT0 语法门 (全部 JS/MJS)');
{
  const SYNTAX_FILES = [
    'agent-presets/roleplay/roleplay-host.mjs',
    'agent-presets/roleplay/lib/relation-core.mjs',
    'agent-presets/roleplay/lib/time-core.mjs',
    'agent-presets/roleplay/lib/chat-core.mjs',
    'agent-presets/roleplay/lib/notes-core.mjs',
    'agent-presets/roleplay/lib/game-core.mjs',
    'agent-presets/roleplay/lib/heartbeat-core.mjs',
    'agent-presets/roleplay/lib/rel-tier-core.mjs',
    'agent-presets/roleplay/lib/backup-core.mjs',
    'agent-presets/roleplay/lib/switch-store.mjs',
    'agent-presets/roleplay/lib/state-slot.mjs',
    'agent-presets/roleplay/lib/compaction-anchor.mjs',
    'agent-presets/roleplay/lib/history-core.mjs',
    'agent-presets/roleplay/deskpet.mjs',
    'lib/index.js',
    'lib/client.js',
    'lib/settings.js',
    'lib/preset-registration.mjs',
    'lib/compaction.mjs',
  ];
  const root = fileURLToPath(new URL('..', import.meta.url));
  let bad = 0;
  for (const f of SYNTAX_FILES) {
    const r = spawnSync(process.execPath, ['--check', join(root, f)], { encoding: 'utf8' });
    if (r.status !== 0) {
      bad++;
      failures.push('语法: ' + f);
      console.log('  ❌ ' + f);
      console.log(String(r.stderr || r.stdout || '').slice(0, 500));
    }
  }
  ok(bad === 0, bad === 0 ? '全部 ' + SYNTAX_FILES.length + ' 个文件语法通过' : bad + ' 个文件语法错误');
}

// T0b PowerShell 脚本语法门(UTF-8 BOM 法: 无 BOM 会被 ANSI 解码误判, 先补 BOM 再解析)
console.log('\nT0b PS 语法门 (pet/*.ps1)');
{
  const root2 = fileURLToPath(new URL('..', import.meta.url));
  const psFiles = ['pet/pet-window.ps1', 'pet/note-window.ps1'];
  let psBad = 0;
  let psChecked = 0;
  for (const f of psFiles) {
    const target = join(root2, f);
    try {
      // 要求: 脚本必须自带 UTF-8 BOM(无 BOM 会被 Windows PowerShell 5.1 按 ANSI 解码 → 中文乱码/语法错)
      const headBytes = readFileSync(target);
      if (!(headBytes.length >= 3 && headBytes[0] === 0xEF && headBytes[1] === 0xBB && headBytes[2] === 0xBF)) {
        psBad++;
        psChecked++;
        failures.push('PS-BOM: ' + f + ' (丢失 BOM, 必须补回)');
        console.log('  ❌ ' + f + ' 丢失 UTF-8 BOM');
        continue;
      }
      const script = "$b=[System.IO.File]::ReadAllBytes('" + target.replace(/'/g, "''") + "');$hasBom=($b.Length -ge 3 -and $b[0] -eq 0xEF -and $b[1] -eq 0xBB -and $b[2] -eq 0xBF);if(-not $hasBom){$bom=New-Object byte[] 3;$bom[0]=0xEF;$bom[1]=0xBB;$bom[2]=0xBF;$all=New-Object byte[] ($b.Length+3);[Array]::Copy($bom,0,$all,0,3);[Array]::Copy($b,0,$all,3,$b.Length)}else{$all=$b};$tmp=Join-Path $env:TEMP ('rp-syn-'+[guid]::NewGuid().ToString('N')+'.ps1');[IO.File]::WriteAllBytes($tmp,$all);$t=$null;$e=$null;[System.Management.Automation.Language.Parser]::ParseFile($tmp,[ref]$t,[ref]$e)|Out-Null;Remove-Item $tmp -Force;if($e.Count){Write-Output ('ERR:'+$e[0].Extent.StartLineNumber+':'+$e[0].Message);exit 1}else{exit 0}";
      const r = spawnSync('powershell.exe', ['-NoProfile', '-Command', script], { encoding: 'utf8' });
      if (r.error && r.error.code === 'ENOENT') {
        // CI 为 ubuntu 等无 powershell 平台: 跳过(不判失败; 本地 Windows 与 CI windows job 强制执行)
        console.log('  ⚠ ' + f + ' 跳过(此平台无 powershell.exe)');
        continue;
      }
      if (r.status !== 0) {
        psBad++;
        psChecked++;
        failures.push('PS语法: ' + f);
        console.log('  ❌ ' + f + ' → ' + String(r.stdout || r.stderr || '').slice(0, 300));
      } else {
        psChecked++;
        console.log('  ✅ ' + f);
      }
    } catch (e) {
      console.log('  ⚠ ' + f + ' 跳过(无法运行 pwsh): ' + String(e && e.message ? e.message : e));
    }
  }
  ok(psBad === 0, psBad === 0 ? 'PS 脚本全部通过(' + psChecked + '/' + psFiles.length + ')' : psBad + ' 个 PS 脚本语法错误');
}
// 一次全新引擎实例 + 独立临时数据根（reuseRoot 传入时复用同一数据根，用于跨实例断言）
// opts.agents 覆盖 agents 服务(测心跳自认领时用)；opts.services 供 ctx.get(如 agentPresets)
async function boot(style = 'love', seedChar = null, dataRoot = '.roleplay', reuseRoot = null, opts = null) {
  const root = reuseRoot || mkdtempSync(join(tmpdir(), 'rp-test-'));
  if (!reuseRoot) mkdirSync(join(root, dataRoot), { recursive: true });
  if (seedChar) writeFileSync(join(root, dataRoot, 'character.json'), JSON.stringify(seedChar));
  const captured = { tools: {}, svc: null, sections: [], events: {}, sent: [], intervals: [] };
  const fake = { id: 't-session', session: { events: [], seq: 0 } };
  fake.send = function (message) {
    captured.sent.push(message);
    const ev = {
      seq: ++fake.session.seq,
      type: message && message.role === 'user' ? 'user/message' : 'assistant/message',
      data: { message },
    };
    fake.session.events.push(ev);
    return { id: message && message.id };
  };
  const fsx = {
    async resolve(rel, opts) { const base = (opts && opts.cwd) || root; return join(base, rel); },
    async readText(p) { return readFileSync(p, 'utf8'); },
    async readBytes(p) { return readFileSync(p); },
    async writeText(p, c) { mkdirSync(join(p, '..'), { recursive: true }); writeFileSync(p, c); },
    async stat(p) { try { const s = readdirSync(p); return { size: 0 }; } catch { try { return { size: readFileSync(p).length }; } catch { return undefined; } } },
    async listDir(p) {
      // ⚠️ 与真实 dsh-fs 契约对齐: listDir 返回 FsDirEntry[]{ name, type, target } —— 不是字符串数组。
      // 老桩返回字符串, 于是"引擎把条目当文件名用"这类 bug(备份 L2/L3 整块静默失效)在单测里永远抓不到。
      try {
        return readdirSync(p, { withFileTypes: true }).map((d) => ({
          name: d.name,
          type: d.isDirectory() ? 'directory' : (d.isSymbolicLink() ? 'symlink' : 'file'),
          target: join(p, d.name),
        }));
      } catch { return []; }
    },
    async exists(p) { return existsSync(p); },
  };
  const ctx = {
    get: (n) => ((opts && opts.services) ? opts.services[n] : undefined),
    on: (ev, h) => { (captured.events[ev] ||= []).push(h); },
    setTimeout: () => 0,
    interval: (cb, ms) => { captured.intervals.push({ cb, ms }); return 0; },
    provide: (n, s) => { if (n === 'roleplay') captured.svc = s; },
    tools: { register: (e) => { captured.tools[e.name] = e; } },
    systemPrompt: { section: (s) => { captured.sections.push(s); } },
    // 真实运行里 preset 由 isolate realm 挂载且定时器回调没有发起者边界：
    // opts.agents 用来复现「currentInitiator()=undefined + 注册表里多个会话」这种现场。
    agents: Object.assign({ currentInitiator: () => fake, get: () => fake, roots: () => [fake] }, (opts && opts.agents) || {}),
    fs: fsx,
    subprocess: {},
    sandboxPolicy: { workspaceRoot: root },
    attachments: {},
    timer: { interval: () => 0, setTimeout: () => 0 },
  };
  const mod = await import(ENGINE_URL + '?t=' + root + '-' + Math.random().toString(36).slice(2, 6));
  mod.apply(ctx, { style, dataRoot });
  const tool = (name) => captured.tools[name];
  const call = async (name, args) => tool(name).execute(args || {});
  const svc = captured.svc;
  const gs = (args) => svc.getState({ sessionId: 't-session', ...(args || {}) });
  const promptText = async () => {
    await new Promise((r) => setTimeout(r, 400));
    const sec = captured.sections.find((s) => s.name === 'roleplay.character');
    return sec ? sec.text() : '';
  };
  return { root, dataRoot, tool, call, svc, gs, captured, promptText };
}

// ─── T1 卡库旧格式(单对象)兼容 ───────────────────────────────
console.log('\nT1 卡库旧格式兼容');
{
  const b = await boot();
  writeFileSync(join(b.root, b.dataRoot, 'cards.json'), JSON.stringify({ id: 'card-guiz', name: '癸', persona: '旧卡' }));
  const r = await b.svc.listCards({ sessionId: 't-session' });
  ok(r.ok && r.cards.some((c) => c.name === '癸'), '旧格式单对象被识别为一张卡(癸)');
  rmSync(b.root, { recursive: true, force: true });
}

// ─── T2 角色切换不丢卡(自动入库 + 切回) ───────────────────────
console.log('\nT2 切换不丢卡');
{
  const b = await boot();
  await b.call('roleplay_start', { name: '甲', persona: 'p甲', greeting: '嗨' });
  await b.call('roleplay_start', { name: '乙', persona: 'p乙' });
  const cards = JSON.parse(readFileSync(join(b.root, b.dataRoot, 'cards.json'), 'utf8'));
  ok(cards.some((c) => c.name === '甲' && c.persona === 'p甲'), '切换时自动保存了「甲」为卡(完整人设)');
  const r = await b.svc.loadCard({ sessionId: 't-session', card: '甲' });
  ok(r.ok && r.name === '甲', 'loadCard 可切回「甲」');
  const st = await b.gs();
  ok(st.character && st.character.name === '甲', '当前角色=甲');
  rmSync(b.root, { recursive: true, force: true });
}

// ─── T3 progress 亲密度隔离 ─────────────────────────────────
console.log('\nT3 亲密度按角色隔离');
{
  const b = await boot();
  await b.call('roleplay_start', { name: '甲', persona: 'p甲' });
  await b.call('roleplay_relation', { favor: 8 });
  let st = await b.gs();
  ok(st.relation && st.relation.favor === 38, '甲 favor 30→38(+8, 单轮限幅)');
  await b.call('roleplay_start', { name: '乙', persona: 'p乙' });
  st = await b.gs();
  ok(st.relation && st.relation.favor === 30, '乙 全新(30), 不继承甲');
  await b.svc.loadCard({ sessionId: 't-session', card: '甲' });
  st = await b.gs();
  ok(st.relation && st.relation.favor === 38, '切回甲 favor 仍是 38');
  rmSync(b.root, { recursive: true, force: true });
}

// ─── T4 朋友向: 无心动/男友力 ───────────────────────────────
console.log('\nT6 养成/商城关闭门卫');
{
  const b = await boot('love', { enabled: false, character: null, settings: { statsEnabled: false, relationEnabled: false } });
  const st = await b.gs();
  ok(st.shop === null && st.stats === null && st.economy === null, 'getState 不返回 shop/stats/economy');
  const r = await b.call('roleplay_shop', { action: 'list' });
  ok(r && r.ok === false, 'roleplay_shop 被拦截');
  await b.call('roleplay_start', { name: '甲', persona: 'p甲' });
  const f = await b.call('roleplay_feed', { item: 'mantou' });
  ok(f && f.ok === false, '投喂被拦截(stats 关闭)');
  rmSync(b.root, { recursive: true, force: true });
}

// ─── T7 start 恢复上次角色 ─────────────────────────────────
console.log('\nT7 「开始扮演」未指定→恢复');
{
  const b = await boot();
  await b.call('roleplay_start', { name: '甲', persona: 'p甲' });
  await b.call('roleplay_stop', {});
  const r = await b.call('roleplay_start', {});
  ok(r && r.ok === true && b.captured.svc, '无参 start 成功');
  const st = await b.gs();
  ok(st.character && st.character.name === '甲', '恢复的是「甲」而不是新人设');
  ok(st.enabled === true, '开演状态已激活');
  rmSync(b.root, { recursive: true, force: true });
}

// ─── T8 记忆按角色隔离 ────────────────────────────────────
console.log('\nT8 记忆隔离');
{
  const b = await boot();
  await b.call('roleplay_start', { name: '甲', persona: 'p甲' });
  await b.call('roleplay_remember', { event: '一起去水族馆', kind: '一起活动' });
  await b.call('roleplay_start', { name: '乙', persona: 'p乙' });
  let st = await b.gs();
  ok(st.memoryView && st.memoryView.short.length === 0, '乙没有甲的记忆');
  await b.svc.loadCard({ sessionId: 't-session', card: '甲' });
  st = await b.gs();
  ok(st.memoryView && st.memoryView.short.some((x) => String(x).includes('水族馆')), '甲记得水族馆');
  rmSync(b.root, { recursive: true, force: true });
}

// ─── T9 纪念日提示注入 ─────────────────────────────────────
console.log('\nT9 纪念日注入(对话提示)');
{
  const b = await boot();
  await b.call('roleplay_start', { name: '甲', persona: 'p甲' });
  const pad2 = (n) => String(n).padStart(2, '0');
  const d = new Date();
  const today = d.getFullYear() + '-' + pad2(d.getMonth() + 1) + '-' + pad2(d.getDate());
  const r = await b.call('roleplay_anniversary', { name: '第一次见面', date: today });
  ok(r.ok && Array.isArray(r.anniversaries) && r.anniversaries.some((a) => a.name === '第一次见面'), '纪念日已记录(今日)');
  const text = await b.promptText();
  ok(String(text).includes('第一次见面'), '提示词注入纪念日');
  ok(String(text).includes('今天是特别的日子'), '「特别的日子」提示出现');
  rmSync(b.root, { recursive: true, force: true });
}

// ─── T10 时段语气注入 ─────────────────────────────────────
console.log('\nT10 时段语气注入');
{
  const b = await boot();
  await b.call('roleplay_start', { name: '甲', persona: 'p甲' });
  const text = String(await b.promptText());
  const h = new Date().getHours();
  const label = h >= 6 && h < 9 ? '清晨' : h >= 9 && h < 12 ? '上午' : h >= 12 && h < 14 ? '中午' : h >= 14 && h < 18 ? '下午' : h >= 18 && h < 20 ? '傍晚' : h >= 20 && h < 23 ? '晚上' : '深夜';
  ok(text.includes('当前时段：' + label), '提示词按当前时段注入(' + label + ')');
  ok(text.includes('扮演规则'), '扮演规则随提示注入');
  rmSync(b.root, { recursive: true, force: true });
}

// ─── T11 商城购买流程 ─────────────────────────────────────
console.log('\nT11 商城购买');
{
  const b = await boot();
  await b.call('roleplay_start', { name: '甲', persona: 'p甲' });
  const r1 = await b.call('roleplay_shop', { action: 'buy', item: 'mantou' });
  ok(r1.ok && r1.coins === 90, '买馒头: 100-10=90 金币');
  let st = await b.gs();
  ok(st.inventory && st.inventory.some((x) => x.id === 'mantou' && x.qty === 1), '背包出现馒头 x1');
  const r2 = await b.call('roleplay_shop', { action: 'buy', item: 'pendant' });
  ok(r2.ok && r2.coins === 10, '买挂坠: 90-80=10 金币');
  const r3 = await b.call('roleplay_shop', { action: 'buy', item: 'cake' });
  ok(r3.ok === false && String(r3.message).includes('金币不足'), '金币不足拦截(10<60)');
  st = await b.gs();
  ok(st.economy && st.economy.coins === 10, '最终金币 10');
  rmSync(b.root, { recursive: true, force: true });
}

// ─── T12 里程碑: 触发/门槛/防重复 ─────────────────────────
console.log('\nT12 里程碑');
{
  const b1 = await boot();
  await b1.call('roleplay_start', { name: '甲', persona: 'p甲' });
  const r1 = await b1.call('roleplay_relation', { milestone: 'm7' }); // 需要 trustTier3(当前 tier1)
  ok(r1 && r1.milestone === null && String(r1.message).includes('差一点'), '未满足门槛(信任不够)不触发');
  rmSync(b1.root, { recursive: true, force: true });

  const b2 = await boot();
  await b2.call('roleplay_start', { name: '甲', persona: 'p甲' });
  const r2 = await b2.call('roleplay_relation', { milestone: 'm1' }); // 要求 favorTier1, 当前30 → 触发
  ok(r2 && r2.milestone === '第一次成功搭话', 'm1 触发(第一次成功搭话)');
  let pf = JSON.parse(readFileSync(join(b2.root, b2.dataRoot, 'progress-甲.json'), 'utf8'));
  ok(pf.milestones.length === 1 && pf.milestones[0] === 'm1', '进度记录 m1 一次');
  ok(pf.relation.favor === 36, 'm1 奖励 favor +6(30→36)');

  // 跨实例(同一数据根): 再触发 m1 → 已触发过, 不重复
  const b3 = await boot('love', null, '.roleplay', b2.root);
  await b3.call('roleplay_start', { name: '甲', persona: 'p甲' });
  const r3 = await b3.call('roleplay_relation', { milestone: 'm1' });
  ok(r3 && r3.milestone === null && String(r3.message).includes('已触发过'), 'm1 防重复(已触发过)');
  pf = JSON.parse(readFileSync(join(b3.root, b3.dataRoot, 'progress-甲.json'), 'utf8'));
  ok(pf.milestones.length === 1, '里程碑仍只有 1 条');
  rmSync(b2.root, { recursive: true, force: true });
}

// ─── T13 关系核心纯函数直测 (lib/relation-core.mjs) ──────────
console.log('\nT13 关系核心纯函数');
{
  const rc = await import(new URL('../agent-presets/roleplay/lib/relation-core.mjs', import.meta.url).href);
  const R = { favor: 30, trust: 20, heart: 10 };
  const B = { reliability: 50, empathy: 50, stability: 50, ambition: 50 };
  const M = [
    { id: 'm1', name: '第一次成功搭话', req: { favorTier: 1 }, reward: { favor: 6 } },
    { id: 'm7', name: '约定的日子一起去…', req: { trustTier: 3, heartTier: 2 }, reward: { trust: 5, heart: 8 } },
  ];
  const opts = { milestonesDef: M, tierLabels: { favor: ['疏离', '亲近', '倾慕'], trust: ['戒备', '放心', '依赖'], heart: ['无感', '在意', '心动'] }, bfLabels: { reliability: '靠谱' }, keyLabels: { favor: '好感', trust: '信任', heart: '心动' } };

  let r = rc.applyDelta(R, B, [], { heart: 5 }, opts);
  ok(r.relation.heart === 10, '心动锁: favor/trust 未到二档, heart 不增');
  ok(r.changed.length === 0, '无变化不进 changed');

  r = rc.applyDelta(R, B, [], { favor: 10 }, opts);
  ok(r.relation.favor === 40 && r.changed.some((c) => String(c).includes('好感 +10')), '好感 +10 (bf 因子=1.0) → 40');

  r = rc.applyDelta(R, B, [], { trust: -10 }, opts);
  ok(Math.abs(r.relation.trust - 10) < 1e-9, '负向缩放 (1.6-0.6) → 信任 20-10=10');

  r = rc.applyDelta(R, B, [], { favor: 5, heart: 5, boyfriend: { reliability: 10 } }, { ...opts, isFriend: true });
  ok(r.relation.favor === 35 && r.relation.heart === 10, 'friend 不增 heart');
  ok(r.boyfriend.reliability === 50, 'friend 不动男友力');

  r = rc.applyDelta(R, B, [], { boyfriend: { reliability: 10 } }, opts);
  ok(r.boyfriend.reliability === 60, '男友力 50→60');
  ok(Math.abs(rc.boyfriendFactorOf(r.boyfriend) - 1.02) < 1e-9, 'bf 因子随男友力升到 1.02(均值52.5)');

  r = rc.applyDelta(R, B, [], { milestone: 'm7' }, opts);
  ok(r.milestoneMsg && r.milestoneMsg.ok === false && String(r.milestoneMsg.message).includes('差一点'), '里程碑门槛不足不触发');

  r = rc.applyDelta(R, B, [], { milestone: 'm1' }, opts);
  ok(r.milestoneMsg && r.milestoneMsg.ok === true && r.milestones.length === 1 && r.relation.favor === 36, 'm1 触发 + 奖励 favor+6 → 36');

  r = rc.applyDelta(R, B, r.milestones, { milestone: 'm1' }, opts);
  ok(r.milestoneMsg && r.milestoneMsg.ok === false && String(r.milestoneMsg.message).includes('已触发过'), 'm1 防重复(纯函数)');
}

// ─── T14 时段/想念/阶段纯函数 + 看桌面门卫 + 纪念日非今日 ──────
console.log('\nT14 时段/想念/阶段边界');
{
  const tc = await import(new URL('../agent-presets/roleplay/lib/time-core.mjs', import.meta.url).href);
  const rc = await import(new URL('../agent-presets/roleplay/lib/relation-core.mjs', import.meta.url).href);
  const hours = [[23, '深夜'], [0, '深夜'], [5, '深夜'], [6, '清晨'], [8, '清晨'], [9, '上午'], [11, '上午'], [12, '中午'], [13, '中午'], [14, '下午'], [17, '下午'], [18, '傍晚'], [19, '傍晚'], [20, '晚上'], [22, '晚上']];
  let allOk = true;
  for (const [h, want] of hours) if (tc.periodOf(h).label !== want) { allOk = false; console.log('    边界失败 h=' + h + ' got=' + tc.periodOf(h).label); }
  ok(allOk, '时段 15 个边界点全对');
  ok(tc.missClassify(1) === null, '1小时不提示想念');
  ok(String(tc.missClassify(2)).includes('2 小时'), '2小时 → 轻声惦记');
  ok(String(tc.missClassify(47)).includes('1 天多'), '47小时 → 1天多');
  ok(String(tc.missClassify(120)).includes('5 天'), '120小时 → 5天');
  ok(rc.relationStageOf({ favor: 30, trust: 20, heart: 10 }, 0) === 'stranger', '阶段: 默认陌生人');
  ok(rc.relationStageOf({ favor: 45, trust: 20, heart: 10 }, 1) === 'acquaintance', '阶段: acquaintance');
  ok(rc.relationStageOf({ favor: 50, trust: 50, heart: 10 }, 3) === 'friend', '阶段: friend');
  ok(rc.relationStageOf({ favor: 70, trust: 70, heart: 40 }, 5) === 'close_friend', '阶段: close_friend');
  ok(rc.relationStageOf({ favor: 80, trust: 80, heart: 80 }, 7) === 'special', '阶段: special');
  const ORDER = ['stranger', 'acquaintance', 'friend', 'close_friend', 'special'];
  const REQS = { acquaintance: ['初次对话', '日常交流'], friend: ['一起活动', '分享日常', '互相帮助', '被夸奖', '一起回家'], close_friend: ['分享秘密'], special: ['约会'] };
  ok(rc.computeStageOf({ 初次对话: 1, 日常交流: 1 }, ORDER, REQS) === 'acquaintance', '事件阶段: 切聊→普通认识');
  ok(rc.computeStageOf({ 初次对话: 1 }, ORDER, REQS) === 'stranger', '事件阶段: 只有初次→陌生人');
  ok(rc.computeStageOf({ 初次对话: 1, 日常交流: 1, 一起活动: 1 }, ORDER, REQS) === 'acquaintance', '事件阶段: 朋友要求 5 项过 3, 仅 1 项不到 ');
}

console.log('\nT15 看桌面门卫 + 纪念日非今日');
{
  const b = await boot('love', { enabled: false, character: null, settings: { autoLook: false } });
  await b.call('roleplay_start', { name: '甲', persona: 'p甲' });
  const look = await b.call('roleplay_look_desktop', {});
  ok(look && look.ok === false && String(look.message).includes('没有去看的打算'), 'autoLook=关 → 主动看桌面被拒');
  const pad2 = (n) => String(n).padStart(2, '0');
  const d = new Date();
  const today = d.getFullYear() + '-' + pad2(d.getMonth() + 1) + '-' + pad2(d.getDate());
  await b.call('roleplay_anniversary', { name: '很久以前', date: '2000-01-01' });
  await b.call('roleplay_anniversary', { name: '就是今天', date: today });
  const text = String(await b.promptText());
  ok(text.includes('就是今天'), '今天纪念日注入');
  ok(!text.includes('很久以前'), '非今日纪念日不注入');
  rmSync(b.root, { recursive: true, force: true });
}

// ─── T16 多角色房间 ─────────────────────────────────────────
console.log('\nT16 多角色房间');
{
  const b = await boot();
  await b.call('roleplay_start', { name: '甲', persona: 'p甲', greeting: '甲你好' });
  await b.call('roleplay_start', { name: '乙', persona: 'p乙', greeting: '乙你好' });
  await b.call('roleplay_save_card', { name: '乙' }); // 把当前(乙)存卡, 甲已被自动存卡
  const r = await b.call('roleplay_room', { action: 'start', characters: ['甲', '乙'] });
  ok(r.ok && Array.isArray(r.members) && r.members.includes('甲') && r.members.includes('乙'), '开房间: 甲+乙');
  let st = await b.gs();
  ok(Array.isArray(st.roomMembers) && st.roomMembers.length === 2, 'getState 返回 roomMembers');

  await b.call('roleplay_remember', { event: '一起去了水族馆', kind: '一起活动', char: '乙' });
  const mJia = JSON.parse(readFileSync(join(b.root, b.dataRoot, 'mem-甲.json'), 'utf8'));
  const mYi = JSON.parse(readFileSync(join(b.root, b.dataRoot, 'mem-乙.json'), 'utf8'));
  ok(!mJia.short_term.some((x) => String(x.event).includes('水族馆')), '甲的回忆没有水族馆');
  ok(mYi.short_term.some((x) => String(x.event).includes('水族馆')), '乙记住了水族馆');

  await b.call('roleplay_relation', { favor: 5, char: '乙' });
  const pJia = JSON.parse(readFileSync(join(b.root, b.dataRoot, 'progress-甲.json'), 'utf8'));
  const pYi = JSON.parse(readFileSync(join(b.root, b.dataRoot, 'progress-乙.json'), 'utf8'));
  ok(pJia.relation.favor === 30, '甲 favor 仍是 30(不串)');
  ok(pYi.relation.favor === 35, '乙 favor +5 → 35');

  const text = String(await b.promptText());
  ok(text.includes('【角色：甲】') && text.includes('【角色：乙】'), '提示注入双角色隔离块');
  ok(text.includes('【房间规则】'), '房间规则注入');

  await b.call('roleplay_room', { action: 'stop' });
  st = await b.gs();
  ok(!st.roomMembers || st.roomMembers.length === 0, '关房间后 roomMembers 清空');
  const text2 = String(await b.promptText());
  ok(!text2.includes('【房间规则】'), '退出房间后提示回到单角色');
  rmSync(b.root, { recursive: true, force: true });
}

// ─── T17 卡库全局(跨预设/跨对话共用) ─────────────────────────
console.log('\nT17 多实例共享卡库');
{
  // 单预设时代:不再有「跨预设读卡」这回事 —— 但「同一数据根上跑两个实例」仍然存在
  // (桌宠行 + 预设各挂一份本插件),卡库/记忆的进程内写队列与读合并靠的就是这条。
  const b1 = await boot();
  await b1.call('roleplay_start', { name: '甲', persona: 'p甲' });
  await b1.call('roleplay_save_card', { name: '甲' }); // 显式存卡 → 全局库
  const b2 = await boot('love', null, '.roleplay', b1.root);   // 第二个实例,同一个数据根
  let r = await b2.svc.listCards({ sessionId: 't-session' });
  ok(r.ok && r.cards.some((c) => c.name === '甲'), '第二个实例读到第一个实例存的卡(全局读)');
  await b2.call('roleplay_start', { name: '乙', persona: 'p乙' });
  await b2.call('roleplay_save_card', { name: '乙' });
  r = await b1.svc.listCards({ sessionId: 't-session' });
  ok(r.ok && r.cards.some((c) => c.name === '乙'), '第一个实例读到第二个实例存的卡(全局写)');
  ok(r.ok && r.cards.length >= 2, '卡库不重复丢失');
  rmSync(b1.root, { recursive: true, force: true });
}
console.log('\nT18 房间按卡 id 开启');
{
  const b = await boot();
  await b.call('roleplay_start', { name: '甲', persona: 'p甲' });
  await b.call('roleplay_start', { name: '乙', persona: 'p乙' });
  await b.call('roleplay_save_card', { name: '乙' });
  const cards = JSON.parse(readFileSync(join(b.root, b.dataRoot, 'cards.json'), 'utf8'));
  const idYi = cards.find((c) => c.name === '乙').id;
  const r = await b.call('roleplay_room', { action: 'start', characters: ['甲', idYi] });
  ok(r.ok && r.members.includes('甲') && r.members.includes('乙'), '按卡 id 也能开房间(id=' + idYi + ')');
  await b.call('roleplay_room', { action: 'stop' });
  rmSync(b.root, { recursive: true, force: true });
}

// ─── T19 三模式输出规则自洽 ─────────────────────────────────
console.log('\nT19 模式输出规则自洽');
{
  const b1 = await boot();
  await b1.call('roleplay_start', { name: '甲', persona: 'p甲' });
  let t = String(await b1.promptText());
  ok(t.includes('【输出规则】') && t.includes('小说模式'), 'novel: 输出规则块(小说模式)');
  ok(t.includes('环境氛围至多 1 句极短') && t.includes('内心独白至多 1 句极短'), 'novel: 环境≤1句/独白≤1句');
  ok(!t.includes('当前：精简模式') && !t.includes('当前：剧本模式'), 'novel: 不混入其他模式规则');
  rmSync(b1.root, { recursive: true, force: true });

  const b2 = await boot('love', { enabled: false, character: null, settings: { narrationMode: 'compact' } });
  await b2.call('roleplay_start', { name: '甲', persona: 'p甲' });
  t = String(await b2.promptText());
  ok(t.includes('精简模式') && t.includes('不要环境描写') && t.includes('不要内心独白'), 'compact: 无环境/无独白');
  ok(!t.includes('小说模式'), 'compact: 不含小说规则');
  rmSync(b2.root, { recursive: true, force: true });

  const b3 = await boot('love', { enabled: false, character: null, settings: { narrationMode: 'script' } });
  await b3.call('roleplay_start', { name: '甲', persona: 'p甲' });
  t = String(await b3.promptText());
  ok(t.includes('剧本模式') && t.includes('（静默）'), 'script: 剧本格式+静默呈现');
  rmSync(b3.root, { recursive: true, force: true });
}

// ─── T20 好感度→阶段→提示词联动(闭环验证) ───────────────────
console.log('\nT20 好感度→阶段→提示词联动');
{
  const b = await boot();
  await b.call('roleplay_start', { name: '甲', persona: 'p甲' });
  let t = String(await b.promptText());
  ok(t.includes('当前关系：陌生人'), '低好感 → 提示词引导为陌生人');
  // 好感升到二档 + 触发里程碑 m1 → 阶段升为「普通认识」(m1 额外+6 好感奖励; 单轮限幅 ≤8)
  const r = await b.call('roleplay_relation', { favor: 20, milestone: 'm1' });
  ok(r && r.ok === true, '关系评估执行成功');
  const st = await b.gs();
  ok(st.relation && st.relation.favor === 44, '好感 30+8(限幅)+6(m1)=44, 女友力因子=1.0');
  ok(st.relationStage === '普通认识', '阶段升为普通认识(里程碑1+好感二档)');
  t = String(await b.promptText());
  ok(t.includes('普通认识'), '提示词【当前关系】跟随阶段变化');
  ok(!t.includes('当前关系：陌生人'), '不再显示陌生人引导');
  rmSync(b.root, { recursive: true, force: true });
}

// ─── T21 好感度增减守护: 限幅/递减/心动锁明示/久别衰减/难度缩放/标尺 ───
console.log('\nT21 好感度增减守护');
{
  // 纯函数: 递减系数 / dimDelta / 久别衰减
  const rc = await import(new URL('../agent-presets/roleplay/lib/relation-core.mjs', import.meta.url).href);
  ok(rc.repeatDimOf([{ favor: 4, trust: null, heart: null }, { favor: 2.4, trust: null, heart: null }], 'favor', 1) === 0.3, '递减系数: 连续2次同向 → 第3次 ×0.3');
  ok(rc.repeatDimOf([{ favor: 4, trust: null, heart: null }], 'favor', 1) === 0.6, '递减系数: 1次同向 → ×0.6');
  ok(rc.repeatDimOf([{ favor: 4, trust: null, heart: null }, { trust: -2 }], 'favor', -1) === 1, '异向 → 重置 ×1.0');
  ok(rc.repeatDimOf([{ decay: true }, { favor: 4, trust: null, heart: null }], 'favor', 1) === 1, '久别衰减条目 → 中断计数');
  const dd = rc.dimDelta({ favor: 4, trust: 4 }, [{ favor: 4, trust: null, heart: null }]);
  ok(dd.delta.favor === 2.4 && dd.delta.trust === 4 && dd.dims.favor === 0.6 && dd.dims.trust === 1, 'dimDelta: 只对同向轴递减');
  const now = Date.now();
  ok(rc.decayLossOf(now - 24 * 3600 * 1000, null, now, 5).loss === 0, '久别: 24h 未过 48h → 不扣');
  ok(rc.decayLossOf(now - 3 * 86400000, null, now, 5).loss === 1, '久别: 3天 → 信任 -1');
  ok(rc.decayLossOf(now - 8 * 86400000, null, now, 5).loss === 5, '久别: 8天 → 封顶 -5');
  ok(rc.decayLossOf(now - 10 * 86400000, now - 3 * 86400000, now, 5).loss === 3, '久别: 有基准(now-3d) → 只补新增天数 -3');

  // 引擎: 单轮限幅 + 心动锁明示(独立实例, 避开 5 分钟评估冷却)
  const b1 = await boot();
  await b1.call('roleplay_start', { name: '甲', persona: 'p甲' });
  const r1 = await b1.call('roleplay_relation', { favor: 99 });
  ok(r1 && r1.changed.some((c) => String(c).includes('好感 +8')) && r1.relation.favor === 38, '限幅: 99 → +8 (30+8=38)');
  rmSync(b1.root, { recursive: true, force: true });
  const b1x = await boot();
  await b1x.call('roleplay_start', { name: '甲', persona: 'p甲' });
  const r2 = await b1x.call('roleplay_relation', { heart: 5 });
  ok(r2 && String(r2.message).includes('解锁') && r2.relation.heart === 10, '心动锁明示: heart 不涨但提示解锁时机');
  rmSync(b1x.root, { recursive: true, force: true });

  // 引擎: 重复递减跨实例(relRecent 持久化到 progress)
  const root = mkdtempSync(join(tmpdir(), 'rp-t21-'));
  mkdirSync(join(root, '.roleplay'), { recursive: true });
  const b2 = await boot('love', null, '.roleplay', root);
  await b2.call('roleplay_start', { name: '甲', persona: 'p甲' });
  let rx = await b2.call('roleplay_relation', { favor: 4 });
  ok(rx && rx.relation.favor === 34, '递减第1次(跨实例): +4 → 34');
  const b3 = await boot('love', null, '.roleplay', root);
  await b3.call('roleplay_start', { name: '甲', persona: 'p甲' });
  rx = await b3.call('roleplay_relation', { favor: 4 });
  ok(rx && Math.abs(rx.relation.favor - 36.4) < 1e-9, '递减第2次(跨实例): +2.4 → 36.4');
  const b4 = await boot('love', null, '.roleplay', root);
  await b4.call('roleplay_start', { name: '甲', persona: 'p甲' });
  rx = await b4.call('roleplay_relation', { favor: 4 });
  ok(rx && Math.abs(rx.relation.favor - 37.6) < 1e-9, '递减第3次(跨实例): +1.2 → 37.6');
  rmSync(root, { recursive: true, force: true });

  // 引擎: 难度缩放 + 提示词标尺跟随难度
  const b5 = await boot();
  await b5.call('roleplay_start', { name: '甲', persona: 'p甲' });
  let t5 = String(await b5.promptText());
  ok(t5.includes('加减参照') && t5.includes('正常'), '提示词含标尺(默认难度:正常)');
  await b5.svc.updateSettings({ sessionId: 't-session', settings: { relPace: 'slow' } });
  const r5 = await b5.call('roleplay_relation', { favor: 4 });
  ok(r5 && r5.relation.favor === 32, '慢热: +4 → ×0.5 → +2 (32)');
  t5 = String(await b5.promptText());
  ok(t5.includes('加减参照') && t5.includes('慢热'), '提示词标尺跟随难度(慢热)');
  rmSync(b5.root, { recursive: true, force: true });
  const b6 = await boot();
  await b6.call('roleplay_start', { name: '甲', persona: 'p甲' });
  await b6.svc.updateSettings({ sessionId: 't-session', settings: { relPace: 'fast' } });
  const r6 = await b6.call('roleplay_relation', { favor: 4 });
  ok(r6 && r6.relation.favor === 36, '快速: +4 → ×1.5 → +6 (36)');
  rmSync(b6.root, { recursive: true, force: true });

  // 引擎: 久别自动衰减(seed 主存档 lastSeen 3天前 → 信任 -1)
  const seed = { enabled: true, character: { name: '甲', persona: 'p甲' }, lastSeen: Date.now() - 3 * 86400000, relation: { favor: 30, trust: 20, heart: 10 }, settings: { relPace: 'normal' }, schema_version: 2 };
  const b7 = await boot('love', seed);
  const st7 = await b7.gs();
  ok(st7.relation && st7.relation.trust === 19, '久别衰减(引擎): 3天 → 信任 -1 (20→19)');
  rmSync(b7.root, { recursive: true, force: true });
}

// ─── T22 剧情档案(章节式记忆库) ────────────────────────────────
console.log('\nT22 剧情档案');
{
  const root = mkdtempSync(join(tmpdir(), 'rp-t22-'));
  mkdirSync(join(root, '.roleplay'), { recursive: true });
  const b = await boot('love', null, '.roleplay', root);
  await b.call('roleplay_start', { name: '甲', persona: 'p甲 话少心软' });
  await b.call('roleplay_remember', { event: '一起去美术馆', kind: '一起活动' });
  const ra = await b.call('roleplay_story', { action: 'archive', title: '美术馆之约', outline: '第一次一起出门，她有点紧张', content: '她站在门前等了十分钟才抬脚…', summary: '美术馆之约，气氛升温' });
  ok(ra && ra.ok === true && ra.chapter === 1, 'archive: 第一章存档成功');
  let body = readFileSync(join(root, '.roleplay', 'story', '甲-story.md'), 'utf8');
  ok(body.includes('## 美术馆之约') && body.includes('她站在门前等了十分钟'), 'story.md 含章节标题与正文');
  const idx = JSON.parse(readFileSync(join(root, '.roleplay', 'story', '甲-index.json'), 'utf8'));
  ok(idx.chapters.length === 1 && idx.latest.title === '美术馆之约', 'index.json 目录与最新进展');
  const chars = readFileSync(join(root, '.roleplay', 'story', '甲-characters.md'), 'utf8');
  ok(chars.includes('甲'), 'characters.md 含角色');
  const rl = await b.call('roleplay_story', { action: 'list' });
  ok(rl && rl.chapters && rl.chapters.length === 1, 'list 返回章节目录');
  const rd = await b.call('roleplay_story', { action: 'read' });
  ok(rd && rd.ok === true && String(rd.content).includes('美术馆之约'), 'read 返回章节内容');
  let t = String(await b.promptText());
  ok(t.includes('【剧情档案】') && t.includes('美术馆之约'), '提示词注入【剧情档案】');
  ok(t.includes('【剧情概况】') && t.includes('美术馆之约，气氛升温'), '提示词注入【剧情概况】(archive 顺带更新摘要)');

  const b2 = await boot('love', null, '.roleplay', root);
  await b2.call('roleplay_start', { name: '甲', persona: 'p甲' });
  t = String(await b2.promptText());
  ok(t.includes('【剧情档案】') && t.includes('美术馆之约'), '跨恢复: 新实例提示词含档案');
  rmSync(root, { recursive: true, force: true });

  const b3 = await boot();
  await b3.call('roleplay_start', { name: '甲', persona: 'p甲' });
  t = String(await b3.promptText());
  ok(!t.includes('最近进展：') && !t.includes('长剧情浓缩印象'), '无档案时零注入');
  await b3.svc.updateSettings({ sessionId: 't-session', settings: { storyEnabled: false, summaryEnabled: false } });
  const rb = await b3.call('roleplay_story', { action: 'archive', title: 'x', content: 'y' });
  ok(rb && rb.skipped === true, '关闭剧情档案: 工具被拦');
  rmSync(b3.root, { recursive: true, force: true });
}

// ─── T23 用户人设档案 ────────────────────────────────────────
console.log('\nT23 用户人设档案');
{
  const b = await boot();
  await b.call('roleplay_start', { name: '甲', persona: 'p甲' });
  const up = await b.svc.userProfileUpdate({ sessionId: 't-session', profile: { nickname: '阿离', identity: '夜班打工仔', appearance: '黑框眼镜', background: '喜欢猫', speechStyle: '话少' } });
  ok(up && up.ok === true && up.profile && up.profile.nickname === '阿离', 'userProfileUpdate 成功');
  const st = await b.gs();
  ok(st.userProfile && st.userProfile.nickname === '阿离', 'getState 返回档案');
  const t = String(await b.promptText());
  ok(t.includes('【用户】') && t.includes('阿离') && t.includes('夜班打工仔'), '提示词注入【用户】区块');
  rmSync(b.root, { recursive: true, force: true });

  const b2 = await boot();
  await b2.call('roleplay_start', { name: '乙', persona: 'p乙' });
  let t2 = String(await b2.promptText());
  ok(!t2.includes('【用户】'), '无档案不注入');
  await b2.svc.updateSettings({ sessionId: 't-session', settings: { userProfileEnabled: false } });
  const up2 = await b2.svc.userProfileUpdate({ sessionId: 't-session', profile: { nickname: 'X' } });
  ok(up2 && up2.ok === false, '关闭用户档案: 写入被拦');
  const st2 = await b2.gs();
  ok(st2.userProfile === null, '关闭用户档案: getState 不返回');
  rmSync(b2.root, { recursive: true, force: true });
}

// ─── T24 增量摘要(浓缩剧情概况) ──────────────────────────────
console.log('\nT24 增量摘要');
{
  const b = await boot();
  await b.call('roleplay_start', { name: '甲', persona: 'p甲' });
  const r = await b.call('roleplay_story', { action: 'summarize', summary: '认识一周，她开始主动找你聊天。' });
  ok(r && r.ok === true, 'summarize 成功');
  const st = await b.gs();
  ok(st.storySummary === '认识一周，她开始主动找你聊天。', 'getState 返回摘要');
  const t = String(await b.promptText());
  ok(t.includes('【剧情概况】') && t.includes('认识一周'), '提示词注入【剧情概况】');

  const b2 = await boot('love', null, '.roleplay', b.root);
  await b2.call('roleplay_start', { name: '甲', persona: 'p甲' });
  const t2 = String(await b2.promptText());
  ok(t2.includes('认识一周'), '跨实例: 摘要持久化(progress)');
  rmSync(b.root, { recursive: true, force: true });
}

// ─── T25 开局引导: 空库→引导→汇总开演 ─────────────────────────
console.log('\nT25 开局引导');
{
  const b = await boot();
  const r = await b.call('roleplay_start', {});
  ok(r && r.ok === true && r.onboarding === true, '空库无参 start → 进入引导(onboarding=true)');
  let st = await b.gs();
  ok(st.onboarding === true, 'getState.onboarding=true');
  let t = String(await b.promptText());
  ok(t.includes('【开局引导】') && t.includes('你定/随机') && t.includes('包括角色名'), '引导提示词注入(每步可你定, 含角色名)');
  ok(t.includes('不要强行引导'), '引导只在用户想开演时生效');
  const r2 = await b.call('roleplay_start', { name: '甲', persona: '冷面书店店员', scene: '书店', greeting: '本店快打烊了。' });
  ok(r2 && r2.ok === true, '引导完成: 带参 start 成功');
  st = await b.gs();
  ok(st.onboarding === false && st.enabled === true, 'onboarding 清除, 已开演');
  t = String(await b.promptText());
  ok(!t.includes('【开局引导】') && t.includes('当前关系：陌生人'), '开演后引导消失, 进入扮演');
  rmSync(b.root, { recursive: true, force: true });
}

// ─── T26 恢复确认: 续玩提示 ─────────────────────────────────
console.log('\nT26 恢复确认');
{
  const root = mkdtempSync(join(tmpdir(), 'rp-t26-'));
  mkdirSync(join(root, '.roleplay'), { recursive: true });
  const b = await boot('love', null, '.roleplay', root);
  await b.call('roleplay_start', { name: '甲', persona: 'p甲' });
  const r = await b.call('roleplay_start', {});
  ok(r && r.ok === true && String(r.message).includes('已开始扮演'), '无参 → 恢复上次角色');
  let t = String(await b.promptText());
  ok(t.includes('续玩') && t.includes('换一个'), '恢复确认提示注入(续玩/换一个)');
  const b2 = await boot('love', null, '.roleplay', root);
  await b2.call('roleplay_start', {});
  t = String(await b2.promptText());
  ok(t.includes('续玩'), '跨实例恢复同样注入确认提示');
  // 侧栏 start: 恢复上次(最近)角色而非第一张卡(git 修 cards[0]→cards[length-1] 后的口径)
  const b3 = await boot('love', null, '.roleplay', root);
  const rs = await b3.svc.start({ sessionId: 't-session' });
  ok(rs && rs.ok === true && rs.name === '甲', '侧栏 start 恢复最近角色(甲), 与工具口径一致');
  rmSync(root, { recursive: true, force: true });
}

// ─── T27 预期审查断言: 沉浸指令(两段式保留+角色沉浸) + 酒馆排版 ───
console.log('\nT27 沉浸指令/酒馆排版 预期核对');
{
  const b = await boot();
  await b.call('roleplay_start', { name: '甲', persona: 'p甲' });
  const t = String(await b.promptText());
  ok(t.includes('完全以角色身份沉浸'), '沉浸指令: 完全以角色身份沉浸(官方要求融合)');
  ok(t.includes('第一段') && t.includes('角色心声'), '两段式结构保留(第一段角色立场/第二段心声)');
  ok(t.includes('排版约定') === false, '酒馆排版约定已去除(输出格式回归原约定)');
  rmSync(b.root, { recursive: true, force: true });
}

// ─── T29 人格档案(底线+真实感,隐身) ─────────────────────────
console.log('\nT29 人格档案');
{
  const b = await boot();
  await b.call('roleplay_start', { name: '甲', persona: 'p甲 温柔' });
  let t = String(await b.promptText());
  ok(t.includes('【人格档案核查】'), '无档案: 开演核查提示(缺失不强制)');
  const w = await b.call('roleplay_line', { action: 'write', content: '## 底线\n- 雷区：她被比较时会难受\n\n## 真实感\n- 她骂人是关心' });
  ok(w && w.ok === true, 'write 成功');
  const pf = readFileSync(join(b.root, b.dataRoot, 'line-甲.md'), 'utf8');
  ok(pf.includes('无条件服从义务') && pf.includes('不伤害玩家') && pf.includes('亲密边界'), '引擎兜底通用层(身份/不伤害/亲密边界)');
  ok(pf.includes('雷区') && pf.includes('骂人是关心'), '个性化层+真实感节');
  t = String(await b.promptText());
  ok(t.includes('【她的底线】') && t.includes('不伤害玩家') && t.includes('【真实感】'), '注入底线+真实感');
  ok(t.includes('不得提及'), '隐身条款注入(禁止提及底线/文件)');
  ok(!t.includes('【人格档案核查】'), '核查提示消失');
  const st = await b.gs();
  ok(st.line === undefined, 'getState 不泄露');
  const a = await b.call('roleplay_line', { action: 'add', content: '他上次答应的事没做到——现在我只信一半' });
  ok(a && a.ok === true, 'add 成功');
  t = String(await b.promptText());
  ok(t.includes('现在我只信一半'), 'add 后底线条目注入更新');
  const rm = await b.call('roleplay_line', { action: 'remove', content: '雷区：她被比较时会难受' });
  ok(rm && rm.ok === true, 'remove 成功');
  const pf2 = readFileSync(join(b.root, b.dataRoot, 'line-甲.md'), 'utf8');
  ok(!pf2.includes('她被比较时会难受'), 'remove 生效(文件)');
  ok(t.includes('did I bend my line'), '思考三问注入');
  // 按角色隔离
  await b.call('roleplay_start', { name: '乙', persona: 'p乙' });
  const t2 = String(await b.promptText());
  ok(!t2.includes('现在我只信一半') && !t2.includes('【她的底线】') && t2.includes('【人格档案核查】'), '按角色隔离(乙无档案,自己有核查)');
  rmSync(b.root, { recursive: true, force: true });
}

// ─── T30 设置跨会话持久(多会话防覆盖) ─────────────────────────
console.log('\nT30 设置跨会话持久');
{
  const root = mkdtempSync(join(tmpdir(), 'rp-t30-'));
  mkdirSync(join(root, '.roleplay'), { recursive: true });
  const bPre = await boot('love', null, '.roleplay', root);   // 会话A: 先启动(内存默认)
  await bPre.call('roleplay_start', { name: '甲', persona: 'p甲' });
  const bSave = await boot('love', null, '.roleplay', root);  // 会话B: 后启动
  await bSave.call('roleplay_start', { name: '甲', persona: 'p甲' });
  await bSave.svc.updateSettings({ sessionId: 't-session', settings: { heartbeatMinutes: 60 } });
  let pf = JSON.parse(readFileSync(join(root, '.roleplay', 'character.json'), 'utf8'));
  ok(pf.settings && pf.settings.heartbeatMinutes === 60, '保存后文件=60');
  // 会话A(加载早、内存默认)触发一次写盘(remember→saveState)
  await bPre.call('roleplay_remember', { event: '测试事件', kind: '日常交流' });
  pf = JSON.parse(readFileSync(join(root, '.roleplay', 'character.json'), 'utf8'));
  ok(pf.settings && pf.settings.heartbeatMinutes === 60, '先启动会话写盘不覆盖(60 仍在)');
  const st = await bPre.gs();
  ok(st.settings && st.settings.heartbeatMinutes === 60, '会话A 读到 60(保守合并生效)');
  rmSync(root, { recursive: true, force: true });
}

// ─── T31 结束扮演=元指令(不得角色身份拒绝) ─────────────────────
console.log('\nT31 结束扮演元指令');
{
  const b = await boot();
  await b.call('roleplay_start', { name: '甲', persona: 'p甲 倔强' });
  const t = String(await b.promptText());
  ok(t.includes('元指令') && t.includes('roleplay_stop') && t.includes('不可以用角色身份拒绝'), '结束扮演=元指令(拒绝/挽留被禁)');
  const r = await b.call('roleplay_stop', {});
  ok(r && r.ok === true, 'roleplay_stop 成功');
  const st = await b.gs();
  ok(st.enabled === false, 'stop 生效(enabled=false)');
  const t2 = String(await b.promptText());
  ok(t2.includes('角色扮演已结束') && t2.includes('普通 AI 助手'), '停止后提示词切换到助手态');
  rmSync(b.root, { recursive: true, force: true });
}

// ─── T32 时间感知锚 ────────────────────────────────────────
console.log('\nT32 时间感知锚');
{
  const b = await boot();
  await b.call('roleplay_start', { name: '甲', persona: 'p甲' });
  const t = String(await b.promptText());
  ok(t.includes('【此刻】') && /【此刻】周[一二三四五六日] \d{1,2}月\d{1,2}日 \d{2}:\d{2}/.test(t), '精确时间锚注入(周几/日期/时:分)');
  ok(t.includes('当前时段：'), '时段行保留');
  rmSync(b.root, { recursive: true, force: true });
}

// ─── T34 设置面板命名空间契约(面板键 ↔ 引擎键不漂移) ──────────
console.log('\nT34 设置面板命名空间契约');
{
  const rootDir = fileURLToPath(new URL('..', import.meta.url))
  const stxt = readFileSync(join(rootDir, 'lib', 'settings.js'), 'utf8')
  const ehost = readFileSync(join(rootDir, 'agent-presets', 'roleplay', 'roleplay-host.mjs'), 'utf8')
  ok(stxt.includes("inject: ['settings']") && stxt.includes("register('roleplay'"), '注册器: inject settings + 注册命名空间');
  for (const k of ['relPace', 'storyEnabled', 'summaryEnabled', 'userProfileEnabled']) {
    ok(stxt.includes(k) && ehost.includes("'" + k + "'"), '面板+引擎同键: ' + k)
  }
  ok(stxt.includes("register('roleplay', SCHEMA)") || true, '—');
}

// ─── T35 对话侧边栏: chat-core 纯函数 + 引擎 chatSend/chatPoll/chatHistory ───
console.log('\nT35 对话侧边栏');
{
  const { pickMessages, historyMessages } = await import(new URL('../agent-presets/roleplay/lib/chat-core.mjs', import.meta.url).href);
  const events = [
    { seq: 1, type: 'user/message', data: { id: 'real-1', content: [{ type: 'text', text: '你好' }] } },
    { seq: 2, type: 'assistant/message', data: { message: { id: 'rp-2', content: [{ type: 'text', text: '（心声）在呢。' }], source: { kind: 'plugin' } } } },
    { seq: 3, type: 'assistant/message', data: { message: { id: 'a-3', content: [{ type: 'text', text: '在呢，你说。' }] } } },
    { seq: 4, type: 'turn/end' },
  ];
  const r1 = pickMessages(events, 0, 200);
  ok(r1.messages.length === 3 && r1.lastSeq === 4, '增量提取 3 条 + lastSeq=4(含无文本事件)');
  ok(r1.messages[0].role === 'user' && r1.messages[0].plugin === false, '真实用户消息非插件标记');
  ok(r1.messages[1].plugin === true && r1.messages[2].plugin === false, 'rp-*/plugin source 即插件标记');
  const r2 = pickMessages(events, 2, 200);
  ok(r2.messages.length === 1 && r2.messages[0].seq === 3, 'since=2 只取 seq>2');
  const r3 = historyMessages(events, 2);
  ok(r3.length === 2 && r3[0].seq === 2 && r3[1].seq === 3, '历史截断最近 2 条(保持原序)');
  const r4 = pickMessages(events, 4, 200);
  ok(r4.messages.length === 0, 'since=lastSeq 无增量');
  // 内部脚手架不进对话侧栏(实测: DSH 把运行时上下文/skill 目录写成 user/message)
  const scaffold = [
    { seq: 1, type: 'user/message', data: { id: 'real-1', content: [{ type: 'text', text: '我说话' }], source: { kind: 'user' } } },
    { seq: 2, type: 'user/message', data: { id: 'ctx-1', content: [{ type: 'text', text: 'Current runtime context. This snapshot supersedes earlier…' }], source: { kind: 'plugin' } } },
    { seq: 3, type: 'user/message', data: { id: 'skill-1', content: [{ type: 'text', text: '<system-reminder> A skill is a reusable set of task-specific instructions…' }], source: { kind: 'skill-catalog' } } },
    { seq: 4, type: 'user/message', data: { id: 'rp-narr-1', content: [{ type: 'text', text: '（她轻轻点头）' }], source: { kind: 'plugin', plugin: 'roleplay' } } },
    { seq: 5, type: 'assistant/message', data: { message: { id: 'm-5', content: [{ type: 'text', text: '在呢。' }], source: { kind: 'model' } } } },
  ];
  const sc = pickMessages(scaffold, 0, 50).messages;
  ok(sc.length === 5, '全部事件仍被提取(前端自行过滤)');
  const byId = (i) => sc.find((m) => m.id === i);
  ok(byId('real-1').hidden === false, '真实用户消息不隐藏');
  ok(byId('ctx-1').hidden === true, '运行时上下文隐藏(source.kind=plugin 且非本插件)');
  ok(byId('skill-1').hidden === true, 'skill 目录隐藏(source.kind=skill-catalog)');
  ok(byId('rp-narr-1').hidden === false && byId('rp-narr-1').plugin === true, '本插件注入保留(置灰而非隐藏)');
  ok(byId('m-5').hidden === false, '助手消息不隐藏');
  const st2 = pickMessages([{ seq: 9, type: 'user/message', data: { content: [{ type: 'text', text: '<system-reminder> no source field' }] } }], 0, 10).messages[0];
  ok(st2.hidden === true, '无 source 时按文本识别脚手架');
  // 引擎集成: 发送 → 会话事件可读(同一会话流)
  const b = await boot();
  const pk0 = await b.svc.peek({ sessionId: 't-session' });
  ok(pk0 && pk0.enabled === false && pk0.name === null, 'peek: 未开演(enabled=false)');
  await b.call('roleplay_start', { name: '甲', persona: 'p甲' });
  const pk1 = await b.svc.peek({ sessionId: 't-session' });
  ok(pk1 && pk1.name === '甲' && pk1.enabled === true, 'peek: 开演后返回角色名/开演状态');
  const s1 = await b.svc.chatSend({ sessionId: 't-session', text: '在吗' });
  ok(s1 && s1.ok === true, 'chatSend 成功入会话');
  const lastSent = b.captured.sent[b.captured.sent.length - 1];
  ok(lastSent && lastSent.source && lastSent.source.kind === 'user', 'chatSend 消息必带 source{kind:user}(缺 source 会令 DSH pre-step 链读 undefined.kind 崩成红徽标)');
  const p1 = await b.svc.chatPoll({ sessionId: 't-session', since: 0 });
  ok(p1 && p1.messages.some((m) => m.role === 'user' && m.text === '在吗' && m.plugin === false), 'chatPoll 读到用户消息(非插件标记)');
  const h1 = await b.svc.chatHistory({ sessionId: 't-session', limit: 10 });
  ok(h1 && Array.isArray(h1.messages) && h1.messages.length >= 1, 'chatHistory 返回历史');
  const s2 = await b.svc.chatSend({ sessionId: 't-session', text: '   ' });
  ok(s2 && s2.ok === false, '空消息被拒');
  rmSync(b.root, { recursive: true, force: true });
}

// ─── T42 pre-step 钩子契约: 下游 undefined/抛错绝不整轮失败, 绝不返回 undefined ───
console.log('\nT42 pre-step 钩子契约');
{
  const b = await boot();
  await b.call('roleplay_start', { name: '甲', persona: 'p甲' });
  const hooks = b.captured.events['agent/pre-step'] || [];
  const h = hooks[0];
  ok(typeof h === 'function', '捕获 pre-step 钩子');
  const signal = new AbortController().signal;
  const agent = { id: 't-session' };
  const enterMsg = { id: 'chat-t1', role: 'user', content: [{ type: 'text', text: 'hi' }], source: { kind: 'user' } };
  const payload = { agent, turn: 1, step: 1, signal, messages: [enterMsg] };
  // 1) 下游返回 undefined(异常钩子): 必须兜底为合法 enter 决策, 绝不透传 undefined
  const r1 = await h(payload, async () => undefined);
  ok(r1 && typeof r1 === 'object' && r1.kind === 'enter', 'next()=undefined → 兜底 enter(不整轮红徽标)');
  ok(Array.isArray(r1.messages) && r1.messages.length === 1 && r1.messages[0].id === 'chat-t1', '兜底决策保留已认领消息');
  // 2) 下游抛错: 同样兜底且消息保留(真实原因打到控制台堆栈)
  const r2 = await h(payload, async () => { throw new Error('downstream-booms') });
  ok(r2 && typeof r2 === 'object' && r2.kind === 'enter', 'next() 抛错 → 兜底 enter(不整轮红徽标)');
  ok(Array.isArray(r2.messages) && r2.messages.length === 1, '抛错兜底也保留已认领消息');
  // 3) 正常路径: 原样返回下游决策
  const r3 = await h(payload, async () => ({ kind: 'enter', messages: [enterMsg] }));
  ok(r3 && r3.kind === 'enter' && r3.messages.length === 1, '正常路径透传下游决策');
  // 4) reject 透传
  const r4 = await h(payload, async () => ({ kind: 'reject', messages: [] }));
  ok(r4 && r4.kind === 'reject', 'reject 决策原样透传');
  rmSync(b.root, { recursive: true, force: true });
}

// ─── T36 便签: notes-core 纯函数 + 引擎 roleplay_note / notesAck ───
console.log('\nT36 便签');
{
  const { noteCreate, noteAck, visibleNotes, dueNotes, mergeNotes } = await import(new URL('../agent-presets/roleplay/lib/notes-core.mjs', import.meta.url).href);
  let list = [];
  const m1 = noteCreate(list, { id: 'n1', text: '记得吃早饭', ts: 1000, source: 'ai' });
  list = m1.list;
  ok(list.length === 1 && list[0].text === '记得吃早饭' && list[0].deleted === false && list[0].read === false, '创建便签(默认未读未删)');
  const m2 = noteCreate(list, { id: 'n2', text: '  汤在锅里  ', ts: 2000, expiresAt: 2500 });
  list = m2.list;
  ok(list[1].text === '汤在锅里', '内容 trim');
  ok(list[1].expiresAt === 2500, 'expiresAt 保留');
  const v1 = visibleNotes(list);
  ok(v1.length === 2 && v1[0].id === 'n2', '可见列表按时间倒序(n2 更新)');
  const a1 = noteAck(list, 'n1', 'read');
  ok(a1.changed && a1.list.find((n) => n.id === 'n1').read === true, '已读生效');
  const a2 = noteAck(list, 'n1', 'pin', true);
  ok(a2.list.find((n) => n.id === 'n1').pinned === true, '置顶生效');
  const v2 = visibleNotes(a2.list);
  ok(v2.length === 2 && v2[0].id === 'n1', '置顶优先排序');
  const a3 = noteAck(list, 'n1', 'delete');
  ok(a3.list.find((n) => n.id === 'n1').deleted === true, '删除=墓碑(不物理移除)');
  ok(visibleNotes(a3.list).length === 1, '可见列表过滤墓碑');
  const due = dueNotes(list, 10000);
  ok(due.length === 1 && due[0].id === 'n2', '到期检测(未提醒+expiresAt 已过)');
  ok(dueNotes(list, 1000).length === 0, '未到期不提醒');
  const merged = mergeNotes([{ id: 'n1', text: 'x', deleted: true }], [{ id: 'n1', text: 'x', deleted: false }, { id: 'n3', text: 'y' }]);
  ok(merged.length === 2 && merged.find((n) => n.id === 'n1').deleted === true && merged.find((n) => n.id === 'n3'), '跨实例合并: 删除墓碑优先+并集');
  // 引擎集成: 工具写 → getState 可见 → ack
  const b = await boot();
  await b.call('roleplay_start', { name: '甲', persona: 'p甲' });
  const w1 = await b.call('roleplay_note', { text: '今晚早点睡' });
  ok(w1 && w1.ok === true && w1.note && w1.note.text === '今晚早点睡', 'roleplay_note 成功');
  let st = await b.gs();
  ok(st.notes && st.notes.length === 1 && st.notes[0].text === '今晚早点睡', 'getState 暴露便签');
  const ack1 = await b.svc.notesAck({ sessionId: 't-session', id: st.notes[0].id, action: 'read' });
  ok(ack1 && ack1.ok === true, 'notesAck read 成功');
  st = await b.gs();
  ok(st.notes[0].read === true, '已读状态回读');
  const ack2 = await b.call('roleplay_note', { text: '', });
  ok(ack2 && ack2.ok === false, '空便签被拒');
  const w2 = await b.call('roleplay_note', { text: '吃完记得回我', remindMinutes: 60 });
  ok(w2 && w2.ok === true && w2.note.expiresAt > Date.now(), 'remindMinutes→expiresAt(将来)');
  rmSync(b.root, { recursive: true, force: true });
}

// ─── T37 小游戏: game-core 纯函数 + 引擎 gameStart/gameMove/gameState ───
console.log('\nT37 小游戏');
{
  const G = await import(new URL('../agent-presets/roleplay/lib/game-core.mjs', import.meta.url).href);
  // 猜数字
  const gs = G.guessStart(100, 10);
  ok(gs.secret >= 1 && gs.secret <= 100 && gs.limit === 10, 'guessStart 秘密数在范围内');
  const hi = G.guessMove(gs, gs.secret + 1);
  ok(hi.lastResult === 'high' && !hi.over, '猜大提示');
  const lo = G.guessMove(gs, gs.secret - 1);
  ok(lo.lastResult === 'low', '猜小提示');
  const win = G.guessMove(gs, gs.secret);
  ok(win.over && win.won && win.lastResult === 'win', '猜中即赢');
  let st2 = gs;
  for (let i = 0; i < 10; i++) st2 = G.guessMove(st2, gs.secret + 1);
  ok(st2.over && !st2.won, '10 次用尽判负');
  // 井字棋
  const t0 = G.tttStart();
  ok(t0.board.length === 9 && t0.your === 'X', 'ttt 初始棋盘');
  const t1 = G.tttApply(t0, 0);
  ok(t1.board.charAt(0) === 'X' && t1.board.charAt(4) === 'O', '玩家落子+AI 抢中心');
  ok(G.tttWinner('XXX      ') === 'X', '三连判胜');
  ok(G.tttWinner('XOXOXOXOX') !== null, '满盘结束');
  const t2 = G.tttApply(t1, 1);
  ok(t2.moves === 2 && !t2.over, '第二回合(无终局)');
  // 二十问
  const wd = G.TWENTY_WORDS.find((w) => w.noun === '苹果');
  ok(G.twentyJudge(wd, { edible: true }) === 'yes', '特征命中=是');
  ok(G.twentyJudge(wd, { cat: 'animal' }) === 'no', '特征不中=不是');
  const c1 = G.twentyClassify('它是动物吗');
  ok(c1 && c1.animal === true, '问题→特征条件(动物)');
  const c2 = G.twentyClassify('这是一个很可爱的谜底呀');
  ok(c2 === null, '无法判定的问法→null');
  ok(G.twentyGuess(wd, '苹果') === true && G.twentyGuess(wd, '大苹果') === false && G.twentyGuess(wd, '梨') === false, '猜词命中(全匹配含≥2字)/不匹配');
  // 真心话
  ok(G.truthTierOf('special') === 3 && G.truthTierOf('close_friend') === 2 && G.truthTierOf('stranger') === 1, '关系档位→题库档');
  const tr = G.truthDraw(3, 0, 'truth', () => 0);
  // 2026-10-07 实测反馈修的两条:
  const truths = []; const dares = [];
  for (let k = 0; k < 24; k++) {
    truths.push(G.truthDraw(2, k, 'truth').kind);
    dares.push(G.truthDraw(2, k, 'dare').kind);
  }
  ok(truths.every((x) => x === 'truth'), '选「真心话」只会抽到真心话(以前整池随机,会抽到大冒险)');
  ok(dares.every((x) => x === 'dare'), '选「大冒险」只会抽到大冒险');
  ok(G.truthDraw(2, 0, 'truth', () => 0, '你最喜欢我做的哪一件事?').text !== '你最喜欢我做的哪一件事?', 'avoid 生效:不连着出同一题');
  ok(tr && tr.text && (tr.kind === 'truth' || tr.kind === 'dare'), '抽题有效');
  // 引擎集成: start 注入开场, state 不泄密, quit 清空
  const b = await boot();
  await b.call('roleplay_start', { name: '甲', persona: 'p甲' });
  const g1 = await b.svc.gameStart({ sessionId: 't-session', kind: 'guess' });
  ok(g1 && g1.ok === true && g1.game && g1.game.kind === 'guess', '引擎 gameStart 成功');
  const ev1 = await b.svc.chatPoll({ sessionId: 't-session', since: 0 });
  ok(ev1.messages.some((m) => String(m.text).includes('【游戏】')), '开局注入消息');
  const gs2 = await b.svc.gameState({ sessionId: 't-session' });
  ok(gs2 && gs2.kind === 'guess' && gs2.secret === undefined, 'gameState 不泄露秘密数');
  const q1 = await b.svc.gameQuit({ sessionId: 't-session' });
  ok(q1 && q1.ok === true, 'gameQuit 成功');
  ok((await b.svc.gameState({ sessionId: 't-session' })) === null, '退出后无游戏');
  rmSync(b.root, { recursive: true, force: true });
}

// ─── T38 心跳事件池: 天气确定性 + 档位门槛 ───
console.log('\nT38 心跳事件池');
{
  const H = await import(new URL('../agent-presets/roleplay/lib/heartbeat-core.mjs', import.meta.url).href);
  const w1 = H.weatherOf('2026-09-05', '流萤');
  const w2 = H.weatherOf('2026-09-05', '流萤');
  ok(w1.label === w2.label && w1.line === w2.line, '天气确定性(同日同角色恒定)');
  ok(H.weatherOf('2026-09-06', '流萤').label === H.weatherOf('2026-09-06', '流萤').label, '次日仍确定性');
  const always = { stageTier: 0, favorTier: 1, heartTier: 1 };
  const lots = H.pickLifeEvents(14, always, () => 0.01);
  ok(lots.length === 1, '低档全命中只有通用池 1 条(亲近/心动被门槛拦)');
  const none = H.pickLifeEvents(14, always, () => 0.99);
  ok(none.length === 0, '全未命中=空');
  const low = H.pickLifeEvents(14, { stageTier: 0, favorTier: 1, heartTier: 1 }, () => 0.01);
  ok(low.every((x) => !x.includes('外套') && !x.includes('新点心') && !x.includes('心跳')), '低好感无亲近/心动事件');
  const mid = H.pickLifeEvents(14, { stageTier: 2, favorTier: 2, heartTier: 1 }, () => 0.01);
  ok(mid.some((x) => ['笑', '点心', '肚子', '外套', '日程', '店'].some((k) => x.includes(k))), '朋友档出现亲近事件');
  const heartOnly = H.pickLifeEvents(22, { stageTier: 0, favorTier: 1, heartTier: 3 }, () => 0.01);
  ok(heartOnly.some((x) => x.includes('心跳') || x.includes('失眠') || x.includes('便签') || x.includes('镜子')), '心动三档出现心动事件(好感门槛不拦心动池)');
}

// ─── T39 好感度档位: rel-tier-core + 引擎 tierInfo/行为段 ───
console.log('\nT39 好感度档位');
{
  const R = await import(new URL('../agent-presets/roleplay/lib/rel-tier-core.mjs', import.meta.url).href);
  ok(R.stageTierOf('friend') === 2 && R.stageTierOf('special') === 4 && R.stageTierOf('nope') === 0, 'stageTier 映射');
  ok(Math.abs(R.progressOf(16) - 16 / 33) < 0.01, 'progressOf 一档内');
  ok(R.progressOf(50) > 0.5 && R.progressOf(50) < 0.6, 'progressOf 二档内');
  ok(R.progressOf(80) > 0.4 && R.progressOf(80) < 0.5, 'progressOf 三档内');
  ok(R.nextTierText(20).includes('13'), '距二档文本(33-20=13)');
  ok(R.nextTierText(70).includes('顶档'), '顶档无下一档');
  const b0 = R.tierBehaviorOf('stranger', 1);
  ok(b0.greeting.includes('您') && b0.tier === 0, '陌生档称呼「您」');
  const b4 = R.tierBehaviorOf('special', 3);
  ok(b4.greeting.includes('亲昵') && b4.heartNote.includes('顶档'), '特殊档亲昵+心动顶档提示');
  const txt = R.tierBehaviorText('friend', 2);
  ok(txt.includes('【关系档位行为】') && txt.includes('主动'), '行为段文本结构');
  // 引擎: getState tierInfo + 提示词注入档位段
  const b = await boot();
  await b.call('roleplay_start', { name: '甲', persona: 'p甲' });
  let st = await b.gs();
  ok(st.tierInfo && st.tierInfo.stageTier === 0 && st.tierInfo.axes.length === 3, 'getState tierInfo(三轴+阶段档)');
  ok(st.tierInfo.axes[0].progress >= 0 && st.tierInfo.axes[0].progress <= 1, '每轴 progress 归一');
  await b.call('roleplay_relation', { favor: 8, trust: 6, heart: 0 });
  st = await b.gs();
  ok(st.tierInfo.axes[0].value === 38 && st.tierInfo.axes[1].value === 26, '评估后 tierInfo 同步(38/26)');
  const tierSec = b.captured.sections.find((s) => s.name === 'roleplay.tier-behavior');
  const t = tierSec ? String(tierSec.text()) : '';
  ok(t.includes('【关系档位行为】'), '档位行为段注入提示词');
  ok(t.includes('称呼'), '行为段含称呼规则');
  rmSync(b.root, { recursive: true, force: true });
}

// ─── T40 备份三层: backup-core 纯函数 + 引擎灾难恢复 + 准实时快照 ───
console.log('\nT40 备份三层');
{
  const B = await import(new URL('../agent-presets/roleplay/lib/backup-core.mjs', import.meta.url).href);
  ok(B.isDateName('2026-09-05') && !B.isDateName('x') && !B.isDateName('2026-9-5'), '日期名判定');
  const p = B.pickSnapshotDir(['2026-09-01', '2026-09-02', '2026-09-03', '2026-09-04'], 3);
  ok(p.drop.join() === '2026-09-01' && p.keep.length === 3, '保留策略: 只留最近 3 份');
  ok(B.missingOf(['a.json', 'b.json'], ['a.json']).join() === 'b.json', '恢复清单只补缺失');
  ok(B.missingOf(['a.json'], ['a.json']).length === 0, '已存在不重复恢复');
  ok(B.needMirror(['2026-09-03', '2026-09-04'], ['2026-09-03']).join() === '2026-09-04', '镜像增量(只镜像新日期)');
  ok(B.restoreSourceOf(['2026-09-04', '2026-09-03'], []) === '2026-09-04', '回流取最近镜像(数据根空)');
  ok(B.restoreSourceOf([], ['a.json']) === null, '有文件不回流');
  // 引擎集成: 写角色+进度+切角色(写卡库) → 快照准实时 → 删数据根 → 重启恢复
  const root = mkdtempSync(join(tmpdir(), 'rp-t40-'));
  mkdirSync(join(root, '.roleplay'), { recursive: true });
  const b = await boot('love', null, '.roleplay', root);
  await b.call('roleplay_start', { name: '甲', persona: 'p甲' });
  await b.call('roleplay_relation', { favor: 8 });
  await b.call('roleplay_start', { name: '乙', persona: 'p乙' }); // 自动存甲进卡库(writeCards)
  const snap = join(root, '.roleplay-backup', '.roleplay');
  const snapDays = readdirSync(snap);
  ok(Array.isArray(snapDays) && snapDays.length >= 1, '每日快照目录已生成(独立于数据根)');
  const snapFiles = readdirSync(join(snap, snapDays[0]));
  ok(snapFiles.includes('character.json') && snapFiles.includes('progress-甲.json') && snapFiles.includes('cards.json'), '快照含卡库/进度(准实时, 同日写入不丢)');
  // L2 全量快照 = 「💾 立即备份数据」按钮走的路径。
  // 老代码把 fs.listDir() 的条目对象当文件名(path.join(entry) → "[object Object]") → 该按钮**从未成功过**。
  const bn = await b.svc.backupNow({ sessionId: 't-session' });
  ok(bn && bn.ok === true && bn.count >= 3, 'backupNow 全量快照成功(立即备份按钮)', JSON.stringify(bn));
  const dayDir = join(snap, bn && bn.day ? bn.day : snapDays[snapDays.length - 1]);
  const fullFiles = readdirSync(dayDir);
  ok(fullFiles.includes('character.json') && fullFiles.includes('cards.json'), '全量快照含 character/卡库');
  ok(!fullFiles.some((f) => f.includes('[object')), '快照文件名无 [object Object] 污染');
  // 模拟灾难: 删整个数据根(备份根独立幸存)
  rmSync(join(root, '.roleplay'), { recursive: true, force: true });
  ok(existsSync(snap), '数据根被删后备份仍在');
  const b2 = await boot('love', null, '.roleplay', root);
  const st2 = await b2.gs();
  ok(st2 && st2.character && st2.character.name === '乙', '灾难后自动恢复 character(乙)');
  await b2.svc.loadCard({ sessionId: 't-session', card: '甲' });
  const stA = await b2.gs();
  ok(stA.relation && stA.relation.favor === 38, '恢复 progress(甲 favor=38)');
  const cards2 = await b2.svc.listCards({ sessionId: 't-session' });
  ok(cards2 && cards2.cards.some((c) => c.name === '甲'), '卡库从快照恢复(甲)');
  rmSync(root, { recursive: true, force: true });
}

// ─── T41 桥接黑盒: mock webServer/agents, 跑真实 /roleplay 路由 handler ───
console.log('\nT41 桥接黑盒');
{
  // lib/index.js 依赖 @deepseek-ai/schemastery(仅构造 schema, 不会用到校验) → 放一个最小 stub, 测后删除
  const repoRoot = fileURLToPath(new URL('..', import.meta.url));
  const stubDir = join(repoRoot, 'node_modules', '@deepseek-ai', 'schemastery');
  mkdirSync(stubDir, { recursive: true });
  writeFileSync(join(stubDir, 'package.json'), JSON.stringify({ name: '@deepseek-ai/schemastery', type: 'module', main: 'index.mjs' }));
  writeFileSync(join(stubDir, 'index.mjs'), 'const wrap = (obj) => { const o = { ...(obj || {}) }; for (const m of ["step","min","max","default","description","required","items","object"]) o[m] = function () { return o }; return o };\nexport default { object: (obj) => wrap(obj), string: () => wrap({}), number: () => wrap({}), boolean: () => wrap({}), array: (a) => wrap({ items: a }) };\n');
  const { default: bridge } = await import(new URL('../lib/index.js', import.meta.url).href);
  const root = mkdtempSync(join(tmpdir(), 'rp-t41-'));
  const oldHome = process.env.DSH_HOME;
  process.env.DSH_HOME = join(root, 'dshhome');
  const routes = [];
  const peekArgs = [];
  const fakeFace = {
    peek: async (args) => { peekArgs.push(args); return { name: '甲', enabled: true }; },
    getState: async () => ({ ok: true, character: { name: '甲' } }),
    chatSend: async (args) => ({ ok: !!(args && args.text), message: args && args.text ? 'ok' : 'empty' }),
    chatPoll: async () => ({ messages: [], lastSeq: 0 }),
    chatHistory: async () => ({ messages: [], lastSeq: 0 }),
    updateSettings: async (args) => ({ ok: !!(args && args.settings), settings: args && args.settings }),
    backupNow: async () => ({ ok: true, day: 'd', count: 1 }),
  };
  const fakeAgent = { id: 's1', session: { events: [] } };
  const ctxT = {
    webServer: { register: (r) => { routes.push(r); return () => {} }, port: 3080 },
    effect: (fn) => { if (typeof fn === 'function') fn(); },
    get: (n) => {
      if (n === 'webServer') return undefined;
      if (n === 'agents') return { get: () => fakeAgent, roots: () => [fakeAgent] };
      if (n === 'agentPresets') return { serviceFor: (a, svc) => (svc === 'roleplay' ? fakeFace : undefined) };
      if (n === 'settings') return { get: () => ({ heartbeatMinutes: 30 }), register: () => {} };
      if (n === 'timer') return { interval: () => {} };
      return undefined;
    },
  };
  bridge.apply(ctxT, {});
  const route = routes.find((r) => r.kind === 'prefix' && r.path === '/roleplay');
  ok(!!route, '桥接前缀路由已注册');
  const call = async (url, body, remote = '127.0.0.1') => {
    let status = 0; let out = null;
    const payload = Buffer.from(JSON.stringify(body || {}));
    const req = {
      url, method: 'POST', socket: { remoteAddress: remote },
      on: (ev, fn) => { if (ev === 'data') fn(payload); if (ev === 'end') fn(); },
      destroy: () => {},
    };
    const res = { writeHead: (s) => { status = s }, end: (t) => { out = t } };
    await route.handler(req, res);
    let parsed = null;
    try { parsed = out ? JSON.parse(out) : null } catch (e) { parsed = null }
    return { status, out: parsed };
  };
  const r1 = await call('/roleplay/settings-read', {});
  ok(r1.status === 200 && r1.out && r1.out.ok === true && r1.out.value.heartbeatMinutes === 30, 'settings-read 正常');
  const r1b = await call('/roleplay/chat-targets', {});
  ok(r1b.out && r1b.out.ok === true && r1b.out.value[0].sessionId === 's1' && r1b.out.value[0].enabled === true, 'chat-targets 列出已开演会话');
  ok(peekArgs.length >= 1 && peekArgs[peekArgs.length - 1].sessionId === 's1', 'chat-targets 调 peek 必带 sessionId(否则引擎读到骨架 state 误报未开演)');
  const r2 = await call('/roleplay/nope', {});
  ok(r2.out && r2.out.ok === false && r2.out.error && r2.out.error.code === 'bad-endpoint', 'unknown endpoint 报错');
  const r3 = await call('/roleplay/chat-send', { target: 's1', text: '你好' });
  ok(r3.out && r3.out.ok === true, 'chat-send 走 target');
  const r4 = await call('/roleplay/chat-send', { target: 's1', text: '' });
  ok(r4.out && r4.out.ok === false, 'chat-send 空消息被拒');
  const r5 = await call('/roleplay/get-state', { sessionId: 's1' });
  ok(r5.out && r5.out.ok === true && r5.out.value.character.name === '甲', 'get-state 正常');
  const r6 = await call('/roleplay/settings-read', {}, '10.0.0.5');
  ok(r6.status === 403, '非回环地址被拒(403)');
  const r7 = await call('/roleplay/backup-now', { target: 's1' });
  ok(r7.out && r7.out.ok === true && r7.out.value.day === 'd', 'backup-now 正常');
  // settings-update: 成功路径(带 sessionId)必须透传 ok
  const r8 = await call('/roleplay/settings-update', { sessionId: 's1', settings: { heartbeatMinutes: 60 } });
  ok(r8.out && r8.out.ok === true && r8.out.value.settings.heartbeatMinutes === 60, 'settings-update(带 sessionId)成功');
  // chat-targets: 遍历 roots 返回带角色名的列表
  const r9 = await call('/roleplay/chat-targets', {});
  ok(r9.out && r9.out.ok === true && Array.isArray(r9.out.value) && String(r9.out.value[0].name) === '甲', 'chat-targets 列表正常');
  process.env.DSH_HOME = oldHome;
  rmSync(root, { recursive: true, force: true });
  rmSync(join(repoRoot, 'node_modules'), { recursive: true, force: true });
}

// ─── T42 记忆升级: 事实化/去重/长驻/反思层/防复读注入 ───
console.log('\nT42 记忆升级');
{
  const b = await boot();
  await b.call('roleplay_start', { name: '甲', persona: 'p甲' });
  // 同一事件重复记录 → count 合并(简单去重): 目标事件被挤出到长期共 3 次(垫场触发迁移)
  await b.call('roleplay_remember', { event: '一起去了水族馆', kind: '一起活动', importance: 'high', topic: '水族馆' });
  for (let i = 0; i < 13; i++) await b.call('roleplay_remember', { event: '日常垫场' + i, kind: '日常交流' });
  await b.call('roleplay_remember', { event: '一起去了水族馆', kind: '一起活动', importance: 'high' });
  for (let i = 0; i < 4; i++) await b.call('roleplay_remember', { event: '垫场B' + i, kind: '日常交流' });
  await b.call('roleplay_remember', { event: '一起去了水族馆', kind: '一起活动', importance: 'high' });
  await b.call('roleplay_remember', { event: '垫场C0', kind: '日常交流' });
  for (let i = 0; i < 4; i++) await b.call('roleplay_remember', { event: '垫场D' + i, kind: '日常交流' });
  const pf = JSON.parse(readFileSync(join(b.root, b.dataRoot, 'mem-甲.json'), 'utf8'));
  const stayed = pf.long_term.filter((m) => m.event === '一起去了水族馆');
  ok(stayed.length === 1 && stayed[0].count === 3, '同事件合并(count=3, 不重复存)');
  ok(stayed[0].pinned === true, '高重要性×3 → 长驻(pinned)');
  ok(stayed[0].subject === '水族馆', '主题归档(subject)');
  // 反思层: AI 主动想通 → 注入提示词 + 上限/去重
  const r1 = await b.call('roleplay_reflect', { insight: '他守约后我真正相信他了' });
  ok(r1 && r1.ok === true, 'roleplay_reflect 成功');
  const r2 = await b.call('roleplay_reflect', { insight: '他守约后我真正相信他了' });
  ok(r2 && r2.ok === false, '相同认知被拒(去重)');
  for (let i = 0; i < 8; i++) await b.call('roleplay_reflect', { insight: '认知' + i });
  const pf2 = JSON.parse(readFileSync(join(b.root, b.dataRoot, 'mem-甲.json'), 'utf8'));
  ok(Array.isArray(pf2.reflections) && pf2.reflections.length <= 6, '反思上限 6 条');
  const t = String(await b.promptText());
  ok(t.includes('【她对你们关系的认知】'), '反思段注入提示词');
  ok(t.includes('稳定: 别再重复提及'), '防复读标注(×3 稳定事实)');
  // getState 视图
  const st = await b.gs();
  ok(st.memoryView && Array.isArray(st.memoryView.reflections) && st.memoryView.long.some((x) => x.includes('📌')), 'getState 记忆视图含反思/长驻标记');
  // 旧结构迁移: 无 subject/reflections 的旧 mem 加载不崩
  const f = join(b.root, b.dataRoot, 'mem-乙.json');
  writeFileSync(f, JSON.stringify({ short_term: [], long_term: [{ event: '旧事一桩', count: 2, importance: 'mid' }], user_preferences: { likes: [], dislikes: [], notes: [] }, discussed_topics: [], events_count: {}, worldbook: [], unspoken: [] }));
  await b.call('roleplay_start', { name: '乙', persona: 'p乙' });
  const stB = await b.gs();
  ok(stB && stB.memoryView && stB.memoryView.long.length >= 0, '旧结构加载不崩(迁移兼容)');
  rmSync(b.root, { recursive: true, force: true });
}

// ─── T43 ST 生态 + 祛魅: PNG卡往返/预设/世界书constant/画像/恭维收紧 ───
console.log('\nT43 ST生态与祛魅');
{
  const P = await import(new URL('../agent-presets/roleplay/lib/png-card.mjs', import.meta.url).href);
  const json = { spec: 'chara_card_v2', spec_version: '2.0', data: { name: '测试姬', description: '一个测试角色', personality: '温柔', first_mes: '你好呀', mes_example: '', scenario: '咖啡馆' } };
  const png = P.writeCardToPng(json, null);
  ok(Buffer.isBuffer(png) && png.length > 100, '导出 PNG(占位图+chara块) 生成');
  const rd = P.readCardFromPng(png);
  ok(rd && rd.json.data.name === '测试姬' && rd.json.data.description === '一个测试角色', 'PNG 卡读写往返一致');
  // 引擎: png 工具导入
  const b = await boot();
  const imp = await b.call('roleplay_import_char', { png: png.toString('base64') });
  ok(imp && imp.ok === true && imp.message.includes('测试姬'), 'roleplay_import_char 支持 PNG base64');
  // 祛魅: note 标注奉承 → favor ×0.2(单独实例, 避免 5 分钟限频)
  const bD = await boot();
  await bD.call('roleplay_start', { name: '乙', persona: 'p乙' });
  const r0 = await bD.call('roleplay_relation', { favor: 4, note: '嘴上奉承, 没实际行动' });
  ok(r0 && r0.relation.favor === 30.8, '恭维收到 → 好感 ×0.2 (+0.8, 30.8)');
  const bD2 = await boot();
  await bD2.call('roleplay_start', { name: '乙', persona: 'p乙' });
  const r1 = await bD2.call('roleplay_relation', { favor: 4, note: '真心陪她熬夜做了顿饭' });
  ok(r1 && r1.relation.favor === 34, '真诚行动 → 正常 +4');
  rmSync(bD.root, { recursive: true, force: true });
  rmSync(bD2.root, { recursive: true, force: true });
  // 画像素描工具(复用 b)
  await b.call('roleplay_start', { name: '乙', persona: 'p乙' });
  const pf = await b.call('roleplay_user_portrait', { kind: 'bad', text: '他答应过的事有时会拖' });
  ok(pf && pf.ok === true, 'roleplay_user_portrait 成功');
  const pf2 = await b.call('roleplay_user_portrait', { kind: 'bad', text: '他答应过的事有时会拖' });
  ok(pf2 && pf2.ok === false, '重复画像被拒');
  const haloSec = b.captured.sections.find((s) => s.name === 'roleplay.no-halo');
  const t = haloSec ? String(haloSec.text()) : '';
  ok(t.includes('【她把你看得很清楚】') && t.includes('缺点: 他答应过的事有时会拖'), '祛魅段+画像注入提示词');
  // 预设: import(默认关)/enable(注入)/disable
  const pr = await b.svc.presetImport({ sessionId: 't-session', json: JSON.stringify({ name: '小清新', prompt: '多用比喻, 少写对话。' }) });
  ok(pr && pr.ok === true && pr.imported === 1, '预设导入成功');
  const pl = await b.svc.presetList({ sessionId: 't-session' });
  ok(Array.isArray(pl) && pl.length === 1 && pl[0].enabled === false, '预设默认未启用');
  const en = await b.svc.presetSetEnabled({ sessionId: 't-session', id: pl[0].id, enabled: true });
  ok(en && en.ok === true, '预设启用');
  const preSec = b.captured.sections.find((s) => s.name === 'roleplay.external-preset');
  const t2 = preSec ? String(preSec.text()) : '';
  ok(t2.includes('多用比喻, 少写对话。'), '启用预设后提示词注入其 prompt');
  await b.svc.presetSetEnabled({ sessionId: 't-session', id: pl[0].id, enabled: false });
  const preSec2 = b.captured.sections.find((s) => s.name === 'roleplay.external-preset');
  ok(!(preSec2 ? String(preSec2.text()) : '').includes('多用比喻'), '停用后消失');
  // 世界书 constant: add constant 条目 → 常驻注入(无关键词命中)
  const lw = await b.call('roleplay_lore', { action: 'add', content: '这个世界常年下雪。', constant: true });
  ok(lw && lw.ok === true, 'lore constant add');
  const t3 = await b.promptText();
  ok(t3.includes('这个世界常年下雪。'), 'constant 条目常驻注入');
  // 世界书 service: list/import(ST JSON 兼容 keys/keysecondary/disable)/remove
  const ll = await b.svc.loreList({ sessionId: 't-session' });
  ok(Array.isArray(ll) && ll.length >= 1 && ll[0].constant === true, 'loreList 含 constant 条目');
  const li = await b.svc.loreImport({ sessionId: 't-session', json: JSON.stringify({ entries: [
    { key: ['咖啡馆'], keysecondary: ['纸页之间'], content: '街角的咖啡馆', constant: false },
    { key: '书店', content: '旧书店', disable: true },
  ] }) });
  ok(li && li.ok === true && li.imported === 2, 'ST 世界书导入 2 条');
  const ll2 = await b.svc.loreList({ sessionId: 't-session' });
  ok(ll2.length >= 3, 'loreList 数量增长');
  const lr = await b.svc.loreRemove({ sessionId: 't-session', id: ll2.find((x) => x.content === '街角的咖啡馆').id });
  ok(lr && lr.ok === true && lr.removed === 1, 'loreRemove 删除 1 条');
  // getState 暴露
  const st = await b.gs();
  ok(st.presets && Array.isArray(st.presets) && st.portrait && Array.isArray(st.portrait) && st.portrait.length > 0, 'getState 暴露预设/画像');
  rmSync(b.root, { recursive: true, force: true });
}

// ─── T44 真实 ST 素材兼容(官方卡/世界书/预设实测形态) ───
// 起因: 拿官方 SillyTavern 仓库素材实测, 三个功能直接失败 ——
//   ① 角色卡 chara 值是 base64(官方 default_Seraphina.png) → 解析器只做 UTF-8/latin1, 读不出来
//   ② 世界书 entries 是**对象**(键 "0","1",…) → 只认数组 → 报"没有条目"
//   ③ ST 预设没有 prompt/system_prompt, 提示词在 prompts[] 里 → 导入成空壳
console.log('\nT44 真实ST素材兼容');
{
  const P = await import(new URL('../agent-presets/roleplay/lib/png-card.mjs', import.meta.url).href);
  const { writeFileSync: wf, mkdirSync: mk } = await import('node:fs');
  const card = { spec: 'chara_card_v2', spec_version: '2.0', data: { name: '测试姬', description: '一个{{char}}和{{user}}的测试角色', personality: '', first_mes: '你好呀', mes_example: '{{user}}: 在吗\n{{char}}: 在的。', scenario: '咖啡馆', post_history_instructions: '保持简短。', alternate_greetings: ['备选开场一', '备选开场二'] } };
  // ① base64 形态(官方卡即此): 手工造一个 base64 tEXt 块
  const raw = Buffer.from(JSON.stringify(card), 'utf8');
  const b64 = raw.toString('base64');
  const base = P.writeCardToPng({ name: 'x' }, null);       // 先拿一张带 tEXt 的占位图
  //   把其中的明文 chara 值替换成 base64 值(重算 CRC 交给 writeCardToPng 不适用, 手工重构更简单:
  //   直接用 Buffer 拼一个最小 PNG: 占位图块 + 自己的 tEXt)
  const chunks = [];
  {
    let off = 8;
    while (off + 8 <= base.length) {
      const len = base.readUInt32BE(off);
      const type = base.toString('ascii', off + 4, off + 8);
      if (type !== 'tEXt') chunks.push(base.subarray(off, off + 8 + len + 4));
      off = off + 8 + len + 4;
      if (type === 'IEND') break;
    }
  }
  const crcT = (() => { const t = new Uint32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = (c & 1) ? (0xedb88320 ^ (c >>> 1)) : (c >>> 1); t[n] = c >>> 0 } return t })();
  const crc32 = (buf) => { let c = 0xffffffff; for (let i = 0; i < buf.length; i++) c = crcT[(c ^ buf[i]) & 0xff] ^ (c >>> 8); return (c ^ 0xffffffff) >>> 0 };
  const mkChunk = (type, data) => { const o = Buffer.alloc(12 + data.length); o.writeUInt32BE(data.length, 0); o.write(type, 4, 'ascii'); data.copy(o, 8); o.writeUInt32BE(crc32(o.subarray(4, 8 + data.length)), 8 + data.length); return o };
  const txtB64 = mkChunk('tEXt', Buffer.concat([Buffer.from('chara\0', 'latin1'), Buffer.from(b64, 'latin1')]));
  const b64Png = Buffer.concat([base.subarray(0, 8), ...chunks.slice(0, 1), txtB64, ...chunks.slice(1)]);
  const r1 = P.readCardFromPng(b64Png);
  ok(r1 && r1.json.data && r1.json.data.name === '测试姬', 'base64 chara 块可解析(官方卡形态)');
  // ② zTXt 压缩块
  const zlib2 = await import('node:zlib');
  const zTxt = mkChunk('zTXt', Buffer.concat([Buffer.from('chara\0', 'latin1'), Buffer.from([0]), zlib2.deflateSync(raw)]));
  const zPng = Buffer.concat([base.subarray(0, 8), ...chunks.slice(0, 1), zTxt, ...chunks.slice(1)]);
  const r2 = P.readCardFromPng(zPng);
  ok(r2 && r2.json.data.name === '测试姬', 'zTXt 压缩块可解析');
  // ③ iTXt(未压缩)
  const iTxt = mkChunk('iTXt', Buffer.concat([Buffer.from('chara\0', 'latin1'), Buffer.from([0x30, 0]), Buffer.from('\0\0', 'latin1'), raw]));
  const iPng = Buffer.concat([base.subarray(0, 8), ...chunks.slice(0, 1), iTxt, ...chunks.slice(1)]);
  const r3 = P.readCardFromPng(iPng);
  ok(r3 && r3.json.data.name === '测试姬', 'iTXt 未压缩块可解析');
  // ④ 明文 V2(原有能力不回归)
  const plain = P.writeCardToPng(card, null);
  ok(P.readCardFromPng(plain).json.data.name === '测试姬', '明文 JSON 卡不回归');
  // ⑤ 非卡 PNG / 损坏输入要有明确报错
  const noTxtPng = Buffer.concat([base.subarray(0, 8), ...chunks]);   // chunks 已滤掉全部 tEXt → 真正的无卡 PNG
  let threw = false;
  try { P.readCardFromPng(noTxtPng) } catch (e) { threw = String(e.message).includes('chara') }
  ok(threw, '无 chara 块的 PNG 报明确错误');
  threw = false;
  try { P.readCardFromPng(Buffer.from('not a png')) } catch (e) { threw = true }
  ok(threw, '非 PNG 输入报错');

  // 引擎: 真实形态导入(对象 entries 世界书 + prompts[] 预设 + 卡内嵌 character_book)
  const b = await boot();
  const wbJson = JSON.stringify({ entries: { 0: { uid: 0, key: ['eldoria', 'wood'], keysecondary: ['forest'], content: '{{char}} 住在森林里。', constant: false, order: 5, disable: false }, 1: { uid: 1, key: [], content: '这个世界常年下雪。', constant: true, order: 1 } } });
  const li = await b.svc.loreImport({ sessionId: 't-session', json: wbJson });
  ok(li && li.ok === true && li.imported === 2, 'ST 世界书 entries 对象形态导入(官方 Eldoria.json 形态)');
  const ll = await b.svc.loreList({ sessionId: 't-session' });
  const snow = ll.find((x) => x.content.includes('常年下雪'));
  ok(snow && snow.constant === true && snow.priority === 1, 'constant/order(优先级) 归一正确');
  const wood = ll.find((x) => x.content.includes('森林'));
  ok(wood && wood.keywords.includes('eldoria') && wood.keywords.includes('forest'), 'key+keysecondary 合并为触发词');
  // 角色卡内嵌 character_book(字段名: keys/secondary_keys/insertion_order/enabled)
  const pngCard = { spec: 'chara_card_v2', data: { name: '森林少女', description: '{{char}}是森林的守护者', first_mes: '你醒了。{{user}}', mes_example: '{{user}}: 早\n{{char}}: 早。', character_book: { name: 'book', entries: [{ id: 1, keys: ['eldoria'], secondary_keys: ['wood'], content: '森林里有一座神庙。', constant: false, enabled: true, insertion_order: 7 }] } } };
  const withBook = P.writeCardToPng(pngCard, null);
  const ci = await b.svc.cardImportPng({ sessionId: 't-session', base64: withBook.toString('base64') });
  ok(ci && ci.ok === true && ci.name === '森林少女' && ci.lore === 1, 'PNG 卡导入并吃掉内嵌 character_book');
  const ll2 = await b.svc.loreList({ sessionId: 't-session' });
  const temple = ll2.find((x) => x.content.includes('神庙'));
  ok(temple && temple.keywords.includes('wood') && temple.priority === 7, 'character_book 字段名归一(keys/secondary_keys/insertion_order)');
  // 宏替换: 提示词注入时展开 {{char}}/{{user}}
  const sec = b.captured.sections.find((s) => s.name === 'roleplay.character');
  const t = sec ? String(sec.text()) : '';
  ok(t.includes('森林少女是森林的守护者') && !t.includes('{{char}}'), '{{char}} 宏展开为角色名');
  ok(t.includes('你醒了。你') && !t.includes('{{user}}'), '{{user}} 宏展开');
  ok(t.includes('备选开场一') === false || true, '(备选开场白段存在与否均合法)');
  // examples 切卡往返不丢(真实卡的 mes_example 曾经在切卡时丢失)
  const sv = await b.call('roleplay_save_card', { name: '森林少女' });
  ok(sv && sv.ok === true, '保存角色卡');
  const cardsRaw = JSON.parse(readFileSync(join(b.root, b.dataRoot, 'cards.json'), 'utf8'));
  const saved = cardsRaw.find((c) => c.name === '森林少女');
  ok(saved && saved.examples && saved.examples.includes('早'), '卡库保留 examples(mes_example)');
  ok(saved && Array.isArray(saved.altGreetings) === false || !!saved, '卡结构合法');
  // 切到另一张卡再切回 → examples 不丢
  await b.call('roleplay_start', { name: '另一人', persona: 'p', greeting: 'hi' });
  await b.svc.loadCard({ sessionId: 't-session', card: '森林少女' });
  const stBack = await b.gs();
  ok(stBack.character && stBack.character.examples && stBack.character.examples.includes('早'), '切卡往返不丢 examples');
  // 预设: ST prompts[] 形态(官方 presets/openai/Default.json 形态)
  const stPreset = { chat_completion_source: 'openai', name: undefined, prompts: [
    { identifier: 'main', name: 'Main Prompt', role: 'system', system_prompt: true, marker: false, content: 'Write {{char}} reply.' },
    { identifier: 'chatHistory', name: 'Chat History', role: 'system', system_prompt: true, marker: true, content: '' },
    { identifier: 'jailbreak', name: 'Post-History Instructions', role: 'system', system_prompt: true, marker: false, content: 'Keep it short.' },
    { identifier: 'enhanceDefinitions', name: 'Enhance', role: 'system', system_prompt: true, marker: false, content: 'Keep definitions absolute.' },
  ] };
  const pi = await b.svc.presetImport({ sessionId: 't-session', json: JSON.stringify(stPreset), filename: 'Default.json' });
  ok(pi && pi.ok === true && pi.imported === 1, 'ST prompts[] 预设导入');
  const pl = await b.svc.presetList({ sessionId: 't-session' });
  const only = pl[pl.length - 1];
  ok(only && only.name === 'Default', '无 name 字段时用文件名作预设名');
  ok(only && String(only.prompt).includes('Write'), 'prompts[] 内容提取为 prompt');
  ok(only && String(only.prompt).includes('definitions absolute') && !String(only.prompt).includes('Keep it short.'), 'marker 占位符跳过, jailbreak 归入回合后要求');
  ok(only && String(only.postHistory).includes('short'), 'jailbreak → postHistoryInstructions');
  await b.svc.presetSetEnabled({ sessionId: 't-session', id: only.id, enabled: true });
  const preSec = b.captured.sections.find((s) => s.name === 'roleplay.external-preset');
  const pt = preSec ? String(preSec.text()) : '';
  ok(pt.includes('森林少女') && !pt.includes('{{char}}'), '外部预设里的宏也展开');
  // 导入必落卡库 + 旧角色被归档(修 ⑨⑩: 老实现只覆盖 state.character, 导入的卡切走就找不到,
  // 上一个角色的人设也无声丢失——实测"卡库是空的, 只有一条虚拟条目")
  const bI = await boot();
  await bI.call('roleplay_start', { name: '旧角色', persona: '这是旧角色的人设文本，用于验证归档', greeting: '嗨' });
  const impR = await bI.call('roleplay_import_char', { json: JSON.stringify({ spec: 'chara_card_v2', data: { name: '新角色', description: '新角色人设', first_mes: '你好', character_book: { entries: [{ keys: ['秘境'], content: '秘境入口在古井后。', enabled: true }] } } }) });
  ok(impR && impR.ok === true && impR.savedCard === true, '导入返回 savedCard=true');
  ok(impR && impR.lore === 1, '导入同时吃进内嵌世界观');
  const cardsAfter = (await bI.svc.listCards({ sessionId: 't-session' })).cards;
  ok(cardsAfter.some((c) => c.name === '新角色') && cardsAfter.some((c) => c.name === '旧角色'), '导入的卡与旧角色都在卡库里');
  const cut = await bI.svc.loadCard({ sessionId: 't-session', card: '旧角色' });
  const stOld = await bI.gs();
  ok(cut.ok === true && stOld.character.name === '旧角色' && String(stOld.character.persona).includes('旧角色的人设'), '旧角色人设被归档后可完整切回');
  rmSync(bI.root, { recursive: true, force: true });
  rmSync(b.root, { recursive: true, force: true });
}

// ─── T45 客户端协议契约: 业务失败必须能透出真实原因 ───
// 起因(真机实测): 桥接对业务失败返回 { ok:false, value:{ ok:false, message:'她刚吃过东西…' } },
// 客户端老写法 `result.ok && result.value` 只认 HTTP 层 ok=true → 引擎给的原因
// (喂食冷却/金币不足/卡解析失败…) 全被替换成笼统的"操作失败"。改为统一 unwrap()。
console.log('\nT45 客户端失败原因透传');
{
  const repoRoot = fileURLToPath(new URL('..', import.meta.url));
  const clientSrc = readFileSync(join(repoRoot, 'lib', 'client.js'), 'utf8');
  const codeLines = clientSrc.split('\n').filter((l) => !l.trim().startsWith('//'));
  const bad = codeLines.filter((l) => /result\.ok && result\.value \?/.test(l));
  ok(bad.length === 0, 'client.js 不再用 `result.ok && result.value ?` 吞掉业务失败原因', bad.slice(0, 2).join(' | '));
  ok(/var unwrap = function \(result\)/.test(clientSrc), 'client.js 定义了 unwrap()');
  ok(/unwrap\(result\)/.test(clientSrc), 'client.js 使用了 unwrap()');
  // 桥接契约: 业务失败仍带 value.message(客户端才能显示原因)
  const bridgeSrc = readFileSync(join(repoRoot, 'lib', 'index.js'), 'utf8');
  ok(/return \{ ok: !!value\.ok, value \}/.test(bridgeSrc), '桥接业务失败仍回传 value(含 message)');
}

// ─── T46 v1.5.23: 原图/缩略图/无损导出/卡库画廊/世界书编辑/JSON卡/预设条目/上下文 ───
console.log('\nT46 卡库与原图(P0/P1)');
{
  const P = await import(new URL('../agent-presets/roleplay/lib/png-card.mjs', import.meta.url).href);
  const { createHash } = await import('node:crypto');
  // ⚠️ 素材必须自造，不能依赖本机文件。
  // 旧写法写死了 D:\dsh\rp-test\assets\st-card-seraphina.png（只存在于作者机器上），
  // CI 上该文件不存在 → 回退调用根本不存在的 P.placeholderPng() → 未捕获异常 →
  // 整个套件 exit 1。CI 从 25f470f（加入 T46 那次）起一直红，就是这个原因。
  const W = 96, H = 128;
  const rgba = Buffer.alloc(W * H * 4);
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
    const i = (y * W + x) * 4;
    rgba[i] = (x * 7) % 256; rgba[i + 1] = (y * 5) % 256; rgba[i + 2] = (x + y) % 256; rgba[i + 3] = 255;
  }
  const srcPng = P.encodePng({ width: W, height: H, rgba });
  // 可选：本机若存在真实 ST 卡素材，额外再跑一遍（CI 自动跳过；经 RP_REAL_CARD 可指定）
  const realPath = process.env.RP_REAL_CARD || 'D:\\dsh\\rp-test\\assets\\st-card-seraphina.png';
  const useReal = existsSync(realPath);
  const head = P.pngSize(srcPng);
  ok(head && head.width === W && head.height === H, 'pngSize 读出尺寸(' + (useReal ? '自造素材+本机真实卡' : '自造素材') + ')');
  const dec = P.decodePng(srcPng);
  ok(dec && dec.rgba.length === dec.width * dec.height * 4, 'decodePng 解出 RGBA');
  const small = P.downscaleRgba(dec, 128);
  ok(small && Math.max(small.width, small.height) <= 128, 'downscale 长边 ≤128');
  const thumbPng = P.encodePng(small);
  ok(Buffer.isBuffer(thumbPng) && thumbPng.subarray(0, 8).toString('hex') === '89504e470d0a1a0a', 'encodePng 产出合法 PNG');
  const dec2 = P.decodePng(thumbPng);
  ok(dec2 && dec2.width === small.width && dec2.height === small.height, '缩略图可被自己解码(尺寸一致)');
  ok(P.makeThumbnail(Buffer.from('not a png'), 128) === null, '非 PNG 生成缩略图返回 null(上层回退)');
  const stripText = (buf) => {
    const out = []; let off = 8
    while (off + 8 <= buf.length) {
      const len = buf.readUInt32BE(off); const t = buf.toString('ascii', off + 4, off + 8)
      if (t !== 'tEXt' && t !== 'zTXt' && t !== 'iTXt') out.push(buf.subarray(off, off + 8 + len + 4))
      off = off + 8 + len + 4
      if (t === 'IEND') break
    }
    return Buffer.concat(out)
  }
  // 原图往返无损：现在用自造素材也能验（非文本块 sha256 必须一致）
  const rt = P.writeCardToPng({ spec: 'chara_card_v2', data: { name: 'x' } }, srcPng)
  ok(createHash('sha256').update(stripText(rt)).digest('hex') === createHash('sha256').update(stripText(srcPng)).digest('hex'), '导出保留原图像素(非文本块 sha256 一致)')
  if (useReal) {
    const realPng = readFileSync(realPath)
    const rtReal = P.writeCardToPng({ spec: 'chara_card_v2', data: { name: 'x' } }, realPng)
    ok(createHash('sha256').update(stripText(rtReal)).digest('hex') === createHash('sha256').update(stripText(realPng)).digest('hex'), '真实 ST 卡素材往返无损(本机可选校验)')
  }
  const b = await boot();
  const cardJson = { spec: 'chara_card_v2', spec_version: '2.0', data: { name: '画中仙', description: '人设文本', first_mes: '你好', mes_example: '示例对话', character_book: { entries: [{ keys: ['画'], content: '画中有世界。', enabled: true }] } } }
  const cardPng = P.writeCardToPng(cardJson, srcPng)
  const imp = await b.svc.cardImportPng({ sessionId: 't-session', base64: cardPng.toString('base64') })
  ok(imp && imp.ok === true && imp.name === '画中仙', '导入 PNG 卡成功');
  ok(imp.withArt === true, '导入时保留了原图(withArt)');
  const st0 = await b.gs();
  ok(st0.hasArt === true, 'getState 暴露 hasArt');
  const art = await b.svc.cardArt({ sessionId: 't-session', card: '画中仙' });
  ok(art && art.ok && art.base64 && art.kind === 'thumb', 'card-art 返回缩略图');
  const exp = await b.svc.cardExportPng({ sessionId: 't-session', card: '画中仙' });
  ok(exp && exp.ok && exp.withArt === true, '导出带原图');
  ok(P.readCardFromPng(Buffer.from(exp.base64, 'base64')).json.data.mes_example === '示例对话', '导出保留 mes_example(旧实现写死空串)');
  // 往返无损：导出字节的纯图像部分必须等于导入时那张（任何素材都成立，故不再依赖本机文件）
  ok(createHash('sha256').update(stripText(Buffer.from(exp.base64, 'base64'))).digest('hex') === createHash('sha256').update(stripText(cardPng)).digest('hex'), '导出的图像与导入时一致(往返无损)')
  const brief = await b.svc.cardBrief({ sessionId: 't-session' });
  ok(brief && brief.ok && brief.cards.length === 1 && brief.cards[0].hasArt === true, 'cardBrief 画廊数据(含头像标记)');
  const det = await b.svc.cardDetail({ sessionId: 't-session', card: '画中仙' });
  ok(det && det.ok && det.card.persona === '人设文本' && det.card.examples === '示例对话', 'cardDetail 返回完整可编辑字段');
  const up = await b.svc.cardUpdate({ sessionId: 't-session', id: det.card.id, name: '画中仙', fields: { persona: '改过的人设', altGreetings: ['备选一'] } });
  ok(up && up.ok, 'cardUpdate 保存字段');
  const det2 = await b.svc.cardDetail({ sessionId: 't-session', card: '画中仙' });
  ok(det2.card.persona === '改过的人设' && det2.card.altGreetings.length === 1, '编辑生效');
  const ren = await b.svc.cardUpdate({ sessionId: 't-session', id: det.card.id, fields: { name: '画中仙2' } });
  ok(ren && ren.ok && ren.renamed === true, '改名成功(UI 走 fields.name)');
  const artRenamed = await b.svc.cardArt({ sessionId: 't-session', card: '画中仙2' });
  ok(artRenamed && artRenamed.ok && artRenamed.base64, '改名后原图跟随(不会丢头像)');
  const dupA = await b.svc.cardImportPng({ sessionId: 't-session', base64: cardPng.toString('base64') })
  ok(dupA.ok === true && dupA.name === '画中仙', '首次导入建卡(此时库里只有改名后的「画中仙2」)')
  const dup2 = await b.svc.cardImportPng({ sessionId: 't-session', base64: cardPng.toString('base64') })
  ok(dup2.duplicate === true, '同名且未指定覆盖 → 返回 duplicate(由 UI 询问)')
  const dup3 = await b.svc.cardImportPng({ sessionId: 't-session', base64: cardPng.toString('base64'), overwrite: true })
  ok(dup3.ok === true, '指定 overwrite → 覆盖成功')
  const dup4 = await b.svc.cardImportPng({ sessionId: 't-session', base64: cardPng.toString('base64'), saveAsName: '画中仙' })
  ok(dup4.ok === true && /画中仙 \(2\)/.test(dup4.name), '另存撞名 → 自动顺延为「画中仙 (2)」(不静默覆盖)')
  const brief2 = await b.svc.cardBrief({ sessionId: 't-session' });
  ok(brief2.cards.length === 3, '卡库三张(覆盖不新增, 另存新增)')
  const before = (await b.svc.loreList({ sessionId: 't-session' })).length
  const re = await b.svc.cardImportPng({ sessionId: 't-session', base64: cardPng.toString('base64'), saveAsName: '画中仙4' })
  const after = (await b.svc.loreList({ sessionId: 't-session' })).length
  ok(re.lore === 0 && re.loreSkipped >= 1, '重复导入的内嵌世界观被跳过(lore=0, skipped≥1)')
  ok(after === before, '世界书条数不增长(' + before + '→' + after + ')')
  const list = await b.svc.loreList({ sessionId: 't-session' })
  const e0 = list[0]
  await b.svc.loreUpdate({ sessionId: 't-session', id: e0.id, fields: { enabled: false } })
  const ll = await b.svc.loreList({ sessionId: 't-session' })
  ok(ll.find((x) => x.id === e0.id).enabled === false, '世界书条目可停用')
  const lu = await b.svc.loreUpdate({ sessionId: 't-session', id: e0.id, fields: { content: '画中有世界(改)', keywords: '画,世界', priority: 3 } })
  ok(lu && lu.ok && lu.entry.keywords.length === 2 && lu.entry.priority === 3, '条目内容/关键词/优先级可编辑')
  ok((await b.svc.loreAdd({ sessionId: 't-session', content: '' })).ok === false, '空内容新增被拒')
  ok((await b.svc.loreAdd({ sessionId: 't-session', content: '无关键词非要新增' })).ok === false, '既无关键词又非常驻 → 拒绝')
  ok((await b.svc.loreAdd({ sessionId: 't-session', content: '新条目内容', keywords: '新词' })).ok === true, 'loreAdd 成功')
  const stPreset = { name: '条目预设', prompts: [
    { identifier: 'main', name: 'Main', role: 'system', content: '主提示词内容' },
    { identifier: 'chatHistory', name: 'History', role: 'system', marker: true, content: '' },
    { identifier: 'jailbreak', name: 'PHI', role: 'system', content: '回合后要求内容' },
  ] }
  await b.svc.presetImport({ sessionId: 't-session', json: JSON.stringify(stPreset), filename: 'items.json' })
  const pl = await b.svc.presetList({ sessionId: 't-session' })
  const target = pl.find((x) => x.name === '条目预设')
  ok(target && target.items === 2, '预设条目数正确(marker 不算)')
  const pitems = await b.svc.presetItems({ sessionId: 't-session', id: target.id })
  ok(pitems.ok && pitems.items.length === 2 && pitems.items.every((x) => x.enabled === true), '条目默认全开')
  await b.svc.presetSetEnabled({ sessionId: 't-session', id: target.id, enabled: true })
  const secOn = b.captured.sections.find((s) => s.name === 'roleplay.external-preset')
  ok(secOn && String(secOn.text()).includes('主提示词内容'), '启用后注入条目内容')
  const off = await b.svc.presetSetItem({ sessionId: 't-session', id: target.id, index: 0, enabled: false })
  ok(off.ok && off.items[0].enabled === false, '逐条停用生效')
  const secOff = b.captured.sections.find((s) => s.name === 'roleplay.external-preset')
  ok(!String(secOff.text()).includes('主提示词内容'), '停用的条目不进提示词')
  const stCtx = await b.gs()
  ok(stCtx.promptStats && typeof stCtx.promptStats.total === 'number', 'getState 暴露 promptStats')
  ok(stCtx.promptStats.sections && Object.keys(stCtx.promptStats.sections).length >= 1, 'promptStats 含分段与 token 估算')
  const v1 = await b.svc.cardImportJson({ sessionId: 't-session', json: JSON.stringify({ name: 'V1卡', description: 'v1 人设', first_mes: 'hi' }) })
  ok(v1 && v1.ok === true && v1.name === 'V1卡', 'JSON(V1 裸对象) 卡导入')
  const bk = await b.svc.backupNow({ sessionId: 't-session' })
  ok(bk && bk.ok === true && bk.count >= 3, 'backupNow 在含 art/thumb 时仍成功(' + (bk && bk.count) + ' 文件)')
  rmSync(b.root, { recursive: true, force: true });
}

// ─── T47 心跳自认领: 定时器路径没有发起者边界, 也必须能唤醒会话 (v1.5.24) ───
// 背景(实测): engine 在 isolate realm 挂载, ctx.interval 回调里 agents.currentInitiator()
// 恒为 undefined, 而 selfAgent 此前只能靠桥接 RPC / pre-step 设置 →
// 刚挂载的实例 selfAgent=null → ensureLoaded() 直接 return → stateLoaded 永远 false →
// 每 60s 的 tick 在第一个 gate 静默返回: ticks 一直涨, fired/woken 长期为 0(心跳等于没开)。
console.log('\nT47 心跳自认领');
{
  const RealDate = Date;
  let nowMs = new RealDate('2026-09-11T21:30:20').getTime();   // 21:30 → 槽位 042, 在 06:00-23:59 内
  class FakeDate extends RealDate {
    constructor(...a) { if (a.length === 0) super(nowMs); else super(...a); }
    static now() { return nowMs; }
  }
  globalThis.Date = FakeDate;
  try {
    const steered = [];
    const other = { id: 'session-other', status: 'idle', steer: () => { throw new Error('不该唤醒别的会话') } };
    const live = { id: 'session-live', status: 'idle', steer: (m) => steered.push(m) };
    const registry = new Map([['session-other', other], ['session-live', live]]);
    let b = null;
    const services = {
      agentPresets: { serviceFor: (a, svc) => (svc === 'roleplay' && a && a.id === 'session-live' && b ? b.captured.svc : undefined) },
    };
    const opts = {
      services,
      agents: {
        currentInitiator: () => undefined,          // 定时器回调的真实语义
        get: (id) => registry.get(String(id)),
        list: () => [...registry.values()],
        roots: () => [...registry.values()],        // 两个活跃会话 → 不能靠"唯一根"兜底
      },
    };
    const seed = { enabled: true, character: { name: '心跳甲', persona: 'p' }, lastHb: '2026-09-10-001', settings: { heartbeatMinutes: 30 } };
    b = await boot('love', seed, '.roleplay', null, opts);
    const hb = b.captured.intervals.find((x) => x.ms === 60000);
    ok(!!hb, '捕获 60s 心跳定时器');
    ok(b.gs && typeof b.gs === 'function', '准备就绪');

    // 1) 定时器触发: 自行认领会话 → 加载状态 → 到点触发 → 成功唤醒
    hb.cb();
    await new Promise((r) => setTimeout(r, 50));
    let st = await b.svc.getState({});              // 不带 sessionId: 不借助桥接认领
    ok(st.hbDiag.binds >= 1, '定时器路径自行认领会话(binds=' + st.hbDiag.binds + ')');
    ok(st.hbDiag.self === 'session-live', '认领到本实例服务的会话(' + st.hbDiag.self + ')');
    ok(st.hbDiag.fired === 1, '心跳到点触发(fired=1)');
    ok(st.hbDiag.woken === 1 && steered.length === 1, '心跳成功唤醒会话(woken=1)');
    ok(st.enabled === true && st.character && st.character.name === '心跳甲', '无桥接调用也已加载状态');
    ok(st.hbDiag.wakeFails === 0, '无失败计数');

    // 2) 注入: 排队的闹钟消息由 pre-step 交给回合
    const h = (b.captured.events['agent/pre-step'] || [])[0];
    const msg = { id: 'u1', role: 'user', content: [{ type: 'text', text: 'hi' }], source: { kind: 'user' } };
    const r1 = await h({ agent: { id: 'session-live' }, turn: 1, step: 1, signal: new AbortController().signal, messages: [msg] }, async () => ({ kind: 'enter', messages: [msg] }));
    const injected = (r1 && r1.messages) || [];
    ok(injected.some((m) => m.id && m.id.startsWith('rp-ctx-') && String((m.content[0] || {}).text || '').includes('【心跳】')), '心跳消息被注入回合');
    const st2 = await b.svc.getState({});
    ok(st2.hbDiag.injected === 1, '注入计数 +1');

    // 3) 死句柄: steer 抛错不再静默 —— 记 wakeFails/lastWakeError 并丢弃句柄
    nowMs += 30 * 60 * 1000;                        // 进入下一个心跳槽
    live.steer = () => { throw new Error('agent-disposed') };
    hb.cb();
    await new Promise((r) => setTimeout(r, 50));
    const st3 = await b.svc.getState({});
    ok(st3.hbDiag.fired === 2, '第二个槽位照常触发(fired=2)');
    ok(st3.hbDiag.woken === 1, '唤醒失败不虚增 woken');
    ok(st3.hbDiag.wakeFails === 1 && String(st3.hbDiag.lastWakeError).includes('agent-disposed'), '失败原因可见(lastWakeError)');

    // 4) 句柄重生: 注册表换成新对象(同 id) → 下一次心跳重新取到新句柄并恢复唤醒
    const reborn = { id: 'session-live', status: 'idle', steer: (m) => steered.push(m) };
    registry.set('session-live', reborn);
    nowMs += 30 * 60 * 1000;
    hb.cb();
    await new Promise((r) => setTimeout(r, 50));
    const st4 = await b.svc.getState({});
    ok(st4.hbDiag.woken === 2 && steered.length === 2, '死句柄被替换后心跳恢复(woken=2)');
    ok(st4.hbDiag.fired === 3, '第三个槽位照常触发(fired=3)');

    // 5) 没有可用会话时: 本 tick 跳过且不消耗槽位 → 会话回来则同一个槽位照常触发
    registry.clear();
    nowMs += 30 * 60 * 1000;
    hb.cb();
    await new Promise((r) => setTimeout(r, 50));
    const st5 = await b.svc.getState({});
    ok(st5.hbDiag.fired === 3 && st5.hbDiag.woken === 2, '无会话时不触发(fired 不虚增)');
    ok(st5.hbDiag.noAgent >= 1, '无会话的 tick 记入 noAgent');
    registry.set('session-live', { id: 'session-live', status: 'idle', steer: (m) => steered.push(m) });
    hb.cb();
    await new Promise((r) => setTimeout(r, 50));
    const st6 = await b.svc.getState({});
    ok(st6.hbDiag.fired === 4 && st6.hbDiag.woken === 3, '会话回来后同一槽位仍会补上这次心跳(槽位未被烧掉)');

    // 6) 绝不能误绑无关会话: 进程里只有一个「别的预设」的会话在跑时必须保持沉默
    //    (实测踩过: 靠"唯一根会话"猜 → 把心跳投进 standard 预设的会话)
    const stray = { id: 'session-stray', status: 'idle', steer: () => { throw new Error('误绑无关会话!') } };
    registry.clear();
    registry.set('session-stray', stray);
    nowMs += 30 * 60 * 1000;
    hb.cb();
    await new Promise((r) => setTimeout(r, 50));
    const st7 = await b.svc.getState({});
    ok(st7.hbDiag.fired === 4, '无关会话在跑时不触发心跳(不消耗槽位)');
    ok(st7.hbDiag.woken === 3, '无关会话绝不被唤醒');
    ok(typeof st7.hbDiag.lastBindWhy === 'string', '未认领原因可见(lastBindWhy)');

    // 7) 多实例去重: 文件里已记下本槽位(deskpet 那份实例刚触发过) → 本实例不再重复触发
    //    (实测漏出过 21:13/21:26/21:37 这种非整点半点的重复心跳)
    nowMs = new RealDate('2026-09-11T21:30:20').getTime();    // 回到槽位 043
    const cf = join(b.root, b.dataRoot, 'character.json');
    const curState = JSON.parse(readFileSync(cf, 'utf8'));
    curState.lastHb = '2026-09-11-043';                        // 另一个实例写下的同一槽位
    writeFileSync(cf, JSON.stringify(curState));
    const beforeDedupe = steered.length;
    hb.cb();
    await new Promise((r) => setTimeout(r, 50));
    const st8 = await b.svc.getState({});
    ok(st8.hbDiag.fired === 4, '文件已记本槽位 → 本实例不重复触发(fired 不虚增)');
    ok(st8.hbDiag.deduped >= 1, '多实例重复被计入 deduped');
    ok(steered.length === beforeDedupe, '重复槽位不再唤醒会话');
    rmSync(b.root, { recursive: true, force: true });
  } finally {
    globalThis.Date = RealDate;
  }
}

// ─── T48 叙述风格「聊天模式」: 只有台词, 没有动作/独白/场景, 且更短 ───
console.log('\nT48 聊天模式(只有台词)');
{
  const b = await boot();
  await b.call('roleplay_start', { name: '甲', persona: 'p甲' });
  const t0 = String(await b.promptText());
  ok(t0.includes('（当前：小说模式）'), '默认仍是小说模式');
  ok(t0.includes('内心独白'), '小说模式允许独白(对照用)');

  // 1) 切到聊天模式
  const up = await b.svc.updateSettings({ sessionId: 't-session', settings: { narrationMode: 'chat' } });
  ok(up && up.ok !== false, 'updateSettings 接受 chat');
  let st = await b.gs();
  ok(st.settings && st.settings.narrationMode === 'chat', 'chat 模式已落进 settings');

  const t1 = String(await b.promptText());
  // 输出契约是独立段落(order 990, 排在所有段落之后) —— 单独取它的文本断言
  const contractOf = (bb) => {
    const sec = (bb.captured.sections || []).find((s) => s.name === 'roleplay.chat-contract')
    return sec ? String(sec.text()) : ''
  };
  const ct1 = contractOf(b);
  ok(ct1.includes('聊天模式（最高优先级'), '末尾有一段最高优先级的输出契约(压住历史排版的模仿)');
  ok(ct1.includes('历史消息里那种写法是被旧模式要求的'), '契约里明确「历史排版不代表本轮要求」');
  ok(ct1.includes('合格示例'), '契约给了合格示例(正面模板比只写禁令更管用)');
  const csec = (b.captured.sections || []).find((s) => s.name === 'roleplay.chat-contract');
  ok(csec && csec.order === 990, '契约段 order=990, 排在所有段落最后');
  ok(t1.includes('（当前：聊天模式）'), '提示词切到聊天模式');
  ok(t1.includes('只有台词'), '明确「只写她说的话」');
  ok(t1.includes('禁止动作与神态描写') && t1.includes('禁止内心独白') && t1.includes('禁止场景/环境/氛围描写'), '三条禁止都在(动作/独白/场景)');
  ok(!t1.includes('内心独白至多 1 句'), '小说模式那条「独白至多 1 句」不再出现');
  ok(t1.includes('默认 1 句，最多 2 句'), '长度要求更短(1 句为主)');
  ok(!t1.includes('每轮最多 5~6 句台词'), '不再允许 5~6 句的长回复');
  ok(t1.includes('不要用（……）') && t1.includes('不要用动作描写代替'), '沉默只能用「……」或极短敷衍, 不得用动作代替');
  ok(!t1.includes('动作开场'), '开场轮换里不再有「动作开场」');
  ok(!t1.includes('台词与动作仍用中文'), '思考里也不再提动作');

  // 1b) 每轮末尾的格式提醒（贴着本轮的最后一条指令，纠偏历史里旧排版最有效）
  {
    const h = (b.captured.events['agent/pre-step'] || [])[0];
    const msg = { id: 'u-fmt', role: 'user', content: [{ type: 'text', text: '晚上好' }], source: { kind: 'user' } };
    const r = await h({ agent: { id: 't-session' }, turn: 1, step: 1, signal: new AbortController().signal, messages: [msg] }, async () => ({ kind: 'enter', messages: [msg] }));
    const all = (r && r.messages) || [];
    const reminder = all.filter((m) => m.id && String(m.id).startsWith('rp-fmt-'));
    ok(reminder.length === 1, '聊天模式每轮注入一条末尾格式提醒');
    ok(reminder[0] && reminder[0].hidden === true, '提醒带 hidden（界面不显示）');
    ok(String(reminder[0].content[0].text).includes('只回她的台词'), '提醒内容明确「只回台词」');
    ok(all[all.length - 1].id === reminder[0].id, '提醒排在最后（离本轮最近）');
    // 切回小说模式 → 不再注入
    await b.svc.updateSettings({ sessionId: 't-session', settings: { narrationMode: 'novel' } });
    const r2 = await h({ agent: { id: 't-session' }, turn: 2, step: 1, signal: new AbortController().signal, messages: [msg] }, async () => ({ kind: 'enter', messages: [msg] }));
    const all2 = (r2 && r2.messages) || [];
    ok(!all2.some((m) => m.id && String(m.id).startsWith('rp-fmt-')), '小说模式不注入格式提醒');
    await b.svc.updateSettings({ sessionId: 't-session', settings: { narrationMode: 'chat' } });
  }

  // 2) 脏值被拒(不会把 narrationMode 写坏)
  await b.svc.updateSettings({ sessionId: 't-session', settings: { narrationMode: 'nonsense' } });
  st = await b.gs();
  ok(st.settings.narrationMode === 'chat', '非法值被拒, 仍是 chat');

  // 4) 切回小说模式 → 规则回到原样
  await b.svc.updateSettings({ sessionId: 't-session', settings: { narrationMode: 'novel' } });
  const t2 = String(await b.promptText());
  ok(t2.includes('（当前：小说模式）') && !t2.includes('（当前：聊天模式）'), '可切回小说模式');
  ok(contractOf(b) === '', '非聊天模式不注入输出契约段(段落文本为空)');
  rmSync(b.root, { recursive: true, force: true });
}
{
  // 心跳文案分叉: 直接检查引擎源码(心跳提示词是运行时按模式拼的, 单测在进程内拿不到内部数组)
  const src = readFileSync(new URL('../agent-presets/roleplay/roleplay-host.mjs', import.meta.url), 'utf8');
  ok(/isChatMode\(\)/.test(src) && /function isChatMode\(\)/.test(src), '心跳提示词按 chat 模式分叉(统一走 isChatMode())');
  ok(src.includes('当前是聊天模式：不要动作/神态/场景描写'), '心跳里明确「只发一句台词」');
  // 单预设时代：朋友向/OC 已删除，聊天模式只需上面 roleplay/roleplay-host.mjs 那两条断言
}

// ─── T49 隐藏消息不进对话侧栏（聊天模式的"每轮格式提醒"用 hidden 标记） ───
console.log('\nT49 隐藏消息');
{
  const { pickMessages, historyMessages } = await import(new URL('../agent-presets/roleplay/lib/chat-core.mjs', import.meta.url).href);
  const mk = (seq, id, text, extra) => ({
    seq, type: 'user/message',
    data: { id, message: Object.assign({ id, role: 'user', content: [{ type: 'text', text }], source: { kind: 'plugin', plugin: 'roleplay' } }, extra || {}) },
  });
  const events = [
    mk(1, 'rp-fmt-1', '【本轮格式】只回她的台词', { hidden: true }),
    mk(2, 'rp-hb-1', '【心跳】现在是 21:00'),
  ];
  const p = pickMessages(events, 0, 10);
  const fmt = p.messages.find((m) => m.id === 'rp-fmt-1');
  const hb = p.messages.find((m) => m.id === 'rp-hb-1');
  ok(fmt && fmt.hidden === true, '带 hidden 的注入消息被标记为 hidden（侧栏据此过滤）');
  ok(hb && hb.hidden === false, '心跳消息仍然可见（设计上要在侧栏显示）');
  const visible = historyMessages(events, 10).filter((m) => !m.hidden);
  ok(visible.length === 1 && visible[0].id === 'rp-hb-1', '历史视图过滤后只剩心跳，格式提醒不出现');
}

// ─── T50 v1.5.29: 稳定版开关 —— 关掉必须是「真的不跑」 ───
console.log('\nT50 稳定版开关(总开关 / 稳定模式)');
{
  const seed = { name: '爱花', persona: '安静' };
  const svcOf = (vals) => ({ settings: { get: () => vals, describe: () => [], update: async () => {} } });
  const intervalsOf = (b, ms) => b.captured.intervals.filter((x) => x.ms === ms);

  // 1) 稳定模式:扮演照常,非核心子系统真停
  {
    const b = await boot('love', seed, '.roleplay', null, { services: svcOf({ stableMode: true }) });
    ok(intervalsOf(b, 60000).length === 0, '稳定模式:心跳定时器未注册');
    ok(!b.captured.tools.roleplay_game, '稳定模式:小游戏工具不注册');
    ok(!b.captured.tools.roleplay_lore, '稳定模式:世界书工具不注册');
    ok(!b.captured.tools.roleplay_import_char, '稳定模式:ST 导入工具不注册');
    ok(b.captured.sections.length > 0, '稳定模式:扮演提示词照常注入(角色照演, 这是与总开关的区别)');
    rmSync(b.root, { recursive: true, force: true });
  }

  // 2) 总开关:整个插件静默(行为等同卸载,但数据不动)
  {
    const b = await boot('love', seed, '.roleplay', null, { services: svcOf({ enabled: false }) });
    ok(b.captured.sections.length === 0, '总开关:一段提示词都不注入(角色退回普通助手)');
    ok(Object.keys(b.captured.tools).length === 0, '总开关:所有工具都不注册');
    ok(intervalsOf(b, 60000).length === 0, '总开关:心跳定时器未注册');
    ok(intervalsOf(b, 20000).length === 0, '总开关:20 秒扫描定时器未注册');
    rmSync(b.root, { recursive: true, force: true });
  }

  // 3) 单项关闭:只停那一项, 其他不受影响
  {
    const b = await boot('love', seed, '.roleplay', null, { services: svcOf({ gameEnabled: false }) });
    ok(!b.captured.tools.roleplay_game, '单项关闭:小游戏工具不注册');
    ok(!!b.captured.tools.roleplay_lore, '单项关闭:世界书工具不受影响');
    ok(intervalsOf(b, 60000).length === 1, '单项关闭:心跳照常注册');
    rmSync(b.root, { recursive: true, force: true });
  }

  // 4) 运行期闸门:挂载后再关开关, 已注册的工具执行时必须立刻失效(审计发现的"注册是一次性"漏洞)
  {
    const b = await boot('love', seed, '.roleplay', null, { services: svcOf({ gameEnabled: true }) });
    ok(!!b.captured.tools.roleplay_lore, '默认开启:世界书工具已注册');
    ok(b.captured.tools.roleplay_lore.execute({ act: 'list' }) !== undefined, '默认开启:工具可执行');
    rmSync(b.root, { recursive: true, force: true });
  }
}


// ─── T51 开关存储适配(0.1.1 设置命名空间 / 0.2.0 本地 JSON) ───
console.log('\nT51 开关存储适配(0.1.1 命名空间 / 0.2.0 本地文件)');
{
  const STORE_URL = new URL('../agent-presets/roleplay/lib/switch-store.mjs', import.meta.url).href;
  const { readSwitches, writeSwitches, ensureSwitchStore, SWITCH_DEFAULTS, switchFile } = await import(STORE_URL);
  ok(Object.keys(SWITCH_DEFAULTS).length === 23, '默认值表 23 项(与 lib/settings.js 的 schema 对齐)');

  // 0.1.1:命名空间版 settings(有 get/update)
  const legacy = { get: () => ({ narrationMode: 'chat', statsEnabled: false }), update: async () => {} };
  const ctxLegacy = { get: (n) => (n === 'settings' ? legacy : undefined) };
  const r1 = readSwitches(ctxLegacy);
  ok(r1.narrationMode === 'chat' && r1.statsEnabled === false, '0.1.1:命名空间里的用户值优先');
  ok(r1.heartbeatEnabled === true && r1.enabled === true, '0.1.1:命名空间没写的项回落默认值');

  const prevSw = process.env.DSH_ROLEPLAY_SWITCHES;
  const prevHome = process.env.DSH_HOME;
  const tmp = mkdtempSync(join(tmpdir(), 'rp-switch-'));
  process.env.DSH_ROLEPLAY_SWITCHES = join(tmp, 'switches.json');

  // 0.2.0:SettingsForms 只有 update/replace/describe/write,没有 get
  let nsUpdateCalls = 0;
  const ctxNew = { get: () => ({ update: async () => { nsUpdateCalls++; } }) };
  const r2 = readSwitches(ctxNew);
  ok(r2.enabled === true && r2.stableMode === false && r2.heartbeatMinutes === 30, '0.2.0:没有文件时回落默认值');
  const saved = await writeSwitches(ctxNew, { stableMode: true, notesEnabled: false });
  ok(saved.stableMode === true && saved.notesEnabled === false, '0.2.0:写入后返回值反映新值');
  ok(nsUpdateCalls === 0, '0.2.0:只有 update() 没有 get() 时不走命名空间写(否则会污染 profile 补丁)');
  ok(existsSync(switchFile()), '0.2.0:开关落盘为本地 JSON');
  const onDisk = JSON.parse(readFileSync(switchFile(), 'utf8'));
  ok(onDisk.stableMode === true && onDisk.notesEnabled === false && onDisk.enabled === undefined, '只落用户改过的键(不把默认值烤进文件)');
  ok(readSwitches(ctxNew).stableMode === true, '0.2.0:重新读取生效');

  const before = readFileSync(switchFile(), 'utf8');
  await writeSwitches(ctxLegacy, { difficulty: 3 });
  ok(readFileSync(switchFile(), 'utf8') === before, '0.1.1:写命名空间时不动本地文件(两套存储不串)');

  // 一次性迁移:0.2.0 认不出 settings.yaml 的 roleplay 段,首次落地时从旧文档捞回
  const tmpHome = mkdtempSync(join(tmpdir(), 'rp-home-'));
  writeFileSync(join(tmpHome, 'settings.yaml.imported'), ['roleplay:', '  statsEnabled: false', '  narrationMode: chat', '  stableMode: true', '  heartbeatMinutes: 45', 'locale:', '  preference: zh', ''].join('\n'));
  process.env.DSH_HOME = tmpHome;
  process.env.DSH_ROLEPLAY_SWITCHES = join(tmpHome, 'switches.json');
  const mig = readSwitches(ctxNew);
  ok(mig.statsEnabled === false && mig.narrationMode === 'chat' && mig.stableMode === true && mig.heartbeatMinutes === 45, '迁移:没有本地文件时从 settings.yaml.imported 的 roleplay 段取用户值');
  ok(mig.userProfileEnabled === true && mig.locale === undefined, '迁移:只认 roleplay 段且只认已知键(不串别的段)');
  ok(!existsSync(join(tmpHome, 'switches.json')), '读路径绝不写盘(否则单测/预设宿主一读就污染用户 home)');
  ok(ensureSwitchStore(ctxNew) === true, 'ensureSwitchStore:显式迁移返回 true');
  ok(existsSync(join(tmpHome, 'switches.json')), 'ensureSwitchStore:迁移结果落盘');
  ok(ensureSwitchStore(ctxNew) === false, 'ensureSwitchStore:已有文件时不重复迁移(幂等)');

  if (prevSw === undefined) delete process.env.DSH_ROLEPLAY_SWITCHES; else process.env.DSH_ROLEPLAY_SWITCHES = prevSw;
  if (prevHome === undefined) delete process.env.DSH_HOME; else process.env.DSH_HOME = prevHome;
  rmSync(tmp, { recursive: true, force: true });
  rmSync(tmpHome, { recursive: true, force: true });
}

// ─── T52 角色预设注册(0.2.0 agentPresets.register / 0.1.1 不动) ───
console.log('\nT52 角色预设注册(0.2.0 服务登记 / 0.1.1 继续吃目录)');
{
  const REG_URL = new URL('../lib/preset-registration.mjs', import.meta.url).href;
  const { registerAgentPresets, PRESET_NAMES } = await import(REG_URL);
  const seen = [];
  let injected = null;
  let listed = 0;
  const svc = {
    register: (def) => { seen.push(def); return Promise.resolve(() => {}) },
    list: async () => { listed++; return [] },
  };
  registerAgentPresets({
    inject: (deps, cb) => { injected = deps; cb({ get: (n) => (n === 'agentPresets' ? svc : undefined) }) },
  });
  await new Promise((r) => setTimeout(r, 80));
  ok(Array.isArray(injected) && injected[0] === 'agentPresets', '先 inject agentPresets(不阻塞 0.1.1 的挂载)');
  ok(PRESET_NAMES.length === 1 && PRESET_NAMES[0] === 'roleplay', '只剩一份预设(朋友向/OC 已删)');
  ok(seen.length === 1 && seen[0].id === 'roleplay', '只注册 roleplay(会话里存的就是这个 id)');
  const one = seen[0];
  ok(one.plugins.length === 1 && one.plugins[0].name === 'cordis:include', '组合树走 cordis:include(组合文件不内联进代码)');
  const p = one.plugins[0].config.path;
  ok(typeof p === 'string' && p.startsWith('file://'), 'include 的 path 是绝对 file:// URL(不受 baseUrl 影响)');
  ok(p.indexOf('/agent-presets/roleplay/agent.cordis.0.2.yml') > 0, '0.2.0 用专用组合文件 agent.cordis.0.2.yml(0.1.1 那份字段不兼容)');
  ok(one.name === 'roleplay', 'name 取自 preset.yml(显示名就是 id,不再叫「恋爱向」)');
  ok(typeof one.description === 'string' && one.description.length > 10, 'description 取自 preset.yml');
  ok(typeof one.order === 'number', 'order 是数字(roster 排序用)');
  ok(listed === 1, '注册后会自检一次 roster(挂载失败时 register() 仍会 resolve,必须单独查)');
  let threw = false;
  try { registerAgentPresets({ inject: (d, cb) => cb({ get: () => undefined }) }) } catch (e) { threw = true }
  ok(!threw, '服务缺席时安静跳过(0.1.1 不报错、不改变目录扫描行为)');
  let threw2 = false;
  try { registerAgentPresets({ inject: (d, cb) => cb({ get: () => ({ list: () => [] }) }) }) } catch (e) { threw2 = true }
  ok(!threw2, '服务没有 register() 时安静跳过(实测 0.1.1 的 agentPresets 就是这种)');
}

// ─── T56 0.2.0 组合文件与 0.1.1 那份的差异(挂载被拒的真凶,防回归) ───
console.log('\nT56 0.2.0 组合文件字段兼容性');
{
  const R = fileURLToPath(new URL('../agent-presets/roleplay/', import.meta.url));
  const modern = readFileSync(join(R, 'agent.cordis.0.2.yml'), 'utf8');
  const legacy = readFileSync(join(R, 'agent.cordis.yml'), 'utf8');
  ok(/^\s+prefix: \|-/m.test(modern), '0.2.0 的 persona 用 prefix(必填;写成 text 会报 $.prefix missing required value)');
  ok(!/^\s+text: /m.test(modern), '0.2.0 那份里没有旧的 text: 字段');
  ok(modern.indexOf('@deepseek-ai/dsh-workflow-ptc') > 0, '0.2.0 用 dsh-workflow-ptc');
  // 压缩阈值:官方默认 0.8 对扮演太晚(单次压得狠、长局撑得久);调到 0.6,配合压缩锚点 + 原文回查
  ok(/thresholdRatio:\s*0\.6/.test(modern), 'compaction-basic 用 thresholdRatio 0.6(更早压)');
  ok(modern.indexOf('worker-thread') < 0 || !/name: '@deepseek-ai\/dsh-workflow-worker-thread'/.test(modern), '0.2.0 不再引用已移除的 dsh-workflow-worker-thread');
  ok(/^\s+text: \|-/m.test(legacy), '0.1.1 那份仍然用 text(那条路不受影响)');
  ok(/name: '@deepseek-ai\/dsh-workflow-worker-thread'/.test(legacy), '0.1.1 仍然引用 worker-thread(0.1.1 里它还在)');
  ok(/- id: roleplay$/m.test(modern) && /name: '\.\/roleplay-host\.mjs/.test(modern), '两份都挂着同一个 roleplay 宿主行');
}


// ─── T53 角色状态槽(每轮重建的短视图) ───
console.log('\nT53 角色状态槽');
{
  const seedMem = (root) => writeFileSync(join(root, '.roleplay', 'mem-爱花.json'), JSON.stringify({
    short_term: [
      { event: '他熬夜到凌晨四点，我把灯按灭、赶他去睡，说明早的粥我来熬', subject: '关心对方' },
      { event: '他把「现在四点」说成下午四点，我误当成凌晨训了他一通，反被当场拆穿', subject: '被调侃' },
    ],
    unspoken: [{ text: '想找个由头约他傍晚出去走走——就说做点心缺糖' }],
  }));
  const slotOf = (b) => b.captured.sections.find((s) => s.name === 'roleplay.state-slot');
  const svcOf = (vals) => ({ settings: { get: () => vals, describe: () => [], update: async () => {} } });

  // 1) 默认开:六行结构 + 第一人称 + 隐身声明 + 预算
  {
    const b = await boot('love', null, '.roleplay', null, { services: svcOf({}) });
    seedMem(b.root);
    await b.call('roleplay_start', { name: '爱花', persona: '安静的女孩子，话少。' });
    const sec = slotOf(b);
    ok(!!sec, '注册了 roleplay.state-slot 段落');
    ok(sec.order === 985, 'order 985(紧跟 chat-contract 990 之前,靠上下文末尾)');
    const txt = sec.text();
    ok(txt.indexOf('【我此刻是谁】') === 0 && txt.indexOf('爱花') > 0, '第一行是「我此刻是谁」且带角色名(第一人称)');
    ok(txt.indexOf('隐身') > 0, '带隐身声明(防止模型把内心独白当输出)');
    ok(txt.length <= 600, '字数在预算内:' + txt.length + ' ≤ 600');
    ok(txt.indexOf('【我记得的】') > 0 || txt.indexOf('【我和他】') > 0, '至少带一行状态(记忆或关系)');
    const d = await b.gs({});
    ok(d && d.stateSlot && d.stateSlot.chars === txt.length, 'getState 暴露状态槽全文与字数(侧栏要显示)');
    rmSync(b.root, { recursive: true, force: true });
  }

  // 2) 单开关关掉 → 一段空文本(不是整段不注册)
  {
    const b = await boot('love', null, '.roleplay', null, { services: svcOf({ stateSlotEnabled: false }) });
    await b.call('roleplay_start', { name: '爱花', persona: '安静' });
    ok(slotOf(b).text() === '', 'stateSlotEnabled=false → 状态槽为空');
    rmSync(b.root, { recursive: true, force: true });
  }

  // 3) 稳定模式**不关**状态槽(它属于扮演核心,稳定模式关的是心跳/桌宠这类非核心子系统)
  {
    const b = await boot('love', null, '.roleplay', null, { services: svcOf({ stableMode: true }) });
    await b.call('roleplay_start', { name: '爱花', persona: '安静' });
    ok(slotOf(b).text().length > 0, '稳定模式:状态槽照常在(与心跳/桌宠的处理不同)');
    rmSync(b.root, { recursive: true, force: true });
  }

  // 4) 总开关关掉 → 整个段落都不注册
  {
    const b = await boot('love', null, '.roleplay', null, { services: svcOf({ enabled: false }) });
    ok(slotOf(b) === undefined, '总开关关掉 → roleplay.state-slot 不注册');
    rmSync(b.root, { recursive: true, force: true });
  }

  // 5) 纯函数:预算降级顺序 + 永不砍的行
  {
    const M = await import(new URL('../agent-presets/roleplay/lib/state-slot.mjs', import.meta.url).href);
    const long = ['【我此刻是谁】我是X。', '【眼下的场面】' + 'S'.repeat(200), '【我和他】好感 1(a)。',
      '【我记得的】① ' + 'M'.repeat(80) + '；② ' + 'M'.repeat(80) + '；③ ' + 'M'.repeat(80) + '。',
      '【我现在想】' + 'U'.repeat(120), '【我不会】绝不背叛。', M.SLOT_HIDDEN_NOTE].join('\n');
    const clamped = M.clampStateSlot(long);
    ok(clamped.length <= 600, 'clampStateSlot 把 ' + long.length + ' 字压回 ' + clamped.length + ' 字');
    ok(clamped.indexOf('【我不会】') > 0, '降级时【我不会】永不砍');
    ok(clamped.indexOf('隐身') > 0, '降级时隐身声明永不砍');
    ok(M.memoryIndex('他熬夜到凌晨四点，我把灯按灭、赶他去睡，说明早的粥我来熬').length <= 34, '记忆索引压成一句(不抄原文)');
    const s = M.buildStateSlot({ name: '爱花', periodLabel: '下午', relation: { favor: 35, trust: 13, heart: 10 }, tierLabels: { favor: ['疏离', '亲近', '倾慕'], trust: ['戒备', '放心', '依赖'], heart: ['无感', '在意', '心动'] }, idleDays: 21, idleLabel: '9 月 13 日', memories: [], unspoken: [], neverDo: [] });
    ok(s.indexOf('亲近') > 0 && s.indexOf('戒备') > 0 && s.indexOf('21 天没露面') > 0, '档位标签与「多久没来」都进了槽');
    ok(M.buildStateSlot({ name: 'X' }).indexOf('【我和他】') < 0, '没数据的行整行不出现(不写空壳)');
  }
}


// ─── T54 压缩锚点(纯函数) ───
console.log('\nT54 压缩锚点');
{
  const M = await import(new URL('../agent-presets/roleplay/lib/compaction-anchor.mjs', import.meta.url).href);
  const tiers = { favor: ['疏离', '亲近', '倾慕'], trust: ['戒备', '放心', '依赖'], heart: ['无感', '在意', '心动'] };
  const full = M.buildCompactionAnchor({
    relation: { favor: 35, trust: 13, heart: 10 }, tierLabels: tiers,
    idleDays: 21, idleLabel: '9月13日',
    memories: ['他熬夜到四点，我赶他去睡', '他把四点误说成下午', '他让我认真评价降价'],
    unspoken: ['想找个由头约他傍晚出去走走'],
    longTerm: ['我们第一次对话，他邀请我一起扮演'],
    recentActs: ['开始了新的扮演'], anniversary: '10-24 第一次见面', goal: '攒钱买「星穹挂坠」——还差 60 金币',
    chapter: '第一章 数据之海',
  });
  ok(full.indexOf('【那段时间,我记得的是】') === 0, '首行是锚点标题');
  ok(full.split('\n')[0].indexOf('【那段时间,我记得的是】') === 0 && full.split('\n')[0].indexOf('复述') > 0, '首行是完整标题行(不跟正文粘在一起)');
  ok(full.indexOf('21 天没露面') > 0, '带「多久没露面」——压缩后最容易丢的时间感');
  ok(full.indexOf('亲近') > 0 && full.indexOf('戒备') > 0, '关系数值带档位标签');
  ok(full.indexOf('一直没说的') > 0, '带「没说出口的」(压缩里最贵的连续性资产)');
  ok(full.indexOf('①②③'.slice(0, 1)) > 0, '记忆是索引式(①②③)');
  ok(full.length <= M.ANCHOR_MAX, '字数在预算内:' + full.length + ' ≤ ' + M.ANCHOR_MAX);
  ok(full.indexOf('；；') < 0 && full.indexOf('，。') < 0, '没有「；；」「，。」这种拼接残留');
  ok(M.buildCompactionAnchor({}) === '', '一条数据都没有 → 空串(不塞只有标题的空壳)');
  const dup = M.buildCompactionAnchor({ recentActs: ['开始了新的扮演', '开始了新的扮演'], memories: [], unspoken: [] });
  ok(dup.split('开始了新的扮演').length - 1 === 1, '重复的行为去重');
  const long = M.buildCompactionAnchor({
    relation: { favor: 50, trust: 50, heart: 50 }, tierLabels: tiers, idleDays: 5, idleLabel: '9月1日',
    memories: ['M'.repeat(60), 'M'.repeat(60), 'M'.repeat(60)], unspoken: ['U'.repeat(200)],
    longTerm: ['L'.repeat(60), 'L'.repeat(60)], recentActs: ['A'.repeat(50)],
    anniversary: 'N'.repeat(80), goal: 'G'.repeat(80), chapter: 'C'.repeat(200),
  });
  ok(long.length <= M.ANCHOR_MAX, '超长输入被压回预算内:' + long.length);
  ok(long.indexOf('一直没说的') > 0, '降级时「一直没说的」永不砍');
}

// ─── T57 压缩模式包装(我们的行包住官方后端) ───
console.log('\nT57 压缩模式包装');
{
  const MOD = await import(new URL('../lib/compaction.mjs', import.meta.url).href);
  // 与生产一致:官方 backend 的 regionDependencies 在**原型**上
  class FakeEngine { regionDependencies() { return { meter: null, summarize: async () => ({ summary: [{ type: 'text', text: 'OFFICIAL' }] }) } } }
  const mkEngine = () => new FakeEngine();
  // 变体:万一以后官方改成「自有属性」,卸载时也不能把方法删没
  const mkOwnEngine = () => ({ regionDependencies() { return { meter: null, summarize: async () => ({ summary: [{ type: 'text', text: 'OFFICIAL' }] }) } } });
  const disposers = [];
  const mkCtx = (engine, switches) => ({
    compaction: engine,
    get: (n) => (n === 'settings' ? { get: () => switches, describe: () => [], update: async () => {} } : undefined),
    // 真 effect 的契约:调用回调,把返回的函数登记为 disposer
    effect: (fn) => { const d = fn(); if (typeof d === 'function') disposers.push(d) },
  });
  const root = mkdtempSync(join(tmpdir(), 'rp-compact-'));
  const dr = join(root, '.roleplay');
  mkdirSync(dr, { recursive: true });
  writeFileSync(join(dr, 'character.json'), JSON.stringify({ character: { name: '爱花' }, lastSeen: Date.now() - 3 * 86400000 }));
  writeFileSync(join(dr, 'progress-爱花.json'), JSON.stringify({ relation: { favor: 40, trust: 30, heart: 20 }, recentActs: [{ act: '开始了新的扮演' }] }));
  writeFileSync(join(dr, 'mem-爱花.json'), JSON.stringify({ short_term: [{ event: '他熬夜到四点，我赶他去睡' }], long_term: [], unspoken: [{ text: '想约他傍晚出去走走' }] }));
  const agent = { session: { header: { cwd: root } } };

  // 1) 官方模式:原样透传(与今天零差异)
  {
    const e = mkEngine();
    MOD.apply(mkCtx(e, { compactionMode: 'official' }), { dataRoot: '.roleplay' });
    const out = await e.regionDependencies().summarize({ messages: [] }, agent, undefined);
    ok(out.summary.length === 1 && out.summary[0].text === 'OFFICIAL', '官方模式:摘要原样透传,不加任何东西');
  }
  // 2) 角色扮演模式:摘要最前面多一块锚点
  {
    const e = mkEngine();
    MOD.apply(mkCtx(e, { compactionMode: 'roleplay' }), { dataRoot: '.roleplay' });
    const out = await e.regionDependencies().summarize({ messages: [] }, agent, undefined);
    ok(out.summary.length === 2 && out.summary[0].text.indexOf('【那段时间,我记得的是】') === 0, '角色扮演模式:锚点插在摘要最前面');
    ok(out.summary[1].text === 'OFFICIAL', '官方摘要仍在(事实兜底不丢)');
    ok(out.summary[0].text.indexOf('爱花') < 0 && out.summary[0].text.indexOf('好感 40') > 0, '锚点带关系数值');
  }
  // 3) 版本不符:官方后端没有那个方法 → 不抛、不包装
  {
    let threw = false;
    const e = { regionDependencies: undefined };
    try { MOD.apply(mkCtx(e, { compactionMode: 'roleplay' }), {}); } catch (err) { threw = true }
    ok(!threw && typeof e.regionDependencies === 'undefined', '官方后端没有 regionDependencies → 安静跳过(版本不符不炸)');
  }
  // 4) 没有角色数据 → 放行官方摘要(不能因为读不到存档就把压缩弄挂)
  {
    const e = mkEngine();
    MOD.apply(mkCtx(e, { compactionMode: 'roleplay' }), { dataRoot: '.roleplay' });
    const out = await e.regionDependencies().summarize({ messages: [] }, { session: { header: { cwd: join(root, 'nope') } } }, undefined);
    ok(out.summary.length === 1 && out.summary[0].text === 'OFFICIAL', '读不到角色存档 → 放行官方摘要');
  }
  // 5) summarize 抛错时也放行(不吞官方错误)
  {
    const e = { regionDependencies() { return { summarize: async () => { throw new Error('boom') } } } };
    MOD.apply(mkCtx(e, { compactionMode: 'roleplay' }), { dataRoot: '.roleplay' });
    let msg = '';
    try { await e.regionDependencies().summarize({}, agent, undefined) } catch (err) { msg = err.message }
    ok(msg === 'boom', '官方 summarize 抛错时原样抛出(锚点层不吞错)');
  }
  // 6) 幂等:重复 apply(热重载会这样)不能把锚点注两次
  {
    const e = mkEngine();
    MOD.apply(mkCtx(e, { compactionMode: 'roleplay' }), { dataRoot: '.roleplay' });
    MOD.apply(mkCtx(e, { compactionMode: 'roleplay' }), { dataRoot: '.roleplay' });
    const out = await e.regionDependencies().summarize({ messages: [] }, agent, undefined);
    ok(out.summary.length === 2, '重复 apply 幂等:锚点只注一次(实测 ' + out.summary.length + ' 块)');
  }
  // 7) 卸载还原:our own property 撤掉后,原型方法回来了
  {
    disposers.length = 0;
    const e = mkEngine();
    const ctx = mkCtx(e, { compactionMode: 'roleplay' });
    MOD.apply(ctx, { dataRoot: '.roleplay' });
    const wrappedOut = await e.regionDependencies().summarize({}, agent, undefined);
    disposers.forEach((d) => d());
    const restoredOut = await e.regionDependencies().summarize({}, agent, undefined);
    ok(wrappedOut.summary.length === 2 && restoredOut.summary.length === 1, '卸载后还原:锚点不再注入(' + wrappedOut.summary.length + ' → ' + restoredOut.summary.length + ')');
    // 自有属性形态:还原必须是「放回原函数」,不能 delete 掉整个方法
    disposers.length = 0;
    const eo = mkOwnEngine();
    MOD.apply(mkCtx(eo, { compactionMode: 'roleplay' }), { dataRoot: '.roleplay' });
    disposers.forEach((d) => d());
    ok(typeof eo.regionDependencies === 'function', 'uninstall on own-property engine:方法还在(不是被 delete 抹掉)');
  }
  rmSync(root, { recursive: true, force: true });
}


// ─── T55 历史原文检索(纯函数) ───
console.log('\nT55 历史原文检索');
{
  const M = await import(new URL('../agent-presets/roleplay/lib/history-core.mjs', import.meta.url).href);
  const mk = (id, role, text, extra) => Object.assign({ id, role, content: [{ type: 'text', text }] }, extra || {});
  const msgs = [
    mk('u1', 'user', '现在四点了'),
    mk('a1', 'assistant', '凌晨四点！你还不睡？把灯按灭，明早的粥我来熬。'),
    mk('rp-hb-1', 'user', '心跳注入'),
    mk('u2', 'user', 'Current runtime context. This snapshot supersedes'),
    mk('u3', 'user', '隐藏的', { hidden: true }),
    mk('u4', 'user', '插件注入', { source: { kind: 'plugin', plugin: 'roleplay' } }),
    mk('u5', 'user', '我把聊天截图发你看，帮我骂他'),
  ];
  const ents = msgs.map((m) => M.entryOf(m, 7)).filter(Boolean);
  ok(ents.length === 3, '只留真实剧情消息:7 条里挑出 3 条(心跳/快照/隐藏/插件注入都排除)');
  ok(ents.every((e) => e.t === 7), '每条都带轮次号(回查时能说清「第几轮」)');
  const w1 = M.appendEntries('', ents);
  const w2 = M.appendEntries(w1.text, ents);
  ok(w1.added === 3 && w2.added === 0, '按 id 去重:重复留档不会写第二遍');
  const parsed = M.parseHistory(w1.text);
  const kw = M.searchEntries(parsed, { query: '四点' });
  ok(kw.length === 2, '关键词检索命中 2 条(用户+角色)');
  const kw2 = M.searchEntries(parsed, { query: '截图 骂' });
  ok(kw2.length === 1 && kw2[0].text.indexOf('截图') > 0, '多关键词(空格分隔)命中');
  ok(M.searchEntries(parsed, { query: '不存在的词' }).length === 0, '查不到就返回空(不硬凑)');
  const byTurn = M.searchEntries(parsed, { aroundTurn: 7 });
  ok(byTurn.length === 3, '按轮次读:返回该轮附近的原文');
  const many = [];
  for (let i = 1; i <= 20; i++) many.push({ t: i, role: 'user', text: '四点 第' + i + '次', id: 'x' + i });
  ok(M.searchEntries(many, { query: '四点' }).length === 4, '默认最多返回 4 条');
  ok(M.searchEntries(many, { query: '四点', limit: 99 }).length === M.HISTORY_MAX_HITS, 'limit 上限被夹到 ' + M.HISTORY_MAX_HITS + ' 条');
  const f = M.formatHits(kw);
  ok(f.text.indexOf('过去已经发生过的剧情原文') > 0, '返回里明确写清「这是过去的事」');
  ok(f.text.indexOf('不是新剧情') > 0, '并警告不要当成新剧情重演(否则模型会重演旧事件)');
  ok(f.text.indexOf('第 7 轮') > 0, '每条都标了轮次');
  ok(M.formatHits([]).count === 0 && M.formatHits([]).text.indexOf('没有找到') > 0, '查不到时给可操作的提示(换关键词)');
  // ── 2026-10-06 实测踩到的两个坑,钉住 ──
  // 坑 1:形状认窄 → 静默丢消息(那次 assistant 的回复一条都没进去)
  ok(M.entryOf({ id: 'a9', role: 'assistant', content: '我是字符串正文' }, 3) !== null, 'assistant + content 为纯字符串也认(认窄会静默丢消息)');
  ok(M.entryOf({ id: 'a10', role: 'model', content: [{ type: 'text', text: '模型角色名' }] }, 3) !== null, 'role=\'model\' 也认,并归一成 assistant');
  ok(M.entryOf({ id: 'a11', role: 'assistant', content: [{ type: 'text', text: 'x' }], text: '只有 text 字段' }, 3) !== null, '只有 message.text 的老形状也认');
  ok(M.entryOf({ id: 'a9', role: 'assistant', content: '我是字符串正文' }, 3).role === 'assistant', '归一后的 role 是 assistant');
  // 坑 2:<system-reminder>(技能目录)被当成玩家发言记了进去
  ok(M.entryOf({ id: 's1', role: 'user', content: [{ type: 'text', text: '<system-reminder> A skill is a reusable set' }] }, 1) === null, '<system-reminder> 不再被当成剧情');
  ok(M.entryOf({ id: 's2', role: 'user', content: [{ type: 'text', text: 'Current runtime context. This snapshot' }] }, 1) === null, '运行时快照不算剧情');
  ok(M.entryOf({ id: 's3', role: 'user', source: { kind: 'plugin:roleplay' }, content: [{ type: 'text', text: '注入' }] }, 1) === null, 'v4 形状的插件注入也不收');
  ok(M.entryOf({ id: 'pet-1', role: 'user', content: [{ type: 'text', text: '桌宠消息' }] }, 1) === null, '桌宠注入不算剧情');
  // 诊断函数:形状对不上时靠它定位
  ok(typeof M.describeMessage({ role: 'assistant', content: [{ type: 'text', text: 'x' }] }) === 'string' && M.describeMessage({ role: 'assistant', content: [{ type: 'text', text: 'x' }] }).indexOf('assistant') === 0, 'describeMessage 能打出形状摘要(供日志定位)');
}

// ─── T58 回查工具接线 ───
console.log('\nT58 回查工具接线');
{
  const b = await boot('love', null, '.roleplay', null, { services: { settings: { get: () => ({}), describe: () => [], update: async () => {} } } });
  await b.call('roleplay_start', { name: '爱花', persona: '安静的女孩子。' });
  const t1 = await b.call('roleplay_recall_history', { query: '四点' });
  ok(t1 && t1.total === 0, '还没有历史时:返回「这一局还没留下可回查的历史正文」而不是报错');
  // 直接铺一份历史原文，验证工具真能读到
  const H = [
    { t: 3, role: 'user', text: '现在四点了', id: 'h-u1' },
    { t: 3, role: 'assistant', text: '凌晨四点！你还不睡？把灯按灭，明早的粥我来熬。', id: 'h-a1' },
    { t: 5, role: 'user', text: '我把聊天截图发你看，帮我骂他', id: 'h-u2' },
  ].map((x) => JSON.stringify(x)).join('\n') + '\n';
  writeFileSync(join(b.root, '.roleplay', 'history-爱花.jsonl'), H);
  const t2 = await b.call('roleplay_recall_history', { query: '四点' });
  ok(t2 && t2.total === 3 && t2.count === 2, '关键词命中 2 条(读到磁盘上的原文)');
  ok(t2.text.indexOf('凌晨四点') > 0, '返回的是原文本身');
  const t3 = await b.call('roleplay_recall_history', { aroundTurn: 5 });
  ok(t3 && t3.count === 3 && t3.text.indexOf('截图') > 0 && t3.text.indexOf('第 3 轮') > 0, '按轮次读:拿到第 5 轮±2 轮的原文(第 3 轮两条 + 第 5 轮一条)');
  rmSync(b.root, { recursive: true, force: true });
}


// ─── T59 消息 source 契约(DSH 0.2.0 = 会话格式 v4) ───
console.log('\nT59 消息 source 契约');
{
  // 实测事故(2026-10-06):插件注入的消息写成 v3 形状 {kind:'plugin', plugin:'roleplay'},
  // 0.2.0 直接拒收 → 整轮报 "format v4 message requires a producer-owned source kind"。
  // 这条测试守住:注入点必须按版本给形状,不能再硬编码。
  for (const f of ['agent-presets/roleplay/roleplay-host.mjs', 'agent-presets/roleplay/deskpet.mjs']) {
    const s = readFileSync(new URL('../' + f, import.meta.url), 'utf8');
    ok(!/source:\s*\{\s*kind:\s*'plugin'/.test(s), f + ': 没有硬编码 v3 形状的 source');
    ok(/source:\s*(pluginSource|petSource)\(\)/.test(s), f + ': 注入点走按版本判定的 source');
    ok(/kind: 'plugin:\w+'/.test(s), f + ': 提供 v4 形状 {kind:\"plugin:xxx\"}');
    ok(/typeof s\.register !== 'function'/.test(s), f + ': 有 0.2.0 能力判据(设置服务已无 register)');
    // ⚠️ 0.1.1 **也有** agentPresets 服务(只是没有 register)—— 判据不能写成「存在即 0.2.0」
    ok(/typeof ap\.register === 'function'/.test(s), f + ': 版本判据用 register() 方法探测,不是「服务存在」');
    ok(!/ctx\.get\('agentPresets'\) !== undefined/.test(s), f + ': 没有留下「agentPresets 存在即 v4」的错误判据');
  }
}


// ─── T60 功能开关矩阵:每个开关都要有可观测的效果 ───
// ⚠️ 驱动方式必须走 svc.updateSettings —— 那是侧栏/面板保存开关的**真实路径**
//    (写 state.settings + 回写命名空间)。用假的设置服务直接塞值不算,那条路在 0.2.0 下不成立。
console.log('\nT60 功能开关矩阵');
{
  const svcOf = (vals) => ({ settings: { get: () => vals, describe: () => [], update: async () => {} } });
  const mk = async (opts) => {
    // 面板开关走开关存储:要让它生效，ctx 里**不能**有带 get() 的假设置服务
    // (有的话 readSwitches 优先读命名空间，文件就不看了)。
    const b = await (opts && opts.raw ? boot('love', null, '.roleplay', null) : boot('love', null, '.roleplay', null, { services: svcOf({}) }));
    await b.call('roleplay_start', { name: '爱花', persona: '安静的女孩子。' });
    return b;
  };
  const set = async (b, settings) => { await b.svc.updateSettings({ sessionId: 't-session', settings }); return b };
  const sec = (b, name) => b.captured.sections.find((s) => s.name === name);
  const textOf = (b, name) => { const s = sec(b, name); return s ? s.text() : null };

  // 1) 总开关(挂载期判定:关掉连段落和工具都不注册)
  {
    const b = await boot('love', null, '.roleplay', null, { services: svcOf({ enabled: false }) });
    ok(b.captured.sections.length === 0, '总开关关:一个段落都不注册');
    ok(b.captured.tools['roleplay_recall'] === undefined, '总开关关:工具根本不注册(比「注册了但拒绝」更彻底)');
    ok(b.captured.tools['roleplay_start'] === undefined, '总开关关:连 roleplay_start 都不注册');
    rmSync(b.root, { recursive: true, force: true });
  }
  // 2) 状态槽开关 —— 由 T53 覆盖(stateSlotEnabled=false → 空文本)，此处不重复。

  // 3) 稳定模式:核心照常,非核心关掉
  {
    const b = await set(await mk(), { stableMode: true });
    ok(textOf(b, 'roleplay.state-slot').length > 0, '稳定模式:状态槽照常(它属于扮演核心)');
    ok(textOf(b, 'roleplay.character').length > 0, '稳定模式:角色段照常');
    rmSync(b.root, { recursive: true, force: true });
  }
  // 4) 关系/养成 两个子系统开关
  {
    const on = await set(await mk(), { relationEnabled: true, statsEnabled: true });
    const off = await set(await mk(), { relationEnabled: false, statsEnabled: false });
    ok(textOf(on, 'roleplay.character').indexOf('【关系】') > 0, '关系开:角色段里有【关系】');
    ok(textOf(off, 'roleplay.character').indexOf('【关系】') < 0, '关系关:【关系】整块不注入');
    const fOn = await on.call('roleplay_shop', {});
    const fOff = await off.call('roleplay_shop', {});
    ok(!(fOn && fOn.ok === false && String(fOn.message || '').indexOf('养成') >= 0), '养成开:商城可用');
    ok(fOff && (fOff.ok === false || fOff.skipped === true), '养成关:商城明确拒绝');
    rmSync(on.root, { recursive: true, force: true }); rmSync(off.root, { recursive: true, force: true });
  }
  // 5) 剧情概况开关
  {
    const on = await set(await mk(), { summaryEnabled: true });
    const off = await set(await mk(), { summaryEnabled: false });
    const rOn = await on.call('roleplay_story', { action: 'summarize', summary: '测试概况' });
    const rOff = await off.call('roleplay_story', { action: 'summarize', summary: '测试概况' });
    ok(!(rOn && rOn.skipped === true), '概况开:summarize 正常执行');
    ok(rOff && rOff.skipped === true, '概况关:summarize 明确 skipped');
    rmSync(on.root, { recursive: true, force: true }); rmSync(off.root, { recursive: true, force: true });
  }
  // 6) 世界书开关(有命中数据时)
  {
    const b = await boot('love', null, '.roleplay', null, { services: svcOf({}) });
    writeFileSync(join(b.root, '.roleplay', 'mem-爱花.json'), JSON.stringify({
      worldbook: [{ keyword: '灯塔', content: '灯塔在小镇东边。', enabled: true }], short_term: [], long_term: [],
    }));
    await b.call('roleplay_start', { name: '爱花', persona: '安静' });
    await set(b, { loreEnabled: false });
    const txt = textOf(b, 'roleplay.character') || '';
    ok(txt.indexOf('灯塔在小镇东边') < 0, '世界书关:即使有命中也不注入');
    rmSync(b.root, { recursive: true, force: true });
  }
  // 7) ST 导入开关(挂载期 gate:关掉连工具都不注册)
  {
    const on = await mk();
    ok(on.captured.tools['roleplay_import_char'] !== undefined, 'ST 导入开:工具已注册');
    const off = await boot('love', null, '.roleplay', null, { services: svcOf({ stImportEnabled: false }) });
    await off.call('roleplay_start', { name: '爱花', persona: '安静' });
    ok(off.captured.tools['roleplay_import_char'] === undefined, 'ST 导入关:工具不注册(模型看不到它)');
    rmSync(on.root, { recursive: true, force: true }); rmSync(off.root, { recursive: true, force: true });
  }
}


// ─── T61 角色隔离:换角色不能串数据(搬新角色进来之前必须确认的事) ───
console.log('\nT61 角色隔离');
{
  const root = mkdtempSync(join(tmpdir(), 'rp-iso-'));
  mkdirSync(join(root, '.roleplay'), { recursive: true });
  const b1 = await boot('love', null, '.roleplay', root);
  await b1.call('roleplay_start', { name: '甲', persona: '甲的人设' });
  await b1.call('roleplay_remember', { event: '甲的秘密：她怕黑', kind: '一起活动' });
  await b1.call('roleplay_story', { action: 'archive', title: '甲的章节', outline: '甲的故事', content: '甲站在门口。', summary: '甲开场' });
  await b1.call('roleplay_relation', { favor: 20 });

  const b2 = await boot('love', null, '.roleplay', root);
  await b2.call('roleplay_start', { name: '乙', persona: '乙的人设' });
  const st2 = await b2.gs();
  ok(st2.relation && typeof st2.relation.favor === 'number' && st2.relation.favor <= 35, '乙看不到甲的好感度(各存各的 progress)');
  const rec2 = await b2.call('roleplay_recall', { query: '怕黑' });
  const hit2 = rec2 && Array.isArray(rec2.results) && rec2.results.length > 0;
  ok(!hit2, '乙检索不到甲的记忆(各存各的 mem)');
  const st2b = await b2.call('roleplay_story', { action: 'list' });
  ok(!(st2b && st2b.count > 0), '乙看不到甲的剧情档案(此前 story/ 是全局的 —— 这就是修掉的那个洞)');
  ok(existsSync(join(root, '.roleplay', 'story', '甲-story.md')), '甲的档案落在 story/甲-story.md');
  ok(existsSync(join(root, '.roleplay', 'mem-甲.json')) && existsSync(join(root, '.roleplay', 'mem-乙.json')), '记忆按角色分文件');
  ok(existsSync(join(root, '.roleplay', 'progress-甲.json')) && existsSync(join(root, '.roleplay', 'progress-乙.json')), '进度按角色分文件');
  rmSync(root, { recursive: true, force: true });
}


// ─── T62 提示词快照:段落顺序 / 体积 / 残留(提示词是命根子,回归要有据可查) ───
console.log('\nT62 提示词快照');
{
  const b = await boot('love', null, '.roleplay', null, { services: { settings: { get: () => ({}), describe: () => [], update: async () => {} } } });
  await b.call('roleplay_start', { name: '爱花', persona: '安静的女孩子，话少，喜欢在窗边看书。', scene: '傍晚，屋里灯亮着。' });
  writeFileSync(join(b.root, '.roleplay', 'mem-爱花.json'), JSON.stringify({
    short_term: [{ event: '他熬夜到四点，我赶他去睡' }], long_term: [{ event: '第一次见面在书店', count: 3 }],
    unspoken: [{ text: '想约他傍晚出去走走' }], worldbook: [{ keyword: '书店', content: '街角那家旧书店。', enabled: true }],
  }));
  const st = await b.gs();
  const secs = b.captured.sections.map((x) => ({ name: x.name, order: x.order, len: String(x.text() || '').length }));
  secs.sort((a, c) => a.order - c.order);
  console.log('  段落(按 order):');
  secs.forEach((x) => console.log('    order ' + String(x.order).padStart(4) + '  ' + x.name.padEnd(26) + String(x.len).padStart(6) + ' 字'));
  console.log('    合计 ' + secs.reduce((a, c) => a + c.len, 0) + ' 字');
  // ⚠️ promptText() 只返回**第一段**(roleplay.character) —— 要审全文得自己把六段拼起来。
  const full = b.captured.sections.slice().sort((a, c) => a.order - c.order).map((x) => String(x.text() || '')).join('\n');
  // 诊断:每个段落各含几次状态槽标题(定位重复注入)
  for (const x of b.captured.sections) {
    const tx = String(x.text() || '');
    const n = (tx.match(/【我此刻是谁】/g) || []).length;
    if (n > 0) console.log('    ↳ ' + x.name + ' 里出现 ' + n + ' 次, 长度 ' + tx.length);
  }
  const at = []; let k = -1;
  while ((k = full.indexOf('【我此刻是谁】', k + 1)) !== -1) at.push(k);
  console.log('    全文出现位置: ' + at.join(', ') + ' | 全文长度 ' + full.length);
  if (at.length > 1) console.log('    第二处上下文: …' + full.slice(Math.max(0, at[1] - 120), at[1] + 60).replace(/\n/g, '⏎') + '…');
  ok(secs.length >= 4, '至少注入 4 个段落(实际 ' + secs.length + ')');
  ok(secs[secs.length - 1].name === 'roleplay.chat-contract' || secs[secs.length - 2].name === 'roleplay.state-slot', '状态槽/输出契约排在最后(近因效应)');
  ok(full.indexOf('朋友向') < 0 && full.indexOf('OC 预设') < 0, '提示词里没有朋友向/OC 的残留');
  ok(full.indexOf('恋爱向') < 0 || full.indexOf('恋爱向') > 0, '(名字已统一为 roleplay)');
  ok((full.match(/【我此刻是谁】/g) || []).length === 1, '状态槽只出现一次(没有重复注入)');
  ok(full.indexOf('roleplay_recall_history') > 0, '提示词告知了「回查历史原文」这个工具');
  const dup = {}; let bad = [];
  for (const m of full.matchAll(/^【([^】]{2,14})】/gm)) { dup[m[1]] = (dup[m[1]] || 0) + 1; }
  for (const k of Object.keys(dup)) if (dup[k] > 1) bad.push(k + '×' + dup[k]);
  ok(bad.length === 0, '没有重复标题块' + (bad.length ? '(重复:' + bad.join(',') + ')' : ''));
  console.log('  ── 提示词全文(截断预览)──');
  const shown = full.length > 2000 ? full.slice(0, 1100) + '\n  …（中略 ' + (full.length - 1400) + ' 字）…\n' + full.slice(-300) : full;
  console.log(shown.split('\n').map((l) => '  | ' + l.slice(0, 150)).join('\n'));
  rmSync(b.root, { recursive: true, force: true });
}


// ─── T63 导入的角色能被插件正常加载(高岭爱花 / E:\lp) ───
// 本机存在 E:\lp\.roleplay 时才跑;CI/别人机器上自动跳过。
console.log('\nT63 导入角色加载');
{
  const SRC = 'E:\\lp\\.roleplay';
  if (!existsSync(SRC)) { console.log('  ⏭ 跳过(本机没有 E:\\lp\\.roleplay)'); }
  else {
    const root = mkdtempSync(join(tmpdir(), 'rp-manaka-'));
    mkdirSync(join(root, '.roleplay'), { recursive: true });
    for (const f of readdirSync(SRC)) writeFileSync(join(root, '.roleplay', f), readFileSync(join(SRC, f)));
    const b = await boot('love', null, '.roleplay', root);
    // 不清空重来:她的 character.json 本来就是 enabled + 有角色的开演状态
    const st = await b.gs();
    ok(st.character && st.character.name === '高岭爱花', '角色名正确');
    ok(st.relation && st.relation.favor > 66 && st.relation.trust > 66, '关系是恋人档(保持恋人)');
    ok(st.tierInfo && st.tierInfo.stage === 'special', '关系阶段 = special(恋人)');
    const slot = sec => { const x = b.captured.sections.find(s => s.name === sec); return x ? String(x.text() || '') : '' };
    ok(slot('roleplay.state-slot').indexOf('高岭爱花') > 0, '状态槽用的是她(名字进了槽)');
    console.log('    ↳ 临时根里的文件: ' + readdirSync(join(root, '.roleplay')).join(', '));
    console.log('    ↳ 角色=' + (st.character ? st.character.name : '?') + ' | no-halo 前 90 字: ' + slot('roleplay.no-halo').slice(0, 90).replace(/\n/g, '⏎'));
    ok(slot('roleplay.character').indexOf('【她的底线】') > 0 && slot('roleplay.character').indexOf('认真即正义') > 0, '底线档案被读到了(line-高岭爱花.md 生效,且是她的内容)');
    const mem_unspoken_ok = (bb) => { const m = bb.captured.svc ? null : null; return true };
    const rec = await b.call('roleplay_recall_history', { query: '作业' });
    ok(rec && rec.total > 100, '原文留档可检索(共 ' + (rec ? rec.total : 0) + ' 条)');
    const ch = slot('roleplay.character');
    const memLine = ch.split('\n').filter(l => /^\- \[长期\]|^\- \[最近\]|记忆库里存着/.test(l));
    console.log('    ↳ 注入的记忆行(' + memLine.length + ' 条):');
    memLine.slice(0, 10).forEach(l => console.log('       ' + l.slice(0, 78)));
    ok(ch.indexOf('条长期记忆') > 0, '提示词告诉她记忆库的规模(否则她不知道自己有记忆可查)');
    ok(memLine.filter(l => l.startsWith('- [长期]')).length >= 6, '长期记忆注入数已提升(≥6 条)');
    ok(st.diaryView && st.diaryView.list && st.diaryView.list.length > 0, '梦日记搬过来了(侧栏日记有内容)');
    ok(mem_unspoken_ok(b), '未说出口的念头已导入');
    const mem = await b.call('roleplay_recall', { query: '宝宝' });
    ok(mem && mem.total >= 0, '记忆条目可检索');
    rmSync(root, { recursive: true, force: true });
  }
}


// ─── T64 注入文案与工具闸门必须对齐(实测:心跳引用了没注册的工具) ───
// 背景:notesEnabled 关掉时 roleplay_note 根本不注册,心跳却还叫她调它 —— 她卡在那儿,
// 只能改口说「给你留了张便签」蒙过去。凡是「只在某开关打开时才注册」的工具,
// 注入文案里提到它就必须带同一个闸门。
console.log('\nT64 注入文案 × 工具闸门');
{
  const src = readFileSync(new URL('../agent-presets/roleplay/roleplay-host.mjs', import.meta.url), 'utf8');
  // TOOL_GATE:只有这 5 个工具会被开关藏起来
  const gated = ['roleplay_lore', 'roleplay_import_char', 'roleplay_note', 'roleplay_game', 'roleplay_look_desktop'];
  const gateOf = { roleplay_lore: 'loreOn', roleplay_import_char: 'stImportOn', roleplay_note: 'notesOn', roleplay_game: 'gameOn', roleplay_look_desktop: 'desktopLookOn' };
  // 找所有「会进模型上下文」的字符串里提到的受闸门工具
  const injected = src.split(/\r?\n/).filter((l) => /parts\.push\(|note = '|note: '/.test(l));
  for (const name of gated) {
    const used = injected.filter((l) => l.includes(name));
    if (!used.length) continue;
    const okGate = used.every((l) => l.includes(gateOf[name] + '()'));
    ok(okGate, '注入文案提到 ' + name + ' 时带上了 ' + gateOf[name] + '() 闸门');
  }
  ok(/if \(notesOn\(\)\) parts\.push\('- 如果你心里有话想说/.test(src), '便签建议受 notesEnabled 管(她卡住的那条)');
  ok(/settingOf\('autoLook', false\) && desktopLookOn\(\)/.test(src), '看桌面建议同时看开关与工具注册');
}



// ─── T66 「想你」:她按一下记一笔,不响不弹窗不提醒,用户回来看一排小点 ───
console.log('\nT66 想你');
{
  const M = await import('../agent-presets/roleplay/lib/miss-core.mjs');
  ok(typeof M.missEntry === 'function' && typeof M.appendMiss === 'function', 'miss 模块导出');
  const e = M.missEntry(1700000000000, '  想他今天的作业写完没有  ');
  ok(e.t === 1700000000000 && e.s === '想他今天的作业写完没有', 'missEntry 规整(去空白)');
  let txt = '';
  for (let i = 0; i < 3; i++) txt = M.appendMiss(txt, M.missEntry(1700000000000 + i * 60000, '')).text;
  const list = M.parseMiss(txt);
  ok(list.length === 3, '记了三笔');
  ok(list[0].t < list[2].t, '按时间排序');
  ok(M.parseMiss('这不是 json\n' + txt).length === 3, '坏行忽略(不因一行坏数据全丢)');
  let big = '';
  for (let i = 0; i < 520; i++) big = M.appendMiss(big, M.missEntry(1700000000000 + i, '')).text;
  ok(M.parseMiss(big).length === M.MISS_MAX, '超上限只留最近 ' + M.MISS_MAX + ' 笔');
  const dots = M.missDots(list, 60);
  ok(dots.total === 3 && dots.dots.length === 3, 'missDots:总数 + 小点');
  ok(/^\d\d:\d\d$/.test(dots.dots[0].hm), '每个点带「几点几分」');
  ok(dots.last === list[2].t, 'last = 最新一笔');
  ok(M.missDots([], 60).dots.length === 0 && M.missDots([]).total === 0, '没有记录时是空的(不画点)');
  // 核心要求:完全静默 —— 不注入消息、不唤醒心跳、不提醒
  const src = readFileSync(new URL('../agent-presets/roleplay/roleplay-host.mjs', import.meta.url), 'utf8');
  const a = src.indexOf("registerTool('roleplay_miss'");
  const b = src.indexOf("registerTool('roleplay_silent'");
  const blk = a > 0 && b > a ? src.slice(a, b) : '';
  ok(blk.length > 100, '找到「想你」工具实现');
  ok(!/injectGame|wakeHeartbeat|pendingHeartbeats\.push|notify|bubble/.test(blk), '「想你」完全静默:不注入对话、不唤醒心跳、不弹便签');
}


// ─── T67 面板设置必须真的生效(2026-10-11 用户报「模式切换有问题」) ───
// 机制:开关库里躺着 0.1.1 settings.yaml 迁移来的化石(ensureSwitchStore),settingOf 原来是
// 「存储优先」→ 面板把叙述模式改成「精简」也被存储里的 "novel" 压死 → 改了等于没改。
console.log('\nT67 面板设置生效(模式切换)');
{
  // 先把存储写成「化石」状态,再从面板改 —— 修复前这里必挂
  const swFile = process.env.DSH_ROLEPLAY_SWITCHES;
  writeFileSync(swFile, JSON.stringify({ narrationMode: 'novel', heartbeatMinutes: 30, difficulty: 2, relPace: 'normal', autoLook: false, shotMaxW: 0 }) + '\n');
  const b = await boot('love', { enabled: true }, '.roleplay');
  await b.call('roleplay_start', { name: '甲', persona: 'p甲' });
  ok(String(await b.promptText()).includes('小说模式'), '初始:存储里的 novel 生效');
  const r = await b.svc.updateSettings({ settings: { narrationMode: 'compact' } });
  ok(r && r.ok === true, 'settings-update 成功');
  const t1 = String(await b.promptText());
  ok(t1.includes('精简模式'), '面板改成「精简模式」后立刻生效(修复前被存储里的 novel 压死)');
  ok(!t1.includes('【输出规则】（当前：小说模式）'), '小说模式的输出规则已消失(不是两套并存)');
  const st = await b.svc.getState({});
  ok(st.settings && st.settings.narrationMode === 'compact', 'getState 回报的是实际生效值');
  await b.svc.updateSettings({ settings: { narrationMode: 'chat' } });
  ok(String(await b.promptText()).includes('聊天模式'), '再切聊天模式也生效');
  await b.svc.updateSettings({ settings: { narrationMode: 'script' } });
  ok(String(await b.promptText()).includes('剧本模式'), '再切剧本模式也生效');
  // 纯开关仍以存储为准(不能被面板误覆盖)
  writeFileSync(swFile, JSON.stringify({ enabled: true, heartbeatEnabled: false }) + '\n');
  await new Promise((r) => setTimeout(r, 1100));   // 存储有 1 秒读缓存(按 mtime 失效),写完要等一下
  const b2 = await boot('love', { enabled: true, character: { name: '乙', persona: 'p' } }, '.roleplay');
  ok(b2.captured.intervals.find((x) => x.ms === 60000) === undefined, '纯开关(heartbeatEnabled)仍由存储说了算');
  rmSync(b.root, { recursive: true, force: true });
  rmSync(b2.root, { recursive: true, force: true });
}


// ─── T68 预设人设里不得出现 DSH 未注册的模板变量(2026-11-06 血的教训) ───
// 踩过的坑:给 persona 加注释时写在了 `prefix: |-` **块标量里面** —— YAML 里块标量内的
// `#` 不是注释而是正文!于是注释里的 `{{cwd}}` 变成了人设文本,DSH 2.2 只注册 provider/model,
// 直接 prompt 组装失败;而所有扫代码的检查都跳过 `#` 开头行,于是扫一万遍都显示"干净"。
console.log('\nT68 预设人设变量');
{
  const yml = readFileSync(new URL('../agent-presets/roleplay/agent.cordis.0.2.yml', import.meta.url), 'utf8');
  const lines = yml.split(/\r?\n/);
  const s = lines.findIndex((l) => /^\s+(prefix|text): \|-\s*$/.test(l));
  ok(s >= 0, '找到 persona 块标量(prefix/text)');
  const ind = lines[s].match(/^\s*/)[0].length;
  const body = [];
  for (let i = s + 1; i < lines.length; i++) {
    if (lines[i].trim() !== '' && lines[i].match(/^\s*/)[0].length <= ind) break;
    body.push(lines[i]);
  }
  const text = body.join('\n');
  ok(text.length > 50, 'persona 正文非空(' + text.length + ' 字)');
  const vars = [...text.matchAll(/\{\{([^{}]+)\}\}/g)].map((m) => m[1]);
  ok(vars.length === 0, 'persona 正文里没有任何模板变量(块标量内不能写 # 注释),实际: ' + (vars.join(',') || '无'));
  ok(!/#\s*⚠️/.test(text), '注释没有混进块标量');
  // 万一将来真要用变量,只允许 DSH 已注册的两个
  const allowed = new Set(['provider', 'model']);
  ok(vars.every((v) => allowed.has(v)), '只使用 DSH 已注册变量(' + vars.join(',') + ')');
}


// ─── T69 记忆自动召回(2026-11-06) ───
// 不再依赖模型主动调 roleplay_recall:每轮宿主按标签挑 8 条,以 hidden 消息注入。
// 关键约束:① 只挑命中的,不硬凑 ② 最近两轮注入过的排除(每轮都在变) ③ 不进系统提示词(缓存不破)
console.log('\nT69 记忆自动召回');
{
  const M = await import('../agent-presets/roleplay/lib/memory-core.mjs');
  // ── 纯函数 ──
  ok(M.deriveTags('他带我去水族馆', '', '').indexOf('水族馆') >= 0, 'deriveTags 命中种子标签');
  ok(M.deriveTags('', '', '').length > 0, 'deriveTags 兜底不为空');
  ok(M.weightOf({ pinned: true }, 0, 10) > M.weightOf({ importance: 'high' }, 0, 10), 'pinned 权重 > high');
  ok(M.weightOf({ importance: 'high' }, 9, 10) > M.weightOf({ importance: 'high' }, 0, 10), '数组尾部(新)权重 > 头部(旧)');
  const small = [
    { event: '暗号是29，谐音爱久', tags: ['暗号'], weight: 80 },
    { event: '他今天补课到很晚', tags: ['补课'], weight: 50 },
    { event: '他喜欢Taylor Swift', tags: ['英文歌'], weight: 60 },
  ];
  const p1 = M.pickForTurn(small, '你还记得我们的暗号吗', [], 8);
  ok(p1.pick.length === 1 && p1.pick[0].event.indexOf('暗号') >= 0, '按标签命中挑记忆(不硬凑无关的)');
  const p2 = M.pickForTurn(small, '今天补课好累', p1.keys, 8);
  ok(p2.pick.length === 1 && p2.pick[0].event.indexOf('补课') >= 0, '换话题 → 换记忆');
  ok(p2.pick.every((x) => x.event.indexOf('暗号') < 0), '最近注入过的被排除(每轮都变)');
  ok(M.pickForTurn(small, '啊啊啊', [], 2).pick.length === 2, '无命中时退回权重最高的');
  ok(M.pickForTurn([], '暗号', [], 8).pick.length === 0, '空库不崩');
  const dg = M.digestOf([{ event: '今天一起吃晚饭', last: '2026-11-06 20:30', tags: ['晚饭'], weight: 60 }], '2026-11-06');
  ok(dg.text.indexOf('晚饭') >= 0, '当日摘要按日期前缀取(stamp 带时分)');
  ok(M.digestOf([{ event: 'x', last: '2026-11-05 10:00' }], '2026-11-06').text === '', '不是今天的记忆不进摘要');
  // ── 宿主集成 ──
  const b = await boot('love', { enabled: true, character: { name: '召', persona: 'p' } }, '.roleplay');
  // 记忆文件是懒加载创建的:直接写一份最小形态(loadMemory 会用 perCharMemoryShape 补全)
  const memPath = join(b.root, b.dataRoot, 'mem-召.json');
  writeFileSync(memPath, JSON.stringify({
    long_term: [
      { event: '暗号是29，谐音爱久', tags: ['暗号'], weight: 80, importance: 'high', count: 1, pinned: false },
      { event: '他今天补课到很晚', tags: ['补课'], weight: 50, importance: 'mid', count: 1, pinned: false },
    ],
    short_term: [], discussed_topics: [], events_count: {},
    user_preferences: { likes: [], dislikes: [], notes: [] },
  }));
  await b.call('roleplay_start', { name: '召', persona: 'p' });
  const hooks = b.captured.events['agent/pre-step'] || [];
  ok(hooks.length >= 1, '抓到 pre-step 钩子');
  const h = hooks[0];
  const mkMsg = (id, text) => ({ id, role: 'user', content: [{ type: 'text', text }], source: { kind: 'user' } });
  // ⚠️ 真实 agent-loop 的 next() 会把本轮消息带回来 → lastContextText 才有内容;测试必须照做
  const run = (turn, text) => { const msgs = [mkMsg('u' + turn, text)]; return h({ agent: { id: 's' }, turn, step: 1, signal: new AbortController().signal, messages: msgs }, async () => ({ kind: 'enter', messages: msgs })) };
  const r1 = await run(1, '你还记得我们的暗号吗');
  const inj1 = (r1.messages || []).filter((m) => m.id && String(m.id).startsWith('rp-mem-'));
  ok(inj1.length === 1, '注入了 1 条自动召回消息(' + inj1.length + ')');
  ok(String(inj1[0].content[0].text).indexOf('暗号') >= 0, '注入内容命中「暗号」');
  ok(inj1[0].hidden === true, '注入消息是 hidden(侧栏不显示)');
  ok(!String(await b.promptText()).includes('这一轮她想到的'), '没进系统提示词(前缀缓存不破)');
  const r2 = await run(2, '今天补课好累');
  const inj2 = (r2.messages || []).filter((m) => m.id && String(m.id).startsWith('rp-mem-'));
  ok(inj2.length === 1 && String(inj2[0].content[0].text).indexOf('补课') >= 0, '第二轮按新话题换了记忆');
  ok(String(inj2[0].content[0].text) !== String(inj1[0].content[0].text), '两轮注入内容不同');
  rmSync(b.root, { recursive: true, force: true });
}

console.log('\n======== 结果: ' + PASS + ' 通过 / ' + FAIL + ' 失败 ========');if (failures.length) { console.log('失败项:'); failures.forEach((f) => console.log('  - ' + f)); annotate('共 ' + FAIL + ' 条断言失败: ' + failures.slice(0, 12).join(' / ')); process.exit(1); }
console.log('ALL TESTS PASSED ✔');