/**
 * Interactive pi-tui front door for DeepSeek Harness agents. It renders the
 * durable session transcript, drives one configured agent, and provides
 * keyboard-driven user-interaction dialogs without owning agent lifecycle.
 * @module @deepseek-ai/dsh-tui
 */

import { randomUUID } from 'node:crypto'
import { stat } from 'node:fs/promises'
import { resolve } from 'node:path'
import {
  CombinedAutocompleteProvider,
  Container,
  Key,
  Spacer,
  Text,
  TUI,
  ProcessTerminal,
  matchesKey,
  visibleWidth,
  type Component,
  type EditorTheme,
  type RgbColor,
  type SlashCommand,
  type TerminalColorScheme,
} from '@earendil-works/pi-tui'
import { Service, type Context, type Fiber, type FiberState } from '@deepseek-ai/cordis'
import {
  assembleContextFor,
  installModelSelection,
  type Agent,
  type AgentHandle,
  type ModelSelectionRef,
  type AgentStatus,
} from '@deepseek-ai/dsh-agent'
import type {} from '@deepseek-ai/dsh-agent-loop'
import type {} from '@deepseek-ai/dsh-token-meter'
import type { CommandResult } from '@deepseek-ai/dsh-commands'
import { createUserMessage, errorChain } from '@deepseek-ai/dsh-llm'
import type { ContentBlock, MessageId } from '@deepseek-ai/dsh-llm'
import type {} from '@deepseek-ai/dsh-llm-retry'
import { renderPrompt } from '@deepseek-ai/dsh-system-prompt'
import {
  SessionId,
  type UserMessage,
} from '@deepseek-ai/dsh-session'
import { foldGoal } from '@deepseek-ai/dsh-goal'
import {
  parseSessionReferenceText,
} from '@deepseek-ai/dsh-session-reference'
import { foldSessionTitle } from '@deepseek-ai/dsh-session-title'
// Type import also declaration-merges the optional `sessionPersistence`
// service onto `Context` so `ctx.get('sessionPersistence')` is typed.
import type {} from '@deepseek-ai/dsh-session-persistence'
import type { SessionQueryEngine } from '@deepseek-ai/dsh-session-query'
import type {} from '@deepseek-ai/dsh-workspace'
import type { SkillRegistry, SkillSummary } from '@deepseek-ai/dsh-skill'
// Merges the `permissionPresets` service and the `permission/preset` session
// event onto their ambient declarations; the service itself is optional at runtime.
import type {} from '@deepseek-ai/dsh-permission-presets'
// Type import declaration-merges the `userInteraction` service onto `Context`;
// the ask-user-question queue is registered by ./chat/questions.
import type {} from '@deepseek-ai/dsh-user-questions'
import {
  TuiExtensionServiceImpl,
  TuiOverlayManager,
} from './extension/overlay-manager.ts'

import {
  parseTuiPromptTemplate,
  renderTuiPromptTemplate,
  type TuiPromptValueHandle,
} from './prompt.ts'
import type {
  TuiOverlayRequest,
  TuiOverlaySession,
  TuiTheme,
} from './extension/types.ts'
import { displayInlineText, displayText } from './components/text.ts'
import { createCodeHighlighter } from './components/highlight.ts'
import { brandText, createPalette, markdownTheme, selectTheme, type PaletteOptions } from './components/theme.ts'
import { THEME_PRESETS, THEME_PRESET_NAMES, type ThemePreset } from './components/theme-presets.ts'
import {
  cacheHitRate,
  formatTokens,
} from './chat/tokens.ts'
import {
  fadeGlyph,
  formatSteeringStatus,
  formatStatusDuration,
  pulseLevel,
  runningPhaseGlyph,
} from './chat/timing.ts'
import {
  resolveTuiConfig,
  type Config,
} from './config.ts'
import {
  type ToolCardVisibility,
  type WelcomeSuggestion,
  HeaderComponent,
} from './components/transcript.ts'
import { FramedEditorComponent } from './components/framed-editor.ts'
import { WorkbenchShellComponent } from './components/workbench-shell.ts'
import { FullScreenTerminal, terminalMouseInput } from './full-screen-terminal.ts'
import { NoticeSlotComponent, type NoticeKind } from './components/notice-slot.ts'
import { WorkingLineComponent } from './components/working-line.ts'
import { logoFullWidth, SHIMMER_INTERVAL_MS, SHIMMER_WIDTH } from './components/logo.ts'
import { contextPressureLevel } from './chat/context-pressure.ts'
import {
  compactTargetLabel,
  ConfirmDialog,
  contextMeter,
  DetailsDialog,
  diagnosticMeter,
  formatDiagnosticCount,
  formatDiagnosticNumber,
  formatDiagnosticTime,
  initialTarget,
  PromptContextComponent,
  RenameDialog,
  SessionSwitchDialog,
  targetLabel,
  ThemeDialog,
  type DetailsSelection,
} from './components/dialogs.ts'
import {
  parseSkillArguments,
  renderSkillInvocation,
} from './chat/skill-invocation.ts'
import { SkillSelector } from './components/skill-selector.ts'
import { ReferenceAutocompleteProvider } from './chat/autocomplete.ts'
import {
  formatCwd,
  gitBranch,
  HintEditor,
} from './chat/helpers.ts'
import { createSessionChannel, type SessionChannel } from './chat/session-channel.ts'
import {
  createTerminalTitleController,
  type TerminalTitleController,
} from './chat/terminal-title.ts'
import {
  ASSISTANT_SESSION_ID,
  createAssistantController,
  setupAssistant,
} from './chat/assistant.ts'
import { createSessionLayout, type SessionLayoutController } from './chat/session-layout.ts'
import { createWorkspaceSessions } from './chat/workspace-sessions.ts'
import { TUI_WORKSPACE_STARTUP_KEY } from './workspace-agent-loop.ts'
import {
  createChannelRegistry,
  DEFAULT_MAX_LIVE_SLOTS,
  type ChannelRegistry,
  type SessionSlot,
} from './chat/channel-registry.ts'
import {
  createModelController,
  type ModelController,
} from './chat/model-command.ts'
import { createApprovalAnswerer, type ApprovalAnswerer } from './chat/approval.ts'
import { createGoalBar, type GoalBarController } from './chat/goal-bar.ts'
import { createPermissionController, type PermissionPresetsService } from './chat/permission.ts'
import { createQuestionQueue } from './chat/questions.ts'
import { createQueueDock, replaceQueuedMessage, type QueueDockController } from './chat/queue-dock.ts'
import {
  deleteImagePlaceholderAtCursor,
  ImageDraft,
  pasteClipboardImage,
  type ImageAttachmentWriter,
} from './chat/image-draft.ts'
import type { MemoryScopeDisposer, TuiMemoryService } from './chat/memory.ts'
import { forkSession } from './chat/fork.ts'
import {
  agentsLines,
  contextLines,
  jobsLines,
  openStaticDialog,
  settingsLines,
  writeExport,
  type InsightsDeps,
} from './chat/insights.ts'
import { foldPlanMode } from '@deepseek-ai/dsh-plan-mode'
import { createResumeController } from './chat/resume.ts'
import { createRewindController } from './chat/rewind.ts'
import type { TuiResumeHost, TuiRuntime } from './runtime.ts'
import { WorkspaceFileSearch } from './chat/file-autocomplete.ts'
import { copyText } from './clipboard.ts'

export { TuiPromptService } from './prompt.ts'
export { renderSkillInvocation } from './chat/skill-invocation.ts'
export type { TuiResumeHost, TuiRuntime } from './runtime.ts'
export {
  resolveTuiConfig,
  TuiConfigSchema,
  Config,
  type ResolvedTuiConfig,
  type ResolvedTuiThemeConfig,
  type TuiConfig,
  type TuiThemeConfig,
} from './config.ts'
export {
  DEFAULT_FILE_SEARCH_EXCLUDED_DIRECTORIES,
  DEFAULT_FILE_SEARCH_MAX_ENTRIES,
  DEFAULT_FILE_SEARCH_MAX_RESULTS,
} from './chat/file-autocomplete.ts'

export type {
  TuiComponent,
  TuiFocusable,
  TuiOverlayAnchor,
  TuiOverlayCloseReason,
  TuiOverlayHost,
  TuiOverlayMargin,
  TuiOverlayOptions,
  TuiOverlayOutcome,
  TuiOverlayRequest,
  TuiOverlaySession,
  TuiOverlayState,
  TuiTheme,
  TuiViewport,
} from './extension/types.ts'

/** First terminal Cordis state: FAILED, DISPOSED, and UNLOADING are unusable. */
const FIBER_FAILED = 3 as FiberState.FAILED
/** Short, bounded window for a sibling session-query plugin to finish mounting. */
const STOPPED_TITLE_RETRY_DELAY_MS = 50
const STOPPED_TITLE_RETRY_LIMIT = 20

/** Complete durable reference required by the attachment store. */
type ImageAttachmentRef = Extract<ContentBlock, { type: 'image' }>['attachment']

declare module '@deepseek-ai/cordis' {
  interface Context {
    /** Terminal-only interaction service, available only while a TUI is mounted. */
    tui: TuiExtensionService
    /** Optional process host that can replace this TUI with a resumed session. */
    tuiResumeHost: TuiResumeHost
    /** Launcher-owned `main` session identity; absent lets the app mint one. */
    mainSessionId: MainSessionIdentity | undefined
    /** Line the launcher wants printed on exit; absent prints nothing. */
    tuiGoodbyeMessage: string | undefined
    /** Skill the launcher wants auto-invoked as the fresh session's first turn; absent leaves it to the user. */
    tuiInitialSkill: string | undefined
  }
}

/** Launcher-chosen identity for the app's `main` session. */
export interface MainSessionIdentity {
  /** Exact session id `main` binds to. */
  readonly id: SessionId
  /**
   * Whether that session already has persisted history to load. `true` requires
   * an existing log and fails loud when absent; `false` creates it fresh.
   */
  readonly resume: boolean
}

/**
 * Context key a launcher sets before any Loader entry mounts
 * (`ctx.provide(MAIN_SESSION_ID_KEY, identity)`) to fix the `main` agent's
 * session identity, so an app bundle mounted from a `cordis.yml` binds a
 * launcher-selected session without a config key. `ctx.provide` is the only
 * channel from launcher argv into a Loader-mounted plugin, because config
 * `!!js` expressions evaluate against the entry's context. Absent leaves the
 * choice to the app.
 */
export const MAIN_SESSION_ID_KEY = 'mainSessionId'

/**
 * Context key a launcher sets before any Loader entry mounts
 * (`ctx.provide(TUI_GOODBYE_MESSAGE_KEY, line)`) to supply the line the TUI
 * prints once the terminal is released on exit — for the shipped CLI, the
 * command that resumes this session. The launcher owns the wording because only
 * it knows how it was invoked; the TUI escapes terminal controls before
 * rendering. Absent prints nothing.
 */
export const TUI_GOODBYE_MESSAGE_KEY = 'tuiGoodbyeMessage'

/**
 * Context key a launcher sets before any Loader entry mounts
 * (`ctx.provide(INITIAL_SKILL_KEY, name)`) to seed a fresh session's first user
 * turn with `/skill <name>` — the `dsh migrate`/`dsh upgrade`
 * guided-session entry. The launcher sets it only when minting a fresh session,
 * so it never re-fires on a resumed one. Absent leaves the first turn to the user.
 */
export const INITIAL_SKILL_KEY = 'tuiInitialSkill'

/**
 * Optional terminal-local interaction service provided by one mounted TUI.
 *
 * The concrete provider retains pi-tui, focus, and terminal lifecycle state.
 * Plugins receive only effect-owned overlay sessions.
 */
export abstract class TuiExtensionService extends Service {
  /** Exact agent driven by this terminal instance. */
  abstract readonly agent: Agent

  /**
   * Queue an interactive overlay owned by the calling plugin fiber.
   *
   * The TUI displays one overlay at a time in FIFO order. Disposing the caller
   * removes a queued overlay or closes an active one before plugin teardown
   * settles. This live presentation is neither logged nor replayed.
   *
   * @param request - component factory, layout constraints, and cancellation.
   * @returns the effect-owned overlay session.
   * @throws when the TUI has begun shutting down.
   */
  abstract openOverlay(request: TuiOverlayRequest): TuiOverlaySession
}

export const name = 'ui-tui'
export const inject = ['agents', 'sessions', 'commands', 'userQuestions', 'tools', 'llm', 'systemPrompt', 'tokenMeter', 'tuiPrompt', 'workspaceRegistry', TUI_WORKSPACE_STARTUP_KEY]

/** Model guidance for path-only file references selected through the TUI. */
export const FILE_REFERENCE_PROMPT = 'Paths prefixed with @ are files explicitly referenced by the user. Use the read tool when their contents are needed; do not claim to have inspected a file before reading it.'

/** Width/height adapter for a modal component rendered inside the base TUI flow. */
class InlineModalComponent extends Container {
  constructor(
    component: Component,
    private readonly width: number,
    private readonly maxHeight: number,
  ) {
    super()
    this.addChild(component)
  }

  override render(width: number): string[] {
    const lines = super.render(Math.max(1, Math.min(width, this.width)))
    return lines.slice(0, Math.max(1, this.maxHeight))
  }
}

/** Lifecycle handle for a mounted interactive terminal channel. */
export interface TuiController {
  /** Stop rendering, restore the terminal, and reject pending questions. */
  dispose(): Promise<void>
}

interface TuiConstructionState {
  failed: boolean
}

/**
 * One live session's full per-session state: the chat channel, the per-session
 * docks, the approval answerer that claims only this slot's agent, and the
 * agent-scoped listeners (model routing, the @-file prompt section). Built by
 * the slot factory, swapped under the shared chrome by the channel registry.
 */
export interface TuiSessionSlot extends SessionSlot {
  /** Model and reasoning selection owned only by this session. */
  readonly target: ModelSelectionRef
  /** Transcript channel: chat container, todo strip, session listeners. */
  readonly channel: SessionChannel
  /** The goal dock (Ctrl+G actions) for this session. */
  readonly goalBar: GoalBarController
  /** The next-turn queue dock for this session. */
  readonly queueDock: QueueDockController
  /** Latest ordinary editor submission used by empty-input Up recall. */
  lastSubmission: { readonly text: string; readonly messageId: MessageId } | undefined
  /** Persisted images waiting for this session's next user message. */
  readonly imageDraft: ImageDraft
  /** Answers `approval/request` for this slot's agent only. */
  readonly approvals: ApprovalAnswerer
  /** Disposer for this agent's model-selection waterfall listeners. */
  readonly disposeTargetListeners: () => void
  /** The @-file reference prompt section fiber on this agent's scope. */
  readonly fileReferenceFiber: Fiber
}

/**
 * Start the interactive pi-tui channel for an already-created target agent.
 * @param ctx - agent, tools, session-event, and user-interaction context.
 * @param config - target agent, banner, and TUI presentation config.
 * @param runtime - terminal and process-exit boundary.
 * @returns lifecycle controller used by the Cordis effect disposer.
 */
export function createTuiChat(
  ctx: Context,
  config: Config,
  runtime: TuiRuntime,
): TuiController {
  const construction: TuiConstructionState = { failed: false }
  try {
    return createTuiChatInternal(ctx, config, runtime, construction)
  } catch (error: unknown) {
    construction.failed = true
    throw error
  }
}

/** Build the TUI while the exported entry point owns construction rollback state. */
function createTuiChatInternal(
  ctx: Context,
  config: Config,
  runtime: TuiRuntime,
  construction: TuiConstructionState,
): TuiController {
  const sessionId = SessionId(config.sessionId ?? 'main')
  const initialAgent = ctx.agents.get(sessionId)
  if (initialAgent === undefined) throw new Error(`ui-tui: session "${sessionId}" is not running`)
  // The initial agent the TUI starts on; the channel registry reassigns this
  // (with the channel/dock lets below) every time the mounted session switches,
  // so chrome closures reading them per call always route to the session on
  // screen. Construction-time captures are the slot factory's own instances.
  let agent: Agent = initialAgent
  const resolved = resolveTuiConfig(config)
  // Named-theme state: `undefined` is the adaptive `deepseek` default.
  const initialPreset = resolved.theme.name === 'deepseek' ? undefined : THEME_PRESETS[resolved.theme.name]
  let currentPreset: ThemePreset | undefined = initialPreset
  let currentThemeName = initialPreset === undefined ? 'deepseek' : resolved.theme.name
  // The terminal's probed background (OSC 11); the bubble fill mixes from it.
  let terminalBackground: RgbColor | undefined
  const paletteOptions = (): PaletteOptions => ({
    ...currentPreset === undefined ? {} : { preset: currentPreset },
    truecolor: resolved.theme.truecolor,
    ...terminalBackground === undefined ? {} : { background: terminalBackground },
  })
  const palette = createPalette(resolved.theme.color, 'dark', paletteOptions())
  // The highlighter reads the live palette per call; once the lazily-loaded
  // module lands, blocks that rendered plain get a transcript rebuild.
  const codeHighlighter = createCodeHighlighter(palette, resolved.theme.color, () => {
    if (!disposed) rebuildTranscript(false)
  })
  const mdTheme = markdownTheme(palette, codeHighlighter.highlightCode)
  codeHighlighter.preload()
  const workbenchRows = (): number => Math.max(0, runtime.terminal.rows - 2)
  const ui = new TUI(new FullScreenTerminal(runtime.terminal), resolved.showHardwareCursor)
  const todoContainer = new Container()
  const mainOverlayContainer = new Container()
  const questionContainer = new Container()
  const auxiliary = new Container()
  const inputArea = new Container()
  const inputTemplate = parseTuiPromptTemplate(displayInlineText(resolved.theme.inputPrompt))
  /**
   * Read one prompt value for a render. A render that races the final teardown
   * (the TUI's debounced render timer firing while the owning context goes
   * away) must not crash the process: the service read degrades to an unset
   * fragment and the stale frame renders without it.
   */
  const safePromptValue = (valueName: string): string | undefined => {
    try {
      return ctx.tuiPrompt.get(valueName)
    } catch {
      return undefined
    }
  }
  const renderInputPrompt = (): string => renderTuiPromptTemplate(inputTemplate, safePromptValue)
  const initialInputPrompt = renderInputPrompt()
  let currentInputPrompt = initialInputPrompt
  const editor = new HintEditor(ui, {
    borderColor: palette.dim,
    selectList: selectTheme(palette),
  } satisfies EditorTheme, {
    paddingX: 1,
    frame: 'none',
    prompt: {
      first: initialInputPrompt,
      continuation: ' '.repeat(visibleWidth(initialInputPrompt)),
    },
  })
  editor.hintPrefix = initialInputPrompt
  const compactionStatusLine = new Text('', 0, 0)
  let showReasoning = resolved.showReasoning
  // Ctrl+O switches between compact previews and full tool-card bodies.
  let toolsVisibility: ToolCardVisibility = 'collapsed'
  let disposed = false
  let shuttingDown: Promise<void> | undefined
  // Optional: skills mount conditionally, so read the global service store
  // rather than declaring an injection that would make the TUI require them.
  const skills = ctx.get('skills')
  const initialCwd = agent.session.header.cwd
    ?? (agent.session.id === ASSISTANT_SESSION_ID ? resolved.assistantCwd : process.cwd())
  const activeSessionCwd = (): string | undefined => agent.session.header.cwd
  const activeCwd = (): string => activeSessionCwd() ?? initialCwd
  const fileSearchConfig = {
    maxResults: resolved.fileSearchMaxResults,
    maxEntries: resolved.fileSearchMaxEntries,
    excludedDirectories: resolved.fileSearchExcludedDirectories,
  }
  let fileSearch = new WorkspaceFileSearch(initialCwd, fileSearchConfig)
  const skillAbort = new AbortController()
  const commandControllers = new Set<AbortController>()
  const referenceControllers = new Set<AbortController>()
  let tuiServiceFiber: Fiber | undefined
  const initialTargetRef: ModelSelectionRef = { current: initialTarget(agent), assembled: undefined }
  let activeTargetRef = initialTargetRef
  const target: ModelSelectionRef = {
    get current() { return activeTargetRef.current },
    set current(value) { activeTargetRef.current = value },
    get assembled() { return activeTargetRef.assembled },
    set assembled(value) { activeTargetRef.assembled = value },
  }
  // `updatePromptValues` (defined below) closes over the model controller, but
  // the controller needs `appendNotice`/`overlayManager`, defined after that
  // closure. Declare here, assign once after those exist, and defer the first
  // `updatePromptValues()` call until after the assignment so no read precedes it.
  // oxlint-disable-next-line prefer-const -- single assignment is a forward-reference, not a const.
  let modelController!: ModelController
  // The mounted slot's pieces, assigned by the registry's initial mount and
  // reassigned on every switch. Chrome closures below read them per call, so
  // message dispatch, commands, status, and prompts follow the mounted session.
  let channel!: SessionChannel
  let goalBar!: GoalBarController
  let queueDock!: QueueDockController
  let sessionLayout: SessionLayoutController | undefined
  let workbench: WorkbenchShellComponent | undefined
  const now = (): number => runtime.now?.() ?? Date.now()
  const agentStatus = (): AgentStatus => agent.status
  const isDisposed = (): boolean =>
    disposed || construction.failed || ctx.fiber.state >= FIBER_FAILED

  let sessionTitle = foldSessionTitle(agent.session.events)?.title
  let terminalTitleController: TerminalTitleController | undefined
  const firstSessionCwd = activeSessionCwd()
  let formattedCwd = displayText(runtime.formatCwd?.(firstSessionCwd) ?? formatCwd(firstSessionCwd))
  /**
   * Whether the session log is still pristine: nothing beyond the opening
   * lifecycle prelude (`turn/start`, `step/start`), and no title. The
   * codex-style welcome box greets only a pristine session; any conversation
   * traffic — a prompt, a streamed reply, a tool call, injected context —
   * removes the welcome area entirely.
   */
  const sessionPristine = (): boolean =>
    sessionTitle === undefined
    && agent.session.events.every(event => event.type === 'turn/start' || event.type === 'step/start')
  // The codex-style welcome box's suggested commands, drawn from the commands
  // this bundle actually owns (see the command registrations below).
  const welcomeSuggestions: readonly WelcomeSuggestion[] = [
    { command: '/new', description: 'start another session in this project' },
    { command: '/sessions', description: 'browse complete history' },
    { command: '/model', description: 'switch the model' },
    { command: '/memory', description: 'toggle session memory' },
    { command: '/help', description: 'list every command' },
  ]
  const header = new HeaderComponent(
    () => ({
      welcome: sessionTitle ?? config.welcome,
      model: target.current === undefined ? 'model unset' : compactTargetLabel(target.current),
      ...formattedCwd === undefined ? {} : { directory: formattedCwd },
      suggestions: welcomeSuggestions,
    }),
    palette,
    resolved.theme.color && resolved.theme.truecolor,
  )
  const visibleHeader: Component = {
    invalidate: () => { header.invalidate() },
    render: width => sessionPristine() ? header.render(width) : [],
  }
  let welcomeShimmer: ReturnType<typeof setInterval> | undefined
  let branch: string | undefined
  let branchGeneration = 0
  const branchQueries = new Map<string, Promise<string | undefined>>()
  const queryBranch = (cwd: string): Promise<string | undefined> => {
    const cached = branchQueries.get(cwd)
    if (cached !== undefined) return cached
    let query: Promise<string | undefined>
    try {
      query = runtime.gitBranch === undefined
        ? gitBranch(cwd)
        : Promise.resolve(runtime.gitBranch(cwd))
    } catch {
      query = Promise.resolve(undefined)
    }
    query = query.catch(() => undefined)
    branchQueries.set(cwd, query)
    void query.then(() => {
      if (branchQueries.get(cwd) === query) branchQueries.delete(cwd)
    })
    return query
  }
  const promptValues: TuiPromptValueHandle[] = [
    ctx.tuiPrompt.register('cwd', formattedCwd === undefined ? undefined : palette.dim(formattedCwd)),
    ctx.tuiPrompt.register('git/worktree', branch === undefined ? undefined : palette.dim(` (${displayText(branch)})`)),
    ctx.tuiPrompt.register('token_meter/cache_hit_rate'),
    ctx.tuiPrompt.register('model'),
    ctx.tuiPrompt.register('context'),
    ctx.tuiPrompt.register('queued'),
    ctx.tuiPrompt.register('indicator', palette.dim('> ')),
    ctx.tuiPrompt.register('permission'),
    ctx.tuiPrompt.register('plan'),
    ctx.tuiPrompt.register('throughput'),
    ctx.tuiPrompt.register('memory'),
  ]
  const [
    cwdValue, gitValue, tokenValue, modelValue, contextValue, queuedValue,
    indicatorValue, permissionValue, planValue, throughputValue, memoryValue,
  ] = promptValues
  /* v8 ignore next -- the fixed built-in registration list always supplies each handle. */
  if (cwdValue === undefined || gitValue === undefined || tokenValue === undefined || modelValue === undefined
    || contextValue === undefined || queuedValue === undefined || indicatorValue === undefined
    || permissionValue === undefined || planValue === undefined || throughputValue === undefined || memoryValue === undefined) {
    throw new Error('TUI prompt built-ins failed to initialize')
  }
  /**
   * The context-pressure projection when the projection registry is mounted
   * (the base bundle always mounts it): projected next-request tokens over the
   * route's context window. Absent, callers fall back to the token-meter
   * measure the footer already uses.
   */
  const contextPressure = (): { projectedTokens?: number; pressureTokens?: number; contextWindow?: number } | undefined => {
    const projections = ctx.get('sessionProjections')
    if (projections === undefined) return undefined
    try {
      const snapshot = (projections as {
        snapshot?: (session: unknown) => { values?: Record<string, unknown> } | undefined
      }).snapshot?.(agent.session)
      const pressure = snapshot?.values?.contextPressure
      return pressure === undefined ? undefined : pressure as NonNullable<ReturnType<typeof contextPressure>>
    } catch {
      // An unavailable projection never breaks the prompt footer.
      return undefined
    }
  }

  const updateDynamicPromptValues = (renderTime: number, occupancy?: number): void => {
    const throughput = channel.liveTokenRate()
    throughputValue.set(throughput === undefined ? undefined : palette.text(`  ${throughput} tok/s`))
    if (channel.isCompacting()) {
      compactionStatusLine.setText(palette.dim(
        `Context being compacted ${formatStatusDuration(renderTime - (channel.compactingStartedAt() ?? renderTime))}`,
      ))
    } else if (occupancy !== undefined) {
      compactionStatusLine.setText(contextPressureLevel(occupancy) === 'critical'
        ? palette.error(
            `Context low · ${Math.round(occupancy)}% used`
            + (ctx.commands.list(agent).some(command => command.name === 'compact') ? ' · run /compact to free space' : ''),
          )
        : '')
    }
    const statusGlyph = runningPhaseGlyph(
      agent.session.events,
      channel.isRunning(),
      channel.isCompacting(),
    )
    channel.noteRenderedStatusGlyph(statusGlyph)
    const envelope = channel.statusGlyphEnvelope(statusGlyph, renderTime)
    const caret = envelope === undefined
      ? palette.dim('>')
      : fadeGlyph(
        envelope.glyph,
        palette,
        resolved.theme.color,
        resolved.theme.color && resolved.theme.truecolor,
        envelope.level * pulseLevel(renderTime),
        envelope.level >= 0.5,
      )
    indicatorValue.set(`${caret}${palette.dim(' ')}`)
  }

  const updatePromptValues = (): void => {
    const renderTime = now()
    sessionLayout?.refresh()
    const tokens = channel.tokens()
    cwdValue.set(formattedCwd === undefined ? undefined : palette.dim(formattedCwd))
    gitValue.set(branch === undefined ? undefined : palette.dim(` (${displayText(branch)})`))
    const rate = cacheHitRate(tokens)
    const usage = `↑${formatTokens(tokens.input)} ↓${formatTokens(tokens.output)}`
    const modelGap = formattedCwd === undefined && branch === undefined ? '' : '  '
    modelValue.set(`${modelGap}${palette.text(displayText(target.current === undefined ? 'model unset' : compactTargetLabel(target.current)))}`)
    tokenValue.set(`  ${palette.dim(rate === undefined ? usage : `${usage}  cache ${rate}%`)}`)
    const pressure = contextPressure()
    const usedTokens = pressure?.projectedTokens ?? pressure?.pressureTokens
      ?? ctx.tokenMeter.measure(agent.session).totalTokens
    const effectiveWindow = pressure?.contextWindow ?? modelController.contextWindow()
    const occupancy = effectiveWindow === undefined || effectiveWindow <= 0
      ? undefined
      : Math.min(100, usedTokens / effectiveWindow * 100)
    if (occupancy === undefined) {
      contextValue.set(undefined)
    } else {
      // The meter segments and the percent number share the pressure color
      // (dim → warning → error); the surrounding text stays dim. Colored
      // pieces are concatenated rather than nested (single-Colored rule).
      const level = contextPressureLevel(occupancy)
      const percentText = `${Math.round(occupancy)}%`
      const percent = level === 'critical'
        ? palette.error(percentText)
        : level === 'warning'
          ? palette.warning(percentText)
          : palette.dim(percentText)
      contextValue.set(`  ${contextMeter(occupancy, palette)} ${percent}${palette.dim(' context')}`)
    }
    const queued = channel.isRunning() ? formatSteeringStatus(channel.pendingSteeringCount()) : undefined
    queuedValue.set(queued === undefined ? undefined : palette.dim(queued))
    // Shift+Tab's preset ring and the plan-mode chip; absent services render nothing.
    const preset = permissionController.chip()
    permissionValue.set(preset === undefined || preset === 'custom' ? undefined : palette.dim(` [${preset}]`))
    const planActive = foldPlanMode(agent.session.events)
    planValue.set(planActive
      ? palette.bold(palette.plan('  ⎇ plan'))
      : undefined)
    // The `${memory}` fragment keeps the session's memory switch visible after
    // the transient /memory notice fades; an absent service or a disabled
    // switch renders nothing so the status row stays clean.
    const memory = memoryService()
    memoryValue.set(memory !== undefined && memory.isEnabled(agent.session.id)
      ? palette.dim(' mem on')
      : undefined)
    sessionLayout?.updateStatus({
      status: agent.status,
      inputTokens: tokens.input,
      outputTokens: tokens.output,
      cacheHitRate: rate,
      permission: preset,
      plan: planActive,
    })
    updateDynamicPromptValues(renderTime, occupancy)
  }
  const promptContext = new PromptContextComponent(
    parseTuiPromptTemplate(displayInlineText(resolved.theme.leftPrompt)),
    parseTuiPromptTemplate(displayInlineText(resolved.theme.rightPrompt)),
    valueName => safePromptValue(valueName),
  )
  auxiliary.addChild(todoContainer)
  // Docks (goal bar, steering queue) mount into this slot in order once their
  // controllers exist; an empty container renders nothing.
  const docks = new Container()
  auxiliary.addChild(docks)
  auxiliary.addChild(compactionStatusLine)
  // The working line mounts above the editor inside the input area; the right
  // sidebar carries only session navigation and the status summary.
  const workingLine = new WorkingLineComponent(palette, now)
  const editorFrame = new FramedEditorComponent(editor)
  inputArea.addChild(workingLine)
  inputArea.addChild(editorFrame)
  inputArea.addChild(promptContext)
  ui.setFocus(editor)
  const updateTerminalTitle = (): void => {
    terminalTitleController?.sync()
  }
  // Session channels report progress edges through the process-wide title
  // controller. Its registry-derived count prevents an idle foreground session
  // from clearing taskbar progress while background work is still running.
  const terminalProgress = {
    setProgress(_active: boolean): void { updateTerminalTitle() },
  }

  /**
   * Request a frame. The default path also refreshes every prompt value and
   * the editor prompt; a light tick (the welcome reveal/shimmer animation)
   * only repaints, so the token meter, session layout, and prompt templates
   * do not recompute on every animation frame.
   */
  const refreshPromptSurface = (): void => {
    const inputPrompt = renderInputPrompt()
    if (inputPrompt !== currentInputPrompt) {
      currentInputPrompt = inputPrompt
      editor.setPrompt({ first: inputPrompt, continuation: ' '.repeat(visibleWidth(inputPrompt)) })
      editor.hintPrefix = inputPrompt
    }
    promptContext.invalidate()
  }
  const requestRender = (light = false): void => {
    if (isDisposed()) return
    if (!light) {
      updatePromptValues()
      refreshPromptSurface()
    }
    ui.requestRender()
  }
  const requestStatusRender = (): void => {
    if (isDisposed()) return
    updateDynamicPromptValues(now())
    refreshPromptSurface()
    ui.requestRender()
  }
  const refreshBranch = (cwd: string | undefined): void => {
    const generation = ++branchGeneration
    branch = undefined
    if (cwd === undefined) return
    void queryBranch(cwd).then(value => {
      if (isDisposed() || generation !== branchGeneration) return
      branch = value
      requestRender()
    })
  }
  // A prompt value that changes on its own schedule (e.g. a plugin-owned
  // `${custom}` fragment) redraws through the registry's coalesced notification;
  // built-ins are already covered by the state-change callers of requestRender.
  const disposePromptChanges = ctx.tuiPrompt.subscribe(() => {
    if (isDisposed()) return
    refreshPromptSurface()
    ui.requestRender()
  })
  refreshBranch(activeSessionCwd())

  const appendNotice = (message: string, kind: 'info' | 'warning' | 'error' = 'info'): void => {
    const color = kind === 'error' ? palette.error : kind === 'warning' ? palette.warning : palette.dim
    // The mounted channel's transcript: a notice about any session (including
    // a backgrounded one) lands where the user is looking.
    channel.chat.addChild(new Spacer(1))
    channel.chat.addChild(new Text(color(displayText(message)), 0, 0))
    requestRender()
  }

  // Claude Code's Notifications slot: one transient row at the very bottom for
  // lightweight operation receipts (state-switch feedback) that must not
  // pollute the durable transcript. Errors, warnings, and anything the user
  // may need to scroll back to keep going through appendNotice.
  const noticeSlot = new NoticeSlotComponent(palette, requestRender, resolved.theme.color && resolved.theme.truecolor)
  inputArea.addChild(noticeSlot)
  const showTransientNotice = (message: string, kind: NoticeKind = 'info'): void => {
    noticeSlot.show(message, kind)
  }

  const extensionTheme: TuiTheme = Object.freeze({
    text: (value: string) => palette.text(value),
    brand: (value: string) => resolved.theme.color
      ? resolved.theme.truecolor ? brandText(value) : palette.brand(value)
      : value,
    dim: (value: string) => palette.dim(value),
    accent: (value: string) => palette.accent(value),
    success: (value: string) => palette.success(value),
    warning: (value: string) => palette.warning(value),
    error: (value: string) => palette.error(value),
    bold: (value: string) => palette.bold(value),
  })
  const overlayManager = new TuiOverlayManager({
    viewport: () => Object.freeze({
      columns: runtime.terminal.columns,
      rows: runtime.terminal.rows,
    }),
    theme: () => extensionTheme,
    display: displayText,
    show: (component, options, placement) => {
      if (placement === 'overlay') {
        return ui.showOverlay(component, options === undefined
          ? undefined
          : {
            ...options,
            ...typeof options.margin === 'object'
              ? { margin: { ...options.margin } }
              : {},
          })
      }
      if (placement === 'main') {
        mainOverlayContainer.clear()
        mainOverlayContainer.addChild(component)
        ui.setFocus(component)
        return {
          hide(): void {
            mainOverlayContainer.clear()
            ui.setFocus(editor)
          },
        }
      }
      const modal = new InlineModalComponent(
        component,
        resolved.questionDialogWidth,
        resolved.questionDialogMaxHeight,
      )
      questionContainer.clear()
      questionContainer.addChild(modal)
      ui.setFocus(component)
      return {
        hide(): void {
          questionContainer.clear()
          ui.setFocus(editor)
        },
      }
    },
    invalidate: requestRender,
    reportError: (error) => {
      const message = errorChain(error)
      ctx.logger.warn(`ui-tui: overlay failed: ${message}`)
      /* v8 ignore next -- shutdown removes overlays before the terminal stops */
      if (disposed) return
      appendNotice(`TUI overlay failed: ${message}`, 'error')
    },
  })

  modelController = createModelController({
    ctx,
    resolved,
    palette,
    overlayManager,
    target,
    appendNotice,
    requestRender,
    isDisposed,
    showTransientNotice,
  })

  // Shift+Tab preset ring with the danger-preset risk confirmation overlay.
  const permissionController = createPermissionController({
    ctx, resolved, palette, overlayManager, requestRender, isDisposed, appendNotice,
    get agent(): Agent { return agent },
    confirmRisk: (message, onChoice) => {
      const session = overlayManager.open({
        create: () => new ConfirmDialog(
          'Full access',
          message,
          palette,
          onChoice,
          () => { void session.close() },
        ),
        options: { width: 64, maxHeight: 12 },
      }, 'inline')
      requestRender()
    },
  })

  // Insight surfaces (/context, /agents, /jobs, /settings, /export, stats
  // strip). `agent` is a getter: every insight handler re-reads the mounted
  // session at call time, so the surfaces follow a /sessions switch.
  const insights: InsightsDeps = {
    ctx, resolved, palette, overlayManager, requestRender, isDisposed, appendNotice,
    get agent(): Agent { return agent },
  }

  /** Resolve one stored image attachment's bytes through the optional store. */
  const loadAttachmentImage = (ref: ImageAttachmentRef): Promise<Uint8Array | undefined> => {
    const attachments = ctx.get('attachments') as {
      readImage?: (ref: ImageAttachmentRef, signal?: AbortSignal) => Promise<{ data: Uint8Array }>
    } | undefined
    if (attachments?.readImage === undefined) return Promise.resolve(undefined)
    return attachments.readImage(ref).then(
      stored => stored.data,
      () => undefined,
    )
  }

  /**
   * The @-file prompt-section fibers by agent context: one registration per
   * distinct context, so agents sharing a context (embedders, fakes) do not
   * collide on the section's global name.
   */
  const fileReferenceFibers = new Map<Context, Fiber>()

  /** Memory tool registrations owned by each live session slot. */
  const memoryScopes = new Map<SessionId, MemoryScopeDisposer>()

  const memoryService = (): TuiMemoryService | undefined =>
    ctx.get('memory') as TuiMemoryService | undefined

  /** Match one live agent's tool scope to its persisted memory switch. */
  const syncMemoryScope = (slotAgent: Agent): void => {
    const memory = memoryService()
    if (memory === undefined) return
    const sessionId = slotAgent.session.id
    const installed = memoryScopes.get(sessionId)
    if (memory.isEnabled(sessionId)) {
      if (installed === undefined) memoryScopes.set(sessionId, memory.installTools(slotAgent.ctx))
      return
    }
    if (installed === undefined) return
    memoryScopes.delete(sessionId)
    void Promise.resolve(installed()).catch((error: unknown) => {
      if (!isDisposed()) appendNotice(`Memory cleanup failed: ${errorChain(error)}`, 'warning')
    })
  }

  /**
   * Register the @-file reference prompt section on one agent's scope, or
   * return the existing fiber when that context already carries one.
   */
  const registerFileReferenceSection = (slotAgent: Agent): Fiber => {
    const existing = fileReferenceFibers.get(slotAgent.ctx)
    if (existing !== undefined) return existing
    const fiber = slotAgent.ctx.inject(['systemPrompt'], (promptCtx) => {
      promptCtx.systemPrompt.section({
        name: 'ui:tui-file-reference',
        order: 99,
        // Tool visibility can change dynamically or by agent scope. Empty
        // sections are omitted by renderPrompt, so guidance never names a
        // tool that this agent cannot call.
        text: () => slotAgent.ctx.tools.get('read', slotAgent) === undefined ? '' : FILE_REFERENCE_PROMPT,
      })
    })
    fileReferenceFibers.set(slotAgent.ctx, fiber)
    return fiber
  }

  /**
   * Build one live session's full slot: its chat channel (transcript, cards,
   * status state machine), its per-session docks, the approval answerer that
   * claims only this agent's asks, this agent's model-selection routing, and
   * its @-file prompt section. Called by the registry for the initial session
   * and for every `/new` adoption; the returned pieces are swapped under the
   * shared chrome by {@link mountSlot}/{@link unmountSlot}.
   */
  const buildSlot = (slotAgent: Agent): TuiSessionSlot => {
    // The registry is assigned by the createChannelRegistry call below; these
    // closures only run on session events, which cannot fire before it exists.
    const isActiveAgent = (): boolean =>
      /* v8 ignore next -- the registry exists before any session event fires. */
      registry === undefined || registry.active().agent === slotAgent
    const slotGoalBar = createGoalBar({ ctx, resolved, palette, overlayManager, requestRender, isDisposed, appendNotice, agent: slotAgent })
    const slotQueueDock = createQueueDock({
      ctx, resolved, palette, overlayManager, requestRender, isDisposed, appendNotice, agent: slotAgent,
      loadIntoEditor: (text) => {
        editor.setText(text)
        requestRender()
      },
      showTransientNotice,
    })
    // The per-session chat channel: transcript container, streaming/tool/
    // context cards, turn status, token totals, and the session-scoped
    // listeners. Every chrome callback it reads (docks, notices, spinner
    // working line) either belongs to this slot or gates on the slot being
    // mounted, so a backgrounded session never repaints the foreground chrome.
    const slotChannel: SessionChannel = createSessionChannel({
      ctx,
      agent: slotAgent,
      resolved,
      palette,
      mdTheme,
      now,
      terminal: terminalProgress,
      requestRender,
      requestStatusRender,
      appendNotice,
      loadAttachmentImage,
      addToEditorHistory: (text) => {
        editor.addToHistory(text)
      },
      refreshGoalBar: () => {
        slotGoalBar.refresh()
      },
      refreshQueueDock: () => {
        slotQueueDock.refresh()
        if (isActiveAgent()) applyEditorHint()
      },
      onSessionTitle: (title) => {
        if (!isActiveAgent()) return
        sessionTitle = title
        header.invalidate()
        updateTerminalTitle()
      },
      onToolResult: () => {
        fileSearch.invalidate()
      },
      applyStatus: (status) => {
        if (isActiveAgent()) setStatus(status)
      },
      showReasoning: () => showReasoning,
      toolsVisibility: () => toolsVisibility,
      onSpinnerFrame: (running, startedAt, label, frame, extras) => {
        if (!isActiveAgent()) return
        workingLine.update(running, startedAt, label, frame, extras)
      },
      onSpinnerIdle: () => {
        if (!isActiveAgent()) return
        workingLine.update(false, undefined, undefined, undefined)
      },
      onAgentError: (error) => {
        // Full cause chain: wrapper messages like `fetch failed` carry the
        // actionable transport detail on `cause`.
        appendNotice(errorChain(error), 'error')
      },
      onAgentDisposed: () => {
        appendNotice(`Agent "${slotAgent.id}" was disposed.`, 'warning')
        // Only the mounted session's disposal ends the TUI; a backgrounded
        // slot losing its agent is a notice, not a shutdown.
        if (isActiveAgent()) disposed = true
      },
    })
    const slotTarget = slotAgent === initialAgent
      ? initialTargetRef
      : { current: initialTarget(slotAgent), assembled: undefined }
    syncMemoryScope(slotAgent)
    return {
      sessionId: slotAgent.session.id,
      agent: slotAgent,
      target: slotTarget,
      channel: slotChannel,
      goalBar: slotGoalBar,
      queueDock: slotQueueDock,
      lastSubmission: undefined,
      imageDraft: new ImageDraft(),
      approvals: createApprovalAnswerer({
        ctx,
        resolved,
        palette,
        overlayManager,
        requestRender,
        isDisposed,
        appendNotice,
        agent: slotAgent,
        questionMaxHeight: () => {
          return Math.max(1, Math.min(
            resolved.questionDialogMaxHeight,
            workbenchRows(),
          ))
        },
        pendingCallLabel: callId => slotChannel.toolCardLabel(callId),
      }),
      disposeTargetListeners: installModelSelection(slotAgent.ctx, slotTarget),
      // The @-file reference section registers on the agent's own scope (the
      // per-agent override the systemPrompt registry names in its collision
      // error). Agents sharing one context (embedders, fakes) share the first
      // registration — the section's text() is agent-scoped either way.
      fileReferenceFiber: registerFileReferenceSection(slotAgent),
    }
  }

  // The registry mounts its initial slot before returning. That first mount
  // uses the chat directly; once the registry exists, startup replaces it
  // synchronously with the persistent workbench before the terminal starts.
  /** Wire one slot's components into the shared chrome and start its listeners. */
  const mountSlot = (slot: TuiSessionSlot): void => {
    // Publish the mounted slot before attach: listener callbacks and repaint
    // requests must always observe the channel that owns the mounted UI.
    agent = slot.agent
    activeTargetRef = slot.target
    channel = slot.channel
    goalBar = slot.goalBar
    queueDock = slot.queueDock
    workbench?.setTranscript(slot.channel.chat)
    todoContainer.addChild(slot.channel.todo)
    docks.addChild(slot.goalBar.component)
    docks.addChild(slot.queueDock.component)
    slot.channel.attach()
  }

  /** Unwire one slot's components and stop its session listeners (switch-away). */
  const unmountSlot = (slot: TuiSessionSlot): void => {
    slot.channel.detach()
    todoContainer.clear()
    docks.clear()
  }

  /** Final teardown for one slot (eviction or shutdown): scoped listeners and overlays. */
  const disposeSlot = (slot: TuiSessionSlot): void => {
    // A detached slot can still own a running/compaction animation when it is
    // removed immediately after cancellation. Clear the channel state before
    // releasing the rest of its scoped resources so no interval survives the
    // slot's lifetime.
    slot.channel.clearStatus()
    slot.approvals.drain()
    slot.approvals.unregister()
    slot.goalBar.dispose()
    slot.queueDock.dispose()
    slot.disposeTargetListeners()
    const memoryScope = memoryScopes.get(slot.sessionId)
    if (memoryScope !== undefined) {
      memoryScopes.delete(slot.sessionId)
      void Promise.resolve(memoryScope()).catch(() => {})
    }
    for (const [context, registered] of fileReferenceFibers) {
      if (registered === slot.fileReferenceFiber) fileReferenceFibers.delete(context)
    }
    // A shared registration (agents on one context) reaches this disposal
    // through each sharing slot; an already-disposed fiber returns nothing or
    // throws, and either way the section is gone.
    try {
      void Promise.resolve(slot.fileReferenceFiber.dispose()).catch(() => {})
    } catch {
      /* already disposed through a sharing sibling slot */
    }
  }

  // The multi-session registry: one slot per live in-process session, swapped
  // under this shared chrome. Sessions live with the process by design —
  // `/sessions` owns live switching and persisted history in one surface.
  const registry: ChannelRegistry<TuiSessionSlot> = createChannelRegistry<TuiSessionSlot>({
    buildSlot,
    mount: mountSlot,
    unmount: unmountSlot,
    dispose: disposeSlot,
    onActiveChange(previous, next) {
      agent = next.agent
      channel = next.channel
      goalBar = next.goalBar
      queueDock = next.queueDock
      // The startup path (rebuild, prompt values, initial setStatus) already
      // covers the first activation; switches refresh the chrome here.
      if (previous === undefined) return
      // The switched-in channel was detached while backgrounded: re-derive
      // its transcript from the log so events it missed render now.
      next.channel.syncTranscript(false)
      void ctx.sessions.flush(previous.agent.session).catch(() => {})
      const nextSessionCwd = next.agent.session.header.cwd
      const nextCwd = nextSessionCwd ?? initialCwd
      fileSearch.dispose()
      fileSearch = new WorkspaceFileSearch(nextCwd, fileSearchConfig)
      formattedCwd = displayText(runtime.formatCwd?.(nextSessionCwd) ?? formatCwd(nextSessionCwd))
      refreshBranch(nextSessionCwd)
      sessionTitle = foldSessionTitle(next.agent.session.events)?.title
      modelController.activateSelection()
      header.invalidate()
      updateTerminalTitle()
      setStatus(next.agent.status, false)
      refreshCommandAutocomplete()
      if (skills !== undefined) refreshSkillCommands(skills)
      next.goalBar.refresh()
      refreshQueueDock()
      requestRender()
    },
    maxLiveSlots: DEFAULT_MAX_LIVE_SLOTS,
    onEvictionSkipped: (liveCount) => {
      appendNotice(`Live-session ceiling reached (${liveCount}); every background session is busy, keeping them all.`, 'warning')
    },
  }, agent)

  terminalTitleController = createTerminalTitleController({
    terminal: runtime.terminal,
    productTitle: resolved.title,
    activeTitle: () => sessionTitle
      ?? (agent.session.id === ASSISTANT_SESSION_ID ? 'Assistant' : undefined),
    runningCount: () => registry.slots().filter(slot =>
      slot.agent.status === 'running' || slot.channel.isCompacting()).length,
  })
  updateTerminalTitle()

  // A queued session reference must not inject its context into the currently
  // running turn. Hold it by prompt identity and inject it synchronously after
  // that turn closes, before the next queued turn claims its first step.
  const queuedReferenceContexts = new Map<MessageId, { readonly agent: Agent; readonly context: UserMessage }>()

  const workspaceSessions = createWorkspaceSessions(ctx)

  // Handles for agents this TUI created through the factory. A rewind
  // replacement disposes its source agent through the recorded handle; agents
  // without one (the config-created startup agent, live re-adoptions) stay
  // registered and remain recoverable through `/sessions`.
  const ownedAgentHandles = new Map<SessionId, AgentHandle>()

  /**
   * Consume one factory handle after publishing its workspace membership and
   * TUI slot. A failed transfer removes only membership added by this call and
   * disposes the handle before rejecting.
   */
  const adoptOwnedAgent = async (
    handle: AgentHandle,
    options: { readonly activate?: boolean; readonly ensureWorkspace?: boolean } = {},
  ): Promise<void> => {
    const sessionId = handle.agent.session.id
    const activate = options.activate ?? true
    const ensureWorkspace = options.ensureWorkspace ?? true
    const previousActive = registry.activeId()
    const alreadyMember = workspaceSessions.has(sessionId)
    let added = false
    try {
      if (ensureWorkspace && !alreadyMember) {
        await workspaceSessions.add(sessionId)
        added = true
      }
      if (isDisposed()) throw new Error('TUI disposed during session activation')
      registry.adopt(handle.agent, activate)
      ownedAgentHandles.set(sessionId, handle)
    } catch (error: unknown) {
      const cleanupErrors: unknown[] = []
      const adopted = registry.get(sessionId)?.agent === handle.agent
      if (adopted) {
        try {
          if (activate) registry.switchTo(previousActive)
          registry.remove(sessionId)
        } catch (cleanupError: unknown) {
          cleanupErrors.push(cleanupError)
        }
      }
      if (added) {
        try {
          await workspaceSessions.remove(sessionId)
        } catch (cleanupError: unknown) {
          cleanupErrors.push(cleanupError)
        }
      }
      try {
        await handle.dispose()
      } catch (cleanupError: unknown) {
        cleanupErrors.push(cleanupError)
      }
      if (cleanupErrors.length > 0) {
        throw new AggregateError([error, ...cleanupErrors], 'Session activation failed and rollback was incomplete.')
      }
      throw error
    }
  }

  if (agent.session.id === ASSISTANT_SESSION_ID) {
    setupAssistant(agent.ctx, registry, workspaceSessions, adoptOwnedAgent, activeCwd())
  }

  /**
   * Start a fresh in-process session (`/new`) and switch to it. The
   * created agent runs the same loop and routing as the initial one; its slot
   * mounts under the shared chrome immediately.
   */
  const newSession = (rawPath = ''): void => {
    const freshId = SessionId(`session-${randomUUID()}`)
    const requested = rawPath.trim()
    const projectCwd = resolve(activeCwd(), requested === '' ? '.' : requested)
    const create = async (): Promise<void> => {
      if (disposed) return
      const handle = await ctx.agents.create({
        sessionId: freshId,
        seed: [],
        meta: { cwd: projectCwd },
      })
      await adoptOwnedAgent(handle)
      showTransientNotice(`New session ${displayText(String(freshId))} in ${displayText(projectCwd)}.`)
    }
    const operation = requested === ''
      ? create()
      : stat(projectCwd).then(async (status) => {
          if (!status.isDirectory()) throw new Error(`not a directory: ${projectCwd}`)
          await create()
        })
    void operation.catch((error: unknown) => {
      if (!disposed) appendNotice(`New session failed: ${errorChain(error)}`, 'error')
    })
  }

  // The personal assistant (`/assistant`): a fixed-id session outside project
  // workspaces, with workspace-management tools and a durable transcript.
  const assistant = createAssistantController({
    ctx,
    registry,
    workspaceSessions,
    appendNotice,
    showTransientNotice,
    isDisposed,
    adoptOwnedAgent,
    assistantCwd: resolved.assistantCwd,
    agentOptions: initialAgent.options,
  })

  // Every live session shares one workbench and swaps only its transcript.
  const persistentLayout = createSessionLayout({
    palette,
    registry,
    workspaceSessions,
    terminalRows: workbenchRows,
    now,
  })
  sessionLayout = persistentLayout
  workbench = new WorkbenchShellComponent(palette, {
    terminalRows: () => runtime.terminal.rows,
    preferredSidebarWidth: resolved.sidebarWidth,
    header: visibleHeader,
    auxiliary,
    main: mainOverlayContainer,
    dialog: questionContainer,
    input: inputArea,
    sidebar: persistentLayout.sidebar,
    sidebarSessionAt: (row, width) => persistentLayout.sidebar.sessionAtRow(row, width),
    transcript: registry.active().channel.chat,
  })
  ui.addChild(workbench)
  persistentLayout.refresh()
  let stoppedTitleScan = 0
  let stoppedTitleAbort: AbortController | undefined
  let stoppedTitleRetry: ReturnType<typeof setTimeout> | undefined
  let stoppedTitleRetryCount = 0
  // Stopped sessions whose latest cold read returned no title. The title may
  // still be in the persistence flush pipeline, so these ids earn a bounded
  // retry plus re-reads on their later title/flush events instead of pinning
  // the bare session id forever.
  const pendingStoppedTitles = new Set<SessionId>()
  let pendingTitleRetry: ReturnType<typeof setTimeout> | undefined
  let pendingTitleRetryCount = 0
  const schedulePendingTitleRetry = (): void => {
    if (
      pendingTitleRetry === undefined
      && pendingStoppedTitles.size > 0
      && pendingTitleRetryCount < STOPPED_TITLE_RETRY_LIMIT
      && !isDisposed()
    ) {
      pendingTitleRetryCount += 1
      pendingTitleRetry = setTimeout(() => {
        pendingTitleRetry = undefined
        refreshStoppedTitles()
      }, STOPPED_TITLE_RETRY_DELAY_MS)
    }
  }
  // A title/flush edge for a pending id means its title pipeline moved:
  // re-read with a fresh retry budget.
  const rereadPendingTitle = (sessionId: SessionId): void => {
    if (!pendingStoppedTitles.has(sessionId)) return
    pendingTitleRetryCount = 0
    refreshStoppedTitles()
  }
  const refreshStoppedTitles = (): void => {
    const query = currentSessionQuery()
    if (query === undefined) {
      if (
        stoppedTitleRetry === undefined
        && stoppedTitleRetryCount < STOPPED_TITLE_RETRY_LIMIT
        && !isDisposed()
      ) {
        stoppedTitleRetryCount += 1
        stoppedTitleRetry = setTimeout(() => {
          stoppedTitleRetry = undefined
          refreshStoppedTitles()
        }, STOPPED_TITLE_RETRY_DELAY_MS)
      }
      return
    }
    stoppedTitleRetryCount = 0
    // The fixed assistant row joins the same cold read whenever no live slot
    // folds its title from memory, so a user-renamed assistant keeps its
    // title while offline.
    const ids = [ASSISTANT_SESSION_ID, ...workspaceSessions.list().map(item => item.sessionId)]
      .filter((sessionId, index, all) => registry.get(sessionId) === undefined && all.indexOf(sessionId) === index)
    // Pending ids that gained a live slot or left the workspace no longer
    // need cold retries.
    for (const pending of [...pendingStoppedTitles]) {
      if (!ids.includes(pending)) pendingStoppedTitles.delete(pending)
    }
    if (ids.length === 0 || typeof query.readTitleSnapshots !== 'function') return
    const scan = ++stoppedTitleScan
    stoppedTitleAbort?.abort()
    const controller = new AbortController()
    stoppedTitleAbort = controller
    void query.readTitleSnapshots(ids, controller.signal).then((results) => {
      if (isDisposed() || controller.signal.aborted || scan !== stoppedTitleScan) return
      const titles = new Map<SessionId, string>()
      let resolvedPending = false
      for (const result of results) {
        if (result.status === 'fulfilled' && result.value.title !== undefined) {
          titles.set(result.sessionId, result.value.title.title)
          if (pendingStoppedTitles.delete(result.sessionId)) resolvedPending = true
        } else if (result.status === 'fulfilled') {
          // No title yet: the flush pipeline may still deliver one.
          pendingStoppedTitles.add(result.sessionId)
        }
      }
      // Progress refills the retry budget; a permanently untitled session
      // still exhausts it and then waits for its own title/flush edge.
      if (resolvedPending) pendingTitleRetryCount = 0
      persistentLayout.setPersistedTitles(titles)
      schedulePendingTitleRetry()
      requestRender()
    }, () => {})
  }
  // Detached channels catch up from their logs when mounted. Background chunks
  // must not wake the foreground; title changes alone affect visible chrome.
  const disposeBackgroundSessionEvents = ctx.on('session/event', (sourceSession, event) => {
    const slot = registry.slots().find(candidate => candidate.agent.session === sourceSession)
    if (slot !== undefined && !registry.isActive(slot)) slot.channel.observeBackgroundEvent(event)
    if (event.type === 'compaction/start' || event.type === 'compaction/end') updateTerminalTitle()
    if (event.type !== 'session/title') return
    rereadPendingTitle(sourceSession.id)
    if (slot !== undefined && !registry.isActive(slot)) requestRender()
  })
  // A pending stopped session that is still live but slotless (LRU-evicted)
  // delivers its title to persistence at the flush checkpoint; re-read there.
  const disposeStoppedTitleFlush = ctx.on('session/flush', (flushed) => {
    rereadPendingTitle(flushed.id)
  })
  const disposeQueuedReferenceTurns = ctx.on('session/event', (sourceSession, event) => {
    if (event.type !== 'turn/end') return
    const slot = registry.slots().find(candidate => candidate.agent.session === sourceSession)
    const next = slot?.agent.inbox.nextTurn[0]
    if (slot === undefined || next === undefined) return
    const pending = queuedReferenceContexts.get(next.id)
    if (pending === undefined || pending.agent !== slot.agent) return
    queuedReferenceContexts.delete(next.id)
    slot.agent.inject(pending.context)
  })
  const disposeQueuedReferenceDiscards = ctx.on('agent/inbox/discarded', ({ message }) => {
    queuedReferenceContexts.delete(message.id)
  })
  const disposeBackgroundStatusChanges = ctx.on('agent/status', ({ agent: source }) => {
    const slot = registry.slots().find(candidate => candidate.agent === source)
    if (slot !== undefined) updateTerminalTitle()
    if (slot !== undefined && !registry.isActive(slot)) requestRender()
  })
  const disposeOwnedAgentChanges = ctx.on('agent/disposed', ({ agent: source }) => {
    const handle = ownedAgentHandles.get(source.session.id)
    if (handle?.agent === source) ownedAgentHandles.delete(source.session.id)
  })
  const disposeWorkspaceChanges = ctx.on('domain/changed', (change) => {
    if (change.domain === 'workspace') {
      stoppedTitleRetryCount = 0
      pendingTitleRetryCount = 0
      refreshStoppedTitles()
      requestRender()
    }
  })

  updatePromptValues()
  refreshStoppedTitles()

  /** Status-priority placeholder text for the empty editor (dim; the hint editor paints it). */
  const editorHintFor = (status: AgentStatus): string => {
    if (status === 'running') return palette.dim(displayInlineText(resolved.theme.inputPlaceholder))
    if (foldPlanMode(agent.session.events)) {
      return palette.dim('plan mode — present a plan; the review runs before any edit')
    }
    // Queued messages are more actionable than examples: ↑ pops the newest
    // one back into the editor (see the input listener's Key.up branch).
    if (queueDock.pendingCount() > 0) return palette.dim('press ↑ to edit queued messages')
    return palette.dim('type / for commands, @ for files')
  }

  /**
   * Re-derive the editor placeholder from the live status, plan mode, and
   * queue. The Ctrl+C/Ctrl+D exit arm hint outranks every status-derived hint
   * for the lifetime of its window; the disarm timeout re-applies this.
   */
  const applyEditorHint = (): void => {
    if (exitArmedAt !== undefined) return
    editor.hint = editorHintFor(agent.status)
  }

  /**
   * Re-derive the queue dock from the inbox and refresh the editor hint with
   * it: the queue-emptying/queue-filling edge is exactly when the idle
   * placeholder flips between the queue hint and the examples hint.
   */
  const refreshQueueDock = (): void => {
    queueDock.refresh()
    applyEditorHint()
  }

  /**
   * Whether the session sits on the danger permission preset. The preset
   * service is optional and its `custom` state names no resolvable preset;
   * either way the border stays dim.
   */
  const dangerPresetActive = (): boolean => {
    const name = permissionController.chip()
    if (name === undefined || name === 'custom') return false
    const service = ctx.get('permissionPresets') as PermissionPresetsService | undefined
    if (service === undefined) return false
    try {
      return service.resolve(name).sandbox === 'danger-full-access'
    } catch {
      // An unhealthy optional provider resolves nothing; the border stays dim.
      return false
    }
  }

  /**
   * The input border flags only the two modes that change what a submission
   * does: plan mode (accent) and the danger permission preset (warning).
   * Running state no longer repaints it — the working line, the sidebar
   * status dot, and the breathing prompt glyph already carry that state, and
   * the border's instant accent flip read as a second, clashing rhythm next
   * to the glyph's pulse.
   */
  const editorBorderColor = (): ((text: string) => string) => {
    if (foldPlanMode(agent.session.events)) return text => palette.plan(text)
    if (dangerPresetActive()) return text => palette.warning(text)
    return text => palette.dim(text)
  }

  const setStatus = (status: AgentStatus, render = true): void => {
    editor.borderColor = editorBorderColor()
    // Running keeps the steering placeholder; idle plan mode carries its own;
    // plain idle carries the queue hint or the example-commands hint.
    applyEditorHint()
    channel.setStatus(status)
    // Publish the active session's state immediately. This also clears a
    // running line retained by the previously mounted session.
    workingLine.update(
      status === 'running',
      status === 'running' ? channel.runningStartedAt() : undefined,
      undefined,
      undefined,
    )
    if (render) requestRender()
  }

  const rebuildTranscript = (populateHistory: boolean): void => {
    channel.rebuildTranscript(populateHistory)
  }
  const clearStatus = (): void => {
    channel.clearStatus()
  }
  const setToolsVisibility = (next: ToolCardVisibility): void => {
    toolsVisibility = next
    // The compact history fold keys off the expanded phase, so a session that
    // ever compacted re-derives its transcript on every phase switch: expanded
    // restores the folded history, the other phases fold it again. The loops
    // below then re-apply the phase to the rebuilt components idempotently.
    if (channel.hasCompactionCheckpoint()) rebuildTranscript(false)
    channel.applyToolsVisibility(toolsVisibility)
    // State-switch feedback: transient receipt, not transcript history.
    showTransientNotice(`Tool and context cards ${toolsVisibility}.`)
  }

  const questions = createQuestionQueue({
    ctx,
    resolved,
    palette,
    overlayManager,
    requestRender,
    isDisposed,
    questionMaxHeight: () => {
      return Math.max(1, Math.min(
        resolved.questionDialogMaxHeight,
        workbenchRows(),
      ))
    },
  })

  // The keyboard answerer behind `approval/request` lives per-slot in the
  // channel registry (each slot claims only its own agent's asks).

  function currentSessionQuery(): SessionQueryEngine | undefined {
    const implementation = ctx.reflect._getImpl('sessionQuery', false)
    if (implementation === undefined || implementation.fiber.state >= FIBER_FAILED) return undefined
    return ctx.get('sessionQuery', false)
  }

  const resume = createResumeController({
    ctx,
    // Getter: /sessions preflights the mounted session, not the initial one.
    get agent(): Agent { return agent },
    runtime,
    resolved,
    palette,
    overlayManager,
    // Optional and independently mounted. Cordis transiently leaves this sibling
    // non-ACTIVE during command callbacks, so the non-strict read is intentional;
    // terminal fiber states still exclude failed, closing, and closed providers.
    sessionQuery: currentSessionQuery,
    workspaceSessions,
    openLive(sessionId): boolean {
      const slot = registry.get(sessionId)
      if (slot !== undefined) return registry.switchTo(sessionId)
      const live = ctx.agents.get(sessionId)
      if (live === undefined) return false
      registry.adopt(live)
      return true
    },
    async openPersisted(sessionId, cwd): Promise<boolean> {
      if (sessionId === ASSISTANT_SESSION_ID) return assistant.open()
      // Tool consumers resolve relative paths from the resumed agent's
      // immutable session cwd, so cross-workspace sessions can resume in this
      // process even on hosts that cannot replace themselves in place.
      const handle = await ctx.agents.resume({ resumeSessionId: sessionId }).catch((error: unknown) => {
        if (resolve(cwd) !== resolve(initialCwd)) return undefined
        throw error
      })
      if (handle === undefined) return false
      await adoptOwnedAgent(handle)
      return true
    },
    ui,
    editor,
    appendNotice,
    requestRender,
    isDisposed,
    agentStatus,
    handoffBlocker(): string | undefined {
      const busy = ctx.agents.list().find(candidate => candidate.status !== 'idle')
      if (busy !== undefined) {
        return `Session "${busy.session.id}" is ${busy.status}; wait for every live session before resume.`
      }
      const compacting = registry.slots().find(slot => slot.channel.isCompacting())
      return compacting === undefined
        ? undefined
        : `Session "${compacting.sessionId}" is compacting; wait for it before resume.`
    },
    async flushLiveSessions(): Promise<void> {
      await Promise.all(ctx.agents.list().map(live => ctx.sessions.flush(live.session)))
    },
  })

  const rewind = createRewindController({
    ctx,
    get agent(): Agent { return agent },
    resolved,
    palette,
    overlayManager,
    appendNotice,
    requestRender,
    isDisposed,
    async activate(handle, prompt, sourceId): Promise<void> {
      const rewoundAgent = handle.agent
      const sourceAgent = registry.get(sourceId)?.agent
      if (sourceAgent === undefined) {
        await handle.dispose()
        throw new Error(`Rewind source "${sourceId}" is no longer live.`)
      }
      try {
        await workspaceSessions.add(rewoundAgent.session.id)
        if (isDisposed()) throw new Error('TUI disposed during rewind')
        registry.adopt(rewoundAgent)
        if (!await workspaceSessions.remove(sourceId)) {
          throw new Error(`Rewind source "${sourceId}" is not in the active workspace.`)
        }
        if (!registry.remove(sourceId)) {
          throw new Error(`Rewind source "${sourceId}" could not leave the live session set.`)
        }
      } catch (error: unknown) {
        const cleanupErrors: unknown[] = []
        if (!workspaceSessions.has(sourceId)) {
          try {
            await workspaceSessions.add(sourceId)
          } catch (cleanupError: unknown) {
            cleanupErrors.push(cleanupError)
          }
        }
        if (registry.get(sourceId) === undefined) {
          try {
            registry.adopt(sourceAgent)
          } catch (cleanupError: unknown) {
            cleanupErrors.push(cleanupError)
          }
        } else if (!registry.switchTo(sourceId)) {
          cleanupErrors.push(new Error('Rewind could not restore the source session.'))
        }
        if (registry.get(rewoundAgent.session.id)?.agent === rewoundAgent) {
          try {
            if (!registry.remove(rewoundAgent.session.id)) {
              cleanupErrors.push(new Error('Rewind could not remove the failed branch session.'))
            }
          } catch (cleanupError: unknown) {
            cleanupErrors.push(cleanupError)
          }
        }
        if (workspaceSessions.has(rewoundAgent.session.id)) {
          try {
            await workspaceSessions.remove(rewoundAgent.session.id)
          } catch (cleanupError: unknown) {
            cleanupErrors.push(cleanupError)
          }
        }
        try {
          await handle.dispose()
        } catch (cleanupError: unknown) {
          cleanupErrors.push(cleanupError)
        }
        if (cleanupErrors.length > 0) {
          throw new AggregateError([error, ...cleanupErrors], 'Rewind failed and rollback was incomplete.')
        }
        throw error
      }
      // Replacement, not accumulation: once the branch is active, the
      // rewound-away session leaves the active workspace list and the
      // live-slot registry, and its agent is disposed when this TUI owns its
      // handle. The source log stays on disk, so /sessions can recover it.
      ownedAgentHandles.set(rewoundAgent.session.id, handle)
      for (const [messageId, pending] of queuedReferenceContexts) {
        if (pending.agent.session.id === sourceId) queuedReferenceContexts.delete(messageId)
      }
      const sourceHandle = ownedAgentHandles.get(sourceId)
      if (sourceHandle !== undefined) {
        ownedAgentHandles.delete(sourceId)
        // The branch is already active; a source teardown failure is a
        // cleanup problem, not a rewind failure.
        await sourceHandle.dispose().catch((error: unknown) => {
          if (!isDisposed()) appendNotice(`Rewound session cleanup failed: ${errorChain(error)}`, 'warning')
        })
      }
      editor.setText(prompt)
      requestRender()
    },
  })

  const activeSessionIds = (): SessionId[] => [
      ASSISTANT_SESSION_ID,
      ...workspaceSessions.list().map(item => item.sessionId),
    ].filter((sessionId, index, all) => all.indexOf(sessionId) === index)

  const activateSession = (sessionId: SessionId): void => {
    if (sessionId === agent.session.id) return
    if (sessionId === ASSISTANT_SESSION_ID) void assistant.open()
    else resume.openSession(sessionId)
  }

  const cycleActiveSession = (offset: -1 | 1): void => {
    const ids = activeSessionIds()
    if (ids.length <= 1) return
    const current = Math.max(0, ids.indexOf(agent.session.id))
    const next = ids[(current + offset + ids.length) % ids.length]
    if (next === undefined || next === agent.session.id) return
    activateSession(next)
  }

  let quittingActiveSession: SessionId | undefined
  const quitCurrentActiveSession = (): void => {
    const source = agent
    const sessionId = source.session.id
    if (sessionId === ASSISTANT_SESSION_ID) {
      showTransientNotice('The assistant session cannot be closed.')
      return
    }
    if (quittingActiveSession !== undefined) return
    if (!workspaceSessions.has(sessionId)) {
      showTransientNotice('This session is not in active sessions.')
      return
    }
    quittingActiveSession = sessionId
    if (source.status === 'running') {
      source.cancel({ kind: 'user' })
      appendNotice('Cancelling the active turn and closing this session…', 'warning')
    }
    void (async () => {
      if (!await assistant.open()) throw new Error('the assistant session could not be opened')
      let removedMembership: boolean
      try {
        removedMembership = await workspaceSessions.remove(sessionId)
      } catch (error: unknown) {
        registry.switchTo(sessionId)
        throw error
      }
      const sourceStillMounted = registry.get(sessionId) !== undefined
      if (sourceStillMounted && !registry.remove(sessionId)) {
        const cleanupErrors: unknown[] = []
        if (removedMembership) {
          try {
            await workspaceSessions.add(sessionId)
          } catch (error: unknown) {
            cleanupErrors.push(error)
          }
        }
        registry.switchTo(sessionId)
        throw cleanupErrors.length === 0
          ? new Error('the closed session remained mounted')
          : new AggregateError(cleanupErrors, 'the closed session remained mounted and workspace membership could not be restored')
      }
      for (const [messageId, pending] of queuedReferenceContexts) {
        if (pending.agent === source) queuedReferenceContexts.delete(messageId)
      }
      const handle = ownedAgentHandles.get(sessionId)
      if (handle !== undefined) {
        ownedAgentHandles.delete(sessionId)
        await handle.dispose().catch((error: unknown) => {
          if (!isDisposed()) appendNotice(`Closed session cleanup failed: ${errorChain(error)}`, 'warning')
        })
      }
      if (!isDisposed()) showTransientNotice('Session closed. History preserved.')
    })().catch((error: unknown) => {
      if (!isDisposed()) appendNotice(`Close session failed: ${errorChain(error)}`, 'error')
    }).finally(() => {
      if (quittingActiveSession === sessionId) quittingActiveSession = undefined
      if (!isDisposed()) requestRender()
    })
  }

  let switchOverlay: TuiOverlaySession | undefined
  const showSessionSwitcher = (): void => {
    const items = sessionLayout?.sessionList.getItems() ?? []
    if (items.length <= 1) {
      showTransientNotice('No other active session.')
      return
    }
    void switchOverlay?.close()
    const session = overlayManager.open({
      create: () => new SessionSwitchDialog(
        items.map(item => ({
          id: item.id,
          title: item.title,
          ...item.kind === 'project' ? { workspace: item.workspace } : {},
          status: item.status,
          current: item.isActive,
        })),
        palette,
        (id) => {
          void session.close()
          activateSession(SessionId(id))
        },
        () => { void session.close() },
      ),
      options: { width: resolved.detailsDialogWidth, maxHeight: resolved.questionDialogMaxHeight },
    }, 'inline')
    switchOverlay = session
    void session.closed.then(() => {
      if (switchOverlay === session) switchOverlay = undefined
    })
    requestRender()
  }

  const runSessionSwitch = (rawInput: string): void => {
    const argument = rawInput.trim()
    if (argument === '') {
      showSessionSwitcher()
      return
    }
    const normalized = argument.toLowerCase()
    if (normalized === 'next') {
      cycleActiveSession(1)
      return
    }
    if (normalized === 'previous' || normalized === 'prev') {
      cycleActiveSession(-1)
      return
    }
    const items = sessionLayout?.sessionList.getItems() ?? []
    const index = /^\d+$/u.test(argument) ? Number.parseInt(argument, 10) - 1 : -1
    const byIndex = index >= 0 ? items[index] : undefined
    const exact = items.filter(item => item.id === argument || item.title.toLowerCase() === normalized)
    const selected = byIndex ?? (exact.length === 1 ? exact[0] : undefined)
    if (selected === undefined) {
      appendNotice(
        exact.length > 1
          ? `Active session title "${displayText(argument)}" is ambiguous; use its number.`
          : `Unknown active session "${displayText(argument)}". Use /switch to list active sessions.`,
        'warning',
      )
      return
    }
    activateSession(SessionId(selected.id))
  }

  const writeClipboardText = async (text: string): Promise<void> => {
    try {
      const method = await copyText(text, runtime.terminal)
      if (!isDisposed()) showTransientNotice(`Copied ${String(text.length)} characters via ${method}.`)
    } catch (error: unknown) {
      if (!isDisposed()) appendNotice(`Copy failed: ${errorChain(error)}`, 'error')
    }
  }

  // Ctrl+C/Ctrl+D at an idle empty prompt require a second press within
  // EXIT_DOUBLE_PRESS_MS (the Claude Code convention) — a stray press shows a
  // dim hint on the editor instead of killing the session.
  const EXIT_DOUBLE_PRESS_MS = 800
  const REWIND_DOUBLE_PRESS_MS = 800
  // Hard ceiling on the shutdown dispose chain before the exit fires anyway.
  const SHUTDOWN_EXIT_FALLBACK_MS = 3_000
  let exitArmedAt: number | undefined
  let rewindArmedAt: number | undefined
  const doublePressExit = (key: string): void => {
    const pressedAt = now()
    if (exitArmedAt !== undefined && pressedAt - exitArmedAt <= EXIT_DOUBLE_PRESS_MS) {
      exitArmedAt = undefined
      editor.hint = undefined
      requestExit()
      return
    }
    exitArmedAt = pressedAt
    editor.hint = palette.dim(`press ${key} again to exit`)
    requestRender()
    setTimeout(() => {
      // Disarm quietly once the window lapses; restore the state-appropriate
      // placeholder (steer / plan / queue / examples).
      if (exitArmedAt !== undefined && now() - exitArmedAt >= EXIT_DOUBLE_PRESS_MS) {
        exitArmedAt = undefined
        applyEditorHint()
        requestRender()
      }
    }, EXIT_DOUBLE_PRESS_MS + 50)
  }

  const shutdown = (exitProcess: boolean): Promise<void> => {
    // The exit boundary is idempotent and reached from three places: the end
    // of the dispose chain, the chain's rejection, and a hard fallback timer
    // — a turn that ran can leave a dispose step unresolved, and the process
    // must never hang with the terminal already torn down.
    let exitedRuntime = false
    const finish = (): void => {
      if (!exitProcess || exitedRuntime) return
      exitedRuntime = true
      if (runtime.goodbyeMessage !== undefined) {
        runtime.terminal.write(`${palette.dim(displayText(runtime.goodbyeMessage))}\n`)
      }
      runtime.exit(0)
    }
    shuttingDown ??= (async () => {
      disposed = true
      overlayManager.beginShutdown()
      modelController.resetContextResolution()
      clearStatus()
      for (const controller of commandControllers) controller.abort(new Error('TUI disposed'))
      commandControllers.clear()
      for (const controller of referenceControllers) controller.abort(new Error('TUI disposed'))
      referenceControllers.clear()
      await tuiServiceFiber?.dispose()
      tuiServiceFiber = undefined
      // Every live slot's approvals drain and unregister together (the
      // registry's dispose path), mirroring the single-slot shutdown before it.
      registry.disposeAll()
      questions.rejectAll()
      await overlayManager.dispose()
      modelController.clearOverlay()
      questions.unregister()
      await runtime.terminal.drainInput(100, 20)
      ui.stop()
      finish()
    })()
    if (exitProcess) {
      void shuttingDown.catch(() => {}).then(finish)
      setTimeout(finish, SHUTDOWN_EXIT_FALLBACK_MS)
    }
    return shuttingDown
  }

  const requestExit = (): void => {
    if (agent.status === 'running') {
      agent.cancel({ kind: 'user' })
      appendNotice('Cancelling the active turn and exiting…', 'warning')
    }
    void shutdown(true)
  }

  /** Swap the palette and all derived themes for the given terminal color scheme. */
  const applyColorScheme = (scheme: TerminalColorScheme): void => {
    if (scheme === currentScheme) return
    currentScheme = scheme
    Object.assign(palette, createPalette(resolved.theme.color, scheme, paletteOptions()))
    Object.assign(mdTheme, markdownTheme(palette, codeHighlighter.highlightCode))
    // Rows cached under the prior palette's roles must not outlive it.
    codeHighlighter.invalidate()
    // `setStatus` below re-derives `editor.borderColor` from the new palette.
    rebuildTranscript(false)
    setStatus(agent.status)
    requestRender()
  }
  let currentScheme: TerminalColorScheme = 'dark'

  // Apply any color scheme the terminal reports. Registering before the query
  // below means even a synchronous reply reaches `applyColorScheme`; in practice
  // the startup query's reply is the only report, since dsh-tui leaves
  // unsolicited color-scheme notifications disabled.
  const disposeSchemeListener = ui.onTerminalColorSchemeChange(applyColorScheme)

  // Ask the terminal for its color scheme via device-status report; the reply,
  // if any, arrives through the listener above. Most terminals do not respond,
  // so we keep the dark-optimised palette. Swallow a query-write failure for the
  // same reason.
  ui.queryTerminalColorScheme({ timeoutMs: 2000 }).catch(() => {})

  // Ask the terminal for its background color (OSC 11); the user-message
  // bubble fill mixes from the real canvas when the reply lands. Most
  // terminals do not respond, leaving the scheme/preset-derived fill.
  // Swallow a query-write failure for the same reason as the scheme query.
  void ui.queryTerminalBackgroundColor({ timeoutMs: 2000 }).then((background) => {
    if (background === undefined) return
    terminalBackground = background
    Object.assign(palette, createPalette(resolved.theme.color, currentScheme, paletteOptions()))
    rebuildTranscript(false)
    requestRender()
  }).catch(() => {})

  const toggleTools = (): void => {
    setToolsVisibility(toolsVisibility === 'collapsed' ? 'expanded' : 'collapsed')
  }

  const setReasoning = (show: boolean): void => {
    showReasoning = show
    rebuildTranscript(false)
    // State-switch feedback: transient receipt, not transcript history.
    showTransientNotice(`Reasoning ${showReasoning ? 'expanded' : 'collapsed'}.`)
  }

  const toggleReasoning = (): void => { setReasoning(!showReasoning) }

  // The selector and the argument grammar mutate the same closure state the
  // Ctrl+O cycle and Ctrl+R toggle drive, so every entry converges.
  let detailsOverlay: TuiOverlaySession | undefined
  const showDetailsSelector = (): void => {
    void detailsOverlay?.close()
    const session = overlayManager.open({
      create: () => new DetailsDialog(
        toolsVisibility,
        showReasoning,
        palette,
        // Each Tab applies immediately; one dimension changes per call.
        (selection: DetailsSelection) => {
          if (selection.showReasoning !== showReasoning) setReasoning(selection.showReasoning)
          if (selection.visibility !== toolsVisibility) setToolsVisibility(selection.visibility)
        },
        () => { void session.close() },
      ),
      options: { width: resolved.detailsDialogWidth, maxHeight: resolved.questionDialogMaxHeight },
    }, 'inline')
    detailsOverlay = session
    void session.closed.then(() => {
      if (detailsOverlay === session) detailsOverlay = undefined
    })
    requestRender()
  }

  /**
   * Swap the active named theme in place: rebuild the palette and derived
   * themes over the SAME palette object (the whole component tree holds it),
   * invalidate highlight rows cached under the old roles, and re-render.
   */
  const applyTheme = (name: string): boolean => {
    const preset = THEME_PRESETS[name]
    if (preset === undefined) {
      appendNotice(`Unknown theme "${name}". Available: ${THEME_PRESET_NAMES.join(', ')}.`, 'warning')
      return false
    }
    currentPreset = name === 'deepseek' ? undefined : preset
    currentThemeName = name
    Object.assign(palette, createPalette(resolved.theme.color, currentScheme, paletteOptions()))
    Object.assign(mdTheme, markdownTheme(palette, codeHighlighter.highlightCode))
    codeHighlighter.invalidate()
    rebuildTranscript(false)
    setStatus(agent.status)
    requestRender()
    return true
  }

  /** Rename the session through the (optional) session-title service. */
  const renameSession = (title: string): void => {
    const titles = ctx.get('sessionTitle') as {
      rename(session: unknown, title: string): unknown
    } | undefined
    if (titles === undefined) {
      appendNotice('Session titles are not available in this session.', 'warning')
      return
    }
    try {
      titles.rename(agent.session, title)
      showTransientNotice(`Session renamed to "${title}".`)
    } catch (error) {
      appendNotice(`Rename failed: ${errorChain(error)}`, 'error')
    }
  }

  // The `/theme` picker overlay; Tab previews live, Enter keeps, Esc restores.
  let themeOverlay: TuiOverlaySession | undefined
  const showThemeSelector = (): void => {
    void themeOverlay?.close()
    const session = overlayManager.open({
      create: () => new ThemeDialog(
        THEME_PRESET_NAMES.map(name => ({
          name,
          description: THEME_PRESETS[name]?.description ?? '',
          dark: THEME_PRESETS[name]?.dark ?? false,
        })),
        currentThemeName,
        palette,
        applyTheme,
        () => { void session.close() },
      ),
      options: { width: resolved.detailsDialogWidth, maxHeight: resolved.questionDialogMaxHeight },
    }, 'inline')
    themeOverlay = session
    void session.closed.then(() => {
      if (themeOverlay === session) themeOverlay = undefined
    })
    requestRender()
  }

  // `/details` names the same transcript-detail state the Ctrl+O cycle and
  // Ctrl+R toggle mutate, so a user can jump to a mode without cycling.
  const runDetails = (rawInput: string): CommandResult => {
    const tokens = rawInput.split(/\s+/u).filter(token => token !== '')
    if (tokens.length === 0) {
      showDetailsSelector()
      return { kind: 'success' }
    }
    let visibility: ToolCardVisibility | undefined
    let reasoning: boolean | undefined
    for (let token = tokens.shift(); token !== undefined; token = tokens.shift()) {
      if (token === 'collapsed' || token === 'expanded') {
        visibility = token
      } else if (token === 'reasoning') {
        const value = tokens[0]
        if (value === 'on' || value === 'off') {
          tokens.shift()
          reasoning = value === 'on'
        } else {
          reasoning = !showReasoning
        }
      } else {
        return { kind: 'error', text: `Unknown /details argument "${token}". Usage: /details [collapsed|expanded] [reasoning [on|off]]` }
      }
    }
    // Reasoning first: its transcript rebuild would drop the visibility notice.
    if (reasoning !== undefined) setReasoning(reasoning)
    if (visibility !== undefined) setToolsVisibility(visibility)
    return { kind: 'success' }
  }

  const showHelp = (): void => {
    const commandLines = ctx.commands.list(agent).map((command) => {
      const input = command.input === undefined ? '' : ` ${displayText(command.input.hint)}`
      return `${palette.accent(`/${displayText(command.name)}${input}`)}  ${palette.dim(displayText(command.description))}`
    })
    const section = (title: string): string => palette.bold(palette.accent(title))
    openStaticDialog(insights, 'Help', [
      section('Message input'),
      '  Enter send or steer · Tab queue while running · Shift/Alt+Enter newline',
      '  Up recalls the latest submission when input is empty',
      '  Esc restores the latest queued message before cancelling a running turn',
      '',
      section('Conversation'),
      '  Double Esc edit from a checkpoint · Alt+Left/Right switch active sessions',
      '  Delete remove the current project session from Active; history is preserved',
      '  Alt+V attach a clipboard image · Page Up/Page Down scroll the transcript',
      '',
      section('Display and control'),
      '  Ctrl+O cycle tool cards · Ctrl+R toggle reasoning · Ctrl+L redraw',
      '  Shift+Tab cycle permission · Ctrl+G goal actions',
      '  Ctrl+C cancel/clear/exit · Ctrl+D exit',
      '',
      section('Commands'),
      ...commandLines,
    ])
  }

  const showStatus = async (signal: AbortSignal): Promise<void> => {
    const assembly = await ctx.systemPrompt.assemble(assembleContextFor(agent, signal))
    /* v8 ignore next -- disposal during the awaited assembly is covered by command-owner teardown tests. */
    if (disposed) return
    /* v8 ignore next -- SystemPrompt always emits at least its required base section. */
    const systemPrompt = displayText(renderPrompt(assembly)) || '(empty)'
    const events = agent.session.events
    const latestActivity = events.at(-1)?.time ?? agent.session.header.createdAt
    const pressure = contextPressure()
    const usedContext = Math.max(0, Math.round(
      pressure?.projectedTokens ?? pressure?.pressureTokens ?? ctx.tokenMeter.measure(agent.session).totalTokens,
    ))
    let context = `${formatDiagnosticNumber(usedContext)} used · capacity unknown`
    const contextWindow = pressure?.contextWindow ?? modelController.contextWindow()
    if (contextWindow !== undefined && contextWindow > 0) {
      const contextPercent = Math.round(usedContext / contextWindow * 100)
      context = `${diagnosticMeter(contextPercent, palette)} ${String(contextPercent)}% used (${formatDiagnosticNumber(usedContext)} / ${formatDiagnosticNumber(contextWindow)})`
    }
    const tokens = channel.tokens()
    const rate = cacheHitRate(tokens)
    const turns = events.filter(event => event.type === 'turn/start').length
    const steps = events.filter(event => event.type === 'step/start').length
    const toolCalls = events.filter(event => event.type === 'tool/call').length
    const model = target.current === undefined ? 'unset' : displayText(targetLabel(target.current))
    const effort = target.current === undefined
      ? 'unset'
      : target.current.reasoningEffort === undefined
        ? 'default'
        : displayText(target.current.reasoningEffort)
    const sessionCwd = agent.session.id === ASSISTANT_SESSION_ID ? undefined : activeCwd()
    const section = (title: string): string => palette.bold(palette.accent(title))
    const field = (label: string, value: string): string => `  ${palette.dim(label.padEnd(11))}${value}`
    const lines = [
      section('Session'),
      field('ID', displayText(agent.session.id)),
      field('Title', displayText(sessionTitle ?? 'untitled')),
      ...sessionCwd === undefined ? [] : [field('Directory', displayText(sessionCwd))],
      field('Model', `${model} ${palette.dim(`(effort ${effort}; reasoning ${showReasoning ? 'shown' : 'hidden'})`)}`),
      '',
      section('Activity'),
      field('Agent', [
        agent.status,
        formatDiagnosticCount(events.length, 'event'),
        formatDiagnosticCount(turns, 'turn'),
        formatDiagnosticCount(steps, 'step'),
        formatDiagnosticCount(toolCalls, 'tool call'),
      ].join(' · ')),
      field('Created', formatDiagnosticTime(agent.session.header.createdAt)),
      field('Latest', formatDiagnosticTime(latestActivity)),
      '',
      section('Usage'),
      field('Tokens', `${formatDiagnosticNumber(tokens.input)} input + ${formatDiagnosticNumber(tokens.output)} output`),
      field('KV cache', rate === undefined
        ? `n/a (${formatDiagnosticNumber(tokens.cacheRead)} read + ${formatDiagnosticNumber(tokens.cacheWrite)} write)`
        : `${diagnosticMeter(rate, palette)} ${String(rate)}% hit (${formatDiagnosticNumber(tokens.cacheRead)} read + ${formatDiagnosticNumber(tokens.cacheWrite)} write)`),
      field('Context', context),
      '',
      section('System prompt'),
      ...systemPrompt.split('\n').map(line => `  ${line}`),
      '',
      section('Registered tools'),
      ...assembly.tools.length === 0
        ? ['  (none)']
        : assembly.tools.map(tool => `  • ${displayText(tool.name)}`),
    ]
    openStaticDialog(insights, 'Session status', lines)
  }

  // Skill listing is async while `createTuiChat` is synchronous. Keep the last
  // complete user-invocable catalog for the selector and argument completion.
  let skillCatalog: readonly SkillSummary[] = []
  let skillCommandScan = 0
  let skillScanController: AbortController | undefined
  let skillSelector: SkillSelector | undefined
  let skillOverlay: TuiOverlaySession | undefined
  const skillArgumentCompletions = (argumentPrefix: string) => {
    const trimmed = argumentPrefix.trimStart()
    if (trimmed !== argumentPrefix || /\s/u.test(trimmed)) return null
    const query = trimmed.toLocaleLowerCase()
    return skillCatalog
      .filter(skill => query === '' || skill.name.toLocaleLowerCase().includes(query))
      .map(skill => ({
        value: skill.name,
        label: skill.name,
        description: `${skill.source.startsWith('project-') ? 'project' : 'user'} — ${skill.description}`,
      }))
  }
  const refreshCommandAutocomplete = (): void => {
    const commands: SlashCommand[] = ctx.commands.list(agent).map(command => ({
      name: command.name,
      description: command.description,
      ...(command.input === undefined ? {} : { argumentHint: command.input.hint }),
      ...command.name === 'skill' ? { getArgumentCompletions: skillArgumentCompletions } : {},
    }))
    const base = new CombinedAutocompleteProvider(
      commands,
      agent.session.header.cwd ?? process.cwd(),
    )
    const sessionReferences = ctx.get('sessionReferenceResolver')
    editor.setAutocompleteProvider(new ReferenceAutocompleteProvider(
      base,
      fileSearch,
      sessionReferences,
      agent,
    ))
  }
  const refreshVisibleSkillAutocomplete = (): void => {
    const cursor = editor.getCursor()
    const textBeforeCursor = editor.getLines().slice(cursor.line, cursor.line + 1).join('').slice(0, cursor.col)
    if (cursor.line === 0 && (/^\/skill(?: [^\s]*)?$/u).test(textBeforeCursor)) {
      // pi-tui's provider setter closes an existing menu but does not query
      // the replacement for the current draft. Tab requests the new catalog
      // without editing the command or its first argument.
      editor.handleInput('\t')
    }
  }
  const disposeCommandChanges = ctx.on('commands/change', () => {
    refreshCommandAutocomplete()
    updatePromptValues()
    requestRender()
  })
  refreshCommandAutocomplete()

  const refreshSkillCommands = (service: SkillRegistry): void => {
    const scan = ++skillCommandScan
    skillScanController?.abort()
    const controller = new AbortController()
    skillScanController = controller
    const signal = AbortSignal.any([skillAbort.signal, controller.signal])
    service.snapshot({ cwd: activeCwd(), signal }).then(
      (snapshot) => {
        if (disposed || signal.aborted || scan !== skillCommandScan || !snapshot.complete) return
        skillCatalog = snapshot.skills.filter(skill => skill.invocation.userInvocable)
        skillSelector?.setSkills(skillCatalog)
        refreshCommandAutocomplete()
        refreshVisibleSkillAutocomplete()
        requestRender()
      },
      () => {
        // Discovery failed or was aborted on dispose; keep the base slash
        // commands so autocomplete still works without skill entries.
      },
    )
  }
  const disposeSkillChanges = skills === undefined
    ? () => {}
    : ctx.on('skills/change', () => { refreshSkillCommands(skills) })
  if (skills !== undefined) refreshSkillCommands(skills)

  // Front-door commands register GLOBALLY (through this plugin's context, not
  // the initial agent's): the commands service scopes registrations by the
  // owning context, and an agent-scoped registration is invisible to every
  // other live session — `/sessions`, `/new`, and the rest must execute for
  // whichever session is mounted. The fiber still dies with the TUI.
  const commandFiber = ctx.inject(['commands'], (commandCtx) => {
    commandCtx.commands.register({
      name: 'help',
      description: 'Show keyboard shortcuts and commands',
      handler: () => { showHelp(); return { kind: 'success' } },
    })
    commandCtx.commands.register({
      name: 'model',
      description: 'Show or switch this session\'s model; use /effort for reasoning level',
      input: { hint: '[[provider/]model]' },
      handler: ({ rawInput }) => {
        modelController.queueModelCommand(rawInput)
        return { kind: 'success' }
      },
    })
    commandCtx.commands.register({
      name: 'effort',
      description: 'Show or set this session\'s reasoning effort',
      input: { hint: '[level]' },
      handler: ({ rawInput }) => {
        modelController.queueReasoningEffortCommand(rawInput)
        return { kind: 'success' }
      },
    })
    commandCtx.commands.register({
      name: 'clear',
      description: 'Clear the transcript view (session history is unchanged)',
      handler: () => { channel.chat.clear(); requestRender(); return { kind: 'success' } },
    })
    commandCtx.commands.register({
      name: 'details',
      description: 'Select tool-card visibility and reasoning display',
      input: { hint: '[collapsed|expanded] [reasoning [on|off]]' },
      handler: ({ rawInput }) => runDetails(rawInput),
    })
    commandCtx.commands.register({
      name: 'theme',
      description: 'Show or switch the TUI color theme',
      input: { hint: '[name]' },
      handler: ({ rawInput }) => {
        const name = rawInput.trim()
        if (name === '') {
          showThemeSelector()
        } else {
          applyTheme(name)
        }
        return { kind: 'success' }
      },
    })
    commandCtx.commands.register({
      name: 'rename',
      description: 'Rename this session',
      input: { hint: '[title]' },
      handler: ({ rawInput }) => {
        const title = rawInput.trim()
        if (title !== '') {
          renameSession(title)
          return { kind: 'success' }
        }
        const session = overlayManager.open({
          create: () => new RenameDialog(
            sessionTitle ?? '',
            palette,
            renameSession,
            () => { void session.close() },
          ),
          options: { width: 64, maxHeight: 10 },
        }, 'inline')
        return { kind: 'success' }
      },
    })
    commandCtx.commands.register({
      name: 'fork',
      description: 'Branch this session at its last completed turn and open it',
      handler: async () => {
        await forkSession({
          ctx, resolved, palette, overlayManager, requestRender, isDisposed, appendNotice, agent,
          activate: adoptOwnedAgent,
        })
        return { kind: 'success' }
      },
    })
    commandCtx.commands.register({
      name: 'status',
      description: 'Show session diagnostics, system prompt, and registered tools',
      handler: async ({ signal }) => { await showStatus(signal); return { kind: 'success' } },
    })
    commandCtx.commands.register({
      name: 'context',
      description: 'Show context occupancy and its system/tools/messages breakdown',
      handler: () => {
        openStaticDialog(insights, 'Context', contextLines(insights, palette), () => contextLines(insights, palette))
        return { kind: 'success' }
      },
    })
    commandCtx.commands.register({
      name: 'agents',
      description: 'List this session\'s subagent sessions and their activity',
      handler: async ({ signal }) => {
        const lines = await agentsLines(insights, signal)
        if (!isDisposed()) openStaticDialog(insights, 'Subagents', lines)
        return { kind: 'success' }
      },
    })
    commandCtx.commands.register({
      name: 'jobs',
      description: 'List this session\'s background jobs',
      handler: () => {
        openStaticDialog(insights, 'Background jobs', jobsLines(insights), () => jobsLines(insights))
        return { kind: 'success' }
      },
    })
    commandCtx.commands.register({
      name: 'settings',
      description: 'Show settings namespaces and where overrides live',
      handler: () => {
        openStaticDialog(insights, 'Settings', settingsLines(insights), () => settingsLines(insights))
        return { kind: 'success' }
      },
    })
    commandCtx.commands.register({
      name: 'memory',
      description: 'Show or set long-term memory for this session',
      input: { hint: '[on|off]' },
      handler: async ({ rawInput }) => {
        const memory = memoryService()
        if (memory === undefined) {
          appendNotice('Memory is not available in this composition.', 'warning')
          return { kind: 'success' }
        }
        const value = rawInput.trim().toLocaleLowerCase()
        if (value === '') {
          showTransientNotice(`Memory is ${memory.isEnabled(agent.session.id) ? 'on' : 'off'} for this session.`)
          return { kind: 'success' }
        }
        if (value !== 'on' && value !== 'off') {
          appendNotice('Usage: /memory [on|off]', 'warning')
          return { kind: 'success' }
        }
        const targetAgent = agent
        const enabled = value === 'on'
        await memory.setEnabled(targetAgent.session.id, enabled)
        if (!isDisposed()) {
          syncMemoryScope(targetAgent)
          refreshCommandAutocomplete()
          showTransientNotice(`Memory ${enabled ? 'enabled' : 'disabled'} for this session.`)
          requestRender()
        }
        return { kind: 'success' }
      },
    })
    commandCtx.commands.register({
      name: 'skill',
      description: 'Load a skill into the conversation',
      input: { hint: '[name] [instructions]' },
      handler: async ({ rawInput, signal }) => {
        const { name, instructions } = parseSkillArguments(rawInput)
        if (name === '') showSkillSelector()
        else await invokeSkill(name, instructions, signal)
        return { kind: 'success' }
      },
    })
    commandCtx.commands.register({
      name: 'export',
      description: 'Write this session\'s transcript to a markdown file',
      input: { hint: '[path]' },
      handler: ({ rawInput }) => {
        const argument = rawInput.trim()
        try {
          const path = writeExport(
            activeCwd(),
            agent.session,
            argument === '' ? undefined : resolve(activeCwd(), argument),
          )
          showTransientNotice(`Exported to ${path}`)
        } catch (error) {
          appendNotice(`Export failed: ${errorChain(error)}`, 'error')
        }
        return { kind: 'success' }
      },
    })
    commandCtx.commands.register({
      name: 'exit',
      description: 'Cancel the active turn and exit the TUI',
      handler: () => { requestExit(); return { kind: 'success' } },
    })
    commandCtx.commands.register({
      name: 'quit',
      description: 'Close this project session and return to the assistant',
      handler: () => { quitCurrentActiveSession(); return { kind: 'success' } },
    })
    commandCtx.commands.register({
      name: 'sessions',
      description: 'Browse active workspace sessions and complete history',
      handler: () => { resume.showSessions(); return { kind: 'success' } },
    })
    commandCtx.commands.register({
      name: 'switch',
      description: 'Switch among active workspace sessions',
      input: { hint: '[next|previous|number|title]' },
      handler: ({ rawInput }) => { runSessionSwitch(rawInput); return { kind: 'success' } },
    })
    commandCtx.commands.register({
      name: 'new',
      description: 'Start a fresh session in this or another project and switch to it',
      input: { hint: '[project path]' },
      handler: ({ rawInput }) => { newSession(rawInput); return { kind: 'success' } },
    })
    commandCtx.commands.register({
      name: 'assistant',
      description: 'Switch to the personal assistant session',
      handler: () => { void assistant.open(); return { kind: 'success' } },
    })
  })
  // The @-file reference prompt section registers per-slot (on each agent's
  // own scope) inside the slot factory.

  const runCommand = (text: string): void => {
    const controller = new AbortController()
    commandControllers.add(controller)
    void ctx.commands.execute(agent, text, [], controller.signal).then(
      (execution) => {
        if (disposed) return
        if (execution === undefined) {
          appendNotice(`Unknown command: ${text}`, 'warning')
        } else if (execution.result.text !== undefined && execution.result.text !== '') {
          appendNotice(execution.result.text, execution.result.kind === 'error' ? 'error' : 'info')
        }
      },
      (error: unknown) => {
        if (!disposed) {
          appendNotice(`Command failed: ${errorChain(error)}`, 'error')
        }
      },
    ).finally(() => { commandControllers.delete(controller) })
  }

  type MessageDelivery = 'auto' | 'queue'

  const dispatchMessage = (
    content: ContentBlock[],
    attachedContext?: UserMessage,
    delivery: MessageDelivery = 'auto',
    targetAgent: Agent = agent,
    targetChannel: SessionChannel = channel,
  ): UserMessage | undefined => {
    if (disposed) {
      appendNotice(`Agent "${targetAgent.id}" is disposed.`, 'error')
      return undefined
    }
    const message = createUserMessage({ content, source: { kind: 'user' } })
    if (delivery === 'queue') {
      if (attachedContext !== undefined) {
        queuedReferenceContexts.set(message.id, { agent: targetAgent, context: attachedContext })
      }
      targetAgent.followup(message)
    } else if (targetAgent.status === 'running') {
      if (attachedContext !== undefined) targetAgent.inject(attachedContext)
      targetAgent.steer(message)
      targetChannel.addPendingSteering(message.id)
    } else {
      if (attachedContext !== undefined) targetAgent.inject(attachedContext)
      targetAgent.followup(message)
    }
    return message
  }

  const recordSubmission = (targetAgent: Agent, text: string, message: UserMessage): void => {
    const slot = registry.get(targetAgent.session.id)
    if (slot !== undefined) slot.lastSubmission = { text, messageId: message.id }
  }

  /** Load a manually invoked skill and deliver its rendered body to the session that issued the command. */
  const invokeSkill = async (name: string, instructions: string, commandSignal?: AbortSignal): Promise<void> => {
    if (skills === undefined) {
      appendNotice('Skills are not available in this session.', 'warning')
      return
    }
    const targetAgent = agent
    const targetChannel = channel
    const signal = commandSignal === undefined
      ? skillAbort.signal
      : AbortSignal.any([skillAbort.signal, commandSignal])
    const lookup = { cwd: activeCwd(), signal }
    const reportFailure = (error: unknown): void => {
      if (disposed || signal.aborted) return
      appendNotice(`Skill "${name}" failed to load: ${errorChain(error)}`, 'error')
    }
    try {
      const summaries = await skills.list(lookup)
      if (disposed || signal.aborted) return
      const summary = summaries.find(skill => skill.name === name)
      if (summary === undefined) {
        appendNotice(`Unknown skill: ${name}`, 'warning')
        return
      }
      if (!summary.invocation.userInvocable) {
        appendNotice(`Skill "${name}" is not available for user invocation.`, 'warning')
        return
      }
      const skill = await skills.get(name, lookup)
      if (disposed || signal.aborted) return
      if (skill === undefined) {
        appendNotice(`Unknown skill: ${name}`, 'warning')
        return
      }
      if (!skill.invocation.userInvocable) {
        appendNotice(`Skill "${name}" is not available for user invocation.`, 'warning')
        return
      }
      dispatchMessage(
        [{ type: 'text', text: renderSkillInvocation(skill, instructions) }],
        undefined,
        'auto',
        targetAgent,
        targetChannel,
      )
    } catch (error: unknown) {
      reportFailure(error)
    }
  }

  const showSkillSelector = (): void => {
    if (skills === undefined) {
      appendNotice('Skills are not available in this session.', 'warning')
      return
    }
    void skillOverlay?.close()
    const session = overlayManager.open({
      create: () => {
        skillSelector = new SkillSelector(
          skillCatalog,
          resolved.maxModelOptions,
          palette,
          (skill) => {
            void session.close()
            void invokeSkill(skill.name, '')
          },
          () => { void session.close() },
        )
        return skillSelector
      },
      options: { width: resolved.modelDialogWidth, maxHeight: resolved.modelDialogMaxHeight },
      signal: skillAbort.signal,
    }, 'inline')
    skillOverlay = session
    void session.closed.then(() => {
      if (skillOverlay === session) {
        skillOverlay = undefined
        skillSelector = undefined
      }
    })
    refreshSkillCommands(skills)
    requestRender()
  }

  const submitEditorValuePrepared = (
    value: string,
    delivery: MessageDelivery,
    targetSlot: TuiSessionSlot,
    imageBlocks: readonly ContentBlock[],
  ): void => {
    const text = value.trim()
    if (text === '') return
    const restoreSubmittedInput = (): void => {
      if (editor.getText() === '') editor.setText(value)
    }
    // An armed inbox edit REPLACES its queued message instead of dispatching.
    const editTarget = queueDock.takeEditTarget()
    if (editTarget !== undefined) {
      editor.addToHistory(text)
      editor.setText('')
      const retainedImages = imageBlocks.length === 0
        ? editTarget.content.filter(block => block.type === 'image')
        : imageBlocks
      const replacement = replaceQueuedMessage(editTarget, [{ type: 'text', text }, ...retainedImages])
      const attached = queuedReferenceContexts.get(editTarget.id)
      queuedReferenceContexts.delete(editTarget.id)
      if (agent.inbox.replace(editTarget.id, replacement)) {
        if (attached !== undefined) queuedReferenceContexts.set(replacement.id, attached)
        if (agent.inbox.nextStep.some(message => message.id === replacement.id)) {
          channel.addPendingSteering(replacement.id)
        }
        recordSubmission(agent, text, replacement)
        showTransientNotice('Queued message updated.')
      } else if (agent.status === 'running') {
        // The target left the queue while editing; deliver as fresh steering.
        if (attached !== undefined) attached.agent.inject(attached.context)
        agent.steer(replacement)
        channel.addPendingSteering(replacement.id)
        recordSubmission(agent, text, replacement)
      } else {
        if (attached !== undefined) attached.agent.inject(attached.context)
        agent.followup(replacement)
        recordSubmission(agent, text, replacement)
      }
      targetSlot.imageDraft.clear()
      refreshQueueDock()
      channel.refreshStatus()
      return
    }
    if (value.startsWith('/')) {
      if (imageBlocks.length > 0) {
        appendNotice('Images can be attached only to user messages, not commands.', 'warning')
        return
      }
      editor.addToHistory(text)
      editor.setText('')
      runCommand(value)
      return
    }
    let parsed: ReturnType<typeof parseSessionReferenceText>
    try {
      parsed = parseSessionReferenceText(text)
    } catch (error: unknown) {
      restoreSubmittedInput()
      appendNotice(`Invalid session reference: ${errorChain(error)}`, 'error')
      return
    }
    if (parsed.references.length === 0) {
      editor.addToHistory(text)
      editor.setText('')
      const message = dispatchMessage([{ type: 'text', text: parsed.text }, ...imageBlocks], undefined, delivery)
      if (message !== undefined) {
        targetSlot.imageDraft.clear()
        recordSubmission(agent, text, message)
      }
      return
    }
    const sessionReferences = ctx.get('sessionReferenceResolver')
    if (sessionReferences === undefined) {
      restoreSubmittedInput()
      appendNotice('Session reference capability unavailable.', 'error')
      return
    }
    const controller = new AbortController()
    const targetAgent = agent
    const targetChannel = channel
    referenceControllers.add(controller)
    editor.disableSubmit = true
    void sessionReferences.prepare(
      targetAgent,
      [{ type: 'text', text: parsed.text }],
      parsed.references,
      controller.signal,
    ).then((prepared: { content: ContentBlock[]; additionalContext?: UserMessage }) => {
      if (disposed) return
      editor.addToHistory(text)
      if (editor.getText() === value) editor.setText('')
      // The snapshot travels with the prompt so a blocking admission hook
      // discards them together — see dispatchMessage's attached-context path.
      const message = dispatchMessage(
        [...prepared.content, ...imageBlocks],
        prepared.additionalContext,
        delivery,
        targetAgent,
        targetChannel,
      )
      if (message !== undefined) {
        targetSlot.imageDraft.clear()
        recordSubmission(targetAgent, text, message)
      }
    }, (error: unknown) => {
      if (!disposed && !controller.signal.aborted) {
        restoreSubmittedInput()
        appendNotice(`Session reference failed: ${errorChain(error)}`, 'error')
      }
    }).finally(() => {
      referenceControllers.delete(controller)
      editor.disableSubmit = false
      requestRender()
    })
  }

  const submitEditorValue = (value: string, delivery: MessageDelivery = 'auto'): void => {
    if (disposed) {
      appendNotice(`Agent "${agent.id}" is disposed.`, 'error')
      return
    }
    const targetSlot = registry.active()
    // Only images whose placeholder survives in the editor text ship with the
    // message; pruning also drops stale entries from the draft.
    const imageBlocks = targetSlot.imageDraft.pruneToText(value)
    if (imageBlocks.length === 0) {
      submitEditorValuePrepared(value, delivery, targetSlot, imageBlocks)
      return
    }
    const text = value.trim()
    if (text === '') return
    if (text.startsWith('/')) {
      submitEditorValuePrepared(value, delivery, targetSlot, imageBlocks)
      return
    }
    const selected = targetSlot.target.current
    if (selected === undefined) {
      appendNotice('Select a model before sending images.', 'warning')
      return
    }
    let handedOff = false
    editor.disableSubmit = true
    void ctx.llm.resolveModelInfo(selected.provider, selected.model).then(
      (model) => {
        if (disposed) return
        const currentText = editor.getText()
        if (registry.active() !== targetSlot || (currentText !== '' && currentText !== value)) {
          appendNotice('Image submission was cancelled because the active draft changed.', 'warning')
          return
        }
        if (!model.inputModalities?.includes('image')) {
          if (editor.getText() === '') editor.setText(value)
          appendNotice(`Model ${selected.provider}/${selected.model} does not support image input. Choose a vision-capable model before sending this draft.`, 'warning')
          return
        }
        handedOff = true
        editor.disableSubmit = false
        submitEditorValuePrepared(value, delivery, targetSlot, imageBlocks)
      },
      (error: unknown) => {
        if (!disposed) {
          if (editor.getText() === '') editor.setText(value)
          appendNotice(`Could not verify image support: ${errorChain(error)}`, 'error')
        }
      },
    ).finally(() => {
      if (!handedOff) editor.disableSubmit = false
      requestRender()
    })
  }
  editor.onSubmit = (value: string) => { submitEditorValue(value) }

  let imagePasteInFlight = false
  const pasteImageFromClipboard = (): void => {
    if (imagePasteInFlight || editor.disableSubmit) return
    const attachments = ctx.get('attachments') as ImageAttachmentWriter | undefined
    if (attachments === undefined) {
      appendNotice('Image attachments are not available in this composition.', 'warning')
      return
    }
    const targetSlot = registry.active()
    imagePasteInFlight = true
    editor.disableSubmit = true
    void pasteClipboardImage(targetSlot.imageDraft, attachments).then(
      (image) => {
        if (disposed) return
        if (registry.active() !== targetSlot) {
          targetSlot.imageDraft.remove(image.number)
          appendNotice('Image paste was cancelled because the active session changed.', 'warning')
          return
        }
        const current = editor.getText()
        const separator = current === '' || /\s$/u.test(current) ? '' : ' '
        editor.setText(`${current}${separator}${image.placeholder}`)
        showTransientNotice(`${image.placeholder} attached.`)
      },
      (error: unknown) => {
        if (!disposed) appendNotice(`Image paste failed: ${errorChain(error)}`, 'error')
      },
    ).finally(() => {
      imagePasteInFlight = false
      editor.disableSubmit = false
      requestRender()
    })
  }

  const removeInputListener = ui.addInputListener((data) => {
    if (overlayManager.hasActiveOverlay()) return undefined

    const mouse = terminalMouseInput(data)
    if (mouse !== undefined) {
      const result = workbench?.handleMouse(mouse, runtime.terminal.columns)
      if (result?.sessionId !== undefined) activateSession(SessionId(result.sessionId))
      if (result?.copiedText !== undefined) {
        void writeClipboardText(result.copiedText)
      }
      if (result?.consumed === true) requestRender(true)
      return { consume: true }
    }

    if (editor.focused && matchesKey(data, 'alt+v')) {
      pasteImageFromClipboard()
      return { consume: true }
    }

    // Backspace right after an `[Image #N]` token removes the whole
    // placeholder (and its draft image) instead of one character at a time.
    if (editor.focused && matchesKey(data, Key.backspace)
      && deleteImagePlaceholderAtCursor(editor, registry.active().imageDraft)) {
      requestRender()
      return { consume: true }
    }

    const fastSessionSwitch = editor.focused
      && editor.getText() === ''
      && !editor.isShowingAutocomplete()
    if (fastSessionSwitch && matchesKey(data, 'alt+left')) {
      cycleActiveSession(-1)
      return { consume: true }
    }
    if (fastSessionSwitch && matchesKey(data, 'alt+right')) {
      cycleActiveSession(1)
      return { consume: true }
    }
    if (fastSessionSwitch && matchesKey(data, Key.delete)) {
      quitCurrentActiveSession()
      return { consume: true }
    }
    if (matchesKey(data, Key.pageUp)) {
      workbench?.scrollPageUp(runtime.terminal.columns)
      requestRender(true)
      return { consume: true }
    }
    if (matchesKey(data, Key.pageDown)) {
      workbench?.scrollPageDown(runtime.terminal.columns)
      requestRender(true)
      return { consume: true }
    }

    // Shift+Tab cycles permission presets before plain Tab is considered for
    // queue submission.
    if (matchesKey(data, Key.shift(Key.tab))) {
      permissionController.cycle()
      return { consume: true }
    }
    if (
      matchesKey(data, Key.tab)
      && agent.status === 'running'
      && editor.focused
      && !editor.disableSubmit
      && !editor.isShowingAutocomplete()
      && editor.getText().trim() !== ''
      && !editor.getText().trimStart().startsWith('/')
    ) {
      submitEditorValue(editor.getText(), 'queue')
      return { consume: true }
    }

    // Empty-input ↑ recalls the latest real message submission. When that
    // exact item is still pending, the next submit replaces it in place;
    // otherwise the text is restored as a fresh draft. This preserves actual
    // Enter/Tab order across the two inbox lanes.
    if (
      matchesKey(data, Key.up)
      && editor.focused
      && editor.getText() === ''
      && !editor.isShowingAutocomplete()
    ) {
      const latest = registry.active().lastSubmission
      if (latest !== undefined) {
        if (!queueDock.armForEdit(latest.messageId)) editor.setText(latest.text)
        requestRender()
        return { consume: true }
      }
      if (queueDock.armLatestForEdit()) return { consume: true }
    }
    if (matchesKey(data, Key.up) && queueDock.hasEditTarget()) {
      queueDock.cancelEditTarget()
    }
    if (matchesKey(data, Key.ctrl('g'))) {
      goalBar.showActions()
      return { consume: true }
    }
    if (matchesKey(data, Key.ctrl('o'))) {
      toggleTools()
      return { consume: true }
    }
    if (matchesKey(data, Key.ctrl('r'))) {
      toggleReasoning()
      return { consume: true }
    }
    if (matchesKey(data, Key.ctrl('l'))) {
      ui.invalidate()
      ui.requestRender(true)
      return { consume: true }
    }
    if (matchesKey(data, Key.escape) && agent.status === 'running') {
      rewindArmedAt = undefined
      if (editor.getText() === '' && !queueDock.hasEditTarget() && queueDock.armLatestForEdit()) {
        showTransientNotice('Latest queued message returned to the input.')
        requestRender()
        return { consume: true }
      }
      agent.cancel({ kind: 'user' })
      return { consume: true }
    }
    if (
      matchesKey(data, Key.escape)
      && agent.status === 'idle'
      && editor.getText() === ''
      && !editor.isShowingAutocomplete()
    ) {
      const pressedAt = now()
      if (rewindArmedAt !== undefined && pressedAt - rewindArmedAt <= REWIND_DOUBLE_PRESS_MS) {
        rewindArmedAt = undefined
        applyEditorHint()
        rewind.show()
      } else {
        rewindArmedAt = pressedAt
        editor.hint = palette.dim('press Esc again to rewind this conversation')
        requestRender()
        setTimeout(() => {
          if (rewindArmedAt !== undefined && now() - rewindArmedAt >= REWIND_DOUBLE_PRESS_MS) {
            rewindArmedAt = undefined
            applyEditorHint()
            requestRender()
          }
        }, REWIND_DOUBLE_PRESS_MS + 50)
      }
      return { consume: true }
    }
    if (matchesKey(data, Key.ctrl('c'))) {
      if (agent.status === 'running') {
        agent.cancel({ kind: 'user' })
      } else if (editor.getText() !== '') {
        editor.setText('')
      } else {
        doublePressExit('ctrl+c')
      }
      return { consume: true }
    }
    if (matchesKey(data, Key.ctrl('d'))) {
      if (agent.status === 'running') appendNotice('Cancel the active turn before exiting.', 'warning')
      else doublePressExit('ctrl+d')
      return { consume: true }
    }
    return undefined
  })

  // Every session-scoped listener (session events, inbox/status/error/disposed)
  // lives on the mounted channel; the registry's mount/unmount attach and
  // detach them with the slot itself. The initial slot is already attached.

  const detachListeners = (): void => {
    if (welcomeShimmer !== undefined) clearInterval(welcomeShimmer)
    welcomeShimmer = undefined
    stoppedTitleAbort?.abort()
    if (stoppedTitleRetry !== undefined) clearTimeout(stoppedTitleRetry)
    if (pendingTitleRetry !== undefined) clearTimeout(pendingTitleRetry)
    skillAbort.abort()
    fileSearch.dispose()
    noticeSlot.dispose()
    removeInputListener()
    disposeCommandChanges()
    disposeSkillChanges()
    disposePromptChanges()
    disposeBackgroundSessionEvents()
    disposeStoppedTitleFlush()
    disposeQueuedReferenceTurns()
    disposeQueuedReferenceDiscards()
    disposeBackgroundStatusChanges()
    disposeOwnedAgentChanges()
    disposeWorkspaceChanges()
    for (const value of promptValues) value.dispose()
    terminalTitleController?.dispose()
    terminalTitleController = undefined
    // Every live slot tears down together: session listeners, per-slot
    // approvals/docks, agent-scoped model routing and prompt sections.
    registry.disposeAll()
    queuedReferenceContexts.clear()
    disposeSchemeListener()
    modelController.detach()
  }

  rebuildTranscript(true)
  goalBar.refresh()
  refreshQueueDock()
  const restoredGoal = foldGoal(agent.session.events).goal
  /* v8 ignore next -- goal replay coverage lives with the goal seam; the TUI only formats its startup notice. */
  if (restoredGoal !== undefined && restoredGoal.phase !== 'complete') {
    appendNotice(
      `Goal restored (${restoredGoal.phase}) with automatic continuation disarmed. `
      + 'Human confirmation is required; send “继续” or run /goal resume.',
      'warning',
    )
  }
  setStatus(agent.status)
  // The welcome box's reveal sweep starts from a fully clipped box, so park
  // the clip before the first frame rather than flash the whole box for the
  // delay span.
  const welcomePending = sessionPristine()
  if (welcomePending) header.setRevealWidth(0)
  try {
    ui.start()
  } catch (error: unknown) {
    disposed = true
    detachListeners()
    void commandFiber.dispose().catch(
      /* v8 ignore next 2 -- command registration cleanup is non-throwing; this guards a future disposer regression */
      (cleanupError: unknown) => {
        ctx.logger.warn(`ui-tui: scoped cleanup after startup failure failed: ${errorChain(cleanupError)}`)
      },
    )
    clearStatus()
    questions.unregister()
    ui.stop()
    throw error
  }
  if (welcomePending) {
    // Two animation phases over the welcome box, started with the first
    // frame: the reveal sweep clips it left-to-right (~6 columns per tick,
    // parking at full width), then the shimmer pass sweeps the logo inside
    // it. Both run on light render ticks — the header is all that moves, so
    // the prompt values are not recomputed per frame.
    let revealed = 0
    let offset = -SHIMMER_WIDTH
    const stopWelcomeAnimation = (): void => {
      if (welcomeShimmer !== undefined) clearInterval(welcomeShimmer)
      welcomeShimmer = undefined
      header.setRevealWidth(undefined)
      header.setShimmerOffset(undefined)
    }
    welcomeShimmer = setInterval(() => {
      if (!sessionPristine()) {
        stopWelcomeAnimation()
        requestRender()
        return
      }
      // Read the target per tick: the first frame may land after the interval
      // starts, and only a rendered box reports its width.
      const revealTarget = header.welcomeBoxWidth()
      if (revealed < revealTarget) {
        revealed = Math.min(revealTarget, revealed + 6)
        header.setRevealWidth(revealed >= revealTarget ? undefined : revealed)
      } else if (offset <= logoFullWidth()) {
        header.setShimmerOffset(offset)
        offset += 2
      } else {
        stopWelcomeAnimation()
      }
      requestRender(true)
    }, SHIMMER_INTERVAL_MS)
  }
  tuiServiceFiber = ctx.inject([], (serviceCtx) => {
    new TuiExtensionServiceImpl(serviceCtx, agent, overlayManager)
  })

  // A launcher-seeded first turn (`dsh migrate`/`dsh upgrade`):
  // invoke the named skill exactly as a typed `/skill <name>` would, once the
  // chat is live and the agent is idle. The launcher sets this only for a fresh
  // session, so there is no prior turn to collide with; invokeSkill reports an
  // unknown skill as a notice.
  if (config.initialSkill !== undefined) void invokeSkill(config.initialSkill, '')

  // A configured theme name that matches no shipped preset falls back to the
  // adaptive default; say so once at startup rather than failing silently.
  if (resolved.theme.name !== 'deepseek' && THEME_PRESETS[resolved.theme.name] === undefined) {
    appendNotice(`Unknown theme "${resolved.theme.name}" in config; using the adaptive default. Available: ${THEME_PRESET_NAMES.join(', ')}.`, 'warning')
  }

  return {
    async dispose(): Promise<void> {
      detachListeners()
      await shutdown(false)
      await commandFiber.dispose()
    },
  }
}

/**
 * Open the pi-tui channel once its configured agent exists.
 *
 * @param ctx - Context supplying the agent registry, tools, and event stream.
 * @param config - Target agent and presentation configuration.
 * @param runtime - Terminal and process-exit boundary.
 */
export function mountTui(ctx: Context, config: Config, runtime: TuiRuntime): void {
  const sessionId = SessionId(config.sessionId ?? 'main')
  const matchesConfiguredIdentity = (agent: Agent): boolean =>
    agent.id === sessionId && ctx.agents.roots().includes(agent)
  let settled = false

  const stopWaiting = (): void => {
    disposeCreated()
    disposeFailure()
  }
  const start = (payload: { agent: Agent }): void => {
    if (settled || !matchesConfiguredIdentity(payload.agent)) return
    settled = true
    stopWaiting()
    ctx.effect(() => {
      const controller = createTuiChat(ctx, config, runtime)
      return () => controller.dispose()
    }, 'ui-tui')
  }
  const fail = (payload: { sessionId: SessionId; error: unknown }): void => {
    if (settled || payload.sessionId !== sessionId) return
    settled = true
    stopWaiting()
    runtime.terminal.write(displayText(`ui-tui: session "${sessionId}" failed to start: ${errorChain(payload.error)}\n`))
    runtime.exit(1)
  }

  const disposeCreated = ctx.on('agent/created', start)
  const disposeFailure = ctx.on('agent-loop/config-start-failed', fail)
  const existing = ctx.agents.roots().find(agent => agent.id === sessionId)
  if (existing !== undefined) start({ agent: existing })
}

const ROOT_DISPOSE_TIMEOUT_MS = 5_000

/**
 * Dispose the whole application before process exit, with a bounded fallback.
 * @param ctx - The TUI plugin context whose root owns sibling resources.
 * @param code - Process status to report.
 * @param exit - Exit boundary, replaceable by tests.
 */
export function disposeRootAndExit(
  ctx: Context,
  code: number,
  exit: (status: number) => void = (status) => { process.exit(status) },
): void {
  let exited = false
  const exitOnce = (): void => {
    if (exited) return
    exited = true
    exit(code)
  }
  const timeout = setTimeout(exitOnce, ROOT_DISPOSE_TIMEOUT_MS)
  void ctx.root.fiber.dispose().then(
    () => { clearTimeout(timeout); exitOnce() },
    () => { clearTimeout(timeout); exitOnce() },
  )
}

/** Cordis entry point using the process terminal; explicit TUI composition requires a TTY pair. */
/* v8 ignore start -- production process wiring; fake-terminal tests cover mountTui/createTuiChat,
   and apps/cli PTY smokes cover the real entry */
export function apply(ctx: Context, config: Config): void {
  if (!process.stdin.isTTY || !process.stdout.isTTY) {
    throw new Error('ui-tui: both stdin and stdout must be TTYs; use the one-shot @deepseek-ai/dsh-cli-demo app for pipes')
  }
  // Truecolor is a terminal capability, so detect it here at the process
  // boundary: COLORTERM is the standard signal, but Windows Terminal only
  // sets WT_SESSION and several other modern terminals announce themselves
  // through TERM_PROGRAM; an explicit theme value still wins.
  const truecolor = config.theme?.truecolor ?? (
    ['truecolor', '24bit'].includes(process.env.COLORTERM ?? '')
    || process.env.WT_SESSION !== undefined
    || ['vscode', 'WezTerm', 'ghostty', 'iTerm.app', 'Hyper'].includes(process.env.TERM_PROGRAM ?? '')
  )
  const resumeHost = ctx.get('tuiResumeHost')
  const goodbyeMessage = ctx.get('tuiGoodbyeMessage')
  // The launcher seeds a guided fresh session's first turn through this key; a
  // config value still wins. Consumed in createTuiChat via config.initialSkill.
  const initialSkill = config.initialSkill ?? ctx.get('tuiInitialSkill')
  const startup = ctx.tuiWorkspaceStartup
  mountTui(ctx, Object.assign(
    {},
    config,
    { sessionId: String(startup.sessionId) },
    { theme: Object.assign({}, config.theme, { truecolor }) },
    initialSkill === undefined ? {} : { initialSkill },
  ), {
    terminal: new ProcessTerminal(),
    exit: (code) => { disposeRootAndExit(ctx, code) },
    ...resumeHost === undefined ? {} : { handoffResume: (sessionId, cwd) => resumeHost.handoff(sessionId, cwd) },
    ...goodbyeMessage === undefined ? {} : { goodbyeMessage },
  })
}
/* v8 ignore stop */
