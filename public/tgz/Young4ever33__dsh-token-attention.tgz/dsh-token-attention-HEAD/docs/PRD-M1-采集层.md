> ⚠️ 本文档已整合进 docs/PRD.html §13（2026-08-23），此副本保留作源码侧参考。

# PRD 细化 — M1 数据采集层设计（v0.2 草案）

> 基于：docs/PRD.html（初步 PRD v0.1）· docs/dsh-interface-survey.md（接口勘察报告）
> 状态：草案 · 2026-08-23 · 配套原型：`src/node/`（collector + store + pricing + selftest）
> 范围：仅细化 PRD §5-FR1 / §8 技术方案 / §9 数据模型 中 **M1（数据地基）** 部分；M2/M3/M4 不在本文。

---

## 1 · M1 目标与验收（引用 PRD §10）

| 项 | 内容 |
|---|---|
| 目标 | 采集层 + SQLite + 聚合：把 DSH 运行期事件沉淀为 token 台账 |
| 验收 | 能按会话 / 日 正确记录 hit/miss/output 与费用（估算） |
| 范围 | 采集 → 落库 → 聚合 → 查询（面板数据接口，UI 属 M2） |

**本设计不覆盖**：建议引擎（M3）、面板 UI（M2）、单价表运行时热配置（M4，默认值已内置于 shared/pricing.ts）。

---

## 2 · 前置结论：DSH 暴露面（详见勘察报告）

- **全部依赖数据已暴露**，事件驱动即刻可用，无需"先轮询后切事件"的渐进路线。
- usage 为 DSH 规范化 `TokenUsage`（互斥桶）：`inputTokens`（未命中）、`outputTokens`、`cacheReadTokens`（命中）、`reasoningTokens`；DeepSeek 原始 `prompt_cache_hit_tokens` 等已被 adapter 映射（勘察报告 §3）。
- goal 明细事件化：`goal/change` 携带 objective / phase / roundsStarted / maxGoalRounds。
- subagent 身份事件化：`subagent/descriptor` + 会话头 `parentSession`。

---

## 3 · 采集架构

```
┌─────────────────────────────── DSH（Cordis 宿主）───────────────────────────────┐
│  ctx.on('session/event', (session, event) => …)      ← 实时增量（主路径）          │
│  ctx.sessions 既有会话 events 回放                    ← 启动回填（catch-up）        │
│  HTTP: session.history / projections                 ← 兜底（重启漏窗/浏览器半区）  │
└──────────────────────────────────────────────────────────────────────────────────┘
                                  │ collector.handle(session, event)
                                  ▼
                    ┌─────────────────────────────┐
                    │  collector.ts（事件→记录）    │  幂等游标 last_seq
                    └─────────────────────────────┘
                                  │
                                  ▼
                    ┌─────────────────────────────┐
                    │  store.ts（node:sqlite）      │  messages / sessions / goals /
                    │                              │  subagents / compactions / daily_agg
                    └─────────────────────────────┘
                                  │ 增量累加 + 定时 rebuildAgg 校正
                                  ▼
                    daily_agg（面板查询只走聚合表）
```

### 3.1 主路径：事件驱动

插件订阅 `session/event`，对每个事件按 §4 映射处理。事件本身是追加式日志（seq 连续），天然按序、不丢。

### 3.2 启动回填（catch-up）

插件加载时，遍历 DSH 既有会话，按 **last_seq 游标**增量回放 `session.events`（游标存于 sessions 表，落库幂等由 `UNIQUE(session_id, seq)` 保证）。插件重启、或晚于会话创建加载，均不丢数据。

### 3.3 兜底（异常/独立场景）

| 场景 | 兜底 |
|---|---|
| 节点半区不可用，浏览器半区独立工作 | HTTP `session.history`（events + projections）补数；`events` 订阅实时帧 |
| usage 字段缺失（老接口/异常） | messages 的 usage 列存 NULL（"未知"），不阻塞其他功能 |
| 聚合漂移 | 定时 `rebuildAgg(day)` 全量重算校正（COUNT(DISTINCT session_id) 修正 session_count） |

---

## 4 · 事件 → 表 映射（详细）

### 4.1 `assistant/message` → messages（**token 明细主入口**）

```ts
event.data = { turn, step, message: { source: { provider, model } }, usage?: TokenUsage, interrupted? }
```

| 目标列 | 来源 |
|---|---|
| session_id / seq / turn / step / ts | 事件信封 + data |
| provider / model | message.source |
| peak | `pricing.isPeak(ts)`（高峰=1） |
| input_hit / input_miss / output / reasoning | usage.cacheReadTokens / inputTokens / outputTokens / reasoningTokens |
| cost_est | `pricing.estimateCost(usage, ts, model)`（元） |
| interrupted | data.interrupted |

规则：
- **usage 缺失时不写 usage 列**（记 NULL），不丢轮次存在性（assistant 行仍落，供轮次计数）。
- **零内容 assistant/message**（max-tokens 截断步，只承载 usage）**仍要采**——surface 投影会跳过它，但 token 要记账。
- 幂等：`UNIQUE(session_id, seq)`，重复回放 UPDATE 同值。

### 4.2 会话元数据 → sessions

| 事件 | 更新列 |
|---|---|
| `request/header` | provider / model / reasoning_effort（EpochHeader.config） |
| `request/context` | context_window（`{ provider, model, contextWindow? }`） |
| `session/title` | title |
| `turn/start` | turn_count = max(turn) |
| （创建时） | created_at、origin、parent_session、delegation_depth、agent_preset（session.header） |

### 4.3 `goal/change` → goals + sessions.goal_id

```ts
change = { kind:'goal/change', version:1, operation, goal?: GoalSnapshot, roundsStarted?, createdAt?, updatedAt? }
GoalSnapshot = { id, revision, objective, phase, blockedReason?, maxGoalRounds }
```

| 目标列 | 来源 |
|---|---|
| id / revision / objective / phase / max_goal_rounds | change.goal |
| rounds_started | change.roundsStarted（**goal 续跑轮数**） |
| blocked_reason | goal.blockedReason（code: message） |
| created_at / updated_at | change.createdAt / updatedAt |

- 主键 `(id, revision)`——**每次变更一个 revision**，天然保留 goal 变更历史（台账可回看目标演进）。
- `sessions.goal_id` 关联最近 goal（按事件时序天然正确）。
- operation=clear：只清关联，不写行（历史保留）。

### 4.4 `subagent/descriptor` → subagents

子会话事件流中的身份事件（版本 2）：

```ts
descriptor = { version:2, mode:'one-shot'|'continuable', provider, label?, agentProvider?, agentModel?, persona?, toolFilter? }
```

| 目标列 | 来源 |
|---|---|
| session_id | 子会话 id（事件所属 session） |
| parent_session | session.header.parentSession（**父子关系无需额外维护**） |
| provider / mode / label | descriptor |
| delegation_depth | session.header.delegationDepth |
| first_seen | event.time |

- 子会话自身的 token 明细照常入 messages；**任务归并 = 子会话 parent_session → 父会话**，面板按父会话汇总子代理消耗。
- 生命周期（start/end、stopReason）M1 可缓，M3 建议引擎再消费 `subagent/start|end` Cordis 事件。

### 4.5 `compaction/summary|prune` → compactions

| 目标列 | 来源 |
|---|---|
| kind | summary / prune |
| shadowed_token_count | data.shadowedTokenCount（**被压缩掉的前缀 token**） |
| shadowed_seq_count | data.shadowedSeqs.length |

用途（M3）：压缩 = 前缀变更点，命中率骤降归因、前缀稳定性评分的依据。

### 4.6 暂不落库（M1 范围外，事件已暴露）

`tool/call|result`（M3 任务类型识别可再用）、`approval/*`、`plan/mode`、`todo/write`、`command/run|done`、`schedule/change`、`llm/retry`——collector 默认分支忽略，后续扩展零侵入。

---

## 5 · 表结构（SQLite DDL，与 src/node/store.ts 一致）

```sql
CREATE TABLE sessions (
  id TEXT PRIMARY KEY, title TEXT, provider TEXT, model TEXT,
  reasoning_effort TEXT, context_window INTEGER, goal_id TEXT,
  origin TEXT, parent_session TEXT, delegation_depth INTEGER, agent_preset TEXT,
  created_at INTEGER, updated_at INTEGER,
  last_seq INTEGER NOT NULL DEFAULT -1,          -- 幂等游标（断点续采）
  turn_count INTEGER NOT NULL DEFAULT 0,
  last_activity INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE messages (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  session_id TEXT NOT NULL, seq INTEGER NOT NULL, turn INTEGER NOT NULL, step INTEGER NOT NULL,
  role TEXT NOT NULL, provider TEXT, model TEXT, peak INTEGER NOT NULL,
  input_hit INTEGER, input_miss INTEGER, output INTEGER, reasoning INTEGER,
  cost_est REAL, interrupted INTEGER NOT NULL DEFAULT 0, ts INTEGER NOT NULL,
  UNIQUE(session_id, seq)
);
CREATE INDEX idx_messages_session ON messages(session_id, seq);
CREATE INDEX idx_messages_day ON messages(ts);
CREATE TABLE goals (
  id TEXT NOT NULL, revision INTEGER NOT NULL,
  objective TEXT NOT NULL, phase TEXT NOT NULL, max_goal_rounds INTEGER NOT NULL,
  rounds_started INTEGER NOT NULL, blocked_reason TEXT,
  created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL,
  PRIMARY KEY (id, revision)
);
CREATE TABLE subagents (
  session_id TEXT PRIMARY KEY, parent_session TEXT, provider TEXT,
  mode TEXT, label TEXT, delegation_depth INTEGER, first_seen INTEGER NOT NULL
);
CREATE TABLE compactions (
  id INTEGER PRIMARY KEY AUTOINCREMENT, session_id TEXT NOT NULL, kind TEXT NOT NULL,
  shadowed_token_count INTEGER NOT NULL, shadowed_seq_count INTEGER NOT NULL, ts INTEGER NOT NULL
);
CREATE TABLE daily_agg (
  day TEXT NOT NULL, model TEXT, peak INTEGER NOT NULL,
  input_hit INTEGER NOT NULL DEFAULT 0, input_miss INTEGER NOT NULL DEFAULT 0,
  output INTEGER NOT NULL DEFAULT 0, cost REAL NOT NULL DEFAULT 0,
  session_count INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (day, model, peak)
);
```

> 说明：PRD v0.1 的 `task_events` 表由 goals（goal 明细）+ subagents（子代理）+ messages（轮次）联合覆盖，M1 不单建；`advice_log` 属 M3。

---

## 6 · 费用估算规则（M1 内嵌默认值）

```
cost = (cacheRead × P_hit + inputMiss × P_miss + output × P_out) / 1e6   （元）
P = 空闲价 × (高峰 ? 2 : 1)
默认单价（元/百万 tokens，deepseek-v4-flash）：
  P_hit = 0.05（空闲）/ 0.10（高峰）   P_miss = 1.5 / 3.0   P_out = 4.5 / 9.0
```

- 峰谷判定：本地时区（按北京时间）`09:00–12:00`、`14:00–18:00` 为高峰。
- 未知模型回退 flash 单价，费用一律标注"估算"（PRD §11）。
- 可配置化（M4）：单价表与时段从配置读，默认值即 shared/pricing.ts 现值。

---

## 7 · 聚合策略

| 时机 | 动作 |
|---|---|
| 每条 assistant 消息 | 增量累加对应 `(day, model, peak)` 行的四桶与 cost |
| 每小时（定时） | `rebuildAgg(今天)` 全量重算校正（COUNT(DISTINCT session_id) 修正 session_count） |
| 每日 03:00 | 重算昨日全量，归档前校正 |

面板查询（M2）只走 daily_agg + sessions/messages 明细；聚合表保证轻量（PRD §8 存储）。

---

## 8 · 与 M2/M3 的接口约定

1. **数据接口（M2 面板）**：`store.queryDaily(day)`、`querySessions()`、`queryMessages(sessionId)` 已就绪；后续包一层 `api.ts`（Cordis 路由或 RPC，见 PRD §8 结构）暴露 `/api/token-attention/*`。
2. **M3 建议引擎输入**：messages（命中率、输出占比）、sessions（上下文占用 = context_window vs 累计）、goals（roundsStarted）、compactions（前缀稳定性）、subagents（归并成本）。
3. **DCL（数据契约）**：TokenUsage / GoalChangeMeta / SessionEvent 类型集中在 `src/shared/types.ts`，随 DSH 版本升级在此同步。

---

## 9 · 原型与验证

`src/node/selftest.ts` 自测并断言（全部通过）：

- 事件→落库：usage 四桶、reasoning、费用、goal（revision 历史）、subagent（父会话归并）、compaction、会话元数据；
- **幂等**：重复回放不重复记账（UNIQUE(session_id, seq)）；
- **峰谷**：同一 usage 高峰费用 = 2 × 空闲；
- **聚合**：增量累加 = 全量重算（rebuildAgg 校正后不变），session_count 去重正确（高峰 1 会话 / 空闲 2 会话）。

运行：`node src/node/selftest.ts`（Node 24 直接跑 TS，node:sqlite 零依赖；产物 `data/selftest-token_records.db`）。

## 10 · 待办/开放项

- [ ] 接入真实 DSH 环境联调（注册 cordis.patch.yml，验证真实会话事件流）；
- [ ] 单价表/时段可配置化（M4 计划，M1 内嵌默认值）；
- [ ] `api.ts` 面板数据路由（M2 开工时）；
- [ ] 评估 `ctx.tokenMeter` 投影与 daily_agg 的交叉校验（可选增强）；
- [ ] better-sqlite3 评估（node:sqlite 为实验性 API，正式版可考虑替换，接口不变）。
