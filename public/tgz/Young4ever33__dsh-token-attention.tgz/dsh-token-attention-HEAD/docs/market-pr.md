# PR: Add Young4ever33/dsh-token-attention (usage)

> 目标仓库：https://github.com/awesome-dsh-plugin/awesome-dsh-plugin
> 状态（2026-08-24）：**PR 尚未创建，改为手动提交**。
> ⚠️ 旧的 fork 分支 `add-dsh-token-attention` 落后 main 233 个提交，直接提 PR 会被 CI 的
> **Stale-fork guard** 打回（删除过多已有条目）。必须先基于最新 main 重建分支并重新生成 README。
> 已准备好的提交材料（校验过，README 基于最新 main 生成、各 +1 行）：
> - `tmp-market/awesome-dsh-plugin-main/data/plugins/Young4ever33__dsh-token-attention.yml`
> - `tmp-market/awesome-dsh-plugin-main/README.md` / `README.zh.md`
> 手动提交步骤见本文件末尾「手动提交步骤」。

## 实际提交内容（与 CI 要求一致）

1. 新增条目文件：`data/plugins/Young4ever33__dsh-token-attention.yml`
2. 重新生成的两个 README：`README.md`、`README.zh.md`（`node scripts/generate-readme.mjs`，条目出现在第 454 行）

## 条目内容

```yaml
url: https://github.com/Young4ever33/dsh-token-attention
name: Young4ever33/dsh-token-attention
category: usage
description:
  en: "Token attention management panel for DeepSeek Harness: per-task/day/week/month token usage and cost tracking (input hit/miss, output, reasoning), DeepSeek peak/off-peak pricing, task-type recognition, and advice on when to switch sessions, write a hand-off, or compact context."
  zh: "Token 注意力管理面板：按任务/日/周/月记录 token 消耗与费用（命中/未命中/输出/推理四桶），支持 DeepSeek 峰谷计价与任务类型识别，并给出换对话、写 hand-off、压缩上下文的建议。"
```

## 校验自检（对应 scripts/check-submission.mjs）

- ✅ `dsh.bundle` manifest：`package.json` 声明 `"dsh": { "bundle": { "patch": "./cordis.patch.yml" } }`，根目录有 `cordis.patch.yml`
- ✅ 仓库 commit 数：12（≥ 10）
- ⏳ 仓库年龄：2026-08-22 创建，**2026-08-23 19:10（北京时间）后满 1 天**
- ✅ 描述属实：五视图面板、四桶统计、峰谷计价、建议引擎均与代码一致
- ✅ 分类 `usage` 贴合插件实际（token 用量与费用追踪，与 dsh-usage-dashboard-plus 同类）
- ✅ 描述含 `: `（冒号加空格）已加引号，YAML 解析安全
- ✅ README 由官方脚本重新生成，无手工编辑
- ⚠️ 待办：`npm publish`（市场安装走 npm tarball 的前提，npm 包 `dsh-token-attention` 的 repository 已指回本仓库）

## 创建 PR 的 API 命令（明天执行）

```
POST /repos/awesome-dsh-plugin/awesome-dsh-plugin/pulls
{
  "title": "Add Young4ever33/dsh-token-attention (usage)",
  "head": "Young4ever33:add-dsh-token-attention",
  "base": "main",
  "body": "见本文件上文：新增 dsh-token-attention（Token Check · 词元管理）插件条目，README 已用官方脚本重新生成。"
}
```

## 手动提交步骤（2026-08-24 更新）

在你自己电脑上（git 可用、能访问 GitHub）：

```powershell
# 1) 克隆 fork 并同步最新上游 main
git clone https://github.com/Young4ever33/awesome-dsh-plugin.git
cd awesome-dsh-plugin
git remote add upstream https://github.com/awesome-dsh-plugin/awesome-dsh-plugin.git
git fetch upstream main

# 2) 基于最新 main 重建提交分支（覆盖旧的落后分支）
git checkout -B add-dsh-token-attention upstream/main

# 3) 放入已准备好的 3 个文件（README 已用官方脚本基于最新 main 生成）
Copy-Item "..\03-dsh-token-attention\tmp-market\awesome-dsh-plugin-main\data\plugins\Young4ever33__dsh-token-attention.yml" data\plugins\
Copy-Item "..\03-dsh-token-attention\tmp-market\awesome-dsh-plugin-main\README.md" README.md
Copy-Item "..\03-dsh-token-attention\tmp-market\awesome-dsh-plugin-main\README.zh.md" README.zh.md
# （也可改为本地 npm ci + node scripts/generate-readme.mjs，结果一致）

# 4) 提交并推送到 fork
git add data/plugins/Young4ever33__dsh-token-attention.yml README.md README.zh.md
git commit -m "Add Young4ever33/dsh-token-attention (usage)"
git push -f origin add-dsh-token-attention

# 5) 创建 PR（gh 未登录先 gh auth login）
gh pr create --repo awesome-dsh-plugin/awesome-dsh-plugin --base main --head Young4ever33:add-dsh-token-attention `
  --title "Add Young4ever33/dsh-token-attention (usage)" --body "Add dsh-token-attention (usage). Entry + regenerated READMEs."
```

PR 创建后等两个 CI：`PR check`（stale-fork guard / README 一致性 / awesome-lint）和
`Submission gate`（dsh.bundle、repo age ≥ 1 天、commits ≥ 10）。均已满足：13 commits、
仓库已满 2 天、`dsh.bundle` 已声明、`dsh-plugin` topic 已加。

后续待办：`npm publish`（npm 包名 `dsh-token-attention` 当前可用，市场安装会优先走 npm tarball）。
