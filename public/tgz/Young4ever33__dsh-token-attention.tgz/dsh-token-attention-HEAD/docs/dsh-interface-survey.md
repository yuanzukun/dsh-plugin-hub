> ⚠️ 本文档已整合进 docs/PRD.html §12（2026-08-23），此副本保留作源码侧参考。

# DSH 接口勘察报告 — M1 数据采集层暴露面确认

> 状态：已完成勘察（2026-08-23） · 依据版本：dsh-desktop 0.4.3 / @deepseek-ai/dsh 0.1.1-rc.1
> 目的：确认 PRD M1（数据采集层）依赖的 DSH 事件与数据是否暴露，从而定采集方式（事件驱动 vs 轮询兜底）。
> 勘察对象：DSH 安装目录 `resources/app/node_modules/@deepseek-ai/*` 的 lib 产物（含类型声明 typert.host.js）。

---

## 1 · 结论摘要

**PRD 担心的"goal 明细、usage 字段未暴露"不成立——暴露面完整。** DSH 以 **事件源会话日志**（event-sourced session log）为核心架构：每个会话是一条 append-only 的事件日志，通过 Cordis 事件 `session/event` 实时广播，且 `session.events` 可随时回放。PRD FR1 所需的四类数据全部有原生事件：

| PRD 需求 | DSH 暴露点 | 形态 |
|---|---|---|
| token 用量（hit/miss/output） | `assistant/message`.data.`usage` | 规范化 `TokenUsage`（见 §3） |
| 模型与参数 | `request/header`.data.`header` | `EpochHeader`（provider/model/reasoningEffort/maxTokens） |
| 任务归属（goal） | `goal/change` 会话事件 + `goal/changed` Cordis 事件 | `GoalChangeMeta`（objective/phase/roundsStarted/maxGoalRounds） |
| 子代理 | `subagent/descriptor` 会话事件 + `subagent/start|end` Cordis 事件 | 描述符 + 生命周期边 |
| 会话元数据 | `session/title`、`request/context`、`session.header` | 标题 / 上下文窗口 / 创建信息 |

**采集方式决策：事件驱动为主，轮询仅作兜底。**

- **主路径（事件驱动）**：节点半区插件 `ctx.on('session/event', (session, event) => ...)` 实时订阅，采集 `assistant/message` 的 usage、`goal/change`、`subagent/descriptor` 等事件写入 SQLite。零轮询、零遗漏、天然按序。
- **兜底路径（轮询/回填）**：① 插件启动时回放 `ctx.sessions` 中既有会话的 `session.events`（catch-up，补齐插件加载前的事件）；② 浏览器半区或异常恢复时可走 HTTP API `session.history`（返回 events + projections）与 `session.list`（含 `tokenUsage` 等投影值）补数。
- **不采用"先轮询再切事件"的渐进路线**——事件驱动当下即可用，无需等上游。

---

## 2 · 事件系统总览（dsh-session）

会话事件架构见 `@deepseek-ai/dsh-session/lib/types/index.js`（源码注释："Event-sourced session service: append-only session log"）。

### 2.1 订阅方式

```ts
ctx.on('session/event', (session, event) => { /* 每次 append 回调 */ });
```

- 回调参数为 `(session, event)`，其中 `event` 是已深冻结的会话事件（见 §2.2），`session` 是对应 `Session` 实例。
- 事件在 append 后同步派发；监听器异常被隔离（只记日志，不影响其他监听器）。
- 会话生命周期事件：`session/flush`（持久化插件在 flush/dispose 时排空）。

### 2.2 事件信封（SessionEvent）

```ts
interface SessionEvent {
  type: string;          // 见 §2.3 词汇表
  seq: number;           // 该会话日志内的连续序号（0 起）
  time: number;          // Date.now() 毫秒时间戳
  data: JsonValue;       // 事件负载（宽对象，按 type 解释）
  surfaceOp?: { start: number; end: number };   // 表面操作（append/replace）
  sourceEventSeqs?: number[];                   // 源块序号（assistant/message 聚合自 chunks）
  ignorable?: true;      // 未知类型标记（新版本事件，可安全跳过）
}
```

### 2.3 事件词汇表（KNOWN_SESSION_EVENT_TYPES 全集）

来自 `dsh-session/lib/types/known-event-types.js`（生成文件）。与采集相关者加粗：

`agent-preset/selected` · `agent/inbox/spliced` · `approval/asked|decided|policy` · `**assistant/chunk**` · `**assistant/message**` · `command/done|run` · `compaction/end|prune|start|summary` · `feedback/record` · `**goal/change**` · `hook/invoked|result` · `llm/retry|retry-started` · `permission/preset` · `**plan/mode**` · `**request/context**` · `**request/header**` · `sandbox/mode` · `schedule/change` · `session/end-seed` · `**session/title**` · `session/title-llm-request` · `**step/end|start**` · `**subagent/descriptor**` · `team/member|message/delivered|message/queued|task` · `todo/write` · `tool-workflow/agent-end|agent-start|run-end|run-start` · `**tool/call|result**` · `**turn/end|start**` · `**user/message**` · `web/deepseek-search-llm-request`

### 2.4 Session 对象 API（采集可用）

```ts
session.id            // 会话 id（字符串）
session.header        // { version, id, createdAt, cwd?, parentSession?, seedLength?, origin?('subagent'), delegationDepth?, agentPreset? }
session.events        // append-only 事件日志（可整体回放 → 启动回填的依据）
session.surface       // 表面（模型可见消息序列）管理器
session.deriveMessages()  // 派生 LLM 消息历史（冻结数组）
session.requestHeader()   // 最近折叠的 EpochHeader（provider/model 等）
session.requestContext()  // 最近折叠的 RequestContext（provider/model/contextWindow）
```

`ctx.sessions` 为会话存储服务（`SessionStore`），`ctx.sessions.get(id)` 取会话。

---

## 3 · token 用量暴露面（usage）

### 3.1 规范化 TokenUsage（DSH 内部约定）

多处 `typert.host.js` 声明一致（dsh-goal、dsh-commands、dsh-cordis-host-runner 等）：

```ts
export interface TokenUsage {
  inputTokens: number;       // 未命中输入（不含缓存命中）
  outputTokens: number;      // 输出
  cacheReadTokens?: number;  // 缓存命中输入
  cacheWriteTokens?: number; // 缓存写入（DeepSeek 不报，恒缺省）
  reasoningTokens?: number;  // 思考 token（DeepSeek completion_tokens_details.reasoning_tokens）
}
```

**关键语义：DSH 的计数是"互斥桶"（disjoint），不是 DeepSeek 原始字段**。映射见 `dsh-llm-deepseek/lib/types/translate.js` 的 `mapUsage`：

```ts
const cacheRead = usage.prompt_tokens_details?.cached_tokens ?? usage.prompt_cache_hit_tokens;
return {
  inputTokens: usage.prompt_tokens - (cacheRead ?? 0),   // ≈ prompt_cache_miss_tokens
  outputTokens: usage.completion_tokens,
  ...(cacheRead !== void 0 ? { cacheReadTokens: cacheRead } : {}),   // = prompt_cache_hit_tokens
  ...(reasoning !== void 0 ? { reasoningTokens: reasoning } : {}),
};
```

对照 PRD 的字段假设：`prompt_cache_hit_tokens → cacheReadTokens`、`prompt_cache_miss_tokens → inputTokens`、`completion_tokens → outputTokens`。**等价，但插件应消费规范化的 TokenUsage，而不是原始 DeepSeek 字段**（换 provider 也能工作）。

### 3.2 usage 出现的位置

| 事件 | 位置 | 说明 |
|---|---|---|
| `assistant/message` | `event.data.usage` | 每步完成/中断时的最终 usage（主采集点） |
| `assistant/chunk` | `event.data.chunk.type === 'usage'` 时 `chunk.usage` | 流中早期采样（可选，防请求失败丢数） |
| `compaction/summary` | `event.data.usage` + `shadowedTokenCount` | 压缩摘要 LLM 调用的 usage + 被替换范围的影子价 |

`assistant/message` 的 `data` 完整形状（`dsh-agent-loop` 与 SessionEventMap 声明）：

```ts
{ turn: number; step: number; message: AssistantMessage; usage?: TokenUsage; interrupted?: true }
// message.source = { provider, model, replayState? }
```

> 注意：`assistant/message` 可能**零内容**（max-tokens 截断步只承载 usage），surface 投影会跳过它，但 usage 仍要采。

### 3.3 已有的 token 计量服务（可复用，勿重复造轮子）

`dsh-token-meter` 服务（`ctx.tokenMeter`）已实现：
- `measure(session, requestHeader?)` → 请求压力 + 表面 token 的测量（baseline/surfaceTokens/totalTokens）；
- 注册了三个会话投影单元：`tokenUsage`（累计四桶）、`contextPressure`（上下文占用 %）、`contextBreakdown`（system/tools/message 构成）。

**含义**：token 计量是 DSH 一等公民。插件有两种数据源——(a) 自己订阅事件落明细库（本项目要的台账粒度）；(b) 读 `sessionProjections` / `tokenMeter.measure` 的聚合视图。M1 两者都用：明细走事件，聚合兜底走投影。

---

## 4 · goal 暴露面（任务归属）

### 4.1 会话事件 `goal/change`（主数据源）

`dsh-goal/lib/index.js`：`agent.session.append("goal/change", change)`。类型（`dsh-goal/lib/typert.host.js`）：

```ts
type GoalChangeMeta = GoalSnapshotChangeMeta | GoalClearChangeMeta;

interface GoalSnapshotChangeMeta {
  kind: 'goal/change'; version: 1;
  operation: 'create' | 'edit' | 'pause' | 'resume' | 'complete' | 'blocked';  // 快照操作
  goal: GoalSnapshot;          // { id, revision, objective, phase, blockedReason?, maxGoalRounds }
  roundsStarted: number;       // 已启动轮数（goal 续跑轮数！）
  createdAt: number; updatedAt: number;
}
interface GoalClearChangeMeta { kind: 'goal/change'; version: 1; operation: 'clear';
  cleared: { id; revision }; clearedAt: number; }

type GoalPhase = 'active' | 'paused' | 'blocked' | 'complete';
interface GoalBlockReason { code: string; message: string; }
```

**PRD 要的 goal 明细全有**：id、objective、phase、roundsStarted（续跑轮数）、maxGoalRounds、blockedReason、时间戳。goal 创建（create）时 `roundsStarted=0, phase='active', revision=1`。

### 4.2 Cordis 事件 `goal/changed`

`dsh-goal` 还发出作用域事件 `goal/changed`（参数 `{ change: GoalChangeMeta }`，按 agent carrier 作用域派发）。节点半区可在 agent 上下文里订阅，得到更聚焦的通知。**主采集仍以会话事件 `goal/change` 为准**（与 usage 同一条事件流，天然对齐时序）。

### 4.3 goal 消息归属

assistant 消息的 `message.source` 可为 `{ kind: 'goal', goalId, revision, round }`（`GoalMessageSource`）——即**每条消息可精确归属到 goal 的某个 round**，比"goal 生命周期事件 + 时间重叠推断"更精确。M1 按事件序维护"当前 goal 上下文"即可覆盖大部分场景，精确归属作为增强项。

### 4.4 读侧投影

HTTP API 的 goal 域**只暴露变更**（`goal.create/edit/pause/resume/complete/clear`，mutations only）；goal 当前状态通过会话投影 `'goal'` 读取（session.history/list 的 `projections.values['goal']`）。轮询兜底时读投影而非调 goal API。

---

## 5 · subagent 暴露面（子代理记录）

### 5.1 会话事件 `subagent/descriptor`（子会话身份）

子代理会话在首个 turn 内追加 `subagent/descriptor`（`dsh-subagent/lib/index.js`，版本 2）：

```ts
// one-shot:  { version: 2, mode: 'one-shot', provider, label? }
// continuable: { version: 2, mode: 'continuable', provider, label, agentProvider?, agentModel?, persona?, toolFilter? }
```

子会话本身也是 `Session`，其 `header.origin === 'subagent'`、`header.parentSession` 指向父会话、`header.delegationDepth` 为委托深度——**父子关系在会话头即得，无需额外维护**。

### 5.2 Cordis 生命周期事件 `subagent/start` / `subagent/end`

```ts
// start: { runId, provider, id /* 子会话 id */, local: boolean }，父会话 carrier 作用域
// end:   { runId, provider, id, local, stopReason: 'completed'|'error'|..., lastAssistantMessage? }
```

用于记录子任务何时开始/结束、成功/失败。token 明细仍从子会话自身的事件流采集，按 `parentSession` 归并到父任务。

---

## 6 · 会话元数据暴露面

| 数据 | 事件/字段 | 形状 |
|---|---|---|
| 标题 | `session/title` | `{ title, messageSeqs, source }`（source: user/llm/...） |
| 模型/参数 | `request/header` | `{ header: EpochHeader, reason }`；`EpochHeader = { config: LlmCallConfig, adapterDefaults?, system?, tools? }`；`LlmCallConfig = { provider, model, reasoningEffort?, temperature?, maxTokens?, stop? }` |
| 上下文窗口 | `request/context` | `{ provider, model, contextWindow? }`（如 128000） |
| 创建信息 | `session.header` | createdAt / cwd / parentSession / agentPreset / delegationDepth |
| 轮次边界 | `turn/start|end`、`step/start|end` | `{ turn, step? }`；turn/end 带 `reason` |
| 用户消息 | `user/message` | 完整 UserMessage（含 source、content） |
| 工具调用 | `tool/call|result` | callId/name/arguments；result 带 error/meta |
| 压缩 | `compaction/summary|prune` | shadowedRange/shadowedSeqs/shadowedTokenCount（**压缩吃掉的前缀 token 数**，命中率分析必用） |
| 计划模式 | `plan/mode` | 会话是否处于 plan mode |
| 待办 | `todo/write` | todos 数组（可辅助任务类型识别） |

---

## 7 · HTTP/RPC API 暴露面（轮询兜底与浏览器半区）

来自 `dsh-host-apiproxy/lib/types/api/*.schema.js`（RPC 域：session.* / goal.* / subagents / events / session-search）：

| API | 用途 | 与采集的关系 |
|---|---|---|
| `session.list` | 会话列表 | 返回 `SessionSummary`（含 `projections` 块：tokenUsage/contextPressure/goal/title 等） |
| `session.history` | 单会话事件历史 | `{ events: { event, view? }[], projections? }`，`beforeSeq/maxMessages` 向后翻页——**轮询兜底的主通道** |
| `events` | 事件订阅/帧 | session/event 帧的订阅通道（浏览器半区可实时收事件） |
| `goal.*` | goal 变更 | mutations only；读侧走 `projections['goal']` |
| `subagents` | 子代理查询 | 列表/详情（生命周期已由事件覆盖） |
| `session.search` | 全文检索 | 可作任务台账搜索后端 |

`sessionProjectionsBlock = { asOfSeq, values: Record<string, unknown> }`——`values` 包含 `tokenUsage`、`contextPressure`、`contextBreakdown`、`goal`、`title` 等投影单元的最新值。

---

## 8 · 采集方式决策

### 8.1 结论：事件驱动为主 + 启动回填兜底 + 投影兜底

```
主路径  插件启动
  │       ├─ 回填：遍历 ctx.sessions 既有会话，回放 session.events（按 seq 增量，游标记 lastSeq）
  │       └─ 订阅：ctx.on('session/event', ...) 实时增量
  ▼
运行期  事件驱动写入 SQLite（明细 messages/sessions/goals/subagents）
  │       └─ 每事件处理：usage → messages；goal/change → goals；descriptor → subagents
  ▼
聚合    定时（每小时）聚合 daily_agg；面板查询只走聚合表
兜底    ① HTTP session.history 翻页补数（插件挂掉重启后漏掉的窗口）
       ② projections 直接提供聚合视图（tokenUsage/contextPressure），可交叉校验
```

### 8.2 各兜底触发条件

| 场景 | 兜底 |
|---|---|
| 插件在 DSH 启动后加载（历史会话已存在） | 启动回填 `session.events` |
| 插件重启，期间会话有更新 | 按 `lastSeq` 游标续采（事件流本身是日志，天然可续） |
| 节点半区不可用、浏览器半区独立工作 | `session.history` + `events` 订阅 |
| usage 字段缺失（老版本/异常） | 降级为"未知"（`input_hit/miss/output = NULL`），不阻塞其他功能（PRD 风险表已列） |

### 8.3 对 PRD 的修正点

1. **usage 字段名**：PRD 写 `prompt_cache_hit_tokens / prompt_cache_miss_tokens / completion_tokens`（DeepSeek 原始字段）。实际消费 **DSH 规范化 TokenUsage**（inputTokens/outputTokens/cacheReadTokens/reasoningTokens），语义等价、跨 provider 通用。建议 PRD 数据模型改为记录规范化字段，另存 provider 原始快照可选。
2. **cacheWriteTokens**：DeepSeek 不报，恒缺省——费用估算无需此桶。
3. **goal 明细**：不只"goal id"——objective/phase/roundsStarted/maxGoalRounds 全部事件化，任务视图可直接用。
4. **compaction 影响**：`compaction/summary|prune` 的 `shadowedTokenCount` 是"被压缩掉的上下文 token"，缓存命中率与"前缀稳定性"分析应把压缩视为前缀变更点。M1 至少记录该事件。
5. **token 计量已有服务**：`ctx.tokenMeter` 与 `sessionProjections` 已提供聚合视图；M1 明细库与之并存（明细是插件自己的资产，聚合可交叉校验），避免重复实现估算逻辑时可复用其 `estimateMessage` 纯函数。

---

## 9 · 源码定位（复核索引）

| 内容 | 文件 |
|---|---|
| 事件词汇表 | `@deepseek-ai/dsh-session/lib/types/known-event-types.js` |
| 事件信封/订阅/session API | `@deepseek-ai/dsh-session/lib/types/index.js` |
| SessionEventMap 完整类型 | `@deepseek-ai/dsh-cordis-host-runner/lib/typert.host.js`（L1091 等） |
| TokenUsage 接口 | 各包 `typert.host.js` 的 `export interface TokenUsage` |
| DeepSeek usage 映射 | `@deepseek-ai/dsh-llm-deepseek/lib/types/translate.js` `mapUsage` |
| token 计量服务 | `@deepseek-ai/dsh-token-meter/lib/index.js` |
| goal/change 事件 | `@deepseek-ai/dsh-goal/lib/index.js`（append 于 L785，decode 于 L118-160） |
| goal/changed Cordis 事件 | `@deepseek-ai/dsh-goal/lib/index.js` L796 |
| subagent/descriptor | `@deepseek-ai/dsh-subagent/lib/index.js`（L320-470） |
| subagent/start|end | `@deepseek-ai/dsh-subagent/lib/index.js`（L199-260） |
| session.list/history schema | `@deepseek-ai/dsh-host-apiproxy/lib/types/api/sessions.schema.js` |
| goal API（mutations only） | `@deepseek-ai/dsh-host-apiproxy/lib/types/api/goals.schema.js` |
