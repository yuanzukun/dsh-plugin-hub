# backlog — dsh-token-attention

> 规则：新需求追加到末尾（带日期）；开始处理时移入本文件"进行中"小节；完成后归档到 archive/ 或标注 [done]。

## 进行中

- [2026-08-22] P0 初步 PRD（docs/PRD.html）：token 综合 + 对话管理面板 + 费用查看，任务/日/周/月记录，任务类型建议引擎（执行时机、换对话、hand-off）。[done]
- [2026-08-23] P0 DSH 接口勘察：确认 goal 明细（goal/change）、usage（规范化 TokenUsage）、subagent（descriptor/start/end）、会话元数据全部暴露 → 定采集方式为"事件驱动 + 启动回填兜底"（docs/dsh-interface-survey.md）。[done]
- [2026-08-23] P0 M1 采集层原型：src/node/{collector,store,pricing,api}.ts + demo.ts（node:sqlite 零依赖），事件→SQLite 落库（messages/sessions/goals/subagents/compactions/daily_agg），幂等/峰谷计价/聚合校正演示全绿；PRD M1 细化见 docs/PRD-M1-采集层.md。[done]
- [2026-08-23] P0 真实 DSH 联调 + MVP 面板：插件已注册到 web profile（link + bundle + cordis.patch.yml，dbPath 走 dshHomePath）；node 半区 = 采集 + /token-attention/api/*（health/summary/trend/models/sessions/tasks/advice）；client 半区 = 设置侧边栏 "词元管理" 入口，四视图（总览/会话/任务/费用）+ 建议卡。[真实联调通过，面板已显示真实数据]
- [2026-08-23] P0 任务×模型视角 + 建议引擎 v1：新增 src/shared/{task-type,quality,advice}.ts；API 按模型拆解（/models、/trend 模型堆叠、会话/任务卡带模型表与注意力分）；建议卡（时间/换对话/hand-off/上下文/费用/模型）。面板更名 Token Check（中文词元管理）。[done，待重启 DSH 验证面板]

## 待办

- [x] P0 重启 DSH 后验证：插件加载 / health / 真实会话事件落库 / 面板渲染 全部通过。
- [x] P0 面板 UI：五视图（总览/会话/任务/费用/设置）+ 任务/日/周/月切换；建议卡在总览。
- [x] P1 建议引擎：任务类型识别 + 时间/换对话/hand-off/上下文/费用/模型 建议卡；阈值可在设置中调整。
- [x] P1 会话消息下钻（#3）：会话卡「详情」展开，读 /sessions/:id 显示消息明细（角色/模型/峰谷/四桶/费用）。
- [x] P1 台账导出（#8）：任务视图「导出 Markdown / CSV」，Blob 下载（含类型、模型拆解、子代理归并）。
- [x] P1 subagent 归并明细（#9）：任务卡展示子代理表（label/模型/tokens/费用）；修复 upsertGoal 误标子代理会话导致归并重复计数的问题。
- [x] P2 hand-off 模板一键生成（任务卡「hand-off」按钮 → 下载 .md 模板，含目标/进度/消耗/模型/子代理/下一步）。
- [x] P2 建议引擎 model 卡真实数据验证：真实环境已出现 3 模型（flash/pro/grok-4.6）；当前 flash 占大头（80.6%）故 model 卡不触发（规则正确：仅当 pro 占优时提示），触发逻辑已在建议引擎中。
- [x] P3 重复会话去重（#2）：确认 DSH goal 续跑继承旧事件流（两个 M1 (1) 会话 295 条消息逐条一致）；按指纹（消息数+四桶+费用+时间戳）识别重复会话，保留最后活动者，全部统计排除重复——真实库任务 tokens 从 166.9M 修正为 122.2M（¥57.91→¥39.74）。顺带完成 P1-3 双源合并（summary/models/trend 统一从 messages 计算）。
- [x] FR7 设置（#1）：设置视图（单价表/峰谷时段/建议阈值 可编辑保存）；pricing 可注入；建议阈值可调；启动与保存时即时生效（新记录按新配置计费）。
- [x] 卸载验证（#3）：代码层面 dispose 完整（定时器清理 / SQLite 关闭 / 路由 effect 撤销 / 事件监听随 ctx 生命周期）。真实卸载操作需在 DSH 设置中手动验证。
- [x] 续跑合并（#2 升级）：去重从"指纹全等"升级为"前缀包含"——会话 A 消息集 ⊆ B 且更旧则 A 为 B 旧副本；真实库 sessions 3→1（只剩 M1），任务 86.9M/¥22.54。
- [x] #4 首启引导：无数据时总览显示欢迎卡（插件就绪说明 + 峰谷/命中提示）。
- [x] #5 发布产物：package.json v0.2.0，新增 prepare（build）/pack 脚本，files 含 dist/client/patch。
- [x] #6 文档：README 新增「安装到真实 DSH」「卸载」章节（含跨机 link 路径说明）。
- [x] #7 注意力 KPI：总览新增「注意力评分」卡（含"建议换会话"计数）。
- [x] #8 费用杠杆：费用视图"杠杆拆解"改为按桶费用占比（命中/未命中/输出各自估算费用，峰值全价/空闲半价），标题标注估算。
- [x] #9 建议采纳记录：建议卡加「采纳」按钮（持久化到 settings），总览建议区显示"已采纳 N 条"。
- [x] UI 轻量化：模型构成/会话卡模型列表改为纵向排列 + 间距；多模型调色板（10 色 hash 分配，不再统称"其他"）；趋势图例动态生成。
- [2026-08-22] 上架准备：package.json 去 private、补 license(MIT)/author/repository(Young4ever33)/keywords，files 排除 dist/node/demo.js，补 LICENSE；上架材料见 docs/market-entry.json（awesome-dsh-plugin 条目）与 docs/market-pr.md（PR 描述草稿）。[done，待 npm publish + GitHub 提 PR]
- [2026-08-22] 展示物料：中英双版 README（README.md 英文 / README.zh.md 中文）配真实界面截图（docs/screenshots/，5 张：总览/会话/任务/费用/设置），files 含 docs/screenshots；.gitignore 建立，独立 git 仓库。[done]

## 已关闭

- （无）
