/**
 * dsh-token-attention · M1 采集层自测（可独立运行，验证采集链路）
 *
 * 运行：node src/node/selftest.ts   （Node 24 直接跑 TS；产物写入 data/selftest-token_records.db）
 *
 * 自测内容：
 *  1. 主会话（goal 驱动，编码类任务）：request/header → session/title → request/context
 *     → goal/change(create) → 多轮 user/assistant（高峰+空闲时段）→ compaction → goal complete
 *  2. 子会话（subagent/descriptor + usage）→ 归并到父会话
 *  3. 校验：usage 四桶、费用估算（高峰 vs 空闲）、goal 状态、子代理归并、daily_agg 聚合
 */
import { openStore, dayOf } from './store.ts';
import { createCollector } from './collector.ts';
import { estimateCost, isPeak, periodOf, usageTotal } from '../shared/pricing.ts';
import type { SessionLike, SessionEvent } from '../shared/types.ts';

/* ---------------- 模拟时间（本地时区按北京时间） ---------------- */
function at(hour: number, minute = 0): number {
  const d = new Date();
  d.setHours(hour, minute, 0, 0);
  return d.getTime();
}
const T_PEAK = at(10, 30);  // 高峰
const T_IDLE = at(22, 0);   // 空闲

/* ---------------- 模拟会话事件流 ---------------- */
let seq = -1;
function ev(type: string, data: Record<string, any>, time: number, extra: Record<string, any> = {}): SessionEvent {
  seq += 1;
  return { type, seq, time, data, ...extra };
}

function buildMainSession(): SessionLike {
  seq = -1;
  const events: SessionEvent[] = [];
  const hdr = { version: 0, id: 'sess-main', createdAt: T_PEAK, cwd: 'A:\\08-DSH\\04-projects\\03-dsh-token-attention' };

  events.push(ev('request/header', {
    header: { config: { provider: 'deepseek', model: 'deepseek-v4-flash', reasoningEffort: 'medium', maxTokens: 8192 } },
    reason: 'initial',
  }, T_PEAK));
  events.push(ev('request/context', { provider: 'deepseek', model: 'deepseek-v4-flash', contextWindow: 128000 }, T_PEAK));
  events.push(ev('session/title', { title: '演示：M1 采集层', messageSeqs: [], source: { kind: 'user' } }, T_PEAK));
  events.push(ev('goal/change', {
    kind: 'goal/change', version: 1, operation: 'create',
    goal: { id: 'goal-1', revision: 1, objective: '完成 M1 数据采集层原型', phase: 'active', maxGoalRounds: 3 },
    roundsStarted: 0, createdAt: T_PEAK, updatedAt: T_PEAK,
  }, T_PEAK));

  // 第 1 轮（高峰）
  events.push(ev('turn/start', { turn: 0 }, T_PEAK));
  events.push(ev('user/message', { turn: 0, message: { id: 'm1', role: 'user', source: { kind: 'user' }, content: [{ type: 'text', text: '勘察 DSH 接口暴露面' }] } }, T_PEAK));
  events.push(ev('assistant/message', {
    turn: 0, step: 0,
    message: { id: 'a1', role: 'assistant', source: { kind: 'model', provider: 'deepseek', model: 'deepseek-v4-flash' }, content: [{ type: 'text', text: '已确认暴露面' }] },
    usage: { inputTokens: 1500, outputTokens: 800, cacheReadTokens: 300, reasoningTokens: 200 },
  }, T_PEAK, { surfaceOp: { start: 4, end: 5 }, sourceEventSeqs: [4] }));
  events.push(ev('turn/end', { turn: 0, reason: 'completed' }, T_PEAK));
  events.push(ev('goal/change', {
    kind: 'goal/change', version: 1, operation: 'resume',
    goal: { id: 'goal-1', revision: 2, objective: '完成 M1 数据采集层原型', phase: 'active', maxGoalRounds: 3 },
    roundsStarted: 1, createdAt: T_PEAK, updatedAt: T_PEAK,
  }, T_PEAK));

  // 第 2 轮（空闲，22:00）
  events.push(ev('turn/start', { turn: 1 }, T_IDLE));
  events.push(ev('user/message', { turn: 1, message: { id: 'm2', role: 'user', source: { kind: 'user' }, content: [{ type: 'text', text: '实现采集层原型' }] } }, T_IDLE));
  events.push(ev('assistant/message', {
    turn: 1, step: 0,
    message: { id: 'a2', role: 'assistant', source: { kind: 'model', provider: 'deepseek', model: 'deepseek-v4-flash' }, content: [{ type: 'text', text: '完成' }] },
    usage: { inputTokens: 800, outputTokens: 1200, cacheReadTokens: 1600, reasoningTokens: 100 },
  }, T_IDLE, { surfaceOp: { start: 8, end: 9 }, sourceEventSeqs: [8] }));
  events.push(ev('compaction/summary', {
    compactionId: 'comp-1', summary: [{ type: 'text', text: '摘要' }],
    shadowedRange: { start: 0, end: 4 }, shadowedSeqs: [0, 1, 2, 3, 4], shadowedTokenCount: 2200,
    provider: 'deepseek', model: 'deepseek-v4-flash', llmStreamCall: true,
  }, T_IDLE));
  events.push(ev('turn/end', { turn: 1, reason: 'completed' }, T_IDLE));

  // 第 3 轮（高峰）
  events.push(ev('turn/start', { turn: 2 }, T_PEAK));
  events.push(ev('user/message', { turn: 2, message: { id: 'm3', role: 'user', source: { kind: 'user' }, content: [{ type: 'text', text: '运行演示验证' }] } }, T_PEAK));
  events.push(ev('assistant/message', {
    turn: 2, step: 0,
    message: { id: 'a3', role: 'assistant', source: { kind: 'model', provider: 'deepseek', model: 'deepseek-v4-flash' }, content: [{ type: 'text', text: '验证通过' }] },
    usage: { inputTokens: 600, outputTokens: 400, cacheReadTokens: 900 },
  }, T_PEAK, { surfaceOp: { start: 12, end: 13 }, sourceEventSeqs: [12] }));
  events.push(ev('turn/end', { turn: 2, reason: 'completed' }, T_PEAK));
  events.push(ev('goal/change', {
    kind: 'goal/change', version: 1, operation: 'complete',
    goal: { id: 'goal-1', revision: 3, objective: '完成 M1 数据采集层原型', phase: 'complete', maxGoalRounds: 3 },
    roundsStarted: 3, createdAt: T_PEAK, updatedAt: T_PEAK,
  }, T_PEAK));

  return { id: 'sess-main', header: hdr, events };
}

function buildSubSession(): SessionLike {
  seq = -1;
  const events: SessionEvent[] = [];
  const hdr = { version: 0, id: 'sess-sub', createdAt: T_PEAK, cwd: 'A:\\08-DSH', origin: 'subagent' as const, parentSession: 'sess-main', delegationDepth: 1 };

  events.push(ev('request/header', { header: { config: { provider: 'deepseek', model: 'deepseek-v4-flash' } }, reason: 'initial' }, T_PEAK));
  events.push(ev('subagent/descriptor', { version: 2, mode: 'one-shot', provider: 'in-process-driver', label: '接口勘察子任务' }, T_PEAK));
  events.push(ev('turn/start', { turn: 0 }, T_PEAK));
  events.push(ev('user/message', { turn: 0, message: { id: 'sm1', role: 'user', source: { kind: 'user' }, content: [{ type: 'text', text: '勘察 goal 事件' }] } }, T_PEAK));
  events.push(ev('assistant/message', {
    turn: 0, step: 0,
    message: { id: 'sa1', role: 'assistant', source: { kind: 'model', provider: 'deepseek', model: 'deepseek-v4-flash' }, content: [{ type: 'text', text: 'goal/change 已确认' }] },
    usage: { inputTokens: 2000, outputTokens: 300, cacheReadTokens: 100 },
  }, T_IDLE, { surfaceOp: { start: 3, end: 4 }, sourceEventSeqs: [3] }));
  events.push(ev('turn/end', { turn: 0, reason: 'completed' }, T_IDLE));

  return { id: 'sess-sub', header: hdr, events };
}

/* ---------------- 断言工具 ---------------- */
let failures = 0;
function check(name: string, cond: boolean, detail = ''): void {
  const mark = cond ? 'PASS' : 'FAIL';
  if (!cond) failures += 1;
  console.log(`  [${mark}] ${name}${detail ? ' — ' + detail : ''}`);
}

/* ---------------- 主流程 ---------------- */
async function main(): Promise<void> {
  const dbPath = new URL('../../data/selftest-token_records.db', import.meta.url).pathname.replace(/^\/([A-Za-z]:)/, '$1');
  // 每次自测用全新库：旧库的 last_seq 游标会让重跑全部跳过（幂等），
  // 导致 daily 断言查的是"今天"而数据在旧日期，产生与实现无关的误报。
  const { rmSync } = await import('node:fs');
  for (const suffix of ['', '-wal', '-shm']) {
    try { rmSync(dbPath + suffix, { force: true }); } catch { /* 忽略 */ }
  }
  console.log('== M1 采集层自测 ==');
  console.log('DB:', dbPath);

  const store = openStore(dbPath);
  const collector = createCollector({ store, log: (m) => console.log('  ·', m) });

  const main = buildMainSession();
  const sub = buildSubSession();

  // 1) 启动回填（模拟插件在会话已存在后加载）
  console.log('\n[1] 启动回填（catch-up）');
  collector.backfill([main, sub]);

  // 2) 再跑一遍（幂等验证：重复回放不应重复记账）
  console.log('\n[2] 重复回放（幂等验证）');
  collector.backfill([main, sub]);

  // 3) 查询与断言
  console.log('\n[3] 断言');
  const sessions = store.querySessions();
  check('sessions 表 = 2 行（主+子）', sessions.length === 2, `got ${sessions.length}`);
  const mainRow = sessions.find((s) => s.id === 'sess-main');
  check('主会话模型 = deepseek-v4-flash', mainRow?.model === 'deepseek-v4-flash');
  check('主会话上下文窗口 = 128000', mainRow?.context_window === 128000);
  check('主会话标题', mainRow?.title === '演示：M1 采集层');
  check('主会话轮次数 = 3', mainRow?.turn_count === 2, `got ${mainRow?.turn_count} (0-based)`);
  const subRow = sessions.find((s) => s.id === 'sess-sub');
  check('子会话 origin = subagent', subRow?.origin === 'subagent');
  check('子会话 parent = sess-main', subRow?.parent_session === 'sess-main');

  const msgs = store.queryMessages('sess-main');
  const assistant = msgs.filter((m) => m.role === 'assistant');
  check('主会话 assistant 消息 = 3（幂等无重复）', assistant.length === 3, `got ${assistant.length}`);
  const peakMsgs = assistant.filter((m) => m.peak === 1);
  const idleMsgs = assistant.filter((m) => m.peak === 0);
  check('高峰 2 条 / 空闲 1 条', peakMsgs.length === 2 && idleMsgs.length === 1,
    `peak=${peakMsgs.length} idle=${idleMsgs.length}`);
  check('usage 桶落库（a1: hit=300 miss=1500 out=800）',
    assistant.some((m) => m.input_hit === 300 && m.input_miss === 1500 && m.output === 800));
  check('reasoning 落库（a2 reasoning=100）', assistant.some((m) => m.reasoning === 100));
  const costPeak = assistant.find((m) => m.turn === 0)?.cost_est ?? NaN;
  const costIdle = assistant.find((m) => m.turn === 1)?.cost_est ?? NaN;
  console.log(`  高峰 a1 费用估: ¥${costPeak.toFixed(4)} · 空闲 a2 费用估: ¥${costIdle.toFixed(4)}`);
  // 峰谷对比：同一 usage 在高峰 vs 空闲，费用应恰为 2 倍（见 [6] 直算）
  const uCmp = { inputTokens: 1500, outputTokens: 800, cacheReadTokens: 300, reasoningTokens: 200 };
  const cp = estimateCost(uCmp, T_PEAK, 'deepseek-v4-flash');
  const ci = estimateCost(uCmp, T_IDLE, 'deepseek-v4-flash');
  check('同 usage 高峰 = 2×空闲（峰谷计价生效）', Math.abs(cp.total / ci.total - 2) < 1e-9,
    `${cp.total.toFixed(6)} / ${ci.total.toFixed(6)} = ${(cp.total / ci.total).toFixed(4)}`);

  const g = store.queryGoals();
  check('goal 最新 revision = 3（complete）', g[0]?.revision === 3 && g[0]?.phase === 'complete',
    `rev=${g[0]?.revision} phase=${g[0]?.phase}`);
  check('goal roundsStarted = 3', g[0]?.rounds_started === 3);
  check('goal 关联到主会话', mainRow?.goal_id === 'goal-1');

  const subagents = store.querySubagents();
  check('subagents 记录 1 条（label=接口勘察子任务）', subagents.length === 1 && subagents[0]?.label === '接口勘察子任务');
  check('subagent 父会话归并', subagents[0]?.parent_session === 'sess-main');

  const comp = store.queryCompactions();
  check('compaction 记录 1 条（shadowed=2200 tokens）', comp.length === 1 && comp[0]?.shadowed_token_count === 2200);

  const day = dayOf(T_PEAK);
  const daily = store.queryDaily(day);
  check('daily_agg 2 行（peak+idle）', daily.length === 2, `got ${daily.length}`);
  const dp = daily.find((r) => r.peak === 1);
  const di = daily.find((r) => r.peak === 0);
  // 高峰行 = 主会话 a1(300/1500/800) + a3(900/600/400) = 1200/2100/1200
  check('聚合: 高峰 hit=1200 miss=2100 out=1200',
    dp?.input_hit === 1200 && dp?.input_miss === 2100 && dp?.output === 1200,
    JSON.stringify(dp));
  // 空闲行 = 主会话 a2(1600/800/1200) + 子会话 sa1(100/2000/300) = 1700/2800/1500
  check('聚合: 空闲 hit=1700 miss=2800 out=1500（含子会话）',
    di?.input_hit === 1700 && di?.input_miss === 2800 && di?.output === 1500,
    JSON.stringify(di));
  // 增量聚合按设计只保证 session_count ≥ 1（精确去重由 rebuildAgg 校正，见 [4]）。
  check('聚合 session_count（增量至少 1）', (dp?.session_count ?? 0) >= 1 && (di?.session_count ?? 0) >= 1,
    JSON.stringify(daily));

  // 交叉校验：daily_agg 与 messages 重算一致
  console.log('\n[4] 聚合重算（rebuildAgg 校正）');
  store.rebuildAgg(day);
  const daily2 = store.queryDaily(day);
  check('rebuild 后聚合不变（增量=重算一致）', daily2.length === daily.length
    && daily2.every((r) => {
      const old = daily.find((o) => o.model === r.model && o.peak === r.peak);
      return old !== undefined && old.input_hit === r.input_hit && old.cost === r.cost;
    }));
  // rebuild 用 COUNT(DISTINCT session_id) 得到精确去重：高峰=1 主会话，空闲=2 主+子
  const dp2 = daily2.find((r) => r.peak === 1);
  const di2 = daily2.find((r) => r.peak === 0);
  check('rebuild 后 session_count（高峰=1 主会话，空闲=2 主+子）',
    dp2?.session_count === 1 && di2?.session_count === 2,
    `peak=${dp2?.session_count} idle=${di2?.session_count}`);

  console.log('\n[5] 会话台账（可视化）');
  for (const s of sessions) {
    const ms = store.queryMessages(s.id);
    const tot = ms.filter((m) => m.role === 'assistant').reduce((a, m) => a + (m.input_hit ?? 0) + (m.input_miss ?? 0) + (m.output ?? 0), 0);
    const cost = ms.filter((m) => m.role === 'assistant').reduce((a, m) => a + (m.cost_est ?? 0), 0);
    console.log(`  ${s.id} [${s.model ?? '-'}] turns=${(s.turn_count ?? 0) + 1} tokens=${tot} 费≈¥${cost.toFixed(4)} goal=${s.goal_id ?? '-'} parent=${s.parent_session ?? '-'}`);
  }

  console.log('\n[6] 费用核对（estimateCost 直算）');
  const u1 = { inputTokens: 1500, outputTokens: 800, cacheReadTokens: 300, reasoningTokens: 200 };
  console.log(`  高峰 a1: ${JSON.stringify(estimateCost(u1, T_PEAK, 'deepseek-v4-flash'))}`);
  console.log(`  空闲 a1(同 usage): ${JSON.stringify(estimateCost(u1, T_IDLE, 'deepseek-v4-flash'))}`);

  store.close();
  console.log(`\n== 结果：${failures === 0 ? '全部通过 ✅' : failures + ' 项失败 ❌'} ==`);
  if (failures > 0) process.exitCode = 1;
}

await main();
