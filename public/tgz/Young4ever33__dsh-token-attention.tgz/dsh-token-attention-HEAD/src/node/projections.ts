/**
 * dsh-token-attention · node/projections
 *
 * 官方投影适配层（可选借用，最小改造方案）：
 *  - 上下文占用 ← @deepseek-ai/dsh-token-meter 的 contextPressure 投影单元
 *    （projectedTokens = 提供方样本 + 表层自取样以来的带符号增减，对压缩即时响应）
 *  - 会话统计   ← @deepseek-ai/dsh-session-stats 的 sessionStats 投影单元
 *    （轮/步/LLM/工具/首 token/解码时长与 tokens，与内置统计条同源）
 *
 * 读取方式：ctx.sessionProjections.stateOf(session, key) 返回 host 折叠状态。
 * contextPressure 的 host 状态不含 projectedTokens（那是 wire.view 折算的），
 * 这里按 view 公式自行折算（见 dsh-token-meter/lib/types/usage-projection.js）。
 * 任何一步失败（单元未注册 / 会话不可读 / 状态未就绪）都返回 null，
 * 由调用方回退到自有计算；本适配层保持零依赖、零运行时开销。
 */

/** contextPressure 的 host 折叠状态（stateOf 返回值，字段以官方 schema 为准）。 */
interface ContextPressureHostState {
  contextWindow?: number;
  /** 提供方最新上报的提示词规模（未缓存输入 + 缓存读写），不含输出。 */
  pressureTokens?: number;
  /** 表层启发式总量（token-meter 内部 fold，O(1) 维护）。 */
  surfaceTokens: number;
  /** 取样时刻的表层总量；缺失表示尚无提供方用量样本。 */
  sampledSurfaceTokens?: number;
}

/** 对外暴露的上下文占用值（与官方客户端 view 口径一致）。 */
export interface ContextPressureValue {
  /** 提供方最新上报的提示词规模（未缓存输入 + 缓存读写），不含输出。 */
  pressureTokens?: number;
  /** 官方占用分子：样本 + 表层自取样以来的带符号增减（压缩即刻反映）。 */
  projectedTokens?: number;
  /** 提供方/路由公布的最新上下文容量。 */
  contextWindow?: number;
}

/** sessionStats 的客户端 view 字段（与官方 wire 一致）。 */
export interface SessionStatsValue {
  /** 含至少一个已关闭步的不同 turn 数。 */
  turns: number;
  /** 已关闭的 step 数（完成/失败/取消/max-tokens 全部计入）。 */
  steps: number;
  /** step/start → assistant/message 的累计模型时长（ms）。 */
  llmMs: number;
  /** tool/call → tool/result 的累计工具时长（ms）。 */
  toolMs: number;
  /** step/start → 首个非空 delta 的累计首 token 时长（ms）。 */
  ttftMs: number;
  /** 计入 ttftMs 的步数。 */
  ttftSteps: number;
  /** 首 token → 已组装消息的累计解码时长（ms）。 */
  decodeMs: number;
  /** 提供方上报的输出 token 累计（仅统计时长与 tokens 兼备的步）。 */
  decodeTokens: number;
}

/** 按官方 view 公式折算 projectedTokens。 */
function projectedOf(state: ContextPressureHostState): number | undefined {
  if (state.pressureTokens === undefined || state.sampledSurfaceTokens === undefined) return undefined;
  return Math.max(0, state.pressureTokens + state.surfaceTokens - state.sampledSurfaceTokens);
}

export interface ProjectionsReader {
  /** 会话「上下文占用」官方值；不可用返回 null。 */
  contextPressure(sessionId: string): ContextPressureValue | null;
  /** 会话「统计条」官方值；不可用返回 null。 */
  sessionStats(sessionId: string): SessionStatsValue | null;
}

/** 需要的最小服务表面（不依赖 @deepseek-ai 类型包）。 */
export interface ProjectionsDeps {
  /** ctx.sessions：按 id 取 live Session 对象。 */
  sessions: { get(id: string): unknown };
  /** ctx.sessionProjections：投影注册表的 stateOf 读取。 */
  sessionProjections: { stateOf(session: unknown, key: string): unknown };
}

export function createProjectionsReader(deps: ProjectionsDeps): ProjectionsReader {
  const { sessions, sessionProjections } = deps;
  const read = (sessionId: string, key: string): unknown | null => {
    try {
      const session = sessions.get(sessionId);
      if (session === undefined || session === null) return null;
      const state = sessionProjections.stateOf(session, key);
      return state === undefined || state === null ? null : state;
    } catch {
      // 单元未注册 / 会话不可读 / 状态未就绪：一律视为「官方不可用」
      return null;
    }
  };
  return {
    contextPressure(sessionId) {
      const raw = read(sessionId, 'contextPressure');
      if (raw === null || typeof raw !== 'object') return null;
      const st = raw as Partial<ContextPressureHostState>;
      if (typeof st.surfaceTokens !== 'number') return null;
      const value: ContextPressureValue = {};
      if (typeof st.contextWindow === 'number') value.contextWindow = st.contextWindow;
      if (typeof st.pressureTokens === 'number') value.pressureTokens = st.pressureTokens;
      const projected = projectedOf(st as ContextPressureHostState);
      if (projected !== undefined) value.projectedTokens = projected;
      return value;
    },
    sessionStats(sessionId) {
      const raw = read(sessionId, 'sessionStats');
      if (raw === null || typeof raw !== 'object') return null;
      const st = raw as Partial<SessionStatsValue>;
      if (typeof st.turns !== 'number') return null;
      return {
        turns: st.turns,
        steps: st.steps ?? 0,
        llmMs: st.llmMs ?? 0,
        toolMs: st.toolMs ?? 0,
        ttftMs: st.ttftMs ?? 0,
        ttftSteps: st.ttftSteps ?? 0,
        decodeMs: st.decodeMs ?? 0,
        decodeTokens: st.decodeTokens ?? 0,
      };
    },
  };
}
