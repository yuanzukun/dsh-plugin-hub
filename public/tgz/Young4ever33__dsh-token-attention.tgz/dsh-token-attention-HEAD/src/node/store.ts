/**
 * dsh-token-attention · node/store
 *
 * SQLite 存储层（node:sqlite 内置 DatabaseSync，Node 24 零依赖）。
 * 表结构对齐 PRD §9 数据模型 v0.1，明细入 messages / goals / subagents /
 * compactions，聚合入 daily_agg（增量累加 + 可全量重算校正）。
 *
 * 设计要点：
 *  - messages 按 (session_id, seq) 唯一——会话事件 seq 天然幂等，重复回放不重复记账；
 *  - daily_agg 按 (day, model, peak) 主键，recordMessage 时增量累加；
 *  - sessions 表维护 last_seq 游标，支持"启动回填/断点续采"。
 */
import { DatabaseSync } from 'node:sqlite';
import { mkdirSync } from 'node:fs';
import { dirname } from 'node:path';
import type {
  SessionRecord, MessageRecord, GoalRecord, SubagentRecord, CompactionRecord,
} from '../shared/types.ts';
import { estimateCost, isPeak } from '../shared/pricing.ts';
import type { TokenUsage } from '../shared/types.ts';

export interface TokenStore {
  readonly dbPath: string;
  upsertSession(rec: Partial<SessionRecord> & { id: string; updated_at?: number; last_seq?: number }): void;
  recordAssistantMessage(args: {
    session_id: string; seq: number; turn: number; step: number; ts: number;
    provider: string | null; model: string | null;
    usage: TokenUsage; interrupted: boolean;
  }): void;
  recordUserTurn(args: { session_id: string; seq: number; turn: number; ts: number }): void;
  upsertGoal(g: GoalRecord): void;
  recordSubagent(rec: SubagentRecord): void;
  recordCompaction(rec: CompactionRecord): void;
  /** 按 (day, model, peak) 全量重算 daily_agg（定时校正用）。 */
  rebuildAgg(day: string): void;
  /** 读 goal 记录（按 updated_at 降序）。 */
  queryGoals(): GoalRow[];
  /** 读 daily_agg 区间行（含两端，day 形如 YYYY-MM-DD）。 */
  queryDailyRange(startDay: string, endDay: string): DailyAggRow[];
  /** 会话级聚合统计（token 四桶 + 费用 + 消息数 + 最后活动）。 */
  querySessionStats(): SessionStatRow[];
  /** 按时间区间读 assistant 消息（面板汇总用）。 */
  queryMessagesRange(start: number, end: number): RangeMessageRow[];
  /** 按 (session_id, model) 的 assistant 统计（会话模型拆解 / 任务模型拆解）。 */
  querySessionModelStats(): SessionModelStatRow[];
  /** 每会话压缩次数（前缀稳定性依据）。 */
  queryCompactionCounts(): CompactionCountRow[];
  /** 读 subagent 记录。 */
  querySubagents(): SubagentRow[];
  /** 读 compaction 记录。 */
  queryCompactions(): CompactionRow[];
  /** 读聚合：某日（或区间）各 model×peak 行。 */
  queryDaily(day: string): DailyAggRow[];
  /** 读会话明细。 */
  querySessions(): SessionRow[];
  /** 读消息明细（按会话）。 */
  queryMessages(sessionId: string, limit?: number): MessageRow[];
  /** 读会话最后一条 assistant 消息（上下文占用估算用；末尾可能是 user 消息而无 usage）。 */
  queryLastAssistantMessage(sessionId: string): MessageRow | null;
  /** 读插件设置（settings 表，JSON 字符串）。 */
  getSetting(key: string): string | null;
  /** 写插件设置。 */
  setSetting(key: string, value: string): void;
  /** 读全部设置。 */
  getAllSettings(): Record<string, string>;
  /** 运行时更新单价/峰谷（FR7，保存设置后立即对后续记录生效）。 */
  setPricing(prices?: Record<string, { hitIdle: number; missIdle: number; outputIdle: number }>, peakPeriods?: ReadonlyArray<{ start: number; end: number }>): void;
  close(): void;
}

export interface DailyAggRow {
  day: string; model: string | null; peak: 0 | 1;
  input_hit: number; input_miss: number; output: number;
  cost: number; session_count: number;
}
export interface SessionRow {
  id: string; title: string | null; provider: string | null; model: string | null;
  context_window: number | null; goal_id: string | null; origin: string | null;
  parent_session: string | null; created_at: number | null; updated_at: number;
  turn_count: number; last_seq: number; last_activity: number;
}
export interface MessageRow {
  session_id: string; seq: number; turn: number; step: number; role: string;
  provider: string | null; model: string | null; peak: 0 | 1;
  input_hit: number | null; input_miss: number | null; output: number | null;
  reasoning: number | null; cost_est: number | null; interrupted: 0 | 1; ts: number;
}
export interface GoalRow {
  id: string; revision: number; objective: string; phase: string;
  max_goal_rounds: number; rounds_started: number; blocked_reason: string | null;
  created_at: number; updated_at: number;
}
export interface SubagentRow {
  session_id: string; parent_session: string | null; provider: string | null;
  mode: string | null; label: string | null; delegation_depth: number | null; first_seen: number;
}
export interface CompactionRow {
  id: number; session_id: string; kind: string;
  shadowed_token_count: number; shadowed_seq_count: number; ts: number;
}
export interface SessionStatRow {
  session_id: string;
  msg_count: number;
  input_hit: number;
  input_miss: number;
  output: number;
  cost: number;
  last_ts: number;
}
export interface RangeMessageRow {
  session_id: string;
  input_hit: number | null;
  input_miss: number | null;
  output: number | null;
  cost_est: number | null;
  peak: 0 | 1;
  model: string | null;
  reasoning: number | null;
  interrupted: 0 | 1;
  ts: number;
}

/** 按 (session_id, model) 的 assistant 消息统计（会话模型拆解）。 */
export interface SessionModelStatRow {
  session_id: string;
  model: string | null;
  msg_count: number;
  input_hit: number;
  input_miss: number;
  output: number;
  reasoning: number;
  cost: number;
  interrupted: number;
  last_ts: number;
}

export interface CompactionCountRow {
  session_id: string;
  n: number;
}

const DDL = `
CREATE TABLE IF NOT EXISTS sessions (
  id             TEXT PRIMARY KEY,
  title          TEXT,
  provider       TEXT,
  model          TEXT,
  reasoning_effort TEXT,
  context_window INTEGER,
  goal_id        TEXT,
  origin         TEXT,
  parent_session TEXT,
  delegation_depth INTEGER,
  agent_preset   TEXT,
  created_at     INTEGER,
  updated_at     INTEGER,
  last_seq       INTEGER NOT NULL DEFAULT -1,
  turn_count     INTEGER NOT NULL DEFAULT 0,
  last_activity  INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS messages (
  id        INTEGER PRIMARY KEY AUTOINCREMENT,
  session_id TEXT NOT NULL,
  seq       INTEGER NOT NULL,
  turn      INTEGER NOT NULL,
  step      INTEGER NOT NULL,
  role      TEXT NOT NULL,
  provider  TEXT,
  model     TEXT,
  peak      INTEGER NOT NULL,
  input_hit INTEGER,
  input_miss INTEGER,
  output    INTEGER,
  reasoning INTEGER,
  cost_est  REAL,
  interrupted INTEGER NOT NULL DEFAULT 0,
  ts        INTEGER NOT NULL,
  UNIQUE(session_id, seq)
);
CREATE INDEX IF NOT EXISTS idx_messages_session ON messages(session_id, seq);
CREATE INDEX IF NOT EXISTS idx_messages_day ON messages(ts);
CREATE TABLE IF NOT EXISTS goals (
  id            TEXT NOT NULL,
  revision      INTEGER NOT NULL,
  objective     TEXT NOT NULL,
  phase         TEXT NOT NULL,
  max_goal_rounds INTEGER NOT NULL,
  rounds_started INTEGER NOT NULL,
  blocked_reason TEXT,
  created_at    INTEGER NOT NULL,
  updated_at    INTEGER NOT NULL,
  PRIMARY KEY (id, revision)
);
CREATE TABLE IF NOT EXISTS subagents (
  session_id      TEXT PRIMARY KEY,
  parent_session  TEXT,
  provider        TEXT,
  mode            TEXT,
  label           TEXT,
  delegation_depth INTEGER,
  first_seen      INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS compactions (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  session_id  TEXT NOT NULL,
  kind        TEXT NOT NULL,
  shadowed_token_count INTEGER NOT NULL,
  shadowed_seq_count INTEGER NOT NULL,
  ts          INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS settings (
  key   TEXT PRIMARY KEY,
  value TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS daily_agg (
  day           TEXT NOT NULL,
  model         TEXT,
  peak          INTEGER NOT NULL,
  input_hit     INTEGER NOT NULL DEFAULT 0,
  input_miss    INTEGER NOT NULL DEFAULT 0,
  output        INTEGER NOT NULL DEFAULT 0,
  cost          REAL NOT NULL DEFAULT 0,
  session_count INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (day, model, peak)
);
`;

export interface StoreOptions {
  /** 自定义单价表（FR7）；默认用 shared/pricing 的 DEFAULT_PRICES。 */
  prices?: Record<string, { hitIdle: number; missIdle: number; outputIdle: number }>;
  /** 自定义峰谷时段（FR7）；默认用 shared/pricing 的 PEAK_PERIODS。 */
  peakPeriods?: ReadonlyArray<{ start: number; end: number }>;
}

export function openStore(dbPath: string, options: StoreOptions = {}): TokenStore {
  // 运行时可变定价（FR7）：setPricing 会更新这两个引用，后续记录立即生效。
  let activePrices = options.prices;
  let activePeriods = options.peakPeriods;
  // node:sqlite 不会自动创建父目录；dbPath 可能来自 dshHomePath('token-attention/...')，
  // 目录首次不存在时先建好（recursive，相对路径按 cwd 解析）。
  mkdirSync(dirname(dbPath), { recursive: true });
  const db = new DatabaseSync(dbPath);
  db.exec('PRAGMA journal_mode = WAL;');
  db.exec('PRAGMA synchronous = NORMAL;');
  db.exec(DDL);

  const upsertSession: TokenStore['upsertSession'] = (rec) => {
    db.prepare(`
      INSERT INTO sessions (id, title, provider, model, reasoning_effort, context_window,
        goal_id, origin, parent_session, delegation_depth, agent_preset,
        created_at, updated_at, last_seq, turn_count, last_activity)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      ON CONFLICT(id) DO UPDATE SET
        title         = COALESCE(excluded.title, sessions.title),
        provider      = COALESCE(excluded.provider, sessions.provider),
        model         = COALESCE(excluded.model, sessions.model),
        reasoning_effort = COALESCE(excluded.reasoning_effort, sessions.reasoning_effort),
        context_window = COALESCE(excluded.context_window, sessions.context_window),
        goal_id       = COALESCE(excluded.goal_id, sessions.goal_id),
        origin        = COALESCE(excluded.origin, sessions.origin),
        parent_session = COALESCE(excluded.parent_session, sessions.parent_session),
        delegation_depth = COALESCE(excluded.delegation_depth, sessions.delegation_depth),
        agent_preset  = COALESCE(excluded.agent_preset, sessions.agent_preset),
        created_at    = COALESCE(excluded.created_at, sessions.created_at),
        updated_at    = MAX(sessions.updated_at, excluded.updated_at),
        last_seq      = MAX(sessions.last_seq, excluded.last_seq),
        turn_count    = MAX(sessions.turn_count, excluded.turn_count),
        last_activity = MAX(sessions.last_activity, excluded.last_activity)
    `).run(
      rec.id,
      rec.title ?? null, rec.provider ?? null, rec.model ?? null, rec.reasoning_effort ?? null,
      rec.context_window ?? null, rec.goal_id ?? null, rec.origin ?? null, rec.parent_session ?? null,
      rec.delegation_depth ?? null, rec.agent_preset ?? null,
      rec.created_at ?? null, rec.updated_at ?? Date.now(), rec.last_seq ?? -1,
      rec.turn_count ?? 0, rec.last_activity ?? Date.now(),
    );
  };

  const recordAssistantMessage: TokenStore['recordAssistantMessage'] = ({ session_id, seq, turn, step, ts, provider, model, usage, interrupted }) => {
    const peak = isPeak(ts, activePeriods) ? 1 : 0;
    const cost = estimateCost(usage, ts, model, activePrices, activePeriods);
    db.prepare(`
      INSERT INTO messages (session_id, seq, turn, step, role, provider, model, peak,
        input_hit, input_miss, output, reasoning, cost_est, interrupted, ts)
      VALUES (?, ?, ?, ?, 'assistant', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      ON CONFLICT(session_id, seq) DO UPDATE SET
        input_hit = excluded.input_hit, input_miss = excluded.input_miss,
        output = excluded.output, reasoning = excluded.reasoning,
        cost_est = excluded.cost_est, interrupted = excluded.interrupted
    `).run(
      session_id, seq, turn, step, provider ?? null, model ?? null, peak,
      usage.cacheReadTokens ?? null, usage.inputTokens, usage.outputTokens,
      usage.reasoningTokens ?? null, cost.total, interrupted ? 1 : 0, ts,
    );
    // 增量聚合
    const day = dayOf(ts);
    // 增量聚合（session_count 语义 = 去重会话数，由 rebuildAgg 的 COUNT(DISTINCT) 校正，
    // 增量只保证"至少 1"；面板查询以聚合表为准，需要精确去重时先跑 rebuildAgg）
    db.prepare(`
      INSERT INTO daily_agg (day, model, peak, input_hit, input_miss, output, cost, session_count)
      VALUES (?, ?, ?, ?, ?, ?, ?, 1)
      ON CONFLICT(day, model, peak) DO UPDATE SET
        input_hit = daily_agg.input_hit + excluded.input_hit,
        input_miss = daily_agg.input_miss + excluded.input_miss,
        output = daily_agg.output + excluded.output,
        cost = daily_agg.cost + excluded.cost
    `).run(day, model ?? null, peak,
      usage.cacheReadTokens ?? 0, usage.inputTokens, usage.outputTokens, cost.total);
    upsertSession({ id: session_id, provider, model, last_seq: seq, last_activity: ts });
  };

  const recordUserTurn: TokenStore['recordUserTurn'] = ({ session_id, seq, turn, ts }) => {
    db.prepare(`
      INSERT INTO messages (session_id, seq, turn, step, role, provider, model, peak,
        input_hit, input_miss, output, reasoning, cost_est, interrupted, ts)
      VALUES (?, ?, ?, 0, 'user', NULL, NULL, ?, NULL, NULL, NULL, NULL, NULL, 0, ?)
      ON CONFLICT(session_id, seq) DO NOTHING
    `).run(session_id, seq, turn, isPeak(ts, activePeriods) ? 1 : 0, ts);
  };

  const upsertGoal: TokenStore['upsertGoal'] = (g) => {
    db.prepare(`
      INSERT INTO goals (id, revision, objective, phase, max_goal_rounds, rounds_started,
        blocked_reason, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      ON CONFLICT(id, revision) DO UPDATE SET
        objective = excluded.objective, phase = excluded.phase,
        max_goal_rounds = excluded.max_goal_rounds, rounds_started = excluded.rounds_started,
        blocked_reason = excluded.blocked_reason, updated_at = excluded.updated_at
    `).run(g.id, g.revision, g.objective, g.phase, g.max_goal_rounds, g.rounds_started,
      g.blocked_reason, g.created_at, g.updated_at);
    // 会话 ↔ goal 关联由 collector 的 goal/change 事件精确写入（upsertSession goal_id），
    // 不再批量 UPDATE：否则会把子代理/无关会话误标成该 goal，导致任务归并重复计数。
  };

  const recordSubagent: TokenStore['recordSubagent'] = (rec) => {
    db.prepare(`
      INSERT INTO subagents (session_id, parent_session, provider, mode, label, delegation_depth, first_seen)
      VALUES (?, ?, ?, ?, ?, ?, ?)
      ON CONFLICT(session_id) DO UPDATE SET
        parent_session = COALESCE(excluded.parent_session, subagents.parent_session),
        provider = COALESCE(excluded.provider, subagents.provider),
        mode = COALESCE(excluded.mode, subagents.mode),
        label = COALESCE(excluded.label, subagents.label)
    `).run(rec.session_id, rec.parent_session, rec.provider, rec.mode, rec.label,
      rec.delegation_depth, rec.first_seen);
  };

  const recordCompaction: TokenStore['recordCompaction'] = (rec) => {
    db.prepare(`
      INSERT INTO compactions (session_id, kind, shadowed_token_count, shadowed_seq_count, ts)
      VALUES (?, ?, ?, ?, ?)
    `).run(rec.session_id, rec.kind, rec.shadowed_token_count, rec.shadowed_seq_count, rec.ts);
  };

  const queryGoals: TokenStore['queryGoals'] = () => {
    return db.prepare(`
      SELECT id, revision, objective, phase, max_goal_rounds, rounds_started,
             blocked_reason, created_at, updated_at
      FROM goals ORDER BY id, revision DESC
    `).all() as unknown as GoalRow[];
  };

  const querySubagents: TokenStore['querySubagents'] = () => {
    return db.prepare(`
      SELECT session_id, parent_session, provider, mode, label, delegation_depth, first_seen
      FROM subagents ORDER BY first_seen DESC
    `).all() as unknown as SubagentRow[];
  };

  const queryCompactions: TokenStore['queryCompactions'] = () => {
    return db.prepare(`
      SELECT id, session_id, kind, shadowed_token_count, shadowed_seq_count, ts
      FROM compactions ORDER BY ts DESC
    `).all() as unknown as CompactionRow[];
  };

  const queryDailyRange: TokenStore['queryDailyRange'] = (startDay, endDay) => {
    return db.prepare(`
      SELECT day, model, peak, input_hit, input_miss, output, cost, session_count
      FROM daily_agg WHERE day >= ? AND day <= ? ORDER BY day, peak, model
    `).all(startDay, endDay) as unknown as DailyAggRow[];
  };

  const queryMessagesRange: TokenStore['queryMessagesRange'] = (start, end) => {
    return db.prepare(`
      SELECT session_id, input_hit, input_miss, output, cost_est, peak, model, reasoning, interrupted, ts
      FROM messages
      WHERE role = 'assistant' AND ts >= ? AND ts < ?
    `).all(start, end) as unknown as RangeMessageRow[];
  };

  const querySessionModelStats: TokenStore['querySessionModelStats'] = () => {
    return db.prepare(`
      SELECT session_id, model,
             COUNT(*) AS msg_count,
             COALESCE(SUM(input_hit), 0) AS input_hit,
             COALESCE(SUM(input_miss), 0) AS input_miss,
             COALESCE(SUM(output), 0) AS output,
             COALESCE(SUM(reasoning), 0) AS reasoning,
             COALESCE(SUM(cost_est), 0) AS cost,
             COALESCE(SUM(interrupted), 0) AS interrupted,
             MAX(ts) AS last_ts
      FROM messages
      WHERE role = 'assistant'
      GROUP BY session_id, model
    `).all() as unknown as SessionModelStatRow[];
  };

  const queryCompactionCounts: TokenStore['queryCompactionCounts'] = () => {
    return db.prepare(`
      SELECT session_id, COUNT(*) AS n
      FROM compactions
      GROUP BY session_id
    `).all() as unknown as CompactionCountRow[];
  };

  const querySessionStats: TokenStore['querySessionStats'] = () => {
    return db.prepare(`
      SELECT m.session_id,
             COUNT(*) AS msg_count,
             COALESCE(SUM(m.input_hit), 0) AS input_hit,
             COALESCE(SUM(m.input_miss), 0) AS input_miss,
             COALESCE(SUM(m.output), 0) AS output,
             COALESCE(SUM(m.cost_est), 0) AS cost,
             MAX(m.ts) AS last_ts
      FROM messages m
      WHERE m.role = 'assistant'
      GROUP BY m.session_id
    `).all() as unknown as SessionStatRow[];
  };

  const rebuildAgg: TokenStore['rebuildAgg'] = (day) => {
    db.prepare('DELETE FROM daily_agg WHERE day = ?').run(day);
    const start = new Date(day + 'T00:00:00+08:00').getTime();
    const end = start + 24 * 3600 * 1000;
    const rows = db.prepare(`
      SELECT model, peak, COUNT(DISTINCT session_id) AS sessions,
             COALESCE(SUM(input_hit), 0) AS ih, COALESCE(SUM(input_miss), 0) AS im,
             COALESCE(SUM(output), 0) AS out, COALESCE(SUM(cost_est), 0) AS cost
      FROM messages
      WHERE ts >= ? AND ts < ? AND role = 'assistant'
      GROUP BY model, peak
    `).all(start, end) as Array<Record<string, any>>;
    for (const r of rows) {
      db.prepare(`
        INSERT INTO daily_agg (day, model, peak, input_hit, input_miss, output, cost, session_count)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
      `).run(day, r.model, r.peak, r.ih, r.im, r.out, r.cost, r.sessions);
    }
  };

  const queryDaily: TokenStore['queryDaily'] = (day) => {
    return db.prepare(`
      SELECT day, model, peak, input_hit, input_miss, output, cost, session_count
      FROM daily_agg WHERE day = ? ORDER BY peak, model
    `).all(day) as unknown as DailyAggRow[];
  };

  const querySessions: TokenStore['querySessions'] = () => {
    return db.prepare(`
      SELECT id, title, provider, model, context_window, goal_id, origin, parent_session,
             created_at, updated_at, turn_count, last_seq, last_activity
      FROM sessions ORDER BY last_activity DESC
    `).all() as unknown as SessionRow[];
  };

  const queryMessages: TokenStore['queryMessages'] = (sessionId, limit = 200) => {
    return db.prepare(`
      SELECT session_id, seq, turn, step, role, provider, model, peak,
             input_hit, input_miss, output, reasoning, cost_est, interrupted, ts
      FROM messages WHERE session_id = ? ORDER BY seq DESC LIMIT ?
    `).all(sessionId, limit) as unknown as MessageRow[];
  };

  const queryLastAssistantMessage: TokenStore['queryLastAssistantMessage'] = (sessionId) => {
    const rows = db.prepare(`
      SELECT session_id, seq, turn, step, role, provider, model, peak,
             input_hit, input_miss, output, reasoning, cost_est, interrupted, ts
      FROM messages WHERE session_id = ? AND role = 'assistant'
      ORDER BY seq DESC LIMIT 1
    `).all(sessionId) as unknown as MessageRow[];
    return rows[0] ?? null;
  };

  const getSetting: TokenStore['getSetting'] = (key) => {
    const row = db.prepare('SELECT value FROM settings WHERE key = ?').get(key) as { value: string } | undefined;
    return row?.value ?? null;
  };
  const setSetting: TokenStore['setSetting'] = (key, value) => {
    db.prepare(`
      INSERT INTO settings (key, value) VALUES (?, ?)
      ON CONFLICT(key) DO UPDATE SET value = excluded.value
    `).run(key, value);
  };
  const getAllSettings: TokenStore['getAllSettings'] = () => {
    const rows = db.prepare('SELECT key, value FROM settings').all() as Array<{ key: string; value: string }>;
    const out: Record<string, string> = {};
    for (const r of rows) out[r.key] = r.value;
    return out;
  };
  const setPricing: TokenStore['setPricing'] = (prices, peakPeriods) => {
    if (prices !== undefined) activePrices = prices;
    if (peakPeriods !== undefined) activePeriods = peakPeriods;
  };

  return {
    dbPath,
    upsertSession,
    recordAssistantMessage,
    recordUserTurn,
    upsertGoal,
    recordSubagent,
    recordCompaction,
    rebuildAgg,
    queryDaily,
    querySessions,
    queryMessages,
    queryGoals,
    querySubagents,
    queryCompactions,
    queryDailyRange,
    querySessionStats,
    queryMessagesRange,
    querySessionModelStats,
    queryCompactionCounts,
    queryLastAssistantMessage,
    getSetting,
    setSetting,
    getAllSettings,
    setPricing,
    close: () => db.close(),
  };
}

/** 本地时区（按北京时间）的 YYYY-MM-DD。 */
export function dayOf(ts: number): string {
  const d = new Date(ts);
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}
