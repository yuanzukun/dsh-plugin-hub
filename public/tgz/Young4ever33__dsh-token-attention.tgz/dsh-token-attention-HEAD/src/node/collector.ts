/**
 * dsh-token-attention · node/collector
 *
 * 事件采集器：把 DSH 的 session/event 流翻译为 SQLite 记录。
 * 与 Cordis 解耦（输入为 SessionLike + SessionEvent），便于独立测试/演示；
 * 正式接入见 index.ts（ctx.on('session/event')）。
 *
 * 采集映射（详见 docs/dsh-interface-survey.md）：
 *  - assistant/message → messages（usage 四桶 + 费用估算）
 *  - request/header    → sessions.model/provider（EpochHeader.config）
 *  - request/context   → sessions.context_window
 *  - session/title     → sessions.title
 *  - goal/change       → goals + sessions.goal_id
 *  - subagent/descriptor → subagents（子会话身份，parent 取自 header）
 *  - compaction/*      → compactions（前缀稳定性/命中率分析依据）
 *  - turn/start        → sessions.turn_count
 *  - user/message      → messages(role=user)（轮次存在性，无 usage）
 */
import type { TokenStore, SessionRow } from './store.ts';
import type { SessionLike, SessionEvent, GoalChangeMeta, SubagentDescriptor, TokenUsage } from '../shared/types.ts';

export interface CollectorOptions {
  store: TokenStore;
  /** 默认按 DSH 事件日志回放全部 seq；测试可传 0 关掉跳过逻辑。 */
  log?: (msg: string) => void;
}

export interface Collector {
  /** 处理单个会话事件（session/event 回调体）。 */
  handle(session: SessionLike, event: SessionEvent): void;
  /**
   * 启动回填：对既有会话按 last_seq 游标增量回放（catch-up）。
   * 幂等：重复回放由 messages(session_id, seq) 唯一约束兜底。
   */
  backfill(sessions: SessionLike[]): void;
  /** 会话当前已消费到的 seq（调试用）。 */
  cursor(sessionId: string): number;
}

export function createCollector(opts: CollectorOptions): Collector {
  const { store, log = () => {} } = opts;
  /** 每个会话已消费的 seq（幂等游标）。 */
  const cursors = new Map<string, number>();

  // 初始化游标：从库里已有的 last_seq 继续
  for (const row of store.querySessions()) cursors.set(row.id, row.last_seq);

  function handle(session: SessionLike, event: SessionEvent): void {
    const prev = cursors.get(session.id) ?? -1;
    if (event.seq <= prev) return; // 已消费（幂等）
    cursors.set(session.id, event.seq);

    switch (event.type) {
      case 'assistant/message': {
        const d = event.data as { turn: number; step: number; message?: { source?: { provider?: string; model?: string } }; usage?: TokenUsage; interrupted?: true };
        const usage = d.usage;
        if (!usage) break; // 无 usage 的 assistant/message（异常路径）——降级为"未知"，不阻塞
        store.recordAssistantMessage({
          session_id: session.id, seq: event.seq, turn: d.turn, step: d.step, ts: event.time,
          provider: d.message?.source?.provider ?? null,
          model: d.message?.source?.model ?? null,
          usage, interrupted: d.interrupted === true,
        });
        break;
      }
      case 'user/message': {
        const d = event.data as { turn?: number };
        store.recordUserTurn({ session_id: session.id, seq: event.seq, turn: d.turn ?? 0, ts: event.time });
        break;
      }
      case 'request/header': {
        const d = event.data as { header?: { config?: { provider?: string; model?: string; reasoningEffort?: string } } };
        const cfg = d.header?.config;
        if (cfg) {
          store.upsertSession({
            id: session.id,
            provider: cfg.provider ?? null,
            model: cfg.model ?? null,
            reasoning_effort: cfg.reasoningEffort ?? null,
            last_seq: event.seq, last_activity: event.time,
          });
        }
        break;
      }
      case 'request/context': {
        const d = event.data as { provider?: string; model?: string; contextWindow?: number };
        store.upsertSession({
          id: session.id, provider: d.provider ?? null, model: d.model ?? null,
          context_window: d.contextWindow ?? null,
          last_seq: event.seq, last_activity: event.time,
        });
        break;
      }
      case 'session/title': {
        const d = event.data as { title?: string };
        if (typeof d.title === 'string') {
          store.upsertSession({ id: session.id, title: d.title, last_seq: event.seq, last_activity: event.time });
        }
        break;
      }
      case 'goal/change': {
        const change = event.data as GoalChangeMeta;
        if (change.operation === 'clear') break;
        const g = change.goal;
        if (!g) break;
        store.upsertGoal({
          id: g.id, revision: g.revision, objective: g.objective, phase: g.phase,
          max_goal_rounds: g.maxGoalRounds, rounds_started: change.roundsStarted ?? 0,
          blocked_reason: g.blockedReason ? `${g.blockedReason.code}: ${g.blockedReason.message}` : null,
          created_at: change.createdAt ?? event.time, updated_at: change.updatedAt ?? event.time,
        });
        store.upsertSession({ id: session.id, goal_id: g.id, last_seq: event.seq, last_activity: event.time });
        break;
      }
      case 'subagent/descriptor': {
        const desc = event.data as SubagentDescriptor;
        store.recordSubagent({
          session_id: session.id,
          parent_session: session.header?.parentSession ?? null,
          provider: desc.provider ?? null,
          mode: desc.mode ?? null,
          label: desc.label ?? null,
          delegation_depth: session.header?.delegationDepth ?? null,
          first_seen: event.time,
        });
        store.upsertSession({
          id: session.id,
          origin: 'subagent',
          parent_session: session.header?.parentSession ?? null,
          delegation_depth: session.header?.delegationDepth ?? null,
          created_at: session.header?.createdAt ?? null,
          agent_preset: session.header?.agentPreset ?? null,
          last_seq: event.seq, last_activity: event.time,
        });
        break;
      }
      case 'compaction/summary':
      case 'compaction/prune': {
        const d = event.data as { shadowedTokenCount?: number; shadowedSeqs?: number[] };
        store.recordCompaction({
          session_id: session.id,
          kind: event.type === 'compaction/summary' ? 'summary' : 'prune',
          shadowed_token_count: d.shadowedTokenCount ?? 0,
          shadowed_seq_count: d.shadowedSeqs?.length ?? 0,
          ts: event.time,
        });
        break;
      }
      case 'turn/start': {
        const d = event.data as { turn?: number };
        const t = d.turn ?? 0;
        store.upsertSession({ id: session.id, turn_count: Math.max(0, t), last_seq: event.seq, last_activity: event.time });
        break;
      }
      default:
        // 其他事件（tool/call、approval/*、plan/mode、todo/write 等）M1 暂不落库
        break;
    }
  }

  function backfill(sessions: SessionLike[]): void {
    for (const session of sessions) {
      const started = cursors.get(session.id) ?? -1;
      for (const event of session.events) {
        if (event.seq > started) handle(session, event);
      }
      log(`backfill ${session.id}: ${session.events.length} events (cursor ${started} → ${cursors.get(session.id) ?? -1})`);
    }
  }

  return {
    handle,
    backfill,
    cursor: (sessionId) => cursors.get(sessionId) ?? -1,
  };
}

/** 从查询结果构造游标（供测试直接设置）。 */
export function cursorFromRows(rows: SessionRow[]): Map<string, number> {
  return new Map(rows.map((r) => [r.id, r.last_seq]));
}
