/**
 * dsh-token-attention · node 半区入口（Cordis apply）
 *
 * 职责：
 *  1. 订阅 session/event，把 usage / goal / subagent / 会话元数据写入 SQLite（collector）；
 *  2. 启动回填：对既有会话增量回放（catch-up，last_seq 游标幂等）；
 *  3. 定时聚合 daily_agg（增量累加 + 每日全量校正）；
 *  4. 挂载面板数据 API（/token-attention/api/*，见 api.ts）。
 *
 * 注册（bundle 机制）：cordis.patch.yml insert + web profile package.json bundles。
 */
import { openStore, dayOf } from './store.ts';
import { createCollector } from './collector.ts';
import { createPanelApi } from './api.ts';
import { createProjectionsReader, type ProjectionsReader } from './projections.ts';

export const name = 'dsh-token-attention';
export const inject = ['webServer', 'sessions'];

export interface TokenAttentionConfig {
  /** SQLite 落库路径（patch 中通常用 !!js dshHomePath('token-attention/token_records.db')）。 */
  dbPath?: string;
  /** 聚合定时（毫秒）。默认 1 小时。 */
  aggIntervalMs?: number;
}

export function apply(ctx: any, config: TokenAttentionConfig = {}): void {
  const dbPath = config.dbPath ?? 'data/token_records.db';
  const aggIntervalMs = config.aggIntervalMs ?? 3600_000;
  const log = (msg: string): void => { ctx.logger?.info(`[token-attention] ${msg}`); };

  const store = openStore(dbPath);
  // FR7：启动时读设置（单价表/峰谷时段），后续新记录按配置计费
  let storeOptions: { prices?: Record<string, { hitIdle: number; missIdle: number; outputIdle: number }>; peakPeriods?: ReadonlyArray<{ start: number; end: number }> } = {};
  try {
    const all = store.getAllSettings();
    const parse = (key: string, fallback: unknown): unknown => { try { return JSON.parse(all[key] ?? 'null') ?? fallback; } catch { return fallback; } };
    storeOptions = {
      prices: parse('prices', undefined) as Record<string, { hitIdle: number; missIdle: number; outputIdle: number }> | undefined,
      peakPeriods: parse('peakPeriods', undefined) as ReadonlyArray<{ start: number; end: number }> | undefined,
    };
    if (storeOptions.prices || storeOptions.peakPeriods) log('using custom pricing settings');
    store.setPricing(storeOptions.prices, storeOptions.peakPeriods);
  } catch {
    // 设置损坏时回退默认，不阻塞启动
  }
  const collector = createCollector({ store, log });

  // 官方投影适配层（可选借用）：base 层挂载 session-projection + token-meter + session-stats
  // 时启用，会话卡的「上下文占用 / 会话统计」读官方口径；未挂载（如 headless 装配）时
  // projectionReader 保持 null，API 回退到自有计算。
  let projectionReader: ProjectionsReader | null = null;
  ctx.inject(['sessionProjections', 'sessions'], (projectionCtx: any) => {
    projectionReader = createProjectionsReader({
      sessions: projectionCtx.sessions,
      sessionProjections: projectionCtx.sessionProjections,
    });
    log('official projections adapter active (contextPressure / sessionStats)');
  });

  const api = createPanelApi({
    store,
    log,
    getProjections: () => projectionReader,
    // 归档状态：读 workspaceRegistry（DSH 归档=删除），服务缺失时返回空集（全部视为未归档）。
    getArchivedSessionIds: () =>
      new Set((ctx.get?.('workspaceRegistry') as { archivedSessionIds?: string[] } | undefined)?.archivedSessionIds ?? []),
  });

  log(`store: ${dbPath}`);

  // 1) 实时事件采集
  ctx.on('session/event', (session: any, event: any) => {
    try {
      collector.handle(session, event);
    } catch (err) {
      ctx.logger?.warn(`[token-attention] session/event ${event?.type} failed: ${String(err)}`);
    }
  });

  // 2) 会话创建即回填（含既有会话的启动回填）
  const backfillSession = (session: any): void => {
    try {
      collector.backfill([session]);
    } catch (err) {
      ctx.logger?.warn(`[token-attention] backfill ${session?.id} failed: ${String(err)}`);
    }
  };
  try {
    for (const session of ctx.sessions.list()) backfillSession(session);
    log(`backfilled ${ctx.sessions.list().length} existing sessions`);
  } catch (err) {
    ctx.logger?.warn(`[token-attention] startup backfill failed: ${String(err)}`);
  }
  ctx.on('session/created', backfillSession);

  // 3) 定时聚合（每小时全量重算今日；启动时一次）
  const rebuildToday = (): void => {
    try {
      store.rebuildAgg(dayOf(Date.now()));
    } catch (err) {
      ctx.logger?.warn(`[token-attention] rebuildAgg failed: ${String(err)}`);
    }
  };
  rebuildToday();
  // 用全局 setInterval（不依赖 Cordis timer 服务的 inject 机制）；
  // dispose 时清理。
  const aggTimer = setInterval(rebuildToday, aggIntervalMs);
  ctx.on('dispose', () => clearInterval(aggTimer));

  // 4) 面板数据 API（前缀避开 /api 浏览器信任围栏）
  ctx.effect(() => {
    ctx.webServer.register({
      kind: 'prefix',
      path: '/token-attention/api',
      handler: api,
    });
  }, 'token-attention: api');

  ctx.on('dispose', () => {
    store.close();
    log('disposed');
  });
}
