/**
 * dsh-token-attention · node/api
 *
 * 面板数据 API（挂载于 webServer，前缀 /token-attention/api）。
 * 用 /token-attention 前缀而非 /api 前缀，避开 DSH 的 /api 浏览器信任围栏
 * （与 dsh-synapse 的 /synapse/api 同理，见 docs/dsh-interface-survey.md §12.6）。
 *
 * 路由：
 *   GET /token-attention/api/health             插件/DB 状态
 *   GET /token-attention/api/summary?scope=day  汇总 KPI（day|week|month）
 *   GET /token-attention/api/daily?days=7       近 N 天聚合（柱状图）
 *   GET /token-attention/api/sessions           会话列表 + 聚合统计
 *   GET /token-attention/api/sessions/:id       会话消息明细
 *   GET /token-attention/api/tasks              goal 任务台账
 */
import type { TokenStore, DailyAggRow, SessionRow, GoalRow, RangeMessageRow, SessionModelStatRow } from './store.ts';
import { dayOf } from './store.ts';
import { classifyTaskType, taskTypeLabel, type TaskTypeId } from '../shared/task-type.ts';
import {
  attentionScore, healthBadge, cacheHitRatePct, unitOutputCost,
  interruptRatePct, reasoningSharePct, occupancyPct,
} from '../shared/quality.ts';
import { generateAdvice, idleHint, shortModel, type AdviceCard } from '../shared/advice.ts';
import { DEFAULT_PRICES, PEAK_PERIODS, estimateCost } from '../shared/pricing.ts';
import type { ProjectionsReader } from './projections.ts';

/** goals 按 id 去重，取最新 revision（queryGoals 按 id, revision DESC 排序）。 */
function latestGoals(goals: GoalRow[]): GoalRow[] {
  const seen = new Set<string>();
  const out: GoalRow[] = [];
  for (const g of goals) {
    if (seen.has(g.id)) continue;
    seen.add(g.id);
    out.push(g);
  }
  return out;
}

export interface PanelApiOptions {
  store: TokenStore;
  log?: (msg: string) => void;
  /** 官方投影读取器（可选）：base 层挂载 token-meter/session-stats 时提供，否则为 null。 */
  getProjections?: () => ProjectionsReader | null;
  /** 归档会话 id 集合（来自 workspaceRegistry.archivedSessionIds；服务缺失时返回空集）。 */
  getArchivedSessionIds?: () => ReadonlySet<string>;
}

type Handler = (req: any, res: any, pathname: string, query: URLSearchParams) => void | Promise<void>;

/** 组装 webServer 路由处理器（原生 http req/res 风格，与 dsh-synapse 一致）。 */
export function createPanelApi(opts: PanelApiOptions): Handler {
  const { store, log = () => {} } = opts;

  const sendJson = (res: any, status: number, body: unknown): void => {
    res.writeHead(status, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' });
    res.end(JSON.stringify(body));
  };

  const scopeRange = (scope: string): { start: number; startDay: string; end: number } => {
    const now = new Date();
    if (scope === 'week') {
      const d = new Date(now);
      const dow = (d.getDay() + 6) % 7; // 周一 = 0
      d.setDate(d.getDate() - dow);
      d.setHours(0, 0, 0, 0);
      return { start: d.getTime(), startDay: dayOf(d.getTime()), end: now.getTime() };
    }
    if (scope === 'month') {
      const d = new Date(now.getFullYear(), now.getMonth(), 1);
      return { start: d.getTime(), startDay: dayOf(d.getTime()), end: now.getTime() };
    }
    const d = new Date(now);
    d.setHours(0, 0, 0, 0);
    return { start: d.getTime(), startDay: dayOf(d.getTime()), end: now.getTime() };
  };

  const summarizeMessages = (rows: Array<{ input_hit: number | null; input_miss: number | null; output: number | null; cost_est: number | null; peak: 0 | 1; session_id: string; model: string | null }>) => {
    let inputHit = 0, inputMiss = 0, output = 0, cost = 0, peakCost = 0, idleCost = 0, peakTokens = 0;
    let hitCost = 0, missCost = 0, outputCost = 0;
    const sessions = new Set<string>();
    for (const r of rows) {
      inputHit += r.input_hit ?? 0;
      inputMiss += r.input_miss ?? 0;
      output += r.output ?? 0;
      cost += r.cost_est ?? 0;
      sessions.add(r.session_id);
      if (r.peak === 1) { peakCost += r.cost_est ?? 0; peakTokens += (r.input_hit ?? 0) + (r.input_miss ?? 0) + (r.output ?? 0); }
      else idleCost += r.cost_est ?? 0;
      // 按桶费用拆分（#8 费用杠杆）：用单价反算 hit/miss/output 各自费用（估算）
      const hit = r.input_hit ?? 0, miss = r.input_miss ?? 0, out = r.output ?? 0;
      if (hit + miss + out > 0) {
        // 峰值消息按全价（正午 12:00），空闲按半价（凌晨 00:00）——比例估算
        const est = estimateCost({ inputTokens: miss, cacheReadTokens: hit, outputTokens: out }, r.peak === 1 ? 12 * 3600 * 1000 : 0, r.model);
        hitCost += est.hit; missCost += est.miss; outputCost += est.output;
      }
    }
    const inputTotal = inputHit + inputMiss;
    const hitRate = inputTotal > 0 ? Math.round((inputHit / inputTotal) * 1000) / 10 : null;
    return { inputHit, inputMiss, output, total: inputHit + inputMiss + output, cost: Math.round(cost * 1e6) / 1e6, peakCost: Math.round(peakCost * 1e6) / 1e6, idleCost: Math.round(idleCost * 1e6) / 1e6, peakTokens, hitRate, sessionCount: sessions.size, hitCost: round4(hitCost), missCost: round4(missCost), outputCost: round4(outputCost) };
  };

  // ---------- 聚合助手 ----------
  const round4 = (n: number): number => Math.round(n * 1e6) / 1e6;
  const round1 = (n: number): number => Math.round(n * 10) / 10;

  const typeLabel = (id: TaskTypeId): string => taskTypeLabel(id);

  /**
   * 重复/续跑会话识别（#2 去重）：DSH goal 续跑创建的新会话会继承旧会话事件流
   * （同 seq/usage/时间戳完全一致，旧会话是新的前缀子集），导致同一批 token 被记到多个会话。
   * 逻辑：按 lastActivity 降序处理，若某会话的 assistant 消息指纹集是已保留会话的子集，
   * 则它是旧副本，排除。所有统计基于排除后的数据，避免双重计费。
   */
  const duplicateExcluded = (): Set<string> => {
    const sessions = store.querySessions();
    const fps = new Map<string, Set<string>>();
    for (const s of sessions) {
      const msgs = store.queryMessages(s.id, 100000);
      const fp = new Set<string>();
      for (const m of msgs) {
        if (m.role !== 'assistant') continue;
        fp.add(m.seq + ':' + (m.input_hit ?? 0) + ':' + (m.input_miss ?? 0) + ':' + (m.output ?? 0) + ':' + m.ts);
      }
      fps.set(s.id, fp);
    }
    const ordered = [...sessions].sort((a, b) => b.last_activity - a.last_activity);
    const excluded = new Set<string>();
    const kept: string[] = [];
    for (const s of ordered) {
      const fp = fps.get(s.id) ?? new Set<string>();
      const isSubset = fp.size > 0 && kept.some((k) => {
        const kf = fps.get(k) ?? new Set<string>();
        return kf.size >= fp.size && [...fp].every((f) => kf.has(f));
      });
      if (isSubset) excluded.add(s.id);
      else kept.push(s.id);
    }
    return excluded;
  };

  /** 从（已去重的）消息行按模型聚合（替代 daily_agg 双源，消除不一致）。 */
  const modelStatsFromRows = (rows: RangeMessageRow[]) => {
    const byModel = new Map<string, { model: string; tokens: number; cost: number; hit: number; miss: number; output: number; msgCount: number }>();
    for (const r of rows) {
      const key = r.model ?? '(未知)';
      const e = byModel.get(key) ?? { model: key, tokens: 0, cost: 0, hit: 0, miss: 0, output: 0, msgCount: 0 };
      e.tokens += (r.input_hit ?? 0) + (r.input_miss ?? 0) + (r.output ?? 0);
      e.cost += r.cost_est ?? 0;
      e.hit += r.input_hit ?? 0;
      e.miss += r.input_miss ?? 0;
      e.output += r.output ?? 0;
      e.msgCount += 1;
      byModel.set(key, e);
    }
    const totalCost = [...byModel.values()].reduce((a, m) => a + m.cost, 0);
    const items = [...byModel.values()].map((m) => ({
      model: m.model,
      short: shortModel(m.model),
      tokens: m.tokens,
      cost: round4(m.cost),
      share: totalCost > 0 ? round1((m.cost / totalCost) * 100) : 0,
      hitRate: cacheHitRatePct(m.hit, m.miss),
      outputShare: m.tokens > 0 ? round1((m.output / m.tokens) * 100) : null,
      unitCost: unitOutputCost(m.cost, m.output),
      msgCount: m.msgCount,
    })).sort((a, b) => b.cost - a.cost);
    return { items, totalCost: round4(totalCost) };
  };

  /**
   * 趋势：从（已去重的）消息行聚合。
   * day = 今日 0–23 时；week = 近 7 天；month = 近 30 天。每桶按模型拆段（peak/idle 分列）。
   */
  const trendFromRows = (rows: RangeMessageRow[], scope: string) => {
    const now = new Date();
    const toSegments = (modelMap: Map<string, { tokens: number; cost: number; peakTokens: number; idleTokens: number; peakCost: number; idleCost: number }>) =>
      [...modelMap.entries()].map(([model, seg]) => ({
        model, short: shortModel(model), tokens: seg.tokens, cost: round4(seg.cost),
        peakTokens: seg.peakTokens, idleTokens: seg.idleTokens, peakCost: round4(seg.peakCost), idleCost: round4(seg.idleCost),
      })).sort((a, b) => b.tokens - a.tokens);
    if (scope === 'day') {
      const byHour = new Map<number, Map<string, { tokens: number; cost: number; peakTokens: number; idleTokens: number; peakCost: number; idleCost: number }>>();
      for (const r of rows) {
        const h = new Date(r.ts).getHours();
        const models = byHour.get(h) ?? new Map();
        const key = r.model ?? '(未知)';
        const seg = models.get(key) ?? { tokens: 0, cost: 0, peakTokens: 0, idleTokens: 0, peakCost: 0, idleCost: 0 };
        const tokens = (r.input_hit ?? 0) + (r.input_miss ?? 0) + (r.output ?? 0);
        seg.tokens += tokens; seg.cost += r.cost_est ?? 0;
        if (r.peak === 1) { seg.peakTokens += tokens; seg.peakCost += r.cost_est ?? 0; }
        else { seg.idleTokens += tokens; seg.idleCost += r.cost_est ?? 0; }
        models.set(key, seg); byHour.set(h, models);
      }
      const items: Array<{ label: string; hour: number; peak: boolean; segments: unknown[] }> = [];
      for (let h = 0; h < 24; h += 1) {
        const peak = (h >= 9 && h < 12) || (h >= 14 && h < 18);
        items.push({ label: String(h).padStart(2, '0') + ':00', hour: h, peak, segments: toSegments(byHour.get(h) ?? new Map()) });
      }
      return { scope, items };
    }
    const days = scope === 'month' ? 30 : 7;
    const start = new Date(now); start.setDate(start.getDate() - (days - 1)); start.setHours(0, 0, 0, 0);
    const byDay = new Map<string, Map<string, { tokens: number; cost: number; peakTokens: number; idleTokens: number; peakCost: number; idleCost: number }>>();
    for (const r of rows) {
      const keyDay = dayOf(r.ts);
      const models = byDay.get(keyDay) ?? new Map();
      const key = r.model ?? '(未知)';
      const seg = models.get(key) ?? { tokens: 0, cost: 0, peakTokens: 0, idleTokens: 0, peakCost: 0, idleCost: 0 };
      const tokens = (r.input_hit ?? 0) + (r.input_miss ?? 0) + (r.output ?? 0);
      seg.tokens += tokens; seg.cost += r.cost_est ?? 0;
      if (r.peak === 1) { seg.peakTokens += tokens; seg.peakCost += r.cost_est ?? 0; }
      else { seg.idleTokens += tokens; seg.idleCost += r.cost_est ?? 0; }
      models.set(key, seg); byDay.set(keyDay, models);
    }
    const items: Array<{ label: string; day: string; segments: unknown[] }> = [];
    for (let i = 0; i < days; i += 1) {
      const d = new Date(start); d.setDate(d.getDate() + i);
      const key = dayOf(d.getTime());
      items.push({ label: key.slice(5), day: key, segments: toSegments(byDay.get(key) ?? new Map()) });
    }
    return { scope, days, items };
  };

  const isPeakNow = (): boolean => {
    const h = new Date().getHours();
    return (h >= 9 && h < 12) || (h >= 14 && h < 18);
  };

  /** 会话列表（含健康度、模型拆解、任务类型）。 */
  const buildSessionItems = () => {
    const projections = opts.getProjections?.() ?? null;
    const excluded = duplicateExcluded();
    const archivedIds = opts.getArchivedSessionIds?.() ?? new Set<string>();
    const sessions = store.querySessions().filter((s) => !excluded.has(s.id));
    const statsBySession = new Map(store.querySessionStats().map((s) => [s.session_id, s]));
    const goalsById = new Map(store.queryGoals().map((g) => [g.id, g]));
    const subagentSessions = new Set(store.querySubagents().map((s) => s.session_id));
    const modelBySession = new Map<string, SessionModelStatRow[]>();
    for (const m of store.querySessionModelStats()) {
      const arr = modelBySession.get(m.session_id) ?? [];
      arr.push(m); modelBySession.set(m.session_id, arr);
    }
    const compactionBySession = new Map(store.queryCompactionCounts().map((c) => [c.session_id, c.n]));
    const items = sessions.map((s) => {
      const st = statsBySession.get(s.id);
      const hit = st?.input_hit ?? 0;
      const miss = st?.input_miss ?? 0;
      const output = st?.output ?? 0;
      const tokens = hit + miss + output;
      const cost = st?.cost ?? 0;
      const hitRate = cacheHitRatePct(hit, miss);
      const goal = s.goal_id ? goalsById.get(s.goal_id) : undefined;
      const goalType = goal ? classifyTaskType(goal.objective, s.title).id : null;
      // 上下文占用：优先官方 contextPressure（projectedTokens 对压缩即时响应，
      // 容量优先官方 contextWindow），缺失时回退到自有算法（末轮 prompt / 存储的 context_window）。
      const pressure = projections !== null ? projections.contextPressure(s.id) : null;
      const pressureUsed = pressure !== null ? (pressure.projectedTokens ?? pressure.pressureTokens) : null;
      let contextUsedPct: number | null = null;
      if (pressureUsed != null) {
        contextUsedPct = occupancyPct(pressureUsed, pressure?.contextWindow ?? s.context_window);
      }
      if (contextUsedPct === null) {
        const lastMsg = store.queryLastAssistantMessage(s.id);
        const promptTokens = lastMsg ? (lastMsg.input_hit ?? 0) + (lastMsg.input_miss ?? 0) : null;
        contextUsedPct = occupancyPct(promptTokens, s.context_window);
      }
      // 会话统计：官方 sessionStats（与内置统计条同源），缺失时回退到自有轮次计数。
      const stats = projections !== null ? projections.sessionStats(s.id) : null;
      const turns = stats !== null ? stats.turns : s.turn_count + 1;
      const compactionCount = compactionBySession.get(s.id) ?? 0;
      const prefixStable = compactionCount <= 1;
      const turnEff = hit + miss > 0 ? output / (hit + miss) : null;
      const attention = attentionScore({ hitRate, contextUsedPct, turnEfficiency: turnEff, prefixStable });
      const health = healthBadge(attention, contextUsedPct, turns, hitRate);
      const modelRows = modelBySession.get(s.id) ?? [];
      const models = modelRows.map((m) => ({
        model: m.model ?? '(未知)', short: shortModel(m.model),
        tokens: m.input_hit + m.input_miss + m.output,
        cost: round4(m.cost),
        hitRate: cacheHitRatePct(m.input_hit, m.input_miss),
        unitCost: unitOutputCost(m.cost, m.output),
        msgCount: m.msg_count,
      })).sort((a, b) => b.cost - a.cost);
      const interrupted = modelRows.reduce((a, m) => a + m.interrupted, 0);
      const reasoning = modelRows.reduce((a, m) => a + m.reasoning, 0);
      return {
        id: s.id, title: s.title ?? '(未命名会话)', provider: s.provider, model: s.model,
        contextWindow: s.context_window, turnCount: turns,
        tokens, inputHit: hit, inputMiss: miss, output,
        cost: round4(cost), hitRate, lastActivity: s.last_activity, createdAt: s.created_at,
        goalId: s.goal_id, goalPhase: goal?.phase ?? null, goalObjective: goal?.objective ?? null,
        goalType, typeLabel: goalType != null ? typeLabel(goalType) : null,
        isSubagent: subagentSessions.has(s.id), parentSession: s.parent_session,
        archived: archivedIds.has(s.id),
        compactionCount, attention, health, contextUsedPct,
        // 官方 sessionStats（无投影时为 null）：步数 / LLM / 工具 / 首 token / 解码
        steps: stats?.steps ?? null,
        llmMs: stats?.llmMs ?? null,
        toolMs: stats?.toolMs ?? null,
        ttftMs: stats?.ttftMs ?? null,
        ttftSteps: stats?.ttftSteps ?? null,
        decodeMs: stats?.decodeMs ?? null,
        decodeTokens: stats?.decodeTokens ?? null,
        interruptRate: interruptRatePct(interrupted, st?.msg_count ?? 0),
        reasoningShare: reasoningSharePct(reasoning, output),
        outputShare: tokens > 0 ? round1((output / tokens) * 100) : null,
        unitCost: unitOutputCost(cost, output),
        models,
      };
    });
    items.sort((a, b) => b.lastActivity - a.lastActivity);
    return items;
  };

  /** 任务台账（含类型识别、模型拆解）。 */
  const buildTaskItems = () => {
    const goals = latestGoals(store.queryGoals());
    const excluded = duplicateExcluded();
    const sessions = store.querySessions().filter((s) => !excluded.has(s.id));
    const statsBySession = new Map(store.querySessionStats().map((s) => [s.session_id, s]));
    const modelStats = store.querySessionModelStats();
    const subagents = store.querySubagents();
    const items = goals.map((g) => {
      const related = sessions.filter((s) => s.goal_id === g.id);
      const subOf = (pid: string): string[] => subagents.filter((sb) => sb.parent_session === pid).map((sb) => sb.session_id);
      const modelAgg = new Map<string, { tokens: number; cost: number; hit: number; miss: number; output: number }>();
      let tokens = 0, cost = 0, msgCount = 0;
      const addSession = (sid: string): void => {
        const st = statsBySession.get(sid);
        if (st !== undefined) { tokens += st.input_hit + st.input_miss + st.output; cost += st.cost; msgCount += st.msg_count; }
        for (const m of modelStats) {
          if (m.session_id !== sid) continue;
          const key = m.model ?? '(未知)';
          const e = modelAgg.get(key) ?? { tokens: 0, cost: 0, hit: 0, miss: 0, output: 0 };
          e.tokens += m.input_hit + m.input_miss + m.output; e.cost += m.cost;
          e.hit += m.input_hit; e.miss += m.input_miss; e.output += m.output;
          modelAgg.set(key, e);
        }
      };
      for (const s of related) { addSession(s.id); for (const subId of subOf(s.id)) addSession(subId); }
      const type = classifyTaskType(g.objective, related.map((r) => r.title).join(' '));
      const models = [...modelAgg.entries()].map(([model, e]) => ({
        model, short: shortModel(model), tokens: e.tokens, cost: round4(e.cost),
        hitRate: cacheHitRatePct(e.hit, e.miss), unitCost: unitOutputCost(e.cost, e.output),
      })).sort((a, b) => b.cost - a.cost);
      // 子代理归并明细：父任务下每个子代理会话的消耗（#9）
      const subDetails: Array<{ sessionId: string; label: string | null; mode: string | null; tokens: number; cost: number; model: string | null }> = [];
      for (const s of related) {
        for (const sb of subagents) {
          if (sb.parent_session !== s.id) continue;
          const sst = statsBySession.get(sb.session_id);
          const subRow = sessions.find((x) => x.id === sb.session_id);
          subDetails.push({
            sessionId: sb.session_id,
            label: sb.label,
            mode: sb.mode,
            tokens: sst !== undefined ? sst.input_hit + sst.input_miss + sst.output : 0,
            cost: sst !== undefined ? round4(sst.cost) : 0,
            model: subRow?.model ?? null,
          });
        }
      }
      return {
        id: g.id, revision: g.revision, objective: g.objective, phase: g.phase,
        type: type.id, typeLabel: type.label, typeHint: type.hint,
        roundsStarted: g.rounds_started, maxGoalRounds: g.max_goal_rounds,
        blockedReason: g.blocked_reason, createdAt: g.created_at, updatedAt: g.updated_at,
        sessionCount: related.length, tokens, cost: round4(cost), msgCount, models,
        subagents: subDetails,
      };
    });
    items.sort((a, b) => b.updatedAt - a.updatedAt);
    return items;
  };


  const handlers: Record<string, Handler> = {
    '/settings': (req, res) => {
      const all = store.getAllSettings();
      const parse = (key: string, fallback: unknown) => { try { return JSON.parse(all[key] ?? 'null') ?? fallback; } catch { return fallback; } };
      const settings = {
        prices: parse('prices', DEFAULT_PRICES),
        peakPeriods: parse('peakPeriods', PEAK_PERIODS),
        advice: {
          contextThreshold: parse('advice.contextThreshold', 70),
          turnThreshold: parse('advice.turnThreshold', 40),
          hitRateThreshold: parse('advice.hitRateThreshold', 40),
        },
        adopted: parse('advice.adopted', []),
      };
      if (req.method === 'PUT') {
        let body = '';
        req.on('data', (c: Buffer) => { body += c; });
        req.on('end', () => {
          try {
            const payload = JSON.parse(body || '{}');
            if (payload.prices != null) store.setSetting('prices', JSON.stringify(payload.prices));
            if (payload.peakPeriods != null) store.setSetting('peakPeriods', JSON.stringify(payload.peakPeriods));
            if (payload.advice != null) {
              store.setSetting('advice.contextThreshold', JSON.stringify(payload.advice.contextThreshold ?? 70));
              store.setSetting('advice.turnThreshold', JSON.stringify(payload.advice.turnThreshold ?? 40));
              store.setSetting('advice.hitRateThreshold', JSON.stringify(payload.advice.hitRateThreshold ?? 40));
            }
            // 立即生效：后续记录按新单价/峰谷计费
            if (payload.prices != null || payload.peakPeriods != null) {
              const all2 = store.getAllSettings();
              const parse2 = (key: string, fallback: unknown) => { try { return JSON.parse(all2[key] ?? 'null') ?? fallback; } catch { return fallback; } };
              store.setPricing(
                payload.prices != null ? payload.prices : (parse2('prices', undefined) as Record<string, { hitIdle: number; missIdle: number; outputIdle: number }> | undefined),
                payload.peakPeriods != null ? payload.peakPeriods : (parse2('peakPeriods', undefined) as ReadonlyArray<{ start: number; end: number }> | undefined),
              );
            }
            sendJson(res, 200, { ok: true });
          } catch (err) {
            log('settings PUT failed: ' + String(err));
            sendJson(res, 400, { error: '设置格式错误' });
          }
        });
        return;
      }
      sendJson(res, 200, settings);
    },
    '/health': (_req, res) => {
      const sessions = store.querySessions();
      const stats = store.querySessionStats();
      sendJson(res, 200, {
        ok: true,
        dbPath: store.dbPath,
        sessions: sessions.length,
        messages: stats.reduce((a, s) => a + s.msg_count, 0),
        goals: store.queryGoals().length,
        subagents: store.querySubagents().length,
        compactions: store.queryCompactions().length,
        now: Date.now(),
      });
    },
    '/summary': (_req, res, _p, query) => {
      const scope = query.get('scope') ?? 'day';
      const { start, end } = scopeRange(scope);
      const excluded = duplicateExcluded();
      const rows = store.queryMessagesRange(start, end).filter((r) => !excluded.has(r.session_id));
      const summary = summarizeMessages(rows);
      const goals = latestGoals(store.queryGoals());
      const activeGoals = goals.filter((g) => g.phase === 'active' || g.phase === 'paused');
      const outputShare = summary.total > 0 ? round1((summary.output / summary.total) * 100) : null;
      const models = modelStatsFromRows(rows).items;
      const sessItems = buildSessionItems();
      const avgAttention = sessItems.length > 0 ? Math.round(sessItems.reduce((a, s) => a + s.attention, 0) / sessItems.length) : null;
      const attentionCount = sessItems.filter((s) => s.health === 'danger').length;
      sendJson(res, 200, {
        scope, ...summary, outputShare, models, avgAttention, attentionCount,
        goalCount: goals.length, activeGoalCount: activeGoals.length,
      });
    },
    '/models': (_req, res, _p, query) => {
      const scope = query.get('scope') ?? 'day';
      const { start, end } = scopeRange(scope);
      const excluded = duplicateExcluded();
      const rows = store.queryMessagesRange(start, end).filter((r) => !excluded.has(r.session_id));
      sendJson(res, 200, { scope, ...modelStatsFromRows(rows) });
    },
    '/trend': (_req, res, _p, query) => {
      const scope = query.get('scope') ?? 'day';
      const excluded = duplicateExcluded();
      const now = Date.now();
      if (scope === 'day') {
        const d = new Date(now); d.setHours(0, 0, 0, 0);
        const rows = store.queryMessagesRange(d.getTime(), now).filter((r) => !excluded.has(r.session_id));
        return sendJson(res, 200, trendFromRows(rows, scope));
      }
      const days = scope === 'month' ? 30 : 7;
      const start = new Date(now); start.setDate(start.getDate() - (days - 1)); start.setHours(0, 0, 0, 0);
      const rows = store.queryMessagesRange(start.getTime(), now).filter((r) => !excluded.has(r.session_id));
      return sendJson(res, 200, trendFromRows(rows, scope));
    },
    '/advice': (req, res) => {
      const all = store.getAllSettings();
      const adopted = (() => { try { return JSON.parse(all['advice.adopted'] ?? '[]'); } catch { return []; } })();
      if (req.method === 'POST') {
        let body = '';
        req.on('data', (c: Buffer) => { body += c; });
        req.on('end', () => {
          try {
            const payload = JSON.parse(body || '{}');
            if (payload.adopt === true && typeof payload.id === 'string' && !adopted.includes(payload.id)) {
              adopted.push(payload.id);
              store.setSetting('advice.adopted', JSON.stringify(adopted));
            }
            sendJson(res, 200, { ok: true, adopted });
          } catch (err) {
            log('advice POST failed: ' + String(err));
            sendJson(res, 400, { error: '参数错误' });
          }
        });
        return;
      }
      const scope = 'day';
      const { start, end, startDay } = scopeRange(scope);
      const summary = summarizeMessages(store.queryMessagesRange(start, end));
      const sessions = buildSessionItems();
      const tasks = buildTaskItems();
      const adviceCtx = {
        now: Date.now(),
        summary: {
          peakCost: summary.peakCost, idleCost: summary.idleCost, cost: summary.cost,
          outputShare: summary.total > 0 ? round1((summary.output / summary.total) * 100) : null,
          total: summary.total,
        },
        sessions: sessions.map((s) => ({
          id: s.id, title: s.title, turnCount: s.turnCount, hitRate: s.hitRate,
          contextUsedPct: s.contextUsedPct, health: s.health, attention: s.attention,
          compactionCount: s.compactionCount, outputShare: s.outputShare, cost: s.cost,
          tokens: s.tokens, models: s.models.map((m) => ({ model: m.model, cost: m.cost, tokens: m.tokens })),
          taskType: s.goalType ?? undefined, goalId: s.goalId,
        })),
        tasks: tasks.map((t) => ({
          id: t.id, objective: t.objective, type: t.type, phase: t.phase,
          sessionCount: t.sessionCount, tokens: t.tokens, cost: t.cost,
          createdAt: t.createdAt, updatedAt: t.updatedAt,
          models: t.models.map((m) => ({ model: m.model, cost: m.cost })),
        })),
      };
      const allS = store.getAllSettings();
      const parseS = (key: string, fallback: number): number => { try { return JSON.parse(allS[key] ?? 'null') ?? fallback; } catch { return fallback; } };
      const cards: AdviceCard[] = generateAdvice(adviceCtx, {
        contextThreshold: parseS('advice.contextThreshold', 70),
        turnThreshold: parseS('advice.turnThreshold', 40),
        hitRateThreshold: parseS('advice.hitRateThreshold', 40),
      });
      sendJson(res, 200, { now: Date.now(), peak: isPeakNow(), idleHint: idleHint(), cards, adopted });
    },
    '/sessions': (_req, res) => {
      const excluded = duplicateExcluded();
      sendJson(res, 200, { items: buildSessionItems().filter((s) => !excluded.has(s.id)) });
    },
    '/sessions/': (req, res, pathname) => {
      const m = /^\/sessions\/([^/]+)$/.exec(pathname.replace(/^\/token-attention\/api/, ''));
      if (m === null) return sendJson(res, 404, { error: '未找到会话' });
      const id = decodeURIComponent(m[1]!);
      const msgs = store.queryMessages(id, 500);
      sendJson(res, 200, {
        sessionId: id,
        messages: msgs.map((m2) => ({
          seq: m2.seq, turn: m2.turn, step: m2.step, role: m2.role,
          provider: m2.provider, model: m2.model, peak: m2.peak,
          inputHit: m2.input_hit, inputMiss: m2.input_miss, output: m2.output,
          reasoning: m2.reasoning, cost: m2.cost_est, interrupted: m2.interrupted, ts: m2.ts,
        })),
      });
    },
    '/tasks': (_req, res) => {
      const excluded = duplicateExcluded();
      sendJson(res, 200, { items: buildTaskItems().filter((t) => !excluded.has(t.id)) });
    },
  };

  return async (req, res) => {
    try {
      // webServer 的 handler 只传 (req, res)；pathname/query 从 req.url 自行解析
      // （与 dsh-synapse 的 api handler 同款）。
      const url = new URL(req.url ?? '/', 'http://dsh.local');
      const pathname = url.pathname;
      const query = url.searchParams;
      // /token-attention 前缀不在 DSH /api 浏览器信任围栏内，自检 Host 防 DNS-rebinding
      // （与 dsh-synapse 的 /synapse/api 同款防护）。
      const hostname = (typeof req.headers?.host === 'string' ? req.headers.host : '').replace(/:\d+$/, '').toLowerCase();
      if (hostname !== 'localhost' && hostname !== '127.0.0.1') {
        return sendJson(res, 403, { error: '不被信任的 Host' });
      }
      // pathname 形如 /token-attention/api/xxx
      let key = pathname.replace(/^\/token-attention\/api/, '') || '/';
      if (key === '/') key = '/health';
      const sessionDetail = /^\/sessions\/([^/]+)$/.exec(key);
      if (sessionDetail !== null) return handlers['/sessions/']!(req, res, pathname, query);
      const handler = handlers[key];
      if (handler === undefined) return sendJson(res, 404, { error: '接口不存在' });
      return handler(req, res, pathname, query);
    } catch (err) {
      log(`api error: ${String(err)}`);
      sendJson(res, 500, { error: '内部错误' });
    }
  };
}
