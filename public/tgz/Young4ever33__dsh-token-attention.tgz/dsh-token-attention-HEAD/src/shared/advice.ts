/**
 * 建议引擎（FR6）：时间 / 换对话 / hand-off / 上下文 / 费用 / 模型。
 * 纯规则，输入为已聚合的会话/任务/汇总，不读库。
 */
import { isPeak, PEAK_PERIODS } from './pricing.ts';
import type { TaskTypeId } from './task-type.ts';
import type { HealthLevel } from './quality.ts';

export type AdviceKind = 'time' | 'switch' | 'handoff' | 'context' | 'cost' | 'model';
export type AdviceLevel = 'ok' | 'warn' | 'danger' | 'info';

export interface AdviceCard {
  id: string;
  kind: AdviceKind;
  level: AdviceLevel;
  title: string;
  body: string;
}

export interface AdviceSession {
  id: string;
  title: string;
  turnCount: number;
  hitRate: number | null;
  contextUsedPct: number | null;
  health: HealthLevel;
  attention: number;
  compactionCount: number;
  outputShare: number | null;
  cost: number;
  tokens: number;
  models: Array<{ model: string; cost: number; tokens: number }>;
  taskType?: TaskTypeId;
  sessionCountForTask?: number;
  goalId?: string | null;
}

export interface AdviceTask {
  id: string;
  objective: string;
  type: TaskTypeId;
  phase: string;
  sessionCount: number;
  tokens: number;
  cost: number;
  createdAt: number;
  updatedAt: number;
  models: Array<{ model: string; cost: number }>;
}

export interface AdviceSummary {
  peakCost: number;
  idleCost: number;
  cost: number;
  outputShare: number | null;
  total: number;
}

export interface AdviceContext {
  now?: number;
  summary: AdviceSummary;
  sessions: AdviceSession[];
  tasks: AdviceTask[];
}

export interface AdviceOptions {
  /** 上下文占用阈值（%），超过触发换会话建议。默认 70。 */
  contextThreshold?: number;
  /** 轮次阈值，超过触发换会话建议。默认 40。 */
  turnThreshold?: number;
  /** 命中率下限（%），低于触发换会话建议。默认 40。 */
  hitRateThreshold?: number;
}

export function generateAdvice(ctx: AdviceContext, opts: AdviceOptions = {}): AdviceCard[] {
  const now = ctx.now ?? Date.now();
  const peak = isPeak(now);
  const ctxThr = opts.contextThreshold ?? 70;
  const turnThr = opts.turnThreshold ?? 40;
  const hitThr = opts.hitRateThreshold ?? 40;
  const cards: AdviceCard[] = [];
  const activeTasks = ctx.tasks.filter((t) => t.phase === 'active' || t.phase === 'paused');
  const heavyTypes = new Set<TaskTypeId>(['coding', 'batch', 'research']);
  const heavyActive = activeTasks.filter((t) => heavyTypes.has(t.type));

  if (peak && heavyActive.length > 0 && ctx.summary.total > 200000) {
    const save = Math.round(ctx.summary.peakCost * 0.5 * 1000) / 1000;
    const types = unique(heavyActive.map((t) => t.type)).join('/');
    cards.push(card('time-defer', 'time', 'warn',
      '现在高峰，' + types + ' 类任务建议错峰',
      idleHint(now) + '。今日高峰已花 ' + fmtCost(ctx.summary.peakCost) + '；若后续同类消耗改到空闲，按半价粗算可再省约 ' + fmtCost(save) + '（估算）。'));
  } else if (!peak && heavyActive.length > 0) {
    cards.push(card('time-go', 'time', 'ok',
      '当前空闲，适合启动长任务',
      idleHint(now) + '。编码 / 调研 / 批处理放在这个窗口，输入未命中与输出都是半价。'));
  } else if (peak) {
    cards.push(card('time-peak', 'time', 'info',
      '当前高峰时段（全价）',
      idleHint(now) + '。短问答可继续；大输入或长输出任务更适合空闲窗口。'));
  }

  for (const s of ctx.sessions) {
    const shouldSwitch = s.health === 'danger'
      || (s.contextUsedPct != null && s.contextUsedPct > ctxThr)
      || s.turnCount > turnThr
      || (s.hitRate != null && s.hitRate < hitThr);
    if (!shouldSwitch) continue;
    const bits: string[] = [];
    if (s.contextUsedPct != null && s.contextUsedPct > ctxThr) bits.push('上下文占用 ' + s.contextUsedPct + '%');
    if (s.turnCount > turnThr) bits.push(s.turnCount + ' 轮');
    if (s.hitRate != null && s.hitRate < hitThr) bits.push('命中率 ' + s.hitRate + '%');
    bits.push('注意力 ' + s.attention);
    cards.push(card('switch-' + s.id, 'switch', 'danger',
      '会话「' + clip(s.title, 24) + '」建议换新对话',
      bits.join(' · ') + '。开新会话承接；若任务未完成，先写 hand-off。'));
  }

  for (const s of ctx.sessions) {
    if (s.compactionCount <= 0) continue;
    if (s.hitRate != null && s.hitRate >= 70) continue;
    cards.push(card('prefix-' + s.id, 'context', 'warn',
      '「' + clip(s.title, 24) + '」前缀可能被扰动',
      '已压缩 ' + s.compactionCount + ' 次' + (s.hitRate != null ? '，命中率 ' + s.hitRate + '%' : '') + '。少改早期消息、用 @文件 引用，比把材料反复粘进对话更稳。'));
  }

  for (const t of ctx.tasks) {
    const spannedDays = Math.floor((t.updatedAt - t.createdAt) / 86400000);
    if (t.sessionCount < 2 && spannedDays < 1) continue;
    if (t.phase === 'complete') continue;
    cards.push(card('handoff-' + t.id, 'handoff', 'info',
      '任务「' + clip(t.objective, 28) + '」建议写 hand-off',
      '已跨 ' + t.sessionCount + ' 个会话' + (spannedDays >= 1 ? '、跨 ' + (spannedDays + 1) + ' 天' : '') + '。把目标、进度、关键文件和下一步写进 notes/，新会话只引用文件。'));
  }

  if (ctx.summary.outputShare != null && ctx.summary.outputShare > 40) {
    cards.push(card('cost-output', 'cost', 'info',
      '输出占比 ' + ctx.summary.outputShare + '%，对话里别堆全文',
      '建议让结果写入文件，会话只留摘要——输出是单价最高的一桶。'));
  }

  for (const t of ctx.tasks) {
    if (t.models.length < 2) continue;
    const sorted = [...t.models].sort((a, b) => b.cost - a.cost);
    const top = sorted[0]!;
    const rest = sorted.slice(1).reduce((a, m) => a + m.cost, 0);
    if (top.cost < 0.01 || top.cost < rest) continue;
    if (!/pro/i.test(top.model)) continue;
    const share = Math.round((top.cost / Math.max(t.cost, 1e-9)) * 100);
    cards.push(card('model-' + t.id, 'model', 'warn',
      '任务「' + clip(t.objective, 24) + '」费用集中在 ' + shortModel(top.model),
      shortModel(top.model) + ' 约占该任务费用的 ' + share + '%。编码/调研若非必要，flash 通常更便宜；写作类再看单位产出成本。'));
  }

  const seen = new Set<string>();
  const out: AdviceCard[] = [];
  for (const c of cards) {
    if (seen.has(c.id)) continue;
    seen.add(c.id);
    out.push(c);
    if (out.length >= 8) break;
  }
  return out;
}

export function idleHint(now = Date.now()): string {
  const hour = new Date(now).getHours();
  const peak = isPeak(now);
  if (peak) {
    const end = PEAK_PERIODS.find((p) => hour >= p.start && hour < p.end)?.end ?? hour;
    return '高峰至 ' + pad(end) + ':00，之后进入空闲半价';
  }
  const next = PEAK_PERIODS.find((p) => hour < p.start);
  if (next) return '空闲半价中，下一高峰 ' + pad(next.start) + ':00';
  return '空闲半价中，直至次日 09:00 高峰';
}

function card(id: string, kind: AdviceKind, level: AdviceLevel, title: string, body: string): AdviceCard {
  return { id, kind, level, title, body };
}

function clip(s: string, n: number): string {
  const t = (s || '').replace(/\s+/g, ' ').trim();
  return t.length <= n ? t : t.slice(0, n - 1) + '…';
}

function unique(xs: string[]): string[] {
  return [...new Set(xs)];
}

function fmtCost(n: number): string {
  return '¥' + n.toFixed(3);
}

function pad(n: number): string {
  return String(n).padStart(2, '0');
}

export function shortModel(model: string | null | undefined): string {
  if (!model) return '未知模型';
  if (/v4-flash/i.test(model)) return 'flash';
  if (/v4-pro/i.test(model)) return 'pro';
  const parts = model.split(/[/:]/);
  return parts[parts.length - 1] || model;
}
