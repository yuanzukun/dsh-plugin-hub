/**
 * dsh-token-attention · shared/types
 *
 * 采集层共享类型：DSH 暴露的事件/usage 形状（对齐 docs/dsh-interface-survey.md）
 * 与插件自身的记录形状。仅用可擦除 TS 语法（Node 24 可直接 strip 运行）。
 */

/** DSH 规范化的 provider usage（disjoint 桶；与 DeepSeek 原始字段的映射见勘察报告 §3）。 */
export interface TokenUsage {
  inputTokens: number;
  outputTokens: number;
  cacheReadTokens?: number;
  cacheWriteTokens?: number;
  reasoningTokens?: number;
}

/** 会话事件最小形状（DSH session/event 回调的 event 参数子集）。 */
export interface SessionEvent {
  type: string;
  seq: number;
  time: number;
  data: Record<string, any>;
  surfaceOp?: { start: number; end: number };
  sourceEventSeqs?: number[];
}

/** 会话最小形状（collector 需要读的部分）。 */
export interface SessionLike {
  id: string;
  header: SessionHeaderLike;
  events: SessionEvent[];
}

export interface SessionHeaderLike {
  version?: number;
  id?: string;
  createdAt?: number;
  cwd?: string;
  parentSession?: string;
  seedLength?: number;
  origin?: 'subagent';
  delegationDepth?: number;
  agentPreset?: string;
}

/* ------------------------------------------------------------------ */
/* 插件记录形状（落 SQLite 前归一）                                     */
/* ------------------------------------------------------------------ */

export interface SessionRecord {
  id: string;
  title: string | null;
  provider: string | null;
  model: string | null;
  reasoning_effort: string | null;
  context_window: number | null;
  goal_id: string | null;
  origin: 'subagent' | null;
  parent_session: string | null;
  delegation_depth: number | null;
  agent_preset: string | null;
  created_at: number | null;
  updated_at: number;
  last_seq: number;
  turn_count: number;
  last_activity: number;
}

export interface MessageRecord {
  session_id: string;
  seq: number;
  turn: number;
  step: number;
  role: 'user' | 'assistant' | 'tool';
  provider: string | null;
  model: string | null;
  peak: 0 | 1;
  input_hit: number | null;
  input_miss: number | null;
  output: number | null;
  reasoning: number | null;
  cost_est: number | null;
  interrupted: 0 | 1;
  ts: number;
}

export type GoalPhase = 'active' | 'paused' | 'blocked' | 'complete';
export type GoalOperation = 'create' | 'edit' | 'pause' | 'resume' | 'complete' | 'blocked' | 'clear';

export interface GoalSnapshot {
  id: string;
  revision: number;
  objective: string;
  phase: GoalPhase;
  blockedReason?: { code: string; message: string };
  maxGoalRounds: number;
}

/** goal/change 事件 data（GoalChangeMeta，见勘察报告 §4）。 */
export interface GoalChangeMeta {
  kind: 'goal/change';
  version: 1;
  operation: GoalOperation;
  goal?: GoalSnapshot;
  roundsStarted?: number;
  createdAt?: number;
  updatedAt?: number;
  cleared?: { id: string; revision: number };
  clearedAt?: number;
}

export interface GoalRecord {
  id: string;
  revision: number;
  objective: string;
  phase: GoalPhase;
  max_goal_rounds: number;
  rounds_started: number;
  blocked_reason: string | null;
  created_at: number;
  updated_at: number;
}

/** subagent/descriptor 事件 data（版本 2，见勘察报告 §5）。 */
export interface SubagentDescriptor {
  version: number;
  mode: 'one-shot' | 'continuable';
  provider: string;
  label?: string;
  agentProvider?: string;
  agentModel?: string;
  persona?: string;
  toolFilter?: { allow?: string[]; deny?: string[] };
}

export interface SubagentRecord {
  session_id: string;
  parent_session: string | null;
  provider: string | null;
  mode: string | null;
  label: string | null;
  delegation_depth: number | null;
  first_seen: number;
}

export interface CompactionRecord {
  session_id: string;
  kind: 'summary' | 'prune';
  shadowed_token_count: number;
  shadowed_seq_count: number;
  ts: number;
}

export interface CostBreakdown {
  hit: number;
  miss: number;
  output: number;
  total: number;
}
