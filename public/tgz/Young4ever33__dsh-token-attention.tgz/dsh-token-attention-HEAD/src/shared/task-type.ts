/**
 * 任务类型识别（FR4）：按 goal 目标文本关键词打标签。
 * 规则优先精确、宁可 unknown，不做深度学习。
 */

export type TaskTypeId = 'coding' | 'writing' | 'research' | 'batch' | 'qa' | 'unknown';

export interface TaskType {
  id: TaskTypeId;
  label: string;
  hint: string;
}

const RULES: Array<{ id: TaskTypeId; label: string; hint: string; keys: string[] }> = [
  {
    id: 'coding',
    label: '编码',
    hint: '空闲时段；子代理隔离；里程碑写 hand-off',
    keys: ['编码', '重构', '实现', '插件', '调试', 'bug', '修复', '编译', '测试', '接口', 'api', 'patch', 'cordis', '联调', 'mvp', '面板', '采集', 'collector', 'store', 'tsx', 'typescript', '代码'],
  },
  {
    id: 'research',
    label: '调研',
    hint: '输入大，善用缓存前缀；批量放空闲',
    keys: ['调研', '检索', '搜索', '分析', '勘察', '阅读', '资料', '对比', '综述', 'web_search', '暴露面'],
  },
  {
    id: 'writing',
    label: '写作',
    hint: '可随时；注意输出成本，结果写入文件',
    keys: ['写作', '翻译', '文案', '润色', '文档', '博客', '稿', 'readme', 'prd'],
  },
  {
    id: 'batch',
    label: '批处理',
    hint: '优先空闲时段；建议固定会话连续跑',
    keys: ['批处理', '转换', '导出', '批量', 'headless', '迁移', '同步', '回填'],
  },
  {
    id: 'qa',
    label: '问答',
    hint: '随时，成本通常可忽略',
    keys: ['问答', '咨询', '解释', '什么是', '如何', '为什么'],
  },
];

const FALLBACK: TaskType = {
  id: 'unknown',
  label: '未识别',
  hint: '按目标文本未能归类，建议手动看目标',
};

/** 按目标文本（可拼接会话标题）识别任务类型。 */
export function classifyTaskType(objective: string | null | undefined, extra?: string | null): TaskType {
  const text = ((objective ?? '') + ' ' + (extra ?? '')).toLowerCase();
  if (!text.trim()) return FALLBACK;
  let best: { rule: (typeof RULES)[number]; hits: number } | null = null;
  for (const rule of RULES) {
    let hits = 0;
    for (const k of rule.keys) {
      if (text.includes(k.toLowerCase())) hits += 1;
    }
    if (hits > 0 && (best === null || hits > best.hits)) best = { rule, hits };
  }
  if (best === null) return FALLBACK;
  return { id: best.rule.id, label: best.rule.label, hint: best.rule.hint };
}

export function taskTypeLabel(id: TaskTypeId): string {
  return RULES.find((r) => r.id === id)?.label ?? FALLBACK.label;
}
