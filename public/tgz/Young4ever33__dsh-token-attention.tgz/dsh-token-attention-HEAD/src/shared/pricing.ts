/**
 * dsh-token-attention · shared/pricing
 *
 * 单价表与峰谷时段（PRD §2 / FR7 的默认值；可配置）。
 * 费用估算：cost = hit×ph + miss×pm + out×po，按模型、按时段（高峰/空闲）。
 * 单价单位：元 / 百万 tokens。
 */
import type { TokenUsage, CostBreakdown } from './types.ts';

/** 高峰时段（北京时间，全价）；其余为空闲时段（半价）。 */
export const PEAK_PERIODS: ReadonlyArray<{ start: number; end: number }> = [
  { start: 9, end: 12 },
  { start: 14, end: 18 },
];

export interface ModelPrice {
  /** 输入 · 缓存命中（空闲） */
  hitIdle: number;
  /** 输入 · 缓存未命中（空闲） */
  missIdle: number;
  /** 输出（空闲） */
  outputIdle: number;
}

/** 默认单价表（deepseek-v4-flash，空闲价；高峰翻倍，见 PRD §2）。 */
export const DEFAULT_PRICES: Record<string, ModelPrice> = {
  'deepseek-v4-flash': { hitIdle: 0.05, missIdle: 1.5, outputIdle: 4.5 },
  'deepseek-v4-pro': { hitIdle: 0.1, missIdle: 3.0, outputIdle: 9.0 },
};

/** 未知模型回退价（按 flash 定价，标注为估算）。 */
export const FALLBACK_PRICE: ModelPrice = { hitIdle: 0.05, missIdle: 1.5, outputIdle: 4.5 };

/** 判断某一时刻（毫秒时间戳，本地时区视为北京时间）是否处于高峰时段。可注入自定义时段。 */
export function isPeak(ts: number, periods: ReadonlyArray<{ start: number; end: number }> = PEAK_PERIODS): boolean {
  const d = new Date(ts);
  const hour = d.getHours();
  return periods.some((p) => hour >= p.start && hour < p.end);
}

/** 返回当前时段标签。 */
export function periodOf(ts: number, periods?: ReadonlyArray<{ start: number; end: number }>): 'peak' | 'idle' {
  return isPeak(ts, periods) ? 'peak' : 'idle';
}

/** 取模型单价；未知模型回退 FALLBACK_PRICE。 */
export function priceFor(model: string | null | undefined, prices: Record<string, ModelPrice> = DEFAULT_PRICES): ModelPrice {
  if (model != null && Object.hasOwn(prices, model)) return prices[model]!;
  return FALLBACK_PRICE;
}

/**
 * 由 usage + 时刻 + 模型估算费用（元）。
 * 互斥桶约定（勘察报告 §3）：inputTokens=未命中、cacheReadTokens=命中、outputTokens=输出。
 */
export function estimateCost(
  usage: TokenUsage,
  ts: number,
  model: string | null | undefined,
  prices: Record<string, ModelPrice> = DEFAULT_PRICES,
  periods: ReadonlyArray<{ start: number; end: number }> = PEAK_PERIODS,
): CostBreakdown {
  const p = priceFor(model, prices);
  const peakFactor = isPeak(ts, periods) ? 2 : 1;
  const hit = (usage.cacheReadTokens ?? 0) * p.hitIdle * peakFactor;
  const miss = usage.inputTokens * p.missIdle * peakFactor;
  const output = usage.outputTokens * p.outputIdle * peakFactor;
  return {
    hit: hit / 1e6,
    miss: miss / 1e6,
    output: output / 1e6,
    total: (hit + miss + output) / 1e6,
  };
}

/** usage 总 token 数（互斥桶相加）。 */
export function usageTotal(usage: TokenUsage): number {
  return usage.inputTokens + (usage.cacheReadTokens ?? 0) + (usage.cacheWriteTokens ?? 0) + usage.outputTokens;
}

/** 缓存命中率（命中 / 输入合计；无输入返回 null 表示未知）。 */
export function cacheHitRate(usage: TokenUsage): number | null {
  const total = usage.inputTokens + (usage.cacheReadTokens ?? 0);
  if (total <= 0) return null;
  return (usage.cacheReadTokens ?? 0) / total;
}
