/**
 * 质量代理（可计算、标明估算）：注意力分 / 单位产出成本 / 中断率 / 健康徽章。
 * 不是主观「写得好不好」，只度量运行质量。
 */

export type HealthLevel = 'ok' | 'warn' | 'danger';

export interface AttentionInput {
  /** 缓存命中率 0–100；未知则按 50 中性分。 */
  hitRate: number | null;
  /** 上下文占用 0–100（末轮 prompt / context_window）；未知按 50。 */
  contextUsedPct: number | null;
  /** 输出 / 输入合计；未知按中性。 */
  turnEfficiency: number | null;
  /** 前缀是否稳定（无 compaction 或 compaction 很少）。 */
  prefixStable: boolean;
}

/** 注意力评分 0–100：命中率 40% + 上下文余量 30% + 轮次效率 20% + 前缀稳定 10%。 */
export function attentionScore(input: AttentionInput): number {
  const hit = input.hitRate == null ? 50 : clamp(input.hitRate, 0, 100);
  const remain = input.contextUsedPct == null ? 50 : clamp(100 - input.contextUsedPct, 0, 100);
  const turnScore = efficiencyScore(input.turnEfficiency);
  const prefix = input.prefixStable ? 100 : 30;
  return Math.round(hit * 0.4 + remain * 0.3 + turnScore * 0.2 + prefix * 0.1);
}

/** 输出/输入比映射到 0–100：过低和过高都扣分，甜区约 0.25–0.6。 */
function efficiencyScore(ratio: number | null): number {
  if (ratio == null || !Number.isFinite(ratio)) return 50;
  const r = Math.max(0, ratio);
  if (r <= 0.25) return (r / 0.25) * 100;
  if (r <= 0.6) return 100;
  return clamp(100 - ((r - 0.6) / 1.4) * 100, 0, 100);
}

export function healthBadge(
  score: number,
  contextUsedPct: number | null,
  turns: number,
  hitRate: number | null,
): HealthLevel {
  if ((contextUsedPct != null && contextUsedPct > 70) || turns > 40 || (hitRate != null && hitRate < 40) || score < 50) {
    return 'danger';
  }
  if ((contextUsedPct != null && contextUsedPct > 50) || turns > 20 || (hitRate != null && hitRate < 60) || score < 70) {
    return 'warn';
  }
  return 'ok';
}

export function healthLabel(level: HealthLevel): string {
  if (level === 'ok') return '健康';
  if (level === 'warn') return '注意';
  return '建议换会话';
}

/** 命中率 0–100，一位小数；无输入返回 null。 */
export function cacheHitRatePct(hit: number, miss: number): number | null {
  const total = hit + miss;
  if (total <= 0) return null;
  return Math.round((hit / total) * 1000) / 10;
}

/** 单位产出成本：元 / 百万输出 tokens；无输出返回 null。 */
export function unitOutputCost(cost: number, outputTokens: number): number | null {
  if (outputTokens <= 0) return null;
  return Math.round((cost / (outputTokens / 1e6)) * 1000) / 1000;
}

/** 中断率 0–100。 */
export function interruptRatePct(interrupted: number, assistantCount: number): number | null {
  if (assistantCount <= 0) return null;
  return Math.round((interrupted / assistantCount) * 1000) / 10;
}

/** 思考占比：reasoning / (reasoning+output)，0–100。 */
export function reasoningSharePct(reasoning: number, output: number): number | null {
  const t = reasoning + output;
  if (t <= 0) return null;
  return Math.round((reasoning / t) * 1000) / 10;
}

export function occupancyPct(promptTokens: number | null, contextWindow: number | null): number | null {
  if (promptTokens == null || promptTokens <= 0) return null;
  const cap = contextWindow && contextWindow > 0 ? contextWindow : 1_000_000;
  return Math.round((promptTokens / cap) * 1000) / 10;
}

function clamp(n: number, lo: number, hi: number): number {
  return Math.min(hi, Math.max(lo, n));
}
