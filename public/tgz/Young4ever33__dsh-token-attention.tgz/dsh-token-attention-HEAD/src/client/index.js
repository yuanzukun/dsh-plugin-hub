/**
 * dsh-token-attention · client 半区（浏览器）— Token Check / 词元管理
 *
 * 挂载点：设置侧边栏 settings.section（与 模型/插件 同级菜单项）。
 * 四视图：总览 / 会话 / 任务 / 费用；数据来自 node 半区 API。
 * 特性：#3 会话消息下钻（点击卡展开明细）· #8 台账导出（Markdown/CSV）· #9 子代理归并明细。
 * 零构建：手写 window.__ModuleLoader__.load 模块格式，React 由 client runner 注入。
 */
window.__ModuleLoader__.load({
  id: 'dsh-token-attention',
  factory: (require) => {
    const module = { exports: {} };
    const React = require('react');
    const { useState, useEffect, useCallback } = React;
    const h = React.createElement;

    const css = [
      '.dta-panel{display:flex;flex-direction:column;gap:14px;max-width:960px;color:var(--dsw-alias-label-primary)}',
      '.dta-toolbar{display:flex;align-items:center;gap:10px;flex-wrap:wrap}',
      '.dta-tabs{display:flex;gap:4px;border:1px solid var(--dsw-alias-border-l2);border-radius:8px;padding:3px;background:var(--dsw-alias-bg-layer-1)}',
      '.dta-tabs button{border:0;background:transparent;color:var(--dsw-alias-label-tertiary);font:600 12px Inter,system-ui,sans-serif;cursor:pointer;padding:4px 12px;border-radius:6px}',
      '.dta-tabs button.on{background:var(--dsw-alias-state-business-primary);color:#fff}',
      '.dta-refresh{border:1px solid var(--dsw-alias-border-l2);background:var(--dsw-alias-bg-layer-1);color:var(--dsw-alias-label-primary);font:inherit;cursor:pointer;border-radius:8px;padding:5px 12px;font-size:12px}',
      '.dta-refresh:hover{border-color:var(--dsw-alias-border-l1)}',
      '.dta-link{background:transparent;border:1px solid var(--dsw-alias-border-l2);color:var(--dsw-alias-label-secondary);cursor:pointer;border-radius:6px;padding:2px 10px;font-size:11.5px}',
      '.dta-link:hover{border-color:var(--dsw-alias-border-l1);color:var(--dsw-alias-label-primary)}',
      '.dta-error{color:var(--dsw-alias-state-error-primary);font-size:13px}',
      '.dta-kpis{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:10px}',
      '.dta-kpi{border:1px solid var(--dsw-alias-border-l2);background:var(--dsw-alias-bg-layer-3);border-radius:10px;padding:10px 12px;min-width:0}',
      '.dta-kpi .k{font-size:11px;color:var(--dsw-alias-label-tertiary)}',
      '.dta-kpi .v{font-size:20px;font-weight:700;margin-top:2px;font-variant-numeric:tabular-nums}',
      '.dta-kpi .d{font-size:11px;color:var(--dsw-alias-label-tertiary);margin-top:2px}',
      '.dta-section{min-width:0;border:1px solid var(--dsw-alias-border-l2);background:var(--dsw-alias-bg-layer-2);border-radius:10px;padding:12px 14px}',
      '.dta-section h4{margin:0 0 10px;font-size:13px;font-weight:600}',
      '.dta-legend{display:flex;gap:14px;font-size:11px;color:var(--dsw-alias-label-tertiary);flex-wrap:wrap}',
      '.dta-legend i{display:inline-block;width:10px;height:10px;border-radius:2px;margin-right:4px;vertical-align:-1px}',
      '.dta-bars{display:flex;align-items:flex-end;gap:3px;height:130px;padding:8px 0 16px}',
      '.dta-bars .col{flex:1;display:flex;flex-direction:column;justify-content:flex-end;height:100%;min-width:0;position:relative}',
      '.dta-bars .col .lbl{position:absolute;bottom:-16px;left:0;right:0;text-align:center;font-size:9.5px;color:var(--dsw-alias-label-tertiary);white-space:nowrap;overflow:hidden}',
      '.dta-seg{width:100%;border-radius:2px 2px 0 0}',
      '.dta-seg.idle{opacity:.45}',
      '.dta-modelbar{display:flex;height:8px;border-radius:4px;overflow:hidden;background:var(--dsw-alias-bg-layer-1)}',
      '.dta-modelbar i{display:block;height:100%}',
      '.dta-advs{display:flex;flex-direction:column;gap:8px}',
      '.dta-adv{border:1px solid var(--dsw-alias-border-l2);border-left:3px solid #8b93a7;background:var(--dsw-alias-bg-layer-3);border-radius:8px;padding:9px 12px}',
      '.dta-adv .t{font-size:12.5px;font-weight:600;display:flex;align-items:center;gap:6px}',
      '.dta-adv .b{font-size:12px;color:var(--dsw-alias-label-secondary);margin-top:3px;line-height:1.5}',
      '.dta-adv.ok{border-left-color:#34d399}',
      '.dta-adv.warn{border-left-color:#fbbf24}',
      '.dta-adv.danger{border-left-color:#f87171}',
      '.dta-adv.info{border-left-color:#4c8dff}',
      '.dta-cards{display:flex;flex-direction:column;gap:10px}',
      '.dta-card{border:1px solid var(--dsw-alias-border-l2);background:var(--dsw-alias-bg-layer-3);border-radius:10px;padding:11px 13px}',
      '.dta-card .head{display:flex;align-items:center;gap:8px;flex-wrap:wrap}',
      '.dta-card .head .title{font-size:13.5px;font-weight:600;word-break:break-word}',
      '.dta-card .meta{display:flex;align-items:center;gap:14px;flex-wrap:wrap;margin-top:8px;font-size:12px;color:var(--dsw-alias-label-secondary)}',
      '.dta-card .meta b{color:var(--dsw-alias-label-primary);font-variant-numeric:tabular-nums}',
      '.dta-card .sub{display:flex;align-items:center;gap:12px;flex-wrap:wrap;margin-top:5px;font-size:11px;color:var(--dsw-alias-label-tertiary)}',
      '.dta-card .sub b{color:var(--dsw-alias-label-secondary);font-variant-numeric:tabular-nums}',
      '.dta-collapse{border:0;background:transparent;color:var(--dsw-alias-label-tertiary);cursor:pointer;font-size:11.5px;padding:0;text-decoration:underline dotted;margin-top:2px}',
      '.dta-collapse:hover{color:var(--dsw-alias-label-primary)}',
      '.dta-card .models{margin-top:8px}',
      '.dta-hbar{height:7px;border-radius:4px;background:var(--dsw-alias-bg-layer-1);overflow:hidden;margin-top:3px}',
      '.dta-hbar i{display:block;height:100%}',
      '.dta-grid{display:grid;grid-template-columns:1fr 1fr;gap:14px}',
      '@media (max-width:760px){.dta-grid{grid-template-columns:1fr}}',
      '.dta-detail{margin-top:10px;border-top:1px dashed var(--dsw-alias-border-l2);padding-top:10px}',
      '.dta-msg{font-size:12px;color:var(--dsw-alias-label-secondary);padding:5px 0;border-bottom:1px solid var(--dsw-alias-border-l2);display:flex;gap:10px;align-items:baseline;flex-wrap:wrap}',
      '.dta-msg .r{width:36px;color:var(--dsw-alias-label-tertiary);font-size:10.5px;flex-shrink:0}',
      '.dta-table-wrap{overflow-x:auto;max-width:100%}',
      '.dta-table{width:100%;border-collapse:collapse;font-size:12.5px}',
      '.dta-table th,.dta-table td{border-bottom:1px solid var(--dsw-alias-border-l2);padding:6px 8px;text-align:left;white-space:nowrap}',
      '.dta-table th{color:var(--dsw-alias-label-tertiary);font-weight:600;font-size:11px}',
      '.dta-table td.wrap{white-space:normal;word-break:break-word;min-width:200px;max-width:380px}',
      '.dta-table td.num{text-align:right;font-variant-numeric:tabular-nums}',
      '.dta-badge{display:inline-block;font-size:10.5px;font-weight:600;padding:1px 8px;border-radius:10px}',
      '.dta-b-ok{background:rgba(52,211,153,.15);color:#34d399}',
      '.dta-b-warn{background:rgba(251,191,36,.15);color:#fbbf24}',
      '.dta-b-danger{background:rgba(248,113,113,.15);color:#f87171}',
      '.dta-b-muted{background:rgba(139,147,167,.18);color:var(--dsw-alias-label-tertiary)}',
      '.dta-b-info{background:rgba(76,141,255,.15);color:#4c8dff}',
      '.dta-b-purple{background:rgba(176,107,255,.15);color:#b06bff}',
      '.dta-fold{display:block;width:100%;text-align:left;border:1px dashed var(--dsw-alias-border-l2);background:var(--dsw-alias-bg-layer-2);color:var(--dsw-alias-label-tertiary);font-size:12px;padding:6px 10px;border-radius:8px;cursor:pointer;margin-top:2px}',
      '.dta-fold:hover{color:var(--dsw-alias-label-primary);border-color:var(--dsw-alias-border-l1)}',
      '.dta-fold .n{color:var(--dsw-alias-label-secondary);font-weight:600;font-variant-numeric:tabular-nums}',
      '.dta-dim{opacity:.45;filter:grayscale(.4)}',
      '.dta-loading{color:var(--dsw-alias-label-tertiary);font-size:13px;padding:20px 0}',
      '.dta-empty{color:var(--dsw-alias-label-tertiary);font-size:12.5px;padding:6px 0}',
      '.dta-head{font-size:12px;color:var(--dsw-alias-label-tertiary);display:flex;align-items:center;gap:8px}',
    ].join('');

    const tagId = 'dsh-token-attention/panel.css';
    if (typeof document !== 'undefined' && document.querySelector('style[data-plugin-css=' + JSON.stringify(tagId) + ']') === null) {
      const tag = document.createElement('style');
      tag.dataset.plugin = 'dsh-token-attention';
      tag.dataset.pluginCss = tagId;
      tag.textContent = css;
      document.head.appendChild(tag);
    }

    // ---------- 工具 ----------
    const fmtTokens = (n) => { if (n == null) return '-'; if (n >= 1e6) return (n / 1e6).toFixed(2) + 'M'; if (n >= 1e3) return (n / 1e3).toFixed(1) + 'K'; return String(n); };
    const fmtCost = (n) => (n == null ? '-' : '¥' + Number(n).toFixed(3));
    const fmtPct = (n, d = 1) => (n == null ? '-' : Number(n).toFixed(d) + '%');
    const fmtTime = (ts) => { if (!ts) return '-'; const d = new Date(ts); const pad = (x) => String(x).padStart(2, '0'); return d.getMonth() + 1 + '-' + pad(d.getDate()) + ' ' + pad(d.getHours()) + ':' + pad(d.getMinutes()); };
    // 官方 sessionStats 时长（ms）→ 紧凑文案：45.2s / 2m42s（与内置统计条同风格）
    const fmtDur = (ms) => { if (ms == null) return '-'; if (ms < 1000) return Math.round(ms) + 'ms'; const s = ms / 1000; if (s < 60) return (Math.round(s * 10) / 10) + 's'; const m = Math.floor(s / 60); const r = Math.round(s % 60); return m + 'm' + (r > 0 ? r + 's' : ''); };
    const SCOPE_LABELS = { day: '今日', week: '本周', month: '本月' };
    const VIEW_LABELS = { overview: '总览', sessions: '会话', tasks: '任务', cost: '费用', settings: '设置' };
    // 模型颜色：flash/pro 保持品牌色，其余模型按名字稳定映射到调色板（不再统称"其他"）
    const MODEL_COLORS = { flash: '#4c8dff', pro: '#b06bff' };
    const PALETTE = ['#34d399', '#fbbf24', '#f87171', '#22d3ee', '#f472b6', '#a3e635', '#fb923c', '#818cf8', '#e879f9', '#60a5fa'];
    const modelColorHex = (short) => {
      if (MODEL_COLORS[short]) return MODEL_COLORS[short];
      let h = 0;
      for (let i = 0; i < String(short).length; i += 1) h = (h * 31 + String(short).charCodeAt(i)) >>> 0;
      return PALETTE[h % PALETTE.length];
    };
    const TYPE_LABELS = { coding: '编码', research: '调研', writing: '写作', batch: '批处理', qa: '问答', unknown: '未识别' };
    const TYPE_CLASS = { coding: 'dta-b-purple', research: 'dta-b-info', writing: 'dta-b-ok', batch: 'dta-b-warn', qa: 'dta-b-muted', unknown: 'dta-b-muted' };
    const typeBadge = (t) => {
      if (!t) return null;
      const label = TYPE_LABELS[t] || t;
      const cls = TYPE_CLASS[t] || 'dta-b-muted';
      return h('span', { className: 'dta-badge ' + cls }, label);
    };
    const roleBadge = (role) => {
      if (role === 'assistant') return h('span', { className: 'dta-badge dta-b-info' }, '助手');
      if (role === 'user') return h('span', { className: 'dta-badge dta-b-ok' }, '用户');
      if (role === 'tool') return h('span', { className: 'dta-badge dta-b-muted' }, '工具');
      return h('span', { className: 'dta-badge dta-b-muted' }, role || '-');
    };
    const healthBadgeUi = (health) => {
      if (health === 'danger') return h('span', { className: 'dta-badge dta-b-danger' }, '建议换会话');
      if (health === 'warn') return h('span', { className: 'dta-badge dta-b-warn' }, '注意');
      return h('span', { className: 'dta-badge dta-b-ok' }, '健康');
    };
    const phaseBadge = (phase) => {
      if (phase === 'active') return h('span', { className: 'dta-badge dta-b-ok' }, '进行中');
      if (phase === 'paused') return h('span', { className: 'dta-badge dta-b-warn' }, '已暂停');
      if (phase === 'complete') return h('span', { className: 'dta-badge dta-b-muted' }, '已完成');
      if (phase === 'blocked') return h('span', { className: 'dta-badge dta-b-danger' }, '受阻');
      return h('span', { className: 'dta-badge dta-b-muted' }, phase ?? '-');
    };
    const ADV_ICONS = { time: '⏰', switch: '⚠️', handoff: '📋', context: '🔍', cost: '💰', model: '🧩' };
    const ADV_TITLES = { time: '时间建议', switch: '换对话建议', handoff: 'hand-off 建议', context: '上下文建议', cost: '费用建议', model: '模型建议' };
    const modelBar = (models, totalTokens) => {
      const arr = models || [];
      const sum = totalTokens || arr.reduce((a, m) => a + m.tokens, 0);
      if (sum <= 0) return h('div', { className: 'dta-empty' }, '暂无消耗');
      return h('div', { className: 'dta-modelbar' },
        arr.map((m, i) => {
          const pct = (m.tokens / sum) * 100;
          return pct > 0.5 ? h('i', { key: i, style: { width: pct + '%', background: modelColorHex(m.short) }, title: (m.model || m.short) + ' ' + fmtTokens(m.tokens) }) : null;
        }),
      );
    };
    // 导出（#8）：Markdown / CSV 生成 + Blob 下载
    const downloadBlob = (filename, text, mime) => {
      try {
        const blob = new Blob([text], { type: mime });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url; a.download = filename;
        document.body.appendChild(a); a.click();
        setTimeout(() => { URL.revokeObjectURL(url); a.remove(); }, 200);
      } catch (e) { /* 忽略下载失败 */ }
    };
    const exportTasksMd = (tasks) => {
      const lines = [];
      lines.push('# Token Check · 任务台账（goal）');
      lines.push('');
      lines.push('导出时间：' + new Date().toLocaleString());
      lines.push('');
      let totalTokens = 0, totalCost = 0;
      tasks.forEach((t, i) => {
        const label = TYPE_LABELS[t.type] || t.type || '-';
        lines.push('## ' + (i + 1) + '. 【' + label + '】' + t.objective);
        lines.push('');
        lines.push('- 阶段：' + (t.phase || '-') + ' · 轮次 ' + t.roundsStarted + ' / ' + t.maxGoalRounds + ' · 会话 ' + t.sessionCount);
        lines.push('- Tokens：' + fmtTokens(t.tokens) + ' · 费用（估）：' + fmtCost(t.cost) + ' · 更新：' + fmtTime(t.updatedAt));
        if (t.typeHint) lines.push('- 建议：' + t.typeHint);
        if (t.models && t.models.length > 0) {
          lines.push('');
          lines.push('| 模型 | Tokens | 费用 | 命中率 | ¥/M输出 |');
          lines.push('| --- | --- | --- | --- | --- |');
          t.models.forEach((m) => {
            lines.push('| ' + m.model + ' | ' + fmtTokens(m.tokens) + ' | ' + fmtCost(m.cost) + ' | ' + fmtPct(m.hitRate) + ' | ' + (m.unitCost == null ? '-' : m.unitCost) + ' |');
          });
        }
        if (t.subagents && t.subagents.length > 0) {
          lines.push('');
          lines.push('子代理归并：');
          t.subagents.forEach((sb) => {
            lines.push('- ' + (sb.label || sb.sessionId.slice(0, 8)) + '（' + (sb.model || '-') + '）：' + fmtTokens(sb.tokens) + ' / ' + fmtCost(sb.cost));
          });
        }
        lines.push('');
        totalTokens += t.tokens; totalCost += t.cost;
      });
      lines.push('---');
      lines.push('合计：' + tasks.length + ' 个任务 · ' + fmtTokens(totalTokens) + ' tokens · ' + fmtCost(totalCost));
      lines.push('');
      downloadBlob('token-check-tasks-' + new Date().toISOString().slice(0, 10) + '.md', lines.join('\n'), 'text/markdown;charset=utf-8');
    };
    const exportTasksCsv = (tasks) => {
      const esc = (v) => '"' + String(v == null ? '' : v).replace(/"/g, '""') + '"';
      const rows = [['目标', '类型', '阶段', '轮次', '会话数', '模型', 'Tokens', '费用', '命中率', '¥/M输出'].join(',')];
      tasks.forEach((t) => {
        const base = [esc(t.objective), esc(TYPE_LABELS[t.type] || t.type || ''), esc(t.phase), t.roundsStarted + '/' + t.maxGoalRounds, t.sessionCount];
        const ms = (t.models && t.models.length > 0 ? t.models : [{ model: '', tokens: 0, cost: 0, hitRate: null, unitCost: null }]);
        ms.forEach((m) => {
          rows.push([...base, esc(m.model), m.tokens, m.cost, m.hitRate == null ? '' : m.hitRate, m.unitCost == null ? '' : m.unitCost].join(','));
        });
      });
      downloadBlob('token-check-tasks-' + new Date().toISOString().slice(0, 10) + '.csv', '\uFEFF' + rows.join('\n'), 'text/csv;charset=utf-8');
    };
    // P2 hand-off 模板一键生成（下载 .md，可放入工作区 notes/）
    const exportHandoff = (t) => {
      const now = new Date();
      const lines = [];
      lines.push('# Hand-off: ' + (t.objective || t.id));
      lines.push('');
      lines.push('- 目标：' + (t.objective || '-'));
      lines.push('- 当前进度：' + (t.phase || '-') + '（轮次 ' + t.roundsStarted + ' / ' + t.maxGoalRounds + '，会话 ' + t.sessionCount + '）');
      lines.push('- 任务类型：' + (TYPE_LABELS[t.type] || t.type || '-') + (t.typeHint ? '（' + t.typeHint + '）' : ''));
      lines.push('- 已消耗（token/费用/会话数）：' + fmtTokens(t.tokens) + ' / ' + fmtCost(t.cost) + ' / ' + t.sessionCount);
      if (t.models && t.models.length > 0) {
        lines.push('- 模型拆解：' + t.models.map((m) => m.model + ' ' + fmtTokens(m.tokens) + ' ' + fmtCost(m.cost) + (m.hitRate != null ? ' 命中' + m.hitRate + '%' : '')).join('；'));
      }
      if (t.subagents && t.subagents.length > 0) {
        lines.push('- 子代理归并：' + t.subagents.map((sb) => (sb.label || sb.sessionId.slice(0, 8)) + ' ' + fmtTokens(sb.tokens) + ' ' + fmtCost(sb.cost)).join('；'));
      }
      lines.push('- 关键文件/产出：');
      lines.push('- 下一步：');
      lines.push('- 注意事项/坑：');
      lines.push('- 交接时间：' + now.toLocaleString());
      lines.push('');
      const name = (t.objective || t.id).replace(/[\\/:*?"<>|\n\r]+/g, ' ').trim().slice(0, 40) || 'task';
      downloadBlob('handoff-' + name + '.md', lines.join('\n'), 'text/markdown;charset=utf-8');
    };


    // ---------- 面板组件 ----------
    function TokenAttentionPanel() {
      const [view, setView] = useState('overview');
      const [scope, setScope] = useState('day');
      const [summary, setSummary] = useState(null);
      const [trend, setTrend] = useState(null);
      const [sessions, setSessions] = useState(null);
      const [tasks, setTasks] = useState(null);
      const [advice, setAdvice] = useState(null);
      const [error, setError] = useState(null);
      const [loading, setLoading] = useState(true);
      // #3 会话下钻
      const [expandedId, setExpandedId] = useState(null);
      const [detail, setDetail] = useState({});
      // 任务卡折叠（轻量化）
      const [showModels, setShowModels] = useState({});
      // 已采纳建议 / 已完成任务：默认折叠为灰色摘要行；已归档/子代理会话默认隐藏但可展开，保持面板简洁
      const [showAdoptedAdv, setShowAdoptedAdv] = useState(false);
      const [showDoneTasks, setShowDoneTasks] = useState(false);
      const [showHiddenSessions, setShowHiddenSessions] = useState(false);
      const [detailLoading, setDetailLoading] = useState({});
      // 设置视图
      const [settings, setSettings] = useState(null);
      const [settingsMsg, setSettingsMsg] = useState(null);

      const load = useCallback(async () => {
        setLoading(true); setError(null);
        try {
          const [s, d, ss, t, a] = await Promise.all([
            fetch('/token-attention/api/summary?scope=' + scope).then((r) => r.json()),
            fetch('/token-attention/api/trend?scope=' + scope).then((r) => r.json()),
            fetch('/token-attention/api/sessions').then((r) => r.json()),
            fetch('/token-attention/api/tasks').then((r) => r.json()),
            fetch('/token-attention/api/advice').then((r) => r.json()),
          ]);
          setSummary(s); setTrend(d); setSessions(ss); setTasks(t); setAdvice(a);
        } catch (e) { setError(String(e && e.message ? e.message : e)); }
        finally { setLoading(false); }
      }, [scope]);

      useEffect(() => { load(); }, [load]);

      const loadSettings = async () => {
        try {
          const r = await fetch('/token-attention/api/settings').then((x) => x.json());
          setSettings(r);
        } catch (e) { setSettingsMsg('设置加载失败：' + String(e)); }
      };
      useEffect(() => { if (view === 'settings' && settings === null) loadSettings(); }, [view, settings]);
      const saveSettings = async () => {
        try {
          const r = await fetch('/token-attention/api/settings', {
            method: 'PUT',
            headers: { 'content-type': 'application/json' },
            body: JSON.stringify(settings),
          }).then((x) => x.json());
          setSettingsMsg(r.ok ? '已保存（后续新记录按新单价计费）' : ('保存失败：' + JSON.stringify(r)));
          setTimeout(() => setSettingsMsg(null), 4000);
        } catch (e) { setSettingsMsg('保存失败：' + String(e)); }
      };

      const toggleDetail = async (id) => {
        if (expandedId === id) { setExpandedId(null); return; }
        setExpandedId(id);
        if (detail[id] === undefined && !detailLoading[id]) {
          setDetailLoading((d) => ({ ...d, [id]: true }));
          try {
            const r = await fetch('/token-attention/api/sessions/' + encodeURIComponent(id)).then((x) => x.json());
            setDetail((d) => ({ ...d, [id]: r.messages || [] }));
          } catch (e) {
            setDetail((d) => ({ ...d, [id]: null }));
          } finally {
            setDetailLoading((d) => ({ ...d, [id]: false }));
          }
        }
      };

      if (loading && summary === null) return h('div', { className: 'dta-panel' }, h('div', { className: 'dta-loading' }, '加载中…'));

      const kpis = summary ? [
        { k: SCOPE_LABELS[scope] + '消耗', v: fmtTokens(summary.total), d: '输入 ' + fmtTokens(summary.inputMiss) + ' / 命中 ' + fmtTokens(summary.inputHit) },
        { k: SCOPE_LABELS[scope] + '费用（估）', v: fmtCost(summary.cost), d: '高峰 ' + fmtCost(summary.peakCost) + ' · 空闲 ' + fmtCost(summary.idleCost) },
        { k: '缓存命中率', v: summary.hitRate == null ? '未知' : summary.hitRate + '%', d: '输入合计 ' + fmtTokens(summary.inputHit + summary.inputMiss) },
        { k: '活跃会话', v: String(summary.sessionCount), d: 'goal ' + summary.activeGoalCount + ' / ' + summary.goalCount },
        summary.avgAttention != null ? { k: '注意力评分', v: String(summary.avgAttention), d: summary.attentionCount > 0 ? summary.attentionCount + ' 个会话建议换新对话' : '健康' } : null,
      ].filter(Boolean) : [];

      const trendMax = trend && trend.items ? Math.max(1, ...trend.items.map((it) => it.segments.reduce((a, s) => a + s.tokens, 0))) : 1;
      const trendChart = trend && trend.items ? h('div', { className: 'dta-bars' },
        trend.items.map((it) => {
          const total = it.segments.reduce((a, s) => a + s.tokens, 0);
          return h('div', { className: 'col', key: it.label, title: it.label + (it.peak ? '（高峰）' : '') + ' 合计 ' + fmtTokens(total) },
            it.segments.flatMap((seg) => {
              const blocks = [];
              if (seg.peakTokens > 0) blocks.push(h('div', { key: seg.model + '-p', className: 'dta-seg', style: { height: (seg.peakTokens / trendMax * 100) + '%', background: modelColorHex(seg.short) }, title: seg.model + ' 高峰 ' + fmtTokens(seg.peakTokens) }));
              if (seg.idleTokens > 0) blocks.push(h('div', { key: seg.model + '-i', className: 'dta-seg idle', style: { height: (seg.idleTokens / trendMax * 100) + '%', background: modelColorHex(seg.short) }, title: seg.model + ' 空闲 ' + fmtTokens(seg.idleTokens) }));
              return blocks;
            }),
            h('div', { className: 'lbl' }, it.label),
          );
        }),
      ) : null;

      const adoptedSet = advice && advice.adopted ? new Set(advice.adopted) : new Set();
      const adoptAdvice = async (id) => {
        try {
          await fetch('/token-attention/api/advice', {
            method: 'POST',
            headers: { 'content-type': 'application/json' },
            body: JSON.stringify({ adopt: true, id }),
          });
          const a = await fetch('/token-attention/api/advice').then((x) => x.json());
          setAdvice(a);
        } catch (e) { /* 忽略 */ }
      };
      const advList = (advice && advice.cards) || [];
      const advPending = advList.filter((c) => !adoptedSet.has(c.id));
      const advAdopted = advList.filter((c) => adoptedSet.has(c.id));
      const renderAdvCard = (c) => h('div', { key: c.id, className: 'dta-adv ' + c.level + (adoptedSet.has(c.id) ? ' dta-dim' : '') },
        h('div', { className: 't' }, h('span', null, ADV_ICONS[c.kind] || '💡'), ' ', c.title || ADV_TITLES[c.kind] || c.kind),
        h('div', { className: 'b' }, c.body),
        adoptedSet.has(c.id) ? h('span', { className: 'dta-badge dta-b-ok', style: { marginTop: 6 } }, '✓ 已采纳') : h('button', { className: 'dta-link', style: { marginTop: 6 }, onClick: () => adoptAdvice(c.id), type: 'button' }, '采纳'),
      );
      const adviceCards = advPending.length > 0 || advAdopted.length > 0 ? h('div', { className: 'dta-advs' },
        advPending.map(renderAdvCard),
        advAdopted.length > 0 ? h('button', { className: 'dta-fold', type: 'button', onClick: () => setShowAdoptedAdv((v) => !v) },
          h('span', null, showAdoptedAdv ? '▾' : '▸', ' 已采纳 '),
          h('span', { className: 'n' }, advAdopted.length),
          h('span', null, ' 条', showAdoptedAdv ? ' · 收起' : ' · 展开'),
        ) : null,
        showAdoptedAdv ? advAdopted.map(renderAdvCard) : null,
      ) : null;

      let body = null;
      if (view === 'overview') {
        const noData = summary && summary.total === 0 && summary.sessionCount === 0;
        body = h('div', { className: 'dta-panel' },
          noData ? h('div', { className: 'dta-section' },
            h('h4', null, '👋 欢迎使用 Token Check · 词元管理'),
            h('div', { className: 'meta' }, '插件已就绪。DSH 会话活动后，token 用量 / 费用 / 任务 / 建议会自动出现在这里（含当前会话）。'),
            h('div', { className: 'meta' }, h('span', { style: { color: 'var(--dsw-alias-label-tertiary)' } }, '提示：缓存命中率越高，输入成本越低（命中约 1/30 价）；高峰时段（9–12 / 14–18）全价，其余半价。')),
          ) : null,
          h('div', { className: 'dta-kpis' }, kpis.map((k) => h('div', { className: 'dta-kpi', key: k.k }, h('div', { className: 'k' }, k.k), h('div', { className: 'v' }, k.v), h('div', { className: 'd' }, k.d)))),
          summary && summary.models && summary.models.length > 0 ? h('div', { className: 'dta-section' },
            h('h4', null, '模型构成（' + SCOPE_LABELS[scope] + '）'),
            modelBar(summary.models, summary.total),
            h('div', { style: { marginTop: 8, display: 'flex', flexDirection: 'column', gap: 6 } }, summary.models.map((m) => h('div', { key: m.model, style: { display: 'flex', alignItems: 'center', gap: 7, fontSize: 12 } }, h('i', { style: { width: 9, height: 9, borderRadius: 2, background: modelColorHex(m.short), flexShrink: 0 } }), h('span', { style: { color: 'var(--dsw-alias-label-primary)', fontWeight: 600 } }, m.short), h('span', { style: { color: 'var(--dsw-alias-label-secondary)' } }, fmtCost(m.cost) + ' · ' + m.share + '%')))),
          ) : null,
          adviceCards ? h('div', { className: 'dta-section' },
            h('h4', null, '建议'),
            adviceCards,
          ) : null,
          h('div', { className: 'dta-section' },
            h('h4', null, SCOPE_LABELS[scope] + '消耗趋势（按模型堆叠 · 半透明=空闲）'),
            trendChart,
            h('div', { className: 'dta-legend' },
              (summary && summary.models && summary.models.length > 0
                ? summary.models
                : [{ short: 'flash' }, { short: 'pro' }]
              ).map((m) => h('span', { key: m.model || m.short }, h('i', { style: { background: modelColorHex(m.short) } }), m.short)),
            ),
          ),
        );
      } else if (view === 'sessions') {
        const list = sessions && sessions.items ? sessions.items : [];
        // 默认只展示主会话（与 DSH 自带会话列表口径一致）：归档 / 子代理会话折叠在
        // 「已隐藏」摘要行下，点击可展开查看（灰色显示）。
        const activeSessions = list.filter((s) => !s.archived && !s.isSubagent);
        const hiddenSessions = list.filter((s) => s.archived || s.isSubagent);
        const archivedCount = list.filter((s) => s.archived).length;
        const subagentCount = list.filter((s) => !s.archived && s.isSubagent).length;
        const renderSessionCard = (s) => h('div', { className: 'dta-card' + (s.archived || s.isSubagent ? ' dta-dim' : ''), key: s.id },
              h('div', { className: 'head' },
                h('span', { className: 'title' }, s.title),
                s.goalType ? typeBadge(s.goalType) : null,
                healthBadgeUi(s.health),
                s.isSubagent ? h('span', { className: 'dta-badge dta-b-muted' }, '子代理') : null,
                h('button', { className: 'dta-link', onClick: () => toggleDetail(s.id), type: 'button' }, expandedId === s.id ? '收起' : '详情'),
              ),
              h('div', { className: 'meta' },
                h('span', null, 'tokens ', h('b', null, fmtTokens(s.tokens))),
                h('span', null, '费用 ', h('b', null, fmtCost(s.cost))),
                h('span', null, '命中率 ', h('b', null, fmtPct(s.hitRate))),
                h('span', null, '注意力 ', h('b', null, s.attention)),
              ),
              h('div', { className: 'sub' },
                h('span', null, '轮次 ', h('b', null, s.turnCount)),
                h('span', null, '上下文 ', h('b', null, fmtPct(s.contextUsedPct))),
                s.unitCost != null ? h('span', null, '¥/M输出 ', h('b', null, s.unitCost)) : null,
                s.compactionCount > 0 ? h('span', null, '压缩 ', h('b', null, s.compactionCount), ' 次') : null,
                // 官方 sessionStats（DSH 内置统计条同源）：步数 / LLM / 工具时长
                s.steps != null ? h('span', null, '步 ', h('b', null, s.steps)) : null,
                s.llmMs != null ? h('span', null, 'LLM ', h('b', null, fmtDur(s.llmMs))) : null,
                s.toolMs != null && s.toolMs > 0 ? h('span', null, '工具 ', h('b', null, fmtDur(s.toolMs))) : null,
                h('span', null, '最后 ', fmtTime(s.lastActivity)),
              ),
              s.contextUsedPct != null ? h('div', { className: 'dta-hbar' }, h('i', { style: { width: Math.min(100, s.contextUsedPct) + '%', background: s.contextUsedPct > 70 ? '#f87171' : s.contextUsedPct > 50 ? '#fbbf24' : '#34d399' } })) : null,
              s.models && s.models.length > 0 ? h('div', { className: 'models' },
                modelBar(s.models, s.tokens),
                h('div', { style: { marginTop: 5, display: 'flex', flexDirection: 'column', gap: 4 } }, s.models.map((m) => h('div', { key: m.model, style: { display: 'flex', alignItems: 'center', gap: 7, fontSize: 12 } }, h('i', { style: { width: 9, height: 9, borderRadius: 2, background: modelColorHex(m.short), flexShrink: 0 } }), h('span', null, m.short, ' ', fmtTokens(m.tokens), ' · ', fmtCost(m.cost), m.hitRate != null ? ' · 命中' + m.hitRate + '%' : '')))),
              ) : null,
              // #3 下钻明细
              expandedId === s.id ? h('div', { className: 'dta-detail' },
                detailLoading[s.id] ? h('div', { className: 'dta-empty' }, '加载中…') :
                detail[s.id] === null ? h('div', { className: 'dta-empty' }, '明细加载失败') :
                detail[s.id] && detail[s.id].length === 0 ? h('div', { className: 'dta-empty' }, '该会话暂无消息记录') :
                h('div', { className: 'dta-table-wrap' }, h('table', { className: 'dta-table' },
                  h('thead', null, h('tr', null, ['#', '轮', '角色', '模型', '时段', '命中', '未命中', '输出', '思考', '费用', '时间'].map((x) => h('th', { key: x }, x)))),
                  h('tbody', null, (detail[s.id] || []).slice().reverse().map((m) => h('tr', { key: m.seq },
                    h('td', null, m.seq),
                    h('td', null, m.turn),
                    h('td', null, roleBadge(m.role)),
                    h('td', null, m.model || '-'),
                    h('td', null, m.peak === 1 ? '高峰' : '空闲'),
                    h('td', { className: 'num' }, m.inputHit == null ? '-' : fmtTokens(m.inputHit)),
                    h('td', { className: 'num' }, m.inputMiss == null ? '-' : fmtTokens(m.inputMiss)),
                    h('td', { className: 'num' }, m.output == null ? '-' : fmtTokens(m.output)),
                    h('td', { className: 'num' }, m.reasoning == null ? '-' : fmtTokens(m.reasoning)),
                    h('td', { className: 'num' }, m.cost == null ? '-' : fmtCost(m.cost)),
                    h('td', null, fmtTime(m.ts)),
                  ))),
                )),
              ) : null,
            );
        body = h('div', { className: 'dta-panel' },
          list.length === 0 ? h('div', { className: 'dta-empty' }, '暂无会话记录') : h('div', { className: 'dta-cards' },
            activeSessions.map(renderSessionCard),
            hiddenSessions.length > 0 ? h('button', { className: 'dta-fold', type: 'button', onClick: () => setShowHiddenSessions((v) => !v) },
              h('span', null, showHiddenSessions ? '▾' : '▸', ' 已隐藏 '),
              h('span', { className: 'n' }, hiddenSessions.length),
              h('span', null, ' 个会话（归档 ' + archivedCount + ' · 子代理 ' + subagentCount + '）', showHiddenSessions ? ' · 收起' : ' · 展开'),
            ) : null,
            showHiddenSessions ? hiddenSessions.map(renderSessionCard) : null,
          ),
        );
      } else if (view === 'tasks') {
        const list = tasks && tasks.items ? tasks.items : [];
        const activeTasks = list.filter((t) => t.phase !== 'complete');
        const doneTasks = list.filter((t) => t.phase === 'complete');
        const renderTaskCard = (t) => h('div', { className: 'dta-card' + (t.phase === 'complete' ? ' dta-dim' : ''), key: t.id + '@' + t.revision },
              h('div', { className: 'head' },
                typeBadge(t.type),
                phaseBadge(t.phase),
                h('span', { className: 'title' }, t.objective),
                h('button', { className: 'dta-link', onClick: () => exportHandoff(t), type: 'button' }, 'hand-off'),
              ),
              h('div', { className: 'meta' },
                h('span', null, 'tokens ', h('b', null, fmtTokens(t.tokens))),
                h('span', null, '费用 ', h('b', null, fmtCost(t.cost))),
                h('span', null, '轮次 ', h('b', null, t.roundsStarted + ' / ' + t.maxGoalRounds)),
              ),
              t.typeHint ? h('div', { className: 'sub' }, h('span', null, '建议：', t.typeHint)) : null,
              h('button', { className: 'dta-collapse', onClick: () => setShowModels((m) => ({ ...m, [t.id]: !m[t.id] })), type: 'button' },
                (showModels[t.id] ? '▾' : '▸') + ' 模型拆解' + (t.models && t.models.length ? '（' + t.models.length + '）' : '') + (t.subagents && t.subagents.length ? ' · 子代理 ' + t.subagents.length : ''),
              ),
              showModels[t.id] ? h('div', { className: 'models' },
                t.models && t.models.length > 0 ? h('div', { className: 'dta-table-wrap', style: { marginTop: 6 } }, h('table', { className: 'dta-table' },
                  h('thead', null, h('tr', null, ['模型', 'Tokens', '费用', '命中率', '¥/M输出'].map((x) => h('th', { key: x }, x)))),
                  h('tbody', null, t.models.map((m) => h('tr', { key: m.model },
                    h('td', null, h('span', null, h('i', { style: { display: 'inline-block', width: 9, height: 9, borderRadius: 2, background: modelColorHex(m.short), marginRight: 5, verticalAlign: -1 } }), m.model)),
                    h('td', { className: 'num' }, fmtTokens(m.tokens)),
                    h('td', { className: 'num' }, fmtCost(m.cost)),
                    h('td', { className: 'num' }, fmtPct(m.hitRate)),
                    h('td', { className: 'num' }, m.unitCost == null ? '-' : m.unitCost),
                  ))),
                )) : null,
                t.subagents && t.subagents.length > 0 ? h('div', { className: 'dta-table-wrap', style: { marginTop: 8 } }, h('table', { className: 'dta-table' },
                  h('thead', null, h('tr', null, ['子代理', '模型', 'Tokens', '费用'].map((x) => h('th', { key: x }, x)))),
                  h('tbody', null, t.subagents.map((sb) => h('tr', { key: sb.sessionId },
                    h('td', null, sb.label || sb.sessionId.slice(0, 8)),
                    h('td', null, sb.model || '-'),
                    h('td', { className: 'num' }, fmtTokens(sb.tokens)),
                    h('td', { className: 'num' }, fmtCost(sb.cost)),
                  ))),
                )) : null,
              ) : null,
            );
        body = h('div', { className: 'dta-panel' },
          h('div', { className: 'dta-toolbar' },
            h('span', { className: 'dta-empty' }, '共 ' + list.length + ' 个任务'),
            h('button', { className: 'dta-refresh', onClick: () => exportTasksMd(list), type: 'button' }, '导出 Markdown'),
            h('button', { className: 'dta-refresh', onClick: () => exportTasksCsv(list), type: 'button' }, '导出 CSV'),
          ),
          list.length === 0 ? h('div', { className: 'dta-empty' }, '暂无 goal 任务') : h('div', { className: 'dta-cards' },
            activeTasks.map(renderTaskCard),
            doneTasks.length > 0 ? h('button', { className: 'dta-fold', type: 'button', onClick: () => setShowDoneTasks((v) => !v) },
              h('span', null, showDoneTasks ? '▾' : '▸', ' 已完成 '),
              h('span', { className: 'n' }, doneTasks.length),
              h('span', null, ' 项', showDoneTasks ? ' · 收起' : ' · 展开'),
            ) : null,
            showDoneTasks ? doneTasks.map(renderTaskCard) : null,
          ),
        );
      } else if (view === 'cost') {
        const s = summary;
        const models = s && s.models ? s.models : [];
        const totalCost = s ? s.cost : 0;
        const peakShare = totalCost > 0 ? (s.peakCost / totalCost) * 100 : 0;
        // #8 费用杠杆：按桶费用占比（命中/未命中/输出各自的估算费用）
        const costDenom = Math.max(1e-9, (s ? s.hitCost + s.missCost + s.outputCost : 1e-9));
        const hitCost = s ? (s.hitCost / costDenom) * 100 : 0;
        const missCost = s ? (s.missCost / costDenom) * 100 : 0;
        const outCost = s ? (s.outputCost / costDenom) * 100 : 0;
        body = h('div', { className: 'dta-panel' },
          h('div', { className: 'dta-grid' },
            h('div', { className: 'dta-section' },
              h('h4', null, '峰谷拆解（' + SCOPE_LABELS[scope] + '）'),
              h('div', { className: 'meta' }, h('span', null, '高峰 ', h('b', null, fmtCost(s ? s.peakCost : 0)), ' · 空闲 ', h('b', null, fmtCost(s ? s.idleCost : 0)))),
              h('div', { className: 'dta-modelbar', style: { marginTop: 8 } }, h('i', { style: { width: peakShare + '%', background: '#f87171' } })),
              h('div', { className: 'meta', style: { marginTop: 4 } }, h('span', null, '高峰占比 ', h('b', null, peakShare.toFixed(1) + '%'), ' · 错峰最多可省约 ', h('b', null, fmtCost(s ? s.peakCost * 0.5 : 0)), '（估算）')),
            ),
            h('div', { className: 'dta-section' },
              h('h4', null, '杠杆拆解（费用构成，估算）'),
              h('div', { className: 'meta' }, h('span', null, '命中 ', h('b', null, fmtCost(s ? s.hitCost : 0))), ' ', h('span', null, '未命中 ', h('b', null, fmtCost(s ? s.missCost : 0))), ' ', h('span', null, '输出 ', h('b', null, fmtCost(s ? s.outputCost : 0)))),
              h('div', { className: 'dta-modelbar', style: { marginTop: 8 } }, h('i', { style: { width: hitCost + '%', background: '#34d399' } }), h('i', { style: { width: missCost + '%', background: '#fbbf24' } }), h('i', { style: { width: outCost + '%', background: '#f87171' } })),
              h('div', { className: 'meta', style: { marginTop: 4 } },
                h('span', null, h('i', { style: { display: 'inline-block', width: 9, height: 9, borderRadius: 2, background: '#34d399', marginRight: 4 } }), '命中 ' + hitCost.toFixed(1) + '%'),
                ' ',
                h('span', null, h('i', { style: { display: 'inline-block', width: 9, height: 9, borderRadius: 2, background: '#fbbf24', marginRight: 4 } }), '未命中 ' + missCost.toFixed(1) + '%'),
                ' ',
                h('span', null, h('i', { style: { display: 'inline-block', width: 9, height: 9, borderRadius: 2, background: '#f87171', marginRight: 4 } }), '输出 ' + outCost.toFixed(1) + '%'),
              ),
            ),
          ),
          h('div', { className: 'dta-section' },
            h('h4', null, '模型对比（' + SCOPE_LABELS[scope] + '）'),
            models.length === 0 ? h('div', { className: 'dta-empty' }, '暂无数据') : h('div', { className: 'dta-table-wrap' }, h('table', { className: 'dta-table' },
              h('thead', null, h('tr', null, ['模型', 'Tokens', '费用', '占比', '命中率', '输出占比', '¥/M输出'].map((x) => h('th', { key: x }, x)))),
              h('tbody', null, models.map((m) => h('tr', { key: m.model },
                h('td', null, h('span', null, h('i', { style: { display: 'inline-block', width: 9, height: 9, borderRadius: 2, background: modelColorHex(m.short), marginRight: 5, verticalAlign: -1 } }), m.model)),
                h('td', { className: 'num' }, fmtTokens(m.tokens)),
                h('td', { className: 'num' }, fmtCost(m.cost)),
                h('td', { className: 'num' }, m.share + '%'),
                h('td', { className: 'num' }, fmtPct(m.hitRate)),
                h('td', { className: 'num' }, fmtPct(m.outputShare)),
                h('td', { className: 'num' }, m.unitCost == null ? '-' : m.unitCost),
              ))),
            )),
          ),
          h('div', { className: 'meta' }, h('span', { style: { color: 'var(--dsw-alias-label-tertiary)' } }, '费用 = token × 单价（按模型 × 峰谷），均为估算，非官方账单。')),
        );
      } else {
        // 设置视图（FR7）：单价表 / 峰谷时段 / 建议阈值
        const set = settings;
        const updPrices = (fn) => setSettings((prev) => { const prices = { ...(prev.prices || {}) }; fn(prices); return { ...prev, prices }; });
        const updAdvice = (key, val) => setSettings((prev) => ({ ...prev, advice: { ...(prev.advice || {}), [key]: Number(val) } }));
        const updPeriods = (idx, key, val) => setSettings((prev) => ({ ...prev, peakPeriods: (prev.peakPeriods || []).map((p, i) => (i === idx ? { ...p, [key]: Number(val) } : p)) }));
        const addPeriod = () => setSettings((prev) => ({ ...prev, peakPeriods: [...(prev.peakPeriods || []), { start: 0, end: 8 }] }));
        const delPeriod = (idx) => setSettings((prev) => ({ ...prev, peakPeriods: (prev.peakPeriods || []).filter((_, i) => i !== idx) }));
        const addModel = () => updPrices((prices) => { prices['new-model'] = { hitIdle: 0.05, missIdle: 1.5, outputIdle: 4.5 }; });
        const delModel = (m) => updPrices((prices) => { delete prices[m]; });
        body = h('div', { className: 'dta-panel' },
          settingsMsg ? h('div', { className: 'dta-error' }, settingsMsg) : null,
          set === null ? h('div', { className: 'dta-empty' }, '设置加载中…') : h('div', { className: 'dta-panel' },
            h('div', { className: 'dta-section' },
              h('h4', null, '模型单价表（元 / 百万 tokens · 空闲价；高峰自动 ×2）'),
              h('div', { className: 'dta-table-wrap' }, h('table', { className: 'dta-table' },
                h('thead', null, h('tr', null, ['模型', '命中', '未命中', '输出', ''].map((x) => h('th', { key: x }, x)))),
                h('tbody', null, Object.keys(set.prices || {}).map((m) => h('tr', { key: m },
                  h('td', null, m),
                  h('td', null, h('input', { style: { width: 64 }, type: 'number', step: 0.01, value: set.prices[m].hitIdle, onChange: (e) => updPrices((p) => { p[m] = { ...p[m], hitIdle: Number(e.target.value) }; }) })),
                  h('td', null, h('input', { style: { width: 64 }, type: 'number', step: 0.01, value: set.prices[m].missIdle, onChange: (e) => updPrices((p) => { p[m] = { ...p[m], missIdle: Number(e.target.value) }; }) })),
                  h('td', null, h('input', { style: { width: 64 }, type: 'number', step: 0.01, value: set.prices[m].outputIdle, onChange: (e) => updPrices((p) => { p[m] = { ...p[m], outputIdle: Number(e.target.value) }; }) })),
                  h('td', null, h('button', { className: 'dta-link', onClick: () => delModel(m), type: 'button' }, '删除')),
                ))),
              )),
              h('button', { className: 'dta-refresh', style: { marginTop: 8 }, onClick: addModel, type: 'button' }, '+ 添加模型'),
            ),
            h('div', { className: 'dta-section' },
              h('h4', null, '峰谷时段（小时；含 start 不含 end）'),
              (set.peakPeriods || []).map((p, i) => h('div', { className: 'meta', key: i, style: { marginTop: 4 } },
                h('span', null, 'start '),
                h('input', { style: { width: 48 }, type: 'number', min: 0, max: 23, value: p.start, onChange: (e) => updPeriods(i, 'start', e.target.value) }),
                h('span', null, ' end '),
                h('input', { style: { width: 48 }, type: 'number', min: 1, max: 24, value: p.end, onChange: (e) => updPeriods(i, 'end', e.target.value) }),
                h('button', { className: 'dta-link', onClick: () => delPeriod(i), type: 'button' }, '删除'),
              )),
              h('button', { className: 'dta-refresh', style: { marginTop: 8 }, onClick: addPeriod, type: 'button' }, '+ 添加时段'),
            ),
            h('div', { className: 'dta-section' },
              h('h4', null, '建议引擎阈值'),
              h('div', { className: 'meta' }, h('span', null, '上下文占用 %（默认 70）'), h('input', { style: { width: 64 }, type: 'number', value: (set.advice || {}).contextThreshold, onChange: (e) => updAdvice('contextThreshold', e.target.value) })),
              h('div', { className: 'meta' }, h('span', null, '轮次（默认 40）'), h('input', { style: { width: 64 }, type: 'number', value: (set.advice || {}).turnThreshold, onChange: (e) => updAdvice('turnThreshold', e.target.value) })),
              h('div', { className: 'meta' }, h('span', null, '命中率下限 %（默认 40）'), h('input', { style: { width: 64 }, type: 'number', value: (set.advice || {}).hitRateThreshold, onChange: (e) => updAdvice('hitRateThreshold', e.target.value) })),
            ),
            h('div', { className: 'dta-toolbar' },
              h('button', { className: 'dta-refresh', onClick: saveSettings, type: 'button' }, '保存设置'),
              h('button', { className: 'dta-link', onClick: loadSettings, type: 'button' }, '放弃修改'),
            ),
          ),
        );
      }

      return h('div', { className: 'dta-panel' },
        h('div', { className: 'dta-head' }, 'Token Check · 词元管理'),
        h('div', { className: 'dta-toolbar' },
          h('div', { className: 'dta-tabs', role: 'group', 'aria-label': '视图' },
            ['overview', 'sessions', 'tasks', 'cost', 'settings'].map((v) => h('button', { key: v, className: v === view ? 'on' : '', onClick: () => setView(v), type: 'button' }, VIEW_LABELS[v])),
          ),
          view === 'overview' ? h('div', { className: 'dta-tabs', role: 'group', 'aria-label': '时间尺度' },
            ['day', 'week', 'month'].map((s) => h('button', { key: s, className: s === scope ? 'on' : '', onClick: () => setScope(s), type: 'button' }, SCOPE_LABELS[s])),
          ) : null,
          h('button', { className: 'dta-refresh', onClick: load, type: 'button' }, '刷新'),
        ),
        error ? h('div', { className: 'dta-error' }, '数据加载失败：' + error) : null,
        body,
      );
    }

    // ---------- 注册到设置侧边栏（settings.section） ----------
    function apply(ctx) {
      ctx.slots.inject('settings.section', () => ctx.slots.register({
        name: 'settings.section',
        id: 'token-attention',
        order: 20,
        label: () => '词元管理',
        inject: () => ({}),
      }, TokenAttentionPanel));
    }

    module.exports.inject = ['slots'];
    module.exports.apply = apply;
    return module.exports;
  },
});
