#!/usr/bin/env node
/**
 * Integration check: prove both halves mount the way the Harness mounts them.
 *
 * The Host half imports nothing outside its own files and Node builtins, so
 * this runs with no arguments, no extraction step, and no dependency on the
 * installed Harness:
 *
 *   node test/load-check.mjs
 *
 * It covers:
 *
 *   - the exported surface and the shipped patch against `resolveConfig`
 *   - `tools/post-execute`: lossless-only without a recovery path, `read`
 *     elision with its own path, pass-through of decisions the plugin does not
 *     own, and fault isolation
 *   - `agent/created` + `agent/inbox/claimed` + `session/event`: the memory
 *     document is created, filled with verbatim input and a turn digest, and
 *     matched on the next message, which injects through `agent.inject`
 *   - the mode route: GET reports the modes, POST changes and persists one
 *   - the Client half: its module id, its `slots` dependency, and the exact
 *     slot registration the page will consume
 *
 * Exit status is 0 when every check passes.
 */
import assert from 'node:assert/strict';
import { existsSync, mkdirSync, mkdtempSync, readFileSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { depthFor } from '../lib/depths.js';

const HERE = dirname(fileURLToPath(import.meta.url));
const ROOT = resolve(HERE, '..');
const load = (relative) => import(pathToFileURL(join(ROOT, relative)).href);

const plugin = await load('index.js');
const { readPatchConfig } = await load('tools/measure-tokens.mjs');
const { MODE_IDS } = await load('lib/modes.js');

// ---------------------------------------------------------------------------
// exports and config
// ---------------------------------------------------------------------------
assert.equal(plugin.name, 'token-frugal');
assert.deepEqual(plugin.inject, ['tools']);
assert.equal(typeof plugin.apply, 'function');
assert.equal(typeof plugin.resolveConfig, 'function');
console.log(`exports ok: name=${plugin.name} inject=${JSON.stringify(plugin.inject)}`);

const workspace = mkdtempSync(join(tmpdir(), 'tf-load-'));
process.env.DSH_PROFILE_DIR = workspace;
const rowConfig = readPatchConfig(join(ROOT, 'cordis.patch.yml'));
assert.ok(rowConfig !== undefined, 'cordis.patch.yml must yield a config block');
const resolved = plugin.resolveConfig(rowConfig);
assert.equal(resolved.defaultMaxChars, 1500);
assert.equal(resolved.budgets.get('read'), 3000);
assert.equal(resolved.memo.path, '.dsh-token-frugal/memory.md');
assert.equal(resolved.recall.maxChars, 1200);
assert.equal(resolved.bridge.path, '/dsh-token-frugal/modes');
console.log(`config validated from the patch: ${Object.keys(plugin.FIELD_KINDS).length} validated fields, memo=${resolved.memo.path}`);

for (const [label, config] of [
  ['unknown field', { notARealSetting: 1 }],
  ['unknown mode', { modes: { teleport: true } }],
  ['unknown memo key', { memo: { nope: 1 } }],
  ['unknown recall key', { recall: { nope: 1 } }],
  ['unknown bridge key', { bridge: { nope: 1 } }],
  ['wrong mode type', { modes: { json: 'yes' } }],
  ['wrong recall type', { recall: { maxChars: -5 } }],
]) {
  let message;
  try { plugin.resolveConfig({ ...rowConfig, ...config }); } catch (error) { message = error.message; }
  assert.ok(message !== undefined, `${label} must be refused`);
  assert.match(message, /token-frugal:/);
}
console.log('undeclared fields, modes, and wrong types are all refused');

// ---------------------------------------------------------------------------
// a fake Cordis context, agent, and HTTP exchange
// ---------------------------------------------------------------------------
const listeners = new Map();
const routes = new Map();
const injections = [];
const warnings = [];
const infos = [];
const injected = [];
const sourceViolations = [];

const fire = (event, ...args) => {
  const handlers = listeners.get(event) ?? [];
  assert.ok(handlers.length > 0, `no listener registered for ${event}`);
  for (const handler of handlers) handler(...args);
};

const sessionId = 'session-load-1';
const agent = {
  id: sessionId,
  session: {
    id: sessionId,
    header: { id: sessionId, cwd: workspace },
    // A session the plugin may rewrite: `append` records what the Host would
    // record, `eventAt` reads it back, and the aging test asserts the surface
    // replacement lands on the original seq.
    events: [],
    append(type, data, opts) {
      const event = { type, seq: this.events.length, time: Date.now(), data, ...(opts ?? {}) };
      this.events.push(event);
      return event;
    },
    eventAt(seq) { return this.events[seq]; },
  },
  // Mirror the durable-message contract `dsh-session` enforces on every
  // appended message: a nonempty producer-owned `source.kind`. The mock used
  // to accept anything, which is how 2.0.x shipped a source-less recall
  // message that threw "Cannot read properties of undefined (reading 'kind')"
  // in the Host (the `dsh-webhook` `agent/inbox/spliced` invariant) and in the
  // Chat inbox filter, blanking the page. Failing loudly here keeps a
  // source-less injection from reaching a release again.
  inject: (message) => {
    const source = message?.source;
    const valid = typeof source === 'object' && source !== null
      && typeof source.kind === 'string' && source.kind.length > 0;
    // Recorded before throwing: the recall path catches a failed injection and
    // continues with a warning, so the violation has to outlive the throw to be
    // reported by the assertion that follows the recall.
    if (!valid) sourceViolations.push(message);
    assert.ok(valid, 'an injected message needs a nonempty string source.kind');
    injected.push(message);
  },
  ctx: { tools: { restrict: () => () => {} }, effect: (fn) => { fn(); return () => {}; } },
};

const ctx = {
  on: (event, handler) => {
    listeners.set(event, [...(listeners.get(event) ?? []), handler]);
    return () => {};
  },
  effect: (fn) => { const disposer = fn(); return typeof disposer === 'function' ? disposer : () => {}; },
  // `inject` is how the plugin must acquire the web server: this row activates
  // as soon as `tools` is ready, which can precede the server's listen. A
  // one-shot `ctx.get('webServer')` lost the route in that ordering, which the
  // live check caught as a 404.
  inject: (deps, callback) => {
    injections.push([...deps]);
    if (deps.includes('webServer')) {
      callback({
        webServer: {
          register: (route) => { routes.set(route.path, route); return () => routes.delete(route.path); },
        },
      });
    }
    return () => {};
  },
  get: () => undefined,
  logger: {
    warn: (line) => warnings.push(line),
    info: (line) => infos.push(line),
    debug: () => {},
  },
  tools: { schemas: () => [], restrict: () => () => {} },
};

plugin.apply(ctx, rowConfig);
assert.ok(infos.some((line) => line.includes('token-frugal: ready')), 'the startup line is missing');
assert.ok(listeners.has('tools/post-execute'));
assert.ok(listeners.has('agent/created'));
assert.ok(listeners.has('agent/inbox/claimed'));
assert.ok(listeners.has('session/event'));
assert.ok(
  injections.some((deps) => deps.includes('webServer')),
  'the web server must be acquired through ctx.inject, not a one-shot ctx.get',
);
console.log('apply() registered post-execute, agent/created, inbox/claimed, session/event, and the route');

// ---------------------------------------------------------------------------
// tools/post-execute
// ---------------------------------------------------------------------------
const next = async () => ({ kind: 'accept' });
const contentOf = (decision, original) => (decision.content ?? original.content)[0].text;
const exec = { name: 'pwsh', callId: 'call_1', arguments: {}, signal: undefined, agent: undefined };

const oversized = Array.from({ length: 400 }, (_, i) => `row ${i} ${String(i * 7919).padStart(7)}    ${'q'.repeat(18)}      x${(i * i) % 977}   `).join('\n');
const result = { isError: false, value: null, content: [{ type: 'text', text: oversized }] };
const lossless = await listeners.get('tools/post-execute')[0](exec, result, next);
const losslessText = contentOf(lossless, result);
assert.ok(losslessText.length < oversized.length, 'lossless compression must shrink the result');
assert.ok(losslessText.length > 1500, `the fixture must stay over budget, got ${losslessText.length}`);
assert.ok(!losslessText.includes('elided by dsh-token-frugal'), 'no recovery path means no elision');
console.log(`lossless only, no recovery path: ${oversized.length} -> ${losslessText.length} chars, nothing dropped`);

const readText = `<path>C:\\x\\big.ts</path>\n<type>file</type>\n<content>\n${Array.from({ length: 400 }, (_, i) => `${i + 1}: const v${i} = g(${i * 31}); // ${'n'.repeat(24)}`).join('\n')}\n</content>`;
const readDecision = await listeners.get('tools/post-execute')[0](
  { ...exec, name: 'read' },
  { isError: false, value: null, content: [{ type: 'text', text: readText }] },
  next,
);
const readAfter = contentOf(readDecision, { content: [{ type: 'text', text: readText }] });
assert.ok(readAfter.includes('elided by dsh-token-frugal') && readAfter.includes('offset/limit'));
console.log(`read elided to ${readAfter.length} chars with a re-read hint`);

const blocked = { kind: 'block', feedback: [{ type: 'text', text: 'no' }] };
assert.equal(await listeners.get('tools/post-execute')[0](exec, result, async () => blocked), blocked);
assert.equal((await listeners.get('tools/post-execute')[0](exec, result, async () => ({ kind: 'accept', value: { ok: true } }))).value.ok, true);
const hostile = { isError: false, value: null, content: [{ type: 'text', get text() { throw new Error('boom'); } }] };
assert.equal((await listeners.get('tools/post-execute')[0](exec, hostile, next)).kind, 'accept');
assert.ok(warnings.some((line) => line.includes('compression skipped')));
console.log('block and value decisions pass through; a fault degrades to the original decision');

// A sibling listener that returns nothing makes `next()` resolve `undefined`.
// Reading `.kind` off that value is exactly the field failure
// (`Cannot read properties of undefined (reading 'kind')` inside the tool
// pipeline), so the hook repairs the decision instead of trusting it.
const hook = listeners.get('tools/post-execute')[0];
const orphaned = await hook(exec, result, async () => undefined);
assert.equal(orphaned.kind, 'accept', 'a listener that returns nothing must not crash the hook');
assert.ok(contentOf(orphaned, result).length < oversized.length, 'the repaired decision still compresses');
const partial = await hook(exec, result, async () => ({ content: [{ type: 'text', text: 'kept' }] }));
assert.equal(partial.kind, 'accept', 'a decision missing its discriminator gets one back');
assert.equal(partial.content[0].text, 'kept', 'the fields a sibling did return survive the repair');
assert.equal(await hook(exec, result, async () => null).then((value) => value.kind), 'accept');
console.log('a sibling that returns nothing is repaired to { kind: "accept" } instead of crashing the hook');

// ---------------------------------------------------------------------------
// the memory document and recall
// ---------------------------------------------------------------------------
const memoPath = join(workspace, resolved.memo.path);
fire('agent/created', { agent });
assert.ok(existsSync(memoPath), `the memory document must exist at ${memoPath}`);
const created = readFileSync(memoPath, 'utf8');
assert.match(created, /# dsh-token-frugal session memory/);
assert.match(created, new RegExp(`## ${sessionId} `));
console.log(`memory document created: ${memoPath}`);

const userLine = '请记住：重试策略实现在 dispatcher 里，超时参数在 timeoutPolicy。';
fire('agent/inbox/claimed', { agent, message: { content: [{ type: 'text', text: userLine }] }, turn: 1 });
assert.ok(readFileSync(memoPath, 'utf8').includes(userLine), 'the user text is recorded verbatim');
assert.equal(injected.length, 0, 'nothing to recall yet');
console.log('user input recorded verbatim; no recall on an empty document');

fire('session/event', { id: sessionId, header: { cwd: workspace } }, {
  type: 'assistant/message',
  data: { message: { content: [{ type: 'text', text: '- 已完成重试策略迁移\n- 已用 29 个测试验证' }] } },
});
fire('session/event', { id: sessionId, header: { cwd: workspace } }, { type: 'turn/end', data: { turn: 1 } });
const withDigest = readFileSync(memoPath, 'utf8');
assert.ok(withDigest.includes('### summary turn 1'), 'the turn digest block is recorded');
assert.ok(withDigest.includes('已完成重试策略迁移'), 'the digest quotes the reply, not the prompt');
console.log('turn digest recorded from the assistant reply');

fire('agent/inbox/claimed', {
  agent,
  message: { content: [{ type: 'text', text: '重试策略在哪个文件里实现？超时参数怎么配？' }] },
  turn: 2,
});
assert.deepEqual(sourceViolations, [], 'an injected message was missing its producer-owned source.kind');
assert.equal(injected.length, 1, `expected exactly one recall injection, got ${injected.length}`);
assert.equal(injected[0].role, 'user');
assert.equal(typeof injected[0].id, 'string');
assert.equal(injected[0].source.kind, 'token-frugal-recall', 'the injected message must carry its producer-owned source kind');
const recalled = injected[0].content[0].text;
assert.match(recalled, /<recalled-context source=/);
assert.match(recalled, /Prefer these over re-reading the transcript/);
assert.match(recalled, /重试策略/);
console.log(`recall injected ${recalled.length} chars for a matching follow-up`);

// `inject()` appends to next-step, so the carrier is claimed like any other
// pending input and comes back through `agent/inbox/claimed` at the next step
// boundary. The producer kind is what lets the plugin recognise its own
// message: without the guard, the recalled text would be written into the
// memory document as user input and then matched against itself.
fire('agent/inbox/claimed', { agent, message: injected[0], turn: 2 });
assert.equal(injected.length, 1, 'the plugin must not recall against its own carrier');
assert.ok(
  !readFileSync(memoPath, 'utf8').includes('<recalled-context'),
  'the injected text must never be recorded as user input',
);
console.log('the plugin ignores its own injected carrier instead of recording it');

fire('agent/inbox/claimed', {
  agent,
  message: { content: [{ type: 'text', text: '重试策略在哪个文件里实现？超时参数怎么配？' }] },
  turn: 3,
});
assert.equal(injected.length, 1, 'the same extracts are never injected twice in a row');
console.log('a repeated match is suppressed rather than re-injected');

// ---------------------------------------------------------------------------
// the mode route
// ---------------------------------------------------------------------------
const route = routes.get(resolved.bridge.path);
assert.ok(route !== undefined, 'the mode route must be registered');
assert.equal(route.kind, 'exact');

const exchange = () => {
  const state = { status: 0, headers: null, body: '' };
  return {
    state,
    writeHead(status, headers) { state.status = status; state.headers = headers; },
    end(payload) { state.body = payload ?? ''; },
    get json() { return JSON.parse(state.body); },
  };
};

const getResponse = exchange();
await route.handler({ method: 'GET' }, getResponse);
assert.equal(getResponse.state.status, 200);
assert.equal(getResponse.state.headers['cache-control'], 'no-store');
assert.equal(getResponse.json.modes.length, MODE_IDS.length);
assert.ok(getResponse.json.modes.every((mode) => typeof mode.on === 'boolean' && typeof mode.available === 'boolean'));
assert.equal(getResponse.json.version, 2);
console.log(`GET ${resolved.bridge.path} -> ${MODE_IDS.length} modes`);

const postResponse = exchange();
await route.handler({
  method: 'POST',
  async *[Symbol.asyncIterator]() { yield Buffer.from(JSON.stringify({ modes: { json: false, terminal: false } })); },
}, postResponse);
assert.equal(postResponse.state.status, 200);
assert.deepEqual(postResponse.json.changed, { json: false, terminal: false });
const statePath = join(workspace, 'dsh-token-frugal.state.json');
assert.ok(existsSync(statePath), `the choice must be persisted at ${statePath}`);
assert.deepEqual(JSON.parse(readFileSync(statePath, 'utf8')).modes.json, false);
assert.ok(infos.some((line) => line.includes('panel change')), 'the change must be logged');

const afterToggle = exchange();
await route.handler({ method: 'GET' }, afterToggle);
assert.equal(afterToggle.json.modes.find((mode) => mode.id === 'json').on, false);
console.log('POST toggled two modes, persisted them, and GET reports them off');

const badResponse = exchange();
await route.handler({
  method: 'POST',
  async *[Symbol.asyncIterator]() { yield Buffer.from(JSON.stringify({ modes: { teleport: true } })); },
}, badResponse);
assert.equal(badResponse.state.status, 400, 'an unknown mode must be a 400, not a silent no-op');

const methodResponse = exchange();
await route.handler({ method: 'DELETE' }, methodResponse);
assert.equal(methodResponse.state.status, 405);
console.log('an unknown mode is rejected, and an unsupported method gets 405');

// ---------------------------------------------------------------------------
// the elision depth
// ---------------------------------------------------------------------------
// The depth is a budget table, not a switch, so it travels in the same body
// under its own key: `{"modes":{...},"depth":"extreme"}`. An unknown tier must
// be a 400 — silently falling back would let the panel claim a tier the host
// never applied.
assert.deepEqual(afterToggle.json.depths.map((depth) => depth.id), ['standard', 'deep', 'extreme']);
assert.equal(afterToggle.json.elisionDepth, 'standard', 'a profile with no stored tier is on the default');
assert.ok(afterToggle.json.depths.every((depth) => typeof depth.promptReductionPercent === 'number'));
assert.ok(afterToggle.json.depths.every((depth) => Number.isFinite(depth.defaultMaxChars)));

const depthResponse = exchange();
await route.handler({
  method: 'POST',
  async *[Symbol.asyncIterator]() { yield Buffer.from(JSON.stringify({ modes: {}, depth: 'extreme' })); },
}, depthResponse);
assert.equal(depthResponse.state.status, 200, 'a depth-only change must be accepted');
assert.equal(depthResponse.json.changed.json, undefined, 'a depth change is not a mode change');
assert.equal(depthResponse.json.elisionDepth, 'extreme');
assert.equal(depthResponse.json.previousDepth, 'standard');
assert.equal(JSON.parse(readFileSync(statePath, 'utf8')).elisionDepth, 'extreme', 'the tier must be persisted too');
console.log('POST {depth} moved the tier, persisted it, and reported the previous one');

const unknownDepth = exchange();
await route.handler({
  method: 'POST',
  async *[Symbol.asyncIterator]() { yield Buffer.from(JSON.stringify({ depth: 'deeper' })); },
}, unknownDepth);
assert.equal(unknownDepth.state.status, 400, 'an unknown depth must be a 400, not a silent fallback');

const emptyBody = exchange();
await route.handler({
  method: 'POST',
  async *[Symbol.asyncIterator]() { yield Buffer.from(JSON.stringify({})); },
}, emptyBody);
assert.equal(emptyBody.state.status, 400, 'an empty patch is not a change');

const afterDepth = exchange();
await route.handler({ method: 'GET' }, afterDepth);
assert.equal(afterDepth.json.elisionDepth, 'extreme', 'GET must report the tier the profile is on');
console.log('an unknown depth and an empty body are both rejected');

// ---------------------------------------------------------------------------
// the statistics route
// ---------------------------------------------------------------------------
// Derived from the bridge path, not configured separately: a profile that points
// the bridge elsewhere must still get both routes from that one key.
const statsRoute = routes.get('/dsh-token-frugal/stats');
assert.ok(statsRoute !== undefined, 'the statistics route must be registered beside the mode route');
assert.equal(statsRoute.kind, 'exact');

const statsResponse = exchange();
await statsRoute.handler({ method: 'GET' }, statsResponse);
assert.equal(statsResponse.state.status, 200);
assert.equal(statsResponse.state.headers['cache-control'], 'no-store');
const report = statsResponse.json;
assert.equal(report.version, 2);
assert.equal(report.charsPerToken, 4);
assert.ok(report.session.savedChars > 0, 'the compressions this run already performed must be counted');
assert.ok(report.session.rewritten > 0, 'a rewritten result must be counted');
assert.ok(report.session.calls >= report.session.rewritten, 'every rewrite is also an inspected call');
assert.ok(report.session.savedTokens > 0, 'the saving must be priced in tokens');
assert.ok(report.session.savedRatio > 0 && report.session.savedRatio <= 1, 'the saved share is a ratio');
assert.ok(Array.isArray(report.tools) && report.tools.length > 0, 'the report must break the saving down by tool');
assert.ok(report.tools.some((row) => row.tool === 'read' && row.savedChars > 0), 'the elided read must appear in the breakdown');
assert.equal(typeof report.statsFile, 'string');
assert.ok(report.statsFile.endsWith('dsh-token-frugal.stats.json'), `unexpected statistics file: ${report.statsFile}`);
assert.ok(typeof report.generatedAt === 'string' && !Number.isNaN(Date.parse(report.generatedAt)));
console.log(`GET ${statsRoute.path} -> ${report.session.savedChars} chars saved across ${report.tools.length} tool(s)`);

const resetResponse = exchange();
await statsRoute.handler({
  method: 'POST',
  async *[Symbol.asyncIterator]() { yield Buffer.from(JSON.stringify({ reset: true })); },
}, resetResponse);
assert.equal(resetResponse.state.status, 200);
assert.equal(resetResponse.json.cumulative.savedChars, 0, 'clearing must zero the all-time record');
assert.equal(resetResponse.json.session.savedChars, report.session.savedChars, 'clearing must keep the current process record');

const statsBad = exchange();
await statsRoute.handler({
  method: 'POST',
  async *[Symbol.asyncIterator]() { yield Buffer.from(JSON.stringify({ nope: true })); },
}, statsBad);
assert.equal(statsBad.state.status, 400, 'an unsupported body must be refused');

const statsMethod = exchange();
await statsRoute.handler({ method: 'PUT' }, statsMethod);
assert.equal(statsMethod.state.status, 405);
console.log('the statistics route reports, clears the all-time half, and refuses bad input');

// ---------------------------------------------------------------------------
// aging: a result that is no longer new is rebuilt as a digest
// ---------------------------------------------------------------------------
// `agent/pre-step` is where the rewrite is committed, so the digest lands
// before the request built from that step and the shorter history is what the
// model reads. The original event stays in the transcript, which is why this
// is a surface replacement and not another `tools/post-execute` decision.
const extremeTier = exchange();
await route.handler({
  method: 'POST',
  async *[Symbol.asyncIterator]() { yield Buffer.from(JSON.stringify({ modes: {}, depth: 'extreme' })); },
}, extremeTier);
assert.equal(extremeTier.state.status, 200, 'the aging test needs the extreme tier');
assert.equal(extremeTier.json.elisionDepth, 'extreme');

const sessionLog = agent.session;
const body = Array.from({ length: 60 }, (_, i) => `line ${i + 1}: ${((i + 1) * 2654435761 % 4294967296).toString(16).padStart(8, '0').repeat(6)}`).join('\n');
const resultSeqs = [];
for (let i = 0; i < 7; i += 1) {
  const call = sessionLog.append('tool/call', { turn: 1, step: i, callId: `c${i}`, name: 'read', arguments: '{}' }, { surfaceOp: 'append' });
  fire('session/event', sessionLog, call);
  const result = sessionLog.append('tool/result', {
    turn: 1,
    step: i,
    message: { toolCallId: `c${i}`, content: [{ type: 'text', text: body }] },
  }, { surfaceOp: 'append' });
  fire('session/event', sessionLog, result);
  resultSeqs.push(result.seq);
}

const beforeAging = sessionLog.events.length;
const preStep = (listeners.get('agent/pre-step') ?? [])[0];
assert.ok(typeof preStep === 'function', 'the aging path must listen on agent/pre-step');
const enter = async () => ({ kind: 'enter', messages: [] });
await preStep({ agent }, enter);

const appended = sessionLog.events.slice(beforeAging);
const extremity = depthFor('extreme').aging.keepFull;
assert.equal(appended.length, resultSeqs.length - extremity, `the extreme tier keeps ${extremity} result(s) whole and ages the rest`);
for (const [index, event] of appended.entries()) {
  const target = resultSeqs[index];
  assert.equal(event.type, 'tool/result');
  assert.deepEqual(event.surfaceOp, { op: 'replace', startSeq: target, endSeq: target });
  assert.deepEqual(event.sourceEventSeqs, [target], 'a replacement must cite every node it shadows');
  const text = event.data.message.content.map((block) => block.text).join('');
  assert.ok(text.length < body.length, 'the aged copy must be shorter');
  assert.match(text, /elided by dsh-token-frugal/);
  // `dsh-session` permits exactly this much and no more.
  const rest = (value) => ({ ...value, message: { ...value.message, content: null } });
  assert.deepEqual(rest(event.data), rest(sessionLog.eventAt(target).data));
}
assert.equal(sessionLog.eventAt(resultSeqs[0]).data.message.content[0].text, body, 'the transcript keeps the full text');

const afterAging = sessionLog.events.length;
await preStep({ agent }, enter);
assert.equal(sessionLog.events.length, afterAging, 'a result is aged once, never again');

const agingReport = exchange();
await statsRoute.handler({ method: 'GET' }, agingReport);
assert.equal(agingReport.json.session.aged, resultSeqs.length - extremity, 'the aged results are reported');
console.log(`aging: ${appended.length} of ${resultSeqs.length} results replaced by digests, transcript intact`);


// ---------------------------------------------------------------------------
// the Client half
// ---------------------------------------------------------------------------
const registrations = [];
let loadedModule = null;
globalThis.window = {
  __ModuleLoader__: {
    load(spec) { loadedModule = spec; },
  },
};
try {
  await load('client.js');
} finally {
  delete globalThis.window;
}
assert.ok(loadedModule !== null, 'client.js must register a module with the page loader');
assert.equal(loadedModule.id, 'dsh-token-frugal', 'the module id must equal the package name');
assert.equal(typeof loadedModule.factory, 'function');

// React hooks are positional: seed one cell per hook the composer panel calls,
// in call order (loaded state, expanded flag, open grade, busy id, error), so it
// can really render.
let hookCells = [{ modes: getResponse.json.modes, profileDir: 'C:/profile' }, true, '', '', ''];
let hookCursor = 0;
const fakeReact = {
  createElement: (type, props, ...children) => ({ type, props: props ?? {}, children }),
  useState: (initial) => { const cell = hookCursor++; if (hookCells[cell] === undefined) hookCells[cell] = typeof initial === 'function' ? initial() : initial; return [hookCells[cell], () => {}]; },
  useEffect: () => {},
  useCallback: (fn) => fn,
};
let requiredNames = [];
const clientPlugin = loadedModule.factory((name) => {
  requiredNames.push(name);
  assert.equal(name, 'react', 'the Client half may require React and nothing else');
  return fakeReact;
});
assert.ok(clientPlugin.inject.includes('slots'));
clientPlugin.apply({
  get: () => undefined,
  slots: {
    inject: (slot, register) => {
      assert.ok(
        ['conversation.composer.dock', 'settings.section'].includes(slot),
        `the client half mounted into an unexpected slot: ${slot}`,
      );
      register();
    },
    register: (options, component) => { registrations.push({ options, component }); },
  },
});
assert.equal(registrations.length, 2, 'the client half mounts the composer panel and one settings page');

const composer = registrations.find((entry) => entry.options.name === 'conversation.composer.dock');
const settings = registrations.find((entry) => entry.options.name === 'settings.section');
assert.ok(composer !== undefined, 'the composer panel must be registered');
assert.ok(settings !== undefined, 'the settings page must be registered');
assert.equal(typeof composer.options.id, 'string');
assert.equal(typeof composer.options.order, 'number');
assert.equal(typeof composer.component, 'function', 'the slot must receive a component');
assert.equal(typeof settings.options.id, 'string');
assert.equal(typeof settings.options.order, 'number');
assert.equal(typeof settings.component, 'function');
assert.equal(typeof settings.options.label(), 'string', 'the settings page needs a nav label');
assert.deepEqual(requiredNames, ['react']);

// The panel must actually build its element tree: a render fault is invisible to
// every check above, and a lossy re-encode of the client half shows up here.
const collectNodes = (root, nodes = []) => {
  const walk = (node) => {
    if (node === null || node === undefined) return;
    if (Array.isArray(node)) { node.forEach(walk); return; }
    if (typeof node !== 'object') return;
    nodes.push(node);
    // This stub React does not expand function components, so call them: the tree
    // we inspect must be the one a browser would build.
    if (typeof node.type === 'function') { walk(node.type(node.props)); return; }
    walk(node.children);
  };
  walk(root);
  return nodes;
};

/** Render the composer panel with one grade open; '' leaves every grade shut. */
const renderPanel = (grade) => {
  hookCells[2] = grade;
  hookCursor = 0;
  return collectNodes(composer.component({}));
};

const collapsed = renderPanel('');
assert.equal(
  collapsed.filter((node) => node.props.role === 'switch').length,
  0,
  'every grade starts collapsed, so no switch is on screen yet',
);
const gradeHeaders = collapsed.filter(
  (node) => node.props['aria-expanded'] !== undefined && node.props.style?.width === '100%',
);
assert.equal(gradeHeaders.length, 3, 'the collapsed panel lists exactly three grades');

// The panel renders the grades, not the mode list, so a mode missing from the
// grade table would vanish from the UI with no other symptom. Opening each grade
// in turn must therefore surface every mode exactly once.
const labels = new Set();
let checkedCount = 0;
let switchesSeen = 0;
for (const grade of ['basic', 'medium', 'advanced']) {
  const opened = renderPanel(grade);
  const gradeSwitches = opened.filter((node) => node.props.role === 'switch');
  assert.ok(gradeSwitches.length > 0, `grade ${grade} must render its switches`);
  switchesSeen += gradeSwitches.length;
  for (const node of gradeSwitches) {
    labels.add(node.props['data-mode']);
    if (node.props['aria-checked'] === 'true') checkedCount += 1;
  }
}
assert.equal(labels.size, MODE_IDS.length, 'the three grades must cover every mode');
assert.deepEqual([...labels].sort(), [...MODE_IDS].sort(), 'no mode may be missing or duplicated');
assert.equal(switchesSeen, MODE_IDS.length, 'a mode must appear in exactly one grade');
assert.equal(
  checkedCount,
  getResponse.json.modes.filter((mode) => mode.on && mode.available !== false).length,
  'the switches must reflect the modes the route reported',
);

// The dock wrapper sizes to its content, so the panel surface needs a definite
// width; without one the rows collapse into an unusably narrow column.
const surface = renderPanel('basic').find((node) => String(node.props.style?.width ?? '').startsWith('min('));
assert.ok(surface !== undefined, 'the panel surface needs a definite width');
assert.ok(
  renderPanel('basic').some((node) => String(node.props.style?.justifyContent ?? '') === 'flex-end'),
  'an open grade must offer its one-click set-all control',
);

const panelCopy = JSON.stringify(collapsed.map((node) => node.children));
assert.ok(panelCopy.includes('初等') && panelCopy.includes('中等') && panelCopy.includes('高等'), 'the three grades carry their Chinese names');
assert.ok(panelCopy.includes('已开'), 'the panel copy must be the pinned Chinese text');
assert.ok(!panelCopy.includes('\uFFFD'), 'the panel copy must not contain replacement characters');

// The settings page renders the host's running record, including the per-tool
// breakdown: an empty or faulting render would leave the whole feature invisible.
hookCells = [{
  session: {
    calls: 4, rewritten: 3, elided: 1, before: 20000, after: 8000,
    savedChars: 12, savedTokens: 3, savedRatio: 0.6, spillFailures: 0,
    catalogueTools: 0, catalogueTokens: 0, recallInjections: 0, recallChars: 0,
  },
  cumulative: {
    calls: 4, rewritten: 3, elided: 1, before: 20000, after: 8000,
    savedChars: 12000, savedTokens: 3000, savedRatio: 0.6, spillFailures: 1,
    catalogueTools: 2, catalogueTokens: 900, recallInjections: 1, recallChars: 300,
  },
  tools: [{ tool: 'read', calls: 3, rewritten: 3, elided: 1, savedChars: 12000, savedTokens: 3000, savedRatio: 1 }],
  statsFile: 'C:/profile/dsh-token-frugal.stats.json',
  generatedAt: '2026-01-02T03:04:05.000Z',
}, '', '', ''];
hookCursor = 0;
const pageNodes = collectNodes(settings.component({}));
const pageText = JSON.stringify(pageNodes.map((node) => node.children));
assert.ok(pageText.includes('省 Token 统计'), 'the settings page must carry its Chinese title');
assert.ok(pageText.includes('read'), 'the per-tool table must render its rows');
assert.ok(pageText.includes('12.0k'), 'large counts must be compacted, not printed raw');
assert.ok(pageText.includes('C:/profile/dsh-token-frugal.stats.json'), 'the page must name its statistics file');
assert.ok(!pageText.includes('\uFFFD'), 'the settings copy must not contain replacement characters');
assert.ok(!readFileSync(join(ROOT, 'client.js'), 'utf8').includes('\uFFFD'), 'client.js must stay valid UTF-8');

// The Theme provider exposes a fixed token set and nothing else. An invented
// variable renders as no colour at all: invisible in a stub render, and obvious
// to the user as a switch or a bar that has no background.
const THEME_TOKENS = [
  '--dsw-alias-bg-base', '--dsw-alias-bg-layer-1', '--dsw-alias-bg-layer-2',
  '--dsw-alias-bg-overlay', '--dsw-alias-border-l1', '--dsw-alias-border-l2',
  '--dsw-alias-brand-primary', '--dsw-alias-label-primary', '--dsw-alias-label-secondary',
  '--dsw-alias-state-error-primary', '--dsw-alias-state-idle-primary', '--dsw-alias-state-success-primary',
];
const usedTokens = [
  ...new Set(
    [...readFileSync(join(ROOT, 'client.js'), 'utf8').matchAll(/var\((--[a-z0-9-]+)\)/g)].map((match) => match[1]),
  ),
];
assert.ok(usedTokens.length > 0, 'the client half must colour itself from theme tokens');
for (const token of usedTokens) {
  assert.ok(THEME_TOKENS.includes(token), `client.js uses ${token}, which the Theme provider does not expose`);
}
console.log(`client theme ok: ${usedTokens.length} tokens, every one declared by the Theme provider`);
console.log(`client settings page ok: ${pageNodes.length} nodes rendered`);
console.log(`client panel ok: ${MODE_IDS.length} modes across ${gradeHeaders.length} grades, Chinese copy intact`);
console.log(`client half ok: id=${loadedModule.id} slots=${registrations.map((entry) => entry.options.name).join('+')}`);

rmSync(workspace, { recursive: true, force: true });
console.log('\nLOAD CHECK PASSED');
