/**
 * Simplified Chinese dictionary for the vision plugin.
 */
export const zh = {
  'section.nav': '识图模型配置',
  'section.title': '识图模型配置',
  'section.description': '配置图片识别所使用的视觉模型参数',

  'loading': '正在加载识图配置…',
  'unavailable': '无法读取识图配置：设置命名空间未注册，或当前连接为只读',

  'enabled.label': '启用图片识别',
  'enabled.description': '开启后，AI 可以识别并理解用户上传的图片内容',

  'model.baseUrl': 'Base URL',
  'model.baseUrl.placeholder': 'https://api.example.com/v1',
  'model.baseUrl.description': '视觉模型 API 的基础地址',

  'model.modelId': 'Model ID',
  'model.modelId.placeholder': 'gpt-4o-vision-preview',
  'model.modelId.description': '用于视觉任务的模型标识符',

  'model.fallbackModelId': '备用模型（可选）',
  'model.fallbackModelId.placeholder': 'qwen/qwen3.8-flash',
  'model.fallbackModelId.description': '主模型遇 429 限流/5xx 且重试耗尽后自动切换的备用模型；留空则只使用主模型（OpenRouter 等聚合平台常因上游限流需要备用模型）',

  'model.maxRetries': '重试次数',
  'model.maxRetries.description': '遇到 429 限流、5xx 或网络错误时的指数退避重试次数（0–10，默认 3），会遵循服务端 Retry-After',

  'test.button': '测试连接',
  'test.testing': '正在测试连接…',
  'test.hint': '保存前会自动用当前配置测试连通性与图片支持，也可点此手动测试。只有配置类错误（地址/模型错误、密钥无效、模型不支持图片）才阻止保存；429/5xx 等临时错误仍可保存。',
  'test.ok': '测试通过',
  'test.warn': '测试未完全通过（仍可保存）',
  'test.blocked': '测试未通过，已阻止保存',

  'model.apiKey': 'API Key',
  'model.apiKey.placeholder': 'sk-xxxxxxxxxxxxxxxx',
  'model.apiKey.description': 'API 密钥（敏感信息，请妥善保管）。识图请求只使用这一处填写的密钥——留空时不会复用其它路由的密钥，而是明确提示「未携带 API Key」',
  'model.keyFormat': '密钥格式',
  'model.keyFormat.description': '密钥的鉴权方式，必须与密钥所属服务商匹配：openai=Authorization: Bearer（OpenAI / OpenRouter / ARK / DeepSeek 及多数兼容网关）；anthropic=x-api-key；gemini=x-goog-api-key；azure=api-key',
  'format.openai': 'OpenAI 格式（Authorization: Bearer）',
  'format.anthropic': 'Anthropic（x-api-key）',
  'format.gemini': 'Gemini（x-goog-api-key）',
  'format.azure': 'Azure / api-key（api-key）',

  'save': '保存',
  'saving': '保存中...',
  'saved': '已保存',
  'saveFailed': '保存失败：配置未写入（多为页面持有的配置版本已过期），请重试或刷新页面后再保存',
  'discard': '放弃修改',
  'readOnly': '当前环境为只读，无法保存配置',
  'unsaved': '有未保存的修改',
  'collapse': '收起',
  'expand': '展开',

  'validation.required': '此项为必填',
  'validation.invalidUrl': '请输入有效的 URL 地址',
} satisfies Record<string, string>

export type VisionPluginKey = keyof typeof zh

export const en: Record<VisionPluginKey, string> = {
  'section.nav': 'Vision Model Config',
  'section.title': 'Vision Model Configuration',
  'section.description': 'Configure vision model parameters for image recognition',

  'loading': 'Loading vision settings…',
  'unavailable': 'Vision settings are unavailable: the namespace is not registered or this connection is read-only',

  'enabled.label': 'Enable Image Recognition',
  'enabled.description': 'When enabled, AI can recognize and understand uploaded images',

  'model.baseUrl': 'Base URL',
  'model.baseUrl.placeholder': 'https://api.example.com/v1',
  'model.baseUrl.description': 'Base URL of the vision model API',

  'model.modelId': 'Model ID',
  'model.modelId.placeholder': 'gpt-4o-vision-preview',
  'model.modelId.description': 'Model identifier for vision tasks',

  'model.fallbackModelId': 'Fallback Model (optional)',
  'model.fallbackModelId.placeholder': 'qwen/qwen3.8-flash',
  'model.fallbackModelId.description': 'Used when the primary model keeps failing with transient errors (429/5xx) after retries; empty means primary only (aggregators like OpenRouter often need a fallback due to upstream rate limits)',

  'model.maxRetries': 'Retries',
  'model.maxRetries.description': 'Exponential-backoff retries for 429 rate limits, 5xx or network errors (0-10, default 3); honors the server Retry-After header',

  'test.button': 'Test connection',
  'test.testing': 'Testing connection…',
  'test.hint': 'A connectivity & image-support check runs automatically with the current draft config before saving; you can also run it manually here. Only real config errors (bad URL/model, invalid key, model without image support) block the save — transient 429/5xx still save.',
  'test.ok': 'Test passed',
  'test.warn': 'Test not fully passed (save still allowed)',
  'test.blocked': 'Test failed — save blocked',

  'model.apiKey': 'API Key',
  'model.apiKey.placeholder': 'sk-xxxxxxxxxxxxxxxx',
  'model.apiKey.description': 'API key (sensitive information, handle with care). This is the ONLY key source for image requests — an empty field is reported as 未携带 API Key instead of reusing another route\u2019s credential',
  'model.keyFormat': 'Key format',
  'model.keyFormat.description': 'How the key is presented; it must match the key\u2019s provider: openai=Authorization: Bearer (OpenAI / OpenRouter / ARK / DeepSeek and most compatible gateways); anthropic=x-api-key; gemini=x-goog-api-key; azure=api-key',
  'format.openai': 'OpenAI (Authorization: Bearer)',
  'format.anthropic': 'Anthropic (x-api-key)',
  'format.gemini': 'Gemini (x-goog-api-key)',
  'format.azure': 'Azure / api-key (api-key)',

  'save': 'Save',
  'saving': 'Saving...',
  'saved': 'Saved',
  'saveFailed': 'Save failed: the settings document did not accept the write (this page usually holds a stale revision). Retry, or refresh the page and save again.',
  'discard': 'Discard',
  'readOnly': 'Read-only environment, cannot save configuration',
  'unsaved': 'Unsaved changes',
  'collapse': 'Collapse',
  'expand': 'Expand',

  'validation.required': 'This field is required',
  'validation.invalidUrl': 'Please enter a valid URL',
}
