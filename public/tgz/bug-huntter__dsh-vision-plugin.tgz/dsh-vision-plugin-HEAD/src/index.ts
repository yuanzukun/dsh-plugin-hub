/**
 * Host-side entry for the vision plugin: registers the settings namespace and,
 * while image recognition is enabled, routes image content through the
 * configured vision model.
 *
 * A deployment's main model may be text-only, so sending raw images fails
 * upstream (the provider answers 404 "no endpoints that support image input").
 * The plugin therefore does two things while `enabled` is on:
 *
 * 1. Capability advertisement: patches the shared `llm` service so its model
 *    capability queries report `image` support, which is what admits inbound
 *    images past the host's image-admission guard on any model.
 * 2. Image transcription: the request boundary is patched so that, BEFORE
 *    the `llm/stream` waterfall, every image block of a user message is
 *    replaced by a text transcription produced by the configured vision model
 *    (one OpenAI-compatible chat-completions call per image), and the main
 *    model only ever sees text.
 *
 * When disabled, the capability patch is restored and no transcription runs;
 * a model that natively declares multimodal input passes images through as-is.
 */
import z from '@deepseek-ai/schemastery'
import { symbols } from '@deepseek-ai/cordis'
import type {
  ContentBlock,
  GenerateOptions,
  LlmRuntime,
  LlmResolvedModelInfo,
  Message,
  StreamChunk,
} from '@deepseek-ai/dsh-llm'
import type { Context } from '@deepseek-ai/cordis'
import { VISION_PLUGIN_NAMESPACE } from './constants.ts'
import { authHeaders, DEFAULT_KEY_FORMAT, normalizeKeyFormat, type KeyFormat } from './authHeaders.ts'
import { resolveVisionKey, type VisionKeyResolution } from './keyResolution.ts'
import { booleanSetting, numberSetting, stringSetting } from './settingsValue.ts'

export interface VisionPluginSettings {
  /** Whether image recognition is enabled. */
  enabled: boolean
  /** Base URL of the vision model API (OpenAI-compatible). */
  baseUrl: string
  /** Model identifier to use for vision tasks. */
  modelId: string
  /**
   * The API key used for image transcription — the ONLY key source (v1.2.0).
   * An empty value is reported as `未携带 API Key`; it is never substituted by
   * a credential belonging to another LLM route.
   */
  apiKey: string
  /**
   * How the API key is presented to the provider: `openai` (Authorization:
   * Bearer — OpenAI, OpenRouter, ARK, DeepSeek and most compatible gateways),
   * `anthropic` (x-api-key + anthropic-version), `gemini` (x-goog-api-key), or
   * `azure` (api-key). Must match the key's own provider.
   */
  keyFormat: KeyFormat
  /** Optional override of the transcription instruction sent with each image. */
  prompt?: string
  /** Transcription request timeout in milliseconds. */
  timeoutMs?: number
  /**
   * Exponential-backoff retry count for transient failures (HTTP 429 / 5xx /
   * network errors). Default 3, clamped to 0..10.
   */
  maxRetries?: number
  /**
   * Optional fallback model id. When the primary model keeps failing with
   * transient errors (429 / 5xx) after `maxRetries`, one final attempt is made
   * with this model (e.g. an aggregator's free tier getting rate-limited is a
   * common reason to set this). Empty means no fallback.
   */
  fallbackModelId?: string
}

const VisionPluginSettingsSchema: z<VisionPluginSettings> = z.object({
  enabled: z.boolean().default(false).volatile(),
  baseUrl: z.string().default('').volatile(),
  modelId: z.string().default('').volatile(),
  apiKey: z.string().default('').volatile(),
  // A plain string, normalized at use: a hand-edited settings.yaml typo then
  // degrades to the default instead of failing namespace validation (which
  // would reject every later write with `settings/rejected`).
  keyFormat: z.string().default(DEFAULT_KEY_FORMAT).volatile(),
  prompt: z.string().default('').volatile(),
  timeoutMs: z.number().default(120000).volatile(),
  maxRetries: z.number().min(0).default(3).volatile(),
  fallbackModelId: z.string().default('').volatile(),
})

/**
 * 0.1.7 settings contract: the profile entry's Config schema IS the settings
 * namespace schema. Exporting it under `Config` makes the `vision-plugin`
 * profile entry a configurable form (describe/mutate) for the client card.
 */
export const Config: z<VisionPluginSettings> = VisionPluginSettingsSchema

function normalizeVisionSettings(settings: VisionPluginSettings): VisionPluginSettings {
  return {
    enabled: booleanSetting(settings.enabled),
    baseUrl: stringSetting(settings.baseUrl),
    modelId: stringSetting(settings.modelId),
    apiKey: stringSetting(settings.apiKey),
    keyFormat: normalizeKeyFormat(stringSetting(settings.keyFormat)),
    prompt: stringSetting(settings.prompt),
    timeoutMs: numberSetting(settings.timeoutMs, 120000),
    maxRetries: numberSetting(settings.maxRetries, 3),
    fallbackModelId: stringSetting(settings.fallbackModelId),
  }
}

/** Base delay (ms) for the first exponential-backoff wait on a transient error. */
const RETRY_BASE_DELAY_MS = 1000
/** Upper bound (ms) for any single retry wait, also used to cap Retry-After. */
const RETRY_MAX_DELAY_MS = 30_000
/** Upper bound for the configurable retry count. */
const RETRY_COUNT_CAP = 10

const DEFAULT_TRANSCRIBE_PROMPT =
  'Transcribe and describe this image faithfully. Include all visible text verbatim (OCR). '
  + 'Then briefly describe any other relevant content such as diagrams, charts, UI elements, people, or the scene. '
  + 'Reply with only the transcription and description, without preamble.'

/**
 * Notice used when no API key is configured. This is the one failure the plugin
 * can name exactly, so it never sends an unauthenticated request (which would
 * come back as a provider-specific 401 the user cannot act on).
 */
function missingKeyMessage(keyFormat: KeyFormat): string {
  return `未携带 API Key：请在 设置 → 识图模型配置 的「API Key」字段填写密钥`
    + `（当前密钥格式：${keyFormat}，如与密钥不匹配请在同页切换）`
}

const TRANSCRIPTION_PREFIX = '[Image transcription]'

type Modality = 'text' | 'image' | 'audio'
function withImage(modalities: readonly Modality[] | undefined): Modality[] | undefined {
  if (modalities === undefined || modalities.includes('image')) return modalities
  return [...modalities, 'image']
}

function errorMessage(value: unknown): string {
  if (!(value instanceof Error)) return String(value)
  const cause = value.cause as { code?: unknown; errno?: unknown; syscall?: unknown; address?: unknown; port?: unknown } | undefined
  const causeParts = cause === undefined ? [] : [
    typeof cause.code === 'string' ? `code=${cause.code}` : undefined,
    typeof cause.errno === 'string' || typeof cause.errno === 'number' ? `errno=${cause.errno}` : undefined,
    typeof cause.syscall === 'string' ? `syscall=${cause.syscall}` : undefined,
    typeof cause.address === 'string' ? `address=${cause.address}` : undefined,
    typeof cause.port === 'number' ? `port=${cause.port}` : undefined,
  ].filter((part): part is string => part !== undefined)
  return causeParts.length === 0 ? value.message : `${value.message} (${causeParts.join(', ')})`
}

/** The host logger, when the runtime exposes one. */
function visionLogger(ctx: Context): {
  error(message: string, ...args: unknown[]): void
  info?(message: string, ...args: unknown[]): void
} | undefined {
  return (ctx as {
    logger?: {
      error(message: string, ...args: unknown[]): void
      info?(message: string, ...args: unknown[]): void
    }
  }).logger
}

function messageHasImage(content: readonly ContentBlock[]): boolean {
  return content.some((block): boolean => {
    if (block.type === 'image') return true
    if (block.type === 'tool-result') return messageHasImage((block as { content: readonly ContentBlock[] }).content)
    return false
  })
}

/** Durable image reference as stored in an image content block. */
interface ImageRef {
  attachmentId: string
  mediaType: string
  bytes: number
  width: number
  height: number
  name?: string
}

/** Collect the image references of one message in request order. */
function collectImageRefs(content: readonly ContentBlock[], out: ImageRef[]): void {
  for (const block of content) {
    if (block.type === 'image') {
      out.push(block.attachment as ImageRef)
      continue
    }
    if (block.type === 'tool-result' && (block as { content?: unknown }).content !== undefined) {
      collectImageRefs((block as { content: readonly ContentBlock[] }).content, out)
    }
  }
}

/**
 * Replace image blocks with text blocks. `nextTranscription` is called once per
 * image in request order and returns the replacement text; non-image blocks
 * pass through unchanged. Returns the original array when nothing changed.
 */
function mapBlocksReplacingImages(
  content: readonly ContentBlock[],
  nextTranscription: () => string,
): ContentBlock[] | undefined {
  let changed = false
  const result: ContentBlock[] = []
  for (const block of content) {
    if (block.type === 'image') {
      result.push({ type: 'text', text: nextTranscription() })
      changed = true
    } else if (block.type === 'tool-result' && (block as { content?: unknown }).content !== undefined) {
      const inner = mapBlocksReplacingImages(
        (block as { content: readonly ContentBlock[] }).content,
        nextTranscription,
      )
      if (inner === undefined) {
        result.push(block)
      } else {
        result.push({ ...(block as object), content: inner } as ContentBlock)
        changed = true
      }
    } else {
      result.push(block)
    }
  }
  return changed ? result : undefined
}

function rewriteMessagesReplacingImages(
  messages: readonly Message[],
  nextTranscription: () => string,
): Message[] {
  let changed = false
  const result: Message[] = []
  for (const message of messages) {
    const content = mapBlocksReplacingImages(message.content, nextTranscription)
    if (content === undefined) {
      result.push(message)
      continue
    }
    changed = true
    result.push({ ...message, content })
  }
  return changed ? result : [...messages]
}

function requestNeedsTranscription(
  settings: VisionPluginSettings,
  messages: readonly Message[],
): boolean {
  const resolved = normalizeVisionSettings(settings)
  return resolved.enabled
    && resolved.baseUrl.trim().length > 0
    && resolved.modelId.trim().length > 0
    && messages.some((message) => messageHasImage(message.content))
}

function fallbackRequest(
  ctx: Context,
  options: GenerateOptions,
  error: unknown,
): GenerateOptions {
  const detail = errorMessage(error)
  const hint = hintOf(error)
  visionLogger(ctx)?.error(
    `vision-plugin: image transcription failed; continuing with a text placeholder: ${detail}${hint}`,
  )
  const notice = `[图片转写失败：${detail.slice(0, 200)}${hint}——该图片未传递给模型]`
  return {
    ...options,
    messages: rewriteMessagesReplacingImages(options.messages, () => notice),
  }
}

async function transcribeRequest(
  ctx: Context,
  settings: VisionPluginSettings,
  options: GenerateOptions,
): Promise<GenerateOptions> {
  const resolvedSettings = normalizeVisionSettings(settings)
  const attachments = ctx.get('attachments') as {
    readImage: (ref: ImageRef, signal?: AbortSignal) => Promise<{ data: Uint8Array }>
  } | undefined
  if (attachments === undefined) {
    throw new Error('vision-plugin: durable attachment service is unavailable')
  }
  const refs: ImageRef[] = []
  for (const message of options.messages) collectImageRefs(message.content, refs)
  if (refs.length === 0) return options
  const resolution = resolveVisionKey(resolvedSettings)
  if (resolution.source === 'none') {
    visionLogger(ctx)?.error(
      `vision-plugin: image transcription skipped — ${missingKeyMessage(resolvedSettings.keyFormat)}`,
    )
  }
  const transcriptions = await Promise.all(refs.map(async (ref) => {
    const stored = await attachments.readImage(ref, options.signal)
    return transcribeImage(stored.data, ref.mediaType, resolution, resolvedSettings, options.signal)
  }))
  let cursor = 0
  const nextTranscription = (): string => {
    const text = transcriptions[cursor]
    if (text === undefined) throw new Error('vision transcription queue exhausted')
    cursor += 1
    return `${TRANSCRIPTION_PREFIX}\n${text}`
  }
  return {
    ...options,
    messages: rewriteMessagesReplacingImages(options.messages, nextTranscription),
  }
}

type StreamMethod = (options: GenerateOptions, prepared?: unknown) => AsyncIterable<StreamChunk>

interface MethodPatch {
  target: object
  descriptor: PropertyDescriptor
  original: (...args: unknown[]) => unknown
}

function methodPatch(instance: object, name: string): MethodPatch | undefined {
  const prototype = Object.getPrototypeOf(instance) as object | null
  const ownDescriptor = Object.getOwnPropertyDescriptor(instance, name)
  const prototypeDescriptor = prototype === null
    ? undefined
    : Object.getOwnPropertyDescriptor(prototype, name)
  const descriptor = ownDescriptor ?? prototypeDescriptor
  const original = descriptor?.value
  if (typeof original !== 'function') return undefined
  return {
    target: ownDescriptor === undefined && prototypeDescriptor !== undefined ? prototype : instance,
    descriptor,
    original,
  }
}

function abortedChunk(): StreamChunk {
  return {
    type: 'finish',
    reason: { kind: 'aborted', failure: { message: 'aborted', code: 'ABORTED' } },
  } as StreamChunk
}

/** Error carrying the HTTP status (and Retry-After) of a failed transcription request. */
interface VisionHttpError extends Error {
  status?: number
  retryAfterSeconds?: number
  /**
   * Actionable, user-facing hint for this failure. Kept beside the message
   * instead of appended to it, because the notice that replaces a failed image
   * truncates the message (and a long provider body would swallow the hint).
   */
  hint?: string
}

/** Attach a user-facing hint to a failed request without bloating its message. */
function withHint<T>(error: T, hint: string): T {
  if (hint.length > 0 && error instanceof Error) (error as { hint?: string }).hint = hint
  return error
}

/** The user-facing hint carried by a failed request, if any. */
function hintOf(error: unknown): string {
  const hint = (error as { hint?: unknown })?.hint
  return typeof hint === 'string' ? hint : ''
}

function visionHttpError(status: number, body: string, retryAfterSeconds?: number): VisionHttpError {
  const error = new Error(`vision model request failed with HTTP ${status}: ${body.slice(0, 300)}`) as VisionHttpError
  error.status = status
  if (retryAfterSeconds !== undefined) error.retryAfterSeconds = retryAfterSeconds
  return error
}

/** Transient statuses worth retrying: 429 (rate limited) and 5xx (upstream). */
function isRetryableStatus(status: number): boolean {
  return status === 429 || status >= 500
}

/** Whether `error` is the per-request timeout abort (as opposed to the caller's own abort). */
function isAbortSignalError(error: unknown): boolean {
  return error instanceof DOMException && error.name === 'AbortError'
}

/** Parse a `Retry-After` header (seconds form; HTTP-date form falls back to undefined). */
function parseRetryAfterSeconds(header: string | null): number | undefined {
  if (header === null) return undefined
  const seconds = Number(header)
  return Number.isFinite(seconds) && seconds >= 0 ? seconds : undefined
}

/** Compute the wait before the next attempt: Retry-After when present, else exponential backoff + jitter. */
function retryDelayMs(error: unknown, attempt: number): number {
  const retryAfter = (error as { retryAfterSeconds?: number })?.retryAfterSeconds
  if (typeof retryAfter === 'number' && Number.isFinite(retryAfter) && retryAfter > 0) {
    return Math.min(retryAfter * 1000, RETRY_MAX_DELAY_MS)
  }
  const base = RETRY_BASE_DELAY_MS * 2 ** Math.min(attempt, 6)
  return Math.min(base + Math.floor(Math.random() * base * 0.25), RETRY_MAX_DELAY_MS)
}

/** Abortable sleep used between attempts. */
function sleep(ms: number, signal: AbortSignal | undefined): Promise<void> {
  if (signal?.aborted === true) return Promise.reject(new DOMException('The operation was aborted.', 'AbortError'))
  return new Promise((resolve, reject) => {
    const timer = setTimeout(resolve, ms)
    const onAbort = (): void => {
      clearTimeout(timer)
      reject(new DOMException('The operation was aborted.', 'AbortError'))
    }
    signal?.addEventListener('abort', onAbort, { once: true })
    void timer.unref?.()
  })
}

/**
 * Transcribe one image through the configured vision model (OpenAI-compatible
 * `POST {baseUrl}/chat/completions`). Transient failures — HTTP 429 / 5xx and
 * network errors — are retried with exponential backoff (honoring
 * `Retry-After`) up to `settings.maxRetries` times; when a `fallbackModelId`
 * is configured and the primary model still fails transiently, one final
 * attempt is made with the fallback model. The caller's abort signal is
 * honored at every step.
 */
async function transcribeImage(
  data: Uint8Array,
  mediaType: string,
  resolution: VisionKeyResolution,
  settings: VisionPluginSettings,
  signal: AbortSignal | undefined,
): Promise<string> {
  settings = normalizeVisionSettings(settings)
  const apiKey = resolution.key
  const keyFormat = normalizeKeyFormat(settings.keyFormat)
  // Fail fast, before any network I/O: with a single, visible key source there
  // is nothing to guess, and the notice can name the exact field to fill.
  if (apiKey.length === 0) throw new Error(missingKeyMessage(keyFormat))
  const base = settings.baseUrl.replace(/\/+$/, '')
  if (base.length === 0) {
    throw new Error('vision-plugin: no Base URL configured — set it in 设置 → 识图模型配置')
  }
  const primary = settings.modelId.trim()
  if (primary.length === 0) {
    throw new Error('vision-plugin: no Model ID configured — set it in 设置 → 识图模型配置')
  }
  const fallback = settings.fallbackModelId?.trim() ?? ''
  const models = fallback.length > 0 ? [primary, fallback] : [primary]
  const url = `${base}/chat/completions`
  const dataUrl = `data:${mediaType};base64,${Buffer.from(data).toString('base64')}`
  const maxRetries = Math.max(0, Math.min(Math.floor(settings.maxRetries ?? 3), RETRY_COUNT_CAP))

  const attemptOnce = async (model: string): Promise<string> => {
    const timeoutController = new AbortController()
    const timeout = setTimeout(() => timeoutController.abort(), settings.timeoutMs ?? 120000)
    const wire = signal === undefined ? timeoutController.signal : AbortSignal.any([timeoutController.signal, signal])
    try {
      const headers: Record<string, string> = {
        'content-type': 'application/json',
        ...authHeaders(keyFormat, apiKey),
      }
      let response: Response
      try {
        response = await globalThis.fetch(url, {
          method: 'POST',
          headers,
          body: JSON.stringify({
            model,
            max_tokens: 4096,
            temperature: 0,
            messages: [{
              role: 'user',
              content: [
                { type: 'image_url', image_url: { url: dataUrl } },
                { type: 'text', text: settings.prompt?.trim() || DEFAULT_TRANSCRIBE_PROMPT },
              ],
            }],
          }),
          signal: wire,
        })
      } catch (error: unknown) {
        if (signal?.aborted === true) throw error
        if (isAbortSignalError(error)) {
          // Per-attempt timeout: turn it into an ordinary transient error so
          // the retry loop can decide, instead of surfacing an AbortError.
          throw new Error(`vision model request timed out after ${settings.timeoutMs ?? 120000}ms`, { cause: error })
        }
        throw new Error(`vision model fetch failed for ${url}: ${errorMessage(error)}`, { cause: error })
      }
      const body = await response.text()
      if (!response.ok) {
        throw visionHttpError(response.status, body, parseRetryAfterSeconds(response.headers.get('retry-after')))
      }
      const parsed: unknown = JSON.parse(body)
      const content: unknown = (parsed as { choices?: { message?: { content?: unknown } }[] })?.choices?.[0]?.message?.content
      const text = typeof content === 'string'
        ? content
        : Array.isArray(content)
          ? content.map((part) => (part as { text?: unknown })?.text ?? '').join('')
          : ''
      if (text.trim().length === 0) throw new Error('vision model returned an empty transcription')
      return text.trim()
    } finally {
      clearTimeout(timeout)
    }
  }

  /**
   * Hints for auth failures. An empty key never reaches the network (see the
   * fail-fast above), so a 401/403 here means the key we sent was refused —
   * which with a single visible key source points at the key itself or at a
   * format mismatch between the key and the 「密钥格式」 field.
   */
  const authHint = (status: number | undefined): string => {
    if (status !== 401 && status !== 403) return ''
    return `（提示：已按「${keyFormat}」格式携带 API Key 发出请求，但被服务端拒绝（HTTP ${status}）`
      + `——请确认 API Key 与「密钥格式」是否匹配、密钥是否有效/未欠费）`
  }

  let lastError: unknown
  for (const model of models) {
    for (let attempt = 0; attempt <= maxRetries; attempt++) {
      try {
        return await attemptOnce(model)
      } catch (error: unknown) {
        if (signal?.aborted === true || isAbortSignalError(error)) throw error
        lastError = error
        const status = (error as VisionHttpError)?.status
        const retryable = status === undefined ? true : isRetryableStatus(status)
        if (!retryable) throw withHint(error, authHint(status))
        if (attempt === maxRetries) break // move to the fallback model, or fail finally
        await sleep(retryDelayMs(error, attempt), signal)
      }
    }
  }
  const status = (lastError as VisionHttpError)?.status
  throw withHint(lastError, authHint(status))
}

/**
 * Patch the shared llm service so model capability queries report `image`
 * support while enabled; restore the originals (idempotently) when disabled or
 * on disposal. Reads of `ctx.llm` from other fibers re-resolve the same
 * instance each access, so the api-proxy's admission guard sees the patched
 * methods.
 */
function installImageGuardBypass(ctx: Context, settings: VisionPluginSettings, llm: LlmRuntime): void {
  const instance = llm[symbols.original] ?? llm
  const proto = Object.getPrototypeOf(instance)
  const originalResolve = Object.getOwnPropertyDescriptor(proto, 'resolveModelInfo')?.value
  if (typeof originalResolve !== 'function') return
  const originalList = Object.getOwnPropertyDescriptor(proto, 'listModels')?.value
  let active = false
  const activate = (): void => {
    if (active) return
    instance.resolveModelInfo = async (provider: string, model: string, signal?: AbortSignal): Promise<LlmResolvedModelInfo> => {
      const info = await originalResolve.call(instance, provider, model, signal)
      const modalities = withImage(info.inputModalities)
      return modalities === info.inputModalities ? info : { ...info, inputModalities: modalities }
    }
    if (typeof originalList === 'function') {
      instance.listModels = async (provider: string): Promise<readonly LlmResolvedModelInfo[]> => {
        const models = await originalList.call(instance, provider)
        return models.map((model) => {
          const modalities = withImage(model.inputModalities)
          return modalities === model.inputModalities ? model : { ...model, inputModalities: modalities }
        })
      }
    }
    active = true
  }
  const deactivate = (): void => {
    if (!active) return
    delete instance.resolveModelInfo
    if (typeof originalList === 'function') delete instance.listModels
    active = false
  }
  const apply = (enabled: boolean): void => { enabled ? activate() : deactivate() }
  apply(booleanSetting(settings.enabled))
}

  /**
   * Rewrite a request's image blocks into vision-model transcriptions, yielding
   * the downstream chunks of the rewritten request. The patch wraps the
   * runtime's private `streamWithRegistration` — the seam every `stream` call
   * passes BEFORE it dispatches the `llm/stream` waterfall — so the
   * agent-loop's request-reconstruction invariant (a waterfall listener that
   * compares options against the durable session log) still sees a matching
   * request, and no waterfall listener observes a raw image version of a
   * rewritten call. The original request object is never mutated; loop-built
   * requests arrive deep-frozen.
   */
function installImageTranscription(ctx: Context, settings: VisionPluginSettings, llm: LlmRuntime): void {
  const instance = llm[symbols.original] ?? llm
  const streamPatch = methodPatch(instance, 'streamWithRegistration')
  const adapterPatch = methodPatch(instance, 'adapterStream')
  if (streamPatch === undefined && adapterPatch === undefined) {
    visionLogger(ctx)?.error('vision-plugin: no compatible LLM stream boundary was found')
    return
  }

  const prepare = async (
    options: GenerateOptions,
  ): Promise<{ options: GenerateOptions; aborted: boolean }> => {
    if (!requestNeedsTranscription(settings, options.messages)) return { options, aborted: false }
    if (options.signal?.aborted === true) return { options, aborted: true }
    try {
      return { options: await transcribeRequest(ctx, settings, options), aborted: false }
    } catch (error: unknown) {
      if (options.signal?.aborted === true) return { options, aborted: true }
      return { options: fallbackRequest(ctx, options, error), aborted: false }
    }
  }

  const wrapStream = (patch: MethodPatch): StreamMethod => {
    const original = patch.original as StreamMethod
    return async function* (this: object, options: GenerateOptions, prepared?: unknown): AsyncGenerator<StreamChunk> {
      const preparedRequest = await prepare(options)
      if (preparedRequest.aborted) {
        yield abortedChunk()
        return
      }
      yield* original.call(this, preparedRequest.options, prepared)
    }
  }

  const wrapAdapterStream = (patch: MethodPatch): StreamMethod => {
    const original = patch.original as StreamMethod
    return async function* (this: object, options: GenerateOptions, prepared?: unknown): AsyncGenerator<StreamChunk> {
      const preparedRequest = await prepare(options)
      if (preparedRequest.aborted) {
        yield abortedChunk()
        return
      }
      yield* original.call(this, preparedRequest.options, prepared)
    }
  }

  ctx.effect(() => {
    const restores: (() => void)[] = []
    const install = (patch: MethodPatch | undefined, name: string, value: StreamMethod): void => {
      if (patch === undefined) return
      Object.defineProperty(patch.target, name, {
        value,
        writable: true,
        configurable: true,
      })
      restores.push(() => Object.defineProperty(patch.target, name, patch.descriptor))
    }
    if (streamPatch !== undefined) install(streamPatch, 'streamWithRegistration', wrapStream(streamPatch))
    if (adapterPatch !== undefined) install(adapterPatch, 'adapterStream', wrapAdapterStream(adapterPatch))
    return () => {
      for (const restore of restores.reverse()) restore()
    }
  }, 'vision-plugin: image transcription boundary')
}

  /**
   * Arm the vision pipeline. 0.1.7 settings contract: the namespace schema is
   * this module's exported `Config`; a settings save hot-reloads this entry and
   * re-runs apply with the fresh config, so `enabled` and every field are read
   * from the `config` argument directly (no runtime scope/watch needed).
   */
export function apply(ctx: Context, config: VisionPluginSettings): void {
    // Image pipeline: needs llm and the durable attachment reader. Wrapped in
    // try/catch so the UI remains usable and the error is logged even if the
    // runtime surface changes shape.
    ctx.inject(['llm', 'attachments'], (injectedCtx) => {
      try {
        const llm = injectedCtx.get('llm')
        installImageGuardBypass(injectedCtx, config, llm)
        installImageTranscription(injectedCtx, config, llm)
      } catch (error: unknown) {
        const logger = injectedCtx.logger ?? ctx.logger
        logger?.error('vision-plugin: failed to install image pipeline patches', error)
      }
    })

    // Expose the settings namespace to the web configuration boundary. Without
    // this registration the settings page can read the namespace (describe) but
    // every write is refused with "settings-not-exposed", which surfaces as
    // "保存失败，请重试". settingsNs must equal the profile entry id
    // (`vision-plugin`), matching the Config export above.
    ctx.inject(['llm'], (injectedCtx) => {
      const handle = injectedCtx.get('llm').registerConfigurableProviders([{
        provider: 'vision-plugin-settings',
        displayName: '识图模型配置',
        settingsNs: VISION_PLUGIN_NAMESPACE,
        settingsPath: [],
      }])
      injectedCtx.effect(() => handle, 'vision-plugin: settings namespace exposure')
    })
  }

const visionPlugin = Object.assign(apply, {
  Config: VisionPluginSettingsSchema,
})

export default visionPlugin

export { VISION_PLUGIN_NAMESPACE }




