# 官方 jobs 双层（DSH 0.2.2，ZB-129）

> 本文是 README 抽出的细节文档，记录「为什么镜像、怎么镜像、真机怎么验」。

0.2.2 之后 DSH 自带后台任务体系（`dsh-jobs` + `dsh-jobs-local` + `dsh-tool-jobs`）。
派发台**不接管**它，但**复用它**能提供的那部分价值 —— 两层职责清晰分开：

| 层 | 归属 | 内容 |
|---|---|---|
| **官方镜像层** | 官方 registry | 归属校验（job 只对发起会话可见/可停）、有界输出环（`outputLimitBytes`）、落地通知（含 0.2.2 `awaited` 抑制）、后台任务 UI 可见 |
| **派发台账层** | 派发台自己 | 跨进程 `jobs.json` 台账、文件锁闸与 FIFO、暂停分类（quota/not-logged-in/…）、降级链、`--resume` 续跑、用量聚合 |

### 为什么是"镜像"而不是"接管 registry"

读 `dsh-jobs-local` 源码后确认接管的 5 条硬冲突（这也是最初判定 P0「不适用」的依据）：

1. `start()` 要求 `owner` 是**活着的 agent**（`resolveOwner`），owner 销毁会 `cancel + 删记录`
   ⇒ 与派发台「关掉发起会话后任务继续跑」的核心价值直接冲突；
2. `owner: undefined` 虽避开 dispose，但 `dsh-tool-jobs` 对 unowned job **不产生通知** ⇒ 白拿不到落地唤醒；
3. unowned 会污染官方工具：`job_list` 把所有 unowned job 返给任意 caller、`job_kill` 也能直接操作 ⇒ 改变对外行为；
4. 官方 registry 是**进程内** `Map`，进程退出即丢，替代不了跨进程台账；
5. `start()` 前置 `servesOwner()` 依赖 bundle 组合里有 job controller，属"能跑但改 bundle 就静默失败"的耦合。

⇒ 结论：**通知与可见性借官方，账本与调度归自己**。落地通知因此**只有一份实现**（有镜像时由官方发，
派发台不重复发；无镜像时回退派发台通知）。

### 实现位置与开关

| 文件 | 作用 |
|---|---|
| `dispatch/official-jobs.mjs` | 镜像层：`mirror()` / `finish()` / `has()` / `stats()` / `dispose()`，全程只 warn 不抛 |
| `dispatch/notify.mjs` | `track()` 时尝试镜像；落地时 `official.finish()` 优先 —— 成功即**不再自己投递** |
| `dispatch/index.js` 配置字段 `officialJobs`（默认 `true`） | 关闭后完全不接触官方 registry，行为与 0.2.2 之前一致 |

语义映射（与官方逐条对齐）：

- 官方侧 `cancel()`（用户点 `job_kill` / 会话归档）⇒ 转成派发台 `dispatcher.kill()`（同一语义，台账照常走暂停分类）；
- 派发台 job 落地 ⇒ 补最后一屏尾部（≤12 行）进官方 ring，再 resolve `hooks.done`（`done`⇒`completed`，其余⇒`failed` + 一行人话 detail）；
- 状态迁移只播**状态行**（`[paused] exit=3`），不搬日志正文（避免把大日志灌进官方 ring 让模型侧读取变贵）。

测试：`dispatch/test/official-jobs-mirror.test.mjs`（33 项）＋ `dispatch/test/official-jobs-notify.test.mjs`（9 项），
覆盖注册参数、状态行、取消转 kill、结算 outcome、四类回退分支、幂等与卸载。

## 真机验证记录（2026-11-06）

### 正向：落地通知单源

| 官方任务 id | label | 说明 |
|---|---|---|
| `dispatch-be178c4548bb453e` | `codebuddy j-mw50val6-0-3099` | 首个镜像（只读核对任务） |
| `dispatch-018388ffcb9e4325` | `codebuddy j-mw50x3db-1-f064` | 第二个镜像（codebuddy shell 被拒，如实回报未伪造） |
| `dispatch-56649c87544f454f` | `codebuddy j-mw50xwiv-2-2a96` | 第三个镜像（被用户从 UI 停止） |

- 注册证据：宿主会话事件 `job/registered`，`kind=dispatch`、`label=<engine> j-<id>`。
- 账本 `dispatch/.data/state/wake-stats.json`：`delivered=0`、`officialDelivered=3`、
  `official={attempted:3, started:3, finished:3, failed:0, skipped:0}` ⇒ **通知全部由官方发出，派发台零重复投递**。

### 反向：官方停止 → 派发台 kill

- 官方 `dispatch-56649c87544f454f` 被停止后结算为 `status=failed`，
  detail=`派发台 job j-mw50xwiv-2-2a96 落地：killed，exit=1`（镜像 `outcomeOf()` 写入）。
- 派发台账：`state=killed`、`exitCode=1`、运行 51s 后停下。
- 镜像层计数 `official.cancelled=1` ⇒ `cancel()` → `dispatcher.kill()` 转译确实执行。
- 有界输出环内容完整（初始镜像行 + tail 行），未被取消破坏。

### 一处判读修正（记录在案）

台账 schema **没有** `killReason` 字段 —— 取消的痕迹是 `official.cancelled=1` + `state=killed`，
不是某个 reason 字符串。核对时请按这两个字段，不要按不存在的字段找。

### 附带观察（非缺陷）

用户主动停止仍会收到**一条**官方落地通知 —— 符合官方语义：`awaited` 抑制只针对"结果已被调用方收走"，
用户主动停是新事件，应当通知。
