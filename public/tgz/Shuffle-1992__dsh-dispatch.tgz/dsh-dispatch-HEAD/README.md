# DSH 派发台（dispatch）

> [DeepSeek Harness](https://github.com/deepseek-ai/deepseek-harness)（DSH）插件：
> 把任务派发给本机 **四个 AI 编程 CLI**（ZCode / OpenCode / Qoder / WorkBuddy）的无头进程，
> 并在页面右下角悬浮面板里监视它们。

DSH 自带的 `subagent` 跑的是 DSH 自己的 agent；**本插件跑的是你自己的 CLI** —— 独立进程、
独立额度、独立会话。任务可查输出、可终止、可续跑、可换通道重跑。

## 能力

| 能力 | 说明 |
|---|---|
| **四引擎派发** | 全部走**官方 CLI**（不反代、不模拟兼容接口、不读写凭据内容）；引擎**自动发现**，无需手填路径 |
| **单写者互斥** | `repo` / 文件锁 + 进程内 FIFO：同锁任务串行，冲突只排队不报错 |
| **实时监视** | 状态、耗时、Token 用量、上下文占用、积分/费用、退出码、锁持有者，可 tail 输出 |
| **续跑 / 重跑** | 同会话 `--resume`（仅 ZCode），或发新指令 |
| **通道与降级链** | 切通道/模型/思考强度；额度耗尽按降级链自动交接重跑；支持分流模式叠加并发 |
| **思考强度核对** | 记录请求档位 vs 实际生效档位，不符时给向上改档建议 |
| **用量聚合** | 本地台账 5 小时滚动 / 本周 / 今日 + 套餐剩余额度 |
| **派发总开关** | 跨会话真值文件：`false` = 任何会话都不得派发 |
| **agent 工具** | 注册 `dispatch` 工具，与面板共用同一套动作实现 |
| **落地自动唤醒** | 任务落地自动唤醒发起会话（与 DSH 后台任务同款） |
| **官方 jobs 镜像**（0.2.2） | run 同时镜像成官方后台任务：借用归属校验 / 有界输出环 / 落地通知 / UI 可见；通知只由官方发一份，镜像失败自动回退。见 [官方 jobs 双层](docs/official-jobs.md) |

## 安装

```bash
dsh plugin --profile <你的profile> add "github:Shuffle-1992/dsh-dispatch#path:dispatch"
```

> `#path:dispatch` **不能省** —— 本仓库是 monorepo，插件本体在 `dispatch/` 子目录。

配置（`runnerPath` / `workRoot` 任一为空则不创建 dispatcher，面板走 demo 降级）：
机器专有路径放 `~/.dsh/profiles/<profile>/cordis.patch.yml`，按 id 覆盖。字段全表见 [安装与配置](docs/install.md)。

## 文档

| 你想了解 | 文档 |
|---|---|
| 安装、配置字段全表、常见问题 | [docs/install.md](docs/install.md) |
| 四个引擎的能力/额度、为什么走官方 CLI | [docs/engines.md](docs/engines.md) |
| 面板与工具动作、派发优先级硬规则 | [docs/usage.md](docs/usage.md) |
| 官方 jobs 双层（镜像/回退/真机验证记录） | [docs/official-jobs.md](docs/official-jobs.md) |
| 架构、目录结构、设计取舍 | [docs/architecture.md](docs/architecture.md) |
| 凭据与 401 排查 | [docs/credentials.md](docs/credentials.md) |
| 引擎协议细节与验收清单 | [dispatch/teaching.md](dispatch/teaching.md) |
| 真机踩坑总账（问题排查先查它） | [pitfalls.md](pitfalls.md) |
| DSH 兼容性审查 / 历史审查留档 | [docs/DSH-0.2.1-COMPAT-REVIEW.md](docs/DSH-0.2.1-COMPAT-REVIEW.md)、[docs/](docs/) |

## 许可

MIT（见 [LICENSE](LICENSE)）。`refs/` 下第三方材料沿用其各自许可，详见
[架构文档的第三方材料声明](docs/architecture.md#第三方材料声明)。
