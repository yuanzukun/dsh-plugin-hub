/**
 * ZB-129 回归：官方 jobs 镜像层（`dispatch/official-jobs.mjs`）。
 *
 * 覆盖的行为契约（每条都对应一个真实回退分支）：
 *   ① 镜像时把 kind/label/owner/outputLimitBytes 交给官方 `jobs.start()`
 *   ② `run()` 同步返回 `{ done, cancel }`；初始状态行进 ring
 *   ③ 派发台状态迁移只播状态行（不搬日志正文）
 *   ④ 官方侧 `cancel()` → 转成派发台 `dispatcher.kill()`（不私改台账）
 *   ⑤ `finish()` 补最后一屏 + resolve outcome（done ⇒ completed，其余 ⇒ failed）
 *   ⑥ 无 `jobs` 服务 / 无 owner / 官方 start 抛错 ⇒ 返回 false（派发台通知兜底）
 *   ⑦ 幂等：同 job 重复 mirror 不重复 start；finish 重复调用无副作用
 *   ⑧ `dispose()` 释放订阅并按失败结算残留
 */
import { DEFAULT_OUTPUT_LIMIT_BYTES, OFFICIAL_KIND, createOfficialJobs } from '../official-jobs.mjs';

let checks = 0, failures = 0;
/** 等一轮微任务：官方 hooks.done 的 then 在微任务里跑。 */
const flush = () => new Promise((r) => setTimeout(r, 0));
function ok(name, cond, extra = '') {
  checks += 1;
  if (cond) console.log(`  ✅ ${name}`);
  else { failures += 1; console.log(`  ❌ ${name}${extra ? `（${extra}）` : ''}`); }
}

/** 假官方 registry：记录 start 的 spec，暴露 handle 供测试驱动。 */
function mkJobs({ throwOnStart = null } = {}) {
  const started = [];
  return {
    started,
    start(spec) {
      if (throwOnStart) throw new Error(throwOnStart);
      const rec = { spec, appends: [], handle: null };
      started.push(rec);
      // 官方 start 会**同步**调用 run(spec) —— 契约如此，测试据此断言同步性
      rec.hooks = spec.run({
        append(text) { rec.appends.push(String(text)); },
        updateProgress() {},
      });
      rec.handle = rec.hooks;
      return `dispatch-${String(started.length).padStart(16, '0')}`;
    },
  };
}

/** 假调度器：可编程事件流 + get/tail/kill。 */
function mkDispatcher({ job = { id: 'j1', state: 'running', engine: 'zcode' }, tailLines = ['out line'], tailThrows = false } = {}) {
  const subs = new Set();
  const calls = { kill: [], get: 0, tail: [] };
  return {
    calls,
    get(id) { calls.get += 1; return id === job.id ? { ...job } : null; },
    tail(id, n) { calls.tail.push([id, n]); if (tailThrows) throw new Error('tail boom'); return tailLines; },
    kill(id, reason) { calls.kill.push([id, reason]); },
    subscribe(fn) { subs.add(fn); return () => subs.delete(fn); },
    emit(ev) { for (const fn of [...subs]) fn(ev); },
    subs,
  };
}

/** 假插件上下文：`get('jobs')` 返回给到的服务（或抛错模拟未装）。 */
function mkCtx(jobs) {
  return {
    get(name) {
      if (name === 'jobs') return jobs;
      return undefined;
    },
  };
}

console.log('== 官方 jobs 镜像：注册与 ring 写入 ==');
{
  const jobs = mkJobs();
  const d = mkDispatcher();
  const logs = [];
  const off = createOfficialJobs({ ctx: mkCtx(jobs), dispatcher: d, log: (l, m) => logs.push([l, m]) });
  ok('mirror 成功返回 true', off.mirror('j1', { ownerId: 's-1', label: 'zcode j1' }) === true);
  ok('官方 jobs.start 被调用一次', jobs.started.length === 1);
  const spec = jobs.started[0].spec;
  ok('kind 为 dispatch', spec.kind === OFFICIAL_KIND);
  ok('owner 透传为发起会话 id', spec.owner === 's-1');
  ok('label 透传', spec.label === 'zcode j1');
  ok('outputLimitBytes 有界', spec.outputLimitBytes === DEFAULT_OUTPUT_LIMIT_BYTES);
  ok('run() 同步返回 {done, cancel}', typeof jobs.started[0].hooks?.done?.then === 'function' && typeof jobs.started[0].hooks.cancel === 'function');
  ok('初始状态行进了 ring', jobs.started[0].appends.join('').includes('已镜像'));
  ok('stats.started = 1', off.stats().started === 1);
  off.dispose();
}

console.log('\n== 状态迁移只播状态行 ==');
{
  const jobs = mkJobs();
  const d = mkDispatcher();
  const off = createOfficialJobs({ ctx: mkCtx(jobs), dispatcher: d, log: () => {} });
  off.mirror('j1', { ownerId: 's-1' });
  const before = jobs.started[0].appends.length;
  d.emit({ type: 'job-updated', job: { id: 'other', state: 'done' } }); // 别的 job：不该写
  ok('无关 job 的事件不写 ring', jobs.started[0].appends.length === before);
  d.emit({ type: 'job-updated', job: { id: 'j1', state: 'running' } }); // 同状态：幂等
  ok('同状态重复事件不重复写', jobs.started[0].appends.length === before);
  d.emit({ type: 'job-updated', job: { id: 'j1', state: 'paused', exitCode: 3 } });
  const joined = jobs.started[0].appends.join('');
  ok('状态迁移写了状态行', joined.includes('[paused] exit=3'));
  off.dispose();
}

console.log('\n== 官方取消 → 派发台 kill ==');
{
  const jobs = mkJobs();
  const d = mkDispatcher();
  const off = createOfficialJobs({ ctx: mkCtx(jobs), dispatcher: d, log: () => {} });
  off.mirror('j1', { ownerId: 's-1' });
  jobs.started[0].hooks.cancel();
  ok('cancel 转成 dispatcher.kill，带原因', d.calls.kill.length === 1 && d.calls.kill[0][0] === 'j1' && /official job/.test(d.calls.kill[0][1]));
  ok('stats.cancelled = 1', off.stats().cancelled === 1);
  off.dispose();
}

console.log('\n== 结算：补最后一屏 + outcome ==');
{
  const jobs = mkJobs();
  const d = mkDispatcher({ job: { id: 'j1', state: 'done', engine: 'zcode', exitCode: 0 }, tailLines: ['line A', 'line B'] });
  const off = createOfficialJobs({ ctx: mkCtx(jobs), dispatcher: d, log: () => {} });
  off.mirror('j1', { ownerId: 's-1' });
  let outcome = null;
  jobs.started[0].hooks.done.then((o) => { outcome = o; });
  const handled = off.finish('j1', { id: 'j1', state: 'done', exitCode: 0 });
  ok('finish 返回 true（有镜像）', handled === true);
  ok('尾部输出进了 ring', jobs.started[0].appends.join('').includes('line A'));
  ok('dispatcher.tail 被调用（有界行数）', d.calls.tail.length === 1 && d.calls.tail[0][0] === 'j1');
  await flush();
  ok('done ⇒ status=completed', outcome !== null && outcome.status === 'completed', JSON.stringify(outcome));
  ok('监听已退订（subs 清空）', d.subs.size === 0);
  await flush();
  ok('再次 finish 无副作用且返回 true（幂等）', off.finish('j1', { id: 'j1', state: 'done' }) === true && off.stats().finished === 1);
  off.dispose();
}

console.log('\n== 回退分支：无服务 / 无 owner / start 抛错 / tail 抛错 ==');
{
  const d1 = mkDispatcher();
  const off1 = createOfficialJobs({ ctx: mkCtx(undefined), dispatcher: d1, log: () => {} });
  ok('无 jobs 服务 ⇒ mirror false（走派发台通知）', off1.mirror('j1', { ownerId: 's-1' }) === false);
  ok('无 jobs 服务 ⇒ finish false', off1.finish('j1', { state: 'done' }) === false);
  off1.dispose();

  const jobs2 = mkJobs();
  const off2 = createOfficialJobs({ ctx: mkCtx(jobs2), dispatcher: mkDispatcher(), log: () => {} });
  ok('无 ownerId ⇒ mirror false', off2.mirror('j1', {}) === false && jobs2.started.length === 0);
  off2.dispose();

  const off3 = createOfficialJobs({ ctx: mkCtx(mkJobs({ throwOnStart: 'no live agent' })), dispatcher: mkDispatcher(), log: () => {} });
  ok('官方 start 抛错 ⇒ mirror false（不冒泡）', off3.mirror('j1', { ownerId: 's-1' }) === false);
  ok('失败计入 stats.failed', off3.stats().failed === 1);
  off3.dispose();

  const jobs4 = mkJobs();
  const d4 = mkDispatcher({ tailThrows: true });
  const off4 = createOfficialJobs({ ctx: mkCtx(jobs4), dispatcher: d4, log: () => {} });
  off4.mirror('j1', { ownerId: 's-1' });
  let ok4 = true;
  try { off4.finish('j1', { id: 'j1', state: 'failed' }); } catch { ok4 = false; }
  ok('tail 抛错也不影响结算（吞掉）', ok4 === true);
  off4.dispose();
}

console.log('\n== 幂等与卸载 ==');
{
  const jobs = mkJobs();
  const d = mkDispatcher();
  const off = createOfficialJobs({ ctx: mkCtx(jobs), dispatcher: d, log: () => {} });
  ok('首次 mirror true', off.mirror('j1', { ownerId: 's-1' }) === true);
  ok('重复 mirror 仍是 true 且不重复 start', off.mirror('j1', { ownerId: 's-1' }) === true && jobs.started.length === 1);
  ok('has 反映镜像存在', off.has('j1') === true);
  let outcome = null;
  jobs.started[0].hooks.done.then((o) => { outcome = o; });
  off.dispose();
  await flush();
  ok('dispose 后 has=false', off.has('j1') === false);
  ok('dispose 结算残留为 failed', outcome !== null && outcome.status === 'failed', JSON.stringify(outcome));
  ok('dispose 后 mirror 直接 false', off.mirror('j1', { ownerId: 's-1' }) === false);
  ok('订阅已释放', d.subs.size === 0);
}

console.log(`\n官方 jobs 镜像小结：${checks - failures}/${checks} 通过`);
if (failures > 0) { console.log('❌ 有失败项'); process.exit(1); }
