/**
 * ZB-129 回归：notify ⇄ 官方 jobs 镜像的**分工**（通知单源）。
 *
 * 要钉死的两条互补行为：
 *   ① 有官方镜像 ⇒ 落地时**不走**派发台自己的投递（`followup/inject` 0 次），
 *      由官方 `dsh-tool-jobs` 发通知 —— 于是"通知/去重/抑制只留一份"。
 *   ② 没有 jobs 服务（镜像不可用）⇒ **照旧**走派发台自己的投递（回退，不能丢通知）。
 */
import { createSettleNotifier } from '../notify.mjs';

let checks = 0, failures = 0;
const flush = () => new Promise((r) => setTimeout(r, 0));
function ok(name, cond, extra = '') {
  checks += 1;
  if (cond) console.log(`  ✅ ${name}`);
  else { failures += 1; console.log(`  ❌ ${name}${extra ? `（${extra}）` : ''}`); }
}

/** 假官方 registry：只记录 start 的 spec，并保存 hooks 供测试结算。 */
function mkJobs() {
  const started = [];
  return {
    started,
    start(spec) {
      const rec = { spec, appends: [], hooks: null };
      started.push(rec);
      rec.hooks = spec.run({ append: (t) => rec.appends.push(String(t)), updateProgress() {} });
      return `dispatch-${String(started.length).padStart(16, '0')}`;
    },
  };
}

/** 假调度器：事件可编程；`jobsFile` 指向临时目录（persistStats 会尝试写，失败也吞）。 */
function mkDispatcher(job) {
  const subs = new Set();
  return {
    jobsFile: '',
    get: (id) => (id === job.id ? { ...job } : null),
    tail: () => ['tail line'],
    kill() {},
    subscribe(fn) { subs.add(fn); return () => subs.delete(fn); },
    emit(ev) { for (const fn of [...subs]) fn(ev); },
  };
}

function mkAgent(id) {
  const calls = [];
  return { id, status: 'idle', followup: (m) => calls.push(['followup', m]), inject: (m) => calls.push(['inject', m]), calls };
}

console.log('== 有官方镜像：通知交给官方，派发台不重复发 ==');
{
  const jobs = mkJobs();
  const job = { id: 'j1', state: 'running', engine: 'zcode', spec: { tag: 't1' } };
  const d = mkDispatcher(job);
  const agent = mkAgent('s-1');
  const ctx = { get: (n) => (n === 'jobs' ? jobs : undefined), on: () => () => {} };
  const notifier = createSettleNotifier({ dispatcher: d, agents: { get: (id) => (id === 's-1' ? agent : undefined) }, log: () => {}, ctx, config: {} });
  ok('track 成功', notifier.track('j1', 's-1') === true);
  ok('已镜像成官方 job', jobs.started.length === 1 && jobs.started[0].spec.owner === 's-1');
  job.state = 'done';
  job.exitCode = 0;
  d.emit({ type: 'job-updated', job: { ...job } });
  await flush();
  ok('派发台**没有**自己投递（followup/inject 0 次）', agent.calls.length === 0, JSON.stringify(agent.calls.map((c) => c[0])));
  ok('计入 officialDelivered', notifier.stats().officialDelivered === 1);
  ok('仍计入 notified（幂等账本一致）', notifier.stats().notified === 1);
  notifier.dispose();
}

console.log('\n== 无官方镜像：照旧走派发台通知（回退不丢）==');
{
  const job = { id: 'j2', state: 'running', engine: 'zcode', spec: {} };
  const d = mkDispatcher(job);
  const agent = mkAgent('s-2');
  const ctx = { get: () => undefined, on: () => () => {} }; // 没有 jobs 服务
  const notifier = createSettleNotifier({ dispatcher: d, agents: { get: (id) => (id === 's-2' ? agent : undefined) }, log: () => {}, ctx, config: {} });
  notifier.track('j2', 's-2');
  job.state = 'done';
  d.emit({ type: 'job-updated', job: { ...job } });
  await flush();
  ok('回退路径确实投递了（followup 1 次）', agent.calls.length === 1 && agent.calls[0][0] === 'followup', JSON.stringify(agent.calls.map((c) => c[0])));
  ok('officialDelivered 保持 0', notifier.stats().officialDelivered === 0);
  notifier.dispose();
}

console.log('\n== 关闭配置开关：完全不接触官方 registry ==');
{
  const jobs = mkJobs();
  const job = { id: 'j3', state: 'running', engine: 'zcode', spec: {} };
  const d = mkDispatcher(job);
  const agent = mkAgent('s-3');
  const ctx = { get: (n) => (n === 'jobs' ? jobs : undefined), on: () => () => {} };
  const notifier = createSettleNotifier({ dispatcher: d, agents: { get: (id) => (id === 's-3' ? agent : undefined) }, log: () => {}, ctx, config: { officialJobs: false } });
  notifier.track('j3', 's-3');
  ok('officialJobs=false ⇒ 没有 start 调用', jobs.started.length === 0);
  job.state = 'done';
  d.emit({ type: 'job-updated', job: { ...job } });
  await flush();
  ok('仍走派发台通知', agent.calls.length === 1);
  notifier.dispose();
}

console.log(`\n官方镜像 × 通知分工小结：${checks - failures}/${checks} 通过`);
if (failures > 0) { console.log('❌ 有失败项'); process.exit(1); }
