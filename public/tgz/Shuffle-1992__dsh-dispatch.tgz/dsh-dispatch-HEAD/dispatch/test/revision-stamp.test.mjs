/**
 * ZB-124（DSH 0.2.2-rc.1 适配 · P1）：面板两级刷新 —— 轻量状态戳（revision）
 *
 * 背景：面板原本每秒 `await remote.call('snapshot')`，而 `snapshot()` 要遍历全部 job
 * （JOBS_FILE_CAP=1000，每条含最多 200 行 tailLines）、读 repo 锁文件、列所有文件锁、
 * 拼 channels/engineDetail —— **静默期（状态没变）也照拉不误**。
 *
 * 改法：宿主暴露 `revision()`（只返回一个整数），面板先拉它、只有版本号变了才拉全量快照。
 * 版本号由唯一的落盘出口 `persist()` 单调递增 —— 于是"版本变了"⟺"面板那份视图该变了"。
 *
 * 本文件钉五件事：
 *   A. 源码锁：`stateRevision` 由 `persist()` 递增（防止有人把它挪到别处失效）；
 *   B. `stateStamp()` 的形状与单调性（真建 dispatcher 跑）；
 *   C. `snapshot()` 带上同一个版本号（双保险：版本探测与全量拉取不会错位）；
 *   D. 三张 face 表都声明了 `revision`（host / wire.client / client.js —— 历史上漂过一次）；
 *   E. 客户端 tick 确实是**两级**（先 revision，变了才 snapshot），且有兜底。
 */
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, readFileSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createDispatcher } from '../core/dispatch-core.mjs';

const HERE = dirname(fileURLToPath(import.meta.url));
const CORE = readFileSync(join(HERE, '..', 'core', 'dispatch-core.mjs'), 'utf8');
const WIRE_HOST = readFileSync(join(HERE, '..', 'wire.host.mjs'), 'utf8');
const WIRE_CLIENT = readFileSync(join(HERE, '..', 'wire.client.mjs'), 'utf8');
const CLIENT = readFileSync(join(HERE, '..', 'client.js'), 'utf8');
const FAKE_RUNNER = join(HERE, 'fixtures', 'fake-runner.mjs');
process.env.DSP_FAKE_RUNNER = FAKE_RUNNER;

const tempDirs = [];
const newWorkRoot = () => {
  const d = mkdtempSync(join(tmpdir(), 'dsp-rev-'));
  tempDirs.push(d);
  return d;
};
test.after(() => { for (const d of tempDirs) { try { rmSync(d, { recursive: true, force: true }); } catch { /* 尽力 */ } } });

const TERMINAL = ['done', 'failed', 'killed', 'paused'];
/** 等 job 落终态。**必须等**：runner 子进程收尾时会再 persist 一次，那时若测试已删掉
 *  临时目录就会 ENOENT，而它发生在异步上下文里 ⇒ uncaughtException ⇒ 整个测试文件 FAIL
 *  （本文件第一版就栽在这里：单独跑绿、进套件才红）。 */
const waitTerminal = async (d, id, ms = 15000) => {
  const t0 = Date.now();
  for (;;) {
    const j = d.get(id);
    if (j && TERMINAL.includes(j.state)) return j;
    if (Date.now() - t0 > ms) throw new Error(`waitTerminal 超时：${id} 仍是 ${j?.state}`);
    await new Promise((r) => setTimeout(r, 20));
  }
};
/** 统一收尾：杀掉在跑的 job → 等终态 → 让 200ms 节流窗口 flush 完 → 再 dispose。 */
const settleAndDispose = async (d) => {
  try {
    for (const j of d.list()) if (!TERMINAL.includes(j.state)) d.kill(j.id);
    for (const j of d.list()) if (!TERMINAL.includes(j.state)) await waitTerminal(d, j.id).catch(() => {});
  } catch { /* 尽力 */ }
  await new Promise((r) => setTimeout(r, 250));
  d.dispose?.();
};

/* ── A. 源码锁：版本号由唯一的落盘出口递增 ── */
test('ZB-124 ①：stateRevision 由 persist() 单调递增（源码锁）', () => {
  assert.match(CORE, /let stateRevision = 0;/, '声明 stateRevision');
  /* 递增必须在 atomicWrite(jobsFile 之后（先落盘再改版本号：顺序反了会让面板在盘还没更新时
   * 就认为"已更新"）。用整体下标比较，避免依赖函数体的缩进/换行风格。 */
  const awIdx = CORE.indexOf('atomicWrite(jobsFile');
  const bumpIdx = CORE.indexOf('stateRevision += 1');
  assert.ok(awIdx > 0, '找得到 atomicWrite(jobsFile');
  assert.ok(bumpIdx > 0, '找得到 stateRevision += 1');
  assert.ok(bumpIdx > awIdx, '★ 版本号递增在 atomicWrite 之后');
  /* 且它确实在 persist 里（persist 起点在它之前，restore 起点在它之后） */
  const persistIdx = CORE.indexOf('function persist() {');
  const restoreIdx = CORE.indexOf('function restore() {');
  assert.ok(persistIdx > 0 && persistIdx < bumpIdx, '递增位于 persist() 内');
  assert.ok(restoreIdx > bumpIdx, '递增位于 persist() 结束之前（restore 是下一个函数）');
});

/* ── B. 形状与单调性（真跑） ── */
test('ZB-124 ②：stateStamp() 形状正确，dispatch/kill 会推进版本号', async () => {
  const d = createDispatcher({ workRoot: newWorkRoot(), maxConcurrent: 2 });
  try {
    const s0 = d.stateStamp();
    assert.equal(typeof s0.revision, 'number', 'revision 是数字');
    assert.ok(s0.revision >= 0, 'revision 非负');
    assert.match(s0.at, /^\d{4}-\d{2}-\d{2}T/, 'at 是 ISO 时间串');
    assert.deepEqual(Object.keys(s0).sort(), ['at', 'locksAt', 'revision'], '三个字段：revision + locksAt + at');
    assert.equal(typeof s0.locksAt, 'number', 'locksAt 是数字（锁目录 mtime）');

    /* 纯读快照不该推进版本号（否则两级刷新退化成一级） */
    const before = d.stateStamp().revision;
    d.snapshot();
    d.list();
    assert.equal(d.stateStamp().revision, before, '★ 只读操作不推进版本号');

    /* 派发 ⇒ 落盘 ⇒ 版本号必须前进 */
    const job = d.dispatch({ kind: 'prompt', prompt: 'zb124', lock: 'none' });
    const afterDispatch = d.stateStamp().revision;
    assert.ok(afterDispatch > before, `★ dispatch 后版本号前进（${before} → ${afterDispatch}）`);
    assert.ok(job.id, 'job 建出来了');
  } finally {
    await settleAndDispose(d);
  }
});

/* ── C. snapshot 带同一版本号 ── */
test('ZB-124 ③：snapshot().revision 与 stateStamp().revision 同源', async () => {
  const d = createDispatcher({ workRoot: newWorkRoot(), maxConcurrent: 2 });
  try {
    d.dispatch({ kind: 'prompt', prompt: 'zb124-c', lock: 'none' });
    const stamp = d.stateStamp();
    const snap = d.snapshot();
    assert.equal(typeof snap.revision, 'number', 'snapshot 带 revision');
    assert.equal(snap.revision, stamp.revision, '★ 两者一致（同一次读取不会错位）');
  } finally {
    await settleAndDispose(d);
  }
});

/* ── D. 三张表都声明了 revision ── */
test('ZB-124 ④：host / wire.client / client.js 三张 face 表都含 revision', () => {
  const hostMethods = WIRE_HOST.match(/const REMOTE_METHODS = (\[[^\]]*\]);/)?.[1] ?? '';
  assert.match(hostMethods, /'revision'/, 'host REMOTE_METHODS 含 revision');
  assert.match(WIRE_HOST, /\['revision', \[\], 'revision\(\)/, 'host FACE_METHOD_TABLE 含 revision 行');
  assert.match(WIRE_HOST, /revision\(\) \{ return impl\.revision\(\); \}/, 'RemoteFace 类有转发方法');
  assert.match(WIRE_HOST, /async revision\(\) \{[\s\S]{0,9000}dispatcher\.stateStamp\(\)/, 'impl.revision 调 stateStamp');

  const clientDesc = WIRE_CLIENT.match(/descriptors: \[([\s\S]*?)\n  \]/)?.[1] ?? '';
  assert.match(clientDesc, /\['revision', \[\]/, 'wire.client 描述符表含 revision');

  assert.match(CLIENT, /\['revision', \[\], \[\]\]/, 'client.js 内联方法表含 revision');
});

/* ── E. 客户端 tick 确实是两级，且有兜底 ── */
test('ZB-124 ⑤：客户端 tick 先 revision、变了才 snapshot，并有兜底强制全量', () => {
  for (const [name, src] of [['client.js', CLIENT], ['wire.client.mjs', WIRE_CLIENT]]) {
    assert.match(src, /remote\.call\('revision'\)/, `${name} 先拉 revision`);
    assert.match(src, /lastSig/, `${name} 记住上一轮签名`);
    /* 全项目 review：判据必须是**三元组** —— 只看 revision 会让锁（别的进程动的）和
     * 通道/引擎（宿主 5s 探测缓存）的变化延迟到 30 拍兜底才可见。 */
    assert.match(src, /locksAt/, `${name} 签名含 locksAt`);
    assert.match(src, /channelsAt/, `${name} 签名含 channelsAt`);
    assert.match(src, /switchAt/, `${name} 签名含 switchAt`);
    assert.match(src, /dismissedAt/, `${name} 签名含 dismissedAt`);
    assert.match(src, /quotaAt/, `${name} 签名含 quotaAt`);
    assert.doesNotMatch(src, /lastRevision/, `${name} 不应再有只比 revision 的旧变量`);
    assert.match(src, new RegExp(`silentTicks[\\s\\S]{0,200}STALE_FULL_PULL_TICKS`), `${name} 有静默兜底`);
    /* 兜底常量必须是正数（0/负数会让兜底失效或每次全量） */
    const m = src.match(/STALE_FULL_PULL_TICKS = (\d+)/);
    assert.ok(m, `${name} 有兜底常量`);
    assert.ok(Number(m[1]) > 0, `${name} 兜底阈值是正数`);
    /* 关键：静默分支里**不能**再调 snapshot（否则两级白做） */
    const silent = src.match(/if \(!changed && silentTicks < STALE_FULL_PULL_TICKS\) \{([\s\S]{0,600}?)return;/);
    assert.ok(silent, `${name} 有静默分支`);
    assert.doesNotMatch(silent[1], /remote\.call\('snapshot'\)/, `★ ${name} 静默分支不拉全量快照`);
    assert.doesNotMatch(silent[1], /remote\.call\('quota'\)/, `★ ${name} 静默分支不拉 quota（单次 ~10.5ms）`);
  }
});

/* ── F. 全项目 review 补的盲区：锁/通道变化必须能被状态戳感知 ── */
test('ZB-124 ⑥：locksAt 能感知**别的进程**抢/放锁（revision 不变时也要变）', async () => {
  const { writeFileSync, mkdirSync } = await import('node:fs');
  const workRoot = newWorkRoot();
  const d = createDispatcher({ workRoot, maxConcurrent: 2 });
  try {
    const before = d.stateStamp();
    /* 模拟"别的 DSH 进程"直接往锁目录里写一个锁文件（绕开本进程的 dispatcher）。 */
    const lockDir = join(workRoot, 'locks', 'files');
    mkdirSync(lockDir, { recursive: true });
    const extLock = join(lockDir, 'external.lock');
    writeFileSync(extLock, JSON.stringify({ jobId: 'ext-job', pid: 999999, at: new Date().toISOString(), paths: ['x.ts'] }));
    await new Promise((r) => setTimeout(r, 30));
    const afterAdd = d.stateStamp();
    assert.ok(afterAdd.locksAt > before.locksAt, `★ 外部建锁后 locksAt 前进（${before.locksAt} → ${afterAdd.locksAt}）`);
    assert.equal(afterAdd.revision, before.revision, '本进程 revision 不变（这正是需要 locksAt 的原因）');

    /* 外部放锁也要能感知 —— 否则面板会一直显示一把已经不存在的锁。 */
    rmSync(extLock, { force: true });
    await new Promise((r) => setTimeout(r, 30));
    assert.ok(d.stateStamp().locksAt > afterAdd.locksAt, '★ 外部放锁后 locksAt 再前进');
  } finally {
    await settleAndDispose(d);
  }
});

test('ZB-124 ⑦：wire 层 revision() 把 channelsAt 一并带出（否则通道/引擎变化看不到）', () => {
  /* 源码锁：`impl.revision()` 必须读 channelsCache.at —— 通道清单是本层 5s TTL 探测缓存，
   * core 的 revision 完全感知不到它。 */
  /* 切实现体用**位置比较**（`indexOf` 起点→下一个 `\n    },`），不用窗口正则：
   * 窗口大小随注释增长要反复调（本项目已为此调过 3 次，每次加注释就断）。 */
  const rFrom = WIRE_HOST.indexOf('async revision()');
  const rTo = WIRE_HOST.indexOf('\n    },', rFrom);
  assert.ok(rFrom > 0 && rTo > rFrom, '能取出 impl.revision() 实现');
  const implBody = WIRE_HOST.slice(rFrom, rTo);
  assert.match(implBody, /dispatcher\.stateStamp\(\)/, '带上 core 的状态戳');
  assert.match(implBody, /channelsCache/, '★ 读 channelsCache');
  assert.match(implBody, /switchAt/, '★ 输出 switchAt（派发总开关也是读文件来的）');
  assert.match(implBody, /dismissedAt/, '★ 输出 dismissedAt（dismiss 不经过 core.persist，必须单独带戳）');
  assert.match(implBody, /quotaAt/, '★ 输出 quotaAt（quota 单次 ~10.5ms，不能每拍拉）');
});

test('ZB-126 ⑧：quotaAt 能感知台账追加（否则静默期永远不会刷用量卡）', async () => {
  /* `quota()` 实测 ≈10.5ms/次（读 1MB 台账聚合），所以静默期不拉它；
   * 判据是台账文件 mtime（quotaAt）—— 这里验证它确实随文件变化。 */
  const { writeFileSync, appendFileSync } = await import('node:fs');
  const { createRemoteFace } = await import('../wire.host.mjs');
  const workRoot = newWorkRoot();
  const ledger = join(workRoot, 'runs.jsonl');
  writeFileSync(ledger, '');
  const d = createDispatcher({ workRoot, maxConcurrent: 2 });
  try {
    const face = createRemoteFace(d, { ledgerPath: ledger });
    const s0 = await face.revision();
    assert.equal(typeof s0.quotaAt, 'number', 'revision 带 quotaAt');
    assert.ok(s0.quotaAt > 0, '台账存在时 quotaAt 非 0');

    await new Promise((r) => setTimeout(r, 30));
    appendFileSync(ledger, `${JSON.stringify({ at: new Date().toISOString(), tag: 'zb126' })}\n`);
    await new Promise((r) => setTimeout(r, 30));
    const s1 = await face.revision();
    assert.ok(s1.quotaAt > s0.quotaAt, `★ 台账追加后 quotaAt 前进（${s0.quotaAt} → ${s1.quotaAt}）`);

    /* 台账没动时不能变（否则静默期又变成每拍都拉 quota） */
    const s2 = await face.revision();
    assert.equal(s2.quotaAt, s1.quotaAt, '★ 台账未变时 quotaAt 稳定');
  } finally {
    await settleAndDispose(d);
  }
});
