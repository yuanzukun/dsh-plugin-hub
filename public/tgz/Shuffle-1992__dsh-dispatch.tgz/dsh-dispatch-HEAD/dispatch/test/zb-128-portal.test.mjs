/* ZB-128 —— 面板"看得见"契约（真机根因的回归锁）
 *
 * 背景（真机，2026-11-06）：用户悬浮/点击「派发台」入口，面板**一闪而过或干脆不出现**。
 * 桌面版是生产构建、DevTools 被禁，无法用 F12 取证 ⇒ 临时给 client.js 加了"诊断上报"
 * （console.warn + fire-and-forget POST 到本地端口），拿到运行时证据：
 *   - 诊断里确实有 `open = true`（面板**渲染**了）
 *   - 但用户屏幕上完全看不见 ⇒ 不是"没打开"，是**打开后被绘制成透明**
 * 根因：DSH 0.2.2 会话头把入口放在 `.titleCluster`（CSS Modules 哈希类）里，该容器带
 * `mask-image`（右缘淡出的渐变）。`mask-image` 会把**超出该元素盒子**的子内容绘制成完全
 * 透明 —— 而弹窗是 `position:absolute; top:calc(100% + 5px)`，正好落在盒子外。官方后台
 * 任务列表（dsh-client-ui-jobs）同样因此用 `createPortal` + `position:fixed`。
 *
 * 修复要点（本文件逐条锁住）：
 *   1. require('react-dom') 探测必须是 try/catch 式的（测试/SSR 无 react-dom 不许崩）
 *   2. 面板用 createPortal 到 document.body（逃出祖先 mask/overflow 的裁剪）
 *   3. Portal 外层 .dsp-portal 是 fixed 定位；面板自身退回 static（不然会二次偏移）
 *   4. 没有 react-dom 时必须退回内联渲染（既有行为不变）
 *   5. Portal 后面板不在入口容器子树内 ⇒「点外部关闭」的判定也要把面板算作内部
 *   6. relatedTarget === null 的 mouseleave 不能立刻取消展开定时器（入口被重挂载时会误发）
 *   7. 临时诊断代码必须已删除（不许留 18888 端口 / [dispatch-diag] 噪音）
 */
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const here = dirname(fileURLToPath(import.meta.url));
const src = readFileSync(join(here, '..', 'client.js'), 'utf8');

let pass = 0;
const ok = (cond, label, extra) => {
  assert.ok(cond, extra === undefined ? label : `${label}（实际：${extra}）`);
  pass += 1;
  console.log(`  ✓ ${label}`);
};

/* 取两个标记之间的源码片段（**位置切片**，不用宽窗口正则 —— ZB-126 的教训：
 * 注释一长 `{0,900}` 就会被截断，测试跟着"假红/假绿"）。 */
const slice = (from, to) => {
  const a = src.indexOf(from);
  if (a < 0) return '';
  const b = to ? src.indexOf(to, a + from.length) : -1;
  return b < 0 ? src.slice(a) : src.slice(a, b);
};

console.log('===== ZB-128：面板 Portal 契约 =====');

/* ── 1. react-dom 探测 ─────────────────────────────────────────── */
const requireBlock = slice("factory(require) {", 'const h = React.createElement;');
ok(requireBlock.includes("require('react-dom')"), '1. 探测 require(\'react-dom\')');
ok(/try\s*\{[^}]*require\('react-dom'\)/.test(requireBlock), '1b. 探测包在 try/catch 里（测试/SSR 无 react-dom 不许崩）');
ok(requireBlock.includes('typeof ReactDOM.createPortal'), '1c. canPortal 同时校验 createPortal 存在');
ok(requireBlock.includes("typeof document !== 'undefined'"), '1d. canPortal 校验 document/document.body 可用');

/* ── 2. Portal 到 body ─────────────────────────────────────────── */
const portalCall = slice('ReactDOM.createPortal(', 'document.body,');
ok(portalCall.length > 0, '2. 面板用 ReactDOM.createPortal 渲染');
ok(src.includes('document.body,'), '2b. createPortal 的容器是 document.body（逃出祖先 mask 裁剪）');
/* 不能改成"往 body 上挂东西"以外的 DOM 修改 */
ok(!/document\s*\.\s*body\s*(?:\.|\[)/.test(src), '2c. 不修改 document.body（只作 portal 容器引用）');

/* ── 3. Portal 定位样式 ───────────────────────────────────────── */
const portalCss = slice("'.dsp-portal{", "',");
ok(/position:fixed/.test(portalCss), '3. .dsp-portal 是 fixed 定位', portalCss.trim().slice(0, 80));
ok(/z-index:\d+/.test(portalCss), '3b. .dsp-portal 有 z-index（盖在标题栏之上）');
const innerCss = slice("'.dsp-portal .dsp-menu{", "',");
ok(/position:static/.test(innerCss), '3c. Portal 内 .dsp-menu 退回 static（避免二次偏移）', innerCss.trim().slice(0, 80));

/* ── 4. 无 react-dom 的退化路径 ───────────────────────────────── */
const renderTail = slice('open\n          ? (canPortal && menuPos', '        : null);');
ok(renderTail.includes('canPortal && menuPos'), '4. 渲染以 canPortal && menuPos 为条件（测量失败/无 react-dom 时退化）');
ok(renderTail.includes('h(PanelBoundary, null, h(PanelBody, { menuShift }))'),
  '4b. 退化路径仍是内联渲染（既有行为不变）');

/* ── 5. 点外部判定含 Portal 面板 ──────────────────────────────── */
const onDown = slice('const onDown = (e) => {', 'closeNow();');
ok(onDown.includes('menuRef.current'), '5. onDown 读取 menuRef（Portal 面板的 DOM）');
ok(/menu\s*\.\s*contains\(\s*t\s*\)|menu\.contains\(t\)/.test(onDown),
  '5b. onDown 把「面板子树内」也算内部（否则点面板任何按钮都关面板）');

/* ── 6. relatedTarget === null 的 mouseleave ─────────────────── */
const leave = slice('onMouseLeave: (e) => {', 'onFocus: scheduleOpen,');
ok(/relatedTarget\s*\?\s*e\.relatedTarget\s*:\s*null|e\.relatedTarget\s*:\s*null/.test(leave),
  '6. onMouseLeave 显式读取 relatedTarget');
ok(/if\s*\(\s*related\s*\)\s*\{\s*scheduleClose\(\);\s*return;\s*\}/.test(leave),
  '6b. related 非空才立刻 scheduleClose（null 走复核分支）');
ok(leave.includes('300'), '6c. null 分支用 300ms 二次确认（不立刻取消展开定时器）');
ok(leave.includes('menuRef.current'), '6d. 复核同时看 Portal 面板（鼠标慢过 300ms 也不误关）');
ok(/matches\(':hover'\)/.test(leave), '6e. 复核用 :hover 判断指针是否真的离开');

/* ── 7. 临时诊断必须已清理 ───────────────────────────────────── */
ok(!src.includes('18888'), '7. 临时诊断端口 18888 已移除');
ok(!src.includes('[dispatch-diag]'), '7b. 诊断前缀 [dispatch-diag] 已移除');
ok(!/\bDIAG_URL\b/.test(src), '7c. DIAG_URL 常量已移除');

console.log(`\n===== ZB-128：${pass} PASS / 0 FAIL =====`);
