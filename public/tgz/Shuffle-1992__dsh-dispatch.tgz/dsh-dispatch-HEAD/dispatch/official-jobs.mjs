/**
 * 官方 jobs 桥（双层里的**上层**）—— 把派发台的 run **镜像**成一条官方后台任务。
 *
 * ## 为什么是"镜像"而不是"接管官方 registry"
 * 任务书的 P0 原文是「runner 子进程注册成官方 job」。读 `dsh-jobs-local` 源码后确认
 * **接管不可行**（5 条硬理由见 README「为什么不接管官方 registry」）：
 * 官方 job 的归属绑定活着的 agent，owner 销毁即 `cancel + 删记录`，而派发台的核心价值
 * 恰恰是**跨会话续跑 / 交接重跑 / 降级链**；unowned 路线又拿不到通知且会污染官方 `job_list`。
 *
 * 所以这里取官方**仍在提供、且与派发台不冲突**的那部分价值：
 *   · 归属校验（job 只对发起会话可见、可停）
 *   · 有界输出环（`outputLimitBytes`，模型侧读取有界）
 *   · **落地通知**（`dsh-tool-jobs` 投递，含 0.2.2 的 `awaited` 抑制语义）
 *   · 后台任务 UI 里可见
 *
 * 派发台保留自己的那层：跨进程 `jobs.json` 台账、文件锁闸、暂停分类、降级链与续跑。
 * 换言之：**通知与可见性借官方，账本与调度归自己**。
 *
 * ## 与 `notify.mjs` 的关系（避免"两套通知"）
 * `notify.mjs` 的 `track()` 会调用本模块 `mirror()`；`check()` 落地时先调 `finish()`。
 * **镜像成功的 job，派发台不再自己发通知**（官方 `dsh-tool-jobs` 会发），于是
 * 「通知/去重/抑制逻辑只保留一份实现」这个目标通过**移交**达成：
 *   · 有镜像 → 官方通知（`awaited` 抑制由官方做）
 *   · 无镜像（无 jobs 服务 / 无活着的 owner / 并发上限 / 官方 start 抛错）→ 派发台自己的通知兜底
 *
 * ## 纪律
 * - **不 import 任何 `@deepseek-ai/**`**（第三方插件目录下裸 import 必失败；`test/z2-verify.mjs` 有静态纪律）。
 * - **任何一步失败都只 warn，绝不抛** —— 镜像只是增强，绝不能影响派发本身。
 * - 官方 `start()` 的 `run()` 必须**同步返回 hooks**；结算靠 `hooks.done` 的 promise。
 * - 官方侧 `cancel()` 转成派发台的 `kill()`（同一语义：用户要停），不私自改台账。
 */

/** 官方 job 的 kind（出现在 `<kind>-<short-uuid>` id 前缀与 UI 上）。 */
export const OFFICIAL_KIND = 'dispatch';
/** 有界输出环上限：只放状态行与最后一屏，足够模型侧 `job_output` 看出结局。 */
export const DEFAULT_OUTPUT_LIMIT_BYTES = 8192;
/** 落地时补进官方 ring 的尾部行数上限。 */
export const TAIL_LINES = 12;

/**
 * 建一个官方 jobs 桥。
 * @param {object} opts
 * @param {object} [opts.ctx] 插件上下文（用 `ctx.get('jobs')` 懒取官方 registry）
 * @param {object} opts.dispatcher 派发台调度器（`get` / `tail` / `kill` / `subscribe`）
 * @param {(level: string, msg: string) => void} [opts.log]
 * @param {object} [opts.config] 插件配置（`officialJobs === false` 可整体关闭）
 */
export function createOfficialJobs({ ctx, dispatcher, log, config = {} } = {}) {
  const warn = (msg) => { try { log?.('warn', msg); } catch { /* 日志失败不影响派发 */ } };
  const info = (msg) => { try { log?.('info', msg); } catch { /* 同上 */ } };
  const enabled = config?.officialJobs !== false;
  /** 派发台 jobId → { officialId, resolve, unsubscribe, handle, settled, lastState, appended } */
  const mirrored = new Map();
  /** 已结算过的派发台 jobId（有界）：让 `finish()` **幂等返回 true**，
   *  避免 notify 侧二次调用时误判"没有镜像 ⇒ 自己再发一条通知"。 */
  const finishedIds = new Set();
  const FINISHED_CAP = 512;
  const counter = { attempted: 0, started: 0, finished: 0, failed: 0, cancelled: 0, skipped: 0 };
  let disposed = false;

  /** 懒取官方 registry：`jobs` 服务缺席（未装 dsh-jobs-local）时返回 undefined。 */
  function jobsService() {
    try {
      const jobs = typeof ctx?.get === 'function' ? ctx.get('jobs') : undefined;
      return jobs && typeof jobs.start === 'function' ? jobs : undefined;
    } catch { return undefined; }
  }

  /** 派发台 job 记录 → 官方结算 outcome（`completed` / `failed` + 一行人话 detail）。 */
  function outcomeOf(job, jobId) {
    const state = String(job?.state ?? 'unknown');
    const status = state === 'done' || state === 'completed' ? 'completed' : 'failed';
    const bits = [`派发台 job ${jobId} 落地：${state}`];
    if (job?.exitCode !== undefined && job?.exitCode !== null) bits.push(`exit=${job.exitCode}`);
    if (job?.pauseReason) bits.push(`暂停原因=${job.pauseReason}`);
    return { status, detail: bits.join('，') };
  }

  /** 把一行文本塞进官方 ring（越界/失败都吞掉：ring 只是可见性，不是事实源）。 */
  function push(entry, text) {
    if (!text) return;
    try {
      entry.handle?.append(String(text));
      entry.appended += 1;
    } catch { /* ring 写入失败不影响派发 */ }
  }

  /**
   * 尝试为一个派发台 job 建官方镜像。
   * @param {string} jobId 派发台 job id
   * @param {{ ownerId?: string, label?: string }} [info0]
   * @returns {boolean} 是否已成功镜像（幂等：已镜像返回 true）
   */
  function mirror(jobId, info0 = {}) {
    if (!enabled || disposed) return false;
    if (typeof jobId !== 'string' || !jobId) return false;
    if (mirrored.has(jobId)) return true;
    const ownerId = info0?.ownerId;
    if (typeof ownerId !== 'string' || !ownerId) { counter.skipped += 1; return false; }
    const jobs = jobsService();
    if (!jobs) { counter.skipped += 1; return false; }
    let job = null;
    try { job = dispatcher.get(jobId); } catch { job = null; }
    if (!job) { counter.skipped += 1; return false; }
    const label = String(info0?.label ?? `${job?.engine ?? 'dispatch'} ${jobId}`).slice(0, 200);
    /* lastState 用 job 的**当前**状态做种子：镜像发生在 run 已经在跑时，
     * 否则首个同状态事件会重复播一行。 */
    const entry = { officialId: null, resolve: null, unsubscribe: null, handle: null, settled: false, lastState: String(job?.state ?? ''), appended: 0 };
    counter.attempted += 1;
    try {
      entry.officialId = jobs.start({
        kind: OFFICIAL_KIND,
        label,
        owner: ownerId,
        outputLimitBytes: DEFAULT_OUTPUT_LIMIT_BYTES,
        run(handle) {
          entry.handle = handle;
          let resolveDone;
          const done = new Promise((resolve) => { resolveDone = resolve; });
          entry.resolve = resolveDone;
          push(entry, `派发台 job ${jobId} 已镜像（engine=${job?.engine ?? '?'}，账本仍归派发台）\n`);
          /* 只播状态迁移（不搬日志正文）：输出细节走派发台自己的 tail，
           * 避免把大日志灌进官方 ring 让模型侧读取变贵。 */
          try {
            entry.unsubscribe = dispatcher.subscribe((ev) => {
              if (ev?.type !== 'job-updated' || ev?.job?.id !== jobId) return;
              const state = String(ev.job?.state ?? '');
              if (!state || state === entry.lastState) return;
              entry.lastState = state;
              push(entry, `[${state}]${ev.job?.exitCode != null ? ` exit=${ev.job.exitCode}` : ''}\n`);
            });
          } catch { entry.unsubscribe = null; }
          return {
            done,
            cancel() {
              /* 官方侧被停（用户点 job_kill / 会话归档）⇒ 同步停派发台 runner。
               * 不在这里改台账：`dispatcher.kill` 自己会走暂停分类与落盘。 */
              counter.cancelled += 1;
              try { dispatcher.kill(jobId, 'stopped via official job'); } catch (e) {
                warn(`官方 job 取消 → 派发台 kill 失败（job ${jobId}）：${e?.message ?? e}`);
              }
            },
          };
        },
      });
    } catch (e) {
      counter.failed += 1;
      warn(`官方 job 镜像失败（job ${jobId}）：${e?.message ?? e}（回退到派发台自己的落地通知）`);
      return false;
    }
    if (typeof entry.officialId !== 'string' || !entry.officialId) {
      counter.failed += 1;
      return false;
    }
    counter.started += 1;
    mirrored.set(jobId, entry);
    info(`已把 job ${jobId} 镜像为官方后台任务 ${entry.officialId}（发起会话 ${ownerId}）`);
    return true;
  }

  /** 该 job 是否已有官方镜像（有 ⇒ 派发台不再自己发通知）。 */
  function has(jobId) {
    return mirrored.has(jobId);
  }

  /**
   * 结算镜像：补最后一屏输出进官方 ring，然后 resolve `hooks.done` —— 官方据此
   * 投递落地通知（并把是否 `awaited` 的抑制交给官方判断）。
   * @param {string} jobId
   * @param {object} job 派发台 job 记录
   * @returns {boolean} 是否处理了（false = 没有镜像，调用方走自己的通知）
   */
  function finish(jobId, job) {
    const entry = mirrored.get(jobId);
    if (!entry) return finishedIds.has(jobId);
    if (entry.settled) return true;
    entry.settled = true;
    try { entry.unsubscribe?.(); } catch { /* 已退订 */ }
    let lines = [];
    try { lines = dispatcher.tail(jobId, TAIL_LINES) ?? []; } catch { lines = []; }
    const body = Array.isArray(lines) && lines.length ? `\n最近输出：\n${lines.slice(-TAIL_LINES).join('\n')}\n` : '';
    push(entry, body);
    try { entry.resolve?.(outcomeOf(job, jobId)); } catch (e) {
      warn(`官方 job 结算失败（job ${jobId}）：${e?.message ?? e}`);
    }
    counter.finished += 1;
    mirrored.delete(jobId);
    finishedIds.add(jobId);
    while (finishedIds.size > FINISHED_CAP) {
      const oldest = finishedIds.values().next().value;
      if (oldest === undefined) break;
      finishedIds.delete(oldest);
    }
    return true;
  }

  /** 诊断快照（测试与激活信标共用）。 */
  function stats() {
    return { enabled, mirrored: mirrored.size, ...counter };
  }

  /** 卸载：退订所有镜像监听，并把残留镜像按失败结算（不抛错）。 */
  function dispose() {
    if (disposed) return;
    disposed = true;
    for (const [jobId, entry] of mirrored) {
      try { entry.unsubscribe?.(); } catch { /* 已退订 */ }
      try { entry.resolve?.({ status: 'failed', detail: `插件卸载：job ${jobId} 的官方镜像提前结束（派发台台账仍可查）` }); } catch { /* 已结算 */ }
    }
    mirrored.clear();
  }

  return { mirror, has, finish, stats, dispose };
}
