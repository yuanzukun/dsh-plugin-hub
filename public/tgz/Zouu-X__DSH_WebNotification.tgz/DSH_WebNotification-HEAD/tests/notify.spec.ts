// @vitest-environment jsdom
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { apply } from '../src/client/index'
import { requestPermissionOnGesture, showCompletionNotification } from '../src/client/notifier'
import type { NotifyContext, SessionListObservable, SessionListState, SessionSummary } from '../src/client/types'
import { shouldNotify, watchCompletions } from '../src/client/watcher'

/** Build one minimal list summary with the fields the watcher reads. */
function summary(id: string, running: boolean): SessionSummary {
  return { id, displayTitle: 'session ' + id, running }
}

/** Build one minimal session-list state. */
function state(rows: SessionSummary[], current?: string): SessionListState {
  const byId: Record<string, SessionSummary> = {}
  for (const row of rows) byId[row.id] = row
  return { byId, current }
}

/** Minimal observable over a session-list state, with a test-only setter. */
function createList(initial: SessionListState): SessionListObservable & { set(next: SessionListState): void } {
  let current = initial
  const listeners = new Set<() => void>()
  return {
    getSnapshot: () => current,
    subscribe: (listener) => {
      listeners.add(listener)
      return () => { listeners.delete(listener) }
    },
    set: (next) => {
      current = next
      for (const listener of [...listeners]) listener()
    },
  }
}

/** Minimal Notification double recording fired instances. */
class MockNotification {
  static permission: NotificationPermission = 'granted'
  static requestPermission = vi.fn()
  static instances: MockNotification[] = []
  constructor(
    readonly title: string,
    readonly options?: NotificationOptions,
  ) {
    MockNotification.instances.push(this)
  }
}

beforeEach(() => {
  MockNotification.permission = 'granted'
  MockNotification.requestPermission = vi.fn()
  MockNotification.instances = []
})

afterEach(() => {
  vi.unstubAllGlobals()
})

describe('shouldNotify', () => {
  it('notifies whenever the user is away', () => {
    expect(shouldNotify('a', 'a', true)).toBe(true)
  })
  it('notifies a non-current session while present', () => {
    expect(shouldNotify('a', 'b', false)).toBe(true)
    expect(shouldNotify('a', undefined, false)).toBe(true)
  })
  it('suppresses the current session while present', () => {
    expect(shouldNotify('a', 'a', false)).toBe(false)
  })
})

describe('watchCompletions', () => {
  it('records the seed without notifying', () => {
    const list = createList(state([summary('a', true), summary('b', false)]))
    const notify = vi.fn()
    watchCompletions(list, notify, () => false)
    expect(notify).not.toHaveBeenCalled()
  })

  it('notifies once on a running-to-idle edge', () => {
    const list = createList(state([summary('a', true)]))
    const notify = vi.fn()
    watchCompletions(list, notify, () => false)
    list.set(state([summary('a', false)]))
    expect(notify).toHaveBeenCalledTimes(1)
    expect(notify).toHaveBeenCalledWith(expect.objectContaining({ id: 'a', running: false }))
  })

  it('ignores non-completion transitions', () => {
    const list = createList(state([summary('a', false), summary('b', false)]))
    const notify = vi.fn()
    watchCompletions(list, notify, () => false)
    list.set(state([summary('a', true), summary('b', false)]))
    expect(notify).not.toHaveBeenCalled()
  })

  it('suppresses the current session while present', () => {
    const list = createList(state([summary('a', true)], 'a'))
    const notify = vi.fn()
    watchCompletions(list, notify, () => false)
    list.set(state([summary('a', false)], 'a'))
    expect(notify).not.toHaveBeenCalled()
  })

  it('does not re-notify a session removed and re-added idle', () => {
    const list = createList(state([summary('a', true)]))
    const notify = vi.fn()
    watchCompletions(list, notify, () => false)
    list.set(state([summary('a', false)]))
    expect(notify).toHaveBeenCalledTimes(1)
    list.set(state([]))
    list.set(state([summary('a', false)]))
    expect(notify).toHaveBeenCalledTimes(1)
  })

  it('stops notifying after dispose', () => {
    const list = createList(state([summary('a', true)]))
    const notify = vi.fn()
    const dispose = watchCompletions(list, notify, () => true)
    dispose()
    list.set(state([summary('a', false)]))
    expect(notify).not.toHaveBeenCalled()
  })
})

describe('showCompletionNotification', () => {
  it('no-ops when Notification is unavailable', () => {
    vi.stubGlobal('Notification', undefined)
    expect(() => { showCompletionNotification(summary('a', false)) }).not.toThrow()
  })

  it('fires with the session title and completion copy when granted', () => {
    vi.stubGlobal('Notification', MockNotification)
    showCompletionNotification(summary('a', false))
    expect(MockNotification.instances).toHaveLength(1)
    expect(MockNotification.instances[0]!.title).toBe('session a')
    expect(MockNotification.instances[0]!.options).toMatchObject({
      body: '模型工作已完成',
      tag: 'dsh-notify:a',
    })
  })

  it('does not fire when permission is denied', () => {
    MockNotification.permission = 'denied'
    vi.stubGlobal('Notification', MockNotification)
    showCompletionNotification(summary('a', false))
    expect(MockNotification.instances).toHaveLength(0)
  })

  it('requests permission then fires only on grant', async () => {
    MockNotification.permission = 'default'
    MockNotification.requestPermission.mockResolvedValue('granted')
    vi.stubGlobal('Notification', MockNotification)
    showCompletionNotification(summary('a', false))
    await vi.waitFor(() => { expect(MockNotification.instances).toHaveLength(1) })
  })

  it('requests permission and stays silent on denial', async () => {
    MockNotification.permission = 'default'
    MockNotification.requestPermission.mockResolvedValue('denied')
    vi.stubGlobal('Notification', MockNotification)
    showCompletionNotification(summary('a', false))
    await Promise.resolve()
    await Promise.resolve()
    expect(MockNotification.instances).toHaveLength(0)
  })
})

describe('requestPermissionOnGesture', () => {
  it('requests permission on the first gesture and retires', () => {
    vi.stubGlobal('Notification', MockNotification)
    MockNotification.permission = 'default'
    MockNotification.requestPermission.mockResolvedValue('granted')
    const dispose = requestPermissionOnGesture()
    window.dispatchEvent(new Event('pointerdown'))
    expect(MockNotification.requestPermission).toHaveBeenCalledTimes(1)
    window.dispatchEvent(new Event('keydown'))
    expect(MockNotification.requestPermission).toHaveBeenCalledTimes(1)
    dispose()
  })

  it('does nothing when permission is already granted', () => {
    vi.stubGlobal('Notification', MockNotification)
    MockNotification.permission = 'granted'
    requestPermissionOnGesture()
    window.dispatchEvent(new Event('pointerdown'))
    expect(MockNotification.requestPermission).not.toHaveBeenCalled()
  })
})

describe('apply', () => {
  it('wires the sessions list to a completion notification', () => {
    vi.stubGlobal('Notification', MockNotification)
    const list = createList(state([summary('a', true)]))
    const ctx: NotifyContext = {
      sessions: { list },
      effect: (effect) => { effect() },
    }
    apply(ctx)
    list.set(state([summary('a', false)]))
    expect(MockNotification.instances).toHaveLength(1)
  })
})
