# dsh-notify

> 为 [DeepSeek Harness](https://github.com/deepseek-ai/deepseek-harness) Web UI 提供浏览器通知——会话一结束运行，就弹一条系统通知。

`dsh-notify` 是一个轻量、纯行为的 DeepSeek Harness（`dsh`）**Web 客户端插件**。当你把长任务交给模型、切到别的标签页或别的应用之后，任务一完成它就会弹出系统通知，让你不用反复回来查看。

## 特性

- 🛎️ **完成即系统通知** —— 在会话的 `running` 状态翻转为 idle 的那一刻触发，标题为会话名，正文为中文完成文案。
- 👀 **盯着看时不打扰** —— 只有当你正在看那个刚完成的会话时才保持安静。以下情况都会通知：
  - 页面已隐藏（切到了别的标签页），或
  - 浏览器窗口已失焦（切到了别的应用），或
  - 完成会话不是当前选中的会话。
- 🔁 **按会话去重** —— 每条通知按会话打 tag，重复完成会替换上一条而不是堆叠。
- 🔐 **在正确的时机申请权限** —— 权限提示在你第一次点击或敲键盘时弹出，而不是等你切走之后（这正是 Safari 下能生效的原因）。
- ⚙️ **零 UI** —— 没有按钮、没有设置页、没有宿主侧改动。它只是 profile 里的一行浏览器插件。

## 环境要求

- 已启用 Web UI 的 [DeepSeek Harness](https://github.com/deepseek-ai/deepseek-harness)（`dsh web` 或 `dsh --profile web`）。
- 现代浏览器。Web UI 运行在 `http://127.0.0.1:<port>`，属于安全上下文，因此 `Notification` API 可用。
- 在 macOS 上，还需要在 **系统设置 → 通知** 里允许该浏览器，否则即便网页有权限，系统也会拦截横幅。

## 安装

`dsh-notify` 是一个可安装的 **组合包（bundle）**。可以从 npm、tarball，或直接从这个仓库安装到 profile：

```sh
# 从 GitHub（本仓库）
dsh plugin --profile web add github:you/dsh-notify

# 从 npm
dsh plugin --profile web add dsh-notify

# 从本地 checkout 或打包的 tarball
dsh plugin --profile web add ./dsh-notify
```

`dsh plugin` 会转发给 pnpm，因此任何 pnpm 包说明符都可用。安装 bundle 会把它追加到 profile 的 `dsh.profile.bundles` 并应用其 patch 层，无需手动改 `cordis.yml`。

> **GitHub 安装无需构建步骤。** 本仓库提交了构建好的 `lib/`，因此 `dsh plugin add github:you/dsh-notify` 可直接使用，无需授予任何安装时的构建权限。

## 使用

安装后启动 Web UI，并在浏览器第一次询问（你的第一次点击或敲键盘）时授予通知权限：

```sh
dsh --profile web
```

在任意会话里发起任务，切走，模型一完成就会弹出系统通知。没有其它需要配置的东西。

## 工作原理

插件注入运行时的 `sessions` 服务，并订阅会话列表快照——与侧栏读取的是同一事实源。一个小的折叠逻辑维护每个会话上一次的 `running` 位，首次观测只记录而不通知，并为每个 `running → idle` 边沿派发一次通知，再由上文「你是否盯着这个会话」的规则把关。

浏览器半边是通过 `window.__ModuleLoader__.load` 注册的 CJS bundle，由 harness 的客户端模块系统扫描并 serve 在 `/plugins/dsh-notify/client.js`。节点半边是一个 no-op 的宿主插件体。

## 开发

```sh
pnpm install     # 安装开发工具
pnpm build       # 打包 lib/index.js（节点半边）与 lib/client.js（浏览器半边）
pnpm typecheck   # tsc --noEmit
pnpm test        # vitest
```

构建产物已提交到 `lib/`，因此 GitHub 安装无需构建步骤。

```
dsh-notify/
├── package.json        # dsh.client + dsh.bundle.patch 清单
├── cordis.patch.yml    # bundle 层：插入 dsh-notify 行
├── tsdown.config.ts    # 构建节点半边与浏览器半边
├── src/
│   ├── index.ts        # 节点半边（no-op 宿主插件）
│   └── client/
│       ├── index.ts    # apply / inject
│       ├── watcher.ts  # running→idle 边沿检测
│       ├── notifier.ts # Notification 派发 + 权限引导
│       └── types.ts    # 最小化的本地运行时视图
└── tests/notify.spec.ts
```

## 已知限制

- **始终开启** —— 还没有用户开关。设置项（开关、声音、仅后台时）是自然的后续。
- **只有系统通知** —— 完成不会同时产生应用内 toast 或标题闪烁；侧栏内置的绿色「已完成」圆点仍是应用内信号。
- **权限由浏览器掌控** —— 用户拒绝权限提示后，该源即被禁用，应用内无法恢复。
- **没有声音** —— 提示音暂缓。

## 许可证

[MIT](LICENSE)
