import type { UserConfig } from 'tsdown'

/** Package name — also the module-loader id and the bundle row name. */
const ID = 'dsh-notify'

/**
 * Node half: the no-op plugin body the host Loader mounts for the row. The
 * browser half (./client) is what dsh-client-modules serves to the page.
 */
const nodeHalf: UserConfig = {
  entry: { index: 'src/index.ts' },
  outDir: 'lib',
  format: ['esm'],
  platform: 'node',
  target: 'es2024',
  fixedExtension: false,
  dts: false,
  clean: false,
}

/**
 * Browser half: a CJS bundle registered through window.__ModuleLoader__.load,
 * matching the shape dsh-client-modules scans and serves under /plugins.
 */
const clientHalf: UserConfig = {
  entry: { client: 'src/client/index.ts' },
  outDir: 'lib',
  format: ['cjs'],
  platform: 'browser',
  target: 'es2024',
  dts: false,
  clean: false,
  sourcemap: true,
  outputOptions: {
    entryFileNames: 'client.js',
    banner: 'window.__ModuleLoader__.load({ id: ' + JSON.stringify(ID) + ', factory: (require) => {',
    footer: 'return module.exports; } });',
    intro: 'var module = { exports: {} }; var exports = module.exports;',
  },
}

export default [nodeHalf, clientHalf]
