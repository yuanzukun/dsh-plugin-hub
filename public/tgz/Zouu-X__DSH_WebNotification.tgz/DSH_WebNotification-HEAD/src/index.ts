/**
 * Node half of dsh-notify: the host Loader mounts this no-op plugin body for
 * the bundle row. The browser behavior lives in ./client, which
 * dsh-client-modules serves to the page under /plugins/dsh-notify/client.js.
 */

/** Provides no host-side behavior. */
export function apply(): void {}
