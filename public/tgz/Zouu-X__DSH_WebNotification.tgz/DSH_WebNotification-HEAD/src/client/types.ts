/**
 * Minimal client-side views of the runtime facts this plugin reads. These are
 * structural subsets of the host's @deepseek-ai/dsh-client-runtime contracts
 * (SessionListState / SessionSummary), declared locally so the plugin ships
 * with no runtime import of that package — the host provides the sessions
 * service through cordis injection at runtime.
 */

/** One listed session's fields the watcher reads. */
export interface SessionSummary {
  id: string
  displayTitle: string
  running: boolean
}

/** The sessions list snapshot the watcher reads. */
export interface SessionListState {
  byId: Record<string, SessionSummary>
  current: string | undefined
}

/** The read-only observable face of the runtime sessions list. */
export interface SessionListObservable {
  getSnapshot(): SessionListState
  subscribe(listener: () => void): () => void
}

/** The cordis context surface this plugin needs at runtime. */
export interface NotifyContext {
  sessions: { list: SessionListObservable }
  effect(effect: () => () => void, label: string): void
}
