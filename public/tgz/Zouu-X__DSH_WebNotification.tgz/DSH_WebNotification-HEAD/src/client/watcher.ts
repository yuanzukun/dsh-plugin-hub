/**
 * Completion edge-detection over the sessions list. Pure and React-free: the
 * plugin body subscribes to the runtime sessions list snapshot and this
 * module derives the running-to-idle edges that arm one system notification.
 */
import type { SessionListObservable, SessionSummary } from './types'

/**
 * Whether one completion should notify the user.
 * @param sessionId - the session that just finished running.
 * @param current - the currently selected session id, when any.
 * @param away - whether the user is away from the page: it is hidden or the
 *   window lost focus, so they are not looking at this session.
 * @returns true when the user is not looking at this exact session: they are
 *   away, or the completing session is not the current selection.
 */
export function shouldNotify(
  sessionId: string,
  current: string | undefined,
  away: boolean,
): boolean {
  return away || current !== sessionId
}

/**
 * Watch the sessions list and notify on each running-to-idle edge. The first
 * observation only records each session's running bit, so a session already
 * idle at load never notifies, while one that appears running and later idles
 * does.
 * @param list - the runtime sessions list observable.
 * @param notify - completion callback (system-notification dispatch).
 * @param isAway - whether the user is currently away from the page.
 * @returns disposer that unsubscribes and drops the running-bit map.
 */
export function watchCompletions(
  list: SessionListObservable,
  notify: (summary: SessionSummary) => void,
  isAway: () => boolean,
): () => void {
  const prevRunning = new Map<string, boolean>()
  const onChange = (): void => {
    const { byId, current } = list.getSnapshot()
    const seen = new Set<string>()
    for (const summary of Object.values(byId)) {
      seen.add(summary.id)
      const prev = prevRunning.get(summary.id)
      if (prev === undefined) {
        prevRunning.set(summary.id, summary.running)
        continue
      }
      if (prev && !summary.running && shouldNotify(summary.id, current, isAway())) {
        notify(summary)
      }
      prevRunning.set(summary.id, summary.running)
    }
    for (const id of prevRunning.keys()) if (!seen.has(id)) prevRunning.delete(id)
  }
  onChange()
  return list.subscribe(onChange)
}
