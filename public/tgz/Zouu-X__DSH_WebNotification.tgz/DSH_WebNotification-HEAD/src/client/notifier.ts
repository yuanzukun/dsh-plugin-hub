/**
 * Browser system-notification dispatch and permission bootstrap. Kept as a
 * thin wrapper so the watcher stays independent of the Notification API and
 * tests can substitute a mock.
 */
import type { SessionSummary } from './types'

/** Notification body copy for a completed session. */
const COMPLETION_BODY = '模型工作已完成'

/** Notification tag prefix; one slot per session, so a repeat replaces the prior. */
const TAG_PREFIX = 'dsh-notify:'

/**
 * Dispatch one completion notification, requesting permission on first use.
 * @param summary - the session that finished running.
 */
export function showCompletionNotification(summary: SessionSummary): void {
  if (typeof Notification === 'undefined') return
  const fire = (): void => {
    new Notification(summary.displayTitle, {
      body: COMPLETION_BODY,
      tag: TAG_PREFIX + summary.id,
    })
  }
  if (Notification.permission === 'granted') {
    fire()
    return
  }
  if (Notification.permission === 'denied') return
  try {
    Notification.requestPermission()
      .then((permission) => {
        if (permission === 'granted') fire()
      })
      .catch(() => {
        // A denied prompt is permanent for the page and nothing here can change
        // it; the request may also reject outside a user gesture, so a later
        // completion retries the request instead.
      })
  } catch {
    // Some browsers throw when requesting permission outside a user gesture.
    // The next completion retries the request; no other recovery is possible.
  }
}

/**
 * Request notification permission on the first user gesture, so the prompt
 * appears while the user is interacting rather than on a later background
 * completion (Safari only grants gesture-bound requests). The listener
 * retires after the first gesture either way.
 * @returns disposer removing the gesture listeners.
 */
export function requestPermissionOnGesture(): () => void {
  if (typeof Notification === 'undefined' || typeof window === 'undefined') return () => {}
  if (Notification.permission !== 'default') return () => {}
  const request = (): void => {
    try {
      void Notification.requestPermission().catch(() => {
        // A denied or rejected prompt is permanent for the page; the listener
        // retires regardless — nothing here can change the outcome.
      })
    } catch {
      // Browsers that throw on a non-gesture request never reach this path
      // from a real gesture; a later completion still requests once.
    }
    window.removeEventListener('pointerdown', request)
    window.removeEventListener('keydown', request)
  }
  window.addEventListener('pointerdown', request)
  window.addEventListener('keydown', request)
  return () => {
    window.removeEventListener('pointerdown', request)
    window.removeEventListener('keydown', request)
  }
}
