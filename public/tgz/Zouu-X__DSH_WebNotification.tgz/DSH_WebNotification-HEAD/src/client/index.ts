/**
 * dsh-notify client half: a system notification when a session finishes
 * running. Pure browser behavior — it registers no slots and renders nothing;
 * it only subscribes to the runtime sessions list and bootstraps the
 * notification permission on first use.
 */
import { requestPermissionOnGesture, showCompletionNotification } from './notifier'
import type { NotifyContext } from './types'
import { watchCompletions } from './watcher'

/** Services required before the completion watcher can mount. */
export const inject = ['sessions']

/** Mount the running-bit watcher that fires completion notifications.
 * @param ctx - Client cordis context.
 */
export function apply(ctx: NotifyContext): void {
  ctx.effect(() => requestPermissionOnGesture(), 'dsh-notify: permission request')
  ctx.effect(
    () => watchCompletions(
      ctx.sessions.list,
      showCompletionNotification,
      () => document.visibilityState === 'hidden' || !document.hasFocus(),
    ),
    'dsh-notify: completion watcher',
  )
}
