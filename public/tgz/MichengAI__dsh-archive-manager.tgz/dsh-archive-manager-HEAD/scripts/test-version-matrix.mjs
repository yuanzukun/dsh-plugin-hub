// 每个宿主版本独立安装依赖并运行同一份插件产物，禁止借用本机 DSH 链接。
import { cp, mkdtemp, readFile, readdir, rm, writeFile } from "node:fs/promises";
import { basename, dirname, join } from "node:path";
import { tmpdir } from "node:os";
import { fileURLToPath } from "node:url";
import { spawn } from "node:child_process";
import { hostTestOverrides } from "./host-test-dependencies.mjs";

const root = fileURLToPath(new URL("..", import.meta.url));
const manifest = JSON.parse(await readFile(join(root, "package.json"), "utf8"));
const profiles = [
	{ version: "0.2.0-rc.1", cordis: "4.0.4", schemastery: "3.18.4", latest: true },
	{ version: "0.2.0-rc.2", cordis: "4.0.4", schemastery: "3.18.4", latest: true },
	{ version: "0.2.1-alpha.1", cordis: "4.0.5-alpha.1", schemastery: "3.18.5-alpha.1", latest: true },
	{ version: "0.2.1-alpha.2", cordis: "4.0.5-alpha.1", schemastery: "3.18.5-alpha.1", latest: true },
	{ version: "0.2.1-alpha.3", cordis: "4.0.5-alpha.2", schemastery: "3.18.5-alpha.2", latest: true },
	{ version: "0.2.1-alpha.4", cordis: "4.0.5-alpha.2", schemastery: "3.18.5-alpha.2", latest: true },
	{ version: "0.2.1-alpha.5", cordis: "4.0.5-alpha.2", schemastery: "3.18.5-alpha.2", latest: true },
	{ version: "0.2.1-rc.1", cordis: "4.0.5", schemastery: "3.18.5", latest: true },
	{ version: "0.2.1-rc.2", cordis: "4.0.5", schemastery: "3.18.5", latest: true },
	{ version: "0.2.1-rc.3", cordis: "4.0.5", schemastery: "3.18.5", latest: true },
];
const cordisPlugins = {
	"4.0.4": {
		"@deepseek-ai/cordis-plugin-group": "1.0.4",
		"@deepseek-ai/cordis-plugin-hmr": "1.0.19",
		"@deepseek-ai/cordis-plugin-include": "1.0.9",
		"@deepseek-ai/cordis-plugin-loader": "1.0.5",
		"@deepseek-ai/cordis-plugin-timer": "1.1.6",
	},
	"4.0.5": {
		"@deepseek-ai/cordis-plugin-group": "1.0.5",
		"@deepseek-ai/cordis-plugin-hmr": "1.0.20",
		"@deepseek-ai/cordis-plugin-include": "1.0.10",
		"@deepseek-ai/cordis-plugin-loader": "1.0.6",
		"@deepseek-ai/cordis-plugin-timer": "1.1.7",
	},
};
const npm = process.platform === "win32" ? process.execPath : "npm";
for (const generation of [1, 2]) {
	cordisPlugins[`4.0.5-alpha.${generation}`] = Object.fromEntries(Object.entries(cordisPlugins["4.0.5"]).map(([name, version]) => [name, `${version}-alpha.${generation}`]));
}
const npmPrefix = process.platform === "win32" ? [join(dirname(process.execPath), "node_modules", "npm", "bin", "npm-cli.js")] : [];
const testNames = (await readdir(join(root, "test"))).filter((name) => name.endsWith(".test.mjs"));

function run(command, args, cwd, env = process.env) {
	return new Promise((resolve, reject) => {
		const child = spawn(command, args, { cwd, env, stdio: ["ignore", "pipe", "pipe"] });
		let output = "";
		child.stdout.setEncoding("utf8").on("data", (data) => { output += data; });
		child.stderr.setEncoding("utf8").on("data", (data) => { output += data; });
		child.once("error", reject);
		child.once("exit", (code, signal) => code === 0 ? resolve(output) : reject(new Error(`命令失败（${code ?? signal}）：${command}\n${output}`)));
	});
}

if (manifest.devDependencies["@deepseek-ai/dsh-session"] !== "0.2.1-rc.3") {
	throw new Error(`开发依赖基线必须钉为 0.2.1-rc.3，实际 ${manifest.devDependencies["@deepseek-ai/dsh-session"]}`);
}
const failures = [];
for (const profile of profiles) {
	const isolated = await mkdtemp(join(tmpdir(), "dsh-am-matrix-"));
	console.log(`\nDSH ${profile.version} / Cordis ${profile.cordis}：安装隔离依赖并执行全量回归`);
	try {
		const dependencies = {};
		for (const [name, pinned] of Object.entries(manifest.devDependencies)) {
			dependencies[name] = name.startsWith("@deepseek-ai/dsh-") ? profile.version : pinned;
		}
		dependencies["@deepseek-ai/cordis"] = profile.cordis;
		dependencies["@deepseek-ai/schemastery"] = profile.schemastery;
		Object.assign(dependencies, cordisPlugins[profile.cordis]);
		for (const name of ["api-session-controller", "session-persistence-jsonl", "session-query", "session-title", "storage-json"]) dependencies[`@deepseek-ai/dsh-${name}`] = profile.version;
		await writeFile(join(isolated, "package.json"), JSON.stringify({ private: true, type: "module", dependencies, overrides: hostTestOverrides(profile.version) }), "utf8");
		await run(npm, [...npmPrefix, "install", "--ignore-scripts", "--no-audit", "--no-fund"], isolated);
		if (profile.latest && process.platform !== "win32") await run(npm, [...npmPrefix, "rebuild", "fs-ext"], isolated);
		for (const [name, version] of Object.entries(dependencies)) {
			if (!name.startsWith("@deepseek-ai/")) continue;
			const installed = JSON.parse(await readFile(join(isolated, "node_modules", name, "package.json"), "utf8"));
			if (installed.version !== version) throw new Error(`${name} 版本混用：期望 ${version}，实际 ${installed.version}`);
		}
		for (const directory of ["src", "lib", "scripts", "test", "locale"]) {
			await cp(join(root, directory), join(isolated, directory), { recursive: true, filter: (source) => basename(source) !== "node_modules" });
		}
		// 安装清单只用于装载宿主；测试仍审查真实插件清单，不伪造发布依赖。
		for (const file of ["package.json", "tsconfig.json", ".gitattributes", "README.md", "README.zh-CN.md", "CHANGELOG.md", "CHANGELOG.zh-CN.md", "LICENSE", "cordis.patch.yml"]) {
			await cp(join(root, file), join(isolated, file));
		}
		const output = await run(process.execPath, ["--import", "tsx", "--test", "--test-reporter=spec", ...testNames.map((name) => join("test", name)), join("test", "fixtures", "latest-host.mjs"), join("test", "fixtures", "projcache-json.mjs"), join("test", "fixtures", "issue88-native.mjs"), join("test", "fixtures", "session-refresh-host.mjs")], isolated, { ...process.env, DSH_ARCHIVE_TEST_HOST_VERSION: profile.version });
		console.log(output.trim().split(/\r?\n/).slice(-8).join("\n"));
	} catch (error) {
		console.error(`DSH ${profile.version} 回归失败：${String(error)}`);
		failures.push(profile.version);
	} finally {
		await rm(isolated, { recursive: true, force: true, maxRetries: 3 });
	}
}
if (failures.length > 0) throw new Error(`版本矩阵未通过：${failures.join(", ")}`);
console.log("全部新旧宿主版本矩阵通过。");
