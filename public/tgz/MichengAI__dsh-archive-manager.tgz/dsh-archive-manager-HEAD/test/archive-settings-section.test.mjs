import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import test from "node:test";

const clientPath = fileURLToPath(new URL("../src/client.ts", import.meta.url));

test("归档入口注册在设置的连接器之后，并移除旧的视图选项入口", async () => {
  const client = await readFile(clientPath, "utf8");

  assert.match(client, /name: "settings\.section",[\s\S]*id: "archive-manager",[\s\S]*order: 45/);
  assert.match(client, /id: "archive-manager",[\s\S]*icon: "archive"/);
  assert.match(client, /ArchivedSessionsSection/);
  assert.doesNotMatch(client, /id: "show-archived"/);
  assert.doesNotMatch(client, /viewOptions\.showArchived/);
});

test("设置菜单与页面大标题统一命名为归档会话", async () => {
  const client = await readFile(clientPath, "utf8");

  assert.match(client, /"archived\.badge": "归档会话"/);
  assert.match(client, /"archives\.title": "归档会话"/);
  assert.match(client, /"archived\.badge": "Archived sessions"/);
  assert.match(client, /"archives\.title": "Archived sessions"/);
  assert.doesNotMatch(client, /"archives\.title": "已归档的聊天"/);
});

test("归档设置页保留筛选并移除重复的全量操作入口", async () => {
  const client = await readFile(clientPath, "utf8");

  assert.match(client, /dsham_settingsToolbar/);
  assert.match(client, /placeholder: t\(contentEnabled \? "discovery\.searchPlaceholder"/);
  assert.match(client, /"dsham_settingsFilter"/);
  assert.match(client, /id: "dsham-sort-filter"/);
  assert.match(client, /value: "updated", label: t\("archives\.sortUpdated"\)/);
  assert.match(client, /value: "created", label: t\("archives\.sortCreated"\)/);
  assert.match(client, /value: "alphabetical", label: t\("archives\.sortAlphabetical"\)/);
  assert.doesNotMatch(client, /className: "dsham_settingsRestoreAll"/);
  assert.doesNotMatch(client, /onClick: \(\) => onBatchUnarchive\(allBatchTarget\)/);
  assert.doesNotMatch(client, /target: allBatchTarget/);
  assert.doesNotMatch(client, /value: chatType, onChange: \(event\) => setChatType\(event\.target\.value\)/);
  assert.doesNotMatch(client, /chatType === "all"/);
});

test("归档设置页在标题区提供项目与反馈入口，不混入批量操作", async () => {
  const client = await readFile(clientPath, "utf8");

  assert.match(client, /className: "dsham_settingsTitleRow"/);
  assert.match(client, /https:\/\/github\.com\/MichengAI\/dsh-archive-manager/);
  assert.match(client, /function GithubMark16\(\)/);
  assert.match(client, /GithubMark16, \{\}/);
  assert.match(client, /https:\/\/github\.com\/MichengAI\/dsh-archive-manager\/issues/);
  assert.match(client, /FeedbackIcon/);
  assert.doesNotMatch(client, /IconDislikeOutline16/);
  assert.match(client, /"archives\.viewProject": "GitHub"/);
  assert.equal((client.match(/"archives\.viewProject": "GitHub"/g) ?? []).length, 3);
  assert.match(client, /"archives\.feedback": "问题反馈"/);
  assert.match(client, /"archives\.feedback": "Issues"/);
  assert.equal((client.match(/className: "dsham_settingsTitleRow"/g) ?? []).length, 1);
  assert.equal((client.match(/https:\/\/github\.com\/MichengAI\/dsh-archive-manager\/issues/g) ?? []).length, 1);
  assert.doesNotMatch(client, /dsham_settingsHeaderActions[\s\S]{0,700}archives\.viewProject/);
});

test("归档设置页原型支持筛选内全选、跨项目选择与确认批量操作", async () => {
	const client = await readFile(clientPath, "utf8");

	assert.match(client, /ArchivedSessionsSection/);
	assert.match(client, /className: "dsham_settingsSelection"/);
	assert.match(client, /archives\.selectAllFiltered/);
	assert.match(client, /onToggle: toggleVisibleSelection/);
	assert.match(client, /scope: "sessions", sessionIds: selectedSessionIds/);
	assert.match(client, /archives\.restoreSelected/);
	assert.match(client, /archives\.deleteSelectedTitle/);
	assert.match(client, /function pruneArchivedSelection/);
	assert.match(client, /function toggleArchivedSelection/);
	assert.match(client, /}, ArchivedSessionsSection\);/);
});

test("恢复和删除后刷新会话投影，使侧栏与宿主状态重新一致", async () => {
	const client = await readFile(clientPath, "utf8");

	assert.match(client, /const refreshSessionList = async \(\) =>/);
	assert.match(client, /restored archived sessions but session list refresh failed/);
	assert.match(client, /await unarchiveOne\(sessionId\);[\s\S]*await refreshSessionList\(\);/);
	assert.match(client, /unarchiveSessionsViaOfficial\(ctx\.workspaces, sessionIds, refreshSessionList, unarchiveOne\)/);
	assert.match(client, /await registry\.deleteSession\(sessionId\);[\s\S]*await refreshSessionList\(\);/);
	assert.match(client, /await registry\.deleteArchivedSessions\(target\);[\s\S]*await refreshSessionList\(\);/);
});

test("创建时间排序从宿主归档头部读取元数据，更新时间继续使用客户端摘要", async () => {
  const client = await readFile(clientPath, "utf8");

  assert.match(client, /registry\.archivedSessionMetadata\(\)/);
  assert.match(client, /Object\.fromEntries\(result\.items\.map/);
  assert.match(client, /sortBy === "created" \? createdAtById\[session\.id\] : session\.updatedAt/);
  assert.match(client, /archives\.sortArchived/);
  assert.match(client, /sortArchivedGroups\(groups, sortBy, createdAtById, t(?:, [^)]+)?\)/);
});

test("归档元数据请求不触发会话列表刷新", async () => {
  const client = await readFile(clientPath, "utf8");
  const start = client.indexOf("const archivedSessionMetadata = async () => {");
  const end = client.indexOf("const sessionMenuSlot =", start);
  assert.ok(start >= 0 && end > start, "必须执行真实元数据请求包装器");
  const build = new Function("ctx", `${client.slice(start, end)}; return archivedSessionMetadata;`);
  const value = { items: [{ sessionId: "archived", createdAt: 42 }], repairedSessionIds: ["archived"] };
  let refreshes = 0;
  const request = build({
    get: () => ({ archivedSessionMetadata: async () => ({ ok: true, value }) }),
    sessions: { refresh: async () => { refreshes += 1; } },
  });
  assert.equal(await request(), value);
  assert.equal(refreshes, 0, "即使旧服务返回补缓存标记，元数据读取也不应触发全量刷新");
});

test("归档设置页占满宿主内容区，侧栏入口使用简短归档标签", async () => {
  const client = await readFile(clientPath, "utf8");

  assert.match(client, /\.dsham_settings\{[^}]*width:100%/);
  assert.doesNotMatch(client, /\.dsham_settings\{[^}]*max-width:760px/);
  assert.match(client, /label: \(\) => ctx\.locale\.bind\(NS\)\("archived\.badge"\)/);
});

test("归档设置页下拉菜单不强制宿主主题", async () => {
  const client = await readFile(clientPath, "utf8");

  assert.doesNotMatch(client, /\.dsham_settingsFilter\{color-scheme:/);
  assert.doesNotMatch(client, /AntdProvider/);
  assert.match(client, /SegmentedTabs/);
});

test("单条删除与批量删除分别调用宿主单会话和作用域接口", async () => {
  const client = await readFile(clientPath, "utf8");

  assert.match(client, /await deleteSession\(deleteTarget\.session\.id\)/);
  assert.match(client, /await deleteArchivedSessions\(target\)/);
  // 批量删除必须恒定走宿主作用域接口。organizeBatch 恒为真时，旧守卫会让这条路径失效。
  assert.doesNotMatch(client, /executeBatch\("delete"/);
  // 客户端级联收集（collect*）已按 clean cutover 移除，不得回归。
  assert.doesNotMatch(client, /collectSessionAndDescendantIds|collectArchivedDeleteAllIds/);
});

test("批量删除反馈区分真正删除与陈旧归档记录清理", async () => {
  const client = await readFile(clientPath, "utf8");

  assert.match(client, /archivedDeleteFeedback\(result, t\)/);
  assert.match(client, /"archives\.deleteSkipped"/);
  assert.doesNotMatch(client, /deletedSessionIds\.length \+ result\.skippedSessionIds\.length/);
});

test("单条恢复按会话阻止重复提交，并在请求结束后释放", async () => {
  const client = await readFile(clientPath, "utf8");

  assert.match(client, /unarchivingSessionIdsRef\.current\.has\(sessionId\)/);
  assert.match(client, /unarchivingSessionIdsRef\.current\.add\(sessionId\)/);
  assert.match(client, /unarchivingSessionIdsRef\.current\.delete\(sessionId\)/);
  assert.match(client, /disabled: busy \|\| unarchivingSessionIds\.has\(session\.id\)/);
});

test("删除文案中英键齐全，并统一使用子代理用语", async () => {
  const client = await readFile(clientPath, "utf8");
  assert.match(client, /"deleteSession.unknown": "会话已不存在或已被删除。"/);
  assert.match(client, /"deleteSession.unknown": "This session no longer exists or was already deleted."/);
  assert.match(client, /"deleteSession.failed": "删除会话失败：{detail}"/);
  assert.match(client, /"deleteSession.failed": "Could not delete the session: {detail}"/);
  assert.match(client, /及其子代理（含正在运行的）/);
  assert.match(client, /their child agents \(including any that are still running\)/);
  assert.doesNotMatch(client, /及其子会话和记录/);
  assert.match(client, /isUnknownSessionError\(reason\)/);
  assert.match(client, /"archives.archiveFailed": "归档失败：{detail}"/);
  assert.match(client, /"archives.archiveFailed": "Could not archive the session: {detail}"/);
});

test("归档设置页筛选使用宿主官方原语 Menu，而不是原生 select 或 AntdSelect", async () => {
  const client = await readFile(clientPath, "utf8");

  assert.match(client, /function ArchiveProjectSelect/);
  assert.match(client, /Menu/);
  assert.doesNotMatch(client, /className: "dsham_selectMenu"/);
  assert.doesNotMatch(client, /\.dsham_selectMenu\{/);
  assert.doesNotMatch(client, /\.dsham_selectOption/);
  assert.doesNotMatch(client, /dsham_selectTrigger/);
  assert.doesNotMatch(client, /jsx\)\("select", \{ className: "dsham_settingsFilter"/);
});

test("批量计数直接取归档集合与 workspace 记账，不依赖摘要是否已加载", async () => {
  const client = await readFile(clientPath, "utf8");

  assert.doesNotMatch(client, /allBatchTarget/);
  assert.match(client, /const accounted = new Set\(items\.find/);
  assert.match(client, /const accounted = new Set\(items\.flatMap/);
  assert.doesNotMatch(client, /allBatchSessionIds = \(0, react\.useMemo\)\(\(\) => groups\.flatMap/);
});

test("每个项目分组提供恢复全部与删除全部菜单", async () => {
  const client = await readFile(clientPath, "utf8");

  assert.match(client, /function ArchivedGroupActions/);
  assert.match(client, /archives\.restoreProject/);
  assert.match(client, /archives\.deleteProject/);
  assert.match(client, /id: "restore",[\s\S]*?IconUnarchiveOutlineMedium/);
  assert.match(client, /moreIcon\(\)/);
  assert.match(client, /archivedBatchTargetForGroup\(group\.key\)/);
  assert.match(client, /archives\.deleteProjectDesc/);
});

test("未分组批量菜单使用简短文案", async () => {
  const client = await readFile(clientPath, "utf8");

  assert.match(client, /"archives\.restoreUngrouped": "全部恢复"/);
  assert.match(client, /"archives\.deleteUngrouped": "全部删除"/);
  assert.match(client, /"archives\.restoreUngrouped": "Restore all"/);
  assert.match(client, /"archives\.deleteUngrouped": "Delete all"/);
});

test("项目筛选与分组使用 workspaceId 作为 key，选中项消失时回退所有项目", async () => {
  const client = await readFile(clientPath, "utf8");

  assert.match(client, /key: workspace\.workspaceId/);
  assert.match(client, /value: group\.key, label: group\.title/);
  assert.match(client, /project === "all" \|\| project === group\.key/);
  assert.match(client, /setProject\("all"\)/);
  // 分组渲染 key 与筛选 value 不再使用允许重名的 title。
  assert.doesNotMatch(client, /\}, group\.title\)\)/);
});

test("确认框按 Escape 只关闭最上层，不关掉设置页", async () => {
  const client = await readFile(clientPath, "utf8");

  assert.match(client, /window\.addEventListener\("keydown", onKeyDown, true\)/);
  assert.match(client, /event\.stopImmediatePropagation/);
  assert.match(client, /if \(event\.key !== "Escape"\) return;/);
});

test("Issue #91: settings.section 使用专用 id archive-manager 并具备 try/catch fail-soft 运行时防护", async () => {
  const client = await readFile(clientPath, "utf8");

  assert.match(client, /name:\s*"settings\.section",[\s\S]*?id:\s*"archive-manager"/);
  assert.match(client, /ctx\.slots\.inject\("settings\.section",\s*\(\)\s*=>\s*\{[\s\S]*?try\s*\{[\s\S]*?ctx\.slots\.register\([\s\S]*?catch\s*(?:\([^)]*\))?\s*\{/);
  assert.doesNotMatch(client, /name:\s*"settings\.section",[\s\S]*?id:\s*"archived-sessions"/);
});

