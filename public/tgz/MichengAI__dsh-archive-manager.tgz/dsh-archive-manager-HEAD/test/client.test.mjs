// dsh-archive-manager client bundle self-tests (node:test).
//
// 使用当前 DSH 的 client-store 实例化已归档会话管理客户端 bundle。其余 static module table
// (react, cordis, ui-slots,
// ui-primitives, ...) resolved from the dsh flat module fallback through the
// test 目录的 `node_modules` junction。覆盖客户端自身的派生
// functions and store through its `__test` export.
import { test } from "node:test";
import { renderToStaticMarkup } from "react-dom/server";
import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import { pathToFileURL } from "node:url";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";
import semver from "semver";

const FALLBACK = fileURLToPath(new URL("../node_modules", import.meta.url));

// --- real static module table (mirror of dsh-client-web getStaticModules) ---
import { createRequire } from "node:module";
const requireFallback = createRequire(import.meta.url);
const statics = {};
for (const spec of [
	"react",
	"react/jsx-runtime",
	"react-dom",
	"react-dom/client",
	"@deepseek-ai/cordis",
	"@deepseek-ai/dsh-client-ui-slots"
]) {
	statics[spec] = await import(pathToFileURL(requireFallback.resolve(spec)).href);
}
const { loadClientStore } = await import("./helpers/client-store.mjs");
const { exports: { defineStore } } = await loadClientStore();
// The primitives package imports CSS through its bundler pipeline, which
// 纯 Node ESM 无法加载；客户端仅在组件
// bodies, so a no-op facade suffices for materialization + derivation tests.
statics["@deepseek-ai/dsh-client-ui-primitives"] = new Proxy({}, {
	get: (target, prop) => {
		if (typeof prop === "string") target[prop] = () => null;
		return target[prop];
	}
});

// --- browser environment stubs for bundle materialization ---
globalThis.window = globalThis;
const styleStub = { dataset: {}, style: {}, setAttribute() {}, appendChild() {}, set textContent(v) {} };
const headStub = { appendChild() {}, removeChild() {}, insertBefore() {}, contains: () => false, querySelector: () => null, querySelectorAll: () => [] };
globalThis.document = {
	head: headStub,
	body: headStub,
	querySelector: (selector) => selector === "head" || selector === "body" ? headStub : null,
	querySelectorAll: () => [],
	createElement: () => styleStub
};
globalThis.getComputedStyle = () => ({ getPropertyValue: () => "" });

// --- minimal client module system ---
const factories = new Map();
window.__ModuleLoader__ = { load: (handoff) => { factories.set(handoff.id, handoff.factory); } };

async function loadBundle(absolutePath) {
	await import(pathToFileURL(absolutePath).href);
}

function materialize(id, options = {}) {
	const staticModules = options.staticModules ?? statics;
	const requests = options.requests;
	const factory = factories.get(id);
	if (factory === void 0) throw new Error(`no factory registered for ${id}`);
	const module = { exports: {} };
	const require = (spec) => {
		requests?.push(spec);
		if (Object.hasOwn(staticModules, spec)) return staticModules[spec];
		const stripped = spec.endsWith("/client") ? spec.slice(0, -7) : spec;
		if (stripped !== id && factories.has(stripped)) return materialize(stripped, options);
		throw new Error(`smoke require miss: ${spec}`);
	};
	// The factory owns its own `module`/`exports` closure; its return value is
	// the authoritative exports object (mirrors the real loader).
	return factory(require, module, module.exports) ?? module.exports;
}

const CLIENT_BUNDLE = fileURLToPath(new URL("../lib/client.js", import.meta.url));
const PACKAGE_MANIFEST = JSON.parse(await readFile(fileURLToPath(new URL("../package.json", import.meta.url)), "utf8"));

await loadBundle(CLIENT_BUNDLE);
const alphaRequests = [];
const bundle = materialize("@michengai/dsh-archive-manager", {
	requests: alphaRequests,
	staticModules: {
		...statics,
		"@deepseek-ai/dsh-client-store": { defineStore }
	}
});

const t = bundle.__test;

test("分叉失败向列表提示回调报告错误，成功时不提示", async () => {
  const messages = [];
  const translate = (key, values) => `${key}: ${values?.detail ?? ""}`;
  await t.forkWithFeedback("session-a", async () => { throw new Error("分叉失败"); }, message => messages.push(message), translate);
  assert.equal(messages.length, 1);
  assert.match(messages[0], /分叉失败/);
  await t.forkWithFeedback("session-a", async () => {}, message => messages.push(message), translate);
  assert.equal(messages.length, 1);
});

test("完整客户端中英文词条和占位符对应", () => {
  assert.deepEqual(Object.keys(t.zh).sort(), Object.keys(t.en).sort());
  for (const key of Object.keys(t.zh)) {
    assert.deepEqual((t.zh[key].match(/\{\w+\}/g) ?? []).sort(), (t.en[key].match(/\{\w+\}/g) ?? []).sort(), key);
  }
});

function summary(id, extra = {}) {
	return { id, displayTitle: `Title-${id}`, origin: "root", blank: false, running: false, updatedAt: 1, ...extra };
}

const list = {
	current: void 0,
	ids: ["s1", "s2", "s3"],
	byId: { s1: summary("s1"), s2: summary("s2"), s3: summary("s3") }
};
const workspaces = [
	{ workspaceId: "w1", path: "D:\\proj-a", title: "proj-a", createdAt: "2026-01-01T00:00:00.000Z", sessionIds: ["s1", "s2"] },
	{ workspaceId: "w2", path: "D:\\proj-b", title: "proj-b", createdAt: "2026-01-01T00:00:00.000Z", sessionIds: ["s3"] }
];
const noPendingInteractions = new Map();

test("bundle materializes with apply/inject and the __test surface", () => {
	assert.equal(typeof bundle.apply, "function");
	assert.deepEqual(bundle.inject, ["slots", "sessions", "workspaces", "locale", "remote", "typert"]);
	assert.equal(typeof t.sessionVisible, "function");
	assert.equal(typeof t.deriveGroups, "function");
	assert.equal(typeof t.deriveFlat, "function");
	assert.equal(typeof t.deriveSearchResults, "function");
	assert.equal(typeof t.displayTitle, "function");
	assert.equal(typeof t.isUnknownSessionError, "function");
	assert.equal(typeof t.isWorkspaceTaskCandidate, "function");
	assert.equal(typeof t.isWorkspaceDeleteMenuItem, "function");
	assert.equal(typeof t.workspaceMenuTriggerFrom, "function");
	assert.equal(typeof t.applySettingsNavIcon, "function");
	assert.equal(typeof t.restoreSettingsNavIcon, "function");
});

test("设置页批量恢复串行调用官方 unarchiveSession", async () => {
	const archived = ["s1", "s2", "s3"];
	const calls = [];
	const workspaces = {
		list: { getSnapshot: () => ({ archivedSessionIds: [...archived] }) },
		async unarchiveSession(id) {
			calls.push(id);
			const i = archived.indexOf(id);
			if (i !== -1) archived.splice(i, 1);
		}
	};
	const result = await t.unarchiveSessionsViaOfficial(workspaces, ["s1", "s1", "s3"], async () => {});
	assert.deepEqual(calls, ["s1", "s3"]);
	assert.deepEqual(result.unarchivedSessionIds, ["s1", "s3"]);
	assert.deepEqual(result.archivedSessionIds, ["s2"]);
});

test("restore requires the official unarchiveSession", async () => {
	const official = [];
	const unarchive = t.createUnarchiveSession({
		async unarchiveSession(id) {
			official.push(id);
		}
	});
	await unarchive("s1");
	assert.deepEqual(official, ["s1"]);
	await assert.rejects(() => t.createUnarchiveSession({})("s1"), /host unarchiveSession is unavailable/);
});

test("设置页与侧栏批量归档串行调用官方 archiveSession", async () => {
	const archived = [];
	const calls = [];
	const workspaces = {
		list: { getSnapshot: () => ({ archivedSessionIds: [...archived] }) },
		async archiveSession(id) {
			calls.push(id);
			if (!archived.includes(id)) archived.push(id);
		}
	};
	const result = await t.archiveSessionsViaOfficial(workspaces, ["s1", "s1", "s2"], async () => {});
	assert.deepEqual(calls, ["s1", "s2"]);
	assert.deepEqual(result.archivedSessionIdsAdded, ["s1", "s2"]);
	assert.deepEqual(result.archivedSessionIds, ["s1", "s2"]);
});

test("批量归档记下单条失败并继续后续", async () => {
	const archived = [];
	const calls = [];
	const workspaces = {
		list: { getSnapshot: () => ({ archivedSessionIds: [...archived] }) },
		async archiveSession(id) {
			calls.push(id);
			if (id === "s2") throw new Error("host rejected s2");
			if (!archived.includes(id)) archived.push(id);
		}
	};
	const result = await t.archiveSessionsViaOfficial(workspaces, ["s1", "s2", "s3"], async () => {});
	assert.deepEqual(calls, ["s1", "s2", "s3"]);
	assert.deepEqual(archived, ["s1", "s3"]);
	assert.deepEqual(result.archivedSessionIdsAdded, ["s1", "s3"]);
	assert.deepEqual(result.failures, [{ sessionId: "s2", message: "host rejected s2" }]);
});

test("运行中的会话记入失败并保留会话 ID，不中断后续", async () => {
	const archived = [];
	const workspaces = {
		list: { getSnapshot: () => ({ archivedSessionIds: [...archived] }) },
		async archiveSession(id) {
			if (id === "s9") {
				const error = new Error("active");
				error.name = "WorkspaceActiveSessionError";
				error.activity = [{ kind: "turn" }];
				throw error;
			}
			archived.push(id);
		}
	};
	const result = await t.archiveSessionsViaOfficial(workspaces, ["s9", "s1"]);
	assert.deepEqual(result.failures, [{ sessionId: "s9", message: "active" }]);
	assert.deepEqual(result.archivedSessionIdsAdded, ["s1"]);
});

test("active archive refusals expose their activity kinds", () => {
	assert.deepEqual(t.activeSessionRefusal({ name: "WorkspaceActiveSessionError", sessionId: "s2", activity: [{ kind: "turn" }] }), { sessionId: "s2", kinds: ["turn"] });
	assert.deepEqual(t.activeArchiveFromMessage("s2", "cannot archive session 's2': the session is active (turn, job)"), { sessionId: "s2", kinds: ["turn", "job"] });
	assert.deepEqual(t.activeSessionActivity({ name: "WorkspaceActiveSessionError", activity: [{ kind: "turn" }, { kind: "job" }] }), ["turn", "job"]);
	assert.deepEqual(t.activeSessionActivity({
		name: "WorkspaceArchiveError",
		rpcError: { code: "workspace/session-active", details: { activity: [{ kind: "subagent" }] } },
	}), ["subagent"]);
	assert.equal(t.activeSessionActivity(new Error("archive failed")), undefined);
});

test("legacy workspace view prefs migrate onto the archive-manager persist key", () => {
	const storage = new Map([
		["dsh.workspace.view.v5", JSON.stringify({ groupBy: "flat", orderBy: "title", groupExpansion: { w1: false } })],
	]);
	const migrated = t.migrateWorkspaceViewPersist({
		getItem: (key) => storage.get(key) ?? null,
		setItem: (key, value) => storage.set(key, value),
	});
	assert.equal(migrated, true);
	assert.equal(
		storage.get("dsh.archive-manager.workspace.view.v1"),
		JSON.stringify({ groupBy: "flat", orderBy: "title", groupExpansion: { w1: false } }),
	);
	assert.equal(
		t.migrateWorkspaceViewPersist({
			getItem: (key) => storage.get(key) ?? null,
			setItem: (key, value) => storage.set(key, value),
		}),
		false,
		"already-migrated prefs must not be overwritten",
	);
});

test("工作区归档与官方侧栏一致：保留 IM 与定时任务，排除子代理、空白和已归档会话", () => {
	const archived = new Set(["archived-1"]);
	const sessionMap = {
		"normal-1": { origin: "chat", blank: false },
		"blank-1": { origin: "chat", blank: true },
		"subagent-1": { origin: "subagent", blank: false },
		"im-origin-1": { origin: "im", blank: false },
		"im:weixin_123": { origin: "chat", blank: false },
		"dsh-automation-session-456": { origin: "chat", blank: false }
	};
	assert.equal(t.isWorkspaceTaskCandidate("normal-1", sessionMap, archived), true);
	assert.equal(t.isWorkspaceTaskCandidate("blank-1", sessionMap, archived), false);
	assert.equal(t.isWorkspaceTaskCandidate("archived-1", sessionMap, archived), false);
	assert.equal(t.isWorkspaceTaskCandidate("subagent-1", sessionMap, archived), false);
	assert.equal(t.isWorkspaceTaskCandidate("im-origin-1", sessionMap, archived), true, "IM 会话不再排除");
	assert.equal(t.isWorkspaceTaskCandidate("im:weixin_123", sessionMap, archived), true, "IM 渠道会话不再排除");
	assert.equal(t.isWorkspaceTaskCandidate("dsh-automation-session-456", sessionMap, archived), true, "定时任务不再排除");
	assert.equal(t.isWorkspaceTaskCandidate("missing-1", sessionMap, archived), false, "侧栏未渲染的会话不属于所见范围");
});

test("删除工作区菜单项优先按文案识别，文案变化时用 danger 类兜底", () => {
	const item = (textContent, className = "") => ({ textContent, className });
	assert.equal(t.isWorkspaceDeleteMenuItem(item("删除工作区")), true);
	assert.equal(t.isWorkspaceDeleteMenuItem(item("Delete workspace")), true);
	assert.equal(t.isWorkspaceDeleteMenuItem(item("DELETE WORKSPACE")), true);
	assert.equal(t.isWorkspaceDeleteMenuItem(item("Удалить рабочее пространство")), true);
	assert.equal(t.isWorkspaceDeleteMenuItem(item("重命名", "Menu_item__a1")), false);
	assert.equal(t.isWorkspaceDeleteMenuItem(item("Rename", "Menu_item__a1"), false), false);
	assert.equal(t.isWorkspaceDeleteMenuItem(item("Delete", "Menu_danger__a1")), true, "未知语言可由 danger 类兜底");
	assert.equal(t.isWorkspaceDeleteMenuItem(item("Delete", "Menu_danger__a1"), false), false, "禁用兜底时不得误判");
	assert.equal(t.isWorkspaceDeleteMenuItem(item("Delete", "Menu_dangerous__a1")), false, "类名包含 danger 子串不得误判");
});

test("工作区菜单上下文只认工作区行，会话行输入会清空", () => {
	const row = (key, title) => ({
		getAttribute: (name) => name === "data-row-key" ? key : null,
		querySelector: (selector) => selector.includes("title") ? { textContent: title } : null,
	});
	const targetIn = (element) => ({ closest: (selector) => selector === "[data-row-key]" ? element : null });
	assert.deepEqual(t.workspaceMenuTriggerFrom(targetIn(row("workspace:w1", " proj-a "))), { workspaceId: "w1", title: "proj-a" });
	assert.deepEqual(t.workspaceMenuTriggerFrom(targetIn({ getAttribute: () => "workspace:w2", querySelector: () => null })), { workspaceId: "w2", title: "w2" });
	assert.equal(t.workspaceMenuTriggerFrom(targetIn(row("session:s1", "chat"))), null, "会话行不得复用上一个工作区");
	assert.equal(t.workspaceMenuTriggerFrom(targetIn(row("overflow:w1", "more"))), null);
	assert.equal(t.workspaceMenuTriggerFrom(targetIn(row("workspace:", "empty"))), null);
	assert.equal(t.workspaceMenuTriggerFrom({ closest: () => null }), null, "菜单与空白区域必须清空上下文");
	assert.equal(t.workspaceMenuTriggerFrom(null), null);
});

test("设置导航图标使用独立 mask 注入，不改写宿主 svg", async () => {
	const source = await readFile(fileURLToPath(new URL("../src/client.ts", import.meta.url)), "utf8");
	const built = await readFile(CLIENT_BUNDLE, "utf8");
	for (const text of [source, built]) {
		assert.match(text, /data-dsham-nav-icon/, "必须带独立标记属性");
		assert.match(text, /::before/, "必须使用 ::before 伪元素渲染图标");
		assert.match(text, />\s*svg\s*\{[^}]*display:\s*none/, "必须隐藏宿主 svg");
	}
	assert.match(source, /width:calc\(\(100% - 4px\)\/2\)!important/, "分段指示器必须与 2px 内边距对齐");

	const svg = { tagName: "svg" };
	const button = {
		textContent: "归档会话",
		attributes: new Map(),
		children: [svg],
		getAttribute(name) { return this.attributes.get(name) ?? null; },
		hasAttribute(name) { return this.attributes.has(name); },
		setAttribute(name, value) { this.attributes.set(name, String(value)); },
		removeAttribute(name) { this.attributes.delete(name); },
		querySelector(selector) {
			if (selector === ":scope > svg") return svg;
			if (selector === "svg") return svg;
			return null;
		},
	};
	assert.equal(t.applySettingsNavIcon(button, "归档会话"), true);
	assert.equal(button.getAttribute("data-dsham-nav-icon"), "");
	assert.equal(button.children.length, 1, "禁止向 button 插入任何真实 DOM 节点");
	assert.equal(button.children[0], svg, "宿主 svg 结构保持原样");
	assert.equal(t.applySettingsNavIcon(button, "归档会话"), false, "重复同步必须幂等");
	assert.equal(t.applySettingsNavIcon(button, "其他入口"), true, "切换非本插件入口时应清除标记");
	assert.equal(button.hasAttribute("data-dsham-nav-icon"), false);
	assert.equal(t.applySettingsNavIcon(button, "其他入口"), false, "已无标记时不重复处理");
	t.applySettingsNavIcon(button, "归档会话");
	assert.equal(button.hasAttribute("data-dsham-nav-icon"), true);
	assert.equal(t.restoreSettingsNavIcon(button), true);
	assert.equal(button.getAttribute("data-dsham-nav-icon"), null);
});

test("设置导航图标样式在安装时全局注入，卸载时清理", () => {
	const previous = {
		getElementById: document.getElementById,
		createElement: document.createElement,
		head: document.head,
		observer: globalThis.MutationObserver,
		raf: globalThis.requestAnimationFrame,
	};
	const style = { id: "", textContent: "", removed: false, remove() { this.removed = true; } };
	let appended = false;
	document.getElementById = () => null;
	document.createElement = (tag) => (tag === "style" ? style : { id: "" });
	document.head = { append(node) { assert.equal(node, style); appended = true; } };
	globalThis.MutationObserver = class {
		constructor(callback) { this.callback = callback; }
		observe() {}
		disconnect() { this.disconnected = true; }
	};
	globalThis.requestAnimationFrame = (fn) => { fn(); return 1; };
	let disposer;
	try {
		t.installSettingsNavIcon({
			effect: (run) => { disposer = run(); },
			locale: { bind: () => () => "归档会话" },
		});
		assert.equal(appended, true, "样式必须在插件安装时就注入，而不是等归档页渲染");
		assert.equal(style.id, "dsham-nav-icon-style");
		assert.match(style.textContent, /data-dsham-nav-icon/);
		assert.match(style.textContent, /::before/);
		assert.match(style.textContent, />\s*svg\s*\{[^}]*display:\s*none/);
		disposer();
		assert.equal(style.removed, true, "卸载时必须移除注入样式");
	} finally {
		document.getElementById = previous.getElementById;
		document.createElement = previous.createElement;
		document.head = previous.head;
		if (previous.observer === undefined) delete globalThis.MutationObserver;
		else globalThis.MutationObserver = previous.observer;
		if (previous.raf === undefined) delete globalThis.requestAnimationFrame;
		else globalThis.requestAnimationFrame = previous.raf;
	}
});

test("DOM 监听只处理触及目标选择器的变更批次", () => {
	const menu = {};
	const element = ({ matches = () => false, descendant = () => null, ancestor = () => null }) => ({
		nodeType: 1,
		matches,
		querySelector: descendant,
		closest: ancestor,
	});
	assert.equal(t.mutationTouches([{ type: "childList", addedNodes: [element({ matches: () => true })] }], '[role="menu"]'), true);
	assert.equal(t.mutationTouches([{ type: "childList", addedNodes: [element({ descendant: () => ({}) })] }], '[role="menu"]'), true);
	assert.equal(t.mutationTouches([{ type: "childList", addedNodes: [element({ ancestor: () => menu })] }], '[role="menu"]'), true);
	assert.equal(t.mutationTouches([{ type: "childList", addedNodes: [element({})] }], '[role="menu"]'), false, "无关节点不应触发扫描");
	assert.equal(t.mutationTouches([{ type: "childList", addedNodes: [{ nodeType: 3 }] }], '[role="menu"]'), false, "文本节点无需扫描");
	assert.equal(t.mutationTouches([{ type: "characterData", target: { parentElement: { closest: () => menu } } }], '[role="menu"]'), true);
	assert.equal(t.mutationTouches([{ type: "characterData", target: { parentElement: { closest: () => null } } }], '[role="menu"]'), false);
	assert.equal(t.mutationTouches([{ type: "characterData", target: { parentElement: null } }], '[role="menu"]'), false);
});

test("legacy forked row stylesheet is completely removed from source and build", async () => {
	const source = await readFile(fileURLToPath(new URL("../src/client.ts", import.meta.url)), "utf8");
	const built = await readFile(CLIENT_BUNDLE, "utf8");
	for (const text of [source, built]) {
		assert.equal(text.includes("YDXeBa_"), false);
		assert.equal(text.includes(".dshamRow_projectRow"), false);
		assert.equal(source.includes("ctx.sessions.open("), false);
	}
	const injected = [];
	const previous = document.createElement;
	const previousQuery = document.querySelector;
	const previousAppend = document.head.appendChild;
	document.querySelector = () => null;
	document.createElement = (name) => {
		const tag = { dataset: {}, textContent: "" };
		return name === "style" ? tag : previous(name);
	};
	document.head.appendChild = (tag) => { injected.push(tag.dataset.pluginCss); };
	try {
		materialize("@michengai/dsh-archive-manager", { staticModules: { ...statics, "@deepseek-ai/dsh-client-store": { defineStore } } });
	} finally {
		document.createElement = previous;
		document.querySelector = previousQuery;
		document.head.appendChild = previousAppend;
	}
	assert.equal(injected.includes("@michengai/dsh-archive-manager/Rows.module.css"), false);
	assert.equal(injected.includes("@michengai/dsh-archive-manager/WorkspaceBrowser.module.css"), false);
	assert.equal(injected.includes("@michengai/dsh-archive-manager/WorkspacePicker.module.css"), false);
});

test("bundle resolves the current client-store", () => {
	assert.equal(alphaRequests.includes("@deepseek-ai/dsh-client-store"), true);
	assert.equal(alphaRequests.includes("@deepseek-ai/dsh-client-runtime/client"), false);
	assert.equal(typeof bundle.__test.createWorkspaceViewStore().create, "function");
});

test("manifest keeps one DSH peer range; store optional; ghost client-runtime peer removed", () => {
	assert.equal(PACKAGE_MANIFEST.engines?.node, "^22.19.0 || >=24.0.0");
	assert.equal(PACKAGE_MANIFEST.engines?.dsh, ">=0.2.0-rc.1 <0.3.0-0");
	assert.equal(PACKAGE_MANIFEST.packageManager, "pnpm@11.22.0");
	const dshPeerRanges = Object.entries(PACKAGE_MANIFEST.peerDependencies ?? {})
		.filter(([name]) => name.startsWith("@deepseek-ai/dsh-"))
		.map(([, range]) => range);
	const dshDevelopmentVersions = Object.entries(PACKAGE_MANIFEST.devDependencies ?? {})
		.filter(([name]) => name.startsWith("@deepseek-ai/dsh-"))
		.map(([, version]) => version);
	assert.ok(dshPeerRanges.length > 0);
	assert.equal(new Set(dshPeerRanges).size, 1);
	assert.equal(dshPeerRanges[0], ">=0.2.0-rc.1 <0.3.0-0");
	for (const version of ["0.2.0-rc.1", "0.2.0-rc.2", "0.2.1-rc.1", "0.2.1-rc.2", "0.2.1-rc.3", "0.2.1-rc.4", "0.2.2-alpha.1", "0.2.2-rc.1", "0.2.9"]) {
		assert.ok(semver.satisfies(version, dshPeerRanges[0], { includePrerelease: true }), `peer 范围必须接纳 0.2.x 代际版本 ${version}`);
	}
	for (const version of ["0.1.0-rc.8", "0.1.1-rc.2", "0.1.2-rc.1", "0.1.5-rc.1", "0.1.5-rc.2", "0.1.5-rc.3", "0.1.6-alpha.1", "0.1.6-alpha.2", "0.1.7-alpha.1", "0.1.7-rc.1", "0.1.7-rc.2", "0.2.0-alpha.1", "0.3.0-alpha.1", "0.3.0-rc.1", "0.3.0", "1.0.0"]) {
		assert.equal(semver.satisfies(version, dshPeerRanges[0], { includePrerelease: true }), false, `不接纳超出 0.2 代际版本 ${version}`);
	}
	assert.ok(dshDevelopmentVersions.length > 0);
	assert.deepEqual([...new Set(dshDevelopmentVersions)], ["0.2.1-rc.3"]);
	assert.equal(PACKAGE_MANIFEST.peerDependenciesMeta?.["@deepseek-ai/dsh-client-store"], undefined);
	assert.equal(PACKAGE_MANIFEST.peerDependenciesMeta?.["@deepseek-ai/dsh-client-runtime"], undefined);
	assert.equal(PACKAGE_MANIFEST.peerDependencies?.["@deepseek-ai/dsh-client-runtime"], undefined);
	assert.equal(PACKAGE_MANIFEST.dsh.client.inject.includes("@deepseek-ai/dsh-client-runtime"), false);
});

test("bindObservable preserves receiver-sensitive alpha store methods", () => {
	const source = {
		value: 42,
		getSnapshot() {
			return this.value;
		},
		subscribe(listener) {
			assert.equal(this, source);
			listener(this.value);
			return () => {};
		}
	};
	const bound = t.bindObservable(source);
	assert.equal(bound.getSnapshot(), 42);
	let observed;
	bound.subscribe((value) => { observed = value; });
	assert.equal(observed, 42);
});

test("归档导航绑定走 effect，即使上下文带 inject 也不调用它", async () => {
	let injected = 0;
	const effects = [];
	const ctx = {
		get: () => undefined,
		sessions: {},
		workspaces: {},
		slots: { inject: () => () => {}, register: () => () => {} },
		effect(_fn, label) { effects.push(label); return () => {}; },
		inject() { injected += 1; return () => {}; },
	};
	const dispose = await bundle.apply(ctx);
	assert.equal(injected, 0);
	assert.ok(effects.includes("archive-manager: explicit archived navigation"));
	await dispose();
});

test("侧栏不再替换官方列表，打开和分叉交给宿主导航", async () => {
	const registrations = new Map();
	const ctx = {
		get: () => undefined,
		sessions: { open() {}, fork: async () => "fork" },
		workspaces: {},
		slots: {
			inject: (name, callback) => name === "archiveManager.sidebar.directoryFlow" ? () => {} : callback(),
			register: (options) => registrations.set(options.name, options)
		},
		effect() {}
	};
	const dispose = await bundle.apply(ctx);
	assert.equal(registrations.has("sidebar.workspaces"), false);
	await dispose();
});

test("Typert remotes 同时带 create 和 schema", () => {
	for (const descriptor of t.ARCHIVE_MANAGER_REMOTE.descriptors) {
		assert.equal(typeof descriptor.result.create, "function");
		assert.equal(descriptor.result.create(), descriptor.result.schema);
		for (const parameter of descriptor.parameters) {
			assert.equal(typeof parameter.codec.create, "function");
			assert.equal(parameter.codec.create(), parameter.codec.schema);
		}
	}
});

test("deriveGroups: 当前会话优先 retainedBy.mainView，没有再看 list.current", () => {
	const view = { expandedGroups: ["w1", "w2"], showArchived: false };
	const withCurrent = t.deriveGroups({ ...list, current: "s3" }, workspaces, [], noPendingInteractions, view);
	assert.equal(withCurrent.find((g) => g.workspaceId === "w2").containsCurrent, false);
	const staleCurrent = t.deriveGroups({
		...list,
		current: "s1",
		byId: {
			s1: summary("s1"),
			s2: summary("s2"),
			s3: summary("s3", { retainedBy: { mainView: 1 } })
		}
	}, workspaces, [], noPendingInteractions, view);
	assert.equal(staleCurrent.find((g) => g.workspaceId === "w2").containsCurrent, true);
	assert.equal(staleCurrent.find((g) => g.workspaceId === "w1").containsCurrent, false);
	const withMainView = t.deriveGroups({
		ids: list.ids,
		byId: {
			s1: summary("s1"),
			s2: summary("s2"),
			s3: summary("s3", { retainedBy: { mainView: 1 } })
		}
	}, workspaces, [], noPendingInteractions, view);
	assert.equal(withMainView.find((g) => g.workspaceId === "w2").containsCurrent, true);
	assert.equal(withMainView.find((g) => g.workspaceId === "w1").containsCurrent, false);
});

test("derive* 把 completionUnread 投影为完成态", () => {
	const facts = { pending: new Map(), completed: new Set(["s1"]) };
	const view = { expandedGroups: ["w1"], showArchived: false };
	const groups = t.deriveGroups(list, workspaces, [], facts, view);
	assert.equal(groups.find((g) => g.workspaceId === "w1").sessions.find((s) => s.id === "s1").completed, true);
	const search = t.deriveSearchResults(list, workspaces, "Title", [], facts, { items: [], hasMore: false }, 50, false);
	assert.equal(search.items.find((s) => s.id === "s1").completed, true);
});

test("displayTitle: SessionSummary 使用 displayTitle，包括未命名会话", () => {
	assert.equal(t.displayTitle(summary("s1"), (key) => key), "Title-s1");
	assert.equal(t.displayTitle(summary("s2", { displayTitle: "" }), (key) => key), "");
	assert.equal(t.displayTitle({ id: "s3", blank: false }, (key) => key), "");
});

test("sessionVisible: archived hidden by default, visible with showArchived", () => {
	const archived = new Set(["s2"]);
	assert.equal(t.sessionVisible(summary("s1"), void 0, archived, false), true);
	assert.equal(t.sessionVisible(summary("s2"), void 0, archived, false), false);
	assert.equal(t.sessionVisible(summary("s2"), void 0, archived, true), true);
	assert.equal(t.sessionVisible(summary("s2"), void 0, archived), false); // default undefined
	assert.equal(t.sessionVisible(summary("s9", { origin: "subagent" }), void 0, archived, true), false);
});

test("deriveGroups: archived rows appear in their workspace group with the archived flag when shown", () => {
	const archived = ["s2"];
	const view = { expandedGroups: ["w1", "w2"], showArchived: false };
	const hidden = t.deriveGroups(list, workspaces, archived, noPendingInteractions, view);
	const w1 = hidden.find((g) => g.workspaceId === "w1");
	assert.deepEqual(w1.sessions.map((s) => s.id), ["s1"]);
	const shown = t.deriveGroups(list, workspaces, archived, noPendingInteractions, { ...view, showArchived: true });
	const w1b = shown.find((g) => g.workspaceId === "w1");
	assert.deepEqual(w1b.sessions.map((s) => s.id), ["s1", "s2"]);
	assert.equal(w1b.sessions.find((s) => s.id === "s2").archived, true);
	assert.equal(w1b.sessions.find((s) => s.id === "s1").archived, false);
});

test("deriveFlat: showArchived toggles archived rows with the flag", () => {
	const archived = ["s2"];
	assert.deepEqual(t.deriveFlat(list, archived, noPendingInteractions, false).map((r) => r.id).sort(), ["s1", "s3"]);
	const rows = t.deriveFlat(list, archived, noPendingInteractions, true);
	assert.deepEqual(rows.map((r) => r.id).sort(), ["s1", "s2", "s3"]);
	assert.equal(rows.find((r) => r.id === "s2").archived, true);
});

test("derive* 从 ui-session 的 pendingInteractions Map 读取待处理交互", () => {
	const pending = new Map([
		["s1", { kind: "question" }],
		["s2", { kind: "approval" }],
		["s3", { kind: "unknown-kind" }]
	]);
	const view = { expandedGroups: ["w1", "w2"], showArchived: true };

	const groups = t.deriveGroups(list, workspaces, [], pending, view);
	assert.equal(groups.find((g) => g.workspaceId === "w1").sessions.find((s) => s.id === "s1").pendingInteraction, "question");

	const flat = t.deriveFlat(list, [], pending, true);
	assert.equal(flat.find((s) => s.id === "s2").pendingInteraction, "approval");
	assert.equal(flat.find((s) => s.id === "s3").pendingInteraction, void 0);

	const search = t.deriveSearchResults(list, workspaces, "Title", [], pending, { items: [], hasMore: false }, 50, true);
	assert.equal(search.items.find((s) => s.id === "s1").pendingInteraction, "question");
	assert.equal(search.items.find((s) => s.id === "s3").pendingInteraction, void 0);
});

test("deriveSearchResults: showArchived toggles archived matches with the flag", () => {
	const archived = ["s2"];
	const content = { items: [], hasMore: false };
	const base = { list, workspaces, query: "Title", archivedSessionIds: archived, content, limit: 50 };
	const hidden = t.deriveSearchResults(base.list, base.workspaces, base.query, base.archivedSessionIds, noPendingInteractions, base.content, base.limit, false);
	assert.deepEqual(hidden.items.map((r) => r.id).sort(), ["s1", "s3"]);
	const shown = t.deriveSearchResults(base.list, base.workspaces, base.query, base.archivedSessionIds, noPendingInteractions, base.content, base.limit, true);
	assert.deepEqual(shown.items.map((r) => r.id).sort(), ["s1", "s2", "s3"]);
	assert.equal(shown.items.find((r) => r.id === "s2").archived, true);
});

test("deriveSearchResults: 未分组会话按当前语言展示并可检索", () => {
	const ungrouped = summary("ungrouped", { title: "独立会话", cwd: void 0 });
	const listWithUngrouped = {
		current: void 0,
		ids: [ungrouped.id],
		byId: { [ungrouped.id]: ungrouped }
	};
	const result = t.deriveSearchResults(
		listWithUngrouped,
		[],
		"未分组",
		[],
		noPendingInteractions,
		{ items: [], hasMore: false },
		50,
		false,
		"未分组"
	);

	assert.deepEqual(result.items.map((item) => item.id), ["ungrouped"]);
	assert.equal(result.items[0].workspace, "未分组");
});

test("view store: showArchived default false, persists toggles, same store family as groupBy/orderBy", () => {
	const handle = t.createWorkspaceViewStore();
	const store = handle.create(void 0);
	assert.equal(store.getSnapshot().showArchived, false);
	store.actions.setShowArchived(true);
	assert.equal(store.getSnapshot().showArchived, true);
	store.actions.setShowArchived("yes");
	assert.equal(store.getSnapshot().showArchived, false); // coerced to boolean
	store.actions.setShowArchived(false);
	assert.equal(store.getSnapshot().showArchived, false);
	// same persistence family as the existing view prefs
	const spec = handle.spec;
	assert.equal(spec.persist, "dsh.archive-manager.workspace.view.v1");
	assert.equal(typeof spec.actions.setGroupBy, "function");
	assert.equal(typeof spec.actions.setShowArchived, "function");
});

test("isUnknownSessionError recognizes the stable delete token", () => {
	assert.equal(t.isUnknownSessionError(new Error("UNKNOWN_SESSION:session-1")), true);
	assert.equal(t.isUnknownSessionError(new Error("cannot archive session 'x': live sessions and session persistence hold no such session")), true);
	assert.equal(t.isUnknownSessionError(new Error("transcript directory remains")), false);
});

test("deriveArchivedGroups: 按工作区分组，重名工作区使用不同 key，未归入者进未分组", () => {
	const byId = {
		s1: summary("s1"),
		s2: summary("s2"),
		s3: summary("s3"),
		sub: summary("sub", { origin: "subagent", parentId: "s1" })
	};
	// 两个工作区同名 proj-a：title 相同但 workspaceId 不同。
	const items = [
		{ workspaceId: "w1", title: "proj-a", sessionIds: ["s1"] },
		{ workspaceId: "w2", title: "proj-a", sessionIds: ["s2"] }
	];
	const groups = t.deriveArchivedGroups(byId, items, ["s1", "s2", "s3", "sub"], "未分组");
	assert.deepEqual(groups.map((g) => g.key), ["w1", "w2", "__ungrouped__"]);
	assert.deepEqual(groups.map((g) => g.title), ["proj-a", "proj-a", "未分组"]);
	assert.deepEqual(groups[0].sessions.map((s) => s.id), ["s1"]);
	assert.deepEqual(groups[2].sessions.map((s) => s.id), ["s3"], "subagent 不进设置页列表");
	const keys = new Set(groups.map((g) => g.key));
	assert.equal(keys.size, groups.length, "分组 key 不得重复");
});

test("deriveArchivedGroups: 无归档会话的工作区不产出空分组", () => {
	const items = [
		{ workspaceId: "w1", title: "proj-a", sessionIds: ["s1"] },
		{ workspaceId: "w2", title: "proj-b", sessionIds: [] }
	];
	const groups = t.deriveArchivedGroups({ s1: summary("s1") }, items, ["s1"], "未分组");
	assert.deepEqual(groups.map((g) => g.key), ["w1"]);
});

test("indexSubagentDescendants stays local and counts uninterrupted lineage", () => {
	const descendants = t.indexSubagentDescendants({
		root: summary("root"),
		child: summary("child", { origin: "subagent", parentId: "root" }),
		grandchild: summary("grandchild", { origin: "subagent", parentId: "child", running: true }),
		fork: summary("fork", { origin: "fork", parentId: "root", running: true })
	});
	assert.deepEqual(descendants.get("root"), { count: 2, runningCount: 1 });
	assert.deepEqual(descendants.get("child"), { count: 1, runningCount: 1 });
	assert.equal(descendants.has("fork"), false);
});

test("sortArchivedGroups: 按更新、创建或字母顺序排列项目与组内会话且不改写输入", () => {
	const groups = [
		{ key: "w1", title: "zeta", sessions: [summary("a", { displayTitle: "Alpha", updatedAt: 10 }), summary("b", { displayTitle: "Beta", updatedAt: 30 })] },
		{ key: "w2", title: "alpha", sessions: [summary("c", { displayTitle: "Charlie", updatedAt: 20 })] }
	];
	const createdAtById = { a: 40, b: 10, c: 50 };
	const translate = (key) => key;

	const updated = t.sortArchivedGroups(groups, "updated", createdAtById, translate);
	assert.deepEqual(updated.map((group) => group.key), ["w1", "w2"]);
	assert.deepEqual(updated[0].sessions.map((session) => session.id), ["b", "a"]);

	const created = t.sortArchivedGroups(groups, "created", createdAtById, translate);
	assert.deepEqual(created.map((group) => group.key), ["w2", "w1"]);
	assert.deepEqual(created[1].sessions.map((session) => session.id), ["a", "b"]);

	const alphabetical = t.sortArchivedGroups(groups, "alphabetical", createdAtById, translate);
	assert.deepEqual(alphabetical.map((group) => group.key), ["w2", "w1"]);
	assert.deepEqual(alphabetical[1].sessions.map((session) => session.id), ["a", "b"]);
	assert.deepEqual(groups[0].sessions.map((session) => session.id), ["a", "b"], "原分组顺序保持不变");
});

test("sortArchivedGroups: 按最近归档顺序（archivedSessionIds 倒序）排列项目与组内会话", () => {
	const groups = [
		{ key: "w1", title: "zeta", sessions: [summary("a", { displayTitle: "Alpha", updatedAt: 100 }), summary("b", { displayTitle: "Beta", updatedAt: 10 })] },
		{ key: "w2", title: "alpha", sessions: [summary("c", { displayTitle: "Charlie", updatedAt: 50 })] }
	];
	// 归档顺序是 a 先归档，c 接着归档，b 最后归档（最新归档）
	const archivedOrder = ["a", "c", "b"];
	const translate = (key) => key;

	const sorted = t.sortArchivedGroups(groups, "archived", {}, translate, archivedOrder);
	// b 是最新归档（索引最大），包含 b 的 w1 排在最前；组内 b 排在 a 前面
	assert.deepEqual(sorted.map((group) => group.key), ["w1", "w2"]);
	assert.deepEqual(sorted[0].sessions.map((session) => session.id), ["b", "a"]);
	assert.deepEqual(sorted[1].sessions.map((session) => session.id), ["c"]);
});

test("deriveArchivedBatchIds: 按完整归档集合派生全部、项目和未分组批次", () => {
	const items = [
		{ workspaceId: "w1", title: "proj-a", sessionIds: ["s1", "s-missing"] },
		{ workspaceId: "w2", title: "proj-b", sessionIds: ["s2"] }
	];
	const archived = ["s1", "s-missing", "s2", "s3", "s1", ""];
	assert.deepEqual(t.deriveArchivedBatchIds(archived, items, { scope: "all" }), ["s1", "s-missing", "s2", "s3", ""], "客户端计数与宿主权威归档集合保持一致");
	assert.deepEqual(t.deriveArchivedBatchIds(archived, items, { scope: "workspace", workspaceId: "w1" }), ["s1", "s-missing"], "摘要未加载的项目会话仍计入批次");
	assert.deepEqual(t.deriveArchivedBatchIds(archived, items, { scope: "ungrouped" }), ["s3", ""], "异常空 ID 也由宿主批量清理路径处理");
	assert.deepEqual(t.deriveArchivedBatchIds(archived, items, { scope: "sessions", sessionIds: ["s3", "s1", "s1", "missing"] }), ["s1", "s3"], "显式多选仍按权威归档顺序派生");
});

test("archived selection helpers preserve cross-filter choices and prune stale sessions", () => {
	const groups = [
		{ sessions: [{ id: "s1" }, { id: "s2" }] },
		{ sessions: [{ id: "s2" }, { id: "s3" }] }
	];
	assert.deepEqual(t.archivedSessionIdsInGroups(groups), ["s1", "s2", "s3"]);
	assert.deepEqual(t.toggleArchivedSelection(["s1"], ["s2", "s3"], true), ["s1", "s2", "s3"]);
	assert.deepEqual(t.toggleArchivedSelection(["s1", "s2", "s3"], ["s2"], false), ["s1", "s3"]);
	assert.deepEqual(t.pruneArchivedSelection(["s3", "s1", "stale", "s1"], ["s1", "s2", "s3"]), ["s3", "s1"]);
});

test("archivedDeleteFeedback: skipped 会话不会计入删除成功数", () => {
	const translate = (key, params) => ({ key, params });
	const skippedOnly = t.archivedDeleteFeedback({
		deletedSessionIds: [],
		skippedSessionIds: ["stale"],
		failures: []
	}, translate);
	assert.deepEqual(skippedOnly, {
		kind: "notice",
		message: { key: "archives.deleteSkipped", params: { n: 1 } }
	});
	const mixed = t.archivedDeleteFeedback({
		deletedSessionIds: ["deleted"],
		skippedSessionIds: ["stale"],
		failures: [{ sessionId: "failed", message: "boom" }]
	}, translate);
	assert.deepEqual(mixed, {
		kind: "error",
		message: {
			key: "archives.deletePartial",
			params: { deleted: 1, skipped: 1, failed: 1, detail: "boom" }
		}
	});
});

function selectionToolbarProps(overrides = {}) {
	return { selectedCount: 5, hiddenCount: 3, allVisibleSelected: false, selectedVisibleCount: 2, visibleCount: 3, busy: false,
		t: (key, params = {}) => Object.entries(params).reduce((text, [name, value]) => text.replaceAll("{" + name + "}", String(value)), t.zh[key]),
		onToggle() {}, onClear() {}, onRestore() {}, onDelete() {}, ...overrides };
}

function toolbarElements(element) {
	if (!element || typeof element !== "object") return [];
	return [element, ...[element.props?.children].flat().flatMap(toolbarElements)];
}

test("选择栏仅在有选择时显示操作，跨筛选范围始终完整提示", () => {
	const empty = renderToStaticMarkup(t.ArchiveSelectionToolbar(selectionToolbarProps({ selectedCount: 0, hiddenCount: 0, selectedVisibleCount: 0 })));
	assert.match(empty, /全选当前筛选结果/);
	assert.doesNotMatch(empty, /<button|也将参与操作/);
	const selected = renderToStaticMarkup(t.ArchiveSelectionToolbar(selectionToolbarProps()));
	assert.match(selected, /已选 5 条/);
	assert.match(selected, /含当前未显示的 3 条，也将参与操作/);
	assert.doesNotMatch(selected, /恢复所选<|删除所选</);
	const visibleOnly = renderToStaticMarkup(t.ArchiveSelectionToolbar(selectionToolbarProps({ hiddenCount: 0 })));
	assert.doesNotMatch(visibleOnly, /也将参与操作/);
});

test("选择栏保留全选语义和操作回调，忙碌时禁用所有操作", () => {
	const calls = [];
	const props = selectionToolbarProps({ onToggle: value => calls.push(value), onClear: () => calls.push("clear"), onRestore: () => calls.push("restore"), onDelete: () => calls.push("delete") });
	const elements = toolbarElements(t.ArchiveSelectionToolbar(props));
	const checkbox = elements.find(el => typeof el.type === "function");
	assert.equal(checkbox.props.label, "全选当前筛选结果");
	assert.equal(checkbox.props.indeterminate, true);
	checkbox.props.onChange({ target: { checked: true } });
	for (const button of elements.filter(el => typeof el.props?.onClick === "function")) button.props.onClick();
	assert.deepEqual(calls, [true, "clear", "restore", "delete"]);
	const busy = toolbarElements(t.ArchiveSelectionToolbar({ ...props, busy: true }));
	assert.ok(busy.filter(el => el.type === "button" || typeof el.type === "function").every(el => el.props.disabled));
});

test("未归档列表排除已归档、子代理和空白占位，保留跨项目与未分组会话", () => {
	const byId = Object.fromEntries([
		summary("a"), summary("b"), summary("loose"), summary("old"), summary("child", {origin:"subagent"}), summary("blank", {blank:true})
	].map(item => [item.id, item]));
	assert.deepEqual(t.unarchivedSessionIds(byId, ["old"]), ["a", "b", "loose"]);
});
