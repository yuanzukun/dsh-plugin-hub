# Changelog

## 0.6.3 (2026-09-22)

- **新增「诊断」页**（捆绑客户端 → 0.6.3）。设置页新增第五个标签页，把此前只能靠手动删 AppData 解决的问题做成自助操作：
  - **WebView2 缓存**：显示本 exe 专属的数据目录路径、占用空间、其中可清理的缓存大小。
  - **清理缓存（保留登录态）**：只删 `Default\Cache`、`Code Cache`、`GPUCache`、`DawnGraphiteCache`、`DawnWebGPUCache`、`Shared Dictionary`、`GPUPersistentCache`、`GrShaderCache`、`ShaderCache`、`BrowserMetrics` 这些纯缓存目录，**不碰** `Default\Network`（Cookie 在这里）、`Local Storage`、`Preferences` 等登录态。实测真实 profile：清理 49.7 MB（73.9 MB → 24.1 MB），Cookies / Local Storage / Preferences 全部保留。
  - **彻底重置（含登录态）**：删掉整个 WebView2 用户数据目录，带二次确认（会丢登录态）。进程存活时 LOCK 等文件可能删不掉，会如实提示残留路径。
  - **重载页面**：先导航到 `about:blank` 清掉旧页面的 JS 上下文与 `window.__ModuleLoader__` 注册表，再回到当前 harness 地址。
  - **重启 Harness**：用当前生效的 runtime 目录重启一次。只在 harness 由本客户端拉起时可用，否则按钮置灰并说明原因（插件/外部拉起的实例绝不擅自杀掉）。
- **修复：切换 runtime 版本后页面报「Failed to load plugins / N entries did not activate」**（捆绑客户端 → 0.6.3）。
  - **现象**：在设置页把 runtime 从 0.1.7-alpha.1 切回 0.1.6-alpha.2 后，harness 页面顶部报大量 `import failed`，**连官方包（`dsh-client-ui-chat` 等）也一起失败**，看起来像全崩。
  - **根因**：切版本时客户端只做 `SetURL` 软导航，WebView2 复用同一浏览器进程与同一份用户数据目录，于是旧页面（0.1.7）的 `__DSH_BOOT__` 模块清单、`window.__ModuleLoader__` 注册表、combo URL 都还在。新 harness（0.1.6）按自己的 runtime 树发模块时，浏览器拿**旧清单**去请求——清单里有 6 个包（`dsh-api-job-controller`、`dsh-client-ui-settings-account/shell/agent-loop/subagent/web-search`）在 0.1.6 里并不存在。由于模块是按 combo URL **批量**请求的，只要其中一个解析不到，整批（65 个）就一起失败，所以官方包也被连带报错。
  - **排查澄清**：这与插件无关，也不是发布的 runtime 有问题——对已发布的 0.1.7-alpha.1 逐条验证过，62 个模块 URL 全部返回 200。问题纯在浏览器侧的陈旧清单。
  - **用户侧应急**：删掉 `%LOCALAPPDATA%\dsh-desktop-shell-client\webview\<hash>` 即可恢复（本次把它做成了诊断页按钮）。
- **注意：插件形态与独立客户端的 WebView2 数据目录、runtime 目录都是分开的**（捆绑客户端 → 0.6.3）。
  - 两者按 exe 所在目录的 md5 生成各自的 WebView2 目录（`webviewUserDataPath()`），runtime 根也分流：插件形态用 `%LOCALAPPDATA%\dsh-desktop-shell-client\runtime`，独立客户端用 exe 同目录 `runtime\`。
  - 所以"插件模式正常、独立客户端异常"是可能的：它们是两套互不共享的 runtime 与浏览器缓存。
- **验证**（捆绑客户端 → 0.6.3）：
  - `go test ./...` 全绿；新增 `diagnostics_test.go` 锁住两条关键性质：软清理必须删缓存、**必须保留**登录态；并禁止后续把 `Network`/`Local Storage` 之类加进 `softCleanTargets`。
  - 真实 WebView2 profile 副本上实测清理行为（见上）。
  - 无头 Edge 渲染诊断页，确认 4 个按钮、6 项数据与状态消息均正常呈现。

## 0.6.2 (2026-09-22)

- **适配 dsh 0.1.7：修复插件在新运行树上整个客户端半不激活**（插件 → 0.6.2）。
  - 现象：升级到 dsh 0.1.7-alpha.1 后 web 启动报 `Failed to load plugins / web boot: 1 entry did not activate`，
    并指明 `@zerorigin-studio/dsh-desktop-shell: pending (waiting for service: settingsScope)`。
  - 根因：0.1.7 把浏览器侧设置服务从 `settingsScope` 换成了 `configForms`
    （官方 `dsh-client-ui-settings` 里 `SettingsScopeBinder` 整个类被删，新注册 `configForms`，
    底层改走 `remote.settings`）。插件顶层 `inject` 里写着 `settingsScope`，依赖永不满足 →
    cordis 把整个客户端半挂成 pending，**不只是设置卡片，插件的浏览器半全都没跑**。
  - 修法：顶层 `inject` 只保留两版都有的 `slots`，两个设置服务各起一个 `ctx.inject([...])` 子插件
    做「二选一」等待——依赖就绪的那个分支才启动，另一个自然保持 pending 且不影响插件激活。
    两代控制器 API（`getSnapshot/subscribe/set/unset`）本就同构，`ShellPolicy` 无需改动。
- **适配 dsh 0.1.7：host 侧 `settings.register()` 已被移除**（插件 → 0.6.2）。
  - 0.1.7 的 `SettingsForms` 删掉了 `register()`（类名也从 `SettingsProvider` 换掉），
    改为插件顶层 `export const Config` 由框架投影成设置表单。
  - 修法：新增顶层 `Config` 导出（`autostart` 字段），并按能力探测分流——
    有 `settings.register` 走 0.1.6 老路（`get()`/`watch()`），没有则用 `settings.get()` 读值
    并订阅 `app-boot/config-reload` 跟随变更。两条路都落到同一个 `applyAutostart()`。
  - `volatile()` 只在 schemastery 3.18.3+（0.1.7 运行树）存在，0.1.6 树是 3.18.2。
    **必须按能力探测后再调用**：直接写 `.volatile()` 会在 `import` 阶段抛
    `z.boolean(...).description(...).volatile is not a function`，把整个插件炸掉
    （实测复现）。现在老树上自动退化为普通 schema。
- **修复：设置卡片注册的槽位名一直是错的**（插件 → 0.6.2）。
  - 卡片原先注册进 `settings.plugin.item`，但两代官方实现里这个槽都**不存在**——
    0.1.6 的 `dsh-client-ui-settings-plugins` 与 0.1.7 的 `dsh-client-ui-plugin-manager`
    用的都是 `plugins.item`。槽位不存在时 `slots.inject` 只是静默等待，不报错，
    因此「桌面壳」卡片此前从未渲染过。现改用 `plugins.item`。
- **验证**（插件 → 0.6.2）：
  - 模块级：改造后的插件在 schemastery 3.18.2 与 3.18.3 下均能 import 成功，
    0.1.7 下 `Config.dict.autostart.meta.volatile === true`（确认能进设置页），老树下降级为 `undefined` 且不抛错。
  - 客户端半 mock：顶层 `inject` 不含 `settingsScope`/`configForms`；0.1.7 场景只启动 `configForms` 分支、
    0.1.6 场景只启动 `settingsScope` 分支，两边卡片都注册成功。
  - host 半 mock：0.1.6 场景走 `register()`、0.1.7 场景走 `get()` + 订阅 `config-reload`。
  - 端到端：用真实 profile 分别在 0.1.6-alpha.2 与 0.1.7-alpha.1 运行树下启动，
    两版都就绪、无 pending 告警、无 import 失败。
- 兼容性：**0.1.6 与 0.1.7 双版本同时可用**，无需按版本分发两份插件。

## 0.6.1 (2026-09-21)

- **客户端产物改名**（捆绑客户端 → 0.6.1）：`dsh-desktop-shell-client.exe` → `dsh-desktop-shell.exe`。
  - **对已有用户的影响**：插件升级后包内 exe 换名，插件会优先找新名、同时仍兼容旧名，
    因此**升级插件本身不会中断**；桌面/开始菜单快捷方式由客户端启动时自愈重建（见下）。
  - 发行版附件名同步改为 `dsh-desktop-shell.exe`（Gitee Release 需重发一次）。
- **修复：快捷方式在产物改名后永久失效**（捆绑客户端 → 0.6.1）。
  - 原先 `ensureShortcuts()` 只判断「.lnk 文件是否存在」，存在就跳过。改名后老用户
    快捷方式仍指向已不存在的旧文件，且**永不自愈**——双击只得到"找不到文件"。
  - 现在改为判断「快捷方式是否已指向当前 exe」（直接扫描 .lnk 明文路径，ANSI 与
    UTF-16LE 两种编码都查，不额外起进程），指向旧名或不相关程序时自动重建。
  - 回归测试：`shortcuts_test.go`（旧名 / UTF-16LE / 无关目标 / 文件缺失四种情形）。
- **修复：插件找不到客户端的兜底路径**（此前一直失效）。
  - 安装版兜底原先找 `dsh-desktop-shell.exe`，而产物实际叫 `dsh-desktop-shell-client.exe`，
    该分支从未命中；改名后已自然对齐，并进一步让新旧名都可命中。

## 0.6.0 (2026-09-20)

- **启动页：接入 DeepSeek 官网背景引擎，前景整体沉底**（捆绑客户端 → 0.6.0）。加载页不再是一块静态深蓝底，而是真正的官网首屏视觉：
  - 官方引擎（粒子鲸鱼 + 流体极光 + 星座网格）随包内置为 `engine.js`，与 dsh-desktop 启动器同一份实现；原先那套 CSS 近似降级为**兜底**（引擎缺席或浅色主题下引擎层自隐藏时才放出），默认 `[hidden]`，不会两层背景叠加。
  - logo、标题、状态文案、下载进度条、版权条**全部移到底部**，页面主体完全留给背景。随后按反馈进一步**移除 logo 与品牌标题**，底部只留状态与进度。
  - 修一个隐蔽 bug：兜底 canvas 在 `hidden` 期间布局尺寸为 0，放出前必须显式重排一次，否则网格永远是空的。
- **设置窗口改为应用级模态**（捆绑客户端 → 0.6.0）：不关掉设置页就没法操作客户端。
  - 用 `AttachModal`（Windows 侧实现即微软推荐做法）：`GWLP_HWNDPARENT` 建立属主关系让设置窗始终浮在主窗之上，`EnableWindow(parent,false)` 禁用主窗，窗口销毁时由 Wails 自动恢复——不会出现"关掉设置页后主窗永久变灰"。
  - **两个坑值得记录**：① `NewWithOptions` 只是把窗口排进待创建队列，原生 `hwnd` 要等 `app.Run()` 才建，而 `attachModal` 直接用句柄、句柄为 0 时**静默失效不报错**，故改为轮询 `NativeWindow()` 就绪后再绑；② 原本打算用 `Common.WindowRuntimeReady` 判就绪，核实后发现它由 Wails 运行时 JS 握手触发，而 `settings.html` 是零依赖静态页、**永远不会发出该信号**，那条路是死的。
  - 设置窗加**单例 + 存活校验**：模态叠开会互相禁用属主而锁死；引用若指向已销毁窗口，则点托盘只会对空气 Show/Focus，设置页从此再也打不开且无报错。
  - 真机探针验证：绑定前主窗 `enabled=true` → 绑定后 `false` → 关闭设置窗后 `true`。
- **标题栏跟随深浅色**（捆绑客户端 → 0.6.0）：主窗口、设置窗与子窗口的标题栏都随 dsh 主题切换。
  - Windows 用 DWM 沉浸式深色标题栏表达；显式给窗口级 `Theme`，避免 Wails 自带的系统主题监听抢刷（它只认系统主题，dsh 选了固定 light/dark 时会刷错）。
  - **修两个成因**：① 主窗是长生命周期窗口，原先只在启动/导航时同步一次，运行期**没有任何触发器**（设置窗因为每次新建、开窗即同步，所以看起来是好的）；② `systemPrefersDark` 用 `sync.Once` 永久缓存，导致"跟随系统"永远停在启动那一刻的取值。
  - 改为**内核事件驱动守候**（目录通知 `FindFirstChangeNotification` + 注册表通知 `RegNotifyChangeKeyValue` + 停止事件），空闲零唤醒。此前用每秒轮询：单次 16µs、CPU 占比 0.0016%，数字虽小但每秒唤醒会打断 CPU 深度 C-state、妨碍 dynticks idle，笔记本上有实际电池代价。
  - **踩坑记录**：`RegNotifyChangeKeyValue` 注册后不能立刻关闭键句柄，否则订阅失效并让等待**立即返回（0ms）**，循环变忙转——比轮询还糟。加了以进程 CPU 时间为判据的回归测试（实测空闲 1.5s 消耗 CPU 0s）。
- **修一处长期漂移**：注入给页面的桌面 SDK `getInfo().clientVersion` 硬编码着 `'0.2.0'`，而客户端版本早已走到 0.5.5——插件与页面拿到的版本号一直是错的。现由模板占位符在初始化时注入真实版本，并加测试锁住。

## 0.5.5 (2026-09-18)

- **紧急修复：0.5.4 引入的“启动后连不上”**（捆绑客户端 → 0.5.5）。0.5.4 把就绪地址的获取从管道改为**轮询日志文件**，但忽略了日志是**追加**写的——里面留着历次启动的记录。解析取的是“最后一条 `dsh web:`”，因此当本次启动还没打印地址时，会**立刻读到上一次的陈旧 URL**，客户端据此连接便失败或连到旧实例。现象即“弹窗只剩一个了，但启动不起来”。
  - 修法：spawn 前记录日志长度作为**基线**，只在新写入的区间内解析地址；历史记录一律排除。
  - 加 4 个单元用例锁住该回归，其中 `TestBaselineWindowExcludesOldRuns` 直接复现“基线之后尚无内容时不得解析出任何地址”。
  - 端到端验证：预置一份含陈旧地址（`127.0.0.1:5641`）的日志后启动，客户端正确取到本次的新地址（`127.0.0.1:12921`），未误用陈旧端口。
- 教训记录：0.5.4 的改动方向本身没错（日志留存更完整、少一条匿名管道），但它**依赖调用方按基线切窗**这一前提，而当时没有一并实现，也未做“日志已有历史记录”的测试。**追加型文件的解析必须显式限定区间**。

## 0.5.4 (2026-09-18)

- **启动路径的可见子进程已清零**（捆绑客户端 → 0.5.4），并附带两项稳健性修复：
  - 就绪地址的获取由 `StdoutPipe` 改为**从日志文件读取**：harness 的 stdout/stderr 现在统一落 `harness.log`，宿主轮询该文件解析 `dsh web: <url>`。好处是 harness 的输出完整留存（此前 stdout 只被扫描、不落盘，出问题时看不到它打的内容），也少一条匿名管道。
  - 就绪等待加 **5 秒存活宽限期**：此前轮询首轮就用 `tasklist` 判活，而刚 spawn 的进程可能尚未被列出，会被误判成"已退出"而立刻失败。
- **排查结论（记录以备后续）**：启动时会新增一个 `conhost.exe`，命令行参数为 `0x4`——即 **headless、不显示任何窗口**，由 harness 进程（node）自身派生，与调用方式无关（对照实验：Go 用 CREATE_NO_WINDOW 起 node 不产生；单独起 harness 也会产生）。因此它**不是**用户看到的弹窗，无需也无法从客户端侧消除。
  - 真正的可见弹窗来源是另两类，均已在 0.5.2 修掉：客户端自身的 `reg`/`tasklist`/`powershell`/`rundll32` 调用（未隐藏时每次调用闪一个黑框），以及插件侧 `reg.exe`（缺 `windowsHide`）。
  - 另有 WebView2 运行时自身在进程启动时执行的 `reg.exe query ...\\Uninstall /s` 探测，属于运行时内部行为，不在客户端控制范围内。

## 0.5.3 (2026-09-18)

- **统一 Wails 依赖到 beta.23**（捆绑客户端 → 0.5.3）：此前 Go 侧（`go.mod`、CLI、AGENTS.md）已是 `beta.23`，但前端 `@wailsio/runtime` 卡在 `beta.12`——两端不一致，属于"本地能构建、他人可能构建失败"的隐患。
  - 前端依赖由 `"latest"` 改为**精确锁定** `3.0.0-beta.23`（`--save-exact`）：`latest` 不可复现，正是这次漂移的根源。
  - 同步更新 `frontend/src/main.ts` 中展示的版本号与 `package-lock.json`。
  - 现在四处声明完全一致：CLI / `go.mod` / `frontend/package.json` / `main.ts` = `3.0.0-beta.23`。
- 顺带复测了一项历史记录：文档里"WebView2CompositionHosting 在 beta.12 下启动即崩"的问题，**在 beta.23 下不再复现**（带 `--remote-debugging-port` 启动，进程存活、窗口与 WebView2 数据目录均正常）。文档已更新为已复测。
- 验证：`go mod verify` 通过、全量测试通过、构建成功，并实跑确认客户端能拉起 harness（协议文件 `owner=client`、窗口标题正常）。

## 0.5.2 (2026-09-18)

- **修复：启动客户端与打开设置时连闪一串命令行黑框**（捆绑客户端 → 0.5.2）。0.5.1 引入主题跟随后，客户端在启动路径与窗口事件上启动了多个未隐藏的子进程，Windows 会为每个分配控制台，表现为"一串一闪而逝的黑框"。逐个改为不分配控制台：
  - **主题解析**：0.5.1 用 `reg query` 子进程读注册表，且它挂在"窗口导航完成"事件上——每次启动、每次打开设置都会触发。现改用 `golang.org/x/sys/windows/registry` **直接读注册表 API**，零子进程。
  - **存活检查**（`tasklist`）：单实例锁校验、harness 存活判定、退出时进程核对都在用，改为隐藏窗口调用。
  - **快捷方式注册**（`powershell` COM）：启动路径上执行，改为隐藏窗口调用。
  - **打开浏览器**（`rundll32`）：改为隐藏窗口调用。
  - 插件侧 `reg.exe` 调用补上 `windowsHide: true`（`stdio: 'ignore'` 只吞输出，并不阻止 Windows 建控制台）。这条影响的是 dsh 启动/插件重载时的黑框。
  - 新增 `subprocess_hidden.go` 统一提供隐藏窗口的调用入口，并加回归测试锁住"热路径不得直接 exec 可见子进程"。
  - 主题偏好在进程内缓存（`sync.Once`）：该函数在热路径上被反复调用，反复起子进程既慢又会闪窗。

## 0.5.1 (2026-09-18)

- **主题改为自动跟随 dsh，移除手动切换**（捆绑客户端 → 0.5.1）：0.5.0 提供的「跟随系统 / 浅色 / 深色」三选一被移除，改为直接跟随 **dsh 自己的主题偏好**。
  - 权威来源是 dsh 的用户设置文档 `<DSH_HOME>/settings.yaml` 的 `ui-theme.preference`（见 deepseek-harness 的 `packages/client/ui-theme/src/theme-settings.ts`：namespace `ui-theme`、字段 `preference`、取值 `light`/`dark`/`system`）。客户端**只读不写**——该文档归 dsh 的 settings 服务所有且支持用户直接编辑，外部写入容易与其内存状态互相覆盖、并破坏用户手写的注释与格式。
  - **加载页也跟随**：原先固定深色，现在按同一份偏好切换。加载页先于任何前端绑定渲染，因此由宿主在导航完成时通过 `__dshTheme` 推送实际明暗。
  - `system` 偏好下由客户端解析系统明暗（Windows 注册表 `AppsUseLightTheme`），并在系统明暗变化时即时更新，无需整页刷新。
  - 解析采用针对 `ui-theme.preference` 的定点读取，不引入 YAML 依赖；文件缺失、字段缺失、取值非法、被注释等情况一律回退 `system`，不会导致客户端启动失败。已由 16 个单元用例覆盖。
  - 移除设置项 `theme`（本地不再保存主题偏好）与对应的 `SetTheme` 方法。

## 0.5.0 (2026-09-18)

- **设置页支持深浅色主题**（捆绑客户端 → 0.5.0）：新增「外观」设置，三选一——**跟随系统**（默认）/ **浅色** / **深色**，切换立即生效。
  - 配色令牌改为「浅色为基线 + `html.dark` 覆盖 + `prefers-color-scheme` 跟随」三层结构，同一套变量两套取值；浅色与深色各自成块，便于对照维护。
  - 原先把颜色硬编码在规则里的位置（开关滑块、分段控件选中态、版本号文字色、页脚等）统一收进令牌，避免深色值泄漏到浅色。
  - `html.light` 单独写一份覆盖块：否则在「系统为深色」的机器上选浅色会被媒体查询抢走变量，出现"选了浅色仍是深色"。
  - 首帧前用缓存的偏好预设主题（内联脚本 + localStorage），消除"先渲染深色再闪成浅色"。
  - 系统偏好变化时，处于跟随模式的窗口会即时刷新提示文案。
  - 设置项 `theme`（`system`/`light`/`dark`），非法值回退 `system`。

## 0.4.3 (2026-09-18)

- **设置页布局调整**（捆绑客户端 → 0.4.3），按反馈修正三处：
  - 标签栏由左侧竖向导航改回**横向排布**，放在内容上方；
  - 移除顶部品牌区（logo、「设置」标题、「DSH 桌面客户端」副标题），只保留标签栏与右侧连接状态胶囊，纵向空间还给内容；
  - **状态区改为按页归属**：原先是一个跨页常驻的公共状态条，导致在「运行时」页查询出的「发现 3 个可用版本」会跟着用户切到其它页。现在「运行时」与「组件」两页各带一个独立状态区，消息与进度只留在触发它的那一页；「通用」「关于」没有异步操作，不再显示任何操作信息。轮询期间即使用户切走，进度也只更新发起操作的那一页。

## 0.4.2 (2026-09-18)

- **设置页视觉重做**（捆绑客户端 → 0.4.2）：对齐 WorkBuddy Manager 那套 shadcn/ui 设计语言——中性色阶配单一强调色、发丝边框（1px 低对比描边）、以 `--radius` 为基准的圆角分层、半透明叠加表达选中态。
  - 顶部改为品牌栏 + 连接状态胶囊（运行中用绿点呼吸，未运行红点），Harness 状态不再埋在「关于」页里；
  - 标签栏由横向按钮改为**左侧竖向导航**（带图标），与内容区形成明确的主从结构；
  - 卡片式分组：每组设置一张卡，组内条目以分隔线切分，不再是一排排独立圆角块；
  - 开关改为细轨道 + 圆形滑块，单选改为分段控件（segmented control），选中态用卡片底色而非高亮描边；
  - 统一留白节奏与字号层级（13px 正文 / 11px 辅助 / 10.5px 页脚），并补上深色滚动条样式；
  - 设置窗口 660×720 → **720×740**（最小 600×540），给侧栏导航留出横向空间。
- 功能与行为完全不变，仅视觉与布局重做。

## 0.4.1 (2026-09-18)

- **设置页改为标签页布局**（捆绑客户端 → 0.4.1）：原先所有设置挤在一页纵向滚动，改动后按功能分为四个标签页：
  - **通用**：开机自启、关闭主窗口行为、退出时是否保留 Harness；
  - **运行时**：存放位置、已下载版本（切换/删除）、从发布仓库查询并下载新版本；
  - **组件**：可选组件的安装与卸载（0.4.0 新增的能力）；
  - **关于**：客户端/Harness/插件版本、Harness 状态与连接地址、工作区。
- 进度条与状态提示移到标签栏下方的**常驻区域**——无论在哪个标签页，运行时下载、版本切换重启、组件安装的进度都可见。
- 组件页数据改为**首次进入时才加载**（它可能触发一次运行时清单补拉），不再拖慢设置页启动。
- 设置窗口由固定 640×860 改为 660×720 且**允许缩放**（最小 560×520）：标签页之间内容长度差异大，固定高度会憋住运行时页。

## 0.4.0 (2026-09-16)

- **可选组件按需安装**（捆绑客户端 → 0.4.0）。新增能力：运行时可以只带基础部分，大体积依赖作为「可选组件」在设置页按需安装。
  - 背景：官方 0.1.6 起引入 Office→PDF 能力，随之带上 `@deepseek-ai/libreoffice-kit-win32-x64`（解压 325MB，占整包 79%）。整包因此涨到 163.8MB，超出 Gitee 单附件 100MB 上限。基础 runtime 现已剔除该组件（**52.4MB**），harness 与 Web UI 完整可用。
  - 组件来源是**官方公开发布的 npm 包**，客户端直接走 npm 镜像下载（实测 npmmirror 33MB/s），用 npm 元数据里的 **sha512 integrity** 校验，不需要自行托管、不依赖系统 npm。
  - 设置页新增「可选组件」区块：显示组件名/体积/安装状态，一键安装或卸载；下载与安装进度复用运行时那套进度通道。
  - 安装采用 staging + 原子改名，校验（sha512 + 包名/版本比对）失败不会留下半个组件。
  - 运行时清单（manifest）会随 runtime 一并留档（`dsh-runtime-manifest.json`），组件声明（包名/版本/integrity/体积/安装位置）写在 `optional` 段；未声明组件的旧 runtime 会明确提示"该运行时未记录组件信息"。
- **修复**：组件安装目录拼接错误——`InstallTo` 已含 scope 目录，直接用完整包名会拼出 `@deepseek-ai/@deepseek-ai/...` 的重复层级。已由单元测试覆盖。

## 0.3.3 (2026-09-16)

- **修复：设置页选中的运行时版本被忽略**（捆绑客户端 → 0.3.3）。此前客户端启动时，"协议文件里的 `runtimeDir`" 优先于用户选中的版本——在源码树 / 插件环境下会表现为：明明下载并选中了新版本（如 0.1.6-alpha.1），实际跑的仍是协议文件指向的那份（如源码树的 0.1.5-rc.2），下载的版本永远轮不到。现在**只要用户在设置页选过版本（`active.json` 存在），就优先使用它**，协议文件的 `runtimeDir` 退为兜底。
- **修复：切换版本无法自动重启 harness**。归属判断原先依赖协议文件的 `owner` 字段，但 dsh 启动后加载插件，插件会把自己的记录写进同一个文件（`owner=plugin`）覆盖客户端写的 `owner=client`，客户端因此永远不敢重启。现在客户端在 `%LOCALAPPDATA%\dsh-desktop-shell-client\harness-state.json` 独立记录自己拉起的 harness（pid / 版本 / 路径 / 地址），不再受共享文件被覆盖影响。
- 说明：要让已下载的新版本真正生效，仍需当前旧的 harness 进程结束一次（退出客户端时关闭「保留 Harness」，或让它自然退出）。

## 0.3.2 (2026-09-13)

- **切换运行时版本即时生效**（捆绑客户端 → 0.3.2）：此前设置页的「使用」只写 `active.json`，必须重启整个客户端才生效。现在若正在运行的 harness 是客户端自己拉起的（协议文件 `owner=client`），切换后客户端会就地停掉旧实例、用所选版本重启，并把窗口切到新实例。插件拉起的 harness 不属于客户端，**绝不擅自杀掉**，仍只写 `active.json` 并提示重启。
- **设置页「关于」显式对照版本**：Harness 版本标注「（运行中）」，与已选版本不一致时提示"重启 Harness 后生效"，避免看起来像切换失败。
- 切换与重启期间复用同一进度通道，显示「正在用 <版本> 重启 Harness…」。

## 0.3.1 (2026-09-13)

- **runtime 存放位置按形态分流**（捆绑客户端 → 0.3.1）：
  - *插件形态*（exe 由 dsh 插件体系安装，位于 `<DSH_HOME>/profiles/<profile>/node_modules/<pkg>/bin/`）：runtime 用默认位置 `%LOCALAPPDATA%\dsh-desktop-shell-client\runtime\`。那类目录归包管理器（pnpm）所有，升级插件会替换整个包目录，放在旁边的 runtime 会被一起清掉，等于每次升级重下 200MB+。
  - *独立客户端形态*：runtime 放在 exe 同目录的 `runtime\` 下，「客户端 + runtime」成为一个可整体拷贝、可离线的自包含目录。
  - 新增设置项 `runtimeLocation`：`auto`（默认，按形态）/ `portable`（随客户端）/ `user`（默认位置）；环境变量 `DSH_SHELL_RUNTIME_DIR` 优先级最高。
- **设置页新增「运行时」区块**：显示存放位置与实际路径、已下载版本列表（可切换为当前版本、可删除），并从发布仓库匿名查询可下载版本、一键下载（带进度）。WebView2 用户数据与 harness 日志位置不变（固定在 `%LOCALAPPDATA%\dsh-desktop-shell-client\`）。
- **修复**：runtime 目录从 `%LOCALAPPDATA%\dsh-desktop-shell\` 挪到 `dsh-desktop-shell-client\`。前者是更早版本客户端遗留的 WebView2 用户数据目录（实测 3200+ 文件 / 500MB+ 浏览器 profile），把 runtime 混进去容易在清理浏览器数据时被一并删除。

## 0.3.0 (2026-09-13)

- **客户端可独立运行（新能力）**：捆绑客户端（bin/dsh-desktop-shell-client.exe → 0.3.0）不再要求机器上先有 dsh。本机没有可用 harness 时，客户端会从发布仓库（Gitee `coldcgh/dsh-runtime`）下载官方 `@deepseek-ai/dsh` 运行时，校验 sha256、解压到 `%LOCALAPPDATA%\dsh-desktop-shell\runtime\<version>`，再自行拉起 harness。下载走匿名直链，客户端不含任何凭证。于是同一个 exe 覆盖两种形态：
  - **插件形态**（本插件已装、dsh 在跑）：协议文件可达 → 直接附着，行为与 0.2.9 一致；
  - **独立形态**（裸机）：没有 harness → 下载运行时 → 启动 → 附着。
  - 加载页会显示下载进度（含百分比），失败显示具体原因；
  - 设置项新增 `pinnedDshVersion`（锁定运行时版本，留空自动选择）。
- **协议文件新增 `owner` 字段**：插件写 `owner=plugin`，独立客户端写 `owner=client`。插件卸载（dispose）时只删除自己写的那份，不再误删独立形态留下的状态。历史文件没有该字段时按插件所有处理，向后兼容。
- **修复**：客户端工作区不再硬编码 `D:\WorkSpaces\DeepSeekHerness`。改为「环境变量 > 设置项 > 历史目录（仅当存在，用于老用户无损迁移）> ~/DeepSeekHarness」。原硬编码会让分发给其它机器的用户把会话写到一个不存在的路径。
- **修复**：客户端与 harness 的数据根目录现在统一按 `DSH_HOME`（缺省 `~/.dsh`）解析。此前客户端固定用 `~/.dsh`，在设置了 `DSH_HOME` 的环境里会与 harness 各写各的目录。
- **改进**：harness 启动日志落到 `%LOCALAPPDATA%\dsh-desktop-shell\harness.log`（harness 是隐藏拉起的，此前启动失败没有任何线索）；退出时按 `tasklist` 核对进程名，避免 pid 复用误杀。

## 0.2.9 (2026-09-03)

- **捆绑桌面客户端升级**（bin/dsh-desktop-shell-client.exe → 0.2.0）：
  - 关闭主窗口行为按设置页三选项生效（退出到托盘 / 每次询问 / 直接退出）。**修复**：此前三个选项均不生效——拦截方式改为 Wails `RegisterHook` + `event.Cancel()`（与官方 hide-window 示例一致），否则框架内置的无条件关闭 listener 总会销毁窗口；
  - 托盘新增「开机自启」勾选（读写 HKCU Run，与插件设置页开关同一条值）；
  - 退出客户端不再杀 Harness（dsh web 后台保留，可随时重连）；
  - **标准多窗口接入（开放协议）**：客户端向每个托管页面注入 `window.dsh.desktop`（version 1），任何插件调用 `openWindow({url,title,width,height})` / `closeWindow(id)` 即可让客户端开原生独立窗口；底层走 WebView2 宿主消息（`window.chrome.webview.postMessage` → `{type:'dsh.desktop.openWindow',...}`），无跨端口 fetch/CORS，任何页面（含外部 harness）都成立；宿主侧由 `RawMessageHandler` 接收。保留旧 `__DSH_DESKTOP_API__` HTTP 桥接兼容；安装 dsh-deepseek-chat（0.3.3 接入该 SDK）后「网页对话」可多窗；
  - 正式版禁用 WebView2 原生右键菜单（DefaultContextMenuDisabled）。

## 0.2.8 (2026-09-02)

- **scope 迁移**：包名 `@coldcgh/dsh-desktop-shell` → `@zerorigin-studio/dsh-desktop-shell`（发布至 zerorigin-studio org）；内部 module id / bundle patch / author 同步更新。code/行为不变。
