"""Source file discovery: walk, ignore rules, size limits."""

from __future__ import annotations

import os
import stat
from fnmatch import fnmatch
from functools import lru_cache
from pathlib import Path

from .languages import lang_for


def _glob_match(path: str, pattern: str) -> bool:
    parts = pattern.split("/")
    if "**" not in parts:
        return fnmatch(path, pattern)
    path_parts = path.split("/")

    @lru_cache(maxsize=None)
    def match(path_idx, pattern_idx):
        if pattern_idx == len(parts):
            return path_idx == len(path_parts)
        if parts[pattern_idx] == "**":
            return match(path_idx, pattern_idx + 1) or (
                path_idx < len(path_parts) and match(path_idx + 1, pattern_idx)
            )
        return (
            path_idx < len(path_parts)
            and fnmatch(path_parts[path_idx], parts[pattern_idx])
            and match(path_idx + 1, pattern_idx + 1)
        )

    return match(0, 0)


def _excluded(rel: Path, cfg, is_dir: bool) -> bool:
    posix = rel.as_posix()
    for pat in cfg.exclude:
        if not pat:
            continue
        if "/" in pat:
            base = pat.rstrip("/")
            if _glob_match(posix, pat) or posix.startswith(base + "/"):
                return True
        else:
            if fnmatch(rel.name, pat) or fnmatch(posix, pat):
                return True
    return False


def _included(rel: Path, cfg) -> bool:
    if not cfg.include:
        return True
    posix = rel.as_posix()
    for pat in cfg.include:
        if not pat:
            continue
        base = pat.rstrip("/")
        if posix == base or posix.startswith(base + "/") or _glob_match(posix, pat):
            return True
    return False


def discover_files(root: Path, cfg, onerror=None) -> list:
    """Return the relative POSIX paths of all indexable source files.

    Directories are pruned as they are walked, so ignore rules on directory
    names are cheap and correct. Files are filtered by language registry,
    include/exclude rules and the size cap. ``onerror`` receives errors that
    make discovery incomplete, including errors reading file metadata.
    """
    root = Path(root)
    root_real = root.resolve()
    max_bytes = cfg.max_file_kb * 1024
    found = []
    for dirpath, dirnames, filenames in os.walk(
            root, followlinks=False, onerror=onerror):
        rel_dir = Path(dirpath).relative_to(root)
        kept = []
        for d in sorted(dirnames):
            rel = rel_dir / d if str(rel_dir) != "." else Path(d)
            if _excluded(rel, cfg, is_dir=True):
                continue
            kept.append(d)
        dirnames[:] = kept
        for fn in sorted(filenames):
            rel = rel_dir / fn if str(rel_dir) != "." else Path(fn)
            if _excluded(rel, cfg, is_dir=False):
                continue
            if not _included(rel, cfg):
                continue
            if lang_for(rel.as_posix(), cfg.language_map) is None:
                continue
            full = root / rel
            try:
                if full.is_symlink():
                    try:
                        full.resolve().relative_to(root_real)
                    except ValueError:
                        continue
                info = full.stat()
            except OSError as exc:
                if onerror is not None:
                    onerror(exc)
                continue
            except RuntimeError:
                continue
            if not stat.S_ISREG(info.st_mode):
                continue
            size = info.st_size
            if max_bytes and size > max_bytes:
                continue
            found.append(rel)
    return sorted(found, key=lambda p: p.as_posix())
