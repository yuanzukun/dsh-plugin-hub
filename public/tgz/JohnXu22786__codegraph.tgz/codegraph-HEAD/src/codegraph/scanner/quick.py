"""Dependency-free scanner: regular-expression based AST approximation.

This scanner needs no third-party packages. It extracts the structural
skeleton of a source file — imports, declarations, call sites — with
per-language patterns. Precision is lower than a real parser (no string /
comment awareness, single-line signatures only), which is why the tree-sitter
based scanner is preferred automatically when the optional grammars are
installed. Both scanners emit the same data shape.
"""

from __future__ import annotations

import ast
import io
import re
import tokenize

from ..models import CallRec, FileScan, ImportRec, SymbolRec
from . import languages

# --------------------------------------------------------------------------
# shared pieces
# --------------------------------------------------------------------------

# a call target: identifier chains like "fmt.Println", "lib::dist", "self.x.y"
CALL_CHAIN = re.compile(r"([A-Za-z_$][\w$]*(?:(?:::|\.)[A-Za-z_$][\w$]*)*)\s*\(")

# note: "self" is intentionally NOT excluded — calls like self.items.append()
# carry the object chain and are resolved by their final segment
PY_EXCLUDE = {
    "def", "class", "if", "elif", "else", "for", "while", "with", "return",
    "import", "from", "raise", "except", "assert", "yield", "lambda", "not",
    "and", "or", "in", "is", "pass", "break", "continue", "del", "global",
    "nonlocal", "try", "finally", "match", "case", "async", "await", "type",
}

JS_EXCLUDE = {
    "function", "if", "for", "while", "switch", "catch", "return", "typeof",
    "instanceof", "delete", "void", "import", "require", "export", "in", "of",
    "do", "else", "try", "finally", "throw", "case", "default", "extends",
    "yield", "await", "async", "class", "const", "let", "var", "static",
    "get", "set", "new", "super", "interface", "type", "enum",
    "namespace", "declare",
}

GO_EXCLUDE = {
    "if", "for", "switch", "func", "go", "defer", "return", "case", "select",
    "range", "var", "const", "type", "import", "package", "else", "break",
    "continue", "fallthrough", "map", "chan", "interface", "struct", "goto",
    "default",
}

JAVA_EXCLUDE = {
    "if", "for", "while", "switch", "return", "new", "try", "catch", "finally",
    "throw", "import", "package", "class", "interface", "extends", "implements",
    "public", "private", "protected", "static", "void", "super", "this",
    "assert", "synchronized", "instanceof", "do", "else", "case", "default",
    "break", "continue", "enum", "record", "sealed", "final", "abstract",
    "native", "volatile", "transient", "strictfp",
}

RUST_EXCLUDE = {
    "if", "for", "while", "fn", "return", "impl", "struct", "enum", "trait",
    "match", "let", "mut", "use", "mod", "pub", "unsafe", "ref", "where",
    "loop", "else", "move", "const", "static", "async", "await",
    "dyn", "type", "in", "union", "break", "continue",
    "extern", "macro_rules",
}


def _indent(line: str) -> int:
    return len(line) - len(line.lstrip(" \t"))


def _calls_in_line(line: str, exclude: set) -> list:
    out = []
    for m in CALL_CHAIN.finditer(line):
        callee = m.group(1)
        head = callee.replace("::", ".").split(".")[0]
        if head in exclude:
            continue
        out.append(callee)
    return out


def _finalize(items, nlines):
    """Turn (start, depth, SymbolRec) triples into ordered SymbolRecs with ends."""
    items = sorted(items, key=lambda t: t[0])
    recs = []
    for i, (start, depth, rec) in enumerate(items):
        end = nlines
        for j in range(i + 1, len(items)):
            if items[j][1] <= depth:
                end = items[j][0] - 1
                break
        rec.end = end
        recs.append(rec)
    return recs


def _assign_callers(calls, recs):
    spans = sorted(recs, key=lambda r: r.start)
    for c in calls:
        for r in spans:
            if r.start <= c.line <= r.end:
                c.caller = r.qualname
    return calls


def _line_no(text, pos) -> int:
    prefix = text[:pos]
    return prefix.count("\n") + prefix.count("\r") - prefix.count("\r\n") + 1


# --------------------------------------------------------------------------
# python
# --------------------------------------------------------------------------

RE_PY_DEF = re.compile(r"^[ \t]*(?:async\s+)?def\s+(\w+)\s*\(([^)]*)\)[^:]*:")
RE_PY_CLASS = re.compile(r"^[ \t]*class\s+(\w+)\s*(?:\([^)]*\))?\s*:")


def _python_doc(lines, header_idx):
    """Docstring right after a def/class header (1-based header line)."""
    if header_idx >= len(lines):
        return ""
    j = header_idx
    while j < len(lines) and not lines[j].strip():
        j += 1
    if j >= len(lines):
        return ""
    line = lines[j].lstrip()
    if not (line.startswith('"""') or line.startswith("'''")):
        return ""
    quote = '"""' if line.startswith('"""') else "'''"
    body = line[len(quote):]
    k = j
    while quote not in body and k + 1 < len(lines):
        k += 1
        body += "\n" + lines[k].lstrip()
    doc = body.split(quote, 1)[0]
    return next((x.strip() for x in doc.splitlines() if x.strip()), "")


def _imports_from_ast(tree, line_offset=0):
    nodes = sorted(
        (node for node in ast.walk(tree)
         if isinstance(node, (ast.Import, ast.ImportFrom))),
        key=lambda node: (node.lineno, node.col_offset),
    )
    imports = []
    for node in nodes:
        line = node.lineno + line_offset
        if isinstance(node, ast.Import):
            imports.extend(
                ImportRec(
                    alias.name,
                    [f"{alias.name} as {alias.asname}"] if alias.asname else [],
                    "module",
                    line,
                )
                for alias in node.names
            )
        else:
            module = "." * node.level + (node.module or "")
            names = [
                alias.name if alias.asname is None
                else f"{alias.name} as {alias.asname}"
                for alias in node.names
            ]
            imports.append(ImportRec(module, names, "from", line))
    return imports


def _imports_python_tokenized(text):
    imports = []
    statement = []
    source_lines = text.splitlines(keepends=True)

    def append_statement():
        nonlocal statement
        tokens = [
            token for token in statement
            if token.type not in (tokenize.COMMENT, tokenize.NL)
        ]
        statement = []
        if not tokens:
            return
        if tokens[0].type != tokenize.NAME or tokens[0].string not in ("import", "from"):
            depth = 0
            colon_idx = None
            for idx, token in enumerate(tokens):
                if token.type != tokenize.OP:
                    continue
                if token.string in ("(", "[", "{"):
                    depth += 1
                elif token.string in (")", "]", "}"):
                    depth = max(0, depth - 1)
                elif token.string == ":" and depth == 0:
                    colon_idx = idx
                    break
            if colon_idx is None:
                return
            import_idx = colon_idx + 1
            if import_idx >= len(tokens) or tokens[import_idx].type != tokenize.NAME:
                return
            if tokens[import_idx].string not in ("import", "from"):
                return
            tokens = tokens[import_idx:]

        start_line, start_col = tokens[0].start
        end_line, end_col = tokens[-1].end
        if start_line == end_line:
            source = source_lines[start_line - 1][start_col:end_col]
        else:
            source = (
                source_lines[start_line - 1][start_col:]
                + "".join(source_lines[start_line:end_line - 1])
                + source_lines[end_line - 1][:end_col]
            )
        try:
            tree = ast.parse(source)
        except (SyntaxError, ValueError):
            return
        imports.extend(_imports_from_ast(tree, start_line - 1))

    try:
        for token in tokenize.generate_tokens(io.StringIO(text).readline):
            if token.type in (tokenize.COMMENT, tokenize.INDENT, tokenize.DEDENT):
                continue
            if token.type in (tokenize.NEWLINE, tokenize.ENDMARKER):
                append_statement()
            elif token.type == tokenize.OP and token.string == ";":
                append_statement()
            else:
                statement.append(token)
    except (IndentationError, SyntaxError, tokenize.TokenError):
        append_statement()
    return imports


def _imports_python(text):
    try:
        tree = ast.parse(text)
    except (SyntaxError, ValueError):
        return _imports_python_tokenized(text)
    return _imports_from_ast(tree)


def _python_body_end(lines, start, indent):
    """Last line of a python declaration body starting at 1-based ``start``."""
    end = start
    for idx in range(start, len(lines)):  # 0-based index of line after header
        line = lines[idx]
        if not line.strip() or line.lstrip().startswith("#"):
            end = idx + 1  # blank / comment lines stay inside the body
            continue
        if _indent(line) > indent:
            end = idx + 1
        else:
            break
    return end


def _scan_python(text, lang, rel_path=None):
    module = languages.module_of(rel_path, lang) if rel_path else ""
    lines = text.splitlines()
    n = len(lines)
    stack = []  # (indent, kind, name, qualname)
    items = []  # (start, depth, SymbolRec)
    for idx, line in enumerate(lines, start=1):
        m = RE_PY_CLASS.match(line)
        if m:
            indent = _indent(line)
            while stack and stack[-1][0] >= indent:
                stack.pop()
            name = m.group(1)
            parent = stack[-1][3] if stack else ""
            qual = f"{parent}.{name}" if parent else (f"{module}.{name}" if module else name)
            stack.append((indent, "class", name, qual))
            items.append((idx, indent, SymbolRec("class", name, qual, parent, idx, 0, "")))
            continue
        m = RE_PY_DEF.match(line)
        if m:
            indent = _indent(line)
            while stack and stack[-1][0] >= indent:
                stack.pop()
            name = m.group(1)
            parent = stack[-1][3] if stack else ""
            kind = "method" if (stack and stack[-1][1] == "class") else "function"
            qual = f"{parent}.{name}" if parent else (f"{module}.{name}" if module else name)
            stack.append((indent, kind, name, qual))
            items.append((idx, indent, SymbolRec(kind, name, qual, parent, idx, 0,
                                                 m.group(2).strip())))
            continue
    recs = _finalize(items, n)
    for r in recs:
        r.doc = _python_doc(lines, r.start)
        r.end = _python_body_end(lines, r.start, _indent(lines[r.start - 1]))
    calls = []
    for idx, line in enumerate(lines, start=1):
        m = RE_PY_DEF.match(line) or RE_PY_CLASS.match(line)
        if m:
            line = line[m.end():]
        for callee in _calls_in_line(line, PY_EXCLUDE):
            calls.append(CallRec("", callee, idx))
    _assign_callers(calls, recs)
    return FileScan(lang, module, recs, calls, _imports_python(text))


# --------------------------------------------------------------------------
# javascript / typescript
# --------------------------------------------------------------------------

RE_JS_CLASS = re.compile(
    r"^\s*(?:export\s+)?(?:declare\s+)?(?:default\s+)?"
    r"(?:abstract\s+)?class\s+(\w+)"
)
RE_JS_FUNC = re.compile(
    r"^\s*(?:export\s+)?(?:default\s+)?(?:async\s+)?function\s+(\w+)\s*\(([^)]*)\)")
RE_JS_DECL_FUNC = re.compile(
    r"^\s*(?:export\s+)?declare\s+(?:async\s+)?function\s+(\w+)\s*\(([^)]*)\)")
RE_JS_ARROW = re.compile(
    r"^\s*(?:export\s+)?(?:const|let|var)\s+(\w+)\s*=\s*(?:async\s*)?"
    r"(?:\(([^)]*)\)|\w+)\s*=>")
RE_JS_INTERFACE = re.compile(
    r"^\s*(?:export\s+)?(?:declare\s+)?interface\s+(\w+)"
)
RE_JS_TYPE = re.compile(
    r"^\s*(?:export\s+)?(?:declare\s+)?type\s+(\w+)\s*="
)
# method-like lines: modifiers? name( params ) [optional return type] { body
# (the '{' may carry a one-line body; trailing comments are stripped first).
# A bare statement call like `helper(x)` has no '{' and never matches.
RE_JS_METHOD = re.compile(
    r"^\s*(?:(?:public|private|protected|static|readonly|async|get|set|"
    r"abstract|override|declare)\s+)*(\w+)\s*\(([^)]*)\)[^{]*\{")
# words that can never be method names (get/set/require are legitimate ones)
JS_RESERVED_NAMES = {
    "if", "for", "while", "switch", "catch", "return", "function", "class",
    "import", "export", "const", "let", "var", "new", "delete", "typeof",
    "instanceof", "in", "of", "do", "else", "try", "finally", "throw",
    "case", "default", "extends", "yield", "await", "async", "interface",
    "type", "enum", "namespace", "declare", "super", "this", "void",
}
RE_JS_ESM = re.compile(
    r"^[ \t]*import\s+(?:([^'\";]+?)\s+from\s+)?['\"]([^'\"]+)['\"]", re.M)
RE_JS_REQUIRE = re.compile(r"require\(\s*['\"]([^'\"]+)['\"]\s*\)")
RE_JS_REQ_NAMES = re.compile(r"(?:const|let|var)\s*\{?\s*([^=\n]*?)\s*\}?\s*=\s*require")
RE_JS_REQ_PROPERTY = re.compile(
    r"(?:const|let|var)\s+([A-Za-z_$][\w$]*)\s*=\s*require\(\s*"
    r"['\"]([^'\"]+)['\"]\s*\)\s*(?:\.\s*([A-Za-z_$][\w$]*)|"
    r"\[\s*['\"]([^'\"]+)['\"]\s*\])"
)
RE_JS_IDENT = re.compile(r"[A-Za-z_$][\w$]*")


def _strip_js_comment(line: str) -> str:
    """Remove a trailing // comment (keeps the caller's original line intact)."""
    return re.split(r"//", line, maxsplit=1)[0] if "//" in line else line


def _skip_js_trivia(text, index):
    while index < len(text):
        if text[index].isspace():
            index += 1
        elif text.startswith("//", index):
            newline = text.find("\n", index + 2)
            if newline < 0:
                return len(text)
            index = newline + 1
        elif text.startswith("/*", index):
            end = text.find("*/", index + 2)
            if end < 0:
                return len(text)
            index = end + 2
        else:
            break
    return index


def _skip_js_quoted(text, index):
    quote = text[index]
    index += 1
    while index < len(text):
        if text[index] == "\\":
            index += 2
        elif text[index] == quote:
            return index + 1
        else:
            index += 1
    return len(text)


def _read_js_import_specifier(text, index):
    index = _skip_js_trivia(text, index)
    if index >= len(text) or text[index] not in "'\"`":
        return None
    quote = text[index]
    start = index + 1
    index = start
    while index < len(text):
        if text[index] == "\\":
            index += 2
        elif quote == "`" and text.startswith("${", index):
            return None
        elif text[index] == quote:
            specifier = text[start:index]
            if not specifier:
                return None
            boundary = _skip_js_trivia(text, index + 1)
            return specifier if boundary < len(text) and text[boundary] in ",)" else None
        else:
            index += 1
    return None


def _skip_js_regex(text, index):
    index += 1
    in_class = False
    while index < len(text) and text[index] not in "\r\n":
        if text[index] == "\\":
            index += 2
        elif text[index] == "[":
            in_class = True
            index += 1
        elif text[index] == "]" and in_class:
            in_class = False
            index += 1
        elif text[index] == "/" and not in_class:
            index += 1
            while index < len(text) and text[index].isalpha():
                index += 1
            return index
        else:
            index += 1
    return index


def _is_jsx_tag_start(text, index):
    if index + 1 >= len(text):
        return False
    char = text[index + 1]
    if char in "/>":
        return True
    return char in "_$" or char.isidentifier()


def _scan_jsx_tag(text, index, imports, jsx):
    closing = text.startswith("</", index)
    index += 2 if closing else 1
    if index < len(text) and text[index] == ">":
        return index + 1, False, closing
    while index < len(text):
        char = text[index]
        if char in "'\"`":
            index = _skip_js_quoted(text, index)
        elif char == "{":
            index = _scan_js_dynamic_imports_code(
                text, index + 1, imports, template_expression=True, jsx=jsx
            )
        elif text.startswith("/>", index):
            return index + 2, True, closing
        elif char == ">":
            return index + 1, False, closing
        else:
            index += 1
    return len(text), True, closing


def _skip_jsx_element(text, index, imports, jsx):
    index, self_closing, closing = _scan_jsx_tag(text, index, imports, jsx)
    if self_closing or closing:
        return index
    while index < len(text):
        if text.startswith("</", index):
            index, _, _ = _scan_jsx_tag(text, index, imports, jsx)
            return index
        if text[index] == "{":
            index = _scan_js_dynamic_imports_code(
                text, index + 1, imports, template_expression=True, jsx=jsx
            )
        elif text[index] == "<" and _is_jsx_tag_start(text, index):
            index = _skip_jsx_element(text, index, imports, jsx)
        else:
            index += 1
    return index


def _find_js_closing_paren(text, index):
    depth = 0
    while index < len(text):
        char = text[index]
        if text.startswith("//", index):
            newline = text.find("\n", index + 2)
            index = len(text) if newline < 0 else newline + 1
        elif text.startswith("/*", index):
            end = text.find("*/", index + 2)
            index = len(text) if end < 0 else end + 2
        elif char in "'\"`":
            index = _skip_js_quoted(text, index)
        elif char == "(":
            depth += 1
            index += 1
        elif char == ")":
            depth -= 1
            if not depth:
                return index
            index += 1
        else:
            index += 1
    return None


def _looks_like_ts_generic_arrow(text, index):
    cursor = index + 1
    angle_depth = brace_depth = paren_depth = bracket_depth = 0
    has_parameter_comma = False
    while cursor < len(text):
        cursor = _skip_js_trivia(text, cursor)
        if cursor >= len(text):
            return False
        char = text[cursor]
        if char in "'\"`":
            cursor = _skip_js_quoted(text, cursor)
        elif char == "{":
            brace_depth += 1
            cursor += 1
        elif char == "}" and brace_depth:
            brace_depth -= 1
            cursor += 1
        elif char == "(":
            paren_depth += 1
            cursor += 1
        elif char == ")" and paren_depth:
            paren_depth -= 1
            cursor += 1
        elif char == "[":
            bracket_depth += 1
            cursor += 1
        elif char == "]" and bracket_depth:
            bracket_depth -= 1
            cursor += 1
        elif char == "<":
            angle_depth += 1
            cursor += 1
        elif char == ">" and cursor and text[cursor - 1] == "=":
            cursor += 1
        elif char == ">" and angle_depth:
            angle_depth -= 1
            cursor += 1
        elif char == ">":
            header = text[index + 1:cursor]
            if not has_parameter_comma and not re.search(r"\bextends\b", header):
                return False
            params = _skip_js_trivia(text, cursor + 1)
            if params >= len(text) or text[params] != "(":
                return False
            end = _find_js_closing_paren(text, params)
            if end is None:
                return False
            arrow = _skip_js_trivia(text, end + 1)
            return text.startswith("=>", arrow)
        elif char == "," and not (brace_depth or paren_depth or bracket_depth or angle_depth):
            has_parameter_comma = True
            cursor += 1
        else:
            cursor += 1
    return False


def _scan_js_dynamic_imports_code(
    text, index, imports, template_expression=False, jsx=False
):
    regex_prefixes = {
        "", "(", "[", "{", "=", ":", ",", ";", "!", "?", "new", "extends",
        "return",
        "throw", "case", "delete", "void", "typeof", "instanceof", "in",
        "of", "yield", "await", "else", "do", "control)", "block}",
        "+", "-", "*", "/", "%", "&", "|", "^", "~", "<", ">",
        "=>", "&&", "||", "??",
    }
    control_parens = {"if", "while", "for", "with", "switch", "catch"}
    jsx_prefixes = regex_prefixes | {"default", "new"}
    paren_stack = []
    brace_stack = []
    class_pending = False
    class_header_parens = 0
    brace_depth = 0
    previous = ""
    while index < len(text):
        char = text[index]
        if char.isspace():
            index += 1
            continue
        if text.startswith("//", index):
            newline = text.find("\n", index + 2)
            index = len(text) if newline < 0 else newline + 1
            continue
        if text.startswith("/*", index):
            end = text.find("*/", index + 2)
            index = len(text) if end < 0 else end + 2
            continue
        if template_expression and char == "}":
            if not brace_depth:
                return index + 1
            brace_depth -= 1
        if char in "'\"":
            index = _skip_js_quoted(text, index)
            previous = "literal"
            continue
        if char == "`":
            index = _skip_js_template(text, index, imports, jsx)
            previous = "literal"
            continue
        if char == "/" and previous in regex_prefixes:
            index = _skip_js_regex(text, index)
            previous = "literal"
            continue
        if (
            jsx and char == "<" and previous in jsx_prefixes
            and not _looks_like_ts_generic_arrow(text, index)
            and _is_jsx_tag_start(text, index)
        ):
            index = _skip_jsx_element(text, index, imports, jsx)
            previous = "literal"
            continue
        if char in "_$" or char.isalpha():
            end = index + 1
            while end < len(text):
                next_char = text[end]
                if next_char in "_$" or next_char.isalnum() or (
                    ("a" + next_char).isidentifier()
                ):
                    end += 1
                else:
                    break
            word = text[index:end]
            if word == "import" and previous != ".":
                opening = _skip_js_trivia(text, end)
                if opening < len(text) and text[opening] == "(":
                    specifier = _read_js_import_specifier(text, opening + 1)
                    if specifier is not None:
                        imports.append(ImportRec(
                            specifier, [], "import", _line_no(text, index)
                        ))
            if word == "class":
                following = _skip_js_trivia(text, end)
                class_pending = previous != "." and (
                    following >= len(text) or text[following] not in ":("
                )
            previous = word
            index = end
            continue
        if text.startswith("?.", index):
            previous = "."
            index += 2
            continue
        if text.startswith(("++", "--"), index):
            previous = text[index:index + 2]
            index += 2
            continue
        if text.startswith(("=>", "&&", "||", "??"), index):
            previous = text[index:index + 2]
            index += 2
            continue
        if char == "(":
            paren_stack.append(previous in control_parens)
            if class_pending:
                class_header_parens += 1
            previous = char
            index += 1
            continue
        if char == ")":
            control = paren_stack.pop() if paren_stack else False
            if class_pending and class_header_parens:
                class_header_parens -= 1
            previous = "control)" if control else char
            index += 1
            continue
        if char == "{":
            if template_expression:
                brace_depth += 1
            class_body = class_pending and not class_header_parens
            is_block = class_body or previous in {
                "", ";", ")", "control)", "else", "do", "try", "finally",
                "=>", "block}",
            }
            brace_stack.append(is_block)
            if class_body:
                class_pending = False
            previous = char
            index += 1
            continue
        if char == "}":
            is_block = brace_stack.pop() if brace_stack else False
            previous = "block}" if is_block else char
            index += 1
            continue
        if char == ";":
            class_pending = False
        previous = char
        index += 1
    return index


def _skip_js_template(text, index, imports, jsx):
    index += 1
    while index < len(text):
        if text[index] == "\\":
            index += 2
        elif text[index] == "`":
            return index + 1
        elif text.startswith("${", index):
            index = _scan_js_dynamic_imports_code(
                text, index + 2, imports, template_expression=True, jsx=jsx
            )
        else:
            index += 1
    return len(text)


def _imports_javascript_dynamic(text, jsx=False):
    imports = []
    _scan_js_dynamic_imports_code(text, 0, imports, jsx=jsx)
    return imports


def _javascript_import_names(clause):
    names = []
    named = re.search(r"\{([^}]*)\}", clause, re.S)
    prefix = clause[:named.start()] if named else clause
    namespace = re.search(r"\*\s+as\s+([A-Za-z_$][\w$]*)", prefix)
    namespace_binding = f"* as {namespace.group(1)}" if namespace else None
    if namespace:
        prefix = prefix[:namespace.start()] + prefix[namespace.end():]
    default = re.match(r"\s*([A-Za-z_$][\w$]*)\s*(?:,|$)", prefix)
    if default and default.group(1) != "type":
        names.append(f"default as {default.group(1)}")
    else:
        names.extend(
            name for name in RE_JS_IDENT.findall(prefix)
            if name not in ("as", "type")
        )
    if named:
        for specifier in named.group(1).split(","):
            specifier = specifier.strip()
            if specifier.startswith("type "):
                specifier = specifier[5:].strip()
            alias = re.fullmatch(
                r"([A-Za-z_$][\w$]*)\s+as\s+([A-Za-z_$][\w$]*)",
                specifier,
            )
            if alias:
                names.append(f"{alias.group(1)} as {alias.group(2)}")
            else:
                names.extend(
                    name for name in RE_JS_IDENT.findall(specifier)
                    if name not in ("as", "type")
                )
    if namespace_binding:
        names.append(namespace_binding)
    return names


def _javascript_require_names(clause):
    names = []
    for binding in clause.strip().strip("{} \t").split(","):
        binding = binding.strip().strip("{} \t")
        if not binding:
            continue
        alias = re.fullmatch(
            r"([A-Za-z_$][\w$]*)\s*:\s*([A-Za-z_$][\w$]*)", binding
        )
        if alias:
            names.append(f"{alias.group(1)} as {alias.group(2)}")
        else:
            names.append(binding)
    return names


def _imports_javascript(text, jsx=False):
    imports = []
    for m in RE_JS_ESM.finditer(text):
        clause = m.group(1) or ""
        names = _javascript_import_names(clause)
        imports.append(ImportRec(m.group(2), names, "import", _line_no(text, m.start())))
    imports.extend(_imports_javascript_dynamic(text, jsx=jsx))
    # A binding applies only to the require call matched by its declaration.
    stmts = list(RE_JS_REQ_NAMES.finditer(text))
    property_bindings = list(RE_JS_REQ_PROPERTY.finditer(text))
    for m in RE_JS_REQUIRE.finditer(text):
        names = []
        property_binding = next((candidate for candidate in property_bindings
                                 if candidate.start() < m.start() < candidate.end()
                                 and candidate.group(2) == m.group(1)), None)
        if property_binding is not None:
            source_name = property_binding.group(3) or property_binding.group(4)
            names = [f"{source_name} as {property_binding.group(1)}"]
        stmt = None
        if not names:
            stmt = next((candidate for candidate in stmts
                         if candidate.end() - len("require") == m.start()), None)
        if stmt is not None and not names:
            names = _javascript_require_names(stmt.group(1))
            binding_prefix = text[stmt.start():stmt.start(1)]
            if "{" not in binding_prefix:
                names = [
                    f"* as {name}" if re.fullmatch(
                        r"[A-Za-z_$][\w$]*", name
                    ) else name
                    for name in names
                ]
        imports.append(ImportRec(m.group(1), names, "require", _line_no(text, m.start())))
    return imports


def _scan_javascript(text, lang, rel_path=None):
    module = languages.module_of(rel_path, lang) if rel_path else ""
    lines = text.splitlines()
    n = len(lines)
    depth = 0
    containers = []  # (open_depth, qualname) for class blocks
    items = []
    decl_pats = (RE_JS_CLASS, RE_JS_FUNC, RE_JS_DECL_FUNC, RE_JS_ARROW, RE_JS_INTERFACE,
                 RE_JS_TYPE, RE_JS_METHOD)
    for idx, line in enumerate(lines, start=1):
        m = RE_JS_CLASS.match(line)
        if m:
            parent = containers[-1][1] if containers else ''
            qual = f"{parent}.{m.group(1)}" if parent else \
                (f"{module}.{m.group(1)}" if module else m.group(1))
            containers.append((depth, qual))
            items.append((idx, depth, SymbolRec(
                "class", m.group(1), qual, parent, idx, 0, "",
                default_export=bool(re.match(
                    r"^\s*export\s+default\b", line))),))
            depth += line.count("{") - line.count("}")
            while containers and depth <= containers[-1][0]:
                containers.pop()
            continue
        m = RE_JS_INTERFACE.match(line) or RE_JS_TYPE.match(line)
        if m:
            parent = containers[-1][1] if containers else ''
            qual = f"{parent}.{m.group(1)}" if parent else \
                (f"{module}.{m.group(1)}" if module else m.group(1))
            kind = "interface" if re.match(
                r"^\s*(?:(?:export|declare)\s+)*interface\b", line
            ) \
                else "type"
            items.append((idx, depth, SymbolRec(kind, m.group(1), qual, parent, idx, 0, "")))
            depth += line.count("{") - line.count("}")
            while containers and depth <= containers[-1][0]:
                containers.pop()
            continue
        m = RE_JS_METHOD.match(_strip_js_comment(line))
        if m and containers and m.group(1) not in JS_RESERVED_NAMES:
            parent = containers[-1][1]
            qual = f"{parent}.{m.group(1)}"
            items.append((idx, depth, SymbolRec("method", m.group(1), qual, parent, idx, 0,
                                                m.group(2).strip())))
            depth += line.count("{") - line.count("}")
            while containers and depth <= containers[-1][0]:
                containers.pop()
            continue
        m = RE_JS_FUNC.match(line) or RE_JS_DECL_FUNC.match(line) \
            or RE_JS_ARROW.match(line)
        if m:
            parent = containers[-1][1] if containers else ''
            qual = f"{parent}.{m.group(1)}" if parent else \
                (f"{module}.{m.group(1)}" if module else m.group(1))
            sig = m.group(2) if (m.lastindex or 0) >= 2 and m.group(2) is not None else ""
            items.append((idx, depth, SymbolRec(
                "function", m.group(1), qual, parent, idx, 0, sig,
                default_export=bool(re.match(
                    r"^\s*export\s+default\b", line)))) )
            depth += line.count("{") - line.count("}")
            while containers and depth <= containers[-1][0]:
                containers.pop()
            continue
        depth += line.count("{") - line.count("}")
        while containers and depth <= containers[-1][0]:
            containers.pop()
    recs = _finalize(items, n)
    calls = []
    for idx, line in enumerate(lines, start=1):
        for pat in decl_pats:
            m = pat.match(line)
            if m:
                # scan the body only; single-line bodies like
                # `m() { this.step() }` keep their call sites
                brace = line.find("{")
                line = line[brace + 1:] if brace >= 0 else line[m.end():]
                break
        for callee in _calls_in_line(line, JS_EXCLUDE):
            calls.append(CallRec("", callee, idx))
    _assign_callers(calls, recs)
    jsx = str(rel_path).lower().endswith((".jsx", ".tsx")) if rel_path else False
    return FileScan(lang, module, recs, calls, _imports_javascript(text, jsx=jsx))


# --------------------------------------------------------------------------
# go
# --------------------------------------------------------------------------

RE_GO_FUNC = re.compile(
    r"^\s*func\s+(\w+)(?:\s*\[(?:[^\[\]]|\[[^\[\]]*\])+\])?"
    r"\s*\(([^)]*)\)"
)
RE_GO_METHOD = re.compile(
    r"^\s*func\s+\((\w+)\s+\*?(\w+)"
    r"(?:\s*\[[^\]\n]+\])?\)\s+(\w+)\s*\(([^)]*)\)"
)
RE_GO_TYPE = re.compile(
    r"^\s*type\s+(\w+)(?:\s*\[[^\]\n]+\])?\s+"
    r"(?:=\s*)?([^\s{]+)"
)
RE_GO_IMP_SINGLE = re.compile(
    r'^[ \t]*import[ \t]+(?:(?P<alias>[\w.]+)[ \t]+)?'
    r'(?:"(?P<module_quoted>[^"]+)"|`(?P<module_raw>[^`]+)`)',
    re.M,
)
RE_GO_IMP_BLOCK_START = re.compile(r"import\s*\(")
RE_GO_IMP_SPEC = re.compile(
    r'^[ \t]*(?:(?P<alias>[\w.]+)[ \t]+)?'
    r'(?:"(?P<module_quoted>[^"]+)"|`(?P<module_raw>[^`]+)`)', re.M
)


def _go_import_rec(module, alias, line):
    names = [f"{module} as {alias}"] if alias else []
    return ImportRec(module, names, "module", line)


def _go_import_module(match):
    return match.group("module_quoted") or match.group("module_raw")


def _go_import_block_ranges(text):
    for block_match in RE_GO_IMP_BLOCK_START.finditer(text):
        body_start = block_match.end()
        i = body_start
        while i < len(text):
            if text.startswith("//", i):
                newline = text.find("\n", i + 2)
                i = len(text) if newline < 0 else newline + 1
            elif text.startswith("/*", i):
                end = text.find("*/", i + 2)
                i = len(text) if end < 0 else end + 2
            elif text[i] in ('"', "'", "`"):
                quote = text[i]
                i += 1
                while i < len(text):
                    if text[i] == "\\" and quote != "`":
                        i += 2
                    elif text[i] == quote:
                        i += 1
                        break
                    else:
                        i += 1
            elif text[i] == ")":
                yield body_start, i
                break
            else:
                i += 1


def _imports_go(text):
    imports = []
    seen = set()
    for m in RE_GO_IMP_SINGLE.finditer(text):
        module = _go_import_module(m)
        imports.append(_go_import_rec(
            module, m.group("alias"), _line_no(text, m.start())
        ))
        seen.add(module)
    for body_start, body_end in _go_import_block_ranges(text):
        block = text[body_start:body_end]
        for mm in RE_GO_IMP_SPEC.finditer(block):
            module = _go_import_module(mm)
            if module not in seen:
                imports.append(_go_import_rec(
                    module, mm.group("alias"),
                    _line_no(text, body_start + mm.start()),
                ))
                seen.add(module)
    return imports


def _go_brace_delta(line, state=None):
    """Count Go scope braces on one line, ignoring comments and strings."""
    delta = 0
    i = 0
    while i < len(line):
        if state == "comment":
            end = line.find("*/", i)
            if end < 0:
                break
            i = end + 2
            state = None
        elif state == "raw_string":
            end = line.find("`", i)
            if end < 0:
                break
            i = end + 1
            state = None
        elif line.startswith("//", i):
            break
        elif line.startswith("/*", i):
            i += 2
            state = "comment"
        elif line[i] == "`":
            i += 1
            state = "raw_string"
        elif line[i] in ('"', "'"):
            quote = line[i]
            i += 1
            while i < len(line):
                if line[i] == "\\":
                    i += 2
                elif line[i] == quote:
                    i += 1
                    break
                else:
                    i += 1
        elif line[i] == "{":
            delta += 1
            i += 1
        elif line[i] == "}":
            delta -= 1
            i += 1
        else:
            i += 1
    return delta, state


def _scan_go(text, lang, rel_path=None):
    module = languages.module_of(rel_path, lang, text)
    lines = text.splitlines()
    n = len(lines)
    items = []
    depth = 0
    scope_state = None
    for idx, line in enumerate(lines, start=1):
        m = RE_GO_METHOD.match(line)
        if m:
            parent = f"{module}.{m.group(2)}" if module else m.group(2)
            qual = f"{parent}.{m.group(3)}"
            items.append((idx, 0, SymbolRec("method", m.group(3), qual, parent, idx, 0,
                                            m.group(4).strip())))
        else:
            m = RE_GO_FUNC.match(line)
            if m:
                qual = f"{module}.{m.group(1)}" if module else m.group(1)
                items.append((idx, 0, SymbolRec("function", m.group(1), qual, "", idx, 0,
                                                m.group(2).strip())))
            else:
                m = RE_GO_TYPE.match(line)
                if m and depth == 0:
                    qual = f"{module}.{m.group(1)}" if module else m.group(1)
                    kind = "interface" if m.group(2) == "interface" else "type"
                    items.append((idx, 0, SymbolRec(kind, m.group(1), qual, "", idx, 0, "")))
        delta, scope_state = _go_brace_delta(line, scope_state)
        depth = max(0, depth + delta)
    recs = _finalize(items, n)
    calls = []
    for idx, line in enumerate(lines, start=1):
        brace = line.find("{")
        if brace >= 0:
            line = line[brace + 1:]
        for callee in _calls_in_line(line, GO_EXCLUDE):
            calls.append(CallRec("", callee, idx))
    _assign_callers(calls, recs)
    return FileScan(lang, module, recs, calls, _imports_go(text))


# --------------------------------------------------------------------------
# java
# --------------------------------------------------------------------------

RE_JAVA_CLASS = re.compile(
    r"^\s*(?:(?:public|final|abstract|sealed|non-sealed|static|strictfp)\s+)*"
    r"class\s+(\w+)")
RE_JAVA_INTERFACE = re.compile(
    r"^\s*(?:(?:public|static|sealed)\s+)*interface\s+(\w+)")
# method-like lines: modifiers? Type [Type ...] name( params ) [throws ...]
# The type segment may hold several space-separated tokens (generics like
# "Map<String, Integer>"); the method name is the token right before '('.
# Statement calls (System.out.println(x)) fail because their whole chain is
# one token followed directly by '('.
RE_JAVA_METHOD = re.compile(
    r"^\s*(?:(?:public|private|protected|static|final|abstract|synchronized|"
    r"native|default|transient|volatile|strictfp)\s+)*"
    r"([\w<>\[\],.?]+(?:\s+[\w<>\[\],.?]+)*)\s+(\w+)\s*\(([^)]*)\)"
    r"\s*(?:throws\s+[\w.,\s]+)?")
# Constructors have no return type, so they need a separate declaration
# pattern.  The scanner verifies that the name matches the enclosing class.
RE_JAVA_CONSTRUCTOR = re.compile(
    r"^\s*(?:(?:public|private|protected)\s+)*(\w+)\s*\(([^)]*)\)"
    r"\s*(?:throws\s+[\w.,\s]+)?")
# statement keywords that can never introduce a method declaration
_JAVA_STMT_HEADS = ("new", "return", "throw", "switch", "if", "for",
                    "while", "catch", "synchronized")
RE_JAVA_IMP = re.compile(
    r"(?:\A|(?<=[\r\n]))[ \t]*import\s+(?:static\s+)?([\w.*]+)\s*;"
)


def _imports_java(text):
    return [ImportRec(m.group(1), [], "import", _line_no(text, m.start()))
            for m in RE_JAVA_IMP.finditer(text)]


def _scan_java(text, lang, rel_path=None):
    module = languages.module_of(rel_path, lang, text)
    lines = text.splitlines()
    n = len(lines)
    depth = 0
    classes = []  # (open_depth, qualname, kind)
    items = []
    for idx, line in enumerate(lines, start=1):
        m = RE_JAVA_CLASS.match(line) or RE_JAVA_INTERFACE.match(line)
        if m:
            parent = classes[-1][1] if classes else ''
            qual = f"{parent}.{m.group(1)}" if parent else \
                (f"{module}.{m.group(1)}" if module else m.group(1))
            kind = "interface" if RE_JAVA_INTERFACE.match(line) else "class"
            classes.append((depth, qual, kind))
            items.append((idx, depth, SymbolRec(kind, m.group(1), qual, parent, idx, 0, "")))
            if kind == "class":
                open_brace = line.find("{", m.end())
                if open_brace >= 0:
                    candidate = RE_JAVA_CONSTRUCTOR.match(line[open_brace + 1:])
                    if candidate and candidate.group(1) == m.group(1):
                        items.append((
                            idx, depth + 1,
                            SymbolRec("method", candidate.group(1),
                                      f"{qual}.{candidate.group(1)}", qual, idx, 0,
                                      candidate.group(2).strip()),
                        ))
            depth += line.count("{") - line.count("}")
            while classes and depth <= classes[-1][0]:
                classes.pop()
            continue
        m = RE_JAVA_METHOD.match(line)
        if m and classes:
            ret = m.group(1)
            if ret.split()[0] in _JAVA_STMT_HEADS:
                m = None  # statement, not a declaration
        if m and classes:
            parent = classes[-1][1]
            qual = f"{parent}.{m.group(2)}"
            items.append((idx, depth, SymbolRec("method", m.group(2), qual, parent, idx, 0,
                                                m.group(3).strip())))
            depth += line.count("{") - line.count("}")
            while classes and depth <= classes[-1][0]:
                classes.pop()
            continue
        ctor = None
        if (classes and classes[-1][2] == "class"
                and depth == classes[-1][0] + 1):
            candidate = RE_JAVA_CONSTRUCTOR.match(line)
            if (candidate
                    and candidate.group(1) == classes[-1][1].rsplit(".", 1)[-1]):
                ctor = candidate
        if ctor:
            parent = classes[-1][1]
            qual = f"{parent}.{ctor.group(1)}"
            items.append((idx, depth, SymbolRec("method", ctor.group(1), qual, parent,
                                                idx, 0, ctor.group(2).strip())))
            depth += line.count("{") - line.count("}")
            while classes and depth <= classes[-1][0]:
                classes.pop()
            continue
        depth += line.count("{") - line.count("}")
        while classes and depth <= classes[-1][0]:
            classes.pop()
    recs = _finalize(items, n)
    calls = []
    for idx, line in enumerate(lines, start=1):
        brace = line.find("{")
        if brace >= 0:
            line = line[brace + 1:]
        for callee in _calls_in_line(line, JAVA_EXCLUDE):
            calls.append(CallRec("", callee, idx))
    _assign_callers(calls, recs)
    return FileScan(lang, module, recs, calls, _imports_java(text))


# --------------------------------------------------------------------------
# rust
# --------------------------------------------------------------------------

RE_RS_USE = re.compile(
    r"^[ \t]*(?:pub(?:\s*\([^)]*\))?\s+)?use\s+([^;]+;)", re.M)
RE_RS_MOD = re.compile(
    r"^[ \t]*(?:#\[[^\]]*\]\s*)*"
    r"(?:pub(?:\s*\([^)]*\))?\s+)?mod\s+(\w+)\s*;", re.M)
RE_RS_INLINE_MOD = re.compile(
    r"^[ \t]*(?:#\[[^\]]*\]\s*)*"
    r"(?:pub(?:\s*\([^)]*\))?\s+)?mod\s+((?:r#)?\w+)\s*\{")
RE_RS_INLINE_MOD_BODY = re.compile(
    r"(?<!\w)(?:#\[[^\]]*\]\s*)*"
    r"(?:pub(?:\s*\([^)]*\))?\s+)?mod\s+((?:r#)?\w+)\s*\{")
RE_RS_FN = re.compile(r"^\s*(?:pub(?:\s*\([^)]*\))?\s+)?fn\s+(\w+)\s*\(([^)]*)\)")
RE_RS_INLINE_FN = re.compile(
    r"\b(?:pub(?:\s*\([^)]*\))?\s+)?fn\s+(\w+)\s*\(([^)]*)\)"
)
RE_RS_TYPE = re.compile(
    r"^\s*(?:pub(?:\s*\([^)]*\))?\s+)?(struct|enum)\s+(\w+)"
)
RE_RS_TRAIT = re.compile(
    r"^\s*(?:pub(?:\s*\([^)]*\))?\s+)?trait\s+(\w+)"
)
RE_RS_IMPL = re.compile(r"^\s*(?:pub\s+)?(?:unsafe\s+)?impl\b")
RE_RS_IMPL_FOR = re.compile(r"\s+for\s+(?!<\s*')")
RE_RS_CHAR = re.compile(
    r"'(?:[^'\\\n]|\\(?:[nrt0\\'\"]|x[0-9a-fA-F]{2}|u\{[0-9a-fA-F_]+\}))'")


def _rust_use_tree_parts(text):
    parts = []
    start = 0
    depth = 0
    for index, char in enumerate(text):
        if char == "{":
            depth += 1
        elif char == "}":
            depth -= 1
        elif char == "," and depth == 0:
            parts.append(text[start:index].strip())
            start = index + 1
    parts.append(text[start:].strip())
    return [part for part in parts if part]


def _rust_mask_comments(text, mask_strings=True, preserve_path_strings=False):
    """Blank Rust comments and strings while preserving source positions."""
    chars = list(text)
    index = 0
    block_depth = 0
    line_comment = False
    string = None
    string_keep = False
    raw_end = None

    def blank(start, end):
        if not mask_strings:
            return
        for offset in range(start, end):
            if chars[offset] != "\n":
                chars[offset] = " "

    while index < len(chars):
        if line_comment:
            if chars[index] == "\n":
                line_comment = False
            else:
                chars[index] = " "
                index += 1
            continue
        if block_depth:
            if text.startswith("/*", index):
                blank(index, index + 2)
                block_depth += 1
                index += 2
            elif text.startswith("*/", index):
                blank(index, index + 2)
                block_depth -= 1
                index += 2
            else:
                if chars[index] != "\n":
                    chars[index] = " "
                index += 1
            continue
        if raw_end is not None:
            if text.startswith(raw_end, index):
                blank(index, index + len(raw_end))
                index += len(raw_end)
                raw_end = None
            else:
                blank(index, index + 1)
                index += 1
            continue
        if string is not None:
            if text[index] == "\\" and index + 1 < len(chars):
                if not string_keep:
                    blank(index, index + 2)
                index += 2
            else:
                if not string_keep:
                    blank(index, index + 1)
                if text[index] == string:
                    string = None
                    string_keep = False
                index += 1
            continue
        char_match = RE_RS_CHAR.match(text, index)
        if char_match:
            blank(index, char_match.end())
            index = char_match.end()
            continue
        raw_prefix = None
        if chars[index] == "r":
            raw_prefix = index + 1
        elif text.startswith("br", index):
            raw_prefix = index + 2
        if raw_prefix is not None:
            hash_end = raw_prefix
            while hash_end < len(chars) and chars[hash_end] == "#":
                hash_end += 1
            if hash_end < len(chars) and chars[hash_end] == '"':
                raw_end = '"' + ('#' * (hash_end - raw_prefix))
                blank(index, hash_end + 1)
                index = hash_end + 1
                continue
        if chars[index] == '"':
            string = '"'
            string_keep = bool(
                preserve_path_strings and
                re.search(r"#\[\s*path\s*=\s*$", "".join(chars[:index]))
            )
            if not string_keep:
                blank(index, index + 1)
            index += 1
        elif text.startswith("//", index):
            chars[index:index + 2] = "  "
            line_comment = True
            index += 2
        elif text.startswith("/*", index):
            chars[index:index + 2] = "  "
            block_depth = 1
            index += 2
        else:
            index += 1
    return "".join(chars)


def _rust_use_tree_bindings(text, prefix=""):
    """Flatten a Rust use tree into ``(path, alias)`` bindings."""
    text = text.strip()
    if not text:
        return []
    if text.startswith("{") and text.endswith("}"):
        paths = []
        for part in _rust_use_tree_parts(text[1:-1]):
            paths.extend(_rust_use_tree_bindings(part, prefix))
        return paths

    brace = text.find("{")
    if brace >= 0 and text.endswith("}"):
        head = text[:brace].strip()
        head = re.sub(r"\s*::\s*", "::", head)
        if head.endswith("::"):
            head = head[:-2]
        joined = "::".join(part for part in (prefix, head) if part)
        paths = []
        for part in _rust_use_tree_parts(text[brace + 1:-1]):
            paths.extend(_rust_use_tree_bindings(part, joined))
        return paths

    alias = None
    alias_match = re.match(r"^(.*?)\s+as\s+([A-Za-z_]\w*)$", text)
    if alias_match:
        text = alias_match.group(1).strip()
        alias = alias_match.group(2)
    text = re.sub(r"\s*::\s*", "::", text)
    text = re.sub(r"::\*$", "", text)
    if text in ("self", "*"):
        return [(prefix, alias)] if prefix else []
    path = "::".join(part for part in (prefix, text) if part)
    return [(path, alias)] if path else []


def _rust_use_tree_paths(text, prefix=""):
    """Flatten a Rust use tree into paths that can be resolved separately."""
    return [path for path, _alias in _rust_use_tree_bindings(text, prefix)]


def _imports_rust(text):
    text = _rust_mask_comments(text)
    imports = []
    for m in RE_RS_MOD.finditer(text):
        imports.append(ImportRec(m.group(1), [], "mod", _line_no(text, m.start())))
    for m in RE_RS_USE.finditer(text):
        expression = re.sub(r"//[^\n]*", "", m.group(1))
        expression = re.sub(r"/\*.*?\*/", "", expression, flags=re.S)
        expression = expression.strip().rstrip(";").strip()
        seen = set()
        for module, alias in _rust_use_tree_bindings(expression):
            if module and module not in seen:
                seen.add(module)
                imports.append(ImportRec(
                    module, [alias] if alias else [], "use",
                    _line_no(text, m.start())))
    return imports


def _split_rust_trailing_functions(text):
    fragments = []
    position = 0
    while True:
        while position < len(text) and text[position].isspace():
            position += 1
        if position == len(text):
            break
        function = RE_RS_INLINE_FN.match(text, position)
        if function is None:
            return text
        opening = text.find("{", function.end())
        if opening < 0:
            return text
        depth = 1
        closing = opening + 1
        while closing < len(text) and depth:
            if text[closing] == "{":
                depth += 1
            elif text[closing] == "}":
                depth -= 1
            closing += 1
        if depth:
            return text
        fragments.append(text[position:closing])
        position = closing
    return "\n".join(fragments) if len(fragments) > 1 else text


def _rust_inline_function_spans(text, include_nested=False):
    functions = []
    position = 0
    depth = 0
    while position < len(text):
        function = RE_RS_INLINE_FN.match(text, position)
        if (include_nested or depth == 0) and function is not None:
            opening = text.find("{", function.end())
            if opening >= 0:
                brace_depth = 1
                closing = opening + 1
                while closing < len(text) and brace_depth:
                    if text[closing] == "{":
                        brace_depth += 1
                    elif text[closing] == "}":
                        brace_depth -= 1
                    closing += 1
                if not brace_depth:
                    functions.append((function, opening, closing))
                    position = closing
                    continue
        if text[position] == "{":
            depth += 1
        elif text[position] == "}":
            depth -= 1
        position += 1
    return functions


def _rust_inline_module_spans(text):
    modules = []
    position = 0
    depth = 0
    while position < len(text):
        module = RE_RS_INLINE_MOD_BODY.match(text, position)
        if depth == 0 and module is not None:
            opening = module.end() - 1
            brace_depth = 1
            closing = opening + 1
            while closing < len(text) and brace_depth:
                if text[closing] == "{":
                    brace_depth += 1
                elif text[closing] == "}":
                    brace_depth -= 1
                closing += 1
            if not brace_depth:
                modules.append((module, opening, closing))
                position = closing
                continue
        if text[position] == "{":
            depth += 1
        elif text[position] == "}":
            depth -= 1
        position += 1
    return modules


def _scan_rust(text, lang, rel_path=None, parent_context=""):
    module = languages.module_of(rel_path, lang) if rel_path else ""
    lines = _rust_mask_comments(text).splitlines()
    n = len(lines)
    depth = 0
    containers = []  # (open_depth, kind, qualname[, local_function_symbol])
    items = []
    inline_calls = []
    inline_module_lines = set()
    inline_function_qualnames = set()
    trailing_symbols = []
    inline_imports = []
    local_function_ends = []

    def close_containers(current_depth, line_no):
        while containers and current_depth <= containers[-1][0]:
            container = containers.pop()
            if len(container) == 4:
                local_function_ends.append((container[3], line_no))

    for idx, line in enumerate(lines, start=1):
        m = RE_RS_INLINE_MOD.match(line)
        if m:
            parent = containers[-1][2] if containers else parent_context
            qual = f"{parent}.{m.group(1)}" if parent else \
                (f"{module}.{m.group(1)}" if module else m.group(1))
            containers.append((depth, "module", qual))
            # Keep a function declaration when a complete inline module fits
            # on one source line; the usual line-by-line pass skips this line.
            module_depth = 0
            module_close = None
            for pos in range(m.end() - 1, len(line)):
                if line[pos] == "{":
                    module_depth += 1
                elif line[pos] == "}":
                    module_depth -= 1
                    if module_depth == 0:
                        module_close = pos
                        break
            if module_close is not None:
                body = line[m.end():module_close]
                inline_module_lines.add(idx)
                if RE_RS_INLINE_MOD.match(body):
                    body_scan = _scan_rust(
                        body, lang, rel_path, parent_context=qual
                    )
                    trailing_symbols.extend(
                        (idx, SymbolRec(
                            symbol.kind, symbol.name, symbol.qualname,
                            symbol.parent, idx, idx, symbol.signature,
                            symbol.doc, symbol.default_export,
                        ))
                        for symbol in body_scan.symbols
                    )
                    inline_calls.extend(
                        CallRec(call.caller, call.callee, idx)
                        for call in body_scan.calls
                    )
                    inline_imports.extend(
                        ImportRec(item.module, list(item.names), item.kind, idx)
                        for item in body_scan.imports
                    )
                else:
                    inline_imports.extend(
                        ImportRec(item.module, list(item.names), item.kind, idx)
                        for item in _imports_rust(body)
                    )

                    def add_inline_function(scope, fn, open_brace, close_brace,
                                            owner, symbol_depth):
                        name = fn.group(1)
                        fn_qual = f"{owner}.{name}"
                        inline_function_qualnames.add(fn_qual)
                        items.append((idx, depth + symbol_depth, SymbolRec(
                            "function", name, fn_qual, owner, idx, 0,
                            fn.group(2).strip(),
                        )))
                        fn_body = scope[open_brace + 1:close_brace - 1]
                        cursor = 0
                        for nested_fn, nested_open, nested_close in \
                                _rust_inline_function_spans(
                                    fn_body, include_nested=True
                                ):
                            inline_calls.extend(
                                CallRec(fn_qual, callee, idx)
                                for callee in _calls_in_line(
                                    fn_body[cursor:nested_fn.start()], RUST_EXCLUDE
                                )
                            )
                            add_inline_function(
                                fn_body, nested_fn, nested_open, nested_close,
                                fn_qual, symbol_depth + 1,
                            )
                            cursor = nested_close
                        inline_calls.extend(
                            CallRec(fn_qual, callee, idx)
                            for callee in _calls_in_line(fn_body[cursor:], RUST_EXCLUDE)
                        )

                    for fn, open_brace, close_brace in \
                            _rust_inline_function_spans(body):
                        add_inline_function(
                            body, fn, open_brace, close_brace, qual, 1
                        )
                    for nested_mod, open_brace, close_brace in \
                            _rust_inline_module_spans(body):
                        nested_qual = f"{qual}.{nested_mod.group(1)}"
                        nested_scan = _scan_rust(
                            body[open_brace + 1:close_brace - 1], lang,
                            rel_path, parent_context=nested_qual,
                        )
                        trailing_symbols.extend(
                            (idx, SymbolRec(
                                symbol.kind, symbol.name, symbol.qualname,
                                symbol.parent, idx, idx, symbol.signature,
                                symbol.doc, symbol.default_export,
                            ))
                            for symbol in nested_scan.symbols
                        )
                        inline_calls.extend(
                            CallRec(call.caller, call.callee, idx)
                            for call in nested_scan.calls
                        )
                trailing = line[module_close + 1:]
                if trailing.strip():
                    trailing = _split_rust_trailing_functions(trailing)
                    trailing_scan = _scan_rust(
                        trailing, lang, rel_path, parent_context=parent
                    )
                    trailing_symbols.extend(
                        (idx, SymbolRec(
                            symbol.kind, symbol.name, symbol.qualname,
                            symbol.parent, idx, idx, symbol.signature,
                            symbol.doc, symbol.default_export,
                        ))
                        for symbol in trailing_scan.symbols
                    )
                    inline_calls.extend(
                        CallRec(call.caller, call.callee, idx)
                        for call in trailing_scan.calls
                    )
                    inline_imports.extend(
                        ImportRec(item.module, list(item.names), item.kind, idx)
                        for item in trailing_scan.imports
                    )
            depth += line.count("{") - line.count("}")
            close_containers(depth, idx)
            continue
        m = RE_RS_TYPE.match(line)
        if m:
            parent = containers[-1][2] if containers else parent_context
            qual = f"{parent}.{m.group(2)}" if parent else \
                (f"{module}.{m.group(2)}" if module else m.group(2))
            items.append((idx, depth, SymbolRec("type", m.group(2), qual, parent, idx, 0, "")))
            depth += line.count("{") - line.count("}")
            close_containers(depth, idx)
            continue
        m = RE_RS_TRAIT.match(line)
        if m:
            parent = containers[-1][2] if containers else parent_context
            qual = f"{parent}.{m.group(1)}" if parent else \
                (f"{module}.{m.group(1)}" if module else m.group(1))
            containers.append((depth, "trait", qual))
            items.append((idx, depth, SymbolRec("interface", m.group(1), qual, parent, idx, 0,
                                                "")))
            depth += line.count("{") - line.count("}")
            close_containers(depth, idx)
            continue
        m = RE_RS_IMPL.match(line)
        if m:
            parent = containers[-1][2] if containers else parent_context
            target = RE_RS_IMPL_FOR.search(line, m.end())
            if target:
                owner_text = _rust_impl_target(line, target.end())
            else:
                start = _rust_impl_type_start(line, m.end())
                owner_text = _rust_impl_target(line, start)
            owner = _rust_impl_owner(owner_text)
            qual = f"{parent}.{owner}" if parent else \
                (f"{module}.{owner}" if module else owner)
            containers.append((depth, "impl", qual))
            depth += line.count("{") - line.count("}")
            close_containers(depth, idx)
            continue
        m = RE_RS_FN.match(line)
        if m:
            parent = containers[-1][2] if containers else parent_context
            parent_kind = containers[-1][1] if containers else ""
            qual = f"{parent}.{m.group(1)}" if parent else \
                (f"{module}.{m.group(1)}" if module else m.group(1))
            kind = "method" if containers and containers[-1][1] in ("impl", "trait") \
                else "function"
            symbol = SymbolRec(kind, m.group(1), qual, parent, idx, 0,
                               m.group(2).strip())
            items.append((idx, depth, symbol))
            container = (depth, "function", qual)
            if parent_kind == "function":
                container += (symbol,)
            containers.append(container)
            depth += line.count("{") - line.count("}")
            close_containers(depth, idx)
            continue
        depth += line.count("{") - line.count("}")
        close_containers(depth, idx)
    recs = _finalize(items, n)
    for symbol, end in local_function_ends:
        symbol.end = end
    for rec in recs:
        if rec.qualname in inline_function_qualnames:
            rec.end = rec.start
    recs.extend(symbol for _, symbol in trailing_symbols)
    recs.sort(key=lambda rec: rec.start)
    calls = []
    for idx, line in enumerate(lines, start=1):
        if idx in inline_module_lines:
            continue
        brace = line.find("{")
        if brace >= 0:
            line = line[brace + 1:]
        else:
            m = RE_RS_FN.match(line)
            if m:
                line = line[m.end():]
        m = RE_RS_FN.match(line)
        if m:
            line = line[m.end():]
        for callee in _calls_in_line(line, RUST_EXCLUDE):
            calls.append(CallRec("", callee, idx))
    _assign_callers(calls, recs)
    calls.extend(inline_calls)
    return FileScan(
        lang, module, recs, calls, _imports_rust(text) + inline_imports
    )


def _rust_impl_target(line, start):
    angle = paren = bracket = brace = 0
    index = start
    while index < len(line):
        char = line[index]
        top_level = not (angle or paren or bracket or brace)
        if top_level and char == "{":
            return line[start:index].strip()
        if top_level and line.startswith("where", index):
            before = line[index - 1] if index else " "
            after_index = index + len("where")
            after = line[after_index] if after_index < len(line) else " "
            if not (before.isalnum() or before in "_#") and not (
                after.isalnum() or after == "_"
            ):
                return line[start:index].strip()
        if char == "'":
            literal = RE_RS_CHAR.match(line, index)
            if literal:
                index = literal.end()
                continue
        if char == "<" and not brace:
            angle += 1
        elif char == ">" and angle and not brace and not (
            index and line[index - 1] == "-"
        ):
            angle -= 1
        elif char == "(":
            paren += 1
        elif char == ")" and paren:
            paren -= 1
        elif char == "[":
            bracket += 1
        elif char == "]" and bracket:
            bracket -= 1
        elif char == "{":
            brace += 1
        elif char == "}" and brace:
            brace -= 1
        index += 1
    return line[start:].strip()


def _rust_impl_type_start(line, start):
    index = start
    while index < len(line) and line[index].isspace():
        index += 1
    if index == len(line) or line[index] != "<":
        return index

    angle = paren = bracket = brace = 0
    while index < len(line):
        char = line[index]
        if char == "'":
            literal = RE_RS_CHAR.match(line, index)
            if literal:
                index = literal.end()
                continue
        if char == "<" and not brace:
            angle += 1
        elif char == ">" and angle and not brace and not (
            index and line[index - 1] == "-"
        ):
            angle -= 1
            if not angle:
                index += 1
                while index < len(line) and line[index].isspace():
                    index += 1
                return index
        elif char == "(":
            paren += 1
        elif char == ")" and paren:
            paren -= 1
        elif char == "[":
            bracket += 1
        elif char == "]" and bracket:
            bracket -= 1
        elif char == "{":
            brace += 1
        elif char == "}" and brace:
            brace -= 1
        index += 1
    return index


def _rust_impl_owner(target):
    target = " ".join(target.split())
    path = target
    while path.startswith("&"):
        path = re.sub(r"^&\s*(?:'\w+\s*)?(?:mut\s+)?", "", path)
    path = re.sub(r"\s*::\s*", "::", path)
    if path.startswith("::"):
        path = path[2:]
    if path.startswith(("dyn ", "for<", "impl ")):
        return target
    base_path = path.split("<", 1)[0].strip()
    parts = base_path.split("::")
    if all(re.fullmatch(r"(?:r#)?[^\W\d]\w*", part) for part in parts):
        return parts[-1]
    return target


# --------------------------------------------------------------------------
# dispatch
# --------------------------------------------------------------------------

def quick_scan(text: str, lang: str, rel_path=None) -> FileScan:
    """Scan ``text`` of language ``lang`` and return a FileScan."""
    text = text.lstrip("\ufeff")  # some editors/CI keep a BOM
    if lang == "python":
        return _scan_python(text, lang, rel_path)
    if lang in ("javascript", "typescript"):
        return _scan_javascript(text, lang, rel_path)
    if lang == "go":
        return _scan_go(text, lang, rel_path)
    if lang == "java":
        return _scan_java(text, lang, rel_path)
    if lang == "rust":
        return _scan_rust(text, lang, rel_path)
    raise ValueError(f"quick scanner does not support language {lang!r}")
