"""Language registry: extension mapping, module-id derivation."""

from __future__ import annotations

import re
from pathlib import Path

# extension (lowercase, with dot) -> canonical language id
EXTENSIONS = {
    ".py": "python",
    ".pyi": "python",
    ".js": "javascript",
    ".jsx": "javascript",
    ".mjs": "javascript",
    ".cjs": "javascript",
    ".ts": "typescript",
    ".tsx": "typescript",
    ".mts": "typescript",
    ".cts": "typescript",
    ".go": "go",
    ".java": "java",
    ".rs": "rust",
}

def _skip_java_trivia(text, pos):
    while pos < len(text):
        if text[pos].isspace():
            pos += 1
        elif text.startswith("//", pos):
            pos += 2
            while pos < len(text) and text[pos] not in "\r\n":
                pos += 1
        elif text.startswith("/*", pos):
            end = text.find("*/", pos + 2)
            if end < 0:
                return len(text)
            pos = end + 2
        else:
            break
    return pos
def _mask_non_code(text):
    """Blank comments and literals while preserving source line breaks."""
    masked = list(text)
    length = len(text)

    def blank(start, end):
        for index in range(start, end):
            if masked[index] not in "\r\n":
                masked[index] = " "

    index = 0
    while index < length:
        if text.startswith("//", index):
            end = index + 2
            while end < length and text[end] != "\n":
                end += 1
            blank(index, end)
            index = end
            continue
        if text.startswith("/*", index):
            end = text.find("*/", index + 2)
            end = length if end < 0 else end + 2
            blank(index, end)
            index = end
            continue

        quote = None
        if text.startswith('"""', index):
            quote = '"""'
            end = index + len(quote)
            escaped = False
            while end < length:
                if escaped:
                    escaped = False
                    end += 1
                elif text[end] == "\\":
                    escaped = True
                    end += 1
                elif text.startswith(quote, end):
                    end += len(quote)
                    break
                else:
                    end += 1
        elif text[index] in ('"', "'", "`"):
            quote = text[index]
            end = index + 1
            while end < length:
                if quote != "`" and text[end] == "\\":
                    end = min(length, end + 2)
                elif text[end] == quote:
                    end += 1
                    break
                else:
                    end += 1
        if quote is not None:
            blank(index, end)
            index = end
            continue
        index += 1

    return "".join(masked)


def _skip_java_text_block(text, pos):
    search = pos + 3
    while True:
        end = text.find('"""', search)
        if end < 0:
            return None
        slash = end - 1
        while slash >= pos + 3 and text[slash] == "\\":
            slash -= 1
        if (end - slash - 1) % 2 == 0:
            return end + 3
        search = end + 1


def _skip_java_annotation_name(text, pos):
    segment = re.match(r"[\w$]+", text[pos:])
    if segment is None:
        return None
    pos += segment.end()
    while True:
        dot = _skip_java_trivia(text, pos)
        if dot >= len(text) or text[dot] != ".":
            return dot
        pos = _skip_java_trivia(text, dot + 1)
        segment = re.match(r"[\w$]+", text[pos:])
        if segment is None:
            return None
        pos += segment.end()


def _skip_java_annotation(text, pos):
    pos = _skip_java_trivia(text, pos + 1)
    pos = _skip_java_annotation_name(text, pos)
    if pos is None:
        return None
    pos = _skip_java_trivia(text, pos)
    if pos >= len(text) or text[pos] != "(":
        return pos

    depth = 1
    pos += 1
    quote = None
    while pos < len(text):
        if quote is not None:
            if text[pos] == "\\":
                pos += 2
                continue
            if text[pos] == quote:
                quote = None
        elif text.startswith("//", pos):
            pos = _skip_java_trivia(text, pos)
            continue
        elif text.startswith("/*", pos):
            pos = _skip_java_trivia(text, pos)
            continue
        elif text.startswith('"""', pos):
            pos = _skip_java_text_block(text, pos)
            if pos is None:
                return None
            continue
        elif text[pos] in "\"'":
            quote = text[pos]
        elif text[pos] == "(":
            depth += 1
        elif text[pos] == ")":
            depth -= 1
            if depth == 0:
                return pos + 1
        pos += 1
    return None


def _declared_package(lang, text):
    if lang == "java":
        pos = 0
        while True:
            pos = _skip_java_trivia(text, pos)
            if pos >= len(text) or text[pos] != "@":
                break
            pos = _skip_java_annotation(text, pos)
            if pos is None:
                return ""
        source = text[pos:]
    else:
        source = text
    # Java permits CR-only files; Go line comments end only at LF.
    if lang == "java":
        source = source.replace("\r\n", "\n").replace("\r", "\n")
    else:
        source = source.replace("\r\n", "\n")
    source = _mask_non_code(source)
    # Keep leading comments/trivia supported while allowing line breaks and
    # comments between package-name components.
    match = re.search(
        r"(?m)^[ \t\f]*package[ \t\n\f]+"
        r"([\w$]+(?:[ \t\n\f]*\.[ \t\n\f]*[\w$]+)*)"
        r"[ \t\f]*(?:;[ \t\f]*|(?=\n|$))",
        source,
    )
    if not match:
        return ""
    return re.sub(r"[ \t\n\f]*\.[ \t\n\f]*", ".", match.group(1))


def lang_for(rel_path, overrides=None) -> "str | None":
    """Map a relative path to a language id, or None when unsupported."""
    if overrides:
        low = Path(rel_path).suffix.lower()
        if low in overrides:
            return overrides[low]
    return EXTENSIONS.get(Path(rel_path).suffix.lower())


def module_of(rel_path, lang, text="") -> str:
    """Derive the module id of a file.

    Python uses dotted package ids ("pkg.cart", with "__init__" collapsed).
    JavaScript / TypeScript / Rust use the slash-separated relative path
    without extension ("web/index", "rustx/lib"). Go and Java prefer their
    ``package`` declaration when one is present.
    """
    if not rel_path:
        if lang in ("go", "java"):
            return _declared_package(lang, text)
        return ""
    rel = Path(rel_path)
    if lang == "python":
        parts = rel.with_suffix("").as_posix().split("/")
        if parts and parts[-1] == "__init__":
            parts = parts[:-1]
        return ".".join(parts) if parts else ""
    if lang == "go":
        package = _declared_package(lang, text)
        return package or rel.with_suffix("").as_posix()
    if lang == "java":
        package = _declared_package(lang, text)
        return package or rel.with_suffix("").as_posix()
    if lang == "typescript":
        for suffix in (".d.ts", ".d.mts", ".d.cts"):
            if rel.name.endswith(suffix):
                return rel.as_posix()[:-len(suffix)]
    return rel.with_suffix("").as_posix()
