"""Index builder: discover, parse, store, resolve — incrementally."""

from __future__ import annotations

import errno
import hashlib
import json
import os
import sqlite3
import tempfile
import threading
import time
from contextlib import contextmanager
from dataclasses import dataclass, field
from pathlib import Path

if os.name == "nt":
    import msvcrt
else:
    import fcntl

from .config import ProjectConfig
from .resolver import resolve_all
from .scanner import SCAN_VERSION, deep, languages, scan_text
from .scanner.walk import discover_files
from .store import IndexStore

_RESOLVER_VERSION = 20
_SCANNER_VERSION = SCAN_VERSION
_build_locks = {}
_build_locks_guard = threading.Lock()
_root_build_locks = {}
_root_build_locks_guard = threading.Lock()


def _build_lock_for(db_path: Path):
    resolved_db = db_path.resolve()
    with _build_locks_guard:
        lock = _build_locks.get(resolved_db)
        if lock is None:
            lock = threading.Lock()
            _build_locks[resolved_db] = lock
        return lock


@contextmanager
def _build_process_lock(db_path: Path):
    # Keep this sidecar stable; unlinking it could split concurrent lockers.
    lock_path = db_path.parent.resolve() / f"{db_path.name}.lock"
    with lock_path.open("a+b") as lock_file:
        if os.name == "nt":
            lock_file.seek(0, os.SEEK_END)
            if lock_file.tell() == 0:
                lock_file.write(b"\0")
                lock_file.flush()
            lock_file.seek(0)
            while True:
                try:
                    msvcrt.locking(
                        lock_file.fileno(), msvcrt.LK_NBLCK, 1
                    )
                    break
                except OSError as exc:
                    if exc.errno not in (errno.EACCES, errno.EDEADLK):
                        raise
                    time.sleep(0.05)
        else:
            fcntl.flock(lock_file.fileno(), fcntl.LOCK_EX)
        try:
            yield
        finally:
            if os.name == "nt":
                lock_file.seek(0)
                msvcrt.locking(lock_file.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                fcntl.flock(lock_file.fileno(), fcntl.LOCK_UN)


@contextmanager
def _root_build_lock(root: Path, db_path: str):
    """Serialize builds for one project across threads and processes."""
    root = Path(root).resolve()
    key = str(root)
    with _root_build_locks_guard:
        thread_lock = _root_build_locks.setdefault(key, threading.Lock())

    with thread_lock:
        lock_parent = Path(db_path).resolve().parent
        lock_parent.mkdir(parents=True, exist_ok=True)
        lock_name = f".codegraph-build-{_digest(key.encode())[:16]}.lock"
        lock_path = lock_parent / lock_name
        with lock_path.open("a+b") as lock_file:
            if os.name == "nt":
                lock_file.seek(0)
                if not lock_file.read(1):
                    lock_file.write(b"\0")
                    lock_file.flush()
                lock_file.seek(0)
                while True:
                    try:
                        msvcrt.locking(
                            lock_file.fileno(), msvcrt.LK_NBLCK, 1
                        )
                        break
                    except OSError:
                        time.sleep(0.05)
            else:
                fcntl.flock(lock_file.fileno(), fcntl.LOCK_EX)
            try:
                yield
            finally:
                if os.name == "nt":
                    lock_file.seek(0)
                    msvcrt.locking(lock_file.fileno(), msvcrt.LK_UNLCK, 1)
                else:
                    fcntl.flock(lock_file.fileno(), fcntl.LOCK_UN)


class _StaleBuildError(RuntimeError):
    """Raised when source contents changed before a build could commit."""


@dataclass
class IndexReport:
    files_scanned: int = 0
    files_changed: int = 0
    files_skipped: int = 0
    files_removed: int = 0
    symbols: int = 0
    calls: int = 0
    imports: int = 0
    languages: dict = field(default_factory=dict)
    elapsed: float = 0.0
    complete: bool = True


def _digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _cargo_manifest_paths(root: Path, source_paths=None) -> list:
    """Return Cargo manifests on the ancestor paths of indexed sources."""
    root = Path(root).resolve()
    if source_paths is None:
        try:
            manifests = set(root.rglob("Cargo.toml"))
        except OSError:
            manifests = set()
        directory = root
        while True:
            candidate = directory / "Cargo.toml"
            if candidate.is_file():
                manifests.add(candidate)
            if directory == directory.parent:
                break
            directory = directory.parent
        return sorted(manifests)

    manifests = set()
    for source in source_paths:
        path = Path(source)
        full_path = path if path.is_absolute() else root / path
        try:
            full_path.relative_to(root)
        except ValueError:
            continue
        directory = full_path.parent
        while True:
            candidate = directory / "Cargo.toml"
            if candidate.is_file():
                manifests.add(candidate)
            if directory == directory.parent:
                break
            directory = directory.parent
    return sorted(manifests)


def _cargo_manifest_state(root: Path, source_paths=None) -> dict:
    """Return content digests for Cargo manifests affecting Rust roots."""
    root = Path(root).resolve()
    manifests = _cargo_manifest_paths(root, source_paths)

    state = {}
    for manifest in manifests:
        if not manifest.is_file():
            continue
        try:
            data = manifest.read_bytes()
        except OSError:
            digest = None
        else:
            digest = _digest(data)
        state[Path(os.path.relpath(manifest, root)).as_posix()] = digest
    return state


def _go_mod_state(root: Path, include_go=True) -> dict:
    """Return the root go.mod digest when Go sources are indexed."""
    manifest = Path(root).resolve() / "go.mod"
    if not include_go or not manifest.is_file():
        return {}
    try:
        digest = _digest(manifest.read_bytes())
    except OSError:
        digest = None
    return {"go.mod": digest}


def _scan_config(cfg: ProjectConfig, include_cargo=True,
                 cargo_manifest_paths=None, include_go=True) -> str:
    """Serialize settings that affect per-file scan payloads."""
    language_ids = set(languages.EXTENSIONS.values())
    language_ids.update(cfg.language_map.values())
    if cfg.engine == "quick":
        providers = {lang: "quick" for lang in language_ids}
    elif cfg.engine == "deep":
        providers = {lang: "deep" for lang in language_ids}
    else:
        providers = {
            lang: "deep" if deep.supports(lang) else "quick"
            for lang in language_ids
        }
    return json.dumps(
        {"engine": cfg.engine, "language_map": cfg.language_map,
         "providers": providers,
         # Scanner changes must rebuild payloads from unchanged source files.
         "scanner_version": _SCANNER_VERSION,
         # A resolver change must revisit unchanged payloads in existing DBs.
         "resolver_version": _RESOLVER_VERSION,
        # Cargo roots affect resolution even though they do not affect the
        # per-file scanner payloads.  Including their state invalidates a
        # no-source-change incremental build when a root path moves.
         "cargo_manifests": (
             _cargo_manifest_state(
                  Path(cfg.root), cargo_manifest_paths) if include_cargo else {}
          ),
         "go_module": _go_mod_state(Path(cfg.root), include_go)},
        sort_keys=True,
        separators=(",", ":"),
    )


def _source_snapshot(root: Path, cfg: ProjectConfig, discovered=None) -> dict:
    """Return content digests for the files visible to this build."""
    if discovered is None:
        discovered = discover_files(root, cfg)
    snapshot = {}
    for rel in discovered:
        posix = rel.as_posix()
        try:
            data = (root / rel).read_bytes()
        except OSError:
            snapshot[posix] = None
        else:
            snapshot[posix] = _digest(data)
    return snapshot


def _assert_file_fresh(root: Path, path: str, digest: str):
    """Reject a payload whose source changed while it was being scanned."""
    try:
        current = _digest((root / path).read_bytes())
    except OSError as exc:
        raise _StaleBuildError(
            f"source changed during index build ({path}); retry"
        ) from exc
    if current != digest:
        raise _StaleBuildError(
            f"source changed during index build ({path}); retry"
        )


def _assert_project_fresh(root: Path, cfg: ProjectConfig, expected: dict,
                          expected_paths):
    """Reject a build whose discovered source set or contents changed."""
    discovered = discover_files(root, cfg)
    current_paths = {rel.as_posix() for rel in discovered}
    if current_paths != expected_paths:
        raise _StaleBuildError("project sources changed during index build; retry")
    current = _source_snapshot(root, cfg, discovered)
    if any(current.get(path) != digest for path, digest in expected.items()):
        raise _StaleBuildError("project sources changed during index build; retry")


def build_index(cfg: ProjectConfig, force: bool = False, quiet: bool = False,
                log=None) -> IndexReport:
    """Index (or refresh) the project described by ``cfg``.

    Incremental mode compares content hashes and scan settings: unchanged
    files are skipped, changed files are re-parsed and their rows replaced
    atomically, files that disappeared are dropped. ``force=True`` rebuilds
    every file.
    """
    with _root_build_lock(Path(cfg.root), cfg.db_path):
        with _build_lock_for(Path(cfg.db_path)):
            return _build_index_locked(cfg, force=force, quiet=quiet, log=log)


def _build_index_locked(cfg: ProjectConfig, force: bool = False,
                        quiet: bool = False, log=None) -> IndexReport:
    root = Path(cfg.root)
    if not root.exists():
        raise FileNotFoundError(f"index root does not exist: {root}")
    if not root.is_dir():
        raise NotADirectoryError(f"index root is not a directory: {root}")
    db = Path(cfg.db_path)
    db.parent.mkdir(parents=True, exist_ok=True)
    with _build_process_lock(db):
        return _build_index_with_process_lock(
            cfg, force=force, quiet=quiet, log=log
        )


def _build_index_with_process_lock(cfg: ProjectConfig, force: bool = False,
                                   quiet: bool = False, log=None) -> IndexReport:
    started = time.monotonic()
    report = IndexReport()
    emit = (lambda msg: None) if quiet else (log or print)
    root = Path(cfg.root)
    discovery_complete = True

    def on_discovery_error(exc):
        nonlocal discovery_complete
        discovery_complete = False
        emit(f"warning: incomplete file discovery: {exc}")

    discovered = discover_files(root, cfg, onerror=on_discovery_error)
    scan_config_complete = discovery_complete
    source_snapshot = {}
    source_paths = {rel.as_posix() for rel in discovered}
    has_discovered_rust = any(
        languages.lang_for(rel.as_posix(), cfg.language_map) == "rust"
        for rel in discovered
    )
    has_discovered_go = any(
        languages.lang_for(rel.as_posix(), cfg.language_map) == "go"
        for rel in discovered
    )

    db = Path(cfg.db_path)

    # Build forced indexes off to the side so a failed rebuild cannot destroy
    # the last published index.
    temporary_db = tempfile.TemporaryDirectory(
        dir=str(db.parent), prefix=f".{db.name}-"
    ) if force else None
    build_db = (Path(temporary_db.name) / db.name
                if temporary_db is not None else db)
    store = IndexStore(str(build_db))
    prebuild_db = sqlite3.connect(":memory:")
    store.conn.backup(prebuild_db)
    build_succeeded = False
    store.set_meta("root", str(Path(cfg.root).resolve()))
    known = store.all_file_paths()
    has_indexed_rust = store.conn.execute(
        "SELECT 1 FROM files WHERE lang = ? LIMIT 1", ("rust",)
    ).fetchone() is not None
    has_indexed_go = store.conn.execute(
        "SELECT 1 FROM files WHERE lang = ? LIMIT 1", ("go",)
    ).fetchone() is not None
    rust_source_paths = [
        rel for rel in discovered
        if languages.lang_for(rel.as_posix(), cfg.language_map) == "rust"
    ]
    if not discovery_complete:
        # An incomplete walk may omit an existing Rust source; retain its
        # ancestor manifests until the next complete discovery.
        rust_source_paths.extend(
            row["path"] for row in store.conn.execute(
                "SELECT path FROM files WHERE lang = ?", ("rust",)
            )
        )
    cargo_manifest_paths = _cargo_manifest_paths(root, rust_source_paths)
    scan_config = _scan_config(
        cfg, include_cargo=has_indexed_rust or has_discovered_rust,
        cargo_manifest_paths=cargo_manifest_paths,
        include_go=has_indexed_go or has_discovered_go)
    store.set_meta(
        "cargo_manifest_paths",
        json.dumps([
            Path(os.path.relpath(manifest, root.resolve())).as_posix()
            for manifest in cargo_manifest_paths
        ]),
    )
    current_scan_config = json.loads(scan_config)
    previous_scan_config = store.get_meta("scan_config")
    try:
        previous_scan_config = json.loads(previous_scan_config or "{}")
    except json.JSONDecodeError:
        previous_scan_config = {}
    if not isinstance(previous_scan_config, dict):
        previous_scan_config = {}
    scan_settings_changed = (
        previous_scan_config.get("engine") != current_scan_config["engine"] or
        previous_scan_config.get("language_map") != current_scan_config["language_map"] or
        previous_scan_config.get("scanner_version") !=
        current_scan_config["scanner_version"]
    )
    cargo_metadata_changed = (
        previous_scan_config.get("cargo_manifests") !=
        current_scan_config["cargo_manifests"]
    )
    go_module_changed = (
        previous_scan_config.get("go_module") !=
        current_scan_config["go_module"]
    )
    resolver_version_changed = (
        previous_scan_config.get("resolver_version") !=
        current_scan_config["resolver_version"]
    )
    previous_providers = previous_scan_config.get("providers", {})
    if not isinstance(previous_providers, dict):
        previous_providers = {}
    current_providers = current_scan_config["providers"]
    seen = set()
    changed_file_ids = set()
    recheck_call_ids = set()
    recheck_import_ids = set()
    changed_symbol_names = set()
    added_file = False
    removed_file = False
    rust_structure_changed = False
    resolution_pending = store.get_meta("resolution_pending") == "1"

    try:
        for rel in discovered:
            posix = rel.as_posix()
            seen.add(posix)
            try:
                data = (root / rel).read_bytes()
            except OSError as exc:  # file vanished or is unreadable mid-walk
                scan_config_complete = False
                emit(f"warning: skipping {posix}: {exc}")
                continue
            digest = _digest(data)
            source_snapshot[posix] = digest
            prev = store.file_by_path(posix)

            lang = languages.lang_for(posix, cfg.language_map)
            if lang is None:  # race with discovery config changes
                scan_config_complete = False
                continue

            previous_mods = set()
            if prev is not None and lang == "rust":
                previous_mods = {
                    row["module"] for row in store.imports_for_file(prev["id"])
                    if row["kind"] == "mod"
                }

            if not force and cfg.incremental and not scan_settings_changed:
                if (prev is not None and prev["digest"] == digest and
                        prev["lang"] == lang and
                        previous_providers.get(lang) == current_providers.get(lang)):
                    report.files_skipped += 1
                    continue

            text = data.decode("utf-8-sig", errors="replace")
            # Mark before scanning so a later scan failure preserves a retry
            # marker for payloads committed earlier in this run.
            store.set_meta("resolution_pending", "1")
            scan = scan_text(text, lang, posix, cfg.engine)
            # digest update and payload replacement share one transaction so
            # a crash mid-replace can never leave a stale-but-skipped file
            with store.transaction():
                fid = store.upsert_file(posix, lang, len(data), digest,
                                        len(text.splitlines()), scan.module)
                impact = store.replace_file_payload(fid, scan)
                _assert_file_fresh(root, posix, digest)
            changed_file_ids.add(fid)
            if lang == "rust" and (prev is None or previous_mods or any(
                    item.kind == "mod" for item in scan.imports)):
                rust_structure_changed = True
            recheck_call_ids.update(impact["call_ids"])
            recheck_import_ids.update(impact["import_ids"])
            changed_symbol_names.update(impact["symbol_names"])
            changed_symbol_names.update(s.name for s in scan.symbols)
            if prev is None:
                added_file = True
            report.files_changed += 1
            report.symbols += len(scan.symbols)
            report.calls += len(scan.calls)
            report.imports += len(scan.imports)

        if discovery_complete:
            _assert_project_fresh(root, cfg, source_snapshot, source_paths)
        removed_paths = sorted(known - seen) if discovery_complete else []
        if removed_paths:
            # Persist the retry marker before a removal transaction commits.
            # Otherwise an interruption after removal can leave cleared
            # incoming edges with no signal for the next incremental run.
            store.set_meta("resolution_pending", "1")
        for path in removed_paths:
            old = store.file_by_path(path)
            if old is not None and old["lang"] == "rust":
                rust_structure_changed = True
            with store.transaction():
                impact = store.remove_file(path)
            recheck_call_ids.update(impact["call_ids"])
            recheck_import_ids.update(impact["import_ids"])
            changed_symbol_names.update(impact["symbol_names"])
            removed_file = True
            report.files_removed += 1

        if discovery_complete:
            _assert_project_fresh(root, cfg, source_snapshot, source_paths)
        needs_resolution = (
            changed_file_ids or recheck_call_ids or recheck_import_ids or
            changed_symbol_names or removed_file or resolution_pending or
            cargo_metadata_changed or go_module_changed or
            rust_structure_changed or
            resolver_version_changed
        )
        if needs_resolution:
            # Payload transactions commit before this pass. Persist the retry
            # marker first so a failed resolution is retried on the next run
            # instead of being hidden by unchanged file digests.
            store.set_meta("resolution_pending", "1")
            if (resolution_pending or cargo_metadata_changed or
                    go_module_changed or
                    rust_structure_changed or resolver_version_changed):
                resolve_all(store)
            else:
                resolve_all(
                    store,
                    file_ids=changed_file_ids,
                    call_ids=recheck_call_ids,
                    import_ids=recheck_import_ids,
                    symbol_names=changed_symbol_names,
                    recheck_all_imports=added_file or removed_file,
                )
            # Keep the retry marker set until the final freshness check and
            # metadata commit succeed.
        # Keep a changed config pending when a discovered file could not be
        # read or mapped, so the next run retries its stale payload.
        with store.transaction():
            if discovery_complete:
                _assert_project_fresh(root, cfg, source_snapshot, source_paths)
            if needs_resolution:
                store.set_meta("resolution_pending", "0")
            if scan_config_complete:
                store.set_meta("scan_config", scan_config)
            store.set_meta("last_indexed", store.now_iso())

        for row in store.conn.execute(
                "SELECT lang, COUNT(*) AS n FROM files GROUP BY lang ORDER BY lang"):
            report.languages[row["lang"]] = row["n"]
        # A force build starts with an empty temporary DB. Do not publish a
        # partial replacement when discovery or a file read was incomplete.
        build_succeeded = scan_config_complete
    except _StaleBuildError:
        store.conn.rollback()
        prebuild_db.backup(store.conn)
        raise
    finally:
        store.close()
        prebuild_db.close()
        if temporary_db is not None:
            try:
                if build_succeeded:
                    os.replace(build_db, db)
            finally:
                temporary_db.cleanup()

    report.files_scanned = len(discovered)
    report.elapsed = time.monotonic() - started
    report.complete = scan_config_complete
    if not (force and not report.complete):
        emit(f"indexed {report.files_scanned} files ({report.files_changed} changed, "
             f"{report.files_skipped} skipped, {report.files_removed} removed) "
             f"in {report.elapsed:.2f}s — {report.symbols} symbols, "
             f"{report.calls} calls, {report.imports} imports")
    return report
