"""Tests for incremental index building (builder.build_index)."""

import json
import multiprocessing
import shutil
import tempfile
import threading
import unittest
from pathlib import Path
from unittest.mock import patch

from codegraph.builder import build_index
from codegraph.config import load_config
from codegraph.models import FileScan, SymbolRec
from codegraph.store import IndexStore

from .fixtures import PROJ

ALL_FILES = 14  # files under fixtures/proj recognised as source code


def _force_build_paused_before_publish(cfg, publish_ready, allow_publish):
    from codegraph import builder

    original_replace = builder.os.replace

    def pause_before_replace(source, destination):
        publish_ready.set()
        if not allow_publish.wait(10):
            raise TimeoutError("forced build publication was not released")
        original_replace(source, destination)

    with patch("codegraph.builder.os.replace", side_effect=pause_before_replace):
        build_index(cfg, force=True, quiet=True)


class BuilderTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name) / "proj"
        shutil.copytree(PROJ, self.root)

    def tearDown(self):
        self.tmp.cleanup()

    def _cfg(self, **kw):
        cfg = load_config(root=str(self.root))
        cfg.engine = "quick"  # deterministic provider for these tests
        for k, v in kw.items():
            setattr(cfg, k, v)
        return cfg

    def test_first_index_counts(self):
        report = build_index(self._cfg())
        self.assertTrue(report.complete)
        self.assertEqual(report.files_scanned, ALL_FILES)
        self.assertEqual(report.files_changed, ALL_FILES)
        self.assertEqual(report.files_skipped, 0)
        self.assertEqual(report.files_removed, 0)
        self.assertGreater(report.symbols, 0)
        self.assertGreater(report.calls, 0)
        self.assertGreater(report.imports, 0)
        self.assertEqual(sum(report.languages.values()), ALL_FILES)

    def test_invalid_roots_are_rejected_before_creating_an_index(self):
        with tempfile.TemporaryDirectory() as tmp:
            base = Path(tmp)
            missing = base / "missing"
            file_root = base / "project-file"
            file_root.write_text("not a directory", encoding="utf-8")

            cases = (
                (missing, FileNotFoundError),
                (file_root, NotADirectoryError),
            )
            for root, error in cases:
                with self.subTest(root=root):
                    cfg = load_config(
                        root=str(root), db_path=str(base / f"{root.name}.db")
                    )
                    with self.assertRaises(error):
                        build_index(cfg)
                    self.assertFalse(Path(cfg.db_path).exists())

    def test_missing_root_does_not_clear_existing_index(self):
        with tempfile.TemporaryDirectory() as tmp:
            base = Path(tmp)
            root = base / "project"
            root.mkdir()
            (root / "module.py").write_text(
                "def target():\n    return 1\n", encoding="utf-8"
            )
            cfg = load_config(
                root=str(root), db_path=str(base / "index.sqlite")
            )
            cfg.engine = "quick"
            build_index(cfg)

            shutil.rmtree(root)
            with self.assertRaises(FileNotFoundError):
                build_index(cfg)

            store = IndexStore(str(cfg.db_path))
            try:
                self.assertIsNotNone(store.file_by_path("module.py"))
            finally:
                store.close()

    def test_unchanged_second_run_skips_everything(self):
        build_index(self._cfg())
        report = build_index(self._cfg())
        self.assertEqual(report.files_skipped, ALL_FILES)
        self.assertEqual(report.files_changed, 0)
        self.assertEqual(report.files_removed, 0)
        self.assertEqual(report.symbols, 0)

    def test_unchanged_incremental_run_skips_resolution_pass(self):
        build_index(self._cfg())
        with patch("codegraph.builder.resolve_all") as resolve:
            report = build_index(self._cfg())
        self.assertEqual(report.files_skipped, ALL_FILES)
        resolve.assert_not_called()

    def test_go_module_path_change_rechecks_unchanged_imports(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "go.mod").write_text(
                "module example.com/old\n\ngo 1.22\n", encoding="utf-8")
            (root / "app.go").write_text(
                'package app\nimport "example.com/old/lib"\n'
                "func caller() { lib.Helper() }\n",
                encoding="utf-8",
            )
            (root / "lib").mkdir()
            (root / "lib" / "lib.go").write_text(
                "package lib\nfunc Helper() {}\n", encoding="utf-8")
            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            build_index(cfg, quiet=True)

            store = IndexStore(str(cfg.db_path))
            try:
                row = store.find_import(module="example.com/old/lib")
                self.assertEqual(
                    store.file_by_id(row["target_id"])["path"], "lib/lib.go"
                )
            finally:
                store.close()

            (root / "go.mod").write_text(
                "module example.com/new\n\ngo 1.22\n", encoding="utf-8")
            report = build_index(cfg, quiet=True)
            self.assertEqual(report.files_changed, 0)
            self.assertEqual(report.files_skipped, 2)

            store = IndexStore(str(cfg.db_path))
            try:
                row = store.find_import(module="example.com/old/lib")
                self.assertIsNone(row["target_id"])
            finally:
                store.close()

    def test_resolver_config_change_rechecks_unchanged_index(self):
        cfg = self._cfg()
        build_index(cfg)
        store = IndexStore(str(cfg.db_path))
        try:
            scan_config = json.loads(store.get_meta("scan_config"))
            scan_config.pop("resolver_version")
            store.set_meta("scan_config", json.dumps(scan_config))
            store.conn.commit()
        finally:
            store.close()

        with patch("codegraph.builder.resolve_all") as resolve:
            report = build_index(cfg)
        self.assertEqual(report.files_skipped, ALL_FILES)
        resolve.assert_called_once()

    def test_scanner_and_resolver_version_changes_rebuild_stale_index(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "app.ts").write_text(
                'import { make } from "./util";\n'
                "function caller() { make(); }\n",
                encoding="utf-8",
            )
            util = root / "util"
            util.mkdir()
            (util / "index.d.ts").write_text(
                "export declare function make(): void;\n", encoding="utf-8")

            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            build_index(cfg)

            store = IndexStore(str(cfg.db_path))
            try:
                app_id = store.file_by_path("app.ts")["id"]
                declaration_id = store.file_by_path("util/index.d.ts")["id"]
                store.conn.execute(
                    "UPDATE imports SET target_id = NULL WHERE file_id = ?",
                    (app_id,),
                )
                store.conn.execute(
                    "UPDATE calls SET callee_id = NULL WHERE file_id = ?",
                    (app_id,),
                )
                stale_symbol = store.conn.execute(
                    "SELECT id FROM symbols WHERE file_id = ? AND name = 'make'",
                    (declaration_id,),
                ).fetchone()
                store.conn.execute(
                    "DELETE FROM sym_fts WHERE rowid = ?", (stale_symbol["id"],)
                )
                store.conn.execute(
                    "DELETE FROM symbols WHERE id = ?", (stale_symbol["id"],)
                )
                scan_config = json.loads(store.get_meta("scan_config"))
                scan_config.pop("scanner_version")
                scan_config["resolver_version"] = 6
                store.set_meta("scan_config", json.dumps(scan_config))
                store.conn.commit()
            finally:
                store.close()

            report = build_index(cfg)

            self.assertEqual(report.files_changed, 2)
            self.assertEqual(report.files_skipped, 0)
            store = IndexStore(str(cfg.db_path))
            try:
                app_id = store.file_by_path("app.ts")["id"]
                import_row = store.imports_for_file(app_id)[0]
                call_row = store.conn.execute(
                    "SELECT callee_id FROM calls WHERE file_id = ?", (app_id,)
                ).fetchone()
                self.assertIsNotNone(import_row["target_id"])
                self.assertIsNotNone(call_row["callee_id"])
                self.assertEqual(
                    store.symbol_by_id(call_row["callee_id"])["name"], "make"
                )
            finally:
                store.close()

    def test_resolver_version_change_re_resolves_stale_absolute_import(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "foo.py").write_text(
                "def target():\n    return 'root'\n", encoding="utf-8")
            pkg = root / "pkg"
            pkg.mkdir()
            (pkg / "__init__.py").write_text("", encoding="utf-8")
            (pkg / "foo.py").write_text(
                "def target():\n    return 'package'\n", encoding="utf-8")
            (pkg / "caller.py").write_text(
                "import foo\n\n"
                "def invoke():\n    return foo.target()\n",
                encoding="utf-8",
            )

            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            build_index(cfg)

            store = IndexStore(str(cfg.db_path))
            try:
                package_id = store.file_by_path("pkg/foo.py")["id"]
                import_row = store.find_import(module="foo")
                store.conn.execute(
                    "UPDATE imports SET target_id = ? WHERE id = ?",
                    (package_id, import_row["id"]),
                )
                scan_config = json.loads(store.get_meta("scan_config"))
                scan_config["resolver_version"] = 1
                store.set_meta("scan_config", json.dumps(scan_config))
                store.conn.commit()
            finally:
                store.close()

            report = build_index(cfg)
            self.assertEqual(report.files_skipped, 4)

            store = IndexStore(str(cfg.db_path))
            try:
                import_row = store.find_import(module="foo")
                self.assertEqual(
                    store.file_by_id(import_row["target_id"])["path"], "foo.py"
                )
            finally:
                store.close()

    def test_resolver_version_change_re_resolves_fallback_import(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            src = root / "src"
            src.mkdir()
            (src / "util.py").write_text(
                "def target():\n    return 'src'\n", encoding="utf-8")
            (src / "app.py").write_text(
                "import util\n\n"
                "def invoke():\n    return util.target()\n",
                encoding="utf-8",
            )

            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            build_index(cfg)

            store = IndexStore(str(cfg.db_path))
            try:
                import_row = store.find_import(module="util")
                self.assertIsNotNone(import_row)
                store.conn.execute(
                    "UPDATE imports SET target_id = NULL WHERE id = ?",
                    (import_row["id"],),
                )
                scan_config = json.loads(store.get_meta("scan_config"))
                scan_config["resolver_version"] = 1
                store.set_meta("scan_config", json.dumps(scan_config))
                store.conn.commit()
            finally:
                store.close()

            report = build_index(cfg)
            self.assertEqual(report.files_changed, 0)
            self.assertEqual(report.files_skipped, 2)

            store = IndexStore(str(cfg.db_path))
            try:
                import_row = store.find_import(module="util")
                self.assertIsNotNone(import_row["target_id"])
                self.assertEqual(
                    store.file_by_id(import_row["target_id"])["path"],
                    "src/util.py",
                )
            finally:
                store.close()

    def test_resolver_version_change_re_resolves_typescript_js_specifier(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "app.ts").write_text(
                'import { target } from "./util.js";\n'
                "export function call() { return target(); }\n",
                encoding="utf-8",
            )
            (root / "util.ts").write_text(
                "export function target() { return 'source'; }\n",
                encoding="utf-8",
            )
            (root / "util.js").write_text(
                "export function target() { return 'output'; }\n",
                encoding="utf-8",
            )

            cfg = self._cfg(root=str(root))
            build_index(cfg)
            store = IndexStore(str(cfg.db_path))
            try:
                import_row = store.find_import(module="./util.js")
                emitted_id = store.file_by_path("util.js")["id"]
                store.conn.execute(
                    "UPDATE imports SET target_id = ? WHERE id = ?",
                    (emitted_id, import_row["id"]),
                )
                scan_config = json.loads(store.get_meta("scan_config"))
                scan_config["resolver_version"] = 5
                store.set_meta("scan_config", json.dumps(scan_config))
                store.conn.commit()
            finally:
                store.close()

            report = build_index(cfg)
            self.assertEqual(report.files_changed, 0)

            store = IndexStore(str(cfg.db_path))
            try:
                import_row = store.find_import(module="./util.js")
                self.assertEqual(
                    store.file_by_id(import_row["target_id"])["path"], "util.ts"
                )
            finally:
                store.close()

    def test_parent_cargo_workspace_change_re_resolves_member_imports(self):
        with tempfile.TemporaryDirectory() as tmp:
            workspace = Path(tmp)
            member = workspace / "member"
            src = member / "src"
            (src / "child").mkdir(parents=True)
            workspace_manifest = workspace / "Cargo.toml"
            workspace_manifest.write_text(
                "[workspace]\nmembers = [\"member\"]\n\n"
                "[workspace.package]\nedition = \"2015\"\n",
                encoding="utf-8",
            )
            (member / "Cargo.toml").write_text(
                "[package]\nname = \"member\"\nversion = \"0.1.0\"\n"
                "edition.workspace = true\n",
                encoding="utf-8",
            )
            (src / "lib.rs").write_text(
                "mod child;\nmod inner;\n", encoding="utf-8")
            (src / "child.rs").write_text(
                "mod inner;\nuse inner::foo;\nfn call() { foo(); }\n",
                encoding="utf-8",
            )
            (src / "inner.rs").write_text("fn foo() {}\n", encoding="utf-8")
            (src / "child" / "inner.rs").write_text(
                "fn foo() {}\n", encoding="utf-8")

            cfg = load_config(root=str(member))
            cfg.engine = "quick"
            build_index(cfg)

            workspace_manifest.write_text(
                "[workspace]\nmembers = [\"member\"]\n\n"
                "[workspace.package]\nedition = \"2021\"\n",
                encoding="utf-8",
            )
            report = build_index(cfg)

            self.assertEqual(report.files_changed, 0)
            self.assertGreater(report.files_skipped, 0)
            store = IndexStore(str(cfg.db_path))
            try:
                target = store.find_import(module="inner::foo")
                self.assertEqual(
                    store.file_by_id(target["target_id"])["path"],
                    "src/child/inner.rs",
                )
            finally:
                store.close()

    def test_incomplete_discovery_retains_cargo_context_for_custom_rust_extension(self):
        with tempfile.TemporaryDirectory() as tmp:
            workspace = Path(tmp)
            member = workspace / "member"
            src = member / "src"
            src.mkdir(parents=True)
            (workspace / "Cargo.toml").write_text(
                '[workspace]\nmembers = ["member"]\n\n'
                '[workspace.package]\nedition = "2021"\n',
                encoding="utf-8",
            )
            (member / "Cargo.toml").write_text(
                '[package]\nname = "member"\nversion = "0.1.0"\n'
                'edition.workspace = true\n\n'
                '[lib]\npath = "src/lib.rsx"\n',
                encoding="utf-8",
            )
            (src / "lib.rsx").write_text(
                '#[path = "child.rsx"] mod child;\n'
                "use crate::child::Thing;\n",
                encoding="utf-8",
            )
            (src / "child.rsx").write_text(
                "pub struct Thing;\n", encoding="utf-8")

            cfg = load_config(root=str(workspace))
            cfg.engine = "quick"
            cfg.language_map = {".rsx": "rust"}
            build_index(cfg, quiet=True)

            store = IndexStore(str(cfg.db_path))
            try:
                import_row = store.find_import(module="crate::child::Thing")
                self.assertEqual(
                    store.file_by_id(import_row["target_id"])["path"],
                    "member/src/child.rsx",
                )
                expected_manifests = {
                    "Cargo.toml", "member/Cargo.toml",
                }
                self.assertEqual(
                    set(json.loads(store.get_meta("cargo_manifest_paths"))),
                    expected_manifests,
                )
            finally:
                store.close()

            def incomplete_walk(path, followlinks=False, onerror=None):
                if onerror is not None:
                    onerror(PermissionError(
                        13, "Permission denied", str(member)))
                yield str(workspace), [], []

            with patch("codegraph.scanner.walk.os.walk", incomplete_walk):
                report = build_index(cfg, quiet=True)

            self.assertFalse(report.complete)
            store = IndexStore(str(cfg.db_path))
            try:
                self.assertEqual(
                    set(json.loads(store.get_meta("cargo_manifest_paths"))),
                    expected_manifests,
                )
                import_row = store.find_import(module="crate::child::Thing")
                self.assertEqual(
                    store.file_by_id(import_row["target_id"])["path"],
                    "member/src/child.rsx",
                )
            finally:
                store.close()

    def test_resolver_version_change_re_resolves_go_dotted_import(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            import_path = "example.com/acme/internal/math"
            package_dir = root / "example.com" / "acme" / "internal"
            package_dir.mkdir(parents=True)
            (root / "main.go").write_text(
                f'package main\n\nimport "{import_path}"\n',
                encoding="utf-8",
            )
            (package_dir / "math.go").write_text(
                "package math\n\nfunc Add(a, b int) int { return a + b }\n",
                encoding="utf-8",
            )

            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            build_index(cfg)

            store = IndexStore(str(cfg.db_path))
            try:
                import_row = store.find_import(module=import_path)
                self.assertIsNotNone(import_row)
                store.conn.execute(
                    "UPDATE imports SET target_id = NULL WHERE id = ?",
                    (import_row["id"],),
                )
                scan_config = json.loads(store.get_meta("scan_config"))
                scan_config["resolver_version"] = 2
                store.set_meta("scan_config", json.dumps(scan_config))
                store.conn.commit()
            finally:
                store.close()

            report = build_index(cfg)
            self.assertEqual(report.files_changed, 0)
            self.assertEqual(report.files_skipped, 2)

            store = IndexStore(str(cfg.db_path))
            try:
                import_row = store.find_import(module=import_path)
                self.assertEqual(
                    store.file_by_id(import_row["target_id"])["path"],
                    "example.com/acme/internal/math.go",
                )
            finally:
                store.close()

    def test_changed_file_reparsed_only(self):
        build_index(self._cfg())
        target = self.root / "pkg" / "pricing.py"
        target.write_text(target.read_text(encoding="utf-8") + "\n\ndef vat(x):\n    return x\n",
                          encoding="utf-8")
        report = build_index(self._cfg())
        self.assertEqual(report.files_changed, 1)
        self.assertEqual(report.files_skipped, ALL_FILES - 1)
        store = IndexStore(str(self._cfg().db_path))
        self.assertIsNotNone(store.symbol_by_qualname("pkg.pricing.vat"))
        store.close()

    def test_changed_file_clears_incoming_edges(self):
        build_index(self._cfg())
        target = self.root / "pkg" / "pricing.py"
        target.write_text(
            '"""Price lookups for the demo shop."""\n\n'
            'def discount(sku):\n    return 0\n',
            encoding="utf-8",
        )
        build_index(self._cfg())
        store = IndexStore(str(self._cfg().db_path))
        try:
            incoming = store.find_call(callee="pricing.price")
            self.assertIsNotNone(incoming)
            self.assertIsNone(incoming["callee_id"])
        finally:
            store.close()

    def test_deleted_file_removed(self):
        build_index(self._cfg())
        (self.root / "helper" / "helper.go").unlink()
        report = build_index(self._cfg())
        self.assertEqual(report.files_removed, 1)
        self.assertEqual(report.files_changed, 0)
        store = IndexStore(str(self._cfg().db_path))
        self.assertIsNone(store.file_by_path("helper/helper.go"))
        store.close()

    def test_inaccessible_directory_preserves_indexed_files(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            hidden = root / "hidden"
            target = hidden / "keep.py"
            hidden.mkdir()
            target.write_text("def keep():\n    return 1\n", encoding="utf-8")
            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            build_index(cfg)

            def incomplete_walk(path, followlinks=False, onerror=None):
                if onerror is not None:
                    onerror(PermissionError(13, "Permission denied", str(hidden)))
                yield str(root), [], []

            with patch("codegraph.scanner.walk.os.walk", incomplete_walk):
                report = build_index(cfg, quiet=True)

            self.assertEqual(report.files_removed, 0)
            store = IndexStore(str(cfg.db_path))
            try:
                self.assertIsNotNone(store.file_by_path("hidden/keep.py"))
            finally:
                store.close()

    def test_transient_stat_failure_preserves_indexed_file(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            target = root / "keep.py"
            target.write_text("def keep():\n    return 1\n", encoding="utf-8")
            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            build_index(cfg)

            original_stat = Path.stat
            failed = False

            def fail_target_once(path, *args, **kwargs):
                nonlocal failed
                if path == target and not failed:
                    failed = True
                    raise OSError("temporary stat failure")
                return original_stat(path, *args, **kwargs)

            with patch.object(Path, "stat", fail_target_once):
                report = build_index(cfg, quiet=True)

            self.assertTrue(failed)
            self.assertEqual(report.files_removed, 0)
            store = IndexStore(str(cfg.db_path))
            try:
                self.assertIsNotNone(store.file_by_path("keep.py"))
            finally:
                store.close()

    def test_deleted_file_interruption_keeps_resolution_pending(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            entry = root / "entry.ts"
            entry.write_text(
                'import { replacement } from "./util";\n'
                "export function invoke() {\n"
                "  return replacement();\n"
                "}\n",
                encoding="utf-8",
            )
            preferred = root / "util.ts"
            preferred.write_text(
                "export const selected = true;\n", encoding="utf-8")
            (root / "util.js").write_text(
                "export function replacement() { return 1; }\n",
                encoding="utf-8",
            )
            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            build_index(cfg)

            preferred.unlink()
            original_remove_file = IndexStore.remove_file
            original_set_meta = IndexStore.set_meta
            removed = False

            def remove_file(store, path):
                nonlocal removed
                impact = original_remove_file(store, path)
                removed = True
                return impact

            def set_meta(store, key, value):
                if removed and key == "resolution_pending" and value == "1":
                    raise RuntimeError("interrupted after file removal")
                return original_set_meta(store, key, value)

            with patch.object(IndexStore, "remove_file", remove_file), \
                    patch.object(IndexStore, "set_meta", set_meta):
                with self.assertRaises(RuntimeError):
                    build_index(cfg)

            store = IndexStore(str(cfg.db_path))
            try:
                self.assertEqual(store.get_meta("resolution_pending"), "1")
                self.assertIsNone(store.find_import(module="./util")["target_id"])
            finally:
                store.close()

            build_index(cfg)

            store = IndexStore(str(cfg.db_path))
            try:
                self.assertEqual(
                    store.find_import(module="./util")["target_id"],
                    store.file_by_path("util.js")["id"],
                )
                call = store.find_call(callee="replacement")
                self.assertIsNotNone(call["callee_id"])
                self.assertEqual(
                    store.file_by_id(call["callee_id"])["path"], "util.js"
                )
                self.assertEqual(store.get_meta("resolution_pending"), "0")
            finally:
                store.close()

    def test_deleted_empty_file_clears_resolution_pending(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            empty = root / "empty.py"
            empty.write_text("# no symbols or references\n", encoding="utf-8")
            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            build_index(cfg)

            empty.unlink()
            build_index(cfg)

            store = IndexStore(str(cfg.db_path))
            try:
                self.assertEqual(store.get_meta("resolution_pending"), "0")
            finally:
                store.close()

            with patch("codegraph.builder.resolve_all") as resolve:
                build_index(cfg)
            resolve.assert_not_called()

    def test_force_reparses_all(self):
        cfg = self._cfg()
        build_index(cfg)
        target = self.root / "pkg" / "pricing.py"
        target.write_text(
            '"""Price lookups for the demo shop."""\n\n'
            "def force_marker():\n    return 1\n",
            encoding="utf-8",
        )
        report = build_index(cfg, force=True)
        self.assertTrue(report.complete)
        self.assertEqual(report.files_changed, ALL_FILES)
        self.assertEqual(report.files_skipped, 0)
        store = IndexStore(str(cfg.db_path))
        try:
            self.assertIsNotNone(store.symbol_by_qualname("pkg.pricing.force_marker"))
            self.assertIsNone(store.symbol_by_qualname("pkg.pricing.price"))
        finally:
            store.close()

    def test_force_scan_failure_preserves_existing_index(self):
        cfg = self._cfg()
        build_index(cfg)

        with patch("codegraph.builder.scan_text",
                   side_effect=RuntimeError("temporary scan failure")):
            with self.assertRaises(RuntimeError):
                build_index(cfg, force=True)

        store = IndexStore(str(cfg.db_path))
        try:
            self.assertIsNotNone(store.file_by_path("app.py"))
            self.assertIsNotNone(store.symbol_by_qualname("app.main"))
        finally:
            store.close()

    def test_force_incomplete_discovery_preserves_existing_index(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            hidden = root / "hidden"
            target = hidden / "keep.py"
            hidden.mkdir()
            target.write_text("def keep():\n    return 1\n", encoding="utf-8")
            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            build_index(cfg)

            def incomplete_walk(path, followlinks=False, onerror=None):
                if onerror is not None:
                    onerror(PermissionError(13, "Permission denied", str(hidden)))
                yield str(root), [], []

            with patch("codegraph.scanner.walk.os.walk", incomplete_walk):
                report = build_index(cfg, force=True, quiet=True)

            self.assertFalse(report.complete)
            self.assertEqual(report.files_removed, 0)
            store = IndexStore(str(cfg.db_path))
            try:
                self.assertIsNotNone(store.file_by_path("hidden/keep.py"))
                self.assertIsNotNone(store.symbol_by_qualname("hidden.keep.keep"))
            finally:
                store.close()

    def test_force_read_failure_preserves_existing_index(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            target = root / "keep.py"
            target.write_text("def keep():\n    return 1\n", encoding="utf-8")
            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            build_index(cfg)

            original_read_bytes = Path.read_bytes
            failed = False

            def fail_target_once(path):
                nonlocal failed
                if path == target and not failed:
                    failed = True
                    raise OSError("temporary read failure")
                return original_read_bytes(path)

            with patch.object(Path, "read_bytes", fail_target_once):
                report = build_index(cfg, force=True, quiet=True)

            self.assertTrue(failed)
            self.assertFalse(report.complete)
            store = IndexStore(str(cfg.db_path))
            try:
                self.assertIsNotNone(store.file_by_path("keep.py"))
                self.assertIsNotNone(store.symbol_by_qualname("keep.keep"))
            finally:
                store.close()

    def test_force_rebuild_publishes_external_database(self):
        with tempfile.TemporaryDirectory() as tmp:
            base = Path(tmp)
            root = base / "source"
            db_parent = base / "index"
            root.mkdir()
            target = root / "module.py"
            target.write_text("def original():\n    return 1\n", encoding="utf-8")
            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            cfg.db_path = str(db_parent / "cg.sqlite")
            build_index(cfg)

            target.write_text("def replacement():\n    return 2\n", encoding="utf-8")
            report = build_index(cfg, force=True, quiet=True)

            self.assertEqual(report.files_changed, 1)
            store = IndexStore(str(cfg.db_path))
            try:
                self.assertIsNotNone(store.symbol_by_qualname("module.replacement"))
                self.assertIsNone(store.symbol_by_qualname("module.original"))
            finally:
                store.close()

    def test_force_rebuild_waits_for_inflight_incremental_build(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            source = root / "module.py"
            source.write_text("def original():\n    return 1\n", encoding="utf-8")
            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            build_index(cfg, quiet=True)

            source.write_text(
                "def force_snapshot():\n    return 2\n", encoding="utf-8")
            force_scan_started = threading.Event()
            release_force_scan = threading.Event()
            incremental_call_started = threading.Event()
            incremental_scan_started = threading.Event()
            errors = []
            from codegraph.scanner import scan_text as real_scan_text

            def controlled_scan(text, lang, rel_path, engine):
                if "force_snapshot" in text:
                    force_scan_started.set()
                    if not release_force_scan.wait(5):
                        raise TimeoutError("force scan was not released")
                elif "newer_incremental" in text:
                    incremental_scan_started.set()
                return real_scan_text(text, lang, rel_path, engine)

            def run_build(force=False, call_started=None):
                if call_started is not None:
                    call_started.set()
                try:
                    build_index(cfg, force=force, quiet=True)
                except Exception as exc:
                    errors.append(exc)

            with patch("codegraph.builder.scan_text", side_effect=controlled_scan):
                force_thread = threading.Thread(
                    target=run_build, kwargs={"force": True},
                    name="force-build",
                )
                incremental_thread = None
                force_thread.start()
                try:
                    self.assertTrue(force_scan_started.wait(5))
                    source.write_text(
                        "def newer_incremental():\n    return 3\n",
                        encoding="utf-8",
                    )
                    incremental_thread = threading.Thread(
                        target=run_build,
                        kwargs={"call_started": incremental_call_started},
                        name="incremental-build",
                    )
                    incremental_thread.start()
                    self.assertTrue(incremental_call_started.wait(5))
                    self.assertFalse(incremental_scan_started.wait(0.2))
                finally:
                    release_force_scan.set()
                    force_thread.join(5)
                    if incremental_thread is not None:
                        incremental_thread.join(5)

            self.assertFalse(force_thread.is_alive())
            self.assertIsNotNone(incremental_thread)
            self.assertFalse(incremental_thread.is_alive())
            self.assertEqual(errors, [])
            store = IndexStore(str(cfg.db_path))
            try:
                self.assertIsNotNone(
                    store.symbol_by_qualname("module.newer_incremental")
                )
                self.assertIsNone(
                    store.symbol_by_qualname("module.force_snapshot")
                )
            finally:
                store.close()

    def test_force_rebuild_cannot_overwrite_incremental_update_in_another_process(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            source = root / "sample.py"
            source.write_text("def before():\n    return 1\n", encoding="utf-8")
            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            build_index(cfg, quiet=True)

            context = multiprocessing.get_context("spawn")
            publish_ready = context.Event()
            allow_publish = context.Event()
            force_process = context.Process(
                target=_force_build_paused_before_publish,
                args=(cfg, publish_ready, allow_publish),
            )
            incremental_started = threading.Event()
            incremental_finished = threading.Event()
            incremental_errors = []

            def run_incremental():
                incremental_started.set()
                try:
                    build_index(cfg, quiet=True)
                except Exception as exc:
                    incremental_errors.append(exc)
                finally:
                    incremental_finished.set()

            incremental_thread = None
            force_process.start()
            try:
                self.assertTrue(publish_ready.wait(5))
                source.write_text(
                    "def after():\n    return 2\n", encoding="utf-8")
                incremental_thread = threading.Thread(target=run_incremental)
                incremental_thread.start()
                self.assertTrue(incremental_started.wait(5))
                incremental_finished_while_publish_paused = incremental_finished.wait(0.2)
            finally:
                allow_publish.set()
                force_process.join(10)
                if force_process.is_alive():
                    force_process.terminate()
                    force_process.join(5)
                if incremental_thread is not None:
                    incremental_thread.join(10)

            self.assertEqual(force_process.exitcode, 0)
            self.assertIsNotNone(incremental_thread)
            self.assertFalse(incremental_thread.is_alive())
            self.assertEqual(incremental_errors, [])
            self.assertFalse(
                incremental_finished_while_publish_paused,
                "incremental build committed while the older forced build "
                "was waiting to publish",
            )

            store = IndexStore(str(cfg.db_path))
            try:
                self.assertIsNotNone(store.symbol_by_qualname("sample.after"))
                self.assertIsNone(store.symbol_by_qualname("sample.before"))
            finally:
                store.close()

    def test_incremental_builds_commit_in_source_order(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            source = root / "module.py"
            source.write_text("def original():\n    return 1\n", encoding="utf-8")
            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            build_index(cfg, quiet=True)

            source.write_text(
                "def first_snapshot():\n    return 2\n", encoding="utf-8")
            first_scan_started = threading.Event()
            release_first_scan = threading.Event()
            second_call_started = threading.Event()
            second_scan_started = threading.Event()
            errors = []
            from codegraph.scanner import scan_text as real_scan_text

            def controlled_scan(text, lang, rel_path, engine):
                if "first_snapshot" in text:
                    first_scan_started.set()
                    if not release_first_scan.wait(5):
                        raise TimeoutError("first scan was not released")
                elif "second_snapshot" in text:
                    second_scan_started.set()
                return real_scan_text(text, lang, rel_path, engine)

            def run_build(call_started=None):
                if call_started is not None:
                    call_started.set()
                try:
                    build_index(cfg, quiet=True)
                except Exception as exc:
                    errors.append(exc)

            with patch("codegraph.builder.scan_text", side_effect=controlled_scan):
                first_thread = threading.Thread(
                    target=run_build, name="first-incremental-build",
                )
                second_thread = None
                first_thread.start()
                try:
                    self.assertTrue(first_scan_started.wait(5))
                    source.write_text(
                        "def second_snapshot():\n    return 3\n",
                        encoding="utf-8",
                    )
                    second_thread = threading.Thread(
                        target=run_build,
                        kwargs={"call_started": second_call_started},
                        name="second-incremental-build",
                    )
                    second_thread.start()
                    self.assertTrue(second_call_started.wait(5))
                    self.assertFalse(second_scan_started.wait(0.2))
                finally:
                    release_first_scan.set()
                    first_thread.join(5)
                    if second_thread is not None:
                        second_thread.join(5)

            self.assertFalse(first_thread.is_alive())
            self.assertIsNotNone(second_thread)
            self.assertFalse(second_thread.is_alive())
            self.assertEqual(errors, [])
            store = IndexStore(str(cfg.db_path))
            try:
                self.assertIsNotNone(
                    store.symbol_by_qualname("module.second_snapshot")
                )
                self.assertIsNone(
                    store.symbol_by_qualname("module.first_snapshot")
                )
            finally:
                store.close()

    def test_language_map_change_replaces_unchanged_file_payload(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "module.py").write_text(
                "def target():\n    return 1\n", encoding="utf-8")
            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            build_index(cfg)

            cfg.language_map = {".py": "javascript"}
            report = build_index(cfg)

            self.assertEqual(report.files_changed, 1)
            self.assertEqual(report.files_skipped, 0)
            store = IndexStore(str(cfg.db_path))
            try:
                self.assertEqual(store.file_by_path("module.py")["lang"], "javascript")
                self.assertIsNone(store.symbol_by_qualname("module.target"))
            finally:
                store.close()

    def test_engine_change_replaces_unchanged_file_payload(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "module.py").write_text(
                "def target():\n    return 1\n", encoding="utf-8")
            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            build_index(cfg)

            cfg.engine = "auto"
            replacement = FileScan(
                "python", "module",
                [SymbolRec("function", "auto_marker", "module.auto_marker", "", 1, 1, "")],
            )
            with patch("codegraph.builder.scan_text", return_value=replacement) as scan:
                report = build_index(cfg)

            self.assertEqual(report.files_changed, 1)
            self.assertEqual(report.files_skipped, 0)
            scan.assert_called_once_with("def target():\n    return 1\n", "python",
                                         "module.py", "auto")
            store = IndexStore(str(cfg.db_path))
            try:
                self.assertIsNotNone(store.symbol_by_qualname("module.auto_marker"))
                self.assertIsNone(store.symbol_by_qualname("module.target"))
            finally:
                store.close()

    def test_auto_provider_change_replaces_unchanged_file_payload(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            source = root / "module.py"
            source.write_text("def target():\n    return 1\n", encoding="utf-8")
            cfg = load_config(root=str(root))

            quick_scan = FileScan(
                "python", "module",
                [SymbolRec("function", "quick_marker", "module.quick_marker", "", 1, 1, "")],
            )
            deep_scan = FileScan(
                "python", "module",
                [SymbolRec("function", "deep_marker", "module.deep_marker", "", 1, 1, "")],
            )

            with patch("codegraph.scanner.deep.supports", return_value=False), \
                    patch("codegraph.scanner.quick.quick_scan", return_value=quick_scan):
                build_index(cfg)

            with patch("codegraph.scanner.deep.supports", return_value=True), \
                    patch("codegraph.scanner.deep.deep_scan", return_value=deep_scan) as scan:
                report = build_index(cfg)

            self.assertEqual(report.files_changed, 1)
            self.assertEqual(report.files_skipped, 0)
            scan.assert_called_once_with(
                "def target():\n    return 1\n", "python", "module.py"
            )
            store = IndexStore(str(cfg.db_path))
            try:
                self.assertIsNotNone(store.symbol_by_qualname("module.deep_marker"))
                self.assertIsNone(store.symbol_by_qualname("module.quick_marker"))
            finally:
                store.close()

    def test_unrelated_provider_change_skips_unchanged_file(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "module.py").write_text(
                "def target():\n    return 1\n", encoding="utf-8")
            cfg = load_config(root=str(root))
            quick_scan = FileScan(
                "python", "module",
                [SymbolRec("function", "quick_marker", "module.quick_marker", "", 1, 1, "")],
            )

            def no_deep_provider(lang):
                return False

            def javascript_only_provider(lang):
                return lang == "javascript"

            with patch("codegraph.scanner.deep.supports", side_effect=no_deep_provider), \
                    patch("codegraph.scanner.quick.quick_scan", return_value=quick_scan):
                build_index(cfg)

            with patch("codegraph.scanner.deep.supports", side_effect=javascript_only_provider), \
                    patch("codegraph.scanner.quick.quick_scan", return_value=quick_scan) as scan:
                report = build_index(cfg)

            self.assertEqual(report.files_changed, 0)
            self.assertEqual(report.files_skipped, 1)
            scan.assert_not_called()

    def test_config_change_retries_file_after_transient_read_failure(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            target = root / "target.py"
            other = root / "other.py"
            target.write_text("def target():\n    return 1\n", encoding="utf-8")
            other.write_text("def other():\n    return 2\n", encoding="utf-8")
            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            build_index(cfg)

            cfg.language_map = {".py": "javascript"}
            original_read_bytes = Path.read_bytes
            failed = False

            def fail_target_once(path):
                nonlocal failed
                if path == target and not failed:
                    failed = True
                    raise OSError("temporary read failure")
                return original_read_bytes(path)

            with patch.object(Path, "read_bytes", fail_target_once):
                first = build_index(cfg, quiet=True)

            self.assertTrue(failed)
            self.assertEqual(first.files_changed, 1)
            report = build_index(cfg, quiet=True)
            self.assertEqual(report.files_changed, 2)
            self.assertEqual(report.files_skipped, 0)

            store = IndexStore(str(cfg.db_path))
            try:
                self.assertEqual(store.file_by_path("target.py")["lang"], "javascript")
            finally:
                store.close()

    def test_last_indexed_meta_written(self):
        build_index(self._cfg())
        store = IndexStore(str(self._cfg().db_path))
        self.assertIsNotNone(store.get_meta("last_indexed"))
        store.close()

    def test_resolution_fills_edges(self):
        build_index(self._cfg())
        store = IndexStore(str(self._cfg().db_path))
        try:
            # a call that resolves cross-file: app.main -> create_cart
            row = store.find_call(callee="create_cart")
            self.assertIsNotNone(row)
            self.assertIsNotNone(row["callee_id"])
            # module import resolves: app.py -> pkg/pricing.py
            imp = store.find_import(module="pkg.pricing")
            self.assertIsNotNone(imp["target_id"])
            # stdlib import stays unresolved
            imp_os = store.find_import(module="os")
            self.assertIsNone(imp_os["target_id"])
        finally:
            store.close()

    def test_failed_resolution_is_retried_on_next_incremental_run(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            caller = root / "caller.py"
            caller.write_text(
                "def invoke():\n    return missing()\n", encoding="utf-8")
            (root / "target.py").write_text(
                "def target():\n    return 1\n", encoding="utf-8")
            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            build_index(cfg)

            caller.write_text(
                "def invoke():\n    return target()\n", encoding="utf-8")
            with patch(
                    "codegraph.builder.resolve_all",
                    side_effect=RuntimeError("temporary resolution failure")):
                with self.assertRaises(RuntimeError):
                    build_index(cfg)

            report = build_index(cfg)
            self.assertEqual(report.files_changed, 0)
            self.assertEqual(report.files_skipped, 2)

            store = IndexStore(str(cfg.db_path))
            try:
                call = store.find_call(callee="target")
                self.assertIsNotNone(call["callee_id"])
                self.assertEqual(store.get_meta("resolution_pending"), "0")
                self.assertEqual(
                    store.symbol_by_id(call["callee_id"]).qualname, "target.target"
                )
            finally:
                store.close()

    def test_scan_failure_after_payload_commit_is_retried_on_next_incremental_run(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "a_target.py").write_text(
                "def target():\n    return 1\n", encoding="utf-8")
            (root / "m_caller.py").write_text(
                "def invoke():\n    return target()\n", encoding="utf-8")
            (root / "z_later.py").write_text(
                "value = 1\n", encoding="utf-8")
            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            build_index(cfg)

            (root / "a_target.py").write_text(
                "def target():\n    return 2\n", encoding="utf-8")
            (root / "z_later.py").write_text(
                "value = 2\n", encoding="utf-8")
            from codegraph.scanner import scan_text as real_scan_text

            def fail_later(text, lang, rel_path, engine):
                if rel_path == "z_later.py":
                    raise RuntimeError("temporary scan failure")
                return real_scan_text(text, lang, rel_path, engine)

            with patch("codegraph.builder.scan_text", side_effect=fail_later):
                with self.assertRaises(RuntimeError):
                    build_index(cfg)

            store = IndexStore(str(cfg.db_path))
            try:
                self.assertEqual(store.get_meta("resolution_pending"), "1")
                self.assertIsNone(store.find_call(callee="target")["callee_id"])
            finally:
                store.close()

            report = build_index(cfg)
            self.assertEqual(report.files_changed, 1)
            self.assertEqual(report.files_skipped, 2)

            store = IndexStore(str(cfg.db_path))
            try:
                call = store.find_call(callee="target")
                self.assertIsNotNone(call["callee_id"])
                self.assertEqual(store.get_meta("resolution_pending"), "0")
            finally:
                store.close()

    def test_new_higher_priority_import_candidate_re_resolves_import(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "entry.ts").write_text(
                'import { value } from "./util";\n', encoding="utf-8")
            (root / "util.js").write_text(
                "export const value = 'js';\n", encoding="utf-8")
            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            build_index(cfg)

            store = IndexStore(str(cfg.db_path))
            try:
                imp = store.find_import(module="./util")
                self.assertEqual(imp["target_id"], store.file_by_path("util.js")["id"])
            finally:
                store.close()

            (root / "util.ts").write_text(
                "export const value = 'ts';\n", encoding="utf-8")
            build_index(cfg)

            store = IndexStore(str(cfg.db_path))
            try:
                imp = store.find_import(module="./util")
                self.assertEqual(imp["target_id"], store.file_by_path("util.ts")["id"])
            finally:
                store.close()

    def test_deleted_import_candidate_rechecks_calls_in_importing_file(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "entry.ts").write_text(
                'import { replacement } from "./util";\n'
                "export function invoke() {\n"
                "  return replacement();\n"
                "}\n",
                encoding="utf-8",
            )
            (root / "util.ts").write_text(
                "export const selected = true;\n", encoding="utf-8")
            (root / "util.js").write_text(
                "export function replacement() { return 1; }\n",
                encoding="utf-8",
            )
            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            build_index(cfg)

            store = IndexStore(str(cfg.db_path))
            try:
                self.assertEqual(
                    store.find_import(module="./util")["target_id"],
                    store.file_by_path("util.ts")["id"],
                )
                self.assertIsNone(store.find_call(callee="replacement")["callee_id"])
            finally:
                store.close()

            (root / "util.ts").unlink()
            report = build_index(cfg)

            store = IndexStore(str(cfg.db_path))
            try:
                self.assertEqual(report.files_removed, 1)
                self.assertEqual(
                    store.find_import(module="./util")["target_id"],
                    store.file_by_path("util.js")["id"],
                )
                call = store.find_call(callee="replacement")
                self.assertIsNotNone(call["callee_id"])
                self.assertEqual(
                    store.file_by_id(call["callee_id"])["path"], "util.js"
                )
            finally:
                store.close()

    def test_import_target_change_does_not_fallback_to_obsolete_symbol(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "entry.ts").write_text(
                'import { old } from "./util";\n'
                "export function invoke() {\n"
                "  return old();\n"
                "}\n",
                encoding="utf-8",
            )
            (root / "util.js").write_text(
                "export function old() { return 1; }\n", encoding="utf-8")
            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            build_index(cfg)

            store = IndexStore(str(cfg.db_path))
            try:
                call = store.find_call(callee="old")
                self.assertEqual(
                    store.file_by_id(call["callee_id"])["path"], "util.js"
                )
            finally:
                store.close()

            (root / "util.ts").write_text(
                "export function replacement() { return 2; }\n", encoding="utf-8")
            build_index(cfg)

            store = IndexStore(str(cfg.db_path))
            try:
                self.assertEqual(
                    store.find_import(module="./util")["target_id"],
                    store.file_by_path("util.ts")["id"],
                )
                self.assertIsNone(store.find_call(callee="old")["callee_id"])
            finally:
                store.close()

            build_index(cfg, force=True)

            store = IndexStore(str(cfg.db_path))
            try:
                self.assertIsNone(store.find_call(callee="old")["callee_id"])
            finally:
                store.close()

    def test_new_duplicate_symbol_invalidates_resolved_calls(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "caller.py").write_text(
                "def invoke():\n    return target()\n", encoding="utf-8")
            (root / "first.py").write_text(
                "def target():\n    return 1\n", encoding="utf-8")
            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            build_index(cfg)

            store = IndexStore(str(cfg.db_path))
            try:
                call = store.find_call(callee="target")
                self.assertEqual(
                    store.symbol_by_id(call["callee_id"]).qualname, "first.target"
                )
            finally:
                store.close()

            (root / "second.py").write_text(
                "def target():\n    return 2\n", encoding="utf-8")
            build_index(cfg)

            store = IndexStore(str(cfg.db_path))
            try:
                self.assertIsNone(store.find_call(callee="target")["callee_id"])
            finally:
                store.close()

    def test_removed_duplicate_symbol_resolves_calls_again(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "caller.py").write_text(
                "def invoke():\n    return target()\n", encoding="utf-8")
            (root / "first.py").write_text(
                "def target():\n    return 1\n", encoding="utf-8")
            (root / "second.py").write_text(
                "def target():\n    return 2\n", encoding="utf-8")
            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            build_index(cfg)

            store = IndexStore(str(cfg.db_path))
            try:
                self.assertIsNone(store.find_call(callee="target")["callee_id"])
            finally:
                store.close()

            (root / "second.py").unlink()
            build_index(cfg)

            store = IndexStore(str(cfg.db_path))
            try:
                call = store.find_call(callee="target")
                self.assertIsNotNone(call["callee_id"])
                self.assertEqual(
                    store.symbol_by_id(call["callee_id"]).qualname, "first.target"
                )
            finally:
                store.close()


if __name__ == "__main__":
    unittest.main()
