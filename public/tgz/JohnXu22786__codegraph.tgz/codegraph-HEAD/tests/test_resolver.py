"""Tests for symbol/module resolution (resolver)."""

import json
import shutil
import sqlite3
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from codegraph.builder import build_index
from codegraph.config import load_config
from codegraph.resolver import resolve_all, resolve_callee, resolve_module
from codegraph.store import IndexStore

from .fixtures import PROJ


class ResolverTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name) / "proj"
        shutil.copytree(PROJ, self.root)
        cfg = load_config(root=str(self.root))
        cfg.engine = "quick"
        build_index(cfg)
        self.store = IndexStore(str(cfg.db_path))

    def tearDown(self):
        self.store.close()
        self.tmp.cleanup()

    def _file_id(self, rel):
        return self.store.file_by_path(rel).id

    def _callee(self, rel, text):
        return resolve_callee(self.store, self._file_id(rel), text)

    def test_same_file(self):
        # price() called from within pricing.py itself
        pid = self._callee("pkg/pricing.py", "price")
        self.assertIsNotNone(pid)
        self.assertEqual(
            self.store.symbol_by_id(pid).qualname, "pkg.pricing.price"
        )

    def test_cross_file_via_import(self):
        cid = self._callee("app.py", "create_cart")
        self.assertIsNotNone(cid)
        self.assertEqual(self.store.symbol_by_id(cid).qualname, "pkg.cart.create_cart")

    def test_python_aliased_submodule_call_with_duplicate_symbol(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            for package in ("pkg", "other"):
                (root / package).mkdir()
            (root / "pkg" / "__init__.py").write_text(
                "def price(x):\n    return x + 1\n", encoding="utf-8")
            (root / "pkg" / "pricing.py").write_text(
                "def price(x):\n    return x\n", encoding="utf-8")
            (root / "other" / "pricing.py").write_text(
                "def price(x):\n    return x\n", encoding="utf-8")
            (root / "app.py").write_text(
                "from pkg import pricing as p\n"
                "def total(x):\n    return p.price(x)\n",
                encoding="utf-8",
            )

            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            build_index(cfg, quiet=True)
            store = IndexStore(str(cfg.db_path))
            try:
                app_id = store.file_by_path("app.py")["id"]
                target_id = resolve_callee(store, app_id, "p.price")
                self.assertIsNotNone(target_id)
                self.assertEqual(
                    store.symbol_by_id(target_id).qualname, "pkg.pricing.price"
                )
            finally:
                store.close()

    def test_python_dotted_module_alias_resolves_duplicate_symbols(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            for package in ("pkg", "other"):
                (root / package).mkdir()
                (root / package / "__init__.py").write_text(
                    "", encoding="utf-8")
                (root / package / "pricing.py").write_text(
                    "def price():\n    return 1\n", encoding="utf-8")
            (root / "app.py").write_text(
                "import pkg.pricing as p\n"
                "import other.pricing as q\n"
                "def caller():\n    return p.price() + q.price()\n",
                encoding="utf-8",
            )

            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            build_index(cfg, quiet=True)
            store = IndexStore(str(cfg.db_path))
            try:
                app_id = store.file_by_path("app.py")["id"]
                expected = {
                    "p.price": ("pkg/pricing.py", "pkg.pricing.price"),
                    "q.price": ("other/pricing.py", "other.pricing.price"),
                }
                for callee, (path, qualname) in expected.items():
                    with self.subTest(callee=callee):
                        target_id = resolve_callee(store, app_id, callee)
                        self.assertIsNotNone(target_id)
                        target = store.symbol_by_id(target_id)
                        self.assertEqual(target.qualname, qualname)
                        self.assertEqual(
                            store.file_by_id(target["file_id"])["path"], path
                        )
                        call = store.find_call(callee=callee, file_id=app_id)
                        self.assertIsNotNone(call)
                        self.assertEqual(call["callee_id"], target_id)
            finally:
                store.close()

    def test_python_function_local_aliases_resolve_in_caller_scope(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            for module in ("module_target", "first", "second"):
                (root / f"{module}.py").write_text(
                    "def run():\n    return None\n", encoding="utf-8")
            (root / "app.py").write_text(
                "from module_target import run as task\n"
                "task()\n"
                "def first_caller():\n"
                "    from first import run as task\n"
                "    task()\n"
                "def second_caller():\n"
                "    from second import run as task\n"
                "    task()\n",
                encoding="utf-8",
            )

            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            build_index(cfg)
            store = IndexStore(str(cfg.db_path))
            try:
                app_id = store.file_by_path("app.py")["id"]
                calls = store.conn.execute(
                    "SELECT caller_name, callee_id FROM calls "
                    "WHERE file_id = ? ORDER BY line",
                    (app_id,),
                ).fetchall()
                targets = {
                    call["caller_name"]:
                    store.symbol_by_id(call["callee_id"])["qualname"]
                    for call in calls
                }
                self.assertEqual(
                    targets,
                    {
                        "": "module_target.run",
                        "app.first_caller": "first.run",
                        "app.second_caller": "second.run",
                    },
                )
            finally:
                store.close()

    def test_python_imported_symbol_alias_resolves_with_duplicate_name(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            package = root / "pkg"
            package.mkdir()
            (package / "__init__.py").write_text("", encoding="utf-8")
            (package / "pricing.py").write_text(
                "def price():\n    return 1\n", encoding="utf-8")
            (root / "other.py").write_text(
                "def price():\n    return 2\n", encoding="utf-8")
            (root / "app.py").write_text(
                "from pkg.pricing import price as p\n"
                "def caller():\n    return p()\n",
                encoding="utf-8",
            )

            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            build_index(cfg)
            store = IndexStore(str(cfg.db_path))
            try:
                app_id = store.file_by_path("app.py")["id"]
                target_id = resolve_callee(store, app_id, "p")
                self.assertIsNotNone(target_id)
                target = store.symbol_by_id(target_id)
                self.assertEqual(target.name, "price")
                self.assertEqual(
                    store.file_by_id(target.file_id)["path"], "pkg/pricing.py"
                )
                call = store.find_call(callee="p", file_id=app_id)
                self.assertIsNotNone(call)
                self.assertEqual(call["callee_id"], target_id)
            finally:
                store.close()

    def test_python_unaliased_import_resolves_with_duplicate_name(self):
        for engine in ("quick", "deep", "auto"):
            with self.subTest(engine=engine):
                with tempfile.TemporaryDirectory() as tmp:
                    root = Path(tmp)
                    (root / "pkg").mkdir()
                    (root / "pkg" / "a.py").write_text(
                        "def foo():\n    return 1\n", encoding="utf-8")
                    (root / "pkg" / "b.py").write_text(
                        "def foo():\n    return 2\n"
                        "def bar():\n    return 3\n",
                        encoding="utf-8",
                    )
                    (root / "app.py").write_text(
                        "from pkg.a import foo\n"
                        "from pkg.b import bar\n"
                        "def caller():\n    return foo()\n",
                        encoding="utf-8",
                    )

                    cfg = load_config(root=str(root))
                    cfg.engine = engine
                    build_index(cfg, quiet=True)
                    store = IndexStore(str(cfg.db_path))
                    try:
                        app_id = store.file_by_path("app.py")["id"]
                        call = store.find_call(callee="foo", file_id=app_id)
                        self.assertIsNotNone(call["callee_id"])
                        target = store.symbol_by_id(call["callee_id"])
                        self.assertEqual(target["qualname"], "pkg.a.foo")
                    finally:
                        store.close()

    def test_python_tab_separated_aliases_resolve_across_engines(self):
        cases = (
            {
                "statement": "from pkg.pricing import price\tas\tp\n",
                "body": "def caller():\n    return p()\n",
                "call": "p",
                "target": "pkg.pricing.price",
                "other_path": "other.py",
                "other_source": "def p():\n    return 2\n",
            },
            {
                "statement": "from pkg import pricing\tas\tp\n",
                "body": "def caller():\n    return p.price()\n",
                "call": "p.price",
                "target": "pkg.pricing.price",
                "other_path": "other/pricing.py",
                "other_source": "def price():\n    return 2\n",
            },
        )
        for engine in ("quick", "deep", "auto"):
            for case in cases:
                with self.subTest(engine=engine, call=case["call"]):
                    with tempfile.TemporaryDirectory() as tmp:
                        root = Path(tmp)
                        package = root / "pkg"
                        package.mkdir()
                        (package / "__init__.py").write_text(
                            "def price():\n    return 0\n", encoding="utf-8")
                        (package / "pricing.py").write_text(
                            "def price():\n    return 1\n", encoding="utf-8")
                        other = root / case["other_path"]
                        other.parent.mkdir(parents=True, exist_ok=True)
                        other.write_text(case["other_source"], encoding="utf-8")
                        (root / "app.py").write_text(
                            case["statement"] + case["body"],
                            encoding="utf-8",
                        )

                        cfg = load_config(root=str(root))
                        cfg.engine = engine
                        build_index(cfg)
                        store = IndexStore(str(cfg.db_path))
                        try:
                            app_id = store.file_by_path("app.py")["id"]
                            target_id = resolve_callee(
                                store, app_id, case["call"]
                            )
                            self.assertIsNotNone(target_id)
                            self.assertEqual(
                                store.symbol_by_id(target_id)["qualname"],
                                case["target"],
                            )
                        finally:
                            store.close()

    def test_absolute_python_import_falls_back_to_source_root(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            src = root / "src"
            src.mkdir()
            (src / "util.py").write_text(
                "def target():\n    return 'src'\n", encoding="utf-8")
            (src / "app.py").write_text(
                "import util\n\n"
                "def invoke():\n    return util.target()\n",
                encoding="utf-8",
            )

            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            build_index(cfg)
            store = IndexStore(str(cfg.db_path))
            try:
                fid = store.file_by_path("src/app.py")["id"]
                self.assertEqual(
                    resolve_module(store, fid, "util"),
                    store.file_by_path("src/util.py")["id"],
                )
                call = store.find_call(callee="util.target", file_id=fid)
                self.assertIsNotNone(call)
                self.assertEqual(
                    store.symbol_by_id(call["callee_id"]).file_id,
                    store.file_by_path("src/util.py")["id"],
                )
            finally:
                store.close()

    def test_absolute_python_import_prefers_project_root(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "util.py").write_text(
                "def target():\n    return 'root'\n", encoding="utf-8")
            src = root / "src"
            src.mkdir()
            (src / "util.py").write_text(
                "def target():\n    return 'src'\n", encoding="utf-8")
            (src / "app.py").write_text(
                "import util\n\n"
                "def invoke():\n    return util.target()\n",
                encoding="utf-8",
            )

            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            build_index(cfg)
            store = IndexStore(str(cfg.db_path))
            try:
                fid = store.file_by_path("src/app.py")["id"]
                self.assertEqual(
                    resolve_module(store, fid, "util"),
                    store.file_by_path("util.py")["id"],
                )
                call = store.find_call(callee="util.target", file_id=fid)
                self.assertIsNotNone(call)
                self.assertEqual(
                    store.symbol_by_id(call["callee_id"]).file_id,
                    store.file_by_path("util.py")["id"],
                )
            finally:
                store.close()

    def test_attribute_call_via_imported_submodule(self):
        # cart.py: from pkg import pricing -> pricing.discount
        sid = self._callee("pkg/cart.py", "pricing.discount")
        self.assertIsNotNone(sid)
        self.assertEqual(self.store.symbol_by_id(sid).qualname, "pkg.pricing.discount")

    def test_local_variable_heuristic_unique_global(self):
        # app.py: cart.add(...) -> unique global method add
        aid = self._callee("app.py", "cart.add")
        self.assertIsNotNone(aid)
        self.assertEqual(self.store.symbol_by_id(aid).qualname, "pkg.cart.Cart.add")

    def test_constructor_call(self):
        cid = self._callee("pkg/cart.py", "Cart")
        self.assertIsNotNone(cid)
        self.assertEqual(self.store.symbol_by_id(cid).qualname, "pkg.cart.Cart")

    def test_js_relative_import_resolution(self):
        fid = self._callee("web/index.ts", "fmt")
        self.assertIsNotNone(fid)
        self.assertEqual(self.store.symbol_by_id(fid).qualname, "web/util.fmt")

    def test_js_ts_directory_imports_resolve_index_files(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            cases = (
                ("js/app.js", "js/util/index.js", 'const util = require("./util");\n'),
                ("ts/app.ts", "ts/util/index.ts", 'import * as util from "./util";\n'),
            )
            for importer, target, statement in cases:
                importer_path = root / importer
                importer_path.parent.mkdir(parents=True, exist_ok=True)
                index_path = root / target
                index_path.parent.mkdir(parents=True, exist_ok=True)
                importer_path.write_text(
                    statement +
                    "export function caller() { return util.hello(); }\n",
                    encoding="utf-8",
                )
                index_path.write_text(
                    "export function hello() { return 1; }\n",
                    encoding="utf-8",
                )

            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            build_index(cfg)
            store = IndexStore(str(cfg.db_path))
            try:
                for importer, target, _ in cases:
                    with self.subTest(importer=importer):
                        importer_id = store.file_by_path(importer)["id"]
                        target_id = store.file_by_path(target)["id"]
                        self.assertEqual(
                            resolve_module(store, importer_id, "./util"),
                            target_id,
                        )
                        hello_id = resolve_callee(
                            store, importer_id, "util.hello"
                        )
                        self.assertIsNotNone(hello_id)
                        self.assertEqual(
                            store.symbol_by_id(hello_id).qualname,
                            Path(target).with_suffix("").as_posix() + ".hello",
                        )
                        resolved_call_ids = {
                            row["callee_id"] for row in store.conn.execute(
                                "SELECT callee_id FROM calls WHERE file_id = ?",
                                (importer_id,),
                            )
                        }
                        self.assertIn(hello_id, resolved_call_ids)
            finally:
                store.close()

    def test_ts_directory_import_resolves_declaration_index(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "app.ts").write_text(
                'import { value } from "./util";\n', encoding="utf-8")
            util = root / "util"
            util.mkdir()
            (util / "index.d.ts").write_text(
                "export declare const value: number;\n", encoding="utf-8")

            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            build_index(cfg)
            store = IndexStore(str(cfg.db_path))
            try:
                app_id = store.file_by_path("app.ts")["id"]
                target_id = resolve_module(store, app_id, "./util")
                self.assertIsNotNone(target_id)
                self.assertEqual(
                    store.file_by_id(target_id)["path"], "util/index.d.ts"
                )
            finally:
                store.close()

    def test_quick_ts_declaration_class_resolves_constructor_call(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "app.ts").write_text(
                'import { Box } from "./util";\n'
                "function caller() { return new Box(); }\n",
                encoding="utf-8",
            )
            util = root / "util"
            util.mkdir()
            (util / "index.d.ts").write_text(
                "export declare class Box { run(): void; }\n"
                "export declare interface Shape {}\n"
                "export declare type Key = string;\n",
                encoding="utf-8",
            )

            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            build_index(cfg)
            store = IndexStore(str(cfg.db_path))
            try:
                app_id = store.file_by_path("app.ts")["id"]
                target_id = resolve_callee(store, app_id, "Box")
                self.assertIsNotNone(target_id)
                self.assertEqual(
                    store.symbol_by_id(target_id)["qualname"], "util/index.Box"
                )
                declaration_symbols = {
                    row["name"]: row["kind"]
                    for row in store.conn.execute(
                        "SELECT name, kind FROM symbols WHERE file_id = ?",
                        (store.file_by_path("util/index.d.ts")["id"],),
                    )
                }
                self.assertEqual(declaration_symbols, {
                    "Box": "class", "Shape": "interface", "Key": "type"
                })
            finally:
                store.close()

    def test_ts_declaration_function_resolves_call(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "app.ts").write_text(
                'import { make } from "./util";\n'
                "function caller() { make(); }\n",
                encoding="utf-8",
            )
            util = root / "util"
            util.mkdir()
            (util / "index.d.ts").write_text(
                "export declare function make(): void;\n", encoding="utf-8")

            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            build_index(cfg)
            store = IndexStore(str(cfg.db_path))
            try:
                app_id = store.file_by_path("app.ts")["id"]
                target_id = resolve_callee(store, app_id, "make")
                self.assertIsNotNone(target_id)
                target = store.symbol_by_id(target_id)
                self.assertEqual(target.name, "make")
                self.assertEqual(
                    store.file_by_id(target.file_id)["path"], "util/index.d.ts"
                )
            finally:
                store.close()

    def test_javascript_alias_imports_resolve_source_exports(self):
        statements = (
            "import { foo as bar } from './util.js';\n",
            "const { foo: bar } = require('./util.js');\n",
        )
        for statement in statements:
            with tempfile.TemporaryDirectory() as tmp:
                root = Path(tmp)
                (root / "app.js").write_text(
                    statement + "function caller() { return bar(); }\n",
                    encoding="utf-8",
                )
                (root / "util.js").write_text(
                    "export function foo() { return 1; }\n", encoding="utf-8")
                (root / "other.js").write_text(
                    "export function bar() { return 2; }\n", encoding="utf-8")

                cfg = load_config(root=str(root))
                cfg.engine = "quick"
                build_index(cfg)
                store = IndexStore(str(cfg.db_path))
                try:
                    app_id = store.file_by_path("app.js")["id"]
                    target_id = resolve_callee(store, app_id, "bar")
                    self.assertIsNotNone(target_id)
                    target = store.symbol_by_id(target_id)
                    self.assertEqual(target.name, "foo")
                    self.assertEqual(
                        store.file_by_id(target.file_id)["path"], "util.js"
                    )
                    call_ids = [row["callee_id"] for row in store.conn.execute(
                        "SELECT callee_id FROM calls WHERE file_id = ?",
                        (app_id,),
                    )]
                    self.assertEqual(call_ids, [target_id])
                finally:
                    store.close()

    def test_commonjs_namespace_member_resolves_with_duplicate_exports(self):
        for engine in ("quick", "deep", "auto"):
            with self.subTest(engine=engine):
                with tempfile.TemporaryDirectory() as tmp:
                    root = Path(tmp)
                    (root / "lib").mkdir()
                    (root / "app.js").write_text(
                        "const util = require('./lib/util.js');\n"
                        "const other = require('./other.js');\n"
                        "function caller() { return util.run(); }\n",
                        encoding="utf-8",
                    )
                    (root / "lib" / "util.js").write_text(
                        "function run() {}\nmodule.exports = { run };\n",
                        encoding="utf-8",
                    )
                    (root / "other.js").write_text(
                        "function run() {}\nmodule.exports = { run };\n",
                        encoding="utf-8",
                    )

                    cfg = load_config(root=str(root))
                    cfg.engine = engine
                    build_index(cfg, quiet=True)
                    store = IndexStore(str(cfg.db_path))
                    try:
                        app_id = store.file_by_path("app.js")["id"]
                        target_id = resolve_callee(
                            store, app_id, "util.run"
                        )
                        self.assertIsNotNone(target_id)
                        self.assertEqual(
                            store.file_by_id(
                                store.symbol_by_id(target_id)["file_id"]
                            )["path"],
                            "lib/util.js",
                        )
                    finally:
                        store.close()

    def test_unaliased_javascript_imports_resolve_with_duplicate_exports(self):
        statements = (
            "import { foo } from './lib/util.js';\n"
            "import { bar } from './other.js';\n",
            "const { foo } = require('./lib/util.js');\n"
            "const { bar } = require('./other.js');\n",
        )
        for engine in ("quick", "deep", "auto"):
            for statement in statements:
                with self.subTest(engine=engine, statement=statement):
                    with tempfile.TemporaryDirectory() as tmp:
                        root = Path(tmp)
                        (root / "lib").mkdir()
                        (root / "app.js").write_text(
                            statement +
                            "function caller() { return foo(); }\n",
                            encoding="utf-8",
                        )
                        (root / "lib" / "util.js").write_text(
                            "export function foo() {}\n",
                            encoding="utf-8",
                        )
                        (root / "other.js").write_text(
                            "export function foo() {}\n"
                            "export function bar() {}\n",
                            encoding="utf-8",
                        )

                        cfg = load_config(root=str(root))
                        cfg.engine = engine
                        build_index(cfg, quiet=True)
                        store = IndexStore(str(cfg.db_path))
                        try:
                            app_id = store.file_by_path("app.js")["id"]
                            call = store.find_call(
                                callee="foo", file_id=app_id
                            )
                            self.assertIsNotNone(call["callee_id"])
                            target = store.symbol_by_id(call["callee_id"])
                            self.assertEqual(
                                store.file_by_id(target["file_id"])["path"],
                                "lib/util.js",
                            )
                        finally:
                            store.close()

    def test_unaliased_typescript_import_resolves_with_duplicate_exports(self):
        for engine in ("quick", "deep", "auto"):
            with self.subTest(engine=engine):
                with tempfile.TemporaryDirectory() as tmp:
                    root = Path(tmp)
                    (root / "app.ts").write_text(
                        "import { foo } from './lib/util.ts';\n"
                        "import { bar } from './other.ts';\n"
                        "function caller() { return foo(); }\n",
                        encoding="utf-8",
                    )
                    (root / "lib").mkdir()
                    (root / "lib" / "util.ts").write_text(
                        "export function foo() {}\n", encoding="utf-8")
                    (root / "other.ts").write_text(
                        "export function foo() {}\n"
                        "export function bar() {}\n",
                        encoding="utf-8",
                    )

                    cfg = load_config(root=str(root))
                    cfg.engine = engine
                    build_index(cfg, quiet=True)
                    store = IndexStore(str(cfg.db_path))
                    try:
                        app_id = store.file_by_path("app.ts")["id"]
                        call = store.find_call(callee="foo", file_id=app_id)
                        self.assertIsNotNone(call["callee_id"])
                        target = store.symbol_by_id(call["callee_id"])
                        self.assertEqual(
                            store.file_by_id(target["file_id"])["path"],
                            "lib/util.ts",
                        )
                    finally:
                        store.close()

    def test_javascript_namespace_import_resolves_own_module_exports(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "one").mkdir()
            (root / "two").mkdir()
            (root / "app.js").write_text(
                'import * as ns from "./one/index.js";\n'
                'import { foo as namedFoo } from "./two/index.js";\n'
                "function foo() { return 3; }\n"
                "function caller() { ns.foo(); namedFoo(); }\n",
                encoding="utf-8",
            )
            (root / "one/index.js").write_text(
                "export function foo() { return 1; }\n", encoding="utf-8")
            (root / "two/index.js").write_text(
                "export function foo() { return 2; }\n", encoding="utf-8")

            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            build_index(cfg)
            store = IndexStore(str(cfg.db_path))
            try:
                file_id = store.file_by_path("app.js")["id"]
                rows = {
                    row["callee"]: row["callee_id"]
                    for row in store.conn.execute(
                        "SELECT callee, callee_id FROM calls WHERE file_id = ?",
                        (file_id,),
                    )
                }
                namespace_target = store.symbol_by_id(rows["ns.foo"])
                named_target = store.symbol_by_id(rows["namedFoo"])
                self.assertEqual(
                    store.file_by_id(namespace_target["file_id"])["path"],
                    "one/index.js",
                )
                self.assertEqual(
                    store.file_by_id(named_target["file_id"])["path"],
                    "two/index.js",
                )
            finally:
                store.close()

    def test_typescript_namespace_import_beats_local_name(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "one").mkdir()
            (root / "app.ts").write_text(
                'import * as ns from "./one/index.ts";\n'
                "function foo() { return 3; }\n"
                "function caller() { ns.foo(); }\n",
                encoding="utf-8",
            )
            (root / "one/index.ts").write_text(
                "export function foo() { return 1; }\n", encoding="utf-8")

            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            build_index(cfg)
            store = IndexStore(str(cfg.db_path))
            try:
                file_id = store.file_by_path("app.ts")["id"]
                target_id = resolve_callee(store, file_id, "ns.foo")
                self.assertIsNotNone(target_id)
                target = store.symbol_by_id(target_id)
                self.assertEqual(
                    store.file_by_id(target["file_id"])["path"], "one/index.ts"
                )
            finally:
                store.close()

    def test_aliased_class_member_calls_resolve_with_duplicate_members(self):
        cases = (
            {
                "lang": "python",
                "importer": "app.py",
                "target": "pkg/mod.py",
                "other": "pkg/other.py",
                "statement": "from pkg.mod import Thing as T\n",
                "target_source": (
                    "class Thing:\n    def run(self): pass\n"
                    "class Other:\n    def run(self): pass\n"
                ),
                "other_source": "class OtherThing:\n    def run(self): pass\n",
                "app_body": "def caller():\n    T.run()\n",
                "call": "T.run",
                "expected": "pkg.mod.Thing.run",
            },
            {
                "lang": "javascript",
                "importer": "app.js",
                "target": "util.js",
                "other": "other.js",
                "statement": "import { Thing as T } from './util.js';\n",
                "target_source": (
                    "export class Thing {\n  static run() {}\n}\n"
                    "export class Other {\n  static run() {}\n}\n"
                ),
                "other_source": "export class OtherThing { static run() {} }\n",
                "app_body": "function caller() { T.run(); }\n",
                "call": "T.run",
                "expected": "util.Thing.run",
            },
        )
        for case in cases:
            for engine in ("quick", "deep", "auto"):
                with self.subTest(lang=case["lang"], engine=engine):
                    with tempfile.TemporaryDirectory() as tmp:
                        root = Path(tmp)
                        if case["lang"] == "python":
                            (root / "pkg").mkdir()
                            (root / "pkg" / "__init__.py").write_text(
                                "", encoding="utf-8")
                        (root / case["importer"]).write_text(
                            case["statement"] + case["app_body"],
                            encoding="utf-8",
                        )
                        target = root / case["target"]
                        target.parent.mkdir(parents=True, exist_ok=True)
                        target.write_text(case["target_source"], encoding="utf-8")
                        (root / case["other"]).write_text(
                            case["other_source"], encoding="utf-8")

                        cfg = load_config(root=str(root))
                        cfg.engine = engine
                        build_index(cfg)
                        store = IndexStore(str(cfg.db_path))
                        try:
                            app_id = store.file_by_path(case["importer"])["id"]
                            target_id = resolve_callee(
                                store, app_id, case["call"]
                            )
                            self.assertIsNotNone(target_id)
                            self.assertEqual(
                                store.symbol_by_id(target_id)["qualname"],
                                case["expected"],
                            )
                        finally:
                            store.close()

    def test_javascript_default_import_resolves_default_symbol(self):
        for engine in ("quick", "deep", "auto"):
            with tempfile.TemporaryDirectory() as tmp:
                root = Path(tmp)
                (root / "app.js").write_text(
                    "import foo from './util.js';\n"
                    "function caller() { return foo(); }\n",
                    encoding="utf-8",
                )
                (root / "util.js").write_text(
                    "export default function source() { return 1; }\n"
                    "export function named() { return 3; }\n",
                    encoding="utf-8",
                )
                (root / "other.js").write_text(
                    "export function foo() { return 2; }\n", encoding="utf-8")

                cfg = load_config(root=str(root))
                cfg.engine = engine
                build_index(cfg)
                store = IndexStore(str(cfg.db_path))
                try:
                    app_id = store.file_by_path("app.js")["id"]
                    import_row = store.imports_for_file(app_id)[0]
                    self.assertEqual(import_row["names"], '["default as foo"]')
                    target_id = resolve_callee(store, app_id, "foo")
                    self.assertIsNotNone(target_id)
                    self.assertEqual(
                        store.symbol_by_id(target_id)["qualname"], "util.source"
                    )
                    exports = {
                        row["name"]: row["default_export"]
                        for row in store.conn.execute(
                            "SELECT name, default_export FROM symbols "
                            "WHERE file_id = ?",
                            (import_row["target_id"],),
                        )
                    }
                    self.assertEqual(exports, {"source": 1, "named": 0})
                finally:
                    store.close()

    def test_javascript_default_class_import_ignores_member_exports(self):
        for engine in ("quick", "deep", "auto"):
            with self.subTest(engine=engine), tempfile.TemporaryDirectory() as tmp:
                root = Path(tmp)
                (root / "app.js").write_text(
                    "import Widget from './widget.js';\n"
                    "function caller() { return Widget.create(); }\n",
                    encoding="utf-8",
                )
                (root / "widget.js").write_text(
                    "export default class Widget {\n"
                    "  static create() { return 1; }\n"
                    "}\n",
                    encoding="utf-8",
                )

                cfg = load_config(root=str(root))
                cfg.engine = engine
                build_index(cfg)
                store = IndexStore(str(cfg.db_path))
                try:
                    app_id = store.file_by_path("app.js")["id"]
                    target_id = resolve_callee(store, app_id, "Widget.create")
                    self.assertIsNotNone(target_id)
                    self.assertEqual(
                        store.symbol_by_id(target_id)["qualname"],
                        "widget.Widget.create",
                    )
                    exported = store.conn.execute(
                        "SELECT name FROM symbols WHERE default_export = 1 "
                        "AND file_id = (SELECT id FROM files WHERE path = ?)",
                        ("widget.js",),
                    ).fetchall()
                    self.assertEqual([row["name"] for row in exported], ["Widget"])
                finally:
                    store.close()

    def test_commonjs_property_alias_resolves_exported_function(self):
        for engine in ("quick", "deep", "auto"):
            with tempfile.TemporaryDirectory() as tmp:
                root = Path(tmp)
                (root / "app.js").write_text(
                    "const bar = require('./util.js').foo;\n"
                    "function caller() { return bar(); }\n",
                    encoding="utf-8",
                )
                (root / "util.js").write_text(
                    "export function foo() { return 1; }\n"
                    "export function extra() { return 3; }\n",
                    encoding="utf-8",
                )
                (root / "other.js").write_text(
                    "export function bar() { return 2; }\n", encoding="utf-8")

                cfg = load_config(root=str(root))
                cfg.engine = engine
                build_index(cfg)
                store = IndexStore(str(cfg.db_path))
                try:
                    app_id = store.file_by_path("app.js")["id"]
                    import_row = store.imports_for_file(app_id)[0]
                    self.assertEqual(import_row["names"], '["foo as bar"]')
                    target_id = resolve_callee(store, app_id, "bar")
                    self.assertIsNotNone(target_id)
                    self.assertEqual(
                        store.symbol_by_id(target_id)["qualname"], "util.foo"
                    )
                finally:
                    store.close()

    def test_typescript_runtime_specifiers_prefer_source_extensions(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            cases = (
                ("app.ts", "./util.js", "util.ts"),
                ("app.mts", "./util.mjs", "util.mts"),
                ("app.cts", "./util.cjs", "util.cts"),
                ("app.js", "./util.js", "util.js"),
            )
            for importer, specifier, _ in cases:
                (root / importer).write_text(
                    f'import "{specifier}";\n', encoding="utf-8")
            for suffix in (".ts", ".js", ".mts", ".mjs", ".cts", ".cjs"):
                (root / f"util{suffix}").write_text(
                    "export const value = true;\n", encoding="utf-8")

            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            build_index(cfg)
            store = IndexStore(str(cfg.db_path))
            try:
                for importer, specifier, expected in cases:
                    with self.subTest(importer=importer):
                        file_id = store.file_by_path(importer)["id"]
                        target_id = store.file_by_path(expected)["id"]
                        self.assertEqual(
                            resolve_module(store, file_id, specifier), target_id
                        )
            finally:
                store.close()

    def test_js_require_with_different_extension(self):
        # app.js requires "./util.js" but the file on disk is util.ts
        fid = self._callee("web/app.js", "fmt")
        self.assertIsNotNone(fid)
        self.assertEqual(self.store.symbol_by_id(fid).qualname, "web/util.fmt")

    def test_js_relative_import_does_not_resolve_python_file(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "app.js").write_text(
                'const { target } = require("./util");\n'
                "target();\n",
                encoding="utf-8",
            )
            (root / "util.py").write_text(
                "def target():\n    return 1\n", encoding="utf-8")

            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            build_index(cfg)
            store = IndexStore(str(cfg.db_path))
            try:
                fid = store.file_by_path("app.js")["id"]
                self.assertIsNone(resolve_module(store, fid, "./util"))
            finally:
                store.close()

    def test_non_python_relative_import_does_not_add_root_module(self):
        """A JS/TS relative path must not be treated as a Python package id."""
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "app.ts").write_text(
                'import { helper } from "./util";\n\n'
                "export function caller() {\n"
                "  return target();\n"
                "}\n",
                encoding="utf-8",
            )
            (root / "util.ts").write_text(
                "export function helper() { return 1; }\n", encoding="utf-8")
            # The Python-style adjustment incorrectly treats this as the
            # imported module, making its unrelated target() visible to app.ts.
            (root / "helper.ts").write_text(
                "export function target() { return 2; }\n", encoding="utf-8")
            (root / "other.ts").write_text(
                "export function target() { return 3; }\n", encoding="utf-8")

            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            build_index(cfg)
            store = IndexStore(str(cfg.db_path))
            try:
                fid = store.file_by_path("app.ts")["id"]
                self.assertIsNone(resolve_callee(store, fid, "target"))
            finally:
                store.close()

    def test_go_imported_function(self):
        main_id = self._file_id("main.go")
        imports = {
            imp["module"]: imp for imp in self.store.imports_for_file(main_id)
        }
        self.assertIn("proj/helper", imports)
        import_target_id = imports["proj/helper"]["target_id"]
        self.assertIsNotNone(import_target_id)
        self.assertEqual(
            self.store.file_by_id(import_target_id)["path"],
            "helper/helper.go",
        )

        gid = resolve_callee(self.store, main_id, "helper.Greet")
        self.assertIsNotNone(gid)
        target = self.store.symbol_by_id(gid)
        self.assertEqual(target.qualname, "helper.Greet")
        self.assertEqual(
            self.store.file_by_id(target.file_id)["path"],
            "helper/helper.go",
        )

    def test_go_same_package_resolution_is_directory_scoped(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "go.mod").write_text(
                "module example.com/acme\n\ngo 1.22\n", encoding="utf-8")
            for package_dir in ("a", "b"):
                (root / package_dir).mkdir()
                (root / package_dir / "target.go").write_text(
                    "package client\nfunc Target() {}\n", encoding="utf-8")
            (root / "a" / "caller.go").write_text(
                "package client\nfunc caller() { Target() }\n", encoding="utf-8")

            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            build_index(cfg)
            store = IndexStore(str(cfg.db_path))
            try:
                caller_id = store.file_by_path("a/caller.go")["id"]
                target_id = resolve_callee(store, caller_id, "Target")

                self.assertIsNotNone(target_id)
                target = store.symbol_by_id(target_id)
                self.assertEqual(
                    store.file_by_id(target["file_id"])["path"],
                    "a/target.go",
                )
            finally:
                store.close()

    def test_go_aliased_import_resolves_call_with_duplicate_name(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "go.mod").write_text(
                "module example.com/acme\n\ngo 1.22\n", encoding="utf-8")
            for package in ("helper", "other"):
                (root / package).mkdir()
                (root / package / f"{package}.go").write_text(
                    f"package {package}\nfunc Greet() {{}}\n", encoding="utf-8")
            (root / "main.go").write_text(
                "package main\n"
                "import (\n"
                '    h "example.com/acme/helper"\n'
                '    o "example.com/acme/other"\n'
                ")\n"
                "func Greet() {}\n"
                "func main() { h.Greet(); o.Greet() }\n",
                encoding="utf-8",
            )

            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            build_index(cfg)
            store = IndexStore(str(cfg.db_path))
            try:
                main_id = store.file_by_path("main.go")["id"]
                call_targets = {
                    row["callee"]: row["callee_id"]
                    for row in store.conn.execute(
                        "SELECT callee, callee_id FROM calls WHERE file_id = ?",
                        (main_id,),
                    )
                }
                for callee, expected_path in (
                    ("h.Greet", "helper/helper.go"),
                    ("o.Greet", "other/other.go"),
                ):
                    target_id = resolve_callee(store, main_id, callee)
                    self.assertIsNotNone(target_id)
                    self.assertEqual(call_targets[callee], target_id)
                    target = store.symbol_by_id(target_id)
                    self.assertEqual(target["name"], "Greet")
                    self.assertEqual(
                        store.file_by_id(target["file_id"])["path"],
                        expected_path,
                    )
            finally:
                store.close()

    def test_go_external_test_package_does_not_shadow_imported_symbol(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "go.mod").write_text(
                "module example.com/acme\n\ngo 1.22\n", encoding="utf-8")
            (root / "helper").mkdir()
            (root / "helper/helper.go").write_text(
                "package helper\nfunc Fetch() {}\n", encoding="utf-8")
            (root / "helper/helper_test.go").write_text(
                "package helper_test\nfunc Fetch() {}\n", encoding="utf-8")
            (root / "main.go").write_text(
                "package main\n"
                'import h "example.com/acme/helper"\n'
                "func caller() { h.Fetch() }\n",
                encoding="utf-8",
            )

            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            build_index(cfg)
            store = IndexStore(str(cfg.db_path))
            try:
                main_id = store.file_by_path("main.go")["id"]
                target_id = resolve_callee(store, main_id, "h.Fetch")

                self.assertIsNotNone(target_id)
                target = store.symbol_by_id(target_id)
                self.assertEqual(target["name"], "Fetch")
                self.assertEqual(
                    store.file_by_id(target["file_id"])["path"],
                    "helper/helper.go",
                )
            finally:
                store.close()

    def test_go_import_fallback_excludes_test_files(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "go.mod").write_text(
                "module example.com/acme\n\ngo 1.22\n", encoding="utf-8")
            package_dir = root / "helper"
            package_dir.mkdir()
            (package_dir / "a_test.go").write_text(
                "package helper_test\nfunc Fetch() {}\n", encoding="utf-8")
            (package_dir / "z.go").write_text(
                "package helper\nfunc Fetch() {}\n", encoding="utf-8")
            (root / "main.go").write_text(
                "package main\n"
                'import h "example.com/acme/helper"\n'
                "func caller() { h.Fetch() }\n",
                encoding="utf-8",
            )

            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            build_index(cfg)
            store = IndexStore(str(cfg.db_path))
            try:
                main_id = store.file_by_path("main.go")["id"]
                test_file = store.file_by_path("helper/a_test.go")
                self.assertIsNotNone(test_file)
                self.assertTrue(store.conn.execute(
                    "SELECT 1 FROM symbols WHERE file_id = ? AND name = ?",
                    (test_file["id"], "Fetch"),
                ).fetchone())

                imp = store.imports_for_file(main_id)[0]
                self.assertEqual(
                    store.file_by_id(imp["target_id"])["path"],
                    "helper/z.go",
                )
                target_id = resolve_callee(store, main_id, "h.Fetch")
                self.assertIsNotNone(target_id)
                self.assertEqual(
                    store.file_by_id(store.symbol_by_id(target_id).file_id)["path"],
                    "helper/z.go",
                )
                edge = store.conn.execute(
                    "SELECT callee_id FROM calls WHERE file_id = ? AND callee = ?",
                    (main_id, "h.Fetch"),
                ).fetchone()
                self.assertEqual(edge["callee_id"], target_id)
            finally:
                store.close()

    def test_go_raw_string_alias_resolves_imported_call(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "go.mod").write_text(
                "module example.com/acme\n\ngo 1.22\n", encoding="utf-8")
            (root / "helper").mkdir()
            (root / "helper/helper.go").write_text(
                "package helper\nfunc Greet() {}\n", encoding="utf-8")
            (root / "main.go").write_text(
                "package main\n"
                'import h `example.com/acme/helper`\n'
                "func caller() { h.Greet() }\n",
                encoding="utf-8",
            )

            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            build_index(cfg)
            store = IndexStore(str(cfg.db_path))
            try:
                main_id = store.file_by_path("main.go")["id"]
                imports = store.imports_for_file(main_id)
                self.assertEqual(imports[0]["module"], "example.com/acme/helper")
                target_id = resolve_callee(store, main_id, "h.Greet")
                self.assertIsNotNone(target_id)
                target = store.symbol_by_id(target_id)
                self.assertEqual(target["qualname"], "helper.Greet")
                edge = store.conn.execute(
                    "SELECT callee_id FROM calls WHERE file_id = ? AND callee = ?",
                    (main_id, "h.Greet"),
                ).fetchone()
                self.assertEqual(edge["callee_id"], target_id)
            finally:
                store.close()

    def test_go_alias_resolves_large_package_under_sqlite_variable_limit(self):
        if not hasattr(sqlite3.Connection, "setlimit"):
            self.skipTest("sqlite3.Connection.setlimit is unavailable")
        limit_id = getattr(sqlite3, "SQLITE_LIMIT_VARIABLE_NUMBER", None)
        if limit_id is None:
            self.skipTest("SQLite variable limit constant is unavailable")

        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "go.mod").write_text(
                "module example.com/acme\n\ngo 1.22\n", encoding="utf-8")
            helper = root / "helper"
            helper.mkdir()
            for index in range(999):
                content = "package helper\n"
                if index == 0:
                    content += "func Greet() {}\n"
                (helper / f"file{index:03}.go").write_text(
                    content, encoding="utf-8")
            (root / "main.go").write_text(
                "package main\n"
                'import h "example.com/acme/helper"\n'
                "func caller() { h.Greet() }\n",
                encoding="utf-8",
            )

            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            build_index(cfg)
            store = IndexStore(str(cfg.db_path))
            try:
                main_id = store.file_by_path("main.go")["id"]
                previous_limit = store.conn.setlimit(limit_id, 999)
                try:
                    target_id = resolve_callee(store, main_id, "h.Greet")
                finally:
                    store.conn.setlimit(limit_id, previous_limit)
                self.assertIsNotNone(target_id)
                target = store.symbol_by_id(target_id)
                self.assertEqual(target["name"], "Greet")
                self.assertEqual(
                    store.file_by_id(target["file_id"])["path"],
                    "helper/file000.go",
                )
            finally:
                store.close()

    def test_go_blank_import_does_not_shadow_same_package_method(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "go.mod").write_text(
                "module example.com/acme\n\ngo 1.22\n", encoding="utf-8")
            (root / "helper").mkdir()
            (root / "helper/helper.go").write_text(
                "package helper\nfunc Greet() {}\n", encoding="utf-8")
            (root / "widget.go").write_text(
                "package main\n"
                "type widget struct{}\n"
                "func (w widget) Greet() {}\n",
                encoding="utf-8",
            )
            (root / "main.go").write_text(
                'package main\nimport _ "example.com/acme/helper"\n'
                "func caller(w widget) { w.Greet() }\n",
                encoding="utf-8",
            )

            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            build_index(cfg)
            store = IndexStore(str(cfg.db_path))
            try:
                main_id = store.file_by_path("main.go")["id"]
                target_id = resolve_callee(store, main_id, "w.Greet")
                self.assertIsNotNone(target_id)
                target = store.symbol_by_id(target_id)
                self.assertEqual(
                    store.file_by_id(target["file_id"])["path"], "widget.go"
                )
                edge = store.conn.execute(
                    "SELECT callee_id FROM calls WHERE file_id = ? AND callee = ?",
                    (main_id, "w.Greet"),
                ).fetchone()
                self.assertEqual(edge["callee_id"], target_id)
            finally:
                store.close()

    def test_go_blank_import_does_not_expose_unqualified_symbols(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "go.mod").write_text(
                "module example.com/acme\n\ngo 1.22\n", encoding="utf-8")
            (root / "helper").mkdir()
            (root / "helper/helper.go").write_text(
                "package helper\nfunc Greet() {}\n", encoding="utf-8")
            (root / "main.go").write_text(
                'package main\nimport _ "example.com/acme/helper"\n'
                "func caller() { Greet() }\n",
                encoding="utf-8",
            )

            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            build_index(cfg)
            store = IndexStore(str(cfg.db_path))
            try:
                main_id = store.file_by_path("main.go")["id"]
                self.assertIsNone(resolve_callee(store, main_id, "Greet"))
                edge = store.conn.execute(
                    "SELECT callee_id FROM calls WHERE file_id = ? AND callee = ?",
                    (main_id, "Greet"),
                ).fetchone()
                self.assertIsNone(edge["callee_id"])
            finally:
                store.close()

    def test_go_dot_import_still_exposes_unqualified_symbols(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "go.mod").write_text(
                "module example.com/acme\n\ngo 1.22\n", encoding="utf-8")
            (root / "helper").mkdir()
            (root / "helper/helper.go").write_text(
                "package helper\nfunc Greet() {}\n", encoding="utf-8")
            (root / "main.go").write_text(
                'package main\nimport . "example.com/acme/helper"\n'
                "func caller() { Greet() }\n",
                encoding="utf-8",
            )

            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            build_index(cfg)
            store = IndexStore(str(cfg.db_path))
            try:
                main_id = store.file_by_path("main.go")["id"]
                target_id = resolve_callee(store, main_id, "Greet")
                self.assertIsNotNone(target_id)
                target = store.symbol_by_id(target_id)
                self.assertEqual(
                    store.file_by_id(target["file_id"])["path"],
                    "helper/helper.go",
                )
                edge = store.conn.execute(
                    "SELECT callee_id FROM calls WHERE file_id = ? AND callee = ?",
                    (main_id, "Greet"),
                ).fetchone()
                self.assertEqual(edge["callee_id"], target_id)
            finally:
                store.close()

    def test_go_import_resolves_arbitrarily_named_package_files(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "go.mod").write_text(
                "module example.com/acme\n\ngo 1.22\n", encoding="utf-8",
            )
            package_dir = root / "internal" / "math"
            package_dir.mkdir(parents=True)
            (root / "main.go").write_text(
                'package main\n\n'
                'import "example.com/acme/internal/math"\n\n'
                'func main() { _ = math.Add(1, 2); _ = math.Area(3) }\n',
                encoding="utf-8",
            )
            (package_dir / "arithmetic.go").write_text(
                "package math\n\n"
                "func Add(a, b int) int { return a + b }\n",
                encoding="utf-8",
            )
            (package_dir / "geometry.go").write_text(
                "package math\n\n"
                "func Area(side int) int { return side * side }\n",
                encoding="utf-8",
            )

            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            build_index(cfg)
            store = IndexStore(str(cfg.db_path))
            try:
                main_id = store.file_by_path("main.go")["id"]
                imp = store.imports_for_file(main_id)[0]
                self.assertEqual(
                    store.file_by_id(imp["target_id"])["path"],
                    "internal/math/arithmetic.go",
                )
                add_id = resolve_callee(store, main_id, "math.Add")
                area_id = resolve_callee(store, main_id, "math.Area")
                self.assertIsNotNone(add_id)
                self.assertIsNotNone(area_id)
                self.assertEqual(store.symbol_by_id(add_id).qualname, "math.Add")
                self.assertEqual(store.symbol_by_id(area_id).qualname, "math.Area")
                resolved_calls = {
                    row["callee_id"] for row in store.conn.execute(
                        "SELECT callee_id FROM calls WHERE file_id = ?",
                        (main_id,),
                    )
                }
                self.assertIn(add_id, resolved_calls)
                self.assertIn(area_id, resolved_calls)
            finally:
                store.close()

    def test_go_import_path_with_dotted_domain(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            package_dir = root / "example.com" / "acme" / "internal"
            package_dir.mkdir(parents=True)
            (root / "main.go").write_text(
                'package main\n\nimport "example.com/acme/internal/math"\n',
                encoding="utf-8",
            )
            (package_dir / "math.go").write_text(
                "package math\n\nfunc Add(a, b int) int { return a + b }\n",
                encoding="utf-8",
            )

            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            build_index(cfg)
            store = IndexStore(str(cfg.db_path))
            try:
                fid = store.file_by_path("main.go")["id"]
                self.assertEqual(
                    resolve_module(store, fid, "example.com/acme/internal/math"),
                    store.file_by_path("example.com/acme/internal/math.go")["id"],
                )
            finally:
                store.close()

    def test_go_import_path_with_dotted_final_segment(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            package_dir = root / "example.com" / "acme"
            package_dir.mkdir(parents=True)
            (root / "main.go").write_text(
                'package main\n\nimport "example.com/acme/foo.bar"\n',
                encoding="utf-8",
            )
            (package_dir / "foo.bar.go").write_text(
                "package foobar\n\nfunc Add(a, b int) int { return a + b }\n",
                encoding="utf-8",
            )

            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            build_index(cfg)
            store = IndexStore(str(cfg.db_path))
            try:
                fid = store.file_by_path("main.go")["id"]
                self.assertEqual(
                    resolve_module(store, fid, "example.com/acme/foo.bar"),
                    store.file_by_path("example.com/acme/foo.bar.go")["id"],
                )
            finally:
                store.close()

    def test_java_same_package_class(self):
        jid = self._callee("Runner.java", "Calc.sum")
        self.assertIsNotNone(jid)
        self.assertEqual(self.store.symbol_by_id(jid).qualname, "com.demo.Calc.sum")

    def test_java_imported_class_member_resolves_with_duplicate_methods(self):
        for engine in ("quick", "deep", "auto"):
            with self.subTest(engine=engine):
                with tempfile.TemporaryDirectory() as tmp:
                    root = Path(tmp)
                    (root / "a").mkdir()
                    (root / "b").mkdir()
                    (root / "app").mkdir()
                    (root / "a" / "Foo.java").write_text(
                        "package a;\npublic class Foo {\n"
                        "  public static void run() {}\n}\n",
                        encoding="utf-8",
                    )
                    (root / "b" / "Bar.java").write_text(
                        "package b;\npublic class Bar {\n"
                        "  public static void run() {}\n}\n",
                        encoding="utf-8",
                    )
                    (root / "app" / "Runner.java").write_text(
                        "package app;\nimport a.Foo;\nimport b.Bar;\n"
                        "public class Runner {\n"
                        "  public void caller() { Foo.run(); }\n}\n",
                        encoding="utf-8",
                    )

                    cfg = load_config(root=str(root))
                    cfg.engine = engine
                    build_index(cfg, quiet=True)
                    store = IndexStore(str(cfg.db_path))
                    try:
                        file_id = store.file_by_path("app/Runner.java")["id"]
                        call = store.find_call(
                            callee="Foo.run", file_id=file_id
                        )
                        self.assertIsNotNone(call)
                        self.assertIsNotNone(call["callee_id"])
                        target = store.symbol_by_id(call["callee_id"])
                        self.assertEqual(target["qualname"], "a.Foo.run")
                    finally:
                        store.close()

    def test_java_imports_resolve_from_source_roots(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            source_root = root / "src" / "main" / "java"
            package_dir = source_root / "com" / "example" / "util"
            app_dir = source_root / "com" / "example" / "app"
            package_dir.mkdir(parents=True)
            app_dir.mkdir(parents=True)
            (package_dir / "Util.java").write_text(
                "package com.example.util;\n"
                "public class Util {\n"
                "  public static int compute() { return 1; }\n"
                "}\n",
                encoding="utf-8",
            )
            (package_dir / "Helper.java").write_text(
                "package com.example.util;\n"
                "public class Helper {\n"
                "  public static int greet() { return 2; }\n"
                "}\n",
                encoding="utf-8",
            )
            (app_dir / "Runner.java").write_text(
                "package com.example.app;\n"
                "import com.example.util.*;\n"
                "import static com.example.util.Helper.greet;\n"
                "public class Runner {\n"
                "  public int viaWildcard() { return Util.compute() + Helper.greet(); }\n"
                "  public int viaStaticImport() { return compute(); }\n"
                "}\n",
                encoding="utf-8",
            )

            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            build_index(cfg)
            store = IndexStore(str(cfg.db_path))
            try:
                runner_id = store.file_by_path(
                    "src/main/java/com/example/app/Runner.java"
                )["id"]
                wildcard_target = resolve_module(
                    store, runner_id, "com.example.util.*"
                )
                static_target = resolve_module(
                    store, runner_id, "com.example.util.Helper.greet"
                )
                self.assertEqual(
                    store.file_by_id(wildcard_target)["module"],
                    "com.example.util",
                )
                self.assertEqual(
                    store.file_by_id(static_target)["path"],
                    "src/main/java/com/example/util/Helper.java",
                )
                compute_id = resolve_callee(store, runner_id, "compute")
                util_compute_id = resolve_callee(
                    store, runner_id, "Util.compute"
                )
                greet_id = resolve_callee(store, runner_id, "greet")
                self.assertIsNotNone(compute_id)
                self.assertIsNotNone(util_compute_id)
                self.assertIsNotNone(greet_id)
                self.assertEqual(
                    store.symbol_by_id(compute_id).qualname,
                    "com.example.util.Util.compute",
                )
                self.assertEqual(
                    store.symbol_by_id(greet_id).qualname,
                    "com.example.util.Helper.greet",
                )
                resolved_calls = {
                    row["callee_id"] for row in store.conn.execute(
                        "SELECT callee_id FROM calls WHERE file_id = ?",
                        (runner_id,),
                    )
                }
                self.assertIn(compute_id, resolved_calls)
                self.assertIn(greet_id, resolved_calls)
            finally:
                store.close()

    def test_rust_inline_module_call_edge_is_persisted(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "lib.rs").write_text(
                "mod util {\n"
                "    pub fn helper() { dependency(); }\n"
                "}\n"
                "fn caller() { util::helper(); }\n",
                encoding="utf-8",
            )
            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            build_index(cfg)
            store = IndexStore(str(cfg.db_path))
            try:
                helper = store.symbol_by_qualname("lib.util.helper")
                self.assertIsNotNone(helper)
                file_id = store.file_by_path("lib.rs")["id"]
                edge = store.conn.execute(
                    "SELECT callee_id FROM calls WHERE file_id = ? "
                    "AND callee = ?",
                    (file_id, "util::helper"),
                ).fetchone()
                self.assertIsNotNone(edge)
                self.assertEqual(edge["callee_id"], helper["id"])
            finally:
                store.close()

    def test_rust_qualified_inline_call_resolves_with_duplicate_names(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "lib.rs").write_text(
                "mod util { pub fn helper() {} }\n"
                "fn helper() {}\n"
                "fn caller() { util::helper(); }\n",
                encoding="utf-8",
            )
            (root / "other.rs").write_text(
                "fn helper() {}\n", encoding="utf-8")

            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            build_index(cfg)
            store = IndexStore(str(cfg.db_path))
            try:
                helper = store.symbol_by_qualname("lib.util.helper")
                self.assertIsNotNone(helper)
                file_id = store.file_by_path("lib.rs")["id"]
                self.assertEqual(
                    resolve_callee(store, file_id, "util::helper"),
                    helper["id"],
                )
                edge = store.conn.execute(
                    "SELECT callee_id FROM calls WHERE file_id = ? "
                    "AND callee = ?",
                    (file_id, "util::helper"),
                ).fetchone()
                self.assertIsNotNone(edge)
                self.assertEqual(edge["callee_id"], helper["id"])
            finally:
                store.close()

    def test_rust_nested_inline_call_uses_caller_module_scope(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "lib.rs").write_text(
                "mod outer {\n"
                "    mod util { pub fn helper() {} }\n"
                "    fn helper() {}\n"
                "    fn caller() { util::helper(); }\n"
                "}\n"
                "fn helper() {}\n",
                encoding="utf-8",
            )
            (root / "other.rs").write_text(
                "fn helper() {}\n", encoding="utf-8")

            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            build_index(cfg)
            store = IndexStore(str(cfg.db_path))
            try:
                helper = store.symbol_by_qualname("lib.outer.util.helper")
                self.assertIsNotNone(helper)
                file_id = store.file_by_path("lib.rs")["id"]
                edge = store.conn.execute(
                    "SELECT callee_id FROM calls WHERE file_id = ? "
                    "AND callee = ?",
                    (file_id, "util::helper"),
                ).fetchone()
                self.assertIsNotNone(edge)
                self.assertEqual(edge["callee_id"], helper["id"])
            finally:
                store.close()

    def test_rust_inline_method_call_uses_enclosing_module_scope(self):
        for engine in ("quick", "deep", "auto"):
            with self.subTest(engine=engine):
                with tempfile.TemporaryDirectory() as tmp:
                    root = Path(tmp)
                    (root / "lib.rs").write_text(
                        "mod util { pub fn helper() {} }\n"
                        "struct S;\n"
                        "impl S {\n"
                        "    fn caller() {\n"
                        "        util::helper();\n"
                        "    }\n"
                        "}\n"
                        "fn helper() {}\n",
                        encoding="utf-8",
                    )

                    cfg = load_config(root=str(root))
                    cfg.engine = engine
                    build_index(cfg, quiet=True)
                    store = IndexStore(str(cfg.db_path))
                    try:
                        file_id = store.file_by_path("lib.rs")["id"]
                        target = store.symbol_by_qualname("lib.util.helper")
                        call = store.find_call(
                            callee="util::helper", file_id=file_id
                        )
                        self.assertIsNotNone(call)
                        self.assertEqual(call["callee_id"], target["id"])
                    finally:
                        store.close()


    def test_rust_explicit_inline_module_paths_resolve_with_duplicates(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "lib.rs").write_text(
                "mod util { pub fn helper() {} }\n"
                "mod outer {\n"
                "    mod nested { pub fn helper() {} }\n"
                "    fn helper() {}\n"
                "    fn self_caller() { self::nested::helper(); }\n"
                "    fn crate_caller() { crate::outer::nested::helper(); }\n"
                "    fn super_caller() { super::util::helper(); }\n"
                "}\n"
                "fn helper() {}\n",
                encoding="utf-8",
            )
            (root / "other.rs").write_text(
                "fn helper() {}\n", encoding="utf-8")

            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            build_index(cfg)
            store = IndexStore(str(cfg.db_path))
            try:
                nested = store.symbol_by_qualname("lib.outer.nested.helper")
                root_util = store.symbol_by_qualname("lib.util.helper")
                self.assertIsNotNone(nested)
                self.assertIsNotNone(root_util)
                file_id = store.file_by_path("lib.rs")["id"]
                rows = {
                    row["callee"]: row["callee_id"]
                    for row in store.conn.execute(
                        "SELECT callee, callee_id FROM calls WHERE file_id = ?",
                        (file_id,),
                    )
                }
                self.assertEqual(rows["self::nested::helper"], nested["id"])
                self.assertEqual(rows["crate::outer::nested::helper"], nested["id"])
                self.assertEqual(rows["super::util::helper"], root_util["id"])
            finally:
                store.close()

    def test_rust_crate_qualified_call_resolves_file_module_with_duplicates(self):
        for engine in ("quick", "deep", "auto"):
            with self.subTest(engine=engine):
                with tempfile.TemporaryDirectory() as tmp:
                    root = Path(tmp)
                    src = root / "src"
                    src.mkdir()
                    (src / "lib.rs").write_text(
                        "mod a;\nmod b;\n"
                        "fn caller() { crate::a::helper(); }\n",
                        encoding="utf-8",
                    )
                    (src / "a.rs").write_text(
                        "pub fn helper() {}\n", encoding="utf-8")
                    (src / "b.rs").write_text(
                        "pub fn helper() {}\n", encoding="utf-8")

                    cfg = load_config(root=str(root))
                    cfg.engine = engine
                    build_index(cfg, quiet=True)
                    store = IndexStore(str(cfg.db_path))
                    try:
                        file_id = store.file_by_path("src/lib.rs")["id"]
                        call = store.find_call(
                            callee="crate::a::helper", file_id=file_id
                        )
                        self.assertIsNotNone(call)
                        self.assertIsNotNone(call["callee_id"])
                        target = store.symbol_by_id(call["callee_id"])
                        self.assertEqual(
                            store.file_by_id(target["file_id"])["path"],
                            "src/a.rs",
                        )
                    finally:
                        store.close()

    def test_rust_single_line_inline_module_resolves_all_functions(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "lib.rs").write_text(
                "mod util { pub fn one() {} pub fn two() { one(); } }\n"
                "fn caller() { util::two(); }\n",
                encoding="utf-8",
            )

            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            build_index(cfg)
            store = IndexStore(str(cfg.db_path))
            try:
                one = store.symbol_by_qualname("lib.util.one")
                two = store.symbol_by_qualname("lib.util.two")
                self.assertIsNotNone(one)
                self.assertIsNotNone(two)
                file_id = store.file_by_path("lib.rs")["id"]
                edges = {
                    (store.symbol_by_id(row["caller_id"])["qualname"],
                     row["callee"], row["callee_id"])
                    for row in store.conn.execute(
                        "SELECT caller_id, callee, callee_id FROM calls "
                        "WHERE file_id = ?",
                        (file_id,),
                    )
                }
                self.assertIn(("lib.util.two", "one", one["id"]), edges)
                self.assertIn(("lib.caller", "util::two", two["id"]), edges)
            finally:
                store.close()

    def test_rust_inline_module_resolves_trailing_same_line_caller(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "lib.rs").write_text(
                "mod util { pub fn run() {} } "
                "fn caller() { util::run(); }\n",
                encoding="utf-8",
            )

            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            build_index(cfg)
            store = IndexStore(str(cfg.db_path))
            try:
                file_id = store.file_by_path("lib.rs")["id"]
                caller_id = store.symbol_by_qualname("lib.caller")["id"]
                target_id = store.symbol_by_qualname("lib.util.run")["id"]
                edge = store.find_call(callee="util::run", file_id=file_id)
                self.assertIsNotNone(edge)
                self.assertEqual(edge["caller_id"], caller_id)
                self.assertEqual(edge["callee_id"], target_id)
            finally:
                store.close()

    def test_rust_mod_and_path_calls(self):
        rid = self._callee("rustx/main.rs", "lib::dist")
        self.assertIsNotNone(rid)
        self.assertEqual(self.store.symbol_by_id(rid).qualname, "rustx/lib.dist")
        oid = self._callee("rustx/main.rs", "lib::Point::origin")
        self.assertIsNotNone(oid)
        self.assertEqual(self.store.symbol_by_id(oid).qualname, "rustx/lib.Point.origin")

    def test_rust_internal_import_paths(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            src = root / "src"
            (src / "child").mkdir(parents=True)
            (src / "lib.rs").write_text(
                "pub mod child;\n"
                "pub mod shared;\n"
                "pub use crate::shared::{shared_fn};\n"
                "pub(crate) use self::child::{child_fn};\n"
                "use crate::root_fn;\n"
                "use root_fn;\n"
                "fn root_fn() {}\n"
                "fn call() { shared_fn(); child_fn(); root_fn(); }\n",
                encoding="utf-8",
            )
            (src / "child.rs").write_text(
                "pub mod nested;\n"
                "use shared::other_fn;\n"
                "use super::shared::shared_fn;\n"
                "use self::nested::nested_fn;\n"
                "fn child_fn() { shared_fn(); other_fn(); nested_fn(); }\n",
                encoding="utf-8",
            )
            (src / "shared.rs").write_text(
                "pub fn shared_fn() {}\n"
                "pub fn other_fn() {}\n", encoding="utf-8")
            (src / "child" / "nested.rs").write_text(
                "pub fn nested_fn() {}\n", encoding="utf-8")
            (src / "main.rs").write_text(
                "pub mod main_child;\n"
                "use crate::main_fn;\n"
                "fn main_fn() {}\n"
                "fn main() { main_fn(); }\n",
                encoding="utf-8",
            )
            (src / "main_child.rs").write_text(
                "use crate::main_fn;\n"
                "fn call() { main_fn(); }\n",
                encoding="utf-8",
            )
            bin_dir = src / "bin"
            bin_dir.mkdir()
            (bin_dir / "tool.rs").write_text(
                "use crate::tool_fn;\n"
                "fn tool_fn() {}\n"
                "fn main() { tool_fn(); }\n",
                encoding="utf-8",
            )

            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            build_index(cfg)
            store = IndexStore(str(cfg.db_path))
            try:
                lib_id = store.file_by_path("src/lib.rs")["id"]
                child_id = store.file_by_path("src/child.rs")["id"]
                tool_id = store.file_by_path("src/bin/tool.rs")["id"]
                imports = {
                    (store.file_by_id(row["file_id"])["path"], row["module"]):
                    store.file_by_id(row["target_id"])["path"]
                    for row in store.conn.execute(
                        "SELECT file_id, module, target_id FROM imports "
                        "WHERE target_id IS NOT NULL"
                    )
                }
                self.assertEqual(
                    imports[("src/lib.rs", "crate::shared::shared_fn")],
                    "src/shared.rs",
                )
                self.assertEqual(
                    imports[("src/lib.rs", "self::child::child_fn")],
                    "src/child.rs",
                )
                self.assertEqual(
                    imports[("src/lib.rs", "crate::root_fn")], "src/lib.rs")
                self.assertEqual(
                    imports[("src/lib.rs", "root_fn")], "src/lib.rs")
                self.assertEqual(
                    imports[("src/child.rs", "super::shared::shared_fn")],
                    "src/shared.rs",
                )
                self.assertEqual(
                    imports[("src/child.rs", "shared::other_fn")],
                    "src/shared.rs",
                )
                self.assertEqual(
                    imports[("src/child.rs", "self::nested::nested_fn")],
                    "src/child/nested.rs",
                )
                self.assertEqual(
                    imports[("src/child.rs", "nested")],
                    "src/child/nested.rs",
                )
                self.assertEqual(
                    imports[("src/main_child.rs", "crate::main_fn")],
                    "src/main.rs",
                )
                self.assertIsNone(
                    store.find_import(
                        module="crate::tool_fn", file_id=tool_id,
                    )["target_id"]
                )

                call = resolve_callee(store, lib_id, "shared_fn")
                self.assertEqual(
                    store.symbol_by_id(call)["qualname"],
                    "src/shared.shared_fn",
                )
                call = resolve_callee(store, child_id, "nested_fn")
                self.assertEqual(
                    store.symbol_by_id(call)["qualname"],
                    "src/child/nested.nested_fn",
                )
            finally:
                store.close()

    def test_rust_nested_main_and_lib_files_are_modules(self):
        """Only the actual crate root owns crate-relative paths."""
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            src = root / "src"
            (src / "foo" / "main").mkdir(parents=True)
            (src / "bar" / "lib").mkdir(parents=True)
            (src / "lib.rs").write_text(
                "mod foo;\n"
                "mod bar;\n"
                "fn root_fn() {}\n",
                encoding="utf-8",
            )
            (src / "foo.rs").write_text("mod main;\n", encoding="utf-8")
            (src / "foo" / "main.rs").write_text(
                "mod child;\n"
                "use crate::root_fn;\n"
                "fn nested_main_fn() { root_fn(); }\n",
                encoding="utf-8",
            )
            (src / "foo" / "main" / "child.rs").write_text(
                "use crate::root_fn;\n", encoding="utf-8")
            (src / "bar.rs").write_text("mod lib;\n", encoding="utf-8")
            (src / "bar" / "lib.rs").write_text(
                "mod child;\n"
                "use crate::root_fn;\n",
                encoding="utf-8",
            )
            (src / "bar" / "lib" / "child.rs").write_text(
                "use crate::root_fn;\n", encoding="utf-8")
            legacy = root / "legacy"
            legacy.mkdir()
            (legacy / "main.rs").write_text(
                "mod lib;\nfn root_fn() {}\n", encoding="utf-8")
            (legacy / "lib.rs").write_text(
                "use crate::root_fn;\n", encoding="utf-8")
            auto_bin = src / "bin" / "auto"
            auto_bin.mkdir(parents=True)
            (auto_bin / "main.rs").write_text(
                "mod child;\n"
                "use crate::bin_fn;\n"
                "fn bin_fn() {}\n",
                encoding="utf-8",
            )
            (auto_bin / "child.rs").write_text(
                "use crate::bin_fn;\n", encoding="utf-8")

            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            build_index(cfg)
            store = IndexStore(str(cfg.db_path))
            try:
                auto_bin_id = store.file_by_path("src/bin/auto/main.rs")["id"]
                imports = {
                    (store.file_by_id(row["file_id"])["path"], row["module"]):
                    store.file_by_id(row["target_id"])["path"]
                    for row in store.conn.execute(
                        "SELECT file_id, module, target_id FROM imports "
                        "WHERE target_id IS NOT NULL"
                    )
                }
                self.assertEqual(
                    imports[("src/foo/main.rs", "child")],
                    "src/foo/main/child.rs",
                )
                self.assertEqual(
                    imports[("src/foo/main.rs", "crate::root_fn")],
                    "src/lib.rs",
                )
                self.assertEqual(
                    imports[("src/bar/lib.rs", "child")],
                    "src/bar/lib/child.rs",
                )
                self.assertEqual(
                    imports[("src/bar/lib.rs", "crate::root_fn")],
                    "src/lib.rs",
                )
                legacy_id = store.file_by_path("legacy/lib.rs")["id"]
                self.assertIsNone(
                    store.find_import(
                        module="crate::root_fn", file_id=legacy_id,
                    )["target_id"]
                )
                self.assertEqual(
                    imports[("src/bin/auto/main.rs", "child")],
                    "src/bin/auto/child.rs",
                )
                self.assertIsNone(
                    store.find_import(
                        module="crate::bin_fn", file_id=auto_bin_id,
                    )["target_id"]
                )
            finally:
                store.close()

    def test_rust_cargo_custom_roots_resolve_modules_and_items(self):
        """Cargo path overrides define roots even outside conventional names."""
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "src").mkdir(parents=True)
            (root / "src" / "bin" / "tools").mkdir(parents=True)
            (root / "examples" / "nested").mkdir(parents=True)
            (root / "Cargo.toml").write_text(
                "[package]\nname = \"demo\"\nversion = \"0.1.0\"\n"
                "autobins = false\n\n"
                "[lib]\npath = \"src/entry.rs\"\n\n"
                "[[bin]]\nname = \"tool\"\n"
                "path = \"src/bin/tools/custom.rs\"\n\n"
                "[[bin]]\nname = \"flat\"\n"
                "path = \"src/bin/flat.rs\"\n\n"
                "[[example]]\nname = \"demo-example\"\n"
                "path = \"examples/nested/demo.rs\"\n",
                encoding="utf-8",
            )
            (root / "src" / "entry.rs").write_text(
                "mod child;\n"
                "use crate::lib_fn;\n"
                "fn lib_fn() {}\n",
                encoding="utf-8",
            )
            (root / "src" / "child.rs").write_text(
                "use crate::lib_fn;\n", encoding="utf-8")
            (root / "src" / "bin" / "tools" / "custom.rs").write_text(
                "mod nested;\n"
                "use crate::bin_fn;\n"
                "fn bin_fn() {}\n",
                encoding="utf-8",
            )
            (root / "src" / "bin" / "tools" / "nested.rs").write_text(
                "use crate::bin_fn;\n", encoding="utf-8")
            (root / "src" / "bin" / "flat.rs").write_text(
                "mod child;\n", encoding="utf-8")
            (root / "src" / "bin" / "child.rs").write_text(
                "mod nested;\n", encoding="utf-8")
            (root / "src" / "bin" / "child" / "nested.rs").parent.mkdir()
            (root / "src" / "bin" / "child" / "nested.rs").write_text(
                "fn nested() {}\n", encoding="utf-8")
            (root / "src" / "main.rs").write_text(
                "mod main_child;\n"
                "use crate::unconfigured;\nfn unconfigured() {}\n",
                encoding="utf-8",
            )
            (root / "src" / "main_child.rs").write_text(
                "fn child_fn() {}\n", encoding="utf-8")
            (root / "examples" / "nested" / "demo.rs").write_text(
                "use crate::example_fn;\nfn example_fn() {}\n",
                encoding="utf-8",
            )

            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            build_index(cfg)
            store = IndexStore(str(cfg.db_path))
            try:
                imports = {
                    (store.file_by_id(row["file_id"])["path"], row["module"]):
                    store.file_by_id(row["target_id"])["path"]
                    for row in store.conn.execute(
                        "SELECT file_id, module, target_id FROM imports "
                        "WHERE target_id IS NOT NULL"
                    )
                }
                self.assertEqual(
                    imports[("src/entry.rs", "child")],
                    "src/child.rs",
                )
                self.assertEqual(
                    imports[("src/entry.rs", "crate::lib_fn")],
                    "src/entry.rs",
                )
                self.assertEqual(
                    imports[("src/bin/tools/custom.rs", "nested")],
                    "src/bin/tools/nested.rs",
                )
                self.assertEqual(
                    imports[("src/bin/tools/custom.rs", "crate::bin_fn")],
                    "src/bin/tools/custom.rs",
                )
                self.assertEqual(
                    imports[("src/bin/flat.rs", "child")],
                    "src/bin/child.rs",
                )
                self.assertEqual(
                    imports[("src/bin/child.rs", "nested")],
                    "src/bin/child/nested.rs",
                )
                self.assertIsNone(
                    store.find_import(module="crate::unconfigured")["target_id"]
                )
                main_id = store.file_by_path("src/main.rs")["id"]
                row = store.conn.execute(
                    "SELECT target_id FROM imports WHERE file_id = ? "
                    "AND module = ?", (main_id, "main_child")
                ).fetchone()
                self.assertIsNone(row["target_id"])
                example = store.find_import(module="crate::example_fn")
                self.assertEqual(
                    store.file_by_id(example["target_id"])["path"],
                    "examples/nested/demo.rs",
                )
            finally:
                store.close()

    def test_rust_no_cargo_nested_binary_files_are_not_crate_roots(self):
        """Nested binary-like files need Cargo target configuration."""
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            bin_dir = root / "src" / "bin"
            (bin_dir / "nested").mkdir(parents=True)
            (bin_dir / "tool.rs").write_text(
                "use crate::tool_fn;\nfn tool_fn() {}\n",
                encoding="utf-8",
            )
            (bin_dir / "nested" / "main.rs").write_text(
                "use crate::nested_fn;\nfn nested_fn() {}\n",
                encoding="utf-8",
            )

            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            build_index(cfg)
            store = IndexStore(str(cfg.db_path))
            try:
                for path, module in (
                        ("src/bin/tool.rs", "crate::tool_fn"),
                        ("src/bin/nested/main.rs", "crate::nested_fn")):
                    file_id = store.file_by_path(path)["id"]
                    self.assertIsNone(
                        store.find_import(
                            module=module, file_id=file_id,
                        )["target_id"]
                    )
            finally:
                store.close()

    def test_rust_cargo_fallback_reads_multiline_custom_root(self):
        """The Python 3.10 fallback handles valid multiline TOML strings."""
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            src = root / "src"
            src.mkdir()
            (root / "Cargo.toml").write_text(
                "[package]\nname = \"demo\"\nversion = \"0.1.0\"\n\n"
                "[lib]\npath = \"\"\"src/entry.rs\"\"\"\n",
                encoding="utf-8",
            )
            src.joinpath("entry.rs").write_text(
                "use crate::root_fn;\nfn root_fn() {}\n", encoding="utf-8")

            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            with patch("codegraph.resolver.tomllib", None):
                build_index(cfg)
            store = IndexStore(str(cfg.db_path))
            try:
                row = store.find_import(module="crate::root_fn")
                self.assertEqual(
                    store.file_by_id(row["target_id"])["path"],
                    "src/entry.rs",
                )
            finally:
                store.close()

    def test_rust_virtual_workspace_does_not_define_roots(self):
        """A workspace-only Cargo manifest is not a package target."""
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "src").mkdir()
            (root / "Cargo.toml").write_text(
                "[workspace]\nmembers = [\"member\"]\n",
                encoding="utf-8",
            )
            (root / "src" / "lib.rs").write_text(
                "use crate::unconfigured;\nfn unconfigured() {}\n",
                encoding="utf-8",
            )

            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            build_index(cfg)
            store = IndexStore(str(cfg.db_path))
            try:
                self.assertIsNone(
                    store.find_import(module="crate::unconfigured")["target_id"]
                )
            finally:
                store.close()

    def test_parent_workspace_only_manifest_does_not_hide_rust_root(self):
        """An unrelated ancestor workspace cannot disable source-root fallback."""
        with tempfile.TemporaryDirectory() as tmp:
            workspace = Path(tmp)
            root = workspace / "source-tree"
            src = root / "src"
            src.mkdir(parents=True)
            workspace.joinpath("Cargo.toml").write_text(
                "[workspace]\nmembers = [\"other-member\"]\n\n"
                "[workspace.package]\nedition = \"2021\"\n",
                encoding="utf-8",
            )
            src.joinpath("lib.rs").write_text(
                "use crate::root_fn;\nfn root_fn() {}\n",
                encoding="utf-8",
            )

            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            build_index(cfg)
            store = IndexStore(str(cfg.db_path))
            try:
                target = store.find_import(module="crate::root_fn")
                self.assertEqual(
                    store.file_by_id(target["target_id"])["path"],
                    "src/lib.rs",
                )
            finally:
                store.close()

    def test_parent_package_with_external_target_does_not_hide_rust_root(self):
        """An ancestor package target outside the index cannot hide its roots."""
        with tempfile.TemporaryDirectory() as tmp:
            package = Path(tmp)
            package_src = package / "src"
            package_src.mkdir()
            package.joinpath("Cargo.toml").write_text(
                "[package]\nname = \"outer\"\nversion = \"0.1.0\"\n",
                encoding="utf-8",
            )
            package_src.joinpath("lib.rs").write_text(
                "fn outer_fn() {}\n", encoding="utf-8")

            root = package / "nested-source-tree"
            src = root / "src"
            src.mkdir(parents=True)
            src.joinpath("lib.rs").write_text(
                "use crate::root_fn;\nfn root_fn() {}\n",
                encoding="utf-8",
            )

            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            build_index(cfg)
            store = IndexStore(str(cfg.db_path))
            try:
                target = store.find_import(module="crate::root_fn")
                self.assertEqual(
                    store.file_by_id(target["target_id"])["path"],
                    "src/lib.rs",
                )
            finally:
                store.close()

    def test_rust_cargo_root_changes_re_resolve_incrementally(self):
        """Changing Cargo root metadata must invalidate old import edges."""
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            src = root / "src"
            src.mkdir()
            manifest = root / "Cargo.toml"
            manifest.write_text(
                "[package]\nname = \"demo\"\nversion = \"0.1.0\"\n\n"
                "[lib]\npath = \"src/entry.rs\"\n",
                encoding="utf-8",
            )
            (src / "entry.rs").write_text(
                "use crate::root_fn;\nfn root_fn() {}\n", encoding="utf-8")

            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            build_index(cfg)
            store = IndexStore(str(cfg.db_path))
            try:
                row = store.find_import(module="crate::root_fn")
                self.assertEqual(store.file_by_id(row["target_id"])["path"],
                                 "src/entry.rs")
            finally:
                store.close()

            (src / "other.rs").write_text(
                "mod entry;\nfn root_fn() {}\n", encoding="utf-8")
            manifest.write_text(
                "[package]\nname = \"demo\"\nversion = \"0.1.0\"\n\n"
                "[lib]\npath = \"src/other.rs\"\n",
                encoding="utf-8",
            )
            build_index(cfg)
            store = IndexStore(str(cfg.db_path))
            try:
                row = store.find_import(module="crate::root_fn")
                self.assertEqual(store.file_by_id(row["target_id"])["path"],
                                 "src/other.rs")
            finally:
                store.close()

    def test_rust_path_attribute_resolves_custom_module_file(self):
        """A path attribute changes the file selected by a mod declaration."""
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            src = root / "src"
            src.mkdir()
            (root / "legacy").mkdir()
            (root / "legacy" / "main.rs").write_text(
                "fn internal_fn() {}\n", encoding="utf-8")
            (src / "parent.rs").write_text(
                "#[path = \"alt/child.rs\"] mod child;\n",
                encoding="utf-8")
            (src / "alt").mkdir()
            (src / "alt" / "child.rs").write_text(
                "use super::super::root_fn;\n", encoding="utf-8")
            (src / "lib.rs").write_text(
                "#[path = \"../legacy/main.rs\"] mod implementation;\n"
                "mod parent;\n"
                "use crate::implementation::internal_fn;\n"
                "fn root_fn() {}\n",
                encoding="utf-8",
            )

            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            build_index(cfg)
            store = IndexStore(str(cfg.db_path))
            try:
                imports = {
                    (store.file_by_id(row["file_id"])["path"], row["module"]):
                    store.file_by_id(row["target_id"])["path"]
                    for row in store.conn.execute(
                        "SELECT file_id, module, target_id FROM imports "
                        "WHERE target_id IS NOT NULL"
                    )
                }
                self.assertEqual(
                    imports[("src/lib.rs", "implementation")],
                    "legacy/main.rs",
                )
                self.assertEqual(
                    imports[("src/lib.rs", "crate::implementation::internal_fn")],
                    "legacy/main.rs",
                )
                self.assertEqual(
                    imports[("src/parent.rs", "child")],
                    "src/alt/child.rs",
                )
                self.assertEqual(
                    imports[("src/alt/child.rs", "super::super::root_fn")],
                    "src/lib.rs",
                )
            finally:
                store.close()

    def test_rust_path_attribute_survives_comments_and_blank_lines(self):
        """Comments cannot cancel or invent a pending path attribute."""
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            src = root / "src"
            (src / "alt").mkdir(parents=True)
            src.joinpath("lib.rs").write_text(
                "/* #[path = \"wrong.rs\"] */\n"
                "#[path = \"alt/child.rs\"]\n"
                "\n"
                "// the attribute applies across comments\n"
                "mod child;\n",
                encoding="utf-8",
            )
            src.joinpath("alt", "child.rs").write_text(
                "fn child_fn() {}\n", encoding="utf-8")

            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            build_index(cfg)
            store = IndexStore(str(cfg.db_path))
            try:
                row = store.find_import(module="child")
                self.assertEqual(
                    store.file_by_id(row["target_id"])["path"],
                    "src/alt/child.rs",
                )
            finally:
                store.close()

    def test_rust_multiline_path_attribute_resolves_custom_module_file(self):
        """A multiline path attribute changes the file selected by mod."""
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            src = root / "src"
            (src / "alt").mkdir(parents=True)
            src.joinpath("lib.rs").write_text(
                "#[path = \"alt/child.rs\"\n"
                "]\n"
                "mod child;\n",
                encoding="utf-8",
            )
            src.joinpath("child.rs").write_text(
                "fn default_child_fn() {}\n", encoding="utf-8")
            src.joinpath("alt", "child.rs").write_text(
                "fn custom_child_fn() {}\n", encoding="utf-8")

            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            build_index(cfg)
            store = IndexStore(str(cfg.db_path))
            try:
                row = store.find_import(module="child")
                self.assertEqual(
                    store.file_by_id(row["target_id"])["path"],
                    "src/alt/child.rs",
                )
            finally:
                store.close()

    def test_rust_path_attribute_string_continuation_resolves_custom_file(self):
        """A continued path string still selects the custom module file."""
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            src = root / "src"
            (src / "alt").mkdir(parents=True)
            src.joinpath("lib.rs").write_text(
                "#[path = \"alt/\\\n"
                "    child.rs\"]\n"
                "mod child;\n",
                encoding="utf-8",
            )
            src.joinpath("child.rs").write_text(
                "fn default_child_fn() {}\n", encoding="utf-8")
            src.joinpath("alt", "child.rs").write_text(
                "fn custom_child_fn() {}\n", encoding="utf-8")

            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            build_index(cfg)
            store = IndexStore(str(cfg.db_path))
            try:
                row = store.find_import(module="child")
                self.assertEqual(
                    store.file_by_id(row["target_id"])["path"],
                    "src/alt/child.rs",
                )
            finally:
                store.close()

    def test_rust_path_attribute_continuation_skips_blank_lines(self):
        """A continued path can span multiple physical lines."""
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            src = root / "src"
            (src / "alt").mkdir(parents=True)
            src.joinpath("lib.rs").write_text(
                "#[path = \"alt/\\\n"
                "\n"
                "    child.rs\"]\n"
                "mod child;\n",
                encoding="utf-8",
            )
            src.joinpath("child.rs").write_text(
                "fn default_child_fn() {}\n", encoding="utf-8")
            src.joinpath("alt", "child.rs").write_text(
                "fn custom_child_fn() {}\n", encoding="utf-8")

            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            build_index(cfg)
            store = IndexStore(str(cfg.db_path))
            try:
                row = store.find_import(module="child")
                self.assertEqual(
                    store.file_by_id(row["target_id"])["path"],
                    "src/alt/child.rs",
                )
            finally:
                store.close()

    def test_rust_edition_2021_bare_use_prefers_current_module(self):
        """Rust 2018+ resolves a bare use path from the current module."""
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            src = root / "src"
            (src / "child" / "inner").mkdir(parents=True)
            (root / "Cargo.toml").write_text(
                "[package]\nname = \"demo\"\nversion = \"0.1.0\"\n"
                "edition = \"2021\"\n",
                encoding="utf-8",
            )
            src.joinpath("lib.rs").write_text(
                "mod child;\nmod inner;\nmod root_only;\n", encoding="utf-8")
            src.joinpath("child.rs").write_text(
                "mod inner;\n"
                "use inner::foo;\n"
                "use root_only::foo;\n"
                "use local_item;\n"
                "fn local_item() {}\n"
                "fn call() { foo(); }\n",
                encoding="utf-8",
            )
            src.joinpath("inner.rs").write_text(
                "fn foo() {}\n", encoding="utf-8")
            src.joinpath("child", "inner.rs").write_text(
                "fn foo() {}\n", encoding="utf-8")
            src.joinpath("root_only.rs").write_text(
                "fn foo() {}\n", encoding="utf-8")

            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            build_index(cfg)
            store = IndexStore(str(cfg.db_path))
            try:
                row = store.find_import(module="inner::foo")
                self.assertEqual(
                    store.file_by_id(row["target_id"])["path"],
                    "src/child/inner.rs",
                )
                self.assertIsNone(
                    store.find_import(module="root_only::foo")["target_id"]
                )
                self.assertEqual(
                    store.find_import(module="local_item")["target_id"],
                    store.file_by_path("src/child.rs")["id"],
                )
            finally:
                store.close()

    def test_rust_workspace_edition_resolves_bare_use_from_current_module(self):
        """A member inherits its workspace edition for bare ``use`` paths."""
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            member = root / "member"
            src = member / "src"
            (src / "child").mkdir(parents=True)
            root.joinpath("Cargo.toml").write_text(
                "[workspace]\nmembers = [\"member\"]\n\n"
                "[workspace.package]\nedition = \"2021\"\n",
                encoding="utf-8",
            )
            member.joinpath("Cargo.toml").write_text(
                "[package]\nname = \"member\"\nversion = \"0.1.0\"\n"
                "edition.workspace = true\n",
                encoding="utf-8",
            )
            src.joinpath("lib.rs").write_text(
                "mod child;\nmod inner;\n", encoding="utf-8")
            src.joinpath("child.rs").write_text(
                "mod inner;\nuse inner::foo;\nfn call() { foo(); }\n",
                encoding="utf-8",
            )
            src.joinpath("inner.rs").write_text(
                "fn foo() {}\n", encoding="utf-8")
            src.joinpath("child", "inner.rs").write_text(
                "fn foo() {}\n", encoding="utf-8")

            cfg = load_config(root=str(root))
            cfg.engine = "quick"

            def assert_target():
                store = IndexStore(str(cfg.db_path))
                try:
                    target = store.find_import(module="inner::foo")
                    self.assertEqual(
                        store.file_by_id(target["target_id"])["path"],
                        "member/src/child/inner.rs",
                    )
                finally:
                    store.close()

            build_index(cfg)
            assert_target()

            store = IndexStore(str(cfg.db_path))
            try:
                target = store.find_import(module="inner::foo")
                stale_target = store.file_by_path("member/src/inner.rs")
                store.conn.execute(
                    "UPDATE imports SET target_id = ? WHERE id = ?",
                    (stale_target["id"], target["id"]),
                )
                scan_config = json.loads(store.get_meta("scan_config"))
                scan_config["resolver_version"] = 3
                store.set_meta("scan_config", json.dumps(scan_config))
                store.conn.commit()
            finally:
                store.close()

            report = build_index(cfg)
            self.assertEqual(report.files_changed, 0)
            assert_target()

            with patch("codegraph.resolver.tomllib", None):
                build_index(cfg, force=True)
                assert_target()

    def test_rust_member_root_inherits_parent_workspace_edition(self):
        """Indexing a member alone still applies its parent workspace edition."""
        with tempfile.TemporaryDirectory() as tmp:
            workspace = Path(tmp)
            member = workspace / "member"
            src = member / "src"
            (src / "child").mkdir(parents=True)
            workspace.joinpath("Cargo.toml").write_text(
                "[workspace]\nmembers = [\"member\"]\n\n"
                "[workspace.package]\nedition = \"2021\"\n",
                encoding="utf-8",
            )
            member.joinpath("Cargo.toml").write_text(
                "[package]\nname = \"member\"\nversion = \"0.1.0\"\n"
                "edition.workspace = true\n",
                encoding="utf-8",
            )
            src.joinpath("lib.rs").write_text(
                "mod child;\nmod inner;\n", encoding="utf-8")
            src.joinpath("child.rs").write_text(
                "mod inner;\nuse inner::foo;\nfn call() { foo(); }\n",
                encoding="utf-8",
            )
            src.joinpath("inner.rs").write_text(
                "fn foo() {}\n", encoding="utf-8")
            src.joinpath("child", "inner.rs").write_text(
                "fn foo() {}\n", encoding="utf-8")

            cfg = load_config(root=str(member))
            cfg.engine = "quick"
            build_index(cfg)
            store = IndexStore(str(cfg.db_path))
            try:
                target = store.find_import(module="inner::foo")
                self.assertEqual(
                    store.file_by_id(target["target_id"])["path"],
                    "src/child/inner.rs",
                )
            finally:
                store.close()

    def test_rust_2015_bare_use_does_not_fallback_to_current_module(self):
        """Rust 2015 bare use paths stay crate-relative without a root."""
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            src = root / "src"
            (src / "parent").mkdir(parents=True)
            src.joinpath("lib.rs").write_text(
                "fn unrelated_root_fn() {}\n", encoding="utf-8")
            src.joinpath("parent.rs").write_text(
                "mod inner;\n"
                "use inner::foo;\n"
                "use self::inner::foo;\n",
                encoding="utf-8",
            )
            src.joinpath("parent", "inner.rs").write_text(
                "fn foo() {}\n", encoding="utf-8")
            src.joinpath("orphan.rs").write_text(
                "use super::unrelated_root_fn;\n", encoding="utf-8")

            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            build_index(cfg)
            store = IndexStore(str(cfg.db_path))
            try:
                parent_id = store.file_by_path("src/parent.rs")["id"]
                self.assertEqual(
                    resolve_module(store, parent_id, "inner"),
                    store.file_by_path("src/parent/inner.rs")["id"],
                )
                bare = store.find_import(module="inner::foo")
                self.assertIsNone(bare["target_id"])
                explicit = store.find_import(module="self::inner::foo")
                self.assertEqual(
                    store.file_by_id(explicit["target_id"])['path'],
                    "src/parent/inner.rs",
                )
                orphan_id = store.file_by_path("src/orphan.rs")["id"]
                self.assertIsNone(
                    store.find_import(
                        module="super::unrelated_root_fn", file_id=orphan_id,
                    )["target_id"]
                )
            finally:
                store.close()

    def test_rust_use_alias_resolves_call_to_source_symbol(self):
        """An aliased use binds the alias to the source item."""
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            src = root / "src"
            src.mkdir()
            src.joinpath("lib.rs").write_text(
                "mod a;\nuse crate::a::foo as bar;\n"
                "fn call() { bar(); }\n",
                encoding="utf-8",
            )
            src.joinpath("a.rs").write_text(
                "fn foo() {}\n", encoding="utf-8")

            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            build_index(cfg)
            store = IndexStore(str(cfg.db_path))
            try:
                file_id = store.file_by_path("src/lib.rs")["id"]
                symbol_id = resolve_callee(store, file_id, "bar")
                self.assertEqual(
                    store.symbol_by_id(symbol_id)["qualname"],
                    "src/a.foo",
                )
            finally:
                store.close()

    def test_rust_module_alias_preserves_nested_member_path(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            src = root / "src"
            (src / "a").mkdir(parents=True)
            (src / "lib.rs").write_text(
                "mod a;\n"
                "use crate::a as A;\n"
                "fn caller() { A::nested::helper(); }\n",
                encoding="utf-8",
            )
            (src / "a.rs").write_text(
                "pub mod nested;\n"
                "pub fn helper() {}\n",
                encoding="utf-8",
            )
            (src / "a" / "nested.rs").write_text(
                "pub fn helper() {}\n",
                encoding="utf-8",
            )

            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            build_index(cfg)
            store = IndexStore(str(cfg.db_path))
            try:
                file_id = store.file_by_path("src/lib.rs")["id"]
                target_id = resolve_callee(
                    store, file_id, "A::nested::helper"
                )
                target = store.symbol_by_id(target_id)
                self.assertEqual(
                    store.file_by_id(target["file_id"])["path"],
                    "src/a/nested.rs",
                )
            finally:
                store.close()

    def test_rust_inline_use_alias_resolves_across_engines(self):
        """Aliases to inline-module items resolve without a target file."""
        for engine in ("quick", "deep", "auto"):
            with self.subTest(engine=engine):
                with tempfile.TemporaryDirectory() as tmp:
                    root = Path(tmp)
                    (root / "lib.rs").write_text(
                        "mod util { pub fn helper() {} }\n"
                        "use crate::util::helper as h;\n"
                        "fn caller() { h(); }\n",
                        encoding="utf-8",
                    )

                    cfg = load_config(root=str(root))
                    cfg.engine = engine
                    build_index(cfg, quiet=True)
                    store = IndexStore(str(cfg.db_path))
                    try:
                        file_id = store.file_by_path("lib.rs")["id"]
                        target_id = resolve_callee(store, file_id, "h")
                        self.assertIsNotNone(target_id)
                        self.assertEqual(
                            store.symbol_by_id(target_id)["qualname"],
                            "lib.util.helper",
                        )
                        call = store.find_call(callee="h", file_id=file_id)
                        self.assertEqual(call["callee_id"], target_id)
                    finally:
                        store.close()

    def test_ignored_nested_cargo_manifest_does_not_hide_conventional_root(self):
        """Excluded package metadata must not change in-scope Rust roots."""
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            src = root / "src"
            ignored = root / "ignored"
            src.mkdir()
            ignored.mkdir()
            src.joinpath("lib.rs").write_text(
                "use crate::root_fn;\nfn root_fn() {}\n",
                encoding="utf-8",
            )
            ignored.joinpath("Cargo.toml").write_text(
                "[package]\nname = \"ignored\"\nversion = \"0.1.0\"\n"
                "[lib]\npath = \"entry.rs\"\n",
                encoding="utf-8",
            )
            ignored.joinpath("entry.rs").write_text(
                "fn root_fn() {}\n", encoding="utf-8")

            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            cfg.exclude = list(cfg.exclude) + ["ignored"]
            build_index(cfg)
            store = IndexStore(str(cfg.db_path))
            try:
                row = store.find_import(module="crate::root_fn")
                self.assertEqual(
                    store.file_by_id(row["target_id"])["path"],
                    "src/lib.rs",
                )
            finally:
                store.close()

    def test_rust_use_does_not_resolve_undeclared_module_file(self):
        """A matching file is not a module until a mod declaration reaches it."""
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            src = root / "src"
            src.mkdir()
            (src / "lib.rs").write_text(
                "use crate::orphan::orphan_fn;\n"
                "use crate::missing::root_fn;\n"
                "fn root_fn() {}\n",
                encoding="utf-8",
            )
            (src / "orphan.rs").write_text(
                "fn orphan_fn() {}\n", encoding="utf-8")

            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            build_index(cfg)
            store = IndexStore(str(cfg.db_path))
            try:
                self.assertIsNone(
                    store.find_import(module="crate::orphan::orphan_fn")["target_id"]
                )
                self.assertIsNone(
                    store.find_import(module="crate::missing::root_fn")["target_id"]
                )
            finally:
                store.close()

    def test_rust_mod_graph_changes_re_resolve_unchanged_descendants(self):
        """Changing mod reachability refreshes imports in unchanged modules."""
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            src = root / "src"
            src.mkdir()
            manifest = root / "Cargo.toml"
            manifest.write_text(
                "[package]\nname = \"demo\"\nversion = \"0.1.0\"\n\n"
                "[lib]\npath = \"src/lib.rs\"\n",
                encoding="utf-8",
            )
            lib = src / "lib.rs"
            lib.write_text("fn root_fn() {}\n", encoding="utf-8")
            child = src / "child.rs"
            child.write_text(
                "use crate::root_fn;\n", encoding="utf-8")

            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            build_index(cfg)
            store = IndexStore(str(cfg.db_path))
            try:
                self.assertIsNone(
                    store.find_import(module="crate::root_fn")["target_id"]
                )
            finally:
                store.close()

            lib.write_text("mod child;\nfn root_fn() {}\n", encoding="utf-8")
            build_index(cfg)
            store = IndexStore(str(cfg.db_path))
            try:
                row = store.find_import(module="crate::root_fn")
                self.assertEqual(store.file_by_id(row["target_id"])["path"],
                                 "src/lib.rs")
            finally:
                store.close()

    def test_bare_relative_import_resolves_on_first_build(self):
        """from . import x must resolve to pkg/x.py on a fresh index."""
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            pkg = root / "pkg"
            pkg.mkdir()
            (pkg / "__init__.py").write_text("", encoding="utf-8")
            (pkg / "ship.py").write_text(
                "def deliver(item):\n    return item\n", encoding="utf-8")
            (pkg / "cart.py").write_text(
                "from . import ship\n\n"
                "def send(item):\n    return ship.deliver(item)\n", encoding="utf-8")
            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            build_index(cfg)
            store = IndexStore(str(cfg.db_path))
            try:
                fid = store.file_by_path("pkg/cart.py")["id"]
                self.assertEqual(
                    resolve_module(store, fid, "."), store.file_by_path("pkg/__init__.py")["id"]
                )
                # ship.deliver reaches through the relative import
                sid = resolve_callee(store, fid, "ship.deliver")
                self.assertIsNotNone(sid)
                self.assertEqual(store.symbol_by_id(sid).qualname, "pkg.ship.deliver")
            finally:
                store.close()

    def test_root_package_relative_import(self):
        """from . import x inside a root __init__.py must resolve to x.py."""
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "__init__.py").write_text(
                "from . import sibling\n\n"
                "def expose(item):\n    return sibling.deliver(item)\n",
                encoding="utf-8",
            )
            (root / "sibling.py").write_text(
                "def deliver(item):\n    return item\n", encoding="utf-8")
            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            build_index(cfg)
            store = IndexStore(str(cfg.db_path))
            try:
                fid = store.file_by_path("__init__.py")["id"]
                sid = resolve_callee(store, fid, "sibling.deliver")
                self.assertIsNotNone(sid)
                self.assertEqual(
                    store.symbol_by_id(sid).qualname, "sibling.deliver"
                )
            finally:
                store.close()

    def test_init_file_relative_import_base(self):
        """from . import ship inside pkg/__init__.py must resolve like pkg.ship."""
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            pkg = root / "pkg"
            pkg.mkdir()
            (pkg / "__init__.py").write_text(
                "from . import ship\n\n"
                "def expose(item):\n    return ship.deliver(item)\n",
                encoding="utf-8",
            )
            (pkg / "ship.py").write_text(
                "def deliver(item):\n    return item\n", encoding="utf-8")
            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            build_index(cfg)
            store = IndexStore(str(cfg.db_path))
            try:
                fid = store.file_by_path("pkg/__init__.py")["id"]
                sid = resolve_callee(store, fid, "ship.deliver")
                self.assertIsNotNone(sid)
                self.assertEqual(store.symbol_by_id(sid).qualname, "pkg.ship.deliver")
            finally:
                store.close()

    def test_unresolved_external(self):
        self.assertIsNone(self._callee("main.go", "fmt.Println"))
        self.assertIsNone(self._callee("pkg/cart.py", "os.getcwd"))
        self.assertIsNone(self._callee("pkg/pricing.py", "PRICES.get"))

    def test_module_resolution(self):
        fid = self._file_id("app.py")
        self.assertEqual(
            resolve_module(self.store, fid, "pkg.cart"), self._file_id("pkg/cart.py")
        )
        self.assertEqual(
            resolve_module(self.store, fid, "pkg.pricing"), self._file_id("pkg/pricing.py")
        )
        self.assertIsNone(resolve_module(self.store, fid, "os"))
        # js relative import with extension mismatch
        jfid = self._file_id("web/app.js")
        self.assertEqual(
            resolve_module(self.store, jfid, "./util.js"), self._file_id("web/util.ts")
        )
        # rust mod declaration
        rfid = self._file_id("rustx/main.rs")
        self.assertEqual(resolve_module(self.store, rfid, "lib"), self._file_id("rustx/lib.rs"))

    def test_python_stub_module_resolution(self):
        """Python imports resolve modules and packages that only have .pyi files."""
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "app.py").write_text(
                "import api\n"
                "from stubs import models\n"
                "api.fetch()\n"
                "models.User()\n",
                encoding="utf-8",
            )
            (root / "api.pyi").write_text(
                "def fetch() -> None: ...\n", encoding="utf-8")
            (root / "ambiguous.pyi").write_text(
                "def from_stub() -> None: ...\n", encoding="utf-8")
            ambiguous = root / "ambiguous"
            ambiguous.mkdir()
            (ambiguous / "__init__.py").write_text(
                "def from_package() -> None: ...\n", encoding="utf-8")
            stubs = root / "stubs"
            stubs.mkdir()
            (stubs / "__init__.pyi").write_text(
                "from . import models\n", encoding="utf-8")
            (stubs / "models.pyi").write_text(
                "class User: ...\n", encoding="utf-8")
            pkg = root / "pkg"
            pkg.mkdir()
            (pkg / "foo__init__.pyi").write_text(
                "from . import sibling\n\n"
                "def expose() -> None: sibling.deliver()\n",
                encoding="utf-8",
            )
            (pkg / "sibling.pyi").write_text(
                "def deliver() -> None: ...\n", encoding="utf-8")

            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            build_index(cfg)
            store = IndexStore(str(cfg.db_path))
            try:
                fid = store.file_by_path("app.py")["id"]
                self.assertEqual(
                    resolve_module(store, fid, "api"),
                    store.file_by_path("api.pyi")["id"],
                )
                self.assertEqual(
                    resolve_module(store, fid, "stubs"),
                    store.file_by_path("stubs/__init__.pyi")["id"],
                )
                self.assertEqual(
                    resolve_module(store, fid, "ambiguous"),
                    store.file_by_path("ambiguous/__init__.py")["id"],
                )
                api_call = resolve_callee(store, fid, "api.fetch")
                self.assertEqual(
                    store.symbol_by_id(api_call).qualname, "api.fetch"
                )
                models_call = resolve_callee(store, fid, "models.User")
                self.assertEqual(
                    store.symbol_by_id(models_call).qualname, "stubs.models.User"
                )
                foo_id = store.file_by_path("pkg/foo__init__.pyi")["id"]
                sibling_call = resolve_callee(store, foo_id, "sibling.deliver")
                self.assertEqual(
                    store.symbol_by_id(sibling_call).qualname,
                    "pkg.sibling.deliver",
                )
            finally:
                store.close()

    def test_scoped_resolution_is_atomic(self):
        statements = []
        self.store.conn.set_trace_callback(statements.append)
        try:
            resolve_all(self.store, file_ids={self._file_id("app.py")})
        finally:
            self.store.conn.set_trace_callback(None)
        self.assertIsNotNone(self.store.find_call(callee="create_cart")["callee_id"])
        self.assertIn("BEGIN IMMEDIATE", statements)
        self.assertEqual(statements.count("COMMIT"), 1)

    def test_scoped_resolution_chunks_large_id_sets(self):
        """Large scoped ID sets must not exceed SQLite's bind limit."""
        if not hasattr(self.store.conn, "setlimit"):
            self.skipTest("sqlite3.Connection.setlimit is unavailable")

        limit = sqlite3.SQLITE_LIMIT_VARIABLE_NUMBER
        previous_limit = self.store.conn.setlimit(limit, 999)
        try:
            large_ids = set(range(1, 1025))
            resolve_all(
                self.store,
                file_ids=large_ids,
                call_ids=large_ids,
                import_ids=large_ids,
            )
        finally:
            self.store.conn.setlimit(limit, previous_limit)

        self.assertIsNotNone(self.store.find_call(callee="create_cart")["callee_id"])
        self.assertIsNotNone(self.store.find_import(module="pkg.cart")["target_id"])


if __name__ == "__main__":
    unittest.main()
