"""Tests for the read-side query API (queries)."""

import shutil
import sqlite3
import tempfile
import unittest
from pathlib import Path

from codegraph.builder import build_index
from codegraph.config import load_config
from codegraph.queries import (
    query_callers,
    query_callees,
    query_dependents,
    query_deps,
    query_impact,
    query_search,
    query_stats,
)
from codegraph.store import IndexStore

from .fixtures import PROJ


class QueryTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name) / "proj"
        shutil.copytree(PROJ, self.root)
        cfg = load_config(root=str(self.root))
        cfg.engine = "quick"
        build_index(cfg)
        self.store = IndexStore(str(cfg.db_path))

    def tearDown(self):
        self.store.close()
        self.tmp.cleanup()

    def test_callers_of_price(self):
        rows = query_callers(self.store, "pkg.pricing.price")
        got = sorted(r["qualname"] for r in rows)
        self.assertEqual(got, ["pkg.cart.Cart.total", "pkg.pricing.discount"])

    def test_callers_by_ambiguous_go_qualname_return_no_partial_results(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "go.mod").write_text(
                "module example.com/acme\n\ngo 1.22\n", encoding="utf-8")
            for package_dir, caller in (("a", "callA"), ("b", "callB")):
                directory = root / package_dir
                directory.mkdir()
                (directory / "target.go").write_text(
                    "package client\nfunc Target() {}\n", encoding="utf-8")
                (directory / "caller.go").write_text(
                    f"package client\nfunc {caller}() {{ Target() }}\n",
                    encoding="utf-8",
                )

            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            build_index(cfg)
            store = IndexStore(str(cfg.db_path))
            try:
                resolved = store.conn.execute(
                    "SELECT callee_id FROM calls WHERE callee = 'Target'"
                ).fetchall()
                self.assertEqual(len(resolved), 2)
                self.assertTrue(all(row["callee_id"] is not None for row in resolved))
                self.assertEqual(query_callers(store, "client.Target"), [])
            finally:
                store.close()

    def test_callers_by_plain_name(self):
        rows = query_callers(self.store, "create_cart")
        got = sorted(r["qualname"] for r in rows)
        self.assertEqual(got, ["app.main"])

    def test_callers_nonexistent(self):
        self.assertEqual(query_callers(self.store, "nope.nope"), [])

    def test_callers_rejects_negative_limit(self):
        with self.assertRaisesRegex(ValueError, "limit must be non-negative"):
            query_callers(self.store, "pkg.pricing.price", limit=-1)

    def test_callees_of_main(self):
        rows = query_callees(self.store, "app.main")
        callees = sorted(
            (r["callee"], r["callee_id"] is not None) for r in rows
        )
        self.assertIn(("cart.add", True), callees)
        self.assertIn(("cart.total", True), callees)
        self.assertIn(("create_cart", True), callees)

    def test_callees_rejects_negative_limit(self):
        with self.assertRaisesRegex(ValueError, "limit must be non-negative"):
            query_callees(self.store, "app.main", limit=-1)

    def test_callees_of_go_main(self):
        rows = query_callees(self.store, "main.main")
        got = sorted((r["callee"], r["callee_id"] is not None) for r in rows)
        self.assertIn(("fmt.Println", False), got)  # external, unresolved
        self.assertIn(("helper.Greet", True), got)

    def test_callees_of_java_method(self):
        rows = query_callees(self.store, "com.demo.Runner.main")
        got = sorted(r["callee"] for r in rows)
        self.assertIn("Calc.sum", got)
        self.assertIn("System.out.println", got)

    def test_deps_of_cart_module(self):
        rows = query_deps(self.store, "pkg.cart")
        got = sorted((r["module"], r["target_path"] or "") for r in rows)
        self.assertIn(("os", ""), got)
        # "from pkg import pricing" records the package import with its
        # member names; the package __init__ file is the resolved target
        self.assertIn(("pkg", "pkg/__init__.py"), got)
        member_import = next(row for row in rows if row["module"] == "pkg")
        self.assertEqual(member_import["names"], ["pricing"])

    def test_deps_by_file_path(self):
        rows = query_deps(self.store, "web/index.ts")
        got = sorted((r["module"], r["target_path"]) for r in rows)
        self.assertEqual(got, [("./logger", "web/logger.ts"), ("./util", "web/util.ts")])

    def test_deps_rejects_negative_limit(self):
        with self.assertRaisesRegex(ValueError, "limit must be non-negative"):
            query_deps(self.store, "pkg.cart", limit=-1)

    def test_deps_of_go_package_aggregates_files(self):
        """Package queries include imports from every file in the package."""
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "first.go").write_text(
                'package p\n\nimport "fmt"\n', encoding="utf-8")
            (root / "second.go").write_text(
                'package p\n\nimport "os"\n', encoding="utf-8")
            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            build_index(cfg)
            store = IndexStore(str(cfg.db_path))
            try:
                rows = query_deps(store, "p")
                self.assertEqual(
                    {row["module"] for row in rows}, {"fmt", "os"})
            finally:
                store.close()

    def test_deps_chunks_large_package_with_sqlite_variable_limit(self):
        with tempfile.TemporaryDirectory() as tmp:
            store = IndexStore(str(Path(tmp) / "large.sqlite"))
            try:
                count = 1000
                store.conn.executemany(
                    "INSERT INTO files(path, lang, module) VALUES (?, ?, ?)",
                    [
                        (f"pkg/file{i:04}.go", "go", "p")
                        for i in range(count)
                    ],
                )
                file_ids = [
                    row["id"] for row in store.conn.execute(
                        "SELECT id FROM files ORDER BY id"
                    )
                ]
                store.conn.executemany(
                    "INSERT INTO imports(file_id, module, kind, line) "
                    "VALUES (?, ?, ?, ?)",
                    [(file_id, f"dep{i}", "import", 1)
                     for i, file_id in enumerate(file_ids)],
                )
                limit_id = getattr(sqlite3, "SQLITE_LIMIT_VARIABLE_NUMBER", None)
                if hasattr(store.conn, "setlimit") and limit_id is not None:
                    store.conn.setlimit(limit_id, 999)

                rows = query_deps(store, "p", limit=count)

                self.assertEqual(len(rows), count)
                self.assertEqual(
                    {row["module"] for row in rows},
                    {f"dep{i}" for i in range(count)},
                )
            finally:
                store.close()

    def test_dependents(self):
        rows = query_dependents(self.store, "pkg.pricing")
        got = sorted(r["path"] for r in rows)
        self.assertEqual(got, ["app.py", "pkg/cart.py"])
        rows2 = query_dependents(self.store, "web/util.ts")
        got2 = sorted(r["path"] for r in rows2)
        self.assertEqual(got2, ["web/app.js", "web/index.ts"])

    def test_typescript_declaration_index_has_canonical_module_id(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "app.ts").write_text(
                'import { make } from "./util";\n', encoding="utf-8")
            util = root / "util"
            util.mkdir()
            (util / "index.d.ts").write_text(
                "export declare function make(): void;\n", encoding="utf-8")

            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            build_index(cfg)
            store = IndexStore(str(cfg.db_path))
            try:
                declaration = store.file_by_path("util/index.d.ts")
                self.assertEqual(declaration["module"], "util/index")
                rows = query_dependents(store, "util/index")
                self.assertEqual([row["path"] for row in rows], ["app.ts"])
            finally:
                store.close()

    def test_dependents_include_all_files_in_java_package(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            models = root / "models"
            app = root / "app"
            models.mkdir()
            app.mkdir()
            (models / "Foo.java").write_text(
                "package sample.models;\npublic class Foo {}\n",
                encoding="utf-8",
            )
            (models / "Bar.java").write_text(
                "package sample.models;\npublic class Bar {}\n",
                encoding="utf-8",
            )
            (app / "One.java").write_text(
                "package sample.app;\nimport sample.models.Foo;\n",
                encoding="utf-8",
            )
            (app / "Two.java").write_text(
                "package sample.app;\nimport sample.models.Bar;\n",
                encoding="utf-8",
            )
            (app / "Both.java").write_text(
                "package sample.app;\n"
                "import sample.models.Foo;\n"
                "import sample.models.Bar;\n",
                encoding="utf-8",
            )

            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            build_index(cfg)
            store = IndexStore(str(cfg.db_path))
            try:
                rows = query_dependents(store, "sample.models")
                self.assertEqual(
                    [row["path"] for row in rows],
                    ["app/Both.java", "app/One.java", "app/Two.java"],
                )
                limited = query_dependents(store, "sample.models", limit=2)
                self.assertEqual(
                    [row["path"] for row in limited],
                    ["app/Both.java", "app/One.java"],
                )
            finally:
                store.close()

    def test_dependents_limit_deduplicates_direct_import_rows(self):
        """Repeated imports must not consume dependent-file limit slots."""
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "target.py").write_text(
                "value = 1\n", encoding="utf-8")
            (root / "duplicate.py").write_text(
                "import target\nimport target\n", encoding="utf-8")
            (root / "other.py").write_text(
                "import target\n", encoding="utf-8")
            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            build_index(cfg)
            store = IndexStore(str(cfg.db_path))
            try:
                rows = query_dependents(store, "target", limit=2)
                self.assertEqual(
                    [row["path"] for row in rows],
                    ["duplicate.py", "other.py"],
                )
            finally:
                store.close()

    def test_dependents_via_aliased_member_import(self):
        """dependents() must see aliased Python member imports."""
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            pkg = root / "pkg"
            pkg.mkdir()
            (pkg / "__init__.py").write_text("", encoding="utf-8")
            (pkg / "pricing.py").write_text(
                "def price(item):\n    return item\n", encoding="utf-8")
            (root / "consumer.py").write_text(
                "from pkg import pricing as p\n\n"
                "def total(item):\n    return p.price(item)\n",
                encoding="utf-8",
            )
            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            build_index(cfg)
            store = IndexStore(str(cfg.db_path))
            try:
                rows = query_dependents(store, "pkg.pricing")
                self.assertEqual([row["path"] for row in rows], ["consumer.py"])
            finally:
                store.close()

    def test_dependents_orders_union_before_applying_limit(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            pkg = root / "pkg"
            pkg.mkdir()
            (pkg / "__init__.py").write_text("", encoding="utf-8")
            (pkg / "pricing.py").write_text(
                "def price(item):\n    return item\n", encoding="utf-8")
            (root / "z_direct.py").write_text(
                "import pkg.pricing\n", encoding="utf-8")
            (root / "a_member.py").write_text(
                "from pkg import pricing\n", encoding="utf-8")

            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            build_index(cfg)
            store = IndexStore(str(cfg.db_path))
            try:
                rows = query_dependents(store, "pkg.pricing")
                self.assertEqual(
                    [row["path"] for row in rows],
                    ["a_member.py", "z_direct.py"],
                )
                limited = query_dependents(store, "pkg.pricing", limit=1)
                self.assertEqual([row["path"] for row in limited], ["a_member.py"])
            finally:
                store.close()

    def test_dependents_limit_deduplicates_member_import_rows(self):
        """Repeated member imports must not consume dependent-file limit slots."""
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            pkg = root / "pkg"
            pkg.mkdir()
            (pkg / "__init__.py").write_text("", encoding="utf-8")
            (pkg / "pricing.py").write_text(
                "def price(item):\n    return item\n", encoding="utf-8")
            (root / "duplicate.py").write_text(
                "from pkg import pricing\nfrom pkg import pricing\n",
                encoding="utf-8",
            )
            (root / "other.py").write_text(
                "from pkg import pricing\n", encoding="utf-8")
            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            build_index(cfg)
            store = IndexStore(str(cfg.db_path))
            try:
                rows = query_dependents(store, "pkg.pricing", limit=2)
                self.assertEqual(
                    [row["path"] for row in rows],
                    ["duplicate.py", "other.py"],
                )
            finally:
                store.close()

    def test_dependents_via_aliased_member_import_with_whitespace(self):
        """dependents() must allow flexible whitespace around ``as``."""
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            pkg = root / "pkg"
            pkg.mkdir()
            (pkg / "__init__.py").write_text("", encoding="utf-8")
            (pkg / "pricing.py").write_text(
                "def price(item):\n    return item\n", encoding="utf-8")
            (root / "consumer_spaces.py").write_text(
                "from pkg import pricing    as p\n\n"
                "def total(item):\n    return p.price(item)\n",
                encoding="utf-8",
            )
            (root / "consumer_tabs.py").write_text(
                "from pkg import pricing\tas\tp\n\n"
                "def total(item):\n    return p.price(item)\n",
                encoding="utf-8",
            )
            (root / "consumer_prefix.py").write_text(
                "from pkg import pricing_factory as p\n\n"
                "def total(item):\n    return p.price(item)\n",
                encoding="utf-8",
            )
            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            build_index(cfg)
            store = IndexStore(str(cfg.db_path))
            try:
                rows = query_dependents(store, "pkg.pricing")
                self.assertEqual(
                    sorted(row["path"] for row in rows),
                    ["consumer_spaces.py", "consumer_tabs.py"],
                )
            finally:
                store.close()

    def test_dependents_limit_caps_the_union(self):
        """The member-import pass must not push results past the limit."""
        rows = query_dependents(self.store, "pkg.pricing", limit=1)
        self.assertEqual([r["path"] for r in rows], ["app.py"])
        rows = query_dependents(self.store, "pkg.pricing", limit=0)
        self.assertEqual(rows, [])

    def test_dependents_rejects_negative_limit(self):
        with self.assertRaisesRegex(ValueError, "limit must be non-negative"):
            query_dependents(self.store, "pkg.pricing", limit=-1)

    def test_impact_transitive_callers(self):
        rows = query_impact(self.store, "pkg.cart.Cart", depth=3)
        got = sorted((r["depth"], r["qualname"]) for r in rows)
        self.assertIn((1, "pkg.cart.create_cart"), got)
        self.assertIn((2, "app.main"), got)
        self.assertEqual([d for d, _ in got], [1, 2])

    def test_impact_respects_depth(self):
        rows = query_impact(self.store, "pkg.cart.Cart", depth=1)
        got = sorted(r["qualname"] for r in rows)
        self.assertEqual(got, ["pkg.cart.create_cart"])

    def test_impact_limit_caps_total_results(self):
        rows = query_impact(self.store, "pkg.cart.Cart", depth=3, limit=1)
        self.assertEqual([r["qualname"] for r in rows], ["pkg.cart.create_cart"])

    def test_impact_handles_wide_frontiers_under_sqlite_variable_limit(self):
        store = IndexStore(":memory:")
        limit_id = getattr(sqlite3, "SQLITE_LIMIT_VARIABLE_NUMBER", None)
        if not hasattr(store.conn, "setlimit") or limit_id is None:
            store.close()
            self.skipTest("SQLite connection variable limits are unavailable")

        try:
            file_id = store.upsert_file("x.py", "python", 0, "", 0, "x")
            target_id = store.conn.execute(
                "INSERT INTO symbols(file_id, kind, name, qualname, start_line, "
                "end_line) VALUES(?, 'function', 'target', 'x.target', 1, 1)",
                (file_id,),
            ).lastrowid

            def add_symbol(name):
                return store.conn.execute(
                    "INSERT INTO symbols(file_id, kind, name, qualname, "
                    "start_line, end_line) VALUES(?, 'function', ?, ?, 1, 1)",
                    (file_id, name.rsplit(".", 1)[-1], name),
                ).lastrowid

            def add_call(caller_id, caller, callee_id, callee_name, line):
                store.conn.execute(
                    "INSERT INTO calls(caller_id, caller_name, callee, callee_id, "
                    "file_id, line) VALUES(?, ?, ?, ?, ?, ?)",
                    (caller_id, caller, callee_name, callee_id, file_id, line),
                )

            wide_ids = []
            for i in range(9):
                name = f"x.wide{i}"
                caller_id = add_symbol(name)
                wide_ids.append(caller_id)
                add_call(caller_id, name, target_id, "target", i + 2)

            shared_a = add_symbol("x.shared_a")
            shared_b = add_symbol("x.shared_b")
            unique = add_symbol("x.unique")
            add_call(shared_a, "x.shared_a", wide_ids[0], "wide0", 20)
            add_call(shared_a, "x.shared_a", wide_ids[-1], "wide8", 21)
            add_call(shared_b, "x.shared_b", wide_ids[1], "wide1", 22)
            add_call(shared_b, "x.shared_b", wide_ids[-1], "wide8", 23)
            add_call(unique, "x.unique", wide_ids[-1], "wide8", 24)

            old_limit = store.conn.setlimit(limit_id, 10)
            try:
                rows = query_impact(store, "x.target", depth=2, limit=12)
            finally:
                store.conn.setlimit(limit_id, old_limit)
        finally:
            store.close()

        self.assertEqual(
            {(row["qualname"], row["depth"]) for row in rows},
            {(f"x.wide{i}", 1) for i in range(9)} |
            {("x.shared_a", 2), ("x.shared_b", 2), ("x.unique", 2)},
        )

    def test_impact_limit_counts_distinct_callers(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "x.py").write_text(
                "def target():\n"
                "    pass\n"
                "def a():\n"
                "    target()\n"
                "    target()\n"
                "def b():\n"
                "    target()\n",
                encoding="utf-8",
            )
            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            build_index(cfg)
            store = IndexStore(str(cfg.db_path))
            try:
                rows = query_impact(store, "x.target", depth=1, limit=2)
                self.assertEqual(
                    {r["qualname"] for r in rows}, {"x.a", "x.b"})
            finally:
                store.close()

    def test_impact_rejects_negative_limit(self):
        with self.assertRaisesRegex(ValueError, "limit must be non-negative"):
            query_impact(self.store, "pkg.cart.Cart", limit=-1)

    def test_impact_zero_depth_returns_no_callers(self):
        self.assertEqual(
            query_impact(self.store, "pkg.cart.Cart", depth=0), [])

    def test_impact_dedupes_cyclic_callers(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "x.py").write_text(
                "def leaf():\n"
                "    return 1\n"
                "def rec(n):\n"
                "    if n:\n"
                "        return rec(n - 1)\n"
                "    return leaf()\n"
                "def top():\n"
                "    return rec(5)\n",
                encoding="utf-8",
            )
            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            build_index(cfg)
            store = IndexStore(str(cfg.db_path))
            try:
                rows = query_impact(store, "x.rec", depth=3)
                quals = [r["qualname"] for r in rows]
                self.assertEqual(len(quals), len(set(quals)))  # no dupes
                # rec (self-call) and top are both direct callers -> depth 1
                self.assertEqual(
                    {(r["qualname"], r["depth"]) for r in rows},
                    {("x.rec", 1), ("x.top", 1)},
                )
            finally:
                store.close()

    def test_impact_limit_ignores_cyclic_duplicates(self):
        """A repeated caller must not consume a later-hop result slot."""
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "x.py").write_text(
                "def target():\n"
                "    pass\n"
                "def cycle():\n"
                "    target()\n"
                "    cycle()\n"
                "def other():\n"
                "    target()\n"
                "def new():\n"
                "    cycle()\n",
                encoding="utf-8",
            )
            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            build_index(cfg)
            store = IndexStore(str(cfg.db_path))
            try:
                rows = query_impact(store, "x.target", depth=2, limit=3)
                self.assertEqual(
                    {(r["qualname"], r["depth"]) for r in rows},
                    {("x.cycle", 1), ("x.other", 1), ("x.new", 2)},
                )
            finally:
                store.close()

    def test_search_symbol_and_doc(self):
        hits = query_search(self.store, "discount")
        qualnames = {h["qualname"] for h in hits}
        self.assertIn("pkg.pricing.discount", qualnames)
        # FTS5 also matches docstring content
        hits2 = query_search(self.store, "shopping cart")
        self.assertTrue(any(h["qualname"] == "pkg.cart.Cart" for h in hits2))

    def test_search_empty_query(self):
        self.assertEqual(query_search(self.store, "  "), [])

    def test_search_rejects_negative_limit(self):
        with self.assertRaisesRegex(ValueError, "limit must be non-negative"):
            query_search(self.store, "discount", limit=-1)

    def test_dependents_via_relative_import(self):
        """dependents() must see files importing the module with ``from .``."""
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            pkg = root / "pkg"
            pkg.mkdir()
            (pkg / "__init__.py").write_text(
                "from . import ship\n", encoding="utf-8")
            (pkg / "ship.py").write_text(
                "def deliver(item):\n    return item\n", encoding="utf-8")
            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            build_index(cfg)
            store = IndexStore(str(cfg.db_path))
            try:
                rows = query_dependents(store, "pkg.ship")
                got = sorted(r["path"] for r in rows)
                self.assertEqual(got, ["pkg/__init__.py"])
            finally:
                store.close()

    def test_dependents_via_top_level_relative_import(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "__init__.py").write_text(
                "from . import sibling\n", encoding="utf-8")
            (root / "sibling.py").write_text(
                "def deliver(item):\n    return item\n", encoding="utf-8")
            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            build_index(cfg)
            store = IndexStore(str(cfg.db_path))
            try:
                rows = query_dependents(store, "sibling")
                self.assertEqual(
                    [row["path"] for row in rows], ["__init__.py"])
            finally:
                store.close()

    def test_relative_import_does_not_match_package_prefix(self):
        """A sibling package with a shared prefix is not a dependent."""
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            pkg = root / "pkg"
            pkg.mkdir()
            (pkg / "__init__.py").write_text(
                "from . import pricing\n", encoding="utf-8")
            (pkg / "pricing.py").write_text(
                "def price(item):\n    return item\n", encoding="utf-8")
            pkg2 = root / "pkg2"
            pkg2.mkdir()
            (pkg2 / "__init__.py").write_text("", encoding="utf-8")
            (pkg2 / "consumer.py").write_text(
                "from . import pricing\n", encoding="utf-8")
            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            build_index(cfg)
            store = IndexStore(str(cfg.db_path))
            try:
                rows = query_dependents(store, "pkg.pricing")
                self.assertEqual(
                    [r["path"] for r in rows], ["pkg/__init__.py"])
            finally:
                store.close()

    def test_nested_relative_import_uses_its_dot_level_for_dependents(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            files = {
                "pkg/__init__.py": "",
                "pkg/pricing.py": "def price(item):\n    return item\n",
                "pkg/sub/__init__.py": "",
                "pkg/sub/sibling.py": "from . import pricing\n",
                "pkg/sub/ancestor.py": "from .. import pricing\n",
            }
            for path, text in files.items():
                target = root / path
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_text(text, encoding="utf-8")

            cfg = load_config(root=str(root))
            cfg.engine = "quick"
            build_index(cfg)
            store = IndexStore(str(cfg.db_path))
            try:
                rows = query_dependents(store, "pkg.pricing")
                self.assertEqual(
                    {row["path"] for row in rows},
                    {"pkg/sub/ancestor.py"},
                )
            finally:
                store.close()

    def test_stats(self):
        stats = query_stats(self.store)
        self.assertEqual(stats["files"], 14)
        self.assertGreater(stats["symbols"], 0)
        self.assertGreater(stats["calls"], 0)
        self.assertGreater(stats["imports"], 0)
        self.assertEqual(stats["languages"]["python"], 4)
        self.assertEqual(stats["languages"]["typescript"], 3)
        self.assertIsNotNone(stats["last_indexed"])

    def test_stats_uses_one_snapshot_during_concurrent_index_update(self):
        expected = query_stats(self.store)
        writer = IndexStore(self.store.db_path)
        count_rows = self.store.count_rows
        inserted = False

        def count_rows_with_concurrent_update(table):
            nonlocal inserted
            count = count_rows(table)
            if table == "calls" and not inserted:
                inserted = True
                with writer.transaction():
                    file_id = writer.upsert_file(
                        "concurrent.js", "javascript", 1, "new", 1
                    )
                    writer.conn.execute(
                        "INSERT INTO calls(caller_name, callee, file_id, line) "
                        "VALUES('', 'external', ?, 1)",
                        (file_id,),
                    )
            return count

        self.store.count_rows = count_rows_with_concurrent_update
        try:
            stats = query_stats(self.store)
        finally:
            self.store.count_rows = count_rows
            writer.close()

        self.assertTrue(inserted)
        self.assertEqual(stats, expected)


if __name__ == "__main__":
    unittest.main()
