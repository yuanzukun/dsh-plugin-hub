"""Demo shop package."""
