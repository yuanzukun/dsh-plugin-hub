"""Tests for the stdio MCP server (server.mcp + server.handlers)."""

import io
import json
import os
import shutil
import sqlite3
import stat
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from codegraph import __version__
from codegraph.config import load_config
from codegraph.server.mcp import run_stdio

from .fixtures import PROJ


class McpServerTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name) / "proj"
        shutil.copytree(PROJ, self.root)
        self.cfg = load_config(root=str(self.root))
        self.cfg.engine = "quick"
        # index the project so the server can answer queries
        from codegraph.builder import build_index

        build_index(self.cfg)

    def tearDown(self):
        self.tmp.cleanup()

    def _run(self, messages):
        """Feed JSON-RPC messages (dicts or strings) through the stdio loop."""
        payload = "\n".join(
            m if isinstance(m, str) else json.dumps(m) for m in messages
        ).encode("utf-8")
        out = io.BytesIO()
        log = io.BytesIO()
        run_stdio(io.BytesIO(payload), out, log, self.cfg)
        return [json.loads(line) for line in out.getvalue().decode("utf-8").splitlines() if line]

    def _msg(self, mid, method, params=None):
        return {"jsonrpc": "2.0", "id": mid, "method": method, "params": params or {}}

    def test_handshake_and_tools_list(self):
        replies = self._run(
            [
                self._msg(1, "initialize", {"protocolVersion": "2024-11-05",
                                            "capabilities": {}, "clientInfo": {
                                                "name": "t", "version": "1"}}),
                {"jsonrpc": "2.0", "method": "notifications/initialized"},
                self._msg(2, "tools/list"),
            ]
        )
        self.assertEqual(replies[0]["id"], 1)
        result = replies[0]["result"]
        self.assertEqual(result["protocolVersion"], "2024-11-05")
        self.assertEqual(result["serverInfo"]["name"], "codegraph")
        self.assertEqual(result["serverInfo"]["version"], __version__)
        self.assertIn("tools", result["capabilities"])
        names = [t["name"] for t in replies[1]["result"]["tools"]]
        self.assertEqual(
            sorted(names),
            ["callees", "callers", "dependents", "deps", "impact", "overview", "reindex", "search"],
        )
        # every tool declares an inputSchema
        for t in replies[1]["result"]["tools"]:
            self.assertEqual(t["inputSchema"]["type"], "object")

    def test_successful_tool_results_use_valid_content_for_supported_versions(self):
        for version in ("2024-11-05", "2025-03-26"):
            with self.subTest(version=version):
                replies = self._run([
                    self._msg(1, "initialize", {
                        "protocolVersion": version,
                        "capabilities": {},
                        "clientInfo": {"name": "test", "version": "1"},
                    }),
                    self._msg(2, "tools/call", {
                        "name": "overview", "arguments": {},
                    }),
                ])

                self.assertEqual(
                    replies[0]["result"]["protocolVersion"], version
                )
                result = replies[1]["result"]
                self.assertEqual(
                    [block["type"] for block in result["content"]],
                    ["text", "text"],
                )
                self.assertEqual(
                    json.loads(result["content"][1]["text"])["files"], 14
                )

    def test_protocol_version_negotiation(self):
        replies = self._run([self._msg(1, "initialize", {
            "protocolVersion": "2030-01-01",
            "capabilities": {},
            "clientInfo": {"name": "test-client", "version": "1"},
        })])
        self.assertIn(replies[0]["result"]["protocolVersion"], ("2024-11-05", "2025-03-26"))

    def test_initialize_requires_valid_parameters(self):
        valid = {
            "protocolVersion": "2024-11-05",
            "capabilities": {},
            "clientInfo": {"name": "test-client", "version": "1"},
        }
        cases = [
            ({"capabilities": {}, "clientInfo": valid["clientInfo"]},
             "Invalid params: protocolVersion must be a string"),
            ({**valid, "protocolVersion": []},
             "Invalid params: protocolVersion must be a string"),
            ({"protocolVersion": valid["protocolVersion"],
              "clientInfo": valid["clientInfo"]},
             "Invalid params: capabilities must be an object"),
            ({**valid, "capabilities": []},
             "Invalid params: capabilities must be an object"),
            ({"protocolVersion": valid["protocolVersion"],
              "capabilities": {}},
             "Invalid params: clientInfo must be an object"),
            ({**valid, "clientInfo": []},
             "Invalid params: clientInfo must be an object"),
            ({**valid, "clientInfo": {"name": "test-client"}},
             "Invalid params: clientInfo requires string name and version"),
            ({**valid, "clientInfo": {"name": "test-client", "version": []}},
             "Invalid params: clientInfo requires string name and version"),
            ({**valid, "clientInfo": {"version": "1"}},
             "Invalid params: clientInfo requires string name and version"),
            ({**valid, "clientInfo": {"name": [], "version": "1"}},
             "Invalid params: clientInfo requires string name and version"),
        ]
        messages = [
            self._msg(i, "initialize", params)
            for i, (params, _) in enumerate(cases, start=1)
        ]

        replies = self._run(messages)

        self.assertEqual(len(replies), len(cases))
        for reply, (_, expected) in zip(replies, cases):
            self.assertEqual(reply["error"]["code"], -32602)
            self.assertEqual(reply["error"]["message"], expected)

    def test_callers_tool(self):
        replies = self._run([self._msg(1, "tools/call", {
            "name": "callers", "arguments": {"symbol": "pkg.pricing.price"}})])
        result = replies[0]["result"]
        self.assertFalse(result["isError"])
        text = result["content"][0]["text"]
        self.assertIn("pkg.pricing.discount", text)
        self.assertIn("pkg.cart.Cart.total", text)
        self.assertEqual([block["type"] for block in result["content"]],
                         ["text", "text"])
        rows = json.loads(result["content"][1]["text"])
        self.assertEqual(len(rows), 2)

    def test_search_tool_and_overview(self):
        replies = self._run([
            self._msg(1, "tools/call", {"name": "search", "arguments": {"query": "discount"}}),
            self._msg(2, "tools/call", {"name": "overview", "arguments": {}}),
        ])
        self.assertIn("pkg.pricing.discount", replies[0]["result"]["content"][0]["text"])
        stats = json.loads(replies[1]["result"]["content"][1]["text"])
        self.assertEqual(stats["files"], 14)

    def test_unknown_tool_is_protocol_error(self):
        replies = self._run([self._msg(1, "tools/call", {"name": "ghost", "arguments": {}})])
        self.assertIn("error", replies[0])
        self.assertEqual(replies[0]["error"]["code"], -32602)

    def test_non_string_tool_names_are_invalid_params(self):
        malformed = (None, [], {}, 0, False, "")
        messages = [
            self._msg(i, "tools/call", {"name": name})
            for i, name in enumerate(malformed, start=1)
        ]
        messages.append(self._msg(len(messages) + 1, "tools/call", {}))

        replies = self._run(messages)

        self.assertEqual(len(replies), len(messages))
        for reply in replies:
            self.assertEqual(reply["error"]["code"], -32602)
            self.assertEqual(
                reply["error"]["message"],
                "Invalid params: tool name must be a non-empty string",
            )

    def test_invalid_arguments_are_tool_errors(self):
        replies = self._run([self._msg(1, "tools/call", {
            "name": "callers", "arguments": {}})])
        result = replies[0]["result"]
        self.assertTrue(result["isError"])
        self.assertIn("symbol", result["content"][0]["text"])

    def test_non_object_arguments_do_not_run_reindex(self):
        malformed = (None, [], ["force"], "force", 0, False)
        messages = [
            self._msg(i, "tools/call", {"name": "reindex", "arguments": args})
            for i, args in enumerate(malformed, start=1)
        ]

        with patch("codegraph.server.handlers.build_index") as build_index:
            replies = self._run(messages)

        self.assertEqual(len(replies), len(malformed))
        for reply in replies:
            self.assertEqual(reply["error"]["code"], -32602)
            self.assertEqual(
                reply["error"]["message"],
                "Invalid params: tool arguments must be an object",
            )
        build_index.assert_not_called()

    def test_reindex_force_requires_boolean_and_preserves_boolean_value(self):
        invalid = (None, "false", "true", 0, 1, [], {})
        malformed = [
            self._msg(i, "tools/call", {
                "name": "reindex", "arguments": {"force": value}
            })
            for i, value in enumerate(invalid, start=1)
        ]
        with patch("codegraph.server.handlers.build_index") as build_index:
            replies = self._run(malformed)

        self.assertEqual(len(replies), len(invalid))
        for reply in replies:
            result = reply["result"]
            self.assertTrue(result["isError"])
            self.assertIn("force must be a boolean", result["content"][0]["text"])
        build_index.assert_not_called()

        valid = [
            self._msg(len(invalid) + i, "tools/call", {
                "name": "reindex", "arguments": {"force": force}
            })
            for i, force in enumerate((False, True), start=1)
        ]
        with patch(
            "codegraph.server.handlers.build_index",
            return_value=SimpleNamespace(
                files_scanned=0, files_changed=0, files_skipped=0,
                files_removed=0, symbols=0, calls=0, imports=0,
                complete=True,
            ),
        ) as build_index:
            replies = self._run(valid)

        self.assertTrue(all(not reply["result"]["isError"] for reply in replies))
        forwarded = [call.kwargs["force"] for call in build_index.call_args_list]
        self.assertEqual(forwarded, [False, True])
        self.assertTrue(all(type(force) is bool for force in forwarded))

    def test_incomplete_forced_reindex_is_reported_as_error(self):
        with patch(
            "codegraph.server.handlers.build_index",
            return_value=SimpleNamespace(complete=False),
        ) as build_index:
            replies = self._run([
                self._msg(1, "tools/call", {
                    "name": "reindex", "arguments": {"force": True}
                })
            ])

        result = replies[0]["result"]
        self.assertTrue(result["isError"])
        self.assertIn(
            "forced index rebuild incomplete", result["content"][0]["text"]
        )
        build_index.assert_called_once()

    def test_incomplete_incremental_reindex_is_reported_as_error(self):
        with patch(
            "codegraph.server.handlers.build_index",
            return_value=SimpleNamespace(complete=False),
        ) as build_index:
            replies = self._run([
                self._msg(1, "tools/call", {
                    "name": "reindex", "arguments": {"force": False}
                })
            ])

        result = replies[0]["result"]
        self.assertTrue(result["isError"])
        self.assertIn(
            "incremental reindex incomplete", result["content"][0]["text"]
        )
        self.assertIn(
            "partial changes may have been committed",
            result["content"][0]["text"],
        )
        build_index.assert_called_once()

    def test_omitted_arguments_default_to_empty_object(self):
        replies = self._run([
            self._msg(1, "tools/call", {"name": "overview"}),
        ])

        result = replies[0]["result"]
        self.assertFalse(result["isError"], result)
        self.assertEqual(
            json.loads(result["content"][1]["text"])["files"], 14
        )

    def test_unknown_method(self):
        replies = self._run([self._msg(1, "mystery/method")])
        self.assertEqual(replies[0]["error"]["code"], -32601)

    def test_lone_surrogate_in_method_returns_serializable_protocol_error(self):
        payload = (
            b'{"jsonrpc":"2.0","id":1,"method":"\\ud800"}\n'
            b'{"jsonrpc":"2.0","id":2,"method":"unknown/caf\xc3\xa9"}\n'
        )
        out = io.BytesIO()
        log = io.BytesIO()

        run_stdio(io.BytesIO(payload), out, log, self.cfg)

        output = out.getvalue()
        self.assertIn(b'"message":"Method not found: \\ud800"', output)
        self.assertIn(b'unknown/caf\xc3\xa9', output)
        replies = [json.loads(line) for line in output.decode("utf-8").splitlines()]
        self.assertEqual(replies[0]["id"], 1)
        self.assertEqual(replies[0]["error"]["code"], -32601)
        self.assertEqual(
            replies[0]["error"]["message"], "Method not found: \ud800"
        )
        self.assertEqual(replies[1]["id"], 2)
        self.assertEqual(
            replies[1]["error"]["message"],
            "Method not found: unknown/café",
        )

    def test_malformed_json_returns_parse_error_and_does_not_kill_server(self):
        payload = b'not-json\n{"jsonrpc":"2.0","id":1,"method":"tools/list"}\n'
        out = io.BytesIO()
        log = io.BytesIO()
        run_stdio(io.BytesIO(payload), out, log, self.cfg)
        lines = out.getvalue().decode("utf-8").splitlines()
        self.assertEqual(len(lines), 2)
        parse_error = json.loads(lines[0])
        self.assertIsNone(parse_error["id"])
        self.assertEqual(parse_error["error"]["code"], -32700)
        self.assertEqual(parse_error["error"]["message"], "Parse error")
        self.assertEqual(json.loads(lines[1])["result"]["tools"][0]["name"], "callers")

    def test_ping(self):
        replies = self._run([{"jsonrpc": "2.0", "id": 1, "method": "ping"}])
        self.assertEqual(replies[0]["result"], {})

    def test_invalid_jsonrpc_ids_return_invalid_request(self):
        invalid_ids = (False, [], {}, float("nan"), float("inf"))
        replies = self._run([
            {"jsonrpc": "2.0", "id": request_id, "method": "ping"}
            for request_id in invalid_ids
        ])

        self.assertEqual(len(replies), len(invalid_ids))
        for reply in replies:
            self.assertIsNone(reply["id"])
            self.assertEqual(reply["error"]["code"], -32600)
            self.assertEqual(reply["error"]["message"], "Invalid Request")

    def test_valid_jsonrpc_ids_are_echoed(self):
        valid_ids = (None, "request", 0, 2.5)
        replies = self._run([
            {"jsonrpc": "2.0", "id": request_id, "method": "ping"}
            for request_id in valid_ids
        ])

        self.assertEqual([reply["id"] for reply in replies], list(valid_ids))
        self.assertEqual([reply["result"] for reply in replies], [{}] * 4)

    def test_explicit_falsey_non_object_params_are_invalid(self):
        malformed = (None, [], "", 0, False)
        messages = [
            {"jsonrpc": "2.0", "id": i, "method": "ping", "params": params}
            for i, params in enumerate(malformed, start=1)
        ]

        replies = self._run(messages)

        self.assertEqual(len(replies), len(malformed))
        for reply in replies:
            self.assertEqual(reply["error"]["code"], -32602)
            self.assertEqual(
                reply["error"]["message"], "Invalid params: expected an object"
            )

    def test_missing_jsonrpc_version_returns_invalid_request(self):
        replies = self._run([{"id": 1, "method": "ping"}])
        self.assertEqual(replies[0]["id"], 1)
        self.assertEqual(replies[0]["error"]["code"], -32600)
        self.assertEqual(replies[0]["error"]["message"], "Invalid Request")

    def test_missing_or_non_string_method_returns_invalid_request(self):
        malformed = (None, [], {}, 0, False)
        messages = [
            {"jsonrpc": "2.0", "id": i, "method": method}
            for i, method in enumerate(malformed, start=1)
        ]
        messages.append({"jsonrpc": "2.0", "id": len(messages) + 1})

        replies = self._run(messages)

        self.assertEqual(len(replies), len(messages))
        for reply in replies:
            self.assertEqual(reply["error"]["code"], -32600)
            self.assertEqual(reply["error"]["message"], "Invalid Request")

    def test_deps_tool_works(self):
        """Regression: deps used to crash with a KeyError in its renderer."""
        replies = self._run([self._msg(1, "tools/call", {
            "name": "deps", "arguments": {"module": "pkg.cart"}})])
        result = replies[0]["result"]
        self.assertFalse(result["isError"], result)
        text = result["content"][0]["text"]
        self.assertIn("pkg/__init__.py", text)
        self.assertIn("(external)", text)
        rows = json.loads(result["content"][1]["text"])
        self.assertEqual(len(rows), 2)

    def test_unindexed_project_gets_friendly_error(self):
        """Regression: a fresh root used to surface a raw sqlite error."""
        fresh = Path(self.tmp.name) / "fresh"
        fresh.mkdir()
        (fresh / "a.py").write_text("x = 1\n", encoding="utf-8")
        cfg2 = load_config(root=str(fresh))
        cfg2.engine = "quick"
        msg = self._msg(1, "tools/call", {"name": "overview", "arguments": {}})
        out = io.BytesIO()
        log = io.BytesIO()
        run_stdio(io.BytesIO(json.dumps(msg).encode("utf-8")), out, log, cfg2)
        reply = json.loads(out.getvalue().decode("utf-8"))
        self.assertTrue(reply["result"]["isError"])
        self.assertIn("codegraph index", reply["result"]["content"][0]["text"])

    def test_readonly_query_does_not_initialize_existing_empty_database(self):
        fresh = Path(self.tmp.name) / "empty-db"
        fresh.mkdir()
        cfg2 = load_config(root=str(fresh))
        cfg2.engine = "quick"
        db_path = Path(cfg2.db_path)
        db_path.parent.mkdir(parents=True, exist_ok=True)
        db_path.write_bytes(b"")

        msg = self._msg(1, "tools/call", {"name": "overview", "arguments": {}})
        out = io.BytesIO()
        log = io.BytesIO()
        run_stdio(io.BytesIO(json.dumps(msg).encode("utf-8")), out, log, cfg2)
        reply = json.loads(out.getvalue().decode("utf-8"))

        self.assertTrue(reply["result"]["isError"])
        self.assertIn("codegraph index", reply["result"]["content"][0]["text"])
        self.assertEqual(db_path.read_bytes(), b"")

    @unittest.skipUnless(os.name == "posix", "requires POSIX file permissions")
    def test_readonly_query_opens_index_without_directory_write_access(self):
        from codegraph.server.handlers import ToolContext

        db_path = Path(self.cfg.db_path)
        directory_mode = stat.S_IMODE(db_path.parent.stat().st_mode)
        file_modes = {
            path: stat.S_IMODE(path.stat().st_mode)
            for path in (
                db_path,
                Path(f"{db_path}-wal"),
                Path(f"{db_path}-shm"),
            )
            if path.exists()
        }
        try:
            for sidecar in (Path(f"{db_path}-wal"), Path(f"{db_path}-shm")):
                if sidecar.exists():
                    sidecar.chmod(0o444)
            db_path.chmod(0o444)
            db_path.parent.chmod(0o555)

            replies = self._run([
                self._msg(1, "tools/call", {
                    "name": "overview", "arguments": {},
                })
            ])
            self.assertFalse(replies[0]["result"]["isError"], replies[0])

            store = ToolContext(self.cfg).store()
            try:
                self.assertIsNotNone(store.get_meta("last_indexed"))
                self.assertEqual(
                    store.conn.execute("PRAGMA query_only").fetchone()[0], 1
                )
                with self.assertRaises(sqlite3.OperationalError):
                    store.conn.execute(
                        "INSERT INTO meta(key, value) VALUES('test', 'value')"
                    )
            finally:
                store.close()
        finally:
            db_path.parent.chmod(directory_mode)
            for path, mode in file_modes.items():
                if path.exists():
                    path.chmod(mode)

    def test_readonly_query_does_not_migrate_legacy_index_schema(self):
        from codegraph.server.handlers import ToolContext, ToolError

        db_path = Path(self.cfg.db_path)
        legacy = sqlite3.connect(str(db_path))
        try:
            legacy.execute("ALTER TABLE symbols DROP COLUMN default_export")
        finally:
            legacy.close()

        with self.assertRaisesRegex(ToolError, "index schema is outdated"):
            ToolContext(self.cfg).store()

        legacy = sqlite3.connect(str(db_path))
        try:
            columns = {
                row[1]
                for row in legacy.execute("PRAGMA table_info(symbols)")
            }
        finally:
            legacy.close()
        self.assertNotIn("default_export", columns)

    def test_reindex_invalidates_query_cache(self):
        from codegraph.server.handlers import ToolContext, execute_tool

        ctx = ToolContext(self.cfg)
        value, _ = execute_tool("callers", {"symbol": "pkg.pricing.price"}, ctx)
        self.assertEqual(len(value), 2)  # primed the cache

        target = self.root / "pkg" / "pricing.py"
        target.write_text(
            target.read_text(encoding="utf-8")
            + "\ndef vat(x):\n    return price(x)\n",
            encoding="utf-8",
        )
        execute_tool("reindex", {}, ctx)
        value, _ = execute_tool("callers", {"symbol": "pkg.pricing.price"}, ctx)
        qualnames = [r["qualname"] for r in value]
        self.assertIn("pkg.pricing.vat", qualnames)
        self.assertEqual(len(value), 3)

    def test_reindex_invalidates_query_cache_when_build_fails(self):
        from codegraph.scanner import scan_text as real_scan_text
        from codegraph.server.handlers import ToolContext, execute_tool

        ctx = ToolContext(self.cfg)
        value, _ = execute_tool("callers", {"symbol": "pkg.pricing.price"}, ctx)
        self.assertEqual(len(value), 2)  # prime the cache

        target = self.root / "pkg" / "pricing.py"
        target.write_text(
            target.read_text(encoding="utf-8")
            + "\ndef vat(x):\n    return price(x)\n",
            encoding="utf-8",
        )
        later = self.root / "z_later.py"
        later.write_text("value = 1\n", encoding="utf-8")

        def fail_later(text, lang, rel_path, engine):
            if rel_path == "z_later.py":
                raise RuntimeError("temporary scan failure")
            return real_scan_text(text, lang, rel_path, engine)

        with patch("codegraph.builder.scan_text", side_effect=fail_later):
            with self.assertRaises(RuntimeError):
                execute_tool("reindex", {}, ctx)

        value, _ = execute_tool("callers", {"symbol": "pkg.pricing.price"}, ctx)
        self.assertEqual(value, [])

    def test_output_has_no_embedded_newlines(self):
        replies = self._run([self._msg(1, "tools/list")])
        out = io.BytesIO()
        log = io.BytesIO()
        run_stdio(io.BytesIO(json.dumps(self._msg(1, "tools/list")).encode()), out, log, self.cfg)
        raw = out.getvalue().decode("utf-8")
        self.assertNotIn("\r", raw)
        for line in raw.splitlines():
            self.assertEqual(len(line), len(line.rstrip("\n")))


if __name__ == "__main__":
    unittest.main()
