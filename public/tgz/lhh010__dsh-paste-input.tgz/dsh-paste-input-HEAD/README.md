# dsh-paste-input

**简体中文** | [English](./README.en.md)

DSH WebUI 文件输入增强插件：**Ctrl+V 粘贴** + **全页面拖拽** + **选择文件/文件夹**，发送时复制进会话工作区临时附件目录，并把对话气泡里的附件文本块**折叠为文件 chip**。

派生自 [dsh-external/dsh-multimedia-webui-input](https://github.com/dsh-external/dsh-multimedia-webui-input)（MIT），在其基础上新增剪贴板粘贴输入、首次告知弹窗与气泡附件折叠。

> **你的 DSH 版本决定装哪个插件版本**（装错会崩：常见症状 `useConversation is not a function`）
>
> - DSH **0.1.2-alpha.1 ~ 0.2.1-alpha.1**：装**新版**（下方默认命令；各 DSH 版本对应的插件 tag 见下方变更记录）
> - 更旧的 DSH（0.1.1-rc.2 及以前）：**无可用版本**
>

## 安装（profile 模式）

> **安装方式（v0.2.10 起自动挂载）**：本包自 v0.2.10 起自带 `cordis.patch.yml` 并声明 `dsh.bundle.patch`——`dsh plugin --profile web add` 安装后**自动注册 profile 层并挂载**，不再需要手写 `insert` 配置行（固定旧 tag 的部署仍需）。**GUI 注意**：插件页「添加插件」只接受注册表包名或本地目录路径；`name@github:owner/repo#tag` 是 pnpm 别名规格（CLI 专用），粘进 GUI 会报 `ERR_PNPM_INVALID_PACKAGE_NAME`——GUI 请克隆后用本地目录路径，或等 npm 发布后用包名。


```sh
# 方式一：git 依赖固定 tag（公开镜像，推荐；也可用 github:lhh010/dsh-paste-input）
dsh plugin --profile web add '@dsh-community/dsh-paste-input@github:lhh010/dsh-paste-input#v0.2.11'

# 方式二：本地 link
# dsh plugin --profile web add link:/path/to/dsh-paste-input
```

并在 `~/.dsh/profiles/web/cordis.patch.yml` 追加（热重载，无需重启）：

```yaml
- insert:
    - id: dsh-paste-input
      name: '@dsh-community/dsh-paste-input'
```

> **安装提示**：pnpm 11 首次安装可能拦截 node-pty 等构建脚本——在 `~/.dsh/profiles/web` 下执行 `pnpm approve-builds --all` 放行后重跑安装命令；装完**硬刷新浏览器**（Ctrl/Cmd+Shift+R）。

## 智能版本门控更新提示 / DSH-gated update chip

更新浮标会结合**当前运行的 DSH 版本**（宿主端从 dsh 安装清单读取）与仓库根的 [`compatibility.json`](compatibility.json)（版本→支持的 DSH 列表，精确匹配）判定提示形态：

- 最新版支持当前 DSH → 正常「新版本 vX 可用，点击更新」；
- 最新版需要更高 DSH、但存在支持当前 DSH 的中间新版 → 提示更新到中间版，并注明「另有 vX 需更高 DSH」；
- 最新版需要更高 DSH、且当前 DSH 无任何可用新版 → 琥珀色信息条：「新版本 vX 支持更高 DSH 版本，当前 DSH vY 暂不可用」，不提供直接升级。

兼容数据拉取失败或无该版本条目时，自动回退为旧的普通升级提示（离线安全）。**发版时需同步维护 `compatibility.json`**（与版本表/变更记录同一步骤新增一行）。

### 2026-09-30 · v0.2.6 — 桌面端粘贴上传修复（纯插件侧，零宿主改动）

- **修复（桌面端）**：双管齐下绕过桌面宿主两个缺陷（均只见于 dsh-app:// 桌面端，web 端不受影响；上游跟踪 [discussion #8303](https://github.com/deepseek-ai/deepseek-harness/discussions/8303)）：① 会话解析——`ctx.sessions` 在桌面端插件侧为空，改用 `ctx.get('workspaceRegistry')` 按 sessionIds→workspace.path 服务端解析 cwd（无客户端路径输入，不破坏原安全模型）；② 上传传输——桌面转发层破坏二进制 PUT body（Content-Length 与实际字节不符），桌面端改走 base64 JSON 通道（`POST /batches/<id>/files/<n>/base64`），web 端保留二进制快路径。实机验证：桌面端粘贴→copied→发送成功，文件落盘 ✓。同时移除 v0.2.4/0.2.5 的“桌面端不可用”弹窗（已过时），保留 live-session-not-found toast 作为回归安全网。

- **声明**：dsh 版本支持面与 v0.2.5 相同；双 bundle `node --check` 通过


- **修正**：v0.2.4 弹窗与 toast 中的跟踪链接原指向内测反馈仓（外部不可见），改为公开的 [deepseek-harness discussion #8303](https://github.com/deepseek-ai/deepseek-harness/discussions/8303)。其余与 v0.2.4 相同。

### 2026-09-29 · v0.2.4 — 桌面端防御：粘贴上传不可用时明确提示
### v0.2.4 / v0.2.5（tag 已撤回）

- 中间防御版：在桌面端弹窗提示“粘贴上传不可用”。该结论被 v0.2.6 的插件侧修复推翻（workspaceRegistry 会话解析 + base64 上传通道），误导性提示已随 tag 一并撤回（提交仍在历史中：0a9f131 / 06a02cb）。


- **声明**：dsh 版本支持面与 v0.2.3 相同；双 bundle `node --check` 通过

### 2026-10-08 · v0.2.8 — 修复：中途粘贴新图片时既有附件被误清理

- **根因**：`add()` 在 draft 末尾无空格时调用 `input.setDraft()` 追加空格——但 `setDraft` 替换整个 draft 文本并**销毁所有 chip 的 occurrence 绑定**。用户粘贴 3 张图后打字（draft 末尾非空格），再粘贴第 4 张时 `setDraft` 先行清除了前 3 张的 occurrences，订阅判定 `alive=false`，records 被清理——发送时模型只看到最后一张（磁盘证据：batch 目录只有 `paste_image(4).png`）。
- **修复**：移除 `setDraft` 尾部空格调用（美观不值得销毁 occurrence 绑定）；另为未提交 record 加 150ms `vanishTimer` 宽限期作为纵深防御。
- **已知限制**：新粘贴的附件仍始终插入在文本末尾，不受光标位置影响——不影响正确性。
- 双 bundle `node --check` 通过。

### 2026-10-04 · v0.2.7 — 声明支持 dsh-v0.2.1-alpha.1

- **声明**：支持 dsh-v0.2.1-alpha.1（升级实机验证：web 宿主七插件挂载激活正常，零适配改动；本插件无构建脚本，PLUGIN_VERSION 烙于 lib/client.js 手改）；双 bundle `node --check` 通过

### 2026-09-29 · v0.2.3 — 声明支持 dsh-v0.2.0-rc.2

- **声明**：支持 dsh-v0.2.0-rc.2（升级实机验证：六插件挂载激活正常，零适配改动）；双 bundle `node --check` 通过

### 2026-09-28 · v0.2.2 — 声明支持 dsh-v0.2.0-rc.1

- **声明**：支持 dsh-v0.2.0-rc.1（升级实机验证：六插件挂载激活正常，零适配改动）；双 bundle `node --check` 通过

### 2026-09-28 · v0.2.1 — 声明支持 dsh-v0.1.7-rc.2

- **声明**：支持 dsh-v0.1.7-rc.2（npm 升级实机验证：六插件挂载激活正常，零适配改动）；双 bundle `node --check` 通过

### 2026-09-26 · v0.2.0 — 修复无视觉模型粘贴图片发送失败

- **修复**：粘贴图片时，官方 composer 的粘贴处理器会把同一张剪贴板图片再收进官方附件通道；对不支持看图的模型，发送时该官方附件被模型能力校验拒绝 → 发送失败，本插件的 chip 成为空壳并提示附件不再受支持，只能手动叉掉官方图片才能发送
- **方案**：无视觉模型无法通过图片附件的宿主校验，发送失败时 composer 会把派发时清空的附件**还原**回草稿——插件监测这一还原信号，自动移除图片附件并提示**直接重新发送**（重新发送只携带附件文本块，即可成功）
- **防伪造**：气泡侧附件折叠增加真实性校验——marker 块指向的文件先经插件 `/file` 端点验证（要求真实发送目录的 owner marker 与文件清单声明），伪造/手打的 marker 块不再被折叠成官方样式的文件 chip，防止以假附件文本误导模型或阅读者
- **顺带修复**：全页拖拽路径 `add(sessionId, …)` 的 `sessionId` 未定义（拖拽会以 toast 报错），改为 `current.sessionId`
- **行为说明**：视觉模型同样不再走多模态通道收到图片本体，而是读取工作区中的暂存文件——与无视觉模型一致，且不再出现同一张图片的双重附件

### 2026-09-24 · v0.1.29 — 声明支持 dsh-v0.1.7-rc.1

- **声明**：支持 dsh-v0.1.7-rc.1（零适配改动）；双 bundle `node --check` 通过

### 2026-09-23 · v0.1.28 — 更新浮标加入 DSH 版本门控 + 声明支持 dsh-v0.1.7-alpha.2

- **新功能**：宿主端新增 `/dsh-paste-input/v1/latest` 端点返回当前 DSH 版本；客户端更新判定结合 `compatibility.json`——最新版不支持当前 DSH 时显示琥珀色「需更高 DSH 版本」提示，支持中间版本时提示中间版
- **声明**：支持 dsh-v0.1.7-alpha.2（实机验证）；双 bundle `node --check` 通过

### 2026-09-17 · v0.1.27 — 适配 dsh-v0.1.6-alpha.2

适配 dsh 0.1.6-alpha.2 多实例重构：当前会话改由 `uiSession.current`（`{ key, ctx }`）解析（alpha.1 的 `sessions.list.current` 字段已移除，此前导致粘贴/拖拽/附件按钮全部弹「请先打开一个会话」）；粘贴、拖拽、附件按钮三条路径均已切换，alpha.1 回退保留。lib node --check 全绿，alpha.2 实机验证 chips 恢复显示。

### 2026-09-15 · v0.1.26 — 声明支持 dsh-v0.1.6-alpha.1

声明支持 dsh-v0.1.6-alpha.1（npm 已发布，钉版本实机验证；client 插件面零代码差异，lib node --check 全绿，实机加载正常）。安装命令统一更新为 `#v0.2.11`。

### 2026-09-10 · v0.1.25 — 补充声明 dsh-v0.1.5-rc.2 兼容
- **验证**：rc.2 无 client 插件面变更，无需代码改动；rc.2 实机宿主（tag fb2c4b9e）加载确认，粘贴入框/悬停预览/查看器正常

### 2026-09-10 · v0.1.25 — 声明支持 dsh-v0.1.5-rc.1
- **验证**：rc.1 为 0.1.5 系列首个候选版本，client 插件面零代码差异；npm 已发布，钉版本实机验证；同步 lib 内烙死的 PLUGIN_VERSION 常量

### 2026-09-09 · v0.1.24 — 修复旧格式消息折叠失败
- **修复**：会话历史中存在两种结束标记（现行 `==== END DSH_PASTE_INPUT ====` 与旧缓存 bundle 写入的 `==== END DSH_PASTE_INPUT_V1 ====`），解析器只认后者之外的现行格式导致旧消息折叠失败并刷 Console 警告；现兼容两种拼写。注：V1 结尾拼写为历史遗留（仅极早期 bundle 写入），**后续版本可能不再兼容**，依赖旧格式折叠的历史消息请尽快升级

### 2026-09-09 · v0.1.23 — 声明支持 dsh-v0.1.5-alpha.2
- **验证**：alpha.2 改动为 Sidebar 文档预览、模型文件交付、minimal 默认工具调整与 `fs-ext` 安装修复，client 插件面零代码差异；npm 已发布，钉版本实机验证；同步 lib 内烙死的 PLUGIN_VERSION 常量（避免幻影自更新）
### 2026-09-08 · v0.1.22 — 声明支持 dsh-v0.1.5-alpha.1
- **验证**：0.1.5 改动在会话格式 V3 / `ctx.agent` 移除 / 宿主 client bundle 服务路由改 `/plugins/??` 组合路由，client 插件面零代码差异；npm 已发布，钉版本实机验证，无需代码改动；启动清单确认加载
### 2026-09-05 · v0.1.21 — 声明支持 dsh-v0.1.3-alpha.2

- **验证**：alpha.2 改动全在 pi-ai / Web 顶栏 / 子代理消息 / host 面，client 插件面零代码差异；npm 已发布，钉版本实机验证，无需代码改动

### 2026-09-05 · v0.1.20 — 粘贴记录持久化开关（sessionStorage，默认关）

- **新功能**：标题栏「Profiles」按钮旁新增「📎 记录持久化」开关（默认**关**）。开启后粘贴记录会镜像到 `sessionStorage`——页面刷新后，输入框里残留的粘贴引用 chip 仍可正常发送（此前会报 "Attachment selection is no longer available in this browser tab"）。
- **限额**：单文件 > 1 MiB 不持久化；快照总量上限约 3 MiB，超出自动跳过（大文件场景请关闭或接受部分持久化）。
- 关闭开关即清空已持久化的记录。
- **作用粒度**：持久化按"每次粘贴的记录"逐条生效——粘贴那一刻开关是开且文件不超限才写入；切到「关」清空已有记录；重新开启不回溯补旧记录；已发送的消息不受影响（文件已存宿主侧）。

### 2026-09-04 · v0.1.19 — 声明支持 dsh-v0.1.3-alpha.1

- **验证**：0.1.3 破坏性变更集中在 host/session 侧（SessionHandle / session format v2），composer/输入面实测无影响；npm 未发布，源码宿主实机验证（粘贴入框/悬停预览/查看器正常），无需代码改动

### 2026-09-03 · v0.1.18 — 声明支持 dsh-v0.1.2-rc.1

- **验证**：alpha.5→rc.1 为纯版本号提交（252 文件零代码差异）；实机 rc.1 验证通过（悬停预览/查看器正常），无需代码改动

### 2026-09-03 · v0.1.17 — 图片/动图悬停预览 + 点击查看器（缩放/平移）

- **新功能（悬停缩略图）**：图片类附件（png/jpg/jpeg/gif/webp/bmp/avif/ico）的 chip 悬停即弹出小预览卡，GIF 动图原样播放；输入框待发送 chip（本地字节，blob URL）与气泡内已发送 chip（宿主端按所有权标记校验后回读文件）都支持
- **新功能（点击查看器）**：点击图片 chip 打开全屏查看器——滚轮以光标为中心缩放（20%–800%）、左键拖动上下左右平移、双击在 1×/2× 间切换、`+`/`-`/`0`/`Esc` 快捷键、工具栏含缩放百分比/重置/复制完整路径/关闭；GIF 在查看器中持续播放
- **宿主端新增只读路由** `GET /dsh-paste-input/v1/file?root=<发送目录>&path=<相对路径>`：仅服务**所有权标记（`.dsh-paste-input.json`）声明过的图片文件**（SVG 除外，避免同域脚本执行），路径解析约束在发送目录内，单文件 ≤64 MiB
- 非图片 chip 行为不变（悬停显示原始附件块、点击复制路径）；图片 chip 的「复制路径」移入查看器工具栏
- **修复（dock chip 崩溃，v0.1.16 遗留）**：输入框上方附件 dock 的删除按钮引用了不在本作用域的 `busy` 变量，chip 一渲染即 `ReferenceError`，整个 dock 槽位被错误边界吞掉（表现：dock 上的附件气泡消失）；已移除该悬空引用

### 2026-09-02 · v0.1.16 — 修复 AttachButton 崩溃 + 版本检查 403 改走 jsdelivr

- **修复（AttachButton 崩溃）**：`conversation.input.left` 槽位不提供 owner props（无 `input`），`props.input.phase` 读取 undefined 崩溃（Console 报 `Cannot read properties of undefined (reading 'phase')`，槽位条目被框架错误边界捕获）。改用可选链 + `'plain'` 默认值（`add()` 自身有 phase 守卫不会误操作）。dock 槽位的 `occurrences` 同样加防御
- **修复（403 刷屏）**：版本检查的 tag 源从 `api.github.com`（未认证限流 ~60 req/hr → 403）改为 `data.jsdelivr.com/v1/packages/gh/`（CDN，无限流，CORS 友好）
### 2026-09-02 · v0.1.15 — 声明支持 dsh-v0.1.2-alpha.5

- **验证**：alpha.5 为纯 bug 修复（升级路径问题），client 运行 API 无变更；lib 产物校验通过

### 2026-09-02 · v0.1.14 — 声明支持 dsh-v0.1.2-alpha.4

- **验证**：alpha.4 下 client 运行 API 无破坏性变更（changelog 仅宿主侧 Session events 重构）；lib 产物校验通过

### 2026-09-02 · v0.1.13 — 更新提示词补版本路由与排查指引

- **修复（更新提示词）**：提示词新增第 0 步（先 `dsh --version` 确认本地 DSH 版本，对照 README「版本兼容」表选对应 tag，不匹配则改装）与第 3 步（安装失败/版本不匹配/启动报错先查 README「版本兼容」「已知限制」章节）；原两步安装流程不变
### 2026-09-01 · v0.1.12 — 版本检查增加缓存 / 403 降级

- **修复（反复 403）**：GitHub tags API 在限流/未授权时返回 403，旧代码每次页面加载与点击重试都重新请求一次，console 被 403 刷屏。现按结果缓存到 localStorage：成功结果缓存 10 分钟、瞬时网络失败 60s、硬 403（限流）缓存 5 分钟——窗口内直接返回缓存结论**不再发请求**，手动「重试」仍可强制执行一次
- **降级文案**：区分「网络不可达」与「GitHub 拒绝访问（限流/403）」——后者显示「版本检查暂不可用（GitHub 拒绝访问），已缓存」，不再误导为网络问题
### 2026-09-01 · v0.1.11 — 版本检查 chip 不再被 GitHub CDN 缓存滞后误导

- **修复**：刚 push 新 tag 后的几分钟内，GitHub tags API / raw CDN 仍返回旧 tag，「已是最新版本」chip 会把**旧的远端 tag** 当作最新显示（如运行 0.1.10 却显示「已是最新 0.1.9」）。现取「拉到的 tag 与运行版本」中较新者展示；离线 chip 的重试路径同样处理
### 2026-09-01 · v0.1.10 — 修复 dock 删除失效 + 同名文件自动加序号

- **修复（删除失效 → unavailable）**：DSH 0.1.2-alpha 的输入机里 occurrence 的 offset/length 是 **clipboard 投影坐标**（chip 展开为完整 `[attachment: …]` 文本），而 `consumeToken` 的 span 校验在 **detect 投影坐标**（chip 仅占 1 个 U+FFFC 字符）下工作——旧代码直接把 clipboard 坐标传入导致替换必然失败，record 却已删除：dock chip 显示 unavailable、输入框 chip 残留。现按「前面每个 chip 缩短 length−1」精确换算成 detect 坐标再调用 `consumeToken`，失败时回退 setDraft 整段切除
- **修复（第二次粘贴报错 / 顶掉）**：`insertReference` 的插入点原来取 `snapshot.draft.length`（clipboard 投影长度），第一个附件存在后插入点越界 → `The DSH composer changed before the attachment could be inserted`。现同样按存活 chip 折算成 detect 坐标，多个附件可连续粘贴共存
- **新增（粘贴文件统一重命名）**：粘贴的文件统一改基础名——图片 `paste_image.<ext>`、其他文件 `paste_file.<ext>`（扩展名优先取原文件名，缺省按 MIME 补全）；重名自动追加 `(2)`、`(3)`… 序号（以 composer 实时 chips + records 为冲突集），改名同步进上传路径。**仅粘贴路径改名**，拖拽与文件/文件夹选择保留原始文件名
- **验证**：实机验证通过——连续粘贴两张截图得到 `paste_image.png` 与 `paste_image(2).png` 共存；dock × 删除上下同步；node --check 通过
### 2026-08-20 · v0.1.5 — 声明 DSH 0.1.1-rc.1 兼容性（实机 boot 验证）

- **验证**：DSH npm `0.1.1-rc.1` 实机 boot 验证通过——boot 清单包含本插件、client.js 返回 200；0.1.4 的 rc.8 适配（`consumeToken` 整段删除、`appearance: 'file'` 官方外观、内联 chip 整体编辑保护）在 0.1.1-rc.1 上行为无回归（所依赖的 `inputTriggers.registerSource`、`conversation.input.for` 门面与 `conversation.input.left/dock`、`settings.section` 槽位均保持不变）

### 2026-08-20 · v0.1.4 — DSH 0.1.0-rc.8 适配（删除失效 + 内联 chip 外观）

- **修复（删除失效）**：rc.8 输入机的引用 occurrence 占据 `@` + label 的完整行内区间（不再是 1 个占位符字符），v0.1.3 点击 dock chip 的 × 只删掉 `@` 一个字符，输入框内残留附件文本。现改用 rc.8 官方删除动词 `input.consumeToken`（span CAS 整段切除），旧宿主回退为按 `occurrence.length` 切除
- **新增（整体编辑保护）**：内联附件 chip 的文件名不可单独删改（部分编辑会被拦截并自动选中整个 chip，下一次按键整体删除/替换），见上「内联 chip 整体编辑保护」
- **修复（内联 chip 外观）**：移除自造的 `📎 ` emoji 前缀与 8 字符截断（在 rc.8 上渲染为「蓝色 @ + 回形针 + 蓝色文件名」），label 改为纯文件名并附带官方 `appearance: 'file'`，与官方 `@file` 引用的内联 chip 外观一致；完整路径与大小仍显示在输入框上方的 dock chip 中
- **新增（内联 chip 整体编辑保护）**：输入框内的附件 chip 只能整体删除/替换，不能改写其中的文件名——在 composer textarea 上以捕获阶段拦截 `beforeinput`，任何只触碰 chip 一部分的编辑（在 label 中间打字、退格删一个字符、选半截替换）都被阻止并把选区扩展到整个 chip（下一次按键即整体删除/替换）；已完整选中整个 chip 的删除/替换放行。守卫通过 `textarea.value === draft` 识别 composer，不影响队列编辑等其他输入框；dock 的 × 按钮仍走 `consumeToken` 整段删除
- **验证**：DSH npm `0.1.0-rc.8` 实机验证——粘贴/拖拽 → dock chip → × 删除后输入框同步清空；发送 → 复制进附件目录 → 气泡折叠 chip 全链路可用

### 2026-08-13 · v0.1.3 — 最终快照服务改名迁移（snapshot0812 + npm rc.5）

- **迁移（client）**：`slash` → `inputTriggers`（lib/client.js 4 处：inject 数组 ×2 + `ctx.get` + `registerSource` 调用），`dsh.client` 元数据 inject 由 `@deepseek-ai/dsh-client-ui-slash` 迁移为 `@deepseek-ai/dsh-client-ui-input-trigger`——最终快照将输入触发服务与官方包一并更名，服务与 `registerSource` API 不变
- **迁移（host）**：`httpServer` → `webServer`（lib/index.js 2 处：inject 数组 + `ctx.webServer.register` 调用）——最终快照将 host 侧 HTTP 路由服务更名，`register({ kind: 'prefix', path, handler })` API 不变
- **验证**：DSH 最终快照（`snapshots/20260812T172954Z-final`）与 npm rc.5（`@deepseek-ai/dsh@0.0.1-rc.5`）consumer 实机 boot 验证通过（boot 清单包含本插件、client.js 返回 200、webServer 上传路由加载成功）

### 2026-08-11 · v0.1.2 — 客户端插件元数据迁移（snapshot0810）

- **迁移**：package.json 从顶层 `dshClient` 声明迁移为嵌套 `dsh.client`（inject 原样保留）——0810 的 ClientModuleHostService 只读 `pkg.dsh.client`，旧字段会被静默忽略导致插件不进 boot 图
- **验证**：DSH snapshot0810 实机验证通过（粘贴 → 复制进附件目录 → 气泡折叠 chip 全链路）

### 2026-08-10 · v0.1.1 — 修复气泡折叠 chip 显示位置错乱

- **修复**：发送时若 chip 前后都有输入文字（尤其是多文件发送），折叠后的文件 chip 位置错乱——此前所有用户文字被合并为一个文本块堆在顶部，第一个 chip 因 flex 布局悬浮在首行文字右侧，其余 chip 散落在文本块下方；现按源顺序穿插渲染（文字 → chip → 文字 → chip…），文字段独占一行，相邻附件块的 chip 自动并排
- **修复**：折叠区文字与 chip 对齐气泡内部 16px 文字缩进（去掉此前多余的横向内缩与底部空隙）
- **验证**：DSH snapshot0809 实机验证通过

## 能力

- **Ctrl+V 粘贴**：粘贴截图/复制的图片/文件 → 作为附件加入输入框（首次粘贴弹出告知弹窗，可勾选"不再提示"，选择持久化在浏览器 localStorage）
- **全页面拖拽**：文件/文件夹拖到页面任意位置（聊天区、空白处、输入框）即加入附件；文本/链接拖拽保持浏览器默认行为
- **选择**：输入框左侧回形针按钮 → 选择文件 / 选择文件夹
- **气泡折叠**：发送后，消息气泡里冗长的附件路径文本块（含 `==== DSH_PASTE_INPUT_V1 ====` 标记协议）自动折叠为 📎 文件 chip；你在 chip 前后输入的文字按原顺序穿插保留（多文件发送时文字与各文件的 chip 逐段交错，chip 独占一行），悬停 chip 显示完整原始附件块（路径/清单/文件列表），点击 chip 复制完整路径
- **图片预览**：图片/动图附件（含 GIF）悬停 chip 弹出小预览图（动图原样播放），点击 chip 打开全屏查看器——滚轮缩放（以光标为中心，20%–800%）、拖动平移、双击 1×/2×、`+`/`-`/`0`/`Esc` 快捷键、工具栏可复制完整路径；输入框待发送 chip 与气泡内已发送 chip 均支持（宿主端按所有权标记校验后回读已发送文件）
- 发送时文件复制到 `<会话工作区>/.dsh/tmp/attachments/<session>/<send>/`，绝对路径随消息前置给模型，无权限问题
- 设置面板：附件用量统计与按会话/工作区清理（所有权标记保护，二次确认）

## 与 dsh-vision 协作：截图识别

配合 [dsh-external/dsh-vision](https://github.com/dsh-external/dsh-vision) 插件（注册 `view_image` 工具，桥接任意 OpenAI 兼容 VLM，默认智谱免费 `glm-4.6v-flash`），本插件的粘贴/拖拽截图可以**直接识别**：

1. 截图（Win+Shift+S）→ 粘贴或拖入 DSH
2. 发送后截图复制进工作区附件目录
3. 模型看到附件路径 → 调用 `view_image` → VLM 返回图片内容（OCR 提取文字、读图表、识别 UI 布局等）

两个插件零耦合：本插件负责"文件进对话"，dsh-vision 负责"看图"，通过工作区附件路径衔接。

## 附件消息协议

附件块以显式标记界定（模型可见文本，气泡折叠识别用）：

```
==== DSH_PASTE_INPUT_V1 ====
<附件根目录绝对路径>

Files: N
Manifest: .dsh-paste-input.json
Attached files (paths are relative to the root above):
- "file.txt" (2.0 KiB)
==== END DSH_PASTE_INPUT ====
```

仅支持标记格式（历史无标记消息不折叠）。标记前后各带空行，保证用户输入的文字与标记不在同一行。

## 限制

- 粘贴的文件支持因浏览器而异：**Chrome/Edge** 在 paste 事件中只提供图片（截图、复制的图片）等媒体与文本/HTML，从文件管理器"复制文件"后粘贴不会出现文件项；**Firefox** 支持粘贴文件，但同样**不提供绝对路径**。浏览器出于安全不会把本地文件路径暴露给网页，因此粘贴均以 `文件名` 作为相对路径存储——需要原路径的场景请使用**拖拽**或**选择文件/文件夹**按钮
- 单文件 ≤ 1 GiB、单次 ≤ 2 GiB、≤ 10000 文件、≤ 64 层

## 安装（profile 模式）

```sh
# 方式一：git 依赖固定 tag（公开镜像，推荐；也可用 github:lhh010/dsh-paste-input）
dsh plugin --profile web add '@dsh-community/dsh-paste-input@github:lhh010/dsh-paste-input#v0.2.11'

# 方式二：本地 link
# dsh plugin --profile web add link:/path/to/dsh-paste-input
```

并在 `~/.dsh/profiles/web/cordis.patch.yml` 追加（热重载，无需重启）：

```yaml
- insert:
    - id: dsh-paste-input
      name: '@dsh-community/dsh-paste-input'
```

> **安装提示**：pnpm 11 首次安装可能拦截 node-pty 等构建脚本——在 `~/.dsh/profiles/web` 下执行 `pnpm approve-builds --all` 放行后重跑安装命令；装完**硬刷新浏览器**（Ctrl/Cmd+Shift+R）。

### 提示词安装（让 DSH 自己装）

把下面这段提示词发给任意一个 DSH 会话，模型会替你完成安装：

> 帮我安装 dsh-paste-input 插件（DSH 文件输入增强：粘贴/拖拽文件），步骤：
> 1. 执行 `dsh plugin --profile web add '@dsh-community/dsh-paste-input@github:lhh010/dsh-paste-input#v0.2.11'`（首次可能被 pnpm 11 拦截 node-pty 构建脚本而失败）
> 2. 在 `~/.dsh/profiles/web` 下执行 `pnpm approve-builds --all`（放行构建脚本）
> 3. 再执行一次第 1 步的安装命令
> 4. 完成后在 `~/.dsh/profiles/web/cordis.patch.yml` 追加 - insert 插件行（id: dsh-paste-input，name: '@dsh-community/dsh-paste-input'），并提醒我硬刷新浏览器（Ctrl/Cmd+Shift+R）
> 遇到报错先查 https://github.com/lhh010/dsh-paste-input README 的常见问题/已知限制。

hip 全链路可用；0811 与 0812 最终快照实机 boot 验证通过（见下）。

## 迁移指南（DSH 0.1.1-rc.1 → 0.1.2-alpha.1）

> 兼容 DSH `dsh-v0.1.2-alpha.3`（无构建面，实机验证；纯客户端）

本插件**无需迁移**：运行时仅依赖 `react` 与 `slots` / `conversation` / `sessions` / `inputTriggers` 服务及 `conversation.input.left` / `conversation.input.dock` / `settings.section` 槽位——这些服务与槽位在 0.1.2-alpha.1 全部保留，客户端 API 重构（`@deepseek-ai/dsh-client-runtime` 移除、`ConversationSnapshot` 视图化、`ctx.slots.inject` 注册范式）不触及本插件的自包含 bundle；直接安装最新 tag（`#v0.1.9`）即可。

**npm 发版兼容**：兼容 DSH npm 发版 `@deepseek-ai/dsh@0.1.1-rc.1`（v0.1.5 实机 boot 验证：`dsh --profile web` 启动后 boot 清单包含本插件、`/plugins/@dsh-community/dsh-paste-input/client.js` 返回 200，依赖的 `inputTriggers`/`conversation.input` 门面与四个槽位在 0.1.1-rc.1 上保持不变）与 `@deepseek-ai/dsh@0.1.0-rc.8`（v0.1.4 实机验证，适配要点见下节），同时兼容 `@deepseek-ai/dsh@0.0.1-rc.5`（dist-tag `next`，即最终快照 snapshot0812 的 npm 发版；`npm exec -p @deepseek-ai/dsh@0.0.1-rc.5 -- dsh --profile web --port <port>` 可访问指定版本并启动，lib 生产模式）与 `@deepseek-ai/dsh@0.0.1-rc.2`（snapshot0811 的 npm 发版）。实测（npm rc.5 基线）：`dsh web` 启动后 `window.__DSH_BOOT__` 清单包含 `@dsh-community/dsh-paste-input`（inject: `dsh-client-runtime`/`dsh-client-ui-input-trigger`/`dsh-client-ui-conversation`/`dsh-client-ui-settings`），`/plugins/@dsh-community/dsh-paste-input/client.js` 返回 200；client 半经 `window.__ModuleLoader__.load` 正确注册，host 半的 `webServer` 上传路由在 rc.5 consumer 中加载成功。本插件**无任何 cordis 依赖**（无 peerDependencies；lib 构建产物无 cordis 导入）——0811 的 cordis 更名（`cordis` → `@deepseek-ai/cordis`）与本插件零影响，`npm install` 无需额外参数。

### 0.1.0-rc.8 兼容要点（npm 发版 `@deepseek-ai/dsh@0.1.0-rc.8`，v0.1.4）

- **输入机引用区间变化（修复删除失效）**：rc.8 的输入机把引用 occurrence 的行内区间从单个占位符字符改为完整显示文本（`@` + label，见 `referenceDraftText`）。v0.1.3 的 dock 删除逻辑只切除 1 个字符，点击 × 后 dock chip 消失但输入框内残留 `📎 image.png …` 之类的纯文本。v0.1.4 改用 `input.consumeToken({ kind: 'span', span: { start: occurrence.offset, end: occurrence.offset + occurrence.length, draftRev } })`（rc.8 `SessionInputShell` 的官方删除动词，带 CAS 保护）整段移除；无 `consumeToken` 的旧版本回退为按 `occurrence.length` 切除的 `setDraft`。
- **官方文件外观（修复蓝色 @ + 回形针 + 蓝色文件名）**：rc.8 的 `insertReference` 支持官方 `appearance` 字段（`file`/`folder`/`session`，官方 `@file` 引用源即用 `appearance: 'file'`），composer 内联 chip 由官方样式渲染（隐藏 @ 字形 + 官方文件图标 + 蓝色文件名）。v0.1.3 自造的 `📎 ` emoji 前缀 + 8 字符截断 label 会渲染成「蓝色 @ + 回形针 + 蓝色文件名」，v0.1.4 移除 emoji 前缀，label 改为纯文件名（与官方 @file 引用一致），并附带 `appearance: 'file'`。
- **槽位与服务不变**：`conversation.input.left` / `conversation.input.dock` / `conversation.input.right`（`kind: 'list'`, `scope: 'session'`）与 `settings.section` 在 rc.8 保持声明；`inputTriggers.registerSource`、`conversation.input.for(actx)`（返回带 `state`/`insertReference`/`consumeToken`/`setDraft` 的 facade）、host 侧 `webServer.register` 均不变。气泡折叠（`DSH_PASTE_INPUT_V1` 标记协议）与上传路由不受影响。

### 0809 兼容要点（实机验证）

- **加载机制变化**：0809 重构了客户端插件机制——旧的 `dsh.plugin.json` 清单 + `resolveClientPath`（`packages/plugin/plugin`）已删除，改为 **package.json 的 `dshClient` 声明**（`platform: 'web'`，可选 `inject`/`immediately`）+ `exports["./client"]` 指向构建产物；宿主扫描 loader 条目组成 boot 图，Web 端从 `/plugins/<id>/client.js` 拉取。本插件 package.json 已满足该声明，无需改动。
- 附件消息协议（`==== DSH_PASTE_INPUT_V1 ====` 标记）与 `.dsh/tmp/attachments/<session>/<send>/` 目录逻辑不依赖快照内部实现，0809 实测全链路成功。
- **构建要求**：0809 宿主在激活时校验 `dshClient` 包的构建产物，缺失会抛 `ClientPackageCompositionError` 并**拒绝启动 `dsh web`**——升级快照或改源码后必须重新 `pnpm run build` 再启动，否则浏览器拉到的是旧 `lib/client.js`。

### 0810 兼容要点（snapshot0810）

- **元数据发现变化**：0810 的 ClientModuleHostService 在启动时扫描已加载插件的 package.json，但只读**嵌套 `dsh.client`**（`packages/client/modules/src/index.ts` 的 `resolveMeta`，`pkg.dsh.client`）；顶层 `dshClient` 字段读不到会静默丢出 boot 图——无日志、无报错，"启动顺利但插件全没"。本插件已从顶层 `dshClient` 迁移为嵌套 `dsh.client`（inject 原样保留）；`lib/client.js` 构建产物不变（package.json 不参与编译），symlink 安装改源仓库即生效，无需重装。

### 0811 兼容要点（snapshot0811，实机验证）

- **cordis 更名对本插件零影响**：0811 将 vendored cordis 由 `cordis@4.0.0-rc.7` 更名为 `@deepseek-ai/cordis@4.0.1-rc.1`（官方 client 包随之全部改从 `@deepseek-ai/cordis` 导入）。本插件不导入 cordis（无 peerDependencies、lib 构建产物无 cordis 引用），无需任何迁移。
- **实机 boot 验证**：snapshot0811（`snapshots/20260811T152241Z`）web 启动后 `window.__DSH_BOOT__` 清单包含 `@dsh-community/dsh-paste-input`（inject: `dsh-client-runtime`/`dsh-client-ui-slash`/`dsh-client-ui-conversation`/`dsh-client-ui-settings`），`/plugins/@dsh-community/dsh-paste-input/client.js` 返回 200。本插件使用的槽位 `conversation.input.left`/`conversation.input.dock`（`ui-conversation` 声明）与 `settings.section`（`ui-settings` 声明）在 0811 上保持声明；`slash` 服务与 `window.__ModuleLoader__` 加载协议不变。

### 0812/最终快照 兼容要点（snapshots/20260812T172954Z-final，实机验证）

- **client 服务更名：`slash` → `inputTriggers`**：最终快照将输入触发服务由 `slash` 更名为 `inputTriggers`（随官方包 `@deepseek-ai/dsh-client-ui-slash` → `@deepseek-ai/dsh-client-ui-input-trigger` 一并改名，服务与 `registerSource` API 本身不变）。本插件 `lib/client.js` 已同步迁移 4 处（两个 inject 数组 + `ctx.get` + `registerSource` 调用），`dsh.client` 元数据的 inject 列表同步由 `dsh-client-ui-slash` 迁移为 `dsh-client-ui-input-trigger`。
- **host 服务更名：`httpServer` → `webServer`**：最终快照将 host 侧 HTTP 路由注册服务由 `httpServer` 更名为 `webServer`（`packages/host/webserver` 提供，`register({ kind: 'prefix', path, handler })` API 不变）。本插件 `lib/index.js` 已同步迁移 2 处（inject 数组 + `ctx.webServer.register` 调用），上传路由照常注册。
- **cordis 更名与本插件零影响**：与 0811 相同，本插件不导入 cordis（无 peerDependencies、lib 构建产物无 cordis 引用），`cordis` → `@deepseek-ai/cordis` 更名（npm rc.5 基线上为 `4.0.1-rc.4`）零影响，`npm install` 无需额外参数。
- **实机 boot 验证**：最终快照（`snapshots/20260812T172954Z-final`）web 启动后 `window.__DSH_BOOT__` 清单包含 `@dsh-community/dsh-paste-input`；npm rc.5 consumer `dsh web` 启动后 boot 清单同样包含本插件（inject 已显示 `dsh-client-ui-input-trigger`），`/plugins/@dsh-community/dsh-paste-input/client.js` 返回 200，host 半 `webServer` 上传路由加载成功。本插件使用的槽位 `conversation.input.left`/`conversation.input.dock`（`ui-conversation` 声明）与 `settings.section`（`ui-settings` 声明）在最终快照与 rc.5 上保持声明；`inputTriggers` 服务与 `window.__ModuleLoader__` 加载协议不变。

## 更新记录 / Changelog
### 2026-10-14 · v0.2.11 — 声明支持 dsh-v0.2.1-alpha.3

- 声明支持 dsh-v0.2.1-alpha.3（升级实机验证：web profile `--dump-config` 全插件行加载零错误；运行时只读探测 file-trace mermaid/katex 路由 200、better-sidebar fence 活；宿主保留 webStartup 服务，六插件零适配改动）；双 bundle `node --check` 通过


### 2026-10-13 · v0.2.10 — 自带 bundle 声明：安装即自动挂载

- **修复**：**自带 bundle 声明**：补齐 `cordis.patch.yml` 并声明 `dsh.bundle.patch`——`dsh plugin --profile web add` 装完自动注册并挂载 profile 层，不再需要手写 insert 行（社区反馈「GUI 安装后不生效」的根因）；双 bundle `node --check` 通过


### 2026-10-11 · v0.2.9 — 声明支持 dsh-v0.2.1-alpha.2

- **声明**：支持 dsh-v0.2.1-alpha.2（升级实机验证：web profile `--dump-config` 全插件行加载、peer 校验零错误；宿主启动监听正常；零适配改动）；双 bundle `node --check` 通过

