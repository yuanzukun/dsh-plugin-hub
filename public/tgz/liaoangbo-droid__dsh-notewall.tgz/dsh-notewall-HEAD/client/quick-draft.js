/**
 * 会话内快速草稿。
 *
 * 入口挂在 `conversation.session.header.utilities` —— 就是会话标题栏右上那排工具按钮，
 * 这个插槽由内核 @deepseek-ai/dsh-client-ui-conversation 提供，不需要 any 外部插件。
 *
 * 面板是自己画的右侧抽屉，不占用 `sidebar.right.pane.tab`：
 * 那个插槽 better-sidebar 也在用，两边抢同一个右栏会互相顶掉；
 * 自绘抽屉可以和它同时开着，互不干扰。
 */
import { useCallback, useEffect, useRef, useState } from 'react';
import { api } from './api.js';
import { NoteEditor } from './editor.js';
import { DeliverDialog } from './deliver';
import { deliverBridge } from './bridge.js';
import { t } from './strings.js';

// 和编辑器面板同宽：NoteEditor 内部写死 520，抽屉比它窄会横向溢出。
/** 草稿 tab 的类型名：注册 tab 类型、开 tab、注册面板都用它。 */
export const DRAFT_KIND = 'sticky-wall-draft';

const PANEL_W = 560;

const chipStyle = {
  border: 'none',
  background: 'rgba(127,127,127,.12)',
  color: 'inherit',
  borderRadius: 7,
  padding: '4px 9px',
  fontSize: 12,
  cursor: 'pointer',
};

export function QuickDraftButton(props) {
  // 右栏版走内核 sidebarRight 时，由 slot 的 inject 把 openDraft 传进来；
  // 拿不到就退回自绘抽屉（当前可用形态），保证功能不会因为改造而消失。
  const openDraft = props?.inject?.openDraft;
  const external = typeof openDraft === 'function';

  const [open, setOpen] = useState(false);
  const [note, setNote] = useState(null);
  const [notes, setNotes] = useState([]);
  const [loading, setLoading] = useState(false);
  const [busy, setBusy] = useState(false);
  const [deliverTarget, setDeliverTarget] = useState(null);

  const listSessions = deliverBridge.listSessions;
  const insertToSession = deliverBridge.insertToSession;
  const scheduleToSession = deliverBridge.scheduleToSession;
  const canDeliver = typeof listSessions === 'function'
    && typeof insertToSession === 'function'
    && typeof scheduleToSession === 'function';

  const openDeliver = useCallback(
    async (target) => {
      if (target === null || target === undefined) return;
      setDeliverTarget({ note: target, sessions: [], busy: false, error: '', initialSessionId: '' });
      try {
        const list = (await listSessions()) ?? [];
        setDeliverTarget((prev) =>
          prev !== null && prev.note.id === target.id ? { ...prev, sessions: list } : prev,
        );
      } catch (err) {
        setDeliverTarget((prev) =>
          prev !== null && prev.note.id === target.id
            ? { ...prev, error: String(err?.message ?? err) }
            : prev,
        );
      }
    },
    [listSessions],
  );

  const runDeliver = useCallback(async (payload, fn) => {
    setDeliverTarget((prev) => (prev === null ? prev : { ...prev, busy: true, error: '' }));
    try {
      await fn(payload);
      // 发送成功后：收起选择会话的弹窗，并关掉正在编辑的便签浮窗。
      // loadNotes 声明在本组件靠后的位置，这里按运行时绑定取用（依赖数组不加它，避免 TDZ）。
      setDeliverTarget(null);
      setNote(null);
      void loadNotes();
    } catch (err) {
      setDeliverTarget((prev) =>
        prev !== null && prev.note.id === payload.note.id
          ? { ...prev, busy: false, error: String(err?.message ?? err) }
          : prev,
      );
    }
  }, []);


  const [error, setError] = useState('');
  const aliveRef = useRef(true);

  useEffect(() => () => { aliveRef.current = false; }, []);

  const createDraft = useCallback(async () => {
    if (busy) return;
    setBusy(true);
    setError('');
    try {
      // 空白便签：留空 title，交给编辑器里的时间戳标题逻辑。
      const result = await api.note({ op: 'create', text: '' });
      const created = result?.note ?? null;
      if (!aliveRef.current) return;
      if (created) { setNote(created); setOpen(false); }
      else setError(t('draft.createFailed'));
    } catch (err) {
      if (aliveRef.current) setError(err?.message ?? String(err));
    } finally {
      if (aliveRef.current) setBusy(false);
    }
  }, [busy]);

  const saveDraft = useCallback(
    async (patch) => {
      const id = note?.id;
      if (!id) return;
      try {
        await api.note({ op: 'update', id, ...patch });
      } catch {
        // 编辑器自己带防抖与重试，这里失败不打断输入。
      }
    },
    [note],
  );

  // 打开抽屉时把墙上的便签读出来，让用户直接挑一张接着写，而不是面对空白。
  const loadNotes = useCallback(async () => {
    setLoading(true);
    try {
      const result = await api.state();
      if (!aliveRef.current) return;
      const list = Array.isArray(result?.doc?.notes) ? result.doc.notes : [];
      setNotes(list);
    } catch (err) {
      if (aliveRef.current) setError(err?.message ?? String(err));
    } finally {
      if (aliveRef.current) setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (open) void loadNotes();
  }, [open, loadNotes]);

  useEffect(() => {
    if (!open) return undefined;
    const onKey = (event) => {
      if (event.key === 'Escape') setOpen(false);
    };
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [open]);

  return (
    <>
      <button
        type="button"
        title={t('draft.button')}
        aria-label={t('draft.button')}
        aria-pressed={open}
        onClick={() => {
          if (!external) {
            if (note) { setNote(null); void loadNotes(); setOpen(false); } else setOpen((value) => !value);
            return;
          }
          try {
            openDraft();
          } catch {
            // openTab 不可用（内核版本差异/未注册 kind）时静默失败，不打断会话
          }
        }}
        style={{
          display: 'inline-flex',
          alignItems: 'center',
          justifyContent: 'center',
          width: 28,
          height: 28,
          borderRadius: 8,
          border: 'none',
          background: open ? 'rgba(77,107,254,.14)' : 'transparent',
          color: 'inherit',
          cursor: 'pointer',
          fontSize: 15,
          lineHeight: 1,
        }}
      >
        <span aria-hidden="true">📝</span>
      </button>

      {!external && open ? (
        <aside
          role="dialog"
          aria-label={t('draft.title')}
          style={{
            position: 'fixed',
            top: 0,
            right: 0,
            bottom: 0,
            width: PANEL_W,
            maxWidth: '94vw',
            zIndex: 1250,
            display: 'flex',
            flexDirection: 'column',
            background: 'var(--dsh-bg-elevated, #ffffff)',
            color: 'var(--dsh-text-primary, #1f2430)',
            borderLeft: '1px solid var(--dsh-border, rgba(128,140,160,.24))',
            boxShadow: '-18px 0 48px rgba(15,23,42,.18)',
          }}
        >
          <div
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: 8,
              padding: '8px 12px',
              borderBottom: '1px solid var(--dsh-border, rgba(128,140,160,.18))',
              flexShrink: 0,
            }}
          >
            <strong style={{ fontSize: 13, flex: 1 }}>{t('draft.title')}</strong>
            <button type="button" onClick={createDraft} disabled={busy} style={chipStyle}>
              {busy ? '…' : t('draft.new')}
            </button>
            <button
              type="button"
              onClick={() => setOpen(false)}
              aria-label={t('draft.close')}
              style={{ ...chipStyle, fontSize: 15, lineHeight: 1, padding: '2px 8px' }}
            >
              ×
            </button>
          </div>

          <div style={{ flex: 1, minHeight: 0, overflow: 'auto', padding: 10 }}>
            {error ? (
              <div style={{ fontSize: 12, color: '#c0392b', marginBottom: 8 }}>{error}</div>
            ) : null}

            {note ? (
              <NoteEditor
                note={note}
                onClose={() => { setNote(null); void loadNotes(); }}
                onChange={saveDraft}
              />
            ) : loading ? (
              <div style={hintStyle}>{t('draft.loading')}</div>
            ) : notes.length === 0 ? (
              <div style={hintStyle}>{t('draft.empty')}</div>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                <div style={{ ...hintStyle, marginBottom: 2 }}>{t('draft.pick')}</div>
                {notes.map((item) => (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => { setNote(item); setOpen(false); }}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: 10,
                      textAlign: 'left',
                      padding: '9px 10px',
                      borderRadius: 9,
                      border: '1px solid var(--dsh-border, rgba(128,140,160,.2))',
                      background: item.color || 'transparent',
                      color: 'inherit',
                      cursor: 'pointer',
                      fontSize: 12,
                      fontFamily: 'inherit',
                    }}
                  >
                    <span
                      style={{
                        flex: 1,
                        minWidth: 0,
                        overflow: 'hidden',
                        textOverflow: 'ellipsis',
                        whiteSpace: 'nowrap',
                      }}
                    >
                      {plainText(item) || t('draft.untitled')}
                    </span>
                    <span style={{ opacity: 0.55, fontSize: 11, flexShrink: 0 }}>
                      {t('draft.edit')}
                    </span>
                  </button>
                ))}
              </div>
            )}
          </div>
        </aside>
      ) : null}
      {!external && note ? (
        <FloatEditor
          note={note}
          onDeliver={canDeliver ? openDeliver : undefined}
          onChange={saveDraft}
          onClose={() => { setNote(null); void loadNotes(); }}
        />
      ) : null}
      {deliverTarget !== null ? (
        <DeliverDialog
          note={deliverTarget.note}
          sessions={deliverTarget.sessions}
          busy={deliverTarget.busy}
          error={deliverTarget.error}
          initialSessionId={deliverTarget.initialSessionId}
          onClose={() => setDeliverTarget(null)}
          onInsert={({ note: target, session }) =>
            runDeliver({ note: target, session }, insertToSession)
          }
          onSchedule={({ note: target, session, at }) =>
            runDeliver({ note: target, session, at }, scheduleToSession)
          }
        />
      ) : null}
    </>
  );
}

/**
 * 右栏里的草稿面板：列出墙上的便签，也能就地新建一张。
 *
 * 它是 slot `sidebar.right.pane.tab` 的 body —— 内核右栏是布局里真实的一栏，
 * 内容占进来之后会话正文会被推挤让位，这正是自绘浮层做不到的地方。
 */
const FLOAT_W = 540;

function clamp(value, min, max) {
  return Math.min(Math.max(value, min), max);
}

function defaultFloatPos() {
  if (typeof window === 'undefined') return { x: 160, y: 80 };
  return {
    x: Math.max(12, Math.round((window.innerWidth - FLOAT_W) / 2)),
    y: Math.max(12, Math.round((window.innerHeight - 620) / 2)),
  };
}

/**
 * 可拖动的浮动编辑窗口。
 *
 * 抓手放在编辑器标题栏中间那段空白里（左侧是标题、右侧是按钮组，中间本来就空着），
 * 既醒目又不遮任何控件。拖动同时挂 mouse 与 touch —— 极空间这类内置 WebView
 * 内核偏旧，只挂 pointerdown 会完全没有反应。
 */
export function FloatEditor({ note, onChange, onClose, onDeliver }) {
  const [pos, setPos] = useState(defaultFloatPos);
  const draggingRef = useRef(false);

  const beginDrag = useCallback((event) => {
    const point = (event.touches && event.touches[0])
      || (event.changedTouches && event.changedTouches[0])
      || event;
    if (point === undefined || typeof point.clientX !== 'number') return;
    if (event.button !== undefined && event.button !== 0) return;

    event.preventDefault();
    event.stopPropagation();
    draggingRef.current = true;

    const startX = point.clientX;
    const startY = point.clientY;
    const base = pos;

    const onMove = (moveEvent) => {
      if (!draggingRef.current) return;
      const moved = (moveEvent.touches && moveEvent.touches[0])
        || (moveEvent.changedTouches && moveEvent.changedTouches[0])
        || moveEvent;
      if (moved === undefined || typeof moved.clientX !== 'number') return;
      if (moveEvent.cancelable) moveEvent.preventDefault();

      const maxX = Math.max(0, window.innerWidth - 140);
      const maxY = Math.max(0, window.innerHeight - 70);
      setPos({
        x: clamp(base.x + moved.clientX - startX, 0, maxX),
        y: clamp(base.y + moved.clientY - startY, 0, maxY),
      });
    };

    const onUp = () => {
      draggingRef.current = false;
      document.removeEventListener('mousemove', onMove);
      document.removeEventListener('mouseup', onUp);
      document.removeEventListener('touchmove', onMove);
      document.removeEventListener('touchend', onUp);
      document.removeEventListener('touchcancel', onUp);
    };

    document.addEventListener('mousemove', onMove);
    document.addEventListener('mouseup', onUp);
    document.addEventListener('touchmove', onMove, { passive: false });
    document.addEventListener('touchend', onUp);
    document.addEventListener('touchcancel', onUp);
  }, [pos]);

  return (
    <div
      style={{
        position: 'fixed',
        left: pos.x,
        top: pos.y,
        zIndex: 60,
        borderRadius: 16,
        boxShadow: '0 18px 48px rgba(8, 12, 24, .28)',
      }}
    >
      <div
        onMouseDown={beginDrag}
        onTouchStart={beginDrag}
        title={t('draft.drag')}
        style={{
          position: 'absolute',
          top: 7,
          left: '50%',
          transform: 'translateX(-50%)',
          height: 28,
          padding: '0 10px',
          zIndex: 5,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          gap: 7,
          cursor: 'move',
          userSelect: 'none',
          WebkitUserSelect: 'none',
          borderRadius: 8,
          border: '1px dashed rgba(128, 140, 160, .5)',
          background: 'rgba(128, 140, 160, .10)',
          color: 'inherit',
          fontSize: 11,
          lineHeight: 1,
          opacity: 0.85,
          whiteSpace: 'nowrap',
        }}
      >
        <span aria-hidden="true" style={{ letterSpacing: 1 }}>⠿⠿</span>
        <span>{t('draft.drag')}</span>
        <span aria-hidden="true" style={{ letterSpacing: 1 }}>⠿⠿</span>
      </div>
      <NoteEditor note={note} onChange={onChange} onClose={onClose} onDeliver={onDeliver} />
    </div>
  );
}

export function DraftPane() {
  const [note, setNote] = useState(null);
  const [notes, setNotes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const aliveRef = useRef(true);

  useEffect(() => () => { aliveRef.current = false; }, []);

  const loadNotes = useCallback(async () => {
    setLoading(true);
    try {
      const result = await api.state();
      if (!aliveRef.current) return;
      setNotes(Array.isArray(result?.doc?.notes) ? result.doc.notes : []);
    } catch (err) {
      if (aliveRef.current) setError(err?.message ?? String(err));
    } finally {
      if (aliveRef.current) setLoading(false);
    }
  }, []);

  useEffect(() => { void loadNotes(); }, [loadNotes]);

  const createDraft = useCallback(async () => {
    if (busy) return;
    setBusy(true);
    setError('');
    try {
      const result = await api.note({ op: 'create', text: '' });
      if (!aliveRef.current) return;
      const created = result?.note ?? null;
      if (created) setNote(created);
      else setError(t('draft.createFailed'));
    } catch (err) {
      if (aliveRef.current) setError(err?.message ?? String(err));
    } finally {
      if (aliveRef.current) setBusy(false);
    }
  }, [busy]);

  const saveDraft = useCallback(
    async (patch) => {
      const id = note?.id;
      if (!id) return;
      try {
        await api.note({ op: 'update', id, ...patch });
      } catch {
        // 编辑器自带防抖与重试，这里失败不打断输入。
      }
    },
    [note],
  );

  const chip = {
    border: 'none',
    background: 'rgba(127,127,127,.12)',
    color: 'inherit',
    borderRadius: 7,
    padding: '4px 9px',
    fontSize: 12,
    cursor: 'pointer',
    fontFamily: 'inherit',
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', minHeight: 0 }}>
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          gap: 8,
          padding: '6px 10px',
          borderBottom: '1px solid var(--dsh-border, rgba(128,140,160,.18))',
          flexShrink: 0,
        }}
      >
        <strong style={{ fontSize: 12, flex: 1 }}>{t('draft.title')}</strong>
        <button type="button" onClick={createDraft} disabled={busy} style={chip}>
          {busy ? '…' : t('draft.new')}
        </button>
        {note ? (
          <button type="button" onClick={() => { setNote(null); void loadNotes(); }} style={chip}>
            {t('draft.back')}
          </button>
        ) : null}
      </div>

      <div style={{ flex: 1, minHeight: 0, overflow: 'auto', padding: 10 }}>
        {error ? (
          <div style={{ fontSize: 12, color: '#c0392b', marginBottom: 8 }}>{error}</div>
        ) : null}

        {note ? (
          <NoteEditor note={note} onClose={() => { setNote(null); void loadNotes(); }} onChange={saveDraft} />
        ) : loading ? (
          <div style={hintStyle}>{t('draft.loading')}</div>
        ) : notes.length === 0 ? (
          <div style={hintStyle}>{t('draft.empty')}</div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
            <div style={{ ...hintStyle, marginBottom: 2 }}>{t('draft.pick')}</div>
            {notes.map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => setNote(item)}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: 10,
                  textAlign: 'left',
                  padding: '9px 10px',
                  borderRadius: 9,
                  border: '1px solid var(--dsh-border, rgba(128,140,160,.2))',
                  background: item.color || 'transparent',
                  color: 'inherit',
                  cursor: 'pointer',
                  fontSize: 12,
                  fontFamily: 'inherit',
                }}
              >
                <span
                  style={{
                    flex: 1,
                    minWidth: 0,
                    overflow: 'hidden',
                    textOverflow: 'ellipsis',
                    whiteSpace: 'nowrap',
                  }}
                >
                  {plainText(item) || t('draft.untitled')}
                </span>
                <span style={{ opacity: 0.55, fontSize: 11, flexShrink: 0 }}>
                  {t('draft.edit')}
                </span>
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

const hintStyle = { fontSize: 12, opacity: 0.66, lineHeight: 1.8 };


/** 列表里只需要一眼能认出来的纯文本标题，不渲染富文本。 */
function plainText(item) {
  const html = typeof item?.html === 'string' ? item.html : '';
  const text = html
    .replace(/<[^>]*>/g, ' ')
    .replace(/&nbsp;/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
  return text.slice(0, 60);
}

export default QuickDraftButton;
