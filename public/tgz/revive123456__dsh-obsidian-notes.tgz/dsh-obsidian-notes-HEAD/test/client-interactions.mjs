/**
 * client 交互 + 数据层测试（无真实 React/浏览器）：
 *  - 有状态钩子桩 + 微渲染器（函数组件展开），驱动真实 onClick / onChange
 *  - fetch mock（/obsidian/* 路由表，记录调用），覆盖 TreeView/Dock 全链路
 *  - window/document/navigator 桩：prompt/confirm、剪贴板、对话输入框注入
 */
import { readFileSync } from "node:fs";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const code = readFileSync(join(root, "lib", "client.js"), "utf8");

// ── 断言工具 ────────────────────────────────────────────────────────────────
const failures = [];
function check(name, cond, extra = "") {
  console.log(`${cond ? "✓" : "✗"} ${name}${extra ? ` — ${extra}` : ""}`);
  if (!cond) failures.push(name);
}

// ── window / document / navigator / fetch 桩 ────────────────────────────────
const timers = [];
const confirmCalls = [];
let confirmResult = true;
// 对话输入框桩：DSH 0.1.x 是 textarea；0.2+ 是 Lexical contenteditable
// （div[data-input-scroll] > [data-composer-input]）。两种都要覆盖，
// 否则「只认 textarea → 提示未找到对话输入框」这类回归测不出来。
const composer = {
  value: "",
  disabled: false,
  readOnly: false,
  events: [],
  setSelectionRange() { },
  focus() { },
  dispatchEvent(e) { composer.events.push(e.type); },
};
const composerEditor = {
  textContent: "",
  isContentEditable: true,
  events: [],
  focusCount: 0,
  focus() { composerEditor.focusCount++; },
  getAttribute: (name) => (name === "contenteditable" ? "true" : null),
  dispatchEvent(e) {
    composerEditor.events.push(e.type);
    // 模拟 Lexical：合成 beforeinput 才会走编辑器自己的插入事务。
    if (beforeInputApplies && e && e.type === "beforeinput" && e.inputType === "insertText" && typeof e.data === "string") {
      composerEditor.textContent += e.data;
    }
    return true;
  },
};
let composerAvailable = true;
let composerKind = "textarea";     // "textarea" | "editable"
let execCommandResult = true;      // document.execCommand("insertText") 的返回
let beforeInputApplies = true;     // 合成 beforeinput 后编辑器是否真的改了文本
const clipboardWrites = [];
let registration = null;
const fakeWindow = {
  __ModuleLoader__: { load: (reg) => { registration = reg; } },
  setTimeout: (fn) => { timers.push(fn); return timers.length; },
  clearTimeout: (id) => { if (id) timers[id - 1] = null; },
  setInterval: () => 0,
  clearInterval: () => { },
  getSelection: () => ({ removeAllRanges() { }, addRange() { } }),
  InputEvent: class { constructor(type, init) { this.type = type; Object.assign(this, init ?? {}); } },
  // Electron（桌面版）把 window.prompt 实现成直接抛错；桩必须一致，
  // 否则「桌面版点 ✎/＋/📁/📋 直接抛异常」这类 bug 测不出来。
  prompt: () => { throw new Error("prompt() is not supported."); },
  confirm: (msg) => { confirmCalls.push(msg); return confirmResult; },
  HTMLTextAreaElement: { prototype: { value: undefined } },
};
globalThis.localStorage = {
  store: new Map([["dsh-obsidian:notesOpen", "1"]]),
  getItem(k) { return this.store.has(k) ? this.store.get(k) : null; },
  setItem(k, v) { this.store.set(k, String(v)); },
  removeItem(k) { this.store.delete(k); },
};
globalThis.document = {
  querySelector: (sel) => {
    if (sel.includes("data-plugin-css")) return null;
    if (sel === "div[data-input-scroll]") {
      if (!composerAvailable) return null;
      if (composerKind === "editable") {
        return { querySelector: (s) => (s === "textarea" ? null : composerEditor) };
      }
      return { querySelector: () => composer };
    }
    return null;
  },
  createElement: () => ({ dataset: {} }),
  createRange: () => ({ selectNodeContents() { }, collapse() { } }),
  execCommand: (cmd, _ui, text) => {
    if (cmd !== "insertText" || !execCommandResult) return false;
    composerEditor.textContent += text;
    return true;
  },
  head: { appendChild: () => { } },
  body: { classList: { add() { }, remove() { } } },
};
Object.defineProperty(globalThis, "navigator", {
  value: { clipboard: { writeText: async (t) => { clipboardWrites.push(t); } } },
  configurable: true,
});
globalThis.setTimeout = (fn) => { timers.push(fn); return timers.length; };
globalThis.clearTimeout = () => { };
globalThis.setInterval = () => 0;
globalThis.clearInterval = () => { };

function flushTimers() {
  const pending = [...timers];
  timers.length = 0;
  for (const fn of pending) if (fn) fn();
}
async function settle(n = 4) {
  for (let i = 0; i < n; i++) await new Promise((r) => setImmediate(r));
}

// ── fetch mock：/obsidian/* 路由表 ──────────────────────────────────────────
const fetchCalls = [];
let vault = { root: "D:\\vault", exists: true };
// 最近一次 /obsidian/session-delete 的返回（模拟 host 全部命中）
let deletedIds = [];
// 模拟「删掉的会话仍被 DSH 进程持有内存副本」：host 会在 attached 里回执这些 id
let attachedOnDelete = [];
// 非空时 /obsidian/session-delete 固定 409：host 权威判定这些 id 还在跑
let deleteRouteRunning = [];
// 非 null 时该路由固定返回该状态码（模拟 host 未重启 → 404）
let deleteRouteStatus = null;
// 这些 id 由 host 报成 missing（磁盘上本就没有日志：本插件更早版本 / 别的客户端删过）
let deleteRouteMissing = [];
// /obsidian/session-state（只读僵死行探测）的桩：
//   sessionStateAvailable=false 模拟 host 没有该路由 / 服务缺失
//   sessionStateStale 里的 id 表示「磁盘上已无 durable 日志」（只剩内存副本）
//   sessionStateRunning 里的 id 表示 Host 判定仍在运行（绝不能隐藏）
let sessionStateAvailable = true;
let sessionStateStale = new Set();
let sessionStateRunning = new Set();
let sessionStateCalls = 0;
const vaultFiles = {
  "": [
    { name: "sub", type: "dir", size: 0, mtimeMs: 1 },
    { name: "a.md", type: "note", size: 633, mtimeMs: 1 },
    { name: "b.md", type: "note", size: 1536, mtimeMs: 1 },
    { name: "c.md", type: "note", size: 2621440, mtimeMs: 1 },
  ],
  sub: [{ name: "deep.md", type: "note", size: 20, mtimeMs: 2 }],
};
const noteContent = {
  "a.md": { content: "# Hello\n\nWorld [[双链目标]]", mtimeMs: 1, size: 633 },
  "sub/deep.md": { content: "# Deep\n\n终端笔记", mtimeMs: 2, size: 20 },
};
const searchResults = {
  "gpu": [{ path: "a.md", name: "a.md", snippet: "…gpu 内容…" }],
  "双链目标": [{ path: "sub/deep.md", name: "deep.md", snippet: "" }],
};

function jsonResponse(obj, status = 200) {
  return { ok: status >= 200 && status < 300, status, json: async () => obj };
}
globalThis.fetch = async (url, init = {}) => {
  const u = new URL(url, "http://x");
  const method = (init.method ?? "GET").toUpperCase();
  let body;
  try { body = init.body ? JSON.parse(init.body) : undefined; } catch { body = undefined; }
  fetchCalls.push({ method, path: u.pathname, search: u.search, body });
  if (u.pathname === "/obsidian/root") {
    if (method === "POST") {
      vault = { root: body.root, exists: true };
      return jsonResponse({ root: vault.root, exists: true });
    }
    return jsonResponse({ root: vault.root, exists: vault.exists });
  }
  if (u.pathname === "/obsidian/tree") {
    const p = decodeURIComponent(u.searchParams.get("path") ?? "");
    return jsonResponse({ path: p, entries: vaultFiles[p] ?? [] });
  }
  if (u.pathname === "/obsidian/note") {
    if (method === "POST") {
      noteContent[body.path] = { content: body.content, mtimeMs: Date.now(), size: body.content.length };
      return jsonResponse({ ok: true });
    }
    const p = u.searchParams.get("path");
    const stored = noteContent[p];
    if (!stored) return jsonResponse({ error: "note not found" }, 404);
    return jsonResponse({ path: p, name: p.split("/").pop(), content: stored.content, frontmatter: {}, links: [], size: stored.size, mtimeMs: stored.mtimeMs });
  }
  if (u.pathname === "/obsidian/file") {
    if (body.action === "new") return jsonResponse({ ok: true, path: body.path === "" ? `${body.name}.md` : `${body.path}/${body.name}.md` });
    if (body.action === "mkdir") return jsonResponse({ ok: true, path: body.path === "" ? body.name : `${body.path}/${body.name}` });
    if (body.action === "rename") {
      const target = `${body.newName}.md`;
      noteContent[target] = { content: "# 改名后\n", mtimeMs: Date.now(), size: 12 };
      return jsonResponse({ ok: true, name: target });
    }
    if (body.action === "delete") return jsonResponse({ ok: true });
  }
  if (u.pathname === "/obsidian/session-delete") {
    // 可切换成 404：模拟 host 未重启（旧进程没有这条路由）
    if (deleteRouteStatus !== null) {
      return jsonResponse({ error: "unknown action session-delete" }, deleteRouteStatus);
    }
    // 非空时固定 409：模拟 host 权威判定「还有会话在跑」
    if (deleteRouteRunning.length > 0) {
      return jsonResponse(
        { error: "session is running", running: deleteRouteRunning, unknown: [], deleted: [] },
        409,
      );
    }
    // host 侧真删除：模拟「全部命中且删后校验通过」，只回 explicit 的 id；
    // deleteRouteMissing 里的 id 走 missing（磁盘上本来就没有日志）。
    const requested = [...(body.ids ?? [])];
    deletedIds = requested.filter((id) => !deleteRouteMissing.includes(id));
    return jsonResponse({
      deleted: deletedIds,
      missing: requested.filter((id) => deleteRouteMissing.includes(id)),
      failed: [],
      attached: attachedOnDelete,
      cacheResidue: [],
      verified: true,
      root: "/home/.dsh/sessions",
    });
  }
  if (u.pathname === "/obsidian/session-state") {
    sessionStateCalls++;
    if (!sessionStateAvailable) return jsonResponse({ available: false, items: [] });
    const ids = body && Array.isArray(body.ids) ? body.ids : [];
    return jsonResponse({
      available: true,
      items: ids.map((id) => ({
        id,
        known: true,
        persisted: !sessionStateStale.has(id),
        live: true,
        running: sessionStateRunning.has(id),
      })),
    });
  }
  if (u.pathname === "/obsidian/search") {
    const q = u.searchParams.get("q") ?? "";
    return jsonResponse({ results: searchResults[q] ?? [] });
  }
  return jsonResponse({ error: `no route ${url}` }, 404);
};

// ── 有状态钩子桩 + 微渲染器 ─────────────────────────────────────────────────
const Fragment = Symbol.for("react.fragment");
function createElement(type, props, ...children) {
  return { type, props: { ...(props ?? {}), children: children.length > 1 ? children : children[0] } };
}
const scopes = new Map();      // fn → { id, hooks }
const effectEntries = new Map(); // `${scopeId}:${slot}` → { fn, deps, lastDeps, cleanup }
let scopeSeq = 0;

function depsChanged(prev, next) {
  if (prev === undefined) return true;
  if (!Array.isArray(prev) || !Array.isArray(next) || prev.length !== next.length) return true;
  return prev.some((v, i) => v !== next[i]);
}
let activeFn = null;
const hook = (init) => {
  const s = scopes.get(activeFn);
  const i = s.cursor++;
  if (s.hooks[i] === undefined) s.hooks[i] = {};
  return { s, h: s.hooks[i] };
};
const stubReact = {
  Fragment,
  createElement,
  useState(init) {
    const { h } = hook();
    if (!("value" in h)) h.value = typeof init === "function" ? init() : init;
    return [h.value, (v) => { h.value = typeof v === "function" ? v(h.value) : v; }];
  },
  useEffect(fn, deps) {
    const { s } = hook();
    const key = `${s.id}:${s.cursor - 1}`;
    const prev = effectEntries.get(key);
    effectEntries.set(key, { fn, deps, lastDeps: prev?.lastDeps, cleanup: prev?.cleanup });
  },
  useRef(init) {
    const { h } = hook();
    if (!("ref" in h)) h.ref = { current: init ?? null };
    return h.ref;
  },
  useCallback(fn, deps) {
    const { h } = hook();
    if (depsChanged(h.deps, deps)) h.fn = fn;
    h.deps = deps;
    return h.fn;
  },
  useMemo(fn, deps) {
    const { h } = hook();
    if (depsChanged(h.deps, deps)) h.value = fn();
    h.deps = deps;
    return h.value;
  },
  useSyncExternalStore(_sub, get) { return get(); },
};

function invoke(fn, props) {
  let s = scopes.get(fn);
  if (!s) { s = { id: ++scopeSeq, hooks: [] }; scopes.set(fn, s); }
  s.cursor = 0;
  activeFn = fn;
  try {
    return fn(props);
  } finally {
    activeFn = null;
  }
}
function runEffects() {
  for (const e of effectEntries.values()) {
    if (!depsChanged(e.lastDeps, e.deps)) continue;
    if (e.cleanup) { try { e.cleanup(); } catch { /* ignore */ } }
    e.lastDeps = e.deps;
    const r = e.fn();
    if (typeof r === "function") e.cleanup = r;
  }
}
// 展开函数组件/Fragment 元素（模拟 React 挂载）
function expand(node) {
  if (node === null || node === undefined || typeof node !== "object") return node;
  if (Array.isArray(node)) return node.map(expand);
  const { type, props } = node;
  if (typeof type === "function") return expand(invoke(type, props));
  if (type === Fragment) {
    const kids = Array.isArray(props.children) ? props.children : [props.children];
    return kids.map(expand);
  }
  const kids = props?.children;
  if (kids !== undefined) {
    return { ...node, props: { ...props, children: Array.isArray(kids) ? kids.map(expand) : expand(kids) } };
  }
  return node;
}
function renderTree(fn, props) {
  const tree = expand(invoke(fn, props));
  runEffects();
  return tree;
}
function resetScopes() {
  scopes.clear();
  effectEntries.clear();
  // 「彻底删除」的墓碑落在 localStorage（跨页面刷新有效），用例之间必须清零，
  // 否则上一个用例删掉的会话会让下一个用例的列表少一行。
  globalThis.localStorage.removeItem("dsh-obsidian-vault:purged-sessions");
  // 只读僵死行探测的桩状态同样清零（默认：全部有 durable 日志，什么都不隐藏）。
  sessionStateAvailable = true;
  sessionStateStale = new Set();
  sessionStateRunning = new Set();
  sessionStateCalls = 0;
  deleteRouteMissing = [];
}

// ── 树遍历工具 ──────────────────────────────────────────────────────────────
function findAll(node, pred, out = []) {
  if (!node) return out;
  if (Array.isArray(node)) { for (const n of node) findAll(n, pred, out); return out; }
  if (typeof node !== "object") return out;
  if (pred(node.props ?? {}, node)) out.push(node);
  const kids = Array.isArray(node.props.children) ? node.props.children : [node.props.children];
  for (const k of kids) findAll(k, pred, out);
  return out;
}
function textOf(node, out = "") {
  if (!node) return out;
  if (Array.isArray(node)) return node.reduce((acc, n) => textOf(n, acc), out);
  if (typeof node !== "object") return out + String(node);
  const kids = Array.isArray(node.props.children) ? node.props.children : [node.props.children];
  return kids.reduce((acc, k) => textOf(k, acc), out);
}
const byTitle = (title) => (p) => p.title === title;
const byText = (txt) => (p, n) => textOf(n) === txt;
const byTextIncludes = (txt) => (p, n) => textOf(n).includes(txt);
const byClass = (cls) => (p, n) => typeof p.className === "string" && p.className.includes(cls);
// 精确到会话行本身：byClass 是 includes 匹配，会连 dsh-obs-session-title 一起命中
const rowsOf = (tree) => findAll(tree, (p) => typeof p.className === "string" && p.className.split(/\s+/).includes("dsh-obs-session"));
const byRowText = (text) => (p, n) => typeof p.className === "string" && p.className.includes("dsh-obs-row") && textOf(n).includes(text);
const click = (el) => {
  if (!el) { check("click target not found", false); return; }
  el.props.onClick({ stopPropagation() { }, preventDefault() { }, target: {} });
};
// 应用内输入卡片（window.prompt 的替代）：写入文本 → 点「确定」。
// 桌面版 Electron 的 window.prompt 直接抛错，凡是取证输入都必须走这里。
const byClassPrefix = (cls) => (p) => typeof p.className === "string" && p.className.includes(cls);
function answerPrompt(text) {
  let panel = renderTree(PromptC, { t });
  const input = findAll(panel, byClassPrefix("dsh-obs-prompt-input"))[0];
  if (input === undefined) { check(`prompt panel rendered (${text})`, false); return; }
  input.props.onChange({ target: { value: text } });
  panel = renderTree(PromptC, { t });   // 重新渲染后 ✓ 闭包才带上新值
  click(findAll(panel, byText(t("confirm")))[0]);
}

// ── 装载 bundle ─────────────────────────────────────────────────────────────
new Function("window", `${code}\nreturn null;`)(fakeWindow);
const exports_ = registration.factory((spec) => {
  if (spec === "react") return stubReact;
  if (spec === "react/jsx-runtime") return {};
  throw new Error(`unexpected require(${spec})`);
});
const registrations = [];
const stubSlots = {
  inject: (_k, cb) => { cb(); return () => { }; },
  register: (options, component) => {
    registrations.push({ options, component });
    return () => { };
  },
};
// ctx.workspaces = IWorkspaces（纯控制器）：只有 list/create/rename/delete/
// archiveSession/insert*，没有 startSession / pickDirectory —— 这两个方法属于
// ctx.uiWorkspace。夹具必须与真实服务一致，否则「＋无反应」这类 bug 测不出来。
const ctxWorkspaces = { create: async () => ({}), rename: async () => { }, delete: async () => { }, archiveSession: async () => { } };
const ctxSessionCalls = [];
const ctxSessions = {
  create: async (opts) => { ctxSessionCalls.push(["create", opts]); return "s-new"; },
  open: (id) => ctxSessionCalls.push(["open", id]),
  // 旧版 ClientSessions 的「清空当前选择」兜底（0.2 起由 uiWorkspace.clearMain 承担）
  clear: () => ctxSessionCalls.push(["clear"]),
  binding: () => ({ session: { rename: async () => ({ ok: true }) } }),
};
const ctxUiWorkspaceCalls = [];
const ctxUiWorkspace = {
  startSession: (id) => ctxUiWorkspaceCalls.push(["startSession", id]),
  // DSH 0.1.7（桌面版内嵌）起会话打开属于 uiWorkspace：sessions.open 已删除
  openSession: (id) => ctxUiWorkspaceCalls.push(["openSession", id]),
  // DSH 0.2 的内部清空入口：删掉当前会话且没有别的会话可切时必须清空主视图
  clearMain: () => ctxUiWorkspaceCalls.push(["clearMain"]),
  pickDirectory: async () => { ctxUiWorkspaceCalls.push(["pickDirectory"]); return "D:\\picked"; },
};
// 模拟「官方 ui-workspace 服务不在位」：插件应退回 sessions.create + open
let uiWorkspaceReady = true;
const fakeCtx = {
  effect: () => { },
  locale: { register: () => { } },
  slots: stubSlots,
  workspaces: ctxWorkspaces,
  sessions: ctxSessions,
  // 服务经 ctx.get 惰性解析；undefined 即服务缺失
  get: (name) => (name === "uiWorkspace" && uiWorkspaceReady ? ctxUiWorkspace : undefined),
};
exports_.apply(fakeCtx);
const byId = Object.fromEntries(registrations.map((r) => [r.options.id, r.component]));
const Sidebar = byId["obsidian-workspace-sidebar"];
const DockC = byId["obsidian-dock"];
const ToastC = byId["obsidian-toast"];
const PromptC = byId["obsidian-prompt"];
const ComposerBridgeC = byId["obsidian-composer-bridge"];
const t = (k, p) => (p ? `${k}(${JSON.stringify(p)})` : k);

// ── 夹具（模块级共享，保持引用稳定以符合真实 React 的 deps 语义）──────────
const NOW = Date.now();
function sessionsFixture() {
  return {
    ids: ["s1", "s2", "s3", "s4"],
    byId: {
      s1: { id: "s1", title: "会话一", displayTitle: "会话一", cwd: "D:\\code\\ds_workspace", updatedAt: NOW - 30 * 1000, blank: false },
      s2: { id: "s2", title: "会话二", displayTitle: "会话二", updatedAt: NOW - 3 * 60000, blank: false },
      s3: { id: "s3", title: "游离会话", displayTitle: "游离会话", updatedAt: NOW - 12600000, blank: false },
      s4: { id: "s4", title: "obsidian_vault", displayTitle: "obsidian_vault", cwd: "D:\\obsidian_vault", updatedAt: NOW - 60000, blank: true },
    },
    current: "s1",
    phase: "ready",
  };
}
function workspacesFixture() {
  return {
    items: [
      { workspaceId: "ws1", path: "D:\\code\\ds_workspace", title: "ds_workspace", sessionIds: ["s1", "s2"], createdAt: "", updatedAt: "" },
      { workspaceId: "ws2", path: "D:\\obsidian_vault", title: "obsidian_vault", sessionIds: ["s4"], createdAt: "", updatedAt: "" },
    ],
    archivedSessionIds: [],
    state: "ready", phase: "ready", error: null, baselinesReady: true, recentWorkspaceId: "ws1",
  };
}
const SF = sessionsFixture();
const WF = workspacesFixture();
const serviceLog = { calls: [] };
const services = {
  // 真实 ctx.workspaces（IWorkspaces）没有 startSession / pickDirectory：
  // 这里刻意不提供，保证「＋」只能命中 uiWorkspace，回归可被测试捕获。
  workspaces: {
    create: async (input) => { serviceLog.calls.push(["createWs", input && input.path]); return { workspaceId: "ws9", path: "D:\\picked", title: "picked" }; },
    rename: async (id, title) => serviceLog.calls.push(["renameWs", id, title]),
    delete: async (id) => serviceLog.calls.push(["deleteWs", id]),
    archiveSession: async (id) => serviceLog.calls.push(["archiveSession", id]),
  },
  // ctx.uiWorkspace（官方 @deepseek-ai/dsh-client-ui-workspace）：新建会话 + 选目录。
  // 夹具传入的 uiWorkspace 是插件 apply() 里真正装配的外观对象（见 sidebarProps），
  // 它经 ctx.get("uiWorkspace") 惰性解析后落到本 mock，故断言看 ctxUiWorkspaceCalls。
  sessions: {
    open: (id) => serviceLog.calls.push(["open", id]),
    // 删除成功后插件必须调用它刷新 Host 权威列表，否则已删会话仍留在前端行里
    refresh: async () => serviceLog.calls.push(["sessionsRefresh"]),
    binding: (id) => ({ session: { rename: async (title) => { serviceLog.calls.push(["renameSession", id, title]); return { ok: true, title, seq: 1 }; } } }),
  },
};
const sidebarProps = () => ({
  wide: true,
  expandSidebar: () => serviceLog.calls.push(["expandSidebar"]),
  t,
  useSessions: (sel) => sel(SF),
  useWorkspaces: (sel) => sel(WF),
  ...services,
  // 生产链路里就是这个外观对象（slots 的 inject 工厂交付），
  // 它内部按点击时刻解析 ctx.get("uiWorkspace")。
  uiWorkspace: registrations.find((r) => r.options.id === "obsidian-workspace-sidebar").options.inject().uiWorkspace,
});
const event = { stopPropagation() { }, preventDefault() { }, target: {} };

// ═════════════════════════ A. 纯函数行为（渲染输出断言） ═════════════════════════
resetScopes();
{
  const fs = sessionsFixture();
  fs.ids = ["s1", "s2", "s3", "s4", "s5"];
  fs.byId = {
    s1: { id: "s1", title: "t0", displayTitle: "t0", cwd: "D:\\code\\ds_workspace", updatedAt: NOW - 30 * 1000, blank: false },
    s2: { id: "s2", title: "t1", displayTitle: "t1", cwd: "D:\\code\\ds_workspace", updatedAt: NOW - 3 * 60000, blank: false },
    s3: { id: "s3", title: "t2", displayTitle: "t2", cwd: "D:\\code\\ds_workspace", updatedAt: NOW - 2 * 3600000, blank: false },
    s4: { id: "s4", title: "t3", displayTitle: "t3", cwd: "D:\\code\\ds_workspace", updatedAt: NOW - 3 * 86400000, blank: false },
    s5: { id: "s5", title: "t4", displayTitle: "t4", cwd: "D:\\code\\ds_workspace", updatedAt: NOW - 40 * 86400000, blank: false },
  };
  fs.current = "s1";
  const wf = workspacesFixture();
  wf.items[0].sessionIds = ["s1", "s2", "s3", "s4", "s5"];
  const props = { ...sidebarProps(), useSessions: (sel) => sel(fs), useWorkspaces: (sel) => sel(wf) };
  const tree = renderTree(Sidebar, props);
  const times = findAll(tree, byClass("dsh-obs-time")).map((n) => textOf(n));
  const d = new Date(fs.byId.s5.updatedAt);
  const dateStr = `${d.getFullYear()}/${String(d.getMonth() + 1).padStart(2, "0")}/${String(d.getDate()).padStart(2, "0")}`;
  check("A1 相对时间·刚刚", times.some((x) => x === t("time.justNow")), JSON.stringify(times));
  check("A2 相对时间·分钟", times.some((x) => x === t("time.minutes", { n: 3 })));
  check("A3 相对时间·小时", times.some((x) => x === t("time.hours", { n: 2 })));
  check("A4 相对时间·天", times.some((x) => x === t("time.days", { n: 3 })));
  check("A5 相对时间·日期", times.some((x) => x === dateStr), `${JSON.stringify(times)} vs ${dateStr}`);
}

// ═════════════════════════ B. WorkspaceSidebar 交互 ═════════════════════════
// B1 打开会话
resetScopes();
{
  serviceLog.calls.length = 0;
  const tree = renderTree(Sidebar, sidebarProps());
  const row = findAll(tree, byClass("dsh-obs-session"))[0]; // 行 div（含 onClick）
  check("B1 会话行存在且可点击", row !== undefined && typeof row.props.onClick === "function");
  ctxUiWorkspaceCalls.length = 0;
  click(row);
  // 回归：0.1.7 的 ctx.sessions 没有 open()，只调它会让整列会话行「点了没反应」
  check("B1b 点击会话行 → uiWorkspace.openSession(id)",
    ctxUiWorkspaceCalls.some((c) => c[0] === "openSession" && c[1] === "s1"), JSON.stringify(ctxUiWorkspaceCalls));
}
// B2 工作区组展开/收起
resetScopes();
{
  const tree1 = renderTree(Sidebar, sidebarProps());
  check("B2a 初始当前组展开", findAll(tree1, byClass("dsh-obs-session")).length >= 2);
  click(findAll(tree1, byClass("dsh-obs-ws-row"))[0]);
  const tree2 = renderTree(Sidebar, sidebarProps());
  const collapsed = findAll(tree2, byClass("dsh-obs-session")).length;
  check("B2b 点组行收起 → 会话被隐藏", collapsed === 0, `rows=${collapsed}`);
  click(findAll(tree2, byClass("dsh-obs-ws-row"))[0]);
  const tree3 = renderTree(Sidebar, sidebarProps());
  check("B2c 再点组行 → 会话恢复", findAll(tree3, byClass("dsh-obs-session")).length >= 2);
}
// B3 工作区行 ＋ 新建会话（必须走 ctx.uiWorkspace，而非 ctx.workspaces）
resetScopes();
{
  serviceLog.calls.length = 0;
  ctxUiWorkspaceCalls.length = 0;
  const tree = renderTree(Sidebar, sidebarProps());
  const plus = findAll(tree, byTitle("newSession"))[0];
  check("B3a 工作区行 ＋ 存在", plus !== undefined);
  click(plus);
  // 根因回归：以前调 workspaces.startSession（真实 IWorkspaces 无此方法）→ 静默无反应
  check("B3b 工作区 ＋ → uiWorkspace.startSession(wsId)",
    ctxUiWorkspaceCalls.some((c) => c[0] === "startSession" && c[1] === "ws1"), JSON.stringify(ctxUiWorkspaceCalls));
  check("B3c 完全不依赖 workspaces.startSession", typeof services.workspaces.startSession === "undefined");
  check("B3d 点 ＋ 展开目标工作区", findAll(renderTree(Sidebar, sidebarProps()), byClass("dsh-obs-session")).length >= 2);
}
// B3x uiWorkspace 服务缺失 → 退回 sessions.create + open，仍然能新建
resetScopes();
{
  uiWorkspaceReady = false;
  serviceLog.calls.length = 0;
  ctxSessionCalls.length = 0;
  const tree = renderTree(Sidebar, sidebarProps());
  click(findAll(tree, byTitle("newSession"))[0]);
  await settle();
  check("B3x-1 无 uiWorkspace → sessions.create({workspaceId})",
    ctxSessionCalls.some((c) => c[0] === "create" && c[1] && c[1].workspaceId === "ws1"), JSON.stringify(ctxSessionCalls));
  check("B3x-2 无 uiWorkspace → create 后 open 新会话",
    ctxSessionCalls.some((c) => c[0] === "open" && c[1] === "s-new"), JSON.stringify(ctxSessionCalls));
  uiWorkspaceReady = true;
}
// B4 区头 ＋ 添加工作区（pick → create → startSession）
resetScopes();
{
  serviceLog.calls.length = 0;
  const tree = renderTree(Sidebar, sidebarProps());
  ctxUiWorkspaceCalls.length = 0;
  click(findAll(tree, byTitle("addWorkspace"))[0]);
  await settle();
  check("B4 添加工作区 pick(uiWorkspace)→create→startSession(uiWorkspace)",
    ctxUiWorkspaceCalls.some((c) => c[0] === "pickDirectory")
    && serviceLog.calls.some((c) => c[0] === "createWs" && c[1] === "D:\\picked")
    && ctxUiWorkspaceCalls.some((c) => c[0] === "startSession" && c[1] === "ws9"),
    JSON.stringify({ ui: ctxUiWorkspaceCalls, ws: serviceLog.calls }));
}
// B5 工作区删除 = 注册项 + 其中全部会话一起彻底删除（确认框必须提醒会话数量）
resetScopes();
{
  serviceLog.calls.length = 0;
  fetchCalls.length = 0;
  confirmCalls.length = 0;
  confirmResult = true;
  let tree = renderTree(Sidebar, sidebarProps());
  click(findAll(tree, byTitle("delete"))[0]);   // ws1：含 s1/s2
  await settle();
  const del = fetchCalls.find((c) => c.method === "POST" && c.path === "/obsidian/session-delete");
  check("B5a 确认删除 → 先彻底删除工作区内的会话",
    del !== undefined && JSON.stringify([...del.body.ids].sort()) === JSON.stringify(["s1", "s2"]),
    JSON.stringify(del && del.body));
  check("B5b 确认删除 → 再 workspaces.delete(wsId)",
    serviceLog.calls.some((c) => c[0] === "deleteWs" && c[1] === "ws1"), JSON.stringify(serviceLog.calls));
  check("B5c confirm 提示含工作区名与会话数",
    confirmCalls.length === 1 && confirmCalls[0].includes("ds_workspace") && confirmCalls[0].includes("2"),
    JSON.stringify(confirmCalls));
  check("B5d 删除后刷新 Host 会话列表", serviceLog.calls.some((c) => c[0] === "sessionsRefresh"));
  // 没有任何可见会话的工作区（ws2）：不碰会话删除路由，确认文案退回简单版
  serviceLog.calls.length = 0;
  fetchCalls.length = 0;
  confirmCalls.length = 0;
  tree = renderTree(Sidebar, sidebarProps());
  const ws2Row = findAll(tree, byClass("dsh-obs-ws-row")).find((r) => textOf(r).includes("obsidian_vault"));
  click(findAll(ws2Row, byTitle("delete"))[0]);
  await settle();
  check("B5e 无会话工作区 → 不发会话删除请求", !fetchCalls.some((c) => c.path === "/obsidian/session-delete"));
  check("B5f 无会话工作区 → 直接删注册项",
    serviceLog.calls.some((c) => c[0] === "deleteWs" && c[1] === "ws2"), JSON.stringify(serviceLog.calls));
  // 取消：会话与工作区都不动
  serviceLog.calls.length = 0;
  fetchCalls.length = 0;
  confirmResult = false;
  tree = renderTree(Sidebar, sidebarProps());
  click(findAll(tree, byTitle("delete"))[0]);
  await settle();
  check("B5g 取消删除 → 会话与工作区都不动",
    !fetchCalls.some((c) => c.path === "/obsidian/session-delete") && !serviceLog.calls.some((c) => c[0] === "deleteWs"));
  confirmResult = true;
}
// B5x 会话删不掉（接口不可用 / 正在运行）→ 工作区保持原样（fail closed）
resetScopes();
{
  serviceLog.calls.length = 0;
  fetchCalls.length = 0;
  confirmResult = true;
  deleteRouteStatus = 404;
  let tree = renderTree(Sidebar, sidebarProps());
  click(findAll(tree, byTitle("delete"))[0]);
  await settle();
  let toast = textOf(renderTree(ToastC, { t }));
  check("B5x-1 会话删除接口不可用 → 工作区不删", !serviceLog.calls.some((c) => c[0] === "deleteWs"), JSON.stringify(serviceLog.calls));
  check("B5x-2 报出需重启 DSH", toast.includes(t("sessionDeleteUnavailable")), `toast=${toast}`);
  deleteRouteStatus = null;
  serviceLog.calls.length = 0;
  fetchCalls.length = 0;
  deleteRouteRunning = ["s1"];
  tree = renderTree(Sidebar, sidebarProps());
  click(findAll(tree, byTitle("delete"))[0]);
  await settle();
  toast = textOf(renderTree(ToastC, { t }));
  check("B5x-3 有会话在跑 → 工作区不删", !serviceLog.calls.some((c) => c[0] === "deleteWs"), JSON.stringify(serviceLog.calls));
  check("B5x-4 报出会话正在运行", toast.includes(t("sessionRunning")), `toast=${toast}`);
  deleteRouteRunning = [];
}
// B6 工作区重命名（输入/取消）
resetScopes();
{
  serviceLog.calls.length = 0;
  let tree = renderTree(Sidebar, sidebarProps());
  click(findAll(tree, byTitle("rename"))[0]);
  answerPrompt("新名字");
  await settle();
  check("B6a 重命名 → workspaces.rename(id,title)", serviceLog.calls.some((c) => c[0] === "renameWs" && c[1] === "ws1" && c[2] === "新名字"), JSON.stringify(serviceLog.calls));
  serviceLog.calls.length = 0;
  tree = renderTree(Sidebar, sidebarProps());
  click(findAll(tree, byTitle("rename"))[0]);
  click(findAll(renderTree(PromptC, { t }), byText(t("cancel")))[0]);
  check("B6b prompt 取消 → 不调用 rename", !serviceLog.calls.some((c) => c[0] === "renameWs"));
}
// B7 会话「归档」：确认 → archiveSession（移出列表，日志保留；不碰 host 删除路由）
resetScopes();
{
  serviceLog.calls.length = 0;
  fetchCalls.length = 0;
  confirmResult = true;
  let tree = renderTree(Sidebar, sidebarProps());
  const btns = findAll(tree, byTitle("archiveSession"));
  check("B7a 归档按钮每行一个", btns.length === 2, `n=${btns.length}`);
  click(btns[0]);
  await settle();
  check("B7b 确认 → archiveSession(s1)", serviceLog.calls.some((c) => c[0] === "archiveSession" && c[1] === "s1"), JSON.stringify(serviceLog.calls));
  check("B7c 归档不调用 host 删除路由", !fetchCalls.some((c) => c.path === "/obsidian/session-delete"), JSON.stringify(fetchCalls.map((c) => c.path)));
  serviceLog.calls.length = 0;
  confirmResult = false;
  tree = renderTree(Sidebar, sidebarProps());
  click(findAll(tree, byTitle("archiveSession"))[0]);
  check("B7d 取消 → 不调用 archiveSession", !serviceLog.calls.some((c) => c[0] === "archiveSession"));
}
// B7e 会话「彻底删除」：确认 → host /obsidian/session-delete，且不带 archiveSession
resetScopes();
{
  serviceLog.calls.length = 0;
  fetchCalls.length = 0;
  confirmResult = true;
  let tree = renderTree(Sidebar, sidebarProps());
  // 删当前会话之外的 s2：本条用例只验请求内容，当前会话的删除见 B7f
  const rowS2 = findAll(tree, byClass("dsh-obs-session")).find((r) => textOf(r).includes("会话二"));
  click(findAll(rowS2, byTitle("deleteSession"))[0]);
  await settle();
  const call = fetchCalls.find((c) => c.method === "POST" && c.path === "/obsidian/session-delete");
  check("B7e-1 确认 → POST /obsidian/session-delete", call !== undefined, JSON.stringify(fetchCalls.map((c) => c.path)));
  check("B7e-2 请求体只含该会话（无子代理）", JSON.stringify(call && call.body) === JSON.stringify({ ids: ["s2"] }), JSON.stringify(call && call.body));
  check("B7e-3 彻底删除不走归档 RPC", !serviceLog.calls.some((c) => c[0] === "archiveSession"), JSON.stringify(serviceLog.calls));
  check("B7e-5 删除成功后刷新 Host 会话列表", serviceLog.calls.some((c) => c[0] === "sessionsRefresh"), JSON.stringify(serviceLog.calls));
  // 删掉的行必须立刻消失：Host 可能仍持有该会话的内存副本（列表不会自己去掉），
  // 只靠 refresh 会让用户看到「提示删除成功、行还在」。
  tree = renderTree(Sidebar, sidebarProps());
  check("B7e-7 已删除的行不再显示",
    !rowsOf(tree).some((r) => textOf(r).includes("会话二")),
    JSON.stringify(rowsOf(tree).map((r) => textOf(r))));
  serviceLog.calls.length = 0;
  fetchCalls.length = 0;
  confirmResult = false;
  click(findAll(tree, byTitle("deleteSession"))[0]);
  check("B7e-4 取消 → 不调用 host 删除路由", !fetchCalls.some((c) => c.path === "/obsidian/session-delete"));
  check("B7e-6 取消 → 不刷新列表", !serviceLog.calls.some((c) => c[0] === "sessionsRefresh"));
}
// B7i host 未重启（路由 404）时：必须明确报「接口未生效」，不能伪装成「没找到会话」
resetScopes();
{
  serviceLog.calls.length = 0;
  fetchCalls.length = 0;
  confirmResult = true;
  deleteRouteStatus = 404;
  let tree = renderTree(Sidebar, sidebarProps());
  const rowS2 = findAll(tree, byClass("dsh-obs-session")).find((r) => textOf(r).includes("会话二"));
  click(findAll(rowS2, byTitle("deleteSession"))[0]);
  await settle();
  const toast = textOf(renderTree(ToastC, { t }));
  check("B7i-1 404 → 提示需重启 dsh web", toast.includes(t("sessionDeleteUnavailable")), `toast=${toast}`);
  check("B7i-2 404 不谎报「没找到会话」", !toast.includes(t("nothingDeleted")), `toast=${toast}`);
  check("B7i-3 404 不刷新列表", !serviceLog.calls.some((c) => c[0] === "sessionsRefresh"), JSON.stringify(serviceLog.calls));
  deleteRouteStatus = null;
  // 恢复后再验一次：路由正常时提示成功
  serviceLog.calls.length = 0;
  fetchCalls.length = 0;
  tree = renderTree(Sidebar, sidebarProps());
  const rowS2b = findAll(tree, byClass("dsh-obs-session")).find((r) => textOf(r).includes("会话二"));
  click(findAll(rowS2b, byTitle("deleteSession"))[0]);
  await settle();
  const okToast = textOf(renderTree(ToastC, { t }));
  check("B7i-4 正常路径 → 报成功", okToast.includes(t("deletedPermanently")), `toast=${okToast}`);
}
// B7j 删掉的会话仍被 DSH 进程持有内存副本（host 回执 attached）→ 行隐藏 + 说明原因
resetScopes();
{
  fetchCalls.length = 0;
  serviceLog.calls.length = 0;
  confirmResult = true;
  attachedOnDelete = ["s2"];
  let tree = renderTree(Sidebar, sidebarProps());
  const rowS2 = findAll(tree, byClass("dsh-obs-session")).find((r) => textOf(r).includes("会话二"));
  click(findAll(rowS2, byTitle("deleteSession"))[0]);
  await settle();
  const toast = textOf(renderTree(ToastC, { t }));
  check("B7j-1 提示说明仍有内存副本、重启后消失",
    toast.includes(t("deletedPermanentlyStickySuffix", { m: 1 })), `toast=${toast}`);
  attachedOnDelete = [];
  check("B7j-2 Host 刷新后仍列出该会话也不复活",
    !rowsOf(renderTree(Sidebar, sidebarProps())).some((r) => textOf(r).includes("会话二")),
    JSON.stringify(rowsOf(renderTree(Sidebar, sidebarProps())).map((r) => textOf(r))));
  // 页面刷新 = 组件重新挂载 + localStorage 里的墓碑仍在
  const saved = globalThis.localStorage.getItem("dsh-obsidian-vault:purged-sessions");
  resetScopes();
  globalThis.localStorage.setItem("dsh-obsidian-vault:purged-sessions", saved);
  check("B7j-3 页面刷新（重挂载）后仍隐藏",
    !rowsOf(renderTree(Sidebar, sidebarProps())).some((r) => textOf(r).includes("会话二")),
    JSON.stringify(rowsOf(renderTree(Sidebar, sidebarProps())).map((r) => textOf(r))));
  check("B7j-4 只是隐藏目标会话，别的行照常",
    rowsOf(renderTree(Sidebar, sidebarProps())).some((r) => textOf(r).includes("会话一")),
    JSON.stringify(rowsOf(renderTree(Sidebar, sidebarProps())).map((r) => textOf(r))));
}
// B7f 当前正在查看的会话：不在跑就必须能删，删完把主视图切到别的会话
resetScopes();
{
  fetchCalls.length = 0;
  serviceLog.calls.length = 0;
  ctxUiWorkspaceCalls.length = 0;
  confirmResult = true;
  const tree = renderTree(Sidebar, sidebarProps());   // current = s1
  click(findAll(tree, byTitle("deleteSession"))[0]);  // 第一行就是当前会话 s1
  await settle();
  const call = fetchCalls.find((c) => c.path === "/obsidian/session-delete");
  check("B7f-1 当前会话（不在跑）可以彻底删除",
    call !== undefined && JSON.stringify(call.body) === JSON.stringify({ ids: ["s1"] }),
    JSON.stringify(call && call.body));
  check("B7f-2 删完把主视图切到别的会话",
    ctxUiWorkspaceCalls.some((c) => c[0] === "openSession" && c[1] !== "s1"),
    JSON.stringify(ctxUiWorkspaceCalls));
  check("B7f-3 已删的当前会话行消失",
    !rowsOf(renderTree(Sidebar, sidebarProps())).some((r) => textOf(r).includes("会话一")),
    JSON.stringify(rowsOf(renderTree(Sidebar, sidebarProps())).map((r) => textOf(r))));
}
// B7g 彻底删除最后一条（当前）会话：主视图必须清空。
// 不能只隐藏侧边栏的行而把已删对话留在聊天框里 —— 那是用户看到的
// 「提示彻底删除成功、记录还在」。也不能顺手新建会话（新建是用户的决定）。
resetScopes();
{
  const only = sessionsFixture();
  only.ids = ["s1"];
  only.byId = { s1: SF.byId.s1 };
  only.current = "s1";
  const wsOnly = workspacesFixture();
  wsOnly.items = [{ ...WF.items[0], sessionIds: ["s1"] }];
  const props = { ...sidebarProps(), useSessions: (sel) => sel(only), useWorkspaces: (sel) => sel(wsOnly) };
  ctxUiWorkspaceCalls.length = 0;
  ctxSessionCalls.length = 0;
  fetchCalls.length = 0;
  confirmResult = true;
  renderTree(Sidebar, props);              // 首帧建立展开状态
  const tree = renderTree(Sidebar, props);
  click(findAll(tree, byTitle("deleteSession"))[0]);
  await settle();
  check("B7g-1 删掉最后一个当前会话 → 清空主视图",
    ctxUiWorkspaceCalls.some((c) => c[0] === "clearMain"),
    JSON.stringify(ctxUiWorkspaceCalls));
  check("B7g-2 没有其它会话可切 → 不擅自打开/新建会话",
    !ctxUiWorkspaceCalls.some((c) => c[0] === "openSession" || c[0] === "startSession"),
    JSON.stringify(ctxUiWorkspaceCalls));
}
// B7g2 uiWorkspace 没有 clearMain（旧版 DSH）→ 退回 ClientSessions.clear()
resetScopes();
{
  const only = sessionsFixture();
  only.ids = ["s1"];
  only.byId = { s1: SF.byId.s1 };
  only.current = "s1";
  const wsOnly = workspacesFixture();
  wsOnly.items = [{ ...WF.items[0], sessionIds: ["s1"] }];
  const props = { ...sidebarProps(), useSessions: (sel) => sel(only), useWorkspaces: (sel) => sel(wsOnly) };
  const savedClearMain = ctxUiWorkspace.clearMain;
  delete ctxUiWorkspace.clearMain;
  ctxSessionCalls.length = 0;
  ctxUiWorkspaceCalls.length = 0;
  confirmResult = true;
  renderTree(Sidebar, props);
  const tree = renderTree(Sidebar, props);
  click(findAll(tree, byTitle("deleteSession"))[0]);
  await settle();
  check("B7g2 旧版无 uiWorkspace.clearMain → 退回 sessions.clear()",
    ctxSessionCalls.some((c) => c[0] === "clear"),
    JSON.stringify({ ctxSessionCalls, ctxUiWorkspaceCalls }));
  ctxUiWorkspace.clearMain = savedClearMain;
}
// B7f4 Host 权威判定「在跑」→ 409：提示正在运行，且不谎报成功、不刷新列表
resetScopes();
{
  fetchCalls.length = 0;
  serviceLog.calls.length = 0;
  confirmResult = true;
  deleteRouteRunning = ["s1"];
  const tree = renderTree(Sidebar, sidebarProps());
  click(findAll(tree, byTitle("deleteSession"))[0]);
  await settle();
  check("B7f4-1 前端仍发请求（判定权归 Host）",
    fetchCalls.some((c) => c.path === "/obsidian/session-delete"),
    JSON.stringify(fetchCalls.map((c) => c.path)));
  const toast = textOf(renderTree(ToastC, { t }));
  check("B7f4-2 409 → 提示「正在运行」——不再说成「已被打开」",
    toast.includes(t("sessionRunning")) && !toast.includes("已被打开"),
    `toast=${toast}`);
  check("B7f4-3 409 不谎报成功", !toast.includes(t("deletedPermanently")), `toast=${toast}`);
  check("B7f4-4 409 不刷新列表", !serviceLog.calls.some((c) => c[0] === "sessionsRefresh"), JSON.stringify(serviceLog.calls));
  check("B7f4-5 409 时该行不隐藏",
    rowsOf(renderTree(Sidebar, sidebarProps())).some((r) => textOf(r).includes("会话一")),
    JSON.stringify(rowsOf(renderTree(Sidebar, sidebarProps())).map((r) => textOf(r))));
  deleteRouteRunning = [];
}
// B7g 父会话彻底删除必须连同子代理闭包一起删（否则子会话悬空）
resetScopes();
{
  fetchCalls.length = 0;
  confirmResult = true;
  const fs = sessionsFixture();
  fs.current = "s2";   // 当前会话不能是要删的那个（会被活性护栏拒绝）
  fs.ids = ["s1", "s2", "sub1", "sub2", "sub3"];
  fs.byId = {
    s1: { id: "s1", title: "会话一", displayTitle: "会话一", cwd: "D:\\code\\ds_workspace", updatedAt: NOW, blank: false },
    s2: { id: "s2", title: "会话二", displayTitle: "会话二", updatedAt: NOW - 60000, blank: false },
    sub1: { id: "sub1", title: "子代理一", displayTitle: "子代理一", updatedAt: NOW, blank: false, origin: "subagent", parentId: "s1" },
    sub2: { id: "sub2", title: "子代理二", displayTitle: "子代理二", updatedAt: NOW, blank: false, origin: "subagent", parentId: "sub1" },
    sub3: { id: "sub3", title: "别的子代理", displayTitle: "别的子代理", updatedAt: NOW, blank: false, origin: "subagent", parentId: "s2" },
  };
  const wf = workspacesFixture();
  wf.items[0].sessionIds = ["s1", "s2", "sub1", "sub2", "sub3"];
  const props = { ...sidebarProps(), useSessions: (sel) => sel(fs), useWorkspaces: (sel) => sel(wf) };
  const tree = renderTree(Sidebar, props);
  // byClass 是 includes 匹配，会连 dsh-obs-session-title 一起命中，这里要精确到行
  const rows = findAll(tree, (p) => typeof p.className === "string" && p.className.split(/\s+/).includes("dsh-obs-session"));
  check("B7g-1 子代理不单独成行", rows.length === 2, `n=${rows.length}`);
  // 第一行是 s1（父）：只点它，验证闭包把 sub1/sub2 一起带上，且不带 s2 的 sub3
  const parentRow = rows.find((r) => textOf(r).includes("会话一"));
  const delBtn = findAll(parentRow, byTitle("deleteSession"))[0];
  check("B7g-2 父行有彻底删除按钮", delBtn !== undefined);
  click(delBtn);
  await settle();
  const call = fetchCalls.find((c) => c.path === "/obsidian/session-delete");
  const ids = call ? [...call.body.ids].sort() : [];
  check("B7g-3 闭包 = 父 + 全部后代", JSON.stringify(ids) === JSON.stringify(["s1", "sub1", "sub2"]), JSON.stringify(ids));
  check("B7g-4 不牵连无关会话", !ids.includes("s2") && !ids.includes("sub3"), JSON.stringify(ids));
}
// B7h 子代理正在运行时，父会话拒绝彻底删除
// B7h 回归：前端快照说「子代理在跑」但 Host 判定子代理已结束（快照停旧）——
//     必须按 Host 的判定删掉，不能因为前端缓存把会话永久锁死。
resetScopes();
{
  fetchCalls.length = 0;
  serviceLog.calls.length = 0;
  confirmResult = true;
  const fs = sessionsFixture();
  fs.ids = ["s1", "sub1"];
  fs.byId = {
    s1: { id: "s1", title: "会话一", displayTitle: "会话一", cwd: "D:\\code\\ds_workspace", updatedAt: NOW, blank: false },
    sub1: { id: "sub1", title: "子代理一", displayTitle: "子代理一", updatedAt: NOW, blank: false, origin: "subagent", parentId: "s1", running: true },
  };
  const wf = workspacesFixture();
  wf.items[0].sessionIds = ["s1", "sub1"];
  const props = { ...sidebarProps(), useSessions: (sel) => sel(fs), useWorkspaces: (sel) => sel(wf) };
  const tree = renderTree(Sidebar, props);
  const parentRow = findAll(tree, byClass("dsh-obs-session")).find((r) => textOf(r).includes("会话一"));
  click(findAll(parentRow, byTitle("deleteSession"))[0]);
  await settle();
  const call = fetchCalls.find((c) => c.path === "/obsidian/session-delete");
  check("B7h-1 前端快照说子代理在跑也必须发请求（判定权归 Host）", call !== undefined, JSON.stringify(fetchCalls.map((c) => c.path)));
  check("B7h-2 请求仍带子代理闭包",
    JSON.stringify(call && [...call.body.ids].sort()) === JSON.stringify(["s1", "sub1"]),
    JSON.stringify(call && call.body));
  const toast = textOf(renderTree(ToastC, { t }));
  check("B7h-3 Host 放行 → 报成功", toast.includes(t("deletedPermanently")), `toast=${toast}`);
  check("B7h-4 已删的父会话行消失",
    !rowsOf(renderTree(Sidebar, sidebarProps())).some((r) => textOf(r).includes("会话一")),
    JSON.stringify(rowsOf(renderTree(Sidebar, sidebarProps())).map((r) => textOf(r))));
}
// B8 未分组整组：归档 / 彻底删除 两个动作分开
resetScopes();
{
  serviceLog.calls.length = 0;
  fetchCalls.length = 0;
  confirmResult = true;
  let tree = renderTree(Sidebar, sidebarProps());
  const archiveBtns = findAll(tree, byTitle("archiveUngrouped"));
  check("B8a 未分组归档按钮存在", archiveBtns.length === 1, `n=${archiveBtns.length}`);
  click(archiveBtns[0]);
  await settle();
  check("B8b 确认 → 归档未分组全部会话 s3", serviceLog.calls.some((c) => c[0] === "archiveSession" && c[1] === "s3"), JSON.stringify(serviceLog.calls));
  check("B8c 整组归档不碰删除路由", !fetchCalls.some((c) => c.path === "/obsidian/session-delete"));
  serviceLog.calls.length = 0;
  fetchCalls.length = 0;
  confirmResult = false;
  tree = renderTree(Sidebar, sidebarProps());
  click(findAll(tree, byTitle("archiveUngrouped"))[0]);
  check("B8d 取消 → 不调用", !serviceLog.calls.some((c) => c[0] === "archiveSession"));
  // 整组彻底删除
  serviceLog.calls.length = 0;
  fetchCalls.length = 0;
  confirmResult = true;
  tree = renderTree(Sidebar, sidebarProps());
  const delBtns = findAll(tree, byTitle("deleteUngrouped"));
  check("B8e 未分组彻底删除按钮存在", delBtns.length === 1, `n=${delBtns.length}`);
  click(delBtns[0]);
  await settle();
  const call = fetchCalls.find((c) => c.path === "/obsidian/session-delete");
  check("B8f 确认 → 整组走 host 删除", JSON.stringify(call && call.body) === JSON.stringify({ ids: ["s3"] }), JSON.stringify(call && call.body));
  check("B8g 整组彻底删除不归档", !serviceLog.calls.some((c) => c[0] === "archiveSession"), JSON.stringify(serviceLog.calls));
}
// B9 会话搜索（过滤 + Escape 关闭）
resetScopes();
{
  const t1 = renderTree(Sidebar, sidebarProps());
  click(findAll(t1, byTitle("searchSessions"))[0]);
  const t2 = renderTree(Sidebar, sidebarProps());
  const input = findAll(t2, (p) => p.placeholder === t("sessionSearchPlaceholder"))[0];
  check("B9a 点🔍出现搜索框", input !== undefined);
  input.props.onChange({ target: { value: "会话二" } });
  const t3 = renderTree(Sidebar, sidebarProps());
  const titles = findAll(t3, byClass("dsh-obs-session-title")).map((n) => textOf(n));
  check("B9b 搜索过滤只剩匹配会话", titles.length === 1 && titles[0] === "会话二", JSON.stringify(titles));
  const t4 = renderTree(Sidebar, sidebarProps());
  const input2 = findAll(t4, (p) => p.placeholder === t("sessionSearchPlaceholder"))[0];
  input2.props.onKeyDown({ key: "Escape" });
  const t5 = renderTree(Sidebar, sidebarProps());
  check("B9c Escape 关闭搜索恢复全部", findAll(t5, (p) => p.placeholder === t("sessionSearchPlaceholder")).length === 0
    && findAll(t5, byClass("dsh-obs-session")).length >= 2);
}
// B10 inject 工厂交付 ctx 服务
{
  const sidebarReg = registrations.find((r) => r.options.id === "obsidian-workspace-sidebar");
  const injected = sidebarReg.options.inject();
  check("B10a inject 工厂 → workspaces/sessions 透传 ctx",
    injected.workspaces === ctxWorkspaces && injected.sessions === ctxSessions);
  // 契约断言：真实 IWorkspaces 上没有 startSession / pickDirectory，
  // 二者只能来自 uiWorkspace —— 这就是「＋无反应」的根因守卫。
  check("B10b ctx.workspaces 无 startSession（方法属于 uiWorkspace）",
    typeof ctxWorkspaces.startSession === "undefined" && typeof ctxWorkspaces.pickDirectory === "undefined");
  check("B10c inject 工厂 → uiWorkspace 外观对象（startSession + pickDirectory）",
    injected.uiWorkspace !== undefined
    && typeof injected.uiWorkspace.startSession === "function"
    && typeof injected.uiWorkspace.pickDirectory === "function");
}
// B10x 空白会话（新建会话占位）不列入侧边栏
// —— 点工作区「＋」/ 顶部「新会话」后的可见反馈是主区的新会话空态页，
//    侧边栏不再多出一条「新建会话」行（当前空白会话同样不列出）。
resetScopes();
{
  const blankFs = sessionsFixture();
  blankFs.current = "s4";           // s4 = blank，属于 ws2（obsidian_vault）
  const tree = renderTree(Sidebar, { ...sidebarProps(), useSessions: (sel) => sel(blankFs) });
  check("B10x-1 当前空白会话不出现在列表（无会话行）",
    findAll(tree, byClass("dsh-obs-session")).length === 0,
    JSON.stringify(findAll(tree, byClass("dsh-obs-session-title")).map((n) => textOf(n))));
  check("B10x-2 也不以本地化「新建会话」标题出现",
    !findAll(tree, byClass("dsh-obs-session-title")).map((n) => textOf(n)).includes(t("newSession")));
  check("B10x-3 该工作区显示「暂无会话」占位", findAll(tree, byClass("dsh-obs-ws-empty")).length >= 1);
}
// B10y 非当前 / 当前空白会话都不列出，普通会话照常列出
resetScopes();
{
  const normalFs = sessionsFixture();
  normalFs.current = "s1";
  const tree = renderTree(Sidebar, { ...sidebarProps(), useSessions: (sel) => sel(normalFs) });
  const titles = findAll(tree, byClass("dsh-obs-session-title")).map((n) => textOf(n));
  check("B10y-1 非当前空白会话不列入列表",
    !titles.includes(t("newSession")) && !titles.includes("obsidian_vault"), JSON.stringify(titles));
  check("B10y-2 普通会话照常列出（ws1 展开）",
    titles.includes("会话一") && titles.includes("会话二"), JSON.stringify(titles));
}
// B10z 子代理会话（origin=subagent）不列入侧边栏
// —— 与官方 @deepseek-ai/dsh-client-ui-workspace 的 sessionVisible 一致：
//    子代理不是用户会话，只挂在父会话行的「N 个子代理运行中」状态（等价于
//    官方 indexSubagentDescendants 的祖先累加）与正文血缘面包屑上，不单独成行。
resetScopes();
{
  const subFs = sessionsFixture();
  const subWf = workspacesFixture();
  subFs.ids = ["s1", "s2", "s5", "s6", "s3", "s4"];
  // s5 = s1 的子代理（运行中）；s6 = s5 的子代理（运行中）→ 两级都记到 s1
  subFs.byId.s5 = { id: "s5", title: "安装 dsh-...", displayTitle: "安装 dsh-...", parentId: "s1", origin: "subagent", running: true, blank: false, updatedAt: NOW - 10 * 1000 };
  subFs.byId.s6 = { id: "s6", title: "孙代理任务", displayTitle: "孙代理任务", parentId: "s5", origin: "subagent", running: true, blank: false, updatedAt: NOW - 20 * 1000 };
  // s7 = s2 的已结束子代理（不运行 → 不产生状态点）
  subFs.byId.s7 = { id: "s7", title: "已结束子代理", displayTitle: "已结束子代理", parentId: "s2", origin: "subagent", running: false, blank: false, updatedAt: NOW - 30 * 1000 };
  subFs.ids.push("s7");
  subWf.items[0].sessionIds = ["s1", "s2", "s5"]; // 子代理也会被 host 账户进工作区
  const subProps = { ...sidebarProps(), useSessions: (sel) => sel(subFs), useWorkspaces: (sel) => sel(subWf) };
  const tree = renderTree(Sidebar, subProps);
  const titles = findAll(tree, byClass("dsh-obs-session-title")).map((n) => textOf(n));
  check("B10z-1 子代理会话不列为会话行",
    !titles.includes("安装 dsh-...") && !titles.includes("孙代理任务") && !titles.includes("已结束子代理"), JSON.stringify(titles));
  check("B10z-2 子代理不落进「未分组」，普通会话照常列出",
    titles.includes("会话一") && titles.includes("会话二") && !findAll(tree, byClass("dsh-obs-session")).some((row) => textOf(row).includes("安装 dsh-...")),
    JSON.stringify(titles));
  const dots = findAll(tree, byClass("dsh-obs-dot-subs"));
  check("B10z-3 父行显示运行中子代理状态点（两级累加 n=2）",
    dots.length === 1 && dots[0].props.title === t("subagentsRunning", { n: 2 }), JSON.stringify(dots.map((d) => d.props.title)));
  // 搜索路径同样过滤子代理
  click(findAll(tree, byTitle("searchSessions"))[0]);
  const tree2 = renderTree(Sidebar, subProps);
  const input = findAll(tree2, (p) => p.placeholder === t("sessionSearchPlaceholder"))[0];
  input.props.onChange({ target: { value: "子代理" } });
  const tree3 = renderTree(Sidebar, subProps);
  check("B10z-4 搜索也不返回子代理会话",
    findAll(tree3, byClass("dsh-obs-session")).length === 0
    && textOf(tree3).includes(t("noSessions")),
    JSON.stringify(findAll(tree3, byClass("dsh-obs-session-title")).map((n) => textOf(n))));
}
// B11 折叠轨道：📚 点击 → expandSidebar
resetScopes();
{
  serviceLog.calls.length = 0;
  const tree = renderTree(Sidebar, { ...sidebarProps(), wide: false, workspaces: null, sessions: null });
  click(findAll(tree, byTitle("notes"))[0]);
  check("B11 轨道📚 → expandSidebar() 被调用", serviceLog.calls.some((c) => c[0] === "expandSidebar"), JSON.stringify(serviceLog.calls));
}

// ═════════════════════════ C. TreeView 状态（fetch mock） ═════════════════════════
// C1 vault 不存在 → noVault + 选择按钮
resetScopes();
{
  vault = { root: "D:\\missing", exists: false };
  let tree = renderTree(Sidebar, sidebarProps());
  await settle();
  tree = renderTree(Sidebar, sidebarProps());
  check("C1a 无 vault → 提示 noVault", textOf(tree).includes(t("noVault")));
  check("C1b 无 vault → 出现选择按钮", findAll(tree, byTitle("pickVaultTitle")).length >= 1);
}
// C1x 📂 选择 Vault：目录选择器同样只能走 uiWorkspace.pickDirectory
resetScopes();
{
  vault = { root: "D:\\missing", exists: false };
  ctxUiWorkspaceCalls.length = 0;
  fetchCalls.length = 0;
  let tree = renderTree(Sidebar, sidebarProps());
  await settle();
  tree = renderTree(Sidebar, sidebarProps());
  click(findAll(tree, byTitle("pickVaultTitle"))[0]);
  await settle();
  check("C1x-1 📂 → uiWorkspace.pickDirectory()",
    ctxUiWorkspaceCalls.some((c) => c[0] === "pickDirectory"), JSON.stringify(ctxUiWorkspaceCalls));
  const rootCall = fetchCalls.find((c) => c.method === "POST" && c.path === "/obsidian/root");
  check("C1x-2 选中目录 → POST /obsidian/root 落库",
    rootCall !== undefined && rootCall.body.root === "D:\\picked", JSON.stringify(rootCall && rootCall.body));
}
// C2 树加载 + 文件大小 + 目录展开
resetScopes();
{
  vault = { root: "D:\\vault", exists: true };
  fetchCalls.length = 0;
  let tree = renderTree(Sidebar, sidebarProps());
  await settle();
  tree = renderTree(Sidebar, sidebarProps());
  const sizes = findAll(tree, byClass("dsh-obs-size")).map((n) => textOf(n));
  check("C2a 树加载 → 目录/笔记行渲染", findAll(tree, byRowText("sub")).length >= 1 && sizes.length >= 3, JSON.stringify(sizes));
  check("C2b 文件大小格式化 B/KB/MB", sizes.includes("633 B") && sizes.includes("1.5 KB") && sizes.includes("2.5 MB"), JSON.stringify(sizes));
  check("C2c 树经 /tree 请求填充", fetchCalls.some((c) => c.method === "GET" && c.path === "/obsidian/tree"));
  click(findAll(tree, byRowText("sub"))[0]);
  await settle();
  tree = renderTree(Sidebar, sidebarProps());
  check("C2d 展开目录 → 子级渲染", textOf(tree).includes("deep.md"), JSON.stringify(fetchCalls.filter((c) => c.path === "/obsidian/tree").map((c) => c.search)));
}
// C3 笔记搜索（🔍 → 防抖 → 结果）
resetScopes();
{
  vault = { root: "D:\\vault", exists: true };
  let tree = renderTree(Sidebar, sidebarProps());
  await settle();
  tree = renderTree(Sidebar, sidebarProps());
  const head = findAll(tree, byClass("dsh-obs-tree-head"))[0];
  click(findAll(head, byTitle("search"))[0]);
  const t2 = renderTree(Sidebar, sidebarProps());
  const input = findAll(t2, (p) => p.placeholder === t("searchPlaceholder"))[0];
  check("C3a 点🔍出笔记搜索框", input !== undefined);
  input.props.onChange({ target: { value: "gpu" } });
  const t3mid = renderTree(Sidebar, sidebarProps());
  flushTimers();
  await settle();
  const t3 = renderTree(Sidebar, sidebarProps());
  check("C3b 搜索结果渲染（名称+摘要）", textOf(t3).includes("gpu") && textOf(t3).includes("a.md"),
    JSON.stringify(fetchCalls.filter((c) => c.path === "/obsidian/search")));
}
// C4 新建文件夹（📁 → 输入名称 → POST /file mkdir → 刷新）
resetScopes();
{
  vault = { root: "D:\\vault", exists: true };
  fetchCalls.length = 0;

  let tree = renderTree(Sidebar, sidebarProps());
  await settle();
  tree = renderTree(Sidebar, sidebarProps());
  const btn = findAll(tree, byTitle("newFolder"))[0];
  check("C4a 新建文件夹按钮存在", btn !== undefined);
  click(btn);
  answerPrompt("新分类");
  await settle();
  const call = fetchCalls.find((c) => c.method === "POST" && c.path === "/obsidian/file" && c.body.action === "mkdir");
  check("C4b 新建文件夹 → POST /file mkdir（名=新分类）", call !== undefined && call.body.name === "新分类", JSON.stringify(call && call.body));
  const cancelled = (() => {
    fetchCalls.length = 0;
    resetScopes();
    return renderTree(Sidebar, sidebarProps());
  })();
  const btn2 = findAll(cancelled, byTitle("newFolder"))[0];
  click(btn2);
  click(findAll(renderTree(PromptC, { t }), byText(t("cancel")))[0]);
  await settle();
  check("C4c 取消输入 → 不调用 mkdir", !fetchCalls.some((c) => c.path === "/obsidian/file" && c.body.action === "mkdir"));
}
// C5 逐行「＋」新建笔记：根路径行右侧 / 文件夹行右侧
resetScopes();
{
  vault = { root: "D:\\vault", exists: true };
  // 根路径行右侧 ＋ → 在根新增
  fetchCalls.length = 0;
  let tree = renderTree(Sidebar, sidebarProps());
  await settle();
  tree = renderTree(Sidebar, sidebarProps());
  const rootRow = findAll(tree, byClass("dsh-obs-root-row"))[0];
  check("C5a 根路径行存在", rootRow !== undefined);
  const rootPlus = findAll(rootRow, byTitle("newNote"))[0];
  check("C5b 根路径行右侧 ＋ 存在", rootPlus !== undefined);
  click(rootPlus);
  answerPrompt("根笔记");
  await settle();
  const call = fetchCalls.find((c) => c.method === "POST" && c.path === "/obsidian/file" && c.body.action === "new");
  check("C5c 根路径＋ → 在根新增笔记", call !== undefined && call.body.path === "" && call.body.name === "根笔记", JSON.stringify(call && call.body));
  // 文件夹行右侧 ＋ → 在该文件夹内新增
  resetScopes();
  fetchCalls.length = 0;
  let t2 = renderTree(Sidebar, sidebarProps());
  await settle();
  t2 = renderTree(Sidebar, sidebarProps());
  const dirRow = findAll(t2, byRowText("sub"))[0];
  check("C5d 文件夹行存在", dirRow !== undefined);
  const dirPlus = findAll(dirRow, byTitle("newNote"))[0];
  check("C5e 文件夹行右侧 ＋ 存在", dirPlus !== undefined);
  click(dirPlus);
  answerPrompt("文件夹笔记");
  await settle();
  const call2 = fetchCalls.find((c) => c.method === "POST" && c.path === "/obsidian/file" && c.body.action === "new");
  check("C5f 文件夹＋ → 在 sub 内新增笔记", call2 !== undefined && call2.body.path === "sub" && call2.body.name === "文件夹笔记", JSON.stringify(call2 && call2.body));
  // 取消输入 → 不调用 new
  resetScopes();
  fetchCalls.length = 0;
  let t3 = renderTree(Sidebar, sidebarProps());
  await settle();
  t3 = renderTree(Sidebar, sidebarProps());
  const dirRow3 = findAll(t3, byRowText("sub"))[0];
  click(findAll(dirRow3, byTitle("newNote"))[0]);
  click(findAll(renderTree(PromptC, { t }), byText(t("cancel")))[0]);
  await settle();
  check("C5g 取消输入 → 不调用 new", !fetchCalls.some((c) => c.path === "/obsidian/file" && c.body.action === "new"));
}
// C6 逐行「🗑」删除：笔记 / 文件夹（递归）
resetScopes();
{
  vault = { root: "D:\\vault", exists: true };
  // 删笔记
  resetScopes();
  confirmCalls.length = 0;
  fetchCalls.length = 0;
  confirmResult = true;
  let tree = renderTree(Sidebar, sidebarProps());
  await settle();
  tree = renderTree(Sidebar, sidebarProps());
  const noteRow = findAll(tree, byRowText("a.md"))[0];
  const delBtn = findAll(noteRow, byTitle("delete"))[0];
  check("C6a 笔记行 🗑 存在", delBtn !== undefined);
  click(delBtn);
  await settle();
  const call = fetchCalls.find((c) => c.method === "POST" && c.path === "/obsidian/file" && c.body.action === "delete");
  check("C6b 删笔记 → POST /file delete a.md", call !== undefined && call.body.path === "a.md", JSON.stringify(call && call.body));
  check("C6c 笔记删除有确认提示（含笔记名）", confirmCalls.some((m) => typeof m === "string" && m.includes("a.md")));
  // 删文件夹
  resetScopes();
  confirmCalls.length = 0;
  fetchCalls.length = 0;
  confirmResult = true;
  let t2 = renderTree(Sidebar, sidebarProps());
  await settle();
  t2 = renderTree(Sidebar, sidebarProps());
  const dirRow = findAll(t2, byRowText("sub"))[0];
  const dirDel = findAll(dirRow, byTitle("delete"))[0];
  check("C6d 文件夹行 🗑 存在", dirDel !== undefined);
  click(dirDel);
  await settle();
  const call2 = fetchCalls.find((c) => c.method === "POST" && c.path === "/obsidian/file" && c.body.action === "delete");
  check("C6e 删文件夹 → POST /file delete sub", call2 !== undefined && call2.body.path === "sub", JSON.stringify(call2 && call2.body));
  check("C6f 文件夹删除有专门确认（含文件夹名）", confirmCalls.some((m) => typeof m === "string" && m.includes("sub")));
  // 取消确认 → 不调用 delete
  resetScopes();
  confirmResult = false;
  fetchCalls.length = 0;
  let t3 = renderTree(Sidebar, sidebarProps());
  await settle();
  t3 = renderTree(Sidebar, sidebarProps());
  const noteRow3 = findAll(t3, byRowText("a.md"))[0];
  click(findAll(noteRow3, byTitle("delete"))[0]);
  await settle();
  check("C6g 取消确认 → 不调用 delete", !fetchCalls.some((c) => c.path === "/obsidian/file" && c.body.action === "delete"));
}

// C7 外部改动目录内容后，再次展开必须重新拉取（回归：曾把空目录永久钉死）
//     场景来源：文件夹先以「空」状态被展开过一次，随后 DSH/代理把笔记写进该目录。
//     旧实现只在 `dirs[rel] === undefined` 时请求，而空数组同样不等于 undefined，
//     于是缓存永不失效 —— 用户看到「目录里明明有文件，面板就是不显示」。
resetScopes();
{
  const keep = vaultFiles[""];
  for (const k of Object.keys(vaultFiles)) delete vaultFiles[k];   // vaultFiles 是 const，只能原地改
  vaultFiles[""] = [{ name: "空目录", type: "dir", size: 0, mtimeMs: 1 }];
  vaultFiles["空目录"] = [];
  fetchCalls.length = 0;
  let tree = renderTree(Sidebar, sidebarProps());
  await settle();
  tree = renderTree(Sidebar, sidebarProps());
  click(findAll(tree, byRowText("空目录"))[0]);          // ① 空目录第一次展开
  await settle();
  check("C7a 空目录展开后无笔记行", findAll(renderTree(Sidebar, sidebarProps()), byRowText("新笔记.md")).length === 0);

  vaultFiles["空目录"] = [{ name: "新笔记.md", type: "note", size: 10, mtimeMs: 2 }];   // ② 外部写入
  tree = renderTree(Sidebar, sidebarProps());
  click(findAll(tree, byRowText("空目录"))[0]);          // ③ 折叠
  await settle();
  tree = renderTree(Sidebar, sidebarProps());
  click(findAll(tree, byRowText("空目录"))[0]);          // ④ 再展开
  await settle();
  const after = renderTree(Sidebar, sidebarProps());
  const subCalls = fetchCalls.filter((c) => c.path === "/obsidian/tree" && c.search.includes(encodeURIComponent("空目录")));
  check("C7b 再次展开会重新请求该目录", subCalls.length >= 2, `tree 请求数=${subCalls.length}`);
  check("C7c 外部新增的笔记立即可见", findAll(after, byRowText("新笔记.md")).length > 0);

  // C7d ⟳ 刷新不再折叠整棵树，且展开目录的内容同步刷新
  vaultFiles["空目录"] = [{ name: "又一篇.md", type: "note", size: 10, mtimeMs: 3 }];
  tree = renderTree(Sidebar, sidebarProps());
  click(findAll(tree, byTitle("refresh"))[0]);
  await settle(8);
  const refreshed = renderTree(Sidebar, sidebarProps());
  check("C7d ⟳ 后展开状态保留", textOf(findAll(refreshed, byRowText("空目录"))[0]).includes("▾"), textOf(findAll(refreshed, byRowText("空目录"))[0]));
  check("C7e ⟳ 后已展开目录内容同步", findAll(refreshed, byRowText("又一篇.md")).length > 0);
  vaultFiles[""] = keep;
}

// ═════════════════════════ D. Dock 全链路 ═════════════════════════
// D1 点笔记 → Dock 打开渲染 markdown + 双链跳转
resetScopes();
{
  vault = { root: "D:\\vault", exists: true };
  let tree = renderTree(Sidebar, sidebarProps());
  await settle();
  tree = renderTree(Sidebar, sidebarProps());
  click(findAll(tree, byRowText("a.md"))[0]);
  await settle();
  let dock = renderTree(DockC, { t, workspaces: null });
  await settle();
  dock = renderTree(DockC, { t, workspaces: null });
  check("D1a Dock 打开 → 渲染标题", textOf(dock).includes("a.md"));
  check("D1b Dock 打开 → markdown 段落渲染", textOf(dock).includes("World"));
  const wiki = findAll(dock, byTitle("[[双链目标]]"));
  check("D1c Dock 打开 → 双链按钮存在", wiki.length === 1, `n=${wiki.length}`);
  click(wiki[0]);
  await settle();
  dock = renderTree(DockC, { t, workspaces: null });
  await settle();
  dock = renderTree(DockC, { t, workspaces: null });
  check("D1d 双链跳转 → 打开目标笔记", textOf(dock).includes("deep.md") && textOf(dock).includes("Deep"),
    JSON.stringify(fetchCalls.filter((c) => c.path === "/obsidian/search")));
}
// D2 编辑/保存
resetScopes();
{
  vault = { root: "D:\\vault", exists: true };
  let tree = renderTree(Sidebar, sidebarProps());
  await settle();
  tree = renderTree(Sidebar, sidebarProps());
  click(findAll(tree, byRowText("a.md"))[0]);
  await settle();
  let dock = renderTree(DockC, { t, workspaces: null });
  await settle();
  dock = renderTree(DockC, { t, workspaces: null });
  click(findAll(dock, byText(t("edit")))[0]);
  const t2 = renderTree(DockC, { t, workspaces: null });
  const ta = findAll(t2, (p) => p.autoFocus === true)[0];
  check("D2a 点编辑 → textarea 带原文", ta !== undefined && ta.props.value.includes("Hello"), `has=${ta !== undefined}`);
  ta.props.onChange({ target: { value: "# 新标题\n\n新正文" } });
  const t3 = renderTree(DockC, { t, workspaces: null });
  const saveBtn = findAll(t3, byClass("dsh-obs-primary"))[0];
  check("D2b 保存按钮出现", saveBtn !== undefined);
  click(saveBtn);
  await settle();
  const saved = fetchCalls.find((c) => c.method === "POST" && c.path === "/obsidian/note");
  check("D2c 保存 → POST /note 内容正确", saved !== undefined && saved.body.content.includes("新标题"), JSON.stringify(saved && saved.body));
  const t4 = renderTree(DockC, { t, workspaces: null });
  check("D2d 保存后回到预览且内容已更新", textOf(t4).includes("新标题"));
}
// D3 引用到对话（注入输入框 + toast）
resetScopes();
{
  vault = { root: "D:\\vault", exists: true };
  composer.value = "已有内容\n";
  composer.events.length = 0;
  let tree = renderTree(Sidebar, sidebarProps());
  await settle();
  tree = renderTree(Sidebar, sidebarProps());
  click(findAll(tree, byRowText("a.md"))[0]);
  await settle();
  let dock = renderTree(DockC, { t, workspaces: null });
  await settle();
  dock = renderTree(DockC, { t, workspaces: null });
  click(findAll(dock, byText(`⤴ ${t("cite")}`))[0]);
  await settle();
  check("D3a 引用 → @D:\\vault\\a.md 注入输入框", composer.value.includes("@D:\\vault\\a.md"), JSON.stringify(composer.value));
  check("D3b 引用 → 派发 input/change 事件", composer.events.includes("input") && composer.events.includes("change"), JSON.stringify(composer.events));
  const toast = renderTree(ToastC, { t });
  check("D3c 引用 → toast 出现", textOf(toast).includes(t("cited")), `toast=${textOf(toast)}`);
}
// D4 引用兜底：无输入框 → 剪贴板
resetScopes();
{
  vault = { root: "D:\\vault", exists: true };
  composerAvailable = false;
  clipboardWrites.length = 0;
  let tree = renderTree(Sidebar, sidebarProps());
  await settle();
  tree = renderTree(Sidebar, sidebarProps());
  click(findAll(tree, byRowText("a.md"))[0]);
  await settle();
  let dock = renderTree(DockC, { t, workspaces: null });
  await settle();
  dock = renderTree(DockC, { t, workspaces: null });
  click(findAll(dock, byText(`⤴ ${t("cite")}`))[0]);
  await settle();
  check("D4 无输入框 → 引用复制到剪贴板", clipboardWrites.some((w) => w.includes("@D:\\vault\\a.md")), JSON.stringify(clipboardWrites));
  composerAvailable = true;
}
// ═════════ E. 注入对话输入框链路（DSH 0.2+ composer = Lexical contenteditable）═════════
// 打开 a.md 并点「⤴ 引用到对话」。
async function clickCite() {
  let tree = renderTree(Sidebar, sidebarProps());
  await settle();
  tree = renderTree(Sidebar, sidebarProps());
  click(findAll(tree, byRowText("a.md"))[0]);
  await settle();
  let dock = renderTree(DockC, { t, workspaces: null });
  await settle();
  dock = renderTree(DockC, { t, workspaces: null });
  click(findAll(dock, byText(`⤴ ${t("cite")}`))[0]);
  await settle();
  return dock;
}
/** 卸载桥接（真实 React 切会话/销毁时会清空捕获的动作面）。 */
function unmountBridge() {
  renderTree(ComposerBridgeC, { inputActions: null });
}
// E0 桥接注册：session 作用域的 conversation.composer.dock（唯一能拿到 inputActions 的位置）
{
  const bridgeReg = registrations.find((r) => r.options.id === "obsidian-composer-bridge");
  check("E0 注册 inputActions 桥接到 conversation.composer.dock",
    bridgeReg !== undefined && bridgeReg.options.name === "conversation.composer.dock",
    bridgeReg ? bridgeReg.options.name : "missing");
}
// E1/E2/E3 有官方 inputActions → 走官方插入，不碰 DOM
resetScopes();
{
  vault = { root: "D:\\vault", exists: true };
  composer.value = "已有内容\n";
  composer.events.length = 0;
  clipboardWrites.length = 0;
  const calls = [];
  const actions = {
    captureInsertion: () => ({ start: 0, end: 0, draftRev: 7 }),
    insertText: (text, span) => { calls.push({ text, span }); return true; },
  };
  renderTree(ComposerBridgeC, { inputActions: actions });
  await clickCite();
  check("E1 引用 → 走官方 inputActions.insertText（含 @绝对路径）",
    calls.length === 1 && calls[0].text.includes("@D:\\vault\\a.md"),
    JSON.stringify(calls));
  check("E1b 注入文本用 captureInsertion 的 span 做 CAS",
    calls.length === 1 && calls[0].span && calls[0].span.draftRev === 7,
    JSON.stringify(calls[0] && calls[0].span));
  check("E2 官方插入成功 → 不再写 DOM textarea", composer.value === "已有内容\n", JSON.stringify(composer.value));
  const toast = renderTree(ToastC, { t });
  check("E3 toast 为「已引用到对话」（不是「未找到对话输入框」）",
    textOf(toast).includes(t("cited")), `toast=${textOf(toast)}`);
  unmountBridge();
}
// E4 draftRev CAS 连续冲突 → 回落 DOM（textarea）
resetScopes();
{
  vault = { root: "D:\\vault", exists: true };
  composer.value = "已有内容\n";
  composer.events.length = 0;
  const actions = {
    captureInsertion: () => ({ start: 0, end: 0, draftRev: 1 }),
    insertText: () => false,            // 每次都被判为「草稿已变」
  };
  renderTree(ComposerBridgeC, { inputActions: actions });
  await clickCite();
  check("E4a CAS 连续失败 → 回落 DOM textarea 注入",
    composer.value === "已有内容\n@D:\\vault\\a.md\n", JSON.stringify(composer.value));
  check("E4b 回落路径仍派发 input/change 事件",
    composer.events.includes("input") && composer.events.includes("change"), JSON.stringify(composer.events));
  unmountBridge();
}
// E5 无桥接（旧版 DSH / 桥接未挂载）且 composer 为 Lexical contenteditable → execCommand 插入
resetScopes();
{
  vault = { root: "D:\\vault", exists: true };
  composerKind = "editable";
  composerEditor.textContent = "";
  composerEditor.events.length = 0;
  composerEditor.focusCount = 0;
  execCommandResult = true;
  clipboardWrites.length = 0;
  await clickCite();
  check("E5a contenteditable → 原生 insertText 注入（不再误报未找到输入框）",
    composerEditor.textContent === "@D:\\vault\\a.md\n", JSON.stringify(composerEditor.textContent));
  check("E5b 注入前先聚焦编辑器", composerEditor.focusCount > 0, `focusCount=${composerEditor.focusCount}`);
  const toast = renderTree(ToastC, { t });
  check("E5c toast 为「已引用到对话」", textOf(toast).includes(t("cited")), `toast=${textOf(toast)}`);
}
// E6 execCommand 不可用 → 合成 beforeinput 让 Lexical 自己插入
resetScopes();
{
  vault = { root: "D:\\vault", exists: true };
  composerEditor.textContent = "";
  composerEditor.events.length = 0;
  execCommandResult = false;
  beforeInputApplies = true;
  await clickCite();
  check("E6a execCommand 不可用 → 合成 beforeinput 生效",
    composerEditor.textContent === "@D:\\vault\\a.md\n" && composerEditor.events.includes("beforeinput"),
    JSON.stringify({ text: composerEditor.textContent, events: composerEditor.events }));
}
// E7 编辑器完全不接受插入 → 诚实回落剪贴板 + 提示「未找到对话输入框」
resetScopes();
{
  vault = { root: "D:\\vault", exists: true };
  composerEditor.textContent = "原有";
  clipboardWrites.length = 0;
  execCommandResult = false;
  beforeInputApplies = false;
  await clickCite();
  check("E7a 插入彻底失败 → 引用复制到剪贴板",
    clipboardWrites.some((w) => w.includes("@D:\\vault\\a.md")), JSON.stringify(clipboardWrites));
  check("E7b 失败文案仍是「未找到对话输入框，引用已复制到剪贴板」",
    textOf(renderTree(ToastC, { t })).includes(t("noInput")), `toast=${textOf(renderTree(ToastC, { t }))}`);
  composerKind = "textarea";
  execCommandResult = true;
  beforeInputApplies = true;
  composerEditor.textContent = "";
}
// E8 POSIX vault：绝对路径用 `/` 拼接（写死 `\` 会让 Linux/macOS 上的 @引用解析不到）
resetScopes();
{
  vault = { root: "/home/mt/note", exists: true };
  composer.value = "";
  composer.events.length = 0;
  await clickCite();
  check("E8 POSIX vault → @路径用 / 拼接",
    composer.value === "@/home/mt/note/a.md\n", JSON.stringify(composer.value));
}
// E9 Windows vault：保持 `\` 拼接（回归保护）
resetScopes();
{
  vault = { root: "D:\\vault", exists: true };
  composer.value = "";
  composer.events.length = 0;
  await clickCite();
  check("E9 Windows vault → @路径仍用 \\ 拼接",
    composer.value === "@D:\\vault\\a.md\n", JSON.stringify(composer.value));
}
// D5 关闭 Dock
resetScopes();
{
  vault = { root: "D:\\vault", exists: true };
  let tree = renderTree(Sidebar, sidebarProps());
  await settle();
  tree = renderTree(Sidebar, sidebarProps());
  click(findAll(tree, byRowText("a.md"))[0]);
  await settle();
  renderTree(DockC, { t, workspaces: null });
  await settle();
  renderTree(DockC, { t, workspaces: null });
  click(findAll(renderTree(DockC, { t, workspaces: null }), byTitle("close"))[0]);
  const closed = renderTree(DockC, { t, workspaces: null });
  check("D5 点✕关闭 Dock → null", closed === null);
}
// D6 重命名 / D7 删除
resetScopes();
{
  vault = { root: "D:\\vault", exists: true };
  let tree = renderTree(Sidebar, sidebarProps());
  await settle();
  tree = renderTree(Sidebar, sidebarProps());
  click(findAll(tree, byRowText("a.md"))[0]);
  await settle();
  let dock = renderTree(DockC, { t, workspaces: null });
  await settle();
  dock = renderTree(DockC, { t, workspaces: null });
  fetchCalls.length = 0;
  click(findAll(dock, byTitle("rename"))[0]);
  answerPrompt("改名后");
  await settle();
  check("D6 重命名 → /file rename 请求", fetchCalls.some((c) => c.method === "POST" && c.path === "/obsidian/file" && c.body.action === "rename" && c.body.newName === "改名后"),
    JSON.stringify(fetchCalls.filter((c) => c.path === "/obsidian/file")));
  await settle();
  dock = renderTree(DockC, { t, workspaces: null });
  confirmResult = true;
  click(findAll(dock, byTitle("delete"))[0]);
  await settle();
  check("D7 删除 → /file delete 请求", fetchCalls.some((c) => c.method === "POST" && c.path === "/obsidian/file" && c.body.action === "delete"));
  const closed = renderTree(DockC, { t, workspaces: null });
  check("D7b 删除后 Dock 为 null", closed === null);
}
// E. 错误分支 → toast（工作区重命名失败）
resetScopes();
{
  const failingWorkspaces = {
    ...services.workspaces,
    rename: async () => { throw new Error("rename rejected"); },
  };
  const props = { ...sidebarProps(), workspaces: failingWorkspaces };
  const tree = renderTree(Sidebar, props);
  click(findAll(tree, byTitle("rename"))[0]);
  answerPrompt("新名");
  await settle();
  const toast = renderTree(ToastC, { t });
  check("E 服务失败 → toast 错误提示", textOf(toast).includes(t("error")), `toast=${textOf(toast)}`);
}

// ═════════════════════════ F. 桌面版（DSH 0.1.7 / Electron）专属回归 ═════════
// F1 0.1.7 的会话列表快照没有 current：当前会话要按 retainedBy.mainView 推导，
//    否则选中高亮与「删完把主视图切走」都会一起失效。
resetScopes();
{
  fetchCalls.length = 0;
  ctxUiWorkspaceCalls.length = 0;
  confirmResult = true;
  const fs = sessionsFixture();
  delete fs.current;                                  // 0.1.7：字段不存在
  fs.byId.s2.retainedBy = { mainView: 1 };            // 官方判据：主视图持有者
  const props = { ...sidebarProps(), useSessions: (sel) => sel(fs) };
  const tree = renderTree(Sidebar, props);
  const selected = findAll(tree, byClass("dsh-obs-selected"));
  check("F1a 无 current 字段时仍能标出当前会话", selected.length === 1 && textOf(selected[0]).includes("会话二"),
    JSON.stringify(selected.map((n) => textOf(n))));
  const rowS2 = findAll(tree, byClass("dsh-obs-session")).find((r) => textOf(r).includes("会话二"));
  click(findAll(rowS2, byTitle("deleteSession"))[0]);
  await settle();
  check("F1b 当前会话（mainView）不在跑时可删，且删完把主视图切走",
    fetchCalls.some((c) => c.path === "/obsidian/session-delete")
      && ctxUiWorkspaceCalls.some((c) => c[0] === "openSession" && c[1] !== "s2"),
    JSON.stringify({ fetch: fetchCalls.map((c) => c.path), ui: ctxUiWorkspaceCalls }));
}
// F2 两条打开通路都缺失时，点会话行必须给出可见反馈，不能静默死掉
resetScopes();
{
  const fs = sessionsFixture();
  const savedOpen = ctxSessions.open;
  const savedUiOpen = ctxUiWorkspace.openSession;
  delete ctxSessions.open;              // 0.1.7：sessions.open 已删除
  delete ctxUiWorkspace.openSession;    // ui-workspace 服务缺失/异常
  try {
    const tree = renderTree(Sidebar, sidebarProps());
    click(findAll(tree, byClass("dsh-obs-session"))[0]);
    const toast = renderTree(ToastC, { t });
    check("F2 无可用打开通路 → toast 报错（不静默，且是本地化提示）",
      textOf(toast).includes(t("error")) && textOf(toast).includes(t("openUnavailable")), `toast=${textOf(toast)}`);
  } finally {
    if (savedOpen !== undefined) ctxSessions.open = savedOpen;
    ctxUiWorkspace.openSession = savedUiOpen;
  }
  // 还原后再点一次：必须重新走 uiWorkspace.openSession
  resetScopes();
  ctxUiWorkspaceCalls.length = 0;
  const tree2 = renderTree(Sidebar, sidebarProps());
  click(findAll(tree2, byClass("dsh-obs-session"))[0]);
  check("F2b 还原后 → uiWorkspace.openSession 生效",
    ctxUiWorkspaceCalls.some((c) => c[0] === "openSession" && c[1] === "s1"), JSON.stringify(ctxUiWorkspaceCalls));
}
// F3 桌面版没有任何 window.prompt：所有取名流程都必须走应用内输入卡片
//    （桩设成抛错；只要插件里还有一处 window.prompt，这一节就会抛异常）
resetScopes();
{
  vault = { root: "D:\\vault", exists: true };
  let tree = renderTree(Sidebar, sidebarProps());
  await settle();
  tree = renderTree(Sidebar, sidebarProps());
  click(findAll(tree, byTitle("newNote"))[0]);
  answerPrompt("桌面版新笔记");
  await settle();
  check("F3 桌面版取名不经过 window.prompt",
    renderTree(PromptC, { t }) === null
    && fetchCalls.some((c) => c.method === "POST" && c.path === "/obsidian/file" && c.body.action === "new" && c.body.name === "桌面版新笔记"),
    JSON.stringify(fetchCalls.filter((c) => c.path === "/obsidian/file")));
}

// F4 删除成功反馈不能被 refresh 挂死：日志已删就必须报成功
resetScopes();
{
  fetchCalls.length = 0;
  confirmResult = true;
  deleteRouteStatus = null;
  const hangingSessions = { ...services.sessions, refresh: () => new Promise(() => { }) };  // 永不 settle
  const props = { ...sidebarProps(), sessions: hangingSessions };
  const tree = renderTree(Sidebar, props);
  const rowS2 = findAll(tree, byClass("dsh-obs-session")).find((r) => textOf(r).includes("会话二"));
  click(findAll(rowS2, byTitle("deleteSession"))[0]);
  await settle();
  check("F4a refresh 挂起 → host 已收到删除",
    fetchCalls.some((c) => c.method === "POST" && c.path === "/obsidian/session-delete"), JSON.stringify(fetchCalls.map((c) => c.path)));
  const toast = textOf(renderTree(ToastC, { t }));
  check("F4b refresh 挂起 → 仍然报「已彻底删除」", toast.includes(t("deletedPermanently")), `toast=${toast}`);
}
// F4c refresh 抛错同样不能压掉成功反馈
resetScopes();
{
  fetchCalls.length = 0;
  confirmResult = true;
  const failingSessions = { ...services.sessions, refresh: async () => { throw new Error("refresh exploded"); } };
  const props = { ...sidebarProps(), sessions: failingSessions };
  const tree = renderTree(Sidebar, props);
  const rowS2 = findAll(tree, byClass("dsh-obs-session")).find((r) => textOf(r).includes("会话二"));
  click(findAll(rowS2, byTitle("deleteSession"))[0]);
  await settle();
  const toast = textOf(renderTree(ToastC, { t }));
  check("F4c refresh 抛错 → 仍报成功且不冒泡", toast.includes(t("deletedPermanently")), `toast=${toast}`);
}
// F5 陈旧会话行：官方 openSession 会同步抛（sessions.retain: unknown session）
//    —— 必须被吞掉并转成可见提示，不能炸在 onClick 里或静默无反应
resetScopes();
{
  const savedOpen = ctxUiWorkspace.openSession;
  ctxUiWorkspace.openSession = () => { throw new Error("sessions.retain: unknown session s1"); };
  const tree = renderTree(Sidebar, sidebarProps());
  let threw = null;
  try {
    click(findAll(tree, byClass("dsh-obs-session"))[0]);
  } catch (e) {
    threw = e;
  }
  ctxUiWorkspace.openSession = savedOpen;
  check("F5a 陈旧行点击不把异常抛出 onClick", threw === null, String(threw && threw.message));
  const toast = textOf(renderTree(ToastC, { t }));
  check("F5b 陈旧行点击 → 原样报出官方原因",
    toast.includes(t("error")) && toast.includes("unknown session"), `toast=${toast}`);
}
// F6 连续两条同文案 toast 不能共用一个 2.6s 期限
resetScopes();
{
  serviceLog.calls.length = 0;
  timers.length = 0;
  let tree = renderTree(Sidebar, sidebarProps());
  click(findAll(tree, byTitle("rename"))[0]);
  answerPrompt("同一个名字");
  await settle();
  tree = renderTree(Sidebar, sidebarProps());
  click(findAll(tree, byTitle("rename"))[0]);
  answerPrompt("同一个名字");
  await settle();
  check("F6a 两次同文案 → 两个 toast 定时器", timers.length === 2, `timers=${timers.length}`);
  if (timers.length === 2) {
    timers[0]();                                   // 只触发第一条的定时器
    const toast = textOf(renderTree(ToastC, { t }));
    check("F6b 第一条到期不清掉第二条", toast === t("renamed"), `toast=${toast}`);
  }
  timers.length = 0;
}

// ═════════════════════════ G. 已删会话记录「复活」的回归 ═════════════════════
// 现象：不重启 dsh web，只刷新页面，以前删掉的记录又出现在侧边栏；再点 🗑 只说
// 「没有找到可删除的会话」（磁盘上确实已经没有了），行却还在。

// G1 墓碑 GC 不能在列表就绪前跑：Store 的初始快照是
//    `{ ids: [], byId: {}, phase: "pending" }`，此时 byId 为空 —— 若拿它当
//    「Host 不再列出这些会话」的证据，页面一加载就会把墓碑全部清掉，而被删的
//    行仍因 Host 进程里的内存副本被列为可见。
resetScopes();
{
  globalThis.localStorage.setItem("dsh-obsidian-vault:purged-sessions", JSON.stringify(["s2"]));
  const cold = { ids: [], byId: {}, current: undefined, phase: "pending" };
  renderTree(Sidebar, { ...sidebarProps(), useSessions: (sel) => sel(cold) });
  const stored = globalThis.localStorage.getItem("dsh-obsidian-vault:purged-sessions");
  check("G1a 列表未就绪（phase: pending）时不清理墓碑", stored === JSON.stringify(["s2"]), `stored=${stored}`);

  // 列表随后到达：Host 仍列着 s2（内存副本），墓碑必须继续隐藏它。
  // 冷启动那一帧 `current` 还是 undefined，工作区分组尚未展开，所以要多渲染一帧
  // 才看得到会话行（否则本断言会因为「一行都没有」而假通过）。
  renderTree(Sidebar, sidebarProps());
  const tree = renderTree(Sidebar, sidebarProps());
  check("G1b 刷新后已删的会话行不复活",
    !rowsOf(tree).some((r) => textOf(r).includes("会话二")) && rowsOf(tree).length > 0,
    JSON.stringify(rowsOf(tree).map((r) => textOf(r))));
  const stored2 = globalThis.localStorage.getItem("dsh-obsidian-vault:purged-sessions");
  check("G1c 列表就绪后墓碑仍保留（Host 还列着它）", stored2 === JSON.stringify(["s2"]), `stored=${stored2}`);

  // phase 已经是 "ready"，但这一次拉取恰好是空列表（Host 还没读到磁盘 / 授权范围为空）：
  // 空快照同样不能当成「Host 不再列出」的证据。
  renderTree(Sidebar, {
    ...sidebarProps(),
    useSessions: (sel) => sel({ ids: [], byId: {}, current: undefined, phase: "ready" }),
  });
  const storedEmpty = globalThis.localStorage.getItem("dsh-obsidian-vault:purged-sessions");
  check("G1e phase:ready 但列表为空时也不清墓碑", storedEmpty === JSON.stringify(["s2"]), `stored=${storedEmpty}`);

  // 反向：Host 不再列出该 id（重启后内存副本消失）→ 墓碑该被回收，避免无限增长
  const gone = { ids: ["s1", "s3"], byId: { s1: SF.byId.s1, s3: SF.byId.s3 }, current: "s1", phase: "ready" };
  renderTree(Sidebar, { ...sidebarProps(), useSessions: (sel) => sel(gone) });
  const stored3 = globalThis.localStorage.getItem("dsh-obsidian-vault:purged-sessions");
  check("G1d Host 不再列出该 id → 墓碑被回收", stored3 === "[]", `stored=${stored3}`);
}
// G2 重删一条「磁盘上早就没有日志」的记录：必须移除该行，且不能报「没有找到可删除
//    的会话」—— missing 与 deleted 一样证明会话已经不存在
resetScopes();
{
  fetchCalls.length = 0;
  confirmResult = true;
  deleteRouteMissing = ["s2"];
  let tree = renderTree(Sidebar, sidebarProps());
  const rowS2 = findAll(tree, byClass("dsh-obs-session")).find((r) => textOf(r).includes("会话二"));
  click(findAll(rowS2, byTitle("deleteSession"))[0]);
  await settle();
  const toast = textOf(renderTree(ToastC, { t }));
  check("G2a 日志已不在 → 报「已移除失效记录」", toast.includes(t("staleSessionsRemoved", { n: 1 })), `toast=${toast}`);
  check("G2b 不谎报「没有找到可删除的会话」", !toast.includes(t("nothingDeleted")), `toast=${toast}`);
  tree = renderTree(Sidebar, sidebarProps());
  check("G2c 该行随即消失（重删不再是死循环）",
    !rowsOf(tree).some((r) => textOf(r).includes("会话二")),
    JSON.stringify(rowsOf(tree).map((r) => textOf(r))));
  const stored = globalThis.localStorage.getItem("dsh-obsidian-vault:purged-sessions");
  check("G2d 仍落墓碑（页面刷新后也不复活）", stored === JSON.stringify(["s2"]), `stored=${stored}`);
}
// G2e deleted 与 missing 混合（父会话日志在、子代理日志早已不在）：两个数字都要报
resetScopes();
{
  fetchCalls.length = 0;
  confirmResult = true;
  const fs = sessionsFixture();
  fs.ids = ["s1", "s2", "s5"];
  fs.byId = {
    s1: { ...SF.byId.s1 },
    s2: { ...SF.byId.s2 },
    s5: { id: "s5", title: "子代理", displayTitle: "子代理", parentId: "s2", origin: "subagent", updatedAt: NOW, blank: false },
  };
  const wf = workspacesFixture();
  wf.items[0].sessionIds = ["s1", "s2"];
  const props = { ...sidebarProps(), useSessions: (sel) => sel(fs), useWorkspaces: (sel) => sel(wf) };
  deleteRouteMissing = ["s5"];
  const tree = renderTree(Sidebar, props);
  const rowS2 = findAll(tree, byClass("dsh-obs-session")).find((r) => textOf(r).includes("会话二"));
  click(findAll(rowS2, byTitle("deleteSession"))[0]);
  await settle();
  const toast = textOf(renderTree(ToastC, { t }));
  check("G2e 父删成功 + 子日志早已不在 → 两个数字都报",
    toast.includes(t("deletedPermanently", { n: 1 })) && toast.includes(t("deletedPermanentlyMissingSuffix", { m: 1 })),
    `toast=${toast}`);
}
// G3 自愈：Host 说「磁盘上已无 durable 日志、也不在跑」的可见会话，不必等用户再点
//    删除 —— 直接不再显示（覆盖「墓碑机制出现之前删掉的」历史记录）
resetScopes();
{
  fetchCalls.length = 0;
  flushTimers();                 // 清掉上一用例残留的 toast，避免断言读到旧提示
  check("G3 前置：toast 已清空", textOf(renderTree(ToastC, { t })) === "", textOf(renderTree(ToastC, { t })));
  sessionStateStale = new Set(["s2"]);
  renderTree(Sidebar, sidebarProps());
  await settle();
  const tree = renderTree(Sidebar, sidebarProps());
  check("G3a Host 权威判定磁盘无日志 → 行不再显示",
    !rowsOf(tree).some((r) => textOf(r).includes("会话二")),
    JSON.stringify(rowsOf(tree).map((r) => textOf(r))));
  check("G3b 其它行不受影响",
    rowsOf(tree).some((r) => textOf(r).includes("会话一")),
    JSON.stringify(rowsOf(tree).map((r) => textOf(r))));
  const toast = textOf(renderTree(ToastC, { t }));
  check("G3c 说明移除了失效记录", toast.includes(t("staleSessionsRemoved", { n: 1 })), `toast=${toast}`);
  // 探测请求只带「可见、非空白、不在跑」的 id（s4 是空白会话，不该问），且每个 id 只问一次
  const probes = fetchCalls.filter((c) => c.path === "/obsidian/session-state");
  check("G3d 探测只带可见且非空白的会话 id（每个 id 只问一次）",
    probes.length === 1
    && JSON.stringify(probes[0].body) === JSON.stringify({ ids: ["s1", "s2", "s3"] }),
    JSON.stringify(probes.map((p) => p.body)));
  const stored = globalThis.localStorage.getItem("dsh-obsidian-vault:purged-sessions");
  check("G3e 自愈也落墓碑（避免下次刷新再问一遍）", stored === JSON.stringify(["s2"]), `stored=${stored}`);
}
// G4 只读探测的安全边界：判不准就什么都不做，绝不误隐藏真实会话
resetScopes();
{
  // (1) Host 没有该路由 / 服务缺失 → available:false
  sessionStateAvailable = false;
  sessionStateStale = new Set(["s2"]);
  renderTree(Sidebar, sidebarProps());
  await settle();
  let tree = renderTree(Sidebar, sidebarProps());
  check("G4a available:false → 不隐藏任何会话",
    rowsOf(tree).some((r) => textOf(r).includes("会话二")),
    JSON.stringify(rowsOf(tree).map((r) => textOf(r))));

  // (2) Host 判定该会话仍在跑（日志可能还没落盘）→ 不隐藏
  resetScopes();
  sessionStateStale = new Set(["s2"]);
  sessionStateRunning = new Set(["s2"]);
  renderTree(Sidebar, sidebarProps());
  await settle();
  tree = renderTree(Sidebar, sidebarProps());
  check("G4b 权威判定「在跑」→ 不隐藏",
    rowsOf(tree).some((r) => textOf(r).includes("会话二")),
    JSON.stringify(rowsOf(tree).map((r) => textOf(r))));

  // (3) 前端快照说它在跑 → 连问都不问
  resetScopes();
  fetchCalls.length = 0;
  const running = sessionsFixture();
  running.byId.s2 = { ...running.byId.s2, running: true };
  renderTree(Sidebar, { ...sidebarProps(), useSessions: (sel) => sel(running) });
  await settle();
  const probe = fetchCalls.find((c) => c.path === "/obsidian/session-state");
  check("G4c 前端快照在跑 → 不发起探测（更不该隐藏）",
    probe === undefined || !probe.body.ids.includes("s2"),
    JSON.stringify(probe && probe.body));
}

// ═════════════════════════ H. 批量操作（工作区 / 会话） ═════════════════════════
// 产品约定：标题行按钮只批量工作区（勾选后删除）；工作区行按钮只批量该工作区的
// 会话（归档 / 彻底删除）；工具条提供全选 / 反选 / 清空 / 取消。范围之外不做。
const byExactClass = (cls) => (p) => typeof p.className === "string" && p.className.split(/\s+/).includes(cls);
const batchInfoText = (tree) => textOf(findAll(tree, byExactClass("dsh-obs-batchbar-info"))[0]);
const checkedIds = (tree) => findAll(tree, byExactClass("dsh-obs-check"))
  .filter((c) => c.props.checked === true)
  .map((c) => c.props["data-id"]);

// H1 标题行批量入口：进入工作区批量模式（勾选框只出现在真实工作区行上）
resetScopes();
{
  let tree = renderTree(Sidebar, sidebarProps());
  const entry = findAll(tree, byTitle(t("batchWorkspaces")))[0];
  check("H1a 标题行批量按钮存在", entry !== undefined);
  click(entry);
  tree = renderTree(Sidebar, sidebarProps());
  check("H1b 进入批量工作区模式 → 工具条出现", findAll(tree, byExactClass("dsh-obs-batchbar")).length === 1);
  check("H1c 每个真实工作区一个勾选框（未分组没有）",
    checkedIds(tree).length === 0 && findAll(tree, byExactClass("dsh-obs-check")).length === 2,
    `n=${findAll(tree, byExactClass("dsh-obs-check")).length}`);
  check("H1d 勾选框带工作区 id",
    findAll(tree, byExactClass("dsh-obs-check")).map((c) => c.props["data-id"]).join(",") === "ws1,ws2",
    JSON.stringify(findAll(tree, byExactClass("dsh-obs-check")).map((c) => c.props["data-id"])));
  check("H1e 工作区模式不提供会话批量动作",
    findAll(tree, byTitle(t("deletePickedWorkspaces"))).length === 1
    && findAll(tree, byTitle(t("archivePicked"))).length === 0
    && findAll(tree, byTitle(t("deletePicked"))).length === 0);
  check("H1f 工具条说明初始 0 已选", batchInfoText(tree).includes("0"), batchInfoText(tree));
}

// H2 全选 / 反选 / 清空勾选
resetScopes();
{
  let tree = renderTree(Sidebar, sidebarProps());
  click(findAll(tree, byTitle(t("batchWorkspaces")))[0]);
  tree = renderTree(Sidebar, sidebarProps());
  // 0 勾选时「清空勾选」应禁用并说明作用（用户反馈：原「清空」点了没反应、不知何用）
  const clear0 = findAll(tree, byTitle(t("batchClear")))[0];
  check("H2-0 未勾选时「清空勾选」禁用且文案明确",
    clear0 !== undefined && clear0.props.disabled === true && textOf(clear0) === t("batchClear"),
    JSON.stringify({ disabled: clear0 && clear0.props.disabled, label: clear0 && textOf(clear0) }));
  click(findAll(tree, byTitle(t("batchSelectAll")))[0]);
  tree = renderTree(Sidebar, sidebarProps());
  check("H2a 全选 → 两个工作区都勾上", checkedIds(tree).join(",") === "ws1,ws2", JSON.stringify(checkedIds(tree)));
  check("H2b 已选说明与勾选同步", batchInfoText(tree).includes("2"), batchInfoText(tree));
  const clear1 = findAll(tree, byTitle(t("batchClear")))[0];
  check("H2b-2 有勾选时「清空勾选」可用", clear1 !== undefined && clear1.props.disabled === false, JSON.stringify(clear1 && clear1.props.disabled));
  click(findAll(tree, byTitle(t("batchInvert")))[0]);
  tree = renderTree(Sidebar, sidebarProps());
  check("H2c 反选 → 全部取消", checkedIds(tree).length === 0, JSON.stringify(checkedIds(tree)));
  click(findAll(tree, byTitle(t("batchSelectAll")))[0]);
  tree = renderTree(Sidebar, sidebarProps());
  click(findAll(tree, byTitle(t("batchClear")))[0]);
  tree = renderTree(Sidebar, sidebarProps());
  check("H2d 清空勾选 → 全部取消且已选归 0",
    checkedIds(tree).length === 0 && batchInfoText(tree).includes("0"),
    JSON.stringify({ ids: checkedIds(tree), info: batchInfoText(tree) }));
}

// H3 工作区批量模式下：点行 = 勾选（不再展开/收起）
resetScopes();
{
  let tree = renderTree(Sidebar, sidebarProps());
  click(findAll(tree, byTitle(t("batchWorkspaces")))[0]);
  tree = renderTree(Sidebar, sidebarProps());
  const rowsBefore = rowsOf(tree).length;
  const wsRow = findAll(tree, byExactClass("dsh-obs-ws-row")).find((r) => r.props["data-workspace-id"] === "ws1");
  click(wsRow);
  tree = renderTree(Sidebar, sidebarProps());
  check("H3a 批量模式点工作区行 = 勾选", checkedIds(tree).join(",") === "ws1", JSON.stringify(checkedIds(tree)));
  check("H3b 点行不再展开/收起", rowsOf(tree).length === rowsBefore, `${rowsOf(tree).length} vs ${rowsBefore}`);
  check("H3c 勾选行带 dsh-obs-picked", findAll(tree, byExactClass("dsh-obs-picked")).length === 1);
}

// H4 批量删除工作区 = 注册项 + 其中会话一起彻底删除；一次确认；取消则什么都不做
resetScopes();
{
  serviceLog.calls.length = 0;
  fetchCalls.length = 0;
  confirmCalls.length = 0;
  confirmResult = true;
  let tree = renderTree(Sidebar, sidebarProps());
  click(findAll(tree, byTitle(t("batchWorkspaces")))[0]);
  tree = renderTree(Sidebar, sidebarProps());
  click(findAll(tree, byTitle(t("batchSelectAll")))[0]);
  tree = renderTree(Sidebar, sidebarProps());
  click(findAll(tree, byTitle(t("deletePickedWorkspaces")))[0]);
  await settle();
  const deletes = serviceLog.calls.filter((c) => c[0] === "deleteWs").map((c) => c[1]);
  check("H4a 一次确认后逐个 workspaces.delete", deletes.join(",") === "ws1,ws2", JSON.stringify(serviceLog.calls));
  const delCall = fetchCalls.find((c) => c.method === "POST" && c.path === "/obsidian/session-delete");
  check("H4a-2 级联彻底删除工作区内的会话",
    delCall !== undefined && JSON.stringify([...delCall.body.ids].sort()) === JSON.stringify(["s1", "s2"]),
    JSON.stringify(delCall && delCall.body));
  check("H4b 只弹一次确认框且同时写清工作区数与会话数",
    confirmCalls.length === 1 && confirmCalls[0].includes('"n":2') && confirmCalls[0].includes('"m":2'),
    JSON.stringify(confirmCalls));
  const okToast = textOf(renderTree(ToastC, { t }));
  check("H4c 提示报出工作区与会话数量",
    okToast.includes(t("deletedWorkspacesWithSessions", { n: 2, m: 2 })), `toast=${okToast}`);
  tree = renderTree(Sidebar, sidebarProps());
  check("H4d 全部成功后退出批量模式",
    findAll(tree, byExactClass("dsh-obs-batchbar")).length === 0
    && findAll(tree, byExactClass("dsh-obs-check")).length === 0);
  serviceLog.calls.length = 0;
  fetchCalls.length = 0;
  confirmCalls.length = 0;
  confirmResult = false;
  click(findAll(tree, byTitle(t("batchWorkspaces")))[0]);
  tree = renderTree(Sidebar, sidebarProps());
  click(findAll(tree, byTitle(t("batchSelectAll")))[0]);
  tree = renderTree(Sidebar, sidebarProps());
  click(findAll(tree, byTitle(t("deletePickedWorkspaces")))[0]);
  await settle();
  check("H4e 取消确认 → 会话与工作区都不动",
    !fetchCalls.some((c) => c.path === "/obsidian/session-delete") && !serviceLog.calls.some((c) => c[0] === "deleteWs"));
  tree = renderTree(Sidebar, sidebarProps());
  check("H4f 取消后仍在批量模式", findAll(tree, byExactClass("dsh-obs-batchbar")).length === 1);
}
// H4x 工作区里有会话在跑：该工作区整块不删（fail closed），不静默把会话移入未分组
resetScopes();
{
  serviceLog.calls.length = 0;
  fetchCalls.length = 0;
  confirmCalls.length = 0;
  confirmResult = true;
  deleteRouteRunning = ["s1"];
  let tree = renderTree(Sidebar, sidebarProps());
  click(findAll(tree, byTitle(t("batchWorkspaces")))[0]);
  tree = renderTree(Sidebar, sidebarProps());
  // 只勾 ws1（它含 s1/s2；s1 在跑）
  const ws1Row = findAll(tree, byExactClass("dsh-obs-ws-row")).find((r) => r.props["data-workspace-id"] === "ws1");
  click(ws1Row);
  tree = renderTree(Sidebar, sidebarProps());
  click(findAll(tree, byTitle(t("deletePickedWorkspaces")))[0]);
  await settle();
  let toast = textOf(renderTree(ToastC, { t }));
  check("H4x-1 会话在跑 → 该工作区不删", !serviceLog.calls.some((c) => c[0] === "deleteWs"), JSON.stringify(serviceLog.calls));
  check("H4x-2 明确提示工作区未删除的原因", toast.includes(t("deleteWorkspaceSessionsFailed")), `toast=${toast}`);
  tree = renderTree(Sidebar, sidebarProps());
  check("H4x-3 失败后仍在批量模式", findAll(tree, byExactClass("dsh-obs-batchbar")).length === 1);
  // 混合选择：被拦的 ws1 保留，无会话的 ws2 照常删除并给出部分成功提示
  serviceLog.calls.length = 0;
  fetchCalls.length = 0;
  confirmCalls.length = 0;
  click(findAll(tree, byTitle(t("batchSelectAll")))[0]);
  tree = renderTree(Sidebar, sidebarProps());
  click(findAll(tree, byTitle(t("deletePickedWorkspaces")))[0]);
  await settle();
  const deletes = serviceLog.calls.filter((c) => c[0] === "deleteWs").map((c) => c[1]);
  check("H4x-4 混合选择：被拦工作区保留、其余照删", deletes.join(",") === "ws2", JSON.stringify(deletes));
  toast = textOf(renderTree(ToastC, { t }));
  check("H4x-5 报部分成功 + 会话删除数",
    toast.includes(t("deletedWorkspacesPartial", { n: 1, m: 1, k: 0 })), `toast=${toast}`);
  tree = renderTree(Sidebar, sidebarProps());
  check("H4x-6 部分失败后仍在批量模式", findAll(tree, byExactClass("dsh-obs-batchbar")).length === 1);
  deleteRouteRunning = [];
  confirmResult = true;
}

// H4y 所选工作区都没有会话 → confirm 用短文案（不出现「0 个会话将被删除」）
resetScopes();
{
  confirmCalls.length = 0;
  confirmResult = false;
  let tree = renderTree(Sidebar, sidebarProps());
  click(findAll(tree, byTitle(t("batchWorkspaces")))[0]);
  tree = renderTree(Sidebar, sidebarProps());
  const ws2Row = findAll(tree, byExactClass("dsh-obs-ws-row")).find((r) => r.props["data-workspace-id"] === "ws2");
  click(ws2Row);
  tree = renderTree(Sidebar, sidebarProps());
  click(findAll(tree, byTitle(t("deletePickedWorkspaces")))[0]);
  await settle();
  check("H4y 0 会话工作区批量删除用短文案",
    confirmCalls.length === 1
    && confirmCalls[0] === t("deletePickedWorkspacesConfirmNoSessions", { n: 1 }),
    JSON.stringify(confirmCalls));
  confirmResult = true;
}

// H4z 批量删除工作区时，当前会话若在其中且没有别的会话可切 → 清空主视图
// （不能把日志已删掉的对话继续留在聊天框里）
resetScopes();
{
  const only = sessionsFixture();
  only.ids = ["s1"];
  only.byId = { s1: SF.byId.s1 };
  only.current = "s1";
  const wsOnly = workspacesFixture();
  wsOnly.items = [{ ...WF.items[0], sessionIds: ["s1"] }];
  const props = { ...sidebarProps(), useSessions: (sel) => sel(only), useWorkspaces: (sel) => sel(wsOnly) };
  serviceLog.calls.length = 0;
  fetchCalls.length = 0;
  confirmCalls.length = 0;
  ctxUiWorkspaceCalls.length = 0;
  confirmResult = true;
  let tree = renderTree(Sidebar, props);
  click(findAll(tree, byTitle(t("batchWorkspaces")))[0]);
  tree = renderTree(Sidebar, props);
  click(findAll(tree, byTitle(t("batchSelectAll")))[0]);
  tree = renderTree(Sidebar, props);
  click(findAll(tree, byTitle(t("deletePickedWorkspaces")))[0]);
  await settle();
  check("H4z-1 批量删工作区后当前会话已删 → 清空主视图",
    ctxUiWorkspaceCalls.some((c) => c[0] === "clearMain"),
    JSON.stringify(ctxUiWorkspaceCalls));
  tree = renderTree(Sidebar, props);
  check("H4z-2 工作区全部删除后退出批量模式",
    findAll(tree, byExactClass("dsh-obs-batchbar")).length === 0);
}

// H5 工作区行批量入口：范围只含该工作区的会话
resetScopes();
{
  let tree = renderTree(Sidebar, sidebarProps());
  const entries = findAll(tree, byTitle(t("batchSessions")));
  check("H5a 只有有会话的真实工作区有批量入口", entries.length === 1, `n=${entries.length}`);
  click(entries[0]);
  tree = renderTree(Sidebar, sidebarProps());
  check("H5b 只有目标工作区的会话出现勾选框",
    findAll(tree, byExactClass("dsh-obs-check")).map((c) => c.props["data-id"]).sort().join(",") === "s1,s2",
    JSON.stringify(findAll(tree, byExactClass("dsh-obs-check")).map((c) => c.props["data-id"])));
  check("H5c 会话模式动作齐全",
    findAll(tree, byTitle(t("archivePicked"))).length === 1
    && findAll(tree, byTitle(t("deletePicked"))).length === 1
    && findAll(tree, byTitle(t("deletePickedWorkspaces"))).length === 0);
  const target = findAll(tree, byExactClass("dsh-obs-batch-target"));
  check("H5d 目标工作区行高亮", target.length === 1 && target[0].props["data-workspace-id"] === "ws1");
  const ungroupedRow = rowsOf(tree).find((r) => textOf(r).includes("游离会话"));
  check("H5e 其它分组的会话行没有勾选框", findAll(ungroupedRow, byExactClass("dsh-obs-check")).length === 0);
  check("H5f 批量模式下单行动作隐藏", findAll(tree, byTitle(t("archiveSession"))).length === 0);
}

// H6 批量归档：一次确认 → 逐个 archiveSession；不碰 host 删除路由
resetScopes();
{
  serviceLog.calls.length = 0;
  fetchCalls.length = 0;
  confirmCalls.length = 0;
  confirmResult = true;
  let tree = renderTree(Sidebar, sidebarProps());
  click(findAll(tree, byTitle(t("batchSessions")))[0]);
  tree = renderTree(Sidebar, sidebarProps());
  click(findAll(tree, byTitle(t("batchSelectAll")))[0]);
  tree = renderTree(Sidebar, sidebarProps());
  click(findAll(tree, byTitle(t("archivePicked")))[0]);
  await settle();
  const archived = serviceLog.calls.filter((c) => c[0] === "archiveSession").map((c) => c[1]).sort();
  check("H6a 一次确认后逐个归档", archived.join(",") === "s1,s2", JSON.stringify(serviceLog.calls));
  check("H6b confirm 只弹一次", confirmCalls.length === 1, JSON.stringify(confirmCalls));
  check("H6c 归档不碰 host 删除路由", !fetchCalls.some((c) => c.path === "/obsidian/session-delete"));
  const toast = textOf(renderTree(ToastC, { t }));
  check("H6d 报归档数量", toast.includes(t("archivedPicked", { n: 2 })), `toast=${toast}`);
  tree = renderTree(Sidebar, sidebarProps());
  check("H6e 归档后清空勾选", checkedIds(tree).length === 0, JSON.stringify(checkedIds(tree)));
  check("H6f 归档执行后退出批量模式（工具条/勾选框消失）",
    findAll(tree, byExactClass("dsh-obs-batchbar")).length === 0
    && findAll(tree, byExactClass("dsh-obs-check")).length === 0);
}

// H7 批量彻底删除：一次请求送全部会话 id；删后隐藏行并刷新列表
resetScopes();
{
  serviceLog.calls.length = 0;
  fetchCalls.length = 0;
  confirmCalls.length = 0;
  confirmResult = true;
  attachedOnDelete = [];
  let tree = renderTree(Sidebar, sidebarProps());
  click(findAll(tree, byTitle(t("batchSessions")))[0]);
  tree = renderTree(Sidebar, sidebarProps());
  click(findAll(tree, byTitle(t("batchSelectAll")))[0]);
  tree = renderTree(Sidebar, sidebarProps());
  click(findAll(tree, byTitle(t("deletePicked")))[0]);
  await settle();
  const call = fetchCalls.find((c) => c.method === "POST" && c.path === "/obsidian/session-delete");
  check("H7a 一次请求送全部会话 id",
    call !== undefined && JSON.stringify([...call.body.ids].sort()) === JSON.stringify(["s1", "s2"]),
    JSON.stringify(call && call.body));
  check("H7b confirm 只弹一次", confirmCalls.length === 1, JSON.stringify(confirmCalls));
  check("H7c 删除后刷新 Host 会话列表", serviceLog.calls.some((c) => c[0] === "sessionsRefresh"));
  tree = renderTree(Sidebar, sidebarProps());
  check("H7d 删掉的行不再显示", !rowsOf(tree).some((r) => textOf(r).includes("会话一")), JSON.stringify(rowsOf(tree).map((r) => textOf(r))));
  check("H7e 删除后清空勾选", checkedIds(tree).length === 0, JSON.stringify(checkedIds(tree)));
  check("H7f 彻底删除执行后退出批量模式（工具条/勾选框消失）",
    findAll(tree, byExactClass("dsh-obs-batchbar")).length === 0
    && findAll(tree, byExactClass("dsh-obs-check")).length === 0);
}

// H8 取消批量：工具条/勾选框消失，单行动作恢复
resetScopes();
{
  let tree = renderTree(Sidebar, sidebarProps());
  click(findAll(tree, byTitle(t("batchWorkspaces")))[0]);
  tree = renderTree(Sidebar, sidebarProps());
  click(findAll(tree, byTitle(t("batchExit")))[0]);
  tree = renderTree(Sidebar, sidebarProps());
  check("H8a 取消批量 → 工具条/勾选框消失",
    findAll(tree, byExactClass("dsh-obs-batchbar")).length === 0
    && findAll(tree, byExactClass("dsh-obs-check")).length === 0);
  check("H8b 单行动作恢复",
    findAll(tree, byTitle(t("archiveSession"))).length === 2
    && findAll(tree, byTitle(t("delete"))).length === 2);
}

// H9 搜索与批量互斥：打开搜索退出批量；再点标题行按钮也可退出
resetScopes();
{
  let tree = renderTree(Sidebar, sidebarProps());
  click(findAll(tree, byTitle(t("batchWorkspaces")))[0]);
  tree = renderTree(Sidebar, sidebarProps());
  click(findAll(tree, byTitle(t("searchSessions")))[0]);
  tree = renderTree(Sidebar, sidebarProps());
  check("H9a 打开搜索 → 退出批量模式", findAll(tree, byExactClass("dsh-obs-batchbar")).length === 0);
  check("H9b 搜索框出现", findAll(tree, byClass("dsh-obs-search")).length === 1);
  click(findAll(tree, byTitle(t("searchSessions")))[0]);
  tree = renderTree(Sidebar, sidebarProps());
  click(findAll(tree, byTitle(t("batchWorkspaces")))[0]);
  tree = renderTree(Sidebar, sidebarProps());
  click(findAll(tree, byTitle(t("batchWorkspaces")))[0]);
  tree = renderTree(Sidebar, sidebarProps());
  check("H9c 再点标题行批量按钮 → 退出", findAll(tree, byExactClass("dsh-obs-batchbar")).length === 0);
}

// H10 会话批量模式下：点会话行/复选框都只是勾选，不打开会话
resetScopes();
{
  let tree = renderTree(Sidebar, sidebarProps());
  click(findAll(tree, byTitle(t("batchSessions")))[0]);
  tree = renderTree(Sidebar, sidebarProps());
  ctxUiWorkspaceCalls.length = 0;
  const row = rowsOf(tree).find((r) => textOf(r).includes("会话一"));
  click(row);
  tree = renderTree(Sidebar, sidebarProps());
  check("H10a 批量模式点会话行 = 勾选", checkedIds(tree).join(",") === "s1", JSON.stringify(checkedIds(tree)));
  check("H10b 不打开会话", !ctxUiWorkspaceCalls.some((c) => c[0] === "openSession"), JSON.stringify(ctxUiWorkspaceCalls));
  const box = findAll(tree, byExactClass("dsh-obs-check")).find((c) => c.props["data-id"] === "s1");
  box.props.onChange(event);
  tree = renderTree(Sidebar, sidebarProps());
  check("H10c 复选框 onChange 取消勾选", checkedIds(tree).length === 0, JSON.stringify(checkedIds(tree)));
}

// H11 批量会话模式下「未分组」行不提供批量入口（范围之外不做）
resetScopes();
{
  const tree = renderTree(Sidebar, sidebarProps());
  const ungroupedRow = findAll(tree, byExactClass("dsh-obs-ws-row")).find((r) => textOf(r).includes(t("ungrouped")));
  check("H11 未分组行没有批量入口", ungroupedRow !== undefined && findAll(ungroupedRow, byTitle(t("batchSessions"))).length === 0);
}

// ═════════════════════════ 汇总 ═════════════════════════
if (failures.length > 0) {
  console.error(`\n${failures.length} check(s) FAILED: ${failures.join(" | ")}`);
  process.exit(1);
}
console.log("\nall client interaction checks passed ✔");
