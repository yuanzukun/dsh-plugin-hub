// Headless fallback for hosts without a display, from issue #32.
//
// Reported from a Debian 13 box running `dsh web` as a systemd service: every `dsh_browser_*` call
// failed with "exited immediately after launch (exit code 1)", the browser never wrote
// DevToolsActivePort, and the underlying cause was "could not connect to display" — Chromium exits
// when neither DISPLAY nor WAYLAND_DISPLAY is set, and the launch args never asked for headless.
//
// The fix has to be a persistent setting, not a source patch: the reporter's own workaround edited
// node_modules and would be lost on the next update.
import { test } from 'node:test'
import assert from 'node:assert/strict'
import { mkdtempSync, readFileSync, rmSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'

import { createFakeBrowser } from './fixtures/fake-cdp-browser.mjs'
import { DEFAULT_SETTINGS, resolveSettings } from '../lib/browser-electron/settings-store.js'

const systemBrowser = readFileSync(new URL('../src/browser-electron/system-browser.ts', import.meta.url), 'utf8')
const settingsStore = readFileSync(new URL('../src/browser-electron/settings-store.ts', import.meta.url), 'utf8')

/** A child-process stub the launcher returns; the host only reads exit codes off it. */
function fakeChild(exited = false) {
  return { exitCode: exited ? 1 : null, signalCode: null, kill() {}, once() {}, on() {} }
}

/**
 * A host that records the arguments a launch would use, without running a browser.
 *
 * The launcher never returns a real process, so `start()` fails — but it has already built the args,
 * which is what these tests are about. A fake browser supplies the CDP side for the cases that need
 * a connected session.
 */
async function capturedArgs(headlessMode, quiet = false, exited = true) {
  const { SystemBrowserViewHost } = await import('../lib/browser-electron/system-browser.js')
  const seen = []
  const profile = mkdtempSync(join(tmpdir(), 'dsh-headless-args-'))
  const host = new SystemBrowserViewHost(
    { kind: 'chrome', path: 'fake-browser' },
    profile,
    [],
    undefined,
    (_path, args) => { seen.push(args); return fakeChild(exited) },
    headlessMode,
    () => quiet,
  )
  try {
    await host.createView().sendCommand('Runtime.evaluate', { expression: '1' })
  } catch {
    // Expected: the stub is not a browser. The arguments are the evidence.
  } finally {
    host.dispose?.()
    rmSync(profile, { recursive: true, force: true })
  }
  return seen[0] ?? []
}

test('a display-less host gets headless, a display gets a window', async () => {
  // The setting exists in the manifest, defaults to auto, and `auto` is resolved from the
  // environment rather than guessed.
  assert.match(settingsStore, /readonly headless: HeadlessMode/, 'the setting is declared')
  assert.equal(DEFAULT_SETTINGS.browser.headless, 'auto', 'and defaults to auto')
  assert.equal(DEFAULT_SETTINGS.browser.channel, 'sidebar', 'external windows require explicit opt-in')
  assert.equal(resolveSettings({ browser: {} }).browser.headless, 'auto', 'missing persisted settings retain auto')
  assert.match(settingsStore, /export type HeadlessMode = 'auto' \| 'headless' \| 'windowed'/,
    'three modes, not a boolean — a JSON document mixing strings and booleans is ambiguous')
  // Booleans are still accepted, because "headless: true" is what a person writes first.
  assert.match(settingsStore, /if \(value === true\) return 'headless'/, 'true maps to headless')
  assert.match(settingsStore, /if \(value === false\) return 'windowed'/, 'false maps to windowed')
  // And a display-less host must actually be detected, on POSIX only.
  assert.match(systemBrowser, /env\.DISPLAY/, 'DISPLAY is read')
  assert.match(systemBrowser, /env\.WAYLAND_DISPLAY/, 'WAYLAND_DISPLAY is read')
})

test('the headless launch carries the switches a server needs', async () => {
  // `--headless=new`, not the legacy flag: the new mode behaves like a windowed browser, which is
  // what every command here was measured against — including CDP input, which Chromium drops for a
  // view it believes has no display surface.
  const args = await capturedArgs('headless')
  assert.ok(args.includes('--headless=new'), `headless=new must be present: ${JSON.stringify(args)}`)
  assert.ok(args.includes('--disable-gpu'), 'no GPU on a server')
  assert.ok(args.includes('--disable-dev-shm-usage'), '/dev/shm is small in the environments that need this')
  // The CDP plumbing must survive the change.
  assert.ok(args.some(a => a.startsWith('--remote-debugging-port=')), 'debugging port still requested')
  assert.ok(args.some(a => a.startsWith('--user-data-dir=')), 'private profile still used')
})

test('a windowed launch is untouched', async () => {
  // Desktop and sidebar users must not lose the visible window they have today.
  const args = await capturedArgs('windowed')
  assert.ok(!args.includes('--headless=new'), `no headless flag when a window is wanted: ${JSON.stringify(args)}`)
  assert.ok(!args.includes('--disable-gpu'), 'and no headless-only switches')
  assert.ok(args.some(a => a.startsWith('--remote-debugging-port=')), 'still a drivable browser')
})

// `ui.quiet` describes how the agent presents its work (no activation, no raising, background
// targets), not whether the human may see a browser. Mapping quiet onto headless made an explicit
// `headless: windowed`/`headed` invisible on Chrome/Edge — reproduced with a real Edge, where
// navigation and screenshots worked but no window appeared, so the human could not take over a
// login or a challenge. The setting is the single source of truth, in both directions.
test('quiet mode does not take away a window the headless setting asked for', async () => {
  for (const mode of ['windowed', 'auto']) {
    // `exited` makes the stub child report an immediate exit, so start() stops at once
    // instead of waiting out its 30s discovery deadline; the captured args are the evidence.
    const args = await capturedArgs(mode, true, true)
    assert.ok(!args.includes('--headless=new'),
      `quiet + ${mode} must still get a window: ${JSON.stringify(args)}`)
    assert.ok(!args.includes('--disable-gpu'), `quiet + ${mode} needs no headless-only switches`)
  }
})

test('quiet mode does not override an explicitly headless setting either', async () => {
  const args = await capturedArgs('headless', true, true)
  assert.ok(args.includes('--headless=new'),
    `an explicit headless setting still wins while quiet: ${JSON.stringify(args)}`)
})

test('headless and container launches never automatically disable the sandbox', async () => {
  const previous = process.env.container
  process.env.container = 'docker'
  try {
    for (const mode of ['headless', 'windowed', 'auto']) {
      const args = await capturedArgs(mode)
      assert.ok(args.length > 0, 'the launcher was reached')
      assert.ok(!args.includes('--no-sandbox'), JSON.stringify(args))
      assert.ok(!args.includes('--disable-setuid-sandbox'), JSON.stringify(args))
    }
  } finally {
    if (previous === undefined) delete process.env.container
    else process.env.container = previous
  }
  assert.doesNotMatch(systemBrowser, /needsNoSandbox|--no-sandbox/)
})

test('an operator can override the setting without editing it', () => {
  // The reporter's point 4.3: a deployment must be fixable by restarting the process with an
  // environment variable, not by patching installed code.
  assert.match(systemBrowser, /DSH_BROWSER_HEADLESS/, 'the variable is read')
  const fn = systemBrowser.slice(systemBrowser.indexOf('function resolveLaunchMode('))
  const body = fn.slice(0, fn.indexOf('\n}'))
  assert.match(body, /override === '1' \|\| override === 'true'/, 'truthy values force headless')
  assert.match(body, /override === '0' \|\| override === 'false'/, 'falsy values force a window')
  // The override must be consulted BEFORE the mode, or a stored setting would win over the
  // operator's explicit emergency switch.
  assert.ok(body.indexOf('DSH_BROWSER_HEADLESS') < body.indexOf("mode === 'headless'"),
    'the override is checked before the configured mode')
})
