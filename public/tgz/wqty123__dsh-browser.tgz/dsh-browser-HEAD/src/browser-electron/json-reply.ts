/**
 * One JSON reply, written the same way by every route this plugin serves.
 *
 * Its own module rather than a helper inside one route file: there are four endpoints now, and the
 * second one that needed this had to import it from the live-view route — which reads as though the
 * readiness endpoints belong to the preview. They do not; only the header rules are shared.
 *
 * The header set is the substance, not boilerplate:
 * - `content-length` computed from the bytes actually written, so a proxy cannot truncate;
 * - `no-store` because every answer here is a reading of the current moment;
 * - `nosniff` + a same-origin resource policy, because these bodies name paths and pids.
 * @module dsh-browser/browser-electron/json-reply
 */
import type { OutgoingHttpHeaders, ServerResponse } from 'node:http'

/**
 * Write one JSON body with no caching and no sniffing.
 * @param response - the response to write.
 * @param status - the HTTP status.
 * @param body - anything JSON-serialisable.
 */
/**
 * Write an already-serialised JSON body with caller-supplied headers.
 *
 * Routes do not all need the same header set: readiness answers carry length and sniffing
 * headers, while the settings route has always returned only a content type and no-store.
 * Sharing the write keeps those exact header sets from drifting into each other.
 * @param response - the response to write.
 * @param status - the HTTP status.
 * @param text - the serialised body.
 * @param headers - the exact header set this route has always sent.
 */
export function writeJsonText(response: ServerResponse, status: number, text: string, headers: OutgoingHttpHeaders): void {
  response.writeHead(status, headers)
  response.end(text)
}

export function replyJson(response: ServerResponse, status: number, body: unknown): void {
  const text = JSON.stringify(body)
  writeJsonText(response, status, text, {
    'content-type': 'application/json; charset=utf-8',
    'content-length': Buffer.byteLength(text),
    'cache-control': 'no-store, private',
    'x-content-type-options': 'nosniff',
    'cross-origin-resource-policy': 'same-origin',
  })
}
