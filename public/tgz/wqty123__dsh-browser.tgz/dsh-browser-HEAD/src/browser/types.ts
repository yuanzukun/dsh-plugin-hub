/**
 * Vocabulary for the browser capability seam (`ctx.browser`). One seam owns
 * provider registration, session lifecycle, cancellation, errors, and product
 * configuration; providers differ only in what backs a session (an Electron
 * `WebContentsView` in the desktop shell, a headless Chromium relay for
 * remote deployments, and so on).
 * @module dsh-browser/browser/types
 */

import { HarnessError } from '@deepseek-ai/dsh-llm'

/**
 * Stable identity of one browser session, resolved by the Host through a
 * Typert `LookupMap` to the live session object (the same mechanism
 * `Agent → agentId` uses). The id is opaque to the wire; only the provider
 * and its host binding can interpret it.
 */
export type BrowserSessionId = import('./handles.ts').BrowserSessionWireId

/**
 * What one browser-capable backend is asked to do. Navigation is the minimal
 * operation every provider shares; the seam deliberately keeps the request
 * minimal so a provider swap never changes how the model asks.
 */
export interface BrowserNavigateRequest {
  /**
   * The URL to open. Admission (HTTP(S) only) is provider-owned; the seam
   * itself does not police credentials or private/localhost targets — a
   * shared real browser legitimately reaches local dev servers.
   */
  readonly url: string
}

/**
 * Click at viewport coordinates. Coordinates are viewport-relative pixels in
 * the session's own coordinate space — the same space the human interacts
 * with, so a real view and a relay agree without scaling.
 */
export interface BrowserClickRequest {
  /** Viewport-relative x in CSS pixels. */
  readonly x: number
  /** Viewport-relative y in CSS pixels. */
  readonly y: number
}

/**
 * A run of coordinate clicks in one call.
 *
 * Each point is clicked in order with the same real CDP sequence the single click uses. Between
 * points the call waits `intervalMs`, because a canvas that receives two presses inside one frame
 * treats them as a double click — or drops the second entirely, which looks like a silently wrong
 * board rather than an error.
 */
export interface BrowserClickSequenceRequest {
  /** Points to click, in order, in viewport CSS pixels. */
  readonly points: readonly { readonly x: number; readonly y: number }[]
  /** Milliseconds to wait between points; defaults to 40. */
  readonly intervalMs?: number
}

/** Result of a click run: how many landed, and where it stopped if it did not finish. */
export interface BrowserClickSequenceResult {
  /** Points that were clicked successfully. */
  readonly clicked: number
  /** Index of the point that failed, when one did. */
  readonly failedAt?: number
  /** Why that point failed. */
  readonly error?: string
}

/** Type text into the focused element. */
export interface BrowserTypeRequest {
  /** The text to insert. */
  readonly text: string
}

/** Scroll the page: by pixel deltas, to an element, or to top/bottom. */
export interface BrowserScrollRequest {
  /** Horizontal delta in CSS pixels. */
  readonly deltaX?: number
  /** Vertical delta in CSS pixels. */
  readonly deltaY?: number
  /** Scroll the given selector's element into view (top document; same-origin iframes reachable via execute). */
  readonly selector?: string
  /** Scroll to the top of the page. */
  readonly toTop?: boolean
  /** Scroll to the bottom of the page. */
  readonly toBottom?: boolean
}

/** Press one named key (Enter, Tab, arrows, …). */
export interface BrowserKeyRequest {
  /** Key name from the supported set (see the dsh_browser_key tool). */
  readonly key: string
}

/**
 * How to find one element for a targeted interaction (form controls, clicks,
 * typing). `text` matches an element's own visible text — exact first, then
 * contains, deepest element preferred (so a button inside a card wins over
 * the card itself).
 */
export interface BrowserElementTarget {
  /** Locator kind. */
  readonly by: 'css' | 'text' | 'xpath'
  /** The CSS selector / visible text / XPath expression. */
  readonly value: string
  /** 0-based index of the match to use. Default 0. */
  readonly index?: number
}

/** Set the value of one input/textarea/select/contenteditable. */
export interface BrowserSetValueRequest {
  /** The element to set (css/text/xpath). */
  readonly target: BrowserElementTarget
  /** The value to set (string, number, or boolean). */
  readonly value: string | number | boolean
  /** Element-lookup budget in ms. Default 5000. */
  readonly timeoutMs?: number
}

/** Result of a single setValue. */
export interface BrowserSetValueResult {
  /** How the value was applied: input | textarea | select | contenteditable. */
  readonly method: string
  /** The value as applied. */
  readonly value: string
}

/** Check/uncheck one checkbox or radio. */
export interface BrowserCheckRequest {
  /** The element to toggle (css/text/xpath). */
  readonly target: BrowserElementTarget
  /** Desired state. Default true (check). */
  readonly checked?: boolean
  /** Element-lookup budget in ms. Default 5000. */
  readonly timeoutMs?: number
}

/** Select one option of a `<select>`, by value, visible text, or index. */
export interface BrowserSelectRequest {
  /** The `<select>` element (css/text/xpath). */
  readonly target: BrowserElementTarget
  /** Match the option by its value attribute. */
  readonly optionValue?: string
  /** Match the option by its visible text. */
  readonly optionText?: string
  /** Match the option by its 0-based index. */
  readonly optionIndex?: number
  /** Element-lookup budget in ms. Default 5000. */
  readonly timeoutMs?: number
}

/** Result of a single select. */
export interface BrowserSelectResult {
  /** The selected option's value attribute. */
  readonly value: string
  /** The selected option's visible text. */
  readonly text: string
}

/** Clear one input/textarea/contenteditable (or uncheck a checkbox/radio). */
export interface BrowserClearRequest {
  /** The element to clear (css/text/xpath). */
  readonly target: BrowserElementTarget
  /** Element-lookup budget in ms. Default 5000. */
  readonly timeoutMs?: number
}

/** Read one element's current value (for verification). */
export interface BrowserGetValueRequest {
  /** The element to read (css/text/xpath). */
  readonly target: BrowserElementTarget
  /** Element-lookup budget in ms. Default 5000. */
  readonly timeoutMs?: number
}

/** Result of a getValue. */
export interface BrowserGetValueResult {
  /** The element's value; null when the element has none (e.g. a checkbox). */
  readonly value: string | null
  /** For checkbox/radio: the checked state. */
  readonly checked?: boolean
  /** For `<select>`: the selected option's visible text. */
  readonly selectedText?: string
}

/** One field of a scrape: a name plus a selector (optionally `selector@attr`). */
export interface BrowserScrapeField {
  /** Output key. */
  readonly name: string
  /**
   * CSS selector relative to each item; append `@attr` to take an attribute
   * instead of text (`a@href` returns an absolute URL for links).
   */
  readonly selector: string
}

/** Extract structured data from repeated DOM items (static, CSP-safe). */
export interface BrowserScrapeRequest {
  /** Required: CSS selector of each result container (e.g. `div.card`). */
  readonly item: string
  /** Field map: name -> selector[@attr]. */
  readonly fields: readonly BrowserScrapeField[]
  /** Wait budget for the item selector to appear. Default 5000. */
  readonly timeoutMs?: number
}

/** Structured extraction result. */
export interface BrowserScrapeResult {
  /** Number of items extracted. */
  readonly count: number
  /** One object per item; missing fields are null. */
  readonly items: readonly Record<string, string | null>[]
}

/** One field of a batch form fill. Match by selector, or by name/label/placeholder. */
export interface BrowserFillField {
  /** CSS selector; when present, candidates are scoped to it. */
  readonly selector?: string
  /** Match by the field's `name` attribute. */
  readonly name?: string
  /** Match by associated `<label>` text or `aria-label`. */
  readonly label?: string
  /** Match by `placeholder` text. */
  readonly placeholder?: string
  /** Field kind; defaults to text. */
  readonly kind?: 'text' | 'textarea' | 'checkbox' | 'radio' | 'select'
  /** Value to set: string, number, or boolean (checkbox/radio). For a
   *  multi-select or radio group, the option value (or visible text). */
  readonly value: string | number | boolean
}

/** Batch form fill: set several fields, optionally submitting the form. */
export interface BrowserFillRequest {
  /** The fields to fill, in order. */
  readonly fields: readonly BrowserFillField[]
  /** Submit the containing form after filling. Default false. */
  readonly submit?: boolean
  /** Per-field evaluation budget in ms. Default 30000. */
  readonly timeoutMs?: number
}

/** One field's outcome in a batch fill. */
export interface BrowserFillFieldResult {
  readonly ok: boolean
  /** The field description matched (selector/name/label/placeholder). */
  readonly target: string
  /** How the value was applied: input | textarea | select | checkbox | radio | contenteditable. */
  readonly method?: string
  /** Error text when the field could not be filled. */
  readonly error?: string
}

/** Outcome of a batch form fill. */
export interface BrowserFillResult {
  /** Per-field outcomes, in request order. */
  readonly fields: readonly BrowserFillFieldResult[]
  /** Whether the containing form was submitted. */
  readonly submitted: boolean
}

/** Wait request: poll until the page is ready (and optional URL/selector). */
export interface BrowserWaitRequest {
  /** Maximum wait in ms. Default 30000. */
  readonly timeoutMs?: number
  /**
   * Optional URL the top document must show (exact or prefix match). Pass the
   * URL you navigated to — this distinguishes the NEW document from the old
   * one still on screen while navigation is in flight.
   */
  readonly url?: string
  /** Optional CSS selector that must exist (top document or same-origin frames). */
  readonly selector?: string
  /** Wait for the page load (readyState complete). Default true. */
  readonly loaded?: boolean
}

/** Outcome of a wait: whether the condition was met before the budget ran out. */
export interface BrowserWaitResult {
  readonly ready: boolean
  /** Why the wait ended: 'condition met' or a short explanation of the miss. */
  readonly reason: string
}

/**
 * A screenshot of the current page state. `dataUrl` is a base64 data URL the
 * tool layer renders directly; the live view itself never crosses the wire
 * (the human watches the real view in the desktop shape).
 */
export interface BrowserScreenshotResult {
  /** Base64 data URL of the capture (PNG or JPEG per the request). */
  readonly dataUrl: string
  /** Pixel size of the image in `dataUrl`, when the capture was measured and scaled.
   *
   * Present when the request carried `maxWidth`/`maxHeight` and the layout metrics were
   * readable: the scaling happens inside CDP through a clip, and without this the only way to
   * learn what came back was to decode the data URL. Undefined means "not measured", which is
   * also what an unscaled capture reports. */
  readonly width?: number
  readonly height?: number
  /** File path the capture was also saved to, when the request asked for it. */
  readonly path?: string
}

/** Screenshot capture options. */
export interface BrowserScreenshotRequest {
  /** Capture the full scrollable page instead of the viewport. Default false. */
  readonly fullPage?: boolean
  /** Absolute file path to also save the image to (for vision-tool reads). */
  readonly savePath?: string
  /**
   * Image format. Default 'png'. JPEG is only available on the self-hosted
   * native capture path; the desktop-shell CDP fallback always returns PNG
   * (CDP JPEG hangs on Electron 43 — a documented platform defect).
   */
  readonly format?: 'png' | 'jpeg'
  /** JPEG quality 1-100 (default 80); ignored for PNG. */
  readonly quality?: number
  /** Downscale to fit within this width (aspect preserved). */
  readonly maxWidth?: number
  /** Downscale to fit within this height (aspect preserved). */
  readonly maxHeight?: number
  /**
   * Capture only this region, in document CSS pixels. Used by the reference
   * service for a masked visible-region snapshot; the tool layer does not
   * expose it, so ordinary screenshots keep their existing behaviour.
   */
  readonly clip?: {
    readonly x: number
    readonly y: number
    readonly width: number
    readonly height: number
  }
}

/** Download options: fetch a URL into a local file, keeping the session's cookies. */
export interface BrowserDownloadRequest {
  /** The URL to download. */
  readonly url: string
  /** Absolute path of the file to write. */
  readonly savePath: string
}

/** A serializable cookie, exported from or imported into the browser session. */
export interface ExportedCookie {
  /** Cookie URL (scheme + domain + path), as accepted by cookies.set. */
  readonly url: string
  readonly name: string
  readonly value: string
  readonly domain?: string
  readonly path?: string
  readonly secure?: boolean
  readonly httpOnly?: boolean
  readonly expirationDate?: number
}

/**
 * Execute arbitrary JavaScript in the session's page context. This is the
 * primary interaction path — DOM-referenced, not screen-coordinate-based:
 * focus/input/click go through the page's own JS (native setters for
 * framework-controlled inputs), matching how a human-driven agent operates.
 */
export interface BrowserExecuteRequest {
  /** The JavaScript expression to evaluate in the page context. */
  readonly script: string
  /** Optional arguments injected into the script scope as `arguments[0..n]`. */
  readonly args?: readonly unknown[]
  /** Evaluation budget in ms; a wedged page rejects with a timeout. Default 30000. */
  readonly timeoutMs?: number
}

/**
 * Fixed page operations implemented by the provider. Strings are serialized as data.
 * Arbitrary JavaScript is handled only by BrowserExecuteRequest.
 */
export type BrowserPageOperationRequest =
  | { readonly operation: 'install' }
  | { readonly operation: 'probe'; readonly method: BrowserProbeMethod; readonly args?: readonly unknown[] }
  | { readonly operation: 'text'; readonly text: string }
  | { readonly operation: 'url' }
  | { readonly operation: 'drag'; readonly from: { x: number; y: number }; readonly to: { x: number; y: number }; readonly steps: number }
  | { readonly operation: 'upload'; readonly target: { by: 'css' | 'text' | 'xpath'; value: string }; readonly file: { name: string; mime: string; base64: string } }

/** Provider-owned probe operations; JavaScript properties such as constructor are excluded. */
export type BrowserProbeMethod = 'read' | 'clear' | 'settle' | 'find' | 'overlayAt' | 'summary'
  | 'findText' | 'hoverAt' | 'setDialogPolicy' | 'dialogStatus' | 'networkCursor'

/**
 * Result of an execute. Mirrors CDP `Runtime.evaluate` semantics: either a
 * value (by value, not by reference) or the exception thrown.
 */
export type BrowserExecuteResult =
  | { readonly ok: true; readonly value: unknown }
  | { readonly ok: false; readonly exception: string }

/**
 * One interactive element in a snapshot, with a stable reference number the
 * tool layer (and the model) can cite to target the element.
 */
export interface BrowserSnapshotElement {
  /** 1-based reference number, stable for the lifetime of one snapshot. */
  readonly ref: number
  /** Element kind: 'input' | 'button' | 'link' | 'textarea' | 'select' | 'checkbox' | 'other'. */
  readonly kind: string
  /** Text content or placeholder/label, truncated for the snapshot. */
  readonly label: string
  /** Best-effort CSS selector; may be empty when none is derivable. */
  readonly selector: string
  /** Viewport-relative center, for coordinate fallbacks. */
  readonly x: number
  readonly y: number
  /**
   * True when the element lives inside an (same-origin) iframe: coordinates
   * are still top-document, but DOM selectors are frame-scoped — reach the
   * element via `iframe.contentDocument` in dsh_browser_execute.
   */
  readonly frame?: boolean
}

/**
 * AI-friendly page snapshot: a compact, numbered inventory of interactive
 * elements plus page facts. Not raw HTML — the model dialogues with this.
 */
export interface BrowserSnapshotResult {
  /** Final page URL. */
  readonly url: string
  /** Page title, if any. */
  readonly title?: string
  /** Numbered interactive elements. */
  readonly elements: readonly BrowserSnapshotElement[]
  /** True when the snapshot was truncated (element cap reached). */
  readonly truncated: boolean
  /** Human-verification challenge blocking the page, when one is detected. */
  readonly challenge?: BrowserChallenge
  /**
   * True when this is a blank page — no document to read, nothing to drive.
   *
   * Zero elements means two very different things: a page that genuinely has nothing interactive,
   * and a browser that has not opened anything at all. Without this flag they look identical, so a
   * caller can act on a blank page and get a success value back — reported as issue #37, where every
   * tool after a carrier swap answered against `about:blank` while appearing to work.
   *
   * Set for `about:blank` and for a view that has never navigated. A caller seeing it should treat
   * the page as absent, not as empty.
   */
  readonly blank?: boolean
  /** A sentence a caller can show instead of reporting an empty page as a successful read. */
  readonly note?: string
  /**
   * True when the page draws its interface on a canvas, so no DOM element exists to collect.
   *
   * Distinct from `blank`: the page is fully rendered and interactive, just not as elements. A
   * caller must switch to a screenshot and coordinate input rather than conclude the page is empty.
   */
  readonly canvas?: boolean
}

/**
 * One node of the accessibility tree, with a stable reference number the
 * model can cite. Roles/names prefer Chrome's `computedRole`/`computedName`
 * with tag/attribute inference as fallback; coordinates are top-document
 * viewport-relative so the node can also be driven by click/type.
 */
export interface BrowserA11yNode {
  /** 1-based reference number, stable for the lifetime of one a11y call. */
  readonly ref: number
  /** ARIA role: button | link | textbox | checkbox | radio | combobox | … */
  readonly role: string
  /** Accessible name (aria-label, label text, placeholder, own text, …). */
  readonly name: string
  /**
   * Current value of input-like nodes; absent when the node has none.
   *
   * The provider produces `null` for "not applicable" and the tool layer drops it, so absence
   * and null mean the same thing here — which is what the output schema declares (`string`,
   * not nullable). Saying `string | null` described the provider's internal shape rather than
   * the contract, and the two disagreed at every call.
   */
  readonly value?: string
  /** ARIA/DOM states: enabled/disabled/checked/unchecked/expanded/… */
  readonly states: readonly string[]
  /** DOM depth (within its document), for reconstructing the tree. */
  readonly depth: number
  /** Element tag name (lowercase). */
  readonly tag: string
  /**
   * A CSS selector for this node, when one can be derived from its id or name.
   *
   * Empty for the many elements that have neither. Present because a role and a name are not
   * always enough to target a node: `{by: 'text'}` matches an accessible name only loosely,
   * and this is what lets a caller point at the exact element it was shown.
   */
  readonly selector: string
  /** Viewport-relative center, for coordinate fallbacks. */
  readonly x: number
  readonly y: number
  /** True when the node lives inside a same-origin iframe. */
  readonly frame?: boolean
}

/** A11y tree request: what to include and how many nodes to return. */
export interface BrowserA11yRequest {
  /** Include hidden elements (display:none, hidden, aria-hidden). Default false. */
  readonly includeHidden?: boolean
  /** Maximum nodes returned. Default 500; clamped to 10-5000. */
  readonly maxNodes?: number
}

/** The page's accessibility tree, flattened into a numbered node list. */
export interface BrowserA11yResult {
  /** Final page URL. */
  readonly url: string
  /** Page title, if any. */
  readonly title?: string
  /** Number of nodes returned. */
  readonly count: number
  /** Flattened a11y nodes (depth restores the tree). */
  readonly nodes: readonly BrowserA11yNode[]
  /** True when the result was truncated (maxNodes reached). */
  readonly truncated: boolean
}

/**
 * A detected human-verification (bot-detection / CAPTCHA) challenge blocking
 * the page. Detection is best-effort and marker-based; a clean result is not a
 * guarantee that no challenge exists.
 */
export interface BrowserChallenge {
  /** Whether a challenge currently blocks the page. */
  readonly blocked: boolean
  /** Machine-readable kind: cloudflare | hcaptcha | recaptcha | turnstile | generic. */
  readonly kind?: string
  /** Short human-readable description, e.g. 'Cloudflare "Just a moment" interstitial'. */
  readonly reason?: string
}

/**
 * Content fetch formats. `html` is the raw DOM; `markdown` is a structured
 * reading view; `txt` is plain text (smallest); `json` is structured data.
 */
export type BrowserContentFormat = 'html' | 'markdown' | 'txt' | 'json'

/** Content fetch request: format, optional selector scoping, and caps. */
export interface BrowserContentRequest {
  /** Desired format. */
  readonly format: BrowserContentFormat
  /** Optional CSS selector limiting the fetch to one region (e.g. `#main`). */
  readonly selector?: string
  /** Maximum characters of the returned content. */
  readonly maxChars?: number
  /** Evaluation timeout in ms; the fetch aborts after this. Default 30000. */
  readonly timeoutMs?: number
}

/** A fetched page content in the requested format. */
export interface BrowserContentResult {
  /** The content in the requested format, capped at `maxChars`. */
  readonly content: string
  /** True when the content was truncated. */
  readonly truncated: boolean
}

/**
 * A tab inside a browser session. Tabs share the session's profile/cookies
 * and are switchable without losing state.
 */
export interface BrowserTab {
  /** Stable tab id within the session. */
  readonly id: import('./handles.ts').BrowserTabWireId
  /** Current URL, or empty for a blank tab. */
  readonly url: string
  /** Page title, if any. */
  readonly title?: string
  /** Whether this tab is the active one. */
  readonly active: boolean
}

/**
 * One passive preview frame: an encoded image plus its dimensions.
 *
 * The image is a data URL so it travels the existing JSON seam unchanged; the media type is part of
 * the URL rather than a separate field because every consumer needs them together.
 */
export interface BrowserPreviewFrame {
  readonly dataUrl: string
  readonly width?: number
  readonly height?: number
}

/** One page a carrier holds, whether or not this plugin created it. */
export interface CarrierPage {
  /** Canonical owner/session/tab identity used to address the page. */
  readonly id: import('./handles.ts').BrowserTabWireId
  readonly url: string
  readonly title?: string
}

/**
 * Why a carrier reported that it can no longer be used.
 *
 * Two different failures reach the same fallback, and saying which one is the difference between a
 * message a user can act on and one that misleads them:
 *
 * - `shell-exited`: the shell process behind the carrier is gone. Its published endpoint stops
 *   being refreshed, which is the condition the fallback was originally written for.
 * - `panel-unusable`: the shell is alive and answering, but its sidebar panel cannot provide a page
 *   — on a shell that renders that panel as an iframe there is no webContents and no CDP endpoint,
 *   so the carrier is undrivable rather than merely unready.
 *
 * The fallback announced the first of these unconditionally, so a `panel-unusable` fallback told
 * the user their desktop shell had exited while it was running normally. Reported as such.
 */
export type CarrierLossReason = 'shell-exited' | 'panel-unusable'

/** Request to open a URL: into the active tab or a new tab. */export interface BrowserOpenRequest {
  /** The URL to open. */
  readonly url: string
  /** Open in a new tab (parallel). Default false (reuse the active tab). */
  readonly newTab?: boolean
}

/**
 * A browser-capable backend. Registered with `ctx.browser.registerBrowserProvider`.
 * `id` is a stable string, unique across the seam.
 */
export interface BrowserProvider {
  readonly id: string
  /** Cheap local usability check; must not make network calls. */
  available(): boolean
  /**
   * Open a new session. The provider mints the session id and prepares its
   * backing surface (a view, a headless page, and so on). Sessions are isolated from
   * each other in what they OWN — tabs, the active tab, history, the view — so one
   * session must not be visible to any other session's caller.
   *
   * That isolation stops at the browser's own state, and is not meant to go further:
   * cookies, logins and site storage are deliberately shared by every session, because
   * every session drives the same browser and "sign in once, use it everywhere" is the
   * point of using a real one. Reads that hand that state to a caller (see
   * `flushAuth`) are scoped to the page in question, which is least exposure rather
   * than a claim that the jar is per-session.
   * @param label - optional human-readable label (e.g. the calling DSH task
   * id) the provider may surface on the visible surface (window title) so a
   * human can tell which task's page is currently shown.
   */
  open(label?: string): Promise<BrowserSessionId>
  /** Bind an existing carrier page to this session without navigating or creating a page. */
  bindPage?(session: BrowserSessionId, pageId: import('./handles.ts').BrowserTabWireId): Promise<void>
  /** Open a URL, optionally in a new tab. Honor `signal` for cancellation. */
  openUrl(session: BrowserSessionId, request: BrowserOpenRequest, signal?: AbortSignal): Promise<void>
  /** List the session's tabs. */
  listTabs(session: BrowserSessionId): Promise<readonly BrowserTab[]>
  /** Switch to a tab by id. Unknown id -> `BROWSER_TAB_UNKNOWN`. */
  switchTab(session: BrowserSessionId, tabId: import('./handles.ts').BrowserTabWireId): Promise<void>
  /** Close one tab. Closing the active tab activates the next. */
  closeTab(session: BrowserSessionId, tabId: import('./handles.ts').BrowserTabWireId): Promise<void>
  /** Close every tab and reset the session's state. */
  reset(session: BrowserSessionId): Promise<void>
  /** Navigate the active tab. Honor `signal` for cancellation. */
  navigate(session: BrowserSessionId, request: BrowserNavigateRequest, signal?: AbortSignal): Promise<void>
  /** Execute JS in the active tab's page context. */
  execute(session: BrowserSessionId, request: BrowserExecuteRequest, signal?: AbortSignal): Promise<BrowserExecuteResult>

  /** Execute one fixed browser operation without granting arbitrary page scripting. */
  pageOperation?(session: BrowserSessionId, request: BrowserPageOperationRequest, signal?: AbortSignal): Promise<BrowserExecuteResult>
  /** Wait until the page is ready (and optional URL/selector match). Honor `signal` for cancellation. */
  waitFor(session: BrowserSessionId, request: BrowserWaitRequest, signal?: AbortSignal): Promise<BrowserWaitResult>
  /** Produce an AI-friendly snapshot of the active tab. */
  snapshot(session: BrowserSessionId, signal?: AbortSignal): Promise<BrowserSnapshotResult>
  /** Read the active tab's accessibility tree (semantic, interactive nodes). */
  a11y(session: BrowserSessionId, request: BrowserA11yRequest, signal?: AbortSignal): Promise<BrowserA11yResult>
  /** Reload the active tab. Honor `signal` for cancellation. */
  reload(session: BrowserSessionId, signal?: AbortSignal): Promise<void>
  /** Check whether a human-verification challenge is blocking the active tab. */
  detectChallenge(session: BrowserSessionId, signal?: AbortSignal): Promise<BrowserChallenge>
  /** Fetch page content in a requested format. */
  content(session: BrowserSessionId, request: BrowserContentRequest, signal?: AbortSignal): Promise<BrowserContentResult>
  /**
   * Click at viewport coordinates, or at a located element's center when the
   * request carries a `target`. Honor `signal` for cancellation.
   */
  click(session: BrowserSessionId, request: BrowserClickRequest | { readonly target: BrowserElementTarget }, signal?: AbortSignal): Promise<void>
  /**
   * Click several points in order, in one round trip.
   *
   * Exists because a canvas page accepts only genuine input: one click per call meant two calls
   * per cell on a 9x9 board. Stops at the first point that fails rather than pressing through a
   * page that has moved under it, and reports how far it got.
   * @param session - the session to click in.
   * @param request - the points and the interval between them.
   * @param signal - cancellation between points.
   */
  clickSequence(session: BrowserSessionId, request: BrowserClickSequenceRequest, signal?: AbortSignal): Promise<BrowserClickSequenceResult>
  /**
   * Type into the focused element, or focus a located element first when the
   * request carries a `target`. Honor `signal` for cancellation.
   */
  type(session: BrowserSessionId, request: BrowserTypeRequest | { readonly target: BrowserElementTarget }, signal?: AbortSignal): Promise<void>
  /** Set one element's value (native setter + input/change events). */
  setValue(session: BrowserSessionId, request: BrowserSetValueRequest, signal?: AbortSignal): Promise<BrowserSetValueResult>
  /** Check or uncheck one checkbox/radio. */
  check(session: BrowserSessionId, request: BrowserCheckRequest, signal?: AbortSignal): Promise<{ readonly checked: boolean }>
  /** Select one option of a `<select>`. */
  selectOption(session: BrowserSessionId, request: BrowserSelectRequest, signal?: AbortSignal): Promise<BrowserSelectResult>
  /** Clear one input/textarea/contenteditable (or uncheck). */
  clearField(session: BrowserSessionId, request: BrowserClearRequest, signal?: AbortSignal): Promise<{ readonly cleared: boolean }>
  /** Read one element's current value (for verification). */
  getValue(session: BrowserSessionId, request: BrowserGetValueRequest, signal?: AbortSignal): Promise<BrowserGetValueResult>
  /** Extract structured data from repeated DOM items (static CSS, CSP-safe). */
  scrape(session: BrowserSessionId, request: BrowserScrapeRequest, signal?: AbortSignal): Promise<BrowserScrapeResult>
  /** Scroll the active tab. Honor `signal` for cancellation. */
  scroll(session: BrowserSessionId, request: BrowserScrollRequest, signal?: AbortSignal): Promise<void>
  /** Go back in the active tab's history. Honor `signal` for cancellation. */
  back(session: BrowserSessionId, signal?: AbortSignal): Promise<void>
  /** Go forward in the active tab's history. Honor `signal` for cancellation. */
  forward(session: BrowserSessionId, signal?: AbortSignal): Promise<void>
  /** Press one named key (Enter/Tab/arrows/…). Honor `signal` for cancellation. */
  key(session: BrowserSessionId, request: BrowserKeyRequest, signal?: AbortSignal): Promise<void>
  /** Fill a form's fields in one batch. Honor `signal` for cancellation. */
  fillForm(session: BrowserSessionId, request: BrowserFillRequest, signal?: AbortSignal): Promise<BrowserFillResult>
  /** Capture the current page. Honor `signal` for cancellation. */
  screenshot(session: BrowserSessionId, request?: BrowserScreenshotRequest, signal?: AbortSignal): Promise<BrowserScreenshotResult>
  /**
   * Capture the active page WITHOUT presenting it, for a remote live view (issue #34).
   *
   * Optional, and it must stay optional: a third-party provider that cannot do this simply does not
   * offer watching, while every existing tool keeps working. That is the design's requirement, not
   * a convenience — a mandatory member would make every provider implement a feature most never
   * need.
   *
   * The contract is narrower than {@link screenshot} in every direction: viewport only, no save
   * path, no full page, and no side effects on what the host displays. A provider that would have to
   * focus, restore, expand or recreate anything to produce a frame must throw
   * BROWSER_PREVIEW_UNAVAILABLE instead — the viewer shows a paused state, it does not rearrange the
   * host's screen.
   */
  capturePassive?(session: BrowserSessionId, signal?: AbortSignal): Promise<BrowserPreviewFrame>
  /**
   * The sessions a viewer may watch. Only meaningful alongside {@link capturePassive}.
   *
   * Exists because the provider names its sessions and the browser page cannot know one; served as
   * ids only, so the panel can address a session without being told what is in it.
   */
  watchableSessions?(): readonly BrowserSessionId[]
  /** Download a URL to a local file. Honor `signal` for cancellation. */
  download(session: BrowserSessionId, request: BrowserDownloadRequest, signal?: AbortSignal): Promise<{ readonly path: string }>
  /** Export the session's cookies (login state). */
  flushAuth(session: BrowserSessionId): Promise<readonly ExportedCookie[]>
  /** Import cookies into the session (restore login state). */
  restoreAuth(session: BrowserSessionId, cookies: readonly ExportedCookie[]): Promise<number>
  /** Return the session's chronological operation log. */
  history(session: BrowserSessionId): Promise<readonly BrowserHistoryEntry[]>
  /**
   * Persisted visits, newest first: what survives the browser process, so a
   * human or an Agent can find a page again after the interface was closed.
   * @param options - result cap and an optional hostname filter.
   * @returns the retained visits (empty when history is disabled).
   */
  visited(options?: { readonly limit?: number; readonly domain?: string }): readonly VisitedPage[]
  /**
   * Optional: whether a session is still live. A session can end outside the
   * tool layer — the human closed the browser window — so a cached id must be
   * checked before it is reused. Providers that never end a session on their own
   * can omit this, and callers treat absence as "still live".
   * @param session - the session id to test.
   */
  exists?(session: BrowserSessionId): boolean
  /** Replay one recorded operation by sequence number. */
  replay(session: BrowserSessionId, seq: number): Promise<void>
  /** Close the session and destroy its backing surface. Idempotent. */
  close(session: BrowserSessionId): Promise<void>
}

/**
 * One visited page in the persistent browsing history — the durable record that
 * outlives sessions, unlike {@link BrowserHistoryEntry}, which is a
 * session-scoped operation log (navigate/click/type/…).
 */
export interface VisitedPage {
  /** Epoch milliseconds when the visit was recorded. */
  readonly at: number
  /** Absolute URL of the visited document. */
  readonly url: string
  /** Document title at visit time, when the page exposed one. */
  readonly title?: string
  /** Session/task label that drove the visit, when the provider knows it. */
  readonly session?: string
}

/** One recorded browser operation, in chronological order (seq 1, 2, 3…). */
export interface BrowserHistoryEntry {
  /** Monotonic sequence number within the session. */
  readonly seq: number
  /** The operation name. Replayable: navigate | execute | click | type.
   *  Also recorded (non-replayable): fill | download | flushAuth | restoreAuth. */
  readonly action: string
  /** The operation's arguments. */
  readonly params: Record<string, unknown>
  /** Whether the operation succeeded. */
  readonly ok: boolean
  /** Truncated result text, when the operation returned one. */
  readonly result?: string
  /** Error text, when the operation failed. */
  readonly error?: string
  /** Epoch millis of the operation. */
  readonly at: number
}

/**
 * Typed browser error with a machine-routable, open-string `code` and chained
 * `cause`. Consumers must tolerate provider-specific codes. Shared codes cover
 * unavailable, missing, unusable, ambiguous, or duplicate providers, unknown
 * or closed sessions, cancellation, and provider failure; a provider adds its
 * own (e.g. `BROWSER_CDP_ATTACH_FAILED`).
 */
export class BrowserError extends HarnessError {}
