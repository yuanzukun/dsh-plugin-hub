import type { Context } from '@deepseek-ai/cordis'

export const name = 'dsh-ext-vision-proxy-invariant'
export const inject = ['invariants']

export function apply(ctx: Context): () => void {
  const invariants = ctx.get('invariants') as { register: (name: string, check: () => void) => () => void } | undefined
  if (invariants) {
    return invariants.register('dsh-ext-vision-proxy', () => {})
  }
  return () => {}
}
