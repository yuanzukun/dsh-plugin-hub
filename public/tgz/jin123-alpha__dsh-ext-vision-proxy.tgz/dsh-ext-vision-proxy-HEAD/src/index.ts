import type { Context } from '@deepseek-ai/cordis'
import { readFileSync, writeFileSync, existsSync, mkdirSync, statSync, readdirSync } from 'node:fs'
import { homedir } from 'node:os'
import { isAbsolute, resolve, join } from 'node:path'
import type { IncomingMessage, ServerResponse } from 'node:http'
import {
  SETTINGS_NS,
  DEFAULT_SETTINGS,
  type VisionProxySettings,
  type VisionProviderConfig,
  type VisionModelItem,
  deriveKeyRef,
} from './types.js'

export * from './types.js'

export const name = 'dsh-ext-vision-proxy'
export const inject = ['tools']
export const provide = ['visionProxy']

export type Config = Readonly<Record<string, never>>

const MIME_BY_EXT: Record<string, string> = {
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
  '.gif': 'image/gif',
}

function getStorageDir(): string {
  const base = process.env.DSH_HOME || join(homedir(), '.dsh')
  const dir = join(base, 'storages')
  try {
    mkdirSync(dir, { recursive: true })
  } catch {
    // ignore
  }
  return dir
}

function getSettingsFilePath(): string {
  return join(getStorageDir(), 'vision_proxy.json')
}

function getSecretsFilePath(): string {
  return join(getStorageDir(), 'vision_proxy_secrets.json')
}

function loadPersistedSettings(): VisionProxySettings {
  try {
    const file = getSettingsFilePath()
    if (existsSync(file)) {
      const data = JSON.parse(readFileSync(file, 'utf8'))
      if (data && typeof data === 'object' && Array.isArray(data.providers)) {
        return data as VisionProxySettings
      }
    }
  } catch {
    // fallback
  }
  return DEFAULT_SETTINGS
}

function savePersistedSettings(settings: VisionProxySettings): void {
  try {
    const file = getSettingsFilePath()
    writeFileSync(file, JSON.stringify(settings, null, 2), 'utf8')
  } catch (e) {
    console.error('Failed to write vision proxy settings to disk:', e)
  }
}

function loadPersistedSecrets(): Record<string, string> {
  try {
    const file = getSecretsFilePath()
    if (existsSync(file)) {
      return JSON.parse(readFileSync(file, 'utf8')) || {}
    }
  } catch {
    // fallback
  }
  return {}
}

function savePersistedSecrets(secrets: Record<string, string>): void {
  try {
    const file = getSecretsFilePath()
    writeFileSync(file, JSON.stringify(secrets, null, 2), 'utf8')
  } catch (e) {
    console.error('Failed to write vision proxy secrets to disk:', e)
  }
}

async function getCredentialValue(ctx: Context, ref: string): Promise<string> {
  if (!ref) return ''
  // 1. Try ctx.credentials if available
  const credsService = ctx.get('credentials') as any
  if (credsService?.resolve) {
    try {
      const res = await credsService.resolve(ref)
      if (res?.value) return res.value
    } catch {
      // ignore
    }
  }
  // 2. Try persisted secrets file
  const secrets = loadPersistedSecrets()
  if (secrets[ref]) return secrets[ref]
  // 3. Try process.env
  if (process.env[ref]) return process.env[ref]
  return ''
}

async function setCredentialValue(ctx: Context, ref: string, value: string): Promise<void> {
  if (!ref) return
  // 1. Try ctx.credentials if available
  const credsService = ctx.get('credentials') as any
  if (credsService?.set) {
    try {
      await credsService.set(ref, value)
    } catch {
      // ignore
    }
  }
  // 2. Save in persisted secrets file
  const secrets = loadPersistedSecrets()
  secrets[ref] = value
  savePersistedSecrets(secrets)
}

function isCredentialConfigured(ctx: Context, ref: string): boolean {
  if (!ref) return false
  const secrets = loadPersistedSecrets()
  if (secrets[ref] && secrets[ref].trim().length > 0) return true
  if (process.env[ref] && process.env[ref].trim().length > 0) return true
  return false
}

function detectMimeType(buffer: Buffer): string {
  if (
    buffer.length >= 8 &&
    buffer[0] === 0x89 &&
    buffer[1] === 0x50 &&
    buffer[2] === 0x4e &&
    buffer[3] === 0x47
  ) {
    return 'image/png'
  }
  if (buffer.length >= 3 && buffer[0] === 0xff && buffer[1] === 0xd8 && buffer[2] === 0xff) {
    return 'image/jpeg'
  }
  if (
    buffer.length >= 12 &&
    buffer.subarray(0, 4).toString('ascii') === 'RIFF' &&
    buffer.subarray(8, 12).toString('ascii') === 'WEBP'
  ) {
    return 'image/webp'
  }
  if (
    buffer.length >= 6 &&
    (buffer.subarray(0, 6).toString('ascii') === 'GIF87a' ||
      buffer.subarray(0, 6).toString('ascii') === 'GIF89a')
  ) {
    return 'image/gif'
  }
  if (buffer.length >= 2 && buffer[0] === 0x42 && buffer[1] === 0x4d) {
    return 'image/bmp'
  }
  return 'image/jpeg'
}

function findLatestAttachmentObject(baseDir: string): string | null {
  try {
    const v1ObjDir = join(baseDir, 'attachments', 'v1', 'objects')
    const searchDirs = [v1ObjDir, join(baseDir, 'attachments', 'objects')]
    let latestFile: string | null = null
    let latestMtime = 0

    for (const sDir of searchDirs) {
      if (!existsSync(sDir)) continue
      const prefixes = readdirSync(sDir)
      for (const prefix of prefixes) {
        const fullPrefix = join(sDir, prefix)
        if (!statSync(fullPrefix).isDirectory()) continue
        const files = readdirSync(fullPrefix)
        for (const file of files) {
          const fullFile = join(fullPrefix, file)
          const stat = statSync(fullFile)
          if (stat.isFile() && stat.mtimeMs > latestMtime) {
            latestMtime = stat.mtimeMs
            latestFile = fullFile
          }
        }
      }
    }
    return latestFile
  } catch {
    return null
  }
}

async function resolveImageToDataUrl(ctx: Context, imageInput: string): Promise<string> {
  let trimmed = (imageInput || '').trim()

  if (
    (trimmed.startsWith('"') && trimmed.endsWith('"')) ||
    (trimmed.startsWith("'") && trimmed.endsWith("'")) ||
    (trimmed.startsWith('`') && trimmed.endsWith('`'))
  ) {
    trimmed = trimmed.slice(1, -1).trim()
  }

  if (trimmed.startsWith('file://')) {
    trimmed = trimmed.replace(/^file:\/\/\/?/, '')
    if (/^\/[a-zA-Z]:/.test(trimmed)) {
      trimmed = trimmed.slice(1)
    }
  }

  if (trimmed.startsWith('data:image/')) {
    return trimmed
  }
  if (trimmed.startsWith('http://') || trimmed.startsWith('https://')) {
    return trimmed
  }

  // 1. Resolve attachment ID if input contains sha256:... or a 64-character hex string
  const sha256Match = /(?:sha256:)?([a-f0-9]{64})/i.exec(trimmed)
  const base = process.env.DSH_HOME || join(homedir(), '.dsh')

  if (sha256Match) {
    const sha256Hash = sha256Match[1].toLowerCase()

    // Check disk storage locations for content-addressed attachment
    const candidatePaths = [
      join(base, 'attachments', 'v1', 'objects', sha256Hash.slice(0, 2), sha256Hash),
      join(base, 'attachments', 'objects', sha256Hash.slice(0, 2), sha256Hash),
      join(base, 'attachments', sha256Hash),
    ]

    for (const objPath of candidatePaths) {
      if (existsSync(objPath)) {
        const buffer = readFileSync(objPath)
        const mime = detectMimeType(buffer)
        const b64 = buffer.toString('base64')
        return `data:${mime};base64,${b64}`
      }
    }
  }

  // 2. Resolve local file path
  try {
    const filePath = isAbsolute(trimmed) ? trimmed : resolve(process.cwd(), trimmed)
    if (existsSync(filePath) && statSync(filePath).isFile()) {
      const dotIndex = filePath.lastIndexOf('.')
      const ext = dotIndex >= 0 ? filePath.slice(dotIndex).toLowerCase() : ''
      const buffer = readFileSync(filePath)
      const mime = MIME_BY_EXT[ext] || detectMimeType(buffer)
      const base64 = buffer.toString('base64')
      return `data:${mime};base64,${base64}`
    }
  } catch {
    // ignore
  }

  // 3. Fallback: If image cannot be found by direct path/id, resolve to latest attachment
  const latestObj = findLatestAttachmentObject(base)
  if (latestObj && existsSync(latestObj)) {
    const buffer = readFileSync(latestObj)
    const mime = detectMimeType(buffer)
    const b64 = buffer.toString('base64')
    return `data:${mime};base64,${b64}`
  }

  throw new Error(`Vision proxy: image file not found at path "${trimmed}"`)
}

async function callOpenAIVisionApi(
  baseUrl: string,
  apiKey: string,
  model: string,
  imageUrl: string,
  prompt: string,
  signal?: AbortSignal,
): Promise<string> {
  const normalizedBase = baseUrl.replace(/\/+$/, '')
  const endpoint = `${normalizedBase}/chat/completions`

  const payload = {
    model,
    messages: [
      {
        role: 'user',
        content: [
          { type: 'text', text: prompt || 'Describe this image in detail.' },
          {
            type: 'image_url',
            image_url: {
              url: imageUrl,
            },
          },
        ],
      },
    ],
  }

  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
  }
  if (apiKey) {
    headers['Authorization'] = `Bearer ${apiKey}`
  }

  const response = await fetch(endpoint, {
    method: 'POST',
    headers,
    body: JSON.stringify(payload),
    signal,
  })

  if (!response.ok) {
    let errorDetail = ''
    try {
      const errJson = await response.json()
      errorDetail = typeof errJson === 'object' ? JSON.stringify(errJson) : String(errJson)
    } catch {
      try {
        errorDetail = await response.text()
      } catch {
        errorDetail = response.statusText
      }
    }
    throw new Error(
      `Vision API error: HTTP ${response.status} from ${endpoint}: ${errorDetail}`,
    )
  }

  const data = (await response.json()) as {
    choices?: Array<{
      message?: {
        content?: string
      }
    }>
  }

  const content = data.choices?.[0]?.message?.content
  if (!content) {
    throw new Error('Vision API returned empty response content.')
  }

  return content
}

async function readJsonBody(req: IncomingMessage): Promise<any> {
  const chunks: Buffer[] = []
  for await (const chunk of req) {
    chunks.push(Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk))
  }
  const text = Buffer.concat(chunks).toString('utf8')
  if (!text.trim()) return {}
  return JSON.parse(text)
}

const sessionVisionEnabledMap = new Map<string, boolean>()
const sessionVisionModelMap = new Map<string, string>()

export function isSessionVisionEnabled(sessionId: string): boolean {
  if (!sessionId) return sessionVisionEnabledMap.get('default') ?? false
  return sessionVisionEnabledMap.get(sessionId) ?? sessionVisionEnabledMap.get('default') ?? false
}

export function setSessionVisionEnabled(sessionId: string, enabled: boolean): void {
  sessionVisionEnabledMap.set(sessionId || 'default', enabled)
}

export function getSessionVisionModel(sessionId: string): string {
  if (!sessionId) return sessionVisionModelMap.get('default') ?? ''
  return sessionVisionModelMap.get(sessionId) ?? sessionVisionModelMap.get('default') ?? ''
}

export function setSessionVisionModel(sessionId: string, model: string): void {
  sessionVisionModelMap.set(sessionId || 'default', model)
}

function sendJson(res: ServerResponse, status: number, data: unknown): void {
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
  })
  res.end(JSON.stringify(data))
}

export function apply(ctx: Context): void {
  ctx.provide('visionProxy')
  // Expose visionProxy service on context for host apiproxy and session query
  ctx.set('visionProxy' as any, {
    isEnabled: (sessionId: string) => isSessionVisionEnabled(sessionId),
    setEnabled: (sessionId: string, val: boolean) => setSessionVisionEnabled(sessionId, val),
    getModel: (sessionId: string) => getSessionVisionModel(sessionId),
    setModel: (sessionId: string, model: string) => setSessionVisionModel(sessionId, model),
  })

  // Register HTTP API routes on webServer
  ctx.inject(['webServer'], (wctx: any) => {
    wctx.webServer.register({
      kind: 'prefix',
      path: '/api/dsh-ext-vision-proxy',
      handler: async (req: IncomingMessage, res: ServerResponse) => {
        const url = new URL(req.url || '/', 'http://localhost')
        const pathname = url.pathname.replace(/\/+$/, '')

        try {
          if (pathname === '/api/dsh-ext-vision-proxy/session-state') {
            if (req.method === 'GET') {
              const sessionId = url.searchParams.get('sessionId') || 'default'
              sendJson(res, 200, {
                ok: true,
                enabled: isSessionVisionEnabled(sessionId),
                selectedModel: getSessionVisionModel(sessionId),
              })
              return
            }

            if (req.method === 'POST') {
              const body = await readJsonBody(req)
              const sessionId = String(body.sessionId || 'default')
              if (typeof body.enabled === 'boolean') {
                setSessionVisionEnabled(sessionId, body.enabled)
              }
              if (typeof body.selectedModel === 'string') {
                setSessionVisionModel(sessionId, body.selectedModel)
              }
              sendJson(res, 200, { ok: true })
              return
            }
          }

          if (pathname === '/api/dsh-ext-vision-proxy/settings') {
            if (req.method === 'GET') {
              const settings = loadPersistedSettings()
              const credStates: Record<string, { configured: boolean }> = {}
              for (const p of settings.providers) {
                if (p.apiKeyRef) {
                  credStates[p.apiKeyRef] = {
                    configured: isCredentialConfigured(ctx, p.apiKeyRef),
                  }
                }
              }
              sendJson(res, 200, { ok: true, settings, credentialStates: credStates })
              return
            }

            if (req.method === 'POST') {
              const body = await readJsonBody(req)
              const newSettings = body.settings as VisionProxySettings
              if (newSettings && Array.isArray(newSettings.providers)) {
                savePersistedSettings(newSettings)
                const settingsService = ctx.get('settings') as any
                if (settingsService?.replace) {
                  try {
                    await settingsService.replace({ ns: SETTINGS_NS, section: newSettings })
                  } catch {
                    // ignore
                  }
                }
              }

              if (body.targetApiKeyRef && typeof body.targetApiKeyValue === 'string') {
                await setCredentialValue(ctx, body.targetApiKeyRef, body.targetApiKeyValue.trim())
              }

              sendJson(res, 200, { ok: true })
              return
            }
          }

          if (pathname === '/api/dsh-ext-vision-proxy/models' && req.method === 'POST') {
            const body = await readJsonBody(req)
            const baseUrl = String(body.baseUrl || '').replace(/\/+$/, '')
            let apiKey = String(body.apiKey || '')
            if (!apiKey && body.apiKeyRef) {
              apiKey = await getCredentialValue(ctx, body.apiKeyRef)
            }

            const endpoint = `${baseUrl}/models`
            const headers: Record<string, string> = {}
            if (apiKey) {
              headers['Authorization'] = `Bearer ${apiKey}`
            }

            const modelRes = await fetch(endpoint, { headers })
            if (!modelRes.ok) {
              throw new Error(`HTTP ${modelRes.status}: ${modelRes.statusText}`)
            }
            const data = await modelRes.json()
            const rawList = Array.isArray(data?.data) ? data.data : Array.isArray(data) ? data : []
            const fetchedModels: VisionModelItem[] = rawList.map((m: any) => {
              const id = typeof m === 'string' ? m : m.id || m.name || ''
              const lower = id.toLowerCase()
              const isVision =
                lower.includes('vision') ||
                lower.includes('4o') ||
                lower.includes('4-turbo') ||
                lower.includes('gemini') ||
                lower.includes('claude-3') ||
                lower.includes('vl') ||
                lower.includes('flash')
              return { id, visionCapable: isVision }
            })

            sendJson(res, 200, { ok: true, models: fetchedModels })
            return
          }

          if (pathname === '/api/dsh-ext-vision-proxy/probe' && req.method === 'POST') {
            const body = await readJsonBody(req)
            const baseUrl = String(body.baseUrl || '').replace(/\/+$/, '')
            const model = String(body.model || 'gpt-4o')
            let apiKey = String(body.apiKey || '')
            if (!apiKey && body.apiKeyRef) {
              apiKey = await getCredentialValue(ctx, body.apiKeyRef)
            }

            const TEST_PNG =
              'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAAAgCAIAAAAt/+nTAAAASklEQVR4nO3PwQ0AEAAEQX91qExfGvT2VwVHMskWsFNan19X4gcA6QOA9AFA+uA2YI16OgAAAAAAAAAAAAAAgDOA1wJIB5AOIN0GIn724TLtSY0AAAAASUVORK5CYII='

            const answer = await callOpenAIVisionApi(
              baseUrl,
              apiKey,
              model,
              TEST_PNG,
              'Respond with exactly "OK" if you can see this image.',
            )

            sendJson(res, 200, { ok: true, answer })
            return
          }

          sendJson(res, 404, { ok: false, error: 'Route not found' })
        } catch (err: any) {
          sendJson(res, 500, { ok: false, error: err.message || String(err) })
        }
      },
    })
  })

  // Dynamic system-prompt and tools visibility based on session vision switch
  ctx.on('system-prompt/assemble', async function (assembly, context, next) {
    const scope = context.scope as any
    const sessionId = scope?.id || scope?.session?.id || 'default'
    const enabled = isSessionVisionEnabled(sessionId)
    if (!enabled) {
      assembly.tools = assembly.tools.filter((t) => t.name !== 'vision_describe')
      assembly.sections = assembly.sections.filter((s) => s.name !== 'tool:vision_describe')
    }
    return next()
  })

  // Inject system prompt instruction if available
  ctx.inject(['systemPrompt'], (spCtx: any) => {
    spCtx.systemPrompt.section({
      name: 'tool:vision_describe',
      order: 100,
      text: (context: any) => {
        const scope = context?.scope as any
        const sessionId = scope?.id || scope?.session?.id || 'default'
        if (!isSessionVisionEnabled(sessionId)) return ''
        return 'Use the vision_describe tool to inspect, analyze, or answer questions about images, diagrams, screenshots, or attachments (pass the image path, attachment ID, or URL).'
      },
    })
  })

  // Register vision_describe tool
  const visionTool = {
    name: 'vision_describe',
    description:
      'Describe or answer questions about an image using a proxy vision model. Accepts a local image file path (e.g. C:\\... or /...), an attachment ID (sha256:...), or an HTTP/HTTPS/data: image URL.',
    parameters: {
      type: 'object',
      properties: {
        image: {
          type: 'string',
          description: 'Local file path, attachment ID, or image URL to analyze.',
        },
        prompt: {
          type: 'string',
          description:
            'Specific question or instructions for the vision model regarding the image. Defaults to "Describe this image in detail."',
        },
        model: {
          type: 'string',
          description:
            'Optional override of the vision model to use. If omitted, uses the default vision model from settings.',
        },
      },
      required: ['image'],
    },
    output: {
      schema: {
        type: 'object',
        properties: {
          description: {
            type: 'string',
            description: "The vision model's response/description of the image.",
          },
        },
        required: ['description'],
      },
      render: (_args: any, value: any) => [{ type: 'text', text: value.description }],
    },
    async execute(args: any, exec: any) {
      const agent = exec.agent as any
      const sessionId = agent?.id || agent?.session?.id || 'default'
      if (!isSessionVisionEnabled(sessionId)) {
        throw new Error('Vision proxy is currently disabled for this session. Please enable the Vision switch in the composer.')
      }

      const currentSettings = loadPersistedSettings()

      const activeProvider =
        currentSettings.providers?.find((p) => p.id === currentSettings.activeProviderId) ??
        currentSettings.providers?.[0] ??
        DEFAULT_SETTINGS.providers[0]

      const baseUrl = activeProvider.baseUrl || 'https://api.openai.com/v1'
      const apiKey = await getCredentialValue(ctx, activeProvider.apiKeyRef)

      let selectedModel = args.model
      if (!selectedModel) {
        selectedModel = getSessionVisionModel(sessionId) || activeProvider.defaultModel
      }
      if (!selectedModel) {
        const firstVision = activeProvider.models?.find((m) => m.visionCapable)?.id
        selectedModel = firstVision || activeProvider.models?.[0]?.id || 'gpt-4o'
      }

      const imageUrl = await resolveImageToDataUrl(ctx, args.image)
      const promptText = args.prompt || 'Describe this image in detail.'

      const description = await callOpenAIVisionApi(
        baseUrl,
        apiKey,
        selectedModel,
        imageUrl,
        promptText,
        exec.signal,
      )

      return { description }
    },
  }

  ctx.tools.register(visionTool as any)
}
