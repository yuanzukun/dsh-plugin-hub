/** Shared types and configuration keys for dsh-ext-vision-proxy. */

export const SETTINGS_NS = 'dsh-ext-vision-proxy'

/**
 * Derive a valid POSIX credential reference for a vision provider.
 * Must match /^[A-Za-z_][A-Za-z0-9_]*$/.
 */
export function deriveKeyRef(providerId: string): string {
  const safe = providerId.toUpperCase().replace(/[^A-Z0-9]+/g, '_')
  return `VISION_PROXY_${safe}_API_KEY`
}

export interface VisionModelItem {
  id: string
  visionCapable: boolean
}

export interface VisionProviderConfig {
  id: string
  name: string
  baseUrl: string
  apiKeyRef: string
  protocol?: string
  models: VisionModelItem[]
  defaultModel?: string
}

export interface VisionProxySettings {
  /** The currently active provider ID. */
  activeProviderId: string
  /** List of configured vision API providers. */
  providers: VisionProviderConfig[]
}

export const DEFAULT_SETTINGS: VisionProxySettings = {
  activeProviderId: 'default',
  providers: [
    {
      id: 'default',
      name: 'OpenAI Vision',
      baseUrl: 'https://api.openai.com/v1',
      apiKeyRef: deriveKeyRef('default'),
      protocol: 'openai-completions',
      models: [{ id: 'gpt-4o', visionCapable: true }],
      defaultModel: 'gpt-4o',
    },
  ],
}
