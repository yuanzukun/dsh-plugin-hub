# dsh-ext-vision-proxy

[English](README.md) | [简体中文](README.zh-CN.md)

> 为 [DeepSeek Harness](https://github.com/deepseek-ai/deepseek-harness) 设计的外部多模态视觉代理插件。通过无缝桥接 OpenAI 兼容的视觉模型 API，使 DeepSeek-V3 / DeepSeek-R1 等纯文本 LLM 获得强大的图片阅读、解析与问答能力。

---

## 📸 界面效果预览

### 1. 视觉代理配置面板（服务商管理与一键连通性测试）
![设置面板预览](docs/assets/settings-preview.png)

### 2. 对话输入框控制栏（经典胶囊开关与模型选择）
![输入框控制栏预览](docs/assets/composer-preview.png)

---

## 🌟 核心特性

- **🖼️ 纯文本大模型多模态赋能**：让 DeepSeek-V3 / R1 等纯文本模型能够自主调用 `vision_describe` 工具，精准识别并解答用户上传的图片、图表、截图或附件内容。
- **🔘 输入框原生控制开关**：在会话工具栏 (`conversation.input.left`) 中无缝嵌入经典风格的「视觉代理」开关与快速模型切换下拉面板。
- **⚙️ 完整的设置面板与连通性测试**：在设置页中提供独立的「视觉代理」配置板块，支持自定义 Base URL、API Key、模型能力过滤与一键连通性测试。
- **🎛️ 严谨的 4 状态会话矩阵**：
  1. **多模态 LLM + 开关开启**：`vision_describe` 工具可见。模型可自主决定是由代理模型识别还是走原生通道；附带图片提交时弹窗提醒用户。
  2. **多模态 LLM + 开关关闭**：工具不可见。模型通过 DSH 原生图片消息流处理图片，代理插件零干扰。
  3. **纯文本 LLM + 开关开启**：工具可见，放行图片上传。LLM 自动调用 `vision_describe` 工具传入附件 ID 或路径获取解析结果。
  4. **纯文本 LLM + 开关关闭**：工具不可见，阻断图片发送（提示切换支持图片的模型）。与未安装该插件时效果 100% 一致。
- **🔍 智能附件与图片寻址**：支持内容寻址哈希（`sha256:...`）、本地绝对/相对路径、HTTP/HTTPS URL，并通过文件二进制魔数自动识别 PNG/JPEG/WEBP/GIF/BMP 等格式。

---

## 🏗️ 架构设计

- **宿主端 (Node.js)**: `src/index.ts`
  - 注册 `vision_describe` 工具 Schema 与执行逻辑；
  - 基于 Cordis `system-prompt/assemble` 瀑布流拦截器，按会话动态剔除/暴露视觉工具与系统提示；
  - 在 `webServer` 上挂载设置管理、连通性探测及会话状态同步 REST API。
- **客户端 (React / 浏览器)**: `src/client/`
  - 注册 `settings.section` 插槽 (`VisionSettingsSection`) 用于服务商与 API Key 配置；
  - 注册 `conversation.input.left` 插槽 (`VisionComposerButton`) 提供输入框开关与模型快速选择。

---

## 📦 安装与构建

### 方式一：在 DSH Profile 中通过 Link 安装（开发推荐）

在 `~/.dsh/profiles/web/package.json` 中添加依赖和 bundle 项：

```json
{
  "dependencies": {
    "dsh-ext-vision-proxy": "link:/path/to/dsh-ext-vision-proxy"
  },
  "dsh": {
    "profile": {
      "bundles": [
        "@deepseek-ai/dsh-base",
        "@deepseek-ai/dsh-web-app",
        "dsh-ext-vision-proxy"
      ]
    }
  }
}
```

### 方式二：本地打包安装

```bash
# 安装依赖并编译打包
npm install
npm run build

# 打包为 tarball
npm pack
```

---

## 🚀 使用指南

1. **启动 DSH Web**：
   ```bash
   dsh web
   ```
2. **配置视觉 API**：
   - 在浏览器中打开 DSH Web（`http://127.0.0.1:3080`）；
   - 进入 **设置 (Settings) -> 视觉代理**；
   - 输入兼容 OpenAI 的视觉 API 基础地址（如 `https://api.openai.com/v1` 或中转服务地址）及 API Key；
   - 点击 **获取模型列表**，挑选默认视觉代理模型（如 `gpt-4o`、`gemini-2.5-flash`、`qwen-vl-max` 等）；
   - 点击 **测试连通性** 验证通过后点击保存。
3. **对话与图片识别**：
   - 在选用 DeepSeek-V3 或 DeepSeek-R1 的会话中，将输入框左侧的 **「视觉代理」** 开关切换为开启；
   - 上传或粘贴图片并输入问题（例如：“请详细描述这张图片的内容”）；
   - 模型将在后台调用 `vision_describe` 工具识别图像并给出详细解答。

---

## 📄 开源协议

[MIT](LICENSE) © 2026 Fan Yuejin
