import { readFile } from 'node:fs/promises'
import { basename, dirname, resolve as resolvePath } from 'node:path'

const CSS_VIRTUAL_PREFIX = '\0dsh-css:'
const CSS_VIRTUAL_SUFFIX = '.js'
const id = 'dsh-ext-vision-proxy'

function parseCssModules(cssText, fileId) {
  const hash = Math.abs(Array.from(fileId).reduce((h, c) => (h * 31 + c.charCodeAt(0)) | 0, 0)).toString(36).slice(0, 6)
  const classMap = {}
  const transformedCss = cssText.replace(/\.([a-zA-Z0-9_-]+)/g, (match, cls) => {
    const scoped = `dsh_vp_${hash}_${cls}`
    classMap[cls] = scoped
    return `.${scoped}`
  })
  return { transformedCss, classMap }
}

export default [
  {
    entry: ['src/index.ts', 'src/invariant.ts'],
    format: ['esm'],
    outDir: 'lib',
    clean: true,
    platform: 'node',
    dts: false,
    deps: {
      neverBundle: ['@deepseek-ai/cordis'],
    },
    outputOptions: {
      entryFileNames: '[name].js',
    },
  },
  {
    entry: {
      client: 'src/client/index.ts',
    },
    format: 'cjs',
    outDir: 'client',
    clean: false,
    platform: 'browser',
    dts: false,
    deps: {
      // These are seeded into the browser module table by the shell — never bundle them.
      neverBundle: [
        'react', 'react/jsx-runtime', 'react-dom', 'react-dom/client',
        '@deepseek-ai/cordis',
        '@deepseek-ai/dsh-client-ui-slots',
        '@deepseek-ai/dsh-client-web-react',
        '@deepseek-ai/dsh-client-ui-primitives',
        '@deepseek-ai/dsh-client-ui-attachment',
        '@deepseek-ai/dsh-client-schema-form',
      ],
      // Bundle everything else (local CSS modules, etc.) inline.
      alwaysBundle: true,
    },
    define: {
      'process.env.NODE_ENV': JSON.stringify('production'),
      'import.meta.env.MODE': JSON.stringify('production'),
      'import.meta.env': JSON.stringify({ MODE: 'production' }),
    },
    plugins: [
      {
        name: 'dsh-css-modules-inline',
        resolveId(source, importer) {
          if (!source.endsWith('.module.css')) return null
          const abs = importer !== undefined ? resolvePath(dirname(importer), source) : source
          return CSS_VIRTUAL_PREFIX + abs + CSS_VIRTUAL_SUFFIX
        },
        async load(virtualId) {
          if (!virtualId.startsWith(CSS_VIRTUAL_PREFIX)) return null
          const fileId = virtualId.slice(CSS_VIRTUAL_PREFIX.length, -CSS_VIRTUAL_SUFFIX.length)
          this.addWatchFile(fileId)
          const source = await readFile(fileId, 'utf8')
          const { transformedCss, classMap } = parseCssModules(source, fileId)
          return [
            `const css = ${JSON.stringify(transformedCss)};`,
            `const tagId = ${JSON.stringify(`${id}/${basename(fileId)}`)};`,
            'if (typeof document !== \'undefined\' && document.querySelector(\'style[data-plugin-css=\' + JSON.stringify(tagId) + \']\') === null) {',
            '  const tag = document.createElement(\'style\');',
            `  tag.dataset.plugin = ${JSON.stringify(id)};`,
            '  tag.dataset.pluginCss = tagId;',
            '  tag.textContent = css;',
            '  document.head.appendChild(tag);',
            '}',
            `module.exports = ${JSON.stringify(classMap)};`,
          ].join('\n')
        },
      },
    ],
    outputOptions: {
      entryFileNames: 'client.js',
      banner: `window.__ModuleLoader__.load({ id: ${JSON.stringify(id)}, factory: (require) => {`,
      footer: 'return module.exports; } });',
      intro: 'var module = { exports: {} }; var exports = module.exports;',
    },
  },
]
