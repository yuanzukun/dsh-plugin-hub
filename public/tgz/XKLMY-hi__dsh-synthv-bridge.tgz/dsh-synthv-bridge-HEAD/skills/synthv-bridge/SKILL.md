# synthv-bridge：Synthesizer V 调音桥接技能

> 通过 synthv-agent-bridge MCP（工具前缀 `mcp__synthv-agent-bridge__`）检查与编辑
> Synthesizer V Studio **Pro**（1.x/2.x）当前打开的工程。仅使用官方公开脚本 API。

## 0. 前置条件

1. 合法的 Synthesizer V Studio **Pro**（Basic 免费版无脚本菜单，不支持）。
2. 桥接 Lua 已装入 SV 脚本目录（`sv_bridge_install` 或面板一键安装）。
3. SV 中运行：`脚本 → 重新检查脚本 → SynthV Agent Bridge → Start SynthV Agent Bridge`（常驻，每个 SV 会话一次）。
4. `sv_status` 显示 connected 后才可写入；读取可在未连接时报错。

## 1. 六工具入口

| 工具 | 用途 |
|---|---|
| `sv_status` | 连接/会话/宿主/构建一致性状态；ping/reload/diagnostics |
| `sv_describe` | 列出能力面或某一 action 的参数结构（先查再调） |
| `sv_query` | 有界只读（readOnly / writeIntent 两种 contextMode） |
| `sv_command` | 有界写入（返回 outcome/changedCount/verified/contextId） |
| `sv_ui` | 选区、视口、坐标、播放控制 |
| `sv_review` | 可选侧边栏运行时状态（未装侧边栏时按无数据处理） |

**优先用两个便捷工具**（一步完成读-改-写-验证，无需 describe/contextId/fingerprint 多步流程）：

| 工具 | 用途 |
|---|---|
| `sv_tune_curve` | 音高线（自动化曲线，默认 PitchDelta）通用编辑：`read`（读区间点）/ `set`（设点，可先清区间）/ `clear`（清区间）/ `shift`（整体偏移 valueOffset cents）/ `scale`（缩放 factor）/ `level`（拉平到 value）/ `ramp`（生成 startValue→endValue 余弦斜坡，steps 点）/ `flattenFalloff`·`flattenAttack`·`flattenBoth`（对音符填平缓出/渐入，noteIndices 显式指定或自动筛选短促非句尾音符）。参数：trackIndex、groupIndex、parameter、rangeBegin/rangeEnd（blick）等。 |
| `sv_tune_attributes` | 音符过渡参数批量编辑：`field`（tF0Left 渐入时长 / tF0Right 缓出时长（秒）/ dF0Left / dF0Right（cents）/ dF0Vbr 颤音深度）+ `value` + `noteIndices`。 |

自动音高生成的逐音符音高线 = PitchDelta 自动化的密集曲线点（短音符音头渐入、音尾缓出各占约 25% 时长的点）；「填平缓出」等需求用 `sv_tune_curve` 的 flatten 预设或 read→shift/level 组合完成。

## 2. 核心写入约定

- **写前读**：sv_query 读目标（建议 `contextMode: writeIntent`）拿 `contextId`；sv_command 带上它，桥接校验新鲜度，防覆盖用户改动。
- **索引 1 基**：trackIndex/groupIndex/noteIndex 全部从 1 开始。
- **undo 边界**：每个 sv_command 成功写入 = 一个 SV 撤销记录（Ctrl+Z 可回退一步）。
- **verified**：普通写入返回 `verified: true` 后可信任；`undoRequired: true` 时按提示先撤销。
- **错误码速查**：`UNSUPPORTED_HOST_CAPABILITY`（宿主无此能力，换方案）、`STALE_*`（目标被改，重读）、`INVALID_ARGUMENT`（参数错）、`GROUP_NOT_FOUND`/`TRACK_NOT_FOUND`/`PARAMETER_NOT_FOUND`（定位错）、`BRIDGE_NOT_CONNECTED`（桥接没启动——提示用户 Start，**不要重装**）、`BRIDGE_TIMEOUT`（约 30 秒后返回，Lua 已停——先 `sv_status` 确认，**勿连续重试**）、`SYNTHV_SESSION_CHANGED`（SV 重启/桥接重载过——旧 contextId 全部失效，重新读目标再写）、`BUILD_MISMATCH`（脚本与插件版本不一致——重装脚本并让用户重新 Start）。
- **止损规则**：同一命令连续失败 2 次就停下来，先 `sv_status` 看连接与错误详情，再向用户报告原因和选项；**不要**无脑重试或擅自反复重装。

## 3. 常用 action 速查

| 意图 | action | 关键参数 |
|---|---|---|
| 工程信息 | `get_project_info` | - |
| 轨道列表 | `list_tracks` | - |
| 音符组列表 | `list_note_groups` | - |
| 读音符 | `get_track_notes` | trackIndex, groupIndex, 可选 offset/limit |
| 加音符 | `add_notes` | trackIndex, groupIndex, notes[{onset,duration,pitch,lyrics,...}], grouping |
| 编辑音符 | `edit_notes` | trackIndex, groupIndex, edits[{noteIndex, fingerprint, 修改字段}] |
| 批量变换 | `transform_notes` | 移调/时值/人性化等确定性批量 |
| 填歌词 | `fit_lyrics` | 音节到音符的对应 |
| 读自动化 | `get_automation` / `sample_automation` | groupIndex, parameter |
| 写自动化 | `set_automation_points` / `clear_automation` / `simplify_automation` | parameter, points |
| 整体调音 | `apply_group_tuning` | voice 参数/自动化/pitchControls（SV1 无 pitchControls 部分） |
| 表达式预设 | `apply_expression_preset` | Scoop/Falloff/Vibrato/Crescendo/Breathiness |
| 轨道/组管理 | `add_track` / `update_track` / `update_group` / `set_group_voice` | - |
| 选区/视口/播放 | sv_ui 系列 | - |

自动化参数（8 个，SV1/2 通用）：
`PitchDelta`(±1200) `VibratoEnv`(0~2) `Loudness`(-48~24) `Tension`(-2~2)
`Breathiness`(-2~2) `Voicing`(0~1) `Gender`(-2~2) `ToneShift`(±800)

## 4. SV1.x 宿主能力限制（重要）

| 缺失能力 | 替代方案 |
|---|---|
| AI Retake | 无（返回 UNSUPPORTED_HOST_CAPABILITY） |
| Smart Pitch 控制曲线 | 用 PitchDelta 自动化曲线表达音高偏移 |
| detune | 用 attributes（alt/dur/strength）或 PitchDelta 自动化 |
| 轨道混音器 | 无；响度用 Loudness 自动化 |
| getComputedPitchForGroup / getComputedAttributesForGroup | 用 get_automation 读 PitchDelta 等曲线；音素用 get_track_notes 的 phonemes 字段 |
| note attributes 大套字段（tF0* 等） | 仅 {alt, dur, strength} |

## 5. 唱法（Vocal Mode）约定

- 官方 API 读不到歌手身份与默认唱法。**需要唱法信息时**：请用户选中目标音符组和歌手，
  提供完整唱法面板截图（推荐）或按面板原拼写给出全部唱法名称；更换歌手后必须重新提供。
- 不涉及唱法的机械编辑（加音符、改歌词、写自动化）不需要这一步。

## 6. 验证流程（推荐）

1. 写入前读目标 → 2. sv_command（带 contextId）→ 3. 看 `verified` → 4.（可选）写后独立
   sv_query 复核 → 5. 报告改动 + 提醒用户试听、Ctrl+Z 可撤销。
