# NOTICE

## 合规声明

本插件（@xklmy/dsh-synthv-bridge）是 Synthesizer V 的**自动化桥接工具**，遵守以下原则：

1. **仅使用官方公开接口**：所有工程读写均通过 Synthesizer V Studio 官方公开的脚本 API
   （「脚本」菜单 / `SV` 全局 Lua API）完成。本插件不解析、不改写 `.svp` 工程文件，
   不打开网络端口对外暴露，不调用任何未公开的内部接口。
2. **不含任何破解内容**：本插件不包含、不依赖任何激活绕过、密钥生成、逆向工程产物或
   对授权检查的干预。用户必须自备合法授权的 Synthesizer V Studio **Pro**
   （Basic 免费版没有脚本菜单，不受支持）。
3. **上游运行时**：`vendor/bridge/` 内为开源项目
   [synthv-agent-bridge](https://github.com/SynthVCopilot/synthv-agent-bridge)
   的构建产物（Apache-2.0），并含针对 SV1.x 的兼容性修改（版本门禁放宽、缺失 API
   优雅降级）。其许可证全文见 `vendor/bridge/LICENSE`。
4. **本插件自身**：BSD-3-Clause（见仓库 LICENSE）。
5. 用户对在自己机器上运行脚本自动化所产生的结果负责；合成音频的版权归属遵循
   Synthesizer V 用户协议的约定。
6. **商标与关联声明**：Synthesizer V 与 Synthesizer V Studio 是 Dreamtonics 的产品与商标。
   本独立项目与 Dreamtonics 无关联，亦未获得其背书。

## 致谢

架构灵感来自 [ocadaruma/mcp-svstudio](https://github.com/ocadaruma/mcp-svstudio)
（Haruki Okada 的概念验证：「本地 MCP 服务器 + SV 内常驻 Lua 脚本」文件通信路线）；
上游 [synthv-agent-bridge](https://github.com/SynthVCopilot/synthv-agent-bridge)
在此之上重实现了请求关联、校验、过期上下文保护、撤销记录、跨平台路径与完整工具面；
本插件进一步完成 SV1 兼容与 DSH 生态封装。
