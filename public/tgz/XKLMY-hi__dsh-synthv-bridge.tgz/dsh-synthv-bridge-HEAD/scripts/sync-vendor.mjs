#!/usr/bin/env node
/**
 * sync-vendor.mjs — 从上游 synthv-agent-bridge 仓库同步 vendor 运行时。
 * 拷贝：dist/（Node MCP 运行时）、synthv/（Lua 脚本）、LICENSE（Apache-2.0）、package.json（依赖声明）。
 * 上游仓库位置：环境变量 SYNTHV_BRIDGE_UPSTREAM（必需，指向上游仓库根目录）。
 */
import { mkdirSync, copyFileSync, rmSync, readdirSync, statSync, existsSync, readFileSync } from 'node:fs'
import { join, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'

const pluginRoot = resolve(fileURLToPath(new URL('..', import.meta.url)))
const upstream = process.env.SYNTHV_BRIDGE_UPSTREAM
if (!upstream) {
  console.error('[sync-vendor] 请设置 SYNTHV_BRIDGE_UPSTREAM 指向上游 synthv-agent-bridge 仓库（需先在其内 npm run build）')
  process.exit(1)
}
const vendorRoot = join(pluginRoot, 'vendor', 'bridge')

if (!existsSync(join(upstream, 'dist', 'src', 'cli.js'))) {
  console.error(`[sync-vendor] 上游构建产物缺失：${join(upstream, 'dist', 'src', 'cli.js')}（先在上游 npm run build）`)
  process.exit(1)
}

rmSync(vendorRoot, { recursive: true, force: true })
mkdirSync(vendorRoot, { recursive: true })

const copyTree = (sourceDir, targetDir) => {
  mkdirSync(targetDir, { recursive: true })
  for (const entry of readdirSync(sourceDir)) {
    const sourcePath = join(sourceDir, entry)
    const targetPath = join(targetDir, entry)
    if (statSync(sourcePath).isDirectory()) {
      copyTree(sourcePath, targetPath)
    } else {
      copyFileSync(sourcePath, targetPath)
    }
  }
}

// dist/src/（Node MCP 运行时，排除测试）+ synthv/（Lua）+ LICENSE
copyTree(join(upstream, 'dist', 'src'), join(vendorRoot, 'dist', 'src'))
copyTree(join(upstream, 'synthv'), join(vendorRoot, 'synthv'))
if (existsSync(join(upstream, 'LICENSE'))) {
  copyFileSync(join(upstream, 'LICENSE'), join(vendorRoot, 'LICENSE'))
}

// 上游依赖声明写入 vendor（与插件 package.json dependencies 一致，装配时 hoist）
const upstreamPkg = JSON.parse(readFileSync(join(upstream, 'package.json'), 'utf8'))
const vendorPkg = {
  name: 'synthv-agent-bridge-vendor',
  version: upstreamPkg.version ?? '0.3.1',
  private: true,
  type: 'module',
  dependencies: {
    '@modelcontextprotocol/sdk': upstreamPkg.dependencies['@modelcontextprotocol/sdk'] ?? '1.29.0',
    zod: upstreamPkg.dependencies['zod'] ?? '4.4.3',
  },
}
const { writeFileSync } = await import('node:fs')
writeFileSync(join(vendorRoot, 'package.json'), JSON.stringify(vendorPkg, null, 2) + '\n')

console.log(`[sync-vendor] vendor 同步完成：${upstream} → ${vendorRoot}`)
console.log(`[sync-vendor] 上游版本：${upstreamPkg.version}`)
