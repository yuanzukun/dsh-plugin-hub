/**
 * @xklmy/dsh-synthv-bridge — client 状态面板（纯 DOM 直插模式）。
 *
 * 不注册 slot 组件（dsh 侧边栏与 conversation.view 没有插件可注册的组件槽），
 * 照 task-board 先例：侧边栏注入入口按钮（MutationObserver 自愈），点击切换
 * 一个 fixed 浮层状态卡，轮询 host API（/@xklmy/dsh-synthv-bridge/api）。
 * 纯 DOM（无 React 树），不干扰 shell reconciliation。
 */

interface BridgeStatus {
  connected: boolean
  fresh: boolean
  ageMs: number | null
  state: string | null
  hostName: string | null
  hostVersion: string | null
  projectFile: string | null
  error: string | null
}

interface FullStatus {
  bridge: BridgeStatus
  installs: { label: string; scriptsDir: string | null; installed: boolean }[]
  mcp: { serverName: string; tools: string[] }
  preset: string
  skill: string
}

export const inject: string[] = []

const ENTRY_SELECTOR = '[data-dsh-synthvbridge-entry]'
const PANEL_SELECTOR = '[data-dsh-synthvbridge-panel]'
const API_BASE = '/@xklmy/dsh-synthv-bridge/api'

const ICON = `<svg viewBox="0 0 16 16" width="14" height="14" fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 3h10M5 6h6M7.5 9h1M8 12V9"/></svg>`

let latest: FullStatus | null = null
let latestError: string | null = null
let panelOpen = false
const panelPainters = new Set<() => void>()

function sidebarRoot(): HTMLElement | undefined {
  const column = document.querySelector<HTMLElement>('[data-pane="sidebar"], [class*="sidebarCol"]')
  if (column === null) return undefined
  const logoOwner = column.querySelector<HTMLElement>('[class*="logoRow"]')?.parentElement
  return logoOwner ?? (column.firstElementChild as HTMLElement | undefined)
}

function newSessionButton(root: HTMLElement): HTMLButtonElement | undefined {
  const nested = root.querySelector<HTMLButtonElement>('button[class*="newSession"]')
  if (nested !== null) return nested
  for (const child of root.children) {
    if (child.tagName === 'BUTTON') return child as HTMLButtonElement
  }
  return undefined
}

function createEntry(): HTMLButtonElement {
  const entry = document.createElement('button')
  entry.type = 'button'
  entry.dataset.dshSynthvbridgeEntry = ''
  entry.setAttribute('aria-label', 'SV 桥接')
  entry.style.cssText = 'display:flex;align-items:center;gap:6px;width:100%;padding:6px 10px;border:none;background:transparent;color:inherit;cursor:pointer;font-size:12px;border-radius:6px;'
  entry.innerHTML = `<span style="display:inline-flex;width:14px;height:14px;">${ICON}</span><span>SV 桥接</span><span data-synthvbridge-dot="" style="margin-left:auto;width:8px;height:8px;border-radius:50%;background:#888;"></span>`
  entry.addEventListener('click', () => { togglePanel() })
  return entry
}

function placeEntry(root: HTMLElement, entry: HTMLButtonElement): boolean {
  const button = newSessionButton(root)
  if (button === undefined) return false
  if (entry.parentElement !== root) {
    const row = button.closest('[class*="logoRow"]')
    const base = (row !== null && row.parentElement === root) ? row : button
    const family = Array.from(root.children).filter(
      (el): el is HTMLElement => el instanceof HTMLElement && el.matches('[data-dsh-taskboard-entry], [data-dsh-ssh-entry], [data-dsh-synthvbridge-entry]'),
    )
    // 排在家族末尾（task-board 与 ssh 之后）
    if (family.length > 0) {
      const last = family[family.length - 1]
      root.insertBefore(entry, last.nextElementSibling)
    } else {
      root.insertBefore(entry, base.nextElementSibling)
    }
  }
  return true
}

function createPanel(anchor: HTMLButtonElement): HTMLElement {
  const panel = document.createElement('div')
  panel.dataset.dshSynthvbridgePanel = ''
  panel.style.cssText = 'position:fixed;z-index:4000;width:280px;max-height:60vh;overflow:auto;background:#1c1c20;color:#e8e8ea;border:1px solid #3a3a42;border-radius:10px;box-shadow:0 8px 28px rgba(0,0,0,.45);padding:12px;font-family:ui-monospace,monospace;font-size:12px;line-height:1.6;display:none;'

  const content = document.createElement('div')
  content.style.whiteSpace = 'pre-wrap'
  panel.appendChild(content)

  const installRow = document.createElement('div')
  installRow.style.cssText = 'display:flex;gap:6px;margin-top:8px;'
  const mkBtn = (label: string, target: string): HTMLButtonElement => {
    const btn = document.createElement('button')
    btn.textContent = label
    btn.style.cssText = 'padding:4px 8px;cursor:pointer;font-size:12px;background:#2a2a32;color:#e8e8ea;border:1px solid #444;border-radius:6px;'
    btn.addEventListener('click', () => { void installTo(target) })
    return btn
  }
  installRow.appendChild(mkBtn('装到 SV1 Pro', 'sv1'))
  installRow.appendChild(mkBtn('装到 SV2 Pro', 'sv2'))
  panel.appendChild(installRow)

  const stamp = document.createElement('div')
  stamp.style.cssText = 'color:#888;font-size:11px;margin-top:6px;'
  panel.appendChild(stamp)

  const paint = (): void => {
    if (latestError !== null) {
      content.textContent = latestError
      return
    }
    if (latest === null) {
      content.textContent = '加载中…'
      return
    }
    const b = latest.bridge
    const lines: string[] = []
    lines.push(b.connected ? '● 已连接' : '○ 未连接')
    if (b.hostName) lines.push(b.hostName + ' ' + (b.hostVersion ?? ''))
    if (b.projectFile) lines.push('当前工程：' + b.projectFile)
    if (b.error) lines.push('⚠ ' + b.error)
    lines.push('')
    for (const install of latest.installs) {
      lines.push((install.installed ? '✓' : '·') + ' ' + install.label.replace(' (Pro)', '') + (install.scriptsDir ? '' : '（未检测到）'))
    }
    content.textContent = lines.join('\n')
    stamp.textContent = b.ageMs !== null ? '上次更新 ' + Math.round(b.ageMs / 1000) + ' 秒前' : ''
    const dot = document.querySelector<HTMLElement>('[data-synthvbridge-dot]')
    if (dot !== null) {
      dot.style.background = b.connected ? '#4caf50' : '#888'
    }
  }
  panelPainters.add(paint)
  paint()
  return panel
}

function positionPanel(panel: HTMLElement, anchor: HTMLButtonElement): void {
  const rect = anchor.getBoundingClientRect()
  panel.style.left = Math.min(rect.right + 8, window.innerWidth - 300) + 'px'
  panel.style.top = Math.max(8, rect.top) + 'px'
}

function togglePanel(): void {
  panelOpen = !panelOpen
  const panel = document.querySelector<HTMLElement>(PANEL_SELECTOR)
  const entry = document.querySelector<HTMLElement>(ENTRY_SELECTOR)
  if (panel !== null && entry instanceof HTMLElement) {
    positionPanel(panel, entry as HTMLButtonElement)
    panel.style.display = panelOpen ? 'block' : 'none'
  }
}

async function fetchStatus(): Promise<void> {
  try {
    const res = await fetch(API_BASE)
    latest = (await res.json()) as FullStatus
    latestError = null
  } catch (err) {
    latestError = String(err)
  }
  for (const paint of panelPainters) paint()
}

async function installTo(target: string): Promise<void> {
  try {
    const res = await fetch(API_BASE + '/install/' + target, { method: 'POST' })
    const data = (await res.json()) as Record<string, unknown>
    latestError = JSON.stringify(data, null, 2)
  } catch (err) {
    latestError = '安装请求失败: ' + String(err)
  }
  for (const paint of panelPainters) paint()
  await fetchStatus()
}

let mounted = false

export function apply(): void {
  if (mounted) return
  mounted = true

  const entry = createEntry()
  const panel = createPanel(entry)
  document.body.appendChild(panel)

  const tryPlace = (): void => {
    const root = sidebarRoot()
    if (root === undefined) return
    placeEntry(root, entry)
  }

  const observer = new MutationObserver(() => {
    tryPlace()
    if (document.body.contains(panel) === false) document.body.appendChild(panel)
  })
  observer.observe(document.body, { childList: true, subtree: true })
  tryPlace()

  const timer = setInterval(() => { void fetchStatus() }, 5000)
  void fetchStatus()
  window.addEventListener('beforeunload', () => {
    clearInterval(timer)
    observer.disconnect()
  })
}
