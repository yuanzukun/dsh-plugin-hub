/**
 * 调音便捷工具：复用 vendor 内桥接的 FileIpcClient 直连文件 IPC，
 * 把音高线（自动化曲线）的任意编辑封装成一步调用。
 * 模型无需管理 describe/contextId/fingerprint——工具内部自动读指纹并带上。
 */
import { join } from 'node:path'
import { pathToFileURL } from 'node:url'
import { bundledBridgeRoot, ipcDirectory } from './paths.js'

interface IpcResponse {
  error?: { code?: string; message?: string; details?: unknown }
  fingerprint?: string
  points?: Array<{ position: number; value: number }>
  totalPointCount?: number
  pointCount?: number
  outcome?: string
  changedCount?: number
  verified?: boolean
  [key: string]: unknown
}

interface IpcClientLike {
  getStatus(): Promise<{ connected: boolean; reason?: string }>
  send(action: string, payload: Record<string, unknown>): Promise<IpcResponse>
}

let clientPromise: Promise<IpcClientLike> | null = null

async function ipcClient(): Promise<IpcClientLike> {
  if (!clientPromise) {
    clientPromise = (async () => {
      const bridgeRoot = bundledBridgeRoot()
      const configModule = await import(pathToFileURL(join(bridgeRoot, 'dist', 'src', 'config.js')).href)
      const clientModule = await import(pathToFileURL(join(bridgeRoot, 'dist', 'src', 'ipc', 'file-ipc-client.js')).href)
      const config = configModule.loadConfig(process.env, ipcDirectory())
      return new clientModule.FileIpcClient(config) as IpcClientLike
    })()
  }
  return clientPromise
}

export async function ensureBridgeConnected(): Promise<{ connected: boolean; reason?: string }> {
  const client = await ipcClient()
  const status = await client.getStatus()
  return { connected: status.connected, reason: status.reason }
}

async function readCurve(args: { trackIndex: number; groupIndex: number; parameter: string; rangeBegin?: number; rangeEnd?: number }): Promise<{ points: Array<{ position: number; value: number }>; fingerprint?: string; totalPointCount: number }> {
  const client = await ipcClient()
  const payload: Record<string, unknown> = {
    trackIndex: args.trackIndex,
    groupIndex: args.groupIndex,
    parameter: args.parameter,
    responseMode: 'full',
  }
  if (args.rangeBegin !== undefined && args.rangeEnd !== undefined) {
    payload.rangeBegin = args.rangeBegin
    payload.rangeEnd = args.rangeEnd
  }
  const response = await client.send('get_automation', payload)
  if (response.error) throw new Error(`${response.error.code}: ${response.error.message}`)
  return {
    points: (response.points ?? []) as Array<{ position: number; value: number }>,
    fingerprint: response.fingerprint,
    totalPointCount: (response.totalPointCount ?? response.pointCount ?? 0) as number,
  }
}

async function writePoints(args: { trackIndex: number; groupIndex: number; parameter: string; points: Array<{ position: number; value: number }>; clearMode?: string; rangeBegin?: number; rangeEnd?: number; expectedFingerprint?: string }): Promise<IpcResponse> {
  const client = await ipcClient()
  const payload: Record<string, unknown> = {
    trackIndex: args.trackIndex,
    groupIndex: args.groupIndex,
    parameter: args.parameter,
    clearMode: args.clearMode ?? 'none',
    points: args.points,
    responseMode: 'compact',
  }
  if (args.clearMode === 'range') {
    payload.rangeBegin = args.rangeBegin
    payload.rangeEnd = args.rangeEnd
  }
  if (args.expectedFingerprint) payload.expectedFingerprint = args.expectedFingerprint
  const response = await client.send('set_automation_points', payload)
  if (response.error) throw new Error(`${response.error.code}: ${response.error.message}`)
  return response
}

export interface CurveOpResult {
  ok: boolean
  operation: string
  error?: string
  points?: Array<{ position: number; value: number }>
  totalPointCount?: number
  changedCount?: number
  verified?: boolean
  appliedPointCount?: number
}

/**
 * 通用音高线（自动化曲线）编辑。operation：
 *  - read          读取区间内的曲线点（带整曲线指纹，供 agent 参考）
 *  - set           设置/更新点（points: [{position, value}]；可选 clearMode: range 先清区间）
 *  - clear         清除区间内的所有点（rangeBegin/rangeEnd）
 *  - shift         区间内所有点整体偏移 valueOffset（cents）
 *  - scale         区间内所有点按 factor 缩放（围绕 0）
 *  - level         区间内所有点拉平为 value（并确保区间两端各有一个点）
 *  - ramp          区间内生成斜坡：从 startValue 到 endValue（余弦/线性插值，steps 个点），先清原区间
 *  - flattenFalloff / flattenAttack / flattenBoth  便捷预设：对目标音符音尾/音头填平到主体值
 */
export async function tuneCurve(args: {
  trackIndex: number
  groupIndex?: number
  parameter?: string
  operation: string
  rangeBegin?: number
  rangeEnd?: number
  points?: Array<{ position: number; value: number }>
  value?: number
  valueOffset?: number
  factor?: number
  startValue?: number
  endValue?: number
  steps?: number
  clearMode?: string
  noteIndices?: number[]
  shortDurationBlick?: number
  tailGapBlick?: number
}): Promise<CurveOpResult> {
  const trackIndex = args.trackIndex
  const groupIndex = args.groupIndex ?? 1
  const parameter = args.parameter ?? 'PitchDelta'
  const client = await ipcClient()
  const status = await client.getStatus()
  if (!status.connected) {
    return { ok: false, operation: args.operation, error: status.reason ?? '桥接未连接' }
  }

  const op = args.operation

  // ── 便捷预设：flatten* ──
  if (op === 'flattenFalloff' || op === 'flattenAttack' || op === 'flattenBoth') {
    return flattenPreset(args, client, trackIndex, groupIndex, parameter, op)
  }

  // ── read ──
  if (op === 'read') {
    try {
      const curve = await readCurve({ trackIndex, groupIndex, parameter, rangeBegin: args.rangeBegin, rangeEnd: args.rangeEnd })
      return { ok: true, operation: op, points: curve.points, totalPointCount: curve.totalPointCount }
    } catch (error) {
      return { ok: false, operation: op, error: error instanceof Error ? error.message : String(error) }
    }
  }

  // ── set ──
  if (op === 'set') {
    if (!args.points || args.points.length === 0) {
      return { ok: false, operation: op, error: 'set 需要 points 列表' }
    }
    try {
      const curve = await readCurve({ trackIndex, groupIndex, parameter })
      const clearMode = args.clearMode ?? 'none'
      const write = await writePoints({
        trackIndex, groupIndex, parameter,
        points: args.points,
        clearMode,
        rangeBegin: args.rangeBegin,
        rangeEnd: args.rangeEnd,
        expectedFingerprint: curve.fingerprint,
      })
      return { ok: true, operation: op, changedCount: write.changedCount, verified: write.verified, appliedPointCount: args.points.length }
    } catch (error) {
      return { ok: false, operation: op, error: error instanceof Error ? error.message : String(error) }
    }
  }

  // ── clear ──
  if (op === 'clear') {
    if (args.rangeBegin === undefined || args.rangeEnd === undefined) {
      return { ok: false, operation: op, error: 'clear 需要 rangeBegin/rangeEnd' }
    }
    try {
      const curve = await readCurve({ trackIndex, groupIndex, parameter })
      const write = await writePoints({
        trackIndex, groupIndex, parameter,
        points: [],
        clearMode: 'range',
        rangeBegin: args.rangeBegin,
        rangeEnd: args.rangeEnd,
        expectedFingerprint: curve.fingerprint,
      })
      return { ok: true, operation: op, changedCount: write.changedCount, verified: write.verified }
    } catch (error) {
      return { ok: false, operation: op, error: error instanceof Error ? error.message : String(error) }
    }
  }

  // ── shift / scale / level / ramp（读-算-写） ──
  if (op === 'shift' || op === 'scale' || op === 'level' || op === 'ramp') {
    if (args.rangeBegin === undefined || args.rangeEnd === undefined) {
      return { ok: false, operation: op, error: `${op} 需要 rangeBegin/rangeEnd` }
    }
    try {
      const curve = await readCurve({ trackIndex, groupIndex, parameter, rangeBegin: args.rangeBegin, rangeEnd: args.rangeEnd })
      const inRange = curve.points.filter((p) => p.position >= args.rangeBegin! && p.position <= args.rangeEnd!)
      let newPoints: Array<{ position: number; value: number }> = []

      if (op === 'shift') {
        const offset = args.valueOffset ?? 0
        newPoints = inRange.map((p) => ({ position: p.position, value: p.value + offset }))
      } else if (op === 'scale') {
        const factor = args.factor ?? 1
        newPoints = inRange.map((p) => ({ position: p.position, value: p.value * factor }))
      } else if (op === 'level') {
        const value = args.value ?? 0
        newPoints = inRange.map((p) => ({ position: p.position, value }))
        // 确保区间两端有点，防止插值回弹
        const positions = new Set(newPoints.map((p) => p.position))
        if (!positions.has(args.rangeBegin!)) newPoints.push({ position: args.rangeBegin!, value })
        if (!positions.has(args.rangeEnd!)) newPoints.push({ position: args.rangeEnd!, value })
        newPoints.sort((a, b) => a.position - b.position)
      } else if (op === 'ramp') {
        const startValue = args.startValue ?? 0
        const endValue = args.endValue ?? 0
        const steps = Math.max(2, args.steps ?? 16)
        const span = args.rangeEnd! - args.rangeBegin!
        newPoints = []
        for (let i = 0; i < steps; i++) {
          const ratio = i / (steps - 1)
          const eased = 0.5 - 0.5 * Math.cos(ratio * Math.PI) // 余弦缓动
          newPoints.push({
            position: Math.round(args.rangeBegin! + span * ratio),
            value: startValue + (endValue - startValue) * eased,
          })
        }
      }

      // 写回：clearMode=range 先清原区间，再写入新点
      const write = await writePoints({
        trackIndex, groupIndex, parameter,
        points: newPoints,
        clearMode: 'range',
        rangeBegin: args.rangeBegin,
        rangeEnd: args.rangeEnd,
        expectedFingerprint: curve.fingerprint,
      })
      return { ok: true, operation: op, changedCount: write.changedCount, verified: write.verified, appliedPointCount: newPoints.length }
    } catch (error) {
      return { ok: false, operation: op, error: error instanceof Error ? error.message : String(error) }
    }
  }

  return { ok: false, operation: op, error: `未知 operation: ${op}` }
}

/** flatten* 便捷预设实现。 */
async function flattenPreset(
  args: Record<string, unknown>,
  client: IpcClientLike,
  trackIndex: number,
  groupIndex: number,
  parameter: string,
  op: string,
): Promise<CurveOpResult> {
  try {
    // 读音符
    const notesResponse = await client.send('get_track_notes', {
      trackIndex, groupIndex, offset: 0, limit: 1000, responseMode: 'full',
    })
    if (notesResponse.error) throw new Error(`${notesResponse.error.code}: ${notesResponse.error.message}`)
    const group = (notesResponse.groups as Array<Record<string, unknown>>)?.[0] ?? {}
    const notesPayload = group.notes as unknown
    const notes: Array<{ noteIndex: number; onset: number; duration: number }> = []
    if (Array.isArray(notesPayload)) {
      for (const n of notesPayload as Array<Record<string, unknown>>) {
        notes.push({ noteIndex: n.noteIndex as number, onset: n.onset as number, duration: n.duration as number })
      }
    } else if (notesPayload && typeof notesPayload === 'object' && 'rows' in (notesPayload as object)) {
      const rows = (notesPayload as { columns: string[]; rows: unknown[][] })
      const ix: Record<string, number> = {}
      rows.columns.forEach((c, i) => { ix[c] = i })
      for (const row of rows.rows) {
        notes.push({ noteIndex: row[ix.noteIndex] as number, onset: row[ix.onset] as number, duration: row[ix.duration] as number })
      }
    }

    const short = (args.shortDurationBlick as number) ?? 176400000
    const gapTol = (args.tailGapBlick as number) ?? 352800000
    let targets: Array<{ noteIndex: number; onset: number; duration: number }>
    if (Array.isArray(args.noteIndices) && (args.noteIndices as number[]).length > 0) {
      const byIndex = new Map(notes.map((n) => [n.noteIndex, n]))
      targets = (args.noteIndices as number[]).map((i) => byIndex.get(i)).filter((n) => n !== undefined) as typeof targets
    } else {
      targets = []
      for (let i = 0; i < notes.length; i++) {
        const note = notes[i]
        if (note.duration > short) continue
        const next = notes[i + 1]
        if (next && next.onset - (note.onset + note.duration) >= gapTol) continue
        targets.push(note)
      }
    }
    if (targets.length === 0) return { ok: true, operation: op, changedCount: 0, verified: true, appliedPointCount: 0 }

    const minOnset = Math.min(...targets.map((t) => t.onset))
    const maxEnd = Math.max(...targets.map((t) => t.onset + t.duration))
    const curve = await readCurve({ trackIndex, groupIndex, parameter, rangeBegin: minOnset, rangeEnd: maxEnd })

    const updates = new Map<number, number>()
    for (const note of targets) {
      const onset = note.onset
      const end = onset + note.duration
      const inner = curve.points.filter((p) => p.position > onset && p.position < end)
      if (inner.length === 0) continue
      const mid = inner.filter((p) => p.position > onset + note.duration * 0.25 && p.position < end - note.duration * 0.25)
      const body = (mid.length > 0 ? mid : inner)
      const values = body.map((p) => p.value).sort((a, b) => a - b)
      const bodyValue = values[Math.floor(values.length / 2)] ?? 0
      const headEdge = onset + note.duration * 0.25
      const tailEdge = end - note.duration * 0.25
      for (const p of inner) {
        let hit = false
        if (op === 'flattenFalloff' || op === 'flattenBoth') {
          if (p.position >= tailEdge) hit = true
        }
        if (op === 'flattenAttack' || op === 'flattenBoth') {
          if (p.position <= headEdge) hit = true
        }
        if (hit && Math.abs(p.value - bodyValue) > 0.001) updates.set(p.position, bodyValue)
      }
    }
    if (updates.size === 0) return { ok: true, operation: op, changedCount: 0, verified: true, appliedPointCount: 0 }
    const newPoints = Array.from(updates.entries()).map(([position, value]) => ({ position, value }))
    const write = await writePoints({
      trackIndex, groupIndex, parameter,
      points: newPoints,
      clearMode: 'none',
      expectedFingerprint: curve.fingerprint,
    })
    return {
      ok: true,
      operation: op,
      changedCount: write.changedCount,
      verified: write.verified,
      appliedPointCount: newPoints.length,
      points: newPoints.slice(0, 200),
    }
  } catch (error) {
    return { ok: false, operation: op, error: error instanceof Error ? error.message : String(error) }
  }
}

export interface TuneAttributesResult {
  ok: boolean
  editedNoteCount: number
  changedCount?: number
  verified?: boolean
  error?: string
}

/**
 * 音符参数便捷操作：批量修改指定音符的音高过渡属性
 * （tF0Left/tF0Right 渐入缓出时长（秒）、dF0Left/dF0Right 渐入缓出偏移（cents）、dF0Vbr 颤音深度）。
 */
export async function tuneAttributes(args: {
  trackIndex: number
  groupIndex?: number
  noteIndices: number[]
  field: string
  value: number
}): Promise<TuneAttributesResult> {
  const trackIndex = args.trackIndex
  const groupIndex = args.groupIndex ?? 1
  const allowed = new Set(['tF0Left', 'tF0Right', 'dF0Left', 'dF0Right', 'dF0Vbr'])
  if (!allowed.has(args.field)) {
    return { ok: false, editedNoteCount: 0, error: `field 必须是 ${Array.from(allowed).join('/')}` }
  }
  const client = await ipcClient()
  const status = await client.getStatus()
  if (!status.connected) {
    return { ok: false, editedNoteCount: 0, error: status.reason ?? '桥接未连接' }
  }

  const full = await client.send('get_track_notes', {
    trackIndex, groupIndex, offset: 0, limit: 1000, responseMode: 'full',
  })
  if (full.error) return { ok: false, editedNoteCount: 0, error: `${full.error.code}: ${full.error.message}` }
  const group = (full.groups as Array<Record<string, unknown>>)?.[0] ?? {}
  const notesPayload = group.notes as Record<string, unknown> | undefined
  const rawNotes: Array<{ noteIndex: number; attributes: Record<string, unknown>; fingerprint?: string }> = []
  if (notesPayload && 'rows' in notesPayload) {
    const rows = notesPayload as { columns: string[]; rows: unknown[][] }
    const ix: Record<string, number> = {}
    rows.columns.forEach((c, i) => { ix[c] = i })
    for (const row of rows.rows) {
      rawNotes.push({
        noteIndex: row[ix.noteIndex] as number,
        attributes: (row[ix.attributes] ?? {}) as Record<string, unknown>,
        fingerprint: row[ix.fingerprint] as string | undefined,
      })
    }
  } else {
    for (const n of (notesPayload as unknown as Array<Record<string, unknown>>) ?? []) {
      rawNotes.push({
        noteIndex: n.noteIndex as number,
        attributes: (n.attributes ?? {}) as Record<string, unknown>,
        fingerprint: n.fingerprint as string | undefined,
      })
    }
  }

  const edits: Array<Record<string, unknown>> = []
  for (const index of args.noteIndices) {
    const note = rawNotes.find((n) => n.noteIndex === index)
    if (!note) continue
    const attributes = { ...(note.attributes ?? {}) }
    attributes[args.field] = args.value
    edits.push({
      noteIndex: index,
      fingerprint: note.fingerprint,
      changes: { attributes },
    })
  }
  if (edits.length === 0) {
    return { ok: false, editedNoteCount: 0, error: '没有找到可编辑的目标音符（noteIndices 无效）' }
  }
  const write = await client.send('edit_notes', { trackIndex, groupIndex, edits })
  if (write.error) return { ok: false, editedNoteCount: edits.length, error: `${write.error.code}: ${write.error.message}` }
  return {
    ok: true,
    editedNoteCount: edits.length,
    changedCount: write.changedCount as number | undefined,
    verified: write.verified as boolean | undefined,
  }
}
