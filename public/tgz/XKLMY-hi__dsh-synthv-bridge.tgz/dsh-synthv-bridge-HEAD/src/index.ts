/**
 * @xklmy/dsh-synthv-bridge — Synthesizer V 调音桥接插件（host 半部）。
 *
 * 职责：
 * 1. webServer 前缀路由 /<pkg>/api —— 供 client 状态面板消费（桥接心跳/安装状态）。
 * 2. 工具注册：sv_bridge_status（读 IPC 状态）、sv_bridge_install（检测官方 SV
 *    安装并把桥接 Lua 脚本装进官方脚本目录）。
 * 3. 资产同步：presets/ → ~/.dsh/.agent-presets（「SV 调音模式」预设）、
 *    skills/ → ~/.dsh/skills（调音技能）。
 * 4. systemPrompt 公告段：告知 agent 本插件存在与使用约定。
 *
 * 合规声明：本插件仅调用 Synthesizer V 官方公开脚本 API（SV 脚本菜单），
 * 不解析/改写工程文件、不含任何激活绕过或逆向产物。需要用户自备合法的
 * Synthesizer V Studio **Pro**（1.x 或 2.x；Basic 免费版无脚本菜单，不支持）。
 * 上游桥接运行时：synthv-agent-bridge（Apache-2.0），vendor 于本包 vendor/bridge/。
 */
import { existsSync, mkdirSync, readFileSync, writeFileSync, copyFileSync, rmSync, readdirSync, statSync, appendFileSync } from 'node:fs'
import { join, dirname, resolve } from 'node:path'
import { homedir } from 'node:os'
import type { Context } from 'cordis'
import type {} from '@deepseek-ai/dsh-tools'
import type {} from '@deepseek-ai/dsh-system-prompt'
import z from 'schemastery'
import { defineTool } from '@deepseek-ai/dsh-tools'
import { dshHome, ipcDirectory, bridgeStatusFile, bundledBridgeRoot, bundledPresetsRoot, bundledSkillsRoot } from './paths.js'
import { tuneCurve, tuneAttributes, ensureBridgeConnected } from './tune-tools.js'

type AppContext = Context & {
  tools: { register(def: unknown): () => void }
  systemPrompt: { section(opts: { name: string; order: number; text: string }): () => void }
  webServer: {
    register(opts: {
      kind: 'prefix'
      path: string
      handler: (req: any, res: any) => void | Promise<void>
    }): () => void
  }
}

export const name = 'synthv-bridge'

/** 装配顺序依赖：公告段需要 prompt 装配，工具需要 tools，面板 API 需要 webServer。 */
export const inject = ['tools', 'systemPrompt', 'webServer']

export interface Config {
  enabled?: boolean
  announceToAgent?: boolean
}

export const Config: z<Config> = z.object({
  enabled: z.boolean().default(true),
  announceToAgent: z.boolean().default(true),
})

const SECTION_ORDER = 160

/** 模型可见公告：插件存在、原理与限制。 */
export const SYNTHV_BRIDGE_GUIDANCE =
  '本机已安装 dsh-synthv-bridge 插件（Synthesizer V 调音桥接）：把开源 synthv-agent-bridge 的 MCP 运行时（Apache-2.0）' +
  '接入 DSH，通过官方 Synthesizer V Studio Pro（1.x/2.x）的公开脚本 API 检查与编辑当前打开的工程。' +
  '提供六工具：sv_status/sv_describe/sv_query/sv_command/sv_ui/sv_review（前缀 mcp__synthv-agent-bridge__）。' +
  '新建会话预设选择器中有「SV 调音模式」，技能目录有 synthv-bridge 技能。' +
  '重要：脚本 API 是 Pro 专属（Basic 免费版无脚本菜单，不支持）；SV1.x 宿主缺 detune/AI Retake/Smart Pitch/轨道混音器/计算音素接口，' +
  '相关 action 会返回 UNSUPPORTED_HOST_CAPABILITY；索引一律 1 基；写操作需要用户先在 SV 里运行一次' +
  '「脚本 → SynthV Agent Bridge → Start SynthV Agent Bridge」启动常驻桥接。' +
  '用户提到「SV 调音 / SynthV / 歌声合成」时即指本插件，请据此协作。'

// 路径解析统一在 ./paths.ts（index 与 tune-tools 共用，避免循环依赖）。
export { dshHome, ipcDirectory, bridgeStatusFile, bundledBridgeRoot, bundledPresetsRoot, bundledSkillsRoot } from './paths.js'

export interface BridgeStatus {
  connected: boolean
  fresh: boolean
  ageMs: number | null
  state: string | null
  hostName: string | null
  hostVersion: string | null
  projectFile: string | null
  ipcDirectory: string | null
  error: string | null
}

export function readBridgeStatus(): BridgeStatus {
  const file = bridgeStatusFile()
  try {
    const raw = JSON.parse(readFileSync(file, 'utf8')) as Record<string, unknown>
    const updatedAt = typeof raw.updatedAtEpochMs === 'number' ? raw.updatedAtEpochMs : 0
    const ageMs = Date.now() - updatedAt
    const host = (raw.host ?? {}) as Record<string, unknown>
    return {
      connected: raw.state === 'running' && ageMs < 30_000,
      fresh: ageMs < 5_000,
      ageMs,
      state: (raw.state as string) ?? null,
      hostName: (host.hostName as string) ?? null,
      hostVersion: (host.hostVersion as string) ?? null,
      projectFile: (raw.projectFile as string) ?? null,
      ipcDirectory: (raw.ipcDirectory as string) ?? null,
      error: null,
    }
  } catch {
    return {
      connected: false, fresh: false, ageMs: null, state: null,
      hostName: null, hostVersion: null, projectFile: null, ipcDirectory: null,
      error: '无桥接心跳：请在 Synthesizer V 里运行「脚本 → SynthV Agent Bridge → Start SynthV Agent Bridge」',
    }
  }
}

/** 官方 SV 脚本目录候选（Pro 才有 scripts 目录）。 */
export interface SvInstall {
  label: string
  scriptsDir: string | null
  installed: boolean
}

export function detectSvInstalls(): SvInstall[] {
  // 数据目录解析顺序：显式环境变量覆盖 → 系统「我的文档」拼接（OneDrive/本地化系统可被覆盖）
  const docsEnv = process.env.SYNTHV_DOCUMENTS_DIR?.trim()
  const docs = docsEnv ? resolve(docsEnv) : join(homedir(), 'Documents')
  const overrideSv1 = process.env.SYNTHV_SCRIPTS_DIR_SV1?.trim()
  const overrideSv2 = process.env.SYNTHV_SCRIPTS_DIR_SV2?.trim()
  const candidates: SvInstall[] = [
    { label: 'Synthesizer V Studio 1.x (Pro)', scriptsDir: overrideSv1 ? resolve(overrideSv1) : join(docs, 'Dreamtonics', 'Synthesizer V Studio', 'scripts'), installed: false },
    { label: 'Synthesizer V Studio 2 (Pro)', scriptsDir: overrideSv2 ? resolve(overrideSv2) : join(docs, 'Dreamtonics', 'Synthesizer V Studio 2', 'scripts'), installed: false },
  ]
  for (const candidate of candidates) {
    if (candidate.scriptsDir) {
      const bridgeFile = join(candidate.scriptsDir, 'SynthV Agent Bridge', 'SynthVAgentBridge.lua')
      candidate.installed = existsSync(bridgeFile)
    }
  }
  return candidates
}

/** 从 vendor 的构建元数据里读出 executorBuildId（供 Lua 占位符替换，保证 Node/Lua 构建一致）。 */
export function readExecutorBuildId(): string {
  const metaFile = join(bundledBridgeRoot(), 'dist', 'src', 'generated-build-metadata.js')
  const text = readFileSync(metaFile, 'utf8')
  const match = /"executorBuildId"\s*:\s*"([^"]+)"/.exec(text)
  return match ? match[1] : ''
}

/** 把 vendor 内的桥接 Lua 装进目标 scripts 目录（替换构建占位符 + 写安装清单）。 */
export function installBridgeScripts(scriptsDir: string): { copied: string[]; destination: string; executorBuildId: string } {
  const source = join(bundledBridgeRoot(), 'synthv')
  const destination = join(scriptsDir, 'SynthV Agent Bridge')
  mkdirSync(destination, { recursive: true })
  const executorBuildId = readExecutorBuildId()
  const files = ['SynthVAgentBridge.lua', 'StopSynthVAgentBridge.lua']
  for (const file of files) {
    let text = readFileSync(join(source, file), 'utf8')
    if (executorBuildId) {
      text = text.replaceAll('__SYNTHV_AGENT_EXECUTOR_BUILD_ID__', executorBuildId)
    }
    writeFileSync(join(destination, file), text, 'utf8')
  }
  // 安装清单：Lua 热重载（reload）需要它来定位已安装脚本
  writeFileSync(
    join(ipcDirectory(), 'synthv-agent-bridge.install.json'),
    JSON.stringify({
      schemaVersion: 2,
      scriptFile: join(destination, 'SynthVAgentBridge.lua'),
      writtenAtEpochMs: Date.now(),
    }, null, 2) + '\n',
    'utf8',
  )
  return { copied: files, destination, executorBuildId }
}

/** 递归拷贝目录树（覆盖式同步，插件资产由插件维护）。 */
function syncTree(sourceRoot: string, targetRoot: string): { synced: string[] } {
  mkdirSync(targetRoot, { recursive: true })
  const synced: string[] = []
  const walk = (sourceDir: string, targetDir: string): void => {
    mkdirSync(targetDir, { recursive: true })
    for (const entry of readdirSync(sourceDir)) {
      const sourcePath = join(sourceDir, entry)
      const targetPath = join(targetDir, entry)
      if (statSync(sourcePath).isDirectory()) {
        walk(sourcePath, targetPath)
      } else {
        copyFileSync(sourcePath, targetPath)
        synced.push(entry)
      }
    }
  }
  walk(sourceRoot, targetRoot)
  return { synced }
}

/** 状态 JSON（面板 API 与工具共用）。 */
export function fullStatus() {
  return {
    bridge: readBridgeStatus(),
    installs: detectSvInstalls(),
    mcp: {
      serverName: 'synthv-agent-bridge',
      tools: ['sv_status', 'sv_describe', 'sv_query', 'sv_command', 'sv_ui', 'sv_review'],
    },
    preset: 'sv-tuning',
    skill: 'synthv-bridge',
  }
}

/** 把 MCP 条目写进本插件的 profile patch（幂等，重启后由装配加载）。 */
function ensureMcpEntryInProfilePatch(): { profile: string; added: boolean }[] {
  const results: { profile: string; added: boolean }[] = []
  const profilesRoot = join(dshHome(), 'profiles')
  let names: string[] = []
  try {
    names = readdirSync(profilesRoot)
  } catch {
    return results
  }
  const cliPath = join(bundledBridgeRoot(), 'dist', 'src', 'cli.js').replace(/\\/g, '/')
  const entry = [
    '',
    '# synthv-agent-bridge MCP（@xklmy/dsh-synthv-bridge 自动注册，重启 DSH 生效）',
    '- insert:',
    '    - id: mcp-synthv-agent-bridge',
    "      name: '@deepseek-ai/dsh-mcp-client'",
    '      config:',
    '        serverName: synthv-agent-bridge',
    '        transport: stdio',
    '        command: node',
    '        args:',
    `          - ${JSON.stringify(cliPath)}`,
    '        cwd: !!js process.cwd()',
    '',
  ].join('\n')
  for (const profile of names) {
    const patchFile = join(profilesRoot, profile, 'cordis.patch.yml')
    if (!existsSync(patchFile)) continue
    const manifestFile = join(profilesRoot, profile, 'package.json')
    let declares = false
    try {
      const manifest = JSON.parse(readFileSync(manifestFile, 'utf8')) as Record<string, unknown>
      const deps = (manifest.dependencies ?? {}) as Record<string, unknown>
      const bundles = Array.isArray(manifest.bundles) ? (manifest.bundles as string[]) : []
      declares = '@xklmy/dsh-synthv-bridge' in deps || bundles.includes('@xklmy/dsh-synthv-bridge')
    } catch {
      continue
    }
    if (!declares) continue
    const current = readFileSync(patchFile, 'utf8')
    if (current.includes('id: mcp-synthv-agent-bridge')) {
      results.push({ profile, added: false })
      continue
    }
    appendFileSync(patchFile, entry)
    results.push({ profile, added: true })
  }
  return results
}

export function apply(ctx: AppContext, config?: Config): void {
  const resolveConfig = (): Config => ({
    enabled: config?.enabled ?? true,
    announceToAgent: config?.announceToAgent ?? true,
  })

  // ── 1. 资产同步（preset + skill） ──────────────────────────────────────
  const syncAssets = (): void => {
    try {
      const presetRoot = join(dshHome(), '.agent-presets')
      const { synced: presets } = syncTree(bundledPresetsRoot(), presetRoot)
      const skillRoot = join(dshHome(), 'skills')
      const { synced: skills } = syncTree(bundledSkillsRoot(), skillRoot)
      ctx.logger?.info?.(`[synthv-bridge] assets synced: presets=${presets.length} skills=${skills.length}`)
    } catch (error) {
      ctx.logger?.warn?.(`[synthv-bridge] asset sync failed: ${error instanceof Error ? error.message : String(error)}`)
    }
    try {
      const patches = ensureMcpEntryInProfilePatch()
      for (const { profile, added } of patches) {
        if (added) ctx.logger?.info?.(`[synthv-bridge] MCP entry added to profile "${profile}" cordis.patch.yml（重启 DSH 生效）`)
      }
    } catch (error) {
      ctx.logger?.warn?.(`[synthv-bridge] MCP patch ensure failed: ${error instanceof Error ? error.message : String(error)}`)
    }
  }

  // ── 2. 面板 API 路由 ───────────────────────────────────────────────────
  ctx.effect(() => ctx.webServer.register({
    kind: 'prefix',
    path: '/@xklmy/dsh-synthv-bridge/api',
    handler: async (req: any, res: any) => {
      const sendJson = (value: unknown): void => {
        const text = JSON.stringify(value)
        res.writeHead(200, { 'content-type': 'application/json; charset=utf-8' })
        res.end(text)
      }
      const url: string = req.url ?? ''
      const pathname = url.split('?')[0]
      // 有副作用的安装路由：仅 POST + 严格枚举 target（防 CSRF/路径注入）
      if (pathname.startsWith('/@xklmy/dsh-synthv-bridge/api/install/')) {
        if ((req.method ?? 'GET') !== 'POST') {
          sendJson({ ok: false, error: '安装接口仅接受 POST 请求' })
          return
        }
        const target = pathname.slice('/@xklmy/dsh-synthv-bridge/api/install/'.length)
        if (target !== 'sv1' && target !== 'sv2') {
          sendJson({ ok: false, error: '目标版本必须是 sv1 或 sv2' })
          return
        }
        const installs = detectSvInstalls()
        const picked = target === 'sv1' ? installs[0] : installs[1]
        if (!picked?.scriptsDir) {
          sendJson({ ok: false, error: `未找到 ${target} 的脚本目录（可用 SYNTHV_SCRIPTS_DIR_SV1/SV2 环境变量覆盖）` })
          return
        }
        try {
          const result = installBridgeScripts(picked.scriptsDir)
          sendJson({ ok: true, ...result, hint: '在 SV 里「脚本 → 重新检查脚本」后运行 Start SynthV Agent Bridge' })
        } catch (error) {
          sendJson({ ok: false, error: error instanceof Error ? error.message : String(error) })
        }
        return
      }
      sendJson(fullStatus())
    },
  }), 'synthv-bridge: api')

  // ── 3. 工具：状态 ──────────────────────────────────────────────────────
  ctx.effect(() => ctx.tools.register(defineTool({
    name: 'sv_bridge_status',
    description: '读取本地 Synthesizer V 桥接状态：心跳连接、SV 宿主版本、当前工程文件、Lua 脚本安装情况与官方 SV 安装检测。',
    parameters: {},
    output: {
      schema: { type: 'json' },
      render: (_args: unknown, value: unknown) => [{ type: 'text', text: JSON.stringify(value, null, 2) }],
    },
    async execute() {
      return fullStatus() as any
    },
  })), 'synthv-bridge: status tool')

  // ── 4. 工具：安装 ──────────────────────────────────────────────────────
  ctx.effect(() => ctx.tools.register(defineTool({
    name: 'sv_bridge_install',
    description: '把桥接 Lua 脚本安装到官方 Synthesizer V Studio Pro 的脚本目录（sv1 或 sv2）。安装后在 SV 中「脚本 → 重新检查脚本 → SynthV Agent Bridge → Start SynthV Agent Bridge」启动。',
    parameters: {
      target: {
        type: 'string',
        required: true,
        enum: ['sv1', 'sv2'],
        description: '目标版本：sv1 = Synthesizer V Studio 1.x Pro；sv2 = Synthesizer V Studio 2 Pro。',
      },
    },
    output: {
      schema: { type: 'json' },
      render: (_args: unknown, value: unknown) => [{ type: 'text', text: JSON.stringify(value, null, 2) }],
    },
    async execute(args: { target: string }) {
      const installs = detectSvInstalls()
      const picked = args.target === 'sv1' ? installs[0] : installs[1]
      if (!picked?.scriptsDir) {
        return { ok: false, error: `未找到 ${args.target} 的官方数据目录（Basic 版无脚本目录，不受支持）`, installs } as any
      }
      try {
        const result = installBridgeScripts(picked.scriptsDir)
        return {
          ok: true,
          target: picked.label,
          ...result,
          hint: '在 SV 中「脚本 → 重新检查脚本」后运行「SynthV Agent Bridge → Start SynthV Agent Bridge」启动常驻桥接；改版后需重新安装并重启桥接。',
        } as any
      } catch (error) {
        return { ok: false, error: error instanceof Error ? error.message : String(error) } as any
      }
    },
  })), 'synthv-bridge: install tool')

  // ── 4.5 工具：音高线（自动化曲线）通用编辑 ──────────────────────────────
  ctx.effect(() => ctx.tools.register(defineTool({
    name: 'sv_tune_curve',
    description: '音高线（自动化曲线，默认 PitchDelta）通用编辑：一步完成读曲线/设点/清区间/整体偏移/缩放/拉平/拉坡/填平预设，无需 describe/contextId/fingerprint 多步流程。operation 取值：read（读区间点）、set（设置点，可选 clearMode=range 先清区间）、clear（清区间）、shift（区间整体偏移 valueOffset）、scale（区间按 factor 缩放）、level（区间拉平为 value）、ramp（区间生成 startValue→endValue 余弦斜坡，steps 个点）、flattenFalloff/flattenAttack/flattenBoth（对目标音符填平缓出/渐入，可 noteIndices 显式指定或自动筛选短促非句尾音符）。',
    parameters: {
      trackIndex: { type: 'number', required: true, description: '1 基轨道索引。' },
      groupIndex: { type: 'number', description: '1 基音符组索引，默认 1（主组）。' },
      parameter: { type: 'string', description: '自动化参数名，默认 PitchDelta（音高偏差）。' },
      operation: {
        type: 'string',
        required: true,
        enum: ['read', 'set', 'clear', 'shift', 'scale', 'level', 'ramp', 'flattenFalloff', 'flattenAttack', 'flattenBoth'],
        description: '曲线编辑操作。',
      },
      rangeBegin: { type: 'number', description: '操作区间起点（blick）。read/set/clear/shift/scale/level/ramp 需要。' },
      rangeEnd: { type: 'number', description: '操作区间终点（blick）。' },
      points: { type: 'array', items: { type: 'object', properties: { position: { type: 'number' }, value: { type: 'number' } }, additionalProperties: false }, description: 'set 操作的点列表 [{position, value}]。' },
      clearMode: { type: 'string', enum: ['none', 'range'], description: 'set 操作是否先清区间，默认 none。' },
      value: { type: 'number', description: 'level 操作的目标值。' },
      valueOffset: { type: 'number', description: 'shift 操作的偏移量（cents）。' },
      factor: { type: 'number', description: 'scale 操作的缩放系数。' },
      startValue: { type: 'number', description: 'ramp 起点值。' },
      endValue: { type: 'number', description: 'ramp 终点值。' },
      steps: { type: 'number', description: 'ramp 生成点数，默认 16。' },
      noteIndices: { type: 'array', items: { type: 'number' }, description: 'flatten* 操作的可选显式音符列表（1 基）。' },
      shortDurationBlick: { type: 'number', description: 'flatten* 自动筛选的「短促」阈值，默认 176400000。' },
      tailGapBlick: { type: 'number', description: 'flatten* 自动筛选的句尾间隙阈值，默认 352800000。' },
    },
    output: {
      schema: { type: 'json' },
      render: (_args: unknown, value: unknown) => [{ type: 'text', text: JSON.stringify(value, null, 2) }],
    },
    async execute(args: Record<string, unknown>) {
      return tuneCurve(args as Parameters<typeof tuneCurve>[0]) as any
    },
  })), 'synthv-bridge: tune-curve tool')

  // ── 4.6 工具：音符参数便捷操作 ──────────────────────────────────────────
  ctx.effect(() => ctx.tools.register(defineTool({
    name: 'sv_tune_attributes',
    description: '音符参数便捷操作：批量修改指定音符的音高过渡属性（tF0Left 渐入时长 / tF0Right 缓出时长 / dF0Left 渐入偏移 / dF0Right 缓出偏移 / dF0Vbr 颤音深度），一次调用完成读-改-写，其余字段保持原值。',
    parameters: {
      trackIndex: { type: 'number', required: true, description: '1 基轨道索引。' },
      groupIndex: { type: 'number', description: '1 基音符组索引，默认 1（主组）。' },
      noteIndices: { type: 'array', items: { type: 'number' }, required: true, description: '目标音符（1 基 noteIndex 列表）。' },
      field: { type: 'string', required: true, enum: ['tF0Left', 'tF0Right', 'dF0Left', 'dF0Right', 'dF0Vbr'], description: '要修改的过渡字段。' },
      value: { type: 'number', required: true, description: '目标值（tF0* 单位秒；dF0* 单位 cents）。' },
    },
    output: {
      schema: { type: 'json' },
      render: (_args: unknown, value: unknown) => [{ type: 'text', text: JSON.stringify(value, null, 2) }],
    },
    async execute(args: Record<string, unknown>) {
      return tuneAttributes(args as Parameters<typeof tuneAttributes>[0]) as any
    },
  })), 'synthv-bridge: tune-attributes tool')

  // ── 5. systemPrompt 公告 ───────────────────────────────────────────────
  let disposeSection: (() => void) | undefined
  const refresh = (): void => {
    disposeSection?.()
    disposeSection = undefined
    if (!resolveConfig().enabled) return
    syncAssets()
    if (resolveConfig().announceToAgent) {
      disposeSection = ctx.systemPrompt.section({
        name: 'plugin:dsh-synthv-bridge',
        order: SECTION_ORDER,
        text: SYNTHV_BRIDGE_GUIDANCE,
      })
    }
  }

  refresh()
  ctx.effect(() => () => { disposeSection?.(); disposeSection = undefined }, 'synthv-bridge: announcement')
}
