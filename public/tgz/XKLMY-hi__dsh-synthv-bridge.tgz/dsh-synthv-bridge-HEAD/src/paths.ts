/**
 * 路径工具：插件内共享的路径解析（供 index.ts 与 tune-tools.ts 共同使用，避免循环依赖）。
 */
import { join, resolve } from 'node:path'
import { homedir, tmpdir } from 'node:os'
import { fileURLToPath } from 'node:url'

/** DSH_HOME（web 进程 homedir 可能与 DSH_HOME 不一致；支持 ~ 展开与相对路径规范化）。 */
export function dshHome(): string {
  const raw = process.env.DSH_HOME || join(homedir(), '.dsh')
  const expanded = raw.startsWith('~/') || raw === '~' ? join(homedir(), raw.slice(1)) : raw
  return resolve(expanded)
}

/** IPC 目录：尊重 SYNTHV_AGENT_BRIDGE_DIR（与桥接 Node/Lua 两侧一致），否则系统临时目录。 */
export function ipcDirectory(): string {
  const configured = process.env.SYNTHV_AGENT_BRIDGE_DIR?.trim()
  if (configured) return resolve(configured)
  return tmpdir()
}

/** IPC 状态文件（与桥接 Lua/Node 两侧默认一致）。 */
export function bridgeStatusFile(): string {
  return join(ipcDirectory(), 'synthv-agent-bridge.status.json')
}

/** 包内 vendor/bridge 绝对路径（MCP CLI + Lua 源）。 */
export function bundledBridgeRoot(): string {
  return fileURLToPath(new URL('../vendor/bridge/', import.meta.url))
}

/** 包内 presets/ 绝对路径。 */
export function bundledPresetsRoot(): string {
  return fileURLToPath(new URL('../presets/', import.meta.url))
}

/** 包内 skills/ 绝对路径。 */
export function bundledSkillsRoot(): string {
  return fileURLToPath(new URL('../skills/', import.meta.url))
}
