import type { IncomingMessage, ServerResponse } from 'node:http';
import type { ProposalView } from '../shared/contracts';
import { deriveChecks } from './command-policy';
import type { GitRepositoryService, ShellService } from './git-repository-service';
import type { StoredProposal } from './proposal-service';
type UnknownRecord = Record<string, unknown>;
export interface WebServerService {
    register(definition: {
        kind: 'prefix';
        path: string;
        handler(req: IncomingMessage, res: ServerResponse): Promise<void>;
    }): unknown;
}
export interface ConnectionService {
    requestRejection(request: IncomingMessage): 401 | 403 | undefined;
}
interface ProposalVerification {
    changed: boolean;
    verified: boolean;
    partial: boolean;
    message: string;
    changedState: string;
}
interface RepositoryContext {
    workdir: string;
    policy: unknown;
}
interface LazyGitActionDependencies {
    repository: GitRepositoryService;
    proposalStorageReady: Promise<void>;
    requestAnalysis?(proposal: StoredProposal, persist: () => Promise<void>, retry: boolean): Promise<void>;
    cancelAnalysis?(sessionId: string): Promise<void>;
    chatStatus?(sessionId: string, since?: number): Promise<{
        running: boolean;
        reply: string;
        error?: string;
    }>;
    openChat?(sessionId: string): Promise<unknown>;
    generateCommitMessage?(sessionId: string, context: RepositoryContext): Promise<unknown>;
    shell: ShellService | null;
    repositoryContext(sessionId: string): Promise<RepositoryContext | null>;
    latestPending(sessionId: string): StoredProposal | null;
    findProposal(sessionId: string, proposalId: unknown): StoredProposal | undefined;
    proposalView(proposal: StoredProposal): ProposalView;
    flushProposal(sessionId: string): Promise<void>;
    captureFingerprint(shell: ShellService | null, workdir: string, policy?: unknown): Promise<string | null>;
    runChecks(shell: ShellService | null, workdir: string, checks: ReturnType<typeof deriveChecks>, policy?: unknown): Promise<string[]>;
    verifyProposal(shell: ShellService | null, proposal: StoredProposal, policy?: unknown): Promise<ProposalVerification>;
    executeProposal(shell: ShellService | null, proposal: StoredProposal, policy: unknown, persist: () => Promise<void>): Promise<UnknownRecord>;
    recoverFailedCommand(sessionId: string, workdir: string, operationId: string, action: string, command: string, message: string, errorOutput: string, errorCode: string, reason: string, policy?: unknown): Promise<UnknownRecord | null>;
    resolveExecutionPolicy(sessionId: string): Promise<unknown>;
}
/** Register the Client-to-Host POST dispatcher with a 1 MiB body limit. */
export declare function registerLazyGitActions(webServer: WebServerService | null, dependencies: LazyGitActionDependencies, connection: ConnectionService | null): unknown;
export {};
