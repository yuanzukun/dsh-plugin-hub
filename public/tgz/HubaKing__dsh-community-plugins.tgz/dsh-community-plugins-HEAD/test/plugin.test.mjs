/**
 * Verifies the plugin's exported contract and, when a built dsh is reachable,
 * validates the hand-written tool definition with dsh's own schema validator.
 *
 * That second part matters: this plugin deliberately does not import
 * `@deepseek-ai/dsh-tools`, so nothing at build time would otherwise catch a
 * definition that `register()` would reject at runtime. The official validator
 * is loaded here, in the test only, to prove the shape is acceptable.
 *
 * Run: node test/plugin.test.mjs
 */

import { existsSync, readFileSync } from 'node:fs'
import { pathToFileURL } from 'node:url'
import { join } from 'node:path'
import { apply, inject, name, TOOL_NAMES } from '../index.js'
import { resolveEnvironment } from '../lib/audit.js'

let passed = 0
let failed = 0
const failures = []

function check(label, condition, detail) {
  if (condition) {
    passed += 1
    return
  }
  failed += 1
  failures.push(`${label}${detail === undefined ? '' : `\n      ${detail}`}`)
}

/** A minimal stand-in for the Cordis context this plugin is applied with. */
function makeContext({ withTools = true, toolsRegisterThrows = false, toolsRegisterThrowsFor = null, getThrows = false } = {}) {
  const calls = { providers: [], tools: [], effects: [] }
  const ctx = {
    skills: {
      registerProvider(provider) {
        calls.providers.push(provider)
        return () => {}
      },
    },
    get(key) {
      if (getThrows) throw new Error('context exploded')
      if (key === 'skills') return ctx.skills
      return key === 'tools' && withTools ? ctx.tools : undefined
    },
    effect(callback, label) {
      calls.effects.push({ label, dispose: callback() })
    },
    logger: { warn() {} },
  }
  if (withTools) {
    ctx.tools = {
      register(definition) {
        if (toolsRegisterThrows || definition.name === toolsRegisterThrowsFor) {
          throw new TypeError(`tool rejected: ${definition.name}`)
        }
        calls.tools.push(definition)
        return () => {}
      },
    }
  }
  return { ctx, calls }
}

// ---------------------------------------------------------------------------
// Plugin shape
// ---------------------------------------------------------------------------

check('exports a bundle name', name === 'dsh-community-plugins')
check('declares skills as its only hard dependency',
  Array.isArray(inject) && inject.length === 1 && inject[0] === 'skills',
  JSON.stringify(inject))
check('apply is a function', typeof apply === 'function')

// ---------------------------------------------------------------------------
// Happy path
// ---------------------------------------------------------------------------

const happy = makeContext()
apply(happy.ctx)
check('registers exactly one skill provider', happy.calls.providers.length === 1)
check('registers exactly two tools (one offline, one networked)', happy.calls.tools.length === 2,
  `tools: ${happy.calls.tools.map(tool => tool.name).join(', ')}`)
check('the registered tool names match the exported contract',
  JSON.stringify(happy.calls.tools.map(entry => entry.name)) === JSON.stringify(TOOL_NAMES),
  `${happy.calls.tools.map(entry => entry.name).join(', ')} vs ${TOOL_NAMES.join(', ')}`)
check('wires each tool registration through ctx.effect', happy.calls.effects.length === 2,
  `effects: ${happy.calls.effects.length}`)

const provider = happy.calls.providers[0]?.()
check('skill provider has the expected name', provider?.name === 'dsh-community-plugins')
check('skill provider declares list and get',
  typeof provider?.list === 'function' && typeof provider?.get === 'function')

const tool = happy.calls.tools.find(entry => entry.name === 'dsh_plugin_audit')
const inspectTool = happy.calls.tools.find(entry => entry.name === 'dsh_plugin_inspect')
check('tool is named dsh_plugin_audit', tool?.name === 'dsh_plugin_audit')
check('the second tool is named dsh_plugin_inspect', inspectTool?.name === 'dsh_plugin_inspect')
check('tool has a description', typeof tool?.description === 'string' && tool.description.length > 80)
check('tool declares parameters', typeof tool?.parameters === 'object' && tool.parameters !== null)
check('tool declares output.schema', typeof tool?.output?.schema === 'object')
check('tool declares output.render', typeof tool?.output?.render === 'function')
check('tool declares execute', typeof tool?.execute === 'function')
check('tool declares a positive timeout budget',
  Number.isFinite(tool?.timeoutMs) && tool.timeoutMs > 0, `timeoutMs=${tool?.timeoutMs}`)
check('the timeout budget is never leaked to the model',
  !Object.hasOwn(tool?.parameters ?? {}, 'timeoutMs') && !Object.hasOwn(tool?.output?.schema ?? {}, 'timeoutMs'))

// The division of labour between the two tools is the point of having two: one
// promises to stay offline, the other is the only one allowed to fetch. If the
// descriptions stop saying which is which, an agent will pick the wrong one.
check('the offline tool promises it fetches nothing',
  tool.description.includes('Runs entirely offline')
  && tool.description.includes('Nothing is fetched from the network'),
  'the audit description no longer promises to stay offline')
check('the offline tool names the networked sibling for pre-install checks',
  tool.description.includes('dsh_plugin_inspect'), 'the audit description lost its pointer to the networked tool')
check('the networked tool says so in capital letters',
  inspectTool.description.includes('USES THE NETWORK'), 'the inspect description hides the network use')
check('the networked tool says it never installs or runs lifecycle scripts',
  inspectTool.description.includes('never installs') && inspectTool.description.includes('never runs the'),
  'the inspect description lost its safety boundaries')
check('the networked tool requires a spec', JSON.stringify(inspectTool.parameters?.required) === '["spec"]',
  JSON.stringify(inspectTool.parameters?.required))
check('the networked tool declares a longer timeout budget than the offline one',
  inspectTool.timeoutMs > tool.timeoutMs, `${inspectTool.timeoutMs} vs ${tool.timeoutMs}`)
check('the networked tool declares output.render and output.schema',
  typeof inspectTool.output?.render === 'function' && typeof inspectTool.output?.schema === 'object')
check('the inspect tool leaks no injected fetch implementation to the model',
  !Object.hasOwn(inspectTool.parameters?.properties ?? {}, 'fetchImpl'),
  JSON.stringify(Object.keys(inspectTool.parameters?.properties ?? {})))

// ---------------------------------------------------------------------------
// Graceful degradation: the skill is the core value and must never be lost
// because the optional tool could not attach.
// ---------------------------------------------------------------------------

const noTools = makeContext({ withTools: false })
let noToolsThrew = null
try {
  apply(noTools.ctx)
} catch (error) {
  noToolsThrew = error
}
check('applies cleanly when the deployment has no tools service',
  noToolsThrew === null, noToolsThrew?.message)
check('skill is still registered without a tools service', noTools.calls.providers.length === 1)
check('no tool is registered without a tools service', noTools.calls.tools.length === 0)

const brokenRegister = makeContext({ toolsRegisterThrows: true })
let brokenThrew = null
try {
  apply(brokenRegister.ctx)
} catch (error) {
  brokenThrew = error
}
check('a rejected tool registration does not break the plugin',
  brokenThrew === null, brokenThrew?.message)
check('skill survives a rejected tool registration', brokenRegister.calls.providers.length === 1)

// One rejected tool must not take the other one down: the offline audit is the
// fallback that still works, so losing it because the networked one failed would
// be the worst of both worlds.
const oneRejected = makeContext({ toolsRegisterThrowsFor: 'dsh_plugin_inspect' })
let oneRejectedThrew = null
try {
  apply(oneRejected.ctx)
} catch (error) {
  oneRejectedThrew = error
}
check('a rejected registration does not stop the second tool from registering',
  oneRejectedThrew === null && oneRejected.calls.tools.length === 1
  && oneRejected.calls.tools[0].name === 'dsh_plugin_audit',
  oneRejected.calls.tools.map(entry => entry.name).join(', '))

const throwingGet = makeContext({ getThrows: true })
let throwingGetThrew = null
try {
  apply(throwingGet.ctx)
} catch (error) {
  throwingGetThrew = error
}
check('a throwing ctx.get does not break the plugin', throwingGetThrew === null)
check('skill survives a throwing ctx.get', throwingGet.providers === undefined
  || throwingGet.calls.providers.length === 1)

// ---------------------------------------------------------------------------
// Validate the hand-written definition with dsh's own validator.
// ---------------------------------------------------------------------------

const environment = resolveEnvironment()
const validatorPath = environment.dshRoot === undefined
  ? undefined
  : join(environment.dshRoot, 'packages', 'core', 'tools', 'lib', 'index.js')

if (validatorPath === undefined || !existsSync(validatorPath)) {
  console.log('! built dsh not found — skipping validation with the official schema checker\n')
} else {
  const official = await import(pathToFileURL(validatorPath).href)
  console.log(`official validator: ${validatorPath}\n`)

  let schemaError = null
  try {
    official.assertSupportedJsonSchema(tool.parameters)
  } catch (error) {
    schemaError = error
  }
  check('official validator accepts the parameters schema',
    schemaError === null, schemaError?.message)

  let outputError = null
  try {
    official.assertSupportedJsonSchema(tool.output.schema)
  } catch (error) {
    outputError = error
  }
  check('official validator accepts the output schema', outputError === null, outputError?.message)

  // An empty call is valid; an unknown key is not, because additionalProperties
  // is false. This is the behaviour `register()` would rely on at dispatch time.
  const acceptsEmpty = official.validateJsonSchemaValue(tool.parameters, {})
  check('official validator accepts an empty argument object',
    Array.isArray(acceptsEmpty) && acceptsEmpty.length === 0, JSON.stringify(acceptsEmpty))

  const rejectsUnknown = official.validateJsonSchemaValue(tool.parameters, { nope: 1 })
  check('official validator rejects unknown arguments',
    Array.isArray(rejectsUnknown) && rejectsUnknown.length > 0, JSON.stringify(rejectsUnknown))

  const rejectsWrongType = official.validateJsonSchemaValue(tool.parameters, { target: 42 })
  check('official validator rejects a wrongly typed argument',
    Array.isArray(rejectsWrongType) && rejectsWrongType.length > 0, JSON.stringify(rejectsWrongType))

  // `register()` performs exactly these two checks on a definition.
  for (const definition of [tool, inspectTool]) {
    let registerable = null
    try {
      const output = definition.output
      const ok = output !== undefined && typeof output === 'object'
        && typeof output.render === 'function'
        && (output.presentationMeta === undefined || typeof output.presentationMeta === 'function')
      if (!ok) throw new TypeError('output contract violated')
      official.assertSupportedJsonSchema(definition.parameters)
      official.assertSupportedJsonSchema(output.schema)
    } catch (error) {
      registerable = error
    }
    check(`${definition.name} satisfies the two checks register() performs`,
      registerable === null, registerable?.message)
  }

  const inspectAcceptsEmpty = official.validateJsonSchemaValue(inspectTool.parameters, { spec: 'x' })
  check('official validator accepts the inspect tool arguments',
    Array.isArray(inspectAcceptsEmpty) && inspectAcceptsEmpty.length === 0, JSON.stringify(inspectAcceptsEmpty))
  const inspectRejectsMissingSpec = official.validateJsonSchemaValue(inspectTool.parameters, {})
  check('official validator rejects an inspect call with no spec',
    Array.isArray(inspectRejectsMissingSpec) && inspectRejectsMissingSpec.length > 0,
    JSON.stringify(inspectRejectsMissingSpec))
}

// ---------------------------------------------------------------------------
// The tool actually runs.
// ---------------------------------------------------------------------------

const report = await tool.execute({}, { signal: undefined })
check('execute returns a report object', typeof report === 'object' && report !== null)
check('report carries an environment block', typeof report.environment === 'object')
check('report carries a summary', typeof report.summary === 'object')
check('summary counts every plugin',
  Array.isArray(report.plugins) && report.summary.total === report.plugins.length,
  `total ${report.summary?.total} vs plugins ${report.plugins?.length}`)
check('every plugin entry carries a verdict and evidence arrays',
  report.plugins.every(plugin => typeof plugin.verdict === 'string'
    && Array.isArray(plugin.blockers) && Array.isArray(plugin.risks) && Array.isArray(plugin.unknowns)))

const missingTarget = await tool.execute({ target: 'this-package-does-not-exist-xyz' }, {})
check('an unmatched target yields an empty result rather than throwing',
  missingTarget.plugins.length === 0 && missingTarget.target === null)

// Declaring `timeoutMs` is a promise that the signal is honoured, so the abort
// path must actually stop the work. A budget that cannot be enforced would be
// a lie told to the dispatch pipeline.
const abortedCall = new AbortController()
abortedCall.abort()
let abortThrew = null
try {
  await tool.execute({}, { signal: abortedCall.signal })
} catch (error) {
  abortThrew = error
}
check('an aborted signal stops execute instead of running to completion',
  abortThrew !== null, 'execute completed despite an already-aborted signal')
check('the abort surfaces as an AbortError, not a generic crash',
  abortThrew === null || abortThrew.name === 'AbortError', abortThrew?.name)

// Documentation guard. The skill is the product; if it silently loses the
// pointer to the official runtime inspector, agents regress to static scans
// for questions that tool already answers exactly.
const skillText = readFileSync(join(process.cwd(), 'skills', 'dsh-community-plugins', 'SKILL.md'), 'utf8')
check('the skill points at the official cordis_inspect tooling',
  skillText.includes('cordis_inspect'), 'SKILL.md no longer mentions the official runtime inspector')
check('the skill states the runtime inspector\'s capability explicitly',
  skillText.includes('Slots.listSubTree'), 'SKILL.md lost the client-slot query path')
// The framing is asserted through two independent formulations rather than one
// verbatim sentence, so a register change cannot silently delete the distinction
// while a wording change alone does not fail the guard.
check('the skill explains the static-vs-runtime division of labour',
  skillText.includes('与本机构建是否一致') && skillText.includes('互不替代'),
  'SKILL.md lost the division-of-labour framing')
// The tool reads only the build installed here, so promising to predict a future
// upgrade would be a lie. This guard exists because an earlier version of the
// skill (and of the tool description) made exactly that claim.
check('the skill never promises to predict a future upgrade',
  skillText.includes('不预测未来') && !skillText.includes('升级前即可'),
  'SKILL.md claims a prediction the tool cannot make')
check('the skill documents the boot-failure layer checks',
  skillText.includes('failed to read overlay') && skillText.includes('declares no dsh.bundle'),
  'SKILL.md lost the guidance for a profile that will not boot')
// The desktop adaptation statement and the activation discipline are what this
// release adds; both are load-bearing, so both are guarded.
check('the skill states full adaptation to DSH Desktop',
  skillText.includes('全面适配 DSH 桌面版') && skillText.includes('正在运行的 profile'),
  'SKILL.md lost the desktop adaptation statement')
check('the skill states that a bundle layer is composed at startup only',
  skillText.includes('bundle 层仅在进程启动时组合'),
  'SKILL.md lost the activation discipline')
check('the skill separates the native skin package line from the skin-centre line',
  skillText.includes('不得装入同一 profile'),
  'SKILL.md lost the two-adaptation-lines warning')

const blocks = tool.output.render({}, report)
check('render returns content blocks',
  Array.isArray(blocks) && blocks.length > 0 && blocks[0].type === 'text')
check('render output names the tool', typeof blocks[0]?.text === 'string' && blocks[0].text.includes('dsh plugin audit'))

// Rendering must be total: replay may hand it arbitrary logged values.
for (const value of [undefined, null, 42, 'text', [], {}]) {
  let threw = null
  try {
    tool.output.render({}, value)
  } catch (error) {
    threw = error
  }
  check(`render tolerates ${JSON.stringify(value) ?? 'undefined'}`, threw === null, threw?.message)
}

for (const value of [undefined, null, 42, 'text', [], {}]) {
  let threw = null
  try {
    inspectTool.output.render({}, value)
  } catch (error) {
    threw = error
  }
  check(`inspect render tolerates ${JSON.stringify(value) ?? 'undefined'}`, threw === null, threw?.message)
}

// The network tool must fail closed on bad arguments: a missing spec has to come
// back as an error report without a request ever leaving the process.
const inspectWithoutSpec = await inspectTool.execute({}, {})
check('the inspect tool reports a missing spec instead of fetching anything',
  typeof inspectWithoutSpec.error === 'string' && inspectWithoutSpec.package === null,
  JSON.stringify(inspectWithoutSpec.error))

const inspectAborted = new AbortController()
inspectAborted.abort()
let inspectAbortThrew = null
try {
  await inspectTool.execute({ spec: 'anything' }, { signal: inspectAborted.signal })
} catch (error) {
  inspectAbortThrew = error
}
check('an already-aborted signal stops the networked tool before it fetches',
  inspectAbortThrew !== null && inspectAbortThrew.name === 'AbortError', inspectAbortThrew?.name)

console.log('# rendered report\n')
console.log(tool.output.render({}, report)[0].text.split('\n').map(line => `  ${line}`).join('\n'))
console.log()

console.log(`passed ${passed}, failed ${failed}`)
if (failed > 0) {
  console.log('\nfailures:')
  for (const failure of failures) console.log(`  ✗ ${failure}`)
  process.exitCode = 1
}
