/**
 * Guard tests: the environment self-check must (1) detect every broken harness
 * contract this plugin rides on, (2) NEVER throw even against hostile inputs,
 * (3) make apply() stop safely — return normally while installing NOTHING —
 * so the harness boot audit never sees a failed/pending entry.
 *
 * Run from the synced dev/headless profile copy so @deepseek-ai/* resolves:
 *   ./scripts/sync.sh && cp -r test <profile>/node_modules/@deepseek-ai/dsh-read-image/
 *   node --test <profile>/node_modules/@deepseek-ai/dsh-read-image/test/guards.test.mjs
 */
import { test } from 'node:test'
import assert from 'node:assert/strict'
import { mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { checkHostEnvironment, guardFailNotice, writeGuardLog } from '../lib/guards.js'
import { apply } from '../lib/index.js'

/** A fully healthy ctx/deps pair — every guard probe passes. */
function healthy() {
  const ctx = {
    on() {}, effect() {}, plugin() {},
    settings: { register() { return { watch() {} } }, get() { return {} } },
    agents: { get() { return undefined } },
    llm: {
      resolveModelInfo: async () => ({}),
      listProviders: async () => [],
      listModels: async () => [],
    },
    logger: { error() {}, warn() {}, info() {}, debug() {} },
  }
  const deps = {
    dshLlm: { contentHasImage() {}, deepFreeze() {}, BlockAssembler() {}, createUserMessage() {} },
    typertProtocol: { Remote() {}, TypertRemoteService() {} },
  }
  return { ctx, deps }
}

const ALL_NAMES = [
  'ctx.on', 'ctx.effect', 'ctx.plugin', 'ctx.settings', 'settings.register', 'settings.get',
  'ctx.agents', 'agents.get', 'ctx.llm', 'llm.resolveModelInfo', 'llm.listProviders',
  'llm.listModels', 'dshLlm.contentHasImage', 'dshLlm.deepFreeze', 'dshLlm.BlockAssembler',
  'dshLlm.createUserMessage', 'typert.Remote', 'typert.TypertRemoteService',
]

test('guard: healthy environment passes every probe', () => {
  const { ctx, deps } = healthy()
  const result = checkHostEnvironment(ctx, deps)
  assert.equal(result.ok, true)
  assert.deepEqual(result.problems, [])
})

test('guard: each missing contract is reported by name', () => {
  for (const name of ALL_NAMES) {
    const { ctx, deps } = healthy()
    // one targeted removal per iteration
    switch (name) {
      case 'ctx.on': delete ctx.on; break
      case 'ctx.effect': delete ctx.effect; break
      case 'ctx.plugin': delete ctx.plugin; break
      case 'ctx.settings': delete ctx.settings; break
      case 'settings.register': delete ctx.settings.register; break
      case 'settings.get': delete ctx.settings.get; break
      case 'ctx.agents': delete ctx.agents; break
      case 'agents.get': delete ctx.agents.get; break
      case 'ctx.llm': delete ctx.llm; break
      case 'llm.resolveModelInfo': delete ctx.llm.resolveModelInfo; break
      case 'llm.listProviders': delete ctx.llm.listProviders; break
      case 'llm.listModels': delete ctx.llm.listModels; break
      case 'dshLlm.contentHasImage': delete deps.dshLlm.contentHasImage; break
      case 'dshLlm.deepFreeze': delete deps.dshLlm.deepFreeze; break
      case 'dshLlm.BlockAssembler': delete deps.dshLlm.BlockAssembler; break
      case 'dshLlm.createUserMessage': delete deps.dshLlm.createUserMessage; break
      case 'typert.Remote': delete deps.typertProtocol.Remote; break
      case 'typert.TypertRemoteService': delete deps.typertProtocol.TypertRemoteService; break
      default: throw new Error('unhandled name ' + name)
    }
    const result = checkHostEnvironment(ctx, deps)
    assert.equal(result.ok, false, `expected failure for missing ${name}`)
    assert.ok(result.problems.some((p) => p.name === name), `missing ${name} not reported: ${JSON.stringify(result.problems)}`)
  }
})

test('guard: never throws against hostile inputs', () => {
  // throwing getter on ctx.llm
  const throwing = healthy()
  Object.defineProperty(throwing.ctx, 'llm', { get() { throw new Error('boom') } })
  const r1 = checkHostEnvironment(throwing.ctx, throwing.deps)
  assert.equal(r1.ok, false)
  assert.ok(r1.problems.some((p) => p.name === 'ctx.llm'))
  // null ctx / null deps
  const r2 = checkHostEnvironment(null, null)
  assert.equal(r2.ok, false)
  assert.ok(r2.problems.length > 0)
  // wrong-typed deps
  const r3 = checkHostEnvironment(healthy().ctx, { dshLlm: { contentHasImage: 'nope' }, typertProtocol: 42 })
  assert.equal(r3.ok, false)
  assert.ok(r3.problems.some((p) => p.name === 'dshLlm.contentHasImage'))
  assert.ok(r3.problems.some((p) => p.name === 'typert.Remote'))
  // empty objects
  assert.equal(checkHostEnvironment({}, {}).ok, false)
})

test('writeGuardLog: writes the diagnostics file and returns its path', () => {
  const dir = mkdtempSync(join(tmpdir(), 'read-image-guard-'))
  const target = join(dir, 'nested', 'guard.log')
  try {
    const problems = [{ name: 'llm.resolveModelInfo', detail: '缺失' }]
    const path = writeGuardLog(problems, target)
    assert.equal(path, target)
    const content = readFileSync(target, 'utf8')
    assert.ok(content.includes('FAILED'))
    assert.ok(content.includes('llm.resolveModelInfo'))
  } finally {
    rmSync(dir, { recursive: true, force: true })
  }
})

test('writeGuardLog: never throws when the target is unwritable', () => {
  const dir = mkdtempSync(join(tmpdir(), 'read-image-guard-unwritable-'))
  try {
    // parent is a regular FILE — mkdir/write under it fails fast (ENOTDIR),
    // and no pseudo-filesystem path is needed (recursive mkdir on /proc can
    // hang — the guard must never block, see lib/guards.js ensureDir).
    const file = join(dir, 'not-a-dir')
    writeFileSync(file, 'x')
    assert.equal(writeGuardLog([{ name: 'x', detail: 'y' }], join(file, 'x.log')), null)
  } finally {
    rmSync(dir, { recursive: true, force: true })
  }
})

test('guardFailNotice: bilingual, actionable, points at log + bypass switch', () => {
  const text = guardFailNotice('/tmp/fake-guard.log')
  assert.ok(text.includes('/tmp/fake-guard.log'))
  assert.ok(text.includes('guard.enabled'))
  assert.ok(text.includes('settings.yaml'))
  assert.ok(text.includes('自检未通过'))
  assert.ok(text.includes('self-check'))
  assert.ok(text.includes('FAILED'))
  assert.ok(text.includes('AI Agent'))
})

test('apply: guard failure path — returns normally, installs NOTHING', () => {
  const calls = { plugin: 0, on: 0, effect: 0, errors: [], wrapperInstalled: false }
  const ctx = {
    settings: { register() { return { watch() {} } }, get() { return {} } },
    agents: { get() {} },
    llm: {
      resolveModelInfo: async () => ({}),
      listProviders: async () => [],
      listModels: async () => [],
    },
    logger: { error: (...a) => calls.errors.push(a.join(' ')), warn() {}, info() {}, debug() {} },
    plugin() { calls.plugin += 1 },
    on() { calls.on += 1 },
    effect() { calls.effect += 1 },
  }
  const originalResolve = ctx.llm.resolveModelInfo
  process.env.DSH_READ_IMAGE_FORCE_GUARD_FAIL = '1'
  try {
    const returned = apply(ctx, {})
    // apply must return normally (fiber stays ACTIVE) — the ONLY safe failure mode
    assert.equal(returned, undefined)
    assert.equal(calls.plugin, 0, 'no config bridge may be registered')
    assert.equal(calls.on, 0, 'no listeners may be registered')
    assert.equal(calls.effect, 0, 'no effects may be registered')
    assert.equal(ctx.llm.resolveModelInfo, originalResolve, 'resolveModelInfo must not be wrapped')
    assert.equal(calls.errors.length, 1, 'exactly ONE front-desk notice')
    assert.ok(calls.errors[0].includes('自检未通过'))
    assert.ok(calls.errors[0].includes('guard.enabled'))
  } finally {
    delete process.env.DSH_READ_IMAGE_FORCE_GUARD_FAIL
  }
})

test('apply: healthy path — hooks installed, dispose restores', () => {
  const cleanups = []
  const calls = { plugin: [], on: [], effect: [], errors: [] }
  const ctx = {
    settings: { register() { return { watch() {} } }, get() { return {} } },
    agents: { get() { return undefined } },
    llm: {
      resolveModelInfo: async () => ({}),
      listProviders: async () => [],
      listModels: async () => [],
    },
    logger: { error: (...a) => calls.errors.push(a.join(' ')), warn() {}, info() {}, debug() {} },
    plugin(cls) { calls.plugin.push(cls) },
    on(name) { calls.on.push(name) },
    effect(fn) {
      calls.effect.push(fn)
      const cleanup = fn()
      cleanups.push(cleanup)
      return () => {}
    },
  }
  const originalResolve = ctx.llm.resolveModelInfo
  let wrapped
  try {
    apply(ctx, {})
    assert.ok(calls.plugin.length >= 1, 'config bridge registered')
    assert.ok(calls.on.includes('llm/stream'), 'M2 projection listener registered')
    assert.ok(calls.on.includes('llm/adapters-updated'), 'truth-table refresh listener registered')
    assert.ok(calls.on.includes('session/created'), 'M3 session listener registered')
    assert.ok(calls.effect.length >= 2, 'admission wrapper + timer cleanup effects registered')
    wrapped = ctx.llm.resolveModelInfo
    assert.notEqual(wrapped, originalResolve, 'M1 wrapper installed')
    assert.equal(calls.errors.length, 0, 'no errors on healthy path')
  } finally {
    for (const cleanup of cleanups) if (typeof cleanup === 'function') cleanup()
  }
  // dispose must restore the ORIGINAL resolver (bound at apply time, so the
  // restored reference is a bound variant — the wrapper must be gone either way)
  assert.notEqual(ctx.llm.resolveModelInfo, wrapped, 'dispose removes the M1 wrapper')
  assert.equal(typeof ctx.llm.resolveModelInfo, 'function', 'dispose leaves a working resolver')
})

test('apply: guard.enabled=false bypasses the self-check and force-loads', () => {
  const calls = { plugin: 0, on: 0 }
  const cleanups = []
  const ctx = {
    // `agents` is MISSING entirely — the guard would report ctx.agents /
    // agents.get if it ran; the bypass must skip the check and still boot.
    settings: { register() { return { watch() {} } }, get() { return { guard: { enabled: false } } } },
    llm: {
      resolveModelInfo: async () => ({}),
      listProviders: async () => [],
      listModels: async () => [],
    },
    logger: { error() {}, warn() {}, info() {}, debug() {} },
    plugin() { calls.plugin += 1 },
    on() { calls.on += 1 },
    effect(fn) {
      const cleanup = fn()
      cleanups.push(cleanup)
      return () => {}
    },
  }
  // with the bypass active, even FORCE_GUARD_FAIL must not matter
  process.env.DSH_READ_IMAGE_FORCE_GUARD_FAIL = '1'
  try {
    apply(ctx, {})
    assert.ok(calls.plugin >= 1, 'bridge registered despite missing agents (bypass)')
    assert.ok(calls.on >= 3, 'listeners registered despite missing agents (bypass)')
  } finally {
    delete process.env.DSH_READ_IMAGE_FORCE_GUARD_FAIL
    // run the timer-cleanup effect so pending schedule() handles are cleared
    for (const cleanup of cleanups) if (typeof cleanup === 'function') cleanup()
  }
})
