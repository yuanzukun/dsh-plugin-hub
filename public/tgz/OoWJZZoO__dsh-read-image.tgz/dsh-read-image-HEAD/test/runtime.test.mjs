/**
 * Shape-matrix tests for the A2 projection path (lib/runtime.js): walk /
 * detection / replacement must agree with the harness's canonical image walk
 * (dsh-llm contentHasImage) across the content shapes the harness actually
 * emits, and must fail closed — loudly — on anything it cannot serialize,
 * instead of silently letting pixels reach a text API.
 *
 * Run from the synced dev/headless profile copy so @deepseek-ai/dsh-llm
 * resolves (the repo root has no node_modules):
 *   ./scripts/sync.sh && cp -r test <profile>/node_modules/@deepseek-ai/dsh-read-image/
 *   node --test <profile>/node_modules/@deepseek-ai/dsh-read-image/test/
 */
import { test } from 'node:test'
import assert from 'node:assert/strict'
import {
  countImages,
  isImageCapable,
  keyOf,
  messageHasImage,
  projectRequest,
  resolveImageRef,
  setCapability,
} from '../lib/runtime.js'

const img = (id) => ({ type: 'image', attachment: { id } })
const text = (t) => ({ type: 'text', text: t })

test('messageHasImage: image block anywhere in array content', () => {
  assert.equal(messageHasImage(undefined), false)
  assert.equal(messageHasImage(null), false)
  assert.equal(messageHasImage({ role: 'user', content: [text('hi')] }), false)
  assert.equal(messageHasImage({ role: 'user', content: [img('a')] }), true)
  assert.equal(messageHasImage({ role: 'user', content: [text('hi'), img('a'), text('bye')] }), true)
})

test('messageHasImage: nested tool-result images are seen', () => {
  const nested = {
    role: 'user',
    content: [
      { type: 'tool-result', content: [text('ok'), img('inner')] },
    ],
  }
  assert.equal(messageHasImage(nested), true)
  const deep = {
    role: 'user',
    content: [
      { type: 'tool-result', content: [{ type: 'tool-result', content: [img('deep')] }] },
    ],
  }
  assert.equal(messageHasImage(deep), true)
})

test('messageHasImage: non-array top-level content is handled without throwing', () => {
  assert.equal(messageHasImage({ role: 'user', content: 'plain string' }), false)
  assert.equal(messageHasImage({ role: 'user', content: 42 }), false)
})

test('messageHasImage: unknown nested shapes fail CLOSED (report has-image)', () => {
  // A tool-result whose content is not an array would make the harness walker
  // throw; fail-closed means the projection boundary treats it as an image and
  // refuses to forward, never silently leaking it.
  assert.equal(messageHasImage({ role: 'user', content: [{ type: 'tool-result', content: 'plain' }] }), true)
})

test('countImages: counts every image block in model-visible order', () => {
  const messages = [
    { role: 'user', content: [img('a'), text('x')] },
    { role: 'user', content: [{ type: 'tool-result', content: [img('b'), { type: 'tool-result', content: [img('c')] }] }] },
    { role: 'assistant', content: [text('reply')] },
  ]
  assert.equal(countImages(messages), 3)
  assert.equal(countImages([]), 0)
})

test('resolveImageRef: 1-based index resolves in model-visible order', () => {
  const messages = [
    { role: 'user', content: [img('a'), text('x')] },
    { role: 'user', content: [{ type: 'tool-result', content: [img('b'), { type: 'tool-result', content: [img('c')] }] }] },
  ]
  assert.equal(resolveImageRef(messages, 1)?.id, 'a')
  assert.equal(resolveImageRef(messages, 2)?.id, 'b')
  assert.equal(resolveImageRef(messages, 3)?.id, 'c')
  assert.equal(resolveImageRef(messages, 4), undefined)
  assert.equal(resolveImageRef(messages, 0), undefined)
  assert.equal(resolveImageRef(messages, -1), undefined)
  assert.equal(resolveImageRef(messages, 1.5), undefined)
  assert.equal(resolveImageRef(messages, '1'), undefined)
})

test('projectRequest: no-image requests pass through unchanged (identity)', () => {
  const request = { provider: 'p', model: 'm', messages: [{ role: 'user', content: [text('hi')] }] }
  assert.equal(projectRequest(request), request)
  const emptyMessages = { provider: 'p', messages: [] }
  assert.equal(projectRequest(emptyMessages), emptyMessages)
  const noMessages = { provider: 'p' }
  assert.equal(projectRequest(noMessages), noMessages)
  assert.equal(projectRequest(null), null)
})

test('projectRequest: replaces image blocks with [Image #N] in order, preserving positions', () => {
  const request = {
    provider: 'p',
    model: 'm',
    messages: [
      { role: 'user', content: [text('see'), img('a'), text('then'), img('b')] },
      { role: 'user', content: [text('last'), img('c')] },
    ],
  }
  const projected = projectRequest(request)
  assert.notEqual(projected, request)
  assert.deepEqual(projected.messages[0].content, [
    { type: 'text', text: 'see' },
    { type: 'text', text: '[Image #1]' },
    { type: 'text', text: 'then' },
    { type: 'text', text: '[Image #2]' },
  ])
  assert.deepEqual(projected.messages[1].content, [
    { type: 'text', text: 'last' },
    { type: 'text', text: '[Image #3]' },
  ])
  // after projection nothing reports as carrying an image anymore
  for (const message of projected.messages) assert.equal(messageHasImage(message), false)
})

test('projectRequest: nested tool-result images replaced, structure preserved', () => {
  const request = {
    provider: 'p',
    model: 'm',
    messages: [
      {
        role: 'user',
        content: [
          { type: 'tool-result', content: [text('r'), img('inner'), { type: 'tool-result', content: [img('deep')] }] },
        ],
      },
    ],
  }
  const projected = projectRequest(request)
  assert.deepEqual(projected.messages[0].content, [
    {
      type: 'tool-result',
      content: [
        { type: 'text', text: 'r' },
        { type: 'text', text: '[Image #1]' },
        { type: 'tool-result', content: [{ type: 'text', text: '[Image #2]' }] },
      ],
    },
  ])
  for (const message of projected.messages) assert.equal(messageHasImage(message), false)
})

test('projectRequest: never mutates the original request (immutability)', () => {
  const request = {
    provider: 'p',
    model: 'm',
    messages: [{ role: 'user', content: [text('see'), img('a')] }],
  }
  projectRequest(request)
  assert.deepEqual(request.messages[0].content, [text('see'), img('a')])
})

test('projectRequest: output is deep-frozen (harness deepFreeze)', () => {
  const request = {
    provider: 'p',
    model: 'm',
    messages: [{ role: 'user', content: [text('see'), img('a')] }],
  }
  const projected = projectRequest(request)
  assert.equal(Object.isFrozen(projected), true)
  assert.equal(Object.isFrozen(projected.messages), true)
  assert.equal(Object.isFrozen(projected.messages[0]), true)
  assert.equal(Object.isFrozen(projected.messages[0].content), true)
})

test('projectRequest: non-array top-level content passes through without throwing', () => {
  const request = { provider: 'p', model: 'm', messages: [{ role: 'user', content: 'plain string' }] }
  assert.equal(projectRequest(request), request)
})

test('projectRequest: un-serializable nested shape fails loudly (fail-closed assertion)', () => {
  // A tool-result whose content is not an array is seen by the canonical walker
  // (fail-closed), cannot be replaced by projectContent's switch, and must
  // therefore throw at the post-projection assertion instead of forwarding.
  const request = {
    provider: 'p',
    model: 'm',
    messages: [{ role: 'user', content: [{ type: 'tool-result', content: 'plain' }] }],
  }
  assert.throws(() => projectRequest(request), /projection failed/)
})

test('capability table: setCapability/isImageCapable round-trip', () => {
  setCapability(new Map([[keyOf('p', 'm'), true]]))
  assert.equal(isImageCapable('p', 'm'), true)
  assert.equal(isImageCapable('p', 'other'), false)
  setCapability(new Map())
  assert.equal(isImageCapable('p', 'm'), false)
})
