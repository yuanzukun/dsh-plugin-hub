# AGENTS.md

面向 AI 编码代理（以及人类维护者）的仓库指南。改动本仓库前请先读完本文，尤其是「铁律」与「硬核教训」两节——每个坑都烧掉过一次完整重启周期。

## 铁律（最重要的一条）

**不要杀掉承载你自己的进程。**

本仓库的宿主 `dsh web` 进程同时承载：Web GUI（用户操作界面）和 **agent 运行时本身**——工具调用（如 run_code）就在这个进程的 code-runtime worker 里执行。

真实事故：为加载插件而 `kill <PID>`（PID 303 = `node /usr/bin/dsh web`），把正在运行自己的进程杀了 → 运行时半死，之后所有工具调用报 `Cannot read properties of undefined (reading 'prepare')`，只能靠人工回退配置 + 重启恢复，浪费了用户大量时间。

规则：

1. **绝不 kill / 重启当前会话所在的 `dsh web` 进程**。host 插件加载需要重启时，**由人类在终端执行**（`kill` 后 `cd ~ && node /usr/bin/dsh web`），你只负责把文件准备好并等人类确认。
   **例外：dev profile（`node /usr/bin/dsh --profile dev`）是隔离验证面，agent 可以自行启动/重启/关闭**——dev 崩了只死 dev，生产无感。动手前仍必须 `ps aux | grep 'dsh'` 确认目标 PID 命令行是 `--profile dev`，绝不含 `dsh web`。
2. 任何涉及杀进程/重启的操作前，先 `ps aux | grep 'dsh web' | grep -v grep` 看 PID，**确认它不是你自己**，再谈下一步。生产进程形态固定为 `node /usr/bin/dsh web`；dev 进程形态为 `node /usr/bin/dsh --profile dev`（端口 3082）。
3. **不要在后台盲启服务器**：后台启动失败时没有可见日志，坏状态会以"工具全部报错"的形式呈现，极难排查。host 侧改动一律走"改码 → sync → 人类重启 → 人类确认"的流程。
   **例外：dev profile 后台启动失败完全可控**（隔离面，死只死 dev）——用托管后台 job 跑 `dsh --profile dev`，从 job 输出读日志，`curl -s http://127.0.0.1:3082/` 确认 HTTP 200 即就绪；失败就 kill 该 job 重启，不触碰生产。
4. 拿不准目标进程身份时，问人类，不要动手。

## dev profile 操作规范（agent 可自行执行）

dev profile（`~/.dsh/profiles/dev`，端口 3082）是生产 web 的镜像，专门用来验证开发中的插件代码，**与生产完全隔离**。以下操作 agent 自己做，不需要人类：

- **启动**：`dsh --profile dev` 用托管后台 job 跑；就绪检查 `curl -s -o /dev/null -w '%{http_code}' http://127.0.0.1:3082/` 应返回 200；异常读 job 日志。
- **重启（应用新代码）**：改码 → `./scripts/sync.sh` → kill 旧 dev 进程 → 重新启动。dev 进程识别：`ps aux | grep dsh | grep -v grep`，命令行含 `--profile dev` 的才是 dev（`dsh web` 是生产本体，绝不能动）。
- **验证**：`curl` 检查 UI 可达；`dsh --profile headless "请直接回复：OK"` 冒烟；浏览器交互（设置页点选）仍需人类，或借助截图/HTTP 断言。
- **崩溃自愈**：开发中插件把 dev boot 搞崩（如客户端 pending），dev 起不来或挂掉——kill dev job 重启即可，生产 web 毫发无损；修复代码后重复 改码 → sync → 重启 dev。
- **关闭**：验证完毕 kill dev 进程（确认 PID 后），避免残留占用 3082。
- **边界**：`./scripts/deploy.sh`（稳定版进生产）+ 生产重启永远由人类把关。

## 这个仓库是什么

**dsh-read-image**：DeepSeek Harness 的即插即用读图插件，让**非多模态**大模型（如 deepseek-v4-flash）也能"看图"：

- 用户发送图片**不再被拦截**（文本路由被声明为可接受图片输入，准入闸门放行）；
- 文本路由的模型请求中，图片块被原位替换为 `[Image #N]` 文本（像素永远不进入文本 API）；
- 一等公民 `read_image` 工具（每个会话自动注册，遮蔽内置同名工具；**仅文本路由**——原生多模态路由回退内置 `read_image`（只 `file_path`），不注入 `[Image #N]` 提示词段）：
  - `image_index`：读取会话中第 N 张图（`[Image #N]`）；
  - `file_path`：读取文件路径的图片（PNG/JPEG/WebP/GIF）；
  - `prompt` / `reasoning_effort` / `timeout_ms` / `max_tokens` / `max_thinking_tokens`：可选参数，缺省用配置默认值（工具描述内插当前真实默认值）；
  - 文本路由通过配置的**视觉模型**把图片转成文字描述返回；多模态路由直接返回图片本身；
  - 无状态、可重复调用（含重复读同一张图）。
- **可视化配置**：设置面板（侧边栏齿轮）新增「读图」页（`settings.section` 槽位，order 12，紧贴「模型」页），编辑 `visionProvider/visionModel` 与默认参数；浏览器 ↔ host 走 **typert Remote 桥**（`readImageConfig` 服务），绕开 harness 对插件命名空间的 `WEB_SETTINGS_NAMESPACES` 白名单。

## 部署形态（本机）

| 项 | 位置 |
| --- | --- |
| 插件源码 | 本仓库（`/home/wanwe/global_workspace/agent/dsh-read-image`） |
| **dev profile（开发镜像）** | `~/.dsh/profiles/dev/`：web 的镜像（同 bundles），端口 3082，副本由 `./scripts/sync.sh` 同步**开发中**代码；`dsh --profile dev` 启动验证 |
| web profile（生产） | `~/.dsh/profiles/web/`：只装**验证通过的稳定版**，副本由 `./scripts/deploy.sh` 显式更新，`scripts/sync.sh` 绝不触碰 |
| headless profile | CLI 验证面，`scripts/sync.sh` 同步开发中代码 |
| 运行时副本 | `<profile>/node_modules/@deepseek-ai/dsh-read-image`（**手动同步的物理副本**，见「开发循环」） |
| 配置 | `~/.dsh/settings.yaml`：`mimo-v2.5` 声明 `input: [text, image]`；`dsh-read-image:` 段配 `visionProvider/visionModel` 与默认参数 |

## 架构（三个机制）

| 机制 | 平面 | 文件 | 作用 |
| --- | --- | --- | --- |
| M1 准入放行 | host | `lib/index.js` | apply 时包装 `llm.resolveModelInfo`：非图片路由追加 `inputModalities: ['text','image']`（dispose 恢复）→ api-proxy 的 prompt/selectModel 闸门放行 |
| M2 投影 | host | `lib/index.js` + `lib/runtime.js` | `llm/stream` waterfall 同步监听器：文本路由上的 image 块原位替换为 `[Image #N]`，用 harness 的 `deepFreeze` 深冻结后 `this.stream(projected)` 重入派发（无图请求直通） |
| M3 工具 | preset/agent | `lib/index.js` | `session/created` 时经 `agent.ctx` 注册 `read_image`（per-agent 层遮蔽内置同名工具）+ 提示词段；**仅文本/未知路由**——原生多模态路由（真值表判定）跳过注册与提示词段，回退 harness 内置 `read_image`（只 `file_path`，"return the image itself"） |
| 设置 | host | `lib/index.js` | 注册 `dsh-read-image` settings 命名空间（schema 默认值即 fallback），`scope.watch` 热同步运行时配置 |
| 配置桥 | host | `lib/config-remote.js` | `createReadImageConfigBridge()` 工厂构造 `ReadImageConfigService extends TypertRemoteService`（`readImageConfig.get/set` 端点，内部读写 `ctx.settings`；Gateway 按 `typertRemote` 绑定 + `@Remote` 标记自动发现，无需 typert-loader）。类在 guard 通过后才构造（`extends` 表达式延迟求值） |
| 配置页 | browser | `lib/client.js` | `settings.section` 注册「读图」页（order 12），**apply 内 `ctx.remote.$mount(contribution)` 自挂载** `remote.readImageConfig` 后经其读写；不用 settingsScope（白名单会拒插件命名空间） |
| 环境自检 | host + browser | `lib/guards.js` + `lib/index.js` + `lib/client.js` | **总保险丝**：apply 开头探测全部 harness 契约（ctx 服务形状 + dsh-llm/typert 具名导出），任一失效 → 写 `~/.dsh/logs/dsh-read-image-guard.log` + 前台一条双语提示 + **正常 return（不装任何 hook）**——插件唯一安全失败模式（boot 审计对 failed/pending/import 失败一律判死，见 AGENTS.md 与 known-hacks G1）。跳过开关：settings.yaml `guard.enabled: false`；测试开关：`DSH_READ_IMAGE_FORCE_GUARD_FAIL=1`。重试调度自管 `setTimeout`（`timer` 不注入） |

共享状态与纯函数在 `lib/runtime.js`：运行时配置、图片能力真值表、`[Image #N]` 扫描/替换、视觉调用（`describeImage`）、`CONFIG_NAMESPACE` 常量。浏览器端 `lib/client.js` 是「读图」设置页（typert Remote 桥，见「已知限制」）。环境自检逻辑在 `lib/guards.js`（`checkHostEnvironment` / `writeGuardLog` / `guardFailNotice`）。

## 开发循环（重要）

pnpm 的 `file:` 依赖是**内容快照**（`Already up to date` 不追踪源码变更），`link:` 又会让依赖解析失败（符号链接按真实路径解析，找不到 profile 的 node_modules）。因此：

```sh
# 1. 改源码
vim lib/index.js lib/runtime.js lib/config-remote.js lib/client.js
# 2. 语法检查
node --check lib/index.js && node --check lib/runtime.js && node --check lib/config-remote.js
# 3. 同步运行时副本（dev + headless —— 生产 web 绝不在此步触碰）
./scripts/sync.sh
# 4. 在 dev 镜像验证（agent 自行执行，见「dev profile 操作规范」）：
#    后台 job 跑 dsh --profile dev → curl 127.0.0.1:3082 确认就绪 → headless 冒烟；
#    浏览器交互（设置页点选/截图）仍需人类。
# 5. 验证通过后，显式部署稳定版到生产 web，再由人类重启
./scripts/deploy.sh   # 只拷 web 副本；重启由人类执行：kill 后 cd ~ && node /usr/bin/dsh web
```

**核心隔离原则**：`scripts/sync.sh` 只喂 dev/headless 两个验证面；`scripts/deploy.sh` 是开发中代码进入生产 web 的唯一闸门。开发中的插件崩了（如客户端 boot pending），死的只是 dev 验证实例，生产 web 不受影响。

**在宿主进程内运行的工具调用无法感知源码改动**（ESM 模块缓存 + 副本快照），只有重启生效。

## 硬核教训（每个都真实发生过）

1. **依赖声明**：`@deepseek-ai/dsh-llm`、`@deepseek-ai/dsh-tools` 必须是 **peerDependencies**（与 harness 共享同一实例）。写成普通 dependencies 会让 pnpm 装第二份副本，`TOOL_RUNTIME_SCHEDULER` 这类模块级 Symbol 身份分裂 → 工具调度在 `prepare` 处崩溃（`Cannot read properties of undefined (reading 'prepare')`）。`@deepseek-ai/schemastery` 这类纯工具库可用普通依赖。
2. **绝不冻结 AbortSignal**：请求对象里的 `signal` 是实时取消通道。harness 的 `deepFreeze`（`@deepseek-ai/dsh-llm` 导出）**特意跳过 AbortSignal**（源码注释明言）。自写 deepFreeze 会冻结 signal → 适配器 `AbortSignal.any([signal,...])` 试图在冻结对象上挂 `kDependantSignals` → 抛 `Cannot add property Symbol(kDependantSignals), object is not extensible`，模型请求表现为 `Connection error.`（TRANSPORT）+ 重试取消。投影路径必须用 harness 的 `deepFreeze`。
3. **`llm.listProviders()` 返回对象数组**（`{id, name}`），不是字符串。按字符串处理会 `listModels(对象)` 查不到适配器 → 真值表永远是空的。
4. **真值表启动竞态**：pi-ai 适配器可能晚于本插件注册。先挂 `llm/adapters-updated` 监听再初始刷新，并加 1.5s/5s/15s 的 `ctx.timeout` 重试（timer 服务注入）。真值表始终用**包装前的原始 `resolveModelInfo`**（`originalResolveModelInfo`）构建，绝不使用被 M1 包装后的方法，避免自指。
5. **`[Image #N]` 编号的作用域**：编号计数器必须在 `projectRequest` 内部闭包里（`projectContent` 要引用它）。写成模块级函数引用局部变量会 `index is not defined`。
6. **投影监听器必须同步**：cordis waterfall 不 await 监听器；异步监听器会把 AsyncIterable 变成 Promise 使链路断裂。能力判定走同步缓存表，不要 await。
7. **重入必须收敛**：`this.stream(projected)` 重新走 `llm/stream` waterfall；`projected` 已无图 → 二进宫直接 `next()` → 直通适配器。视觉调用（真图片路由）不受投影影响。
8. **配置界面不可见是 harness 限制，已用 typert Remote 桥绕开**：本版本 `dsh-host-apiproxy` 把 Web 端可访问的设置命名空间写死为 `WEB_SETTINGS_NAMESPACES` 白名单，插件 `settings.register()` 的命名空间对客户端只回 `settings-not-exposed`（官方注释明言"插件暴露配置"是 deferred work）。浏览器直接走 settings 协议必死；改为 host 侧 `ReadImageConfigService extends TypertRemoteService`（`@Remote` 标记，内部读写 `ctx.settings`）+ 客户端自挂载 remote face。注意：**Node 运行时无装饰器语法**，`@Remote` 用手动 `markRemote`（构造 fake DecoratorContext + `addInitializer`）应用；wire 参数名 = 方法参数名（SRC 推断），多传字段会 `arguments-invalid`；**客户端调用是位置参数**（face 是 `(...args) => invoke(...)`，`values[i]` 按序映射到 descriptor 参数）——单 json 参数的 `set` 要写 `remote.set(obj)`，写 `remote.set({request: obj})` 会让 host 收到 `request = {request: obj}` 双层嵌套，patch/unset 取不到 → mutate 静默不执行且返回 ok（真实事故：读图页"保存"从首版起就是坏的，编辑永远落不了盘）。settings.yaml 仍是底座（user layer 覆盖）。备选：手写 settings.yaml 或改 harness 白名单（升级即丢）。
9. **客户端 `remote.<ns>` 注入只对 harness 硬编码贡献存在（真实事故，烧掉过一整个 web boot）**：浏览器端 `remote.<namespace>` 服务由 `dsh-api-remotes` 客户端把编译期生成的 `TYPERT_REMOTE$1..$5` 贡献挂到 `ctx.remote.$mount` 才安装；**第三方插件没有动态发现机制**。在客户端 `inject` 里写 `"remote.readImageConfig"` 会让插件永久 pending，报 `web boot: 1 entry did not activate ... (waiting for service: remote.readImageConfig)`，**整个 Web 界面起不来**。修复：客户端 apply 里 `await ctx.remote.$mount(contribution)` 自挂载自己的命名空间——descriptor 的 codec 需 `mode:"strict"` 且 schema 有 `_zod` 属性 + `parse` 函数；zod 被内联进 dsh-api-remotes 的 bundle 无法 `require`，手工构造 `{_zod:{}, parse:(v)=>v}` 透传 schema 即可。无参数方法调用 `remote.get()`（位置参数，不是 `get({})`）。
10. **fiber ctx 上 `ctx.service()` 不可用（headless 冒烟抓出）**：cordis 插件 apply 的 ctx 是受限 Proxy，直接 `ctx.service('name', Class)` 报 `cannot get property "service" without inject`，插件 boot 失败。注册服务要用 `ctx.plugin(ServiceClass)`——cordis 的 `Fiber.execute` 对 Service 类插件 `new Class(ctx, config)`，其构造 `super(ctx, name)` 经 `ctx.reflect.provide` 自动注册为服务（message-feedback 纯服务包同理）。

## 验证清单

- **headless 冒烟**：`dsh --profile headless "请直接回复：OK"` 应输出 OK 且无堆栈；内置 `read` 工具可用（确认没破坏工具调度）。
- **dev 就绪**：后台 job 跑 `dsh --profile dev`，`curl http://127.0.0.1:3082/` 返回 200，job 日志无 boot 错误（插件 apply 失败会在这里暴露，生产不受影响）。
- **工具注册**：文本路由会话工具列表应有新版 `read_image`（英文描述，含 image_index/prompt/reasoning_effort/timeout_ms/max_tokens/max_thinking_tokens，描述内插当前真实默认值）。
- **多模态回退**：原生多模态路由（如 mimo-v2.5）会话应看到**内置** `read_image`（描述 "Read a PNG/JPEG/WebP/GIF file and return the image itself. Requires the current model to accept image input."，仅 `file_path` 参数），且系统提示词无 `[Image #N]` 段。
- **file_path 链路**：`read_image file_path=<png>` → 文本路由走视觉模型返回描述；参数透传生效；不存在路径报可读错误。
- **image_index 链路**：粘贴图片 → 不再被拦截、模型看到 `[Image #1]` → `read_image image_index=1` 返回该图描述；无图会话报 "The number of images currently visible in the conversation is 0..."（英文）。
- **视觉路由能力**：`settings.yaml` 中视觉模型必须声明 `input: [text, image]`，否则工具报 "not declared as supporting image input"（英文）。
- **配置页**（需人类浏览器）：dev 设置 → 读图模型配置，提供商/模型下拉能选到「模型」页里的值，编辑后离开页面自动保存（无保存按钮），之后 read_image 用新模型。
- **环境自检（G1）**：`./scripts/verify-guards.sh` 全量扫描——正常 boot OK、`DSH_READ_IMAGE_FORCE_GUARD_FAIL=1` 下 harness 照常（headless OK + dev 200）且 `~/.dsh/logs/dsh-read-image-guard.log` 生成；改码后至少跑一遍 `node --test test/guards.test.mjs test/runtime.test.mjs`（从 dev 副本，见测试文件头注释）。

## 已知限制 / 待办

- **配置页依赖 typert 端点**：设置 → 读图页由客户端 apply 内 `ctx.remote.$mount` 自挂载 `readImageConfig` 后读写（见教训 9）；host 服务未注册（如被禁用）时 remote face 拿不到，页面可能卡在"加载中"（见 `docs/known-hacks.md` A5），刷新/重试即可，不影响 read_image 工具本身。
- **配置页不在 Web 设置白名单里**：浏览器 settingsScope 对 `dsh-read-image` 命名空间仍回 `settings-not-exposed`——这是设计使然（typert 桥是唯一通道），不要在客户端改回 settingsScope。
- **环境自检（G1）**：插件 boot 前全量探测 harness 契约，失败即安静停用（不阻塞 harness），诊断写入 `~/.dsh/logs/dsh-read-image-guard.log`；自检失败的排查入口是这份日志 + 前台双语提示。强行加载：settings.yaml `dsh-read-image: { guard: { enabled: false } }`（自担风险，见 `docs/known-hacks.md` G1）。
- 压缩（compaction）会截断历史 → 旧 `[Image #N]` 索引失效（工具返回明确错误；可选会话级持久索引注册表）。
- 重复读图不缓存（设计如此，可加 `cacheResults` 配置）。
- 视觉路由若网关实际不支持图片输入，适配器会返回错误——工具会原样报告。

## 已知 hack 与架构债

为绕开 harness 限制刻意采用的非常规写法（M1 monkey-patch、M2 waterfall 重入、markRemote 手搓装饰器、客户端 $mount 自挂载、伪造 zod codec、routeOf 深挖 agent 内部等）的**作用 / 风险 / 加固方向**，统一记录在 [`docs/known-hacks.md`](docs/known-hacks.md)。这些写法都有产品功能价值、不能随意删除，但依赖 harness 内部实现，升级后可能静默失效——改动相关代码前先读对应条目。
