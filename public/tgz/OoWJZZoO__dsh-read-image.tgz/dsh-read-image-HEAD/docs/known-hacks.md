# 已知 hack 与架构债

本文件记录 dsh-read-image 中**为绕开 harness 限制而刻意采用的非常规写法**（"不那么插件"的部分）。每个 hack 都有明确的产品功能价值，不能随意删除；但它们都依赖 harness 的内部实现细节，升级后可能静默失效。改动相关代码前先读对应条目。

> 定位：这些条目是"为什么这样做"的决策记录，与 AGENTS.md「硬核教训」（真实事故）互补——教训是"发生过什么"，这里是"当前还在承担哪些技术债"。
>
> 加固状态：A1 / A2 / A3 / A5 / A6 已加固（见各条目「加固状态」）；A4 无代码级替代维持现状；B4 是已知限制、降级路径可用。**G1 环境自检 Guard**（本文件末尾）是所有 hack 的"总保险丝"——任一 hack 依赖的 harness 契约失效时，插件以"不阻塞 harness"的方式自行停用。

---

## G1 · 环境自检 Guard（总保险丝，fail-safe）

- **位置**：`lib/guards.js`（`checkHostEnvironment` / `writeGuardLog` / `guardFailNotice`）+ `lib/index.js`（apply 开头）+ `lib/client.js`（内联守卫）
- **作用**：**让"hack 依赖的 harness 内部契约失效"从"把整个 harness 带死"变成"插件安静停用"**。已从 harness 源码确认：dsh-app-boot 的 `assertEntriesActivated()` 与 dsh-client-web 的 `assertEntriesActive()` 对插件 entry 的 **failed**（apply 抛错）/ **pending**（inject 缺失）/ **import 失败** 一律判定为 boot 失败并 throw（"N entries did not activate"）——即插件 apply 阶段任何异常都会杀死整个 harness（已用对照实验证实：临时让 apply 抛错，headless 直接 exit 1）。**插件唯一的"安全失败模式"是 apply 正常返回（fiber 保持 active）但不安装任何 hook。**
- **为什么 hack**：harness 对插件失败零隔离，只能自己保证"失败也正常返回"。
- **实现**：
  - apply 开头（settings 注册之后）跑 `checkHostEnvironment(ctx, { dshLlm, typertProtocol })`，逐项探测全部 harness 契约（ctx 服务形状 + dsh-llm / typert-protocol 具名导出），**永不抛错**（单项 try/catch，敌意输入也降级为问题项），一次汇报全部问题；
  - 失败路径：完整诊断**写入 `~/.dsh/logs/dsh-read-image-guard.log`**（`writeGuardLog`，覆盖写、路径恒定），前台只打**一条双语提示**（`guardFailNotice`，含日志路径与跳过开关指引），然后 `return`——不注册桥、不装监听、不包装、不注册工具；
  - 依赖防御化：`runtime.js` / `config-remote.js` / `index.js` 全部改为**命名空间导入**（`import * as ...`），harness 具名导出被改名/删除时不再是 import 阶段致命错误，而是 `undefined` → 被 guard 检出 → 走安全退出；`ReadImageConfigService` 类改为 `createReadImageConfigBridge()` 工厂（guard 通过后才构造，`extends` 表达式延迟求值）；
  - 客户端同构：`client.js` apply 开头内联守卫（ctx 服务形状），失败 → `console.error` 双语提示 + `return`（不 $mount、不注入 slot），web boot 不受影响（客户端无 settings 通道，故无跳过开关——客户端失败几乎总是宿主桥未注册，宿主 guard 已覆盖）；
  - `timer` 不再注入（`inject` 只剩 `['llm','settings','agents']`）：重试调度改自管 `setTimeout`（`schedule`，dispose 时统一 `clearTimeout`）——少一个"服务改名即 pending 杀死 boot"的挂点。
- **跳过开关（用户自担风险）**：`~/.dsh/settings.yaml` 的 `dsh-read-image:` 段写 `guard: { enabled: false }` 跳过自检强行加载；环境变量 `DSH_READ_IMAGE_FORCE_GUARD_FAIL=1` 强制走失败路径（自动化验证用）。提示文案中已含此指引。
- **残余风险**：`@deepseek-ai/dsh-tools`（defineTool）、`@deepseek-ai/schemastery`（z）与 dsh-llm/typert-protocol **整个包**（而非导出）仍是静态依赖——包整体消失时插件仍在 import 阶段死亡；但这些是 harness 自身运行的根基，它们没了 harness 本身就死了，"harness 照常启动"场景不成立，可接受。`inject` 的三个服务名同理（核心服务，改名即 harness 自身损坏）。
- **验证**：`test/guards.test.mjs`（矩阵 + 失败路径零副作用 + 成功路径 + 开关）+ `scripts/verify-guards.sh`（正常 / 强制失败 headless+dev 全量扫描）。

---

## A1 · M1 准入放行：monkey-patch `llm.resolveModelInfo`

- **位置**：`lib/index.js`（apply 内 `ctx.effect` 包装）
- **作用**：实现"用户发图片不再被拦截"。api-proxy 的准入闸门按模型声明的 input 检查，纯文本路由（deepseek 等）发图会被拒绝；包装器给文本路由追加 `image` input 声明 → 图片能进入会话。**这是插件存在的第一块基石。**
- **为什么 hack**：harness 没有"按会话放行图片输入"的配置面，只能改共享服务实例的方法。
- **风险**：
  - 与其他插件同时 patch 同一方法会互相覆盖（dispose 还原的是 apply 时的旧引用，可能还原掉别人后装的包装器）；
  - 对网关"撒谎"，像素能否不泄漏完全依赖 M2 投影兜底；
  - 真值表未就绪的启动早期，包装器对所有"未知名路由"生效。
- **加固方向**：patch 时把旧包装器串成链而非直接替换；启动期避免包装（等真值表首次就绪）。
- **加固状态（已做）**：dispose 改为 **identity 守卫 + 降级透传**——dispose 时仅当 `llm.resolveModelInfo` 仍是自己的包装器才还原旧引用；若已被后装插件包装，则置 `admissionActive=false` 让包装器变透明透传（行为完全移除、不破坏别人的链）并 `logger.warn`。启动期 deferral **未做**：分析后确认真值表空时 M2 也默认投影，方向安全，deferral 只消除 0–15s 的瞬时功能降级，收益不抵复杂度（见 A2 兜底）。

## A2 · M2 投影：waterfall 内 `this.stream(projected)` 重入派发

- **位置**：`lib/index.js`（`llm/stream` 监听器）+ `lib/runtime.js`（`projectRequest`）
- **作用**：实现"像素永不进文本 API"。在模型请求发出前的最后边界把图片块原位替换为 `[Image #N]` 文本，再重入 waterfall 派发。**这是"模型看到 [Image #N]"的核心机制。**
- **为什么 hack**：harness 没有"请求改写"钩子，只能在 waterfall 监听器里用重入完成替换。
- **风险**：
  - 依赖监听器**注册顺序**：前面的监听器看到原请求、后面的看到投影后请求；
  - `walkContent` 只覆盖 `image` 与数组型 `tool-result` 内容，harness 若新增未覆盖的 block 类型，图片会被静默漏过（要么被适配器拒、要么进文本 API）；
  - 投影收敛依赖"投影后必然无图"的假设（当前成立）。
- **加固方向**：投影后断言"无剩余图片块"，有则报错而非放行；为嵌套深度加防护。
- **加固状态（已做）**：
  - 检测（`messageHasImage`/`hasImageDeep`）改用 harness 导出的权威 walker **`contentHasImage`**（dsh-llm 的 gating/serialization/compaction 共用同一个 walk，插件不再维护口径副本）；未知名嵌套形状 **fail-closed**（报告"有图"），让投影边界拒绝转发而非静默泄漏。
  - `projectRequest` 返回前断言投影结果无剩余图片块，违反即抛错；监听器侧 catch + `logger.error` 后**响亮失败**（不转发、不重入死循环）。
  - 替换 walk（`projectContent` 的 block switch）保留自研并注释与权威 walker 的镜像契约：harness 新增图片承载形态时，若 switch 未同步，检测会先看到它 → 断言抛错 → 升级场景变成可诊断的响亮失败而非静默泄漏。
  - 形状矩阵单测 `test/runtime.test.mjs`（字符串 content、嵌套 tool-result、fail-closed 路径、不可变性与冻结断言）覆盖上述契约。

## A3 · 配置桥：手搓 `@Remote` 装饰器（markRemote）

- **位置**：`lib/config-remote.js`（`markRemote` + `ReadImageConfigService`）
- **作用**：实现"设置 → 读图页能保存配置"。typert Gateway 靠 `@Remote` 标记自动发现端点，但宿主 Node 运行时**没有装饰器语法**，手搓 fake `DecoratorContext` + `addInitializer` 得到等效标记。没有它：配置只能手写 settings.yaml。
- **为什么 hack**：Node 无 decorators flag，而 typert-protocol 的标记表是模块私有的，无法 import。
- **风险**：深度依赖 typert-protocol 对 `Remote` 的实现（只用 `addInitializer`）；若升级改用其他 context 字段（如 `getMetadata`），会**静默失效**（不报错、端点消失，配置页打不开）。
- **加固方向**：启动时自检端点确实挂载（如 `remote.get` 一次），失败则明确报错。
- **加固状态（已做）**：typert-protocol **官方导出 marker 表读取 API `remoteMethods(service)`**（已核对 v0.1.0-rc.6 源码），启动自检在 `ctx.plugin(ReadImageConfigService)` 后立刻用它对服务实例断言 `get`/`set` 端点存在，缺失即 `logger.error`（升级后 decorator 实现变化 → fake context 不报错但 mark 不发生 → 自检命中）。`remoteMethods` 用**命名空间导入 + typeof 判断**，未来版本若移除该导出，降级为"跳过自检"而非拖垮插件 boot。实例经 `getReadImageConfigService()` 获取（构造器留存最近实例）。

## A4 · 配置页：伪造 zod schema（looseSchema）

- **位置**：`lib/client.js`（`looseSchema` + `CONTRIBUTION` descriptors）
- **作用**：**让 web 界面能正常启动**。客户端 `validateContribution` 要求每个 remote 方法描述符带"严格 codec"（schema 有 `_zod` + `parse`）；zod 被内联进 dsh-api-remotes 的 bundle，插件无法 `require`，于是手工构造 `{_zod:{}, parse:(v)=>v}` 透传 schema 满足形状检查。没有它：整个 web boot 挂掉（见 AGENTS.md 教训 9 的真实事故）。
- **为什么 hack**：zod 实例拿不到、descriptor 校验又是硬性的。
- **风险**：客户端零类型校验（形状全靠 host 侧兜底）；zod 内部结构变化即崩。
- **加固方向**：与 A5 一起，靠"升级后 dev 验证清单"兜底；无更优替代前保持现状。

## A5 · 配置页：`ctx.remote.$mount` 自挂载命名空间

- **位置**：`lib/client.js`（apply 内 `await ctx.remote.$mount(CONTRIBUTION)`）
- **作用**：让浏览器拿到 `remote.readImageConfig` face。harness 对第三方插件**没有 remote 动态发现**（`remote.<ns>` 只对编译期硬编码的 `TYPERT_REMOTE$1..$5` 贡献注入），naive 写法（inject `"remote.readImageConfig"`）会让插件永久 pending 并把整个 web 搞挂。
- **为什么 hack**：缺官方机制，只能自挂载。
- **风险**：host 侧服务未注册时 `ctx.get("remote.readImageConfig")` 拿不到 face；当前 `load()` 里 `this.remote.get()` 在构建 `Promise.allSettled` 数组时同步抛错 → 页面卡"加载中"且无错误 UI（已知未修复项）。
- **加固方向**：mount 后校验 face 存在；`load()` 对 `remote` 缺失显式进入 error 状态并提示重试。
- **加固状态（已做）**：`apply` 内 `$mount` 包 try/catch（失败不拖垮 web boot），mount 后校验 face，缺失时控制器显式进入 error 状态；`load()` 开头对 `!this.remote` 直接进 error（带"刷新/重试"文案，现有 error UI 已有重试按钮）；`void controller.load()` 补 `.catch(() => {})` 杜绝未处理 rejection。

## A6 · 路由推断：`routeOf()` 深挖 agent 内部

- **位置**：`lib/index.js`（`routeOf`，被 `readImageTool.execute` 使用）
- **作用**：实现"多模态路由直接返回图片、文本路由走视觉代看"的分支判断——推断当前会话的 provider/model，查真值表决定返回真实图片还是文字描述。
- **为什么 hack**：工具执行上下文里没有现成的"当前路由"字段，只能从 `exec.agent.session.requestHeader()` / `exec.agent.options` 摸。
- **风险**：harness 内部 API 变动后静默拿到空值 → 一律走视觉代看（功能退化，但不报错、方向安全）。
- **加固方向**：拿到空值时补一条 debug 日志便于排障；长期等 harness 暴露官方路由 API。
- **加固状态（已做）**：`read_image` 执行时若 `routeOf` 推断出空 provider/model，打一条带 session id 的 debug 日志（升级回归可诊断；方向安全，不升级为 error）。官方路由 API 仍等 harness。

---

## 附 · B4：`[Image #N]` 编号口径假设

- **位置**：`lib/runtime.js`（`projectRequest` 注释）+ `lib/index.js`（工具解析）
- **内容**：M2 投影按 `request.messages` 的图片顺序编号（模型实际看到的序列）；`read_image` 工具按 `session.deriveMessages()` 解析索引。两者一致的前提是 harness 的 `buildRequest` 只包装消息不改顺序；**历史压缩（compaction）/截断会使旧索引失效**，工具已给出可读错误并建议改用 `file_path`。
- **为何无法消除**：工具执行时拿不到 `llm/stream` 时刻的 `request.messages`（瞬时值），插件侧无法建立两套序列的映射。彻底方案是会话级持久索引注册表（见 AGENTS.md「已知限制」）。

---

## 附 · 已删除的 A7：设置导航图标 patch

`scripts/patch-harness.sh` 曾直接修改全局安装的 harness bundle（`/usr/lib/node_modules/.../dsh-client-ui-settings-general/lib/client.js`），为「读图」设置分节注入回形针图标。2025 年评审后**已删除**：纯外观价值、需 root、升级即丢、注入符号可能失效。若某环境此前已 patch 过，图标会保留到下次 dsh 升级；之后恢复为默认齿轮图标，功能不受影响。
