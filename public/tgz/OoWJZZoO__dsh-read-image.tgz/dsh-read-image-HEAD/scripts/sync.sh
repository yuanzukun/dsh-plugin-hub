#!/usr/bin/env bash
# Re-sync the in-development plugin source into the DEV and headless profile
# node_modules (the validation surfaces). The production web profile is NOT
# touched here — deploy a verified stable build into it explicitly with
# ./scripts/deploy.sh. This is the guard that keeps a broken in-progress
# plugin from ever reaching the running web GUI.
set -euo pipefail
# Repo root = this script's parent dir (scripts/ lives inside the repo root).
SRC="$(cd "$(dirname "$0")/.." && pwd)"
for prof in dev headless; do
  DEST="$HOME/.dsh/profiles/$prof/node_modules/@deepseek-ai/dsh-read-image"
  rm -rf "$DEST"
  mkdir -p "$DEST"
  cp -r "$SRC/package.json" "$SRC/lib" "$SRC/cordis.patch.yml" "$DEST/"
  echo "synced -> $DEST"
done
