#!/usr/bin/env bash
# Full sweep for the environment self-check (lib/guards.js) and the A-class
# hardening. Verifies the core promise: when the guard trips, the plugin goes
# inert WITHOUT blocking or breaking the harness boot.
#
#   1. syntax check
#   2. sync to dev/headless profile copies
#   3. unit tests (runtime shape-matrix + guard matrix, from the dev copy)
#   4. normal boot: headless replies OK (plugin active, nothing broken)
#   5. forced-failure boot (DSH_READ_IMAGE_FORCE_GUARD_FAIL=1):
#        - headless STILL replies OK (harness alive, plugin inert)
#        - guard log file written (~/.dsh/logs/dsh-read-image-guard.log)
#   6. forced-failure dev web: server still comes up on 3082 (plugin inert)
#
# Safe by construction: only touches dev/headless profiles and the dev web
# process (pattern "dsh --profile dev"); the production "dsh web" process is
# never matched or signalled.
set -euo pipefail

SRC="$(cd "$(dirname "$0")/.." && pwd)"
cd "$SRC"
GUARD_LOG="$HOME/.dsh/logs/dsh-read-image-guard.log"

echo "== 1. syntax =="
node --check lib/index.js
node --check lib/runtime.js
node --check lib/config-remote.js
node --check lib/guards.js
node --check lib/client.js
node --check test/runtime.test.mjs
node --check test/guards.test.mjs
echo "PASS"

echo "== 2. sync to dev/headless =="
./scripts/sync.sh
DEST="$HOME/.dsh/profiles/dev/node_modules/@deepseek-ai/dsh-read-image"
cp -r test "$DEST/test"
trap 'rm -rf "$DEST/test"' EXIT

echo "== 3. unit tests =="
(cd "$DEST" && node --test test/runtime.test.mjs test/guards.test.mjs)

echo "== 4. normal headless smoke =="
OUT="$(dsh --profile headless "请直接回复：OK" 2>&1 || true)"
if echo "$OUT" | grep -q '^OK$'; then
  echo "PASS: headless replies OK (plugin active)"
else
  echo "FAIL: headless did not reply OK"
  echo "$OUT"
  exit 1
fi

echo "== 5. forced-failure headless (plugin must be inert, harness must run) =="
rm -f "$GUARD_LOG"
OUT="$(DSH_READ_IMAGE_FORCE_GUARD_FAIL=1 dsh --profile headless "请直接回复：OK" 2>&1 || true)"
if echo "$OUT" | grep -q '^OK$'; then
  echo "PASS: harness alive with the guard forced to fail"
else
  echo "FAIL: headless died under forced guard failure"
  echo "$OUT"
  exit 1
fi
if [ -f "$GUARD_LOG" ]; then
  echo "PASS: guard diagnostics log written ($GUARD_LOG)"
  grep -q "FAILED" "$GUARD_LOG" || { echo "FAIL: guard log lacks failure marker"; exit 1; }
else
  echo "FAIL: guard diagnostics log missing"
  exit 1
fi
# The front-desk notice may or may not surface on this harness's stdout
# (the web GUI is the real front desk); verify it when visible.
if echo "$OUT" | grep -q "自检未通过\|self-check failed"; then
  echo "PASS: bilingual front-desk notice logged"
else
  echo "NOTE: front-desk notice not visible on headless stdout (normal — the web GUI is the front desk); notice presence is asserted by test/guards.test.mjs"
fi

echo "== 6. forced-failure dev web (server must still come up on 3082) =="
# Stop any dev instance we own (pattern can never match the production "dsh web").
pkill -f "dsh --profile dev" 2>/dev/null || true
sleep 1
DEV_LOG="$(mktemp)"
DSH_READ_IMAGE_FORCE_GUARD_FAIL=1 dsh --profile dev >"$DEV_LOG" 2>&1 &
DEV_PID=$!
cleanup_dev() { kill "$DEV_PID" 2>/dev/null || true; wait "$DEV_PID" 2>/dev/null || true; rm -f "$DEV_LOG"; }
trap cleanup_dev EXIT
OK=0
for _ in $(seq 1 30); do
  if curl -s -o /dev/null -w '%{http_code}' http://127.0.0.1:3082/ 2>/dev/null | grep -q '^200$'; then
    OK=1
    break
  fi
  sleep 1
done
if [ "$OK" = "1" ]; then
  echo "PASS: dev web up on 3082 with the guard forced to fail (plugin inert)"
else
  echo "FAIL: dev web did not come up under forced guard failure"
  tail -50 "$DEV_LOG"
  exit 1
fi
if [ -f "$GUARD_LOG" ]; then
  echo "PASS: guard diagnostics log written during dev boot"
else
  echo "FAIL: guard diagnostics log missing after dev boot"
  exit 1
fi

echo "== all guard checks passed =="
