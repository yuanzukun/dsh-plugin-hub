#!/usr/bin/env bash
# Deploy a VERIFIED stable build of dsh-read-image into the production web
# profile. Run this ONLY after dev/headless validation passes, then restart
# dsh web (human step). Development code in the repo never reaches web except
# through this explicit gate.
set -euo pipefail
# Repo root = this script's parent dir (scripts/ lives inside the repo root).
SRC="$(cd "$(dirname "$0")/.." && pwd)"
DEST="$HOME/.dsh/profiles/web/node_modules/@deepseek-ai/dsh-read-image"
rm -rf "$DEST"
mkdir -p "$DEST"
cp -r "$SRC/package.json" "$SRC/lib" "$SRC/cordis.patch.yml" "$DEST/"
echo "deployed stable -> $DEST"
echo "next: restart dsh web (kill <pid> && cd ~ && node /usr/bin/dsh web)"
