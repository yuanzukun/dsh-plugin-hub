# dsh-goal-scaffold

[English](README.md) | 中文

**一句话：你随手甩一句"帮我从零写个 XX 系统"，这个插件会先拦一下问你"要不要先规划？"——免得 AI 闷头狂奔二十分钟，交出一堆没人验收过的代码。**

不装它的时候：一句话大需求直接开干，没计划、没验收标准，跑偏了你也说不清从哪开始偏的。装了之后，每个会话里第一条这样的消息会被轻轻拦一下：

```text
你发出一句大任务
  → 弹一个三选：
      ① 先规划（推荐）  ② 直接开始  ③ 本会话不再提示
  → 选 ①：你的需求原样放行，同时告诉 agent——
     先写 plan.md（清单里每一项都带"怎么算完成"的验收条件），
     定一个有轮数上限的目标，把计划给你看一眼，然后一项项做、做完一项勾一项
```

你只点一下，剩下的规矩它自己守。和 [`dsh-verify-judge`](https://github.com/zriyox/dsh-verify-judge) 配套：守门员管"想清楚再跑"，验收员管"说完成了要真验"。

## 安装

```sh
dsh plugin --profile web add github:zriyox/dsh-goal-scaffold
# 或本地目录：
dsh plugin --profile web add /absolute/path/to/dsh-goal-scaffold
```

## 行为说明

- **每会话最多问一次**；"本会话不再提示"会彻底安静。
- **headless 安全**：没有问人渠道时（如 headless 一次性任务）消息原样通过，不阻塞不报错。
- **只认真人消息**：goal 续跑递话、插件注入、工具产物都不会触发。
- **取消即放行**：你把问题关掉去打字，原消息照常进行。

## 实测记录（2026-08-15，Web UI 真实驱动）

- 长任务消息 → 弹三选 → 选"先规划" → 模型产出 9 项带可运行验收命令的 plan.md、建 goal（UI 出现目标卡片）、逐项执行打勾，最终 9/9 完成盖章；
- 短问答消息 → 不弹（无误报）；
- 选"Just start" → 直接开工，不产生任何规划产物；
- 选"本会话不再提示" → 后续长任务消息不再弹；
- headless 长任务 → 安静直通，无任何干扰。

## 配置

```yaml
- id: goal-scaffold
  config:
    enabled: true          # 总开关
    minLength: 80          # 参与判定的最小消息长度
    extraSignals: ['迁移']  # 自定义范围信号词（大小写不敏感）
```

## 开发

```sh
pnpm install
pnpm run build   # tsc → lib/
```

## 许可证

[MIT](LICENSE)
