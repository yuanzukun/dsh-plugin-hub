/**
 * goal-scaffold: the long-task gatekeeper for DeepSeek Harness.
 *
 * A one-sentence mammoth request ("rebuild the whole project") sent straight
 * to work is the classic goal-drift setup. This plugin watches the pre-step
 * boundary for human-authored long-task messages and, once per session, asks
 * the user whether to plan first. Choosing "plan first" delegates the original
 * message untouched, then appends a plugin-sourced instruction telling the
 * model to scaffold `plan.md` (acceptance-criteria checklist) and create a
 * capped goal before implementing.
 *
 * Degrades to a pure pass-through where no user-questions channel exists
 * (headless) or when the user dismisses the prompt. Messages from non-human
 * sources (goal-driver continuations, plugin injections) never trigger it.
 *
 * @module dsh-goal-scaffold
 */

import type { Context } from '@deepseek-ai/cordis'
import type { PreStepDecision } from '@deepseek-ai/dsh-agent'
import type { UserMessage } from '@deepseek-ai/dsh-session'
import type { MessageSource } from '@deepseek-ai/dsh-llm'
import type { AskUserQuestionAnswer } from '@deepseek-ai/dsh-user-questions/types'

/** The questions service is absent in headless compositions — model it locally. */
interface UserQuestionsService {
  ask(request: {
    questions: {
      id: string
      question: string
      detail?: string
      header?: string
      options?: { label: string; description?: string }[]
    }[]
    agent: unknown
    signal?: AbortSignal
  }): Promise<AskUserQuestionAnswer>
}

/** Plugin configuration (validated at load by {@link resolveConfig}). */
export interface Config {
  /** Master switch (default true). */
  enabled?: boolean
  /** Minimum human-message length that participates in detection (default 80). */
  minLength?: number
  /** Extra long-task signal phrases (matched case-insensitively, substring). */
  extraSignals?: string[]
}

/** The resolved, fully-defaulted configuration. */
interface ResolvedConfig {
  enabled: boolean
  minLength: number
  signals: string[]
}

/**
 * Built-in long-task signals: scope-expanding phrases in Chinese and English.
 * Short single-step asks ("写一个函数") stay below the length bar; these phrases
 * catch the mammoth scope words even in shorter messages.
 */
const DEFAULT_SIGNALS = [
  '全部', '所有', '整个', '重构', '批量', '完整', '从零', '搭建', '管理系统',
  'everything', 'entire', 'whole', 'refactor', 'rewrite', 'all the', 'from scratch',
]

/**
 * Validate the raw loader config; misconfiguration fails loud at load.
 * @param raw - the plugin row's `config` value.
 * @returns the resolved configuration.
 */
function resolveConfig(raw: unknown): ResolvedConfig {
  const config = (raw ?? {}) as Config
  const enabled = config.enabled ?? true
  if (typeof enabled !== 'boolean') {
    throw new TypeError('goal-scaffold: `enabled` must be a boolean')
  }
  const minLength = config.minLength ?? 80
  if (!Number.isSafeInteger(minLength) || minLength < 1) {
    throw new TypeError('goal-scaffold: `minLength` must be a positive integer')
  }
  const extraSignals = config.extraSignals ?? []
  if (!Array.isArray(extraSignals) || extraSignals.some(s => typeof s !== 'string' || s.trim() === '')) {
    throw new TypeError('goal-scaffold: `extraSignals` must be an array of non-empty strings')
  }
  return {
    enabled,
    minLength,
    signals: [...DEFAULT_SIGNALS, ...extraSignals.map(s => s.trim().toLowerCase())],
  }
}

/** Extract the concatenated text of one message's text blocks. */
function messageText(message: UserMessage): string {
  return message.content
    .map(block => block.type === 'text' ? block.text : '')
    .join('\n')
    .trim()
}

/** True when the source is a human typing, not a driver/plugin/tool artifact. */
function isHuman(message: UserMessage): boolean {
  const source = message.source as MessageSource | undefined
  return source?.kind === 'user'
}

/**
 * The long-task heuristic: long enough to matter AND carrying a scope signal,
 * or extremely long on its own.
 * @param text - the human message text.
 * @param config - resolved configuration.
 * @returns whether to ask about planning.
 */
function looksLikeLongTask(text: string, config: ResolvedConfig): boolean {
  if (text.length < config.minLength) return false
  const lower = text.toLowerCase()
  if (config.signals.some(signal => lower.includes(signal))) return true
  return text.length >= config.minLength * 3
}

/** Per-session ask state: we ask at most once per session. */
type SessionState = 'asked' | 'never-again'

/** The instruction appended when the user picks "plan first". */
const PLAN_FIRST_INSTRUCTION = 'The human chose to plan before execution. Before writing any '
  + 'implementation code: 1) Break this task into `plan.md` in the workspace root — a checklist '
  + 'where every item carries a minimal, verifiable acceptance criterion (a command to run, where '
  + 'one exists). 2) Create a goal via create_goal whose objective references `plan.md` '
  + '(maxGoalRounds: 5). 3) Present the plan to the human, then start with the first item, ticking '
  + 'each item in `plan.md` as you complete it. If a verification gate (e.g. verify-judge) is '
  + 'installed, goal completion will run the workspace verification commands — so make the '
  + 'acceptance criteria real.'

/**
 * Mount the gatekeeper on the pre-step waterfall.
 * @param ctx - the plugin's context.
 * @param rawConfig - the plugin row's config, validated at load.
 */
export function apply(ctx: Context, rawConfig?: unknown): void {
  const config = resolveConfig(rawConfig)
  const sessions = new Map<string, SessionState>()

  ctx.on('agent/pre-step', async ({ agent, messages, signal }, next): Promise<PreStepDecision> => {
    if (!config.enabled) return next()
    if (sessions.has(agent.id)) return next()

    const humanTexts = messages.filter(isHuman).map(messageText).filter(t => t.length > 0)
    if (humanTexts.length === 0) return next()
    const text = humanTexts.join('\n')
    if (!looksLikeLongTask(text, config)) return next()

    const interaction = ctx.get('userQuestions') as UserQuestionsService | undefined
    if (interaction === undefined) return next() // headless: no one to ask

    sessions.set(agent.id, 'asked') // ask at most once per session, whatever the answer

    const answer = await interaction.ask({
      agent,
      signal,
      questions: [{
        id: 'goal-scaffold-plan-first',
        header: 'Long task detected',
        question: 'This looks like a long task. Plan it first (plan.md + a capped goal) before diving in?',
        detail: text.length > 500 ? text.slice(0, 500) + '…' : text,
        options: [
          { label: 'Plan first (Recommended)', description: 'Scaffold plan.md with acceptance criteria and a capped goal, then execute against it.' },
          { label: 'Just start', description: 'Skip planning; work on the task directly.' },
          { label: "Don't ask again this session", description: 'Pass through now and stop prompting for this session.' },
        ],
      }],
    }).catch((cause: unknown) => {
      // A dismissed question is the user taking the turn back to speak — pass
      // through untouched rather than treating it as a choice.
      return cause instanceof Error && cause.name === 'UserQuestionError' ? null : Promise.reject(cause)
    })

    if (answer === null) return next()

    const selected = answer.answers.find(a => a.id === 'goal-scaffold-plan-first')?.selected ?? []
    if (selected.includes("Don't ask again this session")) {
      sessions.set(agent.id, 'never-again')
      return next()
    }
    if (!selected.includes('Plan first (Recommended)')) return next()

    // Delegate first (downstream listeners still see the original messages),
    // then append our separately-sourced instruction to the entered batch.
    const decision = await next()
    if (decision.kind !== 'enter') return decision
    const instruction = Object.freeze(structuredClone({
      id: crypto.randomUUID(),
      role: 'user' as const,
      content: [{ type: 'text' as const, text: PLAN_FIRST_INSTRUCTION }],
      source: { kind: 'plugin', plugin: 'goal-scaffold' },
    })) as UserMessage
    return { kind: 'enter', messages: [...decision.messages, instruction] }
  })
}
