# dsh-goal-scaffold

English | [中文](README.zh.md)

**What it does, in one sentence: when you drop a huge one-liner like "build me a complete task management system", this plugin asks you "want to plan it first?" — before the agent burns twenty minutes improvising.**

Without it, a mammoth one-sentence request goes straight to work: no plan, no acceptance criteria, and nobody can tell whether it's drifting. With `goal-scaffold` installed, the first such message in a session gets a gentle interception:

```text
you send a big vague task
  → a three-option prompt pops up:
      ① Plan first (Recommended)  ② Just start  ③ Don't ask again this session
  → pick ①: your request goes through, and the agent is told to first write
    plan.md (a checklist where every item has a verifiable acceptance
    criterion), create a goal with a round cap, show you the plan — then
    execute item by item, ticking boxes as it goes
```

You stay the boss of one click; the agent does the disciplined rest. Pairs with [`dsh-verify-judge`](https://github.com/zriyox/dsh-verify-judge), which makes the final "done" require passing tests.

## Install

```sh
dsh plugin --profile web add github:zriyox/dsh-goal-scaffold
# or a local checkout:
dsh plugin --profile web add /absolute/path/to/dsh-goal-scaffold
```

## Behavior notes

- **Asks at most once per session.** "Don't ask again" silences it; so does any answer, until a new session.
- **Headless-safe**: where no user-questions channel exists (e.g. the `headless` profile), every message passes through untouched — nothing blocks, nothing errors.
- **Human messages only**: goal-driver continuations, plugin injections, and tool artifacts never trigger detection.
- **Fail-open on dismissal**: if you dismiss the question to type something else, your original message proceeds as-is.

## Configuration

```yaml
- id: goal-scaffold
  config:
    enabled: true          # master switch
    minLength: 80          # minimum message length that participates in detection
    extraSignals: ['迁移']  # extra case-insensitive scope phrases
```

## Development

```sh
pnpm install
pnpm run build   # tsc → lib/
```

## License

[MIT](LICENSE)
