/**
 * goal-scaffold: the long-task gatekeeper for DeepSeek Harness.
 *
 * A one-sentence mammoth request ("rebuild the whole project") sent straight
 * to work is the classic goal-drift setup. This plugin watches the pre-step
 * boundary for human-authored long-task messages and, once per session, asks
 * the user whether to plan first. Choosing "plan first" delegates the original
 * message untouched, then appends a plugin-sourced instruction telling the
 * model to scaffold `plan.md` (acceptance-criteria checklist) and create a
 * capped goal before implementing.
 *
 * Degrades to a pure pass-through where no user-questions channel exists
 * (headless) or when the user dismisses the prompt. Messages from non-human
 * sources (goal-driver continuations, plugin injections) never trigger it.
 *
 * @module dsh-goal-scaffold
 */
import type { Context } from '@deepseek-ai/cordis';
/** Plugin configuration (validated at load by {@link resolveConfig}). */
export interface Config {
    /** Master switch (default true). */
    enabled?: boolean;
    /** Minimum human-message length that participates in detection (default 80). */
    minLength?: number;
    /** Extra long-task signal phrases (matched case-insensitively, substring). */
    extraSignals?: string[];
}
/**
 * Mount the gatekeeper on the pre-step waterfall.
 * @param ctx - the plugin's context.
 * @param rawConfig - the plugin row's config, validated at load.
 */
export declare function apply(ctx: Context, rawConfig?: unknown): void;
