import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, writeFile, readFile, realpath, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join, resolve, relative, isAbsolute } from 'node:path';
import vm from 'node:vm';
import { registerHooks } from 'node:module';
import { pathToFileURL } from 'node:url';
// Optional existing local Zod copy for no-install test environments.
if (process.env.ZOD_TEST_MODULE) registerHooks({ resolve(specifier, context, next) {
  return next(specifier === 'zod' ? pathToFileURL(process.env.ZOD_TEST_MODULE).href : specifier, context);
} });

function durableStore() {
  const tables = new Map(); let opened = false;
  const store = { tables, async open(spec) {
    assert.equal(opened, false); opened = true;
    for (const [name, entry] of Object.entries(spec.tables)) {
      assert.equal(typeof entry.valueSchema.safeParse, 'function');
      if (!tables.has(name)) tables.set(name, new Map());
      for (const value of tables.get(name).values()) entry.valueSchema.parse(value);
    }
    return { table(name) {
      const data = tables.get(name), schema = spec.tables[name].valueSchema;
      return { get: key => structuredClone(data.get(key)), entries: () => structuredClone([...data]).values(),
        async put(key, value) { if (store.failWrites) throw new Error('storage offline'); data.set(key, structuredClone(schema.parse(value))); } };
    }, async close() { opened = false; } };
  } };
  return store;
}

async function fixture(t, execute = async prompt => ({ prompt }), onDispose = async () => {}, options = {}) {
  const root = await mkdtemp(join(tmpdir(), 'dynamic-workflow-test-'));
  const effects = []; let tool; let command; let readRoute; const requests = []; let disposed = 0;
  const listeners = new Map(), catalog = new Map(), histories = new Map(), live = new Map(), continuations = [];
  function on(name, handler) { if (!listeners.has(name)) listeners.set(name, new Set()); listeners.get(name).add(handler); return () => listeners.get(name).delete(handler); }
  async function emit(name, ...args) { for (const handler of [...(listeners.get(name) || [])]) await handler(...args); }
  const policyActivations = [];
  function nativeChild(childId) {
    const childListeners = new Map(), policy = {};
    const child = { id: childId, status: 'running', session: { header: { parentSession: owner.id } }, ctx: {
      effect: fn => fn(), on(name, handler) { childListeners.set(name, handler); return () => childListeners.delete(name); },
      systemPrompt: { section(spec) { policy.prompt = spec.text; return () => { delete policy.prompt; }; } },
      tools: {
        restrict(spec) { policy.tools = [...spec.allow]; return () => { delete policy.tools; }; },
        guard(handler) { policy.guard = handler; return () => { delete policy.guard; }; },
      },
    } };
    return { child, childListeners, policy };
  }
  const subagents = {
    getProvider: name => name === 'spawn' ? { prepareContinuable: async () => ({}) } : undefined,
    async startActivation(spec) {
      const childId = spec.childId;
      const prompt = spec.request.prompt.map(part => part.text).join('\n');
      const request = { args: { prompt, options: spec.request.agentOptions }, meta: { name: spec.label } };
      requests.push(request);
      catalog.set(childId, { id: childId, mode: 'continuable', label: spec.label, createdAt: Date.now() });
      histories.set(childId, [prompt]);
      const { child, childListeners, policy } = nativeChild(childId);
      live.set(childId, child);
      await emit('agent/created', { agent: child, source: 'create' });
      const config = await childListeners.get('agent/request')({}, async () => ({ provider: 'old-provider', model: 'old-model' }));
      policyActivations.push({ childId, prompt: policy.prompt, tools: policy.tools && [...policy.tools] });
      const result = Promise.resolve().then(async () => {
        const value = await execute(prompt, config);
        const text = typeof value === 'string' ? value : JSON.stringify(value);
        live.delete(childId);
        await emit('subagent/end', { id: childId, local: true, runId: `initial-${requests.length}`, stopReason: 'completed', lastAssistantMessage: [{ type: 'text', text }] });
        return { stopReason: 'completed', output: [{ type: 'text', text }] };
      });
      return { childId, messageId: 'initial-message', result, async dispose() { await result; } };
    },
    listChildren: async () => [...catalog.values()],
    async sendMessage(parent, childId, content, delivery) {
      assert.equal(parent, owner);
      assert.equal(catalog.get(childId)?.mode, 'continuable');
      if (live.get(childId)?.status === 'running' && options.onMessage) return options.onMessage({ parent, childId, content, signal: delivery.signal });
      const { child, childListeners, policy } = nativeChild(childId);
      live.set(childId, child);
      await emit('agent/created', { agent: child, source: 'resume' });
      const config = await childListeners.get('agent/request')({}, async () => ({ provider: 'old-provider', model: 'old-model' }));
      continuations.push({ childId, content, config });
      policyActivations.push({ childId, prompt: policy.prompt, tools: policy.tools && [...policy.tools] });
      histories.get(childId).push(content[0].text);
      live.delete(childId);
      const value = options.executeContinuations ? await execute(content[0].text, config) : { model: config.model, seed: histories.get(childId)[0] };
      await emit('subagent/end', { id: childId, local: true, runId: `continuation-${continuations.length}`, stopReason: 'completed', lastAssistantMessage: [{ type: 'text', text: typeof value === 'string' ? value : JSON.stringify(value) }] });
      return 'accepted-message';
    },
    interrupt() {}, async drainChildren() {},
  };
  const fs = {
    async resolve(path, options = {}) { const p = await realpath(resolve(options.cwd || root, path)); return { targetKey: p, displayPath: p }; },
    contains(a, b) { const rel = relative(a.targetKey, b.targetKey); return !rel.startsWith('..') && !isAbsolute(rel); },
    readText(target) { return readFile(target.targetKey, 'utf8'); },
  };
  fs.readBytes = async (target, signal, maxBytes) => { signal?.throwIfAborted(); const bytes = new TextEncoder().encode(await fs.readText(target)); if (bytes.byteLength > maxBytes) throw Error('FS_TOO_LARGE: file too large (1 MiB input limit)'); return bytes; };
  const engine = { start(request) {
    requests.push(request);
    if (options.native) {
      const childId = `child-${requests.length}`, runId = `w${requests.length}`;
      catalog.set(childId, { id: childId, mode: 'continuable', label: `${request.meta.name} child 1`, createdAt: Date.now() });
      histories.set(childId, [`original history for ${childId}`]);
      if (!options.omitChildEvent) queueMicrotask(() => emit('workflow/agent-start', { id: runId }, { seq: 1, label: request.args.options.label, childId }));
    }
    let cancel;
    const cancelled = new Promise(resolve => { cancel = () => resolve({ value: null, stopReason: 'cancelled', agentsStarted: 1 }); });
    const result = Promise.race([cancelled, (async () => {
      try {
        const script = new vm.Script(`(async () => { ${request.script} })()`);
        const value = await script.runInNewContext({ args: request.args, agent: execute });
        return { value, stopReason: 'completed', agentsStarted: 1 };
      } catch (error) { return { value: null, stopReason: 'error', error: error.message, agentsStarted: 1 }; }
    })()]);
    request.signal?.addEventListener('abort', cancel, { once: true });
    return { id: `w${requests.length}`, meta: request.meta, result, cancel, async dispose() { await result; await onDispose(); disposed++; } };
  } };
  const services = { fs, workingDirectory: { ensure: async () => root }, workflowEngine: engine,
    ...(options.settings ? { settings: options.settings } : {}),
    ...(options.native ? { subagents, agents: { get: id => live.get(id) } } : {}) };
  const owner = { id: 'owner', ctx: { get: key => services[key] } };
  const storageDomain = durableStore();
  const ctx = { storageDomain, commands: { register(value) { command = value; return () => { command = undefined; }; } }, tools: { register(value) { tool = value; return () => { tool = undefined; }; } }, effect(fn) { const off = fn(); effects.push(off); return off; }, ...(options.settings ? { settings: options.settings } : {}), ...(options.native ? { on } : {}) };
  ctx.inject = (_keys, setup) => {
    if (!options.readTransport) return;
    setup({ effect: ctx.effect,
      connection: { fetch: { register(route) { readRoute = route; return async () => { readRoute = undefined; }; } } },
      sessionController: { async resolveAgent(id) {
        if (id === 'missing') return { error: { code: 'session/not-found', message: 'Session not found' } };
        return { agent: id === owner.id ? owner : { ...owner, id } };
      } },
    });
  };
  const module = await import('./index.js').catch(error => error.code === 'ERR_MODULE_NOT_FOUND' ? {} : Promise.reject(error));
  assert.equal(typeof module.apply, 'function', 'Host plugin must export apply');
  await module.apply(ctx, options.config);
  t.after(async () => { for (const effect of effects.reverse()) await effect?.(); await rm(root, { recursive: true, force: true }); });
  return { root, owner, requests, storageDomain, services, native: { catalog, histories, continuations, live, policyActivations }, restart: () => module.apply(ctx), get disposed() { return disposed; },
    get command() { return command; }, get readRoute() { return readRoute; }, listeners,
    write: workflow => writeFile(join(root, 'flow.json'), JSON.stringify(workflow)),
    call: (args, agent = owner, signal = new AbortController().signal) => tool.execute(args, { agent, signal }),
    unload: async () => { for (const effect of effects.splice(0).reverse()) await effect?.(); },
  };
}
test('quiet UI reads share workflow state, enforce session ownership, and reject mutations', async t => {
  const f = await fixture(t, undefined, undefined, { readTransport: true });
  assert.ok(f.readRoute, 'register a read route on the authenticated Connection carrier');
  assert.deepEqual(f.readRoute.methods, ['GET']);
  const read = (sessionId, args) => f.readRoute.fetch(new Request(`http://localhost${f.readRoute.path}?sessionId=${sessionId}&args=${encodeURIComponent(JSON.stringify(args))}`));
  const empty = await read('owner', { action: 'list' });
  assert.deepEqual(await empty.json(), { runs: [] });
  assert.equal(empty.headers.get('cache-control'), 'no-store');
  await f.write({ id: 'quiet-read', nodes: [{ id: 'one', prompt: 'hello' }] });
  const run = await f.call({ action: 'run', workflowPath: 'flow.json' });
  const own = await read('owner', { action: 'status', runId: run.runId });
  assert.equal(own.status, 200);
  assert.equal((await own.json()).runId, run.runId);
  const other = await read('other-owner', { action: 'list' });
  assert.deepEqual(await other.json(), { runs: [] });
  assert.notEqual((await read('other-owner', { action: 'status', runId: run.runId })).status, 200);
  assert.equal((await read('missing', { action: 'list' })).status, 404);
  assert.equal((await read('owner', { action: 'stop', runId: run.runId })).status, 400);
  await f.unload();
  assert.equal(f.readRoute, undefined, 'dispose the route with the plugin');
});

test('global router reads a live setting and ignores its own instructions', async t => {
  let enabled = false, calls = 0;
  const setting = { get: () => enabled };
  const f = await fixture(t, undefined, undefined, { native: true, config: { globalEnabled: setting } });
  f.owner.session = { header: {}, requestHeader: () => ({ config: { provider: 'test', model: 'test' } }) };
  f.services.llm = { async *stream() { calls++; yield { type: 'text-delta', text: '{"action":"create"}' }; } };
  const hook = [...f.listeners.get('agent/pre-step')][0];
  const original = { kind: 'enter', messages: [{ id: 'plan-prompt', role: 'user', source: { kind: 'user' }, content: [{ type: 'text', text: 'make a plan' }] }] };
  const payload = { agent: f.owner, messages: original.messages, signal: new AbortController().signal };
  assert.deepEqual(await hook(payload, async () => original), original);
  assert.equal(calls, 0);
  enabled = true;
  const rejected = { kind: 'reject' };
  assert.equal(await hook(payload, async () => rejected), rejected);
  assert.equal(calls, 0);
  const routed = await hook(payload, async () => ({ ...original, startsRequestSeries: true }));
  assert.equal(routed.startsRequestSeries, true);
  assert.equal(typeof routed.messages.at(-1).id, 'string');
  assert.deepEqual(routed.messages.at(-1).source, { kind: 'dynamic-workflow' });
  assert.equal(Object.isFrozen(routed.messages.at(-1)), true);
  assert.equal(calls, 1);
  await hook({ ...payload, messages: routed.messages }, async () => routed);
  assert.equal(calls, 1);
});

for (const action of ['direct', 'create', 'revise']) test(`global router classifies each submitted prompt once when routing ${action}`, async t => {
  const f = await fixture(t, undefined, undefined, { native: true, config: { globalEnabled: true } });
  f.owner.session = { header: {}, requestHeader: () => ({ config: { provider: 'test', model: 'test' } }) };
  let calls = 0;
  f.services.llm = { async *stream() { calls++; yield { type: 'text-delta', text: JSON.stringify({ action }) }; } };
  const hook = [...f.listeners.get('agent/pre-step')][0];
  const prompt = { id: 'human-1', role: 'user', source: { kind: 'user' }, content: [{ type: 'text', text: 'same prompt' }] };
  const signal = new AbortController().signal;
  const step = async (messages, turn, number) => {
    const result = { kind: 'enter', messages };
    return hook({ agent: f.owner, messages, turn, step: number, signal }, async () => result);
  };
  const first = await step([prompt], 1, 1);
  assert.equal(calls, 1);
  await step([{ ...prompt }], 1, 2);
  await step([{ ...prompt }], 2, 3);
  assert.equal(calls, 1, 'model steps and retries must not classify a submitted prompt again');
  for (const messages of [[], [{ id: 'reply', role: 'assistant', content: [{ type: 'text', text: 'model reply' }] }], [{ id: 'goal', role: 'user', source: { kind: 'goal' }, content: [{ type: 'text', text: 'continue' }] }]]) await step(messages, 2, 4);
  assert.equal(calls, 1, 'replies and automatic continuation are not user submissions');
  const routerMessages = first.messages.filter(message => message.source?.kind === 'dynamic-workflow');
  await step([...routerMessages, { ...prompt, id: 'human-2' }], 3, 5);
  assert.equal(calls, 2, 'sending the same text again is a new submission, even alongside plugin messages');
});

test('global router judges queued human prompts separately', async t => {
  const f = await fixture(t, undefined, undefined, { native: true, config: { globalEnabled: true } });
  f.owner.session = { header: {}, requestHeader: () => ({ config: { provider: 'test', model: 'test' } }) };
  const calls = [];
  f.services.llm = { async *stream(options) { calls.push(options.messages[0].content[0].text); yield { type: 'text-delta', text: '{"action":"direct"}' }; } };
  const messages = ['first prompt', 'second prompt'].map((text, index) => ({ id: `queued-${index}`, role: 'user', source: { kind: 'user' }, content: [{ type: 'text', text }] }));
  const hook = [...f.listeners.get('agent/pre-step')][0];
  await hook({ agent: f.owner, messages, signal: new AbortController().signal }, async () => ({ kind: 'enter', messages }));
  assert.equal(calls.length, 2);
  assert.equal(JSON.parse(calls[0]).message, 'first prompt');
  assert.equal(JSON.parse(calls[1]).message, 'second prompt');
});

test('global router uses the selected model before the first request and after a switch', async t => {
  const f = await fixture(t, undefined, undefined, { native: true, config: { globalEnabled: true } });
  const calls = [];
  f.owner.session = { header: {}, requestHeader: () => undefined };
  f.services.llm = { async *stream(options) { calls.push(options); yield { type: 'text-delta', text: '{"action":"direct"}' }; } };
  const observe = [...(f.listeners.get('system-prompt/assemble') ?? [])][0];
  assert.equal(typeof observe, 'function');
  const hook = [...f.listeners.get('agent/pre-step')][0];
  const messages = [{ id: 'before-model-switch', role: 'user', source: { kind: 'user' }, content: [{ type: 'text', text: 'hello' }] }];
  const payload = { agent: f.owner, messages, signal: new AbortController().signal };
  const assembly = { sections: [], contexts: [], tools: [], variables: { provider: 'new', model: 'first' } };
  assert.equal(await observe({}, { scope: f.owner }, async () => assembly), assembly);
  await hook(payload, async () => ({ kind: 'enter', messages }));
  assert.equal(calls[0]?.model, 'first');
  f.owner.session.requestHeader = () => ({ config: { provider: 'old', model: 'stale' } });
  await observe({}, { scope: f.owner }, async () => ({ ...assembly, variables: { provider: 'new', model: 'switched' } }));
  const nextMessages = [{ ...messages[0], id: 'after-model-switch' }];
  await hook({ ...payload, messages: nextMessages }, async () => ({ kind: 'enter', messages: nextMessages }));
  assert.equal(calls[1]?.model, 'switched');
  const injected = [{ role: 'user', source: { kind: 'goal' }, content: [{ type: 'text', text: 'continue the task' }] }];
  await hook({ ...payload, messages: injected }, async () => ({ kind: 'enter', messages: injected }));
  assert.equal(calls.length, 2, 'automatic plugin messages are not new human requests');
});

test('settings reads the dynamic workflow value and writes with its described revision', async t => {
  const calls = [];
  let value = false, revision = 7;
  const settings = {
    describe() { return [{ ns: 'dynamic-workflow', value: { globalEnabled: value }, revision }]; },
    async mutate(...args) { calls.push(args); value = args[1][0].value; revision++; },
  };
  const f = await fixture(t, undefined, undefined, { settings });
  assert.deepEqual(await f.call({ action: 'settings' }), { globalEnabled: false, revision: 7, ns: 'dynamic-workflow' });
  assert.deepEqual(await f.call({ action: 'settings', globalEnabled: true }), { globalEnabled: true, revision: 8, ns: 'dynamic-workflow' });
  assert.deepEqual(calls, [['dynamic-workflow', [{ op: 'set', path: ['globalEnabled'], value: true }], 7]]);
});

test('settings propagates a rejected persistence write', async t => {
  const settings = {
    describe() { return [{ ns: 'dynamic-workflow', value: { globalEnabled: false }, revision: 3 }]; },
    async mutate() { throw new Error('settings conflict'); },
  };
  const f = await fixture(t, undefined, undefined, { settings });
  await assert.rejects(() => f.call({ action: 'settings', globalEnabled: true }), /settings conflict/);
});

test('one capsule reuses its native Agent for successive stages', async t => {
  const f = await fixture(t, async () => 'stage completed', undefined, { native: true });
  await f.write({ id: 'capsules', nodes: [
    { id: 'plan', agentId: 'writer', prompt: 'Plan the task' },
    { id: 'deliver', agentId: 'writer', prompt: 'Deliver the task', deps: ['plan'] },
  ] });
  const run = await f.call({ action: 'run', workflowPath: 'flow.json', concurrency: 2 });
  const result = await finished(f, run.runId);
  assert.equal(result.status, 'completed');
  assert.equal(f.requests.length, 1, 'a later stage must not create another Agent');
  assert.equal(f.native.continuations.length, 1);
  assert.equal(result.nodes.plan.agentSessionId, result.nodes.deliver.agentSessionId);
  assert.equal(result.nodes.deliver.agentId, 'writer');
});

function reviewFlow(maxRounds) {
  return { id: 'bounded-quality', agents: { developer: { title: 'Developer' }, reviewer: { title: 'Independent reviewer' } }, roles: {
    build: { prompt: 'Build the artifact', tools: [] }, review: { prompt: 'Check against requirements independently', tools: [] }, fix: { prompt: 'Repair the cited findings', tools: [] },
  }, nodes: [
    { id: 'draft', agentId: 'developer', role: 'build', prompt: 'INITIAL_ARTIFACT' },
    { id: 'quality', deps: ['draft'], reviewLoop: { ...(maxRounds === undefined ? {} : { maxRounds }),
      review: { agentId: 'reviewer', role: 'review', prompt: 'CHECK_ARTIFACT' }, fix: { agentId: 'developer', role: 'fix', prompt: 'REPAIR_ARTIFACT' },
    } },
    { id: 'deliver', agentId: 'developer', role: 'build', prompt: 'DELIVER_ARTIFACT', deps: ['quality'] },
  ] };
}

for (const approvalRound of [1, 2]) test(`review loop persists skipped rounds and capsule identities after approval in round ${approvalRound}`, async t => {
  let reviews = 0, fixes = 0;
  const f = await fixture(t, async prompt => {
    if (prompt.includes('CHECK_ARTIFACT')) return ++reviews >= approvalRound
      ? { verdict: 'approved', findings: [] }
      : { verdict: 'changes-required', findings: [{ message: 'Missing verification', evidence: 'The draft omits the verification step' }] };
    if (prompt.includes('REPAIR_ARTIFACT')) { fixes++; assert.match(prompt, /Missing verification/); return 'artifact repaired with verification'; }
    return 'artifact';
  }, undefined, { native: true, executeContinuations: true });
  await f.write(reviewFlow());
  const run = await f.call({ action: 'run', workflowPath: 'flow.json' });
  const result = await finished(f, run.runId);
  assert.equal(result.status, 'completed', result.error);
  assert.equal(reviews, approvalRound);
  assert.equal(fixes, approvalRound - 1);
  assert.equal(result.nodes['quality/fix/2'].skipped, true);
  assert.equal(result.nodes['quality/review/3'].skipped, true);
  assert.equal(result.nodes['quality/review/1'].reviewStep.maxRounds, 3);
  assert.equal(result.nodes.quality.reviewStep.kind, 'gate');
  assert.equal(result.nodes.quality.agentSessionId, undefined);
  assert.notEqual(result.nodes.draft.agentSessionId, result.nodes['quality/review/1'].agentSessionId);
  assert.equal(result.nodes.draft.agentSessionId, result.nodes.deliver.agentSessionId);
  if (approvalRound > 1) {
    assert.equal(result.nodes.draft.agentSessionId, result.nodes['quality/fix/1'].agentSessionId);
    assert.equal(result.nodes['quality/review/1'].agentSessionId, result.nodes['quality/review/2'].agentSessionId);
    assert.match(f.native.histories.get(result.nodes['quality/review/1'].agentSessionId).at(-1), /artifact repaired with verification/);
  }
  assert.equal(f.requests.length, 2, 'only the developer and reviewer start children');
  await f.unload(); await f.restart();
  const saved = await f.call({ action: 'status', runId: run.runId, nodeId: 'quality' });
  assert.equal(saved.node.output.verdict, 'approved');
  assert.equal(saved.nodes['quality/fix/2'].skipped, true);
  const resumed = await f.call({ action: 'resume', runId: run.runId });
  const reused = await finished(f, resumed.runId);
  assert.equal(reused.status, 'completed', reused.error);
  assert.equal(reused.contextWarning, undefined, 'deterministic and skipped nodes require no Agent identity');
  assert.ok(Object.values(reused.nodes).every(node => node.reused));
  assert.equal(reviews, approvalRound, 'a completed review must not repeat after restart');
  assert.equal(fixes, approvalRound - 1);
});

test('review loop stops at its configured limit and blocks delivery', async t => {
  let reviews = 0, fixes = 0, deliveries = 0;
  const f = await fixture(t, async prompt => {
    if (prompt.includes('CHECK_ARTIFACT')) { reviews++; return { verdict: 'changes-required', findings: [{ message: 'Still missing verification', evidence: 'No verification step in this version' }] }; }
    if (prompt.includes('REPAIR_ARTIFACT')) fixes++;
    if (prompt.includes('DELIVER_ARTIFACT')) deliveries++;
    return 'artifact';
  }, undefined, { native: true, executeContinuations: true });
  await f.write(reviewFlow(2));
  const run = await f.call({ action: 'run', workflowPath: 'flow.json' });
  const result = await finished(f, run.runId);
  assert.equal(result.status, 'failed');
  assert.match(result.error ?? '', /review.*limit|limit.*review/i);
  assert.equal(reviews, 2);
  assert.equal(fixes, 1);
  assert.equal(deliveries, 0);
  assert.equal(result.nodes.deliver.status, 'blocked');
  const gate = await f.call({ action: 'status', runId: run.runId, nodeId: 'quality' });
  assert.match(gate.node.error, /review.*limit|limit.*review/i);
  const last = await f.call({ action: 'status', runId: run.runId, nodeId: 'quality/review/2' });
  assert.equal(last.node.output.findings[0].message, 'Still missing verification');
  await f.unload(); await f.restart();
  const resumed = await f.call({ action: 'resume', runId: run.runId });
  const exhausted = await finished(f, resumed.runId);
  assert.equal(exhausted.status, 'failed');
  assert.equal(exhausted.contextWarning, undefined, 'a failed deterministic gate has no missing Agent');
  assert.equal(exhausted.nodes.deliver.status, 'blocked');
  assert.equal(reviews, 2, 'resuming an exhausted loop does not reset its review budget');
  assert.equal(fixes, 1);
  assert.equal(deliveries, 0);
});

test('missing historical Agent warnings persist across repeated needs-review resumes without a fingerprint', async t => {
  const f = await fixture(t, async () => 'original result');
  await f.write({ id: 'legacy-history', nodes: [{ id: 'work', prompt: 'Potentially effectful task' }] });
  const initial = await f.call({ action: 'run', workflowPath: 'flow.json' });
  assert.equal((await finished(f, initial.runId)).status, 'completed');
  await f.unload();
  const saved = f.storageDomain.tables.get('runs').get(initial.runId);
  saved.status = 'interrupted'; saved.snapshot.status = 'interrupted';
  saved.snapshot.nodes.work = { status: 'interrupted' }; saved.nodeSessions = {};
  await f.restart();
  let previous = initial;
  for (let attempt = 0; attempt < 2; attempt++) {
    const resumed = await f.call({ action: 'resume', runId: previous.runId });
    previous = await finished(f, resumed.runId);
    assert.equal(previous.status, 'needs_review');
    assert.match(previous.contextWarning ?? '', /Historical Agent identity unavailable.*work/);
  }
  assert.equal(f.requests.length, 1, 'diagnostic recovery must not replay the historical task');
});

test('message steers the running workflow node without restarting or stopping its Agent', async t => {
  let release, entered; const work = new Promise(resolve => { release = resolve; });
  const started = new Promise(resolve => { entered = resolve; }); const messages = [];
  const f = await fixture(t, async () => { entered(); await work; return 'shipped'; }, undefined, {
    native: true, onMessage: async delivery => { messages.push(delivery); return 'steering-message'; },
  });
  await f.write({ id: 'steer', nodes: [{ id: 'commit_merge', agentId: 'ship', prompt: 'Ship' }] });
  const run = await f.call({ action: 'run', workflowPath: 'flow.json' });
  try {
    await started;
    const before = await f.call({ action: 'status', runId: run.runId });
    const controller = new AbortController();
    const receipt = await f.call({ action: 'message', runId: run.runId, nodeId: 'commit_merge', message: 'Please report the current blocker.' }, f.owner, controller.signal);
    assert.deepEqual(receipt, { runId: run.runId, nodeId: 'commit_merge', agentSessionId: before.nodes.commit_merge.agentSessionId, messageId: 'steering-message', accepted: true });
    assert.equal(messages[0].parent, f.owner);
    assert.equal(messages[0].childId, receipt.agentSessionId);
    assert.deepEqual(messages[0].content, [{ type: 'text', text: 'Please report the current blocker.' }]);
    controller.abort();
    assert.equal((await f.call({ action: 'status', runId: run.runId })).status, 'running');
    assert.equal(f.requests.length, 1);
    assert.equal(f.native.continuations.length, 0);
  } finally { release(); await finished(f, run.runId); }
  const result = await f.call({ action: 'status', runId: run.runId, nodeId: 'commit_merge' });
  assert.equal(result.status, 'completed');
  assert.equal(result.node.output, 'shipped');
});

test('message rejects non-running nodes, invalid content, and a different owner without waking children', async t => {
  let release, entered; const work = new Promise(resolve => { release = resolve; });
  const started = new Promise(resolve => { entered = resolve; }); let delivered = 0;
  const f = await fixture(t, async () => { entered(); await work; return 'done'; }, undefined, {
    native: true, onMessage: async () => { delivered++; return 'unexpected'; },
  });
  await f.write({ id: 'message-boundaries', nodes: [
    { id: 'a', agentId: 'worker', prompt: 'First' }, { id: 'b', prompt: 'Later', deps: ['a'] },
  ] });
  const run = await f.call({ action: 'run', workflowPath: 'flow.json' });
  const args = { action: 'message', runId: run.runId, nodeId: 'a', message: 'Progress?' };
  try {
    await started;
    await assert.rejects(f.call(args, { ...f.owner, id: 'other-owner' }), /Run not found/);
    await assert.rejects(f.call({ ...args, nodeId: 'b' }), /not running/);
    await assert.rejects(f.call({ ...args, nodeId: 'unknown' }), /Node not found/);
    await assert.rejects(f.call({ ...args, nodeId: undefined }), /nodeId is required/);
    for (const message of ['', '   ', 12, 'x'.repeat(12001)]) await assert.rejects(f.call({ ...args, message }), /message must/);
    const childId = (await f.call({ action: 'status', runId: run.runId })).nodes.a.agentSessionId;
    const child = f.native.live.get(childId);
    child.session.header.parentSession = 'unrelated';
    await assert.rejects(f.call(args), /live running child/);
    child.session.header.parentSession = f.owner.id;
    child.status = 'idle';
    await assert.rejects(f.call(args), /live running child/);
    child.status = 'running';
    f.native.live.delete(childId);
    await assert.rejects(f.call(args), /live running child/);
    f.native.live.set(childId, child);
  } finally { release(); await finished(f, run.runId); }
  await assert.rejects(f.call(args), /not running/);
  assert.equal(delivered, 0);
});

test('message admission is cancelled when its target stage finishes before acceptance', async t => {
  let release, entered, admitted; const work = new Promise(resolve => { release = resolve; });
  const started = new Promise(resolve => { entered = resolve; });
  const admissionStarted = new Promise(resolve => { admitted = resolve; });
  const caller = new AbortController(); let deliverySignal, rejection;
  const f = await fixture(t, async () => { entered(); await work; return 'done'; }, undefined, {
    native: true, onMessage: ({ signal }) => new Promise((resolve, reject) => {
      deliverySignal = signal;
      const abort = () => reject(signal.reason);
      if (signal.aborted) abort(); else signal.addEventListener('abort', abort, { once: true });
      admitted();
    }),
  });
  await f.write({ id: 'message-race', nodes: [{ id: 'a', agentId: 'worker', prompt: 'Work' }] });
  const run = await f.call({ action: 'run', workflowPath: 'flow.json' });
  try {
    await started;
    rejection = assert.rejects(f.call({ action: 'message', runId: run.runId, nodeId: 'a', message: 'Progress?' }, f.owner, caller.signal), /stopped|abort/i);
    await Promise.race([admissionStarted, rejection.then(() => { throw new Error('Message rejected before admission started'); })]);
    release();
    assert.equal((await finished(f, run.runId)).status, 'completed');
    assert.equal(deliverySignal.aborted, true);
    await rejection;
    assert.equal(f.listeners.get('subagent/end').size, 0);
  } finally {
    caller.abort(); release();
    await rejection?.catch(() => {});
    await finished(f, run.runId);
  }
});

test('each stage installs its role prompt and tools before activating the same capsule Agent', async t => {
  const f = await fixture(t, async () => 'done', undefined, { native: true });
  await f.write({ id: 'stage-roles', agents: { worker: { title: 'Worker' } }, roles: {
    plan: { title: 'Planner', prompt: 'Plan the work', tools: ['read'] },
    review: { title: 'Reviewer', prompt: 'Review without tools', tools: [] },
    deliver: { title: 'Writer', prompt: 'Write the result', tools: ['write'] },
  }, nodes: [
    { id: 'a', agentId: 'worker', role: 'plan', prompt: 'First task' },
    { id: 'b', agentId: 'worker', role: 'review', prompt: 'Second task' },
    { id: 'c', agentId: 'worker', role: 'deliver', prompt: 'Third task' },
  ] });
  const run = await f.call({ action: 'run', workflowPath: 'flow.json', concurrency: 3 });
  const result = await finished(f, run.runId);
  assert.equal(result.status, 'completed');
  assert.equal(f.requests.length, 1);
  assert.equal(new Set(Object.values(result.nodes).map(node => node.agentSessionId)).size, 1);
  assert.deepEqual(f.native.policyActivations.map(({ prompt, tools }) => ({ prompt, tools })), [
    { prompt: 'Plan the work', tools: ['read'] }, { prompt: 'Review without tools', tools: [] }, { prompt: 'Write the result', tools: ['write'] },
  ]);
  assert.equal(result.nodes.c.roleTitle, 'Writer');
});

test('a capsule retains its Agent after plugin reload and a newly appended stage', async t => {
  const f = await fixture(t, async () => 'stage completed', undefined, { native: true });
  const first = { id: 'capsules', nodes: [{ id: 'plan', agentId: 'writer', prompt: 'Plan' }] };
  await f.write(first);
  const run = await f.call({ action: 'run', workflowPath: 'flow.json' });
  const original = await finished(f, run.runId);
  await f.unload(); await f.restart();
  await f.write({ ...first, nodes: [...first.nodes, { id: 'deliver', agentId: 'writer', prompt: 'Deliver', deps: ['plan'] }] });
  const next = await f.call({ action: 'run', workflowPath: 'flow.json' });
  const result = await finished(f, next.runId);
  assert.equal(result.status, 'completed');
  assert.equal(f.requests.length, 1);
  assert.equal(result.nodes.plan.reused, true);
  assert.equal(result.nodes.deliver.agentSessionId, original.nodes.plan.agentSessionId);
});

test('revise stops the source run, reads the new definition, and records the trigger', async t => {
  const f = await fixture(t, async prompt => prompt);
  await f.write({ id: 'revision-flow', nodes: [{ id: 'a', prompt: 'old' }] });
  const first = await f.call({ action: 'run', workflowPath: 'flow.json' });
  await finished(f, first.runId);
  await f.write({ id: 'revision-flow', nodes: [{ id: 'a', prompt: 'new' }] });
  const revised = await f.call({ action: 'revise', runId: first.runId, workflowPath: 'flow.json', revisionReason: 'user changed acceptance criteria' });
  const result = await finished(f, revised.runId);
  assert.equal(result.status, 'completed');
  assert.equal(result.revisionReason, 'user changed acceptance criteria');
  assert.equal(result.resumedFrom, first.runId);
  assert.match(f.requests.at(-1).args.prompt, /^new\n/);
});

test('changed executed capsule history requires a fresh workflow identity', async t => {
  const f = await fixture(t, async () => 'done', undefined, { native: true });
  const original = { id: 'capsule-version-1', nodes: [{ id: 'a', agentId: 'worker', prompt: 'Original task' }] };
  await f.write(original);
  const first = await f.call({ action: 'run', workflowPath: 'flow.json' });
  const firstResult = await finished(f, first.runId);
  const changed = { ...original, nodes: [{ id: 'a', agentId: 'worker', prompt: 'Changed task' }] };
  await f.write(changed);
  const second = await f.call({ action: 'run', workflowPath: 'flow.json' });
  assert.equal((await finished(f, second.runId)).status, 'needs_review');
  const detail = await f.call({ action: 'status', runId: second.runId, nodeId: 'a' });
  assert.match(detail.node.error, /definition|fingerprint|history/i);
  assert.equal(f.requests.length, 1);
  await f.write({ ...changed, id: 'capsule-version-2' });
  const fresh = await f.call({ action: 'run', workflowPath: 'flow.json' });
  const result = await finished(f, fresh.runId);
  assert.equal(result.status, 'completed');
  assert.equal(f.requests.length, 2);
  assert.notEqual(result.nodes.a.agentSessionId, firstResult.nodes.a.agentSessionId);
});

test('a missing saved capsule Agent fails instead of replacing it for the next stage', async t => {
  const f = await fixture(t, async () => 'stage completed', undefined, { native: true });
  const first = { id: 'capsules', nodes: [{ id: 'plan', agentId: 'writer', prompt: 'Plan' }] };
  await f.write(first);
  const run = await f.call({ action: 'run', workflowPath: 'flow.json' }); await finished(f, run.runId);
  f.native.catalog.clear();
  await f.write({ ...first, nodes: [...first.nodes, { id: 'deliver', agentId: 'writer', prompt: 'Deliver', deps: ['plan'] }] });
  const next = await f.call({ action: 'run', workflowPath: 'flow.json' });
  const result = await finished(f, next.runId);
  assert.equal(result.status, 'failed');
  const detail = await f.call({ action: 'status', runId: next.runId, nodeId: 'deliver' });
  assert.match(detail.node.error, /unavailable|missing|continuable/i);
  assert.equal(f.requests.length, 1);
});

async function finished(f, id) {
  for (let i = 0; i < 100; i++) {
    const value = await f.call({ action: 'status', runId: id });
    if (!['running', 'stopping'].includes(value.status)) return value;
    await new Promise(resolve => setTimeout(resolve, 5));
  }
  assert.fail('run did not settle');
}

test('persists history across plugin restarts and scopes access to stable session ids', async t => {
  const f = await fixture(t);
  await f.write({ id: 'flow', nodes: [{ id: 'a', prompt: 'hello' }] });
  const first = await f.call({ action: 'run', workflowPath: 'flow.json' });
  assert.equal((await finished(f, first.runId)).status, 'completed');
  await f.unload();
  await f.restart();
  const resumedOwner = { ...f.owner };
  assert.match((await f.call({ action: 'status', runId: first.runId, nodeId: 'a' }, resumedOwner)).node.output.prompt, /^hello\n/);
  const next = await f.call({ action: 'run', workflowPath: 'flow.json' }, resumedOwner);
  assert.equal((await finished(f, next.runId)).status, 'completed');
  assert.equal(f.requests.length, 1);
  assert.equal((await f.call({ action: 'list' })).runs.length, 2);
  assert.equal((await f.call({ action: 'status', runId: first.runId })).status, 'completed');
});

test('rejects malformed persisted snapshots without replacing saved records', async t => {
  const f = await fixture(t);
  await f.write({ id: 'flow', nodes: [{ id: 'a', prompt: 'hello' }] });
  const run = await f.call({ action: 'run', workflowPath: 'flow.json' });
  await finished(f, run.runId);
  await f.unload();
  const table = f.storageDomain.tables.get('runs');
  table.get(run.runId).snapshot = { version: 99 };
  await assert.rejects(f.restart(), /version|invalid|workflowId/i);
  assert.deepEqual(table.get(run.runId).snapshot, { version: 99 });
});

test('crash-left running metadata is discoverable but never restarts execution on inspection', async t => {
  const f = await fixture(t);
  await f.write({ id: 'flow', nodes: [{ id: 'a', prompt: 'hello' }] });
  const run = await f.call({ action: 'run', workflowPath: 'flow.json' });
  await finished(f, run.runId);
  await f.unload();
  const saved = f.storageDomain.tables.get('runs').get(run.runId);
  saved.status = 'running'; saved.snapshot.nodes.a.status = 'running';
  await f.restart();
  assert.equal((await f.call({ action: 'list' })).runs[0].status, 'interrupted');
  assert.equal((await f.call({ action: 'status', runId: run.runId })).status, 'interrupted');
  assert.equal(f.requests.length, 1);
  const next = await f.call({ action: 'run', workflowPath: 'flow.json' });
  assert.equal((await finished(f, next.runId)).status, 'needs_review');
  assert.equal(f.requests.length, 1);
});

test('different sessions executing the same target cannot reuse or inspect each other outputs', async t => {
  const f = await fixture(t);
  await f.write({ id: 'flow', nodes: [{ id: 'a', prompt: 'hello' }] });
  const first = await f.call({ action: 'run', workflowPath: 'flow.json' });
  await finished(f, first.runId);
  const other = { ...f.owner, id: 'other-session' };
  const second = await f.call({ action: 'run', workflowPath: 'flow.json' }, other);
  for (let i = 0; i < 100; i++) {
    if ((await f.call({ action: 'status', runId: second.runId }, other)).status !== 'running') break;
    await new Promise(resolve => setTimeout(resolve, 5));
  }
  assert.equal(f.requests.length, 2);
  await assert.rejects(f.call({ action: 'status', runId: first.runId }, other), /not found/);
  assert.equal((await f.call({ action: 'list' }, other)).runs.length, 1);
});

test('storage failure prevents agent side effects and remains visible through status', async t => {
  const f = await fixture(t);
  await f.write({ id: 'flow', nodes: [{ id: 'a', prompt: 'hello' }] });
  f.storageDomain.failWrites = true;
  const run = await f.call({ action: 'run', workflowPath: 'flow.json' });
  const result = await finished(f, run.runId);
  assert.equal(result.status, 'failed');
  assert.match(result.error, /storage offline/);
  assert.equal(f.requests.length, 0);
});

test('simultaneous run calls for the same target admit exactly one execution', async t => {
  const f = await fixture(t, () => new Promise(() => {}));
  await f.write({ id: 'flow', nodes: [{ id: 'a', prompt: 'hello' }] });
  const results = await Promise.allSettled([f.call({ action: 'run', workflowPath: 'flow.json' }), f.call({ action: 'run', workflowPath: './flow.json' })]);
  assert.equal(results.filter(r => r.status === 'fulfilled').length, 1);
  assert.match(results.find(r => r.status === 'rejected').reason.message, /already running/);
});

test('executes dependency outputs as data using the parent engine and reuses unchanged nodes', async t => {
  const f = await fixture(t, async prompt => prompt.includes('Dependencies:') ? { consumed: prompt } : { answer: 7 });
  await f.write({ id: 'flow', nodes: [{ id: 'a', prompt: 'first' }, { id: 'b', deps: ['a'], prompt: 'second' }] });
  const start = await f.call({ action: 'run', workflowPath: 'flow.json' });
  assert.equal((await finished(f, start.runId)).status, 'completed');
  assert.equal(f.requests.length, 2);
  assert.equal(f.requests[0].parent, f.owner);
  const output = await f.call({ action: 'status', runId: start.runId, nodeId: 'b' });
  assert.match(JSON.stringify(output), /answer/);
  assert.equal(f.disposed, 2);
  const repeat = await f.call({ action: 'run', workflowPath: 'flow.json' });
  assert.equal((await finished(f, repeat.runId)).status, 'completed');
  assert.equal(f.requests.length, 2);
});

test('rejects cross-session access, denied fs reads, arbitrary state paths and missing scoped engine', async t => {
  const f = await fixture(t);
  await f.write({ id: 'flow', nodes: [{ id: 'a', prompt: 'hello' }] });
  const run = await f.call({ action: 'run', workflowPath: 'flow.json' });
  const other = { ...f.owner, id: 'other-session' };
  await assert.rejects(f.call({ action: 'status', runId: run.runId }, other), /not found|owner/i);
  assert.deepEqual((await f.call({ action: 'list' }, other)).runs, []);
  const denied = { id: 'denied', ctx: { get: key => key === 'fs' ? { ...f.owner.ctx.get(key), readBytes: async () => { throw new Error('FS policy denied'); }, readText: async () => { throw new Error('FS policy denied'); } } : f.owner.ctx.get(key) } };
  await assert.rejects(f.call({ action: 'run', workflowPath: 'flow.json' }, denied), /FS policy denied/);
  await assert.rejects(f.call({ action: 'run', workflowPath: 'flow.json', statePath: '/tmp/owned' }), /statePath|unknown/i);
  await assert.rejects(f.call({ action: 'run', workflowPath: 'flow.json' }, { id: 'no-engine', ctx: { get: key => key === 'workflowEngine' ? undefined : f.owner.ctx.get(key) } }), /workflowEngine/i);
  await assert.rejects(f.call({ action: 'restart', runId: run.runId }), /restart|recover/i);
});

test('stop and unload cancel and drain active workflow handles', async t => {
  const f = await fixture(t, () => new Promise(() => {}));
  await f.write({ id: 'flow', nodes: [{ id: 'a', prompt: 'wait', retrySafe: true }] });
  const run = await f.call({ action: 'run', workflowPath: 'flow.json' });
  while (!f.requests.length) await new Promise(resolve => setTimeout(resolve, 5));
  await assert.rejects(f.call({ action: 'run', workflowPath: 'flow.json' }), /already running/i);
  const stopped = await f.call({ action: 'stop', runId: run.runId });
  assert.equal(stopped.status, 'cancelled');
  assert.equal(f.disposed, 1);
  await f.call({ action: 'run', workflowPath: 'flow.json' });
  while (f.requests.length < 2) await new Promise(resolve => setTimeout(resolve, 5));
  await f.unload();
  assert.equal(f.disposed, 2);
});

test('stop waits for asynchronous child disposal after core abort settles', async t => {
  let release; const gate = new Promise(resolve => { release = resolve; });
  const f = await fixture(t, () => new Promise(() => {}), () => gate);
  await f.write({ id: 'flow', nodes: [{ id: 'a', prompt: 'wait', retrySafe: true }] });
  const run = await f.call({ action: 'run', workflowPath: 'flow.json' });
  while (!f.requests.length) await new Promise(resolve => setTimeout(resolve, 5));
  let settled = false;
  const stopped = f.call({ action: 'stop', runId: run.runId }).then(value => { settled = true; return value; });
  await new Promise(resolve => setTimeout(resolve, 30));
  try { assert.equal(settled, false, 'stop must await child cleanup'); }
  finally { release(); await stopped; }
  assert.equal(f.disposed, 1);
});

test('resume keeps saved definition and completed fingerprints while applying executor overrides', async t => {
  const f = await fixture(t, async (prompt, options) => {
    if (prompt.startsWith('second') && options.model !== 'new-model') throw new Error('switch model');
    return { prompt };
  });
  const definition = { id: 'flow', title: 'Saved title', nodes: [{ id: 'a', prompt: 'first', model: 'node-model' }, { id: 'b', prompt: 'second', deps: ['a'], retrySafe: true }] };
  await f.write(definition);
  const first = await f.call({ action: 'run', workflowPath: 'flow.json', provider: 'old-provider', model: 'old-model' });
  assert.equal((await finished(f, first.runId)).status, 'failed');
  assert.equal(f.requests[0].args.options.model, 'old-model');
  await f.write({ id: 'changed', nodes: [] });
  await f.unload(); await f.restart();
  const resumed = await f.call({ action: 'resume', runId: first.runId, model: 'new-model', concurrency: 2 });
  const status = await finished(f, resumed.runId);
  assert.equal(status.status, 'completed');
  assert.equal(status.nodes.a.reused, true);
  assert.equal(status.resumedFrom, first.runId);
  assert.equal(status.title, 'Saved title');
  assert.equal(status.model, 'new-model');
  assert.equal(status.provider, 'old-provider');
  assert.equal(status.concurrency, 2);
  assert.equal(status.workflow.nodes[0].model, 'node-model');
  assert.equal(f.requests.length, 3);
  assert.equal(f.requests[2].args.options.model, 'new-model');
  const listed = (await f.call({ action: 'list' })).runs.find(run => run.runId === resumed.runId);
  assert.equal(listed.nodes.a.status, 'completed');
  assert.equal(listed.title, 'Saved title');
});

test('human command shares operations and reports JSON success or errors', async t => {
  const f = await fixture(t);
  assert.equal(f.command.name, 'workflow');
  const result = await f.command.handler({ agent: f.owner, rawInput: '{"action":"list"}', signal: new AbortController().signal });
  assert.equal(result.kind, 'success');
  assert.deepEqual(JSON.parse(result.text), { runs: [] });
  const bad = await f.command.handler({ agent: f.owner, rawInput: '{bad', signal: new AbortController().signal });
  assert.equal(bad.kind, 'error');
  assert.equal(typeof bad.text, 'string');
});

test('/workflow without arguments explains the human command syntax', async t => {
  const f = await fixture(t);
  const result = await f.command.handler({ agent: f.owner, rawInput: '', signal: new AbortController().signal });
  assert.equal(result.kind, 'success');
  assert.match(result.text, /\/workflow run/);
  assert.match(result.text, /\/workflow resume/);
  assert.equal(f.requests.length, 0);
});

test('/workflow shorthand runs a file and queries its saved result', async t => {
  const f = await fixture(t, async () => 'done');
  await f.write({ id: 'short-command', nodes: [{ id: 'a', prompt: 'hello' }] });
  const invoke = rawInput => f.command.handler({ agent: f.owner, rawInput, signal: new AbortController().signal });
  const started = await invoke('run "flow.json"');
  assert.equal(started.kind, 'success');
  const run = JSON.parse(started.text);
  assert.equal((await finished(f, run.runId)).status, 'completed');
  const result = await invoke(`status ${run.runId}`);
  assert.equal(JSON.parse(result.text).status, 'completed');
  const listed = await invoke('list');
  assert.equal(JSON.parse(listed.text).runs[0].runId, run.runId);
  assert.equal((await invoke('run')).kind, 'error');
  assert.equal((await invoke('list unexpected')).kind, 'error');
});

test('resume drains running work and serializes simultaneous resume requests', async t => {
  let release; const gate = new Promise(resolve => { release = resolve; });
  const f = await fixture(t, () => new Promise(() => {}), () => gate);
  await f.write({ id: 'flow', nodes: [{ id: 'a', prompt: 'wait' }] });
  const first = await f.call({ action: 'run', workflowPath: 'flow.json' });
  while (!f.requests.length) await new Promise(resolve => setTimeout(resolve, 5));
  let settled = false;
  const attempts = Promise.allSettled([f.call({ action: 'resume', runId: first.runId }), f.call({ action: 'resume', runId: first.runId })]).then(value => { settled = true; return value; });
  await new Promise(resolve => setTimeout(resolve, 20));
  try { assert.equal(settled, false); } finally { release(); }
  const results = await attempts;
  assert.equal(results.filter(r => r.status === 'fulfilled').length, 1);
  assert.match(results.find(r => r.status === 'rejected').reason.message, /already|progress/i);
  const resumed = results.find(r => r.status === 'fulfilled').value;
  assert.equal((await finished(f, resumed.runId)).status, 'needs_review');
  assert.equal(f.requests.length, 1);
});

test('models returns advertised provider choices and contains individual catalog failures', async t => {
  const f = await fixture(t);
  const owner = { id: f.owner.id, ctx: { get: key => key === 'llm' ? {
    listProviders: () => [{ id: 'one', name: 'One' }, { id: 'offline', name: 'Offline' }],
    listModels: async provider => { if (provider === 'offline') throw new Error('catalog offline'); return [{ provider: 'one', id: 'model-a', name: 'Model A' }]; },
  } : f.owner.ctx.get(key) } };
  assert.deepEqual(await f.call({ action: 'models' }, owner), { providers: [
    { id: 'one', name: 'One', models: [{ provider: 'one', id: 'model-a', name: 'Model A' }] },
    { id: 'offline', name: 'Offline', models: [], error: 'catalog offline' },
  ] });
});

test('legacy records remain inspectable and cannot resume without saved definitions', async t => {
  const f = await fixture(t);
  await f.write({ id: 'flow', nodes: [{ id: 'a', prompt: 'hello' }] });
  const run = await f.call({ action: 'run', workflowPath: 'flow.json' });
  await finished(f, run.runId); await f.unload();
  const saved = f.storageDomain.tables.get('runs').get(run.runId);
  for (const key of ['workflow', 'title', 'resumedFrom', 'model', 'provider', 'concurrency']) delete saved[key];
  await f.restart();
  assert.equal((await f.call({ action: 'status', runId: run.runId })).resumeSupported, false);
  await assert.rejects(f.call({ action: 'resume', runId: run.runId }), /definition.*unavailable/);
  assert.equal((await f.call({ action: 'list' })).runs[0].nodes.a.status, 'completed');
});

test('resume retries interrupted nodes only when retrySafe was saved in the workflow', async t => {
  let attempts = 0;
  const f = await fixture(t, async () => ++attempts === 1 ? new Promise(() => {}) : { safe: true });
  await f.write({ id: 'flow', nodes: [{ id: 'a', prompt: 'wait', retrySafe: true }] });
  const first = await f.call({ action: 'run', workflowPath: 'flow.json' });
  while (!f.requests.length) await new Promise(resolve => setTimeout(resolve, 5));
  const resumed = await f.call({ action: 'resume', runId: first.runId, model: 'replacement' });
  assert.equal((await finished(f, resumed.runId)).status, 'completed');
  assert.equal(f.requests.length, 2);
  assert.equal(f.requests[1].args.options.model, 'replacement');
});

for (const omitChildEvent of [false, true]) test(`model resume continues the exact persistent Agent after restart (missing progress event: ${omitChildEvent})`, async t => {
  const f = await fixture(t, () => new Promise(() => {}), async () => {}, { native: true, omitChildEvent });
  await f.write({ id: 'flow', nodes: [{ id: 'a', title: 'Implementation', agentTitle: '方案设计师', prompt: 'Complete the original task' }] });
  const first = await f.call({ action: 'run', workflowPath: 'flow.json' });
  while (!f.requests.length) await new Promise(resolve => setTimeout(resolve, 5));
  await f.call({ action: 'stop', runId: first.runId });
  await f.unload(); await f.restart();
  const resumed = await f.call({ action: 'resume', runId: first.runId, provider: 'new-provider', model: 'new-model' });
  const status = await finished(f, resumed.runId);
  assert.equal(status.status, 'completed');
  assert.equal(status.nodes.a.agentSessionId, 'child-1');
  assert.equal(status.nodes.a.continuations, 1);
  assert.equal(status.nodes.a.title, 'Implementation');
  assert.equal(status.nodes.a.agentTitle, '方案设计师');
  assert.equal(f.requests.length, 1, 'the original task must not be replayed in a new Agent');
  assert.equal(f.native.continuations[0].childId, 'child-1');
  assert.deepEqual(f.native.continuations[0].config, { provider: 'new-provider', model: 'new-model' });
  const detail = await f.call({ action: 'status', runId: resumed.runId, nodeId: 'a' });
  assert.deepEqual(JSON.parse(detail.node.output), { model: 'new-model', seed: 'original history for child-1' });
});

test('node details include bounded live context only for the exact parent-owned Agent', async t => {
  const f = await fixture(t, () => new Promise(() => {}), async () => {}, { native: true });
  await f.write({ id: 'flow', nodes: [{ id: 'a', prompt: 'Task' }] });
  const run = await f.call({ action: 'run', workflowPath: 'flow.json' });
  while (!f.requests.length) await new Promise(resolve => setTimeout(resolve, 5));
  const session = { header: { parentSession: 'owner' }, requestHeader: () => ({ config: { provider: 'actual-provider', model: 'actual-model' } }), deriveMessages: () => [
    { role: 'assistant', content: [{ type: 'text', text: 'old message' }] },
    { role: 'assistant', content: [{ type: 'text', text: 'x'.repeat(13000) }] },
  ] };
  f.native.live.set('child-1', { id: 'child-1', status: 'running', session });
  const detail = await f.call({ action: 'status', runId: run.runId, nodeId: 'a' });
  assert.deepEqual(detail.agent, { sessionId: 'child-1', status: 'running', lastAssistantText: 'x'.repeat(12000), provider: 'actual-provider', model: 'actual-model' });
  session.header.parentSession = 'someone-else';
  assert.equal(Object.hasOwn(await f.call({ action: 'status', runId: run.runId, nodeId: 'a' }), 'agent'), false);
  assert.equal(Object.hasOwn(await f.call({ action: 'status', runId: run.runId }), 'agent'), false);
});

test('completed node diagnostics read the persisted actual model without activating its Agent', async t => {
  const f = await fixture(t, undefined, undefined, { native: true });
  await f.write({ id: 'flow', nodes: [{ id: 'a', prompt: 'Task' }] });
  const run = await f.call({ action: 'run', workflowPath: 'flow.json', model: 'requested-model' });
  await finished(f, run.runId);
  let parentSession = 'owner', inspected = 0;
  f.services.sessionController = { async inspect(id) {
    assert.equal(id, 'child-1'); inspected++;
    return { meta: { parentSession }, events: [
      { type: 'request/header', data: { header: { config: { provider: 'old', model: 'old' } } } },
      { type: 'request/header', data: { header: { config: { provider: 'actual-provider', model: 'actual-model' } } } },
    ] };
  } };
  const detail = await f.call({ action: 'status', runId: run.runId, nodeId: 'a' });
  assert.deepEqual(detail.agent, { sessionId: 'child-1', status: 'inactive', provider: 'actual-provider', model: 'actual-model' });
  assert.equal(inspected, 1);
  assert.equal(f.requests.length, 1);
  parentSession = 'another-parent';
  const denied = await f.call({ action: 'status', runId: run.runId, nodeId: 'a' });
  assert.equal(denied.status, 'completed');
  assert.equal(Object.hasOwn(denied, 'agent'), false);
  assert.match(denied.agentInspectionError, /parent/i);
});

test('an unavailable saved Agent never silently replays a retryable task in a fresh Agent', async t => {
  const f = await fixture(t, () => new Promise(() => {}), async () => {}, { native: true });
  await f.write({ id: 'flow', nodes: [{ id: 'a', prompt: 'Task', retrySafe: true }] });
  const first = await f.call({ action: 'run', workflowPath: 'flow.json' });
  while (!f.requests.length) await new Promise(resolve => setTimeout(resolve, 5));
  await f.call({ action: 'stop', runId: first.runId });
  f.native.catalog.get('child-1').mode = 'external';
  const resumed = await f.call({ action: 'resume', runId: first.runId });
  const status = await finished(f, resumed.runId);
  assert.equal(status.status, 'failed');
  assert.match(status.error, /continuable|unavailable/i);
  assert.equal(f.requests.length, 1);
  assert.equal(f.native.continuations.length, 0);
});

test('an interrupted Agent checkpoint with a changed fingerprint still requires review', async t => {
  const f = await fixture(t, () => new Promise(() => {}), async () => {}, { native: true });
  await f.write({ id: 'flow', nodes: [{ id: 'a', prompt: 'Task' }] });
  const first = await f.call({ action: 'run', workflowPath: 'flow.json' });
  while (!f.requests.length) await new Promise(resolve => setTimeout(resolve, 5));
  await f.call({ action: 'stop', runId: first.runId });
  await f.unload();
  f.storageDomain.tables.get('runs').get(first.runId).nodeSessions.a.fingerprint = 'changed';
  await f.restart();
  const resumed = await f.call({ action: 'resume', runId: first.runId });
  assert.equal((await finished(f, resumed.runId)).status, 'needs_review');
  assert.equal(f.requests.length, 1);
  assert.equal(f.native.continuations.length, 0);
});

test('grouped agents preserve individual capsule identities and expose a collection without an Agent', async t => {
  const f = await fixture(t, async prompt => ({ task: prompt.split('\n')[0] }), undefined, { native: true });
  await f.write({ id: 'grouped-host', agents: { reader: { title: 'Reader' }, checker: { title: 'Checker' } }, roles: { read: { prompt: 'Read carefully', tools: [] } }, nodes: [
    { id: 'prepare', prompt: 'Prepare' },
    { id: 'checks', deps: ['prepare'], agentConcurrency: 2, agents: [
      { id: 'read', agentId: 'reader', role: 'read', prompt: 'Read' },
      { id: 'check', agentId: 'checker', prompt: 'Check' },
    ] },
    { id: 'finish', deps: ['checks'], agentId: 'reader', prompt: 'Finish' },
  ] });
  const run = await f.call({ action: 'run', workflowPath: 'flow.json', concurrency: 2 });
  const result = await finished(f, run.runId);
  assert.equal(result.status, 'completed', result.error);
  const reader = result.nodes['checks/agent/read'], checker = result.nodes['checks/agent/check'];
  assert.ok(reader.agentSessionId);
  assert.notEqual(reader.agentSessionId, checker.agentSessionId);
  assert.equal(result.nodes.finish.agentSessionId, reader.agentSessionId);
  assert.equal(result.nodes.checks.agentSessionId, undefined);
  assert.equal(result.nodes.checks.agentStep.kind, 'collect');
  assert.equal(reader.agentStep.groupId, 'checks');
  const detail = await f.call({ action: 'status', runId: run.runId, nodeId: 'checks' });
  assert.deepEqual(Object.keys(detail.node.output), ['read', 'check']);
  assert.ok(f.native.policyActivations.some(policy => policy.prompt === 'Read carefully' && policy.tools.length === 0));
  await f.unload(); await f.restart();
  const resumed = await f.call({ action: 'resume', runId: run.runId });
  const restored = await finished(f, resumed.runId);
  assert.equal(restored.nodes['checks/agent/read'].agentSessionId, reader.agentSessionId);
  assert.equal(restored.nodes.checks.reused, true);
});

test('expanded member nodes count toward the Host workflow limit', async t => {
  const f = await fixture(t);
  await f.write({ id: 'too-many-members', nodes: [{ id: 'check', agents: Array.from({ length: 100 }, (_, i) => ({ id: `m${i}`, agentId: `a${i}`, prompt: 'Check' })) }] });
  await assert.rejects(f.call({ action: 'run', workflowPath: 'flow.json' }), /exceeds 100 nodes/);
  assert.equal(f.requests.length, 0);
});

test('messages reach the selected running member of a multi-Agent node', async t => {
  let release;
  const held = new Promise(resolve => { release = resolve; });
  const messages = [];
  const f = await fixture(t, async () => { await held; return 'done'; }, undefined, { native: true,
    onMessage: request => { messages.push(request); return 'member-message'; } });
  await f.write({ id: 'member-messages', nodes: [{ id: 'check', agents: [
    { id: 'read', agentId: 'reader', prompt: 'Read', writeResources: [] },
    { id: 'audit', agentId: 'auditor', prompt: 'Audit', writeResources: [] },
  ] }] });
  const run = await f.call({ action: 'run', workflowPath: 'flow.json', concurrency: 2 });
  try {
    while (f.requests.length < 2) await new Promise(resolve => setTimeout(resolve, 1));
    const state = await f.call({ action: 'status', runId: run.runId });
    const sent = await f.call({ action: 'message', runId: run.runId, nodeId: 'check/agent/audit', message: 'Check the new evidence' });
    assert.equal(sent.accepted, true);
    assert.equal(messages[0].childId, state.nodes['check/agent/audit'].agentSessionId);
    assert.notEqual(messages[0].childId, state.nodes['check/agent/read'].agentSessionId);
  } finally { release(); }
  assert.equal((await finished(f, run.runId)).status, 'completed');
});

test('treats null agent results as failures and never executes input as JavaScript', async t => {
  const f = await fixture(t, async prompt => { assert.match(prompt, /globalThis/); return null; });
  await f.write({ id: 'flow', nodes: [{ id: 'a', input: 'globalThis.compromised = true; ${evil}' }] });
  const run = await f.call({ action: 'run', workflowPath: 'flow.json' });
  assert.equal((await finished(f, run.runId)).status, 'failed');
});

// Host adapter tests below use unit doubles, not live DSH/model acceptance.
test('external inputs are re-read through parent policy and invalidate cache on resume', async t => {
  const f = await fixture(t); let reads = 0;
  const read = f.services.fs.readText; f.services.fs.readText = target => { if (target.targetKey.endsWith('input.txt')) reads++; return read(target); };
  await writeFile(join(f.root, 'input.txt'), 'first');
  await f.write({ id: 'external', inputFiles: ['input.txt'], nodes: [{ id: 'a', prompt: 'read input' }] });
  const run = await f.call({ action: 'run', workflowPath: 'flow.json' }); await finished(f, run.runId);
  await writeFile(join(f.root, 'input.txt'), 'changed');
  const resumed = await f.call({ action: 'resume', runId: run.runId }); await finished(f, resumed.runId);
  assert.equal(reads, 2); assert.equal(f.requests.length, 2);
  f.services.fs.readText = () => { throw Error('policy denied'); };
  await assert.rejects(f.call({ action: 'resume', runId: resumed.runId }), /policy denied/);
});

test('capsule input mismatch preserves saved child and requires review without activation', async t => {
  const f = await fixture(t, undefined, undefined, { native: true });
  await writeFile(join(f.root, 'input.txt'), 'first');
  await f.write({ id: 'capsule-input', inputFiles: ['input.txt'], nodes: [{ id: 'a', agentId: 'writer', prompt: 'write' }] });
  const run = await f.call({ action: 'run', workflowPath: 'flow.json' }); const first = await finished(f, run.runId);
  await writeFile(join(f.root, 'input.txt'), 'changed');
  const resumed = await f.call({ action: 'resume', runId: run.runId }); const last = await finished(f, resumed.runId);
  assert.equal(last.status, 'needs_review'); assert.equal(f.requests.length, 1);
  assert.equal(last.nodes.a.agentSessionId, first.nodes.a.agentSessionId);
});

test('archive is explicit reversible owner-scoped and protects resume ancestry', async t => {
  const f = await fixture(t); await f.write({ id: 'archive', nodes: [{ id: 'a', prompt: 'a' }] });
  const run = await f.call({ action: 'run', workflowPath: 'flow.json' }); await finished(f, run.runId);
  await f.call({ action: 'archive', runId: run.runId });
  assert.deepEqual((await f.call({ action: 'list' })).runs, []);
  assert.equal((await f.call({ action: 'archive-read', runId: run.runId })).runId, run.runId);
  await assert.rejects(f.call({ action: 'restore', runId: run.runId }, { ...f.owner, id: 'stranger' }), /owner/);
  await f.call({ action: 'restore', runId: run.runId }); assert.equal((await f.call({ action: 'list' })).runs.length, 1);
  const resumed = await f.call({ action: 'resume', runId: run.runId }); await finished(f, resumed.runId);
  await assert.rejects(f.call({ action: 'archive', runId: run.runId }), /ancestry/);
});

test('executed capsule agentId revision never silently swaps saved identity', async t => {
  const f = await fixture(t, undefined, undefined, { native: true });
  await f.write({ id: 'identity', nodes: [{ id: 'a', agentId: 'writer', prompt: 'a' }] });
  const run = await f.call({ action: 'run', workflowPath: 'flow.json' }); const first = await finished(f, run.runId);
  await f.write({ id: 'identity', nodes: [{ id: 'a', agentId: 'replacement', prompt: 'a' }] });
  const revised = await f.call({ action: 'revise', runId: run.runId, workflowPath: 'flow.json' }); const last = await finished(f, revised.runId);
  assert.equal(last.status, 'needs_review'); assert.equal(f.requests.length, 1);
  assert.equal(last.nodes.a.agentSessionId, first.nodes.a.agentSessionId);
});


test('bounded input files reject missing, oversized, total overflow and unsupported policy reads', async t => {
  const f = await fixture(t);
  for (const inputFiles of [Array.from({ length: 17 }, (_, i) => `${i}.txt`), ['https://example.invalid/file']]) {
    await f.write({ id: 'limits', inputFiles, nodes: [] });
    await assert.rejects(f.call({ action: 'run', workflowPath: 'flow.json' }), /inputFiles/);
  }
  await f.write({ id: 'limits', inputFiles: ['missing.txt'], nodes: [] });
  await assert.rejects(f.call({ action: 'run', workflowPath: 'flow.json' }), /inputFiles/);
  for (let i = 0; i < 5; i++) await writeFile(join(f.root, `${i}.txt`), 'a'.repeat(1024 * 1024));
  await f.write({ id: 'limits', inputFiles: ['0.txt', '1.txt', '2.txt', '3.txt', '4.txt'], nodes: [] });
  await assert.rejects(f.call({ action: 'run', workflowPath: 'flow.json' }), /4 MiB/);
  await writeFile(join(f.root, '0.txt'), 'a'.repeat(1024 * 1024 + 1));
  await f.write({ id: 'limits', inputFiles: ['0.txt'], nodes: [] });
  await assert.rejects(f.call({ action: 'run', workflowPath: 'flow.json' }), /1 MiB|large/i);
  delete f.services.fs.readBytes;
  await assert.rejects(f.call({ action: 'run', workflowPath: 'flow.json' }), /bounded.*readBytes/i);
});

test('archive read and restore survive actual adapter unload and reopen', async t => {
  const f = await fixture(t);
  await f.write({ id: 'archive-durable', nodes: [{ id: 'a', prompt: 'a' }] });
  const run = await f.call({ action: 'run', workflowPath: 'flow.json' }); await finished(f, run.runId);
  const before = await f.call({ action: 'status', runId: run.runId, nodeId: 'a' });
  await f.call({ action: 'archive', runId: run.runId }); await f.unload(); await f.restart();
  assert.equal((await f.call({ action: 'list' })).runs.length, 0);
  const archived = await f.call({ action: 'archive-read', runId: run.runId, nodeId: 'a' });
  assert.deepEqual(archived.node, before.node);
  await f.call({ action: 'restore', runId: run.runId });
  assert.equal((await f.call({ action: 'list' })).runs[0].runId, run.runId);
});

test('child disposal failure requires review and prevents automatic retry', async t => {
  const f = await fixture(t, async () => 'done', async () => { throw Error('child still owns writer'); });
  await f.write({ id: 'cleanup', nodes: [{ id: 'a', prompt: 'write', retrySafe: true, maxRetries: 1 }] });
  const run = await f.call({ action: 'run', workflowPath: 'flow.json' });
  const last = await finished(f, run.runId);
  assert.equal(last.status, 'needs_review'); assert.equal(f.requests.length, 1);
});

test('explicit archive compresses plugin snapshots and verifies readback before restore', async t => {
  const f = await fixture(t, async () => 'repetitive output '.repeat(4000));
  await f.write({ id: 'compact', nodes: [{ id: 'a', prompt: 'text' }] });
  const run = await f.call({ action: 'run', workflowPath: 'flow.json' }); await finished(f, run.runId);
  const table = f.storageDomain.tables.get('runs'), before = JSON.stringify(table.get(run.runId)).length;
  await f.call({ action: 'archive', runId: run.runId });
  const saved = table.get(run.runId);
  assert.equal(saved.snapshot, undefined); assert.equal(saved.workflow, undefined);
  assert.ok(saved.archivePayload); assert.ok(JSON.stringify(saved).length < before / 2);
  await f.unload(); await f.restart();
  await f.call({ action: 'restore', runId: run.runId });
  assert.equal(table.get(run.runId).snapshot.nodes.a.output.length, 72000);
});

test('external input mismatch protects native role child even without agentId', async t => {
  const f = await fixture(t, undefined, undefined, { native: true });
  await writeFile(join(f.root, 'input.txt'), 'one');
  await f.write({ id: 'implicit-capsule', inputFiles: ['input.txt'], nodes: [{ id: 'a', prompt: 'a', tools: [], retrySafe: true }] });
  const run = await f.call({ action: 'run', workflowPath: 'flow.json' }); const first = await finished(f, run.runId);
  await writeFile(join(f.root, 'input.txt'), 'two');
  const resumed = await f.call({ action: 'resume', runId: run.runId }); const last = await finished(f, resumed.runId);
  assert.equal(last.status, 'needs_review'); assert.equal(f.requests.length, 1);
  assert.equal(last.nodes.a.agentSessionId, first.nodes.a.agentSessionId);
});

for (const timed of [false, true]) test(`rework disposal uncertainty stops independent successors and quarantines target timed=${timed}`, async t => {
  const f = await fixture(t, async () => { if (timed) await new Promise(r => setTimeout(r, 12)); return 'done'; }, async () => { throw Error('uncertain child drain'); });
  await f.write({ id: `cleanup-rework-${timed}`, nodes: [{ id: 'a', prompt: 'a', retrySafe: true, maxRetries: 1, timeoutMs: timed ? 2 : 1000 }, { id: 'b', prompt: 'b' }] });
  const run = await f.call({ action: 'run', workflowPath: 'flow.json' }); const last = await finished(f, run.runId);
  assert.equal(last.status, 'needs_review'); assert.equal(f.requests.length, 1); assert.equal(last.nodes.b.status, 'blocked');
  await assert.rejects(f.call({ action: 'run', workflowPath: './flow.json' }), /locked|quarantin/i);
});

test('rework archive preview is exact read-only owner scoped and archived records are discoverable', async t => {
  const f = await fixture(t); await f.write({ id: 'preview-rework', nodes: [{ id: 'a', prompt: 'a' }] });
  const run = await f.call({ action: 'run', workflowPath: 'flow.json' }); await finished(f, run.runId);
  const before = JSON.stringify([...f.storageDomain.tables.get('runs')]);
  const preview = await f.call({ action: 'archive-preview', runId: run.runId });
  assert.equal(preview.ownerId, 'owner'); assert.equal(preview.runId, run.runId); assert.equal(preview.status, 'completed'); assert.equal(preview.eligible, true);
  assert.equal(preview.storageBytes, Buffer.byteLength(JSON.stringify(f.storageDomain.tables.get('runs').get(run.runId))));
  assert.equal(JSON.stringify([...f.storageDomain.tables.get('runs')]), before);
  await assert.rejects(f.call({ action: 'archive-preview', runId: run.runId }, { ...f.owner, id: 'other' }), /owner/);
  await assert.rejects(f.call({ action: 'list', includeArchived: 'yes' }), /includeArchived.*boolean/);
  await assert.rejects(f.call({ action: 'status', runId: run.runId, includeArchived: true }), /includeArchived.*list/);
  await f.call({ action: 'archive', runId: run.runId });
  const list = await f.call({ action: 'list', includeArchived: true });
  assert.equal(list.runs[0].isArchived, true); assert.ok(list.runs[0].archivedAt);
  assert.equal((await f.call({ action: 'list', includeArchived: true }, { ...f.owner, id: 'other' })).runs.length, 0);
  const protectedPreview = await f.call({ action: 'archive-preview', runId: run.runId }); assert.equal(protectedPreview.eligible, false); assert.match(protectedPreview.protectedReason, /archived/);
  await f.call({ action: 'restore', runId: run.runId });
  const resumed = await f.call({ action: 'resume', runId: run.runId }); await finished(f, resumed.runId);
  assert.match((await f.call({ action: 'archive-preview', runId: run.runId })).protectedReason, /ancestry/);
});

test('rework status misclassification cannot cancel active work at routing hook', async t => {
  let release; const gate = new Promise(r => release = r);
  const f = await fixture(t, async () => { await gate; return 'done'; }, undefined, { native: true, config: { globalEnabled: true } });
  f.owner.session = { header: {}, requestHeader: () => ({ config: { provider: 'unit', model: 'unit' } }) };
  f.services.llm = { async *stream() { yield { type: 'text-delta', text: '{"action":"revise"}' }; } };
  let interrupts = 0; const interrupt = f.services.subagents.interrupt;
  f.services.subagents.interrupt = (...args) => { interrupts++; return interrupt(...args); };
  await f.write({ id: 'status-rework', nodes: [{ id: 'a', agentId: 'a', prompt: 'a' }] });
  const run = await f.call({ action: 'run', workflowPath: 'flow.json' });
  let routed;
  try {
    for (let i = 0; !f.requests.length && i < 100; i++) await new Promise(r => setTimeout(r, 1));
    const hook = [...f.listeners.get('agent/pre-step')][0];
    for (const text of ['What is the current progress?', 'status please', '进度怎么样？']) {
      const messages = [{ id: text, role: 'user', source: { kind: 'user' }, content: [{ type: 'text', text }] }];
      routed = hook({ agent: f.owner, messages }, async () => ({ kind: 'enter', messages }));
      await Promise.race([routed, new Promise(r => setTimeout(r, 15))]);
      assert.equal(interrupts, 0); assert.equal((await f.call({ action: 'status', runId: run.runId })).status, 'running');
    }
  } finally { release(); await routed; }
  await finished(f, run.runId);
});

for (const action of ['run', 'resume', 'revise']) test(`rework ${action} rejects denied/deleted inputs and retains original capsule`, async t => {
  const f = await fixture(t, undefined, undefined, { native: true });
  const path = join(f.root, 'input.txt'); await writeFile(path, 'one');
  await f.write({ id: `inputs-rework-${action}`, inputFiles: ['input.txt'], nodes: [{ id: 'a', agentId: 'a', prompt: 'a' }] });
  const run = await f.call({ action: 'run', workflowPath: 'flow.json' }); const first = await finished(f, run.runId);
  const args = { action, ...(action === 'run' ? {} : { runId: run.runId }), ...(action === 'resume' ? {} : { workflowPath: 'flow.json' }) };
  const read = f.services.fs.readBytes;
  f.services.fs.readBytes = (target, ...rest) => { if (target.targetKey.endsWith('input.txt')) throw Error('input policy denied'); return read(target, ...rest); };
  await assert.rejects(f.call(args), /input policy denied/);
  f.services.fs.readBytes = read; await rm(path);
  await assert.rejects(f.call(args), /Cannot refresh inputFiles/);
  assert.equal(f.requests.length, 1); assert.equal((await f.call({ action: 'status', runId: run.runId })).nodes.a.agentSessionId, first.nodes.a.agentSessionId);
});

test('archived prior cannot erase a rejected non-retrySafe execution on same-path run', async t => {
  let possibleEffects = 0;
  const f = await fixture(t, async () => { possibleEffects++; throw Error('submitted operation but receipt is unavailable'); });
  await f.write({ id: 'archived-rejection', nodes: [{ id: 'a', prompt: 'submit operation' }] });
  const run = await f.call({ action: 'run', workflowPath: 'flow.json' });
  assert.equal((await finished(f, run.runId)).status, 'failed');
  assert.equal(possibleEffects, 1);
  await f.call({ action: 'archive', runId: run.runId });
  assert.equal((await f.call({ action: 'archive-read', runId: run.runId, nodeId: 'a' })).node.status, 'failed');
  await assert.rejects(f.call({ action: 'run', workflowPath: './flow.json' }), /archived.*restore|restore.*archived/i);
  assert.equal(possibleEffects, 1); assert.equal(f.requests.length, 1);
  await f.call({ action: 'restore', runId: run.runId });
  const resumed = await f.call({ action: 'run', workflowPath: 'flow.json' });
  assert.equal((await finished(f, resumed.runId)).status, 'needs_review');
  assert.equal(possibleEffects, 1); assert.equal(f.requests.length, 1);
});

test('completed archived prior requires restore even for a new workflow ID and retains capsule identity', async t => {
  const f = await fixture(t, async () => 'completed', undefined, { native: true });
  const workflow = { id: 'archived-completed', nodes: [{ id: 'a', agentId: 'worker', prompt: 'a' }] };
  await f.write(workflow);
  const run = await f.call({ action: 'run', workflowPath: 'flow.json' }); const first = await finished(f, run.runId);
  await f.call({ action: 'archive', runId: run.runId }); await f.unload(); await f.restart();
  await assert.rejects(f.call({ action: 'run', workflowPath: 'flow.json' }), /archived.*restore|restore.*archived/i);
  await f.write({ ...workflow, id: 'intentional-new-workflow' });
  await assert.rejects(f.call({ action: 'run', workflowPath: 'flow.json' }), /archived.*restore|restore.*archived/i);
  assert.equal(f.requests.length, 1);
  const archived = await f.call({ action: 'archive-read', runId: run.runId });
  assert.equal(archived.nodes.a.agentSessionId, first.nodes.a.agentSessionId);
  await f.write(workflow); await f.call({ action: 'restore', runId: run.runId });
  const next = await f.call({ action: 'run', workflowPath: 'flow.json' }); const last = await finished(f, next.runId);
  assert.equal(last.status, 'completed'); assert.equal(last.nodes.a.reused, true);
  assert.equal(last.nodes.a.agentSessionId, first.nodes.a.agentSessionId); assert.equal(f.requests.length, 1);
});
