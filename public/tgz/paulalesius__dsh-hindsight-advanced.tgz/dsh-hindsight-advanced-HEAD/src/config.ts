/**
 * The mount's configuration: the Standard-Schema v1 validator for the row's
 * `config` block and the resolved shape it produces.
 *
 * @module dsh-plugin-hindsight-advanced/config
 */

import { MEMORY_SCOPES, type MemoryScope } from './tiers.ts'

/** Resolved and validated plugin configuration: one mount, one bank. */
export interface ResolvedConfig {
  /** Hindsight bank id (case-sensitive). */
  bank: string
  /** Hindsight REST base URL, trailing slashes stripped. */
  baseUrl: string
  /** Optional API key, sent as a Bearer token; `undefined` sends no auth header. */
  apiKey?: string
  /** Optional credential REFERENCE (a POSIX identifier such as `HINDSIGHT_API_KEY`);
   *  the VALUE is resolved per call through the credentials seam (which layers
   *  process env, `$DSH_HOME/.credentials.yaml`, and `.env` files) — never stored
   *  here. Mutually exclusive with the literal `apiKey`. */
  apiKeyRef?: string
  /** The per-turn automatic recall is active. */
  autoContext: boolean
  /** `true` (default): the recall starts AHEAD of the turn that pays for
   *  it (the `agent/turn-stopping` job), so from the second turn on the
   *  snapshot targets the PREVIOUS turn's message. `false`: no job starts;
   *  every turn takes the bounded synchronous path, whose query is the
   *  message that just arrived (the turn waits on the server for it). */
  prefetch: boolean
  /** How many recent turns the automatic recall composes into its query
   *  (the reference Hindsight integrations' `recallContextTurns`): `1` =
   *  the anchor message only (the current turn's message on the
   *  synchronous path, the previous turn's message on the prefetch);
   *  `N` = the `N - 1` most recent PRIOR human turns above it, rendered
   *  as a `Prior context:` block (their user messages and the assistant
   *  replies between them), the whole thing capped at the query bound with
   *  the anchor kept whole and the oldest context dropping first. */
  recallContextTurns: number
  /** `true`: a LATER step of a running turn (a step claim without a human
   *  message) recalls when the previous step's committed assistant message
   *  carries visible `text` blocks: the step takes the bounded synchronous
   *  path anchored on that text, and its row is labeled `recall:text -
   *  <ms>ms`. Default `false`: a non-human step claim recalls nothing (the
   *  pre-step stays intervention-only). */
  recallAfterText: boolean
  /** `true`: the same mid-step recall, anchored on the previous step's
   *  `reasoning` blocks (its thinking) instead of its visible text (row
   *  label `recall:think - <ms>ms`). Default `false`. With BOTH keys on, a
   *  step that carries both kinds gets ONE recall on one composed anchor
   *  (row label `recall:think+text - <ms>ms`): never two lookups. A
   *  steering claim always wins the precedence over either anchor (the
   *  intervention path). */
  recallAfterReasoning: boolean
  /** `true`: at a LATER step of a running turn, the previous step's
   *  committed tool calls are matched against the bank's `experience`-type
   *  memories (past failure lessons) and the best matches are committed as
   *  a `form: 'notice'` row labeled `lesson:<tool> - <ms>ms`. The branch
   *  runs only when the mid-step anchor branch (the `recallAfterText` /
   *  `recallAfterReasoning` keys) did not attempt a recall of its own: one
   *  bounded recall pass per step. A steering claim wins the precedence
   *  over the branch; lessons already surfaced this turn are never repeated.
   *  Default `false`. Gated by `autoContext` like the other automatic
   *  branches. */
  actionLessons: boolean
  /** Cap on the number of lessons rendered on one action-lesson row (the
   *  bank's recall may return more; the surplus is dropped before render).
   *  Default 10. */
  actionLessonCandidates: number
  /** `true` (default): the model surface is append-only for the snapshots —
   *  every committed recall stays in the model context. `false`: the
   *  surface carries only the LATEST snapshot — each new one replaces the
   *  previously retained one (the session surface's `replace` op, priced
   *  through the shadow-price `compaction/prune` metering event) while the
   *  durable log keeps every snapshot for replay and audit. Naming matches
   *  the llama-server `--no-reasoning-preserve` flag: with it off, the
   *  server keeps each turn's reasoning only for that turn. */
  recallPreserve: boolean
  /** `true`: retain acknowledges fast and runs fact extraction in the
   *  background; `false` (default): the retain call waits for the bank to
   *  process the memory before returning. */
  retainAsync: boolean
  /** Token budget for recall responses. */
  maxRecallTokens: number
  /** Bound, in milliseconds, for the automatic recall lookup. */
  autoContextTimeoutMs: number
  /** The visibility tier `retain` uses when the model omits the `scope`
   *  parameter (see the tier model in `tiers.ts`). */
  retainScope: MemoryScope
  /** Optional Hindsight per-bank config overrides (e.g. `retain_mission`),
   *  forwarded verbatim as the server's `updates` in a one-time config
   *  PATCH that lands before the first memory operation. */
  bankConfig?: Record<string, string>
}

const DEFAULT_BASE_URL = 'http://127.0.0.1:8888'
const DEFAULT_MAX_RECALL_TOKENS = 4096
const DEFAULT_AUTO_CONTEXT_TIMEOUT_MS = 2500
/** How many recent turns the automatic recall composes into its query
 *  (the reference Hindsight integrations' default is 1; the plugin's is 5
 *  — the `Prior context:` block is the query's first-class part). */
const DEFAULT_RECALL_CONTEXT_TURNS = 5
/** How many action-lesson hits the lesson row renders by default (the
 *  client-side cap applied before render; see {@link ResolvedConfig.actionLessonCandidates}). */
const DEFAULT_ACTION_LESSON_CANDIDATES = 10
/** Credential-reference grammar (a POSIX shell identifier), matching the
 *  credentials seam's own `CredentialRef` so an invalid name is a config
 *  issue rather than a per-call resolution surprise. */
const API_KEY_REF_PATTERN = /^[A-Za-z_][A-Za-z0-9_]*$/

interface ConfigIssue {
  message: string
  path?: string[]
}

type ConfigResult = { value: ResolvedConfig } | { issues: readonly ConfigIssue[] }

/** Read one boolean flag from a record, collecting an issue on a non-boolean. */
function boolFlag(
  record: Record<string, unknown>,
  key: string,
  fallback: boolean,
  issues: ConfigIssue[],
): boolean {
  const value = record[key]
  if (value === undefined) return fallback
  if (value !== true && value !== false) {
    issues.push({ message: `${key} must be a boolean`, path: [key] })
    return fallback
  }
  return value
}

/** Read one positive-integer flag from a record, collecting an issue on misuse. */
function intFlag(
  record: Record<string, unknown>,
  key: string,
  fallback: number,
  issues: ConfigIssue[],
): number {
  const value = record[key]
  if (value === undefined) return fallback
  if (typeof value !== 'number' || !Number.isInteger(value) || value < 1) {
    issues.push({ message: `${key} must be a positive integer`, path: [key] })
    return fallback
  }
  return value
}

/**
 * Standard-schema v1 validator for the row's `config`.
 *
 * Hand-rolled on purpose: the deploy location is a preset directory, where
 * Node's upward `node_modules` walk does not reach `@deepseek-ai/schemastery`;
 * a minimal validator keeps the file self-contained while still surfacing
 * issues through Cordis's `ValidationError`.
 */
export const Config: {
  readonly '~standard': {
    readonly version: 1
    readonly validate: (input: unknown) => ConfigResult
  }
} = {
  '~standard': {
    version: 1,
    validate(input: unknown): ConfigResult {
      const issues: ConfigIssue[] = []
      if (input !== null && typeof input !== 'object') {
        return { issues: [{ message: 'config must be an object' }] }
      }
      const record = (input ?? {}) as Record<string, unknown>

      let bank: string | undefined
      if (record.bank !== undefined) {
        if (typeof record.bank !== 'string' || record.bank.trim().length === 0) {
          issues.push({ message: 'bank must be a non-empty string', path: ['bank'] })
        } else {
          bank = record.bank.trim()
        }
      }
      if (bank === undefined) {
        issues.push({ message: 'bank is required', path: ['bank'] })
      }

      let baseUrl = DEFAULT_BASE_URL
      if (record.baseUrl !== undefined) {
        if (typeof record.baseUrl !== 'string' || record.baseUrl.trim().length === 0) {
          issues.push({ message: 'baseUrl must be a non-empty string', path: ['baseUrl'] })
        } else {
          baseUrl = record.baseUrl.trim().replace(/\/+$/, '')
        }
      }

      let apiKey: string | undefined
      if (record.apiKey !== undefined) {
        if (typeof record.apiKey !== 'string' || record.apiKey.trim().length === 0) {
          issues.push({ message: 'apiKey must be a non-empty string', path: ['apiKey'] })
        } else {
          apiKey = record.apiKey.trim()
        }
      }

      let apiKeyRef: string | undefined
      if (record.apiKeyRef !== undefined) {
        if (typeof record.apiKeyRef !== 'string' || !API_KEY_REF_PATTERN.test(record.apiKeyRef)) {
          issues.push({
            message: 'apiKeyRef must be a POSIX identifier (e.g. HINDSIGHT_API_KEY)',
            path: ['apiKeyRef'],
          })
        } else {
          apiKeyRef = record.apiKeyRef
        }
      }
      if (record.apiKey !== undefined && record.apiKeyRef !== undefined) {
        issues.push({
          message: 'set apiKey OR apiKeyRef, not both',
          path: ['apiKey', 'apiKeyRef'],
        })
      }

      let bankConfig: Record<string, string> | undefined
      if (record.bankConfig !== undefined) {
        const raw = record.bankConfig
        if (typeof raw !== 'object' || raw === null || Array.isArray(raw)) {
          issues.push({ message: 'bankConfig must be a flat object of string values', path: ['bankConfig'] })
        } else {
          const overrides: Record<string, string> = {}
          for (const [key, entry] of Object.entries(raw)) {
            if (typeof entry !== 'string') {
              issues.push({ message: `bankConfig.${key} must be a string`, path: ['bankConfig', key] })
              continue
            }
            overrides[key] = entry
          }
          bankConfig = Object.keys(overrides).length > 0 ? overrides : undefined
        }
      }

      let retainScope: MemoryScope = 'preset'
      if (record.retainScope !== undefined) {
        if (typeof record.retainScope !== 'string' || !(MEMORY_SCOPES as readonly string[]).includes(record.retainScope)) {
          issues.push({ message: "retainScope must be one of 'global', 'preset', 'session'", path: ['retainScope'] })
        } else {
          retainScope = record.retainScope as MemoryScope
        }
      }

      const value: ResolvedConfig = {
        bank: bank ?? '',
        baseUrl,
        ...(apiKey !== undefined ? { apiKey } : {}),
        ...(apiKeyRef !== undefined ? { apiKeyRef } : {}),
        ...(bankConfig !== undefined ? { bankConfig } : {}),
        autoContext: boolFlag(record, 'autoContext', true, issues),
        prefetch: boolFlag(record, 'prefetch', true, issues),
        recallContextTurns: intFlag(record, 'recallContextTurns', DEFAULT_RECALL_CONTEXT_TURNS, issues),
        recallAfterText: boolFlag(record, 'recallAfterText', false, issues),
        recallAfterReasoning: boolFlag(record, 'recallAfterReasoning', false, issues),
        actionLessons: boolFlag(record, 'actionLessons', false, issues),
        actionLessonCandidates: intFlag(record, 'actionLessonCandidates', DEFAULT_ACTION_LESSON_CANDIDATES, issues),
        recallPreserve: boolFlag(record, 'recallPreserve', true, issues),
        retainAsync: boolFlag(record, 'retainAsync', false, issues),
        maxRecallTokens: intFlag(record, 'maxRecallTokens', DEFAULT_MAX_RECALL_TOKENS, issues),
        autoContextTimeoutMs: intFlag(record, 'autoContextTimeoutMs', DEFAULT_AUTO_CONTEXT_TIMEOUT_MS, issues),
        retainScope,
      }
      return issues.length > 0 ? { issues } : { value }
    },
  },
}
