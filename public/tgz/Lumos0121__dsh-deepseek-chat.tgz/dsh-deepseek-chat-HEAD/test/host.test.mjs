/**
 * dsh-deepseek-chat — 宿主半边离线测试（零依赖，零副作用）
 *
 * 宿主半边只做两件事：静态核对客户端产物、注册 `deepseek-chat:` 协议。
 * 这里断言的是「哪怕在最坏的环境里，它也不会抛错、不会静默写脏数据」：
 *
 *   1. 常量形状：协议名 / URL / Start-Process 命令行（URL 是字面量，不做 `%1` 拼接）
 *   2. auditClientBundle 对真实产物放行；对调用方抛错的日志出口也绝不外抛
 *   3. protocolRegistered 只读注册表：返回布尔、绝不抛错
 *   4. 非 Windows 上 ensureProtocol 直接返回 false（绝不写注册表）
 *   5. apply 在任何 ctx 形态下都不抛错（含 null / 缺 logger / logger 自己抛错）
 *
 * 注意：本文件**不执行任何 `reg add`**。写注册表只发生在 install-profile.ps1
 * （用户显式运行）和 Desktop 承载下 apply() 里的幂等补登（已注册则跳过）。
 */
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import test from "node:test";

const HOST_URL = new URL("../lib/index.js", import.meta.url);
const HOST_SOURCE = readFileSync(fileURLToPath(HOST_URL), "utf8");
const host = await import(HOST_URL.href);

const { PACKAGE_ID, CHAT_URL, PROTOCOL, PROTOCOL_URL, SHELL_OPEN_COMMAND, ensureProtocol, auditClientBundle, protocolRegistered } =
  host.__internals;

test("常量：协议名 / 地址 / 命令行（URL 是字面量，不存在 %1 拼接）", () => {
  assert.equal(PACKAGE_ID, "dsh-deepseek-chat");
  assert.equal(CHAT_URL, "https://chat.deepseek.com/");
  assert.equal(PROTOCOL, "deepseek-chat");
  assert.equal(PROTOCOL_URL, "deepseek-chat://open");
  assert.match(SHELL_OPEN_COMMAND, /powershell\.exe/);
  assert.match(SHELL_OPEN_COMMAND, /Start-Process/);
  assert.ok(SHELL_OPEN_COMMAND.includes(`'${CHAT_URL}'`), "URL 必须以字面量出现");
  assert.ok(!SHELL_OPEN_COMMAND.includes("%1"), "命令行不得拼接 %1");
});

test("auditClientBundle：真实产物必须放行（否则按钮可能不出现）", () => {
  const warnings = [];
  assert.doesNotThrow(() => auditClientBundle((message) => warnings.push(message)));
  assert.deepEqual(warnings, [], `客户端产物自检不应告警：${warnings.join(" | ")}`);
});

test("auditClientBundle：日志出口自己抛错时也不外抛（apply 的安全前提）", () => {
  assert.doesNotThrow(() =>
    auditClientBundle(() => {
      throw new Error("日志出口炸了");
    }),
  );
});

test("protocolRegistered：只读不写，返回布尔，且绝不抛错", () => {
  let value;
  assert.doesNotThrow(() => {
    value = protocolRegistered();
  });
  assert.equal(typeof value, "boolean");
});

test("protocolRegistered：必须查命名值 /v \"URL Protocol\"（查 /ve 会永远返回 false）", () => {
  // 回归护栏：曾经写成 `reg query <key> /ve`，那只会返回 (Default) 值
  // "URL:deepseek-chat Protocol"，里面**不含**子串 "URL Protocol"，
  // 于是协议明明注册成功，宿主每次仍判定未注册、反复重写注册表。
  const start = HOST_SOURCE.indexOf("function protocolRegistered()");
  assert.ok(start > 0, "找不到 protocolRegistered 源码");
  const body = HOST_SOURCE.slice(start, HOST_SOURCE.indexOf("\n}", start));
  assert.ok(body.includes('"URL Protocol"'), "查询参数里必须出现命名值 URL Protocol");
  assert.ok(!body.includes('"/ve"'), "存在性判断不得用 /ve（只写值的那几处不受影响）");
});

test("非 Windows：ensureProtocol 直接返回 false，绝不写注册表", () => {
  const descriptor = Object.getOwnPropertyDescriptor(process, "platform");
  assert.ok(descriptor, "process.platform 应该是可属性化的");
  Object.defineProperty(process, "platform", { value: "linux", configurable: true });
  try {
    assert.equal(ensureProtocol(), false);
  } finally {
    Object.defineProperty(process, "platform", descriptor);
  }
});

test("apply：任意 ctx 形态都不抛错（含 null / 缺 logger / logger 自己抛错）", () => {
  assert.equal(typeof host.apply, "function");
  assert.equal(typeof host.default.apply, "function");
  const cases = [
    null,
    undefined,
    {},
    { logger: undefined },
    {
      logger: () => ({
        warn() {
          throw new Error("boom");
        },
      }),
    },
  ];
  // 测试进程不是 Desktop 承载：apply 里的注册表补登分支会被跳过，
  // 所以这里只验证「异常安全」这条契约，绝不会改动测试机的注册表。
  const savedProfile = process.env.DSH_PROFILE;
  const savedDesktop = process.env.DSH_DESKTOP;
  process.env.DSH_PROFILE = "test";
  delete process.env.DSH_DESKTOP;
  try {
    for (const ctx of cases) {
      assert.doesNotThrow(() => host.apply(ctx), "apply 必须永远静默成功");
    }
  } finally {
    if (savedProfile === undefined) delete process.env.DSH_PROFILE;
    else process.env.DSH_PROFILE = savedProfile;
    if (savedDesktop === undefined) delete process.env.DSH_DESKTOP;
    else process.env.DSH_DESKTOP = savedDesktop;
  }
});

test("宿主产物形状：具名导出 + default 导出 + __internals", () => {
  assert.equal(typeof host.apply, "function");
  assert.equal(typeof host.default, "object");
  assert.equal(typeof host.default.apply, "function");
  assert.ok(host.__internals);
  assert.ok(HOST_SOURCE.includes("export function apply"), "应导出具名 apply");
  assert.ok(HOST_SOURCE.includes("export default { apply }"), "应导出 default { apply }");
});

test("宿主半边不声明任何注入服务（避免 fiber 停在 PENDING）", () => {
  assert.ok(!/export\s+const\s+inject/.test(HOST_SOURCE), "宿主半边不应导出 inject");
  assert.ok(!/inject\s*=\s*\[/.test(HOST_SOURCE), "宿主半边不应声明 inject 列表");
});

/**
 * 装机脚本的编码护栏。这两条都是「本机能跑、别人机器上炸」的坑：
 *   · install.cmd 里只要有一个非 ASCII 字节，cmd.exe 在 GBK 代码页下就会错配字节、
 *     把相邻的 ASCII 字符一起吃掉，整份脚本被撕成碎片逐条报「不是内部或外部命令」；
 *   · install.cmd 还必须用 CRLF（cmd 的标签/goto 解析对裸 LF 很脆）。
 * install-profile.ps1 反过来必须是「UTF-8 with BOM」：PS 5.1 没有 BOM 时按 ANSI 读，
 * 中文注释会变乱码并引发语法错误。
 */
test("装机脚本编码：install.cmd 纯 ASCII + CRLF，install-profile.ps1 带 BOM", () => {
  const cmdBytes = readFileSync(fileURLToPath(new URL("../install.cmd", import.meta.url)));
  const high = [...cmdBytes].filter((byte) => byte > 0x7e || byte === 0);
  assert.equal(high.length, 0, `install.cmd 只能是 ASCII，却出现了 ${high.length} 个高位/零字节`);
  const cmdText = cmdBytes.toString("latin1");
  const bareLf = cmdText.match(/(?<!\r)\n/g) || [];
  assert.equal(bareLf.length, 0, "install.cmd 必须全部是 CRLF 换行");
  assert.ok(cmdText.includes("install-profile.ps1"), "启动器要指向主脚本");

  const ps1Bytes = readFileSync(fileURLToPath(new URL("../install-profile.ps1", import.meta.url)));
  assert.deepEqual(
    [...ps1Bytes.subarray(0, 3)],
    [0xef, 0xbb, 0xbf],
    "install-profile.ps1 必须带 UTF-8 BOM（PS 5.1 否则按 ANSI 读）",
  );
});
