/**
 * dsh-deepseek-chat — 离线测试（零依赖，node --test "test/*.test.mjs"）
 *
 * 本测试不连接任何真实运行时：它在一个 `vm` 沙箱里提供
 * `window` / `window.__ModuleLoader__` / `document` / Blob / URL，把
 * `lib/client.js` 当作浏览器产物跑起来，然后断言：
 *
 *   1. 产物形状（模块加载器 id、工厂交出 exports、apply/inject 就位）
 *   2. 插槽接线（注入的服务、注册的槽位名 / id / order；页脚按钮 + 隐藏的会话 id 探针）
 *   3. 样式只插一次，且只用 DSH 官方主题变量
 *   4. **菜单**：点击侧边栏按钮只展开五个选项（收起时不渲染任何选项），
 *      文案/顺序/分隔线/无障碍属性稳定；选哪个才走哪条路，且菜单随之收起
 *   5. **选项一（右侧栏）**：`sidebarRightTabs.get('browser')` 可用时只调
 *      `sidebarRight.openTab('browser', { params: { url } })`（应用内右侧栏）；
 *      不可用时如实播报"右侧栏不可用"并退回系统浏览器，**不假装成功**
 *   6. **选项二（系统浏览器）**：`window.open(https://chat.deepseek.com/, '_blank')`
 *      排第一 —— 它由 Electron 主进程的 setWindowOpenHandler 转成 shell.openExternal；
 *      兜底链：deepseek-chat: 协议 → <a target="_blank"> → 全失败时如实报失败
 *   7. **选项三（读取右侧边栏内对话）**：在 `webview[data-sidebar-browser-frame]`
 *      上跑 `executeJavaScript`（点「分享」取链接 + 抓正文），再经
 *      `sessions.binding(id).session.prompt([...], 'queue')` 发进当前会话；
 *      没有 webview / 不是目标站点 / 没有会话 id / 没有 sessions 服务 / 载荷解析失败
 *      —— 每一种都必须如实播报，绝不静默、绝不假装成功
 *   8. **选项四（读取系统浏览器对话）**：读剪贴板里的分享链接或正文再转投；
 *      空 / 非分享链接 / 太短 / 剪贴板不可用，四种都不投递并说明原因
 *   9. 组件本身：窄栏只渲染图标、宽栏渲染图标 + 文案，带 title 与 aria-label；
 *      读取进行中两个读取选项禁用（防连点）
 *
 * 离线迷你 React：`useState` 真的存值（同一份 hook 存储跨渲染保持），
 * 但**不自动重渲染** —— 测试自己调 `view.render()` 再断言新树。
 * 注意：槽位交出的是函数组件，`view.render()` 得到的是惰性元素；要拿"此刻"的
 * 快照必须先 `materialize()`，否则后续遍历会用**当时的 state** 重新渲染。
 */
import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import assert from "node:assert/strict";
import test from "node:test";
import vm from "node:vm";

const BUNDLE_PATH = fileURLToPath(new URL("../lib/client.js", import.meta.url));
const BUNDLE_SOURCE = readFileSync(BUNDLE_PATH, "utf8");

const PACKAGE_ID = "dsh-deepseek-chat";
const SLOT_NAME = "sidebar.footer.action";
const CHAT_URL = "https://chat.deepseek.com/";
const PROTOCOL_URL = "deepseek-chat://open";

/** 所有运行时的 hook 存储（`resetHooks` 让每个函数组件从游标 0 开始读）。 */
const HOOK_STORES = [];

function resetHooks() {
  for (const store of HOOK_STORES) store.cursor = 0;
}

/**
 * 最小 React：`createElement` 只记账；`useState` 真的有状态（否则
 * "点击展开菜单" 这条交互根本无法离线断言）。
 */
function createReactMock() {
  const store = { slots: [], cursor: 0 };
  HOOK_STORES.push(store);

  return {
    store,
    React: {
      createElement(type, props, ...children) {
        // 与真实 React 一致：数组形式的 children 会被摊平
        const flat = [];
        for (const child of children) {
          if (Array.isArray(child)) flat.push(...child);
          else flat.push(child);
        }
        const merged = { ...(props ?? {}) };
        if (flat.length === 1) merged.children = flat[0];
        else if (flat.length > 1) merged.children = flat;
        return { type, props: merged };
      },
      useState(initial) {
        const index = store.cursor++;
        if (!(index in store.slots)) {
          store.slots[index] = typeof initial === "function" ? initial() : initial;
        }
        const set = (next) => {
          store.slots[index] = typeof next === "function" ? next(store.slots[index]) : next;
        };
        return [store.slots[index], set];
      },
      useEffect() {},
      useRef(value) {
        return { current: value };
      },
      useCallback(fn) {
        return fn;
      },
      useMemo(fn) {
        return fn();
      },
    },
  };
}

const ReactDOM = {};

/** 造一个全新的运行时沙箱（每个用例一份，互不串味）。 */
function createRuntime({ open, storage } = {}) {
  const events = [];
  const appended = [];
  const styles = [];
  const byId = new Map();

  const document = {
    head: {
      appendChild(node) {
        appended.push(node);
        if (node && node.tagName === "STYLE") {
          styles.push(node);
          // 让后续 getElementById 真实命中：样式插入的幂等性就是靠它实现的
          byId.set(node.id, node);
        }
        return node;
      },
    },
    createElement(tagName) {
      return {
        tagName: String(tagName).toUpperCase(),
        attrs: {},
        style: {},
        children: [],
        setAttribute(name, value) {
          this.attrs[name] = value;
        },
        appendChild(child) {
          this.children.push(child);
          return child;
        },
        remove() {},
        addEventListener() {},
        click() {
          events.push({ kind: "anchor-click", href: this.attrs.href, target: this.attrs.target });
        },
      };
    },
    getElementById(id) {
      return byId.get(id) ?? null;
    },
    // 右侧栏内嵌浏览器的选择器（插件的 SIDEBAR_WEBVIEW_SELECTOR）
    querySelectorAll(selector) {
      if (selector === "webview[data-sidebar-browser-frame]") return webviews;
      return [];
    },
  };

  /** 假剪贴板：测试自己设定内容、读回插件写了什么（未设定时按"没有 API"处理）。 */
  const clipboard = {
    text: "",
    written: [],
    enabled: true,
    readText() {
      if (!this.enabled) return Promise.reject(new Error("no clipboard permission"));
      return Promise.resolve(this.text);
    },
    writeText(value) {
      if (!this.enabled) return Promise.reject(new Error("no clipboard permission"));
      this.written.push(String(value));
      return Promise.resolve();
    },
  };

  /** 测试推入的假 `<webview>` 元素（默认一个都没有）。 */
  const webviews = [];

  /** 渲染进程的 localStorage 替身：自定义提示词就存在这里。 */
  const store = storage ?? new Map();
  const storageLike = {
    getItem: (key) => (store.has(key) ? store.get(key) : null),
    setItem: (key, value) => store.set(key, String(value)),
    removeItem: (key) => store.delete(key),
  };

  const window = {
    __dshStyles: styles,
    localStorage: storageLike,
    open: (...args) => {
      events.push({ kind: "window.open", args: [...args] });
      return open === undefined ? { closed: false } : open(...args);
    },
    addEventListener() {},
    removeEventListener() {},
    setTimeout() {
      return 0;
    },
  };

  const sandbox = {
    window,
    document,
    navigator: { clipboard },
    console: { log() {}, warn() {}, error() {} },
    Blob: class Blob {
      constructor(parts, options) {
        this.parts = parts;
        this.type = options?.type ?? "";
      }
    },
    URL: {
      createObjectURL() {
        return "blob:mock";
      },
      revokeObjectURL() {},
    },
    /* 宿主侧只有「等右侧栏把分享页打开」这一处要定时器；给个 0 延迟的真定时器就够。 */
    setTimeout: (fn) => setTimeout(fn, 0),
    clearTimeout: (id) => clearTimeout(id),
  };
  sandbox.self = sandbox;
  sandbox.globalThis = sandbox;
  window.__ModuleLoader__ = {
    load(definition) {
      sandbox.__definition = definition;
    },
  };

  const { React } = createReactMock();

  vm.createContext(sandbox);
  vm.runInContext(BUNDLE_SOURCE, sandbox, { filename: "lib/client.js" });

  const definition = sandbox.__definition;
  assert.ok(definition, "bundle 没有调用 window.__ModuleLoader__.load");
  const exported = definition.factory((name) => {
    if (name === "react") return React;
    if (name === "react-dom") return ReactDOM;
    throw new Error(`未预期的 require(${JSON.stringify(name)})`);
  });

  return {
    sandbox,
    definition,
    exports: exported,
    events,
    appended,
    styles,
    document,
    window,
    clipboard,
    webviews,
    store,
  };
}

/** 跑一次 apply，返回注册调用与 context。`extra` 用来塞入可选服务（如 get）。 */
function mount(runtime, extra) {
  const calls = [];
  const registered = [];
  const ctx = {
    slots: {
      inject(key, callback) {
        calls.push({ kind: "inject", key });
        return callback();
      },
      register(options, component) {
        calls.push({ kind: "register", options });
        registered.push({ options, component });
        return { dispose() {} };
      },
    },
    ...(extra ?? {}),
  };
  runtime.exports.apply(ctx);
  return { ctx, calls, registered, entry: registered[0] };
}

/** 造一个「右侧栏可用」的原生 ctx 替身（照抄 ui-chat 的探测写法）。 */
function sidebarContext({ kinds = ["browser"], openTab } = {}) {
  const opened = [];
  const ctx = {
    get(name) {
      if (name === "sidebarRightTabs") {
        return { get: (kind) => (kinds.includes(kind) ? { id: kind } : undefined) };
      }
      if (name === "sidebarRight") {
        if (openTab === undefined) {
          return { openTab: (kind, options) => opened.push({ kind, options }) };
        }
        return openTab === null ? undefined : { openTab };
      }
      return undefined;
    },
  };
  return { ctx, opened };
}

/**
 * 组件探针：`render()` = 一次渲染（hook 游标归零后调用组件）。
 * 状态存在 runtime 的 hook 存储里，所以反复 render 会保留上次的 useState 值。
 */
function createView(entry, props) {
  return {
    render() {
      resetHooks();
      return entry.component(props);
    },
  };
}

/** 菜单里五项的顺序（读的是 role="menuitem" 的渲染顺序）。 */
const CHOICE_INDEX = { sidebar: 0, external: 1, "read-sidebar": 2, "read-external": 3, edit: 4 };

/** 展开菜单，返回 { entry, view, items, registered, calls }（items 断言过是五项）。 */
function openMenu(runtime, extra, props = { wide: true }) {
  const { entry, registered, calls } = mount(runtime, extra);
  const view = createView(entry, props);
  // 同一个运行时可能已经展开过（读取链的用例会连续点两次）
  if (findMenuItems(view.render()).length === 0) {
    const collapsed = findButtons(view.render());
    assert.equal(collapsed.length, 1, "菜单应收起：只渲染主按钮");
    collapsed[0].props.onClick();
  }
  const items = findMenuItems(view.render());
  assert.equal(items.length, 5, "展开后应恰好五个选项（开右侧栏 / 开系统浏览器 / 读右侧栏 / 读系统浏览器 / 自定义提示词）");
  return { entry, view, items, registered, calls };
}

/** 等所有 microtask / 已排队的 then 跑完（读取链是异步的）。 */
function flush(times = 8) {
  let chain = Promise.resolve();
  for (let index = 0; index < times; index += 1) {
    chain = chain.then(() => new Promise((resolve) => setImmediate(resolve)));
  }
  return chain;
}

/**
 * 走一遍真实交互：点主按钮展开菜单 → 点其中一个选项。
 * @param {"sidebar"|"external"|"read-sidebar"|"read-external"} which
 * @returns {any[]} 事件流水
 */
function chooseWith(runtime, which, extra) {
  const { items, view } = openMenu(runtime, extra);
  assert.ok(which in CHOICE_INDEX, `未知选项：${which}`);
  items[CHOICE_INDEX[which]].props.onClick();
  view.render(); // 让读取链的同步部分（busy / 状态位）先落地
  return runtime.events;
}

/** 点一个「读取」选项，等异步链跑完，返回「读取中」与「读完之后」两棵已展开的树。 */
async function chooseRead(runtime, which, extra, props = { wide: true }) {
  const { items, view, registered } = openMenu(runtime, extra, props);
  items[CHOICE_INDEX[which]].props.onClick();
  // 必须立刻 materialize：槽位注册交出的是函数组件，`view.render()` 返回的
  // 还是惰性元素 —— 之后再去遍历它会**用当时的 state 重新渲染**，快照就丢了。
  const during = materialize(view.render());
  await flush();
  const after = materialize(view.render());
  return { tree: during, after, view, items, registered, events: runtime.events };
}

/** 假 <webview>：记录 executeJavaScript 收到的脚本，按设定返回/抛错。 */
function fakeWebview({ url = "https://chat.deepseek.com/a/chat/s/1", payload = null, error = null } = {}) {
  const calls = [];
  return {
    calls,
    getURL: () => url,
    getAttribute: () => null,
    executeJavaScript(code, gesture) {
      calls.push({ code, gesture });
      if (error) return Promise.reject(error);
      return Promise.resolve(payload);
    },
  };
}

/** 内嵌页返回的载荷（readGuestScript 的形状）。 */
function guestPayload(overrides = {}) {
  return JSON.stringify({
    ok: true,
    url: "https://chat.deepseek.com/share/abc123",
    href: "https://chat.deepseek.com/a/chat/s/1",
    title: "共产党宣言心得 - DeepSeek",
    text: "用户：帮我总结一下共产党宣言\n助手：好的，下面分四点……",
    share: "clicked",
    buttons: [],
    error: "",
    ...overrides,
  });
}

/** 假 sessions 服务：记录 prompt 收到的东西。 */
function sessionsWithPrompt(prompts, { ok = true, error = null } = {}) {
  const binding = {
    sessionId: "session-1",
    session: {
      prompt(parts, mode) {
        prompts.push({ parts, mode });
        if (error) return Promise.reject(error);
        return Promise.resolve(ok ? { ok: true, value: { accepted: true } } : { ok: false, error });
      },
    },
  };
  return {
    binding: () => binding,
    retain: () => ({ binding, release() {} }),
  };
}

/** 按 role 找第一个节点。 */
function findByRole(tree, role) {
  let found = null;
  walk(tree, (node) => {
    if (found === null && node.props?.role === role) found = node;
  });
  return found;
}

/* ───────────────────────────── 产物与接线 ───────────────────────────── */

test("产物形状：模块加载器 id、工厂、apply / inject", () => {
  const runtime = createRuntime();
  assert.equal(runtime.definition.id, PACKAGE_ID);
  assert.equal(typeof runtime.definition.factory, "function");
  assert.equal(typeof runtime.exports.apply, "function");
  assert.deepEqual([...runtime.exports.inject], ["slots"]);
});

test("源码静态护栏：工厂体里不得出现模块作用域立即执行的 installStyles 调用", () => {
  // 上面那条行为断言依赖 document 能记录插入；这条直接盯源码文本，
  // 防止有人把「模块求值期插样式」那行加回来（那就是这次启动事故的复现条件）。
  const flat = BUNDLE_SOURCE.replace(/\s+/g, " ");
  assert.ok(
    /try \{ installStyles\(\); \} catch/.test(flat),
    "apply 里的 installStyles 必须包在 try/catch 里（绝不外抛）",
  );
  // 模块作用域（零缩进）不得出现任何 installStyles 调用
  const topLevel = BUNDLE_SOURCE.split("\n").filter((line) => /^installStyles\(/.test(line));
  assert.deepEqual(topLevel, [], `模块作用域出现了 installStyles 调用：${topLevel.join(" | ")}`);
});

test("插槽接线：注册到 sidebar.footer.action，id / order 稳定", () => {
  const runtime = createRuntime();
  const { calls, entry } = mount(runtime);
  const { CAPTURE_SLOT, CAPTURE_ID } = runtime.exports.__internals;
  assert.deepEqual(
    calls.map((call) => call.kind),
    ["inject", "register", "inject", "register"],
    "页脚按钮 + 隐藏的会话 id 探针，各注册一次",
  );
  assert.equal(calls[0].key, SLOT_NAME);
  assert.equal(calls[1].options.name, SLOT_NAME);
  assert.equal(calls[1].options.id, PACKAGE_ID);
  assert.equal(calls[1].options.order, 10);
  assert.equal(typeof entry.component, "function");
  assert.equal(typeof entry.options.label, "function");
  // 第二个注册只用来捕获当前会话 id，必须渲染 null（不许往输入框附近塞可见 DOM）
  assert.equal(calls[2].key, CAPTURE_SLOT);
  assert.equal(calls[3].options.name, CAPTURE_SLOT);
  assert.equal(calls[3].options.id, CAPTURE_ID);
});

test("样式：**工厂运行期零副作用**，样式只在 apply 时插入", () => {
  const runtime = createRuntime();
  // 关键回归护栏：工厂运行（= import 阶段）绝不允许碰 DOM。
  // 本机踩过：模块求值期的样式副作用让这条 entry 停在非 ACTIVE，
  // DSH 启动审计直接报 `web boot: 1 entry did not activate` 并拒绝启动。
  assert.equal(runtime.styles.length, 0, "import 阶段不应插入任何 <style>");

  const { entry } = mount(runtime);
  assert.equal(runtime.styles.length, 1, "apply 应插入一份样式");
  assert.equal(typeof entry.component, "function");

  const css = String(runtime.styles[0].textContent ?? "");
  assert.match(css, /--dsw-alias-interactive-bg-hover/, "悬停必须用官方交互底色 token");
  assert.match(css, /dsh-deepseek-chat/);
  assert.ok(!/#[0-9a-fA-F]{3,8}\b/.test(css), "不应写死十六进制颜色");
  assert.match(css, /position: absolute/, "无障碍状态位应视觉隐藏");
  assert.match(css, /-menu\b/, "菜单容器应有样式");
  assert.match(css, /-option\b/, "选项按钮应有样式");
  assert.match(css, /-action--narrow\b/, "窄栏修饰类应有样式");
  assert.match(css, /-divider\b/, "「打开」与「读取」两组选项之间应有分隔线样式");
  assert.match(css, /-hint\b/, "菜单里那行可见提示（失败原因）应有样式");
  assert.match(css, /-option\[disabled\]/, "读取进行中应禁用读取选项");
  assert.match(css, /-form-title\b/, "自定义提示词面板的标题应有样式");
  assert.match(css, /-input\b/, "自定义提示词面板的输入框应有样式");
  assert.match(css, /-field-label\b/, "输入框上面那行小字应有样式");

  // 回归护栏：只允许引用本机主题里**确实存在**的变量名。
  // 曾经的教训：CSS 里写了 --dsh-border / --dsh-text-secondary / --dsh-fill-hover
  // 这套想当然的名字，而本机主题的前缀是 --dsw-*（--dsh-* 里根本没有这几支），
  // 于是 var() 全部退化成 fallback —— 边框、悬停底色、强调色一个都没生效。
  const ALLOWED_TOKENS = new Set([
    "--dsw-alias-interactive-bg-hover",
    "--dsw-alias-interactive-bg-active",
    "--dsw-alias-label-primary",
    "--dsw-alias-label-secondary",
    "--dsw-alias-border-l1",
    "--dsw-alias-border-l2",
    "--dsw-alias-bg-layer-2",
    "--dsw-alias-brand-primary",
    "--dsw-menu-surface-fill",
    "--dsw-menu-backdrop-filter",
    "--dsw-elevation-panel",
    "--dsw-shadow-lv1",
    "--dsw-radius-sm",
    "--dsw-radius-md",
  ]);
  for (const match of css.matchAll(/var\((--[a-z0-9-]+)/g)) {
    assert.ok(ALLOWED_TOKENS.has(match[1]), `CSS 引用了未登记的主题变量：${match[1]}`);
  }
});

test("样式插入幂等：再次 apply 不会插入第二份", () => {
  const runtime = createRuntime();
  mount(runtime);
  mount(runtime);
  assert.equal(runtime.styles.length, 1);
});

test("apply 绝不抛错：ctx 畸形 / 服务缺失 / DOM 损坏都必须静默降级", () => {
  const brokenDom = createRuntime();
  brokenDom.document.createElement = () => {
    throw new Error("document 坏了");
  };
  for (const ctx of [
    null,
    undefined,
    {},
    { slots: undefined },
    {
      slots: {
        inject() {
          throw new Error("slot not available");
        },
      },
    },
  ]) {
    assert.doesNotThrow(() => brokenDom.exports.apply(ctx), "apply 必须永远静默成功");
  }
  // 插槽注册失败也不能影响组件本身仍然可渲染
  const runtime = createRuntime();
  const { entry } = mount(runtime);
  assert.doesNotThrow(() => entry.component({ wide: true }));
});

test("注入的 slots.inject(key, cb) 必须真的调用回调并拿到注册结果", () => {
  const runtime = createRuntime();
  const { registered } = mount(runtime);
  const { CAPTURE_SLOT } = runtime.exports.__internals;
  assert.equal(registered.length, 2, "页脚按钮 + 会话 id 探针");
  assert.equal(registered[0].options.name, SLOT_NAME);
  assert.equal(registered[1].options.name, CAPTURE_SLOT);
});

test("注册失败不得外抛：slots.register 抛错时 apply 静默返回", () => {
  const runtime = createRuntime();
  const ctx = {
    slots: {
      inject() {
        throw new Error("slot not available");
      },
    },
  };
  assert.doesNotThrow(() => runtime.exports.apply(ctx));
});

test("纪律：sidebarRight / sidebarRightTabs 绝不能写进 inject（会拖挂整个 boot）", () => {
  const runtime = createRuntime();
  assert.deepEqual([...runtime.exports.inject], ["slots"]);
  assert.ok(
    !/inject\s*=\s*\[[^\]]*sidebarRight/.test(BUNDLE_SOURCE),
    "声明一个可能不存在的服务会让 entry 停在 PENDING，DSH 会拒绝启动",
  );
});

/* ───────────────────────── 菜单：五个选项 ───────────────────────── */

test("菜单：默认收起只渲染主按钮，点击后恰好五个选项（顺序：右侧栏 → 系统浏览器 → 读右侧栏 → 读系统浏览器 → 自定义提示词）", () => {
  const runtime = createRuntime();
  const { entry } = mount(runtime);
  const view = createView(entry, { wide: true });
  const { OPTION_SIDEBAR_LABEL, OPTION_EXTERNAL_LABEL, OPTION_READ_SIDEBAR_LABEL, OPTION_READ_EXTERNAL_LABEL, DEFAULT_TEXTS } =
    runtime.exports.__internals;

  const collapsed = findButtons(view.render());
  assert.equal(collapsed.length, 1, "收起时不应渲染任何选项");
  assert.equal(collapsed[0].props["aria-haspopup"], "menu");
  assert.equal(collapsed[0].props["aria-expanded"], false);
  assert.equal(findMenuItems(collapsed).length, 0);

  collapsed[0].props.onClick();
  const expandedTree = view.render();
  const items = findMenuItems(expandedTree);
  assert.equal(items.length, 5);
  // 顺序是产品语义的一部分：两组「打开」在前，两组「读取」在后，最后是「自定义提示词」。
  // 悬停提示（aria-label）逐项与产物里的默认文案对号入座：措辞是随包定制的，不在这里硬编码。
  assert.equal(items[0].props["aria-label"], DEFAULT_TEXTS.sidebar);
  assert.equal(items[1].props["aria-label"], DEFAULT_TEXTS.external);
  assert.equal(items[2].props["aria-label"], DEFAULT_TEXTS.readSidebar);
  assert.equal(items[3].props["aria-label"], DEFAULT_TEXTS.readExternal);
  assert.equal(flatten(items[0]).includes(OPTION_SIDEBAR_LABEL), true);
  assert.equal(flatten(items[1]).includes(OPTION_EXTERNAL_LABEL), true);
  assert.equal(flatten(items[2]).includes(OPTION_READ_SIDEBAR_LABEL), true);
  assert.equal(flatten(items[3]).includes(OPTION_READ_EXTERNAL_LABEL), true);
  assert.equal(flatten(items[4]).includes("自定义提示词"), true);
  // 两组之间有一条纯装饰的分隔线
  const divider = findByRole(expandedTree, "separator");
  assert.ok(divider, "两组选项之间应有分隔线");
  assert.equal(divider.props["aria-hidden"], "true");
  // 没读过东西之前不该有那行可见提示
  assert.equal(findByRole(expandedTree, "note"), null, "默认不应渲染提示行");
  // 展开状态要能读出来
  const expandedToggle = findButtons(expandedTree).find((node) => node.props["aria-haspopup"] === "menu");
  assert.ok(expandedToggle, "展开后主按钮仍应在树上");
  assert.equal(expandedToggle.props["aria-expanded"], true);
  // 选项组有无障碍名字
  const menu = findMenuContainer(expandedTree);
  assert.equal(typeof menu.props["aria-label"], "string");
  assert.equal(menu.props.role, "menu");
});

test("菜单：选「右侧栏」时只调 openTab、不弹系统浏览器，且菜单收起", () => {
  const runtime = createRuntime();
  const sidebar = sidebarContext();
  const events = chooseWith(runtime, "sidebar", sidebar.ctx);

  // 注意：options 对象诞生在 vm 沙箱里（另一种 realm），所以逐字段断言，
  // 不用 deepEqual（跨 realm 的原型不同会被判为不等）。
  assert.equal(sidebar.opened.length, 1);
  assert.equal(sidebar.opened[0].kind, "browser");
  assert.equal(sidebar.opened[0].options.params.url, CHAT_URL);
  assert.equal(events.length, 0, "选了右侧栏就不该触发 window.open 或 <a>");
});

test("菜单：选「系统浏览器」时只走 window.open，绝不碰右侧栏", () => {
  const runtime = createRuntime();
  let sidebarTouched = false;
  const events = chooseWith(runtime, "external", {
    get(name) {
      if (name === "sidebarRightTabs") return { get: () => ({ id: "browser" }) };
      if (name === "sidebarRight") {
        sidebarTouched = true;
        return { openTab() {} };
      }
      return undefined;
    },
  });
  assert.equal(sidebarTouched, false, "明确选系统浏览器时不应去问右侧栏服务");
  assert.equal(events[0].kind, "window.open");
  assert.equal(events[0].args[0], CHAT_URL);
  assert.equal(events[0].args[1], "_blank");
});

test("菜单：右侧栏不可用时选「右侧栏」→ 仍打开系统浏览器，且不假装成功", () => {
  const runtime = createRuntime();
  const { entry } = mount(runtime);
  const view = createView(entry, { wide: true });
  view.render();
  findButtons(view.render())[0].props.onClick();
  findMenuItems(view.render())[0].props.onClick(); // 选「右侧栏」
  const tree = view.render();

  assert.equal(runtime.events[0].kind, "window.open", "应当退回系统浏览器");
  const status = statusTextOf(tree);
  assert.equal(status.includes("右侧栏不可用"), true, `播报应说明是退回来的：${status}`);
});

test("菜单：点一次展开、再点一次收起；Esc 也能收起", () => {
  const runtime = createRuntime();
  const { entry } = mount(runtime);
  const view = createView(entry, { wide: true });

  const toggle = () => findButtons(view.render())[0].props.onClick();
  toggle();
  assert.equal(findMenuItems(view.render()).length, 5);
  toggle();
  assert.equal(findMenuItems(view.render()).length, 0);

  toggle();
  assert.equal(findMenuItems(view.render()).length, 5);
  findActionContainer(view.render()).props.onKeyDown({ key: "Escape" });
  assert.equal(findMenuItems(view.render()).length, 0);
});

test("菜单（窄栏 56px 轨道）：五个选项只出图标，不带文案", () => {
  const runtime = createRuntime();
  const { entry } = mount(runtime);
  const view = createView(entry, { wide: false });
  const { OPTION_SIDEBAR_LABEL, OPTION_EXTERNAL_LABEL, OPTION_READ_SIDEBAR_LABEL, OPTION_READ_EXTERNAL_LABEL } =
    runtime.exports.__internals;

  findButtons(view.render())[0].props.onClick();
  const tree = view.render();
  const items = findMenuItems(tree);
  assert.equal(items.length, 5);
  const text = flatten(tree);
  assert.ok(!text.includes(OPTION_SIDEBAR_LABEL), "窄栏不应渲染选项文案");
  assert.ok(!text.includes(OPTION_EXTERNAL_LABEL), "窄栏不应渲染选项文案");
  assert.ok(!text.includes(OPTION_READ_SIDEBAR_LABEL), "窄栏不应渲染选项文案");
  assert.ok(!text.includes(OPTION_READ_EXTERNAL_LABEL), "窄栏不应渲染选项文案");
  assert.ok(!text.includes("DeepSeek 网页版"), "窄栏不应渲染主按钮文案");
  assert.equal(countType(tree, "svg"), 6, "主按钮 + 五个选项各一个图标");
  assert.equal(countStatusSpans(tree), 1, "状态位只有一个");
  // 窄栏下每个选项仍要被读屏器说清楚
  for (const item of items) assert.equal(typeof item.props["aria-label"], "string");
});

test("组件：窄栏只出图标，宽栏图标 + 文案，且带 title 与 aria-label", () => {
  const runtime = createRuntime();
  const { entry } = mount(runtime);
  const wide = createView(entry, { wide: true }).render();
  const narrow = createView(entry, { wide: false }).render();

  const button = findButton(wide);
  assert.equal(button.props.title.includes("chat.deepseek.com"), true);
  assert.equal(typeof button.props["aria-label"], "string");

  const wideText = flatten(wide);
  const narrowText = flatten(narrow);
  assert.match(wideText, /DeepSeek 网页版/);
  assert.ok(!narrowText.includes("DeepSeek 网页版"), "窄栏不应渲染文案");
  // 图标两条路都要有
  assert.equal(countType(wide, "svg"), 1);
  assert.equal(countType(narrow, "svg"), 1);
  // 无障碍状态位（role=status）两条路都要有
  assert.equal(countStatusSpans(wide), 1);
  assert.equal(countStatusSpans(narrow), 1);
  // 窄栏用 aria-label 说明主按钮
  assert.equal(findButton(narrow).props["aria-label"].includes("chat.deepseek.com"), true);
});

/* ───────────────── 选项五：自定义提示词（悬停文案） ───────────────── */

test("自定义提示词：默认就是产物里的常量（主按钮 + 四个选项的悬停文案）", () => {
  const runtime = createRuntime();
  const { entry } = mount(runtime);
  const view = createView(entry, { wide: true });
  const { TITLE, DEFAULT_TEXTS } = runtime.exports.__internals;

  const toggle = findButtons(view.render())[0];
  assert.equal(toggle.props.title, TITLE);
  toggle.props.onClick();
  const items = findMenuItems(view.render());
  assert.equal(items[0].props.title, DEFAULT_TEXTS.sidebar);
  assert.equal(items[1].props.title, DEFAULT_TEXTS.external);
  assert.equal(items[2].props.title, DEFAULT_TEXTS.readSidebar);
  assert.equal(items[3].props.title, DEFAULT_TEXTS.readExternal);
  assert.equal(typeof items[4].props.title, "string");
  assert.equal(items[4].props.title.includes("提示词"), true);
});

test("自定义提示词：面板里改完保存，悬停文案立刻换新并写进本机存储", () => {
  const runtime = createRuntime();
  const { entry } = mount(runtime);
  const view = createView(entry, { wide: true });
  const { TEXTS_KEY, TEXTS_SAVED, DEFAULT_TEXTS } = runtime.exports.__internals;

  findButtons(view.render())[0].props.onClick();
  findMenuItems(view.render())[4].props.onClick(); // 点「自定义提示词」
  let tree = view.render();
  const inputs = findInputs(tree);
  assert.equal(inputs.length, 5, "面板应有五格输入");
  assert.equal(inputs[0].props.value, DEFAULT_TEXTS.menu, "打开面板时应带出当前文案");

  inputs[0].props.onChange({ target: { value: "开 DeepSeek" } });
  inputs[2].props.onChange({ target: { value: "浏览器里打开" } });
  tree = view.render();
  // 改了草稿但没保存：已生效的文案不动
  assert.equal(findToggle(tree).props.title, DEFAULT_TEXTS.menu, "未保存前不应生效");

  findButtonByText(tree, "保存").props.onClick();
  tree = view.render();
  assert.equal(findToggle(tree).props.title, "开 DeepSeek");
  const items = findMenuItems(tree);
  assert.equal(items.length, 5, "保存后面板收起，回到选项列表");
  assert.equal(items[0].props.title, DEFAULT_TEXTS.sidebar, "没改的那几格保持原样");
  assert.equal(items[1].props.title, "浏览器里打开");
  assert.match(statusTextOf(tree), new RegExp(TEXTS_SAVED.slice(0, 4)));
  const saved = JSON.parse(runtime.store.get(TEXTS_KEY));
  assert.equal(saved.menu, "开 DeepSeek");
  assert.equal(saved.external, "浏览器里打开");

  // 再打开面板：带出的是刚保存的那份
  findMenuItems(tree)[4].props.onClick();
  assert.equal(findInputs(view.render())[0].props.value, "开 DeepSeek");
});

test("自定义提示词：本机存储里的坏数据一律退回默认文案，不抛错", () => {
  const probe = createRuntime();
  const { TEXTS_KEY, DEFAULT_TEXTS } = probe.exports.__internals;
  const cases = ["不是 JSON", "[]", '{"menu":""}', '{"menu":"   ","sidebar":123}', '{"unknown":"x"}', "null"];

  for (const raw of cases) {
    const runtime = createRuntime({ storage: new Map([[TEXTS_KEY, raw]]) });
    const { entry } = mount(runtime);
    const view = createView(entry, { wide: true });
    assert.equal(findButtons(view.render())[0].props.title, DEFAULT_TEXTS.menu, `坏数据 ${raw} 应退回默认`);
    findButtons(view.render())[0].props.onClick();
    const items = findMenuItems(view.render());
    assert.equal(items[0].props.title, DEFAULT_TEXTS.sidebar, `坏数据 ${raw} 应退回默认`);
    assert.equal(items[1].props.title, DEFAULT_TEXTS.external, `坏数据 ${raw} 应退回默认`);
  }
});

test("自定义提示词：点「恢复默认」清掉本机存储并回到默认文案", () => {
  const probe = createRuntime();
  const { TEXTS_KEY, DEFAULT_TEXTS, TEXTS_RESET } = probe.exports.__internals;
  const runtime = createRuntime({ storage: new Map([[TEXTS_KEY, JSON.stringify({ menu: "改过的" })]]) });
  const { entry } = mount(runtime);
  const view = createView(entry, { wide: true });

  assert.equal(findToggle(view.render()).props.title, "改过的", "先读到自定义的那份");
  findToggle(view.render()).props.onClick();
  findMenuItems(view.render())[4].props.onClick();
  findButtonByText(view.render(), "恢复默认").props.onClick();
  const tree = view.render();

  assert.equal(findToggle(tree).props.title, DEFAULT_TEXTS.menu);
  assert.equal(runtime.store.has(TEXTS_KEY), false, "自定义那份应被清掉");
  assert.match(statusTextOf(tree), new RegExp(TEXTS_RESET.slice(0, 4)));
});

test("自定义提示词：本机存储写不进去时，播报「没能存下来」而不是假装成功", () => {
  const runtime = createRuntime();
  const { TEXTS_SAVE_FAILED } = runtime.exports.__internals;
  runtime.window.localStorage.setItem = () => {
    throw new Error("QuotaExceededError");
  };
  const { entry } = mount(runtime);
  const view = createView(entry, { wide: true });

  findToggle(view.render()).props.onClick();
  findMenuItems(view.render())[4].props.onClick();
  const inputs = findInputs(view.render());
  inputs[0].props.onChange({ target: { value: "这次生效，重启就丢" } });
  findButtonByText(view.render(), "保存").props.onClick();
  const tree = view.render();

  assert.equal(findToggle(tree).props.title, "这次生效，重启就丢", "写不进去也应本次生效");
  assert.equal(statusTextOf(tree), TEXTS_SAVE_FAILED);
});

test("自定义提示词（窄栏）：只提示先把侧边栏拉宽，不进入面板", () => {
  const runtime = createRuntime();
  const { entry } = mount(runtime);
  const view = createView(entry, { wide: false });
  const { TEXTS_NARROW } = runtime.exports.__internals;

  findButtons(view.render())[0].props.onClick();
  findMenuItems(view.render())[4].props.onClick();
  const tree = view.render();

  assert.equal(findInputs(tree).length, 0, "窄栏不应进入编辑面板");
  assert.equal(findMenuItems(tree).length, 5, "仍应停在选项列表上");
  assert.equal(statusTextOf(tree), TEXTS_NARROW);
});

test("自定义提示词：Esc 或再点按钮收起时丢掉草稿，下次展开回到五个选项而不是半途的表单", () => {
  const runtime = createRuntime();
  const { entry } = mount(runtime);
  const view = createView(entry, { wide: true });
  const { DEFAULT_TEXTS, TEXTS_KEY } = runtime.exports.__internals;

  findToggle(view.render()).props.onClick();
  findMenuItems(view.render())[4].props.onClick();
  findInputs(view.render())[0].props.onChange({ target: { value: "半途而废" } });

  findActionContainer(view.render()).props.onKeyDown({ key: "Escape" });
  assert.equal(findMenuItems(view.render()).length, 0, "Esc 先收起菜单");
  assert.equal(runtime.store.has(TEXTS_KEY), false, "没点保存就不该写盘");

  findToggle(view.render()).props.onClick();
  const tree = view.render();
  assert.equal(findMenuItems(tree).length, 5, "再展开应回到五个选项");
  assert.equal(findInputs(tree).length, 0, "不应停在没保存完的表单上");
  assert.equal(findToggle(tree).props.title, DEFAULT_TEXTS.menu, "丢掉的草稿当然不该生效");

  // 再点一次主按钮收起，同样要把草稿忘掉
  findMenuItems(tree)[4].props.onClick();
  findInputs(view.render())[0].props.onChange({ target: { value: "又半途而废" } });
  findToggle(view.render()).props.onClick();
  findToggle(view.render()).props.onClick();
  const again = view.render();
  assert.equal(findMenuItems(again).length, 5);
  assert.equal(findInputs(again).length, 0);
});

/* ───────────────── 选项一：DSH 内部右侧栏的内嵌浏览器 ───────────────── */

test("右侧栏链：可用时返回 strategy='sidebar' 且只调一次 openTab", () => {
  const runtime = createRuntime();
  const sidebar = sidebarContext();
  const result = runtime.exports.__internals.openChat({
    ctx: sidebar.ctx,
    document: null,
    window: {},
  });
  assert.equal(result.opened, true);
  assert.equal(result.strategy, "sidebar");
  assert.equal(sidebar.opened.length, 1);
  assert.equal(sidebar.opened[0].options.params.url, CHAT_URL);
});

test("右侧栏链的回退：browser 这种页签没注册时，绝不碰 openTab，直接走系统浏览器", () => {
  const runtime = createRuntime();
  let sidebarTouched = false;
  // 用户点的是「在右侧边栏内打开」，但该 kind 不存在 → 只能退回系统浏览器
  const events = chooseWith(runtime, "sidebar", {
    get(name) {
      if (name === "sidebarRightTabs") return { get: () => undefined };
      if (name === "sidebarRight") {
        sidebarTouched = true;
        return { openTab() {} };
      }
      return undefined;
    },
  });
  assert.equal(sidebarTouched, false, "kind 未注册时不应调用 openTab（会显示空窗）");
  assert.equal(events[0].kind, "window.open");
  assert.equal(events[0].args[0], CHAT_URL);
});

test("右侧栏链的回退：openTab 抛错时，仍然照常打开系统浏览器", () => {
  const runtime = createRuntime();
  const events = chooseWith(
    runtime,
    "sidebar",
    sidebarContext({
      openTab() {
        throw new Error("URL 没通过地址栏校验");
      },
    }).ctx,
  );
  assert.equal(events.filter((event) => event.kind === "window.open").length, 1);
  assert.equal(events[0].args[0], CHAT_URL);
});

test("sidebarOpener：ctx 缺失 / 形状不对 / 服务抛错，一律安静地返回 null", () => {
  const { sidebarOpener } = createRuntime().exports.__internals;
  assert.equal(sidebarOpener(), null);
  assert.equal(sidebarOpener({ ctx: null }), null);
  assert.equal(sidebarOpener({ ctx: {} }), null);
  assert.equal(sidebarOpener({ ctx: { get: () => undefined } }), null);
  // tabs 在、但 browser 这种 kind 没注册
  assert.equal(
    sidebarOpener({ ctx: { get: (name) => (name === "sidebarRightTabs" ? { get: () => undefined } : { openTab() {} }) } }),
    null,
  );
  // tabs 在、sidebar 在，但 openTab 不是函数
  assert.equal(
    sidebarOpener({ ctx: { get: (name) => (name === "sidebarRightTabs" ? { get: () => ({}) } : { openTab: 1 }) } }),
    null,
  );
  // 服务访问本身抛错也要吃掉
  assert.equal(
    sidebarOpener({
      ctx: {
        get() {
          throw new Error("inactive context");
        },
      },
    }),
    null,
  );
});

test("sidebarOpener：直接读 ctx.sidebarRight 的旧式上下文同样识别", () => {
  const { sidebarOpener } = createRuntime().exports.__internals;
  const sidebar = { openTab() {} };
  const got = sidebarOpener({
    ctx: {
      sidebarRightTabs: { get: (kind) => (kind === "browser" ? {} : undefined) },
      sidebarRight: sidebar,
    },
  });
  assert.equal(got, sidebar);
});

test("statusFor：结果 → 播报，且「选了右侧栏却退回来」必须说清楚", () => {
  const { statusFor, STATUS_SIDEBAR, STATUS_EXTERNAL, STATUS_SIDEBAR_UNAVAILABLE, STATUS_FAILED } =
    createRuntime().exports.__internals;
  assert.equal(statusFor({ opened: true, strategy: "sidebar" }), STATUS_SIDEBAR);
  assert.equal(statusFor({ opened: true, strategy: "window.open" }), STATUS_EXTERNAL);
  assert.equal(statusFor({ opened: true, strategy: "protocol" }), STATUS_EXTERNAL);
  assert.equal(statusFor({ opened: true, strategy: "anchor" }), STATUS_EXTERNAL);
  // 用户点的是「右侧栏」，结果落到系统浏览器 → 播报要包含"不可用"
  assert.equal(statusFor({ opened: true, strategy: "window.open" }, "sidebar"), STATUS_SIDEBAR_UNAVAILABLE);
  assert.equal(statusFor({ opened: true, strategy: "anchor" }, "sidebar"), STATUS_SIDEBAR_UNAVAILABLE);
  // 即使是选了右侧栏，真拿到 sidebar 也还是"成功"
  assert.equal(statusFor({ opened: true, strategy: "sidebar" }, "sidebar"), STATUS_SIDEBAR);
  assert.equal(statusFor({ opened: false }, "sidebar"), STATUS_FAILED);
  assert.equal(statusFor({ opened: false }), STATUS_FAILED);
  assert.equal(statusFor(undefined), STATUS_FAILED);
});

/* ───────────────── 选项二：系统浏览器（Electron setWindowOpenHandler）───────────────── */

test("系统浏览器链：window.open(url, '_blank') 排第一", () => {
  const events = chooseWith(createRuntime(), "external");
  const first = events[0];
  assert.ok(first, "点击后没有任何动作");
  assert.equal(first.kind, "window.open");
  assert.equal(first.args[0], CHAT_URL);
  assert.equal(first.args[1], "_blank");
});

test("兜底链：window.open 被拦时走 deepseek-chat: 协议，再退化到 <a>", () => {
  // 两次 window.open 都拒绝（抛错 = 没有拿到窗口句柄），
  // 于是 ①→②→③ 必须依次走完，最后落到 <a target="_blank">。
  const events = chooseWith(
    createRuntime({
      open: () => {
        throw new Error("popup blocked");
      },
    }),
    "external",
  );

  const opens = events.filter((event) => event.kind === "window.open");
  assert.deepEqual(
    opens.map((event) => event.args[0]),
    [CHAT_URL, PROTOCOL_URL],
    "第二条 window.open 应是自定义协议",
  );
  const anchors = events.filter((event) => event.kind === "anchor-click");
  assert.equal(anchors.length, 1, "最后应有一次 <a target=_blank> 兜底");
  assert.equal(anchors[0].href, CHAT_URL);
  assert.equal(anchors[0].target, "_blank");
});

test("window.open 成功时不去碰自定义协议与 <a>", () => {
  const events = chooseWith(createRuntime(), "external");
  assert.equal(events.filter((event) => event.kind === "window.open").length, 1);
  assert.equal(events.filter((event) => event.kind === "anchor-click").length, 0);
});

test("window.open 直接抛错时也必须继续走完兜底链", () => {
  let calls = 0;
  const events = chooseWith(
    createRuntime({
      open: () => {
        calls += 1;
        throw new Error("blocked");
      },
    }),
    "external",
  );
  assert.equal(calls, 2, "两次 window.open 都应被尝试");
  assert.equal(events.filter((event) => event.kind === "anchor-click").length, 1);
});

test("四条路全不可用时：openExternalChat 如实返回 opened:false，且不抛错", () => {
  const runtime = createRuntime();
  // 全局也没有 window.open（真实环境里 sandbox/iframe 可能就是这样）
  delete runtime.sandbox.window.open;
  const result = runtime.exports.__internals.openExternalChat({ window: {}, document: null });
  assert.equal(result.opened, false);
  assert.equal(result.detail, "no-window");
});

test("自定义协议未注册（调用即抛错）时不能谎报成功", () => {
  const runtime = createRuntime();
  delete runtime.sandbox.window.open;
  const result = runtime.exports.__internals.openExternalChat({
    window: {},
    document: null,
    open(url) {
      if (url === PROTOCOL_URL) throw new Error("no registered handler");
      return null;
    },
  });
  assert.equal(result.opened, false);
});

test("自定义协议可用（调用不抛错、也没有窗口句柄）时报 protocol 成功", () => {
  const runtime = createRuntime();
  delete runtime.sandbox.window.open;
  const result = runtime.exports.__internals.openExternalChat({
    window: {},
    document: null,
    open: () => null,
  });
  assert.equal(result.opened, true);
  assert.equal(result.strategy, "protocol");
});

test("openChat 第一条路成功时不再动兜底路", () => {
  const runtime = createRuntime();
  const opened = [];
  const result = runtime.exports.__internals.openChat({
    document: {
      createElement() {
        throw new Error("不该走到 <a> 兜底");
      },
    },
    open: (url, target) => {
      opened.push([url, target]);
      return { closed: false };
    },
  });
  assert.equal(result.opened, true);
  assert.equal(result.strategy, "window.open");
  assert.deepEqual(opened, [[CHAT_URL, "_blank"]]);
});

/* ───────────────────────── 组件树小工具 ───────────────────────── */

/* ──────────────── 选项三 / 四：读取对话 → 发进当前主对话 ──────────────── */

test("读取链（右侧边栏）：内嵌页返回分享链接 + 正文 → 一条消息发进当前会话，并顺手复制链接", async () => {
  const runtime = createRuntime();
  const internals = runtime.exports.__internals;
  internals.setCapturedSessionId("session-1");
  const prompts = [];
  const webview = fakeWebview({ payload: guestPayload() });
  runtime.webviews.push(webview);

  const { after, events } = await chooseRead(runtime, "read-sidebar", {
    get: (name) => (name === "sessions" ? sessionsWithPrompt(prompts) : undefined),
  });

  assert.equal(webview.calls.length, 1, "只往内嵌页里注入一次脚本");
  assert.equal(webview.calls[0].gesture, true, "executeJavaScript 要带 userGesture（点「分享」需要）");
  assert.match(webview.calls[0].code, /分享/, "脚本里必须带点「分享」的启发式");
  assert.equal(prompts.length, 1);
  assert.equal(prompts[0].mode, "queue", "投递走 composer 同款的 queue 模式");
  assert.equal(prompts[0].parts.length, 1);
  assert.equal(prompts[0].parts[0].type, "text");
  const text = prompts[0].parts[0].text;
  assert.match(text, /https:\/\/chat\.deepseek\.com\/share\/abc123/, "分享链接要进消息");
  assert.match(text, /共产党宣言心得 - DeepSeek/, "页面标题要进消息");
  assert.match(text, /帮我总结一下共产党宣言/, "正文要进消息");
  assert.match(text, /读取右侧栏内对话/, "消息要说明来源是插件读的");
  assert.equal(runtime.clipboard.written[0], "https://chat.deepseek.com/share/abc123", "链接要同时进剪贴板");
  assert.match(statusTextOf(after), /已发送到当前对话/);
  assert.match(flatten(after), /已发送到当前对话/, "人也要能看见结果（不只是读屏器）");
  assert.equal(events.length, 0, "读取链不该碰 window.open");
});

test("读取链（右侧边栏）：侧边栏里没有内嵌页时如实播报，且不投递", async () => {
  const runtime = createRuntime();
  runtime.exports.__internals.setCapturedSessionId("session-1");
  const prompts = [];

  const { after } = await chooseRead(runtime, "read-sidebar", {
    get: (name) => (name === "sessions" ? sessionsWithPrompt(prompts) : undefined),
  });

  assert.equal(prompts.length, 0);
  assert.match(statusTextOf(after), /右侧边栏里没有 chat\.deepseek\.com/);
  assert.match(statusTextOf(after), /在右侧边栏内打开/, "要告诉用户先点哪个选项");
});

test("读取链（右侧边栏）：内嵌页不是 chat.deepseek.com 时播报地址，一个字节都不读", async () => {
  const runtime = createRuntime();
  runtime.exports.__internals.setCapturedSessionId("session-1");
  const webview = fakeWebview({ url: "https://example.com/other", payload: guestPayload() });
  runtime.webviews.push(webview);

  const { after } = await chooseRead(runtime, "read-sidebar", {
    get: (name) => (name === "sessions" ? sessionsWithPrompt([]) : undefined),
  });

  assert.equal(webview.calls.length, 0, "不是目标站点时不该执行脚本");
  assert.equal(runtime.clipboard.written.length, 0);
  assert.match(statusTextOf(after), /不是 chat\.deepseek\.com/);
  assert.match(statusTextOf(after), /example\.com/);
});

test("读取链（右侧边栏）：点不到「分享」但有正文 → 仍然投递，并说清原因与页面按钮清单", async () => {
  const runtime = createRuntime();
  runtime.exports.__internals.setCapturedSessionId("session-1");
  const prompts = [];
  runtime.webviews.push(
    fakeWebview({
      payload: guestPayload({ url: "", share: "no-share-button", buttons: ["编辑", "重命名", "删除"] }),
    }),
  );

  const { after } = await chooseRead(runtime, "read-sidebar", {
    get: (name) => (name === "sessions" ? sessionsWithPrompt(prompts) : undefined),
  });

  assert.equal(prompts.length, 1, "有正文就照投，不因为没链接而放弃");
  const text = prompts[0].parts[0].text;
  assert.match(text, /没拿到分享链接/);
  assert.match(text, /页面上没找到「分享」按钮/);
  assert.match(text, /编辑 \/ 重命名 \/ 删除/, "按钮清单是下一次改启发式的线索");
  assert.equal(runtime.clipboard.written.length, 0, "没有链接就没什么可复制的");
  assert.match(statusTextOf(after), /已发送到当前对话/);
});

test("读取链（右侧边栏）：既没链接也没正文时，播报里带诊断为下一次改启发式留线索", async () => {
  const runtime = createRuntime();
  runtime.exports.__internals.setCapturedSessionId("session-1");
  runtime.webviews.push(
    fakeWebview({ payload: guestPayload({ url: "", text: "", share: "clicked", buttons: ["分享", "复制"] }) }),
  );

  const { after } = await chooseRead(runtime, "read-sidebar", {
    get: (name) => (name === "sessions" ? sessionsWithPrompt([]) : undefined),
  });

  const status = statusTextOf(after);
  assert.match(status, /读取失败/);
  assert.match(status, /点了「分享」但没等到链接/);
  assert.match(status, /页面上的候选控件：分享 \/ 复制/);
});

test("读取链（右侧边栏）：载荷解析不了 / executeJavaScript 抛错，都要如实播报而不是静默", async () => {
  const runtime = createRuntime();
  runtime.exports.__internals.setCapturedSessionId("session-1");
  const extra = { get: (name) => (name === "sessions" ? sessionsWithPrompt([]) : undefined) };

  runtime.webviews.push(fakeWebview({ payload: "这不是 JSON" }));
  const bad = await chooseRead(runtime, "read-sidebar", extra);
  assert.match(statusTextOf(bad.after), /无法解析/);

  runtime.webviews.length = 0;
  runtime.webviews.push(fakeWebview({ error: new Error("guest 已销毁") }));
  const boom = await chooseRead(runtime, "read-sidebar", extra);
  assert.match(statusTextOf(boom.after), /读取失败：guest 已销毁/);
});

test("读取链：还没拿到当前会话 id 时绝不投递，并说清怎么让插件拿到它", async () => {
  const runtime = createRuntime();
  const prompts = [];
  runtime.webviews.push(fakeWebview({ payload: guestPayload() }));

  const { after } = await chooseRead(runtime, "read-sidebar", {
    get: (name) => (name === "sessions" ? sessionsWithPrompt(prompts) : undefined),
  });

  assert.equal(prompts.length, 0);
  assert.match(statusTextOf(after), /还没拿到当前会话 id/);
});

test("读取链：拿不到 sessions 服务 / 会话没有 prompt 接口 / 服务返回失败，三种都要说清楚", async () => {
  const runtime = createRuntime();
  runtime.webviews.push(fakeWebview({ payload: guestPayload() }));

  // 1) 没有 sessions 服务
  runtime.exports.__internals.setCapturedSessionId("session-1");
  const noService = await chooseRead(runtime, "read-sidebar", { get: () => undefined });
  assert.match(statusTextOf(noService.after), /拿不到 sessions 服务/);

  // 2) 有 sessions，但 binding 与 retain 都给不出 prompt
  const noPrompt = await chooseRead(runtime, "read-sidebar", {
    get: (name) =>
      name === "sessions" ? { binding: () => null, retain: () => ({ binding: { session: {} }, release() {} }) } : undefined,
  });
  assert.match(statusTextOf(noPrompt.after), /没有可用的 prompt 接口/);

  // 3) prompt 返回 ok:false（例如队列已满）
  const prompts = [];
  const failed = await chooseRead(runtime, "read-sidebar", {
    get: (name) =>
      name === "sessions"
        ? sessionsWithPrompt(prompts, { ok: false, error: new Error("队列已满") })
        : undefined,
  });
  assert.equal(prompts.length, 1);
  assert.match(statusTextOf(failed.after), /读取失败：队列已满/);
});

test("读取链：同一份内容 15 秒内只发一次（防连点重复刷屏）", async () => {
  const runtime = createRuntime();
  runtime.exports.__internals.setCapturedSessionId("session-1");
  const prompts = [];
  const extra = { get: (name) => (name === "sessions" ? sessionsWithPrompt(prompts) : undefined) };
  runtime.webviews.push(fakeWebview({ payload: guestPayload() }));

  const first = await chooseRead(runtime, "read-sidebar", extra);
  assert.match(statusTextOf(first.after), /已发送到当前对话/);

  const second = await chooseRead(runtime, "read-sidebar", extra);
  assert.equal(prompts.length, 1, "第二次不该再发一遍");
  assert.match(statusTextOf(second.after), /刚刚已经发送过同一份内容/);
});

test("读取链：读取进行中两个读取选项都禁用（防连点），结束后恢复", async () => {
  const runtime = createRuntime();
  runtime.exports.__internals.setCapturedSessionId("session-1");
  runtime.webviews.push(fakeWebview({ payload: guestPayload() }));

  const { tree, after, items } = await chooseRead(runtime, "read-sidebar", {
    get: (name) => (name === "sessions" ? sessionsWithPrompt([]) : undefined),
  });

  const during = findMenuItems(tree);
  assert.equal(
    during[2].props.disabled,
    true,
    `读取中应禁用（status=${JSON.stringify(statusTextOf(tree))} disabled=${JSON.stringify(during.map((node) => node.props.disabled))}）`,
  );
  assert.equal(during[3].props.disabled, true, "读取中应禁用");
  assert.equal(during[2].props["aria-disabled"], true);
  assert.match(statusTextOf(tree), /正在读取/);
  assert.equal(during[0].props.disabled, false, "「打开」两个选项不受影响");

  const settled = findMenuItems(after);
  assert.equal(settled[2].props.disabled, false, "结束后要恢复可点");
  assert.equal(settled[3].props.disabled, false);
  assert.equal(items[2].props.disabled, false);
});

test("内嵌页脚本：正文优先取自页面自己的 IndexedDB 缓存 —— 不要 token、不点按钮", async () => {
  const sid = "ffe0d5b9";
  const href = `https://chat.deepseek.com/a/chat/s/${sid}`;
  const cached = {
    data: historyEnvelope({
      title: "缓存里的标题",
      messages: [
        { message_id: 1, role: "USER", fragments: [{ type: "REQUEST", content: "缓存里的问题" }] },
        { message_id: 2, role: "ASSISTANT", fragments: [{ type: "RESPONSE", content: "缓存里的回答" }] },
      ],
    }),
    frontendVersion: 42,
  };
  const { payload, calls } = await runGuestScript({
    href,
    bodyText: "页面正文兜底",
    indexedDB: fakeIndexedDB([[sid, cached]]),
    fetch: apiRouter([["/api/v0/share/create", apiOk(shareEnvelope({ shareId: "CacheShare9" }))]]),
  });

  assert.equal(payload.source, "cache", `正文应当来自页面缓存：${payload.source}`);
  assert.match(payload.api, /页面自己的缓存（2 条）/);
  assert.match(payload.text, /缓存里的问题/);
  assert.match(payload.text, /缓存里的回答/);
  assert.match(payload.title, /缓存里的标题/);
  assert.equal(payload.url, "https://chat.deepseek.com/share/CacheShare9");
  assert.equal(
    calls.filter((call) => call.path.includes("history_messages")).length,
    0,
    "缓存命中就不该再打接口",
  );
});

test("接口请求头：补上 x-client-bundle-id 与时区「秒」，URL 里不再拼字面量 null", async () => {
  const messages = [
    { message_id: 1, role: "USER", fragments: [{ type: "REQUEST", content: "问题" }] },
    { message_id: 2, role: "ASSISTANT", fragments: [{ type: "RESPONSE", content: "回答" }] },
  ];
  const { payload, calls } = await runGuestScript({
    token: "tk-headers",
    indexedDB: fakeIndexedDB([]),
    fetch: apiRouter([
      ["/api/v0/chat/history_messages", apiOk(historyEnvelope({ messages }))],
      ["/api/v0/share/create", apiOk(shareEnvelope({ shareId: "HeaderShare1" }))],
    ]),
  });

  const history = calls.find((call) => call.path.includes("history_messages"));
  assert.ok(history, "缓存是空的时候要退回接口");
  assert.equal(payload.source, "api");
  assert.ok(!history.path.includes("null"), `URL 里不该出现字面量 null：${history.path}`);
  assert.ok(!history.path.includes("cache_version"), "没有缓存版本号时不该带 cache_version");
  assert.equal(history.init.headers["x-client-bundle-id"], "com.deepseek.chat");
  assert.equal(history.init.headers["x-client-platform"], "web");
  assert.equal(history.init.headers["x-client-version"], "2.5.0");
  assert.equal(history.init.headers["x-client-locale"], "zh_CN");
  assert.equal(
    history.init.headers["x-client-timezone-offset"],
    String(-new Date().getTimezoneOffset() * 60),
    "时区偏移是秒（东八区 28800），不是小时",
  );
  assert.equal(payload.url, "https://chat.deepseek.com/share/HeaderShare1");
});

test("读取链（系统浏览器）：剪贴板里是本机路径时不当正文收，如实提示去复制链接", async () => {
  const runtime = createRuntime();
  runtime.exports.__internals.setCapturedSessionId("session-1");
  const prompts = [];
  runtime.clipboard.text = "D:/应用/DeepSeek/插件/dsh-deepseek-chat-1.0.0/dsh-deepseek-chat";

  const { after } = await chooseRead(runtime, "read-external", {
    get: (name) => (name === "sessions" ? sessionsWithPrompt(prompts) : undefined),
  });

  assert.match(statusTextOf(after), /剪贴板里没有分享链接/);
  assert.equal(prompts.length, 0, "本机路径不该被当正文投递");
});

test("读取链（系统浏览器）：只有链接、右侧栏又有内嵌页 → 借它把正文取回来", async () => {
  const runtime = createRuntime();
  runtime.exports.__internals.setCapturedSessionId("session-1");
  const prompts = [];
  runtime.clipboard.text = "https://chat.deepseek.com/share/onlylink99";
  runtime.webviews.push(
    fakeWebview({
      url: "https://chat.deepseek.com/share/onlylink99",
      payload: JSON.stringify({
        ok: true,
        url: "https://chat.deepseek.com/share/onlylink99",
        title: "只有链接的对话",
        text: "【我】\n问题\n\n【DeepSeek】\n回答",
        api: "正文取自分享接口（2 条）",
      }),
    }),
  );

  const { after } = await chooseRead(runtime, "read-external", {
    get: (name) => (name === "sessions" ? sessionsWithPrompt(prompts) : undefined),
  });

  const webview = runtime.webviews[0];
  assert.equal(webview.calls.length, 1, "只该借内嵌页发一次同源请求");
  assert.match(webview.calls[0].code, /"shareId":"onlylink99"/, "分享 id 要当参数递进脚本");
  assert.equal(prompts.length, 1);
  const text = prompts[0].parts[0].text;
  assert.match(text, /https:\/\/chat\.deepseek\.com\/share\/onlylink99/);
  assert.match(text, /回答/, "正文要一起带上");
  assert.match(text, /正文是借右侧栏那个页面取回来的/);
  assert.match(text, /只有链接的对话/, "标题也一起带上");
  assert.match(statusTextOf(after), /已发送到当前对话/);
});

test("读取链（系统浏览器）：只有链接、右侧栏没有内嵌页 → 只发链接，并如实说没带正文", async () => {
  const runtime = createRuntime();
  runtime.exports.__internals.setCapturedSessionId("session-1");
  const prompts = [];
  runtime.clipboard.text = "https://chat.deepseek.com/share/nowebview12";

  const { after } = await chooseRead(runtime, "read-external", {
    get: (name) => (name === "sessions" ? sessionsWithPrompt(prompts) : undefined),
  });

  assert.equal(prompts.length, 1, "链接本身还是要投递的");
  const text = prompts[0].parts[0].text;
  assert.match(text, /https:\/\/chat\.deepseek\.com\/share\/nowebview12/);
  assert.match(text, /没带正文/, "拿不到正文就必须如实说");
  assert.match(text, /在右侧边栏内打开/, "顺手告诉用户怎么把正文也取回来");
  assert.match(statusTextOf(after), /已发送到当前对话/);
});

test("内嵌页脚本：按用户实测的三下点 —— 分享图标 → 创建分享链接 → 创建并复制", async () => {
  const shareUrl = "https://chat.deepseek.com/share/ThreeStep1";
  const expose = {};
  const elements = [];
  const copyButton = domNode("div", {
    text: "创建并复制",
    cls: "ds-button ds-button--primary",
    onClick() {
      Promise.resolve(expose.navigator.clipboard.writeText(shareUrl)).then(
        () => {},
        () => {},
      );
    },
  });
  const createButton = domNode("div", {
    text: "创建分享链接",
    cls: "ds-button ds-button--primary",
    onClick() {
      elements.push(copyButton);
    },
  });
  const shareButton = domNode("button", {
    attrs: { "aria-label": "分享" },
    onClick() {
      elements.push(createButton);
    },
  });
  elements.push(shareButton, domNode("div", { text: "会话内容", cls: "message" }));

  const { payload, clipWrites } = await runGuestScript({ elements, expose, bodyText: "会话正文" });

  assert.equal(payload.url, shareUrl, JSON.stringify(payload));
  assert.equal(payload.share, "captured", `链接该由第三步的复制接住：${payload.share}`);
  assert.ok(clipWrites.includes(shareUrl), `第三步「创建并复制」要把链接写进剪贴板：${JSON.stringify(clipWrites)}`);
});

test("读取链（系统浏览器）：剪贴板只有链接时，插件自己请右侧栏把这个分享页打开再取回正文", async () => {
  const runtime = createRuntime();
  const internals = runtime.exports.__internals;
  internals.setCapturedSessionId("session-1");
  const prompts = [];
  runtime.clipboard.text = "https://chat.deepseek.com/share/onlylink99";

  const opened = [];
  const view = fakeWebview({
    url: "https://chat.deepseek.com/share/onlylink99",
    payload: guestPayload({
      url: "https://chat.deepseek.com/share/onlylink99",
      title: "自动打开的分享页",
      text: "【我】这是分享里的正文",
      source: "share",
    }),
  });
  const extra = {
    get: (name) => {
      if (name === "sessions") return sessionsWithPrompt(prompts);
      if (name === "sidebarRightTabs") return { get: (kind) => (kind === "browser" ? { id: "browser" } : undefined) };
      if (name === "sidebarRight") {
        return {
          openTab(kind, options) {
            opened.push({ kind, options });
            /* 右侧栏开好了 → DOM 里就出现那个 webview（脚本下一拍就能看到）。 */
            runtime.webviews.push(view);
          },
        };
      }
      return undefined;
    },
  };

  const result = await chooseRead(runtime, "read-external", extra);
  await new Promise((resolve) => setTimeout(resolve, 40));
  const after = materialize(result.view.render());

  assert.equal(opened.length, 1, "应该请右侧栏打开这个分享页，而不是让用户自己去开");
  assert.equal(opened[0].kind, "browser");
  assert.equal(opened[0].options.params.url, "https://chat.deepseek.com/share/onlylink99");
  assert.equal(prompts.length, 1);
  const text = prompts[0].parts[0].text;
  assert.match(text, /https:\/\/chat\.deepseek\.com\/share\/onlylink99/);
  assert.match(text, /这是分享里的正文/);
  assert.match(text, /插件已在右侧栏打开这个分享页/);
  assert.match(statusTextOf(after), /已发送到当前对话/);
});

test("读取链（系统浏览器）：借不到右侧栏时，只投递链接并说清怎么办", async () => {
  const runtime = createRuntime();
  const internals = runtime.exports.__internals;
  internals.setCapturedSessionId("session-1");
  internals.setShareGuestWait(150);
  const prompts = [];
  runtime.clipboard.text = "https://chat.deepseek.com/share/nolink77";

  const result = await chooseRead(runtime, "read-external", {
    get: (name) => (name === "sessions" ? sessionsWithPrompt(prompts) : undefined),
  });
  await new Promise((resolve) => setTimeout(resolve, 300));

  assert.equal(prompts.length, 1, "链接还是要投递的");
  const text = prompts[0].parts[0].text;
  assert.match(text, /https:\/\/chat\.deepseek\.com\/share\/nolink77/);
  assert.match(text, /没能借到右侧栏那个页面/);
});

test("读取链（系统浏览器）：剪贴板里是分享链接 → 拆成链接 + 正文发进当前会话", async () => {
  const runtime = createRuntime();
  const internals = runtime.exports.__internals;
  internals.setCapturedSessionId("session-1");
  const prompts = [];
  runtime.clipboard.text =
    "https://chat.deepseek.com/share/xyz789 https://chat.deepseek.com/a/chat/s/9\n助手：这是正文的一段。";

  const { after } = await chooseRead(runtime, "read-external", {
    get: (name) => (name === "sessions" ? sessionsWithPrompt(prompts) : undefined),
  });

  assert.equal(prompts.length, 1);
  const text = prompts[0].parts[0].text;
  assert.match(text, /https:\/\/chat\.deepseek\.com\/share\/xyz789/);
  assert.match(text, /这是正文的一段/);
  assert.match(text, /读取系统浏览器对话/);
  assert.match(statusTextOf(after), /已发送到当前对话/);
});

test("读取链（系统浏览器）：剪贴板空 / 不是分享链接 / 太短，三种都不投递", async () => {
  const runtime = createRuntime();
  const internals = runtime.exports.__internals;
  internals.setCapturedSessionId("session-1");
  const prompts = [];
  const extra = { get: (name) => (name === "sessions" ? sessionsWithPrompt(prompts) : undefined) };

  const empty = await chooseRead(runtime, "read-external", extra);
  assert.match(statusTextOf(empty.after), /剪贴板是空的/);

  runtime.clipboard.text = "https://chat.deepseek.com/a/chat/s/9";
  const notShare = await chooseRead(runtime, "read-external", extra);
  assert.match(statusTextOf(notShare.after), /不是分享链接/);

  runtime.clipboard.text = "太短";
  const short = await chooseRead(runtime, "read-external", extra);
  assert.match(statusTextOf(short.after), /剪贴板内容太短/);

  assert.equal(prompts.length, 0, "三种情况都不该投递");
});

test("读取链（系统浏览器）：剪贴板权限被拒（readText 抛错）时按空处理，不抛错", async () => {
  const runtime = createRuntime();
  runtime.exports.__internals.setCapturedSessionId("session-1");
  const clipboard = runtime.sandbox.navigator.clipboard;
  clipboard.readText = () => Promise.reject(new Error("permission denied"));

  const { after } = await chooseRead(runtime, "read-external", {
    get: (name) => (name === "sessions" ? sessionsWithPrompt([]) : undefined),
  });

  assert.match(statusTextOf(after), /剪贴板是空的/);
});

test("会话 id 探针：注册在 conversation.input.overlay，渲染 null，并把 sessionId 记下来", () => {
  const runtime = createRuntime();
  const { registered } = mount(runtime);
  const { CAPTURE_SLOT, CAPTURE_ID, capturedSessionId } = runtime.exports.__internals;
  const probe = registered[1];

  assert.equal(probe.options.name, CAPTURE_SLOT);
  assert.equal(probe.options.id, CAPTURE_ID);
  assert.equal(capturedSessionId(), null, "初始没有会话 id");
  assert.equal(probe.component({ sessionId: "abc-123" }), null, "探针不许渲染任何可见内容");
  assert.equal(capturedSessionId(), "abc-123");
  assert.equal(probe.component({}), null, "没有 sessionId 也不能抛错");
  assert.equal(capturedSessionId(), "abc-123", "没有新 id 时保留上一次的值");
});

test("读取链小工具：载荷解析 / 剪贴板 / webview 地址 / 选择器挑捡的边界情形", () => {
  const runtime = createRuntime();
  const internals = runtime.exports.__internals;

  assert.equal(internals.parseGuestPayload(null), null);
  assert.equal(internals.parseGuestPayload("垃圾内容"), null);
  assert.equal(internals.parseGuestPayload('"只是一个字符串"'), null, "JSON 里非对象也算解析失败");
  assert.equal(internals.parseGuestPayload('{"ok":true}').ok, true);
  const object = { ok: true };
  assert.equal(internals.parseGuestPayload(object), object, "对象直接透传");

  assert.equal(internals.webviewUrl({ getURL: () => "https://a/b" }), "https://a/b");
  assert.equal(
    internals.webviewUrl({
      getURL: () => {
        throw new Error("guest 还没就绪");
      },
      getAttribute: (name) => (name === "src" ? "https://fallback/c" : null),
    }),
    "https://fallback/c",
    "getURL 抛错时退到 src",
  );
  assert.equal(internals.webviewUrl(null), "");

  assert.equal(internals.clip("abcdef", 3), "abc\n…（已截断，原文共 6 字）");
  assert.equal(internals.clip(null, 10), "");

  assert.equal(internals.describeError(new Error("boom")), "boom");
  assert.equal(internals.describeError("字符串错误"), "字符串错误");
  assert.equal(internals.describeError(null), "未知错误");

  assert.equal(internals.pickSidebarWebview().status, "none", "没有 webview 元素时返回 none");
  runtime.webviews.push(fakeWebview({ url: "https://example.com/x" }));
  assert.equal(internals.pickSidebarWebview().status, "other");
  assert.equal(internals.pickSidebarWebview().url, "https://example.com/x");
  runtime.webviews.push(fakeWebview({ url: "https://chat.deepseek.com/a/chat/s/1" }));
  const picked = internals.pickSidebarWebview();
  assert.equal(picked.status, "match", "同时存在多个 webview 时挑 chat.deepseek.com 那个");
  assert.equal(picked.url, "https://chat.deepseek.com/a/chat/s/1");
});

test("读取链：投递消息的形状稳定（分隔线 / 截断 / 来源前缀）", () => {
  const runtime = createRuntime();
  const internals = runtime.exports.__internals;
  const long = "正".repeat(70000);
  const message = internals.buildMessage("read-sidebar", { url: "https://chat.deepseek.com/share/a", text: internals.clip(long, internals.MESSAGE_TEXT_LIMIT) });

  assert.match(message, /^【插件·读取右侧栏内对话】/);
  assert.match(message, /分享链接：https:\/\/chat\.deepseek\.com\/share\/a/);
  assert.match(message, /已截断/);
  assert.equal(message.includes(long), false, "超长正文必须被截断，不能把整个会话撑爆");
  assert.ok(message.length < internals.MESSAGE_TEXT_LIMIT + 2000, `消息不该远超上限：${message.length}`);
});

/* ── 内嵌页脚本（readGuestScript）真的跑起来 ─────────────────────────────
   这段脚本是整条链里唯一"在别的进程里运行"的部分，也是唯一没法用假 webview
   糊弄过去的：真机上它第一次就报「页面上没找到「分享」按钮」。所以这里搭一个
   最小 DOM，把脚本对着它真跑一遍，覆盖几种真实的按钮形态。 */

/** 假 DOM 元素：够用就行（tag/text/aria/title/testid/class/可见性/点击）。 */
function domNode(tag, { text = "", attrs = {}, cls = "", visible = true, onClick = null } = {}) {
  const node = {
    tagName: String(tag).toUpperCase(),
    textContent: text,
    className: cls,
    offsetWidth: visible ? 12 : 0,
    offsetHeight: visible ? 12 : 0,
    _attrs: { ...attrs },
    getAttribute(name) {
      return name in node._attrs ? node._attrs[name] : null;
    },
    getClientRects() {
      return visible ? [{}] : [];
    },
    scrollIntoView() {},
    dispatchEvent(event) {
      if (String(event?.type || "") === "click" && onClick) onClick(node);
      return true;
    },
    click() {
      if (onClick) onClick(node);
    },
  };
  return node;
}

/** 把 CSS 选择器简化到脚本实际用到的那几种。 */
function domMatches(node, selector) {
  const spec = String(selector).trim();
  if (!spec) return false;
  const tag = node.tagName.toLowerCase();
  const bracket = spec.indexOf("[");
  const tagPart = bracket < 0 ? spec : spec.slice(0, bracket);
  if (tagPart && tagPart !== tag) return false;
  if (bracket < 0) return Boolean(tagPart);
  const inner = spec.slice(bracket + 1, spec.lastIndexOf("]"));
  const eq = inner.indexOf("=");
  const name = (eq < 0 ? inner : inner.slice(0, eq)).replace(/[*^$]$/, "");
  const op = eq < 0 ? "" : inner[eq - 1];
  const raw = eq < 0 ? "" : inner.slice(eq + 1).replace(/^["']|["']$/g, "");
  const actual = name === "class" ? String(node.className || "") : String(node.getAttribute(name) || "");
  if (eq < 0) return name === "class" ? Boolean(actual) : actual !== "";
  if (!actual) return false;
  if (op === "*") return actual.includes(raw);
  if (op === "^") return actual.startsWith(raw);
  if (op === "$") return actual.endsWith(raw);
  return actual === raw;
}

/** 脚本运行环境：document/location/window/MouseEvent/setTimeout 都是假的或宿主的。 */
async function runGuestScript({
  elements = [],
  bodyText = "",
  title = "共产党宣言心得 - DeepSeek",
  href = "https://chat.deepseek.com/a/chat/s/ffe0d5b9",
  token = null,
  tokenRaw = undefined,
  sessionTokenRaw = undefined,
  fetch: fetchImpl = null,
  clipboard: clipboardImpl = null,
  /** 传一个假 IndexedDB（见 fakeIndexedDB）就能测「正文取自页面自己的缓存」那条路。 */
  indexedDB = null,
  /** 传一个空对象进来，脚本装好钩子后会把「内嵌页自己的 window.fetch / navigator」放进去，
   *  用例就能在脚本跑到一半时冒充页面自己发请求、自己写剪贴板。 */
  expose = null,
  /** 宿主递给脚本的参数（选项四只拿到分享链接时，会把分享 id 这样塞进来）。 */
  args = {},
} = {}) {
  const runtime = createRuntime();
  const code = `(${runtime.exports.__internals.readGuestScript.toString()})(${JSON.stringify(args)})`;
  const body = { innerText: bodyText };
  const document = {
    body,
    title,
    querySelectorAll(selector) {
      const parts = String(selector).split(",");
      return elements.filter((node) => parts.some((part) => domMatches(node, part)));
    },
  };
  class FakeMouseEvent {
    constructor(type, init) {
      this.type = type;
      Object.assign(this, init || {});
    }
  }
  const store = new Map();
  if (tokenRaw !== undefined) store.set("userToken", String(tokenRaw));
  else if (token !== null) store.set("userToken", JSON.stringify({ value: token, __version: "0" }));
  const session = new Map();
  if (sessionTokenRaw !== undefined) session.set("userToken", String(sessionTokenRaw));
  const clipWrites = [];
  const clipboard = {
    writeText(text) {
      clipWrites.push(String(text));
      if (clipboardImpl && typeof clipboardImpl.writeText === "function") return clipboardImpl.writeText(String(text));
      return Promise.resolve(true);
    },
  };
  const navigator = { language: "zh-CN", clipboard };
  if (expose) {
    expose.navigator = navigator;
    expose.window = null;
  }
  const memory = (map) => ({
    getItem: (key) => (map.has(key) ? map.get(key) : null),
    setItem: (key, value) => map.set(key, String(value)),
    removeItem: (key) => map.delete(key),
  });
  const calls = [];
  const windowLike = { localStorage: memory(store), sessionStorage: memory(session) };
  if (indexedDB) windowLike.indexedDB = indexedDB;
  if (typeof fetchImpl === "function") {
    windowLike.fetch = (path, init) => {
      calls.push({ path: String(path), init: init || {} });
      if (expose) expose.guestFetch = windowLike.fetch;
      return Promise.resolve(fetchImpl(String(path), init || {}));
    };
  }
  const raw = await vm.runInNewContext(
    code,
    {
      document,
      location: { href, pathname: new URL(href).pathname },
      window: windowLike,
      navigator,
      JSON,
      Promise,
      setTimeout,
      clearTimeout,
      MouseEvent: FakeMouseEvent,
      console,
    },
    { timeout: 20000 },
  );
  return { payload: JSON.parse(raw), body, elements, calls, store, session, clipWrites, window: windowLike, navigator };
}

/** 网页版接口的假应答：形状与 bundle 里一致（两层信封）。clone() 是给钩子嗅探用的。 */
function apiOk(json, status = 200) {
  return {
    status,
    json: () => Promise.resolve(json),
    clone() {
      return apiOk(json, status);
    },
  };
}
function historyEnvelope({ title = "共产党宣言心得", messages = [] } = {}) {
  return {
    code: 0,
    msg: "",
    data: { biz_code: 0, biz_msg: "", biz_data: { chat_session: { id: "s1", title }, chat_messages: messages } },
  };
}
function shareEnvelope({ shareId = "ApiShare123", bizCode = 0, bizMsg = "" } = {}) {
  return {
    code: 0,
    msg: "",
    data: { biz_code: bizCode, biz_msg: bizMsg, biz_data: bizCode === 0 ? { share_id: shareId } : {} },
  };
}
/**
 * `/api/v0/share/list` 的假应答：脚本靠它验明「这条分享链接是不是当前这个会话的」——
 * 用户实测的串台场景（在右侧栏换成另一个对话，读回来的还是上一个对话的链接）就靠这条路由复现。
 */
function shareListEnvelope(entries = []) {
  return {
    code: 0,
    msg: "",
    data: {
      biz_code: 0,
      biz_msg: "",
      biz_data: {
        shares: entries.map((pair) => ({ share_id: pair[0], chat_session_id: pair[1], hint: "" })),
      },
    },
  };
}
/** 一条分享列表路由，省得每个用例手写形状。 */
function shareListRoute(entries = []) {
  return ["/api/v0/share/list", apiOk(shareListEnvelope(entries))];
}
/** 按路径分发假 fetch；没有对应路由就当一个失败的请求。 */
function apiRouter(routes) {
  return (path) => {
    for (const [needle, answer] of routes) {
      if (String(path).includes(needle)) return typeof answer === "function" ? answer(String(path)) : answer;
    }
    return Promise.reject(new Error("测试没有为这个路径准备应答：" + path));
  };
}

/**
 * 假 IndexedDB：只支持脚本真正用到的那几步 ——
 * open(名字, 1) → 事务 → objectStore → getAllKeys()/getAll() → oncomplete。
 * `entries` 是 `[键, 值]` 对，跟网页版缓存的 `{key, data, frontendVersion}` 一一对应。
 */
function fakeIndexedDB(entries = []) {
  const keys = entries.map((pair) => pair[0]);
  const values = entries.map((pair) => pair[1]);
  const store = {
    getAllKeys() {
      const request = { result: keys.slice(), onsuccess: null, onerror: null };
      setTimeout(() => request.onsuccess && request.onsuccess(), 0);
      return request;
    },
    getAll() {
      const request = { result: values.slice(), onsuccess: null, onerror: null };
      setTimeout(() => request.onsuccess && request.onsuccess(), 0);
      return request;
    },
  };
  const db = {
    objectStoreNames: { contains: () => true },
    createObjectStore: () => store,
    transaction() {
      const tx = { oncomplete: null, onerror: null, onabort: null, objectStore: () => store };
      /* 与真家伙一致：事务在所有请求之后才 complete（留给 getAllKeys/getAll 的 onsuccess 先跑）。 */
      setTimeout(() => setTimeout(() => tx.oncomplete && tx.oncomplete(), 0), 0);
      return tx;
    },
    close() {},
  };
  return {
    open(name) {
      assert.equal(name, "deepseek-chat", "缓存库名必须与网页版一致，否则读不到正文");
      const request = { result: db, error: null, onsuccess: null, onerror: null, onblocked: null };
      setTimeout(() => request.onsuccess && request.onsuccess(), 0);
      return request;
    },
  };
}

test("内嵌页脚本：分享入口是个只有 aria-label 的图标按钮时，也要点得到并拿到链接", async () => {
  const shareUrl = "https://chat.deepseek.com/share/AbC-123_xyz";
  const elements = [];
  const shareButton = domNode("button", {
    cls: "ds-icon-button ds-share-button",
    attrs: { "aria-label": "分享此对话", title: "分享" },
    onClick: () => {
      elements.push(domNode("input", { attrs: { value: shareUrl } }));
    },
  });
  elements.push(shareButton, domNode("div", { text: "共产党宣言心得", cls: "chat-title" }));

  const { payload } = await runGuestScript({
    elements,
    bodyText: "会话正文",
    fetch: apiRouter([shareListRoute([["AbC-123_xyz", "ffe0d5b9"]])]),
  });

  assert.equal(payload.share, "clicked", `应当点到分享图标按钮：${JSON.stringify(payload.share)}`);
  assert.equal(payload.url, shareUrl, "点完之后必须从页面上取回分享链接");
  assert.equal(payload.title, "共产党宣言心得 - DeepSeek");
});

test("内嵌页脚本：分享藏在「更多」菜单里时，先点开更多再点分享", async () => {
  const shareUrl = "https://chat.deepseek.com/share/more-menu";
  const elements = [];
  elements.push(
    domNode("button", {
      cls: "ds-icon-button",
      attrs: { "aria-label": "更多" },
      onClick: () => {
        elements.push(
          domNode("button", {
            text: "分享",
            attrs: { "data-testid": "share-entry" },
            onClick: () => {
              elements.push(domNode("textarea", { attrs: { value: shareUrl } }));
            },
          }),
        );
      },
    }),
  );

  const { payload } = await runGuestScript({
    elements,
    fetch: apiRouter([shareListRoute([["more-menu", "ffe0d5b9"]])]),
  });

  assert.equal(payload.share, "opened-more", `应当先点开「更多」：${JSON.stringify(payload)}`);
  assert.equal(payload.url, shareUrl);
});

test("内嵌页脚本：页面上已有分享链接时直接取走，不点任何东西", async () => {
  const shareUrl = "https://chat.deepseek.com/share/already-there";
  const elements = [domNode("a", { attrs: { href: shareUrl }, text: "分享链接" })];

  const { payload } = await runGuestScript({
    elements,
    fetch: apiRouter([shareListRoute([["already-there", "ffe0d5b9"]])]),
  });

  assert.equal(payload.url, shareUrl);
  assert.equal(payload.share, "not-attempted");
});

test("内嵌页脚本：页面里残留着上一个对话的链接时，宁可不给链接也不串台", async () => {
  /* 用户实测的串台场景：在右侧栏换成另一个对话，上次点开的分享弹窗还摆在页面上。 */
  const oldUrl = "https://chat.deepseek.com/share/OldShare001";
  const elements = [domNode("input", { attrs: { value: oldUrl } })];

  const { payload } = await runGuestScript({
    href: "https://chat.deepseek.com/a/chat/s/bbbbbbbb",
    elements,
    fetch: apiRouter([shareListRoute([["OldShare001", "aaaaaaaa"]])]),
  });

  assert.equal(payload.url, "", "旧对话的链接绝不能当成当前对话的结果");
  assert.equal(payload.share, "stale-link", `应当如实标注收不下：${JSON.stringify(payload.share)}`);
  assert.match(payload.stale, /没有收下/);
  assert.match(payload.stale, /aaaaaaaa/);
});

test("内嵌页脚本：先验掉残留的旧链接，再点出当前会话的新链接", async () => {
  const oldUrl = "https://chat.deepseek.com/share/OldShare001";
  const freshUrl = "https://chat.deepseek.com/share/NewShare002";
  const elements = [domNode("input", { attrs: { value: oldUrl } })];
  elements.push(
    domNode("button", {
      cls: "ds-icon-button",
      attrs: { "aria-label": "分享" },
      onClick: () => {
        elements.push(domNode("input", { attrs: { value: freshUrl } }));
      },
    }),
  );

  const { payload } = await runGuestScript({
    href: "https://chat.deepseek.com/a/chat/s/bbbbbbbb",
    elements,
    /* 接口这条路也堵上：没有正文、建不出链接，只能靠点击。 */
    fetch: apiRouter([
      ["/api/v0/chat/history_messages", apiOk({ code: 0, msg: "", data: {} }, 500)],
      ["/api/v0/share/create", apiOk(shareEnvelope({ bizCode: 5, bizMsg: "SOME_MESSAGES_CANNOT_BE_SHARED" }))],
      shareListRoute([
        ["OldShare001", "aaaaaaaa"],
        ["NewShare002", "bbbbbbbb"],
      ]),
    ]),
  });

  assert.equal(payload.url, freshUrl, "点出来的新链接才是当前会话的");
  assert.match(payload.stale, /OldShare001|aaaaaaaa/, "旧链接被收下的原因要留下");
});

test("内嵌页脚本：分享页（/share/<id>）没有会话 id 也读得回来 —— 正文走公开的分享接口", async () => {
  const routes = [
    [
      "/api/v0/share/content",
      apiOk({
        code: 0,
        msg: "",
        data: {
          biz_code: 0,
          biz_msg: "",
          biz_data: {
            title: "示例分享：八页文档字数估算",
            model_type: "default",
            messages: [
              { message_id: "m1", role: "USER", fragments: [{ type: "REQUEST", content: "八页文档大概多少字" }] },
              { message_id: "m2", role: "ASSISTANT", fragments: [{ type: "RESPONSE", content: "大约 4000 - 6000 字" }] },
            ],
          },
        },
      }),
    ],
  ];
  const { payload, calls } = await runGuestScript({
    href: "https://chat.deepseek.com/share/FixtureShare1234",
    token: null,
    fetch: apiRouter(routes),
  });

  assert.equal(payload.share, "share-page");
  assert.equal(payload.source, "share");
  assert.equal(payload.url, "https://chat.deepseek.com/share/FixtureShare1234");
  assert.equal(payload.title, "示例分享：八页文档字数估算");
  assert.match(payload.text, /八页文档大概多少字/);
  assert.match(payload.text, /4000 - 6000/);
  assert.match(payload.api, /分享接口（2 条）/);
  assert.equal(calls.length, 1, "分享页只该发这一个请求（不要 token、不要会话 id）");
  assert.match(calls[0].path, /share_id=FixtureShare1234/);
  assert.equal(calls[0].init.headers["x-client-bundle-id"], "com.deepseek.chat");
});

test("内嵌页脚本：正文取不到、但页面上有分享链接时，用分享接口把整篇补回来", async () => {
  const shareUrl = "https://chat.deepseek.com/share/DomLink77";
  const { payload } = await runGuestScript({
    href: "https://chat.deepseek.com/a/chat/s/ffe0d5b9",
    token: null,
    elements: [domNode("a", { attrs: { href: shareUrl }, text: "分享链接" })],
    fetch: apiRouter([
      ["/api/v0/chat/history_messages", apiOk({ code: 0, msg: "", data: {} }, 500)],
      shareListRoute([["DomLink77", "ffe0d5b9"]]),
      [
        "/api/v0/share/content",
        apiOk({
          code: 0,
          msg: "",
          data: {
            biz_code: 0,
            biz_msg: "",
            biz_data: {
              title: "补回来的标题",
              messages: [
                { message_id: "m1", role: "USER", fragments: [{ type: "REQUEST", content: "问题在此" }] },
                { message_id: "m2", role: "ASSISTANT", fragments: [{ type: "RESPONSE", content: "回答在此" }] },
              ],
            },
          },
        }),
      ],
    ]),
  });

  assert.equal(payload.url, shareUrl, "链接还是页面上那条");
  assert.equal(payload.source, "share", "正文来自分享接口");
  assert.match(payload.text, /问题在此/);
  assert.match(payload.text, /回答在此/);
  assert.match(payload.api, /正文由分享接口补上（2 条）/);
});

test("内嵌页脚本：宿主递进来的分享 id 也能读（选项四手里只有链接时就用它）", async () => {
  const routes = [
    [
      "/api/v0/share/content",
      apiOk({
        code: 0,
        msg: "",
        data: {
          biz_code: 0,
          biz_msg: "",
          biz_data: { title: "递进来的分享", messages: [{ message_id: "m1", role: "USER", fragments: [{ type: "REQUEST", content: "正文由 id 换回来的" }] }] },
        },
      }),
    ],
  ];
  const { payload } = await runGuestScript({
    href: "https://chat.deepseek.com/",
    token: null,
    args: { shareId: "Seeded12345" },
    fetch: apiRouter(routes),
  });

  assert.equal(payload.url, "https://chat.deepseek.com/share/Seeded12345");
  assert.match(payload.text, /正文由 id 换回来的/);
  assert.equal(payload.share, "share-page");
});

test("内嵌页脚本：宿主递进来的分享链接优先于这一栏当前开着的会话", async () => {
  const sid = "aabbccdd";
  const cached = {
    data: historyEnvelope({
      title: "这一栏开着的会话",
      messages: [{ message_id: 1, role: "USER", fragments: [{ type: "REQUEST", content: "当前会话的问题" }] }],
    }),
    frontendVersion: 7,
  };
  const { payload, calls } = await runGuestScript({
    href: `https://chat.deepseek.com/a/chat/s/${sid}`,
    indexedDB: fakeIndexedDB([[sid, cached]]),
    args: { shareId: "PriShare77" },
    fetch: apiRouter([
      [
        "/api/v0/share/content",
        apiOk({
          code: 0,
          msg: "",
          data: {
            biz_code: 0,
            biz_msg: "",
            biz_data: {
              title: "分享里的标题",
              messages: [
                { message_id: "m1", role: "USER", fragments: [{ type: "REQUEST", content: "分享里的正文" }] },
              ],
            },
          },
        }),
      ],
    ]),
  });

  assert.equal(payload.url, "https://chat.deepseek.com/share/PriShare77");
  assert.equal(payload.source, "share", `正文必须来自分享接口：${payload.source}`);
  assert.match(payload.text, /分享里的正文/);
  assert.equal(payload.text.includes("当前会话的问题"), false, "不能把这一栏开着的会话安到这个链接上");
  assert.equal(payload.title, "分享里的标题");
  assert.equal(calls.filter((call) => call.path.includes("share/content")).length, 1);
});

test("内嵌页脚本：找不到分享入口时，诊断要带上 tag / aria / class 三样信息", async () => {
  const elements = [domNode("button", { text: "朗读", cls: "ds-button ds-read" }), domNode("button", { cls: "ds-icon-button", attrs: { "aria-label": "复制" } })];

  const { payload } = await runGuestScript({ elements, bodyText: "正文在此" });

  assert.equal(payload.share, "no-share-button");
  assert.equal(payload.url, "");
  const dump = payload.buttons.join("\n");
  assert.match(dump, /朗读/, "诊断里要有可见文案");
  assert.match(dump, /aria=复制/, "只有 aria-label 的图标按钮也必须出现在诊断里");
  assert.match(dump, /class=ds-icon-button/, "class 是判断图标按钮的关键线索");
});

test("内嵌页脚本 × 投递链：脚本在假 DOM 上拿到的链接，能一路变成会话里的一条消息", async () => {
  const shareUrl = "https://chat.deepseek.com/share/e2e-1234";
  const elements = [];
  elements.push(
    domNode("button", {
      cls: "ds-icon-button ds-share-button",
      attrs: { "aria-label": "分享此对话" },
      onClick: () => {
        elements.push(domNode("input", { attrs: { value: shareUrl } }));
      },
    }),
  );
  const { payload } = await runGuestScript({
    elements,
    bodyText: "用户：帮我数一下多少汉字\n助手：这段文字共有 1030 个汉字",
    fetch: apiRouter([shareListRoute([["e2e-1234", "ffe0d5b9"]])]),
  });
  assert.equal(payload.url, shareUrl, `脚本这一步就得拿到链接：${JSON.stringify(payload)}`);

  const runtime = createRuntime();
  runtime.exports.__internals.setCapturedSessionId("session-1");
  runtime.webviews.push(fakeWebview({ payload: JSON.stringify(payload), url: "https://chat.deepseek.com/a/chat/s/ffe0d5b9" }));
  const prompts = [];
  const { after } = await chooseRead(runtime, "read-sidebar", {
    get: (name) => (name === "sessions" ? sessionsWithPrompt(prompts) : undefined),
  });

  assert.equal(prompts.length, 1, "整条链走完必须正好投递一条消息");
  const text = prompts[0].parts[0].text;
  assert.ok(text.includes(shareUrl), `消息里要有脚本拿到的分享链接：\n${text.slice(0, 400)}`);
  assert.match(text, /助手：这段文字共有 1030 个汉字/, "消息里要有脚本抓回的正文");
  assert.match(text, /读取右侧栏内对话/);
  assert.match(statusTextOf(after), /已发送到当前对话/);
});

test("内嵌页脚本：网页版接口优先 —— 不点任何按钮就拿到整篇正文与分享链接", async () => {
  const messages = [
    { message_id: "m1", role: "USER", fragments: [{ type: "REQUEST", id: -1, content: "八页文档大概多少字" }] },
    {
      message_id: "m2",
      role: "ASSISTANT",
      fragments: [
        { type: "THINK", id: 0, content: "思维链不该被读进正文" },
        { type: "RESPONSE", id: 1, content: "A4 常规排版 500–750 字/页，8 页大约 4000–6000 字。" },
      ],
    },
    { message_id: "m3", role: "USER", content: "帮我数一下具体多少汉字" },
    {
      message_id: "m4",
      role: "ASSISTANT",
      fragments: [
        { type: "RESPONSE", id: 1, content: "这段文字共有 1030 个汉字。" },
        { type: "FILE", id: 2, content: "附件正文不该被读进正文" },
        { type: "TOOL_SEARCH", id: 3, content: "搜索结果也不该被读进正文" },
      ],
    },
  ];
  const { payload, calls } = await runGuestScript({
    elements: [domNode("button", { text: "朗读" })],
    token: "tok-abc",
    fetch: apiRouter([
      ["/api/v0/chat/history_messages", apiOk(historyEnvelope({ title: "示例分享：八页文档字数估算", messages }))],
      ["/api/v0/share/create", apiOk(shareEnvelope({ shareId: "ApiShare123" }))],
    ]),
  });

  assert.equal(payload.source, "api", `应当走接口：${JSON.stringify(payload)}`);
  assert.equal(payload.share, "api");
  assert.equal(payload.url, "https://chat.deepseek.com/share/ApiShare123");
  assert.equal(payload.title, "示例分享：八页文档字数估算", "标题要用会话标题，不是页面标题");
  assert.equal(payload.api, "取到 4 条消息");
  assert.match(payload.text, /【我】\n八页文档大概多少字/);
  assert.match(payload.text, /【DeepSeek】\nA4 常规排版/);
  assert.match(payload.text, /这段文字共有 1030 个汉字。/);
  assert.doesNotMatch(payload.text, /思维链不该被读进正文/, "THINK（思维链）不能算正文");
  assert.doesNotMatch(payload.text, /附件正文不该被读进正文/, "FILE 不能算正文");
  assert.doesNotMatch(payload.text, /搜索结果也不该被读进正文/, "TOOL_* 不能算正文");
  assert.equal(calls.length, 2, "只应当问接口两次：取对话 + 建链接");
  assert.match(calls[0].path, /^\/api\/v0\/chat\/history_messages\?chat_session_id=ffe0d5b9/);
  assert.equal(calls[0].init.headers.authorization, "Bearer tok-abc");
  assert.equal(calls[0].init.credentials, "include");
  assert.equal(calls[1].path, "/api/v0/share/create");
  assert.deepEqual(JSON.parse(calls[1].init.body), { chat_session_id: "ffe0d5b9", message_ids: ["m1", "m2", "m3", "m4"] });
});

test("内嵌页脚本：分享接口只收到成对的消息（落单的提问不进去，正文不丢）", async () => {
  const messages = [
    { message_id: "u1", role: "USER", content: "第一问" },
    { message_id: "a1", role: "ASSISTANT", content: "第一答" },
    { message_id: "u2", role: "USER", content: "刚追加、还没回复的问题" },
  ];
  let postCount = 0;
  const { payload, calls } = await runGuestScript({
    token: "tok-1",
    fetch: apiRouter([
      ["/api/v0/chat/history_messages", apiOk(historyEnvelope({ messages }))],
      [
        "/api/v0/share/create",
        () => {
          postCount += 1;
          return apiOk(shareEnvelope({ shareId: "PairOk" }));
        },
      ],
    ]),
  });

  assert.equal(postCount, 1, "只交成对的消息，一次就该过（不再靠 biz_code 6 之后重试）");
  assert.equal(payload.share, "api", `成对子集应当直接拿到链接：${JSON.stringify(payload)}`);
  assert.equal(payload.url, "https://chat.deepseek.com/share/PairOk");
  assert.match(payload.text, /刚追加、还没回复的问题/, "正文仍然是全文，不因为分享退让而丢消息");
  const posts = calls.filter((item) => item.path === "/api/v0/share/create").map((item) => JSON.parse(item.init.body).message_ids);
  assert.deepEqual(posts, [["u1", "a1"]], "落单的提问不进 message_ids");
});

test("内嵌页脚本：接口这条路失败时退回 DOM 点按钮，两条路的诊断都留下", async () => {
  const shareUrl = "https://chat.deepseek.com/share/from-dom";
  const elements = [];
  elements.push(
    domNode("button", {
      cls: "ds-icon-button ds-share-button",
      attrs: { "aria-label": "分享此对话" },
      onClick: () => {
        elements.push(domNode("input", { attrs: { value: shareUrl } }));
      },
    }),
  );
  const { payload } = await runGuestScript({
    elements,
    bodyText: "页面上可见的那几段",
    token: "stale",
    fetch: apiRouter([
      ["/api/v0/chat/history_messages", apiOk({ code: 0, msg: "", data: { biz_code: 1, biz_msg: "", biz_data: {} } })],
      shareListRoute([["from-dom", "ffe0d5b9"]]),
    ]),
  });

  assert.equal(payload.source, "dom", "接口没给出正文，来源就不能标成 api");
  assert.equal(payload.share, "clicked");
  assert.equal(payload.url, shareUrl);
  assert.equal(payload.text, "页面上可见的那几段");
  assert.match(payload.api, /取对话失败：biz_code 1 INVALID_CHAT_SESSION/);
});

test("内嵌页脚本：userToken 无论是 JSON 包着还是裸串，都认得出并带上 Bearer", async () => {
  const messages = [
    { message_id: "m1", role: "USER", content: "问" },
    { message_id: "m2", role: "ASSISTANT", content: "答" },
  ];
  const routes = [
    ["/api/v0/chat/history_messages", apiOk(historyEnvelope({ messages }))],
    ["/api/v0/share/create", apiOk(shareEnvelope({ shareId: "TokenOk" }))],
  ];

  const wrapped = await runGuestScript({ tokenRaw: JSON.stringify({ value: "tok-wrapped", __version: "0" }), fetch: apiRouter(routes) });
  assert.equal(wrapped.payload.source, "api");
  assert.equal(wrapped.calls[0].init.headers.authorization, "Bearer tok-wrapped");

  const bare = await runGuestScript({ tokenRaw: "tok-bare", fetch: apiRouter(routes) });
  assert.equal(bare.payload.source, "api");
  assert.equal(bare.calls[0].init.headers.authorization, "Bearer tok-bare");
});

test("内嵌页脚本：没登录 / 页面没有 fetch / 接口抛错，三种都如实写进诊断且不抛错", async () => {
  const noToken = await runGuestScript({ token: null, elements: [domNode("button", { text: "朗读" })] });
  assert.equal(noToken.payload.ok, true, "读不到 token 也不能让脚本失败");
  assert.equal(noToken.payload.source, "dom");
  assert.match(noToken.payload.api, /都没有 token（这一栏可能没登录）/);
  assert.match(noToken.payload.api, /先用 cookie 试一次/, "没有 Bearer token 也要拿 cookie 试一次，不能直接放弃");
  assert.equal(noToken.calls.length, 0, "这一栏连 fetch 都没有，只能如实报错");

  /* 没有 userToken 但页面有 fetch：仍要发一次带 cookie 的请求，且不塞空 Bearer。 */
  const cookieOnly = await runGuestScript({
    token: null,
    elements: [domNode("button", { text: "朗读" })],
    fetch: apiRouter([
      [
        "/api/v0/chat/history_messages",
        apiOk(
          historyEnvelope({
            messages: [
              { message_id: "m1", role: "USER", content: "cookie 也能读" },
              { message_id: "m2", role: "ASSISTANT", content: "cookie 也能答" },
            ],
          }),
        ),
      ],
      ["/api/v0/share/create", apiOk(shareEnvelope({ shareId: "CookiePath1" }))],
    ]),
  });
  assert.equal(cookieOnly.calls.length, 2, `cookie 那条路的两次请求都要发出去：${JSON.stringify(cookieOnly.payload)}`);
  for (const call of cookieOnly.calls) {
    assert.equal(
      (call.init.headers || {}).authorization,
      undefined,
      `没有 token 就别硬塞一个空 Bearer（${call.path}）`,
    );
  }
  assert.match(cookieOnly.payload.api, /先用 cookie 试一次；取到 2 条消息/);
  assert.equal(cookieOnly.payload.source, "api", "cookie 这条路通了也算接口取到正文");
  assert.equal(cookieOnly.payload.url, "https://chat.deepseek.com/share/CookiePath1");

  const noFetch = await runGuestScript({ token: "tok-1" });
  assert.match(noFetch.payload.api, /取对话失败：这个内嵌页面没有 fetch/);

  const broken = await runGuestScript({ token: "tok-1", fetch: () => Promise.reject(new Error("net::ERR_CONNECTION_RESET")) });
  assert.match(broken.payload.api, /取对话失败：net::ERR_CONNECTION_RESET/);
});

test("内嵌页脚本：页面自己复制被拒时，钩子仍从剪贴板接住链接并如实标注来路", async () => {
  const expose = {};
  let clicks = 0;
  const shareButton = domNode("button", {
    attrs: { "aria-label": "分享" },
    onClick() {
      clicks += 1;
      /* 真实网页版那一步只调 writeText（没有 textarea 兜底），主文档没焦点就抛错。 */
      Promise.resolve(expose.navigator.clipboard.writeText("https://chat.deepseek.com/share/ClipCap77")).then(
        () => {},
        () => {},
      );
    },
  });
  const { payload, clipWrites } = await runGuestScript({
    token: null,
    elements: [shareButton],
    expose,
    clipboard: { writeText: () => Promise.reject(new Error("Document is not focused")) },
    fetch: apiRouter([
      [
        "/api/v0/chat/history_messages",
        apiOk(
          historyEnvelope({
            messages: [
              { message_id: "m1", role: "USER", content: "帮我数一下多少汉字" },
              { message_id: "m2", role: "ASSISTANT", content: "这段文字共有 1030 个汉字。" },
            ],
          }),
        ),
      ],
      ["/api/v0/share/create", apiOk(shareEnvelope({ bizCode: 9, bizMsg: "RATE_LIMIT_REACHED" }))],
    ]),
  });
  assert.ok(clicks > 0, `DOM 那条路应该点到分享按钮：${JSON.stringify(payload)}`);
  assert.ok(
    clipWrites.includes("https://chat.deepseek.com/share/ClipCap77"),
    `钩子要看见页面写剪贴板的那一次：${JSON.stringify(clipWrites)}`,
  );
  assert.equal(payload.url, "https://chat.deepseek.com/share/ClipCap77", JSON.stringify(payload));
  assert.equal(payload.share, "captured");
  assert.equal(payload.source, "capture");
  assert.match(payload.captured, /页面写入剪贴板/);
});

test("内嵌页脚本：页面自己建分享时，钩子从它自己的应答里接住 share_id", async () => {
  const expose = {};
  let pagePosts = 0;
  const shareButton = domNode("button", {
    attrs: { "aria-label": "分享" },
    onClick() {
      /* 页面自己也去建了一次分享，带的是它自己内存里的 token。 */
      pagePosts += 1;
      Promise.resolve(
        expose.guestFetch("/api/v0/share/create", {
          method: "POST",
          headers: { authorization: "Bearer page-memory-token", "content-type": "application/json" },
          body: JSON.stringify({ chat_session_id: "s1", message_ids: ["m1"] }),
        }),
      ).then(
        () => {},
        () => {},
      );
    },
  });
  const router = (path, init) => {
    const url = String(path);
    if (url.includes("/chat/history_messages")) {
      return Promise.resolve(
        apiOk(
          historyEnvelope({
            title: "被分享的会话",
            messages: [
              { message_id: "m1", role: "USER", content: "问题" },
              { message_id: "m2", role: "ASSISTANT", content: "回答" },
            ],
          }),
        ),
      );
    }
    if (url.includes("/share/create")) {
      const auth = String((init.headers || {}).authorization || "");
      if (auth === "Bearer page-memory-token") return Promise.resolve(apiOk(shareEnvelope({ shareId: "PageOwn99" })));
      return Promise.resolve(apiOk(shareEnvelope({ bizCode: 3, bizMsg: "BANNED_USER_CANNOT_CREATE_SHARES" })));
    }
    return Promise.reject(new Error("unexpected " + url));
  };
  const { payload } = await runGuestScript({ token: null, elements: [shareButton], expose, fetch: router });
  assert.equal(pagePosts, 1, `页面自己那一次请求要发出去：${JSON.stringify(payload)}`);
  assert.equal(payload.url, "https://chat.deepseek.com/share/PageOwn99", JSON.stringify(payload));
  assert.equal(payload.share, "captured");
  assert.equal(payload.source, "capture");
  assert.match(payload.captured, /页面自己的接口/);
});

test("读取链：剪贴板没写进去时，播报就直说没写进去（不许谎报已复制）", () => {
  const { exports } = createRuntime();
  const { noteForShare } = exports.__internals;
  const mine = noteForShare({ share: "api" }, true);
  const failed = noteForShare({ share: "api" }, false);
  const captured = noteForShare({ share: "captured" }, false);
  assert.match(mine, /已复制到剪贴板/);
  assert.match(failed, /没能写进剪贴板/);
  assert.doesNotMatch(failed, /已复制到剪贴板/, "写不进去就不能说已复制");
  assert.match(captured, /接住/, "从页面出口接住的链接，来路要写清楚");
});

test("内嵌页脚本 × 投递链：接口取到的正文与链接，一路变成会话里的一条消息并标明来源", async () => {
  const { payload } = await runGuestScript({
    token: "tok-1",
    fetch: apiRouter([
      [
        "/api/v0/chat/history_messages",
        apiOk(
          historyEnvelope({
            title: "示例分享：八页文档字数估算",
            messages: [
              { message_id: "m1", role: "USER", content: "八页文档大概多少字" },
              { message_id: "m2", role: "ASSISTANT", content: "这段文字共有 1030 个汉字。" },
            ],
          }),
        ),
      ],
      ["/api/v0/share/create", apiOk(shareEnvelope({ shareId: "E2eApi" }))],
    ]),
  });
  assert.equal(payload.share, "api", `接口这一步就该拿到链接：${JSON.stringify(payload)}`);

  const runtime = createRuntime();
  runtime.exports.__internals.setCapturedSessionId("session-1");
  runtime.webviews.push(fakeWebview({ payload: JSON.stringify(payload), url: "https://chat.deepseek.com/a/chat/s/ffe0d5b9" }));
  const prompts = [];
  const { after } = await chooseRead(runtime, "read-sidebar", {
    get: (name) => (name === "sessions" ? sessionsWithPrompt(prompts) : undefined),
  });

  assert.equal(prompts.length, 1, "整条链走完必须正好投递一条消息");
  const text = prompts[0].parts[0].text;
  assert.match(text, /分享链接：https:\/\/chat\.deepseek\.com\/share\/E2eApi/);
  assert.match(text, /【我】\n八页文档大概多少字/);
  assert.match(text, /1030 个汉字/);
  assert.match(text, /网页版接口取得/, "消息里要说明这份内容是接口取的、与滚动位置无关");
  assert.match(statusTextOf(after), /已发送到当前对话/);
});

function isElement(node) {
  return Boolean(node) && typeof node === "object" && "type" in node && "props" in node;
}

/**
 * 槽位注册给出的是一个**函数组件**；React 会在渲染时调用它。
 * 离线测试里我们自己做这一步（必要时递归展开嵌套函数组件）。
 * 每次进入函数组件都把 hook 游标归零 —— 这正是 React 的"同序读同槽"约定。
 */
function materialize(node, depth = 0) {
  let current = node;
  let guard = 0;
  while (isElement(current) && typeof current.type === "function" && guard < 8) {
    resetHooks();
    current = current.type(current.props ?? {});
    guard += 1;
  }
  return current;
}

function walk(node, visit) {
  if (Array.isArray(node)) {
    for (const item of node) walk(item, visit);
    return;
  }
  const resolved = materialize(node);
  if (!isElement(resolved)) return;
  visit(resolved);
  walk(resolved.props?.children, visit);
}

function findButtons(tree) {
  const buttons = [];
  walk(tree, (node) => {
    if (node.type === "button") buttons.push(node);
  });
  return buttons;
}

function findMenuItems(tree) {
  return findButtons(tree).filter((node) => node.props?.role === "menuitem");
}

function findMenuContainer(tree) {
  let found = null;
  walk(tree, (node) => {
    if (found === null && node.props?.role === "menu") found = node;
  });
  assert.ok(found, "组件里没有菜单容器");
  return found;
}

function findActionContainer(tree) {
  let found = null;
  walk(tree, (node) => {
    if (found === null && typeof node.props?.onKeyDown === "function") found = node;
  });
  assert.ok(found, "组件里没有可收键盘事件的容器");
  return found;
}

function findButton(tree) {
  const buttons = findButtons(tree);
  assert.ok(buttons.length >= 1, "组件里没有 <button>");
  return buttons[0];
}

function countType(tree, type) {
  let count = 0;
  walk(tree, (node) => {
    if (node.type === type) count += 1;
  });
  return count;
}

/** 自定义提示词面板里的五格输入。 */
function findInputs(tree) {
  const inputs = [];
  walk(tree, (node) => {
    if (node.type === "input") inputs.push(node);
  });
  return inputs;
}

/** 按可见文字找一个按钮（面板里的「保存 / 恢复默认 / 取消」没有 role 标记）。 */
function findButtonByText(tree, text) {
  const found = findButtons(tree).find((node) => flatten(node).trim() === text);
  assert.ok(found, `没有找到写着「${text}」的按钮`);
  return found;
}

/** 主按钮（菜单展开时它是列表里的最后一个按钮，所以不能用 [0]）。 */
function findToggle(tree) {
  const found = findButtons(tree).find((node) => node.props?.["aria-haspopup"] === "menu");
  assert.ok(found, "没有找到主按钮");
  return found;
}

function countStatusSpans(tree) {
  let count = 0;
  walk(tree, (node) => {
    if (node.type === "span" && node.props?.role === "status") count += 1;
  });
  return count;
}

/** 读无障碍状态位里的话。 */
function statusTextOf(tree) {
  let text = "";
  walk(tree, (node) => {
    if (node.type === "span" && node.props?.role === "status") text = flatten(node);
  });
  return text;
}

function flatten(node, out = []) {
  if (Array.isArray(node)) {
    for (const item of node) flatten(item, out);
    return out.join("");
  }
  if (typeof node === "string" || typeof node === "number") {
    out.push(String(node));
    return out.join("");
  }
  const resolved = materialize(node);
  if (!isElement(resolved)) return out.join("");
  flatten(resolved.props?.children, out);
  return out.join("");
}
