@echo off
rem dsh-deepseek-chat -- install into a DSH profile (double-click, or pass args)
rem   install.cmd -WhatIf      show what would change, write nothing
rem   install.cmd -Uninstall   remove the plugin from the profile
rem
rem This launcher is deliberately ASCII-only AND uses CRLF line endings.
rem cmd.exe under a non-UTF-8 console code page mis-decodes UTF-8 text in a
rem .cmd file and swallows the neighbouring ASCII characters, so the batch
rem lines themselves get shredded into fragments like 'stall.cmd' or 'ODE'.
rem All human-readable output therefore lives in install-profile.ps1
rem (UTF-8 with BOM, which PowerShell reads correctly).
rem
rem Note: this script uses goto instead of if(...) blocks, because %ERRORLEVEL%
rem is expanded when a parenthesised block is parsed, so it would not see the
rem exit code of a command that just ran.
setlocal
set "SCRIPT=%~dp0install-profile.ps1"
set "CODE=0"

where pwsh.exe >nul 2>nul
if errorlevel 1 goto useWindowsPowerShell
pwsh.exe -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT%" %*
goto done

:useWindowsPowerShell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT%" %*

:done
set "CODE=%ERRORLEVEL%"
echo.
if not "%CODE%"=="0" echo [install.cmd] exit code %CODE%
pause
exit /b %CODE%
