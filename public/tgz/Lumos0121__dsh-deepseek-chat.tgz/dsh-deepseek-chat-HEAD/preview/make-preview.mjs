// 生成预览页：主题变量取自本机 app.asar 的真实主题块（按偏移切片），样式表取自插件产物本身。
// 本文件是插件自带的一份拷贝：`node preview/make-preview.mjs` 重新生成同目录的 preview.html。
// 偏移来自 app.asar 块边界扫描；DSH 升级后若报「切片不含主题变量」，重新扫描再改下面的常量。
import { readFileSync, writeFileSync, mkdirSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";
import vm from "node:vm";

const PLUGIN = dirname(dirname(fileURLToPath(import.meta.url))); // 插件根目录
const ASAR = process.env.DSH_ASAR || "D:/应用/DeepSeek/resources/app.asar";
const OUT = join(PLUGIN, "preview", "preview.html");

// 本机 app.asar 里的主题块（明文偏移，均不含嵌套花括号）
const BLOCKS = {
  staticsA: { open: 45043269, close: 45045878 }, // 静态色板 77 token
  staticsB: { open: 45045903, close: 45048512 }, // 同一份静态色板的另一份拷贝
  aliasLight: { open: 45048517, close: 45055331 }, // body{ … } 浅色别名层 113 token
  aliasDark: { open: 45055356, close: 45062201 }, // body[data-ds-dark-theme]{ … } 深色别名层
};

const asar = readFileSync(ASAR).toString("latin1");
const sliceOf = (key) => {
  const { open, close } = BLOCKS[key];
  const body = asar.slice(open + 1, close);
  if (!body.includes("--dsw-")) throw new Error(`${key} 切片不含主题变量，asar 版本可能变了`);
  return body;
};
/** 取包含某偏移的那个声明块的内容（半径/阴影/浮层那几支散在小块里，按偏移兜住最省事）。 */
const blockAround = (needle) => {
  const at = asar.indexOf(needle);
  if (at < 0) throw new Error(`找不到 ${needle}`);
  const open = asar.lastIndexOf("{", at);
  const close = asar.indexOf("}", at);
  const body = asar.slice(open + 1, close);
  if (!body.includes("--dsw-")) throw new Error(`${needle} 所在块不含主题变量`);
  return body;
};

/** 把一段区间里的 `--dsw-*: 值` 声明抓成表（先出现者优先），跳过主题无关的普通 CSS。 */
function collectTokens(from, to) {
  const map = new Map();
  for (const match of asar.slice(from, to).matchAll(/--[a-z0-9-]+:\s*[^;}]+/g)) {
    const [name, ...rest] = match[0].split(":");
    const key = name.trim();
    if (key.startsWith("--ds-font") || key.startsWith("--ds-ea")) continue; // 字号/字体族里的旧前缀，一并带上也无妨
    if (!map.has(key)) map.set(key, rest.join(":").trim().replace(/\s*\n\s*/g, " "));
  }
  return map;
}
const baseTokens = collectTokens(45041893, 45048512); // :root 基础量 + 静态色板（浅色）
const extraTokens = collectTokens(45062233, 45066201); // 圆角/阴影/浮层/毛玻璃那一小撮
for (const [key, value] of extraTokens) if (!baseTokens.has(key)) baseTokens.set(key, value);
const rootCss = [...baseTokens].map(([key, value]) => `${key}:${value};`).join("\n");

const statics = `${sliceOf("staticsA")}\n${sliceOf("staticsB")}`;
const aliasLight = sliceOf("aliasLight");
const aliasDark = sliceOf("aliasDark");
for (const token of ["--dsw-static-neutral-bluish-00:", "--dsw-static-neutral-bluish-50:", "--dsw-static-neutral-bluish-900:", "--dsw-static-neutral-bluish-1000:"]) {
  if (!statics.includes(token)) throw new Error(`静态色板缺 ${token}`);
}
for (const token of ["--dsw-alias-interactive-bg-hover:", "--dsw-menu-surface-fill:"]) {
  if (!aliasLight.includes(token) || !aliasDark.includes(token)) throw new Error(`别名层缺 ${token}`);
}
for (const token of ["--dsw-radius-sm:", "--dsw-elevation-panel:", "--dsw-menu-backdrop-filter:", "--dsw-font-family:"]) {
  if (!rootCss.includes(token)) throw new Error(`基础量缺 ${token}`);
}
console.log(`主题块取好：:root ${baseTokens.size} 支、浅色别名 ${aliasLight.length}B、深色别名 ${aliasDark.length}B`);

// ── 从插件产物里取真实样式表 ─────────────────────────────────────────────
const captured = [];
const sandbox = {
  console,
  window: {
    __ModuleLoader__: {
      load(definition) {
        sandbox.__definition = definition;
      },
    },
  },
  document: {
    head: { appendChild() {} },
    body: { appendChild() {} },
    documentElement: { appendChild() {} },
    getElementById: () => null,
    createElement: () => {
      const node = { id: "", textContent: "", dataset: {}, click() {}, remove() {} };
      captured.push(node);
      return node;
    },
  },
};
sandbox.window.window = sandbox.window;
sandbox.window.document = sandbox.document;
vm.createContext(sandbox);
vm.runInContext(readFileSync(`${PLUGIN}/lib/client.js`, "utf8"), sandbox);

const reactMock = { createElement: () => ({}), useState: (value) => [value, () => {}], useCallback: (fn) => fn };
const api = sandbox.__definition.factory((name) => (name === "react" ? reactMock : {}));
if (!api || typeof api.apply !== "function") throw new Error("没能从产物里拿到 exports");
api.apply({ slots: { inject() {}, register() {} } });
const css = captured.map((node) => String(node.textContent || "")).join("\n");
if (!css.includes("--dsw-alias-interactive-bg-hover")) throw new Error("没抓到插件样式表");
console.log(`插件样式表 ${css.length}B，${(css.match(/--dsw-/g) || []).length} 处 token 引用`);

// ── 文案：一律取自产物自身，避免预览页与真实 UI 漂移 ───────────────────────
const LABELS = api.__internals || {};
for (const key of [
  "LABEL",
  "OPTION_SIDEBAR_LABEL",
  "OPTION_EXTERNAL_LABEL",
  "OPTION_READ_SIDEBAR_LABEL",
  "OPTION_READ_EXTERNAL_LABEL",
  "OPTION_EDIT_LABEL",
  "OPTION_EDIT_TITLE",
  "MENU_LABEL",
]) {
  if (typeof LABELS[key] !== "string") throw new Error(`产物没导出 ${key}，预览页无法保证与真实 UI 一致`);
}
console.log(
  `文案取自产物：主按钮「${LABELS.LABEL}」/ 选项「${LABELS.OPTION_SIDEBAR_LABEL}」「${LABELS.OPTION_EXTERNAL_LABEL}」` +
    `「${LABELS.OPTION_READ_SIDEBAR_LABEL}」「${LABELS.OPTION_READ_EXTERNAL_LABEL}」「${LABELS.OPTION_EDIT_LABEL}」`,
);


// ── 图标（与 client.js 里的 path 一致）────────────────────────────────────
const svg = (paths) =>
  `<svg class="dsh-deepseek-chat-icon" viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${paths
    .map((d) => `<path d="${d}"></path>`)
    .join("")}</svg>`;
const ICON_CHAT = svg(["M20 12.5c0 3.6-3.6 6.5-8 6.5-1 0-2-.15-2.9-.42L5 20l1.05-3.1C4.75 15.7 4 14.18 4 12.5 4 8.9 7.6 6 12 6s8 2.9 8 6.5Z"]);
const ICON_PANEL = svg(["M4 5.5A1.5 1.5 0 0 1 5.5 4h13A1.5 1.5 0 0 1 20 5.5v13A1.5 1.5 0 0 1 18.5 20h-13A1.5 1.5 0 0 1 4 18.5v-13Z", "M15 4v16"]);
const ICON_EXTERNAL = svg(["M14 4h6v6", "M20 4l-8.5 8.5", "M18 14.5V18.5A1.5 1.5 0 0 1 16.5 20h-11A1.5 1.5 0 0 1 4 18.5v-11A1.5 1.5 0 0 1 5.5 6H9.5"]);
const ICON_READ = svg(["M12 3v10", "M8.5 9.5 12 13l3.5-3.5", "M4.5 15.5V18A1.5 1.5 0 0 0 6 19.5h12A1.5 1.5 0 0 0 19.5 18v-2.5"]);
const ICON_CLIPBOARD = svg([
  "M9 4.5h6v2.5H9z",
  "M8.5 5.5H6.5A1.5 1.5 0 0 0 5 7v11.5A1.5 1.5 0 0 0 6.5 20h11a1.5 1.5 0 0 0 1.5-1.5V7a1.5 1.5 0 0 0-1.5-1.5h-2",
  "M8.5 12h7",
  "M8.5 15.5h4.5",
]);
const ICON_EDIT = svg(["M15.5 4.6 19.4 8.5", "M16.6 3.5a1.6 1.6 0 0 1 2.3 0l1.6 1.6a1.6 1.6 0 0 1 0 2.3L8.4 19.5 4 20.5l1-4.4Z"]);

const M = "dsh-deepseek-chat";
// status 给定时，菜单底部会多出一条可见的 `-hint`（窄栏下隐藏）。
const widget = ({ wide, open, status = "" }) => `
  <div class="${M}-action${wide ? "" : " " + M + "-action--narrow"}">
    ${
      open
        ? `<div class="${M}-menu" role="menu" aria-label="${LABELS.MENU_LABEL}">
      <button type="button" class="${M}-option" role="menuitem">${ICON_PANEL}${wide ? `<span class="${M}-text">${LABELS.OPTION_SIDEBAR_LABEL}</span>` : ""}</button>
      <button type="button" class="${M}-option" role="menuitem">${ICON_EXTERNAL}${wide ? `<span class="${M}-text">${LABELS.OPTION_EXTERNAL_LABEL}</span>` : ""}</button>
      <div class="${M}-divider" role="separator" aria-hidden="true"></div>
      <button type="button" class="${M}-option" role="menuitem">${ICON_READ}${wide ? `<span class="${M}-text">${LABELS.OPTION_READ_SIDEBAR_LABEL}</span>` : ""}</button>
      <button type="button" class="${M}-option" role="menuitem">${ICON_CLIPBOARD}${wide ? `<span class="${M}-text">${LABELS.OPTION_READ_EXTERNAL_LABEL}</span>` : ""}</button>
      <div class="${M}-divider" role="separator" aria-hidden="true"></div>
      <button type="button" class="${M}-option" role="menuitem" title="${LABELS.OPTION_EDIT_TITLE}">${ICON_EDIT}${wide ? `<span class="${M}-text">${LABELS.OPTION_EDIT_LABEL}</span>` : ""}</button>
      ${status && wide ? `<div class="${M}-hint" role="note" title="${status}">${status}</div>` : ""}
    </div>`
        : ""
    }
    <button type="button" class="${M}-button" aria-haspopup="menu" aria-expanded="${open}">
      ${ICON_CHAT}${wide ? `<span class="${M}-text">${LABELS.LABEL}</span>` : ""}
      <span class="${M}-status" role="status" aria-live="polite"></span>
    </button>
  </div>`;


const bodyLines = (wide) => (wide ? ["会话列表 …", "会话列表 …", "会话列表 …", "会话列表 …"] : ["·", "·", "·"]).map((line) => `<span>${line}</span>`).join("");

const panel = (theme, label) => `
<section class="stage ${theme}">
  <h2>${label}</h2>
  <div class="pair">
    ${[
      { wide: true, open: false, caption: "宽栏 · 收起" },
      { wide: true, open: true, caption: "宽栏 · 展开（点一下）" },
      { wide: true, open: true, status: LABELS.STATUS_SIDEBAR, caption: "宽栏 · 展开 + 一行提示" },
      { wide: false, open: false, caption: "窄栏 56px · 收起" },
      { wide: false, open: true, caption: "窄栏 56px · 展开" },
    ]
      .map(
        (item) => `
    <figure class="shot ${item.wide ? "shot--wide" : "shot--narrow"}">
      <figcaption>${item.caption}</figcaption>
      <div class="sidebar">
        <div class="sidebar__body">${bodyLines(item.wide)}</div>
        <div class="sidebar__footer">
          <button class="sibling" title="邻居：cordis 面板的角标入口">◍</button>
          ${widget(item)}
        </div>
      </div>
    </figure>`,
      )
      .join("")}
  </div>
</section>`;

const html = `<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<title>dsh-deepseek-chat · UI 预览</title>
<style>
/* ===== 本机 app.asar 里的真实主题变量（原样搬运，未改写任何取值）===== */
:root {
${rootCss}
}
.stage-light { ${aliasLight} }
.stage-dark { ${aliasDark} }

/* ===== 插件自己的样式表（直接取自 lib/client.js；改代码后重跑生成脚本即可）===== */
${css}

/* ===== 预览页脚手架：只负责摆出"侧边栏底部"这个语境，不参与插件样式 ===== */
* { box-sizing: border-box; }
body {
  margin: 0;
  padding: 24px;
  background: var(--dsw-alias-bg-base, #fff);
  color: var(--dsw-alias-label-primary, #111);
  font-family: var(--dsw-font-family, "Segoe UI", "Microsoft YaHei", system-ui, sans-serif);
}
h1 { font-size: 18px; margin: 0 0 4px; }
p.lead { margin: 0 0 24px; color: var(--dsw-alias-label-secondary); font-size: 13px; }
h2 { font-size: 13px; font-weight: 500; margin: 0 0 12px; color: var(--dsw-alias-label-secondary); }
.stage { padding: 20px; border-radius: 16px; border: 1px solid var(--dsw-alias-border-l2, #0001); background: var(--dsw-alias-bg-base); }
.stage + .stage { margin-top: 20px; }
.pair { display: flex; flex-wrap: wrap; gap: 28px; align-items: flex-start; }
figure.shot { margin: 0; }
figure.shot--wide { width: 240px; }
figure.shot--narrow { width: 60px; }
figcaption { font-size: 11px; margin-bottom: 6px; color: var(--dsw-alias-label-secondary); white-space: nowrap; }
.sidebar { display: flex; flex-direction: column; height: 300px; border: 1px solid var(--dsw-alias-border-l2, #0002); border-radius: 12px; overflow: hidden; background: var(--dsw-specific-sidebar-fill, var(--dsw-alias-bg-layer-2)); }
.sidebar__body { flex: 1; display: flex; flex-direction: column; gap: 12px; padding: 8px 10px; font-size: 11px; color: var(--dsw-alias-label-tertiary, #888); overflow: hidden; white-space: nowrap; }
figure.shot--narrow .sidebar__body { padding: 8px 0; align-items: center; font-size: 9px; }
.sidebar__footer { display: flex; align-items: flex-end; gap: 6px; padding: 6px; border-top: .5px solid var(--dsw-alias-border-l1, #0001); }
figure.shot--narrow .sidebar__footer { flex-direction: column; align-items: center; }
.sibling { width: 30px; height: 30px; flex: none; border: 1px solid transparent; border-radius: var(--dsw-radius-sm, 8px); background: transparent; color: var(--dsw-alias-label-secondary); font-size: 13px; line-height: 1; cursor: pointer; }
.sibling:hover { background: var(--dsw-alias-interactive-bg-hover); color: var(--dsw-alias-label-primary); }
figure.shot .${M}-action { flex: 1; }
figure.shot--narrow .${M}-action { flex: none; }
</style>
</head>
<body>
<h1>dsh-deepseek-chat · 侧边栏按钮 UI 预览</h1>
<p class="lead">同一份样式表、同一套本机主题变量。菜单五项：${LABELS.OPTION_SIDEBAR_LABEL} / ${LABELS.OPTION_EXTERNAL_LABEL} / （分隔线）/ ${LABELS.OPTION_READ_SIDEBAR_LABEL} / ${LABELS.OPTION_READ_EXTERNAL_LABEL} / （分隔线）/ ${LABELS.OPTION_EDIT_LABEL}；旁边那个 ◍ 是这座位上的邻居（cordis 面板的角标），用来对齐观感。</p>
${panel("stage-light", "浅色主题")}
${panel("stage-dark", "深色主题（body[data-ds-dark-theme]）")}
</body>
</html>
`;

mkdirSync(`${PLUGIN}/preview`, { recursive: true });
writeFileSync(OUT, html, "utf8");

// ── 交叉校验：插件 CSS 用到的每一支变量都必须在真实主题里存在，并打印两种主题下的取值 ──
const declOf = (text) => new Map([...text.matchAll(/--[a-z0-9-]+:\s*[^;}]+/g)].map((m) => {
  const [name, ...rest] = m[0].split(":");
  return [name.trim(), rest.join(":").trim()];
}));
const lightMap = new Map([...baseTokens, ...declOf(aliasLight)]);
const darkMap = new Map([...baseTokens, ...declOf(aliasDark)]);
const resolve = (name, map) => {
  let value = map.get(name);
  for (let step = 0; step < 8 && value && /^var\(/.test(value); step += 1) {
    const next = value.match(/var\((--[a-z0-9-]+)/);
    if (!next) break;
    value = map.get(next[1]) ?? map.get(next[1]) ?? baseTokens.get(next[1]);
  }
  return value;
};
const pluginVars = [...new Set([...css.matchAll(/var\((--[a-z0-9-]+)/g)].map((m) => m[1]))].sort();
const missing = pluginVars.filter((name) => !lightMap.has(name) || !darkMap.has(name));
console.log(`\n插件 CSS 引用 ${pluginVars.length} 支变量：`);
for (const name of pluginVars) {
  const light = resolve(name, lightMap) ?? "**未定义**";
  const dark = resolve(name, darkMap) ?? "**未定义**";
  console.log(`  ${name.padEnd(38)} 浅色 ${String(light).slice(0, 34).padEnd(36)} 深色 ${String(dark).slice(0, 34)}`);
}
if (missing.length > 0) throw new Error(`这些变量在真实主题里不存在：${missing.join(", ")}`);
console.log(`\n已写出 ${OUT} (${html.length}B)；所有变量在浅色与深色下均有定义。`);
