import { defineConfig } from 'vitest/config'

export default defineConfig({
  test: {
    include: ['test/**/*.test.ts'],
    coverage: {
      provider: 'v8',
      include: ['src/**'],
      // 仪表盘是纯静态模板串、宿主装配依赖 cordis 运行时——两者属集成
      // 表面，单元测试不可达，不纳入门禁。
      exclude: ['src/dashboard.ts', 'src/index.ts'],
      reporter: ['text', 'json-summary'],
      // 棘轮门禁：阈值锁定当前实测值 −1 个百分点。覆盖率只许升不许降
      // ——低于地板即测试失败，防止覆盖在后续演进中悄然流失。
      thresholds: {
        statements: 85,
        branches: 69,
        functions: 87,
        lines: 87,
      },
    },
  },
})
