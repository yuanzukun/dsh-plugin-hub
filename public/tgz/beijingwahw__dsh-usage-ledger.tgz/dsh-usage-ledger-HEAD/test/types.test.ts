import { describe, expect, it } from 'vitest'
import { beijingDate, usageTotalTokens } from '../src/types.js'

const at = (iso: string): number => Date.parse(iso)

describe('beijingDate', () => {
  it('converts an instant to the Beijing calendar day', () => {
    expect(beijingDate(at('2026-08-20T00:30:00+08:00'))).toBe('2026-08-20')
    expect(beijingDate(at('2026-08-19T23:30:00+08:00'))).toBe('2026-08-19')
  })

  it('is independent of the host timezone', () => {
    // 2026-08-20 02:00 Beijing == 2026-08-19 18:00 UTC.
    expect(beijingDate(at('2026-08-19T18:00:00Z'))).toBe('2026-08-20')
  })

  it('rolls over at Beijing midnight', () => {
    expect(beijingDate(at('2026-08-20T23:59:59+08:00'))).toBe('2026-08-20')
    expect(beijingDate(at('2026-08-21T00:00:01+08:00'))).toBe('2026-08-21')
  })

  it('pins the offset to exactly +8h: +1h or +8ms would roll the day (mutation guard)', () => {
    // 北京 23:00：+8h 仍是当天；小时数若被 +1 会翻到次日。
    expect(beijingDate(at('2026-08-20T23:00:00+08:00'))).toBe('2026-08-20')
    // 北京 23:59:59.992：距午夜仅 8ms；偏移毫秒数若被 +1 会翻到次日。
    expect(beijingDate(at('2026-08-20T23:59:59.992+08:00'))).toBe('2026-08-20')
  })
})

describe('usageTotalTokens', () => {
  it('sums input, output, and cache traffic', () => {
    expect(usageTotalTokens({
      inputTokens: 100,
      outputTokens: 50,
      cacheReadTokens: 400,
      cacheWriteTokens: 200,
    })).toBe(750)
  })

  it('excludes reasoning tokens (subset of output, avoids double counting)', () => {
    expect(usageTotalTokens({
      inputTokens: 100,
      outputTokens: 50,
      reasoningTokens: 30,
    })).toBe(150)
  })

  it('tolerates missing optional counters', () => {
    expect(usageTotalTokens({ inputTokens: 10, outputTokens: 5 })).toBe(15)
  })
})
