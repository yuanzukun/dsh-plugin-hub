import { describe, expect, it } from 'vitest'
import {
  parseDoubaoSheet,
  parseErnieSheet,
  parseKimiSheet,
  parsePriceCell,
  parseRawTables,
  parseVendorSheet,
  parseZhipuBundleSheet,
  parseZhipuLegacySheet,
  toGrid,
} from '../src/scrapers.js'

describe('parseRawTables + toGrid', () => {
  it('expands rowspan and colspan into a rectangular grid', () => {
    const html = `<table>
      <tr><td rowspan="2">A</td><td colspan="2">B</td><td>C</td></tr>
      <tr><td>D</td><td>E</td></tr>
    </table>`
    const tables = parseRawTables(html)
    expect(tables).toHaveLength(1)
    const grid = toGrid(tables[0]!)
    expect(grid[0]).toEqual(['A', 'B', '', 'C'])
    expect(grid[1]).toEqual(['A', 'D', 'E'])
  })

  it('strips tags and decodes entities in cells', () => {
    const html = '<table><tr><td><b>模型</b>&nbsp;X</td></tr></table>'
    const grid = toGrid(parseRawTables(html)[0]!)
    expect(grid[0]?.[0]).toBe('模型 X')
  })
})

describe('parsePriceCell', () => {
  it.each([
    ['0.8元', 0.8],
    ['¥1.10', 1.1],
    ['免费', 0],
    ['0.004 元/千tokens', 4],
    ['0.8元 / 百万Tokens', 0.8],
    ['$0.11', undefined],
    ['-', undefined],
  ])('%s → %s', (input, expected) => {
    expect(parsePriceCell(input)).toBe(expected)
  })
})

describe('parseVendorSheet (generic html channel)', () => {
  it('parses the row layout: models as rows, price kinds as columns', () => {
    const html = `<table>
      <tr><th>模型</th><th>输入价格（元/百万Tokens）</th><th>输出价格（元/百万Tokens）</th></tr>
      <tr><td>qwen3-plus</td><td>0.8</td><td>2</td></tr>
      <tr><td>qwen3-max</td><td>2.5</td><td>10</td></tr>
    </table>`
    const table = parseVendorSheet(html, 'qwen')
    expect(table['qwen3-plus']).toEqual({ inputCacheHit: 0, inputMiss: 0.8, output: 2 })
    expect(table['qwen3-max']).toEqual({ inputCacheHit: 0, inputMiss: 2.5, output: 10 })
  })

  it('parses the column layout: models as header columns (DeepSeek style)', () => {
    const html = `<table>
      <tr><th>模型</th><th>deepseek-v4-flash</th></tr>
      <tr><td>输入价格（缓存未命中）</td><td>1元</td></tr>
      <tr><td>输入价格（缓存命中）</td><td>0.02元</td></tr>
      <tr><td>输出价格</td><td>2元</td></tr>
    </table>`
    const table = parseVendorSheet(html, 'deepseek')
    expect(table['deepseek-v4-flash']).toEqual({ inputCacheHit: 0.02, inputMiss: 1, output: 2 })
  })

  it('keeps the first tier of repeated models and ignores unrelated tables', () => {
    const html = `<table>
      <tr><th>模型</th><th>输入（元/百万）</th><th>输出（元/百万）</th></tr>
      <tr><td>qwen3-plus</td><td>0.8</td><td>2</td></tr>
      <tr><td>qwen3-plus</td><td>2.0</td><td>8</td></tr>
    </table>
    <table><tr><th>功能</th><th>说明</th></tr><tr><td>上下文缓存</td><td>自动开启</td></tr></table>`
    const table = parseVendorSheet(html, 'qwen')
    expect(table['qwen3-plus']).toEqual({ inputCacheHit: 0, inputMiss: 0.8, output: 2 })
    expect(Object.keys(table)).toEqual(['qwen3-plus'])
  })

  it('returns an empty table for JS-only pages', () => {
    expect(parseVendorSheet('<html><body><div id="app"></div></body></html>', 'qwen')).toEqual({})
  })
})

describe('parseErnieSheet', () => {
  it('parses the CDN page-data HTML table with unit filtering', () => {
    const html = `<table>
      <tr><th>模型名称</th><th>版本名称</th><th>服务内容</th><th>子项</th><th>在线推理</th><th>批量推理</th><th>单位</th></tr>
      <tr><td>ERNIE 5.1</td><td>ERNIE-5.1</td><td>推理服务</td><td>输入（输入&lt;=32k）</td><td>0.004</td><td>-</td><td>元/千tokens</td></tr>
      <tr><td>ERNIE 5.1</td><td>ERNIE-5.1</td><td>推理服务</td><td>输出</td><td>0.016</td><td>-</td><td>元/千tokens</td></tr>
      <tr><td>ERNIE 5.1</td><td>ERNIE-5.1</td><td>推理服务</td><td>缓存命中</td><td>0.0008</td><td>-</td><td>元/千tokens</td></tr>
      <tr><td>ERNIE 5.1</td><td>ERNIE-5.1-vl</td><td>推理服务</td><td>图片生成</td><td>0.05</td><td>-</td><td>元/张</td></tr>
    </table>`
    const table = parseErnieSheet(html)
    expect(table['ernie-5.1']).toEqual({ inputCacheHit: 0.8, inputMiss: 4, output: 16 })
    expect(table['ernie-5.1-vl']).toBeUndefined() // per-image row excluded by unit filter
  })
})

describe('parseZhipuBundleSheet', () => {
  it('extracts flagship prices embedded in the SPA JS bundle', () => {
    const js = 'newModel:{modelList:[{name:"GLM-5.2",inPrice:["8元"],outPrice:["28元"],hit:["2元"]},{name:"",inPrice:["40元"],outPrice:["120元"]},{name:"GLM-4.6",inPrice:["5元"],outPrice:["5元"],hit:["1元"]}]}'
    const table = parseZhipuBundleSheet(js)
    expect(table['glm-5.2']).toEqual({ inputCacheHit: 2, inputMiss: 8, output: 28 })
    expect(table['glm-4.6']).toEqual({ inputCacheHit: 1, inputMiss: 5, output: 5 })
    // The unnamed tier row is skipped entirely.
    expect(Object.keys(table)).toEqual(['glm-5.2', 'glm-4.6'])
  })

  it('treats 免费 entries as zero', () => {
    const js = 'newModel:{modelList:[{name:"GLM-4-Flash",inPrice:["免费"],outPrice:["免费"],hit:["免费"]}]}'
    expect(parseZhipuBundleSheet(js)['glm-4-flash']).toEqual({ inputCacheHit: 0, inputMiss: 0, output: 0 })
  })
})

describe('parseZhipuLegacySheet', () => {
  it('maps random field codes through the column labels', () => {
    const json = JSON.stringify({
      data: [{
        operationId: '1122',
        content: JSON.stringify({
          list: [{
            fieldList: [{ code: 'm', label: '模型' }, { code: 'p', label: '单价' }],
            modelList: [
              { m: 'GLM-4.5-AIR', p: '0.8元 / 百万Tokens' },
              { m: 'GLM-4-Flash', p: '免费' },
              { m: 'GLM-4V', p: '0.04元 / 千Tokens' },
            ],
          }],
        }),
      }],
    })
    const table = parseZhipuLegacySheet(json)
    expect(table['glm-4.5-air']).toEqual({ inputCacheHit: 0, inputMiss: 0.8, output: 0.8 })
    expect(table['glm-4-flash']).toEqual({ inputCacheHit: 0, inputMiss: 0, output: 0 })
    // "元/千Tokens" cells are not 百万-scaled prices → excluded.
    expect(table['glm-4v']).toBeUndefined()
  })

  it('bills zero output when the cell says 输出：不计费', () => {
    const json = JSON.stringify({
      data: [{
        operationId: '1123',
        content: JSON.stringify({
          list: [{
            fieldList: [{ code: 'a', label: '模型' }, { code: 'b', label: '单价' }],
            modelList: [{ a: 'GLM-4-Flash-250414', b: '输入：0.5元/百万 tokens；输出：不计费' }],
          }],
        }),
      }],
    })
    const table = parseZhipuLegacySheet(json)
    expect(table['glm-4-flash-250414']).toEqual({ inputCacheHit: 0, inputMiss: 0.5, output: 0 })
  })
})

describe('parseDoubaoSheet', () => {
  it('parses LLM tables only, excluding video models and merged tier rows', () => {
    const md = `# 大语言模型
|模型名称|输入（非音频）|输出（非音频）|缓存命中（非音频）|
|---|---|---|---|
|doubao-seed-2.0-pro|3.2元|16元|0.64元|
||6.4元|32元|1.28元|
|doubao-seed-2.0-lite|0.6元|3.6元|0.12元|

# 视频生成
|模型名称|输入|输出|
|---|---|---|
|doubao-seedance-1.0|5元|10元|`
    const table = parseDoubaoSheet(md)
    expect(table['doubao-seed-2.0-pro']).toEqual({ inputCacheHit: 0.64, inputMiss: 3.2, output: 16 })
    expect(table['doubao-seed-2.0-lite']).toEqual({ inputCacheHit: 0.12, inputMiss: 0.6, output: 3.6 })
    expect(Object.keys(table)).toEqual(['doubao-seed-2.0-pro', 'doubao-seed-2.0-lite'])
  })
})

describe('parseKimiSheet', () => {
  it('derives column meanings from RSC payload titles', () => {
    const rsc = 'columns:[{title:`模型`,key:"m"},{title:`输入价格（缓存命中）`},{title:`输入价格（缓存未命中）`},{title:`输出价格`}],rows:[[`kimi-k2.6`,`¥1.10`,`¥6.50`,`¥27.00`],[`kimi-k2.5`,`¥0.70`,`¥4.00`,`¥21.00`]]'
    const table = parseKimiSheet(rsc)
    expect(table['kimi-k2.6']).toEqual({ inputCacheHit: 1.1, inputMiss: 6.5, output: 27 })
    expect(table['kimi-k2.5']).toEqual({ inputCacheHit: 0.7, inputMiss: 4, output: 21 })
  })

  it('survives an inserted extra column between price kinds', () => {
    const rsc = 'columns:[{title:`模型`},{title:`输入价格（缓存命中）`},{title:`限速`},{title:`输入价格（缓存未命中）`},{title:`输出价格`}],rows:[[`kimi-k2.6`,`¥1.10`,`100 TPM`,`¥6.50`,`¥27.00`]]'
    const table = parseKimiSheet(rsc)
    expect(table['kimi-k2.6']).toEqual({ inputCacheHit: 1.1, inputMiss: 6.5, output: 27 })
  })
})
