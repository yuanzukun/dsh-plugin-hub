import { describe, expect, it } from 'vitest'
import { auditFile, describeAudit } from '../src/audit.js'
import type { LedgerFile } from '../src/types.js'

const file = (over: Partial<LedgerFile> = {}): LedgerFile => ({
  version: 1,
  sessions: {},
  daily: {},
  total: { calls: 0, tokens: 0, cost: 0 },
  ...over,
})

const row = (over: Partial<{ calls: number; inputTokens: number; outputTokens: number; cost: number }> = {}) => ({
  calls: 1,
  inputTokens: 1_000,
  outputTokens: 2_000,
  cacheReadTokens: 0,
  cacheWriteTokens: 0,
  reasoningTokens: 0,
  cost: 0.5,
  ...over,
})

describe('auditFile', () => {
  it('一份一致的账本对账平衡', () => {
    const detail = row()
    const tokens = 3_000
    const f = file({
      sessions: { s1: { ...detail, title: '', createdAt: 0, updatedAt: 0, lastSeq: -1 } },
      daily: { '2026-08-20': { calls: 1, tokens, cost: 0.5 } },
      models: { 'deepseek-v4-pro': { ...detail } },
      total: { calls: 1, tokens, cost: 0.5 },
    })
    const report = auditFile(f)
    expect(report.ok).toBe(true)
    expect(report.detail).toEqual({ calls: 1, tokens, cost: 0.5 })
    expect(report.daily).toEqual({ calls: 1, tokens, cost: 0.5 })
    expect(report.models).toEqual({ calls: 1, tokens, cost: 0.5 })
    expect(report.detailDrift).toEqual({ calls: 0, tokens: 0, cost: 0 })
  })

  it('明细 = 活跃会话 + 归档行（tokens 口径沿用归档存储值）', () => {
    const f = file({
      sessions: { s1: { ...row({ calls: 2, cost: 1 }), title: '', createdAt: 0, updatedAt: 0, lastSeq: -1 } },
      archived: { s2: { calls: 3, tokens: 9_000, cost: 2, lastSeq: 5, archivedAt: 0 } },
      daily: { '2026-08-20': { calls: 5, tokens: 12_000, cost: 3 } },
      total: { calls: 5, tokens: 12_000, cost: 3 },
    })
    const report = auditFile(f)
    expect(report.detail).toEqual({ calls: 5, tokens: 3_000 + 9_000, cost: 3 })
    expect(report.ok).toBe(true)
  })

  it('总计被篡改/损坏时明细漂移现形（可修复路径）', () => {
    const f = file({
      sessions: { s1: { ...row(), title: '', createdAt: 0, updatedAt: 0, lastSeq: -1 } },
      daily: { '2026-08-20': { calls: 1, tokens: 3_000, cost: 0.5 } },
      total: { calls: 99, tokens: 99_999, cost: 42 },
    })
    const report = auditFile(f)
    expect(report.ok).toBe(false)
    expect(report.detailDrift.calls).toBe(-98)
    expect(report.detailDrift.cost).toBeCloseTo(-41.5)
  })

  it('日桶漂移被检出但不改变 ok 之外的字段语义', () => {
    const f = file({
      sessions: { s1: { ...row(), title: '', createdAt: 0, updatedAt: 0, lastSeq: -1 } },
      daily: { '2026-08-20': { calls: 1, tokens: 1, cost: 0.1 } },
      total: { calls: 1, tokens: 3_000, cost: 0.5 },
    })
    const report = auditFile(f)
    expect(report.ok).toBe(false)
    expect(report.dailyDrift.tokens).toBe(1 - 3_000)
    expect(report.detailDrift.tokens).toBe(0)
  })

  it('模型表口径边界：漂移仅报告，不影响 ok', () => {
    const f = file({
      sessions: { s1: { ...row(), title: '', createdAt: 0, updatedAt: 0, lastSeq: -1 } },
      daily: { '2026-08-20': { calls: 1, tokens: 3_000, cost: 0.5 } },
      total: { calls: 1, tokens: 3_000, cost: 0.5 },
      // v0.2.0 之前的账本没有 models 表——对账仍应平衡。
      models: {},
    })
    expect(auditFile(f).ok).toBe(true)
    expect(auditFile(f).modelDrift.calls).toBe(-1)
  })

  it('浮点累加的表示误差被 1e-9 容差吸收', () => {
    const cost = 0.1 + 0.2
    const f = file({
      sessions: { s1: { ...row({ cost }), title: '', createdAt: 0, updatedAt: 0, lastSeq: -1 } },
      daily: { '2026-08-20': { calls: 1, tokens: 3_000, cost } },
      total: { calls: 1, tokens: 3_000, cost: 0.30000000000000004 },
    })
    expect(auditFile(f).ok).toBe(true)
  })

  it('容差是严格小于：漂移恰为 1e-9 时判不平衡（mutation guard）', () => {
    // 明细 cost=0 vs 总计 cost=1e-9 → |漂移| = 1e-9，恰在容差线上：
    // `< 1e-9` 必须判「不平衡」；若被改成 `<=` 会把精确漂移误判为平衡。
    const f = file({
      sessions: { s1: { ...row({ calls: 0, inputTokens: 0, outputTokens: 0, cost: 0 }), title: '', createdAt: 0, updatedAt: 0, lastSeq: -1 } },
      daily: { '2026-08-20': { calls: 0, tokens: 0, cost: 1e-9 } },
      total: { calls: 0, tokens: 0, cost: 1e-9 },
    })
    expect(auditFile(f).ok).toBe(false)
  })

  it('容差不放宽：1.5e-9 的漂移必须现形（mutation guard）', () => {
    // 若容差 1e-9 被改成 2e-9，1.5e-9 的漂移会被静默吞掉。
    const f = file({
      sessions: { s1: { ...row({ calls: 0, inputTokens: 0, outputTokens: 0, cost: 0 }), title: '', createdAt: 0, updatedAt: 0, lastSeq: -1 } },
      daily: { '2026-08-20': { calls: 0, tokens: 0, cost: 1.5e-9 } },
      total: { calls: 0, tokens: 0, cost: 1.5e-9 },
    })
    expect(auditFile(f).ok).toBe(false)
  })

  it('容差不收紧：5e-10 的漂移仍被吸收（mutation guard）', () => {
    // 若容差 1e-9 被改成 1e-10，这个亚纳级的表示误差会被误报为不平衡。
    const f = file({
      sessions: { s1: { ...row({ calls: 0, inputTokens: 0, outputTokens: 0, cost: 0 }), title: '', createdAt: 0, updatedAt: 0, lastSeq: -1 } },
      daily: { '2026-08-20': { calls: 0, tokens: 0, cost: 5e-10 } },
      total: { calls: 0, tokens: 0, cost: 5e-10 },
    })
    expect(auditFile(f).ok).toBe(true)
  })
})

describe('describeAudit', () => {
  it('平衡时输出平衡结论', () => {
    const lines = describeAudit(auditFile(file()))
    expect(lines.some(l => l.includes('对账平衡'))).toBe(true)
  })

  it('漂移时分别指出明细（可修复）与日桶（不可自动修复）', () => {
    const f = file({
      sessions: { s1: { ...row({ calls: 2, cost: 0.6 }), title: '', createdAt: 0, updatedAt: 0, lastSeq: -1 } },
      daily: { '2026-08-20': { calls: 3, tokens: 3_000, cost: 0.9 } },
      total: { calls: 4, tokens: 3_000, cost: 1.2 },
    })
    const lines = describeAudit(auditFile(f)).join('\n')
    expect(lines).toContain('明细漂移')
    expect(lines).toContain('日桶漂移')
    expect(lines).toContain('不可自动修复')
  })

  it('输出契约：零漂移也带 + 号前缀，金额固定 4 位小数（mutation guard）', () => {
    // calls/tokens 漂移为 0、cost 漂移非零：「+0 次调用」必须带 + 号
    // （`>= 0` 若被改成 `>` 或 `>= 1` 会丢前缀）；金额锚定「（」，
    // toFixed(4) 若被改成 toFixed(5) 会多一位小数而现形。
    const f = file({
      sessions: { s1: { ...row({ calls: 0, inputTokens: 0, outputTokens: 0, cost: 0 }), title: '', createdAt: 0, updatedAt: 0, lastSeq: -1 } },
      daily: { '2026-08-20': { calls: 0, tokens: 0, cost: 0.1 } },
      total: { calls: 0, tokens: 0, cost: 0.2 },
    })
    const lines = describeAudit(auditFile(f))
    expect(lines[0]).toContain('¥0.2000；')
    expect(lines[1]).toContain('明细漂移 +0 次调用 / 0 tokens / ¥-0.2000（可修复')
    expect(lines[2]).toContain('日桶漂移 +0 次调用 / 0 tokens / ¥-0.1000（不可自动修复')
  })

  it('输出契约：正漂移带 + 号，千分位格式化生效（mutation guard）', () => {
    const f = file({
      sessions: { s1: { ...row({ calls: 2, cost: 0.6 }), title: '', createdAt: 0, updatedAt: 0, lastSeq: -1 } },
      daily: { '2026-08-20': { calls: 2, tokens: 6_000, cost: 0.6 } },
      total: { calls: 1, tokens: 3_000, cost: 0.5 },
    })
    const lines = describeAudit(auditFile(f))
    expect(lines[1]).toContain('明细漂移 +1 次调用 / 0 tokens / ¥0.1000（可修复')
    expect(lines[2]).toContain('日桶漂移 +1 次调用 / 3,000 tokens / ¥0.1000（不可自动修复')
  })
})
