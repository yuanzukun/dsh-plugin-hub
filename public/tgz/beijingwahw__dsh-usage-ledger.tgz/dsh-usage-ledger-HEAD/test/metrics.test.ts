import { describe, expect, it } from 'vitest'
import { renderPrometheusMetrics } from '../src/metrics.js'

const snap = {
  ledgerRev: 7,
  total: { calls: 42, tokens: 123_456, cost: 3.5 },
  today: { calls: 5, tokens: 1_500, cost: 0.25 },
  sessionsActive: 3,
  sessionsArchived: 12,
  dailyBudget: 10,
  cacheHitRate: 0.75,
  cacheSavingsCny: 1.25,
  peakCostShare: 0.5,
  projectedEodCost: 6,
  projectedMonthEndCost: 90,
  pricingFetchedAtSeconds: 1_787_000_000,
  pricingAgeSeconds: 3_600,
  auditOk: true,
  healthScore: 87,
  lowYieldCount: 1,
  budgetAutopilotCny: 11,
  pvmVolumeEffectCny: 1.2,
  pvmMixEffectCny: -0.3,
  pvmEfficiencyEffectCny: 0.5,
  pvmPriceEffectCny: 0.1,
  unitCostCny: 0.05,
  unitCostUclCny: 0.08,
  spcInControl: false,
  runwayDaysLeft: 12,
  costGiniModels: 0.55,
  paretoTop3ShareModels: 0.9,
  weekdayPeakTroughRatio: 1.8,
}

describe('renderPrometheusMetrics', () => {
  const output = renderPrometheusMetrics(snap)

  it('exposes counters and gauges with HELP/TYPE metadata', () => {
    expect(output).toContain('# TYPE dsh_usage_calls_total counter')
    expect(output).toContain('# HELP dsh_usage_calls_total Lifetime number of priced model calls.')
    expect(output).toContain('# TYPE dsh_usage_cache_hit_rate gauge')
    expect(output).toContain('# TYPE dsh_usage_ledger_rev gauge')
  })

  it('renders numeric values on their own sample lines', () => {
    expect(output).toContain('dsh_usage_calls_total 42')
    expect(output).toContain('dsh_usage_tokens_total 123456')
    expect(output).toContain('dsh_usage_cost_total_cny 3.5')
    expect(output).toContain('dsh_usage_cache_hit_rate 0.75')
    expect(output).toContain('dsh_usage_audit_ok 1')
    expect(output).toContain('dsh_usage_ledger_rev 7')
  })

  it('derives the budget ratio gauge from today cost over budget', () => {
    expect(output).toContain('dsh_usage_budget_daily_ratio 0.025')
  })

  it('exports the PVM attribution effects as signed gauges', () => {
    expect(output).toContain('# TYPE dsh_usage_pvm_volume_effect_cny gauge')
    expect(output).toContain('dsh_usage_pvm_volume_effect_cny 1.2')
    expect(output).toContain('dsh_usage_pvm_mix_effect_cny -0.3')
    expect(output).toContain('dsh_usage_pvm_efficiency_effect_cny 0.5')
    expect(output).toContain('dsh_usage_pvm_price_effect_cny 0.1')
  })

  it('exports the SPC control-chart trio with an alert flag', () => {
    expect(output).toContain('# TYPE dsh_usage_unit_cost_cny gauge')
    expect(output).toContain('dsh_usage_unit_cost_cny 0.05')
    expect(output).toContain('dsh_usage_unit_cost_ucl_cny 0.08')
    expect(output).toContain('dsh_usage_spc_in_control 0')
  })

  it('exports the runway, gini, pareto, and weekday gauges', () => {
    expect(output).toContain('# TYPE dsh_usage_runway_days_left gauge')
    expect(output).toContain('dsh_usage_runway_days_left 12')
    expect(output).toContain('dsh_usage_cost_gini_models 0.55')
    expect(output).toContain('dsh_usage_pareto_top3_share_models 0.9')
    expect(output).toContain('dsh_usage_weekday_peak_trough_ratio 1.8')
  })

  it('never emits NaN or Infinity into the exposition', () => {
    const poisoned = renderPrometheusMetrics({
      ...snap,
      cacheHitRate: Number.NaN,
      projectedEodCost: Number.POSITIVE_INFINITY,
    })
    expect(poisoned).not.toContain('NaN')
    expect(poisoned).not.toContain('Infinity')
    // 被污染的值导出为 0 而不是损坏整个抓取。
    expect(poisoned).toContain('dsh_usage_cache_hit_rate 0')
    expect(poisoned).toContain('dsh_usage_projected_eod_cost_cny 0')
  })

  it('terminates every line with newline (exposition 规范)', () => {
    expect(output.endsWith('\n')).toBe(true)
    for (const line of output.split('\n').slice(0, -1)) {
      expect(line.length).toBeGreaterThan(0)
    }
  })

  it('is byte-stable for the same snapshot (可缓存性)', () => {
    expect(renderPrometheusMetrics(snap)).toBe(output)
  })
})
