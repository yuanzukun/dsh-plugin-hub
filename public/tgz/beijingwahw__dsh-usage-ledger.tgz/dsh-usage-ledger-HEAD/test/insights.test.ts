import { describe, expect, it } from 'vitest'
import {
  alternativeCosts,
  budgetAutopilot,
  buildInsights,
  cacheHitInsight,
  costAttribution,
  dailyProjection,
  dayOfWeekEffect,
  detectAnomalies,
  efficiencyInsight,
  forecastNextCall,
  beijingHm,
  healthScore,
  lowYieldSessions,
  monthlyProjection,
  offPeakOpportunity,
  paretoOf,
  runwayOf,
  sumCounters,
  unitCostControl,
  WEEKDAY_LABELS,
} from '../src/insights.js'
import type { RecentSample } from '../src/insights.js'
import type { UsageCounters } from '../src/types.js'

const counters = (over: Partial<UsageCounters> = {}): UsageCounters => ({
  calls: 0, inputTokens: 0, outputTokens: 0, cacheReadTokens: 0, cacheWriteTokens: 0, reasoningTokens: 0, cost: 0,
  ...over,
})

const sample = (over: Partial<RecentSample> = {}): RecentSample => ({
  time: 1, sessionId: 's1', cost: 1, ...over,
})

describe('cacheHitInsight', () => {
  it('computes the hit rate over cache reads plus uncached input', () => {
    const insight = cacheHitInsight(counters({ calls: 4, inputTokens: 100, cacheReadTokens: 300 }))
    expect(insight.hitRate).toBeCloseTo(0.75)
    expect(insight.calls).toBe(4)
  })

  it('reports zero rate on empty counters without dividing by zero', () => {
    expect(cacheHitInsight(counters()).hitRate).toBe(0)
  })
})

describe('dailyProjection', () => {
  const now = Date.parse('2026-08-20T04:00:00+08:00') // 4h into the Beijing day

  it('extrapolates the end-of-day cost from the burn pace', () => {
    const projection = dailyProjection(now, 8, 0)
    expect(projection.hoursElapsed).toBe(4)
    expect(projection.pacePerHour).toBeCloseTo(2)
    expect(projection.projectedEodCost).toBeCloseTo(48)
    expect(projection.projectedExceed).toBe(false)
  })

  it('predicts the exceed time when the pace overshoots the budget', () => {
    const projection = dailyProjection(now, 8, 24)
    expect(projection.projectedExceed).toBe(true)
    expect(projection.exceedAt).toBeDefined()
    // 16 CNY remaining at 2/h → 8h later = 12:00 Beijing.
    expect(beijingHm(projection.exceedAt!)).toBe('12:00')
  })

  it('stays calm under a comfortable budget', () => {
    const projection = dailyProjection(now, 8, 100)
    expect(projection.projectedExceed).toBe(false)
    expect(projection.exceedAt).toBeUndefined()
  })

  it('clamps the elapsed-time floor for the first minutes of a day', () => {
    const midnight = Date.parse('2026-08-20T00:05:00+08:00')
    const projection = dailyProjection(midnight, 1, 1)
    expect(projection.hoursElapsed).toBe(0.25)
    expect(projection.pacePerHour).toBeCloseTo(4)
  })
})

describe('detectAnomalies', () => {
  it('flags robust-score outliers above 3.5 (MAD)', () => {
    const samples = [
      ...Array.from({ length: 19 }, (_, i) => sample({ time: i, cost: 1 })),
      sample({ time: 99, sessionId: 'spike', model: 'deepseek-v4-pro', cost: 100 }),
    ]
    const anomalies = detectAnomalies(samples)
    expect(anomalies).toHaveLength(1)
    expect(anomalies[0]?.sessionId).toBe('spike')
    expect(anomalies[0]?.cost).toBe(100)
    expect(anomalies[0]?.zScore).toBeGreaterThan(3.5)
  })

  it('resists masking: a burst of spikes cannot hide each other', () => {
    // 反例验证经典 z-score 的 masking 缺陷被修复：3 个 100 元离群 + 17 个 1 元常规。
    // 经典法里 3 个离群把均值拉到 ~16.9、σ 拉到 ~37.4，z≈2.2 → 全部漏检；
    // MAD 的中位数仍是 1，三个离群全部现形。
    const samples = [
      ...Array.from({ length: 17 }, (_, i) => sample({ time: i, cost: 1 })),
      ...Array.from({ length: 3 }, (_, i) => sample({ time: 100 + i, sessionId: `spike${i}`, cost: 100 })),
    ]
    const anomalies = detectAnomalies(samples)
    expect(anomalies).toHaveLength(3)
  })

  it('needs at least 8 samples and nonzero scale', () => {
    expect(detectAnomalies([sample({ cost: 100 })])).toEqual([])
    expect(detectAnomalies(Array.from({ length: 10 }, () => sample({ cost: 1 })))).toEqual([])
  })
})

describe('alternativeCosts', () => {
  const usage = { inputTokens: 1_000_000, outputTokens: 1_000_000 }
  const vendorOf = (model: string): string | undefined => (model.startsWith('glm') ? 'zhipu' : undefined)
  const priceOf = (model: string) =>
    model === 'glm-4.6' ? { inputCacheHit: 0.5, inputMiss: 2.5, output: 10 } : undefined

  it('computes the counterfactual cost and skips used / unpriced models', () => {
    const alts = alternativeCosts(usage, 20, new Set(['deepseek-v4-pro']), vendorOf, priceOf)
    expect(alts).toHaveLength(1)
    expect(alts[0]).toMatchObject({ model: 'glm-4.6', vendor: 'zhipu', currentCost: 20, alternativeCost: 12.5 })
    expect(alts[0]?.savingsRatio).toBeCloseTo(0.375)
  })

  it('returns nothing without usage or spend', () => {
    expect(alternativeCosts({ inputTokens: 0, outputTokens: 0 }, 20, new Set(), vendorOf, priceOf)).toEqual([])
    expect(alternativeCosts(usage, 0, new Set(), vendorOf, priceOf)).toEqual([])
  })
})

describe('sumCounters', () => {
  it('sums every counter field across rows', () => {
    const total = sumCounters([
      counters({ calls: 1, inputTokens: 10, outputTokens: 5, cacheReadTokens: 2, cost: 0.1 }),
      counters({ calls: 2, inputTokens: 20, outputTokens: 15, cacheWriteTokens: 3, reasoningTokens: 7, cost: 0.2 }),
    ])
    expect(total.calls).toBe(3)
    expect(total.inputTokens).toBe(30)
    expect(total.outputTokens).toBe(20)
    expect(total.cacheReadTokens).toBe(2)
    expect(total.cacheWriteTokens).toBe(3)
    expect(total.reasoningTokens).toBe(7)
    expect(total.cost).toBeCloseTo(0.3)
  })
})

describe('efficiencyInsight', () => {
  const priceOf = (model: string) =>
    model === 'glm-4.6' ? { inputCacheHit: 0.5, inputMiss: 2.5, output: 10 } : undefined

  it('prices cache savings from the per-row model', () => {
    const rows = [
      { ...counters({ inputTokens: 100, outputTokens: 50, cacheReadTokens: 1_000_000, cost: 5 }), model: 'glm-4.6' },
      counters({ inputTokens: 10, outputTokens: 5, cost: 1 }), // no model → no savings
    ]
    const eff = efficiencyInsight(rows, priceOf)
    // 1M × (2.5 − 0.5) / 1e6 = 2 CNY saved.
    expect(eff.cacheSavingsCny).toBeCloseTo(2)
    const totalTokens = 100 + 50 + 1_000_000 + 10 + 5
    expect(eff.outputRatio).toBeCloseTo(55 / totalTokens)
    expect(eff.tokensPerCny).toBeCloseTo(totalTokens / 6)
  })

  it('ignores models whose hit price is not cheaper', () => {
    const rows = [{ ...counters({ cacheReadTokens: 500_000 }), model: 'flat-model' }]
    expect(efficiencyInsight(rows, () => ({ inputCacheHit: 2, inputMiss: 2, output: 2 })).cacheSavingsCny).toBe(0)
  })

  it('computes the reasoning share of output', () => {
    const rows = [counters({ outputTokens: 400, reasoningTokens: 300 })]
    expect(efficiencyInsight(rows, priceOf).reasoningRatio).toBeCloseTo(0.75)
  })
})

describe('offPeakOpportunity', () => {
  // 北京时间峰窗口 [9,12)、[14,18)：10 点峰，13 点谷，20 点谷。
  const peak = Date.parse('2026-08-20T10:00:00+08:00')
  const valley = Date.parse('2026-08-20T13:00:00+08:00')
  const evening = Date.parse('2026-08-20T20:00:00+08:00')

  it('counts only DeepSeek samples and splits cost by peak windows', () => {
    const result = offPeakOpportunity([
      sample({ time: peak, model: 'deepseek-v4-pro', cost: 3 }),
      sample({ time: peak, model: 'deepseek-v4-flash', cost: 1 }),
      sample({ time: valley, model: 'deepseek-v4-pro', cost: 1 }),
      sample({ time: evening, model: 'deepseek-v4-pro', cost: 1 }),
      sample({ time: peak, model: 'glm-4.6', cost: 100 }), // 非 DeepSeek：不计入
    ])
    expect(result.samples).toBe(4)
    expect(result.peakCallShare).toBeCloseTo(0.5)
    expect(result.peakCostShare).toBeCloseTo(4 / 6)
  })

  it('returns zero shares on no deepseek samples', () => {
    const result = offPeakOpportunity([sample({ time: peak, model: 'glm-4.6', cost: 1 })])
    expect(result).toEqual({ samples: 0, peakCostShare: 0, peakCallShare: 0 })
  })

  it('14:00 整点进入晚峰（边界含起点）', () => {
    const edge = Date.parse('2026-08-20T14:00:00+08:00')
    expect(offPeakOpportunity([sample({ time: edge, model: 'deepseek-v4-pro', cost: 1 })]).peakCallShare).toBe(1)
    // 18:00 整点已出峰（区间不含终点）。
    const out = Date.parse('2026-08-20T18:00:00+08:00')
    expect(offPeakOpportunity([sample({ time: out, model: 'deepseek-v4-pro', cost: 1 })]).peakCallShare).toBe(0)
  })
})

describe('forecastNextCall', () => {
  const priceOf = (model: string) =>
    model === 'glm-4.6' ? { inputCacheHit: 0.5, inputMiss: 2.5, output: 10 } : undefined
  const now = Date.parse('2026-08-20T10:00:00+08:00')

  it('extrapolates a growing context linearly', () => {
    const samples = [
      sample({ time: now, sessionId: 's1', model: 'glm-4.6', cost: 1, inputTokens: 10_000 }),
      sample({ time: now + 1, sessionId: 's1', model: 'glm-4.6', cost: 1, inputTokens: 20_000 }),
      sample({ time: now + 2, sessionId: 's1', model: 'glm-4.6', cost: 1, inputTokens: 30_000 }),
    ]
    const forecast = forecastNextCall(samples, 's1', priceOf)
    expect(forecast).toBeDefined()
    // 线性外推：步长 10k，下一次 40k；成本 40k × 2.5 / 1M = 0.1 元。
    expect(forecast!.nextInputTokens).toBeCloseTo(40_000)
    expect(forecast!.nextInputCost).toBeCloseTo(0.1)
  })

  it('stays at least at the last input for shrinking windows', () => {
    const samples = [
      sample({ time: now, sessionId: 's1', model: 'glm-4.6', cost: 1, inputTokens: 50_000 }),
      sample({ time: now + 1, sessionId: 's1', model: 'glm-4.6', cost: 1, inputTokens: 30_000 }),
      sample({ time: now + 2, sessionId: 's1', model: 'glm-4.6', cost: 1, inputTokens: 20_000 }),
    ]
    const forecast = forecastNextCall(samples, 's1', priceOf)
    // 外推为负时以下限保护：不小于最后一次实际输入。
    expect(forecast!.nextInputTokens).toBeGreaterThanOrEqual(20_000)
  })

  it('requires at least 3 same-session samples with input sizes', () => {
    expect(forecastNextCall([
      sample({ time: now, sessionId: 's1', model: 'glm-4.6', cost: 1, inputTokens: 10_000 }),
      sample({ time: now + 1, sessionId: 's1', model: 'glm-4.6', cost: 1 }),
    ], 's1', priceOf)).toBeUndefined()
    // 其它会话的样本不算数。
    expect(forecastNextCall([
      sample({ time: now, sessionId: 'other', model: 'glm-4.6', cost: 1, inputTokens: 10_000 }),
      sample({ time: now + 1, sessionId: 'other', model: 'glm-4.6', cost: 1, inputTokens: 10_000 }),
      sample({ time: now + 2, sessionId: 'other', model: 'glm-4.6', cost: 1, inputTokens: 10_000 }),
    ], 's1', priceOf)).toBeUndefined()
  })
})

describe('cost breakdown attribution', () => {
  const priceOf = (model: string) =>
    model === 'glm-4.6' ? { inputCacheHit: 0.5, inputMiss: 2.5, output: 10 } : undefined

  it('attributes every yuan to input/output/cache-write/cache-read', () => {
    const rows = [{
      ...counters({ inputTokens: 1_000_000, outputTokens: 1_000_000, cacheReadTokens: 2_000_000, cacheWriteTokens: 500_000, cost: 20 }),
      model: 'glm-4.6',
    }]
    const eff = efficiencyInsight(rows, priceOf)
    expect(eff.breakdown.inputCost).toBeCloseTo(2.5)
    expect(eff.breakdown.outputCost).toBeCloseTo(10)
    expect(eff.breakdown.cacheWriteCost).toBeCloseTo(1.25)
    expect(eff.breakdown.cacheReadCost).toBeCloseTo(1)
  })

  it('yields all-zero breakdown without a per-row model price', () => {
    const eff = efficiencyInsight([counters({ inputTokens: 1_000, outputTokens: 1_000, cost: 1 })], priceOf)
    expect(eff.breakdown).toEqual({ inputCost: 0, outputCost: 0, cacheWriteCost: 0, cacheReadCost: 0 })
  })
})

describe('monthlyProjection', () => {
  // 2026-08-20：八月 31 天，剩 11 天。
  const now = Date.parse('2026-08-20T12:00:00+08:00')

  it('extrapolates a rising daily trend to month end', () => {
    const daily = [
      { day: '2026-08-17', cost: 1 },
      { day: '2026-08-18', cost: 2 },
      { day: '2026-08-19', cost: 3 },
      { day: '2026-08-20', cost: 4 },
    ]
    const proj = monthlyProjection(now, daily)
    expect(proj.daysObserved).toBe(4)
    expect(proj.monthToDateCost).toBeCloseTo(10)
    // 等差 +1/天：斜率 1，外推 = 10 + 1 × 11 = 21。
    expect(proj.slopePerDay).toBeCloseTo(1)
    expect(proj.daysRemaining).toBe(11)
    expect(proj.projectedMonthEndCost).toBeCloseTo(21)
  })

  it('ignores previous-month buckets in month-to-date but keeps them in the trend', () => {
    const daily = [
      { day: '2026-07-31', cost: 100 },
      { day: '2026-08-19', cost: 2 },
      { day: '2026-08-20', cost: 4 },
    ]
    const proj = monthlyProjection(now, daily)
    expect(proj.monthToDateCost).toBeCloseTo(6)
    // 趋势由全部日桶拟合：手动最小二乘 [100,2,4] 的斜率恰为 -48。
    expect(proj.slopePerDay).toBeCloseTo(-48)
    // 负趋势触发下限保护：月末投影仍不高于月至今。
    expect(proj.projectedMonthEndCost).toBeCloseTo(6)
  })

  it('clamps a declining trend to zero growth (月末不会低于月至今)', () => {
    const daily = [
      { day: '2026-08-18', cost: 5 },
      { day: '2026-08-19', cost: 3 },
      { day: '2026-08-20', cost: 1 },
    ]
    const proj = monthlyProjection(now, daily)
    expect(proj.slopePerDay).toBeLessThan(0)
    expect(proj.projectedMonthEndCost).toBeCloseTo(proj.monthToDateCost)
  })

  it('returns zeros for an empty window', () => {
    const proj = monthlyProjection(now, [])
    expect(proj.monthToDateCost).toBe(0)
    expect(proj.slopePerDay).toBe(0)
    expect(proj.projectedMonthEndCost).toBe(0)
  })

  it('handles the last day of the month with zero days remaining', () => {
    const endOfMonth = Date.parse('2026-08-31T12:00:00+08:00')
    const proj = monthlyProjection(endOfMonth, [{ day: '2026-08-31', cost: 2 }])
    expect(proj.daysRemaining).toBe(0)
    expect(proj.projectedMonthEndCost).toBeCloseTo(2)
  })
})

describe('buildInsights', () => {
  const now = Date.parse('2026-08-20T04:00:00+08:00')

  it('emits actionable notes for a low hit rate, savings, a hot pace, an anomaly, and a cheaper model', () => {
    const rows = [{
      ...counters({ calls: 10, inputTokens: 100_000, cacheReadTokens: 10_000, outputTokens: 50_000, cost: 20 }),
      model: 'glm-4.6',
    }]
    const samples = [
      ...Array.from({ length: 19 }, (_, i) => sample({ time: i, cost: 0.02 })),
      sample({ time: 99, sessionId: 's1', model: 'deepseek-v4-pro', cost: 5 }),
    ]
    const set = buildInsights(
      now,
      rows,
      20,
      8,
      24,
      new Set(['deepseek-v4-pro']),
      samples,
      (m) => (m.startsWith('glm') ? 'zhipu' : undefined),
      (m) => (m === 'glm-4.6' ? { inputCacheHit: 0.5, inputMiss: 2.5, output: 10 } : undefined),
    )
    expect(set.cache.hitRate).toBeCloseTo(10_000 / 110_000)
    expect(set.projection.projectedEodCost).toBeCloseTo(48)
    expect(set.anomalies).toHaveLength(1)
    expect(set.alternatives[0]?.model).toBe('glm-4.6')
    expect(set.efficiency.cacheSavingsCny).toBeCloseTo(10_000 * 2 / 1_000_000)
    const joined = set.notes.join('\n')
    expect(joined).toContain('前缀缓存命中率')
    expect(joined).toContain('节省约')
    expect(joined).toContain('燃烧速率')
    expect(joined).toContain('异常高价调用')
    expect(joined).toContain('glm-4.6')
  })

  it('stays quiet on a healthy ledger', () => {
    const set = buildInsights(
      now,
      [counters({ calls: 10, inputTokens: 1, cacheReadTokens: 999, outputTokens: 1 })],
      1,
      0.1,
      0,
      new Set(),
      [],
      () => undefined,
      () => undefined,
    )
    expect(set.notes).toEqual([])
    expect(set.anomalies).toEqual([])
    expect(set.alternatives).toEqual([])
    expect(set.efficiency.cacheSavingsCny).toBe(0)
  })

  it('derives the health score, low-yield findings, and the budget suggestion in one pass', () => {
    const set = buildInsights(
      now,
      [{
        ...counters({ calls: 30, inputTokens: 400_000, cacheReadTokens: 100_000, outputTokens: 2_000, cost: 12 }),
        model: 'glm-4.6',
        id: 's1',
        title: '通读大仓库',
      }],
      12,
      8,
      24,
      new Set(),
      [],
      () => undefined,
      () => undefined,
      Array.from({ length: 10 }, (_, i) => ({ day: `2026-08-${i + 11}`, cost: 10 })),
    )
    // 产出占比 = 2000/502000 ≈ 0.4% < 2%，输入 ≥ 200k → 命中低产出。
    expect(set.lowYield).toHaveLength(1)
    expect(set.lowYield[0]?.sessionId).toBe('s1')
    expect(set.lowYield[0]?.title).toBe('通读大仓库')
    // P90 = 10（全同），建议 = 10 × 1.1 = 11；当前预算 24 偏离 > 20% → 不一致。
    expect(set.budget?.suggestedDailyBudget).toBeCloseTo(11)
    expect(set.budget?.aligned).toBe(false)
    // 五维中：缓存命中 100%（10 万/50 万）、节奏超支 24/48、产出 0.4%/20% 满分线。
    expect(set.health.score).toBeGreaterThan(0)
    expect(set.health.components.length).toBeGreaterThan(0)
    const joined = set.notes.join('\n')
    expect(joined).toContain('低产出会话')
    expect(joined).toContain('预算自动驾驶')
  })
})

describe('healthScore', () => {
  const proj = (projectedEodCost: number, dailyBudget: number) => ({
    hoursElapsed: 4, pacePerHour: projectedEodCost / 4, projectedEodCost, dailyBudget, projectedExceed: false,
  })

  it('averages the applicable dimensions equally into a 0-100 score', () => {
    const health = healthScore({
      cache: { calls: 8, hitRate: 0.8, cacheReadTokens: 800, inputTokens: 200 },
      projection: proj(5, 10),
      dailyBudget: 10,
      anomalyCount: 1,
      recentCount: 10,
      offPeak: { samples: 8, peakCostShare: 0.3, peakCallShare: 0.3 },
      usageTotals: counters({ inputTokens: 1000, outputTokens: 300 }),
    })
    // 命中 0.8 + 节奏 1 + 稳定 0.9 + 峰谷 0.7 + 产出 1（300/1300 ≈ 23% 已达满分线）。
    expect(health.components.map(c => c.key)).toEqual(['cache', 'pacing', 'stability', 'offpeak', 'yield'])
    expect(health.score).toBe(Math.round(((0.8 + 1 + 0.9 + 0.7 + 1) / 5) * 100))
    expect(health.grade).toBe('excellent')
  })

  it('abstains entirely when no dimension has enough data (score 0, not a fake F)', () => {
    const health = healthScore({
      cache: { calls: 2, hitRate: 0, cacheReadTokens: 0, inputTokens: 0 },
      projection: proj(0, 0),
      dailyBudget: 0,
      anomalyCount: 0,
      recentCount: 0,
      offPeak: { samples: 0, peakCostShare: 0, peakCallShare: 0 },
      usageTotals: counters(),
    })
    expect(health.components).toEqual([])
    expect(health.score).toBe(0)
    expect(health.grade).toBe('poor')
  })

  it('scores the pacing dimension by the overrun ratio when projected over budget', () => {
    const health = healthScore({
      cache: { calls: 0, hitRate: 0, cacheReadTokens: 0, inputTokens: 0 },
      projection: proj(20, 10),
      dailyBudget: 10,
      anomalyCount: 0,
      recentCount: 0,
      offPeak: { samples: 0, peakCostShare: 0, peakCallShare: 0 },
      usageTotals: counters(),
    })
    expect(health.components).toHaveLength(1)
    expect(health.components[0]?.key).toBe('pacing')
    expect(health.components[0]?.ratio).toBeCloseTo(0.5)
  })
})

describe('lowYieldSessions', () => {
  it('flags sessions with huge input and tiny output, skipping the rest', () => {
    const rows = [
      { ...counters({ inputTokens: 200_000, outputTokens: 1_000, cost: 10 }), id: 's1' },
      { ...counters({ inputTokens: 100_000, outputTokens: 1_000, cost: 5 }), id: 's2' },
      { ...counters({ inputTokens: 300_000, outputTokens: 30_000, cost: 8 }), id: 's3' },
      counters({ inputTokens: 500_000, outputTokens: 100, cost: 50 }),
    ]
    const result = lowYieldSessions(rows)
    expect(result).toHaveLength(1)
    expect(result[0]?.sessionId).toBe('s1')
    expect(result[0]?.inputTokens).toBe(200_000)
    expect(result[0]?.outputRatio).toBeCloseTo(1_000 / 201_000)
  })

  it('keeps only the three most expensive findings, cost-ranked', () => {
    const rows = Array.from({ length: 5 }, (_, i) => ({
      ...counters({ inputTokens: 250_000, outputTokens: 1_000, cost: 10 - i }),
      id: `s${i}`,
    }))
    const result = lowYieldSessions(rows)
    expect(result).toHaveLength(3)
    expect(result.map(r => r.sessionId)).toEqual(['s0', 's1', 's2'])
  })

  it('treats empty titles as absent for display', () => {
    const result = lowYieldSessions([{ ...counters({ inputTokens: 250_000, outputTokens: 1, cost: 1 }), id: 's1', title: '' }])
    expect(result[0]?.title).toBeUndefined()
  })
})

describe('budgetAutopilot', () => {
  it('suggests a budget from the P90 of daily costs with a 10% headroom', () => {
    // 27 个常态日（0..26）+ 3 个尖峰日（100）：P90 落在 26 与 100 之间。
    const daily = Array.from({ length: 30 }, (_, i) => ({ day: `2026-08-${i + 1}`, cost: i < 27 ? i : 100 }))
    const suggestion = budgetAutopilot(daily, 0)
    expect(suggestion?.daysObserved).toBe(30)
    expect(suggestion?.percentile90).toBeCloseTo(26 + (100 - 26) * 0.1)
    expect(suggestion?.suggestedDailyBudget).toBeCloseTo((26 + 7.4) * 1.1)
    expect(suggestion?.aligned).toBe(false)
  })

  it('returns undefined below the seven-day observation floor', () => {
    expect(budgetAutopilot([{ day: '2026-08-01', cost: 1 }], 0)).toBeUndefined()
    expect(budgetAutopilot([], 10)).toBeUndefined()
  })

  it('returns undefined when every observed day was free', () => {
    const daily = Array.from({ length: 10 }, (_, i) => ({ day: `2026-08-${i + 1}`, cost: 0 }))
    expect(budgetAutopilot(daily, 10)).toBeUndefined()
  })

  it('marks the current budget aligned within ±20%', () => {
    const daily = Array.from({ length: 10 }, (_, i) => ({ day: `2026-08-${i + 1}`, cost: 10 }))
    // P90 = 10，建议 11；当前 12 偏离 9% → 一致。
    expect(budgetAutopilot(daily, 12)?.aligned).toBe(true)
    // 当前 20 偏离 82% → 不一致。
    expect(budgetAutopilot(daily, 20)?.aligned).toBe(false)
  })
})

describe('costAttribution', () => {
  // 时间中点切窗：基线 t=1..8，当前 t≥101（mid 落在 54.5 附近，切分无歧义）。
  const calls = (n: number, base: Partial<RecentSample>, from: number): RecentSample[] =>
    Array.from({ length: n }, (_, i) => sample({ time: from + i, ...base }))

  it('attributes a pure call-volume increase entirely to the volume effect', () => {
    const a = costAttribution([
      ...calls(8, { cost: 1, inputTokens: 100, outputTokens: 50 }, 1),
      ...calls(16, { cost: 1, inputTokens: 100, outputTokens: 50 }, 101),
    ])
    expect(a).toBeDefined()
    expect(a!.volumeEffect).toBeCloseTo(8)
    expect(a!.mixEffect).toBeCloseTo(0)
    expect(a!.efficiencyEffect).toBeCloseTo(0)
    expect(a!.priceEffect).toBeCloseTo(0)
    expect(a!.currentCost - a!.baselineCost).toBeCloseTo(8)
    expect(a!.changeRatio).toBeCloseTo(1)
  })

  it('attributes a pure unit-price increase entirely to the price effect', () => {
    const a = costAttribution([
      ...calls(8, { cost: 1, inputTokens: 100, outputTokens: 50 }, 1),
      ...calls(8, { cost: 2, inputTokens: 100, outputTokens: 50 }, 101),
    ])
    expect(a!.volumeEffect).toBeCloseTo(0)
    expect(a!.mixEffect).toBeCloseTo(0)
    expect(a!.efficiencyEffect).toBeCloseTo(0)
    expect(a!.priceEffect).toBeCloseTo(8)
  })

  it('attributes a pure context growth (tokens per call) to the efficiency effect', () => {
    const a = costAttribution([
      ...calls(8, { cost: 1, inputTokens: 100, outputTokens: 50 }, 1),
      ...calls(8, { cost: 2, inputTokens: 200, outputTokens: 100 }, 101),
    ])
    expect(a!.volumeEffect).toBeCloseTo(0)
    expect(a!.mixEffect).toBeCloseTo(0)
    expect(a!.efficiencyEffect).toBeCloseTo(8)
    expect(a!.priceEffect).toBeCloseTo(0)
  })

  it('attributes switching to a pricier model to the mix effect', () => {
    const a = costAttribution([
      ...calls(8, { cost: 1, model: 'a', inputTokens: 100, outputTokens: 50 }, 1),
      ...calls(8, { cost: 2, model: 'b', inputTokens: 100, outputTokens: 50 }, 101),
    ])
    expect(a!.volumeEffect).toBeCloseTo(0)
    expect(a!.mixEffect).toBeCloseTo(8)
    expect(a!.efficiencyEffect).toBeCloseTo(0)
    expect(a!.priceEffect).toBeCloseTo(0)
    expect(a!.currentCost - a!.baselineCost).toBeCloseTo(8)
  })

  it('keeps the four effects exactly additive on a mixed scenario (no residual)', () => {
    const a = costAttribution([
      ...calls(8, { cost: 1, model: 'a', inputTokens: 100, outputTokens: 50 }, 1),
      ...calls(2, { cost: 1, model: 'a', inputTokens: 200, outputTokens: 100 }, 101),
      ...calls(6, { cost: 3, model: 'b', inputTokens: 300, outputTokens: 150 }, 103),
    ])
    expect(a).toBeDefined()
    expect(
      a!.volumeEffect + a!.mixEffect + a!.efficiencyEffect + a!.priceEffect,
    ).toBeCloseTo(a!.currentCost - a!.baselineCost)
  })

  it('returns undefined below the sample floor or on a lopsided split', () => {
    expect(costAttribution([])).toBeUndefined()
    // 15 个样本：不足 16。
    expect(costAttribution(calls(15, { cost: 1 }, 1))).toBeUndefined()
    // 17 个样本，但时间中点切分后当前窗只有 3 个（<8）。
    expect(costAttribution([
      ...calls(14, { cost: 1 }, 1),
      ...calls(3, { cost: 1 }, 100),
    ])).toBeUndefined()
  })
})

describe('unitCostControl', () => {
  // 7 个基线日：unit = 0.040..0.046（中位 0.043）。
  const baselineDays = Array.from({ length: 7 }, (_, i) => ({
    day: `2026-08-1${i}`, calls: 10, cost: 0.4 + i * 0.01,
  }))
  const latestDay = (cost: number): { day: string; calls: number; cost: number } =>
    ({ day: '2026-08-17', calls: 10, cost })

  it('raises a cost-regression alert when the latest day exceeds the UCL', () => {
    const spc = unitCostControl([...baselineDays, latestDay(5)])
    expect(spc).toBeDefined()
    expect(spc!.status).toBe('above')
    expect(spc!.latestUnitCost).toBeCloseTo(0.5)
    expect(spc!.daysObserved).toBe(7)
    expect(spc!.latestDay).toBe('2026-08-17')
    expect(spc!.baselineUnitCost).toBeCloseTo(0.043)
    expect(spc!.ucl).toBeGreaterThan(spc!.baselineUnitCost)
  })

  it('stays in control when the latest day is within the limits', () => {
    const spc = unitCostControl([...baselineDays, latestDay(0.43)])
    expect(spc!.status).toBe('in')
    expect(spc!.lcl).toBeLessThanOrEqual(spc!.latestUnitCost)
    expect(spc!.latestUnitCost).toBeLessThanOrEqual(spc!.ucl)
  })

  it('flags a significant improvement when the latest day breaks the LCL', () => {
    const spc = unitCostControl([...baselineDays, latestDay(0.01)])
    expect(spc!.status).toBe('below')
  })

  it('clamps the LCL at zero so free days are not flagged as improvements', () => {
    // 大噪声基线（unit 0.01/0.1 交替）：3σ 下限为负 → 截断为 0，
    // 免费日（unit = 0）不小于 0 → 不误报「显著改善」。
    const noisy = [0.1, 1, 0.1, 1, 0.1, 1, 0.1].map((cost, i) => ({
      day: `2026-08-1${i}`, calls: 10, cost,
    }))
    const spc = unitCostControl([...noisy, { day: '2026-08-17', calls: 5, cost: 0 }])
    expect(spc!.lcl).toBe(0)
    expect(spc!.status).toBe('in')
  })

  it('skips empty days and returns undefined below the seven-active-day floor', () => {
    expect(unitCostControl([{ day: '2026-08-01', calls: 0, cost: 0 }])).toBeUndefined()
    const sparse = [
      ...baselineDays.slice(0, 5),
      { day: '2026-08-16', calls: 0, cost: 0 },
      latestDay(0.43),
    ]
    // 活跃日仅 6 天（5 基线 + 1 最新）→ 观测不足。
    expect(unitCostControl(sparse)).toBeUndefined()
    const dense = [
      ...baselineDays,
      { day: '2026-08-17', calls: 0, cost: 0 },
      latestDay(0.43),
    ]
    // 空日被跳过：7 基线 + 最新日仍可判定，最新日为最后一个活跃日。
    const spc = unitCostControl(dense)
    expect(spc!.latestDay).toBe('2026-08-17')
    expect(spc!.status).toBe('in')
  })
})

describe('paretoOf', () => {
  it('returns gini 0 for a perfectly even distribution', () => {
    const p = paretoOf([
      { key: 'a', cost: 10 }, { key: 'b', cost: 10 }, { key: 'c', cost: 10 }, { key: 'd', cost: 10 },
    ])
    expect(p).toBeDefined()
    expect(p!.gini).toBeCloseTo(0)
    expect(p!.top3Share).toBeCloseTo(0.75)
    expect(p!.fewCount).toBe(4) // 均匀分布：80% 需要 4 个实体
  })

  it('returns near-1 gini and fewCount 1 when a single entity dominates', () => {
    // 10 个实体：基尼上限 (n−1)/n = 0.9，独占场景逼近该上限。
    const entries = [{ key: 'a', cost: 1000 }, ...Array.from({ length: 9 }, (_, i) => ({ key: `m${i}`, cost: 1 }))]
    const p = paretoOf(entries)
    expect(p!.gini).toBeGreaterThan(0.8)
    expect(p!.fewCount).toBe(1)
    expect(p!.items[0]!.key).toBe('a')
    expect(p!.items[0]!.share).toBeCloseTo(1000 / 1009)
  })

  it('builds a monotone cumulative series and matches the 80/20 shape', () => {
    const p = paretoOf([
      { key: 'a', cost: 50 }, { key: 'b', cost: 25 }, { key: 'c', cost: 15 }, { key: 'd', cost: 10 },
    ])
    const cums = p!.items.map(i => i.cumulative)
    for (let i = 1; i < cums.length; i++) expect(cums[i]!).toBeGreaterThan(cums[i - 1]!)
    expect(cums[2]!).toBeCloseTo(0.9) // 前 3 个占 90%
    expect(p!.fewCount).toBe(3) // 前 2 个占 75% < 80%，第 3 个达 90% → 关键少数 = 3
  })

  it('drops zero-cost entities and abstains below four actives', () => {
    expect(paretoOf([{ key: 'a', cost: 5 }, { key: 'b', cost: 0 }, { key: 'c', cost: 3 }])).toBeUndefined()
    expect(paretoOf([{ key: 'a', cost: 0 }, { key: 'b', cost: 0 }])).toBeUndefined()
    const p = paretoOf([
      { key: 'a', cost: 5 }, { key: 'b', cost: 0 }, { key: 'c', cost: 3 }, { key: 'd', cost: 2 }, { key: 'e', cost: 1 },
    ])
    expect(p!.count).toBe(4)
  })
})

describe('runwayOf', () => {
  const now = Date.parse('2026-08-20T12:00:00+08:00')
  // 10 个活跃日每天 3 元 → 燃烧率 3 元/天；2 个免费日被排除。
  const daily = [
    ...Array.from({ length: 10 }, (_, i) => ({ day: `2026-08-${i + 1}`, cost: 3 })),
    { day: '2026-08-11', cost: 0 },
    { day: '2026-08-12', cost: 0 },
  ]

  it('computes days left from the active-day burn rate', () => {
    const r = runwayOf(now, 100, 40, daily)
    expect(r).toBeDefined()
    expect(r!.dailyBurn).toBeCloseTo(3)
    expect(r!.remaining).toBeCloseTo(60)
    expect(r!.daysLeft).toBeCloseTo(20)
    expect(r!.exhaustedBy).toBe('2026-09-09')
    expect(r!.burnDays).toBe(10)
  })

  it('reports overspending as a negative runway', () => {
    const r = runwayOf(now, 100, 130, daily)
    expect(r!.remaining).toBeCloseTo(-30)
    expect(r!.daysLeft).toBeCloseTo(-10)
    expect(r!.exhaustedBy).toBeNull()
  })

  it('returns an infinite runway when every observed day was free', () => {
    const free = Array.from({ length: 5 }, (_, i) => ({ day: `2026-08-${i + 1}`, cost: 0 }))
    const r = runwayOf(now, 100, 0, free)
    expect(r).toBeDefined()
    expect(r!.daysLeft).toBe(Number.POSITIVE_INFINITY)
    expect(r!.exhaustedBy).toBeNull()
  })

  it('abstains without a total budget or enough observed days', () => {
    expect(runwayOf(now, 0, 10, daily)).toBeUndefined()
    expect(runwayOf(now, 100, 10, daily.slice(0, 2))).toBeUndefined()
  })
})

describe('dayOfWeekEffect', () => {
  // 2026-08-24 是周一：两周，每周一 10 元、其余每天 1 元。
  const mondaysExpensive = Array.from({ length: 14 }, (_, i) => {
    const day = new Date(Date.UTC(2026, 7, 24 + i)).toISOString().slice(0, 10)
    return { day, cost: day === '2026-08-24' || day === '2026-08-31' ? 10 : 1 }
  })

  it('detects a significant Monday peak from two full weeks', () => {
    const w = dayOfWeekEffect(mondaysExpensive)
    expect(w).toBeDefined()
    expect(w!.peakWeekday).toBe(0)
    expect(w!.averages[0]).toBeCloseTo(10)
    expect(w!.averages[1]).toBeCloseTo(1)
    expect(w!.peakTroughRatio).toBeCloseTo(10)
    expect(w!.significant).toBe(true)
    expect(w!.weekdaysCovered).toBe(7)
    expect(WEEKDAY_LABELS[w!.peakWeekday]).toBe('周一')
  })

  it('stays insignificant on an even weekly rhythm', () => {
    const even = mondaysExpensive.map(d => ({ day: d.day, cost: 3 }))
    const w = dayOfWeekEffect(even)
    expect(w!.peakTroughRatio).toBeCloseTo(1)
    expect(w!.significant).toBe(false)
  })

  it('abstains below ten observed days', () => {
    expect(dayOfWeekEffect(mondaysExpensive.slice(0, 9))).toBeUndefined()
  })
})
