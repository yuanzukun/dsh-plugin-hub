import { afterEach, describe, expect, it, vi } from 'vitest'
import { BUILTIN_SHEET, costOf, isPeakTime, parsePriceSheet, PriceService, resolvePrice } from '../src/pricing.js'

const at = (iso: string): number => Date.parse(iso)
const log = { warn: () => {}, info: () => {}, error: () => {} }

describe('costOf', () => {
  it('bills cache reads at the hit price and cache writes at the miss price', () => {
    const price = { inputCacheHit: 0.02, inputMiss: 1, output: 2 }
    const cost = costOf(price, {
      inputTokens: 100_000,
      outputTokens: 200_000,
      cacheReadTokens: 400_000,
      cacheWriteTokens: 100_000,
    })
    // (100000*1 + 400000*0.02 + 100000*1 + 200000*2) / 1e6 = 0.608
    expect(cost).toBeCloseTo(0.608)
  })

  it('returns 0 for unknown prices (tokens still counted elsewhere)', () => {
    expect(costOf(undefined, { inputTokens: 1000, outputTokens: 1000 })).toBe(0)
  })
})

describe('isPeakTime boundaries', () => {
  const cases: Array<[string, boolean]> = [
    ['2026-08-20T08:59:00+08:00', false],
    ['2026-08-20T09:00:00+08:00', true],
    ['2026-08-20T11:59:59+08:00', true],
    ['2026-08-20T12:00:00+08:00', false],
    ['2026-08-20T13:59:59+08:00', false],
    ['2026-08-20T14:00:00+08:00', true],
    ['2026-08-20T17:59:59+08:00', true],
    ['2026-08-20T18:00:00+08:00', false],
  ]
  it.each(cases)('%s → %s', (iso, expected) => {
    expect(isPeakTime(at(iso))).toBe(expected)
  })

  it('honours custom minute-level windows', () => {
    const windows: ReadonlyArray<readonly [number, number]> = [[9.5, 12]]
    expect(isPeakTime(at('2026-08-20T09:29:00+08:00'), windows)).toBe(false)
    expect(isPeakTime(at('2026-08-20T09:30:00+08:00'), windows)).toBe(true)
  })
})

describe('resolvePrice schedule activation', () => {
  it('uses the flat table before the effective date', () => {
    const before = at('2026-08-16T10:00:00+08:00') // peak hour, but pre-effective
    expect(resolvePrice(BUILTIN_SHEET, 'deepseek-v4-pro', before))
      .toEqual({ inputCacheHit: 0.025, inputMiss: 3, output: 6 })
  })

  it('picks peak/off-peak tables by call time after the effective date', () => {
    const peak = at('2026-08-20T10:00:00+08:00')
    const offPeak = at('2026-08-20T13:00:00+08:00')
    expect(resolvePrice(BUILTIN_SHEET, 'deepseek-v4-flash', peak)?.inputMiss).toBe(3)
    expect(resolvePrice(BUILTIN_SHEET, 'deepseek-v4-flash', offPeak)?.inputMiss).toBe(1.5)
  })
})

describe('parsePriceSheet', () => {
  const html = `
    <html><body>
    <h1>DeepSeek API 定价</h1>
    <table>
      <tr><th>模型</th><th>deepseek-v4-flash</th><th>deepseek-v4-pro</th></tr>
      <tr><td>输入价格（缓存未命中）</td><td>1元</td><td>3元</td></tr>
      <tr><td>输入价格（缓存命中）</td><td>0.02元</td><td>0.025元</td></tr>
      <tr><td>输出价格</td><td>2元</td><td>6元</td></tr>
    </table>
    <p>分时定价自 2026 年 8 月 17 日 00:00（北京时间）开始生效，高峰时段为北京时间 9:00 - 12:00、14:00 - 18:00。</p>
    <table>
      <tr><th>模型</th><th>时段</th><th>输入（缓存命中）</th><th>输入（缓存未命中）</th><th>输出</th></tr>
      <tr><td>deepseek-v4-flash</td><td>空闲时段</td><td>0.05元</td><td>1.5元</td><td>4.5元</td></tr>
      <tr><td>deepseek-v4-flash</td><td>高峰时段</td><td>0.1元</td><td>3元</td><td>9元</td></tr>
    </table>
    </body></html>`

  it('parses both the flat table and the scheduled table', () => {
    const sheet = parsePriceSheet(html, 'https://example.test/pricing')
    expect(sheet.source).toBe('live')
    expect(sheet.current['deepseek-v4-flash']).toEqual({ inputCacheHit: 0.02, inputMiss: 1, output: 2 })
    expect(sheet.current['deepseek-v4-pro']).toEqual({ inputCacheHit: 0.025, inputMiss: 3, output: 6 })

    expect(sheet.scheduled?.effective).toBe('2026-08-17')
    expect(sheet.scheduled?.peakWindows).toEqual([[9, 12], [14, 18]])
    expect(sheet.scheduled?.offPeak['deepseek-v4-flash']).toEqual({ inputCacheHit: 0.05, inputMiss: 1.5, output: 4.5 })
    expect(sheet.scheduled?.peak['deepseek-v4-flash']).toEqual({ inputCacheHit: 0.1, inputMiss: 3, output: 9 })
  })

  it('throws when no recognizable table exists', () => {
    expect(() => parsePriceSheet('<html><body>维护中</body></html>', 'https://x.test')).toThrow()
  })
})

describe('PriceService.resolve priority', () => {
  it('user overrides win over everything, including prefix matches', () => {
    const service = new PriceService('https://x.test', 1000, log)
    service.setOverrides({ 'glm-4.6': { inputCacheHit: 0, inputMiss: 5, output: 5 } })
    const now = at('2026-08-20T10:00:00+08:00')
    expect(service.resolve('glm-4.6', now)).toEqual({ inputCacheHit: 0, inputMiss: 5, output: 5 })
    // Dated snapshot ids fall through prefix matching on the override table.
    expect(service.resolve('glm-4.6-250414', now)).toEqual({ inputCacheHit: 0, inputMiss: 5, output: 5 })
  })

  it('falls back from the DeepSeek sheet to catalog exact and prefix matches', () => {
    const service = new PriceService('https://x.test', 1000, log)
    const now = at('2026-08-20T10:00:00+08:00')
    expect(service.resolve('deepseek-v4-pro', now)?.inputMiss).toBe(9) // peak hour table
    expect(service.resolve('qwen3-plus', now)).toBeDefined()
    // A dated catalog snapshot resolves through the longest catalog prefix.
    expect(service.resolve('qwen3-plus-0428', now)).toBeDefined()
    expect(service.resolve('totally-unknown-model', now)).toBeUndefined()
  })
})

describe('PriceService.resolve 缓存', () => {
  it('overrides 替换后同分钟桶也拿到新价（缓存随代次失效）', () => {
    const service = new PriceService('https://x.test', 1000, log)
    const now = at('2026-08-20T10:00:00+08:00')
    // 首次解析会写入缓存。
    expect(service.resolve('glm-4.6', now)).toBeDefined()
    const rev0 = service.rev
    service.setOverrides({ 'glm-4.6': { inputCacheHit: 0, inputMiss: 5, output: 5 } })
    expect(service.rev).toBeGreaterThan(rev0)
    // 同一模型、同一分钟：缓存必须失效，返回 override 后的新价。
    expect(service.resolve('glm-4.6', now)).toEqual({ inputCacheHit: 0, inputMiss: 5, output: 5 })
  })

  it('分钟桶跨越峰谷边界时重新解析，价格不串桶', () => {
    const service = new PriceService('https://x.test', 1000, log)
    // 内置 sheet 的峰谷窗口为 [9,12)、[14,18)，11:59 峰 / 12:01 谷 / 14:01 又回峰。
    const peakMinute = at('2026-08-20T11:59:00+08:00')
    const offPeakMinute = at('2026-08-20T12:01:00+08:00')
    const peakAgain = at('2026-08-20T14:01:00+08:00')
    expect(service.resolve('deepseek-v4-pro', peakMinute)?.inputMiss).toBe(9)
    // 谷价不能被峰分钟缓存污染。
    expect(service.resolve('deepseek-v4-pro', offPeakMinute)?.inputMiss).toBe(4.5)
    // 峰价同样不能被谷分钟缓存污染。
    expect(service.resolve('deepseek-v4-pro', peakAgain)?.inputMiss).toBe(9)
  })
})

describe('PriceService.refreshVendor zhipu-bundle channel (fetch mocked)', () => {
  afterEach(() => {
    vi.unstubAllGlobals()
  })

  it('discovers the JS bundle, merges legacy prices, and serves them via resolve', async () => {
    const shell = '<!doctype html><script src="https://static.bigmodel.cn/wd-paas-front/js/app.a1b2c3.js"></script>'
    const bundle = 'window.__INITIAL__={newModel:{modelList:[{name:"GLM-5.2",inPrice:["8元"],outPrice:["28元"],hit:["2元"]}]}}'
    const legacy = JSON.stringify({
      data: [{
        operationId: '1122',
        content: JSON.stringify({
          list: [{
            fieldList: [{ code: 'm', label: '模型' }, { code: 'p', label: '单价' }],
            modelList: [{ m: 'GLM-4.5-AIR', p: '0.8元 / 百万Tokens' }],
          }],
        }),
      }],
    })

    const fetchMock = vi.fn(async (input: string | URL | Request) => {
      const url = String(input)
      if (url.includes('app.')) return new Response(bundle)
      if (url.includes('operation/query')) return new Response(legacy)
      return new Response(shell)
    })
    vi.stubGlobal('fetch', fetchMock)

    const service = new PriceService('https://x.test', 1000, log)
    await service.refreshVendor('zhipu')

    const now = at('2026-08-20T10:00:00+08:00')
    expect(service.resolve('glm-5.2', now)).toEqual({ inputCacheHit: 2, inputMiss: 8, output: 28 })
    expect(service.resolve('glm-4.5-air', now)).toEqual({ inputCacheHit: 0, inputMiss: 0.8, output: 0.8 })
    // Bundle results outrank legacy entries for the same model.
    expect(fetchMock).toHaveBeenCalled()
  })
})
