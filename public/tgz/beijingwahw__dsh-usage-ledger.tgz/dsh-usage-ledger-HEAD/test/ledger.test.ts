import { afterEach, beforeEach, describe, expect, it } from 'vitest'
import { mkdtempSync, readdirSync, readFileSync, writeFileSync, existsSync, rmSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { ledgerCsv, UsageLedger } from '../src/ledger.js'
import type { BudgetConfig } from '../src/ledger.js'
import type { UsageCounters } from '../src/types.js'
import { beijingDate } from '../src/types.js'

const log = { warn: () => {}, info: () => {} }
const budgets = (): BudgetConfig => ({ dailyBudget: 0, totalBudget: 0, sessionBudget: 0, warnRatio: 0.8 })

const sample = (over: Partial<Parameters<UsageLedger['record']>[1]> = {}) => ({
  time: Date.parse('2026-08-20T10:00:00+08:00'),
  usage: { inputTokens: 1000, outputTokens: 2000, cacheReadTokens: 500, cacheWriteTokens: 300 },
  model: 'deepseek-v4-pro',
  provider: 'deepseek',
  cost: 0.05,
  ...over,
})

const counters = (over: Partial<UsageCounters> = {}): UsageCounters => ({
  calls: 0, inputTokens: 0, outputTokens: 0, cacheReadTokens: 0, cacheWriteTokens: 0, reasoningTokens: 0, cost: 0,
  ...over,
})

let dir = ''

beforeEach(() => {
  dir = mkdtempSync(join(tmpdir(), 'usage-ledger-'))
})

afterEach(() => {
  rmSync(dir, { recursive: true, force: true })
})

const ledgerPath = (): string => join(dir, 'usage-ledger.json')

describe('UsageLedger.record', () => {
  it('aggregates one call into session, daily, total, and model buckets', () => {
    const ledger = new UsageLedger(ledgerPath(), budgets(), log, 5_000)
    ledger.record('s1', sample())

    const session = ledger.session('s1')
    expect(session?.calls).toBe(1)
    expect(session?.inputTokens).toBe(1000)
    expect(session?.outputTokens).toBe(2000)
    expect(session?.cacheReadTokens).toBe(500)
    expect(session?.cost).toBe(0.05)
    expect(session?.model).toBe('deepseek-v4-pro')

    const day = beijingDate(Date.parse('2026-08-20T10:00:00+08:00'))
    expect(ledger.daily(day)).toEqual({ calls: 1, tokens: 3800, cost: 0.05 })
    expect(ledger.total()).toEqual({ calls: 1, tokens: 3800, cost: 0.05 })

    const models = ledger.models()
    expect(models).toHaveLength(1)
    expect(models[0]?.[0]).toBe('deepseek-v4-pro')
    expect(models[0]?.[1].cost).toBe(0.05)
  })

  it('accumulates across calls and models, sorted by cost descending', () => {
    const ledger = new UsageLedger(ledgerPath(), budgets(), log, 5_000)
    ledger.record('s1', sample())
    ledger.record('s1', sample({ model: 'glm-4.6', cost: 0.2 }))
    ledger.record('s2', sample({ model: 'kimi-k2.6', cost: 0.01 }))

    expect(ledger.session('s1')?.calls).toBe(2)
    expect(ledger.models().map(([m]) => m)).toEqual(['glm-4.6', 'deepseek-v4-pro', 'kimi-k2.6'])
    expect(ledger.total().cost).toBeCloseTo(0.26)
  })

  it('keeps a capped in-memory recent-sample ring buffer', () => {
    const ledger = new UsageLedger(ledgerPath(), budgets(), log, 5_000)
    for (let i = 0; i < 300; i += 1) {
      ledger.record('s1', sample({ time: 1_000_000 + i, cost: i }))
    }
    const recent = ledger.recentSamples()
    expect(recent).toHaveLength(256)
    expect(recent[0]?.cost).toBe(44) // 300 - 256 = 44 dropped from the front
  })
})

describe('UsageLedger watermark and titles', () => {
  it('advances the seq watermark monotonically (idempotent folding)', () => {
    const ledger = new UsageLedger(ledgerPath(), budgets(), log, 5_000)
    // In the real flow session/created always lands before usage events, so
    // the row exists before the watermark advances.
    ledger.setTitle('s1', '标题', 1)
    expect(ledger.lastSeq('s1')).toBe(-1)
    ledger.advanceSeq('s1', 5)
    ledger.advanceSeq('s1', 3) // stale replay must not rewind
    expect(ledger.lastSeq('s1')).toBe(5)
  })

  it('remembers the latest title', () => {
    const ledger = new UsageLedger(ledgerPath(), budgets(), log, 5_000)
    ledger.setTitle('s1', '旧标题', 1)
    ledger.setTitle('s1', '新标题', 2)
    expect(ledger.title('s1')).toBe('新标题')
  })
})

describe('UsageLedger budgets', () => {
  const now = Date.parse('2026-08-20T10:00:00+08:00')

  it('flags the warning state between warnRatio and the budget', () => {
    const ledger = new UsageLedger(ledgerPath(), { ...budgets(), dailyBudget: 10, warnRatio: 0.8 }, log, 5_000)
    ledger.record('s1', sample({ cost: 8.5 }))
    const status = ledger.budgetStatus(now)
    expect(status.daily?.warn).toBe(true)
    expect(status.daily?.exceeded).toBe(false)
    expect(ledger.isWarn(now)).toBe(true)
    expect(ledger.isExceeded(now)).toBe(false)
  })

  it('flags the exceeded state at the budget', () => {
    const ledger = new UsageLedger(ledgerPath(), { ...budgets(), dailyBudget: 10 }, log, 5_000)
    ledger.record('s1', sample({ cost: 10 }))
    expect(ledger.budgetStatus(now).daily?.exceeded).toBe(true)
    expect(ledger.isExceeded(now)).toBe(true)
  })

  it('evaluates the per-session budget for the given session only', () => {
    const ledger = new UsageLedger(ledgerPath(), { ...budgets(), sessionBudget: 1 }, log, 5_000)
    ledger.record('s1', sample({ cost: 2 }))
    const mine = ledger.budgetStatus(now, 's1')
    const other = ledger.budgetStatus(now, 's2')
    expect(mine.session?.exceeded).toBe(true)
    expect(other.session?.exceeded).toBe(false) // unknown session evaluates at cost 0
    expect(other.session?.cost).toBe(0)
  })

  it('reports hasBudget only when at least one budget is configured', () => {
    expect(new UsageLedger(ledgerPath(), budgets(), log, 5_000).hasBudget).toBe(false)
    expect(new UsageLedger(ledgerPath(), { ...budgets(), dailyBudget: 1 }, log, 5_000).hasBudget).toBe(true)
  })
})

describe('UsageLedger persistence', () => {
  it('flushes atomically and reloads the watermark and models', () => {
    const path = ledgerPath()
    const first = new UsageLedger(path, budgets(), log, 5_000)
    first.record('s1', sample())
    first.advanceSeq('s1', 7)
    first.flush()

    const reloaded = new UsageLedger(path, budgets(), log, 5_000)
    expect(reloaded.lastSeq('s1')).toBe(7)
    expect(reloaded.total().cost).toBeCloseTo(0.05)
    expect(reloaded.models()[0]?.[0]).toBe('deepseek-v4-pro')
    expect(existsSync(`${path}.tmp`)).toBe(false)
  })

  it('loads pre-0.2.0 files without the models field (forward compatibility)', () => {
    const path = ledgerPath()
    writeFileSync(path, JSON.stringify({
      version: 1,
      sessions: { s1: { ...counters({ calls: 1, cost: 0.1 }), title: '', createdAt: 1, updatedAt: 1, lastSeq: 2, model: 'glm-4.6' } },
      daily: {},
      total: { calls: 1, tokens: 100, cost: 0.1 },
    }), 'utf8')

    const ledger = new UsageLedger(path, budgets(), log, 5_000)
    expect(ledger.total().cost).toBeCloseTo(0.1)
    expect(ledger.models()).toEqual([])
    // New records start populating the model bucket from now on.
    ledger.record('s2', sample({ model: 'glm-4.6', cost: 0.3 }))
    expect(ledger.models()).toHaveLength(1)
  })

  it('archives a corrupt file aside and starts fresh (never fatal)', () => {
    const path = ledgerPath()
    writeFileSync(path, '{ not valid json', 'utf8')
    const ledger = new UsageLedger(path, budgets(), log, 5_000)
    expect(ledger.total()).toEqual({ calls: 0, tokens: 0, cost: 0 })
    const backups = readdirSync(dir).filter(name => name.startsWith('usage-ledger.json.corrupt-'))
    expect(backups).toHaveLength(1)
  })
})

describe('UsageLedger.dailyWindow', () => {
  it('returns a zero-filled trailing window ending at endDay', () => {
    const ledger = new UsageLedger(ledgerPath(), budgets(), log, 5_000)
    ledger.record('s1', sample({ time: Date.parse('2026-08-20T10:00:00+08:00'), cost: 1 }))
    ledger.record('s1', sample({ time: Date.parse('2026-08-18T10:00:00+08:00'), cost: 2 }))

    const window = ledger.dailyWindow('2026-08-20', 4)
    expect(window.map(w => w.day)).toEqual(['2026-08-17', '2026-08-18', '2026-08-19', '2026-08-20'])
    expect(window[1]?.cost).toBe(2)
    expect(window[3]?.cost).toBe(1)
    expect(window[0]).toEqual({ day: '2026-08-17', calls: 0, tokens: 0, cost: 0 })
  })
})

describe('UsageLedger.compact', () => {
  const now = Date.parse('2026-08-20T12:00:00+08:00')

  it('archives stale sessions, preserves totals, and keeps the watermark', () => {
    const path = ledgerPath()
    const ledger = new UsageLedger(path, budgets(), log, 5_000)
    ledger.record('old', sample({ time: now - 30 * 86_400_000, cost: 1 }))
    ledger.advanceSeq('old', 50)
    ledger.record('fresh', sample({ time: now - 3_600_000, cost: 2 }))
    ledger.flush()

    const moved = ledger.compact(14, now)
    expect(moved).toBe(1)
    expect(ledger.sessions().map(([id]) => id)).toEqual(['fresh'])
    // Totals are untouched: history never shrinks.
    expect(ledger.total()).toEqual({ calls: 2, tokens: 7_600, cost: 3 })
    const summary = ledger.archivedSummary()
    expect(summary).toEqual({ sessions: 1, calls: 1, tokens: 3_800, cost: 1 })
    // The watermark survives archiving (in memory and on disk).
    expect(ledger.lastSeq('old')).toBe(50)
    ledger.flush()
    expect(new UsageLedger(path, budgets(), log, 5_000).lastSeq('old')).toBe(50)
  })

  it('never double-counts when an archived session revives', () => {
    const path = ledgerPath()
    const ledger = new UsageLedger(path, budgets(), log, 5_000)
    ledger.record('s1', sample({ time: now - 30 * 86_400_000, cost: 1 }))
    ledger.advanceSeq('s1', 9)
    ledger.compact(14, now)
    ledger.flush()

    // Simulate the fold of new events 10..12 for the revived session.
    const reloaded = new UsageLedger(path, budgets(), log, 5_000)
    expect(reloaded.lastSeq('s1')).toBe(9)
    reloaded.record('s1', sample({ time: now, cost: 4 })) // the only new usage event
    reloaded.advanceSeq('s1', 12)
    reloaded.flush()

    // Total = first period (1) + revival (4); the archived 1 is not re-added.
    expect(reloaded.total().cost).toBeCloseTo(5)
    expect(reloaded.lastSeq('s1')).toBe(12)
    // Re-archiving merges the revival row into the archive once it re-expires.
    expect(reloaded.compact(14, now + 30 * 86_400_000)).toBe(1)
    expect(reloaded.archivedSummary()).toEqual({ sessions: 1, calls: 2, tokens: 7_600, cost: 5 })
  })

  it('is a no-op with retention disabled', () => {
    const ledger = new UsageLedger(ledgerPath(), budgets(), log, 5_000)
    ledger.record('s1', sample({ time: now - 365 * 86_400_000 }))
    expect(ledger.compact(0, now)).toBe(0)
    expect(ledger.sessions()).toHaveLength(1)
  })
})

describe('dailyAll + ledgerCsv', () => {
  it('lists every day bucket in ascending order', () => {
    const ledger = new UsageLedger(ledgerPath(), budgets(), log, 5_000)
    ledger.record('s1', sample({ time: Date.parse('2026-08-20T10:00:00+08:00'), cost: 1 }))
    ledger.record('s1', sample({ time: Date.parse('2026-08-18T10:00:00+08:00'), cost: 2 }))
    const days = ledger.dailyAll().map(d => d.day)
    expect(days).toEqual(['2026-08-18', '2026-08-20'])
  })

  it('serializes daily and model rows as BOM-prefixed CSV', () => {
    const csv = ledgerCsv(
      [
        { day: '2026-08-18', calls: 3, tokens: 1_500, cost: 2 },
        { day: '2026-08-20', calls: 0, tokens: 0, cost: 0 },
      ],
      [['glm-4.6', counters({ calls: 3, inputTokens: 1_000, outputTokens: 500, cost: 2 })]],
    )
    const lines = csv.split('\n')
    expect(lines[0]).toBe('\ufeffkind,key,calls,tokens,cost')
    expect(lines[1]).toBe('day,2026-08-18,3,1500,2.0000')
    expect(lines[3]).toBe('model,glm-4.6,3,1500,2.0000')
    expect(csv.endsWith('\n')).toBe(true)
  })
})

describe('复式对账与 rebalance', () => {
  const now = Date.parse('2026-08-20T12:00:00+08:00')

  it('正常记账恒对账平衡', () => {
    const ledger = new UsageLedger(ledgerPath(), budgets(), log, 5_000)
    ledger.record('s1', sample({ time: now }))
    ledger.record('s2', sample({ time: now, model: 'glm-4.6', cost: 0.2 }))
    expect(ledger.audit().ok).toBe(true)
  })

  it('检测并修复总计漂移：以明细账为准重建总计', () => {
    const path = ledgerPath()
    const ledger = new UsageLedger(path, budgets(), log, 5_000)
    ledger.record('s1', sample({ time: now, cost: 1 }))
    ledger.flush()
    // 模拟损坏/手改：把 total.calls 改成错误值后重载。
    const raw = JSON.parse(readFileSync(path, 'utf8')) as { total: { calls: number } }
    raw.total.calls = 99
    writeFileSync(path, JSON.stringify(raw), 'utf8')
    const corrupted = new UsageLedger(path, budgets(), log, 5_000)
    expect(corrupted.audit().ok).toBe(false)
    expect(corrupted.audit().detailDrift.calls).toBe(-98)
    // rebalance 以明细为准：total 回到 1，rev 递增并落盘。
    const revBefore = corrupted.rev
    expect(corrupted.rebalance()).toBe(true)
    expect(corrupted.audit().ok).toBe(true)
    expect(corrupted.total().calls).toBe(1)
    expect(corrupted.rev).toBeGreaterThan(revBefore)
    corrupted.flush()
    expect(new UsageLedger(path, budgets(), log, 5_000).total().calls).toBe(1)
  })

  it('平衡账本的 rebalance 是无操作', () => {
    const ledger = new UsageLedger(ledgerPath(), budgets(), log, 5_000)
    ledger.record('s1', sample({ time: now }))
    expect(ledger.rebalance()).toBe(false)
  })

  it('归档后的账本仍对账平衡（明细 = 活跃 + 归档）', () => {
    const ledger = new UsageLedger(ledgerPath(), budgets(), log, 5_000)
    ledger.record('old', sample({ time: now - 30 * 86_400_000, cost: 1 }))
    ledger.record('fresh', sample({ time: now, cost: 2 }))
    ledger.compact(14, now)
    expect(ledger.audit().ok).toBe(true)
  })
})

describe('滚动备份', () => {
  const now = Date.parse('2026-08-20T12:00:00+08:00')

  it('flush 落盘后生成 .bak 快照，一小时内不重复', () => {
    const path = ledgerPath()
    const ledger = new UsageLedger(path, budgets(), log, 5_000)
    ledger.record('s1', sample({ time: now }))
    ledger.flush()
    const baks = readdirSync(dir).filter(n => n.includes('.bak-'))
    expect(baks).toHaveLength(1)
    // 同一小时内的第二次 flush 不再新增备份。
    ledger.record('s2', sample({ time: now }))
    ledger.flush()
    expect(readdirSync(dir).filter(n => n.includes('.bak-'))).toHaveLength(1)
  })
})

describe('rev 与派生视图缓存', () => {
  const now = Date.parse('2026-08-20T12:00:00+08:00')

  it('rev 随变更单调递增，flush 持久化不递增', () => {
    const ledger = new UsageLedger(ledgerPath(), budgets(), log, 5_000)
    const rev0 = ledger.rev
    ledger.record('s1', sample({ time: now }))
    const rev1 = ledger.rev
    expect(rev1).toBeGreaterThan(rev0)
    ledger.setTitle('s1', '标题', now)
    expect(ledger.rev).toBeGreaterThan(rev1)
    const rev2 = ledger.rev
    ledger.flush()
    expect(ledger.rev).toBe(rev2)
  })

  it('sessions() 缓存命中返回同一数组，新记账后重排', () => {
    const ledger = new UsageLedger(ledgerPath(), budgets(), log, 5_000)
    ledger.record('old', sample({ time: now - 1_000, cost: 1 }))
    ledger.record('new', sample({ time: now, cost: 2 }))
    const view = ledger.sessions()
    expect(view.map(([id]) => id)).toEqual(['new', 'old'])
    // 数据未变：同一数组直接复用（O(1) 命中，不重排）。
    expect(ledger.sessions()).toBe(view)
    // 新记账使缓存失效，视图重排且包含新会话。
    ledger.record('newest', sample({ time: now + 1_000, cost: 3 }))
    expect(ledger.sessions().map(([id]) => id)).toEqual(['newest', 'new', 'old'])
  })

  it('models/dailyAll/archivedSummary 缓存随记账与压实失效', () => {
    const ledger = new UsageLedger(ledgerPath(), budgets(), log, 5_000)
    ledger.record('s1', sample({ time: now - 30 * 86_400_000, model: 'glm-4.6', cost: 1 }))
    ledger.record('s2', sample({ time: now - 30 * 86_400_000, model: 'kimi-k2.6', cost: 2 }))
    expect(ledger.models().map(([m]) => m)).toEqual(['kimi-k2.6', 'glm-4.6'])
    expect(ledger.dailyAll()).toHaveLength(1)
    // 压实把过期会话移入归档桶：三个派生视图都随之更新。
    expect(ledger.compact(14, now)).toBe(2)
    expect(ledger.sessions()).toHaveLength(0)
    expect(ledger.archivedSummary()).toEqual({ sessions: 2, calls: 2, tokens: 7_600, cost: 3 })
    // 历史日桶与模型聚合不因压实丢失。
    expect(ledger.dailyAll()).toHaveLength(1)
    expect(ledger.models()).toHaveLength(2)
  })
})
