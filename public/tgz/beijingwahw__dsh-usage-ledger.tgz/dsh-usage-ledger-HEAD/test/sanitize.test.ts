/**
 * 账本文件净化测试：「parse, don't validate」反模式修复的验证。
 *
 * 每类损坏一个用例：字符串成本、Infinity（JSON 文本 1e999）、负 token、
 * 容器形状错误、行形状错误、版本错误。端到端用例证明毒化文件加载后账
 * 本仍可用且数值处处有限非负——NaN 永不进入状态。
 */
import { mkdtempSync, rmSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { afterEach, describe, expect, it } from 'vitest'
import { sanitizeLedgerFile, UsageLedger } from '../src/ledger.js'
import type { UsageSample } from '../src/ledger.js'

const noopLog = { warn: () => {}, info: () => {} }
const budgets = { dailyBudget: 0, totalBudget: 0, sessionBudget: 0, warnRatio: 0.8 }
const sample = (over: Partial<UsageSample> = {}): UsageSample => ({
  time: 1_000,
  usage: { inputTokens: 10, outputTokens: 5 },
  model: 'm1',
  cost: 0.001,
  ...over,
})

describe('sanitizeLedgerFile', () => {
  it('保留完全合法的字段原值', () => {
    const file = sanitizeLedgerFile({
      version: 1,
      sessions: { s1: { calls: 2, inputTokens: 100, outputTokens: 50, cost: 0.5, title: '标题', createdAt: 1, updatedAt: 2, lastSeq: 7 } },
      daily: { '2026-08-01': { calls: 2, tokens: 150, cost: 0.5 } },
      models: { 'deepseek-v4': { calls: 2, inputTokens: 100, outputTokens: 50, cost: 0.5 } },
      total: { calls: 2, tokens: 150, cost: 0.5 },
    })
    expect(file.sessions.s1!.cost).toBe(0.5)
    expect(file.sessions.s1!.lastSeq).toBe(7)
    expect(file.daily['2026-08-01']!.tokens).toBe(150)
    expect(file.total.cost).toBe(0.5)
  })

  it('字符串成本、负 token、非整数 lastSeq 全部归位', () => {
    const file = sanitizeLedgerFile({
      version: 1,
      sessions: { s1: { calls: 2, inputTokens: -50, outputTokens: 50, cost: 'abc', lastSeq: 1.5 } },
      total: { calls: 2, tokens: 0, cost: null },
    })
    expect(file.sessions.s1!.inputTokens).toBe(0)
    expect(file.sessions.s1!.cost).toBe(0)
    expect(file.sessions.s1!.lastSeq).toBe(-1)
    expect(file.total.cost).toBe(0)
  })

  it('JSON 文本 1e999 解析出的 Infinity 被归零（NaN 永不进入状态）', () => {
    // JSON.stringify(Infinity) 会写成 null，只有手写文本能造出 Infinity。
    const file = sanitizeLedgerFile(JSON.parse('{"version":1,"total":{"calls":1e999,"tokens":1,"cost":1e999}}'))
    expect(file.total.calls).toBe(0)
    expect(file.total.cost).toBe(0)
    expect(Number.isFinite(file.total.calls)).toBe(true)
  })

  it('容器位置是数组或原始值时视为空表', () => {
    const file = sanitizeLedgerFile({ version: 1, sessions: [], daily: 42, models: null, archived: 'x' })
    expect(file.sessions).toEqual({})
    expect(file.daily).toEqual({})
    expect(file.models).toEqual({})
    expect(file.archived).toEqual({})
  })

  it('行内是数组或原始值时被丢弃，不污染整表', () => {
    const file = sanitizeLedgerFile({
      version: 1,
      sessions: { good: { calls: 1, cost: 1 }, bad: [1, 2], worse: 'nope' },
    })
    expect(Object.keys(file.sessions)).toEqual(['good'])
    expect(file.sessions.good!.cost).toBe(1)
  })

  it('非对象或版本不是 1 时抛错（走隔离恢复路径）', () => {
    expect(() => sanitizeLedgerFile(null)).toThrow('unsupported ledger version')
    expect(() => sanitizeLedgerFile('x')).toThrow('unsupported ledger version')
    expect(() => sanitizeLedgerFile({ version: 2 })).toThrow('unsupported ledger version')
  })
})

describe('毒化文件的端到端加载', () => {
  const dirs: string[] = []
  afterEach(() => {
    for (const d of dirs.splice(0)) rmSync(d, { recursive: true, force: true })
  })

  it('毒化文件加载后账本可用：数值处处有限，记账照常，审计发现漂移', () => {
    const dir = mkdtempSync(join(tmpdir(), 'ledger-poison-'))
    dirs.push(dir)
    const path = join(dir, 'ledger.json')
    // 明细会话成本被字符串毒化（净化归零），总计保留原值 → 漂移留给审计。
    writeFileSync(path, JSON.stringify({
      version: 1,
      sessions: { s1: { calls: 3, inputTokens: 100, outputTokens: 50, cost: 'poisoned', lastSeq: 3 } },
      total: { calls: 3, tokens: 150, cost: 1.5 },
    }))
    const ledger = new UsageLedger(path, budgets, noopLog, 0)
    expect(ledger.total().cost).toBe(1.5)
    // 审计应发现明细（净化后 0）与总计（1.5）的漂移。
    expect(ledger.audit().ok).toBe(false)
    // 记账照常工作，数值有限。
    ledger.record('s2', sample())
    expect(ledger.total().calls).toBe(4)
    expect(Number.isFinite(ledger.total().cost)).toBe(true)
    // 重算后明细为准：detailDrift 归零（日桶/模型表有口径边界，不在
    // rebalance 修复范围——此处毒化文件本就没有日桶，属预期）。
    ledger.rebalance()
    expect(ledger.audit().detailDrift.cost).toBeCloseTo(0, 9)
  })

  it('合法文件加载后审计平衡（净化不引入假漂移）', () => {
    const dir = mkdtempSync(join(tmpdir(), 'ledger-clean-'))
    dirs.push(dir)
    const path = join(dir, 'ledger.json')
    const ledger0 = new UsageLedger(path, budgets, noopLog, 0)
    ledger0.record('s1', sample())
    ledger0.record('s1', sample({ time: 2_000, cost: 0.002 }))
    ledger0.flush()
    const ledger = new UsageLedger(path, budgets, noopLog, 0)
    expect(ledger.total().calls).toBe(2)
    expect(ledger.audit().ok).toBe(true)
  })
})
