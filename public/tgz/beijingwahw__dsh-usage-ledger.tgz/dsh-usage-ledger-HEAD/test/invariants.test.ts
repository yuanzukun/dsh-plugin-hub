/**
 * 性质测试（property-based testing）：验证数学定律，而非手工样例。
 *
 * 传统单元测试回答「这几个输入对不对」；性质测试用随机生成的上千个
 * 世界回答「定律是否对一切输入成立」——QuickCheck（Haskell，2000）血统，
 * fast-check 实现。每条性质都是一条可证伪的公理：
 *  - PVM 恒等式：四效应之和 ≡ 成本差（归因引擎的无残差承诺）；
 *  - 基尼公理：有界性、尺度不变性、置换不变性（Corrado Gini, 1912）；
 *  - Pareto 结构：累计份额单调递增收敛于 1；
 *  - 定价线性：成本对 token 数线性（单价线性组合的定义）；
 *  - 计数器不相交性：总和 ≥ 每个分桶；
 *  - 北京日期：与 Intl 时区数据库对任意时刻一致；
 *  - 金额格式化：数值单调性（可解析回数字后保持序）；
 *  - SPC 结构：控制限有序且非负。
 */
import fc from 'fast-check'
import { describe, expect, it } from 'vitest'
import { costAttribution, paretoOf, unitCostControl } from '../src/insights.js'
import type { RecentSample } from '../src/insights.js'
import { costOf } from '../src/pricing.js'
import type { ModelPrice } from '../src/types.js'
import { beijingDate, usageTotalTokens } from '../src/types.js'
import { formatCny } from '../src/ledger.js'

const TOLERANCE = 1e-6

/** 任意模型价格（三元非负）。 */
const arbitraryPrice = (): fc.Arbitrary<ModelPrice> => fc.record({
  inputCacheHit: fc.double({ min: 0, max: 100, noNaN: true }),
  inputMiss: fc.double({ min: 0, max: 100, noNaN: true }),
  output: fc.double({ min: 0, max: 100, noNaN: true }),
})

/** 任意近期调用样本（成本与 token 非负、时间递增由调用方排序保证）。 */
const arbitrarySample = (): fc.Arbitrary<RecentSample> => fc.record({
  time: fc.integer({ min: 0, max: 1_000_000 }),
  sessionId: fc.constantFrom('s1', 's2', 's3'),
  model: fc.option(fc.constantFrom('a', 'b', 'c'), { nil: undefined }),
  cost: fc.double({ min: 0, max: 50, noNaN: true }),
  inputTokens: fc.integer({ min: 0, max: 100_000 }),
  outputTokens: fc.integer({ min: 0, max: 100_000 }),
})

describe('PVM 归因恒等式（无残差定律）', () => {
  it('任意样本集上：量 + 结构 + 效率 + 价格 ≡ 成本差', () => {
    const samplesArb = fc.array(arbitrarySample(), { minLength: 0, maxLength: 60 })
      .map(arr => [...arr].sort((x, y) => x.time - y.time))
    fc.assert(
      fc.property(samplesArb, samples => {
        const a = costAttribution(samples)
        if (a === undefined) return
        const sum = a.volumeEffect + a.mixEffect + a.efficiencyEffect + a.priceEffect
        const delta = a.currentCost - a.baselineCost
        expect(Math.abs(sum - delta)).toBeLessThanOrEqual(TOLERANCE)
      }),
      { numRuns: 500 },
    )
  })

  it('归因是纯函数：同一输入两次调用结果逐字段相等', () => {
    const samplesArb = fc.array(arbitrarySample(), { minLength: 16, maxLength: 40 })
      .map(arr => [...arr].sort((x, y) => x.time - y.time))
    fc.assert(
      fc.property(samplesArb, samples => {
        const [x, y] = [costAttribution(samples), costAttribution(samples)]
        if (x === undefined || y === undefined) return
        expect(x).toEqual(y)
      }),
      { numRuns: 200 },
    )
  })
})

describe('基尼系数公理', () => {
  // 成本下界 0.01：避开 subnormal 浮点（<2.2e-308 的算术失去精度，尺度
  // 不变性在 IEEE-754 非规格化数域不成立，属表示层而非定律缺陷）。
  const entriesArb = fc.array(
    fc.record({ key: fc.string({ minLength: 1, maxLength: 4 }), cost: fc.double({ min: 0.01, max: 1000, noNaN: true }) }),
    { minLength: 4, maxLength: 12 },
  )

  it('有界性：0 ≤ gini ≤ (n−1)/n（n 实体的数学上限）', () => {
    fc.assert(
      fc.property(entriesArb, entries => {
        const p = paretoOf(entries)
        if (p === undefined) return
        expect(p.gini).toBeGreaterThanOrEqual(0)
        expect(p.gini).toBeLessThanOrEqual((p.count - 1) / p.count + TOLERANCE)
      }),
      { numRuns: 500 },
    )
  })

  it('尺度不变性（齐次公理）：全部成本乘以 k，基尼不变', () => {
    fc.assert(
      fc.property(entriesArb, fc.double({ min: 0.01, max: 100, noNaN: true }), (entries, k) => {
        const base = paretoOf(entries)
        const scaled = paretoOf(entries.map(e => ({ ...e, cost: e.cost * k })))
        if (base === undefined || scaled === undefined) return
        expect(Math.abs(base.gini - scaled.gini)).toBeLessThanOrEqual(TOLERANCE)
      }),
      { numRuns: 300 },
    )
  })

  it('置换不变性：打乱实体顺序，基尼与份额结构不变', () => {
    fc.assert(
      fc.property(entriesArb, entries => {
        const base = paretoOf(entries)
        const shuffled = paretoOf([...entries].reverse())
        if (base === undefined || shuffled === undefined) return
        expect(base.gini).toBeCloseTo(shuffled.gini, 6)
        expect(base.top3Share).toBeCloseTo(shuffled.top3Share, 6)
        expect(base.fewCount).toBe(shuffled.fewCount)
      }),
      { numRuns: 300 },
    )
  })

  it('Pareto 结构：累计份额单调不减且收敛于 1，fewCount 有界', () => {
    fc.assert(
      fc.property(entriesArb, entries => {
        const p = paretoOf(entries.filter(e => e.cost > 0))
        if (p === undefined) return
        for (let i = 1; i < p.items.length; i++) {
          expect(p.items[i]!.cumulative).toBeGreaterThanOrEqual(p.items[i - 1]!.cumulative - TOLERANCE)
        }
        expect(p.items[p.items.length - 1]!.cumulative).toBeCloseTo(1, 6)
        expect(p.fewCount).toBeGreaterThanOrEqual(1)
        expect(p.fewCount).toBeLessThanOrEqual(p.count)
      }),
      { numRuns: 300 },
    )
  })
})

describe('定价线性定律', () => {
  it('成本对 token 数线性：costOf(k·tokens) = k·costOf(tokens)', () => {
    fc.assert(
      fc.property(
        arbitraryPrice(),
        fc.integer({ min: 0, max: 1_000_000 }),
        fc.integer({ min: 1, max: 9 }),
        (price, tokens, k) => {
          const single = costOf(price, { inputTokens: tokens, outputTokens: tokens })
          const multiplied = costOf(price, { inputTokens: tokens * k, outputTokens: tokens * k })
          expect(Math.abs(multiplied - single * k)).toBeLessThanOrEqual(TOLERANCE)
        },
      ),
      { numRuns: 400 },
    )
  })

  it('非负 token 恒得非负成本', () => {
    fc.assert(
      fc.property(
        arbitraryPrice(),
        fc.integer({ min: 0, max: 1_000_000 }),
        fc.integer({ min: 0, max: 1_000_000 }),
        fc.integer({ min: 0, max: 1_000_000 }),
        fc.integer({ min: 0, max: 1_000_000 }),
        (price, input, output, cacheRead, cacheWrite) => {
          const cost = costOf(price, {
            inputTokens: input,
            outputTokens: output,
            cacheReadTokens: cacheRead,
            cacheWriteTokens: cacheWrite,
          })
          expect(cost).toBeGreaterThanOrEqual(0)
          expect(Number.isFinite(cost)).toBe(true)
        },
      ),
      { numRuns: 400 },
    )
  })
})

describe('计数器不相交性定律', () => {
  it('usageTotalTokens ≥ 每个分桶（非负桶的支配性）', () => {
    const usageArb = fc.record({
      inputTokens: fc.integer({ min: 0, max: 1e9 }),
      outputTokens: fc.integer({ min: 0, max: 1e9 }),
      cacheReadTokens: fc.integer({ min: 0, max: 1e9 }),
      cacheWriteTokens: fc.integer({ min: 0, max: 1e9 }),
      reasoningTokens: fc.integer({ min: 0, max: 1e9 }),
    })
    fc.assert(
      fc.property(usageArb, usage => {
        const total = usageTotalTokens(usage)
        expect(total).toBeGreaterThanOrEqual(usage.inputTokens)
        expect(total).toBeGreaterThanOrEqual(usage.outputTokens)
        expect(total).toBeGreaterThanOrEqual(usage.cacheReadTokens ?? 0)
        expect(total).toBeGreaterThanOrEqual(usage.cacheWriteTokens ?? 0)
        expect(Number.isFinite(total)).toBe(true)
      }),
      { numRuns: 400 },
    )
  })
})

describe('北京日期定律（时区正确性）', () => {
  it('1992 年起的任意时刻：beijingDate 与 Intl Asia/Shanghai 一致', () => {
    // 域从 1992 年起：1986-1991 年中国实行夏令时（Asia/Shanghai 走
    // UTC+9），而账本按现代北京时间固定 +8 计费——两个定义在历史夏
    // 令时窗口合法分歧。计费数据只存在于无夏令时的现代，固定 +8 是
    // 正确口径；性质测试把这个边界显式化并写入文档。
    const since1992 = Date.UTC(1992, 0, 1)
    fc.assert(
      fc.property(fc.integer({ min: since1992, max: 4_102_444_800_000 }), ms => {
        const expected = new Intl.DateTimeFormat('en-CA', {
          timeZone: 'Asia/Shanghai', year: 'numeric', month: '2-digit', day: '2-digit',
        }).format(new Date(ms))
        expect(beijingDate(ms)).toBe(expected)
      }),
      { numRuns: 500 },
    )
  })
})

describe('金额格式化单调性定律', () => {
  it('a ≤ b ⟹ 解析回的数值保持序（自适应精度不破坏单调）', () => {
    const parse = (s: string): number => Number(s.replace('¥', ''))
    fc.assert(
      fc.property(
        fc.double({ min: 0, max: 1e6, noNaN: true }),
        fc.double({ min: 0, max: 1e6, noNaN: true }),
        (a, b) => {
          const [lo, hi] = a <= b ? [a, b] : [b, a]
          expect(parse(formatCny(lo))).toBeLessThanOrEqual(parse(formatCny(hi)) + TOLERANCE)
        },
      ),
      { numRuns: 500 },
    )
  })
})

describe('SPC 控制图结构定律', () => {
  const dailyArb = fc.array(
    fc.record({
      day: fc.date({ min: new Date('2026-01-01'), max: new Date('2026-12-31'), noInvalidDate: true })
        .map(d => d.toISOString().slice(0, 10)),
      calls: fc.integer({ min: 0, max: 500 }),
      cost: fc.double({ min: 0, max: 100, noNaN: true }),
    }),
    { minLength: 7, maxLength: 40 },
  )

  it('任意日序列：0 ≤ lcl ≤ 基线 ≤ ucl，状态与最新点一致', () => {
    fc.assert(
      fc.property(dailyArb, daily => {
        const spc = unitCostControl(daily)
        if (spc === undefined) return
        expect(spc.lcl).toBeGreaterThanOrEqual(0)
        expect(spc.lcl).toBeLessThanOrEqual(spc.baselineUnitCost + TOLERANCE)
        expect(spc.ucl).toBeGreaterThanOrEqual(spc.baselineUnitCost - TOLERANCE)
        const consistent = spc.latestUnitCost > spc.ucl
          ? spc.status === 'above'
          : spc.latestUnitCost < spc.lcl
            ? spc.status === 'below'
            : spc.status === 'in'
        expect(consistent).toBe(true)
        expect(Number.isFinite(spc.sigma)).toBe(true)
      }),
      { numRuns: 400 },
    )
  })
})
