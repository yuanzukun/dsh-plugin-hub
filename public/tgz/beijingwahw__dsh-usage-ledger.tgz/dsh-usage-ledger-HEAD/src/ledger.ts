/**
 * The usage ledger: per-session token/cost aggregation, daily (Beijing) and
 * total buckets, durable JSON persistence, and budget evaluation.
 */
import { copyFileSync, existsSync, mkdirSync, readFileSync, readdirSync, renameSync, rmSync, writeFileSync } from 'node:fs'
import { homedir } from 'node:os'
import { dirname, join } from 'node:path'
import { beijingDate, usageTotalTokens } from './types.js'
import type { ArchivedSession, BudgetState, BudgetStatus, LedgerFile, SessionUsage, UsageCounters } from './types.js'
import type { ModelPrice } from './types.js'
import { auditFile } from './audit.js'
import type { AuditReport } from './audit.js'

/** Minimal logger shape (structurally compatible with the cordis logger). */
export interface LedgerLogger {
  warn(...args: unknown[]): void
  info(...args: unknown[]): void
}

/** Budget configuration the ledger evaluates against. */
export interface BudgetConfig {
  /** Daily cost budget (CNY); 0 disables. */
  dailyBudget: number
  /** Total cost budget (CNY); 0 disables. */
  totalBudget: number
  /** Per-session cost budget (CNY); 0 disables. */
  sessionBudget: number
  /** Ratio (0-1) at which a budget enters the warning state. */
  warnRatio: number
}
/** One recorded model call. */
export interface UsageSample {
  time: number
  usage: {
    inputTokens: number
    outputTokens: number
    cacheReadTokens?: number
    cacheWriteTokens?: number
    reasoningTokens?: number
  }
  model?: string
  provider?: string
  cost: number
}

function emptyCounters(): UsageCounters {
  return {
    calls: 0,
    inputTokens: 0,
    outputTokens: 0,
    cacheReadTokens: 0,
    cacheWriteTokens: 0,
    reasoningTokens: 0,
    cost: 0,
  }
}

function emptyFile(): LedgerFile {
  return { version: 1, sessions: {}, daily: {}, models: {}, archived: {}, total: { calls: 0, tokens: 0, cost: 0 } }
}

function addCounters(target: UsageCounters, sample: UsageSample): void {
  target.calls += 1
  target.inputTokens += sample.usage.inputTokens
  target.outputTokens += sample.usage.outputTokens
  target.cacheReadTokens += sample.usage.cacheReadTokens ?? 0
  target.cacheWriteTokens += sample.usage.cacheWriteTokens ?? 0
  target.reasoningTokens += sample.usage.reasoningTokens ?? 0
  target.cost += sample.cost
}

/** 数值净化：有限且非负才可信，否则归零（Infinity/NaN/负数/字符串毒化防护）。 */
function safeCount(value: unknown): number {
  return typeof value === 'number' && Number.isFinite(value) && value >= 0 ? value : 0
}

/** 文本净化：仅接受字符串，其余归空串。 */
function safeText(value: unknown): string {
  return typeof value === 'string' ? value : ''
}

/** 容器净化：仅接受普通对象（数组与原始值一律视为空表）。 */
function safeRecord<T>(value: unknown, sanitizeRow: (row: unknown) => T): Record<string, T> {
  if (typeof value !== 'object' || value === null || Array.isArray(value)) return {}
  const out: Record<string, T> = {}
  for (const [key, row] of Object.entries(value)) {
    if (typeof row === 'object' && row !== null && !Array.isArray(row)) out[key] = sanitizeRow(row)
  }
  return out
}

/**
 * 账本文件净化：「parse, don't validate」反模式的修复。
 *
 * `JSON.parse` 的返回类型是任意 JSON 形状；旧实现只查 version 就盲转
 * （`as Partial<LedgerFile>`），损坏字段会静默毒化总计、健康分与一切
 * 派生指标——NaN 一旦进入就永不消失。净化在结构层设防：
 *  - 数值：有限且非负才采信（JSON 文本 `1e999` 解析为 Infinity、字符串
 *    成本、负 token 一律归零）；
 *  - 容器：数组/原始值位置视为空表，行内字段逐个净化；
 *  - 版本：非 v1 直接抛错，走既有的「隔离损坏文件、全新开始」恢复路径。
 *
 * 净化只承诺结构与数值的合法性；算术一致性交给复式对账——净化清零造
 * 成的明细/总计漂移会被启动审计发现并按明细重算。两道防线正交组合：
 * 校验防「形状损坏」，审计防「数值漂移」。
 */
export function sanitizeLedgerFile(raw: unknown): LedgerFile {
  if (typeof raw !== 'object' || raw === null || (raw as { version?: unknown }).version !== 1) {
    throw new Error('unsupported ledger version')
  }
  const input = raw as Record<string, unknown>
  const sanitizeCounters = (row: Record<string, unknown>): UsageCounters => ({
    calls: safeCount(row.calls),
    inputTokens: safeCount(row.inputTokens),
    outputTokens: safeCount(row.outputTokens),
    cacheReadTokens: safeCount(row.cacheReadTokens),
    cacheWriteTokens: safeCount(row.cacheWriteTokens),
    reasoningTokens: safeCount(row.reasoningTokens),
    cost: safeCount(row.cost),
  })
  const sessions = safeRecord(input.sessions, row => {
    const r = row as Record<string, unknown>
    const counters = sanitizeCounters(r)
    const model = typeof r.model === 'string' ? r.model : undefined
    const provider = typeof r.provider === 'string' ? r.provider : undefined
    return {
      ...counters,
      title: safeText(r.title),
      ...(model !== undefined ? { model } : {}),
      ...(provider !== undefined ? { provider } : {}),
      createdAt: safeCount(r.createdAt),
      updatedAt: safeCount(r.updatedAt),
      lastSeq: Number.isInteger(r.lastSeq) && typeof r.lastSeq === 'number' ? r.lastSeq : -1,
    }
  })
  const daily = safeRecord(input.daily, row => {
    const r = row as Record<string, unknown>
    return { calls: safeCount(r.calls), tokens: safeCount(r.tokens), cost: safeCount(r.cost) }
  })
  const models = safeRecord(input.models, row => sanitizeCounters(row as Record<string, unknown>))
  const archived = safeRecord(input.archived, row => {
    const r = row as Record<string, unknown>
    const model = typeof r.model === 'string' ? r.model : undefined
    const title = typeof r.title === 'string' ? r.title : undefined
    return {
      calls: safeCount(r.calls),
      tokens: safeCount(r.tokens),
      cost: safeCount(r.cost),
      ...(model !== undefined ? { model } : {}),
      ...(title !== undefined ? { title } : {}),
      lastSeq: Number.isInteger(r.lastSeq) && typeof r.lastSeq === 'number' ? r.lastSeq : -1,
      archivedAt: safeCount(r.archivedAt),
    }
  })
  const totalRaw = typeof input.total === 'object' && input.total !== null && !Array.isArray(input.total)
    ? input.total as Record<string, unknown>
    : {}
  return {
    version: 1,
    sessions,
    daily,
    models,
    archived,
    total: {
      calls: safeCount(totalRaw.calls),
      tokens: safeCount(totalRaw.tokens),
      cost: safeCount(totalRaw.cost),
    },
  }
}

/** Resolve the ledger file path: configured path, else `$DSH_HOME`/`~/.dsh`. */
export function resolveLedgerPath(configured: string): string {
  const trimmed = configured.trim()
  if (trimmed !== '') return trimmed
  const envHome = process.env.DSH_HOME?.trim()
  const home = envHome !== undefined && envHome !== '' ? envHome : join(homedir(), '.dsh')
  return join(home, 'usage-ledger.json')
}

/**
 * Durable per-session usage ledger. All mutation goes through `record()` and
 * `setTitle()`; persistence is debounced and flushed on `dispose()`.
 */
export class UsageLedger {
  private file: LedgerFile = emptyFile()
  private dirty = false
  private saveTimer: NodeJS.Timeout | undefined
  private disposed = false
  /** 近期调用样本（仅内存，供异常检测、下次调用预报与 PVM 归因；重启即失效，不影响账本正确性）。 */
  private recent: Array<{ time: number; sessionId: string; model?: string; cost: number; inputTokens?: number; outputTokens?: number }> = []
  private static readonly RECENT_CAP = 256

  /**
   * 数据版本号：任意一次账本变更（记账/标题/水位/归档）单调 +1。
   * 派生视图（排序/汇总）与外层洞察快照都以 rev 作为缓存失效依据，
   * 轮询与报表读取从 O(n log n) 降为 O(1)；flush 持久化不改变数据、不递增。
   */
  private revision = 0
  private sessionsView: Array<[string, SessionUsage]> | undefined
  private modelsView: Array<[string, UsageCounters]> | undefined
  private dailyAllView: Array<{ day: string; calls: number; tokens: number; cost: number }> | undefined
  private archivedView: { sessions: number; calls: number; tokens: number; cost: number } | undefined

  /** 当前数据版本号（只读快照用途）。 */
  get rev(): number {
    return this.revision
  }

  constructor(
    readonly path: string,
    private budgets: BudgetConfig,
    private readonly log: LedgerLogger,
    private readonly saveIntervalMs: number,
  ) {
    this.load()
  }

  /** Replace the budget configuration (live settings update). */
  setBudgets(budgets: BudgetConfig): void {
    this.budgets = budgets
  }

  /** Load the durable file; a corrupt file is archived aside, never fatal. */
  private load(): void {
    if (!existsSync(this.path)) return
    try {
      this.file = sanitizeLedgerFile(JSON.parse(readFileSync(this.path, 'utf8')))
    }
    catch (error) {
      const backup = `${this.path}.corrupt-${Date.now()}`
      this.log.warn(`usage-ledger: cannot read ${this.path} (${String(error)}); starting fresh, old file kept at ${backup}`)
      try {
        renameSync(this.path, backup)
      }
      catch {
        // The fresh ledger is the recovery path; the rename is best-effort.
      }
      this.file = emptyFile()
    }
  }

  /** The last folded session-log seq, for resume double-count protection. */
  lastSeq(sessionId: string): number {
    const row = this.file.sessions[sessionId]
    if (row !== undefined) return row.lastSeq
    return this.file.archived?.[sessionId]?.lastSeq ?? -1
  }

  /** Session display title, when one was logged. */
  title(sessionId: string): string | undefined {
    return this.file.sessions[sessionId]?.title
  }

  /** Remember the session title (latest-wins). */
  setTitle(sessionId: string, title: string, time: number): void {
    const row = this.sessionRow(sessionId, time)
    if (row.title !== title) {
      row.title = title
      this.markDirty()
    }
  }

  /** Record one priced model call into session, daily, total, and model buckets. */
  record(sessionId: string, sample: UsageSample): void {
    const row = this.sessionRow(sessionId, sample.time)
    addCounters(row, sample)
    if (sample.model !== undefined) row.model = sample.model
    if (sample.provider !== undefined) row.provider = sample.provider
    row.updatedAt = sample.time

    // 模型维度聚合（0.2.0 新增洞察数据源）。
    if (sample.model !== undefined) {
      const modelRow = this.file.models?.[sample.model] ?? emptyCounters()
      addCounters(modelRow, sample)
      if (this.file.models === undefined) this.file.models = {}
      this.file.models[sample.model] = modelRow
    }

    // 近期样本环形缓冲（仅内存，供异常检测、下次调用预报与 PVM 归因）。
    this.recent.push({
      time: sample.time,
      sessionId,
      model: sample.model,
      cost: sample.cost,
      inputTokens: sample.usage.inputTokens + (sample.usage.cacheReadTokens ?? 0) + (sample.usage.cacheWriteTokens ?? 0),
      outputTokens: sample.usage.outputTokens,
    })
    if (this.recent.length > UsageLedger.RECENT_CAP) {
      this.recent.splice(0, this.recent.length - UsageLedger.RECENT_CAP)
    }

    const day = beijingDate(sample.time)
    const daily = this.file.daily[day] ?? { calls: 0, tokens: 0, cost: 0 }
    daily.calls += 1
    daily.tokens += usageTotalTokens(sample.usage)
    daily.cost += sample.cost
    this.file.daily[day] = daily

    this.file.total.calls += 1
    this.file.total.tokens += usageTotalTokens(sample.usage)
    this.file.total.cost += sample.cost
    this.markDirty()
  }

  /** Advance the folded-seq watermark after events were consumed. */
  advanceSeq(sessionId: string, seq: number): void {
    let row = this.file.sessions[sessionId]
    if (row === undefined) {
      // 会话行可能已被压实归档：复活时以归档水位续接，避免回退造成重放。
      const archived = this.file.archived?.[sessionId]
      if (archived === undefined) return
      row = { ...emptyCounters(), title: '', createdAt: Date.now(), updatedAt: Date.now(), lastSeq: archived.lastSeq }
      this.file.sessions[sessionId] = row
    }
    if (seq > row.lastSeq) {
      row.lastSeq = seq
      this.markDirty()
    }
  }

  private sessionRow(sessionId: string, time: number): SessionUsage {
    let row = this.file.sessions[sessionId]
    if (row === undefined) {
      row = { ...emptyCounters(), title: '', createdAt: time, updatedAt: time, lastSeq: -1 }
      this.file.sessions[sessionId] = row
      this.markDirty()
    }
    return row
  }

  /** One session's aggregate, when recorded. */
  session(sessionId: string): SessionUsage | undefined {
    return this.file.sessions[sessionId]
  }

  /**
   * All session rows, newest activity first.
   * 结果按 rev 缓存：数据未变时（轮询/报表反复读取）零重排。
   * 约定返回值只读——行对象与数组都不得原地修改。
   */
  sessions(): ReadonlyArray<[string, SessionUsage]> {
    if (this.sessionsView === undefined) {
      this.sessionsView = Object.entries(this.file.sessions).sort((a, b) => b[1].updatedAt - a[1].updatedAt)
    }
    return this.sessionsView
  }

  /** 模型维度聚合行，按花费降序（0.2.0 洞察数据源；rev 缓存，约定只读）。 */
  models(): ReadonlyArray<[string, UsageCounters]> {
    if (this.modelsView === undefined) {
      this.modelsView = Object.entries(this.file.models ?? {}).sort((a, b) => b[1].cost - a[1].cost)
    }
    return this.modelsView
  }

  /** 近期调用样本（内存环形缓冲副本，供异常检测、下次调用预报与 PVM 归因）。 */
  recentSamples(): ReadonlyArray<{ time: number; sessionId: string; model?: string; cost: number; inputTokens?: number; outputTokens?: number }> {
    return this.recent.slice()
  }

  /** 某日之前（含）最近 N 天的日桶序列（趋势图数据源，缺失的日期补零）。 */
  dailyWindow(endDay: string, days: number): Array<{ day: string; calls: number; tokens: number; cost: number }> {
    const end = Date.parse(`${endDay}T00:00:00+08:00`)
    const result: Array<{ day: string; calls: number; tokens: number; cost: number }> = []
    for (let i = days - 1; i >= 0; i -= 1) {
      const day = beijingDate(end - i * 86_400_000)
      const bucket = this.file.daily[day] ?? { calls: 0, tokens: 0, cost: 0 }
      result.push({ day, ...bucket })
    }
    return result
  }

  /** One day's bucket (Beijing date). */
  daily(day: string): { calls: number; tokens: number; cost: number } {
    return this.file.daily[day] ?? { calls: 0, tokens: 0, cost: 0 }
  }

  /**
   * 数据生命周期治理：把超过保留期未活动的会话行压进归档桶。
   * total/daily/models 全不动（历史总量不变），只有 sessions 表瘦身。
   * `lastSeq` 水位随行进归档——会话复活时从归档水位续接，
   * 折叠增量从水位之后开始，绝不重复计费。返回归档行数。
   */
  compact(retentionDays: number, now: number): number {
    if (!(retentionDays > 0)) return 0
    const cutoff = now - retentionDays * 86_400_000
    let moved = 0
    for (const [id, row] of Object.entries(this.file.sessions)) {
      if (row.updatedAt > cutoff) continue
      if (this.file.archived === undefined) this.file.archived = {}
      const prev = this.file.archived[id]
      const tokens = usageTotalTokens(row)
      if (prev === undefined) {
        this.file.archived[id] = {
          calls: row.calls,
          tokens,
          cost: row.cost,
          model: row.model,
          title: row.title !== '' ? row.title : undefined,
          lastSeq: row.lastSeq,
          archivedAt: now,
        }
      }
      else {
        prev.calls += row.calls
        prev.tokens += tokens
        prev.cost += row.cost
        if (row.model !== undefined) prev.model = row.model
        if (row.title !== '') prev.title = row.title
        if (row.lastSeq > prev.lastSeq) prev.lastSeq = row.lastSeq
        prev.archivedAt = now
      }
      delete this.file.sessions[id]
      moved += 1
    }
    if (moved > 0) this.markDirty()
    return moved
  }

  /** 归档桶汇总（报表展示用；rev 缓存。不含在 total 里，total 本就含全部历史）。 */
  archivedSummary(): { sessions: number; calls: number; tokens: number; cost: number } {
    if (this.archivedView !== undefined) return this.archivedView
    let calls = 0
    let tokens = 0
    let cost = 0
    for (const row of Object.values(this.file.archived ?? {})) {
      calls += row.calls
      tokens += row.tokens
      cost += row.cost
    }
    const summary = { sessions: Object.keys(this.file.archived ?? {}).length, calls, tokens, cost }
    this.archivedView = summary
    return summary
  }

  /** 全部日桶，按日期升序（CSV 导出数据源；rev 缓存，约定只读）。 */
  dailyAll(): ReadonlyArray<{ day: string; calls: number; tokens: number; cost: number }> {
    if (this.dailyAllView === undefined) {
      this.dailyAllView = Object.entries(this.file.daily)
        .map(([day, bucket]) => ({ day, ...bucket }))
        .sort((a, b) => a.day.localeCompare(b.day))
    }
    return this.dailyAllView
  }

  /** Lifetime totals. */
  total(): { calls: number; tokens: number; cost: number } {
    return this.file.total
  }

  /**
   * 复式对账：明细账 / 日桶 / 模型表 vs 总计（详见 audit.ts 口径说明）。
   * 纯读操作，不修改任何数据；报告对象是即时快照。
   */
  audit(): AuditReport {
    return auditFile(this.file)
  }

  /**
   * 以明细账为准重建总计（明细是记账的原始事实，聚合桶是派生值）。
   * 仅当明细与总计存在漂移时改写 total 并落盘；返回是否发生修复。
   * 日桶与模型表不动——日桶是时间真源，模型表有口径边界（见 audit.ts）。
   */
  rebalance(): boolean {
    const report = auditFile(this.file)
    const d = report.detailDrift
    if (d.calls === 0 && d.tokens === 0 && Math.abs(d.cost) < 1e-9) return false
    this.file.total = {
      calls: report.detail.calls,
      tokens: report.detail.tokens,
      cost: report.detail.cost,
    }
    this.markDirty()
    return true
  }

  private budgetState(cost: number, budget: number): BudgetState {
    const ratio = budget > 0 ? cost / budget : 0
    return {
      cost,
      budget,
      ratio,
      warn: budget > 0 && ratio >= this.budgets.warnRatio && cost < budget,
      exceeded: budget > 0 && cost >= budget,
    }
  }

  /** Evaluate daily, total, and (optionally) session budgets. */
  budgetStatus(atMs: number, sessionId?: string): BudgetStatus {
    const day = beijingDate(atMs)
    const status: BudgetStatus = {
      day,
      daily: this.budgetState(this.daily(day).cost, this.budgets.dailyBudget),
      total: this.budgetState(this.file.total.cost, this.budgets.totalBudget),
    }
    if (sessionId !== undefined && this.budgets.sessionBudget > 0) {
      status.session = this.budgetState(this.session(sessionId)?.cost ?? 0, this.budgets.sessionBudget)
    }
    return status
  }

  /** Whether any configured budget is already exceeded. */
  isExceeded(atMs: number, sessionId?: string): boolean {
    const status = this.budgetStatus(atMs, sessionId)
    return status.daily.exceeded || status.total.exceeded || (status.session?.exceeded ?? false)
  }

  /** Whether any configured budget reached the warning threshold. */
  isWarn(atMs: number, sessionId?: string): boolean {
    const status = this.budgetStatus(atMs, sessionId)
    return status.daily.warn || status.total.warn || (status.session?.warn ?? false)
  }

  /** Whether at least one budget is configured. */
  get hasBudget(): boolean {
    return this.budgets.dailyBudget > 0 || this.budgets.totalBudget > 0 || this.budgets.sessionBudget > 0
  }

  /** The resolved price table description for reports. */
  private markDirty(): void {
    this.dirty = true
    // 任何数据变更都使派生视图缓存整体失效（rev 供外层快照缓存判失效）。
    this.revision += 1
    this.sessionsView = undefined
    this.modelsView = undefined
    this.dailyAllView = undefined
    this.archivedView = undefined
    if (this.saveTimer === undefined && !this.disposed) {
      this.saveTimer = setTimeout(() => {
        this.saveTimer = undefined
        this.flush()
      }, this.saveIntervalMs)
      this.saveTimer.unref?.()
    }
  }

  /** Write the ledger to disk (atomic rename). */
  flush(): void {
    if (!this.dirty) return
    try {
      mkdirSync(dirname(this.path), { recursive: true })
      const tmp = `${this.path}.tmp`
      writeFileSync(tmp, JSON.stringify(this.file, null, 2), 'utf8')
      renameSync(tmp, this.path)
      this.dirty = false
      this.rotateBackup()
    }
    catch (error) {
      this.log.warn(`usage-ledger: persist failed: ${String(error)}`)
    }
  }

  /**
   * 滚动备份：成功落盘后，距上次备份 ≥1 小时则把当前账本快照为
   * `<path>.bak-<ms>`，只保留最近 BACKUP_KEEP 份（最旧的删除）。
   * 原子写 + 独立快照双保险：损坏/误删时可从备份恢复历史总计。
   */
  private lastBackupAt = 0
  private static readonly BACKUP_INTERVAL_MS = 3_600_000
  private static readonly BACKUP_KEEP = 3

  private rotateBackup(): void {
    const now = Date.now()
    if (now - this.lastBackupAt < UsageLedger.BACKUP_INTERVAL_MS) return
    this.lastBackupAt = now
    try {
      const dir = dirname(this.path)
      const base = this.path.split(/[\\/]/).pop() ?? 'usage-ledger.json'
      const backup = join(dir, `${base}.bak-${now}`)
      copyFileSync(this.path, backup)
      const stale = readdirSync(dir)
        .filter(name => name.startsWith(`${base}.bak-`))
        .sort((a, b) => Number(b.slice(base.length + 5)) - Number(a.slice(base.length + 5)))
        .slice(UsageLedger.BACKUP_KEEP)
      for (const name of stale) {
        try {
          rmSync(join(dir, name))
        }
        catch {
          // 删除旧备份失败不影响主流程（下次轮换会再试）。
        }
      }
    }
    catch {
      // 备份尽力而为：失败绝不影响记账主路径。
      this.lastBackupAt = 0
    }
  }

  /** Stop timers and persist the final state. */
  dispose(): void {
    this.disposed = true
    if (this.saveTimer !== undefined) {
      clearTimeout(this.saveTimer)
      this.saveTimer = undefined
    }
    this.flush()
  }
}

/** Format one CNY amount with sensible precision. */
export function formatCny(value: number): string {
  if (value === 0) return '¥0'
  if (value < 0.01) return `¥${value.toFixed(4)}`
  if (value < 1) return `¥${value.toFixed(3)}`
  return `¥${value.toFixed(2)}`
}

/** Format one token count with thousands separators. */
export function formatTokens(value: number): string {
  return value.toLocaleString('en-US')
}

/** Describe one price row for reports. */
export function formatPrice(price: ModelPrice): string {
  return `输入(缓存命中) ${price.inputCacheHit}元/M, 输入(未命中) ${price.inputMiss}元/M, 输出 ${price.output}元/M`
}

/**
 * 把日桶与模型聚合序列化为 CSV（带 BOM，Excel 可直接打开 UTF-8）。
 * 行格式：kind,key,calls,tokens,cost。
 */
export function ledgerCsv(
  daily: ReadonlyArray<{ day: string; calls: number; tokens: number; cost: number }>,
  models: ReadonlyArray<readonly [string, UsageCounters]>,
): string {
  const esc = (value: string): string => (/[",\n]/.test(value) ? `"${value.replace(/"/g, '""')}"` : value)
  const lines = ['kind,key,calls,tokens,cost']
  for (const row of daily) {
    lines.push(`day,${row.day},${row.calls},${row.tokens},${row.cost.toFixed(4)}`)
  }
  for (const [model, row] of models) {
    lines.push(`model,${esc(model)},${row.calls},${usageTotalTokens(row)},${row.cost.toFixed(4)}`)
  }
  return `\ufeff${lines.join('\n')}\n`
}
