/**
 * 复式对账引擎：账本从「相信聚合数」升级为「可验证」。
 *
 * 世界级账本实践（复式记账的试算平衡）迁移到 token 成本账：
 * 记账路径同时写「明细账」（sessions + archived 行）与多个「总账」
 * （total / daily / models 聚合桶）。任何一处损坏、手改或版本迁移缺陷
 * 都会在对账中现形——而不是在预算误判或报表失真后才发现。
 *
 * 口径边界（诚实对账，不粉饰）：
 *  - 明细账是原始事实：rebalance 以 Σ(sessions) + Σ(archived) 重建 total；
 *  - 日桶是唯一的时间真源，无法从明细重建——日桶与总计的漂移只报告、不修复；
 *  - 模型表自 v0.2.0 才按调用记账，且会话行的 model 是「最后一次调用的模型」，
 *    跨模型会话的历史无法精确分解——模型漂移仅报告，不参与 ok 判定。
 */
import { usageTotalTokens } from './types.js'
import type { LedgerFile } from './types.js'

/** 一个聚合口径的求和（calls/tokens/cost）。 */
export interface AuditTotals {
  calls: number
  tokens: number
  cost: number
}

/** 一处漂移：某口径求和减总计（0 = 一致；负 = 总账多记）。 */
export interface AuditDrift extends AuditTotals {}

/** 一次完整对账报告。 */
export interface AuditReport {
  /** 明细与日桶均与总计一致（模型表口径边界不参与判定，见模块注释）。 */
  ok: boolean
  /** 总账（持久化的 total 桶）。 */
  total: AuditTotals
  /** 明细账求和：Σ 活跃会话行 + Σ 归档行。 */
  detail: AuditTotals
  /** 日桶求和：Σ 全部北京日桶。 */
  daily: AuditTotals
  /** 模型表求和：Σ 全部模型聚合行（仅报告口径，不参与 ok）。 */
  models: AuditTotals
  /** 明细账 − 总计：可修复漂移（rebalance 以明细为准覆盖总计）。 */
  detailDrift: AuditDrift
  /** 日桶 − 总计：不可自动修复（日桶是时间真源），仅报告。 */
  dailyDrift: AuditDrift
  /** 模型表 − 总计：口径边界（v0.2.0 起才按调用记账），仅报告。 */
  modelDrift: AuditDrift
}

const ZERO: AuditTotals = { calls: 0, tokens: 0, cost: 0 }

function addSum(
  target: AuditTotals,
  row: { calls: number; cost: number } & Parameters<typeof usageTotalTokens>[0], // mutation-ignore: 类型层索引访问，运行时中立（由 tsc 把关）
): void {
  target.calls += row.calls
  target.tokens += usageTotalTokens(row)
  target.cost += row.cost
}

function driftOf(sum: AuditTotals, total: AuditTotals): AuditDrift {
  return {
    calls: sum.calls - total.calls,
    tokens: sum.tokens - total.tokens,
    cost: sum.cost - total.cost,
  }
}

function isZero(d: AuditDrift): boolean {
  return d.calls === 0 && d.tokens === 0 && Math.abs(d.cost) < 1e-9
}

/**
 * 对一份账本文件做四向对账（纯函数，不修改数据）。
 * cost 用绝对容差 1e-9 吸收浮点累加的表示误差。
 */
export function auditFile(file: LedgerFile): AuditReport {
  const total: AuditTotals = { ...file.total }

  const detail: AuditTotals = { ...ZERO }
  for (const row of Object.values(file.sessions)) addSum(detail, row)
  for (const row of Object.values(file.archived ?? {})) {
    // 归档行 tokens 已按 usageTotalTokens 口径存好，直接累加。
    detail.calls += row.calls
    detail.tokens += row.tokens
    detail.cost += row.cost
  }

  const daily: AuditTotals = { ...ZERO }
  for (const row of Object.values(file.daily)) {
    daily.calls += row.calls
    daily.tokens += row.tokens
    daily.cost += row.cost
  }

  const models: AuditTotals = { ...ZERO }
  for (const row of Object.values(file.models ?? {})) addSum(models, row)

  const detailDrift = driftOf(detail, total)
  const dailyDrift = driftOf(daily, total)
  return {
    ok: isZero(detailDrift) && isZero(dailyDrift),
    total,
    detail,
    daily,
    models,
    detailDrift,
    dailyDrift,
    modelDrift: driftOf(models, total),
  }
}

/** 人类可读的对账结论（zh-CN），供日志与报表。 */
export function describeAudit(report: AuditReport): string[] {
  const lines: string[] = []
  const f = (n: number): string => n.toLocaleString('en-US')
  const fmt = (t: AuditTotals): string => `${f(t.calls)} 次调用 / ${f(t.tokens)} tokens / ¥${t.cost.toFixed(4)}`
  lines.push(`总计: ${fmt(report.total)}；明细: ${fmt(report.detail)}；日桶: ${fmt(report.daily)}；模型表: ${fmt(report.models)}`)
  if (report.ok) {
    lines.push('对账平衡：明细账与日桶均与总计一致')
    return lines
  }
  const d = report.detailDrift
  if (!isZero(d)) {
    lines.push(`明细漂移 ${d.calls >= 0 ? '+' : ''}${f(d.calls)} 次调用 / ${f(d.tokens)} tokens / ¥${d.cost.toFixed(4)}（可修复：rebalance 以明细为准重建总计）`)
  }
  const dd = report.dailyDrift
  if (!isZero(dd)) {
    lines.push(`日桶漂移 ${dd.calls >= 0 ? '+' : ''}${f(dd.calls)} 次调用 / ${f(dd.tokens)} tokens / ¥${dd.cost.toFixed(4)}（不可自动修复：日桶是唯一时间真源，请人工核查）`)
  }
  return lines
}
