/**
 * Prometheus 文本 exposition 格式导出：把私有账本接入世界标准可观测体系。
 *
 * 一份 /metrics 端点让账本的数据直接进 Prometheus / Grafana / VictoriaMetrics
 * ——无需任何专属采集器，运维世界的通用语言。所有指标均为即时快照
 * （counter 语义的累计值由账本自身保证单调），导出为纯文本、零依赖。
 *
 * 命名规范（Prometheus 最佳实践）：
 *  - 小写下划线，单位做后缀（_cny / _seconds）；
 *  - counter 用 _total 结尾，gauge 不加；
 *  - 每个指标带 HELP（一句话语义）与 TYPE。
 */

/** 指标快照的输入形状（由宿主从账本与洞察装配）。 */
export interface MetricsSnapshot {
  /** 账本数据版本号（任何变更 +1；观察变化事件的天然 gauge）。 */
  ledgerRev: number
  total: { calls: number; tokens: number; cost: number }
  today: { calls: number; tokens: number; cost: number }
  /** 活跃（未归档）会话数。 */
  sessionsActive: number
  /** 已归档会话数。 */
  sessionsArchived: number
  /** 日预算（0 = 未设置）。 */
  dailyBudget: number
  /** 前缀缓存命中率 0..1。 */
  cacheHitRate: number
  /** 前缀缓存累计节省金额（元）。 */
  cacheSavingsCny: number
  /** 峰时费用占比 0..1（仅 DeepSeek 样本）。 */
  peakCostShare: number
  /** 按当前燃烧速率外推的全天费用（元）。 */
  projectedEodCost: number
  /** 外推的本月总费用（元）。 */
  projectedMonthEndCost: number
  /** 定价页最近抓取时刻（Unix 秒；未知为 0）。 */
  pricingFetchedAtSeconds: number
  /** 定价抓取距今秒数（未知为 0）。 */
  pricingAgeSeconds: number
  /** 复式对账是否平衡（1 = 平衡）。 */
  auditOk: boolean
  /** 成本健康分 0..100（无适用维度时为 0）。 */
  healthScore: number
  /** 低产出会话数（大入小出，最多跟踪 3 个）。 */
  lowYieldCount: number
  /** 预算自动驾驶建议的日预算（元；0 = 观测不足无建议）。 */
  budgetAutopilotCny: number
  /** PVM 量效应：调用次数增减的贡献（元；无归因数据为 0）。 */
  pvmVolumeEffectCny: number
  /** PVM 结构效应：模型份额漂移的贡献（元）。 */
  pvmMixEffectCny: number
  /** PVM 效率效应：单次调用 token 规模变化的贡献（元）。 */
  pvmEfficiencyEffectCny: number
  /** PVM 价格效应：单位 token 价格变化的贡献（元）。 */
  pvmPriceEffectCny: number
  /** 最新观测日单位成本（元/次；无活跃日为 0）。 */
  unitCostCny: number
  /** 单位成本控制上限（元/次；观测不足为 0）。 */
  unitCostUclCny: number
  /** 最新观测日是否在控（1 = 在控或观测不足；0 = 失控警报）。 */
  spcInControl: boolean
  /** 预算跑道剩余天数（-1 = 未设置总预算或观测不足；99 = 燃烧率为零烧不完）。 */
  runwayDaysLeft: number
  /** 模型成本基尼系数 0..1（-1 = 实体不足无意义）。 */
  costGiniModels: number
  /** 模型成本前 3 累计占比 0..1（-1 = 无数据）。 */
  paretoTop3ShareModels: number
  /** 星期效应峰谷比（最贵/最便宜星期几；-1 = 无数据）。 */
  weekdayPeakTroughRatio: number
}

/** 数值格式化：整数原样，浮点保留足够精度，杜绝 NaN/Infinity 污染输出。 */
function num(value: number): string {
  if (!Number.isFinite(value)) return '0'
  return Number.isInteger(value) ? String(value) : String(Number(value.toFixed(6)))
}

/**
 * 渲染 Prometheus 文本 exposition 格式（每行以 \n 结尾）。
 * 纯函数：同一快照得到字节级相同的输出，便于测试与缓存。
 */
export function renderPrometheusMetrics(snap: MetricsSnapshot): string {
  const lines: string[] = []

  const metric = (name: string, help: string, type: 'counter' | 'gauge', rawValue: number): void => {
    const value = Number.isFinite(rawValue) ? rawValue : 0
    lines.push(`# HELP ${name} ${help}`)
    lines.push(`# TYPE ${name} ${type}`)
    lines.push(`${name} ${num(value)}`)
  }

  metric('dsh_usage_calls_total', 'Lifetime number of priced model calls.', 'counter', snap.total.calls)
  metric('dsh_usage_tokens_total', 'Lifetime tokens consumed (input + output + cache read + cache write).', 'counter', snap.total.tokens)
  metric('dsh_usage_cost_total_cny', 'Lifetime cost in CNY.', 'counter', snap.total.cost)
  metric('dsh_usage_today_calls', 'Model calls so far today (Beijing date).', 'gauge', snap.today.calls)
  metric('dsh_usage_today_tokens', 'Tokens so far today (Beijing date).', 'gauge', snap.today.tokens)
  metric('dsh_usage_today_cost_cny', 'Cost so far today (Beijing date).', 'gauge', snap.today.cost)
  metric('dsh_usage_sessions_active', 'Active (non-archived) sessions in the ledger.', 'gauge', snap.sessionsActive)
  metric('dsh_usage_sessions_archived', 'Sessions compacted into the archive bucket.', 'gauge', snap.sessionsArchived)
  metric('dsh_usage_budget_daily_cny', 'Configured daily budget in CNY (0 = unset).', 'gauge', snap.dailyBudget)
  metric('dsh_usage_budget_daily_ratio', 'Today cost over daily budget (0 when unset).', 'gauge', snap.dailyBudget > 0 ? snap.today.cost / snap.dailyBudget : 0)
  metric('dsh_usage_cache_hit_rate', 'Prefix cache hit rate over lifetime usage (0..1).', 'gauge', snap.cacheHitRate)
  metric('dsh_usage_cache_savings_cny', 'Estimated CNY saved by prefix cache hits vs miss-priced input.', 'gauge', snap.cacheSavingsCny)
  metric('dsh_usage_peak_cost_share', 'Share of recent DeepSeek cost in peak windows (0..1).', 'gauge', snap.peakCostShare)
  metric('dsh_usage_projected_eod_cost_cny', 'Projected end-of-day cost at the current burn rate.', 'gauge', snap.projectedEodCost)
  metric('dsh_usage_projected_month_end_cost_cny', 'Projected month-end cost from the daily-bucket trend.', 'gauge', snap.projectedMonthEndCost)
  metric('dsh_usage_pricing_fetched_timestamp_seconds', 'Unix seconds of the last successful pricing page fetch (0 = builtin).', 'gauge', snap.pricingFetchedAtSeconds)
  metric('dsh_usage_pricing_age_seconds', 'Age of the live pricing data in seconds (0 = builtin).', 'gauge', snap.pricingAgeSeconds)
  metric('dsh_usage_audit_ok', '1 when the double-entry audit balances (details vs totals).', 'gauge', snap.auditOk ? 1 : 0)
  metric('dsh_usage_health_score', 'Composite cost health score 0-100 (heuristic; lower = more optimization headroom).', 'gauge', snap.healthScore)
  metric('dsh_usage_low_yield_sessions', 'Sessions flagged low-yield: huge input with tiny output (top 3 tracked).', 'gauge', snap.lowYieldCount)
  metric('dsh_usage_budget_autopilot_cny', 'Suggested daily budget from the P90 of recent daily costs (0 = not enough data).', 'gauge', snap.budgetAutopilotCny)
  metric('dsh_usage_pvm_volume_effect_cny', 'PVM attribution: cost change explained by call volume growth (CNY; 0 = no data).', 'gauge', snap.pvmVolumeEffectCny)
  metric('dsh_usage_pvm_mix_effect_cny', 'PVM attribution: cost change explained by model mix drift, e.g. switching to pricier models (CNY).', 'gauge', snap.pvmMixEffectCny)
  metric('dsh_usage_pvm_efficiency_effect_cny', 'PVM attribution: cost change explained by tokens-per-call growth, e.g. context bloat (CNY).', 'gauge', snap.pvmEfficiencyEffectCny)
  metric('dsh_usage_pvm_price_effect_cny', 'PVM attribution: cost change explained by unit price changes, e.g. sheet updates or peak/off-peak mix (CNY).', 'gauge', snap.pvmPriceEffectCny)
  metric('dsh_usage_unit_cost_cny', 'Latest observed day cost per call (0 = no active day yet).', 'gauge', snap.unitCostCny)
  metric('dsh_usage_unit_cost_ucl_cny', 'SPC upper control limit for daily unit cost: median + 3 robust sigma (0 = not enough data).', 'gauge', snap.unitCostUclCny)
  metric('dsh_usage_spc_in_control', '1 when the latest day unit cost is within SPC control limits (or no data); 0 = cost regression alert.', 'gauge', snap.spcInControl ? 1 : 0)
  metric('dsh_usage_runway_days_left', 'Days of total budget left at the current active-day burn rate (-1 = unset/insufficient data; 99 = zero burn).', 'gauge', snap.runwayDaysLeft)
  metric('dsh_usage_cost_gini_models', 'Gini coefficient of cost concentration across models, 0..1 (higher = more concentrated; -1 = fewer than 4 active models).', 'gauge', snap.costGiniModels)
  metric('dsh_usage_pareto_top3_share_models', 'Cumulative cost share of the top 3 models, 0..1 (-1 = no data).', 'gauge', snap.paretoTop3ShareModels)
  metric('dsh_usage_weekday_peak_trough_ratio', 'Weekly seasonality: mean cost of the most expensive weekday over the cheapest (-1 = no data).', 'gauge', snap.weekdayPeakTroughRatio)
  metric('dsh_usage_ledger_rev', 'Ledger data revision; increments on every ledger mutation.', 'gauge', snap.ledgerRev)

  return `${lines.join('\n')}\n`
}
