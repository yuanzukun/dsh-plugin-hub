/**
 * Self-contained dashboard page (zh-CN).
 *
 * 纯静态 HTML（无服务端插值）：页面加载后经 `/api/usage-ledger` 拉取 JSON
 * 渲染，SSE `/api/usage-ledger/stream` 事件驱动刷新、30 秒轮询兜底。
 * 与宿主装配解耦——表现层改动不再触碰 index.ts。
 */
export const DASHBOARD_HTML = `<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>DeepSeek Harness 用量面板</title>
<style>
  :root { color-scheme: light dark; }
  body { font-family: -apple-system, "Segoe UI", "PingFang SC", "Microsoft YaHei", sans-serif; margin: 0; padding: 24px; background: #f6f7f9; color: #1f2329; }
  @media (prefers-color-scheme: dark) { body { background: #17181c; color: #e6e8eb; } .card, table { background: #202228 !important; } th { background: #26282f !important; } }
  h1 { font-size: 20px; margin: 0 0 4px; }
  .sub { color: #8a9099; font-size: 12px; margin-bottom: 20px; }
  .cards { display: flex; gap: 12px; flex-wrap: wrap; margin-bottom: 20px; }
  .card { background: #fff; border-radius: 10px; padding: 14px 18px; min-width: 180px; box-shadow: 0 1px 3px rgba(0,0,0,.06); }
  .card .label { font-size: 12px; color: #8a9099; }
  .card .value { font-size: 22px; font-weight: 600; margin-top: 4px; }
  .card .extra { font-size: 12px; color: #8a9099; margin-top: 2px; }
  .bar { height: 6px; border-radius: 3px; background: #e8eaed; margin-top: 8px; overflow: hidden; }
  .bar > div { height: 100%; border-radius: 3px; background: #3370ff; }
  .bar > div.warn { background: #f5a623; }
  .bar > div.exceed { background: #e5484d; }
  table { width: 100%; border-collapse: collapse; background: #fff; border-radius: 10px; overflow: hidden; box-shadow: 0 1px 3px rgba(0,0,0,.06); font-size: 13px; }
  th, td { text-align: left; padding: 9px 12px; border-bottom: 1px solid rgba(120,130,140,.12); }
  th { background: #fafbfc; font-weight: 600; color: #8a9099; font-size: 12px; }
  td.num, th.num { text-align: right; font-variant-numeric: tabular-nums; }
  h2 { font-size: 15px; margin: 24px 0 10px; }
  .tag { display: inline-block; font-size: 11px; padding: 1px 8px; border-radius: 9px; background: #eef3ff; color: #3370ff; }
  .trend { display: flex; align-items: flex-end; gap: 4px; height: 140px; background: #fff; border-radius: 10px; padding: 12px; box-shadow: 0 1px 3px rgba(0,0,0,.06); }
  .trend .tbar { flex: 1; min-width: 12px; background: #3370ff; border-radius: 3px 3px 0 0; }
  .trend .tbar.zero { background: #e8eaed; }
  .trend-cap { font-size: 12px; color: #8a9099; margin-top: 6px; }
  .heatmap { display: grid; grid-auto-flow: column; grid-template-rows: repeat(7, 13px); grid-auto-columns: 13px; gap: 3px; background: #fff; border-radius: 10px; padding: 12px; box-shadow: 0 1px 3px rgba(0,0,0,.06); overflow-x: auto; }
  .heatmap .cell { border-radius: 2px; background: #e8eaed; }
  .heatmap .cell.l1 { background: #dbe4ff; }
  .heatmap .cell.l2 { background: #a5b8ff; }
  .heatmap .cell.l3 { background: #6f8dff; }
  .heatmap .cell.l4 { background: #3d63f5; }
  .heatmap .cell.l5 { background: #2149c9; }
  .share { background: #e8eaed; border-radius: 3px; height: 8px; overflow: hidden; }
  .share > div { height: 100%; background: #3370ff; border-radius: 3px; }
  ul.insights { margin: 0; padding-left: 18px; font-size: 13px; }
  ul.insights li { margin: 4px 0; }
</style>
</head>
<body>
<h1>DeepSeek Harness 用量面板</h1>
<div class="sub" id="meta">加载中…</div>
<div class="cards" id="cards"></div>
<h2>成本洞察</h2>
<ul id="insights" class="insights"></ul>
<h2>近 14 天费用趋势</h2>
<div id="trend" class="trend"></div>
<div class="trend-cap" id="trendcap"></div>
<h2>成本日历（近 15 周）</h2>
<div id="heatmap" class="heatmap"></div>
<div class="trend-cap" id="heatmapcap"></div>
<h2>按对话消耗</h2>
<table id="sessions">
  <thead><tr><th>会话</th><th>模型</th><th class="num">调用</th><th class="num">输入 tokens</th><th class="num">输出 tokens</th><th class="num">缓存读 tokens</th><th class="num">费用</th><th>最近更新</th></tr></thead>
  <tbody></tbody>
</table>
<h2>模型成本分布</h2>
<table id="models">
  <thead><tr><th>模型</th><th class="num">调用</th><th class="num">输入 tokens</th><th class="num">输出 tokens</th><th class="num">费用</th><th style="width:140px">费用占比</th></tr></thead>
  <tbody></tbody>
</table>
<h2>当前定价（国产主流大模型）</h2>
<div id="pricing"></div>
<script>
const fmtCny = v => v === 0 ? '¥0' : v < 0.01 ? '¥' + v.toFixed(4) : v < 1 ? '¥' + v.toFixed(3) : '¥' + v.toFixed(2);
const fmtNum = v => v.toLocaleString('en-US');
const fmtHm = t => new Date(t + 8 * 3600000).toISOString().slice(11, 16);
// HTML 转义：会话标题/模型名等外部数据进 innerHTML 前必须经过，杜绝注入。
const ESC_MAP = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
const esc = s => String(s).replace(/[&<>"']/g, c => ESC_MAP[c]);
function budgetCard(label, state, note) {
  if (!state) return '';
  const pct = state.budget > 0 ? Math.min(100, state.ratio * 100) : 0;
  const cls = state.exceeded ? 'exceed' : state.warn ? 'warn' : '';
  const extra = state.budget > 0
    ? fmtCny(state.cost) + ' / ' + fmtCny(state.budget) + (state.exceeded ? '（已超出）' : '')
    : '未设置预算，已花费 ' + fmtCny(state.cost);
  return '<div class="card"><div class="label">' + label + '</div><div class="value">' + fmtCny(state.cost) + '</div>'
    + '<div class="extra">' + extra + '</div>'
    + (state.budget > 0 ? '<div class="bar"><div class="' + cls + '" style="width:' + pct + '%"></div></div>' : '')
    + (note ? '<div class="extra" style="color:#e5484d">' + note + '</div>' : '')
    + '</div>';
}
async function load() {
  const data = await (await fetch('/api/usage-ledger')).json();
  const fmtTime = t => t ? new Date(t).toLocaleString('zh-CN') : '-';
  const ins = data.insights ?? {};
  document.getElementById('meta').textContent = '统计日期 ' + data.day + '（北京时间） · 定价来源 '
    + (data.pricing.source === 'live' ? '官方页面自动抓取' : '内置快照')
    + ' · 定价抓取于 ' + fmtTime(data.pricing.fetchedAt)
    + (data.pricing.lastChangedAt ? ' · 官方价格变更于 ' + fmtTime(data.pricing.lastChangedAt) : '')
    + ' · 数据更新于 ' + fmtTime(data.generatedAt);
  const proj = ins.projection ?? {};
  const eff = ins.efficiency ?? {};
  const projNote = proj.projectedExceed && proj.exceedAt
    ? '按当前速度 ' + fmtHm(proj.exceedAt) + ' 将超出日预算' : '';
  const cachePct = ins.cache && ins.cache.calls > 0 ? (ins.cache.hitRate * 100).toFixed(1) + '%' : '-';
  const cacheExtra = ins.cache && ins.cache.calls > 0
    ? '缓存读 ' + fmtNum(ins.cache.cacheReadTokens) + ' / 总输入 ' + fmtNum(ins.cache.cacheReadTokens + ins.cache.inputTokens) + ' tokens'
    : '暂无数据';
  const saveExtra = eff.cacheSavingsCny > 0
    ? '较未命中价' + (eff.tokensPerCny > 0 ? ' · ' + fmtNum(Math.round(eff.tokensPerCny)) + ' tokens/元' : '')
    : '暂无节省数据';
  const offPeak = ins.offPeak ?? {};
  const offPeakPct = offPeak.samples > 0 ? (offPeak.peakCostShare * 100).toFixed(0) + '%' : '-';
  const offPeakExtra = offPeak.samples > 0
    ? '近 ' + offPeak.samples + ' 次调用 · 峰时段 9-12、14-18（北京时间）'
    : '暂无 DeepSeek 峰谷样本';
  const monthly = data.monthly || {};
  const monthExtra = monthly.monthToDateCost > 0
    ? '本月至今 ' + fmtCny(monthly.monthToDateCost) + ' · 剩 ' + (monthly.daysRemaining || 0) + ' 天'
    : '本月暂无消耗记录';
  // 0.7.0 成本健康分卡片。
  const health = ins.health || {};
  const healthParts = (health.components || []).map(c => c.label + ' ' + Math.round((c.ratio || 0) * 100) + '%').join(' ');
  const healthGradeMap = { excellent: '优', good: '良', fair: '中', poor: '差' };
  const healthPct = (health.components || []).length ? (health.score ?? 0) : '-';
  const healthExtra = (health.components || []).length
    ? (healthGradeMap[health.grade] || '-') + ' · ' + healthParts
    : '暂无评分数据';
  // 0.8.0 SPC 单位成本卡片：日单位成本的统计过程控制。
  const spc = ins.spc || {};
  const spcValue = spc.latestUnitCost !== undefined ? fmtCny(spc.latestUnitCost) : '-';
  const spcExtra = spc.ucl !== undefined
    ? (spc.status === 'above' ? '⛔ 超上限（成本回归）· 限 ' : spc.status === 'below' ? '✅ 破下限（显著改善）· 限 ' : '✓ 受控 · 限 ')
      + '[' + fmtCny(spc.lcl) + ', ' + fmtCny(spc.ucl) + ']'
    : '观测不足（需 7 个活跃日）';
  // 0.8.0 PVM 归因卡片：近期 vs 之前的四效应分解。
  const attr = ins.attribution || {};
  let attrValue = '-', attrExtra = '暂无归因数据（需 16 次调用）';
  if (attr.currentCost !== undefined) {
    const d = attr.currentCost - attr.baselineCost;
    const sgn = v => (v >= 0 ? '+' : '-') + fmtCny(Math.abs(v));
    attrValue = (d >= 0 ? '+' : '-') + fmtCny(Math.abs(d));
    attrExtra = '量 ' + sgn(attr.volumeEffect) + ' · 结构 ' + sgn(attr.mixEffect)
      + ' · 效率 ' + sgn(attr.efficiencyEffect) + ' · 价格 ' + sgn(attr.priceEffect);
  }
  // 0.9.0 预算跑道卡片：burn rate × runway。
  const rw = ins.runway;
  let rwValue = '-', rwExtra = '未设置总预算或观测不足（需 3 个活跃日）';
  if (rw !== undefined) {
    if (!Number.isFinite(rw.daysLeft)) { rwValue = '∞'; rwExtra = '燃烧率为零 · 剩余 ' + fmtCny(rw.remaining); }
    else if (rw.daysLeft <= 0) { rwValue = '超支'; rwExtra = '已超 ' + fmtCny(-rw.remaining) + ' · 日均 ' + fmtCny(rw.dailyBurn); }
    else {
      rwValue = Math.floor(rw.daysLeft) + ' 天';
      rwExtra = '约 ' + (rw.exhaustedBy || '?') + ' 耗尽 · 日均 ' + fmtCny(rw.dailyBurn);
    }
  }
  // 0.9.0 成本集中度卡片：基尼系数 + 关键少数。
  const pt = ins.modelPareto;
  let ptValue = '-', ptExtra = '实体不足（需 ≥ 4 个有消耗的模型）';
  if (pt !== undefined) {
    const top = (pt.items || [])[0] || {};
    ptValue = (pt.gini ?? 0).toFixed(2);
    ptExtra = '前 ' + (pt.fewCount ?? 0) + '/' + (pt.count ?? 0) + ' 模型占 80%'
      + (top.key ? ' · 最高 ' + top.key + ' ' + Math.round((top.share || 0) * 100) + '%' : '');
  }
  // 定价过期预警：live 数据失联超 3 个刷新周期时在 meta 行提示。
  const fetchedAt = (data.pricing || {}).fetchedAt;
  const srcIsLive = (data.pricing || {}).source === 'live';
  if (srcIsLive && fetchedAt && Date.now() - fetchedAt > 3 * 60 * 60 * 1000) {
    document.getElementById('meta').textContent += ' · ⚠️ 定价数据 ' + Math.floor((Date.now() - fetchedAt) / 3.6e6) + ' 小时未刷新';
  }
  const arch = data.archived ?? {};
  document.getElementById('cards').innerHTML =
    budgetCard('今日花费', data.budgets.daily, projNote) + budgetCard('累计花费', data.budgets.total)
    + '<div class="card"><div class="label">今日调用</div><div class="value">' + data.today.calls + '</div><div class="extra">' + fmtNum(data.today.tokens) + ' tokens</div></div>'
    + '<div class="card"><div class="label">累计调用</div><div class="value">' + data.total.calls + '</div><div class="extra">' + fmtNum(data.total.tokens) + ' tokens</div></div>'
    + '<div class="card"><div class="label">前缀缓存命中率</div><div class="value">' + cachePct + '</div><div class="extra">' + cacheExtra + '</div></div>'
    + '<div class="card"><div class="label">缓存已节省</div><div class="value">' + fmtCny(eff.cacheSavingsCny || 0) + '</div><div class="extra">' + saveExtra + '</div></div>'
    + '<div class="card"><div class="label">峰时费用占比</div><div class="value">' + offPeakPct + '</div><div class="extra">' + offPeakExtra + '</div></div>'
    + '<div class="card"><div class="label">月末费用投影</div><div class="value">' + fmtCny((data.monthly || {}).projectedMonthEndCost || 0) + '</div><div class="extra">' + monthExtra + '</div></div>'
    + '<div class="card"><div class="label">成本健康分</div><div class="value">' + healthPct + '</div><div class="extra">' + healthExtra + '</div></div>'
    + '<div class="card"><div class="label">单位成本</div><div class="value">' + spcValue + '</div><div class="extra">' + spcExtra + '</div></div>'
    + '<div class="card"><div class="label">近期成本归因</div><div class="value">' + attrValue + '</div><div class="extra">' + attrExtra + '</div></div>'
    + '<div class="card"><div class="label">预算跑道</div><div class="value">' + rwValue + '</div><div class="extra">' + rwExtra + '</div></div>'
    + '<div class="card"><div class="label">成本集中度</div><div class="value">' + ptValue + '</div><div class="extra">' + ptExtra + '</div></div>';
  // 复式对账状态：平衡显示勾、漂移显示差值（数据可信性一目了然）。
  if (data.audit) {
    const drift = data.audit.detailDrift;
    const balanced = data.audit.ok;
    document.getElementById('meta').textContent += ' · 对账' + (balanced ? '平衡 ✓' : '漂移：明细 ' + (drift.calls >= 0 ? '+' : '') + fmtNum(drift.calls) + ' 次 / ¥' + drift.cost.toFixed(4));
  }
  if (arch.sessions > 0) {
    document.getElementById('meta').textContent += ' · 已归档 ' + arch.sessions + ' 个历史会话（' + fmtCny(arch.cost) + '）';
  }
  document.getElementById('insights').innerHTML = (ins.notes ?? []).map(n => '<li>' + esc(n) + '</li>').join('')
    || '<li>暂无建议</li>';
  const hist = data.history ?? [];
  if (hist.length > 0) {
    const maxCost = Math.max(...hist.map(h => h.cost), 0.0001);
    document.getElementById('trend').innerHTML = hist.map(h =>
      '<div class="tbar' + (h.cost === 0 ? ' zero' : '') + '" style="height:' + Math.max(4, h.cost / maxCost * 116) + 'px" title="' + h.day + '：' + fmtCny(h.cost) + '，' + h.calls + ' 次调用"></div>').join('');
    const peak = hist.reduce((a, b) => b.cost > a.cost ? b : a, hist[0]);
    document.getElementById('trendcap').textContent = '峰值 ' + peak.day.slice(5) + ' ' + fmtCny(peak.cost) + ' · 悬停柱条查看每日明细';
  }
  // 0.8.0 成本日历：GitHub 贡献图式消费节律（sqrt 分桶抗长尾，首列对齐周一）。
  const hm = data.heatmap ?? [];
  if (hm.length > 0) {
    const maxCost = Math.max(...hm.map(h => h.cost), 0.0001);
    const lvl = c => c === 0 ? 0 : Math.min(5, 1 + Math.floor(Math.sqrt(c / maxCost) * 5));
    const firstDow = (new Date(hm[0].day + 'T00:00:00Z').getUTCDay() + 6) % 7;
    document.getElementById('heatmap').innerHTML =
      '<i class="cell" style="visibility:hidden"></i>'.repeat(firstDow)
      + hm.map(h => '<i class="cell l' + lvl(h.cost) + '" title="' + h.day + '：' + fmtCny(h.cost) + '，' + h.calls + ' 次调用"></i>').join('');
    const active = hm.filter(h => h.calls > 0).length;
    const peak = hm.reduce((a, b) => b.cost > a.cost ? b : a, hm[0]);
    document.getElementById('heatmapcap').textContent =
      '近 ' + hm.length + ' 天中 ' + active + ' 天有消耗 · 峰值 ' + peak.day + ' ' + fmtCny(peak.cost) + ' · 悬停查看每日明细';
  }
  const mtbody = document.querySelector('#models tbody');
  const models = data.models ?? [];
  const totalModelCost = models.reduce((a, m) => a + m.cost, 0);
  mtbody.innerHTML = models.length === 0 ? '<tr><td colspan="6">暂无记录</td></tr>' : models.map(m =>
    '<tr><td>' + esc(m.model) + '</td><td class="num">' + m.calls + '</td>'
    + '<td class="num">' + fmtNum(m.inputTokens + m.cacheReadTokens + m.cacheWriteTokens) + '</td>'
    + '<td class="num">' + fmtNum(m.outputTokens) + '</td>'
    + '<td class="num">' + fmtCny(m.cost) + '</td>'
    + '<td><div class="share"><div style="width:' + (totalModelCost > 0 ? Math.round(m.cost / totalModelCost * 100) : 0) + '%"></div></div></td></tr>').join('');
  const tbody = document.querySelector('#sessions tbody');
  tbody.innerHTML = data.sessions.length === 0 ? '<tr><td colspan="8">暂无记录</td></tr>' : data.sessions.map(row =>
    '<tr><td>' + esc(row.title || row.id.slice(0, 12)) + '</td><td>' + esc(row.model || '-') + '</td>'
    + '<td class="num">' + row.calls + '</td><td class="num">' + fmtNum(row.inputTokens) + '</td>'
    + '<td class="num">' + fmtNum(row.outputTokens) + '</td><td class="num">' + fmtNum(row.cacheReadTokens) + '</td>'
    + '<td class="num">' + fmtCny(row.cost) + '</td><td>' + new Date(row.updatedAt).toLocaleString('zh-CN') + '</td></tr>').join('');
  const pdiv = document.getElementById('pricing');
  const srcTag = v => v.source === 'live' ? '<span class="tag">官方实时</span>' : v.source === 'override' ? '<span class="tag">自定义</span>' : '<span class="tag">内置快照</span>';
  const fetchedTag = v => v.fetchedAt ? ' <span class="tag">抓取于 ' + fmtTime(v.fetchedAt) + '</span>' : '';
  pdiv.innerHTML = (data.pricing.vendors ?? []).map(v =>
    '<h3 style="font-size:13px;margin:16px 0 6px;color:#8a9099">' + esc(v.label) + ' ' + srcTag(v) + (v.tiered ? ' <span class="tag">阶梯计价·最低档</span>' : '') + fetchedTag(v) + '</h3>'
    + '<table><thead><tr><th>模型</th><th class="num">输入·缓存命中 (元/M)</th><th class="num">输入·未命中 (元/M)</th><th class="num">输出 (元/M)</th></tr></thead><tbody>'
    + Object.entries(v.models).map(([model, p]) =>
      '<tr><td>' + esc(model) + '</td><td class="num">' + p.inputCacheHit + '</td><td class="num">' + p.inputMiss + '</td><td class="num">' + p.output + '</td></tr>').join('')
    + '</tbody></table>').join('');
}
load().catch(e => document.getElementById('meta').textContent = '加载失败: ' + e);
// 轮询保底（SSE 断开时仍每 30 秒刷新）。
setInterval(() => load().catch(() => {}), 30000);
// SSE 实时流：新记账到达即刷新（事件驱动优先，轮询仅兜底）。
try {
  const es = new EventSource('/api/usage-ledger/stream');
  es.addEventListener('ledger', () => load().catch(() => {}));
  es.onerror = () => es.close();
} catch (e) { /* EventSource 不可用时静默回退到轮询 */ }
</script>
</body>
</html>`
