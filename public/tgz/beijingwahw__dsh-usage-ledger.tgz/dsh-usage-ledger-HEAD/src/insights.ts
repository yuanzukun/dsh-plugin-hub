/**
 * 成本智能引擎：把账本从「事后记录」升级为「实时顾问」。
 *
 * 四类洞察（全部由已记账数据推导，零额外网络开销）：
 *  1. 前缀缓存命中分析 —— 命中率低说明会话前缀不稳定，是最大的隐性成本黑洞；
 *  2. 预算燃烧速率投影 —— 按今日已消耗速度外推全天费用与超支时点；
 *  3. 异常调用检测 —— 对近期单次调用成本做 z-score 离群检测（换模型/失控循环会现形）；
 *  4. 跨模型比价 —— 同等 token 量在其它厂商旗舰模型下的假设成本（粗略估算）。
 */
import { beijingDate } from './types.js'
import type { UsageCounters } from './types.js'
import { costOf, isPeakTime } from './pricing.js'
import type { ModelPrice } from './types.js'
import { formatCny as cny } from './ledger.js'

/** 前缀缓存命中分析。 */
export interface CacheHitInsight {
  /** 命中率 cacheRead / (cacheRead + uncached input)，0..1。 */
  hitRate: number
  /** 缓存读 tokens（命中部分）。 */
  cacheReadTokens: number
  /** 未命中输入 tokens。 */
  inputTokens: number
  /** 参与统计的调用次数。 */
  calls: number
}

/** 今日预算燃烧速率投影。 */
export interface DailyProjection {
  /** 北京日已过小时数（自北京时间 0 点起算）。 */
  hoursElapsed: number
  /** 当前燃烧速率（元/小时）。 */
  pacePerHour: number
  /** 按当前速度外推的全天费用（元）。 */
  projectedEodCost: number
  /** 日预算（0 = 未设置）。 */
  dailyBudget: number
  /** 外推全天费用是否将超出日预算。 */
  projectedExceed: boolean
  /** 预计超出日预算的时刻（Unix ms，仅当按当前速度今日会超支时有值）。 */
  exceedAt?: number
}

/** 一次被判定为离群的单次调用。 */
export interface CostAnomaly {
  time: number
  sessionId: string
  model?: string
  cost: number
  /** (cost - mean) / std。 */
  zScore: number
}

/** 同等用量在其它模型下的假设成本。 */
export interface AlternativeCost {
  model: string
  vendor: string
  /** 实际已花费（全部模型合计）。 */
  currentCost: number
  /** 假设成本（元）。 */
  alternativeCost: number
  /** 预计节省比例 0..1（负值表示更贵）。 */
  savingsRatio: number
}

/** 错峰机会：峰谷电价经济学迁移到 token 经济。 */
export interface OffPeakOpportunity {
  /** 参与统计的 DeepSeek 样本数（其它厂商无峰谷价，不计入）。 */
  samples: number
  /** 峰时（9-12、14-18 北京时间）调用的费用占比 0..1。 */
  peakCostShare: number
  /** 峰时调用的次数占比 0..1。 */
  peakCallShare: number
}

/** 一次完整洞察快照。 */
export interface InsightSet {
  cache: CacheHitInsight
  projection: DailyProjection
  anomalies: CostAnomaly[]
  alternatives: AlternativeCost[]
  /** 生成效率指标（缓存节省金额等）。 */
  efficiency: EfficiencyInsight
  /** 错峰机会（峰时费用占比，仅 DeepSeek 峰谷价模型）。 */
  offPeak: OffPeakOpportunity
  /** 下次调用成本预报（最近活动会话的输入趋势外推；样本不足时缺省）。 */
  forecast?: NextCallForecast
  /** 成本健康分（五维等权启发式，详见 healthScore）。 */
  health: HealthScore
  /** 低产出会话（大量输入、极少输出；提示复查，非判定浪费）。 */
  lowYield: LowYieldSession[]
  /** 预算自动驾驶建议（近 30 天花费分布 P90 外推；观测不足时缺省）。 */
  budget?: BudgetSuggestion
  /** PVM 成本归因（近期两窗口四效应精确分解；样本不足时缺省）。 */
  attribution?: CostAttribution
  /** 单位成本 SPC 控制图（日桶级统计过程控制；观测不足时缺省）。 */
  spc?: UnitCostControl
  /** 模型成本的 Pareto/基尼集中度（实体不足时缺省）。 */
  modelPareto?: ParetoInsight
  /** 日成本的 Pareto/基尼集中度（实体不足时缺省）。 */
  dayPareto?: ParetoInsight
  /** 预算跑道（设了总预算且有活跃日才有；否则缺省）。 */
  runway?: RunwayInsight
  /** 星期效应（周周期性；观测不足时缺省）。 */
  dayOfWeek?: DayOfWeekInsight
  /** 人类可读建议（zh-CN），按重要性排序。 */
  notes: string[]
}

/** 近期调用样本（内存环形缓冲中的最小记录）。 */
export interface RecentSample {
  time: number
  sessionId: string
  model?: string
  cost: number
  /** 本次调用输入规模（未命中 + 缓存读 tokens，供上下文趋势预报）。 */
  inputTokens?: number
  /** 本次调用输出 tokens（PVM 归因的效率效应输入）。 */
  outputTokens?: number
}

/** 生成效率指标：钱花得值不值。 */
export interface EfficiencyInsight {
  /** 前缀缓存较全部按未命中价已节省的金额（元，按当前价格估算）。 */
  cacheSavingsCny: number
  /** 输出 tokens 占全部 token 流量的比例（生成占比）。 */
  outputRatio: number
  /** 思考 tokens 占输出 tokens 的比例（推理密度）。 */
  reasoningRatio: number
  /** 每元产出多少 tokens（性价比；cost 为 0 时为 0）。 */
  tokensPerCny: number
  /** 成本四维归因（按行级模型现价重算，口径与 cacheSavingsCny 一致）。 */
  breakdown: CostBreakdown
}

/** 每一元花在了哪里：按 token 用途归因的成本分解。 */
export interface CostBreakdown {
  /** 输入·未命中：inputTokens 按未命中价。 */
  inputCost: number
  /** 输出：outputTokens 按输出价。 */
  outputCost: number
  /** 缓存写：cacheWriteTokens 按未命中价（DeepSeek 口径）。 */
  cacheWriteCost: number
  /** 输入·缓存命中部分折算成本（节省后实付，仅为参考）。 */
  cacheReadCost: number
}

/** 会话行形状：UsageCounters 加上可选路由与会话标识信息。 */
type LedgerRow = UsageCounters & { model?: string; id?: string; title?: string }

/** 各厂商同档旗舰代表模型（跨模型比价候选，按 vendorOf 前缀识别厂商）。 */
const ALTERNATIVE_CANDIDATES = [
  'deepseek-v4-pro',
  'glm-4.6',
  'kimi-k2.6',
  'qwen3-plus',
  'doubao-seed-2.0-pro',
  'minimax-m2.7',
  'ernie-4.5',
] as const

/** 北京时间 HH:mm。 */
export function beijingHm(ms: number): string {
  return new Date(ms + 8 * 3600_000).toISOString().slice(11, 16)
}

/**
 * 前缀缓存命中分析。会话行与总计行都满足 UsageCounters 形状。
 */
export function cacheHitInsight(counters: UsageCounters): CacheHitInsight {
  const total = counters.cacheReadTokens + counters.inputTokens
  return {
    hitRate: total > 0 ? counters.cacheReadTokens / total : 0,
    cacheReadTokens: counters.cacheReadTokens,
    inputTokens: counters.inputTokens,
    calls: counters.calls,
  }
}

/**
 * 按今日已消耗速度外推全天费用与超支时点。
 * 凌晨刚过 0 点时燃烧速率噪声极大，用 0.25 小时下限保护。
 */
export function dailyProjection(now: number, dailyCost: number, dailyBudget: number): DailyProjection {
  const dayStart = Date.parse(`${beijingDate(now)}T00:00:00+08:00`)
  const hoursElapsed = Math.max((now - dayStart) / 3_600_000, 0.25)
  const pacePerHour = dailyCost / hoursElapsed
  const projectedEodCost = pacePerHour * 24
  const projection: DailyProjection = {
    hoursElapsed,
    pacePerHour,
    projectedEodCost,
    dailyBudget,
    projectedExceed: dailyBudget > 0 && projectedEodCost > dailyBudget,
  }
  if (dailyBudget > 0 && pacePerHour > 0 && dailyCost < dailyBudget) {
    const hoursToExceed = (dailyBudget - dailyCost) / pacePerHour
    if (hoursToExceed < 24 - hoursElapsed) {
      projection.exceedAt = now + hoursToExceed * 3_600_000
    }
  }
  return projection
}

/** 月度成本投影（日桶最小二乘趋势外推）。 */
export interface MonthlyProjection {
  /** 参与趋势拟合的日桶数（缺数据的日期补零，是真实的「无消耗」观测）。 */
  daysObserved: number
  /** 北京月至今累计费用（元）。 */
  monthToDateCost: number
  /** 最小二乘拟合的每日费用趋势（元/天；可能为负 = 消耗在回落）。 */
  slopePerDay: number
  /** 本月剩余天数（含今天之后的整日）。 */
  daysRemaining: number
  /** 外推的本月总费用（元；趋势为负时按零增长下限保护）。 */
  projectedMonthEndCost: number
}

/**
 * 月度成本投影：对最近日桶做最小二乘线性回归，外推到月底。
 *
 * 日预算只看今天，月度预算才决定充值档位——这是从「日节奏」到「月规划」
 * 的升维。补零的空日也参与拟合（无消耗是真实观测，不是缺失数据）。
 * 斜率为负（消耗回落）时按下限保护：月末不会低于月至今累计。
 */
export function monthlyProjection(
  now: number,
  daily: ReadonlyArray<{ day: string; cost: number }>,
): MonthlyProjection {
  const today = beijingDate(now)
  const [year, month, dayOfMonth] = today.split('-').map(Number)
  const y = year ?? 1970
  const m = month ?? 1
  const d = dayOfMonth ?? 1
  // Date.UTC 的月份是 0 起：day 取 0 即上一个月最后一天 = 本月天数。
  const daysInMonth = new Date(Date.UTC(y, m, 0)).getUTCDate()
  const daysRemaining = Math.max(0, daysInMonth - d)

  const prefix = `${String(y).padStart(4, '0')}-${String(m).padStart(2, '0')}`
  let monthToDateCost = 0
  for (const row of daily) {
    if (row.day.startsWith(prefix)) monthToDateCost += row.cost
  }

  // 最小二乘：x = 0..n-1（天序），y = 当日费用。
  const n = daily.length
  const meanX = (n - 1) / 2
  const meanY = daily.reduce((a, row) => a + row.cost, 0) / Math.max(n, 1)
  let num = 0
  let den = 0
  daily.forEach((row, i) => {
    num += (i - meanX) * (row.cost - meanY)
    den += (i - meanX) ** 2
  })
  const slopePerDay = den > 0 ? num / den : 0

  return {
    daysObserved: n,
    monthToDateCost,
    slopePerDay,
    daysRemaining,
    projectedMonthEndCost: monthToDateCost + Math.max(0, slopePerDay) * daysRemaining,
  }
}

/**
 * 中位数绝对偏差（MAD）稳健离群检测。
 *
 * 为什么放弃经典 z-score：均值与标准差会被离群值本身污染——一次极端
 * 调用把均值拉高、方差撑大后，其余真异常反而被稀释漏检（masking 效应）。
 * MAD 以中位数为中心，天然抗污染：最多 50% 的样本被破坏仍不受影响。
 *
 * 稳健分（modified z-score，Iglewicz-Hoaglin）：0.6745×(x−median)/MAD，
 * 0.6745 = Φ⁻¹(3/4)，使正态总体下与经典 z-score 同尺度。阈值 3.5 为
 * 稳健统计的标准推荐。样本不足（<8 条）时返回空。
 */
export function detectAnomalies(samples: ReadonlyArray<RecentSample>): CostAnomaly[] {
  if (samples.length < 8) return []
  const costs = samples.map(s => s.cost)
  const median = medianOf(costs)
  const deviations = costs.map(c => Math.abs(c - median))
  let scale = medianOf(deviations)
  if (scale === 0) {
    // MAD 边界：超过半数样本完全相同（如大量 ¥1 的常规调用）时 MAD=0。
    // 回退到平均绝对偏差（meanAD），仍以中位数为中心，保持抗污染。
    scale = deviations.reduce((a, b) => a + b, 0) / deviations.length
  }
  if (scale === 0) return []
  const anomalies = samples
    .filter(s => s.cost > median && (0.6745 * (s.cost - median)) / scale > 3.5)
    .map(s => ({ ...s, zScore: (0.6745 * (s.cost - median)) / scale }))
    .sort((a, b) => b.cost - a.cost)
  return anomalies.slice(0, 3)
}

/** 中位数：偶数样本取中间两值的平均。 */
function medianOf(values: ReadonlyArray<number>): number {
  const sorted = [...values].sort((a, b) => a - b)
  const mid = Math.floor(sorted.length / 2)
  return sorted.length % 2 === 1 ? sorted[mid]! : (sorted[mid - 1]! + sorted[mid]!) / 2
}

/**
 * 跨模型比价：把累计 token 用量放到候选模型价格下重算。
 * 各厂商 tokenizer 不同，结果仅是量级参考——notes 中已注明口径。
 * priceOf 为价格解析回调（注入 PriceService.resolve），便于测试。
 */
export function alternativeCosts(
  usage: { inputTokens: number; outputTokens: number; cacheReadTokens?: number; cacheWriteTokens?: number },
  currentCost: number,
  usedModels: ReadonlySet<string>,
  vendorOf: (model: string) => string | undefined,
  priceOf: (model: string) => ModelPrice | undefined,
): AlternativeCost[] {
  const total = usage.inputTokens + (usage.cacheReadTokens ?? 0) + (usage.cacheWriteTokens ?? 0) + usage.outputTokens
  if (total <= 0 || currentCost <= 0) return []
  const result: AlternativeCost[] = []
  for (const model of ALTERNATIVE_CANDIDATES) {
    if (usedModels.has(model)) continue
    const price = priceOf(model)
    const vendor = vendorOf(model)
    if (price === undefined || vendor === undefined) continue
    const alternativeCost = costOf(price, usage)
    if (alternativeCost <= 0) continue
    result.push({
      model,
      vendor,
      currentCost,
      alternativeCost,
      savingsRatio: 1 - alternativeCost / currentCost,
    })
  }
  return result.sort((a, b) => a.alternativeCost - b.alternativeCost).slice(0, 3)
}

/** 汇总多行计数器（会话行求和 / 模型行求和通用）。 */
export function sumCounters(rows: Iterable<UsageCounters>): UsageCounters {
  const total: UsageCounters = {
    calls: 0, inputTokens: 0, outputTokens: 0,
    cacheReadTokens: 0, cacheWriteTokens: 0, reasoningTokens: 0, cost: 0,
  }
  for (const row of rows) {
    total.calls += row.calls
    total.inputTokens += row.inputTokens
    total.outputTokens += row.outputTokens
    total.cacheReadTokens += row.cacheReadTokens
    total.cacheWriteTokens += row.cacheWriteTokens
    total.reasoningTokens += row.reasoningTokens
    total.cost += row.cost
  }
  return total
}

/**
 * 生成效率指标。缓存节省金额按行级模型现价估算：
 * Σ cacheReadTokens × (未命中价 − 命中价)，只统计正差价模型。
 */
export function efficiencyInsight(
  rows: ReadonlyArray<LedgerRow>,
  priceOf: (model: string) => ModelPrice | undefined,
): EfficiencyInsight {
  let savings = 0
  let inputTokens = 0
  let outputTokens = 0
  let cacheRead = 0
  let cacheWrite = 0
  let reasoning = 0
  let cost = 0
  const breakdown: CostBreakdown = { inputCost: 0, outputCost: 0, cacheWriteCost: 0, cacheReadCost: 0 }
  for (const row of rows) {
    inputTokens += row.inputTokens
    outputTokens += row.outputTokens
    cacheRead += row.cacheReadTokens
    cacheWrite += row.cacheWriteTokens
    reasoning += row.reasoningTokens
    cost += row.cost
    if (row.model !== undefined) {
      const price = priceOf(row.model)
      if (price !== undefined) {
        if (price.inputMiss > price.inputCacheHit) {
          savings += row.cacheReadTokens * (price.inputMiss - price.inputCacheHit) / 1_000_000
        }
        // 四维归因：同一价格口径下分解每一元的去向。
        breakdown.inputCost += row.inputTokens * price.inputMiss / 1_000_000
        breakdown.outputCost += row.outputTokens * price.output / 1_000_000
        breakdown.cacheWriteCost += row.cacheWriteTokens * price.inputMiss / 1_000_000
        breakdown.cacheReadCost += row.cacheReadTokens * price.inputCacheHit / 1_000_000
      }
    }
  }
  const totalTokens = inputTokens + outputTokens + cacheRead + cacheWrite
  return {
    cacheSavingsCny: savings,
    outputRatio: totalTokens > 0 ? outputTokens / totalTokens : 0,
    reasoningRatio: outputTokens > 0 ? reasoning / outputTokens : 0,
    tokensPerCny: cost > 0 ? totalTokens / cost : 0,
    breakdown,
  }
}

/** 下一次调用的成本预报（上下文趋势外推）。 */
export interface NextCallForecast {
  /** 参与外推的会话内最近样本数（不足 3 条不预报）。 */
  samples: number
  /** 外推出的下次调用输入规模（tokens，含缓存读）。 */
  nextInputTokens: number
  /** 按该会话当前模型现价预估的下一次调用成本（元，仅输入侧）。 */
  nextInputCost: number
}

/**
 * 下次调用成本预报：对同一会话最近几次的输入规模做线性外推。
 *
 * 上下文只会单调增长（历史消息 + 工具结果持续累积），输入规模的趋势
 * 就是未来成本的先行指标。线性外推斜率为负时按零增长处理（保守）。
 * priceOf 需为该会话模型现价；预报只含输入侧（输出不可预知）。
 */
export function forecastNextCall(
  samples: ReadonlyArray<RecentSample>,
  sessionId: string,
  priceOf: (model: string) => ModelPrice | undefined,
): NextCallForecast | undefined {
  const recent = samples.filter(s => s.sessionId === sessionId && s.inputTokens !== undefined)
  if (recent.length < 3) return undefined
  const last = recent[recent.length - 1]!
  if (last.model === undefined) return undefined
  const price = priceOf(last.model)
  if (price === undefined) return undefined
  const window = recent.slice(-5)
  const n = window.length
  const meanX = (n - 1) / 2
  const meanY = window.reduce((a, s) => a + (s.inputTokens ?? 0), 0) / n
  let num = 0
  let den = 0
  window.forEach((s, i) => {
    num += (i - meanX) * ((s.inputTokens ?? 0) - meanY)
    den += (i - meanX) ** 2
  })
  const slope = den > 0 ? num / den : 0
  // 斜率下限 0：上下文不会缩小，但外推为负显然失真。
  const nextInputTokens = Math.max(meanY + slope * (n - meanX), (last.inputTokens ?? 0))
  const nextInputCost = nextInputTokens * price.inputMiss / 1_000_000
  return { samples: recent.length, nextInputTokens, nextInputCost }
}

/**
 * 错峰机会：统计近期 DeepSeek 调用落在峰时段（北京 9-12、14-18）的费用占比。
 * 峰谷价差客观存在（如 deepseek-v4-pro 输入未命中 9 vs 4.5 元/M），
 * 占比高说明把可推迟的任务挪到谷时段是零改造的降本手段。
 * 样本来自内存环形缓冲（近期调用），非全量历史——口径在 notes 中注明。
 */
export function offPeakOpportunity(samples: ReadonlyArray<RecentSample>): OffPeakOpportunity {
  let peakCalls = 0
  let peakCost = 0
  let totalCalls = 0
  let totalCost = 0
  for (const s of samples) {
    // 只有 DeepSeek 系模型有峰谷价，其它厂商计价恒定，计入只会稀释占比。
    if (!s.model?.startsWith('deepseek')) continue
    totalCalls += 1
    totalCost += s.cost
    if (isPeakTime(s.time)) {
      peakCalls += 1
      peakCost += s.cost
    }
  }
  return {
    samples: totalCalls,
    peakCostShare: totalCost > 0 ? peakCost / totalCost : 0,
    peakCallShare: totalCalls > 0 ? peakCalls / totalCalls : 0,
  }
}

/** 成本健康分的单一维度。 */
export interface HealthComponent {
  key: 'cache' | 'pacing' | 'stability' | 'offpeak' | 'yield'
  label: string
  /** 维度得分 0..1；数据不足时不适用（缺省，不参与综合分）。 */
  ratio?: number
  /** 维度现状说明（zh-CN）。 */
  note: string
}

/** 成本健康分：把多维洞察压缩成一个可一眼扫视的数字。 */
export interface HealthScore {
  /** 综合分 0..100（仅由适用维度等权平均；无适用维度时为 0）。 */
  score: number
  grade: 'excellent' | 'good' | 'fair' | 'poor'
  components: HealthComponent[]
}

/** 低产出会话（大量输入、极少输出——大概率是大文件通读或检索过宽）。 */
export interface LowYieldSession {
  sessionId: string
  title?: string
  inputTokens: number
  outputTokens: number
  /** 输出 tokens 占该会话全部 token 流量的比例。 */
  outputRatio: number
  cost: number
}

/** 预算自动驾驶建议（由历史花费分布学习，而非拍脑袋设数）。 */
export interface BudgetSuggestion {
  /** 建议日预算（元）= 近期日花费 P90 × 1.1。 */
  suggestedDailyBudget: number
  /** 参与统计的天数（含补零空日）。 */
  daysObserved: number
  /** 近期日花费的 P90（线性插值，与 Excel PERCENTILE.INC 同口径）。 */
  percentile90: number
  /** 当前预算是否与建议一致（±20% 内）。 */
  aligned: boolean
}

/** 等级中文标签。 */
const GRADE_LABELS: Record<HealthScore['grade'], string> = { excellent: '优', good: '良', fair: '中', poor: '差' }

/** 产出占比维度：输出 /（输入+输出）达到该比例即满分（再高边际收益趋零）。 */
const YIELD_FULL_MARK_RATIO = 0.2

/**
 * 成本健康分：五个维度等权综合的启发式指标（像信用分之于信用记录）。
 *
 * 诚实设计：数据不足的维度弃权（不奖励也不惩罚）——新账本、无预算、
 * 无 DeepSeek 峰谷样本时各自退出，综合分仅由适用维度平均得出。
 * 维度各自只测一件事：缓存维度已奖励缓存命中，产出维度只看
 * 输出/(输入+输出)（缓存读不进分母），避免重复计分。
 */
export function healthScore(args: {
  cache: CacheHitInsight
  projection: DailyProjection
  dailyBudget: number
  anomalyCount: number
  recentCount: number
  offPeak: OffPeakOpportunity
  usageTotals: UsageCounters
}): HealthScore {
  const components: HealthComponent[] = []

  const totalInput = args.cache.cacheReadTokens + args.cache.inputTokens
  if (args.cache.calls >= 8 && totalInput > 0) {
    components.push({
      key: 'cache',
      label: '缓存效率',
      ratio: args.cache.hitRate,
      note: `命中率 ${(args.cache.hitRate * 100).toFixed(0)}%`,
    })
  }
  if (args.dailyBudget > 0) {
    const projected = Math.max(args.projection.projectedEodCost, 0)
    const ratio = projected <= args.dailyBudget ? 1 : Math.max(0, args.dailyBudget / projected)
    components.push({
      key: 'pacing',
      label: '预算节奏',
      ratio,
      note: projected <= args.dailyBudget
        ? `外推全天 ${cny(projected)} 在预算内`
        : `外推全天 ${cny(projected)} 将超预算`,
    })
  }
  if (args.recentCount >= 8) {
    const ratio = Math.max(0, 1 - args.anomalyCount / args.recentCount)
    components.push({
      key: 'stability',
      label: '调用稳定',
      ratio,
      note: args.anomalyCount === 0 ? '近期无异常调用' : `近期 ${args.anomalyCount} 次异常`,
    })
  }
  if (args.offPeak.samples >= 8) {
    components.push({
      key: 'offpeak',
      label: '峰谷纪律',
      ratio: 1 - args.offPeak.peakCostShare,
      note: `峰时费用占比 ${(args.offPeak.peakCostShare * 100).toFixed(0)}%`,
    })
  }
  const ioFlow = args.usageTotals.inputTokens + args.usageTotals.outputTokens
  if (ioFlow > 0) {
    const outputRatio = args.usageTotals.outputTokens / ioFlow
    components.push({
      key: 'yield',
      label: '产出占比',
      ratio: Math.min(1, outputRatio / YIELD_FULL_MARK_RATIO),
      note: `输出占输入输出流量 ${(outputRatio * 100).toFixed(0)}%`,
    })
  }

  const applicable = components.filter(c => c.ratio !== undefined)
  const score = applicable.length > 0
    ? Math.round((applicable.reduce((a, c) => a + (c.ratio ?? 0), 0) / applicable.length) * 100)
    : 0
  const grade: HealthScore['grade'] = score >= 80 ? 'excellent' : score >= 60 ? 'good' : score >= 40 ? 'fair' : 'poor'
  return { score, grade, components }
}

/** 低产出会话的输入规模门槛（tokens，含缓存读）。 */
const LOW_YIELD_INPUT_FLOOR = 200_000
/** 低产出会话的输出占比上限（输出/全部流量）。 */
const LOW_YIELD_OUTPUT_RATIO = 0.02

/**
 * 低产出会话检测：输入 ≥ 200k tokens 且输出占全部流量 < 2% 的会话。
 * 读 50 万 tokens 只产出 1 千——钱花在「看」上而非「产出」上，典型于
 * 大文件通读、检索过宽、失败重试。注意：摘要/审计类任务天然低产出，
 * 命中仅提示复查，不是判定浪费。
 */
export function lowYieldSessions(rows: ReadonlyArray<LedgerRow>): LowYieldSession[] {
  const findings: LowYieldSession[] = []
  for (const row of rows) {
    if (row.id === undefined) continue
    const input = row.inputTokens + row.cacheReadTokens + row.cacheWriteTokens
    if (input < LOW_YIELD_INPUT_FLOOR) continue
    const total = input + row.outputTokens
    const outputRatio = total > 0 ? row.outputTokens / total : 0
    if (outputRatio >= LOW_YIELD_OUTPUT_RATIO) continue
    findings.push({
      sessionId: row.id,
      title: row.title !== undefined && row.title !== '' ? row.title : undefined,
      inputTokens: input,
      outputTokens: row.outputTokens,
      outputRatio,
      cost: row.cost,
    })
  }
  return findings.sort((a, b) => b.cost - a.cost).slice(0, 3)
}

/**
 * 预算自动驾驶：从近 30 天日花费分布的 P90 学习日预算。
 *
 * 手动设预算要么拍脑袋、要么抄别人——P90 说的「覆盖你九成历史日」
 * 才是自己的数：偶发尖峰日不误报，常态超支日也拦得住。建议值再留
 * 10% 余量。需要 ≥7 天观测（含补零空日——不花钱也是真实观测）。
 */
export function budgetAutopilot(
  dailyHistory: ReadonlyArray<{ day: string; cost: number }>,
  currentBudget: number,
): BudgetSuggestion | undefined {
  if (dailyHistory.length < 7) return undefined
  const costs = dailyHistory.map(d => d.cost).sort((a, b) => a - b)
  if (costs.reduce((a, b) => a + b, 0) <= 0) return undefined
  // P90：线性插值分位。
  const rank = 0.9 * (costs.length - 1)
  const lo = Math.floor(rank)
  const hi = Math.ceil(rank)
  const base = costs[lo] ?? 0
  const top = costs[hi] ?? base
  const percentile90 = base + (top - base) * (rank - lo)
  const suggestedDailyBudget = percentile90 * 1.1
  const aligned = currentBudget > 0 && Math.abs(currentBudget - suggestedDailyBudget) / suggestedDailyBudget <= 0.2
  return { suggestedDailyBudget, daysObserved: costs.length, percentile90, aligned }
}

/** PVM 成本归因：把两窗口成本差精确分解为四个可加效应（无残差项）。 */
export interface CostAttribution {
  /** 基线窗口花费（元，较早的一半）。 */
  baselineCost: number
  /** 对比窗口花费（元，较近的一半）。 */
  currentCost: number
  /** 量效应：调用次数等比增减的纯量贡献（元；正 = 增支）。 */
  volumeEffect: number
  /** 结构效应：模型份额漂移（换模型/新模型）的贡献（元）。 */
  mixEffect: number
  /** 效率效应：单次调用 token 规模变化的贡献（元）。 */
  efficiencyEffect: number
  /** 价格效应：单位 token 价格变化的贡献（元；调价或峰谷结构变化）。 */
  priceEffect: number
  /** 基线窗口调用次数。 */
  baselineCalls: number
  /** 对比窗口调用次数。 */
  currentCalls: number
  /** 基线窗口首样本时刻（Unix ms）。 */
  baselineStart: number
  /** 对比窗口首样本时刻（Unix ms）。 */
  currentStart: number
  /** 成本变动比例（基线为 0 时为 0）。 */
  changeRatio: number
}

/**
 * PVM 成本归因：零售与财务分析的黄金标准（Price-Volume-Mix）移植到 token 经济。
 *
 * 「这周为什么比上周多花 37 元」不再是一笔糊涂账——精确拆成四个可加
 * 效应，恒等式严格成立：volume + mix + efficiency + price = ΔCost，无残差：
 *  - 量效应   (N₁−N₀)·c̄₀                     —— 调用次数等比增减；
 *  - 结构效应 Σ(n_m1−N₁·s_m0)·c̄_m0 ＋ 新模型   —— 模型份额漂移（换更贵的模型）；
 *  - 效率效应 Σ n_m1·(t̄_m1−t̄_m0)·p̄_m0        —— 单次调用 token 规模（上下文变长）；
 *  - 价格效应 Σ n_m1·t̄_m1·(p̄_m1−p̄_m0)         —— 单位 token 价格（调价、峰谷结构）。
 *
 * 以环形缓冲的时间中点切两个窗口（各需 ≥8 个样本）。内存态数据、重启即
 * 失效——与逐次异常检测同一口径，不影响账本正确性。比率指标 cost/call
 * 与 cost/token 不受「窗口进行时」影响（比率是无偏的）。
 */
export function costAttribution(samples: ReadonlyArray<RecentSample>): CostAttribution | undefined {
  if (samples.length < 16) return undefined
  const first = samples[0]!.time
  const last = samples[samples.length - 1]!.time
  if (last <= first) return undefined
  const mid = (first + last) / 2
  const baselineSamples = samples.filter(s => s.time <= mid)
  const currentSamples = samples.filter(s => s.time > mid)
  if (baselineSamples.length < 8 || currentSamples.length < 8) return undefined

  interface ModelStat { calls: number; tokens: number; cost: number }
  const statsOf = (arr: ReadonlyArray<RecentSample>): Map<string, ModelStat> => {
    const map = new Map<string, ModelStat>()
    for (const s of arr) {
      const key = s.model ?? '(unknown)'
      const stat = map.get(key) ?? { calls: 0, tokens: 0, cost: 0 }
      stat.calls += 1
      stat.tokens += (s.inputTokens ?? 0) + (s.outputTokens ?? 0)
      stat.cost += s.cost
      map.set(key, stat)
    }
    return map
  }
  const base = statsOf(baselineSamples)
  const cur = statsOf(currentSamples)
  const n0 = baselineSamples.length
  const n1 = currentSamples.length
  const c0 = baselineSamples.reduce((a, s) => a + s.cost, 0)
  const c1 = currentSamples.reduce((a, s) => a + s.cost, 0)

  // 量效应：调用次数变化 × 基线平均单次成本（等比缩放的纯量部分）。
  const volumeEffect = (n1 - n0) * (c0 / n0)

  let mixEffect = 0
  let efficiencyEffect = 0
  let priceEffect = 0
  for (const [model, b] of base) {
    const c = cur.get(model)
    const avgCost0 = b.cost / b.calls
    const share0 = b.calls / n0
    if (c === undefined) {
      // 模型退出：其基线份额按当前总量等比放大后未被使用，负贡献计入结构。
      mixEffect += -n1 * share0 * avgCost0
      continue
    }
    // 结构：偏离等比缩放的部分（份额向贵模型漂移为正，向便宜模型为负）。
    mixEffect += (c.calls - n1 * share0) * avgCost0
    const t0 = b.tokens / b.calls
    const t1 = c.tokens / c.calls
    const p0 = b.tokens > 0 ? b.cost / b.tokens : 0
    const p1 = c.tokens > 0 ? c.cost / c.tokens : 0
    efficiencyEffect += c.calls * (t1 - t0) * p0
    priceEffect += c.calls * t1 * (p1 - p0)
  }
  for (const [model, c] of cur) {
    // 新模型：无基线可比，全部成本都是结构漂移。
    if (!base.has(model)) mixEffect += c.cost
  }

  return {
    baselineCost: c0,
    currentCost: c1,
    volumeEffect,
    mixEffect,
    efficiencyEffect,
    priceEffect,
    baselineCalls: n0,
    currentCalls: n1,
    baselineStart: baselineSamples[0]!.time,
    currentStart: currentSamples[0]!.time,
    changeRatio: c0 > 0 ? (c1 - c0) / c0 : 0,
  }
}

/** 单位成本的 SPC 控制图：日桶级统计过程控制。 */
export interface UnitCostControl {
  /** 基线天数（不含被评定的最新观测日）。 */
  daysObserved: number
  /** 中心线：近期日单位成本的中位数（元/次，抗离群）。 */
  baselineUnitCost: number
  /** 稳健 σ 估计（1.4826×MAD；MAD 退化时回退平均绝对偏差）。 */
  sigma: number
  /** 控制上限（元/次，中心线 + 3σ）。 */
  ucl: number
  /** 控制下限（元/次，中心线 − 3σ，非负截断）。 */
  lcl: number
  /** 最新观测日的单位成本（元/次）。 */
  latestUnitCost: number
  /** 最新观测日（北京日期）。 */
  latestDay: string
  /** 判定：in = 受控 / above = 超上限（成本回归）/ below = 破下限（显著改善）。 */
  status: 'in' | 'above' | 'below'
  /** 基线期内越限天数（过程稳定性参考；持续越限说明过程本身不稳定）。 */
  outOfControlDays: number
}

/**
 * 单位成本控制图：把制造业的统计过程控制（SPC / Shewhart 控制图）移植
 * 到 token 经济。过程指标 = 日单位成本（cost/call）——比率指标，不受
 * 「今天还没过完」的进行时影响（区别于日累计费用的天然偏小）。
 *
 * 中心线取中位数、σ 取 1.4826×MAD（正态下与经典 σ 同尺度）——与逐次
 * 调用异常检测同一稳健哲学：基线不被离群日污染（一次失控日不会把限
 * 撑宽，从而漏报次日的失控）。最新观测日不参与基线估计：用历史过程
 * 评价新点，这是 SPC 的正确姿势。3σ 判界（Shewhart 经典）。
 * MAD = 0（过半天数完全相同）时回退平均绝对偏差，口径同 detectAnomalies。
 */
export function unitCostControl(
  daily: ReadonlyArray<{ day: string; calls?: number; cost: number }>,
): UnitCostControl | undefined {
  const observed = daily.filter(d => (d.calls ?? 0) > 0)
  if (observed.length < 7) return undefined
  const latest = observed[observed.length - 1]!
  const baselineDays = observed.slice(0, -1)
  const units = baselineDays.map(d => d.cost / (d.calls ?? 1))
  const center = medianOf(units)
  const deviations = units.map(u => Math.abs(u - center))
  let scale = medianOf(deviations)
  if (scale === 0) scale = deviations.reduce((a, b) => a + b, 0) / deviations.length
  const sigma = 1.4826 * scale
  const ucl = center + 3 * sigma
  const lcl = Math.max(0, center - 3 * sigma)
  const latestUnitCost = latest.cost / (latest.calls ?? 1)
  const status: UnitCostControl['status'] = latestUnitCost > ucl ? 'above' : latestUnitCost < lcl ? 'below' : 'in'
  return {
    daysObserved: baselineDays.length,
    baselineUnitCost: center,
    sigma,
    ucl,
    lcl,
    latestUnitCost,
    latestDay: latest.day,
    status,
    outOfControlDays: units.filter(u => u > ucl || u < lcl).length,
  }
}

/** Pareto 集中度分析：经济学百年经典的「关键少数」。 */
export interface ParetoInsight {
  /** 实体总数（零成本实体已剔除）。 */
  count: number
  /** 基尼系数 0..1（0 = 完全均匀；越接近 1 越集中）。 */
  gini: number
  /** 前 3 个实体的累计成本占比。 */
  top3Share: number
  /** 覆盖 80% 成本所需的最少实体数（关键少数）。 */
  fewCount: number
  /** 按成本降序的实体列表（含单份额与累计份额）。 */
  items: Array<{ key: string; cost: number; share: number; cumulative: number }>
}

/**
 * Pareto/基尼集中度分析：把经济学的分配不平等度量（基尼系数，Corrado
 * Gini, 1912）移植到 token 成本分布——「钱都花到哪去了」。
 *
 * 基尼 = Σᵢⱼ|xᵢ−xⱼ| / (2n²μ)。完全均匀 → 0；单一实体独占 → (n−1)/n → 1。
 * 与 80/20 法则（Pareto, 1896）配合：fewCount 指出覆盖 80% 成本的最少
 * 实体数——优化投入应该精准砸向这几个「关键少数」，边际收益最高。
 * 实体数 < 4 时基尼无统计意义，返回 undefined（诚实弃权）。
 */
export function paretoOf(entries: ReadonlyArray<{ key: string; cost: number }>): ParetoInsight | undefined {
  const active = entries.filter(e => e.cost > 0)
  if (active.length < 4) return undefined
  const sorted = [...active].sort((a, b) => b.cost - a.cost)
  const total = sorted.reduce((a, e) => a + e.cost, 0)
  if (total <= 0) return undefined
  const costs = sorted.map(e => e.cost)
  // 基尼系数：两两绝对差之和 / (2n²μ)。
  let pairSum = 0
  for (const x of costs) for (const y of costs) pairSum += Math.abs(x - y)
  const gini = pairSum / (2 * costs.length * costs.length * (total / costs.length))
  const items: ParetoInsight['items'] = []
  let cumulative = 0
  for (const e of sorted) {
    cumulative += e.cost
    items.push({ key: e.key, cost: e.cost, share: e.cost / total, cumulative: cumulative / total })
  }
  const fewCount = items.findIndex(i => i.cumulative >= 0.8) + 1
  return {
    count: items.length,
    gini,
    top3Share: items.length >= 3 ? items[2]!.cumulative : items[items.length - 1]!.cumulative,
    fewCount: fewCount === 0 ? items.length : fewCount,
    items,
  }
}

/** 预算跑道（创业金融的生死指标：burn rate × runway）。 */
export interface RunwayInsight {
  /** 总预算（元；0 = 未设置）。 */
  totalBudget: number
  /** 已花费（元）。 */
  spent: number
  /** 剩余（元；超支为负）。 */
  remaining: number
  /** 近期日均燃烧率（元/天，活跃日口径）。 */
  dailyBurn: number
  /** 剩余可烧天数（Infinity = 燃烧率为零，预算用不完）。 */
  daysLeft: number
  /** 按当前燃烧率的耗尽日（北京日期；null = 不可算或烧不完）。 */
  exhaustedBy: string | null
  /** 用于燃烧率的活跃天数。 */
  burnDays: number
}

/**
 * 预算跑道：把 VC 与创业公司财务的 burn rate / runway 移植到 token 预算
 * ——「按现在这个烧法，钱还能用几天」。这是创业金融里最直白的生死指
 * 标：runway 归零即公司（这里：总预算）死亡。
 *
 * 燃烧率取活跃日均值而非自然日均值：休息日不稀释真实消耗节奏（与
 * 预算自动驾驶同一口径哲学）。仅当设置了总预算时才有意义。
 */
export function runwayOf(
  now: number,
  totalBudget: number,
  spent: number,
  daily: ReadonlyArray<{ day: string; cost: number }>,
): RunwayInsight | undefined {
  if (totalBudget <= 0) return undefined
  if (daily.length < 3) return undefined
  const activeDays = daily.filter(d => d.cost > 0)
  if (activeDays.length === 0) {
    // 有观测但全部免费：燃烧率为零，跑道无限。
    return { totalBudget, spent, remaining: totalBudget - spent, dailyBurn: 0, daysLeft: Number.POSITIVE_INFINITY, exhaustedBy: null, burnDays: 0 }
  }
  const burn = activeDays.reduce((a, d) => a + d.cost, 0) / activeDays.length
  const remaining = totalBudget - spent
  const daysLeft = burn > 0 ? remaining / burn : Number.POSITIVE_INFINITY
  let exhaustedBy: string | null = null
  if (burn > 0 && remaining > 0 && daysLeft <= 3650) {
    exhaustedBy = beijingDate(now + daysLeft * 86_400_000)
  }
  return {
    totalBudget,
    spent,
    remaining,
    dailyBurn: burn,
    daysLeft,
    exhaustedBy,
    burnDays: activeDays.length,
  }
}

/** 星期效应：周周期性（时间序列季节分解的周期分量）。 */
export interface DayOfWeekInsight {
  /** 观测天数。 */
  daysObserved: number
  /** 已覆盖的星期位（0=周一..6=周日）。 */
  weekdaysCovered: number
  /** 各星期位平均日花费（索引 0..6；缺样本为 NaN）。 */
  averages: number[]
  /** 最贵星期位。 */
  peakWeekday: number
  /** 最贵与最便宜星期位的花费比。 */
  peakTroughRatio: number
  /** 周期性是否显著（峰谷比 ≥ 1.6 且每位 ≥ 2 样本）。 */
  significant: boolean
}

/** 星期位的中文标签（索引 0..6 = 周一..周日）。 */
export const WEEKDAY_LABELS = ['周一', '周二', '周三', '周四', '周五', '周六', '周日'] as const

/**
 * 星期效应：把时间序列分析的季节分解（seasonal decomposition）思想移植
 * 到日成本序列——剥离趋势后剩下的「周周期分量」。回答：周几天然最贵？
 *
 * 每个星期位至少 2 个样本才计入（避免单日噪声冒充规律）；峰谷比 ≥ 1.6
 * 才判定显著。峰谷比 < 1.6 说明消耗节奏无周周期，稳定本身也是信息。
 */
export function dayOfWeekEffect(daily: ReadonlyArray<{ day: string; cost: number }>): DayOfWeekInsight | undefined {
  if (daily.length < 10) return undefined
  const buckets: number[][] = [[], [], [], [], [], [], []]
  for (const d of daily) {
    // 北京日期 → 星期位（0=周一..6=周日）。注意必须用 UTC 零点锚定：
    // 用 +08:00 会把时刻回退到前一天 16:00，星期位整体偏移一天。
    const dow = (new Date(`${d.day}T00:00:00Z`).getUTCDay() + 6) % 7
    buckets[dow]!.push(d.cost)
  }
  const covered = buckets.filter(b => b.length >= 2)
  if (covered.length < 3) return undefined
  const averages = buckets.map(b => (b.length >= 2 ? b.reduce((a, c) => a + c, 0) / b.length : Number.NaN))
  const valid = buckets
    .map((b, i) => ({ dow: i, avg: averages[i]! }))
    .filter(v => !Number.isNaN(v.avg))
  const peak = valid.reduce((a, b) => (b.avg > a.avg ? b : a))
  const trough = valid.reduce((a, b) => (b.avg < a.avg ? b : a))
  const peakTroughRatio = trough.avg > 0 ? peak.avg / trough.avg : Number.POSITIVE_INFINITY
  return {
    daysObserved: daily.length,
    weekdaysCovered: valid.length,
    averages,
    peakWeekday: peak.dow,
    peakTroughRatio,
    significant: valid.length >= 3 && peakTroughRatio >= 1.6,
  }
}

/**
 * 组装一次完整洞察并生成人类可读建议。
 * @param now 观测时刻。
 * @param rows 会话行（既用于求和，也用于按行级模型估价缓存节省）。
 * @param currentCost 实际累计花费。
 * @param dailyCost 今日已花费。
 * @param dailyBudget 日预算（0 = 未设置）。
 * @param usedModels 已实际使用过的模型 id 集合（比价时排除自身）。
 * @param recentSamples 近期调用样本（内存环形缓冲）。
 * @param vendorOf 价格目录的厂商识别函数。
 * @param priceOf 价格解析回调（通常为 PriceService#resolve 绑定 now）。
 */
export function buildInsights(
  now: number,
  rows: ReadonlyArray<LedgerRow>,
  currentCost: number,
  dailyCost: number,
  dailyBudget: number,
  usedModels: ReadonlySet<string>,
  recentSamples: ReadonlyArray<RecentSample>,
  vendorOf: (model: string) => string | undefined,
  priceOf: (model: string) => ModelPrice | undefined,
  dailyHistory: ReadonlyArray<{ day: string; calls?: number; cost: number }> = [],
  totalBudget = 0,
  modelEntries: ReadonlyArray<{ key: string; cost: number }> = [],
): InsightSet {
  const usageTotals = sumCounters(rows)
  const cache = cacheHitInsight(usageTotals)
  const projection = dailyProjection(now, dailyCost, dailyBudget)
  const anomalies = detectAnomalies(recentSamples)
  const alternatives = alternativeCosts(usageTotals, currentCost, usedModels, vendorOf, priceOf)
  const efficiency = efficiencyInsight(rows, priceOf)
  const offPeak = offPeakOpportunity(recentSamples)
  // 下次调用预报：对最近活动的会话做输入趋势外推（事前感知，区别于事后统计）。
  const activeSession = recentSamples.length > 0 ? recentSamples[recentSamples.length - 1]!.sessionId : undefined
  const forecast = activeSession === undefined ? undefined : forecastNextCall(recentSamples, activeSession, priceOf)
  const health = healthScore({
    cache,
    projection,
    dailyBudget,
    anomalyCount: anomalies.length,
    recentCount: recentSamples.length,
    offPeak,
    usageTotals,
  })
  const lowYield = lowYieldSessions(rows)
  const budget = budgetAutopilot(dailyHistory, dailyBudget)
  // 0.8.0 PVM 成本归因：近期两窗口的四效应精确分解。
  const attribution = costAttribution(recentSamples)
  // 0.8.0 SPC 控制图：日单位成本的统计过程控制（失控即警报）。
  const spc = unitCostControl(dailyHistory)
  // 0.9.0 Pareto/基尼集中度：模型维度与日维度的「关键少数」。
  const modelPareto = paretoOf(modelEntries)
  const dayPareto = paretoOf(dailyHistory.map(d => ({ key: d.day, cost: d.cost })))
  // 0.9.0 预算跑道：剩余预算还能烧几天（burn rate × runway）。
  const runway = runwayOf(now, totalBudget, currentCost, dailyHistory)
  // 0.9.0 星期效应：周周期分量（周几天然最贵）。
  const dayOfWeek = dayOfWeekEffect(dailyHistory)

  const notes: string[] = []
  const totalInput = cache.cacheReadTokens + cache.inputTokens
  if (cache.calls >= 8 && totalInput >= 50_000 && cache.hitRate < 0.5) {
    notes.push(`前缀缓存命中率仅 ${(cache.hitRate * 100).toFixed(0)}%，稳定会话前缀（系统提示与工具定义的顺序、内容保持不变）可显著降本`)
  }
  if (efficiency.cacheSavingsCny >= 0.01) {
    notes.push(`前缀缓存已为你节省约 ${cny(efficiency.cacheSavingsCny)}（按当前价格、较全部按未命中价估算）`)
  }
  if (projection.projectedExceed && projection.exceedAt !== undefined) {
    notes.push(`按当前燃烧速率（${cny(projection.pacePerHour)}/小时）预计全天花费 ${cny(projection.projectedEodCost)}，${beijingHm(projection.exceedAt)} 将超出日预算 ${cny(dailyBudget)}`)
  }
  if (forecast !== undefined && forecast.nextInputCost >= 0.5) {
    notes.push(`当前会话上下文持续增长，下一次调用输入约 ${forecast.nextInputTokens.toLocaleString('en-US')} tokens、仅输入侧预计约 ${cny(forecast.nextInputCost)}；必要时可压缩或重开会话`)
  }
  if (anomalies.length > 0) {
    const top = anomalies[0]!
    const median = medianOf(recentSamples.map(s => s.cost))
    notes.push(`检测到 ${anomalies.length} 次异常高价调用（最高单次 ${cny(top.cost)}，约为近期中位数 ${cny(median)} 的 ${(top.cost / Math.max(median, 0.0001)).toFixed(0)} 倍${top.model !== undefined ? `，模型 ${top.model}` : ''}）`)
  }
  const best = alternatives[0]
  if (best !== undefined && best.savingsRatio > 0.2) {
    notes.push(`同等 token 量下 ${best.model} 报价约 ${cny(best.alternativeCost)}（约省 ${(best.savingsRatio * 100).toFixed(0)}%；各厂 tokenizer 不同，仅供量级参考）`)
  }
  if (offPeak.samples >= 8 && offPeak.peakCostShare >= 0.5) {
    notes.push(`近期 ${offPeak.samples} 次 DeepSeek 调用有 ${(offPeak.peakCostShare * 100).toFixed(0)}% 的费用发生在峰时段（北京 9-12、14-18），可推迟的批量任务挪到谷时段可享约一半输入价`)
  }
  // 0.8.0 SPC 控制图：单位成本失控/显著改善都是「特殊原因变异」，值得被看见。
  if (spc !== undefined && spc.status !== 'in') {
    if (spc.status === 'above') {
      notes.push(`单位成本失控：${spc.latestDay} 单次调用均价 ${cny(spc.latestUnitCost)} 高于控制上限 ${cny(spc.ucl)}（基线 ${cny(spc.baselineUnitCost)}，近 ${spc.daysObserved} 天 3σ 控制图）——排查上下文膨胀、模型切换或失败重试`)
    }
    else {
      notes.push(`单位成本显著改善：${spc.latestDay} 单次调用均价 ${cny(spc.latestUnitCost)} 低于控制下限 ${cny(spc.lcl)}（基线 ${cny(spc.baselineUnitCost)}，3σ 控制图）——缓存生效或调用更精简，值得保持`)
    }
  }
  // 0.8.0 PVM 归因：变化显著（≥10% 且 ≥1 分钱）才报告，避免噪音。
  if (attribution !== undefined && attribution.changeRatio >= 0.1 && attribution.currentCost - attribution.baselineCost >= 0.01) {
    const delta = attribution.currentCost - attribution.baselineCost
    const signed = (v: number): string => `${v >= 0 ? '+' : '-'}${cny(Math.abs(v))}`
    notes.push(`成本归因（PVM）：近期 ${attribution.currentCalls} 次调用较之前 ${attribution.baselineCalls} 次多花 ${cny(delta)}（+${(attribution.changeRatio * 100).toFixed(0)}%）——量 ${signed(attribution.volumeEffect)}、结构 ${signed(attribution.mixEffect)}、效率 ${signed(attribution.efficiencyEffect)}、价格 ${signed(attribution.priceEffect)}`)
  }
  else if (attribution !== undefined && attribution.changeRatio <= -0.1 && attribution.baselineCost - attribution.currentCost >= 0.01) {
    const saved = attribution.baselineCost - attribution.currentCost
    const signed = (v: number): string => `${v >= 0 ? '+' : '-'}${cny(Math.abs(v))}`
    notes.push(`成本归因（PVM）：近期 ${attribution.currentCalls} 次调用较之前 ${attribution.baselineCalls} 次少花 ${cny(saved)}（${(attribution.changeRatio * 100).toFixed(0)}%）——量 ${signed(attribution.volumeEffect)}、结构 ${signed(attribution.mixEffect)}、效率 ${signed(attribution.efficiencyEffect)}、价格 ${signed(attribution.priceEffect)}`)
  }
  // 0.9.0 预算跑道：剩余天数是创业金融的生死指标，紧张才报告。
  if (runway !== undefined && Number.isFinite(runway.daysLeft)) {
    if (runway.daysLeft <= 0) {
      notes.push(`总预算已超支 ${cny(-runway.remaining)}（活跃日均燃烧 ${cny(runway.dailyBurn)}）——如需继续使用请上调总预算`)
    }
    else if (runway.daysLeft <= 14) {
      notes.push(`预算跑道仅剩 ${Math.floor(runway.daysLeft)} 天（约 ${runway.exhaustedBy ?? '?'} 耗尽，日均燃烧 ${cny(runway.dailyBurn)}）——要么放慢节奏，要么上调总预算`)
    }
    else if (runway.daysLeft <= 30) {
      notes.push(`预算跑道还剩 ${Math.floor(runway.daysLeft)} 天（约 ${runway.exhaustedBy ?? '?'} 耗尽，日均燃烧 ${cny(runway.dailyBurn)}）`)
    }
  }
  // 0.9.0 Pareto/基尼：高集中时优化「关键少数」边际收益最高。
  if (modelPareto !== undefined && modelPareto.top3Share >= 0.8) {
    const top = modelPareto.items[0]!
    notes.push(`成本高度集中：基尼系数 ${modelPareto.gini.toFixed(2)}，前 ${modelPareto.fewCount}/${modelPareto.count} 个模型占 80% 成本（最高 ${top.key} 占 ${(top.share * 100).toFixed(0)}%）——优化关键少数边际收益最高`)
  }
  // 0.9.0 星期效应：显著周周期才报告，稳定不制造噪音。
  if (dayOfWeek !== undefined && dayOfWeek.significant) {
    const peakLabel = WEEKDAY_LABELS[dayOfWeek.peakWeekday] ?? '?'
    notes.push(`周周期显著：${peakLabel}均花费 ${cny(dayOfWeek.averages[dayOfWeek.peakWeekday] ?? 0)}，是最便宜星期几的 ${dayOfWeek.peakTroughRatio.toFixed(1)} 倍（近 ${dayOfWeek.daysObserved} 天观测）——重活可避开 ${peakLabel}`)
  }
  if (lowYield.length > 0) {
    const top = lowYield[0]!
    const name = top.title ?? top.sessionId.slice(0, 12)
    notes.push(`低产出会话：${lowYield.length} 个会话输入庞大而输出极少（如「${name}」输入 ${top.inputTokens.toLocaleString('en-US')} tokens、输出占比 ${(top.outputRatio * 100).toFixed(1)}%、花费 ${cny(top.cost)}），建议复查大文件通读与检索范围`)
  }
  if (budget !== undefined && !budget.aligned) {
    notes.push(`预算自动驾驶：近 ${budget.daysObserved} 天花费的 P90 为 ${cny(budget.percentile90)}，建议把日预算设为约 ${cny(budget.suggestedDailyBudget)}（覆盖九成历史日）`)
  }
  const weakest = [...health.components]
    .filter(c => c.ratio !== undefined)
    .sort((a, b) => (a.ratio ?? 0) - (b.ratio ?? 0))[0]
  if (health.components.length > 0 && health.score < 60 && weakest !== undefined) {
    notes.push(`成本健康分 ${health.score}/100（${GRADE_LABELS[health.grade]}）：最薄弱维度是${weakest.label}（${weakest.note}）`)
  }

  return { cache, projection, anomalies, alternatives, efficiency, offPeak, forecast, health, lowYield, budget, attribution, spc, modelPareto, dayPareto, runway, dayOfWeek, notes }
}
