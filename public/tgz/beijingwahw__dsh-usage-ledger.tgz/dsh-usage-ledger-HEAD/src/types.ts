/**
 * Shared types for dsh-usage-ledger: per-model prices, price sheets, and the
 * persisted ledger file shape.
 */

/** Per-million-token prices for one model (CNY by default). */
export interface ModelPrice {
  /** Price per 1M input tokens that hit the prefix cache. */
  inputCacheHit: number
  /** Price per 1M input tokens that miss the cache. */
  inputMiss: number
  /** Price per 1M output tokens. */
  output: number
}

/** Model prices keyed by model id (e.g. `deepseek-v4-pro`). */
export type PriceTable = Record<string, ModelPrice>

/** Peak/off-peak schedule introduced by DeepSeek's time-of-day pricing. */
export interface ScheduledPricing {
  /** Beijing-calendar date (YYYY-MM-DD) from which the schedule applies. */
  effective: string
  /** Beijing-hour windows [start, end) billed at peak prices. */
  peakWindows?: ReadonlyArray<readonly [number, number]>
  /** Prices during off-peak hours. */
  offPeak: PriceTable
  /** Prices during peak hours. */
  peak: PriceTable
}

/** One resolved pricing snapshot, live-fetched or built-in fallback. */
export interface PriceSheet {
  source: 'live' | 'builtin'
  /** Unix ms of the successful fetch; absent for the built-in sheet. */
  fetchedAt?: number
  /** Source URL when fetched live. */
  sourceUrl?: string
  /** Flat prices used before any schedule takes effect. */
  current: PriceTable
  /** Optional upcoming/active peak/off-peak schedule. */
  scheduled?: ScheduledPricing
}

/** Token and cost counters shared by session, daily, and total aggregates. */
export interface UsageCounters {
  calls: number
  inputTokens: number
  outputTokens: number
  cacheReadTokens: number
  cacheWriteTokens: number
  reasoningTokens: number
  cost: number
}

/** Per-session aggregate row in the ledger. */
export interface SessionUsage extends UsageCounters {
  title: string
  provider?: string
  model?: string
  createdAt: number
  updatedAt: number
  /** Last folded session-log seq; guards against double-counting on resume. */
  lastSeq: number
}

/** One calendar-day (Beijing) bucket. */
export interface DailyUsage {
  calls: number
  tokens: number
  cost: number
}

/**
 * 压实归档的会话瘦行：丢弃明细、保留汇总与折叠水位。
 * `lastSeq` 必须保留——会话复活时从该水位续接，防止重放重复计费。
 */
export interface ArchivedSession {
  calls: number
  tokens: number
  cost: number
  model?: string
  title?: string
  /** 归档时该会话的折叠水位。 */
  lastSeq: number
  archivedAt: number
}

/** The persisted ledger document. */
export interface LedgerFile {
  version: 1 // mutation-ignore: 类型层字面量，运行时中立（由 tsc 把关）
  sessions: Record<string, SessionUsage>
  daily: Record<string, DailyUsage>
  total: { calls: number; tokens: number; cost: number }
  /**
   * 模型维度聚合（0.2.0 新增的可选字段）。旧文件缺省时加载为空表，
   * 从后续调用开始累计——保持 version:1 文件的双向兼容。
   */
  models?: Record<string, UsageCounters>
  /** 超过保留期未活动的会话归档桶（0.3.0 新增，可选，v1 兼容）。 */
  archived?: Record<string, ArchivedSession>
}

/** Budget evaluation for one scope. */
export interface BudgetState {
  /** Accumulated cost in scope. */
  cost: number
  /** Configured budget; 0 means no budget. */
  budget: number
  /** cost / budget when a budget is set; otherwise 0. */
  ratio: number
  /** Ratio reached the configured warning threshold. */
  warn: boolean
  /** Cost reached or exceeded the budget. */
  exceeded: boolean
}

/** Complete budget snapshot used by the prompt, tool, and gate. */
export interface BudgetStatus {
  /** Beijing calendar date of the observation. */
  day: string
  daily: BudgetState
  total: BudgetState
  session?: BudgetState
}

/**
 * Sum the disjoint provider usage buckets.
 * `reasoningTokens` 是 output 的子集，显式接纳但刻意不参与求和（防双计）。
 */
export function usageTotalTokens(usage: {
  inputTokens: number
  outputTokens: number
  cacheReadTokens?: number
  cacheWriteTokens?: number
  reasoningTokens?: number
}): number {
  return usage.inputTokens + (usage.cacheReadTokens ?? 0) + (usage.cacheWriteTokens ?? 0) + usage.outputTokens
}

/** Beijing (UTC+8) calendar date string for one Unix-ms instant. */
export function beijingDate(ms: number): string {
  return new Date(ms + 8 * 3600_000).toISOString().slice(0, 10)
}
