/**
 * dsh-usage-ledger: per-session token usage and cost aggregation with dynamic
 * DeepSeek official pricing (peak/off-peak aware) and budget control.
 *
 * Host half:
 * - folds `session/event` logs into a durable ledger (per session, per Beijing
 *   day, and lifetime totals), pricing each call with the official DeepSeek
 *   price sheet refreshed from https://api-docs.deepseek.com;
 * - enforces daily/total/per-session budgets through an `llm/stream` gate;
 * - exposes a `usage_report` tool and an HTTP dashboard (`/usage-ledger`);
 * - warns the model through a dynamic system-prompt section.
 */
import type { Context } from '@deepseek-ai/cordis'
import z from '@deepseek-ai/schemastery'
import { defineTool } from '@deepseek-ai/dsh-tools'
import { settingsNamespace } from '@deepseek-ai/dsh-settings'
import type { Session, SessionEvent } from '@deepseek-ai/dsh-session'
import type { StreamChunk, TokenUsage } from '@deepseek-ai/dsh-llm'
// Type-only imports: pull the Context/Events declaration merges.
import type {} from '@deepseek-ai/dsh-host-webserver'
import type {} from '@deepseek-ai/dsh-system-prompt'
import type { IncomingMessage, ServerResponse } from 'node:http'
import { costOf, OFFICIAL_PRICING_URL, PriceService } from './pricing.js'
import { formatCny, formatPrice, formatTokens, ledgerCsv, resolveLedgerPath, UsageLedger } from './ledger.js'
import type { UsageSample } from './ledger.js'
import { beijingDate } from './types.js'
import { vendorOf } from './catalog.js'
import { buildInsights, dailyProjection, monthlyProjection, WEEKDAY_LABELS } from './insights.js'
import type { InsightSet } from './insights.js'
import { describeAudit } from './audit.js'
import { renderPrometheusMetrics } from './metrics.js'
import { DASHBOARD_HTML } from './dashboard.js'

export const name = 'dsh-usage-ledger'
export const inject = ['sessions', 'tools', 'systemPrompt', 'settings']

/** Deployment-varying choices; every field is cordis.yml-configurable. */
export interface Config {
  /** Ledger file path; empty means `$DSH_HOME/usage-ledger.json` (or `~/.dsh`). */
  ledgerPath: string
  /** Debounce window for ledger persistence, in milliseconds. */
  saveIntervalMs: number
  /** Wall-clock budget for one pricing-page fetch, in milliseconds. */
  pricingTimeoutMs: number
}

/** Schemastery validator for {@link Config}. */
export const Config: z<Config> = z.object({
  ledgerPath: z.string().default(''),
  saveIntervalMs: z.number().default(5000),
  pricingTimeoutMs: z.number().default(10000),
})

/** User settings of the `usage-ledger` namespace. */
export interface UsageLedgerSettings {
  /** Daily cost budget (CNY); 0 disables. */
  dailyBudget: number
  /** Lifetime cost budget (CNY); 0 disables. */
  totalBudget: number
  /** Per-session cost budget (CNY); 0 disables. */
  sessionBudget: number
  /** Ratio (0-1) at which budgets enter the warning state. */
  warnRatio: number
  /** Block model calls once any budget is exceeded. */
  enforceBudget: boolean
  /** Official pricing page to refresh from. */
  pricingUrl: string
  /** Pricing refresh interval in minutes. */
  refreshIntervalMin: number
  /**
   * User price overrides/entries, keyed by model id (longest-prefix match).
   * Example: `{ "glm-4.6": { "inputCacheHit": 1, "inputMiss": 5, "output": 5 } }`.
   * Prices are CNY per 1M tokens and take priority over built-in/live values.
   */
  customPrices: Record<string, { inputCacheHit: number; inputMiss: number; output: number }>
  /** 超过 N 天未活动的会话压入归档桶（明细丢弃、汇总与水位保留）；0 = 永久保留。 */
  retentionDays: number
  /** 启动对账发现明细与总计漂移时，自动以明细账为准重建总计（推荐开启）。 */
  autoRebalance: boolean
}

/** Schemastery schema of the `usage-ledger` namespace section. */
export const UsageLedgerSchema: z<UsageLedgerSettings> = z.object({
  dailyBudget: z.number().default(0),
  totalBudget: z.number().default(0),
  sessionBudget: z.number().default(0),
  warnRatio: z.number().default(0.8),
  enforceBudget: z.boolean().default(true),
  pricingUrl: z.string().default(OFFICIAL_PRICING_URL),
  refreshIntervalMin: z.number().default(60),
  retentionDays: z.number().default(0),
  autoRebalance: z.boolean().default(true),
  customPrices: z.dict(z.object({
    inputCacheHit: z.number().default(0),
    inputMiss: z.number().required(),
    output: z.number().required(),
  })).default({}),
})

export const USAGE_LEDGER_NAMESPACE = settingsNamespace('usage-ledger')

/** Per-session model route tracked from `request/header` events. */
interface SessionRoute {
  provider?: string
  model?: string
}

/**
 * Mount the plugin: ledger, pricing service, session fold, budget gate,
 * report tool, dashboard route, and prompt warning.
 * @param ctx - the plugin context.
 * @param config - schemastery-resolved {@link Config}.
 */
export function apply(ctx: Context, config: Config): void {
  const scope = ctx.settings.register(USAGE_LEDGER_NAMESPACE, UsageLedgerSchema, { applies: 'live' })
  let settings = scope.get()

  const ledger = new UsageLedger(
    resolveLedgerPath(config.ledgerPath),
    settings,
    ctx.logger,
    config.saveIntervalMs,
  )
  const prices = new PriceService(settings.pricingUrl, config.pricingTimeoutMs, ctx.logger)
  prices.setOverrides(settings.customPrices)

  // Per-session model route and pending step usage (chunk-reported usage is
  // replaced by the assembled assistant message's usage for the same step).
  // 两个 Map 均有界（FIFO 驱逐）：会话结束后条目不再增长，长期宿主进程不再泄漏。
  const ROUTE_MAP_CAP = 2048
  const routes = new Map<string, SessionRoute>()
  const pendingStepUsage = new Map<string, Map<string, UsageSample>>()

  /** FIFO 驱逐最旧插入的键（Map 迭代序 = 插入序），把 map 压回容量上限内。 */
  const evictOldest = <K, V>(map: Map<K, V>, cap: number): void => {
    while (map.size > cap) {
      const oldest = map.keys().next().value as K | undefined
      if (oldest === undefined) break
      map.delete(oldest)
    }
  }

  const stepKey = (turn: number, step: number): string => `${turn}/${step}`

  /**
   * 洞察快照缓存：{账本 rev, 价格代次, 短 TTL} 三重键。
   * 仪表盘 30 秒轮询 / 连续工具调用 / 报表渲染在读多写少场景下命中 O(1)，
   * 任何一次记账或价格变更立刻精确失效，投影随 TTL 有界地老化（≤5 秒）。
   */
  let insightCache: { ledgerRev: number; priceRev: number; builtAt: number; value: InsightSet } | undefined
  const INSIGHT_TTL_MS = 5_000

  /**
   * 组装一次成本洞察快照（缓存命中 / 效率 / 燃烧投影 / 异常检测 / 跨模型比价）。
   * 全部由已记账数据推导，零额外网络开销。
   */
  const insightsSnapshot = (now: number): InsightSet => {
    if (
      insightCache !== undefined
      && insightCache.ledgerRev === ledger.rev
      && insightCache.priceRev === prices.rev
      && now - insightCache.builtAt < INSIGHT_TTL_MS
    ) {
      return insightCache.value
    }
    const rows = ledger.sessions().map(([id, row]) => ({ id, ...row }))
    const usedModels = new Set(ledger.models().map(([model]) => model))
    for (const row of rows) {
      if (row.model !== undefined) usedModels.add(row.model)
    }
    const value = buildInsights(
      now,
      rows,
      ledger.total().cost,
      ledger.daily(beijingDate(now)).cost,
      settings.dailyBudget,
      usedModels,
      ledger.recentSamples(),
      vendorOf,
      model => prices.resolve(model, now),
      ledger.dailyWindow(beijingDate(now), 30),
      settings.totalBudget,
      ledger.models().map(([model, counters]) => ({ key: model, cost: counters.cost })),
    )
    insightCache = { ledgerRev: ledger.rev, priceRev: prices.rev, builtAt: now, value }
    return value
  }

  /**
   * 月度成本投影：最近 14 个日桶（补零）做最小二乘趋势外推到月底。
   * 与洞察快照同缓存键——日桶随记账变更，rev 失效天然正确。
   */
  let insightCacheMonthly: { ledgerRev: number; day: string; value: ReturnType<typeof monthlyProjection> } | undefined
  const monthlySnapshot = (now: number) => {
    if (
      insightCacheMonthly !== undefined
      && insightCacheMonthly.ledgerRev === ledger.rev
      && insightCacheMonthly.day === beijingDate(now)
    ) {
      return insightCacheMonthly.value
    }
    const value = monthlyProjection(now, ledger.dailyWindow(beijingDate(now), 14))
    insightCacheMonthly = { ledgerRev: ledger.rev, day: beijingDate(now), value }
    return value
  }

  // ---- SSE 实时推送：记账即通知，去抖合并短时间内的连续记账 ----
  const sseClients = new Set<ServerResponse>()
  let sseTimer: NodeJS.Timeout | undefined
  let sseLastRev = -1

  /** 记账后调用：500ms 去抖窗口内合并，随后向全部 SSE 订阅者推送增量事件。 */
  const notifyLedgerChange = (): void => {
    if (sseTimer !== undefined) return
    sseTimer = setTimeout(() => {
      sseTimer = undefined
      if (ledger.rev === sseLastRev || sseClients.size === 0) return
      sseLastRev = ledger.rev
      const payload = JSON.stringify({
        rev: ledger.rev,
        total: ledger.total(),
        sessions: ledger.sessions().length,
      })
      for (const client of sseClients) {
        try {
          client.write(`event: ledger\ndata: ${payload}\n\n`)
        }
        catch {
          // 写失败的连接交给 req close 清理；这里只跳过。
          sseClients.delete(client)
        }
      }
    }, 500)
    sseTimer.unref?.()
  }

  /** Price and record one usage sample for a session. */
  const recordUsage = (sessionId: string, time: number, usage: TokenUsage, turn: number, step: number): void => {
    const route = routes.get(sessionId)
    const model = route?.model
    const price = model === undefined ? undefined : prices.resolve(model, time)
    ledger.record(sessionId, {
      time,
      usage,
      model,
      provider: route?.provider,
      cost: costOf(price, usage),
    })
    pendingStepUsage.get(sessionId)?.delete(stepKey(turn, step))
    syncPromptSection()
    notifyLedgerChange()
  }

  /** Fold one session log from the ledger watermark to its current tail. */
  const foldSession = (session: Session): void => {
    const sessionId = String(session.id)
    const events = session.events
    let seq = ledger.lastSeq(sessionId) + 1
    if (seq >= events.length) return
    while (seq < events.length) {
      const event = events[seq] as SessionEvent | undefined
      if (event === undefined) break
      foldEvent(sessionId, event)
      seq += 1
    }
    ledger.advanceSeq(sessionId, events.length - 1)
  }

  /** Fold one event into routes, pending usage, titles, and the ledger. */
  const foldEvent = (sessionId: string, event: SessionEvent): void => {
    const type = event.type as string
    const data = event.data as Record<string, unknown>
    switch (type) {
      case 'request/header': {
        const headerConfig = (data.header as { config?: { provider?: string; model?: string } } | undefined)?.config
        if (headerConfig !== undefined) {
          routes.set(sessionId, { provider: headerConfig.provider, model: headerConfig.model })
          evictOldest(routes, ROUTE_MAP_CAP)
        }
        break
      }
      case 'assistant/chunk': {
        const chunk = data.chunk as StreamChunk | undefined
        const turn = data.turn as number | undefined
        const step = data.step as number | undefined
        if (chunk?.type === 'usage' && turn !== undefined && step !== undefined) {
          let pending = pendingStepUsage.get(sessionId)
          if (pending === undefined) {
            pending = new Map()
            pendingStepUsage.set(sessionId, pending)
            evictOldest(pendingStepUsage, ROUTE_MAP_CAP)
          }
          const route = routes.get(sessionId)
          const model = route?.model
          const price = model === undefined ? undefined : prices.resolve(model, event.time)
          pending.set(stepKey(turn, step), {
            time: event.time,
            usage: chunk.usage,
            model,
            provider: route?.provider,
            cost: costOf(price, chunk.usage),
          })
        }
        break
      }
      case 'assistant/message': {
        const turn = data.turn as number | undefined
        const step = data.step as number | undefined
        const usage = data.usage as TokenUsage | undefined
        if (turn === undefined || step === undefined) break
        if (usage !== undefined) {
          recordUsage(sessionId, event.time, usage, turn, step)
        }
        break
      }
      case 'step/end': {
        // A step that reported usage by chunk but never assembled a message
        // (failed/cancelled call) still consumed tokens: count it now.
        const turn = data.turn as number | undefined
        const step = data.step as number | undefined
        if (turn === undefined || step === undefined) break
        const sample = pendingStepUsage.get(sessionId)?.get(stepKey(turn, step))
        if (sample !== undefined) {
          ledger.record(sessionId, sample)
          pendingStepUsage.get(sessionId)?.delete(stepKey(turn, step))
          syncPromptSection()
          notifyLedgerChange()
        }
        break
      }
      case 'session/title': {
        const title = data.title
        if (typeof title === 'string' && title !== '') {
          ledger.setTitle(sessionId, title, event.time)
        }
        break
      }
      default:
        break
    }
  }

  // ---- budget warning prompt section (dynamic toggle) ----
  let sectionDisposer: (() => void) | undefined
  let sectionText: string | undefined

  const budgetSectionText = (): string | undefined => {
    if (!ledger.hasBudget) return undefined
    const now = Date.now()
    const status = ledger.budgetStatus(now)
    const parts: string[] = []
    if (status.daily.exceeded) parts.push(`今日费用 ${formatCny(status.daily.cost)} 已超出预算 ${formatCny(status.daily.budget)}`)
    else if (status.daily.warn) parts.push(`今日费用 ${formatCny(status.daily.cost)} 已达预算 ${formatCny(status.daily.budget)} 的 ${(status.daily.ratio * 100).toFixed(0)}%`)
    if (status.total.exceeded) parts.push(`累计费用 ${formatCny(status.total.cost)} 已超出总预算 ${formatCny(status.total.budget)}`)
    else if (status.total.warn) parts.push(`累计费用 ${formatCny(status.total.cost)} 已达总预算 ${formatCny(status.total.budget)} 的 ${(status.total.ratio * 100).toFixed(0)}%`)
    // 预算减速带：尚未触及警告线，但按当前燃烧速率投影今日将超支——
    // 提前注入引导，而非等超支后由 gate 硬拦截。事前引导 > 事后刹车。
    if (
      parts.length === 0 && settings.dailyBudget > 0
      && !status.daily.exceeded && !status.daily.warn
    ) {
      const projection = dailyProjection(now, status.daily.cost, settings.dailyBudget)
      if (projection.projectedExceed && projection.exceedAt !== undefined) {
        parts.push(`当前燃烧速率 ${formatCny(projection.pacePerHour)}/小时，预计今日将花费 ${formatCny(projection.projectedEodCost)}、超出日预算 ${formatCny(settings.dailyBudget)}（预计超支时刻 ${new Date(projection.exceedAt + 8 * 3_600_000).toISOString().slice(11, 16)} 北京时间）`)
      }
    }
    if (parts.length === 0) return undefined
    return [
      '[usage-ledger 成本警告]',
      parts.join('；') + '。',
      '请严格控制成本：减少不必要的模型调用与工具调用，回复保持简洁，避免重复读取大文件；非必要不要展开长任务。',
    ].join('\n')
  }

  const syncPromptSection = (): void => {
    const next = budgetSectionText()
    if (next === sectionText) return
    sectionDisposer?.()
    sectionDisposer = undefined
    sectionText = next
    if (next !== undefined) {
      sectionDisposer = ctx.systemPrompt.section({ name: 'usage-ledger:budget-warning', order: 150, text: next })
    }
  }

  // ---- budget gate on the llm/stream waterfall ----
  ctx.on('llm/stream', (options: { sessionId?: unknown }, next: () => AsyncIterable<StreamChunk>) => {
    if (!settings.enforceBudget || !ledger.isExceeded(Date.now(), options.sessionId === undefined ? undefined : String(options.sessionId))) {
      return next()
    }
    const status = ledger.budgetStatus(Date.now())
    const which = status.daily.exceeded
      ? `今日预算已用尽（${formatCny(status.daily.cost)} / ${formatCny(status.daily.budget)}）`
      : status.total.exceeded
        ? `总预算已用尽（${formatCny(status.total.cost)} / ${formatCny(status.total.budget)}）`
        : `会话预算已用尽`
    const message = `usage-ledger: ${which}，已阻止本次模型调用。请调整 usage-ledger 设置中的预算（settings 命名空间 "usage-ledger"）后重试。`
    return (async function* (): AsyncIterable<StreamChunk> {
      yield { type: 'finish', reason: { kind: 'error', failure: { message, code: 'BUDGET_EXCEEDED' } } }
    })()
  })

  // ---- session fold wiring ----
  ctx.on('session/created', (session) => {
    foldSession(session)
  })
  ctx.on('session/event', (session) => {
    foldSession(session)
  })
  // Catch up sessions already live in the store (plugin load or HMR reload).
  for (const session of ctx.sessions.list()) foldSession(session)

  // ---- usage_report tool ----
  const renderReport = (view: string, limit: number, currentSessionId?: string): string => {
    const now = Date.now()
    const day = beijingDate(now)
    const lines: string[] = []
    const sheet = prices.currentSheet

    if (view === 'all' || view === 'budget') {
      const status = ledger.budgetStatus(now, currentSessionId)
      lines.push(`# 用量与成本报告（${day}，北京时间）`)
      lines.push('')
      lines.push('## 预算状态')
      const describe = (label: string, state: { cost: number; budget: number; ratio: number; exceeded: boolean; warn: boolean }): string => {
        if (state.budget <= 0) return `- ${label}: 未设置预算，已花费 ${formatCny(state.cost)}`
        const stateText = state.exceeded ? '⛔ 已超出' : state.warn ? '⚠️ 接近上限' : '✅ 正常'
        return `- ${label}: ${formatCny(state.cost)} / ${formatCny(state.budget)}（${(state.ratio * 100).toFixed(1)}%）${stateText}`
      }
      lines.push(describe('今日', status.daily))
      lines.push(describe('累计', status.total))
      if (status.session !== undefined) lines.push(describe('当前会话', status.session))
      lines.push('')
      lines.push('## 定价（国产主流大模型）')
      lines.push(`- 自动刷新: 每 ${settings.refreshIntervalMin} 分钟抓取各厂商官方定价页，新模型与调价自动导入${prices.lastChangedAt !== undefined ? `（最近一次官方价格变更: ${new Date(prices.lastChangedAt).toISOString()}）` : ''}`)
      for (const vendor of prices.vendorPricing(now)) {
        const note = vendor.tiered ? '（阶梯计价，最低档）' : ''
        const src = vendor.source === 'live' ? '官方实时' : vendor.source === 'override' ? '自定义' : '内置快照'
        lines.push(`### ${vendor.label}${note} [${src}]`)
        for (const [model, price] of Object.entries(vendor.models)) {
          lines.push(`- ${model}: ${formatPrice(price)}`)
        }
      }
      if (sheet.scheduled !== undefined) {
        lines.push(`- DeepSeek 峰谷定价自 ${sheet.scheduled.effective} 生效（北京时间高峰时段按 peak 价计费）`)
      }
      const today = ledger.daily(day)
      const total = ledger.total()
      lines.push('')
      lines.push('## 汇总')
      lines.push(`- 今日: ${today.calls} 次调用, ${formatTokens(today.tokens)} tokens, ${formatCny(today.cost)}`)
      lines.push(`- 累计: ${total.calls} 次调用, ${formatTokens(total.tokens)} tokens, ${formatCny(total.cost)}`)

      // 成本洞察：缓存命中分析、效率指标、燃烧速率投影、月度投影、下次调用预报、异常调用、跨模型比价。
      const insights = insightsSnapshot(now)
      lines.push('')
      lines.push('## 成本洞察')
      if (insights.cache.calls > 0) {
        const totalInput = insights.cache.cacheReadTokens + insights.cache.inputTokens
        lines.push(`- 前缀缓存命中率: ${(insights.cache.hitRate * 100).toFixed(1)}%（缓存读 ${formatTokens(insights.cache.cacheReadTokens)} / 总输入 ${formatTokens(totalInput)} tokens）`)
      }
      if (insights.efficiency.cacheSavingsCny > 0) {
        lines.push(`- 前缀缓存已节省: ${formatCny(insights.efficiency.cacheSavingsCny)}（较全部按未命中价）`)
      }
      if (insights.projection.pacePerHour > 0) {
        lines.push(`- 今日燃烧速率: ${formatCny(insights.projection.pacePerHour)}/小时，按此预计全天 ${formatCny(insights.projection.projectedEodCost)}`)
      }
      // 0.6.0 月度投影：日节奏之上的月规划，决定充值档位。
      const monthly = monthlySnapshot(now)
      if (monthly.daysObserved > 0 && monthly.monthToDateCost > 0) {
        const trend = monthly.slopePerDay > 0 ? `，趋势 ${formatCny(monthly.slopePerDay)}/天` : ''
        lines.push(`- 本月至今 ${formatCny(monthly.monthToDateCost)}${trend}，外推月末约 ${formatCny(monthly.projectedMonthEndCost)}（剩 ${monthly.daysRemaining} 天）`)
      }
      // 0.5.0 下次调用预报：让模型在花钱之前感知成本。
      if (insights.forecast !== undefined) {
        lines.push(`- 下次调用预报: 当前会话输入约 ${formatTokens(insights.forecast.nextInputTokens)} tokens，仅输入侧约 ${formatCny(insights.forecast.nextInputCost)}`)
      }
      if (insights.offPeak.samples > 0) {
        lines.push(`- 峰时费用占比: ${(insights.offPeak.peakCostShare * 100).toFixed(0)}%（近 ${insights.offPeak.samples} 次 DeepSeek 调用）`)
      }
      // 0.7.0 成本健康分：一个数字看懂账本健康度（五维等权启发式）。
      if (insights.health.components.length > 0) {
        const gradeLabel: Record<string, string> = { excellent: '优', good: '良', fair: '中', poor: '差' }
        const parts = insights.health.components.map(c => `${c.label} ${Math.round((c.ratio ?? 0) * 100)}%`).join('、')
        lines.push(`- 成本健康分: ${insights.health.score}/100（${gradeLabel[insights.health.grade] ?? '-'}）——${parts}`)
      }
      // 0.8.0 PVM 成本归因：把「为什么变贵」拆成四个精确可加的效应（无残差）。
      if (insights.attribution !== undefined) {
        const a = insights.attribution
        const delta = a.currentCost - a.baselineCost
        const signed = (v: number): string => `${v >= 0 ? '+' : '-'}${formatCny(Math.abs(v))}`
        lines.push(`- 成本归因（PVM）: 近期 ${a.currentCalls} 次较之前 ${a.baselineCalls} 次${delta >= 0 ? '多' : '少'}花 ${formatCny(Math.abs(delta))}（${delta >= 0 ? '+' : ''}${(a.changeRatio * 100).toFixed(0)}%）——量 ${signed(a.volumeEffect)}、结构 ${signed(a.mixEffect)}、效率 ${signed(a.efficiencyEffect)}、价格 ${signed(a.priceEffect)}`)
      }
      // 0.8.0 SPC 控制图：日单位成本的统计过程控制（3σ 稳健限）。
      if (insights.spc !== undefined) {
        const s = insights.spc
        const state = s.status === 'above' ? '⛔ 超上限（成本回归）' : s.status === 'below' ? '✅ 破下限（显著改善）' : '✅ 受控'
        lines.push(`- 单位成本控制图: ${s.latestDay} 单次均价 ${formatCny(s.latestUnitCost)}，控制限 [${formatCny(s.lcl)}, ${formatCny(s.ucl)}]（基线 ${formatCny(s.baselineUnitCost)} · 3σ · 近 ${s.daysObserved} 天）${state}`)
      }
      // 0.9.0 预算跑道：创业金融的 burn rate × runway。
      if (insights.runway !== undefined) {
        const r = insights.runway
        if (!Number.isFinite(r.daysLeft)) {
          lines.push(`- 预算跑道: 燃烧率为零，总预算用不完（剩余 ${formatCny(r.remaining)}）`)
        }
        else if (r.daysLeft <= 0) {
          lines.push(`- 预算跑道: 已超支 ${formatCny(-r.remaining)}（活跃日均 ${formatCny(r.dailyBurn)}）`)
        }
        else {
          lines.push(`- 预算跑道: 还剩 ${Math.floor(r.daysLeft)} 天（约 ${r.exhaustedBy ?? '?'} 耗尽 · 剩余 ${formatCny(r.remaining)} ÷ 日均 ${formatCny(r.dailyBurn)}）`)
        }
      }
      // 0.9.0 Pareto/基尼集中度：关键少数。
      if (insights.modelPareto !== undefined) {
        const p = insights.modelPareto
        const top = p.items[0]!
        lines.push(`- 成本集中度: 基尼 ${p.gini.toFixed(2)}，前 ${p.fewCount}/${p.count} 个模型占 80% 成本（最高 ${top.key} 占 ${(top.share * 100).toFixed(0)}%）`)
      }
      // 0.9.0 星期效应：周周期分量。
      if (insights.dayOfWeek !== undefined) {
        const w = insights.dayOfWeek
        if (w.significant) {
          lines.push(`- 星期效应: ${WEEKDAY_LABELS[w.peakWeekday] ?? '?'}均 ${formatCny(w.averages[w.peakWeekday] ?? 0)}，峰谷比 ${w.peakTroughRatio.toFixed(1)}（近 ${w.daysObserved} 天）`)
        }
        else {
          lines.push(`- 星期效应: 无显著周周期（峰谷比 ${w.peakTroughRatio.toFixed(1)} < 1.6，近 ${w.daysObserved} 天）`)
        }
      }
      for (const note of insights.notes) {
        lines.push(`- ${note}`)
      }
      if (insights.cache.calls === 0 && insights.notes.length === 0) {
        lines.push('（暂无足够数据）')
      }
      // 定价过期预警：live 抓取链路失联超过 3 个刷新周期时显式警告。
      if (sheet.source === 'live' && sheet.fetchedAt !== undefined) {
        const staleMs = now - sheet.fetchedAt
        if (staleMs > 3 * Math.max(5, settings.refreshIntervalMin) * 60_000) {
          lines.push(`- ⚠️ 定价数据已 ${Math.floor(staleMs / 3_600_000)} 小时未刷新（抓取链路可能失联），成本估算可能基于过期价格`)
        }
      }
      const archived = ledger.archivedSummary()
      if (archived.sessions > 0) {
        lines.push('')
        lines.push(`## 历史归档（${settings.retentionDays} 天保留期）`)
        lines.push(`- ${archived.sessions} 个会话已归档: ${archived.calls} 次调用, ${formatTokens(archived.tokens)} tokens, ${formatCny(archived.cost)}`)
      }
    }

    if (view === 'all' || view === 'sessions') {
      lines.push('')
      lines.push('## 按对话（会话）消耗')
      const rows = ledger.sessions()
      if (rows.length === 0) {
        lines.push('（暂无记录）')
      }
      else {
        const top = rows.slice(0, Math.max(1, limit))
        lines.push('| 会话 | 模型 | 调用 | 输入tokens | 输出tokens | 缓存读 | 费用 |')
        lines.push('|---|---|---|---|---|---|---|')
        for (const [id, row] of top) {
          const title = row.title !== '' ? row.title : id.slice(0, 12)
          const marker = id === currentSessionId ? '（当前）' : ''
          lines.push(`| ${title}${marker} | ${row.model ?? '-'} | ${row.calls} | ${formatTokens(row.inputTokens)} | ${formatTokens(row.outputTokens)} | ${formatTokens(row.cacheReadTokens)} | ${formatCny(row.cost)} |`)
        }
        if (rows.length > top.length) lines.push(`（另有 ${rows.length - top.length} 个会话未列出）`)
      }
    }

    return lines.join('\n')
  }

  ctx.tools.register(defineTool({
    name: 'usage_report',
    description: 'Report token usage and cost: per-session consumption, daily/total totals, budget status, and the current DeepSeek official pricing. Use when the user asks about token usage, cost, or budget.',
    parameters: {
      view: {
        type: 'string',
        enum: ['all', 'budget', 'sessions'],
        description: 'Report scope: "all" (default) = budget + pricing + totals + per-session table; "budget" = budget/pricing/totals only; "sessions" = per-session table only.',
      },
      limit: {
        type: 'integer',
        description: 'Maximum number of sessions to list (default 15).',
      },
    },
    output: {
      schema: { type: 'string' },
      render: (_args, value) => [{ type: 'text', text: value }],
    },
    async execute(args, exec) {
      const agent = (exec as { agent?: { id?: string } }).agent
      const currentSessionId = agent?.id
      return renderReport(args.view ?? 'all', args.limit ?? 15, currentSessionId)
    },
  }))

  // ---- HTTP dashboard (optional: only when a web server is composed) ----
  ctx.inject(['webServer'], (webCtx) => {
    const jsonResponse = (res: ServerResponse, body: unknown, headers: Record<string, string> = {}): void => {
      const payload = JSON.stringify(body)
      res.writeHead(200, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store', ...headers })
      res.end(payload)
    }

    webCtx.webServer.register({
      kind: 'exact',
      path: '/api/usage-ledger',
      handler: (req: IncomingMessage, res: ServerResponse) => {
        const now = Date.now()
        const day = beijingDate(now)
        // 协商缓存：账本 rev / 价格代次 / 北京日三者未变即数据未变，
        // 30 秒轮询以 304 空响应替代全量 JSON 重传（no-cache 允许协商、禁止落盘）。
        const etag = `W/"l${ledger.rev}-p${prices.rev}-${day}"`
        if (req.headers['if-none-match'] === etag) {
          res.writeHead(304, { etag, 'cache-control': 'private, no-cache' })
          res.end()
          return
        }
        const payload = {
          generatedAt: now,
          day,
          budgets: ledger.budgetStatus(now),
          pricing: {
            source: prices.currentSheet.source,
            sourceUrl: prices.currentSheet.sourceUrl,
            fetchedAt: prices.currentSheet.fetchedAt,
            lastChangedAt: prices.lastChangedAt,
            current: prices.currentSheet.current,
            scheduled: prices.currentSheet.scheduled,
            vendors: prices.vendorPricing(now),
          },
          today: ledger.daily(day),
          total: ledger.total(),
          sessions: ledger.sessions().map(([id, row]) => ({ id, ...row })),
          // 0.2.0 成本智能引擎维度：洞察快照、14 天趋势、模型分布。
          insights: insightsSnapshot(now),
          // 0.6.0 月度成本投影（日桶最小二乘趋势外推）。
          monthly: monthlySnapshot(now),
          history: ledger.dailyWindow(day, 14),
          // 0.8.0 成本日历热力图：近 15 周日桶（GitHub 贡献图式消费节律）。
          heatmap: ledger.dailyWindow(day, 105),
          models: ledger.models().map(([model, row]) => ({ model, ...row })),
          // 0.3.0 归档汇总（retentionDays 压实后的历史会话）。
          archived: ledger.archivedSummary(),
          // 0.4.0 复式对账：四向一致性快照（明细/日桶/模型 vs 总计）。
          audit: ledger.audit(),
        }
        jsonResponse(res, payload, { etag })
      },
    })

    // 全量日桶 + 模型聚合的 CSV 导出（带 BOM，Excel 直接打开）。
    webCtx.webServer.register({
      kind: 'exact',
      path: '/api/usage-ledger.csv',
      handler: (_req: IncomingMessage, res: ServerResponse) => {
        res.writeHead(200, { 'content-type': 'text/csv; charset=utf-8', 'cache-control': 'no-store' })
        res.end(ledgerCsv(ledger.dailyAll(), ledger.models()))
      },
    })

    // Prometheus 文本 exposition：账本接入世界标准可观测体系（Grafana 直接抓取）。
    webCtx.webServer.register({
      kind: 'exact',
      path: '/metrics',
      handler: (_req: IncomingMessage, res: ServerResponse) => {
        const now = Date.now()
        const day = beijingDate(now)
        const insights = insightsSnapshot(now)
        const sheet = prices.currentSheet
        const pricingAgeSeconds = sheet.fetchedAt !== undefined ? Math.max(0, Math.floor((now - sheet.fetchedAt) / 1000)) : 0
        res.writeHead(200, {
          'content-type': 'text/plain; version=0.0.4; charset=utf-8',
          'cache-control': 'no-store',
        })
        res.end(renderPrometheusMetrics({
          ledgerRev: ledger.rev,
          total: ledger.total(),
          today: ledger.daily(day),
          sessionsActive: ledger.sessions().length,
          sessionsArchived: ledger.archivedSummary().sessions,
          dailyBudget: settings.dailyBudget,
          cacheHitRate: insights.cache.hitRate,
          cacheSavingsCny: insights.efficiency.cacheSavingsCny,
          peakCostShare: insights.offPeak.peakCostShare,
          projectedEodCost: insights.projection.projectedEodCost,
          projectedMonthEndCost: monthlySnapshot(now).projectedMonthEndCost,
          pricingFetchedAtSeconds: sheet.fetchedAt !== undefined ? Math.floor(sheet.fetchedAt / 1000) : 0,
          pricingAgeSeconds,
          auditOk: ledger.audit().ok,
          healthScore: insights.health.score,
          lowYieldCount: insights.lowYield.length,
          budgetAutopilotCny: insights.budget?.suggestedDailyBudget ?? 0,
          pvmVolumeEffectCny: insights.attribution?.volumeEffect ?? 0,
          pvmMixEffectCny: insights.attribution?.mixEffect ?? 0,
          pvmEfficiencyEffectCny: insights.attribution?.efficiencyEffect ?? 0,
          pvmPriceEffectCny: insights.attribution?.priceEffect ?? 0,
          unitCostCny: insights.spc?.latestUnitCost ?? 0,
          unitCostUclCny: insights.spc?.ucl ?? 0,
          spcInControl: insights.spc?.status === 'above' ? false : true,
          runwayDaysLeft: insights.runway === undefined ? -1 : Number.isFinite(insights.runway.daysLeft) ? Math.round(insights.runway.daysLeft) : 99,
          costGiniModels: insights.modelPareto?.gini ?? -1,
          paretoTop3ShareModels: insights.modelPareto?.top3Share ?? -1,
          weekdayPeakTroughRatio: Number.isFinite(insights.dayOfWeek?.peakTroughRatio ?? NaN) ? insights.dayOfWeek!.peakTroughRatio : -1,
        }))
      },
    })

    webCtx.webServer.register({
      kind: 'exact',
      path: '/usage-ledger',
      handler: (_req: IncomingMessage, res: ServerResponse) => {
        res.writeHead(200, { 'content-type': 'text/html; charset=utf-8', 'cache-control': 'no-store' })
        res.end(DASHBOARD_HTML)
      },
    })

    // SSE 实时事件流：记账即推（去抖合并），仪表盘从轮询升级为事件驱动。
    // 常规端点即时注册；SSE 连接的清理在插件 dispose 时统一收尾。
    webCtx.webServer.register({
      kind: 'exact',
      path: '/api/usage-ledger/stream',
      handler: (req: IncomingMessage, res: ServerResponse) => {
        res.writeHead(200, {
          'content-type': 'text/event-stream; charset=utf-8',
          'cache-control': 'no-store',
          connection: 'keep-alive',
          'x-accel-buffering': 'no',
        })
        res.write(':ok\n\n')
        const client = res
        sseClients.add(client)
        req.on('close', () => {
          sseClients.delete(client)
        })
      },
    })
    ctx.logger.info('usage-ledger: dashboard at /usage-ledger, JSON API at /api/usage-ledger, live stream at /api/usage-ledger/stream, Prometheus metrics at /metrics')
  })

  // ---- 复式对账：启动自检，漂移可自动修复（明细账是原始事实） ----
  {
    const report = ledger.audit()
    if (report.ok) {
      ctx.logger.info(`usage-ledger: 对账平衡（总计与明细账、日桶一致）`)
    }
    else {
      for (const line of describeAudit(report)) ctx.logger.warn(`usage-ledger: ${line}`)
      if (settings.autoRebalance && ledger.rebalance()) {
        ctx.logger.info(`usage-ledger: 已以明细账为准重建总计；日桶漂移（若存在）无法自动修复，请人工核查`)
      }
    }
  }

  // ---- data lifecycle: compact stale sessions into the archive bucket ----
  const runCompaction = (): void => {
    const moved = ledger.compact(settings.retentionDays, Date.now())
    if (moved > 0) {
      ctx.logger.info(`usage-ledger: 已归档 ${moved} 个超过 ${settings.retentionDays} 天未活动的会话（明细折叠，汇总与水位保留）`)
    }
  }
  runCompaction()
  const compactTimer = setInterval(runCompaction, 24 * 3_600_000)
  compactTimer.unref?.()

  // ---- pricing refresh loop ----
  let refreshTimer: NodeJS.Timeout | undefined
  const startRefreshLoop = (): void => {
    if (refreshTimer !== undefined) clearInterval(refreshTimer)
    const intervalMs = Math.max(5, settings.refreshIntervalMin) * 60_000
    refreshTimer = setInterval(() => {
      // DeepSeek 官方页 + 全部国产厂商官方定价页，新模型自动导入。
      void prices.refreshAll()
    }, intervalMs)
    refreshTimer.unref?.()
  }
  void prices.refreshAll()
  startRefreshLoop()

  // ---- live settings updates ----
  const stopWatch = scope.watch((next) => {
    const prev = settings
    settings = next
    ledger.setBudgets(next)
    syncPromptSection()
    if (next.refreshIntervalMin !== prev.refreshIntervalMin) startRefreshLoop()
    if (next.pricingUrl !== prev.pricingUrl) {
      prices.setUrl(next.pricingUrl)
      void prices.refresh()
    }
    if (next.customPrices !== prev.customPrices) prices.setOverrides(next.customPrices)
    if (next.retentionDays !== prev.retentionDays) runCompaction()
  })

  syncPromptSection()

  ctx.effect(() => {
    return () => {
      stopWatch()
      if (refreshTimer !== undefined) clearInterval(refreshTimer)
      clearInterval(compactTimer)
      sectionDisposer?.()
      if (sseTimer !== undefined) clearTimeout(sseTimer)
      for (const client of sseClients) {
        try {
          client.end()
        }
        catch {
          // 尽力而为：断开失败的连接由服务器自身回收。
        }
      }
      sseClients.clear()
      ledger.dispose()
    }
  }, 'dsh-usage-ledger: lifecycle')
}

