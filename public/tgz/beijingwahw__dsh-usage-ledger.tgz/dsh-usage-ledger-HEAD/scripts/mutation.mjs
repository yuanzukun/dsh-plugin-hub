/**
 * 自研轻量变异测试引擎（mutation testing）。
 *
 * 为什么需要它：覆盖率只证明「代码被执行过」，不证明「断言能发现行为
 * 变化」——一个没有任何断言的测试也能拿 100% 覆盖率。变异测试把这一
 * 点变成可度量指标：对源码注入系统性缺陷（变异体），逐个跑测试——
 * 测试失败 = 变异体被「杀死」（断言有效）；测试全绿 = 变异体「存活」
 * （断言盲区，真缺陷会溜过去）。变异得分 = 杀死数 / 总数。
 *
 * 与既有质量防线的组合：
 *   覆盖率门禁  —— 代码被执行了吗？
 *   变异测试    —— 断言真的能抓 bug 吗？（本脚本）
 *   性质测试    —— 数学定律在任意输入下成立吗？
 *
 * 设计要点：
 *  - 掩码扫描器：注释/字符串/模板字面量文本/正则字面量替换为等长空白
 *    后在掩码码上定位变异点，偏移与原码逐字符对齐，绝不毒化文本
 *    （模板 `${}` 内部是真实代码，保留可变异）。
 *  - 算子取舍（全部产出语法合法的替换，被杀死只能归因于断言）：
 *      · 比较翻转：=== ↔ !==、>= → >、<= → <、< → <=（限表达式上下文，
 *        排除泛型开口 `Identifier<`）；
 *      · 裸 `>` → `>=` 刻意不做：与泛型收口 `T>` 无语法歧义级区分手段，
 *        会制造一杀即死的编译错误型假阳性；边界突变由 `>=` → `>` 覆盖；
 *      · 逻辑翻转：&& → ||、一元 ! 删除（限前缀位置，排除 `!==` 与
 *        非空断言 `x!.`）；
 *      · 算术翻转：二元 + ↔ -、* → /、+= → -=；
 *      · 整数边界 +1：`slice(0,10)`→11、`?? 0`→1、`1e-9`→2e-9，容差
 *        与位数全部暴露给断言；
 *      · 布尔翻转：true ↔ false。
 *  - 自愈安全：原始文件先备份到 .mutation-backup/；被 SIGKILL 打断后，
 *    下次启动自动从备份还原再开跑。
 *  - 行内 `mutation-ignore` 标记可豁免等价变异体（行为不变者）。
 *
 * 用法：node scripts/mutation.mjs [file ...]   （默认 types.ts + audit.ts）
 */
import { spawnSync } from 'node:child_process'
import { copyFileSync, existsSync, mkdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs'
import { dirname, join, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '..')
const BACKUP_DIR = join(ROOT, '.mutation-backup')
/** 默认变异目标：纯函数核心（无副作用、全量测试可判定）。 */
const DEFAULT_TARGETS = ['src/types.ts', 'src/audit.ts']
/** 变异得分门禁（%）：低于此值退出码 1，只升不降的棘轮。 */
const THRESHOLD = 95
/** 单个变异体的测试时限（ms）：超时视为被杀死（挂起即失败）。 */
const RUN_TIMEOUT_MS = 120_000

/* ------------------------------------------------------------------ */
/* 掩码扫描器：注释/字符串/正则 → 等长空白，模板插值保持代码。        */
/* ------------------------------------------------------------------ */

/** 判定 `/` 是否开启正则字面量：取决于前一个有意义字符。 */
function isRegexStart(ch) {
  if (ch === '') return true
  return '(,=:[!&|?;{+-*%~^<>}'.includes(ch)
}

function maskSource(code) {
  const out = code.split('')
  const blank = i => { if (out[i] !== '\n') out[i] = ' ' }
  let state = 'normal'
  const templateStack = []
  let braceDepth = 0
  let lastMeaningful = ''
  let inClass = false
  let i = 0
  while (i < code.length) {
    const c = code[i]
    const next = code[i + 1] ?? ''
    switch (state) {
      case 'normal': {
        if (c === '/' && next === '/') { state = 'line'; blank(i); blank(i + 1); i += 2; continue }
        if (c === '/' && next === '*') { state = 'block'; blank(i); blank(i + 1); i += 2; continue }
        if (c === "'") { state = 'single'; blank(i); i += 1; continue }
        if (c === '"') { state = 'double'; blank(i); i += 1; continue }
        if (c === '`') { state = 'template'; blank(i); i += 1; continue }
        if (c === '/' && isRegexStart(lastMeaningful)) {
          state = 'regex'; inClass = false; blank(i); i += 1; continue
        }
        if (c === '{') { braceDepth += 1; lastMeaningful = c; i += 1; continue }
        if (c === '}') {
          if (templateStack.length > 0 && braceDepth === templateStack.at(-1).braceDepth) {
            templateStack.pop(); state = 'template'; lastMeaningful = '}'; i += 1; continue
          }
          braceDepth -= 1; lastMeaningful = c; i += 1; continue
        }
        if (!/\s/.test(c)) lastMeaningful = c
        i += 1; continue
      }
      case 'line': {
        if (c === '\n') state = 'normal'
        else blank(i)
        i += 1; continue
      }
      case 'block': {
        if (c === '*' && next === '/') { blank(i); blank(i + 1); state = 'normal'; i += 2; continue }
        blank(i); i += 1; continue
      }
      case 'single': {
        if (c === '\\') { blank(i); blank(i + 1); i += 2; continue }
        blank(i)
        if (c === "'") { state = 'normal'; lastMeaningful = "'" }
        i += 1; continue
      }
      case 'double': {
        if (c === '\\') { blank(i); blank(i + 1); i += 2; continue }
        blank(i)
        if (c === '"') { state = 'normal'; lastMeaningful = '"' }
        i += 1; continue
      }
      case 'template': {
        if (c === '\\') { blank(i); blank(i + 1); i += 2; continue }
        if (c === '`') { blank(i); state = 'normal'; lastMeaningful = '`'; i += 1; continue }
        if (c === '$' && next === '{') {
          blank(i); blank(i + 1)
          templateStack.push({ braceDepth })
          state = 'normal'; lastMeaningful = '{'
          i += 2; continue
        }
        blank(i); i += 1; continue
      }
      case 'regex': {
        if (c === '\\') { blank(i); blank(i + 1); i += 2; continue }
        if (c === '[') inClass = true
        else if (c === ']') inClass = false
        else if (c === '/' && !inClass) {
          blank(i)
          let j = i + 1
          while (j < code.length && /[a-z]/.test(code[j])) { blank(j); j += 1 }
          state = 'normal'; lastMeaningful = 'x' // 正则结束后紧跟的 `/` 是除法
          i = j; continue
        }
        blank(i); i += 1; continue
      }
    }
  }
  return out.join('')
}

/* ------------------------------------------------------------------ */
/* 变异算子：在掩码码上定位，全部产出语法合法的替换。                 */
/* ------------------------------------------------------------------ */

const isWord = c => /[A-Za-z0-9_$]/.test(c)
/** idx 前最近的有意义字符（跳过空白）。 */
function prevMeaningful(masked, idx) {
  for (let j = idx - 1; j >= 0; j -= 1) {
    if (!/\s/.test(masked[j])) return masked[j]
  }
  return ''
}
/** 二元运算符上下文：左侧是表达式结尾（标识符/`)`/`]`/数字）。 */
const isBinaryCtx = (masked, idx) => {
  const p = prevMeaningful(masked, idx)
  return isWord(p) || p === ')' || p === ']'
}

/**
 * 每个算子：regex 在掩码码上全局扫描，对每个命中做上下文裁决。
 * 返回 { start, end, replacement, label }。
 */
const OPERATORS = [
  { name: '===→!==', regex: /(?<![=!<>])(===)(?!=)/g, replace: () => '!==' },
  { name: '!==→===', regex: /(?<![=!<>])(!==)(?!=)/g, replace: () => '===' },
  { name: '>=→>', regex: /(?<![<>!=])>=(?!=)/g, replace: () => '>' },
  { name: '<=→<', regex: /(?<![<>!=])<=(?!=)/g, replace: () => '<' },
  {
    // `<` → `<=`：泛型开口总是 `Identifier<`（词字符紧邻），
    // 因此仅放行 `)`/`]`/数字 开头的比较上下文。
    name: '<→<=', regex: /(?<![<=!>-])<(?![<=])/g, replace: () => '<=',
    allow: (masked, start) => {
      const p = prevMeaningful(masked, start)
      return p === ')' || p === ']' || /\d/.test(p)
    },
  },
  {
    // 二元 `-` → `+`：排除 `--`、一元负号与科学计数法 `1e-9`。
    name: '-→+', regex: /(?<![+\-*/%])-/g, replace: () => '+',
    allow: (masked, start, end) =>
      isBinaryCtx(masked, start)
      && !((masked[start - 1] === 'e' || masked[start - 1] === 'E') && /\d/.test(masked[end] ?? '')),
  },
  {
    // 二元 `+` → `-`：排除 `++`、`+=`、一元正号。
    name: '+→-', regex: /(?<!\+)\+(?![=+])/g, replace: () => '-',
    allow: (masked, start) => isBinaryCtx(masked, start),
  },
  { name: '*→/', regex: /(?<!\*)\*(?!\*)/g, replace: () => '/' },
  { name: '+=→-=', regex: /\+=/g, replace: () => '-=' },
  { name: '&&→||', regex: /&&/g, replace: () => '||' },
  {
    // 一元 `!` 删除：仅限前缀位置（前一字符是定界符），
    // 排除 `!==`/`!=`（lookaround）与非空断言 `x!.`（词字符后）。
    name: '!x→x', regex: /(?<![!=])!(?![=.])/g, replace: () => '',
    allow: (masked, start) => {
      const p = prevMeaningful(masked, start)
      return p === '' || '(,=:[!&|?;{}'.includes(p)
    },
  },
  {
    // 整数边界 +1：`slice(0,10)`→11、`?? 0`→1、`1e-9`→2e-9、容差与位数全暴露。
    name: 'int+1', regex: /\b\d[\d_]*\b/g,
    replace: m => String(BigInt(m.replaceAll('_', '')) + 1n),
  },
  {
    name: 'true↔false', regex: /\b(true|false)\b/g,
    replace: m => (m === 'true' ? 'false' : 'true'),
  },
]

/** 生成一个文件的全部变异体（跳过 `mutation-ignore` 标记行）。 */
function generateMutants(file, original) {
  const masked = maskSource(original)
  const lines = original.split('\n')
  const lineStarts = []
  {
    let pos = 0
    for (const line of lines) { lineStarts.push(pos); pos += line.length + 1 }
  }
  const lineOf = offset => {
    let lo = 0, hi = lineStarts.length - 1
    while (lo < hi) {
      const mid = (lo + hi + 1) >> 1
      if (lineStarts[mid] <= offset) lo = mid
      else hi = mid - 1
    }
    return lo
  }
  const mutants = []
  const seen = new Set()
  for (const op of OPERATORS) {
    op.regex.lastIndex = 0
    for (const m of masked.matchAll(op.regex)) {
      const start = m.index
      const end = start + m[0].length
      if (op.allow && !op.allow(masked, start, end)) continue
      const replacement = op.replace(m[0])
      if (replacement === m[0]) continue
      const key = `${start}:${replacement}`
      if (seen.has(key)) continue
      seen.add(key)
      const line = lineOf(start)
      if (lines[line].includes('mutation-ignore')) continue
      mutants.push({ file, start, end, from: m[0], replacement, label: op.name, line: line + 1 })
    }
  }
  return mutants
}

/* ------------------------------------------------------------------ */
/* 运行器：备份 → 逐变异体写盘跑测试 → 还原（finally + 崩溃自愈）。   */
/* ------------------------------------------------------------------ */

const backupPath = t => join(BACKUP_DIR, t)
const targetPath = t => join(ROOT, t)

/** 上次被 SIGKILL 打断的残留备份：先还原再开跑（自愈）。 */
function restoreFromCrash(targets) {
  if (!existsSync(BACKUP_DIR)) return
  for (const t of targets) {
    if (existsSync(backupPath(t))) writeFileSync(targetPath(t), readFileSync(backupPath(t), 'utf8'))
  }
  rmSync(BACKUP_DIR, { recursive: true, force: true })
  console.log('↺ 检测到上次中断的运行：已从备份还原源码后重新开始\n')
}

function runTestSuite() {
  const bin = join(ROOT, 'node_modules', 'vitest', 'vitest.mjs')
  const res = spawnSync(process.execPath, [bin, 'run'], {
    cwd: ROOT,
    encoding: 'utf8',
    timeout: RUN_TIMEOUT_MS,
    env: { ...process.env, FORCE_COLOR: '0' },
  })
  // 挂起（超时被杀）/ 非零退出码 = 变异体被发现。
  return res.error !== undefined || res.status !== 0
}

const main = () => {
  const targets = process.argv.slice(2).length > 0 ? process.argv.slice(2) : DEFAULT_TARGETS
  restoreFromCrash(targets)

  const originals = new Map()
  mkdirSync(BACKUP_DIR, { recursive: true })
  for (const t of targets) {
    const original = readFileSync(targetPath(t), 'utf8')
    originals.set(t, original)
    mkdirSync(dirname(backupPath(t)), { recursive: true })
    copyFileSync(targetPath(t), backupPath(t))
  }

  const all = []
  for (const [t, original] of originals) all.push(...generateMutants(t, original))
  console.log(`◉ 变异测试 · ${targets.join(', ')} → ${all.length} 个变异体\n`)

  const survivors = []
  let killed = 0
  try {
    for (let i = 0; i < all.length; i += 1) {
      const mut = all[i]
      const original = originals.get(mut.file)
      const mutated = original.slice(0, mut.start) + mut.replacement + original.slice(mut.end)
      writeFileSync(targetPath(mut.file), mutated)
      const isKilled = runTestSuite()
      writeFileSync(targetPath(mut.file), original)
      if (isKilled) killed += 1
      else survivors.push(mut)
      const mark = isKilled ? '✓ 杀死' : '✗ 存活'
      process.stdout.write(
        `  [${String(i + 1).padStart(String(all.length).length)}/${all.length}] `
        + `${mut.file}:${mut.line}  ${mut.label.padEnd(12)} ${mark}\n`,
      )
    }
  }
  finally {
    for (const [t, original] of originals) writeFileSync(targetPath(t), original)
    rmSync(BACKUP_DIR, { recursive: true, force: true })
  }

  const score = all.length === 0 ? 100 : (killed / all.length) * 100
  console.log('')
  if (survivors.length > 0) {
    console.log('存活变异体（断言盲区）：')
    for (const s of survivors) {
      console.log(`  ${s.file}:${s.line}  ${s.label}  ${JSON.stringify(s.from)} → ${JSON.stringify(s.replacement)}`)
    }
    console.log('')
  }
  console.log(`变异得分：${killed}/${all.length} = ${score.toFixed(1)}%（门禁 ${THRESHOLD}%）`)
  if (score < THRESHOLD) {
    console.log('✗ 低于门禁：请为存活变异体补充断言，或用 mutation-ignore 豁免等价变异体')
    process.exitCode = 1
  }
  else {
    console.log('✓ 通过门禁')
  }
}

main()
