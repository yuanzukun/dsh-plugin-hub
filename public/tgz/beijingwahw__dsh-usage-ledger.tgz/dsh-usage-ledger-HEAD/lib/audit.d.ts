import type { LedgerFile } from './types.js';
/** 一个聚合口径的求和（calls/tokens/cost）。 */
export interface AuditTotals {
    calls: number;
    tokens: number;
    cost: number;
}
/** 一处漂移：某口径求和减总计（0 = 一致；负 = 总账多记）。 */
export interface AuditDrift extends AuditTotals {
}
/** 一次完整对账报告。 */
export interface AuditReport {
    /** 明细与日桶均与总计一致（模型表口径边界不参与判定，见模块注释）。 */
    ok: boolean;
    /** 总账（持久化的 total 桶）。 */
    total: AuditTotals;
    /** 明细账求和：Σ 活跃会话行 + Σ 归档行。 */
    detail: AuditTotals;
    /** 日桶求和：Σ 全部北京日桶。 */
    daily: AuditTotals;
    /** 模型表求和：Σ 全部模型聚合行（仅报告口径，不参与 ok）。 */
    models: AuditTotals;
    /** 明细账 − 总计：可修复漂移（rebalance 以明细为准覆盖总计）。 */
    detailDrift: AuditDrift;
    /** 日桶 − 总计：不可自动修复（日桶是时间真源），仅报告。 */
    dailyDrift: AuditDrift;
    /** 模型表 − 总计：口径边界（v0.2.0 起才按调用记账），仅报告。 */
    modelDrift: AuditDrift;
}
/**
 * 对一份账本文件做四向对账（纯函数，不修改数据）。
 * cost 用绝对容差 1e-9 吸收浮点累加的表示误差。
 */
export declare function auditFile(file: LedgerFile): AuditReport;
/** 人类可读的对账结论（zh-CN），供日志与报表。 */
export declare function describeAudit(report: AuditReport): string[];
