import type { UsageCounters } from './types.js';
import type { ModelPrice } from './types.js';
/** 前缀缓存命中分析。 */
export interface CacheHitInsight {
    /** 命中率 cacheRead / (cacheRead + uncached input)，0..1。 */
    hitRate: number;
    /** 缓存读 tokens（命中部分）。 */
    cacheReadTokens: number;
    /** 未命中输入 tokens。 */
    inputTokens: number;
    /** 参与统计的调用次数。 */
    calls: number;
}
/** 今日预算燃烧速率投影。 */
export interface DailyProjection {
    /** 北京日已过小时数（自北京时间 0 点起算）。 */
    hoursElapsed: number;
    /** 当前燃烧速率（元/小时）。 */
    pacePerHour: number;
    /** 按当前速度外推的全天费用（元）。 */
    projectedEodCost: number;
    /** 日预算（0 = 未设置）。 */
    dailyBudget: number;
    /** 外推全天费用是否将超出日预算。 */
    projectedExceed: boolean;
    /** 预计超出日预算的时刻（Unix ms，仅当按当前速度今日会超支时有值）。 */
    exceedAt?: number;
}
/** 一次被判定为离群的单次调用。 */
export interface CostAnomaly {
    time: number;
    sessionId: string;
    model?: string;
    cost: number;
    /** (cost - mean) / std。 */
    zScore: number;
}
/** 同等用量在其它模型下的假设成本。 */
export interface AlternativeCost {
    model: string;
    vendor: string;
    /** 实际已花费（全部模型合计）。 */
    currentCost: number;
    /** 假设成本（元）。 */
    alternativeCost: number;
    /** 预计节省比例 0..1（负值表示更贵）。 */
    savingsRatio: number;
}
/** 错峰机会：峰谷电价经济学迁移到 token 经济。 */
export interface OffPeakOpportunity {
    /** 参与统计的 DeepSeek 样本数（其它厂商无峰谷价，不计入）。 */
    samples: number;
    /** 峰时（9-12、14-18 北京时间）调用的费用占比 0..1。 */
    peakCostShare: number;
    /** 峰时调用的次数占比 0..1。 */
    peakCallShare: number;
}
/** 一次完整洞察快照。 */
export interface InsightSet {
    cache: CacheHitInsight;
    projection: DailyProjection;
    anomalies: CostAnomaly[];
    alternatives: AlternativeCost[];
    /** 生成效率指标（缓存节省金额等）。 */
    efficiency: EfficiencyInsight;
    /** 错峰机会（峰时费用占比，仅 DeepSeek 峰谷价模型）。 */
    offPeak: OffPeakOpportunity;
    /** 下次调用成本预报（最近活动会话的输入趋势外推；样本不足时缺省）。 */
    forecast?: NextCallForecast;
    /** 成本健康分（五维等权启发式，详见 healthScore）。 */
    health: HealthScore;
    /** 低产出会话（大量输入、极少输出；提示复查，非判定浪费）。 */
    lowYield: LowYieldSession[];
    /** 预算自动驾驶建议（近 30 天花费分布 P90 外推；观测不足时缺省）。 */
    budget?: BudgetSuggestion;
    /** PVM 成本归因（近期两窗口四效应精确分解；样本不足时缺省）。 */
    attribution?: CostAttribution;
    /** 单位成本 SPC 控制图（日桶级统计过程控制；观测不足时缺省）。 */
    spc?: UnitCostControl;
    /** 模型成本的 Pareto/基尼集中度（实体不足时缺省）。 */
    modelPareto?: ParetoInsight;
    /** 日成本的 Pareto/基尼集中度（实体不足时缺省）。 */
    dayPareto?: ParetoInsight;
    /** 预算跑道（设了总预算且有活跃日才有；否则缺省）。 */
    runway?: RunwayInsight;
    /** 星期效应（周周期性；观测不足时缺省）。 */
    dayOfWeek?: DayOfWeekInsight;
    /** 人类可读建议（zh-CN），按重要性排序。 */
    notes: string[];
}
/** 近期调用样本（内存环形缓冲中的最小记录）。 */
export interface RecentSample {
    time: number;
    sessionId: string;
    model?: string;
    cost: number;
    /** 本次调用输入规模（未命中 + 缓存读 tokens，供上下文趋势预报）。 */
    inputTokens?: number;
    /** 本次调用输出 tokens（PVM 归因的效率效应输入）。 */
    outputTokens?: number;
}
/** 生成效率指标：钱花得值不值。 */
export interface EfficiencyInsight {
    /** 前缀缓存较全部按未命中价已节省的金额（元，按当前价格估算）。 */
    cacheSavingsCny: number;
    /** 输出 tokens 占全部 token 流量的比例（生成占比）。 */
    outputRatio: number;
    /** 思考 tokens 占输出 tokens 的比例（推理密度）。 */
    reasoningRatio: number;
    /** 每元产出多少 tokens（性价比；cost 为 0 时为 0）。 */
    tokensPerCny: number;
    /** 成本四维归因（按行级模型现价重算，口径与 cacheSavingsCny 一致）。 */
    breakdown: CostBreakdown;
}
/** 每一元花在了哪里：按 token 用途归因的成本分解。 */
export interface CostBreakdown {
    /** 输入·未命中：inputTokens 按未命中价。 */
    inputCost: number;
    /** 输出：outputTokens 按输出价。 */
    outputCost: number;
    /** 缓存写：cacheWriteTokens 按未命中价（DeepSeek 口径）。 */
    cacheWriteCost: number;
    /** 输入·缓存命中部分折算成本（节省后实付，仅为参考）。 */
    cacheReadCost: number;
}
/** 会话行形状：UsageCounters 加上可选路由与会话标识信息。 */
type LedgerRow = UsageCounters & {
    model?: string;
    id?: string;
    title?: string;
};
/** 北京时间 HH:mm。 */
export declare function beijingHm(ms: number): string;
/**
 * 前缀缓存命中分析。会话行与总计行都满足 UsageCounters 形状。
 */
export declare function cacheHitInsight(counters: UsageCounters): CacheHitInsight;
/**
 * 按今日已消耗速度外推全天费用与超支时点。
 * 凌晨刚过 0 点时燃烧速率噪声极大，用 0.25 小时下限保护。
 */
export declare function dailyProjection(now: number, dailyCost: number, dailyBudget: number): DailyProjection;
/** 月度成本投影（日桶最小二乘趋势外推）。 */
export interface MonthlyProjection {
    /** 参与趋势拟合的日桶数（缺数据的日期补零，是真实的「无消耗」观测）。 */
    daysObserved: number;
    /** 北京月至今累计费用（元）。 */
    monthToDateCost: number;
    /** 最小二乘拟合的每日费用趋势（元/天；可能为负 = 消耗在回落）。 */
    slopePerDay: number;
    /** 本月剩余天数（含今天之后的整日）。 */
    daysRemaining: number;
    /** 外推的本月总费用（元；趋势为负时按零增长下限保护）。 */
    projectedMonthEndCost: number;
}
/**
 * 月度成本投影：对最近日桶做最小二乘线性回归，外推到月底。
 *
 * 日预算只看今天，月度预算才决定充值档位——这是从「日节奏」到「月规划」
 * 的升维。补零的空日也参与拟合（无消耗是真实观测，不是缺失数据）。
 * 斜率为负（消耗回落）时按下限保护：月末不会低于月至今累计。
 */
export declare function monthlyProjection(now: number, daily: ReadonlyArray<{
    day: string;
    cost: number;
}>): MonthlyProjection;
/**
 * 中位数绝对偏差（MAD）稳健离群检测。
 *
 * 为什么放弃经典 z-score：均值与标准差会被离群值本身污染——一次极端
 * 调用把均值拉高、方差撑大后，其余真异常反而被稀释漏检（masking 效应）。
 * MAD 以中位数为中心，天然抗污染：最多 50% 的样本被破坏仍不受影响。
 *
 * 稳健分（modified z-score，Iglewicz-Hoaglin）：0.6745×(x−median)/MAD，
 * 0.6745 = Φ⁻¹(3/4)，使正态总体下与经典 z-score 同尺度。阈值 3.5 为
 * 稳健统计的标准推荐。样本不足（<8 条）时返回空。
 */
export declare function detectAnomalies(samples: ReadonlyArray<RecentSample>): CostAnomaly[];
/**
 * 跨模型比价：把累计 token 用量放到候选模型价格下重算。
 * 各厂商 tokenizer 不同，结果仅是量级参考——notes 中已注明口径。
 * priceOf 为价格解析回调（注入 PriceService.resolve），便于测试。
 */
export declare function alternativeCosts(usage: {
    inputTokens: number;
    outputTokens: number;
    cacheReadTokens?: number;
    cacheWriteTokens?: number;
}, currentCost: number, usedModels: ReadonlySet<string>, vendorOf: (model: string) => string | undefined, priceOf: (model: string) => ModelPrice | undefined): AlternativeCost[];
/** 汇总多行计数器（会话行求和 / 模型行求和通用）。 */
export declare function sumCounters(rows: Iterable<UsageCounters>): UsageCounters;
/**
 * 生成效率指标。缓存节省金额按行级模型现价估算：
 * Σ cacheReadTokens × (未命中价 − 命中价)，只统计正差价模型。
 */
export declare function efficiencyInsight(rows: ReadonlyArray<LedgerRow>, priceOf: (model: string) => ModelPrice | undefined): EfficiencyInsight;
/** 下一次调用的成本预报（上下文趋势外推）。 */
export interface NextCallForecast {
    /** 参与外推的会话内最近样本数（不足 3 条不预报）。 */
    samples: number;
    /** 外推出的下次调用输入规模（tokens，含缓存读）。 */
    nextInputTokens: number;
    /** 按该会话当前模型现价预估的下一次调用成本（元，仅输入侧）。 */
    nextInputCost: number;
}
/**
 * 下次调用成本预报：对同一会话最近几次的输入规模做线性外推。
 *
 * 上下文只会单调增长（历史消息 + 工具结果持续累积），输入规模的趋势
 * 就是未来成本的先行指标。线性外推斜率为负时按零增长处理（保守）。
 * priceOf 需为该会话模型现价；预报只含输入侧（输出不可预知）。
 */
export declare function forecastNextCall(samples: ReadonlyArray<RecentSample>, sessionId: string, priceOf: (model: string) => ModelPrice | undefined): NextCallForecast | undefined;
/**
 * 错峰机会：统计近期 DeepSeek 调用落在峰时段（北京 9-12、14-18）的费用占比。
 * 峰谷价差客观存在（如 deepseek-v4-pro 输入未命中 9 vs 4.5 元/M），
 * 占比高说明把可推迟的任务挪到谷时段是零改造的降本手段。
 * 样本来自内存环形缓冲（近期调用），非全量历史——口径在 notes 中注明。
 */
export declare function offPeakOpportunity(samples: ReadonlyArray<RecentSample>): OffPeakOpportunity;
/** 成本健康分的单一维度。 */
export interface HealthComponent {
    key: 'cache' | 'pacing' | 'stability' | 'offpeak' | 'yield';
    label: string;
    /** 维度得分 0..1；数据不足时不适用（缺省，不参与综合分）。 */
    ratio?: number;
    /** 维度现状说明（zh-CN）。 */
    note: string;
}
/** 成本健康分：把多维洞察压缩成一个可一眼扫视的数字。 */
export interface HealthScore {
    /** 综合分 0..100（仅由适用维度等权平均；无适用维度时为 0）。 */
    score: number;
    grade: 'excellent' | 'good' | 'fair' | 'poor';
    components: HealthComponent[];
}
/** 低产出会话（大量输入、极少输出——大概率是大文件通读或检索过宽）。 */
export interface LowYieldSession {
    sessionId: string;
    title?: string;
    inputTokens: number;
    outputTokens: number;
    /** 输出 tokens 占该会话全部 token 流量的比例。 */
    outputRatio: number;
    cost: number;
}
/** 预算自动驾驶建议（由历史花费分布学习，而非拍脑袋设数）。 */
export interface BudgetSuggestion {
    /** 建议日预算（元）= 近期日花费 P90 × 1.1。 */
    suggestedDailyBudget: number;
    /** 参与统计的天数（含补零空日）。 */
    daysObserved: number;
    /** 近期日花费的 P90（线性插值，与 Excel PERCENTILE.INC 同口径）。 */
    percentile90: number;
    /** 当前预算是否与建议一致（±20% 内）。 */
    aligned: boolean;
}
/**
 * 成本健康分：五个维度等权综合的启发式指标（像信用分之于信用记录）。
 *
 * 诚实设计：数据不足的维度弃权（不奖励也不惩罚）——新账本、无预算、
 * 无 DeepSeek 峰谷样本时各自退出，综合分仅由适用维度平均得出。
 * 维度各自只测一件事：缓存维度已奖励缓存命中，产出维度只看
 * 输出/(输入+输出)（缓存读不进分母），避免重复计分。
 */
export declare function healthScore(args: {
    cache: CacheHitInsight;
    projection: DailyProjection;
    dailyBudget: number;
    anomalyCount: number;
    recentCount: number;
    offPeak: OffPeakOpportunity;
    usageTotals: UsageCounters;
}): HealthScore;
/**
 * 低产出会话检测：输入 ≥ 200k tokens 且输出占全部流量 < 2% 的会话。
 * 读 50 万 tokens 只产出 1 千——钱花在「看」上而非「产出」上，典型于
 * 大文件通读、检索过宽、失败重试。注意：摘要/审计类任务天然低产出，
 * 命中仅提示复查，不是判定浪费。
 */
export declare function lowYieldSessions(rows: ReadonlyArray<LedgerRow>): LowYieldSession[];
/**
 * 预算自动驾驶：从近 30 天日花费分布的 P90 学习日预算。
 *
 * 手动设预算要么拍脑袋、要么抄别人——P90 说的「覆盖你九成历史日」
 * 才是自己的数：偶发尖峰日不误报，常态超支日也拦得住。建议值再留
 * 10% 余量。需要 ≥7 天观测（含补零空日——不花钱也是真实观测）。
 */
export declare function budgetAutopilot(dailyHistory: ReadonlyArray<{
    day: string;
    cost: number;
}>, currentBudget: number): BudgetSuggestion | undefined;
/** PVM 成本归因：把两窗口成本差精确分解为四个可加效应（无残差项）。 */
export interface CostAttribution {
    /** 基线窗口花费（元，较早的一半）。 */
    baselineCost: number;
    /** 对比窗口花费（元，较近的一半）。 */
    currentCost: number;
    /** 量效应：调用次数等比增减的纯量贡献（元；正 = 增支）。 */
    volumeEffect: number;
    /** 结构效应：模型份额漂移（换模型/新模型）的贡献（元）。 */
    mixEffect: number;
    /** 效率效应：单次调用 token 规模变化的贡献（元）。 */
    efficiencyEffect: number;
    /** 价格效应：单位 token 价格变化的贡献（元；调价或峰谷结构变化）。 */
    priceEffect: number;
    /** 基线窗口调用次数。 */
    baselineCalls: number;
    /** 对比窗口调用次数。 */
    currentCalls: number;
    /** 基线窗口首样本时刻（Unix ms）。 */
    baselineStart: number;
    /** 对比窗口首样本时刻（Unix ms）。 */
    currentStart: number;
    /** 成本变动比例（基线为 0 时为 0）。 */
    changeRatio: number;
}
/**
 * PVM 成本归因：零售与财务分析的黄金标准（Price-Volume-Mix）移植到 token 经济。
 *
 * 「这周为什么比上周多花 37 元」不再是一笔糊涂账——精确拆成四个可加
 * 效应，恒等式严格成立：volume + mix + efficiency + price = ΔCost，无残差：
 *  - 量效应   (N₁−N₀)·c̄₀                     —— 调用次数等比增减；
 *  - 结构效应 Σ(n_m1−N₁·s_m0)·c̄_m0 ＋ 新模型   —— 模型份额漂移（换更贵的模型）；
 *  - 效率效应 Σ n_m1·(t̄_m1−t̄_m0)·p̄_m0        —— 单次调用 token 规模（上下文变长）；
 *  - 价格效应 Σ n_m1·t̄_m1·(p̄_m1−p̄_m0)         —— 单位 token 价格（调价、峰谷结构）。
 *
 * 以环形缓冲的时间中点切两个窗口（各需 ≥8 个样本）。内存态数据、重启即
 * 失效——与逐次异常检测同一口径，不影响账本正确性。比率指标 cost/call
 * 与 cost/token 不受「窗口进行时」影响（比率是无偏的）。
 */
export declare function costAttribution(samples: ReadonlyArray<RecentSample>): CostAttribution | undefined;
/** 单位成本的 SPC 控制图：日桶级统计过程控制。 */
export interface UnitCostControl {
    /** 基线天数（不含被评定的最新观测日）。 */
    daysObserved: number;
    /** 中心线：近期日单位成本的中位数（元/次，抗离群）。 */
    baselineUnitCost: number;
    /** 稳健 σ 估计（1.4826×MAD；MAD 退化时回退平均绝对偏差）。 */
    sigma: number;
    /** 控制上限（元/次，中心线 + 3σ）。 */
    ucl: number;
    /** 控制下限（元/次，中心线 − 3σ，非负截断）。 */
    lcl: number;
    /** 最新观测日的单位成本（元/次）。 */
    latestUnitCost: number;
    /** 最新观测日（北京日期）。 */
    latestDay: string;
    /** 判定：in = 受控 / above = 超上限（成本回归）/ below = 破下限（显著改善）。 */
    status: 'in' | 'above' | 'below';
    /** 基线期内越限天数（过程稳定性参考；持续越限说明过程本身不稳定）。 */
    outOfControlDays: number;
}
/**
 * 单位成本控制图：把制造业的统计过程控制（SPC / Shewhart 控制图）移植
 * 到 token 经济。过程指标 = 日单位成本（cost/call）——比率指标，不受
 * 「今天还没过完」的进行时影响（区别于日累计费用的天然偏小）。
 *
 * 中心线取中位数、σ 取 1.4826×MAD（正态下与经典 σ 同尺度）——与逐次
 * 调用异常检测同一稳健哲学：基线不被离群日污染（一次失控日不会把限
 * 撑宽，从而漏报次日的失控）。最新观测日不参与基线估计：用历史过程
 * 评价新点，这是 SPC 的正确姿势。3σ 判界（Shewhart 经典）。
 * MAD = 0（过半天数完全相同）时回退平均绝对偏差，口径同 detectAnomalies。
 */
export declare function unitCostControl(daily: ReadonlyArray<{
    day: string;
    calls?: number;
    cost: number;
}>): UnitCostControl | undefined;
/** Pareto 集中度分析：经济学百年经典的「关键少数」。 */
export interface ParetoInsight {
    /** 实体总数（零成本实体已剔除）。 */
    count: number;
    /** 基尼系数 0..1（0 = 完全均匀；越接近 1 越集中）。 */
    gini: number;
    /** 前 3 个实体的累计成本占比。 */
    top3Share: number;
    /** 覆盖 80% 成本所需的最少实体数（关键少数）。 */
    fewCount: number;
    /** 按成本降序的实体列表（含单份额与累计份额）。 */
    items: Array<{
        key: string;
        cost: number;
        share: number;
        cumulative: number;
    }>;
}
/**
 * Pareto/基尼集中度分析：把经济学的分配不平等度量（基尼系数，Corrado
 * Gini, 1912）移植到 token 成本分布——「钱都花到哪去了」。
 *
 * 基尼 = Σᵢⱼ|xᵢ−xⱼ| / (2n²μ)。完全均匀 → 0；单一实体独占 → (n−1)/n → 1。
 * 与 80/20 法则（Pareto, 1896）配合：fewCount 指出覆盖 80% 成本的最少
 * 实体数——优化投入应该精准砸向这几个「关键少数」，边际收益最高。
 * 实体数 < 4 时基尼无统计意义，返回 undefined（诚实弃权）。
 */
export declare function paretoOf(entries: ReadonlyArray<{
    key: string;
    cost: number;
}>): ParetoInsight | undefined;
/** 预算跑道（创业金融的生死指标：burn rate × runway）。 */
export interface RunwayInsight {
    /** 总预算（元；0 = 未设置）。 */
    totalBudget: number;
    /** 已花费（元）。 */
    spent: number;
    /** 剩余（元；超支为负）。 */
    remaining: number;
    /** 近期日均燃烧率（元/天，活跃日口径）。 */
    dailyBurn: number;
    /** 剩余可烧天数（Infinity = 燃烧率为零，预算用不完）。 */
    daysLeft: number;
    /** 按当前燃烧率的耗尽日（北京日期；null = 不可算或烧不完）。 */
    exhaustedBy: string | null;
    /** 用于燃烧率的活跃天数。 */
    burnDays: number;
}
/**
 * 预算跑道：把 VC 与创业公司财务的 burn rate / runway 移植到 token 预算
 * ——「按现在这个烧法，钱还能用几天」。这是创业金融里最直白的生死指
 * 标：runway 归零即公司（这里：总预算）死亡。
 *
 * 燃烧率取活跃日均值而非自然日均值：休息日不稀释真实消耗节奏（与
 * 预算自动驾驶同一口径哲学）。仅当设置了总预算时才有意义。
 */
export declare function runwayOf(now: number, totalBudget: number, spent: number, daily: ReadonlyArray<{
    day: string;
    cost: number;
}>): RunwayInsight | undefined;
/** 星期效应：周周期性（时间序列季节分解的周期分量）。 */
export interface DayOfWeekInsight {
    /** 观测天数。 */
    daysObserved: number;
    /** 已覆盖的星期位（0=周一..6=周日）。 */
    weekdaysCovered: number;
    /** 各星期位平均日花费（索引 0..6；缺样本为 NaN）。 */
    averages: number[];
    /** 最贵星期位。 */
    peakWeekday: number;
    /** 最贵与最便宜星期位的花费比。 */
    peakTroughRatio: number;
    /** 周期性是否显著（峰谷比 ≥ 1.6 且每位 ≥ 2 样本）。 */
    significant: boolean;
}
/** 星期位的中文标签（索引 0..6 = 周一..周日）。 */
export declare const WEEKDAY_LABELS: readonly ['周一', '周二', '周三', '周四', '周五', '周六', '周日'];
/**
 * 星期效应：把时间序列分析的季节分解（seasonal decomposition）思想移植
 * 到日成本序列——剥离趋势后剩下的「周周期分量」。回答：周几天然最贵？
 *
 * 每个星期位至少 2 个样本才计入（避免单日噪声冒充规律）；峰谷比 ≥ 1.6
 * 才判定显著。峰谷比 < 1.6 说明消耗节奏无周周期，稳定本身也是信息。
 */
export declare function dayOfWeekEffect(daily: ReadonlyArray<{
    day: string;
    cost: number;
}>): DayOfWeekInsight | undefined;
/**
 * 组装一次完整洞察并生成人类可读建议。
 * @param now 观测时刻。
 * @param rows 会话行（既用于求和，也用于按行级模型估价缓存节省）。
 * @param currentCost 实际累计花费。
 * @param dailyCost 今日已花费。
 * @param dailyBudget 日预算（0 = 未设置）。
 * @param usedModels 已实际使用过的模型 id 集合（比价时排除自身）。
 * @param recentSamples 近期调用样本（内存环形缓冲）。
 * @param vendorOf 价格目录的厂商识别函数。
 * @param priceOf 价格解析回调（通常为 PriceService#resolve 绑定 now）。
 */
export declare function buildInsights(now: number, rows: ReadonlyArray<LedgerRow>, currentCost: number, dailyCost: number, dailyBudget: number, usedModels: ReadonlySet<string>, recentSamples: ReadonlyArray<RecentSample>, vendorOf: (model: string) => string | undefined, priceOf: (model: string) => ModelPrice | undefined, dailyHistory?: ReadonlyArray<{
    day: string;
    calls?: number;
    cost: number;
}>, totalBudget?: number, modelEntries?: ReadonlyArray<{
    key: string;
    cost: number;
}>): InsightSet;
export {};
