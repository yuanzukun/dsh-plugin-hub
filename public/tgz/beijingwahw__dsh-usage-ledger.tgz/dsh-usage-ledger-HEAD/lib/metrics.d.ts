/**
 * Prometheus 文本 exposition 格式导出：把私有账本接入世界标准可观测体系。
 *
 * 一份 /metrics 端点让账本的数据直接进 Prometheus / Grafana / VictoriaMetrics
 * ——无需任何专属采集器，运维世界的通用语言。所有指标均为即时快照
 * （counter 语义的累计值由账本自身保证单调），导出为纯文本、零依赖。
 *
 * 命名规范（Prometheus 最佳实践）：
 *  - 小写下划线，单位做后缀（_cny / _seconds）；
 *  - counter 用 _total 结尾，gauge 不加；
 *  - 每个指标带 HELP（一句话语义）与 TYPE。
 */
/** 指标快照的输入形状（由宿主从账本与洞察装配）。 */
export interface MetricsSnapshot {
    /** 账本数据版本号（任何变更 +1；观察变化事件的天然 gauge）。 */
    ledgerRev: number;
    total: {
        calls: number;
        tokens: number;
        cost: number;
    };
    today: {
        calls: number;
        tokens: number;
        cost: number;
    };
    /** 活跃（未归档）会话数。 */
    sessionsActive: number;
    /** 已归档会话数。 */
    sessionsArchived: number;
    /** 日预算（0 = 未设置）。 */
    dailyBudget: number;
    /** 前缀缓存命中率 0..1。 */
    cacheHitRate: number;
    /** 前缀缓存累计节省金额（元）。 */
    cacheSavingsCny: number;
    /** 峰时费用占比 0..1（仅 DeepSeek 样本）。 */
    peakCostShare: number;
    /** 按当前燃烧速率外推的全天费用（元）。 */
    projectedEodCost: number;
    /** 外推的本月总费用（元）。 */
    projectedMonthEndCost: number;
    /** 定价页最近抓取时刻（Unix 秒；未知为 0）。 */
    pricingFetchedAtSeconds: number;
    /** 定价抓取距今秒数（未知为 0）。 */
    pricingAgeSeconds: number;
    /** 复式对账是否平衡（1 = 平衡）。 */
    auditOk: boolean;
    /** 成本健康分 0..100（无适用维度时为 0）。 */
    healthScore: number;
    /** 低产出会话数（大入小出，最多跟踪 3 个）。 */
    lowYieldCount: number;
    /** 预算自动驾驶建议的日预算（元；0 = 观测不足无建议）。 */
    budgetAutopilotCny: number;
    /** PVM 量效应：调用次数增减的贡献（元；无归因数据为 0）。 */
    pvmVolumeEffectCny: number;
    /** PVM 结构效应：模型份额漂移的贡献（元）。 */
    pvmMixEffectCny: number;
    /** PVM 效率效应：单次调用 token 规模变化的贡献（元）。 */
    pvmEfficiencyEffectCny: number;
    /** PVM 价格效应：单位 token 价格变化的贡献（元）。 */
    pvmPriceEffectCny: number;
    /** 最新观测日单位成本（元/次；无活跃日为 0）。 */
    unitCostCny: number;
    /** 单位成本控制上限（元/次；观测不足为 0）。 */
    unitCostUclCny: number;
    /** 最新观测日是否在控（1 = 在控或观测不足；0 = 失控警报）。 */
    spcInControl: boolean;
    /** 预算跑道剩余天数（-1 = 未设置总预算或观测不足；99 = 燃烧率为零烧不完）。 */
    runwayDaysLeft: number;
    /** 模型成本基尼系数 0..1（-1 = 实体不足无意义）。 */
    costGiniModels: number;
    /** 模型成本前 3 累计占比 0..1（-1 = 无数据）。 */
    paretoTop3ShareModels: number;
    /** 星期效应峰谷比（最贵/最便宜星期几；-1 = 无数据）。 */
    weekdayPeakTroughRatio: number;
}
/**
 * 渲染 Prometheus 文本 exposition 格式（每行以 \n 结尾）。
 * 纯函数：同一快照得到字节级相同的输出，便于测试与缓存。
 */
export declare function renderPrometheusMetrics(snap: MetricsSnapshot): string;
