import type { BudgetStatus, LedgerFile, SessionUsage, UsageCounters } from './types.js';
import type { ModelPrice } from './types.js';
import type { AuditReport } from './audit.js';
/** Minimal logger shape (structurally compatible with the cordis logger). */
export interface LedgerLogger {
    warn(...args: unknown[]): void;
    info(...args: unknown[]): void;
}
/** Budget configuration the ledger evaluates against. */
export interface BudgetConfig {
    /** Daily cost budget (CNY); 0 disables. */
    dailyBudget: number;
    /** Total cost budget (CNY); 0 disables. */
    totalBudget: number;
    /** Per-session cost budget (CNY); 0 disables. */
    sessionBudget: number;
    /** Ratio (0-1) at which a budget enters the warning state. */
    warnRatio: number;
}
/** One recorded model call. */
export interface UsageSample {
    time: number;
    usage: {
        inputTokens: number;
        outputTokens: number;
        cacheReadTokens?: number;
        cacheWriteTokens?: number;
        reasoningTokens?: number;
    };
    model?: string;
    provider?: string;
    cost: number;
}
/**
 * 账本文件净化：「parse, don't validate」反模式的修复。
 *
 * `JSON.parse` 的返回类型是任意 JSON 形状；旧实现只查 version 就盲转
 * （`as Partial<LedgerFile>`），损坏字段会静默毒化总计、健康分与一切
 * 派生指标——NaN 一旦进入就永不消失。净化在结构层设防：
 *  - 数值：有限且非负才采信（JSON 文本 `1e999` 解析为 Infinity、字符串
 *    成本、负 token 一律归零）；
 *  - 容器：数组/原始值位置视为空表，行内字段逐个净化；
 *  - 版本：非 v1 直接抛错，走既有的「隔离损坏文件、全新开始」恢复路径。
 *
 * 净化只承诺结构与数值的合法性；算术一致性交给复式对账——净化清零造
 * 成的明细/总计漂移会被启动审计发现并按明细重算。两道防线正交组合：
 * 校验防「形状损坏」，审计防「数值漂移」。
 */
export declare function sanitizeLedgerFile(raw: unknown): LedgerFile;
/** Resolve the ledger file path: configured path, else `$DSH_HOME`/`~/.dsh`. */
export declare function resolveLedgerPath(configured: string): string;
/**
 * Durable per-session usage ledger. All mutation goes through `record()` and
 * `setTitle()`; persistence is debounced and flushed on `dispose()`.
 */
export declare class UsageLedger {
    readonly path: string;
    private budgets;
    private readonly log;
    private readonly saveIntervalMs;
    private file;
    private dirty;
    private saveTimer;
    private disposed;
    /** 近期调用样本（仅内存，供异常检测、下次调用预报与 PVM 归因；重启即失效，不影响账本正确性）。 */
    private recent;
    private static readonly RECENT_CAP;
    /**
     * 数据版本号：任意一次账本变更（记账/标题/水位/归档）单调 +1。
     * 派生视图（排序/汇总）与外层洞察快照都以 rev 作为缓存失效依据，
     * 轮询与报表读取从 O(n log n) 降为 O(1)；flush 持久化不改变数据、不递增。
     */
    private revision;
    private sessionsView;
    private modelsView;
    private dailyAllView;
    private archivedView;
    /** 当前数据版本号（只读快照用途）。 */
    get rev(): number;
    constructor(path: string, budgets: BudgetConfig, log: LedgerLogger, saveIntervalMs: number);
    /** Replace the budget configuration (live settings update). */
    setBudgets(budgets: BudgetConfig): void;
    /** Load the durable file; a corrupt file is archived aside, never fatal. */
    private load;
    /** The last folded session-log seq, for resume double-count protection. */
    lastSeq(sessionId: string): number;
    /** Session display title, when one was logged. */
    title(sessionId: string): string | undefined;
    /** Remember the session title (latest-wins). */
    setTitle(sessionId: string, title: string, time: number): void;
    /** Record one priced model call into session, daily, total, and model buckets. */
    record(sessionId: string, sample: UsageSample): void;
    /** Advance the folded-seq watermark after events were consumed. */
    advanceSeq(sessionId: string, seq: number): void;
    private sessionRow;
    /** One session's aggregate, when recorded. */
    session(sessionId: string): SessionUsage | undefined;
    /**
     * All session rows, newest activity first.
     * 结果按 rev 缓存：数据未变时（轮询/报表反复读取）零重排。
     * 约定返回值只读——行对象与数组都不得原地修改。
     */
    sessions(): ReadonlyArray<[string, SessionUsage]>;
    /** 模型维度聚合行，按花费降序（0.2.0 洞察数据源；rev 缓存，约定只读）。 */
    models(): ReadonlyArray<[string, UsageCounters]>;
    /** 近期调用样本（内存环形缓冲副本，供异常检测、下次调用预报与 PVM 归因）。 */
    recentSamples(): ReadonlyArray<{
        time: number;
        sessionId: string;
        model?: string;
        cost: number;
        inputTokens?: number;
        outputTokens?: number;
    }>;
    /** 某日之前（含）最近 N 天的日桶序列（趋势图数据源，缺失的日期补零）。 */
    dailyWindow(endDay: string, days: number): Array<{
        day: string;
        calls: number;
        tokens: number;
        cost: number;
    }>;
    /** One day's bucket (Beijing date). */
    daily(day: string): {
        calls: number;
        tokens: number;
        cost: number;
    };
    /**
     * 数据生命周期治理：把超过保留期未活动的会话行压进归档桶。
     * total/daily/models 全不动（历史总量不变），只有 sessions 表瘦身。
     * `lastSeq` 水位随行进归档——会话复活时从归档水位续接，
     * 折叠增量从水位之后开始，绝不重复计费。返回归档行数。
     */
    compact(retentionDays: number, now: number): number;
    /** 归档桶汇总（报表展示用；rev 缓存。不含在 total 里，total 本就含全部历史）。 */
    archivedSummary(): {
        sessions: number;
        calls: number;
        tokens: number;
        cost: number;
    };
    /** 全部日桶，按日期升序（CSV 导出数据源；rev 缓存，约定只读）。 */
    dailyAll(): ReadonlyArray<{
        day: string;
        calls: number;
        tokens: number;
        cost: number;
    }>;
    /** Lifetime totals. */
    total(): {
        calls: number;
        tokens: number;
        cost: number;
    };
    /**
     * 复式对账：明细账 / 日桶 / 模型表 vs 总计（详见 audit.ts 口径说明）。
     * 纯读操作，不修改任何数据；报告对象是即时快照。
     */
    audit(): AuditReport;
    /**
     * 以明细账为准重建总计（明细是记账的原始事实，聚合桶是派生值）。
     * 仅当明细与总计存在漂移时改写 total 并落盘；返回是否发生修复。
     * 日桶与模型表不动——日桶是时间真源，模型表有口径边界（见 audit.ts）。
     */
    rebalance(): boolean;
    private budgetState;
    /** Evaluate daily, total, and (optionally) session budgets. */
    budgetStatus(atMs: number, sessionId?: string): BudgetStatus;
    /** Whether any configured budget is already exceeded. */
    isExceeded(atMs: number, sessionId?: string): boolean;
    /** Whether any configured budget reached the warning threshold. */
    isWarn(atMs: number, sessionId?: string): boolean;
    /** Whether at least one budget is configured. */
    get hasBudget(): boolean;
    /** The resolved price table description for reports. */
    private markDirty;
    /** Write the ledger to disk (atomic rename). */
    flush(): void;
    /**
     * 滚动备份：成功落盘后，距上次备份 ≥1 小时则把当前账本快照为
     * `<path>.bak-<ms>`，只保留最近 BACKUP_KEEP 份（最旧的删除）。
     * 原子写 + 独立快照双保险：损坏/误删时可从备份恢复历史总计。
     */
    private lastBackupAt;
    private static readonly BACKUP_INTERVAL_MS;
    private static readonly BACKUP_KEEP;
    private rotateBackup;
    /** Stop timers and persist the final state. */
    dispose(): void;
}
/** Format one CNY amount with sensible precision. */
export declare function formatCny(value: number): string;
/** Format one token count with thousands separators. */
export declare function formatTokens(value: number): string;
/** Describe one price row for reports. */
export declare function formatPrice(price: ModelPrice): string;
/**
 * 把日桶与模型聚合序列化为 CSV（带 BOM，Excel 可直接打开 UTF-8）。
 * 行格式：kind,key,calls,tokens,cost。
 */
export declare function ledgerCsv(daily: ReadonlyArray<{
    day: string;
    calls: number;
    tokens: number;
    cost: number;
}>, models: ReadonlyArray<readonly [string, UsageCounters]>): string;
