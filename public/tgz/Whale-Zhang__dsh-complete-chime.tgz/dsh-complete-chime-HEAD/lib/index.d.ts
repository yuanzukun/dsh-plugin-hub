import type { Context } from '@deepseek-ai/cordis'

export const name: 'dsh-complete-chime'
export const inject: string[]

export interface Config {
  enabled?: boolean
  sound?: 'chime' | 'ding' | 'bell' | 'custom'
  volume?: number
  customName?: string
}

export const NS: 'dsh-complete-chime'
export function apply(ctx: Context, config?: Config): void
