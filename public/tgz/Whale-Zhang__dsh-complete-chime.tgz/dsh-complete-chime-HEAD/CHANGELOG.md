# Changelog

## 0.1.1

- Host route caps upload size before buffering and sniffs audio magic bytes.
- Custom playback goes through `fetch` + blob so Desktop `file://` still rings.
- Completion detection skips blank/subagent rows, list replays, and double-fires.
- Settings writes are serialized; oversized files are rejected in the browser.

## 0.1.0

- Initial release: completion chime, built-in tones, custom upload, Settings card.
