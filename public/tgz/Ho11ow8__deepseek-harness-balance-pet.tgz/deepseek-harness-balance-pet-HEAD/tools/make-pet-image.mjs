// make-pet-image.mjs — preprocess the pet source image:
//   1. remove the white background by flood-filling from the image borders
//      (interior white regions such as the speech bubble / face stay intact),
//   2. feather the cut edge for anti-aliased borders,
//   3. cover the original speech-bubble text with a white rounded rect so the
//      desktop pet can draw its own live text on top.
//
// Requires the `sharp` package (e.g. from the DSH profile's node_modules):
//   node make-pet-image.mjs <input.jpg> <output.png>
// The default sharp resolution below points at the DSH web profile; override
// with the SHARP_REQUIRE_BASE environment variable if your layout differs.
import { createRequire } from 'module';
import { existsSync } from 'fs';

const requireBase = process.env.SHARP_REQUIRE_BASE
  || 'C:/Users/Ho11ow8/.dsh/profiles/node_modules/sharp/package.json';
const require = createRequire(requireBase);
const sharp = require('sharp');

const SRC = process.argv[2] || '0082b941172803f0ae12889cbcfd907a.jpg';
const OUT = process.argv[3] || 'pet.png';

// Speech-bubble text area in the 960x912 source image (from OCR analysis).
const TEXT = { x: 70, y: 130, w: 475, h: 170, rx: 26 };

// "white" threshold: a pixel is background-white when every channel >= TH.
const TH = 244;

async function main() {
  if (!existsSync(SRC)) throw new Error(`input image not found: ${SRC}`);
  const meta = await sharp(SRC).metadata();
  const W = meta.width, H = meta.height;
  console.log(`source: ${W}x${H} ${meta.format}`);

  const { data, info } = await sharp(SRC).ensureAlpha().raw().toBuffer({ resolveWithObject: true });
  if (info.width !== W || info.height !== H || info.channels !== 4) throw new Error('unexpected raw layout');
  const px = W * H;

  const isWhite = (p) => data[p * 4] >= TH && data[p * 4 + 1] >= TH && data[p * 4 + 2] >= TH;

  // flood fill from the borders through white pixels
  const bg = new Uint8Array(px);
  const stack = [];
  const seed = (p) => { if (!bg[p] && isWhite(p)) { bg[p] = 1; stack.push(p); } };
  for (let x = 0; x < W; x++) { seed(x); seed((H - 1) * W + x); }
  for (let y = 0; y < H; y++) { seed(y * W); seed(y * W + W - 1); }
  while (stack.length) {
    const p = stack.pop();
    const px2 = p % W, py = (p / W) | 0;
    const nb = [[px2 - 1, py], [px2 + 1, py], [px2, py - 1], [px2, py + 1]];
    for (const [nx, ny] of nb) {
      if (nx < 0 || ny < 0 || nx >= W || ny >= H) continue;
      const np = ny * W + nx;
      if (bg[np]) continue;
      if (isWhite(np)) { bg[np] = 1; stack.push(np); }
    }
  }

  // set alpha: background -> 0, feathered fringe near the cut, else opaque
  let removed = 0;
  for (let i = 0; i < px; i++) {
    if (bg[i]) { data[i * 4 + 3] = 0; removed++; continue; }
    const r = data[i * 4], g = data[i * 4 + 1], b = data[i * 4 + 2];
    const minc = Math.min(r, g, b);
    let nearBg = false;
    const cx = i % W, cy = (i / W) | 0;
    for (const [nx, ny] of [[cx - 1, cy], [cx + 1, cy], [cx, cy - 1], [cx, cy + 1]]) {
      if (nx < 0 || ny < 0 || nx >= W || ny >= H) continue;
      if (bg[ny * W + nx]) { nearBg = true; break; }
    }
    if (nearBg && minc >= 230) {
      data[i * 4 + 3] = Math.max(0, Math.min(255, Math.round((255 - minc) * 8)));
    } else {
      data[i * 4 + 3] = 255;
    }
  }
  console.log(`removed ${removed} background pixels (${(100 * removed / px).toFixed(1)}%)`);

  // cover the old bubble text with a white rounded rect
  const svg = Buffer.from(
    `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}">` +
    `<rect x="${TEXT.x}" y="${TEXT.y}" width="${TEXT.w}" height="${TEXT.h}" rx="${TEXT.rx}" fill="#ffffff"/>` +
    `</svg>`
  );
  await sharp(data, { raw: { width: W, height: H, channels: 4 } })
    .composite([{ input: svg, gravity: 'northwest' }])
    .png()
    .toFile(OUT);
  console.log(`wrote ${OUT} (transparent background, bubble text covered)`);
}

main().catch((e) => { console.error('FATAL', e); process.exit(1); });
