# deepseek-balance-pet

一个 [DeepSeek Harness](https://github.com/deepseek-ai/deepseek-harness)（DSH）插件：**打开 DSH Web 界面时，在屏幕右下角挂一个Deepseek娘**，对话框里的文字换成你 DeepSeek 账号的**实时余额**（默认每 20 秒刷新一次）。

## 功能特性

- ✅ 启动 `dsh web` 时自动出现；**只挂在 DeepSeek Harness 界面（浏览器窗口）上**：
  - 切到别的应用 → 桌宠自动藏到后面；
  - 最小化浏览器 → 桌宠隐藏；恢复 → 显示；关闭浏览器窗口 → 隐藏；
  - 跟随浏览器所在显示器，出现在其右下角（14px 边距）
- ✅ 默认大小 220×209px（约原图 1/4，可配置）
- ✅ 对话框内显示 **"余额：¥xx.xx"**（单行、自动缩放字号防溢出），实时刷新 DeepSeek 账号余额（`GET /user/balance`）
- ✅ 零运行时依赖：插件仅用 Node 内置模块，桌宠是编译好的原生 WPF 小程序（无需安装 .NET 之外的任何东西）
- ✅ 可以拖动：按住左键把宠物拖到任意位置（同一显示器内拖动位置会保留）
- ✅ 右键菜单：刷新余额 / 退出；双击也能刷新
- ✅ 关闭 DSH 时自动退出；服务失联约 2 分钟后自动消失
- ✅ 余额代理只监听 `127.0.0.1`，API Key 不会进入浏览器

## 环境要求

- Windows 10/11（桌宠是 WPF 程序，需要 .NET Framework 4.8——系统自带）
- Node.js ≥ 18（插件与余额代理）
- 已安装 DeepSeek Harness（web profile）

## 安装

### 从 GitHub 安装

```sh
dsh plugin --profile web add github:Ho11ow8/deepseek-harness-balance-pet
```

然后**重启 `dsh web`**（关掉重新打开，或双击桌面的 DeepSeek Harness 快捷方式）。宠物会自动出现。

### 从本地目录安装（开发/调试用）

```sh
dsh plugin --profile web add file:D:\DeepseekHarness\DeepseekBalance\deepseek-balance-pet
```

（等价于：把依赖写进 `~/.dsh/profiles/web/package.json` 的 `dsh.profile.bundles` 与 `dependencies`，然后在该目录 `corepack pnpm install`。）

> 如果之前用 `file:` 装过、现在想改用 `github:`，先移除旧依赖再添加，避免同一包名有两个来源。

> API Key 读取位置：环境变量 `DEEPSEEK_API_KEY`，其次 `~/.dsh/.credentials.yaml` 中的 `DEEPSEEK_API_KEY` 行。

## 配置

在 profile 的 `cordis.patch.yml` 中覆盖任意配置项：

```yaml
- id: balance-pet
  config:
    port: 41999        # 本地余额代理端口
    pollSeconds: 20    # 刷新间隔（秒）
    petWidth: 220      # 宠物窗口宽度（高度按图片比例自动，默认 220）
    shadow: true       # 是否绘制投影
```

## 目录结构

```
deepseek-balance-pet/
├── cordis.patch.yml      # bundle 补丁：把 balance-pet 插件行插入 profile
├── lib/
│   ├── index.js          # 插件生命周期：启动余额代理 + 拉起桌宠，dispose 时清理
│   └── balance-server.js # 本地余额代理（可单独运行：node lib/balance-server.js --port 41999）
├── assets/
│   ├── DesktopPet.exe    # 预编译的 WPF 桌宠窗口（透明、可拖动，从属于 harness 浏览器窗口）
│   └── pet.png           # 预处理后的形象（白底已抠除、对话框文字已覆盖）
├── src/
│   ├── DesktopPet.cs     # 桌宠源码
│   ├── app.manifest      # DPI 感知声明
│   └── build.ps1         # 重新编译脚本（pwsh -File src\build.ps1）
└── tools/
    └── make-pet-image.mjs # 从原始图片重新生成 pet.png
```

## 重新生成形象 / 桌宠

- `tools/make-pet-image.mjs`：把工作区的原始图片（960x912）处理成 `pet.png`——沿图片边缘洪泛去掉白色背景，并用白色圆角矩形覆盖对话框旧文字。改图后可重新运行：

```sh
node tools/make-pet-image.mjs <原图.jpg> pet.png
```

- 重新编译桌宠（无需 Visual Studio，用 Windows 自带编译器）：

```sh
pwsh -File src\build.ps1
```

等价的手写命令：

```sh
C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe /nologo /target:winexe /optimize+ ^
  /main:DeepseekBalancePet.Program /out:assets\DesktopPet.exe ^
  /win32manifest:src\app.manifest ^
  /r:"C:\Windows\Microsoft.NET\Framework64\v4.0.30319\WPF\PresentationFramework.dll" ^
  /r:"C:\Windows\Microsoft.NET\Framework64\v4.0.30319\WPF\PresentationCore.dll" ^
  /r:"C:\Windows\Microsoft.NET\Framework64\v4.0.30319\WPF\WindowsBase.dll" ^
  /r:"C:\Windows\Microsoft.NET\Framework64\v4.0.30319\System.Xaml.dll" ^
  /r:"C:\Windows\Microsoft.NET\Framework64\v4.0.30319\System.dll" ^
  /r:"C:\Windows\Microsoft.NET\Framework64\v4.0.30319\System.Core.dll" ^
  src\DesktopPet.cs
```

## 常见问题

- **宠物没出现？** 确认 `deepseek-balance-pet` 已加入 web profile 的 bundles，并重启过 `dsh web`。
- **显示"获取失败"？** 检查 `~/.dsh/.credentials.yaml` 里 `DEEPSEEK_API_KEY` 是否有效、是否欠费（余额接口返回 `is_available: false` 也会报错）。
- **日志**：`%LOCALAPPDATA%\DeepseekBalancePet\pet.log`（桌宠端）与 dsh web 控制台（插件端 `[balance-pet]` 前缀）。

## License

MIT
