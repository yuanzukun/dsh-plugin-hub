# Rebuilds assets\DesktopPet.exe with the Windows built-in .NET Framework
# compiler (no Visual Studio / SDK required).
#
# Usage:
#   pwsh -File src\build.ps1
$ErrorActionPreference = 'Stop'

$fw = Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319'
$csc = Join-Path $fw 'csc.exe'
if (-not (Test-Path $csc)) { throw "csc.exe not found at $csc (are you on 64-bit Windows?)" }

$root = Split-Path -Parent $PSScriptRoot
$out = Join-Path $root 'assets\DesktopPet.exe'

$refs = @(
  (Join-Path $fw 'WPF\PresentationFramework.dll'),
  (Join-Path $fw 'WPF\PresentationCore.dll'),
  (Join-Path $fw 'WPF\WindowsBase.dll'),
  (Join-Path $fw 'System.Xaml.dll'),
  (Join-Path $fw 'System.dll'),
  (Join-Path $fw 'System.Core.dll')
) | ForEach-Object { "/r:`"$_`"" }

& $csc /nologo /target:winexe /optimize+ /platform:anycpu `
  /main:DeepseekBalancePet.Program `
  "/out:$out" `
  "/win32manifest:$(Join-Path $root 'src\app.manifest')" `
  $refs `
  (Join-Path $root 'src\DesktopPet.cs')

if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
Write-Host "built $out"
