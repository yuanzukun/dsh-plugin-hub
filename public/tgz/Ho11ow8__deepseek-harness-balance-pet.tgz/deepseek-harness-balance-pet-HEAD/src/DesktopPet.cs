// DesktopPet.exe — a transparent desktop pet for DeepSeek Harness.
//
// Shows pet.png (the harness artwork with the speech-bubble text already
// blanked out) and renders the live DeepSeek account balance inside the bubble,
// polling a localhost balance server (deepseek-balance-pet plugin) every N
// seconds.
//
// Visibility: the pet window is OWNED by the browser window whose title
// contains "DeepSeek Harness", so it is only visible while the harness UI is in
// the foreground — other apps cover it, minimizing the harness hides it, and
// closing the harness window hides the pet. It is placed at the bottom-right of
// the monitor the harness window is on (14px margin) and follows it across
// monitors; left-drag moves it (position is remembered per monitor).
//
// Usage: DesktopPet.exe [--port 41999] [--poll 20] [--width 153] [--shadow 1]

using System;
using System.Globalization;
using System.IO;
using System.Net;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Effects;
using System.Windows.Media.Imaging;
using System.Windows.Threading;

namespace DeepseekBalancePet
{
    //#region Win32 helpers
    public static class Native
    {
        public const int GWLP_HWNDPARENT = -8;
        public const uint GW_OWNER = 4;
        public const int SWP_NOSIZE = 0x0001;
        public const int SWP_NOZORDER = 0x0004;
        public const int SWP_NOACTIVATE = 0x0010;

        public delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);

        [DllImport("user32.dll")]
        public static extern bool EnumWindows(EnumWindowsProc lpEnumFunc, IntPtr lParam);
        [DllImport("user32.dll", CharSet = CharSet.Unicode)]
        public static extern int GetWindowText(IntPtr hWnd, StringBuilder lpString, int nMaxCount);
        [DllImport("user32.dll")]
        public static extern bool IsWindowVisible(IntPtr hWnd);
        [DllImport("user32.dll")]
        public static extern bool IsIconic(IntPtr hWnd);
        [DllImport("user32.dll")]
        public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint lpdwProcessId);
        [DllImport("user32.dll", EntryPoint = "SetWindowLongPtr")]
        public static extern IntPtr SetWindowLongPtr64(IntPtr hWnd, int nIndex, IntPtr dwNewLong);
        [DllImport("user32.dll", EntryPoint = "SetWindowLong")]
        public static extern int SetWindowLong32(IntPtr hWnd, int nIndex, IntPtr dwNewLong);
        [DllImport("user32.dll")]
        public static extern IntPtr GetWindow(IntPtr hWnd, uint uCmd);
        [DllImport("user32.dll")]
        public static extern IntPtr MonitorFromWindow(IntPtr hwnd, uint dwFlags);
        [DllImport("user32.dll", CharSet = CharSet.Unicode)]
        public static extern bool GetMonitorInfo(IntPtr hMonitor, ref MONITORINFO lpmi);
        [DllImport("user32.dll")]
        public static extern bool SetWindowPos(IntPtr hWnd, IntPtr hWndInsertAfter, int X, int Y, int cx, int cy, uint uFlags);
        [DllImport("user32.dll")]
        public static extern bool GetWindowRect(IntPtr hWnd, out RECT lpRect);
        [DllImport("user32.dll")]
        public static extern uint GetDpiForWindow(IntPtr hWnd);

        [StructLayout(LayoutKind.Sequential)]
        public struct RECT { public int Left, Top, Right, Bottom; }

        [StructLayout(LayoutKind.Sequential)]
        public struct MONITORINFO
        {
            public int cbSize;
            public RECT rcMonitor;
            public RECT rcWork;
            public uint dwFlags;
        }

        public static void SetOwner(IntPtr hwnd, IntPtr owner)
        {
            if (IntPtr.Size == 8) SetWindowLongPtr64(hwnd, GWLP_HWNDPARENT, owner);
            else SetWindowLong32(hwnd, GWLP_HWNDPARENT, owner);
        }

        public static string WindowTitle(IntPtr hwnd)
        {
            var sb = new StringBuilder(512);
            GetWindowText(hwnd, sb, sb.Capacity);
            return sb.ToString();
        }

        public static uint DpiOf(IntPtr hwnd)
        {
            uint dpi = GetDpiForWindow(hwnd);
            return dpi == 0 ? 96u : dpi;
        }

        /// Find a visible, unowned top-level window whose title contains the
        /// harness title (env override PET_OWNER_TITLE for testing).
        public static IntPtr FindHarnessWindow()
        {
            string match = Environment.GetEnvironmentVariable("PET_OWNER_TITLE");
            if (string.IsNullOrEmpty(match)) match = "DeepSeek Harness";
            IntPtr found = IntPtr.Zero;
            uint selfPid = (uint)System.Diagnostics.Process.GetCurrentProcess().Id;
            EnumWindows(delegate(IntPtr h, IntPtr l)
            {
                uint pid;
                GetWindowThreadProcessId(h, out pid);
                if (pid == selfPid) return true;
                if (!IsWindowVisible(h)) return true;
                if (GetWindow(h, GW_OWNER) != IntPtr.Zero) return true; // skip owned windows
                string title = WindowTitle(h);
                if (title.IndexOf(match, StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    found = h;
                    return false;
                }
                return true;
            }, IntPtr.Zero);
            return found;
        }

        /// Work area (physical px) of the monitor hosting the window, or null.
        public static MONITORINFO? MonitorWorkArea(IntPtr hwnd)
        {
            IntPtr mon = MonitorFromWindow(hwnd, 2 /*MONITOR_DEFAULTTONEAREST*/);
            if (mon == IntPtr.Zero) return null;
            var mi = new MONITORINFO();
            mi.cbSize = Marshal.SizeOf(typeof(MONITORINFO));
            if (!GetMonitorInfo(mon, ref mi)) return null;
            return mi;
        }
    }
    //#endregion

    public static class Program
    {
        [STAThread]
        public static int Main(string[] args)
        {
            try
            {
                return MainInner(args);
            }
            catch (Exception ex)
            {
                try
                {
                    string dump = Environment.GetEnvironmentVariable("PET_CRASHLOG");
                    if (string.IsNullOrEmpty(dump)) dump = Path.Combine(DataDir(), "crash.log");
                    File.WriteAllText(dump, DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + Environment.NewLine + ex.ToString(), Encoding.UTF8);
                }
                catch { }
                return 1;
            }
        }

        private static int MainInner(string[] args)
        {
            int port = 41999;
            int poll = 20;
            int width = 220;
            bool shadow = true;
            for (int i = 0; i < args.Length - 1; i++)
            {
                if (args[i] == "--port") { int.TryParse(args[i + 1], out port); i++; }
                else if (args[i] == "--poll") { int.TryParse(args[i + 1], out poll); i++; }
                else if (args[i] == "--width") { int.TryParse(args[i + 1], out width); i++; }
                else if (args[i] == "--shadow") { shadow = args[i + 1] != "0"; i++; }
            }
            if (poll < 5) poll = 5;
            if (width < 80) width = 80;

            bool owned = false;
            string mutexName = Environment.GetEnvironmentVariable("PET_MUTEX_NAME");
            if (string.IsNullOrEmpty(mutexName)) mutexName = "DeepseekBalancePet_Singleton";
            var mutex = new Mutex(false, mutexName);
            try
            {
                // wait briefly for a previous instance (e.g. a fast harness restart)
                owned = mutex.WaitOne(5000, false);
                if (!owned)
                {
                    Log("another instance is running; exiting");
                    return 0;
                }
                var app = new Application();
                app.DispatcherUnhandledException += (s, e) =>
                {
                    Program.Log("dispatcher exception: " + e.Exception);
                    e.Handled = true;
                };
                var window = new PetWindow(port, width, poll, shadow);
                app.Run(window);
                return 0;
            }
            finally
            {
                if (owned) mutex.ReleaseMutex();
                mutex.Dispose();
            }
        }

        private static string _logPath;
        public static string DataDir()
        {
            string env = Environment.GetEnvironmentVariable("LOCALAPPDATA");
            if (!string.IsNullOrEmpty(env))
                return Path.Combine(env, "DeepseekBalancePet");
            return Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "DeepseekBalancePet");
        }

        public static void Log(string message)
        {
            try
            {
                if (_logPath == null)
                {
                    string dir = DataDir();
                    Directory.CreateDirectory(dir);
                    _logPath = Path.Combine(dir, "pet.log");
                }
                File.AppendAllText(_logPath,
                    DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture) + "  " + message + Environment.NewLine,
                    Encoding.UTF8);
                // keep the log small
                try
                {
                    var fi = new FileInfo(_logPath);
                    if (fi.Exists && fi.Length > 64 * 1024)
                    {
                        string[] lines = File.ReadAllLines(_logPath, Encoding.UTF8);
                        int keep = Math.Min(lines.Length, 300);
                        string[] tail = new string[keep];
                        Array.Copy(lines, lines.Length - keep, tail, 0, keep);
                        File.WriteAllLines(_logPath, tail, Encoding.UTF8);
                    }
                }
                catch { }
            }
            catch { }
        }
    }

    public class PetWindow : Window
    {
        private const double MARGIN = 14.0;

        private readonly string _serverBase;
        private readonly int _pollSeconds;
        private readonly string _dataDir;
        private readonly TextBlock _valueText;
        private readonly double _boxWidth;
        private readonly double _baseValueSize;
        private readonly DispatcherTimer _balanceTimer;
        private readonly DispatcherTimer _ownerTimer;
        private IntPtr _myHwnd;
        private int _failCount;
        private bool _userMoved;
        private IntPtr _ownerHwnd;
        private bool _haveOwner;
        private bool _repositionPending;
        private string _ownerMonitorKey = "";

        public PetWindow(int port, int petWidth, int pollSeconds, bool shadow)
        {
            _serverBase = "http://127.0.0.1:" + port;
            _pollSeconds = pollSeconds;
            _dataDir = Program.DataDir();
            try { Directory.CreateDirectory(_dataDir); }
            catch { _dataDir = ""; } // fall back to no persistence/logging rather than crashing

            Topmost = false; // owned by the harness window instead
            ShowInTaskbar = false;
            ShowActivated = false;
            WindowStyle = WindowStyle.None;
            AllowsTransparency = true;
            Background = Brushes.Transparent;
            ResizeMode = ResizeMode.NoResize;
            WindowStartupLocation = WindowStartupLocation.Manual;
            Cursor = Cursors.Hand;

            // art aspect: 960 x 912
            double scale = petWidth / 960.0;
            Width = petWidth;
            Height = Math.Round(petWidth * 912.0 / 960.0);

            // provisional default (bottom-right of primary work area); the owner
            // tick re-anchors the window to the harness monitor shortly after
            var wa = SystemParameters.WorkArea;
            Left = wa.Right - Width - MARGIN;
            Top = wa.Bottom - Height - MARGIN;

            string baseDir = AppDomain.CurrentDomain.BaseDirectory;
            string imgPath = Path.Combine(baseDir, "pet.png");
            if (!File.Exists(imgPath))
            {
                Program.Log("pet.png not found next to the executable: " + imgPath);
                MessageBox.Show("pet.png not found next to DesktopPet.exe", "Deepseek Balance Pet", MessageBoxButton.OK, MessageBoxImage.Error);
                Application.Current.Shutdown(1);
                return;
            }

            var image = new Image();
            var bmp = new BitmapImage();
            bmp.BeginInit();
            bmp.CacheOption = BitmapCacheOption.OnLoad;
            bmp.UriSource = new Uri(imgPath);
            bmp.EndInit();
            image.Source = bmp;
            image.Stretch = Stretch.Fill;
            image.SnapsToDevicePixels = true;
            RenderOptions.SetBitmapScalingMode(image, BitmapScalingMode.HighQuality);
            if (shadow)
            {
                image.Effect = new DropShadowEffect
                {
                    BlurRadius = 14,
                    ShadowDepth = 3,
                    Opacity = 0.38,
                    Color = Colors.Black
                };
            }

            // speech-bubble text overlay: source rect (70,130)-(545,300) scaled.
            // The bubble shows a single line "余额：<value>" that auto-shrinks to fit.
            _boxWidth = 475.0 * scale;
            double boxH = 170.0 * scale;
            _baseValueSize = Math.Max(11, Math.Min(30, boxH * 0.62));

            var overlay = new Grid();
            overlay.Width = _boxWidth;
            overlay.Height = boxH;
            overlay.HorizontalAlignment = HorizontalAlignment.Left;
            overlay.VerticalAlignment = VerticalAlignment.Top;
            overlay.Margin = new Thickness(70.0 * scale, 130.0 * scale, 0, 0);

            _valueText = new TextBlock();
            _valueText.Text = "余额：……";
            _valueText.FontFamily = new FontFamily("Microsoft YaHei UI");
            _valueText.FontSize = _baseValueSize;
            _valueText.FontWeight = FontWeights.Bold;
            _valueText.Foreground = new SolidColorBrush(Color.FromRgb(0x1A, 0x1A, 0x1A));
            _valueText.TextAlignment = TextAlignment.Center;
            _valueText.TextWrapping = TextWrapping.NoWrap;
            _valueText.HorizontalAlignment = HorizontalAlignment.Center;
            _valueText.VerticalAlignment = VerticalAlignment.Center;

            overlay.Children.Add(_valueText);

            var root = new Grid();
            root.Children.Add(image);
            root.Children.Add(overlay);
            Content = root;

            ToolTip = "DeepSeek 余额（右键菜单 / 双击刷新）";

            // drag to move
            MouseLeftButtonDown += OnLeftButtonDown;

            // right-click menu
            var menu = new ContextMenu();
            var refreshItem = new MenuItem();
            refreshItem.Header = "刷新余额";
            refreshItem.Click += (s, e) => RefreshBalance();
            var exitItem = new MenuItem();
            exitItem.Header = "退出";
            exitItem.Click += (s, e) => Close();
            menu.Items.Add(refreshItem);
            menu.Items.Add(exitItem);
            ContextMenu = menu;

            // double-click to refresh
            MouseDoubleClick += (s, e) => RefreshBalance();

            // balance poll timer
            _balanceTimer = new DispatcherTimer();
            _balanceTimer.Interval = TimeSpan.FromSeconds(_pollSeconds);
            _balanceTimer.Tick += (s, e) => RefreshBalance();

            // harness-window visibility timer (~2s)
            _ownerTimer = new DispatcherTimer();
            _ownerTimer.Interval = TimeSpan.FromSeconds(2);
            _ownerTimer.Tick += (s, e) => OwnerTick();

            Loaded += OnLoaded;
            Closed += OnClosed;

            _myHwnd = new System.Windows.Interop.WindowInteropHelper(this).Handle;
        }

        private void OnLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed)
            {
                try
                {
                    DragMove();
                    _userMoved = true;
                }
                catch { }
            }
        }

        private void OnLoaded(object sender, RoutedEventArgs e)
        {
            _balanceTimer.Start();
            _ownerTimer.Start();
            OwnerTick();          // immediate first pass
            RefreshBalance();
            Program.Log("pet window ready (server=" + _serverBase + ", poll=" + _pollSeconds + "s)");
        }

        private void OnClosed(object sender, EventArgs e)
        {
            try { _balanceTimer.Stop(); } catch { }
            try { _ownerTimer.Stop(); } catch { }
            Program.Log("pet exited");
        }

        //#region harness-window ownership & visibility
        private void OwnerTick()
        {
            try
            {
                // WPF may re-create the window handle; always use the live one
                IntPtr hwnd = new System.Windows.Interop.WindowInteropHelper(this).Handle;
                if (hwnd != _myHwnd)
                {
                    _myHwnd = hwnd;
                    Program.Log("window handle refreshed: 0x" + hwnd.ToString("X"));
                }

                IntPtr found = Native.FindHarnessWindow();
                if (found != _ownerHwnd)
                {
                    _ownerHwnd = found;
                    _haveOwner = found != IntPtr.Zero;
                    _repositionPending = _haveOwner;
                    Program.Log(_haveOwner
                        ? "harness window attached (0x" + _ownerHwnd.ToString("X") + ")"
                        : "harness window not found; hiding");
                }

                // Re-assert Win32 ownership every tick: WPF re-applies its own
                // internal owner on show/hide and would otherwise detach us.
                Native.SetOwner(_myHwnd, _haveOwner ? _ownerHwnd : IntPtr.Zero);

                if (!_haveOwner)
                {
                    HidePet();
                    return;
                }

                // harness window minimized (or otherwise hidden) -> hide the pet
                if (Native.IsIconic(_ownerHwnd) || !Native.IsWindowVisible(_ownerHwnd))
                {
                    HidePet();
                    return;
                }

                ShowPet();

                // follow the harness window across monitors
                var wa = Native.MonitorWorkArea(_ownerHwnd);
                string key = "";
                if (wa.HasValue)
                {
                    key = wa.Value.rcMonitor.Left + "," + wa.Value.rcMonitor.Top + "," +
                          wa.Value.rcMonitor.Right + "," + wa.Value.rcMonitor.Bottom;
                }
                if (key != _ownerMonitorKey)
                {
                    _ownerMonitorKey = key;
                    _repositionPending = true;
                }

                if (_repositionPending && wa.HasValue)
                {
                    if (_userMoved && key == _ownerMonitorKey)
                    {
                        // keep the user's dragged position on this monitor
                        _repositionPending = false;
                    }
                    else
                    {
                        PlaceAtMonitorBottomRight(wa.Value);
                        _repositionPending = false;
                    }
                }
            }
            catch (Exception ex)
            {
                Program.Log("owner tick error: " + ex.Message);
            }
        }

        private void ShowPet()
        {
            if (Visibility != Visibility.Visible) Visibility = Visibility.Visible;
        }

        private void HidePet()
        {
            if (Visibility != Visibility.Hidden) Visibility = Visibility.Hidden;
        }

        /// Place the pet's bottom-right corner 14px inside the work area of the
        /// monitor hosting the harness window. The pet's actual on-screen size
        /// is measured via GetWindowRect, so the placement is correct regardless
        /// of the process DPI context (physical-pixel positioning).
        private void PlaceAtMonitorBottomRight(Native.MONITORINFO wa)
        {
            var r = new Native.RECT();
            if (!Native.GetWindowRect(_myHwnd, out r)) return;
            int wPhys = r.Right - r.Left;
            int hPhys = r.Bottom - r.Top;
            if (wPhys <= 0 || hPhys <= 0) return;
            double dpi = Native.DpiOf(_myHwnd) / 96.0; // pet's own DPI (it is DPI-aware)
            int margin = (int)Math.Round(MARGIN * dpi);
            int left = wa.rcWork.Right - wPhys - margin;
            int top = wa.rcWork.Bottom - hPhys - margin;
            Native.SetWindowPos(_myHwnd, IntPtr.Zero, left, top, 0, 0,
                Native.SWP_NOSIZE | Native.SWP_NOZORDER | Native.SWP_NOACTIVATE);
            Program.Log("positioned at bottom-right of harness monitor (" + left + "," + top + ") physical");
        }
        //#endregion

        private async void RefreshBalance()
        {
            try
            {
                string json;
                using (var wc = new WebClient())
                {
                    wc.Encoding = Encoding.UTF8;
                    json = await wc.DownloadStringTaskAsync(_serverBase + "/balance");
                }
                bool ok = Regex.IsMatch(json, "\"ok\"\\s*:\\s*true");
                if (!ok)
                {
                    string err = GetString(json, "error");
                    Program.Log("balance server error: " + err);
                    _failCount++;
                    ShowError();
                    MaybeAutoExit();
                    return;
                }
                string total = GetString(json, "total");
                string currency = GetString(json, "currency");
                string granted = GetString(json, "granted");
                string toppedUp = GetString(json, "toppedUp");
                _failCount = 0;
                SetValueText("余额：" + SymbolFor(currency) + total,
                    Color.FromRgb(0x1A, 0x1A, 0x1A));
                ToolTip = "DeepSeek 余额  " + SymbolFor(currency) + total
                    + "（充值 " + SymbolFor(currency) + toppedUp + " / 赠送 " + SymbolFor(currency) + granted + "）\n双击刷新 · 右键菜单";
                Program.Log("balance fetched: " + SymbolFor(currency) + total + " " + currency);
            }
            catch (Exception ex)
            {
                Program.Log("balance fetch failed: " + ex.Message);
                _failCount++;
                ShowError();
                MaybeAutoExit();
            }
        }

        private void ShowError()
        {
            SetValueText("余额：获取失败", Color.FromRgb(0xB0, 0x3A, 0x2E));
            ToolTip = "无法获取余额，稍后自动重试（右键可退出）";
        }

        /// Set the bubble text and shrink the font until it fits one line.
        private void SetValueText(string text, Color color)
        {
            _valueText.Text = text;
            _valueText.Foreground = new SolidColorBrush(color);
            double size = _baseValueSize;
            double measured = 0;
            while (size > 9)
            {
                var ft = new FormattedText(text, CultureInfo.CurrentUICulture,
                    FlowDirection.LeftToRight,
                    new Typeface(_valueText.FontFamily, FontStyles.Normal, FontWeights.Bold, FontStretches.Normal),
                    size, Brushes.Black, 1.0 /*PixelsPerDip: measure in DIPs*/);
                measured = ft.Width;
                if (ft.Width <= _boxWidth) break;
                size -= 0.5;
            }
            _valueText.FontSize = size;
            if (size < _baseValueSize - 0.01)
                Program.Log("font fit: text='" + text + "' size=" + size.ToString("0.0", CultureInfo.InvariantCulture)
                    + " width=" + measured.ToString("0.0", CultureInfo.InvariantCulture)
                    + " box=" + _boxWidth.ToString("0.0", CultureInfo.InvariantCulture));
        }

        private void MaybeAutoExit()
        {
            // harness closed / server gone: give up after ~6 consecutive failures
            if (_failCount >= 6)
            {
                Program.Log("server unreachable for " + _failCount + " polls; exiting");
                Close();
            }
        }

        private static string GetString(string json, string key)
        {
            var m = Regex.Match(json, "\"" + Regex.Escape(key) + "\"\\s*:\\s*\"([^\"]*)\"");
            return m.Success ? m.Groups[1].Value : "";
        }

        private static string SymbolFor(string currency)
        {
            if (currency == "CNY") return "¥";
            if (currency == "USD") return "$";
            if (currency == "EUR") return "€";
            if (currency == "GBP") return "£";
            if (currency == "JPY") return "¥";
            return "";
        }
    }
}
