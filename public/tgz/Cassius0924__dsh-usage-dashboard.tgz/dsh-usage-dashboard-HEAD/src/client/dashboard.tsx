/** The 「额度」 conversation view tab: full balance & usage dashboard.
 *
 * Caching: the first render comes straight from the package-local cache
 * (see ./api.ts), so reopening the tab shows data instantly. A background
 * refresh then updates it without blocking; a full-screen 加载中 only
 * appears when nothing has ever been cached.
 */
import { Fragment, useEffect, useLayoutEffect, useRef, useState, type CSSProperties, type DragEvent as ReactDragEvent, type KeyboardEvent as ReactKeyboardEvent, type ReactElement, type ReactNode } from 'react'
import { USAGE_WINDOW_DAYS } from '../contract.ts'
import { fetchBalance, fetchSessionUsage, fetchUsage, getCachedBalance, getCachedUsage, getCachedUsageAt } from './api.ts'
import { budgetSnapshot } from './budget.ts'
import { Bars, GroupedBars, Heatmap, MODEL_COLORS, fmt, fmtCompact, fmtInt } from './charts.tsx'
import { getComposerElement, getComposerInputElement, getShellFrame } from './dom.ts'
import { dailyUsageCsv, downloadText, exportDateStamp, fullUsageJson, modelUsageCsv } from './export.ts'
import { syncStatusText, type SyncState } from './freshness.ts'
import { fallbackT, intlLocale, localizeApiError, useI18n, type Translate } from './i18n.tsx'
import { quotaTabIndexStore, sidebarEntryStore, type SidebarEntryPlacement } from './layout-prefs.ts'
import { CHART_METRICS, chartMetricName, chartMetricValue, type ChartMetric } from './metric.ts'
import type { BalanceData, ModelUsage, PeakSplit, PeriodUsage, PricingInfo, SessionCost, SessionUsageData, UsageCoverage, UsageData, UsageWindowDays, VisionDayPoint, VisionSession, VisionStats } from '../contract.ts'
import { chartMetricStore, lowBalanceStore, monthlyBudgetStore, quotaViewActiveStore, usageWindowStore, widgetTabIdsStore, widgetVisibleStore } from './store.ts'
import { TOP_UP_URL, needsTopUp } from './top-up.ts'
import type { ConversationViewTab, ConversationViewsSource } from './views.ts'

/** `<package name> v<version>`, injected by build.mjs from package.json so the
 *  footer on the 额度 page reports exactly the version that was built. */
declare const __PLUGIN_LABEL__: string

/** Fallback composer height for the narrow-screen bottom safe area, used only
 *  until the real measurement below lands (or if the host markup ever stops
 *  exposing the `conversation.composer.dock` slot). DSH has no `--dsw-*`
 *  variable for composer height — this number is not a guess: it is the
 *  measured `[data-slot="conversation.composer.dock"]` seat height on a live
 *  DSH instance at 620 / 480 / 390px viewports (126px, stable across all
 *  three; see LEARNINGS.md). Kept in sync with the small margin added in
 *  styles.ts's `.dq-balance` narrow media query. */
const COMPOSER_FALLBACK_PX = 126

/** One shimmering placeholder block, sized by the caller. */
function Skel(props: { w: number; h: number }): ReactElement {
  return <div className="dq-skel" style={{ width: `${props.w}px`, height: `${props.h}px` }} />
}

/** Placeholder for the balance card while the first fetch is in flight. */
function BalanceSkeleton(): ReactElement {
  return (
    <div className="dq-balance-grid">
      <div className="dq-stat"><Skel w={56} h={11} /><Skel w={150} h={22} /></div>
      <div className="dq-stat"><Skel w={28} h={11} /><Skel w={48} h={22} /></div>
    </div>
  )
}

/** Placeholder for the current-session card: same three-`Stat` grammar as
 *  the balance card's skeleton above, just one more column. */
function SessionUsageSkeleton(): ReactElement {
  return (
    <div className="dq-balance-grid">
      <div className="dq-stat"><Skel w={64} h={11} /><Skel w={96} h={18} /></div>
      <div className="dq-stat"><Skel w={70} h={11} /><Skel w={80} h={18} /></div>
      <div className="dq-stat"><Skel w={64} h={11} /><Skel w={40} h={18} /></div>
    </div>
  )
}

/** Placeholder for the usage trend card: replaying every session log takes
 *  seconds, and an empty-state string there would read as "you have no usage". */
function UsageSkeleton(): ReactElement {
  return (
    <>
      <div className="dq-usage-totals">
        {[44, 44, 62, 62].map((w, i) => (
          <div key={i} className="dq-stat"><Skel w={w} h={11} /><Skel w={w > 70 ? 84 : 56} h={20} /></div>
        ))}
      </div>
      <Skel w={140} h={12} />
      <div className="dq-skel-bars">
        {Array.from({ length: 30 }, (_, i) => (
          <div key={i} className="dq-skel dq-skel-bar" style={{ height: `${18 + ((i * 37) % 82)}px` }} />
        ))}
      </div>
    </>
  )
}

/** Placeholder for the heatmap card, same loading grammar as the trend card's
 *  bar skeleton above — the heatmap has no separate fetch, it just renders
 *  once `usage` lands, so the two cards share one loading vocabulary. */
function HeatmapSkeleton(): ReactElement {
  return (
    <>
      <Skel w={140} h={12} />
      <div className="dq-skel-bars" style={{ height: '88px' }}>
        {Array.from({ length: 52 }, (_, i) => (
          <div key={i} className="dq-skel dq-skel-bar" style={{ height: `${14 + ((i * 29) % 60)}px` }} />
        ))}
      </div>
    </>
  )
}

/** Percentage chip comparing a window against the one before it. */
function Delta(props: { current: number; previous: number; label: string }): ReactElement | null {
  const { t } = useI18n()
  const { current, previous, label } = props
  if (previous <= 0) {
    if (current <= 0) return null
    return <span className="dq-delta dq-delta--new" title={t('delta.noBaselineTitle', { label })}>{t('delta.noBaseline')}</span>
  }
  const percent = Math.round(((current - previous) / previous) * 100)
  const title = `${label} ¥${fmt(previous)}`
  if (percent === 0) return <span className="dq-delta dq-delta--flat" title={title}>{t('delta.flat')}</span>
  const up = percent > 0
  // A tiny previous baseline makes the ratio explode (e.g. ↑9176%), which reads
  // like a bug rather than a fact. Cap the displayed magnitude; the title keeps
  // the exact baseline the number was computed from.
  const magnitude = Math.abs(percent) >= 1000 ? '999+' : String(Math.abs(percent))
  return (
    <span className={`dq-delta ${up ? 'dq-delta--up' : 'dq-delta--down'}`} title={title}>
      {up ? '↑' : '↓'}{magnitude}% <span className="dq-delta-label">{label}</span>
    </span>
  )
}

/** One window of the 消耗概览 card: cost headline, volume underneath. */
function Period(props: {
  label: string
  period: PeriodUsage
  previous?: PeriodUsage
  compare?: string
}): ReactElement {
  const { t, locale } = useI18n()
  const { period, previous, compare } = props
  return (
    <div className="dq-period">
      <div className="dq-period-head">
        <span className="dq-period-label">{props.label}</span>
        {previous !== undefined && compare !== undefined && (
          <Delta current={period.cost} previous={previous.cost} label={compare} />
        )}
      </div>
      <div className="dq-period-cost">¥{fmt(period.cost)}</div>
      <div className="dq-period-sub">{t('period.volume', {
        tokens: fmtCompact(period.total, locale),
        calls: t('common.calls', { count: fmtInt(period.calls) }),
      })}</div>
    </div>
  )
}

/** Monthly guardrail, kept inside the overview rather than adding another card. */
function BudgetMeter(props: { spent: number; budget: number; onConfigure: () => void }): ReactElement {
  const { t } = useI18n()
  if (props.budget <= 0) {
    return (
      <div className="dq-budget dq-budget--unset">
        <span>{t('budget.unset')}</span>
        <button type="button" className="dq-budget-action" onClick={props.onConfigure}>{t('budget.configure')}</button>
      </div>
    )
  }

  const snapshot = budgetSnapshot(props.spent, props.budget)
  const usedPercent = snapshot.ratio * 100
  const barPercent = Math.min(100, usedPercent)
  const forecastText = snapshot.status === 'over'
    ? t('budget.over', { amount: fmt(Math.abs(snapshot.remaining)) })
    : snapshot.forecastOver > 0
      ? t('budget.forecastOver', { amount: fmt(snapshot.forecastOver) })
      : t('budget.forecast', { amount: fmt(snapshot.forecast) })

  return (
    <div className={`dq-budget dq-budget--${snapshot.status}`}>
      <div className="dq-budget-head">
        <span className="dq-budget-title">{t('budget.title')}</span>
        <span className="dq-budget-amount">¥{fmt(snapshot.spent)} / ¥{fmt(snapshot.budget)}</span>
      </div>
      <div
        className="dq-budget-track"
        role="progressbar"
        aria-label={t('budget.progressLabel')}
        aria-valuemin={0}
        aria-valuemax={snapshot.budget}
        aria-valuenow={Math.min(snapshot.spent, snapshot.budget)}
        aria-valuetext={t('budget.used', { percent: usedPercent.toFixed(1), forecast: forecastText })}
      >
        <div className="dq-budget-fill" style={{ transform: `scaleX(${barPercent / 100})` }} />
      </div>
      <div className="dq-budget-meta">
        <span>{snapshot.remaining >= 0
          ? t('budget.remaining', { amount: fmt(snapshot.remaining) })
          : t('budget.exceeded', { amount: fmt(Math.abs(snapshot.remaining)) })}</span>
        <span>{forecastText}</span>
      </div>
    </div>
  )
}

const rate = (value: number): string => `¥${value.toLocaleString(undefined, { maximumFractionDigits: 3 })}`

/** Auditable breakdown of the rates the cost estimate was computed with —
 *  a `<details>` so it is keyboard-reachable without any extra state. */
function PricingNote(props: { pricing: PricingInfo }): ReactElement {
  const { t } = useI18n()
  const { pricing } = props
  return (
    <details className="dq-pricing">
      <summary className="dq-pricing-summary">
        {t('pricing.title')}
        <span className={`dq-pricing-now${pricing.inPeakNow ? ' dq-pricing-now--peak' : ''}`}>
          {pricing.inPeakNow ? t('pricing.currentPeak') : t('pricing.currentOffPeak')}
        </span>
      </summary>
      <div className="dq-pricing-body">
        <table className="dq-pricing-table">
          <thead>
            <tr>
              <th>{t('pricing.model')}</th>
              <th>{t('pricing.period')}</th>
              <th>{t('pricing.inputCacheHit')}</th>
              <th>{t('pricing.inputCacheMiss')}</th>
              <th>{t('pricing.output')}</th>
            </tr>
          </thead>
          <tbody>
            {pricing.tiers.map(tier => (
              <Fragment key={tier.model}>
                <tr>
                  <td rowSpan={2}>{tier.model}</td>
                  <td>{t('pricing.peak')}</td>
                  <td>{rate(tier.peak.cacheHit)}</td>
                  <td>{rate(tier.peak.input)}</td>
                  <td>{rate(tier.peak.output)}</td>
                </tr>
                <tr>
                  <td>{t('pricing.offPeak')}</td>
                  <td>{rate(tier.offPeak.cacheHit)}</td>
                  <td>{rate(tier.offPeak.input)}</td>
                  <td>{rate(tier.offPeak.output)}</td>
                </tr>
              </Fragment>
            ))}
          </tbody>
        </table>
        <p className="dq-pricing-foot">
          {t('pricing.unit', { currency: pricing.currency })}
          {t('pricing.splitNote', { windows: pricing.peakWindows.join(t('common.listSeparator')) })}
          {t('pricing.visionNote')}
          {t('pricing.unknown')}
        </p>
      </div>
    </details>
  )
}

/** Make a locally-computed bill honest about which logs it could inspect. */
function CoverageDiagnostics(props: { coverage: UsageCoverage }): ReactElement {
  const { t, locale } = useI18n()
  const { coverage } = props
  const hasGaps = coverage.failedSessions > 0
    || coverage.skippedRecords > 0
    || coverage.scannedSessions < coverage.listedSessions
  const coverageTime = new Intl.DateTimeFormat(intlLocale(locale), {
    timeZone: 'Asia/Shanghai', year: 'numeric', month: 'numeric', day: 'numeric',
    hour: '2-digit', minute: '2-digit', hour12: false,
  })
  const range = coverage.earliestAt === null || coverage.latestAt === null
    ? t('coverage.noRange')
    : `${coverageTime.format(coverage.earliestAt)} – ${coverageTime.format(coverage.latestAt)}`

  return (
    <details className={`dq-coverage${hasGaps ? ' dq-coverage--warn' : ''}`}>
      <summary className="dq-coverage-summary">
        <span className="dq-coverage-title">{t('coverage.title')}</span>
        <span className="dq-coverage-status">{hasGaps ? t('coverage.gaps') : t('coverage.complete')}</span>
        <span className="dq-coverage-brief">{t('coverage.brief', {
          scanned: fmtInt(coverage.scannedSessions), listed: fmtInt(coverage.listedSessions), records: fmtInt(coverage.usageRecords),
        })}</span>
      </summary>
      <div className="dq-coverage-body">
        <dl className="dq-coverage-metrics">
          <div><dt>{t('coverage.scanned')}</dt><dd>{t('common.sessions', { count: fmtInt(coverage.scannedSessions) })}</dd></div>
          <div><dt>{t('coverage.failed')}</dt><dd>{t('common.sessions', { count: fmtInt(coverage.failedSessions) })}</dd></div>
          <div><dt>{t('coverage.skipped')}</dt><dd>{t('common.records', { count: fmtInt(coverage.skippedRecords) })}</dd></div>
        </dl>
        <p className="dq-coverage-range">{t('coverage.time', { range })}</p>
        <p className="dq-coverage-note">{t('coverage.scope')}</p>
        {hasGaps && (
          <p className="dq-coverage-warning">{t('coverage.warning')}</p>
        )}
      </div>
    </details>
  )
}

/** Section heading: a short title, plus an optional quiet caption on the same line
 *  (scope / caveat such as 「近 30 天」「费用为估算」) so the title itself stays short. */
function CardTitle(props: { children: ReactNode; caption?: ReactNode; srOnly?: boolean }): ReactElement {
  return (
    <h2 className={`dq-card-title${props.srOnly === true ? ' dq-sr-only' : ''}`}>
      {props.children}
      {props.caption !== undefined && <span className="dq-card-caption">{props.caption}</span>}
    </h2>
  )
}

/** In-column section rail: one dot per top-level card, scroll-spy synced, sitting
 *  in the centred column's left gutter. Purely additive navigation — it never
 *  reorders or restyles the cards — and hides when there is no gutter to sit in,
 *  so it cannot compete with the host's own sidebar. */
function SectionNav(props: {
  rootRef: { readonly current: HTMLDivElement | null }
  label: string
  sections: Array<{ key: string; label: string }>
}): ReactElement | null {
  const { rootRef, label, sections } = props
  const [targets, setTargets] = useState<Array<{ el: HTMLElement; label: string }>>([])
  const [active, setActive] = useState(0)
  const [pos, setPos] = useState({ right: 0, visible: false })
  const signature = sections.map(section => `${section.key}:${section.label}`).join('|')

  // Pair the label list with the rendered top-level cards in DOM order. The only
  // conditional card is the current-session one, reflected in both lists above.
  useEffect(() => {
    const root = rootRef.current
    if (root === null) return
    const nodes = Array.from(root.querySelectorAll<HTMLElement>(':scope > .dq-card, :scope > .dq-card-pair'))
    setTargets(nodes.map((el, i) => ({ el, label: sections[i]?.label ?? '' })).filter(item => item.label !== ''))
    // `signature` captures the label list; `sections` itself changes identity each render.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [rootRef, signature])

  // Keep the rail in the gutter; hide it when the column is too close to an edge.
  useEffect(() => {
    const root = rootRef.current
    if (root === null) return
    const scrollport = root.closest('[data-conversation-scroll]') as HTMLElement | null
    const measure = (): void => {
      const rect = root.getBoundingClientRect()
      setPos({ right: window.innerWidth - rect.left + 12, visible: window.innerWidth >= 1200 && rect.left >= 170 })
    }
    measure()
    const scroller: HTMLElement | Window = scrollport ?? window
    scroller.addEventListener('scroll', measure, { passive: true })
    window.addEventListener('resize', measure)
    return () => {
      scroller.removeEventListener('scroll', measure)
      window.removeEventListener('resize', measure)
    }
  }, [rootRef])

  // Scroll-spy: the last card whose top crossed the top band is "current".
  useEffect(() => {
    if (targets.length === 0) return
    const root = rootRef.current
    if (root === null) return
    const scrollport = root.closest('[data-conversation-scroll]') as HTMLElement | null
    const onScroll = (): void => {
      const base = scrollport === null ? 0 : scrollport.getBoundingClientRect().top
      let current = 0
      targets.forEach((target, i) => {
        if (target.el.getBoundingClientRect().top - base <= 120) current = i
      })
      setActive(current)
    }
    onScroll()
    const scroller: HTMLElement | Window = scrollport ?? window
    scroller.addEventListener('scroll', onScroll, { passive: true })
    return () => scroller.removeEventListener('scroll', onScroll)
  }, [targets, rootRef])

  if (targets.length < 3) return null

  const go = (el: HTMLElement): void => {
    const root = rootRef.current
    const scrollport = root?.closest('[data-conversation-scroll]') as HTMLElement | null
    const reduce = typeof window.matchMedia === 'function' && window.matchMedia('(prefers-reduced-motion: reduce)').matches
    const behavior: ScrollBehavior = reduce ? 'auto' : 'smooth'
    if (scrollport !== null) {
      const base = scrollport.getBoundingClientRect().top
      scrollport.scrollTo({ top: scrollport.scrollTop + el.getBoundingClientRect().top - base - 12, behavior })
    } else {
      window.scrollTo({ top: el.getBoundingClientRect().top + window.scrollY - 12, behavior })
    }
  }

  return (
    <nav className={`dq-sectionnav${pos.visible ? '' : ' dq-sectionnav--hidden'}`} style={{ right: `${pos.right}px` }} aria-label={label}>
      <ol>
        {targets.map((target, i) => (
          <li key={`${target.label}-${String(i)}`}>
            <button
              type="button"
              className={`dq-sectionnav-dot${i === active ? ' dq-sectionnav-dot--active' : ''}`}
              aria-current={i === active ? 'true' : undefined}
              onClick={() => go(target.el)}
            >
              <span className="dq-sectionnav-label">{target.label}</span>
              <span className="dq-sectionnav-pip" aria-hidden="true" />
            </button>
          </li>
        ))}
      </ol>
    </nav>
  )
}

/** Height reveal + retract for content that stays mounted but toggles visibility
 *  (the settings panel). Styles are applied in a layout effect so the panel is
 *  already collapsed to height 0 BEFORE the first paint — no full-height flash,
 *  then it eases 0→measured (easeOutExpo). Closing animates back to 0 (ease-in)
 *  before display:none. Reduced motion snaps straight to the final state. */
function Collapsible(props: { open: boolean; children: ReactNode }): ReactElement {
  const ref = useRef<HTMLDivElement | null>(null)
  const animationRef = useRef<Animation | null>(null)
  const open = props.open
  useLayoutEffect(() => {
    const el = ref.current
    if (el === null) return
    animationRef.current?.cancel()
    animationRef.current = null
    const reduce = typeof window.matchMedia === 'function' && window.matchMedia('(prefers-reduced-motion: reduce)').matches
    const canAnimate = typeof el.animate === 'function' && !reduce
    const reset = (): void => { el.style.height = ''; el.style.overflow = ''; el.style.opacity = '' }
    if (open) {
      if (!canAnimate) {
        el.style.display = ''
        reset()
        return
      }
      // Collapse synchronously before paint so measuring the natural height never
      // shows the full panel for a frame.
      el.style.display = 'block'
      el.style.overflow = 'hidden'
      el.style.height = '0px'
      el.style.opacity = '0'
      const height = el.scrollHeight
      const animation = el.animate(
        [{ height: '0px', opacity: 0 }, { height: `${height}px`, opacity: 1 }],
        { duration: 300, easing: 'cubic-bezier(0.16, 1, 0.3, 1)' },
      )
      animationRef.current = animation
      animation.addEventListener('finish', reset)
      return () => animation.cancel()
    }
    if (el.style.display === 'none') return
    if (!canAnimate) {
      reset()
      el.style.display = 'none'
      return
    }
    const height = el.getBoundingClientRect().height || el.scrollHeight
    el.style.overflow = 'hidden'
    el.style.height = `${height}px`
    const animation = el.animate(
      [{ height: `${height}px`, opacity: 1 }, { height: '0px', opacity: 0 }],
      { duration: 220, easing: 'cubic-bezier(0.4, 0, 1, 1)' },
    )
    animationRef.current = animation
    animation.addEventListener('finish', () => { reset(); el.style.display = 'none' })
    return () => animation.cancel()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open])
  return <div ref={ref}>{props.children}</div>
}

function Stat(props: { label: string; children: ReactNode }): ReactElement {
  return (
    <div className="dq-stat">
      <div className="dq-stat-label">{props.label}</div>
      {props.children}
    </div>
  )
}

function Link(props: { href: string; children: ReactNode }): ReactElement {
  return (
    <a className="dq-link" href={props.href} target="_blank" rel="noreferrer">{props.children}</a>
  )
}

/** Download menu kept compact in the usage card header. */
function ExportMenu(props: { usage: UsageData }): ReactElement {
  const { t } = useI18n()
  const [open, setOpen] = useState(false)
  const [done, setDone] = useState(false)
  const rootRef = useRef<HTMLDivElement | null>(null)
  const triggerRef = useRef<HTMLButtonElement | null>(null)
  const menuRef = useRef<HTMLDivElement | null>(null)
  const doneTimerRef = useRef<number | null>(null)

  useEffect(() => {
    if (!open) return
    const onDown = (event: MouseEvent): void => {
      if (rootRef.current !== null && !rootRef.current.contains(event.target as Node)) setOpen(false)
    }
    const onKey = (event: KeyboardEvent): void => {
      if (event.key !== 'Escape') return
      setOpen(false)
      triggerRef.current?.focus()
    }
    document.addEventListener('mousedown', onDown)
    document.addEventListener('keydown', onKey)
    window.requestAnimationFrame(() => menuRef.current?.querySelector<HTMLButtonElement>('button')?.focus())
    return () => {
      document.removeEventListener('mousedown', onDown)
      document.removeEventListener('keydown', onKey)
    }
  }, [open])

  useEffect(() => () => {
    if (doneTimerRef.current !== null) window.clearTimeout(doneTimerRef.current)
  }, [])

  const finish = (): void => {
    setOpen(false)
    setDone(true)
    if (doneTimerRef.current !== null) window.clearTimeout(doneTimerRef.current)
    doneTimerRef.current = window.setTimeout(() => setDone(false), 1400)
  }

  const exportDaily = (): void => {
    const stamp = exportDateStamp()
    downloadText(`dsh-usage-${stamp}.csv`, dailyUsageCsv(props.usage), 'text/csv;charset=utf-8')
    finish()
  }
  const exportModels = (): void => {
    const stamp = exportDateStamp()
    downloadText(`dsh-usage-models-${stamp}.csv`, modelUsageCsv(props.usage), 'text/csv;charset=utf-8')
    finish()
  }
  const exportJson = (): void => {
    const stamp = exportDateStamp()
    downloadText(`dsh-usage-${stamp}.json`, fullUsageJson(props.usage), 'application/json;charset=utf-8')
    finish()
  }

  return (
    <div className="dq-export" ref={rootRef}>
      <button
        ref={triggerRef}
        type="button"
        className={`dq-export-btn${done ? ' dq-export-btn--done' : ''}`}
        aria-haspopup="true"
        aria-expanded={open}
        title={t('export.title')}
        onClick={() => setOpen(value => !value)}
      >
        {done ? t('export.done') : t('export.action')}
      </button>
      {open && (
        <div ref={menuRef} className="dq-export-menu" aria-label={t('export.menuLabel')}>
          <button type="button" onClick={exportDaily}>
            <span>{t('export.dailyCsv')}</span><small>{t('common.rows', { count: props.usage.daily.length })}</small>
          </button>
          <button type="button" onClick={exportModels}>
            <span>{t('export.modelCsv')}</span><small>{t('common.rows', { count: props.usage.models.length })}</small>
          </button>
          <button type="button" onClick={exportJson}>
            <span>{t('export.fullJson')}</span><small>{t('export.jsonHint')}</small>
          </button>
        </div>
      )}
    </div>
  )
}

export const modelKeyOf = (m: ModelUsage): string => (m.provider !== '' ? `${m.provider}/${m.model}` : m.model)

export const modelNameOf = (m: ModelUsage, t: Translate = fallbackT): string => (m.model !== '' ? m.model : t('common.unknownModel'))

/**
 * Usage for exactly the session the 「额度」 tab is opened inside — the one
 * dimension every other card on this page does not answer (they are all
 * account-wide, replayed across every local session log). Deliberately
 * reuses the same `.dq-balance-grid`/`Stat` headline layout as the balance
 * card above it and the same `.dq-rank`/`MODEL_COLORS` breakdown as the
 * model cost ranking card further down, rather than inventing a third
 * visual language for numbers that are structurally the same kind of thing.
 */
function SessionUsageCard(props: { data: SessionUsageData }): ReactElement {
  const { t, locale } = useI18n()
  const { data } = props
  if (data.calls === 0) return <div className="dq-empty">{t('sessionUsage.empty')}</div>

  const rangeTime = new Intl.DateTimeFormat(intlLocale(locale), {
    timeZone: 'Asia/Shanghai', year: 'numeric', month: 'numeric', day: 'numeric',
    hour: '2-digit', minute: '2-digit', hour12: false,
  })
  const range = data.firstActive !== null && data.lastActive !== null
    ? (data.firstActive === data.lastActive
      ? rangeTime.format(data.firstActive)
      : `${rangeTime.format(data.firstActive)} – ${rangeTime.format(data.lastActive)}`)
    : null

  return (
    <>
      <div className="dq-balance-grid">
        <Stat label={t('sessionUsage.cost')}><div className="dq-stat-value">¥{fmt(data.cost)}</div></Stat>
        <Stat label={t('sessionUsage.tokens')}><div className="dq-stat-value">{fmtCompact(data.total, locale)}</div></Stat>
        <Stat label={t('sessionUsage.calls')}><div className="dq-stat-value">{fmtInt(data.calls)}</div></Stat>
      </div>
      {/* One model = the breakdown would repeat the totals above; fold it into one meta line. */}
      <div className="dq-session-meta">
        {range !== null && <p className="dq-session-sub">{t('sessionUsage.range', { range })}</p>}
        {data.models.length === 1 && (
          <p className="dq-session-sub">{t('sessionUsage.single', {
            model: data.models[0].model !== '' ? data.models[0].model : t('common.unknownModel'),
            input: fmtCompact(data.models[0].input, locale),
            output: fmtCompact(data.models[0].output, locale),
            cache: fmtCompact(data.models[0].cache, locale),
          })}</p>
        )}
      </div>
      {data.models.length > 1 && (
        <div className="dq-rank">
          {data.models.map((m, index) => {
            const key = m.provider !== '' ? `${m.provider}/${m.model}` : (m.model !== '' ? m.model : `model-${index}`)
            const name = m.model !== '' ? m.model : t('common.unknownModel')
            const color = MODEL_COLORS[index % MODEL_COLORS.length]
            const share = data.cost > 0 ? m.cost / data.cost : 0
            return (
              <div key={key} className="dq-rank-row">
                <div className="dq-rank-head">
                  <span className="dq-rank-name" title={key}>
                    <span className="dq-legend-swatch" style={{ background: color }} />
                    {name}
                  </span>
                  <span className="dq-rank-cost">
                    ¥{fmt(m.cost)}
                    <span className="dq-rank-share">{(share * 100).toFixed(1)}%</span>
                  </span>
                </div>
                <div
                  className="dq-rank-track"
                  role="img"
                  aria-label={t('models.shareAria', { name, percent: (share * 100).toFixed(1) })}
                >
                  <div className="dq-rank-fill" style={{ width: `${Math.max(share * 100, 1.5)}%`, background: color }} />
                </div>
                <div className="dq-rank-sub">
                  {t('models.detail', {
                    tokens: fmtCompact(m.total, locale),
                    calls: t('common.calls', { count: fmtInt(m.calls) }),
                    input: fmtCompact(m.input, locale), output: fmtCompact(m.output, locale), cache: fmtCompact(m.cache, locale),
                  })}
                </div>
              </div>
            )
          })}
        </div>
      )}
    </>
  )
}

/**
 * What prefix caching is doing for the bill. Cache-hit tokens are priced at a
 * small fraction of cache-miss tokens, so on a DSH workload this is usually the
 * single biggest lever on cost — and it was invisible before.
 */
function CacheCard(props: { totals: UsageData['totals'] }): ReactElement {
  const { t, locale } = useI18n()
  const { totals } = props
  const prompt = totals.input + totals.cache
  if (prompt === 0) return <div className="dq-empty">{t('cache.empty')}</div>
  const rate = totals.cache / prompt
  const wouldHaveCost = totals.cost + totals.cacheSavings
  const low = rate < 0.6
  return (
    <div className="dq-cache">
      <div className="dq-cache-figures">
        <div className="dq-stat">
          <div className="dq-stat-label">{t('cache.rate')}</div>
          <div className={`dq-stat-value${low ? ' dq-stat-value--warn' : ' dq-stat-value--ok'}`}>
            {(rate * 100).toFixed(1)}%
          </div>
        </div>
        <div className="dq-stat">
          <div className="dq-stat-label">{t('cache.saved')}</div>
          <div className="dq-stat-value">¥{fmt(totals.cacheSavings)}</div>
        </div>
        <div className="dq-stat">
          <div className="dq-stat-label">{t('cache.allMiss')}</div>
          <div className="dq-stat-value dq-muted-value">¥{fmt(wouldHaveCost)}</div>
        </div>
      </div>
      <div className="dq-cache-track" role="img" aria-label={t('cache.aria', { hit: (rate * 100).toFixed(1), miss: ((1 - rate) * 100).toFixed(1) })}>
        <div className="dq-cache-fill" style={{ width: `${rate * 100}%` }} />
      </div>
      <div className="dq-cache-legend">
        <span><span className="dq-legend-swatch dq-legend-swatch--hit" />{t('cache.hitLegend', { tokens: fmtCompact(totals.cache, locale) })}</span>
        <span><span className="dq-legend-swatch dq-legend-swatch--miss" />{t('cache.missLegend', { tokens: fmtCompact(totals.input, locale) })}</span>
      </div>
      <p className="dq-cache-foot">{t('cache.basis', { cost: fmt(totals.cost), miss: fmt(wouldHaveCost) })}</p>
    </div>
  )
}

/** Everything `VisionCard` needs to paint one window's image usage. Captured
 *  as a snapshot by the trend card so the closing animation can keep showing
 *  the last payload after the live window stops reporting images. */
interface VisionSectionProps {
  vision: VisionStats
  daily: VisionDayPoint[]
  sessions: VisionSession[]
  windowLabel: string
  inputTokens: number
  costTotal: number
}

/**
 * Image / multimodal usage: how much of the bill came from pictures. Image
 * blocks are collected from user messages and tool results during the same
 * log replay that feeds the rest of the dashboard (no attachment bytes are
 * read — the refs already carry width/height), so this dimension costs the
 * replay nothing extra. Tokens are estimated with the official resizing rule
 * and priced at the consuming call's rates; shares are against the window's
 * reported input tokens and cost.
 */
function VisionCard(props: VisionSectionProps): ReactElement {
  const { t, locale } = useI18n()
  const { vision, daily, sessions, windowLabel, inputTokens, costTotal } = props
  if (vision.images === 0) return <div className="dq-empty">{t('vision.empty', { window: windowLabel })}</div>
  const tokensShare = inputTokens > 0 ? (vision.imageTokens / inputTokens) * 100 : 0
  const costShare = costTotal > 0 ? (vision.cost / costTotal) * 100 : 0
  const labelEvery = daily.length <= 7 ? 1 : daily.length <= 30 ? 5 : daily.length <= 90 ? 15 : 30
  const bars = daily.map(d => ({
    label: d.date.slice(8, 10),
    value: d.images,
    title: t('vision.barTitle', { date: d.date, images: fmtInt(d.images), tokens: fmtCompact(d.imageTokens, locale), cost: fmt(d.cost) }),
  }))
  return (
    <>
      <div className="dq-usage-totals">
        <Stat label={t('vision.images')}><div className="dq-stat-value">{fmtInt(vision.images)}</div></Stat>
        <Stat label={t('vision.tokens')}>
          <div className="dq-stat-value">
            {fmtCompact(vision.imageTokens, locale)}
            {tokensShare > 0 && <span className="dq-vision-share">{t('vision.tokensShare', { percent: tokensShare.toFixed(1) })}</span>}
          </div>
        </Stat>
        <Stat label={t('vision.cost')}>
          <div className="dq-stat-value">
            ¥{fmt(vision.cost)}
            {costShare > 0 && <span className="dq-vision-share">{t('vision.costShare', { percent: costShare.toFixed(1) })}</span>}
          </div>
        </Stat>
      </div>
      <div className="dq-chart-title">{t('vision.dailyTitle', { window: windowLabel })}</div>
      <Bars data={bars} height={80} labelEvery={labelEvery} />
      {sessions.length > 0 && (
        <div className="dq-vision-sessions">
          <div className="dq-chart-title">{t('vision.sessionsTitle')}</div>
          {sessions.map(session => (
            <div key={session.id} className="dq-session">
              <div className="dq-session-head">
                <span className="dq-session-title" title={session.id}>{session.title}</span>
                <span className="dq-session-cost">
                  {t('vision.sessionRow', { images: fmtInt(session.images), cost: fmt(session.cost) })}
                </span>
              </div>
            </div>
          ))}
        </div>
      )}
      <p className="dq-cache-foot">{t('vision.note')}</p>
    </>
  )
}

/**
 * Peak vs off-peak: which side of DeepSeek's price windows the usage falls on,
 * and what shifting the peak share off-peak would have saved.
 */
function PeakCard(props: { split: PeakSplit; pricing: PricingInfo }): ReactElement {
  const { t, locale } = useI18n()
  const { split, pricing } = props
  // Live Beijing clock so "now" stays honest while the tab is open; one tick a
  // minute is plenty for an hour-resolution strip.
  const [nowMs, setNowMs] = useState(() => Date.now())
  useEffect(() => {
    const id = setInterval(() => setNowMs(Date.now()), 60_000)
    return () => clearInterval(id)
  }, [])
  const total = split.peak.total + split.offPeak.total
  if (total === 0) return <div className="dq-empty">{t('peak.empty')}</div>
  const peakShare = split.peak.total / total
  const shiftSaving = split.peakEraCost - split.offPeakEraCost

  // DeepSeek peak windows are Beijing time and weekday-only in the current price
  // era. Derive the schedule from the same strings the pricing note shows, so the
  // clock cannot drift from the table.
  const beijing = new Date(nowMs + 8 * 3_600_000)
  const hour = beijing.getUTCHours()
  const minute = beijing.getUTCMinutes()
  const weekday = beijing.getUTCDay()
  const weekend = weekday === 0 || weekday === 6
  const windows = pricing.peakWindows
    .map(w => w.match(/(\d{1,2}):\d{2}\D+(\d{1,2}):\d{2}/))
    .filter((m): m is RegExpMatchArray => m !== null)
    .map(m => [Number(m[1]), Number(m[2])] as const)
  const isPeakNow = !weekend && windows.some(([from, to]) => hour >= from && hour < to)
  const nowPercent = ((hour + minute / 60) / 24) * 100
  const clockCells = Array.from({ length: 24 }, (_, h) => !weekend && windows.some(([from, to]) => h >= from && h < to))
  const nowState = isPeakNow ? t('peak.nowPeak') : t('peak.nowOff')
  return (
    <div className="dq-peak">
      <div className="dq-clock">
        <div className="dq-clock-head">
          <span className="dq-clock-title">{t('peak.clockTitle')}</span>
          <span className={`dq-clock-status ${isPeakNow ? 'dq-clock-status--peak' : 'dq-clock-status--off'}`}>{nowState}</span>
        </div>
        <div className="dq-clock-track" role="img" aria-label={t('peak.clockAria', { state: nowState })}>
          {clockCells.map((peak, h) => (
            <span key={h} className={`dq-clock-cell${peak ? ' dq-clock-cell--peak' : ''}`} />
          ))}
          <span className="dq-clock-now" style={{ left: `${nowPercent}%` }} aria-hidden="true" />
        </div>
        <div className="dq-clock-scale" aria-hidden="true"><span>0</span><span>6</span><span>12</span><span>18</span><span>24</span></div>
        <p className="dq-clock-hint">{t('peak.clockHint')}</p>
      </div>
      <div
        className="dq-peak-track"
        role="img"
        aria-label={t('peak.aria', { peak: (peakShare * 100).toFixed(1), offPeak: ((1 - peakShare) * 100).toFixed(1) })}
      >
        <div className="dq-peak-fill" style={{ width: `${peakShare * 100}%` }} />
      </div>
      <div className="dq-peak-legend">
        <span><span className="dq-legend-swatch dq-legend-swatch--peak" />{t('peak.peakLegend', {
          share: (peakShare * 100).toFixed(1), tokens: fmtCompact(split.peak.total, locale), calls: t('common.callsShort', { count: fmtInt(split.peak.calls) }),
        })}</span>
        <span><span className="dq-legend-swatch dq-legend-swatch--offpeak" />{t('peak.offPeakLegend', {
          share: ((1 - peakShare) * 100).toFixed(1), tokens: fmtCompact(split.offPeak.total, locale), calls: t('common.callsShort', { count: fmtInt(split.offPeak.calls) }),
        })}</span>
      </div>
      <div className="dq-peak-figures">
        <div className="dq-stat">
          <div className="dq-stat-label">{t('peak.shift')}</div>
          <div className="dq-stat-value dq-stat-value--ok">{t('peak.saving', { amount: fmt(shiftSaving) })}</div>
        </div>
      </div>
      <p className="dq-peak-foot">{t('peak.basis', { total: fmt(split.offPeakEraCost) })}</p>
    </div>
  )
}

/** Coarse "how long ago", enough to tell a live session from last week's. */
function agoText(ms: number, t: Translate): string {
  const minutes = Math.floor((Date.now() - ms) / 60_000)
  if (minutes < 1) return t('common.justNow')
  if (minutes < 60) return t('common.minutesAgo', { count: minutes })
  const hours = Math.floor(minutes / 60)
  if (hours < 24) return t('common.hoursAgo', { count: hours })
  return t('common.daysAgo', { count: Math.floor(hours / 24) })
}

/** Per-row fetch state for the ranking's on-demand expand — mirrors the
 *  three-way {loading, error, data} shape `loadSessionUsage` already uses
 *  for the current-session card, just keyed per row instead of per tab. */
interface SessionDetailState {
  error: string | null
  data: SessionUsageData | null
}

/** Body of one expanded ranking row: same loading/error/data three-way as the
 *  current-session card, and the same `SessionUsageCard` rendering the data —
 *  this is deliberately not a second implementation of that layout. */
function SessionDetail(props: { state: SessionDetailState | undefined }): ReactElement {
  const { t } = useI18n()
  const { state } = props
  if (state === undefined) return <SessionUsageSkeleton />
  if (state.data !== null) return <SessionUsageCard data={state.data} />
  if (state.error !== null) return <div className="dq-empty dq-empty--error">{localizeApiError(state.error, t, 'error.query')}</div>
  return <SessionUsageSkeleton />
}

/**
 * Which sessions burned the money. Per-model and per-day views say what and
 * when; this says *which run*, which is the one an agent user can act on —
 * a single expensive session is a prompt or a loop worth looking at.
 *
 * Each row is a native `<details>` (same disclosure grammar as `.dq-pricing`/
 * `.dq-coverage` above — no custom open/close state machine, keyboard and
 * touch come for free). Opening a row for the first time fires an on-demand
 * `fetchSessionUsage(s.id)` and renders the result with the exact same
 * `SessionUsageCard` the 「当前会话消耗」card uses — the row only has the
 * summary fields (`SessionCost`), the full per-model breakdown only exists
 * once that fetch lands. `startedRef` guards against re-fetching on a
 * collapse/re-expand: once a row's fetch has been kicked off, later toggles
 * just show whatever is already cached in `details`.
 */
function SessionRanking(props: { sessions: SessionCost[]; count: number; totalCost: number }): ReactElement {
  const { t, locale } = useI18n()
  const { sessions, count, totalCost } = props
  const [details, setDetails] = useState<Record<string, SessionDetailState>>({})
  const startedRef = useRef<Set<string>>(new Set())

  const loadDetail = (id: string): void => {
    if (startedRef.current.has(id)) return
    startedRef.current.add(id)
    fetchSessionUsage(id).then(res => {
      setDetails(prev => ({
        ...prev,
        [id]: res.ok && res.data !== undefined
          ? { error: null, data: res.data }
          : { error: res.error ?? null, data: null },
      }))
    }, err => {
      const message = (err as { message?: string } | null)?.message ?? String(err)
      setDetails(prev => ({ ...prev, [id]: { error: message, data: null } }))
    })
  }

  if (sessions.length === 0) return <div className="dq-empty">{t('sessions.empty')}</div>
  const top = sessions[0].cost
  return (
    <>
      <ol className="dq-sessions">
        {sessions.map(s => (
          <li key={s.id} className="dq-session">
            <details
              className="dq-session-details"
              onToggle={e => { if (e.currentTarget.open) loadDetail(s.id) }}
            >
              <summary className="dq-session-summary">
                <span className="dq-session-chevron" aria-hidden="true" />
                <div className="dq-session-summary-body">
                  <div className="dq-session-head">
                    <span className="dq-session-title" title={`${s.title}\n${s.id}`}>{s.title || t('sessions.fallbackTitle', { id: s.id })}</span>
                    <span className="dq-session-cost">¥{fmt(s.cost)}</span>
                  </div>
                  <div className="dq-session-track">
                    <div className="dq-session-fill" style={{ width: `${Math.max((s.cost / (top || 1)) * 100, 1.5)}%` }} />
                  </div>
                  <div className="dq-session-sub">
                    {t('sessions.detail', {
                      tokens: fmtCompact(s.total, locale),
                      calls: t('common.calls', { count: fmtInt(s.calls) }),
                      ago: agoText(s.lastActive, t),
                    })}
                    {totalCost > 0 && <> · {t('sessions.share', { percent: ((s.cost / totalCost) * 100).toFixed(1) })}</>}
                  </div>
                </div>
              </summary>
              <div className="dq-session-expand">
                <SessionDetail state={details[s.id]} />
              </div>
            </details>
          </li>
        ))}
      </ol>
      {count > sessions.length && (
        <p className="dq-session-foot">{t('sessions.more', { count: fmtInt(count), shown: sessions.length })}</p>
      )}
    </>
  )
}

/** Which model the money actually goes to, most expensive first. */
function ModelRanking(props: {
  models: ModelUsage[]
  totalCost: number
  colorOf: (key: string) => string
}): ReactElement {
  const { t, locale } = useI18n()
  const { models, totalCost } = props
  if (models.length === 0) return <div className="dq-empty">{t('models.empty')}</div>
  return (
    <div className="dq-rank">
      {models.map(m => {
        const key = modelKeyOf(m)
        const share = totalCost > 0 ? m.cost / totalCost : 0
        return (
          <div key={key} className="dq-rank-row">
            <div className="dq-rank-head">
              <span className="dq-rank-name" title={key}>
                <span className="dq-legend-swatch" style={{ background: props.colorOf(key) }} />
                {modelNameOf(m, t)}
              </span>
              <span className="dq-rank-cost">
                ¥{fmt(m.cost)}
                <span className="dq-rank-share">{(share * 100).toFixed(1)}%</span>
              </span>
            </div>
            <div
              className="dq-rank-track"
              role="img"
              aria-label={t('models.shareAria', { name: modelNameOf(m, t), percent: (share * 100).toFixed(1) })}
            >
              <div className="dq-rank-fill" style={{ width: `${Math.max(share * 100, 1.5)}%`, background: props.colorOf(key) }} />
            </div>
            <div className="dq-rank-sub">
              {t('models.detail', {
                tokens: fmtCompact(m.total, locale),
                calls: t('common.calls', { count: fmtInt(m.calls) }),
                input: fmtCompact(m.input, locale), output: fmtCompact(m.output, locale), cache: fmtCompact(m.cache, locale),
              })}
            </div>
          </div>
        )
      })}
    </div>
  )
}

/** Multi-select model dropdown feeding the grouped bar chart. */
function ModelPicker(props: {
  models: ModelUsage[]
  selected: string[]
  colorOf: (key: string) => string
  onChange: (keys: string[]) => void
}): ReactElement | null {
  const { t, locale } = useI18n()
  const { models } = props
  const [open, setOpen] = useState(false)
  const rootRef = useRef<HTMLDivElement | null>(null)
  const triggerRef = useRef<HTMLButtonElement | null>(null)
  const menuRef = useRef<HTMLDivElement | null>(null)

  useEffect(() => {
    if (!open) return
    const onDown = (e: MouseEvent): void => {
      if (rootRef.current !== null && !rootRef.current.contains(e.target as Node)) setOpen(false)
    }
    const onKey = (e: KeyboardEvent): void => {
      if (e.key !== 'Escape') return
      e.preventDefault()
      setOpen(false)
      triggerRef.current?.focus()
    }
    document.addEventListener('mousedown', onDown)
    document.addEventListener('keydown', onKey)
    window.requestAnimationFrame(() => menuRef.current?.querySelector<HTMLInputElement>('input')?.focus())
    return () => {
      document.removeEventListener('mousedown', onDown)
      document.removeEventListener('keydown', onKey)
    }
  }, [open])

  if (models.length === 0) return null

  const toggle = (key: string): void => {
    props.onChange(
      props.selected.includes(key)
        ? props.selected.filter(k => k !== key)
        : [...props.selected, key],
    )
  }

  const label = props.selected.length === 0 ? t('models.all') : t('models.selected', { count: props.selected.length })

  return (
    <div className="dq-model-picker" ref={rootRef}>
      <button
        ref={triggerRef}
        type="button"
        className="dq-model-btn"
        aria-haspopup="true"
        aria-expanded={open}
        aria-controls="dq-model-menu"
        title={t('models.filterTitle')}
        onClick={() => setOpen(value => !value)}
      >
        {label}
      </button>
      {open && (
        <div id="dq-model-menu" ref={menuRef} className="dq-model-menu" role="group" aria-label={t('models.filterLabel')}>
          <label className="dq-model-item dq-model-item--all">
            <input
              type="checkbox"
              checked={props.selected.length === 0}
              onChange={() => props.onChange([])}
            />
            <span>{t('models.all')}</span>
          </label>
          {models.map(m => {
            const key = modelKeyOf(m)
            return (
              <label key={key} className="dq-model-item">
                <input type="checkbox" checked={props.selected.includes(key)} onChange={() => toggle(key)} />
                <span className="dq-legend-swatch" style={{ background: props.colorOf(key) }} />
                <span>{modelNameOf(m, t)}</span>
                <span className="dq-model-tag">{fmtCompact(m.total, locale)}</span>
              </label>
            )
          })}
        </div>
      )}
    </div>
  )
}

const windowName = (days: UsageWindowDays, t: Translate = fallbackT): string => days === 365
  ? t('window.year')
  : t('window.days', { days })

/** One range choice controls every metric whose title carries that range. */
function UsageWindowPicker(props: { value: UsageWindowDays; onChange: (days: UsageWindowDays) => void }): ReactElement {
  const { t } = useI18n()
  return (
    <div className="dq-window-switch" role="group" aria-label={t('window.groupLabel')}>
      {USAGE_WINDOW_DAYS.map(days => (
        <button
          key={days}
          type="button"
          className={`dq-window-btn${props.value === days ? ' dq-window-btn--on' : ''}`}
          aria-pressed={props.value === days}
          title={t('window.viewTitle', { window: windowName(days, t) })}
          onClick={() => props.onChange(days)}
        >
          {days === 365 ? t('window.yearButton') : t('window.daysButton', { days })}
        </button>
      ))}
    </div>
  )
}

const chartMetricLabel = (metric: ChartMetric, t: Translate = fallbackT): string => metric === 'tokens'
  ? t('metric.tokens')
  : chartMetricName(metric, t)

function ChartMetricPicker(props: { value: ChartMetric; onChange: (metric: ChartMetric) => void }): ReactElement {
  const { t } = useI18n()
  return (
    <div className="dq-chart-switch" role="group" aria-label={t('metric.groupLabel')}>
      {CHART_METRICS.map(metric => (
        <button
          key={metric}
          type="button"
          className={`dq-chart-switch-btn${props.value === metric ? ' dq-chart-switch-btn--on' : ''}`}
          aria-pressed={props.value === metric}
          title={t('metric.compareTitle', { metric: chartMetricLabel(metric, t) })}
          onClick={() => props.onChange(metric)}
        >
          {chartMetricLabel(metric, t)}
        </button>
      ))}
    </div>
  )
}

export function BalanceDashboard(props: { sessionId?: string; views: ConversationViewsSource }): ReactElement {
  const { t, locale } = useI18n()
  // Seed state from the cache so the tab never waits on the network when
  // data has been fetched before (stale-while-revalidate).
  const cachedBalance = getCachedBalance()
  const cachedUsage = getCachedUsage()
  const cachedUsageAt = getCachedUsageAt()
  const [balance, setBalance] = useState<BalanceData | null>(cachedBalance?.data ?? null)
  const [usage, setUsage] = useState<UsageData | null>(cachedUsage?.data ?? null)
  const [error, setError] = useState<string | null>(null)
  const [notice, setNotice] = useState<{ kind: 'all' | 'balance' | 'usage'; error: string } | null>(null)
  // Balance answers in well under a second, usage replays every session log and
  // takes seconds — so they get their own loading flags and paint independently
  // instead of the fast one waiting on the slow one.
  const [loadingBalance, setLoadingBalance] = useState(cachedBalance === null)
  const [loadingUsage, setLoadingUsage] = useState(cachedUsage === null)
  const [refreshing, setRefreshing] = useState(false)
  const [usageUpdatedAt, setUsageUpdatedAt] = useState<number | null>(cachedUsageAt)
  const [syncState, setSyncState] = useState<SyncState>(cachedUsageAt === null ? 'syncing' : 'cached')
  const [freshnessNow, setFreshnessNow] = useState(Date.now())
  const [settingsOpen, setSettingsOpen] = useState(false)
  const hadDataRef = useRef(cachedBalance !== null || cachedUsage !== null)
  const [widgetOn, setWidgetOn] = useState(widgetVisibleStore.get())
  const [widgetTabIds, setWidgetTabIds] = useState<string[] | null>(widgetTabIdsStore.get())
  const [viewTabs, setViewTabs] = useState<ConversationViewTab[]>(() => props.views.list())
  useEffect(() => props.views.subscribe(() => setViewTabs(props.views.list())), [props.views])
  const [lowBalance, setLowBalance] = useState(lowBalanceStore.get())
  const [monthlyBudget, setMonthlyBudget] = useState(monthlyBudgetStore.get())
  const [barMode, setBarMode] = useState<'daily' | 'hourly'>('daily')
  const [selectedModels, setSelectedModels] = useState<string[]>([])
  const [windowDays, setWindowDays] = useState<UsageWindowDays>(usageWindowStore.get())
  const [chartMetric, setChartMetric] = useState<ChartMetric>(chartMetricStore.get())
  // Layout preferences shared with the client registration half (see
  // ./layout-prefs.ts): the sidebar entry is applied there, and the 「额度」tab
  // position is mapped onto the host's slot order there. Seed locally and stay
  // subscribed so the row shows whatever actually got applied.
  const [sidebarEntry, setSidebarEntry] = useState<SidebarEntryPlacement>(sidebarEntryStore.get())
  useEffect(() => sidebarEntryStore.subscribe(() => setSidebarEntry(sidebarEntryStore.get())), [])
  // Chip drag state for the tab-position setting. `tabDropTarget` is the chip
  // currently under the pointer while dragging, only to paint the drop target.
  const [tabDragging, setTabDragging] = useState(false)
  const [tabDropTarget, setTabDropTarget] = useState<number | null>(null)
  // The inline image-usage section animates closed when the selected window
  // loses its images; the last payload that had images stays rendered for the
  // ~320ms collapse, so the section always has something to show while shrinking.
  const [retainedVision, setRetainedVision] = useState<VisionSectionProps | null>(null)
  // "预计可用" hover preview: an unopened <details> skips rendering its
  // non-summary children in Chromium (a content-visibility-like platform
  // behavior), so CSS-only `:hover{display:block}` never paints anything
  // when the element isn't actually open. Drive `open` from state instead —
  // hovering opens it for a live preview; a manual click/keyboard/touch open
  // keeps it open independent of hover.
  const [runwayHovering, setRunwayHovering] = useState(false)
  const [runwayManuallyOpened, setRunwayManuallyOpened] = useState(false)
  // 轮次 47: same platform limitation applies to "余额明细" — it used the same
  // CSS-only `:hover{display:flex}` on an uncontrolled <details> since round 29,
  // which never actually painted in current Chromium either. Same fix, same shape.
  const [remainingHovering, setRemainingHovering] = useState(false)
  const [remainingManuallyOpened, setRemainingManuallyOpened] = useState(false)
  const budgetInputRef = useRef<HTMLInputElement | null>(null)
  const rootRef = useRef<HTMLDivElement | null>(null)
  const [composerHeight, setComposerHeight] = useState<number | null>(null)
  // The composer's measured width caps the dashboard column: on narrower
  // viewports the fixed 860px max-width would otherwise overhang the input
  // box the cards visually belong to (user-facing parity requirement).
  const [composerWidth, setComposerWidth] = useState<number | null>(null)
  // The current-session card: fetched per session id, not through the
  // account-wide balance/usage caches (see DESIGN_NOTES — session-scoped
  // data does not go through the localStorage-persisted cache). No cached
  // seed on first render since there is nothing to seed from.
  const [sessionUsage, setSessionUsage] = useState<SessionUsageData | null>(null)
  const [loadingSessionUsage, setLoadingSessionUsage] = useState(props.sessionId !== undefined && props.sessionId !== '')
  const [sessionUsageError, setSessionUsageError] = useState<string | null>(null)
  const sessionUsageIdRef = useRef<string | null>(null)

  // Narrow viewports only: keep the last card scrollable clear of the host's
  // fixed composer, which otherwise overlaps the bottom of a long dashboard
  // (see LEARNINGS.md). Reuses the same `conversation.composer.dock` slot
  // widget.tsx already excludes from its own drag bounds, so both readings of
  // "where is the composer" stay in sync. Desktop layout never reads the
  // height — the CSS variable is only consumed inside the 620px media query;
  // the width is consumed by .dq-balance at every viewport.
  useLayoutEffect(() => {
    const node = rootRef.current
    if (node === null) return
    const measure = (): void => {
      const frame = getShellFrame(node)
      const composer = getComposerElement(frame)
      const rect = composer?.getBoundingClientRect() ?? null
      const nextHeight = rect !== null && rect.height > 0 ? Math.round(rect.height) : null
      setComposerHeight(prev => (prev === nextHeight ? prev : nextHeight))
      // Width parity uses the composer's input card (the rounded panel with
      // the textarea), not the dock seat — the seat spans the whole pane, so
      // it can never narrow the dashboard column below 860px.
      const input = getComposerInputElement(frame)
      const inputRect = input?.getBoundingClientRect() ?? null
      const nextWidth = inputRect !== null && inputRect.width > 0 ? Math.round(inputRect.width) : null
      setComposerWidth(prev => (prev === nextWidth ? prev : nextWidth))
    }
    measure()
    const frame = getShellFrame(node)
    const composer = getComposerElement(frame)
    const input = getComposerInputElement(frame)
    let observer: ResizeObserver | null = null
    if (typeof ResizeObserver === 'function') {
      observer = new ResizeObserver(measure)
      if (composer !== null) observer.observe(composer)
      if (input !== null) observer.observe(input)
      if (frame !== null) observer.observe(frame)
    }
    window.addEventListener('resize', measure)
    return () => {
      observer?.disconnect()
      window.removeEventListener('resize', measure)
    }
  }, [])

  // All conversation view tabs (Chat / Trajectory / 额度 …) share one host
  // scrollport (`[data-conversation-scroll]`), and the host keeps scroll
  // memory only for Chat itself — switching to 额度 from a scrolled-down Chat
  // otherwise opens the tab near the settings card instead of at the account
  // balance. Reset before paint on every mount; the view is remounted per tab
  // switch, and `sessionId` re-runs it if the host reuses the view for
  // another session.
  useLayoutEffect(() => {
    const node = rootRef.current
    if (node === null) return
    const scrollport = node.closest('[data-conversation-scroll]')
    if (scrollport instanceof HTMLElement) scrollport.scrollTop = 0
  }, [props.sessionId])

  // The full dashboard and the floating summary should never compete for the
  // same pixels. This does not touch the persisted widget preference: leaving
  // the tab restores it exactly as the user left it.
  useLayoutEffect(() => {
    quotaViewActiveStore.set(true)
    return () => quotaViewActiveStore.set(false)
  }, [])

  const errText = (err: unknown): string => (err as { message?: string } | null)?.message ?? String(err)

  /** Load both resources; each resolves to null on success or to its error
   *  string on failure, so a partial failure can name the half that broke. */
  const load = async (force: boolean): Promise<void> => {
    const usageAtBefore = getCachedUsageAt()
    setError(null)
    setNotice(null)
    setRefreshing(true)
    setSyncState('syncing')
    const balanceTask = fetchBalance(force).then(res => {
      if (res.ok && res.data !== undefined) {
        setBalance(res.data)
        hadDataRef.current = true
        return null
      }
      return res.error ?? '余额加载失败'
    }, err => errText(err)).then(result => {
      setLoadingBalance(false)
      return result
    })
    const usageTask = fetchUsage(force).then(res => {
      if (res.ok && res.data !== undefined) {
        setUsage(res.data)
        const updatedAt = getCachedUsageAt()
        setUsageUpdatedAt(updatedAt)
        setFreshnessNow(Date.now())
        setSyncState(updatedAt !== null && updatedAt !== usageAtBefore ? 'fresh' : 'cached')
        hadDataRef.current = true
        return null
      }
      return res.error ?? '用量加载失败'
    }, err => errText(err)).then(result => {
      setLoadingUsage(false)
      return result
    })
    const [balanceError, usageError] = await Promise.all([balanceTask, usageTask])
    setRefreshing(false)
    if (usageError !== null) {
      const fallbackAt = getCachedUsageAt()
      setUsageUpdatedAt(fallbackAt)
      setFreshnessNow(Date.now())
      setSyncState(fallbackAt === null ? 'error' : 'fallback')
    }
    if (balanceError !== null && usageError !== null) {
      // Nothing came back at all: an error only when there is nothing to show.
      if (hadDataRef.current) setNotice({ kind: 'all', error: balanceError })
      else setError(balanceError)
    } else if (balanceError !== null) {
      setNotice({ kind: 'balance', error: balanceError })
    } else if (usageError !== null) {
      setNotice({ kind: 'usage', error: usageError })
    }
    // The current-session card rides along with an explicit force refresh so
    // the one refresh button covers all three data sources; the initial
    // mount-time fetch is handled separately below, keyed on the session id
    // itself, so it is not duplicated here (force=false would otherwise fire
    // twice on first render — once from this effect, once from that one).
    if (force && props.sessionId !== undefined && props.sessionId !== '') {
      void loadSessionUsage(props.sessionId, true)
    }
  }

  /** Stale-while-revalidate for the current-session card: on success, swap
   *  in the new data; on failure, keep whatever is already on screen (a
   *  refresh going bad should not blank out a card that was working). Guards
   *  every state write against the session id having changed mid-flight, so
   *  a slow request for a session the user has since navigated away from
   *  cannot clobber the next one's numbers. */
  const loadSessionUsage = async (id: string, force: boolean): Promise<void> => {
    if (!force) setLoadingSessionUsage(true)
    try {
      const res = await fetchSessionUsage(id, force)
      if (sessionUsageIdRef.current !== id) return
      if (res.ok && res.data !== undefined) {
        setSessionUsage(res.data)
        setSessionUsageError(null)
      } else {
        setSessionUsageError(res.error ?? null)
      }
    } catch (err) {
      if (sessionUsageIdRef.current === id) setSessionUsageError(errText(err))
    } finally {
      if (sessionUsageIdRef.current === id) setLoadingSessionUsage(false)
    }
  }

  useEffect(() => {
    void load(false)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  // Mount-time (and session-switch-time) fetch for the current-session card.
  // Independent of the balance/usage effect above: this data is scoped to
  // whichever session the tab happens to be open inside, not to the account.
  useEffect(() => {
    const id = props.sessionId
    sessionUsageIdRef.current = id ?? null
    if (id === undefined || id === '') {
      setSessionUsage(null)
      setSessionUsageError(null)
      setLoadingSessionUsage(false)
      return
    }
    setSessionUsage(null)
    setSessionUsageError(null)
    setLoadingSessionUsage(true)
    void loadSessionUsage(id, false)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [props.sessionId])

  useEffect(() => {
    const timer = window.setInterval(() => setFreshnessNow(Date.now()), 30_000)
    return () => window.clearInterval(timer)
  }, [])

  const toggle = (): void => {
    const next = !widgetOn
    setWidgetOn(next)
    widgetVisibleStore.set(next)
  }

  const widgetTabs = viewTabs.filter(tab => tab.id !== 'balance')
  const toggleWidgetTab = (id: string): void => {
    const selected = widgetTabIds ?? widgetTabs.map(tab => tab.id)
    const next = selected.includes(id) ? selected.filter(tabId => tabId !== id) : [...selected, id]
    setWidgetTabIds(next)
    widgetTabIdsStore.set(next)
  }

  const changeLowBalance = (value: number): void => {
    setLowBalance(value)
    lowBalanceStore.set(value)
  }

  const changeMonthlyBudget = (value: number): void => {
    setMonthlyBudget(value)
    monthlyBudgetStore.set(value)
  }

  const changeWindowDays = (value: UsageWindowDays): void => {
    setWindowDays(value)
    usageWindowStore.set(value)
  }

  const changeChartMetric = (value: ChartMetric): void => {
    setChartMetric(value)
    chartMetricStore.set(value)
  }

  const changeSidebarEntry = (value: SidebarEntryPlacement): void => {
    setSidebarEntry(value)
    sidebarEntryStore.set(value)
  }

  // 「额度」tab position: read from the live roster (never from local state) so
  // the chips show the order the host actually applied, including orders other
  // plugins picked.
  const balanceTabIndex = viewTabs.findIndex(tab => tab.id === 'balance')

  /** Final roster position for dropping the quota chip on `target`, before or
   *  after that chip's midpoint. The dragged chip leaves the roster before it
   *  is reinserted, so a rightward drop lands one slot earlier than the raw
   *  target — `quotaTabIndexStore` stores the final position, not an insertion
   *  gap, so the shift has to be undone here. */
  const finalTabIndex = (target: number, after: boolean): number => {
    const gap = after ? target + 1 : target
    const dropped = balanceTabIndex >= 0 && gap > balanceTabIndex ? gap - 1 : gap
    return Math.max(0, Math.min(dropped, Math.max(viewTabs.length - 1, 0)))
  }

  const endTabDrag = (): void => {
    setTabDragging(false)
    setTabDropTarget(null)
  }

  const previewTabDropTarget = (index: number): void => {
    setTabDropTarget(prev => (prev === index ? prev : index))
  }

  const applyQuotaTabIndex = (index: number): void => {
    const next = Math.max(0, Math.min(index, Math.max(viewTabs.length - 1, 0)))
    if (next === balanceTabIndex) return
    quotaTabIndexStore.set(next)
    // Applying the new slot order replaces our registration, which remounts
    // this dashboard: the chip loses DOM focus. Put it back after the remount
    // so holding ArrowLeft/ArrowRight can nudge the tab more than once.
    window.setTimeout(() => {
      const chip = document.querySelector<HTMLElement>('.dq-tab-chip--current')
      chip?.focus()
    }, 80)
  }

  const dropQuotaTab = (target: number, after: boolean): void => {
    applyQuotaTabIndex(finalTabIndex(target, after))
    endTabDrag()
  }

  const onQuotaTabDragStart = (event: ReactDragEvent<HTMLElement>): void => {
    setTabDragging(true)
    // Firefox refuses to start a drag unless some payload is attached.
    event.dataTransfer.effectAllowed = 'move'
    event.dataTransfer.setData('text/plain', 'balance')
  }

  const onChipDragOver = (event: ReactDragEvent<HTMLElement>, index: number): void => {
    // Only the quota chip's own drag reorders tabs; dragging a file, link or
    // selected text over the strip must not be accepted as a drop target.
    if (!tabDragging) return
    event.preventDefault()
    event.stopPropagation()
    previewTabDropTarget(index)
  }

  const onChipDrop = (event: ReactDragEvent<HTMLElement>, index: number): void => {
    if (!tabDragging) return
    event.preventDefault()
    event.stopPropagation()
    const rect = event.currentTarget.getBoundingClientRect()
    dropQuotaTab(index, event.clientX > rect.left + rect.width / 2)
  }

  const onOrderDragOver = (event: ReactDragEvent<HTMLDivElement>): void => {
    // The container itself (the chip-free tail) means "move to the end"; chips
    // stop propagation and compute a precise before/after slot.
    if (!tabDragging) return
    event.preventDefault()
    if (event.target === event.currentTarget) previewTabDropTarget(viewTabs.length - 1)
  }

  const onOrderDrop = (event: ReactDragEvent<HTMLDivElement>): void => {
    if (!tabDragging) return
    event.preventDefault()
    if (event.target !== event.currentTarget) return
    applyQuotaTabIndex(viewTabs.length - 1)
    endTabDrag()
  }

  const onQuotaTabKeyDown = (event: ReactKeyboardEvent<HTMLElement>): void => {
    if (event.key !== 'ArrowLeft' && event.key !== 'ArrowRight') return
    event.preventDefault()
    applyQuotaTabIndex(balanceTabIndex + (event.key === 'ArrowLeft' ? -1 : 1))
  }

  const primary = balance !== null && balance.balances.length > 0 ? balance.balances[0] : null

  // Runway: balance divided by the last 7 calendar days' average spend. Idle
  // days are included on purpose — that is the burn rate, not the busy-day rate.
  const recentDays = (usage?.daily ?? []).slice(-7)
  const avgDailyCost = recentDays.length > 0
    ? recentDays.reduce((sum, d) => sum + d.cost, 0) / recentDays.length
    : 0
  const balanceValue = primary !== null ? Number(primary.total) : Number.NaN
  // 0 disables the warning; an unreadable balance never triggers it.
  const balanceLow = lowBalance > 0 && Number.isFinite(balanceValue) && balanceValue < lowBalance
  // The top-up shortcut sits outside the configurable warning: either a balance
  // under the fixed floor or one under the user's line is "time to top up".
  const topUpPrompt = needsTopUp(balanceValue, lowBalance)
  const daysLeft = avgDailyCost > 0 && Number.isFinite(balanceValue) ? balanceValue / avgDailyCost : null
  const daysLeftText = daysLeft === null
    ? '—'
    : daysLeft >= 365 ? t('balance.overYear') : t('balance.days', { count: daysLeft < 10 ? daysLeft.toFixed(1) : Math.round(daysLeft) })
  const runwayTitle = daysLeft === null
    ? t('balance.noRunway', { days: recentDays.length || 7 })
    : t('balance.runwayTitle', { days: recentDays.length, cost: fmt(avgDailyCost) })

  const activeWindow = usage?.windows.find(window => window.days === windowDays) ?? null
  const activeWindowName = windowName(windowDays, t)

  // Image / multimodal usage lives inside the 用量趋势 card now, as a section
  // that opens and closes with the selected window: 0 images means no section
  // at all (a line saying "no images" is not worth the space). A host half
  // that has not been restarted yet sends a pre-vision payload, so the shape is
  // re-checked here rather than trusted from the types.
  const visionStats = activeWindow?.vision
  const visionOpen = usage !== null && activeWindow !== null && visionStats !== undefined
    && visionStats.images > 0
    && Array.isArray(activeWindow.visionDaily) && Array.isArray(activeWindow.visionSessions)
  const visionPayload = (window: NonNullable<typeof activeWindow>, stats: VisionStats, label: string): VisionSectionProps => ({
    vision: stats,
    daily: window.visionDaily,
    sessions: window.visionSessions,
    windowLabel: label,
    inputTokens: window.totals.input,
    costTotal: window.totals.cost,
  })
  const liveVision: VisionSectionProps | null = visionOpen && activeWindow !== null && visionStats !== undefined
    ? visionPayload(activeWindow, visionStats, activeWindowName)
    : null
  // Open: paint the live payload immediately. Closed: keep the last payload for
  // 320ms (matching the CSS grid-row collapse) and drop it afterwards. The
  // timer is cleared on every dependency change and on unmount.
  useEffect(() => {
    if (visionOpen && activeWindow !== null && visionStats !== undefined) {
      setRetainedVision(visionPayload(activeWindow, visionStats, activeWindowName))
      return
    }
    const timer = window.setTimeout(() => setRetainedVision(null), 320)
    return () => window.clearTimeout(timer)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [visionOpen, activeWindow, activeWindowName])
  const shownVision = visionOpen ? liveVision : retainedVision

  const dailyBars = (activeWindow?.daily ?? []).map(d => ({
    label: windowDays === 365 ? d.date.slice(5).replace('-', '/') : d.date.slice(8, 10),
    value: chartMetricValue(chartMetric, d),
    title: t('chart.tooltip', {
      head: d.date, tokens: fmtInt(d.total), cost: fmt(d.cost), calls: t('common.calls', { count: d.calls }),
    }),
  }))
  const hourlyBars = (activeWindow?.hourly ?? []).map(h => ({
    label: String(h.hour),
    value: chartMetricValue(chartMetric, h),
    title: t('chart.tooltip', {
      head: t('chart.hourPoint', { hour: h.hour }), tokens: fmtInt(h.total), cost: fmt(h.cost), calls: t('common.calls', { count: h.calls }),
    }),
  }))

  // One canonical model order — most expensive first — shared by the ranking
  // card, the picker and the chart, so a model keeps its colour everywhere
  // instead of being coloured by the order it happened to be ticked in.
  // Tallest bar currently on screen — the chart has no y axis, so this is the
  // only thing giving the bars a magnitude.
  const chartPeak = (barMode === 'daily' ? dailyBars : hourlyBars)
    .reduce((peak, bar) => (bar.value > peak ? bar.value : peak), 0)
  const chartPeakText = chartMetric === 'cost'
    ? `¥${fmt(chartPeak)}`
    : chartMetric === 'calls'
      ? t('common.callsShort', { count: fmtInt(chartPeak) })
      : `${fmtCompact(chartPeak, locale)} tokens`

  const modelList = [...(activeWindow?.models ?? [])].sort((a, b) => b.cost - a.cost)
  const canonicalModels = [...(usage?.models ?? [])].sort((a, b) => b.cost - a.cost)
  const availableModelKeys = new Set(modelList.map(modelKeyOf))
  const effectiveSelection = selectedModels.filter(k => availableModelKeys.has(k))
  const colorOf = (key: string): string => {
    const index = canonicalModels.findIndex(m => modelKeyOf(m) === key)
    return MODEL_COLORS[(index < 0 ? 0 : index) % MODEL_COLORS.length]
  }
  const modelCostTotal = modelList.reduce((sum, m) => sum + m.cost, 0)

  // Per-model series for the grouped bar chart (only when models are selected).
  const grouped = effectiveSelection.map(key => {
    const m = modelList.find(x => modelKeyOf(x) === key)
    const name = m === undefined ? key : modelNameOf(m, t)
    const color = colorOf(key)
    if (barMode === 'daily') {
      return {
        key,
        name,
        color,
        bars: (m?.daily ?? []).map((p, i) => ({
          label: windowDays === 365
            ? ((activeWindow?.daily ?? [])[i]?.date.slice(5).replace('-', '/') ?? '')
            : ((activeWindow?.daily ?? [])[i]?.date.slice(8, 10) ?? ''),
          value: chartMetricValue(chartMetric, p),
          title: t('chart.tooltip', {
            head: `${name} · ${(activeWindow?.daily ?? [])[i]?.date ?? ''}`,
            tokens: fmtInt(p.total), cost: fmt(p.cost), calls: t('common.calls', { count: p.calls }),
          }),
        })),
      }
    }
    return {
      key,
      name,
      color,
      bars: (m?.hourly ?? []).map((p, i) => ({
        label: String(i),
        value: chartMetricValue(chartMetric, p),
        title: t('chart.tooltip', {
          head: `${name} · ${t('chart.hourPoint', { hour: i })}`,
          tokens: fmtInt(p.total), cost: fmt(p.cost), calls: t('common.calls', { count: p.calls }),
        }),
      })),
    }
  })
  const dailyLabelEvery = windowDays === 7 ? 1 : windowDays === 30 ? 5 : windowDays === 90 ? 15 : 30
  const dailyMinWidth = windowDays === 365 ? 1825 : undefined
  const noticeText = notice === null ? null : t(
    notice.kind === 'all'
      ? 'error.refreshCached'
      : notice.kind === 'balance' ? 'error.balanceRefreshCached' : 'error.usageRefreshCached',
    { error: localizeApiError(notice.error, t, 'error.query') },
  )
  const errorText = error === null ? null : localizeApiError(error, t, 'error.query')

  const composerSafeAreaStyle = {
    '--dq-composer-h': `${composerHeight ?? COMPOSER_FALLBACK_PX}px`,
    // Only set once measured; .dq-balance's max-width falls back to 860px
    // without it (pre-measurement render keeps the settled wide-viewport
    // column, then narrows in place — no flash of the old width).
    ...(composerWidth !== null ? { '--dq-composer-w': `${composerWidth}px` } : {}),
  } as CSSProperties

  const navSections = [
    { key: 'balance', label: t('nav.balance') },
    ...(props.sessionId !== undefined && props.sessionId !== '' ? [{ key: 'session', label: t('nav.session') }] : []),
    { key: 'overview', label: t('nav.overview') },
    { key: 'trend', label: t('nav.trend') },
    { key: 'heatmap', label: t('nav.heatmap') },
    { key: 'models', label: t('nav.models') },
    { key: 'sessions', label: t('nav.sessions') },
    { key: 'peakcache', label: t('nav.peakcache') },
  ]

  return (
    <div className="dq-balance" ref={rootRef} style={composerSafeAreaStyle}>
      <SectionNav rootRef={rootRef} label={t('nav.label')} sections={navSections} />
      <div className="dq-status-row">
        <div className="dq-status-messages">
          <span
            className={`dq-sync dq-sync--${syncState}`}
            role="status"
            aria-live="polite"
            title={usageUpdatedAt === null
              ? t('status.neverSynced')
              : t('status.usageTime', { time: new Date(usageUpdatedAt).toLocaleString(intlLocale(locale), { timeZone: 'Asia/Shanghai' }) })}
          >
            <span className="dq-sync-dot" aria-hidden="true" />
            {syncStatusText(syncState, usageUpdatedAt, freshnessNow, t)}
          </span>
          {noticeText !== null && <span className="dq-warn">{noticeText}</span>}
          {errorText !== null && <span className="dq-error">{errorText}</span>}
        </div>
        <div className="dq-status-actions">
          <button
            type="button"
            className="dq-settings-btn"
            aria-expanded={settingsOpen}
            aria-controls="dq-settings-panel"
            onClick={() => setSettingsOpen(open => !open)}
          >
            {t('settings.title')}
            <span className={`dq-settings-caret${settingsOpen ? ' dq-settings-caret--open' : ''}`} aria-hidden="true">▾</span>
          </button>
          <button
            type="button"
            className="dq-refresh-btn"
            title={t('status.forceRefresh')}
            disabled={refreshing}
            aria-busy={refreshing}
            onClick={() => { void load(true) }}
          >
            <span className={`dq-refresh-icon${refreshing ? ' dq-refresh-icon--spin' : ''}`}>↻</span>
            {refreshing ? t('status.refreshing') : t('status.refresh')}
          </button>
        </div>
      </div>

      {balanceLow && (
        <div className="dq-alert" role="status">
          <span className="dq-alert-icon" aria-hidden="true">!</span>
          <div>
            <strong>{t('alert.lowTitle', { balance: fmt(balanceValue), currency: primary?.currency, threshold: fmt(lowBalance) })}</strong>
            {daysLeft !== null && t('alert.runway', { days: daysLeftText })}{t('common.period')}
            <a className="dq-alert-link" href={TOP_UP_URL} target="_blank" rel="noreferrer">{t('alert.topUp')}</a>
          </div>
        </div>
      )}

      <div className="dq-card dq-card--hero">
        <CardTitle srOnly>{t('balance.title')}</CardTitle>
        {primary !== null ? (
          <div className="dq-balance-grid">
            <div className="dq-stat">
              <div className="dq-stat-label">{t('balance.remaining')}</div>
              <details
                className="dq-stat-value dq-remaining"
                open={remainingHovering || remainingManuallyOpened}
                onPointerEnter={() => setRemainingHovering(true)}
                onPointerLeave={() => setRemainingHovering(false)}
              >
                <summary
                  title={t('balance.breakdownTitle')}
                  aria-label={`${fmt(primary.total)} ${primary.currency}`}
                  onClick={e => {
                    // Own the toggle fully instead of the native default action: a controlled
                    // <details> can be forced open by hover, and a plain native toggle here
                    // would fight that (e.g. it flips to "closed" while the mouse is still
                    // hovering). Preventing default and flipping our own "manually opened"
                    // state keeps hover-preview and click/keyboard/tap-to-pin independent.
                    e.preventDefault()
                    setRemainingManuallyOpened(v => !v)
                  }}
                >
                  {fmt(primary.total)}<span className="dq-hero-unit">{primary.currency}</span>
                </summary>
                <div className="dq-remaining-breakdown">
                  <span>{t('balance.toppedUp', { amount: fmt(primary.toppedUp) })}</span>
                  <span className="dq-remaining-granted">{t('balance.granted', { amount: fmt(primary.granted) })}</span>
                </div>
              </details>
            </div>
            <div className="dq-stat">
              <div className="dq-stat-label">{t('balance.runway')}</div>
              <div className="dq-runway-line">
                <details
                  className={`dq-stat-value dq-runway${daysLeft !== null && daysLeft < 3 ? ' dq-stat-value--bad' : ''}`}
                  open={runwayHovering || runwayManuallyOpened}
                  onPointerEnter={() => setRunwayHovering(true)}
                  onPointerLeave={() => setRunwayHovering(false)}
                >
                  <summary
                    title={t('balance.runwayBreakdownTitle')}
                    onClick={e => {
                      // Own the toggle fully instead of the native default action: a controlled
                      // <details> can be forced open by hover, and a plain native toggle here
                      // would fight that (e.g. it flips to "closed" while the mouse is still
                      // hovering). Preventing default and flipping our own "manually opened"
                      // state keeps hover-preview and click/keyboard/tap-to-pin independent.
                      e.preventDefault()
                      setRunwayManuallyOpened(v => !v)
                    }}
                  >
                    {daysLeftText}
                  </summary>
                  <div className="dq-runway-detail">{runwayTitle}</div>
                </details>
                {topUpPrompt && (
                  <a className="dq-topup" href={TOP_UP_URL} target="_blank" rel="noreferrer" title={t('balance.topUpTitle')}>
                    {t('alert.topUp')}
                    <span className="dq-topup-arrow" aria-hidden="true">↗</span>
                  </a>
                )}
              </div>
            </div>
            {/* 「可用」是常态，不占 hero 位；只有账户不可用时才出现，且用错误色。 */}
            {balance?.isAvailable === false && (
              <Stat label={t('common.status')}>
                <div className="dq-stat-value dq-stat-value--bad">{t('common.unavailable')}</div>
              </Stat>
            )}
          </div>
        ) : loadingBalance ? (
          <BalanceSkeleton />
        ) : (
          <div className="dq-empty">{t('balance.empty')}</div>
        )}
      </div>

      <Collapsible open={settingsOpen}>
        <div className="dq-settings-panel" id="dq-settings-panel" role="region" aria-label={t('settings.title')}>
          <CardTitle>{t('settings.title')}</CardTitle>
        <div className="dq-setting-group">
          <div className="dq-setting-group-title">{t('settings.groupDisplay')}</div>
          <label className="dq-toggle">
            <input type="checkbox" checked={widgetOn} onChange={toggle} />
            <span>{t('settings.widget')}</span>
          </label>
          <div className="dq-toggle-hint">{t('settings.widgetHint')}</div>
          <div className="dq-setting dq-setting--tabs">
            <div className="dq-setting-label" id="dq-widget-tabs-label">{t('settings.widgetTabs')}</div>
            <div className="dq-setting-control dq-widget-tabs" role="group" aria-labelledby="dq-widget-tabs-label">
              <div className="dq-widget-tab-list">
                {widgetTabs.map(tab => (
                  <label className="dq-widget-tab" key={tab.id}>
                    <input
                      type="checkbox"
                      checked={widgetTabIds === null || widgetTabIds.includes(tab.id)}
                      onChange={() => toggleWidgetTab(tab.id)}
                    />
                    <span>{tab.label}</span>
                  </label>
                ))}
              </div>
              <span className="dq-setting-hint">
                {widgetTabs.length === 0 ? t('settings.widgetTabsEmpty') : t('settings.widgetTabsHint')}
              </span>
            </div>
          </div>
        </div>

        <div className="dq-setting-group">
          <div className="dq-setting-group-title">{t('settings.groupAlerts')}</div>
          <div className="dq-setting">
            <label className="dq-setting-label" htmlFor="dq-low-balance">{t('settings.lowBalance')}</label>
            <div className="dq-setting-control">
              <input
                id="dq-low-balance"
                className="dq-number"
                type="number"
                min={0}
                step={1}
                value={lowBalance}
                onChange={e => changeLowBalance(Math.max(0, Number(e.target.value) || 0))}
              />
              <span className="dq-setting-hint">
                {lowBalance > 0
                  ? t('settings.lowBalanceOn', { amount: fmt(lowBalance), currency: primary?.currency ?? 'CNY' })
                  : t('settings.lowBalanceOff')}
              </span>
            </div>
          </div>
          <div className="dq-setting">
            <label className="dq-setting-label" htmlFor="dq-monthly-budget">{t('settings.monthlyBudget')}</label>
            <div className="dq-setting-control">
              <input
                ref={budgetInputRef}
                id="dq-monthly-budget"
                className="dq-number"
                type="number"
                min={0}
                step={10}
                value={monthlyBudget}
                aria-describedby="dq-monthly-budget-hint"
                onChange={e => changeMonthlyBudget(Math.max(0, Number(e.target.value) || 0))}
              />
              <span id="dq-monthly-budget-hint" className="dq-setting-hint">
                {monthlyBudget > 0
                  ? t('settings.monthlyBudgetOn', { amount: fmt(monthlyBudget) })
                  : t('settings.monthlyBudgetOff')}
              </span>
            </div>
          </div>
        </div>

        <div className="dq-setting-group">
          <div className="dq-setting-group-title">{t('settings.groupLayout')}</div>
          <div className="dq-setting">
            <label className="dq-setting-label" htmlFor="dq-sidebar-entry">{t('settings.sidebarEntry')}</label>
            <div className="dq-setting-control">
              <select
                id="dq-sidebar-entry"
                className="dq-select"
                value={sidebarEntry}
                onChange={e => changeSidebarEntry(e.target.value as SidebarEntryPlacement)}
              >
                <option value="off">{t('settings.sidebarEntryOff')}</option>
                <option value="top">{t('settings.sidebarEntryTop')}</option>
                <option value="bottom">{t('settings.sidebarEntryBottom')}</option>
              </select>
              <span className="dq-setting-hint">{t('settings.sidebarEntryHint')}</span>
            </div>
          </div>
          <div className="dq-setting">
            <div className="dq-setting-label" id="dq-tab-order-label">{t('settings.tabPosition')}</div>
            <div className="dq-setting-control">
              <div
                className="dq-tab-order"
                role="group"
                aria-labelledby="dq-tab-order-label"
                aria-describedby="dq-tab-order-hint"
                onDragOver={onOrderDragOver}
                onDrop={onOrderDrop}
              >
                {viewTabs.map((tab, index) => {
                  const current = tab.id === 'balance'
                  const dropTarget = tabDragging && !current && tabDropTarget === index
                  return (
                    <span
                      key={tab.id}
                      className={`dq-tab-chip${current ? ' dq-tab-chip--current' : ''}${current && tabDragging ? ' dq-tab-chip--dragging' : ''}${dropTarget ? ' dq-tab-chip--drop-target' : ''}`}
                      draggable={current}
                      tabIndex={current ? 0 : undefined}
                      role={current ? 'button' : undefined}
                      aria-label={current ? t('settings.tabDragAria') : undefined}
                      onDragStart={current ? onQuotaTabDragStart : undefined}
                      onDragEnd={current ? endTabDrag : undefined}
                      onDragOver={event => onChipDragOver(event, index)}
                      onDrop={event => onChipDrop(event, index)}
                      onKeyDown={current ? onQuotaTabKeyDown : undefined}
                    >
                      {tab.label}
                    </span>
                  )
                })}
              </div>
              <span id="dq-tab-order-hint" className="dq-setting-hint">{t('settings.tabPositionHint')}</span>
            </div>
          </div>
        </div>

        <div className="dq-setting-group">
          <div className="dq-setting-group-title">{t('links.title')}</div>
          <div className="dq-links">
            <Link href="https://platform.deepseek.com/usage">{t('links.usage')}</Link>
            <Link href="https://platform.deepseek.com/api_keys">{t('links.apiKey')}</Link>
            <Link href="https://status.deepseek.com">{t('links.status')}</Link>
          </div>
        </div>
        </div>
      </Collapsible>

      {props.sessionId !== undefined && props.sessionId !== '' && (
        <div className="dq-card dq-card--primary">
          <CardTitle caption={t('common.estimated')}>{t('sessionUsage.title')}</CardTitle>
          {sessionUsage !== null ? (
            <SessionUsageCard data={sessionUsage} />
          ) : loadingSessionUsage ? (
            <SessionUsageSkeleton />
          ) : sessionUsageError !== null ? (
            <div className="dq-empty dq-empty--error">{localizeApiError(sessionUsageError, t, 'error.query')}</div>
          ) : (
            <div className="dq-empty">{t('sessionUsage.empty')}</div>
          )}
        </div>
      )}

      <div className="dq-card dq-card--primary">
        <CardTitle caption={t('common.estimated')}>{t('overview.title')}</CardTitle>
        {usage !== null ? (
          <div className="dq-period-grid">
            <Period label={t('overview.today')} period={usage.summary.today} previous={usage.summary.yesterday} compare={t('overview.vsYesterday')} />
            <Period label={t('overview.month')} period={usage.summary.month} previous={usage.summary.lastMonthToDate} compare={t('overview.vsLastMonth')} />
            <Period
              label={t('overview.total')}
              period={{ total: usage.totals.total, cost: usage.totals.cost, calls: usage.totals.calls }}
            />
          </div>
        ) : loadingUsage ? (

          <div className="dq-period-grid">
            {[0, 1, 2].map(i => (
              <div key={i} className="dq-period">
                <Skel w={40} h={11} /><Skel w={104} h={24} /><Skel w={132} h={11} />
              </div>
            ))}
          </div>
        ) : (
          <div className="dq-empty">{t('overview.empty')}</div>
        )}
        {usage !== null && (
          <BudgetMeter
            spent={usage.summary.month.cost}
            budget={monthlyBudget}
            onConfigure={() => { setSettingsOpen(true); window.setTimeout(() => budgetInputRef.current?.focus(), 80) }}
          />
        )}
        {usage !== null && <PricingNote pricing={usage.pricing} />}
      </div>

      <div className="dq-card dq-card--primary">
        <div className="dq-card-head">
          <CardTitle>{t('usage.trendTitle')}</CardTitle>
          {usage !== null && (
            <div className="dq-card-actions">
              <UsageWindowPicker value={windowDays} onChange={changeWindowDays} />
              <ExportMenu usage={usage} />
            </div>
          )}
        </div>
        {usage !== null && activeWindow !== null ? (
          <>
            <div className="dq-usage-totals">
              <Stat label={t('usage.windowInput', { window: activeWindowName })}><div className="dq-stat-value">{fmtCompact(activeWindow.totals.input, locale)}</div></Stat>
              <Stat label={t('common.output')}><div className="dq-stat-value">{fmtCompact(activeWindow.totals.output, locale)}</div></Stat>
              <Stat label={t('common.cacheHit')}><div className="dq-stat-value">{fmtCompact(activeWindow.totals.cache, locale)}</div></Stat>
              <Stat label={t('usage.modelCalls')}><div className="dq-stat-value">{fmtInt(activeWindow.totals.calls)}</div></Stat>
            </div>
            <div className="dq-chart-block-head">
              <div className="dq-chart-title">
                {barMode === 'daily'
                  ? t('chart.dailyTitle', { window: activeWindowName, metric: chartMetricName(chartMetric, t) })
                  : t('chart.hourlyTitle', { window: activeWindowName, metric: chartMetricName(chartMetric, t) })}
                {chartPeak > 0 && <span className="dq-chart-peak">{t('chart.peak', { value: chartPeakText })}</span>}
              </div>
              <div className="dq-chart-controls">
                <ModelPicker models={modelList} selected={effectiveSelection} colorOf={colorOf} onChange={setSelectedModels} />
                <ChartMetricPicker value={chartMetric} onChange={changeChartMetric} />
                <div className="dq-chart-switch" role="tablist" aria-label={t('chart.dimensionLabel')}>
                  <button
                    type="button"
                    role="tab"
                    aria-selected={barMode === 'daily'}
                    className={`dq-chart-switch-btn${barMode === 'daily' ? ' dq-chart-switch-btn--on' : ''}`}
                    onClick={() => setBarMode('daily')}
                  >
                    {t('chart.daily')}
                  </button>
                  <button
                    type="button"
                    role="tab"
                    aria-selected={barMode === 'hourly'}
                    className={`dq-chart-switch-btn${barMode === 'hourly' ? ' dq-chart-switch-btn--on' : ''}`}
                    onClick={() => setBarMode('hourly')}
                  >
                    {t('chart.hourly')}
                  </button>
                </div>
              </div>
            </div>
            {activeWindow.totals.calls === 0 ? (
              <div className="dq-empty">{t('chart.noWindowData', { window: activeWindowName })}</div>
            ) : grouped.length > 0 ? (
              <>
                <GroupedBars
                  series={grouped}
                  height={barMode === 'daily' ? 160 : 140}
                  labelEvery={barMode === 'daily' ? dailyLabelEvery : 3}
                  minWidth={barMode === 'daily' ? dailyMinWidth : undefined}
                />
                <div className="dq-legend">
                  {grouped.map(s => (
                    <span key={s.key} className="dq-legend-item">
                      <span className="dq-legend-swatch" style={{ background: s.color }} />
                      {s.name}
                    </span>
                  ))}
                </div>
              </>
            ) : barMode === 'daily' ? (
              <Bars data={dailyBars} height={160} labelEvery={dailyLabelEvery} minWidth={dailyMinWidth} />
            ) : (
              <Bars data={hourlyBars} height={140} labelEvery={3} />
            )}
          </>
        ) : loadingUsage ? (
          <UsageSkeleton />
        ) : (
          <div className="dq-empty">{t('chart.empty')}</div>
        )}
        {/* 图片用量并入本卡：窗口切到没有图片的范围时整段收起。关闭期间仍渲染
            最后一份有图数据，让 0fr→1fr 的收起动画有内容可动；加载中也保留关闭态
            的空壳，数据到达时才是真的「展开」而不是直接出现。 */}
        <div className="dq-vision-inline" data-open={visionOpen ? 'true' : 'false'} aria-hidden={!visionOpen}>
          <div className="dq-vision-inline-body">
            {shownVision !== null && (
              <>
                <div className="dq-chart-title">{t('vision.title')}<span className="dq-chart-peak">{shownVision.windowLabel}</span></div>
                <VisionCard
                  vision={shownVision.vision}
                  daily={shownVision.daily}
                  sessions={shownVision.sessions}
                  windowLabel={shownVision.windowLabel}
                  inputTokens={shownVision.inputTokens}
                  costTotal={shownVision.costTotal}
                />
              </>
            )}
          </div>
        </div>
        {usage !== null && <CoverageDiagnostics coverage={usage.coverage} />}
      </div>

      <div className="dq-card">
        <CardTitle caption={t('chart.heatmapTitle')}>{t('heatmap.title')}</CardTitle>
        {usage !== null ? (
          <Heatmap data={usage.heatmap} />
        ) : loadingUsage ? (
          <HeatmapSkeleton />
        ) : (
          <div className="dq-empty">{t('chart.empty')}</div>
        )}
      </div>

      <div className="dq-card">
        <CardTitle caption={activeWindowName}>{t('models.title')}</CardTitle>
        {activeWindow !== null ? (
          <ModelRanking models={modelList} totalCost={modelCostTotal} colorOf={colorOf} />
        ) : loadingUsage ? (
          <div className="dq-rank">
            {[0, 1].map(i => (
              <div key={i} className="dq-rank-row">
                <Skel w={148} h={13} />
                <div className="dq-rank-track" />
                <Skel w={230} h={11} />
              </div>
            ))}
          </div>
        ) : (
          <div className="dq-empty">{t('models.empty')}</div>
        )}
      </div>

      <div className="dq-card">
        <CardTitle caption={activeWindowName}>{t('sessions.title')}</CardTitle>
        {activeWindow !== null ? (
          <SessionRanking sessions={activeWindow.sessions} count={activeWindow.sessionCount} totalCost={activeWindow.totals.cost} />
        ) : loadingUsage ? (
          <div className="dq-sessions">
            {[0, 1, 2].map(i => (
              <div key={i} className="dq-session">
                <Skel w={200} h={13} />
                <div className="dq-session-track" />
                <Skel w={250} h={11} />
              </div>
            ))}
          </div>
        ) : (
          <div className="dq-empty">{t('sessions.empty')}</div>
        )}
      </div>

      {/* The two half-width analysis cards sit side by side while there is
          room; below the pair's own 340px column floor they stack. */}
      <div className="dq-card-pair">
        <div className="dq-card">
          <CardTitle>{t('peak.title')}</CardTitle>
          {usage !== null ? (
            <PeakCard split={usage.peakSplit} pricing={usage.pricing} />
          ) : loadingUsage ? (
            <>
              <div className="dq-peak-track" />
              <div className="dq-peak-figures"><Skel w={120} h={11} /><Skel w={96} h={20} /></div>
            </>
          ) : (
            <div className="dq-empty">{t('peak.empty')}</div>
          )}
        </div>

        <div className="dq-card">
          <CardTitle>{t('cache.title')}</CardTitle>
          {usage !== null ? (
            <CacheCard totals={usage.totals} />
          ) : loadingUsage ? (
            <div className="dq-cache-figures">
              {[60, 96, 72].map((w, i) => (
                <div key={i} className="dq-stat"><Skel w={w} h={11} /><Skel w={72} h={20} /></div>
              ))}
            </div>
          ) : (
            <div className="dq-empty">{t('cache.empty')}</div>
          )}
        </div>
      </div>

      <p className="dq-footer">{__PLUGIN_LABEL__}</p>
    </div>
  )
}
