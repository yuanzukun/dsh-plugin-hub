# dsh-matrix-rain — 黑客帝国代码雨（思考链驱动）

DSH WebUI 动效美化插件：聊天界面背景加入「黑客帝国代码雨」特效，
**雨字内容 = 当前会话 AI 的思考链**（流式实时，AI 一边思考、雨一边下它的思路）。

## 特性

- **思考链即雨字**：优先取当前流式输出中的 reasoning 块，其次取最后一条 AI 消息的思考链。三种内容模式：
  - **思考链原文流** — 雨滴按游标顺序取字，竖向可读出思考片段（默认）
  - **思考链乱序投影** — 字符打乱，保留灵感氛围又不直接暴露思考全文（隐私友好）
  - **经典字符** — 纯 Katakana/ASCII 经典矩阵雨（无思考链时自动回退）
- **华丽不挡阅读**：雨层 `pointer-events:none` 全程穿透点击/选择；低透明度 + 可调背景压暗；「两侧留白 / 底部横条」雨区模式给正文让视线
- **设置页完整 DIY**（设置 → 矩阵代码雨，Host 持久化）：
  - 总开关（另有会话标题行快捷开关按钮，可隐藏）
  - 雨区范围 / 密度 / 下落速度 / 字号 / 文字切换速度 / 整体透明度 / 背景压暗
  - 调色盘：头部主色、拖尾主体色、辉光色、背景色 四个取色器 + 五套预设主题（经典矩阵 / 幽灵蓝 / 霓虹紫 / 血色红 / 琥珀金）
  - 内容模式、回退字符集、活跃模式（常驻 / 仅思考时）、鼠标扰动、恢复默认
- **设置变更渐进生效**：每个雨滴生成时快照「当时」的颜色/字号/速度/字符池——改设置不会清空或改写已生成的雨滴，它们保持原样自然滑落到底部消失，新设置只作用于之后生成的雨滴（新旧雨滴平滑交替；背景压暗/透明度属于环境氛围，即时生效）
- **性能**：仅文本变化重建字符池；`仅思考时` 模式无内容自动停帧省电；页面隐藏自动暂停；dpr 上限 2；密度按雨区收敛

## 安装（热装配，免重启）

```powershell
# 方式一：运行时注入
# 使用 DSH 的 dev_inject_plugin，参数 = 本目录
# 方式二：热装配（重启后由 bundles 列表自动装配）
# 使用 DSH 的 dev_install_package，参数 = 本目录
```

## ⚠️ 必做：api-proxy settings 白名单补丁

浏览器设置面板读写 `matrix-rain` 命名空间需要 host 端 `dsh-host-apiproxy`
的 `WEB_SETTINGS_NAMESPACES` 放行（官方把「哪些插件命名空间暴露给 Web 设置」
硬编码在 api-proxy 里）。**dsh 升级覆盖官方包后必须重打**：

```powershell
node patches/apply-runtime-patches.mjs   # 应用（--reverse 回滚）
# 修改目标：@deepseek-ai/dsh-host-apiproxy/lib/index.js
# 效果：WEB_SETTINGS_NAMESPACES 追加 "matrix-rain"
# 注意：需要重启 dsh 进程生效（已打过的环境可跳过）
```

若未打补丁：设置面板仍可打开、雨效照常，但开关/调色盘的改动不会持久化
（每次刷新回到默认值）。

## 文件结构

```
dsh-matrix-rain/
├── package.json          # dsh bundle 声明（exports: . / ./client / ./cordis.patch.yml）
├── cordis.patch.yml      # 组合挂载补丁
├── patches/
│   └── apply-runtime-patches.mjs  # api-proxy allowlist 补丁（dsh 升级后重打）
└── lib/
    ├── index.js          # Node half：注册 matrix-rain settings 命名空间（schemastery schema）
    └── client.js         # 浏览器 half：采集桥 + canvas 引擎 + 设置面板（手写 bundle）
```

## 架构（三个 additive slot，零官方 UI 替换）

| Slot | 职责 |
| --- | --- |
| `conversation.session.header.utilities` | 思考链采集桥：`useSession` 订阅快照 → 提取 reasoning 文本 → 共享 store；同时渲染快捷开关按钮 |
| `shell.overlay` | 全屏 canvas 代码雨（`pointer-events:none`），rAF 直读 store + 最新配置，不经 React 重渲染 |
| `settings.section` | 完整 DIY 设置页（settingsScope Host 持久化，zh/en 双语） |

思考链数据源：`ConversationSnapshot.partial.blocks`（流式）→ 回退 `nodes[]` 最后一条 `assistant` 消息的 `blocks`，取 `kind === 'reasoning'` 块。

## 默认配置

全屏雨区 · 密度 50% · 速度 1× · 15px · 透明度 30% · 压暗 18% · 经典绿调色盘 · 思考链原文流 · 常驻 · 快捷按钮开
