// 创建 GitHub Release v0.1.1 并上传 tgz 附件（token 不落盘不打印）
import { execSync } from 'node:child_process'
import { readFileSync } from 'node:fs'

const input = 'protocol=https\nhost=github.com\n\n'
const out = execSync('git credential fill', { input, encoding: 'utf8' })
const get = (key) => {
  const line = out.split('\n').find((x) => x.startsWith(`${key}=`))
  return line ? line.slice(key.length + 1) : undefined
}
const token = get('password')
const user = get('username')
if (!token || !user) {
  console.error('credential 缺失')
  process.exit(1)
}
const headers = {
  Authorization: `Bearer ${token}`,
  Accept: 'application/vnd.github+json',
  'Content-Type': 'application/json',
  'X-GitHub-Api-Version': '2022-11-28',
}
const REPO = `${user}/dsh-matrix-rain`
const VERSION = '0.1.1'

const body = `## 🟢💧 dsh-matrix-rain — DeepSeek Harness WebUI 矩阵代码雨（思考链驱动）

聊天界面背景「黑客帝国代码雨」动效，**雨字内容 = 当前会话 AI 的思考链**（流式实时，AI 一边思考、雨一边下它的思路）。

### 🆕 v0.1.1 更新

- **窗口缩放同步**：WebUI 窗口尺寸变化后，雨滴列按比例重映射并铺满新视口（拉宽不再右侧空白、收窄不再列跑出屏幕），同时按新尺寸收敛密度

### ✨ 特性

- **思考链即雨字**：流式 reasoning 实时流入雨滴；三种内容模式（原文流 / 乱序投影 / 经典字符）
- **华丽不挡阅读**：雨层 pointer-events 穿透、透明度/背景压暗可调、两侧留白/底部横条雨区
- **设置页完整 DIY**（Host 持久化）：总开关、雨区/密度/速度/字号/文字切换速度/透明度/压暗滑杆、**四色调色盘 + 五套预设主题**、内容模式、活跃模式、鼠标扰动、会话头部快捷开关
- **渐进生效**：改设置不清空已生成的雨滴——旧雨保持原样自然滑落，新设置只作用于之后生成的雨滴
- **性能**：仅思考链变化重建字符池；「仅思考时」模式无内容自动停帧；页面隐藏暂停

### 📦 安装

**方式 A：tgz 直接安装（本 Release 附件）**

\`\`\`bash
# 下载 dsh-matrix-rain-0.1.0.tgz，解压到任意插件目录
# 1. 应用官方包补丁（settings 白名单，自动备份；dsh 升级后需重打）
DSH_INSTALL_DIR=<dsh 安装根> node patches/apply-runtime-patches.mjs

# 2. 把 dsh-matrix-rain 加入 web profile（package.json dependencies link + dsh.profile.bundles）
# 3. 重启 dsh，设置 → 矩阵代码雨
\`\`\`

**方式 B：git clone 安装**

\`\`\`bash
git clone https://github.com/${user}/dsh-matrix-rain.git
cd dsh-matrix-rain
# 其余步骤同方式 A
\`\`\`

### ↩️ 回滚

\`\`\`bash
node patches/apply-runtime-patches.mjs --reverse   # 白名单回滚
# 移除 profile 中的插件条目并重启
\`\`\`

### ✅ 兼容性

- deepseek-harness WebUI（client-modules 插件体系，slots additive 注入，零官方 UI 替换）
- 需要 api-proxy settings 白名单（见 patches/）

### 📄 License

MIT`

// 1. 创建 Release（已存在则复用）
let rel
{
  const existing = await fetch(`https://api.github.com/repos/${REPO}/releases/tags/v${VERSION}`, { headers })
  if (existing.status === 200) {
    rel = await existing.json()
    console.log('release already exists:', rel.html_url)
  } else {
    const release = await fetch(`https://api.github.com/repos/${REPO}/releases`, {
      method: 'POST',
      headers,
      body: JSON.stringify({
        tag_name: `v${VERSION}`,
        name: `v${VERSION}`,
        body,
        draft: false,
        prerelease: false,
      }),
    })
    console.log('create release:', release.status)
    rel = await release.json()
    if (release.status !== 201) {
      console.error(JSON.stringify(rel).slice(0, 500))
      process.exit(1)
    }
    console.log('release url:', rel.html_url)
  }
}

// 2. 上传 tgz 附件（asset 上传走 uploads.github.com）
const tgz = `dsh-matrix-rain-${VERSION}.tgz`
const file = readFileSync(tgz)
const asset = await fetch(`https://uploads.github.com/repos/${REPO}/releases/${rel.id}/assets?name=${tgz}`, {
  method: 'POST',
  headers: {
    Authorization: `Bearer ${token}`,
    Accept: 'application/vnd.github+json',
    'Content-Type': 'application/gzip',
    'X-GitHub-Api-Version': '2022-11-28',
  },
  body: file,
})
console.log('upload asset:', asset.status)
const assetBody = await asset.json().catch(() => ({}))
if (asset.status !== 201) {
  console.error(JSON.stringify(assetBody).slice(0, 400))
  process.exit(1)
}
console.log('asset:', assetBody.name, assetBody.browser_download_url)
