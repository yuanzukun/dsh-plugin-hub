#!/usr/bin/env node
/**
 * dsh-matrix-rain 运行时补丁：把 matrix-rain 加进 host 端 api-proxy 的
 * settings allowlist（WEB_SETTINGS_NAMESPACES），浏览器设置面板才能读写
 * 插件配置。dsh 升级覆盖官方包后需重跑本脚本。
 *
 * 用法：
 *   node patches/apply-runtime-patches.mjs [--reverse]
 *
 * 修改文件（自动备份 .bak-<时间戳>）：
 *   node_modules/@deepseek-ai/dsh/node_modules/@deepseek-ai/dsh-host-apiproxy/lib/index.js
 *
 * 注意：需要重启 dsh 进程后生效。
 */
import { readFileSync, writeFileSync, copyFileSync, existsSync, mkdirSync, statSync } from 'node:fs'
import { dirname, join } from 'node:path'

const reverse = process.argv.includes('--reverse')

// 探测 dsh 安装根：从当前目录向上找 dsh-host-apiproxy 包，或指定 DSH_INSTALL_DIR。
function findUp(start, rel) {
  let dir = start
  for (let depth = 0; depth < 8; depth++) {
    const candidate = join(dir, rel)
    try {
      if (existsSync(candidate) && statSync(candidate).isDirectory()) return candidate
    } catch { /* 继续向上 */ }
    const parent = dirname(dir)
    if (parent === dir) break
    dir = parent
  }
  return undefined
}

const envDir = process.env.DSH_INSTALL_DIR
const candidates = [
  envDir ? join(envDir, 'node_modules/@deepseek-ai/dsh/node_modules/@deepseek-ai/dsh-host-apiproxy/lib') : '',
  findUp(process.cwd(), 'node_modules/@deepseek-ai/dsh/node_modules/@deepseek-ai/dsh-host-apiproxy/lib') || '',
  findUp(process.cwd(), 'node_modules/@deepseek-ai/dsh-host-apiproxy/lib') || '',
].filter(Boolean)
const libDir = candidates.find(dir => existsSync(join(dir, 'index.js')))
if (libDir === undefined) {
  console.error('✗ 未找到 dsh-host-apiproxy 包，请手动修改其 lib/index.js：')
  console.error('  WEB_SETTINGS_NAMESPACES 数组加入 "matrix-rain"')
  process.exit(1)
}

const file = join(libDir, 'index.js')
// 以 webui-perf 行尾为锚点追加 matrix-rain（保留其它插件白名单项）
const marker = '"web-search-deepseek", "webui-perf"'
const withRain = '"web-search-deepseek", "webui-perf", "matrix-rain"'
const stamp = new Date().toISOString().replace(/[:.]/g, '-')
const backupDir = join(libDir, '.matrix-rain-backups')
mkdirSync(backupDir, { recursive: true })

const source = readFileSync(file, 'utf8')
const target = reverse ? source.replaceAll(withRain, marker) : source.replaceAll(marker, withRain)
if (target === source) {
  console.log(reverse ? '- 已回滚' : '- 已包含 matrix-rain，跳过')
  process.exit(0)
}
const backup = join(backupDir, `index.js.bak-${stamp}`)
copyFileSync(file, backup)
writeFileSync(file, target, 'utf8')
console.log(reverse
  ? `✔ 已回滚（备份 ${backup}）`
  : `✔ 补丁完成（备份 ${backup}）。请重启 dsh 进程使 allowlist 生效。`)
