﻿# pilot / _dsh-action.ps1 - one action, executed in whatever process called it.
#
# Extracted from desktop-action.ps1 so the same code serves two callers:
#   * desktop-action.ps1 - one action per process (the fallback path);
#   * desktop-worker.ps1 - many actions in one warm process (the fast path).
#
# Differences from the one-shot script it came from: failures throw
# (Write-ActionError / Assert-Alive used to print JSON and exit, which inside a
# long-lived worker would kill every later request), and the result is returned as
# a hashtable instead of being printed.
$ErrorActionPreference = 'Stop'

# UI Automation: the control tree, for a caller that would rather read a control's
# name and rectangle than guess its pixels. Loaded from here so every entry script
# that dot-sources this file gets it for free.
. (Join-Path $PSScriptRoot '_dsh-uia.ps1')

# Set by Write-ActionError so a caller can forward the structured payload a thrown
# failure carries (cancellation is not just an error message).
$script:ActionStopPayload = $null

# The last controls listing handed out, keyed by element index. A flat listing can
# keep its length while its rows change, so an index that still resolves can still
# point at a different control; this is what lets a click notice that.
$script:UiListing = $null

# Chromium builds its accessibility tree lazily: the first client to ask gets a
# nearly empty answer while the tree is still being constructed. Measured on the
# harness window right after a restart: 3 elements, then 77 a moment later. One
# retry per worker turns that into a correct first answer.
$script:UiWarmed = $false

function Write-ActionError([string] $message) {
    $script:ActionStopPayload = [ordered]@{ ok = $false; error = $message }
    throw [System.Exception]::new($message)
}

function Assert-Alive {
    if (Test-Cancelled) {
        $script:ActionStopPayload = [ordered]@{ ok = $false; cancelled = $true; error = 'the action loop was cancelled before this step' }
        throw [System.Exception]::new('the action loop was cancelled before this step')
    }
}

function Remove-ZeroWidth([string] $text) {
    # Chrome and Edge put U+200B inside their own window titles - the title reads
    # "Microsoft Edge" but the bytes are "Microsoft​ Ed"; a substring search
    # for what a person sees then finds nothing. Strip the invisible ones on both
    # sides of the comparison instead of asking the caller to guess.
    if ([string]::IsNullOrEmpty($text)) { return '' }
    return ($text -replace '[​‌‍⁠﻿]', '')
}

function Get-ProcessNameSafe([uint32] $pidValue) {
    try { return (Get-Process -Id $pidValue -ErrorAction Stop).ProcessName } catch { return $null }
}

function Test-Cancelled {
    if ([string]::IsNullOrEmpty($script:CancelFile)) { return $false }
    if (-not (Test-Path -LiteralPath $script:CancelFile)) { return $false }
    try {
        $content = [System.IO.File]::ReadAllText($script:CancelFile, [System.Text.Encoding]::UTF8)
        return $content.Trim() -eq 'stop'
    } catch {
        return $false
    }
}


# Re-assert the target window as foreground immediately before injecting input.
# Focus can be taken by another process between two steps, and a click or
# keystroke delivered to the wrong window is a real, destructive side effect, so
# this fails loud rather than acting on whatever happens to be in front.
function Assert-TargetFocus {
    if ($script:TargetHwnd -eq [IntPtr]::Zero) { return }
    if (-not [DshInput]::IsAlive($script:TargetHwnd)) {
        Write-ActionError "the target window (hwnd $($script:TargetHwndText)) no longer exists; re-read the screen and target a live window"
    }
    if ([DshInput]::IsForeground($script:TargetHwnd)) { return }
    if ([DshInput]::ForceForeground($script:TargetHwnd)) { return }
    $fg = [DshInput]::ForegroundTitle()
    Write-ActionError "could not bring the target window (hwnd $($script:TargetHwndText)) to the foreground; '$fg' is holding focus, so this action was refused instead of being sent to the wrong window"
}

function Get-Point([object] $x, [object] $y, [string] $what) {
    if ($null -eq $x -or $null -eq $y) { Write-ActionError "$what requires both x and y" }
    $px = 0; $py = 0
    if (-not [int]::TryParse(([string] $x), [ref] $px)) { Write-ActionError "$what x must be an integer (got '$x')" }
    if (-not [int]::TryParse(([string] $y), [ref] $py)) { Write-ActionError "$what y must be an integer (got '$y')" }
    $vx = [DshInput]::GetSystemMetrics(76); $vy = [DshInput]::GetSystemMetrics(77)
    $vw = [DshInput]::GetSystemMetrics(78); $vh = [DshInput]::GetSystemMetrics(79)
    if ($px -lt $vx -or $py -lt $vy -or $px -ge ($vx + $vw) -or $py -ge ($vy + $vh)) {
        Write-ActionError "$what point ($px,$py) is outside the virtual desktop ($vx,$vy,$vw,$vh); screenshots are physical pixels, so re-read the image before acting"
    }
    return @($px, $py)
}

function Invoke-Drag([int] $fromX, [int] $fromY, [int] $toX, [int] $toY, [string] $button) {
    $null = [DshInput]::SetCursorPos($fromX, $fromY)
    Start-Sleep -Milliseconds 90
    Assert-Alive
    [DshInput]::Button($button, $true)
    try {
        $steps = 24
        for ($i = 1; $i -le $steps; $i++) {
            $x = [int] [math]::Round($fromX + (($toX - $fromX) * $i / $steps))
            $y = [int] [math]::Round($fromY + (($toY - $fromY) * $i / $steps))
            $null = [DshInput]::SetCursorPos($x, $y)
            Start-Sleep -Milliseconds 18
            if ($i % 4 -eq 0) { Assert-Alive }
        }
    } finally {
        # Never leave the left button latched down, even on abort.
        [DshInput]::Button($button, $false)
    }
    Start-Sleep -Milliseconds 90
}

function Get-KeySequence([string] $spec) {
    $raw = $spec.Trim()
    if ([string]::IsNullOrEmpty($raw)) { Write-ActionError 'key requires a non-empty value' }
    $parts = @(($raw -split '\+') | Where-Object { $_ -ne '' } | ForEach-Object { $_.Trim() })
    if ($parts.Count -eq 0) { Write-ActionError "key '$spec' has no usable key name" }
    $modifiers = ''
    $base = ''
    foreach ($part in $parts) {
        $lower = $part.ToLowerInvariant()
        if ($lower -eq 'ctrl' -or $lower -eq 'control') { $modifiers += '^'; continue }
        if ($lower -eq 'alt') { $modifiers += '%'; continue }
        if ($lower -eq 'shift') { $modifiers += '+'; continue }
        if (@('win', 'windows', 'cmd', 'meta') -contains $lower) { $modifiers += 'WIN'; continue }
        if (-not [string]::IsNullOrEmpty($base)) { Write-ActionError "key combination '$spec' names both '$base' and '$part'; only one non-modifier key is supported" }
        $base = $part
    }
    if ([string]::IsNullOrEmpty($base) -and [string]::IsNullOrEmpty($modifiers)) { Write-ActionError "key '$spec' has no usable key name" }

    # Named keys become SendKeys tokens; a single literal character passes through.
    $named = @{
        'enter' = 'ENTER'; 'return' = 'ENTER'; 'tab' = 'TAB'; 'esc' = 'ESC'; 'escape' = 'ESC'
        'space' = ' '; 'backspace' = 'BACKSPACE'; 'back' = 'BACKSPACE'; 'delete' = 'DELETE'; 'del' = 'DELETE'
        'home' = 'HOME'; 'end' = 'END'; 'pageup' = 'PGUP'; 'pgup' = 'PGUP'; 'pagedown' = 'PGDN'; 'pgdn' = 'PGDN'
        'up' = 'UP'; 'down' = 'DOWN'; 'left' = 'LEFT'; 'right' = 'RIGHT'; 'insert' = 'INS'; 'ins' = 'INS'
    }
    if (-not [string]::IsNullOrEmpty($base)) {
        $lowerBase = $base.ToLowerInvariant()
        if ($named.ContainsKey($lowerBase)) {
            $base = $named[$lowerBase]
        } elseif ($lowerBase -match '^f([1-9]|1[0-6])$') {
            $base = 'F' + $Matches[1]
        } elseif ($lowerBase -match '^f([0-9]{1,2})$') {
            Write-ActionError "key '$spec' is above F16, which the Windows SendKeys bridge does not implement; use F1..F16"
        } elseif ($base.Length -ne 1) {
            Write-ActionError "key '$spec' names an unknown key '$base'; use a single character or a name such as enter/tab/esc/backspace/delete/home/end/up/down/left/right/pgup/pgdn/f1..f16"
        }
    }
    $encoded = if ($base.Length -eq 0) { '' } elseif ($base.Length -eq 1 -and -not ($base -cmatch '[+^%~()\[\]{}]')) { $base } else { "{$base}" }
    if ($modifiers.Contains('WIN')) {
        $plain = $modifiers.Replace('WIN', '')
        if ($plain.Length -gt 0) { Write-ActionError "key '$spec' mixes the win modifier with other modifiers, which this build does not support" }
        return @{ win = $true; sequence = $encoded }
    }
    return @{ win = $false; sequence = ($modifiers + $encoded) }
}

function Invoke-TextPaste([string] $text) {
    Add-Type -AssemblyName System.Windows.Forms
    $saved = $null
    try { if ([System.Windows.Forms.Clipboard]::ContainsText()) { $saved = [System.Windows.Forms.Clipboard]::GetText() } } catch { $saved = $null }
    try { [System.Windows.Forms.Clipboard]::SetText($text) } catch { Write-ActionError "could not place the text on the clipboard: $($_.Exception.Message)" }
    Start-Sleep -Milliseconds 60
    Assert-Alive
    try { [DshInput]::SendKeysText('^v') } catch { Write-ActionError "the paste keystroke could not be delivered: $($_.Exception.Message)" }
    Start-Sleep -Milliseconds 120
    if ($null -ne $saved) {
        try { [System.Windows.Forms.Clipboard]::SetText($saved) } catch { }
    }
}

<#
Execute one action. $Config is the request object the callers already build
(action, x, y, toX, toY, amount, text, key, title, button, hwnd, cancelFile,
settleMs). Returns the same shape the one-shot script used to print.
#>
function Find-DshWindowHandle([string] $needle) {
    # Foreground wins, otherwise the first visible match: the same rule focus uses,
    # so a title means the same window to every action that takes one.
    $lower = (Remove-ZeroWidth $needle).ToLowerInvariant()
    $fallback = [IntPtr]::Zero
    foreach ($handle in [DshInput]::TopLevelWindows()) {
        if (-not [DshInput]::IsWindowVisible($handle)) { continue }
        $title = [DshInput]::WindowTitle($handle)
        if ($title.Length -eq 0) { continue }
        $owner = [uint32] 0
        $null = [DshInput]::GetWindowThreadProcessId($handle, [ref] $owner)
        $processName = Get-ProcessNameSafe $owner
        $hit = (Remove-ZeroWidth $title).ToLowerInvariant().Contains($lower)
        if (-not $hit -and $null -ne $processName) { $hit = $processName.ToLowerInvariant().Contains($lower) }
        if (-not $hit) { continue }
        if ([DshInput]::IsForeground($handle)) { return $handle }
        if ($fallback -eq [IntPtr]::Zero) { $fallback = $handle }
    }
    return $fallback
}

function Get-DshTargetPoint([string] $indexText, [IntPtr] $hwnd, [string] $title) {
    # An index addresses a node only against the listing it came from. Resolving it
    # again is what turns 'the button I saw' into 'the button that is there now',
    # and an index that no longer resolves fails instead of clicking its successor.
    $index = 0
    if (-not [int]::TryParse($indexText, [ref] $index)) { Write-ActionError ('target must be the index of a control listed by ''controls'', got ''{0}''' -f $indexText) }
    $handle = $hwnd
    if ($handle -eq [IntPtr]::Zero) {
        if ([string]::IsNullOrWhiteSpace($title)) { Write-ActionError ('target {0} needs a window: pass title or hwnd with it' -f $index) }
        $handle = Find-DshWindowHandle $title
        if ($handle -eq [IntPtr]::Zero) { Write-ActionError ('target {0} needs a window: no visible top-level window matches ''{1}''' -f $index, $title) }
    }
    $element = Resolve-DshUiaIndex -Handle $handle -Index $index
    if ($null -eq $element) { Write-ActionError ('the tree changed: index {0} is past the end of the listing for ''{1}''. Read controls again.' -f $index, [DshInput]::WindowTitle($handle)) }
    if ($null -ne $script:UiListing -and $script:UiListing.handle -eq [long] $handle -and $script:UiListing.items.ContainsKey($index)) {
        # Compare identity, not just existence: a reorder keeps the index valid.
        $gotRole = ''
        $gotName = ''
        try {
            $gotRole = $element.Current.ControlType.ProgrammaticName -replace 'ControlType\.', ''
            $gotName = [string] $element.Current.Name
        } catch { }
        $want = $script:UiListing.items[$index]
        if ($gotRole -ne $want.role -or $gotName -ne $want.name) {
            Write-ActionError ('the control at index {0} is not the one that was listed: expected [{1}] ''{2}'', found [{3}] ''{4}''. Read controls again.' -f $index, $want.role, $want.name, $gotRole, $gotName)
        }
    }
    $centre = Get-DshUiaCentre -Element $element
    if ($null -eq $centre) { Write-ActionError ('the control at index {0} has no on-screen rectangle - it may be scrolled out of view or collapsed' -f $index) }
    return @($centre.x, $centre.y)
}

function Invoke-DshAction {
    param([object] $Config)

    function Get-Param([string] $key) {
        if ($null -ne $Config -and $Config.PSObject.Properties.Name -contains $key) { return $Config.$key }
        return $null
    }

    # x/y, or the centre of the control a target path addresses. One entry point so
    # every pointer action accepts both spellings without repeating the branch.
    function Get-AnchoredPoint([string] $what) {
        $targetPath = [string] (Get-Param 'target')
        if (-not [string]::IsNullOrWhiteSpace($targetPath)) {
            return Get-DshTargetPoint $targetPath $script:TargetHwnd $windowTitle
        }
        return Get-Point (Get-Param 'x') (Get-Param 'y') $what
    }

    $script:CancelFile = [string] (Get-Param 'cancelFile')

    # Optional target window. When present, every input action re-asserts it as the
    # foreground window immediately before injecting, so a click or keystroke can
    # never land in whatever window happens to be in front instead.
    $script:TargetHwnd = [IntPtr]::Zero
    $script:TargetHwndText = ''
    $hwndRaw = [string] (Get-Param 'hwnd')
    if (-not [string]::IsNullOrWhiteSpace($hwndRaw)) {
        $parsed = [long] 0
        $text = $hwndRaw.Trim()
        $ok = $false
        if ($text -match '^0[xX]([0-9a-fA-F]+)$') { $ok = [long]::TryParse($Matches[1], [System.Globalization.NumberStyles]::HexNumber, [System.Globalization.CultureInfo]::InvariantCulture, [ref] $parsed) }
        else { $ok = [long]::TryParse($text, [ref] $parsed) }
        if (-not $ok -or $parsed -eq 0) { Write-ActionError "hwnd must be a nonzero window handle such as 0x1094C (got '$hwndRaw')" }
        $script:TargetHwnd = [IntPtr] $parsed
        $script:TargetHwndText = $text
    }

    $action = [string] (Get-Param 'action')
    if ([string]::IsNullOrWhiteSpace($action)) { Write-ActionError 'action is required' }
    $action = $action.Trim()

    $buttonRaw = [string] (Get-Param 'button')
    $button = if ([string]::IsNullOrWhiteSpace($buttonRaw)) { 'left' } else { $buttonRaw.Trim().ToLowerInvariant() }
    if (@('left', 'right', 'middle') -notcontains $button) { Write-ActionError "button must be left, right, or middle (got '$button')" }

    $windowTitle = [string] (Get-Param 'title')
    if ($null -eq $windowTitle) { $windowTitle = '' }

    $notes = @()
    Assert-Alive

switch ($action) {
    'click' {
        $point = Get-AnchoredPoint 'click'
        $null = [DshInput]::SetCursorPos($point[0], $point[1])
        Start-Sleep -Milliseconds 80
        Assert-Alive
        Assert-TargetFocus
        [DshInput]::Button($button, $true)
        Start-Sleep -Milliseconds 45
        [DshInput]::Button($button, $false)
    }
    'doubleClick' {
        $point = Get-AnchoredPoint 'doubleClick'
        $null = [DshInput]::SetCursorPos($point[0], $point[1])
        Start-Sleep -Milliseconds 80
        Assert-Alive
        Assert-TargetFocus
        [DshInput]::Button($button, $true); Start-Sleep -Milliseconds 40; [DshInput]::Button($button, $false)
        Start-Sleep -Milliseconds 70
        Assert-Alive
        Assert-TargetFocus
        [DshInput]::Button($button, $true); Start-Sleep -Milliseconds 40; [DshInput]::Button($button, $false)
    }
    'rightClick' {
        $point = Get-AnchoredPoint 'rightClick'
        $null = [DshInput]::SetCursorPos($point[0], $point[1])
        Start-Sleep -Milliseconds 80
        Assert-Alive
        Assert-TargetFocus
        [DshInput]::Button('right', $true)
        Start-Sleep -Milliseconds 45
        [DshInput]::Button('right', $false)
    }
    'middleClick' {
        $point = Get-AnchoredPoint 'middleClick'
        $null = [DshInput]::SetCursorPos($point[0], $point[1])
        Start-Sleep -Milliseconds 80
        Assert-Alive
        Assert-TargetFocus
        [DshInput]::Button('middle', $true)
        Start-Sleep -Milliseconds 45
        [DshInput]::Button('middle', $false)
    }
    'move' {
        $point = Get-AnchoredPoint 'move'
        $null = [DshInput]::SetCursorPos($point[0], $point[1])
        # The move is queued, so an immediate read can still return the previous
        # position; wait (bounded) until the pointer is where the caller asked.
        $moveDeadline = [DateTime]::UtcNow.AddMilliseconds(200)
        while ([DateTime]::UtcNow -lt $moveDeadline) {
            $reached = [DshInput]::Cursor()
            if ($reached.X -eq $point[0] -and $reached.Y -eq $point[1]) { break }
            Start-Sleep -Milliseconds 10
        }
    }
    'drag' {
        $from = Get-Point (Get-Param 'x') (Get-Param 'y') 'drag'
        $to = Get-Point (Get-Param 'toX') (Get-Param 'toY') 'drag'
        Assert-TargetFocus
        Invoke-Drag $from[0] $from[1] $to[0] $to[1] $button
    }
    'scroll' {
        $amountRaw = Get-Param 'amount'
        $amount = 3
        if ($null -ne $amountRaw) {
            if (-not [int]::TryParse(([string] $amountRaw), [ref] $amount)) { Write-ActionError "amount must be an integer (got '$amountRaw')" }
        }
        if ($amount -eq 0) { Write-ActionError 'amount must not be zero' }
        $hasPoint = ($null -ne (Get-Param 'x')) -and ($null -ne (Get-Param 'y'))
        if ($hasPoint) {
            $point = Get-Point (Get-Param 'x') (Get-Param 'y') 'scroll'
            $null = [DshInput]::SetCursorPos($point[0], $point[1])
            Start-Sleep -Milliseconds 60
        }
        Assert-Alive
        Assert-TargetFocus
        $horizontal = ($null -ne (Get-Param 'toX')) -or ($null -ne (Get-Param 'toY'))
        if ($horizontal) {
            [DshInput]::HWheel($amount * 120)
        } else {
            [DshInput]::Wheel($amount * 120)
        }
    }
    'type' {
        $text = [string] (Get-Param 'text')
        if ([string]::IsNullOrEmpty($text)) { Write-ActionError 'type requires non-empty text' }
        Assert-TargetFocus
        Invoke-TextPaste $text
        $notes += 'The text was delivered as one paste, so the target saw no individual keystrokes.'
    }
    'key' {
        $keySpec = [string] (Get-Param 'key')
        if ([string]::IsNullOrWhiteSpace($keySpec)) { Write-ActionError 'key requires a value such as enter, tab, esc, ctrl+s, alt+tab' }
        $sequence = Get-KeySequence $keySpec
        Assert-TargetFocus
        if ($sequence.win) {
            [DshInput]::WinKey($true)
            Start-Sleep -Milliseconds 60
            try { [DshInput]::SendKeysText($sequence.sequence) }
            catch { Write-ActionError "the keystroke '$keySpec' could not be delivered: $($_.Exception.Message)" }
            finally { [DshInput]::WinKey($false) }
        } else {
            try { [DshInput]::SendKeysText($sequence.sequence) }
            catch { Write-ActionError "the keystroke '$keySpec' could not be delivered: $($_.Exception.Message)" }
        }
    }
    'controls' {
        # Read the window's UI Automation tree and return it as text. This is the
        # cheap half of seeing: a control's name and rectangle, no frame, no pixels.
        # It returns its own result and returns early so it never pays the settle
        # or the capture - the whole point is that no screenshot is needed.
        $treeHandle = $script:TargetHwnd
        if ($treeHandle -eq [IntPtr]::Zero) {
            if ([string]::IsNullOrWhiteSpace($windowTitle)) { Write-ActionError 'controls requires a title, or an hwnd' }
            $treeHandle = Find-DshWindowHandle $windowTitle
            if ($treeHandle -eq [IntPtr]::Zero) { Write-ActionError ('no visible top-level window matches ''{0}''; pass an hwnd if the window is hidden to the tray' -f $windowTitle) }
        }
        $includeValues = $false
        $ivRaw = Get-Param 'includeValues'
        if ($null -ne $ivRaw) { $includeValues = [bool] $ivRaw }
        $meaningfulOnly = $true
        $moRaw = Get-Param 'meaningfulOnly'
        if ($null -ne $moRaw) { $meaningfulOnly = [bool] $moRaw }
        $tree = Get-DshUiaNodes -Handle $treeHandle -IncludeValues $includeValues -MeaningfulOnly $meaningfulOnly
        if (-not $script:UiWarmed -and $tree.total -lt 8) {
            # A window that really has fewer than eight elements pays one extra read
            # once per worker; a cold Electron window is the case this exists for.
            Start-Sleep -Milliseconds 300
            $tree = Get-DshUiaNodes -Handle $treeHandle -IncludeValues $includeValues -MeaningfulOnly $meaningfulOnly
        }
        if ($tree.total -ge 8) { $script:UiWarmed = $true }
        if (-not $tree.ok) { Write-ActionError $tree.error }
        $items = @{}
        foreach ($n in $tree.nodes) { $items[[int] $n.index] = @{ role = [string] $n.role; name = [string] $n.name } }
        $script:UiListing = @{ handle = [long] $treeHandle; items = $items }
        $lines = Format-DshUiaNodes -Nodes $tree.nodes -Truncated $tree.truncated
        if ($meaningfulOnly -and $tree.nodes.Count -eq 0) {
            # An empty list would read as 'this window has no tree', which is the one
            # wrong conclusion to leave a caller with: say what is actually there.
            $full = Get-DshUiaNodes -Handle $treeHandle -MeaningfulOnly $false
            if ($full.nodes.Count -gt 0) {
                $lines = @(('(no operable controls here; the window has {0} elements - pass meaningfulOnly:false to see them)' -f $full.nodes.Count))
            }
        }
        $treeCursor = [DshInput]::Cursor()
        $result = [ordered]@{
            ok                = $true
            action            = 'controls'
            cursor            = [ordered]@{ x = $treeCursor.X; y = $treeCursor.Y }
            foregroundTitle   = [DshInput]::ForegroundTitle()
            foregroundClass   = [DshInput]::ForegroundClass()
            foregroundProcess = Get-ProcessNameSafe ([uint32] [DshInput]::ForegroundPid())
            controls          = $lines
            controlCount      = $tree.nodes.Count
            # What the filter looked at and what it threw away, so an empty list can
            # never be mistaken for a window that has nothing in it.
            controlTotal      = [int] $tree.total
            filteredOut       = [int] $tree.dropped
            controlsTruncated = [bool] $tree.truncated
            controlsWindow    = [DshInput]::WindowTitle($treeHandle)
            notes             = $notes
            actedAt           = [DateTimeOffset]::Now.ToString('o')
        }
        return $result
    }
    'focus' {        # A refused hand-off used to be a note: the step reported ok and the batch
        # carried on, so every later click and keystroke went to whatever window was
        # actually in front. That is the one failure this plugin must not report as
        # success, so it is an error now; tolerant keeps the old behaviour for a
        # caller that knows the coordinates are right either way.
        $tolerant = $false
        $tolerantRaw = Get-Param 'tolerant'
        if ($null -ne $tolerantRaw) { $tolerant = [bool] $tolerantRaw }
        $label = ''
        $target = [IntPtr]::Zero
        if ($script:TargetHwnd -ne [IntPtr]::Zero) {
            # An explicit handle is authoritative and works for a window hidden
            # to the tray, which a title search cannot reach.
            if (-not [DshInput]::IsAlive($script:TargetHwnd)) { Write-ActionError "the target window (hwnd $($script:TargetHwndText)) no longer exists" }
            $target = $script:TargetHwnd
            $label = "hwnd $($script:TargetHwndText)"
            $null = [DshInput]::ForceForeground($target)
            Start-Sleep -Milliseconds 220
        } else {
            if ([string]::IsNullOrWhiteSpace($windowTitle)) { Write-ActionError 'focus requires a title, or an hwnd' }
            $needle = (Remove-ZeroWidth $windowTitle).ToLowerInvariant()
            # EnumWindows, not Process.MainWindowHandle: an Electron, UWP or tray
            # window frequently reports no main window handle at all, so a
            # MainWindowHandle scan cannot find a window that the windows action
            # (which already enumerates) happily lists.
            $fallback = [IntPtr]::Zero
            foreach ($handle in [DshInput]::TopLevelWindows()) {
                if (-not [DshInput]::IsWindowVisible($handle)) { continue }
                $title = [DshInput]::WindowTitle($handle)
                if ($title.Length -eq 0) { continue }
                $owner = [uint32] 0
                $null = [DshInput]::GetWindowThreadProcessId($handle, [ref] $owner)
                $processName = Get-ProcessNameSafe $owner
                $hit = (Remove-ZeroWidth $title).ToLowerInvariant().Contains($needle)
                if (-not $hit -and $null -ne $processName) { $hit = $processName.ToLowerInvariant().Contains($needle) }
                if (-not $hit) { continue }
                if ([DshInput]::IsForeground($handle)) { $target = $handle; break }
                if ($fallback -eq [IntPtr]::Zero) { $fallback = $handle }
            }
            if ($target -eq [IntPtr]::Zero) { $target = $fallback }
            if ($target -eq [IntPtr]::Zero) { Write-ActionError "no visible top-level window matches '$windowTitle'; pass an hwnd if the window is hidden to the tray" }
            $label = "'" + [DshInput]::WindowTitle($target) + "'"
            $null = [DshInput]::Activate($target)
            Start-Sleep -Milliseconds 220
        }

        # Ask the desktop, not the API. SetForegroundWindow is documented to be
        # unreliable about its return value, and the state that decides where the
        # next click lands is the foreground window, not what the call returned.
        if (-not [DshInput]::IsForeground($target)) {
            $holder = [DshInput]::ForegroundTitle()
            if ($tolerant) {
                $notes += "Windows would not hand focus to $label; '$holder' kept it (tolerant: continuing)."
            } else {
                Write-ActionError "could not bring $label to the foreground; '$holder' still holds it, so the rest of this batch would land there. Pass tolerant: true on this step if the coordinates are right either way."
            }
        }
    }
    'windows' {
        $query = $windowTitle.ToLowerInvariant()
        $list = @()
        foreach ($handle in [DshInput]::TopLevelWindows()) {
            $title = [DshInput]::WindowTitle($handle)
            if ($title.Length -eq 0) { continue }
            $owner = [uint32] 0
            $null = [DshInput]::GetWindowThreadProcessId($handle, [ref] $owner)
            $processName = Get-ProcessNameSafe $owner
            if ([string]::IsNullOrEmpty($query) -eq $false) {
                $inTitle = $title.ToLowerInvariant().Contains($query)
                $inProcess = ($null -ne $processName) -and $processName.ToLowerInvariant().Contains($query)
                if (-not ($inTitle -or $inProcess)) { continue }
            }
            $rect = [DshInput]::WindowRect($handle)
            $list += [ordered]@{
                handle     = ('0x{0:X}' -f $handle.ToInt64())
                title      = $title
                process    = $processName
                pid        = [int] $owner
                bounds     = ('{0},{1},{2},{3}' -f $rect.Left, $rect.Top, ($rect.Right - $rect.Left), ($rect.Bottom - $rect.Top))
                minimized  = [bool] [DshInput]::IsIconic($handle)
                visible    = [bool] [DshInput]::IsWindowVisible($handle)
                foreground = [bool] [DshInput]::IsForeground($handle)
            }
        }
        $foreground = $list | Where-Object { $_.foreground } | Select-Object -First 1
        $result = [ordered]@{
            ok               = $true
            action           = 'windows'
            windows          = $list
            windowCount      = $list.Count
            foregroundWindow = $foreground
            foregroundTitle  = [DshInput]::ForegroundTitle()
            cursor           = [ordered]@{ x = ([DshInput]::Cursor()).X; y = ([DshInput]::Cursor()).Y }
            notes            = @()
            actedAt          = [DateTimeOffset]::Now.ToString('o')
        }
        return $result
    }
    default {
        Write-ActionError "unknown action '$action' (use click, doubleClick, rightClick, middleClick, move, drag, scroll, type, key, focus, or windows)"
    }
}

# ------------------------------------------------------------------ settle + report
$settleRaw = Get-Param 'settleMs'
$settle = 750
if ($null -ne $settleRaw) {
    if (-not [int]::TryParse(([string] $settleRaw), [ref] $settle)) { Write-ActionError "settleMs must be an integer (got '$settleRaw')" }
}
if ($settle -lt 0) { $settle = 0 }
if ($settle -gt 0) {
    $remaining = $settle
    while ($remaining -gt 0) {
        Assert-Alive
        $slice = [math]::Min(120, $remaining)
        Start-Sleep -Milliseconds $slice
        $remaining -= $slice
    }
}

$cursor = [DshInput]::Cursor()
$result = [ordered]@{
    ok               = $true
    action           = $action
    cursor           = [ordered]@{ x = $cursor.X; y = $cursor.Y }
    foregroundTitle  = [DshInput]::ForegroundTitle()
    foregroundClass  = [DshInput]::ForegroundClass()
    foregroundProcess = Get-ProcessNameSafe ([uint32] [DshInput]::ForegroundPid())
    notes            = $notes
    actedAt          = [DateTimeOffset]::Now.ToString('o')
}
    return $result
}