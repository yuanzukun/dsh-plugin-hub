import assert from 'node:assert/strict'
import { chmod, cp, lstat, mkdtemp, readFile, realpath, rm, writeFile } from 'node:fs/promises'
import { watch } from 'node:fs'
import { createRequire } from 'node:module'
import { tmpdir } from 'node:os'
import { join, resolve } from 'node:path'
import { fileURLToPath, pathToFileURL } from 'node:url'
import { doctorSource } from '../../lib/doctor.js'

const toolsRoot = process.env.DSH_DEVELOPER_JOURNEY_TOOLS_ROOT
const dshPath = process.env.DSH_DEVELOPER_JOURNEY_DSH
const expectedVersion = process.env.DSH_DEVELOPER_JOURNEY_EXPECTED_VERSION
const lane = process.env.DSH_DEVELOPER_JOURNEY_LANE
assert.ok(toolsRoot, 'DSH_DEVELOPER_JOURNEY_TOOLS_ROOT is required')
assert.ok(dshPath, 'DSH_DEVELOPER_JOURNEY_DSH is required')
assert.ok(expectedVersion, 'DSH_DEVELOPER_JOURNEY_EXPECTED_VERSION is required')
assert.ok(lane, 'DSH_DEVELOPER_JOURNEY_LANE is required')

const requireFromLane = createRequire(join(toolsRoot, 'package.json'))
const importFromLane = async (name) => import(pathToFileURL(requireFromLane.resolve(name)).href)
const [{ Context }, { default: SystemPrompt }, { default: ToolRuntime }, { AgentRegistry }] = await Promise.all([
  importFromLane('@deepseek-ai/cordis'),
  importFromLane('@deepseek-ai/dsh-system-prompt'),
  importFromLane('@deepseek-ai/dsh-tools'),
  importFromLane('@deepseek-ai/dsh-agent'),
])
assert.equal(requireFromLane(join(toolsRoot, 'package.json')).version, expectedVersion)

const temporaryRoot = await realpath(tmpdir())
const sourceParent = await mkdtemp(join(temporaryRoot, 'dsh-developer-native-journey-source-'))
const source = join(sourceParent, 'ordinary-dsh-plugin')
const realProfile = await mkdtemp(join(temporaryRoot, 'dsh-developer-native-journey-profile-'))
await cp(fileURLToPath(new URL('./ordinary-dsh-plugin/', import.meta.url)), source, { recursive: true })
process.env.DSH_HOME = realProfile
process.argv[1] = resolve(dshPath)

const ctx = new Context()
let detachAgent
let firstDigest
let retainedRoot
let expectedRecovery
let callSequence = 0
const approvals = []
let approvalMode = 'allowed-once'
let deferredApproval

function registryStub() {
  return {
    register() { return () => {} },
    get() { return undefined },
  }
}

function execute(agent, argumentsValue, signal = new AbortController().signal) {
  return ctx.tools.execute({
    callId: lane + '-native-cell-' + (++callSequence),
    name: 'dsh_developer',
    arguments: argumentsValue,
    agent,
    signal,
  })
}

async function assertSuccessful(result, operation) {
  assert.equal(result.isError, false, operation + ': ' + result.content?.map((item) => item.text ?? '').join('\n'))
  assert.equal(result.value.operation, operation)
  return result.value.report
}

try {
  await ctx.plugin(SystemPrompt)
  await ctx.plugin(ToolRuntime)
  const agents = new AgentRegistry(ctx)
  ctx.provide('skills', registryStub())
  ctx.provide('commands', registryStub())
  ctx.provide('shellEnv', registryStub())
  ctx.provide('approval', {
    request(request) {
      approvals.push(request)
      if (deferredApproval !== undefined) return deferredApproval.promise
      return Promise.resolve(approvalMode)
    },
  })
  const plugin = await import(pathToFileURL(fileURLToPath(new URL('../../index.js', import.meta.url))).href)
  await ctx.plugin(plugin)

  const agentCtx = ctx.extend()
  const sessionId = lane + '-native-cell-root'
  const agent = {
    id: sessionId,
    options: {},
    session: {
      id: sessionId,
      header: { id: sessionId, cwd: source, origin: 'user', delegationDepth: 0 },
    },
    inbox: {},
    status: 'idle',
    ctx: agentCtx,
    cancel() {},
    async whenIdle() {},
  }
  Object.defineProperty(agentCtx, 'agent', { value: agent, configurable: true })
  detachAgent = agents.enter(agent, undefined)
  assert.equal(ctx.agents.roots().includes(agent), true)

  const profileBefore = await doctorSource(realProfile, { runtime: 'skip' })
  const plan = await assertSuccessful(await execute(agent, {
    operation: 'cell-plan',
    outcome: 'Create one harmless staged proof file through the exact native isolated Build journey',
    commands: [{ command: 'printf after > proof.txt', timeoutMs: 60_000 }],
  }), 'cell-plan')
  firstDigest = plan.planDigest
  assert.equal(plan.source.path, resolve(source))
  assert.equal(plan.source.unchanged, true)
  assert.equal(plan.runtime.version, expectedVersion)
  assert.equal(plan.approval.granted, false)

  for (const denied of ['rejected', 'allowed-always', 'cancelled']) {
    approvalMode = denied
    const result = await execute(agent, { operation: 'cell-run', planDigest: firstDigest })
    assert.equal(result.isError, true, denied + ' must not dispatch the native handler')
    await assert.rejects(lstat(join(source, 'proof.txt')), (cause) => cause.code === 'ENOENT')
  }

  deferredApproval = Promise.withResolvers()
  const cancellation = new AbortController()
  const cancelledRun = execute(agent, { operation: 'cell-run', planDigest: firstDigest }, cancellation.signal)
  while (approvals.at(-1)?.callId !== lane + '-native-cell-' + callSequence) {
    await new Promise((resolvePromise) => setImmediate(resolvePromise))
  }
  cancellation.abort('native journey approval cancelled')
  deferredApproval.resolve('allowed-once')
  const cancelledResult = await cancelledRun
  deferredApproval = undefined
  assert.equal(cancelledResult.isError, true)
  await assert.rejects(lstat(join(source, 'proof.txt')), (cause) => cause.code === 'ENOENT')

  approvalMode = 'allowed-once'
  const run = await assertSuccessful(await execute(agent, {
    operation: 'cell-run',
    planDigest: firstDigest,
  }), 'cell-run')
  retainedRoot = run.staging.root
  assert.equal(run.ok, true)
  assert.equal(run.source.unchanged, true)
  assert.equal(run.source.fingerprintBefore, plan.source.fingerprint)
  assert.equal(run.source.fingerprintAfter, plan.source.fingerprint)
  assert.deepEqual(run.staging.changedPaths, { created: ['proof.txt'], modified: [], deleted: [] })
  assert.equal(run.commands.length, 1)
  assert.equal(run.commands[0].exitCode, 0)
  assert.equal(run.commands[0].cleanup.remaining, 0)
  assert.equal(run.cleanup.cellDisposed, true)
  assert.equal(await readFile(join(run.staging.path, 'proof.txt'), 'utf8'), 'after')
  await assert.rejects(lstat(join(source, 'proof.txt')), (cause) => cause.code === 'ENOENT')

  const approval = approvals.at(-1)
  assert.equal(approvalMode, 'allowed-once')
  assert.equal(approval.agent, agent)
  assert.equal(approval.toolName, 'dsh_developer')
  for (const evidence of [
    firstDigest,
    resolve(source),
    plan.source.fingerprint,
    expectedVersion,
    'printf after > proof.txt',
    'isolated copy only',
    'network',
    'credentials',
  ]) assert.match(approval.reason, new RegExp(evidence.replace(/[.*+?^${}()|[\]\\]/gu, '\\$&'), 'u'))

  const stagedDoctor = await assertSuccessful(await execute(agent, {
    operation: 'doctor',
    source: run.staging.path,
    skipRuntime: true,
  }), 'doctor')
  assert.equal(stagedDoctor.ok, true)
  assert.equal(stagedDoctor.fingerprint, run.staging.fingerprint)

  const applied = await assertSuccessful(await execute(agent, {
    operation: 'cell-apply',
    planDigest: firstDigest,
  }), 'cell-apply')
  assert.equal(applied.ok, true, JSON.stringify(applied, null, 2))
  assert.equal(applied.source.fingerprintBefore, plan.source.fingerprint)
  assert.equal(applied.source.fingerprintAfter, run.staging.fingerprint)
  assert.equal(applied.cleanup.backupRemoved, true)
  assert.equal(applied.cleanup.stageRemoved, true)
  assert.equal(applied.cleanup.capacityReleased, true)
  assert.equal(await readFile(join(source, 'proof.txt'), 'utf8'), 'after')
  const applyApproval = approvals.at(-1)
  for (const evidence of [
    firstDigest,
    plan.source.fingerprint,
    run.staging.fingerprint,
    'created: proof.txt',
    'backup/transaction',
    'Real profile effect: none',
  ]) assert.match(applyApproval.reason, new RegExp(evidence.replace(/[.*+?^${}()|[\]\\]/gu, '\\$&'), 'u'))
  await assert.rejects(lstat(retainedRoot), (cause) => cause.code === 'ENOENT')
  retainedRoot = undefined

  const repeated = await assertSuccessful(await execute(agent, {
    operation: 'cell-discard',
    planDigest: firstDigest,
  }), 'cell-discard')
  assert.equal(repeated.alreadyApplied, true)
  assert.equal(repeated.cleanup.capacityReleased, true)

  const second = await assertSuccessful(await execute(agent, {
    operation: 'cell-plan',
    outcome: 'Preserve a concurrent source edit and retain recovery after failed verification',
    commands: [{ command: 'printf rollback > rollback.txt', timeoutMs: 60_000 }],
  }), 'cell-plan')
  const secondRun = await assertSuccessful(await execute(agent, {
    operation: 'cell-run',
    planDigest: second.planDigest,
  }), 'cell-run')
  assert.equal(secondRun.ok, true)
  retainedRoot = secondRun.staging.root
  const originalPackage = await readFile(join(source, 'package.json'), 'utf8')
  let tampered = false
  const sourceWatcher = watch(source, { persistent: false }, (_event, filename) => {
    if (tampered || filename?.toString() !== 'rollback.txt') return
    tampered = true
    void writeFile(join(source, 'package.json'), '{ invalid rollback probe', 'utf8')
  })
  const rolledBack = await assertSuccessful(await execute(agent, {
    operation: 'cell-apply',
    planDigest: second.planDigest,
  }), 'cell-apply')
  sourceWatcher.close()
  assert.equal(tampered, true)
  assert.equal(rolledBack.ok, false)
  assert.equal(rolledBack.rollback.required, true)
  assert.equal(rolledBack.rollback.verified, false)
  assert.equal(rolledBack.failure.code, 'CELL_APPLY_ROLLBACK_FAILED')
  assert.equal(rolledBack.cleanup.capacityReleased, false)
  assert.equal(await readFile(join(source, 'package.json'), 'utf8'), '{ invalid rollback probe')
  const transactionRoot = rolledBack.cleanup.retainedRoot
  assert.equal(await readFile(join(transactionRoot, 'backup', 'package.json'), 'utf8'), originalPackage)
  await assert.rejects(lstat(join(source, 'rollback.txt')), (cause) => cause.code === 'ENOENT')
  const secondDiscard = await execute(agent, {
    operation: 'cell-discard',
    planDigest: second.planDigest,
  })
  assert.equal(secondDiscard.value.ok, false)
  assert.equal(secondDiscard.value.report.diagnostic.code, 'CELL_APPLY_RECOVERY_REQUIRED')
  assert.equal((await lstat(transactionRoot)).isDirectory(), true)
  assert.equal((await lstat(retainedRoot)).isDirectory(), true)
  expectedRecovery = { transactionRoot, stageRoot: retainedRoot }

  const profileAfter = await doctorSource(realProfile, { runtime: 'skip' })
  assert.equal(profileAfter.fingerprint, profileBefore.fingerprint)
  process.stdout.write(JSON.stringify({
    ok: true,
    lane,
    version: expectedVersion,
    planDigest: firstDigest,
    sourceFingerprint: plan.source.fingerprint,
    stagedFingerprint: run.staging.fingerprint,
    approvalRequests: approvals.length,
    sourceUnchanged: true,
    remainingProcesses: run.commands[0].cleanup.remaining,
    cleanupVerified: true,
    applyVerified: true,
    concurrentEditPreserved: true,
    recoveryRetained: true,
    secondPlan: true,
  }) + '\n')
} finally {
  detachAgent?.()
  try {
    await ctx.fiber.dispose()
  } catch (cause) {
    if (expectedRecovery === undefined && retainedRoot !== undefined) {
      process.stderr.write('BLOCKER retained controller root: ' + retainedRoot + '\n')
    }
    if (expectedRecovery === undefined) throw cause
  }
  if (expectedRecovery !== undefined) {
    // These are known, disposable test artifacts. Product cleanup must retain
    // both recovery trees and the concurrent edit; only the test removes them.
    assert.equal((await lstat(expectedRecovery.transactionRoot)).isDirectory(), true)
    assert.equal((await lstat(expectedRecovery.stageRoot)).isDirectory(), true)
    assert.equal(await readFile(join(source, 'package.json'), 'utf8'), '{ invalid rollback probe')
    await chmod(expectedRecovery.stageRoot, 0o700)
    await rm(expectedRecovery.stageRoot, { recursive: true, force: true })
    retainedRoot = undefined
  }
  if (retainedRoot !== undefined) {
    const retained = await lstat(retainedRoot).then(() => true, (cause) => {
      if (cause?.code === 'ENOENT') return false
      throw cause
    })
    if (!retained) retainedRoot = undefined
  }
  if (retainedRoot !== undefined) {
    process.stderr.write('BLOCKER retained controller root: ' + retainedRoot + '\n')
    process.exitCode = 1
  } else {
    await rm(sourceParent, { recursive: true, force: true })
    await rm(realProfile, { recursive: true, force: true })
  }
}
