/**
 * dshw kanban — browser half.
 *
 * Registers the kanban dashboard as a `sidebar.footer.action` entry (the
 * sidebar foot, above Settings) and opens it in a panel spanning everything
 * right of the sidebar. The Pull requests view renders natively (no iframe),
 * talking to the local dshw daemon API (CORS-enabled) over fetch + SSE; the
 * remaining dshw views stay reachable via the panel's open-in-browser action.
 *
 * The daemon origin defaults to the dshw loopback port (7849) and can be
 * overridden per browser via localStorage (set in the panel's unreachable
 * state). Reachability is probed with a no-cors fetch, which rejects on
 * network failure without needing CORS headers from the daemon.
 */
import { useEffect, useRef, useState } from 'react'
import type { CSSProperties, ReactNode } from 'react'
import { createPortal } from 'react-dom'
import {
  IconBranchOutline16, IconCloseOutline16, IconRefreshOutline16, Tooltip,
} from '@deepseek-ai/dsh-client-ui-primitives'
import { GVsCode } from './icons.tsx'
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client'
import { en, zh } from './locales.ts'
import { KanbanWorkspace } from './workspace.tsx'

/** Locale namespace owned by this plugin. */
const NS = 'kanban'

/** dshw daemon default origin (src/config.ts PORT default 7849, loopback). */
const DEFAULT_BASE_URL = 'http://127.0.0.1:7849'
/** localStorage key holding a user-supplied dshw origin override. */
const URL_STORAGE_KEY = 'dshw.kanban.baseUrl'
/** Unique style-tag id so repeated mounts (HMR) never duplicate rules. */
const STYLE_ID = 'dshw-kanban-styles'

/** Static rules for hover/selected states and the scoped isolation reset.
 *  The harness page has no global box-sizing reset and its plugin sheets can
 *  leak into this panel, so every dshw surface (dashboard root, hover
 *  popovers, dialogs — all marked `data-dshw-kanban="root"`) re-establishes a
 *  baseline: border-box sizing, zeroed margins, neutral table/link/button
 *  defaults. Inline styles on the elements themselves still win where they
 *  differ; the tokens (--dsw-*) are inherited, not reset. */
const STYLE_TEXT = `
[data-dshw-kanban="root"] *,
[data-dshw-kanban="root"] *::before,
[data-dshw-kanban="root"] *::after { box-sizing: border-box; margin: 0; padding: 0; }
[data-dshw-kanban="root"] { font-family: var(--dsw-font-family); font-size: 13px; line-height: 1.5; color: var(--dsw-alias-label-primary); }
[data-dshw-kanban="root"] table { border-collapse: collapse; border-spacing: 0; }
[data-dshw-kanban="root"] td,
[data-dshw-kanban="root"] th { text-align: left; vertical-align: middle; }
[data-dshw-kanban="root"] a { color: inherit; text-decoration: none; }
[data-dshw-kanban="root"] button { font-family: inherit; font-size: inherit; line-height: inherit; appearance: none; -webkit-appearance: none; background: none; border: none; color: inherit; cursor: pointer; }
[data-dshw-kanban="root"] input { font-family: inherit; }
[data-dshw-kanban="root"] p { margin: 0; }
[data-dshw-kanban="root"] img { border: 0; }
[data-dshw-kanban="trigger"],
[data-dshw-kanban="icon"] { background: transparent; }
[data-dshw-kanban="trigger"]:hover,
[data-dshw-kanban="trigger"][data-selected],
[data-dshw-kanban="icon"]:hover { background: var(--dsw-alias-interactive-bg-hover); }
[data-dshw-kanban="input"]:focus { border-color: var(--dsw-alias-state-business-primary); }
/* CommitGraph internals (Git view): keep only the graph surface, sized
   absolute at the host's origin. */
[data-dshw-kanban="gitgraph"] > div { position: relative; }
[data-dshw-kanban="gitgraph"] > div > div:first-child { overflow: visible; }
[data-dshw-kanban="gitgraph"] > div > div:nth-child(n + 2) { display: none !important; }
[data-dshw-kanban="gitgraph"] svg { position: absolute; inset: 0 auto auto 0; }
[data-dshw-kanban="gitgraph"] g[filter*="_curved_path_"] { filter: none; }
/* dshw view chrome (VS Code Light palette; style.css shortcuts) */
@keyframes dshw-dot-pulse { 0%, 100% { opacity: 1; } 50% { opacity: .3; } }
[data-dshw-kanban="pulse"] { animation: dshw-dot-pulse 1.2s ease-in-out infinite; }
[data-dshw-kanban="row"]:hover td { background: #f0f0f0; }
/* Row hover tints every cell, the review-entry column included; the icon
   button's own hover then steps one shade darker (same step as repo-header
   hover) so it stays visible on the tinted row. */
[data-dshw-kanban="row"]:hover td[data-dshw-kanban="reviewentrycell"] .dshw-icon:hover { background: #e3e3e3; }
[data-dshw-kanban="repogroup"]:hover { background: #e3e3e3; }
[data-dshw-kanban="repogroup"] a:hover { color: #006ab1; }
[data-dshw-kanban="gitrow"]:hover { background: #f0f0f0; }
[data-dshw-kanban="gitbranch"]:hover { background: #f0f0f0; }
[data-dshw-kanban="gitbranch"][aria-pressed="true"] { background: rgba(0, 122, 204, .12); }
[data-dshw-kanban="gitchip"]:hover { background: rgba(191, 136, 3, .12); }
[data-dshw-kanban="githash"]:hover { color: #006ab1; text-decoration: underline; }
[data-dshw-kanban="gitpr"]:hover { color: #006ab1; text-decoration: underline; }
.dshw-link:hover { text-decoration: underline; }
[data-dshw-kanban="root"] .dshw-trigger { color: #616161; }
[data-dshw-kanban="root"] .dshw-trigger:hover { color: #333333; text-decoration: underline; }
[data-dshw-kanban="root"] .dshw-chip { background: transparent; }
[data-dshw-kanban="root"] .dshw-chip:hover { background: rgba(191, 136, 3, .12); }
.dshw-nav:hover { background: #f0f0f0; }
.dshw-poprow:hover { background: #f0f0f0; }
[data-dshw-kanban="loadmore"]:hover { background: #f0f0f0; }
[data-dshw-kanban="titlelink"]:hover { text-decoration: underline; }
.dshw-icon:hover { background: #f0f0f0; color: #333333; }
.dshw-danger:hover { background: rgba(161, 38, 13, .1); }
.dshw-btn-default:hover { background: #f3f3f3; }
.dshw-btn-ghost:hover { background: #f0f0f0; }
/* job-dialog composer buttons: secondary (pause/stop) outlined + hover,
   primary (send) accent + darker hover. Inline styles can't do :hover, so
   the base look lives here and the inline style keeps only non-hover props. */
[data-dshw-kanban="root"] .dshw-jobbtn { background: transparent; border: 1px solid rgba(128, 128, 128, .35); }
[data-dshw-kanban="root"] .dshw-jobbtn:hover { background: #f0f0f0; }
[data-dshw-kanban="root"] .dshw-jobbtn:disabled { opacity: .45; cursor: default; }
[data-dshw-kanban="root"] .dshw-send { background: #007acc; color: #ffffff; border: 1px solid transparent; }
[data-dshw-kanban="root"] .dshw-send:hover { background: #0069ac; }
[data-dshw-kanban="root"] .dshw-send:disabled { opacity: .45; cursor: default; }
[data-dshw-kanban="root"] .dshw-wprow:hover { background: #f0f0f0; }
[data-dshw-kanban="root"] .dshw-wpta:focus { border-color: #007acc; }
[data-dshw-kanban="row"] { transition: background-color 100ms; }
/* Review detail workspace: file tree hover/selection and diff-row focus outline. */
[data-dshw-kanban="reviewtree"]:hover { background: #f0f0f0; }
[data-dshw-kanban="reviewtree"][data-selected] { background: rgba(0, 122, 204, .16); box-shadow: inset 2px 0 0 #007acc; }
[data-dshw-kanban="modebtn"]:not([data-selected]):hover { background: #f0f0f0; }
/* While the kanban board is open the sidebar session list shows no current
   selection (visual only — the real session stays current). */
body[data-dshw-kanban-open] [role="treeitem"][aria-selected="true"] { background: transparent; }
`

/** The framework-injected locale seat type (entry `locale` option). */
type Translate = (key: string, params?: Record<string, string | number>) => string

/** Composed props of the footer action entry (owner share + locale seat). */
export interface KanbanFooterActionProps {
  /** Whether the sidebar renders wide content (false = 56px rail). */
  wide: boolean
  /** Standard locale seat bound by the entry's `locale` option. */
  t: Translate
}

/** Services required before the entry activates. */
export const inject = ['slots', 'locale']

/** Register the footer action once its slot declaration is on the ledger. */
export function apply(ctx: ClientContext): void {
  ctx.effect(() => ctx.locale.register(NS, { zh, en }), 'dshw-kanban: dictionaries')
  ctx.slots.inject('sidebar.footer.action', () => ctx.slots.register({
    name: 'sidebar.footer.action',
    id: 'dshw-kanban',
    order: 0,
    locale: NS,
  }, KanbanFooterAction))
}

/** Read the daemon origin override, falling back to the default. */
function readBaseUrl(): string {
  try {
    return localStorage.getItem(URL_STORAGE_KEY) ?? DEFAULT_BASE_URL
  } catch {
    return DEFAULT_BASE_URL
  }
}

/** Inject the shared style tag once (lazy — runs when the entry mounts). */
function useKanbanStyles(): void {
  useEffect(() => {
    if (document.getElementById(STYLE_ID) !== null) return
    const style = document.createElement('style')
    style.id = STYLE_ID
    style.textContent = STYLE_TEXT
    document.head.appendChild(style)
    return () => { style.remove() }
  }, [])
}

/** The sidebar-foot trigger (wide row / rail icon) plus the fullscreen panel.
 *  Geometry and chrome mirror the settings trigger row (ui-settings-general
 *  SettingsRoot.module.css .trigger) so both footer entries look identical. */
export function KanbanFooterAction({ wide, t }: KanbanFooterActionProps): ReactNode {
  const [open, setOpen] = useState(false)
  useKanbanStyles()

  // Closing the panel when a session is opened: the workspace list rows are
  // `role=treeitem` with aria-selected (session rows and search results; the
  // workspace group headers lack aria-selected). A document-level capture
  // listener fires for clicks anywhere, including the sidebar, and closes the
  // board — no core changes needed.
  // While the board is open the current session's selected highlight in the
  // sidebar is suppressed (visual only): a body marker + the scoped rule
  // below. Removing the marker on close restores the normal selected state.
  useEffect(() => {
    if (open) document.body.setAttribute('data-dshw-kanban-open', '')
    else document.body.removeAttribute('data-dshw-kanban-open')
    return () => { document.body.removeAttribute('data-dshw-kanban-open') }
  }, [open])

  useEffect(() => {
    if (!open) return
    const onDocumentClick = (event: MouseEvent): void => {
      const target = event.target
      // 侧栏会话行（aria-selected 的 treeitem）在面板之外；面板内部自己的
      // 文件树行同样带 role=treeitem + aria-selected，必须排除，否则点文件
      // 会误关整个看板。
      if (target instanceof Element
        && target.closest('[data-dshw-kanban="root"]') === null
        && target.closest('[role="treeitem"][aria-selected]') !== null) {
        setOpen(false)
      }
    }
    document.addEventListener('click', onDocumentClick, true)
    return () => { document.removeEventListener('click', onDocumentClick, true) }
  }, [open])

  return (
    <>
      <Tooltip label={t('action.aria')} side="top" delayMs={500}>
        <button
          type="button"
          data-dshw-kanban="trigger"
          data-selected={open || undefined}
          aria-label={t('action.aria')}
          aria-haspopup="dialog"
          aria-expanded={open}
          onClick={() => { setOpen(value => !value) }}
          style={triggerStyle(wide)}
        >
          <IconBranchOutline16 size={wide ? 16 : 18} />
          {wide && <span style={labelStyle}>{t('action.label')}</span>}
        </button>
      </Tooltip>
      <KanbanPanel t={t} onClose={() => { setOpen(false) }} open={open} />
      {/* The panel stays mounted while closed (display:none) so the data channel
          and view state survive; reopening shows the last data instantly. */}
    </>
  )
}

/** Panel state: probing the daemon, embedded dashboard, or an unreachable form. */
type PanelStatus = 'checking' | 'ready' | 'down'

/**
 * Right edge of the left sidebar column: the AppFrame grid's first track
 * (the `sidebarCol` element, identified through the frame's shell-overlay
 * seat). The kanban panel spans everything to the right of it, leaving the
 * sidebar visible and interactive.
 */
function measureSidebarRight(): number {
  const frame = document.querySelector('[data-shell-overlay]')?.parentElement
  const column = frame?.firstElementChild
  return column instanceof HTMLElement ? column.getBoundingClientRect().right : 0
}

/** Panel: header chrome plus the native PR kanban (no iframe). */
function KanbanPanel({ t, onClose, open }: { t: Translate; onClose: () => void; open: boolean }): ReactNode {
  const [baseUrl, setBaseUrl] = useState(readBaseUrl)
  const [draft, setDraft] = useState(baseUrl)
  const [status, setStatus] = useState<PanelStatus>('checking')
  const [refreshKey, setRefreshKey] = useState(0)
  const [codeNotice, setCodeNotice] = useState<string>()
  const codeNoticeTimer = useRef<number | undefined>(undefined)
  const [left, setLeft] = useState(measureSidebarRight)

  const openCodeWorkspace = (): void => {
    fetch(`${baseUrl}/api/open-code`, { method: 'POST' })
      .then(async (response) => {
        const value = await response.json() as { error?: string }
        if (!response.ok) throw new Error(value.error ?? `HTTP ${response.status}`)
        setCodeNotice(undefined)
      })
      .catch((error: unknown) => {
        setCodeNotice(`打开 VS Code 失败：${error instanceof Error ? error.message : String(error)}`)
        if (codeNoticeTimer.current !== undefined) window.clearTimeout(codeNoticeTimer.current)
        codeNoticeTimer.current = window.setTimeout(() => { setCodeNotice(undefined) }, 4_000)
      })
  }
  useEffect(() => () => { if (codeNoticeTimer.current !== undefined) window.clearTimeout(codeNoticeTimer.current) }, [])

  // Follow the sidebar's right edge while open (drag-resize, collapse, narrow
  // auto-collapse) so the panel always fills exactly the space beside it.
  useEffect(() => {
    const frame = document.querySelector('[data-shell-overlay]')?.parentElement
    const column = frame?.firstElementChild
    if (!(column instanceof HTMLElement)) return
    const update = (): void => { setLeft(measureSidebarRight()) }
    const observer = new ResizeObserver(update)
    observer.observe(column)
    window.addEventListener('resize', update)
    return () => {
      observer.disconnect()
      window.removeEventListener('resize', update)
    }
  }, [])

  // Close on Escape while the panel is open.
  useEffect(() => {
    if (!open) return
    const onKeyDown = (event: KeyboardEvent): void => {
      if (event.key === 'Escape') onClose()
    }
    document.addEventListener('keydown', onKeyDown)
    return () => { document.removeEventListener('keydown', onKeyDown) }
  }, [onClose, open])

  // Probe the daemon whenever the target changes: reachable → native kanban,
  // unreachable → the URL editor.
  useEffect(() => {
    let cancelled = false
    setStatus('checking')
    fetch(`${baseUrl}/api/state`, { mode: 'no-cors', signal: AbortSignal.timeout(8000) })
      .then(() => { if (!cancelled) setStatus('ready') })
      .catch(() => { if (!cancelled) setStatus('down') })
    return () => { cancelled = true }
  }, [baseUrl])

  const refresh = (): void => {
    setRefreshKey(value => value + 1)
    // Ask the daemon to re-sync PRs; the snapshot then arrives over SSE.
    void fetch(`${baseUrl}/api/prs/refresh`, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: '{}',
    }).catch(() => {})
  }

  const save = (): void => {
    const next = draft.trim().replace(/\/+$/, '')
    if (next === '') return
    try {
      localStorage.setItem(URL_STORAGE_KEY, next)
    } catch {
      // Storage unavailable (private mode): keep the in-session override.
    }
    setBaseUrl(next)
  }

  return createPortal(
    <div style={{ ...overlayStyle(left), ...(open ? {} : { display: 'none' }) }} role="presentation" aria-hidden={!open}>
      <section style={panelStyle} role="dialog" aria-modal="true" aria-label={t('panel.title')} data-dshw-kanban="root">
        <header style={headerStyle}>
          <span style={titleGroupStyle}>
            <span style={logoStyle}>dw</span>
            <span style={titleStyle}>dshw</span>
            <span style={subtitleStyle}>DeepSeek Harness workflow</span>
          </span>
          {codeNotice !== null && <span style={codeNoticeStyle}>{codeNotice}</span>}
          <span style={actionsStyle}>
            <button
              type="button"
              data-dshw-kanban="icon"
              className="dshw-icon"
              aria-label={t('panel.code')}
              title={t('panel.code')}
              onClick={openCodeWorkspace}
              style={iconButtonStyle}
            >
              <GVsCode size={17.5} />
            </button>
            <button
              type="button"
              data-dshw-kanban="icon"
              className="dshw-icon"
              aria-label={t('panel.refresh')}
              onClick={refresh}
              style={iconButtonStyle}
            >
              <IconRefreshOutline16 size={14} />
            </button>
            <button
              type="button"
              data-dshw-kanban="icon"
              className="dshw-icon"
              aria-label={t('panel.close')}
              onClick={onClose}
              style={iconButtonStyle}
            >
              <IconCloseOutline16 size={14} />
            </button>
          </span>
        </header>
        {status === 'checking' && <div style={loadingStyle}>{t('panel.loading')}</div>}
        {status === 'ready' && (
          <KanbanWorkspace
            baseUrl={baseUrl}
            refreshKey={refreshKey}
            t={t}
            onRefresh={refresh}
          />
        )}
        {status === 'down' && (
          <div style={unreachableStyle}>
            <p style={unreachableTitleStyle}>{t('panel.unreachable.title')}</p>
            <p style={unreachableDetailStyle}>{t('panel.unreachable.detail', { url: baseUrl })}</p>
            <label style={urlFieldStyle}>
              <span style={urlLabelStyle}>{t('panel.url.label')}</span>
              <input
                data-dshw-kanban="input"
                style={urlInputStyle}
                value={draft}
                onChange={(event) => { setDraft(event.target.value) }}
                onKeyDown={(event) => { if (event.key === 'Enter') save() }}
              />
            </label>
            <button type="button" data-dshw-kanban="trigger" style={saveButtonStyle} onClick={save}>
              {t('panel.url.save')}
            </button>
          </div>
        )}
      </section>
    </div>,
    document.body,
  )
}

/* ── inline styles (tokens from the harness ui-theme variables) ─────────── */

/* The trigger mirrors the settings row exactly (ui-settings-general
   SettingsRoot.module.css .trigger): same geometry, radius, inset, hover and
   rail variants, so the two footer entries look identical. The base
   transparent background lives in the stylesheet (not inline) so the
   :hover/[data-selected] rules can paint over it. */
const triggerStyle = (wide: boolean): CSSProperties => ({
  flex: 'none',
  display: 'flex',
  alignItems: 'center',
  justifyContent: wide ? 'flex-start' : 'center',
  gap: wide ? 8 : 0,
  width: wide ? 'calc(100% + 4px)' : 36,
  height: wide ? 42 : 36,
  /* bottom -2px pulls the settings row up: net gap to it is 2px
     (the settings trigger keeps its own 4px top margin — core, untouched). */
  margin: wide ? '4px -2px -2px' : '8px 0 10px',
  padding: wide ? '0 10px 0 8px' : 0,
  boxSizing: 'border-box',
  border: 'none',
  borderRadius: wide ? 12 : '50%',
  color: 'var(--dsw-alias-label-primary)',
  fontFamily: 'inherit',
  fontSize: 14,
  lineHeight: '22px',
  cursor: 'pointer',
  overflow: 'hidden',
})

const labelStyle: CSSProperties = {
  overflow: 'hidden',
  whiteSpace: 'nowrap',
}

/** Fixed overlay spanning everything to the right of the sidebar column. */
const overlayStyle = (left: number): CSSProperties => ({
  position: 'fixed',
  top: 0,
  right: 0,
  bottom: 0,
  left,
  zIndex: 100,
  display: 'flex',
})

/** The panel fills the overlay edge to edge; the frame's own sidebar seam separates it. */
const panelStyle: CSSProperties = {
  flex: 1,
  minWidth: 0,
  minHeight: 0,
  display: 'flex',
  flexDirection: 'column',
  overflow: 'hidden',
  background: '#ffffff',
}

const headerStyle: CSSProperties = {
  flex: 'none',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'space-between',
  gap: 12,
  minHeight: 36,
  padding: '0 8px 0 12px',
  boxSizing: 'border-box',
  borderBottom: '1px solid #e7e7e7',
  background: '#dddddd',
}

const titleGroupStyle: CSSProperties = {
  display: 'flex',
  alignItems: 'center',
  gap: 8,
  minWidth: 0,
}

const logoStyle: CSSProperties = {
  flex: 'none',
  display: 'grid',
  placeItems: 'center',
  width: 18,
  height: 18,
  borderRadius: 4,
  background: '#007acc',
  color: '#ffffff',
  fontSize: 10,
  fontWeight: 700,
  letterSpacing: '-0.02em',
}

const titleStyle: CSSProperties = {
  flex: 'none',
  fontSize: 13,
  fontWeight: 600,
  lineHeight: '20px',
  color: '#333333',
}

const subtitleStyle: CSSProperties = {
  minWidth: 0,
  overflow: 'hidden',
  textOverflow: 'ellipsis',
  whiteSpace: 'nowrap',
  fontSize: 12,
  color: '#616161',
}

const codeNoticeStyle: CSSProperties = {
  minWidth: 0,
  overflow: 'hidden',
  textOverflow: 'ellipsis',
  whiteSpace: 'nowrap',
  fontSize: 11.5,
  color: '#a1260d',
}

const actionsStyle: CSSProperties = {
  display: 'flex',
  alignItems: 'center',
  gap: 2,
}

const iconButtonStyle: CSSProperties = {
  display: 'inline-flex',
  alignItems: 'center',
  justifyContent: 'center',
  width: 30,
  height: 30,
  border: 'none',
  borderRadius: 8,
  padding: 0,
  cursor: 'pointer',
  color: '#616161',
}

const loadingStyle: CSSProperties = {
  flex: 1,
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  fontSize: 13,
  color: '#717171',
}

const unreachableStyle: CSSProperties = {
  flex: 1,
  display: 'flex',
  flexDirection: 'column',
  alignItems: 'center',
  justifyContent: 'center',
  gap: 8,
  padding: 24,
  boxSizing: 'border-box',
}

const unreachableTitleStyle: CSSProperties = {
  margin: 0,
  fontSize: 14,
  fontWeight: 500,
  color: '#333333',
}

const unreachableDetailStyle: CSSProperties = {
  margin: 0,
  maxWidth: 520,
  textAlign: 'center',
  fontSize: 12,
  lineHeight: '18px',
  color: '#616161',
}

const urlFieldStyle: CSSProperties = {
  display: 'flex',
  alignItems: 'center',
  gap: 8,
  marginTop: 8,
}

const urlLabelStyle: CSSProperties = {
  fontSize: 12,
  color: '#616161',
}

const urlInputStyle: CSSProperties = {
  width: 320,
  height: 34,
  padding: '0 12px',
  boxSizing: 'border-box',
  border: '1px solid #e7e7e7',
  borderRadius: 4,
  outline: 'none',
  background: '#ffffff',
  fontFamily: 'inherit',
  fontSize: 12.5,
  color: '#333333',
}

const saveButtonStyle: CSSProperties = {
  height: 26,
  padding: '0 11px',
  border: 'none',
  borderRadius: 4,
  background: '#007acc',
  color: '#fff',
  fontFamily: 'inherit',
  fontSize: 12,
  cursor: 'pointer',
}
