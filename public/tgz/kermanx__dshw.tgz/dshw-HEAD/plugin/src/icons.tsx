/** Lucide stroke-icon glyphs (Icon.vue presetIcons) + status dot. */
import type { ReactNode } from 'react'
import { C_ACCENT, C_DANGER, C_FAINT, C_SUCCESS, C_WARNING, type Tone } from './theme.ts'

/** Lucide stroke-icon base (24px grid, currentColor; Icon.vue presetIcons). */
export function Lucide({ size = 15, children }: { size?: number; children: ReactNode }): ReactNode {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={2}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      {children}
    </svg>
  )
}

/** Status glyph (StatusIcon.vue port): circle-check / circle-x / circle-dashed / circle-dot. */
export function StatusIcon({ tone, size = 13 }: { tone: Tone; size?: number }): ReactNode {
  const color = tone === 'ok' ? C_SUCCESS : tone === 'bad' ? C_DANGER : tone === 'warn' ? C_WARNING : C_FAINT
  return (
    <span style={{ display: 'inline-flex', flex: 'none', color }} aria-hidden="true">
      <Lucide size={size}>
        {tone === 'ok' && (<><circle cx="12" cy="12" r="10" /><path d="m9 12 2 2 4-4" /></>)}
        {tone === 'bad' && (<><circle cx="12" cy="12" r="10" /><path d="m15 9-6 6" /><path d="m9 9 6 6" /></>)}
        {tone === 'warn' && (
          <>
            <path d="M10.1 2.182a10 10 0 0 1 3.8 0" />
            <path d="M13.9 21.818a10 10 0 0 1-3.8 0" />
            <path d="M17.609 3.721a10 10 0 0 1 2.69 2.7" />
            <path d="M2.182 13.9a10 10 0 0 1 0-3.8" />
            <path d="M20.279 17.609a10 10 0 0 1-2.7 2.69" />
            <path d="M21.818 10.1a10 10 0 0 1 0 3.8" />
            <path d="M3.721 6.391a10 10 0 0 1 2.7-2.69" />
            <path d="M6.391 20.279a10 10 0 0 1-2.69-2.7" />
          </>
        )}
        {tone === 'neutral' && (<><circle cx="12" cy="12" r="10" /><circle cx="12" cy="12" r="1" /></>)}
        {tone === 'accent' && (<><circle cx="12" cy="12" r="10" /><path d="m9 12 2 2 4-4" /></>)}
      </Lucide>
    </span>
  )
}

/** Colored status dot (StatusDot.vue port; jobs / busy / loading states). */
export function StatusDot({ tone, pulse }: { tone: Tone; pulse?: boolean }): ReactNode {
  const color = tone === 'ok' ? C_SUCCESS : tone === 'warn' ? C_WARNING : tone === 'bad' ? C_DANGER : tone === 'accent' ? C_ACCENT : C_FAINT
  return (
    <span
      data-dshw-kanban={pulse === true ? 'pulse' : undefined}
      aria-hidden="true"
      style={{ display: 'inline-block', flex: 'none', width: 8, height: 8, borderRadius: '50%', background: color }}
    />
  )
}

export const GPlus = ({ size = 12 }: { size?: number }): ReactNode => <Lucide size={size}><path d="M5 12h14" /><path d="M12 5v14" /></Lucide>
export const GPencil = ({ size = 12 }: { size?: number }): ReactNode => (
  <Lucide size={size}>
    <path d="M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z" />
    <path d="m15 5 4 4" />
  </Lucide>
)
export const GTrash = ({ size = 12 }: { size?: number }): ReactNode => (
  <Lucide size={size}>
    <path d="M3 6h18" />
    <path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6" />
    <path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2" />
    <line x1="10" x2="10" y1="11" y2="17" />
    <line x1="14" x2="14" y1="11" y2="17" />
  </Lucide>
)
export const GKey = ({ size = 11 }: { size?: number }): ReactNode => (
  <Lucide size={size}>
    <path d="M2.586 17.414A2 2 0 0 0 2 18.828V21a1 1 0 0 0 1 1h3a1 1 0 0 0 1-1v-1a1 1 0 0 1 1-1h1a1 1 0 0 0 1-1v-1a1 1 0 0 1 1-1h.172a2 2 0 0 0 1.414-.586l.814-.814a6.5 6.5 0 1 0-4-4z" />
    <circle cx="16.5" cy="7.5" r=".5" fill="currentColor" />
  </Lucide>
)
export const GGrip = ({ size = 13 }: { size?: number }): ReactNode => (
  <Lucide size={size}>
    <circle cx="9" cy="12" r="1" />
    <circle cx="9" cy="5" r="1" />
    <circle cx="9" cy="19" r="1" />
    <circle cx="15" cy="12" r="1" />
    <circle cx="15" cy="5" r="1" />
    <circle cx="15" cy="19" r="1" />
  </Lucide>
)
export const GDownload = ({ size = 14 }: { size?: number }): ReactNode => (
  <Lucide size={size}>
    <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
    <polyline points="7 10 12 15 17 10" />
    <line x1="12" x2="12" y1="15" y2="3" />
  </Lucide>
)
export const GSync = ({ size = 14 }: { size?: number }): ReactNode => (
  <Lucide size={size}>
    <path d="M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8" />
    <path d="M21 3v5h-5" />
    <path d="M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16" />
    <path d="M8 16H3v5" />
  </Lucide>
)
export const GReset = ({ size = 14 }: { size?: number }): ReactNode => (
  <Lucide size={size}>
    <path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8" />
    <path d="M3 3v5h5" />
  </Lucide>
)
export const GWorktree = ({ size = 14 }: { size?: number }): ReactNode => (
  <Lucide size={size}>
    <circle cx="12" cy="18" r="3" />
    <circle cx="6" cy="6" r="3" />
    <circle cx="18" cy="6" r="3" />
    <path d="M18 9v2c0 .6-.4 1-1 1H7c-.6 0-1-.4-1-1V9" />
    <path d="M12 12v3" />
  </Lucide>
)
export const GRepository = ({ size = 14 }: { size?: number }): ReactNode => (
  <Lucide size={size}>
    <path d="M9 20H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h3.9a2 2 0 0 1 1.69.9l.81 1.2a2 2 0 0 0 1.67.9H20a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-9a2 2 0 0 0-2 2Z" />
    <circle cx="13" cy="12" r="2" />
  </Lucide>
)
export const GAlert = ({ size = 13 }: { size?: number }): ReactNode => (
  <Lucide size={size}>
    <circle cx="12" cy="12" r="10" />
    <line x1="12" x2="12" y1="8" y2="12" />
    <line x1="12" x2="12.01" y1="16" y2="16" />
  </Lucide>
)
export const GClose = ({ size = 15 }: { size?: number }): ReactNode => (
  <Lucide size={size}>
    <path d="M18 6 6 18" />
    <path d="m6 6 12 12" />
  </Lucide>
)
export const GGitGraph = ({ size = 15 }: { size?: number }): ReactNode => (
  <Lucide size={size}>
    <circle cx="5" cy="6" r="3" />
    <path d="M5 9v6" />
    <circle cx="5" cy="18" r="3" />
    <path d="M12 3v18" />
    <circle cx="19" cy="6" r="3" />
    <path d="M16 15.7A9 9 0 0 0 19 9" />
  </Lucide>
)
export const GSettings = ({ size = 15 }: { size?: number }): ReactNode => (
  <Lucide size={size}>
    <path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z" />
    <circle cx="12" cy="12" r="3" />
  </Lucide>
)

/** System management sliders — lucide "sliders-horizontal" (24×24, stroke). */
export const GSliders = ({ size = 14 }: { size?: number }): ReactNode => (
  <Lucide size={size}>
    <path d="M10 5H3" />
    <path d="M12 19H3" />
    <path d="M14 3v4" />
    <path d="M16 17v4" />
    <path d="M21 12h-9" />
    <path d="M21 19h-5" />
    <path d="M21 5h-7" />
    <path d="M8 10v4" />
    <path d="M8 12H3" />
  </Lucide>
)

/** Repos — lucide "folder-git-2" (24×24, stroke). */
export const GFolderGit = ({ size = 14 }: { size?: number }): ReactNode => (
  <Lucide size={size}>
    <path d="M18 19a5 5 0 0 1-5-5v8" />
    <path d="M9 20H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h3.9a2 2 0 0 1 1.69.9l.81 1.2a2 2 0 0 0 1.67.9H20a2 2 0 0 1 2 2v5" />
    <circle cx="13" cy="12" r="2" />
    <circle cx="20" cy="19" r="2" />
  </Lucide>
)

/** Collapse chevrons — lucide "chevron-down" / "chevron-right". */
export const GCaretDown = ({ size = 14 }: { size?: number }): ReactNode => (
  <Lucide size={size}><path d="m6 9 6 6 6-6" /></Lucide>
)
export const GCaretRight = ({ size = 14 }: { size?: number }): ReactNode => (
  <Lucide size={size}><path d="m9 18 6-6-6-6" /></Lucide>
)

/** GitHub mark (Octicons mark-github, 16×16). */
export const GGithub = ({ size = 13 }: { size?: number }): ReactNode => (
  <svg width={size} height={size} viewBox="0 0 16 16" fill="currentColor" aria-hidden="true">
    <path d="M8 0C3.58 0 0 3.58 0 8c0 3.54 2.29 6.53 5.47 7.59.4.07.55-.17.55-.38 0-.19-.01-.82-.01-1.49-2.01.37-2.53-.49-2.69-.94-.09-.23-.48-.94-.82-1.13-.28-.15-.68-.52-.01-.53.63-.01 1.08.58 1.23.82.72 1.21 1.87.87 2.33.66.07-.52.28-.87.51-1.07-1.78-.2-3.64-.89-3.64-3.95 0-.87.31-1.59.82-2.15-.08-.2-.36-1.02.08-2.12 0 0 .67-.21 2.2.82.64-.18 1.32-.27 2-.27s1.36.09 2 .27c1.53-1.04 2.2-.82 2.2-.82.44 1.1.16 1.92.08 2.12.51.56.82 1.27.82 2.15 0 3.07-1.87 3.75-3.65 3.95.29.25.54.73.54 1.48 0 1.07-.01 1.93-.01 2.2 0 .21.15.46.55.38A8.01 8.01 0 0 0 16 8c0-4.42-3.58-8-8-8z" />
  </svg>
)

/** Review workspace entry glyph (code brackets: enter the review/diff view). */
export const GReview = ({ size = 13 }: { size?: number }): ReactNode => (
  <Lucide size={size}><path d="m8 7-5 5 5 5" /><path d="m16 7 5 5-5 5" /></Lucide>
)

/** Arrow-left (返回). */
export const GArrowLeft = ({ size = 14 }: { size?: number }): ReactNode => (
  <Lucide size={size}><path d="m12 19-7-7 7-7" /><path d="M19 12H5" /></Lucide>
)

/** External link (在新窗口打开). */
export const GExternalLink = ({ size = 14 }: { size?: number }): ReactNode => (
  <Lucide size={size}><path d="M15 3h6v6" /><path d="M10 14 21 3" /><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6" /></Lucide>
)

/** Message-circle (AI 对话). */
export const GComment = ({ size = 15 }: { size?: number }): ReactNode => (
  <Lucide size={size}><path d="M7.9 20A9 9 0 1 0 4 16.1L2 22Z" /></Lucide>
)

/** Document (单文件浏览模式). */
export const GFileSingle = ({ size = 14 }: { size?: number }): ReactNode => (
  <Lucide size={size}><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" /><path d="M14 2v6h6" /></Lucide>
)

/** Rows/list (连续浏览模式). */
export const GRows = ({ size = 14 }: { size?: number }): ReactNode => (
  <Lucide size={size}><path d="M8 6h13" /><path d="M8 12h13" /><path d="M8 18h13" /><path d="M3 6h.01" /><path d="M3 12h.01" /><path d="M3 18h.01" /></Lucide>
)

/** Maximize (查看完整文件). */
export const GMaximize = ({ size = 14 }: { size?: number }): ReactNode => (
  <Lucide size={size}>
    <polyline points="15 3 21 3 21 9" />
    <polyline points="9 21 3 21 3 15" />
    <line x1="21" y1="3" x2="14" y2="10" />
    <line x1="3" y1="21" x2="10" y2="14" />
  </Lucide>
)

/** Minimize (收起完整文件). */
export const GMinimize = ({ size = 14 }: { size?: number }): ReactNode => (
  <Lucide size={size}>
    <polyline points="4 14 10 14 10 20" />
    <polyline points="20 10 14 10 14 4" />
    <line x1="14" y1="10" x2="21" y2="3" />
    <line x1="3" y1="21" x2="10" y2="14" />
  </Lucide>
)

/** File-stack (分页浏览模式). */
export const GPages = ({ size = 14 }: { size?: number }): ReactNode => (
  <Lucide size={size}>
    <path d="M21 7h-3a2 2 0 0 1-2-2V2" />
    <path d="M21 6v6.5c0 .8-.7 1.5-1.5 1.5h-7c-.8 0-1.5-.7-1.5-1.5v-9c0-.8.7-1.5 1.5-1.5H17Z" />
    <path d="M7 8v8.8c0 .3.2.6.4.8.2.2.5.4.8.4H15" />
    <path d="M3 12v8.8c0 .3.2.6.4.8.2.2.5.4.8.4H11" />
  </Lucide>
)

/** VS Code logo — monochrome version, icon from Octicons by GitHub
 *  (https://github.com/primer/octicons/blob/main/LICENSE). */
export const GVsCode = ({ size = 14 }: { size?: number }): ReactNode => (
  <svg width={size} height={size} viewBox="0 0 48 48" fill="currentColor" aria-hidden="true">
    <path d="M32.59 41.758a2.41 2.41 0 0 1-2.77-.474L14.448 27.188l-6.695 5.109a1.62 1.62 0 0 1-2.074-.093l-2.147-1.963a1.64 1.64 0 0 1-.002-2.416L9.336 22.5L3.53 17.175a1.64 1.64 0 0 1 .002-2.416l2.147-1.963a1.62 1.62 0 0 1 2.074-.093l6.695 5.109L29.82 3.716a2.42 2.42 0 0 1 2.77-.475l8.03 3.884A2.45 2.45 0 0 1 42 9.333V24h-9.744V13.601L20.593 22.5l11.663 8.899V24H42v11.667c0 .941-.537 1.8-1.38 2.208z" />
  </svg>
)

/** Undo（撤销，rotate-ccw）。 */
export const GUndo = ({ size = 14 }: { size?: number }): ReactNode => (
  <Lucide size={size}>
    <path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8" />
    <path d="M3 3v5h5" />
  </Lucide>
)

/** Redo（重做，rotate-cw）。 */
export const GRedo = ({ size = 14 }: { size?: number }): ReactNode => (
  <Lucide size={size}>
    <path d="M21 12a9 9 0 1 1-9-9c2.52 0 4.93 1 6.74 2.74L21 8" />
    <path d="M21 3v5h-5" />
  </Lucide>
)

/** 眼睛（可见）。 */
export const GEye = ({ size = 14 }: { size?: number }): ReactNode => (
  <Lucide size={size}>
    <path d="M2.062 12.348a1 1 0 0 1 0-.696 10.75 10.75 0 0 1 19.876 0 1 1 0 0 1 0 .696 10.75 10.75 0 0 1-19.876 0" />
    <circle cx="12" cy="12" r="3" />
  </Lucide>
)

/** 眼睛加斜杠（隐藏）。 */
export const GEyeOff = ({ size = 14 }: { size?: number }): ReactNode => (
  <Lucide size={size}>
    <path d="M10.733 5.076a10.744 10.744 0 0 1 11.205 6.575 1 1 0 0 1 0 .696 10.747 10.747 0 0 1-1.444 2.49" />
    <path d="M14.084 14.158a3 3 0 0 1-4.242-4.242" />
    <path d="M17.479 17.499a10.75 10.75 0 0 1-15.417-5.151 1 1 0 0 1 0-.696 10.75 10.75 0 0 1 4.446-5.143" />
    <path d="m2 2 20 20" />
  </Lucide>
)
