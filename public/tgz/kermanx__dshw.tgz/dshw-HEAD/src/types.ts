export type JobStatus = 'queued' | 'running' | 'succeeded' | 'blocked' | 'failed' | 'cancelled'
export type SyncStatus = 'active' | 'draft' | 'closed' | 'error'
export type CiStatus = 'none' | 'pending' | 'passed' | 'failed'
export type WorkerType = 'dsh' | 'codex' | 'claude-code'
export type ApiKeyMode = 'value' | 'environment'
export type CredentialSource = 'saved' | 'environment' | 'local' | 'missing'

export interface WorkerTypeAvailability {
  type: WorkerType
  available: boolean
  version?: string
  reason?: string
}

export interface WorkerReasoningEffort {
  id: string
  name: string
  description?: string
}

export interface WorkerModelOption {
  id: string
  name: string
  description?: string
  isDefault?: boolean
  reasoningEfforts: WorkerReasoningEffort[]
  defaultReasoningEffort?: string
}

export interface WorkerModelCatalog {
  type: WorkerType
  provider?: string
  defaultModel?: string
  defaultReasoningEffort?: string
  models: WorkerModelOption[]
}

export interface WorkerConfig {
  id: string
  name: string
  type: WorkerType
  enabled: boolean
  isDefault: boolean
  provider?: string
  model?: string
  reasoningEffort?: string
  baseUrl?: string
  searchBaseUrl?: string
  apiKeyMode: ApiKeyMode
  apiKeyEnv?: string
  hasApiKey: boolean
  credentialSource: CredentialSource
  createdAt: string
  updatedAt: string
}

export interface WorkerConfigInput {
  name: string
  type: WorkerType
  enabled?: boolean
  provider?: string
  model?: string
  reasoningEffort?: string
  baseUrl?: string
  searchBaseUrl?: string
  apiKeyMode?: ApiKeyMode
  apiKeyEnv?: string
  apiKey?: string
}

export interface HarnessRepositoryStatus {
  state: 'ready' | 'error'
  checkedAt: string
  behind?: number
  dirty?: boolean
  error?: string
}

export interface DshwRepositoryStatus extends HarnessRepositoryStatus {
  upstream?: string
}

export interface WorktreeCleanupCandidate {
  name: string
  branch: string
  staged: boolean
  unstaged: boolean
  merging: boolean
  ahead: number
  behind: number
  needsDecision: boolean
  inspectionError?: string
}

export interface WorktreeCleanupPreview {
  total: number
  active: number
  busy: number
  candidates: WorktreeCleanupCandidate[]
}

export interface WorkerExecutionConfig {
  id: string
  name: string
  type: WorkerType
  provider?: string
  model?: string
  reasoningEffort?: string
  baseUrl?: string
  searchBaseUrl?: string
  apiKeyMode: ApiKeyMode
  apiKeyEnv?: string
  apiKey?: string
}

/** 一个被追踪 PR 的 worktree（git 是唯一真相源：运行时从
 *  `git worktree list` 枚举并推导，不落独立元数据文件）。 */
export interface CloneRecord {
  name: string
  path: string
  repoSlug: string
  /** PR head 分支（从 worktree 分支的 upstream 配置推导）。 */
  branch: string
  worktreeBranch: string
}

export interface SyncRecord {
  id: string
  cloneName: string
  clonePath: string
  remoteUrl: string
  repoSlug: string
  prNumber: number
  /** PR title captured when the task starts; absent on legacy persisted records. */
  prTitle?: string
  prUrl: string
  branch: string
  baseRefName: string
  /** PR-specific base snapshot reported by GitHub. */
  baseOid: string
  /** Latest target branch tip observed by the shared ref watcher. */
  observedBaseOid?: string
  headOid: string
  status: SyncStatus
  /** 自动 sync（冲突合并 / CI 修复）开关；缺省视为 true（兼容旧状态），自动追踪发现的 PR 初始为 false。 */
  enabled?: boolean
  pausedReason?: string
  agentPausedAt?: string
  agentPausedReason?: string
  createdAt: string
  updatedAt: string
  nextPrRefreshAt: string
  /** First target-branch push in the current debounce cycle; keeps repeated pushes from postponing forever. */
  pendingBaseCheckStartedAt?: string
  pendingBaseCheckAt?: string
  immediateCheckRequestedAt?: string
  ciMonitorHeadOid?: string
  nextCiCheckAt?: string
  noChecksSince?: string
  lastCiStatus?: CiStatus
  lastFixedHeadOid?: string
  lastError?: string
}

export interface JobRecord {
  id: string
  type: 'update-dshw' | 'update-harness' | 'reconfigure-harness' | 'sync-check' | 'merge-base' | 'fix-ci' | 'resolve-comments' | 'custom' | 'review' | 'auto-review-fix'
  status: JobStatus
  syncId?: string
  /** Worker configuration name captured when the job starts. Missing for built-in and legacy jobs. */
  executor?: string
  createdAt: string
  startedAt?: string
  finishedAt?: string
  cancelRequestedAt?: string
  /** Next periodic task-boundary reminder for a running Worker. */
  nextAgentSteerAt?: string
  summary: string
  output?: string
  /** Persisted field name retained for compatibility; may contain any Worker type. */
  dshWorker?: WorkerState
}

export interface WorkerHandle {
  runId: string
  label: string
  domain: string
  plistPath: string
  requestPath: string
  resultPath: string
  controlSocketPath?: string
  eventLogPath?: string
  runtimeCommit?: string
  /** Missing on older persisted handles, which are always dsh. */
  workerType?: WorkerType
  progressProtocol?: 'memory-events-v1' | 'session-control-v1'
  /** Legacy file-backed progress handle, retained only for state compatibility. */
  progressPath?: string
  startedAt: string
}

export interface WorkerProgress {
  runId: string
  phase: 'starting' | 'running' | 'cancelling' | 'paused' | 'finishing'
  message: string
  startedAt: string
  updatedAt: string
  outputTail: string
}

export interface WorkerState {
  handle: WorkerHandle
  kind: WorkerRunRecord['kind']
  sync: SyncRecord
  oldHead: string
  label: string
  /** Set when this run is the user-approved push of an auto-review fix. */
  push?: boolean
}

export interface WorkerRunRecord {
  id: string
  syncId: string
  kind: 'merge-base' | 'fix-ci' | 'resolve-comments' | 'custom' | 'review' | 'auto-review-fix'
  clonePath: string
  startedAt: string
  finishedAt: string
  status: 'succeeded' | 'blocked' | 'failed' | 'cancelled'
  finalOutput: string
  blockedReason?: string
}

/** Legacy type aliases retained for persisted state and older modules. */
export type DshWorkerHandle = WorkerHandle
export type DshWorkerProgress = WorkerProgress
export type DshWorkerState = WorkerState
export type DshRunRecord = WorkerRunRecord

export interface EventRecord {
  id: string
  time: string
  level: 'info' | 'warning' | 'error'
  kind: string
  message: string
}

export interface LogPage {
  records: EventRecord[]
  nextCursor?: string
  hasMore: boolean
}

export interface JobPage {
  records: JobRecord[]
  nextCursor?: string
  hasMore: boolean
}

/** 一个由 dshw 监控的 GitHub 仓库；数组顺序即各面板的展示顺序。 */
export interface MonitoredRepo {
  repoSlug: string
  enabled: boolean
}

export interface ServiceState {
  version: 3
  serviceStartedAt?: string
  update: {
    nextAt?: string
    lastAt?: string
    lastStatus?: 'succeeded' | 'failed'
    lastMessage?: string
  }
  /** 监控的 GitHub 仓库（顺序即展示顺序）；v2 迁移时以现有 sync 推断。 */
  repos: MonitoredRepo[]
  syncs: SyncRecord[]
  jobs: JobRecord[]
  dshRuns: DshRunRecord[]
  events: EventRecord[]
  /** Last usable dashboard snapshot, retained across daemon restarts. */
  prDashboardCache?: {
    records: PrDashboardRecord[]
    lastSuccessAt?: string
  }
  /** Last usable review-request snapshot, retained across daemon restarts. */
  reviewRequestsCache?: {
    records: ReviewRequestRecord[]
    lastSuccessAt?: string
  }
}

export interface PullRequestInfo {
  number: number
  title: string
  url: string
  state: string
  isDraft: boolean
  author?: { login?: string }
  mergeable: string
  mergeStateStatus: string
  baseRefName: string
  baseRefOid: string
  headRefName: string
  headRefOid: string
  reviewDecision: string
  reviewRequests: PullRequestReviewRequest[]
  latestReviews: PullRequestReview[]
  statusCheckRollup: PullRequestCheck[]
}

export interface PullRequestReviewRequest {
  __typename?: string
  login?: string
}

/** `gh pr list --author @me` / `--assignee @me` 返回的轻量摘要，用于自动追踪发现。 */
export interface MyPullRequestSummary {
  number: number
  title: string
  url: string
  isDraft: boolean
  author?: { login?: string }
  baseRefName: string
  baseRefOid: string
  headRefName: string
  headRefOid: string
}

export interface ReviewRequestRecord {
  repoSlug: string
  number: number
  title: string
  url: string
  isDraft: boolean
  author: string
  headRefName: string
  baseRefName: string
  updatedAt: string
  /** Read-status summary merged by the daemon snapshot (absent on persisted rows). */
  viewed?: ReviewViewedSummary
}

/** Read-status progress of one review (viewed files / changed files). */
export interface ReviewViewedSummary {
  count: number
  total: number
}

export interface PullRequestReview {
  author?: { login?: string }
  state: string
  submittedAt?: string
}

/* ── Review diff workspace (angry-turtle-review port, driven by local clones) ── */

/** Git status of one changed file in a review diff. */
export type ReviewDiffStatus = 'added' | 'deleted' | 'renamed' | 'copied' | 'modified'
export type ReviewDiffRowKind = 'hunk' | 'added' | 'removed' | 'context'

/** One changed file in the review manifest (paths, status, index). */
export interface ReviewDiffFile {
  index: number
  status: ReviewDiffStatus
  /** New path; falls back to the old path for deletions. */
  path: string
  /** Original path when renamed; absent otherwise. */
  oldPath?: string
  /** Hash of this file's changed-line content in the captured diff; used to
   *  auto-unview files whose diff changed after a PR head update. Absent when
   *  the file has no textual patch (binary etc.). */
  fingerprint?: string
}

/** One display row of a file's textual diff. */
export interface ReviewDiffRow {
  kind: ReviewDiffRowKind
  text: string
  oldLine?: number
  newLine?: number
}

/** Per-file diff payload served lazily by the review diff endpoint. */
export type ReviewDiffPayload =
  | { kind: 'text'; file: ReviewDiffFile; rows: ReviewDiffRow[]; additions: number; deletions: number }
  | { kind: 'unavailable'; file: ReviewDiffFile; rows: ReviewDiffRow[]; additions: number; deletions: number; reason: string }

/** Review diff manifest returned after the local clone is prepared. */
export interface ReviewDiffManifest {
  available: boolean
  token: string
  files: ReviewDiffFile[]
  baseRefName: string
  headRefName: string
  clonePath: string
  /** Currently viewed files (path → fingerprint), reconciled against this diff:
   *  paths whose diff changed since the user read them are dropped. */
  viewed: Record<string, string>
  /** 分页模式已读页面：页面内容指纹 → true（客户端按视口打包后写入）。 */
  paged: Record<string, boolean>
  /** Set when the diff could not be captured (e.g. clone preparation failed). */
  error?: string
}

export interface ReviewerCommentProgress {
  total: number
  resolved: number
}

export interface PullRequestCheck {
  __typename?: string
  name?: string
  context?: string
  status?: string
  state?: string
  conclusion?: string
  detailsUrl?: string
  targetUrl?: string
  workflowName?: string
}

export interface CiCheck {
  name: string
  bucket: string
  state: string
  workflow: string
  link: string
}

export interface CloneGitStatus {
  unstaged: boolean
  staged: boolean
  merging: boolean
  ahead: number
  behind: number
}

export interface PrDashboardRecord {
  cloneName: string
  clonePath: string
  repoSlug: string
  number: number
  title: string
  url: string
  state: string
  isDraft: boolean
  branch: string
  baseRefName: string
  /** PR 作者 login；非自己创建的 PR（assign 给我）会带上。 */
  author?: string
  /** PR assign 给我但不是由我创建（用于看板区分“我的 PR”和“assign 给我的 PR”）。 */
  assignedToMe?: boolean
  /** Exact remote PR head observed during the latest GitHub refresh. */
  headOid?: string
  /** PR-specific base snapshot observed during the latest GitHub refresh. */
  baseOid?: string
  mergeable: string
  mergeStateStatus: string
  conflictPaths?: string[]
  autoMergeSkippedReason?: string
  baseBehind?: boolean
  reviewDecision: string
  reviewRequests: string[]
  reviews: PullRequestReview[]
  reviewerComments: Record<string, ReviewerCommentProgress>
  ciStatus: CiStatus
  ciSummary: string
  checks: CiCheck[]
  localGitStatus?: CloneGitStatus
  syncId?: string
  syncEnabled?: boolean
  pendingBaseCheckAt?: string
  unresolvedComments?: number
  agentPausedReason?: string
  updatedAt: string
}

export interface GitGraphCommit {
  hash: string
  parents: string[]
  subject: string
  body: string
  author: {
    name: string
    email: string
    timestamp: number
  }
  refs: string[]
}

export interface GitGraphBranch {
  name: string
  label: string
  oid: string
  kind: 'master' | 'pr'
  number?: number
  title?: string
  url?: string
  isDraft?: boolean
}

export interface GitGraphSnapshot {
  repoSlug: string
  generatedAt: string
  commits: GitGraphCommit[]
  branches: GitGraphBranch[]
  truncated: boolean
}

export interface PrDashboardStatus {
  state: 'loading' | 'ready' | 'error'
  refreshing: boolean
  stale: boolean
  lastAttemptAt?: string
  lastSuccessAt?: string
  error?: string
  /** Exact event-log record containing the reason for the current error. */
  errorEventId?: string
}

/* ── PR Auto Reviewer ──────────────────────────────────────────────────────
 * Per-PR automatic AI review of the commits a PR branch gains. One record per
 * PR mirrors the dashboard identity plus the latest review outcome and the fix
 * session started for it. */

/** Where one PR stands in the auto-review cycle. */
export type AutoReviewStatus = 'idle' | 'pending' | 'running' | 'reviewed' | 'failed'
export type AutoReviewSeverity = 'critical' | 'warning' | 'suggestion'
/** Which commits a PR gains trigger a review. */
export type AutoReviewScope = 'mine' | 'assigned' | 'all'

/** One actionable finding anchored to the reviewed diff. */
export interface AutoReviewComment {
  file: string
  line?: number
  lineStart?: number
  lineEnd?: number
  lineType: 'old' | 'new'
  severity: AutoReviewSeverity
  message: string
  /** Most representative line inside the range. */
  fallbackLine?: number
  /** False when the model picked a line outside the diff; the comment stays visible. */
  locationValid: boolean
  /** Models that reported this finding (parallel review attribution). */
  models?: string[]
}

/** The dsh session started to fix a review's findings. */
export interface AutoReviewFix {
  jobId: string
  /**
   * `ready` = changes sit in the working tree, not pushed (the default flow);
   * `pushed` = the user asked for a push and it happened.
   */
  status: JobStatus | 'ready' | 'pushed'
  startedAt: string
  finishedAt?: string
  /** PR head the fix session started from. */
  headOid: string
  /** Reason the worker reported when it stopped without completing. */
  blockedReason?: string
  /** Commits the fix session produced, once it finished. */
  producedHeadOid?: string
  /** Un-pushed working-tree changes, refreshed after every turn. */
  diff?: ReviewFixDiff
  /** Two-to-four sentence explanation produced by the summary turn. */
  summary?: string
  /** Points the author should look at, produced by the summary turn. */
  notes?: string[]
}

/** Snapshot of `git diff` in the PR clone (see auto-review-fix.ts). */
export interface ReviewFixDiff {
  stat: string
  patch: string
  files: string[]
  additions: number
  deletions: number
  truncated: boolean
  capturedAt: string
}

export interface AutoReviewRecord {
  /** `${repoSlug}#${number}` — one record per PR. */
  id: string
  repoSlug: string
  number: number
  title: string
  url: string
  branch: string
  baseRefName: string
  author?: string
  /** PR head reviewed (or about to be reviewed). */
  headOid: string
  /** Base commit for the reviewed diff (merge base of baseRefName and head). */
  baseOid: string
  /** Newest PR head observed, even while a review is still pending. */
  observedHeadOid: string
  /** Head of the most recent completed review. */
  reviewedHeadOid?: string
  status: AutoReviewStatus
  /** Debounce deadline while `status` is pending. */
  dueAt?: string
  /** First commit of the current debounce cycle; caps repeated postponement. */
  pendingSince?: string
  trigger: 'auto' | 'manual'
  summary: string
  comments: AutoReviewComment[]
  counts: { critical: number, warning: number, suggestion: number }
  model?: string
  /** Models that produced this review (parallel runs merged into `comments`). */
  models?: string[]
  engine?: string
  /** Token usage / estimated cost of the latest review. */
  usage?: AutoReviewUsage
  error?: string
  startedAt?: string
  finishedAt?: string
  fix?: AutoReviewFix
  /** Automatic fix sessions already started for this PR. */
  fixRounds?: number
  /** Why the last cycle stopped without starting a review. */
  skippedReason?: string
  updatedAt: string
}

/** Token usage and estimated cost of one review run. */
export interface AutoReviewUsage {
  input: number
  output: number
  cacheRead: number
  cacheWrite: number
  totalTokens: number
  costUsd: number
  steps: number
}

/** Snapshot row for the list view: the record without its comments. */
export interface AutoReviewSummary extends Omit<AutoReviewRecord, 'comments'> {
  /** Comments kept in the full record (fetched on demand). */
  commentCount: number
}

/** Model families the review bot knows how to configure for the gateway. */
export type AutoReviewModelProfile = 'deepseek' | 'anthropic' | 'openai' | 'glm'

/** Stored (non-secret) auto-review settings. */
export interface AutoReviewConfig {
  enabled: boolean
  scope: AutoReviewScope
  /** Quiet period after the newest commit before the review starts. */
  debounceSeconds: number
  /** Upper bound on one debounce cycle, so a busy branch still gets reviewed. */
  debounceMaxSeconds: number
  /** Models reviewed in parallel (cc_bot's default runs three). */
  models: string[]
  /** Primary model (first of `models`); kept for display and legacy configs. */
  model: string
  /** Gateway preset for `model`; inferred from the model id when absent. */
  modelProfile?: AutoReviewModelProfile
  baseUrl: string
  apiKeyMode: ApiKeyMode
  apiKeyEnv?: string
  hasApiKey: boolean
  credentialSource: CredentialSource
  /** Pinned Pi engine version used to run the reviewer. */
  engineVersion: string
  timeoutSeconds: number
  /** Start a dsh session to fix the findings after a review completes. */
  autoFix: boolean
  /** Lowest severity that triggers an automatic fix session. */
  fixSeverity: 'critical' | 'warning'
  /** Worker configuration used for the fix session; absent = default worker. */
  workerConfigId?: string
  /** Extra instructions appended to the review prompt. */
  instructions: string
}

/** User-editable subset of {@link AutoReviewConfig}. */
export interface AutoReviewConfigInput {
  enabled?: boolean
  scope?: AutoReviewScope
  debounceSeconds?: number
  debounceMaxSeconds?: number
  /** Parallel review models; `model` is accepted as a single-model shorthand. */
  models?: string[]
  model?: string
  /** `'auto'` clears an explicit preset so the model id decides again. */
  modelProfile?: AutoReviewModelProfile | 'auto'
  baseUrl?: string
  apiKeyMode?: ApiKeyMode
  apiKeyEnv?: string
  apiKey?: string
  engineVersion?: string
  timeoutSeconds?: number
  autoFix?: boolean
  fixSeverity?: 'critical' | 'warning'
  workerConfigId?: string
  instructions?: string
}

/* ── Feishu bot ────────────────────────────────────────────────────────────
 * dshw reports PR progress into one Feishu topic chat. Each tracked PR owns a
 * topic thread: notifications are replies in it, and the user's replies there
 * become instructions for dshw. */

/** lark-cli availability, probed on demand from the settings panel. */
export interface FeishuCliStatus {
  available: boolean
  version?: string
  botReady?: boolean
  userReady?: boolean
  userNeedsRefresh?: boolean
  /** open_id of the authorized user, used to invite them into a new topic chat. */
  userOpenId?: string
  error?: string
  checkedAt: string
}

/** Which progress events are announced in Feishu. */
export interface FeishuNotifyConfig {
  /** Automatic review finished (with findings). */
  review: boolean
  /** Fix session finished (succeeded / blocked / failed / cancelled). */
  fix: boolean
  /** Review or fix failed outright. */
  failure: boolean
}

export interface FeishuConfig {
  enabled: boolean
  /** Executable that speaks the Feishu OpenAPI (lark-cli). */
  command: string
  /** Optional HTTPS proxy for lark-cli (e.g. an intranet gateway). */
  proxy?: string
  /** Topic chat (话题群) receiving the notifications. */
  chatId?: string
  chatName?: string
  /** GUI base URL used in message links; auto-filled from the browser origin. */
  webBaseUrl?: string
  /** How often topic replies are polled, in seconds. */
  pollSeconds: number
  notify: FeishuNotifyConfig
  /** Last lark-cli probe (read-only, refreshed by the daemon). */
  status?: FeishuCliStatus
  /** Read-only view of whether a proxy is configured (the value is never returned). */
  hasProxy?: boolean
}

export interface FeishuConfigInput {
  enabled?: boolean
  command?: string
  proxy?: string
  chatId?: string
  chatName?: string
  webBaseUrl?: string
  pollSeconds?: number
  notify?: Partial<FeishuNotifyConfig>
}

/** One Feishu topic thread owned by a tracked PR. */
export interface FeishuThread {
  /** `repoSlug#number` — the same identity the auto-review record uses. */
  key: string
  title: string
  /** Root message that opened the topic. */
  rootMessageId: string
  threadId: string
  /** Card that carries the review result (patched when the fix state changes). */
  reviewCardId?: string
  /** Card that carries the fix session progress (patched while it runs). */
  fixCardId?: string
  /** Message ids already handled (bounded). */
  seenMessageIds: string[]
  createdAt: string
  updatedAt: string
  lastError?: string
}
