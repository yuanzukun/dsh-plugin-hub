/*---------------------------------------------------------------------------------------------
 *  dsh-copilot-sdk plugin entry (dsh port additions; no upstream equivalent).
 *
 *  Cordis plugin that bridges a GitHub Copilot subscription into the harness:
 *  registers the `copilot` llm provider (see adapter.ts) and a `/copilot`
 *  command for status/models/stop. The Copilot CLI runtime is spawned lazily
 *  on first use and stopped on plugin disposal.
 *--------------------------------------------------------------------------------------------*/

import { CopilotClient } from "dsh-copilot-sdk";
import type { Context } from "@deepseek-ai/cordis";
// 类型增强：ctx.commands（strip-types 会在运行时剥掉 type-only import）
import type {} from "@deepseek-ai/dsh-commands";
import z from "@deepseek-ai/schemastery";
import { COPILOT_PROVIDER, CopilotLlmAdapter } from "./adapter.ts";
import type { CopilotClientLike } from "./adapter.ts";

export const name = "dsh-copilot-sdk";

// Session services the plugin needs; llm is resolved eagerly (registerAdapter
// runs in apply), commands via late inject per fleet convention.
export const inject = ["llm"];

// 配置走环境变量（COPILOT_GITHUB_TOKEN / GH_TOKEN / GITHUB_TOKEN / BYOK），
// 行配置留空 schema，避免与 SDK 自身的 env 优先级打架。
export const Config = z.object({});

async function createCopilotClient(): Promise<CopilotClientLike> {
    // The real CopilotClient satisfies CopilotClientLike structurally (the
    // SDK's generic on<K> overload does not statically match the narrow
    // overloads, a TS generic-to-concrete assignability limitation — the
    // narrow surface is verified against the fake in adapter.test.ts).
    const client = new CopilotClient() as unknown as CopilotClientLike;
    await client.start();
    return client;
}

/**
 * Bridge the Copilot subscription into one harness context. The client
 * factory is a seam for tests; the loader entry `apply` uses the real SDK
 * client.
 */
export function applyCopilotBridge(
    ctx: Context,
    clientFactory: () => Promise<CopilotClientLike>,
): void {
    let clientPromise: Promise<CopilotClientLike> | undefined;

    const getClient = (): Promise<CopilotClientLike> => {
        // A rejected start must not be pinned forever: reset so the next
        // call retries (a transient CLI failure would otherwise brick the
        // provider until /copilot stop).
        clientPromise ??= clientFactory().catch((error: unknown) => {
            clientPromise = undefined;
            throw error;
        });
        return clientPromise;
    };

    const adapter = new CopilotLlmAdapter(getClient);
    ctx.llm.registerAdapter([COPILOT_PROVIDER], adapter);

    ctx.inject(["commands"], (cmdCtx) => {
        cmdCtx.commands.register({
            name: "copilot",
            description: "GitHub Copilot bridge: status | models | stop",
            input: { hint: "status | models | stop" },
            async handler(invocation) {
                const [cmdRaw] = (invocation.rawInput || "").trim().toLowerCase().split(/\s+/, 1);
                const cmd = cmdRaw || "status";
                try {
                    if (cmd === "models") {
                        const client = await getClient();
                        const models = await client.listModels();
                        return {
                            kind: "success",
                            text: models.length === 0
                                ? "Copilot bridge: no models available. Check the Copilot subscription."
                                : `Copilot models:\n${models.map((model) => `${model.id} — ${model.name}`).join("\n")}`,
                        };
                    }
                    if (cmd === "stop") {
                        if (clientPromise === undefined) {
                            return { kind: "success", text: "Copilot bridge: not started." };
                        }
                        const client = await clientPromise.catch(() => undefined);
                        if (client !== undefined) await client.stop();
                        clientPromise = undefined;
                        return { kind: "success", text: "Copilot bridge: stopped." };
                    }
                    // status (default)
                    if (cmd !== "status") {
                        return {
                            kind: "error",
                            text: `Unknown subcommand: ${cmdRaw}. Usage: /copilot status | models | stop`,
                        };
                    }
                    const client = await getClient();
                    const models = await client.listModels();
                    return {
                        kind: "success",
                        text: [
                            "Copilot bridge: connected.",
                            `Provider: ${COPILOT_PROVIDER}`,
                            `Models available: ${models.length}`,
                            "Requires a GitHub Copilot subscription (or BYOK via COPILOT_GITHUB_TOKEN / provider config).",
                        ].join("\n"),
                    };
                } catch (error) {
                    return {
                        kind: "error",
                        text: error instanceof Error ? error.message : String(error),
                    };
                }
            },
        });
    });

    ctx.effect(() => async () => {
        if (clientPromise === undefined) return;
        const client = await clientPromise.catch(() => undefined);
        if (client !== undefined) await client.stop();
    }, "dsh-copilot-sdk: client lifecycle");
}

export function apply(ctx: Context): void {
    applyCopilotBridge(ctx, createCopilotClient);
}
