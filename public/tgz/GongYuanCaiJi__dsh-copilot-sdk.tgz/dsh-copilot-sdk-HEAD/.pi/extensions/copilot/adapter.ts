/*---------------------------------------------------------------------------------------------
 *  dsh-copilot-sdk bridge adapter (dsh port additions; no upstream equivalent).
 *
 *  Maps the dsh llm adapter contract (GenerateOptions → StreamChunk) onto the
 *  GitHub Copilot SDK: one Copilot session per stream call, tool execution
 *  denied so the Copilot runtime never touches the machine on dsh's behalf,
 *  assistant deltas forwarded as text/reasoning chunks.
 *--------------------------------------------------------------------------------------------*/

import { EMPTY_RESPONSE_CODE, LlmAdapter, LlmError } from "@deepseek-ai/dsh-llm";
import type {
    GenerateOptions,
    LlmModelInfo,
    LlmResolvedModelInfo,
    Message,
    StreamChunk,
} from "@deepseek-ai/dsh-llm";
import type {
    AssistantMessageDeltaEvent,
    AssistantMessageEvent,
    AssistantMessageStartEvent,
    AssistantReasoningDeltaEvent,
    ModelInfo,
    SessionConfig,
} from "dsh-copilot-sdk";

export const COPILOT_PROVIDER = "copilot";

/** The SDK session surface the bridge touches (structural; the real CopilotSession satisfies it). */
export interface CopilotSessionLike {
    on(eventType: "assistant.message_start", handler: (event: AssistantMessageStartEvent) => void): () => void;
    on(eventType: "assistant.message_delta", handler: (event: AssistantMessageDeltaEvent) => void): () => void;
    on(eventType: "assistant.reasoning_delta", handler: (event: AssistantReasoningDeltaEvent) => void): () => void;
    sendAndWait(options: { prompt: string }, timeout?: number): Promise<AssistantMessageEvent | undefined>;
    abort(): Promise<void>;
    disconnect(): Promise<void>;
}

/** The SDK client surface the bridge touches. */
export interface CopilotClientLike {
    start(): Promise<void>;
    createSession(config: SessionConfig): Promise<CopilotSessionLike>;
    listModels(): Promise<ModelInfo[]>;
    stop(): Promise<Error[]>;
}

/**
 * Deny every tool permission request. The bridge exposes the Copilot
 * subscription as a chat model; the Copilot runtime's own tools (shell, file
 * edits, …) must never execute inside a dsh session.
 */
export function denyToolPermissions(): { kind: "reject" } {
    return { kind: "reject" };
}

/** Extract the renderable text of one dsh message. */
function renderMessageText(message: Message): string {
    const parts: string[] = [];
    for (const block of message.content) {
        if (block.type === "text") {
            parts.push(block.text);
        } else if (block.type === "tool-result") {
            for (const nested of block.content) {
                if (nested.type === "text") parts.push(nested.text);
            }
        }
    }
    return parts.join("\n");
}

function roleLabel(message: Message): string {
    if (message.role === "assistant") return "assistant";
    const isToolResult = message.content.some((block) => block.type === "tool-result");
    return isToolResult ? "tool result" : "user";
}

/**
 * Render a dsh conversation history into one Copilot prompt. The Copilot
 * session API takes text prompts only, so role-labeled turns are joined into
 * a single prompt per stream call (each stream call gets a fresh session).
 * System-role messages are skipped: the system prompt travels via
 * `GenerateOptions.system` → the SDK's systemMessage section instead.
 */
export function renderPrompt(options: GenerateOptions): string {
    const turns: string[] = [];
    for (const message of options.messages) {
        if (message.role === "system") continue;
        const text = renderMessageText(message);
        if (!text) continue;
        turns.push(`${roleLabel(message)}: ${text}`);
    }
    return turns.join("\n\n");
}

const ABORTED_MARKER = { aborted: true } as const;

/** Async FIFO for event-driven chunks pushed while the generator races on them. */
class ChunkQueue {
    private readonly items: StreamChunk[] = [];
    private readonly waiters: Array<(value: StreamChunk | undefined) => void> = [];
    private closed = false;

    push(chunk: StreamChunk): void {
        const waiter = this.waiters.shift();
        if (waiter !== undefined) {
            waiter(chunk);
            return;
        }
        this.items.push(chunk);
    }

    /** Resolves with the next chunk, or `undefined` once the queue is closed. */
    shift(): Promise<StreamChunk | undefined> {
        const item = this.items.shift();
        if (item !== undefined) return Promise.resolve(item);
        if (this.closed) return Promise.resolve(undefined);
        const { promise, resolve } = Promise.withResolvers<StreamChunk | undefined>();
        this.waiters.push(resolve);
        return promise;
    }

    close(): void {
        this.closed = true;
        for (const waiter of this.waiters.splice(0)) waiter(undefined);
    }

    drain(): StreamChunk[] {
        return this.items.splice(0);
    }
}

/**
 * dsh llm adapter backed by the GitHub Copilot SDK. One Copilot session per
 * `stream()` call; deltas are forwarded live, block-ends deferred until the
 * session goes idle (mirroring the DeepSeek adapter's chunk protocol).
 */
export class CopilotLlmAdapter extends LlmAdapter {
    constructor(private readonly clientProvider: () => Promise<CopilotClientLike>) {
        super();
    }

    providerInfo(_provider: string): { id: string; name: string } {
        return { id: COPILOT_PROVIDER, name: "GitHub Copilot" };
    }

    async listModels(provider: string): Promise<LlmModelInfo[]> {
        const models = await (await this.clientProvider()).listModels();
        return models.map((model) => ({ provider, id: model.id, name: model.name }));
    }

    async resolveModel(provider: string, model: string, signal?: AbortSignal): Promise<LlmResolvedModelInfo> {
        const models = await (await this.clientProvider()).listModels();
        if (signal?.aborted) {
            throw new LlmError("copilot: model resolution aborted", "ABORTED", { cause: signal.reason });
        }
        const found = models.find((candidate) => candidate.id === model);
        return {
            provider,
            id: model,
            name: found?.name ?? model,
            ...(found === undefined
                ? {}
                : { context: { contextWindow: found.capabilities.limits.max_context_window_tokens } }),
        };
    }

    private sessionConfig(options: GenerateOptions): SessionConfig {
        return {
            model: options.model,
            streaming: true,
            onPermissionRequest: denyToolPermissions,
            ...(options.system === undefined ? {} : { systemMessage: { content: options.system } }),
        };
    }

    async *stream(options: GenerateOptions): AsyncGenerator<StreamChunk, void, undefined> {
        const prompt = renderPrompt(options);
        if (prompt === "") {
            yield {
                type: "finish",
                reason: {
                    kind: "error",
                    failure: { message: "copilot: no renderable content in the request messages", code: EMPTY_RESPONSE_CODE },
                },
            };
            return;
        }

        let session: CopilotSessionLike;
        try {
            const client = await this.clientProvider();
            session = await client.createSession(this.sessionConfig(options));
        } catch (error) {
            throw new LlmError(
                `copilot: cannot start a Copilot session: ${error instanceof Error ? error.message : String(error)}`,
                "PROVIDER_ERROR",
                { cause: error instanceof Error ? error : undefined },
            );
        }

        const queue = new ChunkQueue();
        let reasoningIndex: number | undefined;
        let textIndex: number | undefined;
        let reasoningContent = "";
        let textContent = "";
        let nextIndex = 0;

        const offReasoning = session.on("assistant.reasoning_delta", (event) => {
            if (reasoningIndex === undefined) {
                reasoningIndex = nextIndex++;
                queue.push({ type: "block-start", index: reasoningIndex, blockType: "reasoning" });
            }
            reasoningContent += event.data.deltaContent;
            queue.push({ type: "reasoning-delta", index: reasoningIndex, text: event.data.deltaContent });
        });
        const offDelta = session.on("assistant.message_delta", (event) => {
            if (textIndex === undefined) {
                textIndex = nextIndex++;
                queue.push({ type: "block-start", index: textIndex, blockType: "text" });
            }
            textContent += event.data.deltaContent;
            queue.push({ type: "text-delta", index: textIndex, text: event.data.deltaContent });
        });

        const signal = options.signal;
        const { promise: abortPromise, resolve: resolveAbort } = Promise.withResolvers<typeof ABORTED_MARKER>();
        const onAbort = (): void => {
            resolveAbort(ABORTED_MARKER);
        };
        if (signal?.aborted) {
            onAbort();
        } else {
            signal?.addEventListener("abort", onAbort, { once: true });
        }

        const finalPromise = session.sendAndWait({ prompt });

        try {
            while (true) {
                const outcome = await Promise.race([
                    queue.shift(),
                    finalPromise.then(
                        () => undefined,
                        (error: unknown) => {
                            throw new LlmError(
                                `copilot: session failed: ${error instanceof Error ? error.message : String(error)}`,
                                "PROVIDER_ERROR",
                                { cause: error instanceof Error ? error : undefined },
                            );
                        },
                    ),
                    abortPromise,
                ]);
                if (outcome === undefined) break;
                if ("aborted" in outcome) {
                    // Swallow the abandoned wait; abort()/disconnect() tear the session down.
                    finalPromise.catch(() => {});
                    await session.abort().catch(() => {});
                    yield {
                        type: "finish",
                        reason: { kind: "aborted", failure: { message: "request aborted", code: "ABORTED" } },
                    };
                    return;
                }
                yield outcome;
            }

            // Detach the listeners before assembling block-ends so a late
            // delta cannot land between the final drain and the block-end.
            offReasoning();
            offDelta();

            for (const chunk of queue.drain()) yield chunk;

            if (reasoningIndex === undefined && textIndex === undefined) {
                yield {
                    type: "finish",
                    reason: {
                        kind: "error",
                        failure: { message: "Copilot returned a completed response with no content", code: EMPTY_RESPONSE_CODE },
                    },
                };
                return;
            }
            if (reasoningIndex !== undefined) {
                yield { type: "block-end", index: reasoningIndex, block: { type: "reasoning", text: reasoningContent } };
            }
            if (textIndex !== undefined) {
                yield { type: "block-end", index: textIndex, block: { type: "text", text: textContent } };
            }
            yield { type: "finish", reason: { kind: "stop" } };
        } finally {
            signal?.removeEventListener("abort", onAbort);
            offReasoning();
            offDelta();
            queue.close();
            await session.disconnect().catch(() => {});
        }
    }
}
