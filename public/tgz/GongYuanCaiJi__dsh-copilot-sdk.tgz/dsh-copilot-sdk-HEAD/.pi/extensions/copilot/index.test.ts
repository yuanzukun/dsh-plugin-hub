/*---------------------------------------------------------------------------------------------
 *  dsh-copilot-sdk plugin entry tests (dsh port additions).
 *--------------------------------------------------------------------------------------------*/

import { describe, expect, it, vi } from "vitest";
import type { ModelInfo } from "dsh-copilot-sdk";
import { applyCopilotBridge } from "./index.ts";
import type { CopilotClientLike, CopilotSessionLike } from "./adapter.ts";

const MODEL_GPT5: ModelInfo = {
  id: "gpt-5",
  name: "GPT-5",
  capabilities: {
    supports: { vision: false, reasoningEffort: true },
    limits: { max_context_window_tokens: 400_000 },
  },
};

class FakeClient implements CopilotClientLike {
  started = 0;
  stopped = 0;
  constructor(readonly models: ModelInfo[] = [MODEL_GPT5]) {}

  async start(): Promise<void> {
    this.started += 1;
  }

  async createSession(): Promise<CopilotSessionLike> {
    throw new Error("not used in plugin tests");
  }

  async listModels(): Promise<ModelInfo[]> {
    return this.models;
  }

  async stop(): Promise<Error[]> {
    this.stopped += 1;
    return [];
  }
}

interface FakeCommand {
  name: string;
  description: string;
  handler: (invocation: { rawInput?: string }) => Promise<{ kind: string; text: string }>;
}

function makeFakeCtx() {
  const registeredAdapters: Array<{ providers: string[]; adapter: unknown }> = [];
  const registeredCommands: FakeCommand[] = [];
  const effects: Array<() => unknown> = [];
  const ctx = {
    llm: {
      registerAdapter(providers: string[], adapter: unknown) {
        registeredAdapters.push({ providers, adapter });
        return { replace() {} };
      },
    },
    commands: {
      register(command: FakeCommand) {
        registeredCommands.push(command);
      },
    },
    inject(_services: string[], callback: (ctx: unknown) => void) {
      callback(ctx);
    },
    effect(fn: () => unknown) {
      effects.push(fn);
      return () => {};
    },
  };
  return { ctx, registeredAdapters, registeredCommands, effects };
}

async function runCommand(command: FakeCommand, rawInput: string) {
  return command.handler({ rawInput });
}

describe("dsh-copilot-sdk plugin entry", () => {
  it("registers the copilot llm provider adapter", () => {
    const { ctx, registeredAdapters } = makeFakeCtx();
    applyCopilotBridge(ctx as never, async () => new FakeClient());
    expect(registeredAdapters).toHaveLength(1);
    expect(registeredAdapters[0].providers).toEqual(["copilot"]);
  });

  it("registers the /copilot command", () => {
    const { ctx, registeredCommands } = makeFakeCtx();
    applyCopilotBridge(ctx as never, async () => new FakeClient());
    expect(registeredCommands.map((command) => command.name)).toEqual(["copilot"]);
  });

  it("status starts the client lazily and reports the model count", async () => {
    const { ctx, registeredCommands } = makeFakeCtx();
    const client = new FakeClient();
    const factory = vi.fn(async () => {
      await client.start();
      return client;
    });
    applyCopilotBridge(ctx as never, factory);

    expect(factory).not.toHaveBeenCalled();
    expect(client.started).toBe(0);
    const result = await runCommand(registeredCommands[0], "status");
    expect(factory).toHaveBeenCalledTimes(1);
    expect(client.started).toBe(1);
    expect(result.kind).toBe("success");
    expect(result.text).toContain("Models available: 1");
  });

  it("models lists the subscription models", async () => {
    const { ctx, registeredCommands } = makeFakeCtx();
    applyCopilotBridge(ctx as never, async () => new FakeClient());
    const result = await runCommand(registeredCommands[0], "models");
    expect(result.kind).toBe("success");
    expect(result.text).toContain("gpt-5");
  });

  it("stop shuts the client down", async () => {
    const { ctx, registeredCommands } = makeFakeCtx();
    const client = new FakeClient();
    applyCopilotBridge(ctx as never, async () => client);

    await runCommand(registeredCommands[0], "status");
    expect(client.stopped).toBe(0);
    await runCommand(registeredCommands[0], "stop");
    expect(client.stopped).toBe(1);
  });

  it("tears the client down on plugin disposal", async () => {
    const { ctx, effects, registeredCommands } = makeFakeCtx();
    const client = new FakeClient();
    applyCopilotBridge(ctx as never, async () => client);

    await runCommand(registeredCommands[0], "status");
    expect(effects.length).toBeGreaterThan(0);
    const cleanup = effects[0]() as () => Promise<void>;
    await cleanup();
    expect(client.stopped).toBe(1);
  });

  it("retries a failed client start on the next call instead of pinning the rejection", async () => {
    const { ctx, registeredCommands } = makeFakeCtx();
    const client = new FakeClient();
    let calls = 0;
    const factory = vi.fn(async () => {
      calls += 1;
      if (calls === 1) throw new Error("CLI spawn failed");
      await client.start();
      return client;
    });
    applyCopilotBridge(ctx as never, factory);

    const first = await runCommand(registeredCommands[0], "status");
    expect(first.kind).toBe("error");
    expect(first.text).toContain("CLI spawn failed");

    const second = await runCommand(registeredCommands[0], "status");
    expect(second.kind).toBe("success");
    expect(factory).toHaveBeenCalledTimes(2);
    expect(client.started).toBe(1);
  });

  it("rejects unknown subcommands instead of falling through to status", async () => {
    const { ctx, registeredCommands } = makeFakeCtx();
    applyCopilotBridge(ctx as never, async () => new FakeClient());
    const result = await runCommand(registeredCommands[0], "frobnicate");
    expect(result.kind).toBe("error");
    expect(result.text).toContain("Unknown subcommand");
    expect(result.text).toContain("status | models | stop");
  });

  it("status reports an error text when the client cannot start", async () => {
    const { ctx, registeredCommands } = makeFakeCtx();
    applyCopilotBridge(ctx as never, async () => {
      throw new Error("no Copilot subscription");
    });
    const result = await runCommand(registeredCommands[0], "status");
    expect(result.kind).toBe("error");
    expect(result.text).toContain("no Copilot subscription");
  });
});
