/*---------------------------------------------------------------------------------------------
 *  dsh-copilot-sdk bridge tests (dsh port additions; upstream has no equivalent).
 *--------------------------------------------------------------------------------------------*/

import { describe, expect, it } from "vitest";
import { createAssistantMessage, createToolResultMessage, createUserMessage, EMPTY_RESPONSE_CODE } from "@deepseek-ai/dsh-llm";
import type { GenerateOptions, StreamChunk } from "@deepseek-ai/dsh-llm";
import type { AssistantMessageEvent, ModelInfo, SessionConfig } from "dsh-copilot-sdk";
import { CopilotLlmAdapter, renderPrompt } from "./adapter.ts";

// ---------------------------------------------------------------------------
// Minimal fake of the CopilotClient / CopilotSession surface the adapter uses.
// Deliberately NOT an identity stub: it records every call and emits scripted
// events, so wiring mistakes (feeding `options` instead of the rendered
// prompt, listening to the wrong event names, forgetting the deny handler)
// fail these tests instead of passing silently.
// ---------------------------------------------------------------------------

class FakeSession {
  readonly sent: Array<{ prompt: string }> = [];
  aborted = false;
  disconnected = false;
  private handlers = new Map<string, Array<(event: unknown) => void>>();

  constructor(readonly config: SessionConfig) {}

  on(eventType: string, handler: (event: unknown) => void): () => void {
    const list = this.handlers.get(eventType) ?? [];
    list.push(handler);
    this.handlers.set(eventType, list);
    return () => {
      this.handlers.set(
        eventType,
        (this.handlers.get(eventType) ?? []).filter((candidate) => candidate !== handler),
      );
    };
  }

  private async emit(eventType: string, data: Record<string, unknown>): Promise<void> {
    for (const handler of this.handlers.get(eventType) ?? []) {
      handler({ type: eventType, data, id: "evt", parentId: null, timestamp: "t", ephemeral: true });
    }
  }

  async sendAndWait(options: { prompt: string }): Promise<AssistantMessageEvent | undefined> {
    this.sent.push(options);
    await this.emit("assistant.message_start", { messageId: "m1" });
    await this.emit("assistant.message_delta", { messageId: "m1", deltaContent: "Hello" });
    await this.emit("assistant.message_delta", { messageId: "m1", deltaContent: " world" });
    return { type: "assistant.message", id: "m1", parentId: null, timestamp: "t", data: { id: "m1", messageId: "m1", content: "Hello world" } } as AssistantMessageEvent;
  }

  async abort(): Promise<void> {
    this.aborted = true;
  }

  async disconnect(): Promise<void> {
    this.disconnected = true;
  }
}

class FakeCopilotClient {
  readonly created: SessionConfig[] = [];
  readonly sessions: FakeSession[] = [];

  constructor(readonly models: ModelInfo[] = []) {}

  async createSession(config: SessionConfig): Promise<FakeSession> {
    this.created.push(config);
    const session = new FakeSession(config);
    this.sessions.push(session);
    return session;
  }

  async listModels(): Promise<ModelInfo[]> {
    return this.models;
  }

  async stop(): Promise<Error[]> {
    return [];
  }
}

const MODEL_GPT5: ModelInfo = {
  id: "gpt-5",
  name: "GPT-5",
  capabilities: {
    supports: { vision: false, reasoningEffort: true },
    limits: { max_context_window_tokens: 400_000, max_prompt_tokens: 200_000 },
  },
};

function makeOptions(overrides: Partial<GenerateOptions> = {}): GenerateOptions {
  return {
    provider: "copilot",
    model: "gpt-5",
    messages: [
      createUserMessage({ content: [{ type: "text", text: "hello" }], source: { kind: "user" } }),
    ],
    ...overrides,
  };
}

async function collect(adapter: CopilotLlmAdapter, options: GenerateOptions): Promise<StreamChunk[]> {
  const chunks: StreamChunk[] = [];
  for await (const chunk of adapter.stream(options)) chunks.push(chunk);
  return chunks;
}

// ---------------------------------------------------------------------------
// renderPrompt: dsh conversation history → one Copilot prompt string.
// ---------------------------------------------------------------------------

describe("renderPrompt", () => {
  it("renders user and assistant text turns with role labels", () => {
    const options = makeOptions({
      messages: [
        createUserMessage({ content: [{ type: "text", text: "hello" }], source: { kind: "user" } }),
        createAssistantMessage({
          content: [{ type: "text", text: "hi there" }],
          source: { provider: "copilot", model: "gpt-5" },
        }),
      ],
    });
    expect(renderPrompt(options)).toBe("user: hello\n\nassistant: hi there");
  });

  it("renders tool results as user-role text", () => {
    const options = makeOptions({
      messages: [
        createToolResultMessage({
          callId: "call-1" as never,
          content: [{ type: "text", text: "exit code 0" }],
          isError: false,
        }),
      ],
    });
    expect(renderPrompt(options)).toBe("tool result: exit code 0");
  });

  it("skips system-role messages (system travels via options.system)", () => {
    const options = makeOptions({
      system: "Be terse.",
      messages: [
        { role: "system", content: [{ type: "text", text: "Be terse." }] } as never,
        createUserMessage({ content: [{ type: "text", text: "hello" }], source: { kind: "user" } }),
      ],
    });
    expect(renderPrompt(options)).toBe("user: hello");
  });

  it("skips messages that carry no renderable text", () => {
    const options = makeOptions({ messages: [] });
    expect(renderPrompt(options)).toBe("");
  });
});

// ---------------------------------------------------------------------------
// CopilotLlmAdapter.
// ---------------------------------------------------------------------------

describe("CopilotLlmAdapter", () => {
  it("describes the provider route as copilot", () => {
    const client = new FakeCopilotClient();
    const adapter = new CopilotLlmAdapter(async () => client as never);
    expect(adapter.providerInfo("copilot")).toEqual({ id: "copilot", name: "GitHub Copilot" });
  });

  it("maps listModels to LlmModelInfo under the copilot route", async () => {
    const client = new FakeCopilotClient([MODEL_GPT5]);
    const adapter = new CopilotLlmAdapter(async () => client as never);
    const models = await adapter.listModels("copilot");
    expect(models).toEqual([
      {
        provider: "copilot",
        id: "gpt-5",
        name: "GPT-5",
      },
    ]);
  });

  it("resolves exact model metadata with context", async () => {
    const client = new FakeCopilotClient([MODEL_GPT5]);
    const adapter = new CopilotLlmAdapter(async () => client as never);
    const resolved = await adapter.resolveModel("copilot", "gpt-5", undefined);
    expect(resolved).toMatchObject({ provider: "copilot", id: "gpt-5", name: "GPT-5" });
    expect(resolved.context?.contextWindow).toBe(400_000);
  });

  it("creates a streaming session that denies tool permission requests", async () => {
    const client = new FakeCopilotClient();
    const adapter = new CopilotLlmAdapter(async () => client as never);
    const chunks = await collect(adapter, makeOptions());

    expect(client.created).toHaveLength(1);
    const config = client.created[0];
    expect(config.model).toBe("gpt-5");
    expect(config.streaming).toBe(true);
    // The deny handler must be wired: the bridge runs Copilot as a chat
    // model, so the CLI must never execute tools on dsh's behalf.
    expect(config.onPermissionRequest).toBeTypeOf("function");
    const decision = await config.onPermissionRequest?.({ kind: "shell" } as never, { sessionId: "s" } as never);
    expect(decision).toEqual({ kind: "reject" });

    expect(chunks.length).toBeGreaterThan(0);
  });

  it("passes the system prompt as an appended system message section", async () => {
    const client = new FakeCopilotClient();
    const adapter = new CopilotLlmAdapter(async () => client as never);
    await collect(adapter, makeOptions({ system: "You are a terse assistant." }));

    expect(client.created[0].systemMessage).toEqual({ content: "You are a terse assistant." });
  });

  it("feeds the rendered conversation history to session.sendAndWait", async () => {
    const client = new FakeCopilotClient();
    const adapter = new CopilotLlmAdapter(async () => client as never);
    await collect(adapter, makeOptions());

    const session = client.sessions[0];
    expect(session.sent).toHaveLength(1);
    expect(session.sent[0].prompt).toBe(renderPrompt(makeOptions()));
  });

  it("finishes with an error without creating a session when the prompt renders empty", async () => {
    const client = new FakeCopilotClient();
    const adapter = new CopilotLlmAdapter(async () => client as never);
    const chunks = await collect(adapter, makeOptions({ messages: [] }));

    expect(client.created).toHaveLength(0);
    expect(chunks).toEqual([
      {
        type: "finish",
        reason: { kind: "error", failure: { message: "copilot: no renderable content in the request messages", code: EMPTY_RESPONSE_CODE } },
      },
    ]);
  });

  it("streams assistant deltas as text chunks and closes with the full text", async () => {
    const client = new FakeCopilotClient();
    const adapter = new CopilotLlmAdapter(async () => client as never);
    const chunks = await collect(adapter, makeOptions());

    expect(chunks).toEqual([
      { type: "block-start", index: 0, blockType: "text" },
      { type: "text-delta", index: 0, text: "Hello" },
      { type: "text-delta", index: 0, text: " world" },
      { type: "block-end", index: 0, block: { type: "text", text: "Hello world" } },
      { type: "finish", reason: { kind: "stop" } },
    ]);
  });

  it("aborts the SDK session and finishes with aborted when the signal fires", async () => {
    const client = new FakeCopilotClient();
    const adapter = new CopilotLlmAdapter(async () => client as never);
    const controller = new AbortController();
    const iterator = adapter.stream(makeOptions({ signal: controller.signal }))[Symbol.asyncIterator]();

    const first = await iterator.next();
    expect(first.value?.type).toBe("block-start");
    controller.abort();

    const chunks: StreamChunk[] = [];
    for (let result = await iterator.next(); !result.done; result = await iterator.next()) {
      if (result.value) chunks.push(result.value);
      if (result.value?.type === "finish") break;
    }
    expect(chunks.some((chunk) => chunk.type === "text-delta")).toBe(true);
    expect(chunks[chunks.length - 1]).toEqual({
      type: "finish",
      reason: { kind: "aborted", failure: { message: "request aborted", code: "ABORTED" } },
    });
    expect(client.sessions[0].aborted).toBe(true);
  });

  it("disconnects the session after the stream completes", async () => {
    const client = new FakeCopilotClient();
    const adapter = new CopilotLlmAdapter(async () => client as never);
    await collect(adapter, makeOptions());
    expect(client.sessions[0].disconnected).toBe(true);
  });
});
