# dsh-copilot-sdk

<p align="center">
  <b>简体中文</b> | <a href="#english">English</a>
</p>

<p align="center">
  <a href="https://github.com/GongYuanCaiJi/dsh-copilot-sdk/blob/main/LICENSE"><img alt="License: MIT" src="https://img.shields.io/badge/license-MIT-blue.svg"></a>
  <a href="https://www.npmjs.com/package/@github/copilot-sdk"><img alt="upstream: @github/copilot-sdk" src="https://img.shields.io/badge/port%20of-%40github%2Fcopilot--sdk-orange"></a>
</p>

**把 GitHub Copilot 订阅接进 DeepSeek Harness：一个 `copilot` LLM provider，直接使用你订阅里的模型（GPT、Claude、DeepSeek……），SDK 库与测试套件 100% 逐字移植自上游。**

本插件是 [`@github/copilot-sdk`](https://www.npmjs.com/package/@github/copilot-sdk)（MIT，[github/copilot-sdk](https://github.com/github/copilot-sdk)）的 **dsh 移植**（port），版本钉在 `1.0.11`（commit `18002a81`）。SDK 库本体与上游逐字一致（见 [THIRD_PARTY_NOTICES.md](./THIRD_PARTY_NOTICES.md) 的 SHA-256 校验）；`.pi/` 下的桥接层是本移植自己的代码。喜欢的话，[也请给上游一个 star](https://github.com/github/copilot-sdk) ⭐

## 功能

- **Copilot 订阅即模型池**：注册 `copilot` provider，订阅里可用的模型（`gpt-5`、`claude-sonnet-4.5`、`deepseek-r1` 等）直接出现在 dsh 的模型列表里
- **复刻 Copilot CLI 引擎**：SDK 自带 Copilot CLI runtime，无需单独安装 CLI；认证走你已有的 GitHub 登录 / token / BYOK
- **纯聊天桥接**：桥接层拒绝一切工具执行请求——Copilot 的 shell、文件编辑等工具绝不会在你的机器上代跑
- **流式输出**：assistant 文本与 reasoning（思维链）增量实时转发
- **`/copilot` 命令**：`status` 查看连接与模型数、`models` 列出可用模型、`stop` 停掉 CLI runtime
- **100% 逐字移植**：SDK 库、docs、samples、测试套件（含离线 replay 的 e2e）全部原样保留，`npm test` 全绿

## 效果

```text
dsh 会话中
   └─ 模型选择器里出现 copilot / gpt-5、copilot / claude-sonnet-4.5 …
        └─ /copilot status
             Copilot bridge: connected.
             Provider: copilot
             Models available: 8
             Requires a GitHub Copilot subscription (or BYOK …)
```

- 每次模型调用对应一个一次性 Copilot 会话：订阅计费走 Copilot 的计费模型（每次 prompt 计入用量）
- 无 Copilot 订阅时也可以用 BYOK（Bring Your Own Key），见下方 FAQ

## 安装

> 尚未发布到 npm —— 从 GitHub 或本地目录安装：

```bash
# GitHub 源（安装时 prepare 会执行 build）
dsh plugin --profile <你的-profile> add github:GongYuanCaiJi/dsh-copilot-sdk

# 本地路径（先在该目录 npm install）
dsh plugin --profile <你的-profile> add /path/to/dsh-copilot-sdk
```

pnpm 默认阻止 git 安装的构建脚本（`prepare`）。如果 `add` 报 `allowBuilds` 错误，
把 pnpm 打印的精确 key 加进 profile 的 `pnpm-workspace.yaml` 的 `allowBuilds` 再重试；
本插件的原生依赖（`koffi` FFI）可能被连带拦截，同样放行后重跑。

安装后重启 dsh。插件按需拉起 Copilot CLI（首次模型调用 / `/copilot status` 时），
不需要订阅之外的任何配置。

## 使用

**dsh 侧命令：** `/copilot status` `/copilot models` `/copilot stop`

**作为模型 provider：** 安装后，会话的模型选择器里会出现 `copilot` provider
及其订阅模型（也可在 agent 配置里指定 `provider: copilot` + 具体模型 id）。

### 配置

全部走环境变量（与上游 SDK 一致）：

- `COPILOT_GITHUB_TOKEN` / `GH_TOKEN` / `GITHUB_TOKEN` —— GitHub 认证 token（缺省用 `copilot` CLI 的已登录用户）
- BYOK：在 session/agent 配置里用 SDK 的 provider 配置指定你自己的 API key（OpenAI / Anthropic / 其他）

## FAQ

- **需要 Copilot 订阅吗？** 需要（含免费额度档），除非用 BYOK。
- **桥接会执行 Copilot 的工具吗？** 不会。桥接层把所有权限请求判为拒绝，Copilot 只作为聊天模型回答。
- **模型调用怎么计费？** 与 Copilot CLI 相同，每次 prompt 计入你的 Copilot 用量。
- **SDK 完整 API 可用吗？** 可用。库本身是逐字移植，API 与上游 `@github/copilot-sdk` 一致；
  完整 API 参考见[上游 README](https://github.com/github/copilot-sdk/blob/main/nodejs/README.md) 与 `docs/`。

## License

MIT —— 见 [LICENSE](./LICENSE)。上游为 [github/copilot-sdk](https://github.com/github/copilot-sdk)（MIT）。

授权 / 合规询问 → [GitHub issues](https://github.com/GongYuanCaiJi/dsh-copilot-sdk/issues)。

**遥测说明：** 上游 SDK 自带 telemetry 代码（`src/telemetry.ts` 与 GitHub telemetry 转发），
本移植逐字保留、未删改。本插件的桥接层不传入 telemetry options、也不注册 handler，
因此**默认不发送**；若你自行构造 `CopilotClient` 并启用，则以上游行为为准。

---

<a name="english"></a>

# dsh-copilot-sdk

<p align="center">
  <a href="#dsh-copilot-sdk">简体中文</a> | <b>English</b>
</p>

<p align="center">
  <a href="https://github.com/GongYuanCaiJi/dsh-copilot-sdk/blob/main/LICENSE"><img alt="License: MIT" src="https://img.shields.io/badge/license-MIT-blue.svg"></a>
  <a href="https://www.npmjs.com/package/@github/copilot-sdk"><img alt="upstream: @github/copilot-sdk" src="https://img.shields.io/badge/port%20of-%40github%2Fcopilot--sdk-orange"></a>
</p>

**Bring your GitHub Copilot subscription into DeepSeek Harness: a `copilot` LLM provider that serves the models in your subscription (GPT, Claude, DeepSeek, …), with the SDK library and test suite ported 100% verbatim from upstream.**

This plugin is a **dsh port** of [`@github/copilot-sdk`](https://www.npmjs.com/package/@github/copilot-sdk)
(MIT, [github/copilot-sdk](https://github.com/github/copilot-sdk)), pinned to
`1.0.11` (commit `18002a81`). The SDK library is byte-identical to upstream
(see [THIRD_PARTY_NOTICES.md](./THIRD_PARTY_NOTICES.md) for SHA-256 checks);
the bridge under `.pi/` is this port's own code. If you like it,
[star the upstream too](https://github.com/github/copilot-sdk) ⭐

## Features

- **Your Copilot subscription as a model pool**: a `copilot` provider whose models
  (`gpt-5`, `claude-sonnet-4.5`, `deepseek-r1`, …) show up in dsh's model list
- **The Copilot CLI engine, embedded**: the SDK bundles the Copilot CLI runtime —
  no separate CLI install; auth via your existing GitHub login / token / BYOK
- **Chat-only bridge**: every tool permission request is denied — Copilot's shell,
  file-edit, and other tools never run on your machine
- **Streaming**: assistant text and reasoning deltas are forwarded live
- **`/copilot` command**: `status` (connection + model count), `models` (list), `stop` (shut the CLI down)
- **100% verbatim port**: SDK library, docs, samples, and the full test suite
  (including offline-replay e2e) kept as-is; `npm test` is green

## Preview

```text
Inside a dsh session
   └─ model selector shows copilot / gpt-5, copilot / claude-sonnet-4.5 …
        └─ /copilot status
             Copilot bridge: connected.
             Provider: copilot
             Models available: 8
             Requires a GitHub Copilot subscription (or BYOK …)
```

- Each model call uses a fresh one-shot Copilot session; billing follows Copilot's
  own model (each prompt counts toward your usage allowance)
- No subscription? BYOK (Bring Your Own Key) works too — see FAQ

## Install

> Not published to npm yet — install from GitHub or a local checkout:

```bash
# GitHub source (prepare runs the build on install)
dsh plugin --profile <your-profile> add github:GongYuanCaiJi/dsh-copilot-sdk

# Local path (run `npm install` in the plugin directory first)
dsh plugin --profile <your-profile> add /path/to/dsh-copilot-sdk
```

pnpm blocks git-hosted installs from running the `prepare` build script until
allowed — if `add` fails with an `allowBuilds` error, add the exact key pnpm
printed under `allowBuilds` in the profile's `pnpm-workspace.yaml`, then re-run.
The native dependency (`koffi` FFI) may be blocked next; allow it the same way.

Restart dsh after installing. The plugin starts the Copilot CLI on demand
(first model call / `/copilot status`); no config beyond your existing GitHub auth.

## Usage

**dsh-side commands:** `/copilot status` `/copilot models` `/copilot stop`

**As a model provider:** after install, the session model selector shows the
`copilot` provider and its subscription models (or set `provider: copilot` plus
the model id in your agent config).

### Configuration

All via environment variables (same as the upstream SDK):

- `COPILOT_GITHUB_TOKEN` / `GH_TOKEN` / `GITHUB_TOKEN` — GitHub auth token (defaults to the logged-in `copilot` CLI user)
- BYOK: use the SDK's provider config with your own API key (OpenAI / Anthropic / others) in the session/agent config

## FAQ

- **Is a Copilot subscription required?** Yes (free tier included), unless you use BYOK.
- **Does the bridge execute Copilot's tools?** No. All permission requests are
  denied; Copilot runs purely as a chat model.
- **How is usage billed?** Same as Copilot CLI — each prompt counts toward your Copilot usage.
- **Is the full SDK API available?** Yes. The library is a verbatim port, so the
  API matches upstream `@github/copilot-sdk`; full API reference is in the
  [upstream README](https://github.com/github/copilot-sdk/blob/main/nodejs/README.md) and `docs/`.

## License

MIT — see [LICENSE](./LICENSE). Upstream: [github/copilot-sdk](https://github.com/github/copilot-sdk) (MIT).

License / compliance enquiries → [GitHub issues](https://github.com/GongYuanCaiJi/dsh-copilot-sdk/issues).

**Telemetry:** the upstream SDK ships telemetry code (`src/telemetry.ts` and GitHub
telemetry forwarding), kept verbatim in this port. This plugin's bridge passes no
telemetry options and registers no handler, so it **sends nothing by default**; if you
construct a `CopilotClient` yourself and enable it, upstream behaviour applies.
