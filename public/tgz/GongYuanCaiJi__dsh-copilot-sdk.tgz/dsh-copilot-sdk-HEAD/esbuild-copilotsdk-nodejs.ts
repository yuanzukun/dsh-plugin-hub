import * as esbuild from "esbuild";
import { globSync } from "glob";
import { execSync } from "child_process";

const entryPoints = globSync("src/**/*.ts");

// ESM build
await esbuild.build({
    entryPoints,
    outbase: "src",
    outdir: "dist",
    format: "esm",
    platform: "node",
    target: "es2022",
    sourcemap: false,
    outExtension: { ".js": ".js" },
});

// CJS build — uses .js extension with a "type":"commonjs" package.json marker
await esbuild.build({
    entryPoints,
    outbase: "src",
    outdir: "dist/cjs",
    format: "cjs",
    platform: "node",
    target: "es2022",
    sourcemap: false,
    outExtension: { ".js": ".js" },
    logOverride: { "empty-import-meta": "silent" },
});

// dsh plugin entry: bundle the bridge (`.pi/extensions/copilot`) into a
// single ESM file under dist/plugin so the installed package (node_modules)
// never needs Node type-stripping — raw .ts entries fail with
// ERR_UNSUPPORTED_NODE_MODULES_TYPE_STRIPPING once pnpm places the package
// under node_modules. Package imports stay external (resolved at runtime
// from this package's own dependencies / self-reference).
await esbuild.build({
    entryPoints: [".pi/extensions/copilot/index.ts"],
    outdir: "dist/plugin",
    format: "esm",
    platform: "node",
    target: "es2022",
    sourcemap: false,
    bundle: true,
    packages: "external",
    outExtension: { ".js": ".js" },
});

// Mark the CJS directory so Node treats .js files as CommonJS
import { writeFileSync } from "fs";
writeFileSync("dist/cjs/package.json", JSON.stringify({ type: "commonjs" }) + "\n");

// Generate .d.ts files
execSync("tsc", { stdio: "inherit" });
