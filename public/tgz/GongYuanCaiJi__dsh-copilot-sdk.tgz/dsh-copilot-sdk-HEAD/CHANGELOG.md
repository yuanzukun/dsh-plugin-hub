# Changelog

## 1.0.11 (2026-08-15)

- Port of `@github/copilot-sdk@1.0.11` (commit `18002a81`) as a DeepSeek
  Harness plugin: SDK library and test suite copied verbatim.
- dsh bridge: register a `copilot` llm provider that runs the GitHub Copilot
  subscription as a chat model (`/copilot status | models | stop`).
- Requires a GitHub Copilot subscription (or BYOK); tool execution inside the
  Copilot runtime is denied — the bridge never lets Copilot touch the machine.
