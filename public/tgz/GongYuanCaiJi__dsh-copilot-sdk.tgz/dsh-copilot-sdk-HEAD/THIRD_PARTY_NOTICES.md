# Third Party Notices

`dsh-copilot-sdk` is a port of the **`@github/copilot-sdk`** Node.js/TypeScript
SDK (the `nodejs/` package of the [`github/copilot-sdk`](https://github.com/github/copilot-sdk)
monorepo), MIT licensed. The SDK library and its test suite are copied verbatim;
the dsh bridge (`.pi/extensions/copilot/`) is this port's own addition.

## Upstream pin

| | |
|---|---|
| npm package | `@github/copilot-sdk` |
| version | `1.0.11` |
| published | 2026-08-14 |
| tarball integrity | `sha512-ngrnfa9052fLTOMoY0iiQS2B6pFDYJpWNj3syCdjzdje0R5mWoij9b8exJZciLvX7BbJjKz2/lIdwo24av3e3A==` |
| tarball shasum | `6605d21a133641b2080cce5c6ea1444f00925732` |
| source commit (this port was copied from) | `18002a81fa52d006589b813441f98b53e118fe8a` |

## Verbatim library files (SHA-256)

The complete SDK library under `src/` is byte-identical to the pinned commit:

```
88a1309e42ad81a8572b3d28033e53aa5ba15e520378311e33b38beade17d358  src/canvas.ts
1d9a52ca4cd5315bbb769c19df69e3bc33f833f29451fbbebaa0a27a147a5ff1  src/client.ts
1aed8eebeee9173e25acac18c69e2f3bcc6e298b0d11dfe6a6b861b4d169730b  src/copilotRequestHandler.ts
d871b815b5b902419dcd71b39718df74e2e44caf1e1a998265b2741b7c68d78b  src/extension.ts
f98f68fe9bfda3af4e2de3a212bc3219cb9dbb628985d915e1f331d52cceba2d  src/factory.ts
879ced0894d4a7b2601ae7d57846eb7f29a8f284636128565e8a850acbba29c6  src/ffiRuntimeHost.ts
878457b7ed0568b21d892298a235e758151016c85d1f3369de6fb7daff3deb51  src/generated/rpc.ts
a3e21d21e037cd4c45f852594338d1cadea20eab1b2823163c06bc0eff4aa6a2  src/generated/session-events.ts
d12da8d3cb3768533491fb05761edbe5916084d68ac29c8ddcea9d45c84d8d1f  src/index.ts
8d5ba19e1239d79188e8c43104a1ee29064aede101d405fa7345cb4eda5af5af  src/sdkProtocolVersion.ts
02e9035f9ee18e9dd0001bdeb3f9f91f6dff6768ffc0cc874a8ef1bce8d228d4  src/session.ts
5d710fb7a6d2b419801406d6800b3355c679d4401a1c49e6a5990d1d56eed8af  src/sessionFsProvider.ts
6d654deec297f2731d3c749a163d2e5714157693e479c714e9dc2e8c146e8ce1  src/telemetry.ts
05bdebb33139f668908c37f17c3d88c882a46f0a17414a2483af7e1acf297f8d  src/toolSet.ts
815286f7541b9bf210f51f0c62618e2a977ed66ef5b93312b3572f79078e2595  src/types.ts
```

Verify:

```bash
cd /path/to/dsh-copilot-sdk
shasum -a 256 src/*.ts src/generated/*.ts | sort -k2 > /tmp/actual.sha
grep -E '^[0-9a-f]{64}  ' THIRD_PARTY_NOTICES.md | sort -k2 > /tmp/claimed.sha
diff /tmp/claimed.sha /tmp/actual.sha && echo 'ALL VERBATIM HASHES MATCH'
```

（舊版用 `awk '{print $1}'` 抽整份文件的欄位當 regex，會產生空 alternation，`grep -E` 匹配一切——被竄改的檔案也照樣「通過」。現在改為只抽 hash 行、逐一 diff。）

## Whole-tree verbatim check

Everything else copied from upstream (docs/, samples/, examples/, scripts/,
test/ fixtures and harness, the monorepo-root `test/harness`, `test/snapshots`,
`scripts/codegen`, `sdk-protocol-version.json`) is also byte-identical to the
pinned commit, with the exception of the port's documented adaptations
(relative-path depth fixes in 14 test files and
`scripts/update-protocol-version.ts`, `vitest.config.ts`
harness exclude, `tsconfig.test.json` additions,
`esbuild-copilotsdk-nodejs.ts` plugin-entry bundle,
`package.json`/`package-lock.json` port identity and dsh wiring).
Verify the whole claim:

```bash
git clone https://github.com/github/copilot-sdk.git /tmp/copilot-sdk-upstream
git -C /tmp/copilot-sdk-upstream checkout 18002a81fa52d006589b813441f98b53e118fe8a
# 1. SDK library + docs/samples/examples: must be byte-identical
diff -rq /tmp/copilot-sdk-upstream/nodejs/src    /path/to/dsh-copilot-sdk/src
diff -rq /tmp/copilot-sdk-upstream/nodejs/docs   /path/to/dsh-copilot-sdk/docs
diff -rq /tmp/copilot-sdk-upstream/nodejs/samples /path/to/dsh-copilot-sdk/samples
diff -rq /tmp/copilot-sdk-upstream/nodejs/examples /path/to/dsh-copilot-sdk/examples
# 2. monorepo-root trees (snapshots / harness / codegen): must be byte-identical
diff -rq /tmp/copilot-sdk-upstream/test/snapshots /path/to/dsh-copilot-sdk/test/snapshots
diff -rq /tmp/copilot-sdk-upstream/test/harness  /path/to/dsh-copilot-sdk/test/harness
diff -rq /tmp/copilot-sdk-upstream/scripts/codegen /path/to/dsh-copilot-sdk/scripts/codegen
diff -q  /tmp/copilot-sdk-upstream/sdk-protocol-version.json /path/to/dsh-copilot-sdk/sdk-protocol-version.json
# 3. nodejs test tree: only the 14 documented depth-fix files may differ
diff -rq /tmp/copilot-sdk-upstream/nodejs/test /path/to/dsh-copilot-sdk/test \
  | grep -vE 'Only in /path/to/dsh-copilot-sdk/test: (snapshots|harness|package-lock.json)' \
  | grep -vE '(disabled_mcp_servers|mcp_and_agents|mcp_oauth|multi_provider_registry|pre_mcp_tool_call_hook|rpc_mcp_and_skills|rpc_mcp_lifecycle|session|system_message_transform)\.e2e\.test\.ts|(session-event-codegen|shared-codegen|typescript-codegen)\.test\.ts|(CapiProxy|sdkTestContext)\.ts'
```

Commands 1–2 must produce no output. Command 3's remaining lines must
only be the 14 documented depth-fix test files (their `Files … differ` lines
are filtered out above by name; anything else is a real deviation).
