/** Pure task-episode, policy, tool-semantics, and verification-debt logic. */

export type TaskRelation =
  | 'new-objective'
  | 'continuation'
  | 'extension'
  | 'correction'
  | 'clarification'
  | 'review'
  | 'conversation'

export type TaskKind = 'build' | 'fix' | 'review' | 'analysis' | 'unknown'
export type AgentPhase = 'orient' | 'inspect' | 'design' | 'construct' | 'verify' | 'recover' | 'converge' | 'blocked'
export type RiskLevel = 'low' | 'medium' | 'high'
export type ToolEffect = 'observe' | 'mutate' | 'verify' | 'benchmark' | 'finish' | 'interact' | 'delegate' | 'unknown'

export interface TaskContract {
  readonly objective: string
  readonly relation: TaskRelation
  readonly kind: TaskKind
  readonly complexity: number
  readonly risk: RiskLevel
  readonly artifacts: readonly string[]
  readonly acceptance: readonly string[]
  readonly evidence: readonly string[]
}

export interface EpisodeContext {
  readonly objective: string
  readonly artifacts: ReadonlySet<string>
}

export interface ToolSemantics {
  readonly name: string
  readonly effect: ToolEffect
  readonly artifact?: string
  readonly operation?: string
  /** An unclassified shell command has a common workspace-mutation signature. */
  readonly riskyMutation?: boolean
  readonly signature: string
}

export interface VerificationDebt {
  readonly id: string
  readonly artifact: string
  /** Workspace revision that created this obligation. */
  readonly revision: number
  readonly requiresReadback: boolean
  readonly requiresCommand: boolean
  readback: boolean
  commandVerified: boolean
  readbackRevision?: number
  commandVerifiedRevision?: number
  waived: boolean
}

export interface ToolClassificationOptions {
  readonly benchmarkToolNames?: readonly string[]
  readonly verificationToolNames?: readonly string[]
  readonly finishToolNames?: readonly string[]
}

export interface BenchmarkResult {
  readonly totalQueries: number
  readonly recall: number
  readonly qps: number
  readonly concurrency?: number
  readonly warmup?: number
  /** A score may only be compared to another result with this exact key. */
  readonly specKey: string
}

export type BenchmarkComparison = 'improved' | 'within-tolerance' | 'regressed' | 'different-spec'

export interface BenchmarkComparisonResult {
  readonly outcome: BenchmarkComparison
  readonly deltaPercent?: number
}

export interface PolicyPlan {
  readonly relation: TaskRelation
  readonly phase: AgentPhase
  readonly restrictBeforeEvidence: boolean
  readonly hint: string
  readonly evidence: readonly string[]
}

const CHAT_RE = /^(?:你好|您好|hello|hi|hey|嗨|哈[喽啰]|在吗|谢谢|感谢|thanks|thank you|早上好|下午好|晚上好|嗯+|好(?:的)?|ok(?:ay)?|yes|no)[!！。.？?~～\s]*$/i
const CORRECTION_RE = /(修复|修一下|修正|改正|不对|错误|有问题|报错|异常|崩溃|失败|回归|bug|fix|debug|broken|wrong|incorrect|regression|crash|error)/i
const EXTENSION_RE = /(继续|接着|再加|增加|新增|扩展|补充|完善|基于.{0,8}(?:现有|刚才|上面)|extend|continue|add (?:a |an |the )?|build on|follow[- ]?up)/i
const CONTINUITY_RE = /(这个|那个|它|其中|刚才|之前|上面|现有|已有|同一|原来|当前|该文件|this|that|it|previous|existing|current|same)/i
const CLARIFICATION_RE = /^(?:是|不是|对|不对|可以|不可以|继续|不用|需要|不需要|yes|no|correct|continue|proceed|stop)(?:[，,。.!！\s].*)?$/i
const REVIEW_RE = /(审查|评审|检查|分析|解释|说明|总结|调研|查看|看看|review|audit|analy[sz]e|explain|summari[sz]e|survey|inspect)/i
const BUILD_RE = /(开发|创建|新建|生成|实现|搭建|构建|写(?:一个|个|出)?|做(?:一个|个|出)?|build|create|develop|generate|implement|write|make)/i
const FIX_RE = /(修复|修正|调试|排查|报错|异常|崩溃|回归|兼容|故障|fix|debug|repair|broken|regression|error|crash)/i
const HIGH_RISK_RE = /(删除|清空|覆盖全部|迁移|升级依赖|发布|部署|生产环境|凭据|密钥|数据库|权限|安全|大规模|全面重构|delete|drop|truncate|migrat|deploy|production|credential|secret|database|permission|security|large refactor)/i
const COMPLEX_RE = /(架构|重构|系统|全面|详细|设计|集成|边界|并发|性能|安全|迁移|调研|architecture|refactor|system|comprehensive|detailed|design|integration|concurren|performance|security|migration|survey)/i
const ANAPHORA_RE = /(这个|那个|它|刚才|之前|上面|现有|继续|再|this|that|it|previous|existing|continue|again)/i

const OBSERVE_TOOLS = new Set([
  'read', 'read_image', 'glob', 'grep', 'web_search', 'web_fetch', 'lsp', 'skill', 'list_agents',
])
const MUTATE_TOOLS = new Set(['write', 'edit'])
const INTERACT_TOOLS = new Set(['ask_user_question', 'exit_plan_mode'])
const DELEGATE_TOOLS = new Set(['subagent', 'subagent_fork', 'workflow', 'ralph'])
const VERIFY_COMMAND_RE = /(?:^|\s)(?:npm|pnpm|yarn|bun)\s+(?:run\s+)?(?:test|build|lint|typecheck|check)|\b(?:pytest|vitest|jest|mocha|tsc|cargo\s+test|go\s+test|dotnet\s+test|mvn\s+test|gradle\s+test|make\s+test)\b/i
const OBSERVE_COMMAND_RE = /(?:^|[;&|]\s*)(?:ls|dir|find|rg|grep|git\s+(?:status|diff|show|log)|sed\s+-n|head|tail|wc)\b/i
const RISKY_SHELL_MUTATION_RE = /(?:^|[;&|]\s*)(?:apply_patch|patch|tee|touch|mkdir|rmdir|rm|mv|cp|install|chmod|chown|sed\s+-i|perl\s+-i|git\s+(?:apply|checkout|restore|clean)|(?:npm|pnpm|yarn|bun)\s+(?:install|add|remove|update))\b|(?<![<&])>{1,2}(?![&>])/i
const SHELL_TOOLS = new Set(['bash', 'pwsh', 'terminal_send'])
const ARTIFACT_RE = /(?:^|[\s"'`(])((?:[A-Za-z]:[\\/])?[^\s"'`()]+?\.(?:[cm]?[jt]sx?|py|rs|go|java|kt|rb|php|cs|cpp|c|h|html?|css|scss|json|ya?ml|toml|md|txt|sql|sh|ps1))(?:$|[\s"'`),:.])/gi

export const DEFAULT_BENCHMARK_TOOL_NAMES = ['run_benchmark'] as const
export const DEFAULT_VERIFICATION_TOOL_NAMES = ['build_project', 'run_correctness_test'] as const
export const DEFAULT_FINISH_TOOL_NAMES = ['finish'] as const

function normalizeWhitespace(text: string): string {
  return text.replace(/\s+/g, ' ').trim()
}

function clamp01(value: number): number {
  return Math.max(0, Math.min(1, value))
}

function unique<T>(values: Iterable<T>): T[] {
  return [...new Set(values)]
}

function lexicalTokens(text: string): Set<string> {
  const words = text.toLowerCase().match(/[\p{L}\p{N}_-]{2,}/gu) ?? []
  return new Set(words.filter(word => !/^(?:please|help|this|that|with|from|then|一个|一下|帮我|这个|那个)$/.test(word)))
}

function jaccard(left: string, right: string): number {
  const a = lexicalTokens(left)
  const b = lexicalTokens(right)
  if (a.size === 0 || b.size === 0) return 0
  let overlap = 0
  for (const token of a) if (b.has(token)) overlap++
  return overlap / (a.size + b.size - overlap)
}

export function extractArtifacts(text: string): string[] {
  const matches: string[] = []
  for (const match of text.matchAll(ARTIFACT_RE)) {
    const artifact = match[1]?.replace(/[。.!！?？]+$/, '')
    if (artifact) matches.push(artifact)
  }
  return unique(matches)
}

function artifactOverlap(current: readonly string[], previous: ReadonlySet<string>): boolean {
  const normalizedPrevious = new Set([...previous].map(item => item.replaceAll('\\', '/').toLowerCase()))
  return current.some(item => normalizedPrevious.has(item.replaceAll('\\', '/').toLowerCase()))
}

function taskKind(text: string): TaskKind {
  const fix = FIX_RE.test(text)
  const build = BUILD_RE.test(text)
  if (fix && !build) return 'fix'
  if (build && !fix) return 'build'
  if (REVIEW_RE.test(text)) return /分析|analy[sz]e|调研|survey/i.test(text) ? 'analysis' : 'review'
  if (fix) return 'fix'
  if (build) return 'build'
  return 'unknown'
}

function riskLevel(text: string, complexity: number): RiskLevel {
  if (HIGH_RISK_RE.test(text) || complexity >= 0.82) return 'high'
  if (complexity >= 0.5) return 'medium'
  return 'low'
}

function complexityScore(text: string, artifacts: readonly string[]): number {
  let score = Math.min(0.35, text.length / 800)
  if (COMPLEX_RE.test(text)) score += 0.32
  if (artifacts.length > 1) score += Math.min(0.2, artifacts.length * 0.05)
  if (/\b(?:and|then|also|across|all)\b|并且|然后|同时|全部|多个/i.test(text)) score += 0.12
  if (HIGH_RISK_RE.test(text)) score += 0.16
  return clamp01(score)
}

function relationFor(
  text: string,
  artifacts: readonly string[],
  previous: EpisodeContext | undefined,
): TaskRelation {
  if (CHAT_RE.test(text)) return 'conversation'
  const prior = previous !== undefined && !CHAT_RE.test(previous.objective) ? previous : undefined
  if (prior && CLARIFICATION_RE.test(text)) return 'clarification'

  const overlap = prior ? artifactOverlap(artifacts, prior.artifacts) : false
  const continuity = prior !== undefined && (overlap || CONTINUITY_RE.test(text) || jaccard(text, prior.objective) >= 0.28)

  if (prior && CORRECTION_RE.test(text) && (continuity || ANAPHORA_RE.test(text))) return 'correction'
  if (prior && EXTENSION_RE.test(text)) return 'extension'
  if (prior && continuity) {
    if (CORRECTION_RE.test(text)) return 'correction'
    if (BUILD_RE.test(text)) return 'extension'
    if (REVIEW_RE.test(text)) return 'review'
    return 'continuation'
  }
  if (REVIEW_RE.test(text) && !BUILD_RE.test(text) && !FIX_RE.test(text)) return 'review'
  return 'new-objective'
}

function acceptanceFor(kind: TaskKind, relation: TaskRelation): string[] {
  if (relation === 'conversation') return []
  switch (kind) {
    case 'fix':
      return ['Inspect the current implementation before mutation', 'Correct the reported failure', 'Verify the corrected behavior']
    case 'build':
      return ['Create the requested deliverable', 'Verify the deliverable before concluding']
    case 'review':
    case 'analysis':
      return ['Ground findings in observed artifacts', 'Cover the requested scope without inventing facts']
    default:
      return ['Produce the requested outcome', 'Verify material claims or changes before concluding']
  }
}

export function classifyTaskContract(rawText: string, previous?: EpisodeContext): TaskContract {
  const objective = normalizeWhitespace(rawText).slice(0, 600)
  const artifacts = extractArtifacts(objective)
  const complexity = complexityScore(objective, artifacts)
  const kind = taskKind(objective)
  const relation = relationFor(objective, artifacts, previous)
  const evidence: string[] = []
  if (relation === 'correction' || relation === 'extension' || relation === 'continuation') {
    evidence.push('Preserve continuity with the existing artifact and inspect its current state before replacing it.')
  }
  if (kind === 'fix') evidence.push('Establish evidence about the failure before changing code.')
  if (kind === 'review' || kind === 'analysis') evidence.push('Use repository observations as the source of truth.')
  if (kind === 'build') evidence.push('Produce a usable artifact, then verify it.')
  return {
    objective,
    relation,
    kind,
    complexity,
    risk: riskLevel(objective, complexity),
    artifacts,
    acceptance: acceptanceFor(kind, relation),
    evidence,
  }
}

export function initialPhase(contract: TaskContract, planMode: boolean): AgentPhase {
  if (contract.relation === 'conversation') return 'converge'
  if (planMode) return contract.kind === 'build' ? 'design' : 'inspect'
  if (contract.relation === 'correction' || contract.relation === 'extension' || contract.relation === 'continuation') return 'inspect'
  if (contract.kind === 'fix' || contract.kind === 'review' || contract.kind === 'analysis') return 'inspect'
  if (contract.risk === 'high' || contract.complexity >= 0.68) return 'inspect'
  if (contract.kind === 'build') return 'construct'
  return 'orient'
}

export function policyPlan(contract: TaskContract, planMode: boolean, maxHintChars = 1200): PolicyPlan {
  const phase = initialPhase(contract, planMode)
  const restrictBeforeEvidence = !planMode && phase === 'inspect'
    && (contract.kind === 'fix' || ['correction', 'extension', 'continuation'].includes(contract.relation))

  const lines = [
    '<trajectory-policy>',
    `relation: ${contract.relation}`,
    `phase: ${phase}`,
    `risk: ${contract.risk}`,
  ]
  if (contract.artifacts.length > 0) lines.push(`artifacts: ${contract.artifacts.join(', ')}`)
  if (contract.acceptance.length > 0) {
    lines.push('acceptance:')
    for (const item of contract.acceptance) lines.push(`- ${item}`)
  }
  if (contract.evidence.length > 0) {
    lines.push('evidence_policy:')
    for (const item of contract.evidence) lines.push(`- ${item}`)
  }
  if (planMode) lines.push('plan_mode: preserve the active plan policy; do not execute mutations.')
  lines.push('</trajectory-policy>')
  const joined = lines.join('\n')
  return {
    relation: contract.relation,
    phase,
    restrictBeforeEvidence,
    hint: joined.length <= maxHintChars ? joined : `${joined.slice(0, maxHintChars - 1)}…`,
    evidence: contract.evidence,
  }
}

function stableJson(value: unknown): string {
  if (value === null || typeof value !== 'object') return JSON.stringify(value) ?? 'null'
  if (Array.isArray(value)) return `[${value.map(stableJson).join(',')}]`
  const object = value as Record<string, unknown>
  return `{${Object.keys(object).sort().map(key => `${JSON.stringify(key)}:${stableJson(object[key])}`).join(',')}}`
}

function firstString(record: Record<string, unknown>, names: readonly string[]): string | undefined {
  for (const name of names) {
    const value = record[name]
    if (typeof value === 'string' && value.trim()) return value
  }
  return undefined
}

function editorEffect(args: Record<string, unknown>): ToolEffect {
  const command = typeof args['command'] === 'string' ? args['command'].toLowerCase() : ''
  if (command === 'view') return 'observe'
  if (['create', 'str_replace', 'insert', 'undo_edit'].includes(command)) return 'mutate'
  return 'unknown'
}

function shellEffect(args: Record<string, unknown>): ToolEffect {
  const command = firstString(args, ['command', 'script']) ?? ''
  if (VERIFY_COMMAND_RE.test(command)) return 'verify'
  if (OBSERVE_COMMAND_RE.test(command)) return 'observe'
  return 'unknown'
}

function normalizedToolNames(names: readonly string[] | undefined, defaults: readonly string[]): Set<string> {
  return new Set((names ?? defaults).map(name => name.toLowerCase()))
}

export function classifyTool(
  name: string,
  rawArguments: unknown,
  options: ToolClassificationOptions = {},
): ToolSemantics {
  const args = typeof rawArguments === 'object' && rawArguments !== null && !Array.isArray(rawArguments)
    ? rawArguments as Record<string, unknown>
    : {}
  const normalizedName = name.toLowerCase()
  const benchmarkTools = normalizedToolNames(options.benchmarkToolNames, DEFAULT_BENCHMARK_TOOL_NAMES)
  const verificationTools = normalizedToolNames(options.verificationToolNames, DEFAULT_VERIFICATION_TOOL_NAMES)
  const finishTools = normalizedToolNames(options.finishToolNames, DEFAULT_FINISH_TOOL_NAMES)
  let effect: ToolEffect
  if (benchmarkTools.has(normalizedName)) effect = 'benchmark'
  else if (verificationTools.has(normalizedName)) effect = 'verify'
  else if (finishTools.has(normalizedName)) effect = 'finish'
  else if (OBSERVE_TOOLS.has(normalizedName) || /^(?:read|list|search|fetch|get)_/.test(normalizedName)) effect = 'observe'
  else if (MUTATE_TOOLS.has(normalizedName)) effect = 'mutate'
  else if (normalizedName === 'str_replace_editor') effect = editorEffect(args)
  else if (SHELL_TOOLS.has(normalizedName)) effect = shellEffect(args)
  else if (INTERACT_TOOLS.has(normalizedName)) effect = 'interact'
  else if (DELEGATE_TOOLS.has(normalizedName) || normalizedName.startsWith('subagent')) effect = 'delegate'
  else effect = 'unknown'

  const artifact = firstString(args, ['file_path', 'path', 'filename'])
  const operation = firstString(args, ['command', 'description', 'query'])
  const riskyMutation = effect === 'unknown'
    && SHELL_TOOLS.has(normalizedName)
    && operation !== undefined
    && RISKY_SHELL_MUTATION_RE.test(operation)
  return {
    name,
    effect,
    ...(artifact === undefined ? {} : { artifact }),
    ...(operation === undefined ? {} : { operation }),
    ...(riskyMutation ? { riskyMutation: true } : {}),
    signature: `${name}:${stableJson(args)}`,
  }
}

export function createVerificationDebt(
  semantics: ToolSemantics,
  sequence: number,
  revision = sequence,
): VerificationDebt | undefined {
  if (semantics.effect !== 'mutate' && !semantics.riskyMutation) return undefined
  const artifact = semantics.artifact ?? (semantics.riskyMutation ? '<shell-mutation>' : '<unknown-artifact>')
  const extension = /\.([^.\\/]+)$/.exec(artifact)?.[1]?.toLowerCase()
  const documentOnly = extension !== undefined && ['md', 'txt', 'rst', 'adoc'].includes(extension)
  return {
    id: `${sequence}:${artifact}`,
    artifact,
    revision,
    requiresReadback: artifact !== '<unknown-artifact>' && artifact !== '<shell-mutation>',
    requiresCommand: !documentOnly,
    readback: false,
    commandVerified: false,
    waived: false,
  }
}

export function debtSatisfied(debt: VerificationDebt, currentRevision = debt.revision): boolean {
  const readbackCurrent = debt.readback && (debt.readbackRevision ?? debt.revision) >= currentRevision
  const commandCurrent = debt.commandVerified && (debt.commandVerifiedRevision ?? debt.revision) >= currentRevision
  return debt.waived
    || (!debt.requiresReadback || readbackCurrent)
      && (!debt.requiresCommand || commandCurrent)
}

export function openDebts(debts: Iterable<VerificationDebt>, currentRevision?: number): VerificationDebt[] {
  return [...debts].filter(debt => !debtSatisfied(debt, currentRevision))
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value)
}

function numericValue(value: unknown): number | undefined {
  if (typeof value === 'number') return Number.isFinite(value) ? value : undefined
  if (typeof value !== 'string') return undefined
  const parsed = Number(value.trim().replace(/%$/, ''))
  return Number.isFinite(parsed) ? parsed : undefined
}

function recordNumber(record: Record<string, unknown>, names: readonly string[]): unknown {
  for (const name of names) {
    if (name in record) return record[name]
  }
  const normalized = new Set(names.map(name => name.toLowerCase()))
  return Object.entries(record).find(([name]) => normalized.has(name.toLowerCase()))?.[1]
}

function normalizedRecall(value: unknown): number | undefined {
  const raw = numericValue(value)
  if (raw === undefined) return undefined
  const recall = raw > 1 && raw <= 100 ? raw / 100 : raw
  return recall >= 0 && recall <= 1 ? recall : undefined
}

function positiveInteger(value: unknown): number | undefined {
  const numeric = numericValue(value)
  return numeric !== undefined && Number.isSafeInteger(numeric) && numeric > 0 ? numeric : undefined
}

function nonNegativeInteger(value: unknown): number | undefined {
  const numeric = numericValue(value)
  return numeric !== undefined && Number.isSafeInteger(numeric) && numeric >= 0 ? numeric : undefined
}

function positiveNumber(value: unknown): number | undefined {
  const numeric = numericValue(value)
  return numeric !== undefined && numeric > 0 ? numeric : undefined
}

function benchmarkFromValues(
  totalQueriesValue: unknown,
  recallValue: unknown,
  qpsValue: unknown,
  concurrencyValue: unknown,
  warmupValue: unknown,
): BenchmarkResult | undefined {
  const totalQueries = positiveInteger(totalQueriesValue)
  const recall = normalizedRecall(recallValue)
  const qps = positiveNumber(qpsValue)
  if (totalQueries === undefined || recall === undefined || qps === undefined) return undefined

  const concurrency = concurrencyValue === undefined ? undefined : positiveInteger(concurrencyValue)
  const warmup = warmupValue === undefined ? undefined : nonNegativeInteger(warmupValue)
  if (concurrencyValue !== undefined && concurrency === undefined) return undefined
  if (warmupValue !== undefined && warmup === undefined) return undefined

  const result = {
    totalQueries,
    recall,
    qps,
    ...(concurrency === undefined ? {} : { concurrency }),
    ...(warmup === undefined ? {} : { warmup }),
  }
  return { ...result, specKey: benchmarkSpecKey(result) }
}

function benchmarkFromRecord(record: Record<string, unknown>): BenchmarkResult | undefined {
  return benchmarkFromValues(
    recordNumber(record, ['total_queries', 'totalQueries', 'query_count', 'queryCount', 'queries']),
    recordNumber(record, ['recall', 'recall_at_k', 'recallAtK', 'recall@10']),
    recordNumber(record, ['qps', 'queries_per_second', 'queriesPerSecond']),
    recordNumber(record, ['concurrency', 'threads', 'workers']),
    recordNumber(record, ['warmup', 'warmup_queries', 'warmupQueries']),
  )
}

function benchmarkRecords(value: unknown): Record<string, unknown>[] {
  const records: Record<string, unknown>[] = []
  const queue: unknown[] = [value]
  const seen = new Set<object>()
  while (queue.length > 0 && records.length < 32) {
    const current = queue.shift()
    if (Array.isArray(current)) {
      for (const item of current) queue.push(item)
      continue
    }
    if (!isRecord(current) || seen.has(current)) continue
    seen.add(current)
    records.push(current)
    for (const key of ['result', 'metrics', 'benchmark', 'data', 'summary']) {
      if (key in current) queue.push(current[key])
    }
  }
  return records
}

function parseJsonCandidates(text: string): unknown[] {
  const candidates: unknown[] = []
  const trimmed = text.trim()
  if (trimmed) {
    try {
      candidates.push(JSON.parse(trimmed))
    } catch {
      // Text output may still contain one fenced or line-delimited JSON record.
    }
  }
  for (const match of text.matchAll(/```(?:json)?\s*([\s\S]*?)```/gi)) {
    try {
      candidates.push(JSON.parse(match[1] ?? ''))
    } catch {
      // Continue scanning; one malformed fence must not hide a later record.
    }
  }
  for (const line of text.split('\n')) {
    const candidate = line.trim()
    if (!candidate.startsWith('{') || !candidate.endsWith('}')) continue
    try {
      candidates.push(JSON.parse(candidate))
    } catch {
      // This line is not a complete JSON object.
    }
  }
  return candidates
}

function textMetric(text: string, names: readonly string[]): string | undefined {
  const pattern = new RegExp(
    `(?:^|[\\s,;{])(?:${names.map(name => name.replace(/[.*+?^${}()|[\\]\\\\]/g, '\\$&')).join('|')})\\s*[:=]\\s*["']?([0-9]+(?:\\.[0-9]+)?%?)`,
    'im',
  )
  return pattern.exec(text)?.[1]
}

function benchmarkFromText(text: string): BenchmarkResult | undefined {
  return benchmarkFromValues(
    textMetric(text, ['total_queries', 'total queries', 'totalQueries', 'query_count', 'queries']),
    textMetric(text, ['recall', 'recall_at_k', 'recall@10']),
    textMetric(text, ['qps', 'queries_per_second', 'queries per second']),
    textMetric(text, ['concurrency', 'threads', 'workers']),
    textMetric(text, ['warmup', 'warmup_queries', 'warmup queries']),
  )
}

/**
 * Parse only a complete, named benchmark result. A prose claim such as
 * "performance improved" is intentionally not accepted as benchmark evidence.
 */
export function parseBenchmarkResult(content: string, meta?: unknown): BenchmarkResult | undefined {
  const candidates = [
    ...(meta === undefined ? [] : [meta]),
    ...parseJsonCandidates(content),
  ]
  for (const candidate of candidates) {
    for (const record of benchmarkRecords(candidate)) {
      const result = benchmarkFromRecord(record)
      if (result !== undefined) return result
    }
  }
  return benchmarkFromText(content)
}

export function benchmarkSpecKey(result: Pick<BenchmarkResult, 'totalQueries' | 'concurrency' | 'warmup'>): string {
  return [
    `total_queries=${result.totalQueries}`,
    `concurrency=${result.concurrency ?? 'unspecified'}`,
    `warmup=${result.warmup ?? 'unspecified'}`,
  ].join(';')
}

export function isFullBenchmark(
  result: BenchmarkResult,
  minQueries: number,
  minRecall: number,
): boolean {
  return result.totalQueries >= minQueries && result.recall >= minRecall
}

export function compareBenchmarkResults(
  candidate: BenchmarkResult,
  baseline: BenchmarkResult,
  tolerancePercent: number,
): BenchmarkComparisonResult {
  if (candidate.specKey !== baseline.specKey) return { outcome: 'different-spec' }
  if (baseline.qps <= 0) return { outcome: 'improved', deltaPercent: Number.POSITIVE_INFINITY }
  const deltaPercent = ((candidate.qps - baseline.qps) / baseline.qps) * 100
  if (candidate.qps > baseline.qps) return { outcome: 'improved', deltaPercent }
  if (deltaPercent >= -Math.max(0, tolerancePercent)) return { outcome: 'within-tolerance', deltaPercent }
  return { outcome: 'regressed', deltaPercent }
}

/** DSH shell tools can surface a non-zero process exit in text without isError. */
export function hasCommandFailure(content: string): boolean {
  const match = /(?:\[\s*)?(?:exit[ _-]?code)\s*:\s*([0-9]+)(?:\s*\])?/i.exec(content)
  return match !== null && Number(match[1]) !== 0
}

/** 400 invalid-request failures are deterministic request-shape failures, not retry candidates. */
export function isTerminalLlmFailure(failure: unknown): boolean {
  if (!isRecord(failure)) return false
  const status = numericValue(failure.status)
  const code = typeof failure.code === 'string' ? failure.code.toLowerCase() : ''
  return status === 400 || /(?:^|[_-])invalid[_-]?request[_-]?error(?:$|[_-])/.test(code)
}

export function verificationHint(
  debts: Iterable<VerificationDebt>,
  maxHintChars = 1200,
  currentRevision?: number,
): string {
  const open = openDebts(debts, currentRevision)
  const lines = [
    '<trajectory-policy>',
    'phase: verify',
    'verification_debt:',
  ]
  for (const debt of open) {
    const requiredRevision = currentRevision ?? debt.revision
    const needs = [
      ...debt.requiresReadback && (!debt.readback || (debt.readbackRevision ?? debt.revision) < requiredRevision)
        ? ['read back the final artifact'] : [],
      ...debt.requiresCommand && (!debt.commandVerified || (debt.commandVerifiedRevision ?? debt.revision) < requiredRevision)
        ? ['run a relevant test/build/check'] : [],
    ]
    lines.push(`- ${debt.artifact}: ${needs.join(' and ')}`)
  }
  lines.push('Do not claim completion until these obligations are satisfied or a concrete blocker is reported.')
  lines.push('</trajectory-policy>')
  const joined = lines.join('\n')
  return joined.length <= maxHintChars ? joined : `${joined.slice(0, maxHintChars - 1)}…`
}

export function recoveryHint(maxHintChars = 1200): string {
  const text = [
    '<trajectory-policy>',
    'phase: recover',
    'The latest action failed or repeated without new information. Re-read the latest result, change the approach or arguments, and avoid repeating the same call unchanged.',
    '</trajectory-policy>',
  ].join('\n')
  return text.length <= maxHintChars ? text : `${text.slice(0, maxHintChars - 1)}…`
}

export function mutationToolNames(availableNames: Iterable<string>, hasDedicatedObserver: boolean): string[] {
  if (!hasDedicatedObserver) return []
  const available = new Set(availableNames)
  const denied = ['write', 'edit'].filter(name => available.has(name))
  // str_replace_editor is hybrid. Restrict it only when a dedicated read tool
  // remains; otherwise a Minimal surface would lose both observation and edit.
  if (available.has('str_replace_editor') && available.has('read')) denied.push('str_replace_editor')
  return denied
}

export function hasObservationCapability(availableNames: Iterable<string>): boolean {
  const available = new Set(availableNames)
  return ['read', 'read_image', 'glob', 'grep', 'web_search', 'web_fetch', 'lsp'].some(name => available.has(name))
}

export function foldPlanMode(events: readonly { type: string; data: unknown }[]): boolean {
  let active = false
  for (const event of events) {
    if (event.type !== 'plan/mode') continue
    const data = event.data as { active?: unknown }
    if (typeof data.active === 'boolean') active = data.active
  }
  return active
}
