/**
 * Closed-loop trajectory policy plane for DeepSeek Harness.
 *
 * The governor keeps the deployment persona and runtime contexts intact. It
 * observes claimed human input before prompt assembly, injects reconstructable
 * near-field policy messages at agent/pre-step, applies scoped capability
 * restrictions through ToolRuntime, and closes verification debt from durable
 * Native and Code Mode tool events.
 */

import type { Context } from '@deepseek-ai/cordis'
import z from '@deepseek-ai/schemastery'
import type { Agent, PreStepDecision } from '@deepseek-ai/dsh-agent'
import { createUserMessage, ReasoningEffortId } from '@deepseek-ai/dsh-llm'
import type { ContentBlock, LlmCallConfig, LlmResolvedModelInfo, UserMessage } from '@deepseek-ai/dsh-llm'
import type { Session } from '@deepseek-ai/dsh-session'
import { defineTool } from '@deepseek-ai/dsh-tools'
import type {} from '@deepseek-ai/dsh-system-prompt'
import type {} from '@deepseek-ai/dsh-plan-mode'
import { homedir } from 'node:os'
import { join } from 'node:path'
import {
  DEFAULT_BENCHMARK_TOOL_NAMES,
  DEFAULT_FINISH_TOOL_NAMES,
  DEFAULT_VERIFICATION_TOOL_NAMES,
  classifyTaskContract,
  classifyTool,
  compareBenchmarkResults,
  createVerificationDebt,
  debtSatisfied,
  foldPlanMode,
  hasCommandFailure,
  hasObservationCapability,
  isFullBenchmark,
  isTerminalLlmFailure,
  mutationToolNames,
  openDebts,
  parseBenchmarkResult,
  policyPlan,
  recoveryHint,
  verificationHint,
} from './core.js'
import type {
  AgentPhase,
  BenchmarkResult,
  EpisodeContext,
  PolicyPlan,
  TaskContract,
  ToolClassificationOptions,
  ToolSemantics,
  VerificationDebt,
} from './core.js'
import { DecisionLedger, fingerprint } from './ledger.js'

export * from './core.js'

export const name = 'trajectory-governor'
export const inject = ['agents', 'sessions', 'systemPrompt', 'tools', 'llm']

export type GovernorMode = 'off' | 'shadow' | 'active'

export interface Config {
  /** off = inert; shadow = decide and log only; active = apply policy. */
  mode?: GovernorMode
  /** Adapt the routed model's reasoning effort during inspect/design/recover phases. */
  adaptiveReasoning?: boolean
  /** Temporarily hide known dedicated mutation tools until one observation succeeds. */
  restrictBeforeEvidence?: boolean
  /** Add at most maxAutomaticContinuations verification turns for open debt. */
  autoVerify?: boolean
  maxAutomaticContinuations?: number
  /** Repeated/no-novel-result threshold that enters recovery. */
  noInformationLimit?: number
  /** Register trajectory_policy_status as a model-facing diagnostic. */
  exposeStatusTool?: boolean
  /** Persist privacy-minimized state/action/outcome JSONL outside Session history. */
  ledger?: boolean
  ledgerPath?: string
  /** Rotate the active JSONL ledger before it grows beyond this many bytes. */
  maxLedgerBytes?: number
  maxHintChars?: number
  /** Require a parseable full benchmark before finish/natural completion. */
  benchmarkRequired?: boolean
  benchmarkToolNames?: string[]
  verificationToolNames?: string[]
  finishToolNames?: string[]
  fullBenchmarkMinQueries?: number
  fullBenchmarkMinRecall?: number
  benchmarkScoreTolerancePercent?: number
  /** Prompt for benchmark evidence after this many successful actions without it. */
  maxActionsWithoutBenchmark?: number
  /** Surface a plateau after this many same-spec full results without material gain. */
  maxStagnantFullBenchmarks?: number
  /** Stop an adapter retry loop for deterministic 400 / invalid_request_error failures. */
  stopRetryOnDeterministicErrors?: boolean
  /** Bound non-authoritative result and benchmark history retained per agent. */
  maxTrackedResults?: number
}

export const Config: z<Config> = z.object({
  mode: z.union(['off', 'shadow', 'active'] as const).default('active'),
  adaptiveReasoning: z.boolean().default(false),
  restrictBeforeEvidence: z.boolean().default(true),
  autoVerify: z.boolean().default(true),
  maxAutomaticContinuations: z.natural().default(1),
  noInformationLimit: z.natural().min(2).default(3),
  exposeStatusTool: z.boolean().default(true),
  ledger: z.boolean().default(true),
  ledgerPath: z.string(),
  maxLedgerBytes: z.natural().min(1024).default(10 * 1024 * 1024),
  maxHintChars: z.natural().min(240).default(1200),
  benchmarkRequired: z.boolean().default(false),
  benchmarkToolNames: z.array(z.string()).default([...DEFAULT_BENCHMARK_TOOL_NAMES]),
  verificationToolNames: z.array(z.string()).default([...DEFAULT_VERIFICATION_TOOL_NAMES]),
  finishToolNames: z.array(z.string()).default([...DEFAULT_FINISH_TOOL_NAMES]),
  fullBenchmarkMinQueries: z.natural().min(1).default(10_000),
  fullBenchmarkMinRecall: z.number().min(0).max(1).default(0.95),
  benchmarkScoreTolerancePercent: z.number().min(0).max(100).default(2),
  maxActionsWithoutBenchmark: z.natural().min(1).default(8),
  maxStagnantFullBenchmarks: z.natural().min(1).default(2),
  stopRetryOnDeterministicErrors: z.boolean().default(true),
  maxTrackedResults: z.natural().min(8).default(256),
})

interface RestrictionState {
  readonly denied: readonly string[]
  readonly dispose: () => void
}

interface CallState {
  readonly semantics: ToolSemantics
  readonly seq: number
}

interface AssemblySnapshot {
  readonly hash: string
  readonly sectionNames: readonly string[]
  readonly toolNames: readonly string[]
}

interface BenchmarkRecord {
  readonly result: BenchmarkResult
  readonly revision: number
  readonly sequence: number
}

interface AgentPolicyState {
  readonly agent: Agent
  episodeNumber: number
  humanMessages: number
  contract?: TaskContract
  plan?: PolicyPlan
  phase: AgentPhase
  planMode: boolean
  policyRevision: number
  injectedRevision: number
  pendingHint: string | undefined
  readonly artifacts: Set<string>
  readonly observedArtifacts: Set<string>
  readonly mutatedArtifacts: Set<string>
  readonly resultFingerprints: Set<string>
  readonly debts: Map<string, VerificationDebt>
  readonly calls: Map<string, CallState>
  readonly bestBenchmarks: Map<string, BenchmarkRecord>
  readonly automaticContinuations: Map<number, number>
  readonly blockerReports: Set<number>
  restriction: RestrictionState | undefined
  finishGuard: (() => void) | undefined
  noInformationStreak: number
  lastCallSignature: string | undefined
  repeatedCallCount: number
  effortOverrideApplied: boolean
  workspaceRevision: number
  benchmarkSeen: boolean
  currentBenchmarkRevision: number | undefined
  latestBenchmark: BenchmarkRecord | undefined
  benchmarkBlocker: string | undefined
  actionsWithoutBenchmark: number
  stagnantFullBenchmarks: number
  recoveryBlocker: string | undefined
  blockedReason: string | undefined
  assembly?: AssemblySnapshot
}

const DEFAULTS: Required<Omit<Config, 'ledgerPath'>> = {
  mode: 'active',
  adaptiveReasoning: false,
  restrictBeforeEvidence: true,
  autoVerify: true,
  maxAutomaticContinuations: 1,
  noInformationLimit: 3,
  exposeStatusTool: true,
  ledger: true,
  maxLedgerBytes: 10 * 1024 * 1024,
  maxHintChars: 1200,
  benchmarkRequired: false,
  benchmarkToolNames: [...DEFAULT_BENCHMARK_TOOL_NAMES],
  verificationToolNames: [...DEFAULT_VERIFICATION_TOOL_NAMES],
  finishToolNames: [...DEFAULT_FINISH_TOOL_NAMES],
  fullBenchmarkMinQueries: 10_000,
  fullBenchmarkMinRecall: 0.95,
  benchmarkScoreTolerancePercent: 2,
  maxActionsWithoutBenchmark: 8,
  maxStagnantFullBenchmarks: 2,
  stopRetryOnDeterministicErrors: true,
  maxTrackedResults: 256,
}

function resolvedConfig(config: Config): Required<Omit<Config, 'ledgerPath'>> & { ledgerPath: string } {
  const dshHome = process.env.DSH_HOME || join(homedir(), '.dsh')
  return {
    mode: config.mode ?? DEFAULTS.mode,
    adaptiveReasoning: config.adaptiveReasoning ?? DEFAULTS.adaptiveReasoning,
    restrictBeforeEvidence: config.restrictBeforeEvidence ?? DEFAULTS.restrictBeforeEvidence,
    autoVerify: config.autoVerify ?? DEFAULTS.autoVerify,
    maxAutomaticContinuations: config.maxAutomaticContinuations ?? DEFAULTS.maxAutomaticContinuations,
    noInformationLimit: config.noInformationLimit ?? DEFAULTS.noInformationLimit,
    exposeStatusTool: config.exposeStatusTool ?? DEFAULTS.exposeStatusTool,
    ledger: config.ledger ?? DEFAULTS.ledger,
    ledgerPath: config.ledgerPath ?? join(dshHome, 'trajectory-governor', 'decisions.jsonl'),
    maxLedgerBytes: config.maxLedgerBytes ?? DEFAULTS.maxLedgerBytes,
    maxHintChars: config.maxHintChars ?? DEFAULTS.maxHintChars,
    benchmarkRequired: config.benchmarkRequired ?? DEFAULTS.benchmarkRequired,
    benchmarkToolNames: config.benchmarkToolNames ?? DEFAULTS.benchmarkToolNames,
    verificationToolNames: config.verificationToolNames ?? DEFAULTS.verificationToolNames,
    finishToolNames: config.finishToolNames ?? DEFAULTS.finishToolNames,
    fullBenchmarkMinQueries: config.fullBenchmarkMinQueries ?? DEFAULTS.fullBenchmarkMinQueries,
    fullBenchmarkMinRecall: config.fullBenchmarkMinRecall ?? DEFAULTS.fullBenchmarkMinRecall,
    benchmarkScoreTolerancePercent: config.benchmarkScoreTolerancePercent ?? DEFAULTS.benchmarkScoreTolerancePercent,
    maxActionsWithoutBenchmark: config.maxActionsWithoutBenchmark ?? DEFAULTS.maxActionsWithoutBenchmark,
    maxStagnantFullBenchmarks: config.maxStagnantFullBenchmarks ?? DEFAULTS.maxStagnantFullBenchmarks,
    stopRetryOnDeterministicErrors: config.stopRetryOnDeterministicErrors ?? DEFAULTS.stopRetryOnDeterministicErrors,
    maxTrackedResults: config.maxTrackedResults ?? DEFAULTS.maxTrackedResults,
  }
}

function newState(agent: Agent): AgentPolicyState {
  return {
    agent,
    episodeNumber: 0,
    humanMessages: 0,
    phase: 'orient',
    planMode: foldPlanMode(agent.session.events),
    policyRevision: 0,
    injectedRevision: 0,
    pendingHint: undefined,
    artifacts: new Set(),
    observedArtifacts: new Set(),
    mutatedArtifacts: new Set(),
    resultFingerprints: new Set(),
    debts: new Map(),
    calls: new Map(),
    bestBenchmarks: new Map(),
    automaticContinuations: new Map(),
    blockerReports: new Set(),
    restriction: undefined,
    finishGuard: undefined,
    noInformationStreak: 0,
    lastCallSignature: undefined,
    repeatedCallCount: 0,
    effortOverrideApplied: false,
    workspaceRevision: 0,
    benchmarkSeen: false,
    currentBenchmarkRevision: undefined,
    latestBenchmark: undefined,
    benchmarkBlocker: undefined,
    actionsWithoutBenchmark: 0,
    stagnantFullBenchmarks: 0,
    recoveryBlocker: undefined,
    blockedReason: undefined,
  }
}

function normalizePath(value: string): string {
  return value.replaceAll('\\', '/').toLowerCase()
}

function sameArtifact(left: string, right: string): boolean {
  const a = normalizePath(left)
  const b = normalizePath(right)
  return a === b || a.endsWith(`/${b}`) || b.endsWith(`/${a}`)
}

function contentText(content: readonly ContentBlock[]): string {
  return content.map((block) => {
    switch (block.type) {
      case 'text':
      case 'reasoning':
        return block.text
      case 'tool-result':
        return contentText(block.content)
      default:
        return `[${block.type}]`
    }
  }).join('\n')
}

function parseArguments(raw: string): unknown {
  try {
    return JSON.parse(raw)
  } catch {
    return {}
  }
}

function pluginMessage(text: string, purpose: string): UserMessage {
  return createUserMessage({
    content: [{ type: 'text', text }],
    source: { kind: 'plugin', plugin: `trajectory-governor/${purpose}` },
  })
}

function insertAfterLastHuman(messages: UserMessage[], inserted: UserMessage): UserMessage[] {
  const output = [...messages]
  const index = output.findLastIndex(message => message.source.kind === 'user')
  output.splice(index < 0 ? output.length : index + 1, 0, inserted)
  return output
}

function constructHint(contract: TaskContract, maxChars: number): string {
  const text = [
    '<trajectory-policy>',
    `relation: ${contract.relation}`,
    'phase: construct',
    contract.relation === 'correction' || contract.relation === 'extension' || contract.relation === 'continuation'
      ? 'Current-state evidence was obtained. Make a minimal change that preserves the existing artifact and prior accepted behavior.'
      : 'Produce the requested artifact directly from the established evidence.',
    'After any mutation, verify the final artifact and relevant behavior before concluding.',
    '</trajectory-policy>',
  ].join('\n')
  return text.length <= maxChars ? text : `${text.slice(0, maxChars - 1)}…`
}

function planModeOf(session: Session): boolean {
  return foldPlanMode(session.events)
}

function effortRank(id: string, index: number): number {
  const value = id.toLowerCase()
  if (value === 'max') return 100
  if (value === 'xhigh') return 90
  if (value === 'high') return 80
  if (value === 'medium') return 60
  if (value === 'low') return 40
  if (value === 'off' || value === 'none' || value === 'disabled') return 0
  return 50 + index
}

function deepestEffort(info: LlmResolvedModelInfo): string | undefined {
  const efforts = info.reasoning?.efforts
  if (!efforts || efforts.length === 0) return undefined
  return [...efforts]
    .sort((a, b) => effortRank(String(b.id), efforts.indexOf(b)) - effortRank(String(a.id), efforts.indexOf(a)))
    .find(effort => effortRank(String(effort.id), efforts.indexOf(effort)) > 0)?.id
}

function deepPhase(phase: AgentPhase): boolean {
  return phase === 'inspect' || phase === 'design' || phase === 'recover'
}

function addBoundedSet<T>(set: Set<T>, value: T, limit: number): void {
  set.delete(value)
  set.add(value)
  while (set.size > limit) {
    const oldest = set.values().next()
    if (oldest.done) break
    set.delete(oldest.value)
  }
}

function setBoundedMap<K, V>(map: Map<K, V>, key: K, value: V, limit: number): void {
  map.delete(key)
  map.set(key, value)
  while (map.size > limit) {
    const oldest = map.keys().next()
    if (oldest.done) break
    map.delete(oldest.value)
  }
}

function truncateHint(text: string, maxChars: number): string {
  return text.length <= maxChars ? text : `${text.slice(0, maxChars - 1)}…`
}

function percent(value: number): string {
  return `${value.toFixed(2)}%`
}

export function apply(ctx: Context, inputConfig: Config = {}): void {
  const config = resolvedConfig(inputConfig)
  const states = new Map<Agent, AgentPolicyState>()
  const sessionStates = new WeakMap<Session, AgentPolicyState>()
  const modelInfo = new Map<string, Promise<LlmResolvedModelInfo>>()
  const ledger = new DecisionLedger({
    enabled: config.ledger,
    path: config.ledgerPath,
    maxBytes: config.maxLedgerBytes,
  })
  const toolClassification: ToolClassificationOptions = {
    benchmarkToolNames: config.benchmarkToolNames,
    verificationToolNames: config.verificationToolNames,
    finishToolNames: config.finishToolNames,
  }

  const stateFor = (agent: Agent): AgentPolicyState => {
    let state = states.get(agent)
    if (state === undefined) {
      state = newState(agent)
      states.set(agent, state)
      sessionStates.set(agent.session, state)
    }
    return state
  }

  const currentOpenDebts = (state: AgentPolicyState): VerificationDebt[] => {
    return openDebts(state.debts.values(), state.workspaceRevision)
  }

  const pruneSatisfiedDebts = (state: AgentPolicyState): void => {
    for (const [id, debt] of state.debts) {
      if (debtSatisfied(debt, state.workspaceRevision)) state.debts.delete(id)
    }
  }

  const benchmarkGateActive = (state: AgentPolicyState): boolean => {
    return config.benchmarkRequired || state.benchmarkSeen
  }

  const hasCurrentFullBenchmark = (state: AgentPolicyState): boolean => {
    return state.currentBenchmarkRevision === state.workspaceRevision
  }

  const benchmarkGateBlocker = (state: AgentPolicyState): string | undefined => {
    if (!benchmarkGateActive(state) || hasCurrentFullBenchmark(state)) return undefined
    return state.benchmarkBlocker
      ?? `Current workspace revision ${state.workspaceRevision} has no parseable full benchmark pass (total_queries >= ${config.fullBenchmarkMinQueries}, recall >= ${config.fullBenchmarkMinRecall}).`
  }

  const completionBlockers = (state: AgentPolicyState): string[] => {
    const blockers = currentOpenDebts(state).map(debt => `Verification debt remains for ${debt.artifact}.`)
    const benchmarkBlocker = benchmarkGateBlocker(state)
    if (benchmarkBlocker !== undefined) blockers.push(benchmarkBlocker)
    if (state.recoveryBlocker !== undefined) blockers.push(state.recoveryBlocker)
    return blockers
  }

  const completionHint = (state: AgentPolicyState): string => {
    const open = currentOpenDebts(state)
    const lines = [
      '<trajectory-policy>',
      'phase: verify',
    ]
    if (open.length > 0) {
      lines.push('verification_debt:')
      for (const debt of open) {
        const readbackCurrent = debt.readback && (debt.readbackRevision ?? debt.revision) >= state.workspaceRevision
        const commandCurrent = debt.commandVerified
          && (debt.commandVerifiedRevision ?? debt.revision) >= state.workspaceRevision
        const needs = [
          ...debt.requiresReadback && !readbackCurrent ? ['read back the final artifact'] : [],
          ...debt.requiresCommand && !commandCurrent ? ['run a relevant test/build/check'] : [],
        ]
        lines.push(`- ${debt.artifact}: ${needs.join(' and ')}`)
      }
    }
    const benchmarkBlocker = benchmarkGateBlocker(state)
    if (benchmarkBlocker !== undefined) {
      lines.push('benchmark_gate:')
      lines.push(`- ${benchmarkBlocker}`)
      lines.push(`- Use one of: ${config.benchmarkToolNames.join(', ') || '(no configured benchmark tool)'}.`)
      lines.push('- A result must name total_queries, recall, and qps; scores are compared only at the same query count, concurrency, and warmup.')
    }
    if (state.stagnantFullBenchmarks >= config.maxStagnantFullBenchmarks) {
      lines.push(`- ${state.stagnantFullBenchmarks} same-spec full benchmarks produced no material gain. Do not keep mutating without a new hypothesis; report a plateau if no such hypothesis exists.`)
    }
    if (state.recoveryBlocker !== undefined) {
      lines.push('trajectory_recovery:')
      lines.push(`- ${state.recoveryBlocker}`)
    }
    lines.push('Do not claim completion or call finish until these obligations are satisfied, or report the concrete blocker honestly.')
    lines.push('</trajectory-policy>')
    return truncateHint(lines.join('\n'), config.maxHintChars)
  }

  const blockerReportHint = (state: AgentPolicyState): string => {
    const blockers = completionBlockers(state)
    return truncateHint([
      '<trajectory-policy>',
      'phase: blocked',
      'Automatic verification budget is exhausted. Do not claim success.',
      'Report the concrete blocker, the evidence already collected, and the next action required to unblock completion.',
      'blockers:',
      ...blockers.map(blocker => `- ${blocker}`),
      '</trajectory-policy>',
    ].join('\n'), config.maxHintChars)
  }

  const releaseFinishGuard = (state: AgentPolicyState): void => {
    state.finishGuard?.()
    state.finishGuard = undefined
  }

  const finishNames = new Set(config.finishToolNames.map(name => name.toLowerCase()))
  const installFinishGuard = (state: AgentPolicyState): void => {
    if (config.mode !== 'active' || state.finishGuard !== undefined || finishNames.size === 0) return
    try {
      state.finishGuard = state.agent.ctx.tools.guard((execution) => {
        if (state.planMode || !finishNames.has(execution.name.toLowerCase())) return undefined
        const blockers = completionBlockers(state)
        if (blockers.length === 0) return undefined
        const reason = `trajectory governor blocked ${execution.name}: ${blockers.join(' ')}`
        ledger.record({
          event: 'finish/blocked',
          sessionId: state.agent.id,
          tool: execution.name,
          workspaceRevision: state.workspaceRevision,
          blockers,
        })
        return reason
      })
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error)
      console.error(`[trajectory-governor] failed to install finish guard for ${state.agent.id}: ${message}`)
      ledger.record({ event: 'finish-guard/rejected', sessionId: state.agent.id, error: message })
    }
  }

  const recordMutation = (state: AgentPolicyState, semantics: ToolSemantics, sequence: number): void => {
    state.workspaceRevision++
    state.currentBenchmarkRevision = undefined
    state.benchmarkBlocker = undefined
    state.stagnantFullBenchmarks = 0
    state.actionsWithoutBenchmark = 0
    if (semantics.artifact !== undefined) {
      state.artifacts.add(semantics.artifact)
      state.mutatedArtifacts.add(semantics.artifact)
    }
    const debt = createVerificationDebt(semantics, sequence, state.workspaceRevision)
    if (debt !== undefined) state.debts.set(debt.id, debt)
  }

  const recordBenchmark = (state: AgentPolicyState, result: BenchmarkResult, sequence: number): void => {
    state.benchmarkSeen = true
    const record: BenchmarkRecord = { result, sequence, revision: state.workspaceRevision }
    state.latestBenchmark = record
    if (!isFullBenchmark(result, config.fullBenchmarkMinQueries, config.fullBenchmarkMinRecall)) {
      if (!hasCurrentFullBenchmark(state)) {
        state.benchmarkBlocker = `Benchmark is not a full pass: total_queries=${result.totalQueries} (need >= ${config.fullBenchmarkMinQueries}), recall=${result.recall} (need >= ${config.fullBenchmarkMinRecall}).`
      }
      return
    }

    const previous = state.bestBenchmarks.get(result.specKey)
    if (previous === undefined) {
      setBoundedMap(state.bestBenchmarks, result.specKey, record, config.maxTrackedResults)
      state.stagnantFullBenchmarks = 0
      state.currentBenchmarkRevision = state.workspaceRevision
      state.benchmarkBlocker = undefined
      state.actionsWithoutBenchmark = 0
      return
    }

    const comparison = compareBenchmarkResults(result, previous.result, config.benchmarkScoreTolerancePercent)
    if (comparison.outcome === 'regressed') {
      state.stagnantFullBenchmarks++
      if (!hasCurrentFullBenchmark(state)) {
        state.benchmarkBlocker = `Full benchmark regressed ${percent(Math.abs(comparison.deltaPercent ?? 0))} below the known best for ${result.specKey}; restore a known-good change or provide a new hypothesis before finishing.`
      }
      return
    }

    if (comparison.outcome === 'improved') {
      setBoundedMap(state.bestBenchmarks, result.specKey, record, config.maxTrackedResults)
      state.stagnantFullBenchmarks = 0
    } else {
      state.stagnantFullBenchmarks++
    }
    state.currentBenchmarkRevision = state.workspaceRevision
    state.benchmarkBlocker = undefined
    state.actionsWithoutBenchmark = 0
  }

  const releaseRestriction = (state: AgentPolicyState, reason: string): void => {
    const restriction = state.restriction
    if (restriction === undefined) return
    restriction.dispose()
    state.restriction = undefined
    ledger.record({
      event: 'restriction/released',
      sessionId: state.agent.id,
      reason,
      denied: restriction.denied,
    })
  }

  const setPendingHint = (state: AgentPolicyState, phase: AgentPhase, hint: string): void => {
    if (state.phase === phase && state.pendingHint === hint) return
    state.phase = phase
    state.policyRevision++
    state.pendingHint = hint
  }

  const installEvidenceRestriction = (state: AgentPolicyState): readonly string[] => {
    releaseRestriction(state, 'new-policy')
    if (config.mode !== 'active' || !config.restrictBeforeEvidence || !state.plan?.restrictBeforeEvidence) return []
    const available = ctx.tools.schemas(state.agent).map(tool => tool.name)
    const denied = mutationToolNames(available, hasObservationCapability(available))
    if (denied.length === 0) return []
    try {
      state.restriction = {
        denied,
        dispose: state.agent.ctx.tools.restrict({ deny: denied }),
      }
      return denied
    } catch (error) {
      ledger.record({
        event: 'restriction/rejected',
        sessionId: state.agent.id,
        denied,
        error: error instanceof Error ? error.message : String(error),
      })
      return []
    }
  }

  const priorEpisode = (state: AgentPolicyState): EpisodeContext | undefined => state.contract === undefined
    ? undefined
    : {
        objective: state.contract.objective,
        artifacts: new Set([...state.artifacts, ...state.contract.artifacts]),
      }

  const acceptHumanMessage = (state: AgentPolicyState, message: UserMessage, turn: number): void => {
    const text = contentText(message.content)
    const contract = classifyTaskContract(text, priorEpisode(state))
    const isNewObjective = contract.relation === 'new-objective' || state.episodeNumber === 0
    state.planMode = planModeOf(state.agent.session)
    state.contract = contract
    state.plan = policyPlan(contract, state.planMode, config.maxHintChars)
    state.phase = state.plan.phase
    state.episodeNumber += isNewObjective ? 1 : 0
    state.humanMessages++
    state.noInformationStreak = 0
    state.repeatedCallCount = 0
    state.lastCallSignature = undefined
    state.recoveryBlocker = undefined
    state.blockedReason = undefined
    if (isNewObjective) {
      state.benchmarkSeen = false
      state.currentBenchmarkRevision = undefined
      state.latestBenchmark = undefined
      state.benchmarkBlocker = undefined
      state.actionsWithoutBenchmark = 0
      state.stagnantFullBenchmarks = 0
    }
    state.policyRevision++
    state.pendingHint = state.plan.hint
    for (const artifact of contract.artifacts) state.artifacts.add(artifact)
    const denied = installEvidenceRestriction(state)
    installFinishGuard(state)

    ledger.record({
      event: 'policy/decided',
      sessionId: state.agent.id,
      turn,
      messageId: message.id,
      messageHash: fingerprint(text),
      episode: state.episodeNumber,
      humanRound: state.humanMessages,
      relation: contract.relation,
      kind: contract.kind,
      phase: state.phase,
      risk: contract.risk,
      complexity: contract.complexity,
      artifacts: contract.artifacts,
      denied,
      mode: config.mode,
      policyRevision: state.policyRevision,
    })
  }

  const registerCall = (state: AgentPolicyState, callId: string, name: string, args: unknown, seq: number): void => {
    const semantics = classifyTool(name, args, toolClassification)
    state.calls.set(callId, { semantics, seq })
    if (state.lastCallSignature === semantics.signature) state.repeatedCallCount++
    else {
      state.lastCallSignature = semantics.signature
      state.repeatedCallCount = 1
    }
  }

  const refreshDebtPhase = (state: AgentPolicyState): void => {
    pruneSatisfiedDebts(state)
    const open = currentOpenDebts(state)
    if (open.length === 0) {
      if (state.phase === 'verify' && benchmarkGateBlocker(state) === undefined) {
        state.phase = 'converge'
        state.policyRevision++
        state.pendingHint = undefined
      }
      return
    }
    setPendingHint(state, 'verify', verificationHint(open, config.maxHintChars, state.workspaceRevision))
  }

  const satisfyReadback = (state: AgentPolicyState, artifact: string | undefined): void => {
    if (artifact === undefined) return
    for (const debt of state.debts.values()) {
      if (sameArtifact(debt.artifact, artifact)) {
        debt.readback = true
        debt.readbackRevision = state.workspaceRevision
      }
    }
  }

  const remindAboutBenchmarkAfterActions = (state: AgentPolicyState, semantics: ToolSemantics): void => {
    if (semantics.effect === 'benchmark' || semantics.effect === 'finish'
      || semantics.effect === 'mutate' || semantics.riskyMutation
      || !benchmarkGateActive(state) || hasCurrentFullBenchmark(state)) return
    state.actionsWithoutBenchmark++
    if (state.actionsWithoutBenchmark >= config.maxActionsWithoutBenchmark) {
      setPendingHint(state, 'verify', completionHint(state))
    }
  }

  const settleCall = (
    state: AgentPolicyState,
    callId: string,
    isError: boolean,
    content: readonly ContentBlock[],
    seq: number,
    meta?: unknown,
  ): void => {
    const call = state.calls.get(callId)
    if (call === undefined) return
    state.calls.delete(callId)
    const { semantics } = call
    const output = contentText(content)
    const commandFailure = semantics.operation !== undefined && hasCommandFailure(output)
    const failed = isError || commandFailure
    const resultHash = fingerprint({ signature: semantics.signature, output, meta: meta ?? null })
    const novel = !state.resultFingerprints.has(resultHash)
    addBoundedSet(state.resultFingerprints, resultHash, config.maxTrackedResults)

    if (failed) {
      setPendingHint(state, 'recover', recoveryHint(config.maxHintChars))
      state.noInformationStreak++
    } else if (semantics.effect === 'observe') {
      if (semantics.artifact !== undefined) {
        state.artifacts.add(semantics.artifact)
        state.observedArtifacts.add(semantics.artifact)
      }
      satisfyReadback(state, semantics.artifact)
      if (novel) state.noInformationStreak = 0
      else state.noInformationStreak++
      releaseRestriction(state, 'evidence-observed')

      if (state.phase === 'inspect' && state.contract !== undefined
        && state.contract.kind !== 'review' && state.contract.kind !== 'analysis') {
        setPendingHint(state, 'construct', constructHint(state.contract, config.maxHintChars))
      }
      refreshDebtPhase(state)
    } else if (semantics.effect === 'mutate' || semantics.riskyMutation) {
      recordMutation(state, semantics, seq)
      state.noInformationStreak = 0
      refreshDebtPhase(state)
    } else if (semantics.effect === 'verify') {
      for (const debt of state.debts.values()) {
        debt.commandVerified = true
        debt.commandVerifiedRevision = state.workspaceRevision
      }
      state.noInformationStreak = 0
      refreshDebtPhase(state)
    } else if (semantics.effect === 'benchmark') {
      state.benchmarkSeen = true
      const benchmark = parseBenchmarkResult(output, meta)
      if (benchmark === undefined) {
        if (!hasCurrentFullBenchmark(state)) {
          state.benchmarkBlocker = 'Configured benchmark returned no parseable total_queries, recall, and qps result; it cannot count as a full pass.'
        }
      } else {
        recordBenchmark(state, benchmark, seq)
      }
      state.noInformationStreak = novel ? 0 : state.noInformationStreak + 1
      refreshDebtPhase(state)
    } else {
      state.noInformationStreak = novel ? 0 : state.noInformationStreak + 1
    }

    const noInformationLimitReached = state.noInformationStreak >= config.noInformationLimit
      || (state.repeatedCallCount >= config.noInformationLimit && !novel)
    if (noInformationLimitReached) {
      state.recoveryBlocker = `No-information limit (${config.noInformationLimit}) was reached. Re-read the latest result and use a materially different action before finishing.`
      setPendingHint(state, 'recover', recoveryHint(config.maxHintChars))
    } else if (novel && !failed && semantics.effect !== 'finish') {
      state.recoveryBlocker = undefined
    }
    if (!failed) remindAboutBenchmarkAfterActions(state, semantics)

    ledger.record({
      event: 'tool/observed',
      sessionId: state.agent.id,
      seq,
      callId,
      name: semantics.name,
      effect: semantics.effect,
      artifact: semantics.artifact,
      riskyMutation: semantics.riskyMutation === true,
      isError: failed,
      toolReportedError: isError,
      commandFailure,
      novel,
      noInformationStreak: state.noInformationStreak,
      repeatedCallCount: state.repeatedCallCount,
      phase: state.phase,
      workspaceRevision: state.workspaceRevision,
      benchmark: state.latestBenchmark?.result ?? null,
      benchmarkBlocker: benchmarkGateBlocker(state) ?? null,
      recoveryBlocker: state.recoveryBlocker ?? null,
      openDebt: currentOpenDebts(state).map(debt => debt.artifact),
      resultHash,
    })
  }

  ctx.on('agent/created', ({ agent }) => {
    installFinishGuard(stateFor(agent))
  })

  ctx.on('agent/disposed', ({ agent }) => {
    const state = states.get(agent)
    if (state !== undefined) {
      releaseRestriction(state, 'agent-disposed')
      releaseFinishGuard(state)
    }
    states.delete(agent)
  })

  // This event fires after inbox.claim() but before systemPrompt.assemble(), so
  // the current human task is available for first-request policy decisions.
  ctx.on('agent/inbox/claimed', ({ agent, message, turn }) => {
    if (config.mode === 'off' || message.source.kind !== 'user') return
    acceptHumanMessage(stateFor(agent), message, turn)
  })

  // Observe the exact assembled request surface without rewriting persona,
  // plan policy, Code Mode protocol, runtime contexts, or tool schemas.
  ctx.on('system-prompt/assemble', async (_assembly, context, next) => {
    const assembled = await next()
    const agent = context.agent
    if (agent === undefined || config.mode === 'off') return assembled
    const state = stateFor(agent)
    const snapshot: AssemblySnapshot = {
      hash: fingerprint({ sections: assembled.sections, tools: assembled.tools, variables: assembled.variables }),
      sectionNames: assembled.sections.map(section => section.name),
      toolNames: assembled.tools.map(tool => tool.name),
    }
    state.assembly = snapshot
    ledger.record({
      event: 'request/assembled',
      sessionId: agent.id,
      policyRevision: state.policyRevision,
      assemblyHash: snapshot.hash,
      sectionNames: snapshot.sectionNames,
      toolNames: snapshot.toolNames,
    })
    return assembled
  })

  // The accepted message is inserted into THIS step, after the current human
  // task when present. It is then durably logged by the official loop.
  ctx.on('agent/pre-step', async ({ agent }, next): Promise<PreStepDecision> => {
    const decision = await next()
    if (decision.kind === 'reject' || config.mode !== 'active') return decision
    const state = stateFor(agent)
    if (state.pendingHint === undefined || state.injectedRevision >= state.policyRevision) return decision
    const message = pluginMessage(state.pendingHint, 'policy')
    state.injectedRevision = state.policyRevision
    state.pendingHint = undefined
    return {
      ...decision,
      messages: insertAfterLastHuman(decision.messages, message),
    }
  })

  ctx.on('agent/request', async ({ agent, signal }, next): Promise<LlmCallConfig> => {
    const proposed = await next()
    if (config.mode !== 'active' || !config.adaptiveReasoning) return proposed
    const state = stateFor(agent)
    if (!deepPhase(state.phase)) {
      if (!state.effortOverrideApplied) return proposed
      const { reasoningEffort: _governorEffort, ...restored } = proposed
      state.effortOverrideApplied = false
      ledger.record({ event: 'reasoning/restored', sessionId: agent.id, phase: state.phase })
      return restored
    }

    const key = `${proposed.provider}\u0000${proposed.model}`
    let pending = modelInfo.get(key)
    if (pending === undefined) {
      pending = ctx.llm.resolveModelInfo(proposed.provider, proposed.model, signal)
      modelInfo.set(key, pending)
    }
    try {
      const info = await pending
      signal.throwIfAborted()
      const effort = deepestEffort(info)
      if (effort === undefined || String(proposed.reasoningEffort ?? '') === String(effort)) return proposed
      state.effortOverrideApplied = true
      ledger.record({ event: 'reasoning/selected', sessionId: agent.id, phase: state.phase, effort: String(effort) })
      return { ...proposed, reasoningEffort: ReasoningEffortId(String(effort)) }
    } catch (error) {
      modelInfo.delete(key)
      ledger.record({
        event: 'reasoning/unavailable',
        sessionId: agent.id,
        error: error instanceof Error ? error.message : String(error),
      })
      return proposed
    }
  })

  ctx.on('agent/request-error', async ({ agent, turn, step, provider, failure }, next) => {
    if (config.mode === 'off' || !config.stopRetryOnDeterministicErrors || !isTerminalLlmFailure(failure)) {
      return next()
    }
    const state = stateFor(agent)
    const reason = `Model request is not retryable: ${failure.code}${failure.status === undefined ? '' : ` (HTTP ${failure.status})`}. ${failure.message}`
    if (state.blockedReason !== reason || state.phase !== 'blocked') {
      state.phase = 'blocked'
      state.blockedReason = reason
      state.pendingHint = undefined
      state.policyRevision++
    }
    ledger.record({
      event: 'request/terminal-error',
      sessionId: agent.id,
      turn,
      step,
      provider,
      status: failure.status ?? null,
      code: failure.code,
      message: failure.message,
    })
    // Deliberately do not call next(): undefined is DSH's terminal action.
    return undefined
  })

  ctx.on('session/event', (session, event) => {
    const state = sessionStates.get(session)
    if (state === undefined || config.mode === 'off') return
    switch (event.type) {
      case 'tool/call':
        registerCall(state, String(event.data.callId), event.data.name, parseArguments(event.data.arguments), event.seq)
        break
      case 'tool/code-dispatch-start':
        registerCall(state, String(event.data.subCallId), event.data.name, event.data.arguments, event.seq)
        break
      case 'tool/result': {
        const block = event.data.message.content[0]
        if (block.type !== 'tool-result') break
        settleCall(state, String(event.data.message.source.callId), block.isError === true, block.content, event.seq, event.data.meta)
        break
      }
      case 'tool/code-dispatch':
        settleCall(state, String(event.data.subCallId), event.data.isError, event.data.content, event.seq)
        break
      case 'plan/mode':
        state.planMode = event.data.active
        if (state.planMode) releaseRestriction(state, 'plan-mode-active')
        break
      case 'turn/end':
        state.automaticContinuations.delete(event.data.turn)
        state.blockerReports.delete(event.data.turn)
        state.calls.clear()
        pruneSatisfiedDebts(state)
        ledger.record({
          event: 'turn/ended',
          sessionId: state.agent.id,
          turn: event.data.turn,
          reason: event.data.reason.kind,
          phase: state.phase,
          relation: state.contract?.relation,
          workspaceRevision: state.workspaceRevision,
          benchmarkBlocker: benchmarkGateBlocker(state) ?? null,
          openDebt: currentOpenDebts(state).map(debt => debt.artifact),
          policyRevision: state.policyRevision,
        })
        break
    }
  })

  ctx.on('agent/turn-stopping', ({ agent, turn, signal }) => {
    if (config.mode !== 'active' || !config.autoVerify || signal.aborted) return
    const state = stateFor(agent)
    if (state.planMode) return
    const blockers = completionBlockers(state)
    if (blockers.length === 0) return
    const used = state.automaticContinuations.get(turn) ?? 0
    if (used < config.maxAutomaticContinuations) {
      state.automaticContinuations.set(turn, used + 1)
      state.phase = 'verify'
      state.policyRevision++
      state.injectedRevision = state.policyRevision // the steering message itself carries this revision
      state.pendingHint = undefined
      agent.steer(pluginMessage(completionHint(state), 'verification'))
      ledger.record({
        event: 'verification/continued',
        sessionId: agent.id,
        turn,
        attempt: used + 1,
        workspaceRevision: state.workspaceRevision,
        blockers,
        openDebt: currentOpenDebts(state).map(debt => debt.artifact),
      })
      return
    }

    if (state.blockerReports.has(turn)) return
    state.blockerReports.add(turn)
    state.phase = 'blocked'
    state.blockedReason = blockers.join(' ')
    state.policyRevision++
    state.injectedRevision = state.policyRevision
    state.pendingHint = undefined
    agent.steer(pluginMessage(blockerReportHint(state), 'blocker-report'))
    ledger.record({
      event: 'verification/blocked',
      sessionId: agent.id,
      turn,
      attempts: used,
      workspaceRevision: state.workspaceRevision,
      blockers,
    })
  })

  if (config.exposeStatusTool) {
    ctx.effect(() => ctx.tools.register(defineTool({
      name: 'trajectory_policy_status',
      description: 'Show the current task episode, policy phase, continuity relation, trajectory health, capability restriction, and open verification debt.',
      parameters: {},
      output: {
        schema: { type: 'string' },
        render: (_args, value) => [{ type: 'text', text: value }],
      },
      async execute(_args, exec) {
        const agent = exec.agent
        if (agent === undefined) return 'trajectory governor: no owning agent'
        const state = stateFor(agent)
        const open = currentOpenDebts(state)
        return JSON.stringify({
          mode: config.mode,
          episode: state.episodeNumber,
          humanRound: state.humanMessages,
          relation: state.contract?.relation ?? null,
          kind: state.contract?.kind ?? null,
          phase: state.phase,
          risk: state.contract?.risk ?? null,
          planMode: state.planMode,
          artifacts: [...state.artifacts],
          observedArtifacts: [...state.observedArtifacts],
          mutatedArtifacts: [...state.mutatedArtifacts],
          restriction: state.restriction?.denied ?? [],
          noInformationStreak: state.noInformationStreak,
          repeatedCallCount: state.repeatedCallCount,
          recoveryBlocker: state.recoveryBlocker ?? null,
          workspaceRevision: state.workspaceRevision,
          openVerificationDebt: open.map(debt => ({
            artifact: debt.artifact,
            revision: debt.revision,
            readback: debt.readback,
            readbackRevision: debt.readbackRevision ?? null,
            commandVerified: debt.commandVerified,
            commandVerifiedRevision: debt.commandVerifiedRevision ?? null,
          })),
          benchmark: {
            required: config.benchmarkRequired,
            seen: state.benchmarkSeen,
            currentRevisionPassed: hasCurrentFullBenchmark(state),
            currentBenchmarkRevision: state.currentBenchmarkRevision ?? null,
            fullMinQueries: config.fullBenchmarkMinQueries,
            fullMinRecall: config.fullBenchmarkMinRecall,
            tolerancePercent: config.benchmarkScoreTolerancePercent,
            actionsWithoutBenchmark: state.actionsWithoutBenchmark,
            stagnantFullBenchmarks: state.stagnantFullBenchmarks,
            blocker: benchmarkGateBlocker(state) ?? null,
            latest: state.latestBenchmark === undefined ? null : {
              revision: state.latestBenchmark.revision,
              sequence: state.latestBenchmark.sequence,
              ...state.latestBenchmark.result,
            },
            bestBySpec: [...state.bestBenchmarks.values()].map(record => ({
              revision: record.revision,
              sequence: record.sequence,
              ...record.result,
            })),
          },
          blockedReason: state.blockedReason ?? null,
          ledger: ledger.status(),
          assemblyHash: state.assembly?.hash ?? null,
        }, undefined, 2)
      },
      presentCall: () => ({ card: 'generic', title: 'Trajectory policy status', kind: 'read' }),
    })))
  }

  ctx.effect(() => async () => {
    for (const state of states.values()) {
      releaseRestriction(state, 'plugin-disposed')
      releaseFinishGuard(state)
    }
    states.clear()
    await ledger.close()
  }, 'trajectory-governor.lifecycle')

  ledger.record({ event: 'plugin/loaded', mode: config.mode, configHash: fingerprint(config) })
}
