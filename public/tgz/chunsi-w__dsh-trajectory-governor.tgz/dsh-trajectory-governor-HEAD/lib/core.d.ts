/** Pure task-episode, policy, tool-semantics, and verification-debt logic. */
export type TaskRelation = 'new-objective' | 'continuation' | 'extension' | 'correction' | 'clarification' | 'review' | 'conversation';
export type TaskKind = 'build' | 'fix' | 'review' | 'analysis' | 'unknown';
export type AgentPhase = 'orient' | 'inspect' | 'design' | 'construct' | 'verify' | 'recover' | 'converge' | 'blocked';
export type RiskLevel = 'low' | 'medium' | 'high';
export type ToolEffect = 'observe' | 'mutate' | 'verify' | 'benchmark' | 'finish' | 'interact' | 'delegate' | 'unknown';
export interface TaskContract {
    readonly objective: string;
    readonly relation: TaskRelation;
    readonly kind: TaskKind;
    readonly complexity: number;
    readonly risk: RiskLevel;
    readonly artifacts: readonly string[];
    readonly acceptance: readonly string[];
    readonly evidence: readonly string[];
}
export interface EpisodeContext {
    readonly objective: string;
    readonly artifacts: ReadonlySet<string>;
}
export interface ToolSemantics {
    readonly name: string;
    readonly effect: ToolEffect;
    readonly artifact?: string;
    readonly operation?: string;
    /** An unclassified shell command has a common workspace-mutation signature. */
    readonly riskyMutation?: boolean;
    readonly signature: string;
}
export interface VerificationDebt {
    readonly id: string;
    readonly artifact: string;
    /** Workspace revision that created this obligation. */
    readonly revision: number;
    readonly requiresReadback: boolean;
    readonly requiresCommand: boolean;
    readback: boolean;
    commandVerified: boolean;
    readbackRevision?: number;
    commandVerifiedRevision?: number;
    waived: boolean;
}
export interface ToolClassificationOptions {
    readonly benchmarkToolNames?: readonly string[];
    readonly verificationToolNames?: readonly string[];
    readonly finishToolNames?: readonly string[];
}
export interface BenchmarkResult {
    readonly totalQueries: number;
    readonly recall: number;
    readonly qps: number;
    readonly concurrency?: number;
    readonly warmup?: number;
    /** A score may only be compared to another result with this exact key. */
    readonly specKey: string;
}
export type BenchmarkComparison = 'improved' | 'within-tolerance' | 'regressed' | 'different-spec';
export interface BenchmarkComparisonResult {
    readonly outcome: BenchmarkComparison;
    readonly deltaPercent?: number;
}
export interface PolicyPlan {
    readonly relation: TaskRelation;
    readonly phase: AgentPhase;
    readonly restrictBeforeEvidence: boolean;
    readonly hint: string;
    readonly evidence: readonly string[];
}
export declare const DEFAULT_BENCHMARK_TOOL_NAMES: readonly ["run_benchmark"];
export declare const DEFAULT_VERIFICATION_TOOL_NAMES: readonly ["build_project", "run_correctness_test"];
export declare const DEFAULT_FINISH_TOOL_NAMES: readonly ["finish"];
export declare function extractArtifacts(text: string): string[];
export declare function classifyTaskContract(rawText: string, previous?: EpisodeContext): TaskContract;
export declare function initialPhase(contract: TaskContract, planMode: boolean): AgentPhase;
export declare function policyPlan(contract: TaskContract, planMode: boolean, maxHintChars?: number): PolicyPlan;
export declare function classifyTool(name: string, rawArguments: unknown, options?: ToolClassificationOptions): ToolSemantics;
export declare function createVerificationDebt(semantics: ToolSemantics, sequence: number, revision?: number): VerificationDebt | undefined;
export declare function debtSatisfied(debt: VerificationDebt, currentRevision?: number): boolean;
export declare function openDebts(debts: Iterable<VerificationDebt>, currentRevision?: number): VerificationDebt[];
/**
 * Parse only a complete, named benchmark result. A prose claim such as
 * "performance improved" is intentionally not accepted as benchmark evidence.
 */
export declare function parseBenchmarkResult(content: string, meta?: unknown): BenchmarkResult | undefined;
export declare function benchmarkSpecKey(result: Pick<BenchmarkResult, 'totalQueries' | 'concurrency' | 'warmup'>): string;
export declare function isFullBenchmark(result: BenchmarkResult, minQueries: number, minRecall: number): boolean;
export declare function compareBenchmarkResults(candidate: BenchmarkResult, baseline: BenchmarkResult, tolerancePercent: number): BenchmarkComparisonResult;
/** DSH shell tools can surface a non-zero process exit in text without isError. */
export declare function hasCommandFailure(content: string): boolean;
/** 400 invalid-request failures are deterministic request-shape failures, not retry candidates. */
export declare function isTerminalLlmFailure(failure: unknown): boolean;
export declare function verificationHint(debts: Iterable<VerificationDebt>, maxHintChars?: number, currentRevision?: number): string;
export declare function recoveryHint(maxHintChars?: number): string;
export declare function mutationToolNames(availableNames: Iterable<string>, hasDedicatedObserver: boolean): string[];
export declare function hasObservationCapability(availableNames: Iterable<string>): boolean;
export declare function foldPlanMode(events: readonly {
    type: string;
    data: unknown;
}[]): boolean;
//# sourceMappingURL=core.d.ts.map