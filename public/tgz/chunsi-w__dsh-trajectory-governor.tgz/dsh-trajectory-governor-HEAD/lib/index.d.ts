/**
 * Closed-loop trajectory policy plane for DeepSeek Harness.
 *
 * The governor keeps the deployment persona and runtime contexts intact. It
 * observes claimed human input before prompt assembly, injects reconstructable
 * near-field policy messages at agent/pre-step, applies scoped capability
 * restrictions through ToolRuntime, and closes verification debt from durable
 * Native and Code Mode tool events.
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
export * from './core.js';
export declare const name = "trajectory-governor";
export declare const inject: string[];
export type GovernorMode = 'off' | 'shadow' | 'active';
export interface Config {
    /** off = inert; shadow = decide and log only; active = apply policy. */
    mode?: GovernorMode;
    /** Adapt the routed model's reasoning effort during inspect/design/recover phases. */
    adaptiveReasoning?: boolean;
    /** Temporarily hide known dedicated mutation tools until one observation succeeds. */
    restrictBeforeEvidence?: boolean;
    /** Add at most maxAutomaticContinuations verification turns for open debt. */
    autoVerify?: boolean;
    maxAutomaticContinuations?: number;
    /** Repeated/no-novel-result threshold that enters recovery. */
    noInformationLimit?: number;
    /** Register trajectory_policy_status as a model-facing diagnostic. */
    exposeStatusTool?: boolean;
    /** Persist privacy-minimized state/action/outcome JSONL outside Session history. */
    ledger?: boolean;
    ledgerPath?: string;
    /** Rotate the active JSONL ledger before it grows beyond this many bytes. */
    maxLedgerBytes?: number;
    maxHintChars?: number;
    /** Require a parseable full benchmark before finish/natural completion. */
    benchmarkRequired?: boolean;
    benchmarkToolNames?: string[];
    verificationToolNames?: string[];
    finishToolNames?: string[];
    fullBenchmarkMinQueries?: number;
    fullBenchmarkMinRecall?: number;
    benchmarkScoreTolerancePercent?: number;
    /** Prompt for benchmark evidence after this many successful actions without it. */
    maxActionsWithoutBenchmark?: number;
    /** Surface a plateau after this many same-spec full results without material gain. */
    maxStagnantFullBenchmarks?: number;
    /** Stop an adapter retry loop for deterministic 400 / invalid_request_error failures. */
    stopRetryOnDeterministicErrors?: boolean;
    /** Bound non-authoritative result and benchmark history retained per agent. */
    maxTrackedResults?: number;
}
export declare const Config: z<Config>;
export declare function apply(ctx: Context, inputConfig?: Config): void;
//# sourceMappingURL=index.d.ts.map