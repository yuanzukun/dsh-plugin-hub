import { describe, expect, it } from 'vitest'
import { Context } from '@deepseek-ai/cordis'
import AgentRegistry, { type Agent } from '@deepseek-ai/dsh-agent'
import AgentLoop from '@deepseek-ai/dsh-agent-loop'
import LlmRuntime, {
  CallId,
  createUserMessage,
  LlmAdapter,
  ReasoningEffortId,
} from '@deepseek-ai/dsh-llm'
import type {
  GenerateOptions,
  LlmModelReasoningInfo,
  LlmResolvedModelInfo,
  StreamChunk,
} from '@deepseek-ai/dsh-llm'
import SessionStore, { SessionId } from '@deepseek-ai/dsh-session'
import SystemPrompt from '@deepseek-ai/dsh-system-prompt'
import ToolRuntime, { defineTool } from '@deepseek-ai/dsh-tools'
import WorkerThreadCodeRuntime from '@deepseek-ai/dsh-code-runtime-worker-thread'
import * as Governor from '../src/index.js'

function textResponse(text: string): StreamChunk[] {
  return [
    { type: 'block-start', index: 0, blockType: 'text' },
    { type: 'text-delta', index: 0, text },
    { type: 'block-end', index: 0, block: { type: 'text', text } },
    { type: 'usage', usage: { inputTokens: 10, outputTokens: text.length } },
    { type: 'finish', reason: { kind: 'stop' } },
  ]
}

function toolCallResponse(rawCallId: string, name: string, args: object): StreamChunk[] {
  const id = CallId(rawCallId)
  const json = JSON.stringify(args)
  return [
    { type: 'block-start', index: 0, blockType: 'tool-call' },
    { type: 'tool-call-delta', index: 0, id, name, argumentsDelta: json },
    { type: 'block-end', index: 0, block: { type: 'tool-call', id, name, arguments: json } },
    { type: 'usage', usage: { inputTokens: 10, outputTokens: 5 } },
    { type: 'finish', reason: { kind: 'tool-calls' } },
  ]
}

class ScriptedAdapter extends LlmAdapter {
  readonly requests: GenerateOptions[] = []

  constructor(
    private readonly script: StreamChunk[][],
    private readonly reasoning?: LlmModelReasoningInfo,
  ) {
    super()
  }

  override resolveModel(provider: string, model: string): Promise<LlmResolvedModelInfo> {
    return Promise.resolve({
      provider,
      id: model,
      name: model,
      ...(this.reasoning === undefined ? {} : { reasoning: this.reasoning }),
    })
  }

  async * stream(options: GenerateOptions): AsyncIterable<StreamChunk> {
    this.requests.push(options)
    const entry = this.script.shift()
    if (entry === undefined) throw new Error('script exhausted')
    for (const chunk of entry) yield chunk
  }
}

class DeterministicFailureAdapter extends LlmAdapter {
  readonly requests: GenerateOptions[] = []

  override resolveModel(provider: string, model: string): Promise<LlmResolvedModelInfo> {
    return Promise.resolve({ provider, id: model, name: model })
  }

  async * stream(options: GenerateOptions): AsyncIterable<StreamChunk> {
    this.requests.push(options)
    const error = Object.assign(new Error('request is four tokens over the context limit'), {
      code: 'invalid_request_error',
      failure: {
        message: 'request is four tokens over the context limit',
        code: 'invalid_request_error',
        status: 400,
      },
    })
    throw error
  }
}

function waitForIdle(ctx: Context, agent: Agent): Promise<void> {
  return new Promise((resolve) => {
    const dispose = ctx.on('agent/status', ({ agent: subject, status }) => {
      if (subject !== agent || status !== 'idle') return
      dispose()
      resolve()
    })
  })
}

function send(agent: Agent, text: string): void {
  agent.followup(createUserMessage({
    source: { kind: 'user' },
    content: [{ type: 'text', text }],
  }))
}

function texts(messages: GenerateOptions['messages']): string[] {
  return messages.flatMap(message => message.content)
    .flatMap(block => block.type === 'text' ? [block.text] : [])
}

function loggedUserTexts(agent: Agent): string[] {
  return agent.session.events
    .filter(event => event.type === 'user/message')
    .flatMap(event => event.type === 'user/message' ? event.data.content : [])
    .flatMap(block => block.type === 'text' ? [block.text] : [])
}

function resultText(content: readonly { type: string; text?: string }[]): string {
  return content.map(block => block.text ?? '').join('')
}

async function setup(
  adapter: LlmAdapter,
  config: Governor.Config = {},
  toolMode: 'native' | 'code' = 'native',
) {
  const ctx = new Context()
  await ctx.plugin(LlmRuntime)
  await ctx.plugin(SessionStore)
  await ctx.plugin(SystemPrompt, { persona: 'OFFICIAL PERSONA' })
  if (toolMode === 'code') await ctx.plugin(WorkerThreadCodeRuntime, {})
  await ctx.plugin(ToolRuntime, { mode: toolMode })
  await ctx.plugin(AgentRegistry)
  await ctx.plugin(AgentLoop, { agents: [] })

  ctx.llm.registerAdapter(['mock'], adapter)
  ctx.systemPrompt.context({ name: 'policy-probe', order: 1, text: 'RUNTIME POLICY CONTEXT' })

  ctx.tools.register(defineTool({
    name: 'read',
    description: 'Read one file.',
    parameters: { file_path: { type: 'string', required: true } },
    output: {
      schema: { type: 'string' },
      render: (_args, value) => [{ type: 'text', text: value }],
    },
    async execute(args) {
      return `content of ${args.file_path}`
    },
  }))
  ctx.tools.register(defineTool({
    name: 'write',
    description: 'Write one file.',
    parameters: {
      file_path: { type: 'string', required: true },
      content: { type: 'string', required: true },
    },
    output: {
      schema: { type: 'string' },
      render: (_args, value) => [{ type: 'text', text: value }],
    },
    async execute(args) {
      return `wrote ${args.file_path}`
    },
  }))
  ctx.tools.register(defineTool({
    name: 'edit',
    description: 'Edit one file.',
    parameters: {
      file_path: { type: 'string', required: true },
      old_string: { type: 'string', required: true },
      new_string: { type: 'string', required: true },
    },
    output: {
      schema: { type: 'string' },
      render: (_args, value) => [{ type: 'text', text: value }],
    },
    async execute(args) {
      return `edited ${args.file_path}`
    },
  }))
  ctx.tools.register(defineTool({
    name: 'bash',
    description: 'Run a command.',
    parameters: { command: { type: 'string', required: true } },
    output: {
      schema: { type: 'string' },
      render: (_args, value) => [{ type: 'text', text: value }],
    },
    async execute(args) {
      return `ok: ${args.command}`
    },
  }))
  ctx.tools.register(defineTool({
    name: 'run_benchmark',
    description: 'Run the configured performance benchmark.',
    parameters: {},
    output: {
      schema: { type: 'string' },
      render: (_args, value) => [{ type: 'text', text: value }],
    },
    async execute() {
      return JSON.stringify({
        total_queries: 10_000,
        recall: 0.98,
        qps: 1_000,
        concurrency: 8,
        warmup: 100,
      })
    },
  }))
  ctx.tools.register(defineTool({
    name: 'finish',
    description: 'Finish the current task.',
    parameters: {},
    output: {
      schema: { type: 'string' },
      render: (_args, value) => [{ type: 'text', text: value }],
    },
    async execute() {
      return 'finished'
    },
  }))

  await ctx.plugin(Governor, {
    ledger: false,
    exposeStatusTool: true,
    ...config,
  })
  return ctx
}

function createAgent(ctx: Context, id: string): Agent {
  return ctx.agentLoop.create(SessionId(id), { provider: 'mock', model: 'mock' })
}

async function policyStatus(ctx: Context, agent: Agent, callId: string): Promise<Record<string, unknown>> {
  const result = await ctx.tools.execute({
    callId: CallId(callId),
    name: 'trajectory_policy_status',
    arguments: {},
    signal: new AbortController().signal,
    agent,
  })
  return JSON.parse(resultText(result.content as Array<{ type: string; text?: string }>)) as Record<string, unknown>
}

function toolResultErrors(agent: Agent, name: string): boolean[] {
  const names = new Map<string, string>()
  const errors: boolean[] = []
  for (const event of agent.session.events) {
    if (event.type === 'tool/call') {
      names.set(String(event.data.callId), event.data.name)
      continue
    }
    if (event.type !== 'tool/result') continue
    if (names.get(String(event.data.message.source.callId)) !== name) continue
    const block = event.data.message.content[0]
    if (block.type === 'tool-result') errors.push(block.isError)
  }
  return errors
}

describe('trajectory governor on the real AgentLoop', () => {
  it('captures the first human task before assembly and injects policy in the same request', async () => {
    const adapter = new ScriptedAdapter([textResponse('done')])
    const ctx = await setup(adapter)
    const agent = createAgent(ctx, 'first-request')

    const idle = waitForIdle(ctx, agent)
    send(agent, 'Fix the bug in src/auth.ts; valid login returns 500.')
    await idle

    expect(adapter.requests).toHaveLength(1)
    const request = adapter.requests[0]!
    expect(request.system).toContain('OFFICIAL PERSONA')
    const requestTexts = texts(request.messages)
    expect(requestTexts[0]).toContain('Fix the bug')
    expect(requestTexts.some(text => text.includes('<trajectory-policy>'))).toBe(true)
    expect(requestTexts.some(text => text.includes('RUNTIME POLICY CONTEXT'))).toBe(true)
    expect(request.tools?.map(tool => tool.name)).toContain('read')
    expect(request.tools?.map(tool => tool.name)).not.toContain('write')
    expect(request.tools?.map(tool => tool.name)).not.toContain('edit')

  })

  it('releases the scoped mutation restriction after durable read evidence', async () => {
    const adapter = new ScriptedAdapter([
      toolCallResponse('read-1', 'read', { file_path: 'src/auth.ts' }),
      textResponse('now ready to change it'),
    ])
    const ctx = await setup(adapter)
    const agent = createAgent(ctx, 'release-after-read')

    const idle = waitForIdle(ctx, agent)
    send(agent, 'Fix the regression in src/auth.ts.')
    await idle

    expect(adapter.requests).toHaveLength(2)
    expect(adapter.requests[0]!.tools?.map(tool => tool.name)).not.toContain('write')
    expect(adapter.requests[1]!.tools?.map(tool => tool.name)).toContain('write')
    expect(texts(adapter.requests[1]!.messages).some(text => text.includes('phase: construct'))).toBe(true)

  })

  it('creates verification debt after mutation and grants only one automatic continuation', async () => {
    const adapter = new ScriptedAdapter([
      toolCallResponse('write-1', 'write', { file_path: 'src/new.ts', content: 'export const x = 1' }),
      textResponse('implemented'),
      textResponse('verification unavailable, reporting honestly'),
      textResponse('blocked: verification command is unavailable'),
    ])
    const ctx = await setup(adapter, { maxAutomaticContinuations: 1 })
    const agent = createAgent(ctx, 'verification-debt')

    const idle = waitForIdle(ctx, agent)
    send(agent, 'Create src/new.ts exporting x.')
    await idle

    expect(adapter.requests).toHaveLength(4)
    const policyTexts = loggedUserTexts(agent).filter(text => text.includes('verification_debt'))
    expect(policyTexts.length).toBeGreaterThanOrEqual(2)
    expect(loggedUserTexts(agent).some(text => text.includes('Automatic verification budget is exhausted'))).toBe(true)
    expect(agent.session.events.filter(event => event.type === 'step/end')).toHaveLength(4)

  })

  it('selects the deepest supported effort for inspect and restores the adapter default after evidence', async () => {
    const reasoning: LlmModelReasoningInfo = {
      efforts: [
        { id: ReasoningEffortId('off'), name: 'Off' },
        { id: ReasoningEffortId('low'), name: 'Low' },
        { id: ReasoningEffortId('max'), name: 'Max' },
      ],
      defaultEffort: ReasoningEffortId('low'),
    }
    const adapter = new ScriptedAdapter([
      toolCallResponse('read-effort', 'read', { file_path: 'src/a.ts' }),
      textResponse('done'),
    ], reasoning)
    const ctx = await setup(adapter, { adaptiveReasoning: true })
    const agent = createAgent(ctx, 'adaptive-effort')

    const idle = waitForIdle(ctx, agent)
    send(agent, 'Fix src/a.ts.')
    await idle

    expect(adapter.requests.map(request => String(request.reasoningEffort))).toEqual(['max', 'low'])
  })

  it('keys diagnostic state by exec.agent, not by the last assembled session', async () => {
    const adapter = new ScriptedAdapter([textResponse('A'), textResponse('B')])
    const ctx = await setup(adapter)
    const a = createAgent(ctx, 'session-a')
    const b = createAgent(ctx, 'session-b')

    let idle = waitForIdle(ctx, a)
    send(a, 'Fix src/a.ts.')
    await idle
    idle = waitForIdle(ctx, b)
    send(b, 'Create src/b.ts.')
    await idle

    const signal = new AbortController().signal
    const statusA = await ctx.tools.execute({
      callId: CallId('status-a'),
      name: 'trajectory_policy_status',
      arguments: {},
      signal,
      agent: a,
    })
    const statusB = await ctx.tools.execute({
      callId: CallId('status-b'),
      name: 'trajectory_policy_status',
      arguments: {},
      signal,
      agent: b,
    })

    const aText = resultText(statusA.content as Array<{ type: string; text?: string }>)
    const bText = resultText(statusB.content as Array<{ type: string; text?: string }>)
    expect(JSON.parse(aText).kind).toBe('fix')
    expect(JSON.parse(bText).kind).toBe('build')

  })

  it('blocks an explicit finish tool until a configured full benchmark passes', async () => {
    const adapter = new ScriptedAdapter([
      toolCallResponse('finish-blocked', 'finish', {}),
      textResponse('benchmark is still required'),
    ])
    const ctx = await setup(adapter, { benchmarkRequired: true, autoVerify: false })
    const agent = createAgent(ctx, 'benchmark-finish-blocked')

    const idle = waitForIdle(ctx, agent)
    send(agent, 'Optimize the index throughput.')
    await idle

    expect(toolResultErrors(agent, 'finish')).toEqual([true])
    const status = await policyStatus(ctx, agent, 'benchmark-status-blocked')
    expect(status.workspaceRevision).toBe(0)
    expect(status.benchmark).toMatchObject({ currentRevisionPassed: false })
  })

  it('allows finish after a parseable full benchmark for the current revision', async () => {
    const adapter = new ScriptedAdapter([
      toolCallResponse('benchmark-pass', 'run_benchmark', {}),
      toolCallResponse('finish-pass', 'finish', {}),
      textResponse('completed'),
    ])
    const ctx = await setup(adapter, { benchmarkRequired: true, autoVerify: false })
    const agent = createAgent(ctx, 'benchmark-finish-allowed')

    const idle = waitForIdle(ctx, agent)
    send(agent, 'Optimize the index throughput.')
    await idle

    expect(toolResultErrors(agent, 'finish')).toEqual([false])
    const status = await policyStatus(ctx, agent, 'benchmark-status-allowed')
    expect(status.benchmark).toMatchObject({ currentRevisionPassed: true, currentBenchmarkRevision: 0 })
  })

  it('invalidates an earlier full benchmark after mutation and requires a new verified revision', async () => {
    const adapter = new ScriptedAdapter([
      toolCallResponse('benchmark-before-write', 'run_benchmark', {}),
      toolCallResponse('write-after-benchmark', 'write', { file_path: 'src/index.ts', content: 'export const improved = true' }),
      toolCallResponse('finish-stale-benchmark', 'finish', {}),
      toolCallResponse('read-after-write', 'read', { file_path: 'src/index.ts' }),
      toolCallResponse('verify-after-write', 'bash', { command: 'pnpm test' }),
      toolCallResponse('benchmark-after-write', 'run_benchmark', {}),
      toolCallResponse('finish-fresh-benchmark', 'finish', {}),
      textResponse('completed after a fresh benchmark'),
    ])
    const ctx = await setup(adapter, { benchmarkRequired: true, autoVerify: false })
    const agent = createAgent(ctx, 'benchmark-revision')

    const idle = waitForIdle(ctx, agent)
    send(agent, 'Create src/index.ts with an improved index.')
    await idle

    expect(toolResultErrors(agent, 'finish')).toEqual([true, false])
    const status = await policyStatus(ctx, agent, 'benchmark-status-revision')
    expect(status.workspaceRevision).toBe(1)
    expect(status.openVerificationDebt).toEqual([])
    expect(status.benchmark).toMatchObject({ currentRevisionPassed: true, currentBenchmarkRevision: 1 })
  })

  it('uses one bounded blocker-report steering step instead of silently closing an unmet benchmark gate', async () => {
    const adapter = new ScriptedAdapter([
      textResponse('done without evidence'),
      textResponse('blocked: benchmark evidence is unavailable'),
    ])
    const ctx = await setup(adapter, { benchmarkRequired: true, maxAutomaticContinuations: 0 })
    const agent = createAgent(ctx, 'benchmark-natural-stop')

    const idle = waitForIdle(ctx, agent)
    send(agent, 'Optimize the index throughput.')
    await idle

    expect(adapter.requests).toHaveLength(2)
    expect(loggedUserTexts(agent).some(text => text.includes('Automatic verification budget is exhausted'))).toBe(true)
    const status = await policyStatus(ctx, agent, 'benchmark-status-natural-stop')
    expect(status.phase).toBe('blocked')
  })

  it('turns repeated no-information calls into a finish blocker until a new result is obtained', async () => {
    const adapter = new ScriptedAdapter([
      toolCallResponse('read-repeat-1', 'read', { file_path: 'src/a.ts' }),
      toolCallResponse('read-repeat-2', 'read', { file_path: 'src/a.ts' }),
      toolCallResponse('read-repeat-3', 'read', { file_path: 'src/a.ts' }),
      toolCallResponse('finish-after-repeats', 'finish', {}),
      textResponse('blocked by repeated unchanged reads'),
    ])
    const ctx = await setup(adapter, { autoVerify: false, noInformationLimit: 3 })
    const agent = createAgent(ctx, 'no-information-finish-blocked')

    const idle = waitForIdle(ctx, agent)
    send(agent, 'Fix src/a.ts.')
    await idle

    expect(toolResultErrors(agent, 'finish')).toEqual([true])
    const status = await policyStatus(ctx, agent, 'no-information-status')
    expect(status.recoveryBlocker).toContain('No-information limit')
  })

  it('stops deterministic invalid-request failures instead of retrying them', async () => {
    const adapter = new DeterministicFailureAdapter()
    const ctx = await setup(adapter, { stopRetryOnDeterministicErrors: true })
    const agent = createAgent(ctx, 'terminal-request-error')

    const idle = waitForIdle(ctx, agent)
    send(agent, 'Analyze src/a.ts.')
    await idle

    expect(adapter.requests).toHaveLength(1)
    const status = await policyStatus(ctx, agent, 'terminal-request-error-status')
    expect(status.phase).toBe('blocked')
    expect(status.blockedReason).toContain('invalid_request_error')
  })

  it('restricts end capabilities through the generated Code Mode SDK while preserving run_code', async () => {
    const adapter = new ScriptedAdapter([textResponse('inspected')])
    const ctx = await setup(adapter, {}, 'code')
    const agent = createAgent(ctx, 'code-mode')

    const idle = waitForIdle(ctx, agent)
    send(agent, 'Fix src/a.ts.')
    await idle

    const request = adapter.requests[0]!
    expect(request.tools?.map(tool => tool.name)).toEqual(['run_code'])
    expect(request.system).toContain('read')
    expect(request.system).not.toMatch(/\bwrite\s*\(/)
    expect(request.system).not.toMatch(/\bedit\s*\(/)
  })

  it('shadow mode preserves the official request byte surface while still observing', async () => {
    const adapter = new ScriptedAdapter([textResponse('baseline')])
    const ctx = await setup(adapter, { mode: 'shadow' })
    const agent = createAgent(ctx, 'shadow')

    const idle = waitForIdle(ctx, agent)
    send(agent, 'Fix src/a.ts.')
    await idle

    const request = adapter.requests[0]!
    expect(texts(request.messages).some(text => text.includes('<trajectory-policy>'))).toBe(false)
    expect(request.tools?.map(tool => tool.name)).toEqual(expect.arrayContaining(['read', 'write', 'edit', 'bash']))
  })
})
