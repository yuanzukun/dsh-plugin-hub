import { describe, expect, it } from 'vitest'
import {
  classifyTaskContract,
  classifyTool,
  compareBenchmarkResults,
  createVerificationDebt,
  debtSatisfied,
  extractArtifacts,
  hasCommandFailure,
  hasObservationCapability,
  initialPhase,
  isFullBenchmark,
  isTerminalLlmFailure,
  mutationToolNames,
  parseBenchmarkResult,
  policyPlan,
  verificationHint,
} from '../src/core.js'

describe('task episodes', () => {
  it('separates conversation from a later real objective', () => {
    expect(classifyTaskContract('你好').relation).toBe('conversation')
    const next = classifyTaskContract('请分析 src/router.ts 并修复这个错误', {
      objective: '你好',
      artifacts: new Set(),
    })
    expect(next.relation).toBe('new-objective')
    expect(next.kind).toBe('fix')
    expect(next.artifacts).toEqual(['src/router.ts'])
  })

  it('recognizes a correction on the same artifact instead of calling it a new task', () => {
    const previous = {
      objective: 'Create cart.js with total()',
      artifacts: new Set(['cart.js']),
    }
    const contract = classifyTaskContract('cart.js 里的 total() 算错了，修复这个 bug', previous)
    expect(contract.relation).toBe('correction')
    expect(contract.kind).toBe('fix')
    expect(initialPhase(contract, false)).toBe('inspect')
  })

  it('recognizes an extension and emits continuity evidence', () => {
    const contract = classifyTaskContract('继续给 cart.js 增加 applyCoupon(code)', {
      objective: 'Create cart.js',
      artifacts: new Set(['cart.js']),
    })
    expect(contract.relation).toBe('extension')
    expect(contract.evidence.join(' ')).toContain('continuity')
    const plan = policyPlan(contract, false)
    expect(plan.restrictBeforeEvidence).toBe(true)
    expect(plan.hint).toContain('relation: extension')
  })

  it('preserves plan mode as design/inspect guidance', () => {
    const contract = classifyTaskContract('全面重构 src/core.ts 的架构')
    expect(contract.risk).toBe('high')
    expect(initialPhase(contract, true)).toBe('inspect')
    expect(policyPlan(contract, true).hint).toContain('preserve the active plan policy')
  })

  it('extracts multiple source artifacts deterministically', () => {
    expect(extractArtifacts('Read src/a.ts, then update tests/a.spec.ts.')).toEqual(['src/a.ts', 'tests/a.spec.ts'])
  })
})

describe('tool semantics and verification debt', () => {
  it('distinguishes observe, mutate, verify, and hybrid editor calls', () => {
    expect(classifyTool('read', { file_path: 'a.ts' }).effect).toBe('observe')
    expect(classifyTool('write', { file_path: 'a.ts', content: 'x' }).effect).toBe('mutate')
    expect(classifyTool('bash', { command: 'pnpm test' }).effect).toBe('verify')
    expect(classifyTool('run_benchmark', {}).effect).toBe('benchmark')
    expect(classifyTool('build_project', {}).effect).toBe('verify')
    expect(classifyTool('finish', {}).effect).toBe('finish')
    expect(classifyTool('str_replace_editor', { command: 'view', path: 'a.ts' }).effect).toBe('observe')
    expect(classifyTool('str_replace_editor', { command: 'str_replace', path: 'a.ts' }).effect).toBe('mutate')
  })

  it('marks likely shell writes as mutation risk without pretending their artifact is known', () => {
    const shellWrite = classifyTool('bash', { command: 'apply_patch <<\'PATCH\'\n*** Begin Patch\nPATCH' })
    expect(shellWrite.effect).toBe('unknown')
    expect(shellWrite.riskyMutation).toBe(true)
    expect(classifyTool('bash', { command: 'rg benchmark src' }).riskyMutation).toBeUndefined()
    expect(createVerificationDebt(shellWrite, 9, 4)?.artifact).toBe('<shell-mutation>')
  })

  it('requires readback and command verification for source code', () => {
    const debt = createVerificationDebt(classifyTool('edit', { file_path: 'src/a.ts' }), 7)
    expect(debt).toBeDefined()
    expect(debtSatisfied(debt!)).toBe(false)
    debt!.readback = true
    expect(debtSatisfied(debt!)).toBe(false)
    debt!.commandVerified = true
    expect(debtSatisfied(debt!)).toBe(true)
  })

  it('requires only readback for documentation', () => {
    const debt = createVerificationDebt(classifyTool('write', { file_path: 'README.md' }), 8)
    expect(debt?.requiresCommand).toBe(false)
    debt!.readback = true
    expect(debtSatisfied(debt!)).toBe(true)
  })

  it('invalidates earlier verification evidence after a later workspace revision', () => {
    const debt = createVerificationDebt(classifyTool('edit', { file_path: 'src/a.ts' }), 10, 3)!
    debt.readback = true
    debt.readbackRevision = 3
    debt.commandVerified = true
    debt.commandVerifiedRevision = 3
    expect(debtSatisfied(debt, 3)).toBe(true)
    expect(debtSatisfied(debt, 4)).toBe(false)
    expect(verificationHint([debt], 1200, 4)).toContain('read back the final artifact')
  })

  it('builds a Code-Mode-safe deny list from end capabilities, never run_code', () => {
    const names = ['run_code', 'read', 'write', 'edit', 'trajectory_policy_status']
    expect(hasObservationCapability(names)).toBe(true)
    expect(mutationToolNames(names, true)).toEqual(['write', 'edit'])
  })

  it('does not cripple a Minimal hybrid-only surface', () => {
    const names = ['bash', 'str_replace_editor']
    expect(hasObservationCapability(names)).toBe(false)
    expect(mutationToolNames(names, false)).toEqual([])
  })
})

describe('benchmark evidence', () => {
  it('parses complete named metrics from structured output and recognizes a full pass', () => {
    const result = parseBenchmarkResult(JSON.stringify({
      total_queries: 10_000,
      recall: '96.2%',
      qps: 1_250.5,
      concurrency: 8,
      warmup: 500,
    }))
    expect(result).toMatchObject({
      totalQueries: 10_000,
      qps: 1_250.5,
      concurrency: 8,
      warmup: 500,
    })
    expect(result?.recall).toBeCloseTo(0.962, 12)
    expect(isFullBenchmark(result!, 10_000, 0.95)).toBe(true)
  })

  it('does not mix 1K and 10K samples, while tolerating small same-spec noise', () => {
    const best = parseBenchmarkResult('{"total_queries":10000,"recall":0.98,"qps":1000,"concurrency":8,"warmup":100}')!
    const noisy = parseBenchmarkResult('{"total_queries":10000,"recall":0.98,"qps":985,"concurrency":8,"warmup":100}')!
    const regression = parseBenchmarkResult('{"total_queries":10000,"recall":0.98,"qps":960,"concurrency":8,"warmup":100}')!
    const shortRun = parseBenchmarkResult('{"total_queries":1000,"recall":0.98,"qps":1200,"concurrency":8,"warmup":100}')!

    expect(compareBenchmarkResults(noisy, best, 2).outcome).toBe('within-tolerance')
    expect(compareBenchmarkResults(regression, best, 2).outcome).toBe('regressed')
    expect(compareBenchmarkResults(shortRun, best, 2).outcome).toBe('different-spec')
  })

  it('rejects incomplete prose as benchmark evidence', () => {
    expect(parseBenchmarkResult('benchmark improved substantially')).toBeUndefined()
  })
})

describe('terminal failures', () => {
  it('recognizes non-zero shell exit text and deterministic invalid requests', () => {
    expect(hasCommandFailure('command failed\n[exit code: 127]')).toBe(true)
    expect(hasCommandFailure('completed\n[exit code: 0]')).toBe(false)
    expect(isTerminalLlmFailure({ status: 400, code: 'invalid_request_error' })).toBe(true)
    expect(isTerminalLlmFailure({ status: 429, code: 'rate_limit_error' })).toBe(false)
  })
})
