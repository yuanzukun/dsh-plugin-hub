import { afterEach, describe, expect, it, vi } from 'vitest'
import { mkdtemp, readFile, readdir, rm, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { DecisionLedger } from '../src/ledger.js'

const temporaryDirectories: string[] = []

afterEach(async () => {
  await Promise.all(temporaryDirectories.splice(0).map(directory => rm(directory, { recursive: true, force: true })))
})

async function temporaryDirectory(): Promise<string> {
  const directory = await mkdtemp(join(tmpdir(), 'trajectory-governor-ledger-'))
  temporaryDirectories.push(directory)
  return directory
}

describe('decision ledger', () => {
  it('rotates the active JSONL file without deleting prior records', async () => {
    const directory = await temporaryDirectory()
    const path = join(directory, 'decisions.jsonl')
    const ledger = new DecisionLedger({ enabled: true, path, maxBytes: 80 })

    ledger.record({ event: 'first', payload: 'a'.repeat(80) })
    ledger.record({ event: 'second', payload: 'b'.repeat(80) })
    await ledger.close()

    const entries = await readdir(directory)
    expect(entries).toHaveLength(2)
    expect(entries).toContain('decisions.jsonl')
    expect(entries.some(entry => entry.startsWith('decisions.jsonl.') && entry.endsWith('.jsonl'))).toBe(true)
    expect(await readFile(path, 'utf8')).toContain('"event":"second"')
    const rotated = entries.find(entry => entry !== 'decisions.jsonl')!
    expect(await readFile(join(directory, rotated), 'utf8')).toContain('"event":"first"')
    expect(ledger.status()).toMatchObject({ rotations: 1, failed: false })
  })

  it('surfaces a write failure once and stops retrying the ledger', async () => {
    const directory = await temporaryDirectory()
    const parentFile = join(directory, 'not-a-directory')
    await writeFile(parentFile, 'fixture', 'utf8')
    const report = vi.spyOn(console, 'error').mockImplementation(() => undefined)
    const ledger = new DecisionLedger({ enabled: true, path: join(parentFile, 'decisions.jsonl'), maxBytes: 80 })

    ledger.record({ event: 'will-fail' })
    ledger.record({ event: 'must-not-retry' })
    await ledger.close()

    expect(ledger.status()).toMatchObject({ enabled: true, failed: true })
    expect(report).toHaveBeenCalledTimes(1)
    report.mockRestore()
  })
})
