#!/usr/bin/env node
import { cpSync, mkdirSync, mkdtempSync, readFileSync, rmSync, symlinkSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { dirname, join, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'
import { WorkspaceTypertGenerator } from '@deepseek-ai/dsh-typert-generator'
import { addLegacyCodecAccess } from './typert-codec-compat.mjs'

const repository = resolve(dirname(fileURLToPath(import.meta.url)), '..')
const workspace = mkdtempSync(join(tmpdir(), 'dsh-explain-typert-'))
const packageRoot = join(workspace, 'packages', 'dsh-explain')
const protocolRoot = join(workspace, 'packages', 'typert', 'protocol')
const dshSource = resolve(repository, 'node_modules', '@deepseek-ai', 'dsh-typert-protocol')

try {
  mkdirSync(packageRoot, { recursive: true })
  cpSync(join(repository, 'src'), join(packageRoot, 'src'), { recursive: true })
  rmSync(join(packageRoot, 'src', 'client'), { recursive: true, force: true })
  mkdirSync(protocolRoot, { recursive: true })
  mkdirSync(join(protocolRoot, 'src'), { recursive: true })
  cpSync(join(dshSource, 'lib', 'types', 'index.d.ts'), join(protocolRoot, 'src', 'index.ts'))
  cpSync(join(dshSource, 'lib', 'types', 'types.d.ts'), join(protocolRoot, 'src', 'types.ts'))
  const protocolManifest = JSON.parse(readFileSync(join(dshSource, 'package.json'), 'utf8'))
  protocolManifest.exports = { '.': './src/index.ts' }
  writeFileSync(join(protocolRoot, 'package.json'), `${JSON.stringify(protocolManifest, null, 2)}\n`)
  writeFileSync(join(protocolRoot, 'tsconfig.json'), `${JSON.stringify({
    compilerOptions: {
      target: 'ES2024',
      module: 'ESNext',
      moduleResolution: 'bundler',
      strict: true,
      noEmit: true,
      skipLibCheck: true,
    },
    include: ['src'],
  }, null, 2)}\n`)
  const manifest = JSON.parse(readFileSync(join(repository, 'package.json'), 'utf8'))
  manifest.exports = {
    '.': './src/index.ts',
    './types': './src/types.ts',
    './typert': {
      types: './lib/typert.host.d.ts',
      default: './lib/typert.host.js',
    },
    './remote': {
      types: './lib/typert.remote-client.d.ts',
      default: './lib/typert.remote-client.js',
    },
  }
  writeFileSync(join(packageRoot, 'package.json'), `${JSON.stringify(manifest, null, 2)}\n`)
  writeFileSync(join(packageRoot, 'tsconfig.json'), `${JSON.stringify({
    compilerOptions: {
      target: 'ES2024',
      module: 'ESNext',
      moduleResolution: 'bundler',
      lib: ['ES2024'],
      types: ['node'],
      strict: true,
      noEmit: true,
      skipLibCheck: true,
      allowImportingTsExtensions: true,
      rewriteRelativeImportExtensions: true,
      baseUrl: '.',
      paths: {
        '@deepseek-ai/dsh-typert-protocol': ['../typert/protocol/src/index.ts'],
      },
      useDefineForClassFields: true,
    },
    include: ['src'],
  }, null, 2)}\n`)
  writeFileSync(join(workspace, 'tsconfig.host.json'), `${JSON.stringify({
    compilerOptions: {
      target: 'ES2024',
      module: 'ESNext',
      moduleResolution: 'bundler',
      strict: true,
      noEmit: true,
      skipLibCheck: true,
      baseUrl: '.',
      paths: {
        '@deepseek-ai/dsh-typert-protocol': ['packages/typert/protocol/src/index.ts'],
      },
    },
    files: [],
    references: [
      { path: './packages/dsh-explain' },
      { path: './packages/typert/protocol' },
    ],
  }, null, 2)}\n`)
  symlinkSync(join(repository, 'node_modules'), join(workspace, 'node_modules'), 'dir')

  const generator = new WorkspaceTypertGenerator(workspace)
  const discovered = generator.discover(['host'])
  const artifacts = generator.generate(['dsh-explain'], ['host'])
  const artifact = artifacts.find(candidate => candidate.package === 'dsh-explain' && candidate.face === 'host')
  if (artifact === undefined || artifact.remote === undefined) {
    const summary = artifacts.map(candidate => ({
      package: candidate.package,
      face: candidate.face,
      remote: candidate.remote !== undefined,
    }))
    throw new Error(`TypeRT generator did not emit the dsh-explain host and Remote artifacts: ${JSON.stringify({ discovered, artifacts: summary })}`)
  }
  mkdirSync(join(repository, 'lib'), { recursive: true })
  const compatible = (source, name) => `${source}\n${addLegacyCodecAccess.toString()}\naddLegacyCodecAccess(${name})\n`
  writeFileSync(join(repository, 'lib', 'typert.host.js'), compatible(artifact.js, 'TYPERT.invocations'))
  writeFileSync(join(repository, 'lib', 'typert.host.d.ts'), artifact.dts)
  writeFileSync(join(repository, 'lib', 'typert.remote-client.js'), compatible(artifact.remote.js, 'TYPERT_REMOTE.descriptors'))
  writeFileSync(join(repository, 'lib', 'typert.remote-client.d.ts'), artifact.remote.dts)
  writeFileSync(join(repository, 'lib', 'typert.remote-client.d.ts.map'), artifact.remote.dtsMap)
  console.log('generated TypeRT host and Remote artifacts')
} finally {
  rmSync(workspace, { recursive: true, force: true })
}
