import type { Branded } from '@deepseek-ai/dsh-brand'

/** Stable identity of one learned topic. */
export type TopicId = Branded<'dsh-explain/topic'>

/** Stable identity of one explanation and its rephrase revisions. */
export type ExplanationId = Branded<'dsh-explain/explanation'>

/** Stable identity of one append-only learning-thread entry. */
export type EntryId = Branded<'dsh-explain/entry'>

/** Stable identity of one structured ExplainContext observation. */
export type ObservationId = Branded<'dsh-explain/observation'>

/** Stable identity of one full ExplainContext checkpoint. */
export type CheckpointId = Branded<'dsh-explain/checkpoint'>

/** Client-generated idempotency identity for one feedback mutation. */
export type RequestId = Branded<'dsh-explain/request'>

/** Host-generated identity for one accepted autonomous model request. */
export type AutoRequestId = Branded<'dsh-explain/auto-request'>

/** Stable identity of one three-question review round. */
export type ReviewBatchId = Branded<'dsh-explain/review-batch'>

/** Stable identity of one persisted review question and answer. */
export type ReviewId = Branded<'dsh-explain/review'>

/** Construct a TopicId after persistence-boundary validation. */
export const TopicId = (value: string): TopicId => value as TopicId

/** Construct an ExplanationId after persistence-boundary validation. */
export const ExplanationId = (value: string): ExplanationId => value as ExplanationId

/** Construct an EntryId after persistence-boundary validation. */
export const EntryId = (value: string): EntryId => value as EntryId

/** Construct an ObservationId after persistence-boundary validation. */
export const ObservationId = (value: string): ObservationId => value as ObservationId

/** Construct a CheckpointId after persistence-boundary validation. */
export const CheckpointId = (value: string): CheckpointId => value as CheckpointId

/** Construct a RequestId after wire-boundary validation. */
export const RequestId = (value: string): RequestId => value as RequestId

/** Construct an AutoRequestId after persistence-boundary validation. */
export const AutoRequestId = (value: string): AutoRequestId => value as AutoRequestId

/** Construct a ReviewBatchId after persistence-boundary validation. */
export const ReviewBatchId = (value: string): ReviewBatchId => value as ReviewBatchId

/** Construct a ReviewId after persistence-boundary validation. */
export const ReviewId = (value: string): ReviewId => value as ReviewId
