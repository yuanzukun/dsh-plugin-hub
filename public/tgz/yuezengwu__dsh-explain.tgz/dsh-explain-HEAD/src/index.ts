/**
 * dsh-explain host plugin: one global SQLite learning thread and its typed Remote service.
 * @module dsh-explain
 */
import type { Context } from '@deepseek-ai/cordis'
import type { CommandResult } from '@deepseek-ai/dsh-commands'
import type { SessionEvent } from '@deepseek-ai/dsh-session'
// Type-only imports install the consumed service/event declarations on Context.
import type {} from '@deepseek-ai/dsh-llm'
import type {} from '@deepseek-ai/dsh-settings'
import type {} from '@deepseek-ai/dsh-token-meter'
import { RequestId } from './brands.ts'
import { readExplainConfig, runtimeSettings, resolveExplainConfig, type ExplainPluginConfig } from './config.ts'
import { ExplainGateway } from './gateway.ts'
import {
  captureManualExplainTarget,
  captureSelectionExplainTarget,
  captureSourceCapsule,
  captureAnswerExplainTarget,
  observeSession,
} from './observer.ts'
import { ExplainRuntime } from './runtime.ts'
import { ExplainStore } from './store.ts'
import type { ThreadEntryView } from './types.ts'

declare module '@deepseek-ai/cordis' {
  interface Context {
    /** Host-side global learning-thread Remote service. */
    explain: ExplainGateway
  }
}

export const name = 'dsh-explain'

/** Required host services for global observation, auxiliary calls, settings, and slash commands. */
export const inject = ['sessions', 'llm', 'tokenMeter', 'settings', 'commands', 'sessionController']

export { Config } from './config.ts'
export type { ExplainConfig, ResolvedExplainConfig } from './config.ts'
export { ExplainGateway } from './gateway.ts'
export * from './brands.ts'
export type * from './types.ts'

/** Open the global runtime, observe eligible completed turns, and publish commands and Remote methods. */
export async function apply(ctx: Context, config: ExplainPluginConfig): Promise<void> {
  const resolved = resolveExplainConfig(readExplainConfig(config))
  const store = new ExplainStore(resolved.databasePath)
  const runtime = new ExplainRuntime(ctx, store, resolved, () => runtimeSettings(resolveExplainConfig(readExplainConfig(config))))
  try {
    await runtime.start()
  } catch (error) {
    await runtime.dispose().catch(() => {})
    store.close()
    throw error
  }
  ctx.effect(() => async () => {
    await runtime.dispose()
    store.close()
  }, 'dsh-explain: stop runtime and close SQLite store')

  const gateway = new ExplainGateway(ctx, store, runtime)
  registerExplainCommand(ctx, runtime, gateway)
  registerReviewCommand(ctx, gateway)

  const observationAbort = new AbortController()
  ctx.effect(() => () => observationAbort.abort(), 'dsh-explain: cancel history reads')
  const seenTurnEnds = new WeakMap<object, number>()
  const logger = ctx.logger('dsh-explain')
  ctx.on('session/event', (session, event) => {
    if (event.type !== 'turn/end' || session.header.origin === 'subagent'
      || !runtime.settings().enabled || (seenTurnEnds.get(session) ?? -1) >= event.seq) return
    seenTurnEnds.set(session, event.seq)
    const generation = runtime.scheduler.generation()
    const observe = async (): Promise<void> => {
      try {
        if (!runtime.scheduler.acceptsGeneration(generation)) return
        const capsule = await captureSourceCapsule(
          observeSession(session, ctx.sessionController, observationAbort.signal),
          event as SessionEvent<'turn/end'>,
          runtime.settings().maxSourceChars,
        )
        if (capsule !== undefined && runtime.scheduler.acceptsGeneration(generation)) runtime.scheduler.enqueue(capsule)
      } catch (error) {
        if (!observationAbort.signal.aborted) logger.warn('completed-turn observation failed: %s', safeMessage(error))
      }
    }
    queueMicrotask(() => { void observe() })
  }, { global: true })
}

function registerReviewCommand(ctx: Context, gateway: ExplainGateway): void {
  ctx.commands.register({
    name: 'review',
    description: 'Start or resume today\'s local learning review',
    handler: (): CommandResult => {
      const result = gateway.startReview({ requestId: RequestId(`command:${crypto.randomUUID()}`) })
      if (!result.ok) return { kind: 'error', text: `${result.error.code}: ${result.error.message}` }
      const current = result.dashboard.current
      return current === undefined
        ? { kind: 'success', text: 'No review question is pending.' }
        : {
            kind: 'success',
            text: `Review ready (${current.position}/${current.total}): ${current.topicTitle}. Open Learning to answer it.`,
          }
    },
  })
}

function registerExplainCommand(ctx: Context, runtime: ExplainRuntime, gateway: ExplainGateway): void {
  ctx.commands.register({
    name: 'explain',
    description: 'Request a learning explanation or control the global learning thread',
    input: { hint: '<request> | on | off | status' },
    handler: async (invocation): Promise<CommandResult> => {
      const action = invocation.rawInput.trim()
      if (action === 'status') return { kind: 'success', text: renderStatus(gateway.status()) }
      if (action === 'on' || action === 'off') {
        const error = await runtime.setEnabled(action === 'on', invocation.signal)
        if (error !== undefined) return { kind: 'error', text: `${error.code}: ${error.message}` }
        return { kind: 'success', text: renderStatus(gateway.status()) }
      }
      if (action === '') return { kind: 'error', text: 'Usage: /explain <request> | on | off | status' }
      const parsed = parseExplainRequest(action)
      if (!parsed.ok) return { kind: 'error', text: `EXPLAIN_INVALID_REQUEST: ${parsed.message}` }
      const generation = runtime.scheduler.generation()
      const source = observeSession(invocation.agent.session, ctx.sessionController, invocation.signal)
      const target = parsed.origin === 'selection'
        ? await captureSelectionExplainTarget(
            source,
            parsed.request,
            runtime.settings().maxSourceChars,
          )
        : parsed.origin === 'answer'
          ? await captureAnswerExplainTarget(
              source,
              parsed.turn,
              parsed.request,
              runtime.settings().maxSourceChars,
            )
          : await captureManualExplainTarget(
              source,
              parsed.request,
              runtime.settings().maxSourceChars,
            )
      if (target === undefined) {
        return {
          kind: 'error',
          text: 'EXPLAIN_SOURCE_UNAVAILABLE: The referenced answer is no longer available as a settled turn.',
        }
      }
      if (generation !== runtime.scheduler.generation()) {
        return { kind: 'error', text: 'EXPLAIN_REQUEST_CANCELLED: Learning settings or data changed while reading the source.' }
      }
      const result = await runtime.scheduler.requestManual(target, invocation.signal)
      return result.ok
        ? { kind: 'success', text: `Explanation added to Learning: ${explanationTitle(result.entry)}` }
        : { kind: 'error', text: `${result.error.code}: ${result.error.message}` }
    },
  })
}

type ParsedExplainRequest =
  | { readonly ok: true; readonly origin: 'manual' | 'selection'; readonly request: string }
  | { readonly ok: true; readonly origin: 'answer'; readonly turn: number; readonly request: string }
  | { readonly ok: false; readonly message: string }

function parseExplainRequest(action: string): ParsedExplainRequest {
  const selection = /^--selection(?:\s+([\s\S]*))?$/u.exec(action)
  if (selection !== null) {
    const request = selection[1]?.trim() ?? ''
    return request === ''
      ? { ok: false, message: 'Usage: /explain --selection <selected text>' }
      : { ok: true, origin: 'selection', request }
  }
  if (/^--(?:answer|suggested)(?:\s|$)/u.test(action)) {
    const match = /^--(?:answer|suggested)\s+([1-9][0-9]*)\s+([\s\S]+)$/u.exec(action)
    const turn = match?.[1] === undefined ? undefined : Number(match[1])
    const request = match?.[2]?.trim()
    return turn === undefined || !Number.isSafeInteger(turn) || request === undefined || request === ''
      ? { ok: false, message: 'Usage: /explain --answer <source turn> <request>' }
      : { ok: true, origin: 'answer', turn, request }
  }
  return { ok: true, origin: 'manual', request: action }
}

function explanationTitle(entry: ThreadEntryView): string {
  if (entry.kind !== 'explanation' || !('title' in entry.payload)) {
    throw new Error('dsh-explain: manual explanation committed no explanation title')
  }
  return entry.payload.title
}

function renderStatus(status: ReturnType<ExplainGateway['status']>): string {
  const route = status.provider === undefined || status.model === undefined
    ? 'not configured'
    : `${status.provider}/${status.model}`
  const capacity = status.contextWindow === undefined ? 'unavailable' : `${status.contextWindow} tokens`
  const pressure = status.estimatedContextRatio === undefined
    ? 'not measured'
    : `${(status.estimatedContextRatio * 100).toFixed(1)}%`
  return [
    `Explain: ${status.enabled ? 'on' : 'off'} (${status.runtimeState})`,
    `Route: ${route}; capacity: ${capacity}`,
    `Active: ${status.activeExplanationCount}; candidates: ${status.pendingCandidateCount}`,
    `Auto budget: ${status.autoRequestsUsed}/${status.autoRequestsLimit}; pressure: ${pressure}`,
    `Last action: ${formatTime(status.lastUserActionAt)}; last compaction: ${formatTime(status.lastCompactedAt)}`,
  ].join('\n')
}

function formatTime(value: number | undefined): string {
  return value === undefined ? 'never' : new Date(value).toISOString()
}

function safeMessage(error: unknown): string {
  return error instanceof Error ? error.message : 'unknown observation failure'
}
