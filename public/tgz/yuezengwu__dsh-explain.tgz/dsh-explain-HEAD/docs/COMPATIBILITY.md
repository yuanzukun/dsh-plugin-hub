# DSH 兼容约定

核验日期：2026-10-28（CLI npm latest：DSH 0.2.1-rc.2；next：0.2.1-rc.4、alpha：0.2.2-alpha.2，后两版待兼容验证）。

<a id="current-npm-next-verification"></a>

## 当前 npm 预发布渠道验证边界

2026-10-28 核对 [CLI npm 标签](https://registry.npmjs.org/-/package/@deepseek-ai%2fdsh/dist-tags) 为 `latest=0.2.1-rc.2`、`next=0.2.1-rc.4`、`alpha=0.2.2-alpha.2`；[store 独立标签](https://registry.npmjs.org/-/package/@deepseek-ai%2fdsh-client-store/dist-tags) 为 `latest=0.1.2-alpha.2`、`next=0.2.1-rc.4`、`alpha=0.2.2-alpha.2`。新 alpha 的 CLI 与二十三个配套 API 包元数据均可读取，但没有 `gitHead`。rc.4 与 0.2.2-alpha.2 的官方 tag / Release API 仍返回 404，远端 tag 查询也无匹配，因此尚无可归属到这两版的固定源码宿主证据。

0.2.2-alpha.2 包声明新预发布依赖 Cordis `~4.0.6-alpha.1`、Schemastery `~3.18.6-alpha.1`。使用协调的 `dsh-client-store@0.2.2-alpha.2` 与 `cordis@4.0.6-alpha.1` 在全新临时 npm 项目中安装成功，随后独立 import 仍报 `ERR_MODULE_NOT_FOUND: zustand`；Immer/Zustand 继续仅列于 devDependencies。rc.4 的包级复现沿用 [M37](./ACCEPTANCE.md) 的 2026-10-27 记录。这些包级观察不等于 Explain 运行验收。

本轮只更新渠道与安装说明，继续固定 rc.3 开发依赖及二十四个已验证源码宿主；不接纳 rc.4 / 0.2.2-alpha.2 到引擎、peer 或源码矩阵，也不新增尚未使用的依赖补丁。已验证 rc.3 的官方兼容检查器复核现有声明时，接受 rc.2 / rc.3，拒绝 rc.4 / 0.2.2-alpha.2，无版本豁免；此检查不表示运行了新宿主。

默认安装继续固定 rc.2，已验证候选版固定 rc.3，不使用尚未验收的 `@next` / `@alpha`。待官方 tag 可解析到精确提交后，再协调新 API、Cordis/Schemastery 和全部旧宿主，完成发布包、固定源码、Web / M6 及当前提交 CI 验证。既有运行时验收保持原始日期，见 [M38](./ACCEPTANCE.md)。

## 已验证版本

M29（2026-10-09）保留当时十七个版本与 SHA，并增加兼容一致性门禁；当前测试扩至 108 项，表内 90 项为既有兼容里程碑的验收记录。共享清单为 [dsh-hosts.json](../scripts/dsh-hosts.json)，`pnpm compat:check` 核对 CI 精确 SHA、`engines.dsh`、peer 范围、协调开发依赖和表内 Web/M6 夹具能力；源码链接与组装夹具从该清单读取版本能力，拒绝未知宿主。新支持版本仍须实际验收，不能只改清单扩大承诺。

| 来源 | 版本 | 精确提交 | 验证范围 |
|---|---|---|---|
| CLI npm latest 配套 API 发布包 | `0.2.1-rc.2` | 2026-10-18 发布包验证 | frozen install、类型检查、108 项单元/集成测试、生产构建、实际 pack |
| 先前 CLI npm next 配套 API 发布包 | `0.2.1-rc.3` | 发布包安装与锁文件 | frozen install、类型检查、108 项单元/集成测试、生产构建、实际 pack |
| 先前 CLI npm alpha 配套 API 发布包 | `0.2.1-alpha.5` | 发布包安装与锁文件 | frozen install、类型检查、108 项单元/集成测试、生产构建、实际 pack |
| 先前 CLI npm alpha 配套 API 发布包 | `0.2.1-alpha.4` | 2026-10-16 发布包验证 | frozen install、类型检查、108 项单元/集成测试、生产构建、实际 pack |
| 先前 CLI npm alpha 配套 API 发布包 | `0.2.1-alpha.3` | 2026-10-15 发布包验证 | frozen install、类型检查、106 项单元/集成测试、生产构建、实际 pack |
| 先前 CLI npm alpha 配套 API 发布包 | `0.2.1-alpha.2` | 2026-10-10 发布包验证 | frozen install、类型检查、106 项单元/集成测试、生产构建、实际 pack |
| 先前 CLI npm alpha 配套 API 发布包 | `0.2.1-alpha.1` | 2026-10-04 发布包验证 | frozen install、类型检查、90 项单元/集成测试、生产构建、实际 pack |
| 先前 CLI npm latest 配套 API 发布包 | `0.2.0-rc.2` | 2026-09-30 发布包验证 | frozen install、类型检查、90 项单元/集成测试、生产构建、实际 pack |
| 先前 CLI npm latest 配套 API 发布包 | `0.1.7-rc.2` | 2026-09-25 发布包验证 | 类型检查、90 项单元/集成测试、生产构建、实际 pack |
| DSH 0.1.2-rc.1 源码 | `0.1.2-rc.1` | `a66e4702047846cdaa10c66c9d3df3951f5ea70d` | 类型检查、90 项测试、7 个 Web 场景、3 个 M6 场景 |
| DSH alpha.1 源码 | `0.1.3-alpha.1` | `d347e703908d0406b7a7ef80e3a0e594d86b2215` | 类型检查、90 项测试、7 个 Web 场景、3 个 M6 场景 |
| DSH alpha.2 源码 | `0.1.3-alpha.2` | `82a5fd61a7cf5c293cec4bdff68f455398d685e9` | 类型检查、90 项测试、7 个 Web 场景、3 个 M6 场景 |
| DSH 0.1.5-alpha.1 源码 | `0.1.5-alpha.1` | `5dda764ed3aa172535a7967b06ff95d9cbfe536a` | 类型检查、90 项测试、7 个 Web 场景、3 个 M6 场景 |
| DSH 0.1.5-alpha.2 源码 | `0.1.5-alpha.2` | `b2e3b2a0125854567a4a5fcba75782e42fe84901` | 类型检查、90 项测试、7 个 Web 场景、3 个 M6 场景 |
| DSH 0.1.5-rc.1 源码 | `0.1.5-rc.1` | `183f08e9c6dde7e36cd2318eaee70b0da08fb35e` | 类型检查、90 项测试、7 个 Web 场景、3 个 M6 场景 |
| DSH 0.1.5-rc.2 源码 | `0.1.5-rc.2` | `fb2c4b9e698e30edb738bca4cf0618587db7d203` | 类型检查、90 项测试、7 个 Web 场景、3 个 M6 场景 |
| DSH 0.1.5-rc.3 源码 | `0.1.5-rc.3` | `a4c74a91e06b00fe0b0937bde982170c526cc842` | 类型检查、90 项测试、7 个 Web 场景、3 个 M6 场景 |
| DSH 0.1.6-alpha.1 源码 | `0.1.6-alpha.1` | `0a15e36e7f82b6ed45af6fa9759f29b40dcd965d` | 类型检查、90 项测试、7 个 Web 场景、3 个 M6 场景 |
| DSH 0.1.6-alpha.2 源码 | `0.1.6-alpha.2` | `ddefc45fbc7f8e46dd73185e68295696d1297887` | 类型检查、90 项测试、7 个 Web 场景、3 个 M6 场景（含实时停用/启用） |
| DSH 0.1.7-alpha.1 源码 | `0.1.7-alpha.1` | `c36a83ff6bb95e3f82cf79f9be7c724270a8aa61` | 类型检查、90 项测试、8 个 Web 场景、3 个 M6 场景 |
| DSH 0.1.7-alpha.2 源码 | `0.1.7-alpha.2` | `00102833dfaee1da9f48a3a8eae9d34005a75218` | 类型检查、90 项测试、8 个 Web 场景、3 个 M6 场景 |
| DSH 0.1.7-rc.1 源码 | `0.1.7-rc.1` | `46a7f68b0922371ce7144b668b90e377d8e799f4` | 类型检查、90 项测试、8 个 Web 场景、3 个 M6 场景 |
| DSH 0.1.7-rc.2 源码 | `0.1.7-rc.2` | `477b4f420553e8a52c2fbccc464d7561b239c443` | 类型检查、90 项测试、8 个 Web 场景、3 个 M6 场景 |
| DSH 0.2.0-rc.1 源码 | `0.2.0-rc.1` | `4878cdabd87d4041bdaff61d04c966883b9fd07a` | 类型检查、90 项测试、8 个 Web 场景、3 个 M6 场景 |
| DSH 0.2.0-rc.2 源码 | `0.2.0-rc.2` | `639ed015397290b3745d163aafe02ffee4aa3f84` | 类型检查、90 项测试、8 个 Web 场景、3 个 M6 场景 |
| DSH 0.2.1-alpha.1 源码 | `0.2.1-alpha.1` | `5badb15009ae1756c3afe0ae0cef1faafc290ccc` | 类型检查、90 项测试、8 个 Web 场景、3 个 M6 场景 |
| 先前 DSH 源码发布 | `0.2.1-alpha.2` | `d743267388641bc76f17c45ce8b4c231aed1d32c` | 类型检查、106 项测试、8 个 Web 场景、3 个 M6 场景 |
| 先前 DSH 源码发布 | `0.2.1-alpha.3` | `2fbf4359b82fb94c03dcce0b831660d87f12ea5c` | 类型检查、106 项测试、8 个 Web 场景、3 个 M6 场景 |
| 先前 DSH 源码发布 | `0.2.1-alpha.4` | `86a402200d95fecef4529d969836f1fe13c6cb0d` | 类型检查、108 项测试、8 个 Web 场景、3 个 M6 场景 |
| 先前 CLI npm alpha 对应源码 | `0.2.1-alpha.5` | `1517a4dbca0a2789ff1d41ba439600f8547d23fa` | 类型检查、108 项测试、8 个 Web 场景、3 个 M6 场景 |
| DSH 0.2.1-rc.1 源码 | `0.2.1-rc.1` | `1600d8a1e140dcde43a1a0941940a0480712c011` | 类型检查、108 项测试、8 个 Web 场景、3 个 M6 场景 |
| DSH 0.2.1-rc.2 源码 | `0.2.1-rc.2` | `687f282e8625c6b8d11ff58211a90524be2e4317` | 类型检查、108 项测试、8 个 Web 场景、3 个 M6 场景 |
| DSH 0.2.1-rc.3 源码 | `0.2.1-rc.3` | `1f81c047fc48fa190a683e469daa699857e9afe8` | 类型检查、108 项测试、8 个 Web 场景、3 个 M6 场景 |

[官方 0.2.1-rc.3](https://github.com/deepseek-ai/deepseek-harness/releases/tag/dsh-v0.2.1-rc.3) 于 2026-10-23 15:26:39 UTC 发布，tag 直接固定源码 `1f81c047fc48fa190a683e469daa699857e9afe8`。2026-10-24 核对 CLI npm `latest=0.2.1-rc.2`、`next=0.2.1-rc.3`、`alpha=0.2.1-alpha.5`；store 自身为 `latest=0.1.2-alpha.2`、`next=0.2.1-rc.3`、`alpha=0.2.1-alpha.5`。M36 固定 rc.3 开发发布包，协调锁文件、精确 peer、引擎、清单和 CI，保留全部二十三个旧宿主并扩至二十四版。新的 More 菜单与草稿选项不要求 Explain 改用新接口；原始 store 仍可复现缺失 Zustand，因此只追加 rc.3 精确补丁。业务源码、Host/Client bundle、旧 golden、SQLite schema 4 与 backup v3 不变；TypeRT 产物重新生成。发布包及固定源码验收见 [M36](./ACCEPTANCE.md)，新 Explain 标签、真实 provider、账号模型、Desktop 与 Session 降级不在本轮范围。

2026-10-20 核对 CLI npm `latest` 已从 `0.2.0-rc.2` 改指 `0.2.1-rc.2`，与 `next` 相同；`alpha` 仍为 `0.2.1-alpha.5`。`@deepseek-ai/dsh@latest` 与固定 `0.2.1-rc.2` 的版本、tarball URL、integrity 和 shasum 一致，官方 rc.2 tag 仍直接固定源码 `687f282e8625c6b8d11ff58211a90524be2e4317`。store 自身的独立标签仍为 `latest=0.1.2-alpha.2`、`next=0.2.1-rc.2`、`alpha=0.2.1-alpha.5`。M35 更新当前安装说明和渠道标注，继续固定安装 rc.2，完整保留二十三个已验收源码宿主（含 0.2.0-rc.2）、peer、`engines.dsh`、开发依赖、锁文件和精确 store 补丁。M34 的运行时兼容证据保持原日期，当前提交 CI 与不可变安装结果随本轮 PR 保存；没有新增 Explain 发布标签。

[官方 0.2.1-rc.1](https://github.com/deepseek-ai/deepseek-harness/releases/tag/dsh-v0.2.1-rc.1) 与 [rc.2](https://github.com/deepseek-ai/deepseek-harness/releases/tag/dsh-v0.2.1-rc.2) 分别于 2026-10-17 05:22:10 / 08:16:33 UTC 发布，直接 tag SHA 见表。2026-10-18 核对 CLI npm `latest=0.2.0-rc.2`、`next=0.2.1-rc.2`、`alpha=0.2.1-alpha.5`；store 独立标签为 `latest=0.1.2-alpha.2`、`next=0.2.1-rc.2`、`alpha=0.2.1-alpha.5`。M34 协调 rc.2 发布 API、Cordis `4.0.5`、Schemastery `3.18.5`、锁文件、精确 peer、`engines.dsh`、共享清单与 CI，保留全部二十一个旧宿主并扩至二十三版。Explain 消费的 Session 分页、LLM 与 TypeRT 接口源码没有变化；新增模型及 Search/Fetch API 的实际调用不在本轮无密钥验收范围。发布包与两个精确源码宿主的实际结果见 [M34](./ACCEPTANCE.md)。

[官方 0.2.1-alpha.5](https://github.com/deepseek-ai/deepseek-harness/releases/tag/dsh-v0.2.1-alpha.5) 于 2026-10-16 12:23:28 UTC 发布，tag 直接固定提交 `1517a4dbca0a2789ff1d41ba439600f8547d23fa`。2026-10-17 核对 CLI npm `alpha=0.2.1-alpha.5`、`latest=next=0.2.0-rc.2`；store 自身 `alpha=0.2.1-alpha.5`、`next=0.2.0-rc.2`、`latest=0.1.2-alpha.2`。M33 更新配套 API、锁文件、精确 peer、`engines.dsh` 与 CI，新增第二十一个固定宿主并保留全部二十版旧宿主。Explain 不使用新增的 `conversation.input.model.label` Slot，现有业务接口与 TypeRT 生成方式保持不变；Cordis/Schemastery 固定源码版本仍沿用 M32。实际验收见 [M33](./ACCEPTANCE.md)，无真实 provider、账号模型或 Desktop 验收。

[官方 0.2.1-alpha.4](https://github.com/deepseek-ai/deepseek-harness/releases/tag/dsh-v0.2.1-alpha.4) 于 2026-10-15 13:40:02 UTC 发布，tag 直接固定提交 `86a402200d95fecef4529d969836f1fe13c6cb0d`。2026-10-16 核对 CLI npm `alpha=0.2.1-alpha.4`、`latest=next=0.2.0-rc.2`；store 自身 `alpha=0.2.1-alpha.4`、`next=0.2.0-rc.2`、`latest=0.1.2-alpha.2`。M32 更新配套发布包、锁文件、精确 peer 和 CI，增加第二十个固定宿主，保留全部十九版旧宿主。新版安装与启动优先检查 `engines.dsh`；Explain 显式枚举清单中二十个精确版本，兼容一致性检查拒绝遗漏和未验收版本。此前 peer 范围仍保留，旧宿主可继续加载。Cordis/Schemastery 和业务逻辑沿用 M31；无真实 provider、账号模型或 Desktop 验收。见 [M32 验收](./ACCEPTANCE.md)。

[官方 0.2.1-alpha.3](https://github.com/deepseek-ai/deepseek-harness/releases/tag/dsh-v0.2.1-alpha.3) 于 2026-10-14 13:32:15 UTC 发布，tag 直接指向提交 `2fbf4359b82fb94c03dcce0b831660d87f12ea5c`。2026-10-15 核对 CLI npm `alpha=0.2.1-alpha.3`、`latest=next=0.2.0-rc.2`；store 的独立标签为 `latest=0.1.2-alpha.2`、`next=0.2.0-rc.2`、`alpha=0.2.1-alpha.3`。M31 协调新 API 与 Cordis/Schemastery 预发布依赖、锁文件、精确 peer 和 CI，新增第十九个固定宿主并保留全部十八版旧宿主。TypeRT 生成临时工作区保留完整协议声明与扩展类型归属，官方 Remote helper 随产物打包以支持旧宿主；夹具按清单适配首次启动选择页和账号菜单。发布包与源码验收结果见 [M31](./ACCEPTANCE.md)；无密钥验证不表示真实 provider、账号模型或 Desktop 已验收。

[官方 0.2.1-alpha.2](https://github.com/deepseek-ai/deepseek-harness/releases/tag/dsh-v0.2.1-alpha.2) 于 2026-10-09 11:09:26 UTC 发布；annotated tag `6851e496285b2c9670066fdd142e7e46da586649` 解析到提交 `d743267388641bc76f17c45ce8b4c231aed1d32c`。2026-10-10 核对 CLI npm `alpha=0.2.1-alpha.2`，`latest=next=0.2.0-rc.2`；store 自身的 `latest` 仍为 `0.1.2-alpha.2`，其 `alpha/next` 分别为 `0.2.1-alpha.2` / `0.2.0-rc.2`。M30 协调开发依赖、锁文件、精确 peer、共享清单与 CI，扩至十八个宿主，保留此前十七版。新增 Session plugin records 与 LLM `prepareCall` 的可选第三参数不需要 Explain 改用新接口；Explain 继续经异步 page 读取来源并使用自己的辅助路由，不写主 Session 插件状态。本地发布包及固定源码验证见 [M30](./ACCEPTANCE.md)，不证明真实模型、账号或桌面端可用性。

[官方 0.2.1-alpha.1](https://github.com/deepseek-ai/deepseek-harness/releases/tag/dsh-v0.2.1-alpha.1) 于 2026-10-03 06:42:19 UTC 发布，精确 tag 为上表 SHA。2026-10-04 核对：`@deepseek-ai/dsh` 的 npm `alpha` 指向 `0.2.1-alpha.1`，`latest` 与 `next` 仍指向 `0.2.0-rc.2`；各 API 包的 dist-tag 独立。M28 当时固定 alpha.1 配套 API 发布包，peer 声明扩至十七个宿主版本，保留此前十六版。新版移除运行时 invariant 插件及 `./invariant` 导出，并拆分输入区统计入口；Explain 不使用这些入口，因此无须改动业务逻辑，但要移除不再发布的 `dsh-invariants` 开发依赖，更新 Cordis/Schemastery 预发布依赖、锁文件及组装矩阵。本地无密钥验证见 [M28](./ACCEPTANCE.md)，不证明真实模型路由。此前 rc.2 的验证与差异见 [M27](./ACCEPTANCE.md)。

0.1.7-rc.2 的宿主设置页新增 DeepSeek Account provider 选项；两个 0.2.0 候选版均保留该无密钥界面选项，复用对应设置快照，不据此声称账号模型实际调用已验收。新宿主在侧边栏把无标题 Session 显示为「未命名」，组装测试按固定 Session ID 定位；旧宿主仍使用原定位方式。

### 0.1.7：设置迁移与 Session V4

新宿主移除 `settings.installSection`，Explain 在 Config 中声明可实时更新的字段，按当前 Loader entry id 保存到 profile patch，并通过 volatile-update 同步调度器。旧宿主继续使用原 settings namespace。存储路径始终不是可实时编辑字段。

首次进入新宿主时，Explain 从宿主的 `settings.yaml` 或保留的 `settings.yaml.imported` 中提取自己的旧 section，忽略其他插件和存储字段；已有 profile 显式设置优先。成功后在 profile 目录写入 `.dsh-explain-settings-migrated`，避免以后清空设置时再次导入旧值。源文件不被修改；失败保留源文件且不写完成标记，日志提示迁移未完成。不同 profile 各自迁移；共享学习 SQLite 的单实例租约不变。

Session V4 的工具结果采用平铺 tool-role 消息，旧版嵌套 tool-result 仍能读取。辅助请求声明 Explain 自己的消息来源，系统提示词由宿主构造函数生成；不进入主 Agent，也不读取仅存在于自定义事件中的附件。来源隔离测试在宿主真实 Session 上确认系统提示词、reasoning 和合成上下文不进入 capsule，主会话消息保持不变。快捷入口同时接受新版 Regular 图标和旧版图标。

TypeRT 0.1.7 把 RPC 校验器从 `schema` 改为惰性的 `create()`；构建时为生成的 Host / Remote 产物补充两种访问入口，共用同一校验器，新宿主仍保持惰性初始化。CI 先以 npm 锁定依赖构建一份 tarball，再让十七个固定宿主的 Web / M6 测试安装同一产物，防止每个宿主分别构建时掩盖旧版本加载失败。

0.1.7 的官方 DeepSeek 适配器仅支持 Messages API，旧适配器配置需遵循宿主发布说明迁移。此次无密钥验证不证明真实 provider 可用性；之前的 deepseek-flash 验收仅属于 0.1.6-alpha.1。

### 客户端 Session 与实时卸载

0.1.6-alpha.2 将客户端来源导航从 `sessions.open()` 移至 `uiWorkspace.openSession()`，Session slot 注入目标从 id 变为持有具体 generation 的 reference。Explain 在新版使用工作区导航，并从 slot reference 的 binding 获取输入框作用域；旧版继续使用 id 与原导航。已释放 reference 的延迟点击不会创建新的引用或写入别的输入框，已有草稿和忙碌状态继续受保护。

M6 在 `0.1.6-alpha.2` 的插件管理页实际停用、重新启用 Explain，检查样式、学习入口和快捷操作卸载及单份恢复，再读取恢复后的学习状态；同时保留所有宿主的 CLI 移除/重新安装检查。宿主 runtime disposer、SQLite 关闭和客户端 long-poll 清理沿用原有生命周期。学习 SQLite 仍为 schema 4，导出仍为 backup v3。

新版默认模型列表移除了 V4 Flash 与 V4 Flash Vision Exp。Explain 继续使用用户明确配置的辅助路由；9 月 15 日的真实 deepseek-flash 验收只归属于当时的 0.1.6-alpha.1，不作为新版模型可用性证明。本轮使用无密钥夹具。

### 异步 Session 历史读取

Explain 的来源观察和手动来源定位已迁移至公开的 `sessionController.page()`，生产代码不再调用 `snapshotEvents()`、`eventAt()` 或 `ownEvents()`。每次读取固定 `throughSeq`，以 `beforeSeq` 逆序分页（每页最多 16 条逻辑消息），只物化目标回合；不建立完整历史副本。该分页契约在表中十个宿主上均可用，旧宿主的打包 stream chunk 记录仅参与游标推进，不进入来源正文。

分页读取支持 AbortSignal；收到取消后的页面不会参与捕获。自动观察与手动命令在等待历史后检查 runtime generation，关闭学习、清空数据或更换模型期间的旧请求不能重新入队。系统提示词、reasoning 和合成用户上下文继续排除，主 Session 消息保持不变。宿主内部如何加载或缓存历史由 DSH 负责，这次迁移不表示上游已完成全部内存优化。上游决定见[弃用说明](https://github.com/deepseek-ai/deepseek-harness/blob/0a15e36e7f82b6ed45af6fa9759f29b40dcd965d/.agents/notes/implemented/architecture/2026-09-09-deprecate-synchronous-session-event-reads.md)。

## 发布包依赖修复

`dsh-client-store` 在 `0.1.5-alpha.2`、`0.1.5-rc.1`、`0.1.5-rc.2`、`0.1.6-alpha.1`、`0.1.6-alpha.2`、`0.1.5-rc.3`、`0.1.7-alpha.1`、`0.1.7-alpha.2`、`0.1.7-rc.1`、`0.1.7-rc.2`、`0.2.0-rc.1` 和 `0.2.0-rc.2`、`0.2.1-alpha.1`、`0.2.1-alpha.2` 的产物中仍导入 Zustand/Immer，但 manifest 仅将两者列为 devDependencies。9 月 18 日安装未添加本轮补丁的 `0.1.6-alpha.2` 仍报 `ERR_MODULE_NOT_FOUND: zustand`。9 月 22 日独立导入 0.1.7-alpha.1 原始 tarball 同样报 `ERR_MODULE_NOT_FOUND: zustand`。9 月 23 日独立导入 rc.3 与 alpha.2 原始 tarball 同样报错；9 月 24 日独立导入 rc.1 原始 tarball 仍报同一缺失；9 月 25 日独立导入 rc.2 原始 tarball 也报同一错误；9 月 29 日独立安装并导入 `0.2.0-rc.1` 原始发布包仍报 `ERR_MODULE_NOT_FOUND: zustand`；9 月 30 日对 `0.2.0-rc.2` 原始发布包同样复现；10 月 4 日最小 npm 安装并导入 `0.2.1-alpha.1` 原始发布包仍报同一错误。10 月 10 日对 `0.2.1-alpha.2` 原始发布包最小 npm 安装成功，独立导入仍报 `ERR_MODULE_NOT_FOUND: zustand`；其 manifest 仅在 devDependencies 声明 `immer: ^10.1.1` 和 `zustand: ~4.5.7`。此前 `0.1.5-alpha.1` 对照导入成功，alpha.2 和两个 rc 的复现记录保留在 M16/M17。

2026-10-15 对 `0.2.1-alpha.3` 原始发布包最小 npm 安装成功，独立导入仍报 `ERR_MODULE_NOT_FOUND: zustand`；其 manifest 继续仅在 devDependencies 声明 `immer: ^10.1.1` 和 `zustand: ~4.5.7`。

2026-10-16 对 `0.2.1-alpha.4` 原始发布包最小 npm 安装成功，独立导入仍报 `ERR_MODULE_NOT_FOUND: zustand`；声明范围与 alpha.3 相同，新增此精确版本补丁。

2026-10-17 对 `0.2.1-alpha.5` 原始发布包最小 npm 安装成功，独立导入仍报 `ERR_MODULE_NOT_FOUND: zustand`；继续仅在 devDependencies 声明 `immer: ^10.1.1` / `zustand: ~4.5.7`，新增此精确版本补丁。

2026-10-18 对 `0.2.1-rc.1` 与 `0.2.1-rc.2` 分别最小 npm 安装成功，独立导入原始 store 发布包均报 `ERR_MODULE_NOT_FOUND: zustand`；仅在 devDependencies 声明 `immer: ^10.1.1` / `zustand: ~4.5.7`，分别新增精确版本补丁，十七版旧补丁保持不变。

2026-10-24 对 `0.2.1-rc.3` 最小 npm 安装成功，独立导入原始 store 发布包仍报 `ERR_MODULE_NOT_FOUND: zustand`；仅在 devDependencies 声明 `immer: ^10.1.1` / `zustand: ~4.5.7`，新增 rc.3 精确补丁，十九版旧补丁保持不变。

`pnpm-workspace.yaml` 的 `packageExtensions` 只匹配二十个已复现的受影响版本：此前十三版保留原依赖范围 `immer: ^10.1.1` 与 `zustand: ~4.4.7`，alpha.2、alpha.3、alpha.4、alpha.5、rc.1、rc.2 与 rc.3 分别使用精确选择器补齐 `immer: ^10.1.1` 与 `zustand: ~4.5.7`，锁文件记录修复。0.2.1-alpha.2 配套发布包经 frozen install、类型检查、106 项测试、构建与实际 pack 通过；上游进展与更广的静态客户端打包问题见 [Discussion #6082](https://github.com/deepseek-ai/deepseek-harness/discussions/6082)。静态库产物保留 bare imports，而上游依赖门禁要求浏览器输入仅列为开发依赖，完整修复需要维护者统一产物与依赖规则。本项目只修复实际消费的 store；该配置作用于本仓库 pnpm 安装，不代表其他消费方或上游发布包已修复。

## 安装

```sh
npx @deepseek-ai/dsh@0.2.1-rc.2 plugin --profile web add github:yuezengwu/dsh-explain#main
npx @deepseek-ai/dsh@0.2.1-rc.2 --profile web
```

先前已验证的候选版使用固定 rc.3 命令；当前 npm `next=0.2.1-rc.4` 待验证：

```sh
npx @deepseek-ai/dsh@0.2.1-rc.3 plugin --profile web add github:yuezengwu/dsh-explain#main
npx @deepseek-ai/dsh@0.2.1-rc.3 --profile web
```

上述命令安装尚未发布新标签的 `main`。需要不可变安装时，把 `#main` 换为对应已通过 CI 的合入提交 SHA。现有 [v0.3.1](https://github.com/yuezengwu/dsh-explain/releases/tag/v0.3.1) 仍搭配 DSH 0.1.6-alpha.2 或更早的表内宿主，不包含后续 0.1.7/0.2.0/0.2.1 适配；v0.3.0 的支持范围截至 0.1.6-alpha.1。2026-10-28 核对 npm `latest=0.2.1-rc.2`、`next=0.2.1-rc.4`、`alpha=0.2.2-alpha.2`；两组命令分别固定默认版本与先前已验证的 rc.3，不跟随当前未验收的 `next` / `alpha`。宿主 Session 格式迁移与 Explain SQLite 独立；各版本独立验收不表示新版 Session 文件可以降级读取。

## 兼容实现

- V3 来源回归在真实 Session 中追加系统提示词，证明其不进入学习 capsule，来源结束坐标和主会话消息不变。合成旧 Web 日志保持先 `step/start`、再 `user/message` 的时间顺序，由官方 V0→V3 迁移器转换。
- Explain 只从 Session 对象读取身份、header 与 seq；历史数据通过异步 page API 获取，来源正文消费 settled 消息，不依赖 durable chunk 事件。
- 0.1.3-alpha.1/alpha.2 使用 Session format 2，0.1.5-alpha.1/alpha.2/rc.1/rc.2 与 0.1.6-alpha.1/alpha.2 使用 format 3。测试中的合成 settled assistant 事件补充 `stream: []`；旧版宿主兼容此额外字段。
- 真实 Web 夹具通过对应宿主自己的 `llm-replay` 解析和迁移旧日志。format 2/3 写入使用 `SessionHandle.append/flush/close`，`0.1.2-rc.1` 使用原持久化接口。这层分支仅在测试夹具中。
- 源码链接覆盖所有直接开发依赖和 peer 包，并共用宿主 React/Cordis 实例，避免源码包和 npm 包混装导致对象身份不一致。链接脚本拒绝未经验证的源码版本。
- Explain SQLite 保持 schema 4、backup v3，不改写旧记录。薄弱概念通过当前有效状态投影恢复 learning，同时保留原有复习排期。

## 本地复现

先按 DSH 官方开发说明安装并构建上表任一精确源码版本，再在 Explain checkout 运行：

```sh
pnpm install --frozen-lockfile
pnpm build
pnpm pack --out /tmp/dsh-explain-candidate.tgz
export DSH_EXPLAIN_INSTALL_SPEC=/tmp/dsh-explain-candidate.tgz
export DSH_SOURCE_DIR=/absolute/path/to/built/deepseek-harness
pnpm dsh:link
pnpm dsh:link:check
pnpm typecheck
pnpm test
pnpm build
pnpm exec vitest run --config vitest.web.config.ts
pnpm exec vitest run --config vitest.m6.config.ts
```

本地验证新版插件时，在该 DSH 源码目录调用其 CLI，并使用独立的测试 home：

```sh
export DSH_HOME=/absolute/path/to/isolated-test-home
node --import tsx/esm apps/cli/src/bin.ts plugin --profile web add /absolute/path/to/dsh-explain
node --import tsx/esm apps/cli/src/bin.ts --profile web --no-open
```

CI 检查锁定的 0.2.1-rc.3 配套发布包，并对二十四个精确源码提交运行组装矩阵：每个宿主 108 项单元/集成、7 个共有 Web 场景及 3 个 M6 场景；四个 0.1.7 预发布版、两个 0.2.0 候选版及八个 0.2.1 预发布版另有旧设置迁移及两次重启验收。发布包经过 frozen install、构建和实际 pack，二十四宿主 Web / M6 安装该同一 tarball。本地验证新的 rc.3 宿主，其余由当前 PR 的完整 CI 复核，提交结果见 [Actions](https://github.com/yuezengwu/dsh-explain/actions/workflows/ci.yml)。M6 的实时启停分支仅在 `0.1.6-alpha.2` 执行，其余宿主运行卸载、移除及重装场景；历史里程碑中泛称的「含实时启停」以此当前夹具范围为准。所有 Web/M6 使用临时 Session、SQLite、profile 和无密钥夹具。另于 2026-09-15 在 0.1.6-alpha.1 上完成的[真实模型验收](./REAL_MODEL_ACCEPTANCE.md)与当前宿主验证范围分开。现有 Demo 仍标注 `0.1.2-rc.1`。

## 修复后的学习行为

1. 同一 context/activity generation 的空闲压缩失败后停止布置零延时定时器；新活动或新可压缩内容再触发。
2. 活跃讲解独立读取，不会因历史超过 30 条而隐藏；历史游标保持原语义。
3. 全局模型请求只含有界 Topic 提示。重讲带目标最新正文和至多三个旧标题，所有历史 revision 仍保存在本地。
4. partial/forgotten 立即反映为 learning，统一用于 UI、统计、模型提示和自主选题。重新讲解取消旧题，避免在学习中重复测验。
5. 来源摘要、模型出入文本和公开导出过滤常见凭证与路径格式；历史数据不被破坏性改写。该过滤不保证识别任意私人文本，界面明确说明辅助 provider 会收到有界来源文本。
6. 题型按每个概念自己的复习历史推进，成功进入下一题型，失败重复当前题型。
