import { afterEach, describe, expect, it } from 'vitest'
import { Context, type Fiber } from '@deepseek-ai/cordis'
import LlmService, {
  ReasoningEffortId,
  type GenerateOptions,
  LlmAdapter,
  type LlmResolvedModelInfo,
  type StreamChunk,
} from '@deepseek-ai/dsh-llm'
import TokenMeterService from '@deepseek-ai/dsh-token-meter'
import { RequestId } from '../src/brands.ts'
import type { ExplainRuntimeSettings } from '../src/config.ts'
import type { SourceCapsule } from '../src/domain.ts'
import { ExplainScheduler } from '../src/scheduler.ts'
import { CandidateQueue } from '../src/queue.ts'
import { ExplainStore } from '../src/store.ts'
import { SessionId } from '@deepseek-ai/dsh-session'
import SessionProjectionRegistry from '@deepseek-ai/dsh-session-projection'

const stores: ExplainStore[] = []
const schedulers: ExplainScheduler[] = []
const serviceFibers: Fiber[] = []

afterEach(async () => {
  for (const scheduler of schedulers.splice(0)) await scheduler.dispose()
  for (const store of stores.splice(0)) store.close()
  for (const fiber of serviceFibers.splice(0).reverse()) await fiber.dispose()
})

class LearningAdapter extends LlmAdapter {
  active = 0
  maxActive = 0
  contextWindow = 1_000_000
  delayMs = 5
  failCompaction = false
  failAutonomous = false
  failManual = false
  readonly calls: string[] = []
  readonly efforts: (string | undefined)[] = []

  override resolveModel(provider: string, model: string): Promise<LlmResolvedModelInfo> {
    return Promise.resolve({
      provider,
      id: model,
      name: model,
      context: { contextWindow: this.contextWindow },
      reasoning: {
        efforts: [
          { id: ReasoningEffortId('off'), name: 'Off' },
          { id: ReasoningEffortId('high'), name: 'High' },
        ],
        defaultEffort: ReasoningEffortId('high'),
      },
    })
  }

  override async * stream(options: GenerateOptions): AsyncIterable<StreamChunk> {
    this.active += 1
    this.maxActive = Math.max(this.maxActive, this.active)
    try {
      await abortableDelay(this.delayMs, options.signal)
      const compaction = options.purpose === 'compaction'
      const rephrase = options.system?.includes('Rephrase one still-active explanation') === true
      const manual = options.system?.includes('Fulfill one explicit learning request') === true
      const review = options.system?.includes('private review evaluator') === true
      const source = requestObject(options)
      const sourceId = String((source.sourceCapsule as { sourceSessionId?: unknown } | undefined)?.sourceSessionId ?? 'rephrase')
      this.calls.push(compaction ? 'compaction' : rephrase ? 'rephrase' : manual ? `manual:${sourceId}`
        : review ? 'review' : `auto:${sourceId}`)
      this.efforts.push(options.reasoningEffort)
      if (compaction && this.failCompaction) throw new Error('test compaction provider failure')
      if (manual && this.failManual) throw new Error('test manual provider failure')
      if (!compaction && !rephrase && !manual && !review && this.failAutonomous) throw new Error('test autonomous provider failure')
      const response = compaction
        ? {
            dialogueProfile: [],
            knowledgeOverview: 'Compressed learning context.',
            learningTrend: 'Closed material is retained as a summary.',
          }
        : rephrase
        ? { title: 'Narrowing with labels', what: 'Each member has a label.', why: 'The label identifies the member.', pitfall: 'Keep labels literal.' }
        : manual
        ? {
            topicKey: `manual/${sourceId}`,
            title: `Requested topic ${sourceId}`,
            what: 'A requested concept.',
            why: 'It answers the explicit learning request.',
            pitfall: 'Keep the source context bounded.',
          }
        : review
        ? { result: 'mastered', feedback: 'The answer captures the core idea.' }
        : {
            kind: 'explain',
            topicKey: `topic/${sourceId}`,
            title: `Topic ${sourceId}`,
            what: 'A focused concept.',
            why: 'It helps future work.',
            pitfall: 'Do not overgeneralize it.',
            contextObservations: [],
          }
      const text = JSON.stringify(response)
      yield { type: 'block-start', index: 0, blockType: 'text' }
      yield { type: 'text-delta', index: 0, text }
      yield { type: 'block-end', index: 0, block: { type: 'text', text } }
      yield { type: 'finish', reason: { kind: 'stop' } }
    } finally {
      this.active -= 1
    }
  }
}

const SETTINGS: ExplainRuntimeSettings = {
  enabled: true,
  provider: 'learning',
  model: 'test-model',
  maxPendingCandidates: 8,
  maxSourceChars: 24_000,
  maxAutoRequestsPerDay: 50,
  maxTopicHints: 100,
  idleCompactMs: 1_800_000,
  contextThresholdRatio: 0.5,
  timeoutMs: 5_000,
  maxOutputTokens: 1_200,
  maxCompactionOutputTokens: 1_600,
  maxAttempts: 2,
}

function source(sourceId: string): SourceCapsule {
  return {
    sourceSessionId: SessionId(sourceId),
    turn: 1,
    endSeq: 5,
    observedAt: Date.now(),
    userText: 'Explain this code.',
    assistantText: 'The code uses one useful idea.',
    tools: [],
    truncated: false,
  }
}

function retainedSources(scheduler: ExplainScheduler): number {
  const queue: unknown = Reflect.get(scheduler, 'queue')
  if (!(queue instanceof CandidateQueue)) throw new Error('scheduler candidate queue is unavailable')
  return queue.retainedSourceCount
}

async function setup(
  settings: ExplainRuntimeSettings = SETTINGS,
  configureAdapter?: (adapter: LearningAdapter) => void,
  registerAdapter = true,
): Promise<{
  readonly ctx: Context
  readonly store: ExplainStore
  readonly adapter: LearningAdapter
  readonly scheduler: ExplainScheduler
}> {
  const ctx = new Context()
  const llm = ctx.plugin(LlmService)
  serviceFibers.push(llm)
  await llm
  const projections = ctx.plugin(SessionProjectionRegistry)
  serviceFibers.push(projections)
  await projections
  const meter = ctx.plugin(TokenMeterService)
  serviceFibers.push(meter)
  await meter
  const adapter = new LearningAdapter()
  configureAdapter?.(adapter)
  if (registerAdapter) ctx.llm.registerAdapter(['learning'], adapter)
  const store = new ExplainStore(':memory:')
  stores.push(store)
  const scheduler = new ExplainScheduler(ctx, store, settings)
  schedulers.push(scheduler)
  await scheduler.start()
  return { ctx, store, adapter, scheduler }
}

describe('real LLM-service scheduler integration', () => {
  it('releases completed source identities throughout a running scheduler', async () => {
    const { store, adapter, scheduler } = await setup(SETTINGS, target => { target.delayMs = 0 })
    for (let i = 0; i < 20; i++) {
      scheduler.enqueue(source(`completed-${i}`))
      await until(() => store.activeExplanationCount() === i + 1 && retainedSources(scheduler) === 0)
    }
    expect(adapter.maxActive).toBe(1)
    expect(adapter.calls).toHaveLength(20)
    expect(store.autoBudget(50).used).toBe(20)
    expect(scheduler.status().pendingCandidates).toBe(0)
  })

  it('does no auxiliary or learning work while disabled', async () => {
    const { store, adapter, scheduler } = await setup({ ...SETTINGS, enabled: false })
    const before = store.cursor()
    scheduler.enqueue(source('disabled-source'))
    await new Promise(resolve => { setTimeout(resolve, 20) })
    expect(adapter.calls).toEqual([])
    expect(scheduler.status()).toMatchObject({ state: 'disabled', pendingCandidates: 0 })
    expect(store.cursor()).toEqual(before)
    expect(store.autoBudget(50).used).toBe(0)
  })

  it('recovers a configured route when its adapter registers after startup', async () => {
    const { ctx, store, adapter, scheduler } = await setup(SETTINGS, undefined, false)
    expect(scheduler.status()).toMatchObject({ state: 'failed', lastError: { code: 'RUNTIME_FAILED' } })

    ctx.llm.registerAdapter(['learning'], adapter)
    scheduler.adaptersUpdated()
    await until(() => scheduler.status().state === 'ready')
    scheduler.enqueue(source('late-adapter'))
    await until(() => store.activeExplanationCount() === 1)
    expect(adapter.calls).toEqual(['auto:late-adapter'])
  })

  it('serializes autonomous calls globally and persists both independent source explanations', async () => {
    const { store, adapter, scheduler } = await setup()
    scheduler.enqueue(source('a'))
    scheduler.enqueue(source('b'))
    await until(() => store.activeExplanationCount() === 2)
    expect(adapter.maxActive).toBe(1)
    expect(adapter.calls).toEqual(['auto:a', 'auto:b'])
    expect(adapter.efforts).toEqual(['off', 'off'])
    expect(store.autoBudget(50).used).toBe(2)
    expect(store.threadPage({ limit: 10 }).entries.map(entry => entry.sourceSessionId))
      .toEqual([SessionId('b'), SessionId('a')])
    await scheduler.dispose()
    schedulers.splice(schedulers.indexOf(scheduler), 1)
    stores.splice(stores.indexOf(store), 1)
    store.close()
  })

  it('restores a persisted rephrase target, appends revision two, and keeps it outside the auto budget', async () => {
    const { store, adapter, scheduler } = await setup()
    scheduler.enqueue(source('a'))
    await until(() => store.activeExplanationCount() === 1)
    const first = store.threadPage({ limit: 10 }).entries[0]
    if (first?.explanationId === undefined || first.revision === undefined) throw new Error('missing explanation')
    const result = store.feedback({
      requestId: RequestId('retry-explanation'),
      sourceSessionId: SessionId('a'),
      explanationId: first.explanationId,
      revision: first.revision,
      action: 'not-understood',
    })
    expect(result.ok).toBe(true)
    scheduler.learningStateChanged({ explanationId: first.explanationId, revision: first.revision })
    await until(() => store.threadPage({ limit: 10 }).entries.some(entry => entry.revision === 2))
    expect(adapter.calls).toEqual(['auto:a', 'rephrase'])
    expect(store.autoBudget(50).used).toBe(1)
    expect(store.threadPage({ limit: 10 }).entries[0]).toMatchObject({
      explanationId: first.explanationId,
      revision: 2,
      topicTitle: 'Narrowing with labels',
    })
    await scheduler.dispose()
    schedulers.splice(schedulers.indexOf(scheduler), 1)
    stores.splice(stores.indexOf(store), 1)
    store.close()
  })

  it('runs a manual request ahead of background work without consuming autonomous budget', async () => {
    const { store, adapter, scheduler } = await setup()
    const result = await scheduler.requestManual({
      origin: 'manual',
      request: 'Explain discriminated unions',
      capsule: source('manual-source'),
    }, new AbortController().signal)
    expect(result).toMatchObject({
      ok: true,
      entry: {
        origin: 'manual',
        sourceSessionId: SessionId('manual-source'),
        topicTitle: 'Requested topic manual-source',
      },
    })
    expect(adapter.calls).toEqual(['manual:manual-source'])
    expect(adapter.efforts).toEqual(['off'])
    expect(store.autoBudget(50).used).toBe(0)

    await expect(scheduler.requestManual({
      origin: 'manual',
      request: 'Explain it again',
      capsule: source('manual-source'),
    }, new AbortController().signal)).resolves.toEqual({
      ok: false,
      error: {
        code: 'EXPLAIN_SOURCE_BUSY',
        message: 'This Session already has an active or pending explanation.',
      },
    })
    expect(adapter.calls).toEqual(['manual:manual-source'])
  })

  it('evaluates one due review through the same global single flight without consuming auto budget', async () => {
    const { store, adapter, scheduler } = await setup()
    store.addFixtureExplanation({
      topicKey: 'review/scheduler',
      title: 'Scheduler review',
      sourceSessionId: SessionId('review-source'),
      sourceTurn: 4,
      state: 'closed',
      topicState: 'mastered',
    })
    const started = store.startReview({ requestId: RequestId('review-start') }, Date.now() + 10)
    const current = started.dashboard.current
    if (current === undefined) throw new Error('missing review question')
    const result = await scheduler.requestReviewAnswer({
      requestId: RequestId('review-answer'),
      reviewId: current.reviewId,
      answer: 'The scheduler ensures model work is serialized.',
    }, new AbortController().signal)
    expect(result).toMatchObject({
      ok: true,
      attempt: { result: 'mastered', feedback: 'The answer captures the core idea.' },
    })
    expect(adapter.calls).toEqual(['review'])
    expect(adapter.maxActive).toBe(1)
    expect(store.autoBudget(50).used).toBe(0)
  })

  it('settles a cancelled in-flight manual request without persisting a result', async () => {
    const { store, adapter, scheduler } = await setup(SETTINGS, target => { target.delayMs = 100 })
    const controller = new AbortController()
    const pending = scheduler.requestManual({
      origin: 'manual',
      request: 'Explain cancellation',
      capsule: source('cancelled-manual'),
    }, controller.signal)
    await until(() => adapter.active === 1)
    controller.abort(new Error('test cancellation'))
    await expect(pending).resolves.toEqual({
      ok: false,
      error: { code: 'EXPLAIN_REQUEST_CANCELLED', message: 'The explanation request was cancelled.' },
    })
    expect(store.activeExplanationCount()).toBe(0)
    expect(store.autoBudget(50).used).toBe(0)
  })

  it('retries dirty idle compaction after a manual request preempts it and then fails', async () => {
    const { store, adapter, scheduler } = await setup(
      { ...SETTINGS, idleCompactMs: 1 },
      target => {
        target.delayMs = 100
        target.failManual = true
      },
    )
    store.addFixtureExplanation({
      topicKey: 'closed/preempted-idle',
      title: 'Closed before preemption',
      sourceSessionId: SessionId('closed-before-manual'),
      sourceTurn: 1,
      state: 'closed',
      topicState: 'mastered',
    })
    scheduler.learningStateChanged()
    await until(() => adapter.active === 1)
    await expect(scheduler.requestManual({
      origin: 'manual',
      request: 'Explain the failed request',
      capsule: source('manual-failure'),
    }, new AbortController().signal)).resolves.toEqual({
      ok: false,
      error: { code: 'EXPLAIN_MANUAL_FAILED', message: 'The requested explanation could not be generated.' },
    })
    await until(() => store.context().inferred)
    expect(adapter.calls).toEqual(['manual:manual-failure', 'compaction'])
  })

  it('compacts pressure-causing context before a manual request and keeps its budget exempt', async () => {
    const { store, adapter, scheduler } = await setup(
      { ...SETTINGS, maxOutputTokens: 100, maxCompactionOutputTokens: 100 },
      target => { target.contextWindow = 3_500 },
    )
    store.addFixtureExplanation({
      topicKey: 'large/manual-closed',
      title: 'Large closed context for manual request',
      sourceSessionId: SessionId('old-manual-context'),
      sourceTurn: 1,
      state: 'closed',
      topicState: 'mastered',
      revisions: [{
        title: 'Large closed context for manual request',
        what: 'w'.repeat(600),
        why: 'y'.repeat(600),
        pitfall: 'p'.repeat(600),
      }],
    })
    const result = await scheduler.requestManual({
      origin: 'manual',
      request: 'Explain this request under context pressure',
      capsule: {
        ...source('manual-pressure'),
        userText: 'u'.repeat(2_000),
        assistantText: 'a'.repeat(2_000),
      },
    }, new AbortController().signal)
    expect(result.ok).toBe(true)
    expect(adapter.calls).toEqual(['compaction', 'manual:manual-pressure'])
    expect(store.autoBudget(50).used).toBe(0)
  })

  it('parks a candidate behind its source active gate without an empty-drain spin', async () => {
    const { store, adapter, scheduler } = await setup()
    scheduler.enqueue(source('a'))
    await until(() => store.activeExplanationCount() === 1)
    scheduler.enqueue({ ...source('a'), turn: 2, endSeq: 10, observedAt: Date.now() + 1 })
    await new Promise(resolve => { setTimeout(resolve, 30) })
    expect(adapter.calls).toEqual(['auto:a'])
    expect(scheduler.status().pendingCandidates).toBe(1)
    await scheduler.dispose()
    schedulers.splice(schedulers.indexOf(scheduler), 1)
    stores.splice(stores.indexOf(store), 1)
    store.close()
  })

  it('runs one idle compaction for dirty closed material and then becomes clean', async () => {
    const { store, adapter, scheduler } = await setup({ ...SETTINGS, idleCompactMs: 1 })
    store.addFixtureExplanation({
      topicKey: 'closed/topic',
      title: 'Closed concept',
      sourceSessionId: SessionId('closed-source'),
      sourceTurn: 1,
      state: 'closed',
      topicState: 'mastered',
    })
    scheduler.learningStateChanged()
    await until(() => store.context().inferred)
    await new Promise(resolve => { setTimeout(resolve, 20) })
    expect(adapter.calls).toEqual(['compaction'])
    expect(store.compactionBatch()).toBeUndefined()
    expect(store.autoBudget(50).used).toBe(0)
  })

  it('compacts pressure-causing closed context before sending the autonomous request', async () => {
    const { store, adapter, scheduler } = await setup(
      { ...SETTINGS, maxOutputTokens: 100, maxCompactionOutputTokens: 100 },
      target => { target.contextWindow = 3_500 },
    )
    store.addFixtureExplanation({
      topicKey: 'large/closed-topic',
      title: 'Large closed concept',
      sourceSessionId: SessionId('old-source'),
      sourceTurn: 1,
      state: 'closed',
      topicState: 'mastered',
      revisions: [{
        title: 'Large closed concept',
        what: 'w'.repeat(600),
        why: 'y'.repeat(600),
        pitfall: 'p'.repeat(600),
      }],
    })
    scheduler.enqueue({
      ...source('new-source'),
      userText: 'u'.repeat(2_000),
      assistantText: 'a'.repeat(2_000),
    })
    await until(() => store.activeExplanationCount() === 1 || scheduler.status().lastError !== undefined)
    expect(scheduler.status().lastError).toBeUndefined()
    expect(adapter.calls).toEqual(['compaction', 'auto:new-source'])
    expect(store.context().inferred).toBe(true)
    expect(store.autoBudget(50).used).toBe(1)
  })

  it('fences an autonomous result when learning mode is disabled in flight', async () => {
    const { store, adapter, scheduler } = await setup(SETTINGS, target => { target.delayMs = 100 })
    scheduler.enqueue(source('late-result'))
    await until(() => adapter.active === 1)
    await scheduler.configure({ ...SETTINGS, enabled: false })
    await new Promise(resolve => { setTimeout(resolve, 20) })
    expect(store.activeExplanationCount()).toBe(0)
    expect(scheduler.status()).toMatchObject({ state: 'disabled', pendingCandidates: 0 })
  })

  it('fences in-flight work before clearing and resumes without resetting autonomous usage', async () => {
    const { store, adapter, scheduler } = await setup(SETTINGS, target => { target.delayMs = 100 })
    store.addFixtureExplanation({
      topicKey: 'existing/clear-target',
      title: 'Existing learning data',
      sourceSessionId: SessionId('existing-clear-source'),
      sourceTurn: 1,
    })
    scheduler.enqueue(source('cleared-in-flight'))
    await until(() => adapter.active === 1)
    const result = await scheduler.resetLearningData(store.storeRevision())
    expect(result).toMatchObject({
      ok: true,
      cleared: { entries: 1, topics: 1, explanations: 1 },
      preservedAutoRequests: 1,
    })
    expect(store.threadPage({ limit: 10 }).entries).toEqual([])
    expect(store.autoBudget(50).used).toBe(1)
    expect(scheduler.status()).toMatchObject({ state: 'ready', pendingCandidates: 0 })

    scheduler.enqueue(source('after-clear'))
    await until(() => store.activeExplanationCount() === 1)
    expect(adapter.calls).toEqual(['auto:after-clear'])
    expect(store.autoBudget(50).used).toBe(2)
    expect(retainedSources(scheduler)).toBe(0)
  })

  it('surfaces a terminal autonomous failure after exhausting its retry attempts', async () => {
    const { store, adapter, scheduler } = await setup(SETTINGS, target => { target.failAutonomous = true })
    scheduler.enqueue(source('provider-failure'))
    await until(() => scheduler.status().lastError?.code === 'EXPLAIN_AUTO_FAILED')
    expect(scheduler.status().lastError).toEqual({
      code: 'EXPLAIN_AUTO_FAILED',
      message: 'dsh-explain: auxiliary model failed (UNKNOWN): test autonomous provider failure',
    })
    expect(store.autoBudget(50).used).toBe(2)
    expect(store.activeExplanationCount()).toBe(0)
    expect(adapter.calls).toEqual(['auto:provider-failure', 'auto:provider-failure'])
    expect(retainedSources(scheduler)).toBe(0)
  })

  it('surfaces pressure-compaction failure and never sends the autonomous request', async () => {
    const { store, adapter, scheduler } = await setup(
      { ...SETTINGS, maxOutputTokens: 100, maxCompactionOutputTokens: 100 },
      target => {
        target.contextWindow = 8_000
        target.failCompaction = true
      },
    )
    store.addFixtureExplanation({
      topicKey: 'existing/topic',
      title: 'Existing closed concept',
      sourceSessionId: SessionId('old-source'),
      sourceTurn: 1,
      state: 'closed',
      topicState: 'mastered',
    })
    scheduler.enqueue({
      ...source('new-source'),
      userText: 'x'.repeat(24_000),
      assistantText: 'A compact answer.',
    })
    await until(() => scheduler.status().lastError?.code === 'EXPLAIN_COMPACTION_FAILED')
    expect(adapter.calls).toEqual(['compaction'])
    expect(store.autoBudget(50).used).toBe(0)
    expect(store.activeExplanationCount()).toBe(0)
    await scheduler.dispose()
    schedulers.splice(schedulers.indexOf(scheduler), 1)
    stores.splice(stores.indexOf(store), 1)
    store.close()
  })
})

function requestObject(options: GenerateOptions): Record<string, unknown> {
  const first = options.messages[0]?.content[0]
  if (first?.type !== 'text') throw new Error('test adapter expected one JSON text request')
  return JSON.parse(first.text) as Record<string, unknown>
}

async function abortableDelay(milliseconds: number, signal?: AbortSignal): Promise<void> {
  if (signal?.aborted === true) throw signal.reason
  await new Promise<void>((resolve, reject) => {
    const timer = setTimeout(done, milliseconds)
    function done(): void {
      signal?.removeEventListener('abort', aborted)
      resolve()
    }
    function aborted(): void {
      clearTimeout(timer)
      reject(signal?.reason)
    }
    signal?.addEventListener('abort', aborted, { once: true })
  })
}

async function until(predicate: () => boolean): Promise<void> {
  const deadline = Date.now() + 2_000
  while (!predicate()) {
    if (Date.now() >= deadline) throw new Error('timed out waiting for scheduler state')
    await new Promise(resolve => { setTimeout(resolve, 5) })
  }
}
