import { appendSystemContext, observedSession, settledAssistant } from './session-fixture.ts'
import { describe, expect, it } from 'vitest'
import {
  ToolCallId,
  createAssistantMessage,
  createToolResultMessage,
  createUserMessage,
} from '@deepseek-ai/dsh-llm'
import { Session, SessionId } from '@deepseek-ai/dsh-session'
import { ObservationId } from '../src/brands.ts'
import type { AuxiliaryContext, SourceCapsule } from '../src/domain.ts'
import {
  renderCompactionRequest,
  renderExplainRequest,
  renderManualExplainRequest,
  renderRephraseRequest,
} from '../src/explainer.ts'
import {
  captureManualExplainTarget,
  captureSelectionExplainTarget,
  captureSourceCapsule,
  captureAnswerExplainTarget,
} from '../src/observer.ts'
import { CandidateQueue } from '../src/queue.ts'

const EMPTY_CONTEXT: AuxiliaryContext = {
  topicHints: [],
  uncoveredObservations: [],
  uncoveredClosedExplanations: [],
  learnerProfileControls: [],
}

function capsule(source: string, turn: number, observedAt: number): SourceCapsule {
  return {
    sourceSessionId: SessionId(source),
    turn,
    endSeq: turn * 10,
    observedAt,
    userText: `question ${turn}`,
    assistantText: `answer ${turn}`,
    tools: [],
    truncated: false,
  }
}

describe('completed-turn source observation', () => {
  it('captures human text, assistant text, and bounded tool results without synthetic context', async () => {
    const session = Session.create(SessionId('source-a'))
    session.append('turn/start', { turn: 1 })
    session.append('step/start', { turn: 1, step: 1 })
    appendSystemContext(session, 'private system instructions')
    session.append('user/message', createUserMessage({
      source: { kind: 'user' },
      content: [{ type: 'text', text: 'How does narrowing work?' }],
    }), { surfaceOp: 'append' })
    session.append('user/message', createUserMessage({
      source: { kind: 'dsh-explain' },
      content: [{ type: 'text', text: 'private synthetic context' }],
    }), { surfaceOp: 'append' })
    const callId = ToolCallId('call-1')
    session.append('tool/call', { turn: 1, step: 1, callId, name: 'read', arguments: '{"path":"secret"}' })
    session.append('tool/result', {
      turn: 1,
      step: 1,
      message: createToolResultMessage({
        callId,
        content: [{ type: 'text', text: 'result preview' }],
        isError: false,
      }),
    }, { surfaceOp: 'append' })
    session.append('assistant/message', settledAssistant({
      turn: 1,
      step: 1,
      message: createAssistantMessage({
        source: { provider: 'test', model: 'test' },
        content: [
          { type: 'reasoning', text: 'hidden chain' },
          { type: 'text', text: 'A union narrows after a discriminant check.' },
        ],
      }),
    }), { surfaceOp: 'append' })
    session.append('step/end', { turn: 1, step: 1 })
    const end = session.append('turn/end', { turn: 1, reason: { kind: 'completed' } })
    const messagesBeforeObservation = session.deriveMessages()

    const captured = await captureSourceCapsule(observedSession(session), end, 10_000)
    expect(captured).toMatchObject({
      sourceSessionId: SessionId('source-a'),
      turn: 1,
      endSeq: end.seq,
      userText: 'How does narrowing work?',
      assistantText: 'A union narrows after a discriminant check.',
      tools: [{ name: 'read', resultPreview: 'result preview' }],
      truncated: false,
    })
    expect(JSON.stringify(captured)).not.toContain('private system instructions')
    expect(JSON.stringify(captured)).not.toContain('private synthetic context')
    expect(JSON.stringify(captured)).not.toContain('hidden chain')
    expect(JSON.stringify(captured)).not.toContain('secret')
    expect(session.deriveMessages()).toEqual(messagesBeforeObservation)
  })

  it('rejects cancelled and step-free turns', async () => {
    const cancelled = Session.create(SessionId('cancelled'))
    cancelled.append('turn/start', { turn: 1 })
    const cancelledEnd = cancelled.append('turn/end', {
      turn: 1,
      reason: { kind: 'aborted', reason: { kind: 'user' } },
    })
    expect(await captureSourceCapsule(observedSession(cancelled), cancelledEnd, 100)).toBeUndefined()

    const empty = Session.create(SessionId('empty'))
    empty.append('turn/start', { turn: 1 })
    const emptyEnd = empty.append('turn/end', { turn: 1, reason: { kind: 'completed' } })
    expect(await captureSourceCapsule(observedSession(empty), emptyEnd, 100)).toBeUndefined()
  })

  it('pairs a manual request with the latest completed source turn or an empty-session marker', async () => {
    const session = Session.create(SessionId('manual-source'))
    session.append('turn/start', { turn: 1 })
    session.append('step/start', { turn: 1, step: 1 })
    session.append('user/message', createUserMessage({
      source: { kind: 'user' },
      content: [{ type: 'text', text: 'What does this branch do?' }],
    }), { surfaceOp: 'append' })
    session.append('assistant/message', settledAssistant({
      turn: 1,
      step: 1,
      message: createAssistantMessage({
        source: { provider: 'test', model: 'test' },
        content: [{ type: 'text', text: 'It narrows the union.' }],
      }),
    }), { surfaceOp: 'append' })
    session.append('step/end', { turn: 1, step: 1 })
    session.append('turn/end', { turn: 1, reason: { kind: 'completed' } })

    expect(await captureManualExplainTarget(observedSession(session), '  请解释这个分支  ', 10_000)).toMatchObject({
      request: '请解释这个分支',
      capsule: {
        sourceSessionId: SessionId('manual-source'),
        turn: 1,
        userText: '请解释这个分支',
        assistantText: 'It narrows the union.',
      },
    })

    const empty = Session.create(SessionId('manual-empty'))
    expect(await captureManualExplainTarget(observedSession(empty), 'Explain discriminated unions', 10_000)).toMatchObject({
      request: 'Explain discriminated unions',
      capsule: { turn: 0, endSeq: 0, assistantText: '', tools: [] },
    })
  })

  it('locates selected assistant, tool, and context text without guessing an unavailable source', async () => {
    const session = Session.create(SessionId('selection-source'))
    session.append('turn/start', { turn: 1 })
    session.append('step/start', { turn: 1, step: 1 })
    session.append('user/message', createUserMessage({
      source: { kind: 'user' },
      content: [{ type: 'text', text: 'Explain the repeated marker.' }],
    }), { surfaceOp: 'append' })
    session.append('assistant/message', settledAssistant({
      turn: 1,
      step: 1,
      message: createAssistantMessage({
        source: { provider: 'test', model: 'test' },
        content: [{ type: 'text', text: 'The repeated marker first appeared here.' }],
      }),
    }), { surfaceOp: 'append' })
    session.append('step/end', { turn: 1, step: 1 })
    session.append('turn/end', { turn: 1, reason: { kind: 'completed' } })
    session.append('user/message', createUserMessage({
      source: { kind: 'advisor' } as never,
      content: [{ type: 'text', text: '[advisor:nit] Prefer exact checks.' }],
    }), { surfaceOp: 'append' })

    session.append('turn/start', { turn: 2 })
    session.append('step/start', { turn: 2, step: 1 })
    session.append('user/message', createUserMessage({
      source: { kind: 'user' },
      content: [{ type: 'text', text: 'What changed now?' }],
    }), { surfaceOp: 'append' })
    const callId = ToolCallId('selection-call')
    session.append('tool/call', { turn: 2, step: 1, callId, name: 'read', arguments: '{}' })
    session.append('tool/result', {
      turn: 2,
      step: 1,
      message: createToolResultMessage({
        callId,
        content: [{ type: 'text', text: 'Tool result selected text.' }],
        isError: false,
      }),
    }, { surfaceOp: 'append' })
    session.append('assistant/message', settledAssistant({
      turn: 2,
      step: 1,
      message: createAssistantMessage({
        source: { provider: 'test', model: 'test' },
        content: [{ type: 'text', text: 'The repeated marker is newer in this answer.' }],
      }),
    }), { surfaceOp: 'append' })
    session.append('step/end', { turn: 2, step: 1 })
    session.append('turn/end', { turn: 2, reason: { kind: 'completed' } })

    expect(await captureSelectionExplainTarget(observedSession(session), 'repeated   marker', 10_000)).toMatchObject({
      origin: 'selection',
      request: 'repeated marker',
      capsule: { turn: 2, assistantText: 'The repeated marker is newer in this answer.' },
    })
    expect(await captureSelectionExplainTarget(observedSession(session), 'Tool result selected text.', 10_000))
      .toMatchObject({ capsule: { turn: 2, tools: [{ resultPreview: 'Tool result selected text.' }] } })
    expect(await captureSelectionExplainTarget(observedSession(session), '[advisor:nit] Prefer exact checks.', 10_000))
      .toMatchObject({ capsule: { turn: 1 } })
    expect(await captureSelectionExplainTarget(observedSession(session), 'text not retained in this Session', 10_000))
      .toMatchObject({ capsule: { turn: 0, assistantText: '', tools: [] } })
    expect(await captureAnswerExplainTarget(observedSession(session), 2, 'Explain the key concept.', 10_000))
      .toMatchObject({ origin: 'answer', capsule: { turn: 2 } })
    expect(await captureAnswerExplainTarget(observedSession(session), 99, 'Explain the key concept.', 10_000)).toBeUndefined()
  })

  it('allows an explicit source to bind a max-tokens answer without admitting it to autonomous observation', async () => {
    const session = Session.create(SessionId('max-token-source'))
    session.append('turn/start', { turn: 1 })
    session.append('step/start', { turn: 1, step: 1 })
    session.append('assistant/message', settledAssistant({
      turn: 1,
      step: 1,
      message: createAssistantMessage({
        source: { provider: 'test', model: 'test' },
        content: [{ type: 'text', text: 'A partial but visible answer.' }],
      }),
    }), { surfaceOp: 'append' })
    session.append('step/end', { turn: 1, step: 1 })
    const end = session.append('turn/end', { turn: 1, reason: { kind: 'max-tokens' } })

    expect(await captureSourceCapsule(observedSession(session), end, 10_000)).toBeUndefined()
    expect(await captureAnswerExplainTarget(observedSession(session), 1, 'Explain the partial answer.', 10_000))
      .toMatchObject({ origin: 'answer', capsule: { turn: 1, assistantText: 'A partial but visible answer.' } })
  })
})

describe('latest-wins candidate queue', () => {
  it.each(['retry', 'defer'] as const)('keeps a full queue within its cap during %s', (operation) => {
    const queue = new CandidateQueue()
    queue.push(capsule('in-flight', 1, 1), 1)
    const active = queue.take(new Set())!
    queue.push(capsule('newer', 1, 2), 1)
    queue[operation](active)
    queue.finish(active)
    expect(queue.size).toBe(1)
    expect(queue.retainedSourceCount).toBe(1)
    expect(queue.isLatest(active)).toBe(false)
    expect(queue.take(new Set())?.capsule.sourceSessionId).toBe(SessionId('newer'))
  })

  it('bounds retained identities during source churn and releases completed targets', () => {
    const queue = new CandidateQueue()
    queue.push(capsule('in-flight', 1, 0), 8)
    const active = queue.take(new Set())!
    for (let i = 1; i <= 10_000; i++) queue.push(capsule(`source-${i}`, 1, i), 8)
    expect(queue.size).toBe(8)
    expect(queue.retainedSourceCount).toBe(9)
    expect(queue.isLatest(active)).toBe(true)
    queue.finish(active)
    expect(queue.retainedSourceCount).toBe(8)
    expect(queue.isLatest(active)).toBe(false)
    while (queue.size > 0) queue.finish(queue.take(new Set())!)
    expect(queue.retainedSourceCount).toBe(0)
    for (let i = 0; i < 1000; i++) {
      queue.push(capsule(`processed-${i}`, 1, i), 8)
      queue.finish(queue.take(new Set())!)
    }
    expect(queue.retainedSourceCount).toBe(0)
  })

  it('invalidates evicted targets so retry and defer cannot resurrect them', () => {
    const queue = new CandidateQueue()
    queue.push(capsule('old', 1, 1), 1)
    const evicted = queue.push(capsule('new', 1, 2), 1)!
    expect(queue.isLatest(evicted)).toBe(false)
    queue.retry(evicted)
    queue.defer(evicted)
    expect(queue.size).toBe(1)
    const latest = queue.take(new Set())!
    expect(latest.capsule.sourceSessionId).toBe(SessionId('new'))
    queue.defer(latest)
    const trimmed = queue.trim(0)[0]!
    queue.retry(trimmed)
    queue.defer(trimmed)
    expect(queue.size).toBe(0)
    expect(queue.retainedSourceCount).toBe(0)
  })

  it('keeps queued retries and deferred targets valid after an attempt finishes', () => {
    const queue = new CandidateQueue()
    queue.push(capsule('retry', 1, 1), 1)
    const first = queue.take(new Set())!
    queue.retry(first)
    queue.finish(first)
    const retried = queue.take(new Set())!
    expect(retried.attempts).toBe(1)
    expect(queue.isLatest(retried)).toBe(true)
    queue.defer(retried)
    queue.finish(retried)
    const deferred = queue.take(new Set())!
    expect(deferred.attempts).toBe(1)
    queue.finish(deferred)
    queue.retry(deferred)
    queue.defer(deferred)
    expect(queue.size).toBe(0)
    expect(queue.retainedSourceCount).toBe(0)
  })

  it('does not forget or revive a newer turn when an old in-flight target finishes', () => {
    const queue = new CandidateQueue()
    queue.push(capsule('same-source', 1, 1), 1)
    const stale = queue.take(new Set())!
    queue.push(capsule('same-source', 2, 2), 1)
    queue.finish(stale)
    queue.retry(stale)
    queue.defer(stale)
    const current = queue.take(new Set())!
    expect(current.capsule.turn).toBe(2)
    expect(queue.isLatest(current)).toBe(true)
    queue.finish(stale)
    expect(queue.isLatest(current)).toBe(true)
    queue.clear()
    queue.finish(current)
    queue.retry(current)
    queue.defer(current)
    expect(queue.retainedSourceCount).toBe(0)
    queue.push(capsule('same-source', 3, 3), 1)
    expect(queue.isLatest(current)).toBe(false)
  })

  it('replaces by source, evicts globally oldest, respects source gates, and retries only the latest target', () => {
    const queue = new CandidateQueue()
    const a1 = capsule('a', 1, 10)
    const b1 = capsule('b', 1, 20)
    const a2 = capsule('a', 2, 30)
    queue.push(a1, 2)
    queue.push(b1, 2)
    queue.push(a2, 2)
    expect(queue.size).toBe(2)
    expect(queue.hasExecutable(new Set([SessionId('a'), SessionId('b')]))).toBe(false)
    expect(queue.hasExecutable(new Set([SessionId('a')]))).toBe(true)

    const c1 = capsule('c', 1, 40)
    expect(queue.push(c1, 2)?.capsule).toEqual(b1)
    const selected = queue.take(new Set([SessionId('a')]))
    expect(selected?.capsule).toEqual(c1)
    if (selected === undefined) throw new Error('candidate was not selected')
    queue.retry(selected)
    expect(queue.take(new Set([SessionId('a')]))?.attempts).toBe(1)

    const oldA = queue.take(new Set())
    if (oldA === undefined) throw new Error('replacement candidate was not selected')
    queue.push(capsule('a', 3, 50), 2)
    queue.retry(oldA)
    expect(queue.take(new Set())?.capsule.turn).toBe(3)

    queue.push(capsule('d', 1, 60), 2)
    queue.push(capsule('e', 1, 70), 2)
    expect(queue.trim(1)).toHaveLength(1)
    const stale = queue.take(new Set())
    if (stale === undefined) throw new Error('candidate was not available before clear')
    queue.clear()
    queue.defer(stale)
    expect(queue.size).toBe(0)
  })
})

describe('strict auxiliary JSON parsing', () => {
  it('accepts bounded autonomous and rephrase results while rejecting extra fields and invalid TopicKey', () => {
    const explain = renderExplainRequest(EMPTY_CONTEXT, capsule('a', 1, 1), 500)
    expect(explain.parse(JSON.stringify({
      kind: 'explain',
      topicKey: 'typescript/narrowing',
      title: 'Narrowing',
      what: 'What',
      why: 'Why',
      pitfall: 'Pitfall',
      contextObservations: [{
        kind: 'dialogue-preference',
        dimension: 'examples',
        value: 'Prefer one concrete example.',
        confidence: 'medium',
      }],
    }))).toMatchObject({ kind: 'explain', topicKey: 'typescript/narrowing' })
    expect(() => explain.parse(JSON.stringify({
      kind: 'skip', reason: 'not-useful', contextObservations: [], extra: true,
    }))).toThrow(/unexpected fields/)
    expect(() => explain.parse(JSON.stringify({
      kind: 'explain', topicKey: 'Bad Topic', title: 'T', what: 'W', why: 'Y', pitfall: 'P',
      contextObservations: [],
    }))).toThrow(/invalid topicKey/)

    const rephrase = renderRephraseRequest(EMPTY_CONTEXT, {
      explanationId: 'explanation' as never,
      topicId: 'topic' as never,
      topicKey: 'typescript/narrowing',
      sourceSessionId: SessionId('a'),
      sourceTurn: 1,
      revision: 1,
      feedbackOrdinal: 2,
      sourceSummary: { userText: 'question', toolNames: [], truncated: false },
      origin: 'autonomous',
      revisions: [{ revision: 1, title: 'T', what: 'W', why: 'Y', pitfall: 'P' }],
    }, 500)
    expect(rephrase.parse('{"title":"T2","what":"W2","why":"Y2","pitfall":"P2"}'))
      .toEqual({ title: 'T2', what: 'W2', why: 'Y2', pitfall: 'P2' })

    const manual = renderManualExplainRequest(EMPTY_CONTEXT, {
      origin: 'manual',
      request: 'Explain narrowing',
      capsule: capsule('manual', 0, 1),
    }, 500)
    expect(manual.parse('{"topicKey":"typescript/narrowing","title":"T","what":"W","why":"Y","pitfall":"P"}'))
      .toEqual({ topicKey: 'typescript/narrowing', title: 'T', what: 'W', why: 'Y', pitfall: 'P' })
    expect(() => manual.parse('{"kind":"skip","reason":"not-useful"}')).toThrow(/unexpected fields/)
    expect(() => manual.parse('{"topicKey":"Bad Topic","title":"T","what":"W","why":"Y","pitfall":"P"}'))
      .toThrow(/invalid topicKey/)
  })

  it('allows checkpoint citations only from the supplied evidence sets', () => {
    const observationId = ObservationId('observation-1')
    const request = renderCompactionRequest({
      contextGeneration: 1,
      activityGeneration: 1,
      observations: [{
        observationId,
        sourceSessionId: SessionId('a'),
        sourceTurn: 1,
        observation: {
          kind: 'dialogue-preference', dimension: 'examples', value: 'Use examples', confidence: 'high',
        },
        createdAt: 1,
      }],
      explanations: [],
      learnerProfileControls: [{
        targetKind: 'dialogue-preference',
        targetKey: 'examples',
        value: 'Use contrasting examples',
        authority: 'correction',
        sourceObservationId: observationId,
        updatedAt: 2,
      }],
      throughOrdinal: 0,
    }, {}, 500)
    expect(JSON.stringify(request.messages)).toContain('dialogueProfile is always an array')
    const requestBlock = request.messages[0]?.content[0]
    if (requestBlock?.type !== 'text') throw new Error('compaction request text is missing')
    expect(JSON.parse(requestBlock.text)).toMatchObject({
      languageSample: 'Use examples',
      learnerProfileControls: [{ targetKey: 'examples', authority: 'correction' }],
    })
    expect(request.parse(JSON.stringify({
      dialogueProfile: [{
        kind: 'examples', preference: 'Use examples', confidence: 'high',
        evidenceObservationIds: [observationId], evidenceEntryOrdinals: [],
      }],
      knowledgeOverview: '', learningTrend: '',
    })).dialogueProfile[0]?.evidenceObservationIds).toEqual([observationId])
    expect(() => request.parse(JSON.stringify({
      dialogueProfile: [{
        kind: 'examples', preference: 'Use examples', confidence: 'high',
        evidenceObservationIds: ['invented'], evidenceEntryOrdinals: [],
      }],
      knowledgeOverview: '', learningTrend: '',
    }))).toThrow(/unavailable evidence/)
  })

  it('rejects a context checkpoint that drops the source writing system', () => {
    const observationId = ObservationId('observation-zh')
    const request = renderCompactionRequest({
      contextGeneration: 1,
      activityGeneration: 1,
      observations: [{
        observationId,
        sourceSessionId: SessionId('a'),
        sourceTurn: 1,
        observation: {
          kind: 'dialogue-preference', dimension: 'examples', value: '请使用具体示例', confidence: 'high',
        },
        createdAt: 1,
      }],
      explanations: [],
      learnerProfileControls: [],
      throughOrdinal: 0,
    }, {}, 500)
    expect(JSON.stringify(request.messages)).toContain('Han characters')
    expect(() => request.parse(JSON.stringify({
      dialogueProfile: [],
      knowledgeOverview: 'Understands discriminated unions.',
      learningTrend: 'Needs more practical examples.',
    }))).toThrow(/preserve Han characters/)
    expect(request.parse(JSON.stringify({
      dialogueProfile: [],
      knowledgeOverview: '已理解可辨识联合。',
      learningTrend: '需要更多实际示例。',
    })).learningTrend).toBe('需要更多实际示例。')
  })
})
