# Contributing

Contributions are welcome! Please follow these steps:

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## Development Setup

```bash
npm install
npm test
```

## Code Style

- Use ES modules
- Follow the existing code structure
- Add tests for new features

## License

By contributing, you agree that your contributions will be licensed under the MIT License.
