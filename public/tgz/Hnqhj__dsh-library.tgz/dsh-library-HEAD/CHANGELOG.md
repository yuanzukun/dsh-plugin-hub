# 更新日志

本文件记录 dsh-library 的每个可交付版本。

## [未发布]

### 阶段 7 修：侧边栏「资料库」入口不显示

- 根因：`sidebar.panellist` 注册只传了一个参数（`icon: Icon` 误写进 config 对象），
  导致这条 sidebar 条目的组件为 `undefined`；侧边栏 `PanelRow` 用
  `renderSlot(..., {only:'library'})` 渲染它时 React 抛错，运行期把该条目
  `abdicated` 并过滤掉，整行消失。`dsh-asset-library` 用 `slots.register(config, Icon)`
  （Icon 作第二参数）因而正常。
- 修法：注册体与 `dsh-asset-library` 对齐——`slots.register({ name:'sidebar.panellist', id:'library', order:22, label:()=>t('panel'), locale:NS }, Icon)`。
- 开发源 `D:\dsh-library\client.js` 与已装入副本
  `C:\Users\Administrator\.dsh\profiles\desktop\node_modules\dsh-library\client.js`
  同步修正（`file:` 装法是拷贝，不是同一 inode）。
- 五套测试（logic/scan/host/office/client）全绿。

### 阶段 1：骨架

- 新建独立插件包 `dsh-library`，与 `dsh-asset-library` 并存、互不依赖。
- 浏览器半：往 `sidebar.panellist` 注册「资料库」入口，往 `main` 槽注册同名页面；
  两个注册共用 id `library`，点击侧边栏即切换。
- 页面按 DSH 原生零件拼装：控件取自官方组件库，配色只读 `--dsw-alias-*` 令牌；
  组件库不可用时整页降级为原生元素，仍然可以打开。
- 宿主半：挂 `/api/library` 前缀路由，先过浏览器信任栅栏；`/status` 自报库根、
  目录是否存在与能力清单。
- 内核与配置：库根解析（显式配置 → `<DSH_HOME>/library`）、配置模式与默认值、
  路径归一化与包含检查、DSH home 解析与原子 JSON 读写。
- 权限口径落进配置：`allowAgentSave` 默认开（可新增入库），`allowAgentModify`
  默认关（不可改动已有资料）。
- 工具脚本：`tools/dev-install.ps1` 与 `tools/sync-all.ps1`，解决 `file:` 装法下
  源码改动不会自动同步进 profile 的问题；`tools/install-desktop.ps1` 一次完成
  "备份 → 写依赖与 bundles → pnpm 同步"，并带 `-Restore` 一键回滚。
- 三套离线测试，全部不依赖 DSH 即可运行（合计 80 项）：
  - `tools/logic-test.mjs` —— 路径归一化与包含检查、home 解析、原子 JSON 读写（21 项）；
  - `tools/client-test.mjs` —— 面板契约与三种状态下的渲染、按钮反馈（31 项，自带迷你渲染器）；
  - `tools/host-test.mjs` —— 真实加载宿主半并走完整的 HTTP 面，含信任栅栏与错误路径（28 项）。

### 阶段 2：库根、扫描、索引、HTTP 面

「磁盘是权威，索引只存人的输入」这条分界在本阶段落地。库里有什么是扫描推出来的，
索引只负责标签/备注/来源；因此索引丢了只损失标注，不会损失内容。

- 新增 `lib/kinds.js`：扩展名 → 类型 / MIME / 能否文本预览 / 能否安全内联。
  与资产库不同，这份表**不封闭**——认不出来的扩展名归到通用附件 `file`，而不是被丢掉。
- 新增 `lib/scan.js`：递归扫描（跳过点开头条目、依赖目录、Office 临时文件与系统垃圾），
  目录本身也进清单供界面画树；带 `maxDepth` / `maxFiles` 防呆上限并回报 `truncated`。
  `folderStats()` 汇总每级目录的直接文件数、含子目录总数与子目录数（空目录也进树）。
- 新增 `lib/store.js`：`.library-index.json`（点开头，扫描自动跳过）。原子写入、
  版本不符或损坏一律退回空索引；`upsertEntry` 支持整体替换与增量增删标签；
  全空的条目直接删除而不是留空壳；`pruneEntries` 只在写入前清理悬空项——
  读取时清理会把"看一眼"变成一次隐式删除。
- 重写 `lib/service.js`：`snapshot()` 带 `cacheMs` 短缓存，任何写操作立刻作废；
  `list()` 二模式（无筛选=子项模式、有筛选=搜索模式，不做隐式猜测）；
  `detail()` / `tree()` / `annotate()` / `rescan()`；库根不存在返回空库而非报错。
- 重写 `lib/routes.js`：`/status`、`/items`、`/item`、`/tree`、`/file`、`/rescan`、
  `/annotate`。文件流是收口重点——`resolveInside` 挡路径逃逸、隐藏段直接 403、
  HTML/SVG 强制加 `Content-Security-Policy: sandbox`（否则预览一个存进来的页面
  等于在 DSH 的源里执行别人写的脚本）；带 Range / 条件请求（304）/ HEAD / 下载模式。
- 安装脚本改为**就地覆盖**：原先"先整目录删除再复制"会触发环境里的删除保护钩子，
  整个脚本中断、profile 里连插件都不剩。现在只复制与覆盖，陈旧文件仅在 `-Clean`
  时逐个尝试删除，被钩子拒绝的会列出来让人手动处理。
- 测试扩到四套、合计 259 项：
  - 新增 `tools/scan-test.mjs`（90 项）—— 类型目录、扫描跳过规则、深度与条目上限、
    目录汇总、索引往返与容错、标注增量写入与悬空清理；
  - `tools/host-test.mjs` 重写（117 项）—— 改为真实起 HTTP 服务器走真 socket，
    覆盖分页/搜索/标签检索、详情、分组树、文件流的 Range/304/HEAD、三道收口、
    标注写入与清空、重扫、以及信任栅栏的四种返回。

### 阶段 3：页面

导航形态定为**面包屑**而不是左树：库的分组本来就是目录，面包屑给的层级信息一样多，
却不用维护一棵会跟磁盘脱节的树，也不占掉列表宽度。

- 新增 `lib/names.js`：入库名称的校验与去重。挡非法字符、控制字符、结尾的点、
  Windows 保留设备名（`CON` / `COM1` / …）、隐藏名与超长；撞名时给 `名字 (2).ext`
  并把扩展名留在最后，比较**大小写不敏感**（Windows 文件系统的语义）。
- `lib/service.js` 增加三个只新增的动作：`mkdir` / `createText` / `saveUpload`。
  名称去重前会重新读一遍目录，而不是复用可能落后几秒的扫描快照 ——
  **覆盖已有资料是这里唯一不能犯的错**。上传先写同目录下带随机后缀的 `.part`
  临时文件再改名，而 `.part` 本来就在扫描的跳过规则里，写到一半的失败不留半截文件。
- `lib/routes.js` 增加 `/mkdir` / `/create` / `/upload`（均 201）。新增
  `LibraryError` 到 HTTP 状态码的映射表；名单里没有的码一律 500，不让内核的语义错误
  悄悄变成 200。上传有 `content-length` 时提前拒绝，省得白收几十兆。
- 配置新增 `maxUploadBytes`（默认 64 MB）。
- **库根改到 D 盘**：出厂默认 `LIBRARY_DEFAULTS.root` 与 `cordis.patch.yml` 的
  `config.root` 都是 `D:/dsh-library-data`。两处都写是为了堵掉"补丁层的 config 没生效
  → 库根静默留在系统盘"这个失败模式；`/status` 新增 `rootSource` 说明当前库根是
  配置给的还是默认推出来的。
- `client.js` 整体重写：面包屑导航、紧凑列表（图标 + 名称 + 类型 + 大小 + 时间）、
  整库搜索、拖拽入库（带覆盖提示层）、文件选择导入、新建文件夹/文档、右侧详情栏
  （类型/大小/时间/完整路径/下载 + 标签与备注，失焦即保存）、空库/空分组/无匹配
  三套不同的空状态、按能力清单禁用未开放的控件。
- 修掉一个会让插件根本跑不起来的错误：内核里名为 `mkdir` 的方法遮蔽了 `node:fs`
  的 `mkdir`，`ensureRoot()` 会递归调用自己。导入改名成 `fsMkdir` 并加注释钉住。
- 修掉"新建文档被误报成撞名"：比对去重结果时用的是没补扩展名的输入
  （`计划` 对比 `计划.md`），应拿真正发出去的名字比。
- 测试扩到四套、合计 401 项：
  - `tools/scan-test.mjs`（124 项）新增入库名称一组：24 项校验 + 10 项去重；
  - `tools/client-test.mjs` 重写（95 项）—— 迷你渲染器改为**按依赖数组判断 effect
    是否重跑**，于是"点进分组后列表变了""选中文件后详情栏出现""拖拽后发出上传请求"
    这些交互是真的跑过一遍；另覆盖能力协商禁用与组件库缺失时的整页降级；
  - `tools/host-test.mjs`（161 项）新增入库端点一组：新建/去重编号（含大小写）、
    非法名与保留名、父目录逃逸与不存在、父目录是文件、上传字节一致、重名上传自动改名、
    上传上限 413 且不留残渣、临时文件不落清单、入库后仍可打标签。

### 阶段 4：原生打通

本阶段先把 DSH 右侧栏与交付卡片两条链路的**真实契约**挖出来，再按契约实现。
挖出来的关键事实（写在这里，省得下次再挖一遍）：

- `ctx.sidebarRightTabs.register({ id, kind, patterns, priority, canOpen, title })`
  返回 disposer；`id` 全局唯一（二次注册 throw）；`fallback` 档独占一个 `kind`，
  `extension` 与 `builtin` 可各占一份配对；`patterns` 含 `:` 时匹配**整个地址串**，
  不含时只匹配 URI pathname 且忽略大小写。
- `ctx.sidebarRight.openResource(address, options?)` 内部只校验两件事：地址以
  `dsh-resource://` 开头、有已注册的类型认领它（`claim()` 排序 = 档位 → pattern 长度
  → 注册顺序）。**不校验资源提供方** —— 地址只是身份字符串，正文自己读内容。
  这让"自有资源类型"完全可行。
- 但这个入口走的是 `require()` 取的**当前会话** —— **没有会话就没有停靠面**，
  调用点必须接住这个异常并给人话。
- `sidebarRight` / `sidebarRightTabs` 由 `ui-sidebar-right` 经 `ctx.reflect.provide`
  提供，可能在本插件激活**之后**才就绪，直接读会拿到 `undefined`。
- 正文拿 `useTabInfo` 是**框架注入的 prop**，不是 import 来的 hook。
- `dsh.client.inject` 里写的是**包名**（`ui-sidebar-documentpreview` 就是这么声明
  它对右侧栏的依赖的），不是服务名。

实现：

- **右侧栏预览。** 注册自有类型 `dsh-library-file`（`kind: library-file`，
  `extension` 档，pattern `dsh-resource://library/**`）与对应的
  `sidebar.right.pane.tab` 正文。**刻意不复用** DSH 文档预览的 `dsh-resource://file/**`：
  那个类型以 `fallback` 档认领且只认 Session 地址，读文件走 Session 文件系统、受工作区
  权限约束 —— 而资料库是会话之外的中央库，文件在 `D:\dsh-library-data`，塞进任何会话的
  坐标系都不对。
- 渲染复用官方零件：Markdown 走 `MarkdownText`（DSH 渲染消息正文的那一个）、代码走
  `CodeBlock`（带语言与行号）、图片直接交给浏览器解码（字节不进 JS）、其余文本是等宽
  `<pre>`。超过 512 KB 的文本与已知二进制只给"下载后打开"。内容现读现渲染，不缓存 ——
  与页面清单同一口径：磁盘才是权威。
- **地址编解码的逃逸校验必须在解码之后做**：逐段 decode 之后 `%2F` 会还原成 `/`，
  于是 `..%2Fetc` 变成 `../etc`，只看分段结果会漏过去。解码后凡是仍含分隔符的段一律拒掉
  （宿主半的 `resolveInside` 是第二道门）。
- **服务等待**：`whenService` 短轮询（约 2 秒）等反射服务出现，拿到就注册并把 disposer
  交回 effect 清理；超时就放弃 —— 预览不可用是纯降级，不影响页面其余部分。正文那条路
  不用轮询，`slots.inject` 本身就是"等这个槽出现"，`ui-sidebar-right` 没挂载时静默永不触发。
- **项目批量导入。** 新增 `lib/scan.js` 的 `scanExternal()`（复用库内扫描的跳过规则，
  只返普通文件，`isFile()` 是 lstat 语义所以符号链接天然被挡）与 `lib/service.js` 的
  `scanExternalDirectory()` / `importFrom()`。三条硬规则：源目录必须是**绝对路径**
  （相对路径的含义取决于进程工作目录，静默导到别处比报错糟得多）、**只复制不移动**、
  **只认普通文件**（`lstat`）。逐份收集失败原因而不是整体失败。
- `lib/routes.js` 增加 `GET /external?dir=`（只读候选）与 `POST /import`（执行），
  `INVALID_SOURCE` → 400。单次导入上限 200 份。
- 页面新增「从目录导入」：填目录 → 扫描 → 勾选 → 导入，**刻意不做"一键全收"** ——
  产出物目录里往往混着一堆不该进库的东西，让人看见清单再决定比事后清理便宜。
  默认全选，按能力清单（`external` / `import`）禁用。
- 详情栏新增「在右侧打开」，失败时提示"先打开一个对话"。
- 测试扩到 **485 项**（logic 21 / scan 124 / client 148 / host 192）：客户端新增预览
  类型注册与渲染共 39 项（含逃逸地址、图片不搬字节、超大不渲染、外来地址拒绝、服务不在
  时静默降级）与目录导入 21 项；宿主端新增库外扫描与批量导入 29 项（含"源文件仍在原处"
  与逐份跳过原因）。

### 阶段 5：摘掉右侧栏预览，改为主页面内查看；视觉重做

本阶段的起因是两件事：用户指出「好多按钮功能并没有实现，界面设计和我开源项目不一样」，
以及一条边界纠正 —— **「我并不想要资料库的文件在右侧栏打开，这本身就是冲突的，
只需要在主页面能打开并查看即可」**。

#### 三层职责的结论（写下来，后续改动都按这份口径）

| | 右侧栏「工作区文件」 | 素材库 `dsh-asset-library` | 资料库 `dsh-library` |
|---|---|---|---|
| 范围 | **一次会话**的工作目录 | 一个项目目录（原地索引） | **跨会话跨项目**的中央库 |
| 根 | 会话工作目录，只有一个 | 项目里的 `assets/` | 配置的库根（`D:\dsh-library-data`） |
| 能不能出根 | **不能**（宿主也拒绝） | 能（宿主半自己扫） | 能（自己的库） |
| 文件 | 只列目录，不搬 | 不搬，就地引用 | **真实副本** |
| 能力 | 列目录 | 缩略图 / 打标 / 参照图钉 | 标注 / 检索 / 导入 / 分组 |

三者**不重合**。原先那个右侧栏预览是纯冗余：从会话侧栏打开一个跨会话的中央库文件，
坐标系是错的（`openResource` 内部要取当前会话，没有会话直接抛），而且它让用户在
"会话的东西"和"跨会话的库"之间产生混淆。**整条链路删干净**：`dsh.client.inject`
去掉 `@deepseek-ai/dsh-client-ui-sidebar-right`、不注册 `dsh-library-file` 类型、
不注册 `sidebar.right.pane.tab` 正文、详情栏去掉「在右侧打开」。契约测试加了一条
**「没有注册任何右侧栏 tab 正文」**的断言守着它别悄悄回来。现在只剩两个注册：
`sidebar.panellist`（入口）与 `main`（页面）。

#### 后端补齐

- `GET /facets?scope=` —— chip 行上的计数。**面板不能自己数**：它手里只有当前这一页
  （`limit` 默认 60），自数出来的数字会随翻页变化，那是错的 —— chip 说的是
  "这个范围里有多少"，不是"这一页里有多少"。计数跟着 `scope` 走；目录**只列直接
  子目录**（深层目录该在面包屑与「上一级」里，不该在 chip 行里堆成一长串）。
- **`list()` 的 `scope` 用「键是否存在」区分整库与未指定。** `scope=''` 与"没给 scope"
  在字符串上无法区分，而面板的第一屏就是"整库的全部文件"，必须能明确表达
  "我要整库、要递归"。比较用 `scope + '/'` 而不是裸 `startsWith(scope)` ——
  后者会把 `图片集/` 里的东西算进 `图片/`。这一条同时让目录筛选**能与其他筛选叠加**
  （进 `图片/` 之后还能再按类型或标签筛）。
- `POST /annotate` 支持 `paths` 数组（批量）。三条约束：请求体给**路径**、响应给
  **条目**；返回 `missing` 让面板能报"有 N 份没改成"；命中为空时**不碰磁盘**
  （否则会造出一堆空条目）。索引只读写一次（循环外 `readIndex`/`writeIndex`），
  但仍逐条 `upsertEntry` —— 它会顺带把"改完变空"的条目删掉，逐条走才保得住这条语义。
  单条契约原样保留（找不到仍 404）。
- `POST /reveal`（在资源管理器中显示）——**本插件唯一一个会离开进程的端点**，
  因此配了开关 `allowReveal`（默认开）。关掉时 `capabilities` 里就没有 `reveal`，
  面板**整个按钮不出现**（而不是禁用后再报错）。三道收口：开关 → `resolveInside`
  挡逃逸 → 隐藏段 403，再 `stat` 确认存在。**只 spawn 不经 shell**（`shell: true`
  等于把库里的文件名当命令行解释，一个叫 `a&calc.exe` 的资料就成了任意命令执行）；
  Windows 的 `/select,` 与路径必须拼成**同一个参数**，分开传会被当成两个文件、
  开两个窗口。
- `KINDS` 新增 `video` / `audio`。分镜项目的产出就是 mp4，把它们一律归到 `file`
  兜底会让"按类型筛"这一栏在真实的创作流程里失去意义。

#### 一处偏离原计划的地方（写明原因）

原计划让后端读文件头探测图片分辨率与视频时长。**改成客户端探测**：`<img>` 的
`naturalWidth/Height`、`<video>` 的 `duration` 都是浏览器免费给的，更准、零依赖，
还顺手拿到时长。不新增读文件头的模块，省掉一类文件解析的边界情况（半个文件头怎么办）。
代价是要在 `MEDIA_MEMO` 里记一份，键取 `relPath|mtimeMs|size` —— 文件一动就重探。

#### 视觉重做

按参照实现（`dsh-asset-library` 的 `.dal-*`）的设计语言重做，但控件**全部自绘**，
只从官方组件库取 6 件（`Toast` / `StateDot` / `PathLabel` / `MarkdownText` /
`CodeBlock` / `languageForPath`）。理由：官方件的图标名是猜的，取不到会渲染成空白，
而混用两套图标比不用更难看。

- **两行表头**。第一行：标题 + 状态点 + 计数 + 当前路径面包屑 + 搜索 + 排序 +
  视图切换 + 新建 / 导入 / 重扫。第二行：`全部 / 类型 │ 上一级 / 全部目录 / 目录 │ 标签`
  三组 chip + 清空筛选。
- **网格 / 列表可切换**（默认按修改时间倒序，网格 4:3 缩略图 + 类型徽标 + 时长角标；
  列表是五列表格：名称 / 类型 / 大小 / 修改时间 / 标签）。
- **页内「放大卡片」**：顶部「← 返回 + 文件名」与「‹ N / M ›」，左侧媒体
  （图片 / 视频 / 音频 / 代码 / 太大 / 失败各有一态），右侧字段表 + 三个动作
  （复制路径 / 在资源管理器中显示 / 下载）+ 标签胶囊 + 备注 + **显式「保存」**
  （备注不自动存，也不用失焦触发 —— 写到一半切走就丢了）。
- 目录渐进收窄、实时搜索（不用按回车）、加载更多、拖拽入库、键盘（`/` 聚焦、
  方向键与 `j`/`k` 移动、`Enter` 打开、`Esc` 逐层退出）。

#### 修掉的真 bug（都不是测试写错，是产品代码确实错了）

1. **CSS 定义了却从没渲染进元素树。** `STYLE` 里是完整的样式表，但宿主不会执行
   写在模块作用域里的模板字符串 —— CSS 只在**元素树里出现**，浏览器才会建样式表。
   真机上整个资料库是**完全无样式的裸 HTML**：两行表头塌成竖排、卡片没有网格、
   chip 变成一串带边框的按钮。而契约测试查的是 className，全都对，一路绿灯。
   只有像素截图抓得到它（见下面的验证链）。
2. **详情页所有操作无声。** Toast 节点写在列表分支的返回里，而放大卡片是**整页
   提前 return** 的 —— 于是在详情里保存备注 / 复制路径 / 定位失败全部静默消失，
   而这些恰恰是最需要反馈的操作。样式表当时也在同一个坑里。
3. **「绝对路径」显示 `—`、`复制路径` 复制到相对路径。** `absolutePath` 只在
   `detail()` 里补，但面板几乎总是先渲染列表、再点开某一条 —— 走的是 `list()` 的
   返回值。改成在投影层 `toWire(item, root)` 就带上。
4. **Shift 范围选择退化成单选追加。** 锚点只在"非 Ctrl 点击"时更新，于是
   "Ctrl 点两个 → Shift 点第三个"因为锚点还停在 `null` 而只追加了一项。
   现在的口径与参照实现一致：**Ctrl 与普通点击更新锚点，Shift 不更新**（Shift 是
   "以锚点为起点扩展"的修饰键，改了锚点就没法连续扩展），且取**并集**而不是替换。
5. **能力协商对 `facets` 没生效。** `/facets` 是阶段 5 才加的端点，老内核上没有它；
   面板无条件请求、catch 里兜住，结果是"永远拿不到计数"却仍留一排没有数字的标签。
   现在没声明 `facets` 能力就不请求，chip 行退化成只有「全部」。

#### 验证链：离屏渲染 + 无头截图

```
node tools/render-preview.mjs      # 渲染 12 个视图成静态 HTML
node tools/shoot-preview.mjs       # 用系统自带 Edge 无头截图
```

`client.js` 是给宿主在浏览器里跑的模块，没有构建、没有可独立打开的页面。只跑断言
能证明"结构还在"，证明不了"看起来是否干净" —— 上面第 1 条就是靠这一层抓到的。
做法：用**与契约测试同一份**迷你渲染器（`tools/mini-react.mjs`）把 `<Panel>` 渲染成
宿主元素树，序列化成静态 HTML，配上 DSH 浅色 token 与树里那份真实 CSS，最后用
系统自带的 Edge（`--headless=new --screenshot`）按精确视口截图，不装 Playwright。

状态注入靠**预置 hook 槽位**而不是模拟点击：槽位下标用 `panelHookIndex(变量名)` 从
源码解析，不写死数字 —— 写死的话，"在中间加一个 useState" 会把后面全部错位，
而且**错位是静默的**（预置到错的槽位上只是"少了那条批量操作条"，不报错）。

`tools/mini-react.mjs` 与 `tools/fake-backend.mjs` 是从 `client-test.mjs` 里抽出来的
共享模块：断言与预览必须看到**同一个世界**，两份实现一定会漂移，而漂移是静默的。

> 顺手记一条给未来的自己：`STYLE` 是模板字符串，**注释里不能出现反引号**。
> 写了 `` `<video>` `` 会报 `ReferenceError: video is not defined`，报错位置指向
> CSS 中段而不是任何一行看起来可疑的代码。

#### 测试

- 迷你渲染器的 hook 状态改为**按树路径隔离**。原先是全局槽位 + 一个 `cursor` 往下发号，
  看上去像 React 实际不是：`walk` 每次断言都把整棵树重新展开一遍，于是 `Detail` 的
  `note` 落在 `Panel` 的某个槽位上，下一次 `collect` 又换到别的槽位 —— 表现为
  「改完备注，`data-dirty` 却是 false、按钮 `disabled` 却是 true」这种自相矛盾的现象。
  真实 React 按**位置**记状态，所以也按路径记。改完之后一批"通过"的断言开始失败 ——
  它们之前是靠错位意外通过的。
- 假后端修三处不保真（都让面板侧报"操作失败"，看着像产品坏了）：请求体挂到
  `parsed` 上（`responder` 只收得到 `parsed`，读 `body` 直接 `ReferenceError`）；
  批量 `/annotate` 响应回**条目**而不是路径串；空库的 `/items` 跟着空。
- 宿主端新增 `scope` 语义、`/facets`、批量标注、`/reveal` 四组行为断言
  （`setSpawnForTest` 把 spawn 换成记录器：真的弹窗是实现细节，路径拼错、开关没关、
  逃逸没挡才是会伤到用户的东西）。`apply` 与 Web 注册的成对关系改为**每次 apply
  断言增量**，不再写死总数。

### 阶段 6：三栏布局 + 四类文档直接预览

本阶段的起因是一句对齐要求：**「像 WorkBuddy 的资料库这样左右分栏，左侧项目管理、
右侧内容，md / Word / Excel 这类都能直接查看，不用启动右侧栏」**。

#### 布局口径：左树与中列表常驻，右内容按需出现

阶段 5 的"点开一份资料就整页切成详情"在三栏下不成立 —— 点开之后左树没了、列表也没了，
想看第二条必须先退回列表，于是"边翻列表边看内容"这个最常见的动作做不了。现在是：

| 栏 | 内容 | 宽度 |
|---|---|---|
| 左 `dsl-rail` | 搜索框 / 全部资料 / 最近添加 / 按类型（计数取自 `/facets`，不重复请求）/ 可展开收起的目录树 | `clamp(180px,20%,236px)` |
| 中 `dsl-mid` | 网格或列表 + 两行表头（表头横跨左中两栏） | 弹性 |
| 右 `dsl-pane` | 四类内容渲染器 + 元信息区（路径 / 标签 / 备注 / 复制 / 定位 / 下载） | `clamp(300px,38%,560px)`；**空态时 176px** |

三个栏宽是互相挤出来的，所以三处一起改才好看：右栏从 42% 收到 38%，网格最小列宽
从 176px 收到 148px，中栏因此从两列变三到五列。**空态右栏单独收窄**是单独的一条
—— 那里只有一句提示，占掉四成宽度会让"扫一眼找文件"这件事的效率掉三分之一。
窄屏（≤980px）右栏改为覆盖整宽，≤620px 整体收起。

旧 `Detail` 组件（285 行）整块删除，10 条随之变孤儿的选择器一并清掉。

#### Office 解析：零依赖手写 zip + OOXML

`.xlsx` / `.docx` 都是 zip。Node 自带 `zlib.inflateRawSync`，所以**不引第三方库**：
`lib/office.js` 自己写最小 zip 读取器（只支持 stored(0) 与 deflate(8) 两种方法，
其余明确报 `UNSUPPORTED`）。xlsx 侧处理共享字符串 / 内联字符串 / 稀疏列；docx 侧取
`word/document.xml`，按文档顺序解析 heading / list / paragraph / table。

CSV / TSV 走一个 RFC 4180 状态机，**不用 `split('\n')`** —— 引号内的换行、引号内的
逗号、`""` 转义这三种情况都会让它解析错，而真实资料里的 CSV 三种全都有。

#### 端点：`GET /document?path=`

按扩展名分派四类出口：`markdown` / `sheet` / `blocks` / `code`（含 `json`）。
文本类有 512 KB 上限（`open` + 只读前 N 字节），二进制 1 GB。UTF-8 优先，
遇到 U+FFFD 退回 GBK —— 中文资料库里 GBK 编码的 CSV 仍然常见。

失败按 `code` 分级，四种提示对应四种处置（去掉密码 / 重新导出 / 换格式 / 下载）：
`ENCRYPTED` / `NOT_XLSX` / `NOT_DOCX` / `NOT_A_ZIP` / `TRUNCATED` / `CORRUPT` /
`UNSUPPORTED` / `TOO_LARGE`。状态码统一落在 4xx（415 / 404 / 422），不是 5xx ——
5xx 的运维口径会指向"资料库自己坏了"，而实际是这份文件的问题。

`GET /items?recent=N`（1–365 天）与 `/tree` 返回的 `recent` 一起支撑左栏的「最近添加」。
`recent` 是**显式查询参数**，不是 `@recent` 魔法搜索词 —— 那样用户真去搜 `@recent`
会命中一堆莫名结果。

#### 修掉的真 bug

1. **`looksEncrypted` 读错 EOCD 偏移。** 原来读 `eocd + 8` 当加密标志位，那里其实是
   条目数，于是加密的工作簿被判成"损坏"。改为读**中央目录第一条条目**的通用标志位
   bit 0（抽出 `findCentralDirectory` 让两处共用同一份扫描逻辑）。
2. **OOXML 解析器不认自闭合标签。** 真实 xlsx 里 `<sheet .../>` 是自闭合的，
   `elementsOf` 找不到闭标签就 `break`，整个工作簿解析成空 —— 报"这个工作簿里没有
   工作表"。改成自闭合时取 `inner: ''` 并继续。
3. **切掉开标签把语义全丢了。** OOXML 的语义几乎全在属性上：`t="s"` 决定单元格类型、
   `r="C5"` 决定列位置、`w:val` 决定标题级别。只取标签之间的正文，表格会解析成
   `["0","1","2","3"]`。改为返回 `{ open, inner }` 并新增 `attr()`。
4. **`topLevelBlocks` 遇自闭合 `<w:p/>` 就 `break`**（注释写"跳过"而代码是 break），
   会把后面所有正文一起丢掉。改 `continue`。
5. **`sheets.push(parseSheet(...))` 丢了 `name`**，页面表格没有工作表标签。
6. **`OFFICE_STATUS` 漏了 code。** 只挑了 3 个，剩下的全落 `CORRUPT`，于是
   「.docx 其实是个 .xlsx」被报成"文件损坏"—— 而两者的处置完全不同。列全 8 个。
7. **`LIBRARY_STATUS` 缺 5 个 code**，全落 500。
8. **`/tree` effect 依赖 `caps`**，而 `useCaps` 每次渲染都 `new Set(...)` —— 用它当
   依赖等于每渲染一次就重跑 effect，自己喂自己的循环，把 settle 的重试次数吃光。
   改成依赖 `hasTree` 布尔。

#### 验证链自身的两个 bug（这一层最值得记）

截图全部停在"正在读取…"，而产品代码与契约测试**全绿**。两处原因都在验证链自己身上：

1. **`settle` 只 `renderRoot` 不 `walk`。** 函数组件的子树在 `renderRoot` 里只是
   `{ type, key, props }`，它的 hook 从不在这条路径上跑 —— `Pane` 的 `/document`
   请求因此根本发不出去。`settle` 每轮补一次 `walk(tree, () => {})`。
2. **序列化器与 `walk` 用了两套 hook 路径命名空间。** `serializeTree` 自己数
   `组件名#序号`，`walk` 用的是树路径分隔符（`.` / `+` / `>`）。于是 `walk` 把
   `/document` 的结果写进 `#root.2+3>Pane`，序列化却从 `Pane#0` 读 —— 读到的是一份
   从没跑过 effect 的空状态。注释里原本写着"计数规则必须与 `walk` 一致"，但两处实现
   根本不是同一套。改成序列化复用 `ROOT_PATH` 与同一套分隔符。

另外把 `MarkdownText` / `CodeBlock` 在**预览**里换成了真渲染的替身。契约测试里它们
是 `primitives:CodeBlock` 这种哨兵标签（断言"走的是官方件"只需要比类型名），但浏览器
不认它，截图里就只剩裸文本 —— 于是"代码块在真机上长什么样"永远看不到，截图成了
骗人的东西。契约测试保持哨兵标签，预览单独给替身。

#### 测试

五套离线测试，合计 707 项断言，全部不依赖 DSH（logic 21 / scan 124 / host 278 /
client 239 / office 45）：

```
node tools/logic-test.mjs      # 路径归一化 / home 解析 / 原子写 / 标注序列化
node tools/scan-test.mjs       # 扫描 / 去重 / 目录统计 / 上限截断
node tools/host-test.mjs       # 真实 HTTP 面（含 /document 约 30 条）
node tools/client-test.mjs     # 面板契约 / 三栏 / 四类渲染器 / 降级
node tools/office-test.mjs     # Office 解析，45 项（对真实 Python 造的 zip 夹具）
```

夹具用 **Python 标准库 `zipfile`** 造（第三方实现，与手写解析器无共同代码 ——
共用代码的话，"手写解析器和某个 zip 库行为一致"就变成了同义反复）。产出 6 个：
双工作表 xlsx（含共享字符串 / 内联字符串 / 稀疏列 / rels 里文件名叫 `sheet7.xml`）、
stored 方法的 xlsx、带表格的 docx、扩展名与内容不符的 docx、缺 workbook 的 xlsx、
非 zip 的 docx。

`tools/client-test.mjs` 加了**反引号守卫断言**：`STYLE` 模板字符串内反引号数必须为 1。
这个坑本轮踩了三次（`SyntaxError: Unexpected identifier 'min'` /
`Unexpected identifier 'clamp'` / `ReferenceError: main is not defined`），靠记性不如钉一条断言。

离屏预览扩到 16 个视图，四类内容各有自己的截图 —— 合在一起看的话，"表格渲染成了正文"
或者"代码被当纯文本"会被另一类盖过去。

#### 新增 `tools/install-check.mjs`

起因是一次误判：用户截图里侧边栏没有「资料库」入口，而排查过程中我自己先错判了两次 ——
一次是把 `cordis.patch.yml` 的内容当成了 `cordis.yml`（一次 `cat` 三个文件，输出连在
一起），看到 1275 行官方组件配置就以为"DSH 重写了配置、丢了 library 行"；实际那个
文件一直是 4 行空列表，插件树由 `package.json` 的 `bundles` 加各 bundle 自己的 patch
拼成。

所以把"该看哪里"固化成 26 条断言：profile 声明、lock 条目、逐文件大小比对、
插件自身声明、patch 的 insert 段、库根位置（顺带守"别放 C 盘"）、`STYLE` 反引号数、
两个注册席位、以及阶段 5 那个"不注册右侧栏"的决定。

**它明确说自己查不了什么**：`/api/library/*` 是进程内虚拟路由，不监听 TCP，
起不来第二个进程（Electron 单体，没有 CLI 可用来加载 profile）。与其假装查过了，
不如把边界写清楚 —— 最后一步只能由人重启后在界面上确认。

