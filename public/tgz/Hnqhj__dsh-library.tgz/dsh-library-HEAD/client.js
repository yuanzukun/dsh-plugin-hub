/**
 * 资料库浏览器半（Client plugin）。
 *
 * 纯 JS、无构建：DSH 的模块加载器要的就是
 * `window.__ModuleLoader__.load({ id, factory })`。`require('react')` 与
 * `require('@deepseek-ai/dsh-client-ui-primitives')` 都由页面自己的模块表提供。
 *
 * 两个注册（形状照抄官方 Plugin Manager 面板与 dsh-asset-library）：
 *
 *   slots.inject('sidebar.panellist', → register({ name:'sidebar.panellist', id: PANEL_ID, … }, Icon))
 *   slots.inject('main',             → register({ name:'main', key: PANEL_ID, … }, Panel))
 *
 * 侧边栏条目的 `id` 与 `main` 槽的 `key` 相同 —— 这是"点侧边栏打开这个页面"的
 * 连接点，不要自己再加按钮或第二次 selectPanel。
 *
 * ## 为什么**没有**第三个注册（阶段 5 撤掉了右侧栏预览）
 *
 * 阶段 4 曾经把库里的文件注册成右侧栏的一个 tab（自有类型
 * `dsh-resource://library/**` + `sidebarRightTabs.register`）。技术上走得通是因为
 * 一条实测事实：`openResource` 只校验"地址以 `dsh-resource://` 开头"+"有类型认领"，
 * **不校验资源提供方** —— 地址只是身份字符串。但产品上是错的：
 *
 *  - 右侧栏的停靠面**属于一次会话**（`openResource` 内部要取当前会话，没有会话直接
 *    抛），而库里的文件不属于任何会话。结果是"打开一份资料"要先有一场对话；
 *  - 右侧栏自带的「工作区文件」面板（kind `files`，`builtin` 档）根是**会话工作
 *    目录**，官方 README 原文还写着"Host 本来也拒绝工作区根之外的路径"。拿它显示
 *    `D:\dsh-library-data` 里的东西是借用了别人的坐标系。
 *
 * 所以现在**只在主页面里查看**：点开一条资料 → 本页切成"放大卡片"（左本体 / 右详情
 * 与标注），`Esc` 或「← 返回」回到列表。资料库与右侧栏工作区文件是三层不同的作用域
 * （一次会话 / 一个项目目录 / 跨会话跨项目），互不替代。
 *
 * ## 布局：两行表头 + 两种视图
 *
 * 视觉语言照 `dsh-asset-library`（同一台机器上已验证的那套 `.dal-*` 写法）重做：
 *
 *   第一行  标题 + 计数 + 当前路径 + 搜索 + 排序 + 视图切换 + 新建/导入/重扫
 *   第二行  类型 chip │ 目录 chip │ 标签 chip
 *
 * 第二行**刻意不做折叠**：chip 全部平铺，维度之间用 1px 发丝线分组。折叠会把
 * "当前筛了什么"藏起来 —— 筛选状态不可见，就等于让人以为自己在看全部。
 *
 * 计数**必须问宿主**（`/facets`）：面板手里只有当前这一页，自己数出来的数字会
 * 随着翻页变化，那是错的。
 *
 * ## 图标为什么是自绘的
 *
 * 全部用 20×20 视口的内联 SVG（`currentColor` + 1.5px 描边），不取
 * `ui-primitives` 的图标件。两个理由：一是图标名是猜的，取不到就会渲染成空白；
 * 二是混用两套图标比统一自绘更难看。真正值得用官方件的是**内容渲染** ——
 * `MarkdownText` / `CodeBlock` / `Toast` / `StateDot` / `PathLabel`，它们的外观
 * 本来就该跟 DSH 其它页面一致，取不到时各自有兜底。
 *
 * ## 四个实测约束（写在题里，省得下次再挖一遍）
 *
 *  - 迷你渲染器（`tools/client-test.mjs`）只实现 `useState` / `useEffect` /
 *    `useCallback` / `useRef`，所以本页**只用这四个**钩子；
 *  - `useCallback` 的依赖数组必须写对（真实 React 会照它缓存），测试里每次渲染
 *    都会拿到新闭包，所以测试中"改完值要重新取节点"；
 *  - `ref` 挂在 `input` 上时会被测试替身接管（`current` 上只有 `click`），
 *    所以 `focus()` 一律走 `focusNode()` 里的 `typeof` 判断；
 *  - 测试环境没有 `window.addEventListener`，快捷键因此挂在**容器**的
 *    `onKeyDown` 上（容器 `tabIndex=0`，挂载时自己拿焦点），不注册全局监听。
 */
window.__ModuleLoader__.load({
    id: 'dsh-library',
    factory(require) {
        const React = require('react');
        const h = React.createElement;
        const { useCallback, useEffect, useRef, useState } = React;

        // ---- 官方组件库：取不到就各自兜底，整页不因此打不开
        let primitives = null;
        try {
            primitives = require('@deepseek-ai/dsh-client-ui-primitives');
        } catch {
            primitives = null;
        }
        const pick = (name, fallback) => {
            const value = primitives === null ? undefined : primitives[name];
            if (value == null) return fallback;
            // 兼容两种导出形态：普通函数组件，以及 memo / forwardRef 这类
            // `typeof === 'object'` 但带 `$$typeof` 的包装对象
            // （例如官方 `MarkdownText = memo(...)`）。旧写法只认函数组件，
            // 会把 memo 组件判成“不存在”回退成 null，导致 h(null) 渲染崩溃。
            const isComponent = typeof value === 'function'
                || (typeof value === 'object' && value.$$typeof != null);
            return isComponent ? value : fallback;
        };

        // ---- 诊断：把渲染崩溃同时写盘 + 渲染成可见面板，便于离线定位根因
        let diagFs = null;
        try { diagFs = require('node:fs'); } catch { try { diagFs = require('fs'); } catch {} }
        const diagWrite = (text) => {
            if (diagFs == null) return;
            try { diagFs.appendFileSync('C:/Users/Administrator/dsh-library-crash.log', text + '\n', 'utf8'); } catch {}
        };
        try {
            if (typeof console !== 'undefined' && console.error) {
                const origErr = console.error.bind(console);
                console.error = (...args) => {
                    try { diagWrite('[console.error] ' + args.map((a) => (a && a.stack) ? a.stack : String(a)).join(' ')); } catch {}
                    origErr(...args);
                };
            }
        } catch {}
        try {
            if (typeof window !== 'undefined' && window.addEventListener) {
                window.addEventListener('error', (e) => diagWrite('[window.error] ' + ((e && e.error && e.error.stack) ? e.error.stack : (e && e.message) ? e.message : String(e))));
                window.addEventListener('unhandledrejection', (e) => diagWrite('[unhandledrejection] ' + ((e && e.reason && e.reason.stack) ? e.reason.stack : String(e && e.reason))));
            }
        } catch {}

        const Toast = pick('Toast', null);
        const StateDot = pick('StateDot', null);
        const PathLabel = pick('PathLabel', null);
        const MarkdownText = pick('MarkdownText', null);
        const CodeBlock = pick('CodeBlock', null);
        const languageFor = pick('languageForPath', () => undefined);

        // ---- 图标：20×20 视口，1.5px 描边，跟随 currentColor
        const STROKE_PATHS = {
            search: 'M14 9a5 5 0 1 1-10 0 5 5 0 0 1 10 0M12.8 12.8 16.6 16.6',
            close: 'M5.2 5.2 14.8 14.8M14.8 5.2 5.2 14.8',
            plus: 'M10 4.4v11.2M4.4 10h11.2',
            paperclip: 'M14 8.9l-5 5a2.1 2.1 0 0 1-3-3l5.2-5.2a3.2 3.2 0 0 1 4.5 4.5l-5.2 5.2a4.3 4.3 0 0 1-6-6l4.7-4.7',
            folderOpen: 'M3 6.4h4.6L9.2 8.5H17v7.1a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1zM3 8.6V5a1 1 0 0 1 1-1h3l1.5 1.9',
            refresh: 'M16.2 10a6.2 6.2 0 1 1-1.9-4.4M16.4 3.4V6h-2.6',
            grid: 'M3.6 3.6h5v5h-5zM11.4 3.6h5v5h-5zM3.6 11.4h5v5h-5zM11.4 11.4h5v5h-5z',
            list: 'M4 5.4h12M4 10h12M4 14.6h12',
            arrowUp: 'M10 15.2V4.8M10 4.8 6.6 8.2M10 4.8l3.4 3.4',
            arrowDown: 'M10 4.8v10.4M10 15.2l-3.4-3.4M10 15.2l3.4-3.4',
            chevronLeft: 'M12.2 4.6 6.8 10l5.4 5.4',
            chevronRight: 'M7.8 4.6 13.2 10l-5.4 5.4',
            chevronDown: 'M4.8 7.8 10 13l5.2-5.2',
            copy: 'M7.6 7.6h7.8v7.8H7.6zM12.4 7.6V4.6H4.6v7.8h3',
            check: 'M4.6 10.4 8.2 14l7.2-8',
            tag: 'M4 4h5.6l6.4 6.4-5.6 5.6L4 9.6zM6.9 6.9v.5',
            download: 'M10 3.6v8.6M6.6 9 10 12.4 13.4 9M4 15.4h12',
            external: 'M11.2 4.2h4.6v4.6M15.4 4.6 9.6 10.4M12.8 11.4v4.2H4.2V7h4.2',
            video: 'M3.4 5.6h8.8v8.8H3.4zM12.2 8.8 16.6 6.2v7.6L12.2 11.2z',
            audio: 'M7.8 14.6a1.9 1.9 0 1 0 0-3.8 1.9 1.9 0 0 0 0 3.8M9.7 10.8V4.4l6.7-1.3v6.7',
            image: 'M3.4 4.4h13.2v11.2H3.4zM6.2 12.6l2.6-3.1 2.1 2 2.1-2.6 2.8 3.7',
            imageOff: 'M3.4 4.4h13.2v11.2H3.4zM6.2 12.6l2.6-3.1 2.1 2M3.2 3.2 16.8 16.8',
            doc: 'M5.6 3.4h5.8l3.4 3.4v9.8H5.6zM11.4 3.4v3.4h3.4',
            sheet: 'M3.4 4.4h13.2v11.2H3.4zM3.4 8.4h13.2M3.4 12h13.2M8.4 8.4v7.2M12.4 8.4v7.2',
            page: 'M3 5.4h14v9.2H3zM3 8.2h14M6 6.8h.6M8.2 6.8h.6',
            link: 'M8.4 11.6 11.6 8.4M6.9 12.6l-1 1a2.5 2.5 0 0 1-3.5-3.5L4.9 7.6M13.1 7.4l1-1a2.5 2.5 0 0 1 3.5 3.5L15.1 12.4',
            file: 'M5.6 3.4h5.8l3.4 3.4v9.8H5.6z',
            folder: 'M3 5.4h4.6L9.2 7.5H17v8.1H3z',
            archive: 'M3 6.4h14v9.2H3zM3 3.8h14v2.6H3zM7.8 9.6h4.4',
            info: 'M10 9.4v4.8M10 6.2v.4',
            // 「最近添加」用时钟：整个图标集里没有"最近"这一类的现成符号，
            // 而 history / rotate 都已经表示"重扫"了（refresh）。加一个 12 边
            // 的表盘比借用 refresh 清楚 —— 那个箭头在"最近"语境下会被读成
            // "重新扫描"。
            clock: 'M10 5.6V10l2.9 1.8M10 17a7 7 0 1 0 0-14 7 7 0 0 0 0 14',
        };
        const FILLED_PATHS = { play: 'M7 4.4 15.4 10 7 15.6z' };
        function Glyph({ name, size = 14, className }) {
            const filled = FILLED_PATHS[name];
            const d = filled ?? STROKE_PATHS[name];
            if (d === undefined) return null;
            return h(
                'svg',
                {
                    className,
                    width: size,
                    height: size,
                    viewBox: '0 0 20 20',
                    fill: filled === undefined ? 'none' : 'currentColor',
                    stroke: filled === undefined ? 'currentColor' : 'none',
                    strokeWidth: 1.5,
                    strokeLinecap: 'round',
                    strokeLinejoin: 'round',
                    'aria-hidden': 'true',
                    focusable: 'false',
                },
                h('path', { d }),
            );
        }

        const PANEL_ID = 'library';
        const NS = 'library';
        const API = '/api/library';
        const PAGE_SIZE = 60;

        /** 类型 → 词典键、图标、色调。顺序跟宿主 `KINDS` 一致，chip 位置才不会跳。 */
        const KIND_META = {
            folder: { key: 'kindFolder', icon: 'folder', hue: 'folder' },
            doc: { key: 'kindDoc', icon: 'doc', hue: 'doc' },
            sheet: { key: 'kindSheet', icon: 'sheet', hue: 'sheet' },
            page: { key: 'kindPage', icon: 'page', hue: 'page' },
            image: { key: 'kindImage', icon: 'image', hue: 'image' },
            video: { key: 'kindVideo', icon: 'video', hue: 'video' },
            audio: { key: 'kindAudio', icon: 'audio', hue: 'audio' },
            link: { key: 'kindLink', icon: 'link', hue: 'link' },
            file: { key: 'kindFile', icon: 'file', hue: 'file' },
        };
        const kindMeta = (kind) => KIND_META[kind] ?? KIND_META.file;

        const zh = {
            panel: '资料库',
            // 类型名：chip、卡片徽标、列表类型列、详情字段共用同一套
            kindFolder: '文件夹',
            kindDoc: '文档',
            kindSheet: '表格',
            kindPage: '网页',
            kindImage: '图片',
            kindVideo: '视频',
            kindAudio: '音频',
            kindLink: '链接',
            kindFile: '文件',
            panelDesc: '把每次对话与每个项目的产出收进一个可浏览、可检索、可整理的本地库',
            // 连接态
            connected: '已连接',
            connecting: '正在连接',
            offline: '宿主机连接失败',
            offlineHint: '资料库的后端跑在 DeepSeek Harness 进程里。请确认应用正在运行，然后重试。',
            retry: '重试',
            // 第一行表头
            matched: '匹配 {0} / 共 {1} 项',
            total: '共 {0} 项',
            searchPlaceholder: '搜索文件名、路径、标签或备注',
            clearSearch: '清空搜索',
            sortLabel: '排序',
            sortByName: '按名称',
            sortByMtime: '按修改时间',
            sortBySize: '按大小',
            sortAsc: '升序',
            sortDesc: '降序',
            toggleSortDir: '切换升序 / 降序',
            viewGrid: '网格视图',
            viewList: '列表视图',
            newDoc: '新建',
            menuNewFolder: '新建文件夹',
            menuNewDoc: '新建文档',
            menuImport: '导入',
            menuImportFiles: '从本机选择文件',
            menuImportFolder: '从文件夹批量导入',
            rescan: '重新扫描',
            rescanDone: '重新扫描完成 · {0} 条资料 · {1} 毫秒',
            // 第二行表头
            filterKind: '按类型筛选',
            filterFolder: '按目录筛选',
            filterTag: '按标签筛选',
            allKinds: '全部',
            allFolders: '全部目录',
            upLevel: '上一级',
            clearFilters: '清空筛选',
            noFolders: '这个范围里还没有子目录',
            noTags: '还没有任何标签',
            // 列表
            emptyRoot: '这里还没有资料',
            emptyRootHint: '把文件拖进来，或用右上角的「新建」「导入」。库根目录还不存在时，第一次入库会自动创建。',
            emptyFolder: '这个分组还是空的',
            emptyFilter: '当前筛选下没有资料',
            emptyFilterHint: '清掉几个筛选条件再看看 —— chip 上都能点，点了就取消。',
            colName: '名称',
            colKind: '类型',
            colSize: '大小',
            colTime: '修改时间',
            colTags: '标签',
            loadMore: '再加载 {0} 条',
            showing: '显示 {0} / {1} 条',
            truncated: '条目数触到了扫描上限，清单可能不完整',
            // 放大卡片
            back: '返回',
            prevItem: '上一项',
            nextItem: '下一项',
            page: '{0} / {1}',
            fieldKind: '类型',
            fieldSize: '大小',
            fieldTime: '修改时间',
            fieldDims: '尺寸',
            fieldRel: '相对路径',
            fieldAbs: '绝对路径',
            fieldSource: '来源',
            copyPath: '复制路径',
            reveal: '在资源管理器中显示',
            download: '下载',
            copied: '路径已复制',
            copyFailed: '复制失败，请手动选中路径',
            revealDone: '已在资源管理器中定位',
            revealFailed: '定位失败',
            tagsTitle: '标签',
            tagPlaceholder: '回车添加标签',
            removeTag: '移除标签 {0}',
            noteTitle: '备注',
            notePlaceholder: '这份资料是干什么用的…',
            save: '保存',
            saving: '保存中',
            unsaved: '未保存',
            saved: '已保存',
            previewBinary: '这是二进制文件，页面里看不了',
            previewBinaryHint: '下载到本机，或者在资源管理器里打开。',
            previewTooLarge: '文本太大，没有搬进页面',
            previewTooLargeHint: '下载到本机用编辑器打开更省事。',
            previewFailed: '打不开这份资料',
            imageBroken: '图片加载失败',
            // ---- 三栏布局：左树 / 中列表 / 右内容
            //
            // 这批键是三栏布局新增的。左树的三个快捷入口与"收起目录树"分开写，
            // 因为它们是两种不同的操作：前者改的是筛选范围，后者只改可见性。
            // 合成一个键看着省事，但收起之后那个入口就不该再出现了。
            railTitle: '资料库',
            railSearch: '搜索资料',
            railAll: '全部资料',
            railRecent: '最近添加',
            railByKind: '按类型',
            railFolders: '目录',
            railCollapseFolders: '收起目录树',
            railExpandFolders: '展开目录树',
            railNoFolders: '库里还没有子目录',
            recentWindow: '最近 7 天',
            // 右栏
            previewPaneTitle: '内容',
            previewEmpty: '未选中资料',
            previewEmptyHint: '点左侧文件',
            previewClose: '关掉内容栏',
            previewLoading: '正在读取…',
            // 表格
            sheetRows: '{0} 行',
            // 空表格名没有占位符可填，拆成独立键由调用点挑选（见 `sheetSheet` 的调用处）。
            sheetSheet: '{0}',
            sheetSheetEmpty: '表格',
            sheetEmpty: '这份表里没有数据',
            sheetTruncated: '内容很长，只显示了前 {0} 行',
            // Word
            docEmpty: '这份文档里没有可显示的文字',
            // 文档解析失败
            docLoadFailed: '读不出内容',
            docEncrypted: '这个文件设了打开密码',
            docEncryptedHint: '资料库打不开加密内容。在 Office 里去掉密码另存一次，之后就能直接看。',
            docCorrupt: '这个文件读不出来',
            docCorruptHint: '可能损坏了，也可能只是把后缀改成了 .xlsx / .docx。在 Office 里打开另存一次就好。',
            docUnsupported: '这一类文件暂时看不了',
            docUnsupportedHint: '页面里能直接看的是 Markdown、Excel（.xlsx / .csv）、Word（.docx）、代码与纯文本。',
            docDownloadInstead: '下载后用本机的软件打开',
            docTruncated: '内容很长，只显示了前面一部分',
            // 批量
            batchSelected: '已选 {0} 项',
            batchTagPlaceholder: '标签',
            batchAdd: '加标签',
            batchRemove: '去标签',
            batchCancel: '取消选择',
            batchDone: '已更新 {0} 项',
            batchMissing: '其中 {0} 项已不在库里',
            pickHint: 'Ctrl / Shift + 点击可多选',
            // 新建
            name: '名称',
            create: '创建',
            cancel: '取消',
            created: '已创建',
            nameTaken: '这个名字已存在，已换成相近的名字',
            // 拖拽 / 上传
            dropHint: '松手就收进资料库',
            dropped: '已入库 {0} 份资料',
            uploadFailed: '入库失败',
            tooLarge: '有 {0} 份超过大小上限，已跳过',
            // 目录导入
            importTitle: '从文件夹批量导入',
            importHint: '填一个本机文件夹的绝对路径，先看清单再决定收哪些。源目录里的文件不会被移动或改动。',
            importScan: '扫描',
            importScanning: '正在扫描…',
            importSource: '来源',
            importPickAll: '全选',
            importPickNone: '全不选',
            importDo: '导入选中的 {0} 项',
            importScanFailed: '扫描失败',
            importEmpty: '这个目录里没有可导入的文件',
            importDone: '已导入 {0} 份资料',
            importSkipped: '有 {0} 份没能导入',
            importClose: '收起导入面板',
            // 通用
            failed: '操作失败',
            folderName: '文件夹名',
        };
        const en = {
            panel: 'Library',
            kindFolder: 'Folder',
            kindDoc: 'Document',
            kindSheet: 'Spreadsheet',
            kindPage: 'Web page',
            kindImage: 'Image',
            kindVideo: 'Video',
            kindAudio: 'Audio',
            kindLink: 'Link',
            kindFile: 'File',
            panelDesc: 'A local library for the output of every conversation and project',
            connected: 'Connected',
            connecting: 'Connecting',
            offline: 'Host unreachable',
            offlineHint: 'The library backend runs inside DeepSeek Harness. Make sure the app is running, then retry.',
            retry: 'Retry',
            matched: '{0} / {1} matched',
            total: '{0} items',
            searchPlaceholder: 'Search name, path, tags or notes',
            clearSearch: 'Clear search',
            sortLabel: 'Sort',
            sortByName: 'By name',
            sortByMtime: 'By modified time',
            sortBySize: 'By size',
            sortAsc: 'Ascending',
            sortDesc: 'Descending',
            toggleSortDir: 'Toggle ascending / descending',
            viewGrid: 'Grid view',
            viewList: 'List view',
            newDoc: 'New',
            menuNewFolder: 'New folder',
            menuNewDoc: 'New document',
            menuImport: 'Import',
            menuImportFiles: 'Choose files',
            menuImportFolder: 'Import a folder',
            rescan: 'Rescan',
            rescanDone: 'Rescanned · {0} items · {1} ms',
            filterKind: 'Filter by kind',
            filterFolder: 'Filter by folder',
            filterTag: 'Filter by tag',
            allKinds: 'All',
            allFolders: 'All folders',
            upLevel: 'Up one level',
            clearFilters: 'Clear filters',
            noFolders: 'no sub-folders here',
            noTags: 'no tags yet',
            emptyRoot: 'Nothing here yet',
            emptyRootHint: 'Drop files in, or use "New" / "Import" at the top right. The library root is created on the first write.',
            emptyFolder: 'This folder is empty',
            emptyFilter: 'Nothing matches the current filters',
            emptyFilterHint: 'Clear a filter or two — every chip is clickable, clicking clears it.',
            colName: 'Name',
            colKind: 'Kind',
            colSize: 'Size',
            colTime: 'Modified',
            colTags: 'Tags',
            loadMore: 'Load {0} more',
            showing: 'Showing {0} of {1}',
            truncated: 'The entry cap was hit; the list may be incomplete',
            back: 'Back',
            prevItem: 'Previous',
            nextItem: 'Next',
            page: '{0} / {1}',
            fieldKind: 'Kind',
            fieldSize: 'Size',
            fieldTime: 'Modified',
            fieldDims: 'Dimensions',
            fieldRel: 'Relative path',
            fieldAbs: 'Absolute path',
            fieldSource: 'Source',
            copyPath: 'Copy path',
            reveal: 'Show in file manager',
            download: 'Download',
            copied: 'Path copied',
            copyFailed: 'Copy failed — select the path manually',
            revealDone: 'Revealed in the file manager',
            revealFailed: 'Could not reveal',
            tagsTitle: 'Tags',
            tagPlaceholder: 'Press Enter to add a tag',
            removeTag: 'Remove tag {0}',
            noteTitle: 'Note',
            notePlaceholder: 'What is this for?',
            save: 'Save',
            saving: 'Saving',
            unsaved: 'Unsaved',
            saved: 'Saved',
            previewBinary: 'Binary file — it cannot be shown here',
            previewBinaryHint: 'Download it, or open it in the file manager.',
            previewTooLarge: 'The text is too large to load into the page',
            previewTooLargeHint: 'Download it and open it in an editor instead.',
            previewFailed: 'Cannot open this item',
            imageBroken: 'Image failed to load',
            // ---- three-column layout: rail / list / content
            railTitle: 'Library',
            railSearch: 'Search the library',
            railAll: 'All items',
            railRecent: 'Recently added',
            railByKind: 'By type',
            railFolders: 'Folders',
            railCollapseFolders: 'Collapse folder tree',
            railExpandFolders: 'Expand folder tree',
            railNoFolders: 'No subfolders yet',
            recentWindow: 'Last 7 days',
            previewPaneTitle: 'Content',
            previewEmpty: 'Nothing selected',
            previewEmptyHint: 'Pick a file on the left',
            previewClose: 'Close the content pane',
            previewLoading: 'Reading…',
            sheetRows: '{0} rows',
            // Empty sheet names have no placeholder to fill; a standalone key is
            // picked by the call site (see where `sheetSheet` is rendered).
            sheetSheet: '{0}',
            sheetSheetEmpty: 'Sheet',
            sheetEmpty: 'This sheet has no data',
            sheetTruncated: 'Very long — showing the first {0} rows',
            docEmpty: 'This document has no readable text',
            docLoadFailed: 'Cannot read this file',
            docEncrypted: 'This file is password protected',
            docEncryptedHint: 'The library cannot open encrypted content. Save a copy from Office without the password and it becomes readable here.',
            docCorrupt: 'This file cannot be read',
            docCorruptHint: 'It may be damaged, or it may just be a renamed file. Open and re-save it from Office.',
            docUnsupported: 'This file type cannot be previewed',
            docUnsupportedHint: 'Readable here: Markdown, Excel (.xlsx / .csv), Word (.docx), code and plain text.',
            docDownloadInstead: 'Download it and open it locally',
            docTruncated: 'Very long — showing only the beginning',
            batchSelected: '{0} selected',
            batchTagPlaceholder: 'Tag',
            batchAdd: 'Add tag',
            batchRemove: 'Remove tag',
            batchCancel: 'Clear selection',
            batchDone: 'Updated {0} items',
            batchMissing: '{0} of them are no longer in the library',
            pickHint: 'Ctrl / Shift + click to select several',
            name: 'Name',
            create: 'Create',
            cancel: 'Cancel',
            created: 'Created',
            nameTaken: 'That name was taken, so a nearby one was used',
            dropHint: 'Drop to add to the library',
            dropped: 'Added {0} items',
            uploadFailed: 'Import failed',
            tooLarge: '{0} items exceeded the size cap and were skipped',
            importTitle: 'Import a folder',
            importHint: 'Give an absolute path on this machine, review the list, then pick what to copy in. Nothing in the source folder is moved or changed.',
            importScan: 'Scan',
            importScanning: 'Scanning…',
            importSource: 'Source',
            importPickAll: 'Select all',
            importPickNone: 'Select none',
            importDo: 'Import {0} selected',
            importScanFailed: 'Scan failed',
            importEmpty: 'Nothing importable in that folder',
            importDone: 'Imported {0} items',
            importSkipped: '{0} items could not be imported',
            importClose: 'Close the import panel',
            failed: 'Failed',
            folderName: 'Folder name',
        };

        // ---- 样式
        //
        // ## 这段是模板字符串：注释里**不能出现反引号**
        //
        // 反引号会提前结束字符串，剩下的 CSS 变成 JS 表达式。写 `.dsl-dmedia
        // video{}` 的话报 `ReferenceError: dsl-dmedia is not defined`；
        // 写 `` `<video>` `` 的话报 `video is not defined`。两种都指向 CSS 中段，
        // 而不是任何一行看起来可疑的代码 —— 排查起来很费时间。
        const STYLE = `
.dsl-root{position:relative;display:flex;flex-direction:column;height:100%;min-height:420px;overflow:hidden;outline:none;
  font-family:var(--dsw-font-family);font-size:13px;color:var(--dsw-alias-label-primary,#1a1a1a);
  background:var(--dsw-alias-bg-base,transparent)}
.dsl-root *{box-sizing:border-box}

/* 两行表头 */
.dsl-head{flex:0 0 auto;padding-top:var(--dsh-frame-top-clearance,48px);
  border-bottom:1px solid var(--dsw-alias-border-l1,rgba(0,0,0,.12))}
.dsl-bar{display:flex;align-items:center;gap:8px;min-width:0;padding:10px 16px}
.dsl-bar-chips{align-items:flex-start;gap:2px;padding:0 16px 9px;flex-wrap:wrap;row-gap:4px}
.dsl-title{display:flex;align-items:baseline;gap:8px;min-width:0}
.dsl-title-main{font-size:15px;font-weight:500;line-height:20px;white-space:nowrap}
.dsl-count{font-size:12px;font-weight:400;color:var(--dsw-alias-label-tertiary,#6b6b6b);white-space:nowrap}
.dsl-where{display:flex;align-items:center;gap:2px;min-width:0;overflow:hidden;font-size:12px;color:var(--dsw-alias-label-tertiary,#6b6b6b)}
.dsl-where-sep{padding:0 1px;opacity:.6}
.dsl-where-link{border:0;background:none;padding:1px 3px;border-radius:5px;font:inherit;font-size:12px;
  color:var(--dsw-alias-label-tertiary,#6b6b6b);cursor:pointer;max-width:180px;overflow:hidden;
  text-overflow:ellipsis;white-space:nowrap}
.dsl-where-link:hover{background:var(--dsw-alias-interactive-bg-hover,rgba(0,0,0,.06));color:var(--dsw-alias-label-primary,#1a1a1a)}
.dsl-where-link[data-on="true"]{color:var(--dsw-alias-label-secondary,#3d3d3d);font-weight:500}
.dsl-spacer{margin-left:auto}
.dsl-tools{display:flex;align-items:center;gap:2px}

/* 搜索：自绘细边框，不吃控件库的整块底色 */
.dsl-search{display:flex;align-items:center;gap:6px;flex:1 1 170px;min-width:110px;max-width:340px;
  padding:3px 8px;border:1px solid var(--dsw-alias-border-l1,rgba(0,0,0,.12));border-radius:6px;
  color:var(--dsw-alias-label-tertiary,#6b6b6b)}
.dsl-search:focus-within{border-color:var(--dsw-alias-brand-primary,#1f6feb)}
.dsl-search input{flex:1;min-width:0;border:0;outline:0;background:none;font:inherit;font-size:13px;
  color:var(--dsw-alias-label-primary,#1a1a1a);padding:0}
.dsl-search input::placeholder{color:var(--dsw-alias-label-tertiary,#6b6b6b)}
.dsl-search-clear{border:0;background:none;padding:0;display:flex;cursor:pointer;border-radius:4px;
  color:var(--dsw-alias-label-tertiary,#6b6b6b)}
.dsl-search-clear:hover{color:var(--dsw-alias-label-primary,#1a1a1a)}

/* 图标按钮 */
.dsl-iconbtn{display:inline-flex;align-items:center;justify-content:center;width:26px;height:26px;
  padding:0;border:0;border-radius:6px;background:none;color:var(--dsw-alias-label-tertiary,#6b6b6b);cursor:pointer}
.dsl-iconbtn:hover{background:var(--dsw-alias-interactive-bg-hover,rgba(0,0,0,.06));color:var(--dsw-alias-label-primary,#1a1a1a)}
.dsl-iconbtn[disabled]{opacity:.4;cursor:default}
.dsl-iconbtn[disabled]:hover{background:none;color:var(--dsw-alias-label-tertiary,#6b6b6b)}
.dsl-iconbtn[data-on="true"]{color:var(--dsw-alias-label-primary,#1a1a1a)}

/* 文字按钮 */
.dsl-btn{display:inline-flex;align-items:center;gap:6px;height:26px;padding:0 10px;border:0;border-radius:6px;
  background:none;font:inherit;font-size:13px;color:var(--dsw-alias-label-secondary,#3d3d3d);cursor:pointer;white-space:nowrap}
.dsl-btn:hover{background:var(--dsw-alias-interactive-bg-hover,rgba(0,0,0,.06));color:var(--dsw-alias-label-primary,#1a1a1a)}
.dsl-btn[disabled]{opacity:.4;cursor:default}
.dsl-btn[disabled]:hover{background:none;color:var(--dsw-alias-label-secondary,#3d3d3d)}
.dsl-btn-primary{background:var(--dsw-alias-brand-primary,#1f6feb);color:#fff}
.dsl-btn-primary:hover{background:var(--dsw-alias-brand-primary,#1f6feb);color:#fff;filter:brightness(1.08)}

/* chip：全部无边底，靠字重与发丝线区分层级 */
.dsl-tab{border:0;border-radius:6px;background:none;padding:4px 9px;font:inherit;font-size:13px;line-height:18px;
  color:var(--dsw-alias-label-tertiary,#6b6b6b);cursor:pointer;white-space:nowrap;display:inline-flex;align-items:center;gap:5px}
.dsl-tab:hover{background:var(--dsw-alias-interactive-bg-hover,rgba(0,0,0,.06))}
.dsl-tab[data-on="true"]{background:var(--dsw-alias-bg-layer-2,rgba(0,0,0,.05));
  color:var(--dsw-alias-label-primary,#1a1a1a);font-weight:500}
.dsl-tab[disabled]{opacity:.4;cursor:default}
.dsl-tab[disabled]:hover{background:none}
.dsl-tab-n{font-size:12px;color:var(--dsw-alias-label-tertiary,#6b6b6b);font-variant-numeric:tabular-nums}
.dsl-tab[data-on="true"] .dsl-tab-n{color:var(--dsw-alias-label-secondary,#3d3d3d)}
.dsl-sep{width:1px;height:16px;margin:0 7px;background:var(--dsw-alias-border-l1,rgba(0,0,0,.12));flex:0 0 auto;align-self:center}
.dsl-chip-empty{font-size:12px;color:var(--dsw-alias-label-tertiary,#6b6b6b);padding:4px 4px;opacity:.75}

/* 下拉 */
.dsl-dd{position:relative;flex:0 0 auto}
.dsl-ddtoggle{display:inline-flex;align-items:center;gap:5px;max-width:220px;border:0;border-radius:6px;background:none;
  color:var(--dsw-alias-label-secondary,#3d3d3d);padding:4px 7px;font:inherit;font-size:13px;cursor:pointer;white-space:nowrap}
.dsl-ddtoggle:hover{background:var(--dsw-alias-interactive-bg-hover,rgba(0,0,0,.06))}
.dsl-ddtoggle-name{overflow:hidden;text-overflow:ellipsis}
.dsl-ddbox{position:absolute;right:0;top:calc(100% + 6px);z-index:40;display:flex;flex-direction:column;gap:1px;
  min-width:180px;padding:6px;border:1px solid var(--dsw-alias-border-l2,rgba(0,0,0,.18));border-radius:8px;
  background:var(--dsw-alias-bg-layer-1,#fff);box-shadow:0 6px 20px rgba(0,0,0,.13);max-height:60vh;overflow:auto}
.dsl-dditem{display:flex;align-items:center;gap:8px;width:100%;border:0;border-radius:6px;background:none;
  padding:5px 8px;font:inherit;font-size:13px;color:var(--dsw-alias-label-secondary,#3d3d3d);cursor:pointer;text-align:left}
.dsl-dditem:hover{background:var(--dsw-alias-interactive-bg-hover,rgba(0,0,0,.06))}
.dsl-dditem[data-on="true"]{color:var(--dsw-alias-brand-primary,#1f6feb);font-weight:500}
.dsl-dditem-icon{margin-left:auto;display:flex;color:inherit}
.dsl-ddsep{height:1px;background:var(--dsw-alias-border-l1,rgba(0,0,0,.12));margin:5px 0}
.dsl-scrim{position:absolute;inset:0;z-index:35}

/* 主体
 *
 * 这里是 .dsl-main（三栏容器）而不是旧的 .dsl-body：.dsl-body 是整页
 * 滚动区，三栏布局里中栏与右栏各自滚动，所以滚动容器搬到了 .dsl-view
 * 与 .dsl-pane-body 上。 */


/* ---- 三栏：左树 / 中列表 / 右内容
 *
 * 布局口径（阶段 6 定下来的一条硬规则）：
 *
 * **左树与中列表常驻，右内容按需出现。** 之前是"点开一份资料就整页切成详情"，
 * 那样点开之后左树没了、列表也没了，想看第二条必须先退回列表 —— 于是
 * "边翻列表边看内容"这个最常见的动作做不了。WorkBuddy 的资料库是三栏，
 * 这里对齐。
 *
 * 三栏都用 min-width:0 —— flex 子项的默认 min-width:auto 会让内容把栏撑破，
 * 表格与代码块尤其明显（一个长行就能把整页顶出横向滚动条）。
 * 宽度用 clamp() 而不是固定 px：窄窗口下三栏会挤成一条，所以给中栏与右栏
 * 各自一个下限，低于下限时右栏先让位（flex-shrink 更大），再是中栏。
 * 真的放不下（比如拖到 600px 宽）时右栏整体收起，只留左树 + 列表 ——
 * 窄屏下"看内容"不如"看清列表"重要。
 *
 * 三个栏宽是**互相挤出来的**，定一个就要看另外两个：
 *  - 右栏 38%（不是 42%）：文档正文有最大行宽约束，38% 在 1240px 视口下
 *    约 470px，正好两三个汉字行宽的阅读区，再宽就只是把中栏的卡片挤成两列。
 *  - 中栏因此拿到约 500px，配合 minmax(148px,1fr) 能放三列 —— 卡片挤成
 *    两列时"扫一眼找文件"这个动作就废了（一屏只能看 4 张）。
 *  - 空态右栏更窄（.dsl-pane-blank，176px 固定）：未选中时那里只有一句提示，
 *    占掉四成宽度是最浪费的一种占法。中栏因此在"没选中"时能放四列。
 */
.dsl-main{flex:1 1 auto;min-height:0;display:flex;align-items:stretch;overflow:hidden}
.dsl-rail{flex:0 0 clamp(180px,20%,236px);min-width:0;display:flex;flex-direction:column;
  border-right:1px solid var(--dsw-alias-border-l1,rgba(0,0,0,.09));overflow:hidden}
.dsl-mid{flex:1 1 auto;min-width:0;display:flex;flex-direction:column;overflow:hidden}
.dsl-view{flex:1 1 auto;min-height:0;position:relative;overflow:auto;padding:12px 16px 20px}
.dsl-pane{flex:0 0 clamp(300px,38%,560px);min-width:0;display:flex;flex-direction:column;
  border-left:1px solid var(--dsw-alias-border-l1,rgba(0,0,0,.09));overflow:hidden;
  background:var(--dsw-alias-bg-layer-1,#fff)}
.dsl-pane-blank{flex-basis:176px;flex-shrink:0}
@media (max-width:980px){.dsl-pane{flex-basis:100%;border-left:0}
  .dsl-pane-blank{display:none}}
@media (max-width:620px){.dsl-pane{display:none}}

/* 左栏各段 */
.dsl-rail-search{display:flex;align-items:center;gap:6px;margin:10px 10px 8px;padding:0 8px;height:28px;
  border:1px solid var(--dsw-alias-border-l1,rgba(0,0,0,.12));border-radius:7px;
  color:var(--dsw-alias-label-tertiary,#6b6b6b)}
.dsl-rail-search:focus-within{border-color:var(--dsw-alias-brand-primary,#1f6feb)}
.dsl-rail-search input{flex:1;min-width:0;border:0;outline:0;background:none;font:inherit;font-size:12.5px;color:inherit;padding:0}
.dsl-rail-sec{padding:0 6px 8px}
.dsl-rail-sec-title{display:flex;align-items:center;gap:5px;padding:6px 6px 4px;font-size:11px;
  color:var(--dsw-alias-label-tertiary,#6b6b6b)}
.dsl-rail-sec-title button{margin-left:auto;display:flex;padding:2px;border:0;border-radius:4px;background:none;
  cursor:pointer;color:inherit}
.dsl-rail-sec-title button:hover{background:var(--dsw-alias-interactive-bg-hover,rgba(0,0,0,.05));color:var(--dsw-alias-label-primary,#1a1a1a)}
.dsl-rail-item{display:flex;align-items:center;gap:7px;width:100%;padding:0 8px;height:27px;border:0;border-radius:6px;
  background:none;cursor:pointer;font:inherit;font-size:12.5px;text-align:left;color:inherit;min-width:0}
.dsl-rail-item:hover{background:var(--dsw-alias-interactive-bg-hover,rgba(0,0,0,.05))}
.dsl-rail-item[data-on="true"]{background:var(--dsw-alias-interactive-bg-hover,rgba(31,111,235,.1));color:var(--dsw-alias-brand-primary,#1f6feb)}
.dsl-rail-item span{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.dsl-rail-item-n{margin-left:auto;font-size:11px;font-variant-numeric:tabular-nums;color:var(--dsw-alias-label-tertiary,#6b6b6b)}
.dsl-rail-item[data-on="true"] .dsl-rail-item-n{color:inherit;opacity:.75}
.dsl-rail-tree{flex:1 1 auto;min-height:0;overflow:auto;padding:0 6px 12px}
.dsl-rail-empty{padding:2px 8px;font-size:11.5px;color:var(--dsw-alias-label-tertiary,#6b6b6b)}
.dsl-rail-twist{display:flex;padding:0;width:15px;height:27px;align-items:center;justify-content:center;flex:0 0 15px;
  border:0;background:none;cursor:pointer;color:var(--dsw-alias-label-tertiary,#6b6b6b)}
.dsl-rail-twist:hover{color:var(--dsw-alias-label-primary,#1a1a1a)}
.dsl-rail-row{display:flex;align-items:center;min-width:0}
.dsl-rail-row .dsl-rail-item{flex:1 1 auto}

/* 右栏（内容） */
.dsl-pane-head{flex:0 0 auto;display:flex;align-items:center;gap:8px;padding:9px 12px;
  border-bottom:1px solid var(--dsw-alias-border-l1,rgba(0,0,0,.09))}
.dsl-pane-name{font-size:12.5px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;min-width:0}
.dsl-pane-body{flex:1 1 auto;min-height:0;overflow:auto;padding:14px 16px 24px}
.dsl-pane-meta{flex:0 0 auto;max-height:46%;overflow:auto;padding:12px 16px 16px;
  border-top:1px solid var(--dsw-alias-border-l1,rgba(0,0,0,.09));
  background:var(--dsw-alias-bg-layer-1,#fff)}
.dsl-pane-empty{display:flex;flex-direction:column;align-items:center;justify-content:center;gap:8px;
  height:100%;padding:24px;text-align:center}
.dsl-pane-empty-title{font-size:13px;color:var(--dsw-alias-label-secondary,#3d3d3d)}
.dsl-pane-empty-hint{font-size:12px;line-height:1.6;color:var(--dsw-alias-label-tertiary,#6b6b6b);max-width:30em}
/* 窄栏（未选中）里 padding 24px 会在 176px 宽度上留下 128px 的文字块 —— 中文
 * 折成每行两三个字，整段读起来是竖的。收到 10px，文字块 156px 能放下短句。 */
.dsl-pane-blank .dsl-pane-empty{padding:10px}
.dsl-pane-blank .dsl-pane-empty-hint{max-width:none}
.dsl-pane-note{font-size:11.5px;color:var(--dsw-alias-label-tertiary,#6b6b6b);margin-top:10px}

/* 右栏里的媒体 */
.dsl-pane-img{display:block;max-width:100%;height:auto;border-radius:8px;margin:0 auto}
.dsl-pane-video{display:block;width:100%;max-width:100%;border-radius:8px;background:#000}
.dsl-pane-audio{display:block;width:100%}
.dsl-pane-md{font-size:13.5px;line-height:1.75;max-width:46em}

/* 表格预览 */
.dsl-sheet{margin:0 0 18px}
.dsl-sheet-name{font-size:12px;color:var(--dsw-alias-label-secondary,#3d3d3d);margin-bottom:6px}
.dsl-tablewrap{overflow:auto;border:1px solid var(--dsw-alias-border-l1,rgba(0,0,0,.12));border-radius:8px;max-width:100%}
.dsl-table{border-collapse:separate;border-spacing:0;font-size:12px;line-height:19px;width:max-content;min-width:100%}
.dsl-table th,.dsl-table td{padding:4px 10px;border-bottom:1px solid var(--dsw-alias-border-l1,rgba(0,0,0,.07));
  border-right:1px solid var(--dsw-alias-border-l1,rgba(0,0,0,.07));text-align:left;vertical-align:top;
  white-space:pre-wrap;overflow-wrap:anywhere;min-width:52px;max-width:380px}
.dsl-table thead th{position:sticky;top:0;z-index:1;background:var(--dsw-alias-bg-layer-2,rgba(0,0,0,.04));
  font-weight:500;color:var(--dsw-alias-label-secondary,#3d3d3d)}
.dsl-table tbody tr:last-child td{border-bottom:0}
.dsl-table th:last-child,.dsl-table td:last-child{border-right:0}
.dsl-table-num{font-variant-numeric:tabular-nums}

/* Word 正文 */
.dsl-doc{font-size:13px;line-height:1.75;max-width:44em}
.dsl-doc p{margin:0 0 9px;white-space:pre-wrap;overflow-wrap:anywhere}
.dsl-doc h1,.dsl-doc h2,.dsl-doc h3,.dsl-doc h4,.dsl-doc h5,.dsl-doc h6{margin:18px 0 7px;line-height:1.4;font-weight:600}
.dsl-doc h1{font-size:17px}.dsl-doc h2{font-size:15.5px}.dsl-doc h3{font-size:14px}
.dsl-doc h4,.dsl-doc h5,.dsl-doc h6{font-size:13px}
.dsl-doc h1:first-child,.dsl-doc h2:first-child{margin-top:0}
.dsl-doc ul{margin:0 0 9px;padding-left:1.4em;list-style:disc}
.dsl-doc .dsl-doc-li{display:flex;gap:7px;align-items:baseline}
.dsl-doc .dsl-doc-bullet{color:var(--dsw-alias-label-tertiary,#6b6b6b);flex:0 0 auto}
.dsl-doc .dsl-doc-table{margin:12px 0 16px}

/* 预览失败 / 不支持 */
.dsl-pane-warn{display:flex;flex-direction:column;align-items:flex-start;gap:7px;padding:12px 13px;
  border:1px solid var(--dsw-alias-border-l1,rgba(0,0,0,.12));border-radius:9px;max-width:36em}
.dsl-pane-warn-title{font-size:13px}
.dsl-pane-warn-hint{font-size:12px;line-height:1.65;color:var(--dsw-alias-label-tertiary,#6b6b6b)}
.dsl-pane-warn-acts{display:flex;gap:7px;margin-top:3px}

.dsl-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(148px,1fr));gap:12px;align-content:start}
.dsl-card{display:flex;flex-direction:column;padding:0;border:1px solid var(--dsw-alias-border-l1,rgba(0,0,0,.12));
  border-radius:10px;background:var(--dsw-alias-bg-layer-1,#fff);cursor:pointer;text-align:left;font:inherit;
  color:inherit;overflow:hidden;min-width:0}
.dsl-card:hover{border-color:var(--dsw-alias-border-l2,rgba(0,0,0,.2))}
.dsl-card[data-picked="true"]{border-color:var(--dsw-alias-brand-primary,#1f6feb);box-shadow:0 0 0 1px var(--dsw-alias-brand-primary,#1f6feb)}
.dsl-card[data-cursor="true"]{border-color:var(--dsw-alias-brand-primary,#1f6feb)}
.dsl-card-media{position:relative;aspect-ratio:4/3;background:var(--dsw-alias-skeleton,rgba(0,0,0,.06));
  display:flex;align-items:center;justify-content:center;overflow:hidden;color:var(--dsw-alias-label-tertiary,#6b6b6b)}
.dsl-card-media img,.dsl-card-media video{width:100%;height:100%;object-fit:cover;display:block}
.dsl-card-media-icon{display:flex}
.dsl-card-badge{position:absolute;left:6px;top:6px;padding:1px 6px;border-radius:5px;font-size:11px;line-height:17px;
  color:#fff;background:rgba(0,0,0,.62);letter-spacing:.02em}
.dsl-card-dur{position:absolute;right:6px;bottom:6px;padding:1px 6px;border-radius:5px;font-size:11px;line-height:17px;
  color:#fff;background:rgba(0,0,0,.62);font-variant-numeric:tabular-nums}
.dsl-card-play{position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);display:flex;color:#fff;
  filter:drop-shadow(0 1px 4px rgba(0,0,0,.5))}
.dsl-card-body{padding:7px 9px 9px;display:flex;flex-direction:column;gap:3px;min-width:0}
.dsl-card-name{font-size:12.5px;line-height:17px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.dsl-card-meta{font-size:11.5px;line-height:16px;color:var(--dsw-alias-label-tertiary,#6b6b6b);
  overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-variant-numeric:tabular-nums}
.dsl-card-tags{display:flex;flex-wrap:wrap;gap:4px;margin-top:2px}
.dsl-pill{display:inline-flex;align-items:center;max-width:110px;padding:0 6px;border-radius:5px;font-size:11px;line-height:17px;
  background:var(--dsw-alias-bg-layer-2,rgba(0,0,0,.05));color:var(--dsw-alias-label-secondary,#3d3d3d);
  overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.dsl-pill-hash{color:var(--dsw-alias-label-tertiary,#6b6b6b);margin-right:1px}

/* 列表视图 */
.dsl-list{width:100%;border-collapse:collapse;table-layout:fixed}
.dsl-list th{text-align:left;font-size:11.5px;font-weight:400;color:var(--dsw-alias-label-tertiary,#6b6b6b);
  padding:0 8px 6px;border-bottom:1px solid var(--dsw-alias-border-l1,rgba(0,0,0,.12));white-space:nowrap}
.dsl-list th:first-child,.dsl-list td:first-child{padding-left:0}
.dsl-list td{padding:0 8px;border-bottom:1px solid var(--dsw-alias-border-l1,rgba(0,0,0,.07));
  font-size:12.5px;height:34px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;
  color:var(--dsw-alias-label-secondary,#3d3d3d)}
.dsl-list tbody tr{cursor:pointer}
.dsl-list tbody tr:hover td{background:var(--dsw-alias-interactive-bg-hover,rgba(0,0,0,.04))}
.dsl-list tbody tr[data-picked="true"] td{background:var(--dsw-alias-interactive-bg-hover,rgba(31,111,235,.09))}
.dsl-list-name{display:flex;align-items:center;gap:7px;min-width:0;color:var(--dsw-alias-label-primary,#1a1a1a)}
.dsl-list-name span{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.dsl-list-kind{display:flex;align-items:center;gap:5px}
.dsl-list-num{font-variant-numeric:tabular-nums}
.dsl-list-tags{display:flex;gap:4px;overflow:hidden}

/* 空态 / 拖拽 / 批量条 */
.dsl-empty{display:flex;flex-direction:column;align-items:center;gap:6px;padding:56px 24px;text-align:center}
.dsl-empty-title{font-size:14px;font-weight:500}
.dsl-empty-hint{font-size:12.5px;color:var(--dsw-alias-label-tertiary,#6b6b6b);max-width:440px;line-height:19px}
.dsl-drop{position:absolute;inset:8px;z-index:50;display:flex;align-items:center;justify-content:center;
  border:1px dashed var(--dsw-alias-brand-primary,#1f6feb);border-radius:12px;
  background:var(--dsw-alias-interactive-bg-hover,rgba(31,111,235,.08));color:var(--dsw-alias-brand-primary,#1f6feb);
  font-size:13px;pointer-events:none}
.dsl-batch{position:absolute;left:50%;bottom:18px;transform:translateX(-50%);z-index:30;display:flex;align-items:center;gap:8px;
  padding:6px 8px 6px 12px;border:1px solid var(--dsw-alias-border-l2,rgba(0,0,0,.18));border-radius:10px;
  background:var(--dsw-alias-bg-layer-1,#fff);box-shadow:0 8px 26px rgba(0,0,0,.16);max-width:calc(100% - 32px)}
.dsl-batch-n{font-size:12.5px;color:var(--dsw-alias-label-secondary,#3d3d3d);white-space:nowrap}
.dsl-batch input{width:130px;height:24px;border:1px solid var(--dsw-alias-border-l1,rgba(0,0,0,.12));border-radius:6px;
  background:none;font:inherit;font-size:12.5px;padding:0 7px;outline:0;color:inherit}
.dsl-batch input:focus{border-color:var(--dsw-alias-brand-primary,#1f6feb)}
.dsl-more{display:flex;justify-content:center;padding:16px 0 4px}
.dsl-note-line{display:flex;align-items:center;gap:8px;font-size:12px;color:var(--dsw-alias-label-tertiary,#6b6b6b);padding:6px 0 0}
.dsl-warn{color:var(--dsw-alias-label-warning,#b06a00)}

/* 导入面板 */
.dsl-import{border-bottom:1px solid var(--dsw-alias-border-l1,rgba(0,0,0,.12));padding:12px 16px 14px;
  background:var(--dsw-alias-bg-layer-2,rgba(0,0,0,.03))}
.dsl-import-title{display:flex;align-items:center;gap:8px;font-size:13px;font-weight:500}
.dsl-import-hint{font-size:12px;color:var(--dsw-alias-label-tertiary,#6b6b6b);line-height:18px;margin:3px 0 9px;max-width:640px}
.dsl-import-bar{display:flex;align-items:center;gap:8px;flex-wrap:wrap}
.dsl-import-bar input{flex:1 1 260px;min-width:160px;height:26px;border:1px solid var(--dsw-alias-border-l1,rgba(0,0,0,.12));
  border-radius:6px;background:none;font:inherit;font-size:13px;padding:0 8px;outline:0;color:inherit}
.dsl-import-bar input:focus{border-color:var(--dsw-alias-brand-primary,#1f6feb)}
.dsl-import-list{max-height:240px;overflow:auto;margin-top:10px;border:1px solid var(--dsw-alias-border-l1,rgba(0,0,0,.12));
  border-radius:8px;background:var(--dsw-alias-bg-layer-1,#fff)}
.dsl-import-item{display:flex;align-items:center;gap:8px;padding:0 9px;height:30px;border-bottom:1px solid var(--dsw-alias-border-l1,rgba(0,0,0,.06))}
.dsl-import-item:last-child{border-bottom:0}
.dsl-import-item input[type="checkbox"]{margin:0;accent-color:var(--dsw-alias-brand-primary,#1f6feb)}
.dsl-import-name{flex:1 1 auto;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:12.5px}
.dsl-import-size{font-size:12px;color:var(--dsw-alias-label-tertiary,#6b6b6b);font-variant-numeric:tabular-nums}
.dsl-import-foot{display:flex;align-items:center;gap:8px;margin-top:10px;flex-wrap:wrap}

/* 放大卡片里还活着的两条：
   - .dsl-dmedia-text：右栏的 Markdown / 代码回退渲染仍用它（宿主没给
     MarkdownText / CodeBlock 时）。
   - .dsl-dbar-page：右栏头部的「上一项 / 下一项」翻页器还用它。 */
.dsl-dbar-page{display:flex;align-items:center;gap:2px;font-size:12px;color:var(--dsw-alias-label-tertiary,#6b6b6b);
  font-variant-numeric:tabular-nums;white-space:nowrap}
.dsl-dmedia-text{width:100%;height:100%;overflow:auto;background:var(--dsw-alias-bg-layer-1,#fff);border-radius:8px;
  padding:14px 16px}
/* 第一列按内容自适应，不写死 64px：「绝对路径」是四个字，64px 装不下会被挤到
   和值贴在一起（截图上看着像没间距）。max-content + 最小值，两种长度都稳。 */
.dsl-fields{display:grid;grid-template-columns:max-content minmax(0,1fr);gap:6px 14px;margin:0 0 4px;font-size:12.5px;align-items:baseline}
.dsl-fields dt{color:var(--dsw-alias-label-tertiary,#6b6b6b)}
.dsl-fields dd{margin:0;min-width:0;overflow-wrap:anywhere;color:var(--dsw-alias-label-secondary,#3d3d3d)}
.dsl-sect{margin-top:18px;padding-top:14px;border-top:1px solid var(--dsw-alias-border-l1,rgba(0,0,0,.09))}
.dsl-sect:first-of-type{border-top:0;padding-top:0;margin-top:14px}
.dsl-sect-title{font-size:12px;color:var(--dsw-alias-label-tertiary,#6b6b6b);margin-bottom:7px}
.dsl-actions{display:flex;flex-direction:column;gap:2px;margin-top:6px}
.dsl-taglist{display:flex;flex-wrap:wrap;gap:5px;margin-bottom:7px}
.dsl-tagpill{display:inline-flex;align-items:center;gap:3px;padding:0 4px 0 8px;border-radius:6px;font-size:12px;line-height:21px;
  background:var(--dsw-alias-bg-layer-2,rgba(0,0,0,.05))}
.dsl-tagpill button{display:flex;padding:0;border:0;border-radius:4px;background:none;cursor:pointer;
  color:var(--dsw-alias-label-tertiary,#6b6b6b)}
.dsl-tagpill button:hover{color:var(--dsw-alias-label-primary,#1a1a1a)}
.dsl-taginput{display:flex;align-items:center;gap:6px;flex:1 1 auto;min-width:100px;height:24px;padding:0 7px;
  border:1px solid var(--dsw-alias-border-l1,rgba(0,0,0,.12));border-radius:6px}
.dsl-taginput:focus-within{border-color:var(--dsw-alias-brand-primary,#1f6feb)}
.dsl-taginput input{flex:1;min-width:0;border:0;outline:0;background:none;font:inherit;font-size:12.5px;color:inherit;padding:0}
.dsl-notearea{width:100%;min-height:76px;resize:vertical;border:1px solid var(--dsw-alias-border-l1,rgba(0,0,0,.12));
  border-radius:8px;background:none;font:inherit;font-size:12.5px;line-height:19px;padding:7px 9px;outline:0;color:inherit}
.dsl-notearea:focus{border-color:var(--dsw-alias-brand-primary,#1f6feb)}
.dsl-savebar{display:flex;align-items:center;gap:8px;margin-top:8px}
`;

        // ---- 小工具
        const UNITS = ['B', 'KB', 'MB', 'GB', 'TB'];
        function humanSize(bytes) {
            const n = Number(bytes);
            if (!Number.isFinite(n) || n < 0) return '—';
            if (n < 1024) return `${Math.round(n)} B`;
            let value = n;
            let unit = 0;
            while (value >= 1024 && unit < UNITS.length - 1) {
                value /= 1024;
                unit += 1;
            }
            const rounded = value >= 100 ? Math.round(value) : Math.round(value * 10) / 10;
            return `${rounded} ${UNITS[unit]}`;
        }

        function humanTime(ms) {
            const n = Number(ms);
            if (!Number.isFinite(n) || n <= 0) return '—';
            const d = new Date(n);
            const p = (value) => String(value).padStart(2, '0');
            return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}`;
        }

        function humanDuration(ms) {
            const total = Math.max(0, Math.round(Number(ms) / 1000));
            const m = Math.floor(total / 60);
            const s = total % 60;
            return `${m}:${String(s).padStart(2, '0')}`;
        }

        /** 标签串 → 数组：中文/英文分隔符都收，去空去重。 */
        function parseTags(value) {
            return [...new Set(String(value ?? '')
                .split(/[,，、;；\n]/u)
                .map((part) => part.trim())
                .filter((part) => part !== ''))];
        }

        /** 相对路径 → 查询串。`URLSearchParams` 会把 `/` 编成 %2F，服务端再解回来。 */
        function fileQuery(relPath) {
            return new URLSearchParams({ path: relPath }).toString();
        }
        const fileUrl = (relPath) => `${API}/file?${fileQuery(relPath)}`;
        const downloadUrl = (relPath) => `${API}/file?${fileQuery(relPath)}&download=1`;

        async function callApi(path, options) {
            const init = { method: options?.method ?? 'GET', headers: {} };
            if (options?.raw !== undefined) {
                // 上传走原始字节流：套 JSON 就会先把整个文件读进内存再 stringify 一遍。
                init.body = options.raw;
            } else if (options?.body !== undefined) {
                init.headers['content-type'] = 'application/json';
                init.body = JSON.stringify(options.body);
            }
            const response = await fetch(`${API}${path}`, init);
            let payload = null;
            try {
                payload = await response.json();
            } catch {
                payload = null;
            }
            if (!response.ok) {
                throw Object.assign(new Error(payload?.error?.message ?? `HTTP ${response.status}`), {
                    code: payload?.error?.code,
                    status: response.status,
                });
            }
            return payload;
        }

        /** 复制到剪贴板；环境不支持时返回 false，不抛。 */
        async function copyText(value) {
            try {
                const clipboard = globalThis.navigator?.clipboard;
                if (clipboard === undefined || clipboard === null) return false;
                await clipboard.writeText(value);
                return true;
            } catch {
                return false;
            }
        }

        /** ref 取节点并聚焦。测试替身上没有 `focus`，所以必须先问一句。 */
        function focusNode(ref) {
            const node = ref?.current;
            if (node !== null && node !== undefined && typeof node.focus === 'function') node.focus();
        }

        function parentPathOf(relPath) {
            const cut = relPath.lastIndexOf('/');
            return cut === -1 ? '' : relPath.slice(0, cut);
        }

        /** `图片/封面` → [{ relPath:'图片', name:'图片' }, { relPath:'图片/封面', name:'封面' }] */
        function pathCrumbs(relPath) {
            const out = [];
            let acc = '';
            for (const part of relPath.split('/')) {
                if (part === '') continue;
                acc = acc === '' ? part : `${acc}/${part}`;
                out.push({ relPath: acc, name: part });
            }
            return out;
        }

        function originOf(relPath) {
            const cut = relPath.lastIndexOf('/');
            return cut === -1 ? '' : relPath.slice(0, cut);
        }

        /**
         * 媒体元信息备忘录。
         *
         * 分辨率与时长**在客户端探测**，不在宿主读文件头：图片挂上之后
         * `naturalWidth/naturalHeight` 就是精确值，视频/音频的 `duration` 浏览器
         * 也给得出 —— 宿主那份实现只会得到同样的数字，却要多一套读文件头的代码与
         * 一份可能过期的备忘录。键里带 `mtimeMs|size`，文件一动就重新探测。
         */
        const MEDIA_MEMO = new Map();
        const mediaKey = (item) => `${item.relPath}|${item.mtimeMs}|${item.size}`;

        // ---- 侧边栏图标
        function Icon() {
            return h('span', { style: { display: 'inline-flex' } }, h(Glyph, { name: 'archive', size: 16 }));
        }

        // ---- 放大卡片
        const PREVIEW_MAX_BYTES = 512 * 1024;

        /**
         * 宿主没有 `facets` 能力时的占位：形状必须与真响应一致，否则渲染处要写两套判空。
         * 计数全 0 会让 chip 行的"当前范围 0 项"也归零 —— 那是对的：拿不到计数时
         * 就不该假装这个范围是空的，面板另有一条"连不上宿主"的提示在管这件事。
         */
        const EMPTY_FACETS = {
            scope: '',
            parent: null,
            total: 0,
            whole: 0,
            kinds: [],
            tags: [],
            folders: [],
            truncatedTags: false,
            truncatedFolders: false,
        };

        // ---- 目录树
        //
        // 树的形状由 `/tree` 给的是**扁平列表**（每条带 relPath 与 parent），
        // 这里在客户端拼成父子关系。理由：宿主那边的 `folders` 数组本来就是
        // 扁平的（每条自带 relPath，父目录靠前缀推），在客户端建树只要一遍
        // Map；让宿主改成嵌套结构反而要在两处（`/tree` 与 `/facets`）保持一致。
        //
        // 展开状态存在组件自己的 `useState` 里，键是目录 relPath。**不进 URL
        // 也不进 localStorage**：它是"这一屏怎么摆"，不是"我在看什么"。
        // 存进持久状态的后果是下次打开还展开着一堆与当前筛选无关的目录。
        function Rail({ ctx, t }) {
            const {
                tree, facets, scope, kind, query, recentDays,
                onScope, onKind, onQuery, onRecent, onCollapseTree, collapseTree,
            } = ctx;
            const [open, setOpen] = useState(() => new Set(['']));

            // 换筛选范围就把新范围这条链展开：否则点进一个子目录，它在树里是收着的，
            // 左边看不出"我在哪"，而面包屑又在头部，视线要来回扫两处。
            useEffect(() => {
                if (scope === '') return undefined;
                setOpen((prev) => {
                    if (prev.has(scope)) return prev;
                    const next = new Set(prev);
                    let at = scope;
                    while (at !== '') {
                        next.add(at);
                        at = at.slice(0, Math.max(0, at.lastIndexOf('/')));
                    }
                    return next;
                });
                return undefined;
            }, [scope]);

            // 扁平 → 树。只保留当前 scope 的祖先链上那些**真的存在**的目录，
            // 不给不存在的中间层造占位节点 —— 树的深度必须与资料库里实际的
            // 目录结构一致，否则会看到一层永远点不动的空节点。
            const byParent = new Map();
            for (const folder of tree.folders ?? []) {
                if (folder.relPath === '') continue;
                const list = byParent.get(folder.parent ?? '');
                if (list === undefined) byParent.set(folder.parent ?? '', [folder]);
                else list.push(folder);
            }
            const visible = new Set();
            for (const folder of tree.folders ?? []) {
                let at = folder.relPath;
                while (at !== '') {
                    visible.add(at);
                    at = at.slice(0, Math.max(0, at.lastIndexOf('/')));
                }
            }

            const renderRow = (folder, depth) => {
                if (!visible.has(folder.relPath)) return null;
                const kids = (byParent.get(folder.relPath) ?? []).filter((kid) => visible.has(kid.relPath));
                const isOpen = open.has(folder.relPath);
                return [
                    h('div', {
                        className: 'dsl-rail-row',
                        key: `r-${folder.relPath}`,
                        style: { paddingLeft: `${depth * 13}px` },
                    },
                        h('button', {
                            className: 'dsl-rail-twist',
                            'aria-label': isOpen ? t('railCollapseFolders') : t('railExpandFolders'),
                            'aria-expanded': isOpen ? 'true' : 'false',
                            onClick: () => setOpen((prev) => {
                                const next = new Set(prev);
                                if (next.has(folder.relPath)) next.delete(folder.relPath);
                                else next.add(folder.relPath);
                                return next;
                            }),
                        }, kids.length === 0
                            ? null
                            : h(Glyph, { name: isOpen ? 'chevronDown' : 'chevronRight', size: 11 })),
                        h('button', {
                            className: 'dsl-rail-item',
                            'data-on': scope === folder.relPath ? 'true' : 'false',
                            onClick: () => onScope(scope === folder.relPath ? '' : folder.relPath),
                        },
                            h(Glyph, { name: 'folder', size: 13 }),
                            h('span', null, folder.name),
                            h('span', { className: 'dsl-rail-item-n' }, String(folder.total)))),
                    isOpen ? kids.map((kid) => renderRow(kid, depth + 1)) : null,
                ];
            };

            // 「按类型」直接用 `/facets` 的计数，不再单独取 —— 同一个数字从两个
            // 端点来两次，两处不一致时（扫描与检索的缓存不同步）左栏与头部
            // chip 会显示不同的数，而用户没理由知道该信哪个。
            const kinds = (facets?.kinds ?? []).filter((entry) => entry.count > 0);
            const recentCut = Date.now() - 7 * 24 * 3600 * 1000;
            const recent = (tree.recent ?? []).filter((item) => item.mtimeMs >= recentCut).length;

            return h('div', { className: 'dsl-rail' },
                h('div', { className: 'dsl-rail-search' },
                    h(Glyph, { name: 'search', size: 13 }),
                    h('input', {
                        value: query,
                        placeholder: t('railSearch'),
                        'aria-label': t('railSearch'),
                        onChange: (event) => onQuery(event.target.value),
                    }),
                    query === '' ? null : h('button', {
                        className: 'dsl-search-clear',
                        'aria-label': t('clearSearch'),
                        onClick: () => onQuery(''),
                    }, h(Glyph, { name: 'close', size: 11 }))),
                h('div', { className: 'dsl-rail-sec' },
                    h('button', {
                        className: 'dsl-rail-item',
                        'data-on': scope === '' && kind === '' && query === '' && recentDays === 0 ? 'true' : 'false',
                        onClick: () => onScope(''),
                    },
                        h(Glyph, { name: 'archive', size: 13 }),
                        h('span', null, t('railAll')),
                        h('span', { className: 'dsl-rail-item-n' }, String(tree.total ?? 0)))),
                h('div', { className: 'dsl-rail-sec' },
                    h('div', { className: 'dsl-rail-sec-title' }, t('railByKind')),
                    h('button', {
                        className: 'dsl-rail-item',
                        'data-on': recentDays > 0 ? 'true' : 'false',
                        onClick: () => onRecent(recentDays > 0 ? 0 : 7),
                    },
                        h(Glyph, { name: 'clock', size: 13 }),
                        h('span', null, t('railRecent')),
                        h('span', { className: 'dsl-rail-item-n' }, String(recent))),
                    kinds.map((entry) => h('button', {
                        className: 'dsl-rail-item',
                        'data-on': kind === entry.kind ? 'true' : 'false',
                        key: entry.kind,
                        onClick: () => onKind(kind === entry.kind ? '' : entry.kind),
                    },
                        h(Glyph, { name: kindMeta(entry.kind).icon, size: 13 }),
                        h('span', null, t(kindMeta(entry.kind).key)),
                        h('span', { className: 'dsl-rail-item-n' }, String(entry.count))))),
                h('div', { className: 'dsl-rail-sec' },
                    h('div', { className: 'dsl-rail-sec-title' },
                        t('railFolders'),
                        h('button', {
                            'aria-label': collapseTree ? t('railExpandFolders') : t('railCollapseFolders'),
                            onClick: onCollapseTree,
                        }, h(Glyph, { name: collapseTree ? 'chevronRight' : 'chevronDown', size: 12 })))),
                collapseTree ? null : h('div', { className: 'dsl-rail-tree' },
                    (tree.folders ?? []).length <= 1
                        ? h('div', { className: 'dsl-rail-empty' }, t('railNoFolders'))
                        : (byParent.get('') ?? []).map((folder) => renderRow(folder, 0))));
        }

        // ---- 右栏：内容预览
        //
        // 这是三栏布局里**唯一新写的渲染器**。原来那份"放大卡片"把内容塞在一个
        // `max-width` 的居中块里，配一个「返回」按钮 —— 那是整页切换时代的形状。
        // 现在它常驻右栏，于是三件事必须改：
        //
        // 1. **没有返回按钮**。左边的列表一直在，关掉内容栏就是回到列表，
        //    而"返回"在这里会跟左栏的目录树抢同一个意思。
        // 2. **宽度是栏宽，不是固定值**。`max-width` 必须去掉：内容栏的宽度由
        //    布局决定，渲染器再压一个上限就变成了"右边留一条空白"。
        // 3. **失败要给出路**。读不出来时给「下载」和「在资源管理器中显示」，
        //    而不是一句"打不开" —— 用户的目标是看到内容，不是看报错。
        //
        // 四类内容各走各的渲染器：表格（`sheets`）、Word 正文（`blocks`）、
        // Markdown / 代码 / 纯文本（`text`）、媒体（交给 `<img>` / `<video>` /
        // `<audio>`）。**不共用一条路径** —— 一条路径意味着所有类型都长得
        // 一样，或者渲染器里堆满 `if (kind === ...)`。
        function Pane({ ctx, t }) {
            const {
                item, index, total, caps, media, onMedia, onClose, onStep, onToast, onChanged, hasDocument,
            } = ctx;
            const [tagDraft, setTagDraft] = useState('');
            const [note, setNote] = useState(item.note ?? '');
            const [saving, setSaving] = useState(false);
            // 文档解析结果。`phase` 只有四态：idle / loading / ready / failed。
            // **没有 'toolarge'**：截断是**正常结果**（`truncated: true` 跟着回来，
            // 界面上给一行小字说明），把它做成错误态会让"这份文档很长"看起来
            // 像"这份文档坏了"。
            const [doc, setDoc] = useState({ phase: 'idle' });

            useEffect(() => {
                setTagDraft('');
                setNote(item.note ?? '');
                setDoc({ phase: 'idle' });
            }, [item.relPath]);

            const key = mediaKey(item);
            const info = media[key] ?? MEDIA_MEMO.get(key);
            const ext = item.ext ?? '';
            const isText = item.text === true;
            // 媒体不查 `/document`：它只需要 `<img src>`，解析接口对它没有意义。
            const isMedia = item.kind === 'image' || item.kind === 'video' || item.kind === 'audio';

            // 文档类才请求 `/document`。宿主没这个能力时降级成"给不了内容"，
            // 而不是让它 404 —— 老内核上这一栏该显示提示，不该报错。
            const wantsDocument = !isMedia && (isText || ext === '.xlsx' || ext === '.csv' || ext === '.tsv' || ext === '.docx');
            useEffect(() => {
                if (!wantsDocument || !hasDocument) {
                    setDoc({ phase: 'idle' });
                    return undefined;
                }
                let alive = true;
                setDoc({ phase: 'loading' });
                const params = new URLSearchParams({ path: item.relPath });
                callApi(`/document?${params.toString()}`)
                    .then((data) => {
                        if (alive) setDoc({ phase: 'ready', data });
                    })
                    .catch((error) => {
                        // 状态码本身带信息：`code` 已经区分了加密 / 损坏 / 不支持，
                        // 提示文案必须跟着 code 变，不能统一一句"打不开"。
                        if (alive) setDoc({ phase: 'failed', code: error.code ?? 'UNKNOWN', message: error.message });
                    });
                return () => {
                    alive = false;
                };
            }, [item.relPath, wantsDocument, hasDocument]);

            const save = useCallback(async (patch) => {
                setSaving(true);
                try {
                    const updated = await callApi('/annotate', { method: 'POST', body: { path: item.relPath, ...patch } });
                    onToast(t('saved'));
                    onChanged(updated);
                } catch (error) {
                    onToast(`${t('failed')}: ${error.message}`);
                } finally {
                    setSaving(false);
                }
            }, [item.relPath]);

            const addTags = useCallback(async () => {
                const tags = parseTags(tagDraft);
                if (tags.length === 0) return;
                setTagDraft('');
                setSaving(true);
                try {
                    const updated = await callApi('/annotate', { method: 'POST', body: { path: item.relPath, tagsAdd: tags } });
                    onToast(t('saved'));
                    onChanged(updated);
                } catch (error) {
                    onToast(`${t('failed')}: ${error.message}`);
                } finally {
                    setSaving(false);
                }
            }, [item.relPath, tagDraft]);

            const removeTag = useCallback(async (tag) => {
                setSaving(true);
                try {
                    const updated = await callApi('/annotate', { method: 'POST', body: { path: item.relPath, tagsRemove: [tag] } });
                    onToast(t('saved'));
                    onChanged(updated);
                } catch (error) {
                    onToast(`${t('failed')}: ${error.message}`);
                } finally {
                    setSaving(false);
                }
            }, [item.relPath]);

            const doReveal = useCallback(async () => {
                try {
                    await callApi('/reveal', { method: 'POST', body: { path: item.relPath } });
                    onToast(t('revealDone'));
                } catch (error) {
                    onToast(`${t('revealFailed')}: ${error.message}`);
                }
            }, [item.relPath]);

            const doCopy = useCallback(async () => {
                const absolute = item.absolutePath ?? item.relPath;
                onToast(await copyText(absolute) ? t('copied') : t('copyFailed'));
            }, [item.absolutePath, item.relPath]);

            // ---- 内容区
            let content;
            if (isMedia) {
                if (item.kind === 'image') {
                    content = h('img', {
                        className: 'dsl-pane-img',
                        src: fileUrl(item.relPath),
                        alt: item.name,
                        onLoad: (event) => {
                            const target = event?.target;
                            if (target === null || target === undefined) return;
                            onMedia(key, { width: target.naturalWidth, height: target.naturalHeight });
                        },
                    });
                } else if (item.kind === 'video') {
                    content = h('video', {
                        className: 'dsl-pane-video',
                        src: fileUrl(item.relPath),
                        controls: true,
                        onLoadedMetadata: (event) => {
                            const target = event?.target;
                            if (target === null || target === undefined) return;
                            onMedia(key, { width: target.videoWidth, height: target.videoHeight, durationMs: target.duration * 1000 });
                        },
                    });
                } else {
                    content = h('audio', {
                        className: 'dsl-pane-audio',
                        src: fileUrl(item.relPath),
                        controls: true,
                        onLoadedMetadata: (event) => {
                            const target = event?.target;
                            if (target === null || target === undefined) return;
                            onMedia(key, { durationMs: target.duration * 1000 });
                        },
                    });
                }
            } else if (doc.phase === 'loading') {
                content = h('div', { className: 'dsl-pane-empty' }, h('div', { className: 'dsl-pane-empty-hint' }, t('previewLoading')));
            } else if (doc.phase === 'failed') {
                content = warnNode(doc.code, doc.message);
            } else if (doc.phase === 'ready') {
                content = renderDocument(doc.data);
            } else if (!hasDocument) {
                // 老内核：能给的只有"这是个二进制文件"，不给假内容。
                content = h('div', { className: 'dsl-pane-warn' },
                    h(Glyph, { name: 'info', size: 18 }),
                    h('div', { className: 'dsl-pane-warn-title' }, t('docUnsupported')),
                    h('div', { className: 'dsl-pane-warn-hint' }, t('docUnsupportedHint')),
                    warnActions());
            } else if (isText || ext === '.xlsx' || ext === '.csv' || ext === '.tsv' || ext === '.docx') {
                // 文档类但既没在请求、也没报错 —— 只可能是宿主没给 `document` 能力
                //（上面已处理）或 effect 还没跑完。不给空白页。
                content = h('div', { className: 'dsl-pane-empty' },
                    h('div', { className: 'dsl-pane-empty-hint' }, t('previewLoading')));
            } else {
                // 二进制附件（.doc / .xls / .pdf / .psd / 压缩包…）：明确说看不了，
                // **并给出路**。只说"看不了"而不给下载按钮的话，用户只能自己去
                // 资源管理器里翻 —— 而这一栏的全部意义就是"不用离开这个页面"。
                content = h('div', { className: 'dsl-pane-warn' },
                    h(Glyph, { name: kindMeta(item.kind).icon, size: 18 }),
                    h('div', { className: 'dsl-pane-warn-title' }, t('docUnsupported')),
                    h('div', { className: 'dsl-pane-warn-hint' }, t('docUnsupportedHint')),
                    warnActions());
            }

            /** 提示条底部的出路：下载 + 定位。 */
            function warnActions() {
                return h('div', { className: 'dsl-pane-warn-acts' },
                    h('a', { className: 'dsl-btn', href: downloadUrl(item.relPath), download: item.name },
                        h(Glyph, { name: 'download', size: 13 }), t('docDownloadInstead')),
                    caps.has('reveal') === true
                        ? h('button', { className: 'dsl-btn', onClick: doReveal },
                            h(Glyph, { name: 'folderOpen', size: 13 }), t('reveal'))
                        : null);
            }

            function warnNode(code, message) {
                // 提示分四种，因为**处置方式完全不同**：加密 → 去掉密码另存；
                // 损坏 → 重新导出；不支持 → 换格式或下载；太大 → 下载。
                // 合成一句"打不开"的话，用户不知道该做什么。
                const presets = {
                    ENCRYPTED: [t('docEncrypted'), t('docEncryptedHint')],
                    NOT_XLSX: [t('docCorrupt'), t('docCorruptHint')],
                    NOT_DOCX: [t('docCorrupt'), t('docCorruptHint')],
                    NOT_A_ZIP: [t('docCorrupt'), t('docCorruptHint')],
                    TRUNCATED: [t('docCorrupt'), t('docCorruptHint')],
                    CORRUPT: [t('docCorrupt'), t('docCorruptHint')],
                    UNSUPPORTED: [t('docUnsupported'), t('docUnsupportedHint')],
                    TOO_LARGE: [t('previewTooLarge'), t('previewTooLargeHint')],
                };
                const [title, hint] = presets[code] ?? [t('docLoadFailed'), message ?? t('docCorruptHint')];
                return h('div', { className: 'dsl-pane-warn' },
                    h(Glyph, { name: 'info', size: 18 }),
                    h('div', { className: 'dsl-pane-warn-title' }, title),
                    h('div', { className: 'dsl-pane-warn-hint' }, hint),
                    warnActions());
            }

            /** 按 `kind` 分派到四种渲染器。 */
            function renderDocument(data) {
                if (data.kind === 'sheet') {
                    const sheets = data.sheets ?? [];
                    if (sheets.length === 0) return h('div', { className: 'dsl-pane-empty-hint' }, t('sheetEmpty'));
                    return h('div', null,
                        sheets.map((sheet, at) => h('div', { className: 'dsl-sheet', key: `s${at}` },
                            sheets.length > 1 || sheet.name !== ''
                                ? h('div', { className: 'dsl-sheet-name' }, t(sheet.name === '' ? 'sheetSheetEmpty' : 'sheetSheet', sheet.name))
                                : null,
                            sheetTable(sheet.rows),
                            sheet.truncated === true ? h('div', { className: 'dsl-pane-note' }, t('sheetTruncated', (sheet.rows ?? []).length)) : null)),
                        data.truncated === true ? h('div', { className: 'dsl-pane-note' }, t('docTruncated')) : null);
                }
                if (data.kind === 'blocks') {
                    const blocks = data.blocks ?? [];
                    if (blocks.length === 0) return h('div', { className: 'dsl-pane-empty-hint' }, t('docEmpty'));
                    return h('div', null, h('div', { className: 'dsl-doc' }, blocks.map(docBlock)), data.truncated === true ? h('div', { className: 'dsl-pane-note' }, t('docTruncated')) : null);
                }
                if (data.kind === 'markdown') {
                    return h('div', { className: 'dsl-pane-md' }, MarkdownText === null
                        ? h('pre', { className: 'dsl-dmedia-text' }, h('code', null, data.text))
                        : h(MarkdownText, { text: data.text }));
                }
                if (data.kind === 'code' || data.kind === 'json') {
                    const lang = languageFor(item.relPath);
                    return h('div', null,
                        lang === undefined || CodeBlock === null
                            ? h('pre', { className: 'dsl-dmedia-text' }, h('code', null, data.text))
                            : h(CodeBlock, { code: data.text, lang, wrap: true }),
                        data.truncated === true ? h('div', { className: 'dsl-pane-note' }, t('docTruncated')) : null);
                }
                return h('pre', { className: 'dsl-dmedia-text' }, h('code', null, data.text ?? ''));
            }

            /** 一个 Word 块 → 元素。连续的列表项合并成一个 `<ul>`，否则一列单项目。 */
            function docBlock(block, at, blocks) {
                if (block.type === 'heading') {
                    const level = Math.min(6, Math.max(1, Number(block.level) || 1));
                    return h(`h${level}`, { key: `b${at}` }, block.text);
                }
                if (block.type === 'list') {
                    // 列表项**各自一行**（不合并成 <ul>）。合并需要一个"同层级才并"的
                    // 判断，而判断对了的收益只是少几个 <ul>，判断错了（把不同层级的
                    // 项并进同一个列表）会让缩进层级在视觉上直接消失 —— 而层级本身
                    // 就是 docx 里 `w:ilvl` 唯一传出来的信息。所以按"保真优先"处理：
                    // 一项一个 div，缩进用 `marginLeft` 表达。
                    return h('div', {
                        key: `b${at}`,
                        className: 'dsl-doc-li',
                        style: { marginLeft: `${(block.level ?? 0) * 16}px` },
                    },
                        h('span', { className: 'dsl-doc-bullet' }, '•'),
                        h('span', null, block.text));
                }
                if (block.type === 'table') {
                    return h('div', { key: `b${at}`, className: 'dsl-doc-table' }, sheetTable(block.rows));
                }
                return h('p', { key: `b${at}` }, block.text);
            }

            /** 行数组 → 表格。空表给一句话，不给一张只有边框的空壳。 */
            function sheetTable(rows) {
                if (!Array.isArray(rows) || rows.length === 0) {
                    return h('div', { className: 'dsl-pane-empty-hint' }, t('sheetEmpty'));
                }
                const width = rows.reduce((max, row) => Math.max(max, Array.isArray(row) ? row.length : 0), 0);
                const head = rows[0] ?? [];
                // 第一行当表头 —— xlsx 与 csv 在这件事上是一致的（第一行就是字段名），
                // 而 docx 的表格没有"表头"概念，当表头也只是让它更易读，不会错。
                return h('div', { className: 'dsl-tablewrap' },
                    h('table', { className: 'dsl-table' },
                        h('thead', null, h('tr', null, Array.from({ length: width }, (_, col) => h('th', { key: `h${col}` }, cellAt(head, col))))),
                        h('tbody', null, rows.slice(1).map((row, at) => h('tr', { key: `r${at}` },
                            Array.from({ length: width }, (_, col) => h('td', { key: `c${col}`, className: numericCell(row, col) ? 'dsl-table-num' : null }, cellAt(row, col))))))));
            }

            function cellAt(row, col) {
                const value = Array.isArray(row) ? row[col] : undefined;
                return value === undefined || value === '' ? '' : value;
            }

            function numericCell(row, col) {
                const value = Array.isArray(row) ? row[col] : undefined;
                return typeof value === 'string' && value !== '' && /^-?\d+(\.\d+)?$/u.test(value);
            }

            // ---- 元信息（可折叠）
            const meta = kindMeta(item.kind);
            const dims = info === undefined ? null : info;
            const fields = [
                [t('fieldKind'), t(meta.key)],
                [t('fieldSize'), humanSize(item.size)],
                [t('fieldTime'), humanTime(item.mtimeMs)],
            ];
            if (dims !== null && typeof dims.width === 'number' && dims.width > 0) {
                fields.push([t('fieldDims'), `${dims.width} × ${dims.height}`]);
            }
            fields.push([t('fieldRel'), item.relPath]);
            fields.push([t('fieldAbs'), item.absolutePath ?? '—']);
            if (item.source !== undefined && item.source !== null) {
                fields.push([t('fieldSource'), item.source.title ?? item.source.sessionId ?? item.source.projectPath ?? '—']);
            }
            const noteDirty = note !== (item.note ?? '');

            return h('div', { className: 'dsl-pane' },
                h('div', { className: 'dsl-pane-head' },
                    h(Glyph, { name: meta.icon, size: 14 }),
                    h('div', { className: 'dsl-pane-name', title: item.relPath }, item.name),
                    h('div', { className: 'dsl-spacer' }),
                    h('div', { className: 'dsl-dbar-page' },
                        h('button', {
                            className: 'dsl-iconbtn',
                            'aria-label': t('prevItem'),
                            disabled: index <= 0,
                            onClick: () => onStep(-1),
                        }, h(Glyph, { name: 'chevronLeft', size: 13 })),
                        h('span', null, t('page', index + 1, total)),
                        h('button', {
                            className: 'dsl-iconbtn',
                            'aria-label': t('nextItem'),
                            disabled: index >= total - 1,
                            onClick: () => onStep(1),
                        }, h(Glyph, { name: 'chevronRight', size: 13 }))),
                    h('button', {
                        className: 'dsl-iconbtn',
                        'aria-label': t('previewClose'),
                        title: t('previewClose'),
                        onClick: onClose,
                    }, h(Glyph, { name: 'close', size: 13 }))),
                h('div', { className: 'dsl-pane-body' }, content),
                h('div', { className: 'dsl-pane-meta' },
                    h('dl', { className: 'dsl-fields' },
                        fields.map(([label, value]) => [
                            h('dt', { key: `k-${label}` }, label),
                            h('dd', { key: `v-${label}` }, value),
                        ])),
                    h('div', { className: 'dsl-sect' },
                        h('div', { className: 'dsl-sect-title' }, t('tagsTitle')),
                        h('div', { className: 'dsl-taglist' },
                            (item.tags ?? []).map((tag) => h('span', { className: 'dsl-tagpill', key: tag },
                                h('span', { className: 'dsl-pill-hash' }, '#'),
                                h('span', null, tag),
                                h('button', {
                                    'aria-label': t('removeTag', tag),
                                    onClick: () => removeTag(tag),
                                }, h(Glyph, { name: 'close', size: 11 }))))),
                        h('div', { className: 'dsl-taginput' },
                            h(Glyph, { name: 'tag', size: 12 }),
                            h('input', {
                                value: tagDraft,
                                placeholder: t('tagPlaceholder'),
                                'aria-label': t('tagPlaceholder'),
                                onChange: (event) => setTagDraft(event.target.value),
                                onKeyDown: (event) => {
                                    if (event.key === 'Enter') {
                                        event.preventDefault?.();
                                        addTags();
                                    }
                                },
                            }))),
                    h('div', { className: 'dsl-sect' },
                        h('div', { className: 'dsl-sect-title' }, t('noteTitle')),
                        h('textarea', {
                            className: 'dsl-notearea',
                            value: note,
                            placeholder: t('notePlaceholder'),
                            'aria-label': t('noteTitle'),
                            onChange: (event) => setNote(event.target.value),
                            onKeyDown: (event) => {
                                if (event.key === 'Enter' && (event.ctrlKey === true || event.metaKey === true)) {
                                    event.preventDefault?.();
                                    save({ note });
                                }
                            },
                        }),
                        h('div', { className: 'dsl-savebar' },
                            h('button', {
                                className: 'dsl-btn dsl-btn-primary',
                                disabled: saving || !noteDirty,
                                'data-dirty': noteDirty ? 'true' : 'false',
                                'data-saving': saving ? 'true' : 'false',
                                onClick: () => save({ note }),
                            }, saving ? t('saving') : t('save')),
                            noteDirty ? h('span', null, t('unsaved')) : null)),
                    h('div', { className: 'dsl-sect' },
                        h('div', { className: 'dsl-sect-title' }, t('fieldAbs')),
                        h('div', { className: 'dsl-actions' },
                            h('button', { className: 'dsl-btn', onClick: doCopy },
                                h(Glyph, { name: 'copy', size: 13 }), t('copyPath')),
                            caps.has('reveal') === true
                                ? h('button', { className: 'dsl-btn', onClick: doReveal },
                                    h(Glyph, { name: 'folderOpen', size: 13 }), t('reveal'))
                                : null,
                            h('a', { className: 'dsl-btn', href: downloadUrl(item.relPath), download: item.name },
                                h(Glyph, { name: 'download', size: 13 }), t('download'))))),
            );
        }

        // ---- 主页面
        function Panel({ t }) {
            const [status, setStatus] = useState({ phase: 'loading' });
            const [listing, setListing] = useState({ phase: 'loading' });
            const [facetState, setFacetState] = useState({ phase: 'loading' });
            const [treeState, setTreeState] = useState({ phase: 'loading' });
            const [tick, setTick] = useState(0);

            const [query, setQuery] = useState('');
            const [kind, setKind] = useState('');
            const [tag, setTag] = useState('');
            const [scope, setScope] = useState('');
            // 「最近添加」是**独立状态**，不是搜索框里的魔法词。
            // 曾经想用 `@recent` 占位（省一个 state），那样用户真去搜 "@recent"
            // 就会命中一批莫名结果，而"我搜的"和"我点的筛选"在界面上必须分得开。
            const [recentDays, setRecentDays] = useState(0);
            const [sort, setSort] = useState('mtime');
            const [dirOrder, setDirOrder] = useState('desc');
            const [view, setView] = useState('grid');
            const [limit, setLimit] = useState(PAGE_SIZE);

            const [open, setOpen] = useState(null);
            const [cursor, setCursor] = useState('');
            const [picked, setPicked] = useState([]);
            const [batchTag, setBatchTag] = useState('');
            const [media, setMedia] = useState(() => ({ ...MEDIA_MEMO }));
            const [menu, setMenu] = useState(null);
            const [draft, setDraft] = useState(null);
            const [dragging, setDragging] = useState(false);
            const [busy, setBusy] = useState(false);
            const [toast, setToast] = useState(null);
            const [importer, setImporter] = useState(null);
            // 左栏目录树的收起状态。默认**展开**：三栏布局刚落地时目录树是左栏
            // 唯一的内容，收起来左栏就只剩三个快捷入口，等于白占 200px。
            // 用户手动收起之后由 CSS 的断点接手（窄窗口自动收起右栏）。
            const [collapseTree, setCollapseTree] = useState(false);

            const fileInput = useRef(null);
            const searchRef = useRef(null);
            const shellRef = useRef(null);
            const dragDepth = useRef(0);
            const anchorRef = useRef(null);
            // 「这一路见过的条目」旁路表，给翻页后仍能渲染选中项用。
            //
            // 为什么需要它：`items` 是**当前页**的数组，点"加载更多"就换一批。
            // 选中的路径如果不在新的一批里，`open` 还记着它，但按 `items` 找
            // 就找不到 —— 右栏于是空白，而用户什么都没做错。翻页时把上一批的
            // 条目留在这张表里，右栏就能继续显示。
            //
            // 为什么是 `useRef` 而不是 `useState`：它不需要触发重渲染，只是
            // 渲染时查一下的旁路数据。放进 state 会在每次翻页时多排一次渲染，
            // 而那次渲染什么都不会变。
            //
            // 上限：不设。库里最多 `maxFiles` 条（默认几万），每条几十字节，
            // 长期驻留的内存可以忽略；反过来"定期清空"会造出一个"翻了很多页
            // 之后选中的东西突然消失"的 bug。
            const lastKnown = useRef(new Map());

            const reload = useCallback(() => setTick((value) => value + 1), []);
            // 提示条的自增 id 用计数器而不是 Date.now()：同一毫秒里连着报两条
            // （"已导入 3 份" + "有 1 份没能导入"）会撞 key，第二条直接不显示。
            const toastSeq = useRef(0);
            const say = useCallback((text) => {
                toastSeq.current += 1;
                setToast({ text, id: toastSeq.current });
            }, []);

            // ---- /status
            useEffect(() => {
                let alive = true;
                setStatus((prev) => (prev.phase === 'ready' ? prev : { phase: 'loading' }));
                callApi('/status')
                    .then((data) => {
                        if (alive) setStatus({ phase: 'ready', data });
                    })
                    .catch((error) => {
                        if (alive) setStatus({ phase: 'error', message: error.message });
                    });
                return () => {
                    alive = false;
                };
            }, [tick]);

            const caps = useCaps(status.phase === 'ready' ? status.data.capabilities : undefined);

            // ---- /items
            useEffect(() => {
                let alive = true;
                setListing((prev) => (prev.phase === 'ready' ? prev : { phase: 'loading' }));
                const params = new URLSearchParams();
                // `scope` 永远显式给：空串就是"整库、递归"。这个键的存在性就是模式开关。
                params.set('scope', scope);
                if (query !== '') params.set('q', query);
                if (kind !== '') params.set('kind', kind);
                if (tag !== '') params.set('tag', tag);
                if (recentDays > 0) params.set('recent', String(recentDays));
                params.set('sort', sort);
                params.set('dir', dirOrder);
                params.set('limit', String(limit));
                callApi(`/items?${params.toString()}`)
                    .then((data) => {
                        if (alive) setListing({ phase: 'ready', data });
                    })
                    .catch((error) => {
                        if (alive) setListing({ phase: 'error', message: error.message });
                    });
                return () => {
                    alive = false;
                };
            }, [scope, query, kind, tag, recentDays, sort, dirOrder, limit, tick]);

            // ---- /facets（跟着 scope 走，进子目录后 chip 上的数字要跟着变）
            const hasFacets = caps.has('facets');
            useEffect(() => {
                // 宿主没声明 `facets` 能力就别去请求：这个端点是阶段 5 才加的，
                // 老内核上没有它，请求会 404。虽然下面 catch 里已经能兜住，
                // 但兜住的结果是"永远拿不到计数"——chip 行该退化成只有「全部」，
                // 而不是留一排没有数字的标签骗人。
                if (!hasFacets) {
                    setFacetState({ phase: 'ready', data: EMPTY_FACETS });
                    return undefined;
                }
                let alive = true;
                setFacetState((prev) => (prev.phase === 'ready' ? prev : { phase: 'loading' }));
                const params = new URLSearchParams();
                params.set('scope', scope);
                callApi(`/facets?${params.toString()}`)
                    .then((data) => {
                        if (alive) setFacetState({ phase: 'ready', data });
                    })
                    .catch(() => {
                        if (alive) setFacetState({ phase: 'failed' });
                    });
                return () => {
                    alive = false;
                };
            }, [scope, tick, hasFacets]);

            // ---- /tree（左栏目录树）
            //
            // 依赖里**没有 scope**：树的形状是整库的，不随筛选变。跟着 scope 重取
            // 的话，点一次目录就要重新拉一遍全树，而拉回来的结果一模一样 ——
            // 在慢盘上这一下会明显卡一下左栏。
            //
            // 依赖的是 `hasTree`（布尔）而不是 `caps`（Set）：`useCaps` 每次
            // 渲染都 `new Set(...)`，拿它当依赖等于"每渲染一次都重跑这个 effect"，
            // 于是 effect 里的 setState 又触发渲染 —— 一个自己喂自己的循环，
            // 表面看只是"多发了几次请求"，实际上它会把 settle 的重试次数吃光，
            // 让别处的异步状态永远收敛不了。
            const hasTree = caps.has('tree');
            useEffect(() => {
                if (!hasTree) {
                    setTreeState({ phase: 'ready', data: { folders: [], total: 0, recent: [] } });
                    return undefined;
                }
                let alive = true;
                setTreeState((prev) => (prev.phase === 'ready' ? prev : { phase: 'loading' }));
                callApi('/tree')
                    .then((data) => {
                        if (alive) setTreeState({ phase: 'ready', data });
                    })
                    .catch(() => {
                        if (alive) setTreeState({ phase: 'failed' });
                    });
                return () => {
                    alive = false;
                };
            }, [tick, hasTree]);

            // 换筛选条件就把页长收回第一页 —— 否则"筛选出 3 条"会摊在 5 页里。
            const resetPage = useCallback(() => setLimit(PAGE_SIZE), []);
            const pickKind = useCallback((value) => {
                setKind(value);
                resetPage();
            }, [resetPage]);
            const pickTag = useCallback((value) => {
                setTag(value);
                resetPage();
            }, [resetPage]);
            const pickScope = useCallback((value) => {
                setScope(value);
                setPicked([]);
                resetPage();
            }, [resetPage]);
            const onQueryChange = useCallback((value) => {
                setQuery(value);
                resetPage();
            }, [resetPage]);

            const items = listing.phase === 'ready' ? listing.data.items : [];
            const matched = listing.phase === 'ready' ? listing.data.matched : 0;
            const whole = facetState.phase === 'ready' ? facetState.data.whole : 0;
            const filtering = query !== '' || kind !== '' || tag !== '' || scope !== '' || recentDays > 0;
            const openIndex = items.findIndex((item) => item.relPath === open);

            const onMedia = useCallback((key, info) => {
                MEDIA_MEMO.set(key, info);
                setMedia((prev) => (prev[key] === undefined ? { ...prev, [key]: info } : prev));
            }, []);

            // ---- 选择
            const activate = useCallback((item, event) => {
                const additive = event !== undefined && (event.ctrlKey === true || event.metaKey === true);
                const ranged = event !== undefined && event.shiftKey === true;
                if (!additive && !ranged) {
                    setPicked([]);
                    setCursor(item.relPath);
                    setOpen(item.relPath);
                    return;
                }
                const index = items.findIndex((candidate) => candidate.relPath === item.relPath);
                setPicked((prev) => {
                    if (additive) {
                        return prev.includes(item.relPath)
                            ? prev.filter((value) => value !== item.relPath)
                            : [...prev, item.relPath];
                    }
                    const anchor = anchorRef.current;
                    if (anchor === null) {
                        return prev.includes(item.relPath) ? prev : [...prev, item.relPath];
                    }
                    const from = items.findIndex((candidate) => candidate.relPath === anchor);
                    if (from < 0 || index < 0) {
                        return prev.includes(item.relPath) ? prev : [...prev, item.relPath];
                    }
                    const lo = Math.min(from, index);
                    const hi = Math.max(from, index);
                    return [...new Set([...prev, ...items.slice(lo, hi + 1).map((candidate) => candidate.relPath)])];
                });
                // 锚点：Ctrl 点击与普通点击都更新，Shift 点击不更新 —— Shift 是
                // 「以锚点为起点扩展」的修饰键，改了锚点就没法连续扩展。
                // 并集语义（而不是替换）与参照实现一致：先 Ctrl 点两个零散项、
                // 再 Shift 点一段，期望是"零散的那几个 + 这一段"都在选中里。
                if (!ranged) anchorRef.current = item.relPath;
                setCursor(item.relPath);
            }, [items]);

            const moveCursor = useCallback((step) => {
                if (items.length === 0) return;
                const at = items.findIndex((item) => item.relPath === cursor);
                const next = at < 0 ? 0 : Math.min(items.length - 1, Math.max(0, at + step));
                setCursor(items[next].relPath);
            }, [items, cursor]);

            const stepDetail = useCallback((delta) => {
                if (open === null) return;
                const next = Math.min(items.length - 1, Math.max(0, openIndex + delta));
                if (items[next] !== undefined) setOpen(items[next].relPath);
            }, [open, openIndex, items]);

            // ---- 快捷键
            const onKeyDown = useCallback((event) => {
                const key = event?.key;
                if (key === undefined) return;
                if (key === 'Escape') {
                    if (open !== null) setOpen(null);
                    else if (menu !== null) setMenu(null);
                    else if (query !== '') onQueryChange('');
                    else if (picked.length > 0) setPicked([]);
                    return;
                }
                if (key === '/') {
                    event.preventDefault?.();
                    focusNode(searchRef);
                    return;
                }
                if (key === 'ArrowLeft' || key === 'ArrowLeft'.toLowerCase() || key === 'k') {
                    if (open !== null) stepDetail(-1); else moveCursor(-1);
                    return;
                }
                if (key === 'ArrowRight' || key === 'ArrowRight'.toLowerCase() || key === 'j') {
                    if (open !== null) stepDetail(1); else moveCursor(1);
                    return;
                }
                if (key === 'Enter' && open === null && cursor !== '') setOpen(cursor);
            }, [open, menu, query, picked.length, cursor, stepDetail, moveCursor, onQueryChange]);

            // 容器自己拿焦点，`/` 与方向键才有人接。依赖带上 `open`：列表与放大卡片
            // 是两个不同的根节点，切换后必须重新拿一次焦点。
            useEffect(() => {
                const node = shellRef.current;
                if (node !== null && node !== undefined && typeof node.focus === 'function') {
                    try {
                        node.focus({ preventScroll: true });
                    } catch {
                        node.focus();
                    }
                }
            }, [open]);

            // ---- 标注（详情里改了标签/备注之后，让列表与 chip 计数跟上）
            const patchItem = useCallback((updated) => {
                if (updated === undefined || updated === null) return;
                setListing((prev) => {
                    if (prev.phase !== 'ready') return prev;
                    return {
                        ...prev,
                        data: {
                            ...prev.data,
                            items: prev.data.items.map((item) => (item.relPath === updated.relPath ? { ...item, ...updated } : item)),
                        },
                    };
                });
                reload();
            }, [reload]);

            // ---- 入库
            const upload = useCallback(async (files, parent) => {
                const list = [...files];
                if (list.length === 0) return;
                setBusy(true);
                let done = 0;
                let skipped = 0;
                for (const file of list) {
                    try {
                        // 整库时不带 `parent` 这个键（而不是 `parent=`）：
                        // 与 `list`/`facets` 的口径统一 —— 用键是否存在区分
                        // "根" 与 "没指定"，避免出现 `?parent=` 这种既像给了
                        // 又像没给的中间态。
                        const query = new URLSearchParams({ name: file.name });
                        if (parent !== '' && parent !== undefined) query.set('parent', parent);
                        await callApi(`/upload?${query.toString()}`, { method: 'POST', raw: file });
                        done += 1;
                    } catch (error) {
                        if (error.code === 'TOO_LARGE') skipped += 1;
                        else say(`${t('uploadFailed')}: ${error.message}`);
                    }
                }
                setBusy(false);
                if (done > 0) say(t('dropped', done));
                if (skipped > 0) say(t('tooLarge', skipped));
                reload();
            }, [reload, say, t]);

            const onDrop = useCallback(async (event) => {
                event.preventDefault?.();
                dragDepth.current = 0;
                setDragging(false);
                await upload(event.dataTransfer?.files ?? [], scope);
            }, [upload, scope]);

            // ---- 新建
            const submitDraft = useCallback(async () => {
                if (draft === null) return;
                const name = draft.name.trim();
                if (name === '') return;
                setBusy(true);
                try {
                    // 文档补 .md、文件夹不补 —— 拿补过扩展名的名字去撞名才是对的，
                    // 否则"新建 说明"会在库里留下 说明 与 说明.md 两个。
                    const final = draft.mode === 'doc' && /\.[A-Za-z0-9]+$/u.test(name) === false ? `${name}.md` : name;
                    const result = draft.mode === 'folder'
                        ? await callApi('/mkdir', { method: 'POST', body: { parent: scope, name: final } })
                        : await callApi('/create', { method: 'POST', body: { parent: scope, name: final, text: '' } });
                    setDraft(null);
                    say(t('created'));
                    reload();
                    return result;
                } catch (error) {
                    if (error.code === 'INVALID_NAME') say(t('nameTaken'));
                    else say(`${t('failed')}: ${error.message}`);
                    return undefined;
                } finally {
                    setBusy(false);
                }
            }, [draft, scope, say, t, reload]);

            const doRescan = useCallback(async () => {
                setBusy(true);
                try {
                    const data = await callApi('/rescan', { method: 'POST' });
                    say(t('rescanDone', data.items, data.ms));
                    reload();
                } catch (error) {
                    say(`${t('failed')}: ${error.message}`);
                } finally {
                    setBusy(false);
                }
            }, [say, t, reload]);

            // ---- 批量打标
            const runBatch = useCallback(async (mode) => {
                const tags = parseTags(batchTag);
                if (tags.length === 0 || picked.length === 0) return;
                setBusy(true);
                try {
                    const patch = mode === 'remove' ? { tagsRemove: tags } : { tagsAdd: tags };
                    const result = await callApi('/annotate', { method: 'POST', body: { paths: picked, ...patch } });
                    setBatchTag('');
                    setPicked([]);
                    say(t('batchDone', result.items.length));
                    if (result.missing.length > 0) say(t('batchMissing', result.missing.length));
                    reload();
                } catch (error) {
                    say(`${t('failed')}: ${error.message}`);
                } finally {
                    setBusy(false);
                }
            }, [batchTag, picked, say, t, reload]);

            // ---- 目录导入
            const scanSource = useCallback(async () => {
                const source = (importer?.source ?? '').trim();
                if (source === '') return;
                setImporter((prev) => ({ ...prev, phase: 'scanning' }));
                try {
                    const data = await callApi(`/external?${new URLSearchParams({ dir: source }).toString()}`);
                    setImporter({
                        phase: 'listed',
                        source: data.source,
                        files: data.files,
                        chosen: data.files.map((file) => file.relPath),
                        message: '',
                    });
                } catch (error) {
                    setImporter((prev) => ({ ...prev, phase: 'error', message: error.message }));
                }
            }, [importer]);

            const runImport = useCallback(async () => {
                if (importer === null || importer.phase !== 'listed') return;
                const chosen = importer.files.filter((file) => importer.chosen.includes(file.relPath)).map((file) => file.relPath);
                if (chosen.length === 0) return;
                setBusy(true);
                try {
                    const data = await callApi('/import', { method: 'POST', body: { source: importer.source, entries: chosen, parent: scope } });
                    setImporter(null);
                    say(t('importDone', data.imported.length));
                    if (data.skipped.length > 0) say(t('importSkipped', data.skipped.length));
                    reload();
                } catch (error) {
                    say(`${t('failed')}: ${error.message}`);
                } finally {
                    setBusy(false);
                }
            }, [importer, scope, say, t, reload]);

            const toggleChosen = useCallback((relPath) => {
                setImporter((prev) => {
                    if (prev === null || prev.phase !== 'listed') return prev;
                    return {
                        ...prev,
                        chosen: prev.chosen.includes(relPath)
                            ? prev.chosen.filter((value) => value !== relPath)
                            : [...prev.chosen, relPath],
                    };
                });
            }, []);

            const chooseAll = useCallback((on) => {
                setImporter((prev) => {
                    if (prev === null || prev.phase !== 'listed') return prev;
                    return { ...prev, chosen: on ? prev.files.map((file) => file.relPath) : [] };
                });
            }, []);

            // ---- 渲染零件
            const can = (name) => caps.has(name);

            const chip = (key, label, count, on, onClick, extra) => h('button', {
                key,
                className: 'dsl-tab',
                'data-on': on === true ? 'true' : 'false',
                'aria-pressed': on === true ? 'true' : 'false',
                onClick,
            }, label, count === undefined ? null : h('span', { className: 'dsl-tab-n' }, String(count)), extra);

            const facets = facetState.phase === 'ready' ? facetState.data : null;
            const crumbs = pathCrumbs(scope);

            // ---- 空态
            let empty = null;
            if (listing.phase === 'ready' && items.length === 0) {
                if (status.phase === 'ready' && status.data.exists === false) {
                    empty = h('div', { className: 'dsl-empty' },
                        h('div', { className: 'dsl-empty-title' }, t('emptyRoot')),
                        h('div', { className: 'dsl-empty-hint' }, t('emptyRootHint')));
                } else if (filtering) {
                    empty = h('div', { className: 'dsl-empty' },
                        h('div', { className: 'dsl-empty-title' }, t('emptyFilter')),
                        h('div', { className: 'dsl-empty-hint' }, t('emptyFilterHint')));
                } else {
                    empty = h('div', { className: 'dsl-empty' },
                        h('div', { className: 'dsl-empty-title' }, t('emptyFolder')));
                }
            }

            const cardOf = (item) => {
                const meta = kindMeta(item.kind);
                const info = media[mediaKey(item)] ?? MEDIA_MEMO.get(mediaKey(item));
                const isPicked = picked.includes(item.relPath);
                const bits = [humanSize(item.size)];
                if (info !== undefined && info !== null && typeof info.width === 'number' && info.width > 0) {
                    bits.push(`${info.width}×${info.height}`);
                } else if (info !== undefined && info !== null && typeof info.durationMs === 'number' && Number.isFinite(info.durationMs)) {
                    bits.push(humanDuration(info.durationMs));
                }
                let mediaSlot;
                if (item.kind === 'image') {
                    mediaSlot = h('img', {
                        src: fileUrl(item.relPath),
                        alt: item.name,
                        loading: 'lazy',
                        onLoad: (event) => {
                            const target = event?.target;
                            if (target === null || target === undefined) return;
                            onMedia(mediaKey(item), { width: target.naturalWidth, height: target.naturalHeight });
                        },
                    });
                } else if (item.kind === 'video') {
                    mediaSlot = h('video', {
                        src: fileUrl(item.relPath),
                        muted: true,
                        preload: 'metadata',
                        onLoadedMetadata: (event) => {
                            const target = event?.target;
                            if (target === null || target === undefined) return;
                            onMedia(mediaKey(item), {
                                width: target.videoWidth,
                                height: target.videoHeight,
                                durationMs: target.duration * 1000,
                            });
                        },
                    });
                } else {
                    mediaSlot = h('div', { className: 'dsl-card-media-icon' }, h(Glyph, { name: meta.icon, size: 24 }));
                }
                const hasDuration = info !== undefined && info !== null
                    && typeof info.durationMs === 'number' && Number.isFinite(info.durationMs) && info.durationMs > 0;
                return h('button', {
                    className: 'dsl-card',
                    key: item.relPath,
                    'data-picked': isPicked ? 'true' : 'false',
                    'data-cursor': cursor === item.relPath ? 'true' : 'false',
                    onClick: (event) => activate(item, event),
                },
                    h('div', { className: 'dsl-card-media' },
                        mediaSlot,
                        h('span', { className: 'dsl-card-badge' }, t(meta.key)),
                        item.kind === 'video' ? h('span', { className: 'dsl-card-play' }, h(Glyph, { name: 'play', size: 26 })) : null,
                        hasDuration ? h('span', { className: 'dsl-card-dur' }, humanDuration(info.durationMs)) : null),
                    h('div', { className: 'dsl-card-body' },
                        h('div', { className: 'dsl-card-name', title: item.name }, item.name),
                        h('div', { className: 'dsl-card-meta' }, bits.join(' · ')),
                        (item.tags ?? []).length === 0 ? null : h('div', { className: 'dsl-card-tags' },
                            item.tags.slice(0, 4).map((value) => h('span', { className: 'dsl-pill', key: value }, value)),
                            item.tags.length > 4 ? h('span', { className: 'dsl-pill' }, `+${item.tags.length - 4}`) : null)));
            };

            const listOf = (item) => {
                const meta = kindMeta(item.kind);
                return h('tr', {
                    key: item.relPath,
                    'data-picked': picked.includes(item.relPath) ? 'true' : 'false',
                    onClick: (event) => activate(item, event),
                },
                    h('td', null, h('div', { className: 'dsl-list-name' },
                        h(Glyph, { name: meta.icon, size: 13 }),
                        h('span', { title: item.name }, item.name))),
                    h('td', null, h('div', { className: 'dsl-list-kind' }, t(meta.key))),
                    h('td', { className: 'dsl-list-num' }, humanSize(item.size)),
                    h('td', { className: 'dsl-list-num' }, humanTime(item.mtimeMs)),
                    h('td', null, h('div', { className: 'dsl-list-tags' },
                        (item.tags ?? []).slice(0, 3).map((value) => h('span', { className: 'dsl-pill', key: value }, value)))));
            };

            const body = listing.phase === 'loading' && items.length === 0
                ? h('div', { className: 'dsl-empty' }, h('div', { className: 'dsl-empty-hint' }, t('connecting')))
                : empty ?? (view === 'grid'
                    ? h('div', { className: 'dsl-grid' }, items.map(cardOf))
                    : h('table', { className: 'dsl-list' },
                        h('thead', null, h('tr', null,
                            h('th', null, t('colName')),
                            h('th', { style: { width: '92px' } }, t('colKind')),
                            h('th', { style: { width: '88px' } }, t('colSize')),
                            h('th', { style: { width: '136px' } }, t('colTime')),
                            h('th', { style: { width: '30%' } }, t('colTags')))),
                        h('tbody', null, items.map(listOf))));

            const more = listing.phase === 'ready' && items.length < matched
                ? h('div', { className: 'dsl-more' },
                    h('button', { className: 'dsl-btn', onClick: () => setLimit((value) => value + PAGE_SIZE) },
                        t('loadMore', Math.min(PAGE_SIZE, matched - items.length))))
                : null;

            const sortName = sort === 'name' ? t('sortByName') : sort === 'size' ? t('sortBySize') : t('sortByMtime');

            const sortMenu = menu === 'sort' ? h('div', { className: 'dsl-ddbox' },
                [['name', t('sortByName')], ['mtime', t('sortByMtime')], ['size', t('sortBySize')]].map(([value, label]) => h('button', {
                    key: value,
                    className: 'dsl-dditem',
                    'data-on': sort === value ? 'true' : 'false',
                    onClick: () => {
                        setSort(value);
                        setMenu(null);
                    },
                }, h('span', null, label), sort === value ? h('span', { className: 'dsl-dditem-icon' }, h(Glyph, { name: 'check', size: 12 })) : null)),
                h('div', { className: 'dsl-ddsep' }),
                h('button', {
                    className: 'dsl-dditem',
                    onClick: () => {
                        setDirOrder(dirOrder === 'asc' ? 'desc' : 'asc');
                        setMenu(null);
                    },
                }, h('span', null, dirOrder === 'asc' ? t('sortDesc') : t('sortAsc'))),
            ) : null;

            const newMenu = menu === 'new' ? h('div', { className: 'dsl-ddbox' },
                h('button', {
                    className: 'dsl-dditem',
                    onClick: () => {
                        setDraft({ mode: 'folder', name: '' });
                        setMenu(null);
                    },
                }, h(Glyph, { name: 'folder', size: 13 }), t('menuNewFolder')),
                h('button', {
                    className: 'dsl-dditem',
                    onClick: () => {
                        setDraft({ mode: 'doc', name: '' });
                        setMenu(null);
                    },
                }, h(Glyph, { name: 'doc', size: 13 }), t('menuNewDoc')),
            ) : null;

            const importMenu = menu === 'import' ? h('div', { className: 'dsl-ddbox' },
                h('button', {
                    className: 'dsl-dditem',
                    disabled: !can('upload'),
                    onClick: () => {
                        setMenu(null);
                        const node = fileInput.current;
                        if (node !== null && node !== undefined && typeof node.click === 'function') node.click();
                    },
                }, h(Glyph, { name: 'paperclip', size: 13 }), t('menuImportFiles')),
                h('button', {
                    className: 'dsl-dditem',
                    disabled: !can('external'),
                    onClick: () => {
                        setImporter({ phase: 'input', source: '', files: [], chosen: [], message: '' });
                        setMenu(null);
                    },
                }, h(Glyph, { name: 'folderOpen', size: 13 }), t('menuImportFolder')),
            ) : null;

            // 下拉菜单本身已经贴在自己的触发按钮下面（`.dsl-dd` 容器里），
            // 这里不需要也不该再包一层 —— 包一层就会跑到页面右上角去。
            const importPanel = importer === null ? null : h('div', { className: 'dsl-import' },
                h('div', { className: 'dsl-import-title' },
                    h(Glyph, { name: 'folderOpen', size: 14 }),
                    t('importTitle'),
                    h('div', { className: 'dsl-spacer' }),
                    h('button', {
                        className: 'dsl-iconbtn',
                        'aria-label': t('importClose'),
                        onClick: () => setImporter(null),
                    }, h(Glyph, { name: 'close', size: 13 }))),
                h('div', { className: 'dsl-import-hint' }, t('importHint')),
                h('div', { className: 'dsl-import-bar' },
                    h('input', {
                        value: importer.source,
                        placeholder: 'D:\\项目\\产出',
                        'aria-label': t('importTitle'),
                        onChange: (event) => setImporter((prev) => ({ ...prev, source: event.target.value })),
                        onKeyDown: (event) => {
                            if (event.key === 'Enter') scanSource();
                        },
                    }),
                    h('button', {
                        className: 'dsl-btn',
                        disabled: importer.phase === 'scanning',
                        onClick: scanSource,
                    }, importer.phase === 'scanning' ? t('importScanning') : t('importScan'))),
                importer.message !== '' ? h('div', { className: 'dsl-note-line dsl-warn' }, importer.message) : null,
                importer.phase === 'listed' && importer.files.length === 0
                    ? h('div', { className: 'dsl-note-line' }, t('importEmpty'))
                    : null,
                importer.phase === 'listed' && importer.files.length > 0
                    ? h('div', { className: 'dsl-import-list' },
                        importer.files.map((file) => h('label', { className: 'dsl-import-item', key: file.relPath },
                            h('input', {
                                type: 'checkbox',
                                checked: importer.chosen.includes(file.relPath),
                                onChange: () => toggleChosen(file.relPath),
                            }),
                            h('span', { className: 'dsl-import-name', title: file.relPath }, file.relPath),
                            h('span', { className: 'dsl-import-size' }, humanSize(file.size)))))
                    : null,
                importer.phase === 'listed' ? h('div', { className: 'dsl-import-foot' },
                    h('button', { className: 'dsl-btn', onClick: () => chooseAll(true) }, t('importPickAll')),
                    h('button', { className: 'dsl-btn', onClick: () => chooseAll(false) }, t('importPickNone')),
                    h('div', { className: 'dsl-spacer' }),
                    h('button', {
                        className: 'dsl-btn dsl-btn-primary',
                        disabled: busy || importer.chosen.length === 0,
                        onClick: runImport,
                    }, t('importDo', importer.chosen.length))) : null);

            const draftPanel = draft === null ? null : h('div', { className: 'dsl-import' },
                h('div', { className: 'dsl-import-title' },
                    h(Glyph, { name: draft.mode === 'folder' ? 'folder' : 'doc', size: 14 }),
                    draft.mode === 'folder' ? t('menuNewFolder') : t('menuNewDoc')),
                h('div', { className: 'dsl-import-bar' },
                    h('input', {
                        value: draft.name,
                        placeholder: draft.mode === 'folder' ? t('folderName') : '说明.md',
                        'aria-label': t('name'),
                        onChange: (event) => setDraft((prev) => ({ ...prev, name: event.target.value })),
                        onKeyDown: (event) => {
                            if (event.key === 'Enter') submitDraft();
                        },
                    }),
                    h('button', { className: 'dsl-btn dsl-btn-primary', disabled: busy, onClick: submitDraft }, t('create')),
                    h('button', { className: 'dsl-btn', onClick: () => setDraft(null) }, t('cancel'))));

            // ---- 头部
            const head = h('div', { className: 'dsl-head' },
                h('div', { className: 'dsl-bar' },
                    h('div', { className: 'dsl-title' },
                        h('span', { className: 'dsl-title-main' }, t('panel')),
                        StateDot === null ? null : h(StateDot, {
                            state: status.phase === 'ready' ? 'done' : status.phase === 'error' ? 'error' : 'pending',
                        }),
                        h('span', { className: 'dsl-count' },
                            listing.phase === 'ready'
                                ? (filtering ? t('matched', matched, whole) : t('total', matched))
                                : t('connecting'))),
                    crumbs.length === 0 ? null : h('div', { className: 'dsl-where' },
                        crumbs.map((crumb, at) => [
                            at === 0 ? null : h('span', { className: 'dsl-where-sep', key: `s${crumb.relPath}` }, '/'),
                            h('button', {
                                key: crumb.relPath,
                                className: 'dsl-where-link',
                                'data-on': at === crumbs.length - 1 ? 'true' : 'false',
                                onClick: () => pickScope(crumb.relPath),
                            }, crumb.name),
                        ])),
                    h('div', { className: 'dsl-spacer' }),
                    h('div', { className: 'dsl-search' },
                        h(Glyph, { name: 'search', size: 13 }),
                        h('input', {
                            ref: searchRef,
                            value: query,
                            placeholder: t('searchPlaceholder'),
                            'aria-label': t('searchPlaceholder'),
                            onChange: (event) => onQueryChange(event.target.value),
                        }),
                        query === '' ? null : h('button', {
                            className: 'dsl-search-clear',
                            'aria-label': t('clearSearch'),
                            onClick: () => onQueryChange(''),
                        }, h(Glyph, { name: 'close', size: 12 }))),
                    h('div', { className: 'dsl-tools' },
                        h('div', { className: 'dsl-dd' },
                            h('button', {
                                className: 'dsl-ddtoggle',
                                'aria-label': t('sortLabel'),
                                onClick: () => setMenu(menu === 'sort' ? null : 'sort'),
                            }, h('span', { className: 'dsl-ddtoggle-name' }, sortName), h(Glyph, { name: 'chevronDown', size: 12 })),
                            sortMenu),
                        h('button', {
                            className: 'dsl-iconbtn',
                            'aria-label': t('toggleSortDir'),
                            title: dirOrder === 'asc' ? t('sortAsc') : t('sortDesc'),
                            onClick: () => setDirOrder(dirOrder === 'asc' ? 'desc' : 'asc'),
                        }, h(Glyph, { name: dirOrder === 'asc' ? 'arrowUp' : 'arrowDown', size: 14 })),
                        h('button', {
                            className: 'dsl-iconbtn',
                            'aria-label': view === 'grid' ? t('viewList') : t('viewGrid'),
                            onClick: () => setView(view === 'grid' ? 'list' : 'grid'),
                        }, h(Glyph, { name: view === 'grid' ? 'list' : 'grid', size: 14 })),
                        h('div', { className: 'dsl-dd' },
                            h('button', {
                                className: 'dsl-iconbtn',
                                'aria-label': t('newDoc'),
                                disabled: !can('mkdir') || !can('create'),
                                onClick: () => setMenu(menu === 'new' ? null : 'new'),
                            }, h(Glyph, { name: 'plus', size: 14 })),
                            newMenu),
                        h('div', { className: 'dsl-dd' },
                            h('button', {
                                className: 'dsl-iconbtn',
                                'aria-label': t('menuImport'),
                                disabled: !can('upload') || !can('external'),
                                onClick: () => setMenu(menu === 'import' ? null : 'import'),
                            }, h(Glyph, { name: 'paperclip', size: 14 })),
                            importMenu),
                        h('button', {
                            className: 'dsl-iconbtn',
                            'aria-label': t('rescan'),
                            disabled: !can('rescan'),
                            onClick: doRescan,
                        }, h(Glyph, { name: 'refresh', size: 14 })))),
                h('div', { className: 'dsl-bar dsl-bar-chips' },
                    chip('all', t('allKinds'), facets === null ? undefined : facets.total, kind === '', () => pickKind('')),
                    (facets?.kinds ?? []).map((entry) => chip(`k-${entry.kind}`, t(kindMeta(entry.kind).key), entry.count, kind === entry.kind, () => pickKind(entry.kind))),
                    h('span', { className: 'dsl-sep' }),
                    facets !== null && facets.parent !== null
                        ? chip('up', t('upLevel'), undefined, false, () => pickScope(facets.parent))
                        : null,
                    chip('dirs', t('allFolders'), undefined, scope === '', () => pickScope('')),
                    (facets?.folders ?? []).map((entry) => chip(`d-${entry.relPath}`, entry.name, entry.total, scope === entry.relPath, () => pickScope(entry.relPath))),
                    (facets !== null && facets.folders.length === 0)
                        ? h('span', { className: 'dsl-chip-empty' }, t('noFolders'))
                        : null,
                    h('span', { className: 'dsl-sep' }),
                    (facets?.tags ?? []).map((entry) => chip(`t-${entry.tag}`, `#${entry.tag}`, entry.count, tag === entry.tag, () => pickTag(entry.tag))),
                    (facets !== null && facets.tags.length === 0)
                        ? h('span', { className: 'dsl-chip-empty' }, t('noTags'))
                        : null,
                    filtering ? h('button', { className: 'dsl-tab', onClick: () => {
                        onQueryChange('');
                        pickKind('');
                        pickTag('');
                    } }, t('clearFilters')) : null),
            );

            // 样式随组件树一起渲染，**两个分支都要挂**。
            //
            // 这是从参照实现（`h('style', null, CSS)`）抄来的关键一条：`client.js`
            // 是给宿主在浏览器里跑的模块，宿主不会"顺手"执行你写在模块作用域里的
            // 模板字符串。CSS 必须在元素树里出现，浏览器才会建样式表。
            // 之前 STYLE 定义了却从没渲染过 —— 真机上整个资料库是**完全无样式的裸
            // HTML**：两行表头塌成竖排、卡片没有网格、chip 变成一串带边框的按钮。
            // 契约测试查的是 className，全都对，所以一层测试都没发现。
            const styleNode = h('style', { 'data-dsl': 'library' }, STYLE);

            const toastNode = Toast === null ? null : h(Toast, {
                key: toast === null ? 'toast-idle' : `toast-${toast.id}`,
                text: toast === null ? '' : toast.text,
                holdMs: 2400,
                onDone: () => setToast(null),
            });

            // ---- 根：左树 + 中列表 + 右内容
            //
            // **不再有"整页切到详情"这个分支。** 之前是 `if (open !== null) return
            // <整页详情>`，点开一份资料时列表整个消失、左栏也没了，于是"边翻
            // 列表边看内容"这个最常见的动作做不了。现在左树与列表**常驻**，
            // 选中只决定右栏显示什么。
            //
            // 选中的条目来自 `items`（当前这一页的清单）。它可能因为翻页或筛选
            // 变化而不在 `items` 里 —— 那时**不清空右栏**，而是回退到"按路径
            // 在整库里找"。清空的话，用户点开一份资料之后手滑按了"加载更多"，
            // 右栏就突然空了，而清单里它明明还在。
            const offline = status.phase === 'error';
            const tree = treeState.phase === 'ready'
                ? treeState.data
                : { folders: [], total: 0, recent: [] };
            const hasDocument = caps.has('document');
            const selected = open === null
                ? null
                : (items.find((candidate) => candidate.relPath === open) ?? lastKnown.current.get(open) ?? null);
            // 每次渲染都把当前这一页记进旁路表（理由见 `lastKnown` 的声明处）。
            for (const item of items) lastKnown.current.set(item.relPath, item);

            return h('div', {
                className: 'dsl-root',
                ref: shellRef,
                tabIndex: 0,
                onKeyDown,
                onDragEnter: (event) => {
                    event.preventDefault?.();
                    dragDepth.current += 1;
                    setDragging(true);
                },
                onDragOver: (event) => event.preventDefault?.(),
                onDragLeave: (event) => {
                    event.preventDefault?.();
                    dragDepth.current -= 1;
                    if (dragDepth.current <= 0) setDragging(false);
                },
                onDrop,
            },
                styleNode,
                head,
                // 遮罩挂在根上（z-index 低于 `.dsl-ddbox`），点空白处收菜单；
                // 挂在 body 里的话表头那半屏点不到。
                menu === null ? null : h('div', { className: 'dsl-scrim', onClick: () => setMenu(null) }),
                importPanel,
                draftPanel,
                offline ? h('div', { className: 'dsl-empty' },
                    h('div', { className: 'dsl-empty-title' }, t('offline')),
                    h('div', { className: 'dsl-empty-hint' }, t('offlineHint')),
                    h('button', { className: 'dsl-btn', onClick: reload }, t('retry'))) : null,
                !offline ? h('div', { className: 'dsl-main' },
                    h(Rail, {
                        ctx: {
                            tree,
                            facets,
                            scope,
                            kind,
                            query,
                            recentDays,
                            collapseTree,
                            onScope: (value) => {
                                pickScope(value);
                                setRecentDays(0);
                            },
                            onKind: pickKind,
                            onQuery: onQueryChange,
                            onRecent: (days) => {
                                setRecentDays(days);
                                resetPage();
                            },
                            onCollapseTree: () => setCollapseTree((value) => !value),
                        },
                        t,
                    }),
                    h('div', { className: 'dsl-mid' },
                        h('div', { className: 'dsl-view' },
                            body,
                            more,
                            listing.phase === 'ready' && items.length > 0
                                ? h('div', { className: 'dsl-note-line' }, t('showing', items.length, matched))
                                : null,
                            listing.phase === 'ready' && listing.data.truncated === true
                                ? h('div', { className: 'dsl-note-line dsl-warn' }, t('truncated'))
                                : null,
                            dragging ? h('div', { className: 'dsl-drop' }, t('dropHint')) : null,
                            picked.length === 0 ? null : h('div', { className: 'dsl-batch' },
                                h('span', { className: 'dsl-batch-n' }, t('batchSelected', picked.length)),
                                h('input', {
                                    value: batchTag,
                                    placeholder: t('batchTagPlaceholder'),
                                    'aria-label': t('batchTagPlaceholder'),
                                    onChange: (event) => setBatchTag(event.target.value),
                                    onKeyDown: (event) => {
                                        if (event.key === 'Enter') runBatch('add');
                                    },
                                }),
                                h('button', { className: 'dsl-btn', disabled: busy, onClick: () => runBatch('add') }, t('batchAdd')),
                                h('button', { className: 'dsl-btn', disabled: busy, onClick: () => runBatch('remove') }, t('batchRemove')),
                                h('button', { className: 'dsl-btn', onClick: () => setPicked([]) }, t('batchCancel'))),
                        ),
                    ),
                    selected === null
                        ? h('div', { className: 'dsl-pane dsl-pane-blank' },
                            h('div', { className: 'dsl-pane-head' },
                                h('div', { className: 'dsl-pane-name' }, t('previewPaneTitle'))),
                            h('div', { className: 'dsl-pane-body' },
                                h('div', { className: 'dsl-pane-empty' },
                                    h(Glyph, { name: 'doc', size: 26 }),
                                    h('div', { className: 'dsl-pane-empty-title' }, t('previewEmpty')),
                                    h('div', { className: 'dsl-pane-empty-hint' }, t('previewEmptyHint')))))
                        : h(Pane, {
                            ctx: {
                                item: selected,
                                index: items.findIndex((candidate) => candidate.relPath === selected.relPath),
                                total: items.length,
                                caps,
                                media,
                                hasDocument,
                                onMedia,
                                onClose: () => setOpen(null),
                                onStep: stepDetail,
                                onToast: say,
                                onChanged: patchItem,
                            },
                            t,
                        }),
                ) : null,
                h('input', {
                    type: 'file',
                    multiple: true,
                    ref: fileInput,
                    style: { display: 'none' },
                    onChange: (event) => {
                        upload(event.target.files ?? [], scope);
                        event.target.value = '';
                    },
                }),
                toastNode,
            );
        }

        /**
         * 能力清单 → Set。
         *
         * 不叫 `useMemo`：迷你渲染器只实现 `useState` / `useEffect` / `useCallback` /
         * `useRef` 这四个钩子，多一个就得在测试里补一个假的出来。按 key 串成一个
         * 字符串当依赖，比把数组本身当依赖稳（数组每次都是新引用）。
         */
        function useCaps(list) {
            const [value, setValue] = useState(() => new Set());
            const key = (list ?? []).join(',');
            useEffect(() => {
                setValue(new Set(list ?? []));
            }, [key]);
            return value;
        }

        // ---- 渲染边界：吞掉崩溃，渲染成可见报错（不再整片空白），并写盘堆栈
        //
        // 基类条件化：测试替身（tools/mini-react）只提供 createElement 与四个 hook，
        // 没有 `Component`，直接 `extends React.Component` 会在模块定义期就崩。
        const boundaryBase = (typeof React === 'object' && typeof React.Component === 'function')
            ? React.Component
            : class {};
        class PanelBoundary extends boundaryBase {
            constructor(props) {
                super(props);
                this.state = { error: null };
            }
            static getDerivedStateFromError(error) {
                return { error };
            }
            componentDidCatch(error, info) {
                const stack = (error && error.stack) ? error.stack : String(error);
                const cstack = (info && info.componentStack) ? info.componentStack : '';
                diagWrite('[panel.crash]\n' + stack + '\nCOMPONENT STACK:\n' + cstack);
                try { console.error('[dsh-library] panel crashed:', error); } catch {}
            }
            render() {
                if (this.state.error) {
                    const e = this.state.error;
                    const message = (e && e.message) ? e.message : String(e);
                    const stack = (e && e.stack) ? e.stack : message;
                    return h('div', {
                        className: 'dsl-crash',
                        style: {
                            padding: '24px', color: '#c0392b', font: '13px/1.6 monospace',
                            whiteSpace: 'pre-wrap', overflow: 'auto', height: '100%', boxSizing: 'border-box',
                        },
                    },
                        h('div', { style: { fontWeight: '700', marginBottom: '10px', fontSize: '14px' } }, '资料库面板渲染失败（请把下方信息发我）'),
                        h('div', { style: { marginBottom: '8px' } }, message),
                        h('div', { style: { opacity: 0.85, fontSize: '11px' } }, stack),
                        h('div', { style: { marginTop: '12px', opacity: 0.7, fontSize: '11px' } }, '完整堆栈已尝试写入 dsh-library-crash.log'));
                }
                return this.props.children;
            }
        }

        // ---- 注册
        function apply(ctx) {
            const { slots, locale } = ctx;
            locale.register(NS, { zh, en });
            const rawT = locale.bind(NS);
            // 宿主 LocaleRuntime.translate 的契约：词条是带 `{name}` 占位符的字符串，
            // 第二参数必须是可 `name in params` 的对象。词条因此全部写成 {0}/{1}
            // 位置占位符，这里包一层把位置参数装进**数组**（数组天然支持 `in` 与
            // 下标访问）再交给宿主 —— 17 个调用点的 t('key', a, b) 老写法一个不用动。
            // 没有参数时直接透传：translate 对 falsy params 原样返回模板。
            const t = (key, ...args) => (args.length === 0 ? rawT(key) : rawT(key, args));

            slots.inject('sidebar.panellist', () => slots.register({
                name: 'sidebar.panellist',
                id: PANEL_ID,
                order: 22,
                label: () => t('panel'),
                locale: NS,
            }, Icon));

            // 真宿主（React.Component 存在）才包边界；测试替身直接挂裸 Panel，
            // 迷你渲染器不支持 class 组件，逻辑测试也不需要这条诊断路径。
            const panelComponent = (typeof React === 'object' && typeof React.Component === 'function')
                ? (props) => h(PanelBoundary, null, h(Panel, props))
                : Panel;
            slots.inject('main', () => slots.register({
                name: 'main',
                key: PANEL_ID,
                locale: NS,
                inject: () => ({ t }),
            }, panelComponent));
        }

        return { inject: ['slots', 'locale'], apply };
    },
});
