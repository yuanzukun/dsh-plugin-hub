/**
 * 迷你 React 渲染器（共享模块）。
 *
 * 为什么单独抽出来：`client-test.mjs`（断言）与 `render-preview.mjs`（离屏预览）
 * 都需要把 `client.js` 这棵树跑起来。两份实现一定会漂移 —— 而且漂移是**静默**的：
 * 测试里那份多漏了一个钩子，预览里那份照旧渲染，截图「看着正常」，于是测试的结论
 * 反而不如截图可信。所以只留一份，谁用都从这里取。
 *
 * 实现范围刻意很窄：只支持 client.js 用到的 `useState` / `useEffect` /
 * `useCallback` / `useRef`，且 `children` 放在元素上而不是 `props.children`。
 * 它不是 React 的替代品，作用是在重启 DSH 之前抓住拼写、结构与状态流转的错误。
 *
 * ## hook 状态按「树路径」隔离
 *
 * 最早是全局 `hooks = {}` + 一个 `cursor` 往下发号。看上去像 React，实际上不是：
 * `walk` 每次断言都会把整棵树的函数组件**重新展开一遍**，每展开一个就接着 `cursor`
 * 往后排。于是 `Detail` 的 `note` 落在 `Panel` 的某个槽位上，而下一次 `collect`
 * 又从 0 开始发号、`Detail` 换到别的槽位 —— 表现为「改完备注，`data-dirty` 却是
 * false、按钮 `disabled` 却是 true」这种自相矛盾的现象。真实 React 按**位置**记
 * 状态，跟本组件无关的兄弟组件不会抢槽位；所以这里也按路径记。
 *
 * 代价：树结构一变（搜索把 8 张卡筛成 1 张），后面的路径会平移。这和真实 React
 * 不用 `key` 时的行为一致，面板里带内部状态的组件只有 `Detail` 与媒体探针，
 * 都是单实例，不受影响。
 */

export const hookStores = new Map();
let activeStore = null;

/**
 * 「这一轮渲染有没有 setState」。
 *
 * 用函数而不是可变量：模块顶层的 `let` 被 `useState` 里的 setter 闭包捕获后，
 * 导入方读不到后续赋值。表现为 `settle()` 永远认为第一轮就已经稳定，
 * 于是异步数据还没落定就返回了半成品树。
 */
let dirtyFlag = false;
export const isDirty = () => dirtyFlag;
export const setDirty = (value) => { dirtyFlag = value; };

function storeFor(path) {
    let store = hookStores.get(path);
    if (store === undefined) {
        store = { slots: [], cursor: 0 };
        hookStores.set(path, store);
    }
    store.cursor = 0;
    return store;
}

export const React = {
    createElement(type, props, ...children) {
        const element = { type, props: props ?? {}, children: children.flat(Infinity).filter((child) => child !== null && child !== undefined && child !== false) };
        // 稳定引用：ref 在本迷你渲染器里没有提交阶段，所以直接给它接一个可点的替身。
        if (element.props.ref !== null && typeof element.props.ref === 'object' && type === 'input') {
            element.props.ref.current = { clicked: 0, click() { this.clicked += 1; } };
        }
        return element;
    },
    useState(initial) {
        const store = activeStore;
        const index = store.cursor;
        store.cursor += 1;
        if (store.slots[index] === undefined) {
            store.slots[index] = { value: typeof initial === 'function' ? initial() : initial };
        }
        const slot = store.slots[index];
        return [slot.value, (next) => {
            slot.value = typeof next === 'function' ? next(slot.value) : next;
            setDirty(true);
        }];
    },
    useCallback(fn) {
        activeStore.cursor += 1;
        return fn;
    },
    useRef(initial) {
        const store = activeStore;
        const index = store.cursor;
        store.cursor += 1;
        if (store.slots[index] === undefined) store.slots[index] = { current: initial };
        return store.slots[index];
    },
    useEffect(fn, deps) {
        const store = activeStore;
        const index = store.cursor;
        store.cursor += 1;
        const prev = store.slots[index];
        const list = Array.isArray(deps) ? deps : null;
        const changed = prev === undefined
            || list === null
            || prev.deps === null
            || prev.deps.length !== list.length
            || list.some((value, position) => !Object.is(value, prev.deps[position]));
        if (!changed) return;
        store.slots[index] = { deps: list };
        fn();
    },
};

/** 组件树里的根路径：顶层 `Panel` 固定用它，`walk` 从它往下派生。 */
export const ROOT_PATH = '#root';

/** 渲染顶层组件（它的 hook 段固定挂在 `ROOT_PATH` 上）。 */
export function renderRoot(component, props) {
    const outer = activeStore;
    activeStore = storeFor(ROOT_PATH);
    try {
        return component(props);
    } finally {
        activeStore = outer;
    }
}

// ---- 元素树工具：访问者会真的展开函数组件（与 React 一致）
//
// 路径分隔符刻意分成三种：数组下标 `.`、宿主元素的子节点 `+`、组件渲染结果的 `>`。
// 三者互不重叠，所以「同一个组件在两次展开里拿到同一个路径」这件事只会在它真的在
// 同一个位置时才成立 —— 这正是要模拟的语义。
export function walk(node, visit, path = ROOT_PATH) {
    if (node === null || node === undefined || typeof node === 'boolean') return;
    if (Array.isArray(node)) {
        node.forEach((child, index) => walk(child, visit, `${path}.${index}`));
        return;
    }
    if (typeof node !== 'object') return;
    visit(node);
    if (typeof node.type === 'function') {
        const outer = activeStore;
        activeStore = storeFor(path);
        try {
            walk(node.type({ ...node.props, children: node.children }), visit, `${path}>`);
        } finally {
            activeStore = outer;
        }
        return;
    }
    walk(node.children, visit, `${path}+`);
}

/**
 * 在指定 hook 段下渲染一个函数组件。
 *
 * 序列化 HTML 时需要**自己**展开函数组件（不能只靠 `collect` 的副作用），而组件
 * 体里全是 hook —— 不给 `activeStore` 的话 `useState` 会读 `null.cursor` 直接炸。
 * 路径与 `walk` 用同一套规则（`组件名#序号`），所以两处展开拿到的是同一段状态。
 */
export function renderComponentAt(key, component, props) {
    const outer = activeStore;
    activeStore = storeFor(key);
    try {
        return component(props);
    } finally {
        activeStore = outer;
    }
}

export function collect(tree, predicate) {
    const out = [];
    walk(tree, (node) => {
        if (predicate(node)) out.push(node);
    });
    return out;
}

export function textOf(tree) {
    const parts = [];
    const grab = (node) => {
        if (node === null || node === undefined || typeof node === 'boolean') return;
        if (Array.isArray(node)) {
            for (const child of node) grab(child);
            return;
        }
        if (typeof node === 'string' || typeof node === 'number') {
            parts.push(String(node));
            return;
        }
        if (typeof node === 'object') grab(node.children);
    };
    grab(tree);
    return parts.join('|');
}

/** 某个节点的直接文本（不展开子组件）。 */
export function textOfNode(node) {
    const parts = [];
    const grab = (child) => {
        if (child === null || child === undefined || typeof child === 'boolean') return;
        if (Array.isArray(child)) {
            for (const item of child) grab(item);
            return;
        }
        if (typeof child === 'string' || typeof child === 'number') {
            parts.push(String(child));
            return;
        }
        if (typeof child === 'object') grab(child.children);
    };
    grab(node.children);
    return parts.join('');
}

export function byClass(tree, className) {
    return collect(tree, (node) => typeof node.props?.className === 'string' && node.props.className.split(/\s+/u).includes(className));
}
