/**
 * 扫描 / 索引 / 类型目录的自测。不依赖 DSH 宿主：
 *
 *   node tools/scan-test.mjs
 *
 * 这一层是资料库的地基：「库里有什么」全部由它推导（磁盘是权威），索引只负责
 * 人的输入。两者一旦错位，页面上就会出现幽灵条目或者点不开的资料。
 */
import { mkdir, writeFile, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { classify, mimeOf, isTextPreviewable, isInlineSafe, extOf, KINDS } from '../lib/kinds.js';
import { scanLibrary, folderStats, toRelative, parentOf, nameOf } from '../lib/scan.js';
import {
    emptyIndex, readIndex, writeIndex, mergeAnnotations, upsertEntry, pruneEntries,
    normalizeEntry, indexPathOf, INDEX_FILE_NAME, INDEX_VERSION,
} from '../lib/store.js';
import { sanitizeName, uniqueName } from '../lib/names.js';

let failed = 0;
function check(label, actual, expected) {
    const ok = JSON.stringify(actual) === JSON.stringify(expected);
    if (ok) {
        console.log(`ok   ${label}`);
    } else {
        failed += 1;
        console.log(`FAIL ${label} -> ${JSON.stringify(actual)} (expected ${JSON.stringify(expected)})`);
    }
}

// ================= 类型目录 =================
check('类型顺序稳定', KINDS, ['doc', 'sheet', 'page', 'image', 'video', 'audio', 'link', 'file']);
check('extOf 取小写扩展名', extOf('a/b/C.MD'), '.md');
check('extOf 无扩展名', extOf('README'), '');
check('分类：文档', classify('.md'), 'doc');
check('分类：表格', classify('.xlsx'), 'sheet');
check('分类：图片', classify('.png'), 'image');
check('分类：页面', classify('.html'), 'page');
check('分类：链接', classify('.url'), 'link');
check('分类：未知扩展名退化成通用附件（不是忽略）', classify('.xyz'), 'file');
check('分类：没有扩展名也是通用附件', classify(''), 'file');
check('MIME：已知', mimeOf('.md'), 'text/markdown');
check('MIME：未知退回八位组流', mimeOf('.xyz'), 'application/octet-stream');
check('可当文本看：md', isTextPreviewable('.md'), true);
check('可当文本看：csv', isTextPreviewable('.csv'), true);
check('不可当文本看：png', isTextPreviewable('.png'), false);
check('不能内联：html', isInlineSafe('.html'), false);
check('不能内联：svg', isInlineSafe('.svg'), false);
check('可以内联：txt', isInlineSafe('.txt'), true);

// ================= 相对路径工具 =================
const root = join(tmpdir(), 'dsh-library-scan');
check('parentOf：顶层为空', parentOf('a.md'), '');
check('parentOf：嵌套', parentOf('x/y/a.md'), 'x/y');
check('nameOf：顶层', nameOf('a.md'), 'a.md');
check('nameOf：嵌套', nameOf('x/y/a.md'), 'a.md');
check('toRelative 反向拼得回来', toRelative(root, join(root, 'x', 'a.md')), 'x/a.md');

// ================= 扫描 =================
await rm(root, { recursive: true, force: true });
await mkdir(join(root, '分组', '2026'), { recursive: true });
await mkdir(join(root, '空目录'), { recursive: true });
await mkdir(join(root, '.hidden'), { recursive: true });
await mkdir(join(root, 'node_modules'), { recursive: true });
await writeFile(join(root, 'a.md'), 'a', 'utf8');
await writeFile(join(root, '分组', 'b.md'), 'b', 'utf8');
await writeFile(join(root, '分组', '2026', 'c.png'), 'c', 'utf8');
await writeFile(join(root, '空目录', '.keep-not-listed'), 'x', 'utf8');
await writeFile(join(root, '.hidden', 'secret.md'), 's', 'utf8');
await writeFile(join(root, 'node_modules', 'dep.js'), 'd', 'utf8');
await writeFile(join(root, '~$a.md'), 'tmp', 'utf8');
await writeFile(join(root, 'part.tmp'), 'tmp', 'utf8');
await writeFile(join(root, 'Thumbs.db'), 'junk', 'utf8');
await writeFile(join(root, INDEX_FILE_NAME), '{}', 'utf8');

const scan = await scanLibrary(root, {});
const paths = scan.items.map((item) => item.relPath);
const files = scan.items.filter((item) => !item.isDir);
const dirs = scan.items.filter((item) => item.isDir);

check('扫描不截断', scan.truncated, false);
check('文件数正确', files.length, 3);
check('目录也被收录', dirs.map((item) => item.relPath), ['分组', '分组/2026', '空目录']);
check('目录标记为 isDir', dirs.every((item) => item.isDir && item.kind === 'folder'), true);
check('隐藏目录被跳过', paths.includes('.hidden/secret.md'), false);
check('依赖目录被跳过', paths.includes('node_modules/dep.js'), false);
check('Office 临时文件被跳过', paths.includes('~$a.md'), false);
check('临时扩展名被跳过', paths.includes('part.tmp'), false);
check('系统垃圾文件被跳过', paths.includes('Thumbs.db'), false);
check('索引文件自己不进清单', paths.includes(INDEX_FILE_NAME), false);
check('空目录仍在清单里', paths.includes('空目录'), true);
check('嵌套文件带正确父目录', files.find((item) => item.name === 'c.png').parent, '分组/2026');
check('扫描结果带类型', files.find((item) => item.name === 'c.png').kind, 'image');
check('扫描结果带大小', files.every((item) => Number.isFinite(item.size)), true);
check('扫描结果带修改时间', files.every((item) => Number.isFinite(item.mtimeMs)), true);
check('清单按路径排序', paths, [...paths].sort());

const withHidden = await scanLibrary(root, { includeHidden: true });
check('允许隐藏时才收录隐藏目录', withHidden.items.some((item) => item.relPath === '.hidden/secret.md'), true);

const shallow = await scanLibrary(root, { maxDepth: 1 });
check('深度限制：根的直接子项仍在', shallow.items.some((item) => item.relPath === 'a.md'), true);
check('深度限制：目录本身仍列出', shallow.items.some((item) => item.relPath === '分组'), true);
check('深度限制：不进入子目录', shallow.items.some((item) => item.relPath === '分组/b.md'), false);

const twoLevels = await scanLibrary(root, { maxDepth: 2 });
check('深度 2：一层子目录可见', twoLevels.items.some((item) => item.relPath === '分组/b.md'), true);
check('深度 2：二层子目录不可见', twoLevels.items.some((item) => item.relPath === '分组/2026/c.png'), false);

const capped = await scanLibrary(root, { maxFiles: 2 });
check('条目上限触发截断标记', capped.truncated, true);
check('条目上限真的封顶', capped.items.length <= 2, true);

// ================= 目录汇总 =================
const folders = folderStats(scan.items);
const pick = (relPath) => folders.find((entry) => entry.relPath === relPath);
check('树里第一个是库根', folders[0].relPath, '');
check('库根总数含子目录', pick('').total, 3);
check('库根直接文件数', pick('').files, 1);
check('库根目录数', pick('').folders, 3);
check('子目录总数', pick('分组').total, 2);
check('子目录直接文件数', pick('分组').files, 1);
check('孙目录计数', pick('分组/2026').total, 1);
check('空目录也在树里', pick('空目录') !== undefined, true);
check('空目录计数为零', [pick('空目录').files, pick('空目录').total], [0, 0]);
check('深度字段正确', pick('分组/2026').depth, 2);
check('名字字段正确', pick('分组/2026').name, '2026');
check('空条目树退化成只剩库根', folderStats([]).length, 1);

// ================= 索引 =================
const indexRoot = join(root, 'index-probe');
await mkdir(indexRoot, { recursive: true });

check('索引路径在库根下', indexPathOf(indexRoot), join(indexRoot, INDEX_FILE_NAME));
check('空索引版本正确', emptyIndex().version, INDEX_VERSION);
check('索引不存在时给空索引', await readIndex(indexRoot), emptyIndex());

await writeIndex(indexRoot, { entries: { 'a.md': { tags: ['x'], note: 'n' } } });
const loaded = await readIndex(indexRoot);
check('索引往返：标签', loaded.entries['a.md'].tags, ['x']);
check('索引往返：备注', loaded.entries['a.md'].note, 'n');
check('索引带更新时间', loaded.updatedAtMs > 0, true);

// 损坏的索引不能让整个资料库打不开
await writeFile(indexPathOf(indexRoot), '{ not json', 'utf8');
check('索引损坏时退回空索引', await readIndex(indexRoot), emptyIndex());
await writeFile(indexPathOf(indexRoot), JSON.stringify({ version: 999, entries: { 'a.md': {} } }), 'utf8');
check('版本不认识时退回空索引', await readIndex(indexRoot), emptyIndex());

check('归一化：标签去重去空', normalizeEntry({ tags: ['a', 'a', ' ', 3, 'b'] }).tags, ['a', 'b']);
check('归一化：备注缺省为空串', normalizeEntry({}).note, '');

// ================= 标注合并 =================
const items = [
    { relPath: 'a.md', name: 'a.md', parent: '', isDir: false, kind: 'doc', ext: '.md', size: 1, mtimeMs: 1 },
    { relPath: 'b.md', name: 'b.md', parent: '', isDir: false, kind: 'doc', ext: '.md', size: 1, mtimeMs: 2 },
];
const merged = mergeAnnotations(items, { version: INDEX_VERSION, updatedAtMs: 0, entries: { 'a.md': { tags: ['t'], note: 'n' } } });
check('有标注的条目拿到标签', merged[0].tags, ['t']);
check('有标注的条目拿到备注', merged[0].note, 'n');
check('没标注的条目是空数组', merged[1].tags, []);
check('没标注的条目是空串', merged[1].note, '');
check('合并不改原对象', items[0].tags, undefined);

// ================= 标注写入 =================
let index = emptyIndex();
index = upsertEntry(index, 'a.md', { tagsAdd: ['研究'] });
check('tagsAdd 新增', index.entries['a.md'].tags, ['研究']);
index = upsertEntry(index, 'a.md', { tagsAdd: ['研究', '紧急'] });
check('tagsAdd 去重', index.entries['a.md'].tags, ['研究', '紧急']);
index = upsertEntry(index, 'a.md', { tagsRemove: ['研究'] });
check('tagsRemove 生效', index.entries['a.md'].tags, ['紧急']);
index = upsertEntry(index, 'a.md', { tags: ['甲', '乙'] });
check('tags 整体替换', index.entries['a.md'].tags, ['甲', '乙']);
index = upsertEntry(index, 'a.md', { note: '备注' });
check('写备注不动标签', index.entries['a.md'].tags, ['甲', '乙']);
index = upsertEntry(index, 'a.md', { source: { sessionId: 's1' } });
check('来源落进索引', index.entries['a.md'].source, { sessionId: 's1' });
index = upsertEntry(index, 'a.md', { source: { projectPath: 'D:/x' } });
check('来源是增量合并', index.entries['a.md'].source, { sessionId: 's1', projectPath: 'D:/x' });

index = upsertEntry(index, 'a.md', { tags: [], note: '' });
check('标签与备注全空、来源还在 → 这一行保留', index.entries['a.md'].source !== undefined, true);
index = upsertEntry(index, 'a.md', { source: {} });
check('空来源是空操作，不会误清已有来源', index.entries['a.md'].source, { sessionId: 's1', projectPath: 'D:/x' });

const bare = upsertEntry(emptyIndex(), 'z.md', { tags: ['t'] });
check('只有标签时留下这一行', Object.keys(bare.entries), ['z.md']);
const cleared = upsertEntry(bare, 'z.md', { tags: [], note: '' });
check('清空所有标注后整行消失', cleared.entries['z.md'], undefined);
check('消失后没有残留空壳', Object.keys(cleared.entries), []);

// ================= 悬空条目清理 =================
const dangling = {
    version: INDEX_VERSION,
    updatedAtMs: 0,
    entries: { 'a.md': { tags: ['keep'], note: '' }, 'gone.md': { tags: ['drop'], note: '' } },
};
const pruned = pruneEntries(dangling, items);
check('清理只保留活着的路径', Object.keys(pruned.index.entries), ['a.md']);
check('清理报告被删掉的路径', pruned.removed, ['gone.md']);
check('清理不改原索引', Object.keys(dangling.entries), ['a.md', 'gone.md']);
check('清理后标注内容不变', pruned.index.entries['a.md'].tags, ['keep']);

// ================= 入库名称 =================
check('名称：普通中文名原样通过', sanitizeName('笔记.md'), '笔记.md');
check('名称：两端空白被去掉', sanitizeName('  笔记.md  '), '笔记.md');
check('名称：中文与空格保留', sanitizeName('会议 记录 2026.md'), '会议 记录 2026.md');
check('名称：空串不行', sanitizeName(''), undefined);
check('名称：纯空白不行', sanitizeName('   '), undefined);
check('名称：非字符串不行', sanitizeName(123), undefined);
check('名称：斜杠不行', sanitizeName('a/b.md'), undefined);
check('名称：反斜杠不行', sanitizeName('a\\b.md'), undefined);
check('名称：冒号不行', sanitizeName('a:b.md'), undefined);
check('名称：问号不行', sanitizeName('a?.md'), undefined);
check('名称：竖线不行', sanitizeName('a|b.md'), undefined);
check('名称：换行不行', sanitizeName('a\nb.md'), undefined);
check('名称：NUL 不行', sanitizeName('a\u0000b'), undefined);
check('名称：点开头默认不行（隐藏）', sanitizeName('.secret.md'), undefined);
check('名称：显式允许时点开头可以', sanitizeName('.secret.md', { allowDot: true }), '.secret.md');
check('名称：单个点不行', sanitizeName('.'), undefined);
check('名称：双点不行', sanitizeName('..'), undefined);
check('名称：结尾的点不行', sanitizeName('报告.'), undefined);
check('名称：太长不行', sanitizeName('x'.repeat(121)), undefined);
check('名称：刚好到上限可以', sanitizeName('x'.repeat(120)), 'x'.repeat(120));
check('名称：Windows 保留名不行', sanitizeName('CON'), undefined);
check('名称：保留名带扩展名也不行', sanitizeName('con.md'), undefined);
check('名称：保留名大小写不敏感', sanitizeName('COM1.txt'), undefined);
check('名称：含保留名但不是保留名可以', sanitizeName('console.md'), 'console.md');

check('去重：没撞名就原样', uniqueName([], '笔记.md'), '笔记.md');
check('去重：撞了加序号', uniqueName(['笔记.md'], '笔记.md'), '笔记 (2).md');
check('去重：序号继续往后找', uniqueName(['笔记.md', '笔记 (2).md'], '笔记.md'), '笔记 (3).md');
check('去重：扩展名留在最后', uniqueName(['a.md'], 'a.md'), 'a (2).md');
check('去重：多个点只动最后一段', uniqueName(['a.b.md'], 'a.b.md'), 'a.b (2).md');
check('去重：没有扩展名就不加', uniqueName(['笔记'], '笔记'), '笔记 (2)');
check('去重：大小写不敏感（Windows 语义）', uniqueName(['A.MD'], 'a.md'), 'a (2).md');
check('去重：接受 Set', uniqueName(new Set(['a.md']), 'a.md'), 'a (2).md');
const crowded = ['a.md', ...Array.from({ length: 199 }, (_, index) => `a (${index + 2}).md`)];
check('去重：序号用尽后放弃', uniqueName(crowded, 'a.md'), undefined);
check('去重：无关名字不干扰', uniqueName(['b.md', 'c.md'], 'a.md'), 'a.md');

await rm(root, { recursive: true, force: true });

console.log(failed === 0 ? 'ALL PASS' : `${failed} FAILED`);
process.exit(failed === 0 ? 0 : 1);
