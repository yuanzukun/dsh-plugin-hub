/**
 * 纯逻辑自测：路径归一化 / 包含检查 / home 解析 / 原子 JSON 读写。
 *
 * 不依赖 DSH 宿主，可以随时离线跑：
 *
 *   node tools/logic-test.mjs
 *
 * 脚本必须用 ASCII 编写（中文从参数传入或写成注释里的说明）—— Windows
 * PowerShell 5.1 会把无 BOM 的 UTF-8 脚本按 ANSI 读；这里用 node 直接跑，
 * 但仍保持 ASCII 习惯，免得日后被别的宿主读成乱码。
 */
import { rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join, sep } from 'node:path';
import { normalizeRelPath, isInside, resolveInside, toAbsolute } from '../lib/paths.js';
import { resolveDshHome, expandHomePath, readJsonFile, writeJsonFile } from '../lib/home.js';

const ROOT = `C:${sep}library-probe`;
let failed = 0;

function check(label, actual, expected) {
    const ok = JSON.stringify(actual) === JSON.stringify(expected);
    if (ok) {
        console.log(`ok   ${label}`);
    } else {
        failed += 1;
        console.log(`FAIL ${label} -> ${JSON.stringify(actual)} (expected ${JSON.stringify(expected)})`);
    }
}

// ---- 路径归一化
check('normalize: 空串是库根自身', normalizeRelPath(''), '');
check('normalize: 反斜杠折成正斜杠', normalizeRelPath('a\\b\\c.png'), 'a/b/c.png');
check('normalize: 去掉 ./ 与重复斜杠', normalizeRelPath('./a//b/'), 'a/b');
check('normalize: 挡掉 ..', normalizeRelPath('../etc/passwd'), undefined);
check('normalize: 挡掉中间的 ..', normalizeRelPath('a/../../b'), undefined);
check('normalize: 挡掉绝对路径', normalizeRelPath('/etc/passwd'), undefined);
check('normalize: 挡掉盘符', normalizeRelPath('C:/Windows'), undefined);
check('normalize: 挡掉 NUL', normalizeRelPath('a\u0000b'), undefined);
check('normalize: 挡掉换行', normalizeRelPath('a\nb'), undefined);
check('normalize: 非字符串', normalizeRelPath(null), undefined);

// ---- 包含检查
check('isInside: 根自身算在内', isInside(ROOT, ROOT), true);
check('isInside: 同名前缀不算在内', isInside(ROOT, `${ROOT}2${sep}x`), false);
check('isInside: 大小写不敏感', isInside(ROOT, ROOT.toLowerCase()), true);
check('resolveInside: 正常路径', resolveInside(ROOT, 'a/b.txt'), toAbsolute(ROOT, 'a/b.txt'));
check('resolveInside: 逃逸被挡', resolveInside(ROOT, '../x'), undefined);
check('resolveInside: 子目录正常', resolveInside(ROOT, '分组/2026/笔记.md') !== undefined, true);

// ---- home 解析
check('expandHome: 展开 ~', expandHomePath('~') !== '~', true);
check('resolveDshHome: 显式优先', resolveDshHome(`D:${sep}x`), `D:${sep}x`);
check('resolveDshHome: 空白视为未设置', resolveDshHome('   ').endsWith('.dsh'), true);

// ---- 原子 JSON 读写
const probeDir = join(tmpdir(), 'dsh-library-probe');
const probeFile = join(probeDir, 'index.json');
await writeJsonFile(probeFile, { version: 1, items: [] });
check('JSON: 往返一致', await readJsonFile(probeFile), { version: 1, items: [] });
await rm(probeDir, { recursive: true, force: true });
check('JSON: 缺失文件返回 undefined', await readJsonFile(probeFile), undefined);

console.log(failed === 0 ? 'ALL PASS' : `${failed} FAILED`);
process.exit(failed === 0 ? 0 : 1);
