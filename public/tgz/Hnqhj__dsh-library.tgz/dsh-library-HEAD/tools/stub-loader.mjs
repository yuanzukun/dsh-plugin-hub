/**
 * 本地测试用的模块替身加载器。
 *
 * `@deepseek-ai/schemastery` 由 DSH 安装本体在运行期提供，仓库里没有它，所以在
 * Node 里直接 import 宿主半会因为解析不到包而失败。这里把该请求重定向到
 * `tools/stubs/schemastery.mjs`，好让宿主半能在没有 DSH 的情况下被真实加载。
 *
 * 只用于测试：真正跑在 DSH 里时解析的是官方包。
 */
const stubUrl = new URL('./stubs/schemastery.mjs', import.meta.url).href;

export function resolve(specifier, context, nextResolve) {
    if (specifier === '@deepseek-ai/schemastery') {
        return { url: stubUrl, shortCircuit: true };
    }
    return nextResolve(specifier, context);
}
