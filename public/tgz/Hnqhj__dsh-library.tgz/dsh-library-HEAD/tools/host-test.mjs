/**
 * 宿主半集成测试：真实加载 index.js，真实起一个 HTTP 服务器，完整走一遍 HTTP 面。
 *
 *   node tools/host-test.mjs
 *
 * 它验证两件事：
 *  1. 重启 DSH 之后不会加载失败 —— 模块图能被求值、`apply()` 能把路由挂上去；
 *  2. HTTP 面真的能用 —— 状态、列目录、搜索、详情、标注、重扫、文件流
 *     （含 Range / 304 / HEAD），以及三道收口（路径逃逸、隐藏段、HTML 的
 *     CSP sandbox）。
 *
 * 走真 socket 而不是假 response 对象：文件流与 Range 语义只有真连接才能验。
 * `@deepseek-ai/schemastery` 用替身顶掉（见 stub-loader.mjs）。
 */
import { register } from 'node:module';
import { createServer } from 'node:http';
import { mkdir, writeFile, rm, copyFile } from 'node:fs/promises';
import { existsSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const here = dirname(fileURLToPath(import.meta.url));

register('./stub-loader.mjs', import.meta.url);

let failed = 0;
function check(label, actual, expected) {
    const ok = JSON.stringify(actual) === JSON.stringify(expected);
    if (ok) {
        console.log(`ok   ${label}`);
    } else {
        failed += 1;
        console.log(`FAIL ${label} -> ${JSON.stringify(actual)} (expected ${JSON.stringify(expected)})`);
    }
}

/** 顺序无关的集合比较（只用于"有哪些条目"这类断言，避免被排序规则牵着走）。 */
function checkNames(label, items, expected) {
    const byName = (a, b) => (a < b ? -1 : a > b ? 1 : 0);
    check(label, items.map((item) => item.name).sort(byName), [...expected].sort(byName));
}

/** 布尔断言的简写，省得每个都写 `, true`。 */
function checkTrue(label, value) {
    check(label, value === true, true);
}

// ---- 用临时 DSH_HOME 隔离这次测试，绝不碰真实的用户数据
const home = join(tmpdir(), 'dsh-library-host-test');
await rm(home, { recursive: true, force: true });
process.env.DSH_HOME = home;

const mod = await import('../index.js');
check('插件名', mod.name, 'library');
check('没有必需服务', mod.inject, []);
check('导出了配置模式', mod.Config !== undefined, true);
check('导出了 apply', typeof mod.apply, 'function');

// ---- 假的插件上下文：Web 服务器即时可见（懒绑定那条路径在 dsh-asset-library 已验过）
//
// apply 与 Web 注册必须成对。写死总数会随本文件里 apply 次数的变化而失效，
// 而它真正要守的是"一次 apply 恰好一条路由" —— 重复注册会让路由表翻倍，
// 且不报错（后注册的先匹配，症状是改了配置却不生效）。
const routes = [];
const perServer = new Map();
const webServer = {
    register(definition) {
        perServer.set(this, (perServer.get(this) ?? 0) + 1);
        routes.push(definition);
        return () => {
            const index = routes.indexOf(definition);
            if (index !== -1) routes.splice(index, 1);
        };
    },
};

const logs = [];
// apply 与 Web 注册必须成对。
//
// 写死"总共注册了几条"会随本文件里 apply 次数的变化而失效；重复注册又不报错
// （后注册的先匹配，症状是"改了配置却不生效"），所以每次 apply 单独断言增量。
let applies = 0;
function checkedApply(context, config) {
    const before = perServer.get(webServer) ?? 0;
    applies += 1;
    mod.apply(context, config);
    check(`第 ${applies} 次 apply 恰好注册一条 Web 路由`, (perServer.get(webServer) ?? 0) - before, 1);
}
let connectionService;
let sessionsService;
const ctx = {
    logger: {
        info: (message) => logs.push(`info ${message}`),
        warn: (message) => logs.push(`warn ${message}`),
    },
    effect(fn, label) {
        fn();
        return () => void label;
    },
    get(key) {
        if (key === 'webServer') return webServer;
        if (key === 'httpServer') return undefined;
        if (key === 'connection') return connectionService;
        if (key === 'sessions') return sessionsService;
        return undefined;
    },
    on() {},
};

/** 把某条路由挂到一个真实的临时 HTTP 服务器上，跑完就关。 */
async function withServer(definition, fn) {
    const origin = createServer((req, res) => {
        definition.handler(req, res).catch(() => {
            if (!res.headersSent) res.writeHead(500);
            res.end();
        });
    });
    await new Promise((resolve) => origin.listen(0, '127.0.0.1', resolve));
    const { port } = origin.address();
    try {
        return await fn(`http://127.0.0.1:${port}/api/library`);
    } finally {
        await new Promise((resolve) => origin.close(resolve));
    }
}

/** 取 JSON；失败返回 `null`（错误路径也走这里，靠状态码断言）。 */
async function getJson(url, init) {
    const response = await fetch(url, init);
    const text = await response.text();
    let json = null;
    try {
        json = JSON.parse(text);
    } catch {
        json = null;
    }
    return { response, json, text };
}

/** POST 一段 JSON。模块级，因为 reveal 那个块要在 `withServer` 回调之外用。 */
async function postJson(base, path, body) {
    return getJson(`${base}${path}`, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify(body),
    });
}

// ================= 库根解析 =================
// 显式空串 = 退回 <DSH_HOME>/library（本机默认值不走这条）
checkedApply(ctx, { root: '' });
check('Web 面已挂载', routes.length, 1);
check('路由是前缀路由', routes[0].kind, 'prefix');
check('路由前缀', routes[0].path, '/api/library');
check('启动时打了日志', logs.some((line) => line.includes('library: ready')), true);
check('挂载后打了日志', logs.some((line) => line.includes('mounted at /api/library')), true);

const defaultRoute = routes[0];
await withServer(defaultRoute, async (base) => {
    let { response, json } = await getJson(`${base}/status`);
    check('状态端点 200', response.status, 200);
    check('状态端点不缓存', response.headers.get('cache-control'), 'no-store');
    check('自报名称', json.name, 'library');
    check('空串库根落在 DSH_HOME 下', json.root, join(home, 'library'));
    check('库根来自默认推导', json.rootSource, 'default');
    check('空库不算存在', json.exists, false);
    check('空库条目数为 0', json.items, 0);
    check('能力清单', json.capabilities, ['status', 'items', 'item', 'tree', 'facets', 'file', 'document', 'mkdir', 'create', 'upload', 'annotate', 'annotateMany', 'rescan', 'external', 'import', 'reveal']);
    check('自检信息带上 Web 状态', json.diagnostics, { web: true });

    ({ response, json } = await getJson(base));
    check('索引端点 200', response.status, 200);
    check('索引端点列出可用路径', json.endpoints, ['status', 'items', 'item', 'tree', 'facets', 'file', 'document', 'mkdir', 'create', 'upload', 'rescan', 'annotate', 'reveal', 'external', 'import']);

    ({ response, json } = await getJson(`${base}/`));
    check('尾部斜杠等价于索引', response.status, 200);

    ({ response, json } = await getJson(`${base}/nope`));
    check('未知路由 404', response.status, 404);
    check('未知路由信封', json.error.code, 'NOT_FOUND');

    ({ response, json } = await getJson(`${base}/status`, { method: 'POST' }));
    check('方法不对 405', response.status, 405);
    check('方法信封', json.error.code, 'METHOD_NOT_ALLOWED');

    // 空库下的查询不该抛异常，而是给一份空清单
    ({ response, json } = await getJson(`${base}/items?parent=`));
    check('空库列目录 200', response.status, 200);
    check('空库列目录模式', json.mode, 'children');
    check('空库列目录为空', json.items, []);

    ({ response, json } = await getJson(`${base}/file?path=whatever.txt`));
    check('空库取文件 404', response.status, 404);
    check('空库取文件信封', json.error.code, 'NOT_FOUND');
});

// 完全不传配置时用出厂默认：**必须落在 C 盘之外**，否则"库根放错盘"会静默发生。
checkedApply(ctx, {});
await withServer(routes[routes.length - 1], async (base) => {
    const { json } = await getJson(`${base}/status`);
    check('出厂默认库根', json.root, join('D:/dsh-library-data'));
    checkTrue('出厂默认不在 C 盘', json.root.slice(0, 2).toUpperCase() !== 'C:');
});

// ================= 建一个真实的库 =================
const libRoot = join(home, 'real-library');
await mkdir(join(libRoot, '笔记'), { recursive: true });
await mkdir(join(libRoot, '.secret'), { recursive: true });
await writeFile(join(libRoot, '笔记', 'hello.md'), '# 你好\n', 'utf8');
await writeFile(join(libRoot, '笔记', '数据.csv'), 'a,b\n1,2\n', 'utf8');
await writeFile(join(libRoot, '图.png'), Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]));
await writeFile(join(libRoot, '页面.html'), '<script>alert(1)</script>', 'utf8');
await writeFile(join(libRoot, 'raw.txt'), 'ABCDEFGHIJ', 'utf8');
await writeFile(join(libRoot, '.secret', 'hidden.txt'), 'secret', 'utf8');

// /document 端点的料。**放在子目录里**，这样上面那批"根目录有 4 个条目 /
// 5 个文件"的计数断言不用改 —— 它们守的是列目录与筛选的形状，不该被
// 新增的解析测试连累。
const docDir = join(libRoot, '资料');
await mkdir(docDir, { recursive: true });
for (const name of ['storyboard.xlsx', 'stored.xlsx', 'script.docx', 'mismatch.docx', 'broken.docx', 'noworkbook.xlsx']) {
    await copyFile(join(here, '..', 'docs', 'fixtures', name), join(docDir, name));
}
// CSV 里刻意放三种"按行 split 会出错"的内容：引号内的逗号、引号内的换行、
// 转义的双引号；再加一个 UTF-8 BOM，验证第一个表头不被污染。
await writeFile(join(docDir, '引号.csv'),
    '﻿片名,备注\r\n"醒来, 分镜","第一行\n第二行"\r\n"他说""好""了",尾\r\n', 'utf8');
await writeFile(join(docDir, '老文档.doc'), Buffer.from([0xd0, 0xcf, 0x11, 0xe0, 0xa1, 0xb1, 0x1a, 0xe1]));
await writeFile(join(docDir, '脚本.js'), 'export const a = 1;\n', 'utf8');

// 库**外**的源目录：批量导入的取材地。刻意放几样"不该被列出来"的东西，
// 用来验证扫描层与库内扫描用的是同一套跳过规则。
const sourceRoot = join(home, 'project-out');
await mkdir(join(sourceRoot, '子目录'), { recursive: true });
await mkdir(join(sourceRoot, 'node_modules'), { recursive: true });
await writeFile(join(sourceRoot, '报告.md'), '# 报告\n', 'utf8');
await writeFile(join(sourceRoot, '数据.csv'), 'x,y\n1,2\n', 'utf8');
await writeFile(join(sourceRoot, '子目录', '深一层.md'), '深', 'utf8');
await writeFile(join(sourceRoot, 'node_modules', 'dep.js'), 'nope', 'utf8');
await writeFile(join(sourceRoot, '.隐藏.md'), 'hidden', 'utf8');
await writeFile(join(sourceRoot, '半截.part'), 'junk', 'utf8');

checkedApply(ctx, { root: libRoot });
const route = routes[routes.length - 1];

/**
 * 库里"种子文件"的个数（不含目录）。
 *
 * 这些计数断言写死数字有个老问题：每加一个夹具就得改一批期望，改漏了就是一片
 * 红，而红的原因跟被测的逻辑无关。改成从夹具数出来之后，断言的意思回到它该
 * 守的那件事 —— "status 报的数与库里实际的数一致"，而不是"库里恰好有 5 个文件"。
 */
const SEED_FILES = 5 + 9; // 根目录 5 个 + 资料/ 目录里 9 个
const SEED_FOLDERS = 2; // 笔记/ 与 资料/

await withServer(route, async (base) => {
    // ---- 状态
    let { response, json } = await getJson(`${base}/status`);
    check('显式库根生效', json.root, libRoot);
    check('库根来自配置', json.rootSource, 'config');
    check('库根已存在', json.exists, true);
    check('统计文件数', json.items, SEED_FILES);
    check('统计分组数（不含库根）', json.folders, SEED_FOLDERS);
    check('统计总字节数可读', typeof json.bytes === 'number' && json.bytes > 0, true);
    check('没有截断', json.truncated, false);
    check('自报上传上限', json.maxUploadBytes, 64 * 1024 * 1024);

    // ---- 列目录（子项模式）
    ({ json } = await getJson(`${base}/items?parent=`));
    check('根目录模式', json.mode, 'children');
    check('根目录只列直接子项', json.matched, 5);
    checkNames('根目录条目', json.items, ['笔记', '资料', '图.png', '页面.html', 'raw.txt']);
    check('目录排在文件前面', json.items[0].isDir, true);

    ({ json } = await getJson(`${base}/items?parent=${encodeURIComponent('笔记')}`));
    check('子目录只列自己的子项', json.matched, 2);
    checkNames('子目录条目', json.items, ['hello.md', '数据.csv']);

    ({ json } = await getJson(`${base}/items?parent=${encodeURIComponent('.secret')}`));
    check('隐藏目录不进清单', json.matched, 0);

    // ---- 搜索（搜索模式）
    ({ json } = await getJson(`${base}/items?q=hello`));
    check('搜索模式', json.mode, 'search');
    check('按文件名搜索', json.matched, 1);
    check('搜索命中路径', json.items[0].relPath, '笔记/hello.md');

    ({ json } = await getJson(`${base}/items?kind=image`));
    check('按类型筛选', json.matched, 1);
    check('类型筛选结果', json.items[0].name, '图.png');

    ({ json } = await getJson(`${base}/items?kind=sheet`));
    check('表格类型筛选命中 xlsx（第一个按名排序）', json.items.map((i) => i.relPath).includes('资料/storyboard.xlsx'), true);

    ({ json } = await getJson(`${base}/items?q=nomatch-zzz`));
    check('搜不到就是空清单', json.items, []);

    ({ json } = await getJson(`${base}/items?limit=1&offset=1`));
    check('分页生效', json.items.length, 1);

    // ---- scope 的"键存在性"就是模式开关
    //
    // `scope=''`（键存在）= 整库递归检索；完全不给 `scope` = 列 `parent` 的直接子项。
    // 字符串上这两种情况无法区分，所以契约落在**键是否存在**上。面板第一屏就是
    // "整库的全部文件"，必须能明确表达"我要整库、要递归"。
    ({ json } = await getJson(`${base}/items`));
    check('不给 scope 就是子项模式', json.mode, 'children');
    ({ json } = await getJson(`${base}/items?scope=`));
    check('给了空 scope 就是整库检索', json.mode, 'search');
    check('整库检索只数文件', json.matched, SEED_FILES);
    ({ json } = await getJson(`${base}/items?scope=${encodeURIComponent('笔记')}`));
    check('scope 收窄到子树', json.matched, 2);
    check('scope 回显', json.scope, '笔记');
    // 同前缀的兄弟目录不能被算进来：`笔记集/` 里的东西不算 `笔记/` 的
    ({ json } = await getJson(`${base}/items?scope=${encodeURIComponent('笔')}`));
    check('scope 用 scope+/ 前缀而不是裸 startsWith', json.matched, 0);

    // scope 与其他筛选叠加
    ({ json } = await getJson(`${base}/items?scope=${encodeURIComponent('笔记')}&kind=doc`));
    check('scope 与 kind 叠加', [json.matched, json.items[0].relPath], [1, '笔记/hello.md']);
    ({ json } = await getJson(`${base}/items?scope=${encodeURIComponent('笔记')}&q=数据`));
    check('scope 与 q 叠加', json.matched, 1);

    // ---- /facets：计数跟着范围走
    ({ json } = await getJson(`${base}/facets`));
    check('facets 回显 scope', json.scope, '');
    check('facets 整库计数', json.whole, SEED_FILES);
    check('facets 目录只列直接子目录', json.folders.map((f) => f.relPath), ['笔记', '资料']);
    // 类型计数守的是"**按类型分**"这件事，不是"doc 有几个"。写死数字的话，
    // 每加一个文档夹具就得改这里，而红的原因跟被测逻辑无关。
    // 真正要守的是：各类型计数加起来恰好等于总数（不多算、不漏算）。
    check('facets 各类型计数加起来等于总数',
        json.kinds.reduce((sum, entry) => sum + entry.count, 0), json.total);
    const docKind = json.kinds.find((entry) => entry.kind === 'doc');
    check('facets 有 doc 类型', docKind !== undefined, true);
    check('facets doc 计数与实际一致', docKind?.count,
        (await getJson(`${base}/items?scope=&kind=doc`)).json.matched);

    ({ json } = await getJson(`${base}/facets?scope=${encodeURIComponent('笔记')}`));
    check('facets 跟着 scope 走', json.total, 2);
    check('facets 整库总数不随 scope 变', json.whole, SEED_FILES);
    check('facets 在子目录里不列自己', json.folders, []);
    check('facets 在子目录里报父级', json.parent, '');

    // 目录计数是递归的（"这个范围里有多少"）
    ({ json } = await getJson(`${base}/facets?scope=${encodeURIComponent('笔')}`));
    check('facets 在不存在的 scope 上返回空', [json.total, json.folders], [0, []]);

    // ---- 列表载荷自带绝对路径
    //
    // 面板几乎总是先渲染列表、再点开某一条 —— "从列表点进来"才是主路径。
    // 绝对路径曾经在 `detail()` 里才补，于是列表来源的条目在详情页里是空的、
    // "复制路径"复制到的也是相对路径。
    ({ json } = await getJson(`${base}/items?scope=`));
    const listed = json.items.find((item) => item.relPath === '笔记/hello.md');
    check('列表项带绝对路径', listed?.absolutePath, join(libRoot, '笔记', 'hello.md'));
    ({ json } = await getJson(`${base}/items?scope=&kind=image`));
    check('列表项里的目录也带绝对路径', json.items[0].absolutePath, join(libRoot, '图.png'));

    // ---- 详情
    ({ json } = await getJson(`${base}/item?path=${encodeURIComponent('笔记/hello.md')}`));
    check('详情 200', json.name, 'hello.md');
    check('详情带绝对路径', json.absolutePath, join(libRoot, '笔记', 'hello.md'));
    check('文本类标记可预览', json.text, true);
    check('未知类型不算文本', (await getJson(`${base}/item?path=图.png`)).json.text, false);

    ({ response, json } = await getJson(`${base}/item?path=nope.md`));
    check('详情找不到 404', response.status, 404);

    // ---- 分组树
    ({ json } = await getJson(`${base}/tree`));
    check('树含库根与子目录', json.folders.length, 1 + SEED_FOLDERS);
    check('库根在最前', json.folders[0].relPath, '');
    check('库根总数含子目录', json.folders[0].total, SEED_FILES);
    check('子目录直接文件数', json.folders[1].files, 2);

    // ---- /document：把文件解析成页面能直接渲染的结构
    //
    // 这一段守的是"页面不用自己解 zip / 自己猜分隔符"这条分工。四类出口各自的
    // 形状都在这里钉住，页面换渲染器时不会顺手改坏契约。
    const doc = async (relPath) => (await getJson(`${base}/document?path=${encodeURIComponent(relPath)}`));

    ({ json } = await doc('资料/storyboard.xlsx'));
    check('xlsx 出口是 sheet', json.kind, 'sheet');
    check('xlsx 工作表数', json.sheets.length, 2);
    check('xlsx 工作表名按工作簿顺序', json.sheets.map((s) => s.name), ['分镜表', '角色表']);
    check('xlsx 共享字符串被还原', json.sheets[0].rows[0], ['片名', '镜号', '景别', '运镜', '时长(秒)', '备注']);
    check('xlsx 稀疏列补位', json.sheets[0].rows[4].slice(0, 4), ['', '', '', '旋转']);
    check('xlsx 第二张表靠 rels 找到', json.sheets[1].rows[0], ['角色', '出场', '状态']);
    check('xlsx 回显 relPath 与格式', [json.relPath, json.format], ['资料/storyboard.xlsx', 'xlsx']);

    ({ json } = await doc('资料/stored.xlsx'));
    check('stored（不压缩）方式解出同样的表', json.sheets[0].rows[0], ['片名', '镜号', '景别', '运镜', '时长(秒)', '备注']);

    ({ json } = await doc('资料/script.docx'));
    check('docx 出口是 blocks', json.kind, 'blocks');
    check('docx 认出标题层级', [json.blocks[0].type, json.blocks[0].level, json.blocks[0].text], ['heading', 1, '醒来 · 分镜脚本']);
    check('docx 认出二级标题', [json.blocks[1].type, json.blocks[1].level], ['heading', 2]);
    check('docx 表格按文档顺序留在中间', json.blocks[7].type, 'table');
    check('docx 表格内容', json.blocks[7].rows, [['镜号', '景别', '备注'], ['S01', '中近景', '陈实低头'], ['']]);

    ({ json } = await doc('资料/引号.csv'));
    check('csv 出口是 sheet', [json.kind, json.format], ['sheet', 'csv']);
    check('csv 剥掉 UTF-8 BOM（第一个表头不被污染）', json.sheets[0].rows[0][0], '片名');
    check('csv 引号内的逗号不当分隔符', json.sheets[0].rows[1], ['醒来, 分镜', '第一行\n第二行']);
    check('csv 转义的双引号还原成一个', json.sheets[0].rows[2], ['他说"好"了', '尾']);
    check('csv 行数', json.sheets[0].rows.length, 3);

    ({ json } = await doc('资料/脚本.js'));
    check('代码走 code 形态', [json.kind, json.format], ['code', 'code']);
    check('代码原文', json.text, 'export const a = 1;\n');

    ({ json } = await doc('笔记/hello.md'));
    check('markdown 走 markdown 形态', [json.kind, json.format], ['markdown', 'markdown']);

    // 读不出来的那几类：状态码与 code 都要能区分，页面靠它决定给什么提示
    let r = await doc('资料/mismatch.docx');
    check('docx 内容其实是 xlsx → 422', r.response.status, 422);
    check('docx 内容其实是 xlsx → code', r.json.error.code, 'NOT_DOCX');
    r = await doc('资料/broken.docx');
    check('完全不是 zip → 415 还是 422 取决于内部判定', [415, 422].includes(r.response.status), true);
    r = await doc('资料/noworkbook.xlsx');
    check('xlsx 缺工作簿 → 422', r.response.status, 422);
    r = await doc('资料/老文档.doc');
    check('老 doc 是 415（不支持）而不是 500', r.response.status, 415);
    check('老 doc 的 code', r.json.error.code, 'UNSUPPORTED');
    check('老 doc 提示里说清了怎么转', r.json.error.message.includes('docx'), true);
    r = await doc('nope.md');
    check('不存在 → 404', r.response.status, 404);
    r = await doc('资料');
    check('目录不是文档 → 404', r.response.status, 404);
    r = await getJson(`${base}/document?path=${encodeURIComponent('../escape.md')}`);
    check('逃逸路径 → 400', r.response.status, 400);
    r = await getJson(`${base}/document`, { method: 'POST' });
    check('POST /document → 405', r.response.status, 405);

    // ---- 文件流
    let text;
    ({ response, text } = await getJson(`${base}/file?path=${encodeURIComponent('笔记/hello.md')}`));
    check('取文本文件 200', response.status, 200);
    check('文本 MIME', response.headers.get('content-type'), 'text/markdown');
    check('内容一致', text, '# 你好\n');
    check('带 accept-ranges', response.headers.get('accept-ranges'), 'bytes');
    check('禁止嗅探', response.headers.get('x-content-type-options'), 'nosniff');

    const rawUrl = `${base}/file?path=raw.txt`;
    ({ response, text } = await getJson(rawUrl));
    check('取纯文本 200', response.status, 200);
    check('全量内容', text, 'ABCDEFGHIJ');
    check('全量长度', response.headers.get('content-length'), '10');
    const etag = response.headers.get('etag');

    ({ response, text } = await getJson(rawUrl, { headers: { range: 'bytes=2-5' } }));
    check('Range 命中 206', response.status, 206);
    check('Range 内容', text, 'CDEF');
    check('Range 头', response.headers.get('content-range'), 'bytes 2-5/10');

    ({ response, text } = await getJson(rawUrl, { headers: { range: 'bytes=-3' } }));
    check('后缀 Range 206', response.status, 206);
    check('后缀 Range 内容', text, 'HIJ');

    ({ response } = await getJson(rawUrl, { headers: { range: 'bytes=999-' } }));
    check('越界 Range 416', response.status, 416);
    check('越界 Range 带上界', response.headers.get('content-range'), 'bytes */10');

    ({ response, text } = await getJson(rawUrl, { headers: { 'if-none-match': etag } }));
    check('ETag 命中 304', response.status, 304);
    check('304 不带体', text, '');

    ({ response } = await getJson(rawUrl, { method: 'HEAD' }));
    check('HEAD 200', response.status, 200);
    check('HEAD 带长度', response.headers.get('content-length'), '10');

    // ---- 收口：可带脚本的格式必须被沙箱化
    ({ response } = await getJson(`${base}/file?path=${encodeURIComponent('页面.html')}`));
    check('HTML 可读', response.status, 200);
    check('HTML MIME', response.headers.get('content-type'), 'text/html');
    check('HTML 强制沙箱', response.headers.get('content-security-policy'), 'sandbox');

    ({ response } = await getJson(`${base}/file?path=raw.txt`));
    check('普通文本不加 CSP', response.headers.get('content-security-policy'), null);

    // ---- 收口：路径逃逸与隐藏段
    ({ response, json } = await getJson(`${base}/file?path=${encodeURIComponent('../outside.txt')}`));
    check('路径逃逸 400', response.status, 400);
    check('路径逃逸信封', json.error.code, 'INVALID_PATH');

    ({ response, json } = await getJson(`${base}/file?path=${encodeURIComponent('..\\outside.txt')}`));
    check('反斜杠逃逸同样被挡', response.status, 400);

    ({ response, json } = await getJson(`${base}/file?path=${encodeURIComponent('.secret/hidden.txt')}`));
    check('隐藏段拒绝 403', response.status, 403);
    check('隐藏段信封', json.error.code, 'HIDDEN_PATH');

    ({ response, json } = await getJson(`${base}/file?path=C%3A%2FWindows%2Fwin.ini`));
    check('盘符路径被挡', response.status, 400);

    ({ response, json } = await getJson(`${base}/file?path=${encodeURIComponent('笔记')}`));
    check('目录不能当文件取', response.status, 400);
    check('目录信封', json.error.code, 'NOT_A_FILE');

    ({ response, json } = await getJson(`${base}/file`));
    check('缺 path 参数 400', response.status, 400);
    check('缺参信封', json.error.code, 'INVALID_PATH');

    ({ response } = await getJson(`${base}/file?path=raw.txt&download=1`));
    check('下载模式带 disposition', (response.headers.get('content-disposition') ?? '').startsWith('attachment'), true);

    // ---- 标注写入（唯一会写盘的路径）
    ({ response, json } = await getJson(`${base}/annotate`, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ path: '笔记/hello.md', tagsAdd: ['研究', '研究', '  '], note: '第一份资料' }),
    }));
    check('标注成功', response.status, 200);
    check('标签去重去空', json.tags, ['研究']);
    check('备注写入', json.note, '第一份资料');

    ({ json } = await getJson(`${base}/items?tag=${encodeURIComponent('研究')}`));
    check('可按标签检索', json.matched, 1);
    check('标签检索命中', json.items[0].relPath, '笔记/hello.md');

    ({ json } = await getJson(`${base}/items?q=第一份资料`));
    check('备注也进搜索', json.matched, 1);

    // 索引文件不该出现在清单里，也不该被当成可读文件
    ({ json } = await getJson(`${base}/items?parent=`));
    check('索引文件不进清单', json.matched, 5);
    ({ response, json } = await getJson(`${base}/file?path=.library-index.json`));
    check('索引文件不可读', response.status, 403);

    ({ response, json } = await getJson(`${base}/annotate`, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ path: '笔记/hello.md', tagsRemove: ['研究'] }),
    }));
    check('移除标签后备注仍在', json.note, '第一份资料');

    ({ response } = await getJson(`${base}/annotate`, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ path: '笔记/hello.md', note: '', tags: [] }),
    }));
    ({ json } = await getJson(`${base}/item?path=${encodeURIComponent('笔记/hello.md')}`));
    check('标注清空后不留空壳', json.tags, []);
    check('备注也清空', json.note, '');

    ({ response, json } = await getJson(`${base}/annotate`, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ path: 'nope.md', tags: ['x'] }),
    }));
    check('标注不存在的条目 404', response.status, 404);

    ({ response, json } = await getJson(`${base}/annotate`, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: 'not json',
    }));
    check('坏 JSON 体 400', response.status, 400);
    check('坏体信封', json.error.code, 'BAD_REQUEST');

    // ---- 批量标注（paths 数组）
    //
    // 与单条的两处差别要守住：请求体给的是**路径**、响应给的是**条目**；还有
    // `missing` —— 库里已经不存在的路径不能当成成功，得让面板能报"有 N 份没改成"。
    ({ response, json } = await getJson(`${base}/annotate`, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ paths: ['图.png', '页面.html', '笔记/hello.md', '已经没了.md'], tagsAdd: ['批量', '批量'] }),
    }));
    check('批量标注 200', response.status, 200);
    check('批量回三个条目', json.items.length, 3);
    check('批量回缺失路径', json.missing, ['已经没了.md']);
    check('批量标签去重', json.items[0].tags, ['批量']);
    check('批量条目带绝对路径', json.items[0].absolutePath, join(libRoot, '图.png'));
    check('批量没被截断', json.truncated, false);

    // 命中为空时不该碰磁盘（否则会造出一堆空条目）
    ({ response, json } = await getJson(`${base}/annotate`, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ paths: ['也不在了.md'], tagsAdd: ['x'] }),
    }));
    check('批量全不命中返回空', [json.items, json.missing], [[], ['也不在了.md']]);
    ({ json } = await getJson(`${base}/items?scope=&tag=${encodeURIComponent('x')}`));
    check('全不命中时没往索引里写东西', json.matched, 0);

    // paths 与 path 同时给：paths 优先（面板一次只会用一种）
    ({ response, json } = await getJson(`${base}/annotate`, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ path: 'raw.txt', paths: ['图.png'], note: '批量优先' }),
    }));
    check('paths 优先于 path', json.items.length, 1);
    check('paths 优先时用的是 paths', json.items[0].relPath, '图.png');

    // paths 必须是数组。非数组时**不**退回单条 —— 请求里同时给了 `path` 才该退回；
    // 只给一个畸形的 `paths` 应当直接拒掉，不然面板一个手误就会静默标错东西。
    ({ response, json } = await getJson(`${base}/annotate`, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ paths: '图.png', tagsAdd: ['x'] }),
    }));
    check('paths 不是数组且没给 path → 400', response.status, 400);
    ({ response, json } = await getJson(`${base}/annotate`, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ paths: '图.png', path: 'raw.txt', note: '退回单条' }),
    }));
    check('paths 畸形但给了 path → 退回单条', [response.status, json.relPath], [200, 'raw.txt']);

    // 批量去标签也要能跑通
    ({ response, json } = await getJson(`${base}/annotate`, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ paths: ['图.png', '页面.html'], tagsRemove: ['批量'] }),
    }));
    check('批量去标签', json.items.map((item) => item.tags), [[], []]);

    // ---- 重扫
    ({ response, json } = await getJson(`${base}/rescan`, { method: 'POST' }));
    check('重扫 200', response.status, 200);
    check('重扫条目数', json.items, SEED_FILES);
    check('重扫带耗时', typeof json.ms === 'number' && json.ms >= 0, true);

    ({ response, json } = await getJson(`${base}/rescan`));
    check('重扫不接受 GET', response.status, 405);

    // ---- 入库：只新增，绝不覆盖 ------------------------------------------------
    /** 发一个 JSON 请求并解析结果。 */
    const post = (path, body) => getJson(`${base}${path}`, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify(body),
    });

    ({ response, json } = await post('/mkdir', { parent: '', name: '归档' }));
    check('新建文件夹 201', response.status, 201);
    check('新建文件夹返回名称', json.name, '归档');
    check('新建文件夹返回相对路径', json.relPath, '归档');

    ({ json } = await getJson(`${base}/items?parent=`));
    checkTrue('新文件夹立刻出现在清单里', json.items.some((item) => item.name === '归档' && item.isDir === true));

    ({ json } = await post('/mkdir', { parent: '', name: '归档' }));
    check('同名文件夹自动改名而不是报错', json.name, '归档 (2)');

    // 小写同名也要撞上（Windows 文件系统不区分大小写）
    ({ json } = await post('/mkdir', { parent: '', name: '归档' }));
    check('再次同名继续往后编号', json.name, '归档 (3)');

    ({ json } = await post('/mkdir', { parent: '', name: '归档', tags: ['x'] }));
    check('同名去重不依赖调用次数上的巧合', json.name, '归档 (4)');

    ({ response, json } = await post('/mkdir', { parent: '', name: 'a/b' }));
    check('名称含斜杠 400', response.status, 400);
    check('非法名称信封', json.error.code, 'INVALID_NAME');

    ({ response } = await post('/mkdir', { parent: '', name: 'CON' }));
    check('Windows 保留名 400', response.status, 400);

    ({ response } = await post('/mkdir', { parent: '', name: '' }));
    check('空名称 400', response.status, 400);

    // 逃逸在路由层就被挡下（`parseRelPath` 先于内核跑），所以这里是 INVALID_PATH
    // 而不是内核的 INVALID_PARENT —— 两道门都在，前一道先响。
    ({ response, json } = await post('/mkdir', { parent: '../outside', name: 'x' }));
    check('父目录逃逸 400', response.status, 400);
    check('父目录逃逸在路由层被挡', json.error.code, 'INVALID_PATH');

    ({ response } = await post('/mkdir', { parent: '不存在的分组', name: 'x' }));
    check('父目录不存在 400', response.status, 400);

    ({ response, json } = await post('/mkdir', { parent: 'raw.txt', name: 'x' }));
    check('父目录是文件 400', response.status, 400);
    check('父目录是文件信封', json.error.code, 'NOT_A_FOLDER');

    ({ response, json } = await getJson(`${base}/mkdir`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: 'nope' }));
    check('新建端点也要合法 JSON', response.status, 400);

    // 新建文本
    ({ response, json } = await post('/create', { parent: '', name: '草稿.md', text: '# 草稿\n' }));
    check('新建文档 201', response.status, 201);
    check('新建文档回报字节数', json.bytes, Buffer.byteLength('# 草稿\n', 'utf8'));
    ({ text } = await getJson(`${base}/file?path=${encodeURIComponent('草稿.md')}`));
    check('新建文档内容写对了', text, '# 草稿\n');

    ({ json } = await post('/create', { parent: '归档', name: '子文件.md', text: '' }));
    check('能建在分组里', json.relPath, '归档/子文件.md');

    // 上传原始字节
    const uploadPayload = Buffer.from('hello upload', 'utf8');
    ({ response, json } = await getJson(`${base}/upload?name=${encodeURIComponent('上传.bin')}`, { method: 'POST', body: uploadPayload }));
    check('上传 201', response.status, 201);
    check('上传回报字节数', json.bytes, uploadPayload.length);
    check('上传回报名称', json.name, '上传.bin');
    ({ response, text } = await getJson(`${base}/file?path=${encodeURIComponent('上传.bin')}`));
    check('上传内容一致', text, 'hello upload');
    check('上传的类型是八位组流', response.headers.get('content-type'), 'application/octet-stream');

    ({ json } = await getJson(`${base}/upload?name=${encodeURIComponent('上传.bin')}`, { method: 'POST', body: uploadPayload }));
    check('重名上传自动改名', json.name, '上传 (2).bin');

    ({ response, json } = await getJson(`${base}/upload`, { method: 'POST', body: uploadPayload }));
    check('上传缺 name 400', response.status, 400);
    check('上传缺 name 信封', json.error.code, 'INVALID_NAME');

    ({ response } = await getJson(`${base}/upload?name=x.bin&parent=${encodeURIComponent('不存在的分组')}`, { method: 'POST', body: uploadPayload }));
    check('上传到不存在的分组 400', response.status, 400);

    ({ response } = await getJson(`${base}/mkdir`, { method: 'GET' }));
    check('新建端点不接受 GET', response.status, 405);

    // 半途失败的临时文件不会留在清单里
    ({ json } = await getJson(`${base}/items?q=.part`));
    check('没有遗留的临时文件', json.items, []);

    // 入库之后标注依然可用（索引与新增共存）
    ({ json } = await postJson(base, '/annotate', { path: '归档/子文件.md', tagsAdd: ['归档'] }));
    check('新入库的资料可以打标签', json.tags, ['归档']);
    ({ json } = await getJson(`${base}/items?tag=${encodeURIComponent('归档')}`));
    check('按标签检索到新资料', json.items[0].relPath, '归档/子文件.md');

    // ---- 库外扫描：只读候选（/external）-------------------------------------
    ({ response, json } = await getJson(`${base}/external?dir=${encodeURIComponent(sourceRoot)}`));
    check('外部扫描 200', response.status, 200);
    check('外部扫描回报源目录', json.source, sourceRoot);
    checkNames('外部扫描只列真内容', json.files, ['报告.md', '数据.csv', '深一层.md']);
    check('外部扫描不含依赖目录', json.files.some((item) => item.relPath.includes('node_modules')), false);
    check('外部扫描不含隐藏文件', json.files.some((item) => item.name.startsWith('.')), false);
    check('外部扫描跳过 .part', json.files.some((item) => item.name.endsWith('.part')), false);
    check('外部扫描带字节数', typeof json.files[0].size, 'number');

    ({ response } = await getJson(`${base}/external`));
    check('外部扫描缺 dir → 400', response.status, 400);
    ({ response } = await getJson(`${base}/external?dir=${encodeURIComponent('相对路径')}`));
    check('外部扫描相对路径 → 400', response.status, 400);
    ({ response } = await getJson(`${base}/external?dir=${encodeURIComponent(join(home, '没有这个目录'))}`));
    check('外部扫描目录不存在 → 400', response.status, 400);
    ({ response } = await getJson(`${base}/external?dir=${encodeURIComponent(join(sourceRoot, '报告.md'))}`));
    check('外部扫描源不是目录 → 400', response.status, 400);

    // ---- 批量导入：只复制、只新增（/import）----------------------------------
    ({ response, json } = await post('/import', { source: sourceRoot, entries: ['报告.md', '数据.csv'], parent: '' }));
    check('导入 201', response.status, 201);
    check('导入回报源目录', json.source, sourceRoot);
    check('导入两份', json.imported.length, 2);
    check('导入没有跳过', json.skipped.length, 0);
    check('导入保留来源相对路径', json.imported.map((item) => item.from), ['报告.md', '数据.csv']);
    check('导入字节数与源一致', json.imported[0].bytes, Buffer.byteLength('# 报告\n', 'utf8'));
    checkTrue('源文件仍在原处（只复制不移动）', existsSync(join(sourceRoot, '报告.md')));
    checkTrue('导入后出现在清单里', (await getJson(`${base}/items?parent=`)).json.items.some((item) => item.name === '报告.md'));

    // 撞名 → 去重，绝不覆盖
    ({ json } = await post('/import', { source: sourceRoot, entries: ['报告.md'], parent: '' }));
    check('导入撞名自动改名', json.imported[0].name, '报告 (2).md');

    // 子目录里的文件按最后一段命名，可以落进指定分组
    ({ json } = await post('/import', { source: sourceRoot, entries: ['子目录/深一层.md'], parent: '笔记' }));
    check('导入到指定分组', json.imported[0].relPath, '笔记/深一层.md');

    // 逐份跳过：一份坏的拖不垮其余
    ({ json } = await post('/import', { source: sourceRoot, entries: ['../外面.md', '不存在.md', '子目录'], parent: '' }));
    check('坏条目一份都不导入', json.imported.length, 0);
    check('坏条目逐份报出原因', json.skipped.map((item) => item.reason), ['INVALID_PATH', 'MISSING', 'NOT_A_FILE']);

    // 好的进、坏的跳过，互不影响
    ({ json } = await post('/import', { source: sourceRoot, entries: ['数据.csv', '不存在.md'], parent: '' }));
    check('混合导入的成功数', json.imported.length, 1);
    check('混合导入的跳过数', json.skipped.length, 1);

    // 参数校验
    ({ response } = await post('/import', { entries: ['报告.md'] }));
    check('导入缺 source → 400', response.status, 400);
    ({ response } = await post('/import', { source: sourceRoot, entries: [] }));
    check('导入空选择 → 400', response.status, 400);
    ({ response } = await post('/import', { source: sourceRoot, entries: [42] }));
    check('导入全是非法条目 → 400', response.status, 400);
    ({ response } = await post('/import', { source: join(sourceRoot, '报告.md'), entries: ['报告.md'] }));
    check('导入源不是目录 → 400', response.status, 400);
    ({ response } = await post('/import', { source: '相对路径', entries: ['报告.md'] }));
    check('导入源是相对路径 → 400', response.status, 400);
    ({ response } = await getJson(`${base}/import`));
    check('导入不接受 GET', response.status, 405);
});

// ================= reveal：唯一一个离开进程的端点 =================
//
// `spawn` 一个文件管理器是真的会把窗口弹到桌面上，测试里绝对不能真跑。所以这里
// 只验**契约与三道收口**，把 spawn 换成一个记录器：真的开窗口是"实现细节"，
// 路径拼错、开关没关、逃逸没挡才是会伤到用户的东西。
const spawnCalls = [];
mod.setSpawnForTest?.((command, args) => { spawnCalls.push({ command, args }); return { on() {}, unref() {} }; });
await withServer(routes[routes.length - 1], async (base) => {
    spawnCalls.length = 0;
    let { response, json } = await postJson(base, '/reveal', { path: '笔记/hello.md' });
    check('reveal 200', response.status, 200);
    check('reveal 回显路径', json.revealed, '笔记/hello.md');
    check('reveal 真的 spawn 了', spawnCalls.length, 1);
    if (process.platform === 'win32') {
        check('reveal 用 explorer', spawnCalls[0]?.command, 'explorer.exe');
        // 开关和路径必须拼成**同一个参数**：`/select,` 与路径分开传会被当成
        // 两个文件，explorer 会打开两个窗口。
        check('reveal 的 select 与路径同一个参数', spawnCalls[0]?.args, [`/select,${join(libRoot, '笔记', 'hello.md')}`]);
    }

    // 收口 1：文件不在库里就不许 reveal（否则就是让调用方拿它去开任意路径）
    ({ response, json } = await postJson(base, '/reveal', { path: '不在库里.md' }));
    check('reveal 对不在库里的条目 404', response.status, 404);

    // 收口 2：路径逃逸
    ({ response, json } = await postJson(base, '/reveal', { path: '../外面.md' }));
    check('reveal 挡逃逸 → 400', response.status, 400);
    ({ response, json } = await postJson(base, '/reveal', { path: '笔记/../../外面.md' }));
    check('reveal 挡中间的 .. → 400', response.status, 400);

    // 收口 3：隐藏段不进库，也不许 reveal
    ({ response, json } = await postJson(base, '/reveal', { path: '.secret/hidden.txt' }));
    check('reveal 挡隐藏段 → 403', response.status, 403);
    check('隐藏段的错误码', json.error.code, 'HIDDEN_PATH');

    ({ response } = await postJson(base, '/reveal', {}));
    check('reveal 缺 path → 400', response.status, 400);
    ({ response } = await getJson(`${base}/reveal`));
    check('reveal 不接受 GET', response.status, 405);
});
mod.setSpawnForTest?.(null);

// 开关关掉时：能力清单里不该有 reveal，端点直接 403
checkedApply(ctx, { root: libRoot, allowReveal: false });
await withServer(routes[routes.length - 1], async (base) => {
    let { response, json } = await getJson(`${base}/status`);
    check('关掉时能力清单里没有 reveal', json.capabilities.includes('reveal'), false);
    // 关掉 reveal 不该影响别的能力
    check('关掉 reveal 不影响其他能力', json.capabilities.includes('annotateMany'), true);
    ({ response, json } = await postJson(base, '/reveal', { path: 'raw.txt' }));
    check('关掉时 reveal 403', response.status, 403);
    check('关掉时的错误码', json.error.code, 'REVEAL_DISABLED');
});

// ================= 上传上限 =================
checkedApply(ctx, { root: libRoot, maxUploadBytes: 16 });
await withServer(routes[routes.length - 1], async (base) => {
    const big = Buffer.from('x'.repeat(64), 'utf8');
    let { response, json } = await getJson(`${base}/upload?name=big.bin`, { method: 'POST', body: big });
    check('超过上限 413', response.status, 413);
    check('超限信封', json.error.code, 'TOO_LARGE');

    ({ json } = await getJson(`${base}/items?q=big`));
    check('超限后没有留下文件', json.items, []);

    // 上限之内的还能正常进
    ({ response, json } = await getJson(`${base}/upload?name=small.bin`, { method: 'POST', body: Buffer.from('ok') }));
    check('上限之内照常入库', response.status, 201);
    check('小文件字节数', json.bytes, 2);
});

// ================= 信任栅栏 =================
await withServer(routes[routes.length - 1], async (base) => {
    connectionService = { requestRejection: () => 401 };
    let { response, json } = await getJson(`${base}/status`);
    check('栅栏拦下未信任请求', response.status, 401);
    check('栅栏信封', json.error.code, 'UNAUTHORIZED');

    connectionService = { requestRejection: () => true };
    ({ response } = await getJson(`${base}/status`));
    check('栅栏布尔拒绝映射成 403', response.status, 403);

    connectionService = { requestRejection: () => undefined };
    ({ response } = await getJson(`${base}/status`));
    check('栅栏放行后回到 200', response.status, 200);

    connectionService = undefined;
    ({ response } = await getJson(`${base}/status`));
    check('没有 Connection 服务时不做拦截', response.status, 200);
});

// ================= 卸载 =================
await rm(home, { recursive: true, force: true });

console.log(failed === 0 ? 'ALL PASS' : `${failed} FAILED`);
process.exit(failed === 0 ? 0 : 1);
