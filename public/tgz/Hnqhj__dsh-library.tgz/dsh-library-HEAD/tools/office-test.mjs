/**
 * Office 解析的测试。
 *
 * 夹具是 **python 的 zipfile 造的真实 zip**（`tools/make-office-fixtures.py`），
 * 不是手写的字节数组 —— 这一点很重要：手写夹具只能验「我以为的格式」，
 * 换成真实文件才会暴露「我理解错了格式」。
 *
 * 跑法：`node tools/office-test.mjs`
 */
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
import { readZipEntry, looksEncrypted, parseXlsx, parseDocx, isParsableOffice, OfficeError } from '../lib/office.js';

const here = dirname(fileURLToPath(import.meta.url));
const fixture = (name) => readFileSync(join(here, '..', 'docs', 'fixtures', name));

let passed = 0;
let failed = 0;
const failures = [];

function check(label, actual, expected) {
    const a = JSON.stringify(actual);
    const b = JSON.stringify(expected);
    if (a === b) {
        passed += 1;
    } else {
        failed += 1;
        failures.push(`${label}\n    实际 ${a}\n    期望 ${b}`);
    }
}

function checkTrue(label, value) {
    check(label, Boolean(value), true);
}

/** 断言某个动作抛出特定 code 的 OfficeError。 */
function checkThrows(label, code, fn) {
    try {
        fn();
    } catch (error) {
        if (error instanceof OfficeError && error.code === code) {
            passed += 1;
            return;
        }
        failed += 1;
        failures.push(`${label}\n    实际抛 ${error.name}/${error.code ?? '-'}：${error.message}\n    期望 code=${code}`);
        return;
    }
    failed += 1;
    failures.push(`${label}\n    实际没抛异常，期望 code=${code}`);
}

// ---------------------------------------------------------------- zip 读取器

const xlsxBuffer = fixture('storyboard.xlsx');
check('xlsx 读得出 sharedStrings', readZipEntry(xlsxBuffer, 'xl/sharedStrings.xml') !== null, true);
check('xlsx 读得出不存在的条目时返回 null', readZipEntry(xlsxBuffer, 'xl/nope.xml'), null);
check('xlsx 未被标记为加密', looksEncrypted(xlsxBuffer), false);
checkTrue('xlsx 是 zip（EOCD 在尾部 4KB 内）', readZipEntry(xlsxBuffer, '[Content_Types].xml') !== null);

// stored（方法 0）与 deflate（方法 8）两条分支
const storedBuffer = fixture('stored.xlsx');
check('stored 方式读得出内容长度一致',
    readZipEntry(storedBuffer, 'xl/workbook.xml').length,
    readZipEntry(xlsxBuffer, 'xl/workbook.xml').length);
check('deflate 与 stored 解出同样的字节',
    readZipEntry(storedBuffer, 'xl/worksheets/sheet1.xml').toString('utf8'),
    readZipEntry(xlsxBuffer, 'xl/worksheets/sheet1.xml').toString('utf8'));

// ---------------------------------------------------------------- xlsx

const book = parseXlsx(xlsxBuffer);
check('两个工作表', book.sheets.length, 2);
check('工作表名按工作簿顺序', book.sheets.map((s) => s.name), ['分镜表', '角色表']);
checkTrue('第二个工作表靠 rels 找到了（文件名是 sheet7 不是 sheet2）', book.sheets[1].rows.length > 0);

const rows = book.sheets[0].rows;
check('表头', rows[0], ['片名', '镜号', '景别', '运镜', '时长(秒)', '备注']);
check('共享字符串被还原成内容而不是下标', rows[1][0], '醒来');
check('数字单元格', rows[1][4], '3');
check('第二行', rows[2].slice(0, 4), ['醒来', 'S02', '全景', '横移']);

// 稀疏列：第 5 行第 1–3 格是 None（不出现），第 4 列必须有内容
check('稀疏列补位：第 4 列没被挤到第 1 列', rows[4][3], '旋转');
check('稀疏列补位：第 1 列是空串', rows[4][0], '');
check('内联字符串不走共享表', rows[4][5], '手写的一行');
check('空格子不追加到行尾', rows[1].length, 6);

// 尾部整行空的 <row> 应当被清掉：SHEET1 最后一行有内容，不该被动
check('最后一行保留', rows.length, 5);
check('末行长度按最后一个有值的列', rows[4].length, 6);
check('末行前 3 格是空串（稀疏补位）', rows[4].slice(0, 3), ['', '', '']);
check('末行没把第 4 列挤到第 1 列', rows[4][3], '旋转');

const roleRows = book.sheets[1].rows;
check('第二张表表头', roleRows[0], ['角色', '出场', '状态']);
check('第二张表数据', roleRows[1], ['陈实', '12', '冷']);

// 同一个 xlsx 的 stored 变体解析结果必须一致
const storedBook = parseXlsx(storedBuffer);
check('stored 变体解出同样的表格', storedBook.sheets[0].rows, rows);

// 坏文件
checkThrows('扩展名 .docx 内容是 xlsx', 'NOT_DOCX', () => parseDocx(fixture('mismatch.docx')));
checkThrows('完全不是 zip', 'NOT_A_ZIP', () => parseXlsx(fixture('broken.docx')));
checkThrows('空 buffer', 'NOT_A_ZIP', () => parseXlsx(Buffer.alloc(0)));
checkThrows('xlsx 缺工作簿', 'NOT_XLSX', () => parseXlsx(fixture('noworkbook.xlsx')));
checkThrows('docx 缺正文', 'NOT_DOCX', () => parseDocx(fixture('noworkbook.xlsx')));

// ---------------------------------------------------------------- docx

const doc = parseDocx(fixture('script.docx'));
const blocks = doc.blocks;
const types = blocks.map((b) => b.type);
// 夹具里「不要给正反打」没有 numPr（就是普通段落），后两条才是列表项。
check('块类型顺序：段落与表格按文档顺序', types,
    ['heading', 'heading', 'paragraph', 'heading', 'paragraph', 'list', 'list', 'table', 'paragraph', 'paragraph']);
check('一级标题', [blocks[0].level, blocks[0].text], [1, '醒来 · 分镜脚本']);
check('二级标题靠 styles.xml 认出 level', [blocks[1].level, blocks[1].text], [2, '第一场：老宅内景 · 日']);
check('三级标题', blocks[3].level, 3);
check('普通段落', blocks[2].text, '陈实坐在门槛上擦枪。他没有抬头。');
check('无 numPr 的段落不被当成列表', blocks[4].text, '不要给正反打');
check('列表二级（ilvl=1）', [blocks[5].level, blocks[5].text], [1, '保持门口在画面右侧']);
check('列表一级（ilvl=0，0 不是"没有值"）', blocks[6].level, 0);
check('表格在段落之间没有跑到末尾', blocks[7].rows,
    [['镜号', '景别', '备注'], ['S01', '中近景', '陈实低头'], ['']]);
check('空段落被丢掉，但后面的正文还在', blocks[8].text, '空段落之后还有正文，用来验证空段落被丢掉');
check('最后一段', blocks[9].text, '收尾：苏砚辞推门进来。');

// ---------------------------------------------------------------- 杂项

check('xlsx 可解析', isParsableOffice('.xlsx'), true);
check('docx 可解析', isParsableOffice('.docx'), true);
check('老 doc 不可解析', isParsableOffice('.doc'), false);
check('老 xls 不可解析', isParsableOffice('.xls'), false);
check('csv 不走 office 解析', isParsableOffice('.csv'), false);

// ---------------------------------------------------------------- 报告

console.log(`office: ${passed + failed} 项，${passed} 通过 / ${failed} 失败`);
if (failed > 0) {
    for (const line of failures) console.log(`  ✗ ${line}`);
    process.exitCode = 1;
}
