/**
 * 装好之后的一次性自检：回答「插件到底装对了没有」。
 *
 *   node tools/install-check.mjs
 *
 * ## 为什么需要它
 *
 * `file:` 装法下，**磁盘上装对了不等于 DSH 认它**。之前踩过的两次：
 *
 *  1. 改了 `client.js` 同步进 profile，界面上却还是旧界面 —— 客户端模块是
 *     **进程启动时**加载的，窗口刷新不够，必须重启。
 *  2. 看到 profile 的 `cordis.yml` 里没有自己的 loader 行，以为插件被卸载了 ——
 *     其实那个文件一直是 4 行空列表，插件树由 `package.json` 的 `bundles`
 *     加上各 bundle 自己的 `cordis.patch.yml` 拼成，`cordis.yml` **本来就不该**
 *     有那些行。
 *
 * 这两件事的共同点：**看错地方就会得出错误结论**。所以这里把"该看哪里"
 * 固化成断言 —— 每一条都指明它守的是什么，不做"看起来像"的形式检查。
 *
 * ## 边界：能查什么，不能查什么
 *
 * 能查：磁盘状态（声明、lock、文件、语法、STYLE 反引号、源码↔profile 一致性）。
 * **查不了**：DSH 进程里的实际加载结果。`/api/library/*` 是**进程内虚拟路由**，
 * 不监听任何 TCP 端口，curl 不出来；`F:\DSH` 下也只有 Electron 单体、没有 CLI，
 * 起不来第二个进程。所以「插件在运行时到底加载没加载」这一条只能由你重启后
 * 在界面上确认 —— 本脚本会在最后一行明确说出这一点，而不是假装查过了。
 *
 * 只读：只 stat / read，不写任何文件。
 */
import { readFile, stat } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { dirname, join, resolve } from 'node:path';

const here = dirname(fileURLToPath(import.meta.url));
const source = resolve(here, '..');
const home = process.env.DSH_HOME ?? 'C:\\Users\\Administrator\\.dsh';
const profile = process.env.DSH_PROFILE ?? 'desktop';
const profileDir = join(home, 'profiles', profile);

let failed = 0;
let passed = 0;

const check = (ok, label, detail = '') => {
    if (ok) {
        passed += 1;
        console.log(`ok   ${label}`);
        return;
    }
    failed += 1;
    console.log(`FAIL ${label}${detail === '' ? '' : `\n       ${detail}`}`);
};

const readJson = async (path) => JSON.parse(await readFile(path, 'utf8'));
const exists = async (path) => {
    try {
        await stat(path);
        return true;
    } catch {
        return false;
    }
};

console.log(`源      ${source}`);
console.log(`profile ${profileDir}\n`);

// ---------------------------------------------------------------- 1. 声明层
// bundles 里有这一项，插件树才会把它拼进来。缺了它，下面全部检查都无意义
// （插件根本没被 DSH 看见，"文件都对"反而更误导）。
const pkgPath = join(profileDir, 'package.json');
if (!await exists(pkgPath)) {
    console.log(`FAIL profile 不存在：${pkgPath}`);
    process.exit(1);
}
const profilePkg = await readJson(pkgPath);
const bundles = profilePkg?.dsh?.profile?.bundles ?? [];
check(bundles.includes('dsh-library'),
    'profile 声明里 bundles 含 dsh-library',
    `bundles = ${JSON.stringify(bundles)}\n       少了它插件根本不会被拼进插件树；补法：dsh plugin install，或手动加进 package.json 的 dsh.profile.bundles`);

const deps = profilePkg?.dependencies ?? {};
check(typeof deps['dsh-library'] === 'string' && deps['dsh-library'].startsWith('file:'),
    'dependencies 里 dsh-library 指向工作区（file: 协议）',
    `实际值 = ${JSON.stringify(deps['dsh-library'])}\n       指向别处的话，同步工作区不会影响这个 profile`);

// lock 缺条目时 pnpm 可能在下次 install 时把目录删掉重建 —— 那次同步就白做了。
const lockPath = join(profileDir, 'pnpm-lock.yaml');
if (await exists(lockPath)) {
    const lock = await readFile(lockPath, 'utf8');
    check(lock.includes('dsh-library'), 'pnpm-lock.yaml 里有 dsh-library 条目',
        'lock 里没有它，下次 pnpm install 可能把这个目录当陈旧依赖清掉');
} else {
    console.log('skip pnpm-lock.yaml 不存在（不是 pnpm 装的 profile）');
}

// ---------------------------------------------------------------- 2. 文件层
const target = join(profileDir, 'node_modules', 'dsh-library');
if (!await exists(target)) {
    check(false, 'node_modules/dsh-library 存在',
        `目录不存在：${target}\n       跑 tools\\dev-install.ps1 同步`);
} else {
    check(true, 'node_modules/dsh-library 存在');

    // 逐个比大小：改了源码没同步过去是最常见的"界面没变"，
    // 而只看文件存不存在分辨不出来。
    for (const name of ['index.js', 'client.js', 'cordis.patch.yml', 'package.json', 'icon.svg']) {
        const from = join(source, name);
        const to = join(target, name);
        if (!await exists(from) || !await exists(to)) {
            check(false, `${name} 两侧都在`, `源或目标缺失：${!await exists(from) ? from : to}`);
            continue;
        }
        const [a, b] = await Promise.all([stat(from), stat(to)]);
        check(a.size === b.size, `${name} 已同步（大小一致）`,
            `源 ${a.size} 字节 / profile ${b.size} 字节 —— 跑 tools\\sync-all.ps1`);
    }

    // lib/ 下每个模块都要在。少一个的话 require 在运行时才炸，而那时只有一个
    // 空白页面加一行控制台报错。
    const libDir = join(target, 'lib');
    const libFiles = ['config.js', 'service.js', 'routes.js', 'office.js', 'scan.js', 'store.js', 'kinds.js', 'paths.js', 'home.js', 'names.js'];
    const missing = [];
    for (const name of libFiles) {
        if (!await exists(join(libDir, name))) missing.push(name);
    }
    check(missing.length === 0, `lib/ 下 ${libFiles.length} 个模块齐全`,
        `缺：${missing.join(', ')}`);
}

// ---------------------------------------------------------------- 3. 插件自身声明
// 这三项与 asset-library 对照过，是 DSH 认 web 插件的方式。少一项都可能
// "文件在但客户端模块不加载"。
const libPkg = await readJson(join(target, 'package.json')).catch(() => null);
if (libPkg !== null) {
    check(libPkg?.dsh?.client?.platform === 'web', 'dsh.client.platform 是 web');
    check(libPkg?.dsh?.client?.immediately === true, 'dsh.client.immediately 是 true（不等用户交互就注入）');
    check(Array.isArray(libPkg?.dsh?.client?.inject) && libPkg.dsh.client.inject.includes('@deepseek-ai/dsh-client-ui-slots'),
        'dsh.client.inject 含 dsh-client-ui-slots',
        '没有 ui-slots 就没有 slots.inject，页面无处可挂');
    check(libPkg?.exports?.['./client'] === './client.js', 'exports["./client"] 指向 ./client.js');
    check(libPkg?.dsh?.bundle?.patch === './cordis.patch.yml', 'dsh.bundle.patch 指向 cordis.patch.yml');
}

// patch 文件：insert 列表是插件挂载的唯一途径。写错缩进或漏了 insert，
// 插件的 loader 根本不会被拼进树里 —— 而这**在 package.json 与 lock 里都看不出来**。
const patchText = await readFile(join(target, 'cordis.patch.yml'), 'utf8').catch(() => '');
check(/^-\s*insert:/mu.test(patchText), 'cordis.patch.yml 有 insert 段',
    '没有 insert 段 = 插件的 loader 永远不会被拼进插件树');
check(/name:\s*dsh-library/u.test(patchText), 'cordis.patch.yml 的 insert 里 name 是 dsh-library');
const rootMatch = /root:\s*'([^']*)'/u.exec(patchText);
check(rootMatch !== null && rootMatch[1] !== '',
    'cordis.patch.yml 配了库根 root',
    '没配会退回 <DSH_HOME>/library，也就是 C 盘');
if (rootMatch !== null) {
    const root = rootMatch[1];
    check(await exists(root), `库根存在：${root}`,
        '不存在也不影响运行（插件会自己建），但说明还没被真正用过');
    // 库根是真实文件副本，会长期长大。放系统盘是个后面很难迁的坑。
    check(!/^[Cc]:/u.test(root), '库根不在 C 盘', `当前在 ${root} —— 真实副本会长大，迁走很麻烦`);
}

// ---------------------------------------------------------------- 4. 客户端模块
const clientPath = join(target, 'client.js');
if (await exists(clientPath)) {
    const text = await readFile(clientPath, 'utf8');

    // STYLE 是模板字符串，正文里出现反引号会提前结束字符串，剩下的 CSS 变成
    // JS 表达式。症状是 `ReferenceError: xxx is not defined`，报错位置指向 CSS
    // 中段而不是任何一行看起来可疑的代码。这个坑踩过三次，所以钉一条断言。
    const start = text.indexOf('const STYLE = `');
    const end = text.indexOf('\n`;', start);
    check(start !== -1 && end > start, '找得到 STYLE 的范围');
    if (start !== -1 && end > start) {
        const ticks = text.slice(start, end).split('`').length - 1;
        check(ticks === 1, 'STYLE 模板字符串里只有一个反引号（注释里也不能有）',
            `数到 ${ticks} 个 —— 出现 2 个就已经截断了`);
    }

    // 匹配不能写死右括号：`slots.inject('sidebar.panellist', () => …)` 的第二个
    // 参数是工厂函数，闭括号位置随写法变。写成带右括号的形式就会在代码完全正确时
    // 报 FAIL —— 而一个总报错的检查等于没有检查。
    check(/slots\.inject\(\s*'sidebar\.panellist'/u.test(text), '注册了 sidebar.panellist（侧边栏入口）');
    check(/slots\.inject\(\s*'main'/u.test(text), '注册了 main 槽（页面本体）');
    // 右侧栏是刻意不给的：资料库是跨会话的中央库，从会话侧栏打开它坐标系是错的。
    // 这条不是"顺便查一下"，是守住阶段 5 那个决定别被改回去。
    check(!text.includes('dsh-client-ui-sidebar-right'), '没有引用右侧栏包（阶段 5 刻意移除）');
    check(!text.includes('sidebar.right.pane.tab'), '没有注册右侧栏 tab 正文');
}

console.log(`\n${failed === 0 ? `磁盘检查 ${passed} 项全过` : `${failed} 项不过 / ${passed} 项过`}`);

// 这一段不是客套话：磁盘全绿而界面不对过一次（2026-10-02）。那次的教训是
// 「磁盘检查通过」很容易被读成「装好了」，而它证明的只是文件在。
if (failed === 0) {
    console.log('');
    console.log('磁盘上一切正确。但这只证明**文件在**，不证明 **DSH 挂载了它** ——');
    console.log('这两件事脱节过一次。所以如果界面上仍然没有「资料库」，按顺序试：');
    console.log('');
    console.log('  1. 打开「插件」页，把 dsh-library 停用再启用');
    console.log('     —— 界面里唯一能改插件启停的地方，逼 Electron 重建这条 loader 行。');
    console.log('  2. 完全退出 DSH 再启动（托盘图标也要退），重开。');
    console.log('  3. 仍然不行：把这一段输出发我 —— desktop profile 由运行中的 Electron');
    console.log('     独占，CLI 读不到它的运行时状态（`dsh --profile desktop` 会报');
    console.log('     "managed exclusively by the Electron application"），');
    console.log('     所以那一步只能靠界面上的启停动作来触发。');
} else {
    console.log('');
    console.log('有不过的项 —— 先按上面每条的提示修，修完再跑一次。');
}
