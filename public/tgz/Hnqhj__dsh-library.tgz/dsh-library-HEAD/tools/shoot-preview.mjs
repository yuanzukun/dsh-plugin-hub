/**
 * 离屏预览截图（开发用）。
 *
 * 依赖 `render-preview.mjs` 先把 HTML 生成到 `docs/preview/`。用系统自带的
 * Edge/Chrome 无头模式按**精确视口**截图 —— 不依赖正在运行的 DSH，也不需要
 * 装 Playwright/Puppeteer（那要下几百 MB 浏览器）。
 *
 * 为什么值得单独一个脚本：`render-preview.mjs` 只能证明"结构在"，像素截图能证明
 * "排版对"。本轮就靠它抓到一个契约测试永远抓不到的 bug —— CSS 定义了却没渲染进
 * 元素树，整页在真机上是完全无样式的裸 HTML，而 className 断言全绿。
 *
 * 用法：
 *   node tools/render-preview.mjs      # 先生成 HTML
 *   node tools/shoot-preview.mjs       # 再截图
 *   node tools/shoot-preview.mjs grid  # 只截一个
 */
import { readdir, stat } from 'node:fs/promises';
import { spawn } from 'node:child_process';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { dirname, join, resolve } from 'node:path';
import { tmpdir } from 'node:os';

const here = dirname(fileURLToPath(import.meta.url));
const outDir = join(here, '..', 'docs', 'preview');

/**
 * 候选路径按顺序试；本机装在哪就用哪。
 *
 * 两个容易踩的坑：
 *  - 这个环境的 Edge 主程序叫 `Microsoft Edge.exe` 而不是 `msedge.exe`
 *    （`msedge.exe` 通常是同一目录下的另一个可执行入口）；
 *  - `EdgeWebView` 里那个 `msedgewebview2.exe` 是**运行时组件**，但它同样接受
 *    `--headless` / `--screenshot`，装在只有 WebView2 的机器上时是唯一可用的。
 *    它必须走带版本号的子目录（`Application/<版本>/`）。
 */
const BROWSERS = [
    'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',
    'C:/Program Files (x86)/Microsoft/Edge/Application/Microsoft Edge.exe',
    'C:/Program Files/Microsoft/Edge/Application/msedge.exe',
    'C:/Program Files/Microsoft/Edge/Application/Microsoft Edge.exe',
    'C:/Program Files/Google/Chrome/Application/chrome.exe',
    'C:/Program Files (x86)/Google/Chrome/Application/chrome.exe',
];

/** EdgeWebView 走版本号子目录，glob 一下取最新的那个。 */
async function webViewCandidates() {
    const root = 'C:/Program Files (x86)/Microsoft/EdgeWebView/Application';
    try {
        const names = (await readdir(root)).sort().reverse();
        return names
            .filter((name) => /^\d+[\d.]*$/u.test(name))
            .map((name) => `${root}/${name}/msedgewebview2.exe`);
    } catch {
        return [];
    }
}

async function findBrowser() {
    const tried = [...BROWSERS, ...(await webViewCandidates())];
    for (const candidate of tried) {
        try {
            await stat(candidate);
            return candidate;
        } catch {
            // 继续试下一个
        }
    }
    throw new Error(`找不到 Edge 或 Chrome。试过：\n${tried.join('\n')}`);
}

// 视口要比 #frame（1240×760）大一点，连 body 的 24px padding 一起框进去。
const WIDTH = 1296;
const HEIGHT = 812;

function shoot(browser, htmlPath) {
    return new Promise((resolvePromise, reject) => {
        const profile = join(tmpdir(), `dsl-shot-${process.pid}`);
        const child = spawn(browser, [
            '--headless=new',
            '--disable-gpu',
            '--hide-scrollbars',
            '--force-device-scale-factor=1',
            `--window-size=${WIDTH},${HEIGHT}`,
            `--user-data-dir=${profile}`,
            `--screenshot=${htmlPath.replace(/\.html$/u, '.png')}`,
            // 先 `file://` 打开再截，等页面真的画完。
            pathToFileURL(htmlPath).href,
        ], { stdio: ['ignore', 'pipe', 'pipe'] });
        let stderr = '';
        child.stderr.on('data', (chunk) => { stderr += String(chunk); });
        child.on('error', reject);
        child.on('exit', (code) => {
            if (code === 0) resolvePromise();
            else reject(new Error(`退出码 ${code}\n${stderr.slice(-600)}`));
        });
    });
}

const browser = await findBrowser();
const entries = (await readdir(outDir)).filter((name) => name.endsWith('.html'));
const wanted = process.argv.slice(2);
const targets = wanted.length > 0 ? entries.filter((name) => wanted.includes(name.replace(/\.html$/u, ''))) : entries;
if (targets.length === 0) {
    console.error('docs/preview 里没有 .html —— 先跑 node tools/render-preview.mjs');
    process.exit(1);
}

console.log(`browser: ${browser}`);
for (const name of targets) {
    const htmlPath = join(outDir, name);
    try {
        await shoot(browser, htmlPath);
        const png = htmlPath.replace(/\.html$/u, '.png');
        const size = (await stat(png)).size;
        console.log(`shot ${name.padEnd(20)} -> ${(size / 1024).toFixed(1)} KB`);
    } catch (error) {
        console.error(`FAIL ${name}: ${error.message}`);
        process.exitCode = 1;
    }
}
