# 造真实的 zip 夹具：python 脚本，跑在 Node 之外。
# 用 python 的 zipfile 是因为它是**第三方实现**—— 造出来的东西和我手写的解析器
# 没有共同代码，能真验出解析器的问题。用 node 自己写 zip 写入器造夹具的话，
# 写入器和读取器共享同一个错误理解，测试全绿而功能是坏的。
import sys, zipfile, io, os

out = sys.argv[1]
os.makedirs(out, exist_ok=True)

# ---------------------------------------------------------------- xlsx

SHARED = []


def shared_xml(items):
    si = "".join(
        "<si><t xml:space=\"preserve\">%s</t></si>" % s.replace("&", "&amp;").replace("<", "&lt;")
        for s in items
    )
    return ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<sst xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" count="%d" uniqueCount="%d">%s</sst>'
            % (len(items), len(items), si)).encode("utf-8")


def col_letter(i):
    s = ""
    i += 1
    while i:
        i, r = divmod(i - 1, 26)
        s = chr(65 + r) + s
    return s


def sheet_xml(rows):
    out = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
           '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">',
           "<sheetData>"]
    for r, row in enumerate(rows, start=1):
        out.append('<row r="%d">' % r)
        for c, val in enumerate(row):
            ref = "%s%d" % (col_letter(c), r)
            if val is None:
                continue  # 稀疏：这个格子不出现，解析器必须补位
            if isinstance(val, str):
                if val.startswith("#inline:"):
                    out.append('<c r="%s" t="inlineStr"><is><t>%s</t></is></c>' % (ref, val[8:]))
                else:
                    if val not in SHARED:
                        SHARED.append(val)
                    out.append('<c r="%s" t="s"><v>%d</v></c>' % (ref, SHARED.index(val)))
            else:
                out.append('<c r="%s"><v>%s</v></c>' % (ref, val))
        out.append("</row>")
    out.append("</sheetData></worksheet>")
    return "".join(out).encode("utf-8")


SHEET1 = [
    ["片名", "镜号", "景别", "运镜", "时长(秒)", "备注"],
    ["醒来", "S01", "中近景", "固定", 3, "陈实低头擦枪"],
    ["醒来", "S02", "全景", "横移", 8, None],
    ["醒来", "S03", "特写", "推", 2, None],
    [None, None, None, "旋转", 1, "#inline:手写的一行"],
]

SHEET2 = [
    ["角色", "出场", "状态"],
    ["陈实", 12, "冷"],
    ["陆沉渊", 9, "戒备"],
]

CONTENT_TYPES = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
 '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
 '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
 '<Default Extension="xml" ContentType="application/xml"/>'
 '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
 '<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
 '<Override PartName="/xl/worksheets/sheet2.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
 '<Override PartName="/xl/sharedStrings.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sharedStrings+xml"/>'
 "</Types>").encode("utf-8")

ROOT_RELS = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
 '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
 '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>'
 "</Relationships>").encode("utf-8")

# 故意让 sheet2 的文件名叫 sheet7：验证解析器是查 rels 而不是按位置猜。
WORKBOOK = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
 '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
 'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
 '<sheets>'
 '<sheet name="分镜表" sheetId="1" r:id="rId1"/>'
 '<sheet name="角色表" sheetId="2" r:id="rId2"/>'
 "</sheets></workbook>").encode("utf-8")

WORKBOOK_RELS = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
 '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
 '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>'
 '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet7.xml"/>'
 "</Relationships>").encode("utf-8")

# 顺序要紧：先把两张表都渲染成 xml（共享字符串表在渲染过程中被填满），
# 再写进 zip。反过来的话 sheet2 的字符串不在表里，造出来的是坏文件。
SHEET1_XML = sheet_xml(SHEET1)
SHEET2_XML = sheet_xml(SHEET2)

path = os.path.join(out, "storyboard.xlsx")
with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
    z.writestr("[Content_Types].xml", CONTENT_TYPES)
    z.writestr("_rels/.rels", ROOT_RELS)
    z.writestr("xl/workbook.xml", WORKBOOK)
    z.writestr("xl/_rels/workbook.xml.rels", WORKBOOK_RELS)
    z.writestr("xl/sharedStrings.xml", shared_xml(SHARED))
    z.writestr("xl/worksheets/sheet1.xml", SHEET1_XML)
    z.writestr("xl/worksheets/sheet7.xml", SHEET2_XML)
print("xlsx", os.path.getsize(path), "shared", len(SHARED))

# stored（不压缩）的一份，验证方法 0 分支
path = os.path.join(out, "stored.xlsx")
with zipfile.ZipFile(path, "w", zipfile.ZIP_STORED) as z:
    z.writestr("[Content_Types].xml", CONTENT_TYPES)
    z.writestr("_rels/.rels", ROOT_RELS)
    z.writestr("xl/workbook.xml", WORKBOOK)
    z.writestr("xl/_rels/workbook.xml.rels", WORKBOOK_RELS)
    z.writestr("xl/sharedStrings.xml", shared_xml(SHARED))
    z.writestr("xl/worksheets/sheet1.xml", SHEET1_XML)
    z.writestr("xl/worksheets/sheet7.xml", SHEET2_XML)
print("xlsx-stored", os.path.getsize(path))

# ---------------------------------------------------------------- docx

def para(text, style=None, ilvl=None, bold=False):
    ppr = ""
    if style:
        ppr += '<w:pStyle w:val="%s"/>' % style
    if ilvl is not None:
        ppr += "<w:numPr><w:ilvl w:val=\"%d\"/><w:numId w:val=\"1\"/></w:numPr>" % ilvl
    ppr = "<w:pPr>%s</w:pPr>" % ppr if ppr else ""
    rpr = "<w:rPr><w:b/></w:rPr>" if bold else ""
    return "<w:p>%s<w:r>%s<w:t xml:space=\"preserve\">%s</w:t></w:r></w:p>" % (ppr, rpr, text)


def cell(text):
    return "<w:tc><w:p><w:r><w:t>%s</w:t></w:r></w:p></w:tc>" % text


def table(rows):
    trs = ""
    for r in rows:
        trs += "<w:tr>%s</w:tr>" % "".join(cell(c) for c in r)
    return "<w:tbl>%s</w:tbl>" % trs


DOC_BODY = (
    para("醒来 · 分镜脚本", style="Heading1", bold=True)
    + para("第一场：老宅内景 · 日", style="Heading2")
    + para("陈实坐在门槛上擦枪。他没有抬头。")
    + para("要点", style="Heading3")
    + para("不要给正反打")
    + para("保持门口在画面右侧", ilvl=1)
    + para("陆沉渊从画外进画", ilvl=0)
    + table([["镜号", "景别", "备注"], ["S01", "中近景", "陈实低头"], [""]])
    + para("空段落之后还有正文，用来验证空段落被丢掉")
    + "<w:p></w:p>"
    + para("收尾：苏砚辞推门进来。")
)

DOCUMENT = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
 '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">'
 "<w:body>%s<w:sectPr/></w:body></w:document>" % DOC_BODY).encode("utf-8")

STYLES = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
 '<w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">'
 '<w:style w:type="paragraph" w:styleId="Heading1"><w:name w:val="heading 1"/></w:style>'
 '<w:style w:type="paragraph" w:styleId="Heading2"><w:name w:val="heading 2"/></w:style>'
 '<w:style w:type="paragraph" w:styleId="Heading3"><w:name w:val="heading 3"/></w:style>'
 "</w:styles>").encode("utf-8")

DOCX_CT = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
 '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
 '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
 '<Default Extension="xml" ContentType="application/xml"/>'
 '<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>'
 '<Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/>'
 "</Types>").encode("utf-8")

DOCX_RELS = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
 '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
 '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>'
 "</Relationships>").encode("utf-8")

path = os.path.join(out, "script.docx")
with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
    z.writestr("[Content_Types].xml", DOCX_CT)
    z.writestr("_rels/.rels", DOCX_RELS)
    z.writestr("word/document.xml", DOCUMENT)
    z.writestr("word/styles.xml", STYLES)
print("docx", os.path.getsize(path))

# 扩展名是 .docx 但内容是 xlsx：验 NOT_DOCX
path = os.path.join(out, "mismatch.docx")
with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
    z.writestr("[Content_Types].xml", CONTENT_TYPES)
    z.writestr("xl/workbook.xml", WORKBOOK)
print("mismatch", os.path.getsize(path))

# 是 zip、内容也是 xlsx 的零件，但没有 workbook.xml：验 NOT_XLSX
path = os.path.join(out, "noworkbook.xlsx")
with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
    z.writestr("[Content_Types].xml", CONTENT_TYPES)
    z.writestr("xl/worksheets/sheet1.xml", sheet_xml(SHEET1))
print("noworkbook", os.path.getsize(path))

# 完全不是 zip
path = os.path.join(out, "broken.docx")
with open(path, "wb") as f:
    f.write(b"this is definitely not a zip file, not even close" * 10)
print("broken", os.path.getsize(path))
