# Install dsh-library into a dsh profile without relying on `dsh plugin add`.
#
# Why the manual package.json edit: `dsh plugin add <path>` writes a `link:` spec
# and does NOT add the package to `dsh.profile.bundles`. Without a bundles entry the
# plugin never enters the composition tree, and a `link:` spec is a junction whose
# realpath lands outside the profile, so `@deepseek-ai/*` stops resolving. This
# script writes the two things that actually matter and then lets pnpm do the copy.
#
# Usage:
#   powershell -NoProfile -ExecutionPolicy Bypass -File tools\install-desktop.ps1
#   powershell -NoProfile -ExecutionPolicy Bypass -File tools\install-desktop.ps1 -Restore
param(
    [string]$Dsh = 'F:\DSH\resources\runtime\cli\bin\dsh.cmd',
    [string]$DshHome = 'C:\Users\Administrator\.dsh',
    [string]$Profile = 'desktop',
    [string]$Source = 'D:\dsh-library',
    [string]$Package = 'dsh-library',
    [switch]$Restore
)

$ErrorActionPreference = 'Stop'
$profileDir = Join-Path $DshHome "profiles\$Profile"
$manifest = Join-Path $profileDir 'package.json'
$backup = Join-Path $profileDir 'package.json.bak-before-dsh-library'

if (-not (Test-Path -LiteralPath $manifest)) { throw "profile manifest missing: $manifest" }

if ($Restore) {
    if (-not (Test-Path -LiteralPath $backup)) { throw "no backup to restore from: $backup" }
    Copy-Item -LiteralPath $backup -Destination $manifest -Force
    Write-Output "restored $manifest from backup"
    exit 0
}

# The manifest is UTF-8. Windows PowerShell 5.1 decodes BOM-less UTF-8 as ANSI, so
# it must be read and written explicitly or non-ASCII paths get mangled.
$utf8 = New-Object System.Text.UTF8Encoding($false)
$text = [System.IO.File]::ReadAllText($manifest, [System.Text.Encoding]::UTF8)
$json = $text | ConvertFrom-Json

if (-not (Test-Path -LiteralPath $backup)) {
    Copy-Item -LiteralPath $manifest -Destination $backup -Force
    Write-Output "backup written: $backup"
}

# A `file:` spec makes pnpm copy the package in as a real directory.
$spec = 'file:' + ($Source -replace '\\', '/')

if ($null -eq $json.dependencies) {
    $json | Add-Member -NotePropertyName dependencies -NotePropertyValue ([pscustomobject]@{})
}
$existing = $json.dependencies.PSObject.Properties[$Package]
if ($null -eq $existing) {
    $json.dependencies | Add-Member -NotePropertyName $Package -NotePropertyValue $spec
    Write-Output "dependencies += $Package = $spec"
}
else {
    $json.dependencies.$Package = $spec
    Write-Output "dependencies ~ $Package = $spec"
}

$bundles = @($json.dsh.profile.bundles)
if ($bundles -notcontains $Package) {
    $json.dsh.profile.bundles = @($bundles + $Package)
    Write-Output "bundles += $Package"
}
else {
    Write-Output "bundles already contains $Package"
}

$out = $json | ConvertTo-Json -Depth 20
[System.IO.File]::WriteAllText($manifest, $out + "`n", $utf8)
Write-Output "wrote $manifest"

if (-not (Test-Path -LiteralPath $Dsh)) { throw "dsh CLI not found: $Dsh" }
Write-Output "== dsh plugin --profile $Profile install =="
& $Dsh plugin --profile $Profile install
Write-Output "exit: $LASTEXITCODE"

$target = Join-Path $profileDir "node_modules\$Package"
if (Test-Path -LiteralPath $target) {
    $count = (Get-ChildItem -LiteralPath $target -Recurse -File | Measure-Object).Count
    Write-Output "installed: $target ($count files)"
}
else {
    Write-Output "WARN: $target not found after install"
}
Write-Output "Restart DeepSeek Harness to load the host half."
