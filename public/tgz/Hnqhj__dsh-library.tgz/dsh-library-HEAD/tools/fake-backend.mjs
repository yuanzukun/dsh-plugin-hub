/**
 * 假后端 + 夹具（共享模块）。
 *
 * 它不是一个「见招招」的桩：`listFrom` 与 `facetsFrom` 按**宿主内核的同一套语义**
 * 实现 —— `scope` 子树、`q` 搜路径/标签/备注、`kind`、`tag`、`sort`/`dir`/`limit`，
 * 以及按范围计数的 facet。共享出来是为了让契约测试与离屏预览看到**同一个世界**：
 * 预览里点开的那份资料，就是测试断言过的那一份。
 *
 * 另一处不保真会立刻咬人的地方：`/items` 必须在载荷里带 `absolutePath`。产品端
 * `service.toWire(item, root)` 是在投影层就补上的（不是 `detail()` 才补），因为面板
 * 几乎总是先渲染列表、再点开某一条。夹具漏了这个字段，「详情页绝对路径」那条断言
 * 在测试里是过的、在真机上是空的。
 */

export const at = (day, hour = 9) => new Date(2026, 9, day, hour, 0).getTime();

/**
 * relPath → 记录。刻意混进子目录、标签、文本与非文本。
 *
 * 四类可预览内容各有一份**真实存在**的样本（`.md` / `.csv` / `.xlsx` /
 * `.docx`），再加一个代码文件与一个不支持的老格式 —— 右栏的四种渲染器与
 * "读不了"那条分支都要有各自的触发点，只放 `.md` 的话其余三条路径永远
 * 走不到，测出来"绿"其实什么都没测。
 *
 * 目录刻意做成**三层**（`分镜/ep01.md`、`图片/角色/立绘.png`）：
 * 两层时"子目录该挂在谁下面"这件事是唯一的，树上少一环也看不出来。
 */
export const FIXTURE = [
    { relPath: '说明.md', kind: 'doc', size: 1640, tags: ['指南'], note: '', mtimeMs: at(1, 9) },
    { relPath: '分镜/ep01.md', kind: 'doc', size: 820, tags: ['分镜'], note: '第一集', mtimeMs: at(2, 10) },
    { relPath: '分镜/ep02.md', kind: 'doc', size: 910, tags: ['分镜', '待改'], note: '', mtimeMs: at(3, 11) },
    { relPath: '分镜/第二集/分镜表.xlsx', kind: 'sheet', size: 24576, tags: ['分镜'], note: '两集合表', mtimeMs: at(4, 9) },
    { relPath: '分镜/第二集/剧本.docx', kind: 'doc', size: 18432, tags: ['分镜'], note: '', mtimeMs: at(4, 10) },
    { relPath: '数据/表.csv', kind: 'sheet', size: 2048, tags: [], note: '', mtimeMs: at(4, 12) },
    { relPath: '数据/配置.json', kind: 'file', size: 640, tags: [], note: '', mtimeMs: at(4, 13) },
    { relPath: '图片/封面.png', kind: 'image', size: 215000, tags: ['主封面'], note: '', mtimeMs: at(5, 13) },
    { relPath: '图片/角色/立绘.png', kind: 'image', size: 336000, tags: ['人物设定'], note: '', mtimeMs: at(6, 14) },
    { relPath: '视频/ep01.mp4', kind: 'video', size: 496000, tags: ['分镜'], note: '', mtimeMs: at(7, 15) },
    { relPath: '音频/旁白.mp3', kind: 'audio', size: 657000, tags: ['音乐'], note: '', mtimeMs: at(8, 16) },
    { relPath: '归档/老文档.doc', kind: 'doc', size: 45056, tags: [], note: '', mtimeMs: at(8, 17) },
];
export const TEXT_EXTS = new Set(['.md', '.csv', '.json', '.js', '.ts', '.py', '.txt', '.yml', '.html', '.xml']);
export const extOf = (name) => {
    const cut = name.lastIndexOf('.');
    return cut === -1 ? '' : name.slice(cut).toLowerCase();
};
export const rowsOf = () => FIXTURE.map((row) => ({
    ...row,
    name: row.relPath.split('/').pop(),
    parent: row.relPath.includes('/') ? row.relPath.slice(0, row.relPath.lastIndexOf('/')) : '',
    isDir: false,
    ext: extOf(row.relPath),
    text: TEXT_EXTS.has(extOf(row.relPath)),
}));
export const inScope = (relPath, scope) => scope === '' || relPath.startsWith(`${scope}/`);

/** 库根拼绝对路径。与 `service.toWire(item, root)` 同一套。 */
export const absoluteOf = (relPath) => `D:\\dsh-library-data\\${relPath.replace(/\//gu, '\\')}`;

/** 与 `service.list()` 的检索模式同语义。 */
export function listFrom(params) {
    const scope = params.get('scope') ?? '';
    const q = (params.get('q') ?? '').trim().toLowerCase();
    const kind = params.get('kind') ?? '';
    const tag = params.get('tag') ?? '';
    const sort = params.get('sort') ?? 'mtime';
    const dir = params.get('dir') === 'asc' ? 1 : -1;
    const limit = Number(params.get('limit') ?? '60');
    let out = rowsOf().filter((row) => inScope(row.relPath, scope));
    if (kind !== '') out = out.filter((row) => row.kind === kind);
    if (tag !== '') out = out.filter((row) => row.tags.includes(tag));
    // 「最近添加」与 `service.list()` 同语义：按 mtime 窗口筛，不是搜文件名。
    const recent = Number(params.get('recent') ?? '0');
    if (Number.isFinite(recent) && recent > 0) {
        const cut = Date.now() - recent * 24 * 3600 * 1000;
        out = out.filter((row) => row.mtimeMs >= cut);
    }
    if (q !== '') {
        out = out.filter((row) => row.relPath.toLowerCase().includes(q)
            || row.tags.some((value) => value.toLowerCase().includes(q))
            || row.note.toLowerCase().includes(q));
    }
    out = [...out].sort((a, b) => {
        if (sort === 'name') return dir * a.name.localeCompare(b.name, 'zh-Hans-CN');
        if (sort === 'size') return dir * (a.size - b.size);
        return dir * (a.mtimeMs - b.mtimeMs);
    });
    return {
        mode: 'search',
        scope,
        q,
        kind,
        tag,
        sort,
        dir: dir === 1 ? 'asc' : 'desc',
        total: rowsOf().length,
        matched: out.length,
        items: out.slice(0, limit).map((row) => ({ ...row, absolutePath: absoluteOf(row.relPath) })),
        truncated: false,
    };
}

/** 与 `service.facets(scope)` 同语义：计数跟着范围走，目录只列直接子目录。 */
export function facetsFrom(scope) {
    const files = rowsOf().filter((row) => inScope(row.relPath, scope));
    const kindCounts = new Map();
    const tagCounts = new Map();
    for (const row of files) {
        kindCounts.set(row.kind, (kindCounts.get(row.kind) ?? 0) + 1);
        for (const value of row.tags) tagCounts.set(value, (tagCounts.get(value) ?? 0) + 1);
    }
    const dirs = [...new Set(rowsOf().map((row) => row.parent))]
        .filter((parent) => parent !== '' && parent.startsWith(scope === '' ? '' : `${scope}/`))
        .filter((parent) => {
            const rest = scope === '' ? parent : parent.slice(scope.length + 1);
            return !rest.includes('/');
        })
        .sort();
    return {
        scope,
        parent: scope === '' ? null : (scope.includes('/') ? scope.slice(0, scope.lastIndexOf('/')) : ''),
        total: files.length,
        whole: rowsOf().length,
        kinds: [...kindCounts.entries()].map(([kind, count]) => ({ kind, count })),
        tags: [...tagCounts.entries()].map(([tag, count]) => ({ tag, count })).sort((a, b) => b.count - a.count),
        folders: dirs.map((relPath) => ({
            relPath,
            name: relPath.split('/').pop(),
            total: rowsOf().filter((row) => inScope(row.relPath, relPath)).length,
        })),
    };
}

/**
 * 与 `service.tree()` 同语义：目录树 + 最近修改的一批。
 *
 * `folders` 是**扁平**的（每条带 relPath，父目录靠前缀推），这与真后端一致 ——
 * 客户端负责把它拼成树。假后端要是自己拼好嵌套，两边形状就不同了，
 * 而"形状不同"正是这一层最该被测出来的东西。
 */
export function treeFrom() {
    const all = rowsOf();
    const dirs = new Map();
    for (const row of all) {
        // 一条 `a/b/c.md` 要把 `a`、`a/b` 都登记上。
        let at = row.parent;
        while (at !== '') {
            if (!dirs.has(at)) dirs.set(at, 0);
            dirs.set(at, dirs.get(at) + 1);
            at = at.includes('/') ? at.slice(0, at.lastIndexOf('/')) : '';
        }
    }
    const recentCut = Date.now() - 7 * 24 * 3600 * 1000;
    return {
        root: 'D:\\dsh-library-data',
        exists: true,
        total: all.length,
        truncated: false,
        scannedAtMs: at(9),
        folders: [
            { relPath: '', name: '', parent: null, total: all.length, files: 0 },
            ...[...dirs.entries()].map(([relPath, total]) => ({
                relPath,
                name: relPath.split('/').pop(),
                parent: relPath.includes('/') ? relPath.slice(0, relPath.lastIndexOf('/')) : '',
                total,
                files: all.filter((row) => row.parent === relPath).length,
            })),
        ],
        recent: all
            .filter((row) => row.mtimeMs >= recentCut)
            .sort((a, b) => b.mtimeMs - a.mtimeMs)
            .slice(0, 50)
            .map((row) => ({ relPath: row.relPath, mtimeMs: row.mtimeMs })),
    };
}

/**
 * 与 `service.document()` 同语义：四类出口。
 *
 * 按扩展名分派，返回的形状必须与真后端**逐字段一致** —— 客户端按 `kind`
 * 分派到不同渲染器，形状差一个字段就会渲染成空白或者抛异常。
 */
export function documentFor(relPath) {
    const row = rowsOf().find((candidate) => candidate.relPath === relPath);
    if (row === undefined) {
        return { ok: false, status: 404, code: 'NOT_FOUND' };
    }
    const meta = {
        relPath: row.relPath,
        name: row.name,
        ext: row.ext,
        bytes: row.size,
        mtimeMs: row.mtimeMs,
    };
    if (row.ext === '.xlsx' || row.ext === '.csv') {
        return {
            ok: true,
            status: 200,
            json: {
                ...meta, kind: 'sheet', format: row.ext === '.csv' ? 'csv' : 'xlsx', truncated: false,
                sheets: [{
                    name: row.ext === '.csv' ? '' : '分镜表',
                    rows: [
                        ['片名', '镜号', '景别', '运镜'],
                        ['醒来', 'S01', '中近景', '固定'],
                        ['醒来', 'S02', '全景', '横移'],
                    ],
                    truncated: false,
                }],
            },
        };
    }
    if (row.ext === '.docx') {
        return {
            ok: true,
            status: 200,
            json: {
                ...meta, kind: 'blocks', format: 'docx',
                blocks: [
                    { type: 'heading', level: 1, text: '醒来 · 分镜脚本' },
                    { type: 'heading', level: 2, text: '第一场：老宅内景 · 日' },
                    { type: 'paragraph', text: '陈实坐在门槛上擦枪。他没有抬头。' },
                    { type: 'list', level: 0, text: '不要给正反打' },
                    { type: 'list', level: 1, text: '保持门口在画面右侧' },
                    {
                        type: 'table',
                        rows: [['镜号', '景别', '备注'], ['S01', '中近景', '陈实低头']],
                    },
                    { type: 'paragraph', text: '收尾：苏砚辞推门进来。' },
                ],
            },
        };
    }
    if (row.ext === '.md' || row.ext === '.markdown') {
        return {
            ok: true,
            status: 200,
            json: { ...meta, kind: 'markdown', format: 'markdown', text: '# 你好\n\n这是**分镜脚本**。\n\n- 第一场\n- 第二场\n', truncated: false },
        };
    }
    if (TEXT_EXTS.has(row.ext) || row.ext === '.json' || row.ext === '.js') {
        return {
            ok: true,
            status: 200,
            json: { ...meta, kind: row.ext === '.json' ? 'json' : 'code', format: row.ext === '.json' ? 'json' : 'code', text: '{ "a": 1 }\n', truncated: false },
        };
    }
    // 读不了的那几类：错误响应带 code，页面靠它选提示文案。
    if (row.ext === '.doc' || row.ext === '.xls') {
        return { ok: false, status: 415, code: 'UNSUPPORTED' };
    }
    return { ok: false, status: 422, code: 'CORRUPT' };
}

export const CAPS = ['status', 'items', 'item', 'tree', 'facets', 'file', 'document', 'mkdir', 'create', 'upload', 'annotate', 'annotateMany', 'rescan', 'external', 'import', 'reveal'];
export const statusPayload = {
    name: 'library',
    root: 'D:\\dsh-library-data',
    rootSource: 'config',
    exists: true,
    items: FIXTURE.length,
    folders: 4,
    bytes: FIXTURE.reduce((sum, row) => sum + row.size, 0),
    truncated: false,
    scannedAtMs: at(9),
    maxUploadBytes: 67108864,
    capabilities: CAPS,
};

export const calls = [];
// 用 getter 函数而不是裸导出：调用方要能在自己的测试里整体换掉后端
// （"空库"、"宿主连不上"、"能力协商缺项"），`export let` 的话 import 方读到的是
// 初始快照，赋值不生效 —— 表现为"改了 responder 但请求还是走老的"。
let currentResponder = () => ({ ok: true, status: 200, json: async () => ({}) });
export const setResponder = (fn) => { currentResponder = fn; };
export const getResponder = () => currentResponder;
globalThis.fetch = async (url, init) => {
    const method = init?.method ?? 'GET';
    const parsed = new URL(url, 'http://localhost');
    let body;
    try {
        body = typeof init?.body === 'string' ? JSON.parse(init.body) : init?.body;
    } catch {
        body = init?.body;
    }
    // 挂到 parsed 上：`responder` 只收得到 `parsed`，请求体必须一起传进去。
    // （之前只在 fetch 的局部变量里，于是 responder 里读 `body` 直接
    // ReferenceError —— 表现为「保存后提示是 操作失败: body is not defined」，
    // 而请求其实早就发出去了。）
    parsed.body = body;
    calls.push({ method, path: parsed.pathname, params: parsed.searchParams, body });
    return currentResponder(parsed, method, init);
};

export function ok(payload, status = 200) {
    return { ok: true, status, headers: { get: () => null }, json: async () => payload, text: async () => JSON.stringify(payload) };
}

/**
 * 错误响应。`code` 必须放进 `error.code` —— 客户端的 `callApi` 从那里取，
 * 页面再按 code 选提示文案（加密 / 损坏 / 不支持是三种不同的说法）。
 */
export function fail(status, code, message = code) {
    return {
        ok: false,
        status,
        headers: { get: () => null },
        json: async () => ({ error: { code, message } }),
        text: async () => JSON.stringify({ error: { code, message } }),
    };
}

export function libraryResponder(overrides = {}) {
    return (parsed, method) => {
        const path = parsed.pathname;
        const body = parsed.body ?? {};
        if (path.endsWith('/status')) return ok({ ...statusPayload, ...(overrides.status ?? {}) });
        if (path.endsWith('/items')) return ok(listFrom(parsed.searchParams));
        if (path.endsWith('/facets')) return ok(facetsFrom(parsed.searchParams.get('scope') ?? ''));
        if (path.endsWith('/tree')) return ok(treeFrom());
        if (path.endsWith('/document')) {
            const result = documentFor(parsed.searchParams.get('path') ?? '');
            return result.ok ? ok(result.json) : fail(result.status, result.code);
        }
        if (path.endsWith('/item')) {
            const wanted = parsed.searchParams.get('path');
            const row = rowsOf().find((candidate) => candidate.relPath === wanted);
            return row === undefined
                ? fail(404, 'NOT_FOUND', 'no such entry')
                : ok({ ...row, absolutePath: absoluteOf(wanted) });
        }
        if (path.endsWith('/annotate')) {
            const patch = body;
            const apply = (row) => {
                let tags = row.tags;
                if (Array.isArray(patch.tags)) tags = patch.tags;
                if (Array.isArray(patch.tagsAdd)) tags = [...new Set([...tags, ...patch.tagsAdd])];
                if (Array.isArray(patch.tagsRemove)) tags = tags.filter((value) => !patch.tagsRemove.includes(value));
                return { ...row, tags, note: patch.note ?? row.note };
            };
            // 批量：请求体给的是**路径**，响应得回条目本身（真实内核是把路径解析成
            // 条目再投影回去的）。早前这里直接把路径串当行传给 apply，于是
            // `row.tags` 是 undefined，`[...tags]` 抛 `tags is not iterable` ——
            // 面板侧只能报「操作失败」，看着像产品坏了，其实是假后端不保真。
            if (Array.isArray(patch.paths)) {
                const items = [];
                const missing = [];
                for (const relPath of patch.paths) {
                    const row = rowsOf().find((candidate) => candidate.relPath === relPath);
                    if (row === undefined) missing.push(relPath);
                    else items.push(apply(row));
                }
                return ok({ items, missing, truncated: false });
            }
            const row = rowsOf().find((candidate) => candidate.relPath === patch.path);
            return row === undefined
                ? { ok: false, status: 404, json: async () => ({ error: { code: 'NOT_FOUND', message: 'no such entry' } }) }
                : ok(apply(row));
        }
        if (path.endsWith('/reveal')) return ok({ revealed: body.path ?? '' });
        if (path.endsWith('/rescan')) return ok({ items: FIXTURE.length, folders: 4, truncated: false, ms: 4 });
        if (path.endsWith('/mkdir')) return ok({ relPath: '新分组', name: '新分组', isDir: true }, 201);
        if (path.endsWith('/create')) return ok({ relPath: '计划.md', name: '计划.md', bytes: 0 }, 201);
        if (path.endsWith('/upload')) return ok({ relPath: 'a.md', name: 'a.md', bytes: 3 }, 201);
        if (path.endsWith('/external')) {
            return ok({ source: parsed.searchParams.get('dir'), files: overrides.external ?? [], truncated: false });
        }
        if (path.endsWith('/import')) {
            return ok({ source: body?.source, imported: (body?.entries ?? []).map((entry) => ({ name: entry })), skipped: [] }, 201);
        }
        if (path.endsWith('/file')) return ok({});
        return { ok: false, status: 404, json: async () => ({ error: { code: 'NOT_FOUND', message: 'no such route' } }) };
    };
}
