# Sync this plugin into a dsh profile's node_modules as a REAL directory.
#
# Why a copy instead of a symlink/junction: Node resolves bare specifiers after
# realpath. When the plugin is a junction into the workspace, the real path lands
# outside the profile and packages that ship with the dsh installation
# (e.g. @deepseek-ai/schemastery) no longer resolve. Official plugins installed
# from npm are real directories, which is why they work. pnpm also does not detect
# content changes in a directory dependency, so re-running `dsh plugin install`
# alone says "Already up to date" and copies nothing -- this script is the sync.
#
# Install strategy = OVERWRITE IN PLACE, never "delete the directory then copy":
#   * a recursive delete of the target trips environment delete-guards (a
#     fail-closed safe-delete hook aborts the whole script and leaves the profile
#     with NO plugin at all);
#   * overwriting is idempotent, so a failed run can simply be re-run.
# Stale files (a module that was removed from source) are only reported by
# default; pass -Clean to try removing them one file at a time.
#
# Usage:
#   powershell -ExecutionPolicy Bypass -File tools\dev-install.ps1 -SkipProjection
#   powershell -ExecutionPolicy Bypass -File tools\dev-install.ps1 -SkipProjection -Clean
param(
    [string]$DshHome = 'C:\Users\Administrator\.dsh',
    [string]$Profile = 'desktop',
    [string]$ProjectionDonor = 'C:\Users\Administrator\.dsh\profiles\node_modules',
    [switch]$SkipProjection,
    [switch]$Clean
)

$ErrorActionPreference = 'Stop'
$source = Split-Path -Parent $PSScriptRoot
$profileDir = Join-Path $DshHome "profiles\$Profile"
$target = Join-Path $profileDir 'node_modules\dsh-library'

if (-not (Test-Path -LiteralPath $profileDir)) {
    throw "profile does not exist: $profileDir"
}

# A profile created straight from the CLI needs a projection of the installation's
# own packages at <DSH_HOME>\profiles\node_modules. The Electron desktop profile
# is app-managed: the application provides those packages itself, so pass
# -SkipProjection for it.
$projection = Join-Path $DshHome 'profiles\node_modules'
if ($SkipProjection) {
    Write-Output "skip projection (app-managed profile provides its own packages)"
}
elseif (-not (Test-Path -LiteralPath $projection)) {
    if (-not (Test-Path -LiteralPath $ProjectionDonor)) { throw "projection donor missing: $ProjectionDonor" }
    New-Item -ItemType Junction -Path $projection -Target $ProjectionDonor | Out-Null
    Write-Output "created projection: $projection -> $ProjectionDonor"
}

# Only a LINK gets removed (and only the link itself -- never recurse through a
# junction, that would delete the workspace sources it points at). A real
# directory is kept and overwritten below. `cmd /c rmdir` is deliberate: it
# removes a reparse point without touching its target.
if (Test-Path -LiteralPath $target) {
    $item = Get-Item -LiteralPath $target -Force
    if ($item.Attributes -band [System.IO.FileAttributes]::ReparsePoint) {
        & cmd.exe /c rmdir "$target" | Out-Null
        Write-Output "removed link: $target"
    }
}
else {
    New-Item -ItemType Directory -Path $target -Force | Out-Null
}

$files = @('index.js', 'client.js', 'package.json', 'cordis.patch.yml', 'icon.svg', 'README.md', 'CHANGELOG.md', 'LICENSE', '.gitignore')
$dirs = @('lib', 'locale', 'tools')

foreach ($file in $files) {
    $from = Join-Path $source $file
    if (Test-Path -LiteralPath $from) { Copy-Item -LiteralPath $from -Destination (Join-Path $target $file) -Force }
}
foreach ($dir in $dirs) {
    $from = Join-Path $source $dir
    if (-not (Test-Path -LiteralPath $from)) { continue }
    New-Item -ItemType Directory -Path (Join-Path $target $dir) -Force | Out-Null
    # Copy the whole subtree, then delete nothing: overwrite is the safe half of sync.
    Copy-Item -LiteralPath $from -Destination $target -Recurse -Force
}

# ---- stale detection -------------------------------------------------------
# Files that exist in the installed copy but no longer exist in the source.
$keep = @{}
foreach ($file in $files) { $keep[$file] = $true }
foreach ($dir in $dirs) { $keep[$dir] = $true }

$stale = @()
foreach ($entry in Get-ChildItem -LiteralPath $target -Force) {
    if (-not $keep.ContainsKey($entry.Name)) { $stale += $entry.FullName }
}
foreach ($dir in $dirs) {
    $srcDir = Join-Path $source $dir
    $dstDir = Join-Path $target $dir
    if (-not (Test-Path -LiteralPath $srcDir) -or -not (Test-Path -LiteralPath $dstDir)) { continue }
    $want = @{}
    foreach ($f in Get-ChildItem -LiteralPath $srcDir -Recurse -File) {
        $rel = $f.FullName.Substring($srcDir.Length).TrimStart('\')
        $want[$rel] = $true
    }
    foreach ($f in Get-ChildItem -LiteralPath $dstDir -Recurse -File) {
        $rel = $f.FullName.Substring($dstDir.Length).TrimStart('\')
        if (-not $want.ContainsKey($rel)) { $stale += $f.FullName }
    }
}

if ($stale.Count -eq 0) {
    Write-Output "no stale files"
}
elseif ($Clean) {
    $removed = 0
    $blocked = @()
    foreach ($path in $stale) {
        try { Remove-Item -LiteralPath $path -Force -ErrorAction Stop; $removed += 1 }
        catch { $blocked += $path }
    }
    Write-Output "removed $removed stale file(s)"
    if ($blocked.Count -gt 0) {
        Write-Output "BLOCKED (a delete guard refused these - remove them by hand):"
        foreach ($path in $blocked) { Write-Output "  $path" }
    }
}
else {
    Write-Output "stale files (re-run with -Clean, or ignore):"
    foreach ($path in $stale) { Write-Output "  $path" }
}

$count = (Get-ChildItem -LiteralPath $target -Recurse -File | Measure-Object).Count
Write-Output "synced $count files -> $target"
