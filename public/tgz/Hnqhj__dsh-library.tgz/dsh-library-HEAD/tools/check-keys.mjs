import { readFileSync } from 'node:fs';
const src = readFileSync('D:/dsh-library/client.js', 'utf8');

// --- used literal t('key') keys ---
const used = new Set();
const re = /t\(\s*['"`]([a-zA-Z][a-zA-Z0-9_]*)['"`]/g;
let m;
while ((m = re.exec(src))) used.add(m[1]);

// --- defined keys in zh dict (between 'const zh = {' and the matching close) ---
const zhStart = src.indexOf('const zh = {');
// find the dict object range by brace matching
let i = src.indexOf('{', zhStart);
let depth = 0, end = -1;
for (let j = i; j < src.length; j++) {
  if (src[j] === '{') depth++;
  else if (src[j] === '}') { depth--; if (depth === 0) { end = j; break; } }
}
const zhObj = src.slice(i, end + 1);
// collect keys: 'key': "key": or bare key:  (top-level or nested — dict is flat-ish)
const defined = new Set();
const kre = /(?:['"`])?([a-zA-Z][a-zA-Z0-9_]*)(?:['"`])?\s*:/g;
let km;
while ((km = kre.exec(zhObj))) defined.add(km[1]);

// function-returning keys (e.g. key: (n)=>`matched ${n}`) are still in defined set by name
const missing = [...used].filter((k) => !defined.has(k));
console.log('used literal t() keys:', used.size);
console.log('defined zh keys:', defined.size);
console.log('USED-BUT-NOT-DEFINED keys:', missing.length ? missing : '(none)');

// --- kindMeta returned .key values ---
const kmStart = src.indexOf('function kindMeta');
const kmSlice = kmStart >= 0 ? src.slice(kmStart, kmStart + 1200) : '';
const kindKeys = new Set();
const k2 = /key:\s*['"`]([a-zA-Z][a-zA-Z0-9_]*)['"`]/g;
let k2m;
while ((k2m = k2.exec(kmSlice))) kindKeys.add(k2m[1]);
const missingKind = [...kindKeys].filter((k) => !defined.has(k));
console.log('kindMeta .key values:', [...kindKeys]);
console.log('kindMeta keys NOT in dict:', missingKind.length ? missingKind : '(none)');
