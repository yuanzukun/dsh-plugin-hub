// Headless render harness for dsh-library Panel.
// Loads the real client.js, runs apply(), then renders the `main` panel's
// first paint via react-dom/server to surface any render-time throw.
import { readFileSync } from 'node:fs';
import vm from 'node:vm';
import react from 'file:///C:/Users/Administrator/.workbuddy/binaries/node/workspace/node_modules/react/index.js';
import { renderToString } from 'file:///C:/Users/Administrator/.workbuddy/binaries/node/workspace/node_modules/react-dom/server.js';

const SRC = 'D:/dsh-library/client.js';
const code = readFileSync(SRC, 'utf8');

const captured = {};
const h = react.createElement;

const sandbox = {
  window: {
    __ModuleLoader__: {
      load(spec) { Object.assign(captured, spec); },
    },
  },
  require: (name) => {
    if (name === 'react') return react;
    if (name === '@deepseek-ai/dsh-client-ui-primitives') {
      return {
        StateDot: ({ state, size }) => h('span', { className: 'statedot', 'data-state': state }),
        Toast: ({ text }) => h('div', { className: 'toast' }, text ?? ''),
        MarkdownText: ({ text }) => h('div', { className: 'md' }, text ?? ''),
        CodeBlock: ({ code }) => h('pre', null, code ?? ''),
        PathLabel: ({ path }) => h('span', null, path ?? ''),
        languageForPath: () => undefined,
      };
    }
    throw new Error('unexpected require: ' + name);
  },
  console,
};
sandbox.globalThis = sandbox;
vm.createContext(sandbox);
vm.runInContext(code, sandbox);

if (!captured.factory) {
  console.error('FACTORY NOT CAPTURED');
  process.exit(1);
}

const { inject, apply } = captured.factory(sandbox.require);

// ---- mock host ctx ----
const injectors = {};
const registrations = [];
const slots = {
  inject: (slot, factoryFn) => { injectors[slot] = factoryFn; return () => {}; },
  register: (options, component) => {
    registrations.push({ options, component });
    return () => {};
  },
  entries: () => [],
  subscribe: () => () => {},
  onEntryError: () => () => {},
};
const localeDict = {};
const locale = {
  register: (ns, dict) => { localeDict[ns] = dict; },
  bind: (ns) => (key, ...args) => {
    const d = localeDict[ns] || {};
    const v = d[key];
    if (v === undefined) return key;
    // 与真实 LocaleRuntime.translate 对齐：字符串模板 + {0}/{1} 位置占位符。
    const template = typeof v === 'function' ? v(...args) : String(v);
    if (args.length === 0) return template;
    return template.replace(/\{(\w+)\}/g, (match, name) => (name in args ? String(args[name]) : match));
  },
};
apply({ slots, locale });

console.log('injectors registered for slots:', Object.keys(injectors));

// ---- realize main panel ----
if (!injectors['main']) {
  console.error('NO main injector found');
  process.exit(1);
}
registrations.length = 0;
injectors['main']();
const mainEntry = registrations.find((r) => r.options.name === 'main');
if (!mainEntry) {
  console.error('main entry not produced by injector');
  console.error('registrations:', registrations.map((r) => r.options));
  process.exit(1);
}
console.log('main entry options:', JSON.stringify({ name: mainEntry.options.name, key: mainEntry.options.key, locale: mainEntry.options.locale, hasInject: typeof mainEntry.options.inject }));

const injected = mainEntry.options.inject ? mainEntry.options.inject() : {};
console.log('injected props:', Object.keys(injected));

const Panel = mainEntry.component;
console.log('Panel is function:', typeof Panel === 'function');

try {
  const html = renderToString(react.createElement(Panel, injected));
  console.log('RENDER OK. html length:', html.length);
  // sanity: show first 400 chars
  console.log('--- html head ---');
  console.log(html.slice(0, 400));
} catch (err) {
  console.error('RENDER THREW:');
  console.error(err && err.stack ? err.stack : err);
  process.exit(2);
}
