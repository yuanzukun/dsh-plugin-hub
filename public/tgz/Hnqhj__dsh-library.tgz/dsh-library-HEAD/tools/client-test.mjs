/**
 * 面板契约测试：不启动 DSH，用迷你渲染器把 client.js 真的跑起来。
 *
 *   node tools/client-test.mjs
 *
 * 覆盖：
 *  1. 两个注册的形状（`main` 槽的 key 与侧边栏条目的 id 必须同一个值），以及
 *     **没有**第三个注册 —— 阶段 5 摘掉了右侧栏预览，这里守着别让它悄悄回来；
 *  2. 页面在各种数据下的渲染：两行表头、chip 筛选、网格/列表、放大卡片、空态；
 *  3. 交互真的会发请求，请求的形状（方法 / 查询串 / 请求体）正确；
 *  4. 降级路径：宿主连不上、组件库缺失、能力清单缺少某项时控件被禁用。
 *
 * ## 假后端不是一个"见招招" 的桩
 *
 * 它按**宿主内核的同一套语义**实现 `list` 与 `facets`（`scope` 子树、`q` 搜
 * 路径/标签/备注、`kind`、`tag`、`sort`/`dir`/`limit`，以及按范围计数的 facet）。
 * 这样"点一个 chip → 计数和列表一起变"才是真的被验证过，而不是断言一个写死的
 * 数字刚好等于我写下的那个数字。
 *
 * 迷你渲染器只实现 `useState` / `useEffect` / `useCallback` / `useRef`（client.js
 * 也只用这四个），并**按依赖数组判断 effect 是否重跑**。目的是在重启 DSH 之前
 * 抓住拼写与结构错误，而不是替代浏览器里的真实渲染。
 */
import { fileURLToPath, pathToFileURL } from 'node:url';
import { dirname, join } from 'node:path';
import { readFileSync } from 'node:fs';
import { React, hookStores, isDirty, setDirty, renderRoot, walk, collect, textOf, textOfNode, byClass } from './mini-react.mjs';
import { FIXTURE, CAPS, statusPayload, calls, listFrom, facetsFrom, ok, libraryResponder, setResponder, at } from './fake-backend.mjs';

const here = dirname(fileURLToPath(import.meta.url));
const clientPath = join(here, '..', 'client.js');

// ---- 断言工具
let failed = 0;
function check(label, actual, expected) {
    const ok = JSON.stringify(actual) === JSON.stringify(expected);
    if (ok) {
        console.log(`ok   ${label}`);
    } else {
        failed += 1;
        console.log(`FAIL ${label} -> ${JSON.stringify(actual)} (expected ${JSON.stringify(expected)})`);
    }
}
function checkTrue(label, value) {
    check(label, value === true, true);
}


// ---- 假的官方组件库：形状与真件一致，渲染成可识别的节点
const fakePrimitives = {
    Toast: ({ text, holdMs }) => React.createElement('primitives:Toast', { text, holdMs }),
    StateDot: ({ state }) => React.createElement('primitives:StateDot', { state }),
    PathLabel: ({ path }) => React.createElement('primitives:PathLabel', { path }),
    CodeBlock: ({ code, lang, wrap }) => React.createElement('primitives:CodeBlock', { lang, wrap, code }),
    languageForPath: (filePath) => (/\.m?js$/iu.test(filePath) ? 'javascript' : undefined),
};
const codeBlocks = (tree) => collect(tree, (node) => node.type === fakePrimitives.CodeBlock);
const images = (tree) => collect(tree, (node) => node.type === 'img');
const videos = (tree) => collect(tree, (node) => node.type === 'video');
const audios = (tree) => collect(tree, (node) => node.type === 'audio');
const anchors = (tree) => collect(tree, (node) => node.type === 'a');
const buttonsOf = (tree) => collect(tree, (node) => node.type === 'button');
const buttonByText = (tree, text) => buttonsOf(tree).find((node) => textOfNode(node) === text);
const buttonByLabel = (tree, label) => buttonsOf(tree).find((node) => node.props['aria-label'] === label);
const inputByLabel = (tree, label) => collect(tree, (node) => node.type === 'input' && node.props['aria-label'] === label)[0];
const textareas = (tree) => collect(tree, (node) => node.type === 'textarea');
const chips = (tree) => byClass(tree, 'dsl-tab');
const chipTexts = (tree) => chips(tree).map(textOfNode);
/** chip 按维度分组：key 前缀分别是 all / k-（类型）/ dirs / up / d-（目录）/ t-（标签）。 */
const chipsWith = (tree, prefix) => chips(tree).filter((node) => typeof node.props.key === 'string' && node.props.key.startsWith(prefix));
const chipTextsOf = (tree, prefix) => chipsWith(tree, prefix).map(textOfNode);
const toastTextOf = (tree) => collect(tree, (node) => node.type === fakePrimitives.Toast)[0]?.props.text ?? '';

// ---- 载入真实的 client.js
function loadClient(requireImpl) {
    let entry = null;
    globalThis.window = { __ModuleLoader__: { load(definition) { entry = definition; } } };
    return import(`${pathToFileURL(clientPath).href}?probe=${Date.now()}${Math.random()}`)
        .then(() => entry.factory(requireImpl));
}

const dictionaries = {};
const baseRequire = (name) => {
    if (name === 'react') return React;
    if (name === '@deepseek-ai/dsh-client-ui-primitives') return fakePrimitives;
    throw new Error(`unexpected require: ${name}`);
};

function makeCtx() {
    const registrations = [];
    const ctx = {
        effect(fn) {
            fn();
            return () => {};
        },
        locale: {
            register(namespace, dicts) {
                dictionaries[namespace] = dicts.zh;
            },
            bind(namespace) {
                // 与真实 LocaleRuntime.translate 对齐：词条是带 {0}/{1} 占位符的
                // 字符串，位置参数由插件客户端装进数组传入（数组支持 `in` 与下标）。
                return (key, ...args) => {
                    const value = (dictionaries[namespace] ?? {})[key] ?? key;
                    return String(value).replace(/\{(\w+)\}/g, (match, name) => (name in args ? String(args[name]) : match));
                };
            },
        },
        slots: {
            inject(name, factory) {
                const produced = factory();
                if (produced !== null && typeof produced === 'object' && typeof produced.next === 'function') {
                    for (const ignored of produced) void ignored;
                }
            },
            register(definition, component) {
                registrations.push({ name: definition.name, definition, component });
                return () => {};
            },
        },
    };
    return { ctx, registrations };
}

const plugin = await loadClient(baseRequire);
check('插件声明了 slots 与 locale 注入', plugin.inject, ['slots', 'locale']);

const { ctx, registrations } = makeCtx();
plugin.apply(ctx);
check('只注册两个席位（没有右侧栏预览）', registrations.map((item) => item.name), ['sidebar.panellist', 'main']);

const mainEntry = registrations.find((item) => item.name === 'main');
const sidebarEntry = registrations.find((item) => item.name === 'sidebar.panellist');
checkTrue('main 槽已注册', mainEntry !== undefined);
check('main 的 key', mainEntry.definition.key, 'library');
check('侧边栏条目的 id 与 main 的 key 一致', sidebarEntry.definition.id, mainEntry.definition.key);
check('侧边栏排序', sidebarEntry.definition.order, 22);
check('侧边栏标签', sidebarEntry.definition.label(), '资料库');
checkTrue('词典已登记', dictionaries.library !== undefined);
checkTrue('没有注册任何右侧栏 tab 正文', registrations.every((item) => item.name !== 'sidebar.right.pane.tab'));


/**
 * 反复渲染直到状态不再变化（把 effect 里的异步 setState 收敛掉）。
 *
 * ## 为什么必须 walk，不能只 renderRoot
 *
 * `renderRoot(Panel)` 只展开 **Panel 自己**。面板里的子组件（`Rail` / `Pane`）
 * 在这棵树里只是 `h(Pane, ...)` 这样的**元素节点**，它们的 hook 要等有人
 * 真正走进去才执行 —— 迷你渲染器的 `walk` 展开函数组件时才跑它的 effect。
 *
 * 于是只 render 的话：`Pane` 的 `/document` 请求根本不会发出，右栏永远停在
 * `loading`。这不是产品 bug，是"断言之前没人走进那棵子树"。这个坑的欺骗性
 * 在于症状完全像产品坏了 —— 而产品代码一行都不用改。
 *
 * 每一轮：render → walk（触发子组件的 effect）→ 等三拍冲刷 fetch 的微任务链
 * → 判脏。请求要两轮以上才看得到结果：第一轮发，第二轮才拿到。
 */
async function settle(component, props) {
    let tree = null;
    for (let pass = 0; pass < 20; pass += 1) {
        setDirty(false);
        tree = renderRoot(component, props);
        // walk 一遍：让子组件的 effect 真的跑起来（发请求、setState）。
        walk(tree, () => {});
        await new Promise((resolve) => setTimeout(resolve, 0));
        await new Promise((resolve) => setTimeout(resolve, 0));
        await new Promise((resolve) => setTimeout(resolve, 0));
        if (!isDirty()) {
            const before = calls.length;
            await new Promise((resolve) => setTimeout(resolve, 0));
            if (!isDirty() && calls.length === before) break;
        }
    }
    return tree;
}

function reset() {
    hookStores.clear();
    calls.length = 0;
}

const t = (key, ...args) => {
    const value = dictionaries.library[key] ?? key;
    // 与真实 LocaleRuntime.translate 对齐：字符串模板 + {0}/{1} 位置占位符。
    const template = typeof value === 'function' ? value(...args) : String(value);
    if (args.length === 0) return template;
    return template.replace(/\{(\w+)\}/g, (match, name) => (name in args ? String(args[name]) : match));
};
const render = () => settle(mainEntry.component, { t });
const lastItemsCall = () => calls.filter((call) => call.path.endsWith('/items')).at(-1);
const lastFacetsCall = () => calls.filter((call) => call.path.endsWith('/facets')).at(-1);
const lastTreeCall = () => calls.filter((call) => call.path.endsWith('/tree')).at(-1);
const lastDocCall = () => calls.filter((call) => call.path.endsWith('/document')).at(-1);

/**
 * 夹具里的资料条数。
 *
 * 断言里写死 8 的老写法有个隐藏成本：加一份夹具（比如为了给右栏多一个可预览
 * 类型）就得改一批期望，而漏改的那几处会以"计数不对"的形式报出来 —— 报错
 * 指向的是计数逻辑，实际原因只是夹具多了一行。改成从夹具数出来之后，断言
 * 守的重新变成它本该守的那件事。
 */
const TOTAL = FIXTURE.length;

// ================= 场景 1：首屏 =================
reset();
setResponder(libraryResponder());
let tree = await render();
let texts = textOf(tree);
check('渲染出标题', texts.includes('资料库'), true);
check('连接状态点', collect(tree, (node) => node.type === fakePrimitives.StateDot)[0].props.state, 'done');
check('未筛选时显示总数', textOfNode(byClass(tree, 'dsl-count')[0]).includes(`共 ${TOTAL} 项`), true);
check('默认按修改时间倒序', lastItemsCall().params.get('sort'), 'mtime');
check('默认降序', lastItemsCall().params.get('dir'), 'desc');
check('显式给了 scope（整库）', lastItemsCall().params.get('scope'), '');
check('没有给 parent（不走子项模式）', lastItemsCall().params.get('parent'), null);
check('渲染出与夹具等量的卡片', byClass(tree, 'dsl-card').length, TOTAL);
check('两行表头', byClass(tree, 'dsl-bar').length, 2);

// chip 上的计数来自 /facets，不是面板自己数的。
//
// 期望值全部**从夹具算出来**，不写死：写死的话每加一份夹具就要改这一段，
// 而漏改时报错指向"facets 计数错了"，会把人引到完全错误的方向（真问题只是
// 夹具多了一行）。派生之后这条断言守的才是它本意：chip 上的数与库里一致。
const parentOf = (relPath) => (relPath.includes('/') ? relPath.slice(0, relPath.lastIndexOf('/')) : '');
const kindCount = (kind) => FIXTURE.filter((row) => row.kind === kind).length;
// 目录 chip 只列**直接**子目录（scope='' 时就是没有第二段 / 的那些），
// 每条的计数是该目录**整棵子树**里的文件数（facets 的 total 是递归的）。
// 排序用**码位比较**而不是 localeCompare —— 与 `scan.folderStats()` 和假后端
// 的 `.sort()` 一致（`a.relPath < b.relPath`）。用 localeCompare 的话中文目录名
// 的顺序不一样，断言会以"目录 chip 顺序不对"的形式报出来，而真机上其实是对的。
const topFolders = [...new Set(FIXTURE.map((row) => parentOf(row.relPath)))]
    .filter((parent) => parent !== '' && !parent.includes('/'))
    .sort()
    .map((parent) => `${parent.split('/').pop()}${FIXTURE.filter((row) => row.relPath.startsWith(`${parent}/`)).length}`);
const tagCounts = new Map();
for (const row of FIXTURE) {
    for (const tag of row.tags) tagCounts.set(tag, (tagCounts.get(tag) ?? 0) + 1);
}

const kindChips = chipTextsOf(tree, 'k-');
const dirChips = chipTextsOf(tree, 'd-');
const tagChips = chipTextsOf(tree, 't-');
check('chip 行里有关键词', tagChips.includes(`#主封面${tagCounts.get('主封面')}`), true);
check('类型 chip 带计数（图片）', kindChips.includes(`图片${kindCount('image')}`), true);
check('类型 chip 带计数（文档）', kindChips.includes(`文档${kindCount('doc')}`), true);
check('目录 chip 只列直接子目录', dirChips, topFolders);
check('标签 chip 带计数', [...tagChips].sort(),
    [...tagCounts.entries()].map(([tag, n]) => `#${tag}${n}`).sort());
check('facets 请求带上了 scope', lastFacetsCall().params.get('scope'), '');

// 卡片内容
const cardNames = byClass(tree, 'dsl-card-name').map(textOfNode);
const newest = [...FIXTURE].sort((a, b) => b.mtimeMs - a.mtimeMs)[0].relPath.split('/').pop();
check('默认按时间倒序，第一张是最新', cardNames[0], newest);
check('卡片有类型徽标', byClass(tree, 'dsl-card-badge').length, TOTAL);
check('图片卡片渲染 img', images(tree).length, kindCount('image'));
check('视频卡片渲染 video', videos(tree).length, kindCount('video'));
// 非媒体卡片才用类型图标占位：图片/视频/音频有自己的渲染，剩下的走图标。
check('非媒体卡片用类型图标', byClass(tree, 'dsl-card-media-icon').length,
    TOTAL - kindCount('image') - kindCount('video'));
check('视频卡片有播放标记', byClass(tree, 'dsl-card-play').length, kindCount('video'));
check('列表视图表格不存在（默认网格）', byClass(tree, 'dsl-list').length, 0);
check('显示计数行', byClass(tree, 'dsl-note-line').some((node) => textOfNode(node) === `显示 ${TOTAL} / ${TOTAL} 条`), true);

// 样式必须真的进了元素树。`client.js` 是给宿主在浏览器里跑的模块，宿主不会
// "顺手"执行写在模块作用域里的模板字符串 —— CSS 只在树里出现，浏览器才会建
// 样式表。曾经 STYLE 定义了却从没渲染：真机上整页是**完全无样式的裸 HTML**，
// 而契约测试查的是 className，全都对，一层测试都没发现。
const styleNode = collect(tree, (node) => node.type === 'style')[0];
checkTrue('样式节点在树里', styleNode !== undefined);
check('样式表非空', String(styleNode.children).includes('.dsl-root'), true);
check('样式表包含网格规则', String(styleNode.children).includes('.dsl-grid'), true);
check('样式表包含 chip 规则', String(styleNode.children).includes('.dsl-tab'), true);
check('样式表包含三栏容器规则', String(styleNode.children).includes('.dsl-main'), true);
check('样式表包含左栏规则', String(styleNode.children).includes('.dsl-rail'), true);
check('样式表包含右栏规则', String(styleNode.children).includes('.dsl-pane-body'), true);
check('样式表包含空态窄栏规则', String(styleNode.children).includes('.dsl-pane-blank'), true);
// 网格最小列宽：148px 而不是 176px。中栏拿到约 500px 时，176px 只能放两列，
// 卡片被挤、"扫一眼"失效。这条断言守的是那个具体数字 —— 有人调回 176 时
// 不会有人想到"预览图里中栏只有两列"这件事。
checkTrue('网格最小列宽是 148px（不是 176px）',
    /minmax\(148px,1fr\)/u.test(String(styleNode.children)));

// ---- 反引号守卫
//
// `STYLE` 是模板字符串，**它的正文里不能出现反引号**：反引号会提前结束字符串，
// 剩下的 CSS 变成 JS 表达式。症状是 `ReferenceError: xxx is not defined`，
// 报错位置指向 CSS 中段，而真正的原因是几百行之前注释里的一个 ` —— 排查极费时间。
// 这个坑本轮踩了三次，所以在这里钉一条断言，而不是靠记性。
//
// 判据：STYLE 到它的收尾之间的反引号数量必须是 1（只有开头那个）。
// 用"数量"而不是"有没有"：出现 2 个就已经截断了。
{
    const source = readFileSync(join(here, '..', 'client.js'), 'utf8');
    const start = source.indexOf('const STYLE = `');
    const end = source.indexOf('\n`;', start);
    checkTrue('找得到 STYLE 的范围', start !== -1 && end > start);
    const ticks = source.slice(start, end).split('`').length - 1;
    check('STYLE 模板字符串里只有一个反引号（注释里也不能有）', ticks, 1);
}

// ================= 场景 2：视图切换 =================
buttonByLabel(tree, '列表视图').props.onClick({});
tree = await render();
check('切到列表视图', byClass(tree, 'dsl-list').length, 1);
const table = byClass(tree, 'dsl-list')[0];
check('表格由表头与表体组成', table.children.length, 2);
check('表头五列', collect(table.children[0], (node) => node.type === 'th').length, 5);
check('列表行数与卡片数一致', collect(table.children[1], (node) => node.type === 'tr').length, TOTAL);
check('列表行显示类型', byClass(tree, 'dsl-list-kind').map(textOfNode).includes('视频'), true);
buttonByLabel(tree, '网格视图').props.onClick({});
tree = await render();
check('切回网格', byClass(tree, 'dsl-grid').length, 1);

// ================= 场景 3：搜索（实时，不按回车） =================
reset();
setResponder(libraryResponder());
tree = await render();
let search = inputByLabel(tree, t('searchPlaceholder'));
search.props.onChange({ target: { value: '封面' } });
tree = await render();
check('输入即搜（不需要回车）', lastItemsCall().params.get('q'), '封面');
check('搜索命中 1 张卡片', byClass(tree, 'dsl-card').length, 1);
check('搜索时显示匹配计数', textOfNode(byClass(tree, 'dsl-count')[0]).includes(`匹配 1 / 共 ${TOTAL} 项`), true);
check('搜索框回显', inputByLabel(tree, t('searchPlaceholder')).props.value, '封面');
check('出现清空搜索按钮', buttonByLabel(tree, t('clearSearch')) !== undefined, true);
buttonByLabel(tree, t('clearSearch')).props.onClick({});
tree = await render();
check('清空后回到全部', lastItemsCall().params.get('q'), null);
check('清空后恢复全量卡片', byClass(tree, 'dsl-card').length, TOTAL);

// 搜标签与备注也应当命中（与宿主同一套语义）
inputByLabel(tree, t('searchPlaceholder')).props.onChange({ target: { value: '待改' } });
tree = await render();
check('按标签搜得到', lastItemsCall().params.get('q'), '待改');
check('按标签搜命中 1 条', byClass(tree, 'dsl-card').length, 1);
inputByLabel(tree, t('searchPlaceholder')).props.onChange({ target: { value: '第一集' } });
tree = await render();
check('按备注搜得到', byClass(tree, 'dsl-card').length, 1);

// ================= 场景 4：chip 筛选 =================
reset();
setResponder(libraryResponder());
tree = await render();
chipsWith(tree, 'k-').find((node) => textOfNode(node) === '图片2').props.onClick({});
tree = await render();
check('类型 chip 生效', lastItemsCall().params.get('kind'), 'image');
check('只剩两张图片', byClass(tree, 'dsl-card').length, 2);
check('被选中的 chip 标记为开', chipsWith(tree, 'k-').find((node) => textOfNode(node) === '图片2').props['data-on'], 'true');
check('全部 chip 变成未选', chipsWith(tree, 'all')[0].props['data-on'], 'false');
check('计数变成匹配口径', textOfNode(byClass(tree, 'dsl-count')[0]).includes(`匹配 2 / 共 ${TOTAL} 项`), true);

chipsWith(tree, 'all')[0].props.onClick({});
tree = await render();
check('点全部取消类型筛选', lastItemsCall().params.get('kind'), null);
check('恢复全量', byClass(tree, 'dsl-card').length, TOTAL);

// 标签 chip
const tagRows = (tag) => FIXTURE.filter((row) => row.tags.includes(tag));
const STORY = '分镜';
const storyChip = `#${STORY}${tagRows(STORY).length}`;
const tagChip = chipsWith(tree, 't-').find((node) => textOfNode(node) === storyChip);
check('标签 chip 带计数', tagChip !== undefined, true);
tagChip.props.onClick({});
tree = await render();
check('标签 chip 生效', lastItemsCall().params.get('tag'), STORY);
check('标签筛出的条数与夹具一致', byClass(tree, 'dsl-card').length, tagRows(STORY).length);
// 类型与标签同时生效
const docChipText = `文档${kindCount('doc')}`;
chipsWith(tree, 'k-').find((node) => textOfNode(node) === docChipText).props.onClick({});
tree = await render();
const both = tagRows(STORY).filter((row) => row.kind === 'doc').length;
check('类型与标签叠加', [lastItemsCall().params.get('kind'), lastItemsCall().params.get('tag'), byClass(tree, 'dsl-card').length], ['doc', STORY, both]);

// 清空筛选
buttonByText(tree, t('clearFilters')).props.onClick({});
tree = await render();
check('清空筛选后回到全部', [lastItemsCall().params.get('kind'), lastItemsCall().params.get('tag')], [null, null]);

// ================= 场景 5：目录（渐进收窄） =================
reset();
setResponder(libraryResponder());
tree = await render();
chipsWith(tree, 'd-').find((node) => textOfNode(node) === '图片2').props.onClick({});
tree = await render();
check('进入目录改的是 scope', lastItemsCall().params.get('scope'), '图片');
check('出现上一级 chip', chipTextsOf(tree, 'up'), [t('upLevel')]);
check('进入后当前目录交给面包屑表示', byClass(tree, 'dsl-where-link').map(textOfNode), ['图片']);
check('当前目录不再重复出现在 chip 行里', chipTextsOf(tree, 'd-'), ['角色1']);
check('全部目录 chip 变为未选', chipsWith(tree, 'dirs')[0].props['data-on'], 'false');
check('facets 跟着 scope 走', lastFacetsCall().params.get('scope'), '图片');
check('目录内计数变成本范围口径', textOfNode(byClass(tree, 'dsl-count')[0]).includes(`匹配 2 / 共 ${TOTAL} 项`), true);

chipsWith(tree, 'up')[0].props.onClick({});
tree = await render();
check('上一级回到整库', lastItemsCall().params.get('scope'), '');

// ================= 场景 6：排序 =================
reset();
setResponder(libraryResponder());
tree = await render();
buttonByLabel(tree, t('sortLabel')).props.onClick({});
tree = await render();
check('排序菜单展开', byClass(tree, 'dsl-ddbox').length, 1);
check('菜单三项', byClass(tree, 'dsl-dditem').length, 4);
buttonByText(tree, t('sortByName')).props.onClick({});
tree = await render();
check('按名称排序生效', lastItemsCall().params.get('sort'), 'name');
check('菜单收起', byClass(tree, 'dsl-ddbox').length, 0);
// 只换排序键、不换方向：方向仍是默认的 desc，所以第一个是名称**最大**的。
// `localeCompare('zh-Hans-CN')` 下汉字排在拉丁字母之前，这是正确行为
// （升序应为 表.csv 封面.png 立绘.png 旁白.mp3 说明.md ep01.md ep01.mp4 ep02.md）。
check('换排序键不动方向', lastItemsCall().params.get('dir'), 'desc');
check('降序时第一张是名称最大的', byClass(tree, 'dsl-card-name').map(textOfNode)[0], 'ep02.md');
check('降序时最后一张是名称最小的', byClass(tree, 'dsl-card-name').map(textOfNode).at(-1), '表.csv');
buttonByLabel(tree, t('toggleSortDir')).props.onClick({});
tree = await render();
check('方向切换生效', lastItemsCall().params.get('dir'), 'asc');
check('切到升序后第一张是名称最小的', byClass(tree, 'dsl-card-name').map(textOfNode)[0], '表.csv');

// ================= 场景 7：三栏布局 + 右栏内容 =================
//
// 这一节守的是本轮最核心的那条产品决定：**点开一份资料，左树与列表都还在**。
// 之前是"整页切成详情"（`if (open !== null) return <整页>`），点开之后列表整个
// 消失，于是"边翻列表边看内容"这个最常见的动作做不了。
reset();
setResponder(libraryResponder());
tree = await render();

// ---- 三栏都在
check('左栏目录树在', byClass(tree, 'dsl-rail').length, 1);
check('中栏列表在', byClass(tree, 'dsl-mid').length, 1);
check('右栏内容在', byClass(tree, 'dsl-pane').length, 1);
check('三栏容器只有一个', byClass(tree, 'dsl-main').length, 1);
check('左栏有搜索框', byClass(tree, 'dsl-rail-search').length, 1);
check('左栏有目录树', byClass(tree, 'dsl-rail-tree').length, 1);
check('左栏列出夹具里的每个目录', chipTextsOf(tree, 'd-').length > 0, true);
check('未选中时右栏是空态', byClass(tree, 'dsl-pane-empty').length, 1);
check('空态说明"选一份资料"', textOfNode(byClass(tree, 'dsl-pane-empty-title')[0]), t('previewEmpty'));
// 空态栏必须比有内容时窄（`dsl-pane-blank`）。这条守的是"未选中时不占掉
// 四成宽度"：那里只有一句提示，却让中栏的卡片从三列掉到两列，一屏能看的
// 文件数直接少了三分之一 —— 而"扫一眼找文件"正是未选中时唯一要做的事。
check('空态右栏带窄栏类', byClass(tree, 'dsl-pane-blank').length, 1);

// ---- 点开一份：左树与列表**必须还在**
byClass(tree, 'dsl-card').find((node) => textOfNode(byClass(node, 'dsl-card-name')[0]) === 'ep01.mp4').props.onClick({});
tree = await render();
check('点开后左栏还在', byClass(tree, 'dsl-rail').length, 1);
check('点开后列表还在', byClass(tree, 'dsl-grid').length, 1);
check('点开后两行表头还在', byClass(tree, 'dsl-head').length, 1);
check('右栏换成了这条资料', textOfNode(byClass(tree, 'dsl-pane-name')[0]), 'ep01.mp4');
check('有内容时右栏不再是窄栏', byClass(tree, 'dsl-pane-blank').length, 0);
check('右栏挂上了 video（网格卡片里另有一个）', byClass(tree, 'dsl-pane').length === 1 && videos(tree).length, 2);
check('右栏里有下载链接', anchors(tree).some((node) => String(node.props.href).includes('download=1')), true);
const fieldTexts = byClass(tree, 'dsl-fields').map(textOfNode).join('|');
checkTrue('含类型', fieldTexts.includes('视频'));
checkTrue('含相对路径', fieldTexts.includes('视频/ep01.mp4'));
// 绝对路径来自列表载荷里的 `absolutePath`（不是 detail 才补的）——这条断言守的
// 就是「从列表点进来」这条主路径。
checkTrue('含绝对路径', fieldTexts.includes('D:\\dsh-library-data\\视频\\ep01.mp4'));
check('样式表仍只有一个（没进别的分支）', collect(tree, (node) => node.type === 'style').length, 1);

// ---- 翻页：右栏的「上一项 / 下一项」走的是列表的真实位置
const panePage = () => textOfNode(byClass(tree, 'dsl-dbar-page')[0]);
const paneName = () => textOfNode(byClass(tree, 'dsl-pane-name')[0]);
// 页码按**真实位置**断言，不写死"第几条"：夹具一改位置就变，写死的话每次
// 都要跟着改，而它真正要守的是"右栏的页码与它在清单里的位置一致"。
const openAt = byClass(tree, 'dsl-card').findIndex((node) => textOfNode(byClass(node, 'dsl-card-name')[0]) === 'ep01.mp4');
check('页码与它在清单里的位置一致', panePage().includes(`${openAt + 1} / ${TOTAL}`), true);
check('能往前翻（不在第一项）', buttonByLabel(tree, t('prevItem')).props.disabled, openAt <= 0);
check('能往后翻（不在最后一项）', buttonByLabel(tree, t('nextItem')).props.disabled, openAt >= TOTAL - 1);
if (openAt > 0) {
    // 清单里紧挨着的那一条（按当前排序取，不写死名字：默认 mtime desc 下
    // 第一条是最新改的那份，而夹具一改就变）
    const names = byClass(tree, 'dsl-card-name').map(textOfNode);
    const neighbour = names[openAt - 1];
    buttonByLabel(tree, t('prevItem')).props.onClick({});
    tree = await render();
    check('往前翻后列表仍在', byClass(tree, 'dsl-grid').length, 1);
    check('往前翻到清单里的上一条', paneName(), neighbour);
    // 一路翻到第一项：每一项之后"上一项"都该可用，只有第一项才禁用
    for (let step = 0; step < openAt; step += 1) {
        if (buttonByLabel(tree, t('prevItem')).props.disabled !== false) break;
        buttonByLabel(tree, t('prevItem')).props.onClick({});
        tree = await render();
    }
    check('翻到第一项后上一项禁用', buttonByLabel(tree, t('prevItem')).props.disabled, true);
    check('第一项确实是清单的第一条', paneName(), names[0]);
    buttonByLabel(tree, t('nextItem')).props.onClick({});
    tree = await render();
    check('往后翻回第二条', paneName(), names[1]);
}

// ---- 键盘翻页与 Esc 关掉右栏
// 从清单里挑一个**不在末尾**的位置，才能断言"往后翻"确实换了内容。
{
    const names = byClass(tree, 'dsl-card-name').map(textOfNode);
    const at = Math.min(names.length - 2, Math.max(0, names.length - 3));
    byClass(tree, 'dsl-card')[at].props.onClick({});
    tree = await render();
    const before = paneName();
    check('点开后右栏显示的是它', before, names[at]);
    byClass(tree, 'dsl-root')[0].props.onKeyDown({ key: 'ArrowRight' });
    tree = await render();
    check('方向键往后翻：右栏换到下一条', paneName(), names[at + 1]);
    check('方向键翻页时列表不动', byClass(tree, 'dsl-grid').length, 1);
    byClass(tree, 'dsl-root')[0].props.onKeyDown({ key: 'ArrowLeft' });
    tree = await render();
    check('方向键往前翻：回到原来那条', paneName(), before);
}
byClass(tree, 'dsl-root')[0].props.onKeyDown({ key: 'Escape' });
tree = await render();
check('Esc 关掉右栏（不是"回到列表"——列表一直在）', byClass(tree, 'dsl-pane-empty').length, 1);
check('Esc 之后列表顺序没被翻页改动', byClass(tree, 'dsl-card-name').map(textOfNode)[0], newest);

// ---- 四类内容各走各的渲染器
// 每类都要有**独立的触发点**：只测 Markdown 的话，表格 / Word / 代码三条路径
// 永远走不到，测试全绿而功能是坏的。
reset();
setResponder(libraryResponder());
tree = await render();

const openByName = async (name) => {
    const card = byClass(tree, 'dsl-card').find((node) => textOfNode(byClass(node, 'dsl-card-name')[0]) === name);
    card.props.onClick({});
    tree = await render();
};

await openByName('ep01.md');
const dbgBody = byClass(tree,'dsl-pane-body')[0];
const paneStore = hookStores.get('#root+.2+.2');
check('Markdown 走 markdown 渲染器', byClass(tree, 'dsl-pane-md').length, 1);
check('Markdown 也会请求 /document', lastDocCall()?.params.get('path'), '分镜/ep01.md');

reset();
setResponder(libraryResponder());
tree = await render();
await openByName('表.csv');
check('CSV 走表格渲染器', byClass(tree, 'dsl-table').length, 1);
check('表头行被 sticky', byClass(tree, 'dsl-table').length === 1 && collect(byClass(tree, 'dsl-table')[0], (n) => n.type === 'th').length, 4);

reset();
setResponder(libraryResponder());
tree = await render();
await openByName('分镜表.xlsx');
check('xlsx 走表格渲染器', byClass(tree, 'dsl-table').length, 1);

reset();
setResponder(libraryResponder());
tree = await render();
await openByName('剧本.docx');
check('docx 走正文渲染器', byClass(tree, 'dsl-doc').length, 1);
check('docx 的标题渲染成 h1/h2', collect(byClass(tree, 'dsl-doc')[0], (n) => n.type === 'h1').length, 1);
check('docx 的列表项带项目符号', byClass(tree, 'dsl-doc-bullet').length, 2);
check('docx 的表格也走同一个表格渲染器', byClass(tree, 'dsl-table').length, 1);

reset();
setResponder(libraryResponder());
tree = await render();
await openByName('配置.json');
check('JSON 走代码渲染器（不是当纯文本）', byClass(tree, 'dsl-dmedia-text').length + byClass(tree, 'dsl-pane-md').length, 1);

reset();
setResponder(libraryResponder());
tree = await render();
await openByName('老文档.doc');
check('不支持的类型给出提示而不是空白', byClass(tree, 'dsl-pane-warn').length, 1);
check('提示里给了下载这条路', byClass(tree, 'dsl-pane-warn').length >= 1 && byClass(tree, 'dsl-pane-warn-acts').length, 1);
check('媒体不请求 /document', lastDocCall(), undefined);

// ================= 场景 8：右栏里的标注（备注必须点保存） =================
reset();
setResponder(libraryResponder());
tree = await render();
byClass(tree, 'dsl-card').find((node) => textOfNode(byClass(node, 'dsl-card-name')[0]) === '封面.png').props.onClick({});
tree = await render();
check('右栏挂上了 img（网格卡片里另有一个）', byClass(tree, 'dsl-pane').length === 1 && images(tree).length, 3);
check('图片不请求 /document（它只需要 src）', lastDocCall(), undefined);
check('标签胶囊带 # 前缀', textOfNode(byClass(tree, 'dsl-pill-hash')[0]), '#');
// 胶囊本体是「# + 标签名 + 删除按钮」三段，`textOfNode` 只取文本节点，正好是 `#主封面`
check('已有标签回填', byClass(tree, 'dsl-tagpill').map(textOfNode)[0], '#主封面');
const saveButton = buttonByText(tree, t('save'));
check('保存按钮初始禁用（没有改动）', saveButton.props.disabled, true);
const area = textareas(tree)[0];
area.props.onChange({ target: { value: '这是新备注' } });
tree = await render();
check('改动后保存按钮可用', buttonByText(tree, t('save')).props.disabled, false);
check('改动后出现未保存提示', textOf(byClass(tree, 'dsl-savebar')[0]).includes(t('unsaved')), true);
check('还没发请求', calls.some((call) => call.path.endsWith('/annotate')), false);
buttonByText(tree, t('save')).props.onClick({});
tree = await render();
const noteCall = calls.find((call) => call.path.endsWith('/annotate'));
check('保存才发请求', [noteCall?.method, noteCall?.body?.path, noteCall?.body?.note], ['POST', '图片/封面.png', '这是新备注']);
checkTrue('保存后有提示', toastTextOf(tree).includes(t('saved')));

// 加标签
inputByLabel(tree, t('tagPlaceholder')).props.onChange({ target: { value: '待排' } });
tree = await render();
inputByLabel(tree, t('tagPlaceholder')).props.onKeyDown({ key: 'Enter' });
tree = await render();
const addCall = calls.filter((call) => call.path.endsWith('/annotate')).at(-1);
check('回车加标签走 tagsAdd', addCall.body.tagsAdd, ['待排']);

// 移除标签
buttonByLabel(tree, t('removeTag', '主封面')).props.onClick({});
tree = await render();
const removeCall = calls.filter((call) => call.path.endsWith('/annotate')).at(-1);
check('移除标签走 tagsRemove', removeCall.body.tagsRemove, ['主封面']);

// ================= 场景 9：复制路径 / 在资源管理器中显示 =================
reset();
setResponder(libraryResponder());
tree = await render();
const revealTarget = byClass(tree, 'dsl-card-name').map(textOfNode)[0];
byClass(tree, 'dsl-card')[0].props.onClick({});
tree = await render();
check('有复制路径按钮', buttonByText(tree, t('copyPath')) !== undefined, true);
check('有定位按钮', buttonByText(tree, t('reveal')) !== undefined, true);
buttonByText(tree, t('reveal')).props.onClick({});
tree = await render();
const revealCall = calls.find((call) => call.path.endsWith('/reveal'));
check('定位请求方法', revealCall?.method, 'POST');
// 断言"带的是右栏当前这条"，而不是写死某个文件名：默认排序是 mtime desc，
// 第一条随夹具的 mtime 变，写死文件名会在夹具一改时以"定位路径错了"的形式红。
check('定位请求带的是右栏当前这条', revealCall?.body?.path?.split('/').pop(), revealTarget);

// 没有 reveal 能力时按钮整个不出现（而不是禁用后报错）
reset();
setResponder(libraryResponder({ status: { capabilities: CAPS.filter((name) => name !== 'reveal') } }));
tree = await render();
byClass(tree, 'dsl-card')[0].props.onClick({});
tree = await render();
check('没有 reveal 能力就不显示该按钮', buttonByText(tree, t('reveal')), undefined);
check('复制路径仍在', buttonByText(tree, t('copyPath')) !== undefined, true);

// ================= 场景 10：批量选择与批量打标 =================
reset();
setResponder(libraryResponder());
tree = await render();
byClass(tree, 'dsl-card')[0].props.onClick({ ctrlKey: true });
tree = await render();
check('Ctrl+点击只改选中，不动右栏', byClass(tree, 'dsl-pane-empty').length, 1);
check('出现批量操作条', byClass(tree, 'dsl-batch').length, 1);
check('批量条显示已选数量', textOfNode(byClass(tree, 'dsl-batch-n')[0]).includes('已选 1 项'), true);
check('被选中的卡片标记', byClass(tree, 'dsl-card')[0].props['data-picked'], 'true');

byClass(tree, 'dsl-card')[2].props.onClick({ ctrlKey: true });
tree = await render();
check('Ctrl 累加', textOfNode(byClass(tree, 'dsl-batch-n')[0]), '已选 2 项');
// Shift 范围选择：以**最后一次 Ctrl 点击的项**为锚点向两侧扩展，并与之前零散选中的
// 项取并集（第 1 项原已选中，落在区间外也要留着）。锚点是第 3 项 → 区间 3..5 共 3 项，
// 加上区间外的第 1 项 = 4 项。Shift 之后锚点不动，所以可以连着 Shift 扩更多。
byClass(tree, 'dsl-card')[4].props.onClick({ shiftKey: true });
tree = await render();
check('Shift 选中区间（并集，不是替换）', textOfNode(byClass(tree, 'dsl-batch-n')[0]), '已选 4 项');
check('区间内的项都在选中里', [0, 2, 3, 4].map((index) => byClass(tree, 'dsl-card')[index].props['data-picked']), ['true', 'true', 'true', 'true']);
check('区间外的项不受影响', byClass(tree, 'dsl-card')[5].props['data-picked'], 'false');
byClass(tree, 'dsl-card')[6].props.onClick({ shiftKey: true });
tree = await render();
check('连着 Shift 能继续往外扩', textOfNode(byClass(tree, 'dsl-batch-n')[0]), '已选 6 项');
byClass(tree, 'dsl-card')[6].props.onClick({ ctrlKey: true });
tree = await render();
check('Ctrl 可从批量选择里取消', textOfNode(byClass(tree, 'dsl-batch-n')[0]), '已选 5 项');

// 批量打标：重新摆一个确定的 5 项选中（Ctrl 连点第 1..5 项）
reset();
setResponder(libraryResponder());
tree = await render();
for (const index of [0, 1, 2, 3, 4]) {
    byClass(tree, 'dsl-card')[index].props.onClick({ ctrlKey: true });
    tree = await render();
}
check('选中 5 项', textOfNode(byClass(tree, 'dsl-batch-n')[0]), '已选 5 项');
inputByLabel(tree, t('batchTagPlaceholder')).props.onChange({ target: { value: '归档' } });
tree = await render();
buttonByText(tree, t('batchAdd')).props.onClick({});
tree = await render();
const batchCall = calls.find((call) => call.path.endsWith('/annotate') && Array.isArray(call.body.paths));
check('批量走 paths', batchCall?.body?.paths?.length, 5);
check('批量用 tagsAdd', batchCall?.body?.tagsAdd, ['归档']);
check('批量后清空选择', byClass(tree, 'dsl-batch').length, 0);
checkTrue('批量后有提示', toastTextOf(tree).includes('已更新 5 项'));

// 去标签
byClass(tree, 'dsl-card')[0].props.onClick({ ctrlKey: true });
tree = await render();
byClass(tree, 'dsl-card')[1].props.onClick({ ctrlKey: true });
tree = await render();
inputByLabel(tree, t('batchTagPlaceholder')).props.onChange({ target: { value: '分镜' } });
tree = await render();
buttonByText(tree, t('batchRemove')).props.onClick({});
tree = await render();
check('去标签走 tagsRemove', calls.filter((call) => call.path.endsWith('/annotate')).at(-1).body.tagsRemove, ['分镜']);

// 取消选择
byClass(tree, 'dsl-card')[0].props.onClick({ ctrlKey: true });
tree = await render();
buttonByText(tree, t('batchCancel')).props.onClick({});
tree = await render();
check('取消选择', byClass(tree, 'dsl-batch').length, 0);

// ================= 场景 11：键盘 =================
reset();
setResponder(libraryResponder());
tree = await render();
const root = byClass(tree, 'dsl-root')[0];
// 光标初始为空，按一次方向键落到第一项（不是"从第一项再走一步"）
root.props.onKeyDown({ key: 'ArrowRight' });
tree = await render();
check('方向键把光标放到第一项', byClass(tree, 'dsl-card').findIndex((node) => node.props['data-cursor'] === 'true'), 0);
byClass(tree, 'dsl-root')[0].props.onKeyDown({ key: 'j' });
tree = await render();
check('j 也能移动', byClass(tree, 'dsl-card').findIndex((node) => node.props['data-cursor'] === 'true'), 1);
byClass(tree, 'dsl-root')[0].props.onKeyDown({ key: 'ArrowLeft' });
tree = await render();
check('方向键往回走', byClass(tree, 'dsl-card').findIndex((node) => node.props['data-cursor'] === 'true'), 0);
byClass(tree, 'dsl-root')[0].props.onKeyDown({ key: '/' });
tree = await render();
check('/ 不会崩（focus 被测试替身挡掉）', byClass(tree, 'dsl-grid').length, 1);
byClass(tree, 'dsl-root')[0].props.onKeyDown({ key: 'Enter' });
tree = await render();
check('回车在右栏打开光标处那份', byClass(tree, 'dsl-pane-empty').length, 0);
check('右栏文件名与光标处一致', textOfNode(byClass(tree, 'dsl-pane-name')[0]),
    byClass(tree, 'dsl-card').find((n) => n.props['data-cursor'] === 'true') ? textOfNode(byClass(byClass(tree, 'dsl-card').find((n) => n.props['data-cursor'] === 'true'), 'dsl-card-name')[0]) : null);
byClass(tree, 'dsl-root')[0].props.onKeyDown({ key: 'Escape' });
tree = await render();
check('Esc 关掉右栏，列表仍在', [byClass(tree, 'dsl-pane-empty').length, byClass(tree, 'dsl-grid').length], [1, 1]);
inputByLabel(tree, t('searchPlaceholder')).props.onChange({ target: { value: 'x' } });
tree = await render();
byClass(tree, 'dsl-root')[0].props.onKeyDown({ key: 'Escape' });
tree = await render();
check('Esc 清掉搜索', lastItemsCall().params.get('q'), null);

// ================= 场景 12：加载更多 =================
reset();
setResponder((parsed) => {
    if (parsed.pathname.endsWith('/status')) return ok(statusPayload);
    if (parsed.pathname.endsWith('/facets')) return ok(facetsFrom(''));
    if (parsed.pathname.endsWith('/items')) {
        const data = listFrom(parsed.searchParams);
        return ok({ ...data, matched: 120, items: data.items.slice(0, Number(parsed.searchParams.get('limit'))) });
    }
    return libraryResponder()(parsed);
});
tree = await render();
check('超过一页时出现加载更多', buttonByText(tree, t('loadMore', 60)) !== undefined, true);
check('显示计数只算已加载的', byClass(tree, 'dsl-note-line').some((node) => textOfNode(node) === `显示 ${TOTAL} / 120 条`), true);
buttonByText(tree, t('loadMore', 60)).props.onClick({});
tree = await render();
check('点加载更多后 limit 变大', Number(lastItemsCall().params.get('limit')) > 60, true);

// ================= 场景 13：拖拽入库 =================
reset();
setResponder(libraryResponder());
tree = await render();
const main = byClass(tree, 'dsl-root')[0];
main.props.onDragEnter({ preventDefault() {} });
tree = await render();
check('拖入时出现提示层', byClass(tree, 'dsl-drop').length, 1);
await main.props.onDrop({ preventDefault() {}, dataTransfer: { files: [{ name: 'a.md', type: 'text/markdown' }] } });
tree = await render();
check('拖拽结束后提示层消失', byClass(tree, 'dsl-drop').length, 0);
const uploadCall = calls.find((call) => call.path.endsWith('/upload'));
check('上传请求是 POST', uploadCall?.method, 'POST');
check('上传带上文件名', uploadCall?.params?.get('name'), 'a.md');
check('上传落在当前范围', uploadCall?.params?.get('parent'), null);
checkTrue('入库后有提示', toastTextOf(tree).includes('已入库 1 份资料'));
check('存在多选文件输入框', collect(tree, (node) => node.type === 'input' && node.props.type === 'file').length, 1);

// ================= 场景 14：新建 =================
reset();
setResponder(libraryResponder());
tree = await render();
buttonByLabel(tree, t('newDoc')).props.onClick({});
tree = await render();
check('新建菜单展开', byClass(tree, 'dsl-ddbox').length, 1);
check('菜单两项', byClass(tree, 'dsl-dditem').map(textOfNode), [t('menuNewFolder'), t('menuNewDoc')]);
buttonByText(tree, t('menuNewDoc')).props.onClick({});
tree = await render();
checkTrue('出现新建表单', inputByLabel(tree, t('name')) !== undefined);
inputByLabel(tree, t('name')).props.onChange({ target: { value: '计划' } });
tree = await render();
buttonByText(tree, t('create')).props.onClick({});
tree = await render();
const createCall = calls.find((call) => call.path.endsWith('/create'));
check('无扩展名时补 .md', createCall?.body?.name, '计划.md');
check('新建落在当前范围', createCall?.body?.parent, '');
checkTrue('创建后有提示', toastTextOf(tree).includes('已创建'));

// 已经带扩展名就不再补
reset();
setResponder(libraryResponder());
tree = await render();
buttonByLabel(tree, t('newDoc')).props.onClick({});
tree = await render();
buttonByText(tree, t('menuNewDoc')).props.onClick({});
tree = await render();
inputByLabel(tree, t('name')).props.onChange({ target: { value: '周报.md' } });
tree = await render();
buttonByText(tree, t('create')).props.onClick({});
tree = await render();
check('带扩展名不重复补', calls.find((call) => call.path.endsWith('/create'))?.body?.name, '周报.md');

// 文件夹
reset();
setResponder(libraryResponder());
tree = await render();
buttonByLabel(tree, t('newDoc')).props.onClick({});
tree = await render();
buttonByText(tree, t('menuNewFolder')).props.onClick({});
tree = await render();
inputByLabel(tree, t('name')).props.onChange({ target: { value: '归档' } });
tree = await render();
buttonByText(tree, t('create')).props.onClick({});
tree = await render();
checkTrue('文件夹走 /mkdir', calls.some((call) => call.path.endsWith('/mkdir')));
check('文件夹名不补扩展名', calls.find((call) => call.path.endsWith('/mkdir'))?.body?.name, '归档');

// 取消
reset();
setResponder(libraryResponder());
tree = await render();
buttonByLabel(tree, t('newDoc')).props.onClick({});
tree = await render();
buttonByText(tree, t('menuNewDoc')).props.onClick({});
tree = await render();
buttonByText(tree, t('cancel')).props.onClick({});
tree = await render();
check('取消后表单收起', inputByLabel(tree, t('name')), undefined);

// ================= 场景 15：重扫 =================
reset();
setResponder(libraryResponder());
tree = await render();
buttonByLabel(tree, t('rescan')).props.onClick({});
tree = await render();
checkTrue('重扫请求已发出', calls.some((call) => call.path.endsWith('/rescan') && call.method === 'POST'));
checkTrue('重扫后有提示', toastTextOf(tree).includes('重新扫描完成'));

// ================= 场景 16：从目录导入 =================
const sourceDir = 'D:\\项目\\产出';
const externalFiles = [
    { relPath: '报告.md', name: '报告.md', size: 1024, mtimeMs: at(1, 8), kind: 'doc' },
    { relPath: '子目录/深一层.md', name: '深一层.md', size: 2048, mtimeMs: at(2, 9), kind: 'doc' },
];
reset();
setResponder(libraryResponder({ external: externalFiles }));
tree = await render();
check('导入面板默认收着', byClass(tree, 'dsl-import').length, 0);
buttonByLabel(tree, t('menuImport')).props.onClick({});
tree = await render();
check('导入菜单展开', byClass(tree, 'dsl-dditem').map(textOfNode), [t('menuImportFiles'), t('menuImportFolder')]);
buttonByText(tree, t('menuImportFolder')).props.onClick({});
tree = await render();
check('导入面板打开', byClass(tree, 'dsl-import').length, 1);
inputByLabel(tree, t('importTitle')).props.onChange({ target: { value: sourceDir } });
tree = await render();
buttonByText(tree, t('importScan')).props.onClick({});
tree = await render();
checkTrue('扫描请求带上了目录', calls.some((call) => call.path === '/api/library/external' && call.params.get('dir') === sourceDir));
check('列出候选', byClass(tree, 'dsl-import-item').length, 2);
const boxes = byClass(tree, 'dsl-import-item').map((node) => collect(node, (child) => child.type === 'input')[0]);
check('候选默认全选', boxes.every((node) => node.props.checked === true), true);
check('候选显示相对路径', byClass(tree, 'dsl-import-name').map(textOfNode), ['报告.md', '子目录/深一层.md']);
boxes[1].props.onChange();
tree = await render();
check('取消勾选生效', buttonByText(tree, t('importDo', 1)) !== undefined, true);
buttonByText(tree, t('importPickAll')).props.onClick({});
tree = await render();
buttonByText(tree, t('importDo', 2)).props.onClick({});
tree = await render();
const importCall = calls.find((call) => call.path === '/api/library/import');
check('导入请求的方法', importCall?.method, 'POST');
check('导入请求的源目录', importCall?.body?.source, sourceDir);
check('导入请求的条目', importCall?.body?.entries, ['报告.md', '子目录/深一层.md']);
check('导入请求的目标范围', importCall?.body?.parent, '');
checkTrue('导入后有提示', toastTextOf(tree).includes('已导入 2 份资料'));
check('导入后面板收起', byClass(tree, 'dsl-import').length, 0);

// 全不选时禁用
reset();
setResponder(libraryResponder({ external: externalFiles }));
tree = await render();
buttonByLabel(tree, t('menuImport')).props.onClick({});
tree = await render();
buttonByText(tree, t('menuImportFolder')).props.onClick({});
tree = await render();
inputByLabel(tree, t('importTitle')).props.onChange({ target: { value: sourceDir } });
tree = await render();
buttonByText(tree, t('importScan')).props.onClick({});
tree = await render();
buttonByText(tree, t('importPickNone')).props.onClick({});
tree = await render();
check('全不选后导入按钮禁用', buttonByText(tree, t('importDo', 0)).props.disabled, true);

// 空目录
reset();
setResponder(libraryResponder({ external: [] }));
tree = await render();
buttonByLabel(tree, t('menuImport')).props.onClick({});
tree = await render();
buttonByText(tree, t('menuImportFolder')).props.onClick({});
tree = await render();
inputByLabel(tree, t('importTitle')).props.onChange({ target: { value: sourceDir } });
tree = await render();
buttonByText(tree, t('importScan')).props.onClick({});
tree = await render();
checkTrue('空目录给出说明', textOf(tree).includes('没有可导入'));

// 扫描失败
reset();
setResponder((parsed, method) => {
    if (parsed.pathname.endsWith('/external')) {
        return { ok: false, status: 400, json: async () => ({ error: { code: 'INVALID_SOURCE', message: 'the source folder does not exist' } }) };
    }
    return libraryResponder()(parsed, method);
});
tree = await render();
buttonByLabel(tree, t('menuImport')).props.onClick({});
tree = await render();
buttonByText(tree, t('menuImportFolder')).props.onClick({});
tree = await render();
inputByLabel(tree, t('importTitle')).props.onChange({ target: { value: sourceDir } });
tree = await render();
buttonByText(tree, t('importScan')).props.onClick({});
tree = await render();
check('扫描失败后面板还开着', byClass(tree, 'dsl-import').length, 1);
checkTrue('扫描失败有警告文案', byClass(tree, 'dsl-warn').length > 0);

// ================= 场景 17：空态 =================
// 空库 = `exists:false` 且一条都没有。`/items` 必须跟着空 —— 之前它仍返回夹具
// 里那 8 条，于是"空库"页面上还摆着 8 张卡片，只是断言碰巧在检查文案。
reset();
setResponder((parsed) => {
    if (parsed.pathname.endsWith('/status')) return ok({ ...statusPayload, exists: false, items: 0, folders: 0, bytes: 0 });
    if (parsed.pathname.endsWith('/facets')) return ok({ scope: '', parent: null, total: 0, whole: 0, kinds: [], tags: [], folders: [] });
    if (parsed.pathname.endsWith('/items')) return ok({ ...listFrom(parsed.searchParams), matched: 0, items: [] });
    return libraryResponder()(parsed);
});
tree = await render();
texts = textOf(tree);
checkTrue('空库给出标题', texts.includes('这里还没有资料'));
checkTrue('空库说明库根会自动创建', texts.includes('库根目录还不存在时，第一次入库会自动创建。'));
check('空库不渲染卡片', byClass(tree, 'dsl-card').length, 0);
check('没有子目录/标签时各给一句说明', byClass(tree, 'dsl-chip-empty').map(textOfNode), [t('noFolders'), t('noTags')]);

// 筛选无结果
reset();
setResponder(libraryResponder());
tree = await render();
inputByLabel(tree, t('searchPlaceholder')).props.onChange({ target: { value: '不存在的关键词' } });
tree = await render();
checkTrue('筛选无结果的文案', textOf(tree).includes('当前筛选下没有资料'));

// ================= 场景 18：宿主连不上 =================
reset();
setResponder(() => {
    throw new Error('boom');
});
tree = await render();
check('连接失败时状态点', collect(tree, (node) => node.type === fakePrimitives.StateDot)[0].props.state, 'error');
checkTrue('连接失败时给出文案', textOf(tree).includes('宿主机连接失败'));
checkTrue('连接失败时给出重试', buttonByText(tree, t('retry')) !== undefined);
check('连接失败时不渲染列表', byClass(tree, 'dsl-grid').length, 0);

// HTTP 非 2xx 也要落到失败态
reset();
setResponder(() => ({ ok: false, status: 500, json: async () => ({ error: { code: 'INTERNAL_ERROR', message: 'internal error' } }) }));
tree = await render();
check('非 2xx 时状态点', collect(tree, (node) => node.type === fakePrimitives.StateDot)[0].props.state, 'error');

// ================= 场景 19：能力协商 =================
reset();
setResponder(libraryResponder({ status: { capabilities: ['status', 'items'] } }));
tree = await render();
check('没有 upload 能力时导入按钮禁用', buttonByLabel(tree, t('menuImport')).props.disabled, true);
check('没有 create 能力时新建按钮禁用', buttonByLabel(tree, t('newDoc')).props.disabled, true);
check('没有 rescan 能力时重扫按钮禁用', buttonByLabel(tree, t('rescan')).props.disabled, true);
check('没有 facets 时 chip 行只剩"全部"', chipTextsOf(tree, 'k-').length + chipTextsOf(tree, 'd-').length + chipTextsOf(tree, 't-').length, 0);

// ================= 场景 20：组件库缺失时整页降级 =================
reset();
setResponder(libraryResponder());
const bareRequire = (name) => {
    if (name === 'react') return React;
    throw new Error(`not available: ${name}`);
};
const bare = await loadClient(bareRequire);
const bareCtx = makeCtx();
bare.apply(bareCtx.ctx);
const bareMain = bareCtx.registrations.find((item) => item.name === 'main');
tree = await settle(bareMain.component, { t });
texts = textOf(tree);
checkTrue('降级后仍渲染标题', texts.includes('资料库'));
check('降级后仍渲染卡片', byClass(tree, 'dsl-card').length, TOTAL);
checkTrue('降级后按钮仍是原生 button', buttonsOf(tree).length > 0);
check('降级后没有任何官方组件节点', collect(tree, (node) => String(node.type).startsWith('primitives:')).length, 0);
check('降级后不渲染 Toast（没有官方件可挂）', collect(tree, (node) => String(node.type).startsWith('primitives:Toast')).length, 0);
// 官方件缺失时不能白屏：筛选 chip 全空也不能把内容区吃掉
check('降级后仍能改搜索', inputByLabel(tree, t('searchPlaceholder')) !== undefined, true);

console.log(failed === 0 ? 'ALL PASS' : `${failed} FAILED`);
process.exit(failed === 0 ? 0 : 1);
