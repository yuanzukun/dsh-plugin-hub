/**
 * 只读地看一眼真实库根：用出厂默认配置起一次路由，问一遍状态与清单。
 *
 *   node tools/live-check.mjs
 *
 * 它**不写任何东西**（读路径不会创建库根、不会动索引），所以可以随时跑。
 * 用途是回答"我的库根到底落在哪、里面现在有什么"这类问题 ——
 * 尤其是改过 root 之后，不必靠重启应用来确认。
 */
import { register } from 'node:module';
import { createServer } from 'node:http';

register('./stub-loader.mjs', import.meta.url);

const mod = await import('../index.js');

const routes = [];
const ctx = {
    logger: { info() {}, warn() {} },
    effect(fn) {
        fn();
        return () => {};
    },
    get(key) {
        if (key === 'webServer') {
            return { register(definition) { routes.push(definition); return () => {}; } };
        }
        return undefined;
    },
    on() {},
};

mod.apply(ctx, {});
check(routes.length === 1, '路由已挂载');

const origin = createServer((req, res) => {
    routes[0].handler(req, res).catch(() => {
        if (!res.headersSent) res.writeHead(500);
        res.end();
    });
});
await new Promise((resolve) => origin.listen(0, '127.0.0.1', resolve));
const base = `http://127.0.0.1:${origin.address().port}/api/library`;

const status = await (await fetch(`${base}/status`)).json();
console.log('库根      ', status.root);
console.log('库根来源  ', status.rootSource === 'config' ? '配置/出厂默认' : '退回 <DSH_HOME>/library');
console.log('存在      ', status.exists);
console.log('资料/分组 ', `${status.items} 条 / ${status.folders} 个`);
console.log('占用      ', `${status.bytes} 字节`);
console.log('上传上限  ', status.maxUploadBytes);
console.log('能力      ', status.capabilities.join(', '));

const listing = await (await fetch(`${base}/items?parent=`)).json();
console.log('\n根目录：');
for (const item of listing.items) {
    console.log(`  ${item.isDir ? '[目录]' : '[文件]'} ${item.name}  (${item.kind}, ${item.size} 字节)`);
}
if (listing.items.length === 0) console.log('  （空）');

await new Promise((resolve) => origin.close(resolve));

function check(condition, label) {
    if (!condition) {
        console.error(`FAIL ${label}`);
        process.exit(1);
    }
}
