/**
 * 面板离屏预览生成器（开发用，不进交付产物）。
 *
 * 为什么需要它：`client.js` 是给 DSH 宿主在浏览器里跑的模块，没有构建、没有可独立
 * 打开的页面。改完视觉如果只跑断言，只能证明"结构还在"，证明不了"看起来是否干净"——
 * 而**这一层恰好抓到了一个契约测试永远抓不到的 bug**：`STYLE` 定义了完整的 CSS 却
 * 从没渲染进元素树，宿主不会执行模块作用域里的模板字符串，于是真机上整页是**完全
 * 无样式的裸 HTML**。契约测试查的是 className，全都对，一路绿灯。
 *
 * 做法：用 `mini-react.mjs`（与契约测试同一份）把 `<Panel>` 渲染成一棵宿主元素树，
 * 序列化成静态 HTML，配上 DSH 浅色 token 与树里那份真实 CSS。于是"视觉"变成一个可以
 * 用无头浏览器截图、逐像素看的产物，而不是凭代码想象。
 *
 * ## 状态注入：预置 hook 槽位，而不是模拟点击
 *
 * 迷你渲染器的 hook 槽位挂在 `ROOT_PATH` 上，`useState` 只在 `slots[i] === undefined`
 * 时初始化 —— 所以直接往槽位里预置值，就能跳过"模拟点击"直接渲染出目标状态（下拉
 * 展开、详情打开、批量选择）。这比在无头浏览器里模拟交互可靠得多。
 *
 * 槽位下标一律用 `panelHookIndex(变量名)` 从源码解析，**不要写死数字**：槽位下标 =
 * hook 在函数体里的出现次序，任何一次"在中间加一个 useState"都会把后面全部错位，
 * 而且错位是**静默**的 —— 预置到错的槽位上，渲染出来只是"少了那条批量操作条"，
 * 不会报错。
 *
 * 用法：
 *   node tools/render-preview.mjs             # 生成全部 html
 *   node tools/render-preview.mjs grid detail # 只生成指定的几个
 *   node tools/shoot-preview.mjs              # 生成后用无头 Edge 截图
 */
import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { dirname, join, resolve } from 'node:path';
import { React, hookStores, isDirty, setDirty, renderRoot, renderComponentAt, collect, walk, ROOT_PATH } from './mini-react.mjs';
import { listFrom, facetsFrom, treeFrom, documentFor, ok, statusPayload, setResponder, calls } from './fake-backend.mjs';

const here = dirname(fileURLToPath(import.meta.url));
const clientPath = join(here, '..', 'client.js');
const outDirArg = process.argv.indexOf('--out-dir');
const outDir = outDirArg === -1 ? join(here, '..', 'docs', 'preview') : resolve(process.argv[outDirArg + 1]);
const clientSource = await readFile(clientPath, 'utf8');

// ------------------------------------------------------------------ 载入 client.js
let captured = null;
globalThis.window = { __ModuleLoader__: { load(definition) { captured = definition; } } };
await import(`${pathToFileURL(clientPath).href}?preview=${Date.now()}`);

const dictionaries = {};
const registrations = [];
const h = React.createElement;

/**
 * 预览专用的官方件替身：**渲染成真元素**，不是哨兵标签。
 *
 * 契约测试（`client-test.mjs`）故意把官方件换成 `primitives:CodeBlock` 这种
 * 自定义标签 —— 断言"走的是官方件"只需要比类型名，不需要看长相。但截图不行：
 * 浏览器不认 `primitives:CodeBlock`，页面上就只剩一段裸文本，于是"代码块在
 * 真机上长什么样"这件事在预览里永远看不到，截图就成了骗人的东西。
 *
 * 所以这里给一个**够用的最小实现**：Markdown 支持标题 / 列表 / 段落 / 行内代码 /
 * 粗体，代码块给 pre + 等宽。真机上外观以 DSH 官方件为准，预览只保证"结构对、
 * 有内容、不空白"。
 */
const inlineMd = (source) => {
    const out = [];
    const pattern = /(`[^`]+`)|(\*\*[^*]+\*\*)|(\*[^*]+\*)/gu;
    let at = 0;
    let match;
    let key = 0;
    while ((match = pattern.exec(source)) !== null) {
        if (match.index > at) out.push(source.slice(at, match.index));
        const token = match[0];
        if (token.startsWith('`')) out.push(h('code', { key: `i${key++}`, className: 'pv-md-code' }, token.slice(1, -1)));
        else if (token.startsWith('**')) out.push(h('strong', { key: `i${key++}` }, token.slice(2, -2)));
        else out.push(h('em', { key: `i${key++}` }, token.slice(1, -1)));
        at = match.index + token.length;
    }
    if (at < source.length) out.push(source.slice(at));
    return out;
};

function markdownToElements(source) {
    const lines = String(source ?? '').split(/\r?\n/u);
    const out = [];
    let at = 0;
    let key = 0;
    while (at < lines.length) {
        const line = lines[at];
        if (line.trim() === '') { at += 1; continue; }
        const heading = /^(#{1,6})\s+(.*)$/u.exec(line);
        if (heading !== null) {
            const level = Math.min(6, heading[1].length);
            out.push(h(`h${level}`, { key: `m${key++}`, className: 'pv-md-h' }, inlineMd(heading[2])));
            at += 1;
            continue;
        }
        if (/^[-*]\s+/u.test(line)) {
            const items = [];
            while (at < lines.length && /^[-*]\s+/u.test(lines[at])) {
                items.push(h('li', { key: `m${key++}` }, inlineMd(lines[at].replace(/^[-*]\s+/u, ''))));
                at += 1;
            }
            out.push(h('ul', { key: `m${key++}`, className: 'pv-md-ul' }, items));
            continue;
        }
        if (/^```/u.test(line)) {
            const body = [];
            at += 1;
            while (at < lines.length && !/^```/u.test(lines[at])) { body.push(lines[at]); at += 1; }
            at += 1;
            out.push(h('pre', { key: `m${key++}`, className: 'pv-md-pre' }, h('code', null, body.join('\n'))));
            continue;
        }
        out.push(h('p', { key: `m${key++}`, className: 'pv-md-p' }, inlineMd(line)));
        at += 1;
    }
    return out;
}

const fakePrimitives = {
    Toast: ({ text, holdMs }) => React.createElement('primitives:Toast', { text, holdMs }),
    StateDot: ({ state }) => React.createElement('primitives:StateDot', { state }),
    PathLabel: ({ path }) => React.createElement('primitives:PathLabel', { path }),
    MarkdownText: ({ source }) => h('div', { className: 'pv-md' }, markdownToElements(source)),
    CodeBlock: ({ code, lang }) => h('pre', { className: 'pv-code', 'data-lang': lang ?? '' }, h('code', null, code)),
    languageForPath: (filePath) => (/\.m?js$/iu.test(filePath) ? 'javascript' : undefined),
};
const requireImpl = (name) => {
    if (name === 'react') return React;
    if (name === '@deepseek-ai/dsh-client-ui-primitives') return fakePrimitives;
    throw new Error(`unexpected require: ${name}`);
};
captured.factory(requireImpl).apply({
    effect(factory) { factory(); return () => undefined; },
    locale: {
        register(namespace, dicts) { dictionaries[namespace] = dicts.zh; return () => undefined; },
        // 转发参数：词典里 `batchDone: (n) => ...` 这类值必须拿到 n，
        // 不转发的话 `batchDone` 会把整个函数当成字符串渲染出去。
        bind(namespace) {
            return (key, ...args) => {
                const value = (dictionaries[namespace] ?? {})[key] ?? key;
                return typeof value === 'function' ? value(...args) : value;
            };
        },
    },
    slots: {
        inject(_name, factory) {
            const produced = factory();
            if (produced !== null && typeof produced === 'object' && typeof produced.next === 'function') {
                for (const _step of produced) void _step;
            }
        },
        register(definition, component) { registrations.push({ definition, component }); return () => undefined; },
    },
});
const Panel = registrations.find((item) => item.definition.name === 'main')?.component;
if (Panel === undefined) throw new Error('Panel 未注册');
const t = (key, ...args) => {
    const value = dictionaries.library[key] ?? key;
    return typeof value === 'function' ? value(...args) : value;
};

/**
 * 预览用后端：与契约测试同一份夹具，但**不许改标注**（改了会污染夹具状态）。
 *
 * `/tree` 与 `/document` 都必须接上，否则三栏布局的左栏是空的、右栏停在
 * `loading` —— 而那正是"预览看起来与真机不一样"最容易发生的地方：契约测试
 * 走的是 `libraryResponder`（它接了），预览走的是这里（原来没接）。
 * 两处后端不一致 = 预览在骗人。
 */
setResponder((parsed) => {
    const path = parsed.pathname;
    if (path.endsWith('/status')) return ok(statusPayload);
    if (path.endsWith('/items')) return ok(listFrom(parsed.searchParams));
    if (path.endsWith('/facets')) return ok(facetsFrom(parsed.searchParams.get('scope') ?? ''));
    if (path.endsWith('/tree')) return ok(treeFrom());
    if (path.endsWith('/document')) {
        const result = documentFor(parsed.searchParams.get('path') ?? '');
        return result.ok ? ok(result.json) : ok({ error: { code: result.code, message: result.code } }, result.status);
    }
    if (path.endsWith('/file')) return ok({});
    return ok({});
});

// ------------------------------------------------------------------ 槽位定位
/**
 * 按变量名解析 `<Panel>` 里某个 hook 的槽位下标（不要写死数字，理由见文件头）。
 *
 * 花括号配平**必须从参数列表之后开始**。`function Panel({ t }) {` 的第一个 `}` 是
 * 参数解构的收尾，从函数头的 `{` 开始数会在 19 个字符处就"配平"成功，切出来的
 * 函数体里一个 hook 都没有 —— 表现为"找不到名为 view 的槽位"，而函数明明就在那儿。
 */
function panelHookIndex(name) {
    const header = 'function Panel({ t }) {';
    const start = clientSource.indexOf(header);
    if (start === -1) throw new Error('client.js 里找不到 Panel 函数定义');
    let depth = 0;
    let end = -1;
    for (let i = start + header.length - 1; i < clientSource.length; i += 1) {
        const char = clientSource[i];
        if (char === '{') depth += 1;
        else if (char === '}') {
            depth -= 1;
            if (depth === 0) { end = i; break; }
        }
    }
    if (end === -1) throw new Error('Panel 函数体花括号不配平');
    const body = clientSource.slice(start + header.length, end);
    const pattern = /const\s*\[\s*(\w+)\s*,[^\]]*\]\s*=\s*useState\(|const\s+(\w+)\s*=\s*use(?:Callback|Ref)\s*\(|useEffect\(/gu;
    let index = 0;
    for (const match of body.matchAll(pattern)) {
        const declared = match[1] ?? match[2];
        if (declared === name) return index;
        index += 1;
    }
    throw new Error(`Panel 里找不到名为 ${name} 的 hook 槽位`);
}

/** 预置一个 useState 槽位。槽位存的是 `{ value }`，写裸值会被静默丢弃。 */
const presetState = (index, value) => ({ value });

/**
 * 反复渲染到状态稳定（把 effect 里的异步 setState 收敛掉）。
 *
 * 必须 `walk`：函数组件的子树在 `renderRoot` 里只是 `{ type, key, props }`，
 * 它的 hook 从不在这条路径上跑，`Pane` 的 `/document` 请求也就发不出去 ——
 * 症状是右栏永远停在"正在读取…"，产品代码一行没错，只有截图骗人。
 */
async function settle(maxPass = 20) {
    let tree = null;
    for (let pass = 0; pass < maxPass; pass += 1) {
        setDirty(false);
        tree = renderRoot(Panel, { t });
        walk(tree, () => {});
        await new Promise((resolve) => setTimeout(resolve, 0));
        await new Promise((resolve) => setTimeout(resolve, 0));
        await new Promise((resolve) => setTimeout(resolve, 0));
        if (!isDirty()) break;
    }
    return tree;
}

/**
 * 渲染一帧。`seed` 里的每一项形如 `[变量名, 值]`，在**第一帧之前**写进槽位。
 *
 * 必须在第一帧之前：`Panel` 里有一条 effect 会在 `items` 变化时把选择集合收敛成
 * "仍然存在的路径"，首帧 `items` 还没到，此时写进去的选择会被那次收敛清空。
 * 所以要预置"依赖数据的状态"（详情打开、目录收窄）就用这里；要预置纯 UI 状态
 * （批量选择、拖拽层）同样用这里 —— 只要那个状态不参与收敛。
 */
async function renderFrame(seed = {}) {
    hookStores.clear();
    calls.length = 0;
    const root = hookStores.get('#root') ?? { slots: [], cursor: 0 };
    for (const [name, value] of Object.entries(seed)) {
        root.slots[panelHookIndex(name)] = presetState(panelHookIndex(name), value);
    }
    hookStores.set('#root', root);
    return settle();
}

// ------------------------------------------------------------------ 序列化成 HTML
const VOID_TAGS = new Set(['img', 'input', 'br', 'hr', 'source', 'meta', 'link']);
const ATTR_ALIAS = { className: 'class', htmlFor: 'for', tabIndex: 'tabindex' };
const escapeText = (value) => String(value).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
const escapeAttr = (value) => escapeText(value).replace(/"/g, '&quot;');

/**
 * React 的 `style={{ minWidth: 320 }}` 会补成 `320px`，序列化时必须照做。
 * 漏了单位会写出被浏览器整条丢弃的 `min-width:320`，表现为"这个样式完全没生效"。
 */
const UNITLESS_PROPS = new Set([
    'opacity', 'zIndex', 'fontWeight', 'lineHeight', 'flex', 'flexGrow', 'flexShrink',
    'order', 'zoom', 'aspectRatio', 'tabSize', 'columnCount', 'gridColumn', 'gridRow',
]);
function styleToCss(style) {
    return Object.entries(style).map(([key, value]) => {
        const prop = key.replace(/[A-Z]/gu, (c) => `-${c.toLowerCase()}`);
        const css = typeof value === 'number' && value !== 0 && !UNITLESS_PROPS.has(key) ? `${value}px` : value;
        return `${prop}:${css}`;
    }).join(';');
}

/** 占位图：预览里没有宿主媒体端点，`/file?...` 换成本地内联 SVG。 */
const PALETTE = ['#4c6ef5', '#f06c3c', '#12b886', '#7048e8', '#f59f00', '#1098ad', '#d6336c', '#5c7cfa'];
/**
 * 出图尺寸**按卡片媒体的 4:3 给**，不要用别的比例。
 *
 * SVG 少了 `viewBox` 时浏览器按 `preserveAspectRatio="xMidYMid meet"` 处理 ——
 * 16:9 的图塞进 4:3 的容器会被等比缩小并在上下留白，看起来像"缩略图没填满卡片"，
 * 很容易误判成 `object-fit:cover` 没生效。给上 viewBox + `preserveAspectRatio="none"`
 * 才是"这张图就该铺满这个盒子"的语义。
 */
function dataUri(index, width, height) {
    const a = PALETTE[Math.abs(index) % PALETTE.length];
    const b = PALETTE[Math.abs(index + 3) % PALETTE.length];
    const svg = `<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 ${width} ${height}' preserveAspectRatio='none' width='${width}' height='${height}'>`
        + `<defs><linearGradient id='g' x1='0' y1='0' x2='1' y2='1'>`
        + `<stop offset='0' stop-color='${a}'/><stop offset='1' stop-color='${b}'/></linearGradient></defs>`
        + `<rect width='${width}' height='${height}' fill='url(#g)'/>`
        + `<circle cx='${Math.round(width * 0.7)}' cy='${Math.round(height * 0.34)}' r='${Math.round(Math.min(width, height) * 0.17)}' fill='rgba(255,255,255,.32)'/>`
        + `<rect x='${Math.round(width * 0.09)}' y='${Math.round(height * 0.72)}' width='${Math.round(width * 0.52)}' height='${Math.max(6, Math.round(height * 0.06))}' rx='4' fill='rgba(255,255,255,.5)'/>`
        + '</svg>';
    // 必须整段百分号编码：SVG 里的 `#`（`stop-color='#4c6ef5'`）在 data URI 里是
    // 片段分隔符，不编码就会从第一个 `#` 处截断，`<img>` 加载失败并显示 alt 文本 ——
    // 看起来像"文件名被画在了缩略图上"，其实是预览夹具自己的问题。
    return `data:image/svg+xml,${encodeURIComponent(svg)}`;
}
/** 卡片缩略图：4:3，与 `.dsl-card-media` 的 aspect-ratio 一致。 */
const CARD_THUMB = [400, 300];
function previewSrc(value) {
    if (typeof value !== 'string' || !value.includes('/file?')) return value;
    const match = /relPath=([^&]+)/u.exec(value);
    if (match === null) return dataUri(0, ...CARD_THUMB);
    const relPath = decodeURIComponent(match[1]);
    let index = 0;
    for (let i = 0; i < relPath.length; i += 1) index += relPath.charCodeAt(i);
    return dataUri(index, ...CARD_THUMB);
}

/**
 * 图片类资源（`/file?...`）换成本地占位图。
 *
 * **只对图片换**：视频/音频即使返回占位图，`<video src>` 也解不出来，只会渲染出
 * 一块空白 + 浏览器默认控件。那些改由 `poster` 处理，见序列化处。
 */
function previewMediaSrc(value, tag) {
    if (tag === 'video' || tag === 'audio') return value;
    return previewSrc(value);
}

/**
 * 把元素树序列化成 HTML。
 *
 * 必须自己展开函数组件（而不是靠 `collect` 的副作用）—— 否则 `<Pane>` 这类组件
 * 会被整棵丢掉，截出来是一个空页面，看着像"内容没渲染"，其实只是序列化器跳过了它。
 *
 * **路径规则必须与 `walk` 逐字一致**（数组 `.i` / 宿主子节点 `+` / 组件结果 `>`）。
 * 曾经这里另起了一套 `组件名#序号` 的命名空间，看着一样、其实两套 store：
 * `walk` 把 `/document` 的结果写进 `#root.2+3>Pane`，序列化却从 `Pane#0` 读 ——
 * 读到的是一份从没跑过 effect 的空状态，于是每一张文档截图都停在"正在读取…"，
 * 而产品代码与契约测试全绿。同一段路径规则在同一个文件里只能有一份实现。
 */
function serializeTree(tree) {
    return serialize(tree, ROOT_PATH);
    function serialize(node, path) {
        if (node === null || node === undefined || typeof node === 'boolean') return '';
        if (Array.isArray(node)) return node.map((child, index) => serialize(child, `${path}.${index}`)).join('');
        if (typeof node === 'string' || typeof node === 'number') return escapeText(node);
        if (typeof node.type === 'function') {
            return serialize(renderComponentAt(path, node.type, { ...node.props, children: node.children }), `${path}>`);
        }
        return element(node, `${path}+`);
    }
    function element(node, childPath) {
        const props = node.props ?? {};
        const attrs = [];
        for (const [key, value] of Object.entries(props)) {
            if (key === 'children' || key === 'key' || key === 'ref' || key === 'dangerouslySetInnerHTML') continue;
            if (/^on[A-Z]/u.test(key)) continue;
            if (value === undefined || value === null || value === false) continue;
            if (key === 'style') {
                if (typeof value === 'object') attrs.push(`style="${escapeAttr(styleToCss(value))}"`);
                continue;
            }
            if (key === 'src') { attrs.push(`src="${escapeAttr(previewMediaSrc(value, node.type))}"`); continue; }
            // 无头浏览器没有音视频解码器，`<video src="....mp4">` 会退化成一块默认
            // 大小的空白（看着像"缩略图没填满"）。预览里给它一张 poster 占位 ——
            // 这是**夹具**的补偿，产品代码不该为它加 poster。
            if (node.type === 'video' && !attrs.some((one) => one.startsWith('poster='))) {
                attrs.push(`poster="${escapeAttr(dataUri(7, ...CARD_THUMB))}"`);
            }
            if (key === 'controls') continue; // 控件由浏览器画，无头下只会加一层灰条
            if (value === true) { attrs.push(key); continue; }
            attrs.push(`${ATTR_ALIAS[key] ?? key}="${escapeAttr(value)}"`);
        }
        const open = `<${node.type}${attrs.length > 0 ? ` ${attrs.join(' ')}` : ''}>`;
        if (VOID_TAGS.has(node.type)) return open;
        return `${open}${serialize(props.children ?? node.children, childPath)}</${node.type}>`;
    }
}

/** 把树里那份真实 CSS 挖出来（它已经被渲染成 `<style>` 节点了）。 */
function styleOf(tree) {
    const node = collect(tree, (item) => item.type === 'style')[0];
    if (node === undefined) throw new Error('树里没有 <style> 节点 —— CSS 又没渲染进去？');
    return String(node.children);
}

// DSH 浅色主题（neutral-bluish）的 token 取值；只为预览真实观感，不做精确复刻。
const TOKENS = `
:root{
  --dsh-frame-top-clearance:48px;
  --dsw-font-family:'Segoe UI Variable Text','Segoe UI',system-ui,-apple-system,'Microsoft YaHei UI',sans-serif;
  --dsw-radius-sm:6px;--dsw-radius-md:8px;
  --dsw-alias-bg-base:#ffffff;
  --dsw-alias-bg-layer-1:#ffffff;
  --dsw-alias-bg-layer-2:#f2f3f5;
  --dsw-alias-bg-skeleton:rgba(15,17,21,.05);
  --dsw-alias-label-primary:#14171c;
  --dsw-alias-label-secondary:#4a4f57;
  --dsw-alias-label-tertiary:#82868d;
  --dsw-alias-label-primary-inverted:#ffffff;
  --dsw-alias-border-l1:rgba(15,17,21,.09);
  --dsw-alias-border-l2:rgba(15,17,21,.16);
  --dsw-alias-interactive-bg-hover:rgba(15,17,21,.045);
  --dsw-alias-interactive-bg-active:rgba(15,17,21,.085);
  --dsw-alias-brand-primary:#1f6feb;
  --dsw-alias-state-error-primary:#d93025;
}
*{box-sizing:border-box}
html,body{margin:0;padding:0;background:#eceef1}
body{display:flex;align-items:flex-start;justify-content:center;padding:24px;font-family:var(--dsw-font-family)}
#frame{width:1240px;height:760px;overflow:hidden;border:1px solid rgba(15,17,21,.1);border-radius:10px;background:var(--dsw-alias-bg-base)}
/* 预览替身（MarkdownText / CodeBlock）的长相。真机上以 DSH 官方件为准，
   这里只保证"结构对、有内容、不空白"，否则截图里是一片裸文本。 */
.pv-md{font-size:13.5px;line-height:1.75}
.pv-md-h{margin:0 0 8px;font-weight:650}
.pv-md-h:first-child{margin-top:0}
.pv-md-h:nth-child(1){font-size:18px}
.pv-md-h:nth-child(2){font-size:16px}
.pv-md-h:nth-child(n+3){font-size:14px}
.pv-md-p{margin:0 0 9px}
.pv-md-ul{margin:0 0 9px;padding-left:20px}
.pv-md-li,.pv-md-ul li{margin:2px 0}
.pv-md-code,.pv-md-pre code,.pv-code code{font-family:Consolas,'Cascadia Mono',monospace;font-size:12.5px}
.pv-md-code{background:var(--dsw-alias-bg-layer-2);border-radius:4px;padding:1px 4px}
.pv-md-pre,.pv-code{margin:0 0 9px;padding:10px 12px;border-radius:6px;background:var(--dsw-alias-bg-layer-2);
  overflow:auto;white-space:pre-wrap;word-break:break-word}
`;

function page({ title, body, css }) {
    return `<!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8"><title>${escapeText(title)}</title>
<style>${TOKENS}</style>
<style>${css}</style>
</head><body><div id="frame">${body}</div></body></html>`;
}

// ------------------------------------------------------------------ 生成
const VIEW_NAMES = ['grid', 'list', 'pane', 'preview', 'filter', 'scope', 'batch', 'menu', 'empty', 'narrow'];
const requested = process.argv.slice(2).filter((value) => VIEW_NAMES.includes(value));
const want = (name) => requested.length === 0 || requested.includes(name);

await mkdir(outDir, { recursive: true });

async function emit(name, { seed = {}, title }) {
    const tree = await renderFrame(seed);
    const css = styleOf(tree);
    const body = serializeTree(tree);
    const html = page({ title, css, body });
    await writeFile(join(outDir, `${name}.html`), html, 'utf8');
    const cards = (html.match(/class="dsl-card"/gu) ?? []).length;
    const docCalls = calls.filter((call) => call.path.endsWith('/document')).length;
    console.log(`wrote ${join(outDir, `${name}.html`)}  (${(html.length / 1024).toFixed(1)} KB, ${cards} cards, ${docCalls} /document)`);
    if (process.env.DSL_PREVIEW_TRACE === '1') {
        for (const call of calls) console.log(`    ${call.method} ${call.path}${call.params?.toString() ? `?${call.params}` : ''}`);
    }
}

// ---- 三栏的两种基本形态
if (want('grid')) await emit('grid', { title: '资料库 · 三栏（未选中）' });
if (want('list')) await emit('list', { seed: { view: 'list' }, title: '资料库 · 列表视图' });

// ---- 右栏的四种内容渲染器
//
// 每一类都要有**自己的截图**：合在一起看的话，"表格渲染成了正文"或者
// "代码被当纯文本"这类问题会被另一类盖过去。四张图摆在一起才能对着比。
if (want('pane')) {
    await emit('pane-image', { seed: { open: '图片/封面.png' }, title: '资料库 · 右栏（图片）' });
    await emit('pane-video', { seed: { open: '视频/ep01.mp4' }, title: '资料库 · 右栏（视频）' });
}
if (want('preview')) {
    await emit('preview-md', { seed: { open: '分镜/ep01.md' }, title: '资料库 · 右栏（Markdown）' });
    await emit('preview-sheet', { seed: { open: '数据/表.csv' }, title: '资料库 · 右栏（表格）' });
    await emit('preview-xlsx', { seed: { open: '分镜/第二集/分镜表.xlsx' }, title: '资料库 · 右栏（Excel）' });
    await emit('preview-docx', { seed: { open: '分镜/第二集/剧本.docx' }, title: '资料库 · 右栏（Word）' });
    await emit('preview-code', { seed: { open: '数据/配置.json' }, title: '资料库 · 右栏（代码）' });
    await emit('preview-unsupported', { seed: { open: '归档/老文档.doc' }, title: '资料库 · 右栏（不支持的格式）' });
}

// 筛选态：预置 tag 就渲染出"点了 #分镜"的样子。
if (want('filter')) await emit('filter', { seed: { tag: '分镜' }, title: '资料库 · 标签筛选' });
// 目录收窄：预置 scope，chip 行与面包屑都跟着变，左树里那条链自动展开。
if (want('scope')) await emit('scope', { seed: { scope: '图片' }, title: '资料库 · 目录收窄' });
// 批量选择：预置 picked，卡片描边 + 批量条一起出现。
if (want('batch')) {
    await emit('batch', {
        seed: { picked: ['图片/封面.png', '视频/ep01.mp4', '音频/旁白.mp3', '分镜/ep01.md'] },
        title: '资料库 · 批量打标',
    });
}
// 下拉菜单：预置 menu 里的 'sort' / 'import' / 'new' 之一。
if (want('menu')) {
    await emit('menu-sort', { seed: { menu: 'sort' }, title: '资料库 · 排序菜单' });
    await emit('menu-new', { seed: { menu: 'new' }, title: '资料库 · 新建菜单' });
}
// 空态：facets 与 items 一起空。
if (want('empty')) {
    setResponder((parsed) => {
        const path = parsed.pathname;
        if (path.endsWith('/status')) return ok({ ...statusPayload, exists: false, items: 0, folders: 0, bytes: 0 });
        if (path.endsWith('/facets')) return ok({ scope: '', parent: null, total: 0, whole: 0, kinds: [], tags: [], folders: [] });
        if (path.endsWith('/items')) return ok({ ...listFrom(parsed.searchParams), matched: 0, items: [] });
        if (path.endsWith('/tree')) return ok({ folders: [], total: 0, recent: [] });
        return ok({});
    });
    await emit('empty', { title: '资料库 · 空态' });
    setResponder((parsed) => {
        const path = parsed.pathname;
        if (path.endsWith('/status')) return ok(statusPayload);
        if (path.endsWith('/items')) return ok(listFrom(parsed.searchParams));
        if (path.endsWith('/facets')) return ok(facetsFrom(parsed.searchParams.get('scope') ?? ''));
        if (path.endsWith('/tree')) return ok(treeFrom());
        return ok({});
    });
}
console.log(`\n下一步：node tools/shoot-preview.mjs   # 无头 Edge 截图到 docs/preview/`);
