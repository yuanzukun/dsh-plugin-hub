/**
 * 问 DSH 自己：这个插件到底挂上没有。
 *
 *   node tools/mount-probe.mjs
 *
 * ## 为什么需要它
 *
 * 磁盘检查（`install-check.mjs`）能证明"文件装对了"，**证明不了"DSH 挂载它了"**。
 * 这两件事脱节过一次：`dsh-library` 的所有文件、`package.json` 的 bundles 条目、
 * lock 条目全部正确，界面里就是没有入口。
 *
 * 原因是 `desktop` profile 由运行中的 Electron **独占管理**，CLI 读不到它
 * （`dsh --profile desktop` 直接报 "managed exclusively by the Electron
 * application"），所以那次的唯一可用信号是磁盘状态 —— 而它全绿。
 *
 * ## 做法：借一个能 CLI 启动的 profile 做对照实验
 *
 * `--patch` 只能覆盖已存在的条目，**不能新增**，所以要新增必须改该 profile 的
 * `package.json` 的 `dsh.profile.bundles`。本脚本：
 *
 *  1. 备份 `web` profile 的 `package.json`；
 *  2. 把目标插件（默认本插件）软链进它的 `node_modules` 并加进 bundles；
 *  3. 启动 `dsh --profile web`，抓 `did not activate` / `skipping profile bundle` /
 *     `ready` 三类输出；
 *  4. **无条件恢复**备份（`finally`），不留任何痕迹。
 *
 * ## 判读
 *
 * - 本插件与**对照插件**（默认 `dsh-asset-library`，界面上已知能工作）表现一致
 *   → 插件声明没问题，问题在 desktop 的运行时状态（重启 / 重新安装）。
 * - 只有本插件 `failed to import` → 声明或文件有问题，输出里会带原因。
 * - 两个都 `skipping profile bundle ... cannot resolve` → 环境缺
 *   `@deepseek-ai/*` 运行时，web profile 不是有效对照组（此时结论无效）。
 *
 * 用法：
 *   node tools/mount-probe.mjs                    # 探 dsh-library，对照 asset-library
 *   node tools/mount-probe.mjs --target dsh-infinite-canvas
 *   node tools/mount-probe.mjs --keep             # 不恢复（调试用，慎用）
 */
import { mkdir, readFile, writeFile, symlink, rm, stat } from 'node:fs/promises';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { dirname, join, resolve } from 'node:path';

const here = dirname(fileURLToPath(import.meta.url));
const source = resolve(here, '..');

const argv = process.argv.slice(2);
const argOf = (name, fallback) => {
    const at = argv.indexOf(name);
    return at === -1 ? fallback : argv[at + 1];
};
const target = argOf('--target', 'dsh-library');
const control = argOf('--control', 'dsh-asset-library');
const keep = argv.includes('--keep');
const home = process.env.DSH_HOME ?? 'C:\\Users\\Administrator\\.dsh';
const webDir = join(home, 'profiles', 'web');
const cli = 'F:\\DSH\\resources\\runtime\\cli\\bin\\dsh.cmd';
const donorDir = join(home, 'profiles', 'desktop', 'node_modules');

for (const [label, path] of [['web profile', webDir], ['CLI', cli], ['对照插件源', join(donorDir, control)]]) {
    try {
        await stat(path);
    } catch {
        console.error(`找不到 ${label}：${path}`);
        process.exit(1);
    }
}

console.log(`探针插件 ${target}（对照 ${control}）\n在 ${webDir} 上做对照实验\n`);

const pkgPath = join(webDir, 'package.json');
const backup = await readFile(pkgPath, 'utf8');

// 只读诊断优先：这个脚本会写别的 profile，跑之前先说清楚。
console.log('注意：这个实验会临时改 web profile 的 package.json 与 node_modules。');
console.log('（desktop profile 完全不碰 —— 它由运行中的 Electron 独占，读写都会被冲掉。）\n');

let restoreNeeded = true;
const restore = async () => {
    if (!restoreNeeded) return;
    restoreNeeded = false;
    await writeFile(pkgPath, backup, 'utf8');
    for (const name of [target, control]) {
        await rm(join(webDir, 'node_modules', name), { recursive: true, force: true });
    }
};

try {
    // 1) 软链两个插件进 web profile。用软链而不是复制：DSH 解析 realpath 后要能找到
    //    app 自带的 @deepseek-ai/*，复制反而会切断这条链（dev-install 的注释记过这条）。
    await mkdir(join(webDir, 'node_modules'), { recursive: true });
    for (const name of [target, control]) {
        const link = join(webDir, 'node_modules', name);
        await rm(link, { recursive: true, force: true });
        await symlink(join(donorDir, name), link, 'junction');
    }

    // 2) 加进 bundles。`dsh plugin add` 只会写 dependencies，不会动 bundles ——
    //    没有 bundles 条目就永远不会被挂载（这一点是实测出来的，别再指望 plugin add）。
    const pkg = JSON.parse(backup);
    pkg.dependencies ??= {};
    for (const name of [target, control]) {
        pkg.dependencies[name] = `link:${join(donorDir, name)}`;
        if (!pkg.dsh.profile.bundles.includes(name)) pkg.dsh.profile.bundles.push(name);
    }
    await writeFile(pkgPath, JSON.stringify(pkg, null, 2) + '\n', 'utf8');

    // 3) 启动并抓输出。`--no-open` 免得弹浏览器。
    //
    //    两个 Windows 上的坑：
    //    - `.cmd` **不能**直接 spawn（Node 18.20+/20.12+/22 抛 EINVAL），必须经
    //      shell，所以走 `cmd.exe /c`；
    //    - `child.kill()` 只杀 cmd.exe，**孙进程（真正的 node）不会被杀** ——
    //      于是 `exit` 事件永远不来，整个脚本挂住。所以不靠 exit 事件，
    //      用固定时长后自己收摊，并且 `unref` 掉残留句柄。
    const child = spawn('cmd.exe',
        ['/d', '/c', cli, '--profile', 'web', '--no-open'],
        { stdio: ['ignore', 'pipe', 'pipe'] });
    let output = '';
    const collect = (chunk) => { output += String(chunk); };
    child.stdout.on('data', collect);
    child.stderr.on('data', collect);
    // 18 秒足够 DSH 完成挂载并打出结论；到点就收摊，不等它退出。
    await new Promise((done) => {
        const timer = setTimeout(() => {
            try { process.kill(-child.pid, 'SIGKILL'); } catch { /* 没有进程组，退化成单杀 */ }
            try { child.kill('SIGKILL'); } catch { /* 已经退了 */ }
            done();
        }, 18_000);
        child.on('exit', () => { clearTimeout(timer); done(); });
        child.on('error', () => { clearTimeout(timer); done(); });
    });
    // 子进程可能还攥着管道，让 Node 别等它。
    child.stdout.destroy();
    child.stderr.destroy();
    child.unref();

    // 4) 判读。**只有看到明确的成功信号才算成功。**
    //
    //    这里踩过一次：原先 `ready` 判据是"输出里含 ready (root= 或 <name>:"，
    //    而 DSH 成功挂载时**根本不打任何日志**（只有失败才打）。于是"没输出"被
    //    判成成功 —— 一个会把沉默当通过的检查比没有检查更糟。
    //
    //    所以成功判据收紧成两条**必然出现**的沉默证据：
    //      · 没有 `skipping profile bundle`（可解析）
    //      · 没有 `did not activate` / `failed to import`（能挂载）
    //    再加一条正向信号：插件自己打的那行 ready 日志（dsh-library 有，
    //    dsh-asset-library 也有，两边都写了 ctx.logger.info）。
    const lineOf = (needle) => output.split(/\r?\n/).find((line) => line.includes(needle)) ?? null;
    const didNotActivate = lineOf('did not activate');
    const rows = [target, control].map((name) => {
        const skipping = lineOf(`skipping profile bundle "${name}"`);
        const failed = output.split(/\r?\n/).find((line) => line.includes(name) && line.includes('failed to import')) ?? null;
        const pending = lineOf(`${name}:`) !== null && line.includes('pending');
        const ownLog = lineOf(`${name}: ready`) ?? lineOf(`${name}:`);
        let verdict;
        if (skipping !== null) verdict = `跳过（cannot resolve）: ${skipping.trim()}`;
        else if (failed !== null) verdict = `挂载失败: ${failed.trim()}`;
        else if (pending) verdict = '永久 pending（某个 inject 的服务不存在）';
        else if (didNotActivate !== null) verdict = `未激活（见 did not activate 那行）: ${didNotActivate.trim()}`;
        else if (ownLog !== null) verdict = `挂载成功（插件自报: ${ownLog.trim().slice(0, 90)}）`;
        else verdict = '**无任何输出：判读不了**（DSH 成功时不打日志，但本脚本也没拿到正向证据）';
        return { name, skipping, failed, pending, verdict, ok: skipping === null && failed === null && !pending && didNotActivate === null && ownLog !== null };
    });

    console.log('结果');
    for (const row of rows) console.log(`  ${row.name.padEnd(20)} ${row.verdict}`);

    const allSilent = rows.every((row) => !row.ok && row.skipping === null && row.failed === null && !row.pending);
    const sameOutcome = rows[0].ok === rows[1].ok
        && rows[0].skipping === null === (rows[1].skipping === null)
        && rows[0].failed === null === (rows[1].failed === null);

    console.log('');
    if (allSilent) {
        console.log('结论：**判读不了**。两个插件都没打出任何日志 —— 既没有失败信号，');
        console.log('也没有成功信号。这条路径在当前环境给不出答案，别拿它下结论。');
        console.log('（成功的挂载本来是静默的，所以"沉默"既可能是成功也可能是启动失败。）');
    } else if (rows[0].skipping !== null && rows[1].skipping !== null) {
        console.log('结论：**无效对照** —— 两个插件都被 "cannot resolve" 跳过了，');
        console.log('说明 web profile 缺 @deepseek-ai/* 运行时（它由 Electron 应用提供，');
        console.log('CLI 启动的 web profile 没有）。上一轮就是在这里误判过一次。');
    } else if (sameOutcome && rows[0].ok) {
        console.log(`结论：${target} 与对照插件 ${control} 都正常挂载。`);
        console.log('→ 插件声明与文件都没问题。问题在 **desktop profile 的 Electron 运行时**。');
        console.log('→ 下一步：完全退出 DSH（含托盘）再启动；若仍不出现，在插件管理页');
        console.log('   把 dsh-library 停用再启用，逼 DSH 重建这条 loader 行。');
    } else if (rows[0].failed !== null || rows[0].skipping !== null || rows[0].pending) {
        console.log(`结论：只有 ${target} 有问题，${control} 正常。`);
        console.log('→ 上面那行就是入口。');
    } else {
        console.log('结论：两者表现不同，细节见上面几行。');
    }
} finally {
    if (keep) {
        console.log('\n--keep：保留实验痕迹，未恢复。');
        restoreNeeded = false;
    } else {
        await restore();
        console.log('\nweb profile 已恢复原状。');
    }
}
