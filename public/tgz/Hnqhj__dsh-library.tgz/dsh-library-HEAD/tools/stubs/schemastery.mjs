/**
 * `@deepseek-ai/schemastery` 的最小替身，只在本地测试里使用。
 *
 * 本插件的配置模式在**模块求值期**构造一次（`z.object({...})`，每个字段再挂
 * `.default()`），所以替身只需要让这条链跑通、不抛异常。真正的字段校验由 DSH
 * 运行期的官方包负责。
 */
function field(kind) {
    const api = {
        default(value) {
            return { kind, value, schema: true };
        },
        min() {
            return api;
        },
        max() {
            return api;
        },
    };
    return api;
}

const z = {
    object(shape) {
        return { kind: 'object', shape, schema: true };
    },
    string: () => field('string'),
    boolean: () => field('boolean'),
    natural: () => field('natural'),
};

export default z;
