/**
 * 资料库 —— DeepSeek Harness 宿主半。
 *
 * 这个插件把"每次对话、每个项目的产出物"变成一处可以长期存放与检索的本地库：
 *
 *  1. `/api/library/*`：面板用的 HTTP 面；
 *  2. （阶段 5）只读 + 可新增的 Agent 工具：模型能检索资料、拿到绝对路径去引用。
 *
 * 两者共用同一个内核（`lib/service.js`），所以"人看到的"和"模型看到的"永远是
 * 同一份数据、同一套过滤语义。
 *
 * 结构取向与 `dsh-asset-library` 一致（那套写法已经在这台机器上验证过）：
 *  - `inject` 故意留空：没有任何服务是"必须存在才能加载"的。Web 服务器用 `ctx.get`
 *    懒绑定，并在 `internal/service` 事件里重试 —— 这样 headless profile 里插件是
 *    静默的，而不是永久 pending 在一个 Composition 根本不提供的 key 上。
 *  - 浏览器信任栅栏按请求解析，绝不快照：Connection 行可能在本插件之后激活。
 *  - 所有注册都挂在 `ctx.effect` 上，卸载即回收。
 *  - 自检状态通过 `/status` 暴露，省得靠猜。
 */
import { Config, resolveConfig } from './lib/config.js';
import { createService } from './lib/service.js';
import { registerLibraryRoutes } from './lib/routes.js';

/** 插件名（loader 行的 id 与它一致）。 */
export const name = 'library';

/** 见文件头：没有必需服务。 */
export const inject = [];

export { Config };
// 测试用的 spawn 间接层：见 `lib/routes.js` 里 `setSpawnForTest` 的注释。
// 导出的唯一理由是让 `tools/host-test.mjs` 能在不弹窗的前提下验 reveal 的契约。
export { setSpawnForTest } from './lib/routes.js';

/** Web 服务器服务的两种拼写，新的在前（老组合叫 `httpServer`）。 */
const WEB_SERVER_KEYS = ['webServer', 'httpServer'];

/**
 * 激活插件。
 *
 * @param ctx - host 插件上下文。
 * @param config - 已由 schema 补全的配置（缺失时这里再补一次）。
 */
export function apply(ctx, config) {
    const resolved = resolveConfig(config);
    ctx.logger.info(`library: ready (root=${resolved.root === '' ? 'dsh-home/library' : resolved.root})`);

    let disposed = false;
    ctx.effect(() => () => {
        disposed = true;
    }, 'library: activation state');

    /** 自检状态：`/status` 会把它带出来。 */
    const state = { web: false };

    /**
     * 会话工作目录。
     *
     * 宿主把会话放在 `ctx.sessions` 里。这里只做保守的启发式：取列表里第一个带
     * `cwd` 的会话（宿主按最近活动排序），拿不到就返回 `undefined`。阶段 3 的
     * "把本轮产出收进资料库"要用它定位来源项目。
     */
    const sessionProjectRoot = async () => {
        const sessions = ctx.get('sessions');
        if (sessions === undefined || typeof sessions.list !== 'function') return undefined;
        const list = await sessions.list();
        const entries = Array.isArray(list) ? list : Array.isArray(list?.items) ? list.items : [];
        for (const entry of entries) {
            const cwd = entry?.header?.cwd ?? entry?.cwd;
            if (typeof cwd === 'string' && cwd.trim() !== '') return cwd;
        }
        return undefined;
    };

    const service = createService({
        config: resolved,
        logger: ctx.logger,
        sessionProjectRoot,
        diagnostics: () => ({ web: state.web }),
    });

    // ---- HTTP 面：懒绑定，服务出现即注册
    const registerWebSurface = () => {
        if (state.web || disposed) return;
        const webServer = ctx.get(WEB_SERVER_KEYS[0]) ?? ctx.get(WEB_SERVER_KEYS[1]);
        if (webServer === undefined) return;
        ctx.effect(() => registerLibraryRoutes(webServer, () => ctx.get('connection'), service), 'library: HTTP API');
        state.web = true;
        ctx.logger.info('library: HTTP API mounted at /api/library');
    };
    registerWebSurface();

    ctx.on('internal/service', (serviceName) => {
        if (serviceName === WEB_SERVER_KEYS[0] || serviceName === WEB_SERVER_KEYS[1]) registerWebSurface();
    });
}
