# dsh-asmrone 交接文档

> 写给下一个接手的人或 AI 会话。目标：**不看之前的对话历史，也能继续开发这个插件。**
> 最后更新：2026-10-05 · 插件版本 0.4.0

---

## 一句话

把音声接进 DeepSeek Harness，**四条来源**：

| 来源 | 要不要代理 | 能干什么 |
|---|---|---|
| **asmr.one**（DLsite 整库镜像，6 万余部） | 要魔法 | 搜索、权重排序、在线播放、批量下载、DLsite 官方试听包抓取 |
| **B 站** | **不用** | 搜索、流式播放（助眠 / 白噪音 / ASMR 存量极大），**不落盘** |
| **DLsite 官方试听** | 要魔法 + 本插件的 DoH 补丁 | 探测 / **在线听**（内存，不落盘）/ **下载**（落盘） |
| **本地曲库** | 不用 | 列已下载的、离线播放、**删除**（单轨 / 整部 / 批量多选） |

带 Web 面板（四个标签页 + 常驻播放器 + 悬浮球），也带一条让 agent 直接推歌出声的通道。

---

## 目录与安装位置

| 东西 | 路径 |
|---|---|
| 插件本体 | `/root/dsh-asmrone/` |
| 安装位置（软链） | `/root/.dsh/profiles/web/node_modules/dsh-asmrone` → `../../../../dsh-asmrone` |
| 运行配置 | `/root/.dsh/asmrone/config.json` |
| 加载日志 | `/root/.dsh/asmrone/boot.log` |
| 技能 | `/root/.dsh/skills/asmr-ambience/SKILL.md` |
| 宿主日志（插件加载失败时看这个） | `/root/dsh-web.log` |

重新安装：`export PATH="/root/dsh-bin:$PATH"` 然后 `dsh plugin --profile web add link:/root/dsh-asmrone`。

---

## 这台机器的硬约束（先读这节）

**一、绝对不要杀宿主进程。** 插件跑在 `dsh web` 进程里（3080 端口，PID 记在 `/root/.dsha-web.pid`）。
禁 `kill`/`pkill`/`killall` 命中它、禁 `POST /dsh-purge/restart`、禁写 `/root/.dsha-stopped`、禁另起 `nohup dsh web`。
杀了自己就没了，**没有任何守门狗会把你拉起来**。

需要重启才能生效时：确认改动落盘 → `node --check` + 跑测试 → **停下来告诉用户去 App 里重启**，并把「现在还不生效的部分」逐条列清楚。

**二、host 侧与 client 侧的热更新行为不一样** —— 这是最容易搞错的一点：

| 改了什么 | 生效方式 |
|---|---|
| `client/client.js` | **刷新页面**即可（每次加载页面都重新取） |
| `src/**`（路由、工具、store、local…） | **必须重启 dsh** |
| `cordis.patch.yml` | 必须重启 dsh |
| `SKILL.md` | 立即生效（技能表每次会话重扫） |

**三、容器网络。** 实测（2026-10-05）：

| 目标 | 结果 |
|---|---|
| `api.bilibili.com` / `www.bilibili.com` | **直连 200，不用魔法** —— 唯一能直连的在线音源 |
| `asmr.one` / `api.asmr.one` | **不通**（000），要魔法 |
| `dlsite.com` / `trial.dlsite.com` / `play.dlsite.com` | **被墙**，要魔法；而且见下面那条 DNS 的坑 |
| `missevan.com`（猫耳FM）/ `ximalaya.com`（喜马拉雅） | 主页 200，但接口有 WAF / 风控 |
| `baidu.com` | 200 |

**四、DLsite 要同时满足两个条件，缺一不可：**

1. **手机上的代理 / VPN 开着** —— 容器的出网**跟着它走**。
   VPN 关着时任何 DLsite 请求都会挂到超时，这一层插件管不了。
   实测出口走 WARP（Cloudflare，`colo=LAX`）。
2. **DNS 得是对的** —— 即使 VPN 开着，容器系统 DNS（`8.8.8.8` / `223.5.5.5`）依然
   返回被污染的结果：`www.dlsite.com` → `2001::6ca0:a21f` 和 `108.160.170.43`
   （后者是 Dropbox 的 IP）。这一层由 `src/doh.js` 解决。

`undici` 模块**不可用**（`ERR_MODULE_NOT_FOUND`），所以宿主 fetch 挂不上 `ProxyAgent`；
本地也没有任何常见代理端口在听（7890/7891/10808/10809/1080/8888/8080/20171 全空）。

---

## 架构

### 两层

```
src/index.js  ── apply(ctx, config)
   ├─ 装 DoH 补丁（只对 dlsite.com 生效，dispose 时还原）
   ├─ 注册 10 个工具（ctx.tools.register）
   ├─ 建 runtime = { api, dlsite, bilibili, doh, store, pending, library, trial, getConfig, setConfig }
   └─ ctx.inject(['webServer']) → registerRoutes({ webServer, runtime })
                                    └─ 挂在 /asmrone 前缀下
```

`runtime` 是整个插件的中枢，工具和路由都从它取依赖。**加新东西时优先往 runtime 上挂**，别搞模块级单例。

### 文件清单

| 文件 | 干什么 |
|---|---|
| `src/index.js` | 入口。配置解析、DoH 补丁、runtime 组装、工具注册、路由挂载。外面套 try/catch 写 `boot.log` |
| `src/api.js` | asmr.one 封装（`AsmrOneApi`）、`summarizeWork`、`flattenAudio`、`isFemaleOriented`、`ORDER_FIELDS` |
| `src/bilibili.js` | **B 站音源**（`BilibiliClient`）：WBI 签名、buvid 凭据、搜索、DASH 取流、**Range 转发**、直链缓存 |
| `src/doh.js` | **DoH 解析器**（`DohResolver`）+ `installDohLookup` 定向补丁 + `isDlsiteHost` |
| `src/dlsite.js` | DLsite 试听抓取（`DlsiteTrialClient`）+ 纯 Node 的 zip 读取器 + Shift-JIS 文件名还原 + `reachable()` |
| `src/trial.js` | **内存试听库**（`TrialLibrary`）：拉 zip → 解压 → 驻留内存 → `subarray` 切片 |
| `src/local.js` | **本地音声库**（`LocalLibrary`）：扫盘、聚合、路径安全校验、MIME、**删除** |
| `src/pending.js` | **待播队列**（`PlayQueue`）：agent → 前端的单槽推送。四种来源共用 |
| `src/store.js` | 配置读写（`AsmrStore`），白名单键、坏 JSON 兜底、越界夹取 |
| `src/http.js` | 全部 HTTP 路由 + `parseRange` + `withStream` + 各来源的代理地址构造 |
| `src/define-tool.js` | 工具定义包装（schema 编译 + render 归一化）**从这里复制自 dsha-localdream，改动要谨慎** |
| `src/tools/*.js` | 10 个工具各一个文件 |
| `client/client.js` | 浏览器半身，单文件自包含（2200+ 行）。侧边栏入口 + 四个标签页 + 常驻播放器 + 悬浮球 |
| `scripts/verify-http.mjs` | 端到端自检：起假 webServer 打真实端点 |
| `scripts/scan-local.mjs` | 打印本地库扫描结果（排查用） |

### 十个工具

`asmr_search` · `asmr_work` · `asmr_play` · **`bili_search`** · **`bili_play`** ·
`asmr_download` · `asmr_trial`（探测 / 在线听 / 下载三合一）· **`asmr_delete`** · `asmr_local` · `asmr_config`

### HTTP 路由（全在 `/asmrone` 前缀下）

| 方法 | 路径 | 说明 |
|---|---|---|
| GET | `/config` | 读配置 |
| POST | `/config` | 改配置（白名单键） |
| GET | `/tags` | asmr.one 的 422 条标签表 |
| GET | `/search` | `q` `order` `page` `pageSize` `chinese` `female` |
| GET | `/work` | `id=` 音轨树 |
| POST | `/sizes` | `{hashes}` 并发探体积 |
| **GET** | **`/pending`** | `since=<seq>` 取待播（前端每 3 秒轮询） |
| **POST** | **`/play`** | `{id, hash?, index?}` / `{localKey, index}` → 入队 |
| GET | `/stream` | asmr.one 音频代理（透传 302 + Range） |
| GET | `/local` | 本地曲库列表；`q=` 过滤、`force=1` 绕缓存 |
| GET | `/local-stream` | 本地文件流；`key=`+`index=` 或 `path=`，支持 Range |
| **POST** | **`/local/delete`** | `{targets:[{key, indexes}], dryRun?}` —— 单轨 / 整部 / 批量删 |
| **GET** | **`/bili/search`** | `q` `order` `page` `pageSize` |
| **GET** | **`/bili/work`** | `ref=`（BV 号 / av 号 / 链接）→ 含分 P 列表 |
| **POST** | **`/bili/play`** | `{ref, page?, quality?}` → 入队并推播 |
| **GET** | **`/bili-stream`** | `bvid=`+`cid=`+`q=` → 流式转发 B 站 CDN（支持 Range / HEAD） |
| GET | `/trial` | `rj=` 探 DLsite 试听包（不下载） |
| **POST** | **`/trial/open`** | `{rj}` → 拉 zip 进内存并解开，返回曲目 |
| **POST** | **`/trial/save`** | `{rj}` → 把内存里的试听落盘到本地曲库目录 |
| **POST** | **`/trial/close`** | `{rj?}` 释放内存（不带 rj 即全清） |
| **GET** | **`/trial-stream`** | `rj=`+`index=` → 从内存切片（支持 Range / HEAD） |

### 客户端要点

- 面板：居中圆角弹窗（`--dsw-alias-*` 设计令牌 + `#4f7cff` 主色）
- **四个标签页**：在线曲库 / B站 / DLsite 试听 / 本地曲库
- 音轨**内联展开在所属卡片正下方**（不是弹层、不是新窗口）
- 播放器 `<audio>` **挂在 `document.body` 上，不在 React 树里**（见下）
- 关掉面板后留一枚**可自由拖动的悬浮球**，点击展开控制条，2.8 秒自动缩回
- 删除是**两步交互**：先点「删整部 / 删这轨」或进多选模式勾选 → 出确认条 → 才真发请求。
  刻意不用 `window.confirm`（WebView 里样式不受控，还会挡住播放控制条）

### 配置键（`/root/.dsh/asmrone/config.json`）

`outputDir` · `localDirs` · `languageFilter` · `defaultOrder` · `downloadConcurrency` ·
`maxWorkMb` · `pageSize` · `dohEndpoint` · `dohEnabled` · `trialMaxWorks` · `trialMaxMb` · `trialMaxTrackMb`

---

## 踩过的坑（这部分最值钱）

### 1. `output.schema` 写成非法 JSON Schema 类型 = 整个插件不激活

**症状**：所有工具报 `unknown tool`，所有路由 404，宿主日志只写一行 `dsh: warning: 1 entry did not activate`。
**原因**：`output.schema: { type: 'json' }` —— `type` 只能是 `object/array/string/number/integer/boolean/null`。
**排查**：用宿主自己的校验器验：
```js
const { assertSupportedJsonSchema } = require('/usr/local/lib/node_modules/@deepseek-ai/dsh/node_modules/@deepseek-ai/dsh-tools/lib/index.js')
```
`test/asmrone.test.mjs` 里那条「十个工具的 schema 类型全部合法」就是钉这个的回归测试，别删。

### 2. 工具的 `render` 必须返回**内容块数组**

返回裸字符串会让宿主抛 `content.some is not a function`。
`define-tool.js` 里做了归一化，所以工具里写字符串也活。

### 3. `<audio>` 放进 React 树 = 面板一关音乐就断

现在 audio 是 `document.body` 上的页面级元素（`ensureAudio()`），组件重挂还会把播到一半的 src 接回来。
**卸载清理时故意不删这个元素**。

### 4. 藏 audio 不能用 `display:none`

部分 WebView 会直接停播。用 `position:fixed + 1px + opacity:0 + pointer-events:none`。

### 5. `flattenAudio` 要**数组根**，传对象会静默返回 0 轨

`api.tracks(id)` 保证返回数组。

### 6. 进度轮询与拖动打架 / 自动缩回计时器的依赖里不能放 `currentTime`

拖动时必须置 `scrubbing: true`；缩回用 `miniTouched`（用户交互计数器）当信号。

### 7. 在线用例网络不通时要 `t.skip()`，不能 `assert.ok(true)`

早期写法制造了「16 pass」的假绿。**同理反向也成立**：接口可达但返回空
（B 站在出口波动 / 风控限速时会这样）也要 skip，而不是 fail —— 见 `test/bilibili.test.mjs`。

### 8. asmr.one 把视频文件也标成 `type: "audio"`

下载过滤必须是**扩展名白名单**（见 `tools/download.js` 的 `AUDIO_EXTENSIONS`）。

### 9. 中文搜索是标题匹配

`query=舔耳` 只有 2 条命中。要覆盖全得用日文关键词（`耳舐め` / `耳かき`）。

### 10. DLsite 试听是 **zip 不是 mp3**，而且**没有独立的音频流接口**

早期按 `.mp3` 拼 URL 全部 404。真实地址在 touch 页的 Nuxt payload 里。
`play.dlsite.com` 上那条 `/api/sample/token/{workno}` → `{prefix}/ziptree.json` →
`/optimized/{hash}.m3u8` 的链路**只对特定作品成立**，对没有音频试听的作品稳定 404 ——
别在这上面绕，**直接从 zip 拿就行**（`src/trial.js` 就是这么做的）。
老包是 CP932 文件名、无 UTF-8 flag，靠 `TextDecoder('shift_jis')` 还原。

### 11. 路径安全：`local-stream` 背后是「读任意文件」

`LocalLibrary.resolveWithin()` 是唯一入口校验，三件事缺一不可：
扩展名白名单、**前缀比较带分隔符**（否则 `/x/asmr-evil` 会被 `/x/asmr` 放行）、**走 `realpath`**（防符号链接）。

**删除比读取还危险一个量级**，所以 `resolveDirWithin()` 多两条：解析后必须**比根深至少一级**、
且**永不允许等于根本身**。`test/delete.test.mjs` 里那组用例（根目录保护、软链穿越、根外路径）别删。

### 12. B 站 CDN 的 UA + Referer 门禁 —— 少一个就是 403

实测同一串带签名的音频直链：

| 请求头 | 结果 |
|---|---|
| PC Chrome UA + Referer | **206** |
| Android UA + Referer | 403 |
| 空 UA + Referer | 403 |
| 不带 Referer | 403 |

响应体只是 openresty 的裸 403 页，**看不出原因**。所以 `PC_UA` 与 `CDN_REFERER` 必须原样
带到每一次 CDN 请求上，包括 Range 转发。

### 13. B 站搜索要 WBI 签名，否则连发几个就 412 风控

签名 = 参数按 key 排序 → URL 编码（滤掉 `!'()*`）→ 拼 `wts` → 串上 mixin key 求 md5 当 `w_rid`。
mixin key 由 `nav` 接口的两个 key 按固定 64 位表（`MIXIN_TAB`）重排而成。
**还要带 buvid3 / buvid4**，不带的话签名也救不了。
三件事都做了之后实测连造 8 个关键词 0 次拦截。撞了 412 要**退避 30 秒 + 作废凭据**再重试。

### 14. B 站 CDN 不认 HEAD（回 404）

而播放器和 HTTP 缓存都可能先拿 HEAD 探长度。`fetchAudio` 把 HEAD 翻成 `GET + bytes=0-0`，
调用方从 `Content-Range` 里抠出真实总长再自己拼响应头 —— **不能透传上游的 `Content-Length: 1`**，
那会让播放器以为整首只有一字节。

### 15. B 站的 DASH 音频是**完整 fMP4**，不用 ffmpeg

`playurl?fnval=16` 的 `dash.audio` 单轨自带 `ftyp` + `moov`（在前）+ `sidx`，
浏览器 `<audio>` 直接能播、能 seek。**所以只取音频轨、不碰视频轨、不做合并** ——
容器里根本没有 ffmpeg。`test/bilibili.test.mjs` 里那条「前 8 字节是 `....ftyp`」就是钉这个前提的。

### 16. DLsite 的 DNS 污染 + VPN 依赖（见上文「硬约束 · 第四条」）

**把这两件事分开看很重要**：DoH 补丁不是「绕过网络封锁」，它只保证「网络已经通了的时候，
域名能解析到对的地方」。VPN 关着时它无能为力 —— 所以 `DlsiteTrialClient.reachable()`
必须被显式调用，给用户一句人话，而不是让请求挂在那儿等超时。

补丁本身只认 `dlsite.com` 后缀（`isDlsiteHost`），且要处理三件事：
`(host, cb)` 与 `(host, options, cb)` 两种签名、`family: 6` 的请求直接放行、
`options.all` 为真时回数组。

### 17. 在线条目的 `stream` 曾漏走代理

`withStream` 早期给在线条目塞的是 asmr.one 的**原始 URL**，播放器照播不误，
所以一直没被发现 —— 直到 `verify-http` 里那条断言在代理通了之后才跑起来。
CDN 没有 CORS 头、原始地址还会 302 跳一次，**这两件事正是 `/asmrone/stream` 存在的理由**。
四种来源的地址构造现在集中在 `withStream` 里（`asmrStreamUrl` / `biliStreamUrl` / local / trial）。

### 18. 本地文件目录名里的 RJ 号要归一

`RJ01726233` → `1726233`（跟 asmr.one 的 id 形式一致）。

### 19. RJ 号认不出来是**用户传错了**，该回 400 不是 500

`normalizeWorkno` 抛的是普通 Error，直接漏到外层 catch 会变成 500。
`http.js` 里统一用 `requireWorkno()` 翻译成 `HttpError(400)`。

### 20. 错误原因被 500 吞掉，前端就只能猜

`/asmrone/trial/open` 对 `RJ01678178` 曾稳定回 500 `操作失败`，看着像「网络不通」。
链路其实是通的 —— 真因是那部试听包 100.39MB，超过了当时 100MB 的在线听上限。
`http.js` 的兜底只把匹配 `/超时|asmr\.one|DLsite|fetch|HTTP /` 的 message 带出去，
**其余一律压成「操作失败」**；前端拿到这四个字，没有别的线索可抓，就把它归到了
唯一有文案的分支：「DLsite 是被墙的 —— 需要手机上的代理/VPN 开着」。
于是用户开着梯子，反复确认自己有没有开梯子。

三处一起改掉，缺一条都会复发：

1. **兜底一律带 message**。状态码仍然分上游/本地，但那只是分档，不是删信息的理由。
2. **试听库的业务错翻成 409**（`withTrialReason`）。「这部没提供官方试听」「超过在线听上限」
   「解压后太大」都是**岔路**，不是服务器故障 —— 前端要靠原话决定给哪个出口。
3. **`describeTrialError` 先判是不是链路层失败**（`TRIAL_LINK_RE`），判不出来就原样显示。

还有两个连带发现：

- 在线听上限 100MB 订得太贴边（真实作品正好卡在 100.39MB），而且与 `trial.js` 头部注释里
  写的 150MB 不一致 —— 先统一成 150，后来分段读做出来之后直接放宽到 **800**（见第 21 条）。
- 「下载到本地」按钮原先只活在「打开成功」才渲染的面板里，**超过在线听上限的试听包
  于是既听不了也存不下**，用户被卡死在提示上。现在打开失败时错误旁边就有下载按钮
  （前端 `trialFailRj`），`/trial/save` 也会为未打开的 RJ 按下载档上限（`maxWorkMb`）自动拉一次。
- **提示的位置也是需求，不是美观问题**：最初把失败说明和下载按钮放在结果列表**顶端**，
  真机上立刻被反馈「全都在最上面显示」—— 用户对着顶上那句话，看不出是哪一部出的问题。
  现在 `trialFailRj` 会和结果列表里的 `workno` 对一遍，对得上就贴到**那一张卡片下面**；
  只有对不上（粘贴的 RJ、从别的标签页跳过来）才回退到顶端兜底。
  「正在打开」的 loading 一并挪到卡片下 —— 否则点一下试听，整页看起来都在等。
  注意 `verify-http` 里那条检查因此改了预期 —— 别再拿真 RJ 去验「未打开」，
  那样每跑一次都会往本地曲库塞一份试听。

### 21. 试听包的真正瓶颈是内存，不是上限 —— 改成远端分段读

修完第 20 条之后，「打开试听」对一部分作品仍然失败：DLsite 的大合集试听包实测有
**231MB / 245.54MB** 的（`RJ01722990` / `RJ01716758`），而手机可用内存只有 2.71GB、
宿主 dsh 自己已占 826MB、swap 吃到 5.8GB。把上限调大只是把失败推迟到 OOM ——
而宿主 OOM 是会把 dsh 一起带走的事故。

方向反了：不该允许「拉整包」，该**不拉**。CloudFront 对这批 zip 支持 Range
（实测 `bytes=0-99` → `206` + `content-range`），于是：

- **打开**只取尾部 64KB+22（EOCD + 中央目录），秒级返回，驻留 0；
- **播放某轨**时才按该条目的偏移取数据段并 inflate，取回的轨进 LRU；
- **下载**逐轨取、逐轨写盘，内存里同时只有一轨。

实测 `RJ01716758`（245.54MB，内容 320MB / 4 轨）：打开 9.1s、驻留 0 B；
播第 1 轨 12.1s、常驻 76MB；三轨轮着听，缓存稳定在 ~182MB 并自动淘汰。
旧写法在这一部上是**直接拒绝**。

**取舍**：整轨必须驻留才能切片（deflate 不支持随机访问，想切中间一段也得从头
inflate），所以留了一道单轨闸门 `trialMaxTrackMb`（默认 200MB）；包体积上限
`trialMaxMb` 因此可以放宽到 800MB —— 它不再跟内存挂钩，只剩「防误点巨物」的意思。
`/trial-stream` 的 HEAD 分支刻意**不取数据**：播放器探长度时会先问一次，
不该为整轨付一次下载代价。`save`/`saveAll` 走 `enforceLimit: false`，
不受单轨闸门约束 —— 下载本来就是「在线听放不下」时的出口，再挡一次等于两条路都堵死。

顺带一个意外收获：`RJ01722990` 那个 231MB 的包**根本没有音频**（是交互游戏 demo）。
新写法在读中央目录那一刻就知道，**零下载**报出「没有音频试听」；旧写法要先白下 231MB。

### 22. 循环与定时是助眠刚需，但「整部循环」有个闭包陷阱

「一首反复放、到点自己停」—— 人睡着以后不会起来点暂停，所以这两件事不是锦上添花。

- **循环三态**（关 / 单曲 / 整部）：单曲交给 `audio.loop`，它设成 `true` 时 `ended`
  根本不触发，与「整部循环走 `ended` → 下一轨」天然互斥，不必在 `onEnded` 里再判一次。
- **定时关闭按「截止时间戳」对表**，不是递减计数：WebView 切到后台时 `setInterval`
  会被降频甚至冻结，数秒数会越数越偏；对时间戳则一次 tick 就追回来了。
- 两个开关在**面板底栏和悬浮条上各有一份** —— 助眠时面板多半是关着的。

**闭包陷阱**：`playNextInList` 靠 `state.playList` 找下一轨，而四个播放点各自
`setState` 完才生效。B 站那条最容易踩 —— 卡片上的播放键是 `playBiliDirect`，
它 `setState({ biliPages })` 之后**立刻**调 `playBili`，此时闭包里的 `state.biliPages`
还是旧的空数组，列表会建成空的，「整部循环」在这条最常用的路径上静默失效。
所以 `playBili` 加了第四个参数显式接收分 P 列表。`test/rank.test.mjs` 里那条
「`playlistOf` 应当出现四处」的硬断言就是钉这个的 —— 以后再加播放路径，它会提醒你接上。

---

## 验证方式

```bash
cd /root/dsh-asmrone
npm run check        # 语法检查（src/ + tools/ + client/ + scripts/）
npm test             # 93 个用例；在线用例网络不通时自动 skip
npm run verify:http  # 端到端：起假 webServer 打真实端点
npm run scan:local   # 打印本地库扫描结果
```

当前基线：**93 tests / 全绿**（网络不通时在线用例 skip，结果诚实）。

`verify:http` 里不依赖网络的那一组应当始终全绿（已实测）：
`/local` 扫到作品 → `HEAD /local-stream` 200 → Range 206 → 越界 416 → 库外 403 →
推本地到队列 → `/local/delete` 空 targets 400 → `/bili-stream` 缺参数 400 →
`/trial-stream` 未打开 409 → `/trial/save` 非法 RJ 400。

`test/rank.test.mjs` 有个取巧但不偷工的做法：**从 `client/client.js` 里截取 `#region rank-core` 那段纯函数**
再求值。被测的就是线上那份代码。改那段时别破坏 `#region` 标记。

---

## 当前数据现状

**本地库：32 部 / 154 轨 / 5.0 GB**

- `/sdcard/Download/ASMR` — 4 部 / 20 轨 / 577 MB（`asmr_download` 下的）
- `/sdcard/Download/DLsite试听` — 28 部 / 134 轨 / 4.5 GB（DLsite 试听包解出来的，WAV 为主）

扫描器按扩展名过滤，跳过 `.md` / `.jpg` 这类非音频。扫盘带 60 秒缓存。
**删除后会立刻 `invalidate()`**，否则面板还列着刚删掉的东西。

---

## 待办 / 未验证项

**未验证（容器没浏览器，客户端渲染无法自验）**
1. `shell.overlay` 容器是否真的常驻 —— 从会话管理插件的架构反推的。就算它被卸载，
   audio 也已脱离 React，声音不会断，最坏是控制条跟着消失。
2. MediaSession 在 dsh 那个 WebView 里能不能被系统认（锁屏 / 通知栏控制）。
3. 悬浮球位置存的是视口坐标，**横竖屏旋转后不会重算**。
4. 四个标签页的新 UI（B站卡片、试听面板、删除多选）**只在代码层面验过，没在真机上渲染过**。
5. 300MB+ 的 WAV 拖动进度到后期的手感。

**待办**
1. **B 站登录** —— 评估过，**不建议**：二维码接口（`passport.bilibili.com`）是通的，
   扫码就能登、不碰密码，但换来的只有「大会员无损档 + 更宽松的风控」；
   实测匿名已经能拿 30280（192K，非会员顶格），标着 Hi-Res 的稿件 `dash.flac` 也是 `null`。
   代价却是把 30 天寿命的 `SESSDATA` 放进容器文件，而且容器出口是 WARP（洛杉矶），
   与用户手机直连 IP 不同城，登录后容易触发异地验证。要做也得走「二维码 + 小号」。
2. ~~播完一首自动下一轨~~ —— 已做（循环三态：关 / 单曲 / 整部，见第 22 条）。
3. **「换源」**：同一个作品在多个来源都有时，能不能一键从当前源切到另一个。
   目前四个来源是四个标签页，互相不知道对方有什么。
4. 发布到 GitHub + npm（用 `dsh-plugin-release` 技能）。

**可以做的加固**
- 悬浮球在 `resize` / `orientationchange` 时重新夹取位置。
- 面板「在线」标签页在检测到网络不通时，直接提示「切到本地曲库 / B站」而不是干等着报错。
- B 站搜索的词条缓存（同一会话里同一个词不重复打接口，省风控额度）。
- ~~试听包按需分段取~~ —— 已做，见第 21 条。下一步能压的是**预取下一轨**
  （首播要等 12~15 秒，预取能把这个抹掉；代价是内存翻倍，得先想清楚值不值）。

---

## 发布

- 仓库：<https://github.com/133563825as-ai/dsh-asmrone>（MIT）
- 首个正式版 **v1.0.0**：tag 打在 main 的 `0301406`，Release 已建。
- topics 含 `dsh-plugin`（插件目录抓取就看这个），npm `keywords` 里也有。
- 匿名复验（不带任何凭据）已过：main 的 `package.json` 读到 `version 1.0.0`、
  `dependencies: {}`；`search/repositories?q=repo:...+topic:dsh-plugin` 命中 1；
  仓库页与 Release 页都是 200。

### 发布这台机器上的一个坑

全局 git 配置里有一条：

```
url.https://gh-proxy.com/https://github.com/.insteadOf = https://github.com/
```

它把所有 `github.com` 的 URL 改写成那个**只读加速镜像**，于是 `git push` 直接死：

```
fatal: could not read Username for 'https://gh-proxy.com'
```

`git remote get-url origin` 也会**读出被改写后的地址**（要看原始值得用
`git config --get remote.origin.url`）—— 这跟 SKILL 里记的那条是同一个坑。

推的办法：临时 `git config --global --unset-all` 这条、推完立刻加回去。
token 走 `-c http.extraheader="AUTHORIZATION: basic $(printf 'x-access-token:%s' "$T" | base64 -w0)"`，
**不要**写进 remote URL，也别让它进 `.git/config`。

### npm 还没发

宿主没有 `.npmrc`，也没有配 Trusted Publisher。要走 CI(OIDC) 需要两步：

1. 加 `.github/workflows/publish.yml` —— tag 触发。
   ⚠️ **别给 `setup-node` 设 `registry-url`**：它注入的占位 `NODE_AUTH_TOKEN` 会盖掉 OIDC，
   `npm publish` 报 404（npm 拿 404 代替 403）。
2. 去 npmjs.com 把本仓库配成这个包的 Trusted Publisher。

在那之前不要推新 tag —— CI 没有 npm 身份，会留一个红叉。

---

## 设计取向（改代码时请保持）

- **运行期零依赖**：只 import Node 内置模块，`dependencies` 是空的。别往插件目录塞 node_modules。
- **不内置内容偏好**：性别过滤、排序、落盘目录全来自可改的配置。
- **中文注释，讲清楚「为什么」**：代码里那些长注释记的是踩坑原因，别当废话删掉。
- **测试宁可诚实 skip，不要假绿**，也不要假红。
- **破坏性操作先说明再动手**，尤其是设备侧（adb-shell、pm、settings）与**删除**（不可逆，没有回收站）。
- **代理地址集中构造**：四种来源的播放地址只在 `withStream` 与它的几个 `xxxStreamUrl` 里拼，
  别在工具或客户端里另起一套。
