/**
 * dsh-asmrone — 浏览器半身。
 *
 * 两个挂载点：
 *   1. `sidebar.footer.action` —— 侧边栏入口按钮（双行标题，跟会话管理插件同款）
 *   2. `shell.overlay`         —— 面板 + **常驻播放器**
 *
 * 设计语言跟 dsh-api-dashboard / dsh-session-manager 对齐：`--dsw-alias-*` 令牌、
 * #4f7cff 主色、圆角 20/16px、纯 SVG 图标（不用 emoji）、跟随系统深浅色。
 *
 * 播放器的两条硬约束：
 *   ① `<audio>` 元素**不在 React 树里** —— 它是一个挂在 `document.body` 上的
 *      页面级元素（见 `ensureAudio`）。面板关闭、切到对话页、容器重建都不影响它，
 *      所以组件返回的永远是 Fragment，面板只是其中一段按 `open` 显隐。
 *      早先 `if (!state.open) return null` 直接把播放器一起拆了，音乐跟着断。
 *   ② 用 `position:fixed + 1px + opacity:0` 藏 audio，不用 `display:none`
 *      （后者在部分 WebView 上会停播）。
 *
 * 所有数据走 host 的 `/asmrone/*`；音频走 `/asmrone/stream` 代理，
 * 因为 asmr.one 的 CDN 不带 CORS 头，前端直连会被挡。
 */
window.__ModuleLoader__.load({
  id: 'dsh-asmrone',
  factory: (require) => {
    const react = require('react')
    const h = react.createElement
    const NS = 'dsh-asmrone'

    const zh = {
      title: '音声库',
      openPanel: '打开音声库',
      panelAria: '音声库面板',
      close: '关闭',
      search: '搜索',
      searchPlaceholder: '题材 / 社团 / 声优 / 简体中文版…',
      order: '排序',
      orderSales: '销量',
      orderRating: '评分',
      orderNew: '最新上架',
      orderRelease: '发售日',
      chineseOnly: '只要中文',
      maleOnly: '排除女性向',
      go: '搜',
      total: '命中',
      unit: '部',
      empty: '没有结果，换个关键词或放宽过滤。',
      loading: '加载中…',
      idle: '输入关键词开始搜，或直接点「搜」看全库销量榜。',
      tracks: '音轨',
      trackUnit: '个',
      play: '播',
      playing: '播放中',
      downloadAll: '下整部',
      downloadOne: '下这轨',
      downloading: '下载中…',
      failed: '失败',
      save: '保存',
      saved: '已保存',
      config: '设置',
      trial: '试听',
      trialNone: '这部没有音频试听',
      more: '收起',
      err: '出错了',
      page: '第',
      prev: '上一页',
      next: '下一页',
      nowPlaying: '正在播放',
      pause: '暂停',
      resume: '继续',
      // 循环与定时 —— 助眠场景要的两个开关：一首反复放、到点自己停
      loopOff: '⟳ 关',
      loopOne: '⟳ 单曲',
      loopAll: '⟳ 整部',
      loopHint: '循环：关 → 单曲循环 → 整部循环',
      sleepOff: '⏱ 关',
      sleepOn: '⏱ {m}分',
      sleepLeft: '⏱ 剩{m}分',
      sleepHint: '定时关闭：关 → 15 → 30 → 60 → 90 分钟',
      sleepDone: '定时到点，已经停止播放。',
      // 权重面板
      weights: '搜索权重',
      weightsOn: '权重排序',
      weightsOff: '官方排序',
      weightHint: '拖动滑块按你的口味重排结果；全为 0 时用官方排序。',
      wDownloads: '销量',
      wRating: '评分',
      wRatingCount: '评价数',
      wFresh: '新鲜度',
      preset: '推荐配置',
      zero: '归零',
      depth: '候选池',
      depthUnit: '页',
      depthHint: '权重排序要先抓一批候选再打分。池子越大越准，也越慢。',
      poolNote: '权重排序中：从 {n} 条候选里挑出的第 {p} 页',
      shake: '清空',
      shuffle: '重新抓取',
      // 本地曲库
      tabOnline: '在线曲库',
      tabBili: 'B站',
      tabLocal: '本地曲库',
      // B 站曲库（国内直连，唯一不用代理的在线源）
      biliPlaceholder: '助眠 雨声 / 白噪音 / 耳舐め / 催眠…',
      biliIdle: '搜 B 站音轨。直连不用代理，播放是流式转发 —— 手机不落盘。',
      biliEmpty: '没有命中，换个词试试。',
      biliTotal: '命中',
      biliPages: '分 P',
      biliOpenPages: '展开分 P',
      biliPlayHint: 'B 站直连可用（asmr.one 要开代理）。点播放是流式转发，一个字节都不落到手机上。',
      biliOffline: 'B 站接口连不上。检查网络 —— 这条链路本来不需要代理。',
      biliOrderRank: '综合排序',
      biliOrderClick: '播放最多',
      biliOrderNew: '最新发布',
      biliOrderStow: '收藏最多',
      // DLsite 试听：在线听（内存）+ 下载（落盘），两条都补上
      tabTrial: 'DLsite 试听',
      trialPlaceholder: '搜 DLsite：耳かき / 催眠 / 白噪音…',
      trialIdle: '直接搜 DLsite 作品 —— 官方试听免费公开。点结果就能在线听（内存切片，手机不落盘）；想留就点下载。',
      trialSearch: '搜',
      trialOnlyMale: '只搜男性向',
      trialFound: '搜到',
      trialUnit: '部',
      trialNoResult: '没有命中，换个词试试（日文关键词命中率最高，比如「耳かき」「耳舐め」）。',
      trialOpen: '试听',
      trialProbe: '探测',
      trialPaste: '粘贴',
      trialPasteHint: '读不到剪贴板就在输入框里长按粘贴 —— RJ 号、整条链接、一段分享文本都认。',
      trialListen: '在线听',
      trialDownload: '下载到本地',
      trialNoTrial: '这部没有官方试听包 —— DLsite 上有一部分作品只提供图片试听。',
      trialNeedRj: '先填 RJ 号。',
      trialOpening: '正在拉取试听包并解开…',
      trialSaving: '正在落盘…',
      trialListenHint: '在线听是内存里的切片，磁盘一个字节都不写；听完满意再点下载，不会重下一次 zip。',
      trialSaved: '已存到本地曲库',
      trialTracks: '轨',
      trialZip: '试听包',
      trialRelease: '释放内存',
      trialBlocked: 'DLsite 连不上或太慢 —— 需要手机上的代理/VPN 开着。链路差的时候再点一次就好。',
      needRestart: '插件的后端还没加载新路由 —— 去 App 里重启一次 dsh 就好（面板这半刷新页面就行，路由那半必须重启）。',
      trialTranslated: '（{from} → {to}）',
      // 删除（不可逆）
      delWork: '删整部',
      delTrack: '删这轨',
      delSelect: '多选',
      delExit: '退出多选',
      delSelectAll: '全选',
      delSelected: '删选中',
      delCancel: '取消',
      delConfirm: '确认删除',
      delConfirmTitle: '确认删除？',
      delWarn: '删除不可恢复，本地没有回收站。',
      delDeleting: '删除中…',
      delDone: '已删除',
      delNothing: '还没选任何东西。',
      delSelectedN: '已选 {n} 部',
      delPickTracks: '勾选要删的轨',
      delThis: '删除本轨',
      localFilter: '过滤本地…',
      localEmpty: '本地目录里没扫到音频。检查设置里的目录。',
      localNoDir: '配置的目录不存在',
      localRescan: '重扫磁盘',
      localScanning: '扫描中…',
      localScanned: '已扫',
      localTotal: '合计',
      localDownload: '下载',
      localLibrary: '外部库',
      localTrial: '试听',
      localPlayHint: '本地文件不走网络，没开代理也能放。',
      onlineDown: '在线不可用 —— 没开代理时 asmr.one 连不上。切到「本地曲库」听已经下好的。'
    }

    // slot 传进来的 t 可能是函数、也可能是字典。两边都兼容。
    function makeT (propsT) {
      const tr = typeof propsT === 'function'
        ? propsT
        : (key, params) => {
            const value = zh[key] ?? key
            if (!params) return value
            return String(value).replace(/\{(\w+)\}/g, (_, name) => (params[name] ?? ''))
          }
      return new Proxy(tr, {
        get: (target, key) => (typeof key === 'string' ? tr(key) : target[key])
      })
    }

    /* ==================================================================== *
     * rank-core —— 纯函数区，**不碰 react / window**。
     *
     * test/rank.test.mjs 会把这段文本从本文件里截出来，用 `new Function`
     * 求值后直接单测。所以：
     *   · 这里只允许出现纯计算，别引用外部变量、别 import；
     *   · 改动这段就等于改动被测目标，公式漂移会当场被测试咬住。
     * ==================================================================== */
    //#region rank-core

    /** 权重键 → 用户可见名（i18n 键在 zh 里另有一份）。 */
    const RANK_KEYS = ['downloads', 'rating', 'ratingCount', 'fresh']

    /** 全零 = 不介入，直接用官方排序。 */
    const DEFAULT_WEIGHTS = { downloads: 0, rating: 0, ratingCount: 0, fresh: 0 }

    /** 一键推荐配置：销量为主，评分与新鲜度次之，评价数只做微调。 */
    const PRESET_WEIGHTS = { downloads: 1, rating: 0.6, ratingCount: 0.3, fresh: 0.4 }

    function clampNumber (value, min, max, fallback) {
      const n = Number(value)
      if (!Number.isFinite(n)) return fallback
      return Math.min(max, Math.max(min, n))
    }

    function sanitizeWeights (input) {
      const out = {}
      for (const key of RANK_KEYS) {
        out[key] = clampNumber(input?.[key], 0, 2, 0)
      }
      return out
    }

    function weightTotal (weights) {
      let sum = 0
      for (const key of RANK_KEYS) sum += Number(weights?.[key]) || 0
      return sum
    }

    /**
     * min-max 归一化到 0~1。
     * 全体相等（或只有一个样本）时返回 0.5 —— 返回 0 会让该维度整体失去意义，
     * 返回 1 又会把这一维度抬成决定性因素，取中间值最中性。
     */
    function normalizeMetric (values) {
      let min = Infinity
      let max = -Infinity
      for (const value of values) {
        const n = Number(value)
        if (!Number.isFinite(n)) continue
        if (n < min) min = n
        if (n > max) max = n
      }
      if (!Number.isFinite(min) || !Number.isFinite(max) || max - min <= 0) {
        return values.map(() => 0.5)
      }
      return values.map((value) => {
        const n = Number(value)
        if (!Number.isFinite(n)) return 0
        return (n - min) / (max - min)
      })
    }

    /**
     * 贝叶斯平滑评分。4.9 分但只有 2 个评价的作品，不该压过 4.6 分 800 个评价的。
     * 先验取 4.0 / 权重 12（asmr.one 的实际评分分布大致落在 3.5~5.0）。
     */
    function bayesRating (work, prior = 4, priorWeight = 12) {
      const rating = Number(work?.rating) || 0
      const count = Number(work?.ratingCount) || 0
      if (rating <= 0) return 0
      return (rating * count + prior * priorWeight) / (count + priorWeight)
    }

    /** 把作品折算成某个维度的原始数值。 */
    function metricValue (work, key) {
      if (key === 'fresh') {
        const raw = work?.release
        const ms = typeof raw === 'number' ? raw : Date.parse(String(raw ?? ''))
        return Number.isFinite(ms) ? ms : 0
      }
      if (key === 'rating') return bayesRating(work)
      return Number(work?.[key]) || 0
    }

    /**
     * 加权重排。
     * 权重全 0、或候选不足 2 条时原样返回 —— 不制造伪随机顺序。
     * 同分时按销量降序兜底，保证顺序稳定（同样的输入永远同样的输出）。
     */
    function rankWorks (works, weights) {
      const list = Array.isArray(works) ? works : []
      const safe = sanitizeWeights(weights)
      const active = RANK_KEYS.filter((key) => safe[key] > 0)
      if (active.length === 0 || list.length < 2) return list.slice()

      const columns = {}
      for (const key of active) {
        columns[key] = normalizeMetric(list.map((work) => metricValue(work, key)))
      }

      const scored = list.map((work, index) => {
        let sum = 0
        let total = 0
        for (const key of active) {
          sum += safe[key] * columns[key][index]
          total += safe[key]
        }
        return { work, score: total > 0 ? sum / total : 0 }
      })

      scored.sort((a, b) => {
        if (b.score !== a.score) return b.score - a.score
        const dl = (Number(b.work?.downloads) || 0) - (Number(a.work?.downloads) || 0)
        if (dl !== 0) return dl
        return String(a.work?.id ?? '').localeCompare(String(b.work?.id ?? ''))
      })

      return scored.map((row) => Object.assign({}, row.work, { score: row.score }))
    }

    /** 秒 → 0:00 / 0:00:00。非有限值一律给 0:00，别把 NaN 抖到界面上。 */
    function formatClock (seconds) {
      const total = Math.floor(Number(seconds))
      if (!Number.isFinite(total) || total < 0) return '0:00'
      const secs = total % 60
      const mins = Math.floor(total / 60) % 60
      const hours = Math.floor(total / 3600)
      const pad = (n) => String(n).padStart(2, '0')
      if (hours > 0) return `${hours}:${pad(mins)}:${pad(secs)}`
      return `${Math.floor(total / 60)}:${pad(secs)}`
    }

    function chunk (list, size) {
      const pageSize = Math.max(1, Math.floor(Number(size)) || 1)
      const out = []
      for (let index = 0; index < list.length; index += pageSize) {
        out.push(list.slice(index, index + pageSize))
      }
      return out.length > 0 ? out : [[]]
    }
    //#endregion rank-core

    const WEIGHT_LABELS = {
      downloads: 'wDownloads',
      rating: 'wRating',
      ratingCount: 'wRatingCount',
      fresh: 'wFresh'
    }

    //#region HTTP
    async function fetchJson (url, init) {
      const response = await fetch(url, init)
      let payload = null
      try {
        payload = await response.json()
      } catch {
        payload = null
      }
      if (!response.ok) {
        const message = payload && payload.error && payload.error.message
          ? payload.error.message
          : 'HTTP ' + response.status
        const error = new Error(message)
        error.status = response.status
        throw error
      }
      return payload
    }

    const postJson = (url, body) => fetchJson(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    })

    const api = {
      config: () => fetchJson('/asmrone/config'),
      setConfig: (patch) => postJson('/asmrone/config', patch),
      search: (params) => fetchJson('/asmrone/search?' + new URLSearchParams(params).toString()),
      work: (id) => fetchJson('/asmrone/work?id=' + encodeURIComponent(id)),
      download: (body) => postJson('/asmrone/download', body),
      trial: (rj) => fetchJson('/asmrone/trial?rj=' + encodeURIComponent(rj)),
      streamUrl: (hash) => '/asmrone/stream?hash=' + encodeURIComponent(hash),
      local: (params) => fetchJson('/asmrone/local?' + new URLSearchParams(params).toString()),
      localStreamUrl: (key, index) =>
        '/asmrone/local-stream?key=' + encodeURIComponent(key) + '&index=' + index,
      // 删除已下载的内容：targets = [{ key, indexes }]，indexes 空 = 整部
      localDelete: (body) => postJson('/asmrone/local/delete', body),
      // DLsite 试听：探测 / 打开（拉进内存）/ 落盘 / 释放
      trialSearch: (params) => fetchJson('/asmrone/trial/search?' + new URLSearchParams(params).toString()),
      trialProbe: (rj) => fetchJson('/asmrone/trial?rj=' + encodeURIComponent(rj)),
      trialOpen: (body) => postJson('/asmrone/trial/open', body),
      trialSave: (body) => postJson('/asmrone/trial/save', body),
      trialClose: (body) => postJson('/asmrone/trial/close', body || {}),
      trialStreamUrl: (rj, index) =>
        '/asmrone/trial-stream?rj=' + encodeURIComponent(rj) + '&index=' + index,
      // B 站曲库：搜索 / 分 P / 推播 / 流地址
      biliSearch: (params) => fetchJson('/asmrone/bili/search?' + new URLSearchParams(params).toString()),
      biliWork: (ref) => fetchJson('/asmrone/bili/work?ref=' + encodeURIComponent(ref)),
      biliPlay: (body) => postJson('/asmrone/bili/play', body),
      // 稳定 URL：只由 bvid/cid/码率决定，不含会过期的签名 —— WebView 才能按它缓存片段。
      biliStreamUrl: (bvid, cid, quality) => '/asmrone/bili-stream?' + new URLSearchParams({
        bvid: String(bvid),
        cid: String(cid),
        q: String(quality || 30280)
      }).toString()
    }
    //#endregion

    //#region 本地偏好（权重 / 候选池深度）
    const LS_WEIGHTS = 'asmrone:weights'
    const LS_DEPTH = 'asmrone:depth'
    // 悬浮球拖到哪儿，下次还在那儿。
    const LS_FAB = 'asmrone:fab-pos'

    function readPref (key, fallback, reviver) {
      try {
        const raw = window.localStorage.getItem(key)
        if (raw === null) return fallback
        const parsed = JSON.parse(raw)
        return reviver ? reviver(parsed) : parsed
      } catch {
        return fallback
      }
    }

    function writePref (key, value) {
      try {
        window.localStorage.setItem(key, JSON.stringify(value))
      } catch {
        /* 隐私模式 / 配额满：静默放弃，不影响功能 */
      }
    }
    //#endregion

    //#region 样式
    const CSS = `
@keyframes asmrone-fadein{from{opacity:0}to{opacity:1}}
@keyframes asmrone-pop{from{opacity:0;transform:scale(.96)}to{opacity:1;transform:scale(1)}}
@keyframes asmrone-slideup{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:translateY(0)}}

/* ── 侧边栏入口：跟会话管理插件同款双行结构 ── */
.asmrone-action-wrap{padding:2px}
.asmrone-action{display:inline-flex;align-items:center;gap:.5rem;padding:.375rem .65rem;border:1px solid var(--dsw-alias-border-l2,#e7e8ec);background:var(--dsw-alias-button-elevated-fill,#fff);color:var(--dsw-alias-label-primary,#17181c);border-radius:10px;cursor:pointer;font:inherit;width:100%;min-width:0;min-height:36px;transition:background .12s ease,box-shadow .2s ease}
.asmrone-action:hover{background:var(--dsw-alias-button-floating-hover,#f5f6f8);box-shadow:0 2px 8px rgba(0,0,0,.06)}
.asmrone-action:active{transform:scale(.985);opacity:.9}
.asmrone-action svg{flex:none;font-size:1.125rem}
.asmrone-action-content{display:inline-flex;align-items:center;gap:.5rem;min-width:0;flex:1}
.asmrone-action-logo{width:20px;height:20px;border-radius:6px;object-fit:cover;flex:none}
.asmrone-action-text{display:flex;flex-direction:column;align-items:flex-start;min-width:0;line-height:1.15}
.asmrone-action-title{font-size:13px;font-weight:700;color:var(--dsw-alias-label-primary,#17181c);white-space:nowrap}
.asmrone-action-sub{font-size:10px;color:var(--dsw-alias-label-secondary,#777b84);white-space:nowrap}

[data-shell-overlay]{z-index:1400!important}

/* ── 弹窗 ── */
.asmrone-backdrop{position:fixed;inset:0;z-index:100;display:grid;place-items:center;background:rgba(0,0,0,.35);animation:asmrone-fadein .15s ease-out;pointer-events:auto;touch-action:none}
.asmrone-dialog{width:min(94vw,720px);height:min(88vh,780px);display:flex;flex-direction:column;background:var(--dsw-specific-panel-fill,#f5f6f8);color:var(--dsw-alias-label-primary,#17181c);border-radius:20px;box-shadow:0 8px 32px rgba(0,0,0,.18);overflow:hidden;touch-action:auto;animation:asmrone-pop .2s cubic-bezier(.16,1,.3,1)}

.asmrone-header{display:flex;align-items:center;gap:10px;padding:16px 18px 10px;flex:none}
.asmrone-title{font-size:18px;font-weight:800;margin:0;min-width:0;flex:1;letter-spacing:-.3px;color:var(--dsw-alias-label-primary,#17181c)}
.asmrone-close{width:32px;height:32px;border-radius:10px;background:rgba(128,128,128,.08);border:0;display:flex;align-items:center;justify-content:center;color:var(--dsw-alias-label-secondary,#777b84);cursor:pointer;transition:background .12s ease;flex:none}
.asmrone-close:hover{background:rgba(128,128,128,.15)}
.asmrone-close:active{transform:scale(.92)}

/* ── 搜索行 ── */
.asmrone-search{display:flex;gap:7px;padding:0 18px 10px;flex:none}
.asmrone-input{flex:1;min-width:0;height:36px;padding:0 12px;border-radius:10px;border:1px solid var(--dsw-alias-border-l2,#e7e8ec);background:var(--dsw-alias-button-elevated-fill,#fff);color:inherit;font:inherit;font-size:13px;outline:none;transition:border-color .12s ease}
.asmrone-input:focus{border-color:#4f7cff}
.asmrone-btn{height:36px;padding:0 14px;border-radius:10px;border:1px solid var(--dsw-alias-border-l2,#e7e8ec);background:var(--dsw-alias-button-elevated-fill,#fff);color:inherit;font:inherit;font-size:12px;font-weight:600;cursor:pointer;white-space:nowrap;transition:all .12s ease}
.asmrone-btn:hover{border-color:#4f7cff}
.asmrone-btn:active{transform:scale(.96);opacity:.9}
.asmrone-btn[disabled]{opacity:.45;cursor:default;transform:none}
.asmrone-btn.primary{background:#4f7cff;border-color:#4f7cff;color:#fff}
.asmrone-btn.sm{height:28px;padding:0 10px;font-size:11px;border-radius:9px}
.asmrone-btn.on{background:#eef2ff;border-color:rgba(79,124,255,.4);color:#4f7cff}

/* ── 在线 / 本地 标签页 ── */
.asmrone-tabs{display:flex;gap:6px;padding:0 18px 10px;flex:none}
.asmrone-tab{border:0;background:rgba(128,128,128,.12);border-radius:10px;padding:7px 14px;font:inherit;font-size:12px;font-weight:600;color:#686c76;cursor:pointer;transition:all .12s ease}
.asmrone-tab:active{transform:scale(.96)}
.asmrone-tab-on{background:#4f7cff;color:#fff}
.asmrone-tab-badge{opacity:.75;font-variant-numeric:tabular-nums}
.asmrone-rootline{font-size:10.5px;color:#9ca0aa;padding:0 2px 6px;line-height:1.6;overflow-wrap:anywhere}

/* ── 筛选 chips ── */
.asmrone-chips{display:flex;gap:6px;padding:0 18px 10px;flex-wrap:wrap;flex:none;align-items:center}
.asmrone-chip{border:1px solid var(--dsw-alias-border-l2,#e7e8ec);background:var(--dsw-alias-button-elevated-fill,#fff);color:#686c76;font:inherit;font-size:11px;font-weight:600;padding:6px 12px;border-radius:999px;cursor:pointer;transition:all .12s ease}
.asmrone-chip:active{transform:scale(.96)}
.asmrone-chip-on{background:#4f7cff;border-color:#4f7cff;color:#fff}
.asmrone-select{height:30px;border:1px solid var(--dsw-alias-border-l2,#e7e8ec);background:var(--dsw-alias-button-elevated-fill,#fff);color:inherit;font:inherit;font-size:11.5px;padding:0 8px;border-radius:9px;outline:none}
.asmrone-select:focus{border-color:#4f7cff}

/* ── 权重面板 ── */
.asmrone-weights{padding:0 18px 12px;flex:none}
.asmrone-weightbox{display:flex;flex-direction:column;gap:9px;padding:12px;border:1px solid var(--dsw-alias-border-l2,#e7e8ec);border-radius:14px;background:var(--dsw-alias-button-elevated-fill,#fff)}
.asmrone-weightrow{display:grid;grid-template-columns:52px minmax(0,1fr) 34px;align-items:center;gap:9px}
.asmrone-weightlabel{font-size:11.5px;color:#686c76}
.asmrone-weightval{font-size:11px;font-variant-numeric:tabular-nums;color:#4f7cff;text-align:right;font-weight:700}
.asmrone-range{width:100%;height:22px;margin:0;accent-color:#4f7cff;background:transparent;cursor:pointer}
.asmrone-weighthint{font-size:10.5px;line-height:1.5;color:#9ca0aa}
.asmrone-weightfoot{display:flex;gap:6px;flex-wrap:wrap;align-items:center}

/* ── 主体 ── */
.asmrone-body{flex:1 1 auto;min-height:0;overflow-y:auto;-webkit-overflow-scrolling:touch;padding:0 14px 14px}
.asmrone-note{font-size:12px;padding:9px 11px;border-radius:10px;background:rgba(128,128,128,.12);line-height:1.7;word-break:break-word}
.asmrone-note.warn{color:#e05252;background:rgba(224,82,82,.08)}
.asmrone-sec{font-size:11px;font-weight:700;color:#686c76;letter-spacing:.02em;margin:10px 0 8px}
.asmrone-count{font-size:11px;color:#777b84;padding:0 2px 8px}
.asmrone-list{display:flex;flex-direction:column;gap:8px}

.asmrone-card{display:flex;align-items:flex-start;gap:10px;padding:11px 12px;border-radius:16px;background:var(--dsw-alias-button-elevated-fill,#fff);border:1px solid var(--dsw-alias-border-l2,#e7e8ec);box-shadow:0 2px 8px rgba(0,0,0,.03);cursor:pointer;transition:transform .12s ease,box-shadow .2s ease,border-color .2s ease;-webkit-tap-highlight-color:transparent;animation:asmrone-fadein .2s ease-out}
.asmrone-card:active{transform:scale(.99)}
.asmrone-card-open{border-color:rgba(79,124,255,.45);box-shadow:0 2px 12px rgba(79,124,255,.08)}
.asmrone-card.playing{border-color:#4f7cff;background:#f8faff}
/* 删除（不可逆）：多选态、危险按钮、确认条 */
.asmrone-card-picked{border-color:#4f7cff;background:#eef2ff}
.asmrone-check{flex:none;width:42px;height:42px;border-radius:12px;border:1.5px dashed #c8cdd8;display:flex;align-items:center;justify-content:center;color:#fff;font-size:16px;font-weight:700}
.asmrone-check.on{background:#4f7cff;border-color:#4f7cff;border-style:solid}
.asmrone-btn.danger{color:#e05252;border-color:rgba(224,82,82,.35)}
.asmrone-btn.danger:hover{border-color:#e05252;background:rgba(224,82,82,.06)}
.asmrone-deletebar{display:flex;gap:6px;align-items:center;flex-wrap:wrap;padding:0 0 10px}
.asmrone-confirm{margin:0 0 12px;padding:12px 13px;border-radius:14px;background:rgba(224,82,82,.06);border:1px solid rgba(224,82,82,.28)}
.asmrone-confirm-title{font-size:12.5px;font-weight:700;color:#e05252;margin-bottom:5px}
.asmrone-confirm-body{font-size:12px;line-height:1.6;word-break:break-word}
.asmrone-confirm-warn{font-size:11px;color:#9ca0aa;margin-top:5px}
.asmrone-confirm-actions{display:flex;gap:8px;justify-content:flex-end;margin-top:11px}
.asmrone-desc{font-size:11px;color:#9ca0aa;line-height:1.55;margin-top:3px;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}
.asmrone-cover{width:64px;height:64px;border-radius:12px;object-fit:cover;flex:none;background:rgba(128,128,128,.14)}
.asmrone-info{flex:1;min-width:0;display:flex;flex-direction:column;gap:3px}
.asmrone-name{font-size:13px;font-weight:700;line-height:1.4;color:var(--dsw-alias-label-primary,#17181c);display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;overflow-wrap:anywhere}
.asmrone-meta{font-size:10.5px;color:#777b84;line-height:1.5;overflow-wrap:anywhere}
.asmrone-tags{display:flex;flex-wrap:wrap;gap:4px;margin-top:2px}
.asmrone-tag{display:inline-block;padding:2px 7px;border-radius:7px;background:rgba(128,128,128,.14);font-size:10px;color:#686c76}
.asmrone-score{font-size:10px;font-weight:700;color:#4f7cff;background:rgba(79,124,255,.1);padding:2px 6px;border-radius:6px;white-space:nowrap;flex:none}

/* 音轨：内联在所属卡片正下方，跟卡片咬合 */
.asmrone-tracks{margin:-8px 0 6px;padding:10px 12px 12px;border:1px solid rgba(79,124,255,.45);border-top:none;border-radius:0 0 16px 16px;background:rgba(79,124,255,.05);animation:asmrone-fadein .16s ease-out}
.asmrone-track{display:flex;align-items:center;gap:8px;padding:5px 6px;border-radius:9px;font-size:12px}
.asmrone-track:hover{background:rgba(128,128,128,.1)}
.asmrone-track-on{background:rgba(79,124,255,.1)}
.asmrone-track-idx{opacity:.5;min-width:20px;font-variant-numeric:tabular-nums;font-size:11px}
.asmrone-track-name{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}

.asmrone-pager{display:flex;gap:10px;align-items:center;justify-content:center;margin-top:14px;flex-wrap:wrap}

/* ── 播放条（面板底栏 + 关掉面板后的悬浮迷你条是同一个组件）── */
.asmrone-player{flex:none;display:flex;flex-direction:column;gap:7px;padding:10px 18px 14px;border-top:1px solid var(--dsw-alias-border-l2,#e7e8ec);background:var(--dsw-specific-panel-fill,#f5f6f8)}
.asmrone-pline{display:flex;align-items:center;gap:9px}
.asmrone-pbtn{width:34px;height:34px;border-radius:50%;border:0;background:#4f7cff;color:#fff;display:flex;align-items:center;justify-content:center;cursor:pointer;flex:none;transition:transform .12s ease}
.asmrone-pbtn:active{transform:scale(.9)}
.asmrone-ptitle{flex:1;min-width:0;font-size:12px;font-weight:600;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.asmrone-ptime{font-size:10.5px;color:#777b84;font-variant-numeric:tabular-nums;white-space:nowrap;flex:none}
.asmrone-progress{width:100%;height:20px;margin:0;accent-color:#4f7cff;background:transparent;cursor:pointer}
.asmrone-prow{display:flex;align-items:center;gap:7px}
/* 底行那几个开关（循环 / 定时）：要和音量条、时钟并排站得下，
   所以比常规 .sm 再紧一档，并且不允许被 flex 压扁 —— 压扁就看不清「单曲」还是「整部」。 */
.asmrone-prow .asmrone-btn.sm{flex:none;height:24px;padding:0 7px;font-size:11px}
.asmrone-vol{width:64px;accent-color:#4f7cff;height:18px;margin:0;cursor:pointer;flex:none}

/* 悬浮球（缩回态）+ 展开条：面板关掉后仍在，切到对话页继续控制。
   缩回态做成可自由拖动的小球 —— 原来固定底部居中，正好压住输入框。 */
.asmrone-fab{position:fixed;z-index:1300;width:52px;height:52px;border-radius:50%;border:0;padding:3px;cursor:pointer;touch-action:none;-webkit-tap-highlight-color:transparent;display:grid;place-items:center;background:conic-gradient(#4f7cff var(--p,0%),rgba(79,124,255,.22) 0);box-shadow:0 6px 20px rgba(0,0,0,.22);transition:box-shadow .2s ease,transform .12s ease}
.asmrone-fab:active{transform:scale(.94)}
.asmrone-fab-drag{transition:none;box-shadow:0 10px 28px rgba(0,0,0,.3)}
.asmrone-fab-core{width:100%;height:100%;border-radius:50%;background:#4f7cff;color:#fff;display:grid;place-items:center}
.asmrone-fabbar{position:fixed;z-index:1300;display:flex;flex-direction:column;gap:6px;padding:10px 12px;border-radius:16px;background:var(--dsw-specific-panel-fill,#fff);border:1px solid var(--dsw-alias-border-l2,#e7e8ec);box-shadow:0 8px 28px rgba(0,0,0,.18);animation:asmrone-pop .16s cubic-bezier(.16,1,.3,1)}

.asmrone-empty{display:flex;flex-direction:column;align-items:center;justify-content:center;padding:36px 20px;color:#9ca0aa;font-size:13px;gap:8px;text-align:center}
.asmrone-loading{padding:28px;text-align:center;color:#9ca0aa;font-size:13px}

@media(prefers-color-scheme:dark){
.asmrone-dialog{background:#1e222a;color:#f2f4f8}
.asmrone-title{color:#f2f4f8}
.asmrone-close{background:rgba(255,255,255,.08);color:#9ca0aa}
.asmrone-close:hover{background:rgba(255,255,255,.14)}
.asmrone-input,.asmrone-btn{background:#262a33;border-color:#363c48;color:#d3d7e0}
.asmrone-chip{background:#262a33;border-color:#363c48;color:#8b91a0}
.asmrone-chip-on{background:#4f7cff;border-color:#4f7cff;color:#fff}
.asmrone-tab{background:#2e3340;color:#8b91a0}
.asmrone-tab-on{background:#4f7cff;color:#fff}
.asmrone-rootline{color:#6b7080}
.asmrone-select{background:#262a33;border-color:#363c48;color:#d3d7e0}
.asmrone-btn.on{background:rgba(79,124,255,.18);border-color:rgba(79,124,255,.4);color:#8ba4ff}
.asmrone-weightbox{background:#262a33;border-color:#363c48}
.asmrone-weightlabel{color:#8b91a0}
.asmrone-weighthint{color:#6b7080}
.asmrone-card{background:#262a33;border-color:#363c48}
.asmrone-card-open{border-color:rgba(79,124,255,.5)}
.asmrone-card.playing{background:rgba(79,124,255,.12)}
.asmrone-card-picked{background:rgba(79,124,255,.14);border-color:#4f7cff}
.asmrone-check{border-color:#4a515e}
.asmrone-btn.danger{color:#ff6b6b;border-color:rgba(255,107,107,.35)}
.asmrone-confirm{background:rgba(255,107,107,.08);border-color:rgba(255,107,107,.3)}
.asmrone-confirm-title{color:#ff6b6b}
.asmrone-name{color:#f2f4f8}
.asmrone-meta{color:#8b91a0}
.asmrone-tag{background:rgba(255,255,255,.08);color:#9ca0aa}
.asmrone-cover{background:rgba(255,255,255,.06)}
.asmrone-player{background:#1e222a;border-color:#363c48}
.asmrone-fabbar{background:#262a33;border-color:#363c48}
.asmrone-note{background:rgba(255,255,255,.07)}
.asmrone-note.warn{background:rgba(255,107,107,.1);color:#ff6b6b}
.asmrone-track:hover{background:rgba(255,255,255,.06)}
.asmrone-empty,.asmrone-loading{color:#6b7080}
}
`

    function injectStyle () {
      if (typeof document === 'undefined') return () => {}
      const existing = document.querySelector('style[data-plugin="' + NS + '"]')
      if (existing) {
        existing.textContent = CSS
        return () => existing.remove()
      }
      const tag = document.createElement('style')
      tag.setAttribute('data-plugin', NS)
      tag.textContent = CSS
      document.head.appendChild(tag)
      return () => tag.remove()
    }
    //#endregion

    //#region 状态
    let singleton = {
      open: false,
      query: '',
      order: 'dl_count',
      chinese: false,
      male: true,
      works: [],
      total: 0,
      page: 1,
      pageSize: 20,
      loading: false,
      error: '',
      idle: true,
      // 本地曲库：离线时的唯一活路。数据来自 host 扫盘，不碰网络。
      tab: 'online',
      localWorks: [],
      localTotals: { works: 0, files: 0, sizeText: '0 B' },
      localRoots: [],
      localScannedAt: 0,
      localLoading: false,
      localLoaded: false,
      localError: '',
      localQuery: '',
      activeLocal: null,
      // 删除（不可逆）：多选模式 + 面板内二次确认，不弹 window.confirm
      selectMode: false,
      selected: [],
      confirmDelete: null,
      deleting: false,
      deleteMsg: '',
      // DLsite 试听
      trialQuery: '',
      trialSex: true,
      trialResults: [],
      trialPage: 1,
      trialHasMore: false,
      trialSearched: false,
      trialSearching: false,
      trialKeyword: '',
      trialAsked: '',
      trialTranslated: false,
      trialActive: '',
      trialWork: null,
      trialLoading: false,
      trialOpening: false,
      trialSaving: false,
      trialError: '',
      trialNote: '',
      // 打开试听失败时留住的 RJ 与原因 —— 提示要贴在**出错的那一部**下面，
      // 不能飘在列表顶上（飘在顶上，用户看不出是谁出的问题）。
      trialFailRj: '',
      trialFailMsg: '',
      // 正在打开哪一部：转圈也要落在那一张卡片上，不然整页都在等的样子。
      trialOpeningRj: '',
      // 已知打不开的作品：`workno → 原因`。下次点它直接给答案，
      // 不再花一次十几秒的往返去重新发现同一件事（有些作品的试听包压根没有音频）。
      trialKnownBad: {},
      // B 站曲库（国内直连）
      biliQuery: '',
      biliOrder: 'totalrank',
      biliWorks: [],
      biliTotal: 0,
      biliPage: 1,
      biliLoading: false,
      biliLoaded: false,
      biliError: '',
      biliActive: null,
      biliPages: [],
      biliPagesLoading: false,
      // 权重排序
      weightsOpen: false,
      weights: Object.assign({}, DEFAULT_WEIGHTS),
      depth: 3,
      pool: [],
      poolPage: 1,
      // 音轨
      active: null,
      tracks: [],
      tracksLoading: false,
      // 播放器（常驻）
      playingHash: '',
      pendingSeq: 0,
      playingWorkId: '',
      playingTitle: '',
      playingCover: '',
      playingUrl: '',
      playing: false,
      currentTime: 0,
      duration: 0,
      scrubbing: false,
      volume: 1,
      // 循环与定时 —— 助眠场景的两个刚需：一首反复放、到点自己停。
      // 人睡着以后不会起来点暂停，所以「播完就静了」和「通宵放到没电」都得能避开。
      loopMode: 'off', // off | one | all
      playList: [], // 当前这批轨（同源）—— 循环到末尾时靠它找下一轨
      playIndex: -1,
      sleepMinutes: 0, // 定时关闭选的档位（0 = 没设）
      sleepEndAt: 0, // 截止时间戳
      sleepLeft: 0, // 剩余秒数，给按钮显示
      downloadMsg: '',
      downloading: false,
      // 悬浮播放器：缩回态是一枚可拖动的球，点击展开成控制条
      miniExpanded: false,
      miniPos: null,
      miniTouched: 0,
      config: null,
      note: ''
    }

    const listeners = new Set()
    function setState (patch) {
      singleton = Object.assign({}, singleton, patch)
      for (const listener of listeners) listener(singleton)
    }

    function useStore () {
      const [, force] = react.useReducer((n) => n + 1, 0)
      react.useEffect(() => {
        listeners.add(force)
        return () => { listeners.delete(force) }
      }, [])
      return singleton
    }

    /** 权重全 0 = 用官方排序，不走候选池也不重排。 */
    const smartActive = (state) => weightTotal(state.weights) > 0

    // 恢复上次拖的权重与候选池深度
    singleton.weights = sanitizeWeights(readPref(LS_WEIGHTS, DEFAULT_WEIGHTS))
    singleton.depth = clampNumber(readPref(LS_DEPTH, 3), 1, 5, 3)
    // 悬浮球位置：坏值当没存过，交给默认的右下角。
    singleton.miniPos = readPref(LS_FAB, null, (value) => {
      const left = Number(value?.left)
      const top = Number(value?.top)
      if (!Number.isFinite(left) || !Number.isFinite(top)) return null
      return { left, top }
    })
    //#endregion

    //#region 搜索
    async function runSearch (t, page) {
      const state = singleton
      const smart = smartActive(state)
      const pageSize = state.pageSize || 20

      setState({ loading: true, error: '', idle: false })

      try {
        if (!smart) {
          // 官方排序：一次一页，交给 host 翻。
          const target = Math.max(1, Number(page) || 1)
          const payload = await api.search({
            q: state.query,
            order: state.order,
            page: String(target),
            chinese: state.chinese ? '1' : '0',
            female: state.male ? '0' : '1'
          })
          const works = payload.works ?? []
          setState({
            loading: false,
            works,
            pool: works,
            poolPage: 1,
            page: payload.page ?? target,
            pageSize: payload.pageSize || pageSize,
            total: payload.total ?? 0
          })
          return
        }

        // 权重排序：并发抓 depth 页当候选池，归一化后重排。
        // 只抓 1 页就重排意义不大 —— 池子越小，min-max 归一化越容易被
        // 单条极端值带偏（一条 4.9 分就能把其余全压成 0.1）。
        const depth = clampNumber(state.depth, 1, 5, 3)
        const requests = []
        for (let index = 1; index <= depth; index += 1) {
          requests.push(api.search({
            q: state.query,
            order: state.order,
            page: String(index),
            chinese: state.chinese ? '1' : '0',
            female: state.male ? '0' : '1'
          }))
        }
        const settled = await Promise.allSettled(requests)
        const seen = new Set()
        const merged = []
        let total = 0
        let resolvedPageSize = pageSize
        let firstError = null

        for (const row of settled) {
          if (row.status !== 'fulfilled') {
            firstError = firstError ?? row.reason
            continue
          }
          const payload = row.value
          total = Math.max(total, Number(payload.total) || 0)
          resolvedPageSize = payload.pageSize || resolvedPageSize
          for (const work of payload.works ?? []) {
            const key = String(work?.id ?? '')
            if (key === '' || seen.has(key)) continue
            seen.add(key)
            merged.push(work)
          }
        }

        // 一条都没拿到才算失败；部分成功就用部分结果，别把整页丢掉。
        if (merged.length === 0 && firstError) throw firstError

        const ranked = rankWorks(merged, state.weights)
        setState({
          loading: false,
          pool: ranked,
          works: chunk(ranked, resolvedPageSize)[0],
          poolPage: 1,
          page: 1,
          pageSize: resolvedPageSize,
          total
        })
      } catch (error) {
        setState({ loading: false, error: error.message, works: [], pool: [] })
      }
    }

    /** 权重模式下的本地翻页：在候选池里切，不再打网络。 */
    function gotoPoolPage (t, page) {
      const state = singleton
      const pages = chunk(state.pool, state.pageSize || 20)
      const target = Math.min(Math.max(1, Number(page) || 1), pages.length)
      setState({ poolPage: target, works: pages[target - 1] ?? [], page: target })
      const body = document.querySelector('.' + NS + '-body')
      if (body && typeof body.scrollTo === 'function') body.scrollTo({ top: 0, behavior: 'smooth' })
    }

    async function openWork (t, work) {
      if (singleton.active && singleton.active.id === work.id) {
        setState({ active: null, tracks: [], note: '' })
        return
      }
      setState({ active: work, tracks: [], tracksLoading: true, note: '', downloadMsg: '' })
      // 展开区在卡片正下方；卡片若贴近屏幕底部，展开区会被切在视野外。
      setTimeout(() => {
        const node = document.querySelector('.' + NS + '-card-open')
        if (node && typeof node.scrollIntoView === 'function') {
          node.scrollIntoView({ block: 'start', behavior: 'smooth' })
        }
      }, 80)
      try {
        const payload = await api.work(work.id)
        setState({ tracks: payload.tracks, tracksLoading: false })
      } catch (error) {
        setState({ tracksLoading: false, note: t('err') + ': ' + error.message })
      }
    }

    async function doDownload (t, body) {
      setState({ downloading: true, downloadMsg: t('downloading') })
      try {
        const payload = await api.download(body)
        const lines = [payload.saved + '/' + payload.selected + ' → ' + payload.dir + '（' + payload.totalMb + ' MB）']
        for (const failure of payload.failures ?? []) lines.push(t('failed') + ': ' + failure.name + ' — ' + failure.error)
        setState({ downloading: false, downloadMsg: lines.join('\n') })
      } catch (error) {
        setState({ downloading: false, downloadMsg: t('failed') + ': ' + error.message })
      }
    }

    async function loadConfig (t) {
      try {
        const payload = await api.config()
        setState({ config: payload.config })
      } catch (error) {
        setState({ note: t('err') + ': ' + error.message })
      }
    }

    /**
     * 拉本地曲库。走 host 扫盘，不碰网络 —— 没代理时这是唯一能用的数据源。
     * @param {*} t
     * @param {{ force?: boolean }} [options] force 会绕过 host 侧 60 秒缓存，直接重扫磁盘
     */
    async function loadLocal (t, { force = false } = {}) {
      setState({ localLoading: true, localError: '' })
      try {
        const payload = await api.local({
          q: singleton.localQuery,
          force: force ? '1' : '0'
        })
        setState({
          localLoading: false,
          localLoaded: true,
          localWorks: payload.works ?? [],
          localTotals: payload.totals ?? { works: 0, files: 0, sizeText: '0 B' },
          localRoots: payload.roots ?? [],
          localScannedAt: payload.scannedAt ?? 0
        })
      } catch (error) {
        setState({ localLoading: false, localError: error.message, localWorks: [] })
      }
    }

    /* ── B 站曲库 ──
     * 唯一不用代理的在线源。播放**不是「先下载再播」**：直接把稳定流地址喂给常驻
     * 播放器，字节由 host 转发 B 站 CDN —— 手机不落盘，这才是「线上缓存」的本意。 */
    async function runBiliSearch (t, page) {
      const target = Math.max(1, Number(page) || 1)
      setState({ biliLoading: true, biliError: '' })
      try {
        const payload = await api.biliSearch({
          q: singleton.biliQuery,
          page: target,
          order: singleton.biliOrder
        })
        setState({
          biliLoading: false,
          biliLoaded: true,
          biliWorks: payload.videos ?? [],
          biliTotal: payload.total ?? 0,
          biliPage: payload.page ?? target,
          biliActive: null,
          biliPages: []
        })
      } catch (error) {
        setState({ biliLoading: false, biliLoaded: true, biliError: error.message, biliWorks: [] })
      }
    }

    /** 展开一个稿件：分 P 列表要单独拉，因为 cid 每段都不一样。 */
    async function openBiliWork (t, work) {
      if (singleton.biliActive && singleton.biliActive.bvid === work.bvid) {
        setState({ biliActive: null, biliPages: [] })
        return
      }
      setState({ biliActive: work, biliPages: [], biliPagesLoading: true })
      setTimeout(() => {
        const node = document.querySelector('.' + NS + '-card-open')
        if (node && typeof node.scrollIntoView === 'function') {
          node.scrollIntoView({ block: 'start', behavior: 'smooth' })
        }
      }, 80)
      try {
        const payload = await api.biliWork(work.bvid)
        setState({ biliPagesLoading: false, biliPages: payload.work?.pages ?? [] })
      } catch (error) {
        setState({ biliPagesLoading: false, biliError: t('err') + ': ' + error.message })
      }
    }

    /**
     * 删除已下载的内容。`targets` 形如 `[{ key, indexes }]`，`indexes` 空 = 整部删。
     *
     * 删完强制重扫本地库：host 侧缓存虽然会作废，前端这份列表也得立刻换掉，
     * 否则刚删掉的东西还挂在面板上，看起来像没删成功。
     */
    async function doDelete (t, targets) {
      if (!Array.isArray(targets) || targets.length === 0) {
        setState({ deleteMsg: t('delNothing'), confirmDelete: null })
        return
      }
      setState({ deleting: true, deleteMsg: t('delDeleting'), confirmDelete: null })
      try {
        const payload = await api.localDelete({ targets })
        const totals = payload.totals ?? { files: 0, works: 0, sizeText: '0 B' }
        const rows = payload.results ?? []
        const lines = [t('delDone') + ' ' + totals.files + ' 个文件 / 释放 ' + totals.sizeText]
        for (const row of rows.filter((item) => item.status === 'failed' || item.status === 'partial')) {
          lines.push(t('failed') + '：' + row.name + ' — ' + row.error)
        }

        const patch = {
          deleting: false,
          deleteMsg: lines.join('\n'),
          selected: [],
          selectMode: false
        }

        // 正在放的那首被删了：audio 还攥着已经不存在文件的 src，表现为「卡住不动」。
        // 直接停掉并清空播放条，比留一个放不动的残影干净。
        const touched = new Set(rows.filter((row) => row.removed > 0).map((row) => row.key))
        const playingWorkId = String(singleton.playingWorkId)
        if (playingWorkId.startsWith('local:') && touched.has(playingWorkId.slice(6))) {
          const audio = ensureAudio()
          if (audio) {
            try { audio.pause() } catch { /* 已停 */ }
            audio.removeAttribute('src')
          }
          Object.assign(patch, { playingUrl: '', playingHash: '', playing: false, currentTime: 0, duration: 0 })
        }

        setState(patch)
        await loadLocal(t, { force: true })
      } catch (error) {
        setState({ deleting: false, deleteMsg: t('failed') + ': ' + error.message })
      }
    }
    /* ── DLsite 试听 ──
     * 手机端只给「在线听」，下载要切电脑模式 —— 这两个动作在这里都补齐了。
     * 在线听的内容常驻 host 内存，前端只拿一个切片地址；下载复用同一份数据，
     * 所以「先试听、满意再存」不会把 zip 重下一遍。 */
    /**
     * 搜 DLsite 作品。
     *
     * 输入框里如果本来就是一个作品标识（RJ 号 / 整条链接 / 分享文本），就直接打开它的
     * 试听包，不再去搜一遍 —— 从手机浏览器复制过来的多是这种，别让人白等一次搜索。
     */
    async function runTrialSearch (t, page) {
      const query = String(singleton.trialQuery ?? '').trim()
      if (query === '') {
        setState({ trialError: t('trialNeedRj') })
        return
      }
      if (/RJ\s*\d{3,}/i.test(query) || /dlsite\.com/i.test(query)) {
        return openTrialByRef(t, query)
      }

      const target = Math.max(1, Number(page) || 1)
      setState({ trialSearching: true, trialError: '', trialNote: '', trialResults: [], trialActive: '', trialFailRj: '', trialFailMsg: '', trialOpeningRj: '' })
      try {
        const payload = await api.trialSearch({
          q: query,
          page: target,
          sex: singleton.trialSex ? 'male' : ''
        })
        setState({
          trialSearching: false,
          trialSearched: true,
          trialResults: payload.works ?? [],
          trialPage: payload.page ?? target,
          trialHasMore: payload.hasMore === true,
          trialKeyword: payload.keyword ?? query,
          trialAsked: payload.asked ?? query,
          trialTranslated: payload.translated === true
        })
      } catch (error) {
        setState({
          trialSearching: false,
          trialSearched: true,
          trialResults: [],
          trialError: describeTrialError(t, error)
        })
      }
    }

    /** 打开某部作品的试听包。搜索结果的「试听」、本地库卡片、粘贴的引用都走这里。 */
    async function openTrialByRef (t, ref) {
      const query = String(ref ?? '').trim()
      if (query === '') return

      // 已经知道这一部打不开（试听包里没有音频、超过上限）—— 直接给答案。
      // 这类作品的失败是**恒定**的，重新问一遍要等十几秒才拿到同一句话：
      // 慢速网络下取一次作品页要 10 秒上下，用户点三次就白等半分钟。
      const known = (singleton.trialKnownBad ?? {})[query]
      if (known !== undefined) {
        setState({
          trialOpening: false,
          trialOpeningRj: '',
          trialError: '',
          trialActive: '',
          trialWork: null,
          trialFailRj: query,
          trialFailMsg: known
        })
        return
      }

      setState({
        trialOpening: true,
        trialOpeningRj: query,
        trialError: '',
        trialFailRj: '',
        trialFailMsg: '',
        trialNote: '',
        trialActive: '',
        trialWork: null
      })
      try {
        const payload = await api.trialOpen({ rj: query })
        setState({
          trialOpening: false,
          trialOpeningRj: '',
          trialWork: payload.work,
          trialActive: payload.work.workno,
          trialNote: '',
          trialFailRj: '',
          trialFailMsg: ''
        })
      } catch (error) {
        // 失败记在**这一部**上，而不是写进 trialError。
        // trialError 是飘在列表顶端的那条，用户对着它看不出是哪一部出的问题；
        // 渲染时会把 trialFailRj 对应的卡片找出来，把原因和「下载到本地」贴到它下面。
        // 找不到对应卡片（粘贴的 RJ、从别的标签页跳过来）才回退到顶端显示。
        const message = describeTrialError(t, error)
        // 只有「本地就说得清」的失败才记进已知坏名单；链路层失败不记 ——
        // 那种等网络好了就能用，记下来会让用户以为这一部永久听不了。
        const cacheable = !TRIAL_LINK_RE.test(String(error?.message ?? ''))
        setState({
          trialOpening: false,
          trialOpeningRj: '',
          trialFailRj: query,
          trialFailMsg: message,
          trialNote: '',
          trialKnownBad: cacheable
            ? Object.assign({}, singleton.trialKnownBad, { [query]: message })
            : singleton.trialKnownBad
        })
      }
    }

    /** 链路层失败的指纹 —— 只有命中这些才说明「代理没开 / 网络不通」。 */
    const TRIAL_LINK_RE = /超时|timeout|fetch failed|ECONN|ENOTFOUND|EAI_AGAIN|socket|abort|网络|连接/i

    /**
     * 「插件没重启」和「DLsite 不通」要分开说 —— 这两件事让用户做的事完全不同：
     * 前者去 App 里重启，后者去开代理。合成一句会让两边都白折腾。
     *
     * 而且**不能让「被墙」当成万能解释**：试听包超过体积上限、这部没有官方试听，
     * 都是本地就能说清的原因。以前它们也显示成「DLsite 是被墙的」，
     * 用户开着梯子看到「你没开梯子」，只剩困惑。
     */
    function describeTrialError (t, error) {
      const message = String(error?.message ?? error ?? '').trim()
      if (/未知路径|not-found/.test(message)) {
        return t('needRestart') + '（' + message + '）'
      }
      if (TRIAL_LINK_RE.test(message)) {
        return t('trialBlocked') + '（' + message + '）'
      }
      return message === '' ? t('trialBlocked') : message
    }

    /** 已经展开的那一项再点一次就收起来（跟其它标签页的展开行为一致）。 */
    function toggleTrial (t, work) {
      if (singleton.trialActive === work.workno) {
        setState({ trialActive: '', trialWork: null, trialError: '', trialNote: '', trialFailRj: '', trialFailMsg: '', trialOpeningRj: '' })
        return
      }
      openTrialByRef(t, work.workno)
    }

    function playTrial (track) {
      const work = singleton.trialWork
      if (!work) return
      const hash = 'trial:' + work.workno + ':' + track.index
      setState({
        playingHash: hash,
        playingWorkId: 'trial:' + work.workno,
        playingTitle: work.title + ' · ' + track.name,
        playingCover: '',
        playingUrl: api.trialStreamUrl(work.workno, track.index),
        playing: true,
        currentTime: 0,
        duration: 0,
        note: '',
        ...playlistOf(work.tracks, (item) => ({
          hash: 'trial:' + work.workno + ':' + item.index,
          workId: 'trial:' + work.workno,
          title: work.title + ' · ' + item.name,
          url: api.trialStreamUrl(work.workno, item.index),
          cover: ''
        }), hash)
      })
    }

    async function saveTrial (t, worknoArg) {
      // 常规入口用已经打开的试听包；worknoArg 是「打开失败后直接下载」那条岔路 ——
      // 下载走的是另一套体积上限（配置里的 maxWorkMb，默认 800），比在线听宽松得多。
      const workno = String(worknoArg ?? singleton.trialWork?.workno ?? '').trim()
      if (workno === '') {
        setState({ trialError: t('trialNeedRj') })
        return
      }
      setState({ trialSaving: true, trialError: '', trialNote: t('trialSaving') })
      try {
        const payload = await api.trialSave({ rj: workno })
        const lines = [t('trialSaved') + '：' + payload.saved + '/' + payload.total + ' → ' + payload.dir]
        for (const failure of payload.failures || []) lines.push(t('failed') + '：' + failure.name + ' — ' + failure.error)
        setState({ trialSaving: false, trialNote: lines.join('\n') })
        // 存完立刻让本地曲库那份也刷新，不然要等 60 秒缓存过期才看得见。
        loadLocal(t, { force: true })
      } catch (error) {
        setState({ trialSaving: false, trialError: error.message, trialNote: '' })
      }
    }

    async function releaseTrial (t) {
      const work = singleton.trialWork
      try {
        await api.trialClose(work ? { rj: work.workno } : {})
      } catch { /* 释放失败无所谓，进程重启一样会清 */ }
      setState({ trialWork: null, trialNote: '', trialFailRj: '', trialFailMsg: '', trialOpeningRj: '' })
    }
    //#endregion

    //#region 图标（纯 SVG，不用 emoji）
    const svg = (props, ...children) => h('svg', Object.assign({
      viewBox: '0 0 24 24', fill: 'none', stroke: 'currentColor',
      strokeWidth: props.weight ?? 1.8, strokeLinecap: 'round', strokeLinejoin: 'round',
      width: props.size ?? '1em', height: props.size ?? '1em', 'aria-hidden': 'true'
    }, props.extra), children)

    const IconHeadphones = (props) => svg({ size: (props && props.size) ?? 20 },
      h('path', { key: 'a', d: 'M4 14v-2a8 8 0 0 1 16 0v2' }),
      h('path', { key: 'b', d: 'M4 14h2a1 1 0 0 1 1 1v4a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1v-5Z' }),
      h('path', { key: 'c', d: 'M20 14h-2a1 1 0 0 0-1 1v4a1 1 0 0 0 1 1h1a1 1 0 0 0 1-1v-5Z' }))

    const IconClose = () => svg({ size: 12, weight: 2.2 },
      h('path', { key: 'x', d: 'M18 6 6 18M6 6l12 12' }))

    const IconPlay = () => h('svg', { viewBox: '0 0 24 24', width: 15, height: 15, fill: 'currentColor', 'aria-hidden': 'true' },
      h('path', { d: 'M8 5.14v13.72L19 12 8 5.14Z' }))

    const IconPause = () => h('svg', { viewBox: '0 0 24 24', width: 15, height: 15, fill: 'currentColor', 'aria-hidden': 'true' },
      h('path', { d: 'M7 5h3.5v14H7zM13.5 5H17v14h-3.5z' }))

    const IconSliders = () => svg({ size: 14, weight: 2 },
      h('path', { key: 'a', d: 'M4 6h10M18 6h2M4 12h4M12 12h8M4 18h12M20 18h0' }),
      h('circle', { key: 'b', cx: 16, cy: 6, r: 2 }),
      h('circle', { key: 'c', cx: 10, cy: 12, r: 2 }),
      h('circle', { key: 'd', cx: 18, cy: 18, r: 2 }))

    const IconDownload = () => svg({ size: 13, weight: 2 },
      h('path', { key: 'a', d: 'M12 3v12M7 11l5 5 5-5M5 21h14' }))

    const IconChevron = (props) => h('svg', {
      viewBox: '0 0 24 24', width: 12, height: 12, fill: 'none', stroke: 'currentColor',
      strokeWidth: 2.4, strokeLinecap: 'round', strokeLinejoin: 'round', 'aria-hidden': 'true',
      style: { transition: 'transform .2s ease', transform: (props && props.open) ? 'rotate(180deg)' : 'none' }
    }, h('path', { d: 'm6 9 6 6 6-6' }))
    //#endregion

    //#region 侧边栏入口
    function SidebarAction (props) {
      const t = makeT(props && props.t)
      return h('div', { className: 'asmrone-action-wrap' },
        h('button', {
          type: 'button',
          className: 'asmrone-action',
          title: t('title'),
          'aria-label': t('openPanel'),
          onClick: () => setState({ open: true })
        },
        h('span', { className: 'asmrone-action-content' },
          h('span', { className: 'asmrone-action-logo', style: { display: 'flex', alignItems: 'center', justifyContent: 'center', background: '#eef2ff', color: '#4f7cff' } }, IconHeadphones({ size: 14 })),
          h('span', { className: 'asmrone-action-text' },
            h('span', { className: 'asmrone-action-title' }, t('title')),
            h('span', { className: 'asmrone-action-sub' }, smartActive(singleton) ? t('weightsOn') : t('orderSales'))
          )
        ))
      )
    }
    //#endregion

    /* ==================================================================== *
     * 页面级 audio（不在 React 树里）
     *
     * `<audio>` 曾经是 Overlay 的一个 React 子节点 —— 那样只要挂载它的容器被
     * 卸载重建（切页、shell 重挂），元素就没了，音乐跟着断。挂在 document.body
     * 上就与 React 生命周期脱钩：容器怎么重建，声音都不受影响；组件重挂时再把
     * 上一次的 src 接回来即可。
     *
     * 用 1px + opacity:0 藏，不用 display:none —— 后者在部分 WebView 上直接停播。
     * ==================================================================== */
    let globalAudio = null

    function ensureAudio () {
      if (typeof document === 'undefined') return null
      if (globalAudio && globalAudio.isConnected) return globalAudio
      const audio = document.createElement('audio')
      audio.preload = 'auto'
      audio.setAttribute('playsinline', '')
      audio.setAttribute('data-plugin', NS)
      Object.assign(audio.style, {
        position: 'fixed', left: '0', bottom: '0', width: '1px', height: '1px',
        opacity: '0', pointerEvents: 'none'
      })
      document.body.appendChild(audio)
      globalAudio = audio
      return audio
    }

    /* ── 循环与定时 ──
     * 助眠场景的两个刚需：一首反复放、到点自己停。人睡着以后没人会来点暂停，
     * 所以「播完就静了」和「通宵放着耗光电」都得能避开。 */

    /** 循环三态。单轨与整部互斥，合成一个布尔分不清用户想要哪个。 */
    const LOOP_MODES = ['off', 'one', 'all']

    /** 定时关闭的档位（分钟），0 是关。 */
    const SLEEP_STEPS = [0, 15, 30, 60, 90]

    function cycleLoop () {
      const at = LOOP_MODES.indexOf(singleton.loopMode)
      setState({ loopMode: LOOP_MODES[(at < 0 ? 0 : at + 1) % LOOP_MODES.length] })
    }

    function cycleSleep () {
      const at = SLEEP_STEPS.indexOf(Number(singleton.sleepMinutes))
      const next = SLEEP_STEPS[(at < 0 ? 0 : at + 1) % SLEEP_STEPS.length]
      setState({
        sleepMinutes: next,
        sleepEndAt: next === 0 ? 0 : Date.now() + next * 60000,
        sleepLeft: next * 60
      })
    }

    /**
     * 把一批轨转成循环用的列表，并算出当前播的是第几项。
     *
     * 四个播放点各自知道自己的轨从哪来（在线音轨 / B 站分 P / 本地文件 / 试听轨），
     * 但循环逻辑只该认「一个数组 + 一个下标」—— 在这里统一成型，
     * 省得把四种来源的分支一路铺到 playNextInList 里。
     */
    function playlistOf (tracks, toEntry, currentHash) {
      const list = (Array.isArray(tracks) ? tracks : []).map(toEntry)
      const index = list.findIndex((entry) => entry.hash === currentHash)
      return { playList: list, playIndex: index < 0 ? 0 : index }
    }

    /**
     * 播列表里的下一轨，`loopMode === 'all'` 时走到末尾绕回开头。
     *
     * 列表是「本次播放上下文里的同源轨」：在线曲库那部作品的音轨、B 站某个稿件的
     * 分 P、本地某部作品的文件、或 DLsite 那个试听包。跨来源接续没有意义 ——
     * 只在同一批里循环。
     *
     * @returns {boolean} 有没有真的换曲
     */
    function playNextInList () {
      const list = singleton.playList
      if (!Array.isArray(list) || list.length === 0) return false
      const next = (Number(singleton.playIndex) + 1) % list.length
      const entry = list[next]
      if (!entry) return false
      setState({
        playingHash: entry.hash,
        playingWorkId: entry.workId ?? singleton.playingWorkId,
        playingTitle: entry.title ?? singleton.playingTitle,
        playingCover: entry.cover ?? singleton.playingCover,
        playingUrl: entry.url,
        playing: true,
        playIndex: next,
        currentTime: 0,
        duration: 0,
        scrubbing: false,
        note: ''
      })
      return true
    }

    /* ==================================================================== *
     * Player —— 面板底栏与悬浮迷你条共用。
     *
     * `mini` 为 true 时不显示音量与下载，只留标题/进度/播放键 —— 悬浮条要小。
     * 进度条用受控 range：拖动期间锁 `scrubbing`，不让 timeupdate 把滑块拽回去。
     * ==================================================================== */
    function Player (props) {
      const t = props.t
      const state = props.state
      const audioRef = props.audioRef
      const clock = formatClock(state.currentTime) + ' / ' + formatClock(state.duration)

      const toggle = () => {
        const audio = audioRef.current
        if (!audio) return
        if (audio.paused) {
          const promise = audio.play()
          if (promise && typeof promise.catch === 'function') {
            promise.catch(() => setState({ note: '播放被浏览器拦下了：再点一次播放键。' }))
          }
        } else {
          audio.pause()
        }
      }

      // 彻底停：清 src 并 load()，让 audio 释放连接，而不是只 pause
      // （pause 留着缓冲，长时间挂着白占内存和解码器）。
      const stopPlayback = () => {
        const audio = audioRef.current
        if (audio) {
          try { audio.pause() } catch { /* 忽略 */ }
          try { audio.removeAttribute('src'); audio.load() } catch { /* 忽略 */ }
        }
        setState({
          playingUrl: '', playingHash: '', playingWorkId: '', playingTitle: '',
          playingCover: '', playing: false, currentTime: 0, duration: 0,
          // 停播就把循环上下文一起丢掉 —— 留着它，「整部循环」会在下次起播时
          // 拿一份已经过期的轨列表去续播。
          playList: [], playIndex: -1
        })
      }

      const onScrub = (event) => {
        // 必须置 scrubbing：进度轮询要看它来决定「别覆盖用户正在拖的值」，
        // 漏了这一步滑块会被 200ms 的轮询一直拽回去。
        const value = Number(event.target.value)
        setState({ scrubbing: true, currentTime: value })
      }
      const commitScrub = (event) => {
        const value = Number(event.target.value)
        const audio = audioRef.current
        if (audio && Number.isFinite(value)) {
          try { audio.currentTime = value } catch { /* 元数据未就绪时忽略 */ }
        }
        setState({ scrubbing: false, currentTime: value })
      }

      const body = h(react.Fragment, null,
        h('div', { className: 'asmrone-pline' },
          h('button', {
            type: 'button',
            className: 'asmrone-pbtn',
            onClick: toggle,
            'aria-label': state.playing ? t('pause') : t('resume'),
            title: state.playing ? t('pause') : t('resume')
          }, state.playing ? IconPause() : IconPlay()),
          h('span', { className: 'asmrone-ptitle', title: state.playingTitle }, t('nowPlaying') + ' · ' + state.playingTitle),
          h('span', { className: 'asmrone-ptime' }, clock)
        ),
        h('input', {
          type: 'range',
          className: 'asmrone-progress',
          min: 0,
          max: Math.max(1, Math.round(state.duration) || 1),
          step: 1,
          value: Math.min(Math.round(state.currentTime) || 0, Math.max(1, Math.round(state.duration) || 1)),
          onChange: onScrub,
          onPointerUp: commitScrub,
          onMouseUp: commitScrub,
          onTouchEnd: commitScrub,
          onKeyUp: commitScrub,
          'aria-label': '进度'
        }),
        h('div', { className: 'asmrone-prow' },
          h('span', { className: 'asmrone-ptime' }, '音量'),
          h('input', {
            type: 'range',
            className: 'asmrone-vol',
            min: 0,
            max: 1,
            step: 0.05,
            value: state.volume,
            onChange: (event) => {
              const value = Number(event.target.value)
              const audio = audioRef.current
              if (audio) audio.volume = value
              setState({ volume: value })
            },
            'aria-label': '音量'
          }),
          h('button', {
            type: 'button',
            className: 'asmrone-btn sm' + (state.loopMode === 'off' ? '' : ' primary'),
            onClick: cycleLoop,
            title: t('loopHint'),
            'aria-label': t('loopHint')
          }, t({ off: 'loopOff', one: 'loopOne', all: 'loopAll' }[state.loopMode] ?? 'loopOff')),
          h('button', {
            type: 'button',
            className: 'asmrone-btn sm' + (state.sleepEndAt ? ' primary' : ''),
            onClick: cycleSleep,
            title: t('sleepHint'),
            'aria-label': t('sleepHint')
          }, state.sleepEndAt
            ? t('sleepLeft').replace('{m}', String(Math.max(1, Math.ceil(state.sleepLeft / 60))))
            : t('sleepOff')),
          h('span', { className: 'asmrone-ptime', style: { marginLeft: 'auto' } },
            state.playingHash ? state.playingHash.split('/').pop() : '')
        )
      )

      return h('div', { className: 'asmrone-player' }, body)
    }

    /* ==================================================================== *
     * FloatingPlayer —— 面板关掉后留在屏幕上的那个。
     *
     * 缩回态是一枚**可自由拖动**的球：原来固定底部居中，正好压住输入框。
     * 点击球展开成完整控制条，2.8 秒没有交互自动缩回；拖到哪儿存 localStorage，
     * 下次还在那儿。
     *
     * 拖动期间位置只写组件内 state，松手才落到全局 store —— 60Hz 地刷全局会让
     * 整个面板跟着重渲染。
     * ==================================================================== */
    const FAB_SIZE = 52

    function clampFabPos (pos, size) {
      const edge = size ?? FAB_SIZE
      if (typeof window === 'undefined') return { left: Math.round(pos.left), top: Math.round(pos.top) }
      const maxLeft = Math.max(8, window.innerWidth - edge - 8)
      const maxTop = Math.max(8, window.innerHeight - edge - 8)
      return {
        left: Math.min(Math.max(8, Math.round(pos.left)), maxLeft),
        top: Math.min(Math.max(8, Math.round(pos.top)), maxTop)
      }
    }

    function defaultFabPos () {
      if (typeof window === 'undefined') return { left: 12, top: 12 }
      // 右下角，抬高到输入框上方 —— 既不压输入框，也不压发送键。
      return clampFabPos({
        left: window.innerWidth - FAB_SIZE - 14,
        top: window.innerHeight - FAB_SIZE - 150
      })
    }

    function FloatingPlayer (props) {
      const t = props.t
      const state = props.state
      const audioRef = props.audioRef
      const dragRef = react.useRef(null)
      const dragPosRef = react.useRef(null)
      const [localPos, setLocalPos] = react.useState(null)
      const [dragging, setDragging] = react.useState(false)

      const pos = localPos || state.miniPos || defaultFabPos()
      const percent = state.duration > 0 ? Math.min(100, (state.currentTime / state.duration) * 100) : 0

      // 展开后安静 2.8 秒自动缩回。依赖里**不能**放 currentTime —— 它每 200ms
      // 变一次，会让计时器永远重置、永远缩不回去。用 miniTouched 当「用户刚动过」的信号。
      react.useEffect(() => {
        if (!state.miniExpanded) return undefined
        if (state.scrubbing) return undefined
        const timer = setTimeout(() => setState({ miniExpanded: false }), 2800)
        return () => clearTimeout(timer)
      }, [state.miniExpanded, state.scrubbing, state.miniTouched])

      const touch = () => setState({ miniTouched: singleton.miniTouched + 1 })

      const togglePlay = () => {
        const audio = audioRef.current
        if (!audio) return
        touch()
        if (audio.paused) {
          const promise = audio.play()
          if (promise && typeof promise.catch === 'function') {
            promise.catch(() => setState({ note: '播放被浏览器拦下了：再点一次播放键。' }))
          }
        } else {
          audio.pause()
        }
      }

      const stopPlayback = () => {
        const audio = audioRef.current
        if (audio) {
          try { audio.pause() } catch { /* 忽略 */ }
          try { audio.removeAttribute('src'); audio.load() } catch { /* 忽略 */ }
        }
        setState({
          playingUrl: '', playingHash: '', playingWorkId: '', playingTitle: '',
          playingCover: '', playing: false, currentTime: 0, duration: 0, miniExpanded: false,
          playList: [], playIndex: -1
        })
      }

      const onPointerDown = (event) => {
        const rect = event.currentTarget.getBoundingClientRect()
        dragRef.current = {
          startX: event.clientX,
          startY: event.clientY,
          originLeft: rect.left,
          originTop: rect.top,
          moved: false
        }
        try { event.currentTarget.setPointerCapture(event.pointerId) } catch { /* 忽略 */ }
      }

      const onPointerMove = (event) => {
        const drag = dragRef.current
        if (!drag) return
        const dx = event.clientX - drag.startX
        const dy = event.clientY - drag.startY
        // 6px 以内算点击，不算拖动 —— 手指按下去总会有几像素抖动。
        if (!drag.moved && Math.abs(dx) < 6 && Math.abs(dy) < 6) return
        drag.moved = true
        setDragging(true)
        const next = clampFabPos({ left: drag.originLeft + dx, top: drag.originTop + dy })
        dragPosRef.current = next
        setLocalPos(next)
      }

      const onPointerUp = () => {
        const drag = dragRef.current
        dragRef.current = null
        if (!drag) return
        setDragging(false)

        if (drag.moved) {
          const next = dragPosRef.current
          dragPosRef.current = null
          setLocalPos(null)
          if (next) {
            writePref(LS_FAB, next)
            setState({ miniPos: next })
          }
          return
        }
        // 没拖动 = 点击：展开 / 缩回
        setState({ miniExpanded: !singleton.miniExpanded, miniTouched: singleton.miniTouched + 1 })
      }

      if (!state.playingUrl) return null

      if (!state.miniExpanded) {
        return h('button', {
          type: 'button',
          className: 'asmrone-fab' + (dragging ? ' asmrone-fab-drag' : ''),
          style: { left: pos.left + 'px', top: pos.top + 'px', '--p': percent + '%' },
          title: state.playingTitle,
          'aria-label': t('nowPlaying') + ' ' + state.playingTitle,
          onPointerDown,
          onPointerMove,
          onPointerUp,
          onPointerCancel: onPointerUp,
          onContextMenu: (event) => event.preventDefault()
        }, h('span', { className: 'asmrone-fab-core' }, state.playing ? IconPause() : IconPlay()))
      }

      // 展开条贴着球展开：球在右半屏就右对齐球，否则左对齐，两边都不出屏。
      const viewWidth = typeof window === 'undefined' ? 360 : window.innerWidth
      const viewHeight = typeof window === 'undefined' ? 640 : window.innerHeight
      const barWidth = Math.min(viewWidth * 0.92, 340)
      const anchoredRight = pos.left + FAB_SIZE / 2 > viewWidth / 2
      const barLeft = Math.min(
        Math.max(8, anchoredRight ? pos.left + FAB_SIZE - barWidth : pos.left),
        Math.max(8, viewWidth - barWidth - 8)
      )
      const barTop = Math.min(Math.max(8, pos.top), Math.max(8, viewHeight - 130))

      return h('div', {
        className: 'asmrone-fabbar',
        style: { left: barLeft + 'px', top: barTop + 'px', width: barWidth + 'px' },
        onPointerDown: touch
      },
      h('div', { className: 'asmrone-pline' },
        h('button', {
          type: 'button',
          className: 'asmrone-pbtn',
          onClick: togglePlay,
          'aria-label': state.playing ? t('pause') : t('resume')
        }, state.playing ? IconPause() : IconPlay()),
        h('span', { className: 'asmrone-ptitle', title: state.playingTitle }, state.playingTitle),
        h('button', {
          type: 'button',
          className: 'asmrone-close',
          style: { width: 26, height: 26, flex: 'none' },
          onClick: () => { touch(); setState({ miniExpanded: false }) },
          title: t('more'),
          'aria-label': t('more')
        }, IconChevron({ open: true })),
        h('button', {
          type: 'button',
          className: 'asmrone-close',
          style: { width: 26, height: 26, flex: 'none' },
          onClick: stopPlayback,
          title: t('close'),
          'aria-label': t('close')
        }, IconClose())
      ),
      h('input', {
        type: 'range',
        className: 'asmrone-progress',
        min: 0,
        max: Math.max(1, Math.round(state.duration) || 1),
        step: 1,
        value: Math.min(Math.round(state.currentTime) || 0, Math.max(1, Math.round(state.duration) || 1)),
        onChange: (event) => {
          touch()
          setState({ scrubbing: true, currentTime: Number(event.target.value) })
        },
        onPointerUp: (event) => {
          const value = Number(event.target.value)
          const audio = audioRef.current
          if (audio && Number.isFinite(value)) {
            try { audio.currentTime = value } catch { /* 元数据还没到 */ }
          }
          touch()
          setState({ scrubbing: false, currentTime: value })
        },
        'aria-label': '进度'
      }),
      h('div', { className: 'asmrone-prow', style: { justifyContent: 'space-between' } },
        h('span', { className: 'asmrone-ptime' },
          formatClock(state.currentTime) + ' / ' + formatClock(state.duration)),
        // 循环与定时在悬浮条上也给一份 —— 助眠时面板多半是关着的，
        // 只把这两个开关留在面板里，等于睡前还得先开一次面板。
        h('button', {
          type: 'button',
          className: 'asmrone-btn sm' + (state.loopMode === 'off' ? '' : ' primary'),
          onClick: cycleLoop,
          title: t('loopHint'),
          'aria-label': t('loopHint')
        }, t({ off: 'loopOff', one: 'loopOne', all: 'loopAll' }[state.loopMode] ?? 'loopOff')),
        h('button', {
          type: 'button',
          className: 'asmrone-btn sm' + (state.sleepEndAt ? ' primary' : ''),
          onClick: cycleSleep,
          title: t('sleepHint'),
          'aria-label': t('sleepHint')
        }, state.sleepEndAt
          ? t('sleepLeft').replace('{m}', String(Math.max(1, Math.ceil(state.sleepLeft / 60))))
          : t('sleepOff')),
        h('button', {
          type: 'button',
          className: 'asmrone-btn sm',
          onClick: () => setState({ open: true, miniExpanded: false })
        }, t('openPanel'))
      ))
    }

    //#region 面板
    function Overlay (props) {
      const t = makeT(props && props.t)
      const state = useStore()
      const audioRef = react.useRef(null)

      react.useEffect(() => {
        if (!state.open) return
        if (state.config === null) loadConfig(t)
        // 本地数量要挂在标签上，所以开面板就拉一次。host 侧有 60 秒缓存，很轻。
        if (!singleton.localLoaded) loadLocal(t)
      }, [state.open])

      react.useEffect(() => {
        const onKey = (event) => { if (event.key === 'Escape' && singleton.open) setState({ open: false }) }
        window.addEventListener('keydown', onKey)
        return () => window.removeEventListener('keydown', onKey)
      }, [])

      // 绑定页面级 audio，并把状态同步从 React 属性改成事件监听。
      react.useEffect(() => {
        const audio = ensureAudio()
        if (!audio) return undefined
        audioRef.current = audio

        const onPlay = () => setState({ playing: true })
        const onPause = () => setState({ playing: false })
        const onEnded = () => {
          // 整部循环：这一轨放完就接下一轨。单轨循环走不到这儿 ——
          // audio.loop 为真时 ended 压根不触发，两者天然互斥。
          if (singleton.loopMode === 'all' && playNextInList()) return
          setState({ playing: false })
        }
        const onTimeUpdate = () => {
          if (singleton.scrubbing) return
          const value = Number(audio.currentTime)
          if (Number.isFinite(value) && Math.abs(value - singleton.currentTime) >= 0.2) {
            setState({ currentTime: value })
          }
        }
        const onDuration = () => {
          const value = Number(audio.duration)
          if (Number.isFinite(value) && value > 0 && value !== singleton.duration) setState({ duration: value })
        }
        const onError = () => setState({ note: '音频加载失败：' + singleton.playingUrl })
        const onVolume = () => {
          const value = Number(audio.volume)
          if (Number.isFinite(value) && Math.abs(value - singleton.volume) > 0.001) setState({ volume: value })
        }

        audio.addEventListener('play', onPlay)
        audio.addEventListener('pause', onPause)
        audio.addEventListener('ended', onEnded)
        audio.addEventListener('timeupdate', onTimeUpdate)
        audio.addEventListener('loadedmetadata', onDuration)
        audio.addEventListener('durationchange', onDuration)
        audio.addEventListener('error', onError)
        audio.addEventListener('volumechange', onVolume)

        // 容器重建后把还在放的那首接回来：audio 里 src 还在、也许还在播，
        // 但新挂载的组件状态是空的，UI 会显示成「没在放」。
        const existing = audio.getAttribute('src')
        if (existing) {
          if (existing !== singleton.playingUrl) setState({ playingUrl: existing })
          if (!audio.paused) setState({ playing: true })
        }

        return () => {
          audio.removeEventListener('play', onPlay)
          audio.removeEventListener('pause', onPause)
          audio.removeEventListener('ended', onEnded)
          audio.removeEventListener('timeupdate', onTimeUpdate)
          audio.removeEventListener('loadedmetadata', onDuration)
          audio.removeEventListener('durationchange', onDuration)
          audio.removeEventListener('error', onError)
          audio.removeEventListener('volumechange', onVolume)
          // 故意不删 audio 元素 —— 它身上正挂着用户的声音，
          // 组件因切页/重建而卸载，不该把音乐一起掐掉。
        }
      }, [])

      // 换曲：src 直接写在页面级 audio 上，不走 React 属性绑定。
      react.useEffect(() => {
        const audio = audioRef.current
        if (!audio || !state.playingUrl) return
        if (audio.getAttribute('src') !== state.playingUrl) {
          audio.setAttribute('src', state.playingUrl)
          try { audio.load() } catch { /* 忽略 */ }
        }
        audio.volume = Number(singleton.volume)
        const promise = audio.play()
        if (promise && typeof promise.catch === 'function') {
          promise.catch(() => setState({ note: '浏览器拦下了自动播放：点播放条上的播放键。' }))
        }
      }, [state.playingUrl])

      // 单轨循环交给 audio.loop：它设成 true 时 ended 事件不触发，
      // 正好与「整部循环」互斥，不必在 onEnded 里再判一次。
      react.useEffect(() => {
        const audio = audioRef.current ?? ensureAudio()
        if (audio) audio.loop = singleton.loopMode === 'one'
      }, [state.loopMode, state.playingUrl])

      // 定时关闭：每秒对一次表。
      // 用「截止时间戳」而不是「倒计时递减」—— WebView 切到后台时定时器会被降频
      // 甚至冻结，数秒数会越数越偏；对时间戳则一次 tick 就追回来了。
      react.useEffect(() => {
        if (!state.sleepEndAt) return undefined
        const tick = () => {
          const left = Math.max(0, Math.round((singleton.sleepEndAt - Date.now()) / 1000))
          if (left !== singleton.sleepLeft) setState({ sleepLeft: left })
          if (left > 0) return
          const audio = audioRef.current
          if (audio) {
            try { audio.pause() } catch { /* 忽略 */ }
          }
          setState({ sleepEndAt: 0, sleepMinutes: 0, sleepLeft: 0, playing: false, note: t('sleepDone') })
        }
        tick()
        const timer = setInterval(tick, 1000)
        return () => clearInterval(timer)
      }, [state.sleepEndAt])

      // 进度轮询。timeupdate 只有 ~4Hz，滑块会一跳一跳；200ms 够顺也不费。
      // 拖动中不覆盖，否则滑块会被拽回去、拖不动。
      react.useEffect(() => {
        if (!state.playingUrl) return undefined
        const timer = setInterval(() => {
          const audio = audioRef.current
          if (!audio) return
          if (singleton.scrubbing) return
          const patch = {}
          const next = Number(audio.currentTime)
          if (Number.isFinite(next) && Math.abs(next - singleton.currentTime) >= 0.2) patch.currentTime = next
          const total = Number(audio.duration)
          if (Number.isFinite(total) && total > 0 && total !== singleton.duration) patch.duration = total
          if (Object.keys(patch).length > 0) setState(patch)
        }, 200)
        return () => clearInterval(timer)
      }, [state.playingUrl])

      // 系统媒体控制（锁屏 / 通知栏 / 耳机线控）。
      react.useEffect(() => {
        if (typeof navigator === 'undefined' || !('mediaSession' in navigator)) return undefined
        const session = navigator.mediaSession
        const setHandler = (name, handler) => {
          try { session.setActionHandler(name, handler) } catch { /* 该动作不支持，忽略 */ }
        }
        const audio = () => audioRef.current
        setHandler('play', () => { const a = audio(); if (a) a.play() })
        setHandler('pause', () => { const a = audio(); if (a) a.pause() })
        setHandler('seekbackward', (details) => {
          const a = audio(); if (a) a.currentTime = Math.max(0, a.currentTime - (details?.seekOffset || 15))
        })
        setHandler('seekforward', (details) => {
          const a = audio(); if (a) a.currentTime = Math.min(a.duration || 0, a.currentTime + (details?.seekOffset || 30))
        })
        setHandler('seekto', (details) => {
          const a = audio()
          if (a && typeof details?.seekTime === 'number') a.currentTime = details.seekTime
        })
        return () => {
          for (const name of ['play', 'pause', 'seekbackward', 'seekforward', 'seekto']) setHandler(name, null)
        }
      }, [])

      react.useEffect(() => {
        if (typeof navigator === 'undefined' || !('mediaSession' in navigator)) return
        if (!state.playingUrl) return
        try {
          if (typeof MediaMetadata !== 'function') return
          navigator.mediaSession.metadata = new MediaMetadata({
            title: state.playingTitle || 'ASMR',
            artist: 'dsh-asmrone',
            artwork: state.playingCover ? [{ src: state.playingCover }] : []
          })
        } catch { /* 某些 WebView 的 MediaMetadata 会抛，忽略 */ }
      }, [state.playingUrl, state.playingTitle, state.playingCover])

      // agent 推歌：每 3 秒问一次 host 有没有新的待播。
      // 轮询挂在常驻组件上，面板没开也在问 —— 主人只要说一句「放这个」，手机就出声。
      // 宿主还没重启（新路由不存在）时拿到 404，静默等下一轮。
      react.useEffect(() => {
        let stopped = false
        const tick = async () => {
          if (stopped) return
          try {
            const payload = await fetchJson('/asmrone/pending?since=' + singleton.pendingSeq)
            if (stopped) return
            const nextSeq = Number(payload.seq)
            if (Number.isFinite(nextSeq) && nextSeq !== singleton.pendingSeq) {
              setState({ pendingSeq: nextSeq })
            }
            const item = payload.item
            if (!item || !item.stream) return
            // 封面从已有的列表里顺手补 —— 待播条目本身不带图。
            const known = singleton.pool.concat(singleton.works)
              .find((work) => String(work.id) === String(item.id))
            setState({
              playingHash: item.hash,
              playingWorkId: String(item.id),
              playingTitle: item.title || item.hash,
              playingCover: (known && known.cover) || '',
              playingUrl: item.stream,
              playing: true,
              currentTime: 0,
              duration: 0,
              note: ''
            })
          } catch {
            /* 宿主未就绪 / 路由未挂载：下一轮再试 */
          }
        }
        tick()
        const timer = setInterval(tick, 3000)
        return () => { stopped = true; clearInterval(timer) }
      }, [])

      const onSearchKey = (event) => {
        if (event.key === 'Enter') runSearch(t, 1)
      }

      const playTrack = (work, track) => {
        setState({
          playingHash: track.hash,
          playingWorkId: String(work.id),
          playingTitle: track.title,
          playingCover: work.cover || '',
          playingUrl: api.streamUrl(track.hash),
          playing: true,
          currentTime: 0,
          duration: 0,
          ...playlistOf(state.tracks, (item) => ({
            hash: item.hash,
            workId: String(work.id),
            title: item.title,
            url: api.streamUrl(item.hash),
            cover: work.cover || ''
          }), track.hash)
        })
      }

      const onWeightChange = (key, value) => {
        const weights = sanitizeWeights(Object.assign({}, singleton.weights, { [key]: value }))
        writePref(LS_WEIGHTS, weights)
        setState({ weights })
      }

      const applyWeights = (next) => {
        const weights = sanitizeWeights(next)
        writePref(LS_WEIGHTS, weights)
        setState({ weights })
        if (!singleton.idle) runSearch(t, 1)
      }

      /* ── 权重面板 ── */
      const weightPanel = h('div', { className: 'asmrone-weights' },
        h('div', { className: 'asmrone-weightbox' },
          RANK_KEYS.map((key) => {
            const value = Number(state.weights[key]) || 0
            return h('div', { key, className: 'asmrone-weightrow' },
              h('span', { className: 'asmrone-weightlabel' }, t(WEIGHT_LABELS[key])),
              h('input', {
                type: 'range',
                className: 'asmrone-range',
                min: 0,
                max: 2,
                step: 0.1,
                value,
                onChange: (event) => onWeightChange(key, Number(event.target.value)),
                onPointerUp: () => { if (!singleton.idle) runSearch(t, 1) },
                onKeyUp: () => { if (!singleton.idle) runSearch(t, 1) },
                'aria-label': t(WEIGHT_LABELS[key])
              }),
              h('span', { className: 'asmrone-weightval' }, value.toFixed(1))
            )
          }),
          h('div', { className: 'asmrone-weightfoot' },
            h('button', { type: 'button', className: 'asmrone-btn sm', onClick: () => applyWeights(PRESET_WEIGHTS) }, t('preset')),
            h('button', { type: 'button', className: 'asmrone-btn sm', onClick: () => applyWeights(DEFAULT_WEIGHTS) }, t('zero')),
            h('span', { className: 'asmrone-weightlabel', style: { marginLeft: '6px' } }, t('depth')),
            h('select', {
              className: 'asmrone-select',
              value: String(state.depth),
              onChange: (event) => {
                const depth = clampNumber(event.target.value, 1, 5, 3)
                writePref(LS_DEPTH, depth)
                setState({ depth })
                if (!singleton.idle && smartActive(singleton)) runSearch(t, 1)
              }
            }, [1, 2, 3, 4, 5].map((n) => h('option', { key: n, value: String(n) }, n + ' ' + t('depthUnit'))))
          ),
          h('div', { className: 'asmrone-weighthint' },
            t('weightHint') + ' ' + t('depthHint'))
        )
      )

      /* ── 音轨面板 ── */
      const trackPanel = (work) => h('div', { className: 'asmrone-tracks' },
        h('div', { className: 'asmrone-sec' },
          t('tracks') + ' ' + (state.tracksLoading ? '' : state.tracks.length + ' ' + t('trackUnit'))),
        h('div', { style: { display: 'flex', gap: '6px', flexWrap: 'wrap', marginBottom: '8px' } },
          h('button', {
            type: 'button',
            className: 'asmrone-btn sm primary',
            disabled: state.downloading,
            onClick: (event) => { event.stopPropagation(); doDownload(t, { id: work.id, title: work.title }) }
          }, t('downloadAll')),
          h('button', {
            type: 'button',
            className: 'asmrone-btn sm',
            onClick: async (event) => {
              event.stopPropagation()
              try {
                const payload = await api.trial(work.id)
                setState({ note: payload.trials && payload.trials.length > 0
                  ? t('trial') + '：' + payload.trials.map((trial) => trial.sizeText).join(' / ')
                  : t('trialNone') })
              } catch (error) {
                setState({ note: t('err') + ': ' + error.message })
              }
            }
          }, t('trial'))
        ),
        state.tracksLoading ? h('div', { className: 'asmrone-note' }, t('loading')) : null,
        h('div', null, state.tracks.map((track, index) => h('div', {
          key: track.hash,
          className: 'asmrone-track' + (state.playingHash === track.hash ? ' asmrone-track-on' : '')
        },
        h('span', { className: 'asmrone-track-idx' }, String(index + 1)),
        h('button', {
          type: 'button',
          className: 'asmrone-btn sm' + (state.playingHash === track.hash ? ' primary' : ''),
          onClick: (event) => { event.stopPropagation(); playTrack(work, track) }
        }, state.playingHash === track.hash ? t('playing') : t('play')),
        h('span', { className: 'asmrone-track-name', title: track.title }, track.title),
        h('button', {
          type: 'button',
          className: 'asmrone-btn sm',
          disabled: state.downloading,
          title: t('downloadOne'),
          onClick: (event) => {
            event.stopPropagation()
            doDownload(t, { id: work.id, title: work.title, hashes: [track.hash] })
          }
        }, IconDownload())
        ))),
        state.downloadMsg ? h('div', { className: 'asmrone-note', style: { marginTop: '8px', whiteSpace: 'pre-wrap' } }, state.downloadMsg) : null
      )

      const cards = state.works.map((work) => {
        const isActive = state.active && state.active.id === work.id
        const isPlaying = state.playingHash !== '' && state.playingWorkId === String(work.id)
        const cls = ['asmrone-card']
        if (isActive) cls.push('asmrone-card-open')
        if (isPlaying) cls.push('playing')
        return h(react.Fragment, { key: String(work.id) },
          h('div', { className: cls.join(' '), onClick: () => openWork(t, work) },
            work.cover
              ? h('img', { className: 'asmrone-cover', src: work.cover, loading: 'lazy', alt: '' })
              : h('div', { className: 'asmrone-cover' }),
            h('div', { className: 'asmrone-info' },
              h('div', { className: 'asmrone-name' }, work.title),
              h('div', { className: 'asmrone-meta' },
                [
                  work.circle,
                  work.rating ? '★' + work.rating + '(' + work.ratingCount + ')' : null,
                  '销 ' + work.downloads,
                  work.durationText,
                  work.hasSubtitle ? '中文字幕' : null,
                  work.voiceActors && work.voiceActors.length ? 'CV ' + work.voiceActors.join('、') : null
                ].filter(Boolean).join(' · ')),
              h('div', { className: 'asmrone-tags' },
                (work.tags || []).map((tag) => h('span', { key: tag, className: 'asmrone-tag' }, tag)),
                typeof work.score === 'number'
                  ? h('span', { className: 'asmrone-score' }, work.score.toFixed(2))
                  : null
              )
            )
          ),
          isActive ? trackPanel(work) : null
        )
      })

      const smart = smartActive(state)
      const poolPages = smart ? Math.max(1, chunk(state.pool, state.pageSize || 20).length) : 1
      const shownPage = smart ? state.poolPage : state.page
      const totalPages = smart ? poolPages : Math.max(1, Math.ceil(state.total / (state.pageSize || 20)))

      /* ── 本地曲库 ──
       * 本地播放整条链都不碰网络：列表来自 host 扫盘，字节来自 /asmrone/local-stream。
       * 这是没代理时唯一能出声的路。
       *
       * 删除也挂在这一段上。因为是不可逆操作，交互刻意做成「两步」：
       * 先点「删整部 / 删这轨」或进多选模式勾选 → 出现确认条 → 才是真的发请求。
       * 没有 window.confirm（WebView 里样式不受控，而且会挡住播放控制条）。 */
      const playLocal = (work, file) => {
        const hash = 'local:' + work.key + ':' + file.index
        setState({
          playingHash: hash,
          playingWorkId: 'local:' + work.key,
          playingTitle: work.name + ' · ' + file.name,
          playingCover: '',
          playingUrl: api.localStreamUrl(work.key, file.index),
          playing: true,
          currentTime: 0,
          duration: 0,
          note: '',
          ...playlistOf(work.files, (item) => ({
            hash: 'local:' + work.key + ':' + item.index,
            workId: 'local:' + work.key,
            title: work.name + ' · ' + item.name,
            url: api.localStreamUrl(work.key, item.index),
            cover: ''
          }), hash)
        })
      }

      const toggleLocal = (work) => {
        if (singleton.activeLocal && singleton.activeLocal.key === work.key) {
          setState({ activeLocal: null })
          return
        }
        setState({ activeLocal: work })
        setTimeout(() => {
          const node = document.querySelector('.' + NS + '-card-open')
          if (node && typeof node.scrollIntoView === 'function') {
            node.scrollIntoView({ block: 'start', behavior: 'smooth' })
          }
        }, 80)
      }

      const isPicked = (work) => state.selected.indexOf(work.key) !== -1

      const togglePick = (work) => {
        const next = isPicked(work)
          ? singleton.selected.filter((key) => key !== work.key)
          : singleton.selected.concat([work.key])
        setState({ selected: next })
      }

      /** 弹确认条。`targets` 与 host 的 `/local/delete` 同形。 */
      const askDelete = (targets, label) => setState({ confirmDelete: { targets, label } })

      const localTrackPanel = (work) => h('div', { className: 'asmrone-tracks' },
        h('div', { className: 'asmrone-sec' }, work.count + ' ' + t('trackUnit') + ' · ' + work.sizeText),
        h('div', null, work.files.map((file) => {
          const hash = 'local:' + work.key + ':' + file.index
          const on = state.playingHash === hash
          return h('div', {
            key: hash,
            className: 'asmrone-track' + (on ? ' asmrone-track-on' : '')
          },
          h('span', { className: 'asmrone-track-idx' }, String(file.index)),
          h('button', {
            type: 'button',
            className: 'asmrone-btn sm' + (on ? ' primary' : ''),
            onClick: (event) => { event.stopPropagation(); playLocal(work, file) }
          }, on ? t('playing') : t('play')),
          h('span', { className: 'asmrone-track-name', title: file.name }, file.name),
          h('span', { className: 'asmrone-ptime' }, file.sizeText),
          h('button', {
            type: 'button',
            className: 'asmrone-btn sm danger',
            title: t('delTrack'),
            onClick: (event) => {
              event.stopPropagation()
              askDelete([{ key: work.key, indexes: [file.index] }], work.name + ' · ' + file.name)
            }
          }, t('delTrack'))
          )
        }))
      )

      const localCards = h('div', { className: 'asmrone-list' }, state.localWorks.map((work) => {
        const isActive = state.activeLocal && state.activeLocal.key === work.key
        const picked = isPicked(work)
        const badge = [
          work.rj === '' ? '' : 'id ' + work.rj,
          work.trial ? t('localTrial') : '',
          work.source === 'download' ? t('localDownload') : t('localLibrary')
        ].filter(Boolean).join(' · ')
        const cls = ['asmrone-card']
        if (isActive) cls.push('asmrone-card-open')
        if (picked) cls.push('asmrone-card-picked')

        return h(react.Fragment, { key: work.key },
          h('div', {
            className: cls.join(' '),
            // 多选模式下整张卡片就是勾选框 —— 手指比复选框大得多。
            onClick: () => (state.selectMode ? togglePick(work) : toggleLocal(work))
          },
          state.selectMode
            ? h('span', { className: 'asmrone-check' + (picked ? ' on' : '') }, picked ? '✓' : '')
            : h('div', {
                className: 'asmrone-cover',
                style: { display: 'flex', alignItems: 'center', justifyContent: 'center', background: '#eef2ff', color: '#4f7cff' }
              }, IconHeadphones({ size: 22 })),
          h('div', { className: 'asmrone-info' },
            h('div', { className: 'asmrone-name' }, work.name),
            h('div', { className: 'asmrone-meta' }, work.count + ' ' + t('trackUnit') + ' · ' + work.sizeText + (badge === '' ? '' : ' · ' + badge))
          ),
          state.selectMode
            ? null
            : h('button', {
                type: 'button',
                className: 'asmrone-btn sm',
                title: t('localTrial'),
                // 目录名里就带 RJ 号 —— 不必让用户去别处抄一遍。
                onClick: (event) => {
                  event.stopPropagation()
                  setState({ tab: 'trial', trialQuery: work.rj, trialError: '', trialNote: '', trialResults: [], trialActive: '', trialFailRj: '', trialFailMsg: '', trialOpeningRj: '' })
                  setTimeout(() => openTrialByRef(t, work.rj), 60)
                }
              }, t('localTrial')),
          state.selectMode
            ? null
            : h('button', {
                type: 'button',
                className: 'asmrone-btn sm danger',
                title: t('delWork'),
                onClick: (event) => {
                  event.stopPropagation()
                  askDelete([{ key: work.key, indexes: [] }], work.name + '（' + work.count + ' ' + t('trackUnit') + ' · ' + work.sizeText + '）')
                }
              }, t('delWork'))
          ),
          isActive && !state.selectMode ? localTrackPanel(work) : null
        )
      }))

      /* 本地工具条：多选模式的入口与出口。全选按「当前列表」算，不是全库 ——
       * 用户过滤之后再全选，期待的是删过滤出来的那一批。 */
      const localToolbar = h('div', { className: 'asmrone-deletebar' },
        h('button', {
          type: 'button',
          className: 'asmrone-chip' + (state.selectMode ? ' asmrone-chip-on' : ''),
          onClick: () => setState({ selectMode: !singleton.selectMode, selected: [], confirmDelete: null })
        }, state.selectMode ? t('delExit') : t('delSelect')),
        state.selectMode
          ? h('button', {
              type: 'button',
              className: 'asmrone-chip',
              disabled: state.localWorks.length === 0,
              onClick: () => {
                const all = singleton.localWorks.map((work) => work.key)
                setState({ selected: singleton.selected.length === all.length ? [] : all })
              }
            }, t('delSelectAll'))
          : null,
        state.selectMode && state.selected.length > 0
          ? h('span', { className: 'asmrone-count' }, t('delSelectedN').replace('{n}', String(state.selected.length)))
          : null,
        state.selectMode && state.selected.length > 0
          ? h('button', {
              type: 'button',
              className: 'asmrone-btn sm danger',
              disabled: state.deleting,
              onClick: () => {
                const targets = singleton.selected.map((key) => ({ key, indexes: [] }))
                askDelete(targets, singleton.selected.length + ' 部（批量）')
              }
            }, t('delSelected'))
          : null
      )

      const confirmBar = state.confirmDelete === null
        ? null
        : h('div', { className: 'asmrone-confirm' },
            h('div', { className: 'asmrone-confirm-title' }, t('delConfirmTitle')),
            h('div', { className: 'asmrone-confirm-body' }, state.confirmDelete.label),
            h('div', { className: 'asmrone-confirm-warn' }, t('delWarn')),
            h('div', { className: 'asmrone-confirm-actions' },
              h('button', {
                type: 'button',
                className: 'asmrone-btn sm',
                disabled: state.deleting,
                onClick: () => setState({ confirmDelete: null })
              }, t('delCancel')),
              h('button', {
                type: 'button',
                className: 'asmrone-btn sm danger',
                disabled: state.deleting,
                onClick: () => doDelete(t, singleton.confirmDelete.targets)
              }, state.deleting ? t('delDeleting') : t('delConfirm'))
            )
          )

      const localBody = h(react.Fragment, null,
        confirmBar,
        state.localError ? h('div', { className: 'asmrone-note warn' }, state.localError) : null,
        state.localLoading && state.localWorks.length === 0
          ? h('div', { className: 'asmrone-loading' }, t('localScanning'))
          : null,
        !state.localLoading && state.localWorks.length === 0 && !state.localError
          ? h('div', { className: 'asmrone-empty' }, t('localEmpty'))
          : null,
        state.localWorks.length > 0 ? localToolbar : null,
        state.localRoots.map((root) => h('div', { key: root.path, className: 'asmrone-rootline' },
          (root.exists ? (root.isDirectory ? '✓ ' : '✗ ') : '✗ ') + root.path +
          (root.exists && root.isDirectory
            ? '　' + root.works + ' 部 · ' + root.sizeText
            : '　' + t('localNoDir')))),
        state.localWorks.length > 0
          ? h('div', { className: 'asmrone-count' },
              t('localTotal') + ' ' + state.localTotals.works + ' 部 · ' +
              state.localTotals.files + ' ' + t('trackUnit') + ' · ' + state.localTotals.sizeText)
          : null,
        state.localWorks.length > 0 ? localCards : null,
        state.deleteMsg
          ? h('div', { className: 'asmrone-note', style: { marginTop: '10px', whiteSpace: 'pre-wrap' } }, state.deleteMsg)
          : null,
        state.localWorks.length > 0
          ? h('div', { className: 'asmrone-note', style: { marginTop: '10px' } }, t('localPlayHint'))
          : null
      )

      /* ── B 站曲库 ──
       * 三段式：搜 → 展开分 P → 点播。点播不做「下载再播」，直接把稳定流地址交给
       * 常驻播放器，字节由 host 转发 B 站 CDN，手机上不产生任何文件。 */
      const shortPlay = (value) => {
        const number = Number(value) || 0
        if (number >= 100000000) return (number / 100000000).toFixed(1) + '亿'
        if (number >= 10000) return (number / 10000).toFixed(1) + '万'
        return String(number)
      }

      /**
       * @param {object} work
       * @param {number} pageNo
       * @param {string} cid
       * @param {Array} [pagesArg] 显式给分 P 列表。卡片上的播放键刚 `setState` 完
       *   就调这里，那时 `state.biliPages` 还是旧闭包值 —— 不显式传就会拿到空数组，
       *   于是「整部循环」在这条最常用的路径上失效。
       */
      const playBili = (work, pageNo, cid, pagesArg) => {
        const pages = Array.isArray(pagesArg) ? pagesArg : state.biliPages
        const many = pages.length > 1
        const hash = 'bili:' + work.bvid + ':' + pageNo
        setState({
          playingHash: hash,
          playingWorkId: 'bili:' + work.bvid,
          playingTitle: (work.title || work.bvid) + (many ? ' · P' + pageNo : ''),
          playingCover: work.cover || '',
          playingUrl: api.biliStreamUrl(work.bvid, cid, 30280),
          playing: true,
          currentTime: 0,
          duration: 0,
          note: '',
          ...playlistOf(pages, (page) => ({
            hash: 'bili:' + work.bvid + ':' + page.page,
            workId: 'bili:' + work.bvid,
            title: (work.title || work.bvid) + (many ? ' · P' + page.page : ''),
            url: api.biliStreamUrl(work.bvid, page.cid, 30280),
            cover: work.cover || ''
          }), hash)
        })
      }

      /** 卡片上的播放键：还没展开过就先拉一次分 P —— 搜索结果里不带 cid。 */
      const playBiliDirect = async (work) => {
        let pages = state.biliPages
        if (!state.biliActive || state.biliActive.bvid !== work.bvid || pages.length === 0) {
          try {
            const payload = await api.biliWork(work.bvid)
            pages = payload.work?.pages ?? []
            setState({ biliActive: work, biliPages: pages, biliPagesLoading: false })
          } catch (error) {
            setState({ biliError: t('err') + ': ' + error.message })
            return
          }
        }
        const first = pages[0]
        if (first === undefined) {
          setState({ biliError: t('err') + '：这个稿件没有可用音轨' })
          return
        }
        playBili(work, first.page, first.cid, pages)
      }

      const biliTrackPanel = (work) => h('div', { className: 'asmrone-tracks' },
        h('div', { className: 'asmrone-sec' },
          state.biliPagesLoading ? t('loading') : state.biliPages.length + ' ' + t('biliPages')),
        state.biliPagesLoading
          ? null
          : h('div', null, state.biliPages.map((page) => {
            const hash = 'bili:' + work.bvid + ':' + page.page
            const on = state.playingHash === hash
            return h('div', {
              key: hash,
              className: 'asmrone-track' + (on ? ' asmrone-track-on' : '')
            },
            h('span', { className: 'asmrone-track-idx' }, 'P' + page.page),
            h('button', {
              type: 'button',
              className: 'asmrone-btn sm' + (on ? ' primary' : ''),
              onClick: (event) => { event.stopPropagation(); playBili(work, page.page, page.cid) }
            }, on ? t('playing') : t('play')),
            h('span', { className: 'asmrone-track-name', title: page.part }, page.part),
            h('span', { className: 'asmrone-ptime' }, page.durationText)
            )
          }))
      )

      const biliCards = h('div', { className: 'asmrone-list' }, state.biliWorks.map((work) => {
        const isActive = state.biliActive && state.biliActive.bvid === work.bvid
        const cls = ['asmrone-card']
        if (isActive) cls.push('asmrone-card-open')
        if (state.playingWorkId === 'bili:' + work.bvid) cls.push('playing')

        return h(react.Fragment, { key: work.bvid },
          h('div', { className: cls.join(' '), onClick: () => openBiliWork(t, work) },
            work.cover
              // B 站图床有防盗链；no-referrer 才拿得到图，否则是一片灰。
              ? h('img', { className: 'asmrone-cover', src: work.cover, loading: 'lazy', alt: '', referrerPolicy: 'no-referrer' })
              : h('div', { className: 'asmrone-cover' }),
            h('div', { className: 'asmrone-info' },
              h('div', { className: 'asmrone-name' }, work.title),
              h('div', { className: 'asmrone-meta' },
                [work.author, work.durationText, '播放 ' + shortPlay(work.plays), work.typeName].filter(Boolean).join(' · ')),
              work.description ? h('div', { className: 'asmrone-desc' }, work.description) : null
            ),
            h('button', {
              type: 'button',
              className: 'asmrone-btn sm primary',
              onClick: (event) => { event.stopPropagation(); playBiliDirect(work) }
            }, t('play'))
          ),
          isActive ? biliTrackPanel(work) : null
        )
      }))

      const biliBody = h(react.Fragment, null,
        state.biliError ? h('div', { className: 'asmrone-note warn' }, state.biliError) : null,
        state.biliLoading && state.biliWorks.length === 0
          ? h('div', { className: 'asmrone-loading' }, t('loading'))
          : null,
        !state.biliLoaded && !state.biliError ? h('div', { className: 'asmrone-empty' }, t('biliIdle')) : null,
        state.biliLoaded && !state.biliLoading && state.biliWorks.length === 0 && !state.biliError
          ? h('div', { className: 'asmrone-empty' }, t('biliEmpty'))
          : null,
        state.biliWorks.length > 0
          ? h('div', { className: 'asmrone-count' },
              t('biliTotal') + ' ' + state.biliTotal + '（接口上限 1000）· ' + t('page') + ' ' + state.biliPage)
          : null,
        state.biliWorks.length > 0 ? biliCards : null,
        state.biliWorks.length > 0
          ? h('div', { className: 'asmrone-pager' },
              h('button', {
                type: 'button',
                className: 'asmrone-btn sm',
                disabled: state.biliLoading || state.biliPage <= 1,
                onClick: () => runBiliSearch(t, state.biliPage - 1)
              }, t('prev')),
              h('span', { className: 'asmrone-count' }, t('page') + ' ' + state.biliPage),
              h('button', {
                type: 'button',
                className: 'asmrone-btn sm',
                disabled: state.biliLoading,
                onClick: () => runBiliSearch(t, state.biliPage + 1)
              }, t('next'))
            )
          : null,
        state.biliWorks.length > 0
          ? h('div', { className: 'asmrone-note', style: { marginTop: '10px' } }, t('biliPlayHint'))
          : null
      )

      /* ── DLsite 试听 ──
       * 手机端只给在线听、不给下载；这里两个都给了。
       * 播放地址是 host 内存里的切片，所以「在线听」是真的不落盘。 */
      /** 已打开的那个试听包：曲目 + 下载 / 释放。 */
      const trialTrackPanel = (t) => {
        const work = state.trialWork
        if (!work) {
          return h('div', { className: 'asmrone-tracks' },
            h('div', { className: 'asmrone-note' }, t('trialNoTrial')))
        }
        return h('div', { className: 'asmrone-tracks' },
          h('div', { className: 'asmrone-sec' },
            work.tracks.length + ' ' + t('trialTracks') + ' · ' + work.sizeText +
            '（' + t('trialZip') + ' ' + work.zipSizeText + '）'),
          h('div', null, work.tracks.map((track) => {
            const hash = 'trial:' + work.workno + ':' + track.index
            const on = state.playingHash === hash
            return h('div', { key: hash, className: 'asmrone-track' + (on ? ' asmrone-track-on' : '') },
              h('span', { className: 'asmrone-track-idx' }, String(track.index)),
              h('button', {
                type: 'button',
                className: 'asmrone-btn sm' + (on ? ' primary' : ''),
                onClick: (event) => { event.stopPropagation(); playTrial(track) }
              }, on ? t('playing') : t('play')),
              h('span', { className: 'asmrone-track-name', title: track.name }, track.name),
              h('span', { className: 'asmrone-ptime' }, track.sizeText)
            )
          })),
          h('div', { className: 'asmrone-deletebar', style: { marginTop: '10px' } },
            h('button', {
              type: 'button',
              className: 'asmrone-btn sm',
              disabled: state.trialSaving,
              onClick: (event) => { event.stopPropagation(); saveTrial(t) }
            }, state.trialSaving ? t('trialSaving') : t('trialDownload')),
            h('button', {
              type: 'button',
              className: 'asmrone-btn sm',
              onClick: (event) => { event.stopPropagation(); releaseTrial(t) }
            }, t('trialRelease'))
          ),
          h('div', { className: 'asmrone-note', style: { marginTop: '8px' } }, t('trialListenHint'))
        )
      }

      /* ── DLsite 试听 ──
       * 搜索结果内联展开试听包，交互跟其它标签页一致（点一下展开、再点收起）。
       * 播放地址是 host 内存里的切片，所以「在线听」是真的不落盘。 */
      /**
       * 打开失败的说明 + 「下载到本地」出口。
       *
       * 默认贴在出错的那一部卡片下面；只有当那一部不在当前结果里
       * （粘贴的 RJ、从别的标签页跳过来）才回退到列表顶上 —— 总比不显示强。
       */
      const trialFailBox = (t, rj) => h(react.Fragment, null,
        h('div', { className: 'asmrone-note warn' }, state.trialFailMsg),
        h('div', { className: 'asmrone-deletebar', style: { marginTop: '10px' } },
          h('button', {
            type: 'button',
            className: 'asmrone-btn sm',
            disabled: state.trialSaving,
            onClick: (event) => { event.stopPropagation(); saveTrial(t, rj) }
          }, state.trialSaving ? t('trialSaving') : t('trialDownload')))
      )

      /** 失败的那一部在不在当前结果列表里 —— 在的话提示就挂到它的卡片下面。 */
      const failCardVisible = state.trialFailRj !== '' &&
        state.trialResults.some((work) => work.workno === state.trialFailRj)

      const trialBody = h(react.Fragment, null,
        // 顶端的错误只留给两种情况：搜索本身失败，或者失败的那一部没有卡片可挂。
        // 打开某一部的失败一律挂到那一部下面 —— 那才是用户看得懂的位置。
        state.trialError ? h('div', { className: 'asmrone-note warn' }, state.trialError) : null,
        state.trialFailMsg !== '' && !failCardVisible && !state.trialOpening
          ? h('div', { className: 'asmrone-tracks' }, trialFailBox(t, state.trialFailRj))
          : null,
        // 打开某一部的 loading 已经落到那张卡片下面了，这里只管搜索 ——
        // 不然点一下「试听」，整页看起来都在等。
        state.trialSearching
          ? h('div', { className: 'asmrone-loading' }, t('loading'))
          : null,
        !state.trialSearched && !state.trialWork && !state.trialSearching &&
          !state.trialOpening && !state.trialError && state.trialFailMsg === ''
          ? h('div', { className: 'asmrone-empty' }, t('trialIdle'))
          : null,
        state.trialSearched && state.trialResults.length === 0 && !state.trialSearching && !state.trialError
          ? h('div', { className: 'asmrone-empty' }, t('trialNoResult'))
          : null,

        state.trialResults.length > 0
          ? h('div', { className: 'asmrone-count' },
              t('trialFound') + ' ' + state.trialResults.length + ' ' + t('trialUnit') +
              ' · ' + t('page') + ' ' + state.trialPage +
              // 中文输入被换成了日文关键词 —— 得让人知道实际搜的是什么。
              (state.trialTranslated
                ? ' ' + t('trialTranslated').replace('{from}', state.trialAsked).replace('{to}', state.trialKeyword)
                : ''))
          : null,

        h('div', { className: 'asmrone-list' }, state.trialResults.map((work) => {
          const isActive = state.trialActive === work.workno
          const cls = ['asmrone-card']
          if (isActive) cls.push('asmrone-card-open')
          if (state.playingWorkId === 'trial:' + work.workno) cls.push('playing')
          return h(react.Fragment, { key: work.workno },
            h('div', { className: cls.join(' '), onClick: () => toggleTrial(t, work) },
              work.cover
                // DLsite 图床也认 Referer，no-referrer 才稳。
                ? h('img', { className: 'asmrone-cover', src: work.cover, loading: 'lazy', alt: '', referrerPolicy: 'no-referrer' })
                : h('div', { className: 'asmrone-cover' }),
              h('div', { className: 'asmrone-info' },
                h('div', { className: 'asmrone-name' }, work.title),
                h('div', { className: 'asmrone-meta' },
                  [
                    work.workno,
                    work.circle,
                    work.voice ? 'CV ' + work.voice : '',
                    work.price ? work.price + ' 円' : '',
                    work.category
                  ].filter(Boolean).join(' · '))
              ),
              h('button', {
                type: 'button',
                className: 'asmrone-btn sm' + (isActive ? ' primary' : ''),
                onClick: (event) => { event.stopPropagation(); toggleTrial(t, work) }
              }, isActive ? t('more') : t('trialOpen'))
            ),
            isActive ? trialTrackPanel(t) : null,
            // 正在打开 / 打开失败 —— 都贴在**这一张**卡片下面，
            // 而不是飘到列表顶端去。点哪一部就在哪一部下面出结果，这是最基本的预期。
            state.trialOpeningRj === work.workno
              ? h('div', { className: 'asmrone-tracks' },
                  h('div', { className: 'asmrone-note' }, t('trialOpening')))
              : null,
            state.trialFailRj === work.workno && state.trialFailMsg !== '' && !state.trialOpening
              ? h('div', { className: 'asmrone-tracks' }, trialFailBox(t, work.workno))
              : null
          )
        })),

        state.trialResults.length > 0
          ? h('div', { className: 'asmrone-pager' },
              h('button', {
                type: 'button',
                className: 'asmrone-btn sm',
                disabled: state.trialSearching || state.trialPage <= 1,
                onClick: () => runTrialSearch(t, state.trialPage - 1)
              }, t('prev')),
              h('span', { className: 'asmrone-count' }, t('page') + ' ' + state.trialPage),
              h('button', {
                type: 'button',
                className: 'asmrone-btn sm',
                disabled: state.trialSearching || !state.trialHasMore,
                onClick: () => runTrialSearch(t, state.trialPage + 1)
              }, t('next'))
            )
          : null,

        state.trialNote
          ? h('div', { className: 'asmrone-note', style: { marginTop: '10px', whiteSpace: 'pre-wrap' } }, state.trialNote)
          : null
      )

      /* ── 面板本体 ── */
      const dialog = h('div', {
        className: 'asmrone-backdrop',
        onClick: (event) => { if (event.target === event.currentTarget) setState({ open: false }) }
      },
      h('div', { className: 'asmrone-dialog', role: 'dialog', 'aria-modal': 'true', 'aria-label': t('panelAria') },
        h('div', { className: 'asmrone-header' },
          h('h2', { className: 'asmrone-title' }, t('title')),
          h('button', {
            type: 'button',
            className: 'asmrone-close',
            'aria-label': t('close'),
            onClick: () => setState({ open: false })
          }, IconClose())
        ),
        h('div', { className: 'asmrone-tabs' },
          [
            { id: 'online', label: t('tabOnline'), badge: null },
            { id: 'bili', label: t('tabBili'), badge: null },
            { id: 'trial', label: t('tabTrial'), badge: null },
            {
              id: 'local',
              label: t('tabLocal'),
              badge: state.localLoaded && state.localTotals.works > 0 ? state.localTotals.works : null
            }
          ].map((tab) => h('button', {
            key: tab.id,
            type: 'button',
            className: 'asmrone-tab' + (state.tab === tab.id ? ' asmrone-tab-on' : ''),
            onClick: () => {
              // 切页时把悬着的删除确认收掉 —— 换个页面还挂着「确认删除」最容易误点。
              setState({ tab: tab.id, confirmDelete: null })
              if (tab.id === 'local' && !singleton.localLoaded) loadLocal(t)
            }
          },
          tab.label,
          tab.badge === null ? null : h('span', { className: 'asmrone-tab-badge' }, ' ' + tab.badge)))
        ),
        state.tab === 'trial'
          ? h('div', { className: 'asmrone-search' },
              h('input', {
                className: 'asmrone-input',
                placeholder: t('trialPlaceholder'),
                value: state.trialQuery,
                onChange: (event) => setState({ trialQuery: event.target.value }),
                onKeyDown: (event) => { if (event.key === 'Enter') runTrialSearch(t, 1) }
              }),
              h('button', {
                type: 'button',
                className: 'asmrone-btn sm',
                title: t('trialPasteHint'),
                onClick: async () => {
                  try {
                    const text = await navigator.clipboard.readText()
                    if (text && text.trim() !== '') {
                      setState({ trialQuery: text.trim() })
                      return
                    }
                  } catch { /* WebView 不给读剪贴板权限，退化成手动粘贴 */ }
                  setState({ trialNote: t('trialPasteHint') })
                }
              }, t('trialPaste')),
              h('button', {
                type: 'button',
                className: 'asmrone-btn primary',
                disabled: state.trialSearching,
                onClick: () => runTrialSearch(t, 1)
              }, state.trialSearching ? t('loading') : t('trialSearch'))
            )
          : state.tab === 'local'
          ? h('div', { className: 'asmrone-search' },
              h('input', {
                className: 'asmrone-input',
                placeholder: t('localFilter'),
                value: state.localQuery,
                onChange: (event) => setState({ localQuery: event.target.value }),
                onKeyDown: (event) => { if (event.key === 'Enter') loadLocal(t) }
              }),
              h('button', {
                type: 'button',
                className: 'asmrone-btn primary',
                disabled: state.localLoading,
                onClick: () => loadLocal(t)
              }, state.localLoading ? t('localScanning') : t('go')),
              h('button', {
                type: 'button',
                className: 'asmrone-btn',
                disabled: state.localLoading,
                title: t('localRescan'),
                onClick: () => { setState({ activeLocal: null }); loadLocal(t, { force: true }) }
              }, t('localRescan'))
            )
          : state.tab === 'bili'
            ? h('div', { className: 'asmrone-search' },
                h('input', {
                  className: 'asmrone-input',
                  placeholder: t('biliPlaceholder'),
                  value: state.biliQuery,
                  onChange: (event) => setState({ biliQuery: event.target.value }),
                  onKeyDown: (event) => { if (event.key === 'Enter') runBiliSearch(t, 1) }
                }),
                h('button', {
                  type: 'button',
                  className: 'asmrone-btn primary',
                  disabled: state.biliLoading,
                  onClick: () => runBiliSearch(t, 1)
                }, state.biliLoading ? t('loading') : t('go')),
                h('select', {
                  className: 'asmrone-select',
                  value: state.biliOrder,
                  onChange: (event) => {
                    setState({ biliOrder: event.target.value })
                    if (singleton.biliLoaded) runBiliSearch(t, 1)
                  }
                }, [
                  ['totalrank', 'biliOrderRank'],
                  ['click', 'biliOrderClick'],
                  ['pubdate', 'biliOrderNew'],
                  ['stow', 'biliOrderStow']
                ].map(([value, label]) => h('option', { key: value, value }, t('order') + '：' + t(label))))
              )
            : h('div', { className: 'asmrone-search' },
              h('input', {
                className: 'asmrone-input',
                placeholder: t('searchPlaceholder'),
                value: state.query,
                onChange: (event) => setState({ query: event.target.value }),
                onKeyDown: onSearchKey
              }),
              h('button', {
                type: 'button',
                className: 'asmrone-btn primary',
                disabled: state.loading,
                onClick: () => runSearch(t, 1)
              }, state.loading ? t('loading') : t('go'))
            ),
        state.tab === 'online' ? h('div', { className: 'asmrone-chips' },
          h('select', {
            className: 'asmrone-select',
            value: state.order,
            onChange: (event) => {
              setState({ order: event.target.value })
              if (!singleton.idle) runSearch(t, 1)
            }
          }, [
            ['dl_count', 'orderSales'],
            ['rate_average_2dp', 'orderRating'],
            ['release', 'orderRelease'],
            ['create_date', 'orderNew']
          ].map(([value, label]) => h('option', { key: value, value }, t('order') + '：' + t(label)))),
          h('button', {
            type: 'button',
            className: 'asmrone-chip' + (state.chinese ? ' asmrone-chip-on' : ''),
            onClick: () => {
              setState({ chinese: !singleton.chinese })
              if (!singleton.idle) runSearch(t, 1)
            }
          }, t('chineseOnly')),
          h('button', {
            type: 'button',
            className: 'asmrone-chip' + (state.male ? ' asmrone-chip-on' : ''),
            onClick: () => {
              setState({ male: !singleton.male })
              if (!singleton.idle) runSearch(t, 1)
            }
          }, t('maleOnly')),
          h('button', {
            type: 'button',
            className: 'asmrone-chip' + (smart ? ' asmrone-chip-on' : ''),
            onClick: () => setState({ weightsOpen: !singleton.weightsOpen }),
            title: t('weights')
          }, IconSliders(), ' ' + (smart ? t('weightsOn') : t('weightsOff'))),
          h('button', {
            type: 'button',
            className: 'asmrone-chip',
            onClick: () => setState({ weightsOpen: !singleton.weightsOpen })
          }, IconChevron({ open: state.weightsOpen }))
        ) : null,
        state.tab === 'online' && state.weightsOpen ? weightPanel : null,
        h('div', { className: 'asmrone-body' },
          state.tab === 'local'
            ? localBody
            : state.tab === 'trial'
              ? trialBody
              : state.tab === 'bili'
                ? biliBody
                : h(react.Fragment, null,
          state.error ? h('div', { className: 'asmrone-note warn' }, state.error) : null,
          state.idle ? h('div', { className: 'asmrone-empty' }, t('idle')) : null,
          !state.idle && !state.loading && state.works.length === 0 && !state.error
            ? h('div', { className: 'asmrone-empty' }, t('empty')) : null,
          !state.idle && state.works.length > 0
            ? h('div', { className: 'asmrone-count' },
                smart
                  ? t('poolNote').replace('{n}', String(state.pool.length)).replace('{p}', String(shownPage))
                  : t('total') + ' ' + state.total + ' ' + t('unit'))
            : null,
          h('div', { className: 'asmrone-list' }, cards),
          !state.idle && state.works.length > 0
            ? h('div', { className: 'asmrone-pager' },
                h('button', {
                  type: 'button',
                  className: 'asmrone-btn sm',
                  disabled: state.loading || shownPage <= 1,
                  onClick: () => (smart ? gotoPoolPage(t, shownPage - 1) : runSearch(t, state.page - 1))
                }, t('prev')),
                h('span', { className: 'asmrone-count' }, t('page') + ' ' + shownPage + ' / ' + totalPages),
                h('button', {
                  type: 'button',
                  className: 'asmrone-btn sm',
                  disabled: state.loading || shownPage >= totalPages,
                  onClick: () => (smart ? gotoPoolPage(t, shownPage + 1) : runSearch(t, state.page + 1))
                }, t('next')),
                smart
                  ? h('button', {
                      type: 'button',
                      className: 'asmrone-btn sm',
                      disabled: state.loading,
                      onClick: () => runSearch(t, 1)
                    }, t('shuffle'))
                  : null
              )
            : null,
          state.note ? h('div', { className: 'asmrone-note', style: { marginTop: '10px' } }, state.note) : null,
          state.config
            ? h('div', null,
                h('div', { className: 'asmrone-sec' }, t('config')),
                h('div', { className: 'asmrone-meta' },
                  '目录 ' + state.config.outputDir + ' · 并发 ' + state.config.downloadConcurrency +
                  ' · 每页 ' + state.config.pageSize + ' · 试听上限 ' + state.config.maxWorkMb + 'MB'))
            : null
          )
        ),
        state.playingUrl ? h(Player, { t, state, audioRef }) : null
      ))

      /* ── 常驻段 ──
       * audio 永远是第一个子节点，且**不受 open 影响**：面板关了、切到对话页，
       * 元素都还在，播放不断。藏法用 1px + opacity:0 —— display:none 会让
       * 部分 WebView 直接停播。 */
      return h(react.Fragment, null,
        state.open ? dialog : null,
        // 面板关掉后留一枚悬浮球 —— 切到对话页也能停/拖/收，而且它不挡位置。
        !state.open ? h(FloatingPlayer, { t, state, audioRef }) : null
      )
    }
    //#endregion

    const inject = ['slots', 'locale']

    function apply (ctx) {
      const removeStyle = injectStyle()

      ctx.effect(() => {
        ctx.locale.register(NS, { zh })
        return () => {
          if (ctx.locale.unregister) ctx.locale.unregister(NS)
          removeStyle()
        }
      }, 'dsh-asmrone: locale')

      ctx.slots.inject('sidebar.footer.action', () => {
        return ctx.slots.register({ name: 'sidebar.footer.action', id: NS, order: 4, locale: NS }, SidebarAction)
      })

      ctx.slots.inject('shell.overlay', () => {
        return ctx.slots.register({ name: 'shell.overlay', id: NS, order: 11, locale: NS }, Overlay)
      })
    }

    return { inject, apply }
  }
})
