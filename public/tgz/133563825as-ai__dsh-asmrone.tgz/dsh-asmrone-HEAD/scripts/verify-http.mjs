/**
 * HTTP 数据面的端到端自检。
 *
 * 起一个假 webServer，让插件把路由挂上来，然后真打这些端点。
 * 只在网络可达时有意义；失败会直接以非 0 退出。
 *
 * 跑：`node scripts/verify-http.mjs`
 */

import { createServer } from 'node:http'

import { apply } from '../src/index.js'

const runEffect = (fn) => {
  const result = fn()
  if (result && typeof result.next === 'function') {
    while (!result.next().done) { /* 跑干 generator */ }
  }
  return result
}

const routes = []
const ctx = {
  logger: { info: () => {} },
  tools: { register: () => {} },
  effect: runEffect,
  inject: (names, callback) => {
    if (names.includes('webServer')) {
      callback({ webServer: { register: (spec) => { routes.push(spec); return () => {} } }, effect: runEffect })
    }
  }
}

apply(ctx, {})
if (routes.length === 0) {
  console.error('✗ 路由没挂上')
  process.exit(1)
}
console.log('✓ 路由已挂载：', routes.map((route) => route.path).join(', '))

const server = createServer((req, res) => routes[0].handler(req, res))
await new Promise((resolve) => server.listen(0, resolve))
const base = `http://127.0.0.1:${server.address().port}`

const failures = []
const check = (label, ok, detail) => {
  console.log(`${ok ? '✓' : '✗'} ${label}${detail === undefined ? '' : ` — ${detail}`}`)
  if (!ok) failures.push(label)
}
const getJson = async (path) => {
  const response = await fetch(base + path)
  return { status: response.status, body: await response.json().catch(() => null) }
}
const postJson = async (path, body) => {
  const response = await fetch(base + path, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body)
  })
  return { status: response.status, body: await response.json().catch(() => null) }
}

try {
  // 配置
  let result = await getJson('/asmrone/config')
  check('GET /config', result.status === 200, result.body?.config?.outputDir)

  // 搜索
  result = await getJson('/asmrone/search?q=%E8%88%8C%E8%80%B3&pageSize=3')
  check('GET /search', result.status === 200 && result.body.works.length > 0, `total ${result.body?.total}`)
  const work = result.body?.works?.[0]
  if (work) {
    console.log(`    首个：${work.title.slice(0, 44)}`)
    console.log(`    封面：${(work.cover || '(空)').slice(0, 56)}`)
    console.log(`    DLsite：${(work.sourceUrl || '(空)').slice(0, 76)}`)
    console.log(`    标签：${(work.tags || []).join(' / ')}`)
  }
  check('搜索项带封面', Boolean(work?.cover))
  check('搜索项带 DLsite 链接', /dlsite\.com/.test(work?.sourceUrl ?? ''))

  // 音轨
  result = await getJson('/asmrone/work?id=1006912')
  check('GET /work', result.status === 200 && result.body.count > 0, `${result.body?.count} 轨`)
  const hash = result.body?.tracks?.[0]?.hash

  // 标签
  result = await getJson('/asmrone/tags')
  check('GET /tags', result.status === 200 && result.body.tags.length > 100, `${result.body?.tags?.length} 个`)

  // 音频代理（Range 请求）
  if (hash !== undefined) {
    const response = await fetch(`${base}/asmrone/stream?hash=${encodeURIComponent(hash)}`, { headers: { range: 'bytes=0-1023' } })
    const buffer = Buffer.from(await response.arrayBuffer())
    const head = buffer.subarray(0, 3)
    const isMp3 = head[0] === 0x49 && head[1] === 0x44 && head[2] === 0x33 // "ID3"
    check('GET /stream (Range)', response.status === 206, `${response.headers.get('content-type')} · ${buffer.length}B · ${response.headers.get('content-range')}`)
    check('音频是有效 MP3', isMp3 || (head[0] === 0xff), `头 ${head.toString('hex')}`)
  }

  // DLsite 试听探测。DLsite 是被墙的，容器跟着手机的 VPN 走 —— 关掉时请求会挂到超时。
  // 那种情况**跳过**而不是判失败（跟 B 站的在线用例同一个原则：宁可诚实 skip，不要假红）。
  result = await getJson('/asmrone/trial?rj=RJ01726233')
  if (result.status >= 500) {
    console.log('﹣ GET /trial 跳过（DLsite 不可达 —— 需要手机上的代理 / VPN 开着）')
  } else {
    const firstTrial = result.body?.trials?.[0]
    check('GET /trial', result.status === 200, `${result.body?.trials?.length ?? 0} 个试听包${firstTrial ? ` · ${firstTrial.sizeText}` : ''}`)
  }

  // 待播队列 —— 先确认初始是空的（下面本地那节会往里推一条）
  result = await getJson('/asmrone/pending?since=0')
  check('GET /pending（空队列）', result.status === 200 && result.body.item === null, `seq ${result.body?.seq}`)

  // 推歌用的 POST 助手。放在这里是因为本地那节也要用它，而 const 有 TDZ。
  const postPlay = async (body) => {
    const response = await fetch(`${base}/asmrone/play`, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify(body)
    })
    return { status: response.status, body: await response.json().catch(() => null) }
  }

  // ── 本地曲库：整条链不碰网络，所以任何网络状态下都该全绿 ──
  result = await getJson('/asmrone/local?force=1')
  check('GET /local 扫到本地作品', result.status === 200 && result.body.totals.works > 0,
    `${result.body?.totals?.works} 部 · ${result.body?.totals?.files} 轨 · ${result.body?.totals?.sizeText}`)
  const localWork = result.body?.works?.find((work) => work.count > 0)
  check('本地作品带 key 与音轨', Boolean(localWork?.key) && (localWork?.files?.length ?? 0) > 0, localWork?.name)
  // 音轨条目不该带绝对路径 ── 前端只用 key+index 取流，路径留在 host 侧。
  // （roots[].path 是「扫描的根目录」，那是要显示给用户看的，不算泄露。）
  const fileKeys = Object.keys(localWork?.files?.[0] ?? {})
  check('本地音轨不回绝对路径', fileKeys.includes('path') === false, fileKeys.join(',') || '(无音轨)')

  if (localWork) {
    const streamUrl = `${base}/asmrone/local-stream?key=${encodeURIComponent(localWork.key)}&index=1`

    // 用 HEAD：整文件可能是几百 MB 的 WAV，真拉下来只会把自检拖死。
    const head = await fetch(streamUrl, { method: 'HEAD' })
    check('HEAD /local-stream 可播', head.status === 200 && head.headers.get('accept-ranges') === 'bytes',
      `${head.headers.get('content-type')} · ${head.headers.get('content-length')}B`)
    check('本地流 Content-Type 是音频', /^audio\//.test(head.headers.get('content-type') ?? ''),
      head.headers.get('content-type'))

    const partial = await fetch(streamUrl, { headers: { range: 'bytes=0-1023' } })
    const chunk = Buffer.from(await partial.arrayBuffer())
    check('GET /local-stream (Range) 206', partial.status === 206, partial.headers.get('content-range'))
    check('Range 回满 1024 字节', chunk.length === 1024, `${chunk.length}B`)

    const outOfRange = await fetch(streamUrl, { headers: { range: 'bytes=999999999-' } })
    check('越界 Range 回 416', outOfRange.status === 416, String(outOfRange.status))

    // 目录穿越：非音频扩展名在进入文件系统之前就该被挡下
    const escape = await getJson('/asmrone/local-stream?path=' + encodeURIComponent('/etc/hosts'))
    check('本地流挡住库外路径', escape.status === 403, String(escape.status))

    const byBadKey = await getJson('/asmrone/local-stream?key=' + encodeURIComponent('不存在的key') + '&index=1')
    check('本地流未知作品回 404', byBadKey.status === 404, String(byBadKey.status))

    const queuedLocal = await postPlay({ localKey: localWork.key, index: 1 })
    check('POST /play 能推本地文件',
      queuedLocal.status === 200 && /^\/asmrone\/local-stream/.test(queuedLocal.body?.item?.stream ?? ''),
      queuedLocal.body?.item?.stream)
  }

  // id 校验发生在 api.tracks 之前，所以这条不依赖网络 —— 出口不通时也能验。
  const badId = await postPlay({ id: '' })
  check('POST /play 空 id 返回 400', badId.status === 400, String(badId.status))

  if (hash !== undefined) {
    const queued = await postPlay({ id: '1006912', hash })
    check('POST /play 入队', queued.status === 200 && queued.body?.item?.seq > 0,
      (queued.body?.item?.title ?? '').slice(0, 40))
    check('待播自带流地址',
      typeof queued.body?.item?.stream === 'string' && queued.body.item.stream.startsWith('/asmrone/stream?hash='),
      queued.body?.item?.stream)

    const taken = await getJson('/asmrone/pending?since=0')
    check('GET /pending 取到刚推的', taken.body?.item?.hash === hash, `seq ${taken.body?.seq}`)

    const again = await getJson(`/asmrone/pending?since=${taken.body?.seq}`)
    check('带上 seq 不再重复投递', again.body?.item === null, `seq ${again.body?.seq}`)

    const outOfRange = await postPlay({ id: '1006912', index: 9999 })
    check('POST /play 越界轨返回 404', outOfRange.status === 404, String(outOfRange.status))
  }

  // ── 删除：空 targets 必须被挡住（这一组不依赖网络） ──
  const delEmpty = await postJson('/asmrone/local/delete', { targets: [] })
  check('POST /local/delete 空 targets 回 400', delEmpty.status === 400, String(delEmpty.status))

  // ── B 站音源：本地校验部分 ──
  const biliBlank = await getJson('/asmrone/bili/search?q=')
  check('GET /bili/search 空关键词不报错', biliBlank.status === 200 && biliBlank.body?.ok === true, `total ${biliBlank.body?.total}`)

  const biliBad = await getJson('/asmrone/bili-stream?bvid=&cid=0')
  check('GET /bili-stream 缺参数回 400', biliBad.status === 400, String(biliBad.status))

  // ── DLsite 试听：没打开就要如实 409，不能假装能播 ──
  const trialClosed = await getJson('/asmrone/trial-stream?rj=RJ01650453&index=1')
  check('GET /trial-stream 未打开回 409', trialClosed.status === 409, String(trialClosed.status))

  const trialBadRj = await postJson('/asmrone/trial/open', { rj: '' })
  check('POST /trial/open 空 RJ 回 400', trialBadRj.status === 400, String(trialBadRj.status))

  // 注意：save 对「还没打开的 RJ」现在会**自动拉一次试听包**（下载档的上限比在线听宽），
  // 所以「未打开」不再是失败预期。别把这里改回真 RJ —— 那样每跑一次 verify
  // 都会真下十几 MB 并往本地曲库塞一份试听。用必然失败的入参验参数校验那条路。
  const trialSaveBadRj = await postJson('/asmrone/trial/save', { rj: '不是RJ号' })
  check('POST /trial/save 非法 RJ 回 400', trialSaveBadRj.status === 400, String(trialSaveBadRj.status))
} finally {
  server.close()
}

if (failures.length > 0) {
  console.error(`\n✗ ${failures.length} 项未过：${failures.join('、')}`)
  process.exit(1)
}
console.log('\n✓ 全部通过')
