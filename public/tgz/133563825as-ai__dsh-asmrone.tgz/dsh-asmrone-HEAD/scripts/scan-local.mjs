/**
 * 打印本地音声库的扫描结果（排查 / 巡检用）。
 *
 * 跑：`node scripts/scan-local.mjs`
 *
 * 面板里的「本地」标签页与 `asmr_local` 工具走的都是同一套 `LocalLibrary`，
 * 所以这里打印出来的就是它们认到的东西 —— 数字对不上时先看这里。
 */

import { LocalLibrary } from '../src/local.js'
import { AsmrStore } from '../src/store.js'

const store = new AsmrStore({})
const library = new LocalLibrary({ store })
const snapshot = library.scan({ force: true })

console.log('根目录：')
for (const root of snapshot.roots) {
  const mark = root.exists ? (root.isDirectory ? '✓' : '✗ 不是目录') : '✗ 不存在'
  console.log(`  ${mark}  ${root.path}`)
  console.log(`       ${root.works} 部 · ${root.files} 个文件 · ${root.sizeText}`)
}

console.log(`\n合计 ${snapshot.totals.works} 部 · ${snapshot.totals.files} 个文件 · ${snapshot.totals.sizeText}\n`)

const keyword = process.argv[2] ?? ''
const works = keyword === '' ? snapshot.works : library.find(keyword)
if (keyword !== '') console.log(`（已按「${keyword}」过滤：${works.length} 部）\n`)

for (const work of works) {
  const meta = [
    work.rj === '' ? '' : `RJ${work.rj}`,
    work.trial ? '试听' : '',
    work.source === 'download' ? '下载' : '外部库'
  ].filter(Boolean).join(' / ')
  console.log(`【${work.name}】 ${work.count} 轨 · ${work.sizeText}${meta === '' ? '' : `　(${meta})`}`)
  for (const [index, file] of work.files.entries()) {
    console.log(`   ${String(index + 1).padStart(2)}. ${file.name}　${file.sizeText}`)
  }
}
