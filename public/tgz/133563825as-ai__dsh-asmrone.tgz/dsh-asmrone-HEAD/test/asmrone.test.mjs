/**
 * dsh-asmrone 测试。
 *
 * 分两类：
 * - **离线**：zip 读取、工具 schema 编译、文件名清洗 —— 任何时候都能跑。
 * - **在线**：真打 asmr.one 与 DLsite。网络不通时自动跳过，不让 CI 因外网变红。
 *
 * 跑：`npm test`
 */

import { test } from 'node:test'
import assert from 'node:assert/strict'
import { existsSync, readFileSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
import { deflateRawSync } from 'node:zlib'

import { AsmrOneApi, flattenAudio, formatDuration, isFemaleOriented, summarizeWork } from '../src/api.js'
import { DlsiteTrialClient, normalizeWorkno, readZip } from '../src/dlsite.js'
import { AsmrStore } from '../src/store.js'
import { compileParameters, defineTool, validateArgs } from '../src/define-tool.js'
import { safeName } from '../src/tools/download.js'

/** 手工拼一个只有 store + deflate 两种条目的 zip，验证读取器。 */
function buildZip (entries) {
  const locals = []
  const centrals = []
  let offset = 0

  for (const entry of entries) {
    const nameBytes = Buffer.from(entry.name, 'utf8')
    const method = entry.deflate === true ? 8 : 0
    const payload = entry.deflate === true ? deflateRawSync(entry.data) : entry.data

    const local = Buffer.alloc(30)
    local.writeUInt32LE(0x04034b50, 0)
    local.writeUInt16LE(20, 4)
    local.writeUInt16LE(0x800, 6) // UTF-8 flag
    local.writeUInt16LE(method, 8)
    local.writeUInt32LE(payload.length, 18)
    local.writeUInt32LE(entry.data.length, 22)
    local.writeUInt16LE(nameBytes.length, 26)
    locals.push(local, nameBytes, payload)

    const central = Buffer.alloc(46)
    central.writeUInt32LE(0x02014b50, 0)
    central.writeUInt16LE(20, 4)
    central.writeUInt16LE(20, 6)
    central.writeUInt16LE(0x800, 8)
    central.writeUInt16LE(method, 10)
    central.writeUInt32LE(payload.length, 20)
    central.writeUInt32LE(entry.data.length, 24)
    central.writeUInt16LE(nameBytes.length, 28)
    central.writeUInt32LE(offset, 42)
    centrals.push(central, nameBytes)

    offset += 30 + nameBytes.length + payload.length
  }

  const centralBuf = Buffer.concat(centrals)
  const eocd = Buffer.alloc(22)
  eocd.writeUInt32LE(0x06054b50, 0)
  eocd.writeUInt16LE(entries.length, 8)
  eocd.writeUInt16LE(entries.length, 10)
  eocd.writeUInt32LE(centralBuf.length, 12)
  eocd.writeUInt32LE(offset, 16)

  return Buffer.concat([...locals, centralBuf, eocd])
}

test('zip 读取器：store 与 deflate 两种条目都能解', () => {
  const zip = buildZip([
    { name: 'a/01_track.mp3', data: Buffer.from('hello asmr'), deflate: false },
    { name: 'a/02_track.mp3', data: Buffer.from('x'.repeat(5000)), deflate: true }
  ])
  const files = readZip(zip)
  assert.equal(files.length, 2)
  assert.equal(files[0].name, 'a/01_track.mp3')
  assert.equal(files[0].data.toString(), 'hello asmr')
  assert.equal(files[1].data.length, 5000)
})

test('zip 读取器：Shift-JIS 文件名在没有 UTF-8 flag 时能还原', () => {
  // 「作品」的 Shift-JIS 字节
  const sjis = Buffer.from([0x8d, 0xec, 0x95, 0x69])
  const nameBytes = Buffer.concat([sjis, Buffer.from('_01.mp3')])
  const payload = Buffer.from('data')
  const local = Buffer.alloc(30)
  local.writeUInt32LE(0x04034b50, 0)
  local.writeUInt16LE(0, 6) // 不置 UTF-8 flag
  local.writeUInt16LE(0, 8)
  local.writeUInt32LE(payload.length, 18)
  local.writeUInt32LE(payload.length, 22)
  local.writeUInt16LE(nameBytes.length, 26)
  const central = Buffer.alloc(46)
  central.writeUInt32LE(0x02014b50, 0)
  central.writeUInt16LE(0, 8)
  central.writeUInt16LE(0, 10)
  central.writeUInt32LE(payload.length, 20)
  central.writeUInt32LE(payload.length, 24)
  central.writeUInt16LE(nameBytes.length, 28)
  const eocd = Buffer.alloc(22)
  eocd.writeUInt32LE(0x06054b50, 0)
  eocd.writeUInt16LE(1, 8)
  eocd.writeUInt16LE(1, 10)
  eocd.writeUInt32LE(46 + nameBytes.length, 12)
  eocd.writeUInt32LE(30 + nameBytes.length + payload.length, 16)

  const files = readZip(Buffer.concat([local, nameBytes, payload, central, nameBytes, eocd]))
  assert.equal(files.length, 1)
  assert.equal(files[0].name, '作品_01.mp3')
})

test('RJ 号归一化接受各种写法', () => {
  assert.equal(normalizeWorkno('RJ01726233'), 'RJ01726233')
  assert.equal(normalizeWorkno('rj1726233'), 'RJ01726233')
  assert.equal(normalizeWorkno('1726233'), 'RJ01726233')
  assert.throws(() => normalizeWorkno('abc'))
})

test('时长格式化', () => {
  assert.equal(formatDuration(45), '45s')
  assert.equal(formatDuration(300), '5m')
  assert.equal(formatDuration(4980), '1h23m')
  assert.equal(formatDuration(0), '0s')
})

test('音轨树拍平只留音频节点，路径带层级', () => {
  const tree = [
    { type: 'folder', title: '01_通常', children: [
      { type: 'folder', title: 'MP3', children: [
        { type: 'audio', title: 'a.mp3', hash: '1/2001' },
        { type: 'audio', title: 'b.mp3', hash: '1/2002' }
      ] }
    ] },
    { type: 'audio', title: 'cover.mp3', hash: '1/2003' }
  ]
  const flat = flattenAudio(tree)
  assert.equal(flat.length, 3)
  assert.equal(flat[0].hash, '1/2001')
  assert.equal(flat[0].path, '01_通常/MP3/a.mp3')
  assert.equal(flat[2].path, 'cover.mp3')
})

test('作品摘要只带模型需要的字段', () => {
  const work = {
    id: 1,
    title: 't',
    name: 'circle',
    dl_count: 100,
    duration: 3600,
    rate_average_2dp: 4.9,
    rate_count: 10,
    release: '2026-01-01',
    has_subtitle: true,
    nsfw: true,
    vas: [{ name: 'CV-A' }, { name: 'CV-B' }],
    tags: [{ id: 500, name: '舔耳', i18n: { 'zh-cn': { name: '舔耳' } } }]
  }
  const summary = summarizeWork(work, (id) => `https://asmr.one/work/${id}`)
  assert.equal(summary.durationText, '1h00m')
  assert.deepEqual(summary.voiceActors, ['CV-A', 'CV-B'])
  assert.deepEqual(summary.tags, ['舔耳'])
  assert.equal(summary.url, 'https://asmr.one/work/1')
  assert.equal(summary.rawTitle, undefined)
})

test('女性向标记能识出来', () => {
  assert.equal(isFemaleOriented({ tags: [{ id: 491 }] }), true)
  assert.equal(isFemaleOriented({ tags: [{ id: 10001 }] }), true)
  assert.equal(isFemaleOriented({ tags: [{ id: 37 }] }), true)
  assert.equal(isFemaleOriented({ tags: [{ id: 500 }] }), false)
  assert.equal(isFemaleOriented({}), false)
})

test('文件名清洗挡住路径分隔与保留字符', () => {
  assert.equal(safeName('01/02:03*04?.mp3'), '01_02_03_04_.mp3')
  assert.equal(safeName('   '), 'untitled')
  assert.equal(safeName('a'.repeat(300)).length, 120)
})

test('defineTool 编译 schema 并挡下非法入参', async () => {
  const tool = defineTool({
    name: 'demo',
    description: 'd',
    parameters: {
      mode: { type: 'string', enum: ['a', 'b'], required: true },
      count: { type: 'integer' }
    },
    output: { schema: { type: 'object' }, render: () => 'ok' },
    execute: async () => ({ done: true })
  })
  assert.equal(tool.parameters.type, 'object')
  assert.deepEqual(tool.parameters.required, ['mode'])
  await assert.rejects(() => tool.execute({}, {}), /"mode" is required/)
  await assert.rejects(() => tool.execute({ mode: 'z' }, {}), /must be one of/)
  await assert.rejects(() => tool.execute({ mode: 'a', count: 1.5 }, {}), /must be integer/)
  const value = await tool.execute({ mode: 'a' }, {})
  assert.equal(value.done, true)
})

test('参数 DSL 拒绝写错的键', () => {
  assert.throws(() => compileParameters({ x: { type: 'string', require: true } }), /不是支持的键/)
})

// 回归：曾把 output.schema 写成 { type: 'json' }，dsh-tools 在 register 时直接抛
// JsonSchemaError，整条插件 `entry did not activate` —— 面板 404、工具 unknown。
// 这里把十个工具的 definition 全过一遍，任何非法的 schema.type 都要当场炸出来。
test('十个工具的 schema 类型全部合法（防 entry did not activate）', async () => {
  const LEGAL = new Set(['object', 'array', 'string', 'number', 'integer', 'boolean', 'null'])
  const tools = []
  const runEffect = (fn) => {
    const result = fn()
    if (result && typeof result.next === 'function') while (!result.next().done) { /* 跑干 */ }
    return result
  }
  const { apply } = await import('../src/index.js')
  apply({
    logger: { info: () => {} },
    tools: { register: (tool) => tools.push(tool) },
    effect: runEffect,
    inject: (names, callback) => {
      if (names.includes('webServer')) {
        callback({ webServer: { register: () => () => {} }, effect: runEffect })
      }
    }
  }, {})

  // 断言名字集合而不是数量：加了工具忘记改这里会当场炸，比脆弱的 `length === 6` 有用。
  const EXPECTED = [
    'asmr_config', 'asmr_delete', 'asmr_download', 'asmr_local', 'asmr_play', 'asmr_search', 'asmr_trial', 'asmr_work',
    'bili_play', 'bili_search'
  ]
  assert.deepEqual(tools.map((tool) => tool.name).sort(), EXPECTED, '十个工具都应注册成功')

  const offenders = []
  const walk = (node, path) => {
    if (node === null || typeof node !== 'object') return
    if (Array.isArray(node)) {
      node.forEach((item, index) => walk(item, `${path}[${index}]`))
      return
    }
    if (node.type !== undefined && !LEGAL.has(node.type)) {
      offenders.push(`${path}.type = ${JSON.stringify(node.type)}`)
    }
    for (const [key, value] of Object.entries(node)) walk(value, `${path}.${key}`)
  }
  for (const tool of tools) {
    walk(tool.parameters, `${tool.name}.parameters`)
    walk(tool.output?.schema, `${tool.name}.output.schema`)
  }
  assert.deepEqual(offenders, [], `非法 JSON Schema 类型：${offenders.join('；')}`)

  // render 必须吐内容块数组（宿主侧 `content.some(...)` 消费），且拿到空值也不能抛
  for (const tool of tools) {
    for (const probe of [null, {}, { error: 'x' }]) {
      const rendered = tool.output.render({}, probe)
      assert.ok(Array.isArray(rendered), `${tool.name}.render 应返回数组（probe=${JSON.stringify(probe)}）`)
      for (const block of rendered) assert.equal(block.type, 'text', `${tool.name}.render 块类型`)
    }
  }
})

test('配置读写：白名单外的键被丢弃，坏 JSON 退回默认', () => {
  const root = join('/tmp', `asmrone-test-${process.pid}`)
  const store = new AsmrStore({ ctx: null, config: {}, dataRoot: root })
  const before = store.get()
  assert.equal(before.languageFilter, 'male')

  store.set({ languageFilter: 'all', pageSize: 33, evilKey: 'boom' })
  const after = store.get()
  assert.equal(after.languageFilter, 'all')
  assert.equal(after.pageSize, 33)
  assert.equal(after.evilKey, undefined)

  // 写坏再读，应退回默认而不是抛错
  writeFileSync(join(root, 'config.json'), '{ not json', 'utf8')
  const recovered = new AsmrStore({ ctx: null, config: {}, dataRoot: root })
  assert.equal(recovered.get().languageFilter, 'male')
})

test('配置越界值被夹回安全区间', () => {
  const root = join('/tmp', `asmrone-clamp-${process.pid}`)
  const store = new AsmrStore({ ctx: null, config: { downloadConcurrency: 99, pageSize: 99999 }, dataRoot: root })
  const config = store.get()
  assert.equal(config.downloadConcurrency, 8)
  assert.equal(config.pageSize, 100)
})

// ─────────────────────────── 在线用例 ───────────────────────────
//
// 网络抖动是常态（代理线路会断），但**绝不能把失败伪装成通过**：
// 这里一律用 `t.skip()` 显式标记跳过，跑完能从 "skipped" 计数里看出真实情况。
// 真出现断言失败仍然照常 fail。

const OFFLINE_PATTERN = /fetch failed|ECONNRESET|ECONNREFUSED|ENOTFOUND|EAI_AGAIN|ETIMEDOUT|timeout|abort|socket hang up/i

function isNetworkError (error) {
  return OFFLINE_PATTERN.test(`${error?.message ?? ''} ${error?.cause?.message ?? ''}`)
}

function asmrOneApi () {
  return new AsmrOneApi({
    apiBaseUrl: 'https://api.asmr.one',
    siteBaseUrl: 'https://asmr.one',
    dlsiteTrialBaseUrl: 'https://trial.dlsite.com',
    timeoutMs: 30000
  })
}

test('在线：搜索返回结构化作品', async (t) => {
  try {
    const result = await asmrOneApi().search({ query: '简体中文版', page: 1, pageSize: 5, order: 'dl_count' })
    assert.ok(result.total > 0, '应命中简中作品')
    assert.ok(result.works.length > 0)
    assert.equal(typeof result.works[0].title, 'string')
    assert.ok(result.works[0].id > 0)
  } catch (error) {
    if (isNetworkError(error)) return t.skip(`网络不可达：${error.message}`)
    throw error
  }
})

test('在线：音轨树能取到音频节点', async (t) => {
  try {
    const tree = await asmrOneApi().tracks('1006912')
    const flat = flattenAudio(tree)
    assert.ok(flat.length > 0, '应有音轨')
    assert.ok(flat[0].hash.includes('/'))
  } catch (error) {
    if (isNetworkError(error)) return t.skip(`网络不可达：${error.message}`)
    throw error
  }
})

test('在线：DLsite 试听 zip 能被分段读（中央目录 + 单条 inflate）', async (t) => {
  const client = new DlsiteTrialClient({ trialBaseUrl: 'https://trial.dlsite.com', timeoutMs: 60000 })
  let info
  try {
    info = await client.workInfo('RJ01726233')
  } catch (error) {
    if (isNetworkError(error)) return t.skip(`网络不可达：${error.message}`)
    throw error
  }
  assert.equal(info.workno, 'RJ01726233')
  assert.ok(info.title.length > 0)
  if (info.trials.length === 0) return t.skip('该作品当前没有试听包')

  // 测线上真正走的那条路：只拉尾部拿中央目录，再按偏移取**一个最小的条目**。
  // 不拉整包、也不拉整轨 —— 单测不该为验证一条链路去下几十上百 MB。
  let zip
  try {
    zip = await client.openZip(info.trials[0].url)
  } catch (error) {
    if (isNetworkError(error)) return t.skip(`网络不可达：${error.message}`)
    throw error
  }
  assert.ok(zip.entries.length > 0, '中央目录要能解出条目')
  assert.ok(zip.totalSize > 1000, `zip 总长看起来不对：${zip.totalSize}`)

  const smallest = zip.entries
    .filter((item) => !item.name.endsWith('/') && item.compressedSize > 0)
    .sort((left, right) => left.compressedSize - right.compressedSize)[0]
  if (smallest === undefined) return t.skip('这个包里没有可取的文件条目')

  let data
  try {
    data = await zip.read(smallest)
  } catch (error) {
    if (isNetworkError(error)) return t.skip(`网络不可达：${error.message}`)
    throw error
  }
  assert.equal(data.length, smallest.uncompressedSize,
    `取回的字节数要与中央目录一致（${smallest.name}）`)
})

test('离线回归：本地已缓存的试听 zip 能被读取器解开', { skip: !existsSync('/tmp/trial/t1.zip') }, () => {
  const files = readZip(readFileSync('/tmp/trial/t1.zip'))
  assert.ok(files.length >= 2)
  assert.ok(files.some((file) => /サンプル/.test(file.name)), 'Shift-JIS 文件名应被正确还原')
  assert.ok(files.some((file) => file.name.endsWith('.mp3')))
})
