/**
 * rank-core 单测。
 *
 * 客户端逻辑跑不了 node（依赖 window / react），所以这里**从 client.js 里把
 * `#region rank-core` 那段纯函数原样截出来**再求值 —— 被测的就是线上那份代码，
 * 不存在「测试通过但线上是另一份实现」的漂移。
 *
 * 一旦有人把窗口调整/归一化公式改成不纯、或塞进外部引用，下面的取文本会直接
 * 抛错，而不是悄悄测到一份过期的复制品。
 */
import test from 'node:test'
import assert from 'node:assert/strict'
import { readFileSync } from 'node:fs'
import { fileURLToPath } from 'node:url'
import { dirname, join } from 'node:path'

const here = dirname(fileURLToPath(import.meta.url))
const CLIENT = join(here, '..', 'client', 'client.js')

function loadRankCore () {
  const source = readFileSync(CLIENT, 'utf8')
  const start = source.indexOf('//#region rank-core')
  const end = source.indexOf('//#endregion rank-core')
  assert.notEqual(start, -1, 'client.js 里找不到 //#region rank-core 标记')
  assert.notEqual(end, -1, 'client.js 里找不到 //#endregion rank-core 标记')
  assert.ok(end > start, 'rank-core 的起止标记顺序反了')
  const body = source.slice(start, end)

  const exports = [
    'RANK_KEYS', 'DEFAULT_WEIGHTS', 'PRESET_WEIGHTS', 'clampNumber',
    'sanitizeWeights', 'weightTotal', 'normalizeMetric', 'bayesRating',
    'metricValue', 'rankWorks', 'formatClock', 'chunk'
  ]
  // 纯函数区内不得出现 window / document / react —— 出现就是越界了。
  for (const banned of ['window.', 'document.', 'react.', 'require(']) {
    assert.equal(body.includes(banned), false, `rank-core 里出现了非纯引用：${banned}`)
  }
  return new Function(body + '\nreturn {' + exports.join(',') + '}')( )
}

const core = loadRankCore()

const work = (id, downloads, rating, ratingCount, release) => ({
  id, downloads, rating, ratingCount, release
})

/* ── formatClock ─────────────────────────────────────────────── */
test('formatClock：分/时进位正确，脏值不冒 NaN', () => {
  assert.equal(core.formatClock(0), '0:00')
  assert.equal(core.formatClock(9), '0:09')
  assert.equal(core.formatClock(65), '1:05')
  assert.equal(core.formatClock(600), '10:00')
  assert.equal(core.formatClock(3599), '59:59')
  assert.equal(core.formatClock(3600), '1:00:00')
  assert.equal(core.formatClock(3661), '1:01:01')
  assert.equal(core.formatClock(NaN), '0:00')
  assert.equal(core.formatClock(undefined), '0:00')
  assert.equal(core.formatClock(-5), '0:00')
  assert.equal(core.formatClock('abc'), '0:00')
})

/* ── 权重清洗 ─────────────────────────────────────────────────── */
test('sanitizeWeights：越界夹紧、缺字段补 0，永不产出 NaN', () => {
  assert.deepEqual(core.sanitizeWeights({ downloads: -3, rating: 99 }), {
    downloads: 0, rating: 2, ratingCount: 0, fresh: 0
  })
  assert.deepEqual(core.sanitizeWeights(undefined), core.DEFAULT_WEIGHTS)
  assert.deepEqual(core.sanitizeWeights({ downloads: 'x' }), core.DEFAULT_WEIGHTS)
  const cleaned = core.sanitizeWeights({ downloads: 1, rating: 0.55 })
  assert.equal(cleaned.downloads, 1)
  assert.equal(cleaned.rating, 0.55)
})

test('weightTotal：默认全 0 —— 不拖滑块就不介入官方排序', () => {
  assert.equal(core.weightTotal(core.DEFAULT_WEIGHTS), 0)
  assert.ok(Math.abs(core.weightTotal(core.PRESET_WEIGHTS) - 2.3) < 1e-9,
    '1 + 0.6 + 0.3 + 0.4 有浮点误差，别拿 === 比')
  assert.equal(core.weightTotal(undefined), 0)
})

/* ── 归一化 ───────────────────────────────────────────────────── */
test('normalizeMetric：拉满 0~1，全体相等时给中性的 0.5', () => {
  assert.deepEqual(core.normalizeMetric([0, 5, 10]), [0, 0.5, 1])
  assert.deepEqual(core.normalizeMetric([7, 7, 7]), [0.5, 0.5, 0.5])
  assert.deepEqual(core.normalizeMetric([3]), [0.5])
  assert.deepEqual(core.normalizeMetric([]), [])
  // 空值不能被当成 0 参与 min/max，否则整列会被一个脏数据压扁
  const withJunk = core.normalizeMetric([0, 10, NaN])
  assert.equal(withJunk[0], 0)
  assert.equal(withJunk[1], 1)
  assert.equal(withJunk[2], 0)
})

/* ── 贝叶斯评分 ───────────────────────────────────────────────── */
test('bayesRating：2 人打的 5.0 不该压过 800 人打的 4.6', () => {
  const fluke = core.bayesRating(work('a', 0, 5, 2))
  const solid = core.bayesRating(work('b', 0, 4.6, 800))
  assert.ok(solid > fluke, `期望 ${solid} > ${fluke}`)
})

test('bayesRating：无评分 / 无评价数都退回 0，不制造虚假好评', () => {
  assert.equal(core.bayesRating(work('a', 0, 0, 0)), 0)
  assert.equal(core.bayesRating(work('b', 0, 0, 500)), 0)
  assert.equal(core.bayesRating({}), 0)
  assert.equal(core.bayesRating(null), 0)
  // 有分无评价数：按纯先验处理，结果应低于先验本身
  const noCount = core.bayesRating(work('c', 0, 4.8, 0))
  assert.ok(noCount > 0 && noCount < 4.8)
})

/* ── metricValue ──────────────────────────────────────────────── */
test('metricValue：销量取数、评分走贝叶斯、新鲜度吃时间戳', () => {
  const row = work('a', 123, 4.5, 50, '2026-03-01T00:00:00Z')
  assert.equal(core.metricValue(row, 'downloads'), 123)
  assert.equal(core.metricValue(row, 'metricMissing'), 0)
  assert.ok(core.metricValue(row, 'rating') > 4.4)
  assert.equal(core.metricValue(row, 'fresh'), Date.parse('2026-03-01T00:00:00Z'))
  // 日期烂掉时给 0，而不是 NaN 顺着加权求和扩散
  assert.equal(core.metricValue(work('b', 0, 0, 0, '不是日期'), 'fresh'), 0)
})

/* ── rankWorks ────────────────────────────────────────────────── */
test('rankWorks：权重全 0 时原样返回，顺序与官方一致', () => {
  const list = [work('a', 1), work('b', 2), work('c', 3)]
  const out = core.rankWorks(list, core.DEFAULT_WEIGHTS)
  assert.deepEqual(out.map((w) => w.id), ['a', 'b', 'c'])
  assert.notEqual(out, list, '应当返回副本，别把调用方的数组交出去')
})

test('rankWorks：销量权重把高销量的顶到前面', () => {
  const list = [work('low', 10, 5, 100), work('high', 900, 4.2, 300), work('mid', 400, 4.5, 80)]
  const out = core.rankWorks(list, { downloads: 1 })
  assert.deepEqual(out.map((w) => w.id), ['high', 'mid', 'low'])
})

test('rankWorks：新鲜度权重看发售日，不看销量', () => {
  const list = [
    work('old', 9999, 5, 500, '2020-01-01T00:00:00Z'),
    work('new', 10, 3, 2, '2026-08-01T00:00:00Z')
  ]
  const out = core.rankWorks(list, { fresh: 1 })
  assert.equal(out[0].id, 'new')
})

test('rankWorks：权重等比放大不改变结果（内部归一），改比例才改结果', () => {
  const list = [work('a', 100, 5, 10), work('b', 50, 4.9, 400), work('c', 10, 4.0, 900)]
  const base = core.rankWorks(list, { downloads: 1, rating: 0.5 })
  const doubled = core.rankWorks(list, { downloads: 2, rating: 1 })
  assert.deepEqual(base.map((w) => w.id), doubled.map((w) => w.id))

  const salesHeavy = core.rankWorks(list, { downloads: 2, rating: 0.1 })
  const ratingHeavy = core.rankWorks(list, { downloads: 0.1, rating: 2 })
  assert.notDeepEqual(salesHeavy.map((w) => w.id), ratingHeavy.map((w) => w.id))
})

test('rankWorks：同分按销量兜底，输出稳定可复现', () => {
  const list = [work('a', 100), work('b', 500), work('c', 300)]
  const first = core.rankWorks(list, { downloads: 1 })
  const second = core.rankWorks(list.slice().reverse(), { downloads: 1 })
  assert.deepEqual(first.map((w) => w.id), second.map((w) => w.id))
  assert.deepEqual(first.map((w) => w.id), ['b', 'c', 'a'])
})

test('rankWorks：单条 / 空数组 / 脏输入都不炸', () => {
  assert.deepEqual(core.rankWorks([], { downloads: 1 }), [])
  assert.deepEqual(core.rankWorks(null, { downloads: 1 }), [])
  assert.equal(core.rankWorks([work('only', 1)], { downloads: 1 }).length, 1)
  assert.equal(core.rankWorks([work('a', NaN), work('b', undefined)], { downloads: 1 }).length, 2)
})

test('rankWorks：不修改入参对象（score 挂在新对象上）', () => {
  const list = [work('a', 1), work('b', 2)]
  const out = core.rankWorks(list, { downloads: 1 })
  assert.equal(Object.prototype.hasOwnProperty.call(list[0], 'score'), false)
  assert.equal(typeof out.find((w) => w.id === 'a').score, 'number')
})

test('rankWorks：打出的分数总在 0~1', () => {
  const list = [
    work('a', 0, 3.5, 1, '2019-01-01T00:00:00Z'),
    work('b', 5000, 5, 900, '2026-01-01T00:00:00Z'),
    work('c', 120, 4.4, 30, '2023-06-01T00:00:00Z')
  ]
  for (const row of core.rankWorks(list, core.PRESET_WEIGHTS)) {
    assert.ok(row.score >= 0 && row.score <= 1, `score 越界：${row.score}`)
  }
})

/* ── chunk（权重模式的本地翻页靠它）──────────────────────────── */
test('chunk：切页正确，空输入给一个空页而不是零页', () => {
  assert.deepEqual(core.chunk([1, 2, 3, 4, 5], 2), [[1, 2], [3, 4], [5]])
  assert.deepEqual(core.chunk([], 20), [[]])
  assert.deepEqual(core.chunk([1, 2], 0), [[1], [2]])
})

/* ── 客户端接线检查 ──────────────────────────────────────────── */
test('client.js 接线：audio 常驻、无新窗口、进度条可 seek', () => {
  const raw = readFileSync(CLIENT, 'utf8')
  // 结构断言必须跑在「剥掉注释」的源码上：文件头的注释里正解释着旧写法，
  // 拿原文 includes 会误报（注释里就写着 `if (!state.open) return null`）。
  const source = raw
    .replace(/\/\*[\s\S]*?\*\//g, '')
    .replace(/^[ \t]*\/\/.*$/gm, '')

  // 播放器不能再被 `if (!state.open) return null` 连坐卸载
  assert.equal(/if \(!state\.open\) return null/.test(source), false,
    '找到了 `if (!state.open) return null` —— 会把 <audio> 一起卸载，后台播放就断了')
  assert.ok(source.includes("state.open ? dialog : null"),
    '面板应当条件渲染，而 audio 常驻在 Fragment 里')

  // audio 必须脱离 React 树，否则容器重建就断播
  assert.ok(source.includes('document.body.appendChild(audio)'),
    'audio 应当挂到 document.body 上，而不是当 React 子节点渲染')
  assert.equal(/h\('audio'/.test(source), false,
    '还有 h(\'audio\', ...) —— 那是 React 元素，会被容器卸载连带拆掉')
  // 卸载清理里不得真的移除 audio —— 移除了就等于「容器一卸载就断播」
  const cleanupAt = source.indexOf('audio.removeEventListener')
  assert.notEqual(cleanupAt, -1, '找不到 audio 的事件解绑段')
  const cleanup = source.slice(cleanupAt, cleanupAt + 2500)
  assert.equal(/\baudio\.remove\(\)|removeChild\(audio\)/.test(cleanup), false,
    '卸载清理里移除了 audio 元素，容器重建就断播')

  // 藏 audio 不能用 display:none
  assert.equal(/position:\s*'fixed'[\s\S]{0,200}display:\s*'none'/.test(source), false,
    'audio 用了 display:none 藏，部分 WebView 会直接停播')

  // 「新窗口打开」已按要求合并掉
  assert.equal(source.includes('新窗口打开'), false, '「新窗口打开」应当已经删掉')
  assert.equal(source.includes('target: \'_blank\''), false, '还有开新窗口的链接')

  // 进度可调
  assert.ok(source.includes('asmrone-progress'), '缺进度条')
  assert.ok(source.includes('audio.currentTime = value'), '进度条没有真正 seek')

  // 悬浮球：可自由拖动、位置持久化、展开后自动缩回
  assert.ok(source.includes('asmrone-fab'), '缺悬浮球（缩回态）')
  assert.ok(source.includes('setPointerCapture'), '悬浮球没有拖动实现')
  assert.ok(source.includes('LS_FAB'), '悬浮球位置没有持久化')
  assert.ok(source.includes('clampFabPos'), '缺边界限制 —— 球会被拖出屏幕')
  assert.ok(/miniExpanded: false \}\)\s*,\s*2800\)/.test(source), '缺 2.8 秒自动缩回')

  // 拖动进度时必须置 scrubbing，否则 200ms 的轮询会把滑块拽回去
  assert.ok(/setState\(\{ scrubbing: true/.test(source), '拖动进度没有锁 scrubbing')

  // 后台播放的系统控制
  assert.ok(source.includes('mediaSession'), '缺 MediaSession（锁屏/通知栏控制）')
})

test('client.js 接线：循环与定时（助眠要的那两个开关）', () => {
  const source = readFileSync(CLIENT, 'utf8')
    .replace(/\/\*[\s\S]*?\*\//g, '')
    .replace(/^[ \t]*\/\/.*$/gm, '')

  // 循环三态：单轨与整部互斥，合成一个布尔就分不清用户要哪个
  assert.match(source, /const LOOP_MODES = \['off', 'one', 'all'\]/, '缺循环三态')
  assert.match(source, /const SLEEP_STEPS = \[0, 15, 30, 60, 90\]/, '缺定时档位')

  // 单轨循环交给 audio.loop —— 它设成 true 时 ended 不触发，正好与「整部」互斥
  assert.ok(/audio\.loop = singleton\.loopMode === 'one'/.test(source),
    '单轨循环该用 audio.loop，而不是在 ended 里自己重播')
  // 整部循环走 ended → 下一轨
  const endedAt = source.indexOf('const onEnded = () =>')
  assert.notEqual(endedAt, -1, '找不到 onEnded')
  assert.match(source.slice(endedAt, endedAt + 400), /singleton\.loopMode === 'all' && playNextInList\(\)/,
    'onEnded 里没有接「整部循环 → 下一轨」')

  // 四个播放点都要记下「这一批轨是什么」，否则整部循环无轨可续。
  // 数量是硬断言：以后再加播放路径时，这条会提醒你把它一起接上。
  assert.equal((source.match(/\.\.\.playlistOf\(/g) ?? []).length, 4,
    'playlistOf 应当出现在在线音轨 / B站分P / 本地文件 / 试听轨这四处')
  for (const anchor of ['work.tracks', 'state.tracks', 'work.files', 'pages']) {
    assert.ok(source.includes(`...playlistOf(${anchor}`), `少了 ${anchor} 这条播放路径的列表`)
  }

  // B 站那条的坑：卡片上的播放键刚 setState 完就调 playBili，
  // 不显式传 pages 就会拿到旧闭包值 → 列表为空 → 整部循环在这条最常用的路上失效
  assert.ok(/const playBili = \(work, pageNo, cid, pagesArg\)/.test(source),
    'playBili 要能接受显式传入的分 P 列表')
  assert.ok(/playBili\(work, first\.page, first\.cid, pages\)/.test(source),
    'playBiliDirect 必须把刚拉到的 pages 传进去')

  // 定时用截止时间戳对表，而不是递减计数 —— WebView 切后台会把定时器降频甚至冻结
  assert.match(source, /singleton\.sleepEndAt - Date\.now\(\)\) \/ 1000/, '定时应当对时间戳')
  assert.ok(source.includes('setInterval(tick, 1000)'), '定时缺每秒 tick')
  assert.ok(source.includes('sleepDone'), '定时到点没有给一句交代')

  // 两个开关在面板底栏和悬浮条上都要有 —— 助眠时面板多半是关着的，
  // 只放面板里等于让人睡前还得先开一次面板
  assert.ok(source.includes("t({ off: 'loopOff', one: 'loopOne', all: 'loopAll' }"), '缺循环按钮的文案映射')
  assert.equal((source.match(/onClick: cycleLoop/g) ?? []).length, 2, '循环按钮该面板与悬浮条各一个')
  assert.equal((source.match(/onClick: cycleSleep/g) ?? []).length, 2, '定时按钮该面板与悬浮条各一个')

  // 停播要连带丢掉循环上下文，免得下次起播拿一份过期的列表续播
  assert.ok((source.match(/playList: \[\], playIndex: -1/g) ?? []).length >= 2, '停播处要清循环上下文')
})
