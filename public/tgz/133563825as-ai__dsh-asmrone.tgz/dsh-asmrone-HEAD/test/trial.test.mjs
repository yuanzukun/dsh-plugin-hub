/**
 * 内存试听库的测试。
 *
 * 全程**不联网** —— 用一个假的 dlsite 客户端喂数据。真链路（DNS 补丁 + 真 zip）
 * 在 `trial-e2e` 那种一次性脚本里验，这里只钉行为：
 * 体积闸门、LRU、切片边界、落盘，以及「没有试听包」这种正常情况要报得有区别。
 */

import assert from 'node:assert/strict'
import { existsSync, mkdtempSync, readFileSync, readdirSync, rmSync, statSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { dirname, join } from 'node:path'
import test from 'node:test'
import { fileURLToPath } from 'node:url'

import { RemoteZip } from '../src/dlsite.js'
import { isDlsiteHost } from '../src/doh.js'
import { withTrialReason } from '../src/http.js'
import { TrialLibrary } from '../src/trial.js'

const here = dirname(fileURLToPath(import.meta.url))
const CLIENT = join(here, '..', 'client', 'client.js')

/** 造一个音频 Buffer：内容不重要，长度要能对上。 */
const audio = (bytes, fill = 0x41) => Buffer.alloc(bytes, fill)

/**
 * 手工拼一个最小 zip（store 模式，不压缩）。
 *
 * 为什么要真字节而不是 mock：`RemoteZip` 里最容易错的就是解析 —— EOCD 定位、
 * 中央目录偏移、本地头里那两个变长字段、再到数据段起点的换算。喂它一个假对象
 * 等于把这部分整个跳过。CRC 一律填 0，因为读取器不校验它，只认签名和长度。
 */
function makeZip (files) {
  const parts = []
  const centrals = []
  let offset = 0

  for (const file of files) {
    const name = Buffer.from(file.name, 'utf8')
    const data = file.data
    const local = Buffer.alloc(30 + name.length)
    local.writeUInt32LE(0x04034b50, 0)
    local.writeUInt16LE(20, 4)
    local.writeUInt16LE(0x800, 6) // flags bit 11：文件名是 UTF-8
    local.writeUInt32LE(data.length, 18)
    local.writeUInt32LE(data.length, 22)
    local.writeUInt16LE(name.length, 26)
    name.copy(local, 30)
    parts.push(local, data)

    const central = Buffer.alloc(46 + name.length)
    central.writeUInt32LE(0x02014b50, 0)
    central.writeUInt16LE(0x800, 8)
    central.writeUInt32LE(data.length, 20) // compressedSize
    central.writeUInt32LE(data.length, 24) // uncompressedSize
    central.writeUInt16LE(name.length, 28)
    central.writeUInt32LE(offset, 42) // localHeaderOffset
    name.copy(central, 46)
    centrals.push(central)

    offset += local.length + data.length
  }

  const cd = Buffer.concat(centrals)
  const eocd = Buffer.alloc(22)
  eocd.writeUInt32LE(0x06054b50, 0)
  eocd.writeUInt16LE(files.length, 8)
  eocd.writeUInt16LE(files.length, 10)
  eocd.writeUInt32LE(cd.length, 12)
  eocd.writeUInt32LE(offset, 16)
  return Buffer.concat([...parts, cd, eocd])
}

/**
 * 把内存里的 zip 伪装成一个支持 Range 的远端 —— 于是测试跑的是**线上那份
 * `RemoteZip`**，而不是它的替身。`calls` 记下每次请求的区间，可以据此断言
 * 「打开时只拉了一次尾部」「只取了要播的那一轨」。
 */
function rangeFromBuffer (zip) {
  const calls = []
  const range = async (spec) => {
    calls.push(spec)
    let start
    let end
    if (spec.startsWith('-')) {
      start = Math.max(0, zip.length - Number(spec.slice(1)))
      end = zip.length - 1
    } else {
      const [from, to] = spec.split('-')
      start = Number(from)
      end = to === '' || to === undefined ? zip.length - 1 : Math.min(Number(to), zip.length - 1)
    }
    return { buffer: zip.subarray(start, end + 1), total: zip.length }
  }
  range.calls = calls
  return range
}

/**
 * 假客户端。`files` 决定包里有什么、多大；`trials` 那层由 `hasTrial` 控制。
 */
function fakeDlsite ({ files, sizeMb = 1, hasTrial = true, sizeText = '1.00MB' }) {
  const zip = makeZip(files ?? [])
  const range = rangeFromBuffer(zip)
  return {
    zip,
    range,
    calls: 0,
    async workInfo (workno) {
      return {
        workno: String(workno),
        title: `测试作品 ${workno}`,
        trials: hasTrial
          ? [{ url: `https://trial.dlsite.com/doujin/${workno}/${workno}_trial.zip`, sizeText, sizeMb }]
          : []
      }
    },
    async openZip () {
      this.calls += 1
      return RemoteZip.open(range)
    }
  }
}

test('open：过滤掉非音频、按文件名自然排序、缓存命中不重复拉取', async () => {
  const files = [
    { name: 'cover.jpg', data: audio(2048) },
    { name: 'sample_10_后段.mp3', data: audio(3000) },
    { name: 'sample_02_中段.mp3', data: audio(2000) },
    { name: 'sample_01_前段.mp3', data: audio(1000) },
    { name: 'readme.txt', data: audio(512) }
  ]
  const dlsite = fakeDlsite({ files })
  const trial = new TrialLibrary({ dlsite, maxMb: 10 })
  const entry = await trial.open('RJ00000001')

  assert.equal(entry.tracks.length, 3, '只留下音频')
  // 自然排序：sample_02 要排在 sample_10 前面，纯字符串比较做不到。
  assert.deepEqual(entry.tracks.map((track) => track.name), [
    'sample_01_前段.mp3',
    'sample_02_中段.mp3',
    'sample_10_后段.mp3'
  ])
  assert.deepEqual(entry.tracks.map((track) => track.index), [1, 2, 3], 'index 从 1 连续')
  assert.equal(entry.bytes, 6000)
  assert.equal(dlsite.calls, 1)
  // 打开这一下只该发一次请求 —— 拉尾部拿中央目录。内容留到真正播放时再取。
  assert.equal(dlsite.range.calls.length, 1, '打开时不该下载任何内容')
  assert.match(dlsite.range.calls[0], /^-\d+$/, '第一次请求应当是「最后 N 字节」')

  await trial.open('RJ00000001')
  assert.equal(dlsite.calls, 1, '第二次应当直接命中缓存，不再拉 zip')

  assert.equal(trial.stats.works, 1)
  assert.equal(trial.stats.tracks, 3)
  assert.equal(trial.stats.bytes, 0, '一轨都没播过，内存里不该有东西')
})

test('没有试听包是正常情况，要报得跟「出错」区分开', async () => {
  const dlsite = fakeDlsite({ files: [], hasTrial: false })
  const trial = new TrialLibrary({ dlsite })
  await assert.rejects(() => trial.open('RJ00000002'), /没有提供官方试听包/)
})

test('zip 体积超过上限时明确让人改走下载', async () => {
  const dlsite = fakeDlsite({ files: [{ name: 'a.mp3', data: audio(100) }], sizeMb: 300, sizeText: '300.00MB' })
  const trial = new TrialLibrary({ dlsite, maxMb: 100 })
  await assert.rejects(() => trial.open('RJ00000003'), /超过在线听的上限 100MB/)
})

test('单轨超限挡在物化那一刻，而不是打开那一刻', async () => {
  // 分段读之后「包大」不再是问题，但整轨还是得驻留才能切片 ——
  // 试听包里真出现过 131MB 的 wav，所以单轨那道闸门留着。
  const dlsite = fakeDlsite({
    files: [{ name: 'big.wav', data: audio(300 * 1024 * 1024) }],
    sizeMb: 300,
    sizeText: '300.00MB'
  })
  const trial = new TrialLibrary({ dlsite, maxMb: 800, maxTrackMb: 200 })

  // 打开必须是成功的：只读中央目录，300MB 的包也一样轻。
  const entry = await trial.open('RJ00000004')
  assert.equal(entry.tracks.length, 1)
  assert.equal(trial.stats.bytes, 0, '打开不该占内存')

  // 挡住的是真要把它读进内存的时候。
  await assert.rejects(() => trial.slice('RJ00000004', 1, 0, 10), /超过单轨内存上限 200MB/)
  assert.equal(trial.stats.bytes, 0, '被挡住就不该留下任何驻留')
})

test('试听包里一个音频都没有时要说清楚（有些作品只有图片试听）', async () => {
  const dlsite = fakeDlsite({ files: [{ name: 'a.jpg', data: audio(10) }, { name: 'b.png', data: audio(10) }] })
  const trial = new TrialLibrary({ dlsite })
  await assert.rejects(() => trial.open('RJ00000005'), /没有音频/)
})

test('slice：边界、越界、错轨都对，且整轨只物化一次', async () => {
  const dlsite = fakeDlsite({ files: [{ name: 'a.mp3', data: audio(10000) }] })
  const trial = new TrialLibrary({ dlsite })
  await trial.open('RJ00000006')

  const head = await trial.slice('RJ00000006', 1, 0, 1023)
  assert.equal(head.data.length, 1024)
  assert.equal(head.total, 10000)
  assert.equal(head.start, 0)
  assert.equal(head.end, 1023)

  // end 省略 = 到文件末尾
  const tail = await trial.slice('RJ00000006', 1, 9000)
  assert.equal(tail.data.length, 1000)
  assert.equal(tail.end, 9999)

  // end 超过总长会被夹回
  const clamp = await trial.slice('RJ00000006', 1, 9999, 999999)
  assert.equal(clamp.data.length, 1)

  assert.equal(await trial.slice('RJ00000006', 1, 10000, 10010), null, '起点越界回 null')
  assert.equal(await trial.slice('RJ00000006', 2, 0, 10), null, '不存在的轨回 null')
  assert.equal(await trial.slice('RJ99999999', 1, 0, 10), null, '没打开的作品回 null')

  // 切片是原 Buffer 的视图，不是副本 —— 大文件下这点很关键。
  // 两次调用共享同一个底层 ArrayBuffer，说明第二次没有再下一次。
  const again = await trial.slice('RJ00000006', 1, 0, 9)
  assert.equal(again.data.buffer, head.data.buffer, 'subarray 应当共享底层 ArrayBuffer')
  assert.equal(trial.stats.cachedTracks, 1, '整轨只该物化一次')

  // 一次物化 = 两次区间请求（30 字节本地头 + 数据段），加上打开时那次尾部请求。
  assert.equal(dlsite.range.calls.length, 3, `请求次数不对：${dlsite.range.calls.join(' | ')}`)
  assert.equal(trial.stats.bytes, 10000, '内存里只该有这一轨')
})

test('saveAll 落盘：文件名里的非法字符会被洗掉', async () => {
  const dir = mkdtempSync(join(tmpdir(), 'trial-test-'))
  const dlsite = fakeDlsite({
    files: [
      { name: 'sample_01_a/b:c*.mp3', data: audio(1024) },
      { name: 'sample_02_正常.mp3', data: audio(2048) }
    ]
  })
  const trial = new TrialLibrary({ dlsite })
  try {
    await trial.open('RJ00000007')
    const result = await trial.saveAll('RJ00000007', dir)

    assert.equal(result.saved, 2)
    assert.equal(result.total, 2)
    assert.equal(result.bytes, 3072)
    assert.deepEqual(result.failures, [])

    const written = readdirSync(dir).sort()
    assert.equal(written.length, 2)
    assert.equal(written.includes('sample_02_正常.mp3'), true)
    for (const name of written) assert.equal(/[/\\:*?"<>|]/.test(name), false, `文件名不该带非法字符：${name}`)

    const first = result.files.find((file) => file.index === 2)
    assert.equal(statSync(first.path).size, 2048)
    assert.equal(existsSync(first.path), true)
  } finally {
    rmSync(dir, { recursive: true, force: true })
  }
})

test('LRU：超过 maxWorks 就淘汰最老的，当前这部永远保住', async () => {
  const dlsite = fakeDlsite({ files: [{ name: 'a.mp3', data: audio(64) }] })
  const trial = new TrialLibrary({ dlsite, maxWorks: 2 })

  await trial.open('RJ00000011')
  await trial.open('RJ00000012')
  assert.equal(trial.stats.works, 2)

  await trial.open('RJ00000013')
  assert.equal(trial.stats.works, 2, '不该超过 maxWorks')
  assert.equal(trial.get('RJ00000011'), null, '最老的那部应当被淘汰')
  assert.notEqual(trial.get('RJ00000012'), null)
  assert.notEqual(trial.get('RJ00000013'), null, '刚打开的那部必须还在')
})

test('clear：单部与全清', async () => {
  const dlsite = fakeDlsite({ files: [{ name: 'a.mp3', data: audio(64) }] })
  const trial = new TrialLibrary({ dlsite, maxWorks: 4 })
  await trial.open('RJ00000021')
  await trial.open('RJ00000022')
  assert.equal(trial.stats.works, 2)

  assert.equal(trial.clear('RJ00000021'), 1)
  assert.equal(trial.stats.works, 1)
  assert.equal(trial.clear('不存在的号'), 0)
  assert.equal(trial.clear(), 1)
  assert.equal(trial.stats.works, 0)
  assert.equal(trial.stats.bytes, 0)
})

test('isDlsiteHost：只认 dlsite.com 那一支，别把面铺大', () => {
  for (const host of ['www.dlsite.com', 'trial.dlsite.com', 'play.dlsite.com', 'dlsite.com', 'WWW.DLSITE.COM.']) {
    assert.equal(isDlsiteHost(host), true, host)
  }
  for (const host of ['asmr.one', 'api.bilibili.com', 'notdlsite.com', 'dlsite.com.evil.net', '', null]) {
    assert.equal(isDlsiteHost(host), false, String(host))
  }
})

/* ── 体积闸门与错误转述 ──
 * 这一组钉的是「开着梯子也显示我没开梯子」那次的成因链：
 *   试听包 100.39MB > 旧默认 100MB → 抛业务错 → 被 http 兜底压成「操作失败」
 *   → 前端分不清，一律说成「DLsite 是被墙的」。
 * 三环里任何一环回退，用户就会重新看到那句没用的提示。 */

test('默认上限 800MB：百 MB 级的大合集要放行，只有离谱的包才挡', async () => {
  // 真实数据：RJ01678178 是 100.39MB、RJ01722990 是 231MB、RJ01716758 是 245.54MB。
  // 旧默认 100 把第一部就判死了，150 也罩不住后两部 —— 而分段读之后「包大」本身
  // 不再吃内存（打开只读中央目录），所以这个数可以放得很宽：它只剩
  // 「别让人误点一个几 GB 的东西」这一层意思。
  const samples = [
    { rj: 'RJ00000051', sizeMb: 100.39, sizeText: '100.39MB' },
    { rj: 'RJ00000052', sizeMb: 231, sizeText: '231MB' },
    { rj: 'RJ00000053', sizeMb: 245.54, sizeText: '245.54MB' }
  ]
  for (const sample of samples) {
    const dlsite = fakeDlsite({ files: [{ name: 'a.mp3', data: audio(64) }], sizeMb: sample.sizeMb, sizeText: sample.sizeText })
    const trial = new TrialLibrary({ dlsite })
    assert.notEqual(await trial.open(sample.rj), null, `${sample.sizeText} 应当落在默认上限内`)
  }

  const huge = fakeDlsite({ files: [{ name: 'a.mp3', data: audio(64) }], sizeMb: 2000, sizeText: '2000MB' })
  const guard = new TrialLibrary({ dlsite: huge })
  await assert.rejects(() => guard.open('RJ00000054'), /超过在线听的上限/, '离谱的包仍然要挡住')
})

test('体积超限的原因要原样传到前端，不能被 500 压成「操作失败」', async () => {
  const dlsite = fakeDlsite({ files: [{ name: 'a.mp3', data: audio(64) }], sizeMb: 100.39, sizeText: '100.39MB' })
  const trial = new TrialLibrary({ dlsite, maxMb: 1 })

  const thrown = await withTrialReason(() => trial.open('RJ00000033')).then(() => null, (error) => error)
  assert.notEqual(thrown, null, '超限必须抛错')
  assert.equal(thrown.status, 409, '这是业务岔路，不是「服务器内部错误」')
  assert.equal(thrown.code, 'trial-unavailable')
  assert.match(thrown.message, /超过在线听的上限/, '原话要留住 —— 前端靠它决定给用户哪个出口')
})

test('client.js：只有链路层失败才允许说成「DLsite 是被墙的」', () => {
  // 把线上那段函数原样截出来求值，避免「测试通过但线上是另一份实现」的漂移。
  const source = readFileSync(CLIENT, 'utf8')
  const start = source.indexOf('/** 链路层失败的指纹')
  const end = source.indexOf('/** 已经展开的那一项再点一次就收起来')
  assert.notEqual(start, -1, 'client.js 里找不到 describeTrialError 的起始注释')
  assert.notEqual(end, -1, 'client.js 里找不到 describeTrialError 之后的锚点')
  const factory = new Function(`${source.slice(start, end)}\nreturn describeTrialError`)()
  // 线上那份 t() 是查文案表的；测试里换成可辨识的占位，好断言它到底落在哪一支。
  const describe = (error) => factory((key) => `[${key}]`, error)

  // 真实报错原文：这句以前被翻译成「DLsite 是被墙的」，用户于是去反复检查梯子。
  const tooBig = describe(new Error('试听包 100.39MB，超过在线听的上限 100MB —— 这种走「下载试听」更合适'))
  assert.match(tooBig, /超过在线听的上限/)
  assert.equal(tooBig.includes('[trialBlocked]'), false, '体积超限跟代理无关，不能挂到「被墙」上')

  const noTrial = describe(new Error('RJ01678178「某某作品」没有提供官方试听包'))
  assert.equal(noTrial.includes('[trialBlocked]'), false, '这部没有试听是正常情况，别甩锅给网络')

  // 真正的链路失败仍然要给「去开代理」的指引。
  assert.match(describe(new Error('fetch failed')), /\[trialBlocked\]/)
  assert.match(describe(new Error('操作超时')), /\[trialBlocked\]/)
  assert.match(describe(new Error('未知路径 /asmrone/trial/open')), /\[needRestart\]/)
  assert.match(describe(new Error('')), /\[trialBlocked\]/, '空错误别吐空字符串给用户')

  // 打开失败时「下载到本地」必须还有入口 —— 否则超过在线听上限的试听包
  // 既听不了也存不下，用户被卡死在提示上（这正是那部 100.39MB 作品的处境）。
  const boxAt = source.indexOf('const trialFailBox = ')
  assert.notEqual(boxAt, -1, 'client.js 里找不到 trialFailBox')
  assert.match(source.slice(boxAt, boxAt + 900), /saveTrial\(t, rj\)/, '那个按钮要能带着失败的 RJ 直接下载')

  // 位置同样是需求：提示与按钮要贴在**出错的那一部**下面。
  // 早先它飘在列表顶端，真机上反馈回来的是「全都在最上面显示」——
  // 用户对着顶上那句话，看不出是哪一部出了什么问题。
  assert.match(source, /state\.trialFailRj === work\.workno && state\.trialFailMsg !== ''/,
    '失败提示要挂在对应卡片的 workno 上')
  const bodyAt = source.indexOf('const trialBody = h(react.Fragment')
  assert.notEqual(bodyAt, -1, 'client.js 里找不到 trialBody')
  const body = source.slice(bodyAt, bodyAt + 1800)
  assert.match(body, /failCardVisible/, '要判断失败的那部在不在结果列表里')
  assert.match(body, /!failCardVisible/, '顶端的兜底提示要受 failCardVisible 约束，否则会同时飘在顶上')

  assert.match(source, /async function saveTrial \(t, worknoArg\)/, 'saveTrial 要能接受指定的 RJ')

  // 「这一部打不开」这个答案要记住：有些作品的试听包压根没有音频（交互游戏 demo），
  // 慢速网络上重新问一遍要等十几秒才拿到同一句话。
  assert.match(source, /trialKnownBad/, '缺「已知打不开」的缓存')
  assert.match(source, /const cacheable = !TRIAL_LINK_RE\.test/,
    '链路层失败不该被记成永久坏 —— 网络好了它就能用')
})

/* ── 分段取：内存不再跟着包的大小走 ──
 * 这一组钉的是「不把整包拉进内存」这件事本身。宿主机可用内存只有 2GB 出头，
 * 而 DLsite 的大合集试听包有 200MB+ —— 靠调大上限是走不通的，只能不拉。 */

test('只取要播的那一轨，别的轨一个字节都不拉', async () => {
  const dlsite = fakeDlsite({
    files: [
      { name: '01.mp3', data: audio(5000, 0x41) },
      { name: '02.mp3', data: audio(6000, 0x42) },
      { name: '03.mp3', data: audio(7000, 0x43) }
    ]
  })
  const trial = new TrialLibrary({ dlsite })
  await trial.open('RJ00000041')
  assert.equal(trial.stats.bytes, 0)

  const want = await trial.slice('RJ00000041', 3, 0, 99)
  assert.equal(want.track.name, '03.mp3')
  assert.equal(want.data[0], 0x43, '取回来的应当是第三轨的内容')
  // 7000 字节，不是三轨的 18000 —— 这就是分段取要的效果。
  assert.equal(trial.stats.bytes, 7000, '只该驻留被播的那一轨')
  assert.equal(trial.stats.contentText, '17.6 KB', '但条目上记着的仍是整包内容量')
})

test('缓存超过上限就丢最旧的，正在播的那一轨永远保住', async () => {
  const dlsite = fakeDlsite({
    files: [
      { name: '01.mp3', data: audio(3 * 1024 * 1024, 0x41) },
      { name: '02.mp3', data: audio(3 * 1024 * 1024, 0x42) }
    ]
  })
  // 缓存上限 4MB，装不下两轨各 3MB。
  const trial = new TrialLibrary({ dlsite, maxCacheMb: 4 })
  await trial.open('RJ00000042')

  await trial.slice('RJ00000042', 1, 0, 9)
  assert.equal(trial.stats.cachedTracks, 1)

  await trial.slice('RJ00000042', 2, 0, 9)
  assert.equal(trial.stats.cachedTracks, 1, '装不下就该淘汰旧的')
  assert.equal(trial.stats.bytes, 3 * 1024 * 1024)
  assert.equal((await trial.slice('RJ00000042', 2, 0, 9)).data[0], 0x42, '刚播的那一轨必须还在')
})

test('落盘不受单轨上限约束 —— 下载正是「在线听放不下」时的出口', async () => {
  const dir = mkdtempSync(join(tmpdir(), 'trial-test-'))
  const dlsite = fakeDlsite({
    files: [{ name: 'huge.wav', data: audio(5 * 1024 * 1024) }],
    sizeMb: 5,
    sizeText: '5.00MB'
  })
  // 单轨上限压到 1MB：在线听会被拒，落盘不该被同一个闸门连坐。
  const trial = new TrialLibrary({ dlsite, maxTrackMb: 1 })
  try {
    await trial.open('RJ00000043')
    await assert.rejects(() => trial.slice('RJ00000043', 1, 0, 9), /超过单轨内存上限 1MB/)

    const saved = await trial.saveAll('RJ00000043', dir)
    assert.equal(saved.saved, 1, '在线听被拒的轨，落盘要能走通')
    assert.equal(statSync(saved.files[0].path).size, 5 * 1024 * 1024)
  } finally {
    rmSync(dir, { recursive: true, force: true })
  }
})

test('clear 要把已解压的轨一起放掉，不能只清条目表', async () => {
  const dlsite = fakeDlsite({ files: [{ name: 'a.mp3', data: audio(4096) }] })
  const trial = new TrialLibrary({ dlsite })
  await trial.open('RJ00000044')
  await trial.slice('RJ00000044', 1, 0, 9)
  assert.equal(trial.stats.bytes, 4096)

  assert.equal(trial.clear('RJ00000044'), 1)
  assert.equal(trial.stats.bytes, 0, '条目清了，轨数据也得跟着走')
  assert.equal(trial.stats.cachedTracks, 0)
})
