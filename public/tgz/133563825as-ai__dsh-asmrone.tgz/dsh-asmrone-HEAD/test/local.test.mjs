/**
 * 本地曲库 + Range 解析的单测。
 *
 * 这两块是「没代理也能听」的全部依据，所以要盯死三件事：
 *   ① 扫盘认得对（聚合单位、非音频过滤、自然序）；
 *   ② `resolveWithin` 挡得住目录穿越 —— 它背后是一个「读任意文件」的流端点，漏了就完了；
 *   ③ `parseRange` 的边界（后缀形式、越界、不可满足），拖进度条靠它。
 */
import test, { after, before } from 'node:test'
import assert from 'node:assert/strict'
import { mkdirSync, mkdtempSync, rmSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'

import { parseRange } from '../src/http.js'
import { LocalLibrary, formatBytes, mimeOf, rjFromName, looksLikeTrial } from '../src/local.js'

let root
let library

/** 写一个指定字节数的假音频，用来验体积统计。 */
function write (path, bytes) {
  mkdirSync(join(path, '..'), { recursive: true })
  writeFileSync(path, Buffer.alloc(bytes, 0))
}

before(() => {
  root = mkdtempSync(join(tmpdir(), 'asmrone-local-'))
  const downloads = join(root, 'ASMR')
  const trials = join(root, '试听')

  // 作品 A：三个文件，专门验证自然序（track2 要排到 track10 前面）
  write(join(downloads, '作品A', 'track10.mp3'), 2048)
  write(join(downloads, '作品A', 'track2.mp3'), 1024)
  write(join(downloads, '作品A', 'track1.mp3'), 512)

  // 文件散在根目录：父目录就是根，作品名退回根目录名
  write(join(downloads, '散装.mp3'), 128)
  // 非音频必须被滤掉
  writeFileSync(join(downloads, '听法说明.md'), 'x')

  // 作品 B：带 RJ 号 + 一张封面图（图要滤掉）
  write(join(trials, '作品B_RJ01726233', '01.wav'), 4096)
  writeFileSync(join(trials, '作品B_RJ01726233', 'cover.jpg'), 'x')

  // 超出深度上限的那支应当被放弃
  write(join(trials, '作品C', 'a', 'b', 'c', 'd', 'e', 'f', 'deep.mp3'), 64)

  library = new LocalLibrary({
    store: {
      get: () => ({
        outputDir: downloads,
        localDirs: [trials],
        // 故意塞两个脏值：相对路径要被丢掉，重复项要去重
        noSuchKey: true,
        languageFilter: 'male'
      })
    }
  })
})

after(() => {
  if (root) rmSync(root, { recursive: true, force: true })
})

test('formatBytes：单位进位正确，脏值不冒 NaN', () => {
  assert.equal(formatBytes(0), '0 B')
  assert.equal(formatBytes(1023), '1023 B')
  assert.equal(formatBytes(1024), '1.0 KB')
  assert.equal(formatBytes(1536), '1.5 KB')
  assert.equal(formatBytes(1024 * 1024), '1.0 MB')
  assert.equal(formatBytes(1024 ** 3), '1.0 GB')
  assert.equal(formatBytes(NaN), '0 B')
  assert.equal(formatBytes(-1), '0 B')
  assert.equal(formatBytes(undefined), '0 B')
})

test('rjFromName：从目录名抠出与 asmr.one 一致的纯数字 id', () => {
  assert.equal(rjFromName('作品B_RJ01726233'), '1726233')
  assert.equal(rjFromName('RJ01057368_mp3_音轨3'), '1057368')
  assert.equal(rjFromName('RJ1723255'), '1723255')
  assert.equal(rjFromName('没有号的作品'), '')
  assert.equal(rjFromName(''), '')
})

test('looksLikeTrial：识别试听包目录名', () => {
  assert.equal(looksLikeTrial('xxx_sample'), true)
  assert.equal(looksLikeTrial('體驗版'), true)
  assert.equal(looksLikeTrial('体験版'), true)
  assert.equal(looksLikeTrial('正式版'), false)
})

test('mimeOf：按扩展名给 Content-Type', () => {
  assert.equal(mimeOf('a.mp3'), 'audio/mpeg')
  assert.equal(mimeOf('a.WAV'), 'audio/wav')
  assert.equal(mimeOf('a.flac'), 'audio/flac')
  assert.equal(mimeOf('a.txt'), 'application/octet-stream')
})

test('roots：outputDir 排第 0，脏值与重复被清掉', () => {
  const roots = library.roots()
  assert.equal(roots.length, 2)
  assert.equal(roots[0], join(root, 'ASMR'), 'outputDir 必须排第一 —— 它标记为「下载」')
  assert.equal(roots[1], join(root, '试听'))

  const withJunk = new LocalLibrary({
    store: { get: () => ({ outputDir: '/tmp/x', localDirs: ['/tmp/x', 'relative/path', '', 42, '/tmp/y'] }) }
  })
  assert.deepEqual(withJunk.roots(), ['/tmp/x', '/tmp/y'])
})

test('scan：按父目录聚合、滤掉非音频、自然序排序', () => {
  const snapshot = library.scan({ force: true })

  assert.equal(snapshot.roots.length, 2)
  assert.equal(snapshot.roots[0].exists, true)
  assert.equal(snapshot.roots[0].files, 4, '作品A 三轨 + 根目录那一个，md 不算')

  const names = snapshot.works.map((work) => work.name)
  assert.ok(names.includes('作品A'))
  assert.ok(names.includes('作品B_RJ01726233'))
  // 文件散在根目录时，父目录就是根，作品名退回根目录名（这里是 `ASMR`）。
  assert.ok(names.includes('ASMR'), '文件散在根目录时，作品名退回根目录名')

  const a = snapshot.works.find((work) => work.name === '作品A')
  assert.deepEqual(a.files.map((file) => file.name), ['track1.mp3', 'track2.mp3', 'track10.mp3'],
    '自然序：track2 必须排到 track10 前面')
  assert.equal(a.count, 3)
  assert.equal(a.bytes, 512 + 1024 + 2048)
  assert.equal(a.source, 'download', '第 0 个根标记为「下载」')

  const b = snapshot.works.find((work) => work.name === '作品B_RJ01726233')
  assert.equal(b.count, 1, 'cover.jpg 不该被当成音轨')
  assert.equal(b.rj, '1726233')
  assert.equal(b.source, 'library', '非 outputDir 的根标记为「外部库」')

  // 深度上限：作品C 的 deep.mp3 埋在 7 层以下，应当被放弃，
  // 于是作品C 一个音频都没有，压根不会出现在结果里。
  assert.equal(names.includes('作品C'), false)
  // 作品A 3 轨 + 根目录散装 1 个 + 作品B 1 轨 = 5（作品C 超深度、md、jpg 都不算）
  assert.equal(snapshot.totals.files, 5)
})

test('scan：缓存生效，force 绕过', () => {
  const first = library.scan({ force: true })
  const cached = library.scan()
  assert.equal(cached, first, 'TTL 内应当返回同一份快照对象')

  library.invalidate()
  assert.notEqual(library.scan(), first, 'invalidate 之后必须重扫')

  const shortTtl = new LocalLibrary({ store: { get: () => ({ outputDir: join(root, 'ASMR') }) }, ttlMs: 0 })
  const one = shortTtl.scan()
  assert.notEqual(shortTtl.scan(), one, 'ttl=0 等于不缓存')
})

test('find：按作品名、文件名、RJ 号都能命中', () => {
  assert.equal(library.find('作品A').length, 1)
  assert.equal(library.find('track10').length, 1, '应当能按文件名找到所属作品')
  assert.equal(library.find('1726233').length, 1, '按归一后的 id 也要能命中')
  assert.equal(library.find('RJ01726233').length, 1, '带 RJ 前缀也认')
  assert.equal(library.find('').length, library.scan().works.length)
  assert.deepEqual(library.find('不存在的作品'), [])
})

test('track：按下标取轨，越界给 null 而不是抛异常', () => {
  const work = library.find('作品A')[0]
  assert.equal(library.track(work.key, 1).file.name, 'track1.mp3')
  assert.equal(library.track(work.key, 3).file.name, 'track10.mp3')
  assert.equal(library.track(work.key, 4), null)
  assert.equal(library.track(work.key, 0), null)
  assert.equal(library.track('不存在的key', 1), null)
})

test('resolveWithin：根内音频放行，其余一律挡掉', () => {
  const downloads = join(root, 'ASMR')
  const inside = join(downloads, '作品A', 'track1.mp3')
  assert.equal(library.resolveWithin(inside), inside)

  // 根外
  assert.equal(library.resolveWithin('/etc/passwd'), null, '不该放行系统文件')
  assert.equal(library.resolveWithin(join(root, 'ASMR', '听法说明.md')), null, '非音频扩展名要挡')
  assert.equal(library.resolveWithin('relative/track1.mp3'), null, '相对路径要挡')
  assert.equal(library.resolveWithin(''), null)
  assert.equal(library.resolveWithin(null), null)
  assert.equal(library.resolveWithin(join(downloads, '作品A', '不存在.mp3')), null)

  // 前缀攻击：/root/ASMR-evil 不能被 /root/ASMR 放行
  const evil = join(root, 'ASMR-evil', 'x.mp3')
  write(evil, 16)
  assert.equal(library.resolveWithin(evil), null, '前缀撞名不该被当成根内文件')
})

/* ── parseRange ─────────────────────────────────────────────────── */
test('parseRange：正常区间 / 开放结尾 / 后缀形式', () => {
  assert.deepEqual(parseRange('bytes=0-1023', 10000), { start: 0, end: 1023 })
  assert.deepEqual(parseRange('bytes=1000-', 10000), { start: 1000, end: 9999 })
  assert.deepEqual(parseRange('bytes=-500', 10000), { start: 9500, end: 9999 })
  assert.deepEqual(parseRange('bytes=0-0', 10000), { start: 0, end: 0 })
  assert.deepEqual(parseRange('bytes=9999-9999', 10000), { start: 9999, end: 9999 })
  assert.deepEqual(parseRange('Bytes=0-9', 100), { start: 0, end: 9 }, '单位大小写不敏感')
})

test('parseRange：超出末端的 end 被夹回，start 越界算不可满足', () => {
  assert.deepEqual(parseRange('bytes=0-99999', 100), { start: 0, end: 99 })
  assert.equal(parseRange('bytes=100-200', 100), null, 'start 等于长度即越界')
  assert.equal(parseRange('bytes=500-600', 100), null)
  assert.equal(parseRange('bytes=50-10', 100), null, 'end 小于 start')
  assert.equal(parseRange('bytes=-0', 100), null)
})

test('parseRange：多段与垃圾输入一律 null（调用方回 416）', () => {
  assert.equal(parseRange('bytes=0-99,200-299', 1000), null, '不支持多段')
  assert.equal(parseRange('bytes=-', 1000), null)
  assert.equal(parseRange('items=0-10', 1000), null)
  assert.equal(parseRange('', 1000), null)
  assert.equal(parseRange(undefined, 1000), null)
  assert.equal(parseRange('bytes=0-10', 0), null, '空文件没有可满足的区间')
  assert.equal(parseRange('bytes=abc-def', 1000), null)
})
