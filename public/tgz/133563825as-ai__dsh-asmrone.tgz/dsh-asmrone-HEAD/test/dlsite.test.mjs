/**
 * DLsite 搜索解析的回归测试。
 *
 * `parseSearchResults` 是全项目**最容易失效**的一段代码 —— 它读的是 DLsite 的
 * HTML 结构，不是稳定接口。所以这里钉一份**实测抓下来的片段**（2026-10-05，
 * `https://www.dlsite.com/maniax/fsr/=/keyword/耳かき`），DLsite 改版时这里会先红。
 *
 * 片段做了两处精简：只留两条结果、砍掉无关的脚本与样式。**分块边界、
 * 转义的封面地址、maker/author/price 的相对位置都保持原样** —— 那些正是解析依赖的东西。
 */

import assert from 'node:assert/strict'
import test from 'node:test'

import { normalizeWorkno, parseSearchResults, withRetry } from '../src/dlsite.js'

const SAMPLE_HTML = `
<dl class="search_result_img_box">
<dt><a href="https://www.dlsite.com/maniax/work/=/product_id/RJ01678178.html">
<img src="//img.dlsite.jp/modpub/images2/work/doujin/RJ01679000/RJ01678178_img_main.jpg" alt="【ブルーアーカイブ】ミヨASMR～先生が、悪いんですよ?～ [Yostar]"></a></dt>
<dd class="work_category_free_sample"><div class="work_category type_SOU type_free_sample"><a href="https://www.dlsite.com/maniax/fsr/=/work_type/SOU">ボイス・ASMR</a></div><span data-vue-component="SampleViewMiniButton"data-product_id="RJ01678178"data-view_samples="[{'thumb':'\\/\\/img.dlsite.jp\\/modpub\\/images2\\/work\\/doujin\\/RJ01679000\\/RJ01678178_img_main.jpg','width':560,'height':420},{'thumb':'\\/\\/img.dlsite.jp\\/modpub\\/images2\\/work\\/doujin\\/RJ01679000\\/RJ01678178_img_smp1.jpg','width':1120,'height':840}]"data-worktype="SOU"></span></dd><dd class="work_name"><div class="icon_wrap"></div><div class="multiline_truncate"><a href="https://www.dlsite.com/maniax/work/=/product_id/RJ01678178.html" title="【ブルーアーカイブ】ミヨASMR～先生が、悪いんですよ?～">【ブルーアーカイブ】ミヨASMR～先生が、悪いんですよ?～</a></div></dd><dd class="maker_name"><a href="https://www.dlsite.com/maniax/circle/profile/=/maker_id/RG62982.html">Yostar</a><span class="separator">/</span><span class="author"><a href="https://www.dlsite.com/maniax/fsr/=/keyword_creater/%22%E8%8A%B1%E5%B2%A9%E9%A6%99%E5%A5%88%22/ana_flg/all" class="">花岩香奈</a></span></dd><dd class="work_price_wrap">
<span class="work_price "> <span class="work_price_parts"> <span class="work_price_prefix"></span> <span class="work_price_base">1,320</span> <span class="work_price_suffix">円</span> </span> </div></dd>
<dt><a href="https://www.dlsite.com/maniax/work/=/product_id/RJ01712782.html">
<img src="//img.dlsite.jp/modpub/images2/work/doujin/RJ01712000/RJ01712782_img_main.jpg" alt="【ASMR/15時間】癒しの森の耳かき屋さん [癒しの森の家]"></a></dt>
<dd class="work_category_free_sample"><div class="work_category type_SOU type_free_sample"><a href="https://www.dlsite.com/maniax/fsr/=/work_type/SOU">ボイス・ASMR</a></div></dd><dd class="work_name"><div class="icon_wrap"></div><div class="multiline_truncate"><a href="https://www.dlsite.com/maniax/work/=/product_id/RJ01712782.html" title="【ASMR/15時間】癒しの森の耳かき屋さん&amp;姉妹">【ASMR/15時間】癒しの森の耳かき屋さん&amp;姉妹</a></div></dd><dd class="maker_name"><a href="https://www.dlsite.com/maniax/circle/profile/=/maker_id/RG12345.html">癒しの森の家</a><span class="separator">/</span><span class="author"><a href="#" class="">こりす</a></span></dd><dd class="work_price_wrap">
<span class="work_price "> <span class="work_price_parts"> <span class="work_price_prefix"></span> <span class="work_price_base">577</span> <span class="work_price_suffix">円</span> </span> </div></dd>
</dl>
`

test('parseSearchResults：两条结果都解出来，字段各就各位', () => {
  const works = parseSearchResults(SAMPLE_HTML)
  assert.equal(works.length, 2)

  const [first, second] = works
  assert.equal(first.workno, 'RJ01678178')
  assert.equal(first.title, '【ブルーアーカイブ】ミヨASMR～先生が、悪いんですよ?～')
  assert.equal(first.circle, 'Yostar')
  assert.equal(first.voice, '花岩香奈')
  assert.equal(first.price, '1,320')
  assert.equal(first.category, 'ボイス・ASMR')
  assert.equal(first.url, 'https://www.dlsite.com/maniax/work/=/product_id/RJ01678178.html')
  // 封面在页面里是 `\\/\\/img...` 这种转义形态，必须还原成可用 URL
  assert.equal(first.cover, 'https://img.dlsite.jp/modpub/images2/work/doujin/RJ01679000/RJ01678178_img_main.jpg')

  assert.equal(second.workno, 'RJ01712782')
  assert.equal(second.circle, '癒しの森の家')
  assert.equal(second.voice, 'こりす')
  // HTML 实体要解开，否则界面上会看到 `&amp;`
  assert.equal(second.title.includes('&amp;'), false, '标题里的实体应当已经解码')
  assert.equal(second.title.includes('&姉妹'), true)
})

test('parseSearchResults：没有结果 / 脏输入都不炸', () => {
  assert.deepEqual(parseSearchResults(''), [])
  assert.deepEqual(parseSearchResults(null), [])
  assert.deepEqual(parseSearchResults('<html><body>没有结果</body></html>'), [])
  // 有 work_name 但没有作品链接：跳过而不是塞一条半成品
  assert.deepEqual(parseSearchResults('<dd class="work_name"><div>空壳</div></dd>'), [])
})

test('parseSearchResults：同一个作品重复出现只留一条', () => {
  const twice = SAMPLE_HTML.replace('RJ01712782', 'RJ01678178')
  const works = parseSearchResults(twice)
  assert.equal(works.length, 1, '去重之后应当只剩一条')
})

test('normalizeWorkno：RJ 号、链接、分享文本、纯数字都认', () => {
  const expected = 'RJ01650453'
  const cases = [
    'RJ01650453',
    'rj1650453',
    'RJ1650453',
    '1650453',
    'https://www.dlsite.com/maniax/work/=/product_id/RJ01650453.html',
    'https://www.dlsite.com/maniax-touch/work/=/product_id/RJ01650453.html?locale=zh_CN',
    '【DLsite】三つ子の姉妹 特典付き https://www.dlsite.com/maniax/work/=/product_id/RJ01650453.html',
    // 关键回归：URL 上再挂别的数字参数，不能把那些数字拼进 RJ 号里
    'https://www.dlsite.com/maniax/work/=/product_id/RJ01650453.html?utm_source=x&p=3',
    'https://www.dlsite.com/maniax/work/=/product_id/RJ01650453.html?page=12&per_page=100'
  ]
  for (const input of cases) {
    assert.equal(normalizeWorkno(input), expected, `解析失败：${input}`)
  }

  // 认不出来的时候要抛，而不是返回一个看着像样的假号
  for (const bad of ['', '   ', 'hello', null, undefined]) {
    assert.throws(() => normalizeWorkno(bad), /无法从/)
  }
  // 十几个数字拼一起显然不是一个 RJ 号
  assert.throws(() => normalizeWorkno('123456789012345'), /无法从/)
})

/**
 * 重试只针对**网络层**失败。
 *
 * 真机反馈：用户开着 VPN 但只有 ~20KB/s，取一次 400KB 的作品页经常断在半路，
 * 而界面把这种「fetch failed」说成「DLsite 是被墙的」—— 一次偶发断线看起来就像被墙了。
 * 重试一次多半就过，所以这层不该省。
 */
test('withRetry：网络层失败重试，服务器明确回答的错误不重试', async () => {
  let flaky = 0
  const value = await withRetry(async () => {
    flaky += 1
    if (flaky < 3) throw new Error('fetch failed')
    return 'ok'
  })
  assert.equal(value, 'ok')
  assert.equal(flaky, 3, '网络层错误应当重试到成功')

  // 服务器已经明确回答过的东西，重试一百次也是同一个答案。
  let hard = 0
  await assert.rejects(
    () => withRetry(async () => {
      hard += 1
      throw new Error('DLsite 返回 404（https://x）')
    }),
    /404/
  )
  assert.equal(hard, 1, '服务器已经明确回答过的错误不该重试')

  // 重试用尽后要把最后一次的错误原样抛出去，不能吞掉。
  let always = 0
  await assert.rejects(
    () => withRetry(async () => {
      always += 1
      throw new Error('fetch failed')
    }),
    /fetch failed/
  )
  assert.equal(always, 3, '上限就是 attempts')
})
