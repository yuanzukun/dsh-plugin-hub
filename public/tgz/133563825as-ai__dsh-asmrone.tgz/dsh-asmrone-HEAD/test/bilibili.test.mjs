/**
 * B 站音源的测试。
 *
 * 分两层：
 *   · 纯函数（`parseRef` / `stripTags` / `formatDuration` / `parseDurationText`）——
 *     离线也跑，必须全绿；
 *   · 在线链路（搜索 → 取流 → Range 转发）—— 容器里 B 站本来是直连可达的，
 *     但换到没有出口的环境时接口会不通。那种情况按老规矩 `t.skip()`，
 *     绝不 `assert.ok(true)` 制造假绿。
 *
 * 在线用例的价值在于钉住三件很容易被上游改掉的事：
 * ① WBI 签名（不加签名连发几个就 412）；② CDN 的 UA + Referer 门禁（少一个就 403）；
 * ③ 「取到的音频是完整 fMP4」这个前提 —— `/asmrone/bili-stream` 的流式播放全靠它。
 */

import assert from 'node:assert/strict'
import test from 'node:test'

import {
  BilibiliClient,
  DEFAULT_QUALITY,
  formatDuration,
  parseDurationText,
  parseRef,
  stripTags
} from '../src/bilibili.js'

/** 探一下 B 站接口通不通。不通就让在线用例 skip 而不是 fail。 */
async function reachable () {
  try {
    const controller = new AbortController()
    const timer = setTimeout(() => controller.abort(), 8000)
    const response = await fetch('https://api.bilibili.com/x/frontend/finger/spi', {
      signal: controller.signal,
      headers: { 'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/126.0.0.0 Safari/537.36' }
    })
    clearTimeout(timer)
    return response.ok
  } catch {
    return false
  }
}

test('parseRef：认 BV / av / 链接 / 分 P 参数', () => {
  assert.deepEqual(parseRef('BV1rE411P7ct'), { bvid: 'BV1rE411P7ct', aid: 0, page: 1 })
  // 大小写：BV 号本身大小写敏感，手打时几乎不会照着原样敲，前缀统一抬成大写提高命中率
  assert.equal(parseRef('bv1rE411P7ct').bvid, 'BV1rE411P7ct')
  assert.deepEqual(parseRef('av97613422'), { bvid: '', aid: 97613422, page: 1 })
  assert.deepEqual(parseRef('97613422'), { bvid: '', aid: 97613422, page: 1 })
  assert.deepEqual(parseRef('https://www.bilibili.com/video/BV1rE411P7ct?p=3'), { bvid: 'BV1rE411P7ct', aid: 0, page: 3 })
  assert.deepEqual(parseRef('BV1rE411P7ct?p=2'), { bvid: 'BV1rE411P7ct', aid: 0, page: 2 })
  // 脏输入不该炸，也不该猜出一个 id
  for (const bad of ['', '   ', 'hello world', null, undefined]) {
    const parsed = parseRef(bad)
    assert.equal(parsed.bvid, '')
    assert.equal(parsed.aid, 0)
  }
})

test('stripTags：去掉搜索结果的 <em> 高亮与 HTML 实体', () => {
  assert.equal(stripTags('<em class="keyword">助眠</em>雨声-白噪音'), '助眠雨声-白噪音')
  assert.equal(stripTags('A &amp; B &quot;x&quot; &#39;y&#39;'), 'A & B "x" \'y\'')
  assert.equal(stripTags('<b>a</b><i>b</i>'), 'ab')
  assert.equal(stripTags(null), '')
})

test('时长：秒与 mm:ss / h:mm:ss 双向都对得上', () => {
  assert.equal(formatDuration(45), '0:45')
  assert.equal(formatDuration(272), '4:32')
  assert.equal(formatDuration(2687), '44:47')
  assert.equal(formatDuration(35139), '9:45:39')
  assert.equal(formatDuration(-5), '0:00')
  assert.equal(formatDuration(NaN), '0:00')

  assert.equal(parseDurationText('44:47'), 2687)
  assert.equal(parseDurationText('9:45:39'), 35139)
  assert.equal(parseDurationText('bad'), 0)
})

test('B 站：搜 → 取流 → Range 转发（网络不通时跳过）', async (t) => {
  if (!(await reachable())) return t.skip('api.bilibili.com 不可达，跳过在线用例')

  const client = new BilibiliClient({ timeoutMs: 25000 })

  // 搜索。顺带钉住 WBI 签名链路 —— 没有签名这里会稳定 412。
  const found = await client.search({ keyword: '白噪音', pageSize: 3 })
  if (found.videos.length === 0) {
    // 接口可达但返回空：出口一波动（VPN 开关、风控限速）就会这样。
    // 这不是代码坏了，按老规矩诚实地 skip，不要制造假绿也不要假红。
    return t.skip('B 站返回空结果（出口变化或风控限速），跳过在线用例')
  }
  assert.equal(found.total > 0, true)
  for (const video of found.videos) {
    assert.match(video.bvid, /^BV[0-9A-Za-z]{10}$/)
    assert.equal(typeof video.title, 'string')
    assert.equal(typeof video.duration, 'number')
    // 标题里的 <em> 必须已经清掉，否则界面会漏标签
    assert.equal(/<[^>]+>/.test(video.title), false, `标题里残留了标签：${video.title}`)
    assert.equal(video.url.startsWith('https://www.bilibili.com/video/'), true)
  }

  // 连造几个关键词：412 风控只有在「不带签名 + 不带 buvid」时才出现。
  for (const keyword of ['助眠 雨声', '耳かき', '催眠']) {
    const more = await client.search({ keyword, pageSize: 1 })
    assert.equal(Array.isArray(more.videos), true, `关键词「${keyword}」不该报错`)
  }

  // 详情：cid 是取流的钥匙，必须能拿到。
  const target = found.videos[0]
  const info = await client.view(target.bvid)
  assert.equal(info.bvid, target.bvid)
  assert.equal(info.pages.length > 0, true)
  assert.equal(info.defaultCid > 0, true)
  for (const page of info.pages) assert.equal(page.cid > 0, true, '每个分 P 都要有 cid')

  // 直链：三档码率里必须能选中一档，并且带 deadline。
  const stream = await client.stream({ bvid: info.bvid, cid: info.defaultCid })
  assert.equal(stream.url.startsWith('https://'), true)
  assert.equal(stream.quality > 0, true)
  assert.equal(stream.deadline > Date.now(), true, '直链的 deadline 应该在将来')

  // 缓存命中：第二次取同一个 cid 不该再出网（时间近零）。
  const started = Date.now()
  await client.stream({ bvid: info.bvid, cid: info.defaultCid })
  assert.equal(Date.now() - started < 50, true, '第二次取流应该直接命中缓存')

  // 真正的关键一步：CDN 直链能不能拿下来。UA 或 Referer 少一个，这里就是 403。
  const head = await client.fetchAudio({ bvid: info.bvid, cid: info.defaultCid, method: 'HEAD' })
  assert.equal(head.headProbe, true, 'HEAD 会被翻成 GET + 1 字节探测')
  assert.equal(head.response.status, 206, `HEAD 探测应该拿到 206，实得 ${head.response.status}`)
  const total = Number(String(head.response.headers.get('content-range') ?? '').split('/')[1])
  assert.equal(total > 0, true, '要能从 Content-Range 里读出总长度')
  await head.response.body?.cancel?.()

  const ranged = await client.fetchAudio({ bvid: info.bvid, cid: info.defaultCid, range: 'bytes=0-65535' })
  assert.equal(ranged.response.status, 206)
  assert.match(String(ranged.response.headers.get('content-range')), /^bytes 0-65535\/\d+$/)
  const bytes = Buffer.from(await ranged.response.arrayBuffer())
  assert.equal(bytes.length, 65536)
  // 完整 fMP4 的头：前 4 字节是 box 长度，紧接着是 `ftyp`。
  // 这一条钉住「不用 ffmpeg 也能播」这个前提 —— 上游哪天改成纯分片这里会当场炸。
  assert.equal(bytes.subarray(4, 8).toString('latin1'), 'ftyp', 'DASH 音频应当是自带头部的完整 fMP4')

  // 越界 Range 要如实报 416，播放器据此重试。
  const bad = await client.fetchAudio({ bvid: info.bvid, cid: info.defaultCid, range: 'bytes=99999999999-' })
  assert.equal(bad.response.status, 416)

  // 低码率档也要能取到
  const low = await client.stream({ bvid: info.bvid, cid: info.defaultCid, quality: 30216 })
  assert.equal(low.quality, 30216)

  assert.equal(DEFAULT_QUALITY, 30280, '默认档位应当是最高档（流式不吃磁盘，没理由省）')
})

test('B 站：无效稿件 / 无效 cid 给明确错误而不是崩栈', async (t) => {
  if (!(await reachable())) return t.skip('api.bilibili.com 不可达，跳过在线用例')

  const client = new BilibiliClient({ timeoutMs: 20000 })

  // 不存在的 av 号：要抛，而且抛出来的得是 B 站自己那句话术，不是 undefined。
  // （别拿 `BV1xx411c7mD` 当反例 —— 那是 B 站文档里的示例稿件，真实存在。）
  await assert.rejects(
    () => client.view({ aid: 99999999999 }),
    (error) => /B 站/.test(String(error.message)) && error.message.length > 0
  )

  // 缺 cid 是本地就该拦下来的，不该白跑一趟网络。
  await assert.rejects(() => client.stream({ bvid: 'BV1rE411P7ct', cid: 0 }), /cid/)

  // 有效稿件 + 无效 cid：必须给出可读错误，不能是把 undefined 拆开那种崩栈。
  const found = await client.search({ keyword: '白噪音', pageSize: 1 })
  if (found.videos.length > 0) {
    await assert.rejects(
      () => client.stream({ bvid: found.videos[0].bvid, cid: 1 }),
      (error) => typeof error.message === 'string' && error.message.length > 0
    )
  }
})
