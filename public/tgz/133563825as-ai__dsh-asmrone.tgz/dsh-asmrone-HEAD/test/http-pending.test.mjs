/**
 * `/asmrone/play` + `/asmrone/pending` 的集成测试。
 *
 * 这两个端点是「agent 说一句『放这首』→ 手机真的出声」那条链路。单测 PlayQueue
 * 只能证明队列自身对，证明不了路由把 track 解析对了、id 归一对了、错误码给对了。
 *
 * 用假 api 顶掉 asmr.one，所以**离线可跑** —— 这条链路不该只在有代理时才能验。
 */
import test, { before, after } from 'node:test'
import assert from 'node:assert/strict'
import { createServer } from 'node:http'

import { registerRoutes } from '../src/http.js'
import { PlayQueue } from '../src/pending.js'

// 音轨树是**数组根**（api.tracks 会保证这点），folder 靠 children 嵌套。
// 之前这里写成 { children: [...] }，flattenAudio 认数组、直接吐了 0 轨。
const TREE = [
  { type: 'audio', hash: '1006912/1', title: '導入' },
  { type: 'folder', title: '本編', children: [{ type: 'audio', hash: '1006912/2', title: '本番' }] }
]

let server
let base
let pending

before(async () => {
  pending = new PlayQueue()
  let handler = null
  registerRoutes({
    webServer: { register: (spec) => { handler = spec.handler; return () => {} } },
    runtime: {
      api: {
        tracks: async () => TREE,
        streamUrl: (hash) => '/asmrone/stream?hash=' + encodeURIComponent(hash),
        workPageUrl: (id) => 'https://asmr.one/work/' + id
      },
      store: { get: () => ({ defaultOrder: 'dl_count', pageSize: 20, languageFilter: 'male' }), set: () => {} },
      dlsite: {},
      pending
    }
  })
  assert.notEqual(handler, null, '路由没挂上')
  server = createServer((req, res) => handler(req, res))
  await new Promise((resolve) => server.listen(0, resolve))
  base = `http://127.0.0.1:${server.address().port}`
})

after(() => { if (server) server.close() })

const postPlay = async (body) => {
  const response = await fetch(base + '/asmrone/play', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: typeof body === 'string' ? body : JSON.stringify(body)
  })
  return { status: response.status, body: await response.json().catch(() => null) }
}
const getPending = async (since) => {
  const response = await fetch(`${base}/asmrone/pending?since=${since}`)
  return { status: response.status, body: await response.json().catch(() => null) }
}

test('推歌链路：默认第 1 轨 → 入队 → 取走 → 游标推进后不再重复', async () => {
  const first = await postPlay({ id: '1006912' })
  assert.equal(first.status, 200)
  assert.equal(first.body.item.hash, '1006912/1', '不传 index 时应取第 1 轨')
  assert.equal(first.body.item.title, '導入')
  assert.equal(first.body.item.id, '1006912')
  assert.equal(first.body.item.total, 2, '树里的音频节点数（folder 不算）')
  assert.match(first.body.item.stream, /^\/asmrone\/stream\?hash=/)

  const taken = await getPending(0)
  assert.equal(taken.status, 200)
  assert.equal(taken.body.item.hash, '1006912/1')
  assert.equal(taken.body.seq, first.body.item.seq, '轮询给的 seq 应与入队时一致')

  const again = await getPending(taken.body.seq)
  assert.equal(again.body.item, null, '同一首不该被投递两次')
})

test('推指定轨：index 认嵌套层级，hash 认任意值', async () => {
  const second = await postPlay({ id: '1006912', index: 2 })
  assert.equal(second.status, 200)
  assert.equal(second.body.item.hash, '1006912/2', 'folder 下的音频也要能被 index 命中')
  assert.equal(second.body.item.title, '本番')

  // 指定一个树上没有的 hash：asmr.one 的 hash 形式多，别因为匹配不上就拒绝
  const byHash = await postPlay({ id: '1006912', hash: '1653004/1937686' })
  assert.equal(byHash.status, 200)
  assert.equal(byHash.body.item.hash, '1653004/1937686')
  assert.equal(byHash.body.item.title, '1653004/1937686', '匹配不到就拿 hash 当标题')
})

test('作品 id 归一：RJ 号带前缀也能对上列表里的数字 id', async () => {
  const { body } = await postPlay({ id: 'RJ01726233' })
  assert.equal(body.item.id, '1726233', '前端要用它匹配列表里的作品来补封面，前缀没剥就匹配不上')
})

test('错误分支：空 id 400、越界轨 404、坏 JSON 400', async () => {
  assert.equal((await postPlay({ id: '' })).status, 400)
  assert.equal((await postPlay({})).status, 400)
  assert.equal((await postPlay({ id: 'RJabc' })).status, 400, '剥完没有数字也算缺 id')
  assert.equal((await postPlay({ id: '1006912', index: 99 })).status, 404)
  assert.equal((await postPlay({ id: '1006912', index: 0 })).status, 404, 'index 0 不合法')

  const malformed = await postPlay('{ 不是 JSON')
  assert.equal(malformed.status, 400)
  assert.ok(malformed.body?.error?.message, '坏 JSON 也要给一句人话')
})

test('错误响应不会污染队列', async () => {
  const before = pending.seq
  await postPlay({ id: '1006912', index: 99 })
  await postPlay({ id: '' })
  assert.equal(pending.seq, before, '失败的请求不该改动 seq，否则前端游标会莫名跳一格')
})
