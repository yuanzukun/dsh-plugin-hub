/**
 * 待播队列单测。
 *
 * 这条链路最容易出的两类错都在这里咬住：
 *   ① 游标语义写反 —— 前端每 3 秒问一次，写反了同一首会反复重播；
 *   ② 没有 TTL —— 半小时前推的一首，在用户已经忘了之后突然响起来。
 */
import test from 'node:test'
import assert from 'node:assert/strict'

import { PlayQueue } from '../src/pending.js'

test('push 返回自增 seq，记录字段被规整', () => {
  const queue = new PlayQueue()
  const first = queue.push({ id: 1006912, hash: 'a/b', title: '第一轨', total: '12' })
  const second = queue.push({ id: 'RJ01726233', hash: 'c/d' })

  assert.equal(first.seq, 1)
  assert.equal(second.seq, 2)
  assert.equal(first.id, '1006912', '数字 id 要归一成字符串，前端拿它比对作品')
  assert.equal(second.id, '1726233', 'RJ 号里的前缀不该原样带进来')
  assert.equal(second.hash, 'c/d')
  assert.equal(second.title, 'c/d', '缺标题时退回 hash，不能是 undefined')
  assert.equal(first.total, 12)
  assert.equal(second.total, 0)
  assert.equal(second.source, 'agent')
  assert.equal(new PlayQueue().push({ id: 1, hash: 'h', source: 'ui' }).source, 'ui')
})

test('poll：游标之后才有货，同一条不会投递两次', () => {
  const queue = new PlayQueue()
  assert.deepEqual(queue.poll(0), { seq: 0, item: null }, '空队列也给 seq，前端才推得动游标')

  queue.push({ id: 'a', hash: 'a/1', title: 'A' })
  const first = queue.poll(0)
  assert.equal(first.seq, 1)
  assert.equal(first.item.hash, 'a/1')

  // 前端收到后把游标推到 1，下一轮必须什么都没有
  assert.deepEqual(queue.poll(1), { seq: 1, item: null })
  assert.deepEqual(queue.poll(1), { seq: 1, item: null }, '连续轮询依然为空')

  queue.push({ id: 'b', hash: 'b/1', title: 'B' })
  const second = queue.poll(1)
  assert.equal(second.item.hash, 'b/1', '新条目要能越过旧游标')
  assert.equal(second.seq, 2)
})

test('poll：脏游标当 0 处理，不回退 seq', () => {
  const queue = new PlayQueue()
  queue.push({ id: 'a', hash: 'a/1' })
  assert.equal(queue.poll(NaN).item.hash, 'a/1')
  assert.equal(queue.poll(undefined).item.hash, 'a/1')
  assert.equal(queue.poll('').item.hash, 'a/1')
  assert.equal(queue.poll(-5).item.hash, 'a/1')
  assert.equal(queue.poll(99).item, null)
  assert.equal(queue.seq, 1, 'poll 不该改动 seq')
})

test('poll：超过 TTL 的待播不再投递', async () => {
  const queue = new PlayQueue({ ttlMs: 30 })
  queue.push({ id: 'a', hash: 'a/1', title: '早就忘了的一首' })
  assert.notEqual(queue.poll(0).item, null, '刚推的应当立刻可取')
  await new Promise((resolve) => setTimeout(resolve, 60))
  assert.equal(queue.poll(0).item, null, '过期后不该再推给前端')
  assert.equal(queue.seq, 1, '过期不影响 seq —— 回退会让游标错乱')
})

test('clear：清掉待播但不动 seq', () => {
  const queue = new PlayQueue()
  queue.push({ id: 'a', hash: 'a/1' })
  queue.clear()
  assert.equal(queue.current, null)
  assert.equal(queue.poll(0).item, null)
  assert.equal(queue.seq, 1)
  queue.push({ id: 'b', hash: 'b/1' })
  assert.equal(queue.seq, 2)
})

test('非法 ttl 退回默认值', () => {
  assert.equal(new PlayQueue({ ttlMs: 0 }).ttlMs, 120_000)
  assert.equal(new PlayQueue({ ttlMs: -1 }).ttlMs, 120_000)
  assert.equal(new PlayQueue({ ttlMs: 'x' }).ttlMs, 120_000)
  assert.equal(new PlayQueue({ ttlMs: 5000 }).ttlMs, 5000)
})
