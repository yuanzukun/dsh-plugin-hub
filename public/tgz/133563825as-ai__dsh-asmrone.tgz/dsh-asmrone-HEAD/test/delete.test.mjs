/**
 * 删除的回归测试。
 *
 * 这是整个插件里唯一会**销毁用户数据**的功能，所以用例集中在「不该删的绝对不许删」：
 * 根目录本身、根外的路径、穿越写法、软链指向外面 —— 每一条都单独钉住。
 *
 * 全部在临时目录里跑，不碰真实设备。
 */

import assert from 'node:assert/strict'
import { existsSync, mkdirSync, mkdtempSync, readdirSync, rmSync, symlinkSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import test from 'node:test'

import { LocalLibrary } from '../src/local.js'

/** 造两部作品：甲有两轨，乙有两轨 + 一张封面图（非音频，但整部删要连它一起收）。 */
function fixture () {
  const root = mkdtempSync(join(tmpdir(), 'asmrone-del-'))
  const album = join(root, 'RJ01111111_作品甲')
  const other = join(root, 'RJ02222222_作品乙')
  mkdirSync(album, { recursive: true })
  mkdirSync(other, { recursive: true })
  writeFileSync(join(album, '01.mp3'), 'a1')
  writeFileSync(join(album, '02.mp3'), 'a2')
  writeFileSync(join(other, '01.wav'), 'b1')
  writeFileSync(join(other, '02.wav'), 'b2')
  writeFileSync(join(other, 'cover.jpg'), 'not-audio')
  return { root, album, other }
}

const libraryOf = (root) => new LocalLibrary({
  store: { get: () => ({ outputDir: root, localDirs: [] }) },
  ttlMs: 0
})

test('删单轨：只掉一个文件，目录还在', (t) => {
  const { root, album } = fixture()
  t.after(() => rmSync(root, { recursive: true, force: true }))

  const library = libraryOf(root)
  const work = library.scan().works.find((row) => row.name.includes('作品甲'))
  const result = library.remove([{ key: work.key, indexes: [1] }])

  assert.equal(result.totals.files, 1)
  assert.equal(result.results[0].status, 'removed')
  assert.equal(result.results[0].wholeWork, false)
  assert.equal(existsSync(join(album, '01.mp3')), false, '第 1 轨应该没了')
  assert.equal(existsSync(join(album, '02.mp3')), true, '第 2 轨不该被动')
  assert.equal(existsSync(album), true, '只删一轨不该收掉目录')
})

test('删整部：音频清空后目录连封面一起收掉', (t) => {
  const { root, other } = fixture()
  t.after(() => rmSync(root, { recursive: true, force: true }))

  const library = libraryOf(root)
  const work = library.scan().works.find((row) => row.name.includes('作品乙'))
  const result = library.remove([{ key: work.key, indexes: [] }])

  assert.equal(result.totals.files, 2, '只算音频，封面不算轨')
  assert.equal(result.results[0].dirRemoved, true)
  assert.equal(result.results[0].wholeWork, true)
  assert.equal(existsSync(other), false, '整部删要把目录一起收掉')
})

test('批量删：一次多部，各自独立结算', (t) => {
  const { root, album, other } = fixture()
  t.after(() => rmSync(root, { recursive: true, force: true }))

  const library = libraryOf(root)
  const works = library.scan().works
  assert.equal(works.length, 2)

  const result = library.remove(works.map((work) => ({ key: work.key, indexes: [] })))
  assert.equal(result.totals.targets, 2)
  assert.equal(result.totals.works, 2)
  assert.equal(result.totals.files, 4)
  assert.equal(existsSync(album), false)
  assert.equal(existsSync(other), false)
  // 根目录本身必须还在 —— 这是最容易被写错的一条。
  assert.equal(existsSync(root), true, '根目录永远不许被删')
  assert.deepEqual(readdirSync(root), [])
})

test('dryRun：只算不删，一个字节都不动', (t) => {
  const { root, album } = fixture()
  t.after(() => rmSync(root, { recursive: true, force: true }))

  const library = libraryOf(root)
  const work = library.scan().works.find((row) => row.name.includes('作品甲'))
  const result = library.remove([{ key: work.key, indexes: [] }], { dryRun: true })

  assert.equal(result.dryRun, true)
  assert.equal(result.totals.files, 2, '预演也要报出正确的数量')
  assert.equal(existsSync(album), true, '预演不许动盘')
  assert.equal(existsSync(join(album, '01.mp3')), true)
})

test('根目录不会被任何一个 key 删掉', (t) => {
  const { root } = fixture()
  t.after(() => rmSync(root, { recursive: true, force: true }))

  const library = libraryOf(root)
  // 直接拿根目录当目标：resolveDirWithin 必须拒绝「等于根本身」。
  assert.equal(library.resolveDirWithin(root), null, '根目录本身必须不被放行')
  // 造一个 key 指向根目录（文件直接堆在根下的情况），删它也不该动目录。
  const strays = join(root, 'lonely.mp3')
  writeFileSync(strays, 'x')
  const works = library.scan().works
  const work = works.find((row) => row.dir === root)
  if (work !== undefined) {
    library.remove([{ key: work.key, indexes: [] }])
    assert.equal(existsSync(root), true, '文件堆在根下时，删文件但根必须留着')
  }
})

test('路径穿越与根外路径一律拒绝', (t) => {
  const { root } = fixture()
  const outside = mkdtempSync(join(tmpdir(), 'asmrone-outside-'))
  writeFileSync(join(outside, 'secret.mp3'), 'secret')
  t.after(() => {
    rmSync(root, { recursive: true, force: true })
    rmSync(outside, { recursive: true, force: true })
  })

  const library = libraryOf(root)
  assert.equal(library.resolveDirWithin(outside), null, '根外目录不放行')
  assert.equal(library.resolveDirWithin(`${root}/../`), null, '穿越写法不放行')
  assert.equal(library.resolveDirWithin(''), null)
  assert.equal(library.resolveDirWithin('relative/path'), null, '相对路径不放行')

  // 根里塞一个指向外面的软链：realpath 之后必须落到根外，于是被拒。
  const link = join(root, 'escape')
  try {
    symlinkSync(outside, link)
    assert.equal(library.resolveDirWithin(link), null, '软链指向根外必须被挡')
  } catch {
    // 环境不允许建软链就跳过这一条，不影响其余断言
  }
  assert.equal(existsSync(join(outside, 'secret.mp3')), true, '外面那个文件必须毫发无伤')
})

test('未知 key 报 missing，不会顺手动到别的作品', (t) => {
  const { root, album } = fixture()
  t.after(() => rmSync(root, { recursive: true, force: true }))

  const library = libraryOf(root)
  const result = library.remove([{ key: '0:/nowhere/at/all', indexes: [] }])

  assert.equal(result.results[0].status, 'missing')
  assert.equal(result.totals.files, 0)
  assert.equal(existsSync(join(album, '01.mp3')), true)
})

test('删完立刻作废扫描缓存（否则面板还列着刚删掉的东西）', (t) => {
  const { root } = fixture()
  t.after(() => rmSync(root, { recursive: true, force: true }))

  const library = libraryOf(root)
  const before = library.scan().works.length
  assert.equal(before, 2)

  const work = library.scan().works[0]
  library.remove([{ key: work.key, indexes: [] }])

  const after = library.scan().works.length
  assert.equal(after, 1, '缓存必须已经失效，重扫应少一部')
})
