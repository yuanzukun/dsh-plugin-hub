/**
 * DLsite 官方试听抓取。
 *
 * ## 试听藏在哪
 *
 * DLsite 作品页的试听不是 HTML 里的 `<audio src>`，而是 Nuxt payload 里的一个
 * 无服务器序列化数组：`"trials":<索引>`，指向同一数组里的元素，元素本身又可能是
 * 指向别的索引的指针。展开后形状是：
 *
 * ```json
 * [{ "extension": "zip", "file_size_unit": "50.19MB",
 *    "url": "//trial.dlsite.com/doujin/RJ01727000/RJ01726233_trial.zip" }]
 * ```
 *
 * 所以「试听」其实是 **zip 包**，不是单个 mp3 —— 早期按 `.mp3` 拼 URL 全部 404，
 * 就是因为后缀猜错了。
 *
 * ## 两条路径
 *
 * 1. **touch 页 payload**（`maniax-touch/work/=/product_id/<RJ>.html`）—— 走这个，
 *    不用登录，`trials` 字段直接给 zip 地址。
 * 2. `play.dlsite.com/api/viewer/work/<RJ>` —— 只有元数据（`sample_type: "image"` 那类），
 *    拿不到音频，仅作佐证。
 *
 * ## 为什么自己解 zip
 *
 * 宿主机器不一定有 `unzip` / `7z`。Node 内置 `zlib.inflateRawSync` 足够解 deflate
 * 条目，于是这里实现一个最小 zip 读取器：只用中央目录、local header 和 inflate，
 * 不碰加密、分卷、zip64 之外的花活。
 *
 * ## 文件名编码
 *
 * 老 DLsite 的 zip 用 CP932（Shift-JIS）存文件名，且不置 UTF-8 flag。Node 带 ICU
 * 时 `TextDecoder('shift_jis')` 可用，这里优先用它，失败再退 CP437 映射。
 *
 * @module dsh-asmrone/dlsite
 */

import { inflateRawSync } from 'node:zlib'

const EOCD_SIGNATURE = 0x06054b50
const CENTRAL_SIGNATURE = 0x02014b50
const LOCAL_SIGNATURE = 0x04034b50

/** 打 DLsite 时统一带的请求头。 */
const SITE_HEADERS = Object.freeze({
  // 手机 UA 是刻意的：PC 版页面在移动端也返回完整服务端渲染的 HTML，搜索页靠的就是这个。
  'user-agent': 'Mozilla/5.0 (Linux; Android 13) Chrome/120',
  accept: '*/*',
  'accept-language': 'ja,zh-CN;q=0.9',
  // R18 站点要这个 cookie 才给完整内容。给不上时页面会退化但不报错。
  cookie: 'adultchecked=1; locale=ja-jp'
})

/**
 * 值得重试的网络层错误。
 *
 * `fetch failed` 是 undici 那套连接错误的总称（DNS 失败、连接超时、连接被重置），
 * 它**不代表「被墙」**，在慢速链路上极其常见：宿主出口是手机上的 VPN，而 DLsite 又远。
 * 实测用户侧只有 20KB/s 时，取一次 400KB 的作品页经常断在半路 —— 而重试一次多半就过。
 */
const RETRYABLE = /fetch failed|ECONNRESET|ECONNREFUSED|ETIMEDOUT|EAI_AGAIN|ENOTFOUND|socket hang up|UND_ERR|network/i

/**
 * 跑一个取数任务，遇到网络层错误就退避重试。
 *
 * 只重试**网络层**的失败：`DLsite 返回 404` 这种服务器已经明确回答过的错误，
 * 重试一百次也是同一个答案。上限 3 次、退避 600ms 递增 —— 再久就更像是链路真的不通，
 * 该让用户看到错误去检查代理，而不是让请求挂在那里。
 *
 * @template T
 * @param {() => Promise<T>} task
 * @param {number} [attempts]
 * @returns {Promise<T>}
 */
export async function withRetry (task, attempts = 3) {
  let last
  for (let attempt = 1; attempt <= attempts; attempt++) {
    try {
      return await task()
    } catch (error) {
      last = error
      if (attempt === attempts || !RETRYABLE.test(String(error?.message ?? ''))) throw error
      await new Promise((resolve) => setTimeout(resolve, 600 * attempt))
    }
  }
  throw last
}

/** CP437 高半区映射表，用于没有 ICU 时的兜底解码。 */
const CP437_HIGH = 'ÇüéâäàåçêëèïîìÄÅÉæÆôöòûùÿÖÜ¢£¥₧ƒáíóúñÑªº¿⌐¬½¼¡«»░▒▓│┤╡╢╖╕╣║╗╝╜╛┐└┴┬├─┼╞╟╚╔╩╦╠═╬╧╨╤╥╙╘╒╓╫╪┘┌█▄▌▐▀αßΓπΣσµτΦΘΩδ∞φε∩≡±≥≤⌠⌡÷≈°∙·√ⁿ²■ '

class ZipError extends Error {}

/**
 * 解一个 CP437 / Shift-JIS 文件名。
 * @param {Buffer} bytes
 * @param {boolean} utf8Flagged
 * @returns {string}
 */
function decodeName (bytes, utf8Flagged) {
  if (utf8Flagged) return bytes.toString('utf8')
  try {
    return new TextDecoder('shift_jis').decode(bytes)
  } catch {
    let out = ''
    for (const byte of bytes) {
      out += byte < 0x80 ? String.fromCharCode(byte) : (CP437_HIGH[byte - 0x80] ?? '?')
    }
    return out
  }
}

/**
 * 从尾部找中央目录结尾记录。
 * @param {Buffer} buffer
 * @returns {number} EOCD 的偏移
 */
function findEndOfCentralDirectory (buffer) {
  const minOffset = Math.max(0, buffer.length - 0x10000 - 22)
  for (let offset = buffer.length - 22; offset >= minOffset; offset--) {
    if (buffer.readUInt32LE(offset) === EOCD_SIGNATURE) return offset
  }
  throw new ZipError('不是有效的 zip：找不到中央目录结尾记录')
}

/**
 * 中央目录条目：只有元信息，没有数据。
 * @typedef {{name: string, method: number, compressedSize: number, uncompressedSize: number, localOffset: number, encrypted: boolean}} ZipEntry
 */

/**
 * 解析中央目录。
 *
 * 抽成独立函数是因为读 zip 有两条路：本地整包（`readZip`）与远端分段（`RemoteZip`）。
 * 中央目录的解析规则一模一样，不该存在两份实现 —— 两处漂移是最难查的那种 bug。
 *
 * @param {Buffer} buffer 覆盖住中央目录的缓冲
 * @param {number} cdOffset 中央目录在**整份文件**里的偏移
 * @param {number} cdBase buffer[0] 对应的文件偏移（整包读取时为 0）
 * @param {number} entryCount
 * @returns {ZipEntry[]}
 */
function parseCentralDirectory (buffer, cdOffset, cdBase, entryCount) {
  let cursor = cdOffset - cdBase
  const entries = []

  for (let index = 0; index < entryCount; index++) {
    if (cursor + 46 > buffer.length || buffer.readUInt32LE(cursor) !== CENTRAL_SIGNATURE) {
      throw new ZipError(`中央目录第 ${index} 条损坏`)
    }
    const flags = buffer.readUInt16LE(cursor + 8)
    const nameLength = buffer.readUInt16LE(cursor + 28)
    const extraLength = buffer.readUInt16LE(cursor + 30)
    const commentLength = buffer.readUInt16LE(cursor + 32)
    const nameBytes = buffer.subarray(cursor + 46, cursor + 46 + nameLength)
    entries.push({
      name: decodeName(nameBytes, (flags & 0x800) !== 0),
      method: buffer.readUInt16LE(cursor + 10),
      compressedSize: buffer.readUInt32LE(cursor + 20),
      uncompressedSize: buffer.readUInt32LE(cursor + 24),
      localOffset: buffer.readUInt32LE(cursor + 42),
      encrypted: (flags & 0x1) !== 0
    })
    cursor += 46 + nameLength + extraLength + commentLength
  }

  return entries
}

/** 加密条目直接拒掉：DLsite 的试听包从来不加密码，遇到就是结构不对。 */
function assertReadable (entry) {
  if (entry.encrypted) throw new ZipError(`条目「${entry.name}」被加密，无法解开`)
}

/**
 * 把一段压缩数据还原成原始字节。
 *
 * 长度一律取**中央目录**里的 `compressedSize`，不信本地头 —— 置了 data descriptor
 * （flags bit 3）的 zip 会把它在本地头里写成 0，照它读只会拿到空数据。
 */
function inflateEntry (raw, entry) {
  if (entry.method === 0) return Buffer.from(raw)
  if (entry.method === 8) return inflateRawSync(raw)
  throw new ZipError(`条目「${entry.name}」用了不支持的压缩方法 ${entry.method}（只支持 store / deflate）`)
}

/** 从「本地头 + 数据」的缓冲里定位数据段并解开。`base` 是 buffer[0] 对应的文件偏移。 */
function readEntryAt (buffer, entry, base) {
  const at = entry.localOffset - base
  if (at < 0 || at + 30 > buffer.length) {
    throw new ZipError(`条目「${entry.name}」的本地头不在取回的区间里`)
  }
  if (buffer.readUInt32LE(at) !== LOCAL_SIGNATURE) {
    throw new ZipError(`条目「${entry.name}」的本地头损坏`)
  }
  const dataStart = at + 30 + buffer.readUInt16LE(at + 26) + buffer.readUInt16LE(at + 28)
  const raw = buffer.subarray(dataStart, dataStart + entry.compressedSize)
  if (raw.length !== entry.compressedSize) {
    throw new ZipError(`条目「${entry.name}」数据不完整（期望 ${entry.compressedSize} 字节，实得 ${raw.length}）`)
  }
  return inflateEntry(raw, entry)
}

/**
 * 最小 zip 读取器：返回 `[{ name, data }]`，目录条目会被跳过。
 * @param {Buffer} buffer
 * @returns {Array<{name: string, data: Buffer}>}
 */
export function readZip (buffer) {
  const eocd = findEndOfCentralDirectory(buffer)
  const entryCount = buffer.readUInt16LE(eocd + 10)
  const cdOffset = buffer.readUInt32LE(eocd + 16)
  const files = []

  for (const entry of parseCentralDirectory(buffer, cdOffset, 0, entryCount)) {
    if (entry.name.endsWith('/')) continue
    assertReadable(entry)
    files.push({ name: entry.name, data: readEntryAt(buffer, entry, 0) })
  }

  return files
}

/** 拉尾部时一次取这么多 —— 要盖住 22 字节的 EOCD 加上最长 64KB 的 zip 注释。 */
const TAIL_SPAN = 0x10000 + 22

/**
 * 远端 zip 的随机读：**只取需要的那一条**，不把整包拉进内存。
 *
 * ## 为什么需要它
 *
 * 「整包下载 → 全部解压 → 驻留内存」在手机上代价极高：实测 100MB 的试听包解开后
 * 占 149MB（包里常有一轨未压缩的 wav），而 200MB+ 的大合集在这条路上直接没救 ——
 * 宿主机的可用内存只有 2GB 出头，硬吃会触发 OOM，那是会把 dsh 一起带走的事故。
 *
 * CloudFront 对这批 zip 支持 Range（实测 `bytes=0-99` 回 206 且带 `content-range`），
 * 于是可以：拉尾部拿到中央目录 → 记下每一条的偏移 → 播放时只拉那一条并 inflate。
 * **内存占用从「整包」降到「当前轨」**，于是体积上限不必再跟内存较劲。
 */
export class RemoteZip {
  #range
  #total = 0
  #entries = []

  /**
   * @param {(spec: string) => Promise<{buffer: Buffer, total: number}>} range
   *   `spec` 是 Range 头的值，形如 `"0-99"`（绝对区间）或 `"-65558"`（最后 N 字节）。
   */
  constructor (range) {
    this.#range = range
  }

  /**
   * 拉尾部、定位中央目录、建好条目表。
   * @param {(spec: string) => Promise<{buffer: Buffer, total: number}>} range
   */
  static async open (range) {
    const zip = new RemoteZip(range)
    const tail = await range(`-${TAIL_SPAN}`)
    zip.#total = tail.total

    const eocd = findEndOfCentralDirectory(tail.buffer)
    const entryCount = tail.buffer.readUInt16LE(eocd + 10)
    const cdOffset = tail.buffer.readUInt32LE(eocd + 16)
    const cdSize = tail.buffer.readUInt32LE(eocd + 12)
    const tailBase = tail.total - tail.buffer.length

    // 中央目录通常就落在刚拉回来的这一块里 —— 能省一次请求就省。
    if (cdOffset >= tailBase) {
      zip.#entries = parseCentralDirectory(tail.buffer, cdOffset, tailBase, entryCount)
    } else {
      const cd = await range(`${cdOffset}-${cdOffset + cdSize - 1}`)
      zip.#entries = parseCentralDirectory(cd.buffer, cdOffset, cdOffset, entryCount)
    }

    return zip
  }

  /** 全部条目（含目录条目，调用方自己过滤）。 */
  get entries () {
    return this.#entries
  }

  /** 整个 zip 的字节数。 */
  get totalSize () {
    return this.#total
  }

  /**
   * 取一条的内容。
   *
   * 两次请求：先 30 字节定长头拿变长字段的长度，再按算出的区间取数据。
   * 本地头里的 filename / extra 长度**不能**用中央目录里那份代替 ——
   * 两边常常不一样（extra 字段各家写法不同），照抄会算错数据起点。
   */
  async read (entry) {
    assertReadable(entry)
    if (entry.compressedSize === 0) return Buffer.alloc(0)

    const head = await this.#range(`${entry.localOffset}-${entry.localOffset + 29}`)
    if (head.buffer.length < 30) {
      throw new ZipError(`条目「${entry.name}」的本地头取不回来`)
    }
    const dataStart = entry.localOffset + 30 + head.buffer.readUInt16LE(26) + head.buffer.readUInt16LE(28)
    const body = await this.#range(`${dataStart}-${dataStart + entry.compressedSize - 1}`)
    return inflateEntry(body.buffer, entry)
  }
}

/**
 * 展开 Nuxt payload 里的无服务器序列化引用。
 * @param {any[]} array
 * @param {any} value
 * @param {number} [depth]
 * @returns {any}
 */
function deref (array, value, depth = 0) {
  if (depth > 6) return value
  if (typeof value === 'number' && Number.isInteger(value) && value >= 0 && value < array.length) {
    return deref(array, array[value], depth + 1)
  }
  if (Array.isArray(value)) return value.map((item) => deref(array, item, depth + 1))
  if (value !== null && typeof value === 'object') {
    const out = {}
    for (const [key, item] of Object.entries(value)) out[key] = deref(array, item, depth + 1)
    return out
  }
  return value
}

export class DlsiteTrialClient {
  /**
   * @param {object} options
   * @param {string} options.trialBaseUrl
   * @param {number} options.timeoutMs
   */
  constructor (options) {
    this.trialBaseUrl = String(options.trialBaseUrl).replace(/\/+$/, '')
    // 试听包在 trial 子域，作品页与搜索在 PC 站 —— 不是同一个 host，别混用。
    this.siteBaseUrl = String(options.siteBaseUrl ?? 'https://www.dlsite.com').replace(/\/+$/, '')
    this.timeoutMs = options.timeoutMs
  }

  async #fetch (url, { as = 'text', timeoutMs } = {}) {
    return withRetry(async () => {
      const controller = new AbortController()
      const timer = setTimeout(() => controller.abort(), timeoutMs ?? this.timeoutMs)
      try {
        const response = await fetch(url, { signal: controller.signal, headers: SITE_HEADERS })
        if (!response.ok) throw new Error(`DLsite 返回 ${response.status}（${url}）`)
        if (as === 'buffer') return Buffer.from(await response.arrayBuffer())
        return await response.text()
      } catch (error) {
        if (error?.name === 'AbortError') throw new Error(`DLsite 请求超时：${url}`)
        throw error
      } finally {
        clearTimeout(timer)
      }
    })
  }

  /**
   * 分段取一段字节，返回数据与整个文件的长度。
   *
   * `spec` 直接拼进 `Range` 头，所以两种写法都收：`"0-99"`（绝对区间）与
   * `"-65558"`（最后 N 字节）—— 后者把「先问总长、再拉尾部」合成了一次请求。
   */
  async #fetchRange (url, spec, timeoutMs) {
    return withRetry(async () => {
      const response = await fetch(url, {
        signal: AbortSignal.timeout(timeoutMs ?? Math.max(this.timeoutMs, 60000)),
        headers: { ...SITE_HEADERS, range: `bytes=${spec}` }
      })
      if (!response.ok) throw new Error(`DLsite 返回 ${response.status}（Range ${spec}）`)

      const buffer = Buffer.from(await response.arrayBuffer())
      // 回 200 就是整包 —— 那正是这条路径要躲开的东西，不能把它当成成功：
      // 真拉全了会直接顶爆内存，宁可在这里报错。
      if (response.status !== 206) {
        throw new Error(`DLsite 没有按分段返回（Range ${spec} → ${response.status}，${buffer.length} 字节）`)
      }
      const total = Number(/\/(\d+)\s*$/.exec(response.headers.get('content-range') ?? '')?.[1] ?? 0)
      return { buffer, total }
    })
  }

  /**
   * 打开远端试听 zip 做**分段读** —— 不把整包拉进内存。
   * @param {string} zipUrl
   * @returns {Promise<RemoteZip>}
   */
  async openZip (zipUrl) {
    return RemoteZip.open((spec) => this.#fetchRange(zipUrl, spec))
  }

  /**
   * 搜 DLsite 作品。
   *
   * 走 **PC 版搜索页**（`/maniax/fsr/=/key/value/...`），因为它是服务端渲染的；
   * 手机上那版（`maniax-touch`）把结果塞在客户端状态里，抓下来解析不出列表。
   *
   * 实测（2026-10-05）支持的路径参数：
   *   `keyword` / `sex_category[0]`（male|female）/ `order[0]`（release_d 等）/
   *   `page` / `per_page`（默认 30，最大 100）
   *
   * @param {{keyword: string, page?: number, perPage?: number, sort?: string, sexCategory?: string}} options
   */
  async search (options = {}) {
    const asked = String(options.keyword ?? '').trim()
    if (asked === '') throw new Error('搜索关键词不能为空')
    // 中文输入自动落到日文关键词上 —— 否则「萝莉」这种在日文站上是 0 命中。
    const keyword = expandKeyword(asked)

    const page = Math.max(1, Number(options.page) || 1)
    const perPage = Math.min(Math.max(Number(options.perPage) || 30, 10), 100)

    const segments = [`keyword/${encodeURIComponent(keyword)}`]
    if (options.sexCategory) segments.push(`sex_category%5B0%5D/${options.sexCategory}`)
    if (options.sort) segments.push(`order%5B0%5D/${options.sort}`)
    if (page > 1) segments.push(`page/${page}`)
    if (perPage !== 30) segments.push(`per_page/${perPage}`)

    const url = `${this.siteBaseUrl}/maniax/fsr/=/${segments.join('/')}`
    const html = await this.#fetch(url, { timeoutMs: Math.max(this.timeoutMs, 30000) })
    const works = parseSearchResults(html)
    // 把用户原话也带回去：面板要显示「你搜的是「萝莉」，实际搜的是「ロリ」」。
    return { keyword, asked, translated: keyword !== asked, page, perPage, works, hasMore: works.length >= perPage }
  }

  /**
   * 取作品名与该作品的试听包列表。
   * @param {string} workno - 形如 `RJ01726233`
   * @returns {Promise<{workno: string, title: string, trials: Array<{url: string, sizeText: string, sizeMb: number}>}>}
   */
  async workInfo (workno) {
    const normalized = normalizeWorkno(workno)
    const url = `${this.siteBaseUrl}/maniax-touch/work/=/product_id/${normalized}.html`
    const html = await this.#fetch(url)

    const match = /<script[^>]*id="__NUXT_DATA__"[^>]*>([\s\S]*?)<\/script>/.exec(html)
    if (match === null) throw new Error(`${normalized} 的 touch 页解析失败（没有 NUXT_DATA）`)

    let payload
    try {
      payload = JSON.parse(match[1])
    } catch (error) {
      throw new Error(`${normalized} 的 payload 不是合法 JSON：${error.message}`)
    }

    const titleMatch = new RegExp(`"${normalized}","([^"]{4,300})"`).exec(html)
    let title = normalized
    if (titleMatch !== null) {
      try {
        title = JSON.parse(`"${titleMatch[1]}"`)
      } catch {
        title = titleMatch[1]
      }
    }

    const trialsIndex = /"trials":(\d+)/.exec(html)
    const trials = trialsIndex === null
      ? []
      : (deref(payload, payload[Number(trialsIndex[1])]) ?? [])

    const zips = (Array.isArray(trials) ? trials : [])
      .filter((trial) => typeof trial?.url === 'string' && trial.url.endsWith('.zip'))
      .map((trial) => {
        const sizeText = String(trial.file_size_unit ?? '')
        const numeric = Number(sizeText.replace(/[^0-9.]/g, '')) || 0
        return {
          url: trial.url.startsWith('http') ? trial.url : `https:${trial.url}`,
          sizeText,
          sizeMb: /GB/i.test(sizeText) ? numeric * 1024 : numeric
        }
      })

    return { workno: normalized, title, trials: zips }
  }

  /**
   * 下载一个试听包并解开，返回文件列表。
   * @param {string} zipUrl
   * @param {number} [maxMb] - 超过此体积直接跳过（返回空数组），避免拖爆手机。
   * @returns {Promise<Array<{name: string, data: Buffer}>>}
   */
  /**
   * 探一下 DLsite 通不通。
   *
   * **必须显式探**，不能在别处「网络失败就重试」：这条路依赖手机上的 VPN 开着，
   * 关掉时任何请求都会挂到超时才失败。面板与工具都靠这个先给一句人话，
   * 而不是让用户对着一个转圈等两分钟。
   *
   * @returns {Promise<{ok: boolean, status: number, ms: number, reason: string}>}
   */
  async reachable () {
    const started = Date.now()
    try {
      const controller = new AbortController()
      const timer = setTimeout(() => controller.abort(), 8000)
      const response = await fetch(`${this.trialBaseUrl}/`, {
        method: 'HEAD',
        signal: controller.signal,
        headers: { 'user-agent': 'Mozilla/5.0 (Linux; Android 13) Chrome/120' }
      })
      clearTimeout(timer)
      return { ok: true, status: response.status, ms: Date.now() - started, reason: '' }
    } catch (error) {
      return {
        ok: false,
        status: 0,
        ms: Date.now() - started,
        reason: /abort|timeout/i.test(String(error?.message ?? ''))
          ? 'DLsite 连接超时 —— 它是被墙的，需要手机上的代理/VPN 开着'
          : `DLsite 不可达：${error?.message ?? error}`
      }
    }
  }

  async fetchTrialFiles (zipUrl, maxMb = 400) {
    const buffer = await this.#fetch(zipUrl, { as: 'buffer', timeoutMs: Math.max(this.timeoutMs, 600000) })
    if (buffer.length / 1048576 > maxMb) {
      throw new Error(`试听包 ${(buffer.length / 1048576).toFixed(0)}MB 超过上限 ${maxMb}MB，已跳过`)
    }
    return readZip(buffer).map((entry) => ({
      name: entry.name.split('/').pop() ?? entry.name,
      data: entry.data
    }))
  }
}

/**
 * 中文 → 日文的关键词别名表。
 *
 * DLsite 是**日文站**，中文关键词基本搜不到东西：实测「萝莉」0 命中，
 * 而「ロリ」一大片。这里不做翻译，只把音声 / ASMR 圈最常输入的那些词对上，
 * 让中文输入也能直接用。
 *
 * 只覆盖「整词」—— 拆词会让「女仆咖啡」这种被切得莫名其妙，
 * 分词的情况交给下面按空白切的处理。
 */
const KEYWORD_ALIASES = new Map([
  ['萝莉', 'ロリ'],
  ['舔耳', '耳舐め'],
  ['耳舔', '耳舐め'],
  ['掏耳', '耳かき'],
  ['挖耳', '耳かき'],
  ['采耳', '耳かき'],
  ['耳骚', '耳舐め'],
  ['耳搔', '耳かき'],
  ['助眠', '睡眠'],
  ['安眠', '睡眠'],
  ['白噪音', 'ヒーリング'],
  ['雨声', '雨'],
  ['海浪', '波'],
  ['篝火', '焚き火'],
  ['猫耳', '猫耳'],
  ['女仆', 'メイド'],
  ['妹妹', '妹'],
  ['姐姐', 'お姉さん'],
  ['哥哥', 'お兄さん'],
  ['病娇', 'ヤンデレ'],
  ['治愈', '癒し'],
  ['低语', '囁き'],
  ['耳语', '囁き'],
  ['呼吸', '呼吸'],
  ['按摩', 'マッサージ'],
  ['洗头', 'シャンプー'],
  ['沐浴', 'お風呂'],
  ['催眠', '催眠'],
  ['ASMR', 'ASMR'],
  ['音声', 'ボイス']
])

/**
 * 把中文关键词换成 DLsite 认识的日文词。
 *
 * 两个层次：整串先试一次（「耳かき」这种本来就是日文的会原样返回），
 * 不中就按空白分词，能换的换、换不了的原样留着 —— 于是「萝莉 催眠」
 * 会变成「ロリ 催眠」。
 *
 * @param {string} input
 * @returns {string}
 */
export function expandKeyword (input) {
  const raw = String(input ?? '').trim()
  if (raw === '') return raw
  const whole = KEYWORD_ALIASES.get(raw)
  if (whole !== undefined) return whole
  return raw.split(/\s+/).map((part) => KEYWORD_ALIASES.get(part) ?? part).join(' ')
}

/** HTML 实体解码。搜索结果里的标题常带 `&amp;` / `&#39;` 这类。 */
function decodeEntities (text) {
  return String(text ?? '')
    .replace(/&quot;/g, '"')
    .replace(/&#0*39;/g, "'")
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&amp;/g, '&')
}

/**
 * 解析 DLsite 搜索结果页。
 *
 * **这是全项目最容易失效的一段代码** —— 它依赖 DLsite 的 HTML 结构，
 * 而不是什么稳定接口。所以：
 *   · 只认那些「一眼能看出是语义」的标记（`<dd class="work_name">`、
 *     `product_id/RJ…html`、`maker_name`、`work_price_base`）；
 *   · 每一项单独 try，抓不到就给空串，**不要因为一个字段的缺失整页报废**；
 *   · `test/dlsite.test.mjs` 里钉了一份实测 HTML 片段，改版时那里会先红。
 *
 * 分块靠 `split(/<dt[\s>]/)`。**别按 `work_name` 切** —— 封面图在它前面的 `<dt>` 里，
 * 那样切会把封面甩到上一块去（踩过）。实测 `<dt>` 与 `work_name` 各 30 个、一一对应，
 * 所以按 `<dt>` 切出来的每一块 = 一个完整条目（封面 + 分类 + 标题 + 社团 + 价格）。
 * 少数不含商品链接的噪声块在下面会被直接跳过。
 *
 * @param {string} html
 * @returns {Array<object>}
 */
export function parseSearchResults (html) {
  const blocks = String(html ?? '').split(/<dt[\s>]/).slice(1)
  const works = []
  const seen = new Set()

  for (const raw of blocks) {
    // 预览图地址在属性里是 `\/\/img...` 这种转义形态，先还原再匹配。
    const block = raw.replace(/\\\//g, '/')

    const rj = /product_id\/(RJ\d{4,})\.html/.exec(block)
    if (rj === null || seen.has(rj[1])) continue
    const workno = rj[1]
    seen.add(workno)

    const titleLink = /<a\s[^>]*product_id\/RJ\d{4,}\.html"[^>]*title="([^"]*)"/.exec(block)
    const titleText = /<a\s[^>]*product_id\/RJ\d{4,}\.html"[^>]*>([^<]*)<\/a>/.exec(block)
    const circle = /class="maker_name"[\s\S]*?<a[^>]*>([^<]+)<\/a>/.exec(block)
    const voice = /class="author"[\s\S]*?<a[^>]*>([^<]+)<\/a>/.exec(block)
    const category = /class="work_category[^"]*"[^>]*>\s*<a[^>]*>([^<]+)<\/a>/.exec(block)
    const price = /class="work_price_base">([^<]*)</.exec(block)
    const coverMatch = /\/\/img\.dlsite\.jp[^"'\s]*?_img_main\.jpg/.exec(block)

    works.push({
      workno,
      title: decodeEntities(titleLink?.[1] ?? titleText?.[1] ?? workno),
      circle: decodeEntities(circle?.[1] ?? ''),
      voice: decodeEntities(voice?.[1] ?? ''),
      category: decodeEntities(category?.[1] ?? ''),
      price: decodeEntities(price?.[1] ?? '').trim(),
      cover: coverMatch === null ? '' : `https:${coverMatch[0]}`,
      url: `${'https://www.dlsite.com'}/maniax/work/=/product_id/${workno}.html`
    })
  }

  return works
}

/**
 * 把 `RJ1726233` / `rj01650453` / `1650453` / 整条 DLsite 链接 / 一段分享文本，
 * 统一成 `RJ01650453`。
 *
 * **优先按 `RJ\d+` 形态匹配**：用户多半是从手机浏览器里复制一整条链接或分享文本
 * 过来，那种串里除了 RJ 号还可能有别的数字（`?p=3`、`locale=zh_CN` 之类）。
 * 早期实现是「把串里所有数字抠出来拼一起」，遇到这种 URL 会拼出 `RJ016504533`
 * 这种鬼东西 —— 查不到、也不报错，最难查。所以现在先认 RJ 形态，
 * 认不到才退化成纯数字（用户手打 1650453 的情况）。
 *
 * @param {string} input
 * @returns {string}
 */
export function normalizeWorkno (input) {
  const raw = String(input ?? '')

  const rj = /RJ\s*0*(\d{3,})/i.exec(raw)
  if (rj !== null) return `RJ${rj[1].padStart(8, '0')}`

  const digits = raw.replace(/[^0-9]/g, '')
  if (digits === '' || digits.length > 12) {
    throw new Error(`无法从「${raw.slice(0, 60)}」里认出 RJ 号`)
  }
  return `RJ${digits.padStart(8, '0')}`
}
