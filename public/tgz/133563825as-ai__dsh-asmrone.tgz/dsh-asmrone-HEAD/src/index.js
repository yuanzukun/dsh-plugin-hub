/**
 * dsh-asmrone —— 把 asmr.one 的音声曲库接进 DeepSeek Harness。
 *
 * 注册十个模型可见工具：
 * - `asmr_search`   —— 搜作品（关键词 / 排序 / 分页 / 中文版筛选 / 性别过滤）
 * - `asmr_work`     —— 看某部作品的音轨树，可顺带探测体积
 * - `asmr_play`     —— 取音轨播放直链（302 → CDN，支持 Range）
 * - `bili_search`   —— 在 B 站搜音轨（**不用代理就能直连**，助眠向存量极大）
 * - `bili_play`     —— 流式播放 B 站音轨（**不下载、不占磁盘**）
 * - `asmr_download` —— 批量下载音频到本机目录，跳过已存在文件
 * - `asmr_trial`    —— 抓 DLsite 官方免费试听包（自带 zip 解压与 Shift-JIS 文件名修复）
 * - `asmr_delete`   —— 删掉已下载的内容（单轨 / 整部 / 批量），默认先预演
 * - `asmr_config`   —— 查看与修改偏好，并可直接列 asmr.one 的标签表
 *
 * ## 两条硬约束
 *
 * **一、运行期零依赖。** 只 import Node 内置模块。装了插件的人不需要往插件目录里
 * 塞 `node_modules` 软链，也就不会有「在插件目录跑一次 npm install 却写进了宿主
 * node_modules」这类事故。`define-tool.js` 顶部有完整说明。
 *
 * **二、不内置内容偏好。** 插件不预设任何题材倾向：性别过滤、默认排序、落盘目录
 * 全部来自容器里的 JSON 配置（`<DSH_HOME>/asmrone/config.json`），用 `asmr_config`
 * 随时可查可改，改完立即生效。
 *
 * @module dsh-asmrone
 */

import { mkdirSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'

import { AsmrOneApi } from './api.js'
import { BilibiliClient } from './bilibili.js'
import { DlsiteTrialClient } from './dlsite.js'
import { DohResolver, installDohLookup, isDlsiteHost } from './doh.js'
import { registerRoutes } from './http.js'
import { LocalLibrary } from './local.js'
import { PlayQueue } from './pending.js'
import { TrialLibrary } from './trial.js'
import { AsmrStore, resolveDshHome } from './store.js'
import { createBiliPlayTool } from './tools/bili-play.js'
import { createBiliSearchTool } from './tools/bili-search.js'
import { createConfigTool } from './tools/config.js'
import { createDeleteTool } from './tools/delete.js'
import { createDownloadTool } from './tools/download.js'
import { createLocalTool } from './tools/local.js'
import { createPlayTool } from './tools/play.js'
import { createSearchTool } from './tools/search.js'
import { createTrialTool } from './tools/trial.js'
import { createWorkTool } from './tools/work.js'

export const name = 'dsh-asmrone'

/** 需要工具注册表才能挂上工具。 */
export const inject = ['tools']

/** 基础设施默认值。用 profile 的 `cordis.patch.yml` 覆盖（见随包的 `cordis.patch.yml`）。 */
const CONFIG_DEFAULTS = Object.freeze({
  apiBaseUrl: 'https://api.asmr.one',
  siteBaseUrl: 'https://asmr.one',
  dlsiteTrialBaseUrl: 'https://trial.dlsite.com',
  bilibiliBaseUrl: 'https://api.bilibili.com',
  dohEndpoint: 'https://doh.pub/dns-query',
  trialMaxWorks: 2,
  // 分段读之后这个数不再跟内存挂钩 —— 打开只拉中央目录，内容按需取。
  // 它只剩「别让人误点一个几 GB 的东西」这一层意思。
  trialMaxMb: 800,
  // 单轨仍要整轨驻留才能切片（deflate 不支持随机访问），所以这道闸门留着。
  trialMaxTrackMb: 200,
  timeoutMs: 45000,
  downloadConcurrency: 4,
  outputDir: ''
})

function pickString (value, fallback) {
  return typeof value === 'string' && value.trim() !== '' ? value.trim() : fallback
}

function pickPositiveNumber (value, fallback) {
  const number = Number(value)
  return Number.isFinite(number) && number > 0 ? number : fallback
}

function resolveConfig (config) {
  const raw = config !== null && typeof config === 'object' ? config : {}
  return {
    apiBaseUrl: pickString(raw.apiBaseUrl, CONFIG_DEFAULTS.apiBaseUrl),
    siteBaseUrl: pickString(raw.siteBaseUrl, CONFIG_DEFAULTS.siteBaseUrl),
    dlsiteTrialBaseUrl: pickString(raw.dlsiteTrialBaseUrl, CONFIG_DEFAULTS.dlsiteTrialBaseUrl),
    bilibiliBaseUrl: pickString(raw.bilibiliBaseUrl, CONFIG_DEFAULTS.bilibiliBaseUrl),
    dohEndpoint: pickString(raw.dohEndpoint, CONFIG_DEFAULTS.dohEndpoint),
    // DLsite 的 DNS 在这台机器上被污染，不补这一层 online 试听整条不通。
    // 留着开关是为了「换到不污染的网络时能关掉」，默认开。
    dohEnabled: raw.dohEnabled !== false,
    trialMaxWorks: pickPositiveNumber(raw.trialMaxWorks, CONFIG_DEFAULTS.trialMaxWorks),
    trialMaxMb: pickPositiveNumber(raw.trialMaxMb, CONFIG_DEFAULTS.trialMaxMb),
    trialMaxTrackMb: pickPositiveNumber(raw.trialMaxTrackMb, CONFIG_DEFAULTS.trialMaxTrackMb),
    timeoutMs: pickPositiveNumber(raw.timeoutMs, CONFIG_DEFAULTS.timeoutMs),
    downloadConcurrency: pickPositiveNumber(raw.downloadConcurrency, CONFIG_DEFAULTS.downloadConcurrency),
    outputDir: typeof raw.outputDir === 'string' ? raw.outputDir.trim() : CONFIG_DEFAULTS.outputDir
  }
}

/**
 * 插件入口。
 *
 * 外面套一层 try/catch 并把结果落到 `<DSH_HOME>/asmrone/boot.log`：
 * 插件加载失败时宿主通常只在启动日志里打一行，而那个日志在容器里并不好取。
 * 自己记一份，排查时直接读文件。
 *
 * @param {import('@deepseek-ai/cordis').Context} ctx
 * @param {object} [config]
 */
export function apply (ctx, config) {
  const trace = []
  const note = (line) => {
    trace.push(`[${new Date().toISOString()}] ${line}`)
  }

  try {
    const resolved = resolveConfig(config)
    note(`apply 进入，接口 ${resolved.apiBaseUrl}`)

    const api = new AsmrOneApi({
      apiBaseUrl: resolved.apiBaseUrl,
      siteBaseUrl: resolved.siteBaseUrl,
      dlsiteTrialBaseUrl: resolved.dlsiteTrialBaseUrl,
      timeoutMs: resolved.timeoutMs
    })

    // DLsite 是被墙的，容器的出网跟着手机那个 VPN 走 —— VPN 关着时整条不通，这层管不了。
    // 这层只管第二件事：**VPN 开着时，系统 DNS 仍然返回被污染的结果**
    // （`www.dlsite.com` 解析到 `2001::` 与 Dropbox 的 IP），换成 DoH 才能拿到真 IP。
    // 补丁只认 dlsite.com 后缀，其余域名原样走系统 DNS —— 影响面刻意压到最小；
    // 它挂在宿主 node 进程上，由下面的 dispose 还原，不碰任何系统文件。
    const doh = new DohResolver({ endpoint: resolved.dohEndpoint, timeoutMs: Math.min(resolved.timeoutMs, 6000) })
    const disposeDoh = resolved.dohEnabled ? installDohLookup({ resolver: doh, match: isDlsiteHost }) : () => {}
    note(`DoH 补丁 ${resolved.dohEnabled ? '已启用' : '已关闭'}（${resolved.dohEndpoint}）`)

    const dlsite = new DlsiteTrialClient({
      trialBaseUrl: resolved.dlsiteTrialBaseUrl,
      timeoutMs: resolved.timeoutMs
    })

    // B 站是容器里唯一直连可达的在线音源（其余都要魔法网络），所以它不是可选装饰。
    const bilibili = new BilibiliClient({
      baseUrl: resolved.bilibiliBaseUrl,
      timeoutMs: resolved.timeoutMs
    })

    const store = new AsmrStore({ ctx, config: resolved })
    note(`store 就绪，数据目录 ${store.dataRoot}`)

    const runtime = {
      api,
      dlsite,
      bilibili,
      store,
      // agent 推歌用的单槽队列。工具往里塞，Web 面板轮询取走并播放。
      pending: new PlayQueue(),
      // 本地音声库：离线时唯一的播放来源（asmr.one 没代理就整条不通）。
      library: new LocalLibrary({ store }),
      // DLsite 试听：zip 下进内存、解开、驻留，播放走 subarray 切片 —— 磁盘零占用。
      trial: new TrialLibrary({
        dlsite,
        store,
        maxWorks: resolved.trialMaxWorks,
        maxMb: resolved.trialMaxMb,
        maxTrackMb: resolved.trialMaxTrackMb
      }),
      doh,
      getConfig: () => store.get(),
      setConfig: (patch) => store.set(patch)
    }

    ctx.logger?.info?.(
      `dsh-asmrone: 接口 ${resolved.apiBaseUrl} · 落盘 ${store.get().outputDir} · 配置 ${store.configPath}`
    )

    ctx.effect(function* registerTools () {
      yield ctx.tools.register(createSearchTool(runtime))
      yield ctx.tools.register(createWorkTool(runtime))
      yield ctx.tools.register(createPlayTool(runtime))
      yield ctx.tools.register(createBiliSearchTool(runtime))
      yield ctx.tools.register(createBiliPlayTool(runtime))
      yield ctx.tools.register(createLocalTool(runtime))
      yield ctx.tools.register(createDeleteTool(runtime))
      yield ctx.tools.register(createDownloadTool(runtime))
      yield ctx.tools.register(createTrialTool(runtime))
      yield ctx.tools.register(createConfigTool(runtime))
      note('十个工具已注册')
    }, 'dsh-asmrone.tools')

    // Web 面板用的数据面。可选注入：headless profile 里没有 webServer，
    // 那种情况下六个工具照常可用，只是没有界面。
    note(`准备注入 webServer；ctx.inject 类型 = ${typeof ctx.inject}`)
    ctx.inject(['webServer'], (webCtx) => {
      note('webServer 注入回调触发')
      webCtx.effect(
        () => {
          const dispose = registerRoutes({ webServer: webCtx.webServer, runtime })
          note(`路由已挂载到 /asmrone（webServer.register 返回 ${typeof dispose}）`)
          return dispose
        },
        'dsh-asmrone: routes'
      )
    })

    note('apply 正常结束')
    return () => {
      note('apply dispose')
      disposeDoh()
      writeBootLog(trace)
    }
  } catch (error) {
    note(`apply 抛错：${error?.stack ?? error?.message ?? error}`)
    writeBootLog(trace)
    throw error
  } finally {
    writeBootLog(trace)
  }
}

/**
 * 把加载轨迹追加写到 `<DSH_HOME>/asmrone/boot.log`。
 * 写失败就算了 —— 绝对不能因为记日志把插件本身带崩。
 * @param {string[]} lines
 */
function writeBootLog (lines) {
  try {
    const dir = join(resolveDshHome(), 'asmrone')
    mkdirSync(dir, { recursive: true })
    writeFileSync(join(dir, 'boot.log'), `${lines.join('\n')}\n`, 'utf8')
  } catch {
    // 忽略
  }
}
