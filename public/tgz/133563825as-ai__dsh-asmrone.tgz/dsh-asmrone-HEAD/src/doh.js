/**
 * DoH 解析器 + 定向 DNS 补丁 —— 让容器能访问 DLsite。
 *
 * ## 为什么需要这个
 *
 * 实测（2026-10-05）容器里 `www.dlsite.com` 被解析到 `2001::6ca0:a21f` 和
 * `108.160.170.43`（后者是 Dropbox 的 IP），两个都是假的 —— 典型的 DNS 污染。
 * 解析到假 IP 之后 TCP 也连不上，表现为 curl 直接 000 超时。
 *
 * **但要分清两层，它们是「与」的关系：**
 *
 *   1. **能不能出去** —— DLsite 在大陆是被墙的（TCP 阻断 + DNS 污染）。
 *      容器的出网跟随**手机上的 VPN**：VPN 开着时链路才通（实测出口走 WARP，colo=LAX），
 *      关掉就整条不通。这一层本模块管不了。
 *   2. **出去之后找不找得到** —— 即使 VPN 开着，容器的系统 DNS（`8.8.8.8` /
 *      `223.5.5.5`）依然返回被污染的结果。换成 DoH 拿真实 IP 直连，`www.dlsite.com`
 *      立刻回 301。**这一层就是本模块要解决的。**
 *
 * 所以别把这里当成「绕过网络封锁」——它不是。它只保证「网络已经通了的时候，
 * 域名能解析到对的地方」。VPN 关着时本模块无能为力，上层要如实告诉用户，
 * 而不是让请求挂在那里等超时。
 *
 * ## 为什么打补丁而不是改系统
 *
 * 三条路都试过：
 *   · 改 `/etc/hosts` —— 简单，但 Cloudflare / AWS 的 IP 会轮换，写死迟早失效；
 *   · 起一个本地 DNS 服务改 `resolv.conf` —— 干净，但多一个常驻进程，
 *     而且它一挂整个容器就断网，代价和收益不成比例；
 *   · **打 `dns.lookup` 补丁** —— 只影响宿主这个 node 进程，只对匹配的域名生效，
 *     其余域名原样走系统 DNS。失败自动回退，不留后遗症。
 *
 * 选第三条。补丁是可逆的（`installDohLookup` 返回还原函数），进程重启即失效。
 *
 * @module dsh-asmrone/doh
 */

import dns from 'node:dns'

/** 默认用腾讯的 DoH。实测同一个域名，阿里 DoH 也返回被污染的结果，腾讯的才是真的。 */
export const DEFAULT_DOH_ENDPOINT = 'https://doh.pub/dns-query'

function normalizeHost (host) {
  return String(host ?? '').trim().toLowerCase().replace(/\.$/, '')
}

/**
 * 把域名解析到「没被污染的 IP」。
 *
 * 带正缓存与并发去重：一次播放可能连着问好几个域名，不能让它们各发一遍 DoH。
 */
export class DohResolver {
  #endpoint
  #timeoutMs
  #ttlMs
  #cache = new Map()
  #inflight = new Map()
  #hits = 0
  #misses = 0

  /**
   * @param {object} [options]
   * @param {string} [options.endpoint]
   * @param {number} [options.timeoutMs] 单次 DoH 查询超时，默认 6 秒
   * @param {number} [options.ttlMs] 解析结果缓存时长，默认 5 分钟
   */
  constructor (options = {}) {
    this.#endpoint = String(options.endpoint ?? DEFAULT_DOH_ENDPOINT)
    const timeout = Number(options.timeoutMs)
    this.#timeoutMs = Number.isFinite(timeout) && timeout > 0 ? timeout : 6000
    const ttl = Number(options.ttlMs)
    this.#ttlMs = Number.isFinite(ttl) && ttl > 0 ? ttl : 5 * 60 * 1000
  }

  get endpoint () {
    return this.#endpoint
  }

  /** 命中 / 未命中次数，自检脚本用。 */
  get stats () {
    return { hits: this.#hits, misses: this.#misses, cached: this.#cache.size }
  }

  /**
   * 解析 A 记录。查不到就返回空数组 —— **不要抛异常**：
   * 调用方（补丁）要的是「回退到系统解析」，而不是把请求直接打断。
   * @param {string} host
   * @returns {Promise<string[]>}
   */
  resolve (host) {
    const key = normalizeHost(host)
    if (key === '') return Promise.resolve([])

    const hit = this.#cache.get(key)
    if (hit !== undefined && hit.expiresAt > Date.now()) {
      this.#hits += 1
      return Promise.resolve(hit.ips)
    }

    const running = this.#inflight.get(key)
    if (running !== undefined) return running

    this.#misses += 1
    const task = this.#query(key)
      .then((ips) => {
        if (ips.length > 0) this.#cache.set(key, { ips, expiresAt: Date.now() + this.#ttlMs })
        return ips
      })
      .finally(() => { this.#inflight.delete(key) })

    this.#inflight.set(key, task)
    return task
  }

  async #query (host) {
    try {
      const response = await fetch(
        `${this.#endpoint}?name=${encodeURIComponent(host)}&type=A`,
        { headers: { accept: 'application/dns-json' }, signal: AbortSignal.timeout(this.#timeoutMs) }
      )
      if (!response.ok) return []
      const data = await response.json()
      return (Array.isArray(data?.Answer) ? data.Answer : [])
        .filter((answer) => Number(answer?.type) === 1 && typeof answer?.data === 'string')
        .map((answer) => answer.data)
        // 过滤掉明显的假答案：被污染的记录常落在这些段里
        .filter((ip) => !/^(0\.|127\.|2001::|::)/.test(ip))
    } catch {
      return []
    }
  }

  clear () {
    this.#cache.clear()
  }
}

/**
 * 把 `dns.lookup` 接到 DoH 上，只对 `match(hostname)` 为真的域名生效。
 *
 * 细节上要小心三件事：
 *   · 签名有两种形态（`(host, cb)` 和 `(host, options, cb)`），都得认；
 *   · 请求 `family: 6` 的调用方只认 IPv6，而我们查的是 A 记录 —— 直接原样放行，
 *     别拿一个 v4 地址去糊弄它，那会让 node 报 address family mismatch；
 *   · `options.all` 为真时要回数组而不是单值，否则 node 内部会炸。
 *
 * @param {object} options
 * @param {DohResolver} options.resolver
 * @param {(host: string) => boolean} options.match
 * @returns {() => void} 还原函数
 */
export function installDohLookup ({ resolver, match }) {
  if (typeof match !== 'function') throw new Error('installDohLookup 需要 match 函数')
  const original = dns.lookup
  let active = true

  const patched = function lookup (hostname, options, callback) {
    // `(hostname, callback)` 这种老式调用
    if (typeof options === 'function') {
      callback = options
      options = undefined
    }
    const opts = options ?? {}

    if (typeof callback !== 'function' || typeof hostname !== 'string' || !match(hostname)) {
      return original.call(dns, hostname, options, callback)
    }
    // 只要 IPv6 的调用方：查 A 记录救不了它，交给系统解析。
    if (Number(opts.family) === 6) {
      return original.call(dns, hostname, options, callback)
    }

    resolver.resolve(hostname).then((ips) => {
      if (!active || ips.length === 0) {
        original.call(dns, hostname, options, callback)
        return
      }
      if (opts.all === true) {
        callback(null, ips.map((address) => ({ address, family: 4 })))
        return
      }
      callback(null, ips[0], 4)
    }).catch(() => original.call(dns, hostname, options, callback))

    return undefined
  }

  dns.lookup = patched

  return () => {
    active = false
    if (dns.lookup === patched) dns.lookup = original
  }
}

/**
 * DLsite 各域名的匹配器。
 *
 * 只认这几个后缀，别的域名一律走系统 DNS —— 补丁的影响面越小越好。
 * `dlsite.com` 覆盖 www / trial / play / cdn / img / ch 全部子域。
 */
export function isDlsiteHost (hostname) {
  const host = normalizeHost(hostname)
  return host === 'dlsite.com' || host.endsWith('.dlsite.com')
}
