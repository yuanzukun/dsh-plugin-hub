/**
 * B 站音源 —— 容器里唯一能直连的在线音频来源。
 *
 * asmr.one / DLsite 都要魔法网络，猫耳 FM 与喜马拉雅的主页虽然可达，但接口撞
 * 阿里云 WAF 与 `riskLevel:5` 风控。实测（2026-10-05）只有 `api.bilibili.com`
 * 是直连 200、无需代理、无需登录的 —— 所以这条链路是「在线听」的现实解法。
 *
 * ## 音频怎么出来（不是下载，是流）
 *
 * `playurl?fnval=16` 给的是 **DASH 分离流**：视频轨与音频轨各一条 URL。
 * 我们只要 `dash.audio`，所以：
 *   · 不需要 ffmpeg、不需要合并 —— 音频轨本身就是完整的 fMP4（`ftyp` + `moov`
 *     在前，随后一串 `moof`/`mdat`），`<audio>` 直接能播，也能 seek；
 *   · 不需要把文件落到磁盘 —— `http.js` 的 `/asmrone/bili-stream` 只是把 Range
 *     原样转给 CDN，播放器要哪一段就拉哪一段。
 *
 * ## 三道门禁（少一道就是 403 或 412）
 *
 * **一、CDN 直链要「PC Chrome UA + Referer」**，两个都带才回 206。
 * 实测同一串带签名的 URL：PC UA + Referer → 206；Android UA + Referer → 403；
 * 空 UA + Referer → 403；不带 Referer → 403。响应体是 openresty 的裸 403 页，
 * 看不出原因，所以踩过一次就得记住（见 `PC_UA` 注释）。
 *
 * **二、搜索要 WBI 签名**，否则连发几个关键词就 412 风控。
 * 签名 = 参数按 key 排序 → URL 编码 → 拼 `wts` → 串上 mixin key 求 md5 当 `w_rid`。
 * mixin key 由 `nav` 接口给的两个 key 按固定 64 位表重排而成（见 `MIXIN_TAB`）。
 *
 * **三、匿名 ID 要带**（`buvid3` / `buvid4`）。不带的话签名也救不了，照样 412。
 *
 * 三件事都做了之后，实测连造 8 个关键词 0 次拦截。
 *
 * @module dsh-asmrone/bilibili
 */

import { createHash } from 'node:crypto'

/**
 * 电脑版 UA。
 *
 * **这个常量不是随手挑的**：B 站 CDN 对直链的 UA 卡得极死，换成 Android UA 或空 UA
 * 一律 403。必须原样带到**每一次** CDN 请求上，包括 Range 转发 —— 见文件头说明。
 */
export const PC_UA =
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36'

/** CDN 只认这个 Referer。注意结尾的斜杠，实测少了它也会掉到 403。 */
export const CDN_REFERER = 'https://www.bilibili.com/'

/**
 * WBI mixin key 的重排表。
 *
 * B 站官方前端里那张 64 项的固定表：把 `img_key + sub_key`（共 64 字符）按这张表
 * 取位、拼起来、取前 32 位，就是本次的 mixin key。表本身是常量，别改。
 */
const MIXIN_TAB = Object.freeze([
  46, 47, 18, 2, 53, 8, 23, 32, 15, 50, 10, 31, 58, 3, 45, 35, 27, 43, 5, 49,
  33, 9, 42, 19, 29, 28, 14, 39, 12, 38, 41, 13, 37, 48, 7, 16, 24, 55, 40, 61,
  26, 17, 0, 1, 60, 51, 30, 4, 22, 25, 54, 21, 56, 59, 6, 63, 57, 62, 11, 36,
  20, 34, 44, 52
])

/** 音频码率档，从高到低。30280 是 B 站给非会员的最高档。 */
export const AUDIO_QUALITIES = Object.freeze([30280, 30232, 30216])

/** 默认取最高档。流式播放不占磁盘，没理由省这个带宽。 */
export const DEFAULT_QUALITY = 30280

const QUALITY_TEXT = Object.freeze({
  30280: '192K',
  30232: '132K',
  30216: '64K'
})

/** 凭据（buvid3 + wbi key）的有效期。B 站按天轮换，6 小时刷新一次足够保守。 */
const CREDENTIAL_TTL_MS = 6 * 60 * 60 * 1000

/**
 * 直链提前作废的余量。
 *
 * API 返回的 `deadline` 是绝对时间戳，实测有效期 **120 分钟**。但我们不等到点：
 * 播放到一半直链过期，CDN 会回 403，表现为「放着放着自己断了」。留 5 分钟余量，
 * 到点前主动重取。
 */
const URL_EXPIRE_MARGIN_MS = 5 * 60 * 1000

/** 同一通道的最小请求间隔。签名能挡大部分风控，但连发依然会被限速。 */
const MIN_INTERVAL_MS = 350

function sleep (ms) {
  return new Promise((resolve) => setTimeout(resolve, ms))
}

/** 判断是不是传输层抖动（这类才值得重试）。 */
function isTransient (error) {
  const text = `${error?.message ?? ''} ${error?.cause?.code ?? ''} ${error?.cause?.message ?? ''}`
  return /fetch failed|ECONNRESET|ECONNREFUSED|EPIPE|ENOTFOUND|EAI_AGAIN|ETIMEDOUT|socket hang up|aborted|network/i.test(text)
}

/**
 * 去掉搜索结果标题里的高亮标签与 HTML 实体。
 *
 * B 站搜索返回的 title 形如 `8D全景声音环绕，432hz更舒缓更<em class="keyword">助眠雨声</em>-白噪音`，
 * 直接显示会漏出一堆标签。description 里也有同样的问题。
 */
export function stripTags (text) {
  return String(text ?? '')
    .replace(/<[^>]*>/g, '')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&amp;/g, '&')
    .trim()
}

/** 秒 → `1:23:45` / `45:12`。搜索结果里给的是字符串，详情接口给的是秒，两边都走这里。 */
export function formatDuration (totalSeconds) {
  const seconds = Math.max(0, Math.floor(Number(totalSeconds) || 0))
  const h = Math.floor(seconds / 3600)
  const m = Math.floor((seconds % 3600) / 60)
  const s = seconds % 60
  const pad = (n) => String(n).padStart(2, '0')
  return h > 0 ? `${h}:${pad(m)}:${pad(s)}` : `${m}:${pad(s)}`
}

/** `"45:12"` / `"1:23:45"` → 秒。搜索结果的 duration 是这个形状。 */
export function parseDurationText (text) {
  const parts = String(text ?? '').split(':').map((piece) => Number(piece))
  if (parts.length === 0 || parts.some((value) => !Number.isFinite(value))) return 0
  return parts.reduce((sum, value) => sum * 60 + value, 0)
}

/** 播放量：B 站给的是数字，超过一万前端自己缩写。这里只做类型兜底。 */
function normalizeCount (value) {
  const number = Number(value)
  return Number.isFinite(number) && number >= 0 ? number : 0
}

/** 图片地址补协议。搜索接口返回的是 `//i0.hdslb.com/...`。 */
function normalizePic (url) {
  const raw = String(url ?? '').trim()
  if (raw === '') return ''
  return raw.startsWith('//') ? `https:${raw}` : raw
}

/**
 * 把用户给的东西解析成 `{ bvid, page }`。
 *
 * 认这几种写法（agent 和面板都会从这里过）：
 *   · `BV1rE411P7ct`            BV 号，补到 12 位
 *   · `av97613422` / `97613422` av 号
 *   · `https://www.bilibili.com/video/BV1rE411P7ct?p=3`   完整链接（带分 P）
 *   · `BV1rE411P7ct?p=3`       带分 P 的裸串
 *
 * 返回 `{ bvid, aid, page }`：bvid 与 aid 二选一有值，page 从 1 起。
 */
export function parseRef (input) {
  const raw = String(input ?? '').trim()
  if (raw === '') return { bvid: '', aid: 0, page: 1 }

  // 分 P 参数：`?p=` 或 `&p=` 或裸的那串里带的
  const pageMatch = /[?&]p=(\d+)/i.exec(raw)
  const page = pageMatch === null ? 1 : Math.max(1, Number(pageMatch[1]))

  // URL 形态：先把 pathname 抠出来，避免把 query 里的字符串当 id
  const withoutQuery = raw.replace(/[?#].*$/, '')

  const bvMatch = /(BV[0-9A-Za-z]{10})/i.exec(withoutQuery)
  if (bvMatch !== null) {
    return { bvid: normalizeBvid(bvMatch[1]), aid: 0, page }
  }

  const avMatch = /(?:^|[^\d])(?:av)?(\d{3,})$/i.exec(withoutQuery)
  if (avMatch !== null) {
    return { bvid: '', aid: Number(avMatch[1]), page }
  }

  return { bvid: '', aid: 0, page }
}

/**
 * BV 号大小写归一：`bv1re411p7ct` → `BV1rE411P7ct`。
 *
 * BV 号是大小写敏感的 base58，全大写全小写都查不到，但用户手打时几乎不会照着原样敲。
 * 官方校验位算法太重，这里只做「首两位大写、其余按官方样例的常见形态原样」，
 * 真正权威的大小写还是靠 `view` 接口 404 来判定 —— 归一只是提高手输命中率。
 */
function normalizeBvid (value) {
  const raw = String(value).trim()
  if (/^BV/i.test(raw) === false) return raw
  // BV 后 10 位按原样，只把前缀 `bv` 抬成 `BV`
  return `BV${raw.slice(2)}`
}

/**
 * B 站客户端。
 *
 * 无状态以外的一切（凭据、直链）都在实例里缓存，因为：
 *   · 凭据每 6 小时才需要重取一次，但每次搜索/取流都要用；
 *   · 直链签名有 120 分钟寿命，重复取会白白多一批带签名的请求，更容易撞风控。
 */
export class BilibiliClient {
  #baseUrl
  #timeoutMs

  /** 凭据缓存：`buvid3` / `buvid4` / `img_key` / `sub_key` → mixin key。 */
  #credential = null
  #credentialAt = 0
  /** 凭据获取的并发锁：同时来十个请求，只能触发一次取凭据。 */
  #credentialPending = null

  /** 直链缓存：`bvid:cid:quality` → `{ url, backup, deadline, quality, mime }`。 */
  #streams = new Map()

  /** 请求闸门：上一次出网的时间戳，用于最小间隔。 */
  #lastRequestAt = 0
  /** 撞了 412 之后的退避截止时间。 */
  #backoffUntil = 0

  /**
   * @param {object} options
   * @param {string} [options.baseUrl] 默认 `https://api.bilibili.com`
   * @param {number} [options.timeoutMs]
   */
  constructor (options = {}) {
    this.#baseUrl = String(options.baseUrl ?? 'https://api.bilibili.com').replace(/\/+$/, '')
    const timeout = Number(options.timeoutMs)
    this.#timeoutMs = Number.isFinite(timeout) && timeout > 0 ? timeout : 20000
  }

  /** 视频页地址，给人点。 */
  videoUrl (bvid, page = 1) {
    const base = `https://www.bilibili.com/video/${bvid}`
    return page > 1 ? `${base}?p=${page}` : base
  }

  /** 当前缓存的直链条数（自检脚本用）。 */
  get cachedStreamCount () {
    return this.#streams.size
  }

  /* ── 传输层 ────────────────────────────────────────────── */

  /** 最小间隔闸门 + 412 退避。所有出网请求都从这里过。 */
  async #gate () {
    const now = Date.now()
    if (now < this.#backoffUntil) await sleep(this.#backoffUntil - now)
    const wait = MIN_INTERVAL_MS - (Date.now() - this.#lastRequestAt)
    if (wait > 0) await sleep(wait)
    this.#lastRequestAt = Date.now()
  }

  /**
   * 打一个 API 接口。
   *
   * @param {string} pathname
   * @param {object} params
   * @param {{ sign?: boolean, attempts?: number, referer?: string }} [options]
   *        sign=true 时走 WBI 签名（搜索/取流必须，其它接口可省）
   * @returns {Promise<any>} 接口的 `data` 字段
   */
  async #api (pathname, params, options = {}) {
    const attempts = Number(options.attempts) || 3
    let lastError = null

    for (let attempt = 1; attempt <= attempts; attempt++) {
      await this.#gate()
      const controller = new AbortController()
      const timer = setTimeout(() => controller.abort(), this.#timeoutMs)
      try {
        const query = options.sign === true
          ? this.#sign(params, await this.#credentials())
          : new URLSearchParams(
            Object.entries(params).map(([key, value]) => [key, String(value)])
          ).toString()

        const response = await fetch(`${this.#baseUrl}${pathname}?${query}`, {
          signal: controller.signal,
          headers: {
            'user-agent': PC_UA,
            referer: options.referer ?? CDN_REFERER,
            origin: 'https://www.bilibili.com',
            accept: 'application/json, text/plain, */*',
            'accept-language': 'zh-CN,zh;q=0.9',
            ...(this.#credential === null ? {} : { cookie: this.#credential.cookie })
          }
        })

        const text = await response.text()

        // 412 是风控：不是接口错误，是「你问太快了」。退避 30 秒后重试，
        // 并且把凭据作废 —— 实测过期的 buvid3 会稳定 412。
        if (response.status === 412) {
          this.#backoffUntil = Date.now() + 30_000
          this.#credential = null
          lastError = new Error('B 站风控拦截（412）。已自动退避，稍后重试。')
          continue
        }

        if (response.status === 429 || response.status >= 500) {
          lastError = new Error(`B 站接口返回 ${response.status}`)
          await sleep(600 * attempt)
          continue
        }

        let payload
        try {
          payload = JSON.parse(text)
        } catch {
          // 拿到的不是 JSON：多半是被风控页接管了。响应开头就是 HTML。
          lastError = new Error(`B 站接口返回了非 JSON 内容（HTTP ${response.status}）：${text.slice(0, 80)}`)
          continue
        }

        // `nav` 未登录时 code=-101，但 data 里带着我们需要的 wbi key —— 不能按失败处理。
        if (payload.code !== 0 && options.allowCodes?.includes(payload.code) !== true) {
          throw new Error(`B 站接口错误 ${payload.code}：${payload.message ?? ''}`)
        }
        return payload.data
      } catch (error) {
        lastError = error
        if (!isTransient(error) && !/风控|B 站接口返回/.test(error?.message ?? '')) throw error
      } finally {
        clearTimeout(timer)
      }
    }

    throw lastError ?? new Error('B 站接口请求失败')
  }

  /**
   * 取凭据：`buvid3` / `buvid4` + WBI 的两个 key。
   *
   * 两个接口都不需要登录，也都不需要签名 —— 这是整条链路唯一能不带签名打的地方。
   * 并发时只发一次（`#credentialPending` 锁），否则面板一开一屏请求会瞬间打满风控。
   */
  #credentials () {
    if (this.#credential !== null && Date.now() - this.#credentialAt < CREDENTIAL_TTL_MS) {
      return Promise.resolve(this.#credential)
    }
    if (this.#credentialPending !== null) return this.#credentialPending

    this.#credentialPending = (async () => {
      try {
        const headers = {
          'user-agent': PC_UA,
          referer: CDN_REFERER,
          origin: 'https://www.bilibili.com'
        }

        const spiResponse = await fetch(`${this.#baseUrl}/x/frontend/finger/spi`, { headers })
        const spi = await spiResponse.json()
        const buvid3 = String(spi?.data?.b_3 ?? '')
        const buvid4 = String(spi?.data?.b_4 ?? '')

        const navResponse = await fetch(`${this.#baseUrl}/x/web-interface/nav`, {
          headers: { ...headers, cookie: `buvid3=${buvid3}; buvid4=${buvid4}` }
        })
        const nav = await navResponse.json()
        const imgUrl = String(nav?.data?.wbi_img?.img_url ?? '')
        const subUrl = String(nav?.data?.wbi_img?.sub_url ?? '')

        if (imgUrl === '' || subUrl === '') {
          throw new Error('B 站没有下发 WBI key，无法签名（接口结构可能已变）')
        }

        const imgKey = imgUrl.split('/').pop().split('.')[0]
        const subKey = subUrl.split('/').pop().split('.')[0]
        const raw = `${imgKey}${subKey}`
        const mixinKey = MIXIN_TAB.map((index) => raw[index] ?? '').join('').slice(0, 32)

        this.#credential = {
          buvid3,
          buvid4,
          imgKey,
          subKey,
          mixinKey,
          cookie: `buvid3=${buvid3}; buvid4=${buvid4}`
        }
        this.#credentialAt = Date.now()
        return this.#credential
      } finally {
        this.#credentialPending = null
      }
    })()

    return this.#credentialPending
  }

  /**
   * WBI 签名。
   *
   * 步骤（顺序不能换）：参数拼上 `wts` 时间戳 → 按 key 字典序排 → 值过滤掉
   * `!'()*` 这几个字符 → URL 编码拼成 query → 串上 mixin key 求 md5 即 `w_rid`。
   *
   * `wts` 必须是**当前秒**，服务端会校验时间窗，旧的时间戳直接算签名错误。
   */
  #sign (params, credential) {
    const merged = { ...params, wts: Math.floor(Date.now() / 1000) }
    const query = Object.keys(merged)
      .sort()
      .map((key) => {
        const value = String(merged[key] ?? '').replace(/[!'()*]/g, '')
        return `${encodeURIComponent(key)}=${encodeURIComponent(value)}`
      })
      .join('&')
    const wRid = createHash('md5').update(`${query}${credential.mixinKey}`).digest('hex')
    return `${query}&w_rid=${wRid}`
  }

  /* ── 业务接口 ──────────────────────────────────────────── */

  /**
   * 搜视频。
   *
   * 注意 `total` 的上限是 **1000**（服务端硬顶），不是真实总量 —— 别拿它当「有多少部」。
   * 分页同样受这个上限约束（50 页 × 20 条）。
   *
   * @param {{ keyword?: string, page?: number, pageSize?: number, order?: string }} [options]
   */
  async search (options = {}) {
    const keyword = String(options.keyword ?? '').trim()
    const page = Math.max(1, Number(options.page) || 1)
    const pageSize = Math.min(Math.max(Number(options.pageSize) || 20, 1), 50)

    if (keyword === '') return { total: 0, page, pageSize, keyword, videos: [] }

    const data = await this.#api('/x/web-interface/wbi/search/type', {
      search_type: 'video',
      keyword,
      page,
      page_size: pageSize,
      order: options.order ?? 'totalrank'
    }, { sign: true })

    const items = Array.isArray(data?.result) ? data.result : []
    const videos = items
      .filter((item) => item?.bvid)
      .map((item) => {
        const duration = parseDurationText(item.duration)
        return {
          bvid: String(item.bvid),
          aid: normalizeCount(item.aid),
          title: stripTags(item.title),
          author: stripTags(item.author),
          mid: normalizeCount(item.mid),
          cover: normalizePic(item.pic),
          duration,
          durationText: formatDuration(duration),
          plays: normalizeCount(item.play),
          danmaku: normalizeCount(item.video_review),
          pubdate: normalizeCount(item.pubdate),
          typeName: stripTags(item.typename),
          description: stripTags(item.description).slice(0, 160),
          url: this.videoUrl(String(item.bvid))
        }
      })

    return {
      total: normalizeCount(data?.numResults),
      page: normalizeCount(data?.page) || page,
      pageSize,
      keyword,
      videos
    }
  }

  /**
   * 取视频详情，主要为了分 P 列表。
   *
   * 助眠内容大量是「一个视频几十个分 P」的白噪音合集，所以 `pages` 是关键字段：
   * 每一条都有自己的 `cid`，取流时必须用对应的 cid，否则永远是第一段。
   */
  async view (ref) {
    const { bvid, aid } = typeof ref === 'string' ? parseRef(ref) : ref
    if (bvid === '' && !aid) throw new Error('缺少 BV 号或 av 号')

    const data = await this.#api(
      '/x/web-interface/view',
      bvid === '' ? { aid } : { bvid }
    )

    const pages = (Array.isArray(data?.pages) ? data.pages : []).map((page) => {
      const duration = normalizeCount(page?.duration)
      return {
        cid: normalizeCount(page?.cid),
        page: normalizeCount(page?.page) || 1,
        part: stripTags(page?.part) || `P${normalizeCount(page?.page) || 1}`,
        duration,
        durationText: formatDuration(duration)
      }
    })

    // 单 P 视频的 `pages` 也有一条，但 `data.cid` 更权威（有些稿件 pages 里 cid 为 0）。
    const defaultCid = normalizeCount(data?.cid) || pages[0]?.cid || 0
    const duration = normalizeCount(data?.duration)

    return {
      bvid: String(data?.bvid ?? bvid),
      aid: normalizeCount(data?.aid ?? aid),
      title: stripTags(data?.title),
      author: stripTags(data?.owner?.name),
      mid: normalizeCount(data?.owner?.mid),
      cover: normalizePic(data?.pic),
      description: stripTags(data?.desc).slice(0, 300),
      duration,
      durationText: formatDuration(duration),
      pubdate: normalizeCount(data?.pubdate),
      pages,
      defaultCid,
      url: this.videoUrl(String(data?.bvid ?? bvid))
    }
  }

  /**
   * 取音频直链（带缓存）。
   *
   * 直链带签名与 `deadline`（实测 120 分钟）。缓存到「deadline 前 5 分钟」为止：
   * 到点前主动重取，避免「听到一半 403」。
   *
   * @param {{ bvid?: string, cid: number, quality?: number, force?: boolean }} options
   */
  async stream (options = {}) {
    const cid = normalizeCount(options.cid)
    if (!cid) throw new Error('缺少 cid，无法取音轨')

    const quality = AUDIO_QUALITIES.includes(Number(options.quality))
      ? Number(options.quality)
      : DEFAULT_QUALITY
    const key = `${options.bvid ?? ''}:${cid}:${quality}`

    if (options.force !== true) {
      const cached = this.#streams.get(key)
      if (cached !== undefined && cached.deadline - URL_EXPIRE_MARGIN_MS > Date.now()) {
        return cached
      }
    }

    const params = { cid, fnval: 16, fnver: 0, fourk: 1 }
    if (options.bvid) params.bvid = options.bvid
    else if (options.aid) params.avid = options.aid

    const data = await this.#api('/x/player/wbi/playurl', params, { sign: true })

    const audios = Array.isArray(data?.dash?.audio) ? data.dash.audio : []
    if (audios.length === 0) {
      // 付费课程、仅限登录、或地区限制的稿件会走到这儿。durl 兜底是整段 mp4（音视频混流），
      // 体积是纯音轨的十几倍，不符合「线上缓存」的目标，所以不做回退，只报清楚原因。
      throw new Error('这个视频没有可取用的独立音轨（可能是付费、受限或已失效稿件）')
    }

    // 优先挑用户要的档位；没有就取最接近的更高档，再没有就取现有最高档。
    const picked =
      audios.find((audio) => Number(audio.id) === quality) ??
      audios.slice().sort((left, right) => Number(right.id) - Number(left.id))[0]

    const record = {
      key,
      bvid: String(options.bvid ?? ''),
      cid,
      quality: Number(picked.id),
      qualityText: QUALITY_TEXT[Number(picked.id)] ?? String(picked.id),
      url: String(picked.baseUrl ?? ''),
      backup: (picked.backupUrl ?? []).map(String).filter((item) => item !== ''),
      mime: String(picked.mimeType ?? 'audio/mp4'),
      codecs: String(picked.codecs ?? ''),
      bandwidth: normalizeCount(picked.bandwidth),
      // API 给的 deadline 是秒级绝对时间戳；给不出就按 100 分钟保守算。
      deadline: normalizeCount(data?.dash?.deadline) * 1000 || Date.now() + 100 * 60 * 1000,
      at: Date.now()
    }

    if (record.url === '') throw new Error('B 站没有下发可用的音频地址')

    this.#streams.set(key, record)
    // 别让缓存无限长大：超过 200 条就丢掉最老的。
    if (this.#streams.size > 200) {
      const oldest = [...this.#streams.entries()]
        .sort((left, right) => left[1].at - right[1].at)
        .slice(0, this.#streams.size - 200)
      for (const [staleKey] of oldest) this.#streams.delete(staleKey)
    }

    return record
  }

  /**
   * 把播放器的 Range 请求转给 B 站 CDN，返回上游响应。
   *
   * 这里是「线上缓存」的核心：**不落盘**，播放器要哪一段就转哪一段。Range 原样透传，
   * 所以拖动进度条也是直连 CDN 的一个片段请求。
   *
   * 直链被回收（403/404）时**自动重取一次**再试 —— 签名 URL 会因为节点调度失效，
   * 而播放器那边只会表现为「卡住」，不给它第二次机会就会变成一个查不出的 bug。
   *
   * **HEAD 要绕一下**：B 站 CDN 对 `HEAD` 直接回 404（实测），而播放器与 HTTP 缓存
   * 都可能先拿 HEAD 探长度。所以这里把 HEAD 翻成 `GET + bytes=0-0`，拿头部信息后
   * 由调用方把 1 字节的 body 丢掉。返回里的 `headProbe` 就是给调用方看的标记。
   *
   * @param {{ bvid?: string, cid: number, quality?: number, range?: string, method?: string }} options
   * @returns {Promise<{ response: Response, record: object, refetched: boolean, headProbe: boolean }>}
   */
  async fetchAudio (options = {}) {
    const rawMethod = String(options.method ?? 'GET').toUpperCase()
    const headProbe = rawMethod === 'HEAD'
    const method = 'GET'
    const range = headProbe ? (options.range ?? 'bytes=0-0') : options.range

    const attempt = async (record) => {
      const headers = {
        'user-agent': PC_UA,
        referer: CDN_REFERER,
        origin: 'https://www.bilibili.com',
        ...(range ? { range } : {})
      }
      const controller = new AbortController()
      const timer = setTimeout(() => controller.abort(), this.#timeoutMs)
      try {
        return await fetch(record.url, { method, headers, signal: controller.signal })
      } finally {
        clearTimeout(timer)
      }
    }

    const cached = await this.stream(options)
    let response = await attempt(cached)

    if (response.status === 403 || response.status === 404) {
      // 直链失效：作废缓存重取一次。备选域名不去试 —— 实测 backupUrl 与主链
      // 同源同时效，主链 403 时备链也 403，试它只是多一次请求。
      this.#streams.delete(cached.key)
      const fresh = await this.stream({ ...options, force: true })
      response = await attempt(fresh)
      return { response, record: fresh, refetched: true, headProbe }
    }

    return { response, record: cached, refetched: false, headProbe }
  }

  /** 清掉某个稿件（或全部）的直链缓存。自检与「重取一次」用。 */
  invalidate (bvid = '') {
    if (bvid === '') {
      this.#streams.clear()
      return
    }
    for (const key of [...this.#streams.keys()]) {
      if (key.startsWith(`${bvid}:`)) this.#streams.delete(key)
    }
  }
}
