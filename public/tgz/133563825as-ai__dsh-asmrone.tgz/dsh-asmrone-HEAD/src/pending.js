/**
 * 待播队列 —— 把 agent 的一次工具调用变成手机上真的出声。
 *
 * 模型侧没有播放能力：`asmr_play` 顶多算出一串 URL，用户不会因此听到任何声音。
 * 所以工具在返回直链的同时往这里塞一条「待播」，Web 面板每 3 秒轮询一次取走并播放。
 *
 * ## 为什么是单槽 + 自增 seq
 *
 * 队列如果真攒起来，用户在半小时后会突然被一首早就忘了的曲子吓到。这里只保留
 * **最后一条**，并且带一个自增 seq 与 TTL：
 * - 前端带上次收到的 seq 来问，只取更新的 —— 反复轮询不会把同一首重播一遍；
 * - 超过 TTL 的待播不再投递 —— 迟到的推送不如不推。
 *
 * 全部状态在内存里。宿主重启即清空，这是期望行为：重启后的第一条待播应该是
 * 重启之后产生的。
 *
 * @module dsh-asmrone/pending
 */

/** 默认 2 分钟：够前端轮询到，又不足以让一条待播活过「用户已经忘了它」的时点。 */
const DEFAULT_TTL_MS = 120_000

/**
 * 作品 id 归一成纯数字串。
 *
 * 前端是用 `String(work.id) === String(item.id)` 回头匹配列表里的作品来补封面的，
 * 所以 agent 说 `RJ01726233` 而列表里是 `1726233` 时必须对得上。
 * 非 RJ 形态的 id 原样放过，不要顺手把别的 id  scheme 洗没了。
 */
export function normalizeWorkId (value) {
  const raw = String(value ?? '').trim()
  const match = /^RJ0*(\d+)$/i.exec(raw)
  return match ? match[1] : raw
}

export class PlayQueue {
  #seq = 0
  #item = null
  #ttlMs

  /** @param {{ ttlMs?: number }} [options] */
  constructor (options = {}) {
    const ttl = Number(options.ttlMs)
    this.#ttlMs = Number.isFinite(ttl) && ttl > 0 ? ttl : DEFAULT_TTL_MS
  }

  /**
   * 压入一条待播，返回带 seq 的完整记录。
   * 三个来源共用这一个槽：asmr.one 的在线音轨（hash）、本地文件（localKey/Index）、
   * B 站稿件（bvid/cid）。前端只认一个 `stream` 地址，由 host 侧的 `withStream`
   * 按来源分派 —— 面板那边不需要知道这首是哪儿来的。
   *
   * @param {{ id: string|number, hash?: string, title?: string, total?: number, source?: string, localKey?: string, localIndex?: number, bvid?: string, cid?: number, biliPage?: number, quality?: number }} item
   */
  push (item) {
    this.#seq += 1
    this.#item = {
      id: normalizeWorkId(item?.id),
      hash: String(item?.hash ?? ''),
      title: typeof item?.title === 'string' && item.title.trim() !== '' ? item.title : String(item?.hash ?? ''),
      total: Number.isFinite(Number(item?.total)) ? Number(item.total) : 0,
      // 本地文件走 localKey + localIndex，不走 hash —— 离线时 streamUrl 那条路根本不通。
      localKey: typeof item?.localKey === 'string' ? item.localKey : '',
      localIndex: Number.isFinite(Number(item?.localIndex)) ? Number(item.localIndex) : 0,
      // B 站稿件：bvid + cid 定位音轨，quality 是码率档（30280/30232/30216）。
      // **直链不进队列** —— 它 120 分钟就过期，入队时固化等于埋一个定时炸弹；
      // 由 `/asmrone/bili-stream` 每次现取现转。
      bvid: typeof item?.bvid === 'string' ? item.bvid : '',
      cid: Number.isFinite(Number(item?.cid)) ? Number(item.cid) : 0,
      biliPage: Number.isFinite(Number(item?.biliPage)) ? Number(item.biliPage) : 1,
      quality: Number.isFinite(Number(item?.quality)) ? Number(item.quality) : 0,
      // DLsite 试听：内容常驻 host 内存，播放走 /asmrone/trial-stream 的切片。
      trialRj: typeof item?.trialRj === 'string' ? item.trialRj : '',
      trialIndex: Number.isFinite(Number(item?.trialIndex)) ? Number(item.trialIndex) : 0,
      source: typeof item?.source === 'string' ? item.source : 'agent',
      seq: this.#seq,
      at: Date.now()
    }
    return this.#item
  }

  /**
   * 前端来问「有没有比 since 更新的」。
   * 没有新条目、或已经过期，都返回 `item: null`，但 seq 照给 —— 前端要拿它推进游标，
   * 否则游标永远不动，每次轮询都会重新收到同一条。
   * @param {number} since
   */
  poll (since) {
    const cursor = Number(since)
    if (this.#item === null) return { seq: this.#seq, item: null }
    if (this.#seq <= (Number.isFinite(cursor) ? cursor : 0)) return { seq: this.#seq, item: null }
    if (Date.now() - this.#item.at > this.#ttlMs) return { seq: this.#seq, item: null }
    return { seq: this.#seq, item: this.#item }
  }

  /** 丢弃当前待播（不影响 seq，避免回退导致重复投递）。 */
  clear () {
    this.#item = null
  }

  get seq () {
    return this.#seq
  }

  get current () {
    return this.#item
  }

  get ttlMs () {
    return this.#ttlMs
  }
}
