/**
 * asmr.one 接口封装。
 *
 * 只依赖 Node 内置能力（全局 `fetch` + `AbortController`），运行期零第三方依赖。
 *
 * 实测过的端点（2026-10 校验）：
 * - `GET /api/search/{关键词}`  关键词搜索，支持 page / pageSize / order
 * - `GET /api/works`            全库列表（按 order 排序）
 * - `GET /api/tags/`            标签表，422 条，带 zh-cn 译名
 * - `GET /api/tracks/{id}`      作品音轨树（folder / audio 嵌套）
 * - `GET /api/media/stream/{hash}` 音频流，302 跳 CDN 真链，支持 Range
 *
 * 注意：`GET /api/works/{id}` 返回 401，作品详情请从列表/搜索结果里取 —— 那些
 * 对象本身就带 tags / vas / duration / rate_average_2dp 等全部字段。
 *
 * @module dsh-asmrone/api
 */

/** 支持的排序字段。传错会被 asmr.one 静默忽略，所以在本地先挡一道。 */
export const ORDER_FIELDS = Object.freeze([
  'create_date',
  'release',
  'dl_count',
  'rate_average_2dp',
  'rate_count',
  'review_count',
  'price'
])

/** 排除女性向 / 乙女向 / BL / 耽美 / 男同 / 异性恋 之外的性别过滤用标签。 */
export const FEMALE_ORIENTED_TAGS = Object.freeze([491, 10001, 37, 33, 47, 462])

/** 判定是否为可重试的传输层抖动。 */
function isTransientNetworkError (error) {
  const text = `${error?.message ?? ''} ${error?.cause?.message ?? ''} ${error?.cause?.code ?? ''}`
  return /fetch failed|ECONNRESET|ECONNREFUSED|EPIPE|ENOTFOUND|EAI_AGAIN|ETIMEDOUT|socket hang up|network/i.test(text)
}

/** @param {number} ms */
function sleep (ms) {
  return new Promise((resolve) => setTimeout(resolve, ms))
}

export class AsmrOneApi {
  /**
   * @param {object} options
   * @param {string} options.apiBaseUrl - 例如 `https://api.asmr.one`
   * @param {string} options.siteBaseUrl - 例如 `https://asmr.one`
   * @param {string} options.dlsiteTrialBaseUrl
   * @param {number} options.timeoutMs
   */
  constructor (options) {
    this.apiBaseUrl = String(options.apiBaseUrl).replace(/\/+$/, '')
    this.siteBaseUrl = String(options.siteBaseUrl).replace(/\/+$/, '')
    this.dlsiteTrialBaseUrl = String(options.dlsiteTrialBaseUrl).replace(/\/+$/, '')
    this.timeoutMs = options.timeoutMs
  }

  /** 作品页地址，给人点。 */
  workPageUrl (id) {
    return `${this.siteBaseUrl}/work/${id}`
  }

  /**
   * 发一个带超时的 JSON 请求。网络抖动（ECONNRESET / EAI_AGAIN 这类）会自动重试，
   * 因为出口线路经常断一下又通 —— 一次抖动不该让整次搜索失败。
   * @param {string} url
   * @param {number} [attempts]
   * @returns {Promise<any>}
   */
  async #json (url, attempts = 3) {
    let lastError = null
    for (let attempt = 1; attempt <= attempts; attempt++) {
      const controller = new AbortController()
      const timer = setTimeout(() => controller.abort(), this.timeoutMs)
      try {
        const response = await fetch(url, {
          signal: controller.signal,
          headers: {
            'user-agent': 'Mozilla/5.0 (Linux; Android 13) Chrome/120',
            accept: 'application/json, text/plain, */*',
            referer: `${this.siteBaseUrl}/`
          }
        })
        if (!response.ok) {
          throw new Error(`asmr.one 返回 ${response.status} ${response.statusText}（${url}）`)
        }
        return await response.json()
      } catch (error) {
        lastError = error
        const transient = isTransientNetworkError(error)
        if (!transient || attempt === attempts) break
        await sleep(400 * attempt)
      } finally {
        clearTimeout(timer)
      }
    }
    if (lastError?.name === 'AbortError') {
      throw new Error(`asmr.one 请求超时（${this.timeoutMs}ms）：${url}`)
    }
    throw lastError ?? new Error(`asmr.one 请求失败：${url}`)
  }

  /**
   * 关键词搜索。关键词留空则退化为全库列表。
   * @param {object} options
   * @param {string} [options.query]
   * @param {number} [options.page]
   * @param {number} [options.pageSize]
   * @param {string} [options.order]
   * @returns {Promise<{works: object[], total: number, page: number, pageSize: number}>}
   */
  async search ({ query = '', page = 1, pageSize = 20, order = 'dl_count' } = {}) {
    const safeOrder = ORDER_FIELDS.includes(order) ? order : 'dl_count'
    const params = new URLSearchParams({
      page: String(page),
      pageSize: String(Math.min(Math.max(pageSize, 1), 200)),
      order: safeOrder
    })
    const trimmed = String(query).trim()
    const path = trimmed === ''
      ? `/api/works?${params}`
      : `/api/search/${encodeURIComponent(trimmed)}?${params}`
    const payload = await this.#json(`${this.apiBaseUrl}${path}`)
    return {
      works: Array.isArray(payload?.works) ? payload.works : [],
      total: payload?.pagination?.totalCount ?? 0,
      page,
      pageSize
    }
  }

  /**
   * 标签表。
   * @returns {Promise<Array<{id: number, name: string, count?: number}>>}
   */
  async tags () {
    const payload = await this.#json(`${this.apiBaseUrl}/api/tags/`)
    return Array.isArray(payload) ? payload : []
  }

  /**
   * 作品音轨树。
   * @param {string|number} id
   * @returns {Promise<object[]>}
   */
  async tracks (id) {
    const payload = await this.#json(`${this.apiBaseUrl}/api/tracks/${encodeURIComponent(String(id))}`)
    return Array.isArray(payload) ? payload : []
  }

  /**
   * 音频流地址。请求它会被 302 到 CDN 真链，支持 Range，可直接喂播放器。
   * @param {string} hash - 形如 `1653004/1937686`
   * @returns {string}
   */
  streamUrl (hash) {
    const [workId, trackId] = String(hash).split('/')
    return `${this.apiBaseUrl}/api/media/stream/${encodeURIComponent(workId)}/${encodeURIComponent(trackId)}`
  }

  /**
   * 把流地址解析成最终 CDN 直链（跟随 302，不下载正文）。
   * @param {string} hash
   * @returns {Promise<string>}
   */
  async resolveStreamUrl (hash) {
    const controller = new AbortController()
    const timer = setTimeout(() => controller.abort(), this.timeoutMs)
    try {
      const response = await fetch(this.streamUrl(hash), {
        method: 'HEAD',
        redirect: 'follow',
        signal: controller.signal,
        headers: {
          'user-agent': 'Mozilla/5.0 (Linux; Android 13) Chrome/120',
          referer: `${this.siteBaseUrl}/`
        }
      })
      return response.url || this.streamUrl(hash)
    } catch {
      // HEAD 不被支持时退化为直接用 stream 地址（播放侧照样能跟 302）。
      return this.streamUrl(hash)
    } finally {
      clearTimeout(timer)
    }
  }

  /**
   * 探测一个音频的体积（字节）。失败返回 0。
   * @param {string} hash
   * @returns {Promise<number>}
   */
  async audioSize (hash) {
    const controller = new AbortController()
    const timer = setTimeout(() => controller.abort(), this.timeoutMs)
    try {
      const response = await fetch(this.streamUrl(hash), {
        signal: controller.signal,
        headers: {
          'user-agent': 'Mozilla/5.0 (Linux; Android 13) Chrome/120',
          referer: `${this.siteBaseUrl}/`,
          range: 'bytes=0-1'
        }
      })
      const range = response.headers.get('content-range') ?? ''
      const total = Number(range.split('/').pop())
      return Number.isFinite(total) ? total : 0
    } catch {
      return 0
    } finally {
      clearTimeout(timer)
    }
  }

  /**
   * 下载一个音频到指定路径，返回写入字节数。
   * @param {string} hash
   * @param {string} filePath
   * @param {number} [timeoutMs]
   * @returns {Promise<number>}
   */
  async downloadAudio (hash, filePath, timeoutMs = 600000) {
    const { createWriteStream } = await import('node:fs')
    const { pipeline } = await import('node:stream/promises')
    const { Readable } = await import('node:stream')

    const controller = new AbortController()
    const timer = setTimeout(() => controller.abort(), timeoutMs)
    try {
      const response = await fetch(this.streamUrl(hash), {
        signal: controller.signal,
        headers: {
          'user-agent': 'Mozilla/5.0 (Linux; Android 13) Chrome/120',
          referer: `${this.siteBaseUrl}/`
        }
      })
      if (!response.ok || response.body === null) {
        throw new Error(`下载失败：HTTP ${response.status}（${hash}）`)
      }
      await pipeline(Readable.fromWeb(response.body), createWriteStream(filePath))
      const { statSync } = await import('node:fs')
      return statSync(filePath).size
    } finally {
      clearTimeout(timer)
    }
  }
}

/**
 * 把作品对象压成给模型看的紧凑形状 —— 完整对象有 30 多个字段，直接吐给模型太吵。
 * @param {object} work
 * @param {(id: string|number) => string} [urlOf]
 * @returns {object}
 */
export function summarizeWork (work, urlOf) {
  const tags = Array.isArray(work?.tags)
    ? work.tags
      .map((tag) => tag?.i18n?.['zh-cn']?.name ?? tag?.name)
      .filter((name) => typeof name === 'string' && name !== '')
      .slice(0, 6)
    : []
  const duration = Number(work?.duration) || 0
  return {
    id: work?.id,
    title: work?.title,
    circle: work?.name,
    rating: work?.rate_average_2dp,
    ratingCount: work?.rate_count,
    downloads: work?.dl_count,
    release: work?.release,
    durationSeconds: duration,
    durationText: formatDuration(duration),
    hasSubtitle: work?.has_subtitle === true,
    nsfw: work?.nsfw === true,
    voiceActors: Array.isArray(work?.vas) ? work.vas.map((va) => va?.name).filter(Boolean).slice(0, 4) : [],
    tags,
    url: typeof urlOf === 'function' ? urlOf(work?.id) : undefined
  }
}

/**
 * 判断作品是否属于女性向阵营（用于「只要男性向」过滤）。
 * @param {object} work
 * @returns {boolean}
 */
export function isFemaleOriented (work) {
  if (!Array.isArray(work?.tags)) return false
  return work.tags.some((tag) => FEMALE_ORIENTED_TAGS.includes(tag?.id))
}

/**
 * 秒 → `1h23m` / `45m`。
 * @param {number} seconds
 * @returns {string}
 */
export function formatDuration (seconds) {
  const total = Math.max(0, Math.round(Number(seconds) || 0))
  if (total < 60) return `${total}s`
  const hours = Math.floor(total / 3600)
  const minutes = Math.floor((total % 3600) / 60)
  return hours > 0 ? `${hours}h${String(minutes).padStart(2, '0')}m` : `${minutes}m`
}

/**
 * 把音轨树拍平成 `[{hash, title, path}]`，只保留音频节点。
 * @param {object[]} nodes
 * @param {string} [prefix]
 * @param {Array<{hash: string, title: string, path: string}>} [out]
 * @returns {Array<{hash: string, title: string, path: string}>}
 */
export function flattenAudio (nodes, prefix = '', out = []) {
  for (const node of Array.isArray(nodes) ? nodes : []) {
    if (node?.type === 'audio' && typeof node.hash === 'string') {
      out.push({ hash: node.hash, title: String(node.title ?? ''), path: `${prefix}${node.title ?? ''}` })
    } else if (Array.isArray(node?.children)) {
      flattenAudio(node.children, `${prefix}${node.title ?? ''}/`, out)
    }
  }
  return out
}
