/**
 * Web UI 的 HTTP 面，挂在 webServer 的 `/asmrone` 前缀下。
 *
 * 客户端半身不碰 Node API，也不直接打 asmr.one —— 所有数据和动作都走这里。
 * 音频默认走 `/asmrone/stream` 代理转发：asmr.one 的 CDN 不带 CORS 头，
 * 前端直接 `fetch` 会被挡；走 host 代理还能把 302 与 Range 一并处理掉。
 *
 * @module dsh-asmrone/http
 */

import { ORDER_FIELDS, flattenAudio, isFemaleOriented, summarizeWork } from './api.js'
import { DEFAULT_QUALITY, parseRef } from './bilibili.js'
import { normalizeWorkno } from './dlsite.js'
import { mimeOf } from './local.js'
import { AUDIO_EXTENSIONS, safeName } from './tools/download.js'
import { mapLimit } from './tools/work.js'
import { createReadStream, existsSync, statSync } from 'node:fs'
import { join } from 'node:path'

const MAX_BODY_BYTES = 64 * 1024
const MAX_PAGE_SIZE = 60

class HttpError extends Error {
  constructor (status, code, message) {
    super(message)
    this.status = status
    this.code = code
  }
}

/**
 * 解析单段 `Range`。
 *
 * 只支持单段：`bytes=0-1023` / `bytes=1000-` / `bytes=-500`（最后 500 字节）。
 * 多段（`bytes=0-99,200-299`）返回 null —— 音频播放器不会这么问，为它去拼
 * `multipart/byteranges` 不值当。
 *
 * @param {string} header
 * @param {number} size 文件总字节数
 * @returns {{start: number, end: number}|null} 闭区间；不可满足时 null（调用方回 416）
 */
export function parseRange (header, size) {
  const total = Number(size)
  if (!Number.isFinite(total) || total <= 0) return null
  const match = /^bytes=(\d*)-(\d*)$/i.exec(String(header ?? '').trim())
  if (match === null) return null
  const [, rawStart, rawEnd] = match
  if (rawStart === '' && rawEnd === '') return null

  let start
  let end
  if (rawStart === '') {
    // `bytes=-500`：末尾 N 字节
    const length = Number(rawEnd)
    if (!Number.isFinite(length) || length <= 0) return null
    start = Math.max(0, total - length)
    end = total - 1
  } else {
    start = Number(rawStart)
    end = rawEnd === '' ? total - 1 : Number(rawEnd)
  }

  if (!Number.isFinite(start) || !Number.isFinite(end)) return null
  if (start < 0 || start >= total) return null
  end = Math.min(end, total - 1)
  if (end < start) return null
  return { start, end }
}

/**
 * B 站音轨的代理地址。
 *
 * 刻意做成**稳定 URL**（只由 bvid/cid/码率决定，不含会过期的签名参数）：
 * 前端拿它当 `<audio>` 的 src，WebView 就能按这个 key 缓存已经拉过的片段 ——
 * 拖动进度条往回拖、或者重听同一段，都不再打 B 站 CDN。签名的重取留在 host 侧。
 */
export function biliStreamUrl (bvid, cid, quality) {
  const params = new URLSearchParams({ bvid: String(bvid), cid: String(cid) })
  const rate = Number(quality)
  if (Number.isFinite(rate) && rate > 0) params.set('q', String(rate))
  return `/asmrone/bili-stream?${params.toString()}`
}

/**
 * 待播条目 → 带一个可播地址。
 *
 * 本地条目走 `/asmrone/local-stream`（离线可用），B 站条目走 `/asmrone/bili-stream`，
 * 其余走 asmr.one 的代理。前端不需要知道区别，拿到 `stream` 直接喂 `<audio>` 即可。
 */
function withStream (item, api) {
  if (item.localKey !== '') {
    return Object.assign({}, item, {
      stream: `/asmrone/local-stream?key=${encodeURIComponent(item.localKey)}&index=${item.localIndex}`
    })
  }
  if (item.bvid !== '' && item.cid > 0) {
    return Object.assign({}, item, { stream: biliStreamUrl(item.bvid, item.cid, item.quality) })
  }
  if (item.trialRj !== '' && item.trialIndex > 0) {
    return Object.assign({}, item, {
      stream: `/asmrone/trial-stream?rj=${encodeURIComponent(item.trialRj)}&index=${item.trialIndex}`
    })
  }
  return Object.assign({}, item, { stream: asmrStreamUrl(item.hash) })
}

/**
 * asmr.one 音轨的**代理**地址。
 *
 * 不把 asmr.one 的原始 URL 直接交给前端：那条地址会 302 跳一次 CDN，而且 CDN 上
 * 没有 CORS 头。`/asmrone/stream` 就是为这两件事存在的（跟随 302 + 透传 Range）。
 * 之前这里漏了一条分支，在线条目被塞了原始 URL —— 播放器能出声，但完全绕过了代理层。
 */
export function asmrStreamUrl (hash) {
  return `/asmrone/stream?hash=${encodeURIComponent(String(hash ?? ''))}`
}

/**
 * 把 RJ 号的几种写法归一到 `RJxxxxxxxx`。
 *
 * `normalizeWorkno` 认不出来时抛的是普通 Error —— 直接漏到外层的 catch 会变成 500，
 * 但那明明是**用户传错了**，该是 400。这里统一把它翻译成 HttpError。
 */
function requireWorkno (value) {
  try {
    return normalizeWorkno(value)
  } catch (error) {
    throw new HttpError(400, 'invalid-rj', error.message)
  }
}

/**
 * 把试听库抛出的普通 Error 翻成 409。
 *
 * 试听库的错**全是能说清楚的业务原因**：这部没提供官方试听 / 试听包超过在线听上限 /
 * 解压后太大 / 包里只有图片。它们既不是「上游挂了」，也不该被 500 吞成「操作失败」——
 * 面板要拿原话决定给用户哪个出口（重试、换一部、还是直接下载）。
 */
export async function withTrialReason (task) {
  try {
    return await task()
  } catch (error) {
    throw new HttpError(409, 'trial-unavailable', error instanceof Error ? error.message : String(error))
  }
}

/** 取 B 站客户端；没配好时给一个能看懂的 503，而不是 undefined 崩栈。 */
function requireBili (runtime) {
  const bili = runtime?.bilibili
  if (bili === undefined || bili === null) {
    throw new HttpError(503, 'bili-unavailable', 'B 站音源没有启用（插件版本太旧或加载失败）')
  }
  return bili
}

function sendJson (res, status, data) {
  const body = JSON.stringify(data)
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    'Content-Length': Buffer.byteLength(body)
  })
  res.end(body)
}

function fail (res, status, code, message) {
  sendJson(res, status, { ok: false, error: { code, message } })
}

async function readJsonBody (req, { allowEmpty = false } = {}) {
  const chunks = []
  let total = 0
  for await (const chunk of req) {
    total += chunk.length
    if (total > MAX_BODY_BYTES) throw new HttpError(413, 'body-too-large', '请求体过大')
    chunks.push(chunk)
  }
  const text = Buffer.concat(chunks).toString('utf8')
  if (text.trim() === '') {
    if (allowEmpty) return {}
    throw new HttpError(400, 'invalid-json', '请求体不能为空')
  }
  try {
    const parsed = JSON.parse(text)
    if (parsed === null || typeof parsed !== 'object' || Array.isArray(parsed)) {
      throw new HttpError(400, 'invalid-json', '请求体必须是对象')
    }
    return parsed
  } catch (error) {
    if (error instanceof HttpError) throw error
    throw new HttpError(400, 'invalid-json', '请求体不是合法 JSON')
  }
}

/**
 * 分流。返回 `true` 表示该请求已被处理。
 * @param {import('node:http').IncomingMessage} req
 * @param {import('node:http').ServerResponse} res
 * @param {object} runtime
 */
async function dispatch (req, res, runtime) {
  const { api, store, dlsite } = runtime
  const url = new URL(req.url, 'http://localhost')
  const path = url.pathname.replace(/\/+$/, '') || '/asmrone'
  const method = (req.method ?? 'GET').toUpperCase()

  // ── 配置 ──────────────────────────────────────────────
  if (path === '/asmrone/config') {
    if (method === 'GET') {
      return sendJson(res, 200, { ok: true, config: store.get(), configPath: store.configPath, orders: [...ORDER_FIELDS] })
    }
    if (method === 'POST') {
      const body = await readJsonBody(req)
      const config = store.set(body)
      return sendJson(res, 200, { ok: true, config })
    }
    throw new HttpError(405, 'method-not-allowed', '只支持 GET / POST')
  }

  // ── 标签 ──────────────────────────────────────────────
  if (path === '/asmrone/tags' && method === 'GET') {
    const tags = await api.tags()
    const sorted = tags
      .map((tag) => ({ id: tag.id, name: tag.name, count: Number(tag.count) || 0 }))
      .sort((left, right) => right.count - left.count)
    return sendJson(res, 200, { ok: true, tags: sorted })
  }

  // ── 搜索 ──────────────────────────────────────────────
  if (path === '/asmrone/search' && method === 'GET') {
    const config = store.get()
    const query = url.searchParams.get('q') ?? ''
    const order = ORDER_FIELDS.includes(url.searchParams.get('order')) ? url.searchParams.get('order') : config.defaultOrder
    const page = Math.max(1, Number(url.searchParams.get('page')) || 1)
    const pageSize = Math.min(Math.max(Number(url.searchParams.get('pageSize')) || config.pageSize, 1), MAX_PAGE_SIZE)
    const chineseOnly = url.searchParams.get('chinese') === '1'
    const includeFemale = url.searchParams.get('female') === '1'

    const widen = chineseOnly || !includeFemale ? 3 : 1
    const result = await api.search({ query, page, pageSize: Math.min(pageSize * widen, 200), order })
    let works = result.works
    if (chineseOnly) works = works.filter((work) => /简体中文版|繁體中文版|中文版/.test(String(work?.title ?? '')))
    if (!includeFemale && config.languageFilter === 'male') works = works.filter((work) => !isFemaleOriented(work))
    works = works.slice(0, pageSize)

    return sendJson(res, 200, {
      ok: true,
      total: result.total,
      page,
      pageSize,
      order,
      works: works.map((work) => ({
        ...summarizeWork(work, (id) => api.workPageUrl(id)),
        cover: work?.mainCoverUrl ?? work?.samCoverUrl ?? '',
        sourceUrl: typeof work?.source_url === 'string' ? work.source_url : `https://www.dlsite.com/maniax/work/=/product_id/RJ${String(work?.source_id ?? '').replace(/[^0-9]/g, '').padStart(8, '0')}.html`
      }))
    })
  }

  // ── 音轨树 ────────────────────────────────────────────
  if (path === '/asmrone/work' && method === 'GET') {
    const raw = url.searchParams.get('id') ?? ''
    const id = raw.replace(/^RJ0*/i, '').replace(/[^0-9]/g, '')
    if (id === '') throw new HttpError(400, 'invalid-id', '缺少作品 id')
    const tree = await api.tracks(id)
    const tracks = flattenAudio(tree)
    return sendJson(res, 200, { ok: true, id, count: tracks.length, tracks })
  }

  // ── 探测体积 ──────────────────────────────────────────
  if (path === '/asmrone/sizes' && method === 'POST') {
    const body = await readJsonBody(req)
    const hashes = Array.isArray(body.hashes) ? body.hashes.slice(0, 80).map(String) : []
    if (hashes.length === 0) throw new HttpError(400, 'invalid-request', 'hashes 不能为空')
    const sizes = await mapLimit(hashes, 8, (hash) => api.audioSize(hash))
    return sendJson(res, 200, {
      ok: true,
      sizes: hashes.map((hash, index) => ({ hash, bytes: sizes[index] }))
    })
  }

  // ── 音频代理 ──────────────────────────────────────────
  // ── 待播队列：agent → 前端播放器 ──────────────────────
  // 这两个端点让「模型说一句『放这首』」变成手机上真的出声。
  // 没有它，asmr_play 只能吐一串 URL，用户在对话里点了也听不到东西。
  if (path === '/asmrone/pending' && method === 'GET') {
    const since = Number(url.searchParams.get('since')) || 0
    const result = runtime.pending.poll(since)
    return sendJson(res, 200, {
      ok: true,
      seq: result.seq,
      item: result.item === null ? null : withStream(result.item, api)
    })
  }

  if (path === '/asmrone/play' && method === 'POST') {
    const body = await readJsonBody(req)

    // 本地文件分支：给 key + index，不碰网络。离线时这是唯一能推的路。
    if (typeof body.localKey === 'string' && body.localKey !== '') {
      const index = Number.isInteger(body.index) ? body.index : 1
      const track = runtime.library.track(body.localKey, index)
      if (track === null) {
        throw new HttpError(404, 'track-not-found', `本地库里没有第 ${index} 轨`)
      }
      const item = runtime.pending.push({
        id: track.work.rj === '' ? track.work.name : track.work.rj,
        hash: '',
        title: `${track.work.name} · ${track.file.name}`,
        total: track.work.count,
        localKey: track.work.key,
        localIndex: index,
        source: typeof body.source === 'string' ? body.source : 'agent'
      })
      return sendJson(res, 200, { ok: true, item: withStream(item, api) })
    }

    const rawId = String(body.id ?? '')
    const id = rawId.replace(/^RJ0*/i, '').replace(/[^0-9]/g, '')
    if (id === '') throw new HttpError(400, 'invalid-id', '缺少作品 id')

    const tracks = flattenAudio(await api.tracks(id))
    let target = null
    if (typeof body.hash === 'string' && body.hash.trim() !== '') {
      const wanted = body.hash.trim()
      target = tracks.find((track) => track.hash === wanted) ?? { hash: wanted, title: wanted }
    } else {
      const index = Number.isInteger(body.index) ? body.index : 1
      target = tracks[index - 1] ?? null
      if (target === null) {
        throw new HttpError(404, 'track-not-found', `第 ${index} 轨不存在（共 ${tracks.length} 轨）`)
      }
    }

    const item = runtime.pending.push({
      id,
      hash: target.hash,
      title: target.title,
      total: tracks.length,
      source: typeof body.source === 'string' ? body.source : 'agent'
    })
    return sendJson(res, 200, { ok: true, item: withStream(item, api) })
  }

  // ── 音频流 ────────────────────────────────────────────
  if (path === '/asmrone/stream' && (method === 'GET' || method === 'HEAD')) {
    const hash = url.searchParams.get('hash') ?? ''
    if (!/^\d+\/\d+$/.test(hash)) throw new HttpError(400, 'invalid-hash', 'hash 格式应为 `作品ID/音轨ID`')

    // 跟随 asmr.one 的 302 拿到 CDN 真链，再把请求转出去。
    const target = await api.resolveStreamUrl(hash)
    const headers = {
      'user-agent': 'Mozilla/5.0 (Linux; Android 13) Chrome/120',
      referer: `${api.siteBaseUrl}/`
    }
    const range = req.headers?.range
    if (typeof range === 'string') headers.range = range

    const upstream = await fetch(target, { method, headers })
    const passthrough = {}
    for (const key of ['content-type', 'content-length', 'content-range', 'accept-ranges', 'etag', 'last-modified']) {
      const value = upstream.headers.get(key)
      if (value !== null) passthrough[key] = value
    }
    if (passthrough['content-type'] === undefined) passthrough['content-type'] = 'audio/mpeg'
    passthrough['cache-control'] = 'private, max-age=300'

    res.writeHead(upstream.status, passthrough)
    if (method === 'HEAD' || upstream.body === null) {
      res.end()
      return
    }
    const { Readable } = await import('node:stream')
    const { pipeline } = await import('node:stream/promises')
    await pipeline(Readable.fromWeb(upstream.body), res)
    return
  }

  // ── 下载 ──────────────────────────────────────────────
  // ── 本地音声库 ────────────────────────────────────────
  // asmr.one 是境外站，没有代理时在线那条链路（搜索 / 音轨 / 封面 / 流）整条不通。
  // 但用户机器上那些文件本来就不需要网络。这两个端点让面板在离线时照样能列、能播 ——
  // 也是「已经下了哪些」这个问题的唯一答案来源。
  if (path === '/asmrone/local' && method === 'GET') {
    const force = url.searchParams.get('force') === '1'
    const query = url.searchParams.get('q') ?? ''
    const snapshot = runtime.library.scan({ force })
    const works = query === '' ? snapshot.works : runtime.library.find(query)

    return sendJson(res, 200, {
      ok: true,
      scannedAt: snapshot.scannedAt,
      roots: snapshot.roots,
      totals: snapshot.totals,
      matched: works.length,
      works: works.map((work) => ({
        key: work.key,
        name: work.name,
        rj: work.rj,
        source: work.source,
        trial: work.trial,
        count: work.count,
        bytes: work.bytes,
        sizeText: work.sizeText,
        // 不把绝对路径发到前端：前端用 key+index 取流，路径只留在 host 侧。
        files: work.files.map((file, index) => ({
          index: index + 1,
          name: file.name,
          ext: file.ext,
          sizeText: file.sizeText
        }))
      }))
    })
  }

  if (path === '/asmrone/local-stream' && (method === 'GET' || method === 'HEAD')) {
    let target = ''
    const key = url.searchParams.get('key')
    const rawIndex = url.searchParams.get('index')

    if (typeof key === 'string' && key !== '') {
      const wanted = Number(rawIndex)
      const track = runtime.library.track(key, Number.isInteger(wanted) ? wanted : 1)
      if (track === null) throw new HttpError(404, 'track-not-found', '本地库里没有这一轨')
      target = track.file.path
    } else {
      // 也允许直接给绝对路径（脚本 / agent 用），但必须落在配置的根目录内。
      const requested = url.searchParams.get('path') ?? ''
      const resolved = runtime.library.resolveWithin(requested)
      if (resolved === null) throw new HttpError(403, 'path-not-allowed', '路径不在允许的本地目录内')
      target = resolved
    }

    let total
    try {
      total = statSync(target).size
    } catch {
      throw new HttpError(404, 'file-missing', '文件已不在磁盘上')
    }
    const type = mimeOf(target)
    const rangeHeader = req.headers?.range

    if (typeof rangeHeader === 'string' && rangeHeader !== '') {
      const range = parseRange(rangeHeader, total)
      if (range === null) {
        // 不可满足的 Range：按 RFC 回 416 并告知真实长度，播放器据此重试
        res.writeHead(416, { 'Content-Range': `bytes */${total}`, 'Accept-Ranges': 'bytes' })
        res.end()
        return true
      }
      res.writeHead(206, {
        'Content-Type': type,
        'Content-Length': range.end - range.start + 1,
        'Content-Range': `bytes ${range.start}-${range.end}/${total}`,
        'Accept-Ranges': 'bytes',
        'Cache-Control': 'no-store'
      })
      if (method === 'HEAD') {
        res.end()
        return true
      }
      createReadStream(target, { start: range.start, end: range.end }).pipe(res)
      return true
    }

    res.writeHead(200, {
      'Content-Type': type,
      'Content-Length': total,
      'Accept-Ranges': 'bytes',
      'Cache-Control': 'no-store'
    })
    if (method === 'HEAD') {
      res.end()
      return true
    }
    createReadStream(target).pipe(res)
    return true
  }

  // ── 删除已下载的内容 ──────────────────────────────────
  // 单轨 / 整部 / 一次多部。`indexes` 省略或为空数组就是整部删。
  // 真正的路径校验在 LocalLibrary.remove 里（每轨单独 resolveWithin），
  // 这里只管收参、限流和转述结果。`dryRun` 只算不删，面板的二次确认拿它算给用户看。
  if (path === '/asmrone/local/delete' && method === 'POST') {
    const body = await readJsonBody(req)
    const raw = Array.isArray(body.targets) ? body.targets : []
    if (raw.length === 0) throw new HttpError(400, 'invalid-request', 'targets 不能为空')
    if (raw.length > 500) throw new HttpError(400, 'too-many-targets', `一次最多删 500 项（收到 ${raw.length}）`)

    const result = runtime.library.remove(
      raw.map((item) => ({
        key: String(item?.key ?? ''),
        indexes: Array.isArray(item?.indexes) ? item.indexes : []
      })),
      { dryRun: body.dryRun === true }
    )
    return sendJson(res, 200, { ok: true, ...result })
  }

  // ── B 站音源 ──────────────────────────────────────────
  // 容器里唯一「不用魔法网络」的在线源：asmr.one 与 DLsite 直连都不通，
  // 猫耳 / 喜马拉雅接口有 WAF。B 站这条链路实测能直连、匿名可用。
  //
  // 三段式：搜 → 看分 P → 流式转发。**全程不落盘**，文件不会堆在手机上。
  if (path === '/asmrone/bili/search' && method === 'GET') {
    const bili = requireBili(runtime)
    const pageSize = Math.min(Math.max(Number(url.searchParams.get('pageSize')) || store.get().pageSize, 1), MAX_PAGE_SIZE)
    const result = await bili.search({
      keyword: url.searchParams.get('q') ?? '',
      page: Math.max(1, Number(url.searchParams.get('page')) || 1),
      pageSize,
      order: url.searchParams.get('order') ?? 'totalrank'
    })
    return sendJson(res, 200, { ok: true, ...result })
  }

  if (path === '/asmrone/bili/work' && method === 'GET') {
    const bili = requireBili(runtime)
    const ref = url.searchParams.get('ref') ?? url.searchParams.get('bvid') ?? ''
    if (ref.trim() === '') throw new HttpError(400, 'invalid-ref', '需要 bvid / av 号 / 视频链接')
    return sendJson(res, 200, { ok: true, work: await bili.view(ref) })
  }

  if (path === '/asmrone/bili/play' && method === 'POST') {
    const bili = requireBili(runtime)
    const body = await readJsonBody(req)
    const ref = String(body.ref ?? body.bvid ?? '').trim()
    if (ref === '') throw new HttpError(400, 'invalid-ref', '需要 ref（BV 号 / av 号 / 视频链接）')

    const parsed = parseRef(ref)
    if (parsed.bvid === '' && parsed.aid === 0) {
      throw new HttpError(400, 'invalid-ref', `看不懂这个引用：${ref}`)
    }

    const info = await bili.view(parsed.bvid === '' ? { aid: parsed.aid } : parsed.bvid)
    const wanted = Number.isInteger(body.page) ? Number(body.page) : parsed.page
    const target = info.pages[wanted - 1]
    if (target === undefined) {
      throw new HttpError(404, 'page-not-found', `这个稿件没有第 ${wanted} 个分 P（共 ${info.pages.length} 个）`)
    }

    const item = runtime.pending.push({
      id: info.bvid,
      title: info.pages.length > 1 ? `${info.title} · ${target.part}` : info.title,
      total: info.pages.length,
      bvid: info.bvid,
      cid: target.cid,
      biliPage: target.page,
      quality: Number.isFinite(Number(body.quality)) ? Number(body.quality) : DEFAULT_QUALITY,
      source: typeof body.source === 'string' ? body.source : 'panel'
    })

    return sendJson(res, 200, {
      ok: true,
      item: withStream(item, api),
      work: { bvid: info.bvid, title: info.title, cover: info.cover, page: target.page }
    })
  }

  if (path === '/asmrone/bili-stream' && (method === 'GET' || method === 'HEAD')) {
    const bili = requireBili(runtime)
    const parsed = parseRef(url.searchParams.get('bvid') ?? '')
    const cid = Number(url.searchParams.get('cid')) || 0
    const quality = Number(url.searchParams.get('q')) || DEFAULT_QUALITY
    if (parsed.bvid === '' || cid <= 0) {
      throw new HttpError(400, 'invalid-request', '需要 bvid 与 cid')
    }

    // Range 原样转给 CDN：拖动进度条 = 一次片段请求，host 侧只做搬运。
    // 直链被回收时 fetchAudio 自己会重取一次再试，这里不用管。
    const { response: upstream, record, headProbe } = await bili.fetchAudio({
      bvid: parsed.bvid, cid, quality, range: req.headers?.range, method
    })

    if (headProbe) {
      // B 站 CDN 不认 HEAD，上面已经把它翻成 `GET + bytes=0-0`。
      // 这一字节的 body 不要，只从 `Content-Range` 里抠出真实总长回给播放器 ——
      // 直接透传上游的 `Content-Length: 1` 会让播放器以为整首只有一秒。
      try {
        await upstream.body?.cancel?.()
      } catch { /* body 已关或不可取消，忽略 */ }
      const contentRange = String(upstream.headers.get('content-range') ?? '')
      const total = Number(contentRange.split('/')[1]) || Number(upstream.headers.get('content-length') ?? 0)
      res.writeHead(upstream.status >= 400 ? upstream.status : 200, {
        'Content-Type': 'audio/mp4',
        'Content-Length': Number.isFinite(total) && total > 0 ? total : 0,
        'Accept-Ranges': 'bytes',
        'Cache-Control': 'private, max-age=3600',
        'x-bili-quality': record.qualityText
      })
      res.end()
      return
    }

    const upstreamType = upstream.headers.get('content-type') ?? ''
    const headers = {
      // CDN 回的是 application/octet-stream；原样透传会让部分 WebView 直接拒播。
      'content-type': upstreamType === '' || /octet-stream/i.test(upstreamType) ? 'audio/mp4' : upstreamType,
      'accept-ranges': 'bytes',
      // 稳定 URL + 长缓存 = WebView 自己攒一份「线上缓存」：往回拖、重听都不再出网。
      'cache-control': 'private, max-age=3600',
      'x-bili-quality': record.qualityText
    }
    for (const key of ['content-length', 'content-range', 'etag', 'last-modified']) {
      const value = upstream.headers.get(key)
      if (value !== null) headers[key] = value
    }

    res.writeHead(upstream.status, headers)
    if (upstream.body === null) {
      res.end()
      return
    }
    const { Readable } = await import('node:stream')
    const { pipeline } = await import('node:stream/promises')
    await pipeline(Readable.fromWeb(upstream.body), res)
    return
  }

  if (path === '/asmrone/download' && method === 'POST') {
    const body = await readJsonBody(req)
    const id = String(body.id ?? '').replace(/^RJ0*/i, '').replace(/[^0-9]/g, '')
    if (id === '') throw new HttpError(400, 'invalid-id', '缺少作品 id')

    const config = store.get()
    const tree = await api.tracks(id)
    let tracks = flattenAudio(tree)
    if (Array.isArray(body.hashes) && body.hashes.length > 0) {
      const wanted = new Set(body.hashes.map(String))
      tracks = tracks.filter((track) => wanted.has(track.hash))
    } else {
      const keyword = typeof body.keyword === 'string' ? body.keyword.trim() : ''
      if (keyword !== '') tracks = tracks.filter((track) => track.path.includes(keyword))
      if (body.includeWav !== true) tracks = tracks.filter((track) => AUDIO_EXTENSIONS.test(track.path))
    }
    if (tracks.length === 0) throw new HttpError(400, 'no-tracks', '没有匹配的音轨')

    const root = typeof body.outputDir === 'string' && body.outputDir.trim() !== '' ? body.outputDir.trim() : config.outputDir
    const dir = store.ensureDir(join(root, safeName(body.title, String(id))))

    const results = await mapLimit(tracks, config.downloadConcurrency, async (track) => {
      const name = safeName(track.title, track.hash.replace('/', '_'))
      const filePath = join(dir, name)
      if (existsSync(filePath) && statSync(filePath).size > 1024) {
        return { name, status: 'skipped', bytes: statSync(filePath).size }
      }
      try {
        const bytes = await api.downloadAudio(track.hash, filePath)
        return { name, status: 'saved', bytes }
      } catch (error) {
        return { name, status: 'failed', error: error.message }
      }
    })

    const files = results.filter((item) => item.status !== 'failed')
    const failures = results.filter((item) => item.status === 'failed')
    return sendJson(res, 200, {
      ok: true,
      dir,
      selected: tracks.length,
      saved: files.length,
      totalMb: Math.round((files.reduce((sum, item) => sum + (item.bytes ?? 0), 0) / 1048576) * 10) / 10,
      files: files.map((item) => ({ name: item.name, status: item.status, sizeMb: Math.round(((item.bytes ?? 0) / 1048576) * 10) / 10 })),
      failures: failures.map((item) => ({ name: item.name, error: item.error }))
    })
  }

  // ── DLsite 试听 ───────────────────────────────────────
  if (path === '/asmrone/trial' && method === 'GET') {
    const workno = url.searchParams.get('rj') ?? ''
    if (workno === '') throw new HttpError(400, 'invalid-rj', '缺少 RJ 号')
    const info = await dlsite.workInfo(requireWorkno(workno))
    return sendJson(res, 200, { ok: true, ...info })
  }

  // ── DLsite 试听：在线听（内存）+ 下载（落盘） ──────────
  // 手机端本身只给「在线听」，下载要切电脑模式 —— 这两条路由把两个能力都补齐：
  //   · open 把 zip 拉进内存解开，stream 从内存切片喂播放器，**磁盘零占用**；
  //   · save 复用同一份内存数据落盘，「听着满意再存」不会重下一次 zip。
  // DLsite 域名在本机被 DNS 污染，靠 index.js 装的 DoH 补丁才能通。
  if (path === '/asmrone/trial/search' && method === 'GET') {
    const keyword = (url.searchParams.get('q') ?? '').trim()
    if (keyword === '') throw new HttpError(400, 'invalid-query', '缺少搜索关键词')
    const result = await dlsite.search({
      keyword,
      page: Math.max(1, Number(url.searchParams.get('page')) || 1),
      perPage: Math.min(Math.max(Number(url.searchParams.get('perPage')) || 30, 10), 100),
      sort: url.searchParams.get('sort') ?? '',
      // 空串 = 不过滤。项目取向是不内置偏好，默认值由调用方（面板 / 工具）决定。
      sexCategory: url.searchParams.get('sex') ?? ''
    })
    return sendJson(res, 200, { ok: true, ...result })
  }

  if (path === '/asmrone/trial/open' && method === 'POST') {
    const body = await readJsonBody(req)
    const workno = requireWorkno(body.rj ?? body.workno ?? '')
    const work = await withTrialReason(() => runtime.trial.open(workno, {
      force: body.force === true,
      maxMb: Number(body.maxMb) > 0 ? Number(body.maxMb) : undefined
    }))
    return sendJson(res, 200, { ok: true, work: runtime.trial.list(workno), stats: runtime.trial.stats })
  }

  if (path === '/asmrone/trial/close' && method === 'POST') {
    const body = await readJsonBody(req, { allowEmpty: true })
    const target = body.rj === undefined || body.rj === null || String(body.rj) === ''
      ? ''
      : requireWorkno(body.rj)
    const cleared = runtime.trial.clear(target)
    return sendJson(res, 200, { ok: true, cleared, stats: runtime.trial.stats })
  }

  if (path === '/asmrone/trial/save' && method === 'POST') {
    const body = await readJsonBody(req)
    const workno = requireWorkno(body.rj ?? body.workno ?? '')
    const config = store.get()
    if (runtime.trial.get(workno) === null) {
      // 下载这条岔路不该被「在线听」的体积上限挡住：面板上只有一个「下载到本地」
      // 按钮，报「先在线听一次再存」等于让用户去做一件刚刚被上限拒绝的事。
      // 这里直接按下载档的上限（配置里的 maxWorkMb，默认 800）把它拉进来 ——
      // 落盘不额外占内存，唯一代价是一次多出来的 zip 下载，而这正是用户点它的目的。
      await withTrialReason(() => runtime.trial.open(workno, {
        maxMb: Math.max(Number(config.maxWorkMb) || 0, 200)
      }))
    }
    const root = typeof body.outputDir === 'string' && body.outputDir.trim() !== ''
      ? body.outputDir.trim()
      : config.outputDir
    const dir = store.ensureDir(join(root, safeName(`${workno}_试听`, workno)))
    const result = await withTrialReason(() => runtime.trial.saveAll(workno, dir))
    // 落盘之后本地库要立刻能看到 —— 否则用户存完了面板里找不到。
    runtime.library.invalidate()
    return sendJson(res, 200, { ok: true, ...result })
  }

  if (path === '/asmrone/trial-stream' && (method === 'GET' || method === 'HEAD')) {
    const raw = url.searchParams.get('rj') ?? ''
    if (raw === '') throw new HttpError(400, 'invalid-rj', '缺少 RJ 号')
    const workno = requireWorkno(raw)
    if (runtime.trial.get(workno) === null) {
      throw new HttpError(409, 'trial-not-open', `${workno} 的试听包还没打开`)
    }

    const index = Number(url.searchParams.get('index')) || 1
    // 只问元信息，不碰数据 —— 下面 HEAD 分支能便宜地探长度，靠的就是这一点。
    const probe = runtime.trial.track(workno, index)
    if (probe === null) throw new HttpError(404, 'track-not-found', `第 ${index} 轨不存在`)
    const total = probe.total
    const type = mimeOf(probe.track.name)
    const rangeHeader = req.headers?.range

    if (typeof rangeHeader === 'string' && rangeHeader !== '') {
      const range = parseRange(rangeHeader, total)
      if (range === null) {
        res.writeHead(416, { 'Content-Range': `bytes */${total}`, 'Accept-Ranges': 'bytes' })
        res.end()
        return true
      }
      // HEAD 不取数据：播放器探长度时会先问一次，不该为整轨付一次下载代价。
      if (method === 'HEAD') {
        res.writeHead(206, {
          'Content-Type': type,
          'Content-Length': range.end - range.start + 1,
          'Content-Range': `bytes ${range.start}-${range.end}/${total}`,
          'Accept-Ranges': 'bytes',
          'Cache-Control': 'no-store'
        })
        res.end()
        return true
      }
      // 内容本来不在内存里 —— 这一次会把整轨按需取回来（deflate 不支持随机访问，
      // 想切中间一段也得从头 inflate）。取回的轨进 LRU，后续 Range 请求只走内存。
      // 必须在 writeHead 之前做完：抛错时头还没发出去，才能回一个正经的错误。
      const chunk = await withTrialReason(() => runtime.trial.slice(workno, index, range.start, range.end))
      if (chunk === null) throw new HttpError(404, 'track-not-found', `第 ${index} 轨取不到`)
      res.writeHead(206, {
        'Content-Type': type,
        'Content-Length': range.end - range.start + 1,
        'Content-Range': `bytes ${range.start}-${range.end}/${total}`,
        'Accept-Ranges': 'bytes',
        'Cache-Control': 'no-store'
      })
      res.end(chunk.data)
      return true
    }

    if (method === 'HEAD') {
      res.writeHead(200, {
        'Content-Type': type,
        'Content-Length': total,
        'Accept-Ranges': 'bytes',
        'Cache-Control': 'no-store'
      })
      res.end()
      return true
    }
    const chunk = await withTrialReason(() => runtime.trial.slice(workno, index, 0, total - 1))
    if (chunk === null) throw new HttpError(404, 'track-not-found', `第 ${index} 轨取不到`)
    res.writeHead(200, {
      'Content-Type': type,
      'Content-Length': total,
      'Accept-Ranges': 'bytes',
      'Cache-Control': 'no-store'
    })
    res.end(chunk.data)
    return true
  }

  throw new HttpError(404, 'not-found', `未知路径 ${path}`)
}

/**
 * 挂到 webServer 上。返回 dispose。
 * @param {object} options
 * @param {object} options.webServer
 * @param {object} options.runtime
 */
export function registerRoutes ({ webServer, runtime }) {
  return webServer.register({
    kind: 'prefix',
    path: '/asmrone',
    async handler (req, res) {
      try {
        await dispatch(req, res, runtime)
      } catch (error) {
        if (error instanceof HttpError) {
          fail(res, error.status, error.code, error.message)
          return
        }
        const message = error instanceof Error ? error.message : String(error)
        // 上游接口的错误（超时、4xx/5xx）原样转述，比笼统的「操作失败」有用。
        const isUpstream = /超时|asmr\.one|DLsite|fetch|HTTP /.test(message)
        // 状态码分上游/本地，但 message 一律带出去。
        // 以前非上游错误被压成「操作失败」，「试听包 100MB 超过上限」这种本地就能说清
        // 的原因也成了哑巴错误 —— 前端只能猜成「你是不是没开代理」。
        fail(
          res,
          isUpstream ? 502 : 500,
          isUpstream ? 'upstream-error' : 'internal-error',
          message.trim() === '' ? '操作失败' : message
        )
      }
    }
  })
}
