/**
 * `asmr_local` —— 本地音声库工具。
 *
 * 回答两个问题：「我已经下了哪些」，以及「离线时放什么」。
 *
 * asmr.one 是境外站，没代理时 `asmr_search` / `asmr_work` / `asmr_play` 全部不可用；
 * 但用户机器上的文件本来就不需要网络。没有这个工具，那段对话里模型只能干看着
 * 几个 G 的音声说「我连不上服务器」。
 *
 * @module dsh-asmrone/tools/local
 */

import { defineTool } from '../define-tool.js'

/**
 * 把用户/模型给的 key 解析成一部作品。
 *
 * 优先精确匹配 key（`0:/sdcard/...` 这种形态太长，模型未必照抄得准），所以精确
 * 匹配失手时再按名字模糊找一次 —— 名字唯一命中就认，多个就报出来让人选，
 * 绝不猜。
 *
 * @param {import('../local.js').LocalLibrary} library
 * @param {string} key
 */
function resolveWork (library, key) {
  const raw = String(key ?? '').trim()
  if (raw === '') return { error: '缺少 key，先用 action=list 看有哪些作品' }

  const exact = library.work(raw)
  if (exact !== null) return { work: exact }

  const matches = library.find(raw)
  if (matches.length === 0) return { error: `本地库里没有匹配「${raw}」的作品` }
  if (matches.length > 1) {
    return {
      error: `「${raw}」匹配到 ${matches.length} 部，换更具体的名字：${
        matches.slice(0, 5).map((work) => work.name).join(' ｜ ')
      }`
    }
  }
  return { work: matches[0] }
}

export function createLocalTool (runtime) {
  const { library } = runtime

  return defineTool({
    name: 'asmr_local',
    description:
      '本地音声库：列出已经下到这台手机上的音声（`asmr_download` 下的，加上配置里 localDirs 指向的目录），' +
      '并且可以直接推给面板播放器播放 —— **全程不需要网络**。' +
      'asmr.one 是境外站，没开代理时在线搜索与在线播放都不可用，那种情况下这个工具是唯一的播放来源。' +
      '不传 action 就是列作品。',
    parameters: {
      action: {
        type: 'string',
        description: 'list（默认）= 列本地作品；files = 列某部的音轨；play = 推给面板播放；rescan = 强制重扫磁盘（默认 60 秒缓存）'
      },
      query: { type: 'string', description: 'list 时按作品名 / 文件名 / RJ 号过滤' },
      key: { type: 'string', description: '作品 key（取自 list），也可以直接给作品名关键词；files 与 play 需要它' },
      index: { type: 'integer', description: 'play 时播第几轨（从 1 开始），默认 1' }
    },
    output: {
      schema: { type: 'object' },
      render: (args, value) => {
        if (value.error) return `失败：${value.error}`

        if (value.action === 'list' || value.action === 'rescan') {
          const lines = [
            `本地音声库：**${value.totals.works} 部 · ${value.totals.files} 个文件 · ${value.totals.sizeText}**`,
            ''
          ]
          for (const root of value.roots) {
            const mark = root.exists ? (root.isDirectory ? '✓' : '✗ 不是目录') : '✗ 不存在'
            lines.push(`- ${mark} \`${root.path}\`　${root.works} 部 · ${root.sizeText}`)
          }
          if (value.matched === 0) {
            lines.push('', '没有匹配的作品。')
            return lines.join('\n')
          }
          lines.push('', value.query === '' ? '全部作品：' : `匹配「${value.query}」的 ${value.matched} 部：`)
          for (const [index, work] of value.works.slice(0, 40).entries()) {
            const meta = [
              work.rj === '' ? '' : `id ${work.rj}`,
              work.trial ? '试听' : '',
              work.source === 'download' ? '下载' : '外部库'
            ].filter(Boolean).join(' · ')
            lines.push(`${index + 1}. **${work.name}**　${work.count} 轨 · ${work.sizeText}${meta === '' ? '' : `　（${meta}）`}`)
          }
          if (value.works.length > 40) lines.push(`… 其余 ${value.works.length - 40} 部已省略`)
          lines.push('', '给 `key` 传作品名关键词就能取某部；`action=play` 直接放。')
          return lines.join('\n')
        }

        if (value.action === 'files') {
          const lines = [`**${value.work.name}**　${value.work.count} 轨 · ${value.work.sizeText}`, '']
          for (const file of value.work.files) {
            lines.push(`${file.index}. \`${file.name}\`　${file.sizeText}`)
          }
          lines.push('', `播放：\`asmr_local action=play key="${value.work.name}" index=<轨号>\``)
          return lines.join('\n')
        }

        if (value.action === 'play') {
          return [
            `已在手机上播放：**${value.work.name}** 第 ${value.index} 轨`,
            '',
            `\`${value.file.name}\`　${value.file.sizeText}`,
            '',
            value.pushed
              ? '本地文件，不经过网络 —— 没开代理也能放。面板关着也会响，底部悬浮条可以停、可以拖进度。'
              : '（没有推送到面板：宿主的待播队列不可用）'
          ].join('\n')
        }

        return JSON.stringify(value, null, 2)
      }
    },
    async execute (args) {
      try {
        const action = typeof args.action === 'string' && args.action !== '' ? args.action : 'list'

        if (action === 'list' || action === 'rescan') {
          const snapshot = library.scan({ force: action === 'rescan' })
          const query = typeof args.query === 'string' ? args.query.trim() : ''
          const works = query === '' ? snapshot.works : library.find(query)
          return {
            action: 'list',
            scannedAt: new Date(snapshot.scannedAt).toISOString(),
            roots: snapshot.roots,
            totals: snapshot.totals,
            query,
            matched: works.length,
            works: works.map((work) => ({
              key: work.key,
              name: work.name,
              rj: work.rj,
              dir: work.dir,
              source: work.source,
              trial: work.trial,
              count: work.count,
              sizeText: work.sizeText
            }))
          }
        }

        if (action === 'files') {
          const { work, error } = resolveWork(library, args.key)
          if (error) return { error }
          return {
            action: 'files',
            work: {
              key: work.key,
              name: work.name,
              count: work.count,
              sizeText: work.sizeText,
              files: work.files.map((file, index) => ({
                index: index + 1,
                name: file.name,
                ext: file.ext,
                sizeText: file.sizeText
              }))
            }
          }
        }

        if (action === 'play') {
          const { work, error } = resolveWork(library, args.key)
          if (error) return { error }
          const index = Number.isInteger(args.index) ? args.index : 1
          const track = library.track(work.key, index)
          if (track === null) {
            return { error: `第 ${index} 轨不存在（${work.name} 共 ${work.count} 轨）` }
          }

          let pushed = false
          if (runtime.pending) {
            runtime.pending.push({
              id: work.rj === '' ? work.name : work.rj,
              hash: '',
              title: `${work.name} · ${track.file.name}`,
              total: work.count,
              localKey: work.key,
              localIndex: index,
              source: 'agent-local'
            })
            pushed = true
          }

          return {
            action: 'play',
            pushed,
            index,
            work: { key: work.key, name: work.name, count: work.count, sizeText: work.sizeText },
            file: {
              name: track.file.name,
              ext: track.file.ext,
              path: track.file.path,
              sizeText: track.file.sizeText
            }
          }
        }

        return { error: `不认识的 action：${action}（可用 list / files / play / rescan）` }
      } catch (error) {
        return { error: error.message }
      }
    }
  })
}
