/**
 * `asmr_play` —— 取音轨的播放直链。
 * @module dsh-asmrone/tools/play
 */

import { defineTool } from '../define-tool.js'

export function createPlayTool (runtime) {
  const { api } = runtime

  return defineTool({
    name: 'asmr_play',
    description:
      '取 asmr.one 上音轨的音频直链，并默认推送到 Web 面板的播放器立即播放。' +
      '不传 hash / index 时只列出该作品的全部音轨；传 hash（形如 `1653004/1937686`）' +
      '或 index（第几轨）时返回可直接喂给任何播放器的流地址（该地址会 302 跳到 CDN，支持 Range 拖动进度），' +
      '同时让面板开始放这首。',
    parameters: {
      id: { type: 'string', description: '作品 id 或 RJ 号', required: true },
      hash: { type: 'string', description: '音轨 hash，形如 `1653004/1937686`；不传则只列清单' },
      index: { type: 'integer', description: '取第几轨（从 1 开始），与 hash 二选一' },
      resolveCdn: { type: 'boolean', description: '是否跟随 302 解析出 CDN 最终地址，默认 false' },
      push: {
        type: 'boolean',
        description:
          '是否顺手推给 Web 面板的播放器立刻播放，默认 true —— 指定 hash 或 index 时，' +
          '前端会在几秒内开始出声。只想拿地址、不想打扰正在放的东西时传 false。'
      }
    },
    output: {
      schema: { type: 'object' },
      render: (args, value) => {
        if (value.error) return `失败：${value.error}`
        if (value.url) {
          return [
            `音轨：**${value.title}**`,
            value.pushed ? '\n已推送到面板播放器，几秒内开始播放。' : '',
            '',
            '```',
            value.url,
            '```',
            '',
            value.cdnUrl ? `CDN 直链（有时效签名，过期重新调用本工具）：` : '',
            value.cdnUrl ? `\n\`\`\`\n${value.cdnUrl}\n\`\`\`` : ''
          ].filter((line) => line !== '').join('\n')
        }
        const lines = [`作品 **${value.id}** 共 ${value.tracks.length} 个音轨：`, '']
        for (const [index, track] of value.tracks.slice(0, 40).entries()) {
          lines.push(`${index + 1}. \`${track.hash}\`　${track.title}`)
        }
        if (value.tracks.length > 40) lines.push(`… 其余 ${value.tracks.length - 40} 个已省略`)
        lines.push('', '再调一次并带上 `hash=` 或 `index=` 就能拿到播放直链。')
        return lines.join('\n')
      }
    },
    async execute (args) {
      try {
        const { flattenAudio } = await import('../api.js')
        const id = String(args.id).replace(/^RJ0*/i, '').replace(/[^0-9]/g, '')
        const tree = await api.tracks(id)
        const tracks = flattenAudio(tree)

        let target = null
        if (typeof args.hash === 'string' && args.hash.trim() !== '') {
          const wanted = args.hash.trim()
          target = tracks.find((track) => track.hash === wanted) ?? { hash: wanted, title: wanted, path: wanted }
        } else if (Number.isInteger(args.index)) {
          target = tracks[args.index - 1] ?? null
          if (target === null) return { error: `第 ${args.index} 轨不存在（共 ${tracks.length} 轨）`, tracks }
        }

        if (target === null) return { id, tracks }

        const url = api.streamUrl(target.hash)
        const cdnUrl = args.resolveCdn === true ? await api.resolveStreamUrl(target.hash) : ''

        // 顺手推给前端播放器。模型侧只会拿到一串地址，用户不会因此听到任何声音 ——
        // 推队列才是「点一下就放」。runtime.pending 可能不存在（老宿主），用可选链。
        let seq = 0
        if (args.push !== false && runtime.pending) {
          seq = runtime.pending.push({
            id,
            hash: target.hash,
            title: target.title,
            total: tracks.length
          }).seq
        }

        return { id, hash: target.hash, title: target.title, url, cdnUrl, pushed: seq > 0, seq }
      } catch (error) {
        return { error: error.message }
      }
    }
  })
}
