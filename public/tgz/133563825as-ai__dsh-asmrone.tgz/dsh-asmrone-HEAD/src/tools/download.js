/**
 * `asmr_download` —— 把作品音频下到本地。
 * @module dsh-asmrone/tools/download
 */

import { join } from 'node:path'
import { existsSync, statSync } from 'node:fs'

import { defineTool } from '../define-tool.js'
import { flattenAudio } from '../api.js'
import { mapLimit } from './work.js'

/** 文件名里不能出现的字符，统一换成下划线。 */
export function safeName (input, fallback = 'untitled') {
  const cleaned = String(input ?? '')
    .replace(/[\\/:*?"<>|\u0000-\u001f]/g, '_')
    .replace(/\s+/g, ' ')
    .trim()
  return cleaned === '' ? fallback : cleaned.slice(0, 120)
}

/**
 * 纯音频扩展名白名单。
 *
 * asmr.one 的音轨树里，部分作品的条目是 `.avi` / `.mp4`（作者原本发的是视频），
 * 但它们同样被标成 `type: "audio"`。所以「默认只下音频」不能只排 `.wav`，
 * 得按白名单收 —— 否则会把几百 MB 的视频当音频拖下来。
 */
export const AUDIO_EXTENSIONS = /\.(mp3|m4a|aac|ogg|opus|flac)$/i

export function createDownloadTool (runtime) {
  const { api, getConfig, store } = runtime

  return defineTool({
    name: 'asmr_download',
    description:
      '把 asmr.one 上某部作品的音频下载到本机目录（默认 /sdcard/Download/ASMR）。' +
      '默认只下 MP3（跳过 WAV，否则体积翻几倍），自动跳过已存在的文件，按作品名建子目录。' +
      '可用 hashes 只下指定几轨，或用 keyword 过滤轨名（如「01」「通常」）。下载完返回落盘路径与体积。',
    parameters: {
      id: { type: 'string', description: '作品 id 或 RJ 号', required: true },
      title: { type: 'string', description: '用作子目录名的作品名；不传则用作品 id' },
      hashes: { type: 'array', items: { type: 'string' }, description: '只下这些 hash 的轨道' },
      keyword: { type: 'string', description: '只下路径含该关键词的音轨，例如「通常」「含音效」' },
      includeWav: { type: 'boolean', description: '为 true 时连 WAV 一起下（体积×3~5）' },
      limit: { type: 'integer', description: '最多下多少轨，默认全部' },
      outputDir: { type: 'string', description: '覆盖落盘目录' }
    },
    output: {
      schema: { type: 'object' },
      render: (args, value) => {
        if (value.error) return `下载失败：${value.error}`
        const lines = [
          `✅ **${value.saved} / ${value.selected}** 轨写入 \`${value.dir}\`，共 **${value.totalMb} MB**`,
          ''
        ]
        for (const file of value.files.slice(0, 30)) {
          lines.push(`- ${file.status === 'skipped' ? '（已存在，跳过）' : ''}${file.sizeMb} MB　${file.name}`)
        }
        if (value.files.length > 30) lines.push(`… 其余 ${value.files.length - 30} 条已省略`)
        if (value.skippedMedia > 0) lines.push(`\n（已跳过 ${value.skippedMedia} 个非音频文件：视频或 WAV。要连它们一起下就加 includeWav=true）`)
        for (const failure of value.failures) lines.push(`- ⚠️ ${failure.name}：${failure.error}`)
        lines.push('', '这些文件已脱离 asmr.one，飞行模式也能放。')
        return lines.join('\n')
      }
    },
    timeoutMs: 1800000,
    isConcurrencySafe: () => false,
    async execute (args) {
      const config = getConfig()
      const id = String(args.id).replace(/^RJ0*/i, '').replace(/[^0-9]/g, '')
      if (id === '') return { error: `无法从「${args.id}」里认出作品 id`, files: [], failures: [], saved: 0, selected: 0, totalMb: 0, dir: '', skippedMedia: 0 }

      try {
        const tree = await api.tracks(id)
        let tracks = flattenAudio(tree)
        let skippedMedia = 0

        if (Array.isArray(args.hashes) && args.hashes.length > 0) {
          const wanted = new Set(args.hashes.map((hash) => String(hash)))
          tracks = tracks.filter((track) => wanted.has(track.hash))
        } else {
          const keyword = typeof args.keyword === 'string' && args.keyword.trim() !== '' ? args.keyword.trim() : ''
          if (keyword !== '') tracks = tracks.filter((track) => track.path.includes(keyword))
          if (args.includeWav !== true) {
            const before = tracks.length
            tracks = tracks.filter((track) => AUDIO_EXTENSIONS.test(track.path))
            skippedMedia = before - tracks.length
          }
        }
        if (Number.isInteger(args.limit) && args.limit > 0) tracks = tracks.slice(0, args.limit)
        if (tracks.length === 0) {
          const reason = skippedMedia > 0
            ? `这部作品只有 ${skippedMedia} 个非音频文件（视频或 WAV），默认不下。要下就加 includeWav=true。`
            : '没有匹配的音轨（试试放宽 keyword 过滤）'
          return { error: reason, files: [], failures: [], saved: 0, selected: 0, totalMb: 0, dir: '', skippedMedia }
        }

        const baseName = safeName(args.title, String(id))
        const root = typeof args.outputDir === 'string' && args.outputDir.trim() !== '' ? args.outputDir.trim() : config.outputDir
        const dir = store.ensureDir(join(root, baseName))

        const results = await mapLimit(tracks, config.downloadConcurrency, async (track) => {
          const name = safeName(track.title, track.hash.replace('/', '_'))
          const filePath = join(dir, name)
          if (existsSync(filePath) && statSync(filePath).size > 1024) {
            return { name, status: 'skipped', bytes: statSync(filePath).size, track }
          }
          try {
            const bytes = await api.downloadAudio(track.hash, filePath)
            return { name, status: 'saved', bytes, track }
          } catch (error) {
            return { name, status: 'failed', error: error.message, track }
          }
        })

        const files = []
        const failures = []
        let totalBytes = 0
        for (const result of results) {
          if (result.status === 'failed') {
            failures.push({ name: result.name, error: result.error })
            continue
          }
          totalBytes += result.bytes
          files.push({ name: result.name, status: result.status, sizeMb: Math.round((result.bytes / 1048576) * 10) / 10 })
        }

        return {
          dir,
          skippedMedia,
          selected: tracks.length,
          saved: files.length,
          totalMb: Math.round((totalBytes / 1048576) * 10) / 10,
          files,
          failures
        }
      } catch (error) {
        return { error: error.message, files: [], failures: [], saved: 0, selected: 0, totalMb: 0, dir: '', skippedMedia: 0 }
      }
    }
  })
}
