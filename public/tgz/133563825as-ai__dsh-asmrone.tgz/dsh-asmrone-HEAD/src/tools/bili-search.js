/**
 * `bili_search` —— 在 B 站搜视频（音轨）。
 *
 * 这条工具存在的理由：asmr.one 与 DLsite 在没开代理的容器里**直连不通**，
 * 猫耳 FM / 喜马拉雅接口有 WAF，B 站是唯一能直连、匿名可用的在线音源。
 * 助眠 / 白噪音 / ASMR 这一类在 B 站有极大存量，且几乎都是长音频。
 *
 * @module dsh-asmrone/tools/bili-search
 */

import { defineTool } from '../define-tool.js'

/** B 站搜索的排序取值。传错会被服务端静默忽略，所以先在本地挡一道。 */
export const BILI_ORDERS = Object.freeze(['totalrank', 'click', 'pubdate', 'dm', 'stow'])

const ORDER_TEXT = Object.freeze({
  totalrank: '综合',
  click: '播放最多',
  pubdate: '最新发布',
  dm: '弹幕最多',
  stow: '收藏最多'
})

/** 一万以上缩写成 `1.2万`，搜索结果里播放量动辄几百万，原样铺开太长。 */
function shortCount (value) {
  const number = Number(value) || 0
  if (number >= 100_000_000) return `${(number / 100_000_000).toFixed(1)}亿`
  if (number >= 10_000) return `${(number / 10_000).toFixed(1)}万`
  return String(number)
}

export function createBiliSearchTool (runtime) {
  const { bilibili, getConfig } = runtime

  return defineTool({
    name: 'bili_search',
    description:
      '在 B 站（bilibili）搜索视频音轨。**这是容器里唯一不用代理就能直连的在线音源** —— ' +
      'asmr.one 与 DLsite 都要魔法网络，猫耳 FM / 喜马拉雅接口有 WAF 风控。' +
      '助眠向内容（白噪音、雨声、海浪、篝火、ASMR 耳舐め / 耳かき、催眠、钢琴、' +
      '低语、户外自然音、专注自习 BGM）在 B 站存量极大，而且多为几十分钟到几小时的长音频。' +
      '返回 bvid、标题、UP 主、时长、播放量、封面与稿件地址；拿到 bvid 后用 `bili_play` 直接流式播放' +
      '（不下载、不占磁盘），或先用工具看分 P。' +
      '注意：B 站搜索的命中数上限恒为 1000，那是服务端硬顶，不代表真实总量。',
    parameters: {
      query: { type: 'string', description: '搜索关键词，如「助眠 雨声」「白噪音」「耳舐め」「催眠」', required: true },
      order: {
        type: 'string',
        enum: [...BILI_ORDERS],
        description: '排序：totalrank 综合（默认）/ click 播放最多 / pubdate 最新 / dm 弹幕 / stow 收藏'
      },
      page: { type: 'integer', description: '页码，从 1 开始，默认 1' },
      pageSize: { type: 'integer', description: '每页条数，默认取插件配置（20），上限 50' }
    },
    output: {
      schema: { type: 'object' },
      render: (args, value) => {
        if (value.error) return `B 站搜索失败：${value.error}`
        if (value.videos.length === 0) {
          return `B 站没有命中（关键词「${args.query ?? ''}」）。换个词试试，或去掉英文/日文混写。`
        }
        const lines = [
          `B 站命中 **${value.total}** 条（服务端上限 1000）· 关键词「${value.keyword}」· 第 ${value.page} 页 · ${ORDER_TEXT[value.order] ?? value.order}`,
          ''
        ]
        for (const video of value.videos) {
          lines.push(`**${video.bvid}**　${video.title}`)
          lines.push(`　${video.author} · ${video.durationText} · 播放 ${shortCount(video.plays)} · ${video.typeName}`)
          if (video.description !== '') lines.push(`　${video.description}`)
          lines.push(`　${video.url}`)
          lines.push('')
        }
        lines.push('下一步：`bili_play` 带 `ref=` 这个 bvid 直接播放（流式，不落盘）；多分 P 的稿件先看 `page=`。')
        return lines.join('\n')
      }
    },
    async execute (args) {
      const query = String(args.query ?? '').trim()
      if (query === '') return { error: 'query 不能为空', videos: [], total: 0, page: 1, order: 'totalrank' }

      const order = BILI_ORDERS.includes(args.order) ? args.order : 'totalrank'
      const page = Math.max(1, Number(args.page) || 1)
      const pageSize = Math.min(Math.max(Number(args.pageSize) || getConfig().pageSize, 1), 50)

      try {
        const result = await bilibili.search({ keyword: query, page, pageSize, order })
        return { ...result, order }
      } catch (error) {
        return { error: error.message, videos: [], total: 0, page, order, keyword: query }
      }
    }
  })
}
