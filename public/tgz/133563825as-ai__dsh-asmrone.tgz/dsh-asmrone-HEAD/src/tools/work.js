/**
 * `asmr_work` —— 看一部作品的音轨清单。
 * @module dsh-asmrone/tools/work
 */

import { defineTool } from '../define-tool.js'
import { flattenAudio, formatDuration } from '../api.js'

export function createWorkTool (runtime) {
  const { api, getConfig } = runtime

  return defineTool({
    name: 'asmr_work',
    description:
      '列出 asmr.one 上某部作品的完整音轨树（音轨标题、层级、可播放条数），并估算 MP3 总体积。' +
      '用来在下载前确认内容结构和体量。参数给作品 id（数字）或 RJ 号都行。',
    parameters: {
      id: { type: 'string', description: '作品 id（如 1006912）或 RJ 号（如 RJ01726233）', required: true },
      resolveSizes: { type: 'boolean', description: '是否并发探测每轨体积，默认 false（探测慢，全 WAV 的包会很久）' }
    },
    output: {
      schema: { type: 'object' },
      render: (args, value) => {
        if (value.error) return `读取失败：${value.error}`
        const lines = [`作品 **${value.id}**：共 **${value.tracks.length}** 个音频${value.totalMb > 0 ? `，合计约 ${value.totalMb} MB` : ''}`, '']
        for (const track of value.tracks.slice(0, 60)) {
          const size = track.sizeMb > 0 ? ` · ${track.sizeMb} MB` : ''
          lines.push(`- \`${track.hash}\`　${track.title}${size}`)
        }
        if (value.tracks.length > 60) lines.push(`… 其余 ${value.tracks.length - 60} 个已省略`)
        lines.push('')
        lines.push('下载：`asmr_download` 带 id 即可；只挑部分轨就把 hash 填进 `hashes`。')
        return lines.join('\n')
      }
    },
    async execute (args) {
      try {
        const id = String(args.id).replace(/^RJ0*/i, '').replace(/[^0-9]/g, '')
        if (id === '') return { error: `无法从「${args.id}」里认出作品 id`, tracks: [], totalMb: 0 }
        const tree = await api.tracks(id)
        let tracks = flattenAudio(tree)
        let totalMb = 0

        if (args.resolveSizes === true && tracks.length > 0) {
          const sample = tracks.slice(0, 60)
          const sizes = await mapLimit(sample, 8, (track) => api.audioSize(track.hash))
          tracks = [
            ...sample.map((track, index) => ({ ...track, sizeMb: Math.round((sizes[index] / 1048576) * 10) / 10 })),
            ...tracks.slice(60)
          ]
          totalMb = Math.round(sizes.reduce((sum, size) => sum + size, 0) / 1048576)
        }

        return { id, count: tracks.length, totalMb, tracks }
      } catch (error) {
        return { error: error.message, tracks: [], totalMb: 0 }
      }
    }
  })
}

/**
 * 并发跑一个有上限的 map，保持输入顺序。
 * @template T, R
 * @param {T[]} items
 * @param {number} limit
 * @param {(item: T, index: number) => Promise<R>} worker
 * @returns {Promise<R[]>}
 */
export async function mapLimit (items, limit, worker) {
  const results = new Array(items.length)
  let cursor = 0
  const runners = Array.from({ length: Math.min(limit, items.length) }, async () => {
    while (true) {
      const index = cursor++
      if (index >= items.length) return
      results[index] = await worker(items[index], index)
    }
  })
  await Promise.all(runners)
  return results
}

export { formatDuration }
