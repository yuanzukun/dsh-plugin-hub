/**
 * `bili_play` —— 把 B 站稿件的音轨推给面板流式播放。
 *
 * 与 `asmr_play` 的关键区别：**这里不下载任何东西**。入队的是 `bvid + cid`，
 * 播放时由 `/asmrone/bili-stream` 现取直链、原样转发 Range —— 手机上一个字节都不落盘。
 * 直链（120 分钟寿命）刻意不进队列，否则「入队 → 十分钟后再播」必然撞上过期。
 *
 * @module dsh-asmrone/tools/bili-play
 */

import { AUDIO_QUALITIES, DEFAULT_QUALITY, formatDuration, parseRef } from '../bilibili.js'
import { defineTool } from '../define-tool.js'

const QUALITY_TEXT = Object.freeze({ 30280: '192K', 30232: '132K', 30216: '64K' })

export function createBiliPlayTool (runtime) {
  const { bilibili } = runtime

  return defineTool({
    name: 'bili_play',
    description:
      '播放 B 站稿件的音轨 —— **流式，不下载，不占磁盘**。' +
      '传 BV 号、av 号或视频链接（`ref`）即可；多分 P 的稿件用 `page` 指定第几段。' +
      '默认取最高码率（192K），并顺手推给 Web 面板的播放器立刻出声（`push=false` 只探测不播）。' +
      '不传 `page` 且只想先看看有什么时，也拿它当「列分 P」用：返回里会带全部分 P。' +
      '播放地址由 host 现取现转，B 站直链 120 分钟过期这件事不需要你操心。',
    parameters: {
      ref: {
        type: 'string',
        description: 'BV 号（BV1rE411P7ct）、av 号（av97613422）或完整视频链接，必填',
        required: true
      },
      page: { type: 'integer', description: '第几个分 P（从 1 开始）。不给则用 ref 里带的 `?p=`，再不给就是第 1 段' },
      quality: {
        type: 'integer',
        enum: [...AUDIO_QUALITIES],
        description: '码率档：30280 高位(192K，默认) / 30232 中(132K) / 30216 低(64K)'
      },
      push: {
        type: 'boolean',
        description: '是否推给 Web 面板播放器立即播放，默认 true。只想看稿件信息时传 false。'
      }
    },
    output: {
      schema: { type: 'object' },
      render: (args, value) => {
        if (value.error) return `失败：${value.error}`
        const lines = [
          `**${value.title}**`,
          `　${value.author} · ${value.durationText} · ${value.pageCount} 个分 P · ${value.qualityText}`
        ]
        if (value.pageCount > 1) lines.push(`　当前：第 ${value.page} 段 · ${value.part}（${value.partDuration}）`)
        lines.push(`　${value.url}`)
        if (value.pushed) lines.push('', '已推送到面板播放器，几秒内开始出声。**流式播放，手机不落盘**。')
        if (value.otherPages.length > 0) {
          lines.push('', `其余分 P：${value.otherPages.map((item) => `${item.page}.${item.part}`).join(' | ')}`)
        }
        return lines.join('\n')
      }
    },
    async execute (args) {
      try {
        const ref = String(args.ref ?? '').trim()
        if (ref === '') return { error: 'ref 不能为空（BV 号 / av 号 / 视频链接）' }

        const parsed = parseRef(ref)
        if (parsed.bvid === '' && parsed.aid === 0) return { error: `看不懂这个引用：${ref}` }

        const info = await bilibili.view(parsed.bvid === '' ? { aid: parsed.aid } : parsed.bvid)
        const wanted = Number.isInteger(args.page) ? args.page : parsed.page
        const target = info.pages[wanted - 1]
        if (target === undefined) {
          return { error: `这个稿件没有第 ${wanted} 个分 P（共 ${info.pages.length} 个）` }
        }

        const quality = AUDIO_QUALITIES.includes(Number(args.quality)) ? Number(args.quality) : DEFAULT_QUALITY

        // 真去取一次直链：既验证这个稿件确实有可用音轨（付费/受限的会在这里报错），
        // 也把直链预热进缓存 —— 面板几秒后开始播时就不必再等一次签名请求。
        const stream = await bilibili.stream({ bvid: info.bvid, cid: target.cid, quality })

        let seq = 0
        if (args.push !== false && runtime.pending) {
          seq = runtime.pending.push({
            id: info.bvid,
            title: info.pages.length > 1 ? `${info.title} · ${target.part}` : info.title,
            total: info.pages.length,
            bvid: info.bvid,
            cid: target.cid,
            biliPage: target.page,
            quality,
            source: 'agent'
          }).seq
        }

        return {
          bvid: info.bvid,
          title: info.title,
          author: info.author,
          durationText: info.durationText,
          url: info.url,
          page: target.page,
          part: target.part,
          partDuration: formatDuration(target.duration),
          pageCount: info.pages.length,
          quality,
          qualityText: stream.qualityText || QUALITY_TEXT[quality] || String(quality),
          cached: true,
          pushed: seq > 0,
          seq,
          otherPages: info.pages
            .filter((item) => item.page !== target.page)
            .slice(0, 12)
            .map((item) => ({ page: item.page, part: item.part }))
        }
      } catch (error) {
        return { error: error.message }
      }
    }
  })
}
