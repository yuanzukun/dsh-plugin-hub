/**
 * `asmr_config` —— 查看与修改插件偏好。
 * @module dsh-asmrone/tools/config
 */

import { defineTool } from '../define-tool.js'

export function createConfigTool (runtime) {
  const { getConfig, setConfig, store, api } = runtime

  return defineTool({
    name: 'asmr_config',
    description:
      '查看或修改 asmr.one 插件的使用偏好：下载落盘目录、性别过滤、默认排序、下载并发数、试听体积上限。' +
      '改完立即生效，不需要重启。不传任何参数时只显示当前配置。',
    parameters: {
      outputDir: { type: 'string', description: '下载落盘目录，例如 /sdcard/Download/ASMR' },
      languageFilter: { type: 'string', enum: ['male', 'all'], description: 'male = 搜索时默认剔除女性向/BL；all = 不过滤' },
      defaultOrder: { type: 'string', description: '默认排序字段，如 dl_count / rate_average_2dp / release' },
      downloadConcurrency: { type: 'integer', description: '下载并发数，1~8' },
      maxWorkMb: { type: 'integer', description: 'DLsite 试听包体积上限（MB）' },
      pageSize: { type: 'integer', description: '搜索默认每页条数，1~100' },
      action: { type: 'string', enum: ['show', 'tags'], description: 'show = 显示配置（默认）；tags = 列出 asmr.one 的标签表' }
    },
    output: {
      schema: { type: 'object' },
      render: (args, value) => {
        if (value.error) return `失败：${value.error}`
        if (Array.isArray(value.tags)) {
          const lines = [`asmr.one 标签表（${value.tags.length} 条，按作品数降序）：`, '']
          for (const tag of value.tags.slice(0, 60)) lines.push(`- \`${tag.id}\`　${tag.name}（${tag.count}）`)
          lines.push('', `其余 ${Math.max(0, value.tags.length - 60)} 条已省略。`)
          return lines.join('\n')
        }
        const config = value.config
        return [
          '**asmr.one 插件配置**',
          '',
          `- 落盘目录：\`${config.outputDir}\``,
          `- 性别过滤：${config.languageFilter === 'male' ? '只男性向（剔除女性向/乙女向/BL）' : '不过滤'}`,
          `- 默认排序：${config.defaultOrder}`,
          `- 下载并发：${config.downloadConcurrency}`,
          `- 试听体积上限：${config.maxWorkMb} MB`,
          `- 搜索每页：${config.pageSize}`,
          '',
          `配置文件：\`${value.configPath}\`${value.changed ? '（本次已更新）' : ''}`
        ].join('\n')
      }
    },
    async execute (args) {
      try {
        if (args.action === 'tags') {
          const tags = await api.tags()
          const sorted = tags
            .map((tag) => ({ id: tag.id, name: tag.name, count: Number(tag.count) || 0 }))
            .sort((left, right) => right.count - left.count)
          return { tags: sorted }
        }

        const patch = {}
        for (const key of ['outputDir', 'languageFilter', 'defaultOrder', 'downloadConcurrency', 'maxWorkMb', 'pageSize']) {
          if (args[key] !== undefined) patch[key] = args[key]
        }
        const changed = Object.keys(patch).length > 0
        if (changed) setConfig(patch)
        return { config: getConfig(), configPath: store.configPath, changed }
      } catch (error) {
        return { error: error.message }
      }
    }
  })
}
