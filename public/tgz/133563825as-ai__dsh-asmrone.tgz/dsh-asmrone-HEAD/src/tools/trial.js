/**
 * `asmr_trial` —— DLsite 官方试听：探测 / 在线听 / 下载，三合一。
 *
 * 手机端的 DLsite 只给「在线听」，下载要切电脑模式 —— 这个工具把两个能力都补上：
 *   · `listen: true`  → zip 拉进 host 内存、解开、推给面板流式播放，**磁盘零占用**；
 *   · `download: true` → 落到本地目录，走的是同一份内存数据（先听过就不会再下一次）。
 *
 * 试听是 DLsite 免费公开的，不需要账号。但有相当一部分作品**压根没有音频试听**
 * （只有图片），这时要明确说出来，别让人以为是自己网络坏了。
 *
 * @module dsh-asmrone/tools/trial
 */

import { writeFileSync } from 'node:fs'
import { join } from 'node:path'

import { defineTool } from '../define-tool.js'
import { safeName } from './download.js'

const mb = (bytes) => Math.round((Number(bytes) / 1048576) * 10) / 10

export function createTrialTool (runtime) {
  const { dlsite, trial, getConfig, store } = runtime

  return defineTool({
    name: 'asmr_trial',
    description:
      'DLsite 官方免费试听（不需要账号）：先探测有没有试听包，再决定在线听还是下载。' +
      '三种用法 —— ' +
      '① 只给 workno：探测，报告有几个试听包、多大、有没有音频；' +
      '② `listen: true`：**在线听**，把试听包拉进主机内存解开并推给面板播放器，磁盘不落任何文件' +
      '（DLsite 手机端只给在线听，这条路把它搬进了插件）；' +
      '③ `download: true`：**下载**，把试听音频落到本地目录（手机端原本要切电脑模式才能下）。' +
      '试听包大小两极分化：单集常见 10MB 上下，大合集能到 100MB+；在线听有体积上限，' +
      '超了会提示改用下载。注意不少作品只有图片试听、没有音频，这时会明确说明。',
    parameters: {
      workno: { type: 'string', description: 'DLsite RJ 号，如 RJ01650453（大小写与补零都无所谓）。与 `search` 二选一。' },
      search: {
        type: 'string',
        description:
          '搜 DLsite 作品（与 workno 二选一）。返回带封面、社团、声优、价钱的列表，' +
          '拿到 workno 后再在线听或下载。**日文关键词命中率最高**（「耳かき」「耳舐め」「催眠」）。'
      },
      page: { type: 'integer', description: '搜索页码，从 1 开始，默认 1（仅 search 时有效）' },
      listen: { type: 'boolean', description: '为 true 时在线听：打开试听包并推给面板播放器立即出声（不落盘）' },
      allAges: { type: 'boolean', description: '为 true 时搜索不过滤性别向，默认只搜男性向' },
      index: { type: 'integer', description: '听/下第几轨（从 1 开始）。不给则听第一轨、下载则全部' },
      download: { type: 'boolean', description: '为 true 时把试听音频落盘到本地目录' },
      maxMb: { type: 'integer', description: '单个试听包体积上限（MB），默认取插件配置' },
      outputDir: { type: 'string', description: '覆盖落盘目录（仅 download 时有效）' }
    },
    output: {
      schema: { type: 'object' },
      render: (args, value) => {
        if (value.error) return `失败：${value.error}`

        if (value.mode === 'search') {
          if (value.works.length === 0) {
            return `DLsite 没有命中（关键词「${value.keyword}」）。换个词 —— 日文关键词命中率最高，比如「耳かき」「耳舐め」。`
          }
          const lines = [`DLsite 搜到 **${value.works.length}** 部（关键词「${value.keyword}」· 第 ${value.page} 页）：`, '']
          for (const work of value.works) {
            lines.push(`**${work.workno}**　${work.title}`)
            lines.push(`　${[work.circle, work.voice ? 'CV ' + work.voice : '', work.price ? work.price + ' 円' : '', work.category].filter(Boolean).join(' · ')}`)
          }
          lines.push('', '下一步：拿 `workno` 调 `listen: true` 在线听（不落盘），或 `download: true` 存下来。')
          return lines.join('\n')
        }

        const lines = [`**${value.workno}**　${value.title}`]

        if (value.mode === 'probe') {
          if (value.trials.length === 0) {
            lines.push('', '这部作品**没有提供官方试听包**（DLsite 上有一部分作品就是这样，只有图片试听）。')
            return lines.join('\n')
          }
          lines.push('')
          for (const item of value.trials) lines.push(`试听包：${item.sizeText || '体积未知'}　\`${item.url}\``)
          lines.push('', '要在线听就带 `listen=true`；要落盘就带 `download=true`。')
          return lines.join('\n')
        }

        if (value.mode === 'listen') {
          lines.push(`　${value.tracks.length} 轨 · ${value.sizeText}（zip ${value.zipSizeText}）`, '')
          for (const track of value.tracks) {
            const mark = track.index === value.pushed ? '▶' : '　'
            lines.push(`${mark} ${track.index}. ${track.name}　${track.sizeText}`)
          }
          lines.push('', `已推送到面板播放器，几秒内开始出声（第 ${value.pushed} 轨）。**流式播放，手机不落盘**。`)
          lines.push('想存下来再带 `download=true` —— 会复用这份内存数据，不会再下一次 zip。')
          return lines.join('\n')
        }

        // mode === 'download'
        lines.push('')
        if (value.files.length === 0) {
          lines.push('下载阶段没有产出文件。')
        } else {
          lines.push(`✅ 已存 **${value.files.length}/${value.total}** 个文件到 \`${value.dir}\`（${value.totalMb} MB）：`)
          for (const file of value.files) lines.push(`- ${file.sizeMb} MB　${file.name}`)
          lines.push('', '到面板「本地曲库」里就能直接放这些文件了。')
        }
        for (const failure of value.failures) lines.push(`- ⚠️ ${failure.name}：${failure.error}`)
        return lines.join('\n')
      }
    },
    timeoutMs: 1800000,
    isConcurrencySafe: () => false,
    async execute (args) {
      const config = getConfig()
      const maxMb = Number.isInteger(args.maxMb) && args.maxMb > 0 ? args.maxMb : config.maxWorkMb

      try {
        // ── 搜索 ────────────────────────────────────────────
        // 不下载、不打开，只列出来让人挑 —— 用户不该被逼着去浏览器抄 RJ 号。
        if (typeof args.search === 'string' && args.search.trim() !== '' && !args.workno) {
          const result = await dlsite.search({
            keyword: args.search.trim(),
            page: Math.max(1, Number(args.page) || 1),
            perPage: 30,
            sexCategory: args.allAges === true ? '' : 'male'
          })
          return { mode: 'search', ...result }
        }

        if (typeof args.workno !== 'string' || args.workno.trim() === '') {
          return { error: '要么给 `workno`（RJ 号），要么给 `search`（关键词）。' }
        }

        // ── 在线听 ──────────────────────────────────────────
        if (args.listen === true) {
          const entry = await trial.open(args.workno, { maxMb })
          const list = trial.list(entry.workno)
          const wanted = Number.isInteger(args.index) && args.index > 0 ? args.index : 1
          const track = list.tracks[wanted - 1]
          if (track === undefined) {
            return { error: `第 ${wanted} 轨不存在（共 ${list.tracks.length} 轨）` }
          }

          let seq = 0
          if (runtime.pending) {
            seq = runtime.pending.push({
              id: entry.workno,
              title: `${entry.title} · ${track.name}`,
              total: list.tracks.length,
              trialRj: entry.workno,
              trialIndex: track.index,
              source: 'agent'
            }).seq
          }

          return {
            mode: 'listen',
            workno: entry.workno,
            title: entry.title,
            sizeText: entry.sizeText,
            zipSizeText: entry.zipSizeText,
            tracks: list.tracks,
            pushed: track.index,
            pushedOk: seq > 0,
            seq
          }
        }

        // ── 下载 ────────────────────────────────────────────
        if (args.download === true) {
          const root = typeof args.outputDir === 'string' && args.outputDir.trim() !== ''
            ? args.outputDir.trim()
            : join(config.outputDir, 'DLsite试听')

          const info = await dlsite.workInfo(args.workno)
          const dir = store.ensureDir(join(root, safeName(`${info.title}_${info.workno}`)))

          let saved
          try {
            // 先试内存路径：读过就直接写盘。
            const opened = await trial.open(info.workno, { maxMb: Math.max(maxMb, 200) })
            saved = await trial.saveAll(info.workno, dir)
            void opened
          } catch {
            // 走到这儿通常不是「内存放不下」（分段读之后不存在这回事），而是包里没有音频，
            // 或者调用方把 maxMb 压得很低。退回直连，但**仍然逐条按需取**，
            // 绝不把整包拉进内存 —— 试听包真有两百多 MB 的。
            saved = { dir, workno: info.workno, title: info.title, saved: 0, total: 0, bytes: 0, files: [], failures: [] }
            for (const item of info.trials) {
              if (item.sizeMb > maxMb) {
                saved.failures.push({ name: item.url, error: `${item.sizeText} 超过上限 ${maxMb}MB，跳过` })
                continue
              }
              try {
                const zip = await dlsite.openZip(item.url)
                for (const entry of zip.entries) {
                  if (entry.name.endsWith('/')) continue
                  // 封面图之类的非音频也一并留着 —— 试听包本来就只有这些东西，无所谓。
                  const name = entry.name.split('/').pop() ?? entry.name
                  const data = await zip.read(entry)
                  const filePath = join(dir, safeName(name, 'track'))
                  writeFileSync(filePath, data)
                  saved.files.push({ name, bytes: data.length, sizeMb: mb(data.length) })
                  saved.bytes += data.length
                  saved.total += 1
                }
              } catch (error) {
                saved.failures.push({ name: item.url, error: error.message })
              }
            }
          }

          const totalMb = Math.round((saved.bytes / 1048576) * 10) / 10
          return {
            mode: 'download',
            workno: saved.workno ?? info.workno,
            title: saved.title ?? info.title,
            dir: saved.dir,
            files: saved.files,
            failures: saved.failures,
            total: saved.total,
            totalMb
          }
        }

        // ── 探测 ────────────────────────────────────────────
        const info = await dlsite.workInfo(args.workno)
        return { mode: 'probe', workno: info.workno, title: info.title, trials: info.trials }
      } catch (error) {
        return { error: error.message }
      }
    }
  })
}
