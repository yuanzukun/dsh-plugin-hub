/**
 * `asmr_delete` —— 删掉已经下到本机的音频。
 *
 * 三种粒度：单轨、整部、一次多部（批量）。**这是不可逆的破坏性操作**，所以：
 *   · 默认先 `dryRun` 报一遍「会删什么、腾多少空间」，确认无误再真删；
 *   · 每一条路径在 host 侧单独过一次 `LocalLibrary.resolveWithin`，
 *     根目录之外的、软链指向外面的，一律跳过并如实报告。
 *
 * @module dsh-asmrone/tools/delete
 */

import { defineTool } from '../define-tool.js'

export function createDeleteTool (runtime) {
  const { library } = runtime

  return defineTool({
    name: 'asmr_delete',
    description:
      '删除已下载到本机的音频，支持单轨 / 整部 / 一次多部批量。' +
      '**这是不可逆操作，没有回收站。**' +
      '用法一（先看）：不带 keys 调用 —— 列出本地库里的作品与它们的 key，可带 query 过滤。' +
      '用法二（算一遍）：带 keys 且 `dryRun: true` —— 只报告会删掉多少轨、腾出多少空间，一个字节都不动。' +
      '用法三（真删）：带 keys —— 整部删（目录连封面一起收掉）；再带 indexes 就只删指定的那几轨。' +
      '建议：先 dryRun 把结果念给用户听，用户点头了再去掉 dryRun 重发一次。',
    parameters: {
      keys: {
        type: 'array',
        items: { type: 'string' },
        description: '要删的作品 key（先不带 keys 调一次拿到）。可以给多个 —— 那就是批量删。'
      },
      indexes: {
        type: 'array',
        items: { type: 'integer' },
        description: '只删这几轨（从 1 开始）。省略或空数组 = 整部删。只在 keys 恰好一项时生效。'
      },
      query: { type: 'string', description: '按作品名 / 文件名 / RJ 号过滤，用于列出候选' },
      dryRun: { type: 'boolean', description: '为 true 时只算不删，先看清要动什么' }
    },
    output: {
      schema: { type: 'object' },
      render: (args, value) => {
        if (value.error) return `失败：${value.error}`

        if (value.mode === 'list') {
          if (value.works.length === 0) {
            return `本地库里没有匹配的东西${args.query ? `（过滤词「${args.query}」）` : ''}。`
          }
          const lines = [
            `本地库 ${value.total.works} 部 / ${value.total.files} 轨 / ${value.total.sizeText}${args.query ? `（过滤「${args.query}」）` : ''}`,
            ''
          ]
          for (const work of value.works) {
            lines.push(`**${work.name}**　${work.count} 轨 · ${work.sizeText}${work.rj ? ` · RJ${work.rj}` : ''}`)
            lines.push(`　key=\`${work.key}\``)
          }
          lines.push('', '要删就带上 `keys=` 再调一次；先加 `dryRun: true` 看一遍更稳。')
          return lines.join('\n')
        }

        const head = value.dryRun
          ? `预演（**没有真删**）：将移除 ${value.totals.files} 个文件 / 腾出 ${value.totals.sizeText}`
          : `已移除 ${value.totals.files} 个文件 / 腾出 ${value.totals.sizeText}`
        const lines = [head, '']
        for (const row of value.results) {
          const mark = row.status === 'removed' ? '✓' : row.status === 'partial' ? '!' : '✗'
          const scope = row.wholeWork ? '整部' : `${row.removed} 轨`
          lines.push(`${mark} ${row.name}　${scope} · ${row.sizeText}${row.dirRemoved ? ' · 目录已收掉' : ''}`)
          if (row.error !== '') lines.push(`　⚠ ${row.error}`)
        }
        if (value.dryRun) lines.push('', '确认无误后去掉 `dryRun` 重发一次即可真删。')
        return lines.join('\n')
      }
    },
    async execute (args) {
      try {
        const query = String(args.query ?? '').trim()
        const keys = Array.isArray(args.keys) ? args.keys.map(String).filter((key) => key.trim() !== '') : []

        // 没给 keys = 列候选。删东西之前先让人看清 key 长什么样。
        if (keys.length === 0) {
          const snapshot = library.scan()
          const works = query === '' ? snapshot.works : library.find(query)
          return {
            mode: 'list',
            total: snapshot.totals,
            works: works.slice(0, 60).map((work) => ({
              key: work.key,
              name: work.name,
              rj: work.rj,
              count: work.count,
              sizeText: work.sizeText,
              source: work.source
            }))
          }
        }

        const indexes = Array.isArray(args.indexes)
          ? args.indexes.map(Number).filter((value) => Number.isInteger(value) && value > 0)
          : []
        // indexes 只在单部时有意义：一次删多部时轨号跟哪一部都对不上，
        // 硬套只会删错东西 —— 所以多部时忽略 indexes，一律整部删。
        const targets = keys.map((key) => ({
          key,
          indexes: keys.length === 1 ? indexes : []
        }))

        const result = library.remove(targets, { dryRun: args.dryRun === true })
        return { mode: 'remove', ...result }
      } catch (error) {
        return { error: error.message }
      }
    }
  })
}
