/**
 * `asmr_search` —— 在 asmr.one 曲库里搜作品。
 * @module dsh-asmrone/tools/search
 */

import { defineTool } from '../define-tool.js'
import { ORDER_FIELDS, isFemaleOriented, summarizeWork } from '../api.js'

export function createSearchTool (runtime) {
  const { api, getConfig } = runtime

  return defineTool({
    name: 'asmr_search',
    description:
      '在 asmr.one（DLsite 同人音声整库镜像，六万余部）里搜索作品。支持关键词、排序、分页，' +
      '默认只返回男性向作品（剔除女性向/乙女向/BL）。返回带评分、销量、时长、声优、标签和作品页地址。' +
      '关键词可填中文题材（如「舔耳」「催眠」「NTR」）、社团名、声优名，或官方中文版标记「简体中文版」。',
    parameters: {
      query: { type: 'string', description: '搜索关键词；留空则返回全库按销量排序的列表' },
      order: {
        type: 'string',
        enum: [...ORDER_FIELDS],
        description: '排序字段，默认 dl_count（销量）'
      },
      page: { type: 'integer', description: '页码，从 1 开始，默认 1' },
      pageSize: { type: 'integer', description: '每页条数，默认 20，上限 100' },
      chineseOnly: { type: 'boolean', description: '只返回标题带中文版标记的作品' },
      includeFemaleOriented: { type: 'boolean', description: '为 true 时不过滤女性向作品' }
    },
    output: {
      schema: { type: 'object' },
      render: (args, value) => {
        if (value.error) return `搜索失败：${value.error}`
        if (value.works.length === 0) return `没有命中（关键词「${args.query ?? ''}」，第 ${value.page} 页）。换个词或放宽过滤试试。`
        const lines = [
          `asmr.one 命中 **${value.total}** 部${args.query ? `（关键词「${args.query}」）` : ''} · 第 ${value.page} 页 · 按 ${value.order} 排序`,
          ''
        ]
        for (const work of value.works) {
          const meta = [
            work.rating ? `★${work.rating}(${work.ratingCount})` : null,
            `销 ${work.downloads}`,
            work.durationText,
            work.voiceActors.length > 0 ? `CV ${work.voiceActors.join('、')}` : null,
            work.hasSubtitle ? '中文字幕' : null
          ].filter((item) => item !== null).join(' · ')
          lines.push(`**${work.id}**　${work.title}`)
          lines.push(`　${work.circle} · ${meta}`)
          if (work.tags.length > 0) lines.push(`　标签：${work.tags.join(' / ')}`)
          lines.push(`　${work.url}`)
          lines.push('')
        }
        lines.push('下一步：拿 id 调 `asmr_work` 看音轨，或直接 `asmr_download` 下到手机。')
        return lines.join('\n')
      }
    },
    async execute (args) {
      const config = getConfig()
      const page = Math.max(1, Number(args.page) || 1)
      const pageSize = Math.min(Math.max(Number(args.pageSize) || config.pageSize, 1), 100)
      const order = ORDER_FIELDS.includes(args.order) ? args.order : config.defaultOrder

      try {
        const result = await api.search({ query: args.query ?? '', page, pageSize: pageSize * (args.chineseOnly || !args.includeFemaleOriented ? 2 : 1), order })
        let works = result.works
        if (args.chineseOnly === true) works = works.filter((work) => /简体中文版|繁體中文版|中文版/.test(String(work?.title ?? '')))
        if (args.includeFemaleOriented !== true && config.languageFilter === 'male') {
          works = works.filter((work) => !isFemaleOriented(work))
        }
        works = works.slice(0, pageSize)
        return {
          total: result.total,
          page,
          order,
          works: works.map((work) => summarizeWork(work, (id) => api.workPageUrl(id)))
        }
      } catch (error) {
        return { error: error.message, works: [], total: 0, page, order }
      }
    }
  })
}
