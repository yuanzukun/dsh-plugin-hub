/**
 * 本地音声库 —— 让插件认得到「已经下到手机上的那些」。
 *
 * 存在的理由很实际：asmr.one 是境外站，没有代理时在线搜索、在线播放、封面全部不可用。
 * 但用户机器上往往已经躺着几个 G 的音声（`asmr_download` 下的，或 DLsite 试听包解出来的），
 * 那些文件**根本不需要网络**。没有这个模块，面板在离线时等于一块砖。
 *
 * ## 结构假设（两个来源都符合）
 *
 * ```
 * <根目录>/<作品名>/<音轨文件>.mp3
 * <根目录>/<作品名>_RJ01726233/<音轨文件>.wav
 * ```
 *
 * 也就是「两层：作品目录 + 文件」。所以聚合单位取**文件的父目录**，而不是猜层级 ——
 * 文件直接堆在根目录下时，父目录就是根，作品名退回根目录名。
 *
 * ## 缓存
 *
 * 扫 4.6G / 147 个文件要遍历目录树 + 逐个 `statSync`，几百毫秒级；面板每次刷新都跑一遍
 * 是浪费。带 60 秒 TTL，`force` 可绕过（面板上的「重新扫描」用它）。
 *
 * @module dsh-asmrone/local
 */

import { existsSync, readdirSync, realpathSync, rmSync, statSync, unlinkSync } from 'node:fs'
import { basename, dirname, extname, isAbsolute, join, resolve, sep } from 'node:path'

/** 能被浏览器/WebView 直接喂给 `<audio>` 的扩展名。WAV 也算 —— 体积大但能流式播。 */
export const AUDIO_EXTENSIONS = Object.freeze(['mp3', 'm4a', 'aac', 'ogg', 'opus', 'flac', 'wav'])

const AUDIO_EXT_SET = new Set(AUDIO_EXTENSIONS)

const MIME_BY_EXT = Object.freeze({
  mp3: 'audio/mpeg',
  m4a: 'audio/mp4',
  aac: 'audio/aac',
  ogg: 'audio/ogg',
  opus: 'audio/ogg',
  flac: 'audio/flac',
  wav: 'audio/wav'
})

/** 递归深度上限。两层是常态，留点余量但不给爆栈的机会。 */
const MAX_DEPTH = 5

/**
 * @param {string} file
 * @returns {string} 可直接用作 `Content-Type` 的 MIME
 */
export function mimeOf (file) {
  const ext = extname(String(file ?? '')).slice(1).toLowerCase()
  return MIME_BY_EXT[ext] ?? 'application/octet-stream'
}

/**
 * @param {number} bytes
 * @returns {string} 人类可读体积。非有限值给 `0 B`，不把 NaN 漏到界面上。
 */
export function formatBytes (bytes) {
  const value = Number(bytes)
  if (!Number.isFinite(value) || value < 0) return '0 B'
  if (value < 1024) return `${Math.round(value)} B`
  const units = ['KB', 'MB', 'GB', 'TB']
  let scaled = value / 1024
  let index = 0
  while (scaled >= 1024 && index < units.length - 1) {
    scaled /= 1024
    index += 1
  }
  return `${scaled >= 100 ? Math.round(scaled) : scaled.toFixed(1)} ${units[index]}`
}

/**
 * 从目录名里抠 RJ 号，归一成纯数字。
 *
 * 试听包的目录名形如 `【マッサージ・囁き・耳かき】おしごとねいろ 〜整体師編〜【CV.中島由貴】_RJ01726233`，
 * 下载目录则是 `RJ01057368_mp3_...`。归一后能跟在线搜索结果里的 id 直接对上，
 * 「这部我下过了」才有得判。
 *
 * @param {string} name
 * @returns {string} 数字串，找不到给空串
 */
export function rjFromName (name) {
  const match = /RJ0*(\d{4,})/i.exec(String(name ?? ''))
  return match ? match[1] : ''
}

/** 目录名里带「試聴」「试听」「sample」「体験版」的，多半是试听包。简繁日三种写法都要认。 */
export function looksLikeTrial (name) {
  return /試聴|試聽|试听|体験版|體驗版|体验版|sample|trial/i.test(String(name ?? ''))
}

/**
 * 递归收集音频文件。
 * @param {string} dir
 * @param {number} depth
 * @param {object[]} out
 */
function walk (dir, depth, out) {
  if (depth > MAX_DEPTH) return out
  let entries
  try {
    entries = readdirSync(dir, { withFileTypes: true })
  } catch {
    // 目录没权限 / 半路被删：跳过这一支，不要把整次扫描带崩
    return out
  }
  for (const entry of entries) {
    const full = join(dir, entry.name)
    if (entry.isDirectory()) {
      walk(full, depth + 1, out)
      continue
    }
    if (!entry.isFile()) continue
    const ext = extname(entry.name).slice(1).toLowerCase()
    if (!AUDIO_EXT_SET.has(ext)) continue
    let stat
    try {
      stat = statSync(full)
    } catch {
      continue
    }
    out.push({
      path: full,
      name: entry.name,
      ext,
      bytes: stat.size,
      sizeText: formatBytes(stat.size),
      mtime: stat.mtimeMs,
      playable: true
    })
  }
  return out
}

export class LocalLibrary {
  #store
  #ttlMs
  #cache = null

  /**
   * @param {object} [options]
   * @param {import('./store.js').AsmrStore} [options.store] - 用来读 `outputDir` 与 `localDirs`
   * @param {number} [options.ttlMs]
   */
  constructor ({ store = null, ttlMs = 60_000 } = {}) {
    this.#store = store
    this.#ttlMs = Number.isFinite(ttlMs) && ttlMs >= 0 ? ttlMs : 60_000
  }

  /**
   * 生效的根目录：`outputDir` 在前（索引 0，标记为「下载」），其余按配置顺序。
   * 只保留绝对路径、去重，不做存在性过滤 —— 那一步交给 `scan`，面板要能看到「配了但不存在」。
   * @returns {string[]}
   */
  roots () {
    const config = this.#store?.get?.() ?? {}
    const list = []
    const push = (value) => {
      if (typeof value !== 'string') return
      const trimmed = value.trim()
      if (trimmed === '' || !isAbsolute(trimmed)) return
      const normalized = resolve(trimmed)
      if (!list.includes(normalized)) list.push(normalized)
    }
    push(config.outputDir)
    for (const dir of Array.isArray(config.localDirs) ? config.localDirs : []) push(dir)
    return list
  }

  /**
   * 扫描并聚合。带 TTL 缓存。
   * @param {{ force?: boolean }} [options]
   */
  scan ({ force = false } = {}) {
    const now = Date.now()
    if (!force && this.#cache !== null && now - this.#cache.scannedAt < this.#ttlMs) {
      return this.#cache
    }

    const roots = this.roots()
    const works = []
    const rootReports = []

    roots.forEach((root, rootIndex) => {
      const exists = existsSync(root)
      let isDirectory = false
      if (exists) {
        try {
          isDirectory = statSync(root).isDirectory()
        } catch {
          isDirectory = false
        }
      }

      const files = exists && isDirectory ? walk(root, 0, []) : []
      const grouped = new Map()
      for (const file of files) {
        const dir = dirname(file.path)
        if (!grouped.has(dir)) grouped.set(dir, [])
        grouped.get(dir).push(file)
      }

      for (const [dir, dirFiles] of grouped) {
        // 文件名排序：`track2` 要排在 `track10` 前面，纯字符串比较做不到。
        dirFiles.sort((a, b) => a.name.localeCompare(b.name, 'zh-Hans', { numeric: true, sensitivity: 'base' }))
        const bytes = dirFiles.reduce((sum, file) => sum + file.bytes, 0)
        const name = dir === root ? basename(root) : basename(dir)
        works.push({
          key: `${rootIndex}:${dir}`,
          root,
          rootIndex,
          dir,
          name,
          rj: rjFromName(dir) || rjFromName(name),
          source: rootIndex === 0 ? 'download' : 'library',
          trial: looksLikeTrial(dir),
          files: dirFiles,
          count: dirFiles.length,
          bytes,
          sizeText: formatBytes(bytes)
        })
      }

      rootReports.push({
        path: root,
        exists,
        isDirectory,
        works: grouped.size,
        files: files.length,
        bytes: files.reduce((sum, file) => sum + file.bytes, 0)
      })
    })

    // 作品排序：有 RJ 号的在前（更像正经作品），再按体积降序 —— 大的多半是完整版。
    works.sort((a, b) => {
      if (Boolean(a.rj) !== Boolean(b.rj)) return a.rj ? -1 : 1
      if (a.bytes !== b.bytes) return b.bytes - a.bytes
      return a.name.localeCompare(b.name, 'zh-Hans', { numeric: true, sensitivity: 'base' })
    })

    const totals = {
      works: works.length,
      files: works.reduce((sum, work) => sum + work.count, 0),
      bytes: works.reduce((sum, work) => sum + work.bytes, 0)
    }

    this.#cache = {
      scannedAt: now,
      roots: rootReports.map((root) => ({ ...root, sizeText: formatBytes(root.bytes) })),
      works,
      totals: { ...totals, sizeText: formatBytes(totals.bytes) }
    }
    return this.#cache
  }

  /** 丢掉缓存，下次 `scan()` 重新走盘。 */
  invalidate () {
    this.#cache = null
  }

  /** 按作品名 / 文件名 / RJ 号过滤。`query` 为空时返回全部。 */
  find (query = '') {
    const needle = String(query ?? '').trim().toLowerCase()
    const { works } = this.scan()
    if (needle === '') return works
    return works.filter((work) => {
      if (work.name.toLowerCase().includes(needle)) return true
      if (work.rj !== '' && work.rj.includes(needle.replace(/^rj0*/i, ''))) return true
      return work.files.some((file) => file.name.toLowerCase().includes(needle))
    })
  }

  /** @param {string} key */
  work (key) {
    return this.scan().works.find((row) => row.key === String(key)) ?? null
  }

  /**
   * 取某部作品里第 n 轨（从 1 开始）。
   * @param {string} key
   * @param {number} index
   */
  track (key, index = 1) {
    const work = this.work(key)
    if (work === null) return null
    const position = Number.isInteger(index) ? index : 1
    if (position < 1 || position > work.files.length) return null
    return { work, file: work.files[position - 1], index: position }
  }

  /**
   * 把一个外部传入的路径限制在允许的根目录内。
   *
   * 这是本地流路由唯一的入口校验，必须走 `realpath` —— 光比字符串前缀挡不住符号链接；
   * 前缀比较还要带上分隔符，否则 `/sdcard/asmr-evil` 会被 `/sdcard/asmr` 放行。
   *
   * @param {string} requested 绝对路径
   * @returns {string|null} 校验通过的真实路径，否则 null
   */
  resolveWithin (requested) {
    const raw = String(requested ?? '').trim()
    if (raw === '' || !isAbsolute(raw)) return null

    const ext = extname(raw).slice(1).toLowerCase()
    if (!AUDIO_EXT_SET.has(ext)) return null

    let real
    try {
      real = realpathSync(resolve(raw))
    } catch {
      return null
    }
    if (!existsSync(real)) return null

    for (const root of this.roots()) {
      if (real === root) return null
      if (real.startsWith(root + sep)) return real
      // 根目录本身也可能是软链（/sdcard 就常是），两边都解析一次
      try {
        const realRoot = realpathSync(root)
        if (real !== realRoot && real.startsWith(realRoot + sep)) return real
      } catch {
        /* 根不存在，换下一个 */
      }
    }
    return null
  }

  /**
   * 把一个**目录**限制在允许的根之内，并且不允许就是根本身。
   *
   * 删除比播放危险一个量级：播放读错了顶多是读到不该读的，删除删错了就是数据没了。
   * 所以这里比 `resolveWithin` 多两条约束：
   *   · `realpath` 解析后**必须比根深至少一级** —— 永远不允许把配的根目录自己删掉；
   *   · 走 `realpath` 而不是字符串比较 —— 挡掉「根里面塞一个指向外面的软链」。
   *
   * @param {string} requested 绝对路径
   * @returns {{real: string, root: string}|null}
   */
  resolveDirWithin (requested) {
    const raw = String(requested ?? '').trim()
    if (raw === '' || !isAbsolute(raw) || raw.includes('\0')) return null

    let real
    try {
      real = realpathSync(resolve(raw))
    } catch {
      return null
    }

    for (const root of this.roots()) {
      let realRoot = root
      try {
        realRoot = realpathSync(root)
      } catch {
        continue
      }
      if (real === realRoot) return null
      if (!real.startsWith(realRoot + sep)) continue
      const relative = real.slice(realRoot.length + 1)
      if (relative === '') return null
      return { real, root: realRoot }
    }
    return null
  }

  /**
   * 删除已下载的内容 —— 单个轨、某部的全部轨、或一次多部（面板多选走这里）。
   *
   * `targets` 里每一项是 `{ key, indexes }`：
   *   · `indexes` 为空数组或省略 → **整部删**（音频全清之后连目录一起收掉，
   *     因为试听包目录里还躺着封面图和 md，只删音频会在盘上留个空壳）；
   *   · `indexes` 给从 1 起的轨号 → 只删这几轨，目录留着。
   *
   * 每一轨都**单独走一遍 `resolveWithin`**，而不是信 `work.files` 里那份扫描结果：
   * 从扫盘到用户点删除之间，路径上的任何一段都可能被换成软链（TOCTOU）。
   *
   * @param {{key: string, indexes?: number[]}[]} targets
   * @param {{dryRun?: boolean}} [options] dryRun 只算一遍要删什么，一个字节都不动
   */
  remove (targets, { dryRun = false } = {}) {
    const list = Array.isArray(targets) ? targets : []
    const results = []
    let removedFiles = 0
    let freedBytes = 0
    let removedWorks = 0

    for (const target of list) {
      const key = String(target?.key ?? '')
      const work = this.work(key)
      if (work === null) {
        results.push({ key, name: key, status: 'missing', removed: 0, bytes: 0, sizeText: '0 B', error: '本地库里没有这一项（可能已经被删掉了）' })
        continue
      }

      const wanted = Array.isArray(target?.indexes)
        ? target.indexes.map(Number).filter((value) => Number.isInteger(value) && value > 0)
        : []
      // 空 indexes = 整部。面板的「删整部」和多选批量都走这条。
      const wholeWork = wanted.length === 0
      const picked = wholeWork ? work.files : work.files.filter((_, index) => wanted.includes(index + 1))

      if (picked.length === 0) {
        results.push({ key, name: work.name, status: 'missing', removed: 0, bytes: 0, sizeText: '0 B', error: '没有匹配的轨，可能编号已经变了' })
        continue
      }

      let removed = 0
      let bytes = 0
      const failures = []

      for (const file of picked) {
        const safe = this.resolveWithin(file.path)
        if (safe === null) {
          failures.push(`${file.name}: 路径不在允许的目录内，已跳过`)
          continue
        }
        try {
          if (!dryRun) unlinkSync(safe)
          removed += 1
          bytes += file.bytes
        } catch (error) {
          failures.push(`${file.name}: ${error.message}`)
        }
      }

      // 整部删除且这一个都没漏，连目录一起收 —— 但仍要过目录版的安全校验。
      let dirRemoved = false
      if (wholeWork && removed === picked.length && !dryRun) {
        const dirInfo = this.resolveDirWithin(work.dir)
        if (dirInfo === null) {
          if (work.dir !== work.root) failures.push('目录不在允许的根之内，保留原样')
        } else {
          try {
            rmSync(dirInfo.real, { recursive: true, force: true })
            dirRemoved = true
          } catch (error) {
            failures.push(`目录：${error.message}`)
          }
        }
      }

      removedFiles += removed
      freedBytes += bytes
      if (wholeWork && removed > 0) removedWorks += 1

      results.push({
        key,
        name: work.name,
        status: failures.length === 0 ? 'removed' : (removed > 0 ? 'partial' : 'failed'),
        removed,
        bytes,
        sizeText: formatBytes(bytes),
        dirRemoved,
        wholeWork,
        error: failures.length === 0 ? '' : failures.join('；')
      })
    }

    // 盘上的东西变了，缓存立刻作废 —— 否则面板下一次刷新还会列出刚删掉的东西。
    if (!dryRun && removedFiles > 0) this.invalidate()

    return {
      dryRun,
      results,
      totals: {
        targets: list.length,
        works: removedWorks,
        files: removedFiles,
        bytes: freedBytes,
        sizeText: formatBytes(freedBytes)
      }
    }
  }
}
