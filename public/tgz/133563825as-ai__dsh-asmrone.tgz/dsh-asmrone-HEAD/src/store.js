/**
 * 配置与落盘路径。
 *
 * 属于某台机器的偏好（下载目录、并发数、默认排序）放在容器里的 JSON 文件，
 * 不写进插件的 `cordis.patch.yml` —— 那个文件升级插件时会被覆盖。
 *
 * 配置损坏时退回默认值而不抛错：插件不该因为一个手改坏的 JSON 整条起不来。
 *
 * @module dsh-asmrone/store
 */

import { homedir } from 'node:os'
import { isAbsolute, join, resolve } from 'node:path'
import { existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs'

const DEFAULTS = Object.freeze({
  outputDir: '',
  // 额外的本地音声根目录（试听包解出来的、手动拷进去的…）。
  // outputDir 永远是第 0 个根，这个数组接在它后面。
  localDirs: [],
  languageFilter: 'male',
  defaultOrder: 'dl_count',
  downloadConcurrency: 4,
  maxWorkMb: 800,
  pageSize: 20
})

/** 可写字段白名单，`asmr_config` 与 API 都只认这些。 */
export const CONFIG_KEYS = Object.freeze(Object.keys(DEFAULTS))

/**
 * dsh 的家目录：优先 Cordis 上下文，其次环境变量，最后 `~/.dsh`。
 * @param {object} [ctx]
 * @returns {string}
 */
export function resolveDshHome (ctx) {
  if (typeof ctx?.dshHomePath === 'function') {
    const fromContext = ctx.dshHomePath()
    if (typeof fromContext === 'string' && fromContext.trim() !== '') return fromContext.trim()
  }
  const fromEnv = process.env.DSH_HOME
  if (typeof fromEnv === 'string' && fromEnv.trim() !== '') return resolve(fromEnv)
  return join(homedir(), '.dsh')
}

function clampInt (value, min, max, fallback) {
  const number = Number(value)
  if (!Number.isFinite(number)) return fallback
  return Math.min(Math.max(Math.round(number), min), max)
}

/**
 * 配置读写。一个 profile 一个实例，路径在构造时定死。
 */
export class AsmrStore {
  /**
   * @param {object} options
   * @param {object} [options.ctx] - Cordis 上下文，用于拿 dshHomePath。
   * @param {object} [options.config] - profile `cordis.patch.yml` 里传进来的基础设施配置。
   * @param {string} [options.dataRoot] - 覆盖数据目录（测试用）。
   */
  constructor ({ ctx, config = {}, dataRoot = '' } = {}) {
    this.ctx = ctx
    this.dataRoot = dataRoot !== '' ? dataRoot : join(resolveDshHome(ctx), 'asmrone')
    this.configPath = join(this.dataRoot, 'config.json')
    // 优先级：profile 里的配置 > 容器 JSON > 内置默认
    this.infra = {
      outputDir: typeof config.outputDir === 'string' ? config.outputDir.trim() : '',
      downloadConcurrency: config.downloadConcurrency,
      pageSize: config.pageSize
    }
    this.current = this.#read()
  }

  #read () {
    let stored = {}
    if (existsSync(this.configPath)) {
      try {
        const parsed = JSON.parse(readFileSync(this.configPath, 'utf8'))
        if (parsed !== null && typeof parsed === 'object' && !Array.isArray(parsed)) stored = parsed
      } catch {
        stored = {}
      }
    }
    const merged = { ...DEFAULTS, ...stored }
    if (this.infra.outputDir !== '') merged.outputDir = this.infra.outputDir
    if (this.infra.downloadConcurrency !== undefined) merged.downloadConcurrency = this.infra.downloadConcurrency
    if (this.infra.pageSize !== undefined) merged.pageSize = this.infra.pageSize

    merged.outputDir = typeof merged.outputDir === 'string' && merged.outputDir.trim() !== ''
      ? merged.outputDir.trim()
      : this.defaultOutputDir()
    merged.languageFilter = ['male', 'all'].includes(merged.languageFilter) ? merged.languageFilter : 'male'
    merged.defaultOrder = typeof merged.defaultOrder === 'string' && merged.defaultOrder !== ''
      ? merged.defaultOrder
      : DEFAULTS.defaultOrder
    merged.downloadConcurrency = clampInt(merged.downloadConcurrency, 1, 8, DEFAULTS.downloadConcurrency)
    merged.maxWorkMb = clampInt(merged.maxWorkMb, 50, 20000, DEFAULTS.maxWorkMb)
    merged.pageSize = clampInt(merged.pageSize, 1, 100, DEFAULTS.pageSize)
    // 一定要重新建数组：上面是浅拷贝，直接留用会让 DEFAULTS 里那个数组被后续 set() 改到。
    merged.localDirs = Array.isArray(merged.localDirs)
      ? merged.localDirs.filter((dir) => typeof dir === 'string' && dir.trim() !== '').map((dir) => dir.trim())
      : []
    return merged
  }

  /**
   * 有外置存储就落 `/sdcard/Download/ASMR`，否则退回数据目录。
   * @returns {string}
   */
  defaultOutputDir () {
    return existsSync('/sdcard') ? '/sdcard/Download/ASMR' : join(this.dataRoot, 'downloads')
  }

  /** @returns {object} 当前生效的配置（只读快照）。 */
  get () {
    return { ...this.current }
  }

  /**
   * 覆盖写入白名单字段。
   * @param {object} patch
   * @returns {object} 合并后的完整配置
   */
  set (patch) {
    for (const key of CONFIG_KEYS) {
      if (patch?.[key] !== undefined) this.current[key] = patch[key]
    }
    mkdirSync(this.dataRoot, { recursive: true })
    writeFileSync(this.configPath, `${JSON.stringify(this.current, null, 2)}\n`, 'utf8')
    this.current = this.#read()
    return this.get()
  }

  /**
   * 确保目录存在，返回绝对路径。
   * @param {string} directory
   * @returns {string}
   */
  ensureDir (directory) {
    const target = isAbsolute(directory) ? directory : join(this.dataRoot, directory)
    mkdirSync(target, { recursive: true })
    return target
  }
}
