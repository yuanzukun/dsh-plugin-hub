/**
 * 内存试听库 —— 「在线听」里不落盘的那一半。
 *
 * ## 为什么是内存
 *
 * DLsite 官方试听是一条 `RJxxxxxxxx_trial.zip`。手机上点「试听」听到的东西，
 * 剥开看就是它 —— 没有任何独立的音频流接口（试过 `play.dlsite.com` 的
 * `/api/sample/token/{workno}` + `ziptree.json` + `/optimized/{hash}.m3u8` 那条链，
 * 对没有音频试听的作品稳定 404，而真正有音频试听的作品走的是同一份 zip）。
 *
 * 既然源头就是 zip，就直接按 zip 的随机访问能力来用：**打开时只取中央目录**
 * （尾部几十 KB），**播放那一轨时才按偏移 Range 取回来并 inflate**，
 * 切片喂给播放器。磁盘上一个字节都不会产生 —— 这正是「手机只能在线听」
 * 和「不下载」能同时成立的原因。
 *
 * ## 为什么不是「整包下载 + 全部解压」
 *
 * 一开始就是那么写的，在真机上撞了墙：100MB 的包解压后驻留 149MB（包里常带
 * 一轨未压缩的 wav），而 200MB+ 的大合集直接没救 —— 宿主机可用内存只有 2GB
 * 出头，硬吃会触发 OOM，那是会把 dsh 一起带走的事故。所以上限不该靠调大，
 * 而该靠**不拉**。
 *
 * ## 体量控制
 *
 *   · 包体积上限（默认 800MB）—— 分段读之后它跟内存无关，只是防误点巨物；
 *   · 单轨上限（默认 200MB）—— 这条是真的内存闸门：deflate 不支持随机访问，
 *     想切中间一段也得整轨 inflate，所以当前这一轨必须完整驻留；
 *   · 已解压的轨按 LRU 缓存（默认 256MB），同时最多留 `maxWorks` 部。
 *
 * 超限不是错误路径，而是一条**明确的岔路**：报「太大，建议走下载」。
 * 下载那条路（`save` / `saveAll`）逐轨取、逐轨写盘，不受单轨闸门约束。
 *
 * @module dsh-asmrone/trial
 */

import { mkdirSync, writeFileSync } from 'node:fs'
import { dirname, join } from 'node:path'

import { AUDIO_EXTENSIONS } from './local.js'

/** 能被浏览器直接喂给 `<audio>` 的扩展名，跟本地库用同一套。 */
const AUDIO_RE = new RegExp(`\\.(${AUDIO_EXTENSIONS.join('|')})$`, 'i')

/** 文件名里的非法字符。试听包里的名字来自作品标题，什么符号都可能有。 */
function safeFileName (name) {
  const cleaned = String(name ?? '')
    .replace(/[/\\:*?"<>|\u0000-\u001f]/g, '_')
    .replace(/^\.+/, '')
    .trim()
  return cleaned === '' ? 'track' : cleaned.slice(0, 120)
}

function formatBytes (bytes) {
  const value = Number(bytes)
  if (!Number.isFinite(value) || value <= 0) return '0 B'
  if (value < 1024) return `${Math.round(value)} B`
  const units = ['KB', 'MB', 'GB']
  let scaled = value / 1024
  let index = 0
  while (scaled >= 1024 && index < units.length - 1) {
    scaled /= 1024
    index += 1
  }
  return `${scaled >= 100 ? Math.round(scaled) : scaled.toFixed(1)} ${units[index]}`
}

export class TrialLibrary {
  #dlsite
  #store
  #maxWorks
  #maxMb
  #maxTrackMb
  #maxCacheBytes
  #ttlMs
  #entries = new Map()
  /** 已经解压出来的轨数据：`${workno}#${index}` → `{data, bytes}`，按 LRU 只留最近几轨。 */
  #cache = new Map()
  #cacheBytes = 0

  /**
   * @param {object} options
   * @param {import('./dlsite.js').DlsiteTrialClient} options.dlsite
   * @param {import('./store.js').AsmrStore} [options.store] 用来取默认落盘目录
   * @param {number} [options.maxWorks] 同时缓存几部（LRU），默认 2
   * @param {number} [options.maxMb] 单个试听 zip 的体积上限，默认 150
   * @param {number} [options.maxUnpackedMb] 解压后总量上限，默认 200
   * @param {number} [options.ttlMs] 缓存保留时长，默认 30 分钟
   */
  constructor ({
    dlsite,
    store = null,
    maxWorks = 2,
    maxMb = 800,
    maxTrackMb = 200,
    maxCacheMb = 256,
    ttlMs = 30 * 60 * 1000
  } = {}) {
    this.#dlsite = dlsite
    this.#store = store
    const pick = (value, fallback, floor = 1) => {
      const number = Number(value)
      return Number.isFinite(number) && number >= floor ? number : fallback
    }
    this.#maxWorks = Math.floor(pick(maxWorks, 2))
    this.#maxMb = pick(maxMb, 800)
    this.#maxTrackMb = pick(maxTrackMb, 200)
    this.#maxCacheBytes = pick(maxCacheMb, 256) * 1048576
    this.#ttlMs = pick(ttlMs, 30 * 60 * 1000)
  }

  /**
   * 缓存现状，自检与面板都用得上。
   *
   * `bytes` 报的是**真正驻留在内存里的量**（已解压的那几轨），不是试听包的总大小 ——
   * 分段读之后两者差着一个数量级，混着报会让人误判内存压力。
   */
  get stats () {
    let tracks = 0
    let contentBytes = 0
    for (const entry of this.#entries.values()) {
      tracks += entry.tracks.length
      contentBytes += entry.bytes
    }
    return {
      works: this.#entries.size,
      tracks,
      contentBytes,
      contentText: formatBytes(contentBytes),
      bytes: this.#cacheBytes,
      sizeText: formatBytes(this.#cacheBytes),
      cachedTracks: this.#cache.size,
      maxWorks: this.#maxWorks,
      maxMb: this.#maxMb,
      maxTrackMb: this.#maxTrackMb,
      maxCacheText: formatBytes(this.#maxCacheBytes)
    }
  }

  /** 取已打开的试听包；没打开或已过期返回 null。 */
  get (workno) {
    const entry = this.#entries.get(String(workno))
    if (entry === undefined) return null
    if (Date.now() - entry.at > this.#ttlMs) {
      this.#entries.delete(String(workno))
      return null
    }
    return entry
  }

  /**
   * 打开一部作品的试听包：**只取回中央目录**，内容留到播放时按需取。
   *
   * 早先这里是「拉整包 → 全部解压 → 驻留内存」，100MB 的包就吃 149MB，
   * 200MB+ 的大合集直接把宿主机推向 OOM。改成远端分段读之后，打开这一下只花
   * 一次几十 KB 的尾部请求，内存占用推迟到「真正在播的那一轨」。
   *
   * @param {string} workno RJ 号（`RJ01721463` / `rj1721463` / `1721463` 都认）
   * @param {{ force?: boolean, maxMb?: number }} [options] force 绕过缓存重取
   */
  async open (workno, options = {}) {
    const key = String(workno)
    if (options.force !== true) {
      const cached = this.get(key)
      if (cached !== null) return cached
      // 缓存已过期：先把旧的丢掉，否则下面 LRU 会把它当成"最新的"留下
      this.#entries.delete(key)
    }

    const info = await this.#dlsite.workInfo(key)
    if (info.trials.length === 0) {
      // 这是**正常情况**，不是异常：DLsite 上有相当一部分作品压根没提供官方试听。
      throw new Error(`${info.workno}「${info.title}」没有提供官方试听包`)
    }

    const trial = info.trials[0]
    const limitMb = Number(options.maxMb) > 0 ? Number(options.maxMb) : this.#maxMb
    if (trial.sizeMb > 0 && trial.sizeMb > limitMb) {
      throw new Error(`试听包 ${trial.sizeText}，超过在线听的上限 ${limitMb}MB —— 这种走「下载试听」更合适`)
    }

    const zip = await this.#dlsite.openZip(trial.url)
    const unpacked = zip.entries
      .filter((item) => !item.name.endsWith('/') && AUDIO_RE.test(item.name))
      .sort((left, right) => left.name.localeCompare(right.name, 'zh-Hans', { numeric: true, sensitivity: 'base' }))

    if (unpacked.length === 0) {
      throw new Error(`${info.workno} 的试听包里没有音频（可能只有图片试听）`)
    }

    const tracks = unpacked.map((item, position) => ({
      index: position + 1,
      name: item.name.split('/').pop() ?? item.name,
      bytes: item.uncompressedSize,
      sizeText: formatBytes(item.uncompressedSize),
      entry: item
    }))
    const bytes = tracks.reduce((sum, track) => sum + track.bytes, 0)

    const record = {
      workno: info.workno,
      title: info.title,
      zipUrl: trial.url,
      zip,
      zipSizeText: trial.sizeText,
      bytes,
      sizeText: formatBytes(bytes),
      tracks,
      at: Date.now()
    }

    this.#entries.set(key, record)
    this.#evict(key)
    return record
  }

  /** 只读的曲目清单（把 Buffer 摘掉，可以直接发给前端）。 */
  list (workno) {
    const entry = this.get(workno)
    if (entry === null) return null
    return {
      workno: entry.workno,
      title: entry.title,
      sizeText: entry.sizeText,
      zipSizeText: entry.zipSizeText,
      openedAt: entry.at,
      tracks: entry.tracks.map((track) => ({
        index: track.index,
        name: track.name,
        bytes: track.bytes,
        sizeText: track.sizeText
      }))
    }
  }

  /** 取某一轨的元信息（不碰数据）—— 播放器探长度、拼响应头时用。 */
  track (workno, index) {
    const entry = this.get(workno)
    if (entry === null) return null
    const track = entry.tracks[Number(index) - 1]
    if (track === undefined) return null
    return { track, total: track.bytes }
  }

  /**
   * 取一段字节。`end` 省略表示到文件末尾。
   * 返回的 `data` 是**原 Buffer 的视图**（`subarray`），不复制 —— 大文件下这点很关键。
   *
   * 是 async 的：内容本来不在内存里，得先把这一轨取回来（deflate 不支持随机访问，
   * 想切第 1000 字节也得从头 inflate 整轨）。取回来的轨进 LRU 缓存，
   * 所以播放器的多次 Range 请求只付一次下载代价。
   *
   * @returns {Promise<{track: object, data: Buffer, total: number, start: number, end: number}|null>}
   */
  async slice (workno, index, start, end) {
    const found = this.track(workno, index)
    if (found === null) return null
    const { track, total } = found

    const from = Math.max(0, Math.floor(Number(start) || 0))
    const to = Number.isFinite(Number(end)) ? Math.min(Math.floor(Number(end)), total - 1) : total - 1
    if (from > to || from >= total) return null

    const data = await this.#materialize(this.get(workno), track)
    return { track, data: data.subarray(from, to + 1), total, start: from, end: to }
  }

  /**
   * 把一轨的内容取回内存（命中缓存就秒回）。
   *
   * 单轨也要挡一道：整轨必须驻留才能切片，而试听包里真出现过 131MB 的 wav。
   * 拦在这里报「太大了，走下载」，比让宿主进程被 OOM 带走强得多。
   */
  async #materialize (entry, track, { enforceLimit = true } = {}) {
    const key = `${entry.workno}#${track.index}`
    const hit = this.#cache.get(key)
    if (hit !== undefined) {
      // 提到最新：Map 的迭代顺序就是 LRU 顺序。
      this.#cache.delete(key)
      this.#cache.set(key, hit)
      return hit.data
    }

    // 落盘那条路不查单轨上限：数据取回来马上就写进文件了，驻留时间极短；
    // 而且下载本来就是「在线听放不下」时的出口，再挡一次等于两条路都堵死。
    const limitMb = this.#maxTrackMb
    if (enforceLimit && track.bytes / 1048576 > limitMb) {
      throw new Error(`第 ${track.index} 轨 ${track.sizeText} 超过单轨内存上限 ${limitMb}MB —— 这种走「下载试听」更合适`)
    }

    const data = await entry.zip.read(track.entry)
    // 以实际长度为准：个别打包工具在中央目录里写的 uncompressedSize 不准。
    if (data.length !== track.bytes) {
      track.bytes = data.length
      track.sizeText = formatBytes(data.length)
      entry.bytes = entry.tracks.reduce((sum, item) => sum + item.bytes, 0)
      entry.sizeText = formatBytes(entry.bytes)
    }

    this.#cache.set(key, { data })
    this.#cacheBytes += data.length
    this.#trimCache()
    return data
  }

  /** 缓存超了就丢最旧的，但永远保住刚放进去的那一轨。 */
  #trimCache () {
    while (this.#cacheBytes > this.#maxCacheBytes && this.#cache.size > 1) {
      const oldest = this.#cache.keys().next().value
      const dropped = this.#cache.get(oldest)
      this.#cache.delete(oldest)
      this.#cacheBytes -= dropped.data.length
    }
  }

  /**
   * 落盘 —— 「下载」那一半。
   *
   * 在线听已经取下来过的轨直接命中缓存；没取过的现取一次。两边共用一个 LRU，
   * 所以「先听两耳朵、满意再存整部」既不会重下已经取过的轨，也不会因为
   * 整包太大而存不下来。
   * 目录不存在就地建，跟 `asmr_download` 的落盘行为保持一致。
   *
   * @param {string} workno
   * @param {number} index 第几轨（从 1 起）
   * @param {string} filePath 目标文件的绝对路径
   */
  async save (workno, index, filePath) {
    const entry = this.get(workno)
    if (entry === null) throw new Error('试听包还没打开，先打开再存')
    const track = entry.tracks[Number(index) - 1]
    if (track === undefined) {
      throw new Error(`第 ${index} 轨不存在（共 ${entry.tracks.length} 轨）`)
    }
    const data = await this.#materialize(entry, track, { enforceLimit: false })
    mkdirSync(dirname(filePath), { recursive: true })
    writeFileSync(filePath, data)
    return { path: filePath, bytes: data.length, name: track.name }
  }

  /**
   * 把整部试听存到一个目录下。返回逐轨结果 —— 中途失败不让整批一起废掉。
   *
   * 逐轨按需取，内存里同时只有一轨，落完就交给 LRU 回收。所以 800MB 的包也存得下，
   * 不会因为它「大」而被拒 —— 这正是「在线听放不下」时该走的那条路。
   *
   * @param {string} workno
   * @param {string} dir
   */
  async saveAll (workno, dir) {
    const entry = this.get(workno)
    if (entry === null) throw new Error('试听包还没打开，先打开再存')
    const files = []
    const failures = []
    for (const track of entry.tracks) {
      const target = join(dir, safeFileName(track.name))
      try {
        await this.save(workno, track.index, target)
        files.push({ index: track.index, name: track.name, path: target, bytes: track.bytes, sizeText: track.sizeText })
      } catch (error) {
        failures.push({ index: track.index, name: track.name, error: error.message })
      }
    }
    return {
      dir,
      workno: entry.workno,
      title: entry.title,
      saved: files.length,
      total: entry.tracks.length,
      bytes: files.reduce((sum, file) => sum + file.bytes, 0),
      files,
      failures
    }
  }

  /** 丢掉某一部（或全部）的缓存，内存立刻释放。 */
  clear (workno = '') {
    if (workno === '') {
      const count = this.#entries.size
      this.#entries.clear()
      this.#dropCache()
      return count
    }
    const key = String(workno)
    if (!this.#entries.delete(key)) return 0
    this.#dropCache(key)
    return 1
  }

  /**
   * 丢掉某部作品（不给就全丢）已经解压出来的轨数据。
   *
   * 条目表和轨数据是两套生命周期：条目可能因为 LRU 被淘汰，也可能被 `clear` 清掉，
   * 两种情况下缓存里的轨都得跟着走 —— 否则「释放内存」只释放了一半。
   */
  #dropCache (workno) {
    for (const [key, item] of this.#cache) {
      if (workno === undefined || key.startsWith(`${workno}#`)) {
        this.#cache.delete(key)
        this.#cacheBytes -= item.data.length
      }
    }
    if (this.#cacheBytes < 0) this.#cacheBytes = 0
  }

  /** LRU：只留 `maxWorks` 部，正在打开的那一部永远保住。 */
  #evict (keep) {
    while (this.#entries.size > this.#maxWorks) {
      let oldestKey = null
      let oldestAt = Infinity
      for (const [key, entry] of this.#entries) {
        if (key === keep) continue
        if (entry.at < oldestAt) {
          oldestAt = entry.at
          oldestKey = key
        }
      }
      if (oldestKey === null) break
      this.#entries.delete(oldestKey)
      this.#dropCache(oldestKey)
    }
  }
}
