#!/usr/bin/env node
/**
 * Blender 引擎渲染 + 编码 / render frames through headless Blender, then encode.
 *
 *   node scripts/render-blender.mjs --project=<dir> [--start=0 --end=11]
 *       [--out=out/video.mp4]            # 默认 out/video.mp4（相对工程）
 *       [--script=blender/scene.py]      # 程序化建景路线（帧号反推 t，确定性）
 *       [--blend=blender/scene.blend]    # .blend 直渲路线（-o/-F/-s/-e/-a）
 *       [--blender=<path>]               # 默认自动探测（PATH → 已知安装位）
 *       [--fps=] [--audio=] [--encoder=auto] [--preset=] [--crf=] [--depth=8]
 *       [--force]                        # 忽略签名缓存
 *
 * 帧仍是 t 的纯函数：python 路线用帧号反推 t（t = frame / fps），同一帧号必须
 * 得到同一像素；.blend 路线的确定性由场景自身负责（固定 seed、无墙钟）。
 *
 * 缓存：.cache/signatures-blender.json（按帧存签名）。签名 = 工程基线
 * （尺寸/fps/project.json/src 树）+ **场景目录整树哈希**（.blend、.py 及其依赖
 * 全在内）——改场景文件即整段失效。
 */
import fs from 'node:fs';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { createProgress } from './lib/progress.mjs';
import { pickEncoder, buildEncodeArgs, runFfmpeg } from './lib/encode.mjs';
import { createSignature, loadSignatures, saveSignatures, fileHash, treeHash } from './lib/signature.mjs';

const HERE = path.dirname(fileURLToPath(import.meta.url));

// ---------------------------------------------------------------- args
const argv = process.argv.slice(2);
const opt = {};
const positional = [];
for (const a of argv) {
  const m = /^--([^=]+)(?:=([\s\S]*))?$/.exec(a);
  if (m) opt[m[1]] = m[2] === undefined ? true : m[2];
  else positional.push(a);
}
const log = (...a) => { if (!opt.quiet) console.log('[blender]', ...a); };

const projectDir = path.resolve(opt.project || positional[0] || '.');
if (!fs.existsSync(projectDir)) { console.error('project dir not found: ' + projectDir); process.exit(2); }
const loadJson = (p) => { try { return JSON.parse(fs.readFileSync(p, 'utf8')); } catch { return null; } };
const proj = loadJson(path.join(projectDir, 'project.json')) || {};

const W = Number(opt.w || proj.width || 1280);
const H = Number(opt.h || proj.height || 720);
const FPS = Number(opt.fps || proj.fps || 24);
const DUR = Number(opt.dur || proj.duration || 10);
const TOTAL = Math.max(1, Math.round(DUR * FPS));
const START = Math.max(0, Number(opt.start || 0));
const END = Math.max(START, Number(opt.end !== undefined ? opt.end : TOTAL - 1));
const COUNT = END - START + 1;
const OUT = path.resolve(projectDir, String(opt.out || 'out/video.mp4'));
const FRAMES = path.join(projectDir, 'frames');
const SIGFILE = path.join(projectDir, '.cache', 'signatures-blender.json');
const SCENE_DIR = path.join(projectDir, 'blender');
const frameName = (n) => 'f' + String(n).padStart(5, '0') + '.png';
const framePath = (n) => path.join(FRAMES, frameName(n));

function findFfmpeg() {
  // 从 scripts/ 逐级向上找 node_modules（与 render.mjs 的 findUpFrom 同思路）
  const ups = [];
  let d = HERE;
  for (let i = 0; i < 8; i++) { ups.push(d); d = path.dirname(d); }
  const cands = [
    opt.ffmpeg, process.env.FFMPEG_PATH,
    ...ups.flatMap(u => [
      path.join(u, 'node_modules', 'ffmpeg-static', 'ffmpeg.exe'),
      path.join(u, 'node_modules', 'ffmpeg-static', 'ffmpeg')
    ]),
    'ffmpeg'
  ].filter(Boolean);
  for (const c of cands) {
    try { cp.execFileSync(c, ['-hide_banner', '-version'], { stdio: 'ignore' }); return c; } catch { /* next */ }
  }
  console.error('ffmpeg not found (pass --ffmpeg= or install ffmpeg-static)');
  process.exit(3);
}

/** 自动探测 Blender：--blender → BLENDER_PATH → PATH → 已知安装位。 */
function findBlender() {
  const known = [
    'C:\\Program Files\\Blender Foundation\\Blender 5.0\\blender.exe',
    'C:\\Program Files\\Blender Foundation\\Blender 4.0\\blender.exe',
    '/Applications/Blender.app/Contents/MacOS/Blender',
    '/usr/bin/blender'
  ];
  // 优先级：--blender=（显式：只认它，坏路径直接报错+降级建议，绝不静默回退）
  //        > BLENDER_PATH > 已发现的安装位（版本高→低）> 硬编码 known > PATH
  if (opt.blender) {
    try {
      const out = cp.execFileSync(opt.blender, ['--version'], { stdio: ['ignore', 'pipe', 'ignore'] }).toString().split('\n')[0];
      if (!/Blender\s+\d/.test(out)) throw new Error('unexpected --version output: ' + out.trim());
      return { path: opt.blender, version: out.trim(), explicit: true };
    } catch (e) {
      console.error('ERR  --blender="' + opt.blender + '" 不可用 / unusable: ' + String(e.message || e).split('\n')[0]);
      console.error('     降级建议 / fallback：① 去掉 --blender 让工具自动探测；② 改走 Chrome 引擎（render.mjs）或 NumPy 引擎（render-np.py）。');
      process.exit(3);
    }
  }
  // 扫描本机安装位，按版本从高到低（默认选最高版）
  const found = [];
  try {
    const rootDir = 'C:\\Program Files\\Blender Foundation';
    for (const d of fs.readdirSync(rootDir)) {
      const m = /^Blender (\d+)\.(\d+)/.exec(d);
      if (!m) continue;
      const exe = path.join(rootDir, d, 'blender.exe');
      if (fs.existsSync(exe)) found.push({ v: [+m[1], +m[2]], p: exe });
    }
    found.sort((a, b) => (b.v[0] - a.v[0]) || (b.v[1] - a.v[1]));
  } catch { /* 非 Windows 或目录不存在：走下面的候选 */ }
  const cands = [process.env.BLENDER_PATH, ...found.map(f => f.p), ...known, 'blender'].filter(Boolean);
  const seen = new Set();
  for (const c of cands) {
    if (seen.has(c)) continue;
    seen.add(c);
    try {
      const out = cp.execFileSync(c, ['--version'], { stdio: ['ignore', 'pipe', 'ignore'] }).toString().split('\n')[0];
      if (/Blender\s+\d/.test(out)) return { path: c, version: out.trim() };
    } catch { /* next */ }
  }
  return null;
}

// ---------------------------------------------------------------- main
const cp = await import('node:child_process');
const FFMPEG = findFfmpeg();

const scriptPath = opt.script ? path.resolve(projectDir, String(opt.script))
  : (fs.existsSync(path.join(SCENE_DIR, 'scene.py')) ? path.join(SCENE_DIR, 'scene.py') : null);
const blendPath = opt.blend ? path.resolve(projectDir, String(opt.blend))
  : (fs.existsSync(path.join(SCENE_DIR, 'scene.blend')) ? path.join(SCENE_DIR, 'scene.blend') : null);
if (!scriptPath && !blendPath) {
  console.error('no scene found: pass --script=…py or --blend=…blend (or put blender/scene.py | blender/scene.blend in the project)');
  process.exit(2);
}
const bl = findBlender();
if (!bl) {
  console.error('Blender not found. Install from https://www.blender.org/download/ (or winget install BlenderFoundation.Blender),');
  console.error('then re-run, or pass --blender="C:\\Program Files\\Blender Foundation\\Blender 5.0\\blender.exe"');
  process.exit(3);
}
log('blender: ' + bl.version + '  (' + bl.path + ')');
log('scene:   ' + (scriptPath ? 'python ' + path.relative(projectDir, scriptPath) : '') +
  (scriptPath && blendPath ? ' + ' : '') + (blendPath ? 'blend ' + path.relative(projectDir, blendPath) : ''));

// ---- 签名（场景目录整树进哈希：.blend/.py/依赖全在内）----
const sig = createSignature(projectDir, { width: W, height: H, fps: FPS, duration: DUR, engine: 'blender', quality: String(opt.crf || '') });
// 指纹额外覆盖：**Blender 版本号 + renderer 选择 + 色彩管理**——换任一项都失效重渲。
// 跨版本像素会变（4.x 默认 AgX 而非 Filmic），所以版本必须在指纹里。
const RENDERER = String(opt.renderer || 'CYCLES');
const VIEW_XF = String(opt['view-transform'] || 'AgX');
const baseSig = sig.forGlobal() + '|scene:' +
  (fs.existsSync(SCENE_DIR) ? treeHash(SCENE_DIR) : 'none') +
  '|py:' + fileHash(scriptPath || 'none') + '|blend:' + fileHash(blendPath || 'none') +
  '|blender:' + bl.version + '|renderer:' + RENDERER + '|view:' + VIEW_XF;
const store = loadSignatures(SIGFILE);
const isCached = (n) => !opt.force && fs.existsSync(framePath(n)) && store[n] === baseSig;

const missing = [];
for (let n = START; n <= END; n++) if (!isCached(n)) missing.push(n);
log((END - START + 1 - missing.length) + '/' + (END - START + 1) + ' frames cached' +
  (missing.length ? ', rendering ' + missing.length : ''));

// ---- 渲染：把缺失帧并成连续段，每段一次 Blender 调用 ----
if (missing.length) {
  fs.mkdirSync(FRAMES, { recursive: true });
  const runs = [];
  let s = missing[0], prev = missing[0];
  for (let i = 1; i <= missing.length; i++) {
    if (i === missing.length || missing[i] !== prev + 1) { runs.push([s, prev]); s = missing[i]; }
    prev = missing[i];
  }
  const bar = createProgress({ total: missing.length, label: 'blender' });
  let done = 0;
  for (const [rs, re] of runs) {
    const buildArgs = (rend) => scriptPath
      ? ['-b', '--factory-startup', '--python', scriptPath, '--',
         '--out', FRAMES, '--start', String(rs), '--end', String(re),
         '--width', String(W), '--height', String(H), '--fps', String(FPS),
         '--renderer', rend, '--view-transform', VIEW_XF]
      : ['-b', blendPath, '-o', path.join(FRAMES, 'f#####').replace(/\\/g, '/'),
         '-F', 'PNG', '-s', String(rs), '-e', String(re), '-a'];
    if (!scriptPath) log('note: .blend route renders at the resolution stored in the .blend');
    // 单次运行：返回 {ok, why}（不抛），便于 EEVEE 失败后自动回退 CYCLES 再试一次
    const runOnce = (rend) => new Promise((resolve) => {
      let child;
      try { child = cp.spawn(bl.path, buildArgs(rend), { stdio: ['ignore', 'pipe', 'pipe'] }); }
      catch (e) { return resolve({ ok: false, why: String(e.message || e) }); }
      let tail = [];
      const onData = (d) => {
        const s2 = d.toString();
        tail.push(s2); if (tail.length > 40) tail.shift();
        // 透传场景的关键自述行（渲染器回退/色彩锁），否则成功路径上这些日志会被吞掉
        for (const ln of s2.split(/[\r\n]+/)) {
          if (/view_transform|renderer .*unavailable|fallback|simulated:/i.test(ln)) log('  [scene] ' + ln.trim().slice(0, 200));
        }
        for (const m of s2.matchAll(/Fra:(\d+)/g)) {
          const f = Number(m[1]);
          if (f >= rs && f <= re) bar.update(Math.min(missing.length, done + (f - rs + 1)));
        }
      };
      child.stdout.on('data', onData);
      child.stderr.on('data', onData);
      child.on('error', (e) => resolve({ ok: false, why: String(e.message || e) }));
      child.on('close', (code) => {
        if (code === 0) resolve({ ok: true });
        else resolve({ ok: false, why: 'exit ' + code + '\n' + tail.join('').split('\n').slice(-8).join('\n') });
      });
    });
    let res = await runOnce(RENDERER);
    if (!res.ok && scriptPath && /EEVEE/i.test(RENDERER)) {
      // headless/无 GPU/远桌面常见坑：EEVEE 起不来 → 自动回退 CYCLES，日志写明原因
      log('EEVEE 启动失败 → 自动回退 CYCLES / fallback:');
      log('  reason: ' + res.why.split('\n').slice(0, 4).join(' ⏎ ').slice(0, 400));
      log('  note: 回退帧仍记在请求的 renderer 签名下——修好 GPU 后请 --force 重渲一次。');
      res = await runOnce('CYCLES');
    }
    if (!res.ok) throw new Error('blender failed for frames ' + rs + '-' + re + '\n' + res.why);
    done += re - rs + 1;
    bar.update(done);
    for (let n = rs; n <= re; n++) store[n] = baseSig;
  }
  bar.done('rendered ' + missing.length + ' frames');
  saveSignatures(SIGFILE, store);
}

// ---- 编码（带进度条：runFfmpeg({totalFrames,label}) 解析 -progress pipe:1）----
const encoder = await pickEncoder(FFMPEG, opt.encoder || 'auto');
const audio = opt.audio ? path.resolve(projectDir, String(opt.audio)) : null;
const args = buildEncodeArgs({
  fps: FPS, out: OUT, audio,
  encoder, preset: String(opt.preset || 'medium'), crf: Number(opt.crf || 17),
  depth: opt.depth === undefined ? 8 : Number(opt.depth),
  audioCodec: opt['audio-codec'], audioBitrate: opt['audio-bitrate']
});
fs.mkdirSync(path.dirname(OUT), { recursive: true });
// encode.mjs 现为单一 image2pipe 路径：帧必须经 stdin 喂入（文件输入已删）。
// 帧流 = 目标区间的 PNG 逐个读出；推多少编多少，截断天然在写入侧。
async function* pngStream() {
  for (let n = START; n <= END; n++) yield fs.readFileSync(framePath(n));
}
await runFfmpeg(FFMPEG, args, { totalFrames: COUNT, label: 'encode', frames: pngStream() });

const size = fs.statSync(OUT).size;
let probe = '';
try {
  const { execFileSync } = cp;
  try { execFileSync(FFMPEG, ['-i', OUT], { stdio: ['ignore', 'ignore', 'pipe'] }); } catch (e) {
    probe = String(e.stderr || '').split('\n').filter(l => /Duration|Stream #/.test(l)).join('\n');
  }
} catch { /* ignore */ }
log('OK  ' + (size / 1048576).toFixed(2) + ' MB  ' + OUT);
if (probe) console.log(probe.trim());
