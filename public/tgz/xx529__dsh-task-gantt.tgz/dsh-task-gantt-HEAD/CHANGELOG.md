# Changelog

## 0.2.37 — 2026-10-16

**提问浮窗按视口展开（不再截断）+ 下方详情面板显示问题与答案**

用户实测两条：① 「浮窗显示不全」；② 「点击后下方出现的详情显示内容不全」。

**① 浮窗显示不全 —— 修掉我上一轮推迟的那件事**
根因是 `.dtg-popover` 的 **200px 上限**（3~4 条问题的内容 400~550px ⇒ 只能滚动，用户看到的是"第二问被切在半行上"）。
上一轮我以"popover 没有垂直夹取、加高可能溢出"为由推迟，这次一并做掉：
- **删掉 CSS 的 `max-height`**，高度改由 JS 计算；上限取 **视口 ∩ 包含块**换算到浮窗坐标系后的交集 ——
  视口是真限制（`fixed` 浮层可以越出面板），包含块只在祖先 `transform` 劫持时才是裁剪者。**不夹到面板**
  （0.2.26/0.2.29 的菜单就栽在"夹到面板"上）；
- **垂直夹在视口内 + 按 `roomBelow/roomAbove` 上下择一展开**，**只用 `top` 定位**（`bottom` 相对包含块底边，
  菜单那次就是被它坑）；`useLayoutEffect` 先量后定，绘制前完成 ⇒ 不跳动；
- **不被切在半行**：可见高度**吸附到"最后一个完整子块"**（块放不下才回退 18px 整行网格）。

实测（1 / 2 / 4 条问题 × 视口 900 / 420）：900 下 **1 问 h152、2 问 h184、4 问 h394 均不需滚动**
（4 问 `scrollHeight === clientHeight === 392`，四块逐块 `fullyInside`）；420 下 4 问 h308 需滚动，
但**六格的"被切的行"均为 0**、`fullyVisibleInViewport` 均 true。

修这步时抓到并修掉两个自己引入的真 bug：
1. **自然高度误用 `scrollHeight`（不含边框）**，而 `max-height` 约束的是**边框盒** ⇒ 每个浮窗矮 2px，
   **连只有一个问题的浮窗都永久出现滚动条**（`clientHeight 148 / scrollHeight 150`）。改为量边框盒。
2. **18px 整行网格不够**：块内行高不统一（标题 14 / 正文 18 / chip 自带边框内距）⇒ 仍切 1 行；
   改为**吸附块边界**后归零 —— 把"切在哪"从像素对齐问题变成结构问题。

**② 下方详情面板内容不全**
底部详情面板在 `BoardView.tsx` 的 `MessageDetails`，原本走**通用字段**路径（from/to、时间、类型、泳道、
预览），所以 question 标记只显示问题正文、**没有答案与状态**。现在把浮窗的 body 抽成可共享组件
（`QuestionPopoverBody`）并复用：`kind === 'question'` 时详情面板渲染**与浮窗完全相同**的内容
（每条问题：问题 + 答案；等待中只有问题 +「等待回复」；空选择/`unparsed`/`failed` 的诚实措辞照旧）；
非 question 的通用路径**逐字节不变**。两处**逐字一致**由锁守住。
（我方给范围时**两次漏掉 `BoardView.tsx`** —— 外壳类代码在那里；这次是实施者**主动停手要授权**，
而不是越界修改。）

**一处错误结论的更正（留痕）**：0.2.35/0.2.36 期间报的"提问浮窗有 2 条 React key 警告（加载时另有 6 条
来自 `BoardView`/`LaneHead`）"**是测试 harness 的 `jsx-runtime` shim 的 bug** —— 它把 `children` 塞进
props 对象，使 React 把静态子节点当"无 key 列表"校验。改成变参传 `children` 后：**加载 0 条、
依次打开 4 问 / 2 问 / 1 问浮窗也是 0 条**。**产品代码没有这个缺陷**，此前的记法有误。

Tests: 880 passed / 1 skipped, 41 files; typecheck 0 errors.

## 0.2.36 — 2026-10-16

**提问标记「?」：在消息行标记"模型向人类提问"的那一刻，点开看问题与答案**

用户要求：当前对话过程中**有提问**时，在泳道**收发信息那一行**、那一刻显示一个 **`?`**，
点击可看**问题详情 / 状态 / 选择结果**。随后按实测反馈又改了一轮浮窗内容与图标颜色。

**数据侧（host）**
- 工具普查：真实日志里只有 `ask_user_question`（63 次调用 / 237 个日志，`request_user_input` 0 次）；
  payload = `{questions:[{id,header,question,options:[{label,description}],multi_select}]}`，
  实测 1~4 个问题、`options` 从不缺席。
- 契约新增 `MessageSpan.kind:'question'` + `MessageSpan.question?: QuestionDetail`，**复用消息行**的位置、
  点击与浮窗机制；`to` = user；**只落在提问那条 lane**（人没有 lane，不硬造）；`waiting` 时 `end: null`。
- **三态**：`waiting`（有 call 无 result）/ `answered` / `failed`（真实 `UserQuestionError/DELEGATED_CALLER`，
  调用后 11ms 返回、问题没到人面前）。**没有超时态、没有取消事件** —— 契约 JSDoc 里明说不可观测，不造分支。
  `selected` 为空（18 例）与 `custom` 自由文本（12 例）都是**正常结果**，不是错误。
- **降级**：解析失败一律 `unparsed: true` + `raw`（按 `MESSAGE_PREVIEW_MAX` 截断）——标记仍出现在正确
  时刻，浮窗显示原文而**不假装"人选了空"**。

**修掉一个比需求本身更重要的坑：重复 `tool/result`**
DSH 的 **context compaction 在压缩历史时会追加一条同 callId 的 `tool/result`**，把原始输出替换成
`[dsh-jev-compaction] … pruned …` 占位符；而投影是 last-write-wins ⇒ **"后到者胜"恰好选中占位符**。
全库实测：**64 个提问里 36 个**的 callId 有多条 result。后果是 `end` 被推后 **28.4 分钟**、
`unparsed` 与 `selected` **同时成立**（自相矛盾）。现在同 callId **只认一条**（能解析答案的最早一条 →
否则 `isError` 那条 → 否则最早一条并降级），`selected` 与 `unparsed` **构造性互斥**；
`end` 取真答案时刻（`+27.0s`）。全库复测 **0 个提问的 `end` 来自改写**。
这与 `foldWaitSpans` 当年被 compaction 重复追加骗过是**同一类坑**。

**让需求真正落地：抽稀优先级**
首次交付后实测发现 **`?` 会被抽稀吞掉**：布局每泳道按 9px 桶抽稀、同桶只留一个，而比较器**主键是时间**，
于是 `message@T` 与 `question@T+120s`（此缩放下 9px ≈ 3.8 分钟）相撞时**提问被丢**。
只改 host 的 `sortMessageSpans` rank **无效** —— 全库实测 (message, question) 配对 **2308** 对、
落在窗口内 **35** 对、**时间完全相同 0 对**，即 rank 只决定同毫秒并列。真正的修法在客户端抽稀：
**选桶代表先按 kind 优先级、再看时间**，游标**按 rank 顺序**走（并覆盖单向 9px 游标）。
客户端自持一份 `messageKindRank()`（`turn 0 / question 1 / dispatch 2 / message 3 / user-prompt 4`），
与 host 表逐字同形、互相指向，并有**行为级 parity 锁**防漂移。真实数据复测 **5/5 提问全部存活**，
对抗性场景（`user-prompt` 早 30s / 54.7s / 200s）也存活，且**被丢的标记如实计入 `+N` 徽标**
（"提问存活"不以"消息静默消失"为代价）。改游标时还引入并修掉一个真回归：按 rank 顺序遍历使
`x - lastX` 读到负数、把更早的标记误丢 ⇒ 改为对已保留 x 取**绝对距离**（顺序无关）。

**浮窗按实测反馈改了两轮**
用户第一次反馈：「显示内容不合适，应该是显示**问题 + 答案**，一次可能有多条问题；**还在等待就只显示问题**，
状态是**等待回复**；`?` 要用**鲜艳的红**」。现在：
- **已回答** ⇒ 每条问题醒目显示**选中的选项 label**（多选多个 chip）+ `custom` 自由文本；
  **不再罗列未选选项的长描述**（有锁断言 `option.description` / `dtg-q-option` 不出现）；
- **等待中** ⇒ **只有问题** + 状态 chip「等待回复」（不列选项，有锁）；
- **空选择** ⇒「结果中未记录选项选择」（描述数据、不描述人）；`unparsed` ⇒ 原文；`failed` ⇒ errorCode/Text；
- 1~4 条问题各自一块，长问句换行，整体可滚动（保持 200px 上限）。
- **`?` 改为静态红 `--dsw-static-red-600`（#ec1313）**，两皮肤实测对比度：**light 4.50:1 / dark 3.49:1**
  （均过 WCAG 图形对象 3:1；**深色未达正文 4.5:1** —— 已如实记录并钉进锁）。颜色统一后**三态改用
  非颜色线索区分**：等待 = 脉冲（尊重 `prefers-reduced-motion`）、失败 = `currentColor` 虚线轮廓、
  已回答 = 朴素红。

**一处澄清（实测）**：抽稀的桶键**含方向**，只有同方向标记互相挤占 —— 这正是真实数据里
"更早的 `user-prompt` 挤掉提问"的形态（两者在 lead 泳道同方向）。

**过程记录**：本轮有三次"自我纠错"值得留痕 —— host 侧撤回了自己上一轮"5 个提问只活 3 个"的错数字
（模拟脚本 `widthPx` 覆盖不全、屏外标记被 clamp 挤进最后一个桶，按正确比例重测是 5/5）；
客户端承认第一次量到"消息静默消失"是自己的夹具**没按时间排序**；以及一条**有意为绿的 PIN**
（把旧行为显式断言并注明"客户端改好后会翻红、应换成反向"）——它如期翻红后已改成**对照断言**
（旧算法 ⇒ `[message]`，生产 ⇒ `[question]`），避免"绿 suite 被读成用户那条已修好"。

**本地构建说明**：`0.2.35` 是**只装进 desktop profile 做实测的本地构建、从未发布**（无 tag、无 Release），
其浮窗内容在用户反馈后已被 0.2.36/0.2.37 取代；**0.2.35 与 0.2.36 都是只装进 desktop profile 做实测的本地构建、从未发布**（无 tag、无 Release），本功能集**首次发布**的版本是 0.2.37，因此版本号从 0.2.34 跳到 0.2.37。

Tests: 868 passed / 1 skipped, 41 files; typecheck 0 errors.

## 0.2.34 — 2026-10-15

**消息标记改为以**箭头尖端**为锚 —— 尖端落在真实时间点上，不再越过 now 线**

用户看着 lead 泳道右端、`现在 14:36` 线附近的一个接收箭头说：「接收消息箭头指向的位置在时间线后面，
也就是箭头指向位置不是实际接收的时间，不然不可能会超过时间线」。**他说得对，而且这直接证伪了
0.2.32 的裁决**：当时为了"与发送侧同一口径"，我选择保留尖端相对时间坐标 **+9.29px** 的偏移
（`ui-2` 当时明确停下来问过"要让差值 ≈0 只有两条路"，是我选了保持现状）。后果就是消息时间贴近
now 时，尖端被推过 now 线，看起来像"收到了未来的消息"。

修法：`left: arrowMarker ? marker.x - ARROW_TIP_INSET_PX : marker.x` —— **以尖端为锚**，盒子整体
左移 9.3px，使尖端落在时间坐标上；`ARROW_TIP_INSET_PX = 9.3` 从"仅被源码锁断言的常量"变成真正的
定位量，注释写明来历（`marker.x` 是时间坐标、尖端画在 x=9.8、12px 图标在 11px 盒里居中回吐 0.5）
**以及为什么不能靠盒内平移**（会 overshoot，并把字形拖出 11px 盒、`box-shadow` 光晕留在原地变成
空环 —— 上一轮实测过）。**只有"画箭头"的标记参与位移**：`turn` 刻度与人类气泡没有尖端，保持旧锚点
（`const arrowMarker = marker.kind !== 'turn' && !isUser`，理由写在代码里）。

**验收（时间坐标用轴刻度独立推导，不用 marker 自己的 left）**：`msPerPx = 25027.7`（13:00→15:00
两条刻度：7,200,000ms / 287.7px），now 线取 `.dtg-now-head`。尖端 − 时间坐标：sent `−0.02`、
received `−0.02`、dispatch ×6 `0 ~ +0.01`；盒子整体 `−9.30 ~ −9.32`，**两方向同为 −9.3 ⇒ 对称性保持**。
**关键回归**：把消息钉在 now−2s、等一次 5s 轮询后测 —— 改后 `timeX 288.64 / tipX 288.61 /
nowLine 288.92` ⇒ **`tipMinusNow = −0.31`（在线左侧，不越线）**；同一标记换回旧锚点则
**`tipMinusNow = +8.98`（越过 now 线 8.98px）**，即用户看到的现象在数值上被复现并被本次改动消除。
不回归：命中/悬浮正常（浮窗 `收到 ← lead`）、laneH/headRowH 均 72、三行头子节点不变、wait 2 /
turn 7 / step 8 / 气泡 1、非箭头标记锚点未动（user-prompt `−0.02`）、图例两 swatch 与 marker
逐项相等、dispatch 虚线仍在（`1.6px, 1.2px` + `butt` + `scale(1,-1)`）。

**两条过期锁重基（增强而非弱化，断言 3 → 6）**：① 原"尖端 = 坐标 +9.29"的注释改为旧→新对照，
并新增三条断言 —— 源码必须含 `marker.x - ARROW_TIP_INSET_PX`（常量必须真的参与定位）、必须匹配
`arrowMarker ? … : marker.x`（只有箭头移）、必须含 `arrowMarker` 的定义；保留"禁止盒内平移"。
② 原断言两个 route 文案字面量，改为断言 `uiLabel(messageRouteKey(` 且两份键仍存在且不同 ——
顺带修掉一处不一致：**aria-label 的 route 之前不走 `messageRouteKey`**（浮窗走了），对 dispatch
措辞不当。

**一条新的证据陷阱（值得留痕）**：重做的 fixture 用了主题 shim 里没有的**静态色 token**，于是
`stroke: var(...)` 解析为 `none`、**箭头在截图里完全不可见**（几何量测不受影响，因为用 CTM 取几何、
不依赖颜色）。补上 token 后才显示 —— **截图证据必须确认 ink 能解析，只看几何会漏。**
（未验证：turn 标记本体在这套 fixture 里没有渲染出 marker，故"turn 锚点未动"是代码层排除 + 同类
非箭头标记的实测；暗色皮肤；其它缩放档未逐档复量。）

Tests: 811 passed / 1 skipped, 39 files; typecheck 0 errors.

Build identity: v0.2.34

## 0.2.33 — 2026-10-15

**构建标识与 release 名称都只保留版本号**

用户要求 release 名称"保留版本就可以了"。已把**全部 30 个历史 release 的 title** 改成纯 tag
（`v0.2.32 · subagents` → `v0.2.32`，依此类推；v0.2.3–v0.2.8 本就是纯版本），**tag、说明正文、
`latest` 标记与资产均未受影响**。今后新 release 一律只写版本号。

随后把页脚那行**构建标识**也对齐：`BUILD_LABEL` 由 `'v0.2.32 · subagents'` 改为 **`'v0.2.33'`** ——
只保留版本。取舍说明：这几轮我一直靠页脚的 slug 区分"应用里加载的到底是不是这份构建"
（例如 desktop 装的是 0.2.30 还是 0.2.31），去掉后**只能靠版本号本身辨认**；版本唯一确定构建，
所以这不损失可判定性，只是少了一个一眼可读的标签。README 的版本行同步更新。

功能上与 0.2.32 完全一致（无代码行为改动），只是标识与版本的收尾。

Tests: 811 passed / 1 skipped, 39 files; typecheck 0 errors.

## 0.2.32 — 2026-10-15

**子智能体适配（名字 / 状态 / 派发标记）+ 接收箭头改为垂直镜像**

### 1 — 接收箭头：`↙` → `↘`，用**垂直镜像**而非 180° 旋转

用户指出接收图标"从右上指向左下"，要求"从左上指向右下"。抽成命名常量 `RECEIVED_ARROW_TRANSFORM`：
`scale(-1,-1)`（旋转 180°）→ **`scale(1,-1)`（垂直镜像）**。注释写明了区别与实测依据
（`rotate(180 6 6)` 同样得到 `↙`，所以旋转不是目标态），后人无法"化简"回去。**发送侧未动**
（字形/方向/粗细/填充全未改），两枚仍是同一字形、只有方向不同；两方向尖端 x 一致（+9.29，
因垂直镜像不动 x），与发送侧既有口径相同。图例两个 swatch 与 marker 逐项相等。

### 2 — 子代理泳道的名字：会话 id → 真实任务名

根因是**我们自己代码的 bug**：`src/host/fold.ts` 的 `subagent/catalog` 分支把 lane 名**硬写成
子会话 id**，而该事件的 data **本来就带 `label`**、全文件从未读取。真实值（HtDot 会话实测）：
`Map codebase concerns` / `Map conventions and testing` / `Map architecture and structure` /
`Map tech stack and integrations` —— 与父会话 `subagent` 工具的 `arguments.description` 一致。
回退链：`catalog.label` → 派发的 `arguments.description` → 子会话 `session/title`（**仅当
`source.kind !== 'fallback'`** —— 实测那 7 个子会话的 title 全都是 "You are a codebase mapper"，
没有区分度）→ 会话 id。**7/7 泳道已从 id 前缀变成真实任务名。**

长名（最长 31 字符）在 132px 头部列里必然省略（92/198，隐藏约 54%），**完整名 100% 保留在
药丸 `title` 与行 `aria-label` 里**。经评审决定**不加宽头部列**（会等量吃掉时间轴宽度）也不做
字符串截断（与 CSS 省略号信息量相同却会丢尾部差异）——完整名走悬浮与无障碍名。

### 3 — 子代理泳道的状态：不再永远"分析中"

三行连坐把状态钉死：`fold.ts` 写死 `phase:'provisioning'` → 放进 draft → `deriveStatus` **第一
优先**判 provisioning，后面基于 live agent 与 span 的判据**永远轮不到**，于是转圈永不结束。
结束信号用**子会话自己的 `turn/end`**（实测 `4b877229` 253 个事件、最后一条就是 `turn/end`；
仍在跑的会话有未闭合 span）。父会话里那条 `subagent` 的 `tool/result` **只是 ack**
（正文 `started subagent <id>`、调用后约 400ms 返回），它真正的价值是**父 callId → 子会话 id 的
链接**；`session/end` 之类**不存在**。

修法：catalog 占位行**不再写死 phase**（`phase` 改可选，写死就是编造），改用子会话日志的 span
状态推导 —— **有未闭合 span ⇒ `running`；可读且无未闭合 ⇒ `idle`；读不到且探针无回答 ⇒
省略 `status`**（未知，不再撒谎）。因为 `mode:'continuable'` 的子代理可被再次唤醒，`turn/end`
只代表"当前不在工作"，所以取 **`idle`**，不新造"已完成"状态。为了用**真实日志**证明"仍在跑"
那一档，把真实子日志截断到第一个 `step/end` 之前（39/207 事件，即面板当时那一瞬）重放 ⇒
`running`；同一批真实日志现在 7/7 为 `idle`（都已跑完）。客户端对 `status` **缺席**的渲染是
"静态 ⏸ + 不转圈 + 不给活动词"，即除"不工作"外不作任何断言。

### 4 — 派发标记（诚实版：只画能观测的方向）

teammate 的箭头**只**来自 `team/message/queued` + `delivered` 成对事件（要求收件人 `targetId`），
而子代理场景父会话**完全没有** `team/message/*` 事件、也没有发消息的工具调用 ⇒ **子→父的定向
箭头在数据里不存在，不画**（契约 JSDoc 逐条写明为何不可观测）。可观测的是**父→子派发**：
新增 `kind: 'dispatch'`，`from` = 父 lane、`to` = 子 lane、`time` = 父会话 `tool/call` 的时刻
（**不是** ack）、`preview` = 该次派发的 description、`messageId` = 父 `callId`；同一条 span
**双向落位**（父侧读作"派发给 X"、子侧读作"接收自 Y"）。契约里写明它**不是** journal 的定向
消息，而是按父子关系推出的有向派发。**ack 未到的派发直接丢弃** —— 真实数据里有两条共用同一
label，按 label 配对会画错箭头，宁可不画也不猜。

视觉上它与日志消息区分：同一个箭头字形，但**描边改虚线**、措辞独立（`messageDispatchedTo/From`、
派发说明）。实测 6 条 dispatch 与 3 条普通消息在真实 DOM 中的 class、`stroke-dasharray`、
`transform`、以及尖端与时间坐标的差值（**≤0.01px**）。

### 两条过程记录（都值得留痕）

**"computed style 说虚线、截图却是实线"**：箭头自带 `stroke-linecap: round` + `stroke-width: 2`，
两端各 1 单位的圆帽**跨过 1.4 的间隙把它填满**了。改成 `linecap: butt` + 间隙大于描边宽后虚线
才真正出现 —— 只看 computed style 会漏掉这类缺陷，已写进锁（锁 `butt` 并注释"圆帽会吞掉间隙"）。

**一张假绿截图**：第一版把 `<svg>` 单独克隆放大，**丢掉了 `.dtg-msg-dispatch` 祖先**，而虚线规则
是后代选择器，克隆体自然没有虚线 ⇒ 截图假绿。改为克隆整个 marker 后重截。

另有一处澄清（非缺陷）：`role` 的契约是 `'lead' | 'teammate' | 'unknown'`，**没有 `subagent`**；
客户端落到 `unknown` 是正确行为，是测试 fixture 用了契约外的值。若 host 需要区分"子代理"这个
角色，那是**契约变更**，不是客户端能猜的。

Tests: 811 passed / 1 skipped, 39 files; typecheck 0 errors.

The footer build identity is now `v0.2.32 · subagents`.

## 0.2.31 — 2026-10-14

**活动词的三个缺陷一次收清：语言竞态、空闲泳道误报、以及词的位置**

用户在真机上看到 **9 条泳道全部显示 `thinking`**（包括 6 条空闲泳道）。三个独立缺陷叠在一起：

**1 — 语言竞态（根因，且不限于活动词）**。`src/client/ui/labels.ts` 用的是
`import { locale } from '../i18n.ts'` —— **模块加载那一刻的快照**。而 DSH 宿主在客户端 bundle
执行**之后**才写 `<html lang>`，那一刻 `lang` 还是空的 ⇒ 快照冻结成 `en` ⇒ **中文词典永远不可达**。
这解释了为什么用户先后看到中文 `运行中` 与英文 `thinking` 两种结果：快照值取决于宿主写 `lang`
的时机，是竞态。**受影响的不只是活动词** —— `5 任务`/`5 Tasks`、行 tooltip、无障碍名都可能在两种
语言间随机。修法是 `labels.ts` 改用调用期解析的 `currentLocale()`（`i18n.ts` 早已导出并把旧的
`locale` 标为 `@deprecated`），文件头 JSDoc 改成明确的禁令，防止有人"好心"改回快照。
新增 `tests/ui-locale.spec.ts`（5 条，含结构锁：必须 import `currentLocale`、不得 import `locale`、
不得出现 `dictionaries[locale]`；两本字典 key 集合必须一致；每个活动 key 经 `uiLabel()` 解析后
不得等于 key 本身）。浏览器在**真实 DSH 时序**下验收：bundle 先、lang 后 ⇒ 仍能跟随；
不重载改 `lang=zh-CN` ⇒ `分析中`／`3 任务 · ✉ 5`；切回 en ⇒ `thinking`／`3 Tasks`。

**2 — 空闲泳道误报「正在分析请求」**。客户端此前"只要 `lane.activity` 存在就渲染活动词"，**没有把
该泳道是否活跃作为闸门** —— 而宿主契约的 JSDoc 里明确写了这条前置条件。改为**先定状态、再选词**：
空闲/失败泳道直接无词，活动行的 tooltip 也同样加闸门（否则 hover 里仍会被写成"正在分析请求"）。
新增 4 条锁，并把上一轮**编码了这个 bug** 的一条断言翻正（它当时断言的正是 `statusKey === 'laneActThinking'`）。

**3 — 词的位置与计数的宽度**。活动词最终落在**独立第三行**（用户要求"出现在统计数据的下方"）：
`药丸+spinner / 5 任务 · ✉ 259 / 分析中`。计数**恢复完整措辞**——0.2.30 里的紧凑写法 `5 · ✉ 259`
只是活动词与计数争同一个 107px 盒子时的中间态，词移出后不再需要（这条"自己推翻自己"的过程记在
`docs/VALIDATION.md` §1.24.6）。头部内容 51px + padding/border = 58 ≤ 65 可用，**泳道仍 72px、未加高**；
三档宽度下 21 个文本节点逐节点无省略、名字无内部省略。

**4 — host 侧的可读性闸门**。0.2.30 的挂载条件**名义上**是"日志可读才挂"，代码却把空 fold 无条件
塞进 map —— 于是会给**根本没能观测到的 agent** 断言一个 `thinking`（是"断言"而不是"降级"）。
改用 `readableLogs`：**读不到 ⇒ 字段完全缺席（与旧 payload 逐字节相同）；读得到 ⇒ 即使没有未闭合
turn 也必带 `thinking`**。新增 3 条端到端挂载锁，`dev-verify` 增加用**真实日志**跑真 `buildTimeline`
的检查（含"JSON 序列化后仍在"，因为路由发的是 JSON）。

**一条过程教训（值得留痕）**：前几轮所有测量都在**没设 `document.documentElement.lang`** 的 harness
里做，所以一直是 en、每次量到的都是 en 词，看起来"正常" —— 缺陷因此躲过了多轮验收。**复现条件里
缺一个变量，等于验收无效。** 另外 vitest 环境是 `en` 而浏览器是 `zh`，所以断言一律走
`uiLabel()`/`t()`，**禁止硬编码渲染出来的词**（`ui` 第一次标定就因此红在了错误的位置）。

Tests: 785 passed / 1 skipped, 37 files; typecheck 0 errors.

The footer build identity is now `v0.2.31 · locale-gate`.

## 0.2.30 — 2026-10-13

**泳道头显示「正在做什么」；面板菜单在矮面板/被 transform 的祖先下都能贴住按钮**

**1 — 当前活动：从「运行中」一个词，变成真正的活动短语**

用户贴了参照图，红框里是 `正在分析请求`，并说"这个应该跟对话状态有关的"。查证（三处 file:line 闭合）：
那句话**不是 better-sidebar 的词**，是**内置 `@deepseek-ai/dsh-client-ui-chat` 的词典**
（`lib/client.js:5366`），由客户端从会话事件流物化出的「工具调用节点」推导
（选词 `:2249-2253`、产出 `processActivity` `:10596-10633`、类别映射 `:10494-10517`、
节点物化 `rootCall` `:9524-9555`）。它的语义是 **`activity = summary.running ?? 'thinking'`**，
也就是**「当前没有正在跑的工具」** —— 这正是 `正在分析请求` 的含义。

host 侧据此新增 `LaneLiveActivity`（`kind` / `detail` / `toolName?` / `evidence`）与
`TimelineLane.activity?`：取该 lane 会话日志里**最后一条 `tool/call` 且其 `callId` 没有对应
`tool/result`**；没有未结算调用 ⇒ `thinking`。为什么用这个信号而不是只看 `turn/start`：
真实日志实测 2580 次 `tool/call → tool/result` 的间隔**中位 175ms、>1s 796 次、>5s 385 次、
最长 900s** —— 只看 turn 会把整个 turn 都算作"在工作"，而"调用还没结果"才是工具真正执行的窗口，
且我们读的是**活会话通道**（未 flush 的 `tool/call` 立刻可见）。17 条守卫真值表锁，
其中一条关键：**已闭合的 turn 即使还留着未结算调用也只报 `thinking`** —— 否则中断的 turn
会永远显示"正在跑 bash"。实现中**自己抓到并修掉**一个设计缺陷：第一版用"任一 span 未闭合"，
结果一个孤儿 `step/start` 就能让已闭合的 turn 续命；现在有 turn 事件时只看 turn，step 无权续命。

真实日志**活捉**两条：一条正在跑 `bash`（`kind=commands`, detail 取自 arguments）、
一条正在跑 `wait_agent`（`kind=tools`，走 catch-all）。48 个真实工具名里 **38 个**落到 catch-all
（MCP 工具、`send_message`、`team_task_*`），说明内置那张表的兜底不是理论问题。

**已知、且已写进契约 JSDoc 的差异**：内置面板在模型刚开始流式生成工具参数时显示
`准备读取文件`，我们**不复现这个子状态** —— 该信号来自客户端合成事件 `assistant/live-chunk`，
它不在宿主已知事件类型里、在全部持久日志里 0 命中，只活在实时流中。此时我们显示上一状态或
`正在分析请求`。`已完成 …` 那句摘要需要客户端的分组切分模型，**属独立任务，不在本轮**。

**2 — 短词 + 紧凑计数：一次被抓住的"假绿"**

短语由我们自己的词典出（`thinking→分析中`、`commands→运行命令`、`read→读取中` 等 14 个 kind，
zh/en 各一份），回退链是 `activity → 运行中/启动中 → 不给词`（空闲泳道仍不说词）。
但 107px 的头部列放不下「短词 + `5 任务 · ✉ 259`」：**14 个短词没有一个放得下**
（`分析中` 46px + 75px = 121px），而且**计数文本自身被 `text-overflow: ellipsis` 静默截断**
（实测 `clientWidth 54 < scrollWidth 62`，尾部的 `✉ 5` 被吃掉）—— 而 meta 行的 `scrollWidth`
**看不出来**。此前"0/9 省略"的测量因此是**假绿**：那份 fixture 的任务数与消息数为 0。
改成**紧凑计数** `分析中 · 5 · ✉ 259`（任务数用裸数字、消息数保留 `✉`），完整措辞
（`5 个任务 · 259 条消息`）保留在 tooltip 与无障碍名里。验收方法也随之升级为**逐文本节点**
判定，并用真实量级（5 任务 / 259 消息）：三档宽度 × 27 个节点 `failingNodes = 0`、
`namesTruncated = 0`，最紧组合 `运行命令 + ✉ 259 = 103px ≤ 107px`（余 4px）。

**3 — 面板菜单：`position: fixed` 的包含块被祖先劫持**

用户报"底部打开还是这样，不是在点击处的下方"。根因被合成复现坐实：**祖先上的 `transform`
会让它成为 `fixed` 后代的包含块**，我们按视口算的 `top/left` 于是整体偏移**恰好等于该祖先的
视口位置**（合成场景实测 Δtop +406 = 包含块 top、Δleft +600 = 包含块 left）。修法是识别包含块
并把坐标换算到它的空间，同时**保留以窗口为界的夹取** —— 这样"贴住按钮"与"不被面板裁掉"
不再冲突（改成"面板内 absolute"会重新被 `overflow` 裁掉，把 0.2.29 刚修好的矮面板打回原形）。
三场景实测：干净 `top−bottom = 6`、`left−left = 0`；宽包含块 `left−left = 0`（空间足够时优先对齐
按钮左缘）；窄包含块（420px）兜底夹取以保证可见。四档矮面板（410/250/160/100px）仍全部
可见可点、`.dtg-scroll` 不变；popover 回归验证未变。

**4 — 文档与回归锁**

`docs/VALIDATION.md`：§1.23 那句"状态词只在顶行"的过期描述改为"状态词是 meta 行里的独立
`.dtg-head-status` 节点"；新增 **§1.24**（活动短词 / 紧凑计数 / 菜单定位 / 证据口径 / ❓ 未验证）。
新增真锁三类：泳道高与轨道栈一致性的**产出侧**检查（用 `laneTracks()` 的真实 y/h、零魔数，
含"只越轨不越界"这一当年密度带的 bug 类别）、泳道头可见契约（`tests/lane-head.spec.ts` 13 例，
刻意与"词在哪一行、有几个词"无关）、以及**密度带不回流**（扫 `src/**` 5 个 token，校准指向
删除前的真实源码树 `e32aa2b^` 报出 8 处命中）。牙齿校准均做了破坏→红→复原。

Tests: 773 passed / 1 skipped, 36 files; typecheck 0 errors; verify-build and verify-meta OK.
**未验证**：暗色皮肤下的短词/开关可辨性；极窄面板（<320px）；非 `transform` 的包含块祖先
（`filter`/`perspective`/`will-change`/`contain`）只做了代码层判定；`detail` 含换行/超长中文；
真机上"活动短语渲染"与"自动展示面板"的视觉与焦点落点。

The footer build identity is now `v0.2.30 · live-activity`.

## 0.2.29 — 2026-10-13

**Working agents get a word; the panel reveals itself on the first team call; the lane-bottom band is
gone; the filter menu survives a short panel**

**1 — a status word beside the spinner, and an honest finding: we have no activity text**

The user wanted the working lanes to carry text like another panel's `运行中  正在分析请求`. The
investigation came first, and it settled the wording: `turnSpansFrom()` builds turn spans as
`{kind, time, end, from, sessionId}` with no summary, tool name or activity text, and `ActivitySpan` /
`SpanRect` have no text field either (raw fixture value: `{kind:'turn',start:…,end:…}`). So the panel
shows a STATE WORD — `运行中` / `启动中` — and deliberately does not invent a sentence. A description
would have to start being carried by the host.

It sits on the top line, not the meta line: measured, the meta column has 108px, `3 任务 · ✉ 5` already
takes 62px, and adding `运行中` (33px) would land exactly on 108px. Idle lanes get NO word, because the
user removed 「空闲」 one round earlier as redundant. Explicit `idle`/`failed` beat an unclosed span
(otherwise a frozen session that still holds an open span would spin forever); a missing status falls
back to the open-span signal. A 40-character name yields to the status (the pill compresses to 51px and
ellipsises internally) and the row stays 72px. Nine locks, teeth-calibrated.

**2 — the panel reveals itself on the first team / sub-agent call**

The Lead's premise for this task was WRONG and the teammate corrected it: the tab is registered by the
CLIENT half, and `betterSidebar` is a client-only service — the host Inspect answers "no catalogued
Service named betterSidebar", and the host's only outward channel (better-sidebar's `agent-opens`
WebSocket) carries `file|folder|url` only. So the feature cannot live in `src/host/**`; it went into
`src/client/index.ts`, with the deviation reported rather than hidden.

The APIs were quoted from source, not guessed: `openTab(seed, scope)` (better-sidebar
`src/client/service.ts:639`), `reveal?: boolean` (`:483-491`), `isTabEnabled(id)` (`:610`), and
`features` containing `'targetedOpen'` (`:651-657`) — that last one is the documented basis for
capability detection instead of a version check, and the code contains no version comparison (a lock
asserts it). The built-in panel was traced the same way: a `0 -> N` transition in the number of
sessions with `origin === 'subagent'` (`subagent-detect.ts:47-56`), a 500ms debounce
(`use-host-feeds.ts:253/258`), and the reveal itself at `:130`. Our watcher reuses that same signal,
is idempotent (a `done` flag plus `stop()`, asserted to fire exactly once across later joins/leaves),
and is a silent no-op without `openTab` (it returns a no-op disposer before even creating the timer,
and a lock asserts `console.warn` is never called). Published semantics match the built-in: a team that
already exists at load does not trigger a reveal, so a page reload never steals focus.

**3 — the lane-bottom message density band is deleted end to end**

"这里每个泳道底部都有一个色条，我觉得这个逻辑可以不需要了". Removed cleanly rather than half-way: the
`MESSAGE_BAND_*` constants, the `messageBands` result field, the `MessageBandRect` interface, the
construction block, the render block with its lane-colour paint and tooltip, the `.dtg-msg-band` rule,
the `messageBandTitle` key, and the prose that explained why the band was deliberately NOT
range-scoped (the reasoning dies with the feature).

MEASURED A/B on the same page and fixture, swapping only the bundle: before, every lane carried a 2px
`.dtg-msg-band` at `+69..+71` painted in its lane colour (8 of them, opacity 0.35); after, ZERO, with no
element <=3px tall at any lane bottom and none anywhere on the canvas. Everything else is
byte-for-byte equal: lane height 72, header 28, canvas 676, markers 33, tasks 24, waits 18, task events
51, turn 54, step 57, head lines one row at 62/62 with nothing ellipsised. The deepest track child fell
71 -> 62, which is why the lane height stays 72: the band sat BELOW the deepest child, so removing it
frees no space (measured, not assumed). Locks were re-based rather than dropped wholesale — every
band-only assertion was deleted, but the marker half of each mixed lock was kept because it guards the
real clamp/phantom defect from 0.2.12. The teammate also improved on the approved plan: instead of
adding a `messageCountTitle` key it reused the existing `messageCountLabel`
(101 -> 100 keys per locale, parity intact), avoiding two identical strings that would drift.

**4 — the filter menu now works in a SHORT panel (the Lead's own regression from 0.2.26)**

Reported as "点击筛选 teammate 没有反应" in a bottom-docked panel. The menu was never failing to open —
it was being clamped to nothing: the 0.2.26 fix had changed the clamp boundary from the viewport to the
panel (`scope: 'outer'`), so a short panel drove `max-height` toward zero and the menu became
invisible. The clamp now uses the WINDOW, with `maxHeight = clamp(room, 90, 240)` — a hard floor of
about three rows and internal scrolling — flipping to whichever side has more room, positioned from
`top`. MEASURED at bottom-docked panel heights 410 / 250 / 160 / 100px: the menu is present,
`aria-expanded: true`, height 221px, `elementFromPoint` at its centre hits a menu row, and
`.dtg-scroll` stays 361/288 in all four. Before the fix the 100px case had `max-height: 80px` and sat at
`744..824` against a 813px viewport, i.e. off-screen. The now-dead `scope: 'outer'` option was deleted
along with its walk (the popovers keep the default and were regression-verified).

**5 — a special "working only" filter**

"上面筛选 teammate 地方，多一个特殊的筛选就是筛选当前正在工作中的". A `role="switch"` row (not a
checkbox) sits above the per-teammate list, with new keys in both locales (102 each). It shares the
spinner's predicate — importing the same `laneActivity` rather than growing a second copy — is ANDed
with the per-teammate hidden set, survives the 5s poll, and is reflected in the trigger
(`筛选 teammate 工作中 · −1`). The pinned lane survives even when idle (the user's standing rule that
the Lead cannot be filtered), and an empty result shows the pinned row rather than a blank board.

Tests: 716 passed / 1 skipped, 34 files; typecheck 0 errors; verify-build and verify-meta OK. The
verifier is not used for this round; every claim above is accompanied by the measurement it came from,
and the two items the implementers could not verify are stated as such.

The footer build identity is now `v0.2.29 · working-lanes`.

## 0.2.28 — 2026-10-13

**A working spinner in the lane head for currently active agents**

"现在我先对正在活动的 agent 在这里显示一下工作的状态，就好像 任务管理那个插件一样". The reference
plugin was identified rather than guessed: `dsh-turn-outline`, installed in the same profile, whose
shipped bundle renders `<span className="ttl-spin">{spinnerIcon()}</span>` with `@keyframes ttl-spin`
plus a no-animation variant. Our own `.dtg-spin` reproduces that pattern (11x11 ring,
`@keyframes dtg-spin`, and `@media (prefers-reduced-motion: reduce) { animation: none }`) — the code
was not copied.

The working signal is an existing field, not a new heuristic:
`lane.status === 'running' || 'provisioning' || any turn span with end === null`. `status` is the
contract's own member status and matches "正在活动的 agent" exactly; the unclosed turn span covers the
tick before the host refreshes the status. Deliberately NOT "has any span" (a finished lane is full of
spans and is idle). A lane whose span is unclosed is treated as working even if its status says idle —
an unclosed turn is direct evidence of work, and closing it is the host's job rather than something to
guess at on the client. `unassigned` gets no special case.

MEASURED at 480 / 420 / 300px on a 9-lane fixture with a running and an idle lane: 4 spinners and 5
static glyphs at every width, per-lane `animation-name: dtg-spin` / `duration 0.8s` for exactly the
running lanes and none for the idle ones, head row height unchanged at 72px, meta height 13px,
`scrollWidth === clientWidth` and `ellipsisedCount 0/9` — nothing new is truncated and no lane grew.
With `prefers-reduced-motion: reduce` emulated: `animation-name: none`, `duration 0s`, and the ring
still 11x11 and visible (static, not gone). The ring is drawn with a border token plus
`currentColor`, so it follows the same ink as the static glyph in both skins.

Recorded honestly: this is backed by browser measurement only, with NO regression lock. The spinner's
presence and its animation are DOM-observable, while the repo's element-tree tests use a React stub
(`useState` returns only the initial value, no effects) and so cannot see a computed
`animation-name`; pulling GanttChart.tsx into a unit test would need React render facilities the
project does not have. The suggested fix — extracting `laneIsWorking(lane)` into its own pure module
so a truth table can cover running/idle/provisioning/failed/open-turn/closed-turn — was NOT done
unilaterally and is left as a decision.

Also not measured: the dark skin (no dark demo), a lane whose status is idle while its span is
unclosed (the fixture has no such lane, so the branch is reasoned rather than exercised), and the
visual rotation itself (only the computed animation properties and the reduced-motion zeroing were
verified, not frame-by-frame angles).

The footer build identity is now `v0.2.28 · working-spinner`.

## 0.2.27 — 2026-10-13

**The lane head drops the status word, which also un-truncates the message count**

"「空闲」这个状态文本我觉得没必要了". The one-line head no longer spells out the status; the status
glyph beside the name pill carries it, and the status is still in BOTH the accessible name
(`aria-label: "lead，状态空闲，3 个任务，18 段活动, 打开该会话"`) and the tooltip, so nothing is lost to a
screen reader or a hover.

It also fixed a truncation the user was living with: the line used to read `空闲 · 5 任务 · …` because
its content was 97px in a 108px column (reported as a known limit in 0.2.26). Dropping the status word
took it to **62px / 62px with `scrollWidth === clientWidth`** and `ellipsisedCount 0/9` at 480 / 420 /
300px, so the message count is fully visible. Measured per width: text `3 任务 · ✉ 5`, 13px line at
11px font (the theme shim proving the font token resolves), all 9 status glyphs present.

No locale key became unused, and this was checked rather than assumed: the status word comes from
shell-provided text functions (`memberStatusText` / `taskStatusText`), not from this plugin's
dictionary, and `statusText()` itself is still used by the aria and title paths — so `labels.ts` is
untouched and zh/en parity (99 keys each) is unaffected. A heuristic scan for keys that never appear
as quoted literals turned up 12 candidates, but it is unreliable (`taskStatus_${status}` is
template-composed) and unrelated to this change, so nothing was deleted on the strength of it.

Still true and worth repeating: the line has 62px of 108px, so a much longer task or message count
will eventually ellipsise again — removing that possibility needs a wider `LANE_HEAD_WIDTH`, which
costs the same width from the timeline. Not done without a decision.

The footer build identity is now `v0.2.27 · no-status-word`.

## 0.2.26 — 2026-10-13

**Compact lanes: the head metadata on one line, and the lane trimmed to what the tracks need**

"现在每个泳道的间距我觉得可以做得紧凑一些，「状态，任务数量，消息数量」是不是可以变成一行，这样泳道图下方
就会留有这么多的空位".

The head's three text rows (空闲 / 5 Tasks / ≈ 313) are now ONE node joined with ` · ` (empty parts are
filtered, so a lane with no tasks or messages shows no stray separators), with the name pill and the
status glyph untouched, `nowrap` + ellipsis and explicit `font: var(--dsw-font-xxxs-11)`. Measured at
480 / 420 / 300px: `fontSize 11px`, `textH 13px`, `clientW 97 === scrollW 97`, `ellipsisedCount 0/9`.

The lane height is now what the tracks actually require, MEASURED rather than guessed: the deepest
absolutely-positioned child sits 67px below the lane top (transition rail; the task card bottom is 50,
the wait/turn band 27, the message track 14), so `DEFAULT_LANE_HEIGHT` went **92 -> 72** (67 + 5px
margin). The old 92 was really being held up by the four-row head; the one-line head needs ~46px, so
the larger of the two decides and the head is not clipped to win pixels. Measured before/after at
420px with 9 lanes: lane height 92 -> 72, **canvas 856 -> 676 (-180px)**, lane tops 0/92/184 ->
0/72/144, deepest child 67 -> 62 with `clippedLanes: 0`, neighbour gaps still [0] (no overlap), and
every component height UNCHANGED (task 20, message 11, wait 10, step 8, turn 10) — this is a spacing
change, not a scale change.

Two things worth recording from this round. The harness under /tmp had been wiped by the OS, so it
was rebuilt from the loading contract in docs/VALIDATION.md; rebuilding it surfaced a real trap: an
independent page has no DSH theme tokens, and `var(--dsw-font-xxxs-11)` then falls back to **16px**
rather than to nothing — which made the meta text measure 141px and look like the message count was
being ellipsised away. That was a harness artefact, not a product defect, and it was fixed with a
theme shim whose values come from tests/fixtures/dsw-theme-tokens.json. Second: the new lane height
and the one-line head are backed by browser measurement only, with no regression lock in the repo
(no existing lock referenced 92, so nothing needed re-basing).

Known limit, reported rather than silently accepted: the meta line fits with 97px of the head
column's 108px at 11px, so a longer status word or a much larger task count will start to ellipsise.
Widening `LANE_HEAD_WIDTH` would fix that by eating the same amount from the timeline — not done
without a decision.

The footer build identity is now `v0.2.26 · compact-lanes`.

## 0.2.25 — 2026-10-13

**Sixteen distinct agent colours, the filter menu clamped inside the panel, and honest task times**

**1 — palette: the Lead plus SIXTEEN teammate colours, cycling only after 16**

"现在 agent 的颜色有相同的，你起码要给出16种与 lead 不同颜色的预设色，超过了才能循环使用".
The palette was 7 composed hues, so the 8th lane repeated. Two independent sources of duplication were
found and both are fixed:
- the HOST palette was 7 entries (the cycle itself);
- the CLIENT had its own assignment rule — `1 + (hash(id) % (len - 2))` — which is not the host's rule
  at all. MEASURED before the fix on the real roster ids: **12 teammate lanes used only 4 distinct
  colours**, with collision groups `slot 3 = {host-data, shell, host-data-2, ui-2, synthetic-4}`,
  `slot 4 = {packaging, verify, docs, synthetic-2}`, `slot 1 = {ui, synthetic-3}` — and the structure,
  not luck, guaranteed it: the hash only ever covered `1..len-2`, so the LAST entry of the table was
  unreachable (a 17-entry table would have left `slot 16` spinning empty and only 15 colours for 16
  teammates). The client now uses the host's positional rule `slot = 1 + ((index - 1) % 16)`, measured
  after: lanes 0..16 are **17 distinct colours**, lane 17 == lane 1, and no lane 1..64 ever equals the
  Lead's colour.

The 16 teammate colours are composed with nested TWO-colour `color-mix` (never three: three-colour
mixes resolve incorrectly in the app's Chromium) over 8 deliberately UNEVENLY spaced hue anchors
(7.0 / 44.3 / 86.5 / 133.1 / 179.4 / 233.8 / 293.6 / 334.0 deg) because sRGB chroma collapses to
~0.09 in the yellow-green/cyan region and reaches ~0.22 in red, so an even 45-deg wheel cannot give
even perceptual spacing. Distinctness is established on three measured axes, not on "16 different
hexes": minimum pairwise OKLab dE **0.0714** (~3.5 JND), minimum adjacent dE in lane order **0.1832**
(~9 JND), minimum anchor hue gap **33.0 deg**, minimum within-anchor lightness step **0.0705**, and
every colour at least **27.2 deg / 0.147 dE** from the Lead. Contrast against the lane ink (static
white, which does not flip with the skin) is **>= 4.5:1 for all 17 in both skins**, worst **4.51** —
asserted 17 x 2 times, which is also what keeps the ink from regressing into a flipping alias (that
alias once measured 2.34:1).

The old `tests/host-integration.spec.ts` assertion `min(hue gaps) >= 25` was DELETED with an in-place
explanation rather than lowered: 17 entries cannot fit into 360 deg with a 25-deg gap (the ceiling is
~21.2 deg), and because the palette is 8 anchors x 2 lightness steps, two entries share a hue and the
measured gap is 0. Lowering it to 0 would have been a vacuous assertion; the distinctness claims now
live in tests/lane-color.spec.ts, which also permanently compares the client's fallback table against
the host palette element-by-element (order included) and asserts the two agreement on the same token
for indices 0..20.

Also fixed while there: `unassigned` used to pick `palette[length - 1]`, which in a 17-entry palette
is a TEAMMATE's colour; it now uses the reserved `--dsw-static-blue-800`, with a lock asserting it
matches no roster entry.

**2 — the Filter teammates menu is clamped inside the panel**

Screenshot showed the menu opened BELOW the toolbar and cut off by the panel's bottom edge. Root
cause measured: `clipBounds` walks up to the first clipping ancestor, and for the menu that is the
29px-tall toolbar, while the old positioning wrote the menu's `bottom` from the PANEL's bottom rather
than the TRIGGER's top (before: `menu top 672 / bottom 782`, `withinHost: false` on a 420px panel).
`clipBounds` gained a `scope: 'inner' | 'outer'` option (the menu takes the outermost clipping
ancestor = the panel; the popovers keep `inner`, and their behaviour was re-verified), flipping is
decided by real available space, and everything is positioned from `top` (a viewport-relative `bottom`
is what dragged the menu out of the panel). Measured at 900 / 600 / 420px panel heights: menu
`30/140/110`, `fullyVisibleInPanel: true` at all three, `.dtg-scroll` 311/248 unchanged while open.
Stated plainly: the menu can NEVER actually flip in this layout because the toolbar is the panel's
first row (above it there is no space); the correct behaviour there is clamping the height, which is
what ships. The flip branch was exercised only by injection and is NOT claimed as end-to-end verified.

**3 — the popover now shows created / started / ended and a LIVE duration**

"应该有创建，开始，结束三个时间，durations 如果不是在结束状态应该是开始时间到此时的时长，
如果是结束了，就是开始到结束的时长". The old popover labelled the last transition "finished" and
reported a fixed duration. Now, measured in the browser:
```
running : 创建 23:43:41 | 开始 23:48:41 | 结束 — 进行中（尚未结束） | 时长 11m 28s
finished: 创建 23:30:41 | 开始 23:32:41 | 结束 23:50:41 | 时长 18m 0s
```
with the end taken from the last `completed` (23:50:41, NOT the 23:38:21 `updated`), a duration that
genuinely grows with the clock (`11m 36s -> 11m 40s -> 11m 44s` over 8 real seconds), and a documented
fallback: a task that was never claimed uses `created` as its start and SAYS SO ("开始时间按创建计
（从未认领）") instead of silently picking a value or showing a dash that would leave it with no
duration at all. Ten new locks in tests/task-times.spec.ts; calibrated for teeth by re-installing the
old "last transition as the end, ignore status" defect, which turns five of them red.

The footer build identity is now `v0.2.25 · sixteen-hues`.

## 0.2.24 — 2026-10-12

**Regression fix: the time range was collapsing to 全部 — one clamp direction was reversed**

User report, right after 0.2.23: "现在筛选 tim range 页面没有任何变化". Reproduced with a SIX-HOUR
fixture (a session must be longer than the span for the range to be able to narrow anything — the
previous acceptance fixture was 30 minutes with a 1h span, so every range assertion passed for the
wrong reason):

| range | anchorMinAgo (0.2.23) | winStartMinAgo | durationMin |
|---|---|---|---|
| 1h | 60 | 360 | 361 |
| 30m | 30 | 360 | 361 |
| 15m | 15 | 360 | 361 |
| 全部 | null | 360 | 361 |

The anchor was computed correctly (60/30/15 minutes back) and then thrown away: 0.2.23 clamped it
with `Math.min(anchorStartMs, start)` — intended as "never later than the earliest datum", it
actually means "never LATER than the session start", so for any session longer than the span the
anchor was dragged back to the beginning and every range collapsed to 全部. The correct clamp is
`Math.max(anchorStartMs, start)`, the same direction the sliding-window path already used
(`Math.max(start, end - span)`).

After the fix, same 6h fixture: 1h -> 65min, 30m -> 35min, 15m -> 20min, 全部 -> 365min (each span
plus the grid allowance on the right). In the browser at range 1h / follow on / manual 1 s/px the
visible span is ~62min, 30m -> ~31min, 15m -> ~14.5min, 全部 -> ~397min, so the narrowing path is
genuinely exercised now.

The four criteria were re-measured in the user's state: the old task bar's screen x moves **0.00px**
across three ticks within a page (-2640.00 three times, then -2713.00 three times), `scrollLeft`
shows zero movement until the edge and then moves once by 73px = 0.294 viewport, and 全部 is
unaffected.

Two locks added to tests/layout.spec.ts on a SIX-HOUR fixture, with the fixture's own extent asserted
first (`dataExtent.start === 1000`) so that shortening it fails loudly rather than silently passing:
`1h`/`30m`/`15m` must each be narrower than the session and than each other, and the anchor must stay
pinned while `end` grows. Calibrated for teeth: restoring `Math.min` fails exactly two assertions
(`expected 21660000 to be less than 3720000`, `expected 1000 to be 18001000`).

The blind spot itself is now written down in the new describe's docblock — the earlier range tests
used fixtures shorter than any span, "so every assertion here passes for the wrong reason" — with an
instruction not to shorten it again. That is the process failure worth remembering: new locks were
added for the anchored window while the fixture that could have caught this was already too short.

The footer build identity is now `v0.2.24 · range-clamp-fix`.

## 0.2.23 — 2026-10-12

**The time range now anchors its left boundary (option A) — old content stops sliding**

The user's screenshots pinned the last unknown: footer `v0.2.22 · follow-latch` (so the client was
current), follow ON, zoom manual at 1 s/px, and **Time range = 1h**. The complaint survived 0.2.20 and
0.2.22 because those fixed the scroll policy and the scale — but with a range selected the window was
SLIDING (`[now - span, now]`), so its LEFT boundary advanced with the clock and every drawing was
pushed left on every tick. No scroll policy can fix a window that is itself moving.

Chosen by the user ("选 A"): selecting a range anchors the window's left boundary at that moment, and
from then on only the END grows with `now` — the range means "the width of the window when I chose
it", not "the last N hours". `全部` and follow-OFF are untouched. The anchor is re-taken when the range
changes, when follow is switched on, and when the viewport width changes; manual zoom does NOT
re-anchor (the window is in time, not pixels — re-anchoring on zoom would push the boundary the user
had just pinned).

MEASURED in the user's own state (range 1h, follow ON, manual 1 s/px):

| step | bar viewport x | nowViewX | scrollLeft |
|---|---|---|---|
| 0 | -487.03 | 186.88 | 1070 |
| 1 | -487.03 | 208.39 | 1070 |
| 2 | -487.03 | 208.39 | 1070 |
| 3 | -552.03 | 185.73 | **1135 (snap)** |
| 4 | -552.03 | 207.25 | 1135 |
| 5 | -552.03 | 228.77 | 1135 |
| 6 | -616.03 | 186.28 | **1199 (snap)** |

Within a page the bar's screen position moves **0.00px**, `scrollLeft` shows zero movement, and
`nowViewX` grows monotonically; at the edge the view moves ONCE by 65px / 64px = **0.262 / 0.258 of
the viewport** (~1/4), and the bar shifts by exactly that same amount — one discrete page step, which
is what the user asked for ("碰到边缘位置又再回到 3/4"). `全部` shows the same character with no
regression, and follow-OFF shows zero movement throughout.

STATED PLAINLY, because it is a real trade-off and not a defect: "old content never moves by a single
pixel" and "the window stays bounded" are mutually exclusive. The first implementation tried an
unbounded window with no gutter and the snap then fired on EVERY tick (`scrollLeft` advancing 21-22px
per step with `nowViewX` pinned at 247.6 of 248) — the failure was measured, not assumed. So the
window advances its anchor at the snap and drops the content that has left the view.

Also re-based, with data rather than a guess: `tests/waits-real-log.spec.ts` asserted every real wait
is under 600000ms as a "this must be a compaction re-append" heuristic, and this session's own log now
contains a **630789ms** wait — because a call that requested a 900000ms timeout waited 10.5 minutes.
Measured distribution: 48 closed waits from 2399ms to 630789ms, every one carrying its own
`timeoutMs`, and only 3 exceeding their own timeout — by 48 / 166 / 48ms of timer jitter. The rule is
now "a wait may not outlive its OWN requested timeout plus 60s slack" (falling back to a coarse 1-hour
bound only when no timeout is recorded), so the original intent — never let a compaction re-append be
mispaird into an over-long wait — is preserved. Calibrated for teeth: making the slack negative fails
immediately with `wait of 60982ms outlives its own 60000ms timeout`.

Not verified end to end: "still ±1px after re-selecting the range" (the re-anchor path is covered by
the anchor key and the truth table, but was not measured in the browser), and the continuous
second-scale animation (the clock was stepped and polled).

The footer build identity is now `v0.2.23 · anchored-window`.

## 0.2.22 — 2026-10-12

**Follow mode: the old content finally stays still — the scale was re-fitting every tick**

"现在还是时间推移向右时候，时间线一直停留在3/4 的位置，就是现在感觉的越新时间的内容覆盖了旧内容，但是我想要
的效果是，旧内容在时间线未去到最右边时候是不动的，时间线往右走".

0.2.20 fixed the SCROLL policy but the symptom persisted, and the running app was confirmed to be on
the new build (plugin installed 21:45:19, app started 21:46:46, hysteresis code present in the
installed client) — so the cause was elsewhere. The Lead's hypothesis, confirmed by measurement:

`effectiveMsPerPx = msPerPx ?? fitMsPerPx(win.durationMs, viewportWidth)` is recomputed on EVERY
render, and the window is `[earliest datum, now]`, so `durationMs` grows with the clock. In AUTO-FIT
mode the time scale therefore drifted upward on every tick and the whole drawing was RESCALED —
already-drawn content compressed leftwards while new time squeezed in. That is the "越新时间的内容
覆盖了旧内容" the user was describing.

MEASURED before, driving the clock forward 3 minutes per step, follow on, auto-fit:
`firstBarX 3.28 -> 3.16 -> 3.03 -> 3.03 -> 62.33 -> 60.25` (the old bar MOVED), `nowViewX` pinned at
186 with `scrollLeft` frozen at 62 — both symptoms reproduced. The same sweep with a MANUAL zoom
showed `firstBarX 75.30` constant and `nowViewX` advancing 186 -> 235 then snapping: manual zoom was
already correct, which is why the defect only ever appeared in the state the panel loads in.

FIX: latch the fitted scale while follow is on (`fitLatch`, keyed by viewport width + range filter).
The clock no longer re-fits; only turning follow on, resizing the viewport or changing the range
re-fits, and follow off clears the latch and restores per-render fitting.

MEASURED after, auto-fit, follow on: over 6 steps `firstBarX` stayed at **115.72 (drift 0.00px)**,
`nowViewX` advanced monotonically 186.09 -> 227.97, `scrollLeft` stayed at **435 with zero movement**,
and the canvas width grew linearly 683 -> 725. Run on to the edge, `scrollLeft` moved exactly once
(437 -> 504, i.e. **0.270 viewport**, the ~1/4 snap) and the bar never moved. Follow OFF still fits
every render (canvas width constant at 248 over five sample points), and a viewport-width change
re-fits as before.

TEST GAP, stated rather than hidden: the latch is React state + an effect, and the repository's locks
are pure-function locks (`layoutTimeline` / `shouldFollowScroll`), which cannot observe it — so this
correction is backed by browser measurement only, with no regression lock in the repo. Adding one
needs component-render test facilities the project does not currently have; worth deciding separately.

The footer build identity is now `v0.2.22 · follow-latch`.

## 0.2.21 — 2026-10-12

**The footer diagnostics block is gone from the UI**

"界面中这段内容不需要显示" — the 提示 line (unique message counts, per-lane copies, turn spans, runtime
injections) no longer renders at any width. The HOST contract is untouched: the payload still carries
`notes` (measured `notes.length === 3` with `noticeCount === 0`), this was a UI decision.

The block's only render site turned out to be BoardView.tsx, not GanttChart.tsx — the Lead's file list
was a guess and wrong, so the change had to land there; the task record says so rather than pretending
the scope held.

Two things the removal did NOT do, because measurement said they were not dead code: `.dtg-notice` is
still used by four other sites (error, failure, the message-truncated hint and an error sub-view) and
`notesLabel` is still used by the TaskDetails write-scope row. Deleting them would have broken three
other notices, so the count of CSS rules and label keys removed here is ZERO — reported as a deviation
from the task rather than done silently.

Measured in the same bundle, by re-inserting the removed block once and taking it out again:
`chart 767 / legend h46 / build bottom 813` after vs `chart 689 / notice h79` with it present — the
block was 79px, the legend's height is unchanged at 46, the build label still sits at the bottom, and
the chart GROWS into the freed space rather than being pushed. Same at 480 / 380 / 300px:
`noticeCount 0`, none of 提示 / unique message / runtime injections in the body, legend and build both
rendering, footer bottom constant.

No test needed changing: `grep -rn "dtg-notice" tests/` has no hits, so nothing ever asserted that the
block renders (the fixture's `notes: []` is data, not a render assertion).

The footer build identity is now `v0.2.21 · no-notice`.

## 0.2.20 — 2026-10-12

**Follow mode advances to the edge and then snaps back to 3/4 — it is a cycle, not a pin**

0.2.19 read the request as "keep `now` at 3/4 always" and pinned it there. The user corrected the
semantics: "他不是永远停在 3/4 位置，而是条到这个位置后，时间线往后推，推到边缘位置又再回到 3/4".
So: snap to 3/4, then do NOT scroll while time advances and let `now` drift right on its own, and only
when it REACHES the right edge snap it back to 3/4.

`shouldFollowScroll` is now a hysteresis rule — it returns a target ONLY once `now` has reached the
right edge (`nowViewX >= viewportWidth - 0.5`, the half-pixel tolerance being far smaller than the
~1/4-viewport jump it guards) and `null` (no scrolling at all) while `now` is inside the viewport. The
1/4 gutter is unchanged and still essential: without content beyond `now`, scrolling `now` back to 3/4
would lie beyond the scroll maximum.

MEASURED in the browser with the clock driven forward (the demo's own clock is too slow to watch): over
8 consecutive renders `scrollLeft` stayed at **693** with a per-render delta of 0 while `now`'s viewport
position drifted **185.63 → 220.98**, i.e. **0.7485 → 0.8910 of the viewport width** — the headroom being
eaten, which is exactly the behaviour 0.2.19 lacked. The snap then lands at the maximum scroll position
at both widths tested: viewport 348 → `nowViewX 261.02` against `3/4 x 348 = 261`, and viewport 168 →
`125.66` against `126`; the residual ≤0.34px is the browser rounding `scrollLeft` to an integer, since
the layout-level arithmetic `nowX - target` equals `3/4 x viewportWidth` exactly. The pure-function
truth table covers 0.60 / 0.99 vw → `null`, 1.00 vw / sub-pixel overflow / 2.00 vw → the snap target,
follow off → `null`, both clamps, and idempotence (a second call after the snap returns `null` instead
of re-writing the scroll).

The four 0.2.19 locks were RE-BASED, not deleted, and every one is reported old → new in the task
record; the ratio lock is untouched, and one stronger lock was added (follow off must not scroll even
in the state that would otherwise snap).

Recorded as not verified: the continuous animation at true second-scale time (the drift was sampled by
stepping a clock offset and polling), and the 适应窗口 button's interaction with follow, which does not
go through `shouldFollowScroll`.

The footer build identity is now `v0.2.20 · follow-snap`.

## 0.2.19 — 2026-10-12

**Follow mode keeps `now` at 3/4 of the viewport, with blank headroom to its right**

"跟随时间线情况下，如果时间线已经去到最右边了，应该自动延长空白部分，让时间线回到整屏的 3/4 位置（左边3
右边1）这样就不用一直贴着边往前".

`FOLLOW_GUTTER_RATIO = 1/4` adds a right gutter IN CONTENT PIXELS, produced by the layout (not a CSS
spacer, which the scroll arithmetic cannot see): `contentWidth = dataWidth + gutterPx`, with
`gutterPx = viewportWidth * RATIO` and ZERO when follow is off. `dataWidth` is never modified, so
`now` keeps its own x and an open task still ends exactly at the semantic end of data — the gutter is
pure headroom to the right.

MEASURED at 348 / 248 / 168 px viewports with follow on and the content scrolled fully right
(scrollLeft = contentWidth - viewportWidth):

| viewport | gutter | contentWidth | now's viewport x | viewport × 3/4 | task bars beyond now |
|---|---|---|---|---|---|
| 348 | 87 | 435 | **261** | **261** | 0 |
| 248 | 62 | 310 | **186** | **186** | 0 |
| 168 | 42 | 210 | **126** | **126** | 0 |

`now`'s x equals 3/4 of the viewport to the pixel, and every open task's right edge sits exactly
`0px` relative to `now` (closed tasks are negative) — so the headroom did not stretch any running
task into the future. The gutter is exactly `viewportWidth / 4` in all three cases.

The axis extends across the gutter (chosen over stopping at `now`: the headroom is future time, and a
label-free blank strip would be worse) — a right-side tick label now flips to the left of its line
with `.dtg-tick-label-flip`, because without it a label reached x=338 on a 310px canvas and was cut.

The gutter is deliberate scroll range now, so the numbers are stated rather than merely asserted: the
scroll maximum equals the gutter (87 / 62 / 42), and with follow OFF the content width returns to
`dataWidth` with no gutter at all. The lane background and gridlines still use `dataWidth` and draw
nothing inside it (measured lane background 248 == dataWidth, gridline max x 167).

The three new locks were ADDED to tests/layout.spec.ts; no existing assertion was modified
(`git diff tests/layout.spec.ts | grep '^-'` is empty), and all 86 previous locks still pass.

Recorded as not verified: the continuous behaviour of follow as `now` advances in real time — only
the static geometry at the end of the scroll range was measured; the scroll-target function itself
has a truth-table lock.

The footer build identity is now `v0.2.19 · follow-headroom`.

## 0.2.18 — 2026-10-12

**Toolbar labels stop wrapping when the panel is narrow**

"这里缩小后就文本换行了，修复一下" — at narrow widths `时间段` was breaking across two and then
three lines, so the toolbar row grew from 14px to 42px and the row looked broken.

MEASURED before the fix by sweeping `#host` width: the wrapping element was exactly one —
`.dtg-control-label` (时间段) with `white-space: normal` — at 480px it was 28px / 2 lines, and from
420px down it stayed 42px / 3 lines; every other label was already on one line but carried the same
`normal` value and the same latent risk, so all of them were fixed together. `.dtg-bar` is now a
horizontally scrollable row (`overflow-x: auto`, hidden scrollbar) whose children are
`flex: 0 0 auto`, and `.dtg-btn` / `.dtg-control-label` / `.dtg-select` are `nowrap`. No control is
hidden, no label is truncated, and no copy or behaviour changed (`git diff --stat labels.ts` empty).

MEASURED after: at 480 / 420 / 380 / 340 / 300px every label is ONE line (max 1), 时间段 went
42px → 14px, all 8 controls remain in the DOM, and at the narrowest width the toolbar scrolls
(508px of content) with the last control fully visible once scrolled. The toolbar's scroll range does
NOT leak into `.dtg-scroll` — checked as a control experiment at 300px with the bar hidden and shown:
`169/168` both ways, `barContributesToScrollContainer: false`.

Known trade-off, reported rather than papered over: the toolbar's intrinsic width is 508px, so at
panel widths below that it scrolls, which means the leftmost controls are not initially in view.
Tightening the padding/gaps would win ~20–30px and shortening the labels would need copy changes the
user has not asked for, so neither was done unilaterally.

The footer build identity is now `v0.2.18 · bar-nowrap`.

## 0.2.17 — 2026-10-12

**The hover popover shows the WHOLE title, plus start, end, status and duration**

"这个浮动的任务卡显示，就要完整显示标题，不能缩略了，显示完整标题，显示开始和结束时间、运行状态和运行
用时". The 0.2.15 single-line rules (`text-overflow: ellipsis` + `white-space: nowrap` on the
popover's title and meta) were exactly what the user was looking at, so they are gone: the title
WRAPS (`overflow-wrap: anywhere`) and the meta line is a wrapping flex row.

Measured on a deliberately long subject — the popover's title text is byte-equal to the first line
of the card's own `title` attribute (68 characters, `VERBATIM_EQUAL: true`, `text-overflow: clip`,
`white-space: normal`, 2 lines / 36px), and the meta carries all four facts as separate parts:
`创建 10-12 18:59:31` / `完成 10-12 19:20:31` / `已完成` / `时长 21m 0s`. The start/end/duration
values reuse the SAME `taskDurationLine(...)` the card's tooltip already used, so there is no second
formatting to drift; a live task with no end still reports `duration unknown` rather than inventing
one.

The popover keeps `max-height: 200px` and its clamp into the panel, but its overflow is now `auto`
so a title long enough to exceed the cap scrolls instead of being cut — measured `scrollHeight 98 ===
clientHeight 98`, i.e. the cap did not bite for a 2-line title. Description still does not appear
(`descriptionAbsent: true`) — the user asked for the title and the times, and the detail stays on
click. The label INSIDE the task box keeps its own truncation (measured `clientW 53 / scrollW 357`,
ellipsis) because that is a different surface and the user asked only about the popover.

The lock that asserted the old contract (title ellipsised, title + time only) was RE-BASED rather
than deleted, since it asserted the opposite of what is now required.

The footer build identity is now `v0.2.17 · popover-full`.

## 0.2.16 — 2026-10-12

**A filtered teammate's messages are hidden, not greyed — and the 活动+消息 toggle is gone**

**1 — "如果过滤掉的 teammate，收发信息的标识就不要打灰色了，直接隐藏就行了".** The grey turned out NOT
to be a `laneColorFor` fallback: measured `rgb(225,229,238)`, which is exactly
`--dsw-alias-label-dimmed`, reached through the "the peer resolves to no lane" branch
(`peerMatched === false` in `markerPaint`). Filtering is now done at the DATA layer instead: the pure
filter also drops each surviving lane's messages whose peer is a lane the user HID.

The distinction that had to survive: a peer that was NEVER in the roster (a finished member, another
team) is legitimate and stays drawn on the sender's lane — measured, after hiding all three
teammates, `markers 8 → 1` with `peers ["你"]` and `greys: 0`, while roster-outside peers are kept.

The first attempt at this was WRONG and the browser caught it: it only inspected `message.to`, so an
INCOMING reply whose sender was the hidden lane kept its grey marker. Both endpoints have to be
checked — a lane carries what it sends AND what it receives. Two regression locks were added for
exactly that (`drops a hidden peer even when its SESSION id differs from its LANE id`, and `drops a
message whose SENDER was hidden (an incoming reply)`), and they were calibrated for teeth: reverting
the implementation to compare only `message.to` makes precisely those two fail (13 passed / 2 failed),
and 15/15 pass restored.

**2 — "活动+消息这个开关感觉意义不大，取消这个功能吧".** The button, the `messageMode` state, its use in
the layout call and the three gated render sites are all gone; the activity track and the messages are
simply always drawn. The three labels (`messageModeBoth` / `messageModeMarkers` / `messageModeHint`)
were deleted from BOTH locales, leaving 95 keys in each. The old lock that asserted the gating was
REPLACED — not deleted — by one asserting the toggle and its labels can never come back, since a lock
written for a removed feature asserts the opposite of the code.

Leftover, deliberately not swept up here: `timeline-layout.ts` still accepts a `messageMode` option
and one verifier lock still exercises it, because that option is a property of the layout API and is
still true. Nothing in the UI passes it any more, so it is dead but not misleading — worth a small
cleanup round rather than a rushed one.

The footer build identity is now `v0.2.16 · filter-hides`.

## 0.2.15 — 2026-10-12

**A teammate filter, a toggle that finally does something, and a popover that fits**

**1 — "活动+消息" was doing nothing at all.** Reported as "点击这个，页面好像没有什么变化", and
the measurement agreed: the click changed NOTHING — `{step:3, turn:1, msg:8, wait:5}` before and
after. The code was consistent with that: `'both'` only excluded turn-kind entries from the
marker candidate set (folding them into a "+n"), while the turn/step ACTIVITY BARS never read
`messageMode` at all. So the label promised the activity bars and the code did nothing.

The toggle now hides the whole activity track: `{step:3, turn:1, msg:8, wait:5}` becomes
`{step:0, turn:0, msg:8, wait:0}`, restores exactly on the second click, and the label switches
between 活动+消息 and 只看消息. The message markers deliberately stay (that is what the label
says), and the wait band hides WITH the track because since 0.2.13 it shares that track and
coincides with the step bar — leaving it behind would draw a grey stripe in an empty row and make
the toggle look half-applied.

**2 — the hover popover now fits.** "悬停，看不完整，这里我觉得仅显示到标题和时间就够了，详细的点开来看".
`TaskPopoverBody` drops the description and keeps the title plus the time/status line
(measured: `156x17`, i.e. `设计面板布局 / 10-12 17:23:21 → 完成 10-12 17:40:21 · 已完成`). The full
detail is still one click away in the TaskDetails panel. A max height plus single-line ellipsis on
the title and meta means a long subject truncates instead of pushing the popover out of view.

**3 — the teammate filter.** "如果我筛选了某几个 teammate，甘特图里面内容就只显示这个几个 agent
的内容，包括 agent 列只保留选择的，泳道里面的内容，收发标识也仅展示该 teammate，但是 lead 是不能
筛选的，一定要显示的，默认情况下全选所有 teammate".

Implemented with ONE filtering point — `data.lanes` (and orphaned top-level tasks) are filtered in
BoardView before the chart sees them, so the lane-head column, the lane contents, the send/receive
markers, the waits and the legend counts all follow automatically and there is no second place to
keep in sync. The state is the HIDDEN set (empty = all shown), so a teammate who appears later is
visible by default. `lead` is pinned by `role === 'lead' || id === 'lead'` and cannot be hidden
even if its id reaches the hidden set; `unassigned` is deliberately filterable.

Measured with two teammates unchecked: lanes `["Lead","host-data","ui","verify"]` →
`["Lead","host-data"]`, messages 8 → 6, the button reads `筛选 teammate −2`, the lead row survives,
and `.dtg-scroll` stays 249/248 with the menu OPEN (the trap that has bitten this repo twice).

The pure filter lives in `src/client/ui/lane-filter.ts` with 9 locks (identity for an empty hidden
set, a hidden teammate disappearing with its tasks, a hidden LEAD still shown, `unassigned`
filterable, orphaned tasks dropped, unknown ids ignored, order preserved). `clipBounds` moved from
GanttChart into `src/client/ui/overlay-position.ts` so the new menu and both popovers share one
implementation instead of a second copy of a trap-prone helper.

The footer build identity is now `v0.2.15 · lane-filter`.

## 0.2.14 — 2026-10-12

**The grey wait band now paints ON TOP of the span it coincides with**

Reported immediately after 0.2.13 put the band on the activity track: "等待的灰色条应该在颜色条
的上层吧，现在这样看不清等待开始和结束在哪里". Coinciding was only half the request — the band
rendered BEFORE the span bars inside `.dtg-layer` and neither carried a z-index, so the span's
opaque fill covered the band entirely, caps included.

Fixed with a stacking order (`z-index: 2` on `.dtg-wait`) rather than by moving the JSX, so that
a future reorder of the layer's children cannot silently bury it again. It stays below the two
things it may never cover: the sticky axis (`z-index: 3`) and the lane heads (`z-index: 4`).

MEASURED, as a pixel A/B on the same page: a 17×10 crop of a band overlapping a span, with the
shipped CSS versus the same page with `z-index: auto` injected to reproduce the old order.

| sample | shipped (band on top) | simulated pre-fix (span on top) |
|---|---|---|
| centre | `(76,111,187)` washed | `(36,96,229)` raw span blue |
| left cap | `(26,60,135)` visible | `(36,96,229)` **invisible** |
| right cap | `(26,60,135)` visible | `(36,96,229)` **invisible** |

128 of 170 pixels differ, and both cap pixels read as the span's flat colour before the fix —
i.e. the start and end of the wait genuinely could not be seen. Two source locks now stand in
for that rendering property in `tests/wait-band.spec.ts` (the band's `z-index` with the axis and
heads above it, and the span bars carrying no `z-index` of their own).

A second stale comment was found and fixed here: the CSS block above `.dtg-wait` still said the
band was "drawn on the message row ... the opposite of the turn/step bars above it", which the
0.2.13 move had already made false (the `GanttChart.tsx` copy had been updated, the CSS one had
not).

Two process notes, because both cost time. The build guard rejected my first attempt at that
comment: I wrote element names in backticks inside the BOARD_CSS template, which is the exact
trap this repo has hit repeatedly; the guard printed the line and `deploy.sh` aborted before
writing a bundle, so no partial artifact was published. And `elementFromPoint` is NOT a valid
probe for paint order here — `.dtg-layer` is `pointer-events: none`, so hit-testing falls through
to the canvas and reports the wrong element regardless of which layer paints on top. Pixels
settle it; hit-testing does not.

The footer build identity is now `v0.2.14 · wait-above-span`.

## 0.2.13 — 2026-10-12

**1 — the message markers get the same hover popover as the task cards**

"鼠标悬停到发送和接收的 icon 也要像任务卡一样有悬浮框出现". The 0.2.12 popover was not copied:
`TaskPopover` became a shared `HoverPopover({ anchor, children })`, and the `title`-suspension
logic became a shared `useSuspendedTitle(element, open)` hook used by BOTH the cards and the
markers — so there is one popover implementation and one place that can forget to restore a
title (there is none: the restore lives in the effect cleanup).

The marker body reuses what the marker already knows (`messageSentTo` / `messageReceivedFrom`
for the route line, `preview` for the body) rather than re-deriving anything. Measured on the
built bundle: an outgoing marker reads `发出 → alpha · 10-12 14:27:21 · 消息内容 · lane 0 msg 10`
and an incoming one reads `收到 ← alpha · … · lane 0 msg 9`.

The invariants that cost this repo real time all still hold, re-measured with a marker popover
OPEN: `.dtg-scroll` stays 249/248 (identical to closed — the trap that twice inflated the scroll
box), the popover's parent is the chart and not the scroller, it is clamped into the panel, and
`title` follows rest -> absent -> restored-to-the-same-string across mouseleave AND focus->blur
with 160/160 markers carrying their title again afterwards.

**2 — the grey wait bar coincides with the span**

"我觉得等待的灰色条可以重合在 span，这样表达更清晰". `waitBandRects` moved from the message
track to the activity track: `y = laneY + ACTIVITY_TRACK_TOP`, `h = ACTIVITY_TRACK_HEIGHT`. The
band now covers the whole turn band with the 8px step bar centred inside it, so "this agent was
blocked right here" is drawn on the very interval it describes. Measured on a page with waits:
`wait {y: 96, h: 10}` against `step {y: 97, h: 8}` — a 1px offset, which is exactly
`(10 - 8) / 2`, on all five waits.

Only the vertical slice moved: the caps, the striped pattern, and the `open` / `timedOut` /
`unknown` classes are untouched, and the doc comment above the function — which argued the
OPPOSITE ("Deliberately not on the turn/step bars") — was rewritten to the new ruling instead of
being left contradicting the code.

**3 — the wait band's geometry is now guarded, which it never was**

`grep -rn 'waitBandRects\|MESSAGE_MARKER_TOP' tests/` used to return nothing: the band's
position had no test at all, which is how it could drift from the activity track to the message
track without anything going red. `tests/wait-band.spec.ts` adds 8 locks — the y and height for
several lane indices, coincidence with the same lane's turn band taken from `laneTracks()` (so
either side drifting fails), an explicit "NOT the message track" regression lock, the band
staying inside its own lane, and the unchanged window / clip / cull behaviour. Writing them
caught a real coordinate mistake in the test itself (`laneTracks()` returns absolute y, so adding
`laneY` again double-counted) — which is the point of a lock.

One label key was added for the popover body (`messagePopoverPreview`, zh + en, no existing key
touched).

The footer build identity is now `v0.2.13 · popover-everywhere`.

## 0.2.12 — 2026-10-12

Three requests from a screenshot of a real board, and one bug found while building them.

**1 — a box too narrow for text now shows "…"**

The user, pointing at a task card that rendered NO text at all: "对于这些一个文本都显示不出来的，
我觉得最少也要显示 「...」这样有内容". `TaskLabelPlacement` gained its third state, and the ladder
is now decided by one exported pure function, `taskLabelPlacement(anchor, w)`:

| box width | state | what is drawn |
|---|---|---|
| `w >= 36` (`TASK_LABEL_MIN_WIDTH`) | `'inside'` | the subject, CSS-truncated |
| `22 <= w < 36` (`TASK_LABEL_ELLIPSIS_MIN_WIDTH`) | `'ellipsis'` | a bare "…" |
| `w < 22` | `'none'` | nothing (a hairline cannot hold even the ellipsis) |

All three numbers are DERIVED from the card's padding in `styles.ts` (8px left + 6px right =
14px), so the text box is `w - 14` measured against an ~8px "…" and ~19px for one 11px glyph
plus it. Change the padding and the three numbers have to be re-derived; a live anchor (a 9px
marker with no duration) is always `'none'`.

**2 — the message row moved ABOVE the span row**

"信息收发显示的泳道放在 span 的泳道上面". `laneTracks()` now returns message -> activity -> task
instead of activity -> message -> task, with `MESSAGE_TRACK_TOP` and `ACTIVITY_TRACK_TOP` named
constants behind it. `TASK_CARD_TOP` is still 30 and every lane height is unchanged, because the
same terms are summed either way — the swap moves the two thin rows and nothing else. Measured
in the browser: message row y=82 < step span y=97 < task box y=109, in one lane.

**3 — sent and received arrows are one icon**

"发送和接收的箭头 icon 样式应该一致，现在发送略粗，接收比较细，统一一下". `ARROW_STROKE_SENT`
(3.4) and `ARROW_STROKE_RECEIVED` (2) are gone, replaced by a single `ARROW_STROKE = 2`, and
`ArrowIcon` no longer takes a `filled` prop at all — so the difference cannot be quietly added
back. Only the diagonal's aim distinguishes the directions now. The lock in
tests/message-paint.spec.ts was re-based to assert exactly that (it still guards the original
property: the direction cue does not depend on colour) and now fails if either old constant or
`filled={outgoing}` reappears. Measured: both arrows report `strokeWidth: 2px`, `fill: none`.

**4 — a hover popover with the whole title**

"鼠标悬停到任务卡时候，可以有个浮窗来完整显示任务的标题". The native `title` attribute is still
there at rest (it carries the status and the measured time range), but it cannot be styled and
has an OS delay, so a real popover now opens on hover AND on keyboard focus, showing the full
subject and description.

It was built wrong first and the measurement caught it: rendered inside `.dtg-canvas`, the
popover measured `right 618` against a `380` clipper and `elementFromPoint` on the overhang
returned `BODY` — **`position: fixed` does not escape an ancestor's `overflow: hidden`**. It now
renders as a SIBLING of `.dtg-scroll` (so it cannot join the scroll box's overflow, the trap that
once inflated `scrollWidth` from 248 to 399 and broke the follow toggle) and clamps itself into
the first really-clipping ancestor, found by walking up from the card. Re-measured with it open:
`scrollWidth 249 / clientWidth 248`, unchanged from closed; `clippedByClipper: 0`.

The native tooltip and the popover then overlapped each other, so while the popover is open the
`title` is temporarily removed and restored on every close path (mouseleave, blur, unmount),
while `aria-label` — which already carries subject and description — is present throughout.

**Recorded, still open**

- ❓25(a): a history task card that crosses the viewport's right edge disappeared entirely at a
  finer-than-fit zoom; unattributed, no code change, needs `scrollLeft` recorded alongside.
- ❓25(b): the axis tick labels DO create a ~24px horizontal scroll range at fit zoom, which
  contradicts two older claims in the ledger that they are clipped harmlessly.

The footer build identity is now `v0.2.12 · popover-ellipsis`.

## 0.2.11 — 2026-10-12

Four more real-screen requests, and the label finally stops leaving the box.

**1 — the finest manual zoom is 1 s/px**

"最小时间粒度改成 1s 吧" moved `MIN_ZOOM_MS_PER_PX` from 5 s to 1 s. The structure that made the
number safe to move is unchanged and is what the tests lock: two separate floors
(`MIN_MS_PER_PX = 50` is only the sanity clamp), the fit path exempt in BOTH directions, and
`clampZoomMsPerPx(value, current)` never letting a zoom-IN click from a sub-floor fit jump
backwards. The number has now moved twice, so the tests assert the relationships rather than
the constant.

**2 — the label lives inside the box, or not at all**

"还是出现图中文字在任务条外的情况", then, asked how far to go: "只在条内画，装不下就较少显示的
文本". So the outside caption is GONE — `TaskLabelPlacement` is now `'inside' | 'none'`, and
`TASK_CHIP_GAP` / `TASK_CHIP_WIDTH` / `TASK_CHIP_INSIDE_MIN_WIDTH` / `TASK_CHIP_MIN_SIDE_WIDTH`
are deleted with it. A history-anchored box at least `TASK_LABEL_MIN_WIDTH = 36` px wide draws
its subject inside and the renderer truncates with CSS ellipsis; below that the layout emits
`'none'` (`labelW === 0`) because there is not room for the ellipsis itself, and `title` /
`aria-label` still carry subject and description.

36 is derived, not chosen: the card's padding is 8px + 6px, so the text box is `w - 14`; one
11px glyph plus an ~8px ellipsis needs 19px, i.e. `w >= 33`. Below that the browser clips a
glyph in half — the exact artefact the user had now reported twice.

The deleted machinery was not stupid: the outside caption existed so a SHORT task could still be
named, and two measured defects came with it (a caption at the canvas edge reached 151px past it
and inflated `scrollWidth` 248 → 399, and at a coarse zoom all twelve captions collapsed into one
18.1px column). Removing the placement deletes both failure modes instead of constraining them.

Measured on the built bundle (12 task boxes at 44 s/px): `.dtg-task-caption` 0,
`.dtg-task-outside` 0, placements only `['inside','none']`, every `'none'` box has no subject
child (8/8), and an `'inside'` box measured `subClient 22` vs `subScroll 65` — the ellipsis path
is genuinely engaged. `.dtg-scroll` scrollWidth 249 vs clientWidth 248: the phantom horizontal
scroll has not come back.

**3 — the task box is no longer filled with the agent colour**

"任务条背景颜色不要用跟 agent 的颜色，用回之前那种看图2". `00e58a6` had replaced the earlier
"thin agent-coloured bar + neutral label card with a 3px agent-coloured left edge" with ONE box
filled solid in the lane identity colour. The one-box geometry (length = duration) is what the
user asked for and it stays; the PAINT goes back to the pre-`00e58a6` card: fill
`var(--dsw-alias-bg-layer-2)`, 1px `var(--dsw-alias-border-l2)` border, `border-left-width: 3px`
coloured by the agent, radius 4px, ink `var(--dsw-alias-label-primary)`, padding
`2px 6px 2px 8px`.

Measured: all 12 boxes share ONE background (`rgb(255,255,255)` in the Light skin, i.e. the
theme's `bg-layer-2` — no lane colour among them) while the left edges resolve to four different
lane colours (`rgb(37,99,235)` / `rgb(236,19,19)` / `rgb(221,134,41)` / `rgb(34,197,94)`), all at
exactly 3px. Every box measured 20px tall — `.dtg-root *` is `box-sizing: border-box`, so the new
1px border and the padding stay inside the bar height instead of overflowing their track.

**4 — a better README feature image**

`docs/screenshots/panel-v3.png` is replaced by a high-DPI capture of the real panel with the
recent rounds of fixes visible.

**Recorded, not fixed**

- The zoom readout prints whole seconds at >= 1 s/px (`toFixed(msPerPx < 1000 ? 2 : 0)`), so two
  DIFFERENT zooms can read the same text: measured "2 秒/像素" at both 1614 and 2421 ms/px. That
  makes "click until the readout stops changing" an unsound acceptance method — the verifier
  caught it while checking the new floor and switched to fixed click counts plus a scrollWidth
  cross-check. Worth a look next round: the readout is not lying about the layout, only about
  its own precision.
- ❓24 (a message at exactly `range.end` is culled on a frozen board, silently) is still open.

The footer build identity is now `v0.2.11 · label-in-box`.

## 0.2.10 — 2026-10-12

**The manual zoom stops at 5 s/px, and 适应窗口 is deliberately left free**

The user's rule: "时间粒度，最少的只需要去到 5 秒就行". Asked which of the panel's two
granularities that meant, they chose the manual zoom floor, and chose that it constrains
the manual zoom ONLY.

- `MIN_ZOOM_MS_PER_PX = 5 * SECOND_MS` is a new constant, and `clampZoomMsPerPx(value,
  current)` is the new clamp on the manual-zoom path (`applyZoom`, reached by both zoom
  buttons and ctrl+wheel). Zooming in now stops at 5 秒/像素; before this it went to
  `MIN_MS_PER_PX = 50` (0.05 秒/像素).
- It is a SEPARATE constant from `MIN_MS_PER_PX` on purpose, because `clampMsPerPx` — the
  function that used to serve the manual zoom — is shared by `fitMsPerPx` AND
  `layoutTimeline`'s own input sanitisation. Raising that single floor would have clamped
  适应窗口 as well, and the measured consequence is not subtle: a 5-minute range on a 248px
  canvas fits at ~1.2 s/px, so a clamped fit would draw 300s ÷ 5s = **60px of content
  inside a 248px canvas**, stranding the chart in the left quarter. Locked by test:
  `fitMsPerPx(5 * MINUTE_MS, 248)` must stay below the manual floor and `layoutTimeline`
  must keep it, with `dataWidth ≈ 248`.
- The floor is the FINER of the 5 s/px limit and the zoom currently on screen. Without
  that, a zoom-in click from a fitted 1.2 s/px (a 5m range) would snap to 5 s/px — the
  reader asks to move closer and the chart jumps 4x AWAY. With it, that click clamps onto
  the current value and `applyZoom`'s `next === effectiveMsPerPx` guard makes it a no-op;
  zooming out from there is unaffected.

The footer build identity is now `v0.2.10 · zoom-floor-5s`.

## 0.2.9 — 2026-10-12

**Four defects the time-range filter exposed — and one it still hides**

All four were reported against the panel after 0.2.7 shipped the range filter. The first two
turned out to be ONE cause.

**1 + 2 — the phantom mark at the start of the timeline, and the "+n" that ballooned**

- The message layer was the only part of the layout that never asked `inWindow()` before
  drawing (`spanRect` and `taskCardRect` both do). A marker's x is
  `(clamp(time, win.start, win.end) - win.start) / msPerPx`, so a message OLDER than the selected
  range was never dropped — it was clamped onto the window's left edge and drawn there.
  Measured on a 4-lane / 3-hour fixture (180 messages per lane, 248px viewport):
  **8 markers with a left edge of exactly 0 at the 15-minute range, against 0 at 全部**.
- `droppedBefore` ran over the lane's WHOLE list too, so the badge counted the omission of
  messages the reader had explicitly filtered OUT: **"+163" at 15m against "+6" at 全部**.
- The fix scopes the CANDIDATE LIST (not the output) to `[win.start, win.end]` — which also
  makes the pixel budget honest, since `decimateMarkers` is handed the WINDOW's width. The
  density band is deliberately left at the lane's true extent and is only skipped when the
  window does not touch it at all: "this lane was talking from here to there" is the fact the
  strip carries, and its tooltip names the true endpoints.
- Verified after: 15m → 60 markers, **0 at the left edge**, **0 badges**; 全部 → byte-identical
  to before (160 markers, 76 badges all "+6"). Calibrated in reverse: putting the whole list
  back makes the three new tests fail with `marker at 1000000 is outside [4000000, 4600000]`,
  `expected 69 to be 19`, and one clamped stub back on the all-before lane.
- The legend now reads "…（当前时间段内）" because its denominator is the SELECTED RANGE —
  measured "12/60 条消息已绘制（当前时间段内）" where it used to divide by 720, the whole log.

**3 — a task caption that cannot be read is no longer drawn**

- At the coarsest zoom (600 s/px) over a 3-hour log the content is `3h / 600s = 18px` wide, and
  `taskCardRect`'s last-resort branch ("no side has room, so clamp inside the canvas") clamped
  all **12 captions into that same 18.1px column with 45–71px of text inside each** — twelve
  one-character fragments at one x.
- `TaskCardRect.labelPlacement` gained a fourth case, `'none'`, and `TaskLabelPlacement` is now
  exported as a named type: when the whole canvas is narrower than `TASK_CHIP_MIN_SIDE_WIDTH`,
  no label is emitted at all. The box, its `title`/`aria-label` and its click target are
  untouched (verified: at 600 s/px, 0 captions, 12 boxes still titled 长任务 0 …).
- A canvas that is narrow but still ≥ 48px keeps the old clamp, because that behaviour is what
  stopped a 148px caption from inflating `scrollWidth` from 248 to 399.

**4 — the 「实时」 badge is gone**

- The growing box already says "still elapsing" with a dashed right cap; the badge repeated it
  in words on every open task (measured: 4 of them). Removed, together with the
  `.dtg-task-flag` CSS rule and the now-unused `liveBadge` string in BOTH locales. The
  accessible name still says 实时态, so nothing is lost to a screen reader.

**Found while verifying, and NOT fixed: the last message of a frozen run is invisible**

- A message at exactly `win.end` passes `inWindow` (both ends are closed) but lands at
  `viewX === viewportWidth`, and `rectVisible` is strict on the right (`viewX < viewportWidth`),
  so with `cull: true` it is dropped — and it is neither drawn nor thinned, so neither the
  legend nor a badge mentions it. Measured on a frozen board filtered to 15m: 45 markers,
  minutes 165..179 present, **180 absent**, empty legend.
- This is PRE-EXISTING, and narrower than the two above: a live board heals itself as the clock
  advances, so only a frozen board puts the last event out of reach permanently. It is recorded
  as a standing `❓` in docs/VALIDATION.md rather than papered over, because every candidate fix
  trades against a stronger invariant (`contentWidth` slack would move the phantom-scroll and
  follow behaviour; shifting the edge marker would break "a marker is never moved off its own
  time").

The footer build identity is now `v0.2.9 · range-scoped-messages`.

## 0.2.8 — 2026-10-12

**A dark-skin defect that had been invisible because there was no dark demo**

- Found while closing the standing ❓ "the dark-skin token values were never measured on a
  live page". The way in was already in the tree: the demo's theme sheet carries BOTH skins
  (`:root` from the shipped theme plus a `[data-ds-dark-theme]` override), so setting that
  attribute renders with the theme's REAL dark values rather than an approximation. The
  measured values confirm every value the verification track had DERIVED
  (`label-secondary` #cfd3d6, `label-primary` #f9fafb, `label-primary-inverted` #353638,
  `bg-layer-1` #232324).
- **The defect**: the lane NAME pill and the task box used
  `--dsw-alias-label-primary-inverted` as their ink. That alias FLIPS with the skin — white
  in the light one, `#353638` in the dark one — and all seven lane fills are saturated and
  dark-ish in BOTH skins, so their text has to be light in both. Measured: `#353638` on
  `--dsw-static-blue-600` is **2.34:1**, i.e. dark grey on blue, on the two elements that
  identify a lane and its task.
- **The fix**: the ink on a saturated fill is now `--dsw-static-neutral-bluish-00`, a
  STATIC white that does not flip. All seven fills clear 4.5:1 against white in both skins
  (5.17 / 7.05 / 4.56 / 4.52 / 4.55 / 4.51 / 4.51). Two places had also hardcoded an ink
  and are fixed: `styles.ts`'s `.dtg-head-name` wrote the flipping alias directly (so it
  never used the payload's `on` at all), and `LaneHead` inlined only `background` and not
  `color`. Fill and ink now both come from the payload.
- **Why the existing test missed it**: the palette test asserted each fill against a literal
  `#ffffff`. The FILLS were fine; the INK was not, so that assertion stayed green through
  the whole thing. It now resolves the CONFIGURED ink in BOTH skins and asserts 4.5:1.
  Calibrated in reverse: restoring the old alias makes it fail with
  `is only 2.34:1 in the dark skin`, and restoring the fix makes it pass.
- Verified in a real browser on the dark skin: name pill `rgb(37,99,235)` with
  `rgb(255,255,255)` text, task box likewise, wait band `rgb(173,178,184)`, arrows red.

Also: the standing `❓` ledger in docs/VALIDATION.md had two entries that had gone STALE
against the code — the palette was described as five tokens with a wrap-around (it is now
seven composed hues) and the label placement as two cases (it now has three, plus a
side-width floor). Both are marked as superseded with a pointer to the section that
replaced them, rather than quietly rewritten.

The footer build identity is now `v0.2.8 · skin-safe-lane-ink`.

## 0.2.7 — 2026-10-12

Three additions, and the two defects that measuring them turned up.

**A time-range filter: 全部 / 5m / 15m / 30m / 1h / 3h**

- Expressed as ONE number on the window (`windowSpanMs`), not as a pass over the rects
  in the renderer: every downstream position is already relative to the window's start,
  so the axis, the bars, the markers, the waits and the ticks are filtered by the same
  decision and cannot disagree about what is in range.
- The window's END is deliberately untouched. For a live board it is still `now`, which
  is what lets the follow toggle keep working while a range is selected; for a frozen
  board it is still the last datum, so filtering cannot make a stopped chart creep.
- A range WIDER than the log is clamped to the log's own start, so "3 hours" on a
  two-minute session shows those two minutes rather than an hour of empty axis.
- Selecting a range re-fits the zoom, so the chosen span fills the panel instead of
  becoming a 41px sliver of it (measured before the fix: 5 minutes drawn 41px wide on a
  248px canvas).

**A follow toggle: does the view keep up with the clock**

- On, the scroller is moved so the NOW line stays at the viewport's right edge; off, it
  is never touched. Verified end-to-end on a LIVE page: with it on, `scrollLeft` went
  0 → 317 = maxScroll; with it off, it stayed at exactly 100 across seven seconds while
  the clock advanced and the content grew.
- Manual scrolling never flips the toggle: the callback does not write back, so there is
  no "parent writes, child reports, parent writes again" loop.

**`wait_agent` blocks, drawn on the message row**

- A wait is time an agent spent blocked on its peers rather than working, so it is its
  own fold (`foldWaitSpans`) rather than being folded into the activity spans or the
  messages. Both ends are drawn, with a distinct cap at each: a start tick and an end
  tick, and an end that is absent for a wait that is still blocking.
- Three outcomes are kept apart, because they mean different things: `timedOut: true`
  (waited out the timeout, nobody came), `false` (a peer woke it), and ABSENT (the result
  could not be read — never collapsed to `false`, which would be the positive claim
  "someone arrived").
- Measured on a real session log: 24 `wait_agent` calls, 24 paired, 2.4s to 300s, 3
  timeouts and 21 wakes.

**Two defects found by measuring the above**

- **A wait was paired with the wrong result.** On real data every `wait_agent` call
  carries TWO results: the real one, and a much later re-append from the compaction
  machinery whose body is `[dsh-jev-compaction] Historical tool output pruned…`. Keeping
  the LAST gave all 24 waits a duration of 15 minutes to 21 hours and lost every
  outcome — and looked perfectly reasonable against hand-built fixtures. The earliest
  result is when the call actually returned. There is now a test that runs against a real
  log when the machine has one, and skips VISIBLY when it does not.
- **A task label could overflow the canvas by 151px.** The borderless caption added in
  0.2.6 started just past its box, so for a task at the right edge it reached past the
  canvas. An absolutely-positioned descendant contributes to its scroll container's
  scrollable overflow, so this did not merely look wrong: `scrollWidth` went 248 → 399,
  giving the panel a phantom horizontal scroll range that also defeated the follow
  toggle. Labels now flip to the OTHER SIDE of the box when there is no room, and their
  width is clamped to the room that side has, so no label can leave the canvas.
- Related, and the same class of defect: a task or activity span that lay WHOLLY outside
  the selected range was still drawn, because clamping an out-of-range rect into the
  window produces a plausible stub at x=0 rather than something obviously wrong. With a
  5-minute filter over a 30-minute log, a task that had ended 14 minutes earlier was
  still a 10px box on the left edge. Out-of-range rects are now dropped; a rect that
  merely STARTS before the window is kept and flagged `clippedLeft`.

The footer build identity is now `v0.2.7 · range+follow+waits`.

## 0.2.6 — 2026-10-12

Four issues from the first look at the panel in the real app.

**A task's box is now exactly its duration, with no fixed minimum**

- There were TWO objects per task: a thin bar whose length was the real elapsed time, and
  a 36px card at a FIXED 148px that held the label. The user read the fixed one as "the
  task" and reported the consequence: "任务框的长度应该是按实际时间线来，而不是有个最小固定长度
  大小（这样意义上不合理）". They were right — a 5-second task and a 5-minute task drew the
  same 148px box, so the box carried no information and directly contradicted the bar
  beside it.
- There is now ONE element per task: a box whose LENGTH is the duration and which holds
  the label. Its fill is the lane's identity colour with the lane's own `on` ink — the
  same treatment the lane NAME gets, so "the coloured box is the task" is one idea instead
  of two.
- When the box is too narrow to hold its label, the label hangs outside as plain
  TEXT — no background, no border — so the only bordered rectangle on a task row is the
  one whose length means something.
- A task with no dated history has no duration at all, so it draws a small fixed marker
  rather than a width that would misrepresent nothing: there is nothing to be honest
  about, and a 1px marker was invisible.

**An unfinished task keeps growing, to NOW**

- A task that is `pending` or `in_progress` has a duration that is still elapsing, so its
  box runs from its creation to `now` and grows on every render. Its right edge is drawn
  dashed, because that end is not a fact yet.
- It used to draw `max(history.time)` — and for a task whose only event so far IS the
  creation, that is the creation itself, so an open task was a 1px mark and the chart said
  it had lasted no time. The user: "当任务未完成时候，应该是跟随时间线不停拖动拉长任务框，
  这样才代表任务进行中".
- `win.end` is `now` for a live window, so the layout still reads no clock of its own and
  a frozen window never grows. Verified in a real browser: the open box's right edge is
  exactly the NOW line (measured offset 0px) and the completed boxes keep their measured
  lengths (140px and 91px for different durations).

**The lane's role badge is gone**

- It was a bordered chip printing the role, and for the Lead it printed "Lead" directly
  under a name pill that already said the same word: "下面多了一个白色框+ agent名称，这个已经
  是多余的了". Removing it also returned 16px to a head column that had zero margin. The
  role still reaches the user through the row's tooltip and accessible name.

**The human's prompt is a speech bubble**

- It was a punched-out white disc with a two-tone ring and an arrow inside — which the
  user described exactly: "变成一个白色框黑心的东西". Three shapes competing in 11px, and
  the dark glyph in the white ring said nothing about who spoke.
- It is now a single outlined bubble, in the panel's own primary ink with the same surface
  halo every other marker carries, so it is readable over any lane colour in either skin
  and cannot be confused with the arrows that mean "this lane sent / received".

The footer build identity is now `v0.2.6 · duration-box+growing-tasks`.

## 0.2.5 — 2026-10-12

Four requests from using the panel on a real screen: mark each task's state changes,
give every agent a distinct colour, make the agent NAME carry that colour, and stop
truncating the lane's facts.

**Each task now marks its own transitions (创建 / 认领 / 完成, and the rest)**

- The task's `history` already carried every dated transition; the chart simply was not
  drawing them, so this needed no new host data. Each event is drawn at its OWN time
  scaled by the same `msPerPx` as the bar, so a mark reads against the bar's length —
  "claimed a third of the way in" is a fact, not an impression.
- The rail hangs UNDER the bar rather than on it: `TASK_BAR_HEIGHT` is the one
  measurement on this chart that must stay exactly proportional, and glyphs over a 10px
  bar would either cover it or force it taller.
- Glyphs reuse the vocabulary the panel already teaches (`▶` is "in progress", `✓` is
  "completed"), and the words come from `historyActionText` — the SAME vocabulary the
  details panel prints, so the legend cannot drift from the marks it explains.
- Two events at the same instant get a 1px stagger, so a create-then-immediately-claim
  burst shows as two marks instead of one hiding the other.
- The marks carry an `aria-label` (through the shared `taskEventAria` template) rather
  than `aria-hidden`: they are information, not decoration.
- A task's LAST transition is by definition at the bar's right edge, which is exactly
  where an outside label chip begins — so the completed mark was painted under the chip
  and vanished. Lifted above it with a hairline of the chip's own surface behind it.

**Every agent has its own colour: 红橙黄绿青蓝紫, with the Lead fixed to blue**

- The theme publishes only FOUR chromatic families (red 0°, amber 31-38°, green 142°,
  blue 212-226°) and no cyan or purple token at all — so the seven requested hues are
  composed from it with `color-mix()`, which is the theme's own idiom
  (`--dsw-alias-interactive-bg-hover` is itself a `color-mix()`). Nothing here is a
  literal colour.
- A vivid yellow cannot carry white text in sRGB (white needs ~4.5:1, which at hue 60
  forces a dark olive), and neither can the theme's green or amber. Each hue is darkened
  by the LEAST amount that lets white text clear 4.5:1. Measured result: hues
  0° / 31° / 61° / 143° / 182° / 221° / 307°, all between 4.51:1 and 7.05:1 with white.
- The Lead is pinned to blue and is never handed to a teammate; the other six hues plus a
  wrap cover the roster.

**The agent's NAME carries the colour, not a hairline**

- The identity colour was a 2px border on the row's left edge, which read as a hairline.
  It is now the name's own background with white text, set inline because the stylesheet
  must stay free of literal paint (the theme scan enforces that).

**The lane's facts are one per line, and nothing is truncating them**

- They were four items in one flex row, so `text-overflow: ellipsis` ate the tail —
  the user's "状态显示不完整 … 后面就 ... 省略号了". The meta block is now a column, and
  the ellipsis is gone: text wraps instead of being silently cut.
- That needed more vertical room: measured, the head column needs 90px, and at the old
  `DEFAULT_LANE_HEIGHT = 84` the last row was clipped (`clientHeight 83` vs
  `scrollHeight 86`). Raised to 92, and the role row's `border` became a non-layout
  inset ring so its row is 14px instead of 16px. Now 91px of content in 91px of room.

The footer build identity is now `v0.2.5 · seven-hues+event-marks`.

## 0.2.4 — 2026-10-12

**The sent and received arrows are now the same arrow, differing only in weight**

The report: "发送的标识只有一个小三角形明显，改成更接收一样的 icon 只是方向变了斜线上".

The received arrow was right and the sent one was wrong, because they used different
*paint* on a different *geometry*:

- The filled variant used the same centreline as the stroked one — a path of **open
  line segments**. Open lines enclose no area, so `fill` on them paints almost
  nothing; the sent marker was a 1px sliver with one visible nub. That is the "小三角形".
- It was then given a real closed polygon, and it came out wrong a second way: the
  head reached 10.8 of a 12-unit box, so the arrow was **silently clipped** by its own
  viewBox and read as a stub. Neither defect is visible from reading the numbers.

Both are replaced by ONE centreline drawn at two stroke weights:

| | aim | weight |
|---|---|---|
| sent | up-right | 3.4px — wide enough that the head's barbs fill, so it reads solid |
| received | down-left | 2px — the same shape read as an outline |

The centreline is derived, not eyeballed: a 2px stroke reaches 1px either side of its
path, so the line is inset one unit from the outer silhouette, which keeps the painted
arrow inside its box at both weights (a test now asserts that for every vertex).

The footer build identity is now `v0.2.4 · matched-arrow-weights`.

## 0.2.3 — 2026-10-12

Two follow-ups from looking at the panel on a real screen: the message icon still
had a square around it, and one lane colour was grey.

**The message icon is now the arrow, and nothing else**

- Every earlier revision wrapped the glyph — first an 11px disc, then a
  solid/hollow plate — and the report each time was the same: "外面还有个正方形的框
  会让里面的尖头显示不清晰". A frame competes with the arrow's own tip for the same
  few pixels in an 11px track. The marker now carries `background: none`,
  `border: 0` and `border-radius: 0`; the SVG path *is* the icon.
- The arrow is drawn as a path, not set as a text glyph. `↗` renders as a hairline
  whose weight depends on the font and never gets as legible as a 2px stroke with
  round caps — which is what the user's reference image shows.
- Direction is two independent cues from one geometry: the path is mirrored for a
  received message, and a sent message is FILLED while a received one is STROKED at
  2px. Both are equally heavy, so the two directions differ in shape rather than in
  strength.
- The arrow is painted in the **counterpart's lane colour** — the rule the user
  asked for ("A 发给 B，A 的泳道显示 收件人B 的颜色"). A hairline of the panel
  surface behind each marker keeps a pale lane colour readable as an edge without
  introducing a frame.

**No lane is grey any more, and the palette is built from measured values**

- `--dsw-alias-state-idle-primary`, the fifth palette entry, resolves to a pure
  grey: `--dsw-static-neutral-300` (`#d4d4d4`, chroma 0) in the light skin and
  `--dsw-static-neutral-600` (`#545557`, chroma 0) in the dark one. Every sixth lane
  was therefore drawn in black-and-white, which is the report "每个 agent 的颜色区分度
  要大，但是不要出现 黑白灰". It is gone, and a test forbids it from returning.
- The palette is now eight chromatic slots: four hue families, each used twice at a
  clearly different lightness. This is a real ceiling of the theme, not a choice —
  extracting every `--dsw-static-*` value shows the theme publishes only four
  chromatic families (red 0°, amber 31-38°, green 142°, blue 212-226°) and no
  purple, magenta, cyan, teal, lime or pink token at all. Past four lanes a palette
  *must* reuse a family, and separating the repeat by lightness is the honest way to
  do it.
- The values were read out of the theme the running app actually ships, not out of
  the npm copy on disk. That copy is an older build with fewer tokens, which is why
  an earlier scan appeared to show `state-idle-primary` did not exist. Both a
  name-only fixture and a new value fixture now pin the palette, so a colour can be
  checked for being chromatic and legible rather than merely for existing.
- Measured defect found while doing this: the previous palette's
  `state-success-primary` (`#22c55e`) and `state-warn-primary` (`#f59e0b`) carried the
  light skin's white ink at **2.28:1** and **2.15:1**, both below the 3:1 graphical
  minimum. Those lanes' arrows and card badges were not reliably readable.
- The footer build identity is now `v0.2.3 · box-free-arrows+chromatic-lanes`.

## 0.2.2 — 2026-10-12

Five defects reported from live use of the panel. Each one was reproduced and
measured in a real browser before it was fixed; the measurements are quoted
below because three of the five had a root cause that did not look like the
symptom.

**Clicking a message icon did nothing (the body never opened)**

- The marker `<button>` computed to `pointer-events: none`: it inherited the
  value from the decorative `.dtg-layer`, which disables hit-testing for its
  children so the lane background, gridlines and bands never swallow a click.
  The marker is the one interactive child of that layer and had no re-enable, so
  **0 of 11 markers were hit-testable** — `elementFromPoint` at a marker's centre
  returned the lane-head button underneath it. Not a React problem, and not
  fixable in the marker's own handler: a CSS cascade defect that made a real
  `<button>` inert while it still looked and focused like a button.
- The marker now re-enables `pointer-events` and grows a transparent `::before`
  hit area outward, so the arrow's own centre still marks the exact instant the
  message happened (the layout positions it from the message's real time).
  Measured after: `8/8` markers hit-testable and clickable.

**Message markers froze in place and stacked up after zooming**

- A message is folded onto BOTH its sender's and its recipient's lane and keeps
  its `messageId`, but the marker key was the bare `messageId`. The same key
  therefore occurred twice in one `layout.messages` array; React logged
  `Encountered two children with the same key, msg:m2` and reconciled against a
  duplicate, leaving markers from an earlier layout pass on screen. The key is
  now lane-qualified (`<laneId>:<messageId>`) — the lane is part of a marker's
  identity regardless, since the same message paints and points differently per
  lane. The details view resolves the same key, and prefers the LAST lane that
  carries a message, matching the layout's own order.
- `visible` was computed in CONTENT space (`x + w >= 0 && x <= viewportWidth`)
  for message markers and density bands — contradicting the contract documented
  at the top of the module. Everything inside the first `viewportWidth` pixels of
  the canvas was therefore reported visible wherever the user had scrolled, and
  markers reappeared only once the scroll passed the viewport width. All four
  rect families (spans, task cards, markers, bands) now share one exported
  `rectVisible(viewX, …)` helper, so they cannot drift apart again.

**A task's bar was floored at a minimum width**

- The bar's width floor was `MIN_SPAN_PX` (2px), so at a coarse zoom a 1ms task
  and a 1.9s task both drew 2px: the chart told the reader they lasted the same.
  The floor is now a single device pixel with no other job than keeping a
  zero-width rect renderable, so the bar's length is its real duration and its
  left edge is always the task's real start. The activity spans keep their 2px
  floor: a span is an instant, a bar is a duration that a floor can distort.

**Hovering a task drew a colour bar across its middle**

- The duration bar sits at exactly the card's own position and is drawn under it,
  so an opaque card hides it completely. `:hover` replaced that opaque card
  background with `--dsw-alias-interactive-bg-hover`, which is **translucent**,
  and the bar showed straight through. Measured: with the pointer off the card
  the card region contained **zero** saturated pixels; with the pointer on it,
  rows 100–109 across the card's full width became solid `rgb(135,82,225)`.
  The hover tint is now painted as an inset shadow, which composes over the
  element's own background instead of replacing it, so the card stays opaque in
  both states. Measured after: hover changes the card to a uniform tint and the
  saturated rows are gone.

**Message markers redesigned**

- The disc is gone. Each marker is now the diagonal arrow itself: solid for a
  message this lane sent, hollow for one it received, so direction is carried by
  shape as well as by the counterpart's colour. The circle, and the plate around
  the glyph that made the two directions differ mainly by hue, were the visual
  noise the report called out.
- The footer build identity is now
  `v0.2.2 · arrow-icons+exact-bars+clickable`; read it to confirm which build is
  actually loaded.

## 0.2.1 — 2026-10-12

Follow-up to 0.2.0 from the first pass of live testing of the message details.

- A message whose recipient was not recorded no longer reads `unknown peer`.
  A human prompt carries no addressee in the journal, but its recipient is
  knowable: the prompt lives in the log of whoever it was addressed to. The
  details view now derives that from the lane it is drawn on (`you -> lead`),
  and falls back to `(recipient not recorded)` when even that is unavailable.
  The `unknown peer` dictionary entry is deleted, and the tests forbid the
  wording from returning.
- The details view shows seconds. `formatClock` had only ever formatted to the
  minute while a self-check claimed otherwise: the asserted value had been
  written into the log by hand rather than read back from the function, so the
  assertion never ran. The formatter now defaults to seconds (axis labels keep
  minutes) and the check reads the real return value.
- `data-message-route` carries `data-message-direction`, `-from` and `-to` on
  the same node, so a live check can read the whole routing in one query.

## 0.2.0 — 2026-10-12

The panel's first release with a build identity, so a tester can tell from the
screen which build they are looking at (`BUILD_LABEL` in the footer and on the
panel root's `data-build`).

**Lanes**

- Lane height is a fixed 84px across three non-overlapping tracks — activity
  (3–13), messages (16–27), tasks (30–66). Previously a 56px lane held the
  message markers (12–23) and the 36px task card (17–53) on top of each other.
- An idle team's timeline stops moving. `live` is derived from event evidence
  only (a registered agent that is running, or the requested session's own open
  span/turn), and a frozen chart is labelled `ended` rather than hidden or
  mislabelled `now`.

**Tasks**

- Bar length is the task's duration. The old width was
  `clamp(duration/msPerPx, 148, 260)`, and 148px is about 740s at the panel's
  zoom, so every task shorter than ~12 minutes drew the same length and the bar
  you saw was mostly the label's background.
- Bar height is 10px, independent of the 36px chip. It previously reused the
  card height, which rendered as a coloured block rather than a bar.
- The label is a separate chip (inside the bar when it fits, otherwise to its
  right) so text width can no longer influence geometry; swapping a 1-character
  subject for a 4000-character one leaves the bar's x and width unchanged.
- The details view and the card tooltip print `created 23:11 → finished 23:11
  (14s)` from one shared helper.

**Messages**

- Every exchange is drawn on both lanes (the host mirrors it), and a marker is
  coloured by the *counterparty*: `sent to B` on A's lane takes B's colour,
  `received from A` on B's lane takes A's colour, with a non-colour arrow. The
  colour previously always came from the sender, so a lane's own colour carried
  no information.
- Clicking a marker shows both names, the local time with seconds, the kind,
  and the **full message body**. Long text stays out of `title` — a browser
  tooltip truncates and cannot scroll, so it would look complete while showing
  only a prefix.
- `MESSAGE_PREVIEW_MAX` 140 → 16384, and the field's meaning changed from
  "one-line teaser" to "the whole collapsed body". Across 177 real
  `team/message` records the bodies run 600–7135 characters (median 1839), so
  **all 177** were truncated before this. The ceiling is now only a guard
  against a pathological record; clipping is reported in the host's notes
  rather than happening silently.

**Fixes found by cross-checking rather than by the suite**

- An empty live log shadowed the disk log, so a registered-but-not-yet-replayed
  session drew an empty chart while claiming `source: 'log'`.
- A 1.5s cross-request log cache could serve a stale snapshot exactly when a
  new prompt arrived, pinning the panel in the frozen state.
- Decimation shared one pixel-gap cursor and one bucket set across both message
  directions, and a reply lands a few pixels after the message it answers, so
  every lane's outgoing markers lost the gap contest and that whole direction
  vanished silently.
- A human prompt was drawn three times: it appears in the lead's log and in
  every teammate's, and deduplication keyed on the carrying session.
- `--dsw-font-mono` and `--dsw-alias-label-quaternary` do not exist in the
  host's 408 theme tokens, making those declarations invalid at
  computed-value time — invisible to typecheck and to the colour scan.
- `laneIdOf` needed two hops: a lane's id is the session id for a teammate, but
  the lead's lane id is the literal `lead`, so `lead` never resolved.

## 0.1.0

First working version: a sidebar Gantt of an agent team's shared tasks, with
teammates on the y-axis and time taken from the durable session event log.
