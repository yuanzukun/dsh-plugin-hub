import { describe, expect, it } from 'vitest'
import { extractSummary, normalizeText, truncate } from '../src/client/summary.ts'

describe('summary', () => {
  it('normalizes whitespace runs', () => {
    expect(normalizeText('  a\n\n  b\tc ')).toBe('a b c')
    expect(normalizeText('')).toBe('')
  })

  it('truncates with an ellipsis', () => {
    expect(truncate('short', 10)).toBe('short')
    expect(truncate('a very long string', 10)).toBe('a very lo…')
    expect(truncate('', 10)).toBe('')
  })

  it('extracts readable text and strips UI chrome', () => {
    const row = document.createElement('div')
    const bubble = document.createElement('div')
    bubble.textContent = 'Hello world'
    const copy = document.createElement('button')
    copy.textContent = 'Copy'
    const icon = document.createElement('span')
    icon.setAttribute('aria-hidden', 'true')
    icon.textContent = 'pencil-icon'
    const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg')
    svg.textContent = 'svg-label'
    const reasoning = document.createElement('details')
    reasoning.textContent = 'reasoning text'
    row.append(bubble, document.createTextNode(' '), copy, icon, svg, reasoning)

    const summary = extractSummary(row, 200)
    expect(summary).toBe('Hello world reasoning text')
  })

  it('returns an empty string when nothing readable remains', () => {
    const row = document.createElement('div')
    const copy = document.createElement('button')
    copy.textContent = 'Copy'
    row.append(copy)
    expect(extractSummary(row, 200)).toBe('')
  })

  it('truncates long summaries to the char budget', () => {
    const row = document.createElement('div')
    row.textContent = 'x'.repeat(500)
    const summary = extractSummary(row, 100)
    expect(summary.length).toBe(100)
    expect(summary.endsWith('…')).toBe(true)
  })
})
