import { describe, expect, it } from 'vitest'
import { contentRatio, hasOverflow, markerTop, panelHeightFor, scrollTarget } from '../src/client/geometry.ts'

describe('geometry', () => {
  it('detects overflow with a tolerance', () => {
    expect(hasOverflow(4000, 800)).toBe(true)
    expect(hasOverflow(800, 800)).toBe(false)
    expect(hasOverflow(801, 800)).toBe(false) // within the 1px tolerance
    expect(hasOverflow(802, 800)).toBe(true)
  })

  it('computes a clamped content ratio', () => {
    expect(contentRatio(320, 4000)).toBeCloseTo(0.08)
    expect(contentRatio(0, 4000)).toBe(0)
    expect(contentRatio(-10, 4000)).toBe(0)
    expect(contentRatio(9999, 4000)).toBe(1)
    expect(contentRatio(100, 0)).toBe(0)
  })

  it('positions markers inside the rail', () => {
    expect(markerTop(0, 800, 7)).toBe(0)
    expect(markerTop(0.08, 800, 7)).toBeCloseTo(64)
    expect(markerTop(1, 800, 7)).toBe(793) // never overflows the rail
    expect(markerTop(1, 4, 7)).toBe(0) // rail shorter than the marker
    expect(markerTop(0.5, 0, 7)).toBe(0)
  })

  it('computes scroll targets with padding', () => {
    expect(scrollTarget(320, 12)).toBe(308)
    expect(scrollTarget(5, 12)).toBe(0) // clamped at the top
  })

  it('sizes the panel as a clamped fraction of the viewport', () => {
    expect(panelHeightFor(800, 0.5, 140, 520)).toBe(400)
    expect(panelHeightFor(200, 0.5, 140, 520)).toBe(140) // min bound
    expect(panelHeightFor(2000, 0.5, 140, 520)).toBe(520) // max bound
    expect(panelHeightFor(0, 0.5, 140, 520)).toBe(0)
  })
})
