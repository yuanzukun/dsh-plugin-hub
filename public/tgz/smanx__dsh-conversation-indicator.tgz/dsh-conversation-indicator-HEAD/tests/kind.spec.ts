import { describe, expect, it } from 'vitest'
import { detectLanguage, kindLabel, shouldMark } from '../src/client/kind.ts'

describe('kind', () => {
  it('filters kinds against the configured list', () => {
    expect(shouldMark('user', ['user', 'assistant-step'])).toBe(true)
    expect(shouldMark('assistant-step', ['user', 'assistant-step'])).toBe(true)
    expect(shouldMark('tool-call', ['user', 'assistant-step'])).toBe(false)
    expect(shouldMark('anything', ['*'])).toBe(true)
    expect(shouldMark('tool-call', [])).toBe(false)
  })

  it('labels known kinds in both languages and falls back to the raw kind', () => {
    expect(kindLabel('user', 'zh')).toBe('用户消息')
    expect(kindLabel('assistant-step', 'en')).toBe('Assistant reply')
    expect(kindLabel('assistant', 'zh')).toBe('助手回复') // legacy alias
    expect(kindLabel('tool-call', 'en')).toBe('Tool call')
    expect(kindLabel('custom-kind', 'zh')).toBe('custom-kind')
  })

  it('detects the UI language from navigator-like input', () => {
    expect(detectLanguage('zh-CN')).toBe('zh')
    expect(detectLanguage('zh')).toBe('zh')
    expect(detectLanguage('en-US')).toBe('en')
    expect(detectLanguage('fr-FR')).toBe('en')
  })
})
