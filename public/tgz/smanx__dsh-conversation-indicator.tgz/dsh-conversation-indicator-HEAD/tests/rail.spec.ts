import { beforeEach, describe, expect, it, vi } from 'vitest'
import { DEFAULT_OPTIONS } from '../src/client/options.ts'
import { COUNT_CLASS, MARKER_CLASS, PANEL_CLASS, TOOLTIP_CLASS } from '../src/client/styles.ts'
import { Rail, ROW_SELECTOR, SCROLLPORT_SELECTOR } from '../src/client/rail.ts'

/** jsdom has no ResizeObserver; the rail needs only the observe/unobserve bookkeeping. */
class ResizeObserverStub {
  observe(): void {}
  unobserve(): void {}
  disconnect(): void {}
}

function rect(top: number, left: number, right: number, height: number): DOMRect {
  return { top, left, right, bottom: top + height, width: right - left, height, x: left, y: top, toJSON: () => ({}) } as DOMRect
}

function makeRow(key: string, kind: string, top: number): HTMLElement {
  const row = document.createElement('div')
  row.setAttribute('data-chat-anchor-key', key)
  row.setAttribute('data-chat-flow-kind', kind)
  row.getBoundingClientRect = () => rect(top, 20, 380, 60)
  Object.defineProperty(row, 'getClientRects', { value: () => [{}], configurable: true })
  return row
}

function makeScrollport(): HTMLElement {
  const scrollport = document.createElement('div')
  scrollport.setAttribute(SCROLLPORT_SELECTOR.replace(/^\[|\]$/g, ''), '')
  scrollport.getBoundingClientRect = () => rect(100, 0, 400, 800)
  Object.defineProperty(scrollport, 'scrollHeight', { value: 4000, configurable: true })
  Object.defineProperty(scrollport, 'clientHeight', { value: 800, configurable: true })
  Object.defineProperty(scrollport, 'scrollTop', { value: 120, configurable: true })
  scrollport.scrollTo = vi.fn()
  return scrollport
}

describe('Rail', () => {
  beforeEach(() => {
    vi.stubGlobal('ResizeObserver', ResizeObserverStub)
    document.body.replaceChildren()
    document.head.querySelectorAll('style').forEach((style) => style.remove())
  })

  it('renders one marker per marked row, filtered by kind, in a centered panel', () => {
    const scrollport = makeScrollport()
    const userRow = makeRow('user:1', 'user', 300)
    const assistantRow = makeRow('assistant:1', 'assistant-step', 1500)
    const toolRow = makeRow('tool:1', 'tool-call', 2800)
    scrollport.append(userRow, assistantRow, toolRow)
    document.body.appendChild(scrollport)

    const rail = new Rail(scrollport, { ...DEFAULT_OPTIONS, markKinds: ['user', 'assistant-step'] })
    rail.refresh()

    const overlay = document.body.querySelector(`.${PANEL_CLASS}`) as HTMLElement
    expect(overlay).not.toBeNull()

    // Panel: width 26, height = clamp(800 * 0.5, 140, 520) = 400, vertically
    // centered in the 800px scrollport at top 100 → top 300; left edge keeps a
    // 10px right margin: 400 - 10 - 26 = 364.
    expect(overlay.style.top).toBe('300px')
    expect(overlay.style.left).toBe('364px')
    expect(overlay.style.height).toBe('400px')

    const markers = [...overlay.querySelectorAll(`.${MARKER_CLASS}`)]
    expect(markers).toHaveLength(2)

    // contentTop = rect.top - scrollport.top + scrollTop → ratio → marker offset
    // inside the 400px panel:
    // user row: (300 - 100 + 120) / 4000 * 400 = 32
    expect((markers[0] as HTMLElement).style.top).toBe('32px')
    // assistant row: (1500 - 100 + 120) / 4000 * 400 = 152
    expect((markers[1] as HTMLElement).style.top).toBe('152px')

    expect((markers[0] as HTMLElement).dataset.kind).toBe('user')
    expect((markers[1] as HTMLElement).dataset.kind).toBe('assistant-step')

    // The count badge shows the number of marked conversations.
    const count = overlay.querySelector(`.${COUNT_CLASS}`)
    expect(count).not.toBeNull()
    expect(count!.textContent).toBe('2')
    rail.dispose()
  })

  it('shows a summary tooltip on hover and fades it out when the pointer leaves', () => {
    vi.useFakeTimers()
    try {
      const scrollport = makeScrollport()
      const row = makeRow('user:1', 'user', 300)
      const bubble = document.createElement('div')
      bubble.textContent = 'Build me a conversation indicator plugin'
      const chrome = document.createElement('button')
      chrome.textContent = 'Copy'
      row.append(bubble, chrome)
      scrollport.append(row)
      document.body.appendChild(scrollport)

      const rail = new Rail(scrollport, DEFAULT_OPTIONS)
      rail.refresh()

      const marker = document.body.querySelector(`.${MARKER_CLASS}`) as HTMLButtonElement
      const tooltip = document.body.querySelector(`.${TOOLTIP_CLASS}`) as HTMLElement
      expect(tooltip).not.toBeNull()
      expect(tooltip.style.display).toBe('none')

      // Reveal the panel by moving the pointer near it, then hover a marker.
      document.body.dispatchEvent(new MouseEvent('mousemove', { clientX: 380, clientY: 400, bubbles: true }))
      marker.dispatchEvent(new MouseEvent('mouseover', { bubbles: true }))
      expect(tooltip.style.display).toBe('block')
      expect(tooltip.textContent).toContain('Build me a conversation indicator plugin')
      expect(tooltip.textContent).not.toContain('Copy') // chrome is stripped

      // The pointer leaves the indicator; markers may have been rebuilt by
      // a refresh in between — document-level tracking still hides it.
      rail.refresh()
      document.body.dispatchEvent(new MouseEvent('mouseover', { bubbles: true }))
      expect(tooltip.style.opacity).toBe('0') // fade-out started…
      expect(tooltip.style.display).toBe('block') // …but it is still visible
      vi.advanceTimersByTime(400)
      expect(tooltip.style.display).toBe('none') // …until the fade completes
      rail.dispose()
    } finally {
      vi.useRealTimers()
    }
  })

  it('re-hovering during a fade-out cancels the hide', () => {
    vi.useFakeTimers()
    try {
      const scrollport = makeScrollport()
      scrollport.append(makeRow('user:1', 'user', 300))
      document.body.appendChild(scrollport)

      const rail = new Rail(scrollport, DEFAULT_OPTIONS)
      rail.refresh()
      const marker = document.body.querySelector(`.${MARKER_CLASS}`) as HTMLButtonElement
      const tooltip = document.body.querySelector(`.${TOOLTIP_CLASS}`) as HTMLElement

      document.body.dispatchEvent(new MouseEvent('mousemove', { clientX: 380, clientY: 400, bubbles: true }))
      marker.dispatchEvent(new MouseEvent('mouseover', { bubbles: true }))
      document.body.dispatchEvent(new MouseEvent('mouseover', { bubbles: true }))
      expect(tooltip.style.opacity).toBe('0')
      // Hover again before the fade-out completes.
      marker.dispatchEvent(new MouseEvent('mouseover', { bubbles: true }))
      vi.advanceTimersByTime(400)
      expect(tooltip.style.display).toBe('block') // the pending hide was cancelled
      rail.dispose()
    } finally {
      vi.useRealTimers()
    }
  })

  it('does not show the tooltip when tooltips are disabled', () => {
    const scrollport = makeScrollport()
    scrollport.append(makeRow('user:1', 'user', 300))
    document.body.appendChild(scrollport)

    const rail = new Rail(scrollport, { ...DEFAULT_OPTIONS, tooltips: false })
    rail.refresh()
    const marker = document.body.querySelector(`.${MARKER_CLASS}`) as HTMLButtonElement
    const tooltip = document.body.querySelector(`.${TOOLTIP_CLASS}`) as HTMLElement
    marker.dispatchEvent(new MouseEvent('mouseover', { bubbles: true }))
    expect(tooltip.style.display).toBe('none')
    rail.dispose()
  })

  it('positions the tooltip to the left of the panel, never over the scrollbar', () => {
    const scrollport = makeScrollport()
    scrollport.append(makeRow('user:1', 'user', 300))
    document.body.appendChild(scrollport)

    const rail = new Rail(scrollport, DEFAULT_OPTIONS)
    rail.refresh()
    const overlay = document.body.querySelector(`.${PANEL_CLASS}`) as HTMLElement
    // jsdom has no layout: stub the panel rect so the hot zone and the
    // horizontal anchor resolve to the computed position (left 364, top 300).
    Object.defineProperty(overlay, 'getBoundingClientRect', {
      configurable: true,
      value: () => ({ left: 364, top: 300, right: 390, bottom: 700, width: 26, height: 400, x: 364, y: 300, toJSON: () => ({}) }),
    })
    document.body.dispatchEvent(new MouseEvent('mousemove', { clientX: 380, clientY: 400, bubbles: true }))
    const marker = document.body.querySelector(`.${MARKER_CLASS}`) as HTMLButtonElement
    marker.dispatchEvent(new MouseEvent('mouseover', { bubbles: true }))

    const tooltip = document.body.querySelector(`.${TOOLTIP_CLASS}`) as HTMLElement
    // jsdom measures no layout (tooltip width/height are 0), so the tooltip
    // sits `gap` px left of the panel and centers on the panel vertically.
    expect(tooltip.style.left).toBe('354px') // 364 - 10 gap
    expect(tooltip.style.top).toBe('500px') // 300 + 400 / 2
    rail.dispose()
  })

  it('keeps the panel hidden until hover; scrolling never reveals it', () => {
    vi.useFakeTimers()
    try {
      const scrollport = makeScrollport()
      scrollport.append(makeRow('user:1', 'user', 300))
      document.body.appendChild(scrollport)

      const rail = new Rail(scrollport, DEFAULT_OPTIONS)
      rail.refresh()
      const overlay = document.body.querySelector(`.${PANEL_CLASS}`) as HTMLElement
      // jsdom has no layout, so give the panel the rect the geometry code
      // computes for this fixture (left 364, top 300, 26x400) for hot-zone hits.
      Object.defineProperty(overlay, 'getBoundingClientRect', {
        configurable: true,
        value: () => ({ left: 364, top: 300, right: 390, bottom: 700, width: 26, height: 400, x: 364, y: 300, toJSON: () => ({}) }),
      })
      expect(overlay.style.display).toBe('block') // laid out…
      expect(overlay.style.opacity).toBe('0') // …but invisible by default
      expect(overlay.style.visibility).toBe('hidden')

      // Scrolling (or DOM mutations while streaming) must NOT reveal it.
      scrollport.dispatchEvent(new Event('scroll'))
      expect(overlay.style.opacity).toBe('0')
      expect(overlay.style.visibility).toBe('hidden')

      // Moving the pointer near the panel reveals it.
      document.body.dispatchEvent(new MouseEvent('mousemove', { clientX: 380, clientY: 400, bubbles: true }))
      expect(overlay.style.opacity).toBe('1')
      expect(overlay.style.visibility).toBe('visible')

      // Leaving the zone starts the idle countdown; the panel stays visible
      // while it counts, then fades out with the configured fade-out duration.
      document.body.dispatchEvent(new MouseEvent('mousemove', { clientX: 100, clientY: 100, bubbles: true }))
      expect(overlay.style.opacity).toBe('1')
      vi.advanceTimersByTime(1000)
      expect(overlay.style.opacity).toBe('0')
      expect(overlay.style.visibility).toBe('hidden')
      expect(overlay.style.transitionDuration).toBe(`${DEFAULT_OPTIONS.fadeOutMs}ms`)

      // Even after the fade-out, scrolling still keeps it hidden.
      scrollport.dispatchEvent(new Event('scroll'))
      expect(overlay.style.opacity).toBe('0')
      expect(overlay.style.visibility).toBe('hidden')
      rail.dispose()
    } finally {
      vi.useRealTimers()
    }
  })

  it('clicking a marker scrolls the transcript to that conversation', () => {
    const scrollport = makeScrollport()
    const userRow = makeRow('user:1', 'user', 300)
    scrollport.append(userRow)
    document.body.appendChild(scrollport)

    const rail = new Rail(scrollport, DEFAULT_OPTIONS)
    rail.refresh()

    const marker = document.body.querySelector(`.${MARKER_CLASS}`) as HTMLButtonElement
    marker.click()
    expect(scrollport.scrollTo).toHaveBeenCalledWith({ top: 300 - 100 + 120 - DEFAULT_OPTIONS.scrollPadding, behavior: 'smooth' })
    rail.dispose()
  })

  it('hides the rail when disabled, when nothing matches, or without overflow', () => {
    const scrollport = makeScrollport()
    scrollport.append(makeRow('user:1', 'user', 300))
    document.body.appendChild(scrollport)

    const disabled = new Rail(scrollport, { ...DEFAULT_OPTIONS, enabled: false })
    disabled.refresh()
    expect((document.body.querySelector(`.${PANEL_CLASS}`) as HTMLElement).style.display).toBe('none')
    disabled.dispose()

    const noMatch = new Rail(scrollport, { ...DEFAULT_OPTIONS, markKinds: ['tool-call'] })
    noMatch.refresh()
    expect((document.body.querySelector(`.${PANEL_CLASS}`) as HTMLElement).style.display).toBe('none')
    noMatch.dispose()

    const noOverflow = makeScrollport()
    Object.defineProperty(noOverflow, 'scrollHeight', { value: 800, configurable: true })
    noOverflow.append(makeRow('user:1', 'user', 300))
    document.body.appendChild(noOverflow)
    const short = new Rail(noOverflow, DEFAULT_OPTIONS)
    short.refresh()
    expect((document.body.querySelector(`.${PANEL_CLASS}`) as HTMLElement).style.display).toBe('none')
    short.dispose()
  })

  it('dispose removes the overlay from the DOM', () => {
    const scrollport = makeScrollport()
    scrollport.append(makeRow('user:1', 'user', 300))
    document.body.appendChild(scrollport)

    const rail = new Rail(scrollport, DEFAULT_OPTIONS)
    rail.refresh()
    expect(document.body.querySelector(`.${PANEL_CLASS}`)).not.toBeNull()
    rail.dispose()
    expect(document.body.querySelector(`.${PANEL_CLASS}`)).toBeNull()
  })

  it('skips hidden rows without a layout box', () => {
    const scrollport = makeScrollport()
    const visible = makeRow('user:1', 'user', 300)
    const hidden = makeRow('user:2', 'user', 2000)
    Object.defineProperty(hidden, 'getClientRects', { value: () => [] })
    scrollport.append(visible, hidden)
    document.body.appendChild(scrollport)

    const rail = new Rail(scrollport, DEFAULT_OPTIONS)
    rail.refresh()
    const markers = document.body.querySelectorAll(`.${MARKER_CLASS}`)
    expect(markers).toHaveLength(1)
    expect((markers[0] as HTMLElement).dataset.key).toBe('user:1')
    rail.dispose()
  })
})
