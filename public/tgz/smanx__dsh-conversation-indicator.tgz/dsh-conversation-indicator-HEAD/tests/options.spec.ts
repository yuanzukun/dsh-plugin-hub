import { describe, expect, it } from 'vitest'
import { DEFAULT_OPTIONS, loadOptions, saveOptions } from '../src/client/options.ts'

function memoryStorage(): { getItem(key: string): string | null; setItem(key: string, value: string): void } {
  const data = new Map<string, string>()
  return {
    getItem: (key) => data.get(key) ?? null,
    setItem: (key, value) => { data.set(key, value) },
  }
}

describe('options', () => {
  it('returns defaults without persisted data', () => {
    expect(loadOptions(memoryStorage())).toEqual(DEFAULT_OPTIONS)
  })

  it('merges a partial persisted patch over the defaults', () => {
    const storage = memoryStorage()
    storage.setItem('dsh-conversation-indicator.options', JSON.stringify({ markKinds: ['user'] }))
    const options = loadOptions(storage)
    expect(options.markKinds).toEqual(['user'])
    expect(options.enabled).toBe(true)
    expect(options.railWidth).toBe(DEFAULT_OPTIONS.railWidth)
  })

  it('ignores invalid JSON and invalid shapes', () => {
    const broken = memoryStorage()
    broken.setItem('dsh-conversation-indicator.options', 'not json')
    expect(loadOptions(broken)).toEqual(DEFAULT_OPTIONS)

    const wrongType = memoryStorage()
    wrongType.setItem('dsh-conversation-indicator.options', JSON.stringify({ enabled: 'yes' }))
    expect(loadOptions(wrongType)).toEqual(DEFAULT_OPTIONS)

    const wrongKinds = memoryStorage()
    wrongKinds.setItem('dsh-conversation-indicator.options', JSON.stringify({ markKinds: [1, 2] }))
    expect(loadOptions(wrongKinds)).toEqual(DEFAULT_OPTIONS)
  })

  it('round-trips a save', () => {
    const storage = memoryStorage()
    saveOptions({ markerSize: 10, tooltips: false }, storage)
    const options = loadOptions(storage)
    expect(options.markerSize).toBe(10)
    expect(options.tooltips).toBe(false)
    expect(options.enabled).toBe(true) // untouched keys keep defaults
  })
})
