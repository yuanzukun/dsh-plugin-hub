/** The hover tooltip that shows a conversation summary next to a marker. */
export declare const TOOLTIP_CLASS = "dsh-ci-tooltip";
export declare const TOOLTIP_HEADER_CLASS = "dsh-ci-tooltip-header";
export declare const TOOLTIP_BODY_CLASS = "dsh-ci-tooltip-body";
/** Fade-out duration (ms) when the pointer leaves a marker. */
export declare const FADE_OUT_MS = 300;
/** Fade-in duration (ms) when a marker is hovered. */
export declare const FADE_IN_MS = 120;
export interface TooltipContent {
    readonly header: string;
    readonly body: string;
}
/**
 * A single reusable tooltip element, appended to <body>, hidden until a
 * marker is hovered. It fades in quickly on show and fades out slowly on
 * hide; a show during a pending fade-out cancels the hide. Positioned left
 * of the marker, flipping to the right when there is no room, and clamped
 * into the viewport.
 */
export declare class Tooltip {
    readonly element: HTMLDivElement;
    private readonly header;
    private readonly body;
    private hideTimer;
    private hidden;
    constructor();
    /**
     * Show the tooltip just to the left of the panel, vertically centered on
     * the anchor point, clamped into the viewport. It never renders over the
     * scrollbar: when there is not enough room the left edge is clamped into
     * the viewport instead of flipping to the marker's right side.
     */
    show(content: TooltipContent, anchorLeft: number, anchorTop: number): void;
    /** Fade the tooltip out; it is removed from view when the transition ends. */
    hide(): void;
    /** Remove the tooltip from the DOM immediately, cancelling any fade. */
    dispose(): void;
}
