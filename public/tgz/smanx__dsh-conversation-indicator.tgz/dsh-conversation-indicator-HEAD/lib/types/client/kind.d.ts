/** Kind labels and filtering for the chat node rows the indicator marks. */
export type Language = 'zh' | 'en';
/** Pick the UI language from the environment. */
export declare function detectLanguage(navigatorLanguage?: string): Language;
/** Human-readable kind label in the given language (falls back to the kind). */
export declare function kindLabel(kind: string, language: Language): string;
/** Whether a kind should be marked under the configured filter. */
export declare function shouldMark(kind: string, markKinds: readonly string[]): boolean;
