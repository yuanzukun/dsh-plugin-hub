/** Pure geometry helpers shared by the rail and its tests. */
/** Whether the scrollport has content overflow worth marking. */
export declare function hasOverflow(scrollHeight: number, clientHeight: number): boolean;
/** Fraction of the scroll content above a row's top edge, clamped to [0, 1]. */
export declare function contentRatio(contentTop: number, scrollHeight: number): number;
/** Marker top offset inside the rail for a content ratio and rail height. */
export declare function markerTop(ratio: number, railHeight: number, markerSize: number): number;
/** Panel height for a viewport height: a fraction of it, clamped to [min, max]. */
export declare function panelHeightFor(viewportHeight: number, ratio: number, min: number, max: number): number;
/** Scroll target that brings a row's top near the top of the scrollport. */
export declare function scrollTarget(contentTop: number, padding: number): number;
