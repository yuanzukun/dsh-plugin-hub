import { type IndicatorOptions } from './options.ts';
export declare const SCROLLPORT_SELECTOR = "[data-conversation-scroll]";
export declare const ROW_SELECTOR = "[data-chat-anchor-key]";
/** Read the app's scrollbar width (it publishes it as a CSS custom property). */
export declare function scrollbarWidthOf(scrollport: HTMLElement): number;
export declare class Rail {
    readonly scrollport: HTMLElement;
    private readonly overlay;
    private readonly options;
    private readonly language;
    private readonly tooltip;
    private frame;
    private rows;
    private hoveredKey;
    private panelShown;
    private idleTimer;
    private pointerX;
    private pointerY;
    private readonly onScroll;
    private readonly onResize;
    private readonly onFrame;
    private readonly onMouseOver;
    private readonly onMouseMove;
    private readonly onMouseDown;
    private readonly onFocusIn;
    private readonly onFocusOut;
    private readonly observer;
    private readonly mutation;
    constructor(scrollport: HTMLElement, options?: IndicatorOptions);
    private attach;
    /** Whether the pointer currently sits in the hot zone around the panel. */
    private pointerInZone;
    /** Reveal the panel immediately and cancel any pending fade-out. */
    private showPanel;
    /** Start (or restart) the idle countdown that fades the panel out. */
    private schedulePanelHide;
    /** Fade the panel out; it stops receiving pointer events once hidden. */
    private hidePanel;
    /** Whether the event target is one of this rail's markers. */
    private isMarker;
    /** Show the summary when the pointer enters a marker; hide otherwise. */
    private handlePointerEnter;
    /** Read the current marked row set from the DOM. */
    private readRows;
    /** Recompute marker positions on the next animation frame. */
    schedule(): void;
    refresh(): void;
    private buildMarkers;
    private buildMarker;
    /** Show the summary tooltip just left of the panel, aligned with the marker. */
    private showSummary;
    /** Fade the summary tooltip out. */
    private hideSummary;
    /** Remove the panel, the tooltip, and all listeners. */
    dispose(): void;
}
