/** Summary extraction from a rendered conversation row. */
/** Collapse all whitespace runs into single spaces and trim. */
export declare function normalizeText(text: string): string;
/** Truncate to at most maxChars characters, ending with an ellipsis. */
export declare function truncate(text: string, maxChars: number): string;
/**
 * Extract a readable summary of a row's content, stripping UI chrome
 * (buttons, icons, menus) without depending on the app's hashed class names.
 * Returns '' when nothing readable remains.
 */
export declare function extractSummary(row: HTMLElement, maxChars: number): string;
