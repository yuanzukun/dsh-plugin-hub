export declare const name = "@smanx/dsh-conversation-indicator";
/** The indicator needs no framework service; it talks to the DOM only. */
export declare const inject: readonly string[];
export declare function apply(): () => void;
