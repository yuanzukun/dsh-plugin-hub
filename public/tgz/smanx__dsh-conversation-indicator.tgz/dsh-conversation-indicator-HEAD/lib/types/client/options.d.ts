/** Persisted options for the conversation indicator. */
export interface IndicatorOptions {
    /** Master switch; false removes every marker. */
    enabled: boolean;
    /**
     * Node kinds to mark, matched against each row's `data-chat-flow-kind`.
     * `'*'` marks every rendered row. Defaults to user messages (`'user'`)
     * only; assistant replies (kind `assistant-step`) are not marked unless
     * added here.
     */
    markKinds: readonly string[];
    /** Panel width in px (the compact pill near the scrollbar). */
    panelWidth: number;
    /** Marker (bar) height in px. */
    markerSize: number;
    /** Gap between the panel and the scrollport's right edge in px. */
    rightMargin: number;
    /** Panel height as a fraction of the scrollport height. */
    panelHeightRatio: number;
    /** Panel height bounds in px. */
    minPanelHeight: number;
    maxPanelHeight: number;
    /** Show a small conversation-count badge at the panel's bottom. */
    showCount: boolean;
    /** Show a summary tooltip on hover (kind label + extracted row text). */
    tooltips: boolean;
    /** Max characters of the hover summary body. */
    summaryMaxChars: number;
    /** Extra px kept above the target row when jumping. */
    scrollPadding: number;
    /** Hot zone around the panel (px) that reveals it while the pointer is near. */
    hoverZoneX: number;
    hoverZoneY: number;
    /** Ms of no pointer activity before the panel starts fading out. */
    idleHideMs: number;
    /** Panel fade-out animation duration in ms (fade-in stays at 200ms). */
    fadeOutMs: number;
}
export declare const DEFAULT_OPTIONS: IndicatorOptions;
/** Load persisted options, tolerating a broken or unavailable store. */
export declare function loadOptions(storage?: Pick<Storage, 'getItem'> | undefined): IndicatorOptions;
/** Persist a partial options patch; failures are swallowed (read-only modes). */
export declare function saveOptions(patch: Partial<IndicatorOptions>, storage?: Pick<Storage, 'getItem' | 'setItem'> | undefined): void;
