/** Style injection for the indicator panel. */
export declare const STYLE_ID = "dsh-conversation-indicator.css";
export declare const PANEL_CLASS = "dsh-ci-rail";
export declare const MARKER_CLASS = "dsh-ci-marker";
export declare const COUNT_CLASS = "dsh-ci-count";
export declare const TOOLTIP_CLASS = "dsh-ci-tooltip";
export declare const TOOLTIP_HEADER_CLASS = "dsh-ci-tooltip-header";
export declare const TOOLTIP_BODY_CLASS = "dsh-ci-tooltip-body";
/** One shared <style> element, appended to <head> when the first panel mounts. */
export declare const INJECT_CSS: HTMLStyleElement;
