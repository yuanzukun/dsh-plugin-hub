/**
 * @smanx/dsh-conversation-indicator host entry: a deliberate no-op.
 *
 * The indicator is browser-only: the client half (lib/client.js) observes the
 * transcript scrollport and renders clickable markers. The host row exists so
 * the package is a bundle in the profile's layer stack and its client half is
 * composed into the web boot; nothing runs server-side.
 */
export declare const name = "@smanx/dsh-conversation-indicator";
/** No host services are required. */
export declare const inject: readonly string[];
/** No server-side registration. */
export declare function apply(): void;
