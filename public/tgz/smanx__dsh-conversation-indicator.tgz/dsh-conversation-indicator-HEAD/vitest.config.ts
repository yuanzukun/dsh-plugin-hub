import { defineConfig } from 'vitest/config'

export default defineConfig({
  test: {
    environment: 'jsdom',
    environmentOptions: {
      jsdom: {
        // requestAnimationFrame support for the Rail's rAF scheduling.
        pretendToBeVisual: true,
      },
    },
    include: ['tests/**/*.spec.ts'],
  },
})
