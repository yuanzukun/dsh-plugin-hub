# @smanx/dsh-conversation-indicator

> [中文](README.md) | English

Conversation indicator for the DeepSeek Harness web GUI. A compact pill sits
vertically centered on the right side of the transcript, just left of the
scrollbar, with one clickable marker bar per user message — assistant replies
are not marked. Clicking a marker smooth-scrolls
the transcript so that conversation lands near the top, so you can jump around
a long session without dragging the scrollbar or scrolling past tool spam. The
pill stays out of the way while the transcript scrolls or streams: it appears
only when the pointer moves near it and fades out once the pointer leaves.

![Screenshot: the indicator pill on the right edge of the transcript](image.png)

*Hover a marker for the summary tooltip; click it to jump to that conversation.*

```
browser: watches [data-conversation-scroll] (the app's transcript scrollport)
         -> reads [data-chat-anchor-key] rows, filtered by data-chat-flow-kind
         -> fixed pill overlay, vertically centered near the right edge
         -> one marker bar per row, positioned by content ratio (contentTop / scrollHeight)
         -> click -> scrollport.scrollTo({ top: contentTop - padding, behavior: 'smooth' })
```

No harness change is needed and nothing runs server-side: the host entry is a
no-op; the whole plugin is the client bundle served at
`/plugins/@smanx/dsh-conversation-indicator/client.js`.

## Install

From the GitHub repository (pnpm's `github:` git-dependency shorthand for
`git+ssh://git@github.com/smanx/dsh-conversation-indicator.git#main`):

```sh
dsh plugin --profile web add github:smanx/dsh-conversation-indicator#main
```

After install the plugin shows up as `@smanx/dsh-conversation-indicator` in the
plugin inventory and the profile dependencies (npm scope = developer name
`smanx` + plugin name).

Restart the web server once so the boot manifest composes the new client
bundle, then refresh the page. The pill stays hidden while the transcript
scrolls or streams — move the pointer near it (the right edge, just left of
the scrollbar) to reveal it, and it fades out when the pointer leaves. It only
exists at all when the current session has more than one screen of content (it
hides when the transcript does not overflow). To update, run the same command
again — pnpm re-resolves the git dependency to the latest commit.

For development against the working tree (live rebuilds, no re-install), point
the profile at the local checkout instead:

```sh
dsh plugin --profile web add file:C:/mydata/codes/dsh-conversation-indicator
```

## Options

The plugin is self-contained and keeps its preferences in the browser
(`localStorage["dsh-conversation-indicator.options"]`, JSON, partial merge).
Set them from DevTools and reload; changes apply on the next plugin mount.

| Key | Default | Effect |
| --- | --- | --- |
| `enabled` | `true` | Master switch. |
| `markKinds` | `["user"]` | Row kinds to mark (`data-chat-flow-kind`); `"*"` marks every rendered row. Assistant replies render as kind `assistant-step` and are not marked by default — add `"assistant-step"` (or `"*"`) to mark them too. Other kinds: `steering`, `context`, `tool-call`, `command`, `compaction`, `manual-compaction`, `model-retry`, `turn-error`, `turn-max-tokens`, `turn-tail`, `unknown`. |
| `panelWidth` | `26` | Panel (pill) width in px. |
| `markerSize` | `6` | Marker bar height in px. |
| `rightMargin` | `10` | Gap between the panel and the scrollport's right edge in px. |
| `panelHeightRatio` | `0.5` | Panel height as a fraction of the scrollport height (markers stay concentrated in the middle band). |
| `minPanelHeight` / `maxPanelHeight` | `140` / `520` | Panel height bounds in px. |
| `showCount` | `true` | Small conversation-count badge at the panel's bottom. |
| `tooltips` | `true` | Hover summary tooltip: kind label + the row's text (UI chrome stripped). |
| `summaryMaxChars` | `200` | Max characters of the hover summary body. |
| `scrollPadding` | `12` | Extra px kept above the target row when jumping. |
| `hoverZoneX` | `28` | Hot zone around the panel (px, horizontal) that reveals it on hover. |
| `hoverZoneY` | `24` | Hot zone around the panel (px, vertical) that reveals it on hover. |
| `idleHideMs` | `450` | Ms of no pointer activity before the panel starts fading out. |
| `fadeOutMs` | `400` | Panel fade-out animation duration in ms (fade-in stays at 200ms). |

```js
localStorage["dsh-conversation-indicator.options"] = JSON.stringify({
  markKinds: ["user", "tool-call"],
  panelWidth: 30,
  markerSize: 8,
})
```

## Model experience

| Aspect | Effect |
| --- | --- |
| Token cost | None — indicators are UI-only and never enter a request. |
| Tool calls | None — the model gets no new tool. |
| Session log | Unchanged — the plugin reads the rendered DOM only, adds no events. |
| Prompt | Unchanged — no system-prompt section is registered. |

## Permission boundary

- The client observes the transcript scrollport and the rows the web app
  already renders (`[data-chat-anchor-key]` / `[data-chat-flow-kind]`); it
  writes nothing to the session log and registers no model-facing tools.
- The rail is a `pointer-events: none` overlay; only the small markers are
  interactive, so the scrollbar and the conversation remain fully usable.
- Marker positions are layout-derived (proportional to the row's place in the
  scroll content); no conversation content is copied or stored.

## Development

```sh
pnpm install
pnpm run check    # typecheck + vitest + build (lib/ committed with source)
pnpm run test     # vitest (geometry / kind / options / rail DOM behavior)
pnpm run build    # esbuild host + client bundles, tsc declarations
```

The plugin has no dependency on the harness checkout: the client bundle is
self-contained vanilla DOM, so `pnpm install` needs no `../dsh` sibling.

## Known limitations

- Markers reflect the currently loaded history window; very old rows that the
  web app has not rendered yet cannot be marked (paging in more history adds
  their markers).
- The rail is drawn near the scrollbar of the active conversation view; it
  does not overlay other views (trajectory, details panel).
- Options are read at plugin mount; toggling `localStorage` live takes effect
  on the next mount (page reload or view remount).
- Smooth scrolling is animated by the browser; clicking many markers in
  quick succession may not interrupt the current animation.

## License

MIT
