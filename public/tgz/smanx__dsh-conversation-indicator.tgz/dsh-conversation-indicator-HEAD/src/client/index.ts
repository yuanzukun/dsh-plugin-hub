/**
 * @smanx/dsh-conversation-indicator client entry: the browser half that draws
 * clickable conversation markers along the transcript scrollbar.
 *
 * The plugin is self-contained (no harness service is required): it watches
 * for the app's transcript scrollport (`[data-conversation-scroll]`), reads
 * the rendered conversation rows (`[data-chat-anchor-key]`), and positions
 * one marker per marked kind (default: user messages + assistant replies).
 * Clicking a marker scrolls the transcript to that conversation.
 *
 * Options persist under `localStorage["dsh-conversation-indicator.options"]`
 * (see src/client/options.ts); changes apply on the next plugin mount.
 */
import { loadOptions } from './options.ts'
import { Rail, SCROLLPORT_SELECTOR } from './rail.ts'

export const name = '@smanx/dsh-conversation-indicator'

/** The indicator needs no framework service; it talks to the DOM only. */
export const inject: readonly string[] = []

const WATCH_INTERVAL_MS = 750

/** One controller instance for the lifetime of the plugin mount. */
class Controller {
  private readonly rails = new Map<HTMLElement, Rail>()
  private timer: ReturnType<typeof setInterval> | undefined
  private started = false

  start(): void {
    if (this.started) return
    this.started = true
    this.sync()
    this.timer = setInterval(() => this.sync(), WATCH_INTERVAL_MS)
  }

  /** Attach rails to new scrollports, detach from removed ones. */
  private sync(): void {
    if (!loadOptions().enabled) {
      this.disposeAll()
      return
    }
    const live = new Set<HTMLElement>(Array.from(document.querySelectorAll<HTMLElement>(SCROLLPORT_SELECTOR)))
    for (const [element, rail] of this.rails) {
      if (!live.has(element) || !element.isConnected) {
        rail.dispose()
        this.rails.delete(element)
      }
    }
    for (const element of live) {
      if (!this.rails.has(element)) {
        try {
          this.rails.set(element, new Rail(element))
        } catch (error) {
          console.warn('[@smanx/dsh-conversation-indicator] rail attach failed', error)
        }
      }
    }
  }

  disposeAll(): void {
    for (const rail of this.rails.values()) rail.dispose()
    this.rails.clear()
  }

  dispose(): void {
    if (this.timer !== undefined) clearInterval(this.timer)
    this.timer = undefined
    this.started = false
    this.disposeAll()
  }
}

const controller = new Controller()

export function apply(): () => void {
  controller.start()
  return () => controller.dispose()
}
