/** Style injection for the indicator panel. */

export const STYLE_ID = 'dsh-conversation-indicator.css'
export const PANEL_CLASS = 'dsh-ci-rail'
export const MARKER_CLASS = 'dsh-ci-marker'
export const COUNT_CLASS = 'dsh-ci-count'
export const TOOLTIP_CLASS = 'dsh-ci-tooltip'
export const TOOLTIP_HEADER_CLASS = 'dsh-ci-tooltip-header'
export const TOOLTIP_BODY_CLASS = 'dsh-ci-tooltip-body'

const CSS = `
.${PANEL_CLASS} {
  position: fixed;
  z-index: 2147483000;
  pointer-events: none;
  box-sizing: border-box;
  border-radius: 999px;
  background: rgba(28, 28, 30, 0.78);
  background: color-mix(in srgb, var(--dsw-alias-bg-overlay, #1c1c1e) 82%, transparent);
  border: 1px solid var(--dsw-alias-border-l2, rgba(127, 127, 127, 0.35));
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.22);
  opacity: 0;
  visibility: hidden;
  /* Default durations; rail.ts overrides the duration per direction
     (200ms fade-in, fadeOutMs fade-out). */
  transition: opacity 200ms ease, visibility 200ms;
}
.${MARKER_CLASS} {
  position: absolute;
  left: 7px;
  right: 7px;
  border: 0;
  border-radius: 999px;
  padding: 0;
  margin: 0;
  cursor: pointer;
  pointer-events: auto;
  background: rgba(127, 127, 127, 0.55);
  background: color-mix(in srgb, var(--dsw-alias-label-primary, #888888) 55%, transparent);
  opacity: 0.72;
  transition: opacity 120ms ease, transform 120ms ease;
}
.${MARKER_CLASS}:hover {
  opacity: 1;
  transform: scaleY(1.45);
  background: var(--dsw-alias-label-primary, #888888);
}
.${COUNT_CLASS} {
  position: absolute;
  left: 0;
  right: 0;
  bottom: 3px;
  text-align: center;
  font-size: 9px;
  line-height: 1;
  color: var(--dsw-alias-label-secondary, #aaaaaa);
  pointer-events: none;
  user-select: none;
}
.${TOOLTIP_CLASS} {
  position: fixed;
  z-index: 2147483100;
  max-width: 300px;
  max-height: 220px;
  overflow: hidden;
  border-radius: 8px;
  padding: 8px 10px;
  font-size: 12px;
  line-height: 1.5;
  color: var(--dsw-alias-label-primary, #eeeeee);
  background: rgba(28, 28, 30, 0.92);
  background: color-mix(in srgb, var(--dsw-alias-bg-overlay, #1c1c1e) 92%, transparent);
  border: 1px solid var(--dsw-alias-border-l2, rgba(127, 127, 127, 0.35));
  box-shadow: 0 4px 16px rgba(0, 0, 0, 0.3);
  pointer-events: none;
  user-select: none;
  opacity: 0;
  transition: opacity 120ms ease;
}
.${TOOLTIP_HEADER_CLASS} {
  display: block;
  font-weight: 600;
  margin-bottom: 4px;
  color: var(--dsw-alias-label-secondary, #bbbbbb);
}
.${TOOLTIP_BODY_CLASS} {
  display: block;
  white-space: pre-wrap;
  word-break: break-word;
}
`

/** One shared <style> element, appended to <head> when the first panel mounts. */
export const INJECT_CSS: HTMLStyleElement = (() => {
  const style = document.createElement('style')
  style.id = STYLE_ID
  style.dataset.pluginCss = 'dsh-conversation-indicator'
  style.textContent = CSS
  return style
})()
