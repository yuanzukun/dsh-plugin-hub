/** Kind labels and filtering for the chat node rows the indicator marks. */

/**
 * Labels for the chat-flow kinds the web app actually renders as
 * `data-chat-flow-kind` rows (verified against dsh-client-ui-conversation:
 * assistant replies render as `assistant-step`, tool calls as `tool-call`,
 * retries as `model-retry`). Legacy aliases from older app versions are kept
 * so the labels and filtering still make sense there too.
 */
const KIND_LABELS: Readonly<Record<string, { zh: string; en: string }>> = {
  user: { zh: '用户消息', en: 'User message' },
  'assistant-step': { zh: '助手回复', en: 'Assistant reply' },
  assistant: { zh: '助手回复', en: 'Assistant reply' }, // legacy alias
  steering: { zh: '改写消息', en: 'Steering' },
  context: { zh: '注入上下文', en: 'Context' },
  'tool-call': { zh: '工具调用', en: 'Tool call' },
  tool: { zh: '工具调用', en: 'Tool call' }, // legacy alias
  command: { zh: '命令', en: 'Command' },
  compaction: { zh: '上下文压缩', en: 'Compaction' },
  'manual-compaction': { zh: '手动压缩', en: 'Manual compaction' },
  'model-retry': { zh: '模型重试', en: 'Model retry' },
  retry: { zh: '重试', en: 'Retry' }, // legacy alias
  'turn-error': { zh: '回合错误', en: 'Turn error' },
  'turn-max-tokens': { zh: 'Token 上限', en: 'Token limit' },
  'turn-tail': { zh: '回合尾', en: 'Turn tail' },
  inbox: { zh: '待处理', en: 'Inbox' },
  unknown: { zh: '未知节点', en: 'Unknown node' },
}

export type Language = 'zh' | 'en'

/** Pick the UI language from the environment. */
export function detectLanguage(navigatorLanguage: string = navigator.language): Language {
  return /^zh\b/i.test(navigatorLanguage) ? 'zh' : 'en'
}

/** Human-readable kind label in the given language (falls back to the kind). */
export function kindLabel(kind: string, language: Language): string {
  return KIND_LABELS[kind]?.[language] ?? kind
}

/** Whether a kind should be marked under the configured filter. */
export function shouldMark(kind: string, markKinds: readonly string[]): boolean {
  return markKinds.includes('*') || markKinds.includes(kind)
}
