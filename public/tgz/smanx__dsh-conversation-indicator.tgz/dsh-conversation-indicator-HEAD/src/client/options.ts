/** Persisted options for the conversation indicator. */

export interface IndicatorOptions {
  /** Master switch; false removes every marker. */
  enabled: boolean
  /**
   * Node kinds to mark, matched against each row's `data-chat-flow-kind`.
   * `'*'` marks every rendered row. Defaults to user messages (`'user'`)
   * only; assistant replies (kind `assistant-step`) are not marked unless
   * added here.
   */
  markKinds: readonly string[]
  /** Panel width in px (the compact pill near the scrollbar). */
  panelWidth: number
  /** Marker (bar) height in px. */
  markerSize: number
  /** Gap between the panel and the scrollport's right edge in px. */
  rightMargin: number
  /** Panel height as a fraction of the scrollport height. */
  panelHeightRatio: number
  /** Panel height bounds in px. */
  minPanelHeight: number
  maxPanelHeight: number
  /** Show a small conversation-count badge at the panel's bottom. */
  showCount: boolean
  /** Show a summary tooltip on hover (kind label + extracted row text). */
  tooltips: boolean
  /** Max characters of the hover summary body. */
  summaryMaxChars: number
  /** Extra px kept above the target row when jumping. */
  scrollPadding: number
  /** Hot zone around the panel (px) that reveals it while the pointer is near. */
  hoverZoneX: number
  hoverZoneY: number
  /** Ms of no pointer activity before the panel starts fading out. */
  idleHideMs: number
  /** Panel fade-out animation duration in ms (fade-in stays at 200ms). */
  fadeOutMs: number
}

const STORAGE_KEY = 'dsh-conversation-indicator.options'

export const DEFAULT_OPTIONS: IndicatorOptions = {
  enabled: true,
  markKinds: ['user'],
  panelWidth: 26,
  markerSize: 6,
  rightMargin: 10,
  panelHeightRatio: 0.5,
  minPanelHeight: 140,
  maxPanelHeight: 520,
  showCount: true,
  tooltips: true,
  summaryMaxChars: 200,
  scrollPadding: 12,
  hoverZoneX: 28,
  hoverZoneY: 24,
  idleHideMs: 450,
  fadeOutMs: 400,
}

const NUMBER_KEYS = [
  'panelWidth',
  'markerSize',
  'rightMargin',
  'panelHeightRatio',
  'minPanelHeight',
  'maxPanelHeight',
  'summaryMaxChars',
  'scrollPadding',
  'hoverZoneX',
  'hoverZoneY',
  'idleHideMs',
  'fadeOutMs',
] as const

function isOptions(value: unknown): value is Partial<IndicatorOptions> {
  if (typeof value !== 'object' || value === null) return false
  const record = value as Record<string, unknown>
  if (record.enabled !== undefined && typeof record.enabled !== 'boolean') return false
  if (record.showCount !== undefined && typeof record.showCount !== 'boolean') return false
  if (record.tooltips !== undefined && typeof record.tooltips !== 'boolean') return false
  if (record.markKinds !== undefined) {
    if (!Array.isArray(record.markKinds) || !record.markKinds.every((k) => typeof k === 'string')) return false
  }
  for (const key of NUMBER_KEYS) {
    const v = record[key]
    if (v !== undefined && (typeof v !== 'number' || !Number.isFinite(v))) return false
  }
  return true
}

function safeStorage(): Storage | undefined {
  try {
    return typeof localStorage === 'undefined' ? undefined : localStorage
  } catch {
    return undefined
  }
}

/** Load persisted options, tolerating a broken or unavailable store. */
export function loadOptions(storage: Pick<Storage, 'getItem'> | undefined = safeStorage()): IndicatorOptions {
  const merged: IndicatorOptions = { ...DEFAULT_OPTIONS }
  try {
    const raw = storage?.getItem(STORAGE_KEY)
    if (raw === null || raw === undefined) return merged
    const parsed: unknown = JSON.parse(raw)
    if (!isOptions(parsed)) return merged
    return { ...merged, ...parsed }
  } catch {
    return merged
  }
}

/** Persist a partial options patch; failures are swallowed (read-only modes). */
export function saveOptions(
  patch: Partial<IndicatorOptions>,
  storage: Pick<Storage, 'getItem' | 'setItem'> | undefined = safeStorage(),
): void {
  try {
    const current = loadOptions(storage)
    storage?.setItem(STORAGE_KEY, JSON.stringify({ ...current, ...patch }))
  } catch {
    // ignore
  }
}
