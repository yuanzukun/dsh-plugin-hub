/**
 * One overlay panel attached to one transcript scrollport.
 *
 * The web client renders each conversation row with a stable
 * `data-chat-anchor-key` and a `data-chat-flow-kind` (see
 * dsh-client-ui-conversation's ChatNodeSeat), inside the transcript
 * scrollport `[data-conversation-scroll]`. The indicator is a compact pill
 * (appended to <body>, viewport-fixed) vertically centered on the scrollport's
 * right side, just left of the scrollbar; each marked row gets one marker bar
 * positioned proportionally to its place in the scroll content, compressed
 * into the pill. The pill stays hidden while the transcript scrolls or
 * streams — it reveals only when the pointer moves near it (hot zone around
 * the panel) and fades out once the pointer leaves. Hovering a marker shows a
 * summary tooltip (kind label + the row's text, stripped of UI chrome);
 * clicking a marker scrolls the transcript so that conversation lands near
 * the top.
 */
import { contentRatio, hasOverflow, markerTop, panelHeightFor, scrollTarget } from './geometry.ts'
import { detectLanguage, kindLabel, shouldMark, type Language } from './kind.ts'
import { loadOptions, type IndicatorOptions } from './options.ts'
import { extractSummary } from './summary.ts'
import { COUNT_CLASS, INJECT_CSS, MARKER_CLASS, PANEL_CLASS, TOOLTIP_CLASS } from './styles.ts'
import { Tooltip } from './tooltip.ts'

export const SCROLLPORT_SELECTOR = '[data-conversation-scroll]'
export const ROW_SELECTOR = '[data-chat-anchor-key]'

/** Panel fade-in duration in ms (the fade-out duration is the `fadeOutMs` option). */
const FADE_IN_MS = 200

interface RowTarget {
  readonly element: HTMLElement
  readonly kind: string
  readonly key: string
}

/** Read the app's scrollbar width (it publishes it as a CSS custom property). */
export function scrollbarWidthOf(scrollport: HTMLElement): number {
  const raw = getComputedStyle(scrollport).getPropertyValue('--dsh-scrollbar-width')
  const parsed = Number.parseFloat(raw)
  return Number.isFinite(parsed) && parsed > 0 ? parsed : 0
}

export class Rail {
  readonly scrollport: HTMLElement
  private readonly overlay: HTMLDivElement
  private readonly options: IndicatorOptions
  private readonly language: Language
  private readonly tooltip: Tooltip
  private frame = 0
  private rows: readonly RowTarget[] = []
  private hoveredKey: string | null = null
  private panelShown = false
  private idleTimer: ReturnType<typeof setTimeout> | undefined
  private pointerX = -1
  private pointerY = -1
  private readonly onScroll: () => void
  private readonly onResize: () => void
  private readonly onFrame: () => void
  private readonly onMouseOver: (event: MouseEvent) => void
  private readonly onMouseMove: (event: MouseEvent) => void
  private readonly onMouseDown: (event: MouseEvent) => void
  private readonly onFocusIn: (event: FocusEvent) => void
  private readonly onFocusOut: () => void
  private readonly observer: ResizeObserver
  private readonly mutation: MutationObserver

  constructor(scrollport: HTMLElement, options: IndicatorOptions = loadOptions()) {
    this.scrollport = scrollport
    this.options = options
    this.language = detectLanguage()
    this.overlay = document.createElement('div')
    this.overlay.className = PANEL_CLASS
    this.overlay.style.width = `${options.panelWidth}px`
    this.overlay.style.opacity = '0'
    this.overlay.style.visibility = 'hidden'
    this.tooltip = new Tooltip()
    this.onScroll = () => {
      // Scrolling / streaming only repositions the markers; it must never
      // reveal the panel — the pill is hover-only.
      this.schedule()
    }
    this.onResize = () => this.schedule()
    this.onFrame = () => this.refresh()
    this.onMouseOver = (event) => this.handlePointerEnter(event.target)
    this.onMouseMove = (event) => {
      this.pointerX = event.clientX
      this.pointerY = event.clientY
      if (this.pointerInZone()) this.showPanel()
      else this.schedulePanelHide()
    }
    this.onMouseDown = (event) => {
      if (this.options.tooltips && !this.isMarker(event.target)) this.hideSummary()
    }
    this.onFocusIn = (event) => this.handlePointerEnter(event.target)
    this.onFocusOut = () => this.hideSummary()
    this.observer = new ResizeObserver(this.onResize)
    this.mutation = new MutationObserver(this.onScroll)
    document.head?.appendChild(INJECT_CSS)
    this.attach()
  }

  private attach(): void {
    document.body.appendChild(this.overlay)
    this.scrollport.addEventListener('scroll', this.onScroll, { passive: true })
    window.addEventListener('resize', this.onResize)
    // Document-level pointer tracking: markers are rebuilt on every refresh
    // (scrolling / streaming), so per-marker mouseleave is unreliable — a
    // replaced marker under the cursor never fires it. Re-evaluating on every
    // mouseover guarantees the tooltip fades out as soon as the pointer leaves
    // the indicator, even across rebuilds.
    document.addEventListener('mouseover', this.onMouseOver)
    document.addEventListener('mousemove', this.onMouseMove)
    document.addEventListener('mousedown', this.onMouseDown)
    document.addEventListener('focusin', this.onFocusIn)
    document.addEventListener('focusout', this.onFocusOut)
    this.observer.observe(this.scrollport)
    this.mutation.observe(this.scrollport, { childList: true, subtree: true })
    this.schedule()
  }

  /** Whether the pointer currently sits in the hot zone around the panel. */
  private pointerInZone(): boolean {
    const rect = this.overlay.getBoundingClientRect()
    if (rect.width === 0 || rect.height === 0) return false
    return this.pointerX >= rect.left - this.options.hoverZoneX
      && this.pointerX <= rect.right + this.options.hoverZoneX
      && this.pointerY >= rect.top - this.options.hoverZoneY
      && this.pointerY <= rect.bottom + this.options.hoverZoneY
  }

  /** Reveal the panel immediately and cancel any pending fade-out. */
  private showPanel(): void {
    if (this.idleTimer !== undefined) {
      clearTimeout(this.idleTimer)
      this.idleTimer = undefined
    }
    if (this.panelShown) return
    this.panelShown = true
    this.overlay.style.transitionDuration = `${FADE_IN_MS}ms`
    this.overlay.style.visibility = 'visible'
    this.overlay.style.opacity = '1'
  }

  /** Start (or restart) the idle countdown that fades the panel out. */
  private schedulePanelHide(): void {
    if (this.idleTimer !== undefined) clearTimeout(this.idleTimer)
    this.idleTimer = setTimeout(() => {
      this.idleTimer = undefined
      if (!this.pointerInZone()) this.hidePanel()
    }, this.options.idleHideMs)
  }

  /** Fade the panel out; it stops receiving pointer events once hidden. */
  private hidePanel(): void {
    if (!this.panelShown) return
    this.panelShown = false
    this.hideSummary()
    this.overlay.style.transitionDuration = `${this.options.fadeOutMs}ms`
    this.overlay.style.visibility = 'hidden'
    this.overlay.style.opacity = '0'
  }

  /** Whether the event target is one of this rail's markers. */
  private isMarker(target: EventTarget | null): boolean {
    return target instanceof Element && target.closest(`.${MARKER_CLASS}`) !== null
      && this.overlay.contains(target.closest(`.${MARKER_CLASS}`)!)
  }

  /** Show the summary when the pointer enters a marker; hide otherwise. */
  private handlePointerEnter(target: EventTarget | null): void {
    if (!this.options.tooltips) {
      this.hideSummary()
      return
    }
    const marker = target instanceof Element ? target.closest<HTMLElement>(`.${MARKER_CLASS}`) : null
    if (marker !== null && this.overlay.contains(marker)) {
      const row = this.rows.find((candidate) => candidate.key === marker.dataset.key)
      if (row !== undefined) this.showSummary(marker, row)
    } else {
      this.hideSummary()
    }
  }

  /** Read the current marked row set from the DOM. */
  private readRows(): readonly RowTarget[] {
    const rows: RowTarget[] = []
    for (const element of Array.from(this.scrollport.querySelectorAll<HTMLElement>(ROW_SELECTOR))) {
      if (element.getClientRects().length === 0) continue // hidden / empty rows
      const kind = element.dataset.chatFlowKind ?? 'unknown'
      if (!shouldMark(kind, this.options.markKinds)) continue
      rows.push({ element, kind, key: element.dataset.chatAnchorKey ?? '' })
    }
    return rows
  }

  /** Recompute marker positions on the next animation frame. */
  schedule(): void {
    if (this.frame !== 0) return
    this.frame = requestAnimationFrame(this.onFrame)
  }

  refresh(): void {
    this.frame = 0
    this.rows = this.readRows()
    // If the hovered conversation is no longer rendered, let the tooltip fade
    // out; otherwise keep it (markers are rebuilt on every refresh, which
    // would otherwise flash the tooltip during scrolling or streaming).
    if (this.hoveredKey !== null && !this.rows.some((row) => row.key === this.hoveredKey)) {
      this.hoveredKey = null
      this.tooltip.hide()
    }
    const scrollport = this.scrollport
    const rect = scrollport.getBoundingClientRect()
    const scrollbarWidth = scrollbarWidthOf(scrollport)
    const panelWidth = this.options.panelWidth
    const margin = this.options.rightMargin
    const panelHeight = panelHeightFor(
      rect.height,
      this.options.panelHeightRatio,
      this.options.minPanelHeight,
      this.options.maxPanelHeight,
    )
    const visible =
      this.options.enabled
      && this.rows.length > 0
      && hasOverflow(scrollport.scrollHeight, scrollport.clientHeight)

    if (!visible) {
      this.panelShown = false
      if (this.idleTimer !== undefined) {
        clearTimeout(this.idleTimer)
        this.idleTimer = undefined
      }
      this.overlay.style.display = 'none'
      return
    }
    this.overlay.style.display = 'block'
    this.overlay.style.width = `${panelWidth}px`
    this.overlay.style.height = `${panelHeight}px`
    this.overlay.style.left = `${rect.right - scrollbarWidth - margin - panelWidth}px`
    this.overlay.style.top = `${rect.top + (rect.height - panelHeight) / 2}px`
    this.overlay.replaceChildren(...this.buildMarkers(panelHeight))
  }

  private buildMarkers(panelHeight: number): HTMLElement[] {
    const nodes: HTMLElement[] = this.rows.map((row, index) => this.buildMarker(row, index, panelHeight))
    if (this.options.showCount && this.rows.length >= 2) {
      const count = document.createElement('span')
      count.className = COUNT_CLASS
      count.textContent = String(this.rows.length)
      nodes.push(count)
    }
    return nodes
  }

  private buildMarker(row: RowTarget, index: number, panelHeight: number): HTMLButtonElement {
    const scrollport = this.scrollport
    const rowTop = row.element.getBoundingClientRect().top - scrollport.getBoundingClientRect().top + scrollport.scrollTop
    const ratio = contentRatio(rowTop, scrollport.scrollHeight)
    const marker = document.createElement('button')
    marker.type = 'button'
    marker.className = MARKER_CLASS
    marker.dataset.kind = row.kind
    marker.dataset.key = row.key
    marker.style.top = `${markerTop(ratio, panelHeight, this.options.markerSize)}px`
    marker.style.height = `${this.options.markerSize}px`
    marker.addEventListener('click', () => {
      const target = scrollTarget(rowTop, this.options.scrollPadding)
      scrollport.scrollTo({ top: target, behavior: 'smooth' })
    })
    return marker
  }

  /** Show the summary tooltip just left of the panel, aligned with the marker. */
  private showSummary(marker: HTMLElement, row: RowTarget): void {
    this.hoveredKey = row.key
    // Anchor horizontally to the panel (which sits left of the scrollbar),
    // not to the marker: markers are rebuilt on every refresh and their
    // measured rect can be transient, which previously put the tooltip over
    // the scrollbar. Vertical alignment falls back to the panel center.
    const panelRect = this.overlay.getBoundingClientRect()
    const markerRect = marker.getBoundingClientRect()
    const anchorTop = markerRect.height > 0
      ? markerRect.top + markerRect.height / 2
      : panelRect.top + panelRect.height / 2
    this.tooltip.show({
      header: kindLabel(row.kind, this.language),
      body: extractSummary(row.element, this.options.summaryMaxChars),
    }, panelRect.left, anchorTop)
  }

  /** Fade the summary tooltip out. */
  private hideSummary(): void {
    this.hoveredKey = null
    this.tooltip.hide()
  }

  /** Remove the panel, the tooltip, and all listeners. */
  dispose(): void {
    if (this.frame !== 0) cancelAnimationFrame(this.frame)
    this.frame = 0
    if (this.idleTimer !== undefined) clearTimeout(this.idleTimer)
    this.idleTimer = undefined
    this.scrollport.removeEventListener('scroll', this.onScroll)
    window.removeEventListener('resize', this.onResize)
    document.removeEventListener('mouseover', this.onMouseOver)
    document.removeEventListener('mousemove', this.onMouseMove)
    document.removeEventListener('mousedown', this.onMouseDown)
    document.removeEventListener('focusin', this.onFocusIn)
    document.removeEventListener('focusout', this.onFocusOut)
    this.observer.disconnect()
    this.mutation.disconnect()
    this.overlay.remove()
    this.tooltip.dispose()
  }
}
