/** The hover tooltip that shows a conversation summary next to a marker. */

export const TOOLTIP_CLASS = 'dsh-ci-tooltip'
export const TOOLTIP_HEADER_CLASS = 'dsh-ci-tooltip-header'
export const TOOLTIP_BODY_CLASS = 'dsh-ci-tooltip-body'

/** Fade-out duration (ms) when the pointer leaves a marker. */
export const FADE_OUT_MS = 300
/** Fade-in duration (ms) when a marker is hovered. */
export const FADE_IN_MS = 120

export interface TooltipContent {
  readonly header: string
  readonly body: string
}

/**
 * A single reusable tooltip element, appended to <body>, hidden until a
 * marker is hovered. It fades in quickly on show and fades out slowly on
 * hide; a show during a pending fade-out cancels the hide. Positioned left
 * of the marker, flipping to the right when there is no room, and clamped
 * into the viewport.
 */
export class Tooltip {
  readonly element: HTMLDivElement
  private readonly header: HTMLSpanElement
  private readonly body: HTMLSpanElement
  private hideTimer: ReturnType<typeof setTimeout> | undefined
  private hidden = true

  constructor() {
    this.element = document.createElement('div')
    this.element.className = TOOLTIP_CLASS
    this.element.style.display = 'none'
    this.header = document.createElement('span')
    this.header.className = TOOLTIP_HEADER_CLASS
    this.body = document.createElement('span')
    this.body.className = TOOLTIP_BODY_CLASS
    this.element.append(this.header, this.body)
    document.body.appendChild(this.element)
  }

  /**
   * Show the tooltip just to the left of the panel, vertically centered on
   * the anchor point, clamped into the viewport. It never renders over the
   * scrollbar: when there is not enough room the left edge is clamped into
   * the viewport instead of flipping to the marker's right side.
   */
  show(content: TooltipContent, anchorLeft: number, anchorTop: number): void {
    if (this.hideTimer !== undefined) {
      clearTimeout(this.hideTimer)
      this.hideTimer = undefined
    }
    this.hidden = false
    this.header.textContent = content.header
    this.body.textContent = content.body
    this.body.style.display = content.body.length === 0 ? 'none' : 'block'
    this.element.style.transitionDuration = `${FADE_IN_MS}ms`
    this.element.style.display = 'block'
    // Force layout so offsetWidth/Height reflect the content, then fade in.
    void this.element.offsetWidth
    requestAnimationFrame(() => {
      if (!this.hidden) this.element.style.opacity = '1'
    })
    const width = this.element.offsetWidth
    const height = this.element.offsetHeight
    const gap = 10
    const margin = 8
    const left = Math.max(margin, anchorLeft - gap - width)
    const top = Math.min(
      Math.max(margin, anchorTop - height / 2),
      Math.max(margin, window.innerHeight - height - margin),
    )
    this.element.style.left = `${left}px`
    this.element.style.top = `${top}px`
  }

  /** Fade the tooltip out; it is removed from view when the transition ends. */
  hide(): void {
    if (this.hidden) return
    this.hidden = true
    this.element.style.transitionDuration = `${FADE_OUT_MS}ms`
    this.element.style.opacity = '0'
    if (this.hideTimer !== undefined) clearTimeout(this.hideTimer)
    this.hideTimer = setTimeout(() => {
      this.hideTimer = undefined
      if (this.hidden) this.element.style.display = 'none'
    }, FADE_OUT_MS)
  }

  /** Remove the tooltip from the DOM immediately, cancelling any fade. */
  dispose(): void {
    if (this.hideTimer !== undefined) clearTimeout(this.hideTimer)
    this.hideTimer = undefined
    this.element.remove()
  }
}
