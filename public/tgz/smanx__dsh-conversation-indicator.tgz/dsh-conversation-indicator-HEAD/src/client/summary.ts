/** Summary extraction from a rendered conversation row. */

const CHROME_SELECTOR = [
  'button',
  'input',
  'textarea',
  'select',
  'option',
  '[role="button"]',
  '[role="toolbar"]',
  '[role="menu"]',
  '[role="menuitem"]',
  '[role="tab"]',
  '[aria-hidden="true"]',
  'svg',
  'style',
  'script',
  'template',
  'noscript',
].join(',')

/** Collapse all whitespace runs into single spaces and trim. */
export function normalizeText(text: string): string {
  return text.replace(/\s+/g, ' ').trim()
}

/** Truncate to at most maxChars characters, ending with an ellipsis. */
export function truncate(text: string, maxChars: number): string {
  if (text.length <= maxChars) return text
  const cut = text.slice(0, Math.max(0, maxChars - 1)).trimEnd()
  return `${cut}…`
}

/**
 * Extract a readable summary of a row's content, stripping UI chrome
 * (buttons, icons, menus) without depending on the app's hashed class names.
 * Returns '' when nothing readable remains.
 */
export function extractSummary(row: HTMLElement, maxChars: number): string {
  const clone = row.cloneNode(true) as HTMLElement
  for (const element of Array.from(clone.querySelectorAll<HTMLElement>(CHROME_SELECTOR))) {
    element.remove()
  }
  const text = normalizeText(clone.textContent ?? '')
  if (text.length === 0) return ''
  return truncate(text, maxChars)
}
