/** Pure geometry helpers shared by the rail and its tests. */

/** Whether the scrollport has content overflow worth marking. */
export function hasOverflow(scrollHeight: number, clientHeight: number): boolean {
  return scrollHeight > clientHeight + 1
}

/** Fraction of the scroll content above a row's top edge, clamped to [0, 1]. */
export function contentRatio(contentTop: number, scrollHeight: number): number {
  if (scrollHeight <= 0) return 0
  return Math.min(1, Math.max(0, contentTop / scrollHeight))
}

/** Marker top offset inside the rail for a content ratio and rail height. */
export function markerTop(ratio: number, railHeight: number, markerSize: number): number {
  if (railHeight <= 0) return 0
  const max = Math.max(0, railHeight - markerSize)
  return Math.min(max, Math.max(0, ratio * railHeight))
}

/** Panel height for a viewport height: a fraction of it, clamped to [min, max]. */
export function panelHeightFor(viewportHeight: number, ratio: number, min: number, max: number): number {
  if (viewportHeight <= 0) return 0
  return Math.min(max, Math.max(min, viewportHeight * ratio))
}

/** Scroll target that brings a row's top near the top of the scrollport. */
export function scrollTarget(contentTop: number, padding: number): number {
  return Math.max(0, contentTop - padding)
}
