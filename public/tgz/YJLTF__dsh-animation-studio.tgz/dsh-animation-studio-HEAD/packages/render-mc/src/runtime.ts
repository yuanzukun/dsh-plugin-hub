/**
 * Motion Canvas 的默认运行时：起 vite dev server + 无头浏览器 + 点 Render。
 *
 * 为什么是这个形状——Motion Canvas 3.17 **没有 CLI**：官方只在编辑器 UI 里提供
 * RENDER 按钮，落盘机制是浏览器把每帧 base64 通过 dev server 的 WebSocket 发回来
 * （见 vite-plugin 的 exporterPlugin）。所以要自动渲染，只能把编辑器开起来再按按钮。
 *
 * 默认 headless（没有窗口，渲染不打扰用户）：2026-09 实测 Edge 152 的新 headless
 * 配合 SwiftShader 能拿到 WebGL 上下文、完整出片。旧结论「纯 headless 拿不到 GL、
 * 必须有头」基于旧版 headless，已过时；headless:false 保留作调试后门，
 * 「有头 + Linux 无显示时上 Xvfb」的旧逻辑只为它服务。
 */

import { exec as execCallback, spawn } from 'node:child_process'
import type { ChildProcess } from 'node:child_process'
import { copyFileSync, existsSync, mkdirSync, readdirSync, realpathSync, statSync, symlinkSync, writeFileSync } from 'node:fs'
import { basename, dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'
import { promisify } from 'node:util'

import { createRequire } from 'node:module'

import puppeteer from 'puppeteer-core'
import type { Browser } from 'puppeteer-core'
import { createServer } from 'vite'
import type { ViteDevServer } from 'vite'

import { collectFrames, resetDir } from './adapter.ts'
import type { MotionCanvasRuntime } from './adapter.ts'
import type { RenderDiagnostics } from './contract.ts'

const exec = promisify(execCallback)

export interface DefaultRuntimeOptions {
  /**
   * vite dev server 端口。缺省 0 = 随机可用端口——渲染器已有串行闸，但固定
   * 端口仍会被同机的其他进程占走，EADDRINUSE 的裸报错对模型不可读。
   * 需要钉端口（如防火墙白名单）时显式传入。
   */
  port?: number
  /** 输出目录，相对 workDir。 */
  outputDir?: string
  /** Chromium/Chrome 可执行文件路径；省略时依次查 CHROME_PATH 与各平台常见位置。 */
  chromiumPath?: string
  /**
   * 无头渲染（默认 true）：没有窗口，进度只经 onProgress 上报。
   * 显式传 false 走有头模式用于调试——窗口标题会显示渲染状态条，
   * Linux 无显示时需要 Xvfb（旧方案，部分环境 headless 拿不到 GL 时兜底）。
   */
  headless?: boolean
  /** Xvfb 显示号（仅 headless:false 且 Linux 无 DISPLAY 时使用）。 */
  display?: string
  /** 单次渲染的墙钟上限，默认 30 分钟。 */
  timeoutMs?: number
}

const DEFAULT_TIMEOUT = 30 * 60 * 1000

/* ------------------------------------------------------------- 环境探测 */

/**
 * 按 CHROME_PATH → 平台常见位置 的顺序找出可用的浏览器。
 * Windows 上没有全局 chromium 命令，Chrome/Edge 的安装路径就是默认值。
 */
function findChromium(explicit?: string): string | undefined {
  const candidates = explicit
    ? [explicit]
    : [
        process.env.CHROME_PATH,
        ...(process.platform === 'win32'
          ? [
              join(process.env['PROGRAMFILES'] ?? 'C:\\Program Files', 'Google/Chrome/Application/chrome.exe'),
              join(process.env['PROGRAMFILES(X86)'] ?? 'C:\\Program Files (x86)', 'Google/Chrome/Application/chrome.exe'),
              join(process.env['LOCALAPPDATA'] ?? '', 'Google/Chrome/Application/chrome.exe'),
              // 64 位 Windows 上 Edge 默认装在 Program Files (x86)，两个都要查
              join(process.env['PROGRAMFILES'] ?? 'C:\\Program Files', 'Microsoft/Edge/Application/msedge.exe'),
              join(process.env['PROGRAMFILES(X86)'] ?? 'C:\\Program Files (x86)', 'Microsoft/Edge/Application/msedge.exe'),
            ]
          : process.platform === 'darwin'
            ? [
                '/Applications/Chromium.app/Contents/MacOS/Chromium',
                '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
              ]
            : ['/usr/bin/chromium', '/usr/bin/chromium-browser', '/usr/bin/google-chrome']),
      ].filter((p): p is string => typeof p === 'string' && p.length > 0)
  return candidates.find(p => existsSync(p))
}

/**
 * 依赖自检。
 *
 * 这一层的价值在于**报错要可操作**：说「渲染失败」没用，要说「缺 ffmpeg，装它」。
 * 依赖清单不是猜的，是踩出来的：Xvfb 缺失 = 拿不到 GL；字体缺失 = 中文变豆腐块。
 */
export async function probeEnvironment(options: { chromiumPath?: string; headless?: boolean } = {}): Promise<RenderDiagnostics> {
  const issues: string[] = []
  const details: Record<string, string> = {}

  const chromium = findChromium(options.chromiumPath)
  if (chromium) details['chromium'] = chromium
  else {
    issues.push(
      process.platform === 'win32'
        ? '未找到 Chrome/Edge：请安装，或用环境变量 CHROME_PATH 指向浏览器可执行文件'
        : '未找到 Chromium：可用 CHROME_PATH 指定（apt install chromium）',
    )
  }

  const ffmpeg = await which('ffmpeg')
  if (ffmpeg) details['ffmpeg'] = ffmpeg
  else issues.push('未找到 ffmpeg：帧合成 MP4 需要它（apt install ffmpeg / winget install ffmpeg）')

  // Xvfb 只在有头模式下才是硬依赖；默认 headless 不需要任何显示服务器
  if (!options.headless && process.platform === 'linux' && !process.env.DISPLAY) {
    const xvfb = await which('Xvfb')
    if (xvfb) details['Xvfb'] = xvfb
    else issues.push('未找到 Xvfb：有头模式下无显示的 Linux 需要虚拟显示才能拿到 WebGL 上下文（apt install xvfb）')
  }

  // 中文字体：缺了不会报错，只会渲成方块，所以必须主动查
  const cjk = await probeCjkFonts()
  if (cjk) details['cjkFonts'] = cjk
  else issues.push('未找到中文字体：中文会渲成豆腐块（apt install fonts-noto-cjk）')

  return { renderer: 'motion-canvas', ok: issues.length === 0, issues, details }
}

/** 找一个能覆盖中文的字体名，供诊断报告引用；找不到返回 undefined。 */
async function probeCjkFonts(): Promise<string | undefined> {
  if (process.platform === 'win32') {
    for (const f of ['msyh.ttc', 'simsun.ttc', 'simhei.ttf']) {
      if (existsSync(join(process.env['WINDIR'] ?? 'C:\\Windows', 'Fonts', f))) return f
    }
    return undefined
  }
  const fonts = await execQuiet('fc-list :lang=zh').catch(() => '')
  const lines = fonts.split('\n').filter(Boolean)
  if (lines.length === 0) return undefined
  const sans = lines.find(l => l.includes('Noto Sans CJK'))
  return sans ? (sans.split(':')[1]?.trim() ?? sans) : `${lines.length} 个`
}

async function which(bin: string): Promise<string | undefined> {
  // cmd.exe 没有 command -v，等价物是 where
  const cmd = process.platform === 'win32' ? `where ${bin}` : `command -v ${bin}`
  const out = await execQuiet(cmd).catch(() => '')
  return out.trim().split(/\r?\n/)[0] || undefined
}

/* ------------------------------------------------------- work 目录模块解析 */

/**
 * 让 work 目录能解析到渲染依赖。
 *
 * work 目录（`<outputDir>/work`）通常悬在用户的输出目录下，往上找不到任何
 * node_modules；而 vite 的虚拟编辑器模块会 import `@motion-canvas/ui`、生成的
 * 场景会 import `@motion-canvas/2d`——解析不到就是 500，浏览器里只剩一个
 * Internal Server Error 页，渲染永远 0 帧。这里把含 Motion Canvas 的
 * node_modules 以 junction/软链形式钉进 work 目录，一次解决全部裸导入。
 *
 * 从本模块的编译产物位置向上找（bundle 在 <插件根>/lib/ 下），能同时覆盖
 * 源码仓库、pnpm profile 安装、离线 tgz 三种布局。
 */
export function ensureWorkDirModules(workDir: string): void {
  const target = findModulesDir()
  if (!target) return
  const link = join(workDir, 'node_modules')
  if (existsSync(link)) return
  mkdirSync(workDir, { recursive: true })
  try {
    // Windows 上 junction 不需要管理员权限；其他平台用 dir 软链
    symlinkSync(target, link, process.platform === 'win32' ? 'junction' : 'dir')
  } catch {
    // 建不出来就退回 CWD 的 node_modules 解析链——样例工程等场景本来就能解析
  }
}

let cachedModulesDir: string | null | undefined

function findModulesDir(): string | null {
  if (cachedModulesDir !== undefined) return cachedModulesDir
  cachedModulesDir = null
  try {
    // 先用 require.resolve 确认 @motion-canvas/core 真的可解析，再定位它所在的
    // node_modules——只找目录不验证包，会把 junction 钉到一个空壳上
    createRequire(import.meta.url).resolve('@motion-canvas/core')
  } catch {
    return cachedModulesDir
  }
  let dir = dirname(fileURLToPath(import.meta.url))
  for (let i = 0; i < 8; i++) {
    const candidate = join(dir, 'node_modules')
    if (existsSync(join(candidate, '@motion-canvas', 'core'))) {
      cachedModulesDir = candidate
      return cachedModulesDir
    }
    const parent = dirname(dir)
    if (parent === dir) break
    dir = parent
  }
  return cachedModulesDir
}

/**
 * 找到包实际所在的 node_modules 目录（pnpm 下是 .pnpm 深处的真实路径）。
 * vite 的 fs.allow 按「浏览器的真实请求路径」判定，符号链接不算数，
 * 所以白名单必须基于 realpath 而不是链接位置。
 */
function containingModulesDir(pkgName: string): string | null {
  try {
    const entry = createRequire(import.meta.url).resolve(pkgName)
    let dir = dirname(realpathSync(entry))
    while (true) {
      if (basename(dir) === 'node_modules') return dir
      const parent = dirname(dir)
      if (parent === dir) return null
      dir = parent
    }
  } catch {
    return null
  }
}

async function execQuiet(cmd: string): Promise<string> {
  const { stdout } = await exec(cmd, { encoding: 'utf8' })
  return String(stdout ?? '')
}

/* ------------------------------------------------------------- 默认运行时 */

/** 空闲回收阈值：最后一次渲染结束后，常驻实例存活这么久就整套关停（§3.2）。 */
const IDLE_RECLAIM_MS = 10 * 60 * 1000

/**
 * 进程退出时的兜底回收：常驻浏览器是宿主进程的子进程，宿主自然退
 * 出（事件循环排空）时若不处理会留僵尸。beforeExit 里走优雅关闭；
 * exit 事件是同步的最后机会，直接杀浏览器根进程，尽力而为
 * （SIGKILL / 断电救不了，正常插件卸载走的是 dispose 的优雅路径）。
 */
const exitHooks = new WeakMap<object, unknown>()

function installExitHooks(owner: object, graceful: () => Promise<void>, killSync: () => void): void {
  if (exitHooks.has(owner)) return
  exitHooks.set(owner, true)
  process.once('beforeExit', () => { void graceful() })
  process.once('exit', killSync)
}

export function createDefaultRuntime(options: DefaultRuntimeOptions = {}): MotionCanvasRuntime {
  const port = options.port ?? 0
  const display = options.display ?? ':99'
  const chromiumPath = findChromium(options.chromiumPath)
  const outputDir = options.outputDir ?? 'output'
  const timeoutMs = options.timeoutMs ?? DEFAULT_TIMEOUT
  const headless = options.headless ?? true

  /* ------------ 常驻实例：浏览器进程级单例 + vite dev server 按 spec 一份（§3.2） ------------- */

  interface EditorSession {
    server: ViteDevServer
    port: number
  }

  /** workDir → vite 会话。存 Promise 是为了让并发创建天然去重（串行闸下罕见，但便宜）。 */
  const sessions = new Map<string, Promise<EditorSession>>()
  let browserPromise: Promise<Browser> | undefined
  let browserProc: ChildProcess | undefined
  let xvfb: ChildProcess | undefined
  let idleTimer: ReturnType<typeof setTimeout> | undefined
  /** 当前渲染是否已进入等帧阶段：只有「起手阶段」的失败才值得整套重建重试。 */
  let framesStarted = false

  const linuxNoDisplay = !headless && process.platform === 'linux' && !process.env.DISPLAY

  async function launchBrowser(): Promise<Browser> {
    if (chromiumPath === undefined) {
      throw new Error('未找到可用的 Chrome/Chromium：设置 CHROME_PATH 环境变量或安装浏览器后重试')
    }
    // Xvfb 只服务于「有头调试 + Linux 无显示」的组合；常驻模式下随浏览器同生命周期
    if (linuxNoDisplay && !xvfb) {
      xvfb = spawn('Xvfb', [display, '-screen', '0', '1920x1080x24'], { stdio: 'ignore' })
      await new Promise(r => setTimeout(r, 2000))
    }
    const browser = await puppeteer.launch({
      executablePath: chromiumPath,
      headless,
      env: linuxNoDisplay ? { ...process.env, DISPLAY: display } : process.env,
      args: [
        '--no-sandbox',
        '--disable-setuid-sandbox',
        '--disable-dev-shm-usage',
        '--use-gl=angle',
        '--use-angle=swiftshader',
        '--enable-unsafe-swiftshader',
        // 编辑器靠 rAF 驱动渲染：窗口被遮挡/最小化时 Chromium 会节流 rAF，
        // 帧就永远出不来（实测 Windows 上浏览器窗口可能以最小化状态启动）
        '--disable-backgrounding-occluded-windows',
        '--disable-renderer-backgrounding',
        '--disable-background-timer-throttling',
        // 不要传 --window-position / --window-size：Edge 152 起对这两个开关
        // 有离谱缺陷——窗口按指定几何创建了却永不显示（Win32 visible=False，
        // 任务栏也没有），渲染照常出帧、标题状态条却永远看不见；CDP
        // setWindowBounds 也救不回来。默认窗口尺寸对编辑器足够，出帧分辨率
        // 由 project.meta × resolutionScale 决定，与窗口大小无关。
      ],
    })
    browserProc = browser.process() ?? undefined
    return browser
  }

  /** 浏览器进程级单例：存活检查失败（崩溃 / 被外部杀掉）就丢弃重建。 */
  async function ensureBrowser(): Promise<Browser> {
    if (browserPromise) {
      const browser = await browserPromise
      if (browser.connected) return browser
      browserPromise = undefined
    }
    browserPromise = launchBrowser()
    return browserPromise
  }

  async function createEditorServer(workDir: string): Promise<EditorSession> {
    // project 与 output 都必须写绝对路径：MC 的 vite-plugin 会把它们原样
    // 塞进虚拟模块/导出器配置里按相对路径处理，而虚拟模块的相对导入与
    // exporter 的落盘目录都按 process.cwd() 解析——dsh 的 cwd 是启动目录
    // 而不是 workDir，相对路径在这里要么 500 要么把帧写到天南海北。
    // 配置用 .mts 后缀强制 Vite 走 ESM 链路加载：workDir 没有 "type": "module"
    // 的 package.json，.ts 配置会被打包成 CJS require('vite')，每次渲染都刷
    // 一条 CJS 弃用告警（真机日志回归发现）。配置内容只取决于 workDir 与
    // outputDir，所以跟着会话写一次，复用期间不再重写。
    const configPath = join(workDir, 'vite.config.mts')
    mkdirSync(workDir, { recursive: true })
    const uiModulesDir = containingModulesDir('@motion-canvas/ui')
    writeFileSync(
      configPath,
      viteConfigSource(
        join(workDir, 'project.tsx').replace(/\\/g, '/'),
        join(workDir, outputDir).replace(/\\/g, '/'),
        [workDir, ...(uiModulesDir ? [uiModulesDir, dirname(uiModulesDir)] : [])],
      ),
      'utf8',
    )

    const server = await createServer({
      // 场景源码都物化在 workDir 下，vite 的 root 必须钉在这里，
      // 否则 project: './project.tsx' 会相对进程 cwd 解析而落空
      root: workDir,
      configFile: configPath,
      // 依赖预打包缓存必须钉在 workDir 自己身上：workDir/node_modules 是指向
      // 插件真实 node_modules 的 junction，默认 cacheDir 会落到共享缓存里，
      // 与其他项目/其他 spec 的优化产物串台，跑出双 core 实例的经典错乱
      cacheDir: join(workDir, '.vite'),
      server: { port, strictPort: true },
      logLevel: 'warn',
    })
    await server.listen()

    // port 0 = 由系统分派随机可用端口：编辑器页面要按实际端口访问
    const address = server.httpServer?.address()
    const listenPort = typeof address === 'object' && address !== null ? address.port : port
    return { server, port: listenPort }
  }

  /**
   * 复用前的健康检查：端口还在监听 + HTTP 真能应答。
   * 只查 listening 不够——僵死的 server 这一位可能仍是 true，一发真实请求才算数。
   */
  async function serverHealthy(session: EditorSession): Promise<boolean> {
    if (!session.server.httpServer?.listening) return false
    try {
      const res = await fetch(`http://localhost:${session.port}/`, { signal: AbortSignal.timeout(3000) })
      return res.ok
    } catch {
      return false
    }
  }

  async function ensureEditorServer(workDir: string): Promise<EditorSession> {
    const existing = sessions.get(workDir)
    if (existing) {
      const session = await existing
      if (await serverHealthy(session)) return session
      // 僵死：丢弃重建。close 的异常吞掉——反正已经不打算用它了
      sessions.delete(workDir)
      await session.server.close().catch(() => {})
    }
    const creating = createEditorServer(workDir)
    sessions.set(workDir, creating)
    return creating
  }

  /** 整套关停常驻实例：所有 spec 的 vite 会话 + 浏览器 + Xvfb。幂等。 */
  async function disposeInstances(): Promise<void> {
    if (idleTimer) {
      clearTimeout(idleTimer)
      idleTimer = undefined
    }
    const closing = [...sessions.values()].map(p => p.then(s => s.server.close()).catch(() => {}))
    sessions.clear()
    const bp = browserPromise
    browserPromise = undefined
    if (bp) await bp.then(b => b.close()).catch(() => {})
    await Promise.all(closing)
    xvfb?.kill()
    xvfb = undefined
  }

  /** 渲染结束后重新武装空闲回收；unref 保证常驻实例不拖住进程退出。 */
  function armIdleReclaim(): void {
    if (idleTimer) clearTimeout(idleTimer)
    idleTimer = setTimeout(() => { void disposeInstances() }, IDLE_RECLAIM_MS)
    idleTimer.unref?.()
  }

  installExitHooks(
    sessions,
    () => disposeInstances(),
    () => {
      try { browserProc?.kill('SIGKILL') } catch { /* 已经不在了 */ }
      try { xvfb?.kill('SIGKILL') } catch { /* 已经不在了 */ }
    },
  )

  /* ------------------------------------------------------------- 单次渲染 */

  const renderOnce = async (args: {
    workDir: string
    fps: number
    expectedFrames: number
    signal: AbortSignal
    onProgress?: (done: number, total: number) => void
  }): Promise<{ frameDir: string; frameCount: number }> => {
    framesStarted = false
    const rootDir = join(args.workDir, outputDir)

    const session = await ensureEditorServer(args.workDir)
    const browser = await ensureBrowser()
    // 每次渲染开新页、渲完关页：浏览器实例跨渲染复用，页面状态绝不跨渲染
    // 带入（编辑器是纯页面状态， goto 即全新）。启动时的首个空白页留给
    // 浏览器当「保活目标」，永不关闭。
    const page = await browser.newPage()
    try {
      await page.setViewport({ width: 1600, height: 900 })
      await page.bringToFront()

      // 有头调试时窗口标题就是渲染状态条；默认 headless 没有窗口，进度只走
      // onProgress。标题更新失败绝不影响渲染本身
      let lastTitleAt = 0
      const setTitle = (text: string): void => {
        // 包的 TS lib 无 DOM，document 经 globalThis 转型；函数体跑在浏览器里
        void page.evaluate(t => {
          (globalThis as unknown as { document: { title: string } }).document.title = t
        }, text).catch(() => {})
      }
      const titleProgress = (done: number, total: number): void => {
        args.onProgress?.(done, total)
        const now = Date.now()
        if (now - lastTitleAt < 500) return // 进度回调每帧都来，标题刷新限频
        lastTitleAt = now
        const pct = total > 0 ? Math.round((done / total) * 100) : 0
        setTitle(`视频渲染中 ${done}/${total} 帧（${pct}%）…`)
      }

      setTitle('动画渲染启动中：正在加载 Motion Canvas 编辑器…')
      const loadStarted = Date.now()
      await page.goto(`http://localhost:${session.port}/`, { waitUntil: 'networkidle2', timeout: 120_000 })
      const gotoMs = Date.now() - loadStarted
      setTitle('编辑器加载中…')
      await page.waitForSelector('canvas', { timeout: 60_000 })
      const canvasMs = Date.now() - loadStarted - gotoMs

      // 动态等待（0.4.0 规划 §3.1）：canvas 出现后轮询「Render 按钮存在且
      // enabled」，就绪即走。轮询上限 30 秒兜底——按钮比预期晚到时多等而
      // 不是盲点失败；计时落盘 workDir/editor-timing.json
      const buttonStarted = Date.now()
      let buttonReady = false
      while (Date.now() - buttonStarted < 30_000) {
        buttonReady = await page.$$eval(
          'button',
          // 回调跑在浏览器页面里；TS lib 无 DOM，disabled 经 unknown 转型读取
          buttons => buttons.some(b => (b.textContent ?? '').trim() === 'Render' && !(b as unknown as { disabled?: boolean }).disabled),
        )
        if (buttonReady) break
        await new Promise(r => setTimeout(r, 100))
      }
      const buttonReadyMs = Date.now() - buttonStarted
      if (!buttonReady) {
        // 30 秒兜底到顶还没见按钮：多等只会拖长失败路径，直接给可读报错
        throw new Error('编辑器 30 秒内没有出现可用的 Render 按钮——编辑器加载可能卡住了。'
          + '请重试；若反复出现，检查 <workDir> 下 vite 的报错或用 headless:false 肉眼排查。')
      }
      // O10 实测（0.4.0 规划 §3.1）：按钮在 canvas 后 14ms 即可点，旧版固定
      // 4 秒等待是 99.6% 的纯余量，已按数据收紧。留一拍短稳定余量兜「按钮
      // 先于编辑器内部状态就绪」的极端时序；真机若复现 0 帧失败再回调此值。
      const settleMs = 300
      await new Promise(r => setTimeout(r, settleMs))

      // 自定义字体就绪（0.4.0 规划 §4.2）：canvas 的 fillText 用文档字体集，
      // @font-face 未就绪时先渲的字形退回兜底字体（豆腐块/宋体）。canvas 用法
      // 不会触发 @font-face 懒加载，必须 FontFace.load() 显式触发后等 ready。
      // 无自定义字体时约 1ms；整体 5 秒封顶——字体加载慢不该拖死渲染。
      const fontsStarted = Date.now()
      await Promise.race([
        page.evaluate(async () => {
          const doc = globalThis as unknown as {
            document: { fonts?: { ready: Promise<unknown>; forEach: (cb: (face: { load: () => Promise<unknown> }) => void) => void } }
          }
          const fonts = doc.document.fonts
          if (!fonts) return
          fonts.forEach(face => { void face.load().catch(() => {}) })
          await fonts.ready
        }),
        new Promise(r => setTimeout(r, 5000)),
      ])
      const fontsMs = Date.now() - fontsStarted

      try {
        writeFileSync(
          join(args.workDir, 'editor-timing.json'),
          JSON.stringify({
            at: new Date().toISOString(),
            gotoMs,
            canvasMs,
            buttonReadyMs,
            settleMs,
            fontsMs,
            editorLoadTotalMs: gotoMs + canvasMs + buttonReadyMs + settleMs + fontsMs,
          }, null, 2),
        )
      } catch { /* 测量失败绝不影响渲染 */ }

      // 按文本找按钮：MC 的 class 名带构建哈希，不能依赖。
      // 用 $$eval 而不是 evaluateHandle —— 后者返回的 ElementHandle<Node> 没法直接 click。
      const clicked = await page.$$eval('button', buttons => {
        const target = buttons.find(b => (b.textContent ?? '').trim() === 'Render')
        if (!target) return false
        target.click()
        return true
      })
      if (!clicked) throw new Error('找不到 Render 按钮——Motion Canvas 版本可能变了，请重新确认编辑器 UI')

      setTitle('编辑器就绪，开始渲染…')
      // 注意顺序：先等帧、再定位帧目录。exporter 的输出子目录是在首帧落盘时
      // 才创建的，点完 Render 立刻找目录只会拿到空的 output 根目录——而等待
      // 用的 collectFrames 会递归扫一层子目录，帧再多也救不回早已定错的目录。
      framesStarted = true
      const count = await waitForFrames(rootDir, args.expectedFrames, args.fps, timeoutMs, args.signal, titleProgress)
      setTitle(`帧渲染完成（${count} 帧），正在关闭页面…`)
      return { frameDir: findImageDir(rootDir), frameCount: count }
    } finally {
      await page.close().catch(() => {})
      armIdleReclaim()
    }
  }

  return {
    async probe() {
      return probeEnvironment({ chromiumPath: options.chromiumPath, headless })
    },

    async dispose() {
      await disposeInstances()
    },

    async materialize(files, workDir) {
      ensureWorkDirModules(workDir)
      for (const file of files) {
        const target = join(workDir, file.path)
        mkdirSync(dirname(target), { recursive: true })
        writeFileSync(target, file.content, 'utf8')
      }
    },

    async renderProject(args) {
      if (args.signal.aborted) throw new Error('渲染已取消')
      const rootDir = join(args.workDir, outputDir)
      // 清掉上一轮产物：旧帧混进新片是最难发现的一类错误。只清 output——
      // .vite 预打包缓存与段缓存都要跨渲染存活（§3.3 / §3.4）
      resetDir(rootDir)
      // 渲染进行中绝不被空闲回收；结束后由 renderOnce 的 finally 重新武装
      if (idleTimer) {
        clearTimeout(idleTimer)
        idleTimer = undefined
      }
      const wasReused = sessions.has(args.workDir)

      try {
        return await renderOnce(args)
      } catch (err) {
        // 复用实例的「起手阶段」失败（起服务/开页/goto/找按钮）：实例可能已
        // 僵死——整套丢弃，冷启动重试一次。等帧阶段（framesStarted）的失败
        // 是内容/环境问题，重试同样的渲染只会再花一遍时间，原样上抛。
        if (wasReused && !framesStarted && !args.signal.aborted) {
          await disposeInstances()
          return renderOnce(args)
        }
        throw err
      }
    },
  }
}

/**
 * 等帧写满。
 *
 * 停滞有四种结局，不能一概而论：
 * - 写满 expected 后稳定 → 正常完成（多出的缓冲帧由 ffmpeg -frames:v 截掉）；
 * - **尾部静止**：最后一幕动画结束、只剩 waitFor 静止收尾时，MC 编辑器会提前
 *   约 0.5 秒停止出帧（实测每次渲染必现：462 帧的片子稳定差 10~17 帧）。
 *   缺的帧与最后一帧画面相同，只要帧列从 000000 起连续、缺口不超过 1 秒，
 *   就复制最后一帧补齐——即便偶尔误判，代价也只是片尾多定格 ≤1 秒，
 *   远好于让每次带静止收尾的渲染都失败；
 * - 其余停滞 = 真中断：渲染出的是一条短了几秒的残片，报错让上层重试，
 *   比静默交片更负责任；
 * - 墙钟超时 = 同样报错，绝不静默返回残片。
 */
export async function waitForFrames(
  dir: string,
  expected: number,
  fps: number,
  timeoutMs: number,
  signal: AbortSignal,
  onProgress?: (done: number, total: number) => void,
): Promise<number> {
  const started = Date.now()
  let last = -1
  let stableSince = Date.now()
  // MC 提前停帧约 0.5 秒，按 1 秒留一倍余量；fps 很低时至少容 12 帧
  const tailTolerance = Math.max(12, Math.ceil(fps))
  while (Date.now() - started < timeoutMs) {
    if (signal.aborted) throw new Error('渲染已取消')
    const n = safeCount(dir)
    if (n !== last) {
      last = n
      stableSince = Date.now()
      onProgress?.(n, expected)
    }
    if (n >= expected && Date.now() - stableSince > 3000) break
    // 0 帧停滞：编辑器没起来（依赖解析失败→页面 500）或窗口被最小化（rAF 被
    // 节流）。不快速失败的话，一次失败渲染要挂满整个超时才返回。
    if (n === 0 && Date.now() - stableSince > 90_000) {
      throw new Error(
        '渲染器 90 秒没有产出任何帧。常见原因：浏览器窗口被最小化或关闭了；'
        + 'Motion Canvas 编辑器加载失败（检查 <workDir> 下 vite 的报错）。恢复窗口或修复后重试。',
      )
    }
    // 帧断流：先试尾部静止补偿，补不上才是真中断
    if (n > 0 && Date.now() - stableSince > 15_000) {
      if (n >= expected) break
      if (expected - n <= tailTolerance && fillStaticTail(dir, expected)) {
        onProgress?.(expected, expected)
        break
      }
      throw new Error(`帧产出在 ${n}/${expected} 处停滞超过 15 秒，渲染中断。请重试；若反复出现，降低分辨率或缩短时长。`)
    }
    await new Promise(r => setTimeout(r, 800))
  }
  const final = safeCount(dir)
  // 循环条件耗尽 = 墙钟超时：不带这个检查，超时会静默返回一条缺了几十秒的残片
  if (final < expected) {
    throw new Error(
      `渲染超时：${Math.round(timeoutMs / 60_000)} 分钟只产出 ${final}/${expected} 帧。`
      + '请重试；若反复出现，降低分辨率或缩短时长。',
    )
  }
  return final
}

/**
 * 尾部静止补偿：把最后一帧复制到缺失的帧号上，补齐到 expected。
 *
 * 只有帧列从 000000 起完全连续才允许补——ffmpeg 的 %06d.png 图像序列遇到
 * 第一个空洞就会停，不连续的帧列补了也出不了完整片子，那种情况必须报错。
 */
function fillStaticTail(dir: string, expected: number): boolean {
  const frames = collectFrames(dir)
  if (frames.length === 0 || frames.length >= expected) return false
  for (let i = 0; i < frames.length; i++) {
    if (frameIndex(frames[i]) !== i) return false
  }
  const lastFrame = frames[frames.length - 1]
  const dot = lastFrame.lastIndexOf('.')
  const ext = dot >= 0 ? lastFrame.slice(dot) : '.png'
  for (let i = frames.length; i < expected; i++) {
    copyFileSync(lastFrame, join(dirname(lastFrame), `${String(i).padStart(6, '0')}${ext}`))
  }
  return true
}

/** 帧文件名开头的 6 位序号；不带序号的文件返回 NaN（在连续性检查里会被拒）。 */
function frameIndex(path: string): number {
  const m = basename(path).match(/^(\d{6})/)
  return m ? Number.parseInt(m[1]!, 10) : Number.NaN
}

function safeCount(dir: string): number {
  try {
    return collectFrames(dir).length
  } catch {
    return 0
  }
}

/** 在 `output/` 下找到真正存帧的子目录。 */
function findImageDir(root: string): string {
  try {
    for (const top of readdirSync(root)) {
      const full = join(root, top)
      if (statSync(full).isDirectory()) {
        if (readdirSync(full).some(f => f.endsWith('.png') || f.endsWith('.jpg'))) return full
      }
    }
  } catch {
    // fallthrough
  }
  return root
}

/** 生成插件工作目录用的 vite 配置：项目入口与帧输出都在 workDir 下。 */
export function viteConfigSource(
  projectPath?: string,
  outputPath?: string,
  allowDirs: string[] = [],
): string {
  // 缺省时保持相对写法（样例工程里 config 与 project 同目录，cwd 也是它）
  const project = projectPath ? JSON.stringify(projectPath) : "'./project.tsx'"
  const output = outputPath ? JSON.stringify(outputPath) : "'./output'"
  const allow = JSON.stringify(allowDirs.map(d => d.replace(/\\/g, '/')))
  return `import { defineConfig } from 'vite';
import motionCanvasPlugin from '@motion-canvas/vite-plugin';

const motionCanvas = (motionCanvasPlugin as unknown as { default?: typeof motionCanvasPlugin }).default ?? motionCanvasPlugin;

export default defineConfig({
  plugins: [motionCanvas({ project: ${project}, output: ${output} })],
  esbuild: { jsx: 'automatic', jsxImportSource: '@motion-canvas/2d' },
  server: {
    fs: {
      // workDir/node_modules 是指向插件真实 node_modules 的 junction，
      // 编辑器的样式与脚本从那里加载，必须放进白名单，否则编辑器裸奔无样式
      allow: ${allow},
    },
  },
});
`
}
