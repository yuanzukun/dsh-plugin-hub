/**
 * 工具的业务逻辑（纯 TS，不 import 任何 dsh 类型）。
 *
 * 这么切的原因很实在：`defineTool` 的类型来自 dsh，而 dsh 的依赖链
 * （`@deepseek-ai/dsh-llm` 等）装不上，逻辑一旦写进工具里就再也没法单测。
 * 把逻辑留在这一层，`register.ts` 只负责包一层 schema，测试就能跑起来。
 *
 * 每个 op 都通过 `emit` 回调产出事件，而不是自己返回事件让调用方去发——
 * 「一次修改对应一条事件」这个约束在类型上就钉死了。
 */

import { copyFileSync, existsSync, mkdirSync, readdirSync, statSync } from 'node:fs'
import { extname, join, resolve } from 'node:path'

import type { AnimationSpec, JsonValue, PatchOp, Scene, SpecSummary, ThemeToken } from '@dsh-anim/spec'
import { LAYER_TYPES, PROP_ALIASES, readAt, safeName, sceneDurationMs, specDurationMs, summarizeSpec, validateSpec } from '@dsh-anim/spec'
import type { OutlineItem } from '@dsh-anim/store'
import { SpecStore, SpecStoreError } from '@dsh-anim/store'

import type { AnimEvent, AnimOutlineData } from './events.ts'
import type { AnimRenderer, AnimRendererRegistry, IncrementalInfo, RenderResult } from './render.ts'
import type { SpeechNote, TtsService } from './tts.ts'
import { synthesizeNarration, type SpeechBuildResult } from './tts.ts'

export interface AnimDeps {
  store: SpecStore
  renderers: AnimRendererRegistry
  /** 渲染产物的默认落盘目录。 */
  outputDir: string
  /** 配音服务（0.5.0 §5）：宿主配置了 tts.command 时存在，否则旁白只出字幕。 */
  tts?: TtsService
  /** 护栏阈值覆盖（0.6.0 §3.3）：不配置用 DEFAULT_GUARD_THRESHOLDS。 */
  guard?: Partial<GuardThresholds>
  /** 新建 spec 的缺省画质（0.6.0）：模型建片不带 fps/width/height 时生效。 */
  defaults?: { fps?: number; width?: number; height?: number }
}

export type Emit = (event: AnimEvent) => void

/** 工具层统一错误：消息直接给模型看，所以要写成可执行的建议，不是堆栈。 */
export class AnimOpError extends Error {
  constructor(message: string) {
    super(message)
    this.name = 'AnimOpError'
  }
}

/* ------------------------------------------------------------------ 主题 */

export const DEFAULT_THEME: ThemeToken = {
  colors: {
    background: '#101418',
    text: '#F2F5F7',
    muted: '#7C8A96',
    primary: '#4C9AFF',
    accent: '#FFB020',
  },
  font: { family: 'Noto Sans CJK SC, sans-serif', size: 48 },
}

/* ------------------------------------------------------------- 建 spec */

export interface CreateSpecArgs {
  specId: string
  title: string
  fps?: number
  width?: number
  height?: number
  background?: string
  fontFamily?: string
}

export type CreateSpecResult = {
  specId: string
  title: string
  fps: number
  size: { width: number; height: number }
  /** 下一步该做什么，写进回执里比让模型自己猜强。 */
  next: string
}

export function opCreateSpec(deps: AnimDeps, args: CreateSpecArgs, emit: Emit): CreateSpecResult {
  // 缺省画质三层：模型显式传参 > 宿主 defaults 配置 > 内置 30fps / 1280×720。
  // 生效值随回执（fps/size）返回，模型与面板看到的都是实际落库值
  const spec: AnimationSpec = {
    version: 1,
    meta: {
      id: args.specId,
      title: args.title,
      fps: args.fps ?? deps.defaults?.fps ?? 30,
      size: {
        width: args.width ?? deps.defaults?.width ?? 1280,
        height: args.height ?? deps.defaults?.height ?? 720,
      },
      background: args.background ?? DEFAULT_THEME.colors.background,
      locale: 'zh-CN',
    },
    theme: {
      ...DEFAULT_THEME,
      font: { ...DEFAULT_THEME.font, family: args.fontFamily ?? DEFAULT_THEME.font.family },
    },
    assets: {},
    scenes: [],
  }
  // 空 spec 是合法中间态：库层要显式放行，免得为了建空文档去伪造一个假场景
  const checked = validateSpec(spec, { allowEmptyScenes: true })
  if (!checked.ok) throw new AnimOpError(checked.errors.map(e => e.message).join('; '))
  const empty = checked.spec

  try {
    deps.store.create(args.specId, empty)
  } catch (err) {
    if (err instanceof SpecStoreError) throw new AnimOpError(err.message)
    throw err
  }
  emit({ type: 'anim/spec-created', data: { specId: args.specId, spec: empty } })

  return {
    specId: args.specId,
    title: args.title,
    fps: spec.meta.fps,
    size: spec.meta.size,
    next: `spec 已建立，0 个场景。下一步用 anim_plan 写分镜大纲，再用 anim_draft_scene 逐幕细化。`,
  }
}

/* ------------------------------------------------------------- 分镜大纲 */

export interface PlanArgs {
  specId: string
  outline: AnimOutlineData['outline']
}

export type PlanResult = {
  specId: string
  sceneCount: number
  totalMs: number
  /** 节奏体检：哪些幕太短讲不完、哪些幕太长会走神。 */
  pacing: string[]
}

/**
 * 大纲由模型写，工具负责落库与节奏体检。
 *
 * 为什么工具不自己「生成」大纲：生成内容本来就是模型的活，工具代劳只会把
 * 一次模型调用变成一次工具调用加一次模型调用。但**校验**值得放在工具里——
 * 教学动画的节奏是有客观约束的，模型自己算不准总时长。
 */
export function opPlan(deps: AnimDeps, args: PlanArgs, emit: Emit): PlanResult {
  if (!deps.store.has(args.specId)) throw new AnimOpError(`spec ${args.specId} 不存在，先调 anim_create_spec`)
  if (args.outline.length === 0) throw new AnimOpError('大纲不能为空')

  const pacing: string[] = []
  for (const item of args.outline) {
    if (item.durationMs < 1200) pacing.push(`「${item.name}」只有 ${item.durationMs}ms，讲不完一个概念，建议 ≥1500ms`)
    if (item.durationMs > 8000) pacing.push(`「${item.name}」${item.durationMs}ms 偏长，建议拆成两幕或压到 6s 内`)
    if (!item.intent) pacing.push(`「${item.name}」缺少教学意图，写清楚这幕要让学生明白什么`)
  }
  const totalMs = args.outline.reduce((s, x) => s + x.durationMs, 0)
  // 「全片 Xs 共 N 幕」这类中性信息不再混进 pacing：totalMs/sceneCount 已在
  // 回执与面板摘要里，混在一起会稀释真警告的视觉权重（优化清单 O18）
  // 全片时长档位（0.4.0 规划 N5）：单幕体检管不住「幕幕合格加起来渲不动」
  if (totalMs > 180_000) {
    pacing.push(`全片 ${Math.round(totalMs / 1000)}s：默认渲染超时 30 分钟，这个体量渲染前先用 anim_render 的 scenes 抽查，并认真考虑压缩节奏或拆片`)
  } else if (totalMs > 60_000) {
    pacing.push(`全片 ${Math.round(totalMs / 1000)}s：长片渲染耗时以分钟计，确认这个体量是有意为之`)
  }

  // 大纲进状态（0.4.0 规划 N3）：后续 draft/render 才能对「大纲 ↔ 实际场景」
  // 做对账；事件照发，回放由 foldEvents 消费同一条事件恢复出同一份大纲
  deps.store.setOutline(args.specId, args.outline)
  emit({ type: 'anim/outline-updated', data: { specId: args.specId, outline: args.outline } })
  return { specId: args.specId, sceneCount: args.outline.length, totalMs, pacing }
}

/* --------------------------------------------------------------- 读 spec */

export interface GetArgs {
  specId: string
  /** JSON Pointer（`/scenes/1/layers/0`）；空或省略返回整份。 */
  path?: string
  /** 批量读取（0.5.0 §3.1）：一次取多段，与单数 `path` 并存（单数形式向后兼容）。 */
  paths?: string[]
  /** `'summary'` 返回时间线摘要（幕起止/图层/资产引用），不返回 spec 片段。
   * 宿主 schema 的字符串推断较宽，运行时按值等于 'summary' 判断。 */
  view?: string
}

export interface GetSegment {
  path: string
  value?: unknown
  error?: string
}

export type GetResultView = {
  specId: string
  durationMs: number
} & (
  | { view: 'summary'; summary: SpecSummary }
  | { path: string; value: unknown }
  | { segments: GetSegment[] }
)

export function opGet(deps: AnimDeps, args: GetArgs): GetResultView {
  const spec = deps.store.get(args.specId)
  const durationMs = specDurationMs(spec.scenes)
  if (args.view === 'summary') {
    return { specId: args.specId, durationMs, view: 'summary', summary: summarizeSpec(spec) }
  }
  if (args.paths !== undefined) {
    const segments: GetSegment[] = args.paths.map(path => {
      try {
        return { path, value: readAt(spec, path) }
      } catch (err) {
        return { path, error: err instanceof Error ? err.message : String(err) }
      }
    })
    return { specId: args.specId, durationMs, segments }
  }
  const path = args.path ?? ''
  let value: unknown = spec
  if (path !== '') {
    try {
      value = readAt(spec, path)
    } catch (err) {
      throw new AnimOpError(err instanceof Error ? err.message : String(err))
    }
  }
  return { specId: args.specId, durationMs, path: path || '(整份)', value }
}

/* --------------------------------------------------------------- 写 spec */

export interface PatchArgs {
  specId: string
  ops: PatchOp[]
  note?: string
}

export type PatchResultView = {
  specId: string
  version: number
  applied: number
  durationMs: number
  /** 反向 ops，模型可以直接拿它再调一次 anim_patch 来撤销。 */
  inverse: PatchOp[]
  warnings: string[]
}

export function opPatch(deps: AnimDeps, args: PatchArgs, emit: Emit): PatchResultView {
  if (args.ops.length === 0) throw new AnimOpError('ops 为空，没有要改的东西')
  let applied: PatchOp[]
  let inverse: PatchOp[]
  let version: number
  try {
    const r = deps.store.patch(args.specId, args.ops, args.note)
    applied = [...args.ops]
    inverse = r.inverse
    version = deps.store.record(args.specId).version
  } catch (err) {
    throw new AnimOpError(err instanceof Error ? err.message : String(err))
  }
  // patch 后的软警告（时长超声明、疑似左上角坐标系）随回执带给模型
  const { warnings } = validateSpec(deps.store.get(args.specId))
  const durationMs = deps.store.durationMs(args.specId)

  emit({ type: 'anim/spec-patched', data: { specId: args.specId, ops: applied, inverse, note: args.note, durationMs } })
  return { specId: args.specId, version, applied: applied.length, durationMs, inverse, warnings }
}

/* ------------------------------------------------------------- 场景草稿 */

export interface DraftSceneArgs {
  specId: string
  scene: Scene
  /** 省略则追加到末尾。 */
  index?: number
}

export type DraftSceneResult = {
  specId: string
  sceneId: string
  index: number
  sceneCount: number
  durationMs: number
  inverse: PatchOp[]
  /** 边界自动纠正清单：哪些机械错误被工具改掉了。模型应读到并下次自己写对。 */
  repairs: string[]
  /** 校验软警告（时长超声明、疑似左上角坐标系等）。模型必须读到并自行处理。 */
  warnings: string[]
  /**
   * 「大纲 ↔ 实际场景」对账提示（中性信息，非告警）：超出/偏离大纲的形态
   * 需要模型看一眼自行判断是新想法还是笔误。大纲不存在时缺省。
   */
  outlineNotes?: string[]
}

/* ----------------------------------------------------- 草稿边界自动纠错 */

export interface CoercedScene {
  scene: Scene
  /** 人话版修复清单，每条说清改了什么、为什么。 */
  repairs: string[]
}

const LAYER_TYPE_SET: ReadonlySet<string> = new Set(LAYER_TYPES)

/**
 * 场景草稿的机械错误自动纠正（真机首写 `anim_draft_scene` 高频失败四类）：
 * 1. `ease: "easeOut"` 写成字符串 → 包装成 `{ kind: 'easeOut' }`。未知缓动名
 *    也一并包装——这样校验器报的是「未知缓动类型 "bounce"，可选：…」而不是
 *    一句「应为对象」，模型一眼知道错在值不在形态；
 * 2. 图层 `type` 大小写写飘（"Text"/"Circle"）→ 按不区分大小写匹配 LAYER_TYPES 纠正；
 * 3. 漏纯展示字段 `name`（图层/场景）→ 用 id 补上；漏 `tracks`（静态图层本就合法）
 *    → 补空数组；
 * 4. 属性别名归一为规范名（权威表 `PROP_ALIASES`，0.4.0 N2 收敛）：props 键与
 *    轨道目标两侧都改写——`strokeWidth → lineWidth`、`color → fill`。规范名
 *    已显式给出时别名不动（规范名优先，不丢内容）。
 *
 * 只修「无歧义、不丢内容」的错；拿不准的一律不动，留给 validateSpec 报错
 * （文案自带可执行指引）。输入先深拷贝，绝不改调用方的参数对象。
 */
export function coerceScene(input: unknown): CoercedScene {
  const repairs: string[] = []
  if (input === null || typeof input !== 'object' || Array.isArray(input)) {
    // 场景本身不是对象：无从纠起，原样交校验器报「场景应为对象」
    return { scene: input as Scene, repairs }
  }
  const scene = structuredClone(input) as Record<string, unknown>

  // ease 字符串 → { kind } 包装。闭包共享计数，最后合并成一条修复说明
  let easeWrapped = 0
  const wrapEase = (holder: Record<string, unknown>, key: string): void => {
    if (typeof holder[key] === 'string') {
      holder[key] = { kind: holder[key] }
      easeWrapped++
    }
  }

  if ((scene.name === undefined || scene.name === null || scene.name === '') && typeof scene.id === 'string' && scene.id !== '') {
    scene.name = scene.id
    repairs.push(`场景缺 name，已用 id「${scene.id}」补上（name 只用于展示）`)
  }

  const typeFixed: string[] = []
  const nameFilled: string[] = []
  const tracksFilled: string[] = []
  const aliasesFixed: string[] = []
  if (Array.isArray(scene.layers)) {
    for (const l of scene.layers) {
      if (l === null || typeof l !== 'object' || Array.isArray(l)) continue
      const layer = l as Record<string, unknown>
      const label = typeof layer.id === 'string' && layer.id !== '' ? layer.id : '(缺 id)'
      if (typeof layer.type === 'string' && !LAYER_TYPE_SET.has(layer.type)) {
        const lower = layer.type.toLowerCase()
        if (LAYER_TYPE_SET.has(lower)) {
          typeFixed.push(`"${layer.type}"→"${lower}"`)
          layer.type = lower
        }
      }
      if ((layer.name === undefined || layer.name === null || layer.name === '') && typeof layer.id === 'string' && layer.id !== '') {
        layer.name = layer.id
        nameFilled.push(label)
      }
      if (layer.tracks === undefined || layer.tracks === null) {
        layer.tracks = []
        tracksFilled.push(label)
      }
      // 属性别名归一（表驱动，含 color→fill / strokeWidth→lineWidth 等）：
      // 规范名写库时就落对，anim_get 读到的就是规范形态
      const lp = layer.props
      if (lp !== null && typeof lp === 'object' && !Array.isArray(lp)) {
        const p = lp as Record<string, unknown>
        for (const [alias, canonical] of Object.entries(PROP_ALIASES)) {
          if (p[alias] !== undefined && p[canonical] === undefined) {
            p[canonical] = p[alias]
            delete p[alias]
            aliasesFixed.push(`${label}: ${alias}→${canonical}`)
          }
        }
      }
      if (Array.isArray(layer.tracks)) {
        for (const t of layer.tracks) {
          if (t === null || typeof t !== 'object' || !Array.isArray((t as Record<string, unknown>).keys)) continue
          const tr = t as Record<string, unknown>
          // 轨道目标别名归一：props.strokeWidth → props.lineWidth（轨道目标
          // 永远不会被支持为别名形态，无歧义改写）
          if (typeof tr.target === 'string') {
            const m = /^props\.([^.]+)$/.exec(tr.target)
            const canonical = m ? PROP_ALIASES[m[1]!] : undefined
            if (m && canonical !== undefined) {
              tr.target = `props.${canonical}`
              aliasesFixed.push(`${label}: 轨道目标 ${m[1]}→${canonical}`)
            }
          }
          for (const k of tr.keys as unknown[]) {
            if (k !== null && typeof k === 'object' && !Array.isArray(k)) wrapEase(k as Record<string, unknown>, 'ease')
          }
        }
      }
    }
  }
  if (scene.transition !== undefined && scene.transition !== null && typeof scene.transition === 'object') {
    wrapEase(scene.transition as Record<string, unknown>, 'ease')
  }

  if (easeWrapped > 0) repairs.push(`${easeWrapped} 处 ease 由字符串包装成 { kind } 对象——下次请直接写 {"kind":"easeOut"} 形式`)
  if (typeFixed.length > 0) repairs.push(`图层 type 大小写已纠正：${typeFixed.join('、')}（类型名全小写）`)
  if (nameFilled.length > 0) repairs.push(`图层缺 name，已用各自 id 补上：${nameFilled.join('、')}`)
  if (tracksFilled.length > 0) repairs.push(`图层缺 tracks，已按静态图层补空数组：${tracksFilled.join('、')}`)
  if (aliasesFixed.length > 0) repairs.push(`属性别名已归一化为规范名：${aliasesFixed.join('、')}（下次直接写规范名）`)
  return { scene: scene as unknown as Scene, repairs }
}

/* ----------------------------------------------------------- 大纲对账 */

/**
 * 「大纲 ↔ 实际场景」对账（0.4.0 规划 N3）。
 *
 * 返回**中性提示**而不是 warnings：大纲与场景本就不要求逐字对应，这些形态
 * 需要模型看一眼自行判断是新想法（更新大纲）还是笔误（核对场景 id）。
 * `anim_draft_scene`（写幕时）与 `anim_render`（渲染前）都吃这份提示——
 * 渲染前的偏差意味着「整片重渲也得不到想要的片子」，此时说比渲完说便宜。
 */
export function reconcileOutline(outline: readonly OutlineItem[], scenes: readonly Scene[]): string[] {
  const notes: string[] = []
  if (outline.length === 0) return notes
  const outlineIds = new Set(outline.map(o => o.id))
  if (scenes.length > outline.length) {
    notes.push(`已写入 ${scenes.length} 幕，超出大纲的 ${outline.length} 幕——多出的幕是新想法（用 anim_plan 更新大纲）还是误写（核对场景）？`)
  }
  const stray = scenes.filter(s => !outlineIds.has(s.id)).map(s => s.id)
  if (stray.length > 0) {
    notes.push(`场景 ${stray.join('、')} 不在大纲中（大纲：${outline.map(o => o.id).join('、')}）`)
  }
  for (const s of scenes) {
    const suggested = outline.find(o => o.id === s.id)?.durationMs
    if (typeof suggested === 'number' && suggested > 0) {
      const dev = Math.abs(sceneDurationMs(s) - suggested) / suggested
      if (dev > 0.5) {
        notes.push(`场景「${s.id}」实际时长 ${sceneDurationMs(s)}ms，大纲建议 ${suggested}ms（偏差 ${Math.round(dev * 100)}%）`)
      }
    }
  }
  const actualMs = specDurationMs(scenes)
  const outlineMs = outline.reduce((sum, o) => sum + (typeof o.durationMs === 'number' && o.durationMs > 0 ? o.durationMs : 0), 0)
  // 全片偏差只在幕数写齐后才有意义：草稿写到一半偏差必然大（真机验证发现
  // 逐幕 draft 时这条提示每幕都响，属噪音）——「未写完」那条已经覆盖该语义
  if (outlineMs > 0 && actualMs > 0 && scenes.length >= outline.length) {
    const dev = Math.abs(actualMs - outlineMs) / outlineMs
    if (dev > 0.3) {
      notes.push(`全片实际 ${actualMs}ms，大纲合计 ${outlineMs}ms（偏差 ${Math.round(dev * 100)}%）——先对齐再渲染，避免整片重渲`)
    }
  }
  if (scenes.length > 0) {
    const missing = outline.filter(o => !scenes.some(s => s.id === o.id)).map(o => o.id)
    if (missing.length > 0) notes.push(`大纲还有 ${missing.length} 幕未写：${missing.join('、')}`)
  }
  return notes
}

export function opDraftScene(deps: AnimDeps, args: DraftSceneArgs, emit: Emit): DraftSceneResult {
  // 先过机械纠错再校验：ease 字符串、type 大小写、漏 name/tracks、strokeWidth
  // 旧名这类机械错误不值得烧一个来回，纠正清单随回执回报让模型下次自己写对
  const { scene, repairs } = coerceScene(args.scene)
  const checked = validateSpec({ ...deps.store.get(args.specId), scenes: [scene] })
  if (!checked.ok) {
    // 报错尾部带最小行动指引：模型不必翻工具描述就能对齐最常漏的形态
    throw new AnimOpError(
      `场景草稿非法：${checked.errors.map(e => `${e.path || '(根)'} — ${e.message}`).join('; ')}`
      + '。图层必填五字段 id / name / type / props / tracks，ease 必须是对象（如 {"kind":"easeOut"}）而不是字符串',
    )
  }
  let ops: PatchOp[]
  let inverse: PatchOp[]
  try {
    const r = deps.store.putScene(args.specId, scene, args.index)
    ops = r.ops
    inverse = r.inverse
  } catch (err) {
    throw new AnimOpError(err instanceof Error ? err.message : String(err))
  }
  const spec = deps.store.get(args.specId)
  const index = spec.scenes.findIndex(s => s.id === scene.id)
  const durationMs = specDurationMs(spec.scenes)
  emit({
    type: 'anim/spec-patched',
    data: { specId: args.specId, ops, inverse, note: `写入场景「${scene.name}」`, durationMs },
  })
  // 大纲存在才对账：大纲是模型的计划，写幕时偏差最便宜的时刻就在此刻
  const outline = deps.store.record(args.specId).outline
  const outlineNotes = outline !== undefined && outline.length > 0 ? reconcileOutline(outline, spec.scenes) : []
  return {
    specId: args.specId,
    sceneId: scene.id,
    index,
    sceneCount: spec.scenes.length,
    durationMs,
    inverse,
    repairs,
    warnings: checked.warnings,
    ...(outlineNotes.length > 0 ? { outlineNotes } : {}),
  }
}

/* ------------------------------------------------------------------ 渲染 */

export interface PreviewArgs {
  specId: string
  atMs?: number[]
  scale?: number
  renderer?: string
}

export interface PreviewFrame {
  atMs: number
  path: string
}

export interface PreviewResultView {
  specId: string
  renderer: string
  frames: PreviewFrame[]
  warnings?: string[]
  /** 单幕直放（0.5.0 规划 §3.2）：段缓存命中时回放段视频，frames 为空数组。 */
  clip?: PreviewClipInfo
}

export interface PreviewClipInfo {
  path: string
  sceneId: string
  sceneIndex: number
  durationMs: number
}

/**
 * 单幕直放快路径（0.5.0 规划 §3.2）：抽帧点全部落在同一幕、且后端的段缓存
 * 命中该幕时，直接回放段视频——原画质、带音频、零渲染开销。段缓存是
 * anim_render 的副产品，这里只是把它送到面板；未命中返回 undefined，走正常
 * 抽帧路径（预期管理不变：抽帧无音频）。
 * `displayMs` 是配音渲染时传给指纹的实测语音时长——查段口径必须与渲染一致，
 * 否则 TTS spec 的段永远不命中（真机 E2E 抓到的失配）。
 */
export function previewClipFastPath(
  spec: AnimationSpec,
  renderer: AnimRenderer,
  args: PreviewArgs,
  displayMs?: number[],
): PreviewClipInfo | undefined {
  const find = renderer.findSceneSegment?.bind(renderer)
  if (!find) return undefined
  const at = args.atMs ?? []
  if (at.length === 0) return undefined // 缺省抽帧点按全片自动采样，通常跨幕，不适用
  let sceneIndex = -1
  for (const atMs of at) {
    const idx = sceneIndexAtMs(spec, atMs)
    if (idx === -1) return undefined
    if (sceneIndex !== -1 && sceneIndex !== idx) return undefined
    sceneIndex = idx
  }
  if (sceneIndex === -1) return undefined
  const segment = find(spec, sceneIndex, args.scale, displayMs)
  if (!segment) return undefined
  return { path: segment.path, sceneId: spec.scenes[sceneIndex]!.id, sceneIndex, durationMs: segment.durationMs }
}

/** atMs 落在哪一幕（场景内绝对毫秒，与渲染同口径的累计实际时长）。越界钳到末幕。 */
function sceneIndexAtMs(spec: AnimationSpec, atMs: number): number {
  let cursor = 0
  for (let i = 0; i < spec.scenes.length; i++) {
    const duration = sceneDurationMs(spec.scenes[i]!)
    if (atMs < cursor + duration || i === spec.scenes.length - 1) return i
    cursor += duration
  }
  return -1
}

/** 后台模式下预览的即时回执：帧清单经 preview-finished 事件与 job_output 到达。 */
export interface PreviewBackgroundTicket {
  kind: 'background'
  jobId: string
  specId: string
  next: string
}

/**
 * 抽帧预览（0.4.0 §5.3，O19）：宿主提供 ctx.jobs 时转后台任务——工具立即返回
 * jobId，帧清单以 preview-finished 事件与 job_output 到达，面板卡片轮询
 * /api/state 重建缩略图。宿主没有 jobs 服务或发布失败时维持同步回退。
 */
/* --------------------------------------------------------- 重复发起护栏 */

/**
 * 护栏阈值（0.6.0 规划 §3.3）：0.5 的软提示被真机证明拦不住死循环（模型 70+
 * 次同参连发、每次都收到提示、每次都不听），升级为四层——状态（lastRender，
 * 见 store）→ 收束指引（完成回执 next）→ 软提示（softAt/specSoftAt 起）→
 * 硬拒绝（hardAt/specHardAt 起）。阈值经插件配置 `guard` 可调。
 */
export interface GuardThresholds {
  /** 同参第 N 次起软提示（回执附纠正文案，任务照常执行）。 */
  softAt: number
  /** 同参第 N 次起硬拒绝（抛 AnimOpError，任务不执行）。 */
  hardAt: number
  /** 同 spec 同工具在窗口内第 N 次起软提示（换参也计数——治「每次换一点参数」的绕行）。 */
  specSoftAt: number
  /** 同 spec 同工具在窗口内第 N 次起硬拒绝。 */
  specHardAt: number
  /** 计数窗口（毫秒）。 */
  windowMs: number
}

export const DEFAULT_GUARD_THRESHOLDS: GuardThresholds = {
  softAt: 3,
  hardAt: 6,
  specSoftAt: 15,
  specHardAt: 30,
  windowMs: 10 * 60_000,
}

export interface GuardVerdict {
  /** 软提示：附进回执 warnings / 票据 next，任务照常执行。 */
  note?: string
  /** 硬拒绝文案：调用方必须抛 AnimOpError，任务不执行。永远给出路。 */
  refuse?: string
}

interface GuardEntry {
  count: number
  firstAt: number
  /** 计数开始时的 spec 版本：版本变化（patch 过）即重置——合法的修改-检查循环豁免。 */
  specVersion: number
}

/** 护栏状态按 deps（= 插件实例）隔离：冒烟多夹具与多插件互不串计数。 */
const repeatGuardByDeps = new WeakMap<object, { byKey: Map<string, GuardEntry>; bySpec: Map<string, GuardEntry> }>()

function guardThresholds(deps: AnimDeps): GuardThresholds {
  return { ...DEFAULT_GUARD_THRESHOLDS, ...deps.guard }
}

/** 当前 spec 版本（version 重置判据）；spec 不存在按 -1（不触发重置）。 */
function specVersionOf(deps: AnimDeps, specId: string): number {
  try {
    return deps.store.has(specId) ? deps.store.record(specId).version : -1
  } catch {
    return -1
  }
}

/** 计数 +1（窗口外或版本变化则重置），返回计数后的条目。 */
function bumpGuard(map: Map<string, GuardEntry>, sig: string, now: number, windowMs: number, version: number): GuardEntry {
  // 过期项惰性清理：Map 过大时扫一遍窗口外的
  if (map.size > 500) {
    for (const [k, v] of map) if (now - v.firstAt > windowMs) map.delete(k)
  }
  const entry = map.get(sig)
  if (!entry || now - entry.firstAt > windowMs) {
    const fresh: GuardEntry = { count: 1, firstAt: now, specVersion: version }
    map.set(sig, fresh)
    return fresh
  }
  if (version >= 0 && entry.specVersion !== version) {
    entry.count = 1
    entry.firstAt = now
    entry.specVersion = version
    return entry
  }
  entry.count += 1
  return entry
}

/**
 * 同参/同 spec 重复发起判定（真机 turn 17 教训，0.6.0 §3.3 强化）。
 *
 * 两层计数互补：
 * - **同参维度**（key）：治 preview→wait_agent→preview 的机械死循环；
 * - **spec 维度**（bySpec）：治「每次挪一点参数」的绕行——死循环的本质特征
 *   是高频 + spec 未修改，spec 维度只看频次。
 *
 * 签名归一化：atMs 排序去重 + 秒级量化，挪几百毫秒不再重置计数；一次调用取
 * 多个抽帧点本就合法（数组语义），不受影响。version 重置：patch 过的 spec
 * 计数清零，「修改 → 抽帧复查」的正当循环永不误伤。持久化刻意不做：退化循环
 * 发生在同一进程的同一回合里，重启即断环，持久化反而让隔天的正当复查撞上
 * 昨天的计数（0.6.0 §3.3 评估结论）。
 */
export function checkRepeatGuard(deps: AnimDeps, scope: string, specId: string, key: string): GuardVerdict {
  const th = guardThresholds(deps)
  const now = Date.now()
  let guard = repeatGuardByDeps.get(deps)
  if (!guard) {
    guard = { byKey: new Map(), bySpec: new Map() }
    repeatGuardByDeps.set(deps, guard)
  }
  const version = specVersionOf(deps, specId)
  const byKey = bumpGuard(guard.byKey, `${scope}|${key}`, now, th.windowMs, version)
  const bySpec = bumpGuard(guard.bySpec, `${scope}|${specId}`, now, th.windowMs, version)
  const minutes = Math.max(1, Math.round(th.windowMs / 60_000))
  if (byKey.count >= th.hardAt || bySpec.count >= th.specHardAt) {
    const sameParam = byKey.count >= th.hardAt
    return {
      refuse: `${scope}已连续第 ${sameParam ? byKey.count : bySpec.count} 次重复发起${sameParam ? '（同一参数）' : '（本会话短时间内高频，含换参）'}，本次已拒绝执行。`
        + '后台任务不会因重复发起而变快：请改用 job_output 查询既有任务的结果（jobId 见此前回执）；wait_agent 对后台任务只会立即空转返回。'
        + `若确需再次执行，请先用 anim_patch 修改 spec（版本变化会重置计数）或等待 ${minutes} 分钟后重试；如是用户明确要求，请向用户说明该限制。`,
    }
  }
  if (byKey.count >= th.softAt || bySpec.count >= th.specSoftAt) {
    return {
      note: byKey.count >= th.softAt
        ? `同一参数的${scope}已连续发起 ${byKey.count} 次：后台任务不会因重复发起而变快或提前完成，请改用 job_output 查询既有任务的结果（jobId 见此前回执）；wait_agent 只用于等待团队成员，对本工具的后台任务会立即空转返回。再连续 ${Math.max(0, th.hardAt - byKey.count)} 次将被拒绝执行。`
        : `近 ${minutes} 分钟内已对同一 spec 发起 ${bySpec.count} 次${scope}（含换参）：这个频率通常是在无效重试——后台任务的结果请用 job_output 查询；修改请走 anim_patch（版本变化会重置本计数），确认修改已落库再复查。`,
    }
  }
  return {}
}

/**
 * 「渲染后未修改再检查」提示（0.6.0 §3.1/§3.3 配套）：lastRender 的版本与
 * 当前一致说明 spec 渲染后没改过，此时抽帧/重渲不产生新信息——把这句话递到
 * 模型眼前，让「看一眼就收尾」成为默认动作。只提示不拦截（用户显式要求的
 * 复查是正当的，但模型该知道自己可以停了）。
 */
function staleRenderNote(deps: AnimDeps, specId: string, verb: string): string | undefined {
  let record
  try {
    if (!deps.store.has(specId)) return undefined
    record = deps.store.record(specId)
  } catch {
    return undefined
  }
  const lr = record.lastRender
  if (!lr || lr.specVersionAtRender !== record.version) return undefined
  return `该 spec 自上次渲染成片（${lr.outputPath}）后未修改，本次${verb}不会产生新信息——若只是想确认成片效果，请直接向用户报告既有结果并结束回合。`
}

/**
 * 抽帧点卫生（0.6.0 规划 §4.2）：越界点钳到片尾、负值钳到 0，钳动过就给
 * 一条警告。抽帧点落在片外此前行为未定义（落到末幕的越界偏移），显式钳制
 * 让回执与画面口径一致。
 */
function sanitizeAtMs(spec: AnimationSpec, atMs: number[] | undefined): { atMs: number[] | undefined; note?: string } {
  if (atMs === undefined) return { atMs: undefined }
  const totalMs = specDurationMs(spec.scenes)
  const clamped = atMs.map(ms => Math.max(0, Math.min(ms, totalMs)))
  if (clamped.every((ms, i) => ms === atMs[i])) return { atMs }
  return {
    atMs: clamped,
    note: `抽帧点 [${atMs.join(', ')}]ms 含超出全片时长（${totalMs}ms）或负值的点，已钳到有效范围`,
  }
}

/** 护栏签名（0.6.0 §3.3 归一化）：atMs 排序去重 + 秒级量化，微调参数不再绕过计数。 */
function normalizeAtMsKey(atMs: number[] | undefined): string {
  const quantized = [...new Set((atMs ?? []).map(ms => Math.round(ms / 1000)))].sort((a, b) => a - b)
  return JSON.stringify(quantized)
}

export async function opPreview(
  deps: AnimDeps,
  args: PreviewArgs,
  signal: AbortSignal,
  emit: Emit = () => {},
  jobs?: AnimJobsService,
  owner?: unknown,
): Promise<PreviewResultView | PreviewBackgroundTicket> {
  const spec = deps.store.get(args.specId)
  const renderer = deps.renderers.get(args.renderer)
  // 重复发起护栏（真机 turn 17 教训，0.6.0 §3.3 强化）：软提示附进回执、
  // 高频硬拒绝——拒绝在一切工作开始前，绝不烧渲染开销
  const verdict = checkRepeatGuard(
    deps,
    '预览',
    args.specId,
    `${args.specId}|atMs=${normalizeAtMsKey(args.atMs)}|scale=${args.scale ?? ''}`,
  )
  if (verdict.refuse) throw new AnimOpError(verdict.refuse)
  const guardNote = verdict.note
  // 抽帧点卫生（0.6.0 §4.2）：越界钳制 + 警告
  const { atMs, note: atMsNote } = sanitizeAtMs(spec, args.atMs)
  if (atMsNote !== undefined) args = { ...args, atMs }
  // 渲染后未修改的语境提示（0.6.0 §3.1）：spec 渲染后没改过就明说「不会有新信息」
  const staleNote = staleRenderNote(deps, args.specId, '抽帧')
  const warnings = [guardNote, atMsNote, staleNote].filter((w): w is string => w !== undefined)
  // 单幕直放快路径（0.5.0 §3.2）：零渲染开销，无「后台」可言，命中即同步返回。
  // 配音 spec 先按缓存口径还原 displayMs（渲染后命中缓存近零开销），
  // 保证查段指纹与 anim_render 完全同口径。
  if (deps.tts && (spec.narration?.cues.length ?? 0) > 0) {
    const speechBuild = await buildSpeech(spec, deps)
    const clip = previewClipFastPath(spec, renderer, args, speechBuild?.displayMs)
    if (clip) {
      emit({ type: 'anim/preview-start', data: { specId: args.specId, jobId: 'clip' } })
      emit({ type: 'anim/preview-finished', data: { specId: args.specId, jobId: 'clip', frames: [], clip } })
      return { specId: args.specId, renderer: renderer.name, frames: [], clip, ...(warnings.length > 0 ? { warnings } : {}) }
    }
  }
  const clip = previewClipFastPath(spec, renderer, args)
  if (clip) {
    emit({ type: 'anim/preview-start', data: { specId: args.specId, jobId: 'clip' } })
    emit({ type: 'anim/preview-finished', data: { specId: args.specId, jobId: 'clip', frames: [], clip } })
    return { specId: args.specId, renderer: renderer.name, frames: [], clip, ...(warnings.length > 0 ? { warnings } : {}) }
  }
  if (jobs) {
    // 与 opRender 同一降级链：先带 owner，失败退无主，再失败退同步
    let lastError: unknown
    for (const ownerCandidate of [owner, undefined]) {
      try {
        const ticket = await startBackgroundPreview(args, { spec, renderer }, emit, jobs, ownerCandidate)
        return warnings.length > 0 ? { ...ticket, next: `${ticket.next} ⚠️${warnings.join(' ')}` } : ticket
      } catch (err) {
        lastError = err
      }
    }
    console.warn(`[dsh-anim-studio] 后台预览发布失败（owner 与无主两档均被拒），退回同步抽帧：${lastError instanceof Error ? lastError.message : String(lastError)}`)
  }
  const view = await previewSync(args, { spec, renderer }, signal, emit)
  return warnings.length > 0 ? { ...view, warnings: [...(view.warnings ?? []), ...warnings] } : view
}

async function startBackgroundPreview(
  args: PreviewArgs,
  resolved: { spec: AnimationSpec; renderer: AnimRenderer },
  emit: Emit,
  jobs: AnimJobsService,
  owner: unknown,
): Promise<PreviewBackgroundTicket> {
  const { spec, renderer } = resolved
  const specId = args.specId
  const controller = new AbortController()
  const jobIdBox: { value: string | null } = { value: null }
  // 事件与 jobId 的先后保障与渲染同款：id 未定先缓冲，确定后按因果序补发
  const gate = createRenderEventGate(emit, jobIdBox)
  const finishedId = (): string => jobIdBox.value ?? 'anim-preview'
  const run = (): AnimJobHandle => ({
    cancel: (reason?: unknown) => {
      controller.abort(reason instanceof Error ? reason : new Error(reason ? String(reason) : '预览任务被终止'))
    },
    done: renderer
      .preview({ spec, atMs: args.atMs, scale: args.scale ?? 2 }, controller.signal)
      .then(
        result => {
          gate.pass(() => ({
            type: 'anim/preview-finished',
            data: {
              specId,
              jobId: finishedId(),
              frames: result.frames.map(f => ({ atMs: f.atMs, path: f.path })),
              ...(result.warnings !== undefined && result.warnings.length > 0 ? { warnings: result.warnings } : {}),
            },
          }))
          return { status: 'completed' as const, output: result }
        },
        (err: unknown) => {
          const message = err instanceof Error ? err.message : String(err)
          if (controller.signal.aborted) {
            gate.pass(() => ({
              type: 'anim/preview-finished',
              data: { specId, jobId: finishedId(), status: 'killed' },
            }))
            return { status: 'killed' as const, detail: message }
          }
          gate.pass(() => ({
            type: 'anim/preview-finished',
            data: { specId, jobId: finishedId(), status: 'failed', error: message },
          }))
          return { status: 'failed' as const, detail: message }
        },
      ),
  })
  const jobId = await jobs.start({
    kind: 'anim-preview',
    label: `抽帧预览「${spec.meta.title}」(${specId})`,
    ...(owner === undefined ? {} : { owner }),
    run,
  })
  const id = typeof jobId === 'string' ? jobId : String(jobId ?? 'anim-preview')
  jobIdBox.value = id
  gate.pass(() => ({ type: 'anim/preview-start', data: { specId, jobId: id } }))
  gate.flush()
  return {
    kind: 'background',
    jobId: id,
    specId,
    next: `预览已在后台进行（jobId: ${id}）。用 job_output 收集帧清单；需要终止时用 job_kill。不要用 wait_agent 等待本任务，也不要重复发起同一预览。`,
  }
}

async function previewSync(
  args: PreviewArgs,
  resolved: { spec: AnimationSpec; renderer: AnimRenderer },
  signal: AbortSignal,
  emit: Emit,
): Promise<PreviewResultView> {
  const { spec, renderer } = resolved
  emit({ type: 'anim/preview-start', data: { specId: args.specId, jobId: 'sync' } })
  const result = await renderer.preview({ spec, atMs: args.atMs, scale: args.scale ?? 2 }, signal)
  emit({
    type: 'anim/preview-finished',
    data: {
      specId: args.specId,
      jobId: 'sync',
      frames: result.frames.map(f => ({ atMs: f.atMs, path: f.path })),
      ...(result.warnings !== undefined && result.warnings.length > 0 ? { warnings: result.warnings } : {}),
    },
  })
  return {
    specId: args.specId,
    renderer: result.renderer,
    frames: result.frames.map(f => ({ atMs: f.atMs, path: f.path })),
    ...(result.warnings !== undefined && result.warnings.length > 0 ? { warnings: result.warnings } : {}),
  }
}

/**
 * dsh `ctx.jobs` 的最小结构接口。
 *
 * 宿主侧类型不在本包的类型面上（与 EventSink 同一个处境），运行时按结构探测
 * 后使用；字段语义以官方 jobs 子系统文档为准：
 * - `start()` 预检通过后**同步**调用一次 `run()`，返回品牌化 JobId（形如 anim-render-1）；
 * - `run()` 返回 `{ cancel, done, readOutput? }`，done 在资源释放后 resolve、不应 reject；
 * - 模型侧的 job_output / job_kill 由 dsh-tool-jobs 提供，本插件不必自己造。
 */
export interface AnimJobHandle {
  cancel(reason?: unknown): unknown
  done: Promise<{ status?: 'completed' | 'killed' | 'failed'; detail?: unknown; output?: unknown }>
}

export interface AnimJobsService {
  start(spec: {
    kind: string
    label: string
    owner?: unknown
    run: () => AnimJobHandle
  }): unknown
}

export interface RenderArgs {
  specId: string
  outputPath?: string
  scenes?: number[]
  scale?: number
  /** 段缓存开关（§3.4），缺省开启；传 false 强制全量渲染。 */
  cache?: boolean
  renderer?: string
}

export interface RenderResultView {
  /** 区分回执：sync = 同步出片；background = 已转后台任务（见 RenderBackgroundTicket）。 */
  kind: 'sync'
  outputPath: string
  frameCount: number
  durationMs: number
  width: number
  height: number
  renderer: string
  /** 本片目标帧数（fps × 时长），成本预期管理（0.4.0 规划 N5）。 */
  expectedFrames?: number
  /** 生成期降级警告（同类已合并），模型需要逐条判断是否要改 spec（N4）。 */
  warnings?: string[]
  /** 大纲对账提示（中性信息），大纲不存在或完全对得上时缺省（N3）。 */
  outlineNotes?: string[]
  /** 增量渲染命中情况（§3.4），未走增量时缺省。 */
  incremental?: IncrementalInfo
  /** 混入成片的音轨（§4.1，audio 图层 assetId 列表），无声成片缺省。 */
  audioTracks?: string[]
  /** 混入成片的旁白配音条数（0.5.0 §5），纯字幕模式缺省。 */
  speechTracks?: number
  /** 旁白音画对账清单（0.5.0 §5.3）：报告而非自动改时间线。 */
  speechNotes?: SpeechNote[]
  /** 全片关键帧拼贴图（0.5.0 规划 §3.3，jpg 绝对路径），生成失败时缺省。 */
  contactSheet?: string
  /**
   * 完成时刻的收束指引（0.6.0 规划 §3.2）：成片就绪 → 报告用户并结束回合。
   * 0.5 真机教训：模型拿到完成结果的那一刻恰恰没有这句指引，转而反复抽帧。
   * 同步回执、后台 job_output 产物、render-finished 事件三处出口同文。
   */
  next: string
}

/** 后台模式下工具的即时回执：真正的渲染结果经 job_output / 完成通知到达。 */
export interface RenderBackgroundTicket {
  kind: 'background'
  jobId: string
  specId: string
  outputPath: string
  next: string
  /** 渲染启动前的对账提示：此刻说比渲完说便宜。 */
  outlineNotes?: string[]
}

/** 进度事件按 5% 一档节流：事件直接落会话日志，每帧一发等于往回放流里灌水。 */
const PROGRESS_STEPS = 20

/**
 * 渲染事件按因果序落盘的保障。
 *
 * jobs.start 是**同步**调用 run() 的，品牌化 jobId 要等 start 返回才已知；
 * 极端情况下（同步完成的假后端、立即 abort）渲染可能在 id 产生前就结算。
 * 所以渲染事件都以 thunk 形式过这道闸：id 未定先缓冲，id 确定后统一补发，
 * 落盘顺序恒为 render-start → render-progress… → render-finished，且载荷里
 * 的 jobId 不会错。
 */
function createRenderEventGate(emit: Emit, jobIdBox: { value: string | null }) {
  const deferred: Array<() => AnimEvent> = []
  const pass = (make: () => AnimEvent): void => {
    if (jobIdBox.value) emit(make())
    else deferred.push(make)
  }
  const flush = (): void => {
    for (const make of deferred.splice(0)) emit(make())
  }
  return { pass, flush }
}

function createProgressReporter(
  specId: string,
  jobIdBox: { value: string | null },
  emit: (make: () => AnimEvent) => void,
) {
  let lastStep = -1
  return (done: number, total: number): void => {
    if (!(total > 0) || done < 0) return
    const step = Math.min(PROGRESS_STEPS, Math.floor((done / total) * PROGRESS_STEPS))
    if (step <= lastStep && done < total) return
    lastStep = step
    // jobId 在补发时才取值：缓冲期间 id 可能尚未产生
    // 尾帧缓冲会让 done 略超预估 total（真机实测 92/90），percent 钳在 100
    emit(() => ({
      type: 'anim/render-progress',
      data: {
        specId,
        jobId: jobIdBox.value ?? 'anim-render',
        done,
        total,
        percent: Math.min(100, Math.round((done / total) * 100)),
      },
    }))
  }
}

function emitRenderStart(emit: Emit, specId: string, jobId: string, outputPath: string, args: RenderArgs): void {
  emit({
    type: 'anim/render-start',
    data: {
      specId,
      jobId,
      outputPath,
      // 可选字段按无损 JSON 约束条件展开，不留 undefined 属性值
      ...(args.scenes ? { scenes: args.scenes } : {}),
      ...(args.scale === undefined ? {} : { scale: args.scale }),
    },
  })
}

/** 完成时刻的收束指引（0.6.0 §3.2）：同步回执 / 后台产物 / 事件三处出口同文。 */
function renderDoneNext(outputPath: string): string {
  return `成片已就绪：${outputPath}——请直接向用户报告结果并结束本回合；如需修改，先用 anim_patch 改时间线再 anim_render 重渲，不要对未修改的 spec 反复抽帧或重渲。`
}

/**
 * 渲染成功视图组装：同步路径与后台路径共用一份形态——job_output 的产物就是
 * 这个视图（带 kind/next/speechNotes），模型在两条路径看到的结果一致。
 */
function buildRenderView(
  result: RenderResult,
  extras: { warnings: string[]; outlineNotes: string[] },
): RenderResultView {
  const warnings = extras.warnings
  return {
    ...result,
    kind: 'sync',
    next: renderDoneNext(result.outputPath),
    ...(warnings.length > 0 ? { warnings } : {}),
    ...(extras.outlineNotes.length > 0 ? { outlineNotes: extras.outlineNotes } : {}),
  }
}

/* ------------------------------------------------------- 渲染前预检 */

/**
 * 渲染前预检（0.6.0 规划 §4.1）：零渲染开销的快检。硬问题（注定渲不出或渲出
 * 也无意义的形态）直接报错快速失败——替代适配器深处的隐晦报错；软问题汇总成
 * 预检警告进回执，让模型在开跑前看到全貌。
 *
 * 硬检：scenes 越界/空数组；图层引用的 asset 未登记或登记的本地文件已丢失。
 * 软检：validateSpec 的软警告族（字幕带占用、缺尺寸兜底、秒毫秒混淆等）在
 * 渲染入口聚合一份——写幕时模型可能没逐条处理，开跑前最后一次提醒。
 */
export function preflightRender(deps: AnimDeps, spec: AnimationSpec, args: RenderArgs): string[] {
  // 硬检 1：scenes 形态
  if (args.scenes !== undefined) {
    if (args.scenes.length === 0) {
      throw new AnimOpError('scenes 是空数组：要么省略 scenes 渲整片，要么给出至少一个幕下标（0 基）')
    }
    const total = spec.scenes.length
    const bad = args.scenes.filter(i => !Number.isInteger(i) || i < 0 || i >= total)
    if (bad.length > 0) {
      throw new AnimOpError(`scenes 含越界下标 ${bad.join('、')}：本片共 ${total} 幕，合法范围 0~${total - 1}`)
    }
  }
  // 硬检 2：资产引用完整性。图层引用 asset:<id>（src）或按 assetId 引字体
  // （fontFamily），未登记/文件丢失的引用渲出来必然 404——此刻说最便宜。
  const assets = spec.assets
  const missing: string[] = []
  for (const scene of spec.scenes) {
    for (const layer of scene.layers) {
      const props = layer.props as Record<string, unknown>
      const label = `${scene.id}/${layer.id}`
      const src = typeof props.src === 'string' ? /^asset:(.+)$/.exec(props.src) : null
      if (src) {
        const id = src[1]!
        const asset = assets[id]
        if (!asset) {
          missing.push(`图层「${label}」引用的资产 ${id} 未登记（anim_asset_import 导入后再引用，或改 src 为直连路径）`)
        } else if (!/^https?:\/\//.test(asset.src) && !existsSync(asset.src)) {
          missing.push(`图层「${label}」引用的资产 ${id} 源文件不存在：${asset.src}（文件被移动或删除，重新 anim_asset_import 导入）`)
        }
      }
      const font = typeof props.fontFamily === 'string' ? props.fontFamily : ''
      if (font !== '' && assets[font]?.kind === 'font' && !/^https?:\/\//.test(assets[font]!.src) && !existsSync(assets[font]!.src)) {
        missing.push(`图层「${label}」引用的字体资产 ${font} 源文件不存在：${assets[font]!.src}`)
      }
    }
  }
  if (missing.length > 0) {
    throw new AnimOpError(`渲染预检失败（未开始渲染）：\n- ${missing.join('\n- ')}`)
  }
  // 软检：写库校验的警告族在渲染入口再报一次（模型写幕时可能没逐条处理）
  return validateSpec(spec).warnings
}

/**
 * 渲染成 MP4。
 *
 * 宿主提供 ctx.jobs 时走后台任务：工具立即返回 jobId，进度以 render-progress
 * 事件可见，模型用 job_output 收集结果、job_kill 终止。任务一旦发布，取消只认
 * 任务自己的 cancel 信号——外层 exec.signal 的取消只是不再等待，不杀已发布的
 * 工作（官方 jobs 文档写明的约定）。宿主没有 jobs 服务或发布失败时退回同步
 * 渲染：调用方 await 到出片为止，进度事件照发。
 */
export async function opRender(
  deps: AnimDeps,
  args: RenderArgs,
  signal: AbortSignal,
  emit: Emit,
  jobs?: AnimJobsService,
  owner?: unknown,
): Promise<RenderResultView | RenderBackgroundTicket> {
  const spec = deps.store.get(args.specId)
  const renderer = deps.renderers.get(args.renderer)
  // 重复发起护栏（0.6.0 §3.3）：软提示附进回执、高频硬拒绝，都在开跑前
  const verdict = checkRepeatGuard(
    deps,
    '渲染',
    args.specId,
    `${args.specId}|scenes=${JSON.stringify(args.scenes ?? null)}|out=${args.outputPath ?? ''}|cache=${args.cache ?? ''}`,
  )
  if (verdict.refuse) throw new AnimOpError(verdict.refuse)
  const guardNote = verdict.note
  // 渲染前预检（0.6.0 §4.1）：硬问题快速失败；软警告汇总进回执
  const preflightWarnings = preflightRender(deps, spec, args)
  // 切片渲染（scenes 选幕）不默认写正片路径：solo 出片与整片是两种产物，
  // 覆盖正片是真实事故（真机：8s 第一幕 solo 覆盖了 64.5s 成片，用户点开
  // 只见第一幕）。显式传了 outputPath 的调用者自己决定落点。
  // 相对路径在这里解析成绝对路径：ffmpeg 把相对路径按宿主进程 cwd 落盘，
  // 回执必须给出文件的真实位置——真机教训：回显 "x.mp4" 让模型在会话目录
  // 找不到文件，全盘搜索无果后只能重渲一遍。
  const outputPath = resolve(
    args.outputPath
      ?? (args.scenes?.length ? `${deps.outputDir}/${args.specId}-solo-${args.scenes.join('-')}.mp4` : `${deps.outputDir}/${args.specId}.mp4`),
  )
  if (signal.aborted) throw new AnimOpError('渲染已取消')
  // 渲染后未修改的语境提示（0.6.0 §3.1）：重渲未修改的 spec 会全量命中段缓存，
  // 明说「不会有新画面」，让「报告既有成片」成为默认动作
  const staleNote = staleRenderNote(deps, args.specId, '渲染')
  const extraWarnings = [...preflightWarnings, guardNote, staleNote].filter((w): w is string => w !== undefined)
  // 渲染状态投影（0.6.0 §3.1）：完成时写 lastRender，版本取开跑时的——
  // 渲染过程中 model patch（后台渲染完全可能）不算「渲染后修改」
  const specVersionAtStart = deps.store.record(args.specId).version
  const onRendered = (done: string): void => {
    try {
      deps.store.setLastRender(args.specId, { outputPath: done, finishedAt: Date.now(), specVersionAtRender: specVersionAtStart })
    } catch {
      /* spec 已被 drop 等边缘态：状态投影失败不拖垮渲染回执 */
    }
  }
  // 渲染前对账（0.4.0 规划 N3）：大纲与实际场景对不上时，此刻说比渲完说便宜
  const outline = deps.store.record(args.specId).outline
  const outlineNotes = outline !== undefined && outline.length > 0 ? reconcileOutline(outline, spec.scenes) : []

  // 旁白配音（0.5.0 §5）：spec 带 cues 且配置了 TTS 才合成（纯字幕模式是
  // 缺省）。合成立即开跑但只在渲染内部被 await——后台渲染时合成发生在
  // job 内，不占模型回合；缓存命中（同 text/voice/rate）时近乎免费。
  const speechBase = buildSpeech(spec, deps)
  // 切片渲染的语音对齐：语音 atMs 是全片绝对毫秒，solo/选幕渲的窗口却从 0
  // 重新计轴——不裁剪的话，窗口内 cue 带着原时轴延迟（错位到切片外），窗口
  // 外 cue 被 mux 的 -t 截在片尾。按选中幕的原始时段过滤并平移到切片时轴。
  const sliceScenes = args.scenes?.length ? args.scenes : undefined
  const speech = sliceScenes
    ? speechBase.then(build => (build ? sliceSpeechForScenes(build, spec, sliceScenes) : build))
    : speechBase

  if (jobs) {
    // 先带 owner（结果可归属、job_output/job_kill 的访问控制按 owner 走）；
    // owner 没有附加 job controller 时退到无主任务；再不行退同步渲染。
    // 失败原因落宿主日志——「jobs 在但 start 拒绝」的门控问题要能被看见。
    let lastError: unknown
    for (const ownerCandidate of [owner, undefined]) {
      try {
        const ticket = await startBackgroundRender(args, { spec, renderer, outputPath, outlineNotes, extraWarnings, speech, specVersionAtStart, onRendered }, emit, jobs, ownerCandidate)
        return extraWarnings.length > 0 ? { ...ticket, next: `${ticket.next} ⚠️${extraWarnings.join(' ')}` } : ticket
      } catch (err) {
        lastError = err
      }
    }
    console.warn(`[dsh-anim-studio] 后台渲染发布失败（owner 与无主两档均被拒），退回同步渲染：${lastError instanceof Error ? lastError.message : String(lastError)}`)
  }
  const view = await renderSync(args, { spec, renderer, outputPath, outlineNotes, extraWarnings, speech, specVersionAtStart, onRendered }, signal, emit)
  return view
}

/**
 * 旁白配音载荷构建（0.5.0 §5）：spec 带 narration.cues 且配置了 TTS 时，
 * 逐 cue 合成语音（按 text/voice/rate 缓存于 work/<specId>/tts/——与适配器
 * 的 specWorkDir 布局契约一致，键用 spec.meta.id）。任何构建期失败都降级为
 * 「带警告的无配音」，绝不阻塞渲染。
 */
function buildSpeech(spec: AnimationSpec, deps: AnimDeps): Promise<SpeechBuildResult | undefined> {
  const cues = spec.narration?.cues ?? []
  if (!deps.tts || cues.length === 0) return Promise.resolve(undefined)
  const cacheDir = join(deps.outputDir, 'work', safeName(spec.meta.id), 'tts')
  return synthesizeNarration(spec, deps.tts, cacheDir).catch(err => {
    const message = err instanceof Error ? err.message : String(err)
    return { tracks: [], displayMs: [], notes: [], warnings: [`旁白配音整体失败，本片为纯字幕：${message}`] }
  })
}

/**
 * 切片渲染的语音对齐：把全片时轴的语音轨过滤并平移到选中幕的切片窗口上。
 * notes 一并按窗口过滤（对账只报窗内 cue，atMs 保持全片绝对口径）；displayMs
 * 按 cue 下标与 narration 对齐，保持全量不动。
 */
export function sliceSpeechForScenes(build: SpeechBuildResult, spec: AnimationSpec, scenes: number[]): SpeechBuildResult {
  const picked = [...new Set(scenes)]
    .filter(i => Number.isInteger(i) && i >= 0 && i < spec.scenes.length)
    .sort((a, b) => a - b)
  if (picked.length === 0) return build
  const leadMs = spec.scenes.slice(0, picked[0]!).reduce((sum, s) => sum + sceneDurationMs(s), 0)
  const windowMs = picked.reduce((sum, i) => sum + sceneDurationMs(spec.scenes[i]!), 0)
  const windowEnd = leadMs + windowMs
  const inWindow = (start: number, duration: number): boolean => start < windowEnd && start + duration > leadMs
  return {
    ...build,
    tracks: build.tracks
      .filter(t => inWindow(t.startMs, t.durationMs))
      .map(t => ({
        ...t,
        startMs: Math.max(0, t.startMs - leadMs),
        durationMs: Math.min(t.durationMs, windowEnd - t.startMs),
      })),
    notes: build.notes.filter(n => inWindow(n.atMs, n.audioMs)),
  }
}

async function startBackgroundRender(
  args: RenderArgs,
  resolved: {
    spec: AnimationSpec
    renderer: AnimRenderer
    outputPath: string
    outlineNotes: string[]
    extraWarnings: string[]
    speech: Promise<SpeechBuildResult | undefined>
    specVersionAtStart: number
    onRendered: (outputPath: string) => void
  },
  emit: Emit,
  jobs: AnimJobsService,
  owner: unknown,
): Promise<RenderBackgroundTicket> {
  const { spec, renderer, outputPath, outlineNotes, extraWarnings, speech, specVersionAtStart, onRendered } = resolved
  const specId = args.specId
  const controller = new AbortController()
  const jobIdBox: { value: string | null } = { value: null }
  const gate = createRenderEventGate(emit, jobIdBox)
  const progress = createProgressReporter(specId, jobIdBox, gate.pass)

  const finishedId = (): string => jobIdBox.value ?? 'anim-render'
  const run = (): AnimJobHandle => ({
    cancel: (reason?: unknown) => {
      controller.abort(reason instanceof Error ? reason : new Error(reason ? String(reason) : '渲染任务被终止'))
    },
    done: (async () => {
      // 配音合成在 job 内 await：合成耗时（首次每条数秒）不占模型回合
      const speechBuild = await speech
      // 合成期间可能已被 cancel：信号已中止时不能再进渲染（监听器注册不上
      // 会永不落定），直接走 killed 路径——与「同步在 run() 里调 render」的
      // 旧时序等价
      if (controller.signal.aborted) throw new Error('渲染已取消')
      return renderer.render(
        {
          spec, outputPath, scenes: args.scenes, scale: args.scale, cache: args.cache, onProgress: progress,
          ...(speechBuild ? { speech: { tracks: speechBuild.tracks, displayMs: speechBuild.displayMs } } : {}),
        },
        controller.signal,
      )
    })()
      .then(
        async result => {
          const speechBuild = await speech
          // 渲染状态投影（0.6.0 §3.1）+ 完成视图（job_output 产物与同步回执同形）
          onRendered(result.outputPath)
          const view = buildRenderView(result, {
            warnings: [...(speechBuild?.warnings ?? []), ...(result.warnings ?? []), ...extraWarnings],
            outlineNotes,
          })
          gate.pass(() => ({
            type: 'anim/render-finished',
            data: {
              specId,
              jobId: finishedId(),
              outputPath: result.outputPath,
              frameCount: result.frameCount,
              durationMs: result.durationMs,
              width: result.width,
              height: result.height,
              ...((speechBuild?.warnings.length ?? 0) + (result.warnings?.length ?? 0) + extraWarnings.length > 0
                ? { warnings: [...(speechBuild?.warnings ?? []), ...(result.warnings ?? []), ...extraWarnings] }
                : {}),
              ...(result.incremental !== undefined ? { incremental: result.incremental } : {}),
              ...(result.audioTracks !== undefined && result.audioTracks.length > 0 ? { audioTracks: result.audioTracks } : {}),
              ...(result.contactSheet !== undefined ? { contactSheet: result.contactSheet } : {}),
              ...(speechBuild !== undefined && speechBuild.notes.length > 0 ? { speechNotes: speechBuild.notes } : {}),
              specVersion: specVersionAtStart,
              next: view.next,
            },
          }))
          return { status: 'completed' as const, output: view }
        },
        (err: unknown) => {
          const message = err instanceof Error ? err.message : String(err)
          if (controller.signal.aborted) {
            gate.pass(() => ({
              type: 'anim/render-finished',
              data: { specId, jobId: finishedId(), outputPath, status: 'killed' },
            }))
            return { status: 'killed' as const, detail: message }
          }
          gate.pass(() => ({
            type: 'anim/render-finished',
            data: { specId, jobId: finishedId(), outputPath, status: 'failed', error: message },
          }))
          return { status: 'failed' as const, detail: message }
        },
      ),
  })

  // await 兼容同步/异步两种 start 签名；发布失败向上抛，由 opRender 退回同步
  const jobId = await jobs.start({
    kind: 'anim-render',
    label: `渲染「${spec.meta.title}」(${specId}) → ${outputPath}`,
    // 无主任务按「省略 owner」的形状传，让宿主按缺省处理
    ...(owner === undefined ? {} : { owner }),
    run,
  })
  const id = typeof jobId === 'string' ? jobId : String(jobId ?? 'anim-render')
  jobIdBox.value = id
  emitRenderStart(emit, specId, id, outputPath, args)
  gate.flush()
  return {
    kind: 'background',
    jobId: id,
    specId,
    outputPath,
    next: `渲染已在后台进行（jobId: ${id}）。用 job_output 查询进度与收集结果；需要终止时用 job_kill。不要用 wait_agent 等待本任务，也不要重复发起同一渲染。`,
    ...(outlineNotes.length > 0 ? { outlineNotes } : {}),
  }
}

async function renderSync(
  args: RenderArgs,
  resolved: {
    spec: AnimationSpec
    renderer: AnimRenderer
    outputPath: string
    outlineNotes: string[]
    extraWarnings: string[]
    speech: Promise<SpeechBuildResult | undefined>
    specVersionAtStart: number
    onRendered: (outputPath: string) => void
  },
  signal: AbortSignal,
  emit: Emit,
): Promise<RenderResultView> {
  const { spec, renderer, outputPath, outlineNotes, extraWarnings, speech, specVersionAtStart, onRendered } = resolved
  const specId = args.specId
  const jobIdBox: { value: string | null } = { value: 'sync' }
  const gate = createRenderEventGate(emit, jobIdBox)
  const progress = createProgressReporter(specId, jobIdBox, gate.pass)
  emitRenderStart(emit, specId, 'sync', outputPath, args)
  try {
    const speechBuild = await speech
    const result = await renderer.render(
      {
        spec, outputPath, scenes: args.scenes, scale: args.scale, cache: args.cache, onProgress: progress,
        ...(speechBuild ? { speech: { tracks: speechBuild.tracks, displayMs: speechBuild.displayMs } } : {}),
      },
      signal,
    )
    onRendered(result.outputPath)
    const view = buildRenderView(result, {
      warnings: [...(speechBuild?.warnings ?? []), ...(result.warnings ?? []), ...extraWarnings],
      outlineNotes,
    })
    const warnings = view.warnings
    emit({
      type: 'anim/render-finished',
      data: {
        specId,
        jobId: 'sync',
        outputPath: result.outputPath,
        frameCount: result.frameCount,
        durationMs: result.durationMs,
        width: result.width,
        height: result.height,
        ...(warnings !== undefined && warnings.length > 0 ? { warnings } : {}),
        ...(result.incremental !== undefined ? { incremental: result.incremental } : {}),
        ...(result.audioTracks !== undefined && result.audioTracks.length > 0 ? { audioTracks: result.audioTracks } : {}),
        ...(result.contactSheet !== undefined ? { contactSheet: result.contactSheet } : {}),
        ...(speechBuild !== undefined && speechBuild.notes.length > 0 ? { speechNotes: speechBuild.notes } : {}),
        specVersion: specVersionAtStart,
        next: view.next,
      },
    })
    return view
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err)
    emit({
      type: 'anim/render-finished',
      data: { specId, jobId: 'sync', outputPath, status: 'failed', error: message },
    })
    throw err
  }
}

/* ------------------------------------------------------------------ 资产导入 */

export const ASSET_KINDS = ['image', 'svg', 'audio', 'font', 'video'] as const
export type AssetKind = (typeof ASSET_KINDS)[number]

/** 资产类型 → 可接受的扩展名（不含点）。 */
const ASSET_EXT: Record<AssetKind, string[]> = {
  image: ['png', 'jpg', 'jpeg', 'gif', 'webp'],
  svg: ['svg'],
  audio: ['mp3', 'wav', 'm4a', 'ogg', 'aac'],
  font: ['ttf', 'otf', 'woff', 'woff2'],
  video: ['mp4', 'webm', 'mov'],
}

export interface AssetImportArgs {
  specId: string
  assetId: string
  kind: AssetKind
  /** 本地文件路径或 http(s) URL。 */
  src: string
  alt?: string
}

export type AssetImportResult = {
  specId: string
  assetId: string
  kind: AssetKind
  /** 解析后的 src：本地文件复制到 <outputDir>/assets/ 的绝对路径；URL 原样。 */
  src: string
  next: string
}

/**
 * 登记一份资产进 spec.assets。
 *
 * 本地文件会被复制进插件的资产目录（<outputDir>/assets/），渲染时再复制进
 * 渲染项目（见 render-mc 的 copyAssetsToPublic）；http(s) URL 原样登记，
 * 渲染时浏览器直接加载。登记即写 spec（patch + 事件），撤销 / 回放天然可用。
 */
export function opAssetImport(deps: AnimDeps, args: AssetImportArgs, emit: Emit): AssetImportResult {
  if (!deps.store.has(args.specId)) throw new AnimOpError(`spec ${args.specId} 不存在，先调 anim_create_spec`)
  if (!ASSET_KINDS.includes(args.kind)) throw new AnimOpError(`资产类型应为 ${ASSET_KINDS.join(' / ')}，收到 ${String(args.kind)}`)
  if (!/^[A-Za-z0-9._-]+$/.test(args.assetId)) throw new AnimOpError('assetId 只能含字母/数字/._-（会被用作文件名与 URL）')
  if (deps.store.get(args.specId).assets[args.assetId]) {
    throw new AnimOpError(`资产 ${args.assetId} 已存在，覆盖请用 anim_patch 改 /assets/${args.assetId}`)
  }
  const ext = extname(args.src).slice(1).toLowerCase()
  if (!ASSET_EXT[args.kind].includes(ext)) {
    throw new AnimOpError(`资产类型 ${args.kind} 不支持扩展名 .${ext || '(无)'}，可选：${ASSET_EXT[args.kind].join(' / ')}`)
  }

  let resolvedSrc: string
  if (/^https?:\/\//.test(args.src)) {
    resolvedSrc = args.src
  } else {
    const abs = resolve(args.src)
    let stats
    try {
      stats = statSync(abs)
    } catch {
      throw new AnimOpError(`文件不存在：${abs}`)
    }
    if (!stats.isFile()) throw new AnimOpError(`不是文件（应为图片/音频等文件本身）：${abs}`)
    const dir = join(deps.outputDir, 'assets')
    mkdirSync(dir, { recursive: true })
    resolvedSrc = join(dir, `${safeName(args.assetId)}.${ext}`)
    copyFileSync(abs, resolvedSrc)
  }

  const value = { kind: args.kind, src: resolvedSrc, ...(args.alt === undefined ? {} : { alt: args.alt }) }
  const ops: PatchOp[] = [{ op: 'add', path: `/assets/${args.assetId}`, value: value as unknown as JsonValue }]
  const { inverse } = deps.store.patch(args.specId, ops, `导入资产 ${args.assetId}`)
  emit({
    type: 'anim/spec-patched',
    data: {
      specId: args.specId,
      ops,
      inverse,
      note: `导入资产 ${args.assetId}`,
      durationMs: deps.store.durationMs(args.specId),
    },
  })
  return {
    specId: args.specId,
    assetId: args.assetId,
    kind: args.kind,
    src: resolvedSrc,
    next: `资产 ${args.assetId} 已登记（${args.kind}）。在图层 props 里用 src="asset:${args.assetId}" 引用它。`,
  }
}

/* ------------------------------------------------------------------ 自检 */

/** 段缓存占用报告的一项（§3.4 配套）。 */
export interface CacheUsageEntry {
  /** work 下的 spec 目录名（safeName 后的 specId）。 */
  workDir: string
  segments: number
  bytes: number
}

/**
 * 段缓存磁盘占用：各 spec 目录的段数与体积，按体积降序。
 * 段缓存与 outputDir 产物同生命周期（spec 删除不回收，§3.3），
 * anim_diagnose 把占用说清楚，用户才知道磁盘去哪了。
 */
export function scanSegmentCache(outputDir: string): { specs: CacheUsageEntry[]; totalBytes: number } {
  const workRoot = join(outputDir, 'work')
  const specs: CacheUsageEntry[] = []
  let entries: string[] = []
  try {
    entries = readdirSync(workRoot)
  } catch {
    return { specs, totalBytes: 0 }
  }
  for (const name of entries) {
    const segDir = join(workRoot, name, 'segments')
    let files: string[] = []
    try {
      files = readdirSync(segDir).filter(f => f.endsWith('.mp4'))
    } catch {
      continue
    }
    if (files.length === 0) continue
    let bytes = 0
    for (const f of files) {
      try {
        bytes += statSync(join(segDir, f)).size
      } catch {
        /* 文件刚好被清了就少算它 */
      }
    }
    specs.push({ workDir: name, segments: files.length, bytes })
  }
  specs.sort((a, b) => b.bytes - a.bytes)
  return { specs, totalBytes: specs.reduce((acc, s) => acc + s.bytes, 0) }
}

export async function opDiagnose(
  deps: AnimDeps,
  args: { renderer?: string },
): Promise<{
  renderer: string
  ok: boolean
  issues: string[]
  /** 段缓存占用（§3.4 配套），没有任何缓存时缺省。 */
  cache?: { specs: CacheUsageEntry[]; totalBytes: number }
  /** 配音能力状态（0.5.0 §5）：未配置 = 纯字幕模式（设计内形态）。 */
  tts?: { configured: boolean; sessionId?: string }
}> {
  const renderer = deps.renderers.get(args.renderer)
  const d = await renderer.diagnose()
  const cache = scanSegmentCache(deps.outputDir)
  return {
    renderer: d.renderer,
    ok: d.ok,
    issues: d.issues,
    ...(cache.specs.length > 0 ? { cache } : {}),
    tts: { configured: deps.tts !== undefined },
  }
}
