// End-to-end commit test for @xia-sc/dsh-git (run: node test/commit.mjs).
//
// Unlike test/smoke.mjs, this file really spawns git: it drives the plugin's
// own `/dsh-git-rpc/commit` route against a throwaway repository and reads the
// message back with `git log --format=%B`. That round trip is the only way to
// catch the regression this test exists for — a subject+body message being
// rejected (or mangled by argv quoting) before git ever records it.
//
// It needs to spawn git with piped stdio, so it cannot run inside a sandbox
// that blocks that (EPERM). Run it where git is available.
import { execFile } from "node:child_process";
import { EventEmitter } from "node:events";
import { mkdtemp, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { apply } from "../lib/index.js";

let failures = 0;
function check(label, condition, detail) {
  if (condition) return;
  failures += 1;
  console.error(`FAIL ${label}${detail === undefined ? "" : `: ${detail}`}`);
}

/** Run git in the fixture repo and resolve stdout (rejects on failure). */
function git(cwd, args) {
  return new Promise((resolve, reject) => {
    execFile("git", args, { cwd, encoding: "utf8", windowsHide: true }, (error, stdout, stderr) => {
      if (error !== null) {
        reject(new Error(`${args.join(" ")}: ${stderr || error.message}`));
        return;
      }
      resolve(stdout);
    });
  });
}

// ── mount the plugin's route, capturing the handler ──────────────────────────
let route = null;
const ctx = {
  effect(fn) { return fn(); },
  get(name) { return name === "connection" ? { requestRejection: () => undefined } : undefined; },
  llm: { listProviders: () => [], listModels: async () => [], stream: async function* () {} },
  webServer: { register(candidate) { route = candidate; return () => { route = null; }; } }
};
apply(ctx);
if (route === null) throw new Error("no route registered");

let rpcSeq = 0;
/** One endpoint call exactly as `connection.rpc.call` performs it. */
async function call(endpoint, args) {
  const rpcId = `commit-${++rpcSeq}`;
  const req = new EventEmitter();
  req.url = `/dsh-git-rpc/${endpoint}`;
  req.method = "POST";
  req.headers = { "content-type": "application/json" };
  req.resume = () => {};
  const res = new EventEmitter();
  const out = [];
  res.writableEnded = false;
  res.statusCode = 0;
  res.setHeader = () => {};
  res.end = (chunk) => { if (chunk !== undefined) out.push(String(chunk)); res.writableEnded = true; };
  const pending = route.handler(req, res);
  req.emit("data", Buffer.from(JSON.stringify({ type: "client-request", rpcId, method: endpoint, payload: { args } }), "utf8"));
  req.emit("end");
  await pending;
  const envelope = JSON.parse(out.join(""));
  if (envelope.type !== "server-response" || envelope.rpcId !== rpcId) {
    throw new Error(`${endpoint}: bad envelope ${out.join("")}`);
  }
  return envelope.result;
}

const pluginCode = (res) => (res && res.error && res.error.details ? res.error.details.code : null);

// ── fixture repository ───────────────────────────────────────────────────────
const repo = await mkdtemp(join(tmpdir(), "dsh-git-commit-"));
try {
  await git(repo, ["init", "--quiet"]);
  await git(repo, ["config", "user.name", "dsh-git test"]);
  await git(repo, ["config", "user.email", "dsh-git@example.invalid"]);

  /** Stage one new file so the next commit has something to record. */
  async function stageOne(name) {
    await writeFile(join(repo, name), `${name}\n`, "utf8");
    await git(repo, ["add", "--all"]);
  }

  const headMessage = async () => (await git(repo, ["log", "-1", "--format=%B"])).replace(/\n+$/, "");

  // ── the regression: a subject + body message must commit verbatim ──────────
  // This is exactly the shape `generateMessage` asks the model for, and the
  // shape the panel's ✨ button fills in.
  for (const [label, message, expected] of [
    ["single line", "feat: add single line", "feat: add single line"],
    ["subject + body", "feat: add body\n\nIt explains why.\n\nAnd more.", "feat: add body\n\nIt explains why.\n\nAnd more."],
    ["no blank separator", "subject\nbody", "subject\nbody"],
    ["CRLF from a Windows draft", "subject\r\n\r\nbody", "subject\n\nbody"],
    ["extra blank lines collapse", "subject\n\n\n\nbody", "subject\n\nbody"],
    ["leading/trailing blanks stripped", "\n\nsubject\n\nbody\n\n\n", "subject\n\nbody"],
    ["indented body line keeps its tab", "subject\n\n\tindented", "subject\n\n\tindented"],
    ["unicode subject", "feat: 支持多行提交信息\n\n正文说明", "feat: 支持多行提交信息\n\n正文说明"],
    ["leading dash is data, not a flag", "--amend is not run", "--amend is not run"],
    ["message with quotes", 'fix: handle "quoted" and \'single\' text', 'fix: handle "quoted" and \'single\' text'],
    ["message with shell metacharacters", "fix: a && b | c > d ; rm -rf /", "fix: a && b | c > d ; rm -rf /"],
    ["message with a percent sign", "fix: 100% done", "fix: 100% done"]
  ]) {
    await stageOne(`${label.replace(/[^a-z0-9]+/gi, "-")}.txt`);
    const res = await call("commit", { cwd: repo, message });
    if (res.ok !== true) {
      check(`commit records ${label}`, false, JSON.stringify(res));
      continue;
    }
    const recorded = await headMessage();
    check(`commit records ${label} byte-for-byte`, recorded === expected, `expected ${JSON.stringify(expected)}, recorded ${JSON.stringify(recorded)}`);
  }

  // ── rejected messages never create a commit ────────────────────────────────
  for (const [label, message] of [
    ["empty", ""],
    ["whitespace only", "   \n  "],
    ["NUL", "a\u0000b"],
    ["escape", "a\u001bb"],
    ["DEL", "a\u007fb"],
    ["over-long", "x".repeat(10001)],
    ["not a string", 42]
  ]) {
    const before = await git(repo, ["rev-parse", "HEAD"]);
    const res = await call("commit", { cwd: repo, message });
    check(`reject ${label}`, res.ok !== true && pluginCode(res) === "invalid-message", JSON.stringify(res));
    const after = await git(repo, ["rev-parse", "HEAD"]);
    check(`reject ${label} creates no commit`, before === after);
  }

  // ── a commit with nothing staged fails cleanly, keeping git's own words ────
  {
    const res = await call("commit", { cwd: repo, message: "nothing staged" });
    check("clean tree reports commit-failed", res.ok !== true && pluginCode(res) === "commit-failed", JSON.stringify(res));
  }

  // ── amend rewrites HEAD through the same message path ─────────────────────
  // The panel pre-fills HEAD's message into the composer, so the endpoint only
  // has to take that message and rewrite the commit: same count, new oid, and
  // whatever is staged (including a file staged after the original commit) is
  // folded into the replacement.
  {
    const beforeCount = (await git(repo, ["rev-list", "--count", "HEAD"])).trim();
    const beforeSha = (await git(repo, ["rev-parse", "HEAD"])).trim();
    await stageOne("amended.txt");
    const res = await call("commit", { cwd: repo, message: "feat: amended subject\n\nNew body.", amend: true });
    check("amend succeeds", res.ok === true, JSON.stringify(res));
    check("amend keeps the commit count", (await git(repo, ["rev-list", "--count", "HEAD"])).trim() === beforeCount);
    const afterSha = (await git(repo, ["rev-parse", "HEAD"])).trim();
    check("amend replaces the commit", afterSha !== beforeSha, `${beforeSha} -> ${afterSha}`);
    check("amend records the given message", (await headMessage()) === "feat: amended subject\n\nNew body.");
    const tree = await git(repo, ["ls-tree", "--name-only", "HEAD"]);
    check("amend folds in the newly staged file", tree.includes("amended.txt"), tree.trim());
  }
  {
    const res = await call("commit", { cwd: repo, message: "  ", amend: true });
    check("amend rejects an empty message", res.ok !== true && pluginCode(res) === "invalid-message", JSON.stringify(res));
  }
  // An unborn branch has nothing to rewrite: the panel disables the switch when
  // `headMessage` answers no-commit, and the commit path must agree.
  {
    const emptyRepo = await mkdtemp(join(tmpdir(), "dsh-git-amend-empty-"));
    try {
      await git(emptyRepo, ["init", "--quiet"]);
      await git(emptyRepo, ["config", "user.name", "dsh-git test"]);
      await git(emptyRepo, ["config", "user.email", "dsh-git@example.invalid"]);
      const res = await call("commit", { cwd: emptyRepo, message: "no commit", amend: true });
      check("amend without HEAD reports no-commit", res.ok !== true && pluginCode(res) === "no-commit", JSON.stringify(res));
      const head = await call("headMessage", { cwd: emptyRepo });
      check("headMessage without HEAD reports no-commit", head.ok !== true && pluginCode(head) === "no-commit", JSON.stringify(head));
      const amendCheckEmpty = await call("amendCheck", { cwd: emptyRepo });
      check("amendCheck without HEAD reports no-commit", amendCheckEmpty.ok !== true && pluginCode(amendCheckEmpty) === "no-commit", JSON.stringify(amendCheckEmpty));
    } finally {
      await rm(emptyRepo, { recursive: true, force: true });
    }
  }
  // headMessage returns the message git recorded, byte for byte.
  {
    const head = await call("headMessage", { cwd: repo });
    check("headMessage returns the last message", head.ok === true && head.value.message === "feat: amended subject\n\nNew body.", JSON.stringify(head));
  }

  // ── amendCheck: is HEAD already on a remote? ──────────────────────────────
  // The panel asks before entering amend mode: rewriting a published commit
  // makes the next push a force push, which this plugin never performs. The
  // answer comes from the local remote-tracking refs (no fetch, no network), so
  // it uses the same view as every other command here. A remote-tracking ref is
  // created with update-ref instead of a real push: same ref, no network.
  {
    const noRemote = await call("amendCheck", { cwd: repo });
    check("amendCheck reports an unpublished HEAD", noRemote.ok === true && noRemote.value.pushed === false, JSON.stringify(noRemote));
    check("amendCheck names no refs without one", noRemote.ok === true && Array.isArray(noRemote.value.refs) && noRemote.value.refs.length === 0, JSON.stringify(noRemote));

    const bare = await mkdtemp(join(tmpdir(), "dsh-git-amendcheck-bare-"));
    try {
      await git(bare, ["init", "--bare", "--quiet"]);
      await git(repo, ["remote", "add", "origin", bare]);
      const branch = (await git(repo, ["rev-parse", "--abbrev-ref", "HEAD"])).trim();
      const head = (await git(repo, ["rev-parse", "HEAD"])).trim();
      await git(repo, ["update-ref", `refs/remotes/origin/${branch}`, head]);
      await git(repo, ["branch", "--set-upstream-to", `origin/${branch}`, branch]);
      const published = await call("amendCheck", { cwd: repo });
      check("amendCheck reports a published HEAD", published.ok === true && published.value.pushed === true, JSON.stringify(published));
      check("amendCheck names the remote ref", published.ok === true && published.value.refs.includes(`origin/${branch}`), JSON.stringify(published));
      check("amendCheck reports the tracking upstream", published.ok === true && published.value.upstream === `origin/${branch}`, JSON.stringify(published));
      // A commit made on top of the published one is unpublished again.
      await stageOne("unpublished.txt");
      await call("commit", { cwd: repo, message: "chore: local only" });
      const local = await call("amendCheck", { cwd: repo });
      check("amendCheck reports a new local HEAD as unpublished", local.ok === true && local.value.pushed === false, JSON.stringify(local));
    } finally {
      await git(repo, ["remote", "remove", "origin"]).catch(() => {});
      await rm(bare, { recursive: true, force: true });
    }
  }
} finally {
  await rm(repo, { recursive: true, force: true });
}

if (failures > 0) {
  console.error(`\n${failures} COMMIT TEST(S) FAILED`);
  process.exit(1);
}
console.log("COMMIT END-TO-END TESTS PASSED (message shapes, rejection, clean-tree failure)");
