﻿<#
.SYNOPSIS
  Open the awesome-dsh-plugin listing pull request for this plugin.

.DESCRIPTION
  The curated list is data-driven: a submission is ONE file,
  data/plugins/<owner>__<repo>.yml in awesome-dsh-plugin/awesome-dsh-plugin.
  Its READMEs are generated from those files, so a submission never conflicts
  with anyone else's.

  This fork/branch/commit/PR flow is a convenience; the same result is three
  clicks on github.com: fork the list, "Add file -> Create new file" at the
  target path, paste the entry, "Propose new file".

  WHY THIS CAN REFUSE TO RUN: the list's CI checks repo age BEFORE anything
  else and rejects repositories younger than 1 day, to filter out repos created
  minutes before the PR. Running early cannot succeed, so this checks the same
  thing first and tells you when to come back.

.PARAMETER DryRun
  Do the reads, print the writes, change nothing.

.EXAMPLE
  $env:GH_PUSH_TOKEN = '<a token with public_repo scope>'
  pwsh -File tools/submit-to-market.ps1 -DryRun
#>
[CmdletBinding()]
param(
  [string]$Token = $env:GH_PUSH_TOKEN,
  [string]$Entry = 'tools/market/MistyRain-field__dsh-hu-tao-skin.yml',
  [string]$UpstreamOwner = 'awesome-dsh-plugin',
  [string]$UpstreamRepo = 'awesome-dsh-plugin',
  [switch]$DryRun
)

$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
if (-not $Token) { throw 'No token. Set $env:GH_PUSH_TOKEN to one with public_repo scope.' }

$repoRoot  = Split-Path -Parent $PSScriptRoot
$entryPath = Join-Path $repoRoot $Entry
if (-not (Test-Path $entryPath)) { throw "entry file not found: $entryPath" }
$entryText = [System.IO.File]::ReadAllText($entryPath)
$entryName = Split-Path -Leaf $entryPath
$fileOwner = ($entryName -split '__')[0]
$fileRepo  = ($entryName -split '__')[1] -replace '\.yml$', ''
$targetPath = 'data/plugins/' + $fileOwner + '__' + $fileRepo + '.yml'
$branch     = 'add-' + $fileRepo
$bodyText   = [System.IO.File]::ReadAllText((Join-Path $PSScriptRoot 'market\pr-body.md'))

$api = 'https://api.github.com'
$headers = @{ Authorization = "token $Token"; 'User-Agent' = 'dsh-hu-tao-skin'; Accept = 'application/vnd.github+json' }

# PS 5.1 sends a string -Body using the ANSI code page, which would corrupt the
# entry's Chinese description. A BOM-less UTF-8 file with -InFile is exact.
function New-ApiBody($obj) {
  $p = Join-Path $env:TEMP ('gh-body-' + [guid]::NewGuid().ToString('N') + '.json')
  [System.IO.File]::WriteAllText($p, ($obj | ConvertTo-Json -Depth 8), (New-Object System.Text.UTF8Encoding($false)))
  return $p
}
function Invoke-Api {
  param([string]$Method, [string]$Uri, $Body)
  if ($Method -ne 'GET' -and $DryRun) {
    Write-Host "   [dry-run] $Method $Uri"
    return $null
  }
  $params = @{ Uri = $Uri; Method = $Method; Headers = $headers }
  if ($null -ne $Body) {
    $params.ContentType = 'application/json; charset=utf-8'
    $params.InFile = (New-ApiBody $Body)
  }
  Invoke-RestMethod @params
}

Write-Host '== 1. who am I =='
$me = Invoke-Api GET "$api/user"
Write-Host "   $($me.login)"

Write-Host '== 2. repo age gate (the list CI checks this first) =='
$target  = Invoke-Api GET "$api/repos/$fileOwner/$fileRepo"
$created = ([datetime]$target.created_at).ToUniversalTime()
$age     = (Get-Date).ToUniversalTime() - $created
Write-Host "   $fileOwner/$fileRepo created $($created.ToString('u'))  ($([math]::Round($age.TotalHours,1)) h old)"
if ($age.TotalDays -lt 1) {
  throw ('repo is under the 1-day bar, so the list CI would reject this PR. ' +
         'Come back after ' + $created.AddDays(1).ToString('u') + '.')
}
Write-Host '   age OK'

Write-Host '== 3. fork the list =='
$fork = $null
try { $fork = Invoke-Api GET "$api/repos/$($me.login)/$UpstreamRepo" } catch {}
if ($null -eq $fork) {
  Invoke-Api POST "$api/repos/$UpstreamOwner/$UpstreamRepo/forks" | Out-Null
  if (-not $DryRun) {
    for ($i = 0; $i -lt 20; $i++) {
      Start-Sleep -Seconds 3
      try { $null = Invoke-Api GET "$api/repos/$($me.login)/$UpstreamRepo"; break } catch {}
    }
  }
}
Write-Host "   $($me.login)/$UpstreamRepo"

Write-Host '== 4. branch off the default branch =='
$info = Invoke-Api GET "$api/repos/$UpstreamOwner/$UpstreamRepo"
$base = $info.default_branch
$baseRef = Invoke-Api GET "$api/repos/$UpstreamOwner/$UpstreamRepo/git/ref/heads/$base"
# Never reset a branch that backs an OPEN pull request: that rewrites the PR's
# only commit out from under it. Reset only when there is no open PR to
# preserve - a first submission, or one whose predecessor was merged or closed.
$openPr = @()
# PowerShell 5.1 turns an empty JSON array into $null, and @($null).Count is 1 -
# so an empty result must be normalised explicitly or "no open PR" reads as one.
$rawOpen = $null
try { $rawOpen = Invoke-Api GET "$api/repos/$UpstreamOwner/$UpstreamRepo/pulls?head=$($me.login):$branch&state=open" } catch {}
$openPr = if ($null -eq $rawOpen) { @() } else { @($rawOpen) }
$branchRef = $null
try { $branchRef = Invoke-Api GET "$api/repos/$($me.login)/$UpstreamRepo/git/ref/heads/$branch" } catch {}
if ($null -ne $branchRef -and $openPr.Count -gt 0) {
  Write-Host "   $branch backs open PR #$($openPr[0].number) - committing onto it as-is"
} elseif ($null -ne $branchRef) {
  Write-Host "   $branch exists but backs no open PR - rebasing it onto $base"
  Invoke-Api PATCH "$api/repos/$($me.login)/$UpstreamRepo/git/refs/heads/$branch" @{ sha = $baseRef.object.sha; force = $true } | Out-Null
} else {
  Invoke-Api POST "$api/repos/$($me.login)/$UpstreamRepo/git/refs" @{ ref = 'refs/heads/' + $branch; sha = $baseRef.object.sha } | Out-Null
  Write-Host "   created $branch off $base"
}

Write-Host '== 5. commit the entry =='
$payload = @{
  message = 'Add ' + $fileOwner + '/' + $fileRepo
  content = [Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes($entryText))
  branch  = $branch
}
$fileInfo = $null
# Build the URL in a variable: in argument mode PowerShell passes `+` through
# literally, so `... "url" + '?ref=' + $branch` arrives as extra arguments and
# the sha lookup silently fails - which then makes the PUT 422 on an existing
# file ("sha wasn't supplied").
$shaUri = "$api/repos/$($me.login)/$UpstreamRepo/contents/$targetPath" + '?ref=' + $branch
try { $fileInfo = Invoke-Api GET $shaUri } catch {}
if ($null -ne $fileInfo) { $payload.sha = $fileInfo.sha }
Invoke-Api PUT "$api/repos/$($me.login)/$UpstreamRepo/contents/$targetPath" $payload | Out-Null
Write-Host "   $targetPath"

Write-Host '== 6. open (or refresh) the pull request =='
# Re-running must UPDATE the open PR, not fail on it. POST /pulls answers 422
# ("A pull request already exists") for a head branch that already has one, and
# that is exactly the situation after a reviewer asks for a wording change:
# edit tools/market/<entry>.yml, re-run this, and the same PR gains the commit.
$open = @()
$rawOpen2 = $null
try { $rawOpen2 = Invoke-Api GET "$api/repos/$UpstreamOwner/$UpstreamRepo/pulls?head=$($me.login):$branch&state=open" } catch {}
$open = if ($null -eq $rawOpen2) { @() } else { @($rawOpen2) }
if ($open.Count -gt 0) {
  Write-Host "   PR already open - the commit above updated it: $($open[0].html_url)"
} elseif ($DryRun) {
  Write-Host '   [dry-run] would open the PR'
} else {
  $pr = Invoke-Api POST "$api/repos/$UpstreamOwner/$UpstreamRepo/pulls" @{
    title = 'Add ' + $fileOwner + '/' + $fileRepo
    head  = $me.login + ':' + $branch
    base  = $base
    body  = $bodyText
    maintainer_can_modify = $true
  }
  Write-Host "   $($pr.html_url)"
}

Get-ChildItem (Join-Path $env:TEMP 'gh-body-*.json') -ErrorAction SilentlyContinue | Remove-Item -Force -ErrorAction SilentlyContinue