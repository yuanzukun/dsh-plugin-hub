// Repo-local CI gate: packaging contract, hygiene, and market readiness.
// Dependency-free and profile-free, so it runs on a bare checkout.
import { existsSync, readFileSync, readdirSync, statSync } from "node:fs"
import { dirname, join, relative, sep } from "node:path"
import { fileURLToPath } from "node:url"

const ROOT = join(dirname(fileURLToPath(import.meta.url)), "..")
let failures = 0
const ok = (label, value) => console.log("   PASS  " + label + (value === undefined ? "" : ": " + value))
const bad = (label, value) => { failures++; console.log("   FAIL  " + label + (value === undefined ? "" : ": " + value)) }
const section = (title) => console.log("\n-- " + title + " --")
const readJson = (p) => JSON.parse(readFileSync(p, "utf8").replace(/^\uFEFF/, ""))

/** Every file under ROOT except the ones a checkout should not carry. */
function walk(dir, out = []) {
  for (const name of readdirSync(dir)) {
    if (name === ".git" || name === "node_modules") continue
    const full = join(dir, name)
    if (statSync(full).isDirectory()) walk(full, out)
    else out.push(relative(ROOT, full).split(sep).join("/"))
  }
  return out
}
const files = walk(ROOT)

// ── packaging contract ──────────────────────────────────────────────────────
section("packaging contract")
let manifest
try {
  manifest = readJson(join(ROOT, "package.json"))
  ok("package.json parses")
} catch (err) { bad("package.json parses", err.message) }

if (manifest !== undefined) {
  const name = manifest.name
  if (name) ok("name", name); else bad("name", "missing")
  if (manifest.license) ok("license", manifest.license); else bad("license", "missing")
  if (manifest.repository?.url) ok("repository", manifest.repository.url); else bad("repository", "missing")

  // dsh.bundle is what makes the plugin installable with `dsh plugin add`.
  const patch = manifest.dsh?.bundle?.patch
  if (patch) ok("dsh.bundle.patch", patch)
  else bad("dsh.bundle.patch", "missing - a dsh.client-only package is NOT installable")

  if (patch !== undefined) {
    const patchPath = join(ROOT, patch)
    if (existsSync(patchPath)) {
      const text = readFileSync(patchPath, "utf8")
      const rowId = /-\s*id:\s*(\S+)/.exec(text)?.[1]
      const rowName = /name:\s*(\S+)/.exec(text)?.[1]
      if (rowId === name && rowName === name) ok("cordis.patch.yml row", "id=" + rowId + " name=" + rowName)
      else bad("cordis.patch.yml row", "id=" + rowId + " name=" + rowName + " (must equal " + name + ")")
    } else bad("patch file exists", patch)
  }

  const decl = manifest.dsh?.client
  if (decl?.platform === "web") ok("dsh.client.platform", decl.platform)
  else if (decl === undefined) ok("dsh.client", "absent (host-only plugin)")
  else bad("dsh.client.platform", JSON.stringify(decl))

  if (decl !== undefined) {
    const ex = manifest.exports?.["./client"]
    const rel = typeof ex === "string" ? ex : ex?.default
    if (typeof rel === "string" && existsSync(join(ROOT, rel))) {
      ok("exports['./client']", rel)
      const body = readFileSync(join(ROOT, rel), "utf8")
      const declared = /id:\s*"([^"]+)"/.exec(body)?.[1]
      if (declared === name) ok("browser module id === package name", declared)
      else bad("browser module id", declared + " !== " + name)
      if (body.includes("__ModuleLoader__.load")) ok("module-loader wrapper", "present")
      else bad("module-loader wrapper", "missing")
    } else bad("exports['./client']", String(rel))
  }
}

// ── hygiene ─────────────────────────────────────────────────────────────────
section("hygiene")
const dshRead = files.filter((f) => /^(package\.json|screenshots\.json|cordis\.patch\.yml|lib\/)/.test(f))
const withBom = dshRead.filter((f) => readFileSync(join(ROOT, f)).subarray(0, 3).toString("hex") === "efbbbf")
if (withBom.length === 0) ok("no UTF-8 BOM in files DSH parses", dshRead.length + " checked")
else bad("no UTF-8 BOM in files DSH parses", withBom.join(", "))

const SECRET = /(ghp_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,}|sk-[A-Za-z0-9]{20,}|AKIA[0-9A-Z]{16})/
const PERSONAL = /(C:\\\\Users\\\\|D:\\\\tool\\\\AI|\/Users\/[a-z0-9._-]+\/|\/home\/[a-z0-9._-]+\/)/
const leaked = []
const personal = []
for (const f of files) {
  if (/\.(png|jpg|jpeg|gif|webp|ico)$/i.test(f)) continue
  const text = readFileSync(join(ROOT, f), "utf8")
  if (SECRET.test(text)) leaked.push(f)
  if (PERSONAL.test(text)) personal.push(f)
}
if (leaked.length === 0) ok("no credential-shaped strings", files.length + " files scanned")
else bad("no credential-shaped strings", leaked.join(", "))
if (personal.length === 0) ok("no personal absolute paths")
else bad("no personal absolute paths", personal.join(", "))

// ── market readiness ────────────────────────────────────────────────────────
section("market readiness")
if (existsSync(join(ROOT, "screenshots.json"))) {
  const shots = readJson(join(ROOT, "screenshots.json"))
  const list = Array.isArray(shots) ? shots : shots.screenshots
  if (!Array.isArray(list)) bad("screenshots.json", "not an array")
  else if (list.length < 1 || list.length > 8) bad("screenshots.json count", list.length + " (market allows 1-8)")
  else {
    const badPath = list.find((p) => typeof p !== "string" || p.startsWith("/") || p.includes("..") || !existsSync(join(ROOT, p)))
    if (badPath === undefined) ok("screenshots.json", list.length + " images, all present and relative")
    else bad("screenshots.json entry", String(badPath))
  }
} else console.log("   SKIP  screenshots.json (optional)")

// How many alias tokens the browser half actually overrides.
const tokenCount = (readFileSync(join(ROOT, "lib/client.js"), "utf8").match(/"--dsw-[a-z0-9-]+":\s*\{\s*light:/g) ?? []).length

const entries = files.filter((f) => f.startsWith("tools/market/") && f.endsWith(".yml"))
if (entries.length === 0) console.log("   SKIP  market entry")
for (const entry of entries) {
  const text = readFileSync(join(ROOT, entry), "utf8")
  const field = (k) => new RegExp("^" + k + ":\\s*(.+)$", "m").exec(text)?.[1]?.trim().replace(/^['"]|['"]$/g, "")
  const url = field("url")
  const category = field("category")
  const en = /^\s*en:\s*(.+)$/m.exec(text)?.[1]?.trim().replace(/^['"]|['"]$/g, "")
  const CATEGORIES = ["agi", "ui", "usage", "theme", "model", "identity", "session", "memory", "tools", "wsl", "browser", "vision", "voice", "docs", "skill", "workflow", "git", "notify", "dev", "security", "remote", "market", "fun"]
  if (url && manifest !== undefined && url.replace(/\/$/, "") === (manifest.repository?.url ?? "").replace(/^git\+/, "").replace(/\.git$/, "").replace(/\/$/, "")) {
    ok(entry + " url matches repository", url)
  } else bad(entry + " url", String(url))
  if (CATEGORIES.includes(category)) ok(entry + " category", category)
  else bad(entry + " category", String(category))
  if (en && en.endsWith(".")) ok(entry + " description.en ends with a period")
  else bad(entry + " description.en", String(en))
  if (/:\s/.test(en ?? "")) {
    const quoted = /en:\s*['"]/.test(text)
    if (quoted) ok(entry + " colon-space is quoted", "yes")
    else bad(entry + " colon-space must be quoted", en)
  }

  // The listing review reads every claim in the entry against the code, and
  // names an inaccurate description as the usual reason an otherwise-good
  // plugin is sent back. The one number in ours is the token count, so tie it
  // to the source instead of trusting the prose.
  const claimed = /(\d+)-token/.exec(en ?? "")?.[1]
  if (claimed !== undefined) {
    if (Number(claimed) === tokenCount) ok(entry + " token count matches lib/client.js", claimed)
    else bad(entry + " token count", claimed + " claimed, " + tokenCount + " in lib/client.js")
  }
}

console.log(failures === 0 ? "\n   RESULT: OK" : "\n   RESULT: " + failures + " FAILURE(S)")
process.exitCode = failures === 0 ? 0 : 1