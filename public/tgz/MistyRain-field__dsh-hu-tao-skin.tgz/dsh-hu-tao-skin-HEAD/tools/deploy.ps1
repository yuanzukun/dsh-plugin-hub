# Install (or reinstall) this plugin package into a dsh profile.
#
#   pwsh -File tools/deploy.ps1 [-ProfileDir <dir>] [-ProfileName web]
#
# Profile default: $env:DSH_PROFILE_DIR, else $env:DSH_HOME\profiles\<name>,
# else $HOME\.dsh\profiles\<name>. Idempotent.
#
# Only the runtime files are copied (package.json, cordis.patch.yml, README.md,
# lib/) - never tools/ or .git/. A directory junction links the profile's
# node_modules at the installed copy.
#
# Two Windows-PowerShell traps this script deliberately avoids:
#  1. `Set-Content -Encoding utf8` writes a UTF-8 BOM here, and DSH's modules
#     scanner reads a row's manifest with JSON.parse(readFileSync(pkg, "utf8")).
#     A BOM throws there and the GUI never boots, so the manifest is written
#     through an explicit BOM-less encoder.
#  2. A .ps1 kept as BOM-less UTF-8 is read back by Get-Content under the ANSI
#     code page, which mangles non-ASCII paths. Read this file with
#     -Encoding UTF8 (and leave its own BOM alone).
[CmdletBinding()]
param(
  [string]$ProfileDir,
  [string]$ProfileName = 'web'
)

$ErrorActionPreference = 'Stop'
$utf8NoBom = New-Object System.Text.UTF8Encoding($false)
$repo = Split-Path -Parent $PSScriptRoot

if (-not $ProfileDir) {
  $dshHome = if ($env:DSH_HOME) { $env:DSH_HOME } else { Join-Path $HOME '.dsh' }
  $ProfileDir = if ($env:DSH_PROFILE_DIR) { $env:DSH_PROFILE_DIR } else { Join-Path $dshHome "profiles\$ProfileName" }
}
$dest     = Join-Path $ProfileDir 'local-plugins\dsh-hu-tao-skin'
$manifest = Join-Path $ProfileDir 'package.json'
$link     = Join-Path $ProfileDir 'node_modules\dsh-hu-tao-skin'

Write-Host "repo    : $repo"
Write-Host "profile : $ProfileDir"

Write-Host '== 1. install runtime files =='
if (Test-Path $dest) { Remove-Item $dest -Recurse -Force }
New-Item -ItemType Directory -Force -Path (Join-Path $dest 'lib') | Out-Null
foreach ($file in @('package.json', 'cordis.patch.yml', 'README.md')) {
  Copy-Item (Join-Path $repo $file) $dest -Force
}
Copy-Item (Join-Path $repo 'lib\*') (Join-Path $dest 'lib') -Force
Get-ChildItem $dest -Recurse -File | ForEach-Object {
  $b = [System.IO.File]::ReadAllBytes($_.FullName)
  $bom = ($b.Length -ge 3 -and $b[0] -eq 0xEF -and $b[1] -eq 0xBB -and $b[2] -eq 0xBF)
  Write-Host ('   ' + $_.FullName.Substring($dest.Length + 1) + '  (' + $_.Length + ' B' + $(if ($bom) { ', BOM!' } else { '' }) + ')')
}

Write-Host '== 2. patch the profile manifest =='
if (-not (Test-Path $manifest)) { throw "no profile manifest at $manifest - is this a dsh profile directory?" }
if (([System.IO.File]::ReadAllText($manifest) | ConvertFrom-Json).dependencies.'dsh-hu-tao-skin') {
  Write-Host '   already patched - no new backup'
} else {
  $backup = "$manifest.bak-$(Get-Date -Format 'yyyyMMdd-HHmmss')"
  Copy-Item $manifest $backup -Force
  Write-Host "   backup -> $backup"
}
$json = [System.IO.File]::ReadAllText($manifest) | ConvertFrom-Json
$json.dependencies | Add-Member -NotePropertyName 'dsh-hu-tao-skin' -NotePropertyValue 'link:./local-plugins/dsh-hu-tao-skin' -Force
if ($json.dsh.profile.bundles -notcontains 'dsh-hu-tao-skin') {
  $json.dsh.profile.bundles = @($json.dsh.profile.bundles) + 'dsh-hu-tao-skin'
}
[System.IO.File]::WriteAllText($manifest, ($json | ConvertTo-Json -Depth 10), $utf8NoBom)
Write-Host ('   bundles: ' + ($json.dsh.profile.bundles -join ', '))

Write-Host '== 3. link into node_modules =='
# "The command succeeded" is NOT proof the package became reachable. On Linux,
# New-Item -ItemType Junction reports success while creating nothing at all, and
# Node then cannot resolve the row - a green install that does not install. So
# confirm by looking at the result, and fall back to a real copy when the link
# did not materialise. Every platform agrees on whether a file is there.
$entryFile    = Join-Path (Join-Path $link 'lib') 'index.js'
$manifestFile = Join-Path $link 'package.json'
$present = { (Test-Path $manifestFile) -and (Test-Path $entryFile) }

New-Item -ItemType Directory -Force -Path (Split-Path $link) | Out-Null
if (Test-Path $link) { Remove-Item $link -Recurse -Force }
try {
  New-Item -ItemType Junction -Path $link -Target $dest -ErrorAction Stop | Out-Null
  Write-Host "   junction: $link -> $dest"
} catch {
  Write-Host "   junction refused ($($_.Exception.Message.Trim()))"
}
if (-not (& $present)) {
  Write-Host '   link did not materialise - falling back to a copy'
  if (Test-Path $link) { Remove-Item $link -Recurse -Force }
  Copy-Item $dest $link -Recurse -Force
  Write-Host "   copied: $link"
  Write-Host '   (a copy resolves exactly like a link; it just stops tracking the source)'
}
if (-not (& $present)) { throw "install incomplete: $link does not hold the package" }
Write-Host '   package is present under node_modules'

Write-Host '== 4. resolve check =='
node (Join-Path $PSScriptRoot 'verify.mjs')