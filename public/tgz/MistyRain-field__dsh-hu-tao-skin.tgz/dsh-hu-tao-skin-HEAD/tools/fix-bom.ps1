# Strip UTF-8 BOMs from the files DSH itself reads.
#
#   pwsh -File tools/fix-bom.ps1 [-ProfileDir <dir>] [-ProfileName web]
#
# WHY: Windows PowerShell writes a BOM for `Set-Content -Encoding utf8`, and
# DSH's modules scanner reads a row's manifest with
# JSON.parse(readFileSync(pkgPath, "utf8")) - a BOM throws there and the GUI
# never boots. YAML and JS survive a BOM, but keeping the deployed package
# BOM-free removes the trap entirely.
#
# DELIBERATELY NOT TOUCHED: the .ps1 helpers in this directory. They are read
# back by Get-Content, which on Windows PowerShell 5.1 decodes a BOM-less file
# under the ANSI code page and mangles non-ASCII paths. Keep their BOM, or read
# them with -Encoding UTF8.
[CmdletBinding()]
param(
  [string]$ProfileDir,
  [string]$ProfileName = 'web'
)

$ErrorActionPreference = 'Stop'
$utf8NoBom = New-Object System.Text.UTF8Encoding($false)
$repo = Split-Path -Parent $PSScriptRoot

if (-not $ProfileDir) {
  $dshHome = if ($env:DSH_HOME) { $env:DSH_HOME } else { Join-Path $HOME '.dsh' }
  $ProfileDir = if ($env:DSH_PROFILE_DIR) { $env:DSH_PROFILE_DIR } else { Join-Path $dshHome "profiles\$ProfileName" }
}

$targets = @()
$installed = Join-Path $ProfileDir 'local-plugins\dsh-hu-tao-skin'
if (Test-Path $installed) { $targets += Get-ChildItem $installed -Recurse -File }
$profileManifest = Join-Path $ProfileDir 'package.json'
if (Test-Path $profileManifest) { $targets += Get-Item $profileManifest }
foreach ($file in @('package.json', 'cordis.patch.yml')) { $targets += Get-Item (Join-Path $repo $file) }
$targets += Get-ChildItem (Join-Path $repo 'lib') -File

$stripped = 0
foreach ($f in $targets) {
  $before = [System.IO.File]::ReadAllBytes($f.FullName)
  if (-not ($before.Length -ge 3 -and $before[0] -eq 0xEF -and $before[1] -eq 0xBB -and $before[2] -eq 0xBF)) { continue }
  [System.IO.File]::WriteAllText($f.FullName, [System.IO.File]::ReadAllText($f.FullName), $utf8NoBom)
  $stripped++
  Write-Host ('   stripped BOM: ' + $f.FullName)
}
if ($stripped -eq 0) { Write-Host '   all DSH-read files already BOM-free' }

Write-Host '== proof: the scanner would parse both manifests =='
node -e "const fs=require('fs');const p=process.argv[1];for(const f of [p,process.argv[2]]){JSON.parse(fs.readFileSync(f,'utf8'));console.log('   JSON.parse OK: '+f)}" (Join-Path $installed 'package.json') $profileManifest