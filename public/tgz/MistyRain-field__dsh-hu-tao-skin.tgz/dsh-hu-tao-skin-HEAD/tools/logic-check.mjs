// Stub-harness check: load the real browser half, run apply(), then render,
// measure and click every surface it registers.
import { readFileSync } from "node:fs"
import { dirname, join } from "node:path"
import { fileURLToPath } from "node:url"

// The package under test is this script's own repository root.
const CLIENT = join(dirname(fileURLToPath(import.meta.url)), "..", "lib", "client.js")

let captured = null
const stored = new Map()
const stateUpdates = []
let lastObserver = null

const FAKE_FRAME = { style: { gridTemplateColumns: "268px minmax(0, 1fr) 0px" }, hasAttribute: () => false }
const FAKE_LAYER = { parentElement: FAKE_FRAME }
const FAKE_NODE = { closest: (sel) => (sel === "[data-shell-overlay]" ? FAKE_LAYER : null) }

globalThis.window = {
  __ModuleLoader__: { load(def) { captured = def } },
  // Deliberately WRONG on purpose: the component must prefer the inline target.
  getComputedStyle: () => ({ gridTemplateColumns: "56px minmax(0, 1fr) 0px" }),
  addEventListener() {}, removeEventListener() {},
  requestAnimationFrame: (fn) => { fn(); return 1 },
}
globalThis.MutationObserver = class { constructor(cb) { this.cb = cb; lastObserver = this } observe() {} disconnect() {} }
Object.defineProperty(globalThis, "localStorage", {
  configurable: true,
  value: { getItem: (k) => (stored.has(k) ? stored.get(k) : null), setItem: (k, v) => { stored.set(k, String(v)) } },
})

new Function(readFileSync(CLIENT, "utf8"))()
if (captured === null) throw new Error("FAIL: load never called")
console.log("module id           :", captured.id, "| matches package name:", captured.id === "dsh-hu-tao-skin")

const pendingEffects = []
const React = {
  createElement(type, props, ...children) {
    const el = { type, props: props || {}, children: children.flat(Infinity).filter((c) => c !== null && c !== undefined) }
    if (el.props.ref && typeof el.props.ref === "object") el.props.ref.current = FAKE_NODE
    return el
  },
  useState(initial) {
    const value = typeof initial === "function" ? initial() : initial
    return [value, (next) => stateUpdates.push(typeof next === "function" ? next(value) : next)]
  },
  useRef(initial) { return { current: initial ?? null } },
  useEffect(fn) { pendingEffects.push(fn) },
}

const registered = []
const slots = { inject: (k, cb) => { cb() }, register: (o, c) => { registered.push({ options: o, component: c }) } }
const tokenCalls = []
const theme = {
  getTheme: () => ({ active: { colorScheme: "dark" } }),
  overrideTokens(source, tokens) { tokenCalls.push({ source, tokens }); return () => tokenCalls.push({ disposed: true }) },
}
const events = {}
const ctx = {
  get: (n) => (n === "slots" ? slots : n === "theme" ? theme : undefined),
  on(n, fn) { events[n] = fn },
  effect(fn) { fn() },
}

const fails = []
const check = (label, condition, detail) => {
  if (condition) console.log("   PASS  " + label + (detail ? ": " + detail : ""))
  else { fails.push(label); console.log("   FAIL  " + label + (detail ? ": " + detail : "")) }
}
const mod = captured.factory((s) => { if (s === "react") return React; throw new Error("unexpected require: " + s) })
console.log("exports             :", Object.keys(mod).sort().join(", "), "| inject:", JSON.stringify(mod.inject))
mod.apply(ctx)

function expand(node) {
  if (Array.isArray(node)) return node.flatMap(expand)
  if (node === null || node === undefined || typeof node !== "object") return node
  if (typeof node.type === "function") return expand(node.type(node.props))
  if (typeof node.type === "string") return { ...node, children: expand(node.children) }
  return node
}
function findAll(node, predicate, out = []) {
  if (Array.isArray(node)) { node.forEach((n) => findAll(n, predicate, out)); return out }
  if (!node || typeof node !== "object") return out
  if (predicate(node)) out.push(node)
  findAll(node.children, predicate, out)
  return out
}
const byId = (id) => registered.find((r) => r.options.id === id || r.options.key === id || r.options.name === id)
function render(reg, props) {
  const tree = expand(reg.component(props ?? { size: 32, className: "host-class" }))
  pendingEffects.splice(0).forEach((fn) => fn())
  return tree
}
const fabButton = () => findAll(render(byId("hutao-petals")), (n) => n.type === "button")[0]

console.log("\n-- registered surfaces --")
for (const r of registered) {
  console.log("  ", r.options.name.padEnd(28), JSON.stringify(r.options.id || r.options.key || "-").padEnd(24), "order=" + (r.options.order ?? "-"), "label=" + (r.options.label ?? "-"))
}

console.log("\n-- theme --")
const tokenMap = tokenCalls[0].tokens
const tokenNames = Object.keys(tokenMap)
const malformed = Object.entries(tokenMap).filter(([, v]) => typeof v.light !== "string" || typeof v.dark !== "string")
check("overrideTokens source is the package name", tokenCalls[0].source === "dsh-hu-tao-skin", tokenCalls[0].source)
check("token layer is complete for this theme", tokenNames.length === 14, tokenNames.length + " tokens")
check("every token carries a light and a dark value", malformed.length === 0, malformed.length + " malformed")
check("covers the 0.2.0 idle token", tokenNames.includes("--dsw-alias-state-idle-primary"))
console.log("   tokens:", tokenNames.join(", "))

console.log("\n-- ambient / hero / settings --")
const petalCount = () => findAll(render(byId("hutao-skin-ambient")), (n) => n.props.className === "ht-petal").length
const flyCount = () => findAll(render(byId("hutao-skin-ambient")), (n) => n.props.className === "ht-fly").length
const settingsButtons = () => findAll(render(byId("hu-tao-skin")), (n) => n.type === "button")
console.log("   petals:", petalCount(), "| butterflies:", flyCount(), "| seal:", findAll(render(byId("hutao-skin-ambient")), (n) => n.props.className === "ht-seal")[0].children[0])
const heroSvg = findAll(render(byId("conversation.hero.brand.mark")), (n) => n.type === "svg")[0]
console.log("   hero petals:", findAll(heroSvg, (n) => n.type === "ellipse").length, "rotations:", findAll(heroSvg, (n) => n.type === "ellipse").map((p) => p.props.transform.replace(/rotate\(| 50 50\)/g, "")).join(","))
console.log("   settings:", settingsButtons().map((b) => b.children[1] + (b.props["aria-pressed"] === "true" ? "[on]" : "[off]")).join(" "))

console.log("\n-- NEW: floating petal button (conversation bottom-left) --")
console.log("   slot:", byId("hutao-petals").options.name, "| id:", byId("hutao-petals").options.id, "| order:", byId("hutao-petals").options.order)
stateUpdates.length = 0
const firstButton = fabButton()
const mountMeasure = stateUpdates.filter((v) => typeof v === "number")
check("inline target wins over computed", mountMeasure[0] === 268, JSON.stringify(stateUpdates))
console.log("   button markup: class=" + JSON.stringify(firstButton.props.className) + " | inline left=" + JSON.stringify(firstButton.props.style) + " (CSS pins bottom-left + pointer-events:auto)")

console.log("\n-- sidebar collapse: does it follow left? --")
stateUpdates.length = 0
FAKE_FRAME.style.gridTemplateColumns = "56px minmax(0, 1fr) 0px"
if (lastObserver) lastObserver.cb()
check("follows the sidebar left on collapse", stateUpdates.includes(56), stateUpdates.join(","))
stateUpdates.length = 0
FAKE_FRAME.style.gridTemplateColumns = "268px minmax(0, 1fr) 0px"
if (lastObserver) lastObserver.cb()
check("follows it right on expand", stateUpdates.includes(268), stateUpdates.join(","))

console.log("\n-- click behaviour: the switch drives petals AND butterflies --")
console.log("   before    :", petalCount(), "petals |", flyCount(), "butterflies |", stored.get("dsh.hu-tao-skin.prefs"))
fabButton().props.onClick()
const offPetals = petalCount(), offFlies = flyCount()
check("switch off clears petals AND butterflies", offPetals === 0 && offFlies === 0, offPetals + " petals / " + offFlies + " butterflies | " + stored.get("dsh.hu-tao-skin.prefs"))
console.log("   button    :", "aria-pressed=" + fabButton().props["aria-pressed"], "| title=" + fabButton().props.title, "| slash=" + (findAll(fabButton(), (n) => n.props.className === "ht-fab-slash").length > 0))
console.log("   settings  :", settingsButtons().map((b) => b.children[1] + (b.props["aria-pressed"] === "true" ? "[on]" : "[off]")).join(" "))
fabButton().props.onClick()
check("switch on restores both", petalCount() === 14 && flyCount() === 3, petalCount() + " petals / " + flyCount() + " butterflies")

console.log("\n-- the settings page keeps its own independent toggles --")
const flutter = settingsButtons().find((b) => b.children[1] === "蝶影流光")
flutter.props.onClick()
check("settings toggle stays independent", petalCount() === 14 && flyCount() === 0, petalCount() + " petals / " + flyCount() + " butterflies")
flutter.props.onClick()
console.log("   蝶影流光 back on        :", petalCount(), "petals |", flyCount(), "butterflies")

console.log("\n-- re-apply (HMR) / theme change --")
const before2 = registered.length
mod.apply(ctx)
console.log("   re-registered:", registered.length - before2, "surfaces | theme layer never stacks:", tokenCalls.length, "calls,", tokenCalls.filter((c) => c.disposed).length, "disposed")
events["theme/change"]({ active: { colorScheme: "light" } })
console.log("   light theme handled OK")
console.log("\n   resolved surfaces:", registered.map((r) => r.options.id || r.options.name).join(", "))

// ── gate: a printed verdict is not a check unless a failure changes the exit code ──
console.log("\n-- RESULT --")
if (fails.length === 0) {
  console.log("   RESULT: OK (" + registered.length + " surfaces registered)")
} else {
  console.log("   RESULT: " + fails.length + " FAILURE(S): " + fails.join("; "))
  process.exitCode = 1
}
