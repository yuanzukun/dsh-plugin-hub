// Read-only post-deploy check: does the row package resolve from the profile
// anchor, and does the loader find the host half, browser half and patch layer
// exactly where it expects them?
import { createRequire } from "node:module"
import { readFileSync, existsSync } from "node:fs"
import { homedir } from "node:os"
import { dirname, join } from "node:path"

const readJson = (p) => JSON.parse(readFileSync(p, "utf8").replace(/^\uFEFF/, ""));
const PROFILE = process.env.DSH_PROFILE_DIR ?? join(process.env.DSH_HOME ?? join(homedir(), ".dsh"), "profiles", "web")
const require = createRequire(PROFILE + "/package.json")
let failures = 0
const ok = (label, value) => console.log("   PASS  " + label + ": " + value)
const bad = (label, value) => { failures++; console.log("   FAIL  " + label + ": " + value) }

/** Walk up from a resolved entry to the directory that owns package.json. */
function packageRoot(from) {
  let dir = dirname(from)
  for (let i = 0; i < 6; i++) {
    if (existsSync(join(dir, "package.json"))) return dir
    const up = dirname(dir)
    if (up === dir) break
    dir = up
  }
  return undefined
}

let entry
try { entry = require.resolve("dsh-hu-tao-skin"); ok("row package resolves", entry) }
catch (err) { bad("row package resolves", err.message) }

const root = entry === undefined ? undefined : packageRoot(entry)
if (root === undefined) bad("package root", "not found")
else {
  ok("package root", root)
  const manifest = readJson(join(root, "package.json"))

  if (manifest.name === "dsh-hu-tao-skin") ok("package name", manifest.name)
  else bad("package name", String(manifest.name))

  if (manifest.dsh?.bundle?.patch === "./cordis.patch.yml") ok("dsh.bundle.patch", manifest.dsh.bundle.patch)
  else bad("dsh.bundle.patch", JSON.stringify(manifest.dsh?.bundle))

  if (manifest.dsh?.client?.platform === "web") ok("dsh.client.platform", manifest.dsh.client.platform)
  else bad("dsh.client.platform", JSON.stringify(manifest.dsh?.client))

  const clientRel = manifest.exports?.["./client"]?.default
  if (typeof clientRel === "string") ok("exports[./client].default", clientRel)
  else bad("exports[./client].default", JSON.stringify(manifest.exports?.["./client"]))

  const clientPath = join(root, clientRel ?? "MISSING")
  if (existsSync(clientPath)) {
    const body = readFileSync(clientPath, "utf8")
    ok("browser half on disk", clientPath.split("\\").pop() + " (" + body.length + " B)")
    const declaredId = /id:\s*"([^"]+)"/.exec(body)?.[1]
    if (declaredId === manifest.name) ok("module id === package name", declaredId)
    else bad("module id === package name", String(declaredId))
    if (body.includes("__ModuleLoader__.load")) ok("module-loader wrapper", "present")
    else bad("module-loader wrapper", "missing")
  } else bad("browser half on disk", clientPath)

  const patchPath = join(root, manifest.dsh?.bundle?.patch ?? "MISSING")
  if (existsSync(patchPath)) {
    const patch = readFileSync(patchPath, "utf8")
    const rowId = /-\s*id:\s*(\S+)/.exec(patch)?.[1]
    const rowName = /name:\s*(\S+)/.exec(patch)?.[1]
    ok("loader patch row", "id=" + rowId + " name=" + rowName)
    if (rowId === manifest.name && rowName === manifest.name) ok("row id + name match package", "yes")
    else bad("row id + name match package", rowId + " / " + rowName)
  } else bad("loader patch on disk", patchPath)

  const hostHalf = readFileSync(join(root, "lib/index.js"), "utf8")
  if (hostHalf.includes("export default")) ok("host half exports a plugin", "export default present")
  else bad("host half exports a plugin", "no export default")
}

const profileManifest = readJson(PROFILE + "/package.json")
const bundles = profileManifest.dsh?.profile?.bundles ?? []
if (bundles.includes("dsh-hu-tao-skin")) ok("dsh.profile.bundles", bundles.join(", "))
else bad("dsh.profile.bundles", bundles.join(", "))
if (profileManifest.dependencies?.["dsh-hu-tao-skin"]) ok("profile dependency", profileManifest.dependencies["dsh-hu-tao-skin"])
else bad("profile dependency", "absent")

console.log(failures === 0 ? "\n   deployment check: OK" : "\n   deployment check: " + failures + " FAILURE(S)")
process.exitCode = failures === 0 ? 0 : 1

