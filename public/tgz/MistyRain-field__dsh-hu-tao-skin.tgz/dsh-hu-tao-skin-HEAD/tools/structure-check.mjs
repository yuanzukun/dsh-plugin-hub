// Final read-only validation, mirroring what DSH itself does at startup: the
// modules scanner's own JSON.parse, the dsh.client declaration rules, the YAML
// loader dialect, the host-half ESM import, and the browser module id.
//
//   node tools/structure-check.mjs
//
// Profile default: $DSH_PROFILE_DIR, else $DSH_HOME\profiles\web, else
// $HOME\.dsh\profiles\web.
import { existsSync, readFileSync } from "node:fs"
import { createRequire } from "node:module"
import { homedir } from "node:os"
import { dirname, join } from "node:path"
import { pathToFileURL } from "node:url"

const PROFILE = process.env.DSH_PROFILE_DIR
  ?? join(process.env.DSH_HOME ?? join(homedir(), ".dsh"), "profiles", "web")

/** Walk up from a resolved entry to the directory that owns package.json. */
function packageRoot(from) {
  let dir = dirname(from)
  for (let i = 0; i < 6; i++) {
    if (existsSync(join(dir, "package.json"))) return dir
    const up = dirname(dir)
    if (up === dir) break
    dir = up
  }
  return undefined
}

let failures = 0
const ok = (label, value) => console.log("   PASS  " + label + ": " + value)
const bad = (label, value) => { failures++; console.log("   FAIL  " + label + ": " + value) }

const nodeRequire = createRequire(join(PROFILE, "package.json"))
const ROOT = packageRoot(nodeRequire.resolve("dsh-hu-tao-skin"))
if (ROOT === undefined) throw new Error("dsh-hu-tao-skin is not resolvable from " + PROFILE)
console.log("   package: " + ROOT)

// 1. exactly what client-modules/src/index.ts does with the row's manifest
let manifest
try {
  manifest = JSON.parse(readFileSync(join(ROOT, "package.json"), "utf8"))
  ok("JSON.parse(readFileSync(pkg)) - the scanner's exact call", "parsed")
} catch (err) { bad("JSON.parse(readFileSync(pkg))", err.message) }

if (manifest !== undefined) {
  const decl = manifest.dsh?.client
  const injectOk = decl?.inject === undefined
    || (Array.isArray(decl.inject) && decl.inject.every((s) => typeof s === "string"))
  if (decl && typeof decl.platform === "string" && injectOk) {
    ok("parseDshClient validation rules", "platform=" + decl.platform + " inject=" + JSON.stringify(decl.inject))
  } else bad("parseDshClient validation rules", JSON.stringify(decl))

  const ex = manifest.exports?.["./client"]
  const rel = typeof ex === "string" ? ex : ex?.default
  if (typeof rel === "string" && existsSync(join(ROOT, rel))) ok("exports['./client'] resolves", rel)
  else bad("exports['./client'] resolves", String(rel))
}

// 2. the loader patch, parsed the way the YAML loader would. A YAML package is
// usually NOT a dependency of this plugin, so fall back to resolving it from
// the profile's own parent node_modules (where dsh keeps its dependencies).
const anchorRequire = createRequire(join(PROFILE, "..", "package.json"))
async function loadYaml(name) {
  try { return await import(name) } catch {}
  try { return await import(pathToFileURL(anchorRequire.resolve(name)).href) } catch { return undefined }
}
for (const name of ["yaml", "js-yaml"]) {
  try {
    const lib = await loadYaml(name)
    if (lib === undefined) { console.log("   SKIP  " + name + ": not installed"); continue }
    const parse = typeof lib.parse === "function" ? lib.parse : lib.default?.load
    if (typeof parse !== "function") { console.log("   SKIP  " + name + ": no parse/load export"); continue }
    const rows = parse(readFileSync(join(ROOT, "cordis.patch.yml"), "utf8"))
    const row = rows?.[0]?.insert?.[0]
    if (row?.id === "dsh-hu-tao-skin" && row?.name === "dsh-hu-tao-skin") ok(name + " parses the patch", JSON.stringify(row))
    else bad(name + " parses the patch", JSON.stringify(rows))
  } catch (err) { console.log("   SKIP  " + name + ": " + err.message.split("\n")[0]) }
}

// 3. the host half is a real, importable ESM plugin
try {
  const host = await import(pathToFileURL(join(ROOT, "lib/index.js")).href)
  const plugin = host.default
  if (plugin && typeof plugin.apply === "function" && plugin.name === "dsh-hu-tao-skin") {
    ok("host half imports as ESM", "name=" + plugin.name + " apply=" + typeof plugin.apply)
  } else bad("host half imports as ESM", JSON.stringify(Object.keys(host)))
} catch (err) { bad("host half imports as ESM", err.message) }

// 4. the browser half declares the module id the table will key it by
const client = readFileSync(join(ROOT, "lib/client.js"), "utf8")
const declared = /id:\s*"([^"]+)"/.exec(client)?.[1]
if (declared === "dsh-hu-tao-skin") ok("browser half module id", declared)
else bad("browser half module id", String(declared))
if (!client.includes("\uFEFF")) ok("no BOM in the browser bundle", "clean")
else bad("no BOM in the browser bundle", "BOM present")

console.log(failures === 0 ? "\n   FINAL: OK" : "\n   FINAL: " + failures + " FAILURE(S)")
process.exitCode = failures === 0 ? 0 : 1