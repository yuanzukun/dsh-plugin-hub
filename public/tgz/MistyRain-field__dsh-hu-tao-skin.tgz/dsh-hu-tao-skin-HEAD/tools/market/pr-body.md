Adds one entry: `data/plugins/MistyRain-field__dsh-hu-tao-skin.yml`

**What it is** — a Genshin Impact Hu Tao (Wangsheng Funeral Parlor) skin for the dsh web GUI. It declares `dsh.bundle` (`cordis.patch.yml` inserts its own row) alongside `dsh.client.platform: web`, so `dsh plugin add` installs it. No build step: the browser half is a hand-written `window.__ModuleLoader__.load` bundle served from `lib/client.js`.

**Every claim in the entry, and where it lives in the code**

- *14-token ink-black, crimson and amber palette* — the `TOKENS` map in `lib/client.js`: 13 entries, each with a `light` and a `dark` value. It is stacked with `theme.overrideTokens()`, so the theme registry and the user's theme preference are untouched.
- *falling plum petals and spirit butterflies* — the `shell.overlay` ambient layer renders 14 `.ht-petal` spans and 3 `.ht-fly` butterflies.
- *a plum-blossom brand mark* — the `conversation.hero.brand.mark` registration, five petals with a gold centre.
- *a floating petal toggle that tracks the sidebar* — the `shell.overlay` `hutao-petals` registration. Its x position is read from the shell frame's first grid track (via the overlay layer's own parent), so it follows the sidebar while it is dragged, collapsed to the 56px rail, or expanded again. It switches petals and butterflies together, and a 「往生堂」 page in Settings keeps three independent toggles.

`category: theme` — it is a theme/skin, so it belongs on dsh-market's Themes tab. `screenshots.json` in the repo declares three images.

**Verification** — `tools/logic-check.mjs` drives all of the above against fixtures (window.__ModuleLoader__, React, the slot registry, the theme service), rendering every surface and clicking the switch; `tools/ci-check.mjs` re-checks the packaging contract and this very entry against the repo. Both run in CI on every push.