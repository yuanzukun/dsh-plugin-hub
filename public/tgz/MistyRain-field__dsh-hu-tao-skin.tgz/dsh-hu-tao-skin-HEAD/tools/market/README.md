# Market submission

To appear in [dsh-market](https://github.com/dsh-market/dsh-market) (and on
[awesome-dsh-plugin.com](https://awesome-dsh-plugin.com)) a plugin needs one
entry file in the curated list
[`awesome-dsh-plugin/awesome-dsh-plugin`](https://github.com/awesome-dsh-plugin/awesome-dsh-plugin):

```
data/plugins/<owner>__<repo>.yml
```

That repository's READMEs are **generated** from `data/plugins/*.yml` — never
edit them by hand, and never touch anyone else's entry.

`MistyRain-field__dsh-hu-tao-skin.yml` here is a byte-for-byte copy of what the
pull request must add. `tools/submit-to-market.ps1` forks the list, adds it on a
branch, and opens the PR.

## What the listed repository has to satisfy

| Requirement | Where this repo stands |
| --- | --- |
| Declares `dsh.bundle` in `package.json` | `dsh.bundle.patch: ./cordis.patch.yml` |
| Ships `cordis.patch.yml` inserting its own row | `id` and `name` both `dsh-hu-tao-skin` |
| Real, working code (no placeholder or README-only repo) | `lib/client.js`, 470+ lines, exercised by `tools/logic-check.mjs` |
| Repo at least **1 day old** | checked automatically by their CI before anything else |
| Carries the `dsh-plugin` topic | set on the repository |
| Description accurate against the code, no marketing | `tools/ci-check.mjs` re-reads the entry against this repo |
| Category matches what it does | `theme` — which is also what puts it in dsh-market's Themes tab |

Themes and skins **must** use `category: theme`: that is the category dsh-market
reads for its one-click install/switch/uninstall Themes tab. UI tweaks that are
not themes belong under `ui` instead.

## Screenshots

The storefront gallery comes from `screenshots.json` in **this** repository
(1-8 relative paths), not from the list. See `../../screenshots.json`. Keeping
them here means swapping a screenshot is a push to this repo — no pull request.

## Not required

Publishing to npm is optional and does not affect listing; it only adds a
download count. The `repository` field in `package.json` must point back at the
listed repository either way, which it does.