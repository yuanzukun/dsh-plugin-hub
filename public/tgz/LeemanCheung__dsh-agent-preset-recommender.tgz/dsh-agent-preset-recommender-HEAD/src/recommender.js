import { addToolCounts, emptyToolCounts } from './utils.js'
import { DSH_PRESET_CONTRACT } from './constants.js'

function summarize(projects) {
  const tools = emptyToolCounts()
  let sessions = 0
  let workflows = 0
  let metadata = 0
  const sources = new Set()
  for (const project of projects) {
    addToolCounts(tools, project.toolCounts)
    sessions += project.sessionCount
    workflows += project.workflowCount
    metadata += project.metadataCount || 0
    sources.add(project.source)
  }
  return { tools, sessions, workflows, metadata, sources: [...sources].sort() }
}

export function recommend(projects) {
  const evidence = summarize(projects)
  const toolTotal = Object.values(evidence.tools).reduce((a, b) => a + b, 0)
  const activeCategories = Object.values(evidence.tools).filter((count) => count > 0).length
  // PTC and Cordis are specialized, explicit user choices in DSH 0.1.2.
  // Local activity volume is not enough evidence to replace either selection.
  const needsStandard = evidence.sessions > 0 || evidence.workflows > 0 || toolTotal > 0
  const preset = needsStandard ? 'standard' : 'minimal'

  const capabilities = []
  if (projects.some((project) => project.source === 'codex' && project.sessionCount > 0)) capabilities.push('Codex delegation')
  if (projects.some((project) => project.source === 'claude' && project.sessionCount > 0)) capabilities.push('Claude Code delegation')
  if (evidence.workflows > 0 || evidence.tools.workflow > 0) capabilities.push('workflows')
  if (evidence.tools.web > 0) capabilities.push('web')
  if (evidence.tools.mcp > 0) capabilities.push('MCP')
  if (evidence.tools.lsp > 0) capabilities.push('LSP')

  const observations = evidence.sessions + evidence.workflows + toolTotal
  const confidence = observations === 0 ? 0 : Math.min(0.95, Number((0.35 + Math.log10(observations + 1) * 0.2).toFixed(2)))
  return {
    preset,
    capabilities,
    confidence,
    evidence: {
      sessions: evidence.sessions,
      workflows: evidence.workflows,
      metadataFiles: evidence.metadata,
      categorizedToolCalls: toolTotal,
      activeToolCategories: activeCategories,
      sources: evidence.sources,
      toolCounts: evidence.tools,
    },
    advisoryOnly: true,
    presetContract: {
      dshVersion: DSH_PRESET_CONTRACT.dshVersion,
      shippedPresets: [...DSH_PRESET_CONTRACT.shippedPresets],
      automaticallyRecommended: [...DSH_PRESET_CONTRACT.automaticallyRecommended],
      preservesUserSelection: DSH_PRESET_CONTRACT.preservesUserSelection,
    },
  }
}
