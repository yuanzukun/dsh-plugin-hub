# Changelog

## 0.1.7 — 2026-09-05

- Records the DSH `0.1.2-rc.1` shipped preset roster: `minimal`, `standard`, `ptc`, and `cordis`.
- Keeps automatic advice limited to the general-purpose `minimal` and `standard` presets.
- Makes the selection-preservation rule visible in stored recommendations and rendered tool output.
- Updates Cordis and Schemastery contracts for DSH `0.1.2-rc.1`.
