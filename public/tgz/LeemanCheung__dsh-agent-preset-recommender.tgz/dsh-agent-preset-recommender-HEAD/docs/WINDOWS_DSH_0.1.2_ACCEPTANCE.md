# Windows DSH 0.1.2 acceptance

Validated on 2026-09-05 in the isolated `QA3081` Web profile running DeepSeek
Harness `0.1.2-rc.1` on Windows.

- Plugin Inventory reported `dsh-agent-preset-recommender` enabled.
- The Host loaded the bundle and registered the recommender plugin.

This acceptance covers package loading and Host registration. The repository
tests cover its local scanner, stored report, privacy bounds, and preset advice.
No external model or memory-service call was part of this check.
