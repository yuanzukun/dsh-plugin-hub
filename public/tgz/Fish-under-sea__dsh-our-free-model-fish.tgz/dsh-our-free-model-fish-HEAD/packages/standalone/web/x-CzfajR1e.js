import{c as o}from"./app.js";const e={name:"x",size:24,node:[["path",{d:"M18 6 6 18",key:"1bl5f8"}],["path",{d:"m6 6 12 12",key:"d8bk6v"}]]};e.node;const a=o(e);export{a as X};
