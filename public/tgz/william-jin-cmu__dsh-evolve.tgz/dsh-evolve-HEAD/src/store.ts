/**
 * Persistence layer for evolved plugins: name validation, source files on
 * disk, and the manifest that lets evolutions survive a DSH restart. Pure
 * filesystem helpers — no cordis types — so the whole module is unit-testable
 * without a runtime.
 * @module dsh-evolve/store
 */

import { existsSync, lstatSync, mkdirSync, readFileSync, rmSync, symlinkSync, writeFileSync } from 'node:fs'
import { platform } from 'node:os'
import { join } from 'node:path'

/** One persisted evolution: enough to remount it after a restart. */
export interface ManifestEntry {
  /** Monotonic revision counter; bumped on every rewrite to cache-bust `import()`. */
  rev: number
  /** One-line purpose, echoed in evolve_list so the model remembers why it exists. */
  description?: string
  /** Config object passed to `ctx.plugin(plugin, config)` at mount time. */
  config?: unknown
}

/** The on-disk manifest: every evolution that should be restored on boot. */
export interface EvolveManifest {
  plugins: Record<string, ManifestEntry>
}

const NAME_PATTERN = /^[a-z][a-z0-9-]{0,63}$/
const MANIFEST_FILENAME = 'manifest.json'

/**
 * Validate an evolution name (kebab-case, ≤64 chars — it becomes a filename).
 * @param name - the candidate name.
 * @returns the name, for chaining.
 */
export function validateName(name: string): string {
  if (!NAME_PATTERN.test(name)) {
    throw new Error(
      `invalid evolution name "${name}" — use kebab-case: lowercase letters, digits, hyphens, starting with a letter (max 64 chars)`,
    )
  }
  return name
}

/**
 * The source file path for an evolution.
 * @param dir - the evolve store directory.
 * @param name - the validated evolution name.
 * @returns the absolute `.mjs` path.
 */
export function sourcePath(dir: string, name: string): string {
  return join(dir, `${name}.mjs`)
}

/**
 * Read the manifest, tolerating a missing or empty store.
 * @param dir - the evolve store directory.
 * @returns the parsed manifest, or an empty one.
 */
export function readManifest(dir: string): EvolveManifest {
  const file = join(dir, MANIFEST_FILENAME)
  if (!existsSync(file)) return { plugins: {} }
  const parsed: unknown = JSON.parse(readFileSync(file, 'utf8'))
  if (typeof parsed !== 'object' || parsed === null || typeof (parsed as EvolveManifest).plugins !== 'object') {
    throw new Error(`corrupt evolve manifest at ${file} — delete it to reset (evolved sources are kept as .mjs files)`)
  }
  return parsed as EvolveManifest
}

/**
 * Write the manifest atomically enough for a single-process store.
 * @param dir - the evolve store directory.
 * @param manifest - the manifest to persist.
 */
export function writeManifest(dir: string, manifest: EvolveManifest): void {
  writeFileSync(join(dir, MANIFEST_FILENAME), `${JSON.stringify(manifest, null, 2)}\n`)
}

/**
 * Write an evolution's source file.
 * @param dir - the evolve store directory.
 * @param name - the validated evolution name.
 * @param source - the ESM plugin module source.
 */
export function writeSource(dir: string, name: string, source: string): void {
  writeFileSync(sourcePath(dir, name), source)
}

/**
 * Delete an evolution's source file if present.
 * @param dir - the evolve store directory.
 * @param name - the validated evolution name.
 */
export function removeSource(dir: string, name: string): void {
  rmSync(sourcePath(dir, name), { force: true })
}

/**
 * Ensure the store directory exists and evolved modules can resolve bare
 * specifiers (`@deepseek-ai/cordis`, `@deepseek-ai/dsh-tools`, …) by symlinking the store's
 * `node_modules` to this plugin's own — which already links into the dsh
 * checkout (the marisa#2 workaround, reused as a resolution bridge).
 * @param dir - the evolve store directory.
 * @param pluginNodeModules - this plugin's own `node_modules` directory.
 */
export function ensureStore(dir: string, pluginNodeModules: string): void {
  mkdirSync(dir, { recursive: true })
  const link = join(dir, 'node_modules')
  // lstat, not existsSync: a dangling symlink must still count as present.
  try {
    lstatSync(link)
  } catch {
    // Directory symlinks require elevated privileges on Windows, while
    // junctions work for ordinary users and provide the same resolution bridge.
    symlinkSync(pluginNodeModules, link, platform() === 'win32' ? 'junction' : 'dir')
  }
}

/**
 * Pick the cordis plugin out of an imported evolution module: the namespace
 * itself when it exports `apply`, else a plugin default export.
 * @param mod - the imported module namespace.
 * @param name - the evolution name, for error attribution.
 * @returns something mountable by `ctx.plugin`.
 */
export function resolvePlugin(mod: unknown, name: string): object {
  const candidate = mod as { apply?: unknown; default?: unknown }
  if (typeof candidate?.apply === 'function') return assertConfigShape(candidate as object, name)
  const fallback = candidate?.default
  if (typeof fallback === 'function') return assertConfigShape(fallback as unknown as object, name)
  if (typeof (fallback as { apply?: unknown } | undefined)?.apply === 'function') return assertConfigShape(fallback as object, name)
  throw new Error(
    `evolution "${name}" is not a cordis plugin module — export a top-level \`apply(ctx, config)\` function `
    + '(plus optional `name`, `inject`, `Config`), or default-export a plugin',
  )
}

/**
 * Catch the most common authoring mistake before cordis produces an opaque
 * mount error: `Config` written as a plain descriptor object instead of a
 * schemastery schema (schemas are callable validator functions).
 * @param plugin - the resolved plugin (namespace or default export).
 * @param name - the evolution name, for error attribution.
 * @returns the plugin, for chaining.
 */
function assertConfigShape(plugin: object, name: string): object {
  const config = (plugin as { Config?: unknown }).Config
  if (config !== undefined && typeof config !== 'function') {
    throw new Error(
      `evolution "${name}" exports a plain-object \`Config\` — it must be a schemastery schema, `
      + 'which is a callable validator. Write: `import z from \'schemastery\'; '
      + 'export const Config = z.object({ myKey: z.number().default(1) })`, or omit `Config` entirely.',
    )
  }
  return plugin
}
