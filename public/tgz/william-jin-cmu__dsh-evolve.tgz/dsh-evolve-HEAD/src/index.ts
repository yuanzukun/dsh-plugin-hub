/**
 * dsh-evolve: the self-evolving harness loop. Three tools let the agent grow
 * and shed capabilities mid-session as the conversation reveals what the user
 * actually needs: `evolve_add` persists a plugin source to disk and hot-mounts
 * it (its tools appear on the very next model step — dsh re-enumerates tools
 * every step), `evolve_remove` disposes it (cordis revertible effects clean up
 * everything it registered), and `evolve_list` shows the current organism.
 *
 * Unlike tool-cordis's in-memory temporary mounts, evolutions are durable:
 * sources live in `~/.dsh/evolve/*.mjs`, a manifest records what to restore,
 * and the plugin remounts everything on boot — the harness the user ends a
 * session with is the harness the next session starts with.
 * @module dsh-evolve
 */

import { homedir } from 'node:os'
import { dirname, join } from 'node:path'
import { fileURLToPath, pathToFileURL } from 'node:url'
import type { Context as CordisContext, Fiber, FiberState, Plugin } from '@deepseek-ai/cordis'
import z from 'schemastery'
import type SystemPrompt from '@deepseek-ai/dsh-system-prompt'
import type ToolRuntime from '@deepseek-ai/dsh-tools'
import { defineTool } from '@deepseek-ai/dsh-tools'
import {
  ensureStore,
  readManifest,
  removeSource,
  resolvePlugin,
  sourcePath,
  validateName,
  writeManifest,
  writeSource,
} from './store.js'

type Context = CordisContext & {
  tools: ToolRuntime
  systemPrompt: SystemPrompt
}

export const name = 'dsh-evolve'
export const inject = ['tools', 'systemPrompt']

export interface Config {
  /** Store directory for evolved sources + manifest (default `~/.dsh/evolve`). */
  dir?: string
  /** Remount every manifest entry on boot (default true). */
  autoRestore?: boolean
}

/** Schemastery validator for {@link Config}. */
export const Config: z<Config> = z.object({
  dir: z.string().default(''),
  autoRestore: z.boolean().default(true),
})

/** Value mirror of cordis's const-enum `FiberState` (no runtime object to import). */
const STATE_LABELS: Record<number, string> = {
  0: 'pending',
  1: 'loading',
  2: 'active',
  3: 'failed',
  4: 'disposed',
  5: 'unloading',
}

/** One live evolution: its fiber and the revision that was imported. */
interface EvolveMount {
  fiber: Fiber
  rev: number
}

const PROMPT_TEXT = `## Self-evolution (evolve_add / evolve_remove / evolve_list)

You can reshape your own toolset while this conversation runs. When the user's
requests reveal a capability you lack — a recurring transformation, a domain
lookup, a workflow shortcut — author a small cordis plugin and mount it with
evolve_add; its tools become callable on your next step. Real examples: the
user keeps asking about weather for family members in different cities → grow
a weather tool with their cities as aliases; they mention family dates (baby's
birthday, anniversary) they'll ask about again → grow a reminder tool with the
dates baked in; they convert currencies daily → grow a live-rate converter;
they keep asking what codes in a project table mean → grow a lookup tool over
that file. Personalize: bake the user's specifics (cities, dates, paths) into
the tool or its config so future asks need no parameters. When an evolution is
obsolete, wrong, or the user asks you to slim down, remove it. Evolutions
persist across sessions and restarts until removed, so treat the set as a
garden: grow what earns its place, prune what doesn't. A tool earns its place
when it does something you can't do by answering inline: cross-session state
(a running expense log), live external data (weather, rates, the team's
repos), precise computation (date arithmetic, aggregations), or the user's
private specifics baked in. Don't evolve for a one-off or anything you can
answer correctly without tools. Announce what you grew or pruned and why.

Evolution source contract — a plain ESM cordis plugin module (JavaScript, not
TypeScript):

\`\`\`js
import { defineTool } from '@deepseek-ai/dsh-tools'
export const name = 'my-evolution'
export const inject = ['tools']
export function apply(ctx) {
  ctx.tools.register(defineTool({
    name: 'my_tool',
    description: 'What the model reads to decide when to call this.',
    parameters: { text: { type: 'string', required: true } },
    output: {
      schema: { type: 'string' },
      render: (_args, value) => [{ type: 'text', text: value }],
    },
    async execute(args) { return args.text },
  }))
}
\`\`\`

Bare imports of harness packages (@deepseek-ai/cordis, @deepseek-ai/dsh-tools, …) resolve.
Declare every service you touch in \`inject\` — undeclared services may be
undefined. In parameters, \`required\` may only be true or omitted — never
false. Everything registered in apply() is cleaned up automatically on
remove. To update an evolution, call evolve_add again with the same name and
the full revised source.

Evolutions are full cordis plugins, NOT just tool carriers. Tools are pull —
they only run when you remember to call them. When the user's need is "this
must happen every time / without asking / when no one is talking", a tool is
the wrong shape; register one of these instead:

- Standing rules (always-on preferences, style constraints): a system-prompt
  section, present on every step without anyone remembering it —
  \`inject: ['systemPrompt']\`, then
  \`ctx.effect(() => ctx.systemPrompt.section({ name: 'evo:<name>', order: 300, text: '…' }), '<name>.prompt')\`.
- Self-correction and per-step watching: the between-steps waterfall hook
  \`ctx.on('agent/pre-step', async ({ agent, messages, turn, step, signal }, next) => { …; return next() })\`
  — it is a waterfall: ALWAYS return \`next()\` to let the step proceed. Read
  recent output from \`agent.session.events\` (each event is
  \`{ type, seq, time, data }\` — e.g. the last \`assistant/message\` event's
  \`data.message.content\`), and when
  intervention is needed inject model-facing context with
  \`agent.inject(createUserMessage({ content: [{ type: 'text', text: '…' }], source: { kind: 'plugin', plugin: '<name>' } }))\`
  (\`createUserMessage\` from \`@deepseek-ai/dsh-llm\`).
- After-the-work automation ("every time you finish, do X"): listen to
  \`ctx.on('agent/turn-stopping', ({ agent, turn, signal }) => { … })\` and act in
  ordinary code — write the file, post the message — with no model round trip.
- Proactivity (initiate when nobody prompted): a timer that wakes the agent.
  \`inject: ['agents']\`, wrap the interval in an effect so removal cleans it:
  \`ctx.effect(() => { const t = setInterval(() => { const agent = ctx.agents.get(SESSION_ID); agent?.send(createUserMessage({ content: [{ type: 'text', text: '…' }], source: { kind: 'plugin', plugin: '<name>' } }), 'next-turn', true) }, ms); return () => clearInterval(t) }, '<name>.timer')\`.
  Mounting is process-wide, so TARGET a session: bake the current session id
  into the source (or config) and use \`ctx.agents.get(id)\` — iterating
  \`ctx.agents.list()\` broadcasts into every live session, including ones that
  never asked for reminders.

Event listeners registered with ctx.on and effects registered with ctx.effect
are disposed automatically on evolve_remove, exactly like tools.`

/**
 * Register the evolve toolset, restore persisted evolutions, and teach the
 * model the self-evolution stance through a system-prompt section.
 * @param ctx - the plugin context (`tools`, `systemPrompt` injected).
 * @param config - the schemastery-resolved {@link Config}.
 */
export function apply(ctx: Context, config: Config): void {
  const dir = config.dir !== undefined && config.dir !== '' ? config.dir : join(homedir(), '.dsh', 'evolve')
  const ownNodeModules = join(dirname(dirname(fileURLToPath(import.meta.url))), 'node_modules')
  ensureStore(dir, ownNodeModules)

  // The one group fiber every evolution hangs under; disposing dsh-evolve
  // unwinds the whole subtree through ordinary fiber effects.
  const group = ctx.plugin({ name: 'evolve-dynamic', apply: () => {} })
  const mounts = new Map<string, EvolveMount>()
  // Cache-buster for dynamic import. Deliberately NOT the persisted rev: a
  // failed mount doesn't advance rev, so retrying a fixed source under the
  // same rev would hit Node's module cache and reload the broken version.
  let importSeq = 0

  /** Import (cache-busted per attempt) and mount one evolution; never leaves a failed fiber behind. */
  async function mountEvolution(evoName: string, rev: number, pluginConfig: unknown): Promise<Fiber> {
    await group.await()
    const url = `${pathToFileURL(sourcePath(dir, evoName)).href}?rev=${rev}&seq=${++importSeq}`
    const mod: unknown = await import(url)
    const plugin = resolvePlugin(mod, evoName) as Plugin
    const fiber = group.ctx.plugin(plugin, pluginConfig)
    try {
      await fiber.await()
    } catch (error) {
      await fiber.dispose()
      throw error instanceof Error ? error : new Error(String(error))
    }
    mounts.set(evoName, { fiber, rev })
    return fiber
  }

  /** The `inject`ed services an evolution declared that do not exist yet. */
  function missingServices(fiber: Fiber): string[] {
    return Object.keys(fiber.inject).filter(service => ctx.get(service) === undefined)
  }

  function stateOf(fiber: Fiber): string {
    return STATE_LABELS[fiber.state as unknown as number] ?? String(fiber.state satisfies FiberState)
  }

  if (config.autoRestore !== false) {
    void (async () => {
      const manifest = readManifest(dir)
      for (const [evoName, entry] of Object.entries(manifest.plugins)) {
        try {
          await mountEvolution(evoName, entry.rev, entry.config)
        } catch (error) {
          console.warn(`[dsh-evolve] failed to restore "${evoName}": ${error instanceof Error ? error.message : String(error)}`)
        }
      }
    })()
  }

  ctx.tools.register(defineTool({
    name: 'evolve_add',
    description:
      'Grow yourself a new capability: persist a cordis plugin source and hot-mount it in the '
      + 'current DSH process. Its tools become callable on your NEXT step. Unlike cordis_mount, '
      + 'this is DURABLE — the source is written to the evolve store, recorded in a manifest, and '
      + 'remounted automatically on every DSH start until evolve_remove. Calling evolve_add again '
      + 'with an existing name REPLACES that evolution (old version fully unmounted first, its '
      + 'registrations cleaned up). `source` must be a complete plain-JavaScript ESM module: '
      + 'export `apply(ctx, config)` plus optional `name`, `inject` (declare EVERY ctx service '
      + 'you touch, e.g. [\'tools\']), and schemastery `Config`. Bare imports of harness packages '
      + 'resolve (cordis, @deepseek-ai/dsh-tools, @deepseek-ai/dsh-system-prompt, …); Node '
      + 'built-ins (node:fs, node:fetch, …) are fully available — evolutions are trusted code, '
      + 'not sandboxed. Register tools with ctx.tools.register(defineTool({ name, description, '
      + 'parameters: { key: { type, required?, description?, enum?, items?, properties? } } — '
      + '`required` may only be true or omitted, NEVER false (optional = omit it), '
      + 'output: { schema, render(args, value) { return [{ type: \'text\', text }] } }, '
      + 'async execute(args, exec) { … } })) — execute must return the JSON value declared by '
      + 'output.schema. Evolutions are NOT limited to tools: they may register system-prompt '
      + 'sections (ctx.systemPrompt.section), subscribe to agent events (ctx.on(\'agent/pre-step\' | '
      + '\'agent/turn-stopping\' | …)), inject context (agent.inject), wake the agent '
      + '(agent.send(msg, \'next-turn\', true)), or run timers inside '
      + 'ctx.effect — see the self-evolution prompt section for the exact recipes. On mount '
      + 'failure the source file is kept for inspection but NOT added to '
      + 'the manifest; fix the source and call evolve_add again with the same name.',
    parameters: {
      name: {
        type: 'string',
        required: true,
        description: 'Kebab-case evolution name (becomes <name>.mjs in the store); reusing a name replaces that evolution.',
      },
      source: {
        type: 'string',
        required: true,
        description: 'The complete ESM plugin module source (plain JavaScript).',
      },
      description: {
        type: 'string',
        description: 'One line on why this evolution exists — echoed by evolve_list so future turns remember.',
      },
      config: {
        type: 'json',
        description: 'Optional config object passed to the plugin at mount time (validated by its Config schema if it exports one).',
      },
    },
    output: {
      schema: {
        type: 'object',
        additionalProperties: false,
        properties: {
          name: { type: 'string', required: true },
          state: { type: 'string', required: true },
          rev: { type: 'integer', required: true },
          replaced: { type: 'boolean', required: true },
          file: { type: 'string', required: true },
          waitingFor: { type: 'array', required: true, items: { type: 'string' } },
        },
      },
      render: (_args, value) => {
        const verb = value.replaced ? 'replaced (rev ' + String(value.rev) + ')' : 'grown'
        const status = value.waitingFor.length > 0
          ? `pending — waiting for services: ${value.waitingFor.join(', ')}`
          : value.state
        return [{
          type: 'text',
          text: `Evolution "${value.name}" ${verb}: ${status}. Persisted at ${value.file}; new tools are callable from your next step.`,
        }]
      },
    },
    async execute(args) {
      const evoName = validateName(args.name)
      const manifest = readManifest(dir)
      const existing = mounts.get(evoName)
      const replaced = existing !== undefined || manifest.plugins[evoName] !== undefined
      if (existing) {
        await existing.fiber.dispose()
        mounts.delete(evoName)
      }
      writeSource(dir, evoName, args.source)
      const rev = (manifest.plugins[evoName]?.rev ?? existing?.rev ?? 0) + 1
      let fiber: Fiber
      try {
        fiber = await mountEvolution(evoName, rev, args.config)
      } catch (error) {
        const message = error instanceof Error ? error.message : String(error)
        throw new Error(
          `evolution "${evoName}" failed to mount: ${message}\n`
          + `The source is kept at ${sourcePath(dir, evoName)} but not persisted to the manifest — `
          + 'fix it and call evolve_add again with the same name.',
        )
      }
      manifest.plugins[evoName] = { rev, description: args.description, config: args.config }
      writeManifest(dir, manifest)
      return {
        name: evoName,
        state: stateOf(fiber),
        rev,
        replaced,
        file: sourcePath(dir, evoName),
        waitingFor: missingServices(fiber),
      }
    },
  }))

  ctx.tools.register(defineTool({
    name: 'evolve_remove',
    description:
      'Prune an evolution: unmount it (all its tools, listeners, and services clean up '
      + 'automatically), drop it from the manifest so it never remounts, and delete its source '
      + 'unless keepSource is true. Only evolutions created by evolve_add can be removed.',
    parameters: {
      name: {
        type: 'string',
        required: true,
        description: 'The evolution name as shown by evolve_list.',
      },
      keepSource: {
        type: 'boolean',
        description: 'Keep the .mjs source on disk (default false — source is deleted).',
      },
    },
    output: {
      schema: {
        type: 'object',
        additionalProperties: false,
        properties: {
          name: { type: 'string', required: true },
          sourceKept: { type: 'boolean', required: true },
        },
      },
      render: (_args, value) => [{
        type: 'text',
        text: `Evolution "${value.name}" pruned${value.sourceKept ? ' (source kept on disk)' : ''}.`,
      }],
    },
    async execute(args) {
      const evoName = validateName(args.name)
      const manifest = readManifest(dir)
      const mount = mounts.get(evoName)
      if (!mount && manifest.plugins[evoName] === undefined) {
        throw new Error(`no evolution named "${evoName}" (see evolve_list)`)
      }
      if (mount) {
        await mount.fiber.dispose()
        mounts.delete(evoName)
      }
      delete manifest.plugins[evoName]
      writeManifest(dir, manifest)
      const keep = args.keepSource === true
      if (!keep) removeSource(dir, evoName)
      return { name: evoName, sourceKept: keep }
    },
  }))

  ctx.tools.register(defineTool({
    name: 'evolve_list',
    description:
      'List every evolution: name, live state (active/pending/failed-to-restore/not-mounted), '
      + 'revision, description, and source path. Read this to recall what you have already grown '
      + 'before adding more.',
    parameters: {},
    output: {
      schema: {
        type: 'object',
        additionalProperties: false,
        properties: {
          plugins: {
            type: 'array',
            required: true,
            items: {
              type: 'object',
              additionalProperties: false,
              properties: {
                name: { type: 'string', required: true },
                state: { type: 'string', required: true },
                rev: { type: 'integer', required: true },
                description: { type: 'string' },
                file: { type: 'string', required: true },
                waitingFor: { type: 'array', required: true, items: { type: 'string' } },
              },
            },
          },
        },
      },
      render: (_args, value) => {
        if (value.plugins.length === 0) return [{ type: 'text', text: 'No evolutions yet.' }]
        const lines = value.plugins.map(p =>
          `- ${p.name} (rev ${String(p.rev)}, ${p.state}${p.waitingFor.length > 0 ? `, waiting for ${p.waitingFor.join(', ')}` : ''})${p.description !== undefined ? `: ${p.description}` : ''}`)
        return [{ type: 'text', text: `Evolutions:\n${lines.join('\n')}` }]
      },
    },
    execute() {
      const manifest = readManifest(dir)
      const names = new Set([...Object.keys(manifest.plugins), ...mounts.keys()])
      const plugins = [...names].sort().map((evoName) => {
        const mount = mounts.get(evoName)
        const entry = manifest.plugins[evoName]
        return {
          name: evoName,
          state: mount ? stateOf(mount.fiber) : entry !== undefined ? 'not-mounted (restore failed or restore disabled)' : 'unmanaged',
          rev: entry?.rev ?? mount?.rev ?? 0,
          description: entry?.description,
          file: sourcePath(dir, evoName),
          waitingFor: mount ? missingServices(mount.fiber) : [],
        }
      })
      return Promise.resolve({ plugins })
    },
  }))

  ctx.effect(() => ctx.systemPrompt.section({
    name: 'tool:dsh-evolve',
    order: 118,
    text: PROMPT_TEXT,
  }), 'dsh-evolve.prompt')
}
