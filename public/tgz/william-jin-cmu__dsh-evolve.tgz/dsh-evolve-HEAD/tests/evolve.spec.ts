import { mkdtempSync, readFileSync, rmSync, existsSync, lstatSync, mkdirSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { describe, expect, it, afterEach } from 'vitest'
import {
  ensureStore,
  readManifest,
  removeSource,
  resolvePlugin,
  sourcePath,
  validateName,
  writeManifest,
  writeSource,
} from '../src/store.js'

const dirs: string[] = []
function tempStore(): string {
  const dir = mkdtempSync(join(tmpdir(), 'dsh-evolve-'))
  dirs.push(dir)
  return dir
}
afterEach(() => {
  for (const dir of dirs.splice(0)) rmSync(dir, { recursive: true, force: true })
})

describe('validateName', () => {
  it('accepts kebab-case', () => {
    expect(validateName('string-reverser')).toBe('string-reverser')
    expect(validateName('a2-b3')).toBe('a2-b3')
  })
  it('rejects path traversal, uppercase, and leading digits', () => {
    expect(() => validateName('../evil')).toThrow('invalid evolution name')
    expect(() => validateName('Evil')).toThrow('invalid evolution name')
    expect(() => validateName('2fast')).toThrow('invalid evolution name')
    expect(() => validateName('a/b')).toThrow('invalid evolution name')
    expect(() => validateName('')).toThrow('invalid evolution name')
  })
})

describe('manifest round-trip', () => {
  it('reads an empty manifest from a fresh store', () => {
    expect(readManifest(tempStore())).toEqual({ plugins: {} })
  })

  it('persists and reloads entries', () => {
    const dir = tempStore()
    writeManifest(dir, { plugins: { foo: { rev: 3, description: 'd', config: { x: 1 } } } })
    expect(readManifest(dir)).toEqual({ plugins: { foo: { rev: 3, description: 'd', config: { x: 1 } } } })
  })

  it('throws a repair hint on corrupt manifests', () => {
    const dir = tempStore()
    writeSource(dir, 'x', 'whatever')
    writeManifest(dir, { plugins: {} })
    const file = join(dir, 'manifest.json')
    // Overwrite with junk shaped like JSON but not a manifest.
    writeManifest(dir, [] as unknown as { plugins: Record<string, never> })
    void file
    expect(() => readManifest(dir)).toThrow('corrupt evolve manifest')
  })
})

describe('source files', () => {
  it('writes and removes <name>.mjs', () => {
    const dir = tempStore()
    writeSource(dir, 'foo', 'export function apply() {}')
    expect(readFileSync(sourcePath(dir, 'foo'), 'utf8')).toContain('apply')
    removeSource(dir, 'foo')
    expect(existsSync(sourcePath(dir, 'foo'))).toBe(false)
    removeSource(dir, 'foo') // idempotent
  })
})

describe('ensureStore', () => {
  it('creates the dir and a node_modules resolution symlink exactly once', () => {
    const base = tempStore()
    const store = join(base, 'evolve')
    const fakeModules = join(base, 'plugin-node-modules')
    // An existing directory target lets Node use a junction on Windows,
    // avoiding the elevated privilege required for a true directory symlink.
    mkdirSync(fakeModules)
    ensureStore(store, fakeModules)
    ensureStore(store, fakeModules)
    const link = join(store, 'node_modules')
    expect(lstatSync(link).isSymbolicLink()).toBe(true)
  })
})

describe('resolvePlugin', () => {
  it('accepts a namespace exporting apply', () => {
    const mod = { name: 'x', inject: ['tools'], apply: () => {} }
    expect(resolvePlugin(mod, 'x')).toBe(mod)
  })
  it('accepts a default-exported plugin object or function', () => {
    const obj = { apply: () => {} }
    expect(resolvePlugin({ default: obj }, 'x')).toBe(obj)
    const fn = (): void => {}
    expect(resolvePlugin({ default: fn }, 'x')).toBe(fn)
  })
  it('rejects modules with no plugin shape', () => {
    expect(() => resolvePlugin({ foo: 1 }, 'x')).toThrow('not a cordis plugin module')
    expect(() => resolvePlugin(undefined, 'x')).toThrow('not a cordis plugin module')
  })
  it('rejects a plain-object Config with an actionable message', () => {
    const mod = { apply: () => {}, Config: { limit: { type: 'number', default: 300 } } }
    expect(() => resolvePlugin(mod, 'x')).toThrow('schemastery schema')
    const viaDefault = { default: { apply: () => {}, Config: { a: 1 } } }
    expect(() => resolvePlugin(viaDefault, 'x')).toThrow('schemastery schema')
  })
  it('accepts a callable schemastery-style Config', () => {
    const schema = Object.assign(() => {}, { meta: {} })
    const mod = { apply: () => {}, Config: schema }
    expect(resolvePlugin(mod, 'x')).toBe(mod)
  })
})

describe('end-to-end mount lifecycle on a bare cordis Context', () => {
  it('mounts an evolved module from disk, sees its registration, and cleans up on dispose', async () => {
    const { Context } = await import('@deepseek-ai/cordis')
    const dir = tempStore()
    writeSource(dir, 'greeter', [
      "export const name = 'greeter'",
      'export function apply(ctx) {',
      "  ctx.provide('greeter', { hello: () => 'hi' })",
      '}',
    ].join('\n'))

    const ctx = new Context()
    const url = `${new URL(`file://${sourcePath(dir, 'greeter')}`).href}?rev=1`
    const mod: unknown = await import(url)
    const fiber = ctx.plugin(resolvePlugin(mod, 'greeter') as never)
    await fiber.await()
    expect((ctx.get('greeter') as { hello: () => string }).hello()).toBe('hi')

    await fiber.dispose()
    expect(ctx.get('greeter')).toBeUndefined()
  })

  it('cache-busts by rev so a replaced source actually reloads', async () => {
    const { Context } = await import('@deepseek-ai/cordis')
    const dir = tempStore()
    const write = (version: string): void => writeSource(dir, 'v', [
      "export function apply(ctx) { ctx.provide('v', '" + version + "') }",
    ].join('\n'))

    const ctx = new Context()
    write('one')
    const mod1: unknown = await import(`${new URL(`file://${sourcePath(dir, 'v')}`).href}?rev=1`)
    const fiber1 = ctx.plugin(resolvePlugin(mod1, 'v') as never)
    await fiber1.await()
    expect(ctx.get('v')).toBe('one')
    await fiber1.dispose()

    write('two')
    const mod2: unknown = await import(`${new URL(`file://${sourcePath(dir, 'v')}`).href}?rev=2`)
    const fiber2 = ctx.plugin(resolvePlugin(mod2, 'v') as never)
    await fiber2.await()
    expect(ctx.get('v')).toBe('two')
    await fiber2.dispose()
  })
})
