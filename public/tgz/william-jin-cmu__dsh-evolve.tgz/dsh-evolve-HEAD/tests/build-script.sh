#!/bin/bash
set -euo pipefail

SOURCE_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT

ROOT="$TMP/plugin"
mkdir -p "$ROOT/scripts"
cp "$SOURCE_ROOT/scripts/build.sh" "$ROOT/scripts/build.sh"

CHECKOUT="$TMP/checkout"
mkdir -p "$CHECKOUT/bin" "$CHECKOUT/packages" "$CHECKOUT/node_modules/.bin" \
  "$CHECKOUT/node_modules/.pnpm"
mkdir -p "$CHECKOUT/node_modules/@types" \
  "$CHECKOUT/vendor/cordis" \
  "$CHECKOUT/vendor/cosmokit" \
  "$CHECKOUT/vendor/schemastery" \
  "$CHECKOUT/packages/core/agent" \
  "$CHECKOUT/packages/util/brand" \
  "$CHECKOUT/packages/llm/llm" \
  "$CHECKOUT/packages/core/scope" \
  "$CHECKOUT/packages/core/session" \
  "$CHECKOUT/packages/subagent/subagent" \
  "$CHECKOUT/packages/core/system-prompt" \
  "$CHECKOUT/packages/core/tools"

cat >"$CHECKOUT/bin/dsh" <<'EOF'
#!/bin/bash
exit 0
EOF
cat >"$CHECKOUT/node_modules/.bin/tsc" <<EOF
#!/bin/bash
if [ "\${1:-}" = "--version" ]; then
  echo "Version test"
else
  mkdir -p "$ROOT/lib/types"
fi
EOF
chmod +x "$CHECKOUT/bin/dsh" "$CHECKOUT/node_modules/.bin/tsc"

if ! OUTPUT=$(PATH="$CHECKOUT/bin:$PATH" "$ROOT/scripts/build.sh" 2>&1); then
  echo "$OUTPUT" >&2
  exit 1
fi
# Compare the paths after resolving each spelling.  Git Bash may print /tmp
# while pwd -P spells the same directory as AppData/Local/Temp; macOS likewise
# has /var as an alias for /private/var.
PRINTED_CHECKOUT=$(sed -n 's/^=== Linking build dependencies (checkout: \(.*\)) ===$/\1/p' <<<"$OUTPUT")
[ -n "$PRINTED_CHECKOUT" ]
[ "$(cd "$PRINTED_CHECKOUT" && pwd -P)" = "$(cd "$CHECKOUT" && pwd -P)" ]

mkdir -p "$TMP/not-a-checkout/bin"
cp "$CHECKOUT/bin/dsh" "$TMP/not-a-checkout/bin/dsh"
BAD_DSH_BIN=$(readlink -f "$TMP/not-a-checkout/bin/dsh" 2>/dev/null || echo "$TMP/not-a-checkout/bin/dsh")
if OUTPUT=$(PATH="$TMP/not-a-checkout/bin:$PATH" "$ROOT/scripts/build.sh" 2>&1); then
  echo "expected build to reject a dsh binary outside a checkout" >&2
  exit 1
fi
grep -F "cannot locate the dsh checkout (resolved dsh to $BAD_DSH_BIN)" <<<"$OUTPUT" >/dev/null

if OUTPUT=$(PATH="/usr/bin:/bin" "$ROOT/scripts/build.sh" 2>&1); then
  echo "expected build to reject a PATH without dsh" >&2
  exit 1
fi
grep -F "build: dsh not found on PATH" <<<"$OUTPUT" >/dev/null

# DSH_CHECKOUT escape hatch: discovery skips PATH entirely, so a PATH without
# dsh must still build against the pointed-at checkout.
if ! OUTPUT=$(PATH="/usr/bin:/bin" DSH_CHECKOUT="$CHECKOUT" "$ROOT/scripts/build.sh" 2>&1); then
  echo "$OUTPUT" >&2
  exit 1
fi
PRINTED_CHECKOUT=$(sed -n 's/^=== Linking build dependencies (checkout: \(.*\)) ===$/\1/p' <<<"$OUTPUT")
[ -n "$PRINTED_CHECKOUT" ]
[ "$(cd "$PRINTED_CHECKOUT" && pwd -P)" = "$(cd "$CHECKOUT" && pwd -P)" ]

if OUTPUT=$(PATH="/usr/bin:/bin" DSH_CHECKOUT="$TMP/not-a-checkout" "$ROOT/scripts/build.sh" 2>&1); then
  echo "expected build to reject a DSH_CHECKOUT without packages/" >&2
  exit 1
fi
grep -F "cannot locate the dsh checkout" <<<"$OUTPUT" >/dev/null

echo "build-script tests passed"
