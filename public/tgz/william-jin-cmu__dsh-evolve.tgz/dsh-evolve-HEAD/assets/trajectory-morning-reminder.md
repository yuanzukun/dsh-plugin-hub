# Trajectory: 每天早上主动来找我（非工具进化 · 定时器 + agent.send 唤醒）

真实 E2E 会话记录（`dsh web` RPC 驱动，DeepSeek-V4-Flash，未经剪辑；从 session.history 事件流提取）。

这是三个非工具案例里论证最干净的一个：**"没有对话时发起对话"是工具这个形态在定义上做不到的事**——工具只在对话内被调用，而这里连"对话"都还不存在。

**用户输入：**

> 我老是忘事。希望你以后每天早上 9 点主动来找我，帮我过一遍今天的安排——注意，是你主动发起对话，不是等我来问。我知道这听起来不像你能做到的事，所以先来个演示版：装好之后大约 45 秒后你主动触发一次、跟我打个招呼报个时，我亲眼看到你真的会自己来，再让你改成每天早上 9 点的正式版。

### Turn 1 · 🔧 `evolve_list` → `evolve_add` {"name": "morning-reminder-demo"}

agent 长出的演示版核心（`inject: ['agents']`，零工具）：

```js
ctx.effect(() => {
  const timer = setTimeout(() => {
    const text = '【⏰ 每日提醒 · 演示版】\n你好！现在是 …（报时）…'
    for (const agent of ctx.agents.list()) {
      agent.send(
        createUserMessage({ content: [{ type: 'text', text }], source: { kind: 'plugin', plugin: name } }),
        { target: 'next-turn', wakeup: true },   // 唤醒空闲 agent，开一个新 turn
      )
    }
  }, 45 * 1000)
  return () => clearTimeout(timer)               // evolve_remove 时自动清掉定时器
}, `${name}.demo`)
```

> 装好了。我给它加了个「主动触发」能力：约 45 秒后它会自己冒出来，跟我打招呼报时间——你什么都不用做，盯着屏幕等我就行。

### Turn 2 · ⚡ 45 秒后，插件自主发起（trigger source: `plugin: morning-reminder-demo`）

**用户没有发任何消息。** 事件流里 turn 2 的 trigger 是插件：

```
turn/start {"turn":2,"trigger":{"kind":"message","source":{"kind":"plugin","plugin":"morning-reminder-demo"}}}
```

> 👋 你好！现在是 2026年8月6日 星期四 15:25——这条就是刚才那个 45 秒演示：装好后我主动冒出来跟你打招呼，全程没等你来问。演示通过的话，回我一句「可以」，我就把它改成每天早上 9:00 的正式版。

### Turn 3 · 确认 → 正式版上线，demo 可逆退场

> 用户：可以，亲眼看到了！改成每天早上 9 点的正式版吧。

一个 turn 里两次进化操作：`evolve_add` **morning-reminder**（自算距下一个 9:00 的毫秒数、fire 后自动重排明天，`ctx.effect` 归还 `clearTimeout`）+ `evolve_remove` **morning-reminder-demo**（定时器随 fiber dispose 自动清理，不留幽灵）。

> ✅ 正式版已上线（demo 版已删）。从明天起每天早上 9:00 我会主动来找你，帮你过当天的安排。插件已持久化，重启也不丢。

正式版的提醒文案里还写着「可结合天气、账本、家庭日期、团队周报等工具给出建议」——**新进化主动引用了之前会话里长出的其他进化**，organism 在互相咬合。

## 一个真实的涟漪（未剪辑的代价与看点）

demo 定时器用 `ctx.agents.list()` 广播，而挂载是进程级的——同进程里**另一个会话**（工作日志那条）也收到了演示提醒。那个 agent 的反应堪称完美：先怀疑「我没装过定时器插件啊」，调 `evolve_list` 查明有个 `morning-reminder-demo`，然后照做打了招呼。副作用真实存在（广播 vs 定向是进化代码该考虑的事），但每个 agent 都对突如其来的插件消息做出了正确反应——这本身就是鲁棒性的证据。

## 为什么这必须是非工具进化

前两个案例（brevity-guard、worklog）里，工具形态输在"依赖模型记得"；这个案例里工具形态连参赛资格都没有：清晨 9 点没有会话、没有 step、没有工具调用的宿主。唯一的形态就是一段常驻进程的代码，到点用 `agent.send(…, { wakeup: true })` 把对话**造出来**。
