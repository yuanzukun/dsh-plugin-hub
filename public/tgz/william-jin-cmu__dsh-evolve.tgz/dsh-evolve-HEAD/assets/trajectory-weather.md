# Trajectory: 帮家里人看天气（个人化别名 + 真实气象 API）

真实 E2E 会话记录（`dsh web` RPC 驱动，DeepSeek-V4-Flash，未经剪辑；从 session.history 事件流提取）。

**用户输入：**

> 我妈这周六要去杭州玩，那边天气怎么样？要不要带伞？对了我经常要帮家里人看各个城市的天气，爸妈在成都，妹妹在深圳，你最好想个办法让我以后问起来方便点

### step 1 · 🔧 `bash` {"command": "date '+%Y-%m-%d %A'", "description": "Show current date and weekday"}

```
2026-08-06 Thursday

```

### step 1 · 🔧 `bash` {"command": "curl -s --max-time 15 'https://geocoding-api.open-meteo.com/v1/search?name=%E6%9D%AD%E5%B7%9E&count=1&language=zh&format=json' | head -c 600; echo; curl -s --max-time 15 'https://api.open-meteo.com/v1/forecast?latitude=30.2741&longitude=120.1551&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max,precipitation_sum&timezone=Asia%2FShanghai&forecast_da…

```
{"results":[{"id":1808926,"name":"杭州","latitude":30.29365,"longitude":120.16142,"elevation":12.0,"feature_code":"PPLA","country_code":"CN","admin1_id":1784764,"admin2_id":1808925,"timezone":"Asia/Shanghai","population":9236032,"country_id":1814991,"country":"中国","admin1":"浙江","admin2":"杭州市"}],"generationtime_ms":0.12540817}
{"latitude":30.263618,"longitude":120.14051,"generationtime_ms":46.59557342529297,"utc_offset_seconds":28800,"timezone":"Asia/Shanghai","timezone_abbreviation":"GMT+8","elevation":13.0,"daily_units":{"time":"iso8601","weather_code":"wmo code","temperature_2m_max":"°C","temperature_2m_min":"°C","precipitation_probability_max":"%","precipitation_sum":"mm"},"daily":{"time":[…
```

### step 1 · 🔧 `web_search` {"query": "杭州天气预报 本周六 周末 降雨"}

```
Sources:
- [杭州市西湖区天气预报_查询](https://m.moji.com/param?from=moji&internal_id=5273)
- [杭州市西湖区天气预报_杭州市西湖区天气查询](https://m.moji.com/weather/china/zhejiang/xihu-district)
- [【杭州市天气预报15天】_杭州市天气预报15天查询 - 预报查询](https://tianqi.moji.com/forecast15/china/zhejiang/hangzhou)
- [杭州天气预报,杭州7天天气预报,杭州15天天气预报,杭州天气查询](https://www.weather.com.cn/weather/101210101.shtml)
- [杭州市天气预报_查询](http://m.moji.com/param?from=singlemessage&internal_id=143&isappinstalled=0)
- [杭州市 天气](https://forecast7.com/zh/30d27120d16/hangzhou/?unit=us)
- [“白海豚”重回超强台风级 将缓解杭州持续高温](https://www.hangzhou.gov.cn/col/col812267/art/2026/art_c5558f9a6490442f8a1a0749cc80fc98.html)
- [【杭州市天气预报一周】_杭州市天气预报一周查询_一周天气](https://tianqi.moji.com/forecast7/chin…
```

今天是周四（2026-08-06），这周六就是 **8月8日**。我先把查天气的工具建好（以后你说"成都""妹妹那边"就能直接查），同时确认一下杭州的情况。

### step 2 · 🔧 `evolve_add` {"name": "weather-check", "description": "查任意城市天气（当前+未来1-7天，含降水概率与带伞建议），支持中文城市名和家庭成员别名（爸妈→成都、妹妹→深圳），满足\"帮家里人看天气\"的反复需求。"}

<details><summary>模型现场编写的插件源码（source 参数）</summary>

```js
import { defineTool } from '@deepseek-ai/dsh-tools'

export const name = 'weather-check'
export const inject = ['tools']

const WMO = {
  0: '晴', 1: '基本晴朗', 2: '多云', 3: '阴',
  45: '雾', 48: '雾凇',
  51: '毛毛雨', 53: '毛毛雨', 55: '毛毛雨',
  56: '冻毛毛雨', 57: '冻毛毛雨',
  61: '小雨', 63: '中雨', 65: '大雨',
  66: '冻雨', 67: '冻雨',
  71: '小雪', 73: '中雪', 75: '大雪', 77: '雪粒',
  80: '阵雨', 81: '强阵雨', 82: '暴雨',
  85: '阵雪', 86: '强阵雪',
  95: '雷阵雨', 96: '雷阵雨伴冰雹', 99: '强雷暴伴冰雹',
}

const WEEK = ['周日', '周一', '周二', '周三', '周四', '周五', '周六']

// 家人常驻城市：爸妈在成都，妹妹在深圳（妈妈周末去杭州旅游时直接说"杭州"即可）
const FAMILY = {
  '妈妈': '成都', '老妈': '成都', '我妈': '成都', '母亲': '成都',
  '爸爸': '成都', '老爸': '成都', '我爸': '成都', '父亲': '成都', '爸妈': '成都',
  '妹妹': '深圳', '小妹': '深圳', '妹': '深圳',
}

function umbrella(prob, sum) {
  if (prob >= 90 || sum >= 20) return '必带伞（雷雨/暴雨风险高）'
  if (prob >= 60 || sum >= 3) return '建议带伞'
  if (prob >= 30) return '可备一把伞'
  return '基本不用带伞'
}

export function apply(ctx) {
  ctx.tools.register(defineTool({
    name: 'weather_city',
    description: '查任意城市天气：当前天气 + 未来1-7天预报，含降水概率、雨量和带伞建议。支持中文城市名（杭州/成都/深圳/北京等）和家庭成员别名（妈妈/爸爸/爸妈→成都，妹妹→深圳）。',
    parameters: {
      city: { type: 'string', required: true, description: '城市名或家庭成员称呼，如 杭州、成都、深圳、妈妈、妹妹' },
      days: { type: 'number', description: '预报天数 1-7，默认 1' },
    },
    output: {
      schema: { type: 'string' },
      render: (_a, v) => [{ type: 'text', text: v }],
    },
    async execute(args) {
      let cityName = String(args.city || '').trim()
      if (!cityName) return '请提供城市名，如 杭州 / 成都 / 深圳'
      if (FAMILY[cityName]) cityName = FAMILY[cityName]
      const days = Math.min(Math.max(parseInt(args.days, 10) || 1, 1), 7)
      try {
        let geo = await fetch(`https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(cityName)}&count=1&language=zh&format=json`).then(r => r.json())
        if (!geo.results || !geo.results.length) {
          geo = await fetch(`https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(cityName)}&count=1&format=json`).then(r => r.json())
        }
        if (!geo.results || !geo.results.length) return `未找到城市「${args.city}」，试试写全称，如 杭州市`
        const p = geo.results[0]
        const url = `https://api.open-meteo.com/v1/forecast?latitude=${p.latitude}&longitude=${p.longitude}&current=temperature_2m,weather_code,relative_humidity_2m,wind_speed_10m&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max,precipitation_sum&timezone=auto&forecast_days=${days}`
        const d = await fetch(url).then(r => r.json())
        const cur = d.current
        const curW = WMO[cur.weather_code] || `代码${cur.weather_code}`
        const lines = []
        lines.push(`📍 ${p.name}${p.admin1 ? '（' + p.admin1 + '）' : ''} 当前：${curW}，${cur.temperature_2m}°C，湿度${cur.relative_humidity_2m}%，风速${cur.wind_speed_10m}km/h`)
        lines.push('')
        d.daily.time.forEach((t, i) => {
          const wc = d.daily.weather_code[i]
          const prob = d.daily.precipitation_probability_max[i]
          const sum = d.daily.precipitation_sum[i]
          const date = new Date(t + 'T00:00:00Z')
          lines.push(`${WEEK[date.getUTCDay()]} ${t.slice(5)}：${WMO[wc] || wc}｜${d.daily.temperature_2m_min[i]}~${d.daily.temperature_2m_max[i]}°C｜降水概率${prob}%｜雨量${sum}mm｜${umbrella(prob, sum)}`)
        })
        return lines.join('\n')
      } catch (e) {
        return `查询失败：${e.message}`
      }
    },
  }))
}

```
</details>

```
Evolution "weather-check" grown: active. Persisted at /Users/jinqiu/.dsh/evolve/weather-check.mjs; new tools are callable from your next step.
```

### step 2 · 🔧 `bash` {"command": "curl -s --max-time 20 'https://www.hangzhou.gov.cn/col/col812267/art/2026/art_c5558f9a6490442f8a1a0749cc80fc98.html' | python3 -c \"import sys,re,html; t=sys.stdin.read(); t=re.sub(r'<script.*?</script>','',t,flags=re.S); t=re.sub(r'<style.*?</style>','',t,flags=re.S); t=re.sub(r'<[^>]+>',' ',t); t=html.unescape(t); t=re.sub(r'\\s+',' ',t); print(t[:1500])\"", "description": "Read Han…

```
 403 Forbidden 403 Forbidden openresty 

```

工具已装好 ✅。现在用新工具查杭州周末 + 成都/深圳（顺便验证家人城市都好用），并搜一下台风"白海豚"对杭州的影响：

### step 3 · 🔧 `weather_city` {"city": "杭州", "days": 7}

```
📍 杭州（浙江） 当前：基本晴朗，35.2°C，湿度48%，风速11.6km/h

周四 08-06：雷阵雨｜28.3~37°C｜降水概率100%｜雨量5.8mm｜必带伞（雷雨/暴雨风险高）
周五 08-07：毛毛雨｜26.4~35.4°C｜降水概率75%｜雨量2.4mm｜建议带伞
周六 08-08：雷阵雨伴冰雹｜24.9~31.7°C｜降水概率98%｜雨量23.2mm｜必带伞（雷雨/暴雨风险高）
周日 08-09：雷阵雨伴冰雹｜24.9~28.1°C｜降水概率100%｜雨量55.8mm｜必带伞（雷雨/暴雨风险高）
周一 08-10：雷阵雨伴冰雹｜24.5~26.9°C｜降水概率94%｜雨量51.9mm｜必带伞（雷雨/暴雨风险高）
周二 08-11：雷阵雨伴冰雹｜25.8~31.4°C｜降水概率81%｜雨量34.5mm｜必带伞（雷雨/暴雨风险高）
周三 08-12：雷阵雨伴冰雹｜26.1~28°C｜降水概率64%｜雨量24mm｜必带伞（雷雨/暴雨风险高）
```

### step 3 · 🔧 `weather_city` {"city": "成都"}

```
📍 成都（四川） 当前：基本晴朗，27.9°C，湿度71%，风速5.7km/h

周四 08-06：雷阵雨｜23.1~30.2°C｜降水概率64%｜雨量2.7mm｜建议带伞
```

### step 3 · 🔧 `weather_city` {"city": "妹妹"}

```
📍 深圳（广东） 当前：基本晴朗，31.7°C，湿度59%，风速2.7km/h

周四 08-06：阴｜24.4~33.3°C｜降水概率27%｜雨量0mm｜基本不用带伞
```

### step 3 · 🔧 `web_search` {"query": "台风 白海豚 杭州 8月8日 8月9日 影响 降雨"}

```
Sources:
- [台风“白海豚”趋近中国东部沿海 强降雨将至](https://www.zaobao.com/news/china/story20260805-9473064)
- [台风“白海豚”将影响浙江](https://news.hangzhou.com.cn/zjnews/content/2026-08/06/content_9273176.htm)
- [台风“白海豚”路径及其对我国的影响将于8月6日后趋于明朗，或影响上海浙江](https://nw.eastday.com/zq/zh/20260804/a12823d18df18075f42a16ce2be5231c.html)
- [“白海豚”逼近，各部门严阵以待 我省启动海上防台风应急响应](https://news.hangzhou.com.cn/zjnews/content/2026-08/06/content_9273262.htm)
- [本周天气复杂多变 “白海豚”靠近需警惕](https://www.linping.gov.cn/col/col1229531838/art/2026/art_7a27bb1e452e4a0ebb7060cfc516cdd6.html)
- [周末台风白海豚风雨开始登场 华东等地将有强风雨 北方地区也要关注台风动态](https://m.gmw.cn/2026-08/05/content_1304543432.htm)
- [确定影响浙江！台风“白海豚”步步紧逼，周末有大到暴雨！“三台共舞”来了，浙江省启动海上防台风应急响应！](https://news.qq.c…
```

查到了，给你说清楚 👇

## 杭州周六（8/8）天气：**必须带伞，而且是大暴雨**

| 日期 | 天气 | 气温 | 降水概率 | 雨量 |
|---|---|---|---|---|
| **周六 08-08** | ⛈️ 雷阵雨伴冰雹 | 24.9~31.7°C | **98%** | **23.2mm** |
| 周日 08-09 | ⛈️ 雷阵雨伴冰雹 | 24.9~28.1°C | 100% | **55.8mm** |

**结论：伞必须带，而且要带防风雨的伞（或备雨衣）。** 台风"白海豚"周末正好影响浙江，华东有大到暴雨（[联合早报](https://www.zaobao.com/news/china/story20260805-9473064)、[杭州网](https://news.hangzhou.com.cn/zjnews/content/2026-08/06/content_9273176.htm)、[光明网](https://m.gmw.cn/2026-08/05/content_1304543432.htm) 都确认了）。这周六高温会退（降到 32°C 以下），但雨是真不小——周日甚至更夸张（55.8mm）。**如果行程能调，建议避开周日；周六出门穿防滑鞋，伞要结实点的。**

## 以后查家里人天气方便了 ☂️

我给自己装了个常驻的天气工具（`weather-check`），**你以后直接说就行，不用带任何参数**：

- "**杭州**天气怎么样" / "**成都**这周下雨吗" → 直接查任意城市
- "**爸妈**那边天气" → 自动对应 **成都**
- "**妹妹**那边天气" → 自动对应 **深圳**
- 还能指定看几天，比如"深圳 3 天预报"

顺手给你验了一下家人城市（都没问题）：

- **成都（爸妈）**：今天 23~30°C，雷阵雨概率 64%，**今天出门建议带伞**
- **深圳（妹妹）**：24~33°C 阴天，降水概率 27%，**不用带伞**

以后想问随时开口就行～ 另外提醒一句：台风路径周末还会变，出发前可以再问我一次最新预报。
