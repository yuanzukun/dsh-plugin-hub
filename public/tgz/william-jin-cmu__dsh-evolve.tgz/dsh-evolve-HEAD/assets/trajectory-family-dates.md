# Trajectory: 家庭纪念日（日子长进工具里，随口一问马上答）

真实 E2E 会话记录（`dsh web` RPC 驱动，DeepSeek-V4-Flash，未经剪辑；从 session.history 事件流提取）。

**用户输入：**

> 帮我记几个日子：宝宝是 2026 年 3 月 18 号出生的，我和老婆的结婚纪念日是 5 月 20 号，我妈生日是 11 月 2 号。以后我随口问宝宝多大了、离纪念日还有几天、快到谁生日了，你都要能马上答上来

我来给你把这个能力固化下来：先建一个常驻的"家庭纪念日"工具（存下这三个日子），之后每次会话你随口一问，我就能直接算出来。

先看一下当前日期（用来验证计算），同时挂载这个能力：

### step 1 · 🔧 `bash` {"command": "date \"+%Y-%m-%d %A\"", "description": "Show current date for verification"}

```
2026-08-06 Thursday

```

### step 1 · 🔧 `evolve_add` {"name": "family-reminders", "description": "家庭重要日期常驻工具：宝宝年龄（2026-03-18 出生）、结婚纪念日倒计时（5-20）、下次是谁的生日（宝宝 03-18 / 妈妈 11-02）。用户随口问\"宝宝多大了/离纪念日几天/快到谁生日\"时调用。"}

<details><summary>模型现场编写的插件源码（source 参数）</summary>

```js
import { defineTool } from '@deepseek-ai/dsh-tools'

export const name = 'family-reminders'
export const inject = ['tools']

// ---- 家庭重要日期（要改日子：改这里，或重新 evolve_add 同名覆盖）----
const BABY_BIRTH = { year: 2026, month: 3, day: 18 } // 宝宝出生日
const ANNIVERSARY = { month: 5, day: 20 }            // 结婚纪念日（每年 5 月 20 日）
const MOM_BIRTHDAY = { month: 11, day: 2 }           // 妈妈生日（每年 11 月 2 日）

const MS_DAY = 24 * 60 * 60 * 1000

function parseOn(on) {
  if (!on) {
    const now = new Date()
    return { year: now.getFullYear(), month: now.getMonth() + 1, day: now.getDate() }
  }
  const m = /^(\d{4})-(\d{1,2})-(\d{1,2})$/.exec(String(on).trim())
  if (!m) throw new Error(`日期格式应为 YYYY-MM-DD，收到: ${on}`)
  return { year: +m[1], month: +m[2], day: +m[3] }
}

function toDate(p) { return new Date(p.year, p.month - 1, p.day) }

function diffDays(from, to) {
  return Math.round((toDate(to) - toDate(from)) / MS_DAY)
}

function ageParts(birth, from) {
  let years = from.year - birth.year
  if (from.month < birth.month || (from.month === birth.month && from.day < birth.day)) years--
  let anchorYear = from.year
  if (from.month < birth.month || (from.month === birth.month && from.day < birth.day)) anchorYear = from.year - 1
  let months = (from.year - anchorYear) * 12 + (from.month - birth.month)
  let days = from.day - birth.day
  if (days < 0) {
    months--
    days += new Date(from.year, from.month - 1, 0).getDate() // 上个月的天数
  }
  return { years, months, days }
}

function nextOccurrence(month, day, from) {
  let y = from.year
  if (month < from.month || (month === from.month && day < from.day)) y++
  return { year: y, month, day }
}

function fmtDate(p) {
  return `${p.year}-${String(p.month).padStart(2, '0')}-${String(p.day).padStart(2, '0')}`
}

export function apply(ctx) {
  ctx.tools.register(defineTool({
    name: 'family_baby_age',
    description: '查询宝宝多大了（宝宝出生于 2026-03-18）。返回 岁/月/天、出生总天数、下次生日和还有几天。可选参数 on 指定计算基准日期 YYYY-MM-DD，默认今天。',
    parameters: {
      on: { type: 'string', description: '可选，计算基准日期 YYYY-MM-DD，默认今天' },
    },
    output: {
      schema: { type: 'string' },
      render: (_a, v) => [{ type: 'text', text: v }],
    },
    async execute(args) {
      const from = parseOn(args.on)
      const birth = BABY_BIRTH
      if (toDate(from) < toDate(birth)) return `宝宝还没出生（预产/出生日 ${fmtDate(birth)}）。`
      const a = ageParts(birth, from)
      const totalDays = diffDays(birth, from)
      const next = nextOccurrence(birth.month, birth.day, from)
      const isToday = next.year === from.year && next.month === from.month && next.day === from.day
      let line = `截至 ${fmtDate(from)}：宝宝 ${a.years} 岁 ${a.months} 个月 ${a.days} 天（出生于 ${fmtDate(birth)}，共 ${totalDays} 天）。`
      if (isToday) line += ` 今天就是宝宝生日，${a.years + 1} 岁啦！🎂`
      else line += ` 下次生日：${fmtDate(next)}（${a.years + 1} 岁），还有 ${diffDays(from, next)} 天。`
      return line
    },
  }))

  ctx.tools.register(defineTool({
    name: 'family_anniversary',
    description: '查询离结婚纪念日（每年 5 月 20 日）还有几天。可选参数 on 指定计算基准日期 YYYY-MM-DD，默认今天。',
    parameters: {
      on: { type: 'string', description: '可选，计算基准日期 YYYY-MM-DD，默认今天' },
    },
    output: {
      schema: { type: 'string' },
      render: (_a, v) => [{ type: 'text', text: v }],
    },
    async execute(args) {
      const from = parseOn(args.on)
      const next = nextOccurrence(ANNIVERSARY.month, ANNIVERSARY.day, from)
      const d = diffDays(from, next)
      if (d === 0) return `今天就是结婚纪念日（${fmtDate(next)}）！🎉`
      return `离下一个结婚纪念日（${fmtDate(next)}，每年 5 月 20 日）还有 ${d} 天。`
    },
  }))

  ctx.tools.register(defineTool({
    name: 'family_next_birthday',
    description: '查询快到谁的生日了：宝宝 03-18、妈妈 11-02，按距离排序并给出各自还有几天。可选参数 on 指定计算基准日期 YYYY-MM-DD，默认今天。',
    parameters: {
      on: { type: 'string', description: '可选，计算基准日期 YYYY-MM-DD，默认今天' },
    },
    output: {
      schema: { type: 'string' },
      render: (_a, v) => [{ type: 'text', text: v }],
    },
    async execute(args) {
      const from = parseOn(args.on)
      const entries = [
        { name: '宝宝', month: BABY_BIRTH.month, day: BABY_BIRTH.day, birthYear: BABY_BIRTH.year },
        { name: '妈妈', month: MOM_BIRTHDAY.month, day: MOM_BIRTHDAY.day, birthYear: null },
      ]
      const rows = entries.map((e) => {
        const next = nextOccurrence(e.month, e.day, from)
        const d = diffDays(from, next)
        let ageNote = ''
        if (e.birthYear != null) {
          const turn = next.year - e.birthYear
          ageNote = d === 0 ? `（今天 ${turn} 岁生日！）` : `（${turn} 岁）`
        } else {
          ageNote = d === 0 ? '（就是今天！）' : ''
        }
        return `${e.name}的生日：${fmtDate(next)}${ageNote}，还有 ${d} 天`
      })
      rows.sort((x, y) => diffDays(from, nextOccurrence(MOM_BIRTHDAY.month, MOM_BIRTHDAY.day, from)) - diffDays(from, nextOccurrence(BABY_BIRTH.month, BABY_BIRTH.day, from)))
      const soonest = [...entries].sort((a, b) => diffDays(from, nextOccurrence(a.month, a.day, from)) - diffDays(from, nextOccurrence(b.month, b.day, from)))[0]
      const soonestNext = nextOccurrence(soonest.month, soonest.day, from)
      const soonestD = diffDays(from, soonestNext)
      const head = soonestD === 0 ? `今天是 ${soonest.name} 的生日！` : `下一个生日是 ${soonest.name}（${fmtDate(soonestNext)}），还有 ${soonestD} 天。`
      const sorted = [...entries].sort((a, b) => diffDays(from, nextOccurrence(a.month, a.day, from)) - diffDays(from, nextOccurrence(b.month, b.day, from)))
      return head + '\n' + sorted.map((e) => {
        const next = nextOccurrence(e.month, e.day, from)
        const d = diffDays(from, next)
        let ageNote = ''
        if (e.birthYear != null) {
          const turn = next.year - e.birthYear
          ageNote = d === 0 ? `（今天 ${turn} 岁生日！）` : `（${turn} 岁）`
        } else {
          ageNote = d === 0 ? '（就是今天！）' : ''
        }
        return `· ${e.name}：${fmtDate(next)}${ageNote}，还有 ${d} 天`
      }).join('\n')
    },
  }))
}

```
</details>

```
Evolution "family-reminders" grown: active. Persisted at /Users/jinqiu/.dsh/evolve/family-reminders.mjs; new tools are callable from your next step.
```

能力已挂载成功 ✅ 今天是 **2026-08-06**，我马上验证三个工具算得对不对：

### step 2 · 🔧 `family_baby_age` {}

```
截至 2026-08-06：宝宝 0 岁 4 个月 19 天（出生于 2026-03-18，共 141 天）。 下次生日：2027-03-18（1 岁），还有 224 天。
```

### step 2 · 🔧 `family_anniversary` {}

```
离下一个结婚纪念日（2027-05-20，每年 5 月 20 日）还有 287 天。
```

### step 2 · 🔧 `family_next_birthday` {}

```
下一个生日是 妈妈（2026-11-02），还有 88 天。
· 妈妈：2026-11-02，还有 88 天
· 宝宝：2027-03-18（1 岁），还有 224 天
```

全部验证通过 ✅ 数字我手工核对过，都对。三个日子已经记牢了：

| 日子 | 日期 |
|---|---|
| 👶 宝宝出生 | 2026-03-18 |
| 💍 结婚纪念日 | 每年 5 月 20 日 |
| 🎂 妈妈生日 | 每年 11 月 2 日 |

**我做了什么**：给这个会话环境装了一个常驻的「家庭纪念日」工具（`family-reminders`），三个日期固化在里面，以后任何会话你随口问，我都会自动调它算，不用再报一遍日期。

**刚才的实测**（以今天 2026-08-06 为准）：
- 宝宝 **0 岁 4 个月 19 天**（出生 141 天），下次生日 2027-03-18 过 1 岁，还有 224 天
- 离结婚纪念日（2027-05-20）还有 **287 天**
- 下一个生日是**妈妈**（11-02），还有 **88 天**；然后是宝宝（224 天）

以后你直接问「宝宝多大了」「离纪念日还有几天」「快到谁生日了」，我都能秒答。

另外，如果你愿意补两个信息，我还能答得更细：**结婚的年份**（可以算"第几个纪念日"）和**妈妈的出生年份**（可以算妈妈今年多大）。要的话告诉我一声就行～
