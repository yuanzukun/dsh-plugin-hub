# Trajectory: 干完活自动记工作日志（非工具进化 · agent/settled 监听器）

真实 E2E 会话记录（`dsh web` RPC 驱动，DeepSeek-V4-Flash，未经剪辑；从 session.history 事件流提取）。

**用户输入：**

> 我有个习惯问题：每天干了什么老是想不起来。以后你每次帮我做完一件事，就自动往当前目录的 worklog.md 里追加一行（日期时间 + 一句话干了什么），注意是"每次、自动"——别指望你自己记得，也别每次问我。装好之后，帮我算一下这组数的均值和标准差：12, 47, 33, 8, 59, 21，顺便看看日志是不是真的记上了。

### Turn 1 · 🔧 `bash` ×2 → `evolve_add` {"name": "worklog"} → `evolve_list`

agent 先确认 cwd 和文件现状、用 node 算好统计量，然后长出 **worklog**——整个插件只有一个注册面，零工具：

```js
ctx.on('agent/settled', (agent, turn, reason) => {
  ensureFile(file)
  const summary = summarize(agent)   // 取本轮最后一条 assistant 消息的可见文本，清掉 markdown，截 100 字
  appendFileSync(file, `${formatTime(new Date())} ${summary}\n`)
})
```

> ✅ 装好了：插件「worklog」已激活，以后每个回合结束自动往 `/tmp/evolve-nontool-ws/worklog.md` 追加一行（时间+摘要），无需提醒。 📊 计算：… 均值 = 30 …

这个 turn 一结束，监听器就把它自己记了下来（第一行日志）。

### Turn 2 · 关键验证：零工具调用的普通回答，日志照记

> 用户：帮我把这个 base64 解一下：aGVsbG8gZXZvbHZl

> agent：解码结果：**hello evolve**（"你好，进化"）

**本轮事件流里没有任何 tool/call**——模型只是回答了问题，写日志发生在 `agent/settled` 的普通代码里，没有模型回合、没有工具调用、没有"记得"这个环节。settle 后 worklog.md 里多了一行：

```
2026-08-06 15:02 解码结果： hello evolve （"你好，进化"）
```

### Turn 3 · 让 agent 自己念日志（这个动作本身也被记了进去）

> 用户：把 worklog.md 的内容念给我看看

> agent：日志已自动记录，两行都在：14:56 装好 worklog 插件 + 计算均值/标准差；15:02 解码 base64（hello evolve）。自动追加机制验证通过 ✓

最终文件（第三行就是"念日志"这轮自己）：

```
# Worklog

2026-08-06 14:56 ✅ 装好了：插件「worklog」已激活，以后每个回合结束自动往 /tmp/evolve-nontool-ws/worklog.md 追加一行（时间+摘要），无需提醒。 📊 计算：12, 47, 3
2026-08-06 15:02 解码结果： hello evolve （"你好，进化"）
2026-08-06 15:11 日志已自动记录，两行都在： - 14:56 装好 worklog 插件 + 计算均值/标准差 - 15:02 解码 base64（hello evolve） 自动追加机制验证通过 ✓
```

## 为什么这必须是非工具进化

"每次、自动"是需求的全部。如果做成 `log_work` 工具，等于把"每个 turn 末尾记得调一次"押在模型的自觉上——漏一次，日志就有洞，而漏掉恰恰发生在最忙、最长的会话里。`agent/settled` 监听器把"记录"从模型的决策空间里拿走了：turn 提交是事实，监听器跟着事实走，一个模型 token 都不花。
