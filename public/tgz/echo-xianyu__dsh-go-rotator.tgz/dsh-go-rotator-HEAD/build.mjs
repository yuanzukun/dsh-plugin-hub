// Build the browser client bundle (lib/client.js) with esbuild.
// Mirrors the official dsh client-bundle contract:
//   - CJS factory artifact: window.__ModuleLoader__.load({ id, factory })
//   - Platform modules stay external (resolved from the loader module table)
//   - Everything else inlined
// Usage: node build.mjs

import { build } from "esbuild";
import { readFileSync } from "node:fs";

const pkg = JSON.parse(readFileSync(new URL("./package.json", import.meta.url), "utf8"));
const id = pkg.name;

// Same platform module table as packages/client/web/src/platform.ts plus the
// documented runtime store exemption.
const CLIENT_EXTERNALS = [
  "react",
  "react/jsx-runtime",
  "react-dom",
  "react-dom/client",
  "@deepseek-ai/cordis",
  "@deepseek-ai/dsh-client-ui-slots",
  "@deepseek-ai/dsh-client-web-react",
  "@deepseek-ai/dsh-client-ui-primitives",
  "@deepseek-ai/dsh-client-ui-attachment",
  "@deepseek-ai/dsh-client-schema-form",
  "@deepseek-ai/dsh-client-runtime/client",
];

await build({
  entryPoints: ["src/client/index.tsx"],
  outfile: "lib/client.js",
  bundle: true,
  format: "cjs",
  platform: "browser",
  target: "es2020",
  sourcemap: true,
  jsx: "automatic",
  external: CLIENT_EXTERNALS,
  define: {
    "process.env.NODE_ENV": JSON.stringify(process.env.NODE_ENV ?? "production"),
  },
  banner: {
    js: `window.__ModuleLoader__.load({ id: ${JSON.stringify(id)}, factory: (require) => {\nvar module = { exports: {} }; var exports = module.exports;`,
  },
  footer: {
    js: "return module.exports; } });",
  },
});

console.log("client bundle written: lib/client.js");
