// OpenCode Go model price table (per 1M tokens, in USD).
// Source: https://opencode.ai/docs/go/  (Endpoints + price table)
// Used to estimate cost from token usage emitted in llm/stream usage chunks
// (dsh-llm's TokenUsage carries tokens only, no cost).
// Ported unchanged from the Pi opencode-go-rotator extension.

export interface ModelPricing {
  input: number;
  output: number;
  cachedRead: number;
  cachedWrite: number | null;
}

// Prices are USD per 1,000,000 tokens.
export const PRICETABLE: Record<string, ModelPricing> = {
  "glm-5.2": { input: 1.4, output: 4.4, cachedRead: 0.26, cachedWrite: null },
  "glm-5.1": { input: 1.4, output: 4.4, cachedRead: 0.26, cachedWrite: null },
  "kimi-k2.7-code": { input: 0.95, output: 4.0, cachedRead: 0.19, cachedWrite: null },
  "kimi-k2.6": { input: 0.95, output: 4.0, cachedRead: 0.16, cachedWrite: null },
  "mimo-v2.5": { input: 0.14, output: 0.28, cachedRead: 0.0028, cachedWrite: null },
  "mimo-v2.5-pro": { input: 1.74, output: 3.48, cachedRead: 0.0145, cachedWrite: null },
  "minimax-m3": { input: 0.3, output: 1.2, cachedRead: 0.06, cachedWrite: null },
  "minimax-m2.7": { input: 0.3, output: 1.2, cachedRead: 0.06, cachedWrite: 0.375 },
  "minimax-m2.5": { input: 0.3, output: 1.2, cachedRead: 0.06, cachedWrite: 0.375 },
  "qwen3.7-max": { input: 2.5, output: 7.5, cachedRead: 0.5, cachedWrite: 3.125 },
  // Qwen3.7 Plus is tiered by context size; we use the <=256K tier by default.
  "qwen3.7-plus": { input: 0.4, output: 1.6, cachedRead: 0.04, cachedWrite: 0.5 },
  "qwen3.6-plus": { input: 0.5, output: 3.0, cachedRead: 0.05, cachedWrite: 0.625 },
  "deepseek-v4-pro": { input: 1.74, output: 3.48, cachedRead: 0.0145, cachedWrite: null },
  "deepseek-v4-flash": { input: 0.14, output: 0.28, cachedRead: 0.0028, cachedWrite: null },
};

// Go subscription hard limits in USD (for estimated-cost display only;
// real remaining quota comes from the dashboard scraper).
export const GO_LIMITS = {
  fiveHour: 12,
  weekly: 30,
  monthly: 60,
};

export interface TokenUsage {
  inputTokens?: number;
  outputTokens?: number;
  cachedReadTokens?: number;
  cachedWriteTokens?: number;
}

// Resolve pricing for a model id, tolerating provider-prefixed forms like
// "opencode-go/glm-5.2" and minor casing differences.
export function resolvePricing(modelId: string): ModelPricing | null {
  if (!modelId) return null;
  const id = modelId.toLowerCase();
  const bare = id.split("/").pop() ?? id;
  if (PRICETABLE[bare]) return PRICETABLE[bare];
  // try without dots/dashes normalization as a last resort
  for (const k of Object.keys(PRICETABLE)) {
    if (k.replace(/[-_.]/g, "") === bare.replace(/[-_.]/g, "")) return PRICETABLE[k];
  }
  return null;
}

export function estimateCostUsd(modelId: string, u: TokenUsage): number {
  const p = resolvePricing(modelId);
  if (!p) return 0;
  const per = (n: number | undefined, price: number | null) =>
    n && price ? (n / 1_000_000) * price : 0;
  return (
    per(u.inputTokens, p.input) +
    per(u.outputTokens, p.output) +
    per(u.cachedReadTokens, p.cachedRead) +
    per(u.cachedWriteTokens, p.cachedWrite)
  );
}
