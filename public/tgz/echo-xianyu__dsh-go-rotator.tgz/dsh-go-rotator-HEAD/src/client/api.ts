// API client for the go-rotator HTTP server (port 7777 by default, matching
// the Pi extension's GUI contract). The dsh web UI runs on a different port,
// so the server answers with CORS "*".

export interface GoState {
  keys: { name: string; key: string; hasWorkspace: boolean; hasCookie: boolean }[];
  activeKeyIndex: number;
  cooldownMinutes: number;
  disableThresholdPercent: number;
  scrapeIntervalMs: number;
  watchdogEnabled: boolean;
  watchdogIdleMs: number;
  guiPort: number;
  cooldowns: Record<string, string>;
  disabledUntil: Record<string, { window: string; untilIso: string }>;
  usage: Record<string, {
    current5h: WindowUsage;
    currentWeek: WindowUsage;
    currentMonth: WindowUsage;
  }>;
  scraped: Record<string, { ok: boolean; quota?: unknown; error?: string; fetchedAt: string }>;
  rotationLog: { ts: string; from: string; to: string; reason: string }[];
  statsFile: string;
}

export interface WindowUsage {
  costUsd: number;
  requests: number;
  windowStartIso: string;
  byModel: Record<string, ModelUsage>;
}

export interface ModelUsage {
  requests: number;
  costUsd: number;
  inputTokens: number;
  outputTokens: number;
  cachedReadTokens: number;
  cachedWriteTokens?: number;
}

export interface StatRows {
  period: string;
  isCurrent: boolean;
  total: { requests: number; costUsd: number; inputTokens: number; outputTokens: number; cachedReadTokens: number; cachedWriteTokens: number; byModel: Record<string, ModelUsage> };
  keys: Record<string, { requests: number; costUsd: number; inputTokens: number; outputTokens: number; cachedReadTokens: number; cachedWriteTokens: number; byModel: Record<string, ModelUsage> }>;
}

export interface StatsResponse {
  days: number;
  months: number;
  years: number;
  statsFile: string;
  daily: StatRows[];
  monthly: StatRows[];
  yearly: StatRows[];
}

export interface DebugResponse {
  events: { ts: string; kind: string; msg: string }[];
  env: { pid: number; uptimeSec: number; keysConfigured: number };
  stats: { file: string; dailyBuckets: number; monthlyBuckets: number; yearlyBuckets: number };
}

let baseUrl = `http://127.0.0.1:${localStorage.getItem("go-rotator:port") ?? 7777}`;
export function setApiPort(port: number) {
  baseUrl = `http://127.0.0.1:${port}`;
  localStorage.setItem("go-rotator:port", String(port));
}
export function apiPort(): number {
  return Number(new URL(baseUrl).port);
}

async function call<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(`${baseUrl}${path}`, {
    ...init,
    headers: { "content-type": "application/json", ...(init?.headers ?? {}) },
  });
  if (!res.ok) throw new Error(`HTTP ${res.status}: ${await res.text().catch(() => "")}`);
  return res.json() as Promise<T>;
}

export const api = {
  state: () => call<GoState>("/api/state"),
  stats: (days = 30, months = 12, years = 6) =>
    call<StatsResponse>(`/api/stats?days=${days}&months=${months}&years=${years}`),
  debug: () => call<DebugResponse>("/api/debug"),
  addKey: (body: { name: string; key: string; workspaceId?: string; authCookie?: string }) =>
    call<{ ok: boolean }>("/api/keys", { method: "POST", body: JSON.stringify(body) }),
  updateKey: (i: number, body: Record<string, unknown>) =>
    call<{ ok: boolean }>(`/api/keys/${i}`, { method: "POST", body: JSON.stringify(body) }),
  deleteKey: (i: number) => call<{ ok: boolean }>(`/api/keys/${i}`, { method: "DELETE" }),
  setActive: (i: number) => call<{ ok: boolean }>(`/api/active/${i}`, { method: "POST" }),
  clearCooldowns: () => call<{ ok: boolean }>("/api/clear-cooldowns", { method: "POST" }),
  updateSettings: (body: Record<string, unknown>) =>
    call<{ ok: boolean }>("/api/settings", { method: "POST", body: JSON.stringify(body) }),
  rotate: () => call<{ ok: boolean; rotated: boolean; active: string | null }>("/api/rotate", { method: "POST" }),
  scrapeNow: () => call<{ ok: boolean; started: boolean }>("/api/scrape/now", { method: "POST" }),
  health: () => call<{ ok: boolean }>("/health"),
};
