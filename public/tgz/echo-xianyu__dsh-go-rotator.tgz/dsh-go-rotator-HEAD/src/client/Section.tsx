// OpenCode Go rotator settings section: keys management, dual-window usage,
// long-term stats, settings, and a debug event panel. Consumes the node half's
// HTTP API (port 7777 default). Styling uses the dsh web semantic tokens
// (--dsw-alias-*) so the panel follows the host light/dark theme.

import { useCallback, useEffect, useMemo, useState } from "react";
import { api, apiPort, setApiPort } from "./api.ts";
import type { GoState, StatsResponse, DebugResponse } from "./api.ts";
import { GO_LIMITS } from "../pricetable.ts";
import { ModelBarChart, TrendLine, tokSum, aggregateModels, colorForModel, CHART_CSS, LINE_CSS } from "./Charts.tsx";
import type { ChartRow } from "./Charts.tsx";

const STYLE = `
/* Fallback palette follows the dsh theme switch (body[data-ds-dark-theme]);
   --dsw-alias-* tokens win when the host theme defines them. */
.go-rotator {
  --go-rot-bg-1: #ffffff;
  --go-rot-bg-2: #f6f7f9;
  --go-rot-bg-3: #eef0f3;
  --go-rot-border: #e2e5ea;
  --go-rot-fg: #1f2328;
  --go-rot-fg-2: #444b56;
  --go-rot-fg-3: #767d8a;
  --go-rot-brand: #2563eb;
  --go-rot-brand-strong: #1d4ed8;
  --go-rot-on-brand: #ffffff;
  --go-rot-success: #16a34a;
  --go-rot-error: #dc2626;
  --go-rot-warn: #f59e0b;
  --go-rot-warn-fg: #b45309;
  --go-rot-hover: #f0f2f6;
  --go-rot-hover-accent: #c7d2fe;
}
body[data-ds-dark-theme] .go-rotator {
  --go-rot-bg-1: #17191d;
  --go-rot-bg-2: #1f2227;
  --go-rot-bg-3: #2a2e35;
  --go-rot-border: #363b44;
  --go-rot-fg: #e8eaed;
  --go-rot-fg-2: #a7adba;
  --go-rot-fg-3: #767d8a;
  --go-rot-brand: #5b8def;
  --go-rot-brand-strong: #3b6fe0;
  --go-rot-on-brand: #0b1220;
  --go-rot-success: #4ade80;
  --go-rot-error: #f87171;
  --go-rot-warn: #fbbf24;
  --go-rot-warn-fg: #fbbf24;
  --go-rot-hover: #2a2e35;
  --go-rot-hover-accent: #374151;
}
.go-rotator {
  font-size: 13px;
  color: var(--dsw-alias-label-primary, var(--go-rot-fg));
  display: flex;
  flex-direction: column;
  gap: 14px;
}
.go-rotator .statusbar { display: flex; gap: 8px; align-items: center; flex-wrap: wrap; }
.go-rotator .statusbar .spacer { flex: 1; }
.go-rotator .statusbar .actions { display: flex; gap: 8px; align-items: center; }
.go-rotator .row { display: flex; gap: 8px; align-items: center; flex-wrap: wrap; }
.go-rotator .pill {
  display: inline-flex; align-items: center; gap: 5px;
  padding: 3px 10px; border-radius: 999px; font-size: 12px; font-weight: 600;
  background: var(--dsw-alias-bg-layer-3, var(--go-rot-bg-3));
  border: 1px solid var(--dsw-alias-border-l, var(--go-rot-border));
  color: var(--dsw-alias-label-secondary, var(--go-rot-fg-2));
}
.go-rotator .pill.active {
  background: color-mix(in srgb, var(--dsw-alias-state-success-primary, var(--go-rot-success)) 14%, transparent);
  color: var(--dsw-alias-state-success-primary, var(--go-rot-success));
  border-color: color-mix(in srgb, var(--dsw-alias-state-success-primary, var(--go-rot-success)) 40%, transparent);
}
.go-rotator .pill.warn {
  background: color-mix(in srgb, var(--go-rot-warn) 14%, transparent);
  color: var(--go-rot-warn-fg);
  border-color: color-mix(in srgb, var(--go-rot-warn) 40%, transparent);
}
.go-rotator .pill.off {
  background: color-mix(in srgb, var(--dsw-alias-state-error-primary, var(--go-rot-error)) 12%, transparent);
  color: var(--dsw-alias-state-error-primary, var(--go-rot-error));
  border-color: color-mix(in srgb, var(--dsw-alias-state-error-primary, var(--go-rot-error)) 40%, transparent);
}
.go-rotator .cards {
  display: grid;
  grid-template-columns: repeat(5, minmax(0, 1fr));
  gap: 10px;
}
@media (max-width: 1100px) {
  .go-rotator .cards { grid-template-columns: repeat(3, minmax(0, 1fr)); }
}
@media (max-width: 700px) {
  .go-rotator .cards { grid-template-columns: repeat(2, minmax(0, 1fr)); }
}
.go-rotator .card {
  background: var(--dsw-alias-bg-layer-2, var(--go-rot-bg-2));
  border: 1px solid var(--dsw-alias-border-l, var(--go-rot-border));
  border-radius: 10px;
  padding: 12px 14px;
  transition: border-color .15s ease;
}
.go-rotator .card:hover { border-color: var(--dsw-alias-interactive-bg-hover-accent, var(--go-rot-hover-accent)); }
.go-rotator .card .label { font-size: 11px; font-weight: 600; opacity: .62; letter-spacing: .2px; }
.go-rotator .card .num { font-size: 21px; font-weight: 750; font-variant-numeric: tabular-nums; margin-top: 3px; letter-spacing: -.2px; }
.go-rotator .card .sub { font-size: 11px; opacity: .55; margin-top: 2px; }
.go-rotator .bar { height: 8px; border-radius: 999px; background: var(--dsw-alias-bg-layer-3, var(--go-rot-bg-3)); margin-top: 7px; overflow: hidden; }
.go-rotator .bar > span { display: block; height: 100%; border-radius: 999px; background: var(--dsw-alias-state-success-primary, var(--go-rot-success)); }
.go-rotator .bar > span.over { background: var(--dsw-alias-state-error-primary, var(--go-rot-error)); }
.go-rotator .panel {
  background: var(--dsw-alias-bg-layer-2, var(--go-rot-bg-2));
  border: 1px solid var(--dsw-alias-border-l, var(--go-rot-border));
  border-radius: 12px;
  padding: 14px 16px;
}
.go-rotator .panel-title {
  font-size: 13px; font-weight: 700; margin: 0 0 10px;
  color: var(--dsw-alias-label-primary, var(--go-rot-fg));
}
.go-rotator table { width: 100%; border-collapse: collapse; }
.go-rotator th, .go-rotator td {
  text-align: left; padding: 7px 10px;
  border-bottom: 1px solid var(--dsw-alias-border-l, var(--go-rot-border));
  font-variant-numeric: tabular-nums;
  vertical-align: middle;
}
.go-rotator th {
  font-size: 11px; text-transform: uppercase; letter-spacing: .6px;
  color: var(--dsw-alias-label-secondary, var(--go-rot-fg-2)); font-weight: 650;
  background: var(--dsw-alias-bg-layer-3, var(--go-rot-bg-3));
}
.go-rotator thead th:first-child { border-radius: 6px 0 0 6px; }
.go-rotator thead th:last-child { border-radius: 0 6px 6px 0; }
.go-rotator tbody tr { transition: background .1s ease; }
.go-rotator tbody tr:hover { background: var(--dsw-alias-interactive-bg-hover, var(--go-rot-hover)); }
.go-rotator tbody tr.active-row { background: color-mix(in srgb, var(--dsw-alias-state-success-primary, var(--go-rot-success)) 7%, transparent); }
.go-rotator input {
  background: var(--dsw-alias-bg-layer-3, var(--go-rot-bg-3));
  border: 1.5px solid var(--dsw-alias-border-l, var(--go-rot-border));
  border-radius: 8px;
  color: var(--dsw-alias-label-primary, var(--go-rot-fg));
  padding: 6px 10px; font-size: 13px;
  transition: border-color .15s ease, box-shadow .15s ease;
  width: 100%;
  box-sizing: border-box;
}
.go-rotator input:hover { border-color: var(--dsw-alias-label-dimmed, var(--go-rot-fg-3)); }
.go-rotator input:focus {
  outline: none;
  border-color: var(--dsw-alias-brand-primary, var(--go-rot-brand));
  box-shadow: 0 0 0 3px color-mix(in srgb, var(--dsw-alias-brand-primary, var(--go-rot-brand)) 18%, transparent);
}
.go-rotator button {
  background: var(--dsw-alias-bg-layer-3, var(--go-rot-bg-3));
  border: 1px solid var(--dsw-alias-border-l, var(--go-rot-border));
  color: var(--dsw-alias-label-primary, var(--go-rot-fg));
  border-radius: 8px;
  padding: 5px 12px;
  cursor: pointer; font-size: 12px; font-weight: 550;
  transition: background .15s ease, border-color .15s ease, transform .05s ease;
  white-space: nowrap;
}
.go-rotator button:hover { background: var(--dsw-alias-interactive-bg-hover, var(--go-rot-hover)); border-color: var(--dsw-alias-border-l, var(--go-rot-border)); }
.go-rotator button:active { transform: scale(.97); }
.go-rotator button:disabled { opacity: .45; cursor: not-allowed; }
.go-rotator button.primary {
  background: var(--dsw-alias-button-primary-fill, var(--go-rot-brand));
  border-color: transparent;
  color: var(--go-rot-on-brand);
}
.go-rotator button.primary:hover { background: var(--go-rot-brand-strong); }
.go-rotator button.danger {
  background: transparent;
  border-color: color-mix(in srgb, var(--dsw-alias-state-error-primary, var(--go-rot-error)) 45%, transparent);
  color: var(--dsw-alias-state-error-primary, var(--go-rot-error));
}
.go-rotator button.danger:hover { background: color-mix(in srgb, var(--dsw-alias-state-error-primary, var(--go-rot-error)) 10%, transparent); }
.go-rotator button.small { padding: 3px 9px; font-size: 11.5px; }
.go-rotator .tabs { display: flex; gap: 2px; border-bottom: 1px solid var(--dsw-alias-border-l, var(--go-rot-border)); }
.go-rotator .tabs button {
  border: none; background: transparent; border-radius: 8px 8px 0 0;
  padding: 7px 14px; color: var(--dsw-alias-label-secondary, var(--go-rot-fg-2));
  position: relative; font-weight: 600;
}
.go-rotator .tabs button:hover { background: var(--dsw-alias-interactive-bg-hover, var(--go-rot-hover)); color: var(--dsw-alias-label-primary, var(--go-rot-fg)); }
.go-rotator .tabs button.on { color: var(--dsw-alias-label-primary, var(--go-rot-fg)); }
.go-rotator .tabs button.on::after {
  content: ''; position: absolute; left: 8px; right: 8px; bottom: -1px; height: 2px;
  border-radius: 2px; background: var(--dsw-alias-brand-primary, var(--go-rot-brand));
}
.go-rotator .err {
  color: var(--dsw-alias-state-error-primary, var(--go-rot-error));
  background: color-mix(in srgb, var(--dsw-alias-state-error-primary, var(--go-rot-error)) 8%, transparent);
  border: 1px solid color-mix(in srgb, var(--dsw-alias-state-error-primary, var(--go-rot-error)) 30%, transparent);
  border-radius: 8px; padding: 8px 12px; font-size: 12.5px;
}
.go-rotator .muted { opacity: .55; font-size: 11.5px; }
.go-rotator .tag {
  display: inline-block; font-size: 10.5px; font-weight: 600;
  padding: 1px 7px; border-radius: 5px; margin-right: 4px;
  background: var(--dsw-alias-bg-layer-3, var(--go-rot-bg-3));
  color: var(--dsw-alias-label-secondary, var(--go-rot-fg-2));
  border: 1px solid var(--dsw-alias-border-l, var(--go-rot-border));
}
.go-rotator .tag.ok { background: color-mix(in srgb, var(--dsw-alias-state-success-primary, var(--go-rot-success)) 12%, transparent); color: var(--dsw-alias-state-success-primary, var(--go-rot-success)); border-color: transparent; }
.go-rotator .tag.warn { background: color-mix(in srgb, var(--go-rot-warn) 12%, transparent); color: var(--go-rot-warn-fg); border-color: transparent; }
.go-rotator .tag.off { background: color-mix(in srgb, var(--dsw-alias-state-error-primary, var(--go-rot-error)) 10%, transparent); color: var(--dsw-alias-state-error-primary, var(--go-rot-error)); border-color: transparent; }
.go-rotator .grid2 { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 10px; }
.go-rotator .fld { display: flex; flex-direction: column; gap: 4px; }
.go-rotator .fld label { font-size: 11px; font-weight: 600; opacity: .7; }
.go-rotator .log {
  font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
  font-size: 11px; max-height: 300px; overflow: auto;
  background: var(--dsw-alias-bg-layer-1, var(--go-rot-bg-1));
  border: 1px solid var(--dsw-alias-border-l, var(--go-rot-border));
  border-radius: 8px; padding: 8px 10px; line-height: 1.7;
}
.go-rotator .log div { padding: 1px 0; white-space: nowrap; }
.go-rotator .log .t { opacity: .45; margin-right: 8px; font-variant-numeric: tabular-nums; }
.go-rotator .hint { font-size: 11px; opacity: .5; margin-top: 6px; }
/* collapse panels */
.go-rotator .collapse { border: 1px solid var(--dsw-alias-border-l, var(--go-rot-border)); border-radius: 10px; margin-bottom: 10px; overflow: hidden; background: var(--dsw-alias-bg-layer-2, var(--go-rot-bg-2)); }
.go-rotator .collapse-head {
  display: flex; align-items: center; gap: 8px; width: 100%;
  box-sizing: border-box;
  background: transparent; border: none; padding: 10px 14px;
  font-size: 13px; font-weight: 700; cursor: pointer;
  color: var(--dsw-alias-label-primary, var(--go-rot-fg));
  border-radius: 0; user-select: none;
  flex-wrap: wrap; row-gap: 6px;
}
.go-rotator .collapse-head:hover { background: var(--dsw-alias-interactive-bg-hover, var(--go-rot-hover)); }
.go-rotator .collapse-head .head-title { font-size: 13px; font-weight: 700; }
.go-rotator .collapse-head .caret {
  display: inline-block; font-size: 10px; color: var(--dsw-alias-label-dimmed, var(--go-rot-fg-3));
  transition: transform .18s ease;
}
.go-rotator .collapse-head.open .caret { transform: rotate(90deg); }
.go-rotator .collapse-head .cnt { font-size: 11px; font-weight: 550; opacity: .6; font-variant-numeric: tabular-nums; }
.go-rotator .collapse-head .extra { margin-left: auto; display: inline-flex; align-items: center; }
.go-rotator .range-switch { display: inline-flex; gap: 2px; padding: 2px; border-radius: 8px; background: var(--dsw-alias-bg-layer-3, var(--go-rot-bg-3)); }
.go-rotator .range-switch button { border: none; background: transparent; padding: 2px 10px; border-radius: 6px; font-size: 11px; color: var(--dsw-alias-label-secondary, var(--go-rot-fg-2)); }
.go-rotator .range-switch button:hover { background: var(--dsw-alias-interactive-bg-hover, var(--go-rot-hover)); }
.go-rotator .range-switch button.on { background: var(--dsw-alias-button-primary-fill, var(--go-rot-brand)); color: var(--go-rot-on-brand); }
.go-rotator .collapse-body { padding: 6px 14px 14px; animation: goRotFadeIn .2s ease; }
@keyframes goRotFadeIn { from { opacity: 0; transform: translateY(-3px); } to { opacity: 1; transform: none; } }
/* quota progress with threshold tick */
.go-rotator .quota-row { position: relative; margin-top: 10px; }
.go-rotator .quota-head { display: flex; justify-content: space-between; font-size: 11px; color: var(--dsw-alias-label-secondary, var(--go-rot-fg-2)); }
.go-rotator .quota-bar { position: relative; height: 8px; border-radius: 999px; background: var(--dsw-alias-bg-layer-3, var(--go-rot-bg-3)); margin-top: 4px; overflow: visible; }
.go-rotator .quota-bar > span { display: block; height: 100%; border-radius: 999px; background: var(--dsw-alias-state-success-primary, var(--go-rot-success)); transition: width .5s ease; }
.go-rotator .quota-bar > span.warn { background: var(--go-rot-warn); }
.go-rotator .quota-bar > span.over { background: var(--dsw-alias-state-error-primary, var(--go-rot-error)); }
.go-rotator .quota-bar .thresh { position: absolute; top: -2px; bottom: -2px; width: 2px; border-radius: 2px; background: var(--dsw-alias-label-dimmed, var(--go-rot-fg-3)); }
.go-rotator .win-line { display: flex; flex-wrap: wrap; gap: 4px 16px; font-size: 12px; padding: 3px 0; }
.go-rotator .win-line b { font-variant-numeric: tabular-nums; }
.go-rotator .win-models { font-size: 11px; opacity: .65; padding-left: 2px; display: flex; flex-wrap: wrap; gap: 2px 12px; }
.go-rotator .win-models span { display: inline-flex; align-items: center; gap: 4px; }
.go-rotator .win-models .dot { width: 7px; height: 7px; border-radius: 2px; display: inline-block; }
${CHART_CSS}
${LINE_CSS}
`;

const fmtUsd = (n: number) => `$${n.toFixed(2)}`;
const fmtTok = (n: number) =>
  n >= 1e9 ? `${(n / 1e9).toFixed(2)}B` : n >= 1e6 ? `${(n / 1e6).toFixed(2)}M` : n >= 1e3 ? `${(n / 1e3).toFixed(1)}k` : String(n);

interface UsageRow {
  costUsd: number;
  requests: number;
  inputTokens: number;
  outputTokens: number;
  cachedReadTokens: number;
  byModel: Record<string, { requests: number; costUsd: number; inputTokens: number; outputTokens: number; cachedReadTokens: number }>;
}

function StatTable({ title, rows, names }: { title: string; rows: { period: string; isCurrent: boolean; total: UsageRow; keys: Record<string, UsageRow> }[]; names: string[] }) {
  if (!rows.length) return <div className="muted">暂无数据</div>;
  return (
    <div>
      <div style={{ fontWeight: 700, margin: "12px 0 6px", fontSize: 13 }}>{title}</div>
      <table>
        <thead>
          <tr>
            <th>周期</th>
            {names.map((n) => (
              <th key={n}>{n}</th>
            ))}
            <th>合计</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((r) => (
            <tr key={r.period} className={r.isCurrent ? "active-row" : undefined}>
              <td>
                {r.period}
                {r.isCurrent && <span className="tag ok" style={{ marginLeft: 6 }}>当前</span>}
              </td>
              {names.map((n) => (
                <td key={n}>{r.keys[n] ? `${fmtUsd(r.keys[n].costUsd)} · ${r.keys[n].requests}req` : "—"}</td>
              ))}
              <td>
                {fmtUsd(r.total.costUsd)} · {fmtTok(r.total.inputTokens)}i/{fmtTok(r.total.outputTokens)}o
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function Collapsible({ title, count, extra, defaultOpen, children }: { title: string; count?: string; extra?: React.ReactNode; defaultOpen?: boolean; children: React.ReactNode }) {
  const [open, setOpen] = useState(defaultOpen ?? false);
  return (
    <div className="collapse">
      <div className={`collapse-head${open ? " open" : ""}`} onClick={() => setOpen(!open)}>
        <span className="caret">▶</span>
        <span className="head-title">{title}</span>
        {count !== undefined && <span className="cnt">{count}</span>}
        {extra && <span className="extra" onClick={(e) => e.stopPropagation()}>{extra}</span>}
      </div>
      {open && <div className="collapse-body">{children}</div>}
    </div>
  );
}

const fmtDur = (sec: number) => {
  if (!sec || sec <= 0) return "—";
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  return h > 0 ? `${h}h${m > 0 ? ` ${m}m` : ""}` : `${m}m`;
};

// Local-estimate window (5h/week/month) + scraped real quota for one key.
function KeyWindows({ keyName, usage, scraped, threshold }: { keyName: string; usage?: GoState["usage"][string]; scraped?: GoState["scraped"][string]; threshold: number }) {
  const win = (label: string, w?: { costUsd: number; requests: number; byModel: Record<string, { requests: number; costUsd: number; inputTokens: number; outputTokens: number; cachedReadTokens: number }> }) => {
    if (!w) return <div className="win-line"><span className="muted">{label}：暂无数据</span></div>;
    const models = Object.entries(w.byModel ?? {});
    const winTok = models.reduce((a, [, v]) => a + tokSum(v), 0);
    return (
      <div style={{ marginBottom: 8 }}>
        <div className="win-line">
          <b>{label}</b>
          <span>${w.costUsd.toFixed(2)}</span>
          <span>{w.requests} 次</span>
          <span>{fmtTok(winTok)} tok</span>
        </div>
        {models.length > 0 && (
          <div className="win-models">
            {models.map(([id, v]) => (
              <span key={id}>
                <span className="dot" style={{ background: colorForModel(id) }} />
                {id}: {v.requests}次 / {fmtTok(tokSum(v))}tok / ${v.costUsd.toFixed(4)}
              </span>
            ))}
          </div>
        )}
      </div>
    );
  };

  const quotaWin = (label: string, win?: { usagePercent: number; resetInSec: number }) => {
    if (!win) return <div className="win-line"><span className="muted">{label}：未提供</span></div>;
    const pct = Math.max(0, Math.min(100, win.usagePercent));
    const cls = pct >= threshold ? "over" : pct >= 70 ? "warn" : "";
    const left = Math.max(0, 100 - pct);
    return (
      <div className="quota-row">
        <div className="quota-head">
          <span>{label} · 已用 {pct.toFixed(1)}% · {fmtDur(win.resetInSec)} 后重置</span>
          <span>剩 {left.toFixed(1)}%</span>
        </div>
        <div className="quota-bar">
          <span className={cls} style={{ width: `${pct}%` }} />
          <span className="thresh" style={{ left: `${threshold}%` }} />
        </div>
      </div>
    );
  };

  return (
    <div style={{ padding: "4px 0 2px" }}>
      <div style={{ fontWeight: 700, marginBottom: 6 }}>{keyName}</div>
      <div className="muted" style={{ marginBottom: 2 }}>本地估算（token × 价目表）</div>
      {win("5 小时", usage?.current5h)}
      {win("本周", usage?.currentWeek)}
      {win("本月", usage?.currentMonth)}
      <div className="muted" style={{ margin: "8px 0 2px" }}>
        真实额度（控制台爬取{scraped ? ` · ${new Date(scraped.fetchedAt).toLocaleTimeString()}` : ""}）
      </div>
      {!scraped ? (
        <div className="muted">未配置 Workspace/Cookie 或尚未爬取</div>
      ) : !scraped.ok ? (
        <div style={{ color: "var(--dsw-alias-state-error-primary, var(--go-rot-error))", fontSize: 12 }}>爬取失败: {scraped.error ?? ""}</div>
      ) : (
        <>
          {quotaWin("5 小时", (scraped.quota as { rolling?: { usagePercent: number; resetInSec: number } } | undefined)?.rolling)}
          {quotaWin("本周", (scraped.quota as { weekly?: { usagePercent: number; resetInSec: number } } | undefined)?.weekly)}
          {quotaWin("本月", (scraped.quota as { monthly?: { usagePercent: number; resetInSec: number } } | undefined)?.monthly)}
        </>
      )}
    </div>
  );
}

// Convert API stat rows into chart rows (newest -> oldest in the API is
// reversed here so charts draw oldest -> newest).
function toChartRows(rows: { period: string; isCurrent: boolean; total: UsageRow; keys: Record<string, UsageRow> }[], labelFn: (p: string, isCurrent: boolean) => string, limit = 30): ChartRow[] {
  return rows.slice(0, limit).reverse().map((r) => ({
    label: labelFn(r.period, r.isCurrent),
    total: tokSum(r.total),
    requests: r.total.requests,
    costUsd: r.total.costUsd,
    isCurrent: r.isCurrent,
    models: aggregateModels(r.keys as Record<string, { byModel?: Record<string, { requests: number; costUsd: number; inputTokens: number; outputTokens: number; cachedReadTokens: number; cachedWriteTokens?: number }> }>),
  }));
}

const dailyLabel = (p: string, isCurrent: boolean) => (isCurrent ? "今天" : p.slice(5).replace(/^0/, ""));
const monthLabel = (p: string) => `${p.slice(5).replace(/^0/, "")}月`;
const yearLabel = (p: string) => p;

export function GoRotatorSection() {
  const [state, setState] = useState<GoState | null>(null);
  const [stats, setStats] = useState<StatsResponse | null>(null);
  const [debug, setDebug] = useState<DebugResponse | null>(null);
  const [error, setError] = useState("");
  const [connected, setConnected] = useState<boolean | null>(null);
  const [tab, setTab] = useState<"usage" | "stats" | "settings" | "debug">("usage");
  const [lastUpdate, setLastUpdate] = useState("");
  const [port, setPort] = useState(apiPort());
  const [dailyRange, setDailyRange] = useState(14);
  const [editing, setEditing] = useState<number | null>(null);
  const [form, setForm] = useState({ name: "", key: "", workspaceId: "", authCookie: "" });
  const [settingsForm, setSettingsForm] = useState({ cooldownMinutes: 60, disableThresholdPercent: 97, scrapeIntervalMs: 300000, statsFile: "" });
  const [busy, setBusy] = useState(false);

  const refresh = useCallback(async () => {
    try {
      const [st, stt] = await Promise.all([api.state(), api.stats(30, 12, 6)]);
      setState(st);
      setStats(stt);
      setSettingsForm((f) => ({
        cooldownMinutes: st.cooldownMinutes,
        disableThresholdPercent: st.disableThresholdPercent,
        scrapeIntervalMs: st.scrapeIntervalMs,
        statsFile: f.statsFile || st.statsFile,
      }));
      setConnected(true);
      setError("");
    } catch (e) {
      setConnected(false);
      setError(`无法连接 go-rotator API: ${e instanceof Error ? e.message : String(e)}`);
    }
    setLastUpdate(new Date().toLocaleTimeString());
  }, []);

  const refreshDebug = useCallback(async () => {
    try {
      setDebug(await api.debug());
    } catch {
      // silent — main refresh surfaces connectivity
    }
  }, []);

  useEffect(() => {
    void refresh();
    const t = setInterval(() => void refresh(), 10000);
    return () => clearInterval(t);
  }, [refresh]);

  useEffect(() => {
    if (tab === "debug") void refreshDebug();
  }, [tab, refreshDebug]);

  const names = useMemo(() => (state?.keys ?? []).map((k) => k.name), [state]);

  const applyPort = () => {
    setApiPort(port);
    setConnected(null);
    void refresh();
  };

  const addKey = async () => {
    if (!form.name || !form.key) return;
    setBusy(true);
    try {
      await api.addKey({ ...form, workspaceId: form.workspaceId || undefined, authCookie: form.authCookie || undefined });
      setForm({ name: "", key: "", workspaceId: "", authCookie: "" });
      await refresh();
    } catch (e) {
      setError(String(e));
    }
    setBusy(false);
  };

  const saveEdit = async () => {
    if (editing === null) return;
    setBusy(true);
    try {
      await api.updateKey(editing, { ...form, workspaceId: form.workspaceId || undefined, authCookie: form.authCookie || undefined });
      setEditing(null);
      setForm({ name: "", key: "", workspaceId: "", authCookie: "" });
      await refresh();
    } catch (e) {
      setError(String(e));
    }
    setBusy(false);
  };

  const startEdit = (i: number) => {
    const st = state!;
    setEditing(i);
    setForm({
      name: st.keys[i].name,
      key: "", // masked; empty means "keep"
      workspaceId: "",
      authCookie: "",
    });
  };

  const saveSettings = async () => {
    setBusy(true);
    try {
      await api.updateSettings({
        cooldownMinutes: Number(settingsForm.cooldownMinutes),
        disableThresholdPercent: Number(settingsForm.disableThresholdPercent),
        scrapeIntervalMs: Number(settingsForm.scrapeIntervalMs),
        statsFile: settingsForm.statsFile,
      });
      await refresh();
    } catch (e) {
      setError(String(e));
    }
    setBusy(false);
  };

  const activeName = state?.keys[state.activeKeyIndex]?.name ?? "";
  const activeUsage = state?.usage[activeName];
  const quota = state?.scraped?.[activeName];
  const quotaPct = quota?.ok && quota.quota
    ? Math.max(...Object.values(quota.quota as Record<string, { usagePercent: number }>).map((w) => w.usagePercent))
    : null;
  const quotaOver = quotaPct !== null && quotaPct >= (state?.disableThresholdPercent ?? 97);

  return (
    <div className="go-rotator">
      <style>{STYLE}</style>

      {/* status bar */}
      <div className="statusbar">
        <span className="pill active">{state ? `活跃: ${activeName || "无"}` : "—"}</span>
        <span className="pill">{state ? `${state.keys.length} keys` : "—"}</span>
        <span className={`pill ${connected === false ? "off" : ""}`}>
          {connected === null ? "连接中…" : connected ? `API :${apiPort()}` : "API 离线"}
        </span>
        <span className="muted">更新于 {lastUpdate || "…"}</span>
        <div className="spacer" />
        <div className="actions">
          <button
            className="primary"
            disabled={!state || state.keys.length === 0}
            title={state && state.keys.length <= 1 ? "当前仅一个 key，切换无效果" : "手动切换到下一个可用订阅"}
            onClick={() => void api.rotate().then(() => refresh())}
          >
            切换订阅
          </button>
          <button onClick={() => void refresh()}>立即刷新</button>
          <button onClick={() => void api.scrapeNow().then(() => refresh())}>立即爬取</button>
          <span className="muted" style={{ whiteSpace: "nowrap" }}>API 端口</span>
          <input
            type="number"
            value={port}
            style={{ width: 72 }}
            onChange={(e) => setPort(Number(e.currentTarget.value))}
          />
          <button onClick={applyPort}>应用</button>
        </div>
      </div>
      {error && <div className="err">{error}</div>}

      {/* usage cards */}
      <div className="cards">
        <div className="card">
          <div className="label">5H 输入</div>
          <div className="num">
            {state ? fmtTok(Object.values(activeUsage?.current5h.byModel ?? {}).reduce((a, m) => a + (m.inputTokens ?? 0), 0)) : "—"}
          </div>
          <div className="sub">滚动 5 小时窗口</div>
        </div>
        <div className="card">
          <div className="label">5H 成本</div>
          <div className="num">{state ? fmtUsd(activeUsage?.current5h.costUsd ?? 0) : "—"}</div>
          <div className="sub">上限 ${GO_LIMITS.fiveHour} · 估算</div>
        </div>
        <div className="card">
          <div className="label">本周</div>
          <div className="num">{state ? fmtUsd(activeUsage?.currentWeek.costUsd ?? 0) : "—"}</div>
          <div className="sub">上限 ${GO_LIMITS.weekly} · 估算</div>
        </div>
        <div className="card">
          <div className="label">本月</div>
          <div className="num">{state ? fmtUsd(activeUsage?.currentMonth.costUsd ?? 0) : "—"}</div>
          <div className="sub">上限 ${GO_LIMITS.monthly} · 估算</div>
        </div>
        <div className="card">
          <div className="label">真实配额</div>
          <div className="num">{quotaPct !== null ? `${quotaPct}%` : quota ? "—" : "未爬取"}</div>
          <div className="bar">
            <span className={quotaOver ? "over" : undefined} style={{ width: `${Math.min(quotaPct ?? 0, 100)}%` }} />
          </div>
          <div className="sub">rolling / weekly / monthly 取最高</div>
        </div>
      </div>

      {/* tabs */}
      <div className="tabs">
        {(["usage", "stats", "settings", "debug"] as const).map((t) => (
          <button key={t} className={tab === t ? "on" : ""} onClick={() => setTab(t)}>
            {t === "usage" ? "用量与密钥" : t === "stats" ? "长期统计" : t === "settings" ? "设置" : "调试"}
          </button>
        ))}
      </div>

      {tab === "usage" && (
        <>
          <div className="panel">
            <div className="panel-title">密钥列表</div>
            <table>
              <thead>
                <tr>
                  <th style={{ width: 34 }}>#</th>
                  <th>名称</th>
                  <th>Key</th>
                  <th style={{ width: 130 }}>WS / Cookie</th>
                  <th>状态</th>
                  <th style={{ textAlign: "right" }}>5h / 周 / 月 $</th>
                  <th style={{ width: 190, textAlign: "right" }}>操作</th>
                </tr>
              </thead>
              <tbody>
                {(state?.keys ?? []).map((k, i) => {
                  const cd = state?.cooldowns[k.name];
                  const dis = state?.disabledUntil[k.name];
                  const u = state?.usage[k.name];
                  return (
                    <tr key={i} className={i === state?.activeKeyIndex ? "active-row" : undefined}>
                      <td className="muted">{i}</td>
                      <td style={{ fontWeight: 600 }}>
                        {k.name}
                        {i === state?.activeKeyIndex && <span className="tag ok" style={{ marginLeft: 6 }}>活跃</span>}
                      </td>
                      <td style={{ fontFamily: "ui-monospace, monospace", fontSize: 12 }}>{k.key}</td>
                      <td>
                        {k.hasWorkspace && <span className="tag">WS</span>}
                        {k.hasCookie && <span className="tag">Cookie</span>}
                        {!k.hasWorkspace && !k.hasCookie && <span className="muted">—</span>}
                      </td>
                      <td>
                        {cd ? (
                          <span className="tag warn">冷却至 {new Date(cd).toLocaleTimeString()}</span>
                        ) : dis ? (
                          <span className="tag off">{dis.window} 超限禁用</span>
                        ) : (
                          <span className="tag ok">正常</span>
                        )}
                      </td>
                      <td style={{ textAlign: "right", whiteSpace: "nowrap", fontSize: 11.5 }}>
                        {u ? `${fmtUsd(u.current5h.costUsd)} / ${fmtUsd(u.currentWeek.costUsd)} / ${fmtUsd(u.currentMonth.costUsd)}` : "—"}
                      </td>
                      <td style={{ textAlign: "right", whiteSpace: "nowrap" }}>
                        {i !== state?.activeKeyIndex && (
                          <button className="small" onClick={() => void api.setActive(i).then(() => refresh())}>设活跃</button>
                        )}
                        <button className="small" style={{ marginLeft: 4 }} onClick={() => startEdit(i)}>编辑</button>
                        <button className="small danger" style={{ marginLeft: 4 }} onClick={() => void api.deleteKey(i).then(() => refresh())}>删除</button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>

            {editing !== null ? (
              <div className="grid2" style={{ marginTop: 14, paddingTop: 14, borderTop: `1px solid var(--dsw-alias-border-l, #e2e5ea)` }}>
                <div className="fld">
                  <label>名称</label>
                  <input value={form.name} onChange={(e) => setForm({ ...form, name: e.currentTarget.value })} />
                </div>
                <div className="fld">
                  <label>API Key（留空保持原值）</label>
                  <input value={form.key} placeholder="sk-..." onChange={(e) => setForm({ ...form, key: e.currentTarget.value })} />
                </div>
                <div className="fld">
                  <label>Workspace ID（爬取用量）</label>
                  <input value={form.workspaceId} placeholder="wrk_..." onChange={(e) => setForm({ ...form, workspaceId: e.currentTarget.value })} />
                </div>
                <div className="fld">
                  <label>Auth Cookie</label>
                  <input value={form.authCookie} placeholder="Fe26..." onChange={(e) => setForm({ ...form, authCookie: e.currentTarget.value })} />
                </div>
                <div className="row" style={{ alignItems: "flex-end" }}>
                  <button className="primary" disabled={busy} onClick={() => void saveEdit()}>保存</button>
                  <button onClick={() => setEditing(null)}>取消</button>
                </div>
              </div>
            ) : (
              <div className="grid2" style={{ marginTop: 14, paddingTop: 14, borderTop: `1px solid var(--dsw-alias-border-l, #e2e5ea)` }}>
                <div className="fld">
                  <label>名称</label>
                  <input value={form.name} placeholder="personal" onChange={(e) => setForm({ ...form, name: e.currentTarget.value })} />
                </div>
                <div className="fld">
                  <label>API Key</label>
                  <input value={form.key} placeholder="sk-..." onChange={(e) => setForm({ ...form, key: e.currentTarget.value })} />
                </div>
                <div className="fld">
                  <label>Workspace ID（爬取用量）</label>
                  <input value={form.workspaceId} placeholder="wrk_..." onChange={(e) => setForm({ ...form, workspaceId: e.currentTarget.value })} />
                </div>
                <div className="fld">
                  <label>Auth Cookie</label>
                  <input value={form.authCookie} placeholder="Fe26..." onChange={(e) => setForm({ ...form, authCookie: e.currentTarget.value })} />
                </div>
                <div className="row" style={{ alignItems: "flex-end" }}>
                  <button className="primary" disabled={busy || !form.name || !form.key} onClick={() => void addKey()}>添加密钥</button>
                  <button onClick={() => void api.clearCooldowns().then(() => refresh())}>清除全部冷却</button>
                </div>
              </div>
            )}
          </div>

          <div className="panel">
            <div className="panel-title">5 小时窗口用量（按模型）</div>
            {state && (() => {
              const u = activeUsage?.current5h;
              if (!u || Object.keys(u.byModel).length === 0) return <div className="muted">暂无数据</div>;
              return (
                <table>
                  <thead>
                    <tr>
                      <th>模型</th>
                      <th style={{ textAlign: "right" }}>请求</th>
                      <th style={{ textAlign: "right" }}>成本</th>
                      <th style={{ textAlign: "right" }}>输入</th>
                      <th style={{ textAlign: "right" }}>输出</th>
                      <th style={{ textAlign: "right" }}>缓存读</th>
                    </tr>
                  </thead>
                  <tbody>
                    {Object.entries(u.byModel).map(([m, mu]) => (
                      <tr key={m}>
                        <td style={{ fontWeight: 550 }}>{m}</td>
                        <td style={{ textAlign: "right" }}>{mu.requests}</td>
                        <td style={{ textAlign: "right" }}>{fmtUsd(mu.costUsd)}</td>
                        <td style={{ textAlign: "right" }}>{fmtTok(mu.inputTokens)}</td>
                        <td style={{ textAlign: "right" }}>{fmtTok(mu.outputTokens)}</td>
                        <td style={{ textAlign: "right" }}>{fmtTok(mu.cachedReadTokens)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              );
            })()}
          </div>

          <div className="panel">
            <div className="panel-title">窗口用量与限额</div>
            <div className="muted" style={{ marginBottom: 8 }}>
              订阅硬限：5h ${GO_LIMITS.fiveHour} · 周 ${GO_LIMITS.weekly} · 月 ${GO_LIMITS.monthly}（本地估算仅供对比，真实剩余以爬取为准）
            </div>
            {state && (state.keys.length === 0 ? (
              <div className="muted">尚未添加密钥</div>
            ) : (
              state.keys.map((k, i) => (
                <div key={i} style={{ padding: "10px 0", borderTop: i > 0 ? `1px dashed var(--dsw-alias-border-l, var(--go-rot-border))` : undefined }}>
                  <KeyWindows
                    keyName={k.name}
                    usage={state.usage[k.name]}
                    scraped={state.scraped[k.name]}
                    threshold={state.disableThresholdPercent}
                  />
                </div>
              ))
            ))}
          </div>
        </>
      )}

      {tab === "stats" && stats && (
        <div className="panel">
          <div className="panel-title">长期统计</div>
          <Collapsible
            title="每日"
            count={`近 ${dailyRange} 天`}
            defaultOpen
            extra={
              <span className="range-switch">
                {[7, 14, 30].map((d) => (
                  <button
                    key={d}
                    className={`small${dailyRange === d ? " on" : ""}`}
                    onClick={() => setDailyRange(d)}
                  >
                    {d}天
                  </button>
                ))}
              </span>
            }
          >
            {(() => {
              const dRows = toChartRows(stats.daily, dailyLabel, dailyRange);
              return (
                <>
                  <div className="muted" style={{ margin: "2px 0 6px" }}>
                    近 {dailyRange} 天累计 {fmtTok(dRows.reduce((a, r) => a + r.total, 0))} tok ·{" "}
                    {dRows.reduce((a, r) => a + r.requests, 0)} 次请求 · 悬停查看模型明细
                  </div>
                  <ModelBarChart rows={dRows} />
                  <TrendLine rows={dRows} />
                </>
              );
            })()}
            <StatTable title="" rows={stats.daily} names={names} />
          </Collapsible>
          <Collapsible title="每月" count={`${stats.monthly.length} 个月`}>
            <ModelBarChart rows={toChartRows(stats.monthly, monthLabel, 12)} />
            <TrendLine rows={toChartRows(stats.monthly, monthLabel, 12)} />
            <StatTable title="" rows={stats.monthly} names={names} />
          </Collapsible>
          <Collapsible title="每年" count={`${stats.yearly.length} 年`}>
            <ModelBarChart rows={toChartRows(stats.yearly, yearLabel)} />
            <TrendLine rows={toChartRows(stats.yearly, yearLabel)} />
            <StatTable title="" rows={stats.yearly} names={names} />
          </Collapsible>
          <div className="hint">账本文件: {stats.statsFile}</div>
        </div>
      )}

      {tab === "settings" && (
        <div className="panel">
          <div className="panel-title">轮换器设置</div>
          <div className="grid2">
            <div className="fld">
              <label>冷却分钟数（出错后）</label>
              <input
                type="number"
                value={settingsForm.cooldownMinutes}
                onChange={(e) => setSettingsForm({ ...settingsForm, cooldownMinutes: Number(e.currentTarget.value) })}
              />
            </div>
            <div className="fld">
              <label>配额禁用阈值 %</label>
              <input
                type="number"
                value={settingsForm.disableThresholdPercent}
                onChange={(e) => setSettingsForm({ ...settingsForm, disableThresholdPercent: Number(e.currentTarget.value) })}
              />
            </div>
            <div className="fld">
              <label>爬取间隔 ms（0 关闭）</label>
              <input
                type="number"
                value={settingsForm.scrapeIntervalMs}
                onChange={(e) => setSettingsForm({ ...settingsForm, scrapeIntervalMs: Number(e.currentTarget.value) })}
              />
            </div>
            <div className="fld">
              <label>统计账本文件</label>
              <input
                value={settingsForm.statsFile}
                onChange={(e) => setSettingsForm({ ...settingsForm, statsFile: e.currentTarget.value })}
              />
            </div>
          </div>
          <div className="row" style={{ marginTop: 12 }}>
            <button className="primary" disabled={busy} onClick={() => void saveSettings()}>保存设置</button>
          </div>
        </div>
      )}

      {tab === "debug" && (
        <div className="panel">
          <div className="row" style={{ marginBottom: 10 }}>
            <span className="pill">{debug ? `pid ${debug.env.pid} · uptime ${debug.env.uptimeSec}s` : "—"}</span>
            <span className="pill">{debug ? `${debug.env.keysConfigured} keys` : "—"}</span>
            <div style={{ flex: 1 }} />
            <button onClick={() => void refreshDebug()}>刷新</button>
          </div>
          <div className="log">
            {(debug?.events ?? []).map((e, i) => (
              <div key={i}>
                <span className="t">{new Date(e.ts).toLocaleTimeString()}</span>
                <span className="tag">{e.kind}</span> {e.msg}
              </div>
            ))}
            {!debug && <div className="muted">无事件</div>}
          </div>
        </div>
      )}
    </div>
  );
}
