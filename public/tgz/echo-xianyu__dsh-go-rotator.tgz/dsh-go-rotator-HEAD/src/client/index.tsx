// OpenCode Go rotator — browser half. Registers the settings section that
// hosts the keys/usage/stats/settings/debug GUI. Data flows over the node
// half's HTTP API (cross-origin, CORS-open); no Typert Remote needed.

import type { ClientContext } from "@deepseek-ai/dsh-client-runtime/client";
// Type-only: pulls the shell's SlotMap merge (the 'settings.section' entry).
import type {} from "@deepseek-ai/dsh-client-ui-settings/client";
import { GoRotatorSection } from "./Section.tsx";

/** Required services (cordis fiber inject). */
export const inject = ["slots"];

/** Register the OpenCode Go section in Settings once the slot is declared. */
export function apply(ctx: ClientContext): void {
  ctx.slots.inject("settings.section", () =>
    ctx.slots.register(
      {
        name: "settings.section",
        id: "go-rotator",
        order: 50,
        label: () => "OpenCode Go",
      },
      GoRotatorSection,
    ),
  );
}
