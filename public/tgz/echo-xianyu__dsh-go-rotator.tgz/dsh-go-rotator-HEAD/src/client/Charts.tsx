// SVG charts for the go-rotator settings section: stacked model bar chart and
// cost trend line, ported from the Pi GUI (flat SVG, no chart library), with
// grow-in animations, hover tooltips, and a line-draw animation.

import { useMemo, useState } from "react";

// ---- model colors (ported from the Pi GUI) ----

const MODEL_COLOR_HINTS: Record<string, string> = {
  "glm-5.2": "#84cc16",
  "glm-5.1": "#84cc16",
  "glm-5": "#84cc16",
  "kimi-k2.7-code": "#10b981",
  "kimi-k2.6": "#10b981",
  "kimi-k2.5": "#10b981",
  "mimo-v2.5-pro": "#a855f7",
  "mimo-v2.5": "#a855f7",
  "mimo-v2-pro": "#a855f7",
  "mimo-v2-omni": "#a855f7",
  "minimax-m3": "#f97316",
  "minimax-m2.7": "#f97316",
  "minimax-m2.5": "#f97316",
  "qwen3.7-max": "#ec4899",
  "qwen3.7-plus": "#ec4899",
  "qwen3.6-plus": "#ec4899",
  "qwen3.5-plus": "#ec4899",
  "deepseek-v4-flash": "#60a5fa",
  "deepseek-v4-pro": "#1e40af",
  "deepseek-v4": "#3b82f6",
  "deepseek-r1": "#2563eb",
};
const MODEL_PALETTES: Record<string, string[]> = {
  glm: ["#84cc16", "#4ade80", "#a3e635", "#65a30d"],
  kimi: ["#10b981", "#34d399", "#059669", "#6ee7b7"],
  mimo: ["#a855f7", "#c084fc", "#9333ea", "#d8b4fe"],
  minimax: ["#f97316", "#fb923c", "#ea580c", "#fdba74"],
  qwen: ["#ec4899", "#f472b6", "#db2777", "#f9a8d4"],
  deepseek: ["#3b82f6", "#60a5fa", "#1d4ed8", "#93c5fd"],
};
const FALLBACK_PALETTE = [
  "#6366f1", "#8b5cf6", "#ec4899", "#f43f5e", "#f97316", "#f59e0b", "#84cc16",
  "#10b981", "#06b6d4", "#3b82f6", "#a855f7", "#d946ef", "#14b8a6", "#eab308",
  "#ef4444", "#0ea5e9", "#22c55e", "#facc15", "#64748b", "#94a3b8",
];

function hashOf(s: string): number {
  let h = 0;
  for (const ch of String(s)) h = (h * 31 + ch.charCodeAt(0)) >>> 0;
  return h;
}
function vendorOf(modelId: string): string | null {
  const m = String(modelId || "").toLowerCase();
  for (const v of Object.keys(MODEL_PALETTES)) if (m.startsWith(v)) return v;
  return null;
}
export function colorForModel(modelId: string): string {
  const id = String(modelId || "unknown");
  const c = MODEL_COLOR_HINTS[id];
  if (c) return c;
  const pal = vendorOf(id) ? MODEL_PALETTES[vendorOf(id)!] : FALLBACK_PALETTE;
  return pal[hashOf(id) % pal.length];
}

// ---- data helpers ----

export interface ModelAgg {
  id: string;
  requests: number;
  costUsd: number;
  tok: number;
}
export interface ChartRow {
  label: string;
  total: number; // tokens
  requests: number;
  costUsd: number;
  isCurrent: boolean;
  models: ModelAgg[];
}

export function tokSum(o: { inputTokens?: number; outputTokens?: number; cachedReadTokens?: number; cachedWriteTokens?: number }): number {
  return (o.inputTokens ?? 0) + (o.outputTokens ?? 0) + (o.cachedReadTokens ?? 0) + (o.cachedWriteTokens ?? 0);
}

// Cross-key model aggregation for one period: sorted by tokens desc
// (biggest at the bottom of the stack).
export function aggregateModels(
  keys: Record<string, { byModel?: Record<string, { requests: number; costUsd: number; inputTokens: number; outputTokens: number; cachedReadTokens: number; cachedWriteTokens?: number }> }>,
): ModelAgg[] {
  const agg: Record<string, ModelAgg> = {};
  for (const ks of Object.values(keys ?? {})) {
    for (const [mid, mv] of Object.entries(ks.byModel ?? {})) {
      const a = (agg[mid] ??= { id: mid, requests: 0, costUsd: 0, tok: 0 });
      a.requests += mv.requests || 0;
      a.costUsd += mv.costUsd || 0;
      a.tok += tokSum(mv);
    }
  }
  return Object.values(agg).sort((a, b) => b.tok - a.tok);
}

const fmtTok = (n: number) =>
  n >= 1e9 ? `${(n / 1e9).toFixed(2)}B` : n >= 1e6 ? `${(n / 1e6).toFixed(2)}M` : n >= 1e3 ? `${(n / 1e3).toFixed(1)}k` : String(n);
const fmtUsd = (n: number) => `$${n.toFixed(2)}`;

// ---- bar chart ----

const CH_W = 940;
const CH_H = 212;
const CH_LEFT = 52;
const CH_RIGHT = 8;
const CH_TOP = 14;
const CH_BOTTOM = 30;

function niceMax(v: number): number {
  if (v <= 0) return 1;
  const pow = Math.pow(10, Math.floor(Math.log10(v)));
  for (const m of [1, 2, 5, 10]) {
    if (v <= m * pow) return m * pow;
  }
  return 10 * pow;
}

const CHART_CSS = `
.go-rotator .chart { position: relative; }
.go-rotator .chart svg { display: block; width: 100%; height: auto; }
.go-rotator .chart .legend { display: flex; flex-wrap: wrap; gap: 4px 14px; margin: 6px 0 2px; }
.go-rotator .chart .legend span { display: inline-flex; align-items: center; gap: 5px; font-size: 11px; opacity: .85; }
.go-rotator .chart .legend .dot { width: 8px; height: 8px; border-radius: 2px; display: inline-block; }
.go-rotator .chart .tip {
  position: absolute; z-index: 5; pointer-events: none;
  background: var(--go-rot-tip-bg, #111318);
  color: #fff; border-radius: 8px; padding: 8px 10px;
  font-size: 11px; box-shadow: 0 4px 14px rgba(0,0,0,.35);
  transform: translate(-50%, -100%);
  max-width: 340px;
  opacity: 0; transition: opacity .12s ease;
}
.go-rotator .chart .tip.flip { transform: translate(-50%, 10px); }
.go-rotator .chart .tip.show { opacity: 1; }
.go-rotator .chart .tip .t-title { font-weight: 700; margin-bottom: 2px; }
.go-rotator .chart .tip .t-num { font-weight: 750; font-variant-numeric: tabular-nums; margin-bottom: 3px; }
.go-rotator .chart .tip table td { border: none; padding: 1px 0; font-size: 10.5px; color: #d1d5db; }
.go-rotator .chart .tip table td:last-child { text-align: right; padding-left: 12px; color: #fff; font-variant-numeric: tabular-nums; }
/* bar grow-in */
.go-rotator .chart rect.grow {
  transform-origin: bottom;
  animation: goRotGrow .55s cubic-bezier(.22,.9,.3,1.2) backwards;
}
@keyframes goRotGrow { from { transform: scaleY(0); } to { transform: scaleY(1); } }
.go-rotator .chart rect.seg { transition: filter .12s ease; }
.go-rotator .chart rect.seg.dim { filter: brightness(.55); }
`;

export function ModelBarChart({ rows }: { rows: ChartRow[] }) {
  const [hover, setHover] = useState<number | null>(null);
  const [tipPos, setTipPos] = useState<{ x: number; y: number } | null>(null);

  const plotW = CH_W - CH_LEFT - CH_RIGHT;
  const plotH = CH_H - CH_TOP - CH_BOTTOM;
  const max = niceMax(Math.max(1, ...rows.map((r) => r.total)));
  const n = rows.length || 1;
  const bw = Math.min(44, (plotW / n) * 0.52);
  const step = plotW / n;

  const models = useMemo(() => {
    const agg: Record<string, ModelAgg> = {};
    for (const r of rows) for (const m of r.models) {
      const a = (agg[m.id] ??= { id: m.id, requests: 0, costUsd: 0, tok: 0 });
      a.tok += m.tok;
      a.requests += m.requests;
      a.costUsd += m.costUsd;
    }
    return Object.values(agg).sort((a, b) => b.tok - a.tok);
  }, [rows]);

  if (!rows.length) return <div className="muted" style={{ padding: "20px 0", textAlign: "center" }}>暂无数据</div>;

  const showTip = (i: number, el: SVGRectElement) => {
    setHover(i);
    const box = el.closest(".chart")?.getBoundingClientRect();
    const pos = el.getBoundingClientRect();
    if (box) setTipPos({ x: pos.left - box.left + pos.width / 2, y: pos.top - box.top });
  };

  const hoverRow = hover !== null ? rows[hover] : null;
  // Flip the tooltip below the point when it would overflow the top edge;
  // clamp horizontally so it never leaves the panel on either side.
  const tipFlip = tipPos !== null && tipPos.y < 110;
  const tipLeft = tipPos !== null ? `clamp(70px, ${tipPos.x}px, calc(100% - 70px))` : undefined;
  const tipTop = tipPos !== null ? (tipFlip ? tipPos.y + 8 : tipPos.y) : undefined;

  return (
    <div className="chart">
      <div className="legend">
        {models.map((m) => (
          <span key={m.id}>
            <span className="dot" style={{ background: colorForModel(m.id) }} />
            {m.id}
          </span>
        ))}
      </div>
      <svg viewBox={`0 0 ${CH_W} ${CH_H}`} xmlns="http://www.w3.org/2000/svg" role="img" aria-label="model token bar chart">
        {[0, 0.5, 1].map((f) => {
          const y = CH_TOP + plotH - plotH * f;
          return (
            <g key={f}>
              <line x1={CH_LEFT} y1={y} x2={CH_W - CH_RIGHT} y2={y} stroke="var(--go-rot-grid, #eef0f3)" strokeWidth="1" />
              {f > 0 && (
                <text x={CH_LEFT - 8} y={y + 3.5} textAnchor="end" fontSize="10" fill="var(--go-rot-fg-3, #98a2b3)">
                  {fmtTok(max * f)}
                </text>
              )}
            </g>
          );
        })}
        {rows.map((r, i) => {
          const cx = CH_LEFT + step * i + step / 2;
          const w = bw;
          let yb = CH_TOP + plotH;
          const segs = [];
          if (r.models.length) {
            for (const m of r.models) {
              const h = Math.max(2, (plotH * m.tok) / max);
              yb -= h;
              segs.push(
                <rect
                  key={m.id}
                  className={`seg grow ${hover !== null && hover !== i ? "dim" : ""}`}
                  style={{ fill: colorForModel(m.id), animationDelay: `${i * 40}ms`, cursor: "pointer" }}
                  x={cx - w / 2}
                  y={yb}
                  width={w}
                  height={h}
                />,
              );
            }
          } else {
            segs.push(
              <rect
                key="zero"
                className="seg zero grow"
                style={{ animationDelay: `${i * 40}ms` }}
                x={cx - w / 2}
                y={CH_TOP + plotH - 3}
                width={w}
                height={3}
                fill="var(--go-rot-grid, #e5e7eb)"
              />,
            );
          }
          return (
            <g key={i}>
              {segs}
              <rect
                className="barzone"
                x={cx - w / 2}
                y={CH_TOP}
                width={w}
                height={plotH}
                fill="transparent"
                style={{ cursor: "pointer" }}
                onMouseEnter={(e) => showTip(i, e.currentTarget)}
                onMouseMove={(e) => showTip(i, e.currentTarget)}
                onMouseLeave={() => { setHover(null); setTipPos(null); }}
              />
              <text
                x={cx}
                y={CH_H - 10}
                textAnchor="middle"
                fontSize="10"
                fontWeight={r.isCurrent ? 700 : 400}
                fill={r.isCurrent ? "var(--dsw-alias-brand-primary, var(--go-rot-brand))" : "var(--go-rot-fg-3, #98a2b3)"}
              >
                {r.label}
              </text>
            </g>
          );
        })}
      </svg>
      {hoverRow && tipPos && (
        <div className={`tip show${tipFlip ? " flip" : ""}`} style={{ left: tipLeft, top: tipTop }}>
          <div className="t-title">
            {hoverRow.label}
            {hoverRow.isCurrent && " · 当前"}
          </div>
          <div className="t-num">
            {fmtTok(hoverRow.total)} tok · {hoverRow.requests} 次 · {fmtUsd(hoverRow.costUsd)}
          </div>
          <table>
            {hoverRow.models.map((m) => (
              <tr key={m.id}>
                <td>
                  <span style={{ display: "inline-block", width: 8, height: 8, borderRadius: 2, background: colorForModel(m.id), marginRight: 6 }} />
                  {m.id}
                </td>
                <td>
                  {m.requests} 次 · {fmtTok(m.tok)} tok · {fmtUsd(m.costUsd)}
                </td>
              </tr>
            ))}
          </table>
        </div>
      )}
    </div>
  );
}

// ---- cost trend line ----

const LINE_CSS = `
.go-rotator .trend { position: relative; margin-top: 4px; }
.go-rotator .trend svg { display: block; width: 100%; height: auto; }
.go-rotator .trend .dot-point {
  opacity: 0; transition: opacity .12s ease;
}
.go-rotator .trend:hover .dot-point { opacity: 1; }
.go-rotator .trend path.area { animation: goRotFade .8s ease .25s backwards; }
.go-rotator .trend path.line {
  stroke-dasharray: 1; stroke-dashoffset: 1;
  animation: goRotDraw 1.1s ease .1s forwards;
}
@keyframes goRotDraw { to { stroke-dashoffset: 0; } }
@keyframes goRotFade { from { opacity: 0; } to { opacity: 1; } }
`;

/** Cost trend line with gradient area fill and a draw-in animation. */
export function TrendLine({ rows }: { rows: ChartRow[] }) {
  const [hover, setHover] = useState<number | null>(null);
  const pts = rows.map((r) => r.costUsd);
  const maxV = niceMax(Math.max(1, ...pts));
  const plotW = CH_W - CH_LEFT - CH_RIGHT;
  const plotH = CH_H - CH_TOP - CH_BOTTOM;
  const n = rows.length || 1;
  const step = plotW / n;

  const xy = (i: number) => ({
    x: CH_LEFT + step * i + step / 2,
    y: CH_TOP + plotH - (plotH * pts[i]) / maxV,
  });

  if (!rows.length) return <div className="muted" style={{ padding: "20px 0", textAlign: "center" }}>暂无数据</div>;

  const line = rows.map((_, i) => `${i === 0 ? "M" : "L"}${xy(i).x.toFixed(1)},${xy(i).y.toFixed(1)}`).join(" ");
  const area = `${line} L${xy(n - 1).x.toFixed(1)},${CH_TOP + plotH} L${xy(0).x.toFixed(1)},${CH_TOP + plotH} Z`;

  const onMove = (i: number) => {
    setHover(i);
  };

  const hoverPt = hover !== null ? xy(hover) : null;
  const tipFlip = hoverPt !== null && hoverPt.y < 110;
  const tipLeft = hoverPt !== null ? `clamp(70px, ${hoverPt.x}px, calc(100% - 70px))` : undefined;
  const tipTop = hoverPt !== null ? (tipFlip ? hoverPt.y + 8 : hoverPt.y) : undefined;

  return (
    <div className="trend chart">
      <svg viewBox={`0 0 ${CH_W} ${CH_H}`} xmlns="http://www.w3.org/2000/svg" role="img" aria-label="cost trend line">
        <defs>
          <linearGradient id="goRotArea" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="var(--dsw-alias-brand-primary, var(--go-rot-brand))" stopOpacity="0.35" />
            <stop offset="100%" stopColor="var(--dsw-alias-brand-primary, var(--go-rot-brand))" stopOpacity="0.02" />
          </linearGradient>
        </defs>
        {[0, 0.5, 1].map((f) => {
          const y = CH_TOP + plotH - plotH * f;
          return (
            <g key={f}>
              <line x1={CH_LEFT} y1={y} x2={CH_W - CH_RIGHT} y2={y} stroke="var(--go-rot-grid, #eef0f3)" strokeWidth="1" />
              {f > 0 && (
                <text x={CH_LEFT - 8} y={y + 3.5} textAnchor="end" fontSize="10" fill="var(--go-rot-fg-3, #98a2b3)">
                  ${(maxV * f).toFixed(1)}
                </text>
              )}
            </g>
          );
        })}
        <path d={area} className="area" fill="url(#goRotArea)" />
        <path
          d={line}
          className="line"
          fill="none"
          stroke="var(--dsw-alias-brand-primary, var(--go-rot-brand))"
          strokeWidth="2.5"
          strokeLinecap="round"
          strokeLinejoin="round"
          pathLength={1}
        />
        {rows.map((r, i) => (
          <g key={i}>
            <circle
              className="dot-point"
              cx={xy(i).x}
              cy={xy(i).y}
              r={hover === i ? 4.5 : 3}
              fill={r.isCurrent ? "var(--dsw-alias-brand-primary, var(--go-rot-brand))" : "var(--go-rot-fg-3, #98a2b3)"}
              stroke="var(--dsw-alias-bg-layer-1, #fff)"
              strokeWidth="1.5"
              style={{ transition: "r .1s ease" }}
            />
            <rect
              x={xy(i).x - step / 2}
              y={CH_TOP}
              width={step}
              height={plotH}
              fill="transparent"
              style={{ cursor: "pointer" }}
              onMouseEnter={() => onMove(i)}
              onMouseMove={() => onMove(i)}
              onMouseLeave={() => setHover(null)}
            />
          </g>
        ))}
      </svg>
      {hover !== null && hoverPt && (
        <div className={`tip show${tipFlip ? " flip" : ""}`} style={{ left: tipLeft, top: tipTop }}>
          <div className="t-title">
            {rows[hover].label}
            {rows[hover].isCurrent && " · 当前"}
          </div>
          <div className="t-num">{fmtUsd(rows[hover].costUsd)}</div>
          <table>
            <tr>
              <td>tokens</td>
              <td>{fmtTok(rows[hover].total)}</td>
            </tr>
            <tr>
              <td>requests</td>
              <td>{rows[hover].requests}</td>
            </tr>
          </table>
        </div>
      )}
    </div>
  );
}

export { CHART_CSS, LINE_CSS };
