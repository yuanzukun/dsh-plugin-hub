// Long-term usage ledger for the dsh-go-rotator plugin.
//
// Stored in its own file (State.statsFile, default
// <plugin dir>/data/opencode-go-rotator-stats.json) so the main config file —
// keys, cookies, cooldowns, rotation log — stays small, while the append-only
// stats ledger grows without ever slowing down rotation reads/writes. The
// file may be shared with other tools via a custom statsFile: flush and
// snapshot always re-read the file and merge, so concurrent contexts never
// clobber each other.
//
// Three aggregate levels, each bucketed key-name -> WindowUsage (with a
// per-model breakdown):
//   daily   YYYY-MM-DD (local time)
//   monthly YYYY-MM
//   yearly  YYYY
//
// Consistency model: the FILE is the source of truth; this context keeps only
// a small in-memory PENDING delta since its last flush. Every flush re-reads
// the file and merges the pending delta into it under a write lock, so
// concurrent contexts never overwrite each other's accounting.
//
// Nothing is pruned: each bucket stores one small object per (key, model),
// so even years of history stay tiny.

import { readFile, writeFile, mkdir, chmod, rename } from "node:fs/promises";
import { dirname } from "node:path";
import { resolveDataPath } from "./store.ts";
import type { WindowUsage, ModelUsage } from "./store.ts";

export type StatLevel = "daily" | "monthly" | "yearly";

export interface StatsData {
  daily: Record<string, Record<string, WindowUsage>>;
  monthly: Record<string, Record<string, WindowUsage>>;
  yearly: Record<string, Record<string, WindowUsage>>;
}

export interface TokenCounts {
  inputTokens: number;
  outputTokens: number;
  cachedReadTokens: number;
  cachedWriteTokens?: number;
}

function blankWindow(): WindowUsage {
  return {
    costUsd: 0,
    requests: 0,
    windowStartIso: new Date().toISOString(),
    byModel: {},
  };
}

function blankModelUsage(): ModelUsage {
  return {
    requests: 0,
    costUsd: 0,
    inputTokens: 0,
    outputTokens: 0,
    cachedReadTokens: 0,
    cachedWriteTokens: 0,
  };
}

function emptyData(): StatsData {
  return { daily: {}, monthly: {}, yearly: {} };
}

// Local-time bucket key: "2026-08-05" / "2026-08" / "2026". Zero-padded so
// string ordering == chronological ordering.
export function levelKey(level: StatLevel, ts: number): string {
  const d = new Date(ts);
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  if (level === "yearly") return String(y);
  if (level === "monthly") return `${y}-${m}`;
  return `${y}-${m}-${String(d.getDate()).padStart(2, "0")}`;
}

// Debounce for persisting the pending delta. Short enough that another
// context (or a fresh GUI request) sees recent writes almost immediately.
const FLUSH_IDLE_MS = 2000;

export class StatsStore {
  private pending: StatsData = emptyData();
  private dirty = false;
  private flushTimer: ReturnType<typeof setTimeout> | null = null;
  private writeLock: Promise<void> = Promise.resolve();
  readonly path: string;

  constructor(path: string) {
    this.path = resolveDataPath(path);
  }

  // Warm up / reset. The pending delta starts empty; the file is re-read on
  // every flush and snapshot anyway.
  async load(): Promise<void> {
    this.pending = emptyData();
    this.dirty = false;
    await this.readDisk();
  }

  // Fold a leftover `daily` ledger from an intermediate main-state version
  // (when stats lived inside the config file) into our store. Returns true
  // if anything was imported.
  migrateLegacyDaily(legacy: Record<string, Record<string, WindowUsage>> | null | undefined): boolean {
    if (!legacy || typeof legacy !== "object") return false;
    const days = Object.keys(legacy);
    if (days.length === 0) return false;
    for (const dk of days) {
      const byKey = legacy[dk];
      if (!byKey || typeof byKey !== "object") continue;
      const bucket = (this.pending.daily[dk] ??= {});
      for (const [name, usage] of Object.entries(byKey)) {
        if (!usage || typeof usage !== "object") continue;
        mergeWindow((bucket[name] ??= blankWindow()), usage);
      }
    }
    this.dirty = true;
    this.scheduleFlush(0);
    return true;
  }

  // In-memory pending update across all three levels; persisted by the
  // debounced flush. Safe to call per message — no I/O happens here.
  addUsage(keyName: string, modelId: string, costUsd: number, tokens: TokenCounts): void {
    const now = Date.now();
    for (const level of ["daily", "monthly", "yearly"] as const) {
      const k = levelKey(level, now);
      const bucket = (this.pending[level][k] ??= {});
      const e = (bucket[keyName] ??= blankWindow());
      e.costUsd += costUsd;
      e.requests += 1;
      const m = (e.byModel[modelId] ??= blankModelUsage());
      m.requests += 1;
      m.costUsd += costUsd;
      m.inputTokens += tokens.inputTokens;
      m.outputTokens += tokens.outputTokens;
      m.cachedReadTokens += tokens.cachedReadTokens;
      m.cachedWriteTokens = (m.cachedWriteTokens ?? 0) + (tokens.cachedWriteTokens ?? 0);
    }
    this.dirty = true;
    this.scheduleFlush(FLUSH_IDLE_MS);
  }

  // Fresh view of the ledger: the file (written by ANY context) plus this
  // context's not-yet-flushed delta. Always reads the file, so GUI refreshes
  // see the latest accounting without a restart.
  async snapshot(): Promise<StatsData> {
    const data = await this.readDisk();
    if (this.dirty) mergeInto(data, this.pending);
    return data;
  }

  private async readDisk(): Promise<StatsData> {
    try {
      const raw = await readFile(this.path, "utf8");
      const parsed = JSON.parse(raw) as Partial<StatsData>;
      return {
        daily: parsed.daily ?? {},
        monthly: parsed.monthly ?? {},
        yearly: parsed.yearly ?? {},
      };
    } catch {
      return emptyData(); // fresh file (or unreadable) — start empty
    }
  }

  private scheduleFlush(delayMs: number): void {
    if (this.flushTimer) return;
    this.flushTimer = setTimeout(() => {
      this.flushTimer = null;
      this.flush().catch((e) => {
        console.warn(`[dsh-go-rotator] stats flush failed: ${e instanceof Error ? e.message : String(e)}`);
        if (this.dirty) this.scheduleFlush(FLUSH_IDLE_MS); // retry later
      });
    }, delayMs);
  }

  // Merge the pending delta into the file's current state and persist.
  // The read-merge-write runs under a write lock; because the file is
  // re-read inside the critical section, concurrent contexts can't clobber
  // each other's accounting.
  async flush(): Promise<void> {
    if (!this.dirty) return;
    const prev = this.writeLock;
    this.writeLock = prev.then(async () => {
      if (!this.dirty) return;
      const data = await this.readDisk();
      mergeInto(data, this.pending);
      await mkdir(dirname(this.path), { recursive: true });
      const tmp = `${this.path}.tmp`;
      await writeFile(tmp, JSON.stringify({ version: 1, ...data }, null, 2), "utf8");
      try {
        await chmod(tmp, 0o600);
      } catch {
        // Windows: chmod is a no-op for 0600; ignore.
      }
      await rename(tmp, this.path);
      this.pending = emptyData();
      this.dirty = false;
    });
    await this.writeLock;
  }

  // Stop timers and persist anything pending (call on session shutdown).
  async dispose(): Promise<void> {
    if (this.flushTimer) {
      clearTimeout(this.flushTimer);
      this.flushTimer = null;
    }
    await this.flush();
  }
}

// Add src into target (same levels/buckets/keys/models accumulate).
function mergeInto(target: StatsData, src: StatsData): void {
  for (const level of ["daily", "monthly", "yearly"] as const) {
    const tb = target[level];
    for (const [k, byKey] of Object.entries(src[level])) {
      const tByKey = (tb[k] ??= {});
      for (const [name, usage] of Object.entries(byKey)) {
        if (tByKey[name]) mergeWindow(tByKey[name], usage);
        else tByKey[name] = usage;
      }
    }
  }
}

// Sum a source WindowUsage into a target.
function mergeWindow(target: WindowUsage, src: WindowUsage): void {
  target.costUsd += src.costUsd ?? 0;
  target.requests += src.requests ?? 0;
  for (const [modelId, sm] of Object.entries(src.byModel ?? {})) {
    const tm = (target.byModel[modelId] ??= blankModelUsage());
    tm.requests += sm.requests ?? 0;
    tm.costUsd += sm.costUsd ?? 0;
    tm.inputTokens += sm.inputTokens ?? 0;
    tm.outputTokens += sm.outputTokens ?? 0;
    tm.cachedReadTokens += sm.cachedReadTokens ?? 0;
    tm.cachedWriteTokens = (tm.cachedWriteTokens ?? 0) + (sm.cachedWriteTokens ?? 0);
  }
}
