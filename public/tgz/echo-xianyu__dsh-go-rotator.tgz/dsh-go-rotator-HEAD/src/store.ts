// Atomic JSON state store for the dsh-go-rotator plugin.
//
// Default location: <plugin install dir>/data/opencode-go-rotator.json — the
// plugin never assumes any machine-specific absolute path. The data/ folder is
// created on first write. Always re-reads from disk so writes made by other
// processes are seen immediately.

import { readFile, writeFile, mkdir, chmod, rename } from "node:fs/promises";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { homedir } from "node:os";

export interface KeyEntry {
  name: string;
  key: string;
  workspaceId?: string;
  authCookie?: string;
}

export interface ModelUsage {
  requests: number;
  costUsd: number;
  inputTokens: number;
  outputTokens: number;
  cachedReadTokens: number;
  cachedWriteTokens?: number;
}

export interface WindowUsage {
  costUsd: number;
  requests: number;
  windowStartIso: string;
  byModel: Record<string, ModelUsage>;
}

export interface KeyUsage {
  current5h: WindowUsage;
  currentWeek: WindowUsage;
  currentMonth: WindowUsage;
}

export interface ScrapedWindow {
  usagePercent: number;
  resetInSec: number;
  percentRemaining: number;
  resetTimeIso: string;
}
export interface ScrapedQuota {
  rolling?: ScrapedWindow;
  weekly?: ScrapedWindow;
  monthly?: ScrapedWindow;
}
export interface ScrapedRecord {
  ok: boolean;
  quota?: ScrapedQuota;
  error?: string;
  fetchedAt: string;
}

export interface RotationLogEntry {
  ts: string;
  from: string;
  to: string;
  reason: string;
}

export interface State {
  keys: KeyEntry[];
  activeKeyIndex: number;
  cooldownMinutes: number;
  disableThresholdPercent: number;
  scrapeIntervalMs: number;
  watchdogEnabled: boolean;
  watchdogIdleMs: number;
  guiPort: number;
  // key name -> ISO when cooldown (429/error) expires
  cooldowns: Record<string, string>;
  // key name -> { window, untilIso } threshold-based auto-disable
  disabledUntil: Record<string, { window: string; untilIso: string }>;
  // key name -> estimated token usage
  usage: Record<string, KeyUsage>;
  // key name -> last scraped real quota
  scraped: Record<string, ScrapedRecord>;
  rotationLog: RotationLogEntry[];
  // Long-term usage ledger file (see stats.ts). Kept separate so the
  // append-only stats never bloat this config, which is rewritten on every
  // rotation / usage event. "~/..." is expanded to the home dir.
  statsFile: string;
  // LEGACY: intermediate versions kept a per-day ledger here before stats
  // moved to statsFile. Read once by StatsStore.migrateLegacyDaily, then
  // deleted; never written going forward.
  daily?: Record<string, Record<string, WindowUsage>>;
}

const FIVE_H = 5 * 60 * 60 * 1000;
const WEEK = 7 * 24 * 60 * 60 * 1000;
const MONTH = 30 * 24 * 60 * 60 * 1000;

export const WINDOW_DURATIONS = {
  current5h: FIVE_H,
  currentWeek: WEEK,
  currentMonth: MONTH,
} as const;

/**
 * Plugin install root: the directory that contains package.json. Both default
 * data files live under <root>/data so the plugin is fully self-contained —
 * no machine-specific paths are assumed, and an install can be moved/copied
 * anywhere without breaking its state.
 */
export const PKG_ROOT = fileURLToPath(new URL("..", import.meta.url)).replace(/[\\/]$/, "");
export const DEFAULT_DATA_DIR = join(PKG_ROOT, "data");

/** Default state file: <plugin dir>/data/opencode-go-rotator.json */
export const DEFAULT_STATE_FILE = join(DEFAULT_DATA_DIR, "opencode-go-rotator.json");

/**
 * Default stats ledger path: <plugin dir>/data/opencode-go-rotator-stats.json.
 * A custom path configured inside the state file (statsFile) still wins over
 * this default.
 */
export const DEFAULT_STATS_FILE = join(DEFAULT_DATA_DIR, "opencode-go-rotator-stats.json");

/**
 * Resolve a user-supplied data path to an absolute path, portably:
 *   - "~/x"            -> $HOME/x
 *   - "./x" or "x"     -> <plugin root>/x   (relative to the install dir)
 *   - anything else    -> used as-is (absolute)
 * Used for stateFile/statsFile so configs never need machine-specific paths.
 */
export function resolveDataPath(p: string): string {
  if (!p) return p;
  if (p.startsWith("~/")) return join(homedir(), p.slice(2));
  if (p.startsWith("./") || p.startsWith("../") || !/^[A-Za-z]:[\\/]/.test(p)) {
    return resolve(PKG_ROOT, p);
  }
  return p;
}

export function defaultState(): State {
  const nowIso = new Date().toISOString();
  const blankWindow = (): WindowUsage => ({
    costUsd: 0,
    requests: 0,
    windowStartIso: nowIso,
    byModel: {},
  });
  const blankUsage = (): KeyUsage => ({
    current5h: blankWindow(),
    currentWeek: blankWindow(),
    currentMonth: blankWindow(),
  });
  return {
    keys: [],
    activeKeyIndex: 0,
    cooldownMinutes: 60,
    disableThresholdPercent: 97,
    scrapeIntervalMs: 5 * 60 * 1000,
    watchdogEnabled: false,
    watchdogIdleMs: 5 * 60 * 1000,
    guiPort: 7777,
    cooldowns: {},
    disabledUntil: {},
    usage: {},
    scraped: {},
    rotationLog: [],
    statsFile: DEFAULT_STATS_FILE,
  };
}

function blankModelUsage(): ModelUsage {
  return {
    requests: 0,
    costUsd: 0,
    inputTokens: 0,
    outputTokens: 0,
    cachedReadTokens: 0,
    cachedWriteTokens: 0,
  };
}

function ensureKeyUsage(state: State, name: string): KeyUsage {
  if (!state.usage[name]) {
    const nowIso = new Date().toISOString();
    const w = (): WindowUsage => ({ costUsd: 0, requests: 0, windowStartIso: nowIso, byModel: {} });
    state.usage[name] = { current5h: w(), currentWeek: w(), currentMonth: w() };
  }
  return state.usage[name];
}

// Roll over a window if it has aged past its duration.
function rollIfNeeded(win: WindowUsage, duration: number): WindowUsage {
  const start = Date.parse(win.windowStartIso);
  if (Number.isNaN(start) || Date.now() - start >= duration) {
    return { costUsd: 0, requests: 0, windowStartIso: new Date().toISOString(), byModel: {} };
  }
  return win;
}

function normalize(raw: Partial<State>): State {
  const merged = { ...defaultState(), ...raw };
  for (const k of merged.keys) {
    if (k.name) ensureKeyUsage(merged, k.name);
  }
  merged.rotationLog = merged.rotationLog ?? [];
  merged.statsFile = merged.statsFile || DEFAULT_STATS_FILE;
  return merged;
}

export class Store {
  path: string;
  private cache: State | null = null;
  private writeLock: Promise<void> = Promise.resolve();

  constructor(path?: string) {
    this.path = path ? resolveDataPath(path) : DEFAULT_STATE_FILE;
  }

  async load(): Promise<State> {
    // ALWAYS re-read from disk: another process may hold this file; an
    // in-memory cache would go stale and hide its writes.
    try {
      const raw = await readFile(this.path, "utf8");
      const parsed = JSON.parse(raw) as Partial<State>;
      const merged = normalize(parsed);
      this.cache = merged;
      return merged;
    } catch {
      if (this.cache) return this.cache;
      const s = defaultState();
      this.cache = s;
      return s;
    }
  }

  async save(state: State): Promise<void> {
    const prev = this.writeLock;
    this.writeLock = prev.then(async () => {
      await mkdir(dirname(this.path), { recursive: true });
      const tmp = `${this.path}.tmp`;
      await writeFile(tmp, JSON.stringify(state, null, 2), "utf8");
      try {
        await chmod(tmp, 0o600);
      } catch {
        // Windows: chmod is a no-op for 0600; ignore.
      }
      await rename(tmp, this.path);
    });
    this.cache = state;
    await this.writeLock;
  }

  // Apply a mutation atomically and persist.
  async mutate<T>(fn: (s: State) => T): Promise<T> {
    const s = await this.load();
    const res = fn(s);
    await this.save(s);
    return res;
  }

  // ---- usage accounting ----

  // Add estimated cost + tokens to a key's rolling windows. The long-term
  // per-day/month/year ledger lives in the separate stats file (StatsStore),
  // so this stays a small, fast write.
  async addUsage(
    keyName: string,
    modelId: string,
    costUsd: number,
    tokens: { inputTokens: number; outputTokens: number; cachedReadTokens: number; cachedWriteTokens?: number },
  ): Promise<void> {
    await this.mutate((s) => {
      const u = ensureKeyUsage(s, keyName);
      for (const wkey of ["current5h", "currentWeek", "currentMonth"] as const) {
        const dur = WINDOW_DURATIONS[wkey];
        u[wkey] = rollIfNeeded(u[wkey], dur);
        const win = u[wkey];
        win.costUsd += costUsd;
        win.requests += 1;
        const m = (win.byModel[modelId] ??= blankModelUsage());
        m.requests += 1;
        m.costUsd += costUsd;
        m.inputTokens += tokens.inputTokens;
        m.outputTokens += tokens.outputTokens;
        m.cachedReadTokens += tokens.cachedReadTokens;
        m.cachedWriteTokens = (m.cachedWriteTokens ?? 0) + (tokens.cachedWriteTokens ?? 0);
      }
    });
  }
}
