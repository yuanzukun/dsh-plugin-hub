// Rotation engine: picks the active key, applies cooldowns on 429/quota errors,
// proactively disables keys whose scraped real quota crosses the threshold,
// and records a rotation log. Ported from the Pi opencode-go-rotator extension;
// the state file is shared, so both environments see each other's rotations.

import type { Store, State, KeyEntry } from "./store.ts";

const ALL_WINDOWS = ["rolling", "weekly", "monthly"] as const;
type WindowName = (typeof ALL_WINDOWS)[number];

export interface RotationDecision {
  active: KeyEntry | null;
  activeIndex: number;
  rotated: boolean;
  reason?: string;
}

function isCooldownActive(s: State, name: string): boolean {
  const until = s.cooldowns[name];
  if (!until) return false;
  if (Date.parse(until) <= Date.now()) {
    delete s.cooldowns[name];
    return false;
  }
  return true;
}

function isThresholdDisabled(s: State, name: string): boolean {
  const d = s.disabledUntil[name];
  if (!d) return false;
  if (Date.parse(d.untilIso) <= Date.now()) {
    delete s.disabledUntil[name];
    return false;
  }
  return true;
}

// Pure (non-mutating) variants for read-only checks. Used by resolveActive's
// fast path so we don't write the file on every request.
function cooldownActive(s: State, name: string): boolean {
  const until = s.cooldowns[name];
  return until ? Date.parse(until) > Date.now() : false;
}
function thresholdDisabled(s: State, name: string): boolean {
  const d = s.disabledUntil[name];
  return d ? Date.parse(d.untilIso) > Date.now() : false;
}
function availableKeyIndices(s: State): number[] {
  return s.keys
    .map((_, i) => i)
    .filter((i) => !!s.keys[i].key && !cooldownActive(s, s.keys[i].name) && !thresholdDisabled(s, s.keys[i].name));
}

// Is a key available right now? (exists, not cooled down, not threshold-disabled)
function availableKeys(s: State): number[] {
  return s.keys
    .map((_, i) => i)
    .filter(
      (i) =>
        !!s.keys[i].key &&
        !isCooldownActive(s, s.keys[i].name) &&
        !isThresholdDisabled(s, s.keys[i].name),
    );
}

export class Rotation {
  onActiveChange?: (key: string, name: string) => void;
  store: Store;
  constructor(store: Store, onActiveChange?: (key: string, name: string) => void) {
    this.store = store;
    this.onActiveChange = onActiveChange;
  }

  // Notify the host that the active key changed so it can hot-swap the
  // provider's auth (updates the env ref the llm-pi-ai route resolves per
  // request: process.env[GO_ROTATOR_ACTIVE_KEY]).
  private notify(s: State) {
    const k = s.keys[s.activeKeyIndex];
    if (k?.key && this.onActiveChange) this.onActiveChange(k.key, k.name);
  }

  // Resolve the currently-active key, rotating away if it became unavailable.
  // Fast path is read-only (no file write); only rotates+writes when needed.
  async resolveActive(): Promise<RotationDecision> {
    const s = await this.store.load();
    if (s.keys.length === 0)
      return { active: null, activeIndex: -1, rotated: false };
    const cur = s.keys[s.activeKeyIndex];
    if (cur && !cooldownActive(s, cur.name) && !thresholdDisabled(s, cur.name)) {
      return { active: cur, activeIndex: s.activeKeyIndex, rotated: false };
    }
    // current is blocked -> need to rotate (write path)
    return this.store.mutate((st) => {
      if (st.keys.length === 0)
        return { active: null, activeIndex: -1, rotated: false };
      const cur2 = st.keys[st.activeKeyIndex];
      if (cur2 && !isCooldownActive(st, cur2.name) && !isThresholdDisabled(st, cur2.name)) {
        return { active: cur2, activeIndex: st.activeKeyIndex, rotated: false };
      }
      const avail = availableKeys(st);
      if (avail.length === 0) {
        const next = (st.activeKeyIndex + 1) % st.keys.length;
        const nk = st.keys[next];
        if (nk) {
          delete st.cooldowns[nk.name];
          delete st.disabledUntil[nk.name];
          st.activeKeyIndex = next;
        }
        this.notify(st);
        return { active: nk ?? null, activeIndex: next, rotated: true, reason: "all blocked; force-advance" };
      }
      let chosen = avail.find((i) => i > st.activeKeyIndex);
      if (chosen === undefined) chosen = avail[0];
      const fromName = cur2?.name ?? "(none)";
      st.activeKeyIndex = chosen;
      const toName = st.keys[chosen].name;
      st.rotationLog.unshift({ ts: new Date().toISOString(), from: fromName, to: toName, reason: "active unavailable" });
      keepLogBounded(st);
      this.notify(st);
      return { active: st.keys[chosen], activeIndex: chosen, rotated: true, reason: "active unavailable" };
    });
  }

  // Called when a 429 / rate-limit / quota error is observed for a key.
  async markErrorCooldown(keyName: string, reason: string): Promise<RotationDecision> {
    return this.store.mutate((s) => {
      const until = new Date(Date.now() + s.cooldownMinutes * 60_000).toISOString();
      s.cooldowns[keyName] = until;
      const cur = s.keys[s.activeKeyIndex];
      const fromName = cur?.name ?? "(none)";
      // rotate to next available
      const avail = availableKeys(s);
      if (avail.length > 0) {
        let chosen = avail.find((i) => i > s.activeKeyIndex);
        if (chosen === undefined) chosen = avail[0];
        s.activeKeyIndex = chosen;
      } else if (s.keys.length > 0) {
        const next = (s.activeKeyIndex + 1) % s.keys.length;
        delete s.cooldowns[s.keys[next].name];
        s.activeKeyIndex = next;
      }
      const toName = s.keys[s.activeKeyIndex]?.name ?? "(none)";
      s.rotationLog.unshift({
        ts: new Date().toISOString(),
        from: fromName,
        to: toName,
        reason,
      });
      keepLogBounded(s);
      this.notify(s);
      return {
        active: s.keys[s.activeKeyIndex] ?? null,
        activeIndex: s.activeKeyIndex,
        rotated: toName !== fromName,
        reason,
      };
    });
  }

  // Apply scraped real quota for a key; if any window's usagePercent crosses
  // the threshold, disable that key until the window resets.
  async applyScrapedQuota(
    keyName: string,
    quota: { rolling?: { usagePercent: number; resetInSec: number }; weekly?: { usagePercent: number; resetInSec: number }; monthly?: { usagePercent: number; resetInSec: number } },
  ): Promise<{ disabled: boolean; window?: string; rotated: boolean }> {
    return this.store.mutate((s) => {
      const threshold = s.disableThresholdPercent;
      let disabled = false;
      let disabledWindow: string | undefined;
      for (const w of ALL_WINDOWS) {
        const win = quota[w];
        if (!win) continue;
        if (win.usagePercent >= threshold) {
          const untilIso = new Date(Date.now() + Math.max(win.resetInSec, 60) * 1000).toISOString();
          s.disabledUntil[keyName] = { window: w, untilIso };
          disabled = true;
          disabledWindow = w;
          break; // one disabling window is enough
        }
      }
      if (!disabled) {
        // key healthy — clear any prior disable for it
        delete s.disabledUntil[keyName];
      }
      if (!disabled) return { disabled: false, rotated: false };
      // if the disabled key is currently active, rotate away
      const cur = s.keys[s.activeKeyIndex];
      if (cur && cur.name === keyName) {
        const fromName = cur.name;
        const avail = availableKeys(s);
        if (avail.length > 0) {
          let chosen = avail.find((i) => i > s.activeKeyIndex);
          if (chosen === undefined) chosen = avail[0];
          s.activeKeyIndex = chosen;
        } else if (s.keys.length > 0) {
          const next = (s.activeKeyIndex + 1) % s.keys.length;
          s.activeKeyIndex = next;
        }
        const toName = s.keys[s.activeKeyIndex]?.name ?? "(none)";
        s.rotationLog.unshift({
          ts: new Date().toISOString(),
          from: fromName,
          to: toName,
          reason: `quota ${disabledWindow} >= ${threshold}%`,
        });
        keepLogBounded(s);
        this.notify(s);
        return { disabled: true, window: disabledWindow, rotated: toName !== fromName };
      }
      return { disabled: true, window: disabledWindow, rotated: false };
    });
  }

  // Manual switch (from GUI): set active by index, clearing that key's blocks.
  async setActive(index: number): Promise<void> {
    await this.store.mutate((s) => {
      if (index < 0 || index >= s.keys.length) return;
      const k = s.keys[index];
      delete s.cooldowns[k.name];
      delete s.disabledUntil[k.name];
      s.activeKeyIndex = index;
      this.notify(s);
    });
  }

  // Manual force-switch: advance to the next available key without marking
  // an error ("切换订阅"). Single-key states stay on the same key.
  async forceRotate(reason = "manual"): Promise<RotationDecision> {
    return this.store.mutate((s) => {
      if (s.keys.length === 0) return { active: null, activeIndex: -1, rotated: false, reason };
      const avail = availableKeys(s);
      let chosen: number;
      if (avail.length > 1) {
        chosen = avail.find((i) => i > s.activeKeyIndex) ?? avail[0];
      } else {
        chosen = (s.activeKeyIndex + 1) % s.keys.length;
      }
      const fromName = s.keys[s.activeKeyIndex]?.name ?? "(none)";
      s.activeKeyIndex = chosen;
      const toName = s.keys[chosen]?.name ?? "(none)";
      s.rotationLog.unshift({ ts: new Date().toISOString(), from: fromName, to: toName, reason });
      keepLogBounded(s);
      this.notify(s);
      return { active: s.keys[chosen] ?? null, activeIndex: chosen, rotated: toName !== fromName, reason };
    });
  }

  async clearCooldowns(): Promise<void> {
    await this.store.mutate((s) => {
      s.cooldowns = {};
      s.disabledUntil = {};
    });
  }
}

function keepLogBounded(s: State, max = 200) {
  if (s.rotationLog.length > max) s.rotationLog.length = max;
}
