// OpenCode Go dashboard scraper.
// Logic ported from @kurbezz/opencode-quota (MIT) dist/lib/opencode-go.js —
// same approach: fetch the workspace Go page and parse SolidJS SSR hydration
// output for rollingUsage / weeklyUsage / monthlyUsage windows. Ported from
// the Pi opencode-go-rotator extension; state (workspaceId + authCookie) is
// shared through the common state file.
//
// Each key's Go subscription is tied to a workspace. To scrape a key's real
// remaining quota you need that account's (workspaceId, auth cookie) pair.
// The API key itself is used for the chat endpoint; the (workspaceId,
// authCookie) is used only for dashboard scraping.

const DASHBOARD_URL_PREFIX = "https://opencode.ai/workspace/";
const DASHBOARD_URL_SUFFIX = "/go";
const USER_AGENT =
  "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) Gecko/20100101 Firefox/148.0";
const SCRAPE_TIMEOUT_MS = 10_000;

const NUM = String.raw`(-?\d+(?:\.\d+)?)`;
// SolidJS SSR hydration emits objects like rollingUsage:$R[12]={...usagePercent:42,...resetInSec:3600,...}
// Field order varies, so we try both orderings per window.
const mk = (win: string) => ({
  pctFirst: new RegExp(
    String.raw`${win}:\$R\[\d+\]=\{[^}]*usagePercent:${NUM}[^}]*resetInSec:${NUM}[^}]*\}`,
  ),
  resetFirst: new RegExp(
    String.raw`${win}:\$R\[\d+\]=\{[^}]*resetInSec:${NUM}[^}]*usagePercent:${NUM}[^}]*\}`,
  ),
});

const RE = {
  rolling: mk("rollingUsage"),
  weekly: mk("weeklyUsage"),
  monthly: mk("monthlyUsage"),
};

export interface ScrapedWindow {
  usagePercent: number; // 0-100, percent USED
  resetInSec: number;
  percentRemaining: number;
  resetTimeIso: string;
}

export interface ScrapedQuota {
  rolling?: ScrapedWindow; // 5-hour window
  weekly?: ScrapedWindow;
  monthly?: ScrapedWindow;
}

export interface ScrapeResult {
  ok: boolean;
  quota?: ScrapedQuota;
  error?: string;
  status?: number;
  fetchedAt: string;
}

function parseWindow(
  html: string,
  r: { pctFirst: RegExp; resetFirst: RegExp },
): { usagePercent: number; resetInSec: number } | null {
  const m1 = r.pctFirst.exec(html);
  if (m1) {
    const usagePercent = Number(m1[1]);
    const resetInSec = Number(m1[2]);
    if (Number.isFinite(usagePercent) && Number.isFinite(resetInSec))
      return { usagePercent, resetInSec };
  }
  const m2 = r.resetFirst.exec(html);
  if (m2) {
    const resetInSec = Number(m2[1]);
    const usagePercent = Number(m2[2]);
    if (Number.isFinite(usagePercent) && Number.isFinite(resetInSec))
      return { usagePercent, resetInSec };
  }
  return null;
}

function norm(w: { usagePercent: number; resetInSec: number }, now: number): ScrapedWindow {
  const usagePercent = Math.max(0, w.usagePercent);
  const resetInSec = Math.max(0, w.resetInSec);
  return {
    usagePercent,
    resetInSec,
    percentRemaining: 100 - usagePercent,
    resetTimeIso: new Date(now + resetInSec * 1000).toISOString(),
  };
}

export async function queryGoQuota(
  workspaceId: string,
  authCookie: string,
): Promise<ScrapeResult> {
  const fetchedAt = new Date().toISOString();
  try {
    if (!workspaceId || !authCookie)
      return { ok: false, error: "missing workspaceId or authCookie", fetchedAt };
    const url = `${DASHBOARD_URL_PREFIX}${encodeURIComponent(workspaceId)}${DASHBOARD_URL_SUFFIX}`;
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), SCRAPE_TIMEOUT_MS);
    let res: Response;
    try {
      res = await fetch(url, {
        method: "GET",
        headers: {
          "User-Agent": USER_AGENT,
          Accept: "text/html",
          Cookie: `auth=${authCookie}`,
        },
        signal: ctrl.signal,
        redirect: "manual",
      });
    } finally {
      clearTimeout(timer);
    }
    if (!res.ok)
      return { ok: false, status: res.status, fetchedAt, error: `HTTP ${res.status}` };
    const html = await res.text();
    const rolling = parseWindow(html, RE.rolling);
    const weekly = parseWindow(html, RE.weekly);
    const monthly = parseWindow(html, RE.monthly);
    if (!rolling && !weekly && !monthly)
      return {
        ok: false,
        status: res.status,
        fetchedAt,
        error: "no usage windows parsed (dashboard format changed or cookie expired)",
      };
    const now = Date.now();
    const quota: ScrapedQuota = {};
    if (rolling) quota.rolling = norm(rolling, now);
    if (weekly) quota.weekly = norm(weekly, now);
    if (monthly) quota.monthly = norm(monthly, now);
    return { ok: true, quota, fetchedAt };
  } catch (err) {
    return {
      ok: false,
      fetchedAt,
      error: err instanceof Error ? err.message : String(err),
    };
  }
}
