// HTTP API server for the dsh-go-rotator GUI, ported from the Pi extension's
// gui server (index.ts). Serves the same JSON contract the Pi GUI consumes,
// with CORS for the dsh web UI (different port). No secrets are exposed: keys
// are masked, workspaceId/authCookie are presence flags only.

import { createServer } from "node:http";
import type { Server } from "node:http";
import type { Store, State } from "./store.ts";
import { resolveDataPath } from "./store.ts";
import type { Rotation } from "./rotation.ts";
import type { StatsStore } from "./stats.ts";
import type { WindowUsage, ModelUsage } from "./store.ts";

// ---- debug event ring buffer (in-memory, no secrets) ----

export interface DebugEvent {
  ts: string;
  kind: string;
  msg: string;
}
const debugLog: DebugEvent[] = [];
const DEBUG_MAX = 300;
export function pushDebug(kind: string, msg: string) {
  debugLog.push({ ts: new Date().toISOString(), kind, msg });
  if (debugLog.length > DEBUG_MAX) debugLog.splice(0, debugLog.length - DEBUG_MAX);
}
export function debugEvents(): DebugEvent[] {
  return debugLog.slice(-120);
}

// ---- helpers ----

export function maskKey(k?: string): string {
  if (!k) return "";
  if (k.length <= 10) return "••••";
  return k.slice(0, 6) + "••••" + k.slice(-4);
}

function log(store: Store, msg: string, level: "info" | "warn" | "error" = "info") {
  const prefix = "[go-rotator]";
  if (level === "warn" || level === "error") console.warn(`${prefix} ${msg}`);
  else console.log(`${prefix} ${msg}`);
  pushDebug("log", `${level}: ${msg}`);
}

interface StatRowKeys {
  requests: number;
  costUsd: number;
  inputTokens: number;
  outputTokens: number;
  cachedReadTokens: number;
  cachedWriteTokens: number;
  byModel: Record<string, ModelUsage>;
}

function buildStatRows(
  bucket: Record<string, Record<string, WindowUsage>>,
  names: string[],
  currentKey: string,
  max: number,
): { period: string; isCurrent: boolean; total: StatRowKeys; keys: Record<string, StatRowKeys> }[] {
  // lexicographic == chronological for zero-padded bucket keys
  const periods = Object.keys(bucket).sort();
  const rows: { period: string; isCurrent: boolean; total: StatRowKeys; keys: Record<string, StatRowKeys> }[] = [];
  for (const pk of periods.slice(-max)) {
    const byKey = bucket[pk] ?? {};
    const keys: Record<string, StatRowKeys> = {};
    const total: StatRowKeys = { requests: 0, costUsd: 0, inputTokens: 0, outputTokens: 0, cachedReadTokens: 0, cachedWriteTokens: 0, byModel: {} };
    for (const name of names) {
      const e = byKey[name];
      if (!e) continue;
      const ks: StatRowKeys = {
        requests: e.requests,
        costUsd: e.costUsd,
        inputTokens: 0,
        outputTokens: 0,
        cachedReadTokens: 0,
        cachedWriteTokens: 0,
        byModel: e.byModel ?? {},
      };
      for (const m of Object.values(ks.byModel)) {
        ks.inputTokens += m.inputTokens ?? 0;
        ks.outputTokens += m.outputTokens ?? 0;
        ks.cachedReadTokens += m.cachedReadTokens ?? 0;
        ks.cachedWriteTokens += m.cachedWriteTokens ?? 0;
      }
      keys[name] = ks;
      total.requests += ks.requests;
      total.costUsd += ks.costUsd;
      total.inputTokens += ks.inputTokens;
      total.outputTokens += ks.outputTokens;
      total.cachedReadTokens += ks.cachedReadTokens;
      total.cachedWriteTokens += ks.cachedWriteTokens;
    }
    rows.push({ period: pk, isCurrent: pk === currentKey, total, keys });
  }
  return rows.reverse(); // newest first
}

function resolveStatsPath(p: string): string {
  return resolveDataPath(p);
}

export interface GoRotatorHttpOptions {
  store: Store;
  rotation: Rotation;
  stats: () => StatsStore | undefined;
  /** Base port; falls back to the next ports when busy. */
  basePort: number;
  /** Manual scrape trigger (fire-and-forget). */
  scrapeNow: () => void;
  /** Called after a key edit that may change the active key. */
  onKeyEdited: (key: string, name: string) => void;
}

export interface GoRotatorHttpServer {
  port: number;
  stop: () => Promise<void>;
}

/** Start the GUI/API HTTP server with port fallback. Returns the bound port. */
export async function startGoRotatorHttp(opts: GoRotatorHttpOptions): Promise<GoRotatorHttpServer> {
  const { store, rotation, stats, basePort, scrapeNow, onKeyEdited } = opts;

  const handler = async (req: Request): Promise<Response> => {
    const url = new URL(req.url);
    const p = url.pathname;
    const method = req.method;

    const json = (obj: unknown, status = 200) =>
      new Response(JSON.stringify(obj), {
        status,
        headers: { "content-type": "application/json", "access-control-allow-origin": "*" },
      });
    if (method === "OPTIONS")
      return new Response(null, { status: 204, headers: { "access-control-allow-origin": "*", "access-control-allow-methods": "GET,POST,DELETE,OPTIONS", "access-control-allow-headers": "content-type" } });

    if (p === "/health" && method === "GET") return json({ ok: true });

    if (p === "/api/state" && method === "GET") {
      const st = await store.load();
      const safe = {
        ...st,
        keys: st.keys.map((k) => ({
          name: k.name,
          key: maskKey(k.key),
          hasWorkspace: !!k.workspaceId,
          hasCookie: !!k.authCookie,
        })),
      };
      return json(safe);
    }

    if (p === "/api/keys" && method === "POST") {
      const body = (await req.json()) as Record<string, any>;
      if (!body?.name || !body?.key) return json({ error: "name and key required" }, 400);
      await store.mutate((st) => {
        st.keys.push({
          name: String(body.name),
          key: String(body.key),
          workspaceId: body.workspaceId ? String(body.workspaceId) : undefined,
          authCookie: body.authCookie ? String(body.authCookie) : undefined,
        });
      });
      pushDebug("keys", `added key "${body.name}" (${maskKey(String(body.key))})`);
      return json({ ok: true });
    }

    const upd = p.match(/^\/api\/keys\/(\d+)$/);
    if (upd && method === "GET") {
      const st = await store.load();
      const i = Number(upd[1]);
      if (i < 0 || i >= st.keys.length) return json({ error: "not found" }, 404);
      return json(st.keys[i]);
    }

    if (upd && method === "POST") {
      const i = Number(upd[1]);
      const body = (await req.json()) as Record<string, any>;
      let keyChanged = false;
      let changedName = "";
      let changedKey = "";
      await store.mutate((st) => {
        if (i < 0 || i >= st.keys.length) return;
        const k = st.keys[i];
        if (body.name !== undefined) k.name = String(body.name);
        if (body.key !== undefined && body.key !== maskKey(k.key)) {
          k.key = String(body.key);
          keyChanged = true;
        }
        if (body.workspaceId !== undefined) k.workspaceId = body.workspaceId ? String(body.workspaceId) : undefined;
        if (body.authCookie !== undefined) k.authCookie = body.authCookie ? String(body.authCookie) : undefined;
        changedName = k.name;
        changedKey = k.key;
      });
      const st = await store.load();
      if (i === st.activeKeyIndex && st.keys[i]?.key) {
        onKeyEdited(st.keys[i].key, st.keys[i].name);
      }
      pushDebug("keys", `updated key #${i} "${changedName}"${keyChanged ? " (key changed)" : ""}`);
      scrapeNow();
      return json({ ok: true });
    }

    if (upd && method === "DELETE") {
      const i = Number(upd[1]);
      await store.mutate((st) => {
        if (i < 0 || i >= st.keys.length) return;
        const removed = st.keys.splice(i, 1)[0];
        if (removed) {
          delete st.cooldowns[removed.name];
          delete st.disabledUntil[removed.name];
          delete st.usage[removed.name];
          delete st.scraped[removed.name];
          pushDebug("keys", `removed key "${removed.name}"`);
        }
        if (st.activeKeyIndex >= st.keys.length) st.activeKeyIndex = Math.max(0, st.keys.length - 1);
      });
      return json({ ok: true });
    }

    const act = p.match(/^\/api\/active\/(\d+)$/);
    if (act && method === "POST") {
      await rotation.setActive(Number(act[1]));
      pushDebug("keys", `manual switch to key #${act[1]}`);
      return json({ ok: true });
    }

    if (p === "/api/rotate" && method === "POST") {
      const d = await rotation.forceRotate("manual");
      pushDebug("keys", `manual rotate: ${d.active?.name ?? "none"}${d.rotated ? " (switched)" : " (no change)"}`);
      return json({ ok: true, rotated: d.rotated, active: d.active?.name ?? null });
    }

    if (p === "/api/clear-cooldowns" && method === "POST") {
      await rotation.clearCooldowns();
      pushDebug("keys", "cooldowns cleared");
      return json({ ok: true });
    }

    // Long-term stats (daily/monthly/yearly ledger from the stats file).
    if (p === "/api/stats" && method === "GET") {
      const days = Math.min(90, Math.max(1, parseInt(url.searchParams.get("days") ?? "", 10) || 30));
      const months = Math.min(60, Math.max(1, parseInt(url.searchParams.get("months") ?? "", 10) || 12));
      const years = Math.min(20, Math.max(1, parseInt(url.searchParams.get("years") ?? "", 10) || 6));
      const st = await store.load();
      const names = st.keys.map((k) => k.name);
      const snap = (stats() ? await stats()!.snapshot() : { daily: {}, monthly: {}, yearly: {} }) as {
        daily: Record<string, Record<string, WindowUsage>>;
        monthly: Record<string, Record<string, WindowUsage>>;
        yearly: Record<string, Record<string, WindowUsage>>;
      };
      const now = Date.now();
      return json({
        days,
        months,
        years,
        statsFile: stats()?.path ?? "",
        daily: buildStatRows(snap.daily, names, levelKeyOf(now, "day"), days),
        monthly: buildStatRows(snap.monthly, names, levelKeyOf(now, "month"), months),
        yearly: buildStatRows(snap.yearly, names, levelKeyOf(now, "year"), years),
      });
    }

    // Debug: recent internal events + environment status (no secrets).
    if (p === "/api/debug" && method === "GET") {
      const st = await store.load();
      const snap = stats() ? await stats()!.snapshot() : null;
      return json({
        events: debugEvents(),
        env: {
          pid: process.pid,
          uptimeSec: Math.round(process.uptime()),
          keysConfigured: st.keys.length,
        },
        stats: {
          file: stats()?.path ?? "",
          dailyBuckets: Object.keys(snap?.daily ?? {}).length,
          monthlyBuckets: Object.keys(snap?.monthly ?? {}).length,
          yearlyBuckets: Object.keys(snap?.yearly ?? {}).length,
        },
      });
    }

    if (p === "/api/settings" && method === "POST") {
      const body = (await req.json()) as Record<string, any>;
      let statsFileChanged = false;
      await store.mutate((st) => {
        if (body.cooldownMinutes != null) st.cooldownMinutes = Number(body.cooldownMinutes);
        if (body.disableThresholdPercent != null) st.disableThresholdPercent = Number(body.disableThresholdPercent);
        if (body.scrapeIntervalMs != null) st.scrapeIntervalMs = Number(body.scrapeIntervalMs);
        if (body.watchdogIdleMs != null) st.watchdogIdleMs = Number(body.watchdogIdleMs);
        if (body.watchdogEnabled != null) st.watchdogEnabled = !!body.watchdogEnabled;
        if (body.guiPort != null) st.guiPort = Number(body.guiPort);
        if (typeof body.statsFile === "string" && body.statsFile.trim()) {
          const np = resolveStatsPath(body.statsFile.trim());
          if (np !== st.statsFile) {
            st.statsFile = np;
            statsFileChanged = true;
          }
        }
      });
      // switch the ledger to the new file (old file is left untouched)
      if (statsFileChanged && stats()) {
        await stats()!.dispose();
        // rebuild lazily: the plugin owns the StatsStore instance; signal via
        // a marker by re-reading the new path through the option hook.
        const newPath = (await store.load()).statsFile;
        onStatsFileChanged(newPath);
      }
      pushDebug("settings", "settings updated");
      return json({ ok: true });
    }

    if (p === "/api/scrape/now" && method === "POST") {
      scrapeNow();
      pushDebug("scrape", "manual scrape requested");
      return json({ ok: true, started: true });
    }

    return json({ error: "not found" }, 404);
  };

  // node fallback (minimal) with port-retry so pi's GUI and dsh can coexist.
  let bound: Server | null = null;
  for (let port = basePort; port <= basePort + 5 && !bound; port++) {
    try {
      bound = await new Promise<Server>((res, rej) => {
        const server = createServer(async (req, res) => {
          try {
            const buf = await new Promise<string>((resolveBody) => {
              let d = "";
              req.on("data", (c) => (d += c));
              req.on("end", () => resolveBody(d));
            });
            const init: RequestInit = { method: req.method || "GET", headers: req.headers as any };
            if (req.method !== "GET" && req.method !== "DELETE" && buf) init.body = buf;
            const r = await handler(new Request(`http://localhost:${port}${req.url}`, init));
            const outHeaders: Record<string, string> = {};
            r.headers.forEach((v, k) => {
              outHeaders[k] = v;
            });
            res.writeHead(r.status, outHeaders);
            res.end(r.body ? await r.text() : "");
          } catch (e) {
            res.writeHead(500);
            res.end(String(e));
          }
        });
        server.once("error", (err: any) => rej(err));
        server.listen(port, () => res(server));
      });
      const server = bound;
      log(store, `GUI API on http://localhost:${port}${port !== basePort ? ` (port ${basePort} busy, fell back)` : ""}`);
    } catch (e: any) {
      if (e?.code !== "EADDRINUSE") throw e;
    }
  }
  if (!bound) {
    throw new Error(`go-rotator HTTP server failed: ports ${basePort}-${basePort + 5} in use`);
  }
  return {
    port: (bound.address() as any)?.port ?? basePort,
    stop: async () => {
      await new Promise<void>((res) => bound?.close(() => res()));
    },
  };
}

function levelKeyOf(ts: number, level: "day" | "month" | "year"): string {
  const d = new Date(ts);
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  if (level === "year") return String(y);
  if (level === "month") return `${y}-${m}`;
  return `${y}-${m}-${String(d.getDate()).padStart(2, "0")}`;
}

/** Set by the plugin to rebuild the StatsStore after its path changes. */
let onStatsFileChanged: (newPath: string) => void = () => {};
export function setStatsFileChangedHook(fn: (newPath: string) => void) {
  onStatsFileChanged = fn;
}
