// dsh-go-rotator: OpenCode Go subscription key rotator for DeepSeek Harness.
//
// Adaptation of the Pi extension `opencode-go-rotator` to the dsh (Cordis 4)
// plugin seam:
//
// - Routing: the llm-pi-ai adapter declares the `opencode-go` provider route
//   in $DSH_HOME/settings.yaml with `apiKeyEnv: GO_ROTATOR_ACTIVE_KEY`; that
//   reference resolves PER REQUEST through the credentials seam, so updating
//   process.env rotates the active key with no reload.
// - Rotation: this plugin wraps the `llm/stream` waterfall. When a stream
//   fails with one of `rotateOnCodes` (RATE_LIMIT / QUOTA_EXCEEDED / AUTH /
//   INVALID_CREDENTIAL), it cools the active key down in the shared state file
//   and rotates to the next available key. The failure is re-thrown as-is, so
//   the built-in llm-retry executor re-issues the request and automatically
//   picks up the fresh key.
// - Accounting: completed streams (terminal usage chunk + non-error finish)
//   are charged to the key that was active when the stream started, using the
//   local price table for cost estimation. Both the rolling-window usage in
//   the shared state file and the long-term daily/monthly/yearly ledger are
//   updated — the ledger file is shared with the Pi extension.
// - Quota scraping: periodically fetches each key's real dashboard quota
//   (workspaceId + authCookie from the shared state) and disables a key whose
//   usage crosses the configured threshold.
//
// State defaults to <plugin dir>/data/opencode-go-rotator.json (no
// machine-specific paths, no legacy probing). No GUI ships yet; the
// Pi extension's GUI (localhost:7777) can read/write the same file when
// pointed at it.

import type { Context } from "@deepseek-ai/cordis";
import z from "@deepseek-ai/schemastery";
import type { GenerateOptions, StreamChunk } from "@deepseek-ai/dsh-llm";
import { Store, DEFAULT_STATE_FILE, DEFAULT_STATS_FILE } from "./store.ts";
import { Rotation } from "./rotation.ts";
import { StatsStore } from "./stats.ts";
import { estimateCostUsd } from "./pricetable.ts";
import { queryGoQuota } from "./scraper.ts";
import { pushDebug, startGoRotatorHttp, setStatsFileChangedHook } from "./http.ts";

export const name = "dsh-go-rotator";

/** Require the credentials service so ctx.get("credentials") is live in apply. */
export const inject = ["credentials"];

export interface GoRotatorConfig {
  /** Shared state file (default: the Pi extension's file). */
  stateFile?: string;
  /** Long-term ledger file (default: the shared Pi ledger). */
  statsFile?: string;
  /** Env var the llm-pi-ai provider route resolves per request. */
  apiKeyEnv?: string;
  /** Cooldown minutes applied to a key after an error. */
  cooldownMinutes?: number;
  /** Disable a key once a scraped quota window crosses this percent. */
  disableThresholdPercent?: number;
  /** LlmError codes that trigger cooldown + rotation. */
  rotateOnCodes?: string[];
  /** Min interval between two rotations (concurrent failure debounce). */
  rotateDebounceMs?: number;
  /** Dashboard quota scrape interval; 0 disables scraping. */
  scrapeIntervalMs?: number;
  /** GUI/API HTTP server port (falls back to next ports when busy); 0 disables the server. */
  guiPort?: number;
}

export const Config = z.object({
  stateFile: z.string(),
  statsFile: z.string(),
  apiKeyEnv: z.string().default("GO_ROTATOR_ACTIVE_KEY"),
  cooldownMinutes: z.number().default(60),
  disableThresholdPercent: z.number().default(97),
  rotateOnCodes: z
    .array(z.string())
    .default(["RATE_LIMIT", "QUOTA_EXCEEDED", "AUTH", "INVALID_CREDENTIAL"]),
  rotateDebounceMs: z.number().default(3000),
  scrapeIntervalMs: z.number().default(300000),
  guiPort: z.number().default(7777),
});

export function apply(ctx: Context, config: GoRotatorConfig) {
  const store = new Store(config.stateFile ?? DEFAULT_STATE_FILE);
  const envName = config.apiKeyEnv ?? "GO_ROTATOR_ACTIVE_KEY";

  // Push the active key into every per-request resolution path:
  // 1) process.env — read live by some consumers;
  // 2) the credentials managed store (~/.dsh/.credentials.yaml) — required
  //    because llm-pi-ai resolves apiKeyEnv through the credentials service,
  //    whose inherited layer is the LAUNCH-TIME environment snapshot (a
  //    process.env write after boot is invisible to it). A user-exported env
  //    shadows the store write (credentials-local refuses it) — that is fine,
  //    the exported value wins and stays consistent with rotation here.
  const syncActiveKey = async (key: string | undefined) => {
    if (key) {
      process.env[envName] = key;
    } else {
      delete process.env[envName];
    }
    const credentials = ctx.get("credentials") as
      | { set?: (ref: string, value: string) => Promise<void>; unset?: (ref: string) => Promise<void> }
      | undefined;
    if (!credentials?.set) return;
    try {
      if (key) await credentials.set(envName, key);
      else await credentials.unset?.(envName);
    } catch (err) {
      // env shadows the store (user exported it) — the env value wins anyway.
      ctx.logger.debug(`[go-rotator] credentials store sync skipped: ${String(err)}`);
    }
  };

  const rotation = new Rotation(store, (key) => {
    // Called whenever the active key changes. Fire-and-forget; never block
    // the rotation hook on the store write.
    void syncActiveKey(key);
  });

  // Long-term ledger; path falls back to the shared state's statsFile so a
  // custom ledger location carries over. resolveDataPath inside StatsStore
  // handles ~/ and plugin-relative paths.
  let stats: StatsStore;
  const statsFor = (s: { statsFile?: string }) =>
    new StatsStore(config.statsFile ?? s.statsFile ?? DEFAULT_STATS_FILE);

  let lastRotateTs = 0;
  const maybeRotate = (keyName: string, reason: string) => {
    const now = Date.now();
    const debounce = config.rotateDebounceMs ?? 3000;
    if (now - lastRotateTs < debounce) return;
    lastRotateTs = now;
    rotation.markErrorCooldown(keyName, reason).then(
      (d) => {
        if (d.rotated) {
          ctx.logger.warn(
            `[go-rotator] rotated "${d.active?.name ?? "none"}" after ${reason} (was "${keyName}")`,
          );
          pushDebug("rotation", `rotated "${keyName}" → "${d.active?.name ?? "none"}" after ${reason}`);
        }
      },
      (err) => {
        ctx.logger.error(`[go-rotator] rotation failed: ${String(err)}`);
        pushDebug("rotation", `rotation failed: ${String(err)}`);
      },
    );
  };

  // Wrap one llm/stream: snapshot the active key at stream start, collect the
  // usage chunk, rotate on error finishes, and account completed streams to
  // the snapshot key. Failures pass through untouched (llm-retry re-issues).
  const wrapStream = (
    options: GenerateOptions,
    upstream: () => AsyncIterable<StreamChunk>,
  ): AsyncIterable<StreamChunk> =>
    (async function* () {
      const state = await store.load();
      const keyName = state.keys[state.activeKeyIndex]?.name ?? null;
      let usage: NonNullable<StreamChunk & { type: "usage" }>["usage"] | undefined;
      let failed = false;
      try {
        for await (const chunk of upstream()) {
          if (chunk.type === "usage") usage = chunk.usage;
          if (chunk.type === "finish") {
            if (chunk.reason.kind === "error") {
              failed = true;
              const code = chunk.reason.failure.code;
              if (keyName && (config.rotateOnCodes ?? []).includes(code)) {
                maybeRotate(keyName, `llm error ${code}`);
              }
            } else if (chunk.reason.kind === "aborted") {
              failed = true;
            }
          }
          yield chunk;
        }
      } finally {
        if (!failed && usage && keyName) {
          const costUsd = estimateCostUsd(options.model, usage);
          if (costUsd > 0 || usage.inputTokens > 0 || usage.outputTokens > 0) {
            const counts = {
              inputTokens: usage.inputTokens,
              outputTokens: usage.outputTokens,
              cachedReadTokens: usage.cacheReadTokens ?? 0,
              cachedWriteTokens: usage.cacheWriteTokens,
            };
            void store.addUsage(keyName, options.model, costUsd, counts);
            stats.addUsage(keyName, options.model, costUsd, counts);
            pushDebug(
              "accounting",
              `+$${costUsd.toFixed(5)} ${options.model} → "${keyName}" (${usage.inputTokens}+${usage.outputTokens} tok)`,
            );
          }
        }
      }
    })();

  ctx.effect(() => {
    let disposed = false;
    stats = statsFor({});

    // Startup: sync the shared state's active key into env + credentials store
    // so requests pick it up even when the shell did not export the ref.
    void store.load().then(async (s) => {
      if (disposed) return;
      const k = s.keys[s.activeKeyIndex];
      await syncActiveKey(k?.key);
      if (k?.key) {
        pushDebug("auth", `active key synced → "${k.name}"`);
      } else {
        ctx.logger.warn("[go-rotator] no OpenCode Go key in shared state");
        pushDebug("auth", "no OpenCode Go key in shared state");
      }
      stats = statsFor(s);
      void stats.load();
    });

    const disposeStream = ctx.on(
      "llm/stream",
      (options: GenerateOptions, next: () => AsyncIterable<StreamChunk>) =>
        wrapStream(options, next),
    );

    // Periodic dashboard quota scraping (disabled at interval 0).
    let timer: ReturnType<typeof setInterval> | null = null;
    if ((config.scrapeIntervalMs ?? 0) > 0) {
      timer = setInterval(() => {
        void scrapeQuotas(ctx, store, rotation, config.disableThresholdPercent);
      }, config.scrapeIntervalMs);
    }

    // GUI/API HTTP server (disabled at port 0). Serves the same JSON contract
    // the Pi GUI consumed; the dsh web client half fetches it cross-origin.
    let httpServer: { port: number; stop: () => Promise<void> } | null = null;
    const guiPort = config.guiPort ?? 7777;
    if (guiPort > 0) {
      void startGoRotatorHttp({
        store,
        rotation,
        stats: () => stats,
        basePort: guiPort,
        scrapeNow: () => {
          void scrapeQuotas(ctx, store, rotation, config.disableThresholdPercent);
        },
        onKeyEdited: (key, name) => {
          void syncActiveKey(key);
          pushDebug("keys", `active key refreshed → "${name}"`);
        },
      })
        .then((srv) => {
          if (disposed) {
            void srv.stop();
            return;
          }
          httpServer = srv;
          ctx.logger.info(`[go-rotator] GUI API on http://localhost:${srv.port}`);
        })
        .catch((err) => {
          ctx.logger.error(`[go-rotator] HTTP server failed: ${String(err)}`);
        });
      setStatsFileChangedHook((newPath) => {
        void stats.dispose().then(() => {
          stats = new StatsStore(newPath);
          void stats.load();
        });
      });
    }

    return () => {
      disposed = true;
      disposeStream();
      if (timer) clearInterval(timer);
      void httpServer?.stop();
      void stats.dispose();
    };
  });
}

// Fetch every key's real dashboard quota and disable keys over the threshold.
async function scrapeQuotas(
  ctx: Context,
  store: Store,
  rotation: Rotation,
  threshold: number | undefined,
): Promise<void> {
  const s = await store.load();
  for (const k of s.keys) {
    if (!k.workspaceId || !k.authCookie) continue;
    const res = await queryGoQuota(k.workspaceId, k.authCookie);
    await store.mutate((st) => {
      st.scraped[k.name] = res;
    });
    if (!res.ok || !res.quota) {
      if (!res.ok) ctx.logger.warn(`[go-rotator] quota scrape failed for "${k.name}": ${res.error}`);
      continue;
    }
    const r = await rotation.applyScrapedQuota(k.name, res.quota);
    if (r.disabled) {
      ctx.logger.warn(
        `[go-rotator] "${k.name}" disabled by quota (${r.window} >= ${threshold ?? 97}%), rotated=${r.rotated}`,
      );
    }
  }
}
