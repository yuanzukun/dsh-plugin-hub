import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'
import { setImmediate } from 'node:timers/promises'
import { test } from 'node:test'

import { createMemoryViews } from '../lib/memory-panel.js'

const MODULE = new URL('../lib/memory-panel.js', import.meta.url)

// The suite has no React dependency: the views are real, the hook runtime is a
// four-hook stand-in that preserves state across renders and runs effect
// cleanup the way the host's mount does. Fetch is the browser boundary.
function mount(t, name, options = {}) {
  const values = []
  const effects = []
  let cursor = 0
  let pending = []
  const React = {
    createElement: (type, props, ...children) => ({ type, props: { ...props, children } }),
    useState(initial) {
      const index = cursor++
      if (!(index in values)) values[index] = initial
      return [
        values[index],
        (next) => {
          values[index] = typeof next === 'function' ? next(values[index]) : next
        },
      ]
    },
    useRef(initial) {
      const index = cursor++
      if (!(index in values)) values[index] = { current: initial }
      return values[index]
    },
    useEffect(run, deps) {
      const index = cursor++
      const previous = effects[index]
      if (
        previous?.deps &&
        previous.deps.length === deps.length &&
        previous.deps.every((value, i) => Object.is(value, deps[i]))
      )
        return
      pending.push(() => {
        previous?.cleanup?.()
        effects[index] = { deps, cleanup: run() }
      })
    },
  }
  const View = createMemoryViews({ React, ...options })[name]
  t.after(() => effects.forEach((effect) => effect?.cleanup?.()))
  const focused = []
  // React attaches a DOM node to an object ref after mounting. This stand-in
  // attaches a focus stub to the same ref object so a test can prove the view
  // moved focus (the host has no DOM here). Refs are attached before the effects
  // run, the order the host mounts in.
  const attachRefs = (tree) => {
    for (const node of nodes(tree)) {
      const ref = node?.props?.ref
      if (ref === null || typeof ref !== 'object' || !('current' in ref)) continue
      if (typeof node.type !== 'string') continue
      ref.current = {
        focus: () =>
          focused.push(node.type + (node.props.className ? ':' + node.props.className : '')),
      }
    }
  }
  const render = (props) => {
    cursor = 0
    const tree = View(props)
    attachRefs(tree)
    const runs = pending
    pending = []
    runs.forEach((run) => run())
    return tree
  }
  render.focused = focused
  return render
}

function nodes(tree) {
  if (!tree || typeof tree !== 'object') return [tree]
  // The stand-in React keeps function components as elements. Render them here
  // so a status/notice rendered by a small component is visible to the tree
  // assertions exactly as the host would render it. None of these components
  // use hooks; the views themselves are called directly by mount().
  const rendered = typeof tree.type === 'function' ? flat(tree.type(tree.props)) : []
  return [tree, ...flat(tree.props?.children ?? []).flatMap(nodes), ...rendered.flatMap(nodes)]
}
const flat = (value) => (Array.isArray(value) ? value.flat(Infinity) : [value])
function texts(tree) {
  return nodes(tree)
    .flatMap((node) => (Array.isArray(node?.props?.children) ? node.props.children : []))
    .flat(Infinity)
    .filter((value) => typeof value === 'string' || typeof value === 'number')
}
const find = (tree, predicate) => nodes(tree).find(predicate)
const byClass = (tree, className) =>
  nodes(tree).filter(
    (node) =>
      typeof node?.props?.className === 'string' &&
      node.props.className.split(' ').includes(className),
  )
const byText = (tree, text) =>
  nodes(tree).filter(
    (node) =>
      node?.type === 'button' &&
      flat(node.props.children ?? [])
        .flat(Infinity)
        .includes(text),
  )
/** How many rendered strings contain `text`. The duplicate-status guard. */
const countText = (tree, text) => texts(tree).filter((value) => String(value).includes(text)).length
/** Every live region a screen reader would announce. */
const liveRegions = (tree) =>
  nodes(tree).filter((node) => node?.props?.role === 'status' || node?.props?.role === 'alert')
const deferred = () => {
  let resolve
  let reject
  const promise = new Promise((yes, no) => {
    resolve = yes
    reject = no
  })
  return { promise, resolve, reject }
}

const ok = (value) => ({ ok: true, status: 200, json: async () => ({ ok: true, value }) })
const failure = (status, code, message) => ({
  ok: false,
  status,
  json: async () => ({ ok: false, error: { code, message } }),
})

const PROJECT = {
  state: 'bound',
  name: 'repo',
  projectId: '05025725-00be-4852-aba6-4854f961cd01',
  vault: { display: '~/vault', basename: 'vault' },
  reason: null,
}
const healthValue = (overrides = {}) => ({
  project: PROJECT,
  index: {
    state: 'ready',
    backend: 'sqlite',
    fts: true,
    stale: false,
    scanning: false,
    notes: 12,
    lastScan: '2026-10-27T12:00:00.000Z',
    quarantined: 0,
    skipped: {},
    reason: null,
  },
  queue: {
    queued: 1,
    failed: 1,
    deferred: 0,
    failedJobs: [
      {
        jobId: 'job-0123456789abcdef0123456789abcdef',
        state: 'failed',
        projectId: PROJECT.projectId,
        attempts: 2,
        createdAt: '2026-10-26T00:00:00.000Z',
        failedAt: '2026-10-26T01:00:00.000Z',
        lastError: 'boom',
        outputState: null,
      },
    ],
  },
  hot: {
    missing: false,
    used: 7200,
    capacity: 9000,
    trigger: 6030,
    ratio: 0.8,
    archivable: 3,
    compactable: 5,
    sections: [
      { name: '已完成', chars: 1200, entries: 1, pointers: 2, moveable: 3 },
      { name: '进行中', chars: 5400, entries: 6, pointers: 0, moveable: 2 },
    ],
  },
  diagnostics: {
    window: { capacity: 100, size: 2, oldestSeq: 1, newestSeq: 2, dropped: 0 },
    events: [
      { seq: 1, at: '2026-10-27T12:00:00.000Z', event: 'brief', outcome: 'injected' },
      { seq: 2, at: '2026-10-27T12:05:00.000Z', event: 'search', outcome: 'ok' },
    ],
  },
  digest: {
    window: { days: 1 },
    notes: { created: 1, updated: 0, superseded: 0 },
    appraisal: { findings: [], total: 0, truncated: false },
    hot: null,
    queue: null,
    recent: [],
    snapshot: {
      at: '2026-10-27T12:00:00.000Z',
      basis: 'current-status-among-inspected-sources',
      fields: [],
    },
    collection: {
      basis: 'inspected-source-notes',
      inspected: 1,
      limit: 200,
      truncated: false,
      incomplete: false,
      reasons: [],
    },
  },
  capabilities: { mutations: ['retry-job', 'compact-hot', 'refresh-digest'] },
  ...overrides,
})
const overviewValue = (overrides = {}) => ({
  project: PROJECT,
  counts: {
    notes: 515,
    links: 8,
    orphans: 12,
    byType: [
      { type: 'convention', n: 506 },
      { type: 'decision', n: 7 },
      { type: 'hub', n: 2 },
    ],
    byStatus: [
      { status: 'active', n: 514 },
      { status: 'provisional', n: 1 },
    ],
  },
  health: { state: 'ready', notes: 12, lastScan: '2026-10-27T12:00:00.000Z' },
  queue: { queued: 0, failed: 0, deferred: 0, failedJobs: [] },
  hot: { capacity: 9000, used: 5145 },
  recent: [
    { path: 'a.md', title: '决策一', type: 'decision', updated: '2026-10-27T12:00:00.000Z' },
    { path: 'b.md', title: '约定一', type: 'convention', updated: '2026-10-27T11:00:00.000Z' },
  ],
  digest: null,
  capabilities: { mutations: ['retry-job', 'compact-hot', 'refresh-digest'] },
  ...overrides,
})

const hit = (path, title) => ({
  path,
  title,
  type: 'decision',
  status: 'active',
  source: 'title',
  snippet: '一段摘要',
  scoreSignals: ['title'],
})

const previewValue = (mutation = 'retry-job') => ({
  mutation,
  token: 'token-case-1',
  expiresAt: Date.now() + 60_000,
  preview: {
    title: '重试失败的作业',
    confirmLabel: '确认执行',
    facts: [
      { label: '任务', value: 'job-0123456789abcdef0123456789abcdef' },
      { label: '状态', value: 'failed' },
    ],
    effects: ['会把该作业重新放入队列'],
    warning: 'DSH 可能唤醒工作进程，Codex 只会重新排队。',
  },
})
const confirmValue = (mutation = 'retry-job', replayed = false) => ({
  mutation,
  replayed,
  result:
    mutation === 'retry-job'
      ? { status: 'retried', jobId: 'job-0123456789abcdef0123456789abcdef', state: 'pending' }
      : mutation === 'compact-hot'
        ? { status: 'compacted', moved: 3, folded: 2, reclaimed: 900, used: 5000, capacity: 9000 }
        : {
            status: 'created',
            path: 'Projects/repo/_meta/digest.md',
            id: 'doc-1',
            charCount: 900,
            txId: 'tx-1',
            window: { days: 1 },
          },
})

/** Record each fetch body and answer from one handler. */
function stubFetch(t, handler) {
  const sent = []
  t.mock.method(globalThis, 'fetch', async (url, options) => {
    const body = JSON.parse(options.body)
    sent.push({ url, body })
    return handler(body, sent.length)
  })
  return sent
}

/**
 * The props the shell hands `SearchView`. The box and the filters live in the
 * shell now, so a view test supplies them the way the shell would; `query` is the
 * one the box holds and `onFilter` is the shell's one filter setter.
 */
const searchProps = (overrides = {}) => ({
  sessionId: 'session-a',
  query: 'binding',
  scope: 'project',
  type: null,
  status: null,
  limit: 25,
  visible: true,
  onFilter: () => {},
  onClose: () => {},
  ...overrides,
})

test('the confirm sheet is a modal with a trap, Escape, live status and an in-flight lock', async () => {
  const source = await readFile(MODULE, 'utf8')
  for (const marker of [
    "role: 'alertdialog'",
    "'aria-modal': true",
    "event.key === 'Escape'",
    "event.key === 'Tab'",
    "'aria-live': 'polite'",
    "'确认执行'",
    "'取消'",
    "'正在执行…'",
    'disabled:',
    'mem-sheet',
  ])
    assert.ok(source.includes(marker), 'the sheet contains ' + marker)
})

test('mutations use the preview/confirm contract and are hidden without capabilities', async () => {
  const source = await readFile(MODULE, 'utf8')
  for (const marker of [
    "action: 'preview'",
    "action: 'confirm'",
    'mutation',
    'capabilities',
    'mutations',
    'failedJobs',
    "'preview-stale'",
    'replayed',
  ])
    assert.ok(source.includes(marker), 'the mutation seam names ' + marker)
  assert.equal(
    source.includes("action: 'retry-job'"),
    false,
    'the action vocabulary stays preview/confirm',
  )
})

// ---------------------------------------------------------------------------
// Overview, search and health as rendered views
// ---------------------------------------------------------------------------

test('the overview reports project, clock and refresh to the shell and bands its numbers', async (t) => {
  stubFetch(t, () => ok(overviewValue()))
  const render = mount(t, 'OverviewView')
  const reported = []
  const jumps = []
  const props = {
    sessionId: 'session-a',
    visible: true,
    onMeta: (meta) => reported.push(meta),
    onJump: (view) => jumps.push(view),
  }
  render(props)
  await setImmediate()
  const tree = render(props)
  const last = reported.at(-1)
  assert.equal(last.project.name, 'repo', 'the masthead learns the project')
  assert.equal(last.loading, false)
  assert.ok(last.updatedAt > 0, 'the clock has a time to show')
  assert.equal(typeof last.refresh, 'function', 'the masthead refresh reaches the poll')
  assert.deepEqual(
    byClass(tree, 'mem-kpi-value').map((node) => node.props.children[0]),
    ['515', '8', '12', '0'],
  )
  assert.equal(byClass(tree, 'mem-kpi').length, 4, 'the KPI band keeps its four cells')

  // Composition: one stacked track, one fill per type row, one legend row each.
  assert.equal(byClass(tree, 'mem-comp').length, 1)
  assert.equal(byClass(tree, 'mem-bar-track').length, 1, 'the parts share one track')
  assert.equal(byClass(tree, 'mem-bar-fill').length, 3, 'the three type segments are drawn')
  assert.deepEqual(
    byClass(tree, 'mem-comp-name').map((node) => node.props.children[0]),
    ['约定', '决策', 'hub'],
  )
  assert.deepEqual(
    byClass(tree, 'mem-comp-value').map((node) => node.props.children[0]),
    ['506', '7', '2'],
  )
  assert.deepEqual(
    byClass(tree, 'mem-comp-pct').map((node) => node.props.children[0]),
    ['98.3%', '1.4%', '0.4%'],
  )
  // The status distribution rides the composition legend's tail as one line, not
  // as a second chip row: two "share of the whole" readings on one block disagree
  // about what the whole is (design §3.4 item 4).
  assert.equal(byClass(tree, 'mem-comp-status').length, 1, 'status rides the legend tail')
  assert.deepEqual(
    byClass(tree, 'mem-comp-status-value').map((node) => node.props.children[0]),
    ['生效 514 · 待确认 1'],
  )

  // Recent: ordinals retired, the type appears once, the meta is type · time.
  assert.equal(byClass(tree, 'mem-recent-row').length, 2)
  assert.equal(byClass(tree, 'mem-recent-index').length, 0, 'the numbered index is retired')
  assert.equal(byClass(tree, 'mem-dot').length, 2, 'each recent row carries a type dot')
  const recentMeta = byClass(tree, 'mem-recent-meta').map((node) => node.props.children[0])
  assert.ok(
    recentMeta.every((text) => /^(决策|约定) · /u.test(text)),
    'meta is type · time',
  )
  assert.equal(
    byClass(tree, 'mem-recent-row').reduce((sum, row) => sum + byClass(row, 'mem-stamp').length, 0),
    0,
    'the type is no longer printed twice',
  )

  // The health strip is passive and one action opens 健康.
  const strip = nodes(tree).find(
    (node) => node?.type === 'section' && node.props['aria-label'] === '健康',
  )
  assert.ok(strip, 'the overview keeps its health section')
  // The fixture has no failed jobs, so the strip carries 索引/扫描/热层.
  assert.equal(byClass(strip, 'mem-summary-item').length, 3)
  assert.ok(
    byClass(strip, 'mem-summary-item').every((cell) => cell.type !== 'button'),
    'the summary cells are not buttons',
  )
  assert.equal(byText(strip, '全部 →').length, 1, 'one action opens the health view')
})

test('overview KPI cells jump: 待处理 opens 健康, the other three open 检索', async (t) => {
  stubFetch(t, () => ok(overviewValue()))
  const jumps = []
  const render = mount(t, 'OverviewView')
  const props = { sessionId: 'session-a', visible: true, onJump: (view) => jumps.push(view) }
  render(props)
  await setImmediate()
  const tree = render(props)
  const cells = byClass(tree, 'mem-kpi')
  assert.equal(cells.length, 4)
  for (const cell of cells) cell.props.onClick()
  assert.deepEqual(jumps, ['search', 'search', 'search', 'health'])
})

test('composed, the tab names the page: no duplicate heading and no search jump', async (t) => {
  // The shell mounts every view with `onMeta`, so that prop is the "composed" signal.
  // A "概览" headline under a 概览 tab is the same word twice, and a 去检索 jump
  // pointed at a box that is now permanently one row above the body.
  stubFetch(t, () =>
    ok(overviewValue({ activity: activityFixture(), tags: { items: [], total: 0 } })),
  )
  const render = mount(t, 'OverviewView')
  render({ sessionId: 'session-a', visible: true, onMeta: () => {}, onJump: () => {} })
  await setImmediate()
  const composed = render({
    sessionId: 'session-a',
    visible: true,
    onMeta: () => {},
    onJump: () => {},
  })
  assert.equal(byClass(composed, 'mem-viewhead').length, 0, 'no page heading when composed')
  assert.equal(byText(composed, '去检索').length, 0, 'no jump to a box that is always visible')
  // Standalone (no `onMeta`) keeps the heading: there it is the only orientation.
  const alone = render({ sessionId: 'session-a', visible: true })
  assert.equal(byClass(alone, 'mem-viewhead').length, 1, 'standalone still says where it is')
})

// ---------------------------------------------------------------------------
// The five 概览 charts (design §3.4, acceptance §6.5)
// ---------------------------------------------------------------------------

/** An 84-day series with a few busy days, so the buckets and weeks are non-zero. */
function activityFixture() {
  const day = (offset) => {
    const date = new Date(2026, 9, 29)
    date.setDate(date.getDate() - offset)
    const pad = (n) => String(n).padStart(2, '0')
    return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`
  }
  const days = []
  for (let i = 83; i >= 0; i -= 1) days.push(day(i))
  return {
    from: days[0],
    to: days[83],
    days,
    created: days.map((_d, index) => (index % 7 === 0 ? 2 : index % 5 === 0 ? 1 : 0)),
    updated: days.map((_d, index) => (index % 6 === 0 ? 1 : 0)),
  }
}

const chartProps = (overrides = {}) => ({ sessionId: 'session-a', visible: true, ...overrides })

test('the activity heat map draws every day of the window and prints the matching total', async (t) => {
  const activity = activityFixture()
  stubFetch(t, () => ok(overviewValue({ activity, tags: { items: [], total: 0 } })))
  const render = mount(t, 'OverviewView')
  render(chartProps())
  await setImmediate()
  const tree = render(chartProps())
  const grid = byClass(tree, 'mem-heat-grid')
  assert.equal(grid.length, 1, 'one grid')
  assert.equal(grid[0].props.role, 'img', 'the whole grid is a single image')
  assert.ok(String(grid[0].props['aria-label']).includes('周活动'), 'its label states the window')
  const cells = byClass(tree, 'mem-heat-cell')
  // Sunday-first columns laid out by the grid CSS (`grid-auto-flow:column`, 7 rows)
  // from one flat run of cells, padded to whole weeks. The column count follows the
  // calendar, NOT a hard-coded twelve: 84 days spans 13 columns unless the window
  // starts on a Sunday, and that head partial column is real data. Dropping it once
  // made this chart print 合计 82 under a grid of 84 days, beside a flow block
  // reading 净增 84 — two answers for one window.
  assert.equal(cells.length % 7, 0, 'whole weeks only')
  const real = cells.filter((cell) => !(cell.props.className ?? '').split(' ').includes('is-void'))
  assert.equal(real.length, activity.days.length, 'every day in the window gets a cell')
  // Spec §6.5: a void cell is a calendar gap, not a reading. The grid's
  // `role="img"` already hides the run from assistive technology, but the
  // criterion is named on the cell, and a gap must not become focusable either.
  const voids = cells.filter((cell) => (cell.props.className ?? '').split(' ').includes('is-void'))
  assert.ok(voids.length > 0, 'an unaligned window is padded to whole weeks')
  for (const cell of voids) {
    assert.equal(cell.props['aria-hidden'], true, 'a void cell is hidden from AT')
    assert.equal(cell.props.tabIndex, undefined, 'a void cell is not focusable')
  }
  assert.equal(
    byClass(tree, 'mem-heat-col').length,
    0,
    'no per-column wrappers: the grid does the column layout',
  )
  // A 6px square is far below the 24px focus floor: a tabbable grid would be a
  // keyboard path nobody can use, so no cell may claim focus. The readings are
  // carried by the section meta and by each cell's own `title`/`aria-label`.
  for (const cell of cells) assert.equal(cell.props.tabIndex, undefined, 'no focusable cell')
  // Spec §3.4/§6.5: a data cell names the date and the value. A body-level <span>
  // has no tooltip of its own, so the same sentence is on `title` and `aria-label`
  // and in a screen-reader span — it must not be an inert <title> child.
  for (const cell of real) {
    assert.match(String(cell.props.title), /^\d{4}-\d{2}-\d{2} · \d+ 条$/u, 'date · value')
    assert.equal(cell.props['aria-label'], cell.props.title, 'the cell is readable')
    assert.equal(
      nodes(cell).some((node) => node?.type === 'title'),
      false,
      'no inert <title> inside an HTML cell',
    )
  }
  const legend = byClass(tree, 'mem-heat-legend')
  assert.equal(legend.length, 1)
  assert.equal(legend[0].props['aria-hidden'], true, 'the legend is decorative')
  assert.deepEqual(byClass(legend[0], 'mem-heat-swatch').length, 5, 'five buckets, zero included')
  // The printed total must equal the series it annotates — that equality is the
  // whole contract the meta text claims.
  const expectedTotal =
    activity.created.reduce((sum, n) => sum + n, 0) +
    activity.updated.reduce((sum, n) => sum + n, 0)
  const sectionNode = nodes(tree).find(
    (node) => node?.type === 'section' && node.props['aria-label'] === '活动热度',
  )
  const metaText = byClass(sectionNode, 'mem-meta').map((node) => node.props.children[0])
  assert.ok(
    metaText.some((text) => /^近 \d+ 周（\d+ 天）· 本周 \d+ 天有更新 · 合计 \d+ 条$/u.test(text)),
    'the meta names the window and states the numbers: ' + metaText.join('|'),
  )
  assert.ok(
    metaText.some((text) => String(text).includes('合计 ' + expectedTotal + ' 条')),
    '合计 equals every event in the window, not the cells that survived padding',
  )
  // Both charts read the same series, so one window cannot produce two totals.
  assert.equal(byClass(tree, 'mem-flow').length, 1, 'the flow chart is drawn from it too')
})

test('the flow bars share one zero line and normalise to the larger side', async (t) => {
  const activity = activityFixture()
  stubFetch(t, () => ok(overviewValue({ activity, tags: { items: [], total: 0 } })))
  const render = mount(t, 'OverviewView')
  render(chartProps())
  await setImmediate()
  const tree = render(chartProps())
  const chart = byClass(tree, 'mem-flow')
  assert.equal(chart.length, 1)
  const svgNode = byClass(chart[0], 'mem-flow-svg')[0]
  assert.equal(svgNode.props.role, 'img')
  // One zero line, drawn once, shared by both streams.
  assert.equal(byClass(svgNode, 'mem-flow-zero').length, 1, 'the zero line is drawn once')
  const bars = nodes(svgNode).filter(
    (node) => node?.type === 'rect' && node.props.className?.startsWith('mem-flow-'),
  )
  assert.ok(bars.length > 0, 'the calendar weeks draw bars')
  assert.ok(
    bars.some((bar) => bar.props.className.includes('created')),
    'created is one stream',
  )
  assert.ok(
    bars.some((bar) => bar.props.className.includes('updated')),
    'updated is the other',
  )
  // Every bar starts or ends on the shared zero line: 40 in a 80-unit box.
  for (const bar of bars) {
    const { y, height } = bar.props
    assert.ok(
      Math.abs(y + height - 40) < 0.01 || Math.abs(y - 40) < 0.01,
      'a bar touches the zero line: y=' + y + ' h=' + height,
    )
  }
  // sup erseded is a status snapshot, never a dated flow: no third stream exists.
  assert.equal(
    bars.some((bar) => bar.props.className.includes('superseded')),
    false,
    'no archived/superseded series is invented',
  )
  // Design §3.4 item 3 fixes the per-bar reading as `WW 周 · 新建 n · 更新 m`, and a
  // week number is only true if the bar IS that calendar week. This window starts on
  // Friday 2026-08-07 and ends on Thursday 2026-10-29, so it touches thirteen
  // Sunday-first weeks (2 + 11×7 + 5 days): the first bar holds only Aug 7-8 and the
  // last only Oct 25-29. The week numbers and (created, updated) pairs below are
  // re-derived from the fixture's day rule by hand; a trailing seven-day chunk would
  // produce different pairs and label days with a neighbouring week's number.
  const readings = nodes(svgNode)
    .filter((node) => node?.type === 'title')
    .map((node) => {
      const text = String(node.props.children[0])
      const match = /^(\d{2}) 周 · 新建 (\d+) · 更新 (\d+)$/u.exec(text)
      assert.ok(match, 'title is `WW 周 · 新建 n · 更新 m`: ' + text)
      return { week: Number(match[1]), created: Number(match[2]), updated: Number(match[3]) }
    })
  assert.deepEqual(
    readings.map((reading) => reading.week),
    [32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44],
    'one Sunday-first week of 2026 per bar, 32 through 44',
  )
  assert.deepEqual(
    readings.map((reading) => [reading.created, reading.updated]),
    [
      [2, 1],
      [3, 1],
      [4, 1],
      [3, 1],
      [3, 1],
      [3, 2],
      [3, 1],
      [4, 1],
      [3, 1],
      [3, 1],
      [3, 1],
      [3, 2],
      [1, 0],
    ],
    'each bar is exactly one calendar week, partial edge weeks included',
  )
  // Nothing is dropped: the readings sum to the series the window carries.
  const total = (values) => values.reduce((sum, value) => sum + value, 0)
  const createdTotal = total(activity.created)
  const updatedTotal = total(activity.updated)
  assert.equal(total(readings.map((reading) => reading.created)), createdTotal, 'created add up')
  assert.equal(total(readings.map((reading) => reading.updated)), updatedTotal, 'updated add up')
  // The week count and totals are stated numbers derived from the grouping, not
  // hard-coded twelves.
  const flowSection = nodes(tree).find(
    (node) => node?.type === 'section' && node.props['aria-label'] === '新建与更新',
  )
  assert.ok(
    byClass(flowSection, 'mem-meta').some(
      (node) => node.props.children[0] === '近 13 周净增 ' + (createdTotal - updatedTotal),
    ),
    'the meta states the calendar week count and the window net',
  )
  assert.equal(
    svgNode.props['aria-label'],
    '近 13 周新建 ' + createdTotal + ' 条，更新 ' + updatedTotal + ' 条',
    'the image label states the same window',
  )
  assert.equal(byClass(chart[0], 'mem-flow-legend').length, 1)
  assert.equal(byClass(chart[0], 'mem-flow-legend')[0].props['aria-hidden'], true)
})

test('every flow bar covers exactly one Sunday-first calendar week', async (t) => {
  // Day i is given the count i + 1, so a bar's total identifies precisely which days
  // it grouped. A calendar week is a contiguous in-window run, so the thirteen bar
  // totals are fixed; the old trailing seven-day chunks would group a 6-day head and
  // 7-day middles instead, producing different sums for the same window.
  const base = activityFixture()
  const activity = {
    from: base.days[0],
    to: base.days.at(-1),
    days: base.days,
    created: base.days.map((_day, index) => index + 1),
    updated: base.days.map(() => 0),
  }
  stubFetch(t, () => ok(overviewValue({ activity, tags: { items: [], total: 0 } })))
  const render = mount(t, 'OverviewView')
  render(chartProps())
  await setImmediate()
  const tree = render(chartProps())
  const svgNode = byClass(tree, 'mem-flow-svg')[0]
  const created = nodes(svgNode)
    .filter((node) => node?.type === 'title')
    .map((node) =>
      Number(/(\d+) 周 · 新建 (\d+) · 更新 \d+/u.exec(String(node.props.children[0]))[2]),
    )
  assert.deepEqual(
    created,
    [3, 42, 91, 140, 189, 238, 287, 336, 385, 434, 483, 532, 410],
    'a 2-day head, eleven whole weeks, then a 5-day tail',
  )
  assert.equal(
    created.reduce((sum, value) => sum + value, 0),
    (84 * 85) / 2,
    'the bars between them keep every day in the window',
  )
})

test('the week-of-year convention numbers the week containing January 1 as 01', async (t) => {
  // Sunday-first weeks, week 1 = the Sun-Sat week containing 1 January. Jan 1 2027 is
  // a Friday, so that week starts Sunday 2026-12-27 and numbers 01 there; Dec 20 2026
  // (the Sunday before) is week 52, and 2027-01-03 is week 02.
  const days = []
  for (let offset = 0; offset < 21; offset += 1) {
    const date = new Date(2026, 11, 20)
    date.setDate(date.getDate() + offset)
    const pad = (n) => String(n).padStart(2, '0')
    days.push(date.getFullYear() + '-' + pad(date.getMonth() + 1) + '-' + pad(date.getDate()))
  }
  const activity = {
    from: days[0],
    to: days[20],
    days,
    created: days.map(() => 1),
    updated: days.map(() => 0),
  }
  stubFetch(t, () => ok(overviewValue({ activity, tags: { items: [], total: 0 } })))
  const render = mount(t, 'OverviewView')
  render(chartProps())
  await setImmediate()
  const tree = render(chartProps())
  const titles = nodes(byClass(tree, 'mem-flow-svg')[0])
    .filter((node) => node?.type === 'title')
    .map((node) => node.props.children[0])
  assert.deepEqual(titles, [
    '52 周 · 新建 7 · 更新 0',
    '01 周 · 新建 7 · 更新 0',
    '02 周 · 新建 7 · 更新 0',
  ])
})

test('the sparkline samples twelve weekly cumulative points from created', async (t) => {
  const activity = activityFixture()
  stubFetch(t, () => ok(overviewValue({ activity, tags: { items: [], total: 0 } })))
  const render = mount(t, 'OverviewView')
  render(chartProps())
  await setImmediate()
  const tree = render(chartProps())
  const spark = byClass(tree, 'mem-kpi-spark')
  assert.equal(spark.length, 1, 'the 记忆条目 cell carries the growth shape')
  assert.equal(
    spark[0].props['aria-hidden'],
    true,
    'the shape is decorative; the number is the reading',
  )
  const polyline = nodes(spark[0]).find((node) => node?.type === 'polyline')
  assert.ok(polyline, 'the sparkline is one polyline')
  const points = String(polyline.props.points)
    .trim()
    .split(/\s+/u)
    .map((pair) => pair.split(',').map(Number))
  // Design §3.4 item 1 asks for a 12-point line. One point per day drew 84 points in
  // a 60×16 box — a step thirty times finer than the box can resolve.
  assert.equal(points.length, 12, 'twelve weekly points for an 84-day window')
  assert.equal(points[0][0], 0, 'the line starts at the left edge')
  assert.equal(points.at(-1)[0], 60, 'and ends at the right edge')
  // Hard-coded from the fixture's day rule, not recomputed with the implementation's
  // loop: a day whose index is a multiple of 7 contributes 2 and one whose index is a
  // multiple of 5 contributes 1 (two such days can share one week), so the twelve
  // weekly `created` sums are 3,3,4,3,3,3,3,4,3,3,3,3. The line is scaled to its own
  // total, so each plotted value is recovered from its y and compared.
  const expected = [3, 6, 10, 13, 16, 19, 22, 26, 29, 32, 35, 38]
  const createdTotal = activity.created.reduce((sum, n) => sum + n, 0)
  assert.equal(expected.at(-1), createdTotal, 'the hard-coded series ends at the created total')
  const plotted = points.map(([, y]) => ((16 - y) / 16) * createdTotal)
  plotted.forEach((value, index) =>
    assert.ok(
      Math.abs(value - expected[index]) < 0.15,
      'point ' + index + ' plots ' + expected[index] + ', got ' + value,
    ),
  )
  assert.ok(Math.abs(plotted.at(-1) - createdTotal) < 0.001, 'the last point is the created total')
  assert.ok(
    plotted.every((value, index) => index === 0 || value >= plotted[index - 1]),
    'the running total never drops',
  )
})

test('a 30-day sparkline window groups its days from the window end', async (t) => {
  // 30 days is four full weeks plus two days, so the grouping direction is observable:
  // a trailing resample puts the two-day chunk first (cumulative 1,4,7,10,13), while a
  // start-aligned one would put it last (4,7,9,13,13). The sparkline's contract is a
  // bounded decorative series of weekly marks, so it keeps its own trailing resample —
  // deliberately not the calendar weeks the flow bars draw.
  const base = activityFixture()
  const activity = {
    ...base,
    from: base.days.slice(-30)[0],
    to: base.days.at(-1),
    days: base.days.slice(-30),
    created: base.created.slice(-30),
    updated: base.updated.slice(-30),
  }
  stubFetch(t, () => ok(overviewValue({ activity, tags: { items: [], total: 0 } })))
  const render = mount(t, 'OverviewView')
  render(chartProps())
  await setImmediate()
  const tree = render(chartProps())
  const polyline = nodes(byClass(tree, 'mem-kpi-spark')[0]).find(
    (node) => node?.type === 'polyline',
  )
  const points = String(polyline.props.points)
    .trim()
    .split(/\s+/u)
    .map((pair) => pair.split(',').map(Number))
  assert.equal(points.length, 5, 'four weeks plus the two-day tail is five points')
  const total = activity.created.reduce((sum, n) => sum + n, 0)
  assert.equal(total, 13, 'the window carries 13 new notes')
  const plotted = points.map(([, y]) => ((16 - y) / 16) * total)
  ;[1, 4, 7, 10, 13].forEach((value, index) =>
    assert.ok(
      Math.abs(plotted[index] - value) < 0.1,
      'point ' + index + ' plots ' + value + ', got ' + plotted[index],
    ),
  )
})

test('a window that cannot hold two weekly points draws no sparkline', async (t) => {
  const full = activityFixture()
  const short = {
    ...full,
    days: full.days.slice(-7),
    created: [0, 0, 0, 0, 0, 0, 4],
    updated: [0, 0, 0, 0, 0, 0, 0],
  }
  stubFetch(t, () => ok(overviewValue({ activity: short, tags: { items: [], total: 0 } })))
  const render = mount(t, 'OverviewView')
  render(chartProps())
  await setImmediate()
  const tree = render(chartProps())
  // Seven days is exactly one weekly point, and a one-point line has no shape: the
  // cell shows the number alone rather than a single dot.
  assert.equal(byClass(tree, 'mem-kpi-spark').length, 0)
})

test('a year-long window still draws twelve points ending at the whole created total', async (t) => {
  // The index API accepts up to a year of days (`MAX_ACTIVITY_DAYS` in lib/index-db.js);
  // the panel route asks for 84 today, but "at most twelve points" cannot depend on the
  // caller always sending a twelve-week window.
  const end = new Date(2026, 9, 29)
  const days = []
  for (let offset = 364; offset >= 0; offset -= 1) {
    const date = new Date(end)
    date.setDate(date.getDate() - offset)
    const pad = (n) => String(n).padStart(2, '0')
    days.push(date.getFullYear() + '-' + pad(date.getMonth() + 1) + '-' + pad(date.getDate()))
  }
  // One created note per day: the window total is 365.
  const activity = {
    from: days[0],
    to: days[364],
    days,
    created: days.map(() => 1),
    updated: days.map(() => 0),
  }
  stubFetch(t, () => ok(overviewValue({ activity, tags: { items: [], total: 0 } })))
  const render = mount(t, 'OverviewView')
  render(chartProps())
  await setImmediate()
  const tree = render(chartProps())
  const polyline = nodes(byClass(tree, 'mem-kpi-spark')[0]).find(
    (node) => node?.type === 'polyline',
  )
  const points = String(polyline.props.points)
    .trim()
    .split(/\s+/u)
    .map((pair) => pair.split(',').map(Number))
  assert.equal(points.length, 12, 'a year still plots at most twelve points')
  // 365 days is 53 weekly chunks (the oldest is one day); the oldest 42 fold into the
  // first point and the last eleven stay whole weeks of seven, so the cumulative line
  // opens at 365 − 11 × 7 = 288 and closes on the whole window total of 365.
  const expectedFirstY = 16 - ((365 - 11 * 7) / 365) * 16
  assert.ok(Math.abs(points[0][1] - expectedFirstY) < 0.06, 'the head folds into point one')
  assert.ok(Math.abs(points.at(-1)[1]) < 0.001, 'the last point is the whole-window total')
  for (let index = 1; index < points.length; index += 1)
    assert.ok(points[index][1] <= points[index - 1][1] + 0.001, 'the running total never drops')
})

test('an all-zero window renders an empty sentence with its own week count', async (t) => {
  const flat = activityFixture()
  flat.created = flat.created.map(() => 0)
  flat.updated = flat.updated.map(() => 0)
  stubFetch(t, () => ok(overviewValue({ activity: flat, tags: { items: [], total: 0 } })))
  const render = mount(t, 'OverviewView')
  render(chartProps())
  await setImmediate()
  const tree = render(chartProps())
  assert.equal(byClass(tree, 'mem-flow-svg').length, 0, 'a zero window draws no bars')
  // The empty sentence counts the same calendar weeks the drawn chart would: the
  // 84-day fixture spans 13, not the static "12" the copy used to say.
  assert.equal(countText(tree, '近 13 周没有新建或更新记录。'), 1, 'the empty sentence, once')
  assert.equal(countText(tree, '近 12 周没有新建或更新记录。'), 0, 'never a hard-coded 12')
  assert.equal(byClass(tree, 'mem-kpi-spark').length, 0, 'a zero total has no shape to draw')
  // The heat map still draws: a zero window is a real reading, not a missing one.
  assert.equal(byClass(tree, 'mem-heat-grid').length, 1)
})

test('the empty-flow sentence names the short window’s own week count', async (t) => {
  // A 30-day window starting Wednesday 2026-09-30 touches five Sunday-first weeks, so
  // the empty state must derive its count from the grouping too: 5, not 13 or 12.
  const full = activityFixture()
  const activity = {
    ...full,
    from: full.days.slice(-30)[0],
    to: full.days.at(-1),
    days: full.days.slice(-30),
    created: full.created.slice(-30).map(() => 0),
    updated: full.updated.slice(-30).map(() => 0),
  }
  stubFetch(t, () => ok(overviewValue({ activity, tags: { items: [], total: 0 } })))
  const render = mount(t, 'OverviewView')
  render(chartProps())
  await setImmediate()
  const tree = render(chartProps())
  assert.equal(byClass(tree, 'mem-flow-svg').length, 0, 'a zero window draws no bars')
  assert.equal(countText(tree, '近 5 周没有新建或更新记录。'), 1, 'five calendar weeks, once')
})

test('the tag ranking counts tags, not occurrences, in its remainder line', async (t) => {
  // Ten distinct tags, five occurrences each; only eight fit. The remainder is two
  // TAGS, not the ten occurrences those two tags account for. Deriving it from
  // `total` once printed "另有 10 个标签" where two tags existed — the label and the
  // number were in different units, and it was only right when every unshown tag
  // happened to have one occurrence.
  const items = Array.from({ length: 10 }, (_x, index) => ({
    tag: 'dsh-mem/tag-' + index,
    n: 5,
  }))
  stubFetch(t, () =>
    ok(
      overviewValue({
        activity: activityFixture(),
        tags: { items, total: 50, distinct: 10 },
      }),
    ),
  )
  const render = mount(t, 'OverviewView')
  render(chartProps())
  await setImmediate()
  const tree = render(chartProps())
  assert.equal(byClass(tree, 'mem-freq-row').length, 8, 'eight rows at most')
  assert.equal(countText(tree, '另有 2 个标签'), 1, 'the remainder counts the two unshown TAGS')
  assert.equal(countText(tree, '另有 10 个标签'), 0, 'never the occurrences they hold')
  // The head count is occurrences, and it says so with its own unit.
  assert.equal(countText(tree, '50 次'), 1, 'occurrences are labelled 次')
  // The bars are proportional to the ranking's own maximum.
  const fills = byClass(tree, 'mem-freq-fill').map((node) => node.props.style.width)
  assert.equal(fills[0], '100%', 'the biggest tag fills the track')
})

test('without a flow, the composition falls back to the capped bar and legend', async (t) => {
  // The fallback path: no `flow` on the wire (an older host, or the trimmer having
  // dropped the whole flow). Seven types, which is what a real vault looks like.
  // The previous guard asserted `<= 3` against a THREE-type fixture, so it passed
  // without testing a cap at all — while the code emitted one segment per type and
  // aliased the seventh back to the first colour. A guard is only a guard when its
  // input exceeds the limit.
  const byType = [
    { type: 'convention', n: 30 },
    { type: 'decision', n: 20 },
    { type: 'doc', n: 10 },
    { type: 'gotcha', n: 6 },
    { type: 'hub', n: 3 },
    { type: 'glossary', n: 2 },
    { type: 'misc', n: 1 },
  ]
  stubFetch(t, () =>
    ok(
      overviewValue({
        activity: activityFixture(),
        counts: {
          notes: 7,
          links: 1,
          orphans: 0,
          byType,
          byStatus: [
            { status: 'active', n: 65 },
            { status: 'contested', n: 7 },
          ],
        },
        tags: { items: [], total: 0 },
      }),
    ),
  )
  const render = mount(t, 'OverviewView')
  render(chartProps())
  await setImmediate()
  const tree = render(chartProps())
  assert.equal(byClass(tree, 'mem-bar-track').length, 1)
  const fills = byClass(tree, 'mem-bar-fill')
  assert.equal(fills.length, 3, 'three segments for seven types')
  // Each segment has its OWN colour class: a duplicate tint reads as a repeated band.
  const segClasses = fills.map((node) =>
    (node.props.className ?? '').split(' ').find((name) => name.startsWith('is-seg')),
  )
  assert.equal(
    new Set(segClasses).size,
    3,
    'no two segments share a colour: ' + segClasses.join(','),
  )
  // The two largest keep their own names; the rest fold into one honest 其他.
  const names = byClass(tree, 'mem-comp-name').map((node) => node.props.children[0])
  assert.deepEqual(names, ['约定', '决策', '文档', '踩坑', 'hub', '术语表', 'misc'])
  // The legend still lists every type with its exact count, and the segments add up:
  // 30 + 20 + (10+6+3+2+1).
  const values = byClass(tree, 'mem-comp-value').map((node) => node.props.children[0])
  assert.deepEqual(values, ['30', '20', '10', '6', '3', '2', '1'])
  const widths = fills.map((node) => Number.parseFloat(node.props.style.width))
  assert.ok(
    Math.abs(widths.reduce((sum, width) => sum + width, 0) - 100) < 0.5,
    'the three segments account for the whole: ' + widths.join('+'),
  )
  assert.equal(byClass(tree, 'mem-comp-status').length, 1, 'status is one line, not a chip row')
  void byType
})

// ---------------------------------------------------------------------------
// The 构成 Sankey (joint type×status flow). The fixture's two margins add up on
// paper, and every layout number in the expectations is recomputable from those
// counts and the chart's declared 292×200 coordinate space: 180 usable units
// across 60 notes is 3 units per note, with a 4-unit gap between nodes.
// ---------------------------------------------------------------------------

/** 60 notes: 30 convention / 20 decision / 10 doc, and 45 active / 15 provisional. */
const FLOW_COUNTS = {
  notes: 60,
  links: 5,
  orphans: 2,
  byType: [
    { type: 'convention', n: 30 },
    { type: 'decision', n: 20 },
    { type: 'doc', n: 10 },
  ],
  byStatus: [
    { status: 'active', n: 45 },
    { status: 'provisional', n: 15 },
  ],
  // Every joint number is real: 25+5=30, 18+2=20, 2+8=10, 25+18+2=45, 5+2+8=15.
  flow: [
    { type: 'convention', status: 'active', n: 25 },
    { type: 'decision', status: 'active', n: 18 },
    { type: 'doc', status: 'provisional', n: 8 },
    { type: 'convention', status: 'provisional', n: 5 },
    { type: 'decision', status: 'provisional', n: 2 },
    { type: 'doc', status: 'active', n: 2 },
  ],
}

/** The first string child of an element's native <title> child. */
function titleOf(element) {
  const found = nodes(element).find((node) => node?.type === 'title')
  return found?.props?.children?.[0]
}

/** Render 概览 once with these counts; the chart data stays present so only 构成 changes. */
async function renderOverviewWith(t, counts, options) {
  stubFetch(t, () => ok(overviewValue({ counts, activity: activityFixture(), tags: null })))
  const render = mount(t, 'OverviewView', options)
  render(chartProps())
  await setImmediate()
  return render(chartProps())
}

test('the composition draws a Sankey whose geometry is the joint flow', async (t) => {
  const tree = await renderOverviewWith(t, FLOW_COUNTS)
  assert.equal(byClass(tree, 'mem-sankey').length, 1, 'one Sankey surface')
  assert.equal(byClass(tree, 'mem-comp').length, 0, 'the Sankey replaces the stacked bar')
  assert.equal(byClass(tree, 'mem-bar-track').length, 0, 'and its track')
  const svg = byClass(tree, 'mem-sankey-svg')
  assert.equal(svg.length, 1)
  assert.equal(svg[0].props.role, 'img', 'the whole chart is one image')
  assert.equal(svg[0].props.viewBox, '0 0 292 200', "the 320px floor's 292px content space")
  assert.equal(svg[0].props['aria-label'], '构成桑基图：共 60 条', 'the label names the total')
  // The section head prints the flow's own total, not a second aggregate.
  const sectionNode = nodes(tree).find(
    (node) => node?.type === 'section' && node.props['aria-label'] === '构成',
  )
  assert.ok(sectionNode, 'the 构成 section')
  assert.deepEqual(
    byClass(sectionNode, 'mem-meta').map((node) => node.props.children[0]),
    ['60 条'],
  )
  // Left column = byType order, height = n × 3 units; 4-unit gaps.
  const leftNodes = byClass(tree, 'mem-sankey-node').filter((node) =>
    node.props.className.split(' ').includes('is-type'),
  )
  assert.equal(leftNodes.length, 3)
  assert.deepEqual(
    leftNodes.map((node) => [node.props.x, node.props.y, node.props.width, node.props.height]),
    [
      [76, 6, 8, 90], // convention 30 × 3
      [76, 100, 8, 60], // decision 20 × 3 (6 + 90 + 4)
      [76, 164, 8, 30], // doc 10 × 3 (100 + 60 + 4)
    ],
  )
  // Right column = byStatus order; a two-node column is vertically centred.
  const rightNodes = byClass(tree, 'mem-sankey-node').filter((node) =>
    node.props.className.split(' ').includes('is-status'),
  )
  assert.equal(rightNodes.length, 2)
  assert.deepEqual(
    rightNodes.map((node) => [node.props.x, node.props.y, node.props.width, node.props.height]),
    [
      [204, 8, 8, 135], // active 45 × 3
      [204, 147, 8, 45], // provisional 15 × 3 (8 + 135 + 4)
    ],
  )
  // Every node carries its exact number in a native title (an SVG title is a real tooltip).
  assert.deepEqual(leftNodes.map(titleOf), ['约定 · 30 条', '决策 · 20 条', '文档 · 10 条'])
  assert.deepEqual(rightNodes.map(titleOf), ['生效 · 45 条', '待确认 · 15 条'])
  // Links: one filled closed band per joint row, stacked so a source's targets
  // follow the right column and a target's sources follow the left column.
  const links = byClass(tree, 'mem-sankey-link')
  assert.equal(links.length, 6)
  assert.deepEqual(
    links.map((node) => node.props.d),
    [
      'M84,6 C144,6 144,8 204,8 L204,83 C144,83 144,81 84,81 Z',
      'M84,81 C144,81 144,147 204,147 L204,162 C144,162 144,96 84,96 Z',
      'M84,100 C144,100 144,83 204,83 L204,137 C144,137 144,154 84,154 Z',
      'M84,154 C144,154 144,162 204,162 L204,168 C144,168 144,160 84,160 Z',
      'M84,164 C144,164 144,137 204,137 L204,143 C144,143 144,170 84,170 Z',
      'M84,170 C144,170 144,168 204,168 L204,192 C144,192 144,194 84,194 Z',
    ],
  )
  assert.deepEqual(links.map(titleOf), [
    '约定 → 生效 · 25 条',
    '约定 → 待确认 · 5 条',
    '决策 → 生效 · 18 条',
    '决策 → 待确认 · 2 条',
    '文档 → 生效 · 2 条',
    '文档 → 待确认 · 8 条',
  ])
  // numbers = geometry: each link's drawn thickness is its count × 3 units, a
  // node's outgoing links add up to the node's own height, and the two columns
  // are the same total (60 notes × 3).
  const thickness = (d) => {
    const numbers = String(d)
      .match(/-?\d+(?:\.\d+)?/gu)
      .map(Number)
    return numbers.at(-1) - numbers[1]
  }
  const printed = [25, 5, 18, 2, 2, 8]
  links.forEach((node, index) => {
    assert.equal(
      thickness(node.props.d),
      printed[index] * 3,
      'link thickness is the printed count: ' + printed[index],
    )
  })
  assert.equal(thickness(links[0].props.d) + thickness(links[1].props.d), 90, 'convention 30')
  assert.equal(thickness(links[2].props.d) + thickness(links[3].props.d), 60, 'decision 20')
  assert.equal(thickness(links[4].props.d) + thickness(links[5].props.d), 30, 'doc 10')
  assert.equal(
    thickness(links[0].props.d) + thickness(links[2].props.d) + thickness(links[4].props.d),
    135,
  )
  assert.equal(
    thickness(links[1].props.d) + thickness(links[3].props.d) + thickness(links[5].props.d),
    45,
  )
  // Labels and values are text, so no reading depends on colour alone.
  assert.deepEqual(
    byClass(tree, 'mem-sankey-label').map((node) => node.props.children[1]),
    ['约定', '决策', '文档', '生效', '待确认'],
  )
  assert.deepEqual(
    byClass(tree, 'mem-sankey-value').map((node) => node.props.children[0]),
    ['30', '20', '10', '45', '15'],
  )
  assert.equal(
    byClass(tree, 'mem-sankey-leader').length,
    0,
    'labels that already sit on their node centre need no leader',
  )
  // Colour is the type rank (left nodes + outgoing links); right nodes are neutral.
  assert.deepEqual(
    leftNodes.map((node) => node.props.className),
    [
      'mem-sankey-node is-type is-seg0',
      'mem-sankey-node is-type is-seg1',
      'mem-sankey-node is-type is-seg2',
    ],
  )
  assert.deepEqual(
    rightNodes.map((node) => node.props.className),
    ['mem-sankey-node is-status', 'mem-sankey-node is-status'],
  )
  assert.deepEqual(
    links.map((node) => node.props.className),
    [
      'mem-sankey-link is-seg0',
      'mem-sankey-link is-seg0',
      'mem-sankey-link is-seg1',
      'mem-sankey-link is-seg1',
      'mem-sankey-link is-seg2',
      'mem-sankey-link is-seg2',
    ],
  )
})

test('a long Sankey label truncates but keeps its full title', async (t) => {
  // A type name that is not one of the panel's own labels: clipped in the fixed
  // label column, with the full string in the native title next to it.
  const tree = await renderOverviewWith(t, {
    notes: 5,
    links: 0,
    orphans: 0,
    byType: [
      { type: 'decision', n: 3 },
      { type: 'a-very-long-type-name', n: 2 },
    ],
    byStatus: [{ status: 'active', n: 5 }],
    flow: [
      { type: 'decision', status: 'active', n: 3 },
      { type: 'a-very-long-type-name', status: 'active', n: 2 },
    ],
  })
  const labels = byClass(tree, 'mem-sankey-label')
  assert.equal(labels.length, 3, 'two type labels and one status label')
  const long = labels[1]
  assert.equal(
    nodes(long).find((node) => node?.type === 'title').props.children[0],
    'a-very-long-type-name',
  )
  const clipped = long.props.children[1]
  assert.notEqual(clipped, 'a-very-long-type-name', 'the column is bounded, so the text is clipped')
  assert.ok(String(clipped).endsWith('…'), 'clipping is visible: ' + clipped)
  assert.ok(String(clipped).length < 'a-very-long-type-name'.length)
})

// A realistic skewed vault (7 types, 3 statuses) packs six labels into the bottom
// third of the column. The single forward pass this replaces could push an earlier
// row past a later one there — measured at 200 units: 182 then 168, two labels 2px
// apart at the 11px font. The two-pass layout has to stay monotonic.
const SLIVER_COUNTS = {
  notes: 515,
  links: 0,
  orphans: 0,
  byType: [
    { type: 'convention', n: 420 },
    { type: 'decision', n: 60 },
    { type: 'doc', n: 20 },
    { type: 'gotcha', n: 8 },
    { type: 'hub', n: 4 },
    { type: 'glossary', n: 2 },
    { type: 'misc', n: 1 },
  ],
  byStatus: [
    { status: 'active', n: 500 },
    { status: 'provisional', n: 10 },
    { status: 'contested', n: 5 },
  ],
  flow: [
    { type: 'convention', status: 'active', n: 410 },
    { type: 'convention', status: 'provisional', n: 8 },
    { type: 'convention', status: 'contested', n: 2 },
    { type: 'decision', status: 'active', n: 56 },
    { type: 'decision', status: 'provisional', n: 2 },
    { type: 'decision', status: 'contested', n: 2 },
    { type: 'doc', status: 'active', n: 19 },
    { type: 'doc', status: 'contested', n: 1 },
    { type: 'gotcha', status: 'active', n: 8 },
    { type: 'hub', status: 'active', n: 4 },
    { type: 'glossary', status: 'active', n: 2 },
    { type: 'misc', status: 'active', n: 1 },
  ],
}

test('a sliver cluster keeps its label rows ordered and apart', async (t) => {
  const tree = await renderOverviewWith(t, SLIVER_COUNTS)
  const rows = byClass(tree, 'mem-sankey-label').map((node) => Number(node.props.y))
  assert.equal(rows.length, 10, 'seven type labels and three status labels')
  // The first seven rows belong to the left column, the last three to the right; 11px
  // is the token font size, so a correctly laid out column keeps at least that between
  // neighbouring rows (and the whole column orders top to bottom).
  for (const column of [rows.slice(0, 7), rows.slice(7)]) {
    for (let index = 1; index < column.length; index += 1) {
      const gap = column[index] - column[index - 1]
      assert.ok(gap >= 11, 'label rows stay ordered and apart, gap ' + gap + ' at ' + index)
    }
  }
})

test('a displaced label row is tied to its mark by a leader', async (t) => {
  const tree = await renderOverviewWith(t, SLIVER_COUNTS)
  const labels = byClass(tree, 'mem-sankey-label')
  const typeLabels = labels.filter((node) => node.props.x === 34)
  const statusLabels = labels.filter((node) => node.props.x === 252)
  const typeNodes = byClass(tree, 'mem-sankey-node').filter((node) =>
    node.props.className.split(' ').includes('is-type'),
  )
  const statusNodes = byClass(tree, 'mem-sankey-node').filter((node) =>
    node.props.className.split(' ').includes('is-status'),
  )
  const centreOf = (node) => Number(node.props.y) + Number(node.props.height) / 2
  const rowOf = (label) => Number(label.props.y) - 4
  // The expectation is the ASSOCIATION, not the layout formula: every row whose
  // baseline no longer sits on its mark's centre must own exactly one leader, and the
  // leader's two endpoints must be that row and that centre.
  const expected = [
    ...typeLabels.map((label, index) => ({
      x: 74,
      row: rowOf(label),
      centre: centreOf(typeNodes[index]),
    })),
    ...statusLabels.map((label, index) => ({
      x: 214,
      row: rowOf(label),
      centre: centreOf(statusNodes[index]),
    })),
  ].filter((entry) => Math.abs(entry.row - entry.centre) >= 0.5)
  assert.equal(expected.length, 8, 'six type rows and two status rows are displaced here')
  const leaderOf = (d) => {
    const match = /^M([\d.]+),([\d.]+)L([\d.]+),([\d.]+)$/u.exec(String(d))
    assert.ok(match, 'a leader is one vertical two-point path: ' + d)
    return {
      x: Number(match[1]),
      row: Number(match[2]),
      endX: Number(match[3]),
      centre: Number(match[4]),
    }
  }
  const leaders = byClass(tree, 'mem-sankey-leader').map((node) => leaderOf(node.props.d))
  assert.equal(
    leaders.length,
    expected.length,
    'one leader per displaced row, none for aligned rows',
  )
  leaders.forEach((leader, index) => {
    const wanted = expected[index]
    assert.equal(leader.x, wanted.x, 'the leader runs down its own label column')
    assert.equal(leader.endX, wanted.x, 'a leader is vertical')
    assert.ok(Math.abs(leader.row - wanted.row) < 0.01, 'the leader starts on the label row')
    assert.ok(Math.abs(leader.centre - wanted.centre) < 0.01, 'the leader ends on the node centre')
  })
})

test('a total that disagrees with the payload note count falls back to the bar', async (t) => {
  const tree = await renderOverviewWith(t, { ...FLOW_COUNTS, notes: 61 })
  assert.equal(byClass(tree, 'mem-sankey').length, 0, 'the claimed total is not the drawn total')
  assert.equal(byClass(tree, 'mem-bar-track').length, 1, 'the fallback bar answers')
})

test('the Sankey fills the measured block width and only its middle grows', async (t) => {
  const narrow = await renderOverviewWith(t, FLOW_COUNTS)
  const wide = await renderOverviewWith(t, FLOW_COUNTS, { sankeyWidth: 640 })
  const floored = await renderOverviewWith(t, FLOW_COUNTS, { sankeyWidth: 200 })
  const svgOf = (tree) => byClass(tree, 'mem-sankey-svg')[0]
  assert.equal(svgOf(narrow).props.viewBox, '0 0 292 200', 'the default is the 320px floor')
  assert.equal(svgOf(wide).props.viewBox, '0 0 640 200', 'a wide block gets a wide chart')
  assert.equal(svgOf(floored).props.viewBox, '0 0 292 200', 'never narrower than the floor')
  const typeNodes = (tree) =>
    byClass(tree, 'mem-sankey-node').filter((node) =>
      node.props.className.split(' ').includes('is-type'),
    )
  const statusNodes = (tree) =>
    byClass(tree, 'mem-sankey-node').filter((node) =>
      node.props.className.split(' ').includes('is-status'),
    )
  const vertical = (nodes) => nodes.map((node) => [node.props.y, node.props.height])
  // Only the horizontal positions move: the nodes' y/height, the link thickness and
  // the label rows are identical, so every printed number still equals its geometry.
  assert.deepEqual(vertical(typeNodes(wide)), vertical(typeNodes(narrow)))
  assert.deepEqual(vertical(statusNodes(wide)), vertical(statusNodes(narrow)))
  assert.deepEqual(
    typeNodes(wide).map((node) => node.props.x),
    [76, 76, 76],
    'the left column keeps its edge band',
  )
  assert.deepEqual(
    statusNodes(wide).map((node) => node.props.x),
    [552, 552],
    'the right column moves to the measured right edge (640 - 88)',
  )
  const linkOf = (tree) => String(byClass(tree, 'mem-sankey-link')[0].props.d)
  assert.ok(linkOf(narrow).startsWith('M84,'), 'links start at the left band edge')
  assert.ok(linkOf(narrow).includes(' 204,'), 'the narrow link ends at the right column')
  assert.ok(linkOf(wide).includes(' 552,'), 'the wide link ends at the measured right edge')
  assert.ok(
    byClass(wide, 'mem-sankey-label').some((node) => node.props.x === 600),
    'status labels hug the measured right edge (640 - 40)',
  )
  // The leaders that tie displaced rows to their slivers follow the same edge.
  const wideSliver = await renderOverviewWith(t, SLIVER_COUNTS, { sankeyWidth: 640 })
  const leaders = byClass(wideSliver, 'mem-sankey-leader').map((node) => String(node.props.d))
  assert.ok(
    leaders.some((d) => d.startsWith('M74,')),
    'type leaders stay on the left edge band',
  )
  assert.ok(
    leaders.some((d) => d.startsWith('M562,')),
    'status leaders follow the measured right edge (640 - 78)',
  )
})
test('a flow whose margins disagree falls back to the bar, never a lying chart', async (t) => {
  // Two host bugs (wrong type margin, wrong status margin). A Sankey drawn from
  // either would put link thickness next to printed totals that do not match.
  const mismatches = [
    {
      ...FLOW_COUNTS,
      flow: [
        { type: 'convention', status: 'active', n: 25 },
        { type: 'decision', status: 'active', n: 18 },
        { type: 'convention', status: 'provisional', n: 5 },
        { type: 'decision', status: 'provisional', n: 2 },
        { type: 'doc', status: 'active', n: 1 }, // doc's margin is 10, not 1
        { type: 'doc', status: 'provisional', n: 1 },
      ],
    },
    {
      ...FLOW_COUNTS,
      flow: [
        { type: 'convention', status: 'active', n: 30 }, // active's margin is 45
        { type: 'decision', status: 'active', n: 15 },
        { type: 'doc', status: 'provisional', n: 10 },
        { type: 'doc', status: 'active', n: 5 },
      ],
    },
  ]
  for (const counts of mismatches) {
    const tree = await renderOverviewWith(t, counts)
    assert.equal(byClass(tree, 'mem-sankey').length, 0, 'no Sankey from inconsistent margins')
    assert.equal(byClass(tree, 'mem-bar-track').length, 1, 'the old stacked bar answers instead')
    assert.equal(byClass(tree, 'mem-comp-legend').length, 1)
    assert.equal(byClass(tree, 'mem-comp-value').length, 3, 'and its legend still lists every type')
  }
})

test('an empty flow array is no chart either: the fallback bar answers', async (t) => {
  // The route's trimmer drops the flow WHOLE, so [] is a legitimate wire value
  // meaning "no joint counts". The view must read it as absent, not draw an
  // empty figure or a bar without its status line.
  const counts = {
    notes: 7,
    links: 1,
    orphans: 0,
    byType: [{ type: 'decision', n: 7 }],
    byStatus: [{ status: 'active', n: 7 }],
    flow: [],
  }
  stubFetch(t, () => ok(overviewValue({ counts })))
  const render = mount(t, 'OverviewView')
  render(chartProps())
  await setImmediate()
  const tree = render(chartProps())
  assert.equal(byClass(tree, 'mem-sankey').length, 0)
  assert.equal(byClass(tree, 'mem-bar-track').length, 1, 'the existing bar is the fallback')
  assert.equal(byClass(tree, 'mem-comp-status').length, 1, 'and its status line still rides along')
})

test('a payload without the chart fields draws no charts at all', async (t) => {
  // The route feature-detects `activity`/`tags` and answers null for an older index
  // build. That is "no chart", never an empty grid or an empty ranking block.
  stubFetch(t, () => ok(overviewValue({ activity: null, tags: null })))
  const render = mount(t, 'OverviewView')
  render(chartProps())
  await setImmediate()
  const tree = render(chartProps())
  assert.equal(byClass(tree, 'mem-kpi').length, 4, 'the KPI band still answers')
  assert.equal(byClass(tree, 'mem-heat-grid').length, 0, 'no heat map')
  assert.equal(byClass(tree, 'mem-flow').length, 0, 'no flow bars')
  assert.equal(byClass(tree, 'mem-freq-row').length, 0, 'no ranking')
  assert.equal(byClass(tree, 'mem-kpi-spark').length, 0, 'no sparkline either')
})

test('search is a results page: no field of its own, named filter groups and marked rows', async (t) => {
  const sent = stubFetch(t, (body) =>
    ok({
      query: body.query,
      hits: [
        {
          path: 'Projects/repo/Decisions/a.md',
          title: '决策一',
          type: 'decision',
          status: 'active',
          source: 'title',
          snippet: 'Binding memory notes',
          scoreSignals: ['title'],
        },
        {
          path: 'Projects/repo/Conventions/b.md',
          title: '约定一',
          type: 'convention',
          status: 'active',
          source: 'body',
          snippet: '另一段',
          scoreSignals: [],
        },
      ],
      limit: 25,
      hasMore: false,
      tookMs: 3,
    }),
  )
  const render = mount(t, 'SearchView')
  // The box belongs to the shell, so the results page must not carry a second one:
  // two `role="search"` forms in one DOM is two owners of the same query.
  let tree = render(searchProps())
  assert.equal(
    find(tree, (node) => node?.type === 'form'),
    undefined,
    'no form in the view',
  )
  assert.equal(byClass(tree, 'mem-searchbar').length, 0, 'no search bar in the view')
  assert.equal(
    find(tree, (node) => node?.type === 'input'),
    undefined,
    'no input in the view',
  )
  assert.equal(liveRegions(tree).length, 1, 'the body still owns one status region')
  assert.ok(
    texts(tree).some((text) => text === '本地记忆索引'),
    'the head names the local index',
  )
  assert.equal(
    texts(tree).some((text) => String(text).includes('FTS5')),
    false,
  )

  await setImmediate()
  tree = render(searchProps())
  assert.equal(sent.length, 1, 'mounting with a query runs exactly one read')
  assert.equal(sent[0].body.query, 'binding')
  assert.equal(sent[0].body.scope, 'project')
  assert.equal(byClass(tree, 'mem-result').length, 2)
  assert.equal(byClass(tree, 'mem-result-index').length, 0, 'result ordinals are retired')
  const groups = byClass(tree, 'mem-filter')
  assert.ok(groups.length >= 3, 'the three filter rows remain')
  for (const group of groups) {
    assert.equal(group.props.role, 'group', 'each filter row names its group')
    assert.ok(['类型', '状态', '范围'].includes(group.props['aria-label']))
    assert.ok(byClass(group, 'mem-filter-option').length >= 2, 'each group wraps its pills')
  }
  assert.ok(
    byClass(tree, 'mem-filter-option').some((node) => node.props['aria-pressed'] === true),
    'aria-pressed is retained',
  )
  assert.deepEqual(
    byClass(tree, 'mem-filter-option')
      .filter((node) => node.props['aria-pressed'] === true)
      .map((node) => node.props.children[0]),
    ['全部', '全部', '当前项目'],
    'the default selected pills are unchanged',
  )

  assert.ok(byClass(tree, 'mem-result-path').length === 2, 'every row carries its path')
  assert.ok(
    String(byClass(tree, 'mem-result-path')[0].props.children[0]).includes(
      'Projects/repo/Decisions/a.md',
    ),
  )
  assert.ok(
    byClass(tree, 'mem-chip').some((node) => node.props.children[0] === '决策'),
    'type is a chip',
  )
  assert.ok(
    byClass(tree, 'mem-chip').some((node) => node.props.children[0] === '生效'),
    'status is a chip',
  )
  assert.ok(
    byClass(tree, 'mem-chip').some((node) => String(node.props.children[0]).includes('来源 标题')),
  )
  const marks = nodes(tree).filter((node) => node?.type === 'mark')
  assert.deepEqual(
    marks.map((node) => node.props.children[0]),
    ['Binding'],
    'the snippet marks the query case-insensitively',
  )
  assert.equal(byClass(tree, 'mem-snippet').length, 2)
  assert.ok(texts(tree).some((text) => String(text).startsWith('共 2 条 · 用时 3 ms')))
})

test('a filter chip asks the shell for the change instead of owning filter state', async (t) => {
  const sent = stubFetch(t, () => ok({ hits: [], limit: 25, hasMore: false, tookMs: 1 }))
  const asked = []
  const render = mount(t, 'SearchView')
  render(searchProps({ onFilter: (field, value) => asked.push([field, value]) }))
  await setImmediate()
  let tree = render(searchProps({ onFilter: (field, value) => asked.push([field, value]) }))
  const before = sent.length
  byText(tree, '决策')[0].props.onClick()
  // The view reports the intent and does NOT run its own read: the shell rewrites
  // the search object, the new props arrive, and that is the one read.
  assert.deepEqual(asked, [['type', 'decision']])
  assert.equal(sent.length, before, 'a chip click is the shell’s run, not a second one')
  // Scope is filterable the same way; the unbound fallback is the view's one
  // self-initiated change, and it reports it through the same callback.
  assert.deepEqual(
    byClass(tree, 'mem-filter-option')
      .filter((node) => node.props['aria-pressed'] === true)
      .map((node) => node.props.children[0]),
    ['全部', '全部', '当前项目'],
  )
})

test('with no shell callback the chips still render and a run reads once', async (t) => {
  const sent = stubFetch(t, () => ok({ hits: [], limit: 25, hasMore: false, tookMs: 1 }))
  const render = mount(t, 'SearchView')
  render(searchProps({ onFilter: undefined }))
  await setImmediate()
  let tree = render(searchProps({ onFilter: undefined }))
  assert.equal(sent.length, 1)
  assert.equal(byClass(tree, 'mem-filter-option').length >= 6, true, 'the groups still render')
})

test('the results head offers 返回 only when the shell can close the search', async (t) => {
  stubFetch(t, () => ok({ hits: [hit('a.md', '决策一')], limit: 25, hasMore: false, tookMs: 1 }))
  const render = mount(t, 'SearchView')
  const closed = []
  const withClose = searchProps({ onClose: () => closed.push('close') })
  render(withClose)
  await setImmediate()
  let tree = render(withClose)
  const back = byText(tree, '返回')
  assert.equal(back.length, 1, 'one 返回 action when onClose is wired')
  back[0].props.onClick()
  assert.deepEqual(closed, ['close'], '返回 reports to the shell that owns the search state')
  // The view can also be mounted without the callback; then there is nowhere to go
  // back to and it must not offer a dead control.
  render(searchProps({ onClose: undefined }))
  await setImmediate()
  tree = render(searchProps({ onClose: undefined }))
  assert.equal(byText(tree, '返回').length, 0, 'no 返回 without a shell callback')
})

test('显示更多 reports the wider page to the shell instead of running its own read', async (t) => {
  const sent = stubFetch(t, () =>
    ok({ hits: [hit('a.md', '决策一')], limit: 25, hasMore: true, tookMs: 1 }),
  )
  const render = mount(t, 'SearchView')
  const limits = []
  const props = searchProps({ onLimit: (value) => limits.push(value) })
  render(props)
  await setImmediate()
  const tree = render(props)
  const more = byText(tree, '显示更多')
  assert.equal(more.length, 1, 'a partial page offers 显示更多')
  const before = sent.length
  more[0].props.onClick()
  // One owner for the page size: the view reports 50 upward and the shell's props
  // drive the next read, because a view-local 50 leaves the shell believing 25 and a
  // retry on the wider page silently drops rows.
  assert.deepEqual(limits, [50], 'the page size is reported, not owned')
  assert.equal(sent.length, before, 'the view itself starts no read')
})

test('the search footer reports a real total only for a complete page', async (t) => {
  const sent = stubFetch(t, (_body, call) =>
    ok({
      query: 'binding',
      hits: [
        {
          path: 'a.md',
          title: 'A',
          type: 'decision',
          status: 'active',
          source: 'title',
          snippet: 'a',
          scoreSignals: [],
        },
      ],
      limit: call === 1 ? 25 : 50,
      hasMore: call < 3,
      tookMs: 4,
    }),
  )
  const render = mount(t, 'SearchView')
  render(searchProps())
  await setImmediate()
  let tree = render(searchProps())
  assert.deepEqual(
    texts(tree).filter((text) => /条 · 用时/u.test(String(text))),
    ['已显示 1 条 · 用时 4 ms'],
    'a page with more rows says 已显示, never 共',
  )
  assert.equal(countText(tree, '共 1 条'), 0)
  assert.equal(byText(tree, '显示更多').length, 1)
  byText(tree, '显示更多')[0].props.onClick()
  await setImmediate()
  tree = render(searchProps())
  assert.equal(sent.at(-1).body.limit, 50, '显示更多 asks for the ceiling')
  assert.equal(countText(tree, '已达上限 50'), 1, 'the ceiling is named')
  // A new run at the ceiling (the shell would hand down a fresh limit, or the user
  // re-submits) turns the page complete: hasMore is false on the third answer.
  render(searchProps({ limit: 50 }))
  await setImmediate()
  tree = render(searchProps({ limit: 50 }))
  assert.deepEqual(
    texts(tree).filter((text) => /条 · 用时/u.test(String(text))),
    ['共 1 条 · 用时 4 ms'],
    'a complete page may claim 共',
  )
  assert.equal(countText(tree, '已显示 1 条'), 0)
})

test('search marks only terms of two or more characters, case-insensitively and literally', async (t) => {
  stubFetch(t, (body) =>
    ok({
      query: body.query,
      hits: [
        {
          path: 'a+b.md',
          title: 'T',
          type: 'doc',
          status: 'active',
          source: 'body',
          snippet: 'x A+B binding value',
          scoreSignals: [],
        },
      ],
      limit: 25,
      hasMore: false,
      tookMs: 1,
    }),
  )
  const render = mount(t, 'SearchView')
  // A query of two or more characters marks its terms; one character marks
  // nothing. Both are one mount each, because the query now arrives as a prop.
  render(searchProps({ query: 'x BINDING a+b' }))
  await setImmediate()
  let tree = render(searchProps({ query: 'x BINDING a+b' }))
  assert.deepEqual(
    nodes(tree)
      .filter((node) => node?.type === 'mark')
      .map((node) => node.props.children[0]),
    ['A+B', 'binding'],
    'the single-character term is ignored; the regex metacharacters stay literal',
  )
  render(searchProps({ query: 'x' }))
  await setImmediate()
  tree = render(searchProps({ query: 'x' }))
  assert.equal(
    nodes(tree).filter((node) => node?.type === 'mark').length,
    0,
    'one char marks nothing',
  )
})

test('health bands its summary, meter, digest and 诊断记录 timeline', async (t) => {
  stubFetch(t, () => ok(healthValue()))
  const render = mount(t, 'HealthView')
  render({ sessionId: 'session-a', visible: true })
  await setImmediate()
  const next = render({ sessionId: 'session-a', visible: true })
  const summary = find(next, (node) => node?.props?.['aria-label'] === '健康摘要')
  assert.ok(summary, 'the summary band comes first')
  assert.equal(byClass(next, 'mem-summary-item').length, 4, 'a 2x2 band of 索引/队列/热层/摘要')
  assert.deepEqual(
    byClass(next, 'mem-label')
      .map((node) => node.props.children[0])
      .slice(0, 4),
    ['索引', '队列', '热层', '摘要'],
  )
  assert.ok(byClass(next, 'mem-stamp').some((node) => node.props.children[0] === '就绪'))
  assert.ok(byClass(next, 'mem-meter-track').length === 1)
  assert.ok(byClass(next, 'mem-digest').length === 1)
  assert.ok(texts(next).some((text) => String(text).includes('今日摘要')))
  assert.ok(byClass(next, 'mem-row-title').some((node) => node.props.children[0] === '已完成'))
  assert.ok(
    texts(next).some((text) => String(text).includes('诊断记录')),
    'the section is retitled',
  )
  assert.equal(
    texts(next).some((text) => String(text).includes('最近的决策')),
    false,
    'the old mislabel is gone',
  )
  assert.equal(byClass(next, 'mem-event').length, 2)
  assert.equal(byClass(next, 'mem-event-dot').length, 2, 'each event is a timeline dot')
  assert.ok(
    byClass(next, 'mem-event').every((event) => byClass(event, 'mem-event-dot').length === 1),
  )
})

// ---------------------------------------------------------------------------
// 検索: one derived status, one render site (the reported duplicate class)
// ---------------------------------------------------------------------------

test('search renders every status string at most once across idle, loading, results, empty and error', async (t) => {
  const first = deferred()
  let requests = 0
  const sent = stubFetch(t, () => {
    requests += 1
    if (requests === 1) return first.promise
    if (requests === 2) return ok({ hits: [], limit: 25, hasMore: false, tookMs: 1 })
    return failure(503, 'unavailable', 'memory panel unavailable')
  })
  const render = mount(t, 'SearchView')
  const idle = '输入关键词开始检索'
  // An empty query is the idle state and sends nothing: the shell's box already
  // refuses an empty submit, and the view must not spend a request on its own.
  render(searchProps({ query: '' }))
  await setImmediate()
  let tree = render(searchProps({ query: '' }))
  assert.equal(sent.length, 0, 'an empty query never reaches the route')
  assert.equal(countText(tree, idle), 1, 'the idle sentence renders once')
  assert.equal(liveRegions(tree).length, 1, 'one status region owns the idle state')

  // A query arrives: the loading state replaces the idle one, exactly once.
  // The run starts in an effect (the props changed), so the loading frame is the
  // next paint, the order the host mounts in.
  render(searchProps())
  tree = render(searchProps())
  assert.equal(requests, 1, 'one query is one request')
  assert.equal(countText(tree, '正在检索…'), 1, 'the loading status renders once')
  assert.equal(countText(tree, idle), 0, 'the idle sentence is gone while loading')
  assert.equal(liveRegions(tree).length, 1, 'one status region owns the loading state')

  // Results: the footer carries the count, and only for a complete page.
  first.resolve(
    ok({
      hits: [hit('a.md', '决策一'), hit('b.md', '约定一')],
      limit: 25,
      hasMore: false,
      tookMs: 3,
    }),
  )
  await setImmediate()
  tree = render(searchProps())
  assert.equal(byClass(tree, 'mem-result').length, 2)
  assert.equal(countText(tree, '共 2 条'), 1, 'the results footer renders once')
  assert.equal(countText(tree, '正在检索…'), 0)
  assert.equal(countText(tree, idle), 0)

  // Empty results: one empty line, no idle fallback.
  render(searchProps({ query: 'nothing-matches' }))
  await setImmediate()
  tree = render(searchProps({ query: 'nothing-matches' }))
  assert.equal(countText(tree, '没有匹配的记忆。'), 1, 'the empty status renders once')
  assert.equal(countText(tree, idle), 0)

  // A failure after results is a stale notice carrying the real last-read time.
  render(searchProps({ query: 'explode' }))
  await setImmediate()
  tree = render(searchProps({ query: 'explode' }))
  assert.equal(countText(tree, '上次更新 '), 1, 'the stale notice renders once')
  assert.equal(countText(tree, '上次更新 —'), 0, 'a stale error never shows a fabricated time')
  assert.equal(
    countText(tree, '读取记忆失败：'),
    0,
    'the stale branch replaces the fresh error text',
  )
  for (const copy of [idle, '正在检索…', '没有匹配的记忆。', '上次更新 ', '共 2 条'])
    assert.ok(countText(tree, copy) <= 1, 'the status string renders at most once: ' + copy)
  assert.equal(byClass(tree, 'mem-result').length, 0)
})

test('a filter chip with an empty query asks the shell and sends no request', async (t) => {
  const sent = stubFetch(t, () => ok({ hits: [], limit: 25, hasMore: false, tookMs: 1 }))
  const asked = []
  const render = mount(t, 'SearchView')
  let tree = render(
    searchProps({ query: '', onFilter: (field, value) => asked.push([field, value]) }),
  )
  await setImmediate()
  byText(tree, '约定')[0].props.onClick()
  tree = render(searchProps({ query: '', onFilter: (field, value) => asked.push([field, value]) }))
  assert.equal(sent.length, 0, 'the empty query is not sent to the route')
  assert.deepEqual(asked, [['type', 'convention']], 'the chip reports the intent to the shell')
  assert.equal(countText(tree, '输入关键词开始检索'), 1)
  byText(tree, '全部')[0].props.onClick()
  tree = render(searchProps({ query: '', onFilter: (field, value) => asked.push([field, value]) }))
  assert.equal(sent.length, 0)
  assert.deepEqual(
    asked,
    [
      ['type', 'convention'],
      ['type', null],
    ],
    'a second chip still reports without reading',
  )
  assert.equal(countText(tree, '输入关键词开始检索'), 1)
})

test('a filter chip with a query reports once and the shell’s new props do the read', async (t) => {
  const sent = stubFetch(t, () =>
    ok({ hits: [hit('a.md', '决策一')], limit: 25, hasMore: false, tookMs: 1 }),
  )
  const asked = []
  const render = mount(t, 'SearchView')
  render(searchProps({ onFilter: (field, value) => asked.push([field, value]) }))
  await setImmediate()
  let tree = render(searchProps({ onFilter: (field, value) => asked.push([field, value]) }))
  const before = sent.length
  byText(tree, '决策')[0].props.onClick()
  assert.deepEqual(asked, [['type', 'decision']])
  assert.equal(sent.length, before, 'the chip itself never reads')
  // The shell then hands down the refined filter; that is the one read.
  render(searchProps({ type: 'decision', onFilter: () => {} }))
  await setImmediate()
  tree = render(searchProps({ type: 'decision', onFilter: () => {} }))
  assert.equal(sent.length, before + 1, 'the refined filter runs exactly one more request')
  assert.equal(sent.at(-1).body.query, 'binding')
  assert.equal(sent.at(-1).body.type, 'decision')
  assert.equal(byClass(tree, 'mem-result').length, 1)
})

test('the unbound scope switch asks the shell and lets its single read carry the notice', async (t) => {
  const fallback = deferred()
  let requests = 0
  const sent = stubFetch(t, () => {
    requests += 1
    return requests === 1 ? failure(422, 'unbound', 'project unbound') : fallback.promise
  })
  const asked = []
  const onFilter = (field, value) => asked.push([field, value])
  const render = mount(t, 'SearchView')
  render(searchProps({ onFilter }))
  await setImmediate()
  let tree = render(searchProps({ onFilter }))
  // The view tried `project`, failed, and REPORTS the scope move. It must not also
  // run `all` itself: doing both spent a third request, and the props change then
  // started a fresh run that cleared the notice this branch exists to show.
  assert.equal(requests, 1, 'the failed project read is the only request so far')
  assert.deepEqual(asked, [['scope', 'all']], 'the view tells the shell the scope moved')
  assert.equal(
    countText(tree, '当前项目未绑定；正在搜索全部项目。'),
    1,
    'the notice is no longer dead copy and renders once',
  )
  assert.equal(countText(tree, '输入关键词开始检索'), 0)

  // The shell answers with the new scope — exactly one more read, and the carried
  // notice survives it rather than being replaced by a bare loading state.
  tree = render(searchProps({ scope: 'all', onFilter }))
  assert.equal(requests, 2, 'the shell-driven run is the second and only extra read')
  assert.equal(sent[1].body.scope, 'all', 'the fallback asks the all-project scope')
  assert.equal(
    countText(tree, '当前项目未绑定；正在搜索全部项目。'),
    1,
    'the notice survives the run it prompted',
  )
  fallback.resolve(ok({ hits: [hit('a.md', '决策一')], limit: 25, hasMore: false, tookMs: 2 }))
  await setImmediate()
  tree = render(searchProps({ scope: 'all', onFilter }))
  assert.equal(byClass(tree, 'mem-result').length, 1)
  assert.equal(
    countText(tree, '当前项目未绑定；正在搜索全部项目。'),
    0,
    'the run-scoped notice is replaced by the results status',
  )
  assert.equal(requests, 2, 'and no third request was ever spent')
  assert.ok(
    byClass(tree, 'mem-filter-option').some(
      (node) => node.props.children[0] === '全部' && node.props['aria-pressed'] === true,
    ),
    'the 范围 group shows the switched scope',
  )
})

test('the overview owns its loading announcement once, from the skeleton, then refreshes', async (t) => {
  const gates = [deferred(), deferred()]
  let calls = 0
  stubFetch(t, () => gates[Math.min(calls++, gates.length - 1)].promise)
  const render = mount(t, 'OverviewView')
  const props = { sessionId: 'session-a', visible: true }
  render(props)
  await setImmediate()
  let tree = render(props)
  assert.equal(countText(tree, '正在读取记忆…'), 1, 'the skeleton is the one loading announcement')
  assert.equal(liveRegions(tree).length, 1, 'one live region in the loading state')
  gates[0].resolve(ok(overviewValue()))
  await setImmediate()
  tree = render(props)
  assert.equal(countText(tree, '正在读取记忆…'), 0)
  const refreshing = { ...props, refreshKey: 1 }
  render(refreshing)
  tree = render(refreshing)
  assert.equal(
    countText(tree, '正在刷新…'),
    1,
    'the refresh status renders once, from the status line',
  )
  assert.equal(countText(tree, '正在读取记忆…'), 0, 'the skeleton does not announce a refresh')
  assert.equal(liveRegions(tree).length, 1)
})

test('the health view owns its loading announcement once, from the skeleton', async (t) => {
  const gate = deferred()
  stubFetch(t, () => gate.promise)
  const render = mount(t, 'HealthView')
  const props = { sessionId: 'session-a', visible: true }
  render(props)
  await setImmediate()
  const tree = render(props)
  assert.equal(countText(tree, '正在读取记忆…'), 1, 'the skeleton is the one loading announcement')
  assert.equal(liveRegions(tree).length, 1, 'one live region in the loading state')
})

/** Render health until its first read lands. */
async function health(t) {
  const render = mount(t, 'HealthView')
  const props = { sessionId: 'session-a', visible: true }
  render(props)
  await setImmediate()
  return { render, props, tree: render(props) }
}

test('the sheet restores focus to its invoker and the busy trap keeps focus on the dialog', async (t) => {
  const confirmGate = deferred()
  stubFetch(t, (body) => {
    if (body.action === 'preview') return ok(previewValue('retry-job'))
    if (body.action === 'confirm') return confirmGate.promise
    return ok(healthValue())
  })
  const { render, props } = await health(t)
  let tree = render(props)
  const restored = []
  const invoker = { focus: () => restored.push('invoker') }
  byText(tree, '重新排队')[0].props.onClick({ currentTarget: invoker })
  await setImmediate()
  tree = render(props)
  assert.ok(
    find(tree, (node) => node?.props?.role === 'alertdialog'),
    'the preview opens the sheet',
  )
  assert.equal(render.focused.at(-1), 'button:mem-sheet-cancel', 'Cancel takes focus on open')

  byText(tree, '确认执行')[0].props.onClick()
  await setImmediate()
  tree = render(props)
  const dialog = find(tree, (node) => node?.props?.role === 'alertdialog')
  assert.ok(dialog, 'the sheet stays open while the confirm is in flight')
  assert.equal(
    find(tree, (node) => node?.props?.className === 'mem-sheet-panel').props.tabIndex,
    -1,
    'the dialog panel is focusable as the trap floor',
  )
  const prevented = []
  dialog.props.onKeyDown({
    key: 'Tab',
    shiftKey: false,
    target: null,
    preventDefault: () => prevented.push('tab'),
  })
  assert.deepEqual(prevented, ['tab'], 'the trap still handles Tab while busy')
  assert.equal(
    render.focused.at(-1),
    'div:mem-sheet-panel',
    'focus stays on the dialog instead of dropping to body',
  )

  confirmGate.resolve(failure(409, 'preview-stale', 'stale preview'))
  await setImmediate()
  tree = render(props)
  assert.equal(
    find(tree, (node) => node?.props?.role === 'alertdialog'),
    undefined,
    'the invalidating failure closes the sheet',
  )
  assert.deepEqual(restored, ['invoker'], 'focus returns to the control that opened the sheet')
})

test('the retry action previews facts then confirms one token and reports the outcome', async (t) => {
  const sent = stubFetch(t, (body) => {
    if (body.action === 'preview') return ok(previewValue('retry-job'))
    if (body.action === 'confirm') return ok(confirmValue('retry-job'))
    return ok(healthValue())
  })
  const { render, props } = await health(t)
  const ready = render(props)
  const retry = byText(ready, '重新排队')[0]
  assert.ok(retry, 'a failed job offers one retry affordance')
  retry.props.onClick()
  await setImmediate()
  let tree = render(props)
  const dialog = find(tree, (node) => node?.props?.role === 'alertdialog')
  assert.ok(dialog, 'the preview opens a sheet')
  assert.ok(byClass(tree, 'mem-sheet-fact').length >= 2, 'the facts are listed')
  const previewRequest = sent.filter((entry) => entry.body.action === 'preview').at(-1)
  assert.deepEqual(previewRequest.body, {
    sessionId: 'session-a',
    action: 'preview',
    mutation: 'retry-job',
    args: { jobId: 'job-0123456789abcdef0123456789abcdef' },
  })
  assert.equal(
    sent.filter((entry) => entry.body.action === 'confirm').length,
    0,
    'a preview writes nothing',
  )
  const confirm = byText(tree, '确认执行')[0]
  assert.ok(confirm, 'the confirm label comes from the preview')
  confirm.props.onClick()
  await setImmediate()
  tree = render(props)
  const confirmRequest = sent.filter((entry) => entry.body.action === 'confirm').at(-1)
  assert.deepEqual(confirmRequest.body, {
    sessionId: 'session-a',
    action: 'confirm',
    token: 'token-case-1',
  })
  assert.equal(
    find(tree, (node) => node?.props?.role === 'alertdialog'),
    undefined,
    'the sheet closes',
  )
  assert.ok(
    byClass(tree, 'mem-action-status').some((node) =>
      texts(node).some((text) => String(text).includes('已重新排队')),
    ),
    'the outcome is named in words',
  )
})

test('Escape and cancel close the sheet without sending a request', async (t) => {
  const sent = stubFetch(t, (body) =>
    body.action === 'preview' ? ok(previewValue('retry-job')) : ok(healthValue()),
  )
  const { render, props } = await health(t)
  let tree = render(props)
  byText(tree, '重新排队')[0].props.onClick()
  await setImmediate()
  tree = render(props)
  const before = sent.length
  find(tree, (node) => node?.props?.role === 'alertdialog').props.onKeyDown({
    key: 'Escape',
    preventDefault() {},
  })
  await setImmediate()
  tree = render(props)
  assert.equal(
    find(tree, (node) => node?.props?.role === 'alertdialog'),
    undefined,
    'Escape closes it',
  )
  assert.equal(sent.length, before, 'closing sends nothing')

  byText(tree, '重新排队')[0].props.onClick()
  await setImmediate()
  tree = render(props)
  byText(tree, '取消')[0].props.onClick()
  await setImmediate()
  tree = render(props)
  assert.equal(
    find(tree, (node) => node?.props?.role === 'alertdialog'),
    undefined,
    'cancel closes it',
  )
  assert.equal(sent.length, before + 1, 'only the second preview was sent')
})

test('a 409 preview-stale invalidates the sheet, refreshes health and says so', async (t) => {
  const sent = stubFetch(t, (body) => {
    if (body.action === 'preview') return ok(previewValue('retry-job'))
    if (body.action === 'confirm') return failure(409, 'preview-stale', 'stale preview')
    return ok(healthValue())
  })
  const { render, props } = await health(t)
  let tree = render(props)
  byText(tree, '重新排队')[0].props.onClick()
  await setImmediate()
  tree = render(props)
  byText(tree, '确认执行')[0].props.onClick()
  await setImmediate()
  tree = render(props)
  assert.equal(
    find(tree, (node) => node?.props?.role === 'alertdialog'),
    undefined,
  )
  assert.ok(
    byClass(tree, 'mem-action-status').some((node) =>
      texts(node).some((text) => String(text).includes('预览已过期')),
    ),
  )
  assert.equal(
    sent.filter((entry) => entry.body.action === 'confirm').length,
    1,
    'one confirm attempt, then the sheet is gone',
  )
  assert.ok(
    sent.filter((entry) => entry.body.action === 'health').length >= 2,
    'the underlying view refreshes',
  )
})

test('a replayed confirmation names the same outcome and says nothing was written twice', async (t) => {
  stubFetch(t, (body) => {
    if (body.action === 'preview') return ok(previewValue('retry-job'))
    if (body.action === 'confirm') return ok(confirmValue('retry-job', true))
    return ok(healthValue())
  })
  const { render, props } = await health(t)
  let tree = render(props)
  byText(tree, '重新排队')[0].props.onClick()
  await setImmediate()
  tree = render(props)
  byText(tree, '确认执行')[0].props.onClick()
  await setImmediate()
  tree = render(props)
  const status = byClass(tree, 'mem-action-status')
    .map((node) => texts(node).join(''))
    .join(' ')
  assert.ok(status.includes('已重新排队'), 'the outcome is still named')
  assert.ok(status.includes('未重复'), 'the replay is explained')
})

test('compact-hot and refresh-digest open the same sheet with their own facts', async (t) => {
  stubFetch(t, (body) => {
    if (body.action === 'preview')
      return ok(
        body.mutation === 'compact-hot'
          ? {
              mutation: 'compact-hot',
              token: 'token-compact',
              expiresAt: Date.now() + 60_000,
              preview: {
                title: '压缩热层',
                confirmLabel: '确认执行',
                facts: [
                  { label: '使用', value: '7,200 / 9,000' },
                  { label: '可搬出', value: '3 条' },
                ],
                effects: ['折叠指针行并归档最旧条目'],
              },
            }
          : {
              ...previewValue('refresh-digest'),
              preview: {
                title: '刷新今日摘要',
                confirmLabel: '确认执行',
                facts: [
                  { label: '目标', value: 'Projects/repo/_meta/digest.md' },
                  { label: '窗口', value: '最近 1 天' },
                ],
                effects: ['重写项目自己的摘要笔记'],
              },
            },
      )
    if (body.action === 'confirm')
      return ok(confirmValue(body.token === 'token-compact' ? 'compact-hot' : 'refresh-digest'))
    return ok(healthValue())
  })
  const { render, props } = await health(t)
  let tree = render(props)
  byText(tree, '整理热层')[0].props.onClick()
  await setImmediate()
  tree = render(props)
  assert.ok(byClass(tree, 'mem-sheet-fact').some((node) => texts(node).join('').includes('使用')))
  byText(tree, '确认执行')[0].props.onClick()
  await setImmediate()
  tree = render(props)
  assert.ok(
    byClass(tree, 'mem-action-status').some((node) =>
      texts(node).some((text) => String(text).includes('搬出 3')),
    ),
  )
  byText(tree, '发布项目摘要')[0].props.onClick()
  await setImmediate()
  tree = render(props)
  assert.ok(
    byClass(tree, 'mem-sheet-fact').some((node) =>
      texts(node).join('').includes('_meta/digest.md'),
    ),
  )
  byText(tree, '取消')[0].props.onClick()
})

test('a transient confirm failure stays inline in the sheet and Cancel still closes it', async (t) => {
  const sent = stubFetch(t, (body) => {
    if (body.action === 'preview') return ok(previewValue('retry-job'))
    if (body.action === 'confirm') return failure(503, 'unavailable', 'memory panel unavailable')
    return ok(healthValue())
  })
  const { render, props } = await health(t)
  let tree = render(props)
  byText(tree, '重新排队')[0].props.onClick()
  await setImmediate()
  tree = render(props)
  byText(tree, '确认执行')[0].props.onClick()
  await setImmediate()
  tree = render(props)
  const sheet = find(tree, (node) => node?.props?.role === 'alertdialog')
  assert.ok(sheet, 'the sheet stays open so the preview is not lost')
  assert.ok(
    byClass(tree, 'mem-sheet-error').some((node) => texts(node).join('').includes('稍后重试')),
    'the refusal is named inline',
  )
  byText(tree, '取消')[0].props.onClick()
  await setImmediate()
  tree = render(props)
  assert.equal(
    find(tree, (node) => node?.props?.role === 'alertdialog'),
    undefined,
  )
  assert.equal(
    sent.filter((entry) => entry.body.action === 'preview').length,
    1,
    'no silent re-preview',
  )
})

test('without capabilities the panel is fully usable read-only and offers no confirm action', async (t) => {
  stubFetch(t, () => ok(healthValue({ capabilities: { mutations: [] } })))
  const { render, props } = await health(t)
  const tree = render(props)
  assert.equal(byText(tree, '重新排队').length, 0)
  assert.equal(byText(tree, '整理热层').length, 0)
  assert.equal(byText(tree, '发布项目摘要').length, 0)
  assert.ok(byClass(tree, 'mem-stamp').length > 0, 'the read-only view still renders')
})

test('an unavailable preview API hides the controls and leaves one clear notice', async (t) => {
  stubFetch(t, (body) =>
    body.action === 'preview'
      ? failure(503, 'unavailable', 'memory panel unavailable')
      : ok(healthValue()),
  )
  const { render, props } = await health(t)
  let tree = render(props)
  byText(tree, '重新排队')[0].props.onClick()
  await setImmediate()
  tree = render(props)
  assert.equal(byText(tree, '重新排队').length, 0, 'the mutation controls are gone')
  assert.ok(
    byClass(tree, 'mem-action-status').some((node) =>
      texts(node).some((text) => String(text).includes('只读')),
    ),
    'the panel says it fell back to read-only',
  )
  assert.ok(byClass(tree, 'mem-stamp').length > 0, 'reading keeps working')
})
