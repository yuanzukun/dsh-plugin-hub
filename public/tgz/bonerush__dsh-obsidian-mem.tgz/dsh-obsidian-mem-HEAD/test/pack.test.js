// Task 19: the package manifest contract, and the verifier that guards it.
//
// `npm run prepack` is the release gate: it runs this suite and then
// `scripts/verify-pack.mjs`. A verifier nothing exercises is a verifier that
// quietly rots, so every failure condition the ruling names is pinned here
// against a throwaway fixture tree — the real checkout is only ever read.
//
// The fixture is deliberately tiny: it is the smallest tree that satisfies the
// contract, so a case can break exactly one thing and still fail for that
// reason alone.
import assert from 'node:assert/strict'
import { spawnSync } from 'node:child_process'
import { mkdirSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { dirname, join, resolve } from 'node:path'
import { test } from 'node:test'
import { fileURLToPath } from 'node:url'
import { Range, parse, satisfies } from 'semver'

import {
  REQUIRED_ENTRIES,
  listArchive,
  npmCommand,
  parsePackReport,
  verifyTarballEntries,
} from '../scripts/verify-tarball.mjs'

const REPO_ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '..')
const VERIFIER = resolve(REPO_ROOT, 'scripts/verify-pack.mjs')
const TARBALL_VERIFIER = resolve(REPO_ROOT, 'scripts/verify-tarball.mjs')

/**
 * The harness versions this plugin claims to have been verified against.
 *
 * Kept as a literal rather than read out of the README: the point of the check is
 * that the declared peer range agrees with the claim, and parsing prose to prove
 * a claim about prose would let both drift together.
 */
const MEASURED_HOST_VERSIONS = Object.freeze({
  '@deepseek-ai/dsh-tools': ['0.1.5-rc.2', '0.1.7-rc.2', '0.2.0-rc.1'],
  '@deepseek-ai/cordis': ['4.0.2', '4.0.4'],
})

/**
 * The six tool names the shipped surface registers, and the four names the façade
 * publishes them through.
 *
 * Both halves exist in the fixture because the verifier checks both: the
 * registration sites live in `lib/tool-registry.js` and the re-exports in
 * `lib/tools.js` since Task 11, and a fixture that only wrote one of the two
 * files would be testing a package layout this plugin no longer has.
 */
const TOOL_NAMES = ['mem_search', 'mem_read', 'mem_write', 'mem_log', 'mem_brief', 'mem_admin']

/** The four published names, and the module each one is re-exported from. */
const FACADE = [
  ['TOOL_NAMES', './tool-schema.js'],
  ['TOOL_PARAMETERS', './tool-schema.js'],
  ['registerTools', './tool-registry.js'],
  ['createMemoryServices', './services.js'],
]

/**
 * A `lib/tool-registry.js` with one `name: '…'` registration site per tool.
 *
 * @param {string[]} [names] - the tools to register.
 * @returns {string} the module's contents.
 */
function registrySource(names = TOOL_NAMES) {
  return names.map((name) => `  name: '${name}',\n`).join('')
}

/**
 * A `lib/tools.js` façade. By default it is the real one's three re-export
 * statements; `omit` drops a name so a case can break exactly that.
 *
 * @param {string[]} [omit] - published names to leave out.
 * @returns {string} the module's contents.
 */
function facadeSource(omit = []) {
  const byModule = new Map()
  for (const [name, module] of FACADE) {
    if (omit.includes(name)) continue
    byModule.set(module, [...(byModule.get(module) ?? []), name])
  }
  const lines = [...byModule].map(
    ([module, names]) => `export { ${names.join(', ')} } from '${module}'`,
  )
  return `${lines.join('\n')}\n`
}

/**
 * The smallest manifest that satisfies every mandatory check.
 *
 * Kept as a literal so a case can override exactly one field and know the rest
 * still describe a packable package.
 *
 * @returns {object} a fresh, mutable `package.json` value.
 */
function baseManifest() {
  return {
    name: 'dsh-obsidian-mem',
    version: '0.1.0',
    main: 'lib/index.js',
    bin: {
      'dsh-obsidian-mem-diagnose': './lib/diagnose-cli.js',
      'dsh-obsidian-mem-review': './lib/curation-cli.js',
    },
    engines: { node: '>=22.22.2' },
    files: [
      'lib',
      'skills/obsidian-mem/SKILL.md',
      'cordis.patch.yml',
      'dsh.plugin.json',
      'README.md',
      'LICENSE',
    ],
  }
}

/** The `dsh.plugin.json` that matches `baseManifest()`. */
function basePluginManifest() {
  return { id: 'dsh-obsidian-mem', version: '0.1.0', main: 'lib/index.js' }
}

/** Write one file, creating its parent directories. */
function write(root, path, content) {
  const full = join(root, path)
  mkdirSync(dirname(full), { recursive: true })
  writeFileSync(full, content)
}

/**
 * Build a fixture tree and run the verifier against it.
 *
 * @param {object} [options] - overrides.
 * @param {object} [options.pkg] - a complete replacement `package.json`.
 * @param {object} [options.plugin] - a complete replacement `dsh.plugin.json`.
 * @param {string[]} [options.omit] - asset paths to leave off disk.
 * @returns {{status:number, stdout:string, stderr:string, root:string}} the run.
 */
function verify(t, options = {}) {
  const root = mkdtempSync(join(tmpdir(), 'obsidian-mem-pack-'))
  t.after(() => rmSync(root, { recursive: true, force: true }))
  const omit = new Set(options.omit ?? [])
  const assets = {
    'lib/index.js': "export const name = 'obsidian-mem'\n",
    'lib/diagnose-cli.js': "#!/usr/bin/env node\nprocess.stdout.write('diagnose fixture')\n",
    'lib/curation-cli.js': "#!/usr/bin/env node\nprocess.stdout.write('review fixture')\n",
    'lib/client.js': '// browser fixture\n',
    'lib/graph-renderer.js': '// worker fixture\n',
    'lib/graph-palette.js': '// graph palette fixture\n',
    'lib/graph-recall.js': '// graph recall fixture\n',
    'lib/graph-data.js': '// graph topology fixture\n',
    'lib/graph-links.js': '// graph link fixture\n',
    'lib/graph-worker.js': '// worker fixture\n',
    'lib/graph-worker.LICENSE': 'ISC\n',
    'lib/tools.js': facadeSource(),
    'lib/tool-registry.js': registrySource(),
    'skills/obsidian-mem/SKILL.md': '---\nname: obsidian-mem\n---\n',
    'cordis.patch.yml': '- insert: []\n',
    'dsh.plugin.json': `${JSON.stringify(options.plugin ?? basePluginManifest(), null, 2)}\n`,
    'README.md': '# fixture\n',
    LICENSE: 'MIT\n',
  }
  for (const [path, content] of Object.entries(assets)) {
    if (!omit.has(path)) write(root, path, content)
  }
  write(root, 'package.json', `${JSON.stringify(options.pkg ?? baseManifest(), null, 2)}\n`)
  const run = spawnSync(process.execPath, [VERIFIER, '--root', root], { encoding: 'utf8' })
  return { status: run.status, stdout: run.stdout ?? '', stderr: run.stderr ?? '', root }
}

test('the shipped manifest passes the pack verifier', () => {
  const run = spawnSync(process.execPath, [VERIFIER], { encoding: 'utf8' })
  assert.equal(run.status, 0, `expected the real manifest to pass:\n${run.stdout}${run.stderr}`)
  assert.match(run.stdout, /verify-pack: OK/)
})

test('a fixture that satisfies the contract passes', (t) => {
  const run = verify(t)
  assert.equal(run.status, 0, run.stdout + run.stderr)
})

test('a version disagreement between the two manifests fails', (t) => {
  const run = verify(t, { plugin: { ...basePluginManifest(), version: '0.2.0' } })
  assert.notEqual(run.status, 0)
  assert.match(run.stdout + run.stderr, /0\.1\.0/)
  assert.match(run.stdout + run.stderr, /0\.2\.0/)
})

test('dropping the portable skill from files fails', (t) => {
  const pkg = baseManifest()
  pkg.files = pkg.files.filter((entry) => entry !== 'skills/obsidian-mem/SKILL.md')
  // `lib` stays, so the only thing missing is the skill asset itself.
  const run = verify(t, { pkg })
  assert.notEqual(run.status, 0)
  assert.match(run.stdout + run.stderr, /skills\/obsidian-mem\/SKILL\.md/)
})

test('a skill asset listed but absent on disk fails', (t) => {
  const run = verify(t, { omit: ['skills/obsidian-mem/SKILL.md'] })
  assert.notEqual(run.status, 0)
  assert.match(run.stdout + run.stderr, /skills\/obsidian-mem\/SKILL\.md/)
})

test('the diagnostic command must be present at the declared bin target', (t) => {
  const missing = verify(t, { omit: ['lib/diagnose-cli.js'] })
  assert.notEqual(missing.status, 0)
  assert.match(missing.stdout + missing.stderr, /lib\/diagnose-cli\.js/)

  const pkg = baseManifest()
  pkg.bin['dsh-obsidian-mem-diagnose'] = '../outside.js'
  const escaping = verify(t, { pkg })
  assert.notEqual(escaping.status, 0)
  assert.match(escaping.stdout + escaping.stderr, /bin/)
})

test('the review command must be present at the declared bin target', (t) => {
  // The tarball's only approval route. A `bin` entry is the one asset no other
  // check would miss: `lib` is a directory entry, so a module inside it packs
  // whether or not the command that runs it is declared.
  const missing = verify(t, { omit: ['lib/curation-cli.js'] })
  assert.notEqual(missing.status, 0)
  assert.match(missing.stdout + missing.stderr, /lib\/curation-cli\.js/)

  const dropped = baseManifest()
  delete dropped.bin['dsh-obsidian-mem-review']
  const undeclared = verify(t, { pkg: dropped })
  assert.notEqual(undeclared.status, 0)
  assert.match(undeclared.stdout + undeclared.stderr, /dsh-obsidian-mem-review/)

  const pkg = baseManifest()
  pkg.bin['dsh-obsidian-mem-review'] = '../outside.js'
  const escaping = verify(t, { pkg })
  assert.notEqual(escaping.status, 0)
  assert.match(escaping.stdout + escaping.stderr, /bin/)
})

test('an entry that is absolute or escapes the package root fails', (t) => {
  for (const entry of ['/etc/passwd', '../outside', 'lib/../../outside', '~/.dsh']) {
    const pkg = baseManifest()
    pkg.files = [...pkg.files, entry]
    const run = verify(t, { pkg })
    assert.notEqual(run.status, 0, `expected ${entry} to be refused`)
    assert.match(
      run.stdout + run.stderr,
      /files/,
      `expected the report to name \`files\` for ${entry}`,
    )
  }
})

test('probe records, dependency trees and pending data can never be packed', (t) => {
  const forbidden = [
    'scratch/notes.md',
    'research/prior-art.md',
    'docs/design.md',
    'test/pack.test.js',
    'node_modules/left-pad/index.js',
    'pending/jobs/job.json',
    '_meta/hot.md',
    '.superpowers/sdd/task-19-brief.md',
    'probe-events.jsonl',
    'lib/pending/queue.json',
    'lib/_meta/.history/tx1/hot.md',
    'lib/index.db',
  ]
  for (const entry of forbidden) {
    const pkg = baseManifest()
    pkg.files = [...pkg.files, entry]
    const run = verify(t, { pkg })
    assert.notEqual(run.status, 0, `expected ${entry} to be refused`)
    assert.match(
      run.stdout + run.stderr,
      new RegExp(entry.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')),
      `expected the report to name ${entry}`,
    )
  }
})

test('a directory entry is expanded, so forbidden files under lib are refused', (t) => {
  const run = verify(t)
  assert.equal(run.status, 0, run.stdout + run.stderr)
  // Same tree, one forbidden file added under the `lib` directory entry.
  const second = verify(t, { pkg: baseManifest() })
  assert.equal(second.status, 0)
  write(second.root, 'lib/pending/queue.json', '{}\n')
  const rerun = spawnSync(process.execPath, [VERIFIER, '--root', second.root], { encoding: 'utf8' })
  assert.notEqual(rerun.status, 0)
  assert.match(rerun.stdout + rerun.stderr, /lib\/pending\/queue\.json/)
})

test('a missing plugin entry, a missing registry or a dropped tool fails', (t) => {
  const missingEntry = verify(t, { omit: ['lib/index.js'] })
  assert.notEqual(missingEntry.status, 0)
  assert.match(missingEntry.stdout + missingEntry.stderr, /lib\/index\.js/)

  // The registration module is its own required file now: shipping the façade
  // without it is a package whose six names resolve to nothing.
  const missingRegistry = verify(t, { omit: ['lib/tool-registry.js'] })
  assert.notEqual(missingRegistry.status, 0)
  assert.match(missingRegistry.stdout + missingRegistry.stderr, /lib\/tool-registry\.js is missing/)

  const pkg = baseManifest()
  const droppedTool = verify(t, { pkg })
  assert.equal(droppedTool.status, 0, droppedTool.stdout + droppedTool.stderr)
  write(droppedTool.root, 'lib/tool-registry.js', registrySource(TOOL_NAMES.slice(0, 5)))
  const rerun = spawnSync(process.execPath, [VERIFIER, '--root', droppedTool.root], {
    encoding: 'utf8',
  })
  assert.notEqual(rerun.status, 0)
  assert.match(rerun.stdout + rerun.stderr, /no longer registers mem_admin/)
})

test('an unstated Node floor fails', (t) => {
  const pkg = baseManifest()
  delete pkg.engines
  const run = verify(t, { pkg })
  assert.notEqual(run.status, 0)
  assert.match(run.stdout + run.stderr, /engines/)
})

// The regression that made this check worth tightening: a bare substring search
// over the registry passes on the module's own header comment and on the
// exported `TOOL_NAMES` list, so it kept passing with every registration deleted.
// These two cases pin the shapes that must be distinguished.
test('the tool check requires a registration site, not a mention', (t) => {
  const run = verify(t)
  assert.equal(run.status, 0, run.stdout + run.stderr)

  // Every one of the six names is still present as a *mention* — in a comment and
  // in an exported list — while `mem_admin` has no `name: '…'` registration.
  write(
    run.root,
    'lib/tool-registry.js',
    [
      '// The six tools: mem_search, mem_read, mem_write, mem_log, mem_brief, mem_admin.',
      `export const TOOL_NAMES = Object.freeze([${TOOL_NAMES.map((name) => `'${name}'`).join(', ')}])`,
      ...TOOL_NAMES.filter((name) => name !== 'mem_admin').map((name) => `  name: '${name}',\n`),
    ].join('\n'),
  )
  const dropped = spawnSync(process.execPath, [VERIFIER, '--root', run.root], { encoding: 'utf8' })
  assert.notEqual(dropped.status, 0, 'a comment and an export list must not satisfy the check')
  assert.match(dropped.stdout + dropped.stderr, /no longer registers mem_admin/)
})

test('a seventh registration fails, because the surface is capped at six', (t) => {
  const run = verify(t)
  assert.equal(run.status, 0, run.stdout + run.stderr)
  write(run.root, 'lib/tool-registry.js', registrySource([...TOOL_NAMES, 'mem_extra']))
  const extra = spawnSync(process.execPath, [VERIFIER, '--root', run.root], { encoding: 'utf8' })
  assert.notEqual(extra.status, 0)
  assert.match(extra.stdout + extra.stderr, /mem_extra/)
})

// Task 11's own failure mode, and the reason the façade is checked separately
// from the registrations: all six tools can be registered correctly while
// `lib/tools.js` publishes none of them, because both entry points import
// through the façade. The package installs, the plugin loads, the surface is
// empty — nothing above this line would notice.
test('a façade that stops publishing a name fails, even with every tool registered', (t) => {
  const run = verify(t)
  assert.equal(run.status, 0, run.stdout + run.stderr)
  write(run.root, 'lib/tools.js', facadeSource(['registerTools']))
  const trimmed = spawnSync(process.execPath, [VERIFIER, '--root', run.root], { encoding: 'utf8' })
  assert.notEqual(trimmed.status, 0)
  assert.match(trimmed.stdout + trimmed.stderr, /no longer re-exports registerTools/)
  // …and the registrations it would have published are still all there.
  assert.doesNotMatch(trimmed.stdout + trimmed.stderr, /no longer registers/)
})

test('a local copy of a published name does not satisfy the façade check', (t) => {
  const run = verify(t)
  assert.equal(run.status, 0, run.stdout + run.stderr)
  // A second, structurally-equal `TOOL_NAMES` is exactly what the façade must not
  // grow: it compiles, it passes type checking, and it drifts.
  write(run.root, 'lib/tools.js', `export const TOOL_NAMES = []\n${facadeSource(['TOOL_NAMES'])}`)
  const copied = spawnSync(process.execPath, [VERIFIER, '--root', run.root], { encoding: 'utf8' })
  assert.notEqual(copied.status, 0, 'a declared copy is not a re-export')
  assert.match(copied.stdout + copied.stderr, /no longer re-exports TOOL_NAMES/)
})

// ---------------------------------------------------------------------------
// Task 6: the real archive, checked as a set rather than a count.
// ---------------------------------------------------------------------------

/**
 * A complete, synthetic archive listing.
 *
 * @param {object} [overrides] - `drop` removes entries, `add` appends them.
 * @returns {string[]} archive paths.
 */
function archiveListing({ drop = [], add = [] } = {}) {
  const base = [
    ...REQUIRED_ENTRIES.map(([path]) => path),
    ...LISTED_LIB.map((path) => `package/${path}`),
  ]
  return [...base.filter((path) => !drop.includes(path)), ...add]
}

/** The lib modules the synthetic listing claims to carry. */
const LISTED_LIB = ['lib/index.js', 'lib/tools.js']

test('a complete archive listing passes the tarball contract', () => {
  assert.deepEqual(verifyTarballEntries(archiveListing(), LISTED_LIB), [])
})

test('a missing required asset is named, and its reason with it', () => {
  const problems = verifyTarballEntries(
    archiveListing({ drop: ['package/README.zh.md'] }),
    LISTED_LIB,
  )
  assert.equal(problems.length, 1)
  assert.match(problems[0], /package\/README\.zh\.md/)
  assert.match(problems[0], /Chinese half/)
})

test('the contract is a set of lib modules, not a frozen count', () => {
  // A new module that ships is fine — this is what a fixed "33 files" would break.
  const grown = archiveListing({ add: ['package/lib/new-module.js'] })
  assert.deepEqual(verifyTarballEntries(grown, [...LISTED_LIB, 'lib/new-module.js']), [])
  // A module on disk that did not ship is the failure that matters.
  const problems = verifyTarballEntries(archiveListing(), [...LISTED_LIB, 'lib/new-module.js'])
  assert.equal(problems.length, 1)
  assert.match(problems[0], /missing lib\/new-module\.js/)
})

test('a packed development tree or vault artefact fails', () => {
  const cases = [
    ['package/test/pack.test.js', /development or runtime state/],
    ['package/docs/superpowers/specs/x.md', /development or runtime state/],
    ['package/lib/pending/queue.json', /vault or data-root state/],
    ['package/lib/foo.lock', /evidence rather than package content/],
  ]
  for (const [entry, pattern] of cases) {
    const problems = verifyTarballEntries(archiveListing({ add: [entry] }), LISTED_LIB)
    assert.equal(problems.length, 1, `${entry} should be refused`)
    assert.match(problems[0], pattern)
  }
})

test('npm 11 reports an array and npm 12 an object keyed by package name', () => {
  // Measured on the two npm majors the CI matrix really runs: npm 11 prints
  // `[{…}]`, and npm 12.1.0 — what the floating `node` leg installs — prints
  // `{"dsh-obsidian-mem": {…}}`. Destructuring the second envelope threw
  // "object is not iterable" (2026-10-31, run 41176291759) and took that leg red,
  // so both envelopes have to read as the same record.
  const record = { filename: 'dsh-obsidian-mem-1.0.0.tgz', files: [{ path: 'package.json' }] }
  assert.deepEqual(parsePackReport(JSON.stringify([record])), record)
  assert.deepEqual(parsePackReport(JSON.stringify({ 'dsh-obsidian-mem': record })), record)
})

test('a pack report with no archive, or more than one, is refused', () => {
  // The verifier joins the reported filename onto the pack destination and then
  // checks that file, so picking one out of an ambiguous report would check an
  // archive npm did not describe. Say the tooling answered something unknown.
  assert.throws(() => parsePackReport(JSON.stringify([])), /reported 0 archive records/)
  assert.throws(() => parsePackReport(JSON.stringify({})), /reported 0 archive records/)
  assert.throws(
    () =>
      parsePackReport(
        JSON.stringify({ a: { filename: 'a-1.0.0.tgz' }, b: { filename: 'b-1.0.0.tgz' } }),
      ),
    /reported 2 archive records/,
  )
  // A record without a filename is not an archive record: the caller would join
  // `undefined` onto the directory and fail as "not on disk", which names the
  // wrong problem.
  assert.throws(
    () => parsePackReport(JSON.stringify([{ files: [] }])),
    /reported 0 archive records/,
  )
})

/**
 * Whether this environment can run npm at all, which is the only way to pack.
 *
 * The probe asks through the SAME resolver the verifier packs with. Spawning bare
 * `npm` is a POSIX assumption: on Windows the executable is `npm.cmd`, which a
 * shell-less `spawnSync` answers with EINVAL, so a host with npm 12.0.2 installed
 * used to skip the real-archive case (measured 2026-11-01 on Windows 11) even
 * though `scripts/verify-tarball.mjs` — which already ran `npm-cli.js` through this
 * Node — packs there fine. A missing npm still answers "not runnable", which is
 * what the environment gate is for.
 *
 * @returns {boolean} true when npm --version exits 0 through `npmCommand()`.
 */
function npmRuns() {
  const { command, args } = npmCommand()
  const probe = spawnSync(command, [...args, '--version'], { encoding: 'utf8' })
  return probe.status === 0
}

/**
 * Why the real-archive case cannot run here, or false when npm is available.
 *
 * This is an environment gate, not a relaxation of the contract: the case packs
 * this checkout and checks the archive npm would publish, and no npm means no
 * archive to check. With a working npm the case runs unchanged and must pass.
 */
const NPM_SKIP = npmRuns()
  ? false
  : 'npm is not runnable in this environment (npm --version does not exit 0), so npm pack cannot produce the archive; expected to pass with npm installed'

test('the npm probe uses the npm JS entry through this Node, never a shell-less .cmd', () => {
  const { command, args } = npmCommand()
  // No npm CLI beside this node: the environment gate exists for that host, and
  // there is no path to pin beyond "the probe does not invent one".
  if (command === 'npm') return
  assert.equal(command, process.execPath)
  assert.deepEqual(args, [
    join(dirname(process.execPath), 'node_modules', 'npm', 'bin', 'npm-cli.js'),
  ])
})

// The archive case needs npm and tar, so it is skipped only where npm itself is absent.
test('the archive this checkout really produces satisfies the contract', { skip: NPM_SKIP }, () => {
  const run = spawnSync(process.execPath, [TARBALL_VERIFIER], { encoding: 'utf8' })
  assert.equal(run.status, 0, run.stdout + run.stderr)
  assert.match(run.stdout, /verify-tarball: OK/)
  // The report has to stay informative without freezing a number.
  assert.match(run.stdout, /lib modules, every required asset present/)
})

// ---------------------------------------------------------------------------
// Task 8: the listing path has to work where `tar` is GNU tar on Windows.
// ---------------------------------------------------------------------------

/**
 * Whether this host has a runnable `tar`.
 *
 * The two cases below exercise the listing *call shape*, not packaging, so a host
 * with no tar at all is the only skip — every CI runner, Windows included, has one.
 *
 * @returns {boolean} true when `tar --version` exits 0.
 */
function tarRuns() {
  return spawnSync('tar', ['--version'], { encoding: 'utf8' }).status === 0
}

const TAR_SKIP = tarRuns()
  ? false
  : 'no runnable tar on PATH, so the archive listing cannot be exercised'

test(
  'the listing reads an archive by relative name, which GNU tar on Windows requires',
  { skip: TAR_SKIP },
  (t) => {
    const directory = mkdtempSync(join(tmpdir(), 'obsidian-mem-tar-'))
    t.after(() => rmSync(directory, { recursive: true, force: true }))
    writeFileSync(join(directory, 'package.json'), '{ "name": "sample" }\n')
    // Relative names plus cwd on purpose: `tar -tf C:\…` makes GNU tar 1.35 read
    // `C:` as a remote host (`Cannot connect to C: resolve failed`, exit 128),
    // the measured Windows pack-gate failure this helper exists to avoid. The
    // fixture archive itself is built the same way for the same reason.
    const packed = spawnSync('tar', ['-czf', 'sample.tgz', 'package.json'], {
      cwd: directory,
      encoding: 'utf8',
    })
    assert.equal(packed.status, 0, packed.stderr || packed.error?.message)
    const listing = listArchive(join(directory, 'sample.tgz'))
    assert.equal(listing.status, 0, listing.error)
    assert.deepEqual(listing.entries, ['package.json'])
  },
)

test("a failed listing names tar's own reason instead of `undefined`", { skip: TAR_SKIP }, (t) => {
  const directory = mkdtempSync(join(tmpdir(), 'obsidian-mem-tar-bad-'))
  t.after(() => rmSync(directory, { recursive: true, force: true }))
  writeFileSync(join(directory, 'not-an-archive.tgz'), 'plain text\n')
  const listing = listArchive(join(directory, 'not-an-archive.tgz'))
  assert.notEqual(listing.status, 0)
  assert.equal(typeof listing.error, 'string')
  assert.ok(listing.error.length > 0, 'a failed listing has to carry a reason')
  assert.doesNotMatch(listing.error, /undefined/, 'the old message rendered as "undefined"')
})

test('the harness peer range opts each measured prerelease tuple in explicitly', () => {
  // A prerelease version only satisfies a range when some comparator in the same
  // set shares its exact major.minor.patch tuple AND carries a prerelease tag.
  // That is node-semver's documented behavior, and it makes a range look wider
  // than it is: `>=0.1.5-rc.1 <0.2.0-0` rejects `0.1.7-rc.2` because no
  // comparator mentions the 0.1.7 tuple. This plugin shipped exactly that bug —
  // `^0.1.5-rc.1 || ^0.2.0-rc.1` excluded `0.1.7-rc.2`, one of the two versions
  // the README lists as measured. The assertion is "the refused version names a
  // tuple the range never opts in", so it stays about the rule rather than about
  // a range string nobody may ever change.
  const pkg = JSON.parse(readFileSync(join(REPO_ROOT, 'package.json'), 'utf8'))
  for (const name of ['@deepseek-ai/dsh-tools', '@deepseek-ai/cordis']) {
    const range = pkg.peerDependencies?.[name]
    assert.equal(typeof range, 'string', `${name} is declared as a peer`)
    const optedIn = new Set(
      new Range(range).set
        .flat()
        .filter((comparator) => comparator.semver?.prerelease?.length)
        .map(
          (comparator) =>
            `${comparator.semver.major}.${comparator.semver.minor}.${comparator.semver.patch}`,
        ),
    )
    for (const version of MEASURED_HOST_VERSIONS[name]) {
      const parsed = parse(version)
      const tuple = `${parsed.major}.${parsed.minor}.${parsed.patch}`
      assert.ok(
        satisfies(version, range) || optedIn.has(tuple),
        `${name} ${range} silently excludes ${version}: no comparator opts in the ${tuple} tuple`,
      )
    }
  }
})
