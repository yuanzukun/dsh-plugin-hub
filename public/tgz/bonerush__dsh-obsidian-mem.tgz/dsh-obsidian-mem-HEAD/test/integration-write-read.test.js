// Task 10: the P1 integration chain — a real vault, the real tool runtime.
//
// Every case builds a throwaway home, repo and vault under `mkdtemp`, binds and
// bootstraps them with the Task 4/5 modules, and then drives the six tools
// through the SHIPPED `ToolRuntime`. The user's real vault, real `~/.dsh` and
// real repositories are never read or written: the plugin's data root is an
// explicit temporary directory except in the two `apply` cases, which point
// `DSH_HOME` at a temporary home first.
//
// What is under test end to end is exactly the P1 claim: `mem_write` lands a
// note in the vault, `mem_search` finds the same id through the index, and
// `mem_read` returns that same note's body and hash. Around that chain the file
// also pins the honesty boundary — Task 11 binds `mem_brief` to the real
// `buildBrief`, and Task 17 makes all six `mem_admin` actions real: a lint
// report traces to vault-relative paths, and a bind refusal reports its reason
// instead of a silent success.
//
// Like `test/tools.test.js`, this file mounts the real `@deepseek-ai/dsh-tools`
// runtime, which is an optional peer dependency DSH provides to an installed
// plugin (`~/.dsh/profiles/node_modules/@deepseek-ai/*` symlinks).
import assert from 'node:assert/strict'
import { execFile } from 'node:child_process'
import { createHash, randomUUID } from 'node:crypto'
import { existsSync } from 'node:fs'
import { mkdir, mkdtemp, readFile, readdir, rm, utimes, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { test } from 'node:test'
import { promisify } from 'node:util'

import { Context } from '@deepseek-ai/cordis'
import toolsPlugin from '@deepseek-ai/dsh-tools'

import { validateConfig } from '../lib/config.js'
import { scanCuration } from '../lib/curation-scan.js'
import { buildCurationView, readCurationView } from '../lib/curation-view.js'
import { apply } from '../lib/index.js'
import { writeMemory } from '../lib/memory.js'
import { resolveDataRoot } from '../lib/paths.js'
import { queueRootFor, readPendingJobs, writeJobAtomic } from '../lib/pending.js'
import { createMemoryServices, registerTools } from '../lib/tools.js'
import { bootstrapVault, resolveBinding } from '../lib/vault.js'
import { makeCurationWorld } from './curation-world.js'

const execFileAsync = promisify(execFile)

const DATE = (() => {
  const now = new Date()
  const pad = (value) => String(value).padStart(2, '0')
  return `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())}`
})()

function gitEnvironment() {
  const env = { ...process.env, GIT_CONFIG_NOSYSTEM: '1', GIT_CONFIG_GLOBAL: '/dev/null' }
  for (const key of [
    'GIT_DIR',
    'GIT_WORK_TREE',
    'GIT_COMMON_DIR',
    'GIT_INDEX_FILE',
    'GIT_OBJECT_DIRECTORY',
  ]) {
    delete env[key]
  }
  return env
}

async function initRepo(dir) {
  await mkdir(dir, { recursive: true })
  await execFileAsync('git', ['-c', 'init.defaultBranch=main', 'init', '-q'], {
    cwd: dir,
    env: gitEnvironment(),
  })
}

/** Vault-relative path → absolute path inside the throwaway vault. */
const at = (vault, relative) => join(vault, ...relative.split('/'))

/** Every file below `root` as `relative path -> sha256`. */
async function hashTree(root) {
  const found = new Map()
  async function walk(directory, prefix) {
    let entries
    try {
      entries = await readdir(directory, { withFileTypes: true })
    } catch {
      return
    }
    for (const entry of entries.sort((left, right) => (left.name < right.name ? -1 : 1))) {
      const relative = prefix === '' ? entry.name : `${prefix}/${entry.name}`
      const absolute = join(directory, entry.name)
      if (entry.isDirectory()) await walk(absolute, relative)
      else if (entry.isFile())
        found.set(
          relative,
          createHash('sha256')
            .update(await readFile(absolute))
            .digest('hex'),
        )
    }
  }
  await walk(root, '')
  return found
}

// ---------------------------------------------------------------------------
// Fixtures
// ---------------------------------------------------------------------------

/**
 * A bound, bootstrapped throwaway project: a temporary home, a real git repo
 * carrying a `.obsidian-mem` pointer, and a vault whose skeleton exists.
 */
async function fixture(t) {
  const root = await mkdtemp(join(tmpdir(), 'obsidian-mem-t10-'))
  const dataRoot = await mkdtemp(join(tmpdir(), 'obsidian-mem-t10-data-'))
  t.after(() =>
    Promise.all([
      rm(root, { recursive: true, force: true, maxRetries: 4 }),
      rm(dataRoot, { recursive: true, force: true, maxRetries: 4 }),
    ]),
  )
  const home = join(root, 'home')
  const repo = join(root, 'repo')
  const vault = join(root, 'vault')
  await mkdir(home, { recursive: true })
  await initRepo(repo)
  const binding = await resolveBinding({ cwd: repo, vaultRoot: vault, home })
  assert.equal(binding.kind, 'bound', `fixture must bind: ${JSON.stringify(binding)}`)
  await bootstrapVault(binding, { dataRoot, home })
  return { root, dataRoot, home, repo, vault, binding }
}

/** A real Cordis context with the shipped ToolRuntime mounted, and no tools. */
async function bareBed(t) {
  const ctx = new Context()
  ctx.provide('systemPrompt', { tools: () => () => {} })
  const fork = ctx.plugin(toolsPlugin)
  await fork
  t.after(async () => {
    await fork.dispose().catch(() => {})
  })
  return ctx
}

/** The same context, with the six tools registered against real services. */
async function memoryBed(t, fixture, config = {}) {
  const ctx = await bareBed(t)
  const services = createMemoryServices({
    config: validateConfig({ vaultPath: fixture.vault, ...config }),
    dataRoot: fixture.dataRoot,
    cwd: fixture.repo,
    home: fixture.home,
  })
  const disposers = registerTools(ctx, services)
  t.after(async () => {
    for (const dispose of disposers) dispose()
    await services.close()
  })
  return { ctx, services }
}

let callSeq = 0

/** Execute one tool with an agent whose session carries `cwd`. */
function call(ctx, name, args, { cwd, signal } = {}) {
  return ctx.tools.execute({
    callId: `call-${(callSeq += 1)}`,
    name,
    arguments: args,
    signal: signal ?? new AbortController().signal,
    agent: {
      session: { header: { id: 'sess-integration', ...(cwd === undefined ? {} : { cwd }) } },
    },
  })
}

/** Assert a call succeeded and hand back its canonical value. */
function value(result, label) {
  assert.equal(
    result.isError,
    false,
    `${label}: ${result.error?.message ?? JSON.stringify(result)}`,
  )
  return result.value
}

/** The plugin's decision ring, as `mem_admin(action="diagnostics")` reports it. */
async function diagnosticsEvents(ctx, f) {
  const listed = value(
    await call(ctx, 'mem_admin', { action: 'diagnostics' }, { cwd: f.repo }),
    'diagnostics',
  )
  return listed.result.events
}

/**
 * What the worker has recorded about one job, or null while it has said nothing.
 *
 * `outcome` matters: the services record the retry itself (`job/retried`) in this
 * same ring, so a lookup by job id alone answers with the request rather than the
 * pass it was supposed to wake.
 */
async function jobEvent(ctx, f, jobId, outcome) {
  const events = await diagnosticsEvents(ctx, f)
  return (
    events.find(
      (event) => event.jobId === jobId && (outcome === undefined || event.outcome === outcome),
    ) ?? null
  )
}

/**
 * The same, polled to a deadline.
 *
 * Nothing awaits a queue-worker pass — the plugin starts it and returns — so the
 * only honest way to observe one is to wait for the decision it records.
 */
async function waitForJobEvent(ctx, f, jobId, outcome, timeoutMs) {
  const deadline = Date.now() + timeoutMs
  for (;;) {
    const found = await jobEvent(ctx, f, jobId, outcome)
    if (found !== null) return found
    if (Date.now() >= deadline) {
      assert.fail(`no diagnostics event named ${jobId} within ${timeoutMs} ms`)
    }
    await new Promise((resolve) => setTimeout(resolve, 25))
  }
}

// ---------------------------------------------------------------------------
// The chain
// ---------------------------------------------------------------------------

test('mem_write → mem_search → mem_read round-trips one note id', async (t) => {
  const f = await fixture(t)
  const { ctx } = await memoryBed(t, f)

  const written = value(
    await call(
      ctx,
      'mem_write',
      {
        type: 'doc',
        title: '调度器改为可插拔后端',
        body: '采用可插拔调度器方案，理由与备选方案见正文。',
      },
      { cwd: f.repo },
    ),
    'mem_write',
  )

  assert.match(
    written.id,
    /^doc-[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/,
  )
  assert.match(written.path, /^Projects\/[^/]+--[0-9a-f]{8}\/Docs\//)
  assert.equal(written.receipt.action, 'write')
  assert.equal(written.receipt.result.status, 'applied')
  assert.equal(written.receipt.afterHashes[written.path].length, 64)

  const found = value(
    await call(ctx, 'mem_search', { query: '调度器' }, { cwd: f.repo }),
    'mem_search',
  )
  const hit = found.hits.find((candidate) => candidate.id === written.id)
  assert.ok(hit, `mem_search must return the written id: ${JSON.stringify(found.hits)}`)
  assert.equal(hit.path, written.path)
  assert.equal(hit.projectId, f.binding.projectId)
  assert.equal(hit.type, 'doc')
  assert.equal(hit.title, '调度器改为可插拔后端')
  assert.ok(hit.scoreSignals.length > 0, 'a hit must explain its ranking')
  assert.match(hit.snippet, /调度器/)

  const read = value(
    await call(ctx, 'mem_read', { path: written.path }, { cwd: f.repo }),
    'mem_read',
  )
  assert.equal(read.id, written.id)
  assert.equal(read.path, written.path)
  assert.equal(read.hash, written.receipt.afterHashes[written.path])
  assert.match(read.body, /采用可插拔调度器方案/)
  assert.equal(read.frontmatter.id, written.id)
  assert.equal(read.frontmatter.project, f.binding.projectId)
  // Provenance: the producing session is recorded from the execution context,
  // not asked of the model (spec §6.4 `session:`, R13).
  assert.equal(read.frontmatter.session, 'sess-integration')

  // The type filter is the closed §6.4 vocabulary: an unknown type is refused
  // rather than silently matching nothing, and the `invariant` input alias
  // resolves to `convention`.
  const badType = await call(ctx, 'mem_search', { query: '调度器', type: 'nope' }, { cwd: f.repo })
  assert.equal(badType.isError, true)
  assert.match(badType.error.message, /type must be one of/)
  const aliased = value(
    await call(ctx, 'mem_search', { query: '调度器', type: 'invariant' }, { cwd: f.repo }),
    'aliased type',
  )
  assert.deepEqual(aliased.hits, [], 'a convention filter must not return the doc note')
})

test('a note written after the first scan is searchable in the same session', async (t) => {
  const f = await fixture(t)
  const { ctx } = await memoryBed(t, f)

  const before = value(
    await call(ctx, 'mem_search', { query: '索引未刷新' }, { cwd: f.repo }),
    'first search',
  )
  assert.deepEqual(before.hits, [], 'the index must be ready and empty before the write')

  value(
    await call(
      ctx,
      'mem_write',
      {
        type: 'gotcha',
        title: '写后必须刷新索引',
        body: '索引未刷新时，同一会话搜不到刚写入的笔记。',
      },
      { cwd: f.repo },
    ),
    'mem_write',
  )

  const after = value(
    await call(ctx, 'mem_search', { query: '索引未刷新' }, { cwd: f.repo }),
    'second search',
  )
  assert.equal(
    after.hits.some((h) => h.title === '写后必须刷新索引'),
    true,
    JSON.stringify(after.hits),
  )
})

test('a repeated idempotencyKey replays the original receipt instead of writing twice', async (t) => {
  const f = await fixture(t)
  const { ctx } = await memoryBed(t, f)
  const args = {
    type: 'gotcha',
    title: '重试幂等',
    body: '同一 key 只写一次。',
    idempotencyKey: 'k-replay-1',
  }

  const first = value(await call(ctx, 'mem_write', args, { cwd: f.repo }), 'first write')
  const replay = value(await call(ctx, 'mem_write', args, { cwd: f.repo }), 'replay write')
  assert.equal(replay.id, first.id)
  assert.equal(replay.path, first.path)
  assert.equal(replay.receipt.txId, first.receipt.txId)

  const notes = await readdir(at(f.vault, `${f.binding.relativeDir}/Pitfalls`))
  assert.deepEqual(
    notes.filter((name) => name.endsWith('.md') && name !== 'index.md'),
    ['重试幂等.md'],
  )
})

test('mem_write updates a known id and refuses an unknown one', async (t) => {
  const f = await fixture(t)
  const { ctx } = await memoryBed(t, f)
  const created = value(
    await call(
      ctx,
      'mem_write',
      {
        type: 'decision',
        title: '调度器改为可插拔后端',
        body: '初始正文。',
      },
      { cwd: f.repo },
    ),
    'create',
  )

  const updated = value(
    await call(
      ctx,
      'mem_write',
      {
        id: created.id,
        type: 'decision',
        title: '调度器改为可插拔后端',
        body: '改后的正文。',
      },
      { cwd: f.repo },
    ),
    'update',
  )
  assert.equal(updated.id, created.id)
  assert.equal(updated.path, created.path)

  const read = value(await call(ctx, 'mem_read', { path: created.path }, { cwd: f.repo }), 'read')
  assert.match(read.body, /改后的正文/)

  const missing = await call(
    ctx,
    'mem_write',
    {
      id: 'dec-00000000-0000-4000-8000-000000000000',
      type: 'decision',
      title: '不存在',
      body: '正文',
    },
    { cwd: f.repo },
  )
  assert.equal(missing.isError, true)
  assert.match(missing.error.message, /carries id/)
})

test('mem_write refuses an unknown type through the real memory layer', async (t) => {
  const f = await fixture(t)
  const { ctx } = await memoryBed(t, f)
  const result = await call(
    ctx,
    'mem_write',
    { type: 'docs', title: '标题', body: '正文' },
    { cwd: f.repo },
  )
  assert.equal(result.isError, true)
  assert.match(result.error.message, /type must be one of/)
})

test('mem_read keeps every path inside the vault jail', async (t) => {
  const f = await fixture(t)
  const { ctx } = await memoryBed(t, f)
  // An existing non-Markdown file, so the not-a-note branch is exercised on a
  // path that really exists: `readNote` resolves the path first, so a missing
  // internal path is reported as missing rather than as internal plumbing.
  const plainText = `${f.binding.relativeDir}/Docs/样例.txt`
  await writeFile(at(f.vault, plainText), '不是笔记\n')
  const cases = [
    ['/etc/passwd', /absolute path is not allowed/],
    ['../../secrets.md', /path traversal is not allowed/],
    [`${f.binding.relativeDir}/Docs/../Conventions/x.md`, /path traversal is not allowed/],
    ['_meta/registry.md', /internal vault plumbing/],
    ['_meta/.history', /internal vault plumbing/],
    [plainText, /not a retrievable Markdown note/],
    ['_meta/log.md', /does not exist|internal vault plumbing/],
  ]
  for (const [path, pattern] of cases) {
    const result = await call(ctx, 'mem_read', { path }, { cwd: f.repo })
    assert.equal(result.isError, true, `${path} must be refused`)
    assert.match(result.error.message, pattern, `${path}: ${result.error.message}`)
  }
  // The refusal above never returned bytes: the file it points at is untouched.
  assert.equal(await readFile(at(f.vault, plainText), 'utf8'), '不是笔记\n')
})

test('a cloud-managed vault root refuses every read path without touching the vault', async (t) => {
  const root = await mkdtemp(join(tmpdir(), 'obsidian-mem-t10-cloud-'))
  const dataRoot = await mkdtemp(join(tmpdir(), 'obsidian-mem-t10-cloud-data-'))
  t.after(() =>
    Promise.all([
      rm(root, { recursive: true, force: true, maxRetries: 4 }),
      rm(dataRoot, { recursive: true, force: true, maxRetries: 4 }),
    ]),
  )
  const home = join(root, 'home')
  const repo = join(root, 'repo')
  // iCloud's documented root: `~/Library/Mobile Documents/`. A dataless file
  // there can hard-fail or trigger a mass download, so R14 refuses the whole
  // vault — reads as well as writes.
  const vault = join(home, 'Library', 'Mobile Documents', 'com~apple~CloudDocs', 'dsh-memory')
  await mkdir(vault, { recursive: true })
  await initRepo(repo)
  const note =
    '---\nid: "doc-11111111-1111-4111-8111-111111111111"\ntype: "doc"\ntitle: "云端笔记"\n---\n云端正文\n'
  await writeFile(join(vault, 'note.md'), note)
  const { ctx } = await memoryBed(t, { home, repo, vault, dataRoot })

  const cases = [
    ['mem_read', { path: 'note.md' }],
    ['mem_read', { path: '_meta/user.md' }],
    ['mem_search', { query: '云端', scope: 'global' }],
    ['mem_search', { query: '云端' }],
    ['mem_admin', { action: 'projects' }],
    ['mem_admin', { action: 'index' }],
    ['mem_write', { type: 'doc', title: '云端写入', body: '正文' }],
  ]
  for (const [name, args] of cases) {
    const result = await call(ctx, name, args, { cwd: repo })
    assert.equal(
      result.isError,
      true,
      `${name} ${JSON.stringify(args)} must refuse a cloud-managed vault`,
    )
    assert.match(result.error.message, /cloud-managed/, `${name}: ${result.error.message}`)
  }
  // Nothing was opened, scanned, locked or written: no index directory, no lock,
  // no receipt, and the note's bytes are exactly as they were.
  assert.deepEqual(await readdir(dataRoot), [])
  assert.equal(await readFile(join(vault, 'note.md'), 'utf8'), note)
})

test('an unbound working directory refuses project scope and writes but still reads globally', async (t) => {
  const f = await fixture(t)
  // A directory that is not a Git repository: it stays unbound even for a write,
  // which is the one shape an implicit first write must not bind (Task 20b). A
  // pointerless *Git* repository is bound by its first write instead; that is
  // covered by `test/auto-bind.test.js`.
  const other = join(f.root, 'unbound')
  await mkdir(other, { recursive: true })
  const { ctx } = await memoryBed(t, f)

  const search = await call(ctx, 'mem_search', { query: '调度器' }, { cwd: other })
  assert.equal(search.isError, true)
  assert.match(search.error.message, /needs a bound project/)

  const global = value(
    await call(ctx, 'mem_search', { query: '调度器', scope: 'global' }, { cwd: other }),
    'global search',
  )
  assert.deepEqual(global.hits, [])

  const write = await call(
    ctx,
    'mem_write',
    { type: 'doc', title: '标题', body: '正文' },
    { cwd: other },
  )
  assert.equal(write.isError, true)
  assert.match(write.error.message, /bound project/)
})

test('mem_log appends exactly one idempotent day-log block', async (t) => {
  const f = await fixture(t)
  const { ctx } = await memoryBed(t, f)
  const args = {
    text: '本轮修好了索引刷新。',
    session: '20260923-120000-abcd',
    idempotencyKey: 'log-key-1',
  }

  const first = value(await call(ctx, 'mem_log', args, { cwd: f.repo }), 'first log')
  const replay = value(await call(ctx, 'mem_log', args, { cwd: f.repo }), 'replayed log')
  assert.equal(first.action, 'log')
  assert.equal(replay.txId, first.txId)

  const logPath = at(f.vault, `${f.binding.relativeDir}/Daily/${DATE}.md`)
  const text = await readFile(logPath, 'utf8')
  assert.equal(text.split('本轮修好了索引刷新。').length - 1, 1, 'the block is written once')
  assert.match(text, /## 20260923-120000-abcd · 会话/)
})

test('mem_log section=hot writes the controlled 进行中 zone, not a day log', async (t) => {
  const f = await fixture(t)
  const { ctx } = await memoryBed(t, f)
  const result = value(
    await call(
      ctx,
      'mem_log',
      {
        text: '正在实现六个工具。',
        session: 'sess-hot',
        section: 'hot',
        idempotencyKey: 'hot-key-1',
      },
      { cwd: f.repo },
    ),
    'hot log',
  )
  assert.equal(result.action, 'hot')

  const hot = await readFile(at(f.vault, `${f.binding.relativeDir}/_meta/hot.md`), 'utf8')
  const start = hot.indexOf('## 进行中')
  const end = hot.indexOf('## 已完成')
  assert.ok(start > -1 && end > start, 'hot.md keeps its three fixed zones')
  assert.match(hot.slice(start, end), /正在实现六个工具。/)
})

test('mem_admin(hot) reports the fill level and compacts a stranded hot file', async (t) => {
  const f = await fixture(t)
  // A small capacity keeps the fixture readable: what is under test is the shape of
  // the answer and the recovery, not the default 9000.
  const { ctx } = await memoryBed(t, f, { hotCapacityChars: 2000 })
  const hotPath = at(f.vault, `${f.binding.relativeDir}/_meta/hot.md`)
  const archivePath = at(f.vault, `${f.binding.relativeDir}/Docs/hot-archive.md`)
  const pointer = (id) =>
    `- [${id}] 已归档 → [[${f.binding.relativeDir}/Docs/hot-archive|热记忆归档]]`

  // Three real entries through the shipped writer …
  for (const name of ['甲甲甲甲', '乙乙乙乙', '丙丙丙丙']) {
    value(
      await call(
        ctx,
        'mem_log',
        { text: `${name}${'记'.repeat(400)}`, session: 'sess-hot', section: 'hot' },
        { cwd: f.repo },
      ),
      'hot log',
    )
  }
  // … then the two things a long-lived vault accumulates by hand: a pointer per
  // archived entry, and text the plugin did not write. Together they push the file
  // over its cap with nothing archivable left in 已完成.
  const ids = [
    'cba84efd-1e75-4741-946d-4474435c2610',
    '11111111-1111-4111-8111-111111111111',
    '22222222-2222-4222-8222-222222222222',
  ]
  let hot = await readFile(hotPath, 'utf8')
  hot = hot.replace(
    '## 已完成\n',
    `## 已完成\n\n${ids.map((id) => pointer(`hot-${id}`)).join('\n')}\n`,
  )
  hot = hot.replace('## 进行中\n', `## 进行中\n\n- 手写填充${'x'.repeat(500)}\n`)
  await writeFile(hotPath, hot, 'utf8')

  const status = value(
    await call(ctx, 'mem_admin', { action: 'hot' }, { cwd: f.repo }),
    'hot status',
  )
  assert.equal(status.result.operation, 'status')
  assert.ok(status.result.used > status.result.capacity, 'the fixture starts over its cap')
  assert.equal(status.result.archivable, 0, 'pointers are never archivable')
  assert.equal(status.result.compactable, 3, 'and 进行中 still holds three movable entries')
  assert.equal(status.result.sections.find((zone) => zone.name === '已完成').pointers, 3)

  // The write the bug made impossible now fails with a message that names the way out.
  const refused = await call(
    ctx,
    'mem_log',
    { text: '溢出', session: 'sess-hot', section: 'hot' },
    { cwd: f.repo },
  )
  assert.equal(refused.isError, true)
  // The tool runtime surfaces the message, not the error code, so the message has
  // to carry both the reason and the route out of it.
  assert.match(refused.error.message, /above the 2000 character cap/)
  assert.match(refused.error.message, /已完成: .*0 moveable/)
  assert.match(refused.error.message, /mem_admin\(action="hot", operation="compact"\)/)

  const compacted = value(
    await call(ctx, 'mem_admin', { action: 'hot', operation: 'compact' }, { cwd: f.repo }),
    'hot compact',
  )
  assert.equal(compacted.result.operation, 'compact')
  assert.ok(compacted.result.moved > 0, 'entries left the injected zone')
  assert.ok(compacted.result.folded > 0, 'and the pointer lines were folded')
  assert.ok(compacted.result.reclaimed > 0, 'so the file came back under its trigger')
  assert.ok(
    compacted.result.used <= compacted.result.trigger,
    `compact must reach the trigger: ${JSON.stringify(compacted.result)}`,
  )
  assert.equal(compacted.result.sections.find((zone) => zone.name === '已完成').pointers, 1)

  // The archive holds the entries and no pointer, and the same write now lands.
  const archive = await readFile(archivePath, 'utf8')
  assert.equal(archive.includes('已归档'), false)
  value(
    await call(
      ctx,
      'mem_log',
      { text: '溢出', session: 'sess-hot', section: 'hot' },
      { cwd: f.repo },
    ),
    'hot log after compact',
  )
  assert.equal((await readFile(hotPath, 'utf8')).includes('溢出'), true)

  // The shared enum admits curation's `scan`; the hot service narrows it again.
  const wrong = await call(ctx, 'mem_admin', { action: 'hot', operation: 'scan' }, { cwd: f.repo })
  assert.equal(wrong.isError, true)
  assert.match(wrong.error.message, /does not accept operation/)
})

test('mem_brief returns the real budgeted brief through the tool runtime', async (t) => {
  const f = await fixture(t)
  const { ctx } = await memoryBed(t, f)
  value(
    await call(
      ctx,
      'mem_log',
      { text: '简报必须出现这一条。', session: 'sess-brief', section: 'hot' },
      { cwd: f.repo },
    ),
    'hot log',
  )
  const brief = value(await call(ctx, 'mem_brief', {}, { cwd: f.repo }), 'mem_brief')

  // Task 11 binds `mem_brief` to the same `buildBrief` the pre-step injection
  // uses, so the P1 `not-ready-in-p1` marker is gone: the tool answers the real
  // brief, with the binding, the hot entry and its own budget report.
  assert.equal(typeof brief.text, 'string')
  assert.ok(brief.text.includes(f.binding.relativeDir))
  assert.ok(brief.text.includes('简报必须出现这一条。'))
  assert.equal(brief.charCount, [...brief.text].length)
  assert.ok(brief.charCount <= 6000, 'the default brief budget is respected')
  assert.equal(brief.indexState.status, 'ready')
  assert.ok(Array.isArray(brief.hotItems) && brief.hotItems.length === 1)
  assert.match(brief.hotHash, /^[0-9a-f]{64}$/)
  assert.match(brief.text, /<!-- brief: \d+\/6000 chars/)
})

test('mem_admin exposes index status, the project list and bind(show)', async (t) => {
  const f = await fixture(t)
  const { ctx, services } = await memoryBed(t, f)

  const projects = value(
    await call(ctx, 'mem_admin', { action: 'projects' }, { cwd: f.repo }),
    'projects',
  )
  assert.equal(projects.action, 'projects')
  assert.deepEqual(
    projects.result.projects.map((row) => row.projectId),
    [f.binding.projectId],
  )

  const status = value(await call(ctx, 'mem_admin', { action: 'index' }, { cwd: f.repo }), 'index')
  assert.equal(status.action, 'index')
  assert.equal(status.result.rebuilt, false)
  assert.ok(['sqlite', 'scan'].includes(status.result.backend))
  assert.equal(status.result.boundProjectId, f.binding.projectId)
  // The tools and a future brief compose from one memoised handle per project.
  const handle = await services.index({ agent: { session: { header: { cwd: f.repo } } } })
  assert.equal(handle.boundProjectId, f.binding.projectId)
  assert.equal(handle.status().boundProjectId, f.binding.projectId)

  const rebuilt = value(
    await call(ctx, 'mem_admin', { action: 'index', rebuild: true }, { cwd: f.repo }),
    'index rebuild',
  )
  assert.equal(rebuilt.result.rebuilt, true)
  assert.equal(rebuilt.result.ready, true)

  const bind = value(await call(ctx, 'mem_admin', { action: 'bind' }, { cwd: f.repo }), 'bind show')
  assert.equal(bind.action, 'bind')
  assert.equal(bind.result.mode, 'show')
  assert.equal(bind.result.status, 'shown')
  assert.equal(bind.result.resolution.kind, 'bound')
  assert.equal(bind.result.resolution.projectId, f.binding.projectId)
  assert.equal(bind.result.resolution.relativeDir, f.binding.relativeDir)
})

test('mem_admin(lint) stays read-only by default and reports real vault facts', async (t) => {
  const f = await fixture(t)
  const { ctx } = await memoryBed(t, f)

  const report = value(await call(ctx, 'mem_admin', { action: 'lint' }, { cwd: f.repo }), 'lint')
  assert.equal(report.action, 'lint')
  assert.equal(report.result.readOnly, true)
  assert.equal(report.result.relativeDir, f.binding.relativeDir)
  assert.equal(report.result.report.status, 'none')
  assert.equal(report.result.index.compared, true)
  // The plugin's own receipts log and registry are permanently excluded.
  assert.equal(
    report.result.findings.some((finding) => finding.path === '_meta/log.md'),
    false,
  )
  assert.ok(report.result.safetyExclusions.length > 0)
  // The dated report note is written only when the caller asks for it.
  await assert.rejects(readFile(at(f.vault, `_meta/Lint Report ${DATE}.md`)), { code: 'ENOENT' })

  const written = value(
    await call(ctx, 'mem_admin', { action: 'lint', report: true }, { cwd: f.repo }),
    'lint report',
  )
  assert.equal(written.result.report.status, 'written')
  const text = await readFile(at(f.vault, written.result.report.path), 'utf8')
  assert.match(text, /<!-- obsidian-mem:generated begin sha256:[0-9a-f]{64} -->/)
  assert.match(text, /永久安全排除/)
})

test('mem_admin(lint, report=true) writes only the report; pruning is its own request', async (t) => {
  const f = await fixture(t)
  const { ctx } = await memoryBed(t, f)
  // One old, unprotected snapshot directory: exactly what the retention policy
  // is allowed to remove, and exactly what a report must never remove.
  const snapshot = at(f.vault, '_meta/.history/tx-old')
  await mkdir(snapshot, { recursive: true })
  await writeFile(join(snapshot, '0__note.md'), '# old snapshot\n')
  const longAgo = new Date(Date.now() - 400 * 24 * 3600_000)
  await utimes(snapshot, longAgo, longAgo)
  await utimes(join(snapshot, '0__note.md'), longAgo, longAgo)

  const before = await hashTree(f.vault)
  const reported = value(
    await call(ctx, 'mem_admin', { action: 'lint', report: true }, { cwd: f.repo }),
    'lint report',
  )
  const after = await hashTree(f.vault)
  const changed = [...new Set([...before.keys(), ...after.keys()])].filter(
    (path) => before.get(path) !== after.get(path),
  )
  assert.deepEqual(
    changed,
    [reported.result.report.path],
    'a report changes exactly the report note',
  )
  assert.equal(existsSync(snapshot), true, 'a report must not prune history')

  const pruned = value(
    await call(ctx, 'mem_admin', { action: 'lint', prune: true }, { cwd: f.repo }),
    'lint prune',
  )
  assert.deepEqual(pruned.result.history.pruned, ['tx-old'], 'the prune is what deletes history')
  assert.equal(existsSync(snapshot), false)

  // Neither flag alone may imply the other.
  const plain = value(await call(ctx, 'mem_admin', { action: 'lint' }, { cwd: f.repo }), 'lint')
  assert.equal(plain.result.readOnly, true)
  assert.equal(plain.result.report.status, 'none')
})

test('mem_admin(promote) creates a Methods note and leaves the source untouched', async (t) => {
  const f = await fixture(t)
  const { ctx } = await memoryBed(t, f)
  const source = value(
    await call(
      ctx,
      'mem_write',
      {
        type: 'convention',
        title: '项目内约定',
        body: '只在本项目成立。\n',
      },
      { cwd: f.repo },
    ),
    'write',
  )

  const before = await readFile(at(f.vault, source.path))
  const promoted = value(
    await call(ctx, 'mem_admin', { action: 'promote', path: source.path }, { cwd: f.repo }),
    'promote',
  )
  assert.equal(promoted.action, 'promote')
  assert.equal(promoted.result.moved, false)
  assert.equal(promoted.result.source, source.path)
  assert.match(promoted.result.path, /^Methods\//)
  const method = await readFile(at(f.vault, promoted.result.path), 'utf8')
  assert.ok(method.includes('来源：'))
  assert.deepEqual(await readFile(at(f.vault, source.path)), before)

  // A source outside the vault is refused by the vault jail, not by a guess.
  const refused = await call(
    ctx,
    'mem_admin',
    { action: 'promote', path: '../../outside.md' },
    { cwd: f.repo },
  )
  assert.equal(refused.isError, true)
})

test('mem_admin(jobs) lists the queue and reports a retry refusal honestly', async (t) => {
  const f = await fixture(t)
  const { ctx } = await memoryBed(t, f)
  const listed = value(await call(ctx, 'mem_admin', { action: 'jobs' }, { cwd: f.repo }), 'jobs')
  assert.equal(listed.action, 'jobs')
  assert.equal(listed.result.status, 'listed')
  assert.deepEqual(listed.result.jobs, [])
  assert.equal(listed.result.failed, 0)

  const missing = value(
    await call(
      ctx,
      'mem_admin',
      { action: 'jobs', jobId: 'job-404', retry: true },
      { cwd: f.repo },
    ),
    'retry',
  )
  assert.equal(missing.result.status, 'refused')
  assert.match(missing.result.message, /job-404/)

  const unnamed = await call(ctx, 'mem_admin', { action: 'jobs', retry: true }, { cwd: f.repo })
  assert.equal(unnamed.isError, true)
  assert.match(unnamed.error.message, /jobId/)
})

test('mem_admin(bind) modes report what they did, or why they refused', async (t) => {
  const f = await fixture(t)
  const { ctx } = await memoryBed(t, f)

  const shown = value(
    await call(ctx, 'mem_admin', { action: 'bind' }, { cwd: f.repo }),
    'bind show',
  )
  assert.equal(shown.result.mode, 'show')
  assert.equal(shown.result.status, 'shown')
  assert.equal(shown.result.resolution.kind, 'bound')

  // `retain` with no origin remote has nothing to confirm.
  const refused = value(
    await call(ctx, 'mem_admin', { action: 'bind', mode: 'retain' }, { cwd: f.repo }),
    'bind retain',
  )
  assert.equal(refused.result.mode, 'retain')
  assert.equal(refused.result.status, 'refused')
  assert.equal(refused.result.resolution.kind, 'conflict')
  assert.equal(refused.result.resolution.reason, 'no-remote')
  assert.equal(typeof refused.result.message, 'string')

  // `fork` separates this worktree's identity without touching the old project.
  const before = await readFile(at(f.vault, `${f.binding.relativeDir}/index.md`), 'utf8')
  const forked = value(
    await call(ctx, 'mem_admin', { action: 'bind', mode: 'fork' }, { cwd: f.repo }),
    'bind fork',
  )
  assert.equal(forked.result.mode, 'fork')
  assert.equal(forked.result.status, 'forked')
  assert.equal(forked.result.previousProjectId, f.binding.projectId)
  assert.notEqual(forked.result.resolution.projectId, f.binding.projectId)
  assert.equal(forked.result.bootstrapped, true)
  assert.equal(forked.result.registryUpdated, true)
  assert.equal(await readFile(at(f.vault, `${f.binding.relativeDir}/index.md`), 'utf8'), before)
  assert.equal(existsSync(at(f.vault, forked.result.resolution.relativeDir)), true)
})

// ---------------------------------------------------------------------------
// The host assembly
// ---------------------------------------------------------------------------

test('apply registers exactly the six tools, and nothing at all when enabled is false', async (t) => {
  const ctx = await bareBed(t)
  assert.equal(apply(ctx, { enabled: false }), undefined)
  assert.deepEqual(ctx.tools.schemas(), [])

  const f = await fixture(t)
  // Task 13 made `apply` install the packaged skill under `DSH_HOME`, so this
  // enabled case points `DSH_HOME` at the fixture — the isolation this file's
  // header already claims for both `apply` cases — and then waits for that
  // install, so the fixture teardown cannot race a still-running file write.
  const dshHome = join(f.root, 'dsh-home')
  const previous = process.env.DSH_HOME
  process.env.DSH_HOME = dshHome
  t.after(() => {
    if (previous === undefined) delete process.env.DSH_HOME
    else process.env.DSH_HOME = previous
  })

  apply(ctx, { vaultPath: f.vault })
  assert.deepEqual(
    ctx.tools
      .schemas()
      .map((schema) => schema.name)
      .sort(),
    ['mem_admin', 'mem_brief', 'mem_log', 'mem_read', 'mem_search', 'mem_write'],
  )

  const installed = join(dshHome, 'skills', 'obsidian-mem', 'SKILL.md')
  const installedManifest = join(dshHome, 'skills', 'obsidian-mem', '.obsidian-mem-manifest.json')
  for (let attempt = 0; attempt < 400 && !existsSync(installedManifest); attempt += 1) {
    await new Promise((resolve) => setTimeout(resolve, 5))
  }
  assert.equal(
    existsSync(installed),
    true,
    'the packaged skill is installed into the isolated DSH home',
  )
  assert.equal(
    existsSync(installedManifest),
    true,
    'and the sync finished before the fixture was torn down',
  )
})

test('apply hands one DSH_HOME-derived data root to the transaction engine and the index', async (t) => {
  const f = await fixture(t)
  const dshHome = join(f.root, 'dsh-home')
  await mkdir(dshHome, { recursive: true })
  const previous = process.env.DSH_HOME
  process.env.DSH_HOME = dshHome
  t.after(() => {
    if (previous === undefined) delete process.env.DSH_HOME
    else process.env.DSH_HOME = previous
  })

  const ctx = await bareBed(t)
  apply(ctx, { vaultPath: f.vault })

  const written = value(
    await call(
      ctx,
      'mem_write',
      {
        type: 'doc',
        title: '装配说明',
        body: '数据根由 DSH_HOME 推导。',
      },
      { cwd: f.repo },
    ),
    'mem_write through apply',
  )
  assert.match(written.path, /^Projects\//)

  const dataRoot = join(dshHome, 'data', 'obsidian-mem')
  assert.equal(
    existsSync(join(dataRoot, 'locks')),
    true,
    'the transaction lock lives under the derived data root',
  )
  assert.equal(
    existsSync(join(dataRoot, 'receipts')),
    true,
    'the receipt store lives under the derived data root',
  )

  const found = value(
    await call(ctx, 'mem_search', { query: '装配说明' }, { cwd: f.repo }),
    'mem_search through apply',
  )
  assert.equal(
    found.hits.some((hit) => hit.id === written.id),
    true,
  )
  assert.equal(
    existsSync(join(dataRoot, 'index')),
    true,
    'the index lives under the same derived data root',
  )
})

test('an explicit job retry wakes the host worker, so a revived job really runs', async (t) => {
  const f = await fixture(t)
  const ctx = await bareBed(t)
  // `apply` derives the queue from `DSH_HOME` in exactly one place, so this case
  // points that variable at the fixture first and then asks the same function where
  // the queue is, instead of guessing the layout a second time.
  const dshHome = join(f.root, 'dsh-home')
  await mkdir(dshHome, { recursive: true })
  const previous = process.env.DSH_HOME
  process.env.DSH_HOME = dshHome
  t.after(() => {
    if (previous === undefined) delete process.env.DSH_HOME
    else process.env.DSH_HOME = previous
  })
  const queueRoot = queueRootFor(resolveDataRoot())
  // A terminally failed job whose project this data root has never registered: the
  // only thing a pass can do with it is defer it, which is what makes the pass
  // itself visible in the decision ring.
  const jobId = 'job-revive-1'
  await writeJobAtomic(queueRoot, {
    jobId,
    sessionId: 'sess-revive',
    projectId: randomUUID(),
    fromSeq: 1,
    toSeq: 2,
    state: 'failed',
    attempts: 3,
    lastError: {
      code: 'truncated',
      message: 'truncated: the output is incomplete',
      at: '2026-09-25T00:00:00.000Z',
    },
    createdAt: '2026-09-25T00:00:00.000Z',
    allowedEvents: [],
    safeInput: 'safe input',
  })

  const dispose = apply(ctx, { vaultPath: f.vault })
  t.after(() => dispose())

  // A terminally failed job is never retried by a pass, and a pass with nothing
  // left to wait for arms no timer — so nothing may touch this job until something
  // wakes the worker. Asserted rather than assumed: a stray pass here would make
  // the positive half of this case pass for the wrong reason.
  await new Promise((resolve) => setTimeout(resolve, 300))
  assert.equal(await jobEvent(ctx, f, jobId), null)

  const retried = value(
    await call(ctx, 'mem_admin', { action: 'jobs', jobId, retry: true }, { cwd: f.repo }),
    'retry',
  )
  assert.equal(retried.result.status, 'retried')
  assert.equal(retried.result.failed, 0)
  assert.equal(retried.result.jobs[0].state, 'pending')
  // The reason survives the revive, and the listing renders the stored object.
  assert.equal(retried.result.jobs[0].lastError, 'truncated: the output is incomplete')

  // Nothing in this case captures a turn or reloads the plugin, so a decision the
  // worker records about this job can only have come from the retry waking it.
  const event = await waitForJobEvent(ctx, f, jobId, 'deferred', 5000)
  assert.equal(event.outcome, 'deferred')
  assert.equal(event.code, 'no-binding')

  const { jobs } = await readPendingJobs(queueRoot)
  assert.equal(jobs[0].state, 'deferred')
  assert.equal(jobs[0].deferredReason, 'no-binding')
})

test('a stored view reaches the real brief through mem_brief, and a changed source falls back', async (t) => {
  const f = await fixture(t)
  const { ctx } = await memoryBed(t, f)

  // Two exact duplicates, one distinct fact nothing has ever retrieved: the
  // duplicate pair is the collapsed group and the third note rules out an
  // implementation that evicts what retrieval has not touched.
  const low = value(
    await call(
      ctx,
      'mem_write',
      { type: 'decision', title: '集成视图', body: '集成视图的第一条事实。' },
      { cwd: f.repo },
    ),
    'first write',
  )
  const twin = value(
    await call(
      ctx,
      'mem_write',
      { type: 'decision', title: '集成视图', body: '集成视图的第一条事实。' },
      { cwd: f.repo },
    ),
    'duplicate write',
  )
  assert.notEqual(low.path, twin.path)

  // Build the view the way the curation action will (Task 5): scan the bound
  // project, then store what the scan produced. The pass is asserted to be complete,
  // so its deadline is set where a busy machine cannot reach it — the shipped 500 ms
  // bound belongs to a hook pass, not to this coverage claim.
  const scan = await scanCuration(f.binding, {
    dataRoot: f.dataRoot,
    home: f.home,
    maxNotes: 1000,
    maxMs: 60_000,
  })
  assert.equal(scan.complete, true)
  const built = await buildCurationView({
    binding: f.binding,
    dataRoot: f.dataRoot,
    scan,
  })
  assert.equal(built.status, 'written')
  const stored = await readCurationView({ dataRoot: f.dataRoot, projectId: f.binding.projectId })
  assert.equal(stored.complete, true)

  const brief = value(await call(ctx, 'mem_brief', {}, { cwd: f.repo }), 'mem_brief')
  const viewLine = brief.text.split('\n').find((line) => line.includes(`\`${low.path}\``))
  assert.ok(viewLine !== undefined, brief.text)
  // The collapsed group is displayed once, and the alternative path is named.
  assert.ok(viewLine.includes(twin.path), viewLine)
  assert.equal(brief.text.split('\n').filter((line) => line.includes(`\`${low.path}\``)).length, 1)
  assert.equal(brief.indexState.status, 'ready')
  assert.ok(brief.charCount <= 6000)

  // Retrieval is untouched: the view never narrows what the tools can reach.
  const found = value(
    await call(ctx, 'mem_search', { query: '集成视图' }, { cwd: f.repo }),
    'search',
  )
  const paths = found.hits.map((hit) => hit.path)
  assert.ok(paths.includes(low.path))
  assert.ok(paths.includes(twin.path))

  // Edit the alternative member; the next brief must take the source path and
  // still surface the fact rather than repeating a stale view line.
  const raw = await readFile(join(f.vault, ...twin.path.split('/')), 'utf8')
  await writeFile(join(f.vault, ...twin.path.split('/')), `${raw}\n补充一行。\n`, 'utf8')
  const fallen = value(await call(ctx, 'mem_brief', {}, { cwd: f.repo }), 'fallback brief')
  assert.ok(fallen.text.includes(twin.path.replace(/\.md$/u, '')), fallen.text)
  assert.equal(fallen.indexState.status, 'ready')
  assert.ok(fallen.charCount <= 6000)
})

// ---------------------------------------------------------------------------
// Task 8 step 1: the same fixture queried before and after the view exists
// ---------------------------------------------------------------------------

/** A second project's identity, so a cross-project claim names a real project. */
const OTHER_PROJECT_ID = '6a1f0b52-0f6e-4a0f-9a0e-1d7a2f4b6c31'

/**
 * Add one note to a second, independent project inside the same vault.
 *
 * The service layer is bound to one working directory, so a cross-project fixture
 * is built through the same shipped writer with a hand-built binding — exactly the
 * shape `test/curation-baseline.test.js` uses. Bootstrap first, so the second
 * project is a real project rather than a directory that happens to hold a file.
 *
 * @param {object} world - the world `makeCurationWorld` returned.
 * @param {object} request - a `writeMemory` request.
 * @returns {Promise<object>} the written identity.
 */
async function writeToOtherProject(world, request) {
  const binding = {
    kind: 'bound',
    projectId: OTHER_PROJECT_ID,
    slug: 'other',
    displayName: 'Other Project',
    schema: 1,
    vaultRoot: world.vault,
    relativeDir: `Projects/other--${OTHER_PROJECT_ID.slice(0, 8)}`,
  }
  await bootstrapVault(binding, { dataRoot: world.dataRoot, home: world.home })
  return writeMemory(binding, request, { dataRoot: world.dataRoot, home: world.home })
}

/**
 * The plan's same-fixture quality comparison (Task 8 step 1).
 *
 * The fixture is queried once with no stored view at all — the status quo the
 * plugin shipped — and once after a real
 * `mem_admin(action="curation", operation="scan")` has written one. Every class the
 * design names is in it: a cross-project twin of a project fact, an old superseded
 * conclusion, an exact duplicate, a same-title/different-number pair, a
 * same-title/different-date pair, a note whose only relation to its query is shared
 * vocabulary, and a cold-but-relevant note: relevant to its own query and recalled
 * by no earlier activity in the fixture. That last one is deliberately *not* framed
 * as "never retrieved" — the pre-scan loop below queries it, and two other classes'
 * queries return it in passing — so the class proves the view keeps a note it has
 * no history for, which is what it asserts.
 *
 * What is compared is the answer retrieval gives, never the view's internals: the
 * retrieved source ids, the brief's character count and omission count, and whether
 * every returned path is still readable. A view that widens, narrows or reorders a
 * project-scoped search, that loses a fact from the brief, or that pushes the brief
 * over its budget is a quality regression and is reported as one — the fixture is
 * the specification and is not adjusted to make a case pass.
 *
 * The per-class rows are emitted as test diagnostics so the measured table can be
 * read from the run's own output rather than restated from memory. A comparison is
 * collected rather than thrown so one failing class cannot hide the others.
 */
test('a stored curation view changes no retrieval answer on the baseline fixture', async (t) => {
  const world = await makeCurationWorld(t)
  const { services } = world

  // --- the fixture ---------------------------------------------------------
  const budgetLow = await services.write({
    type: 'decision',
    title: '预算上限',
    body: '预算是 12 万，超过需要重新审批。',
  })
  // Byte-identical to the first: the same project, type, title and body, a
  // different id and path (a title is a rendering, an id is the identity).
  const budgetTwin = await services.write({
    type: 'decision',
    title: '预算上限',
    body: '预算是 12 万，超过需要重新审批。',
  })
  // Same title, a different number: a near duplicate, never an exact one.
  const budgetNear = await services.write({
    type: 'decision',
    title: '预算上限',
    body: '预算是 13 万，超过需要重新审批。',
  })
  const ruleOld = await services.write({
    type: 'convention',
    title: '导出格式',
    body: '导出时使用 CSV。',
  })
  const ruleNew = await services.write({
    type: 'convention',
    title: '导出格式',
    body: '导出时使用 JSON。',
    supersedes: ruleOld.id,
  })
  // Same title, a different date: the design's "differing dates/numbers" class.
  const windowEarly = await services.write({
    type: 'decision',
    title: '发布窗口',
    body: '发布窗口定在 2026-10-01 开始。',
  })
  const windowLate = await services.write({
    type: 'decision',
    title: '发布窗口',
    body: '发布窗口定在 2026-10-15 开始。',
  })
  // Shares the query's vocabulary and nothing else: high lexical similarity, no
  // answer. Retrieval has to keep returning it exactly as it did before.
  const noise = await services.write({
    type: 'gotcha',
    title: '格式讨论历史',
    body: '这里只记录导出格式的讨论历史，结论与当前导出无关。',
  })
  // The cold-relevant note: relevant to its own query, recalled by no earlier
  // activity in this fixture. Not "never retrieved" — the pre-scan loop above
  // queries it by name, and the superseded and vocabulary queries return it in
  // passing — so the class is about a note the view had no history for.
  const cold = await services.write({
    type: 'decision',
    title: '冷门但相关的约束',
    body: '只在导出时保留原始编号。',
  })
  const other = await writeToOtherProject(world, {
    type: 'decision',
    title: '预算上限',
    body: '预算是 12 万，超过需要重新审批。',
  })
  assert.notEqual(budgetTwin.path, budgetLow.path)
  assert.notEqual(other.path, budgetLow.path)

  /** Readable aliases for the diagnostic table, so a row names notes and not hashes. */
  const aliasById = new Map(
    [
      ['budget-low', budgetLow.id],
      ['budget-twin', budgetTwin.id],
      ['budget-near', budgetNear.id],
      ['rule-old', ruleOld.id],
      ['rule-new', ruleNew.id],
      ['window-early', windowEarly.id],
      ['window-late', windowLate.id],
      ['noise', noise.id],
      ['cold', cold.id],
      ['other-project', other.id],
    ].map(([name, id]) => [id, name]),
  )
  const nameOf = (id) => (typeof id === 'string' ? (aliasById.get(id) ?? id) : '(no-id)')

  const cases = [
    {
      name: 'cross-project',
      query: '预算上限',
      present: [budgetLow.id, budgetTwin.id, budgetNear.id],
      absent: [other.id],
    },
    {
      name: 'superseded',
      query: '导出格式',
      present: [ruleNew.id],
      absent: [ruleOld.id],
    },
    {
      name: 'superseded-with-history',
      query: '导出格式',
      includeHistory: true,
      present: [ruleOld.id, ruleNew.id],
      absent: [],
    },
    {
      name: 'exact-duplicate',
      query: '预算是 12 万',
      present: [budgetLow.id, budgetTwin.id],
      absent: [],
    },
    {
      name: 'near-duplicate',
      query: '预算是 13 万',
      present: [budgetNear.id],
      absent: [],
    },
    {
      name: 'differing-date',
      query: '发布窗口',
      present: [windowEarly.id, windowLate.id],
      absent: [],
    },
    {
      name: 'irrelevant-high-similarity',
      query: '导出格式 讨论历史',
      present: [noise.id],
      absent: [],
    },
    {
      name: 'cold-relevant',
      query: '冷门但相关的约束',
      present: [cold.id],
      absent: [],
    },
  ]

  const query = (one) =>
    services.search({
      query: one.query,
      ...(one.includeHistory === true ? { includeHistory: true } : {}),
    })

  // --- before: no stored view exists yet -----------------------------------
  const briefBefore = await services.brief({})
  assert.equal(briefBefore.indexState.status, 'ready')
  const before = new Map()
  for (const one of cases) {
    const hits = await query(one)
    before.set(one.name, hits)
    // The class's own anchors have to be retrieved *before* anything changed: a
    // query that matches nothing compares two empty lists and proves nothing.
    for (const id of one.present) {
      assert.ok(
        hits.some((hit) => hit.id === id),
        `${one.name}: ${nameOf(id)} must be retrieved before the scan`,
      )
    }
    for (const id of one.absent) {
      assert.equal(
        hits.some((hit) => hit.id === id),
        false,
        `${one.name}: ${nameOf(id)} must be absent before the scan`,
      )
    }
  }

  // --- the view is built by the shipped action, not by a test seam ---------
  const scanned = await services.admin({ action: 'curation', operation: 'scan' })
  assert.equal(scanned.action, 'curation')
  assert.equal(scanned.result.status, 'scanned')
  assert.equal(
    scanned.result.complete,
    true,
    `the pass must cover this fixture: truncated=${scanned.result.truncated}`,
  )
  // The after-brief only proves anything if there really was a view for it to use.
  const foreignView = await readCurationView({
    dataRoot: world.dataRoot,
    projectId: OTHER_PROJECT_ID,
  })
  assert.equal(foreignView, null, 'the view belongs to one project only')
  const ownView = await readCurationView({
    dataRoot: world.dataRoot,
    projectId: scanned.result.projectId,
  })
  assert.equal(ownView?.complete, true, 'the scan must have written a complete view')

  // --- after: the same fixture, the same queries ---------------------------
  const briefAfter = await services.brief({})
  const failures = []
  for (const one of cases) {
    const hits = await query(one)
    const beforeIds = before.get(one.name).map((hit) => hit.id)
    const afterIds = hits.map((hit) => hit.id)
    let readable = 0
    for (const hit of hits) {
      try {
        const note = await services.read({ path: hit.path })
        if (note.path === hit.path) readable += 1
        else failures.push(`${one.name}: mem_read(${hit.path}) answered ${note.path}`)
      } catch (error) {
        failures.push(`${one.name}: mem_read(${hit.path}) threw ${error?.message ?? error}`)
      }
    }
    if (JSON.stringify(afterIds) !== JSON.stringify(beforeIds)) {
      failures.push(
        `${one.name}: retrieval changed: before=[${beforeIds.map(nameOf)}] after=[${afterIds.map(nameOf)}]`,
      )
    }
    for (const id of one.present) {
      if (!afterIds.includes(id))
        failures.push(`${one.name}: ${nameOf(id)} is missing after the scan`)
    }
    for (const id of one.absent) {
      if (afterIds.includes(id)) failures.push(`${one.name}: ${nameOf(id)} must stay absent`)
    }
    const pass =
      !failures.some((line) => line.startsWith(`${one.name}:`)) && readable === hits.length
    t.diagnostic(
      `task8 class=${one.name} query=${JSON.stringify(one.query)} ` +
        `before=[${beforeIds.map(nameOf).join(' ')}] after=[${afterIds.map(nameOf).join(' ')}] ` +
        `chars=${briefBefore.charCount}->${briefAfter.charCount} ` +
        `omitted=${briefBefore.omitted}->${briefAfter.omitted} ` +
        `reads=${readable}/${hits.length} ${pass ? 'PASS' : 'FAIL'}`,
    )
  }
  assert.deepEqual(failures, [], 'a stored view must not change any retrieval answer')

  // --- the brief's own contract --------------------------------------------
  assert.ok(briefBefore.charCount <= 6000, `before: ${briefBefore.charCount}`)
  assert.ok(briefAfter.charCount <= 6000, `after: ${briefAfter.charCount}`)
  assert.ok(
    briefAfter.omitted <= briefBefore.omitted,
    `the view must not omit more than the source path did: ${briefBefore.omitted} -> ${briefAfter.omitted}`,
  )
  // The cold-relevant class's own note is still in the brief by name.
  assert.ok(briefAfter.text.includes(`\`${cold.path}\``), briefAfter.text)
  // The exact pair is one displayed line carrying both paths, and the near pair is
  // two lines: the view collapses only what is byte-identical.
  const lowLines = briefAfter.text
    .split('\n')
    .filter((line) => line.includes(`\`${budgetLow.path}\``))
  assert.equal(lowLines.length, 1, briefAfter.text)
  assert.ok(lowLines[0].includes(budgetTwin.path), lowLines[0])
  assert.notEqual(
    briefAfter.text.split('\n').findIndex((line) => line.includes(`\`${windowEarly.path}\``)),
    -1,
    briefAfter.text,
  )
  assert.notEqual(
    briefAfter.text.split('\n').findIndex((line) => line.includes(`\`${windowLate.path}\``)),
    -1,
    briefAfter.text,
  )
  // The near duplicate keeps its own line: a differing number is not an exact copy.
  const nearLine = briefAfter.text
    .split('\n')
    .find((line) => line.includes(`\`${budgetNear.path}\``))
  assert.ok(nearLine !== undefined, briefAfter.text)
  assert.equal(nearLine.includes(budgetLow.path), false, nearLine)
  assert.equal(
    briefAfter.text.includes(`\`${ruleOld.path}\``),
    false,
    'history is not current guidance',
  )
  assert.equal(
    briefAfter.text.includes(`\`${other.path}\``),
    false,
    'another project is not this brief',
  )
})
