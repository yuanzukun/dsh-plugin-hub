import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'
import { setImmediate } from 'node:timers/promises'
import { runInNewContext } from 'node:vm'
import { test } from 'node:test'

const source = () => readFile(new URL('../lib/client.js', import.meta.url), 'utf8')
/** The served views — the producer side of the class-coverage contract below. */
const viewsSource = () => readFile(new URL('../lib/memory-panel.js', import.meta.url), 'utf8')

/**
 * Drop `//` and block comments while respecting string quotes. The class
 * extraction below must not be satisfied by a class named only in a comment, and
 * — measured — matching quotes across an unstripped comment desynchronises on an
 * apostrophe and finds 67 of the views' 108 classes instead of 108. The views
 * compose some class names at runtime (`'mem-heat-cell is-l' + level`,
 * `'mem-flow-swatch ' + level`, `span('mem-stamp' + …)`), so the extraction
 * splits a quoted literal on spaces and keeps the `mem-*` token; the composed
 * suffixes (`is-l1`, `is-created`, …) are stylesheet variants, covered by the
 * variant assertions in the same test.
 */
function stripComments(text) {
  let stripped = ''
  let index = 0
  let quote = null
  while (index < text.length) {
    const char = text[index]
    if (quote !== null) {
      stripped += char
      if (char === '\\') {
        stripped += text[index + 1] ?? ''
        index += 2
        continue
      }
      if (char === quote) quote = null
      index += 1
      continue
    }
    if (char === '/' && text[index + 1] === '/') {
      while (index < text.length && text[index] !== '\n') index += 1
      continue
    }
    if (char === '/' && text[index + 1] === '*') {
      index += 2
      while (index < text.length && !(text[index] === '*' && text[index + 1] === '/')) index += 1
      index += 2
      continue
    }
    if (char === "'" || char === '"' || char === '`') quote = char
    stripped += char
    index += 1
  }
  return stripped
}

/**
 * The shell's React stand-in. The bundle only receives React through
 * `require('react')`, so a test supplies it. Most tests below need
 * `createElement` alone and scan the source; the behavioural shell tests mount
 * the shell's own components, which use state and refs, so this stand-in keeps
 * one component's state across renders the way the host's renderer does. It is
 * the same hook shape test/panel-ui.test.js uses for the served views — the
 * suite has no React dependency to test the shell against otherwise.
 */
function shellReact() {
  const slots = new Map()
  let current = null
  let cursor = 0
  const slot = () => {
    let state = slots.get(current)
    if (state === undefined) slots.set(current, (state = { values: [] }))
    return state
  }
  return {
    React: {
      createElement: (type, props, ...children) => ({ type, props: { ...props, children } }),
      useState(initial) {
        const { values } = slot()
        const index = cursor++
        // React calls a function initializer instead of storing it; GraphView
        // passes `initialGroups` that way, so the stand-in has to as well.
        if (!(index in values)) values[index] = typeof initial === 'function' ? initial() : initial
        return [
          values[index],
          (next) => {
            values[index] = typeof next === 'function' ? next(values[index]) : next
          },
        ]
      },
      useRef(initial) {
        const { values } = slot()
        const index = cursor++
        if (!(index in values)) values[index] = { current: initial }
        return values[index]
      },
      // The shell's two effects are the stylesheet injection (this context has no
      // `document`) and the served-module import (the vm has no dynamic-import
      // hook). Neither can run here and no assertion below reads them, so the hook
      // is counted for the cursor and nothing else.
      useEffect() {
        cursor += 1
      },
      // GraphView and GraphCanvas memoize their filtered graph and styling; the
      // stand-in recomputes on every render instead, which is what these tests read.
      useMemo(factory) {
        return factory()
      },
    },
    render(component, props) {
      current = component
      cursor = 0
      return component(props)
    },
    // The hook slots one component rendered with. GraphCanvas keeps the model it
    // hands the renderer in a ref (`state.current.model`), which is the seam this
    // suite can read without a browser; `values` is in hook-call order.
    slots: (component) => slots.get(component),
  }
}

/** Register the bundle the way the host does, and return its factory exports. */
async function bundle(react = shellReact().React, globals = {}) {
  const script = await source()
  let module
  const window = {
    __ModuleLoader__: {
      load(value) {
        module = value
      },
    },
  }
  runInNewContext(script, { window, ...globals })
  assert.equal(module.id, 'dsh-obsidian-mem')
  const exports = module.factory((name) => {
    assert.equal(name, 'react')
    return react
  })
  return { script, exports }
}

/** The marked panel stylesheet, exactly the slice the static rules scan. */
function panelCss(script) {
  const start = script.indexOf('/* panel-css:start */')
  const end = script.indexOf('/* panel-css:end */')
  assert.ok(start >= 0 && end > start, 'the panel stylesheet is marked for scanning')
  return script.slice(start, end)
}

/**
 * Every element in a rendered tree, depth-first. Function components are left as
 * elements — call one through the runtime when its output is what you assert.
 */
function nodes(tree) {
  const found = []
  const visit = (value) => {
    for (const node of Array.isArray(value) ? value.flat(Infinity) : [value]) {
      if (node === null || typeof node !== 'object') continue
      found.push(node)
      visit(node.props?.children ?? [])
    }
  }
  visit(tree)
  return found
}

const component = (tree, name) =>
  nodes(tree).find((node) => typeof node.type === 'function' && node.type.name === name)
const byRole = (tree, role) => nodes(tree).find((node) => node.props?.role === role)
const byClass = (tree, className) =>
  nodes(tree).filter(
    (node) =>
      typeof node.props?.className === 'string' &&
      node.props.className.split(' ').includes(className),
  )

/**
 * Mount the shell the way the host does: register the tab, then call the panel
 * component the tab renders through the hook stand-in. `render` re-renders it
 * against the same state, which is how a test sees a state change land.
 */
async function mountShell(sessionId = 'session-shell', globals = {}) {
  const shell = shellReact()
  const { script, exports } = await bundle(shell.React, globals)
  let tab
  const ctx = {
    betterSidebar: {
      registerTab(value) {
        tab = value
        return () => {
          tab = undefined
        }
      },
    },
    inject() {},
    effect(callback) {
      this.dispose = callback()
    },
  }
  exports.apply(ctx)
  const panel = tab.component({ scope: { sessionId }, visible: true })
  return {
    script,
    shell,
    tab,
    render: (overrides) => shell.render(panel.type, { sessionId, visible: true, ...overrides }),
  }
}

test('the shell keeps the graph tab id, retitles it 记忆 and renders the panel', async () => {
  const { exports } = await bundle()
  assert.deepEqual(Array.from(exports.inject), ['betterSidebar'])
  let tab
  const ctx = {
    betterSidebar: {
      registerTab(value) {
        tab = value
        return () => {
          tab = undefined
        }
      },
    },
    inject() {},
    effect(callback) {
      this.dispose = callback()
    },
  }
  exports.apply(ctx)
  assert.equal(tab.id, 'obsidian-mem:graph', 'the tab id is what Better Sidebar keys open tabs by')
  assert.equal(tab.title, '记忆')
  assert.equal(tab.description, '项目的记忆：概览、图谱、检索与健康')
  assert.equal(tab.order, 35)
  assert.equal(tab.single, true)
  assert.equal(typeof tab.component, 'function')
  const view = tab.component({ scope: { sessionId: 'session-case' }, visible: true })
  assert.equal(view.props.sessionId, 'session-case')
  assert.equal(view.props.visible, true)
  ctx.dispose()
  assert.equal(tab, undefined)
})

test('the shell loads the one served module and passes React into it', async () => {
  const { script } = await bundle()
  assert.ok(
    script.includes("import('/obsidian-mem/memory-panel.js')"),
    'dynamic import of the served module',
  )
  // The served module's factory runs behind that dynamic import, and a vm context
  // has no dynamic-import hook to resolve it, so this is source-shape by
  // necessity: it pins the wiring rather than a renamed substring. The argument
  // handed to `createMemoryViews` must be the bundle's own `React` binding — the
  // object `require('react')` returned — not a second global or a re-require.
  assert.match(script, /const React = require\('react'\)/u, 'React comes through require')
  assert.match(
    script,
    /createMemoryViews\(\{\s*React,\s*locale\s*\}\)/u,
    'the served factory receives React and the resolved locale',
  )
  assert.ok(
    script.includes("import('/obsidian-mem/graph-renderer.js')"),
    'the graph renderer stays',
  )
  assert.ok(
    script.includes("import('/obsidian-mem/graph-settings.js')"),
    'the settings module stays',
  )
})

test('the view strip is a real tablist with roving focus and keyboard navigation', async () => {
  const { shell, render } = await mountShell()
  const strip = (overrides = {}) => {
    const element = component(render(), 'MemoryTabs')
    assert.ok(element, 'the shell renders the strip')
    return shell.render(element.type, { ...element.props, ...overrides })
  }
  const tabs = (tree) => nodes(tree).filter((node) => node.props?.role === 'tab')
  const selected = (tree) => tabs(tree).map((node) => node.props['aria-selected'])
  const selectedIndex = () => selected(strip()).indexOf(true)

  let tree = strip()
  assert.equal(nodes(tree).filter((node) => node.props?.role === 'tablist').length, 1)
  assert.deepEqual(
    tabs(tree).map((node) => node.props.id),
    ['obsidian-mem-tab-overview', 'obsidian-mem-tab-graph', 'obsidian-mem-tab-health'],
    'three tabs, 检索 is no longer one of them',
  )
  assert.deepEqual(selected(tree), [true, false, false], 'the mounted view is the selected tab')
  assert.deepEqual(
    tabs(tree).map((node) => node.props.tabIndex),
    [0, -1, -1],
    'roving tabindex: only the selected tab is in the tab order',
  )

  // Roving state is a prop: selecting another tab moves both markers with it.
  tree = strip({ value: 'graph' })
  assert.deepEqual(selected(tree), [false, true, false])
  assert.deepEqual(
    tabs(tree).map((node) => node.props.tabIndex),
    [-1, 0, -1],
  )

  // Keyboard navigation is behaviour, not a source marker: each key must move the
  // shell's selection and the focus, and unhandled keys must leave both alone.
  const focused = []
  const press = (key, index) => {
    const buttons = tabs(strip())
    buttons.forEach((button, position) => {
      button.props.ref({ focus: () => focused.push(position) })
    })
    let prevented = false
    buttons[index].props.onKeyDown({
      key,
      preventDefault: () => {
        prevented = true
      },
    })
    return prevented
  }
  const cases = [
    ['End', 0, 2],
    ['Home', 2, 0],
    ['ArrowRight', 0, 1],
    ['ArrowLeft', 0, 2],
    ['ArrowRight', 2, 0],
    ['ArrowLeft', 2, 1],
  ]
  for (const [key, from, to] of cases) {
    focused.length = 0
    assert.equal(press(key, from), true, key + ' is consumed by the tablist')
    assert.equal(selectedIndex(), to, key + ' selects view ' + to)
    assert.deepEqual(focused, [to], key + ' moves focus to view ' + to)
  }
  focused.length = 0
  assert.equal(press('Tab', 0), false, 'an unhandled key is not consumed')
  assert.equal(selectedIndex(), 1, 'an unhandled key leaves the selection alone')
  assert.deepEqual(focused, [], 'an unhandled key leaves the focus alone')
})

test('the view index is exactly three folder tabs in the reviewed order, without ordinals', async () => {
  const { script } = await bundle()
  const start = script.indexOf('const MEMORY_VIEWS = [')
  const end = script.indexOf(']', start)
  assert.ok(start >= 0 && end > start, 'the view index is a literal list')
  assert.deepEqual(
    [...script.slice(start, end).matchAll(/id: '([a-z]+)'/gu)].map((match) => match[1]),
    ['overview', 'graph', 'health'],
    'three views, 检索 is no longer one of them',
  )
  for (const [id, label, icon] of [
    ['overview', '概览', 'overview'],
    ['graph', '图谱', 'graph'],
    ['health', '健康', 'health'],
  ])
    assert.ok(
      script.includes("{ id: '" + id + "', label: '" + label + "', icon: '" + icon + "' }"),
      'the strip lists ' + label + ' with its icon key',
    )
  assert.equal(script.includes("{ id: 'search'"), false, 'the 检索 view is gone')
  assert.equal(script.includes('ordinal'), false, 'the 01-04 ordinals retired')
  for (const name of ['overview', 'graph', 'search', 'health', 'refresh'])
    assert.ok(
      new RegExp(name + ": (?:'|\\[)").test(script),
      'icon() defines the ' + name + ' glyph',
    )
  for (const marker of ["className: 'mem-tab-icon'", "'aria-hidden': true", 'icon(view.icon)'])
    assert.ok(script.includes(marker), 'each tab carries ' + marker)
  assert.ok(script.includes("className: 'mem-tab-label'"), 'each tab keeps a text label')
  assert.ok(
    script.indexOf("className: 'mem-tab-icon'") < script.indexOf("className: 'mem-tab-label'"),
    'the icon precedes the label',
  )
})

test('every tab controls the one mounted tabpanel', async () => {
  const { script, shell, render } = await mountShell()
  const panel = () => byRole(render(), 'tabpanel')
  assert.ok(panel(), 'the shell mounts one panel')
  assert.equal(nodes(render()).filter((node) => node.props?.role === 'tabpanel').length, 1)
  assert.equal(
    panel().props.id,
    'obsidian-mem-panel',
    'the one mounted panel carries the id the tabs name',
  )
  assert.equal(
    panel().props['aria-labelledby'],
    'obsidian-mem-tab-overview',
    'the panel is labelled by the selected tab',
  )
  const tabs = () => {
    const element = component(render(), 'MemoryTabs')
    return nodes(shell.render(element.type, element.props)).filter(
      (node) => node.props?.role === 'tab',
    )
  }
  for (const tab of tabs())
    assert.equal(tab.props['aria-controls'], panel().props.id, 'every tab points at that panel')
  // A tab click answers in the shell's state: the mounted panel relabels itself
  // for the new view, so the `aria-controls`/`aria-labelledby` pair stays live.
  const graph = tabs().find((node) => node.props.id === 'obsidian-mem-tab-graph')
  graph.props.onClick()
  assert.equal(panel().props['aria-labelledby'], 'obsidian-mem-tab-graph', 'the panel follows')
  assert.deepEqual(
    tabs().map((node) => node.props['aria-selected']),
    [false, true, false],
  )
  // The retired per-view panel ids stay retired; the behaviour above only proves
  // the one panel exists, so this keeps "a second panel per view" from returning.
  assert.equal(
    script.includes("'obsidian-mem-panel-' + view"),
    false,
    'the unmounted per-view panel ids are gone',
  )
})

test('the injected panel CSS is token-only, injected once and motion-gated', async () => {
  const { script } = await bundle()
  const css = panelCss(script)
  assert.equal(/#[0-9a-f]{3,8}\b/iu.test(css), false, 'no hex colour literal')
  assert.equal(/\brgba?\(/u.test(css), false, 'no rgb() colour literal')
  assert.equal(/\bhsla?\(/u.test(css), false, 'no hsl() colour literal')
  const tokens = css.match(/var\(--[a-z0-9-]+/gu) ?? []
  assert.ok(tokens.length > 0, 'the stylesheet reads theme tokens')
  for (const token of tokens) assert.match(token, /var\(--dsw-/u, 'not a --dsw-* alias: ' + token)
  assert.ok(css.includes('prefers-reduced-motion'), 'motion is gated')
  assert.ok(css.includes(':focus-visible'), 'focus is visible')
  assert.ok(script.includes('data-plugin-css="dsh-obsidian-mem/panel"'), 'the sheet is tagged')
  assert.ok(script.includes('querySelector('), 'the injection dedupes by selector')
  assert.ok(
    script.includes('document.head.appendChild(style)'),
    'the sheet lands in head exactly once',
  )
})

test('the graph keeps its canvas and counts what it drew instead of truncating', async () => {
  const { script } = await bundle()
  assert.ok(script.includes("role: 'img', tabIndex: 0"), 'the canvas is still the graph')
  assert.ok(
    script.includes("import('/obsidian-mem/graph-renderer.js')"),
    'the renderer is unchanged',
  )
  // 图谱 draws every node in scope: a "first N nodes" notice is the defect the
  // change removed, so the panel must not carry the vocabulary for it either.
  assert.equal(script.includes('graph.truncated'), false, 'no truncation state is rendered')
  assert.equal(script.includes('仅显示前 '), false, 'the old partial-projection sentence is gone')
  assert.ok(script.includes('graph-count'), 'the drawn count is stated instead')
  assert.ok(script.includes("' 个节点 · '"), 'the count names the node total')
  assert.ok(script.includes("' 条连接'"), 'and the edge total beside it')
  // The route, not the client, is where a cap used to live: pin that it asks for the
  // unscoped projection, because a reintroduced limit would silently hide nodes.
  const route = await readFile(new URL('../lib/graph-route.js', import.meta.url), 'utf8')
  assert.ok(route.includes('index.graph({ scope })'), 'the route requests the whole graph')
  assert.equal(/index\.graph\(\{\s*scope,\s*limit/.test(route), false, 'no cap is passed')
})

test('the top bar is the tab strip itself, with the freshness line and refresh at its tail', async () => {
  const { script } = await bundle()
  // The dedicated masthead is gone: the project name and vault line repeated what
  // the host's own sidebar already says, and the panel is a tab strip over a body.
  // What survives is the one reading no other surface gives — how fresh the
  // figures are — carried small at the strip's tail, plus the refresh control.
  assert.equal(script.includes('function Masthead'), false, 'the separate header is retired')
  assert.equal(script.includes("className: 'mem-masthead'"), false, 'and its element with it')
  for (const marker of [
    "'mem-tabbar'",
    "'mem-tabbar-meta'",
    "'mem-clock'",
    "'mem-refresh'",
    "'数据截至 '",
    "'读取失败'",
    '正在读取…',
    '刷新记忆数据',
    "icon('refresh')",
  ])
    assert.ok(script.includes(marker), 'the strip carries ' + marker)
  // The clock stays guarded exactly as before: a tab that never polls must not
  // show a permanent "正在读取…" that will never resolve.
  assert.ok(
    script.includes('const hasClock = meta !== null || onRefresh !== null'),
    'the clock is withheld when no view reported and the tab has no poll',
  )
  const guard = script.indexOf('const hasClock = meta !== null || onRefresh !== null')
  assert.ok(
    script.indexOf("clock = '正在读取…'") > guard,
    'the fallback clock text sits behind the guard, not in the always-on row',
  )
  // The strip is the first thing in the panel and the search box follows it.
  const shell = script.slice(
    script.indexOf('function MemoryPanel'),
    script.indexOf('function SearchBox'),
  )
  const tabs = shell.indexOf('h(MemoryTabs,')
  const box = shell.indexOf('h(SearchBox,')
  assert.ok(tabs >= 0 && box >= 0, 'both the strip and the box are rendered by the shell')
  assert.ok(tabs < box, 'the tab strip is the top bar; the search box sits under it')
  assert.equal(shell.indexOf("className: 'mem-panel'") < tabs, true, 'the strip opens the panel')
})

test('the stylesheet is a token-only host-type design system with bounded radii', async () => {
  const { script } = await bundle()
  const css = panelCss(script)
  assert.equal(/font-family/iu.test(css), false, 'no custom font-family declaration')
  assert.equal(/serif/iu.test(css), false, 'the serif display face is retired')
  assert.ok(css.includes('var(--dsw-font-'), 'the host font shorthands are used')
  for (const token of [
    'font:var(--dsw-font-s-strong-14)',
    'font:var(--dsw-font-xxs-strong-12)',
    'font:var(--dsw-font-xxs-12)',
    'font:var(--dsw-font-xxxs-11)',
  ])
    assert.ok(css.includes(token), 'the type scale uses ' + token)
  assert.ok(css.includes('letter-spacing:0'), 'no negative tracking')
  assert.ok(css.includes('font-variant-numeric:tabular-nums'), 'numbers are tabular')
  assert.ok(css.includes('line-height:1.6'), 'CJK line-height is 1.55-1.7')

  const radii = [...css.matchAll(/border-radius:\s*([^;}]+)/gu)].map((match) => match[1].trim())
  assert.ok(radii.length > 0, 'the design system declares radii')
  for (const radius of radii)
    for (const value of radius.match(/[0-9.]+/gu) ?? [])
      assert.ok(Number(value) <= 16, 'radius stays 0-16px, found ' + radius)

  const shadows = [...css.matchAll(/box-shadow:\s*([^;}]+)/gu)].map((match) => match[1].trim())
  assert.ok(shadows.length > 0, 'the two token shadows are used')
  for (const shadow of shadows)
    assert.ok(
      ['var(--dsw-shadow-lv1)', 'var(--dsw-shadow-lv3)'].includes(shadow),
      'shadow is lv1 or lv3, found ' + shadow,
    )
  assert.equal(/gradient/iu.test(css), false, 'no gradient furniture')
  assert.equal(/color-scheme/iu.test(css), false, 'the host owns the colour scheme')
})

test('the bundle reads only host tokens on the measured allowlist', async () => {
  const { script } = await bundle()
  const css = panelCss(script)
  // MEASURED 2026-10-29 against the installed DSH build at
  //   C:/Users/bonerush/AppData/Local/Programs/DeepSeek Harness/resources/app.asar
  //   (182,434,783 bytes), where the host defines 405 `--dsw-*:` names. Command shape:
  //   grep -a -o -- '--dsw-[a-z0-9-]*:' '<app.asar>' | sort -u     # -> 405 names
  //   grep -a -o -- '--dsw-font-xs-regular-13:' '<app.asar>'       # -> 0 matches
  // The second command is why this guard exists: the search input's `font:`
  // shorthand once named `--dsw-font-xs-regular-13`, a token this host build does
  // not define, so the shorthand was invalid at computed-value time and the input
  // silently inherited 12px. The host's real 13px token is
  // `--dsw-font-xs-13:13px/20px var(--dsw-font-family)`.
  //
  // CI has no host build to measure against, so this allowlist is a reviewed
  // decision in the same posture as the architecture LAYERS/BUDGETS tables: a name
  // is added only after it is checked against a host build, and its entry is
  // deleted when the stylesheet stops reading it. The scan covers both stylesheet
  // strings in the bundle — the graph token block (3 of these names) and the marked
  // panel sheet (21) — which is exactly the set the measurement cross-checked.
  const verified = [
    '--dsw-alias-bg-base',
    // Added for the plug-in page's settings section (Task 7): measured in the
    // installed 0.2.2-rc.1 build, `grep -a -o -- '--dsw-alias-brand-primary:' app.asar`
    // -> 5 matches; it is the primary-button border token the owner-specified
    // form styling names. Verified against the host build like every entry here.
    '--dsw-alias-brand-primary',
    '--dsw-alias-bg-layer-1',
    '--dsw-alias-bg-layer-2',
    '--dsw-alias-bg-overlay',
    '--dsw-alias-border-l1',
    '--dsw-alias-border-l2',
    '--dsw-alias-interactive-bg-hover',
    '--dsw-alias-label-dimmed',
    '--dsw-alias-label-primary',
    '--dsw-alias-label-secondary',
    '--dsw-alias-label-tertiary',
    '--dsw-alias-link',
    '--dsw-alias-state-business-primary',
    '--dsw-alias-state-error-primary',
    '--dsw-alias-state-success-primary',
    '--dsw-alias-state-warn-primary',
    '--dsw-font-s-strong-14',
    '--dsw-font-xs-13',
    '--dsw-font-xxs-12',
    '--dsw-font-xxs-strong-12',
    '--dsw-font-xxxs-11',
    '--dsw-font-xxxs-strong-11',
    '--dsw-shadow-lv1',
    '--dsw-shadow-lv3',
  ]
  const used = [
    ...new Set([...script.matchAll(/var\((--dsw-[a-z0-9-]+)/gu)].map((match) => match[1])),
  ].sort()
  const unverified = used.filter((name) => !verified.includes(name))
  assert.deepEqual(
    unverified,
    [],
    'host tokens the stylesheet reads but has not been verified against: ' + unverified.join(', '),
  )
  const stale = verified.filter((name) => !used.includes(name))
  assert.deepEqual(
    stale,
    [],
    'allowlist entries the stylesheet no longer uses: ' + stale.join(', '),
  )
  // The one defect this guard was born from, pinned by name: the allowlist alone
  // would accept any other verified token, so the search field's size is asserted
  // at the declaration that broke.
  const input = css.slice(
    css.indexOf('.mem-panel .mem-search-input{'),
    css.indexOf('}', css.indexOf('.mem-panel .mem-search-input{')),
  )
  assert.ok(
    input.includes('font:var(--dsw-font-xs-13)'),
    'the search input uses the host 13px shorthand',
  )
})

test('the settings switch contrasts in both host palettes', async () => {
  const { script } = await bundle()
  // The host's dark palette defines `--dsw-alias-brand-primary` as near-white
  // (#f9fafb). An ON track painted with it plus a hardcoded white knob rendered as
  // one featureless white pill in the reported screenshot. The contract: the ON
  // track stays the brand token, and the ON knob is painted with `bg-base` (white
  // in the light palette, #151517 in the dark one), so the two differ in both.
  const slice = (name) => {
    const at = script.indexOf(name + ':')
    assert.ok(at >= 0, `${name} is declared`)
    const end = script.indexOf('}', at)
    return script.slice(at, end)
  }
  assert.ok(
    slice('switchTrackOn').includes('var(--dsw-alias-brand-primary)'),
    'the ON track is still the host brand token',
  )
  const knobOn = slice('switchKnobOn')
  assert.ok(
    knobOn.includes('var(--dsw-alias-bg-base)'),
    'the ON knob uses the palette-aware background token',
  )
  assert.ok(!knobOn.includes('#ffffff'), 'the ON knob is never hardcoded white')
  // The OFF state keeps the plain white knob on the border track, which is visible
  // on its own in either palette.
  assert.ok(slice('switchKnob').includes('#ffffff'))
})

test('the heat map is a fixed 10px GitHub-style calendar in its own scroll box', async () => {
  const { script } = await bundle()
  const css = panelCss(script)
  // A fixed calendar, not a fluid one: 10px cells on a 2px gap are the same size at
  // every panel width. When the panel is narrower than the calendar the chart scrolls
  // inside its own box, so the page itself never grows a horizontal scrollbar (the
  // round-3 defect: cells shrank into stripes to fit instead).
  const scrollStart = css.indexOf('.mem-panel .mem-heat-scroll{')
  assert.ok(scrollStart >= 0, 'the heat scroll box rule exists')
  const scrollRule = css.slice(scrollStart, css.indexOf('}', scrollStart))
  assert.ok(scrollRule.includes('overflow-x:auto'), 'the calendar scrolls inside its own box')
  assert.equal(scrollRule.includes('overflow-y:auto'), false, 'it is a horizontal scroll only')
  assert.ok(scrollRule.includes('scrollbar-width:thin'), 'a thin scrollbar for the calendar')
  // A panel WIDER than the fixed calendar centres it: the canvas keeps its computed
  // width and the auto inline margins split the leftover space. A narrower panel
  // resolves those margins to zero, so the scroll still starts at the left edge.
  const canvasStart = css.indexOf('.mem-panel .mem-heat-canvas{')
  assert.ok(canvasStart >= 0, 'the canvas rule exists')
  const canvasRule = css.slice(canvasStart, css.indexOf('}', canvasStart))
  assert.ok(canvasRule.includes('margin-inline:auto'), 'the fixed calendar centres: ' + canvasRule)
  const gridStart = css.indexOf('.mem-panel .mem-heat-grid{')
  assert.ok(gridStart >= 0, 'the heat grid rule exists')
  const gridRule = css.slice(gridStart, css.indexOf('}', gridStart))
  for (const declaration of [
    'grid-template-rows:repeat(7,10px)',
    'grid-auto-flow:column',
    'grid-auto-columns:10px',
    'gap:2px',
  ])
    assert.ok(gridRule.includes(declaration), 'the fixed grid declares ' + declaration)
  assert.equal(/minmax\(0,1fr\)/u.test(gridRule), false, 'no width-sharing columns')
  const cellStart = css.indexOf('.mem-panel .mem-heat-cell{')
  assert.ok(cellStart >= 0, 'the heat cell rule exists')
  const cellRule = css.slice(cellStart, css.indexOf('}', cellStart))
  assert.ok(cellRule.includes('width:10px'), 'a heat cell is a fixed 10px: ' + cellRule)
  assert.ok(cellRule.includes('height:10px'), 'and a fixed 10px tall')
  assert.equal(cellRule.includes('aspect-ratio'), false, 'a fixed-size cell needs no aspect ratio')
  // The weekday gutter rides inside the scroll box and sticks to its left edge.
  const weekdaysStart = css.indexOf('.mem-panel .mem-heat-weekdays{')
  assert.ok(weekdaysStart >= 0, 'the weekday gutter rule exists')
  const weekdaysRule = css.slice(weekdaysStart, css.indexOf('}', weekdaysStart))
  assert.ok(weekdaysRule.includes('position:sticky'), 'the weekday labels stick: ' + weekdaysRule)
  assert.ok(weekdaysRule.includes('left:0'))
  assert.ok(
    weekdaysRule.includes('background:var(--dsw-alias-bg-base)'),
    'the sticky gutter paints over the cells it covers',
  )
  // A scrolled month label must not survive above the gutter: the mask is painted
  // upward by one month-row height so "Nov" cannot peek out over "Mon".
  const maskStart = css.indexOf('.mem-panel .mem-heat-weekdays::before{')
  assert.ok(maskStart > weekdaysStart, 'the gutter extends its mask above the grid')
  const maskRule = css.slice(maskStart, css.indexOf('}', maskStart))
  for (const declaration of [
    'content:""',
    'position:absolute',
    'left:0',
    'right:0',
    'top:-14px',
    'height:14px',
    'background:var(--dsw-alias-bg-base)',
  ])
    assert.ok(maskRule.includes(declaration), 'the month-row mask declares ' + declaration)
  const frameStart = css.indexOf('.mem-panel .mem-heat-frame{')
  assert.ok(frameStart >= 0, 'the frame rule exists')
  const frameRule = css.slice(frameStart, css.indexOf('}', frameStart))
  assert.ok(frameRule.includes('grid-template-columns:14px auto'), '14px gutter + auto grid')
  // Month labels above the columns, and the styled tooltip above the cell.
  const monthsStart = css.indexOf('.mem-panel .mem-heat-months{')
  assert.ok(monthsStart >= 0, 'the months row rule exists')
  assert.ok(css.slice(monthsStart, css.indexOf('}', monthsStart)).includes('position:relative'))
  const monthStart = css.indexOf('.mem-panel .mem-heat-month{')
  assert.ok(monthStart >= 0, 'the month label rule exists')
  assert.ok(css.slice(monthStart, css.indexOf('}', monthStart)).includes('position:absolute'))
  const tipStart = css.indexOf('.mem-panel .mem-heat-tip{')
  assert.ok(tipStart >= 0, 'the styled tooltip rule exists')
  const tipRule = css.slice(tipStart, css.indexOf('}', tipStart))
  assert.ok(tipRule.includes('position:absolute'), 'the tooltip floats over the cell: ' + tipRule)
  assert.ok(tipRule.includes('pointer-events:none'), 'the tooltip never steals the hover')
  // The scroll box gets the same thin, token-built scrollbar as the view body.
  assert.ok(
    css.includes('.mem-panel .mem-heat-scroll::-webkit-scrollbar{height:8px'),
    'the webkit heat scrollbar is 8px',
  )
})

test('the heat map keeps the blue business-primary ramp, token-only', async () => {
  const { script } = await bundle()
  const css = panelCss(script)
  for (const level of [
    'color-mix(in srgb,var(--dsw-alias-state-business-primary) 28%,transparent)',
    'color-mix(in srgb,var(--dsw-alias-state-business-primary) 50%,transparent)',
    'color-mix(in srgb,var(--dsw-alias-state-business-primary) 72%,transparent)',
    'color-mix(in srgb,var(--dsw-alias-state-business-primary) 92%,transparent)',
  ])
    assert.ok(css.includes(level), 'the ramp keeps ' + level)
  assert.ok(
    css.includes('color-mix(in srgb,var(--dsw-alias-label-secondary) 16%,transparent)'),
    'the empty cell is the label-secondary 16% mix',
  )
  // The token-only contract is asserted for the whole sheet elsewhere; this pins the
  // heat map's own slice while it was redrawn, since it is the most colour-heavy block.
  const heat = css.slice(css.indexOf('.mem-heat-scroll{'), css.indexOf('.mem-panel .mem-flow{'))
  assert.ok(heat.length > 0, 'the heat slice is present')
  assert.equal(/#[0-9a-f]{3,8}\b/iu.test(heat), false, 'no hex in the heat rules')
  assert.equal(/\brgba?\(/u.test(heat), false, 'no rgb() in the heat rules')
  assert.equal(/\bhsla?\(/u.test(heat), false, 'no hsl() in the heat rules')
})

test('最近变化 is a token-built activity rail, and the flat list rules are gone', async () => {
  const { script } = await bundle()
  const css = panelCss(script)
  // The rail: one continuous 1px border-token line through the 12px node column.
  const groupStart = css.indexOf('.mem-panel .mem-timeline-group{')
  assert.ok(groupStart >= 0, 'the timeline group rule exists')
  const groupRule = css.slice(groupStart, css.indexOf('}', groupStart))
  assert.ok(
    groupRule.includes('grid-template-columns:12px minmax(0,1fr)'),
    'node column + body: ' + groupRule,
  )
  const railStart = css.indexOf('.mem-panel .mem-timeline-group::before{')
  assert.ok(railStart >= 0, 'the rail pseudo-element exists')
  const railRule = css.slice(railStart, css.indexOf('}', railStart))
  assert.ok(railRule.includes('width:1px'), 'the rail is a hairline: ' + railRule)
  // border-l1 is rgba(0,0,0,.04) on the host's light theme — measured invisible in the
  // round-4 capture. A 22% label-secondary mix is still token-only and reads as one
  // continuous hairline on both themes.
  assert.ok(
    railRule.includes(
      'background:color-mix(in srgb,var(--dsw-alias-label-secondary) 22%,transparent)',
    ),
    'the rail is a visible token-only hairline: ' + railRule,
  )
  assert.equal(railRule.includes('--dsw-alias-border-l1'), false, 'not the 4% border token')
  assert.ok(railRule.includes('bottom:0'), 'the rail continues into the next group')
  const nodeStart = css.indexOf('.mem-panel .mem-timeline-node{')
  assert.ok(nodeStart >= 0, 'the node rule exists')
  const nodeRule = css.slice(nodeStart, css.indexOf('}', nodeStart))
  assert.ok(nodeRule.includes('width:12px') && nodeRule.includes('height:12px'), 'a 12px node')
  assert.ok(nodeRule.includes('border-radius:16px'), 'the node is a circle')
  assert.ok(
    nodeRule.includes('background:var(--dsw-alias-state-business-primary)'),
    'the node is a filled accent circle',
  )
  assert.ok(
    nodeRule.includes('border:2px solid var(--dsw-alias-bg-base)'),
    'a bg-base ring separates the node from the rail',
  )
  const dotStart = css.indexOf('.mem-panel .mem-timeline-dot{')
  assert.ok(dotStart >= 0, 'the item dot rule exists')
  const dotRule = css.slice(dotStart, css.indexOf('}', dotStart))
  assert.ok(dotRule.includes('width:6px') && dotRule.includes('height:6px'), 'a 6px item dot')
  // Retired rules must be gone from BOTH sides: a stale rule is dead CSS, and a test
  // that only checked the markup would never notice it.
  for (const retired of ['.mem-panel .mem-recent{', '.mem-panel .mem-dot{'])
    assert.equal(css.includes(retired), false, 'retired rule is gone: ' + retired)
  assert.equal(script.includes('mem-recent-row'), false, 'and its markup with it')
})

test('the panel POST and the route fence share one same-origin header name', async () => {
  // Two files own the two halves of the fence: the served browser module sends the
  // header, and lib/panel-route.js accepts it when the desktop proxy stripped Origin.
  // They cannot import each other (the served module is standalone), so the literals
  // are pinned from BOTH sources here — a rename on either side fails this test
  // instead of only a live 403 in the desktop app.
  const client = await viewsSource()
  const route = await readFile(new URL('../lib/panel-route.js', import.meta.url), 'utf8')
  const nameIn = (text) => /'(x-obsidian-mem-panel)'/u.exec(text)?.[1] ?? null
  const valueIn = (text) => /PANEL_HEADER_VALUE\s*=\s*'([^']+)'/u.exec(text)?.[1] ?? null
  const clientName = nameIn(client)
  const routeName = nameIn(route)
  assert.equal(clientName, 'x-obsidian-mem-panel', 'the served module sends the header literal')
  assert.equal(routeName, clientName, 'the route accepts the same literal it is sent')
  assert.equal(valueIn(client), '1', 'the served module sends the value 1')
  assert.ok(routeName, 'the route half has landed (a missing literal is the failure to fix)')
  assert.equal(valueIn(route), valueIn(client), 'both halves agree on the value')
})

test('the composed overview starts on the body inset, not on a doubled margin', async () => {
  const { script } = await bundle()
  const css = panelCss(script)
  // 概览's first block in the composed shell has no view head above it: the shell
  // passes `onMeta`, so the view drops its own heading and the KPI band is the
  // first thing the body paints. The band's `margin-top:14px` belongs to the
  // standalone layout (a view head or project card above it); left in the composed
  // layout it doubles the body inset — measured 42px from the search field to the
  // KPI card instead of the 28px 健康 and 检索 start from. The first block is
  // zeroed; every later KPI band keeps its separation.
  assert.ok(
    css.includes(
      '.mem-panel .mem-view>.mem-ledger>.mem-block:first-child>.mem-kpiline{margin-top:0}',
    ),
    "the composed overview zeroes the first KPI band's standalone top margin",
  )
  const start = css.indexOf('.mem-panel .mem-kpiline{')
  assert.ok(start >= 0, 'the KPI band rule exists')
  const rule = css.slice(start, css.indexOf('}', start))
  assert.ok(
    rule.includes('margin-top:14px'),
    'every non-first KPI band keeps the standalone separation',
  )
  // Round 2 left 28px from the search field to the first content (10px search-row
  // padding + 18px body inset); the user asked for 16–20px, so the body's top inset
  // dropped to 8px. The two declarations that compose the gap are asserted as a sum:
  // the number the user sees is the contract, not either padding alone.
  const searchStart = css.indexOf('.mem-panel > .mem-searchbar{')
  assert.ok(searchStart >= 0, 'the shell search row rule exists')
  const searchRule = css.slice(searchStart, css.indexOf('}', searchStart))
  const searchPadding = /padding:(\d+)px (\d+)px (\d+)px/u.exec(searchRule)
  assert.ok(searchPadding, 'the search row declares the three-value padding: ' + searchRule)
  const viewStart = css.indexOf('.mem-panel .mem-view{')
  assert.ok(viewStart >= 0, 'the view body rule exists')
  const viewRule = css.slice(viewStart, css.indexOf('}', viewStart))
  const viewPadding = /padding:(\d+)px (\d+)px (\d+)px/u.exec(viewRule)
  assert.ok(viewPadding, '.mem-view declares the three-value padding: ' + viewRule)
  const gap = Number(searchPadding[3]) + Number(viewPadding[1])
  assert.ok(gap >= 16 && gap <= 20, 'search field to first content is ' + gap + 'px (target 16–20)')
})

test('the KPI band spreads its readings evenly and the sparkline stays a bounded shape', async () => {
  const { script } = await bundle()
  const css = panelCss(script)
  // Equal quarters centred each reading inside a fixed 140.75px box, but the readings
  // are not equally wide: the sparkline makes the first cell 120px while "0 个" leaves
  // the last one 29px. The band's own ink therefore measured 25px of space on the left
  // against 69px on the right at a 593px panel, and the row read as shifted left (the
  // reported "左右两边的空隙还是不一致"). space-evenly sizes each cell to its content
  // and divides the remainder equally, so both outer margins and every gap between
  // cells measure the same; the wide layout drops the dividers that would then sit at
  // uneven positions.
  const bandStart = css.indexOf('.mem-panel .mem-kpiline{')
  assert.ok(bandStart >= 0, 'the KPI band rule exists')
  const band = css.slice(bandStart, css.indexOf('}', bandStart))
  assert.ok(band.includes('display:flex'), 'the band lays its cells out as a row: ' + band)
  assert.ok(
    band.includes('justify-content:space-evenly'),
    'and spends equal whitespace between them and at both ends: ' + band,
  )
  const start = css.indexOf('.mem-panel .mem-kpi{')
  assert.ok(start >= 0, 'the KPI cell rule exists')
  const rule = css.slice(start, css.indexOf('}', start))
  assert.ok(rule.includes('align-items:center'), 'the cell rows share one centre line: ' + rule)
  assert.ok(rule.includes('flex:0 0 auto'), 'a cell is its own content, not a quarter: ' + rule)
  const sparkStart = css.indexOf('.mem-panel .mem-kpi-spark{')
  assert.ok(sparkStart >= 0, 'the sparkline rule exists')
  const sparkRule = css.slice(sparkStart, css.indexOf('}', sparkStart))
  assert.ok(sparkRule.includes('width:120px'), 'the shape names its width: ' + sparkRule)
  assert.ok(
    /max-width:100%/u.test(sparkRule),
    'and only gives way inside a narrower folded cell: ' + sparkRule,
  )
})

test('the figure grid declares its column count so a short card fills its row', async () => {
  const { script } = await bundle()
  const css = panelCss(script)
  // A fixed three-column grid rounds its cells up to a whole row, and the cells it never
  // fills show the container's own background: the 热层 card (two cells) printed one
  // solid grey block and the 摘要 card (four cells) printed two. figures() declares how
  // many cells it has, so a short card spans its row; six keep two full rows of three.
  for (const marker of [
    '.mem-figures[data-columns="1"]{grid-template-columns:minmax(0,1fr)}',
    '.mem-figures[data-columns="2"]{grid-template-columns:repeat(2,minmax(0,1fr))}',
    '.mem-figures[data-columns="4"]{grid-template-columns:repeat(4,minmax(0,1fr))}',
  ])
    assert.ok(css.includes(marker), 'the figure grid declares ' + marker)
  const start = css.indexOf('.mem-panel .mem-figure{')
  assert.ok(start >= 0, 'the figure cell rule exists')
  const rule = css.slice(start, css.indexOf('}', start))
  assert.ok(rule.includes('align-items:center'), 'a cell centres its reading: ' + rule)
  assert.ok(rule.includes('text-align:center'), 'and its key line: ' + rule)
})

test('the tab strip is a Chrome-like row: separate roomy leaves, the active page merged', async () => {
  const { script } = await bundle()
  const css = panelCss(script)
  assert.equal(
    /grid-template-columns/iu.test(
      css.slice(css.indexOf('.mem-tabs{'), css.indexOf('}', css.indexOf('.mem-tabs{')) + 1),
    ),
    false,
    '.mem-tabs is not a grid',
  )
  // Chrome's tab strip separates its tabs instead of folding them into one another:
  // a 2px gap, a roomier leaf (36px tall, up to 180px wide) and a 16px glyph. The
  // active leaf still merges into the content surface below the strip.
  const tabs = css.slice(
    css.indexOf('.mem-panel .mem-tabs{'),
    css.indexOf('}', css.indexOf('.mem-panel .mem-tabs{')) + 1,
  )
  for (const marker of ['display:flex', 'gap:2px'])
    assert.ok(tabs.includes(marker), 'the tab row declares ' + marker)
  assert.equal(css.includes('margin-left:-8px'), false, 'tabs no longer overlap')
  // The strip's background and bottom rule belong to the row that carries both the
  // leaves and the freshness tail (`mem-tabbar`), not to the tablist.
  const bar = css.slice(
    css.indexOf('.mem-panel .mem-tabbar{'),
    css.indexOf('}', css.indexOf('.mem-panel .mem-tabbar{')) + 1,
  )
  for (const marker of [
    'background:var(--dsw-alias-bg-layer-1)',
    'border-bottom:1px solid var(--dsw-alias-border-l1)',
    'padding:8px 14px 0',
    'display:flex',
  ])
    assert.ok(bar.includes(marker), 'the top bar declares ' + marker)
  for (const marker of [
    'height:36px',
    'padding:0 14px',
    'max-width:180px',
    'margin-bottom:-1px',
    'border-radius:10px 10px 0 0',
    'border-bottom-color:var(--dsw-alias-bg-base)',
    'background:var(--dsw-alias-bg-base)',
    'box-shadow:var(--dsw-shadow-lv1)',
    'text-overflow:ellipsis',
    'transition:background-color 150ms ease,color 150ms ease',
  ])
    assert.ok(css.includes(marker), 'the tab leaf contains ' + marker)
  assert.ok(
    css.includes('.mem-tab[aria-selected="true"]'),
    'the selected tab is the content surface',
  )
  assert.ok(css.includes('z-index:2'), 'the active tab rides above the strip rule')
  assert.ok(css.includes('min-width:0'), 'tabs may truncate instead of overflowing')
  assert.ok(tabs.includes('flex-wrap:nowrap'), 'the leaves stay on one row')
  // Nothing at the page level scrolls sideways. Two measured drawings are the
  // exceptions, and each scrolls inside its own box: the fixed heat calendar and
  // the composition Sankey, whose English labels are too wide to shrink without
  // truncating them. That split is what keeps a 634px calendar and a full-label
  // Sankey usable in a 320px panel without the body gaining a scrollbar.
  const sideways = [...css.matchAll(/([^{}]+)\{[^}]*overflow-x:(?:auto|scroll)/gu)].map((match) =>
    match[1].split('\n').at(-1).trim().replace(/^'|'$/gu, ''),
  )
  assert.deepEqual(
    sideways,
    ['.mem-panel .mem-heat-scroll', '.mem-panel .mem-sankey-scroll'],
    'only the heat calendar and the Sankey scroll sideways, each inside its own box',
  )
  for (const marker of ['flex:0 1 auto', 'align-items:flex-end'])
    assert.ok(css.includes(marker), 'the tab row contains ' + marker)
  // The 44px click target is the strip's 8px top padding plus the 36px leaf: the
  // leaf extends its own hit area upward by that padding so the whole 44px is
  // clickable, while the drawn leaf stays 36px tall.
  assert.ok(css.includes('top:-8px'), 'the leaf extends its own hit area upward')
  assert.ok(css.includes('bottom:0'), 'the hit extension reaches the content surface')
  assert.ok(
    css.includes('.mem-tab:hover{background:var(--dsw-alias-interactive-bg-hover)'),
    'the resting leaf lifts on hover',
  )
  const icon = css.slice(
    css.indexOf('.mem-tab-icon{'),
    css.indexOf('}', css.indexOf('.mem-tab-icon{')) + 1,
  )
  assert.ok(icon.includes('width:16px') && icon.includes('height:16px'), 'the glyph is 16px')
  // The narrow-panel step is 374px, not 359: measured, the 359 breakpoint made 360px
  // WORSE than 359px, because the icon came back and ate 22px of a strip that gained
  // only 6 (label widths 19/24 at 360 against 24/24 at 359). The step also tightens
  // the leaves' padding and the row's gap, which is what clears truncation across
  // the whole 280-374 band instead of only below it.
  for (const marker of [
    '@container (max-width:374px)',
    '.mem-tab-icon{display:none}',
    '.mem-tab{padding:0 8px;gap:4px}',
  ])
    assert.ok(css.includes(marker), 'the narrow-panel step contains ' + marker)
  assert.equal(
    css.includes('@container (max-width:359px)'),
    false,
    'the 359 step is gone: it was the defect, not the fallback',
  )
  // The KPI band folds to 2x2 at 559px. With content-sized cells the four readings plus
  // their insets need 385px in Chinese and 439px in English; at a 560px panel the band
  // still has 28.9px and 18.3px of whitespace to distribute, and at the 446px panel that
  // prompted the earlier fold it has none at all. The folded grid restores equal
  // quarters, their dividers and the figure grid's own 2x2 fallback (a four-column
  // figures row would otherwise print two grey holes).
  for (const marker of [
    '@container (max-width:559px)',
    '.mem-kpiline{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));justify-content:normal}',
    '.mem-kpi:nth-child(2){border-left:1px solid var(--dsw-alias-border-l1)}',
    '.mem-kpi:nth-child(3){border-top:1px solid var(--dsw-alias-border-l1)}',
    '.mem-kpi:nth-child(4){border-left:1px solid var(--dsw-alias-border-l1);border-top:1px solid var(--dsw-alias-border-l1)}',
    '.mem-figures[data-columns="4"]{grid-template-columns:repeat(2,minmax(0,1fr))}',
  ])
    assert.ok(css.includes(marker), 'the KPI fold contains ' + marker)
  assert.equal(
    css.includes('@container (max-width:339px)'),
    false,
    'the 339 fold is gone: it folded only after four cells had already run into each other',
  )
  // The language switch is a 28px square glyph button now, not a two-letter badge:
  // "ZH" printed on the button read as the panel's current state rather than as the
  // action a click takes, so the switch carries the translate mark instead.
  const localeRule = css.slice(
    css.indexOf('.mem-panel .mem-locale{'),
    css.indexOf('}', css.indexOf('.mem-panel .mem-locale{')) + 1,
  )
  for (const marker of ['width:28px', 'height:28px', 'padding:0'])
    assert.ok(localeRule.includes(marker), 'the language switch is a square button: ' + marker)
  assert.equal(
    localeRule.includes('font:var(--dsw-font'),
    false,
    'the button no longer sets type for a printed EN/ZH badge',
  )
  assert.ok(
    css.includes('.mem-panel .mem-locale svg{width:16px;height:16px}'),
    'the glyph is drawn 16px',
  )
})

test('the shell keeps one persistent search box between the tab strip and the view body', async () => {
  const { script, shell, render } = await mountShell('session-search')
  const panel = () => render()
  const boxElement = (tree = panel()) => component(tree, 'SearchBox')
  const boxTree = (overrides = {}) => {
    const element = boxElement()
    assert.ok(element, 'the shell renders the search box itself, not a view')
    return shell.render(element.type, { ...element.props, ...overrides })
  }
  const input = () => byClass(boxTree(), 'mem-search-input')[0]
  const form = (tree = boxTree()) => nodes(tree).find((node) => node.type === 'form')

  // The box is shell chrome: one form directly between the strip and the one view
  // body, so it survives every tab and a tab only replaces the mounted view.
  const tree = panel()
  const positioned = nodes(tree)
  const stripNode = component(tree, 'MemoryTabs')
  const boxNode = boxElement(tree)
  assert.ok(positioned.indexOf(stripNode) < positioned.indexOf(boxNode), 'tab strip → search box')
  assert.ok(
    positioned.indexOf(boxNode) < positioned.indexOf(byRole(tree, 'tabpanel')),
    'search box → the one tabpanel',
  )
  assert.equal(form().props.className, 'mem-searchbar')
  const box = boxTree()
  assert.equal(nodes(box).filter((node) => node.props?.role === 'search').length, 1)
  for (const hook of [
    'mem-search-field',
    'mem-search-icon',
    'mem-search-input',
    'mem-search-submit',
  ])
    assert.equal(byClass(box, hook).length, 1, 'the box has one ' + hook)
  assert.equal(byClass(box, 'mem-search-clear').length, 0, 'no clear control while empty')

  // The shell owns the draft: typing is one shell state change and the field is
  // controlled by it — the box never grows a state of its own.
  input().props.onChange({ target: { value: '绑定' } })
  assert.equal(boxElement().props.value, '绑定', 'typing updates the shell-owned draft')
  assert.equal(input().props.value, '绑定', 'the field renders that draft back')
  assert.equal(byClass(boxTree(), 'mem-search-clear').length, 1, 'the clear control appears')

  // Escape is one of the three exits: it empties the field.
  let prevented = 0
  input().props.onKeyDown({
    key: 'Escape',
    preventDefault: () => {
      prevented += 1
    },
  })
  assert.equal(prevented, 1, 'Escape is consumed by the box')
  assert.equal(boxElement().props.value, '', 'Escape empties the shell-owned draft')
  assert.equal(byClass(boxTree(), 'mem-search-clear').length, 0)

  // The clear control is the same exit and hands the caret back to the field.
  input().props.onChange({ target: { value: 'x' } })
  let focused = 0
  input().props.ref.current = {
    focus: () => {
      focused += 1
    },
  }
  byClass(boxTree(), 'mem-search-clear')[0].props.onClick()
  assert.equal(focused, 1, 'the clear control hands focus back to the field')
  assert.equal(boxElement().props.value, '', 'the clear control empties the draft too')

  // Clicking anywhere in the field puts the caret in the input: the icon and the
  // padding are part of one control, not decoration. A click that starts on a
  // button (the clear control) is excluded — it owns its own focus handoff.
  let fieldFocused = 0
  input().props.ref.current = {
    focus: () => {
      fieldFocused += 1
    },
  }
  const field = () => byClass(boxTree(), 'mem-search-field')[0]
  field().props.onClick({ target: { closest: () => null } })
  assert.equal(fieldFocused, 1, 'a click on the field focuses the input')
  field().props.onClick({ target: { closest: () => ({ tagName: 'BUTTON' }) } })
  assert.equal(fieldFocused, 1, 'a click that starts on a button does not steal its focus')

  const tab = (id) => {
    const element = component(panel(), 'MemoryTabs')
    return nodes(shell.render(element.type, element.props)).find(
      (node) => node.props?.id === 'obsidian-mem-tab-' + id,
    )
  }
  tab('graph').props.onClick()
  assert.ok(component(panel(), 'GraphView'), '图谱 mounts the graph view')
  assert.ok(boxElement(), 'the search box survives the tab switch')

  // Submitting enters search mode: the shell replaces the view body with the
  // results page. The served module cannot load in this context, so the observable
  // is the body swap; the props crossing that seam are pinned in the source below.
  const submit = () => {
    let submitted = 0
    form().props.onSubmit({
      preventDefault: () => {
        submitted += 1
      },
    })
    return submitted
  }
  input().props.onChange({ target: { value: '绑定' } })
  assert.equal(submit(), 1, 'the form submit is consumed by the shell')
  assert.equal(component(panel(), 'GraphView'), undefined, 'a submitted query replaces the body')
  // A tab click is the second exit: search mode drops even when the tab is the one
  // that is already mounted. The typed text survives a tab click by design, so the
  // field is emptied first for the empty-query guard below.
  tab('graph').props.onClick()
  assert.ok(component(panel(), 'GraphView'), 'a tab click leaves search mode')
  input().props.onKeyDown({ key: 'Escape', preventDefault: () => {} })
  assert.equal(boxElement().props.value, '', 'Escape empties the field')
  // An empty query is not a search (design §6.3): no request, no mode change.
  assert.equal(submit(), 1)
  assert.ok(component(panel(), 'GraphView'), 'an empty query does not enter search mode')
  // Escape is the third exit, from the input itself.
  input().props.onChange({ target: { value: '绑定' } })
  submit()
  assert.equal(component(panel(), 'GraphView'), undefined)
  input().props.onKeyDown({ key: 'Escape', preventDefault: () => {} })
  assert.ok(component(panel(), 'GraphView'), 'Escape leaves search mode')

  // The served view is behind the dynamic import a vm context cannot resolve, so
  // the props contract across that seam is the source-shape seam: what it pins is
  // that the results page mounts with the shell's own state plus its callbacks,
  // never an internally owned form. panel-ui.test.js mounts the view side.
  const shellSource = script.slice(
    script.indexOf('function MemoryPanel'),
    script.indexOf('function SearchBox'),
  )
  for (const prop of [
    'sessionId',
    'query',
    'scope',
    'type',
    'status',
    'limit',
    'visible',
    // The two callbacks the single-owner model depends on (I6/I7): the view
    // reports filter changes and page-size changes upward instead of owning them.
    'onFilter',
    'onLimit',
    'onClose',
  ])
    assert.ok(
      new RegExp('SearchView,\\s*\\{[^}]*\\b' + prop + '\\b', 'u').test(shellSource),
      'SearchView receives ' + prop + ' from the shell',
    )
  // 检索 is no longer a tab, so polling keeps to the two polling reads.
  assert.ok(
    script.includes("const polling = view === 'overview' || view === 'health'"),
    'polling covers 概览 and 健康 only',
  )
  assert.equal(script.includes("view === 'search'"), false, 'no search tab branch survives')
})

test('the search box styles stay token-built and clear of hex literals', async () => {
  const { script } = await bundle()
  const css = panelCss(script)
  for (const hook of [
    'mem-searchbar',
    'mem-search-field',
    'mem-search-icon',
    'mem-search-input',
    'mem-search-clear',
  ]) {
    assert.match(css, new RegExp('\\.' + hook + '(?![a-z0-9-])', 'u'), 'styled: ' + hook)
  }
  for (const hook of ['mem-search-field', 'mem-search-icon', 'mem-search-input']) {
    const start = css.indexOf('.mem-panel .' + hook + '{')
    assert.ok(start >= 0, 'the shell search rule exists: ' + hook)
    const rule = css.slice(start, css.indexOf('}', start))
    assert.ok(rule.includes('var(--dsw-'), hook + ' is token-built')
  }
  const field = css.slice(
    css.indexOf('.mem-panel .mem-search-field{'),
    css.indexOf('}', css.indexOf('.mem-panel .mem-search-field{')),
  )
  assert.ok(field.includes('height:40px'), 'the shell field is 40px tall')
  assert.match(field, /border-radius:\s*10px/u, 'the shell field is a 10px rounded box')
})

test('every class the redesigned views consume is styled in the one stylesheet', async () => {
  const { script } = await bundle()
  const css = panelCss(script)
  const hooks = [
    'mem-panel',
    'mem-display',
    'mem-tabbar',
    'mem-tabbar-meta',
    'mem-clock',
    'mem-refresh',
    // Round 2: the in-panel language switch the shell paints beside the clock.
    'mem-locale',
    'mem-tabs',
    'mem-tab',
    'mem-tab-icon',
    'mem-tab-label',
    'mem-view',
    'mem-ledger',
    'mem-sr',
    'mem-stamp',
    'mem-viewhead',
    'mem-viewhead-title',
    'mem-viewhead-meta',
    'mem-actions',
    'mem-action',
    'mem-btn',
    'mem-btn-primary',
    'mem-btn-quiet',
    'mem-label',
    'mem-meta',
    'mem-warn',
    'mem-notice',
    'mem-action-status',
    // Round 5: the per-mutation outcome line drawn in the owning section, and the hot
    // card's trigger state beside its 整理热层 action.
    'mem-action-result',
    'mem-hot-state',
    'mem-status',
    'mem-empty',
    'mem-skeleton',
    'mem-more',
    'mem-kpiline',
    'mem-kpi',
    'mem-kpi-label',
    'mem-kpi-line',
    'mem-kpi-value',
    'mem-kpi-unit',
    'mem-kpi-spark',
    'mem-summary',
    'mem-summary-item',
    'mem-summary-value',
    // The 概览 charts landed with the chart redesign and are what this list is
    // really for: each hook is emitted by `lib/memory-panel.js` and has a rule in
    // the stylesheet, so a renamed class in either place fails here.
    // The heat map is a fixed GitHub-style calendar now: a horizontal scroll box, a
    // computed canvas, the months row, the sticky weekday gutter, the tooltip and the
    // bottom legend. The cell/legend classes survive their redraw.
    'mem-heat',
    'mem-heat-scroll',
    'mem-heat-canvas',
    'mem-heat-months',
    'mem-heat-month',
    'mem-heat-frame',
    'mem-heat-weekdays',
    'mem-heat-weekday',
    'mem-heat-grid',
    'mem-heat-cell',
    'mem-heat-tip',
    'mem-heat-hint',
    'mem-heat-legend',
    'mem-heat-legend-label',
    'mem-heat-swatch',
    'mem-flow',
    'mem-flow-svg',
    'mem-flow-created',
    'mem-flow-updated',
    'mem-flow-zero',
    'mem-flow-legend',
    'mem-flow-swatch',
    'mem-flow-legend-label',
    // 标签频率 is a squarified treemap now: area is the count, and each tile prints
    // its own digits. The five `mem-freq*` bar classes are retired with their
    // producer (the ranked list they styled is gone, not merely unused).
    'mem-treemap',
    'mem-treemap-tile',
    'mem-treemap-name',
    'mem-treemap-value',
    // 健康's charts: the gauge band, the figure grid, and the two bar shapes.
    'mem-gauges',
    'mem-gauge',
    'mem-gauge-label',
    'mem-gauge-value',
    'mem-gauge-track',
    'mem-gauge-fill',
    'mem-figures',
    'mem-figure',
    'mem-figure-value',
    'mem-figure-key',
    'mem-stackbar',
    'mem-stackbar-track',
    'mem-stackbar-seg',
    'mem-stackbar-legend',
    'mem-stackbar-row',
    'mem-bars',
    'mem-bar-row',
    'mem-bar-name',
    'mem-bar-value',
    'mem-chart-empty',
    'mem-block',
    'mem-section',
    'mem-section-head',
    'mem-section-meta',
    'mem-comp',
    'mem-bar-track',
    'mem-bar-fill',
    'mem-comp-legend',
    'mem-comp-row',
    'mem-comp-dot',
    'mem-comp-name',
    'mem-comp-value',
    'mem-comp-pct',
    // `mem-stamps` is retired with its producer: the status distribution is one line
    // at the composition legend's tail now, not a second chip row.
    'mem-comp-status',
    'mem-comp-status-label',
    'mem-comp-status-value',
    // The 构成 Sankey: an SVG drawn only from the real type×status joint counts; the
    // bar above stays as the fallback when the wire carries no flow.
    'mem-sankey',
    // Round 2: the Sankey's own horizontal scroll box and the canvas inside it.
    'mem-sankey-scroll',
    'mem-sankey-svg',
    'mem-sankey-canvas',
    'mem-sankey-node',
    'mem-sankey-link',
    'mem-sankey-label',
    'mem-sankey-value',
    'mem-sankey-leader',
    // 最近变化 is a GitHub contribution-activity rail: one group per updated day, a
    // node per group, items with their own dots. The flat mem-recent* list and its
    // mem-dot are retired with their producer (not merely unused).
    'mem-timeline',
    'mem-timeline-group',
    'mem-timeline-node',
    'mem-timeline-body',
    'mem-timeline-head',
    'mem-timeline-date',
    'mem-timeline-count',
    'mem-timeline-items',
    'mem-timeline-item',
    'mem-timeline-dot',
    'mem-timeline-main',
    'mem-timeline-title',
    'mem-timeline-meta',
    // Round 5: the quiet '仅显示最近 K 条' hint under a sampled day's total.
    'mem-timeline-more',
    'mem-searchbar',
    'mem-search-field',
    'mem-search-icon',
    'mem-search-input',
    'mem-search-clear',
    'mem-search-submit',
    'mem-filter',
    'mem-filter-label',
    'mem-filter-options',
    'mem-filter-option',
    'mem-results',
    'mem-result',
    'mem-result-main',
    'mem-result-head',
    'mem-result-title',
    'mem-result-path',
    'mem-snippet',
    'mem-chips',
    'mem-chip',
    'mem-facts',
    'mem-rows',
    'mem-row',
    'mem-row-title',
    'mem-row-time',
    'mem-meter',
    'mem-meter-head',
    'mem-meter-track',
    'mem-meter-fill',
    'mem-events',
    'mem-event',
    'mem-event-dot',
    'mem-digest',
    'mem-sheet',
    'mem-sheet-scrim',
    'mem-sheet-panel',
    'mem-sheet-head',
    'mem-sheet-title',
    'mem-sheet-body',
    'mem-sheet-fact',
    'mem-fact-value',
    'mem-sheet-effects',
    'mem-sheet-warning',
    'mem-sheet-error',
    'mem-sheet-actions',
    'mem-sheet-confirm',
    'mem-sheet-cancel',
    // 待审阅: the curation review card (executable rows, the read-only findings
    // group, the honest auto-review note and the recent-decisions list) and the
    // sheet's rendered-Markdown region with its block/inline element hooks.
    'mem-review',
    'mem-review-row',
    'mem-review-kind',
    'mem-review-reason',
    'mem-review-paths',
    'mem-review-age',
    'mem-review-actions',
    'mem-review-subhead',
    'mem-review-auto',
    'mem-review-recent',
    'mem-review-recent-row',
    'mem-review-state',
    'mem-review-by',
    // The row itself is the way into the sheet now, so its full-row open control is
    // a guarded hook like every other view class.
    'mem-review-open',
    'mem-sheet-markdown',
    'mem-md',
    'mem-md-h',
    'mem-md-p',
    'mem-md-list',
    'mem-md-item',
    'mem-md-quote',
    'mem-md-hr',
    'mem-md-code',
    'mem-md-inline-code',
    'mem-md-link',
  ]
  // The list is only a guard if it is bound to the producer: read the served
  // views and extract every class token they emit from quoted literals (comments
  // stripped first, see `stripComments`). Every one must be in the list, so a new
  // or renamed view class fails here until the list and the stylesheet follow. The
  // count is asserted as well: the subset check would pass vacuously if the scan
  // ever stopped seeing the views (a quoting change, all names moving into template
  // literals), and deleting an emitted class should force the list and this count
  // to be re-derived.
  const emitted = [
    ...new Set(
      [
        ...stripComments(await viewsSource()).matchAll(
          /'([^'\\]*(?:\\.[^'\\]*)*)'|"([^"\\]*(?:\\.[^"\\]*)*)"/gu,
        ),
      ]
        .flatMap((match) => (match[1] ?? match[2]).split(/\s+/))
        .filter((token) => /^mem-[a-z0-9-]+$/u.test(token)),
    ),
  ].sort()
  const unguarded = emitted.filter((name) => !hooks.includes(name))
  assert.deepEqual(
    unguarded,
    [],
    'classes the views emit but the list does not guard: ' + unguarded.join(', '),
  )
  // Re-derived for the round-4 UI: 132 before it, minus the six retired `mem-recent*`
  // and `mem-dot` hooks, plus the nine the GitHub-style heat map and the thirteen the
  // activity rail add. Round 5 adds the inline outcome line, the hot trigger state and
  // the sampled-day hint on the activity rail; round 2 adds the composition Sankey's
  // scroll box and canvas pair; the curation review adds the 13 review-card hooks plus
  // the 11 rendered-Markdown hooks (24, hence 177), plus the 待审阅 row-open control
  // (178). The count is what makes a deleted
  // producer fail even when the list happens to still cover the rest — the subset check
  // alone would pass on a shrunken view.
  assert.equal(
    emitted.length,
    178,
    'the views scan still sees every emitted class (re-derive the count with the list)',
  )
  for (const hook of hooks)
    assert.match(
      css,
      new RegExp('\\.' + hook + '(?![a-z0-9-])', 'u'),
      'the stylesheet styles ' + hook,
    )
  for (const variant of [
    '.mem-stamp.is-ok',
    '.mem-stamp.is-warn',
    '.mem-stamp.is-err',
    '.mem-notice.is-stale',
    '.mem-notice.is-error',
    '.mem-notice.is-empty',
    '.mem-status.is-error',
    '.mem-status.is-idle',
    '.mem-summary-value.is-warn',
    '.mem-summary-value.is-err',
    '.mem-meter-fill.is-warn',
    '.mem-action-result.is-error',
    '.mem-hot-state.is-ok',
    '.mem-hot-state.is-warn',
    '.mem-snippet mark',
    '.mem-filter-option[aria-pressed="true"]',
    '.mem-sankey-node.is-status',
    '.mem-sankey-node.is-seg0',
    '.mem-sankey-link.is-seg0',
  ])
    assert.ok(css.includes(variant), 'the stylesheet styles ' + variant)
  for (const action of ['.mem-sheet-confirm', '.mem-sheet-cancel']) {
    const start = css.indexOf('.mem-panel ' + action + '{')
    assert.ok(start >= 0, 'the sheet styles ' + action)
    const rule = css.slice(start, css.indexOf('}', start))
    assert.ok(rule.includes('min-height:44px'), action + ' keeps its 44px hit area')
  }
  // The sheet's rendered-Markdown region must stay a bounded scroll box: an
  // unbounded body would push the warning and the confirm/cancel controls out of
  // the modal, which is exactly the reason the region exists. Class coverage alone
  // only proves a rule exists, so the two declarations are pinned here.
  const markdownRegionStart = css.indexOf('.mem-panel .mem-sheet-markdown{')
  assert.ok(markdownRegionStart >= 0, 'the sheet markdown region has a rule')
  const markdownRegion = css.slice(markdownRegionStart, css.indexOf('}', markdownRegionStart))
  assert.ok(
    markdownRegion.includes('max-height:'),
    'the markdown region is height-bounded: ' + markdownRegion,
  )
  assert.ok(
    markdownRegion.includes('overflow:auto'),
    'and scrolls inside its own box: ' + markdownRegion,
  )
  assert.ok(css.includes('grid-template-columns:repeat(2,minmax(0,1fr))'), 'overflow folds to 2x2')
  // The Sankey's coordinate width is the MEASURED block width, so the chart fills a
  // wide panel instead of capping itself or scaling its 11px type; only the height is
  // the fixed vertical coordinate space.
  const sankey = css.indexOf('.mem-panel .mem-sankey{')
  assert.ok(sankey >= 0, 'the Sankey wrapper rule exists')
  const sankeyRule = css.slice(sankey, css.indexOf('}', sankey))
  assert.equal(
    sankeyRule.includes('max-width'),
    false,
    'the chart is not capped: it fills its block',
  )
  const sankeySvg = css.indexOf('.mem-panel .mem-sankey-svg{')
  assert.ok(sankeySvg >= 0, 'the Sankey svg rule exists')
  const sankeySvgRule = css.slice(sankeySvg, css.indexOf('}', sankeySvg))
  assert.ok(sankeySvgRule.includes('width:100%'), 'the svg fills its measured block')
  assert.ok(sankeySvgRule.includes('height:200px'), 'the height stays the fixed coordinate space')
  assert.ok(css.includes('-webkit-line-clamp:2'), 'snippets clamp to two lines')
})

test('the search field owns one rounded focus ring; the input paints no second box', async () => {
  const { script } = await bundle()
  const css = panelCss(script)
  // The measured defect this replaces: the panel-wide :focus-visible rule drew a
  // 2px ring at 2px offset on the square .mem-search-input, INSIDE the rounded field
  // that already turns its own border on :focus-within. Two blue indicators for one
  // focus, one of them square and inset (user screenshot: outer x11..579/y83..122,
  // inner x42..572/y80..125 at 646px). The field now owns the single ring.
  assert.ok(
    css.includes(
      '.mem-panel :focus-visible{outline:2px solid var(--dsw-alias-state-business-primary);outline-offset:2px}',
    ),
    'every other control keeps the global focus ring',
  )
  assert.ok(
    css.includes('.mem-panel .mem-search-input:focus-visible{outline:none}'),
    'the input paints no second, square ring inside the rounded field',
  )
  const start = css.indexOf('.mem-panel .mem-search-field:focus-within{')
  assert.ok(start >= 0, 'the field still tracks focus')
  const field = css.slice(start, css.indexOf('}', start))
  assert.ok(
    field.includes('border-color:var(--dsw-alias-state-business-primary)'),
    'the field edge turns on focus',
  )
  assert.ok(
    field.includes('outline:2px solid var(--dsw-alias-state-business-primary)'),
    'the field paints the one rounded ring the input no longer paints',
  )
  assert.ok(
    css.includes(
      '.mem-panel .mem-search-input::-webkit-search-cancel-button{-webkit-appearance:none;display:none}',
    ),
    'the Chromium search clear affordance is suppressed',
  )
  const passive = css.indexOf('.mem-panel .mem-summary-item{')
  assert.ok(passive >= 0, 'the passive summary cells stay styled')
  const summary = css.slice(passive, css.indexOf('}', passive))
  assert.equal(
    summary.includes('cursor:pointer'),
    false,
    'a passive summary cell does not claim a click',
  )
  assert.equal(
    css.includes('.mem-summary-item:hover'),
    false,
    'a passive summary cell has no hover lift',
  )
  // The metadata rules that actually carry a line of CJK text sit on the CJK
  // line-height floor. `mem-tabbar-meta` is the flex slot around that text, not a
  // text rule of its own, so it is not in this list.
  for (const hook of ['mem-clock', 'mem-viewhead-meta', 'mem-label']) {
    const hookStart = css.indexOf('.mem-panel .' + hook + '{')
    assert.ok(hookStart >= 0, 'the metadata rule exists: ' + hook)
    const rule = css.slice(hookStart, css.indexOf('}', hookStart))
    assert.ok(rule.includes('line-height:1.6'), hook + ' sits on the CJK line-height floor')
  }
})

test('motion is one 160ms entrance plus explicit transitions that reduced motion removes', async () => {
  const { script } = await bundle()
  const css = panelCss(script)
  assert.ok(css.includes('@keyframes mem-enter'), 'the entrance is named')
  assert.ok(css.includes('animation:mem-enter 160ms'), 'the entrance runs 160ms')
  assert.deepEqual(
    [...css.matchAll(/animation-delay:([0-9]+)ms/gu)].map((match) => Number(match[1])),
    [20, 40, 60, 80],
    'children stagger by 20ms',
  )
  assert.equal(/transition:all/iu.test(css), false, 'transitions name their properties')
  const reduced = css.slice(css.indexOf('prefers-reduced-motion'))
  assert.match(reduced, /animation:none/u, 'reduced motion removes the entrance')
  assert.match(reduced, /transition:none/u, 'reduced motion removes the transitions')
})

test('the view scrolls its own thin, token-built scrollbar', async () => {
  const { script } = await bundle()
  const css = panelCss(script)
  assert.ok(css.includes('scrollbar-width:thin'), 'thin scrollbar for the narrow column')
  assert.ok(
    css.includes(
      'scrollbar-color:color-mix(in srgb,var(--dsw-alias-label-secondary) 35%,transparent) transparent',
    ),
    'the scrollbar colour is a token mix',
  )
  assert.ok(css.includes('::-webkit-scrollbar{width:8px'), 'the webkit fallback is 8px')
  assert.ok(
    css.includes(
      '::-webkit-scrollbar-thumb{background:color-mix(in srgb,var(--dsw-alias-label-secondary) 35%,transparent)',
    ),
    'the webkit thumb is the same mix',
  )
})

// The English locale. The bundle's detectLocale() is gated on `window` because
// Node ships a global navigator (language "en-US") — the vm harness supplies the
// fake window, so a sandbox with no navigator still resolves zh, and these tests
// define the browser's navigator to exercise the inferred-English path.

const enSandbox = () => ({ navigator: { language: 'en-US' } })

/** Every string a rendered tree would put in front of the reader. */
function chromeText(tree) {
  const found = []
  for (const node of nodes(tree)) {
    for (const child of node.props?.children ?? []) if (typeof child === 'string') found.push(child)
    for (const key of ['title', 'aria-label', 'placeholder', 'description'])
      if (typeof node.props?.[key] === 'string') found.push(node.props[key])
  }
  return found
}

const hasHan = (values) => values.some((value) => /[\u3400-\u9fff]/u.test(value))

test('the shell infers English from the browser language and keeps zh otherwise', async () => {
  const register = async (globals) => {
    const { exports } = await bundle(undefined, globals)
    let tab
    exports.apply({
      betterSidebar: {
        registerTab(value) {
          tab = value
        },
      },
      inject() {},
      effect(callback) {
        callback()
      },
    })
    return tab
  }
  const en = await register(enSandbox())
  assert.equal(en.title, 'Memory', 'an en-US navigator selects the English tab title')
  assert.equal(en.description, 'Project memory: overview, graph, search and health')
  const zh = await register({})
  assert.equal(zh.title, '记忆', 'a window without navigator keeps the source locale')
  const zhTag = await register({ navigator: { languages: ['zh-CN', 'en-US'] } })
  assert.equal(zhTag.title, '记忆', 'the first supported tag wins')
  const unsupported = await register({ navigator: { language: 'fr-FR' } })
  assert.equal(unsupported.title, 'Memory', 'an unsupported tag still selects English')
})

test('the English shell renders its tab strip, search box, clock and loading copy in English', async () => {
  const { shell, render } = await mountShell('session-en', enSandbox())
  const panel = () => render()
  const renderChild = (name) => {
    const element = component(panel(), name)
    assert.ok(element, 'the shell renders ' + name)
    return shell.render(element.type, element.props)
  }
  const tabs = () => renderChild('MemoryTabs')
  const metaTree = () => {
    const element = component(tabs(), 'TabbarMeta')
    assert.ok(element, 'the strip renders the freshness meta')
    return shell.render(element.type, element.props)
  }
  assert.deepEqual(
    byClass(tabs(), 'mem-tab-label').map((node) => node.props.children.join('')),
    ['Overview', 'Graph', 'Health'],
    'the three tabs are English',
  )
  assert.equal(byRole(tabs(), 'tablist').props['aria-label'], 'Memory view')
  const meta = metaTree()
  assert.ok(chromeText(meta).includes('Loading…'), 'the clock says loading, not 正在读取…')
  const refresh = byClass(meta, 'mem-refresh')[0]
  assert.equal(refresh.props.title, 'Refresh memory data')
  assert.equal(refresh.props['aria-label'], 'Refresh memory data')
  // The refresh arrow is lucide rotate-cw — the clockwise twin of the graph's
  // rotate-ccw reset glyph — not the hand-tuned arc it was before 2026-11-03.
  const refreshIcon = nodes(refresh).find((node) => node.type === 'svg')
  assert.ok(refreshIcon, 'the refresh control paints its icon')
  assert.equal(
    refreshIcon.props.viewBox,
    '0 0 24 24',
    'on the same 24px grid as the graph controls',
  )
  assert.deepEqual(
    nodes(refreshIcon)
      .filter((node) => node.type === 'path')
      .map((node) => node.props.d),
    ['M21 12a9 9 0 1 1-9-9c2.52 0 4.93 1 6.74 2.74L21 8', 'M21 3v5h-5'],
    'lucide rotate-cw: the same five-unit arrowhead as rotate-ccw',
  )
  const box = renderChild('SearchBox')
  const input = byClass(box, 'mem-search-input')[0]
  assert.equal(input.props.placeholder, 'Search memories…')
  assert.equal(input.props['aria-label'], 'Search memories')
  const submit = byClass(box, 'mem-search-submit')[0]
  assert.equal(submit.props['aria-label'], 'Search')
  assert.deepEqual(submit.props.children, ['Search'])
  assert.ok(
    chromeText(panel()).includes('Loading memories…'),
    'the served-module wait says loading in English',
  )
  assert.equal(
    hasHan([
      ...chromeText(panel()),
      ...chromeText(tabs()),
      ...chromeText(box),
      ...chromeText(meta),
    ]),
    false,
    'English shell chrome renders no Han characters',
  )
})

test('the English graph controls localize every control and the empty state', async () => {
  const { shell, render } = await mountShell('session-graph-en', enSandbox())
  const panel = () => render()
  const tabs = () => {
    const element = component(panel(), 'MemoryTabs')
    return shell.render(element.type, element.props)
  }
  const graphTab = nodes(tabs()).find((node) => node.props?.id === 'obsidian-mem-tab-graph')
  assert.ok(graphTab, 'the graph tab is in the strip')
  graphTab.props.onClick()
  const graph = () => {
    const element = component(panel(), 'GraphView')
    assert.ok(element, 'the graph tab mounts GraphView')
    return shell.render(element.type, element.props)
  }
  let tree = graph()
  assert.equal(byRole(tree, 'region').props['aria-label'], 'Graph settings')
  // Every section starts collapsed; opening all four is what renders their controls.
  const headers = byClass(tree, 'tree-item-self')
  assert.equal(headers.length, 4, 'the four control sections are there')
  for (const header of headers) header.props.onClick()
  tree = graph()
  const canvas = shell.render(
    component(tree, 'GraphCanvas').type,
    component(tree, 'GraphCanvas').props,
  )
  assert.equal(canvas.props['aria-label'], 'Zoomable memory graph')
  // Five built-in type groups render their rows; the add button appends a sixth so
  // the localized copy below is read for both a preset row and a new one.
  assert.equal(byClass(tree, 'graph-color-group').length, 5, 'the built-in type groups render')
  const addGroup = nodes(tree).find(
    (node) =>
      node.props?.className === 'mod-cta' && node.props?.children?.includes('New color group'),
  )
  assert.ok(addGroup, 'the color-group section offers its add button')
  addGroup.props.onClick()
  tree = graph()
  assert.equal(
    byClass(tree, 'graph-color-group').length,
    6,
    'the new group appends after the presets',
  )
  const text = [...chromeText(tree), ...chromeText(canvas)]
  for (const copy of [
    'Close',
    'Open graph settings',
    'Start animation',
    'Reset to defaults',
    'Filters',
    'Search notes…',
    'Search notes',
    'Tags',
    'Attachments',
    'Show created notes only',
    'Orphans',
    'Scope',
    'Graph scope',
    'All memories',
    'Current project',
    'Color groups',
    'Enter a query…',
    'Color group query 1',
    'Click to change color; drag to reorder',
    'Color group color 1',
    'Delete color group 1',
    'New color group',
    'Appearance',
    'Arrows',
    'Text opacity',
    'Label size',
    'Node size',
    'Link thickness',
    'Play animation',
    'Force',
    'Center force',
    'Repel force',
    'Link force',
    'Link distance',
    'No memories yet',
  ])
    assert.ok(text.includes(copy), 'English graph copy: ' + copy)
  assert.equal(hasHan(text), false, 'English graph chrome renders no Han characters')
})

test("the graph-control glyphs are Obsidian's own lucide icons", async () => {
  const { shell, render } = await mountShell('session-graph-icons', enSandbox())
  const panel = () => render()
  const tabs = () => {
    const element = component(panel(), 'MemoryTabs')
    return shell.render(element.type, element.props)
  }
  nodes(tabs())
    .find((node) => node.props?.id === 'obsidian-mem-tab-graph')
    .props.onClick()
  const element = component(panel(), 'GraphView')
  const tree = shell.render(element.type, element.props)
  const button = (cls) =>
    byClass(tree, 'graph-controls-button').find((node) => node.props.className.includes(cls))
  const glyph = (cls) => nodes(button(cls)).find((node) => node.type === 'svg')
  const shapes = (svg) =>
    nodes(svg).filter((node) => node.type === 'path' || node.type === 'circle')
  for (const [cls, name] of [
    ['mod-close', 'x'],
    ['mod-open', 'settings'],
    ['mod-animate', 'wand-2'],
    ['mod-reset', 'rotate-ccw'],
  ]) {
    assert.ok(button(cls), 'the ' + name + ' control renders')
    assert.equal(
      glyph(cls).props.viewBox,
      '0 0 24 24',
      name + ' draws on the 24px grid, so every control shares one optical size',
    )
  }
  const settings = shapes(glyph('mod-open'))
  assert.deepEqual(
    settings.map((node) => node.type),
    ['path', 'circle'],
    'the gear is one eight-lobed outline plus its hub',
  )
  assert.ok(settings[0].props.d.startsWith('M9.671 4.136'), 'the lucide settings outline')
  assert.deepEqual(
    [settings[1].props.cx, settings[1].props.cy, settings[1].props.r],
    [12, 12, 3],
    'the hub sits in the middle of the grid',
  )
  assert.deepEqual(
    shapes(glyph('mod-close')).map((node) => node.props.d),
    ['M18 6 6 18', 'm6 6 12 12'],
    'the cross is two lucide stems from (18,6) to (6,18)',
  )
  const wand = shapes(glyph('mod-animate'))
  assert.equal(wand.length, 8, 'wand-2 is the nib plus seven sparkle strokes')
  assert.ok(
    wand[0].props.d.startsWith('m21.64 3.64'),
    'the wand body stays inside its viewBox instead of running off the top edge',
  )
  assert.deepEqual(
    shapes(glyph('mod-reset')).map((node) => node.props.d),
    ['M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8', 'M3 3v5h5'],
    'the rotate-ccw arc plus its five-unit arrowhead',
  )
})

test('the graph colours each memory type with a Morandi default group', async () => {
  const { shell, render } = await mountShell('session-graph-types', enSandbox())
  const panel = () => render()
  const tabs = () => {
    const element = component(panel(), 'MemoryTabs')
    return shell.render(element.type, element.props)
  }
  const graphTab = nodes(tabs()).find((node) => node.props?.id === 'obsidian-mem-tab-graph')
  assert.ok(graphTab, 'the graph tab is in the strip')
  graphTab.props.onClick()
  const graph = () => {
    const element = component(panel(), 'GraphView')
    assert.ok(element, 'the graph tab mounts GraphView')
    return shell.render(element.type, element.props)
  }
  let tree = graph()
  for (const header of byClass(tree, 'tree-item-self')) header.props.onClick()
  tree = graph()

  // The built-in groups are the five note types the vault protocol defines, in the
  // panel's own type order, with the shipped Morandi swatches. Pinning the colour
  // values here is deliberate: a palette change is a visible change to the product.
  const preset = [
    { query: '[type:decision]', color: '#7b8ea6' },
    { query: '[type:convention]', color: '#8ba084' },
    { query: '[type:gotcha]', color: '#ab817c' },
    { query: '[type:doc]', color: '#b39b6f' },
    { query: '[type:glossary]', color: '#9a8aa0' },
  ]
  const rows = byClass(tree, 'graph-color-group')
  assert.deepEqual(
    rows.map((row) => ({
      query: row.props.children[0].props.value,
      color: row.props.children[1].props.value,
    })),
    preset,
    'five editable colour groups, one per memory type',
  )

  // The same list reaches the canvas: colour resolution is the shell→renderer seam,
  // so the check renders GraphCanvas for real and reads the model it would hand over.
  const canvasElement = component(tree, 'GraphCanvas')
  assert.ok(canvasElement, 'GraphView mounts the canvas')
  // Copied into host-realm objects first: the bundle's array comes from the vm.
  assert.deepEqual(
    [...canvasElement.props.groups].map((group) => ({ query: group.query, color: group.color })),
    preset,
    'the canvas is handed the groups',
  )
  const nodesOfType = (nodeType) => ({
    id: 'n-' + nodeType,
    path: nodeType + '/' + nodeType + '.md',
    title: nodeType,
    type: nodeType,
  })
  const rendered = shell.render(canvasElement.type, {
    ...canvasElement.props,
    graph: {
      nodes: [
        ...['decision', 'convention', 'gotcha', 'doc', 'glossary'].map(nodesOfType),
        nodesOfType('hub'),
        nodesOfType('untyped'),
        nodesOfType('unresolved'),
      ],
      edges: [],
      total: 8,
    },
  })
  assert.equal(rendered.type, 'canvas')
  // GraphCanvas's second useRef is the model/state ref; the first is the canvas.
  const state = shell.slots(canvasElement.type).values[1]
  const colors = state.current.model.colors
  for (const group of preset) {
    assert.equal(
      colors.get('n-' + group.query.slice(6, -1)),
      group.color,
      'a ' + group.query + ' node takes its type colour',
    )
  }
  for (const neutral of ['hub', 'untyped', 'unresolved']) {
    assert.equal(
      colors.get('n-' + neutral),
      undefined,
      'the ' + neutral + ' node keeps the theme node colour',
    )
  }
})

test('the English copy only a live graph can reach is still in the bundle', async () => {
  const { script } = await bundle()
  for (const copy of [
    "'Graph unavailable'",
    "'Graph rendering unavailable'",
    "' · All memories'",
    "'Open a session to see its memories'",
    "'Search memories…'",
    "'Clear search'",
    "'Graph settings'",
  ])
    assert.ok(script.includes(copy), 'the bundled fallback copy exists: ' + copy)
  assert.match(script, /quantity\(/u, 'the node/link count pluralizes through quantity()')
  assert.match(
    script,
    /if \(locale === 'en'\) clock = 'Loading…'/u,
    'the clock has its English branch',
  )
  assert.ok(
    script.includes("'正在读取…'"),
    'the Chinese loading literal stays for the default render',
  )
  assert.ok(
    script.includes("' 个节点 · '"),
    'the Chinese count literal stays for the default render',
  )
})

// ---------------------------------------------------------------------------
// Round-2 shell fixes: the in-panel language switch (default English, persisted
// in the host page's localStorage), the search row centred in the gap it opens,
// and the Sankey's own horizontal scroll box.

/** A localStorage stand-in: one fixed stored value, plus a log of every write. */
function storeSandbox(stored = null) {
  const writes = []
  return {
    writes,
    globals: {
      localStorage: {
        getItem: () => stored,
        setItem: (key, value) => writes.push([key, value]),
      },
    },
  }
}

/** The language switch draws the translate mark, not a printed "EN"/"ZH" badge. */
function assertLocaleGlyph(button, message) {
  const children = button.props.children
  assert.equal(children.length, 1, message + ': one glyph replaces the badge text')
  const glyph = children[0]
  assert.equal(glyph.type, 'svg', message + ': an inline svg')
  assert.equal(glyph.props.viewBox, '0 0 24 24')
  assert.equal(glyph.props['aria-hidden'], true, message + ': decorative for the reader')
  assert.ok(
    children.every((child) => typeof child === 'object' && child !== null),
    message + ': no letters are printed',
  )
  const path = nodes(glyph).find((node) => node.type === 'path')
  assert.ok(path, message + ': a path paints the glyph')
  assert.ok(
    path.props.d.startsWith('M12.87'),
    message + ': the translate mark (a 文/A pair) is the Material glyph',
  )
}

test('the panel opens in English by default and switches to Chinese in place', async () => {
  const store = storeSandbox()
  const { script, shell, render, tab } = await mountShell('session-locale-toggle', store.globals)
  assert.equal(tab.title, 'Memory', 'a browser hosting the panel opens it in English by default')
  const panel = () => render()
  const renderChild = (name) => {
    const element = component(panel(), name)
    assert.ok(element, 'the shell renders ' + name)
    return shell.render(element.type, element.props)
  }
  const tabs = () => renderChild('MemoryTabs')
  const metaTree = () => {
    const element = component(tabs(), 'TabbarMeta')
    assert.ok(element, 'the strip renders the freshness meta')
    return shell.render(element.type, element.props)
  }
  const switchButton = () => {
    const button = byClass(metaTree(), 'mem-locale')[0]
    assert.ok(button, 'the strip carries the language switch')
    return button
  }
  assert.deepEqual(
    byClass(tabs(), 'mem-tab-label').map((node) => node.props.children.join('')),
    ['Overview', 'Graph', 'Health'],
    'the tabs are English before any interaction',
  )
  assert.equal(byRole(tabs(), 'tablist').props['aria-label'], 'Memory view')
  const meta = metaTree()
  const localeIndex = nodes(meta).indexOf(byClass(meta, 'mem-locale')[0])
  const clockIndex = nodes(meta).indexOf(byClass(meta, 'mem-clock')[0])
  assert.ok(localeIndex >= 0 && clockIndex > localeIndex, 'the switch sits before the clock')
  let button = switchButton()
  assertLocaleGlyph(button, 'the switch offers Chinese from English')
  assert.equal(button.props['aria-label'], 'Switch to Chinese')
  assert.equal(button.props.title, 'Switch to Chinese')
  assert.equal(button.props.type, 'button', 'the switch is a real button, not a link')
  button.props.onClick()
  assert.deepEqual(
    store.writes,
    [['dsh-obsidian-mem:locale', 'zh']],
    'the choice is persisted for the next session',
  )
  assert.deepEqual(
    byClass(tabs(), 'mem-tab-label').map((node) => node.props.children.join('')),
    ['概览', '图谱', '健康'],
    'the strip re-renders in Chinese without a reload',
  )
  assert.equal(byRole(tabs(), 'tablist').props['aria-label'], '记忆视图')
  const box = renderChild('SearchBox')
  assert.equal(byClass(box, 'mem-search-input')[0].props.placeholder, '搜索记忆…')
  assert.ok(chromeText(metaTree()).includes('正在读取…'), 'the clock re-renders in Chinese')
  button = switchButton()
  assertLocaleGlyph(button, 'the switch offers English back from Chinese')
  assert.equal(button.props['aria-label'], '切换到英文')
  button.props.onClick()
  assert.deepEqual(
    store.writes,
    [
      ['dsh-obsidian-mem:locale', 'zh'],
      ['dsh-obsidian-mem:locale', 'en'],
    ],
    'switching back persists the English choice too',
  )
  assert.deepEqual(
    byClass(tabs(), 'mem-tab-label').map((node) => node.props.children.join('')),
    ['Overview', 'Graph', 'Health'],
  )
  // The served views are built from the module locale, so the import effect must
  // depend on the rendered value as well: otherwise a switch leaves the old
  // locale's view tree mounted under the new chrome.
  assert.ok(
    script.includes('[visible, attempt, localeValue]'),
    'the served-module import effect re-runs when the language switches',
  )
})

test('a stored language choice beats the browser language in both directions', async () => {
  const register = async (globals) => {
    const { exports } = await bundle(undefined, globals)
    let tab
    exports.apply({
      betterSidebar: {
        registerTab(value) {
          tab = value
        },
      },
      inject() {},
      effect(callback) {
        callback()
      },
    })
    return tab
  }
  const storedEn = await register({
    ...storeSandbox('en').globals,
    navigator: { language: 'zh-CN' },
  })
  assert.equal(storedEn.title, 'Memory', 'a stored English choice wins over a Chinese navigator')
  const storedZh = await register({
    ...storeSandbox('zh').globals,
    navigator: { language: 'en-US' },
  })
  assert.equal(storedZh.title, '记忆', 'a stored Chinese choice wins over an English navigator')
  const unknown = await register(storeSandbox('fr').globals)
  assert.equal(unknown.title, 'Memory', 'an unknown stored value still opens English')
  const quiet = await register({})
  assert.equal(quiet.title, '记忆', 'no store at all keeps the old detected default')
})

test('switching the language rebuilds the graph canvas into the new locale', async () => {
  const store = storeSandbox()
  const { script, shell, render } = await mountShell('session-locale-graph', store.globals)
  const panel = () => render()
  const tabs = () => {
    const element = component(panel(), 'MemoryTabs')
    assert.ok(element, 'the shell renders the strip')
    return shell.render(element.type, element.props)
  }
  const meta = () => {
    const element = component(tabs(), 'TabbarMeta')
    assert.ok(element, 'the strip renders the freshness meta')
    return shell.render(element.type, element.props)
  }
  const graphTab = nodes(tabs()).find((node) => node.props?.id === 'obsidian-mem-tab-graph')
  assert.ok(graphTab, 'the graph tab is in the strip')
  graphTab.props.onClick()
  const canvasOf = () => {
    const graphElement = component(panel(), 'GraphView')
    assert.ok(graphElement, 'the graph tab mounts GraphView')
    const graphTree = shell.render(graphElement.type, graphElement.props)
    const canvasElement = component(graphTree, 'GraphCanvas')
    assert.ok(canvasElement, 'GraphView mounts the canvas')
    const canvas = shell.render(canvasElement.type, canvasElement.props)
    return { graphElement, canvasElement, canvas }
  }
  let seen = canvasOf()
  assert.equal(seen.graphElement.props.locale, 'en', 'GraphView receives the live locale')
  assert.equal(seen.canvasElement.props.locale, 'en', 'GraphCanvas is rebuilt for the locale')
  assert.equal(seen.canvas.props['aria-label'], 'Zoomable memory graph')
  byClass(meta(), 'mem-locale')[0].props.onClick()
  seen = canvasOf()
  assert.equal(seen.graphElement.props.locale, 'zh', 'GraphView re-renders with the new locale')
  assert.equal(seen.canvasElement.props.locale, 'zh', 'GraphCanvas re-renders with the new locale')
  assert.equal(seen.canvas.props['aria-label'], '可缩放的记忆关系图谱')
  // The canvas import effect must depend on the locale tag, or the mounted
  // renderer would keep drawing the previous language's aria label.
  assert.ok(
    script.includes('[visible, localeTag]'),
    'the renderer import effect re-runs when the language switches',
  )
})

test('the search row is centred in the gap it opens above and below', async () => {
  const { script } = await bundle()
  const css = panelCss(script)
  const searchStart = css.indexOf('.mem-panel > .mem-searchbar{')
  assert.ok(searchStart >= 0, 'the shell search row rule exists')
  const searchRule = css.slice(searchStart, css.indexOf('}', searchStart))
  const searchPadding = /padding:(\d+)px (\d+)px (\d+)px/u.exec(searchRule)
  assert.ok(searchPadding, 'the search row declares the three-value padding: ' + searchRule)
  const viewStart = css.indexOf('.mem-panel .mem-view{')
  assert.ok(viewStart >= 0, 'the view body rule exists')
  const viewRule = css.slice(viewStart, css.indexOf('}', viewStart))
  const viewPadding = /padding:(\d+)px (\d+)px (\d+)px/u.exec(viewRule)
  assert.ok(viewPadding, '.mem-view declares the three-value padding: ' + viewRule)
  const above = Number(searchPadding[1])
  const below = Number(searchPadding[3]) + Number(viewPadding[1])
  assert.equal(above, 16, '16px above the field')
  assert.equal(below, 16, '16px below the field: 8px row padding + 8px body inset')
})

test('the Sankey scrolls inside its own horizontal box', async () => {
  const { script } = await bundle()
  const css = panelCss(script)
  const start = css.indexOf('.mem-panel .mem-sankey-scroll{')
  assert.ok(start >= 0, 'the Sankey scroll box rule exists')
  const rule = css.slice(start, css.indexOf('}', start))
  for (const marker of [
    'overflow-x:auto',
    'overflow-y:hidden',
    'scrollbar-width:thin',
    'padding-bottom:2px',
  ])
    assert.ok(rule.includes(marker), 'the Sankey scroll box declares ' + marker)
  assert.ok(
    css.includes('.mem-panel .mem-sankey-scroll::-webkit-scrollbar{width:8px;height:8px}'),
    'the webkit fallback is the same 8px bar as the view',
  )
  assert.ok(
    css.includes(
      '.mem-panel .mem-sankey-scroll::-webkit-scrollbar-thumb{background:color-mix(in srgb,var(--dsw-alias-label-secondary) 35%,transparent);border-radius:4px}',
    ),
    'the thumb is the view scrollbar mix, rounded',
  )
  assert.ok(
    css.includes('.mem-panel .mem-sankey-scroll::-webkit-scrollbar-track{background:transparent}'),
    'the track stays invisible',
  )
  assert.ok(css.includes('.mem-panel .mem-sankey-canvas{display:block}'), 'the canvas is a block')
})

// ─────────────────────────────────────────────────────────────────────────────
// The DSH plug-in page's 配置 section (Task 7).
//
// The owner asked for graphical settings instead of hand-edited profile YAML.
// DSH already renders a configuration section on a bundle's Plugins page when the
// bundle registers the `plugins.bundle.config` slot seat with its package name, so
// this half of the feature is a slot registration plus a schema-driven form.
//
// The shell stand-in above deliberately never runs an effect (its components only
// draw chrome). The settings form fetches on mount and polls a write's outcome, so
// it gets a second stand-in that keeps state and re-runs an effect only when its
// deps change — the shape test/panel-ui.test.js uses for the served views. The vm
// sandbox has no timers or fetch, so both are injected through `globals`.
// ─────────────────────────────────────────────────────────────────────────────

function settingsReact() {
  const slots = new Map()
  let current = null
  let cursor = 0
  let pending = []
  const slotState = () => {
    let state = slots.get(current)
    if (state === undefined) slots.set(current, (state = { values: [], effects: [] }))
    return state
  }
  return {
    React: {
      createElement: (type, props, ...children) => ({ type, props: { ...props, children } }),
      useState(initial) {
        const { values } = slotState()
        const index = cursor++
        if (!(index in values)) values[index] = typeof initial === 'function' ? initial() : initial
        return [
          values[index],
          (next) => {
            values[index] = typeof next === 'function' ? next(values[index]) : next
          },
        ]
      },
      useRef(initial) {
        const { values } = slotState()
        const index = cursor++
        if (!(index in values)) values[index] = { current: initial }
        return values[index]
      },
      useEffect(run, deps) {
        const { effects } = slotState()
        const index = cursor++
        const previous = effects[index]
        if (
          previous?.deps &&
          previous.deps.length === (deps ?? []).length &&
          previous.deps.every((value, position) => Object.is(value, deps[position]))
        )
          return
        pending.push(() => {
          previous?.cleanup?.()
          effects[index] = { deps: deps ?? [], cleanup: run() }
        })
      },
    },
    render(component, props) {
      current = component
      cursor = 0
      const tree = component(props)
      const runs = pending
      pending = []
      runs.forEach((run) => run())
      return tree
    },
    unmount(component) {
      for (const effect of slots.get(component)?.effects ?? []) effect?.cleanup?.()
    },
  }
}

/** Register the plugin through a fake ctx that models the nested slots inject. */
async function mountPlugin(globals = {}) {
  const react = settingsReact()
  const { script, exports } = await bundle(react.React, globals)
  const services = []
  const seats = []
  const registrations = []
  const scoped = {
    slots: {
      inject(name, callback) {
        seats.push(name)
        callback()
      },
      register(seat, render) {
        registrations.push({ seat, render })
        return () => {}
      },
    },
  }
  exports.apply({
    betterSidebar: { registerTab: () => () => {} },
    inject(injected, callback) {
      services.push(injected)
      callback(scoped)
    },
    effect(callback) {
      callback()
    },
  })
  return { script, exports, react, services, seats, registrations }
}

const okValue = (value) => ({ ok: true, status: 200, json: async () => ({ ok: true, value }) })
const codedFailure = (status, code, message) => ({
  ok: false,
  status,
  json: async () => ({ ok: false, error: { code, message } }),
})

/** A fake fetch that records every settings request and answers from a handler. */
function settingsFetch(handler) {
  const sent = []
  const fetch = async (url, options = {}) => {
    const body = JSON.parse(options.body)
    sent.push({ url, body, headers: options.headers ?? {}, method: options.method })
    return handler(body, sent.length)
  }
  return { fetch, sent }
}

/**
 * A controllable clock. The vm context has no timers of its own, so the form's
 * `setTimeout`/`clearTimeout` are this fake's — which is what lets a test step the
 * 600 ms poll deterministically instead of sleeping.
 */
function settingsClock() {
  const queue = []
  let nextId = 1
  let now = 0
  return {
    setTimeout: (callback, delay) => {
      const timer = { id: nextId++, at: now + Number(delay) || now, callback }
      queue.push(timer)
      return timer.id
    },
    clearTimeout: (id) => {
      const index = queue.findIndex((timer) => timer.id === id)
      if (index >= 0) queue.splice(index, 1)
    },
    /** Run every timer due at or before `now + ms`; returns how many ran. */
    advance: (ms) => {
      now += Number(ms) || 0
      let ran = 0
      for (;;) {
        const due = queue
          .filter((timer) => timer.at <= now)
          .sort((left, right) => left.at - right.at)[0]
        if (due === undefined) break
        queue.splice(queue.indexOf(due), 1)
        due.callback()
        ran += 1
      }
      return ran
    },
    pending: () => queue.length,
  }
}

/** Mount the registered page view and render it once its first read has landed. */
async function mountSettingsPage(t, handler, extraGlobals = {}) {
  const io = settingsFetch(handler)
  const clock = settingsClock()
  const mounted = await mountPlugin({
    fetch: io.fetch,
    setTimeout: clock.setTimeout,
    clearTimeout: clock.clearTimeout,
    ...extraGlobals,
  })
  const registration = mounted.registrations[0]
  assert.ok(registration, 'the plugin registered the 配置 seat')
  const element = registration.render({ view: 'page' })
  mounted.react.render(element.type, element.props)
  await setImmediate()
  const render = () => mounted.react.render(element.type, element.props)
  t.after(() => mounted.react.unmount(element.type))
  return { ...mounted, clock, element, io, render, tree: render() }
}

const SETTINGS_FIELDS = [
  { path: 'vaultPath', type: 'string', default: '~/Documents/dsh-memory' },
  { path: 'initGitOnCreate', type: 'boolean', default: true },
  { path: 'injectBrief', type: 'boolean', default: true },
  { path: 'bindHint', type: 'boolean', default: true },
  { path: 'autoCapture', type: 'boolean', default: true },
  { path: 'captureIdleMs', type: 'number', default: 90000 },
  { path: 'autoCurate', type: 'boolean', default: true },
  { path: 'autoReview', type: 'boolean', default: true },
  { path: 'briefBudgetChars', type: 'number', default: 6000 },
  { path: 'briefConventionMode', type: 'enum', enum: ['summary', 'flat'], default: 'summary' },
  { path: 'recallBudgetChars', type: 'number', default: 900 },
  { path: 'failureRecall', type: 'boolean', default: true },
  { path: 'hotCapacityChars', type: 'number', default: 9000, min: 2000, max: 100000 },
  { path: 'hotArchiveRatio', type: 'number', default: 0.67 },
  { path: 'distill.provider', type: 'string', default: '' },
  { path: 'distill.model', type: 'string', default: '' },
  { path: 'distill.transport', type: 'enum', enum: ['host', 'http'], default: 'host' },
  { path: 'distill.egress', type: 'enum', enum: ['loopback', 'remote'], default: 'loopback' },
  { path: 'distill.endpoint', type: 'string', default: '' },
  { path: 'distill.apiStyle', type: 'enum', enum: ['openai-chat'], default: 'openai-chat' },
  { path: 'distill.apiKeyEnv', type: 'string', default: '' },
  { path: 'distill.maxItems', type: 'number', default: 12 },
  { path: 'distill.minConfidence', type: 'number', default: 0.75 },
  { path: 'distill.dryRun', type: 'boolean', default: false },
  { path: 'indexBackend', type: 'enum', enum: ['auto', 'sqlite', 'scan'], default: 'auto' },
  {
    path: 'retrievalEngine',
    type: 'enum',
    enum: ['lexical', 'sparse', 'hybrid'],
    default: 'hybrid',
  },
  { path: 'retrievalProvider.enabled', type: 'boolean', default: false },
  {
    path: 'retrievalProvider.egress',
    type: 'enum',
    enum: ['loopback', 'remote'],
    default: 'loopback',
  },
  { path: 'retrievalProvider.endpoint', type: 'string', default: '' },
  { path: 'retrievalProvider.apiStyle', type: 'enum', enum: ['embed', 'openai'], default: 'embed' },
  { path: 'retrievalProvider.apiKeyEnv', type: 'string', default: '' },
  { path: 'retrievalProvider.dimensions', type: 'number', default: 0 },
  { path: 'ignoreGlobs', type: 'stringArray', default: [] },
  // Unknown future paths still render: the host projects the schema and the form
  // must never drop a field it has not learned a label for.
  { path: 'futureFlag', type: 'boolean', default: false },
  // The host projection carries `integer` as a flag beside a `number` type, and the
  // exclusive bound flags beside min/max (one CONFIG_RANGES table host-side).
  { path: 'futureCount', type: 'number', integer: true, default: 3, min: 1, max: 9 },
  { path: 'futureRatio', type: 'number', default: 0.5, min: 0, exclusiveMin: true },
  { path: 'futureCeiling', type: 'number', default: 10, max: 10, exclusiveMax: true },
  // No host default: its row must show no 默认 hint.
  { path: 'futureText', type: 'string' },
]

const settingsValues = () => ({
  vaultPath: '/tmp/vault',
  initGitOnCreate: true,
  injectBrief: false,
  bindHint: true,
  autoCapture: true,
  captureIdleMs: 90000,
  autoCurate: true,
  autoReview: false,
  briefBudgetChars: 6000,
  briefConventionMode: 'summary',
  recallBudgetChars: 900,
  failureRecall: true,
  hotCapacityChars: 9000,
  hotArchiveRatio: 0.67,
  distill: {
    provider: '',
    model: '',
    transport: 'host',
    egress: 'loopback',
    endpoint: '',
    apiStyle: 'openai-chat',
    apiKeyEnv: '',
    maxItems: 12,
    minConfidence: 0.75,
    dryRun: false,
  },
  indexBackend: 'auto',
  retrievalEngine: 'hybrid',
  retrievalProvider: {
    enabled: false,
    egress: 'loopback',
    endpoint: '',
    apiStyle: 'embed',
    apiKeyEnv: '',
    dimensions: 0,
  },
  ignoreGlobs: ['ignored/**'],
  futureFlag: false,
  futureCount: 3,
  futureRatio: 0.5,
  futureCeiling: 9,
  futureText: '',
  // Hidden from `fields` on purpose (the plugin page's own switch owns it). A save
  // sends a complete raw config, so it must survive the form untouched.
  enabled: true,
})

const settingsDefaults = () => ({
  ...settingsValues(),
  vaultPath: '~/Documents/dsh-memory',
  autoReview: true,
  ignoreGlobs: [],
})

const settingsRead = (overrides = {}) =>
  okValue({
    fields: SETTINGS_FIELDS,
    values: settingsValues(),
    defaults: settingsDefaults(),
    writable: true,
    entry: { name: 'dsh-obsidian-mem', id: 'row-obsidian-mem' },
    lastWrite: null,
    ...overrides,
  })

const settingsControl = (tree, path) =>
  nodes(tree).find(
    (node) => node?.props?.id === 'obsidian-mem-setting-' + path.replace(/\./gu, '-'),
  )
const settingsButton = (tree, label) =>
  nodes(tree).find(
    (node) =>
      node?.type === 'button' &&
      (Array.isArray(node.props?.children) ? node.props.children.flat(Infinity) : []).includes(
        label,
      ),
  )
const settingsStrings = (tree) => chromeText(tree)

test('the plugin registers its 配置 seat through a nested optional slots inject', async () => {
  const { exports, services, seats, registrations } = await mountPlugin()
  assert.deepEqual(
    services.map((names) => Array.from(names)),
    [['slots']],
    'the outer inject asks for the slots service',
  )
  assert.deepEqual(seats, ['plugins.bundle.config'], 'the nested inject waits for the seat')
  assert.equal(registrations.length, 1, 'exactly one seat registration')
  // The seat object comes from the vm realm, so its fields are asserted one by one
  // (a cross-realm object has a different Object.prototype and deepEqual refuses it).
  assert.equal(registrations[0].seat.name, 'plugins.bundle.config', 'the seat is the config slot')
  // The key must be this bundle's package name: read package.json rather than
  // repeating the literal, so a rename cannot silently drift the seat out of the page.
  const packageJson = JSON.parse(
    await readFile(new URL('../package.json', import.meta.url), 'utf8'),
  )
  assert.equal(
    registrations[0].seat.key,
    packageJson.name,
    'the page keys the section by this bundle package name',
  )
  // The summary view is one quiet line, never the form.
  const summary = registrations[0].render({ view: 'summary' })
  assert.deepEqual(settingsStrings(summary), ['记忆与整理配置'])
  // The page view is the settings form component.
  const page = registrations[0].render({ view: 'page' })
  assert.equal(page.type.name, 'SettingsSection')
  // ownerProps is optional: an undefined owner still renders the form, not a crash.
  assert.equal(registrations[0].render(undefined).type.name, 'SettingsSection')
  // `slots` stays out of the top-level inject list: an old host has no such
  // service and the plugin must load exactly as before rather than wait on it.
  assert.deepEqual(Array.from(exports.inject), ['betterSidebar'])
})

test('a ctx without inject still loads the memory tab and silently skips the settings seat', async () => {
  const { exports } = await bundle()
  let tab
  const ctx = {
    betterSidebar: {
      registerTab(value) {
        tab = value
        return () => {
          tab = undefined
        }
      },
    },
    effect(callback) {
      callback()
    },
    // Deliberately NO `inject`: this is an older host, and also the shape
    // test/graph-client.test.js and other consumers fake the client ctx with. The
    // settings seat may never make the primary memory tab fail to load.
  }
  assert.doesNotThrow(() => exports.apply(ctx), 'the plugin applies without the slots API')
  assert.ok(tab, 'the memory tab is still registered')
  assert.equal(tab.id, 'obsidian-mem:graph', 'and it is the same tab as on a modern host')
  assert.equal(typeof tab.component, 'function', 'with its component intact')
})

test('the settings form renders the host fields grouped, labelled and with current values', async (t) => {
  const { io, tree } = await mountSettingsPage(t, () => settingsRead())
  assert.equal(io.sent.length, 1, 'one read on mount')
  assert.equal(io.sent[0].url, 'obsidian-mem/settings')
  assert.equal(io.sent[0].method, 'POST')
  assert.deepEqual(io.sent[0].body, { action: 'read' })
  assert.equal(io.sent[0].headers['content-type'], 'application/json')
  assert.equal(
    io.sent[0].headers['x-obsidian-mem-panel'],
    '1',
    'the same same-origin fence header as the panel route',
  )

  const groups = nodes(tree)
    .filter((node) => node?.type === 'section')
    .map((node) => node.props['aria-label'])
  assert.deepEqual(
    groups,
    ['基础', '采集与整理', '上下文预算', '模型蒸馏', '检索', '其他'],
    'the groups render in the fixed order',
  )
  const strings = settingsStrings(tree)
  for (const copy of [
    '记忆库路径',
    '自动审阅提案',
    '热层容量（字符）',
    '蒸馏模型',
    '检索引擎',
    '忽略的路径（每行一个）',
    'futureFlag',
    'futureCount',
  ])
    assert.ok(strings.includes(copy), 'the form labels ' + copy)
  const routeHint = strings.filter(
    (value) => value.includes('路由 ID') && value.includes('Base URL'),
  )
  assert.equal(routeHint.length, 1, 'the distill group explains what the pair selects once')
  assert.ok(
    routeHint[0].includes('最近一次对话'),
    'the hint says an empty pair falls back to the latest conversation model',
  )
  assert.ok(
    routeHint[0].includes('Base URL'),
    'the hint sends third-party API settings to the host model settings',
  )
  assert.equal(
    nodes(tree).some((node) => typeof node?.props?.className === 'string'),
    false,
    'the form adds no stylesheet class — inline tokens only',
  )

  const control = (path) => settingsControl(tree, path)
  assert.equal(control('autoReview').type, 'button')
  assert.equal(control('autoReview').props.role, 'switch', 'a mobile-style switch, not a checkbox')
  assert.equal(control('autoReview').props['aria-checked'], false, 'the current value is shown')
  assert.equal(control('vaultPath').props.type, 'text')
  assert.equal(control('vaultPath').props.value, '/tmp/vault')
  assert.equal(control('retrievalEngine').type, 'select')
  assert.equal(control('retrievalEngine').props.value, 'hybrid')
  assert.deepEqual(
    nodes(control('retrievalEngine'))
      .filter((node) => node?.type === 'option')
      .map((node) => node.props.value),
    ['lexical', 'sparse', 'hybrid'],
    'the enum options come from the host',
  )
  assert.equal(control('hotCapacityChars').props.type, 'number')
  assert.equal(control('hotCapacityChars').props.value, '9000')
  assert.equal(control('hotCapacityChars').props.min, 2000)
  assert.equal(control('hotCapacityChars').props.max, 100000)
  assert.equal(control('futureCount').props.type, 'number')
  assert.equal(control('futureCount').props.step, 1, 'an integer field steps by one')
  assert.equal(control('ignoreGlobs').type, 'textarea')
  assert.equal(control('ignoreGlobs').props.value, 'ignored/**', 'one array item per line')
  assert.equal(settingsButton(tree, '保存').props.disabled, true, 'nothing to save while clean')
})

test('the model-route fields carry Chinese labels, translated options and a meaning hint', async (t) => {
  const { tree } = await mountSettingsPage(t, () => settingsRead())
  const strings = settingsStrings(tree)
  for (const label of [
    '蒸馏调用方式',
    '蒸馏出站范围',
    '蒸馏服务地址',
    '蒸馏接口协议',
    '蒸馏 API Key 环境变量名',
    '检索出站范围',
    '检索接口协议',
    '检索 API Key 环境变量名',
  ])
    assert.ok(strings.includes(label), 'the form labels ' + label)

  const optionTexts = (path) =>
    nodes(settingsControl(tree, path))
      .filter((node) => node?.type === 'option')
      .map((node) =>
        Array.isArray(node.props.children) ? node.props.children.join('') : node.props.children,
      )
  assert.deepEqual(
    optionTexts('distill.transport'),
    ['宿主模型（host）', 'HTTP 端点（http）'],
    'the transport options print their Chinese meaning beside the raw token',
  )
  assert.deepEqual(optionTexts('distill.egress'), ['本机回环（loopback）', '远端服务（remote）'])
  assert.deepEqual(optionTexts('distill.apiStyle'), ['OpenAI 兼容对话（openai-chat）'])
  assert.deepEqual(optionTexts('retrievalProvider.egress'), [
    '本机回环（loopback）',
    '远端服务（remote）',
  ])
  assert.deepEqual(optionTexts('retrievalProvider.apiStyle'), [
    '插件原生向量（embed）',
    'OpenAI 兼容向量（openai）',
  ])
  const explains = (copy) => strings.some((value) => value.includes(copy))
  for (const copy of [
    'API 基址',
    '存放 API Key 的环境变量名（不是 Key 本身）',
    '允许任意 http(s) 主机',
    '向量维度与本地不同，切换后要重建索引',
    '直接调用 OpenAI 兼容的 /chat/completions 端点',
  ])
    assert.ok(explains(copy), 'a field or group explains ' + copy)
})

test('boolean fields are toggle switches and a click dirties the form', async (t) => {
  const { tree, render } = await mountSettingsPage(t, () => settingsRead())
  const before = settingsControl(tree, 'autoReview')
  assert.equal(before.props.disabled, false)
  assert.equal(
    before.props['aria-label'],
    '自动审阅提案',
    'the switch keeps the row label as its name',
  )
  const knob = nodes(before).find((node) => node?.type === 'span')
  assert.ok(knob, 'the switch renders a knob element')
  assert.equal(
    nodes(tree).some((node) => node?.props?.type === 'checkbox'),
    false,
    'the settings form no longer renders checkboxes',
  )
  before.props.onClick()
  const next = render()
  assert.equal(
    settingsControl(next, 'autoReview').props['aria-checked'],
    true,
    'clicking the switch flips it on',
  )
  assert.equal(settingsButton(next, '保存').props.disabled, false, 'the toggle dirties the form')
})

test('a dirty form saves the complete nested draft and reports the reload', async (t) => {
  let reloads = 0
  const { clock, io, render, tree } = await mountSettingsPage(t, (body) => {
    if (body.action === 'read') return settingsRead()
    if (body.action === 'save') return okValue({ scheduled: true, attempt: 7 })
    if (body.action === 'status') {
      reloads += 1
      return okValue({ state: 'applied', attempt: 7 })
    }
    throw new Error('unexpected action ' + body.action)
  })
  settingsControl(tree, 'distill.provider').props.onChange({ target: { value: 'local/llm' } })
  // The mirrored host pair rule is active: a one-sided route disables save, so the
  // test fills both sides the way a user must.
  settingsControl(tree, 'distill.model').props.onChange({ target: { value: 'local/model' } })
  let next = render()
  assert.equal(settingsButton(next, '保存').props.disabled, false, 'an edit enables save')
  settingsButton(next, '保存').props.onClick()
  await setImmediate()
  render()
  const save = io.sent.find((entry) => entry.body.action === 'save')
  assert.ok(save, 'the save was posted')
  assert.deepEqual(save.body.action, 'save')
  // The draft is sent as one complete nested object: every projected path keeps the
  // reader's value, and the untouched siblings keep their current ones.
  assert.equal(save.body.values.vaultPath, '/tmp/vault')
  assert.equal(save.body.values.distill.provider, 'local/llm')
  assert.equal(save.body.values.distill.model, 'local/model')
  assert.equal(save.body.values.distill.maxItems, 12)
  assert.equal(save.body.values.retrievalProvider.dimensions, 0)
  assert.deepEqual(save.body.values.ignoreGlobs, ['ignored/**'])
  assert.equal(save.body.values.autoReview, false)
  assert.equal(save.body.values.futureCount, 3)
  assert.equal(
    save.body.values.enabled,
    true,
    'the hidden enabled key survives the complete-draft save',
  )
  assert.equal(
    io.sent.filter((entry) => entry.body.action === 'status').length,
    0,
    'the page waits before its first poll',
  )
  clock.advance(600)
  await setImmediate()
  next = render()
  assert.equal(reloads, 1, 'one status poll')
  assert.deepEqual(
    io.sent.find((entry) => entry.body.action === 'status').body,
    { action: 'status', attempt: 7 },
    'the poll carries the attempt the save was scheduled under',
  )
  assert.ok(
    settingsStrings(next).some((value) => value.includes('已保存') && value.includes('重载')),
    'a successful reload is announced',
  )
  assert.equal(
    io.sent.filter((entry) => entry.body.action === 'read').length,
    2,
    'applied re-reads the persisted values',
  )
})

test('a failed reload shows the host message', async (t) => {
  const { clock, render, tree } = await mountSettingsPage(t, (body) => {
    if (body.action === 'read') return settingsRead()
    if (body.action === 'save') return okValue({ scheduled: true, attempt: 3 })
    return okValue({ state: 'failed', attempt: 3, message: 'loader rejected the row' })
  })
  settingsControl(tree, 'vaultPath').props.onChange({ target: { value: '/tmp/other' } })
  settingsButton(render(), '保存').props.onClick()
  await setImmediate()
  render()
  clock.advance(600)
  await setImmediate()
  const next = render()
  assert.ok(
    settingsStrings(next).some((value) => value.includes('loader rejected the row')),
    'the host failure message is shown verbatim',
  )
})

test('a read-only host offers no save and says how to edit', async (t) => {
  const { tree } = await mountSettingsPage(t, () =>
    settingsRead({ writable: false, reason: 'editor-unavailable' }),
  )
  const strings = settingsStrings(tree)
  assert.ok(
    strings.some((value) => value.includes('只读') && value.includes('配置编辑服务不可用')),
    'the read-only hint carries the host reason',
  )
  assert.equal(settingsControl(tree, 'vaultPath').props.disabled, true, 'controls are disabled')
  assert.equal(settingsButton(tree, '保存'), undefined, 'no save is offered at all')
  assert.equal(settingsButton(tree, '恢复默认'), undefined, 'and no reset-to-defaults action')
  assert.ok(settingsButton(tree, '刷新'), 'refresh stays available')
})

test('a home-layer override reports the client migration copy, never a save', async (t) => {
  const { tree } = await mountSettingsPage(t, () =>
    settingsRead({
      writable: false,
      reason: 'layer-override',
      message: 'overridden by a home patch or command-line overlay',
    }),
  )
  const strings = settingsStrings(tree)
  assert.ok(
    strings.some(
      (value) => value.includes('$DSH_HOME/cordis.patch.yml') && value.includes('home 补丁'),
    ),
    'the banner names the home patch layer: ' + strings.join(' | '),
  )
  assert.ok(
    strings.some((value) => value.includes('优先级高于 profile 补丁')),
    'and explains why the profile write cannot win',
  )
  assert.ok(
    strings.some((value) => value.includes('profile') && value.includes('cordis.patch.yml')),
    'and tells the user to move the row into the profile patch',
  )
  assert.ok(
    strings.some((value) => value.includes('overridden by a home patch')),
    'the host message stays as a fallback detail',
  )
  assert.equal(settingsButton(tree, '保存'), undefined, 'a layer override is never saveable')
  assert.equal(settingsControl(tree, 'vaultPath').props.disabled, true)
})

test('an invalid stored config is read-only and shows the stored error', async (t) => {
  const { tree } = await mountSettingsPage(t, () =>
    settingsRead({
      writable: false,
      reason: 'config-invalid',
      readError: 'hotCapacityChars must be between 2000 and 100000',
    }),
  )
  const strings = settingsStrings(tree)
  assert.ok(
    strings.some((value) => value.includes('hotCapacityChars must be between 2000 and 100000')),
    'the stored-config error is printed',
  )
  assert.ok(
    strings.some((value) => value.includes('只读')),
    'the form is declared read-only',
  )
  assert.equal(settingsButton(tree, '保存'), undefined, 'no save button exists for it')
})

test('a degraded stored read is read-only and never overwrites the row', async (t) => {
  // A legacy host could answer readError with writable:true; the client must still
  // refuse to save values it could not verify (I1) instead of replacing the row.
  const { tree } = await mountSettingsPage(t, () =>
    settingsRead({ readError: 'profile row unreadable' }),
  )
  assert.ok(
    settingsStrings(tree).some((value) => value.includes('profile row unreadable')),
    'the degraded read is called out',
  )
  assert.equal(settingsControl(tree, 'vaultPath').props.disabled, true, 'controls read-only')
  assert.equal(settingsButton(tree, '保存'), undefined, 'the row can never be replaced blind')
})

test('each scalar field prints its host default as a hint, arrays and unknowns do not', async (t) => {
  const { tree } = await mountSettingsPage(t, () => settingsRead())
  const row = (path) => nodes(tree).find((node) => node?.props?.key === path)
  const rowStrings = (path) => chromeText(row(path))
  assert.ok(
    rowStrings('hotCapacityChars').some((value) => value === '默认：9000'),
    'a number default is printed',
  )
  assert.ok(
    rowStrings('autoReview').some((value) => value === '默认：开'),
    'a boolean default reads 开',
  )
  assert.ok(
    rowStrings('vaultPath').some((value) => value === '默认：~/Documents/dsh-memory'),
    'a string default is printed',
  )
  assert.equal(
    rowStrings('ignoreGlobs').some((value) => String(value).startsWith('默认：')),
    false,
    'an array field shows no scalar default hint',
  )
  assert.equal(
    rowStrings('futureText').some((value) => String(value).startsWith('默认：')),
    false,
    'a field the host sent no default for shows none',
  )
})

test('inline validation names range, integer and exclusive violations and disables save', async (t) => {
  const { render, tree } = await mountSettingsPage(t, () => settingsRead())
  const change = (path, value) => settingsControl(tree, path).props.onChange({ target: { value } })
  change('hotCapacityChars', '10')
  let next = render()
  assert.ok(
    settingsStrings(next).some((value) => value.includes('不能小于 2000')),
    'a below-minimum number is named',
  )
  assert.equal(settingsButton(next, '保存').props.disabled, true, 'save is disabled')

  change('hotCapacityChars', '9000')
  change('futureCount', '2.5')
  next = render()
  assert.ok(
    settingsStrings(next).some((value) => value.includes('必须是整数')),
    'a non-integer value is named',
  )

  change('futureCount', '3')
  change('futureRatio', '0')
  next = render()
  assert.ok(
    settingsStrings(next).some((value) => value.includes('必须大于 0')),
    'an exclusive minimum is named',
  )

  change('futureRatio', '0.5')
  change('futureCeiling', '10')
  next = render()
  assert.ok(
    settingsStrings(next).some((value) => value.includes('必须小于 10')),
    'an exclusive maximum is named',
  )
  assert.equal(settingsButton(next, '保存').props.disabled, true, 'save stays disabled')

  change('futureCeiling', '8')
  next = render()
  assert.equal(settingsButton(next, '保存').props.disabled, false, 'valid edits enable save again')
})

test('the distill route pair is validated locally and disables save', async (t) => {
  const pairWarning = (tree) =>
    settingsStrings(tree).some(
      (value) =>
        value.includes('distill.provider') &&
        value.includes('distill.model') &&
        value.includes('同时'),
    )
  const { render, tree } = await mountSettingsPage(t, () => settingsRead())
  settingsControl(tree, 'distill.provider').props.onChange({ target: { value: 'openai' } })
  let next = render()
  assert.ok(pairWarning(next), 'a one-sided route pair is named')
  assert.equal(
    settingsButton(next, '保存').props.disabled,
    true,
    'save is disabled while the pair is broken',
  )
  settingsControl(tree, 'distill.model').props.onChange({ target: { value: 'gpt' } })
  next = render()
  assert.equal(
    settingsButton(next, '保存').props.disabled,
    false,
    'both sides filled satisfies the pair',
  )
  settingsControl(tree, 'distill.provider').props.onChange({ target: { value: '' } })
  settingsControl(tree, 'distill.model').props.onChange({ target: { value: '' } })
  next = render()
  assert.equal(pairWarning(next), false, 'the pair warning clears when both sides are empty')
  assert.equal(
    settingsButton(next, '保存').props.disabled,
    true,
    'clearing back to the baseline leaves nothing to save',
  )
})

test('a legacy status field is still accepted when the host sends no state', async (t) => {
  const { clock, render, tree } = await mountSettingsPage(t, (body) => {
    if (body.action === 'read') return settingsRead()
    if (body.action === 'save') return okValue({ scheduled: true, attempt: 5 })
    return okValue({ status: 'applied', attempt: 5 })
  })
  settingsControl(tree, 'vaultPath').props.onChange({ target: { value: '/tmp/one' } })
  settingsButton(render(), '保存').props.onClick()
  await setImmediate()
  render()
  clock.advance(600)
  await setImmediate()
  const next = render()
  assert.ok(
    settingsStrings(next).some((value) => value.includes('已保存')),
    'an old host that wrote status:"applied" still resolves the reload',
  )
})

test('a route failure is an error state with a retry, not a broken form', async (t) => {
  const { io, render, tree } = await mountSettingsPage(t, (_body, count) =>
    count === 1 ? codedFailure(503, 'unavailable', 'settings route unavailable') : settingsRead(),
  )
  assert.ok(
    settingsStrings(tree).some((value) => value.includes('无法读取配置')),
    'the read failure names itself',
  )
  assert.ok(
    settingsStrings(tree).some((value) => value.includes('settings route unavailable')),
    'and carries the host message',
  )
  settingsButton(tree, '重试').props.onClick()
  await setImmediate()
  const next = render()
  assert.ok(settingsControl(next, 'vaultPath'), 'the retry reads again and renders the form')
  assert.equal(io.sent.filter((entry) => entry.body.action === 'read').length, 2)
})

test('a malformed read is an error state instead of a crash', async (t) => {
  const { tree } = await mountSettingsPage(t, () => okValue({ nope: true }))
  assert.ok(
    settingsStrings(tree).some((value) => value.includes('无法识别')),
    'an unrecognized payload is reported, never assumed',
  )
})

test('a silent plugin reload times out with the restart and diagnostics hint', async (t) => {
  const { clock, io, render, tree } = await mountSettingsPage(t, (body) => {
    if (body.action === 'read') return settingsRead()
    if (body.action === 'save') return okValue({ scheduled: true, attempt: 11 })
    return okValue({ state: 'pending', attempt: 11 })
  })
  settingsControl(tree, 'vaultPath').props.onChange({ target: { value: '/tmp/other' } })
  settingsButton(render(), '保存').props.onClick()
  await setImmediate()
  render()
  for (let step = 0; step < 40; step += 1) {
    clock.advance(600)
    await setImmediate()
  }
  const next = render()
  const strings = settingsStrings(next)
  assert.ok(
    strings.some((value) => value.includes('重启') && value.includes('diagnostics')),
    'the timeout points at restart and mem_admin(action="diagnostics"): ' + strings.join(' | '),
  )
  assert.ok(
    io.sent.filter((entry) => entry.body.action === 'status').length >= 30,
    'the poll kept asking before it gave up',
  )
})

test('an English host page renders the settings form and the summary in English', async (t) => {
  const { tree } = await mountSettingsPage(t, () => settingsRead(), {
    navigator: { language: 'en-US' },
  })
  const strings = settingsStrings(tree)
  for (const copy of [
    'Basics',
    'Capture & curation',
    'Context budget',
    'Model distillation',
    'Retrieval',
    'Other',
    'Memory vault path',
    'Save',
    'Reset to defaults',
    'Refresh',
  ])
    assert.ok(strings.includes(copy), 'the en form renders ' + copy)
})
