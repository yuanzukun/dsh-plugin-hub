// Task 7: reviewing one parked proposal, and applying it through a transaction.
//
// A proposal exists because applying it is a *semantic* decision. This module is
// the half that lets a human make that decision and nothing else: it may apply
// exactly the operation the proposal carries, through the same transaction engine
// every other write uses, or it may refuse and change nothing. Everything here is
// one of four properties:
//
//   * **The write request is built from explicit fields.** `writeMemory` reads a
//     present `request.id` as "update this note", so a candidate that happens to
//     carry one would turn an approved create into an overwrite of an unrelated
//     note. R6: never spread the candidate.
//   * **A stale proposal never auto-rebases.** The proposal's own source hashes
//     travel into the transaction request as `expectedSourceHashes` and are
//     re-verified there, under the transaction's own vault lock. A mismatch
//     refuses and leaves the record pending for another review.
//   * **Only `create-separate` and `supersede` execute.** A finding is evidence,
//     never a plan, and a deletion has no generic apply at all.
//   * **A refused or rejected decision changes no source byte** and never marks an
//     unapplied proposal applied.
//
// Every case runs in the isolated world Task 1 built (a throwaway vault, Git
// repository and private data root), so nothing here can read or write the user's
// real home, vault or `$DSH_HOME`.
import assert from 'node:assert/strict'
import { fork } from 'node:child_process'
import { createHash, randomUUID } from 'node:crypto'
import { promises as fsp, readFileSync } from 'node:fs'
import { link, mkdir, readFile, readdir, rm, symlink, writeFile } from 'node:fs/promises'
import { dirname, join } from 'node:path'
import { test } from 'node:test'
import ts from 'typescript'

import {
  CURATION_REVIEW_CODES,
  MAX_PROPOSAL_BYTES,
  PROPOSAL_SCHEMA,
  curationProposalDir,
  readCurationProposal,
  saveCurationProposal,
  snapshotProposalSources,
} from '../lib/curation-proposals.js'
import { CurationStateError } from '../lib/curation-state.js'
import { applyReviewedMemory, reviewCurationProposal } from '../lib/curation-review.js'
import { recoverTransactions, withVaultLock } from '../lib/transaction.js'
import { resolveBinding } from '../lib/vault.js'
import { makeCurationWorld } from './curation-world.js'
import {
  assertPrivateFile,
  createDirectoryLink,
  skipWithoutFileSymlink,
} from './platform-capabilities.js'

/** One fixed clock, so every timestamp in a case is the same timestamp. */
const NOW = new Date('2026-10-03T04:00:00Z')
/** The other project these cases must never see. */
const OTHER_PROJECT = '6a1f0b52-0000-4000-8000-000000000001'
/**
 * The translation tables in `lib/curation-review.js` whose *values* are the answer
 * vocabulary: a key is an engine code, a value is what this module reports for it.
 * `OWNERSHIP_CODES` is the one table read at a dynamic emitter site rather than by
 * `refusalCode`, and it is here for the same reason: its values are answers.
 */
const TABLE_NAMES = new Set([
  'OWNERSHIP_CODES',
  'STORE_CODES',
  'TRANSACTION_CODES',
  'MEMORY_CODES',
  'STATE_CODES',
])

/** The sha256 of a byte sequence. */
function sha256(value) {
  return createHash('sha256').update(value).digest('hex')
}

/** The binding the world's writes created, resolved through the shipped seam. */
async function bindingOf(made) {
  const binding = await resolveBinding({
    cwd: made.repo,
    vaultRoot: made.vault,
    mode: 'show',
    home: made.home,
  })
  assert.equal(binding.kind, 'bound', JSON.stringify(binding))
  return binding
}

/** One world, one binding, one seed note. */
async function world(t) {
  const made = await makeCurationWorld(t)
  const seed = await made.services.write({ type: 'doc', title: '起点', body: '起点正文。\n' })
  return { ...made, binding: await bindingOf(made), seed }
}

/** The absolute vault path of one vault-relative path. */
function at(made, relative) {
  return join(made.vault, ...relative.split('/'))
}

/** The `id` prefix of each type, as `lib/routing.js` fixes it. */
const PREFIXES = Object.freeze({
  doc: 'doc',
  decision: 'dec',
  gotcha: 'got',
  convention: 'con',
  glossary: 'glo',
  method: 'met',
})

/** One validated-looking distillation item, as `lib/distill.js` shapes it. */
function itemFixture(overrides = {}) {
  return {
    preassignedId: `${PREFIXES[overrides.type ?? 'decision']}-${randomUUID()}`,
    idempotencyKey: `item:${randomUUID()}`,
    type: 'decision',
    title: '新结论',
    body: '新结论正文。\n',
    tags: [],
    confidence: 0.9,
    assertion: 'stated',
    status: 'accepted',
    evidenceSeqs: [3, 4],
    ...overrides,
  }
}

/**
 * Park one `supersede` proposal about the seed note, from the vault's own bytes.
 *
 * The sources are snapshotted through the store's own reader so the hashes a
 * review re-verifies are the hashes of the bytes on disk, not a literal this test
 * invented.
 */
async function parkSupersede(made, overrides = {}) {
  const item = itemFixture({ supersedesId: made.seed.id, ...(overrides.item ?? {}) })
  const proposal = await saveCurationProposal({
    dataRoot: made.dataRoot,
    now: NOW,
    projectId: made.binding.projectId,
    itemKey: item.idempotencyKey,
    kind: 'supersede',
    sources: await snapshotProposalSources(made.binding, {
      supersedesId: made.seed.id,
      twin: { id: made.seed.id, path: made.seed.path },
      home: made.home,
    }),
    operation: { kind: 'supersede', item, supersedesId: made.seed.id },
    evidence: item.evidenceSeqs,
    ...(overrides.details ?? {}),
  })
  return { proposal, item }
}

/** Park one `create-separate` proposal about the seed note (a twin, not a target). */
async function parkCreateSeparate(made, overrides = {}) {
  const item = itemFixture({
    type: 'gotcha',
    title: '新的踩坑标题',
    body: '新的踩坑正文。\n',
    ...(overrides.item ?? {}),
  })
  const proposal = await saveCurationProposal({
    dataRoot: made.dataRoot,
    now: NOW,
    projectId: made.binding.projectId,
    itemKey: item.idempotencyKey,
    kind: 'near-duplicate',
    sources: await snapshotProposalSources(made.binding, {
      twin: { id: made.seed.id, path: made.seed.path },
      home: made.home,
    }),
    operation: { kind: 'create-separate', item },
    ...(overrides.details ?? {}),
  })
  return { proposal, item }
}

/**
 * Park one `supersede` proposal about a note named by a raw path and id.
 *
 * `snapshotProposalSources` hashes the bytes it reads without judging who wrote them,
 * so a target a review must refuse for its *ownership* is built through the same two
 * public store calls every shipped proposal uses — no hand-written record.
 *
 * @param {object} made - the world.
 * @param {string} relative - the vault-relative note the candidate supersedes.
 * @param {string} id - the id the snapshot and the operation name.
 * @returns {Promise<object>} the stored record.
 */
async function parkSupersedeAbout(made, relative, id) {
  const item = itemFixture({ supersedesId: id })
  return saveCurationProposal({
    dataRoot: made.dataRoot,
    now: NOW,
    projectId: made.binding.projectId,
    itemKey: item.idempotencyKey,
    kind: 'supersede',
    sources: await snapshotProposalSources(made.binding, {
      supersedesId: id,
      twin: { id, path: relative },
      home: made.home,
    }),
    operation: { kind: 'supersede', item, supersedesId: id },
  })
}

/** The absolute path of one stored proposal record. */
function recordPath(made, proposalId) {
  return join(made.dataRoot, 'curation', 'proposals', made.binding.projectId, `${proposalId}.json`)
}

/** Whether a path is there, without caring why it is not. */
async function fileExists(path) {
  return fsp.access(path).then(
    () => true,
    () => false,
  )
}

/**
 * The absolute path of one vault-relative path, spelled as the *binding* spells it.
 *
 * `at()` reads and writes the same file, but a hook that must recognize the path
 * `lib/curation-review.js` reads has to use the resolved vault root: the binding resolves
 * the temporary directory's symlink (`/var/…` → `/private/var/…` on macOS) and `at()`
 * does not.
 */
function boundPath(made, relative) {
  return join(made.binding.vaultRoot, ...relative.split('/'))
}

/** Every `.md` file under one directory, vault-relative, sorted. */
async function listMarkdown(directory) {
  const walk = async (base, prefix) => {
    let entries
    try {
      entries = await readdir(base, { withFileTypes: true })
    } catch {
      return []
    }
    const out = []
    for (const entry of entries) {
      const next = prefix === '' ? entry.name : `${prefix}/${entry.name}`
      if (entry.isDirectory()) out.push(...(await walk(join(base, entry.name), next)))
      else if (entry.name.endsWith('.md')) out.push(next)
    }
    return out
  }
  return (await walk(directory, '')).sort()
}

/** Every note byte in the vault, keyed by path, so "no byte changed" is literal. */
async function vaultBytes(made) {
  const out = new Map()
  for (const relative of await listMarkdown(made.vault)) {
    out.set(relative, await readFile(join(made.vault, relative)))
  }
  return out
}

// ---------------------------------------------------------------------------
// The executable operations
// ---------------------------------------------------------------------------

test('an approved supersede creates the note, marks the old one, and records a receipt', async (t) => {
  const made = await world(t)
  const { proposal, item } = await parkSupersede(made)
  const old = await readFile(at(made, made.seed.path))

  const answer = await reviewCurationProposal({
    dataRoot: made.dataRoot,
    proposalId: proposal.proposalId,
    decision: 'apply',
    binding: made.binding,
    now: NOW,
  })
  assert.equal(answer.status, 'applied', JSON.stringify(answer))
  // `writeMemory` answers `{id, path, receipt}`, so the transaction receipt a
  // decision records is its `receipt` field — the same shape a direct write gets.
  assert.equal(answer.receipt.receipt.result.status, 'applied')
  assert.equal(answer.receipt.receipt.idempotencyKey, item.idempotencyKey)
  assert.equal(answer.receipt.id, item.preassignedId)

  const record = await readCurationProposal({
    dataRoot: made.dataRoot,
    projectId: made.binding.projectId,
    proposalId: proposal.proposalId,
  })
  assert.equal(record.state, 'applied')
  assert.equal(record.decidedAt, NOW.toISOString())

  // The new note exists under the candidate's own pre-assigned identity…
  const written = await made.services.read({ path: answer.receipt.path })
  assert.equal(written.frontmatter.id, item.preassignedId)
  assert.equal(written.frontmatter.supersedes, made.seed.id)
  // …and the superseded note still holds its own id, with its status moved.
  const after = await made.services.read({ path: made.seed.path })
  assert.equal(after.frontmatter.id, made.seed.id)
  assert.equal(after.frontmatter.status, 'superseded')
  assert.notDeepEqual(await readFile(at(made, made.seed.path)), old)
})

test('an approved create-separate publishes the candidate as a separate note', async (t) => {
  const made = await world(t)
  const { proposal, item } = await parkCreateSeparate(made)
  const before = await vaultBytes(made)

  const answer = await reviewCurationProposal({
    dataRoot: made.dataRoot,
    proposalId: proposal.proposalId,
    decision: 'apply',
    binding: made.binding,
    now: NOW,
  })
  assert.equal(answer.status, 'applied', JSON.stringify(answer))

  const written = await made.services.read({ path: answer.receipt.path })
  assert.equal(written.frontmatter.id, item.preassignedId)
  assert.equal(written.frontmatter.supersedes, null)

  const after = await vaultBytes(made)
  // Exactly one file appears, and it is the one the receipt names. Everything the
  // create is not allowed to touch is byte-identical: the seed note, the user's own
  // preferences file, and every other note.
  // The engine's own snapshot of the MOC it updated lives under `_meta/.history/`,
  // which is recovery material and not vault content.
  assert.deepEqual(
    [...after.keys()].filter((path) => !before.has(path) && !path.startsWith('_meta/.history/')),
    [answer.receipt.path],
    'exactly one new note is published',
  )
  for (const [path, bytes] of before) {
    // Two files are *expected* to move and are the create's own routed changes:
    // the directory's generated MOC gains the new link, and the append-only receipt
    // log gains this transaction's entry. Neither is another note's content.
    if (path.endsWith('/index.md') || path === '_meta/log.md') continue
    assert.deepEqual(after.get(path), bytes, `${path} changed`)
  }
  assert.notDeepEqual(
    after.get(`${made.binding.relativeDir}/Pitfalls/index.md`),
    before.get(`${made.binding.relativeDir}/Pitfalls/index.md`),
    'the generated MOC gained the new line',
  )
  assert.match(after.get('_meta/log.md').toString('utf8'), /新的踩坑标题/u)
})

test('R6: an id on the parked candidate never reaches the write request', async (t) => {
  // The dangerous shape: a distilled item that happens to carry the *seed note's*
  // id. `writeMemory` reads a present `id` as "update that note", so spreading the
  // candidate would rewrite the seed's body instead of publishing a new note — an
  // approved create silently becoming an overwrite of an unrelated file.
  const made = await world(t)
  const { proposal } = await parkSupersede(made, {
    item: { id: made.seed.id, type: 'decision' },
  })
  const old = await readFile(at(made, made.seed.path))

  const answer = await reviewCurationProposal({
    dataRoot: made.dataRoot,
    proposalId: proposal.proposalId,
    decision: 'apply',
    binding: made.binding,
    now: NOW,
  })
  assert.equal(answer.status, 'applied', JSON.stringify(answer))

  // The seed is an *update* (status → superseded), never a body overwrite, and the
  // new note carries the candidate's own pre-assigned identity.
  const seed = await made.services.read({ path: made.seed.path })
  assert.equal(seed.frontmatter.id, made.seed.id)
  assert.match(seed.body, /起点正文。/, 'the seed body must survive an approved create')
  assert.notDeepEqual(await readFile(at(made, made.seed.path)), old)
  const written = await made.services.read({ path: answer.receipt.path })
  assert.equal(written.frontmatter.id, proposal.operation.item.preassignedId)
})

test('a second approval of an applied proposal is refused, not applied twice', async (t) => {
  const made = await world(t)
  const { proposal } = await parkCreateSeparate(made)
  const first = await reviewCurationProposal({
    dataRoot: made.dataRoot,
    proposalId: proposal.proposalId,
    decision: 'apply',
    binding: made.binding,
    now: NOW,
  })
  assert.equal(first.status, 'applied')
  const after = await vaultBytes(made)

  const second = await reviewCurationProposal({
    dataRoot: made.dataRoot,
    proposalId: proposal.proposalId,
    decision: 'apply',
    binding: made.binding,
    now: NOW,
  })
  assert.equal(second.status, 'refused')
  assert.equal(second.code, 'proposal-not-current')
  assert.deepEqual(await vaultBytes(made), after, 'a repeated apply writes no byte')

  const third = await reviewCurationProposal({
    dataRoot: made.dataRoot,
    proposalId: proposal.proposalId,
    decision: 'reject',
    binding: made.binding,
    now: NOW,
  })
  assert.equal(third.status, 'refused')
  assert.equal(
    (
      await readCurationProposal({
        dataRoot: made.dataRoot,
        projectId: made.binding.projectId,
        proposalId: proposal.proposalId,
      })
    ).state,
    'applied',
    'a refused rejection never rewrites a decided proposal',
  )
})

// ---------------------------------------------------------------------------
// Refusals, each of which must change no source byte
// ---------------------------------------------------------------------------

test('an unknown proposal id is refused and nothing in the vault moves', async (t) => {
  const made = await world(t)
  const before = await vaultBytes(made)
  const answer = await reviewCurationProposal({
    dataRoot: made.dataRoot,
    proposalId: 'a'.repeat(64),
    decision: 'apply',
    binding: made.binding,
    now: NOW,
  })
  assert.equal(answer.status, 'refused')
  assert.equal(answer.code, 'proposal-missing')
  assert.deepEqual(await vaultBytes(made), before)
})

test('wrong project: the binding’s own project is the only one this may apply', async (t) => {
  const made = await world(t)
  const { proposal } = await parkCreateSeparate(made)
  const before = await vaultBytes(made)

  const answer = await reviewCurationProposal({
    dataRoot: made.dataRoot,
    proposalId: proposal.proposalId,
    // The proposal lives under the world's own project directory; this binding
    // names another, so the store itself cannot even find the record.
    binding: { ...made.binding, projectId: OTHER_PROJECT },
    decision: 'apply',
    now: NOW,
  })
  assert.equal(answer.status, 'refused')
  assert.equal(answer.code, 'proposal-missing')
  assert.deepEqual(await vaultBytes(made), before)

  const record = await readCurationProposal({
    dataRoot: made.dataRoot,
    projectId: made.binding.projectId,
    proposalId: proposal.proposalId,
  })
  assert.equal(record.state, 'pending', 'the proposal stays for the right project to review')
})

test('a source edited after the scan refuses the approval and keeps the record pending', async (t) => {
  // The stale-proposal case the plan names. The edit lands between the scan that
  // hashed it and the approval, so the decision refers to bytes nobody read.
  const made = await world(t)
  const { proposal } = await parkSupersede(made)
  const source = at(made, made.seed.path)
  await writeFile(source, `${await readFile(source, 'utf8')}尾注。\n`)
  const beforeReviewBytes = await readFile(source)

  const answer = await reviewCurationProposal({
    dataRoot: made.dataRoot,
    proposalId: proposal.proposalId,
    decision: 'apply',
    binding: made.binding,
    now: NOW,
  })
  assert.equal(answer.status, 'refused')
  assert.equal(answer.code, 'source-changed')
  assert.deepEqual(await readFile(source), beforeReviewBytes)

  const record = await readCurationProposal({
    dataRoot: made.dataRoot,
    projectId: made.binding.projectId,
    proposalId: proposal.proposalId,
  })
  assert.equal(record.state, 'pending', 'a stale proposal is never auto-rebased')
})

test('the evidence is re-verified by the engine, under its own lock', async (t) => {
  // The seam proves *where* the second check happens. `io.readFile` is the
  // transaction engine's own vault read, so a stub that answers other bytes for a
  // source makes the apply fail even though the file on disk is untouched: the
  // precondition is validated inside the transaction, not from a caller's earlier
  // read. Without the field the request would carry no evidence check at all and
  // this stub would change nothing.
  const made = await world(t)
  const { proposal } = await parkCreateSeparate(made)
  const before = await vaultBytes(made)
  const wrongBytes = { [made.seed.path]: Buffer.from('不是扫描时看到的那份字节\n') }
  const io = {
    readFile: (absolute, ...rest) => {
      for (const [relative, bytes] of Object.entries(wrongBytes)) {
        if (String(absolute).endsWith(relative.split('/').at(-1))) return Promise.resolve(bytes)
      }
      return readFile(absolute, ...rest)
    },
  }

  const answer = await reviewCurationProposal({
    dataRoot: made.dataRoot,
    proposalId: proposal.proposalId,
    decision: 'apply',
    binding: made.binding,
    now: NOW,
    io,
  })
  assert.equal(answer.status, 'refused', JSON.stringify(answer))
  assert.equal(answer.code, 'source-changed')
  assert.deepEqual(await vaultBytes(made), before, 'the refusal published nothing')
})

test(
  'a source replaced by a file symlink is refused before any write',
  // A file symlink is the link kind this host refuses to create unprivileged
  // (EPERM, measured), so the escape it models cannot be built here at all.
  { skip: skipWithoutFileSymlink() },
  async (t) => {
    const made = await world(t)
    const { proposal } = await parkCreateSeparate(made)
    const source = at(made, made.seed.path)
    const outside = join(made.root, 'outside.md')
    await writeFile(outside, '外部文件。\n')
    await symlink(outside, `${source}.link`)
    // Rewrite the proposal's own source list at the store's path, so the review is
    // asked about a path that is now a symlink out of the vault. The record is
    // written through the store's reader/writer pair rather than by hand.
    const storePath = join(
      made.dataRoot,
      'curation',
      'proposals',
      made.binding.projectId,
      `${proposal.proposalId}.json`,
    )
    const stored = JSON.parse(await readFile(storePath, 'utf8'))
    stored.sources = [{ id: null, path: `${made.seed.path}.link`, hash: sha256('外部文件。\n') }]
    await writeFile(storePath, `${JSON.stringify(stored, null, 2)}\n`)
    const before = await vaultBytes(made)

    const answer = await reviewCurationProposal({
      dataRoot: made.dataRoot,
      proposalId: proposal.proposalId,
      decision: 'apply',
      binding: made.binding,
      now: NOW,
    })
    assert.equal(answer.status, 'refused')
    assert.equal(answer.code, 'source-unsafe')
    assert.deepEqual(await vaultBytes(made), before)
  },
)

test('a source that is a directory link is refused before any write', async (t) => {
  // The half of the refusal this host *can* exercise: an escape built from a
  // directory link (a junction where a directory symlink is refused) is still a
  // link on the source path, and the review must refuse it as source-unsafe.
  // Dropping the case instead would leave the refusal with no coverage at all here.
  const made = await world(t)
  const { proposal } = await parkCreateSeparate(made)
  const outside = join(made.root, 'outside-dir')
  await mkdir(outside, { recursive: true })
  await writeFile(join(outside, 'x.md'), '外部文件。\n')
  await createDirectoryLink(outside, at(made, `${made.seed.path}.link`))
  const storePath = join(
    made.dataRoot,
    'curation',
    'proposals',
    made.binding.projectId,
    `${proposal.proposalId}.json`,
  )
  const storedNote = JSON.parse(await readFile(storePath, 'utf8'))
  storedNote.sources = [{ id: null, path: `${made.seed.path}.link`, hash: sha256('外部文件。\n') }]
  await writeFile(storePath, `${JSON.stringify(storedNote, null, 2)}\n`)
  const before = await vaultBytes(made)

  const answer = await reviewCurationProposal({
    dataRoot: made.dataRoot,
    proposalId: proposal.proposalId,
    decision: 'apply',
    binding: made.binding,
    now: NOW,
  })
  assert.equal(answer.status, 'refused')
  assert.equal(answer.code, 'source-unsafe')
  assert.deepEqual(await vaultBytes(made), before)
})

test('a human-owned supersede target is refused by the executor', async (t) => {
  const made = await world(t)
  // A note the user wrote: `trust: owner` is a declaration this plugin obeys.
  const humanPath = made.seed.path.replace(/\.md$/u, '-human.md')
  await writeFile(
    at(made, humanPath),
    [
      '---',
      `id: doc-${randomUUID()}`,
      'type: doc',
      'title: "人手写的"',
      'trust: owner',
      'harness: dsh',
      '---',
      '人写的正文。\n',
    ].join('\n'),
  )
  const humanId = /id: (.+)/u.exec(await readFile(at(made, humanPath), 'utf8'))[1].trim()
  const item = itemFixture({ supersedesId: humanId })
  const proposal = await saveCurationProposal({
    dataRoot: made.dataRoot,
    now: NOW,
    projectId: made.binding.projectId,
    itemKey: item.idempotencyKey,
    kind: 'supersede',
    sources: await snapshotProposalSources(made.binding, {
      supersedesId: humanId,
      twin: { id: humanId, path: humanPath },
      home: made.home,
    }),
    operation: { kind: 'supersede', item, supersedesId: humanId },
  })
  const before = await vaultBytes(made)

  const answer = await reviewCurationProposal({
    dataRoot: made.dataRoot,
    proposalId: proposal.proposalId,
    decision: 'apply',
    binding: made.binding,
    now: NOW,
  })
  assert.equal(answer.status, 'refused', JSON.stringify(answer))
  assert.equal(answer.code, 'human-owned')
  assert.deepEqual(await vaultBytes(made), before)
})

test('a review-only finding has no apply path', async (t) => {
  const made = await world(t)
  const finding = await saveCurationProposal({
    dataRoot: made.dataRoot,
    now: NOW,
    projectId: made.binding.projectId,
    itemKey: `scan:dead-wikilink:${made.seed.path}`,
    kind: 'dead-wikilink',
    reviewOnly: true,
    reason: '一个指向不存在笔记的 wikilink',
    sources: await snapshotProposalSources(made.binding, {
      twin: { id: made.seed.id, path: made.seed.path },
      home: made.home,
    }),
  })
  assert.equal(finding.operation, null)
  const before = await vaultBytes(made)

  const answer = await reviewCurationProposal({
    dataRoot: made.dataRoot,
    proposalId: finding.proposalId,
    decision: 'apply',
    binding: made.binding,
    now: NOW,
  })
  assert.equal(answer.status, 'refused')
  assert.equal(answer.code, 'review-only')
  assert.deepEqual(await vaultBytes(made), before)
  assert.equal(
    (
      await readCurationProposal({
        dataRoot: made.dataRoot,
        projectId: made.binding.projectId,
        proposalId: finding.proposalId,
      })
    ).state,
    'pending',
  )
})

test('a deletion operation has no generic apply, and the executor refuses it by name', async (t) => {
  const made = await world(t)
  const before = await vaultBytes(made)
  await assert.rejects(
    () =>
      applyReviewedMemory(
        made.binding,
        {
          operation: { kind: 'delete', path: made.seed.path },
          idempotencyKey: 'delete:1',
        },
        { dataRoot: made.dataRoot, home: made.home, now: NOW },
      ),
    (error) => {
      assert.equal(error.code, 'operation-not-executable', error.message)
      return true
    },
  )
  assert.deepEqual(await vaultBytes(made), before)

  // No operation at all is a different answer: there is no plan here to refuse by
  // name, so the exported executor says the operation itself is unusable rather than
  // claiming it recognised a kind it never saw.
  await assert.rejects(
    () =>
      applyReviewedMemory(
        made.binding,
        { operation: null, idempotencyKey: 'review-only:1' },
        { dataRoot: made.dataRoot, home: made.home, now: NOW },
      ),
    (error) => {
      assert.equal(error.code, 'operation-invalid', error.message)
      return true
    },
  )
  assert.deepEqual(await vaultBytes(made), before)
})

test('a rejection marks the proposal rejected and changes no source byte', async (t) => {
  const made = await world(t)
  const { proposal } = await parkSupersede(made)
  const before = await vaultBytes(made)

  const answer = await reviewCurationProposal({
    dataRoot: made.dataRoot,
    proposalId: proposal.proposalId,
    decision: 'reject',
    binding: made.binding,
    now: NOW,
  })
  assert.equal(answer.status, 'rejected')
  assert.equal(answer.receipt, undefined)
  assert.equal(answer.code, undefined)

  const record = await readCurationProposal({
    dataRoot: made.dataRoot,
    projectId: made.binding.projectId,
    proposalId: proposal.proposalId,
  })
  assert.equal(record.state, 'rejected')
  assert.equal(record.decidedAt, NOW.toISOString())
  assert.deepEqual(await vaultBytes(made), before)

  const after = await reviewCurationProposal({
    dataRoot: made.dataRoot,
    proposalId: proposal.proposalId,
    decision: 'apply',
    binding: made.binding,
    now: NOW,
  })
  assert.equal(after.status, 'refused')
  assert.equal(after.code, 'proposal-not-current')
  assert.deepEqual(await vaultBytes(made), before)
})

// ---------------------------------------------------------------------------
// Concurrency, the lock, and what a committed transaction that cannot notify
// the index must leave behind
// ---------------------------------------------------------------------------

test('two concurrent reviewers of one proposal: one applies, one is refused', async (t) => {
  const made = await world(t)
  const { proposal } = await parkCreateSeparate(made)
  const review = (decision) =>
    reviewCurationProposal({
      dataRoot: made.dataRoot,
      proposalId: proposal.proposalId,
      decision,
      binding: made.binding,
      now: NOW,
    })

  const [first, second] = await Promise.all([review('apply'), review('apply')])
  const statuses = [first.status, second.status].sort()
  assert.deepEqual(statuses, ['applied', 'refused'], JSON.stringify([first, second]))
  const refused = [first, second].find((answer) => answer.status === 'refused')
  assert.equal(refused.code, 'proposal-not-current')

  // `index.md` is the directory's own MOC, created by bootstrap and rewritten by
  // no review: the count that matters is the notes beside it.
  const notes = (await listMarkdown(at(made, `${made.binding.relativeDir}/Pitfalls`))).filter(
    (name) => name !== 'index.md',
  )
  assert.deepEqual(notes.length, 1, `one note for one approved candidate, saw ${notes.join(', ')}`)
})

/** A gate before the vault lock, after the reviewer has acquired its claim. */
function sourceGate(sourceFile) {
  const original = fsp.readFile
  const reached = Promise.withResolvers()
  const resume = Promise.withResolvers()
  let gated = false
  fsp.readFile = async (file, ...rest) => {
    if (file === sourceFile && !gated) {
      gated = true
      reached.resolve()
      await resume.promise
    }
    return original(file, ...rest)
  }
  return {
    reached: reached.promise,
    release: () => resume.resolve(),
    restore: () => {
      fsp.readFile = original
    },
  }
}

/** Review inputs shared by the competing decisions in one temporary world. */
function reviewInput(made, proposal) {
  return {
    dataRoot: made.dataRoot,
    proposalId: proposal.proposalId,
    binding: made.binding,
    home: made.home,
    now: NOW,
  }
}

test('three reviewers cannot reject behind an old but active apply', async (t) => {
  const made = await world(t)
  const { proposal } = await parkCreateSeparate(made)
  const input = reviewInput(made, proposal)
  const gate = sourceGate(boundPath(made, made.seed.path))
  const applying = reviewCurationProposal({
    ...input,
    decision: 'apply',
    now: new Date('2020-01-01T00:00:00Z'),
  })
  let competitors
  try {
    await gate.reached
    competitors = await Promise.all(
      ['reject', 'apply'].map((decision) => reviewCurationProposal({ ...input, decision })),
    )
  } finally {
    gate.release()
    gate.restore()
  }
  const applied = await applying
  assert.deepEqual(
    competitors.map(({ status, code }) => ({ status, code })),
    [
      { status: 'refused', code: 'proposal-not-current' },
      { status: 'refused', code: 'proposal-not-current' },
    ],
  )
  assert.equal(applied.status, 'applied', JSON.stringify(applied))
  const record = await readCurationProposal({ ...input, projectId: made.binding.projectId })
  assert.equal(record.state, 'applied')
  const notes = (await listMarkdown(at(made, `${made.binding.relativeDir}/Pitfalls`))).filter(
    (name) => name !== 'index.md',
  )
  assert.equal(notes.length, 1)
})

test('a refused owner releases its claim before a later reviewer retries', async (t) => {
  const made = await world(t)
  const { proposal } = await parkCreateSeparate(made)
  const input = reviewInput(made, proposal)
  const source = boundPath(made, made.seed.path)
  const original = await readFile(source)
  await writeFile(source, 'changed after proposal\n')
  const gate = sourceGate(source)
  const applying = reviewCurationProposal({ ...input, decision: 'apply' })
  let competitors
  try {
    await gate.reached
    competitors = await Promise.all(
      ['reject', 'apply'].map((decision) => reviewCurationProposal({ ...input, decision })),
    )
  } finally {
    gate.release()
    gate.restore()
  }
  assert.equal((await applying).code, 'source-changed')
  assert.deepEqual(
    competitors.map((answer) => answer.code),
    ['proposal-not-current', 'proposal-not-current'],
  )
  const claim = join(
    curationProposalDir(made.dataRoot, made.binding.projectId),
    `${proposal.proposalId}.claim`,
  )
  assert.equal(await fileExists(claim), false)
  await writeFile(source, original)
  assert.equal((await reviewCurationProposal({ ...input, decision: 'apply' })).status, 'applied')
})

/** A reviewer with its own pid and IPC gates around the real source read. */
function reviewProcess(t, made, input, { source, execArgv = [], guard } = {}) {
  const child = fork(new URL('./fixtures/curation-review-worker.mjs', import.meta.url), [], {
    env: { ...process.env, DSH_HOME: made.home },
    execArgv,
    stdio: ['ignore', 'ignore', 'inherit', 'ipc'],
  })
  const first = Promise.withResolvers()
  const done = Promise.withResolvers()
  const exited = Promise.withResolvers()
  child.on('message', (message) => {
    first.resolve(message)
    if (message.phase === 'done' || message.phase === 'error') done.resolve(message)
  })
  child.once('exit', (code, signal) => {
    const message = { phase: 'exit', code, signal }
    first.resolve(message)
    done.resolve(message)
    exited.resolve(message)
  })
  t.after(async () => {
    if (child.exitCode === null && child.signalCode === null) child.kill('SIGKILL')
    await exited.promise
  })
  child.send({ input, source, guard })
  return { child, first: first.promise, done: done.promise, exited: exited.promise }
}

test(
  'dead-owner recovery excludes competing processes and preserves a later release',
  { timeout: 15_000 },
  async (t) => {
    const made = await world(t)
    const { proposal } = await parkCreateSeparate(made)
    const input = { ...reviewInput(made, proposal), decision: 'apply' }
    const source = boundPath(made, made.seed.path)
    const crashed = reviewProcess(t, made, { ...input, now: '2020-01-01T00:00:00Z' }, { source })
    assert.equal((await crashed.first).phase, 'claimed')
    const claim = join(
      curationProposalDir(made.dataRoot, made.binding.projectId),
      `${proposal.proposalId}.claim`,
    )
    assert.equal(JSON.parse(await readFile(claim, 'utf8')).pid, crashed.child.pid)
    const liveAnswer = await reviewCurationProposal({ ...input, decision: 'reject' })
    assert.equal(liveAnswer.code, 'proposal-not-current', 'an old foreign live pid is not stale')
    // POSIX asserts the exact private bits; NTFS does not implement them, so the
    // helper asserts the regular-file / non-link / owner-readable shape instead.
    await assertPrivateFile(claim, 0o600)
    await assertPrivateFile(join(dirname(claim), '.review-lock.sqlite'), 0o600)
    crashed.child.kill('SIGKILL')
    await crashed.exited

    // Both reclaimers start against the dead owner's on-disk claim. The winner
    // pauses with its new claim held; the loser must refuse without withdrawing it.
    const a = reviewProcess(t, made, input, { source })
    const b = reviewProcess(t, made, input, { source })
    const starts = await Promise.all([a.first, b.first])
    assert.deepEqual(starts.map((message) => message.phase).sort(), ['claimed', 'done'])
    const winner = starts[0].phase === 'claimed' ? a : b
    const loser = starts[0].phase === 'done' ? starts[0] : starts[1]
    assert.equal(loser.answer.code, 'proposal-not-current')
    assert.equal(JSON.parse(await readFile(claim, 'utf8')).pid, winner.child.pid)

    // A third process attempts a rejection while the recovered owner still applies.
    const third = reviewProcess(t, made, { ...input, decision: 'reject' })
    assert.equal((await third.done).answer.code, 'proposal-not-current')
    assert.equal(JSON.parse(await readFile(claim, 'utf8')).pid, winner.child.pid)
    winner.child.send('resume')
    assert.equal((await winner.done).answer.status, 'applied')
    assert.equal(await fileExists(claim), false)
    const record = await readCurationProposal({ ...input, projectId: made.binding.projectId })
    assert.equal(record.state, 'applied')
    const notes = (await listMarkdown(at(made, `${made.binding.relativeDir}/Pitfalls`))).filter(
      (name) => name !== 'index.md',
    )
    assert.equal(notes.length, 1)
  },
)

test('a linked claim guard never creates or modifies outside or vault targets', async (t) => {
  // The guard refuses a guard path that is not *one* regular private file with one
  // hardlink: `lib/curation-review.js` checks `nlink !== 1` on both the opened
  // descriptor and the name. Two link kinds trip that check, and each half uses the
  // one its row needs:
  //
  //   * `existing=true` — a **hardlink** to a real empty file. Target and guard share
  //     bytes, so opening the guard would initialize the caller's file through the
  //     shared inode; the guard sees `nlink === 2` and refuses. A hardlink needs no
  //     privilege, so this half runs everywhere and "the outside bytes did not
  //     change" is a real assertion, not a formality.
  //   * `existing=false` — a **dangling file symlink**, the only construct that names
  //     a path which does not exist yet. This host refuses to create a file symlink
  //     unprivileged (EPERM, measured), so those rows skip with that reason while the
  //     hardlink rows keep the same refusal branch covered.
  for (const location of ['outside', 'vault']) {
    for (const exists of [false, true]) {
      for (const decision of ['apply', 'reject']) {
        // A row whose target must already exist is built from a hardlink and runs
        // everywhere; only the rows that need a *dangling* link skip.
        await t.test(
          `${location}, existing=${exists}, ${decision}`,
          exists ? {} : { skip: skipWithoutFileSymlink() },
          async (t) => {
            const made = await world(t)
            const { proposal } = await parkCreateSeparate(made)
            const input = reviewInput(made, proposal)
            const target = join(location === 'vault' ? made.vault : made.root, 'guard-target.db')
            const guard = join(
              curationProposalDir(made.dataRoot, made.binding.projectId),
              '.review-lock.sqlite',
            )
            // An existing empty regular file is also protected from SQLite
            // initialization; a hardlink shares its bytes with the guard name.
            if (exists) {
              await writeFile(target, '')
              await link(target, guard)
            } else {
              await symlink(target, guard)
            }
            const before = await vaultBytes(made)
            const answer = await reviewCurationProposal({ ...input, decision })
            if (exists)
              assert.equal((await readFile(target)).length, 0, 'outside bytes must not change')
            else
              assert.equal(
                await fileExists(target),
                false,
                'a missing outside target must stay missing',
              )
            assert.equal(answer.code, 'review-lock-unavailable', JSON.stringify(answer))
            assert.deepEqual(await vaultBytes(made), before)
            assert.equal(
              (await readCurationProposal({ ...input, projectId: made.binding.projectId })).state,
              'pending',
            )
          },
        )
      }
    }
  }
})

test('reject refuses a partially published or committed application until its recovery is resolved', async (t) => {
  for (const failAfter of ['new-note', 'receipt', 'receipt-store']) {
    await t.test(failAfter, async (t) => {
      const made = await world(t)
      const { proposal } = await parkCreateSeparate(made)
      const input = reviewInput(made, proposal)
      await assert.rejects(
        reviewCurationProposal({ ...input, decision: 'apply', failAfter }),
        (error) => error.code === 'injected-failure' && error.when === failAfter,
      )
      const before = await vaultBytes(made)
      const notes = (await listMarkdown(at(made, `${made.binding.relativeDir}/Pitfalls`))).filter(
        (name) => name !== 'index.md',
      )
      assert.equal(notes.length, 1, 'the failure occurred after publication')
      const rejected = await reviewCurationProposal({ ...input, decision: 'reject' })
      assert.equal(rejected.code, 'review-recovery-required', JSON.stringify(rejected))
      assert.deepEqual(
        await vaultBytes(made),
        before,
        'refusing rejection does not reconcile implicitly',
      )
      assert.equal(
        (await readCurationProposal({ ...input, projectId: made.binding.projectId })).state,
        'pending',
      )

      // A different proposal/key is still rejectable while this transaction waits.
      const unrelated = await parkCreateSeparate(made)
      assert.equal(
        (
          await reviewCurationProposal({
            ...reviewInput(made, unrelated.proposal),
            decision: 'reject',
          })
        ).status,
        'rejected',
      )
      await recoverTransactions(made.binding, {
        dataRoot: made.dataRoot,
        home: made.home,
        notifyIndex: () => {},
      })
      const afterRecovery = await reviewCurationProposal({ ...input, decision: 'reject' })
      if (failAfter !== 'receipt-store') {
        assert.equal(
          afterRecovery.status,
          'rejected',
          'rollback removes the incomplete application',
        )
        const remaining = (
          await listMarkdown(at(made, `${made.binding.relativeDir}/Pitfalls`))
        ).filter((name) => name !== 'index.md')
        assert.equal(remaining.length, 0)
      } else {
        assert.equal(
          afterRecovery.code,
          'review-recovery-required',
          'the durable receipt still blocks rejection',
        )
        const replay = await reviewCurationProposal({ ...input, decision: 'apply', recover: true })
        assert.equal(replay.status, 'applied', JSON.stringify(replay))
        assert.equal(
          (await readCurationProposal({ ...input, projectId: made.binding.projectId })).state,
          'applied',
        )
      }
    })
  }
})

test('a hardlinked claim guard cannot initialize shared outside bytes', async (t) => {
  const made = await world(t)
  const { proposal } = await parkCreateSeparate(made)
  const target = join(made.vault, 'hardlinked-guard.db')
  await writeFile(target, '')
  const guard = join(
    curationProposalDir(made.dataRoot, made.binding.projectId),
    '.review-lock.sqlite',
  )
  await fsp.link(target, guard)
  const answer = await reviewCurationProposal({
    ...reviewInput(made, proposal),
    decision: 'reject',
  })
  assert.equal((await readFile(target)).length, 0, 'SQLite must not initialize another hardlink')
  assert.equal(answer.code, 'review-lock-unavailable', JSON.stringify(answer))
  assert.equal(
    (
      await readCurationProposal({
        ...reviewInput(made, proposal),
        projectId: made.binding.projectId,
      })
    ).state,
    'pending',
  )
})

test('a runtime without SQLite refuses review instead of approving without a guard', async (t) => {
  const made = await world(t)
  const { proposal } = await parkCreateSeparate(made)
  const input = { ...reviewInput(made, proposal), decision: 'apply' }
  const child = reviewProcess(t, made, input, { execArgv: ['--no-experimental-sqlite'] })
  const result = await child.done
  assert.equal(result.phase, 'done', JSON.stringify(result))
  assert.equal(result.answer.code, 'review-lock-unavailable')
  const record = await readCurationProposal({ ...input, projectId: made.binding.projectId })
  assert.equal(record.state, 'pending')
})

test(
  'a busy claim guard refuses and recovers when its process dies',
  { timeout: 10_000 },
  async (t) => {
    const made = await world(t)
    const { proposal } = await parkCreateSeparate(made)
    const input = { ...reviewInput(made, proposal), decision: 'apply' }
    const guard = join(
      curationProposalDir(made.dataRoot, made.binding.projectId),
      '.review-lock.sqlite',
    )
    const owner = reviewProcess(t, made, input, { guard })
    assert.equal((await owner.first).phase, 'locked')
    const busy = await reviewCurationProposal(input)
    assert.equal(busy.code, 'review-lock-unavailable', JSON.stringify(busy))
    owner.child.kill('SIGKILL')
    await owner.exited
    assert.equal((await reviewCurationProposal(input)).status, 'applied')
  },
)

test('an unavailable claim guard refuses both decisions without changing the proposal', async (t) => {
  const made = await world(t)
  const { proposal } = await parkCreateSeparate(made)
  const input = reviewInput(made, proposal)
  await mkdir(
    join(curationProposalDir(made.dataRoot, made.binding.projectId), '.review-lock.sqlite'),
  )
  for (const decision of ['apply', 'reject']) {
    const answer = await reviewCurationProposal({ ...input, decision })
    assert.equal(answer.code, 'review-lock-unavailable', JSON.stringify(answer))
  }
  const record = await readCurationProposal({ ...input, projectId: made.binding.projectId })
  assert.equal(record.state, 'pending')
  const notes = (await listMarkdown(at(made, `${made.binding.relativeDir}/Pitfalls`))).filter(
    (name) => name !== 'index.md',
  )
  assert.equal(notes.length, 0)
})

/**
 * A one-shot gate on the reviewed evidence read.
 *
 * The engine reads each `expectedSourceHashes` path inside the transaction, through
 * `io.readFile`, so a promise that resolves on that read is a seam *after* the review
 * took its claim and *before* it publishes. `release` lets the apply finish.
 *
 * @param {string} relative - the vault-relative source the apply will re-read.
 * @returns {{reached: Promise<void>, io: object, release: () => void}} the gate.
 */ function evidenceGate(relative) {
  const name = relative.split('/').at(-1)
  let arrived = null
  const reached = new Promise((resolve) => {
    arrived = resolve
  })
  let release = null
  const held = new Promise((resolve) => {
    release = resolve
  })
  let fired = false
  return {
    reached,
    release,
    io: {
      readFile: async (absolute, ...rest) => {
        if (!fired && String(absolute).endsWith(name)) {
          fired = true
          arrived()
          await held
        }
        return readFile(absolute, ...rest)
      },
    },
  }
}

test(
  'a rejection cannot take a proposal an apply is publishing',
  { timeout: 30_000 },
  async (t) => {
    // The interleaving Important 5 names: the apply has taken the claim and is between
    // its publish and its mark when a rejection arrives. Before this round the reject
    // branch ran before any claim, so it read the record `pending`, marked it
    // `rejected`, and the apply then refused *after* the note was on disk — a published
    // note behind a rejected record, and an undeclared `proposal-state` answer.
    const made = await world(t)
    const { proposal } = await parkCreateSeparate(made)
    const gate = evidenceGate(made.seed.path)
    const applying = reviewCurationProposal({
      dataRoot: made.dataRoot,
      proposalId: proposal.proposalId,
      decision: 'apply',
      binding: made.binding,
      now: NOW,
      io: gate.io,
    })
    await gate.reached
    // The claim is held while the apply is inside its transaction, so the reject is
    // refused before it can move the record.
    const rejected = await reviewCurationProposal({
      dataRoot: made.dataRoot,
      proposalId: proposal.proposalId,
      decision: 'reject',
      binding: made.binding,
      now: NOW,
    })
    assert.equal(rejected.status, 'refused', JSON.stringify(rejected))
    assert.equal(rejected.code, 'proposal-not-current')
    gate.release()
    const applied = await applying
    assert.equal(applied.status, 'applied', JSON.stringify(applied))

    const record = await readCurationProposal({
      dataRoot: made.dataRoot,
      projectId: made.binding.projectId,
      proposalId: proposal.proposalId,
    })
    assert.equal(record.state, 'applied', 'no rejection landed behind the apply')
    const notes = (await listMarkdown(at(made, `${made.binding.relativeDir}/Pitfalls`))).filter(
      (name) => name !== 'index.md',
    )
    assert.equal(notes.length, 1, 'exactly one note, and the record that decided it')
  },
)

test('a held vault lock refuses the review with the engine’s lock code', async (t) => {
  const made = await world(t)
  const { proposal } = await parkCreateSeparate(made)
  const before = await vaultBytes(made)

  const answer = await withVaultLock(
    made.binding,
    () =>
      reviewCurationProposal({
        dataRoot: made.dataRoot,
        proposalId: proposal.proposalId,
        decision: 'apply',
        binding: made.binding,
        now: NOW,
        lockTimeoutMs: 60,
        pollMs: 10,
      }),
    { dataRoot: made.dataRoot, home: made.home },
  )

  // The lock is not reentrant, so the nested review cannot take it and reports the
  // engine's own code rather than a second name for the same fact. Nothing is
  // written: the refusal happens before the transaction plans a single target.
  assert.equal(answer.status, 'refused', JSON.stringify(answer))
  assert.equal(answer.code, 'lock-timeout')
  assert.deepEqual(await vaultBytes(made), before)
  assert.equal(
    (
      await readCurationProposal({
        dataRoot: made.dataRoot,
        projectId: made.binding.projectId,
        proposalId: proposal.proposalId,
      })
    ).state,
    'pending',
  )
})

test('a committed apply whose index notification fails still records the applied proposal', async (t) => {
  const made = await world(t)
  const { proposal } = await parkCreateSeparate(made)

  const answer = await reviewCurationProposal({
    dataRoot: made.dataRoot,
    proposalId: proposal.proposalId,
    decision: 'apply',
    binding: made.binding,
    now: NOW,
    notifyIndex: () => {
      throw Object.assign(new Error('index unavailable'), { code: 'index-unavailable' })
    },
  })
  // The vault is committed, so the proposal is applied and the receipt says the
  // index is behind rather than claiming it was notified.
  assert.equal(answer.status, 'applied', JSON.stringify(answer))
  assert.equal(answer.receipt.receipt.result.index, 'stale')
  assert.equal(
    (
      await readCurationProposal({
        dataRoot: made.dataRoot,
        projectId: made.binding.projectId,
        proposalId: proposal.proposalId,
      })
    ).state,
    'applied',
  )
  const written = await made.services.read({ path: answer.receipt.path })
  assert.equal(written.frontmatter.id, proposal.operation.item.preassignedId)
})

test('a pre-receipt crash can be retried only by asking for recovery', async (t) => {
  // `receipt` interrupts before the log and durable receipted marker, after the
  // note is published. Recovery rolls this attempt back before retrying the same
  // candidate identity. `receipt-store` is the separate committed/roll-forward case
  // covered by the reject/recovery matrix above.
  const made = await world(t)
  const { proposal } = await parkCreateSeparate(made)
  const attempt = (extra) =>
    reviewCurationProposal({
      dataRoot: made.dataRoot,
      proposalId: proposal.proposalId,
      decision: 'apply',
      binding: made.binding,
      now: NOW,
      ...extra,
    })

  await assert.rejects(
    () => attempt({ failAfter: 'receipt' }),
    (error) => {
      assert.equal(error.code, 'injected-failure', error.message)
      assert.equal(error.when, 'receipt')
      return true
    },
  )
  // The crash landed after the publish, so the note is already in the vault and the
  // record is still undecided — this is the window `recover` exists for.
  const afterCrash = (await listMarkdown(at(made, `${made.binding.relativeDir}/Pitfalls`))).filter(
    (name) => name !== 'index.md',
  )
  assert.deepEqual(
    afterCrash.length,
    1,
    `the crash published the note, saw ${afterCrash.join(', ')}`,
  )
  assert.equal(
    (
      await readCurationProposal({
        dataRoot: made.dataRoot,
        projectId: made.binding.projectId,
        proposalId: proposal.proposalId,
      })
    ).state,
    'pending',
    'the crash left the record undecided',
  )

  // A retry that does not ask for recovery cannot proceed, and it never will on its
  // own: the partial transaction still owns the published id, so the retry is refused rather
  // than allowed to publish a second note. Two attempts, because "it refuses once"
  // would also be true of a transient failure.
  for (const round of ['first', 'second']) {
    const blocked = await attempt({})
    assert.equal(blocked.status, 'refused', `${round} retry: ${JSON.stringify(blocked)}`)
    assert.equal(blocked.code, 'proposal-not-current')
  }

  // Explicit recovery rolls back the incomplete attempt, then retries the same
  // candidate. There is one current note at its preassigned identity and path.
  const retry = await attempt({ recover: true })
  assert.equal(retry.status, 'applied', JSON.stringify(retry))
  const notes = (await listMarkdown(at(made, `${made.binding.relativeDir}/Pitfalls`))).filter(
    (name) => name !== 'index.md',
  )
  assert.deepEqual(notes.length, 1, `one note after a crash and a replay, saw ${notes.join(', ')}`)
  assert.deepEqual(notes, afterCrash, 'rollback and retry retain the candidate identity and path')
  const afterRetry = await vaultBytes(made)

  const replay = await attempt({})
  assert.equal(replay.status, 'refused')
  assert.equal(replay.code, 'proposal-not-current')
  assert.deepEqual(await vaultBytes(made), afterRetry, 'a refused replay writes no byte')
})
// ---------------------------------------------------------------------------
// The declared code vocabulary
// ---------------------------------------------------------------------------

test('every refusal code this module answers with is declared in one list', async (t) => {
  // The Step-1 cases each name a code. A code answered but not declared is a
  // vocabulary a caller cannot enumerate, and a declared code nothing answers is a
  // promise the module does not keep. Both directions are checked against observed
  // behaviour rather than against a second hand-copied list: every case below
  // produces its code, and the fall-through at the end fails the moment the module
  // answers with something not declared here.
  const made = await world(t)
  const observed = new Set()

  const refused = (answer) => {
    assert.equal(answer.status, 'refused', JSON.stringify(answer))
    observed.add(answer.code)
    return answer
  }
  const unknown = 'f'.repeat(64)
  refused(
    await reviewCurationProposal({
      dataRoot: made.dataRoot,
      proposalId: unknown,
      decision: 'apply',
      binding: made.binding,
      now: NOW,
    }),
  )
  assert.equal(observed.has('proposal-missing'), true)

  const applied = await parkCreateSeparate(made)
  const first = await reviewCurationProposal({
    dataRoot: made.dataRoot,
    proposalId: applied.proposal.proposalId,
    decision: 'apply',
    binding: made.binding,
    now: NOW,
  })
  assert.equal(first.status, 'applied', JSON.stringify(first))
  refused(
    await reviewCurationProposal({
      dataRoot: made.dataRoot,
      proposalId: applied.proposal.proposalId,
      decision: 'apply',
      binding: made.binding,
      now: NOW,
    }),
  )

  const finding = await saveCurationProposal({
    dataRoot: made.dataRoot,
    now: NOW,
    projectId: made.binding.projectId,
    itemKey: `scan:expired-review:${made.seed.path}`,
    kind: 'expired-review',
    reviewOnly: true,
    sources: await snapshotProposalSources(made.binding, {
      twin: { id: made.seed.id, path: made.seed.path },
      home: made.home,
    }),
  })
  refused(
    await reviewCurationProposal({
      dataRoot: made.dataRoot,
      proposalId: finding.proposalId,
      decision: 'apply',
      binding: made.binding,
      now: NOW,
    }),
  )

  // A `supersede` record whose operation was rewritten to a deletion: nothing the
  // store writes can produce this, which is the point — the executor refuses on the
  // operation, not on the path that produced the record.
  const { proposal: tampered } = await parkSupersede(made)
  const storePath = join(
    made.dataRoot,
    'curation',
    'proposals',
    made.binding.projectId,
    `${tampered.proposalId}.json`,
  )
  const stored = JSON.parse(await readFile(storePath, 'utf8'))
  stored.operation = { kind: 'delete', path: made.seed.path }
  await writeFile(storePath, `${JSON.stringify(stored, null, 2)}\n`)
  refused(
    await reviewCurationProposal({
      dataRoot: made.dataRoot,
      proposalId: tampered.proposalId,
      decision: 'apply',
      binding: made.binding,
      now: NOW,
    }),
  )

  const stale = await parkSupersede(made)
  await writeFile(at(made, made.seed.path), '被改写。\n')
  refused(
    await reviewCurationProposal({
      dataRoot: made.dataRoot,
      proposalId: stale.proposal.proposalId,
      decision: 'apply',
      binding: made.binding,
      now: NOW,
    }),
  )

  // A source that is a *directory* link: this host can build that link (a junction
  // where a directory symlink is refused), so the refusal is exercised for real
  // instead of being skipped.
  const symlinked = await parkCreateSeparate(made)
  const outside = join(made.root, 'outside-proof-dir')
  await mkdir(outside, { recursive: true })
  await writeFile(join(outside, 'x.md'), '外部。\n')
  await createDirectoryLink(outside, `${at(made, made.seed.path)}.link`)
  const symlinkStore = join(
    made.dataRoot,
    'curation',
    'proposals',
    made.binding.projectId,
    `${symlinked.proposal.proposalId}.json`,
  )
  const symlinkRecord = JSON.parse(await readFile(symlinkStore, 'utf8'))
  symlinkRecord.sources = [{ id: null, path: `${made.seed.path}.link`, hash: sha256('外部。\n') }]
  await writeFile(symlinkStore, `${JSON.stringify(symlinkRecord, null, 2)}\n`)
  refused(
    await reviewCurationProposal({
      dataRoot: made.dataRoot,
      proposalId: symlinked.proposal.proposalId,
      decision: 'apply',
      binding: made.binding,
      now: NOW,
    }),
  )

  const humanPath = `${made.binding.relativeDir}/Docs/human-proof.md`
  await writeFile(
    at(made, humanPath),
    [
      '---',
      `id: doc-${randomUUID()}`,
      'type: doc',
      'title: "人手写的"',
      'trust: owner',
      'harness: dsh',
      '---',
      '人写的正文。\n',
    ].join('\n'),
  )
  const humanId = /^id: (.+)$/mu.exec(await readFile(at(made, humanPath), 'utf8'))[1].trim()
  const humanItem = itemFixture({ supersedesId: humanId })
  const human = await saveCurationProposal({
    dataRoot: made.dataRoot,
    now: NOW,
    projectId: made.binding.projectId,
    itemKey: humanItem.idempotencyKey,
    kind: 'supersede',
    sources: await snapshotProposalSources(made.binding, {
      supersedesId: humanId,
      twin: { id: humanId, path: humanPath },
      home: made.home,
    }),
    operation: { kind: 'supersede', item: humanItem, supersedesId: humanId },
  })
  refused(
    await reviewCurationProposal({
      dataRoot: made.dataRoot,
      proposalId: human.proposalId,
      decision: 'apply',
      binding: made.binding,
      now: NOW,
    }),
  )

  // Two more ownership proofs the memory layer names, built through the same public
  // store calls: a note with frontmatter and a valid id but no ownership evidence
  // (`ownership-unproven`), and a plugin-owned note that is not the one the snapshot
  // recorded (`ownership-mismatch`). Both are answered under the layer's own names.
  const unprovenId = `dec-${randomUUID()}`
  const unprovenPath = `${made.binding.relativeDir}/Docs/no-ownership-proof.md`
  await writeFile(
    at(made, unprovenPath),
    ['---', `id: ${unprovenId}`, 'type: decision', 'title: "没有归属证据"', '---', '正文。\n'].join(
      '\n',
    ),
  )
  const unproven = await parkSupersedeAbout(made, unprovenPath, unprovenId)
  refused(
    await reviewCurationProposal({
      dataRoot: made.dataRoot,
      proposalId: unproven.proposalId,
      decision: 'apply',
      binding: made.binding,
      now: NOW,
    }),
  )

  const ownId = `dec-${randomUUID()}`
  const mismatchPath = `${made.binding.relativeDir}/Docs/id-mismatch.md`
  await writeFile(
    at(made, mismatchPath),
    [
      '---',
      `id: ${ownId}`,
      'type: decision',
      'title: "身份不一致"',
      'trust: agent',
      'harness: dsh',
      '---',
      '正文。\n',
    ].join('\n'),
  )
  const mismatch = await parkSupersedeAbout(made, mismatchPath, `dec-${randomUUID()}`)
  refused(
    await reviewCurationProposal({
      dataRoot: made.dataRoot,
      proposalId: mismatch.proposalId,
      decision: 'apply',
      binding: made.binding,
      now: NOW,
    }),
  )

  // A stored record whose bytes cannot be read: the private-state reader refuses it,
  // and a review reports that as an answer (`proposal-unreadable`) instead of letting a
  // corrupt cache escape as an exception.
  const corrupt = await parkCreateSeparate(made)
  await writeFile(recordPath(made, corrupt.proposal.proposalId), '{ this is not a record\n')
  refused(
    await reviewCurationProposal({
      dataRoot: made.dataRoot,
      proposalId: corrupt.proposal.proposalId,
      decision: 'apply',
      binding: made.binding,
      now: NOW,
    }),
  )

  const locked = await parkCreateSeparate(made)
  refused(
    await withVaultLock(
      made.binding,
      () =>
        reviewCurationProposal({
          dataRoot: made.dataRoot,
          proposalId: locked.proposal.proposalId,
          decision: 'apply',
          binding: made.binding,
          now: NOW,
          lockTimeoutMs: 60,
          pollMs: 10,
        }),
      { dataRoot: made.dataRoot, home: made.home },
    ),
  )

  // `operation-invalid` also travels through a review: a record whose operation is not
  // an object at all reaches `applyReviewedMemory`, whose own request check names it —
  // the path the exported executor exists for.
  const malformed = await parkCreateSeparate(made)
  const malformedPath = join(
    made.dataRoot,
    'curation',
    'proposals',
    made.binding.projectId,
    `${malformed.proposal.proposalId}.json`,
  )
  const malformedRecord = JSON.parse(await readFile(malformedPath, 'utf8'))
  malformedRecord.operation = { kind: 'create-separate', item: null }
  await writeFile(malformedPath, `${JSON.stringify(malformedRecord, null, 2)}\n`)
  refused(
    await reviewCurationProposal({
      dataRoot: made.dataRoot,
      proposalId: malformed.proposal.proposalId,
      decision: 'apply',
      binding: made.binding,
      now: NOW,
    }),
  )

  // The store's own refused transition (`proposal-state`) is answered as
  // `proposal-not-current`: a rejection arriving while an apply holds the claim is
  // refused by the claim, which is the same fact about the same record.
  const gated = await parkCreateSeparate(made)
  const gate = evidenceGate(made.seed.path)
  const applying = reviewCurationProposal({
    dataRoot: made.dataRoot,
    proposalId: gated.proposal.proposalId,
    decision: 'apply',
    binding: made.binding,
    now: NOW,
    io: gate.io,
  })
  await gate.reached
  refused(
    await reviewCurationProposal({
      dataRoot: made.dataRoot,
      proposalId: gated.proposal.proposalId,
      decision: 'reject',
      binding: made.binding,
      now: NOW,
    }),
  )
  gate.release()
  assert.equal((await applying).status, 'applied')

  const interrupted = await parkCreateSeparate(made)
  const interruptedInput = reviewInput(made, interrupted.proposal)
  await assert.rejects(
    reviewCurationProposal({
      ...interruptedInput,
      decision: 'apply',
      failAfter: 'receipt',
    }),
    (error) => error.code === 'injected-failure',
  )
  refused(await reviewCurationProposal({ ...interruptedInput, decision: 'reject' }))

  const unavailable = await parkCreateSeparate(made)
  const guard = join(
    curationProposalDir(made.dataRoot, made.binding.projectId),
    '.review-lock.sqlite',
  )
  await rm(guard, { force: true })
  await mkdir(guard)
  refused(
    await reviewCurationProposal({
      ...reviewInput(made, unavailable.proposal),
      decision: 'apply',
    }),
  )

  assert.deepEqual(
    [...observed].sort(),
    [...CURATION_REVIEW_CODES].sort(),
    'every declared code is answered by a case, and every answered code is declared',
  )
})

test('every untrustworthy stored record is answered proposal-unreadable', async (t) => {
  // `STATE_CODES` holds eight keys and the review's one read path
  // (`readCurationProposal` → `readRecord`) can raise all eight: the four `state-*` ones
  // are the shared document refusals `lib/curation-state.js` raises too, and the four
  // `proposal-*` ones belong to `lib/curation-proposals.js` alone. Each row drives one
  // key through the shipped review, asserts the reader raised *that* key, and asserts
  // the review answered it as the one declared code instead of throwing.
  const made = await world(t)
  const rows = [
    ['state-corrupt', async (path) => writeFile(path, '{ not a record\n')],
    ['proposal-invalid', async (path) => writeFile(path, '[]\n')],
    [
      'proposal-version',
      async (path) => writeFile(path, `${JSON.stringify({ version: PROPOSAL_SCHEMA + 1 })}\n`),
    ],
    [
      'proposal-mismatch',
      async (path) => {
        const raw = JSON.parse(await readFile(path, 'utf8'))
        raw.proposalId = 'f'.repeat(64)
        await writeFile(path, `${JSON.stringify(raw)}\n`)
      },
    ],
    [
      'proposal-state',
      async (path) => {
        const raw = JSON.parse(await readFile(path, 'utf8'))
        raw.state = 'not-a-state'
        await writeFile(path, `${JSON.stringify(raw)}\n`)
      },
    ],
    [
      'state-not-a-file',
      async (path) => {
        await rm(path)
        await mkdir(path)
      },
    ],
    ['state-oversize', async (path) => writeFile(path, 'x'.repeat(MAX_PROPOSAL_BYTES + 1))],
    // Last, because it replaces the project's proposal directory with a regular file:
    // every other row needs that directory for the proposal it parks next.
    [
      'state-unreadable',
      async (path) => {
        await rm(dirname(path), { recursive: true, force: true })
        await writeFile(dirname(path), 'occupied\n')
      },
    ],
  ]
  for (const [key, damage] of rows) {
    const { proposal } = await parkCreateSeparate(made)
    await damage(recordPath(made, proposal.proposalId))
    await assert.rejects(
      () =>
        readCurationProposal({
          dataRoot: made.dataRoot,
          projectId: made.binding.projectId,
          proposalId: proposal.proposalId,
        }),
      (error) => {
        assert.ok(error instanceof CurationStateError, `${key}: ${error.name}`)
        assert.equal(error.code, key)
        return true
      },
    )
    const answer = await reviewCurationProposal({
      dataRoot: made.dataRoot,
      proposalId: proposal.proposalId,
      decision: 'apply',
      binding: made.binding,
      now: NOW,
    })
    assert.equal(answer.code, 'proposal-unreadable', `${key}: ${JSON.stringify(answer)}`)
  }
})

test('the review vocabulary and the module’s own emitters are the same set', () => {
  // The behavioural case above can only observe the codes its own drivers produce, so
  // on its own it cannot fail for a code the module answers and this file never
  // drives — the direction the finding named. This reads the module's source instead:
  // every code it passes to its own error constructor, every `code: '…'` it returns,
  // and every value of the translation tables it answers through is an answer it can
  // give. The one *dynamic* emitter — the ownership proof re-emitted from
  // `assertPluginOwnedNote` — is not skipped: its code must be read out of a declared
  // table, and a bare `error.code` there is reported as an emitter whose codes cannot
  // be enumerated. A refusal added to the module and not declared fails here, and a
  // declared code the module cannot answer fails here too.
  const source = readFileSync(new URL('../lib/curation-review.js', import.meta.url), 'utf8')

  /**
   * Every code one module source can answer with, and every emitter whose code this
   * scan cannot enumerate.
   *
   * @param {string} sourceText - the JavaScript.
   * @returns {{answers: Set<string>, unbounded: string[]}} the answered codes and the emitter expressions that read no declared table.
   */
  const scanAnswers = (sourceText) => {
    const file = ts.createSourceFile(
      'scan.js',
      sourceText,
      ts.ScriptTarget.Latest,
      true,
      ts.ScriptKind.JS,
    )
    // The tables' *values* are the answers (their keys are the engine's own codes).
    // They are declared as `Object.freeze({…})`, so the literal is reached through the
    // call; a spread or shorthand entry is not an answer and is skipped.
    const tableValues = new Map()
    const tableLiteral = (name) => {
      let literal = null
      const visit = (node) => {
        if (
          ts.isVariableDeclaration(node) &&
          ts.isIdentifier(node.name) &&
          node.name.text === name &&
          node.initializer
        ) {
          const initializer =
            ts.isCallExpression(node.initializer) && node.initializer.arguments.length === 1
              ? node.initializer.arguments[0]
              : node.initializer
          if (ts.isObjectLiteralExpression(initializer)) literal = initializer
        }
        ts.forEachChild(node, visit)
      }
      visit(file)
      return literal
    }
    for (const name of TABLE_NAMES) {
      const literal = tableLiteral(name)
      if (literal === null) continue
      tableValues.set(
        name,
        literal.properties.flatMap((property) =>
          // Only the reading side of a key/value pair is an answer a list may declare.
          ts.isPropertyAssignment(property) && ts.isStringLiteral(property.initializer)
            ? [property.initializer.text]
            : [],
        ),
      )
    }
    // A `const code = OWNERSHIP_CODES[error.code]` bound to a declared table is an
    // enumerable source, so an emitter passing that name is bounded by that table.
    const boundedNames = new Set()
    const isTableRead = (node) =>
      ts.isElementAccessExpression(node) &&
      ts.isIdentifier(node.expression) &&
      tableValues.has(node.expression.text)
    const answers = new Set()
    const unbounded = []
    // One code expression: a literal is an answer, a conditional is judged branch by
    // branch (an `error.code === 'ENOENT' ? 'a' : 'b'` emitter names exactly those two
    // codes), a read of a declared table is bounded by that table, and anything else
    // cannot be enumerated and is reported.
    const judge = (code) => {
      if (ts.isStringLiteralLike(code)) answers.add(code.text)
      else if (ts.isConditionalExpression(code)) {
        judge(code.whenTrue)
        judge(code.whenFalse)
      } else if (isTableRead(code) || boundedNames.has(code.getText(file))) return
      else unbounded.push(code.getText(file))
    }
    const walk = (node) => {
      if (ts.isVariableDeclaration(node) && ts.isIdentifier(node.name) && node.initializer) {
        if (isTableRead(node.initializer)) boundedNames.add(node.name.text)
      }
      if (ts.isNewExpression(node) && node.expression.getText(file) === 'CurationReviewError') {
        // The code is a quoted string (`'operation-invalid'`) or a substitution-free
        // template; one with a `${}` in it is a message.
        const code = node.arguments?.[0]
        if (code !== undefined) judge(code)
      }
      // A refusal the function returns rather than throws is a `code: '…'` entry.
      if (
        ts.isPropertyAssignment(node) &&
        node.name.getText(file) === 'code' &&
        ts.isStringLiteralLike(node.initializer)
      ) {
        answers.add(node.initializer.text)
      }
      ts.forEachChild(node, walk)
    }
    walk(file)
    for (const values of tableValues.values()) for (const value of values) answers.add(value)
    return { answers, unbounded }
  }

  const scan = scanAnswers(source)
  assert.ok(scan.answers.size > 0, 'the scan found no emitter, so this check would be vacuous')
  assert.deepEqual(
    scan.unbounded,
    [],
    'every dynamic refusal code must be read out of a declared table, not an arbitrary expression',
  )
  // `proposal-state` is a table *key*: the store's own refusal is reported under this
  // module's name for the same fact, so it is not part of the answer vocabulary and a
  // position here would be a promise nothing answers.
  assert.deepEqual(
    [...scan.answers].sort(),
    [...CURATION_REVIEW_CODES].sort(),
    'the codes lib/curation-review.js can answer with must be exactly the declared list',
  )

  // Control 1: the same scan reports an answer the list does not declare. It changes a
  // table *value*, which is the half that is an answer, so the case above is a check
  // and not a restatement of the list.
  const controlValue = source.replace(
    `'human-owned': 'human-owned',`,
    `'human-owned': 'undeclared-x',`,
  )
  assert.notEqual(controlValue, source, 'the control must actually change the source')
  assert.deepEqual(
    [...scanAnswers(controlValue).answers].filter((code) => !CURATION_REVIEW_CODES.includes(code)),
    ['undeclared-x'],
    'an answered-but-undeclared code must be reported',
  )

  // Control 2: the dynamic emitter site itself. Replacing the table read with the bare
  // `error.code` — the construction this finding was found through — must be reported,
  // so an emitter whose codes cannot be enumerated fails this case rather than being
  // skipped for not being a string literal.
  const controlDynamic = source.replace(
    'const code = OWNERSHIP_CODES[error.code]',
    'const code = error.code',
  )
  assert.notEqual(controlDynamic, source, 'the dynamic control must actually change the source')
  assert.deepEqual(
    scanAnswers(controlDynamic).unbounded,
    ['code'],
    'an emitter reading no declared table must be reported',
  )
})

// ---------------------------------------------------------------------------
// Decision provenance (curation review panel, spec R8)
// ---------------------------------------------------------------------------

/**
 * The stored sentence an automatic rejection writes.
 *
 * @param {string} note - the reviewer's bounded reason.
 * @returns {string} the sentence.
 */
function autoRejectionReason(note) {
  return `an automatic review rejected this candidate: ${note}`
}

test('a human decision records its provenance, and the human rejection sentence is unchanged', async (t) => {
  const made = await world(t)
  const applied = await parkCreateSeparate(made)
  const applyAnswer = await reviewCurationProposal({
    dataRoot: made.dataRoot,
    proposalId: applied.proposal.proposalId,
    decision: 'apply',
    binding: made.binding,
    now: NOW,
  })
  assert.equal(applyAnswer.status, 'applied', JSON.stringify(applyAnswer))
  const appliedRecord = await readCurationProposal({
    dataRoot: made.dataRoot,
    projectId: made.binding.projectId,
    proposalId: applied.proposal.proposalId,
  })
  assert.equal(appliedRecord.decidedBy, 'human')
  assert.equal(appliedRecord.decidedByModel, null)
  assert.equal(appliedRecord.decisionNote, null)

  const rejected = await parkSupersede(made)
  const rejectAnswer = await reviewCurationProposal({
    dataRoot: made.dataRoot,
    proposalId: rejected.proposal.proposalId,
    decision: 'reject',
    binding: made.binding,
    now: NOW,
    reviewer: { kind: 'human', note: 'read it, not a memory' },
  })
  assert.equal(rejectAnswer.status, 'rejected')
  const rejectedRecord = await readCurationProposal({
    dataRoot: made.dataRoot,
    projectId: made.binding.projectId,
    proposalId: rejected.proposal.proposalId,
  })
  assert.equal(rejectedRecord.decidedBy, 'human')
  assert.equal(
    rejectedRecord.reason,
    'a human reviewed this candidate and rejected it',
    'the human sentence is byte-identical to the one the CLI has always recorded',
  )
  assert.equal(rejectedRecord.decisionNote, 'read it, not a memory')
})

test('an automatic decision records the model and a reversible note on the record', async (t) => {
  const made = await world(t)
  const applied = await parkCreateSeparate(made)
  const answer = await reviewCurationProposal({
    dataRoot: made.dataRoot,
    proposalId: applied.proposal.proposalId,
    decision: 'apply',
    binding: made.binding,
    now: NOW,
    reviewer: { kind: 'auto', model: 'openai/gpt-test', note: 'the evidence is strong' },
  })
  assert.equal(answer.status, 'applied', JSON.stringify(answer))
  const record = await readCurationProposal({
    dataRoot: made.dataRoot,
    projectId: made.binding.projectId,
    proposalId: applied.proposal.proposalId,
  })
  assert.equal(record.decidedBy, 'auto')
  assert.equal(record.decidedByModel, 'openai/gpt-test')
  assert.equal(record.decisionNote, 'the evidence is strong')

  const rejected = await parkSupersede(made)
  const rejection = await reviewCurationProposal({
    dataRoot: made.dataRoot,
    proposalId: rejected.proposal.proposalId,
    decision: 'reject',
    binding: made.binding,
    now: NOW,
    reviewer: { kind: 'auto', model: 'openai/gpt-test', note: 'the new body restates the old one' },
  })
  assert.equal(rejection.status, 'rejected')
  const rejectedRecord = await readCurationProposal({
    dataRoot: made.dataRoot,
    projectId: made.binding.projectId,
    proposalId: rejected.proposal.proposalId,
  })
  assert.equal(rejectedRecord.decidedBy, 'auto')
  assert.equal(rejectedRecord.decidedByModel, 'openai/gpt-test')
  assert.equal(
    rejectedRecord.reason,
    autoRejectionReason('the new body restates the old one'),
    'an automatic rejection names the automatic reviewer',
  )
  assert.equal(rejectedRecord.decisionNote, 'the new body restates the old one')
})

test('a reviewer kind the queue does not know is a programming error, not a decision', async (t) => {
  const made = await world(t)
  const { proposal } = await parkSupersede(made)
  for (const reviewer of [{ kind: 'model' }, { kind: null }, 'human', { kind: 'auto', note: 7 }]) {
    await assert.rejects(
      () =>
        reviewCurationProposal({
          dataRoot: made.dataRoot,
          proposalId: proposal.proposalId,
          decision: 'reject',
          binding: made.binding,
          now: NOW,
          reviewer,
        }),
      RangeError,
    )
  }
  // No refused decision was written by any of those attempts.
  const record = await readCurationProposal({
    dataRoot: made.dataRoot,
    projectId: made.binding.projectId,
    proposalId: proposal.proposalId,
  })
  assert.equal(record.state, 'pending')
})
