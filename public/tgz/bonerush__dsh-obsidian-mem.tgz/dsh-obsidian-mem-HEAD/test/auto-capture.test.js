// Task 16: applying distilled candidates, dedupe/retry, dryRun and crash resume.
//
// The queue worker is the only place in this plugin that writes a vault from an
// unattended path, so every case here is about a failure that must not become a
// duplicate or a silent drop:
//
//   * **A persisted output is never distilled twice.** A `raw-durable` job is
//     re-validated from exactly the bytes on disk and a `validated` job hands
//     back its stored `preassignedId`/`idempotencyKey` pairs, so a restart at
//     either barrier makes ZERO model calls and reuses the same identities.
//   * **A crash mid-apply only finishes the unfinished items.** Progress is
//     persisted per item (`appliedItems`), and the transaction receipt of the
//     item already written replays by idempotency key, so neither an ADR number
//     nor a `_meta/log.md` entry is ever minted twice.
//   * **`dryRun` writes receipts only.** The whole vault tree is snapshotted and
//     must come back byte-identical, while the result receipt says what WOULD
//     have been written.
//   * **Failure is bounded and visible.** A validation refusal (R43) records an
//     attempt per pass and ends in a terminal `failed` state with a reason, so a
//     bad model output can neither wedge a turn invisibly nor start a retry storm
//     at startup. `retryJob` is the only way back, and it is explicit.
//   * **An index failure never undoes a committed vault transaction.** The
//     refresh is the last step, its failure is recorded on the receipt, and the
//     note stays.
//
// Every case runs against a REAL temporary vault created by the REAL bootstrap,
// a real throwaway data root and an explicit queue root: nothing here may read or
// write the user's `~/.dsh` or a real vault.
import assert from 'node:assert/strict'
import { spawnSync } from 'node:child_process'
import { createHash, randomUUID } from 'node:crypto'
import { existsSync } from 'node:fs'
import { mkdir, mkdtemp, readFile, readdir, stat, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { dirname, join } from 'node:path'
import { test } from 'node:test'
import { setTimeout as sleep } from 'node:timers/promises'

import {
  createCapture,
  createQueueWorker,
  enqueueTurn,
  processQueue,
  retryJob,
} from '../lib/capture.js'
import { createDiagnostics } from '../lib/debug.js'
import { openDiagnosticJournal, readDiagnosticJournal } from '../lib/diagnostic-journal.js'
import { listCurationProposals, readCurationProposal } from '../lib/curation-proposals.js'
import {
  MAX_CHANGED_PATHS,
  curationChangedPath,
  readChangedSources,
} from '../lib/curation-state.js'
import { openIndex } from '../lib/index-db.js'
import { registerHooks } from '../lib/hooks.js'
import { applyCandidate, createMemoryWithId } from '../lib/memory.js'
import {
  PENDING_SCHEMA,
  PendingError,
  loadPending,
  readResultReceipts,
  writeJobAtomic,
  writeResultReceipt,
} from '../lib/pending.js'
import { createMemoryServices } from '../lib/tools.js'
import { bootstrapVault, parseNote } from '../lib/vault.js'

import { HAS_POSIX_MODES, registerTreeCleanup } from './platform-capabilities.js'

// ---------------------------------------------------------------------------
// Fixtures
// ---------------------------------------------------------------------------

/** Fixed, valid UUIDv4 identity (version nibble `4`, variant nibble `8`). */
const PROJECT_ID = '1c392abb-7b08-42f7-871d-2a379caf9448'
const ID8 = PROJECT_ID.slice(0, 8)
const PROJECT = `Projects/alpha--${ID8}`
const SESSION_ID = 'session-9d4a4c1e-2f1a-4f4e-8b3a-000000000001'
const TO_SEQ = 7
const JOB_ID = 'job-0123456789abcdef0123456789abcdef'
const DECISIONS = `${PROJECT}/Decisions`
const INBOX = `${PROJECT}/Inbox`
const LOG = '_meta/log.md'

/** The §6.4 prefix of each type admissible to automatic distillation. */
const PREFIX = Object.freeze({ decision: 'dec', gotcha: 'got', convention: 'con' })

/** The whitelisted evidence `capture.js` stores: user, one tool run, final text. */
const ALLOWED = Object.freeze([
  { kind: 'user', seq: 2, source: 'user' },
  { kind: 'tool', seq: 4, name: 'bash', ok: true },
  { kind: 'assistant-final', seq: 6 },
])

const sha256 = (value) => createHash('sha256').update(value).digest('hex')
const at = (vault, relative) => join(vault, ...relative.split('/'))
const occurrences = (haystack, needle) => String(haystack).split(needle).length - 1

/**
 * A fresh private root; nothing in this file uses the process cwd or home.
 *
 * The removal is registered through `registerTreeCleanup`, because `node:test`
 * runs hooks in registration order: a plain `t.after(rm)` here would delete the
 * tree BEFORE a later `index.close()`, and Windows answers EBUSY on the
 * still-open sqlite files. Returns the root and the disposal registrar.
 */
async function temporaryRoot(t, name = 'obsidian-mem-t16-auto-') {
  const root = await mkdtemp(join(tmpdir(), name))
  return { root, onCleanup: registerTreeCleanup(t, root) }
}

/** A real bootstrapped vault, a throwaway data root and an explicit queue root. */
async function fixture(t) {
  // The root's registrar is registered first, so its hook runs first: it runs
  // the index/service disposals and only then removes `root`. The data root gets
  // a second registrar whose removal still follows. See `temporaryRoot`.
  const { root, onCleanup } = await temporaryRoot(t)
  const dataRoot = await mkdtemp(join(tmpdir(), 'obsidian-mem-t16-data-'))
  registerTreeCleanup(t, dataRoot)
  const home = join(root, 'home')
  await mkdir(home, { recursive: true })
  const vault = join(root, 'vault')
  const binding = {
    kind: 'bound',
    projectId: PROJECT_ID,
    slug: 'alpha',
    displayName: 'alpha',
    schema: 1,
    vaultRoot: vault,
    relativeDir: PROJECT,
  }
  await bootstrapVault(binding, { dataRoot, home })
  return {
    root,
    dataRoot,
    onCleanup,
    home,
    vault,
    binding,
    queueRoot: join(dataRoot, 'pending'),
    deps: { dataRoot, home },
  }
}

/** The validated plugin config shape, with the distillation knobs under `distill`. */
function baseConfig({ distill = {}, ...rest } = {}) {
  return {
    autoCapture: true,
    captureIdleMs: 90000,
    distill: {
      provider: 'deepseek-official',
      model: 'deepseek-flash',
      maxItems: 12,
      minConfidence: 0.75,
      maxInputChars: 24000,
      maxOutputTokens: 4000,
      timeoutMs: 60000,
      maxRetries: 3,
      dryRun: false,
      ...distill,
    },
    ...rest,
  }
}

/** The shape `enqueueTurn` is contracted to produce. */
function jobFixture(overrides = {}) {
  return {
    schema: PENDING_SCHEMA,
    jobId: JOB_ID,
    sessionId: SESSION_ID,
    projectId: PROJECT_ID,
    fromSeq: 1,
    toSeq: TO_SEQ,
    state: 'pending',
    route: { provider: 'deepseek-official', model: 'deepseek-flash' },
    allowedEvents: [...ALLOWED],
    safeInput:
      '[obsidian-mem pending] session=… project=… turn=1 seq 1-7\n--- user (seq 2) ---\n把调度器改成可插拔后端\n',
    credentialSkips: 0,
    omitted: null,
    attempts: 0,
    output: null,
    createdAt: '2026-09-23T00:00:00.000Z',
    updatedAt: '2026-09-23T00:00:00.000Z',
    ...overrides,
  }
}

/** A real v4 tool-result turn; the private output must never reach a job. */
function failureTurn({ recovered = false, soft = false } = {}) {
  const events = [
    { seq: 0, type: 'turn/start', data: { turn: 1 } },
    {
      seq: 1,
      type: 'user/message',
      data: {
        source: { kind: 'user' },
        content: [{ type: 'text', text: 'Run the probe and explain its outcome.' }],
      },
    },
  ]
  for (let i = 0; i < (recovered ? 4 : 3); i += 1) {
    const ok = recovered && i === 3
    events.push({
      seq: events.length,
      type: 'tool/call',
      data: { name: 'bash', callId: `c${i}`, turn: 1 },
    })
    events.push({
      seq: events.length,
      type: 'tool/result',
      data: {
        turn: 1,
        step: i + 1,
        message: {
          role: 'tool',
          toolCallId: `c${i}`,
          isError: !soft && !ok,
          content: [{ type: 'text', text: ok ? 'ok' : 'ENOENT /private/OUTPUT-SENTINEL' }],
        },
      },
    })
  }
  events.push({
    seq: events.length,
    type: 'assistant/message',
    data: {
      message: {
        content: [
          {
            type: 'text',
            text: recovered
              ? 'The retry succeeded. Its cause remains unverified.'
              : 'The probe still fails. Its cause remains unverified.',
          },
        ],
      },
    },
  })
  events.push({
    seq: events.length,
    type: 'turn/end',
    data: { turn: 1, reason: { kind: 'completed' } },
  })
  return {
    events,
    session: {
      header: { id: SESSION_ID },
      requestContext: () => ({ provider: 'deepseek-official', model: 'deepseek-flash' }),
      snapshotEvents: (from = 0, to) => events.slice(from, to ?? events.length),
    },
  }
}

test('v4 repeated failures reach Inbox through the real queue, restart once and park twins', async (t) => {
  const f = await fixture(t)
  const { events, session } = failureTurn()
  const job = await enqueueTurn({
    session,
    event: events.at(-1),
    binding: f.binding,
    queueRoot: f.queueRoot,
    config: baseConfig(),
  })
  assert.equal(JSON.stringify(job).includes('OUTPUT-SENTINEL'), false)
  const model = stubLlm('{"items":[]}')
  const index = await openIndex({
    vaultRoot: f.vault,
    dataRoot: f.dataRoot,
    backend: 'sqlite',
    projectId: PROJECT_ID,
    home: f.home,
  })
  // Closed through the fixture registrar, before the trees are removed.
  f.onCleanup(() => index.close())
  await index.waitReady(undefined, 10_000)
  const options = queueOptions(f, { llm: model, index: async () => index })
  await processQueue(options)
  const [note] = await memoryNotes(f)
  assert.ok(note.path.startsWith(INBOX))
  assert.equal(note.note.data.assertion, 'inferred')
  assert.equal(note.note.data.status, 'provisional')
  await processQueue(options)
  assert.equal(model.calls.length, 1, 'restart does not distill completed work again')
  assert.equal((await memoryNotes(f)).length, 1)
  assert.equal((await readReceipts(f)).length, 1)
  const repeated = { ...session, header: { ...session.header, id: `session-${randomUUID()}` } }
  await enqueueTurn({
    session: repeated,
    event: events.at(-1),
    binding: f.binding,
    queueRoot: f.queueRoot,
    config: baseConfig(),
  })
  await processQueue(options)
  assert.equal(
    (await memoryNotes(f)).length,
    1,
    'a repeated symptom does not overwrite or duplicate its note',
  )
  const proposals = await listCurationProposals({ dataRoot: f.dataRoot, projectId: PROJECT_ID })
  assert.equal(proposals.total, 1, 'a twin waits for interactive review')
})

test('a described same-tool recovery is stored provisionally in Pitfalls, with no observed cause', async (t) => {
  const f = await fixture(t)
  const { events, session } = failureTurn({ recovered: true })
  await enqueueTurn({
    session,
    event: events.at(-1),
    binding: f.binding,
    queueRoot: f.queueRoot,
    config: baseConfig(),
  })
  const raw = JSON.stringify({
    items: [
      itemFixture({
        type: 'gotcha',
        title: 'Probe retry',
        body: 'The probe failed repeatedly. A retry succeeded. The cause remains unverified.',
        assertion: 'observed',
        status: 'active',
        evidenceSeqs: [3, 5, 7, 9, 10],
      }),
    ],
  })
  await processQueue(queueOptions(f, { llm: stubLlm(raw) }))
  const [note] = await memoryNotes(f)
  assert.ok(note.path.includes('/Pitfalls/'))
  assert.equal(note.note.data.assertion, 'inferred')
  assert.equal(note.note.data.status, 'provisional')
})

test('a user-stated habit reaches Conventions/ through the real queue, tagged', async (t) => {
  // The learned half of the user-habit feature, end to end: the model output is
  // validated by the shipped validator, applied by the shipped transaction engine, and
  // the note on disk carries the plugin's own marker — so a habit is findable by tag
  // rather than only by reading its title. The evidence rule is the whole point: one
  // completed turn can prove the user *said* it, and nothing else.
  const f = await fixture(t)
  await writeJobAtomic(f.queueRoot, jobFixture())
  const raw = JSON.stringify({
    items: [
      itemFixture({
        type: 'convention',
        title: '习惯：前端一律 React + TypeScript',
        body: '前端新页面一律用 React 与 TypeScript，不再引入 Vue。',
        tags: ['dsh-mem/convention'],
        assertion: 'stated',
        evidenceSeqs: [2],
      }),
    ],
  })
  await processQueue(queueOptions(f, { llm: stubLlm(raw) }))

  const [note] = await memoryNotes(f)
  assert.equal(note.note.data.type, 'convention')
  assert.equal(note.note.data.assertion, 'stated')
  assert.ok(note.path.startsWith(`${PROJECT}/Conventions/`), note.path)
  assert.ok(note.note.data.tags.includes('user-habit'), JSON.stringify(note.note.data.tags))
  const [receipt] = await readReceipts(f)
  assert.equal(receipt.result, 'applied')
})

test('a habit without a verifiable user quote is refused through the real queue', async (t) => {
  const f = await fixture(t)
  await writeJobAtomic(f.queueRoot, jobFixture())
  const raw = JSON.stringify({
    items: [
      itemFixture({
        type: 'convention',
        title: '习惯：改动前先跑测试',
        body: '改动一律先跑测试再提交。',
        tags: ['dsh-mem/convention'],
        assertion: 'observed',
        evidenceSeqs: [4],
      }),
    ],
  })
  await processQueue(queueOptions(f, { llm: stubLlm(raw) }))
  assert.deepEqual(await memoryNotes(f), [], 'an ungrounded habit never becomes a preference')
  const [receipt] = await readReceipts(f)
  assert.equal(receipt.refused[0].reason, 'habit-quote-unproven')
})

test('soft-only error text creates no automatic failure note through the real queue', async (t) => {
  const f = await fixture(t)
  const { events, session } = failureTurn({ soft: true })
  await enqueueTurn({
    session,
    event: events.at(-1),
    binding: f.binding,
    queueRoot: f.queueRoot,
    config: baseConfig(),
  })
  const raw = JSON.stringify({
    items: [itemFixture({ type: 'gotcha', assertion: 'observed', evidenceSeqs: [3, 5, 7, 8] })],
  })
  await processQueue(queueOptions(f, { llm: stubLlm(raw) }))
  assert.deepEqual(await memoryNotes(f), [])
  const [receipt] = await readReceipts(f)
  assert.equal(receipt.refused[0].reason, 'soft-only-evidence')
})

test('a hard-failure fallback obeys dryRun and leaves the vault byte-identical', async (t) => {
  const f = await fixture(t)
  const { events, session } = failureTurn()
  await enqueueTurn({
    session,
    event: events.at(-1),
    binding: f.binding,
    queueRoot: f.queueRoot,
    config: baseConfig(),
  })
  const before = await snapshotTree(f.vault)
  await processQueue(
    queueOptions(f, {
      config: baseConfig({ distill: { dryRun: true } }),
      llm: stubLlm('{"items":[]}'),
    }),
  )
  assert.deepEqual(await snapshotTree(f.vault), before)
  const [receipt] = await readReceipts(f)
  assert.equal(receipt.result, 'dry-run')
  assert.equal(receipt.items.length, 1)
})

/** One complete, well-formed candidate item (the Task 15 contract fields only). */
function itemFixture(overrides = {}) {
  return {
    type: 'decision',
    title: '调度器改为可插拔后端',
    body: '结论与适用范围：调度器通过一个后端接口注册，默认实现不变。',
    tags: ['dsh-mem/decision'],
    confidence: 0.91,
    assertion: 'stated',
    status: 'accepted',
    supersedesId: null,
    evidenceSeqs: [2],
    ...overrides,
  }
}

/** Give each item the persisted identity Task 15 assigns before any vault write. */
function withIdentity(items) {
  return items.map((item, index) => ({
    ...item,
    preassignedId: item.preassignedId ?? `${PREFIX[item.type]}-${randomUUID()}`,
    idempotencyKey: item.idempotencyKey ?? `${SESSION_ID}:${TO_SEQ}:${index}`,
  }))
}

/** A job whose validated output is already durable — the resume state. */
function validatedJob(items, overrides = {}) {
  const identified = withIdentity(items)
  return jobFixture({
    state: 'validated',
    output: {
      state: 'validated',
      raw: JSON.stringify({
        items: identified.map(({ preassignedId, idempotencyKey, ...rest }) => rest),
      }),
      items: identified,
      usage: null,
    },
    ...overrides,
  })
}

/** An `llm` stub in the P0-measured `{provider,model,messages,system,maxTokens,signal}` shape. */
function stubLlm(raw, { delayMs = 0 } = {}) {
  const calls = []
  return {
    calls,
    stream(options) {
      calls.push(options)
      const text = typeof raw === 'function' ? raw(options, calls.length) : raw
      return (async function* () {
        if (delayMs > 0) await new Promise((resolve) => setTimeout(resolve, delayMs))
        yield { type: 'text-delta', index: 0, text }
        yield { type: 'block-end', index: 0, block: { type: 'text', text } }
        yield { type: 'finish', reason: { kind: 'stop' } }
      })()
    },
  }
}

/** An `llm` stub whose stream ends in a terminal, non-throwing abort chunk. */
function abortedLlm() {
  const calls = []
  return {
    calls,
    stream(options) {
      calls.push(options)
      return (async function* () {
        yield {
          type: 'finish',
          reason: { kind: 'aborted', failure: { code: 'ABORTED', message: 'aborted by caller' } },
        }
      })()
    },
  }
}

/**
 * A provider-shaped `llm` stub that stays open until the test releases it, and
 * turns a caller-side abort into the terminal chunk the host really emits.
 *
 * The measured contract (`docs/p0-compatibility.md` §8.3) is that a cancellation
 * is DATA, not a throw: the adapter ends the stream with
 * `finish.reason.kind === 'aborted'` (`failure.code === 'ABORTED'`). A stub that
 * always finishes with `stop` would hide exactly the defect the teardown tests
 * exist to catch, so this one watches its own `signal`.
 *
 * `dispose()` switches the stub to the OTHER measured post-teardown shape
 * (`docs/p0-compatibility.md` §9): once the provider fiber is DISPOSED its
 * adapter is unregistered, so a call answers a terminal `error`/`NO_ADAPTER`
 * chunk immediately. A worker that keeps its pass running past disposal and
 * starts another job with the same snapshotted handle therefore records a
 * failure the model never produced.
 *
 * @param {string|Function} raw - the model text, or a function of the request.
 * @returns {object} the stub (`calls`, `opened`, `release`, `dispose`, `stream`).
 */
function inFlightLlm(raw) {
  const calls = []
  let openedResolve
  const opened = new Promise((resolve) => {
    openedResolve = resolve
  })
  let releaseResolve
  const release = new Promise((resolve) => {
    releaseResolve = resolve
  })
  const stub = {
    calls,
    opened,
    disposed: false,
    release: () => releaseResolve(),
    dispose() {
      stub.disposed = true
    },
    stream(options) {
      calls.push(options)
      if (stub.disposed) {
        return (async function* () {
          yield {
            type: 'finish',
            reason: {
              kind: 'error',
              failure: {
                code: 'NO_ADAPTER',
                message: 'no adapter registered for provider "deepseek-official"',
              },
            },
          }
        })()
      }
      return (async function* () {
        // Open and streaming: from here the only endings are the caller's signal
        // and the test's release.
        yield { type: 'block-start', index: 0, block: { type: 'reasoning' } }
        openedResolve()
        const aborted = new Promise((resolve) => {
          const signal = options.signal
          if (signal === undefined || signal === null) return
          if (signal.aborted === true) {
            resolve()
            return
          }
          signal.addEventListener('abort', () => resolve(), { once: true })
        })
        await Promise.race([aborted, release])
        if (options.signal?.aborted === true) {
          yield {
            type: 'finish',
            reason: { kind: 'aborted', failure: { code: 'ABORTED', message: 'aborted by caller' } },
          }
          return
        }
        const text = typeof raw === 'function' ? raw(options) : raw
        yield { type: 'text-delta', index: 0, text }
        yield { type: 'block-end', index: 0, block: { type: 'text', text } }
        yield { type: 'finish', reason: { kind: 'stop' } }
      })()
    },
  }
  return stub
}

/** The default worker options for a fixture: explicit roots, no debounce, no backoff. */
function queueOptions(f, overrides = {}) {
  return {
    queueRoot: f.queueRoot,
    dataRoot: f.dataRoot,
    home: f.home,
    config: baseConfig(),
    resolveBinding: () => f.binding,
    debounceMs: 0,
    retryBackoffMs: 0,
    warn: () => {},
    ...overrides,
  }
}

/** Every file under one tree, as `relativePath:sha256`, sorted. */
async function snapshotTree(root) {
  const found = []
  async function walk(directory, prefix) {
    let entries
    try {
      entries = await readdir(directory, { withFileTypes: true })
    } catch (error) {
      if (error.code === 'ENOENT') return
      throw error
    }
    for (const entry of [...entries].sort((left, right) => (left.name < right.name ? -1 : 1))) {
      const relative = prefix === '' ? entry.name : `${prefix}/${entry.name}`
      if (entry.isDirectory()) {
        await walk(join(directory, entry.name), relative)
        continue
      }
      if (!entry.isFile()) continue
      found.push(`${relative}:${sha256(await readFile(join(directory, entry.name)))}`)
    }
  }
  await walk(root, '')
  return found.sort()
}

/** Every note inside the bound project, with its parsed frontmatter. */
async function listProjectNotes(f) {
  const root = at(f.vault, PROJECT)
  const found = []
  async function walk(directory, prefix) {
    let entries
    try {
      entries = await readdir(directory, { withFileTypes: true })
    } catch (error) {
      if (error.code === 'ENOENT') return
      throw error
    }
    for (const entry of [...entries].sort((left, right) => (left.name < right.name ? -1 : 1))) {
      if (entry.name.startsWith('.')) continue
      const relative = prefix === '' ? entry.name : `${prefix}/${entry.name}`
      if (entry.isDirectory()) {
        await walk(join(directory, entry.name), relative)
        continue
      }
      if (!entry.isFile() || !entry.name.toLowerCase().endsWith('.md')) continue
      const bytes = await readFile(join(directory, entry.name))
      found.push({
        path: `${PROJECT}/${relative}`,
        bytes,
        hash: sha256(bytes),
        note: parseNote(bytes),
      })
    }
  }
  await walk(root, '')
  return found
}

/** The decision|gotcha|convention notes of a project (the only auto-writable types). */
async function memoryNotes(f) {
  return (await listProjectNotes(f)).filter((entry) =>
    ['decision', 'gotcha', 'convention'].includes(entry.note.data.type),
  )
}

/** The receipts written for one project, oldest first. */
async function readReceipts(f) {
  return readResultReceipts(f.queueRoot, PROJECT_ID)
}

/** Read one vault file, or `''` when it does not exist. */
async function readVault(f, relative) {
  try {
    return await readFile(at(f.vault, relative), 'utf8')
  } catch (error) {
    if (error.code === 'ENOENT') return ''
    throw error
  }
}

/** The candidate notes parked in the explicit inbox (the MOC itself is not one). */
async function inboxCandidates(f) {
  return (await listProjectNotes(f)).filter(
    (entry) => entry.path.startsWith(INBOX) && !entry.path.endsWith('/index.md'),
  )
}

/** The job on disk, or `null`. */
async function jobOnDisk(f, jobId = JOB_ID) {
  return (await loadPending(f.queueRoot)).find((job) => job.jobId === jobId) ?? null
}

/** A recording per-item apply seam wrapping the real `applyCandidate`. */
function recordingApply() {
  const calls = []
  return {
    calls,
    seam: async (binding, job, item, deps) => {
      calls.push({ idempotencyKey: item.idempotencyKey, preassignedId: item.preassignedId })
      return applyCandidate(binding, job, item, deps)
    },
  }
}

/** Seed one real decision note and return its identity and bytes. */
async function seedDecision(f, { title = '旧结论', idempotencyKey = `seed:${randomUUID()}` } = {}) {
  const id = `dec-${randomUUID()}`
  const written = await createMemoryWithId(
    f.binding,
    {
      preassignedId: id,
      idempotencyKey,
      type: 'decision',
      title,
      body: '旧结论正文。',
      status: 'accepted',
      confidence: 0.9,
      assertion: 'stated',
    },
    { dataRoot: f.dataRoot, home: f.home },
  )
  return written
}

// ---------------------------------------------------------------------------
// The happy path and the two no-op results
// ---------------------------------------------------------------------------

test('a validated job applies through createMemoryWithId: one note, one MOC line, one log entry', async (t) => {
  const f = await fixture(t)
  const job = validatedJob([itemFixture()])
  const items = job.output.items
  await writeJobAtomic(f.queueRoot, job)

  const summary = await processQueue(queueOptions(f))
  assert.equal(summary.completed, 1)
  assert.equal(summary.failed, 0)
  assert.equal(summary.deferred, 0)

  const notes = await memoryNotes(f)
  assert.equal(notes.length, 1)
  assert.equal(notes[0].note.data.id, items[0].preassignedId)
  assert.equal(notes[0].note.data.type, 'decision')
  assert.equal(notes[0].note.data.trust, 'agent')
  assert.equal(notes[0].note.data.session, SESSION_ID)
  assert.match(notes[0].path, /Decisions\/ADR-1-/)

  // The MOC's generated region lists the note; the log carries exactly one block.
  const moc = await readVault(f, `${DECISIONS}/index.md`)
  assert.equal(occurrences(moc, notes[0].path.replace(/\.md$/, '')), 1)
  const log = await readVault(f, LOG)
  assert.equal(occurrences(log, items[0].idempotencyKey), 1)

  // The finished job is deleted (spec §10.1) and its receipt is the completion marker.
  assert.equal(await jobOnDisk(f), null)
  const receipts = await readReceipts(f)
  assert.equal(receipts.length, 1)
  assert.equal(receipts[0].result, 'applied')
  assert.equal(receipts[0].items.length, 1)
  assert.equal(receipts[0].items[0].id, items[0].preassignedId)
  assert.equal(receipts[0].items[0].path, notes[0].path)
})

test('a candidate duplicating an existing note is parked for review instead of skipped', async (t) => {
  // Rewritten by Task 3. This is the end-to-end shape of the duplicate rule: a
  // real job through the real apply path, with a real index behind the lookup.
  // Measured on this repository's own vault, 42 same-type pairs are near
  // duplicates — and the old outcome was that the second fact vanished as
  // `skipped` with only a diagnostic recording it. The candidate is now parked
  // whole, the job still completes, and the item is marked applied *because the
  // proposal is durable*, which is what keeps a retry from writing it twice.
  const f = await fixture(t)
  const seeded = await seedDecision(f, { title: '调度器后端选型' })
  const index = await openIndex({
    vaultRoot: f.vault,
    dataRoot: f.dataRoot,
    backend: 'sqlite',
    projectId: f.binding.projectId,
    home: f.home,
  })
  f.onCleanup(() => index.close().catch(() => {}))
  await index.waitReady(undefined, 10_000)

  const job = validatedJob([itemFixture({ title: '调度器后端选型（重写）' })])
  await writeJobAtomic(f.queueRoot, job)
  const summary = await processQueue(queueOptions(f, { index: async () => index }))

  assert.equal(summary.completed, 1)
  assert.equal(summary.failed, 0)
  const notes = await memoryNotes(f)
  assert.equal(notes.length, 1, 'the duplicate was not written a second time')
  assert.equal(notes[0].note.data.id, seeded.id)

  const [receipt] = await readReceipts(f)
  assert.equal(receipt.result, 'applied')
  assert.equal(receipt.items[0].id, null, 'a parked candidate wrote no note')
  assert.equal(receipt.items[0].path, null)
  assert.match(receipt.items[0].proposalId, /^[0-9a-f]{64}$/u)
  const parked = await readCurationProposal({
    dataRoot: f.dataRoot,
    projectId: f.binding.projectId,
    proposalId: receipt.items[0].proposalId,
  })
  assert.equal(parked.kind, 'near-duplicate')
  assert.equal(parked.state, 'pending')
  assert.equal(parked.operation.kind, 'create-separate')
  assert.equal(parked.operation.item.idempotencyKey, job.output.items[0].idempotencyKey)

  // A second pass over the same job is a receipt replay, not a second proposal:
  // the job is gone, and the queue holds exactly one entry for the one item.
  const listed = await listCurationProposals({
    dataRoot: f.dataRoot,
    projectId: f.binding.projectId,
    state: 'pending',
  })
  assert.equal(listed.total, 1)

  // The parked candidate is still executable by the *review* path: approving it
  // writes exactly the note the automatic path refused to write.
  const approved = await applyCandidate(
    f.binding,
    { sessionId: SESSION_ID },
    parked.operation.item,
    { dataRoot: f.dataRoot, home: f.home },
  )
  assert.equal(approved.id, parked.operation.item.preassignedId)
  assert.equal((await memoryNotes(f)).length, 2)
})

test('an empty result writes a no-memory receipt and touches nothing', async (t) => {
  const f = await fixture(t)
  const before = await snapshotTree(f.vault)
  await writeJobAtomic(f.queueRoot, jobFixture())
  const llm = stubLlm('{"items":[]}')

  const summary = await processQueue(queueOptions(f, { llm }))
  assert.equal(summary.completed, 1)
  assert.equal(llm.calls.length, 1)
  assert.deepEqual(await memoryNotes(f), [])
  assert.deepEqual(
    await snapshotTree(f.vault),
    before,
    'an empty distillation writes no vault byte',
  )

  const [receipt] = await readReceipts(f)
  assert.equal(receipt.result, 'no-memory')
  assert.deepEqual(receipt.items, [])
  assert.equal(await jobOnDisk(f), null)
})

test('dryRun writes a dry-run receipt and leaves the whole vault tree byte-identical', async (t) => {
  const f = await fixture(t)
  const before = await snapshotTree(f.vault)
  await writeJobAtomic(f.queueRoot, jobFixture())
  const llm = stubLlm(JSON.stringify({ items: [itemFixture()] }))

  const summary = await processQueue(
    queueOptions(f, { llm, config: baseConfig({ distill: { dryRun: true } }) }),
  )
  assert.equal(summary.completed, 1)
  assert.equal(llm.calls.length, 1)

  assert.deepEqual(
    (await listProjectNotes(f)).filter((entry) =>
      ['decision', 'gotcha', 'convention'].includes(entry.note.data.type),
    ),
    [],
  )
  assert.deepEqual(
    await snapshotTree(f.vault),
    before,
    'dryRun changes no note, MOC, hot file or log byte',
  )

  const receipts = await readReceipts(f)
  assert.equal(receipts.at(-1).result, 'dry-run')
  assert.equal(receipts.at(-1).dryRun, true)
  assert.equal(receipts.at(-1).items.length, 1)
  assert.equal(receipts.at(-1).items[0].type, 'decision')
  assert.match(receipts.at(-1).items[0].preassignedId, /^dec-/)
  assert.equal(await jobOnDisk(f), null, 'a dry run still finishes the job it observed')
})

test('a dry run of an empty result is visibly finished as no-memory', async (t) => {
  const f = await fixture(t)
  await writeJobAtomic(f.queueRoot, jobFixture())
  const llm = stubLlm('{"items":[]}')

  await processQueue(queueOptions(f, { llm, config: baseConfig({ distill: { dryRun: true } }) }))
  const [receipt] = await readReceipts(f)
  assert.equal(receipt.result, 'no-memory')
  assert.equal(receipt.dryRun, true)
})

// ---------------------------------------------------------------------------
// Deferral: no model call is worth making yet
// ---------------------------------------------------------------------------

test('a missing llm defers the job with zero attempts and leaves it on disk', async (t) => {
  const f = await fixture(t)
  await writeJobAtomic(f.queueRoot, jobFixture())

  const summary = await processQueue(queueOptions(f, { llm: undefined }))
  assert.equal(summary.completed, 0)
  assert.equal(summary.deferred, 1)
  assert.equal(summary.failed, 0)

  const job = await jobOnDisk(f)
  assert.notEqual(job, null)
  assert.equal(job.state, 'deferred')
  assert.equal(job.deferredReason, 'no-route')
  assert.equal(job.attempts, 0)
  assert.equal(job.output, null)
})

test('a project that cannot be resolved defers without consuming an attempt', async (t) => {
  const f = await fixture(t)
  await writeJobAtomic(f.queueRoot, jobFixture())

  const summary = await processQueue(
    queueOptions(f, { llm: stubLlm('{"items":[]}'), resolveBinding: () => null }),
  )
  assert.equal(summary.deferred, 1)
  const job = await jobOnDisk(f)
  assert.equal(job.state, 'deferred')
  assert.equal(job.deferredReason, 'no-binding')
  assert.equal(job.attempts, 0)
})

test('a deferred job is retried by the worker timer alone, with no new capture or restart', async (t) => {
  const f = await fixture(t)
  await writeJobAtomic(f.queueRoot, jobFixture())
  // The first pass runs with no llm at all: the job defers, and the timer the pass
  // armed must be what brings it back (no capture, no restart, no external kick).
  let llm
  const worker = createQueueWorker({
    queueRoot: f.queueRoot,
    dataRoot: f.dataRoot,
    home: f.home,
    config: baseConfig({ captureIdleMs: 1000 }),
    resolveBinding: () => f.binding,
    retryBackoffMs: 0,
    warn: () => {},
    getLlm: () => llm,
  })
  // Stopped before the trees go: a running worker still polls the queue files.
  f.onCleanup(() => worker.stop())

  const first = await worker.pass()
  assert.equal(first.deferred, 1)
  assert.equal((await jobOnDisk(f)).state, 'deferred')
  assert.ok(Number.isFinite(first.nextDueAt), 'a deferral schedules a re-check')
  assert.ok(first.nextDueAt > Date.now(), 'and it is in the future, not a spin')

  llm = stubLlm(JSON.stringify({ items: [itemFixture()] }))
  // Wait for the JOB to finish (not just for the note to appear): the note commits
  // before the receipt and the deletion, so polling the note alone would race.
  const finished = await waitFor(
    () => jobOnDisk(f),
    (job) => job === null,
    { timeoutMs: 8000 },
  )
  assert.equal(finished, null, 'the armed timer retried the deferred job on its own')
  assert.equal(llm.calls.length, 1)
  assert.equal((await memoryNotes(f)).length, 1)
})

// ---------------------------------------------------------------------------
// Bounded failure: R43's terminal, visible refusal
// ---------------------------------------------------------------------------

test('a validation refusal records an attempt per pass and ends failed with a reason', async (t) => {
  const f = await fixture(t)
  await writeJobAtomic(f.queueRoot, jobFixture())
  const llm = stubLlm('not json at all')

  for (let pass = 1; pass <= 3; pass += 1) {
    await processQueue(queueOptions(f, { llm }))
    const job = await jobOnDisk(f)
    assert.equal(job.attempts, pass, `pass ${pass} records its attempt`)
    if (pass < 3)
      assert.equal(job.state, 'raw-durable', 'the retry resumes from the durable barrier')
  }

  const failed = await jobOnDisk(f)
  assert.equal(failed.state, 'failed')
  assert.equal(failed.attempts, 3)
  assert.equal(failed.lastError.code, 'not-json')
  assert.equal(typeof failed.lastError.message, 'string')
  assert.equal(failed.output.state, 'raw-durable', 'the refused bytes stay inspectable')
  // The refusal happened AFTER the raw barrier, so exactly one model call was made
  // for all three attempts: the resume path re-validates the same bytes.
  assert.equal(llm.calls.length, 1)

  const again = await processQueue(queueOptions(f, { llm }))
  assert.equal(again.failed, 1)
  assert.equal(again.completed, 0)
  assert.equal(llm.calls.length, 1, 'a terminally failed job is never retried at startup')
})

test('a transient stream failure retries with backoff, then fails with the stream reason', async (t) => {
  const f = await fixture(t)
  await writeJobAtomic(f.queueRoot, jobFixture())
  const llm = abortedLlm()

  for (let pass = 1; pass <= 3; pass += 1) await processQueue(queueOptions(f, { llm }))
  const job = await jobOnDisk(f)
  assert.equal(job.state, 'failed')
  assert.equal(job.attempts, 3)
  assert.equal(job.lastError.code, 'aborted')
  assert.equal(job.output, null, 'a terminal abort reaches no durability barrier')
  assert.equal(llm.calls.length, 3, 'each transient retry made exactly one call')
})

test('a job whose next attempt is in the future is not retried by the next pass', async (t) => {
  const f = await fixture(t)
  await writeJobAtomic(f.queueRoot, jobFixture())
  const llm = abortedLlm()

  const first = await processQueue(queueOptions(f, { llm, retryBackoffMs: 3_600_000 }))
  assert.equal(first.deferred, 1)
  assert.equal(first.failed, 0)
  const job = await jobOnDisk(f)
  assert.equal(job.state, 'pending')
  assert.equal(job.attempts, 1)
  assert.ok(Date.parse(job.nextAttemptAt) > Date.now(), 'the retry is scheduled in the future')
  assert.ok(first.nextDueAt > Date.now(), 'the worker is told when to wake up')

  await processQueue(queueOptions(f, { llm, retryBackoffMs: 3_600_000 }))
  assert.equal(llm.calls.length, 1, 'no startup retry storm')
})

test('retryJob explicitly requeues a terminally failed job and refuses a healthy one', async (t) => {
  const f = await fixture(t)
  await writeJobAtomic(f.queueRoot, jobFixture())
  const llm = abortedLlm()
  for (let pass = 0; pass < 3; pass += 1) await processQueue(queueOptions(f, { llm }))
  const failed = await jobOnDisk(f)
  assert.equal(failed.state, 'failed')
  assert.equal(failed.attempts, 3)

  const revived = await retryJob(JOB_ID, { queueRoot: f.queueRoot })
  assert.equal(
    revived.state,
    'pending',
    'a job with no durable output restarts from the model call',
  )
  assert.equal(revived.attempts, 0)
  assert.equal(revived.nextAttemptAt, null)
  assert.equal(revived.previousAttempts, 3, 'the prior attempt count stays inspectable')

  const healthy = stubLlm(JSON.stringify({ items: [itemFixture()] }))
  // The retry is explicit, so the capture debounce does not apply to it.
  const summary = await processQueue(queueOptions(f, { llm: healthy, debounceMs: 90_000 }))
  assert.equal(summary.completed, 1)
  assert.equal((await memoryNotes(f)).length, 1)

  await writeJobAtomic(f.queueRoot, jobFixture({ jobId: 'job-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa' }))
  await assert.rejects(
    () => retryJob('job-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa', { queueRoot: f.queueRoot }),
    (error) => error instanceof PendingError && error.code === 'retry-not-failed',
  )
  assert.equal(await retryJob('job-does-not-exist', { queueRoot: f.queueRoot }), null)
})

// ---------------------------------------------------------------------------
// Crash resume: the two durability barriers
// ---------------------------------------------------------------------------

test('a fault before the raw barrier leaves no output and the next pass calls the model once more', async (t) => {
  const f = await fixture(t)
  await writeJobAtomic(f.queueRoot, jobFixture())
  const llm = stubLlm(JSON.stringify({ items: [itemFixture()] }))

  const first = await processQueue(
    queueOptions(f, {
      llm,
      beforePersist: (jobId, output) => {
        if (output.state === 'raw-durable') throw new Error('injected-before-output')
      },
    }),
  )
  assert.equal(first.deferred, 1)
  const interrupted = await jobOnDisk(f)
  assert.equal(interrupted.output, null, 'nothing durable was written')
  assert.equal(interrupted.attempts, 1)
  assert.match(interrupted.lastError.message, /injected-before-output/)

  const second = await processQueue(queueOptions(f, { llm }))
  assert.equal(second.completed, 1)
  assert.equal(llm.calls.length, 2, 'no barrier means the model call is legitimately repeated')
  assert.equal((await memoryNotes(f)).length, 1, 'and it is applied exactly once')
})

test('a raw-durable job resumes by re-validating the same bytes with no second model call', async (t) => {
  const f = await fixture(t)
  await writeJobAtomic(f.queueRoot, jobFixture())
  const llm = stubLlm(JSON.stringify({ items: [itemFixture()] }))

  const first = await processQueue(
    queueOptions(f, {
      llm,
      afterPersist: (jobId, output) => {
        if (output.state === 'raw-durable') throw new Error('injected-after-output')
      },
    }),
  )
  assert.equal(first.deferred, 1)
  const interrupted = await jobOnDisk(f)
  assert.equal(interrupted.output.state, 'raw-durable')
  const rawBytes = interrupted.output.raw
  assert.equal(interrupted.attempts, 1)

  const second = await processQueue(queueOptions(f, { llm }))
  assert.equal(second.completed, 1)
  assert.equal(llm.calls.length, 1, 'the persisted bytes are re-validated, never re-requested')

  const notes = await memoryNotes(f)
  assert.equal(notes.length, 1)
  // The identity minted on the resume is the one that was persisted and applied.
  const receipt = (await readReceipts(f)).at(-1)
  assert.equal(receipt.result, 'applied')
  assert.equal(receipt.items[0].id, notes[0].note.data.id)
  assert.match(rawBytes, /"items"/)
})

// ---------------------------------------------------------------------------
// Crash mid-apply: only the unfinished items, with stable identities
// ---------------------------------------------------------------------------

test('a crash after the first item resumes with only the unfinished second item', async (t) => {
  const f = await fixture(t)
  const items = [itemFixture({ title: '第一条结论' }), itemFixture({ title: '第二条结论' })]
  const job = validatedJob(items)
  const ids = job.output.items.map((item) => item.preassignedId)
  await writeJobAtomic(f.queueRoot, job)

  const apply = recordingApply(f)
  const first = await processQueue(
    queueOptions(f, {
      writeMemory: apply.seam,
      beforeApply: (binding, current, item, index) => {
        if (index === 1) throw new Error('injected-before-second-item')
      },
    }),
  )
  assert.equal(first.deferred, 1)
  const interrupted = await jobOnDisk(f)
  assert.equal(interrupted.attempts, 1)
  assert.deepEqual(
    interrupted.output.items.map((item) => item.preassignedId),
    ids,
    'identities are byte-stable',
  )
  assert.equal(interrupted.appliedItems.length, 1)
  assert.equal(interrupted.appliedItems[0].idempotencyKey, `${SESSION_ID}:${TO_SEQ}:0`)

  const second = recordingApply(f)
  const resumed = await processQueue(queueOptions(f, { writeMemory: second.seam }))
  assert.equal(resumed.completed, 1)
  assert.deepEqual(
    second.calls.map((entry) => entry.idempotencyKey),
    [`${SESSION_ID}:${TO_SEQ}:1`],
    'only the unfinished item is applied',
  )

  const notes = await memoryNotes(f)
  assert.equal(notes.length, 2, 'no third note from the resumed item')
  assert.deepEqual(
    notes.map((entry) => entry.note.data.id).sort(),
    [...ids].sort(),
    'the same identities survive the resume',
  )
  assert.match(notes.map((entry) => entry.path).join('\n'), /ADR-1-/)
  assert.match(notes.map((entry) => entry.path).join('\n'), /ADR-2-/)
  const names = (await readdir(at(f.vault, DECISIONS))).filter((name) => name.endsWith('.md'))
  assert.equal(
    names.filter((name) => name.startsWith('ADR-3-')).length,
    0,
    'no duplicate ADR number was minted',
  )
})

test('a replayed parked item keeps its proposal id in the receipt', async (t) => {
  // A parked candidate writes no vault byte, so `appliedItems[].proposalId` is the only
  // durable handle to its proposal. The replay branch re-reports the item as `skipped`
  // from that record, and it used to drop the proposal id, so a resumed job's receipt
  // said a parked item had been skipped without saying what it was parked as.
  const f = await fixture(t)
  const old = await seedDecision(f)
  const items = [
    itemFixture({ title: '停放的第一条', supersedesId: old.id }),
    itemFixture({ title: '第二条结论' }),
  ]
  await writeJobAtomic(f.queueRoot, validatedJob(items))

  const first = await processQueue(
    queueOptions(f, {
      beforeApply: (binding, current, item, index) => {
        if (index === 1) throw new Error('injected-before-second-item')
      },
    }),
  )
  assert.equal(first.deferred, 1)
  const interrupted = await jobOnDisk(f)
  const parkedId = interrupted.appliedItems[0].proposalId
  assert.match(parkedId, /^[0-9a-f]{64}$/u, 'the first item really was parked')

  const resumed = await processQueue(queueOptions(f))
  assert.equal(resumed.completed, 1)
  const receipt = (await readReceipts(f)).at(-1)
  const replayed = receipt.items[0]
  assert.equal(replayed.skipped, true)
  assert.equal(replayed.id, null)
  assert.equal(replayed.path, null)
  assert.equal(replayed.proposalId, parkedId, 'the replay still names the proposal')
})

test('a crash after a note write but before the progress record replays its receipt', async (t) => {
  const f = await fixture(t)
  const items = [itemFixture({ title: '第一条结论' }), itemFixture({ title: '第二条结论' })]
  const job = validatedJob(items)
  await writeJobAtomic(f.queueRoot, job)

  const first = await processQueue(
    queueOptions(f, {
      afterApply: (binding, current, item, index) => {
        if (index === 1) throw new Error('injected-after-second-note')
      },
    }),
  )
  assert.equal(first.deferred, 1)
  const interrupted = await jobOnDisk(f)
  assert.equal(interrupted.appliedItems.length, 1, 'the second item was written but not recorded')
  assert.equal((await memoryNotes(f)).length, 2, 'both notes exist on disk')

  const second = recordingApply(f)
  const resumed = await processQueue(queueOptions(f, { writeMemory: second.seam }))
  assert.equal(resumed.completed, 1)
  assert.deepEqual(
    second.calls.map((entry) => entry.idempotencyKey),
    [`${SESSION_ID}:${TO_SEQ}:1`],
  )

  const notes = await memoryNotes(f)
  assert.equal(notes.length, 2, 'the replay created no third note')
  const log = await readVault(f, LOG)
  for (const item of job.output.items) {
    assert.equal(
      occurrences(log, item.idempotencyKey),
      1,
      `${item.idempotencyKey} appears exactly once in the log`,
    )
  }
  assert.equal(
    (await readdir(at(f.vault, DECISIONS))).filter((name) => name.startsWith('ADR-3-')).length,
    0,
  )
})

test('a fault after the result receipt but before the job deletion does not double-apply', async (t) => {
  const f = await fixture(t)
  const job = validatedJob([itemFixture()])
  await writeJobAtomic(f.queueRoot, job)

  const first = await processQueue(
    queueOptions(f, {
      beforeComplete: () => {
        throw new Error('injected-before-complete')
      },
    }),
  )
  assert.equal(first.deferred, 1)
  assert.notEqual(await jobOnDisk(f), null, 'the receipt exists but the job was not deleted')
  assert.equal((await readReceipts(f)).length, 1)

  const second = await processQueue(queueOptions(f))
  assert.equal(second.completed, 1)
  assert.equal((await memoryNotes(f)).length, 1, 'the item replayed instead of being duplicated')
  assert.equal(
    (await readReceipts(f)).length,
    1,
    'the receipt is keyed by job, so it is upserted not appended',
  )
})

// ---------------------------------------------------------------------------
// The index is the last step and never rolls a write back
// ---------------------------------------------------------------------------

test('a working index is refreshed for each applied item', async (t) => {
  const f = await fixture(t)
  const items = [itemFixture({ title: '第一条结论' }), itemFixture({ title: '第二条结论' })]
  await writeJobAtomic(f.queueRoot, validatedJob(items))
  const refreshes = []

  const summary = await processQueue(
    queueOptions(f, {
      index: (binding) => ({
        refresh: async () => {
          refreshes.push(binding.projectId)
        },
      }),
    }),
  )
  assert.equal(summary.completed, 1)
  assert.deepEqual(refreshes, [PROJECT_ID, PROJECT_ID])
  assert.equal((await readReceipts(f)).at(-1).index, 'refreshed')
})

test('an index failure does not undo a successful vault transaction', async (t) => {
  const f = await fixture(t)
  const job = validatedJob([itemFixture()])
  const items = job.output.items
  await writeJobAtomic(f.queueRoot, job)

  const summary = await processQueue(
    queueOptions(f, {
      index: () => ({
        refresh: async () => {
          throw new Error('index-down')
        },
      }),
    }),
  )
  assert.equal(summary.completed, 1)
  const notes = await memoryNotes(f)
  assert.equal(notes.length, 1, 'the committed note stays')
  assert.equal(notes[0].note.data.id, items[0].preassignedId)
  const receipt = (await readReceipts(f)).at(-1)
  assert.equal(receipt.result, 'applied')
  assert.equal(receipt.index, 'failed')
  assert.equal(await jobOnDisk(f), null)
})

test('a fault injected before the index update leaves the note committed', async (t) => {
  const f = await fixture(t)
  const job = validatedJob([itemFixture()])
  await writeJobAtomic(f.queueRoot, job)
  const refreshes = []

  const summary = await processQueue(
    queueOptions(f, {
      index: () => ({
        refresh: async () => {
          refreshes.push(1)
        },
      }),
      beforeIndex: () => {
        throw new Error('injected-before-index')
      },
    }),
  )
  assert.equal(summary.completed, 1)
  assert.equal((await memoryNotes(f)).length, 1)
  assert.deepEqual(refreshes, [], 'the refresh never ran')
  assert.equal((await readReceipts(f)).at(-1).index, 'failed')
})

// ---------------------------------------------------------------------------
// Supersede: evidence, ownership and the old file's hash
// ---------------------------------------------------------------------------

test('a supersede whose old file changed mid-apply parks the candidate, never the new revision', async (t) => {
  // Rewritten by Task 3. The old case exercised the hash race through the inbox
  // fallback: the engine saw `hash-mismatch` and wrote the candidate into
  // `Inbox/`. Now the candidate never reaches a transaction at all — it is parked
  // for review — so the race is exercised as "the proposal's evidence is the
  // revision that is actually on disk", which is what makes the later approval's
  // hash recheck meaningful. The coverage is kept: the human edit survives and is
  // never relinked, and no second decision note is written.
  const f = await fixture(t)
  const old = await seedDecision(f)
  const before = await readFile(at(f.vault, old.path))
  const item = itemFixture({ title: '新结论', supersedesId: old.id })
  await writeJobAtomic(f.queueRoot, validatedJob([item]))

  const summary = await processQueue(
    queueOptions(f, {
      afterScan: async ({ path }) => {
        const absolute = at(f.vault, path)
        const current = await readFile(absolute, 'utf8')
        await writeFile(absolute, `${current}\n人工补充的一行。\n`)
      },
    }),
  )
  assert.equal(summary.completed, 1)

  const after = await readFile(at(f.vault, old.path))
  assert.notEqual(sha256(after), sha256(before), 'the human edit is the revision on disk')
  assert.match(after.toString('utf8'), /人工补充的一行。/)
  assert.doesNotMatch(
    after.toString('utf8'),
    /superseded_by: dec-/,
    'the old note was not relinked',
  )
  assert.deepEqual(
    (await readdir(at(f.vault, DECISIONS))).filter((name) => name.startsWith('ADR-')),
    ['ADR-1-旧结论.md'],
    'the parked candidate took no ADR number',
  )
  assert.deepEqual(await inboxCandidates(f), [], 'nothing was written anywhere')

  const receipt = (await readReceipts(f)).at(-1)
  assert.equal(receipt.items[0].superseded, false)
  assert.deepEqual(receipt.items[0].conflicts, [])
  assert.equal(receipt.items[0].inbox, false)
  assert.equal(receipt.items[0].id, null)

  // The evidence names the bytes the human left behind, not the hash the pre-check
  // read before the edit: an approval re-verifies these, so a stale hash here would
  // make every later approval refuse a target that never moved again.
  const parked = await readCurationProposal({
    dataRoot: f.dataRoot,
    projectId: f.binding.projectId,
    proposalId: receipt.items[0].proposalId,
  })
  assert.deepEqual(parked.sources, [{ id: old.id, path: old.path, hash: sha256(after) }])
  assert.equal(parked.operation.supersedesId, old.id)
})

test('a supersede target that no longer exists parks the candidate in the inbox', async (t) => {
  const f = await fixture(t)
  const missing = `dec-${randomUUID()}`
  await writeJobAtomic(f.queueRoot, validatedJob([itemFixture({ supersedesId: missing })]))

  await processQueue(queueOptions(f))
  const receipt = (await readReceipts(f)).at(-1)
  assert.equal(receipt.items[0].conflicts[0].reason, 'note-not-found')
  assert.equal((await inboxCandidates(f)).length, 1)
})

test('a human-owned supersede target is never rewritten', async (t) => {
  const f = await fixture(t)
  const id = `dec-${randomUUID()}`
  const handWritten = `---\nid: ${id}\ntype: decision\ntitle: 手写结论\nstatus: active\ntrust: owner\nharness: dsh\n---\n手写正文。\n`
  const path = `${DECISIONS}/手写结论.md`
  await writeFile(at(f.vault, path), handWritten)
  await writeJobAtomic(f.queueRoot, validatedJob([itemFixture({ supersedesId: id })]))

  await processQueue(queueOptions(f))
  assert.equal(await readVault(f, path), handWritten, 'the human file is byte-identical')
  const receipt = (await readReceipts(f)).at(-1)
  assert.equal(receipt.items[0].conflicts[0].reason, 'human-owned')
})

test('a legitimate supersede is parked for review and the old note stays active', async (t) => {
  // Rewritten by Task 3. The old case proved that a model-supplied `supersedesId`
  // rewrote the old note's status automatically. A model's judgment that a
  // conclusion changed is exactly the semantic decision the design reserves for a
  // human: the candidate is now parked whole, the predecessor is left `active`,
  // and the **receipt** carries the proposal so the job's own record names it.
  // The coverage that mattered is kept — a supersede candidate never overwrites
  // the old body — and strengthened, because not even its status moves.
  const f = await fixture(t)
  const old = await seedDecision(f)
  const oldBytes = await readFile(at(f.vault, old.path))
  const job = validatedJob([itemFixture({ title: '新结论', supersedesId: old.id })])
  await writeJobAtomic(f.queueRoot, job)

  await processQueue(queueOptions(f))
  const receipt = (await readReceipts(f)).at(-1)
  assert.equal(receipt.result, 'applied')
  assert.equal(receipt.items[0].superseded, false, 'no supersede was applied')
  assert.equal(receipt.items[0].id, null)
  assert.equal(receipt.items[0].path, null)
  assert.deepEqual(receipt.items[0].conflicts, [])
  assert.match(receipt.items[0].proposalId, /^[0-9a-f]{64}$/u)

  const after = await readFile(at(f.vault, old.path))
  assert.equal(Buffer.compare(after, oldBytes), 0, 'the old note is byte-identical')
  // The seeded decision is `status: accepted`, which is what `seedDecision` writes;
  // the point is that it is still whatever it was, not `superseded`.
  assert.equal(parseNote(after).data.status, 'accepted', 'the predecessor was not relinked')
  assert.equal((await memoryNotes(f)).length, 1, 'the replacement was not written')

  // The parked proposal is the complete candidate: it names the predecessor and
  // carries the exact item an approval would apply.
  const parked = await readCurationProposal({
    dataRoot: f.dataRoot,
    projectId: f.binding.projectId,
    proposalId: receipt.items[0].proposalId,
  })
  assert.equal(parked.kind, 'supersede')
  assert.equal(parked.operation.kind, 'supersede')
  assert.equal(parked.operation.supersedesId, old.id)
  assert.equal(parked.operation.item.title, '新结论')
  assert.deepEqual(parked.sources, [{ id: old.id, path: old.path, hash: sha256(after) }])
  assert.equal(
    (await listCurationProposals({ dataRoot: f.dataRoot, projectId: f.binding.projectId })).total,
    1,
  )
})

// ---------------------------------------------------------------------------
// The refusal audit: a dropped candidate is never unaccounted for
// ---------------------------------------------------------------------------

test('a refused candidate is persisted beside the validated items and survives a restart', async (t) => {
  const f = await fixture(t)
  const raw = JSON.stringify({
    items: [
      itemFixture({ title: '保留的结论' }),
      itemFixture({
        title: '被拒的结论',
        supersedesId: `Projects/other--deadbeef/Decisions/ADR-1.md`,
      }),
    ],
  })
  await writeJobAtomic(f.queueRoot, jobFixture())
  const llm = stubLlm(raw)

  // Stop right after the validated barrier: the output is durable, nothing applied.
  const first = await processQueue(
    queueOptions(f, {
      llm,
      beforeApply: () => {
        throw new Error('injected-before-apply')
      },
    }),
  )
  assert.equal(first.deferred, 1)
  const interrupted = await jobOnDisk(f)
  assert.equal(interrupted.state, 'validated')
  assert.equal(interrupted.output.items.length, 1, 'only the surviving candidate is an item')
  assert.equal(interrupted.output.refused.length, 1, 'the refusal is durable with the items')
  assert.equal(interrupted.output.refused[0].reason, 'foreign-target')
  assert.equal(interrupted.output.refused[0].field, 'supersedesId')
  assert.equal(llm.calls.length, 1)

  // A restart with NO llm at all resumes from the persisted output; the audit is
  // still available because it lives on the job, not in the model's answer.
  const resumed = await processQueue(queueOptions(f, { llm: undefined }))
  assert.equal(resumed.completed, 1)
  assert.equal(llm.calls.length, 1, 'the resume never called the model')
  const receipt = (await readReceipts(f)).at(-1)
  assert.equal(receipt.result, 'applied')
  assert.equal(receipt.items.length, 1)
  assert.equal(receipt.refusedCount, 1)
  assert.equal(receipt.refused[0].reason, 'foreign-target')
  assert.equal((await memoryNotes(f)).length, 1, 'the refused candidate became no note')
})

test('a refused candidate alone is a no-memory turn that still explains the drop', async (t) => {
  const f = await fixture(t)
  await writeJobAtomic(f.queueRoot, jobFixture())
  const llm = stubLlm(
    JSON.stringify({
      items: [itemFixture({ supersedesId: `Methods/跨项目方法.md` })],
    }),
  )

  const summary = await processQueue(queueOptions(f, { llm }))
  assert.equal(summary.completed, 1)
  const receipt = (await readReceipts(f)).at(-1)
  assert.equal(receipt.result, 'no-memory')
  assert.deepEqual(receipt.items, [])
  assert.equal(receipt.refusedCount, 1)
  assert.equal(receipt.refused[0].reason, 'foreign-target')
  assert.deepEqual(await memoryNotes(f), [])
})

test('the receipt keeps the real refusal count while the listed reasons stay bounded', async (t) => {
  const f = await fixture(t)
  const refused = Array.from({ length: 40 }, (unused, index) => ({
    index,
    reason: 'foreign-target',
    field: 'supersedesId',
    value: `Projects/other--deadbeef/Decisions/ADR-${index}.md`,
  }))
  const items = validatedJob([itemFixture()]).output.items
  await writeJobAtomic(
    f.queueRoot,
    validatedJob([itemFixture()], {
      output: { state: 'validated', raw: '{}', items, usage: null, refused },
    }),
  )

  await processQueue(queueOptions(f, { llm: undefined }))
  const receipt = (await readReceipts(f)).at(-1)
  assert.equal(receipt.refusedCount, 40, 'the count is never truncated')
  assert.equal(receipt.refused.length, 16, 'the listed reasons are bounded')
  assert.equal(receipt.items.length, 1)
})

test('a process killed between the validated barrier and the audit still reports the drop', async (t) => {
  const f = await fixture(t)
  const raw = JSON.stringify({
    items: [
      itemFixture({ title: '保留的结论' }),
      itemFixture({
        title: '被拒的结论',
        supersedesId: `Projects/other--deadbeef/Decisions/ADR-1.md`,
      }),
    ],
  })
  await writeJobAtomic(f.queueRoot, jobFixture())

  const script = join(f.root, 't16-crash-child.mjs')
  await writeFile(script, T16_CRASH_CHILD, 'utf8')
  const killed = spawnSync(
    process.execPath,
    [script, f.queueRoot, f.dataRoot, f.home, JSON.stringify(f.binding), raw],
    {
      encoding: 'utf8',
      env: { ...process.env, T16_CAPTURE_URL: new URL('../lib/capture.js', import.meta.url).href },
    },
  )
  if (HAS_POSIX_MODES) {
    assert.equal(
      killed.signal,
      'SIGKILL',
      `the child must die at the audit boundary, stderr: ${killed.stderr}`,
    )
  } else {
    // Windows has no POSIX signals. `process.kill(pid, 'SIGKILL')` still
    // terminates the process, but `spawnSync` reports `signal: null` and a
    // non-zero `status` (measured: status 1, signal null) instead of naming
    // 'SIGKILL'. The property under test is unchanged — the child did NOT
    // reach a normal exit at the audit boundary — and the durable state
    // assertions below prove it stopped at that exact point, not merely that
    // it failed somewhere.
    assert.equal(killed.signal, null, `no POSIX signal exists on Windows: ${killed.stderr}`)
    assert.notEqual(
      killed.status,
      0,
      `the child must not reach its normal exit, stderr: ${killed.stderr}`,
    )
  }

  // The durable state after the kill: items are on disk, the audit is missing.
  const orphan = await jobOnDisk(f)
  assert.equal(orphan.state, 'validated')
  assert.equal(orphan.output.refused, null, 'the crash landed before the audit was written')
  assert.equal(orphan.output.items.length, 1)

  // Resume with no llm: the drop set must be re-derived from the persisted raw.
  const resumed = await processQueue(queueOptions(f, { llm: undefined }))
  assert.equal(resumed.completed, 1)
  const receipt = (await readReceipts(f)).at(-1)
  assert.equal(receipt.result, 'applied')
  assert.equal(receipt.refusedCount, 1, 'the drop set is re-derived from the persisted raw')
  assert.equal(receipt.refused[0].reason, 'foreign-target')
  assert.equal((await memoryNotes(f)).length, 1)
})

const T16_CRASH_CHILD = `
const { processQueue } = await import(process.env.T16_CAPTURE_URL)
const [queueRoot, dataRoot, home, bindingJson, raw] = process.argv.slice(2)
const binding = JSON.parse(bindingJson)
const llm = {
  stream() {
    return (async function* () {
      yield { type: 'text-delta', index: 0, text: raw }
      yield { type: 'block-end', index: 0, block: { type: 'text', text: raw } }
      yield { type: 'finish', reason: { kind: 'stop' } }
    })()
  },
}
await processQueue({
  queueRoot, dataRoot, home, llm,
  config: {
    autoCapture: true,
    captureIdleMs: 90000,
    distill: {
      provider: 'deepseek-official', model: 'deepseek-flash', maxItems: 12,
      minConfidence: 0.75, maxInputChars: 24000, maxOutputTokens: 4000,
      timeoutMs: 60000, maxRetries: 3, dryRun: false,
    },
  },
  resolveBinding: () => binding,
  debounceMs: 0,
  retryBackoffMs: 0,
  warn: () => {},
  // The exact boundary: the validated output is durable, the audit write has not
  // started. A real SIGKILL, so nothing can clean up after it.
  afterPersist: (jobId, output) => {
    if (output.state === 'validated') process.kill(process.pid, 'SIGKILL')
  },
})
`

test('a result receipt distinguishes an unaudited turn from an audited empty one', async (t) => {
  const f = await fixture(t)
  const base = {
    jobId: JOB_ID,
    projectId: PROJECT_ID,
    sessionId: SESSION_ID,
    toSeq: TO_SEQ,
    result: 'applied',
    items: [],
    at: '2026-01-01T00:00:00.000Z',
  }
  await writeResultReceipt(f.queueRoot, { ...base, refused: null })
  await writeResultReceipt(f.queueRoot, {
    ...base,
    jobId: 'job-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa',
    at: '2026-01-01T00:00:01.000Z',
    refused: [],
  })

  const receipts = await readReceipts(f)
  assert.equal(receipts[0].refused, null, 'never audited is not the same as nothing refused')
  assert.equal(receipts[0].refusedCount, null)
  assert.deepEqual(receipts[1].refused, [])
  assert.equal(receipts[1].refusedCount, 0)
})

test('an output whose audit cannot be re-derived fails the job instead of completing it', async (t) => {
  const f = await fixture(t)
  const raw = JSON.stringify({
    items: [
      itemFixture({ title: '保留的结论' }),
      itemFixture({
        title: '被拒的结论',
        supersedesId: `Projects/other--deadbeef/Decisions/ADR-1.md`,
      }),
    ],
  })
  const items = withIdentity([itemFixture({ title: '保留的结论' })])
  await writeJobAtomic(
    f.queueRoot,
    jobFixture({
      state: 'validated',
      output: { state: 'validated', raw, items, usage: null, refused: null },
    }),
  )

  // `maxItems: 1` makes the persisted output no longer validate, so the drop set
  // cannot be re-derived. Completing the job would delete the only copy of the
  // audit, so it is failed (bounded and visible, R43b) and kept instead.
  const summary = await processQueue(
    queueOptions(f, {
      llm: undefined,
      config: baseConfig({ distill: { maxItems: 1 } }),
    }),
  )
  assert.equal(summary.completed, 0)
  assert.equal(summary.deferred, 1)
  const job = await jobOnDisk(f)
  assert.equal(job.state, 'validated')
  assert.equal(job.lastError.code, 'audit-unavailable')
  assert.equal(job.attempts, 1)
  assert.deepEqual(await readReceipts(f), [], 'no receipt claims a completion that did not happen')
  assert.deepEqual(await memoryNotes(f), [], 'nothing is applied before the audit is durable')
})

// ---------------------------------------------------------------------------
// Single-flight, capture gating and the real-host wiring
// ---------------------------------------------------------------------------

test('two concurrent passes distill one job exactly once', async (t) => {
  const f = await fixture(t)
  await writeJobAtomic(f.queueRoot, jobFixture())
  const llm = stubLlm(JSON.stringify({ items: [itemFixture()] }), { delayMs: 20 })
  const options = queueOptions(f, { llm })

  const [first, second] = await Promise.all([processQueue(options), processQueue(options)])
  assert.equal(first.completed + second.completed, 1)
  assert.equal(llm.calls.length, 1)
  assert.equal((await memoryNotes(f)).length, 1)
})

test('the capture seam hands a freshly captured turn to the worker', async (t) => {
  const f = await fixture(t)
  const kicked = []
  const capture = createCapture({
    queueRoot: f.queueRoot,
    config: baseConfig(),
    resolveBinding: async () => f.binding,
    warn: () => {},
    onEnqueued: (job) => kicked.push(job.jobId),
  })
  const events = [
    { seq: 0, type: 'turn/start', data: { turn: 1 } },
    {
      seq: 1,
      type: 'user/message',
      data: {
        role: 'user',
        content: [{ type: 'text', text: '把调度器改成可插拔后端' }],
        source: { kind: 'user' },
      },
    },
    {
      seq: 2,
      type: 'assistant/message',
      data: {
        turn: 1,
        step: 1,
        message: {
          role: 'assistant',
          content: [{ type: 'text', text: '已实现' }],
          source: { kind: 'model' },
        },
      },
    },
    { seq: 3, type: 'turn/end', data: { turn: 1, reason: { kind: 'completed' } } },
  ]
  const session = {
    header: { id: SESSION_ID, cwd: '/work/demo' },
    snapshotEvents: (from = 0, to) => events.slice(from, to ?? events.length),
    requestContext: () => ({ provider: 'deepseek-official', model: 'deepseek-flash' }),
  }
  await capture.recover()
  capture.sessionEvent(session, events[3])
  await capture.settle()
  assert.equal(kicked.length, 1)

  const jobs = await loadPending(f.queueRoot)
  assert.equal(jobs.length, 1)
  const llm = stubLlm(JSON.stringify({ items: [itemFixture({ evidenceSeqs: [1] })] }))
  const summary = await processQueue(queueOptions(f, { llm }))
  assert.equal(summary.completed, 1)
  assert.equal((await memoryNotes(f)).length, 1)
})

test('enqueueTurn produces nothing when autoCapture is off', async (t) => {
  const f = await fixture(t)
  const events = [
    { seq: 0, type: 'turn/start', data: { turn: 1 } },
    {
      seq: 1,
      type: 'user/message',
      data: { role: 'user', content: [{ type: 'text', text: '你好' }], source: { kind: 'user' } },
    },
    { seq: 2, type: 'turn/end', data: { turn: 1, reason: { kind: 'completed' } } },
  ]
  const session = {
    header: { id: SESSION_ID, cwd: '/work/demo' },
    snapshotEvents: (from = 0, to) => events.slice(from, to ?? events.length),
    requestContext: () => ({ provider: 'deepseek-official', model: 'deepseek-flash' }),
  }
  const job = await enqueueTurn({
    session,
    event: events[2],
    binding: f.binding,
    queueRoot: f.queueRoot,
    config: baseConfig({ autoCapture: false }),
  })
  assert.equal(job, null)
  assert.deepEqual(await loadPending(f.queueRoot), [])
})

test('an explicit queueRoot and dataRoot are the only filesystem targets; DSH_HOME is never consulted', async (t) => {
  const f = await fixture(t)
  const { root: fakeHome } = await temporaryRoot(t, 'obsidian-mem-t16-home-')
  const previous = process.env.DSH_HOME
  process.env.DSH_HOME = fakeHome
  t.after(() => {
    if (previous === undefined) delete process.env.DSH_HOME
    else process.env.DSH_HOME = previous
  })

  await writeJobAtomic(f.queueRoot, validatedJob([itemFixture()]))
  const summary = await processQueue(queueOptions(f))
  assert.equal(summary.completed, 1)
  assert.equal(
    existsSync(join(fakeHome, 'data')),
    false,
    'the production data root was never derived',
  )
  assert.equal(existsSync(join(fakeHome, 'skills')), false)
  // The vault is a temporary directory, never the default `~/Documents/dsh-memory`.
  assert.ok(f.vault.startsWith(f.root))
  assert.equal((await stat(f.vault)).isDirectory(), true)
})

test('an injected model route wins over the host llm service for the queue worker', async (t) => {
  // The cloud/local wiring (2026-11-09): with \`distill.transport: 'http'\` the plugin
  // builds its own route (lib/model-transport.js) and hands it to the queue worker,
  // which must prefer it to \`ctx.get('llm')\`. Both answer the same chunk contract, so
  // nothing downstream can tell them apart — the precedence is observable only at
  // this seam, and this case drives it: one durably queued job, the worker the hooks
  // build, and a counter per side.
  const f = await fixture(t)
  await writeJobAtomic(f.queueRoot, jobFixture())
  const llm = stubLlm(JSON.stringify({ items: [itemFixture({ evidenceSeqs: [1] })] }))
  let hostCalls = 0
  const hostStream = llm.stream
  llm.stream = (options) => {
    hostCalls += 1
    return hostStream(options)
  }
  let routeCalls = 0
  const route = {
    stream() {
      routeCalls += 1
      return (async function* () {
        yield { type: 'finish', reason: { kind: 'stop' } }
      })()
    },
  }
  const ctx = fakeContext({ llm })
  const disposers = registerHooks(ctx, {
    resolveBinding: async () => f.binding,
    index: async () => ({}),
    buildBrief: async () => null,
    config: baseConfig({ captureIdleMs: 1000 }),
    queueRoot: f.queueRoot,
    dataRoot: f.dataRoot,
    home: f.home,
    resolveJobBinding: () => f.binding,
    llm: route,
  })
  f.onCleanup(() => {
    for (const dispose of disposers) dispose()
  })
  await ctx.settled()
  // The worker's first pass runs off its own arm; wait for a counter instead of
  // guessing at a timer.
  const deadline = Date.now() + 10000
  while (hostCalls === 0 && routeCalls === 0 && Date.now() < deadline) {
    await sleep(20)
  }
  assert.equal(hostCalls, 0, 'the host service is never asked when a route is injected')
  assert.equal(routeCalls, 1, 'the injected route is the one the worker calls')
})

test('registerHooks starts capture and the worker from one queue root, end to end', async (t) => {
  const f = await fixture(t)
  const llm = stubLlm(JSON.stringify({ items: [itemFixture({ evidenceSeqs: [1] })] }))
  const ctx = fakeContext({ llm })
  const config = baseConfig({ captureIdleMs: 1000 })
  const disposers = registerHooks(ctx, {
    resolveBinding: async () => f.binding,
    index: async () => {
      throw new Error('the index is not part of this case')
    },
    buildBrief: async () => null,
    config,
    queueRoot: f.queueRoot,
    dataRoot: f.dataRoot,
    home: f.home,
    resolveJobBinding: () => f.binding,
  })
  f.onCleanup(() => {
    for (const dispose of disposers) dispose()
  })

  // The worker effect resolved, so recovery ran and the debounce timer is armed.
  await ctx.settled()
  const events = [
    { seq: 0, type: 'turn/start', data: { turn: 1 } },
    {
      seq: 1,
      type: 'user/message',
      data: {
        role: 'user',
        content: [{ type: 'text', text: '把调度器改成可插拔后端' }],
        source: { kind: 'user' },
      },
    },
    {
      seq: 2,
      type: 'assistant/message',
      data: {
        turn: 1,
        step: 1,
        message: {
          role: 'assistant',
          content: [{ type: 'text', text: '已实现' }],
          source: { kind: 'model' },
        },
      },
    },
    { seq: 3, type: 'turn/end', data: { turn: 1, reason: { kind: 'completed' } } },
  ]
  const session = {
    header: { id: SESSION_ID, cwd: '/work/demo' },
    snapshotEvents: (from = 0, to) => events.slice(from, to ?? events.length),
    requestContext: () => ({ provider: 'deepseek-official', model: 'deepseek-flash' }),
  }
  ctx.handlers.get('session/event')(session, events[3])

  const notes = await waitFor(
    () => memoryNotes(f),
    (found) => found.length === 1,
  )
  assert.equal(notes.length, 1, 'the debounced worker pass applied the captured turn')
  assert.equal(llm.calls.length, 1)
  assert.equal(await jobOnDisk(f), null)
})

// ---------------------------------------------------------------------------
// Small host-shaped helpers for the wiring case
// ---------------------------------------------------------------------------

/** A minimal Cordis-shaped context: `on`, `effect`, `get` and a logger. */
function fakeContext({ llm } = {}) {
  const handlers = new Map()
  const pending = []
  return {
    handlers,
    on(event, handler) {
      handlers.set(event, handler)
      return () => handlers.delete(event)
    },
    effect(fn) {
      pending.push(fn())
      return () => {}
    },
    get(name) {
      return name === 'llm' ? llm : undefined
    },
    logger: { warn: () => {}, info: () => {} },
    async settled() {
      await Promise.all(pending.map((entry) => Promise.resolve(entry).catch(() => {})))
    },
  }
}

/** Poll a reader until a predicate holds, or fail the test with a timeout. */
async function waitFor(read, done, { timeoutMs = 5000, stepMs = 25 } = {}) {
  const deadline = Date.now() + timeoutMs
  let value = await read()
  while (!done(value) && Date.now() < deadline) {
    await new Promise((resolve) => setTimeout(resolve, stepMs))
    value = await read()
  }
  return value
}

/** Poll a predicate until it answers true, or return false at the deadline. */
async function waitUntil(predicate, { timeoutMs = 5000, stepMs = 5 } = {}) {
  const deadline = Date.now() + timeoutMs
  for (;;) {
    if (await predicate()) return true
    if (Date.now() > deadline) return false
    await sleep(stepMs)
  }
}

test('without a binding seam the worker resolves the project from the vault registry', async (t) => {
  const f = await fixture(t)
  const otherProject = '7f3b19c2-4d05-4a1e-9c77-000000000002'
  await writeJobAtomic(f.queueRoot, validatedJob([itemFixture()]))
  await writeJobAtomic(
    f.queueRoot,
    validatedJob([itemFixture()], {
      jobId: 'job-bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb',
      projectId: otherProject,
      createdAt: '2026-09-23T00:00:01.000Z',
      updatedAt: '2026-09-23T00:00:01.000Z',
    }),
  )

  // No `resolveBinding`: this is exactly the production path, where the worker has
  // only the job's persisted project id and the configured vault.
  const summary = await processQueue({
    queueRoot: f.queueRoot,
    dataRoot: f.dataRoot,
    home: f.home,
    config: baseConfig({ vaultPath: f.vault }),
    debounceMs: 0,
    retryBackoffMs: 0,
    warn: () => {},
  })
  assert.equal(summary.completed, 1)
  assert.equal(summary.deferred, 1, 'an unregistered project waits instead of failing')
  assert.equal((await memoryNotes(f)).length, 1)

  const waiting = await jobOnDisk(f, 'job-bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb')
  // The deferred state names the resume point its durable output already reached,
  // so an unbound project never costs the work that was already paid for.
  assert.equal(waiting.state, 'validated')
  assert.equal(waiting.deferredReason, 'no-binding')
  assert.equal(waiting.attempts, 0)
})

test('a cloud-managed vault is refused by the worker instead of written into', async (t) => {
  const f = await fixture(t)
  const cloudHome = join(f.root, 'cloud-home')
  const cloudVault = join(
    cloudHome,
    'Library',
    'Mobile Documents',
    'com~apple~CloudDocs',
    'dsh-memory',
  )
  await mkdir(cloudVault, { recursive: true })
  await writeJobAtomic(f.queueRoot, validatedJob([itemFixture()]))

  const summary = await processQueue({
    queueRoot: f.queueRoot,
    dataRoot: f.dataRoot,
    home: cloudHome,
    config: baseConfig({ vaultPath: cloudVault }),
    debounceMs: 0,
    retryBackoffMs: 0,
    warn: () => {},
  })
  assert.equal(summary.completed, 0)
  assert.equal(summary.deferred, 1)
  const job = await jobOnDisk(f)
  assert.equal(job.lastError.code, 'vault-cloud-managed')
  assert.equal(job.attempts, 1)
  assert.deepEqual(await memoryNotes(f), [])
})

// ---------------------------------------------------------------------------
// The worker lifecycle used by the host
// ---------------------------------------------------------------------------

test('the queue worker is single-flight, debounce-aware and disposable', async () => {
  const calls = []
  const worker = createQueueWorker({
    queueRoot: '/nonexistent/obsidian-mem-queue',
    dataRoot: '/nonexistent/obsidian-mem-data',
    config: baseConfig(),
    resolveBinding: () => null,
    debounceMs: 0,
    retryBackoffMs: 0,
    warn: (message) => calls.push(message),
    getLlm: () => undefined,
  })
  assert.equal(typeof worker.start, 'function')
  assert.equal(typeof worker.stop, 'function')
  assert.equal(typeof worker.abort, 'function')
  await worker.pass()
  assert.ok(worker.pass() instanceof Promise)
  worker.stop()
  await worker.pass()
})

// ---------------------------------------------------------------------------
// The host unloads the plugin while the model call is still streaming
// ---------------------------------------------------------------------------

/**
 * The measured host fact these cases pin (`docs/p0-compatibility.md` §9): DSH
 * disposes the whole plugin tree when a headless run's session completes, and
 * that disposal happens while the queue worker's model call can still be in
 * flight. The stream itself is NOT killed by the teardown, so the only thing
 * that ended it was the worker's own `stop()` aborting its controller — which
 * `distill.js` then reported as a terminal `aborted` and the queue recorded as a
 * failed attempt (the R43 bound was consumed by a failure the model never
 * produced). A lifecycle unload must therefore not be mistaken for a caller
 * cancellation; `abort()` remains the explicit way to cancel.
 */
test('a host unload mid-call lets the job finish instead of reporting a caller abort (Task 18b)', async (t) => {
  const f = await fixture(t)
  await writeJobAtomic(f.queueRoot, jobFixture())
  const llm = inFlightLlm(JSON.stringify({ items: [itemFixture()] }))
  const worker = createQueueWorker({
    ...queueOptions(f, { debounceMs: 0 }),
    llm,
    getLlm: () => llm,
  })

  const pass = worker.pass()
  await llm.opened
  // Let the generator reach its await so `stop()` really lands mid-call.
  await new Promise((resolve) => setTimeout(resolve, 5))
  worker.stop()
  llm.release()
  const summary = await pass

  assert.equal(summary.completed, 1, 'the unloaded worker still finished the job it had in flight')
  assert.equal(await jobOnDisk(f), null, 'a completed job is deleted')
  const receipts = await readReceipts(f)
  assert.equal(receipts.length, 1)
  assert.equal(receipts[0].result, 'applied', 'the note was written by the real apply path')
  assert.equal((await memoryNotes(f)).length, 1)
  assert.equal(llm.calls.length, 1)
})

test('an explicit worker.abort() still cancels an in-flight model call', async (t) => {
  const f = await fixture(t)
  await writeJobAtomic(f.queueRoot, jobFixture())
  const llm = inFlightLlm(JSON.stringify({ items: [itemFixture()] }))
  const worker = createQueueWorker({
    ...queueOptions(f, { debounceMs: 0 }),
    llm,
    getLlm: () => llm,
  })

  const pass = worker.pass()
  await llm.opened
  await new Promise((resolve) => setTimeout(resolve, 5))
  worker.abort()
  const summary = await pass

  // The cancellation is real and is accounted for the way R43 requires: one
  // recorded attempt with the stream's own reason, no receipt, no vault write.
  assert.equal(summary.deferred, 1)
  assert.equal((await readReceipts(f)).length, 0)
  assert.deepEqual(await memoryNotes(f), [])
  const job = await jobOnDisk(f)
  assert.equal(job.attempts, 1)
  assert.equal(job.lastError.code, 'aborted')
})

test('a pass that outlives the plugin tree defers the rest of the queue instead of failing it (Task 18b)', async (t) => {
  const f = await fixture(t)
  // Two due jobs in ONE pass: two completed turns captured inside one debounce
  // window coalesce into two ranges the same pass has to work. Job ids decide the
  // order (`readPendingJobs` sorts by `createdAt`, then id), so the first job is
  // the one this test allows to finish.
  const firstJob = 'job-00000000000000000000000000000001'
  const secondJob = 'job-00000000000000000000000000000002'
  await writeJobAtomic(f.queueRoot, jobFixture({ jobId: firstJob }))
  await writeJobAtomic(f.queueRoot, jobFixture({ jobId: secondJob, fromSeq: 2, toSeq: 8 }))
  const llm = inFlightLlm(JSON.stringify({ items: [itemFixture()] }))
  const worker = createQueueWorker({
    ...queueOptions(f, { debounceMs: 0 }),
    llm,
    getLlm: () => llm,
  })

  const pass = worker.pass()
  await llm.opened
  await new Promise((resolve) => setTimeout(resolve, 5))
  // The host disposes the tree while the first job is streaming: the handle the
  // pass snapshotted at its start is dead from here on (measured `NO_ADAPTER`).
  worker.stop()
  llm.dispose()
  llm.release()
  const summary = await pass

  assert.equal(
    llm.calls.length,
    1,
    'the settling pass did not start a second job with a dead handle',
  )
  assert.equal(summary.completed, 1, 'the job that was already in flight still completed')
  assert.deepEqual(
    summary.results.filter((entry) => entry.status === 'deferred').map((entry) => entry.reason),
    ['unloaded'],
    'the remaining job is reported as unloaded, not as a model failure',
  )
  const remaining = await loadPending(f.queueRoot)
  assert.equal(remaining.length, 1, 'the second job is kept for the next process')
  assert.equal(remaining[0].jobId, secondJob)
  assert.equal(remaining[0].attempts, 0, 'a deferred job must not consume an attempt')
  assert.equal(
    remaining[0].lastError,
    undefined,
    'and it must not record a failure the model never produced',
  )
  assert.equal(remaining[0].state, 'pending')
  assert.equal((await readReceipts(f)).length, 1)
  assert.equal((await memoryNotes(f)).length, 1)
})

// ---------------------------------------------------------------------------
// Task 10: the decisions the diagnostics ring records, at the real seams
// ---------------------------------------------------------------------------

/** Every recorded event of one category, in order. */
function eventsOf(diagnostics, name) {
  return diagnostics.snapshot().events.filter((event) => event.event === name)
}

/** A session whose committed log is the four events of one finished turn. */
function finishedTurn(sessionId = SESSION_ID, text = '把调度器改成可插拔后端') {
  const events = [
    { seq: 0, type: 'turn/start', data: { turn: 1 } },
    {
      seq: 1,
      type: 'user/message',
      data: { role: 'user', content: [{ type: 'text', text }], source: { kind: 'user' } },
    },
    {
      seq: 2,
      type: 'assistant/message',
      data: {
        turn: 1,
        step: 1,
        message: {
          role: 'assistant',
          content: [{ type: 'text', text: '已实现' }],
          source: { kind: 'model' },
        },
      },
    },
    { seq: 3, type: 'turn/end', data: { turn: 1, reason: { kind: 'completed' } } },
  ]
  return {
    events,
    session: {
      header: { id: sessionId, cwd: '/work/demo' },
      snapshotEvents: (from = 0, to) => events.slice(from, to ?? events.length),
      requestContext: () => ({ provider: 'deepseek-official', model: 'deepseek-flash' }),
    },
  }
}

test('a capture that cannot bind records why, and never records the turn', async (t) => {
  const f = await fixture(t)
  const diagnostics = createDiagnostics()
  const sentinel = 'SENTINEL-BODY-' + randomUUID()
  const capture = createCapture({
    queueRoot: f.queueRoot,
    config: baseConfig(),
    resolveBinding: async () => null,
    warn: () => {},
    diagnostics,
  })
  const { events, session } = finishedTurn(SESSION_ID, sentinel)
  capture.sessionEvent(session, events[3])
  await capture.settle()

  const decisions = eventsOf(diagnostics, 'capture')
  assert.equal(decisions.length, 1)
  assert.equal(decisions[0].outcome, 'skipped-unbound')
  assert.equal(JSON.stringify(diagnostics.snapshot()).includes(sentinel), false)
})

test('each reason a turn is not captured is named, and a broken sink costs nothing', async (t) => {
  const f = await fixture(t)
  const diagnostics = createDiagnostics()
  const { events, session } = finishedTurn()
  const sink = (reason) => diagnostics.event('capture', { outcome: reason })

  // Off by configuration: the switch is read before a single byte is written.
  await enqueueTurn({
    session,
    event: events[3],
    binding: f.binding,
    queueRoot: f.queueRoot,
    config: baseConfig({ autoCapture: false }),
    onSkip: sink,
  })
  // A turn with no user message has nothing to remember. Only the projection can
  // see that, and 'nothing was captured' without the reason is the guess this
  // channel exists to replace.
  await enqueueTurn({
    session: { ...session, snapshotEvents: () => [events[0]] },
    event: events[3],
    binding: f.binding,
    queueRoot: f.queueRoot,
    config: baseConfig(),
    onSkip: sink,
  })
  // A sink that throws must not cost the capture: this call still enqueues.
  const job = await enqueueTurn({
    session,
    event: events[3],
    binding: f.binding,
    queueRoot: f.queueRoot,
    config: baseConfig(),
    onSkip: () => {
      throw new Error('the sink is broken')
    },
  })
  assert.equal(typeof job?.jobId, 'string')

  const capture = createCapture({
    queueRoot: f.queueRoot,
    config: baseConfig(),
    resolveBinding: async () => f.binding,
    warn: () => {},
    diagnostics,
  })
  await capture.recover()
  capture.sessionEvent(session, events[3])
  await capture.settle()

  // The third call enqueued the turn, so the capture seam sees it as processed.
  assert.deepEqual(
    eventsOf(diagnostics, 'capture').map((event) => event.outcome),
    ['auto-capture-off', 'no-user-messages', 'already-processed'],
  )
})

test('a captured turn records the job it created, with its project', async (t) => {
  const f = await fixture(t)
  const diagnostics = createDiagnostics()
  const capture = createCapture({
    queueRoot: f.queueRoot,
    config: baseConfig(),
    resolveBinding: async () => f.binding,
    warn: () => {},
    diagnostics,
  })
  const { events, session } = finishedTurn()
  await capture.recover()
  capture.sessionEvent(session, events[3])
  await capture.settle()

  const [decision] = eventsOf(diagnostics, 'capture')
  assert.equal(decision.outcome, 'captured')
  assert.equal(decision.projectId, PROJECT_ID)
  assert.match(String(decision.jobId), /^job-/)
})

test('an applied job records the job, the distillation and the index refresh', async (t) => {
  const f = await fixture(t)
  const diagnostics = createDiagnostics()
  const job = validatedJob([itemFixture()])
  await writeJobAtomic(f.queueRoot, job)
  const summary = await processQueue(queueOptions(f, { diagnostics }))
  assert.equal(summary.completed, 1)

  const jobs = eventsOf(diagnostics, 'job')
  assert.deepEqual(
    jobs.map((event) => event.outcome),
    ['completed'],
  )
  assert.equal(jobs[0].jobId, job.jobId)
  assert.equal(jobs[0].projectId, PROJECT_ID)

  const distilled = eventsOf(diagnostics, 'distill')
  assert.equal(distilled.length, 1)
  assert.equal(distilled[0].outcome, 'applied')
  assert.equal(distilled[0].jobId, job.jobId)
  assert.equal(Number.isInteger(distilled[0].ms), true)

  // This pass has no index seam at all, which is worth distinguishing from 'the
  // refresh failed' — the two look identical from the vault.
  assert.deepEqual(
    eventsOf(diagnostics, 'index').map((event) => event.outcome),
    ['none'],
  )
})

test('a job that drops several changed-path hints reports their sum, not the largest', async (t) => {
  // The worker enqueues one committed path at a time and the cap evicts at most one
  // hint per enqueue (the addition is a one-element array), so a job that drops two
  // hints owes the ring `hits: 2`. Reporting the largest single enqueue would say 1 and
  // understate work a later pass does not repair by itself — the dropped hint's note is
  // trusted by its record's presence and keeps its pre-edit hash in the view.
  const f = await fixture(t)
  const diagnostics = createDiagnostics()
  const job = validatedJob([
    itemFixture({ title: '第一条结论' }),
    itemFixture({ title: '第二条结论' }),
  ])
  await writeJobAtomic(f.queueRoot, job)
  const synthetic = Array.from(
    { length: MAX_CHANGED_PATHS },
    (unused, index) => `${PROJECT}/Docs/合成-${String(index).padStart(4, '0')}.md`,
  )
  await mkdir(dirname(curationChangedPath(f.dataRoot, PROJECT_ID)), { recursive: true })
  await writeFile(
    curationChangedPath(f.dataRoot, PROJECT_ID),
    `${JSON.stringify({ version: 1, projectId: PROJECT_ID, paths: synthetic, updatedAt: new Date().toISOString() }, null, 2)}\n`,
    'utf8',
  )
  const summary = await processQueue(queueOptions(f, { diagnostics }))
  assert.equal(summary.completed, 1)
  const dropped = diagnostics
    .snapshot()
    .events.filter(
      (event) => event.event === 'curation' && event.outcome === 'changed-path-dropped',
    )
  // One event for the job, carrying the sum: the two-item pass evicts one hint per
  // enqueue into the full queue, and both are the job's own drops.
  assert.equal(dropped.length, 1, JSON.stringify(diagnostics.snapshot().events))
  assert.equal(dropped[0].hits, 2)
  assert.equal(dropped[0].projectId, PROJECT_ID)
})

test('a failed attempt records the code and the attempt count, never the model text', async (t) => {
  const f = await fixture(t)
  const diagnostics = createDiagnostics()
  const sentinel = 'SENTINEL-BODY-' + randomUUID()
  await writeJobAtomic(f.queueRoot, jobFixture({ state: 'pending', output: null, attempts: 0 }))
  // The model answers with something the validated barrier must refuse, so this
  // exercises the real failure path rather than an injected fault.
  const summary = await processQueue(
    queueOptions(f, {
      diagnostics,
      llm: stubLlm(sentinel),
      config: baseConfig({ distill: { maxRetries: 1 } }),
    }),
  )
  assert.equal(summary.failed, 1)

  const failed = eventsOf(diagnostics, 'job')
  assert.equal(failed.length, 1)
  assert.equal(failed[0].outcome, 'failed')
  assert.equal(failed[0].attempts, 1)
  assert.equal(typeof failed[0].code, 'string')
  assert.equal(JSON.stringify(diagnostics.snapshot()).includes(sentinel), false)
})

test('a job that cannot bind is recorded as deferred, not as failed', async (t) => {
  const f = await fixture(t)
  const diagnostics = createDiagnostics()
  await writeJobAtomic(f.queueRoot, validatedJob([itemFixture({ evidenceSeqs: [1, 2, 3] })]))
  const summary = await processQueue(queueOptions(f, { diagnostics, resolveBinding: () => null }))
  assert.equal(summary.deferred, 1)

  const deferred = eventsOf(diagnostics, 'job')
  assert.equal(deferred.length, 1)
  assert.equal(deferred[0].outcome, 'deferred')
  assert.equal(deferred[0].code, 'no-binding')
})

test('a write records its committed transaction, and a refusal is rethrown unchanged', async (t) => {
  const f = await fixture(t)
  const diagnostics = createDiagnostics()
  const services = createMemoryServices({
    config: baseConfig({ vaultPath: f.vault }),
    dataRoot: f.dataRoot,
    home: f.home,
    cwd: '/work/demo',
    binding: f.binding,
    diagnostics,
  })
  const sentinel = 'SENTINEL-BODY-' + randomUUID()
  const written = await services.write(
    { type: 'decision', title: '可插拔调度后端', body: sentinel },
    undefined,
    {},
  )
  const [committed] = eventsOf(diagnostics, 'transaction')
  assert.equal(committed.outcome, 'committed')
  assert.equal(committed.txId, written.receipt.txId)
  assert.equal(committed.projectId, PROJECT_ID)
  assert.equal(JSON.stringify(diagnostics.snapshot()).includes(sentinel), false)

  // A refusal reaches the caller unchanged; the ring only says that it happened.
  // 'code' is present only when the refusal carries one, which is the honest
  // shape — an invented code would be worse than a missing one.
  await assert.rejects(
    services.write({ type: 'not-a-type', title: 'x', body: 'y' }, undefined, {}),
    /type/,
  )
  const last = eventsOf(diagnostics, 'transaction').at(-1)
  assert.equal(last.outcome, 'refused')
  assert.equal(last.projectId, PROJECT_ID)
})

test('a refused job retry is visible without reading the queue', async (t) => {
  const f = await fixture(t)
  const diagnostics = createDiagnostics()
  const services = createMemoryServices({
    config: baseConfig({ vaultPath: f.vault }),
    dataRoot: f.dataRoot,
    home: f.home,
    cwd: '/work/demo',
    binding: f.binding,
    diagnostics,
  })
  const result = await services.admin(
    { action: 'jobs', retry: true, jobId: 'job-absent' },
    undefined,
    {},
  )
  assert.equal(result.result.status, 'refused')

  const retry = eventsOf(diagnostics, 'job')
  assert.equal(retry.length, 1)
  assert.equal(retry[0].outcome, 'retry-missing')
  assert.equal(retry[0].jobId, 'job-absent')
})

test('a proposal-write failure before markJob leaves the job validated and retryable', async (t) => {
  // Brief Step 1, the one mandated case the implementation leaned on but nothing
  // pinned: "inject proposal-write failure before `markJob`: the job must stay
  // retryable and retain its validated output."
  //
  // The seam is a `writeMemory` wrapper rather than a `propose` option because
  // `processQueue` does not expose the proposal seam (production wires it from the
  // store). Delegating to the real `applyCandidate` with a throwing `propose` is
  // the same fault at the same point: the store cannot be written, so the risky
  // candidate cannot be parked, and the throw is the only honest outcome.
  const f = await fixture(t)
  const seeded = await seedDecision(f)
  const job = validatedJob([itemFixture({ title: '新结论', supersedesId: seeded.id })])
  await writeJobAtomic(f.queueRoot, job)
  const before = await snapshotTree(f.vault)
  const diagnostics = createDiagnostics()
  const proposalDirectory = join(f.dataRoot, 'curation', 'proposals', PROJECT_ID)
  // A 100 ms backoff rather than an hour: the retry barrier is the point, and the
  // scheduled retry has to stay reachable inside one test without a fake clock.
  const clock = () => new Date(Date.now() + 200)
  const first = Date.now()

  const summary = await processQueue(
    queueOptions(f, {
      diagnostics,
      retryBackoffMs: 100,
      writeMemory: (binding, current, item, deps) =>
        applyCandidate(binding, current, item, {
          ...deps,
          propose: async () => {
            throw new Error('proposal store unavailable')
          },
        }),
    }),
  )

  assert.equal(summary.completed, 0, 'a failed park is not a completed item')
  assert.equal(summary.failed, 0, 'one transient failure is not a terminal job')
  assert.equal(summary.deferred, 1)

  const interrupted = await jobOnDisk(f)
  assert.equal(interrupted.state, 'validated', 'the validated output is retained, so no re-distill')
  assert.deepEqual(interrupted.output.items, job.output.items, 'the candidate is not re-derived')
  assert.equal(interrupted.lastError.code, 'propose-failed')
  assert.match(interrupted.lastError.message, /proposal store unavailable/)
  assert.equal(interrupted.attempts, 1)
  assert.ok(Date.parse(interrupted.nextAttemptAt) > first, 'the retry is scheduled in the future')
  assert.deepEqual(await readReceipts(f), [], 'no receipt claims a completion that did not happen')

  // Nothing was written and nothing was parked: the candidate is not silently gone,
  // it is still exactly where it was.
  assert.deepEqual(await snapshotTree(f.vault), before)
  assert.equal(existsSync(proposalDirectory), false, 'the failed park created no proposal')
  assert.deepEqual(
    eventsOf(diagnostics, 'distill').map((event) => event.outcome),
    [],
    'a failed item records no distill outcome, and certainly not one claiming a write',
  )
  assert.deepEqual(
    eventsOf(diagnostics, 'job').map((event) => event.outcome),
    ['retry'],
  )

  // The retry barrier is what makes this recoverable: a later pass resumes from the
  // persisted output with a working seam, re-distills nothing, and parks.
  await sleep(150)
  const resumed = await processQueue(queueOptions(f, { now: clock }))
  assert.equal(resumed.completed, 1)
  const [receipt] = await readReceipts(f)
  assert.match(receipt.items[0].proposalId, /^[0-9a-f]{64}$/u)
  assert.equal(receipt.items[0].id, null, 'the resumed pass parked rather than wrote')
})

test('a parked candidate persists the review outcome the codec must keep', async (t) => {
  // The gate's whole signal is `outcome: 'review'`, and the disk format is a closed
  // vocabulary that rewrites an unlisted token to `other`. The codec runs in the
  // journal sink and nowhere else, so this case drives the REAL sink and reads the
  // record back off disk. (Fix round 2 replaced the in-process-ring assertion that
  // stood here: the ring carries `review` whatever the codec does, so it could not
  // fail for the reason the case claims, and it passed under a codec without the
  // token.) `applied` follows the parked item because `completeJob` records the
  // job's own summary line: the item was parked and the turn still finished, which
  // is the difference this signal exists to make visible.
  const f = await fixture(t)
  const seeded = await seedDecision(f)
  const sink = openDiagnosticJournal({ dataRoot: f.dataRoot, config: baseConfig() })
  const diagnostics = createDiagnostics({ sink })
  await writeJobAtomic(f.queueRoot, validatedJob([itemFixture({ supersedesId: seeded.id })]))

  const summary = await processQueue(queueOptions(f, { diagnostics }))
  assert.equal(summary.completed, 1)

  const distilled = eventsOf(diagnostics, 'distill')
  assert.equal(distilled[0].outcome, 'review', 'the parked signal is what the ring holds')
  assert.deepEqual(
    distilled.map((event) => event.outcome),
    ['review', 'applied'],
  )
  assert.equal(distilled[0].jobId, JOB_ID)
  assert.equal(distilled[0].projectId, PROJECT_ID)

  // The same two decisions as they reached the disk: the sink encodes through the
  // codec on the way, so a codec that drops `review` writes `other` here and fails.
  // The identifiers arrive as per-run aliases, so the content-free projection the
  // journal is allowed to keep is asserted with the outcome.
  const persisted = readDiagnosticJournal({ dataRoot: f.dataRoot }).events.filter(
    (event) => event.event === 'distill',
  )
  assert.deepEqual(
    persisted.map((event) => event.outcome),
    ['review', 'applied'],
    'a persisted distill record must not be coarsened to `other`',
  )
  assert.match(persisted[0].job, /^j[1-9][0-9]*$/u)
  // The parked candidate wrote nothing, so no index refresh happened either.
  assert.deepEqual(
    eventsOf(diagnostics, 'index').map((event) => event.outcome),
    ['none'],
  )
})

// ---------------------------------------------------------------------------
// The automatic curation trigger (curation Task 6)
// ---------------------------------------------------------------------------

test('a committed write queues its note once and a parked candidate queues nothing', async (t) => {
  // R5's boundary. A parked candidate writes no vault byte, so a trigger that
  // queued a path for it would ask the next pass to inspect a note that does not
  // exist. Both jobs below go through the shipped apply path; only the first one
  // commits a transaction.
  const f = await fixture(t)
  const applied = []
  const callback = (binding, paths) => applied.push({ projectId: binding.projectId, paths })
  const seamWith = (extra = {}) => ({
    ...queueOptions(f, { config: baseConfig({ autoCurate: true }), ...extra }),
    onCurationCompleted: callback,
  })

  await writeJobAtomic(f.queueRoot, validatedJob([itemFixture()]))
  const summary = await processQueue(seamWith())
  assert.equal(summary.completed, 1)

  const note = (await memoryNotes(f))[0]
  assert.equal(applied.length, 1, 'one completed job asks for exactly one pass')
  assert.equal(applied[0].projectId, f.binding.projectId)
  assert.deepEqual(applied[0].paths, [note.path])
  // Durable, not merely reported: the hint the next process reads comes off disk.
  assert.deepEqual(await readChangedSources({ binding: f.binding, dataRoot: f.dataRoot }), [
    note.path,
  ])

  // The parked case. A title twin is what makes a candidate risky, and the seam
  // parks it instead of writing. An index is required, exactly as the duplicate
  // case above requires one: without it the lookup answers `null` and the
  // candidate is not risky at all.
  const seeded = await seedDecision(f, { title: '自动清理触发边界' })
  const index = await openIndex({
    vaultRoot: f.vault,
    dataRoot: f.dataRoot,
    backend: 'sqlite',
    projectId: f.binding.projectId,
    home: f.home,
  })
  f.onCleanup(() => index.close().catch(() => {}))
  await index.waitReady(undefined, 10_000)
  applied.length = 0
  await writeJobAtomic(
    f.queueRoot,
    validatedJob([itemFixture({ title: '自动清理触发边界（重写）' })], {
      jobId: 'job-cccccccccccccccccccccccccccccccc',
      toSeq: 9,
      createdAt: '2026-09-23T00:00:01.000Z',
      updatedAt: '2026-09-23T00:00:01.000Z',
    }),
  )
  const second = await processQueue(seamWith({ index: async () => index }))
  assert.equal(second.completed, 1, 'the parked candidate leaves a completed job')
  const parkedReceipt = (await readReceipts(f)).at(-1)
  assert.equal(parkedReceipt.result, 'applied')
  assert.equal(parkedReceipt.items[0].path, null, 'the candidate wrote no note')
  assert.equal(typeof parkedReceipt.items[0].proposalId, 'string')
  assert.equal(
    (await memoryNotes(f)).some((note) => note.note.data.id === seeded.id),
    true,
    'the seeded note is still the only one with that identity',
  )
  assert.deepEqual(
    applied,
    [],
    'a non-write must not enqueue a path for a note that does not exist',
  )
  assert.deepEqual(
    await readChangedSources({ binding: f.binding, dataRoot: f.dataRoot }),
    [note.path],
    'the committed note stays queued and the parked one is absent',
  )
})

test('two passes asked for in one tick start exactly one', async (t) => {
  // The worker's own single-flight gate, and only that: `pass()` records the
  // in-flight promise before its first `await`, so a second request in the same
  // tick cannot start a second pass. The proof is the answer, not a clock — a
  // request answered by the running pass resolves to *that* pass's summary (the one
  // job applied), where a second pass would resolve to a fresh summary of an empty
  // queue. The callback is deliberately not awaited by the pass, so it cannot be
  // what keeps the first pass in flight; nothing here races `completeJob`'s fs
  // latency.
  const f = await fixture(t)
  await writeJobAtomic(f.queueRoot, validatedJob([itemFixture()]))
  const worker = createQueueWorker(
    queueOptions(f, { config: baseConfig({ autoCurate: true }), debounceMs: 0 }),
  )
  f.onCleanup(() => worker.stop())

  const calls = []
  worker.setOnCurationCompleted((binding, paths) => calls.push(paths.slice()))

  const first = worker.pass()
  const second = worker.pass()
  assert.equal(worker.isRunning(), true, 'the first pass is the one running')
  const [started, answered] = await Promise.all([first, second])
  assert.equal(answered, started, 'a request during an in-flight pass is answered with that pass')
  assert.equal(started.completed, 1, 'the one job was applied once')
  assert.equal(calls.length, 1, 'and the callback ran once')

  // Answered, not queued: with work waiting and nothing running, the next request
  // is a fresh pass.
  await writeJobAtomic(
    f.queueRoot,
    validatedJob([itemFixture({ title: '第二次写入' })], {
      jobId: 'job-dddddddddddddddddddddddddddddddd',
      toSeq: 11,
      createdAt: '2026-09-23T00:00:02.000Z',
      updatedAt: '2026-09-23T00:00:02.000Z',
    }),
  )
  const third = worker.pass()
  assert.equal(await waitUntil(() => calls.length === 2), true, 'an idle worker runs the next pass')
  const next = await third
  assert.equal(next.completed, 1, 'the second pass is a pass of its own')
  assert.equal(calls.length, 2)
})

test('a curation callback that throws cannot fail a job whose vault work is done', async (t) => {
  // The callback is advisory, so the receipt is the job's outcome and the callback's
  // failure may only be a diagnostic. The counterfactual is why this case exists:
  // the bare call let a synchronous throw reach the pass's catch, and `failJob`
  // consumes an attempt — at `maxAttempts` (here 1, to make it terminal in one pass)
  // the job would be marked `failed` for good with its note already on disk and no
  // receipt to say so.
  const f = await fixture(t)
  const diagnostics = createDiagnostics()
  const boom = new Error('the trigger threw')
  boom.code = 'trigger-threw'
  await writeJobAtomic(f.queueRoot, validatedJob([itemFixture()]))
  const summary = await processQueue({
    ...queueOptions(f, {
      config: baseConfig({ autoCurate: true, distill: { maxRetries: 1 } }),
      diagnostics,
    }),
    onCurationCompleted: () => {
      throw boom
    },
  })

  assert.equal(summary.completed, 1)
  const note = (await memoryNotes(f))[0]
  const receipt = (await readReceipts(f)).at(-1)
  assert.equal(receipt.result, 'applied', 'a done job gets its receipt')
  assert.equal(receipt.items[0].path, note.path)
  assert.equal(await jobOnDisk(f), null, 'a completed job is deleted, not retried')
  const events = eventsOf(diagnostics, 'curation')
  assert.equal(events.length, 1, 'the callback failure is recorded once')
  assert.equal(events[0].outcome, 'failed')
  assert.equal(events[0].code, 'trigger-threw')
  assert.equal(JSON.stringify(events).includes(note.path), false, 'content-free')
})

test('a curation callback that rejects is observed and never reaches the job', async (t) => {
  // The same class as the throw above, with one extra hazard: the pass never awaits
  // the callback, so before this wrapper nothing in the process held its rejection —
  // it surfaced as an unhandled rejection instead of one diagnostic.
  const f = await fixture(t)
  const unhandled = []
  const onUnhandled = (reason) => unhandled.push(reason)
  process.on('unhandledRejection', onUnhandled)
  t.after(() => process.removeListener('unhandledRejection', onUnhandled))
  const diagnostics = createDiagnostics()
  await writeJobAtomic(f.queueRoot, validatedJob([itemFixture()]))
  const summary = await processQueue({
    ...queueOptions(f, {
      config: baseConfig({ autoCurate: true, distill: { maxRetries: 1 } }),
      diagnostics,
    }),
    onCurationCompleted: async () => {
      const error = new Error('the trigger rejected')
      error.code = 'trigger-rejected'
      throw error
    },
  })
  // One macrotask turn is all a rejection needs to be reported as unhandled.
  await sleep(20)

  assert.equal(summary.completed, 1)
  assert.deepEqual(unhandled, [], 'the rejection was observed, not left to the process')
  const receipt = (await readReceipts(f)).at(-1)
  assert.equal(receipt.result, 'applied')
  assert.equal(await jobOnDisk(f), null)
  const events = eventsOf(diagnostics, 'curation')
  assert.equal(events.length, 1)
  assert.equal(events[0].outcome, 'failed')
  assert.equal(events[0].code, 'trigger-rejected')
})

test('a stopped worker starts no curation pass for a later kick', async (t) => {
  const f = await fixture(t)
  await writeJobAtomic(f.queueRoot, validatedJob([itemFixture()]))
  const worker = createQueueWorker(
    queueOptions(f, { config: baseConfig({ autoCurate: true }), debounceMs: 0 }),
  )
  const calls = []
  worker.setOnCurationCompleted((binding, paths) => calls.push(paths.slice()))

  await worker.pass()
  assert.equal(calls.length, 1, 'an active worker does run a pass')
  worker.stop()
  worker.kick()
  await sleep(50)
  assert.equal(calls.length, 1, 'a teardown stops new work instead of scheduling one more pass')
  // `stop()` is also what makes an explicit pass a no-op, which is the same
  // decision seen from the other side: the worker cannot start one.
  const after = await worker.pass()
  assert.equal(after, null, 'a stopped worker answers a pass with nothing at all')
})
