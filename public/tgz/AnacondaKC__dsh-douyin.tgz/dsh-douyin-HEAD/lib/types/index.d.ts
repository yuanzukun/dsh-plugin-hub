import type { Context } from '@deepseek-ai/cordis';
export declare const name = "dsh-douyin";
export declare const inject: string[];
export declare const RESOLVE_ROUTE = "/dsh-douyin/resolve";
/** Only built-in HTTPS feed endpoints may make the host issue a request. */
export declare function isAllowedFeedUrl(rawUrl: string): boolean;
export declare function isPublicIpAddress(address: string): boolean;
type HostLookup = (hostname: string) => Promise<readonly {
    address: string;
}[]>;
export declare function isSafeRedirectTarget(target: URL, resolveHost?: HostLookup): Promise<boolean>;
/** Resolve an allowlisted feed URL to its first public HTTP redirect target. */
export declare function resolveRedirect(rawUrl: string): Promise<string | null>;
export declare function apply(ctx: Context): void;
export {};
