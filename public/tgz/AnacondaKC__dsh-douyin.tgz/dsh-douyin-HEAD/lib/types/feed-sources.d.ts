/** Shared source contracts used by both the host resolver and browser client. */
export type SourceKind = 'feed' | 'direct' | 'web';
export interface VideoSource {
    /** Stable identifier used for persistence and React keys. */
    id: string;
    /** Display name in the source navigation. */
    name: string;
    /** Feed API, fixed media URL, or sandboxed web page. */
    kind: SourceKind;
    url: string;
    /** Marks a source restored from user-owned preferences. */
    custom?: boolean;
}
/**
 * Verified category feeds. Explicitly minor-coded categories from the
 * upstream page are intentionally excluded.
 */
export declare const DEFAULT_SOURCES: readonly VideoSource[];
