import type { VideoSource } from './index.ts';
export interface MediaPlayerProps {
    source: VideoSource;
}
export declare function MediaPlayer(props: MediaPlayerProps): React.ReactElement;
