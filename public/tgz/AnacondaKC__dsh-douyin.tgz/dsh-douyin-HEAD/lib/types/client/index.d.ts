import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
import { DEFAULT_SOURCES, type SourceKind, type VideoSource } from '../feed-sources.ts';
export { DEFAULT_SOURCES };
export type { SourceKind, VideoSource };
/** Plugin id == bundle registration key. */
export declare const ID = "dsh-douyin";
/** Persisted panel prefs: active source + user-added sources. */
export interface FeedPrefs {
    activeSourceId: string;
    customSources: VideoSource[];
}
export declare const EMPTY_PREFS: FeedPrefs;
/** Display labels for the three source modes (add-form radio + tab tooltip). */
export declare const KIND_LABEL: Record<SourceKind, string>;
export declare function readPrefs(): FeedPrefs;
export declare function writePrefs(prefs: FeedPrefs): void;
/** All sources, built-ins first, then customs. */
export declare function allSources(prefs: FeedPrefs): VideoSource[];
/** No hard inject: services are probed optionally at apply time. */
export declare const inject: string[];
export declare function apply(ctx: ClientContext): void;
