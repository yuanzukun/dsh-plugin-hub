export declare const WHEEL_THROTTLE_MS = 400;
export declare const FAILURE_RETRY_BASE_MS = 300;
export declare const MAX_CONSECUTIVE_FAILURES = 3;
export declare const MAX_HISTORY_ENTRIES = 100;
export interface FailureDecision {
    count: number;
    retryDelayMs: number | null;
}
/** A null delay means automatic retries must stop and surface an error. */
export declare function nextFailureDecision(previousCount: number): FailureDecision;
export declare function acceptsWheel(lastAcceptedAt: number, now: number): boolean;
export declare function supportsSegmentNavigation(kind: 'feed' | 'direct' | 'web'): boolean;
export declare function appendBounded<T>(entries: readonly T[], entry: T, limit?: number): T[];
