import type { IncomingMessage, ServerResponse } from 'node:http'
import { afterEach, describe, expect, it, vi } from 'vitest'
import { apply, inject, isAllowedFeedUrl, isPublicIpAddress, isSafeRedirectTarget, resolveRedirect } from '../src/index.ts'

afterEach(() => vi.restoreAllMocks())

describe('resolver URL 围栏', () => {
  it('只允许内置 HTTPS feed 和单个 _t 参数', () => {
    expect(isAllowedFeedUrl('https://api.yujn.cn/api/zzxjj.php')).toBe(true)
    expect(isAllowedFeedUrl('https://api.yujn.cn/api/zzxjj.php?_t=123')).toBe(true)
    expect(isAllowedFeedUrl('http://api.yujn.cn/api/zzxjj.php')).toBe(false)
    expect(isAllowedFeedUrl('https://api.yujn.cn:444/api/zzxjj.php')).toBe(false)
    expect(isAllowedFeedUrl('https://user:pass@api.yujn.cn/api/zzxjj.php')).toBe(false)
    expect(isAllowedFeedUrl('https://api.yujn.cn/api/zzxjj.php?next=http://127.0.0.1')).toBe(false)
    expect(isAllowedFeedUrl('https://api.yujn.cn/api/not-built-in.php')).toBe(false)
    expect(isAllowedFeedUrl('http://127.0.0.1:3080/private')).toBe(false)
    expect(isAllowedFeedUrl('http://169.254.169.254/latest/meta-data')).toBe(false)
  })

  it('非法 URL 在调用 fetch 前被拒绝', async () => {
    const fetchMock = vi.spyOn(globalThis, 'fetch')
    await expect(resolveRedirect('http://127.0.0.1:3080/private')).resolves.toBeNull()
    expect(fetchMock).not.toHaveBeenCalled()
  })

  it('重定向目标只接受全部解析到公网的地址', async () => {
    expect(isPublicIpAddress('8.8.8.8')).toBe(true)
    expect(isPublicIpAddress('127.0.0.1')).toBe(false)
    expect(isPublicIpAddress('169.254.169.254')).toBe(false)
    expect(isPublicIpAddress('10.0.0.1')).toBe(false)
    expect(isPublicIpAddress('2001:4860:4860::8888')).toBe(true)
    expect(isPublicIpAddress('::1')).toBe(false)
    expect(isPublicIpAddress('fc00::1')).toBe(false)
    expect(isPublicIpAddress('::ffff:127.0.0.1')).toBe(false)

    await expect(isSafeRedirectTarget(
      new URL('https://cdn.example/video.mp4'),
      async () => [{ address: '8.8.8.8' }],
    )).resolves.toBe(true)
    await expect(isSafeRedirectTarget(
      new URL('https://cdn.example/video.mp4'),
      async () => [{ address: '8.8.8.8' }, { address: '127.0.0.1' }],
    )).resolves.toBe(false)
    await expect(isSafeRedirectTarget(new URL('http://127.0.0.1/private'))).resolves.toBe(false)
  })

  it('只返回合法 HTTP(S) 首跳重定向', async () => {
    const fetchMock = vi.spyOn(globalThis, 'fetch')
      .mockResolvedValueOnce(new Response(null, { status: 302, headers: { location: 'https://8.8.8.8/video.mp4' } }))
      .mockResolvedValueOnce(new Response(null, { status: 302, headers: { location: 'file:///etc/passwd' } }))

    await expect(resolveRedirect('https://api.yujn.cn/api/zzxjj.php?_t=1'))
      .resolves.toBe('https://8.8.8.8/video.mp4')
    await expect(resolveRedirect('https://api.yujn.cn/api/zzxjj.php?_t=2'))
      .resolves.toBeNull()
    expect(fetchMock).toHaveBeenCalledTimes(2)
    expect(fetchMock.mock.calls[0]?.[1]).toMatchObject({ method: 'HEAD', redirect: 'manual' })
  })
})

function createResponse(): ServerResponse & { body: string, headers: Record<string, string> } {
  const response = {
    statusCode: 200,
    body: '',
    headers: {} as Record<string, string>,
    setHeader(name: string, value: string | number | readonly string[]) {
      this.headers[name.toLowerCase()] = String(value)
      return this
    },
    end(body?: string) {
      this.body = body ?? ''
      return this
    },
  }
  return response as unknown as ServerResponse & { body: string, headers: Record<string, string> }
}

describe('resolver 路由契约', () => {
  it('注册 disposer，并拒绝非 GET 与未允许地址', async () => {
    let handler: ((req: IncomingMessage, res: ServerResponse) => Promise<void>) | undefined
    const dispose = vi.fn()
    let effectDispose: (() => void) | undefined
    apply({
      webServer: {
        register(route) {
          handler = route.handler
          return dispose
        },
      },
      effect(callback) {
        effectDispose = callback()
      },
    })
    expect(handler).toBeTypeOf('function')
    expect(inject).toContain('webServer')

    const post = createResponse()
    await handler!({ method: 'POST', url: '/dsh-douyin/resolve?u=x' } as IncomingMessage, post)
    expect(post.statusCode).toBe(405)
    expect(post.headers.allow).toBe('GET')

    const blocked = createResponse()
    await handler!({ method: 'GET', url: '/dsh-douyin/resolve?u=http%3A%2F%2F127.0.0.1' } as IncomingMessage, blocked)
    expect(blocked.statusCode).toBe(400)
    expect(JSON.parse(blocked.body)).toEqual({ url: null, error: 'feed-not-allowed' })

    effectDispose?.()
    expect(dispose).toHaveBeenCalledOnce()
  })
})
