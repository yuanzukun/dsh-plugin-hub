import { existsSync, mkdtempSync, mkdirSync, rmSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { afterEach, describe, expect, it } from 'vitest'
import { cleanOutput } from '../scripts/artifact-utils.mjs'

const tempDirectories: string[] = []

afterEach(() => {
  for (const directory of tempDirectories.splice(0)) {
    rmSync(directory, { recursive: true, force: true })
  }
})

describe('构建产物门禁', () => {
  it('pre 清理函数同步删除整个输出目录及陈旧嵌套产物', () => {
    const root = mkdtempSync(join(tmpdir(), 'dsh-douyin-artifacts-'))
    tempDirectories.push(root)
    const output = join(root, 'lib')
    const sentinel = join(output, 'stale', 'sentinel.js')
    mkdirSync(join(output, 'stale'), { recursive: true })
    writeFileSync(sentinel, 'stale')

    cleanOutput(output)

    expect(existsSync(output)).toBe(false)
    expect(existsSync(sentinel)).toBe(false)
  })
})
