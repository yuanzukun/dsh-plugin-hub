import { describe, expect, it, beforeEach } from 'vitest'
import { DEFAULT_SOURCES, EMPTY_PREFS, allSources, readPrefs, writePrefs, type FeedPrefs, type VideoSource } from '../src/client/index.ts'

/** Minimal in-memory localStorage stand-in (Node has none). */
const memory = new Map<string, string>()
beforeEach(() => memory.clear())
;(globalThis as Record<string, unknown>).localStorage = {
  getItem: (k: string) => memory.get(k) ?? null,
  setItem: (k: string, v: string) => void memory.set(k, v),
}

describe('默认源列表', () => {
  it('至少含已验证的杜嘟嘟源，且字段完整', () => {
    expect(DEFAULT_SOURCES.length).toBeGreaterThanOrEqual(1)
    const dudu = DEFAULT_SOURCES.find(s => s.id === 'dudududu')
    expect(dudu).toBeDefined()
    expect(dudu!.url).toMatch(/^https?:\/\//)
    expect(dudu!.name.length).toBeGreaterThan(0)
  })

  it('杜嘟嘟为 feed 模式（原生播放器连播）', () => {
    expect(DEFAULT_SOURCES.find(s => s.id === 'dudududu')!.kind).toBe('feed')
  })

  it('id 在默认源内唯一', () => {
    const ids = DEFAULT_SOURCES.map(s => s.id)
    expect(new Set(ids).size).toBe(ids.length)
  })

  it('内置 21 个已验证系列，包含甜妹系列真实接口', () => {
    expect(DEFAULT_SOURCES).toHaveLength(21)
    expect(DEFAULT_SOURCES.find(s => s.id === 'sweet')).toEqual({
      id: 'sweet',
      name: '甜妹系列',
      kind: 'feed',
      url: 'https://api.yujn.cn/api/tianmei.php',
    })
  })

  it('所有内置系列均为 HTTPS feed，且不含未成年人语义分类', () => {
    expect(DEFAULT_SOURCES.every(s => s.kind === 'feed' && s.url.startsWith('https://'))).toBe(true)
    expect(DEFAULT_SOURCES.map(s => s.name).join('|')).not.toMatch(/萝莉|女高|未成年/)
  })
})

describe('prefs 持久化', () => {
  it('无存储时回退到空配置（激活第一个默认源）', () => {
    const prefs = readPrefs()
    expect(prefs).toEqual(EMPTY_PREFS)
    expect(prefs.activeSourceId).toBe(DEFAULT_SOURCES[0].id)
  })

  it('write → read 往返一致', () => {
    const custom: VideoSource = { id: 'custom-1', name: '我的源', url: 'https://example.com/', kind: 'feed', custom: true }
    const prefs: FeedPrefs = { activeSourceId: 'custom-1', customSources: [custom] }
    writePrefs(prefs)
    expect(readPrefs()).toEqual(prefs)
  })

  it('损坏的存储内容被丢弃而非抛错', () => {
    memory.set('dsh-douyin:prefs', '{not json!!')
    expect(readPrefs()).toEqual(EMPTY_PREFS)
  })

  it('存储中的非法自定义源条目被过滤，合法条目缺省 kind 回落为 web', () => {
    memory.set('dsh-douyin:prefs', JSON.stringify({
      activeSourceId: 'x',
      customSources: [{ id: 42 }, { id: 'ok', name: 'a', url: 'https://a.com' }],
    }))
    const prefs = readPrefs()
    expect(prefs.customSources).toHaveLength(1)
    expect(prefs.customSources[0].id).toBe('ok')
    expect(prefs.customSources[0].kind).toBe('web')
  })

  it('合法条目携带 kind 时原样保留', () => {
    memory.set('dsh-douyin:prefs', JSON.stringify({
      activeSourceId: 'x',
      customSources: [{ id: 'f', name: 'a', url: 'https://a.com', kind: 'feed' }],
    }))
    expect(readPrefs().customSources[0].kind).toBe('feed')
  })

  it('内置系列选择可持久化，失效的旧源 id 自动回落', () => {
    writePrefs({ activeSourceId: 'sweet', customSources: [] })
    expect(readPrefs().activeSourceId).toBe('sweet')

    memory.set('dsh-douyin:prefs', JSON.stringify({ activeSourceId: 'bilibili', customSources: [] }))
    expect(readPrefs().activeSourceId).toBe(DEFAULT_SOURCES[0].id)
  })
})

describe('源合并', () => {
  it('内置源在前，自定义源在后', () => {
    const custom: VideoSource = { id: 'custom-1', name: 'c', url: 'https://c.com/', custom: true }
    const merged = allSources({ activeSourceId: 'custom-1', customSources: [custom] })
    expect(merged.map(s => s.id)).toEqual([...DEFAULT_SOURCES.map(s => s.id), 'custom-1'])
  })

  it('空自定义列表时只含内置源', () => {
    expect(allSources(EMPTY_PREFS).map(s => s.id)).toEqual(DEFAULT_SOURCES.map(s => s.id))
  })
})
