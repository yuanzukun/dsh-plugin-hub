import { describe, expect, it } from 'vitest'
import {
  MAX_CONSECUTIVE_FAILURES,
  MAX_HISTORY_ENTRIES,
  acceptsWheel,
  appendBounded,
  nextFailureDecision,
  supportsSegmentNavigation,
} from '../src/client/player-policy.ts'

describe('播放器策略', () => {
  it('第三次连续失败停止自动重试，并采用递增退避', () => {
    const first = nextFailureDecision(0)
    const second = nextFailureDecision(first.count)
    const third = nextFailureDecision(second.count)

    expect(first).toEqual({ count: 1, retryDelayMs: 300 })
    expect(second).toEqual({ count: 2, retryDelayMs: 600 })
    expect(third).toEqual({ count: MAX_CONSECUTIVE_FAILURES, retryDelayMs: null })
  })

  it('滚轮节流时间跨切段状态判断保持一致', () => {
    expect(acceptsWheel(1_000, 1_399)).toBe(false)
    expect(acceptsWheel(1_000, 1_400)).toBe(true)
  })

  it('只有 feed 支持上下切段', () => {
    expect(supportsSegmentNavigation('feed')).toBe(true)
    expect(supportsSegmentNavigation('direct')).toBe(false)
    expect(supportsSegmentNavigation('web')).toBe(false)
  })

  it('历史只保留最近的固定上限', () => {
    const initial = Array.from({ length: MAX_HISTORY_ENTRIES }, (_, index) => index)
    const next = appendBounded(initial, MAX_HISTORY_ENTRIES)
    expect(next).toHaveLength(MAX_HISTORY_ENTRIES)
    expect(next[0]).toBe(1)
    expect(next.at(-1)).toBe(MAX_HISTORY_ENTRIES)
  })
})
