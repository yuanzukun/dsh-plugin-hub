/** Shared source contracts used by both the host resolver and browser client. */

export type SourceKind = 'feed' | 'direct' | 'web'

export interface VideoSource {
  /** Stable identifier used for persistence and React keys. */
  id: string
  /** Display name in the source navigation. */
  name: string
  /** Feed API, fixed media URL, or sandboxed web page. */
  kind: SourceKind
  url: string
  /** Marks a source restored from user-owned preferences. */
  custom?: boolean
}

/**
 * Verified category feeds. Explicitly minor-coded categories from the
 * upstream page are intentionally excluded.
 */
export const DEFAULT_SOURCES: readonly VideoSource[] = [
  { id: 'dudududu', name: '学姐系列', kind: 'feed', url: 'https://api.yujn.cn/api/zzxjj.php' },
  { id: 'kawaii', name: '卡哇伊', kind: 'feed', url: 'https://api.yujn.cn/api/xjj.php' },
  { id: 'tender', name: '嫩嫩系列', kind: 'feed', url: 'https://api.yujn.cn/api/juhexjj.php' },
  { id: 'dance', name: '丝滑舞蹈', kind: 'feed', url: 'https://api.yujn.cn/api/shwd.php' },
  { id: 'figure', name: '完美身材', kind: 'feed', url: 'https://api.yujn.cn/api/wmsc.php' },
  { id: 'feet', name: '极品玉足', kind: 'feed', url: 'https://api.yujn.cn/api/jpmt.php' },
  { id: 'slow', name: '慢摇系列', kind: 'feed', url: 'https://api.yujn.cn/api/manyao.php' },
  { id: 'sling', name: '丝滑吊带', kind: 'feed', url: 'https://api.yujn.cn/api/diaodai.php' },
  { id: 'pure', name: '清纯系列', kind: 'feed', url: 'https://api.yujn.cn/api/qingchun.php' },
  { id: 'cos', name: 'COS系列', kind: 'feed', url: 'https://api.yujn.cn/api/COS.php' },
  { id: 'street', name: '街拍系列', kind: 'feed', url: 'https://api.yujn.cn/api/jiepai.php' },
  { id: 'song', name: '懒洋洋歌', kind: 'feed', url: 'https://api.yujn.cn/api/lyy.php' },
  { id: 'dream', name: '你的欲梦', kind: 'feed', url: 'https://api.yujn.cn/api/ndym.php' },
  { id: 'sweet', name: '甜妹系列', kind: 'feed', url: 'https://api.yujn.cn/api/tianmei.php' },
  { id: 'silk', name: '御丝系列', kind: 'feed', url: 'https://api.yujn.cn/api/jksp.php' },
  { id: 'pretty-feet', name: '超美玉足', kind: 'feed', url: 'https://api.yujn.cn/api/yuzu.php' },
  { id: 'hot-dance', name: '热舞系列', kind: 'feed', url: 'https://api.yujn.cn/api/rewu.php' },
  { id: 'stockings', name: '精品丝袜', kind: 'feed', url: 'https://api.yujn.cn/api/heisis.php' },
  { id: 'outfit', name: '正常穿搭', kind: 'feed', url: 'https://api.yujn.cn/api/chuanda.php' },
  { id: 'zhang-ruonan', name: '章若楠', kind: 'feed', url: 'https://api.yujn.cn/api/zrn.php' },
  { id: 'ju-jingyi', name: '鞠婧祎', kind: 'feed', url: 'https://api.yujn.cn/api/jjy.php' },
]
