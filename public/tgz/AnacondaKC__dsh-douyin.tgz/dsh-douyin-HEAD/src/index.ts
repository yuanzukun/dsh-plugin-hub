/**
 * Host-side resolver for the built-in random-video feeds. Browsers cannot
 * observe the CORS-less 302 target, so this route returns the first redirect
 * location without downloading the media body.
 */
import { lookup } from 'node:dns/promises'
import { isIP } from 'node:net'
import type { Context } from '@deepseek-ai/cordis'
import type {} from '@deepseek-ai/dsh-host-webserver'
import type { ServerResponse } from 'node:http'
import { DEFAULT_SOURCES } from './feed-sources.ts'

export const name = 'dsh-douyin'
export const inject = ['webServer']
export const RESOLVE_ROUTE = '/dsh-douyin/resolve'

const RESOLVE_TIMEOUT_MS = 8000
const MAX_REQUEST_URL_LENGTH = 2048
const MAX_FEED_URL_LENGTH = 1024
const MAX_CONCURRENT_RESOLVES = 8
const RATE_WINDOW_MS = 10_000
const MAX_RESOLVES_PER_WINDOW = 60

const ALLOWED_FEEDS = new Set(DEFAULT_SOURCES
  .filter(source => source.kind === 'feed')
  .map(source => {
    const url = new URL(source.url)
    return `${url.origin}${url.pathname}`
  }))

let activeResolves = 0
let rateWindowStartedAt = 0
let resolvesInWindow = 0

/** Only built-in HTTPS feed endpoints may make the host issue a request. */
export function isAllowedFeedUrl(rawUrl: string): boolean {
  if (rawUrl.length === 0 || rawUrl.length > MAX_FEED_URL_LENGTH) return false
  let target: URL
  try {
    target = new URL(rawUrl)
  } catch {
    return false
  }
  if (target.protocol !== 'https:' || target.username !== '' || target.password !== '' || target.port !== '' || target.hash !== '') {
    return false
  }
  if (!ALLOWED_FEEDS.has(`${target.origin}${target.pathname}`)) return false
  const keys = [...target.searchParams.keys()]
  return keys.length <= 1 && keys.every(key => key === '_t')
}

function takeRateSlot(now = Date.now()): boolean {
  if (now - rateWindowStartedAt >= RATE_WINDOW_MS) {
    rateWindowStartedAt = now
    resolvesInWindow = 0
  }
  if (resolvesInWindow >= MAX_RESOLVES_PER_WINDOW) return false
  resolvesInWindow += 1
  return true
}

function isPublicIpv4(address: string): boolean {
  const octets = address.split('.').map(Number)
  if (octets.length !== 4 || octets.some(octet => !Number.isInteger(octet) || octet < 0 || octet > 255)) return false
  const [a, b, c] = octets as [number, number, number, number]
  if (a === 0 || a === 10 || a === 127 || a >= 224) return false
  if (a === 100 && b >= 64 && b <= 127) return false
  if (a === 169 && b === 254) return false
  if (a === 172 && b >= 16 && b <= 31) return false
  if (a === 192 && (b === 168 || (b === 0 && c === 0) || (b === 0 && c === 2))) return false
  if (a === 198 && (b === 18 || b === 19 || (b === 51 && c === 100))) return false
  if (a === 203 && b === 0 && c === 113) return false
  return true
}

function parseIpv6(address: string): number[] | null {
  const unzoned = address.toLowerCase().split('%', 1)[0]!
  const lastColon = unzoned.lastIndexOf(':')
  let normalized = unzoned
  if (unzoned.includes('.')) {
    const ipv4 = unzoned.slice(lastColon + 1)
    const octets = ipv4.split('.').map(Number)
    if (octets.length !== 4 || octets.some(value => !Number.isInteger(value) || value < 0 || value > 255)) return null
    normalized = `${unzoned.slice(0, lastColon)}:${((octets[0]! << 8) | octets[1]!).toString(16)}:${((octets[2]! << 8) | octets[3]!).toString(16)}`
  }
  const halves = normalized.split('::')
  if (halves.length > 2) return null
  const left = halves[0] === '' ? [] : halves[0]!.split(':')
  const right = halves.length === 1 || halves[1] === '' ? [] : halves[1]!.split(':')
  const missing = 8 - left.length - right.length
  if ((halves.length === 1 && missing !== 0) || (halves.length === 2 && missing < 1)) return null
  const words = [...left, ...Array.from({ length: missing }, () => '0'), ...right]
    .map(word => Number.parseInt(word, 16))
  return words.length === 8 && words.every(word => Number.isInteger(word) && word >= 0 && word <= 0xffff)
    ? words
    : null
}

export function isPublicIpAddress(address: string): boolean {
  const family = isIP(address)
  if (family === 4) return isPublicIpv4(address)
  if (family !== 6) return false
  const words = parseIpv6(address)
  if (words === null) return false
  const [a, b] = words
  if (words.slice(0, 5).every(word => word === 0) && words[5] === 0xffff) {
    return isPublicIpv4(`${words[6]! >> 8}.${words[6]! & 255}.${words[7]! >> 8}.${words[7]! & 255}`)
  }
  if (words.every(word => word === 0) || (words.slice(0, 7).every(word => word === 0) && words[7] === 1)) return false
  if ((a! & 0xfe00) === 0xfc00 || (a! & 0xffc0) === 0xfe80 || (a! & 0xff00) === 0xff00) return false
  if (a === 0x0100 && b === 0) return false
  if (a === 0x2001 && (b === 0 || b === 0x0002 || b === 0x000d || b === 0x0db8)) return false
  return true
}

type HostLookup = (hostname: string) => Promise<readonly { address: string }[]>

const lookupAll: HostLookup = async hostname => lookup(hostname, { all: true, verbatim: true })

export async function isSafeRedirectTarget(target: URL, resolveHost: HostLookup = lookupAll): Promise<boolean> {
  if ((target.protocol !== 'http:' && target.protocol !== 'https:') || target.username !== '' || target.password !== '') return false
  if (isIP(target.hostname) !== 0) return isPublicIpAddress(target.hostname)
  try {
    const addresses = await resolveHost(target.hostname)
    return addresses.length > 0 && addresses.every(({ address }) => isPublicIpAddress(address))
  } catch {
    return false
  }
}

/** Resolve an allowlisted feed URL to its first public HTTP redirect target. */
export async function resolveRedirect(rawUrl: string): Promise<string | null> {
  if (!isAllowedFeedUrl(rawUrl)) return null
  const target = new URL(rawUrl)
  try {
    const res = await fetch(target, {
      method: 'HEAD',
      redirect: 'manual',
      signal: AbortSignal.timeout(RESOLVE_TIMEOUT_MS),
    })
    if (res.status < 300 || res.status >= 400) return null
    const location = res.headers.get('location')
    if (location === null) return null
    const redirected = new URL(location, target)
    if (!await isSafeRedirectTarget(redirected)) return null
    return redirected.href === target.href ? null : redirected.href
  } catch {
    return null
  }
}

function sendJson(res: ServerResponse, statusCode: number, body: { url: string | null, error?: string }): void {
  res.statusCode = statusCode
  res.setHeader('content-type', 'application/json; charset=utf-8')
  res.setHeader('cache-control', 'no-store')
  res.setHeader('x-content-type-options', 'nosniff')
  res.end(JSON.stringify(body))
}

export function apply(ctx: Context): void {
  ctx.effect(() => ctx.webServer.register({
    kind: 'exact',
    path: RESOLVE_ROUTE,
    async handler(req, res): Promise<void> {
      if (req.method !== 'GET') {
        res.setHeader('allow', 'GET')
        sendJson(res, 405, { url: null, error: 'method-not-allowed' })
        return
      }
      if ((req.url?.length ?? 0) > MAX_REQUEST_URL_LENGTH) {
        sendJson(res, 414, { url: null, error: 'request-url-too-long' })
        return
      }
      const rawUrl = new URL(req.url ?? '', 'http://localhost').searchParams.get('u')
      if (rawUrl === null || !isAllowedFeedUrl(rawUrl)) {
        sendJson(res, 400, { url: null, error: 'feed-not-allowed' })
        return
      }
      if (activeResolves >= MAX_CONCURRENT_RESOLVES || !takeRateSlot()) {
        sendJson(res, 429, { url: null, error: 'resolver-busy' })
        return
      }
      activeResolves += 1
      try {
        sendJson(res, 200, { url: await resolveRedirect(rawUrl) })
      } finally {
        activeResolves -= 1
      }
    },
  }), 'dsh-douyin:resolve-route')
}
