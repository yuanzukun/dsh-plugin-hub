export const WHEEL_THROTTLE_MS = 400
export const FAILURE_RETRY_BASE_MS = 300
export const MAX_CONSECUTIVE_FAILURES = 3
export const MAX_HISTORY_ENTRIES = 100

export interface FailureDecision {
  count: number
  retryDelayMs: number | null
}

/** A null delay means automatic retries must stop and surface an error. */
export function nextFailureDecision(previousCount: number): FailureDecision {
  const count = Math.max(0, previousCount) + 1
  return {
    count,
    retryDelayMs: count >= MAX_CONSECUTIVE_FAILURES
      ? null
      : FAILURE_RETRY_BASE_MS * count,
  }
}

export function acceptsWheel(lastAcceptedAt: number, now: number): boolean {
  return now - lastAcceptedAt >= WHEEL_THROTTLE_MS
}

export function supportsSegmentNavigation(kind: 'feed' | 'direct' | 'web'): boolean {
  return kind === 'feed'
}

export function appendBounded<T>(entries: readonly T[], entry: T, limit = MAX_HISTORY_ENTRIES): T[] {
  const appended = [...entries, entry]
  if (limit <= 0) return []
  return appended.length > limit ? appended.slice(appended.length - limit) : appended
}
