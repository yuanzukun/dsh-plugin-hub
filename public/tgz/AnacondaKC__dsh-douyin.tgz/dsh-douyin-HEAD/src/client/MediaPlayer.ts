/**
 * Native media player for dsh-douyin: plays `feed` sources (a random-video
 * URL that yields a different clip per request — automatically fetches the
 * next one on end, infinite autoplay) and `direct` sources (one fixed file,
 * replayable).
 *
 * Navigation (feed mode only):
 *  - wheel down  → next segment; wheel up → previous segment (400ms throttle)
 *  - every segment is recorded in a history stack. New segments are resolved
 *    through the host resolver first, so the history holds the REAL direct
 *    URL: going back or forward replays the exact clip instead of asking the
 *    API for a new random one. If resolution fails, the request URL is played
 *    as-is.
 *
 * Autoplay policy: every segment starts muted (browser-safe). Clicking the
 * video toggles play/pause; volume and mute live in the right-side control.
 */
import { createElement, useCallback, useEffect, useLayoutEffect, useRef, useState } from 'react'
import LoaderCircle from 'lucide-react/dist/esm/icons/loader-circle.js'
import Pause from 'lucide-react/dist/esm/icons/pause.js'
import Play from 'lucide-react/dist/esm/icons/play.js'
import Volume1 from 'lucide-react/dist/esm/icons/volume-1.js'
import Volume2 from 'lucide-react/dist/esm/icons/volume-2.js'
import VolumeX from 'lucide-react/dist/esm/icons/volume-x.js'
import type { VideoSource } from './index.ts'
import {
  acceptsWheel,
  appendBounded,
  nextFailureDecision,
  supportsSegmentNavigation,
} from './player-policy.ts'

/** Cache-busting suffix for random feed requests. */
function bustedUrl(url: string): string {
  return `${url}${url.includes('?') ? '&' : '?'}_t=${Date.now()}`
}

/**
 * Resolve the real video URL behind a feed API request. Browsers cannot see
 * the redirect target of a CORS-less 302, so the host resolver returns the
 * final direct URL. A null result is treated as a failed segment; playing the
 * feed URL directly would make historical replay random again.
 */
async function resolveFeedUrl(url: string, signal: AbortSignal): Promise<string | null> {
  try {
    const res = await fetch(`/dsh-douyin/resolve?u=${encodeURIComponent(url)}`, { signal })
    if (!res.ok) return null
    const data = await res.json() as { url?: unknown }
    if (typeof data.url !== 'string') return null
    const resolved = new URL(data.url)
    return resolved.protocol === 'http:' || resolved.protocol === 'https:' ? resolved.href : null
  } catch (error) {
    if (signal.aborted) throw error
    return null
  }
}

export interface MediaPlayerProps {
  source: VideoSource
}

type PlayerStatus = 'loading' | 'ready' | 'error'

/** One playback position: a feed request URL (`live`) or a resolved direct URL. */
interface HistoryEntry {
  url: string
  /** True while the entry still points at the feed request; resolved once the redirect target is known. */
  live: boolean
}

/** Minimum vertical touch travel before a gesture switches clips. */
const SWIPE_THRESHOLD_PX = 56
/** Keyboard seek distance. */
const SEEK_STEP_SECONDS = 5

function formatTime(seconds: number): string {
  if (!Number.isFinite(seconds) || seconds < 0) return '0:00'
  const whole = Math.floor(seconds)
  const minutes = Math.floor(whole / 60)
  return `${minutes}:${String(whole % 60).padStart(2, '0')}`
}

export function MediaPlayer(props: MediaPlayerProps): React.ReactElement {
  const source = props.source
  const isFeed = source.kind === 'feed'
  const stageRef = useRef<HTMLDivElement>(null)
  // Playback history, keyed by position; index walks it both ways.
  const historyRef = useRef<HistoryEntry[]>([])
  if (historyRef.current.length === 0) {
    historyRef.current = [{ url: isFeed ? bustedUrl(source.url) : source.url, live: isFeed }]
  }
  const [index, setIndex] = useState(0)
  const [revision, setRevision] = useState(0)
  const [status, setStatus] = useState<PlayerStatus>('loading')
  const [paused, setPaused] = useState(false)
  const [currentTime, setCurrentTime] = useState(0)
  const [duration, setDuration] = useState(0)
  const [muted, setMuted] = useState(true)
  /** Master volume 0–1, independent from the mute toggle. */
  const [volume, setVolume] = useState(1)
  const [volumeOpen, setVolumeOpen] = useState(false)
  const volumeRef = useRef<HTMLDivElement>(null)
  const videoRef = useRef<HTMLVideoElement>(null)
  const touchStartRef = useRef<{ x: number, y: number } | null>(null)
  const suppressClickUntilRef = useRef(0)
  const lastWheelAtRef = useRef(0)
  const failureCountRef = useRef(0)
  const retryTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null)
  const effectiveMuted = muted || volume === 0

  const entry = historyRef.current[index]
  // key drives <video> rebuilds: a fresh segment, a history walk, or a
  // resolved URL all get a clean element.
  const key = `${source.id}:${index}:${entry.url}:${revision}`

  const clearRetryTimer = useCallback((): void => {
    if (retryTimerRef.current === null) return
    clearTimeout(retryTimerRef.current)
    retryTimerRef.current = null
  }, [])

  const resetFailures = useCallback((): void => {
    clearRetryTimer()
    failureCountRef.current = 0
  }, [clearRetryTimer])

  const goTo = useCallback((nextIndex: number) => {
    clearRetryTimer()
    setIndex(nextIndex)
    setStatus('loading')
    setPaused(false)
    setCurrentTime(0)
    setDuration(0)
    setVolumeOpen(false)
  }, [clearRetryTimer])

  /** Forward through feed history or append one bounded fresh request. */
  const next = useCallback(() => {
    if (!supportsSegmentNavigation(source.kind)) return
    const hist = historyRef.current
    if (index < hist.length - 1) {
      goTo(index + 1)
      return
    }
    historyRef.current = appendBounded(hist, { url: bustedUrl(source.url), live: true })
    setRevision(current => current + 1)
    goTo(historyRef.current.length - 1)
  }, [index, goTo, source.kind, source.url])

  /** Backward navigation exists only for random feeds. */
  const prev = useCallback(() => {
    if (isFeed && index > 0) goTo(index - 1)
  }, [index, isFeed, goTo])

  const handleReady = useCallback(() => {
    resetFailures()
    setStatus('ready')
  }, [resetFailures])

  const handleCanPlay = useCallback((): void => {
    handleReady()
    const video = videoRef.current
    if (video === null || !video.paused || paused) return
    void video.play().catch(() => setPaused(true))
  }, [handleReady, paused])

  /** Feed failures retry with backoff and stop after a strict upper bound. */
  const handleError = useCallback(() => {
    clearRetryTimer()
    if (!isFeed) {
      setStatus('error')
      return
    }
    const decision = nextFailureDecision(failureCountRef.current)
    failureCountRef.current = decision.count
    if (decision.retryDelayMs === null) {
      setStatus('error')
      return
    }
    setStatus('loading')
    retryTimerRef.current = setTimeout(() => {
      retryTimerRef.current = null
      next()
    }, decision.retryDelayMs)
  }, [clearRetryTimer, isFeed, next])

  const retry = useCallback(() => {
    resetFailures()
    setStatus('loading')
    setPaused(false)
    setCurrentTime(0)
    setDuration(0)
    setRevision(current => current + 1)
  }, [resetFailures])

  const skipFailed = useCallback(() => {
    resetFailures()
    next()
  }, [next, resetFailures])

  const toggleMute = useCallback(() => setMuted(m => !m), [])

  const togglePlayback = useCallback((): void => {
    const video = videoRef.current
    if (video === null) return
    if (video.paused) {
      if (video.ended) video.currentTime = 0
      void video.play().catch(() => setPaused(true))
    } else {
      video.pause()
    }
  }, [])

  const handleVideoClick = useCallback((): void => {
    if (Date.now() < suppressClickUntilRef.current) return
    stageRef.current?.focus({ preventScroll: true })
    setVolumeOpen(false)
    togglePlayback()
  }, [togglePlayback])

  const handleDurationChange = useCallback((): void => {
    const video = videoRef.current
    setDuration(video !== null && Number.isFinite(video.duration) ? video.duration : 0)
  }, [])

  const handleTimeUpdate = useCallback((): void => {
    const video = videoRef.current
    if (video !== null) setCurrentTime(video.currentTime)
  }, [])

  const handleSeek = useCallback((event: React.ChangeEvent<HTMLInputElement>): void => {
    const nextTime = Number(event.target.value)
    const video = videoRef.current
    if (video !== null && Number.isFinite(nextTime)) video.currentTime = nextTime
    setCurrentTime(nextTime)
  }, [])

  const seekBy = useCallback((seconds: number): void => {
    const video = videoRef.current
    if (video === null || !Number.isFinite(video.duration)) return
    video.currentTime = Math.min(video.duration, Math.max(0, video.currentTime + seconds))
    setCurrentTime(video.currentTime)
  }, [])

  const handleTouchStart = useCallback((event: React.TouchEvent<HTMLVideoElement>): void => {
    if (!isFeed) return
    const touch = event.touches[0]
    if (touch !== undefined) touchStartRef.current = { x: touch.clientX, y: touch.clientY }
  }, [isFeed])

  const handleTouchEnd = useCallback((event: React.TouchEvent<HTMLVideoElement>): void => {
    const start = touchStartRef.current
    const touch = event.changedTouches[0]
    touchStartRef.current = null
    if (start === null || touch === undefined) return
    const deltaX = touch.clientX - start.x
    const deltaY = touch.clientY - start.y
    if (Math.abs(deltaY) < SWIPE_THRESHOLD_PX || Math.abs(deltaY) <= Math.abs(deltaX)) return
    event.preventDefault()
    suppressClickUntilRef.current = Date.now() + 500
    if (deltaY < 0) next()
    else prev()
  }, [next, prev])

  const handlePlayerKeyDown = useCallback((event: React.KeyboardEvent<HTMLDivElement>): void => {
    if ((event.target as HTMLElement).closest('button,input') !== null) return
    if (event.key === ' ' || event.key.toLowerCase() === 'k') {
      event.preventDefault()
      togglePlayback()
    } else if (event.key.toLowerCase() === 'm') {
      event.preventDefault()
      toggleMute()
    } else if (event.key === 'ArrowDown' && isFeed) {
      event.preventDefault()
      next()
    } else if (event.key === 'ArrowUp' && isFeed) {
      event.preventDefault()
      prev()
    } else if (event.key === 'ArrowLeft') {
      event.preventDefault()
      seekBy(-SEEK_STEP_SECONDS)
    } else if (event.key === 'ArrowRight') {
      event.preventDefault()
      seekBy(SEEK_STEP_SECONDS)
    }
  }, [isFeed, next, prev, seekBy, toggleMute, togglePlayback])

  // React's volume prop is unreliable on <video>: browsers restore the
  // pre-mute volume when unmuting. Re-apply our volume on every change of
  // volume OR effective mute state (layout effect beats the browser reset).
  useLayoutEffect(() => {
    if (videoRef.current !== null) videoRef.current.volume = volume
  }, [key, volume, effectiveMuted])

  const toggleVolumePanel = useCallback(() => setVolumeOpen(open => !open), [])

  /** Slider change: apply volume and un-mute when raised above zero. */
  const handleVolumeChange = useCallback((event: React.ChangeEvent<HTMLInputElement>): void => {
    const next = Math.min(1, Math.max(0, Number(event.target.value) / 100))
    setVolume(next)
    if (next > 0) setMuted(false)
  }, [])

  useEffect(() => () => clearRetryTimer(), [clearRetryTimer])

  // Close the volume panel on outside pointer interactions.
  useEffect(() => {
    if (!volumeOpen) return
    const onDown = (event: PointerEvent): void => {
      if (volumeRef.current !== null && !volumeRef.current.contains(event.target as Node)) {
        setVolumeOpen(false)
      }
    }
    document.addEventListener('pointerdown', onDown)
    return () => document.removeEventListener('pointerdown', onDown)
  }, [volumeOpen])

  // Resolve a live feed request to its real redirect target before mounting
  // the video. An unresolved feed is a failed segment: retaining the request
  // URL would make a later history replay return a different random clip.
  useEffect(() => {
    const current = historyRef.current[index]
    if (current === undefined || !current.live || !isFeed) return
    const controller = new AbortController()
    setStatus('loading')
    resolveFeedUrl(current.url, controller.signal)
      .then(final => {
        if (controller.signal.aborted) return
        if (final === null) {
          handleError()
          return
        }
        historyRef.current = historyRef.current.map((h, i) =>
          i === index ? { url: final, live: false } : h,
        )
        setRevision(r => r + 1)
      })
      .catch(() => {
        if (!controller.signal.aborted) handleError()
      })
    return () => controller.abort()
  }, [index, revision, isFeed, handleError])

  // Wheel navigation: native non-passive listener so page scroll is
  // suppressed while the panel is being flicked through.
  useEffect(() => {
    const stage = stageRef.current
    if (stage === null || !isFeed) return
    const onWheel = (event: WheelEvent): void => {
      event.preventDefault()
      if ((event.target as HTMLElement).closest('button,input,.vf-volume-wrap,.vf-progress-shell') !== null) return
      const now = Date.now()
      if (!acceptsWheel(lastWheelAtRef.current, now)) return
      lastWheelAtRef.current = now
      if (event.deltaY > 0) next()
      else if (event.deltaY < 0) prev()
    }
    stage.addEventListener('wheel', onWheel, { passive: false })
    return () => stage.removeEventListener('wheel', onWheel)
  }, [isFeed, next, prev])

  const statusOverlay =
    status === 'loading'
      ? createElement('div', {
          className: 'vf-overlay vf-overlay-loading',
          role: 'status',
          'aria-label': '加载中',
        }, createElement(LoaderCircle, {
          className: 'vf-spinner',
          size: 30,
          strokeWidth: 2,
          'aria-hidden': true,
        }))
      : status === 'error'
        ? createElement('div', { className: 'vf-overlay' },
            createElement('span', { className: 'vf-overlay-text' }, '加载失败，可能接口失效或网络问题'),
            createElement('div', { className: 'vf-overlay-actions' },
              createElement('button', { className: 'vf-btn', onClick: retry }, '重试'),
              isFeed ? createElement('button', { className: 'vf-btn', onClick: skipFailed }, '下一个') : null,
            ),
          )
        : null

  const progressMax = duration > 0 ? duration : 0
  const progressValue = Math.min(currentTime, progressMax)
  const progressPercent = progressMax > 0 ? progressValue / progressMax * 100 : 0
  const CenterIcon = paused ? Play : Pause

  return createElement('div', {
    className: 'vf-player',
    ref: stageRef,
    role: 'region',
    'aria-label': `${source.name} 视频播放器`,
    tabIndex: 0,
    onKeyDown: handlePlayerKeyDown,
  },
    createElement('video', {
      key,
      className: 'vf-video',
      ref: videoRef,
      src: entry.live ? undefined : entry.url,
      autoPlay: true,
      muted: effectiveMuted,
      playsInline: true,
      onClick: handleVideoClick,
      onTouchStart: handleTouchStart,
      onTouchEnd: handleTouchEnd,
      onLoadedMetadata: handleDurationChange,
      onDurationChange: handleDurationChange,
      onTimeUpdate: handleTimeUpdate,
      onCanPlay: handleCanPlay,
      onPlay: () => setPaused(false),
      onPlaying: () => { setPaused(false); handleReady() },
      onPause: () => setPaused(true),
      onWaiting: () => setStatus('loading'),
      onStalled: () => setStatus('loading'),
      onEnded: () => { if (isFeed) next(); else setPaused(true) },
      onError: () => handleError(),
    }),
    statusOverlay,
    status === 'ready'
      ? createElement('button', {
          className: 'vf-center-control',
          type: 'button',
          title: paused ? '继续播放' : '暂停',
          'aria-label': paused ? '继续播放' : '暂停',
          'data-paused': paused ? true : undefined,
          onClick: togglePlayback,
        }, createElement(CenterIcon, {
          size: 30,
          fill: paused ? 'currentColor' : 'none',
          strokeWidth: 2.1,
          'aria-hidden': true,
        }))
      : null,
    createElement('div', { className: 'vf-video-meta' },
      createElement('strong', null, source.name),
    ),
    createElement('div', { className: 'vf-progress-shell' },
      createElement('input', {
        className: 'vf-progress-slider',
        type: 'range',
        min: 0,
        max: progressMax,
        step: 0.05,
        value: progressValue,
        disabled: progressMax === 0,
        style: { '--vf-progress': `${progressPercent}%` } as React.CSSProperties,
        'aria-label': '播放进度',
        onChange: handleSeek,
      }),
      createElement('span', { className: 'vf-progress-time' },
        `${formatTime(currentTime)} / ${formatTime(duration)}`,
      ),
    ),
    createElement('div', { className: 'vf-volume-wrap', ref: volumeRef },
      volumeOpen
        ? createElement('div', { className: 'vf-volume-pop' },
            createElement('input', {
              className: 'vf-volume-slider',
              type: 'range',
              min: 0,
              max: 100,
              step: 1,
              value: Math.round(volume * 100),
              'aria-label': '音量',
              onChange: handleVolumeChange,
            }),
            createElement('span', { className: 'vf-volume-value' }, `${Math.round(volume * 100)}%`),
          )
        : null,
      createElement('button', {
        className: 'vf-fab-btn',
        title: '音量',
        'aria-label': '调节音量',
        onClick: toggleVolumePanel,
        'data-active': volumeOpen ? true : effectiveMuted ? undefined : true,
      }, createElement(effectiveMuted
        ? VolumeX
        : volume < 0.5 ? Volume1 : Volume2, {
        size: 18,
        strokeWidth: 2.2,
        'aria-hidden': true,
      })),
    ),
  )
}
