/**
 * dsh-douyin browser half: a sidebar video-feed panel.
 *
 * Mounting is dual-mode, mirroring dsh-browser-panel's compatibility pattern:
 *  - when the `betterSidebar` service is present (dsh-better-sidebar
 *    installed), the panel registers itself as a sidebar tab via its official
 *    registerTab protocol;
 *  - otherwise it falls back to a self-drawn right dock with a floating
 *    toggle button, so the plugin works with zero extra dependencies.
 *
 * The source list is data-driven (`VideoSource[]`): built-in defaults plus
 * user-added custom sources, persisted in localStorage. Swapping feeds later
 * (a new aggregator site, a different embed URL) means adding an entry —
 * no code changes. The shape is kept deliberately small so it can later be
 * promoted to host settings (settings namespace + RPC) without a UI rewrite.
 */
import { createElement, useCallback, useEffect, useMemo, useRef, useState } from 'react'
import ChevronLeft from 'lucide-react/dist/esm/icons/chevron-left.js'
import ChevronRight from 'lucide-react/dist/esm/icons/chevron-right.js'
import PanelRightClose from 'lucide-react/dist/esm/icons/panel-right-close.js'
import PanelRightOpen from 'lucide-react/dist/esm/icons/panel-right-open.js'
import Play from 'lucide-react/dist/esm/icons/play.js'
import { createRoot, type Root } from 'react-dom/client'
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client'
import { DEFAULT_SOURCES, type SourceKind, type VideoSource } from '../feed-sources.ts'
import { MediaPlayer } from './MediaPlayer.ts'

export { DEFAULT_SOURCES }
export type { SourceKind, VideoSource }

/** Plugin id == bundle registration key. */
export const ID = 'dsh-douyin'

const STYLE_TAG_ID = `${ID}/styles`
const PREFS_KEY = `${ID}:prefs`

/** Old persisted entries (v0.1, no kind) default to iframe mode. */
const LEGACY_KIND: SourceKind = 'web'

/** Persisted panel prefs: active source + user-added sources. */
export interface FeedPrefs {
  activeSourceId: string
  customSources: VideoSource[]
}

export const EMPTY_PREFS: FeedPrefs = { activeSourceId: DEFAULT_SOURCES[0]!.id, customSources: [] }

/** Display labels for the three source modes (add-form radio + tab tooltip). */
export const KIND_LABEL: Record<SourceKind, string> = {
  feed: '随机流',
  direct: '单视频',
  web: '网页',
}

export function readPrefs(): FeedPrefs {
  try {
    const raw = localStorage.getItem(PREFS_KEY)
    if (!raw) return EMPTY_PREFS
    const parsed = JSON.parse(raw) as Partial<FeedPrefs>
    const customSources = Array.isArray(parsed.customSources)
      ? (parsed.customSources as VideoSource[]).filter(s => s && typeof s.id === 'string' && typeof s.name === 'string' && typeof s.url === 'string')
        .map(s => ({ ...s, kind: s.kind ?? LEGACY_KIND }))
      : []
    const candidates = [...DEFAULT_SOURCES, ...customSources]
    const activeSourceId = typeof parsed.activeSourceId === 'string' && candidates.some(s => s.id === parsed.activeSourceId)
      ? parsed.activeSourceId
      : EMPTY_PREFS.activeSourceId
    return { activeSourceId, customSources }
  } catch {
    return EMPTY_PREFS
  }
}

export function writePrefs(prefs: FeedPrefs): void {
  try {
    localStorage.setItem(PREFS_KEY, JSON.stringify(prefs))
  } catch {
    // storage unavailable — prefs just won't persist
  }
}

/** All sources, built-ins first, then customs. */
export function allSources(prefs: FeedPrefs): VideoSource[] {
  return [...DEFAULT_SOURCES, ...prefs.customSources]
}

/** No hard inject: services are probed optionally at apply time. */
export const inject: string[] = []

/* ------------------------------------------------------------------ */
/* Styles — plugin-owned tag, theme-aware via official CSS variables.  */
/* ------------------------------------------------------------------ */

const css = `
#root{transition:margin-right var(--ds-transition-duration-slow,200ms) var(--ds-ease-in-out,ease)}
.vf-root{position:relative;display:flex;flex-direction:column;width:100%;height:100%;min-height:0;background:#050505;color:#fff;font:13px/1.5 system-ui,-apple-system,Segoe UI,Roboto,sans-serif}
.vf-series-bar{box-sizing:border-box;position:absolute;top:0;left:0;right:0;height:70px;display:flex;align-items:center;gap:8px;padding:8px 9px 16px;background:linear-gradient(to bottom,rgba(0,0,0,.82),rgba(0,0,0,.46) 58%,rgba(0,0,0,0));z-index:7}
.vf-series-nav{min-width:0;flex:1;display:grid;grid-template-columns:28px minmax(0,1fr) 28px;align-items:center;gap:3px}
.vf-series-arrow{width:28px;height:32px;display:grid;place-items:center;padding:0;border:0;background:rgba(18,18,18,.62);color:rgba(255,255,255,.82);border-radius:50%;cursor:pointer;backdrop-filter:blur(10px)}
.vf-series-arrow:hover:not(:disabled){background:rgba(254,44,85,.92);color:#fff}
.vf-series-arrow:focus-visible,.vf-series-track:focus-visible{outline:2px solid #25f4ee;outline-offset:2px}
.vf-series-arrow:disabled{opacity:.24;cursor:default}
.vf-series-track{--vf-series-item-w:92px;--vf-series-item-half:46px;min-width:0;height:40px;display:flex;align-items:center;gap:4px;padding-inline:calc(50% - var(--vf-series-item-half));overflow-x:auto;overflow-y:hidden;scroll-snap-type:x mandatory;scrollbar-width:none;overscroll-behavior-x:contain;touch-action:pan-x;outline:0}
.vf-series-track::-webkit-scrollbar{display:none}
.vf-series-item{position:relative;flex:0 0 var(--vf-series-item-w);height:32px;overflow:hidden;padding:0 7px;border:0;background:rgba(20,20,20,.26);color:rgba(255,255,255,.36);border-radius:16px;font:650 12px/1.1 system-ui,-apple-system,Segoe UI,Roboto,sans-serif;white-space:nowrap;text-overflow:ellipsis;cursor:pointer;scroll-snap-align:center;scroll-snap-stop:always;backdrop-filter:blur(8px);transition:background-color 140ms ease,color 140ms ease,transform 140ms ease,opacity 140ms ease}
.vf-series-item[data-distance="3"]{opacity:.36}
.vf-series-item[data-distance="2"]{background:rgba(25,25,25,.34);color:rgba(255,255,255,.52)}
.vf-series-item[data-distance="1"]{background:rgba(26,26,26,.58);color:rgba(255,255,255,.72)}
.vf-series-item[data-distance="0"]{background:rgba(8,8,8,.84);color:#fff;transform:scale(1.04);box-shadow:-2px 0 0 #25f4ee,2px 0 0 #fe2c55}
.vf-series-item[data-distance="0"]::after{content:"";position:absolute;left:50%;bottom:3px;width:20px;height:2px;background:#fff;transform:translateX(-50%)}
.vf-series-item:hover{background:rgba(35,35,35,.78);color:#fff}
.vf-series-item:focus-visible{outline:2px solid #25f4ee;outline-offset:-2px}
.vf-stage{flex:1;min-height:0;position:relative;background:#000}
.vf-stage::after{content:"";position:absolute;left:0;right:0;bottom:0;height:170px;background:linear-gradient(to top,rgba(0,0,0,.82),rgba(0,0,0,.3) 48%,rgba(0,0,0,0));pointer-events:none;z-index:3}
.vf-stage iframe{position:absolute;inset:0;width:100%;height:100%;border:0;display:block}
.vf-player{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;background:#000;overflow:hidden;outline:0;touch-action:none}
.vf-player:focus-visible{box-shadow:inset 0 0 0 2px rgba(37,244,238,.72)}
.vf-video{width:100%;height:100%;object-fit:cover;object-position:center;display:block;cursor:pointer;-webkit-tap-highlight-color:transparent}
.vf-overlay{position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:10px;background:rgba(0,0,0,.66);color:#fff;z-index:6}
.vf-overlay-loading{background:transparent;pointer-events:none}
.vf-spinner{animation:vf-spin .8s linear infinite;filter:drop-shadow(0 2px 8px rgba(0,0,0,.7))}
@keyframes vf-spin{to{transform:rotate(360deg)}}
.vf-overlay-text{font-size:12px;padding:0 16px;color:rgba(255,255,255,.82);text-align:center}
.vf-overlay-actions{display:flex;gap:8px}
.vf-overlay-actions .vf-btn{color:#fff;background:#fe2c55;border:1px solid #fe2c55;padding:7px 15px}
.vf-overlay-actions .vf-btn:hover{background:#fff;border-color:#fff;color:#111}
.vf-btn{border:0;background:transparent;color:inherit;font-size:12px;font-weight:700;cursor:pointer;padding:4px 8px;border-radius:4px;line-height:1}
.vf-center-control{position:absolute;left:50%;top:50%;z-index:5;width:58px;height:58px;display:grid;place-items:center;padding:0;border:0;border-radius:50%;background:rgba(12,12,12,.54);color:#fff;transform:translate(-50%,-50%);opacity:0;cursor:pointer;backdrop-filter:blur(8px);transition:opacity 150ms ease,transform 150ms ease}
.vf-player:hover .vf-center-control,.vf-center-control:focus-visible,.vf-center-control[data-paused="true"]{opacity:1}
.vf-center-control[data-paused="true"]{width:66px;height:66px;background:rgba(0,0,0,.62);box-shadow:-2px 0 0 rgba(37,244,238,.8),2px 0 0 rgba(254,44,85,.8)}
.vf-center-control:active{transform:translate(-50%,-50%) scale(.94)}
.vf-center-control:focus-visible{outline:2px solid #25f4ee;outline-offset:3px}
.vf-video-meta{position:absolute;left:14px;right:82px;bottom:44px;z-index:4;color:#fff;text-shadow:0 1px 4px rgba(0,0,0,.9);pointer-events:none}
.vf-video-meta strong{font-size:14px;line-height:1.3}
.vf-progress-shell{position:absolute;left:12px;right:12px;bottom:10px;z-index:5;display:grid;grid-template-columns:minmax(0,1fr) auto;align-items:center;gap:9px}
.vf-progress-slider{--vf-progress:0%;width:100%;height:16px;margin:0;appearance:none;background:transparent;cursor:pointer;touch-action:pan-x}
.vf-progress-slider::-webkit-slider-runnable-track{height:3px;border-radius:0;background:linear-gradient(to right,#fff var(--vf-progress),rgba(255,255,255,.28) var(--vf-progress))}
.vf-progress-slider::-webkit-slider-thumb{width:10px;height:10px;margin-top:-3.5px;appearance:none;border:0;border-radius:50%;background:#fff;box-shadow:-1px 0 0 #25f4ee,1px 0 0 #fe2c55}
.vf-progress-slider::-moz-range-track{height:3px;background:rgba(255,255,255,.28)}
.vf-progress-slider::-moz-range-progress{height:3px;background:#fff}
.vf-progress-slider::-moz-range-thumb{width:10px;height:10px;border:0;border-radius:50%;background:#fff}
.vf-progress-slider:disabled{opacity:.34;cursor:default}
.vf-progress-time{min-width:65px;text-align:right;color:rgba(255,255,255,.72);font:600 10px/1 ui-monospace,SFMono-Regular,Consolas,monospace}
.vf-fab-btn{width:42px;height:42px;display:grid;place-items:center;border:1px solid rgba(255,255,255,.18);background:rgba(16,16,16,.62);color:#fff;cursor:pointer;padding:0;border-radius:50%;line-height:1;backdrop-filter:blur(10px);box-shadow:0 4px 16px rgba(0,0,0,.28)}
.vf-fab-btn:hover{border-color:#25f4ee;background:rgba(0,0,0,.78)}
.vf-fab-btn[data-active="true"]{background:#fe2c55;border-color:#fe2c55;color:#fff;box-shadow:-2px 0 0 rgba(37,244,238,.8)}
.vf-fab-btn:focus-visible{outline:2px solid #25f4ee;outline-offset:3px}
.vf-volume-wrap{position:absolute;right:14px;bottom:43px;z-index:5;width:42px;height:42px;display:grid;place-items:center}
.vf-volume-pop{position:absolute;right:0;bottom:50px;display:flex;align-items:center;gap:8px;padding:9px 11px;background:rgba(10,10,10,.88);border:1px solid rgba(255,255,255,.16);border-radius:6px;backdrop-filter:blur(12px);box-shadow:0 8px 20px rgba(0,0,0,.4)}
.vf-volume-slider{width:112px;height:16px;accent-color:#fe2c55;cursor:pointer;touch-action:pan-x}
.vf-volume-value{width:34px;text-align:right;color:#fff;font:700 11px/1 ui-monospace,SFMono-Regular,Consolas,monospace}
.vf-dock{position:fixed;top:0;right:0;bottom:0;width:var(--vf-dock-w,min(100vw,clamp(380px,calc(100vh*9/16),700px)));z-index:1000;display:flex;flex-direction:column;background:#050505;border-left:1px solid #2b2b2b;box-shadow:-14px 0 36px rgba(0,0,0,.2)}
.vf-dock[hidden]{display:none}
.vf-fab{position:fixed;right:0;top:50%;transform:translateY(-50%);z-index:1001;width:34px;height:54px;display:grid;place-items:center;border:1px solid rgba(255,255,255,.14);border-right:0;background:#111;color:#25f4ee;cursor:pointer;padding:0;border-radius:6px 0 0 6px;box-shadow:-6px 0 18px rgba(0,0,0,.18)}
.vf-fab:hover{background:#fe2c55;color:#fff;border-color:#fe2c55}
.vf-fab[data-open="true"]{right:var(--vf-dock-w,min(100vw,clamp(380px,calc(100vh*9/16),700px)));border-right:1px solid rgba(255,255,255,.14);border-radius:6px;background:#111;color:#fe2c55;box-shadow:0 4px 14px rgba(0,0,0,.22)}
@media (max-width:520px){#root{margin-right:0!important}.vf-series-bar{gap:4px;padding:8px 5px 16px}.vf-series-nav{grid-template-columns:26px minmax(0,1fr) 26px;gap:2px}.vf-series-arrow{width:26px;height:30px}.vf-series-track{--vf-series-item-w:82px;--vf-series-item-half:41px;gap:3px}.vf-series-item{height:30px;padding-inline:6px;font-size:11px}.vf-video-meta{left:12px;right:70px;bottom:45px}.vf-volume-wrap{right:12px;bottom:44px}.vf-progress-shell{left:8px;right:8px;bottom:8px;gap:6px}.vf-progress-time{min-width:59px;font-size:9px}.vf-fab[data-open="true"]{left:8px;right:auto;top:78px;bottom:auto;width:36px;height:36px;border:1px solid rgba(255,255,255,.14);border-radius:50%;z-index:1002;transform:none}}
@media (prefers-reduced-motion:reduce){#root,.vf-series-item,.vf-center-control{transition:none}.vf-spinner{animation-duration:1.6s}}
@media (hover:none){.vf-center-control:not([data-paused="true"]){display:none}}
@media (forced-colors:active){.vf-series-item,.vf-series-arrow,.vf-center-control,.vf-fab,.vf-fab-btn{forced-color-adjust:auto}}
`

/* ------------------------------------------------------------------ */
/* Panel component: compact series selector + immersive player.        */
/* ------------------------------------------------------------------ */

function FeedPanel(): React.ReactElement {
  const [prefs, setPrefs] = useState<FeedPrefs>(readPrefs)
  const sources = useMemo(() => allSources(prefs), [prefs])
  const activeIndex = Math.max(0, sources.findIndex(s => s.id === prefs.activeSourceId))
  const active = sources[activeIndex]
  const [centeredIndex, setCenteredIndex] = useState(activeIndex)
  const trackRef = useRef<HTMLDivElement>(null)
  const rootRef = useRef<HTMLDivElement>(null)
  const focusIndexRef = useRef<number | null>(null)
  const settleTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null)
  const programmaticIndexRef = useRef<number | null>(null)

  useEffect(() => { writePrefs(prefs) }, [prefs])

  const scrollToIndex = useCallback((index: number, behavior: ScrollBehavior): void => {
    const track = trackRef.current
    const item = track?.children.item(index) as HTMLElement | null
    if (track === null || item === null || track.clientWidth === 0) return
    const trackRect = track.getBoundingClientRect()
    const itemRect = item.getBoundingClientRect()
    const left = track.scrollLeft
      + itemRect.left + itemRect.width / 2
      - trackRect.left - trackRect.width / 2
    track.scrollTo({ left, behavior })
  }, [])

  const clearSettleTimer = useCallback((): void => {
    if (settleTimerRef.current === null) return
    clearTimeout(settleTimerRef.current)
    settleTimerRef.current = null
  }, [])

  const activateIndex = useCallback((index: number, behavior: ScrollBehavior = 'smooth'): void => {
    const nextIndex = Math.max(0, Math.min(sources.length - 1, index))
    const source = sources[nextIndex]
    if (source === undefined) return
    clearSettleTimer()
    programmaticIndexRef.current = nextIndex
    setCenteredIndex(nextIndex)
    scrollToIndex(nextIndex, behavior)
    setPrefs(current => current.activeSourceId === source.id
      ? current
      : { ...current, activeSourceId: source.id })
    if (focusIndexRef.current === nextIndex) {
      requestAnimationFrame(() => {
        const item = trackRef.current?.children.item(nextIndex) as HTMLElement | null
        item?.focus({ preventScroll: true })
        focusIndexRef.current = null
      })
    }
  }, [clearSettleTimer, scrollToIndex, sources])

  // Center persisted selections after mount and after a hidden dock opens.
  useEffect(() => {
    const track = trackRef.current
    if (track === null) return
    const center = (): void => {
      if (programmaticIndexRef.current !== null) return
      setCenteredIndex(activeIndex)
      scrollToIndex(activeIndex, 'auto')
    }
    center()
    const observer = new ResizeObserver(() => center())
    observer.observe(track)
    return () => observer.disconnect()
  }, [activeIndex, scrollToIndex])

  useEffect(() => () => clearSettleTimer(), [clearSettleTimer])

  const nearestToCenter = useCallback((): number => {
    const track = trackRef.current
    if (track === null) return activeIndex
    const trackRect = track.getBoundingClientRect()
    const center = trackRect.left + trackRect.width / 2
    let nearest = activeIndex
    let nearestDistance = Number.POSITIVE_INFINITY
    Array.from(track.children).forEach((node, index) => {
      const itemRect = (node as HTMLElement).getBoundingClientRect()
      const distance = Math.abs(itemRect.left + itemRect.width / 2 - center)
      if (distance < nearestDistance) {
        nearest = index
        nearestDistance = distance
      }
    })
    return nearest
  }, [activeIndex])

  const handleTrackScroll = useCallback((): void => {
    const nextIndex = nearestToCenter()
    setCenteredIndex(nextIndex)
    clearSettleTimer()
    settleTimerRef.current = setTimeout(() => {
      const programmaticIndex = programmaticIndexRef.current
      if (programmaticIndex !== null) {
        programmaticIndexRef.current = null
        setCenteredIndex(programmaticIndex)
        scrollToIndex(programmaticIndex, 'auto')
        return
      }
      const source = sources[nextIndex]
      if (source !== undefined) {
        setPrefs(current => current.activeSourceId === source.id
          ? current
          : { ...current, activeSourceId: source.id })
      }
    }, 160)
  }, [clearSettleTimer, nearestToCenter, scrollToIndex, sources])

  const beginManualScroll = useCallback((): void => {
    programmaticIndexRef.current = null
    clearSettleTimer()
  }, [clearSettleTimer])

  const handleTrackWheel = useCallback((event: React.WheelEvent<HTMLDivElement>): void => {
    const distance = Math.abs(event.deltaX) > Math.abs(event.deltaY) ? event.deltaX : event.deltaY
    if (distance === 0) return
    event.preventDefault()
    beginManualScroll()
    event.currentTarget.scrollBy({ left: distance, behavior: 'auto' })
  }, [beginManualScroll])

  const handleTrackKey = useCallback((event: React.KeyboardEvent<HTMLDivElement>): void => {
    const focused = (event.target as HTMLElement).closest('.vf-series-item')
    const focusedIndex = focused === null || trackRef.current === null
      ? activeIndex
      : Array.from(trackRef.current.children).indexOf(focused)
    let nextIndex: number | null = null
    if (event.key === 'ArrowLeft') nextIndex = focusedIndex - 1
    else if (event.key === 'ArrowRight') nextIndex = focusedIndex + 1
    else if (event.key === 'Home') nextIndex = 0
    else if (event.key === 'End') nextIndex = sources.length - 1
    if (nextIndex === null) return
    event.preventDefault()
    focusIndexRef.current = Math.max(0, Math.min(sources.length - 1, nextIndex))
    activateIndex(nextIndex)
  }, [activateIndex, activeIndex, sources.length])

  /** Series bar floats above the video; wheel gestures outside the track
   * are forwarded to the player so top-of-video flicks still switch clips. */
  const forwardWheelToPlayer = useCallback((event: React.WheelEvent<HTMLElement>): void => {
    if ((event.target as HTMLElement).closest('.vf-series-track') !== null) return
    const player = rootRef.current?.querySelector('.vf-player')
    if (player === null || player === undefined) return
    player.dispatchEvent(new WheelEvent('wheel', {
      deltaY: event.deltaY,
      deltaX: event.deltaX,
      bubbles: true,
      cancelable: true,
    }))
  }, [])

  return createElement('div', { className: 'vf-root', ref: rootRef },
    createElement('nav', { className: 'vf-series-bar', 'aria-label': '视频系列', onWheel: forwardWheelToPlayer },
      createElement('div', { className: 'vf-series-nav' },
        createElement('button', {
          className: 'vf-series-arrow',
          type: 'button',
          title: '上一个系列',
          'aria-label': '上一个系列',
          disabled: centeredIndex === 0,
          onClick: () => activateIndex(centeredIndex - 1),
        }, createElement(ChevronLeft, { size: 17, strokeWidth: 2.4, 'aria-hidden': true })),
        createElement('div', {
          className: 'vf-series-track',
          ref: trackRef,
          role: 'tablist',
          'aria-label': '系列列表',
          onScroll: handleTrackScroll,
          onWheel: handleTrackWheel,
          onTouchStart: beginManualScroll,
          onKeyDown: handleTrackKey,
        },
          ...sources.map((source, index) => createElement('button', {
            key: source.id,
            className: 'vf-series-item',
            type: 'button',
            role: 'tab',
            title: source.name,
            'aria-selected': source.id === active.id,
            tabIndex: index === activeIndex ? 0 : -1,
            'data-distance': Math.min(Math.abs(index - centeredIndex), 3),
            onClick: () => activateIndex(index),
          }, source.name)),
        ),
        createElement('button', {
          className: 'vf-series-arrow',
          type: 'button',
          title: '下一个系列',
          'aria-label': '下一个系列',
          disabled: centeredIndex === sources.length - 1,
          onClick: () => activateIndex(centeredIndex + 1),
        }, createElement(ChevronRight, { size: 17, strokeWidth: 2.4, 'aria-hidden': true })),
      ),
    ),
    createElement('div', { className: 'vf-stage' },
      active.kind === 'web'
        ? createElement('iframe', { key: active.id, src: active.url, allow: 'autoplay; fullscreen; picture-in-picture' })
        : createElement(MediaPlayer, { key: active.id, source: active }),
    ),
  )
}

/* ------------------------------------------------------------------ */
/* Mounting: sidebar tab (better-sidebar) or fallback dock.            */
/* ------------------------------------------------------------------ */

/** DSH main content mount; compressed while the fallback dock is open. */
const MAIN_ROOT_SELECTOR = '#root'

/** Must stay in sync with the dock width expression in the stylesheet. */
const DOCK_WIDTH_CSS = 'min(100vw, clamp(380px, calc(100vh * 9 / 16), 700px))'

function setMainRootMargin(value: string): void {
  const root = document.querySelector(MAIN_ROOT_SELECTOR) as HTMLElement | null
  if (root !== null) root.style.marginRight = value
}

export function apply(ctx: ClientContext): void {
  ctx.effect(() => {
    const tag = document.createElement('style')
    tag.dataset.plugin = ID
    tag.dataset.pluginCss = STYLE_TAG_ID
    tag.textContent = css
    document.head.appendChild(tag)
    return () => { tag.remove() }
  }, `${ID}: styles`)

  const betterSidebar = ctx.get('betterSidebar') as { registerTab?: (descriptor: unknown) => () => void } | undefined

  if (betterSidebar?.registerTab) {
    ctx.effect(() => betterSidebar.registerTab!({
      id: 'dsh-douyin:feed',
      title: '刷视频',
      icon: (size: number) => createElement(Play, { size, strokeWidth: 2.2, 'aria-hidden': true }),
      single: true,
      component: () => createElement(FeedPanel),
    }), `${ID}: better-sidebar tab`)
    return
  }

  // 经典 dock 模式（无 better-sidebar）：浮动按钮 + 右侧面板；展开时压缩
  // 主会话区（#root margin-right = 面板宽），收起时还原。
  let root: Root | null = null
  let marginBeforeOpen: string | null = null
  const dockHost = document.createElement('div')
  document.body.appendChild(dockHost)

  const render = (open: boolean): void => {
    if (root === null) root = createRoot(dockHost)
    const mainRoot = document.querySelector(MAIN_ROOT_SELECTOR) as HTMLElement | null
    if (open) {
      if (marginBeforeOpen === null && mainRoot !== null) marginBeforeOpen = mainRoot.style.marginRight
      setMainRootMargin(DOCK_WIDTH_CSS)
    } else if (marginBeforeOpen !== null) {
      setMainRootMargin(marginBeforeOpen)
      marginBeforeOpen = null
    }
    root.render(createElement('div', null,
      createElement('button', {
        className: 'vf-fab',
        type: 'button',
        'data-open': open ? true : undefined,
        title: open ? '收起' : '打开刷视频面板',
        'aria-label': open ? '收起刷视频面板' : '打开刷视频面板',
        'aria-expanded': open,
        onClick: () => render(!open),
      }, createElement(open ? PanelRightClose : PanelRightOpen, {
        size: 17,
        strokeWidth: 2.2,
        'aria-hidden': true,
      })),
      open
        ? createElement('div', { className: 'vf-dock' }, createElement(FeedPanel))
        : null,
    ))
  }
  render(false)

  ctx.effect(() => {
    return () => {
      root?.unmount()
      dockHost.remove()
      if (marginBeforeOpen !== null) setMainRootMargin(marginBeforeOpen)
    }
  }, `${ID}: dock lifecycle`)
}
