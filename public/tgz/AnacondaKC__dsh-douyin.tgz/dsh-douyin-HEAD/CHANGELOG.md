# Changelog

## 0.2.0 - 2026-08-13

### Changed

- Migrated the host plugin to the official scoped Cordis `Context` and DSH rc.5 `WebServer` contract.
- Migrated the browser plugin to the official rc.5 `ClientContext` contract.
- Added explicit rc.5 peer dependency ranges and optional host-provided peer metadata.
- Aligned the browser bundle externals with the rc.5 frozen loader module table.

### Verified

- Verified type checking, all 23 tests, client/host builds, and package contents against DSH npm `next` rc.5.
- Verified real DSH Web loading, resolver routing, SSRF rejection, player mount/unmount, accessibility state, and zero horizontal overflow.

### Fixed

- Removed handwritten host and client context interfaces that could silently drift from the DSH runtime.
- Updated bundle metadata comments to the rc.5 `dsh.client` manifest name.

## 0.1.0 - 2026-08-13

- Initial private release with 21 video feeds, native playback, exact URL history, automatic playback, gestures, keyboard controls, resolver hardening, and accessible responsive UI.
