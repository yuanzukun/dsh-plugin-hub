# 兼容性与一次性 Profile 验证（Compatibility & Disposable-Profile Evidence）

> 本文件记录 `dsh-omni-bridge` 对官方 DeepSeek Harness（`@deepseek-ai/dsh`）发行版的
> 逐版本兼容性声明，以及每次声明对应的**一次性 Profile 安装/启动/卸载证据**。
> 本文档与 `package.json` 中 `dsh.compatibility.dshReleases` 保持同一事实来源；
> 仓库任何版本号变化都必须同步更新两处并重新运行下方验证。
>
> 验证日志（非仓库提交物）完整记录了每个发行版的 `dsh --version` 输出、`plugin add` /
> `plugin remove` 退出码与宿主启动 banner，见工作区 `.smoke/verification-log.md`。

## 版本范围

- **DSH 范围**：`>=0.1.0-rc.8 <0.2.0`（见 `package.json` 的 `dsh.compatibility.dsh`）。
  插件只使用 DSH/Cordis 的通用服务（`webServer`、`agents`、`sessionPersistence`、
  `subprocess`、`timer`、`sandboxPolicy`），这些服务在 0.1.0-rc.8 至 0.1.2-rc.1
  的公开发行版中签名保持不变。
- **Node.js 范围**：`>=22.13.0`（与 DSH 官方插件 `build-dsh-plugin` 一致的最低要求）。

## 一次性 Profile 验证方法

每次验证都在**全新的一次性 `DSH_HOME` 与独立 Profile** 中进行：

1. 以目标发行版新建空目录并 `pnpm add @deepseek-ai/dsh@<version>`（本地缓存已就绪时
   不访问第三方网络）；pnpm 首次下载 `@deepseek-ai/dsh` 属于官方 npm Registry 正常读取。
2. `dsh plugin --profile <p> add <repo 路径>` —— 用 pnpm 把本插件安装进该 Profile。
3. `dsh --profile <p> headless "say ok"` —— 启动 DSH 并加载插件；宿主侧
   `apply()` 完整执行（启动日志出现 `[bridge] Omni Bridge v27 Host 就绪`），
   因无模型凭据/无实际聊天消息，agent 无回复属预期，不作为失败。
4. `dsh plugin --profile <p> remove dsh-omni-bridge` —— 从 Profile 卸载并复核
   `--dump-config` 不再包含 `# == dsh-omni-bridge` 层。

| DSH 发行版 | 状态 | install | start（宿主启动日志） | uninstall |
| --- | --- | --- | --- | --- |
| `0.1.0-rc.7` | compatible* | ✅ 一次性 Profile `plugin add` 成功 | ✅ `[bridge] Omni Bridge v27 Host 就绪` | ✅ `plugin remove` 成功 |
| `0.1.0-rc.8` | compatible | ✅ Profile `plugin add` 成功 | ✅ `[bridge] Omni Bridge v27 Host 就绪` | ✅ |
| `0.1.1-rc.1` | compatible | ✅ Profile `plugin add` 成功 | ✅ `[bridge] Omni Bridge v27 Host 就绪` | ✅ |
| `0.1.1-rc.2` | compatible | ✅ Profile `plugin add` 成功 | ✅ `[bridge] Omni Bridge v27 Host 就绪` | ✅ |
| `0.1.2-alpha.2` | compatible | ✅ Profile `plugin add` 成功 | ✅ `[bridge] Omni Bridge v27 Host 就绪` | ✅ |
| `0.1.2-alpha.3` | compatible | ✅ Profile `plugin add` 成功 | ✅ `[bridge] Omni Bridge v27 Host 就绪` | ✅ |
| `0.1.2-alpha.4` | compatible | ✅ Profile `plugin add` 成功 | ✅ `[bridge] Omni Bridge v27 Host 就绪` | ✅ |
| `0.1.2-alpha.5` | compatible | ✅ Profile `plugin add` 成功 | ✅ `[bridge] Omni Bridge v27 Host 就绪` | ✅ |
| `0.1.2-rc.1` | compatible | ✅ Profile `plugin add` 成功 | ✅ `[bridge] Omni Bridge v27 Host 就绪` | ✅ |

`* 0.1.0-rc.7` 是 DSH 商店仍接受的历史别名（旧发布线），与 `rc.8` 之后的版本共用同一批
服务签名，因此一并声明为 compatible；同样完成了一次性 Profile install/start/uninstall。

- **install**: `dsh plugin --profile <p> add <repo>` 退出码 0，Profile 的
  `cordis.patch.yml`/`pnpm-lock.yaml` 正常生成且 `--dump-config` 出现插件层。
- **start**: `dsh --profile <p> headless "say ok"` 打印宿主就绪日志后因“无回复”超时
  退出（退出码 1）属于预期——**插件 `apply()` 与宿主启动已完成**。
- **uninstall**: `dsh plugin --profile <p> remove dsh-omni-bridge` 退出码 0，
  `--dump-config` 中不再出现 `# == dsh-omni-bridge`。
- **rollback**: 每次验证使用全新一次性 Profile，回滚等价于删除该一次性 Profile
  （`dsh` 未在 Profile 外写入任何状态）。

## 环境

- 验证机：Windows，Node.js ≥ 22（`node --version` 记录于验证日志），pnpm ≥ 9。
- 运行日志（本机一次性生成，非仓库提交物）含每个发行版的 `dsh --version` 输出、
  `plugin add`/`remove` 退出码与宿主启动 banner。
- 未执行真实第三方消息收发（需要微信 ClawBot / QQ / 飞书凭据与外部服务），
  因此安装/启动/卸载门为**一次性 Profile 级（partial）证据**，不是完整端到端运行验收。

## 维护约定

修改插件代码后若引入新的 DSH 服务依赖或变更 Node 要求，必须按上述方法在受影响
发行版上重跑验证并更新本表与 `package.json`；仅文档/客户端资源变化不影响本声明。
