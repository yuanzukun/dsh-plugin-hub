/**
 * dsh-task-planner — Task planning with experience muscle-memory for DeepSeek Harness
 *
 * Workflow (Codex-like):
 *  1. Task arrives → task_memory recall: condition-reflex search of the experience
 *     library (sliding-window keyword matching, tolerant of wording differences)
 *  2. plan_task: past experiences + optional capability list → LLM evaluates fit
 *     → dynamic decomposition + capability matching (never hard-coded combos)
 *  3. Deliverable standard: any textual output (docs/sheets/slides/copy) must pass
 *     a de-AI-ification step (humanize then review) before delivery
 *  4. Loop closes → task_memory save (auto-drafted by plan_task, verified by the agent)
 *
 * Tools:
 *  - plan_task    task planning (auto recall + LLM decision + auto draft save)
 *  - task_memory  experience library: save / recall / list
 *
 * Config (cordis.yml row):
 *  - lessonsDir:      experience library directory (default ~/.dsh/planner-lessons)
 *  - capabilityFile:  optional path to a capability/catalog markdown fed to the LLM
 */
import { homedir } from 'node:os'
import { join } from 'node:path'

export const name = 'dsh-task-planner'
export const inject = ['shell', 'llm', 'tools']

export function apply(ctx, config) {
  const cfg = config || {}
  const LESSONS_DIR = cfg.lessonsDir || join(homedir(), '.dsh', 'planner-lessons')
  const CAP_FILE = cfg.capabilityFile || ''

  async function shellOut(cmd, timeoutMs) {
    const spec = ctx.shell.resolve({ command: cmd, timeoutMs: timeoutMs || 60000 })
    const r = await ctx.shell.run(spec)
    return (((r.stdout && r.stdout.text) || '') + ((r.stderr && r.stderr.text) || '')).trim()
  }

  async function defaultModel() {
    const adm = ctx.get('agentDefaultModel')
    if (adm && typeof adm.currentSelection === 'function') {
      const sel = adm.currentSelection()
      if (sel && sel.provider && sel.model) return sel
    }
    return null
  }

  async function generate(system, userText, provider, model, maxTokens) {
    let out = ''
    const chunks = ctx.llm.stream({
      provider: provider,
      model: model,
      system: system,
      messages: [{ role: 'user', content: [{ type: 'text', text: userText }] }],
      maxTokens: maxTokens || 2500,
    })
    for await (const chunk of chunks) {
      if (chunk && chunk.type === 'text-delta' && chunk.text) out += chunk.text
    }
    return out
  }

  // ── experience library ──────────────────────────────────────────
  const STOPWORDS = ['我们', '你们', '他们', '这个', '那个', '这些', '那些', '什么', '怎么', '为什么', '一个', '一种', '进行', '自动', '每天', '电脑', '可以', '需要', '应该', '之后', '之前', '时候', '地方', '东西', '用户', '使用', '相关', '完成', '处理', '通过', '根据', '对于', '由于', '以及', '或者', '不是', '没有', '还有', '已经', '现在', '今天', '明天', '昨天', '主要', '非常', '比较', '可能', '如果', '因为', '所以']

  // Sliding-window 2-3 char tokenization: catches core words even when
  // the phrasing differs (e.g. "weekly report" vs "daily report").
  function extractKeywords(text) {
    const words = text.match(/[a-zA-Z0-9]{2,}/g) || []
    const cn = []
    for (const m of text.matchAll(/[\u4e00-\u9fff]+/g)) {
      const s = m[0]
      for (let i = 0; i < s.length - 1; i++) cn.push(s.slice(i, i + 2))
      for (let i = 0; i < s.length - 2; i++) cn.push(s.slice(i, i + 3))
    }
    const filtered = cn.filter((w) => !STOPWORDS.includes(w))
    return [...new Set([...filtered, ...words])].slice(0, 24)
  }

  async function recallLessons(taskText, limit) {
    await shellOut(`mkdir -p '${LESSONS_DIR}'`, 10000)
    const kws = extractKeywords(taskText)
    if (kws.length === 0) return ''
    const lines = await shellOut(`ls '${LESSONS_DIR}'/*.md 2>/dev/null | grep -v README | head -60`, 10000)
    const files = lines.split('\n').filter(Boolean)
    if (files.length === 0) return ''
    const scored = []
    for (const f of files) {
      const content = await shellOut(`head -c 2500 '${f}'`, 10000)
      let score = 0
      for (const kw of kws) if (content.includes(kw)) score++
      if (score > 0) scored.push({ f, score })
    }
    scored.sort((a, b) => b.score - a.score)
    let out = ''
    for (const s of scored.slice(0, limit || 3)) {
      const body = await shellOut(`head -c 1200 '${s.f}'`, 10000)
      out += `\n--- experience ${s.score}pt: ${s.f.split('/').pop()} ---\n${body}\n`
    }
    return out
  }

  async function saveLesson(task, plan, outcome) {
    await shellOut(`mkdir -p '${LESSONS_DIR}'`, 10000)
    const kws = extractKeywords(task)
    const slug = task.replace(/[^a-zA-Z0-9\u4e00-\u9fff]+/g, '-').slice(0, 40).replace(/^-|-$/g, '') || 'lesson'
    const ts = new Date().toISOString().slice(0, 10)
    const name = `${ts}-${slug}.md`
    const status = (outcome || '').includes('验证') ? 'draft' : 'verified'
    const body = `---\ntags: ${kws.join(', ')}\ndate: ${ts}\nstatus: ${status}\noutcome: ${(outcome || 'pending').slice(0, 100)}\n---\n# ${task.slice(0, 60)}\n\n## Plan\n${(plan || '').slice(0, 2000)}\n\n## Outcome\n${outcome || 'pending: verify on next similar task.'}\n`
    await shellOut(`cat > '${LESSONS_DIR}/${name}' <<'LESSONEOF'\n${body}\nLESSONEOF`, 10000)
    return name
  }

  // ── plan_task ───────────────────────────────────────────────────
  ctx.tools.register({
    name: 'plan_task',
    description: 'Task planning with capability matching: recall similar past experiences (condition reflex), feed them plus the optional capability list to the LLM, let it evaluate fit and produce a dynamic plan (never hard-coded combos). Every textual deliverable step must include a de-AI step (humanize then review). Call before starting complex/cross-domain work.',
    parameters: {
      type: 'object',
      properties: {
        task: { type: 'string', description: 'Task description (goal, inputs, expected outputs)' },
        goal: { type: 'string', description: 'Optional: final objective / acceptance criteria' },
        constraints: { type: 'string', description: 'Optional: constraints (budget/time/platform/compliance)' },
      },
      required: ['task'],
    },
    output: { schema: { type: 'string' }, render(_a, v) { return [{ type: 'text', text: v }] } },
    async execute(args) {
      try {
        const memories = await recallLessons(args.task, 3)
        let cap = ''
        if (CAP_FILE) {
          cap = await shellOut(`cat '${CAP_FILE}' 2>/dev/null | head -c 7000`, 15000)
          if (cap.length >= 7000) cap += '\n…[truncated]'
        }
        const sel = await defaultModel()
        if (!sel) return 'plan_task: cannot resolve default model (agentDefaultModel unavailable)'
        const system = 'You are a task planner. Working principles:\n1. Understand the task, decompose into 3-8 executable steps\n2. **Experience first**: if past similar experiences are provided, evaluate whether they fit (context/dependencies/timeline) — reuse and improve if they do, explicitly explain why not and give a fresh plan if they do not (never force-fit)\n3. Pick the most fitting tool/skill per step from the capability list when available — precise over abundant (MECE)\n4. Identify risks (permissions/network/credentials/external systems) and how to remove them\n5. Output: task understanding / past-experience assessment (if any) / decomposition with capability match / execution steps / risks / suggested next\n6. Be direct; mark uncertain capabilities as "needs exploration".\n7. **Deliverable standard**: any textual output (documents/sheets/slides/copy/scripts/messages) must include a de-AI step — draft, then humanize, then review before delivery; mark such steps explicitly.\n8. Remind at the end: persist the experience after the loop closes (save via task_memory).'
        const user = `【Task】${args.task}\n\n【Goal】${args.goal || 'unspecified'}\n【Constraints】${args.constraints || 'none'}\n\n【Past similar experiences (evaluate fit)】${memories || '（none — new task, persist after completion）'}\n\n【Capability context】${cap || '（not configured）'}`
        const plan = await generate(system, user, sel.provider, sel.model, 8000)
        const result = plan.trim() || '（empty response）'
        try {
          await saveLesson(args.task, result, '待验证-自动沉淀（执行后更新）')
        } catch (e) { /* draft save must not break the main result */ }
        return result + '\n\n---\n✅ Plan auto-drafted to the experience library (status: draft). The agent will update the outcome when the task closes.'
      } catch (error) {
        return 'plan_task ERROR: ' + (error && error.message ? error.message : String(error))
      }
    },
  })

  // ── task_memory ─────────────────────────────────────────────────
  ctx.tools.register({
    name: 'task_memory',
    description: 'Experience muscle-memory library: save persists a task experience (task→plan→outcome) to the lessons dir; recall finds past similar experiences (condition reflex); list shows all experiences.',
    parameters: {
      type: 'object',
      properties: {
        action: { type: 'string', enum: ['save', 'recall', 'list'], description: 'operation' },
        task: { type: 'string', description: 'task description (title + signature keywords when saving)' },
        plan: { type: 'string', description: 'save: plan summary (tools/skills/steps used)' },
        outcome: { type: 'string', description: 'save: outcome assessment (success/failure/lesson)' },
      },
      required: ['action'],
    },
    output: { schema: { type: 'string' }, render(_a, v) { return [{ type: 'text', text: v }] } },
    async execute(args) {
      try {
        if (args.action === 'save') {
          if (!args.task) return 'save requires task'
          return 'saved: ' + (await saveLesson(args.task, args.plan || '', args.outcome || ''))
        }
        if (args.action === 'recall') {
          if (!args.task) return 'recall requires task'
          const hits = await recallLessons(args.task, 5)
          return hits || '（no similar experience — treat as new, remember to save after）'
        }
        if (args.action === 'list') {
          const out = await shellOut(`ls -t '${LESSONS_DIR}'/*.md 2>/dev/null | grep -v README`, 10000)
          return out || '（empty）'
        }
        return 'unknown action'
      } catch (error) {
        return 'task_memory ERROR: ' + (error && error.message ? error.message : String(error))
      }
    },
  })
}
