import * as obsidian from "../../../harness-ui";

const zh = {
  readSave: "保存连接", saveManage: "保存并管理模型", saved: "连接配置已保存", saving: "正在保存…",
  missingKey: "请输入 API Key", duplicateModel: "此模型 ID 已在列表中，请直接启用已有条目。",
  getModels: "获取模型列表", addManual: "手动添加", displayName: "显示名称（可选）", manualEntry: "手动添加", modelAdded: "模型已添加，尚未检测", modelEmpty: "获取模型列表，或手动添加服务商提供的模型 ID。", modelHelp: "列表发现和手动添加可同时使用，只有启用的模型会出现在对话中。",
  pasteKey: "粘贴密钥", keyPasted: "已粘贴", clipboardEmpty: "剪贴板中没有文字，请先复制密钥。", clipboardInvalid: "请仅复制密钥，不要包含说明文字。", clipboardDenied: "无法读取剪贴板。请允许粘贴，或长按输入框粘贴。",
  showKey: "显示密钥", hideKey: "隐藏密钥", manual: "手动指定模型", modelId: "模型 ID",
  modelHint: "填写服务商提供的完整模型 ID", discover: "读取模型并添加", testAdd: "测试模型并添加",
  reading: "正在读取模型…", testing: "正在测试模型…", secretNote: "密钥由 Obsidian 本地保存",
  emptyModels: "没有读取到模型，请手动填写模型 ID 后测试。", missingModel: "请输入模型 ID",
  invalidModel: "模型 ID 不能包含空白且不能超过 200 个字符", noText: "模型没有返回文字，请检查模型 ID 或输出额度。",
  network: "无法连接接口，请检查地址、网络或代理后重试。", timeout: "请求超时，请检查网络或稍后重试。",
  challenge: "服务端要求 Cloudflare 人机验证，请联系服务商为 API 请求开放访问。",
  unauthorized: "密钥无效或已过期，请核对 API Key。", forbidden: "服务端拒绝访问，请检查密钥权限或服务商的访问规则。",
  notFound: "接口或模型不存在，请核对接口地址和完整模型 ID。", rateLimit: "请求受限或额度不足，请检查余额并稍后重试。",
  server: "服务商暂时不可用，请稍后重试。", http: "接口请求失败", invalidResponse: "接口没有返回有效的模型数据，请检查地址或手动指定模型。",
  redirect: "接口返回了跳转，请填写最终 API 地址后重试。", cancelled: "请求已取消",
  loaded: "模型列表已读取", tested: "模型调用成功", manualHelp: "不读取模型列表，直接测试此模型。",
  retryHelp: "可重试，或手动指定模型后测试。", saveTest: "测试模型并保存", responses: "OpenAI Responses",
} as const;
const en: Record<keyof typeof zh, string> = {
  readSave: "Save connection", saveManage: "Save and manage models", saved: "Connection configuration saved", saving: "Saving…",
  missingKey: "Enter an API key", duplicateModel: "This exact model ID already exists. Enable the existing entry instead.",
  getModels: "Get model list", addManual: "Add manually", displayName: "Display name (optional)", manualEntry: "Manually added", modelAdded: "Model added; not tested yet", modelEmpty: "Get the model list or manually add an exact model ID from your provider.", modelHelp: "Discovery and manual models work together. Only enabled models appear in chat.",
  pasteKey: "Paste API key", keyPasted: "Pasted", clipboardEmpty: "Clipboard is empty. Copy your key first.", clipboardInvalid: "Copy only the key, without explanatory text.", clipboardDenied: "Cannot read clipboard. Allow paste access, or touch and hold the input to paste.",
  showKey: "Show API key", hideKey: "Hide API key", manual: "Specify a model manually", modelId: "Model ID",
  modelHint: "Enter the exact model ID from your provider", discover: "Load models and add", testAdd: "Test model and add",
  reading: "Loading models…", testing: "Testing model…", secretNote: "Key stored locally by Obsidian",
  emptyModels: "No models found. Enter a model ID and test it manually.", missingModel: "Enter a model ID",
  invalidModel: "Model IDs must contain no whitespace and be at most 200 characters", noText: "The model returned no text. Check the model ID or output allowance.",
  network: "Cannot connect. Check the API URL, network or proxy and retry.", timeout: "Request timed out. Check the network or try again later.",
  challenge: "The server requires a Cloudflare challenge. Ask the provider to allow API access.",
  unauthorized: "Invalid or expired API key. Check your key.", forbidden: "Access denied. Check key permissions or the provider's access rules.",
  notFound: "Endpoint or model not found. Check the API URL and exact model ID.", rateLimit: "Rate limit or quota exceeded. Check your balance and retry later.",
  server: "Provider unavailable. Try again later.", http: "API request failed", invalidResponse: "The API did not return valid model data. Check the URL or specify a model manually.",
  redirect: "The API redirected the request. Enter the final API URL and retry.", cancelled: "Request cancelled",
  loaded: "Model list loaded", tested: "Model call succeeded", manualHelp: "Test this model directly without loading the model list.",
  retryHelp: "Retry, or specify and test a model manually.", saveTest: "Test model and save", responses: "OpenAI Responses",
};
export function connectionText(key: keyof typeof zh): string {
  const lang = typeof obsidian.getLanguage === "function" ? obsidian.getLanguage() : "zh";
  return (lang.startsWith("en") ? en : zh)[key];
}
