import { describe, expect, it } from 'vitest'
import {
  countsAverage,
  historyFromResults,
  isVoteResults,
  isVoteStatus,
  scoreFromAverage,
  shanghaiDate,
  tierNameFromAverage
} from '../src/model.ts'

describe('vote model', () => {
  it('uses the Shanghai calendar day', () => {
    expect(shanghaiDate(new Date('2026-08-15T16:01:00Z'))).toBe('2026-08-16')
  })

  it('converts five-tier counts into score and label', () => {
    const average = countsAverage([0, 0, 3, 1, 0])
    expect(average).toBe(2.25)
    expect(scoreFromAverage(average)).toBe(43.75)
    expect(tierNameFromAverage(average)).toBe('梁子')
  })

  it('validates status and result payloads', () => {
    expect(isVoteStatus({ today: '2026-08-16', voted: true, tier: 2 })).toBe(true)
    expect(isVoteStatus({ today: '2026-08-16', voted: true, tier: 9 })).toBe(false)
    expect(isVoteResults({ version: 1, today: '2026-08-16', days: { '2026-08-16': [1, 2, 3, 4, 5] } })).toBe(true)
  })

  it('sorts and limits history', () => {
    const history = historyFromResults({
      version: 1,
      today: '2026-08-16',
      days: {
        '2026-08-16': [1, 0, 0, 0, 0],
        '2026-08-14': [0, 0, 1, 0, 0],
        '2026-08-15': [0, 1, 0, 0, 0]
      }
    }, 2)
    expect(history.map(day => day.date)).toEqual(['2026-08-15', '2026-08-16'])
  })
})

