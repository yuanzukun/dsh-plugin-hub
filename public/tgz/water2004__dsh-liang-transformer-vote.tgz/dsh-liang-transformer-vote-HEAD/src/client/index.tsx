import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import type { CSSProperties } from 'react'
import { createPortal } from 'react-dom'
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client'
import type {} from '@deepseek-ai/dsh-client-ui-conversation/client'
import {
  TIERS,
  historyFromResults,
  isVoteResults,
  isVoteStatus,
  shanghaiDate,
  summarizeDay,
  tierNameFromAverage,
  type VoteResults,
  type VoteStatus
} from '../model.ts'

export const name = 'dsh-liang-transformer-vote'
export const inject = ['slots']

const API_BASE = 'https://liang.gbwater.icu'
const POLL_MS = 30_000

type PageKey = 'today' | 'distribution' | 'history'

const CSS = `
.lvt-root{position:relative;display:inline-flex;align-items:center}.lvt-trigger{height:28px;border:0;border-radius:24px;padding:0 8px;background:transparent;color:var(--dsw-alias-label-secondary,#61666b);display:inline-flex;align-items:center;gap:5px;font:inherit;font-size:13px;cursor:pointer;white-space:nowrap}.lvt-trigger:hover,.lvt-trigger[data-open=true]{background:var(--dsw-alias-interactive-bg-hover,rgba(38,49,72,.06));color:var(--dsw-alias-label-primary,#0f1115)}.lvt-trigger-score{color:var(--dsw-alias-label-tertiary,#81858c);font-variant-numeric:tabular-nums}.lvt-trigger[data-open=true] .lvt-trigger-score{color:inherit}
.lvt-pop{position:fixed;z-index:2147482000;width:min(310px,calc(100vw - 20px));display:flex;flex-direction:column;overflow:hidden;border:1px solid var(--dsw-alias-border-l2,rgba(0,0,0,.1));border-radius:12px;background:var(--dsw-alias-bg-layer-2,#fff);color:var(--dsw-alias-label-primary,#0f1115);box-shadow:0 8px 24px rgba(0,0,0,.14);font-family:Inter,"PingFang SC","Microsoft YaHei",sans-serif}.lvt-head{flex:0 0 auto;display:flex;align-items:center;justify-content:space-between;padding:8px 9px 6px 11px}.lvt-title strong{display:block;font-size:12px;font-weight:650}.lvt-close{width:24px;height:24px;border:0;border-radius:50%;background:transparent;color:var(--dsw-alias-label-tertiary,#81858c);font-size:16px;cursor:pointer}.lvt-close:hover{background:var(--dsw-alias-interactive-bg-hover,rgba(38,49,72,.06));color:var(--dsw-alias-label-primary,#0f1115)}
.lvt-tabs{flex:0 0 auto;display:grid;grid-template-columns:repeat(3,1fr);gap:2px;margin:0 10px;padding:2px;border-radius:8px;background:var(--dsw-alias-bg-module-platform,#f5f6f7)}.lvt-tab{height:25px;border:0;border-radius:6px;background:transparent;color:var(--dsw-alias-label-tertiary,#81858c);font-size:10px;cursor:pointer}.lvt-tab:hover{color:var(--dsw-alias-label-primary,#0f1115)}.lvt-tab.active{background:var(--dsw-alias-bg-layer-1,#fff);color:var(--dsw-alias-label-primary,#0f1115);box-shadow:0 1px 3px rgba(0,0,0,.07);font-weight:650}
.lvt-body{min-height:0;flex:1 1 auto;overflow:auto;padding:8px 10px}.lvt-page{min-height:100%}.lvt-error{margin-bottom:6px;padding:6px 7px;border-radius:7px;background:rgba(220,38,38,.08);color:#b4232c;font-size:10px}.lvt-link{border:0;background:transparent;color:var(--dsw-alias-button-info-fill,#4176e6);font:inherit;text-decoration:underline;cursor:pointer}.lvt-loading,.lvt-empty{display:grid;place-items:center;height:100%;color:var(--dsw-alias-label-tertiary,#81858c);font-size:11px}
.lvt-vote{box-sizing:border-box;height:100%;display:flex;flex-direction:column;padding:9px 10px;border:1px solid var(--dsw-alias-border-l2,rgba(0,0,0,.1));border-radius:9px;background:var(--dsw-alias-bg-layer-1,#fff)}.lvt-choice{display:flex;align-items:end;justify-content:space-between;margin:0 0 6px}.lvt-choice strong{font-size:20px}.lvt-choice b{font-size:24px;line-height:1;color:var(--dsw-alias-label-primary-bluish,#0e3074);font-variant-numeric:tabular-nums}.lvt-range{width:100%;margin:1px 0;accent-color:var(--dsw-alias-button-info-fill,#4176e6)}.lvt-scale{display:flex;justify-content:space-between}.lvt-scale button{border:0;background:transparent;color:var(--dsw-alias-label-caption,#adb2b8);cursor:pointer;font-size:9px;padding:3px 1px}.lvt-scale button.active{color:var(--dsw-alias-label-primary,#0f1115);font-weight:650}.lvt-primary{width:100%;margin-top:7px;border:0;border-radius:8px;padding:8px 10px;background:var(--dsw-alias-button-primary-fill,#0f1115);color:var(--dsw-alias-label-primary-foreground,#fff);font-size:11px;font-weight:650;cursor:pointer}.lvt-primary:disabled{opacity:.45;cursor:wait}
.lvt-own{display:grid;grid-template-columns:auto 1fr auto;gap:9px;align-items:center;padding:11px;border-radius:9px;background:var(--dsw-alias-bg-module-platform,#f5f6f7)}.lvt-own small,.lvt-stat small{color:var(--dsw-alias-label-tertiary,#81858c);font-size:9px}.lvt-own strong{font-size:18px}.lvt-own b{font-size:21px;color:var(--dsw-alias-label-primary-bluish,#0e3074);font-variant-numeric:tabular-nums}.lvt-today-stats{display:grid;grid-template-columns:1fr 1fr;gap:7px;margin-top:7px}.lvt-stat{padding:9px;border:1px solid var(--dsw-alias-border-l2,rgba(0,0,0,.1));border-radius:9px;background:var(--dsw-alias-bg-layer-1,#fff)}.lvt-stat strong{display:block;margin-top:3px;font-size:17px;font-variant-numeric:tabular-nums}.lvt-stat span{display:block;margin-top:2px;color:var(--dsw-alias-label-tertiary,#81858c);font-size:9px}
.lvt-section-head{display:flex;justify-content:space-between;align-items:center;margin:1px 1px 9px}.lvt-section-head h4{margin:0;font-size:12px}.lvt-section-head small{color:var(--dsw-alias-label-tertiary,#81858c);font-size:9px}.lvt-row{display:grid;grid-template-columns:36px 1fr 40px;gap:7px;align-items:center;margin:9px 1px;font-size:9px}.lvt-bar{height:6px;border-radius:99px;background:var(--dsw-alias-bg-overlay,#e9ecf2);overflow:hidden}.lvt-bar i{display:block;height:100%;border-radius:inherit;background:var(--dsw-alias-button-info-fill,#4176e6)}.lvt-row b{text-align:right;font-variant-numeric:tabular-nums}.lvt-chart-wrap{padding:7px 5px 2px;border:1px solid var(--dsw-alias-border-l2,rgba(0,0,0,.1));border-radius:10px;background:var(--dsw-alias-bg-layer-1,#fff)}.lvt-chart{display:block;width:100%;height:auto}.lvt-gridline{stroke:var(--dsw-alias-border-l2,rgba(0,0,0,.1));stroke-width:1}.lvt-line{fill:none;stroke:var(--dsw-alias-button-info-fill,#4176e6);stroke-width:2.3;stroke-linecap:round;stroke-linejoin:round}.lvt-area{fill:url(#lvt-mini-area)}.lvt-chart text{fill:var(--dsw-alias-label-tertiary,#81858c);font-size:8px}.lvt-chart circle{fill:var(--dsw-alias-bg-layer-1,#fff);stroke:var(--dsw-alias-button-info-fill,#4176e6);stroke-width:1.5}
.lvt-foot{flex:0 0 auto;display:flex;align-items:center;justify-content:flex-end;padding:5px 9px;border-top:1px solid var(--dsw-alias-border-l1,rgba(0,0,0,.04));font-size:9px}.lvt-foot a{color:var(--dsw-alias-label-secondary,#61666b)}.lvt-refresh{border:0;border-radius:7px;padding:4px 6px;background:transparent;color:var(--dsw-alias-label-secondary,#61666b);font-size:9px;cursor:pointer}.lvt-refresh:hover{background:var(--dsw-alias-interactive-bg-hover,rgba(38,49,72,.06))}
@media(max-width:520px){.lvt-pop{left:10px!important;right:10px;width:auto;top:10px!important;height:calc(100vh - 20px)!important;max-height:none!important}}
`

function errorText(error: unknown): string {
  return error instanceof Error && error.message ? error.message : String(error)
}

function Widget(): React.ReactElement {
  const triggerRef = useRef<HTMLButtonElement>(null)
  const panelRef = useRef<HTMLElement>(null)
  const [open, setOpen] = useState(false)
  const [page, setPage] = useState<PageKey>('today')
  const [panelStyle, setPanelStyle] = useState<CSSProperties>({ left: 10, top: 10 })
  const [status, setStatus] = useState<VoteStatus | null>(null)
  const [result, setResult] = useState<VoteResults | null>(null)
  const [selected, setSelected] = useState(2)
  const [loading, setLoading] = useState(true)
  const [submitting, setSubmitting] = useState(false)
  const [error, setError] = useState('')
  const targetHeight = status?.voted ? 270 : 210

  const placePanel = useCallback((): void => {
    const rect = triggerRef.current?.getBoundingClientRect()
    const width = Math.min(310, window.innerWidth - 20)
    const height = Math.min(targetHeight, window.innerHeight - 20)
    const left = Math.max(10, Math.min(rect?.left ?? 10, window.innerWidth - width - 10))
    const above = (rect?.top ?? window.innerHeight) - height - 8
    const below = (rect?.bottom ?? 0) + 8
    const top = above >= 10 ? above : Math.max(10, Math.min(below, window.innerHeight - height - 10))
    setPanelStyle({ left, top, maxHeight: height })
  }, [targetHeight])

  const loadResults = useCallback(async (): Promise<void> => {
    const response = await fetch(`${API_BASE}/results.json`, { mode: 'cors', cache: 'no-store' })
    if (!response.ok) throw new Error(response.status === 404 ? '结果尚未生成' : `结果读取失败（${response.status}）`)
    const payload: unknown = await response.json()
    if (!isVoteResults(payload)) throw new Error('结果数据格式无效')
    setResult(payload)
  }, [])

  const syncStatus = useCallback(async (): Promise<void> => {
    setLoading(true)
    setError('')
    try {
      const response = await fetch(`${API_BASE}/api/status`, { mode: 'cors', credentials: 'include', cache: 'no-store' })
      if (!response.ok) throw new Error(`状态同步失败（${response.status}）`)
      const payload: unknown = await response.json()
      if (!isVoteStatus(payload)) throw new Error('状态数据格式无效')
      const normalized: VoteStatus = { ...payload, tier: payload.voted ? Number(payload.tier) : null }
      setStatus(normalized)
      if (normalized.voted && normalized.tier !== null) {
        setSelected(normalized.tier)
        await loadResults()
      } else {
        setResult(null)
        setPage('today')
      }
    } catch (cause) {
      setError(errorText(cause))
    } finally {
      setLoading(false)
    }
  }, [loadResults])

  useEffect(() => { void syncStatus() }, [syncStatus])

  useEffect(() => {
    if (!status?.voted) return
    const timer = window.setInterval(() => {
      if (status.today !== shanghaiDate()) void syncStatus()
      else void loadResults().catch(cause => setError(errorText(cause)))
    }, POLL_MS)
    return () => window.clearInterval(timer)
  }, [loadResults, status?.today, status?.voted, syncStatus])

  useEffect(() => {
    if (!open) return
    placePanel()
    const onPointerDown = (event: PointerEvent): void => {
      const target = event.target as Node
      if (!triggerRef.current?.contains(target) && !panelRef.current?.contains(target)) setOpen(false)
    }
    window.addEventListener('resize', placePanel)
    document.addEventListener('pointerdown', onPointerDown)
    return () => {
      window.removeEventListener('resize', placePanel)
      document.removeEventListener('pointerdown', onPointerDown)
    }
  }, [open, placePanel])

  const todayCounts = result?.days[status?.today ?? result?.today ?? ''] ?? [0, 0, 0, 0, 0]
  const today = useMemo(() => summarizeDay(status?.today ?? result?.today ?? '', todayCounts), [result, status?.today])
  const history = useMemo(() => historyFromResults(result), [result])
  const total = today?.total ?? 0
  const ownTier = status?.voted && status.tier !== null ? TIERS[status.tier] : null

  const chart = useMemo(() => {
    const width = 286, height = 138, left = 23, top = 8, bottom = 18
    const usableW = width - left - 7, usableH = height - top - bottom
    const points = history.map((day, index) => ({
      ...day,
      x: left + (history.length < 2 ? usableW / 2 : index / (history.length - 1) * usableW),
      y: top + (100 - day.score) / 100 * usableH
    }))
    const line = points.map((point, index) => `${index ? 'L' : 'M'} ${point.x.toFixed(1)} ${point.y.toFixed(1)}`).join(' ')
    const floor = height - bottom
    const area = points.length > 1 ? `${line} L ${points.at(-1)?.x.toFixed(1)} ${floor} L ${points[0]?.x.toFixed(1)} ${floor} Z` : ''
    return { width, height, left, top, usableH, points, line, area }
  }, [history])

  async function submitVote(): Promise<void> {
    if (submitting || status?.voted) return
    setSubmitting(true)
    setError('')
    try {
      const response = await fetch(`${API_BASE}/api/vote`, {
        method: 'POST',
        mode: 'cors',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ tier: selected })
      })
      if (!response.ok) throw new Error((await response.text()) || `投票失败（${response.status}）`)
      setStatus({ today: shanghaiDate(), voted: true, tier: selected })
      setPage('today')
      await loadResults()
    } catch (cause) {
      setError(errorText(cause))
    } finally {
      setSubmitting(false)
    }
  }

  const triggerText = status?.voted && today ? tierNameFromAverage(today.average) : loading ? '同步中' : error ? '未连接' : '未投票'
  const triggerScore = status?.voted && today ? today.score.toFixed(1) : ''

  const votedPage = page === 'today' ? (
    <div className="lvt-page">
      <div className="lvt-own"><small>我的</small><strong>{ownTier?.name ?? '—'}</strong><b>{ownTier?.score ?? '—'}</b></div>
      <div className="lvt-today-stats">
        <article className="lvt-stat"><small>今日评分</small><strong>{today ? today.score.toFixed(1) : '—'}</strong><span>{tierNameFromAverage(today?.average ?? null)}</span></article>
        <article className="lvt-stat"><small>票数</small><strong>{total}</strong></article>
      </div>
    </div>
  ) : page === 'distribution' ? (
    <div className="lvt-page">
      <div className="lvt-section-head"><h4>分布</h4><small>{total} 票</small></div>
      {TIERS.map((tier, index) => {
        const count = todayCounts[index] ?? 0
        const percent = total ? count / total * 100 : 0
        return <div className="lvt-row" key={tier.name}><span>{tier.name}</span><div className="lvt-bar"><i style={{ width: `${percent}%` }} /></div><b>{percent.toFixed(0)}%</b></div>
      })}
    </div>
  ) : (
    <div className="lvt-page">
      <div className="lvt-section-head"><h4>最近 30 天</h4></div>
      {chart.points.length ? <div className="lvt-chart-wrap"><svg className="lvt-chart" viewBox={`0 0 ${chart.width} ${chart.height}`} role="img" aria-label="最近三十天每日评分曲线">
        <defs><linearGradient id="lvt-mini-area" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="var(--dsw-alias-button-info-fill, #4176e6)" stopOpacity=".2" /><stop offset="1" stopColor="var(--dsw-alias-button-info-fill, #4176e6)" stopOpacity="0" /></linearGradient></defs>
        {[0, 50, 100].map(score => { const y = chart.top + (100 - score) / 100 * chart.usableH; return <g key={score}><line className="lvt-gridline" x1={chart.left} x2={chart.width - 7} y1={y} y2={y} /><text x="1" y={y + 3}>{score}</text></g> })}
        {chart.area && <path className="lvt-area" d={chart.area} />}
        <path className="lvt-line" d={chart.line} />
        {chart.points.map(point => <circle key={point.date} cx={point.x} cy={point.y} r={point.date === status?.today ? 3.5 : 2.2}><title>{point.date} · {point.score.toFixed(1)} 分</title></circle>)}
      </svg></div> : <div className="lvt-empty">暂无数据</div>}
    </div>
  )

  const panel = open ? createPortal(
    <section ref={panelRef} className="lvt-pop" style={{ ...panelStyle, height: targetHeight }} role="dialog" aria-label="滑动变祖器控件">
      <header className="lvt-head"><div className="lvt-title"><strong>滑动变祖器</strong></div><button className="lvt-close" type="button" aria-label="关闭" onClick={() => setOpen(false)}>×</button></header>
      {status?.voted ? <nav className="lvt-tabs" aria-label="梁值视图"><button className={`lvt-tab${page === 'today' ? ' active' : ''}`} type="button" onClick={() => setPage('today')}>今日</button><button className={`lvt-tab${page === 'distribution' ? ' active' : ''}`} type="button" onClick={() => setPage('distribution')}>分布</button><button className={`lvt-tab${page === 'history' ? ' active' : ''}`} type="button" onClick={() => setPage('history')}>历史</button></nav> : null}
      <div className="lvt-body">
        {error && <div className="lvt-error">{error} <button className="lvt-link" type="button" onClick={() => void syncStatus()}>重试</button></div>}
        {loading && status === null ? <div className="lvt-loading">正在同步投票状态…</div> : null}
        {!loading && !status?.voted ? <div className="lvt-vote"><div className="lvt-choice"><strong>{TIERS[selected]?.name}</strong><b>{TIERS[selected]?.score}</b></div><input className="lvt-range" type="range" min="0" max="4" step="1" value={selected} onChange={event => setSelected(Number(event.target.value))} aria-label="选择今日梁值挡位" /><div className="lvt-scale">{TIERS.map((tier, index) => <button type="button" key={tier.name} className={selected === index ? 'active' : ''} onClick={() => setSelected(index)}>{tier.name}</button>)}</div><button className="lvt-primary" type="button" disabled={submitting} onClick={() => void submitVote()}>{submitting ? '投票中…' : '投票'}</button></div> : null}
        {status?.voted ? votedPage : null}
      </div>
      <footer className="lvt-foot"><button className="lvt-refresh" type="button" onClick={() => void syncStatus()}>刷新</button>　<a href={API_BASE} target="_blank" rel="noreferrer">原网页</a></footer>
    </section>, document.body
  ) : null

  return <span className="lvt-root"><style>{CSS}</style><button ref={triggerRef} className="lvt-trigger" data-open={open} type="button" aria-label={`滑动变祖器，${triggerText}${triggerScore ? ` ${triggerScore}` : ''}`} onClick={() => { setOpen(value => !value); if (!open) void syncStatus() }}><span>{triggerText}</span>{triggerScore ? <span className="lvt-trigger-score">{triggerScore}</span> : null}</button>{panel}</span>
}

export function apply(ctx: ClientContext): void {
  ctx.slots.inject('conversation.input.left', () => ctx.slots.register(
    { name: 'conversation.input.left', id: 'liang-transformer-vote', order: 60, label: '滑动变祖器' },
    () => <Widget />
  ))
}
