export const TIERS = [
  { name: '梁神', score: 100, color: '#4d6bfe' },
  { name: '梁圣', score: 75, color: '#6f84ff' },
  { name: '梁子', score: 50, color: '#7889c7' },
  { name: '牢梁', score: 25, color: '#53627d' },
  { name: '梁÷', score: 0, color: '#343d52' }
] as const

export interface VoteStatus {
  today: string
  voted: boolean
  tier: number | null
}

export interface VoteResults {
  version: number
  today: string
  days: Record<string, number[]>
}

export interface DaySummary {
  date: string
  counts: number[]
  total: number
  average: number
  score: number
}

export function shanghaiDate(value = new Date()): string {
  const parts = new Intl.DateTimeFormat('zh-CN', {
    timeZone: 'Asia/Shanghai',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit'
  }).formatToParts(value)
  const read = (type: string): string => parts.find(part => part.type === type)?.value ?? ''
  return `${read('year')}-${read('month')}-${read('day')}`
}

export function countsAverage(counts: readonly number[]): number | null {
  const total = counts.reduce((sum, count) => sum + count, 0)
  if (!total) return null
  return counts.reduce((sum, count, index) => sum + count * index, 0) / total
}

export function scoreFromAverage(average: number | null): number | null {
  return average === null ? null : Math.max(0, Math.min(100, 100 - average * 25))
}

export function tierNameFromAverage(average: number | null): string {
  if (average === null) return '等待样本'
  return TIERS[Math.max(0, Math.min(4, Math.round(average)))]?.name ?? '等待样本'
}

export function isVoteStatus(value: unknown): value is VoteStatus {
  if (!value || typeof value !== 'object') return false
  const status = value as Partial<VoteStatus>
  if (typeof status.today !== 'string' || typeof status.voted !== 'boolean') return false
  if (!status.voted) return status.tier === null || status.tier === undefined
  return Number.isInteger(status.tier) && Number(status.tier) >= 0 && Number(status.tier) < TIERS.length
}

export function isVoteResults(value: unknown): value is VoteResults {
  if (!value || typeof value !== 'object') return false
  const result = value as Partial<VoteResults>
  if (result.version !== 1 || typeof result.today !== 'string' || !result.days || typeof result.days !== 'object') return false
  return Object.values(result.days).every(counts => Array.isArray(counts) && counts.length === TIERS.length && counts.every(count => Number.isFinite(count) && count >= 0))
}

export function summarizeDay(date: string, counts: readonly number[]): DaySummary | null {
  const average = countsAverage(counts)
  const score = scoreFromAverage(average)
  if (average === null || score === null) return null
  return {
    date,
    counts: [...counts],
    total: counts.reduce((sum, count) => sum + count, 0),
    average,
    score
  }
}

export function historyFromResults(result: VoteResults | null, limit = 30): DaySummary[] {
  if (!result) return []
  return Object.entries(result.days)
    .map(([date, counts]) => summarizeDay(date, counts))
    .filter((day): day is DaySummary => day !== null)
    .sort((a, b) => a.date.localeCompare(b.date))
    .slice(-limit)
}

