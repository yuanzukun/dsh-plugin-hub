import type { Context } from '@deepseek-ai/cordis'

export const name = 'dsh-liang-transformer-vote'

// The browser half talks directly to liang.gbwater.icu so its credentialed
// requests carry the same anonymous vote Cookie as the original website.
export function apply(_ctx: Context): void {}

