# 滑动变祖器 · DeepSeek Harness 插件

为 [DeepSeek Harness](https://github.com/deepseek-ai/deepseek-harness) Web UI 接入 [water2004/liang-transformer-vote](https://github.com/water2004/liang-transformer-vote)。插件在会话输入框底栏提供梁值小控件，可完成每日投票，并在投票后分页查看今日评分、梁值分布和最近 30 天迷你曲线。

![滑动变祖器在 DeepSeek Harness 中的效果](docs/screenshot.png)

## 功能

- 与 `https://liang.gbwater.icu` 原网页同步今日投票状态。
- 未投票时仅显示「今日未投票」，不会请求结果文件。
- 五个固定挡位：梁神 100、梁圣 75、梁子 50、牢梁 25、梁÷ 0。
- 投票后解锁今日评分、分布和最近 30 天曲线。
- 每 30 秒从 CDN 刷新结果；投票状态接口只在启动、打开面板或跨日时访问。

## 前置条件

源站需要部署配套版本：

- `GET /api/status` 回显普通 Cookie 中的今日日期和挡位；
- `POST /api/vote` 支持 credentialed CORS 并写入 Cookie；
- `GET /results.json` 允许公开 CORS。

DSH 默认运行在 `http://127.0.0.1:3080`。浏览器需要允许源站 Cookie，才能与原网页同步今日状态。

## 安装

DSH 的插件管理命令会调用 `pnpm`。Windows 上如果 `pnpm --version` 不可用，请先按 pnpm 官方方式安装，并重新打开终端：

```powershell
npx get-pnpm
```

从 GitHub 安装到 DSH 的 `web` profile：

```sh
npx @deepseek-ai/dsh plugin --profile web add github:water2004/dsh-liang-transformer-vote
npx @deepseek-ai/dsh web
```

如果已经全局安装 `dsh` CLI，可以省略命令开头的 `npx @deepseek-ai/dsh`，直接使用 `dsh`。

本地开发安装：

```sh
pnpm install
pnpm check
npx @deepseek-ai/dsh plugin --profile web add .
npx @deepseek-ai/dsh web
```

安装或更新后重启 `dsh web`，刷新浏览器即可在输入框底栏看到「梁值」控件。

## 开发

```sh
pnpm install
pnpm typecheck
pnpm test
pnpm build
```

插件是标准 DSH profile bundle：`cordis.patch.yml` 挂载 Host 空壳，`exports["./client"]` 提供 Web Client Slot 实现。浏览器端注册 `conversation.input.left`，通过源站接口同步今日状态和结果。

## 许可

[MIT](LICENSE)
