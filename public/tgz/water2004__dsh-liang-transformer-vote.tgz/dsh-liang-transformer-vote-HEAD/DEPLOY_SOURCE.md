# liang.gbwater.icu 配套部署

插件直接从 DSH 页面跨域访问 `https://liang.gbwater.icu`。源站需要同时部署本项目准备好的 Go、Vue 与 Nginx 改动。

## 源站行为

- `POST /api/vote`：累计五档总票数，并写入普通 Cookie `liang-daily-vote=YYYY-MM-DD:tier`。
- `GET /api/status`：读取并返回浏览器保存的今日投票状态。
- `/api/vote` 和 `/api/status`：回显请求的 `Origin`，并返回 `Access-Control-Allow-Credentials: true`。
- `GET /results.json`：继续作为公开静态文件，返回 `Access-Control-Allow-Origin: *`。
- 原网页从旧 `localStorage` 自动迁移一次 Cookie，因此已经投过票的浏览器无需重新投票。

## Nginx

在 `liang.gbwater.icu` 的 HTTPS `server` 块里保留原 `/api/vote` 反代，并加入：

```nginx
location = /api/status {
    proxy_pass http://127.0.0.1:18080/status;
    proxy_http_version 1.1;
    proxy_set_header Host $host;
    proxy_set_header X-Forwarded-Proto $scheme;
    proxy_read_timeout 10s;
}

location = /results.json {
    add_header Access-Control-Allow-Origin "*" always;
    add_header Cache-Control "public, max-age=10, stale-while-revalidate=60" always;
    default_type application/json;
    try_files /results.json =404;
}
```

不要在 Nginx 给 `/api/vote` 或 `/api/status` 再加 `Access-Control-Allow-Origin: *`；带 Cookie 的 CORS 不能使用星号，Go 服务会回显真实 Origin。

## 更新容器

源项目推送到 `main`、GitHub Actions 的 `Build container` 成功后，在服务器执行：

```bash
cd /path/to/liang-transformer-vote
docker compose pull
docker compose up -d --force-recreate liang-vote
sudo nginx -t
sudo systemctl reload nginx
```

如果服务器直接从源码构建：

```bash
cd /path/to/liang-transformer-vote
git pull --ff-only
docker compose build --pull liang-vote
docker compose up -d --force-recreate liang-vote
sudo nginx -t
sudo systemctl reload nginx
```

挂载目录里的 `results.json` 会保留；新容器只更新前端静态文件和 Go 程序。

## 验证

```bash
origin='http://127.0.0.1:3080'

curl -i -X OPTIONS 'https://liang.gbwater.icu/api/status' \
  -H "Origin: $origin" \
  -H 'Access-Control-Request-Method: GET'

curl -i 'https://liang.gbwater.icu/api/status' \
  -H "Origin: $origin"

curl -I 'https://liang.gbwater.icu/results.json' \
  -H "Origin: $origin"
```

应看到：

- 状态接口返回 `Access-Control-Allow-Origin: http://127.0.0.1:3080`；
- 状态接口返回 `Access-Control-Allow-Credentials: true`；
- 未带 Cookie 时 JSON 为 `{"today":"...","voted":false,"tier":null}`；
- `results.json` 返回 `Access-Control-Allow-Origin: *`。

最后刷新 DSH。若浏览器屏蔽第三方 Cookie，需要允许 `liang.gbwater.icu` 在 `127.0.0.1` 页面使用跨站 Cookie，否则 CORS 正确也无法共享投票状态。
