#!/usr/bin/env node
// dsh-plugin-8r 判定器验证：86 条黄金用例（纯 node 可跑，无第三方依赖）
// 用法: npm test  或  node test/verify.js
'use strict';
const fs = require('fs');
const path = require('path');
const { judge } = require('./judge.cjs');

const cases = JSON.parse(
  fs.readFileSync(path.join(__dirname, 'data', '8r_strict_cases.json'), 'utf8')
).cases;

let bad = [];
for (const c of cases) {
  const r = judge(c.text);
  if (r.should_e !== c.expected) bad.push([c.text, r.should_e, c.expected]);
}
console.log(`黄金测试: ${cases.length - bad.length}/${cases.length} 通过`);
for (const b of bad) console.log('    FAIL:', JSON.stringify(b));
process.exit(bad.length === 0 ? 0 : 1);
