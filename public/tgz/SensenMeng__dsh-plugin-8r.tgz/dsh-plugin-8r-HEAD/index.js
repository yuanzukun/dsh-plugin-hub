// dsh-plugin-8r —— 8R 前缀注入插件（DSH Cordis bundle）
// 判定逻辑内嵌（8R Judge v2.3，与 8Rworld 仓库 scripts/8r_judge_core.py 逐字等价）；
// 安装与挂载方式见 README.md 与 cordis.patch.yml
const _8r = (() => {
// 8R Judge v2.3 —— JS 移植（与 scripts/8r_judge_core.py 逐字等价；由 gen.py 生成，勿手改）
const PUNCT = "，。！？、；：\"\"（）《》〈〉【】…—·～~,.;:!?()[]{}<>\"' \t\n\r";
const NEUTRAL_DIGITS = new Set('01345679');
const SPECIAL_LOW_TOKENS = new Set(["几把", "曼巴"]);
const UNIVERSE = new Set((
"一丁七万丈三上下不与丐丑专且世丘丙业丛东丝丢两严丧个丫中丰串临丸丹为主丽举乃久么义之乌乍乎乏乐乒乓乔乖乘乙九乞也习乡书买乱乳乾了予争事二于亏云互五井亚些亡亢交亥亦产亩享京亭亮亲人亿什仁仅仆仇今介仍从仑仓仔他仗付仙代令以仪们仰仲件价任份仿企伊伍伏伐休众优伙会伞伟传伤伦伪伯估伴伶伸伺似佃但位低住佐佑体何余佛作你佣佩佳使侄侈例侍供依侠侣侥侦侧侨侮侯侵便促俄俊俏俐俗俘保信俩俭修俯俱俺倍倒倔倘候倚借倡倦债值倾假偎偏做停健偶偷偿傅傍储催傲傻像僚僧僵僻儒儿允元兄充兆先光克免兑兔党兜兢入全八公六兰共关兴兵其具典兹养兼兽冀内冈冉册再冒冗写军农冠冤冥冬冯冰冲决况冶冷冻净凄准凉凌减凑凛凝几凡凤凭凯凰凳凶凸凹出击函凿刀刁刃分切刊刑划列刘则刚创初删判刨利别刮到制刷券刹刺刻剂剃削前剑剔剖剥剧剩剪副割剿劈力劝办功加务劣动助努劫励劲劳势勃勇勉勋勒勘募勤勺勾勿匀包匆匈匕化北匙匠匣匪匹区医匾匿十千升午卉半华协卑卒卓单卖南博卜占卡卢卤卦卧卫卯印危即却卵卷卸卿厂厅历厉压厌厕厘厚原厢厦厨去县叁参又叉及友双反发叔取受变叙叛叠口古句另叨叩只叫召叭叮可台史右叶号司叹叼叽吁吃各吆合吉吊同名后吏吐向吓吕吗君吝吞吟吠否吧吨吩含听吭吮启吱吴" +
"吵吸吹吻吼吾呀呆呈告呐呕员呛呜呢周味呵呻呼命咄咋和咏咐咒咕咖咙咧咨咪咬咱咳咸咽哀品哄哆哇哈哉响哎哑哗哟哥哦哨哩哪哭哮哲哺哼唁唆唇唉唐唠唤唧唬售唯唱唾啃啄商啊啡啤啥啦啪啰啸啼喂善喇喉喊喘喜喝喧喳喷喻嗅嗓嗜嗡嗦嗽嘀嘉嘛嘱嘲嘴嘶嘹嘻嘿器噩噪嚎嚣嚷嚼囊囚四回因团囤园困囱围固国图圃圆圈土圣在地场圾址均坊坎坏坐坑块坚坛坝坟坠坡坤坦坪坯坷垂垃垄型垒垛垢垦垫垮埂埃埋城域埠培基堂堆堕堡堤堪堰堵塌塑塔塘塞填境墅墓墙增墟墨墩壁壤士壬壮声壳壶壹处备复夏夕外多夜够大天太夫夭央夯失头夷夸夹夺奇奈奉奋奏契奔奖套奠奢奥女奴奶奸她好如妃妄妆妇妈妒妓妖妙妥妨妮妹妻姆姊始姐姑姓委姚姜姥姨姻姿威娃娄娇娘娜娟娥娱娶婆婉婚婪婴婶婿媒媚媳嫁嫂嫉嫌嫩子孔孕字存孙孝孟季孤学孩孵孽宁它宅宇守安宋完宏宗官宙定宛宜宝实宠审客宣室宦宪宫宰害宴宵家容宽宾宿寂寄寅密寇富寒寓寝寞察寡寥寨寸对寺寻导寿封射将尉尊小少尔尖尘尚尝尤尧尬就尴尸尺尼尽尾尿局屁层居屈屉届屋屎屏屑展属屠屡履屯山屹屿岁岂岔岖岗岛岩岭岳岸峡峦峨峭峰峻崇崎崔崖崛崩崭嵌巅巍川州巡巢工左巧巨巩巫差己已巳巴巷巾币市布帅帆师希帐帕帖帘帚帜帝带席帮帷常帽幅幌幕幢干平年并幸幻幼幽广庄庆庇床序庐库应" +
"底店庙庚府庞废度座庭庵庶康庸廉廊廓延廷建开异弃弄弊式弓引弗弘弛弟张弥弦弧弯弱弹强归当录形彤彩彪彬彭彰影役彻彼往征径待很徊律徐徒得徘徙御循微德徽心必忆忌忍志忘忙忠忧快忱念忽忿怀态怎怒怔怕怖怜思怠怡急性怨怪怯总恃恋恍恐恒恕恢恤恨恩恬恭息恰恳恶恼悄悉悍悔悖悟悠患悦您悬悯悲悴悼情惊惋惑惕惜惟惠惦惧惨惩惫惭惯惰想惶惹愁愈愉意愕愚感愣愤愧愿慈慌慎慕慢慧慨慰慷憋憎憔憨憾懂懈懊懒懦戈戊戌戎戏成我戒或战戚截戳戴户房所扁扇手才扎扑扒打扔托扛扣执扩扫扬扭扮扯扰扳扶批扼找承技抄把抑抒抓投抖抗折抚抛抠抡抢护报披抬抱抵抹押抽拂拄担拆拇拉拌拍拎拐拒拓拔拖拗拘拙招拜拟拢拣拥拦拧拨择括拭拯拱拳拴拷拼拽拾拿持挂指按挎挑挖挚挟挠挡挣挤挥挨挪挫振挺挽捂捅捆捉捌捍捎捏捐捕捞损捡换捣捧据捶捷捺捻掀掂授掉掌掏掐排掘掠探接控推掩措掰掷掺揉揍描提插握揣揩揪揭援揽搀搁搂搅搏搓搔搜搞搬搭携摄摆摇摊摔摘摧摩摸摹撇撑撒撕撞撤撩撬播撮撰撵撼擂擅操擎擒擦攀支收改攻放政故效敌敏救教敛敞敢散敦敬数敲整敷文斋斌斑斗料斜斟斤斥斧斩断斯新方施旁旅旋族旗无既日旦旧旨早旬旭旱时旷旺昂昆昌明昏易昔星映春昧昨昭是昼显晃晋晌晒晓晕晚晦晨普景晰晴晶智晾暂暇暑暖暗暮暴曙" +
"曝曰曲更曹曼曾替最月有朋服朗望朝期朦木未末本术朱朴朵机朽杀杂权杆杉李杏材村杖杜束杠条来杨杭杯杰松板极构枉析枕林枚果枝枢枣枪枫枯架柄柏某柑柒染柔柜柠查柬柱柳柴柿栅标栈栋栏树栓栖栗校株样核根格栽桂桃框案桌桐桑桔档桥桦桨桩桶梁梅梆梗梢梦梧梨梭梯械梳检棉棋棍棒棕棘棚棠森棱棵棺椅植椎椒椭椰椿楚楷楼概榄榆榔榕榜榨榴槐槛槽樟模横樱橄橘橙橡橱檀檐檬欠次欢欣欧欲欺款歇歉歌止正此步武歧歪歹死歼殃殉殊残殖殴段殷殿毁毅母每毒比毕毙毛毡毫毯氏民氓气氛氢氧氨氮氯水永汁求汇汉汗汛汝汞江池污汤汪汰汹汽沁沃沈沉沐沙沛沟没沥沦沧沪沫沮河沸油治沼沽沾沿泄泉泊泌法泛泞泡波泣泥注泪泰泳泵泻泼泽洁洋洒洗洛洞津洪洲活洼洽派流浅浆浇浊测济浏浑浓浙浦浩浪浮浴海浸涂消涉涌涕涛涝涡涣涤润涧涨涩涮涯液涵淀淆淋淌淑淘淡淤淫淮深淳混淹添清渊渐渔渗渝渠渡渣渤温港渲渴游渺湃湖湘湾湿溃溅溉源溜溢溪溯溶溺滇滋滑滔滚滞满滤滥滨滩滴漂漆漏漓演漠漫漱漾潇潘潜潭潮澄澈澎澜澡澳激濒瀑灌火灭灯灰灵灶灸灼灾灿炉炊炎炒炕炫炬炭炮炸点炼烁烂烈烘烙烛烟烤烦烧烫热烹焉焊焕焚焦焰然煌煎煞煤照煮煽熄熊熏熔熙熟熬燃燕燥爆爪爬爱爵父爷爸爹爽片版牌牙牛牡牢牧物牲牵特牺犀犁犬犯状犹狂狈" +
"狐狗狞狠狡独狭狮狰狱狸狼猎猖猛猜猩猪猫猬献猴猾猿玄率玉王玖玛玩玫环现玲玷玻珊珍珠班球琅理琉琐琢琳琴琼瑙瑞瑟瑰璃璧瓜瓢瓣瓤瓦瓶瓷甘甚甜生甥用甩甫田由甲申电男甸画畅界畏畔留畜略番畴畸疆疏疑疗疙疚疟疤疫疮疯疲疹疼疾病症痊痒痕痘痛痢痪痰痴痹瘟瘤瘦瘩瘪瘫瘸瘾癌癣癸登白百皂的皆皇皓皖皮皱皿盆盈益盏盐监盒盔盖盗盘盛盟目盯盲直相盹盼盾省眉看真眠眨眯眶眷眼着睁睐睛睡督睦睫睬睹瞄瞅瞎瞒瞧瞩瞪瞬瞭瞳瞻矗矛矢矣知矩矫短矮石矾矿码砂砌砍研砖砚砰破砸砾础硅硕硝硫硬确碌碍碎碑碗碘碟碧碰碱碳碾磁磅磊磕磨磷礁示礼社祀祈祖祝神祟祠祥票祭祷祸禀禁禄禅福禹离禽禾秀私秃秆秉秋种科秒秘租秤秦秧秩积称秸移秽稀程稍税稚稠稳稻稼稽稿穆穗穴究穷空穿突窃窄窍窑窒窖窗窘窜窝窟窥窿立竖站竞竟章竣童竭端竹竿笋笑笔笙笛符笨第笼等筋筏筐筑筒答策筛筝筷筹签简箕算管箩箫箭箱篇篓篡篮篱篷簇簧簸簿籍米类籽粉粒粗粘粟粤粥粪粮粱粹精糊糕糖糙糟糠糯系紊素索紧紫累絮繁纠红纤约级纪纫纬纯纱纲纳纵纷纸纹纺纽线练组绅细织终绊绍绎经绑绒结绕绘给绚络绝绞统绢绣继绩绪续绰绳维绵绷绸综绽绿缀缅缆缉缎缓缔缕编缘缚缝缠缤缩缭缰缴缸缺罐网罕罗罚罢罩罪置署羊美羔羚羞羡群羹羽翁翅翔翘翠翩" +
"翰翻翼耀老考者而耍耐耕耗耘耙耳耶耸耻耽耿聂聆聊聋职联聘聚聪肃肆肇肉肋肌肖肘肚肛肝肠股肢肤肥肩肪肮肯育肴肺肾肿胀胁胃胆背胎胖胚胜胞胡胧胰胳胶胸能脂脆脉脊脏脐脑脓脖脚脯脱脸脾腊腋腐腔腕腥腮腰腹腺腻腾腿膀膊膏膛膜膝膨臀臂臊臣自臭至致臼舀舅舆舌舍舒舔舞舟航般舰舱舵舶船艇艘良艰色艳艺艾节芋芒芙芜芝芥芦芬芭芯花芳芹芽苇苍苏苑苔苗苛苞苟若苦英苹茁茂范茄茅茉茎茧茫茬茵茶茸荆草荐荒荔荡荣荤荧荫药荷莉莫莱莲获莹莺莽菇菊菌菜菠菩菱菲萄萌萍萎萝萤营萧萨落著葛葡董葫葬葱葵蒂蒋蒙蒜蒲蒸蓄蓉蓝蓬蔑蔓蔗蔚蔡蔬蔼蔽蕉蕊蕴蕾薄薇薛薪薯藉藏藐藕藤藻蘑虎虏虐虑虚虫虹虽虾蚀蚁蚂蚊蚌蚓蚕蚣蚤蚪蚯蛀蛇蛋蛙蛛蛤蛮蛾蜀蜂蜈蜒蜓蜕蜗蜘蜜蜡蜻蝇蝉蝌蝎蝗蝙蝠蝴蝶螃融螺蟀蟆蟋蟹蠕蠢血衅行衍衔街衙衡衣补表衫衬衰衷袁袄袋袍袖袜被袭袱裁裂装裕裙裤裳裸裹褂褐褒褥褪襟西要覆见观规觅视览觉角解触言誉誊誓警譬计订认讥讨让训议讯记讲讳讶许讹论讼讽设访诀证评识诈诉诊词译试诗诚话诞诡询该详诫诬语误诱诲说诵请诸诺读诽课谁调谅谆谈谊谋谍谎谐谓谚谜谢谣谤谦谨谬谭谱谴谷豁豆豌豚象豪豫豹豺貌贝贞负贡财责贤败账货质贩贪贫贬购贮贯贰贱贴贵贷贸费贺贻贼贾贿赁赂赃资赋赌赎赏赐赔赖" +
"赘赚赛赞赠赡赢赣赤赦赫走赴赵赶起趁超越趋趟趣足趴趾跃跋跌跑跛距跟跤跨跪路跳践跷跺踊踏踢踩踪踱蹂蹄蹈蹋蹦蹬蹭蹲躁躏身躬躯躲躺车轧轨轩转轮软轰轴轻载轿较辅辆辈辉辐辑输辖辗辙辛辜辞辟辣辨辩辫辰辱边辽达迁迂迄迅过迈迎运近返还这进远违连迟迢迪迫迭述迷迹追退送适逃逆选逊透逐递途逗通逛逝逞速造逢逮逸逻逼逾遂遇遍遏道遗遣遥遭遮遵避邀邑邓那邦邪邮邻郁郊郎郑部郭都鄂鄙酉酌配酒酗酝酣酥酪酬酱酵酷酸酿醇醉醋醒采释里重野量金鉴针钉钓钙钝钞钟钠钢钥钦钧钩钮钱钳钻钾铁铃铅铐铛铜铝铭铲银铸铺链销锁锄锅锈锋锌锐错锚锡锣锤锥锦键锯锰锹锻镀镇镐镑镜镰镶长门闪闭问闯闰闲间闷闸闹闺闻闽阀阁阅阎阐阔队防阳阴阵阶阻阿附际陆陈陋陌降限陕陡院除陨险陪陵陶陷隅隆隋随隐隔隘隙障隧隶难雀雁雄雅集雇雌雏雕雨雪雳零雷雹雾需霄震霉霍霎霜霞露霸霹青靖静非靠靡面革靴靶鞋鞍鞠鞭韧韩韭音韵页顶顷项顺须顽顾顿颁颂预颅领颇颈颊频颓颖颗题颜额颠颤风飘飞食餐饥饭饮饰饱饲饵饶饺饼饿馁馅馆馈馋馍馏馒首香馨马驮驯驰驱驳驴驶驹驻驼驾骂骄骆骇验骏骑骗骚骡骤骨髓高鬓鬼魁魂魄魅魏魔鱼鲁鲍鲜鲤鲨鲫鲸鳄鳍鳖鳞鸟鸡鸣鸥鸦鸭鸯鸳鸵鸽鸿鹃鹅鹉鹊鹏鹤鹦鹰鹿麦麻黄黎黑黔默黯鼎鼓鼠鼻齐齿龄龙" +
"龟"));
const D = new Set("8也付伏佛俘俯傅八冶副叭吧咐坝复夫妇孵富巴幅府弗扒扶把抚拂拔捌敷斧服椰浮父爷爸爹甫疤福符缚罢耙耶肤脯腐腹芙芭蝠袱覆负赋赴跋跌辅辐野附霸靶");
const E = new Set("2Rr二仔儿姊子孙尔籽紫而耳贰饵");
const GEN_MAP = {};
for (const ch of D) GEN_MAP[ch] = 'D';
for (const ch of E) GEN_MAP[ch] = 'E';
const ALLOWED = new Set();
for (const ch of UNIVERSE) ALLOWED.add(ch);
for (const ch of NEUTRAL_DIGITS) ALLOWED.add(ch);
for (const ch of '28rR') ALLOWED.add(ch);
for (const ch of PUNCT) ALLOWED.add(ch);

function normalize(text) {
  let i = text.length;
  while (i > 0 && PUNCT.indexOf(text[i - 1]) !== -1) i -= 1;
  return text.slice(0, i);
}

function _result(shouldE, reason, body, throne, kind, start, end) {
  return {
    valid: reason !== 'invalid',
    should_e: shouldE,
    throne: throne,
    set: kind,
    start: start,
    end: end,
    position: start,
    reason: reason,
    body: body,
  };
}

function judge(text) {
  if (typeof text !== 'string') throw new TypeError('judge() 只接受字符串');
  if (text.length === 0) return _result(false, 'empty', '', null, null, null, null);
  for (const ch of text) {
    if (!ALLOWED.has(ch)) return _result(false, 'invalid', text, null, null, null, null);
  }
  const body = normalize(text);
  if (body.length === 0) return _result(false, 'empty', body, null, null, null, null);
  for (let i = body.length - 1; i >= 0; i -= 1) {
    const ch = body[i];
    const kind = GEN_MAP[ch];
    if (kind === undefined) continue;
    if (i > 0) {
      const token = body[i - 1] + ch;
      if (SPECIAL_LOW_TOKENS.has(token)) {
        return _result(false, 'E_SPECIAL', body, token, 'E_SPECIAL', i - 1, i);
      }
    }
    return _result(kind === 'D', kind, body, ch, kind, i, i);
  }
  return _result(false, 'none', body, null, null, null, null);
}

function makePrefix(result) {
  const body = result.body || '';
  let excerpt = body;
  if (body.length > 10) excerpt = body.slice(0, 5) + '…' + body.slice(-5);
  return '**诶！「' + excerpt + '」**\n\n';
}
  return { judge, makePrefix };
})();

const plugin = {
  name: 'plugin-8r',
  apply(ctx) {
    // pending：待注入的诶前缀；sessionId 关联会话，armed 由 agent/pre-step 武装
    // （只有真正进入模型调用的步骤才放行，标题生成等旁路调用不会消费前缀），
    // applied 防止同回合重复注入（失败重试不受影响）
    const pending = { sessionId: '', text: '', prefix: '', armed: false, applied: false };

    // ---- 诊断：事件计数器 + 状态路由（调试用；正常使用无副作用）----
    const diag = { applied: Date.now(), inbox: 0, userMsg: 0, preStep: 0, armed: 0,
                   streamHit: 0, streamWrapped: 0, prefixed: 0 };
    try {
      const ws = ctx.get('webServer');
      if (ws) {
        ws.register({
          kind: 'exact',
          path: '/8r-status',
          handler: (req, res) => {
            res.setHeader('content-type', 'application/json; charset=utf-8');
            res.setHeader('cache-control', 'no-store');
            res.end(JSON.stringify({
              ok: true,
              plugin: 'plugin-8r',
              diag,
              pending: { sessionId: pending.sessionId, hasText: !!pending.text,
                         armed: pending.armed, applied: pending.applied },
            }));
          },
        });
        diag.route = 'registered';
      } else {
        diag.route = 'no-webServer';
      }
    } catch (e) {
      diag.routeError = String(e && e.message);
    }

    const extractText = (msg) => {
      try {
        if (!msg) return '';
        const c = msg.content;
        if (typeof c === 'string') return c;
        if (Array.isArray(c)) {
          let out = '';
          for (const b of c) {
            if (b && typeof b === 'object') {
              if (typeof b.text === 'string') out += b.text;
              else if (typeof b.content === 'string') out += b.content;
            }
          }
          return out;
        }
        return '';
      } catch (e) {
        return '';
      }
    };

    const isHuman = (msg) => {
      try {
        return !!msg && !!msg.source && msg.source.kind === 'user';
      } catch (e) {
        return false;
      }
    };

    const sessionIdOf = (agent) => {
      try {
        if (!agent) return '';
        const s = agent.session;
        return (s && s.id) || agent.id || '';
      } catch (e) {
        return '';
      }
    };

    // 注意：不重置 pending.armed。armed 由 agent/pre-step 统一管理；
    // 实测 session/event 的 user/message 在 pre-step 之后才触发（消息入日志时发射），
    // 若此处重置会把 pre-step 刚武装的状态清掉，导致 llm/stream 跳过注入（v5 修复）。
    const setPending = (sessionId, text) => {
      const r = _8r.judge(text);
      if (r.should_e) {
        pending.sessionId = sessionId;
        pending.text = text;
        pending.prefix = _8r.makePrefix(r);
        pending.applied = false;
      } else {
        pending.sessionId = '';
        pending.text = '';
        pending.prefix = '';
        pending.armed = false;
        pending.applied = false;
      }
    };

    const judgeMessage = (msg, sessionId) => {
      if (!isHuman(msg)) return;
      const text = extractText(msg);
      if (!text) return;
      setPending(sessionId, text);
    };

    const lastHumanText = (messages) => {
      try {
        for (let i = messages.length - 1; i >= 0; i -= 1) {
          const m = messages[i];
          if (!m || m.role === 'assistant' || m.role === 'system') continue;
          const blocks = Array.isArray(m.content) ? m.content : [];
          const nonText = blocks.some((b) => b && typeof b === 'object' &&
            (b.type === 'tool' || b.type === 'tool_result' || b.type === 'tool_call' ||
             b.type === 'toolCall' || b.type === 'image' || b.type === 'file' ||
             b.type === 'attachment'));
          if (nonText) continue;
          const t = extractText(m);
          if (t) return t;
        }
        return '';
      } catch (e) {
        return '';
      }
    };

    // 用户消息判定（双通道，幂等）：
    //  - agent/inbox/inserted：常规消息
    //  - session/event 'user/message'：每条入日志的用户消息必发，
    //    覆盖新会话首条消息（初始化时随会话进入，不走 inbox 插入路径）
    ctx.on('agent/inbox/inserted', (payload) => {
      try {
        if (!payload || !payload.agent || !payload.message) return;
        diag.inbox += 1;
        judgeMessage(payload.message, sessionIdOf(payload.agent));
      } catch (e) {
        console.error('[8r] judge error:', e && e.message);
      }
    });

    ctx.on('session/event', (session, event) => {
      try {
        if (!event || event.type !== 'user/message') return;
        diag.userMsg += 1;
        const sid = session && session.id ? session.id : '';
        judgeMessage(event.data, sid);
      } catch (e) {
        console.error('[8r] judge error:', e && e.message);
      }
    });

    // 主通道：agent/pre-step 判定并武装（该瀑布必然可达；v3 起判定主通道迁到这里，
    // inbox/session-event 仅作备份）。多步回合中后续步骤的 claimed 为空，不会覆盖 pending。
    ctx.on('agent/pre-step', (payload, next) => {
      try {
        diag.preStep += 1;
        const agent = payload && payload.agent ? payload.agent : null;
        const msgs = Array.isArray(payload && payload.messages) ? payload.messages : [];
        let text = '';
        for (let i = msgs.length - 1; i >= 0; i -= 1) {
          const m = msgs[i];
          if (!m || m.role === 'assistant' || m.role === 'system') continue;
          const t = extractText(m);
          if (!t) continue;
          text = t;
          break;
        }
        if (text) {
          const sid = agent ? sessionIdOf(agent) : pending.sessionId;
          const r = _8r.judge(text);
          if (r.should_e) {
            pending.sessionId = sid;
            pending.text = text;
            pending.prefix = _8r.makePrefix(r);
            pending.armed = true;
            diag.armed += 1;
            pending.applied = false;
          } else if (text !== pending.text) {
            pending.sessionId = '';
            pending.text = '';
            pending.prefix = '';
            pending.armed = false;
            pending.applied = false;
          }
        }
      } catch (e) {}
      return next();
    });

    ctx.on('llm/stream', (options, next) => {
      try {
        if (!pending.prefix || pending.applied || !pending.armed) return next();
        if (!options || options.sessionId !== pending.sessionId) return next();
        const msgs = Array.isArray(options.messages) ? options.messages : [];
        const last = lastHumanText(msgs);
        if (!last || last !== pending.text) return next();
        diag.streamHit += 1;
        const prefix = pending.prefix;
        const inner = next();
        diag.streamWrapped += 1;
        return (async function* () {
          let prefixed = false;
          let ok = false;
          try {
            for await (const chunk of inner) {
              if (chunk && typeof chunk === 'object') {
                if (!prefixed && chunk.type === 'text-delta' && typeof chunk.text === 'string') {
                  // 产出新对象，不修改原块（原块可能冻结/只读；v4 修复）
                  yield Object.assign({}, chunk, { text: prefix + chunk.text });
                  prefixed = true;
                  continue;
                }
                if (chunk.type === 'block-end' && chunk.block &&
                    chunk.block.type === 'text' && typeof chunk.block.text === 'string' &&
                    chunk.block.text.indexOf(prefix) !== 0) {
                  // 无 !prefixed 守卫：适配器补发的 block-end 携带其内部攒的原始完整文本
                  // （不含注入前缀），assembler first-close-wins 以它为准，必须在此也注入；
                  // indexOf 守卫防重复前缀（v6 修复）。
                  yield Object.assign({}, chunk, {
                    block: Object.assign({}, chunk.block, { text: prefix + chunk.block.text }),
                  });
                  prefixed = true;
                  continue;
                }
              }
              yield chunk;
            }
            ok = true;
          } finally {
            if (ok && prefixed) {
              diag.prefixed += 1;
              pending.applied = true;
              pending.armed = false;
            }
          }
        })();
      } catch (e) {
        console.error('[8r] stream wrap error:', e && e.message);
        return next();
      }
    });
  }
};

export default plugin;
export { plugin };
