/**
 * dsh-liangwengu host half.
 *
 * Reads the bundled cartoon asset (assets/cartoon.jpg) and serves it to the
 * browser half at GET /liangwengu/cartoon.jpg. The client half uses that URL
 * as the popup avatar and as the Notification icon.
 *
 * Everything else (scheduling, popup, notification, sound) lives in the
 * browser half (lib/client.js) — pure client, no host state.
 */

export const name = 'dsh-liangwengu'

const IMAGE_ROUTE = '/liangwengu/cartoon.jpg'

export async function apply(ctx) {
  const { readFile } = await import('node:fs/promises')
  const { dirname, join } = await import('node:path')
  const { fileURLToPath } = await import('node:url')

  const packageDir = dirname(fileURLToPath(import.meta.url))
  const imagePath = join(packageDir, '..', 'assets', 'cartoon.jpg')

  let bytes = null
  try {
    bytes = await readFile(imagePath)
  } catch (err) {
    console.error('[liangwengu] cartoon asset load failed:', err)
  }

  if (bytes === null || bytes.length === 0) {
    console.error('[liangwengu] no cartoon asset; popup will render without an avatar')
    return
  }

  const webServer = ctx.get('webServer')
  if (webServer === undefined) {
    console.error('[liangwengu] webServer service unavailable; image route skipped')
    return
  }

  ctx.effect(() => webServer.register({
    kind: 'exact',
    path: IMAGE_ROUTE,
    handler(req, res) {
      res.writeHead(200, {
        'Content-Type': 'image/jpeg',
        'Content-Length': String(bytes.length),
        'Cache-Control': 'public, max-age=3600',
      })
      res.end(bytes)
    },
  }))
}
