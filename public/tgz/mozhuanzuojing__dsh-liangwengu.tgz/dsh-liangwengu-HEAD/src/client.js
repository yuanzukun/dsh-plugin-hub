/**
 * dsh-liangwengu browser half (ModuleLoader bundle) — v0.2.0 HUD.
 *
 * 梁文谷提醒 — DeepSeek API 定价高峰/空闲时段提醒。
 *
 * 梗：梁文峰=峰=高峰时段（贵一倍，快跑）；梁文谷=谷=空闲时段（半价，开薅）。
 *
 * 触发点（北京时间，钉死 Asia/Shanghai，与机器时区无关）：
 *   08:30 / 08:40 / 08:50  → 高峰倒计时（距 09:00 还有 30/20/10 分钟）
 *   08:55                   → 峰前警告「梁文峰要来了，块跑啊！」
 *   12:00                   → 峰结束「乡亲们，梁文峰走了！！可以出来了！」+「梁文谷 启动~~~」
 *   13:30 / 13:40 / 13:50  → 高峰倒计时（距 14:00 还有 30/20/10 分钟）
 *   13:55                   → 峰前警告「梁文峰要来了，块跑啊！」
 *   18:00                   → 峰结束「乡亲们，梁文峰走了！！可以出来了！」+「梁文谷 启动~~~」
 *
 * 游戏化 HUD（v0.2.0）：
 *   - 右上角常驻胶囊（可拖动，位置存 localStorage）：图标 + 阶段名 + 生命值血条 + 距下一事件
 *   - 生命值 = 安全剩余量：谷中满血 100 → 倒计时掉血（30分70/20分40/10分10）→ 峰中回血爬升（距峰走越近越多）→ 峰走满血
 *   - 点击胶囊展开详情：当前阶段卡 + 今日时间表 + HP 规则 + 今日播报记录（点外部关闭）
 *
 * 大喊：右下角 bounce 卡通弹窗（气泡台词） + 浏览器系统通知 + 提示音（Web Audio）。
 * 错过：页面打开时距最近主触发点 ≤15 分钟补播，否则一次性阶段播报（倒计时过期不补播）。
 *
 * bundle 世界拥有完整浏览器全局：Notification / AudioContext / window / document / localStorage。
 */
window.__ModuleLoader__.load({
	id: 'dsh-liangwengu',
	factory: (require) => {
		var module = { exports: {} };
		var exports = module.exports;
		let React = require("react");

		const CARTON_URL = '/liangwengu/cartoon.jpg';
		const CATCHUP_WINDOW_MS = 15 * 60 * 1000;
		const POPUP_MS = 8000;
		const TICK_MS = 20000;
		const HUD_MS = 1000;
		const FIRE_WINDOW_MS = 2 * 60 * 1000; // 触发窗口：触发点后 2 分钟内都算（抗后台节流漏触发）
		const POS_KEY = 'lwg.capsule.pos';
		const LOG_KEY = 'lwg.log.v1';

		const TRIGGERS = [
			{ key: 'am-warn', at: '08:55', tone: 'warn', lines: ['梁文峰要来了，块跑啊！'], label: '早峰警告·快跑' },
			{ key: 'am-end', at: '12:00', tone: 'good', gurgle: true, lines: ['乡亲们，梁文峰走了！！可以出来了！', '梁文谷 启动~~~'], label: '早峰结束·谷启动' },
			{ key: 'pm-warn', at: '13:55', tone: 'warn', lines: ['梁文峰要来了，块跑啊！'], label: '午峰警告·快跑' },
			{ key: 'pm-end', at: '18:00', tone: 'good', gurgle: true, lines: ['乡亲们，梁文峰走了！！可以出来了！', '梁文谷 启动~~~'], label: '午峰结束·谷启动' },
		];

		// 倒计时阶梯：高峰开始前 30/20/10 分钟各喊一次
		const PEAK_STARTS = ['09:00', '14:00'];
		const COUNTDOWN_STEPS = [
			{ mins: 30, line: '梁文峰 30 分钟后到，乡亲们抓紧收尾！', label: '距峰 30 分' },
			{ mins: 20, line: '还有 20 分钟，梁文峰就要来了！', label: '距峰 20 分' },
			{ mins: 10, line: '还有 10 分钟！梁文峰快到了，快找地方躲！！', label: '距峰 10 分' },
		];
		const COUNTDOWN_TRIGGERS = [];
		for (const peak of PEAK_STARTS) {
			const hmArr = peak.split(':');
			const peakMins = +hmArr[0] * 60 + +hmArr[1];
			for (const step of COUNTDOWN_STEPS) {
				const at = peakMins - step.mins;
				COUNTDOWN_TRIGGERS.push({
					at: String(Math.floor(at / 60)).padStart(2, '0') + ':' + String(at % 60).padStart(2, '0'),
					key: 'cd-' + peak + '-' + step.mins,
					tone: 'warn',
					lines: [step.line],
					label: step.label,
					quiet: true,
				});
			}
		}

		// 隐藏彩蛋：HP 归零时刻（峰至 09:00/14:00）随机触发，每天限 2 次
		const PEAK_MOMENTS = ['09:00', '14:00'];
		const EASTER_EGGS = [
			'梁文峰路过你工位，你屏住了呼吸',
			'隔壁屏还亮着，你假装在改 PPT',
			'会议室的灯亮了，快把摸鱼页面切走',
			'梁文峰在走廊咳嗽了一声，全员静止',
			'你听见键盘声渐近，那是老板的脚步',
			'空调停了，办公室静得能听见梁文峰的呼吸',
			'水杯还冒着热气，人已经藏到显示器后面',
			'梁文峰回头了！快，假装在查文档',
			'滴——监测到梁文峰接近，全体卧倒',
		];
		const eggFired = new Set();
		// 血条煮水气泡：模块级预生成固定配置（渲染期不再 Math.random，避免每秒抖动）
		const BUBBLE_CFGS = [];
		for (let i = 0; i < 6; i++) {
			BUBBLE_CFGS.push({
				left: 10 + Math.random() * 70,
				delay: Math.random(),
				dur: 0.8 + Math.random() * 0.6,
				w: 2 + Math.random() * 3,
				h: 2 + Math.random() * 3,
			});
		}
		function fireEgg(when) {
			const hm = hhmm(when);
			const key = dateKey(when) + '|egg|' + hm;
			if (eggFired.has(key)) return;
			eggFired.add(key);
			const line = EASTER_EGGS[Math.floor(Math.random() * EASTER_EGGS.length)];
			logPush({ date: dateKey(when), at: hm, label: '隐藏彩蛋' });
			showPopup({ id: 'egg-' + key, tone: 'good', egg: true, lines: [line] });
		}

		// ---------- 修仙等级（凡人修仙传九境，翻倍曲线） ----------
		const CULT_KEY = 'lwg.cultivation.v1';
		const REALMS = [
			{ name: '炼气', icon: '🌱', need: 10, lines: ['灵气入体，炼气圆满！', '凡人起步，气感初成！'] },
			{ name: '筑基', icon: '🧱', need: 20, lines: ['灵根扎根，筑基已成！', '踏稳道基，再上高楼！'] },
			{ name: '金丹', icon: '⚜️', need: 40, lines: ['丹成九转，金丹大道初显！', '一粒金丹吞入腹，我命由我不由天！'] },
			{ name: '元婴', icon: '👶', need: 80, lines: ['婴变新生，元婴出窍！', '元婴一现，天地变色！'] },
			{ name: '化神', icon: '👁️', need: 160, lines: ['神识如海，化神成矣！', '神游太虚，一念千里！'] },
			{ name: '炼虚', icon: '🌌', need: 320, lines: ['破虚合道，炼虚登堂！', '虚空炼体，道法自明！'] },
			{ name: '合体', icon: '☯️', need: 640, lines: ['身与道合，合体大成！', '法相天地，合体归一！'] },
			{ name: '大乘', icon: '🕉️', need: 1280, lines: ['道行圆满，大乘在望！', '九转功成，只差一劫！'] },
			{ name: '真仙', icon: '🦢', need: 2560, lines: [] },
		];
		const SECLUSION_SEC_PER_XP = 3600; // 谷中每在线 1 小时 +1 闭关修为
		function loadCult() {
			try {
				const c = JSON.parse(window.localStorage.getItem(CULT_KEY) || 'null');
				if (c && typeof c.xp === 'number') return Object.assign({ xp: 0, seclusionSec: 0, tribDate: '', tribCount: 0, lastSeen: 0, lastSettle: '' }, c);
			} catch {}
			return { xp: 0, seclusionSec: 0, tribDate: '', tribCount: 0, lastSeen: 0, lastSettle: '' };
		}
		let CULT = loadCult();
		CULT.lastSeen = Date.now(); // 页面加载即开始计算在场时长（关闭期间不累计）
		function saveCult() { try { window.localStorage.setItem(CULT_KEY, JSON.stringify(CULT)); } catch {} }
		function realmOf(xp) {
			let total = 0;
			for (let i = 0; i < REALMS.length; i++) {
				total += REALMS[i].need;
				if (xp < total) {
					return {
						index: i,
						name: REALMS[i].name,
						icon: REALMS[i].icon,
						done: xp - (total - REALMS[i].need),
						into: REALMS[i].need,
						lines: REALMS[i].lines,
						next: i + 1 < REALMS.length ? REALMS[i + 1].name : null,
						total: xp,
					};
				}
			}
			return { index: REALMS.length - 1, name: REALMS[REALMS.length - 1].name, icon: REALMS[REALMS.length - 1].icon, done: REALMS[REALMS.length - 1].need, into: REALMS[REALMS.length - 1].need, lines: [], next: null, total: xp };
		}
		function playLevelUp() {
			try {
				const Ctx = window.AudioContext || window.webkitAudioContext;
				if (!Ctx) return;
				const ac = new Ctx();
				const beep = (freq, at, dur) => {
					const osc = ac.createOscillator();
					const gain = ac.createGain();
					osc.connect(gain); gain.connect(ac.destination);
					osc.type = 'triangle'; osc.frequency.value = freq;
					const t0 = ac.currentTime + at;
					gain.gain.setValueAtTime(0.0001, t0);
					gain.gain.exponentialRampToValueAtTime(0.2, t0 + 0.02);
					gain.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
					osc.start(t0); osc.stop(t0 + dur + 0.02);
				};
				beep(523, 0, 0.14); beep(659, 0.16, 0.14); beep(784, 0.32, 0.24); // 上行三连音
				window.setTimeout(() => { try { ac.close(); } catch {} }, 1000);
			} catch {}
		}
		function breakthrough(realm, when) {
			const hm = hhmm(when);
			logPush({ date: dateKey(when), at: hm, label: '突破·' + realm.name });
			if (realm.name === '真仙') {
				showPopup({ id: 'ascend-' + Date.now(), tone: 'good', ascend: true, lines: ['🦢 渡劫成功，飞升仙界！', '梁文谷仙途圆满，再见人间。'] });
			} else {
				const line = realm.lines[Math.floor(Math.random() * realm.lines.length)];
				showPopup({ id: 'break-' + Date.now(), tone: 'good', breakthru: true, lines: [realm.icon + ' ' + realm.name + '！' + line] });
			}
			playLevelUp();
		}
		function addXp(amount, when) {
			const before = realmOf(CULT.xp);
			CULT.xp += amount;
			saveCult();
			const after = realmOf(CULT.xp);
			if (after.index > before.index) breakthrough(after, when);
		}
		// 渡劫：12:00/18:00 结算点在线 +1（含跨标签守卫，防双开刷点）
		const SETTLE_MOMENTS = ['12:00', '18:00'];
		const settleFired = new Set();
		function settleTrib(when) {
			const hm = hhmm(when);
			const key = dateKey(when) + '|' + hm;
			if (settleFired.has(key)) return;
			settleFired.add(key);
			try {
				const c = JSON.parse(window.localStorage.getItem(CULT_KEY) || 'null');
				if (c && c.lastSettle === key) return; // 另一标签已结算，本标签跳过
			} catch {}
			CULT.lastSettle = key;
			if (CULT.tribDate !== dateKey(when)) { CULT.tribDate = dateKey(when); CULT.tribCount = 0; }
			CULT.tribCount += 1;
			logPush({ date: dateKey(when), at: hm, label: '渡劫结算 +1' });
			addXp(1, when);
		}
		// 闭关：谷时段（非峰即谷，含倒计时）每在线 1 小时 +1。
		// 按真实流逝时间计（非每 tick 固定 20s），后台节流/休眠也能准确累积；
		// 单次上限 15 分钟，防睡眠/长时间后台刷点。
		function seclusionTick(when) {
			const last = typeof CULT.lastSeen === 'number' && CULT.lastSeen > 0 ? CULT.lastSeen : when - TICK_MS;
			let elapsed = when - last;
			if (elapsed <= 0) elapsed = TICK_MS;
			if (elapsed > 15 * 60 * 1000) elapsed = 15 * 60 * 1000;
			CULT.lastSeen = when;
			if (!isPeak(when)) {
				CULT.seclusionSec += Math.round(elapsed / 1000);
				if (CULT.seclusionSec >= SECLUSION_SEC_PER_XP) {
					CULT.seclusionSec -= SECLUSION_SEC_PER_XP;
					logPush({ date: dateKey(when), at: hhmm(when), label: '闭关 +1' });
					addXp(1, when);
				}
			}
			saveCult();
		}

		// ---------- 北京时间（钉死 Asia/Shanghai） ----------
		function beijingParts(when) {
			const parts = new Intl.DateTimeFormat('en-CA', {
				timeZone: 'Asia/Shanghai',
				year: 'numeric', month: '2-digit', day: '2-digit',
				hour: '2-digit', minute: '2-digit', second: '2-digit',
				hour12: false,
			}).formatToParts(when);
			const get = (t) => { const p = parts.find((x) => x.type === t); return p ? p.value : '0'; };
			return { y: +get('year'), m: +get('month'), d: +get('day'), h: +get('hour'), min: +get('minute'), s: +get('second') };
		}
		function hhmm(when) {
			const p = beijingParts(when);
			return String(p.h).padStart(2, '0') + ':' + String(p.min).padStart(2, '0');
		}
		function beijingEpoch(y, m, d, h, min) {
			return Date.UTC(y, m - 1, d, h, min, 0) - 8 * 3600 * 1000;
		}
		function isPeak(when) {
			const p = beijingParts(when);
			const mins = p.h * 60 + p.min;
			return (mins >= 540 && mins < 720) || (mins >= 840 && mins < 1080); // 09:00-12:00, 14:00-18:00
		}
		function dateKey(when) {
			const p = beijingParts(when);
			return p.y + '-' + p.m + '-' + p.d;
		}

		// ---------- 生命值（安全剩余量，v0.4.4 起峰中改为回血爬升） ----------
		// 谷中 100 满血；倒计时按锚点分段线性掉血（T-30=70 / T-20=40 / T-10=10 / 峰=0）；
		// 峰中从 0 向 100 爬升（对应距峰走剩余，越接近峰走血越多，峰走回满）
		const PEAK_WINDOWS = [
			{ start: 540, end: 720 }, // 09:00 → 12:00
			{ start: 840, end: 1080 }, // 14:00 → 18:00
		];
		const COUNTDOWN_WINDOWS = [
			{ start: 510, end: 540 }, // 08:30 → 09:00
			{ start: 810, end: 840 }, // 13:30 → 14:00
		];
		const HP_ANCHORS = [[0, 70], [1 / 3, 40], [2 / 3, 10], [1, 0]];
		function piecewise(t, pts) {
			for (let i = 0; i < pts.length - 1; i++) {
				const [t0, v0] = pts[i]; const [t1, v1] = pts[i + 1];
				if (t >= t0 && t <= t1) return v0 + (v1 - v0) * ((t - t0) / ((t1 - t0) || 1));
			}
			return pts[pts.length - 1][1];
		}
		function hpAt(when) {
			const p = beijingParts(when);
			const mins = p.h * 60 + p.min;
			for (const w of PEAK_WINDOWS) {
				if (mins >= w.start && mins < w.end) {
					return { hp: Math.round(((mins - w.start) / (w.end - w.start)) * 100), phase: 'peak' };
				}
			}
			for (const w of COUNTDOWN_WINDOWS) {
				if (mins >= w.start && mins < w.end) {
					return { hp: Math.round(piecewise((mins - w.start) / (w.end - w.start), HP_ANCHORS)), phase: 'countdown' };
				}
			}
			return { hp: 100, phase: 'valley' };
		}

		const ICONS = { valley: '🐋', countdown: '⏳', peak: '😱' };
		const LABELS = { valley: '梁文谷', countdown: '峰将至', peak: '峰中·快躲' };
		const MEANINGS = {
			valley: '空闲时段 · 半价随便薅',
			countdown: '高峰将至 · 血条开始掉，准备跑路',
			peak: '高峰时段 · 贵一倍，别乱动',
		};
		function hpColor(hp) {
			if (hp >= 60) return '#43e97b';
			if (hp >= 20) return '#ffb300';
			return '#ff5252';
		}

		// ---------- 白天/月夜主题（北京时间 06:00-18:00 白天，其余月夜） ----------
		function dayNightAt(when) {
			const p = beijingParts(when);
			return p.h >= 6 && p.h < 18 ? 'day' : 'night';
		}

		// ---------- 血雾（屏幕边缘随 HP 变化：倒计时渐显、峰中随回血渐隐，v0.3.2 起极淡） ----------
		function fogOpacity(hp, phase) {
			if (phase === 'peak') return Math.round(((100 - hp) / 100) * 0.0275 * 10000) / 10000;
			if (phase === 'countdown') return Math.round(((100 - hp) / 100) * 0.0225 * 10000) / 10000;
			return 0;
		}

		// ---------- 下一事件 ----------
		function allTriggers() { return TRIGGERS.concat(COUNTDOWN_TRIGGERS); }
		function nextEvent(when) {
			const now = when;
			const today = beijingParts(now);
			const yesterday = beijingParts(now - 86400000);
			let best = null;
			for (const base of [yesterday, today]) {
				for (const t of allTriggers()) {
					const hmArr = t.at.split(':');
					const epoch = beijingEpoch(base.y, base.m, base.d, +hmArr[0], +hmArr[1]);
					if (epoch > now && (best === null || epoch < best.epoch)) best = { trigger: t, epoch };
				}
			}
			if (best === null) return { label: '—', at: '--:--' };
			return { label: best.trigger.label, at: hhmm(best.epoch), epoch: best.epoch };
		}
		function todaySchedule(when) {
			const p = beijingParts(when);
			const nowMins = p.h * 60 + p.min;
			return allTriggers()
				.map((t) => {
					const hmArr = t.at.split(':');
					const tm = +hmArr[0] * 60 + +hmArr[1];
					return { key: t.key, at: t.at, label: t.label, past: tm < nowMins, now: tm === nowMins };
				})
				.sort((a, b) => a.at < b.at ? -1 : 1);
		}

		// ---------- 弹窗状态总线 + 今日播报记录 ----------
		const listeners = new Set();
		const emit = (popup) => { listeners.forEach((fn) => { try { fn(popup); } catch {} }); };
		const subscribe = (fn) => { listeners.add(fn); return () => { listeners.delete(fn); }; };
		const fired = new Set();

		function loadLog() {
			try {
				const arr = JSON.parse(window.localStorage.getItem(LOG_KEY) || '[]');
				return Array.isArray(arr) ? arr : [];
			} catch { return []; }
		}
		function saveLog(arr) {
			try { window.localStorage.setItem(LOG_KEY, JSON.stringify(arr.slice(-30))); } catch {}
		}
		let LOG = loadLog();
		function logPush(entry) {
			LOG = LOG.concat(entry).filter((e) => e.date === dateKey(Date.now())).slice(-30);
			saveLog(LOG);
		}
		function todayLog() { return LOG.filter((e) => e.date === dateKey(Date.now())); }

		function fire(trigger, when) {
			const key = dateKey(when) + '|' + trigger.key;
			if (fired.has(key)) return;
			fired.add(key);
			logPush({ date: dateKey(when), at: hhmm(when), label: trigger.label });
			showPopup({ id: key, tone: trigger.tone, gurgle: trigger.gurgle, lines: trigger.lines }, !trigger.quiet);
		}
		function firePhase(when) {
			const peak = isPeak(when);
			showPopup({
				id: 'phase-' + dateKey(when) + '-' + (peak ? 'peak' : 'valley'),
				tone: peak ? 'warn' : 'good',
				lines: [peak ? '梁文峰还在盯场，别乱跑' : '梁文谷进行时，随便薅'],
			});
		}
		function tick() {
			const now = Date.now();
			for (const t of TRIGGERS) if (inFireWindow(now, t.at)) fire(t, now);
			// 倒计时（08:30/40/50、13:30/40/50）不再弹窗，由血条下滑 + 胶囊「距下一事件」承载
			for (const m of PEAK_MOMENTS) if (inFireWindow(now, m)) fireEgg(now);
			for (const m of SETTLE_MOMENTS) if (inFireWindow(now, m)) settleTrib(now);
			seclusionTick(now);
		}
		// 窗口检测：now 落在 at（北京时间）触发点后的 FIRE_WINDOW_MS 内即视为命中；
		// 配合去重集合，后台节流/切回前台补扫也不会重复或遗漏
		function inFireWindow(when, atHm) {
			const p = beijingParts(when);
			const hmArr = atHm.split(':');
			const epoch = beijingEpoch(p.y, p.m, p.d, +hmArr[0], +hmArr[1]);
			return when >= epoch && when - epoch < FIRE_WINDOW_MS;
		}
		function onLoad() {
			const now = Date.now();
			const today = beijingParts(now);
			const yesterday = beijingParts(now - 86400000);
			let best = null;
			// 补播只看主触发点（倒计时过期不补播）
			for (const base of [yesterday, today]) {
				for (const t of TRIGGERS) {
					const hmArr = t.at.split(':');
					const epoch = beijingEpoch(base.y, base.m, base.d, +hmArr[0], +hmArr[1]);
					if (epoch <= now && (best === null || epoch > best.epoch)) best = { trigger: t, epoch };
				}
			}
			if (best !== null && now - best.epoch <= CATCHUP_WINDOW_MS) {
				fire(best.trigger, now);
				return;
			}
			firePhase(now);
		}

		// ---------- 大喊三件套：弹窗 + 系统通知 + 提示音 ----------
		function ensureNotifyPermission() {
			try {
				if (typeof Notification === 'undefined') return;
				if (Notification.permission === 'default') Notification.requestPermission();
			} catch {}
		}
		function notify(title, body) {
			try {
				if (typeof Notification === 'undefined') return;
				if (Notification.permission !== 'granted') return;
				const n = new Notification(title, { body, icon: CARTON_URL, tag: 'liangwengu' });
				if (n) window.setTimeout(() => { try { n.close(); } catch {} }, 10000);
			} catch {}
		}
		function playBeep(tone) {
			try {
				const Ctx = window.AudioContext || window.webkitAudioContext;
				if (!Ctx) return;
				const ac = new Ctx();
				const beep = (freq, at, dur) => {
					const osc = ac.createOscillator();
					const gain = ac.createGain();
					osc.connect(gain); gain.connect(ac.destination);
					osc.type = 'square'; osc.frequency.value = freq;
					const t0 = ac.currentTime + at;
					gain.gain.setValueAtTime(0.0001, t0);
					gain.gain.exponentialRampToValueAtTime(0.22, t0 + 0.02);
					gain.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
					osc.start(t0); osc.stop(t0 + dur + 0.02);
					return osc;
				};
				if (tone === 'warn') { beep(880, 0, 0.18); beep(660, 0.22, 0.3); }
				else { beep(523, 0, 0.15); beep(784, 0.18, 0.35); }
				window.setTimeout(() => { try { ac.close(); } catch {} }, 1200);
			} catch {}
		}
		function playGurgle() {
			try {
				const Ctx = window.AudioContext || window.webkitAudioContext;
				if (!Ctx) return;
				const ac = new Ctx();
				const t0 = ac.currentTime;
				// 7 个随机低频"咕噜"气泡音
				for (let i = 0; i < 7; i++) {
					const at = t0 + i * 0.13 + Math.random() * 0.05;
					const freq = 140 + Math.random() * 220;
					const osc = ac.createOscillator();
					const gain = ac.createGain();
					osc.connect(gain); gain.connect(ac.destination);
					osc.type = 'sine'; osc.frequency.value = freq;
					gain.gain.setValueAtTime(0.0001, at);
					gain.gain.exponentialRampToValueAtTime(0.16, at + 0.02);
					gain.gain.exponentialRampToValueAtTime(0.0001, at + 0.12);
					osc.start(at); osc.stop(at + 0.15);
				}
				// 低通噪声模拟水声
				const bufSize = Math.floor(ac.sampleRate * 0.5);
				const buffer = ac.createBuffer(1, bufSize, ac.sampleRate);
				const data = buffer.getChannelData(0);
				for (let i = 0; i < bufSize; i++) data[i] = (Math.random() * 2 - 1) * 0.3;
				const src = ac.createBufferSource(); src.buffer = buffer;
				const filt = ac.createBiquadFilter(); filt.type = 'lowpass'; filt.frequency.value = 520;
				const ng = ac.createGain();
				src.connect(filt); filt.connect(ng); ng.connect(ac.destination);
				ng.gain.setValueAtTime(0.0001, t0);
				ng.gain.exponentialRampToValueAtTime(0.11, t0 + 0.05);
				ng.gain.exponentialRampToValueAtTime(0.0001, t0 + 0.7);
				src.start(t0); src.stop(t0 + 0.75);
				window.setTimeout(() => { try { ac.close(); } catch {} }, 1500);
			} catch {}
		}
		function showPopup(popup, loud = true) {
			emit(popup);
			if (!popup) return;
			if (loud) {
				ensureNotifyPermission();
				notify('梁文谷提醒', popup.lines.join(' / '));
				if (popup.gurgle) playGurgle();
				else playBeep(popup.tone);
			}
		}

		// ---------- 样式 ----------
		const CSS = `
			.lwg-popup{position:fixed;right:24px;bottom:24px;z-index:99999;display:flex;align-items:flex-end;gap:10px;cursor:pointer;pointer-events:auto;animation:lwg-bounce .55s cubic-bezier(.34,1.56,.64,1);user-select:none;font-family:system-ui,-apple-system,'PingFang SC','Microsoft YaHei',sans-serif}
			.lwg-avatar{width:110px;height:110px;border-radius:16px;object-fit:cover;box-shadow:0 6px 20px rgba(0,0,0,.28);border:2px solid rgba(255,255,255,.85);background:#fff}
			.lwg-bubble{position:relative;max-width:280px;padding:12px 16px;border-radius:14px;font-size:15px;line-height:1.5;font-weight:700;color:#fff;box-shadow:0 6px 18px rgba(0,0,0,.22)}
			.lwg-bubble::after{content:'';position:absolute;right:-8px;bottom:18px;border:8px solid transparent;border-left:10px solid currentColor}
			.lwg-warn{background:linear-gradient(135deg,#ff5f5f,#e53935)}
			.lwg-good{background:linear-gradient(135deg,#43e97b,#38b000)}
			.lwg-line{white-space:pre-line}
			.lwg-line+.lwg-line{margin-top:4px}
			.lwg-close{position:absolute;top:-8px;right:-8px;width:22px;height:22px;border-radius:50%;background:#333;color:#fff;font-size:12px;line-height:22px;text-align:center;box-shadow:0 2px 6px rgba(0,0,0,.3)}
			@keyframes lwg-bounce{0%{transform:translateY(140%) scale(.6);opacity:0}60%{transform:translateY(-14%) scale(1.05);opacity:1}100%{transform:translateY(0) scale(1)}}

			.lwg-fog{position:fixed;inset:0;z-index:99996;pointer-events:none;background:radial-gradient(ellipse at center,transparent 52%,rgba(200,30,30,.55) 100%);opacity:0;transition:opacity 1s linear}
			.lwg-egg .lwg-avatar-egg{width:150px;height:150px;animation:lwg-shake .5s ease-in-out}
			.lwg-egg-bubble{background:linear-gradient(135deg,#a78bfa,#7c3aed)}
			@keyframes lwg-shake{0%,100%{transform:rotate(0)}20%{transform:rotate(-6deg) translateX(-3px)}40%{transform:rotate(5deg) translateX(3px)}60%{transform:rotate(-4deg)}80%{transform:rotate(3deg)}}

			.lwg-realm{font-size:10px;font-weight:800;color:var(--accent);background:var(--card);border:1px solid var(--border);border-radius:999px;padding:2px 7px;white-space:nowrap}
			.lwg-xpbar{display:block;width:100%;height:8px;border-radius:4px;background:var(--track);overflow:hidden;margin:4px 0}
			.lwg-xpfill{display:block;height:100%;border-radius:4px;background:linear-gradient(90deg,#ffd54f,#ffb300);transition:width .6s ease}
			.lwg-break .lwg-avatar-break{width:130px;height:130px;box-shadow:0 0 0 3px rgba(255,193,7,.9),0 0 34px rgba(255,193,7,.85);animation:lwg-glow 1.4s ease-in-out infinite}
			.lwg-break-bubble{background:linear-gradient(135deg,#ffd54f,#ffb300)}
			.lwg-ascend .lwg-avatar-ascend{width:150px;height:150px;box-shadow:0 0 0 4px rgba(255,214,79,.95),0 0 60px rgba(255,193,7,1);animation:lwg-ascend-spin 1.6s ease-in-out infinite}
			.lwg-ascend-bubble{background:linear-gradient(135deg,#fff3b0,#ffb300);color:#5a3e00}
			@keyframes lwg-glow{0%,100%{box-shadow:0 0 0 3px rgba(255,193,7,.9),0 0 20px rgba(255,193,7,.6)}50%{box-shadow:0 0 0 3px rgba(255,193,7,.9),0 0 44px rgba(255,193,7,.95)}}
			@keyframes lwg-ascend-spin{0%,100%{transform:translateY(0) rotate(0)}50%{transform:translateY(-8px) rotate(4deg)}}

			.lwg-hpbar.water{height:16px}
			.lwg-bub{position:absolute;bottom:10%;border-radius:50%;background:rgba(255,255,255,.9);animation:lwg-bub-rise 1s ease-in infinite;opacity:0}
			@keyframes lwg-bub-rise{0%{transform:translateY(0) scale(.6);opacity:0}15%{opacity:.95}100%{transform:translateY(-14px) scale(1.2);opacity:0}}
			.lwg-puff{position:absolute;bottom:calc(100% + 2px);width:12px;height:12px;border-radius:50%;background:radial-gradient(circle,rgba(255,255,255,.95),rgba(255,255,255,0));animation:lwg-puff-rise 2.6s ease-out infinite;opacity:0;pointer-events:none}
			.lwg-puff-big{width:20px;height:20px;animation-duration:1.6s}
			@keyframes lwg-puff-rise{0%{transform:translateY(0) scale(.5);opacity:0}20%{opacity:.9}100%{transform:translateY(-28px) scale(1.6);opacity:0}}

			.lwg-capsule{position:fixed;z-index:99998;display:flex;align-items:center;gap:7px;padding:7px 13px;border-radius:999px;color:#eaf2ff;font-size:12px;line-height:1;cursor:grab;user-select:none;touch-action:none;pointer-events:auto;font-family:system-ui,-apple-system,'PingFang SC','Microsoft YaHei',sans-serif;--fg:#eaf2ff;--dim:rgba(234,242,255,.55);--accent:#9ad1ff;--track:rgba(255,255,255,.15);--card:rgba(255,255,255,.06);--border:rgba(255,255,255,.14);--bg:linear-gradient(135deg,#16213e,#1b2a4a);--details-bg:rgba(22,28,48,.97);background:var(--bg);border:1px solid var(--border);box-shadow:0 4px 18px rgba(10,15,40,.5)}
			.lwg-capsule.day{--fg:#1e2a3a;--dim:rgba(30,42,58,.52);--accent:#0a7ea4;--track:rgba(30,60,90,.14);--card:rgba(30,60,90,.06);--border:rgba(30,60,90,.16);--bg:linear-gradient(135deg,#ffffff,#e8f2ff);--details-bg:rgba(255,255,255,.98);box-shadow:0 4px 16px rgba(30,60,90,.18)}
			.lwg-capsule.night{--fg:#eaf2ff;--dim:rgba(234,242,255,.55);--accent:#9ad1ff;--track:rgba(255,255,255,.15);--card:rgba(255,255,255,.06);--border:rgba(140,180,255,.25);--bg:linear-gradient(135deg,#16213e,#1b2a4a);--details-bg:rgba(22,28,48,.97);box-shadow:0 4px 18px rgba(10,15,40,.55)}
			.lwg-capsule.dragging{cursor:grabbing;opacity:.9}
			.lwg-capsule.dead{animation:lwg-pulse 4s ease-in-out infinite}
			@keyframes lwg-pulse{0%,100%{box-shadow:0 0 0 0 rgba(255,82,82,.5)}50%{box-shadow:0 0 0 7px rgba(255,82,82,0)}}
			.lwg-capsule-icon{font-size:15px}
			.lwg-capsule-name{font-weight:700;white-space:nowrap;color:var(--fg)}
			.lwg-hpbar{width:72px;height:10px;border-radius:5px;background:var(--track);overflow:visible;position:relative;flex:none;transition:height .4s ease}
			.lwg-hpfill{display:block;height:100%;border-radius:5px;position:relative;overflow:hidden;transition:width .4s linear,background .4s linear}
			.lwg-hpnum{font-variant-numeric:tabular-nums;font-weight:700;min-width:18px;text-align:right;color:var(--fg)}
			.lwg-next{color:var(--dim);white-space:nowrap}
			.lwg-dn{font-size:11px;opacity:.95}

			.lwg-backdrop{position:fixed;inset:0;z-index:99997;background:transparent}
			.lwg-details{position:absolute;width:268px;background:var(--details-bg);border:1px solid var(--border);border-radius:14px;padding:12px;color:var(--fg);box-shadow:0 10px 30px rgba(0,0,0,.45);z-index:99999;pointer-events:auto;font-family:system-ui,-apple-system,'PingFang SC','Microsoft YaHei',sans-serif}
			.lwg-details-head{font-size:13px;font-weight:800;margin-bottom:8px;color:var(--accent)}
			.lwg-detail-card{display:flex;gap:10px;align-items:center;padding:10px;border-radius:10px;margin-bottom:10px;background:var(--card)}
			.lwg-detail-card.peak{background:rgba(255,82,82,.14)}
			.lwg-detail-card.countdown{background:rgba(255,179,0,.12)}
			.lwg-detail-card.valley{background:rgba(67,233,123,.10)}
			.lwg-detail-icon{font-size:26px}
			.lwg-detail-title{font-size:14px;font-weight:800;color:var(--fg)}
			.lwg-detail-sub{font-size:11px;color:var(--dim);margin-top:2px}
			.lwg-detail-hp{font-size:11px;margin-top:4px;color:var(--accent)}
			.lwg-detail-sec{margin-top:10px;border-top:1px solid var(--border);padding-top:8px}
			.lwg-detail-sec-title{font-size:11px;font-weight:700;color:var(--dim);margin-bottom:5px}
			.lwg-detail-text{font-size:11px;line-height:1.6;color:var(--fg);opacity:.85}
			.lwg-sched-row{display:flex;gap:8px;font-size:11px;padding:2px 0;color:var(--fg)}
			.lwg-sched-time{font-variant-numeric:tabular-nums;color:var(--accent);min-width:34px}
			.lwg-sched-past{opacity:.38}
			.lwg-sched-now{color:#43e97b;font-weight:800}
			.lwg-detail-close{margin-top:10px;text-align:center;font-size:11px;color:var(--dim);cursor:pointer;padding:6px;border-radius:8px}
			.lwg-detail-close:hover{background:var(--card);color:var(--fg)}
		`;

		// ---------- 右下角卡通弹窗（临时） ----------
		function Popup() {
			const [popup, setPopup] = React.useState(null);
			React.useEffect(() => subscribe(setPopup), []);
			React.useEffect(() => {
				if (popup === null) return;
				const t = window.setTimeout(() => setPopup(null), POPUP_MS);
				return () => window.clearTimeout(t);
			}, [popup]);
			if (popup === null) return null;
			const egg = !!popup.egg;
			const brk = !!popup.breakthru;
			const asc = !!popup.ascend;
			const extraCls = egg ? ' lwg-egg' : brk ? ' lwg-break' : asc ? ' lwg-ascend' : '';
			const bubbleCls = egg ? 'lwg-egg-bubble' : brk ? 'lwg-break-bubble' : asc ? 'lwg-ascend-bubble' : (popup.tone === 'warn' ? 'lwg-warn' : 'lwg-good');
			const avatarCls = 'lwg-avatar' + (egg ? ' lwg-avatar-egg' : brk ? ' lwg-avatar-break' : asc ? ' lwg-avatar-ascend' : '');
			return React.createElement('div', { className: 'lwg-popup' + extraCls, onClick: () => setPopup(null) },
				React.createElement('div', { className: 'lwg-bubble ' + bubbleCls },
					popup.lines.map((l, i) => React.createElement('div', { key: i, className: 'lwg-line' }, l)),
				),
				React.createElement('img', { className: avatarCls, src: CARTON_URL, alt: '梁文谷' }),
				React.createElement('div', { className: 'lwg-close' }, '✕'),
			);
		}

		// ---------- 右上角胶囊 HUD（可拖动 + 点击详情） ----------
		function Capsule() {
			const [pos, setPos] = React.useState(null);
			const [hpInfo, setHpInfo] = React.useState(() => hpAt(Date.now()));
			const [next, setNext] = React.useState(() => nextEvent(Date.now()));
			const [open, setOpen] = React.useState(false);
			const [dragging, setDragging] = React.useState(false);
			const [steam, setSteam] = React.useState(false);
			const dragRef = React.useRef(null);
			const posRef = React.useRef(null);
			const prevPhaseRef = React.useRef(hpAt(Date.now()).phase);
			const steamTimerRef = React.useRef(null);

			React.useEffect(() => {
				try {
					const saved = JSON.parse(window.localStorage.getItem(POS_KEY) || 'null');
					if (saved && typeof saved.x === 'number' && typeof saved.y === 'number') { setPos(saved); posRef.current = saved; }
				} catch {}
			}, []);
			React.useEffect(() => {
				const iv = window.setInterval(() => {
					const now = Date.now();
					const nxt = hpAt(now);
					const prev = prevPhaseRef.current;
					// 相位转换：峰/倒计时 → 谷（12:00/18:00 峰走）触发蒸汽喷发
					if (nxt.phase !== prev) {
						if (nxt.phase === 'valley' && (prev === 'peak' || prev === 'countdown')) {
							setSteam(true);
							if (steamTimerRef.current) window.clearTimeout(steamTimerRef.current);
							steamTimerRef.current = window.setTimeout(() => setSteam(false), 2600);
						}
						prevPhaseRef.current = nxt.phase;
					}
					setHpInfo(nxt);
					setNext(nextEvent(now));
				}, HUD_MS);
				return () => window.clearInterval(iv);
			}, []);
			React.useEffect(() => () => { if (steamTimerRef.current) window.clearTimeout(steamTimerRef.current); }, []);

			const onPointerDown = (e) => {
				if (e.button !== 0 && e.pointerType === 'mouse') return;
				const rect = e.currentTarget.getBoundingClientRect();
				dragRef.current = { startX: e.clientX, startY: e.clientY, baseX: pos ? pos.x : rect.left, baseY: pos ? pos.y : rect.top, moved: false };
				try { e.currentTarget.setPointerCapture(e.pointerId); } catch {}
			};
			const onPointerMove = (e) => {
				const ds = dragRef.current;
				if (!ds) return;
				const dx = e.clientX - ds.startX; const dy = e.clientY - ds.startY;
				if (!ds.moved && Math.abs(dx) + Math.abs(dy) > 6) ds.moved = true;
				if (ds.moved) {
					setDragging(true);
					const nx = Math.max(4, Math.min(window.innerWidth - 8, ds.baseX + dx));
					const ny = Math.max(4, Math.min(window.innerHeight - 8, ds.baseY + dy));
					posRef.current = { x: nx, y: ny };
					setPos(posRef.current);
				}
			};
			const onPointerUp = () => {
				const ds = dragRef.current;
				dragRef.current = null;
				if (ds && !ds.moved) { setOpen((v) => !v); return; }
				if (ds && ds.moved && posRef.current) {
					try { window.localStorage.setItem(POS_KEY, JSON.stringify(posRef.current)); } catch {}
				}
				setDragging(false);
			};

			const dn = dayNightAt(Date.now());
			const realm = realmOf(CULT.xp);
			const cardCls = 'lwg-detail-card ' + hpInfo.phase;
			const capsuleCls = 'lwg-capsule ' + dn + (dragging ? ' dragging' : '') + (hpInfo.phase === 'peak' && hpInfo.hp < 30 ? ' dead' : '');
			const flipUp = pos && pos.y > window.innerHeight * 0.55;
			const style = pos ? { left: pos.x, top: pos.y } : { right: 16, top: 64 };
			const detailStyle = flipUp ? { bottom: 'calc(100% + 8px)', right: 0 } : { top: 'calc(100% + 8px)', right: 0 };

			// 血条煮水：宽度=血量，颜色/气泡=水温（boil 0→100），谷启动蒸汽喷发
			const boil = hpInfo.phase === 'peak' ? 100 : hpInfo.phase === 'countdown' ? Math.max(0, Math.min(100, 100 - hpInfo.hp)) : 0;
			const waterBg = boil > 75 ? 'linear-gradient(90deg,rgba(232,242,255,.95),rgba(184,218,255,.95))' : boil > 40 ? 'linear-gradient(90deg,rgba(160,205,255,.95),rgba(110,170,240,.95))' : boil > 0 ? 'linear-gradient(90deg,rgba(120,180,255,.9),rgba(60,120,220,.9))' : hpColor(hpInfo.hp);
			const bubbleCount = boil < 35 ? 0 : boil < 65 ? 3 : 6;
			const bubs = [];
			for (let i = 0; i < bubbleCount; i++) {
				const c = BUBBLE_CFGS[i];
				bubs.push(React.createElement('span', { key: 'b' + i, className: 'lwg-bub', style: { left: c.left + '%', animationDelay: c.delay + 's', animationDuration: c.dur + 's', width: c.w + 'px', height: c.h + 'px' } }));
			}
			const puffs = [];
			if (steam) { for (let i = 0; i < 3; i++) puffs.push(React.createElement('span', { key: 'p' + i, className: 'lwg-puff lwg-puff-big', style: { left: (22 + i * 26) + '%', animationDelay: (i * 0.3) + 's' } })); }
			else if (hpInfo.phase === 'peak') { for (let i = 0; i < 2; i++) puffs.push(React.createElement('span', { key: 'p' + i, className: 'lwg-puff', style: { left: (28 + i * 40) + '%', animationDelay: (i * 1.2) + 's' } })); }

			return React.createElement(React.Fragment, null,
				React.createElement('div', { className: 'lwg-fog', style: { opacity: fogOpacity(hpInfo.hp, hpInfo.phase) } }),
				open && React.createElement('div', { className: 'lwg-backdrop', onPointerDown: () => setOpen(false) }),
				React.createElement('div', { className: capsuleCls, style: style, onPointerDown, onPointerMove, onPointerUp },
					React.createElement('span', { className: 'lwg-capsule-icon' }, ICONS[hpInfo.phase]),
					React.createElement('span', { className: 'lwg-capsule-name' }, LABELS[hpInfo.phase]),
					React.createElement('span', { className: 'lwg-realm', title: '修仙境界' }, '·' + realm.icon + realm.name),
					React.createElement('span', { className: 'lwg-dn' }, dn === 'day' ? '☀️' : '🌙'),
					React.createElement('span', { className: 'lwg-hpbar' + (boil > 0 ? ' water' : '') },
						React.createElement('span', { className: 'lwg-hpfill', style: { width: hpInfo.hp + '%', background: waterBg } }, bubs),
						puffs,
					),
					React.createElement('span', { className: 'lwg-hpnum', style: hpInfo.hp < 20 ? { color: '#ff5252' } : null }, String(hpInfo.hp)),
					React.createElement('span', { className: 'lwg-next' }, next.at + ' ' + next.label),
					open && React.createElement('div', { className: 'lwg-details', style: detailStyle, onClick: (e) => e.stopPropagation() },
						React.createElement('div', { className: 'lwg-details-head' }, '梁文谷 · 实时状态 · ' + (dn === 'day' ? '☀️ 白天' : '🌙 月夜')),
						React.createElement('div', { className: cardCls },
							React.createElement('div', { className: 'lwg-detail-icon' }, ICONS[hpInfo.phase]),
							React.createElement('div', null,
								React.createElement('div', { className: 'lwg-detail-title' }, LABELS[hpInfo.phase]),
								React.createElement('div', { className: 'lwg-detail-sub' }, MEANINGS[hpInfo.phase]),
								React.createElement('div', { className: 'lwg-detail-hp' }, 'HP ' + hpInfo.hp + '/100 · 下一事件 ' + next.at + ' ' + next.label),
							),
						),
						React.createElement('div', { className: 'lwg-detail-sec' },
							React.createElement('div', { className: 'lwg-detail-sec-title' }, '今日时间表（北京时间）'),
							todaySchedule(Date.now()).map((s) => React.createElement('div', { key: s.key, className: 'lwg-sched-row' + (s.past ? ' lwg-sched-past' : '') + (s.now ? ' lwg-sched-now' : '') },
								React.createElement('span', { className: 'lwg-sched-time' }, s.at),
								React.createElement('span', null, s.label),
							)),
						),
						React.createElement('div', { className: 'lwg-detail-sec' },
							React.createElement('div', { className: 'lwg-detail-sec-title' }, '生命值规则'),
							React.createElement('div', { className: 'lwg-detail-text' },
								'谷中满血 100 · 倒计时掉血（距峰 30 分→70 / 20 分→40 / 10 分→10）· 峰中回血爬升（距峰走越近血越多，18:00 满血）· 峰走回满。',
							),
						),
						React.createElement('div', { className: 'lwg-detail-sec' },
							React.createElement('div', { className: 'lwg-detail-sec-title' }, '修为 · ' + realm.icon + ' ' + realm.name + (realm.next ? '（距' + realm.next + '还需 ' + (realm.into - realm.done) + '）' : '（已飞升）')),
							React.createElement('span', { className: 'lwg-xpbar' },
								React.createElement('span', { className: 'lwg-xpfill', style: { width: Math.round((realm.done / realm.into) * 100) + '%' } }),
							),
							React.createElement('div', { className: 'lwg-detail-text' },
								'境界内修为 ' + realm.done + '/' + realm.into + ' · 总修为 ' + realm.total +
								' · 渡劫今日 ' + (CULT.tribDate === dateKey(Date.now()) ? CULT.tribCount : 0) + '/2 · 闭关 ' + Math.floor(CULT.seclusionSec / 60) + ' 分钟',
							),
						),
						React.createElement('div', { className: 'lwg-detail-sec' },
							React.createElement('div', { className: 'lwg-detail-sec-title' }, '今日播报（' + todayLog().length + ' 次）'),
							todayLog().length === 0
								? React.createElement('div', { className: 'lwg-detail-text' }, '今天还没喊过，谷中岁月静好')
								: todayLog().slice(-6).reverse().map((l, i) => React.createElement('div', { key: i, className: 'lwg-sched-row' },
									React.createElement('span', { className: 'lwg-sched-time' }, l.at),
									React.createElement('span', null, l.label),
								)),
						),
						React.createElement('div', { className: 'lwg-detail-close', onClick: () => setOpen(false) }, '✕ 关闭'),
					),
				),
			);
		}

		function apply(ctx) {
			// 样式
			ctx.effect(() => {
				const styleEl = document.createElement('style');
				styleEl.setAttribute('data-lwg', '');
				styleEl.textContent = CSS;
				document.head.appendChild(styleEl);
				return () => { try { styleEl.remove(); } catch {} };
			}, 'liangwengu: styles');
			// 注册胶囊 + 弹窗到 shell.overlay 槽位（0.1.2 须在 slots 就绪后注入）。
			// 用 ctx.get('slots') 一次判定可能因时序拿到 undefined，改用 slots.inject 延迟注册。
			const slots = ctx.get('slots');
			if (slots !== undefined) {
				slots.inject('shell.overlay', () => slots.register(
					{ name: 'shell.overlay', id: 'liangwengu' },
					() => React.createElement(React.Fragment, null,
						React.createElement(Capsule),
						React.createElement(Popup),
					),
				));
			} else {
				// 兜底：slots 尚未就绪则退化为仅调度器（无胶囊 UI，通知/弹窗仍可用）。
				ctx.effect(() => {
					const iv = window.setInterval(tick, TICK_MS);
					const t = window.setTimeout(onLoad, 2000);
					const onVis = () => { if (document.visibilityState === 'visible') tick(); };
					document.addEventListener('visibilitychange', onVis);
					return () => { window.clearInterval(iv); window.clearTimeout(t); document.removeEventListener('visibilitychange', onVis); };
				}, 'liangwengu: scheduler (fallback)');
				return;
			}

			// 调度器：到点触发 + 开页补播/阶段播报 + 前台切回补扫
			ctx.effect(() => {
				const iv = window.setInterval(tick, TICK_MS);
				const t = window.setTimeout(onLoad, 2000);
				const onVis = () => { if (document.visibilityState === 'visible') tick(); };
				document.addEventListener('visibilitychange', onVis);
				return () => { window.clearInterval(iv); window.clearTimeout(t); document.removeEventListener('visibilitychange', onVis); };
			}, 'liangwengu: scheduler');

			// 调试钩子：window.__lwgTest('warn' | 'good' | 'cd' | 'egg' | 'phase')
			try {
				window.__lwgTest = (kind) => {
					if (kind === 'warn') showPopup({ id: 'dbg-' + Date.now(), tone: 'warn', lines: ['梁文峰要来了，块跑啊！'] });
					else if (kind === 'good') showPopup({ id: 'dbg-' + Date.now(), tone: 'good', lines: ['乡亲们，梁文峰走了！！可以出来了！', '梁文谷 启动~~~'] });
					else if (kind === 'cd') showPopup({ id: 'dbg-' + Date.now(), tone: 'warn', lines: ['还有 10 分钟！梁文峰快到了，快找地方躲！！'] });
					else if (kind === 'egg') showPopup({ id: 'dbg-' + Date.now(), tone: 'good', egg: true, lines: ['梁文峰路过你工位，你屏住了呼吸'] });
					else firePhase(Date.now());
				};
			} catch {}
		}

		exports.apply = apply;
		// 0.1.2:声明 slots 硬依赖，Cordis 保证 apply 在 slots 服务就绪后执行，
		// 避免原先 ctx.get('slots') 一次判定因时序拿到 undefined 而走 fallback 丢胶囊。
		exports.inject = ['slots'];
		return module.exports;
	}
});
