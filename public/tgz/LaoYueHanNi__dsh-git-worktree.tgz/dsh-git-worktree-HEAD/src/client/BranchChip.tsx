/**
 * BranchChipDock: the composer tool-row entry (conversation.input.left, right
 * of the mode chips) for sessions inside a git repository. Blank sessions
 * OF THE MAIN checkout get the full segmented control — branch picker plus
 * the worktree isolation toggle — because that is the moment to choose the
 * environment for the conversation, and starting a worktree is a main-repo
 * decision. Once the session starts, the worktree toggle is withdrawn (its
 * directory is fixed). A session inside a LINKED worktree scopes the entry
 * down to TWO things, blank or started alike: the branch this worktree
 * holds (the position marker, trailing check included) and the 「工作树」
 * group of every OTHER worktree — the main checkout included, since from
 * in here that is another place to go — whose rows carry the hop. The
 * directory's identity IS its branch, so every other BRANCH would be a row
 * the owner must refuse — a menu of refusals is not a menu (the same
 * judgement that removed the toggle and the in-place new-branch tool here).
 * A worktree row is different in kind: hopping there registers that folder
 * and opens a fresh session, touching no checkout, so it stays legal here —
 * and it is the one action a linked-worktree session most needs, since
 * moving between worktrees is the point of having them. What also stays is
 * the two tools that never move a checkout: fetch, and update-current — the
 * update fast-forwards the session's OWN worktree, the fetch is
 * repository-wide metadata. Both run as jobs in ./sync-job.ts and show a
 * floating, non-modal progress card with a cancel button (./SyncProgress.tsx).
 * Non-git directories and load failures render nothing. The confirm dialogs
 * and the error toast live here too.
 *
 * Checking the worktree toggle pops the cutout confirm dialog right away:
 * confirming it cuts a NEW branch (`<current>-wt`, suffixes past taken
 * names) out of the current checkout into a fresh isolated worktree — the
 * current branch itself is occupied by the main worktree, so git refuses a
 * second worktree on it. The dialog stands alone above the chip (the
 * branch menu stays closed); the chip still opens the menu, where picking
 * another branch keeps the plain create-or-reuse flow and re-picking the
 * current branch stages the same cutout confirm. Dismissing the dialog and
 * sending the message anyway means the user knowingly stays in the current
 * directory — no separate notice fires on send.
 *
 * In-place branch creation (the menu toolbar's plus, worktree mode off)
 * opens the create flyout right of the branch card: type the name, press
 * Create — the new branch is cut from the session directory's current
 * checkout and checked out there in one stroke, the worktree-less sibling
 * of the cutout flow. A failure toasts and leaves the flyout open.
 *
 * Remote branches join the picker under their own menu group: picking one
 * stages the remote-twin confirm — the switch creates the local tracking
 * branch in place (git's dwim), the worktree pick creates the twin inside
 * its fresh worktree. Both rides go through the existing /switch and
 * /worktree routes, which already resolve `<remote>/name` display names.
 *
 * Worktrees get their own 「工作树」 group, listing every worktree but the
 * one the session sits in: the row menu's 「跳到此工作树」 registers that
 * directory and opens a blank session in it (adoptWorktree; no git action,
 * no confirm), and its 「删除工作树」 rides the shared removal flow behind
 * a fact-spelling confirm (uncommitted count, ahead commits, sessions to
 * be archived — the branch itself survives; a directory holding a running
 * session withholds the verb). On the main checkout's BLANK session the
 * group doubles as
 * the only way to reach a branch held by a worktree — those have left the
 * local group (git refuses to check them out twice, so a local-group row
 * would be a dead end). A linked-worktree session keeps that group and
 * gains the main checkout row (see {@link buildLinkedWorktreeRows}); a
 * started MAIN-checkout session drops the group — its directory is fixed.
 */

import { useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState, type CSSProperties } from 'react'
import { createPortal } from 'react-dom'
import {
  Button, IconBranchOutlineRegular, Toast,
} from '@deepseek-ai/dsh-client-ui-primitives'
import type { PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots'
// Type-only: merges SessionStandardProps / GlobalStandardProps (`sessionId`,
// `useSessions`) into the input-left runtime kit.
import type {} from '@deepseek-ai/dsh-client-ui-session/client'
import { branchNameIssue, localBranchName } from '../normalize.ts'
import type { BranchEntry, PushBody, RepoStatus, WorktreeEntry } from '../wire.ts'
import { fetchStatus, requestCreateBranch, requestDeleteBranch, requestFetch, requestInspectWorktree, requestPush, requestRenameBranch, requestSwitch, requestUpdate, requestWorktree, requestWorktreeCutout } from './api.ts'
import { subscribeCheckedOutBranch } from './head-poll.ts'
import { PushDialog } from './PushDialog.tsx'
import { BranchMenu, type BranchRow } from './BranchMenu.tsx'
import { repoHasRemotes } from './branch-tree.ts'
import type { BranchChipInjected } from './slots.ts'
import { cancelSyncJob, findSyncJob, recordPushFailure, runSyncJob, subscribeSyncJobs, takePushFailure, type PushFailure, type SyncJob } from './sync-job.ts'
import { explainUpdateFailure, updateErrorText, type UpdateFailureKind } from './update-error.ts'
import { SyncProgress } from './SyncProgress.tsx'
import css from './BranchChip.module.css'
import type { GitWorktreeKey } from './locales.ts'

/** The toast for an update failure the plugin can name. Each one says what
 * to do next; git's hint essay is not part of it. */
const UPDATE_FAIL = {
  diverged: 'updateFailDiverged',
  dirty: 'updateFailDirty',
  noUpstream: 'updateFailNoUpstream',
} as const satisfies Record<UpdateFailureKind, GitWorktreeKey>

/** Full props: owner share + standard kit + injected adopt verb + locale seat. */
export type BranchChipDockProps =
  PropsRuntime<'conversation.input.left'>
  & BranchChipInjected
  & PropsLocale<'git-worktree'>

/** Status fetch lifecycle: `null` facts until ready; failures park unloaded. */
interface StatusState {
  facts: (RepoStatus & { repo: true }) | null
}

/** One pending confirm dialog. Switches are NOT here — 签出 runs directly
 * (keep-open, no confirmation step); the confirms left are the ones with
 * real consequences to spell out or inputs to carry. */
interface ConfirmState {
  kind: 'worktree' | 'worktree-cutout' | 'delete' | 'remove-worktree'
  branch: string
  /** True when `branch` names a REMOTE branch (an `origin/feat-x` row):
   * the worktree confirm creates the twin plus its worktree — the ask line
   * spells that out instead of reading as a plain reuse. */
  remote?: boolean
  /** Editable cutout name (kind `worktree-cutout` only): starts EMPTY —
   * the user types the new branch name themselves (the auto `<branch>-wt`
   * prefill is gone), confirm disables until the draft is valid. */
  draft?: string
  /** The removal target directory (kind `remove-worktree` only): the row
   * menu hands it over with the branch; the dialog's details and the
   * eventual removal both act on it, not on `branch`. */
  path?: string
}

/** The inspect half of one staged removal (kind `remove-worktree` only):
 * `undefined` while the probe is in flight, `null` after it failed — the
 * dialog still works (git itself refuses a dirty non-forced removal), just
 * without the fact lines. */
type RemovalFacts = { dirty: number; ahead?: number } | null | undefined

/**
 * Read the repository status for a directory; refetch on demand.
 * @param cwd - absolute session directory.
 * @returns the state holder and a refetch verb.
 */
function useRepoStatus(cwd: string | undefined): readonly [StatusState, () => Promise<void>] {
  const [state, setState] = useState<StatusState>({ facts: null })
  // Mount, focus, and the HEAD poll can be in flight together. A slower
  // older response must not paint over a newer one.
  const gen = useRef(0)
  const load = useCallback(async (): Promise<void> => {
    const ticket = ++gen.current
    if (cwd === undefined) {
      setState({ facts: null })
      return
    }
    const result = await fetchStatus(cwd)
    // A transient failure must not remove the label and its HEAD subscription.
    // Keep the last successful facts so the next tick can retry the change.
    if (ticket !== gen.current || !result.ok) return
    setState({ facts: result.repo ? result : null })
  }, [cwd])
  useEffect(() => {
    const ticket = ++gen.current
    let live = true
    setState({ facts: null })
    if (cwd !== undefined) {
      void fetchStatus(cwd).then(result => {
        if (live && ticket === gen.current) setState({ facts: result.ok && result.repo ? result : null })
      })
    }
    return () => { live = false }
  }, [cwd])
  return [state, load]
}

/**
 * The fetch/update running for a directory, live. The job store outlives
 * this component (switching sessions unmounts the dock, a long transfer does
 * not stop), so the hook reads the store at render time — a held copy could
 * lag a render behind a directory change — and only subscribes to learn WHEN
 * to re-render.
 * @param cwd - absolute session directory.
 * @returns the running job, or undefined.
 */
function useSyncJob(cwd: string | undefined): SyncJob | undefined {
  const [, redraw] = useState(0)
  useEffect(() => subscribeSyncJobs(() => { redraw(tick => tick + 1) }), [])
  return findSyncJob(cwd)
}

/** Longest branch name shown on the chip before ellipsizing (chars, … included). */
const BRANCH_DISPLAY_MAX = 25

/** Viewport edge clearance and chip gap, mirroring BranchMenu's posture. */
const POP_MARGIN = 12
const POP_GAP = 6
/** Unplaced dialog: hidden but laid out at a fixed origin so offsetWidth is
 * real for the measure-then-place pass (BranchMenu's flyout trick). */
const POP_MEASURE: CSSProperties = { left: '-9999px', bottom: '0px', visibility: 'hidden' }

/**
 * Clamp a branch name for chip display: names up to 25 chars pass through;
 * longer ones show the first 24 chars plus an ellipsis.
 * @param branch - full branch name.
 */
function displayBranch(branch: string): string {
  return branch.length <= BRANCH_DISPLAY_MAX ? branch : `${branch.slice(0, BRANCH_DISPLAY_MAX - 1)}…`
}

/**
 * Build the branch rows for the picker on the MAIN checkout, in three
 * kinds: LOCAL branches not held by a linked worktree, REMOTE branches,
 * and one WORKTREE row per linked worktree. A branch held by a worktree
 * LEAVES the local group — git refuses to check it out twice, so the row
 * would be a dead end; the worktree group is the way INTO it instead (a
 * direct session hop, see the owner's onAdoptWorktree).
 *
 * The worktree group is "every worktree EXCEPT the one this session sits
 * in" — here that is the main checkout itself (the session IS the main
 * checkout), so `w.main` drops out: hopping home is not a hop. A detached
 * worktree drops out too — it has no branch name to show or hop by.
 * (Linked-worktree sessions express the same rule from the other side, and
 * therefore DO list the main checkout: see
 * {@link buildLinkedWorktreeRows}.)
 *
 * Only the MAIN checkout's sessions call this: a linked-worktree session
 * renders its own pair of rows instead (see
 * {@link buildLinkedWorktreeRows}), so nothing here ever has to express
 * "not usable in this directory".
 */
export function buildBranchRows(
  branches: readonly BranchEntry[],
  worktrees: readonly WorktreeEntry[],
): BranchRow[] {
  const held = new Set(worktrees.flatMap(w => w.main || w.branch === undefined ? [] : [w.branch]))
  const localMap = new Map(branches.filter(b => b.kind === 'local').map(b => [b.name, b]))
  return [
    ...branches.filter(b => b.kind === 'local' && !held.has(b.name)).map(b => ({
      name: b.name,
      kind: 'local' as const,
      ...b.ahead === undefined ? {} : { ahead: b.ahead },
      ...b.behind === undefined ? {} : { behind: b.behind },
      ...b.upstream === undefined ? {} : { upstream: b.upstream },
      ...b.upstreamGone === undefined ? {} : { upstreamGone: b.upstreamGone },
    })),
    ...branches.filter(b => b.kind === 'remote').map(b => ({
      name: b.name,
      kind: 'remote' as const,
    })),
    ...worktrees.flatMap(w => {
      if (w.main || w.branch === undefined) return []
      const twin = localMap.get(w.branch)
      return [{
        name: w.branch,
        kind: 'worktree' as const,
        path: w.path,
        ...twin?.ahead === undefined ? {} : { ahead: twin.ahead },
        ...twin?.behind === undefined ? {} : { behind: twin.behind },
        ...twin?.upstream === undefined ? {} : { upstream: twin.upstream },
        ...twin?.upstreamGone === undefined ? {} : { upstreamGone: twin.upstreamGone },
      }]
    }),
  ]
}

/**
 * Build the rows for a LINKED-worktree session: the branch this worktree
 * holds, plus one row per OTHER worktree of the repository.
 *
 * The worktree rows are here for the HOP: 「跳到此工作树」 registers that
 * directory and opens a blank session in it (`adoptWorktree`) — a
 * session-level jump that never touches a checkout, so a linked-worktree
 * session can offer it on the same terms the main checkout's blank session
 * does. Hopping between worktrees is the whole point of having them.
 *
 * The exclusion is the SAME rule as {@link buildBranchRows} states from the
 * main checkout's side — "every worktree except the one you are in" — which
 * here means excluding by BRANCH (`w.branch === currentBranch`) rather than
 * by `w.main`. The main checkout therefore STAYS in the list: from inside a
 * linked worktree it is exactly the other place you want to go, and unlike
 * the worktree you are sitting in, its row is not a hop to where you
 * already are. Detached worktrees still drop out (no branch name to show),
 * as does this session's own worktree (it already owns the local row above,
 * which carries the trailing check as the "you are here" mark).
 *
 * What stays absent is every OTHER branch, local or remote: the directory's
 * identity is its branch, so those rows could only ever be offered as
 * refusals (see the component doc).
 */
export function buildLinkedWorktreeRows(
  branches: readonly BranchEntry[],
  worktrees: readonly WorktreeEntry[],
  currentBranch: string,
): BranchRow[] {
  const current = branches.find(b => b.kind === 'local' && b.name === currentBranch)
  const localMap = new Map(branches.filter(b => b.kind === 'local').map(b => [b.name, b]))
  return [
    ...current === undefined
      ? []
      : [{
          name: current.name,
          kind: 'local' as const,
          ...current.ahead === undefined ? {} : { ahead: current.ahead },
          ...current.behind === undefined ? {} : { behind: current.behind },
          ...current.upstream === undefined ? {} : { upstream: current.upstream },
          ...current.upstreamGone === undefined ? {} : { upstreamGone: current.upstreamGone },
        }],
    // The main checkout is NOT filtered out here: it is another place to go.
    // Its row carries `mainWorktree` — the hop is legal, but git refuses
    // `worktree remove` on the main checkout, so the destructive menu verb
    // gates off this flag.
    ...worktrees.flatMap(w => {
      if (w.branch === undefined || w.branch === currentBranch) return []
      const twin = localMap.get(w.branch)
      return [{
        name: w.branch,
        kind: 'worktree' as const,
        path: w.path,
        ...(w.main ? { mainWorktree: true } : {}),
        ...twin?.ahead === undefined ? {} : { ahead: twin.ahead },
        ...twin?.behind === undefined ? {} : { behind: twin.behind },
        ...twin?.upstream === undefined ? {} : { upstream: twin.upstream },
        ...twin?.upstreamGone === undefined ? {} : { upstreamGone: twin.upstreamGone },
      }]
    }),
  ]
}

/** The standalone confirm dialog shown while the branch menu is closed. */
interface ChipConfirmProps {
  /** The chip element — the dialog's bottom edge pins just above its top. */
  anchorRef: React.RefObject<HTMLElement | null>
  /** Ask line (already localized). */
  ask: string
  /** The branch the ask refers to, on its own weight-500 line (remote picks
   * only — the ask line says "该远程分支" and this names it). */
  subject?: string
  /** Consequence lines under the ask (see BranchConfirmFly.details). */
  details?: React.ReactNode
  /** Confirm-button label (progress text while busy). */
  confirmLabel: string
  /** Cancel-button label. */
  cancelLabel: string
  /** True while the action runs: both buttons disable. */
  busy: boolean
  /** Editable new-branch name (cutout flow): present, the dialog renders a
   * naming input under the ask line and focuses IT instead of the confirm
   * button; Enter commits a valid draft. */
  draft?: string
  onDraftChange?: (value: string) => void
  draftPlaceholder?: string
  /** True while the draft is NOT an acceptable new branch name — the
   * confirm button disables in lockstep. */
  draftInvalid?: boolean
  /** Why the draft is invalid (rendered under the input; absent while the
   * draft is acceptable or merely empty). */
  draftHint?: string
  /** Run the confirmed action. */
  onConfirm: () => void
  /** Dismiss the dialog without acting. */
  onCancel: () => void
}

/**
 * The check-time confirm dialog, rendered while the branch menu is closed:
 * the same popCard chrome as BranchMenu's flyout, but bottom-pinned above
 * the chip in the menu card's posture — the flyout's right-of-card anchor
 * has no card to sit beside here. Outside pointerdown and Escape cancel;
 * the naming input (cutout flow) takes focus when present, else the
 * confirm button does so Enter commits.
 */
function ChipConfirm({
  anchorRef, ask, subject, details, confirmLabel, cancelLabel, busy,
  draft, onDraftChange, draftPlaceholder, draftInvalid, draftHint,
  onConfirm, onCancel,
}: ChipConfirmProps) {
  const popRef = useRef<HTMLDivElement>(null)
  const confirmRef = useRef<HTMLButtonElement | null>(null)
  const draftInputRef = useRef<HTMLInputElement | null>(null)
  const [pos, setPos] = useState<{ left: number; bottom: number } | null>(null)

  // Bottom-pin above the chip and clamp horizontally against the measured,
  // content-driven width (popCard is max-content under an 80vw cap).
  useLayoutEffect(() => {
    const place = (): void => {
      const anchor = anchorRef.current
      const pop = popRef.current
      if (anchor === null || pop === null) return
      const rect = anchor.getBoundingClientRect()
      const vw = window.innerWidth
      const vh = window.innerHeight
      const left = Math.min(Math.max(rect.left, POP_MARGIN), Math.max(POP_MARGIN, vw - POP_MARGIN - pop.offsetWidth))
      setPos({ left, bottom: vh - rect.top + POP_GAP })
    }
    place()
    window.addEventListener('resize', place)
    window.addEventListener('scroll', place, true)
    return () => {
      window.removeEventListener('resize', place)
      window.removeEventListener('scroll', place, true)
    }
  }, [anchorRef])

  // Focus rides a rAF: the first frame lays the dialog out in the hidden
  // measure-then-place posture, and focus() on a visibility:hidden node
  // no-ops — one frame later the placed dialog is visible and the focus
  // lands. The naming input wins when present (typing is the point).
  useEffect(() => {
    const raf = requestAnimationFrame(() => { (draftInputRef.current ?? confirmRef.current)?.focus() })
    return () => { cancelAnimationFrame(raf) }
  }, [])

  // Outside pointerdown cancels (the dialog and the chip excluded — the
  // chip click runs its own toggle); Escape unwinds the dialog.
  useEffect(() => {
    const onPointerDown = (event: PointerEvent): void => {
      if (popRef.current?.contains(event.target as Node) === true) return
      if (anchorRef.current?.contains(event.target as Node) === true) return
      onCancel()
    }
    const onKeyDown = (event: KeyboardEvent): void => {
      if (event.key === 'Escape') onCancel()
    }
    document.addEventListener('pointerdown', onPointerDown, true)
    document.addEventListener('keydown', onKeyDown)
    return () => {
      document.removeEventListener('pointerdown', onPointerDown, true)
      document.removeEventListener('keydown', onKeyDown)
    }
  }, [onCancel, anchorRef])

  return createPortal(
    <div ref={popRef} className={css.popCard} style={pos ?? POP_MEASURE} role="dialog" aria-label={ask}>
      <p className={css.popAsk}>{ask}</p>
      {subject !== undefined && <p className={css.popSubject}>{subject}</p>}
      {details !== undefined && <div className={css.popDetails}>{details}</div>}
      {onDraftChange !== undefined && (
        <>
          <input
            ref={draftInputRef}
            className={css.menuCreate}
            type="text"
            value={draft}
            placeholder={draftPlaceholder}
            aria-label={draftPlaceholder}
            aria-invalid={draftInvalid}
            spellCheck={false}
            disabled={busy}
            onChange={event => { onDraftChange(event.target.value) }}
            onKeyDown={event => {
              if (event.key === 'Enter' && draftInvalid !== true && !busy) {
                event.preventDefault()
                onConfirm()
              }
            }}
          />
          {draftInvalid === true && draftHint !== undefined && (
            <p className={css.menuCreateHintBad} role="status">{draftHint}</p>
          )}
        </>
      )}
      <div className={css.popActions}>
        <button type="button" disabled={busy} onClick={onCancel}>
          {cancelLabel}
        </button>
        <button
          ref={confirmRef}
          type="button"
          disabled={busy || draftInvalid === true}
          onClick={onConfirm}
        >
          {confirmLabel}
        </button>
      </div>
    </div>,
    document.body,
  )
}

/** The tool-row entry registered into conversation.input.left. */
export function BranchChipDock({ sessionId, useSessions, useSession, adoptWorktree, describeWorktreeRemoval, removeWorktree, pruneWorktrees, t }: BranchChipDockProps) {
  const summary = useSessions(state => state.byId[sessionId])
  const session = useSession(s => s)
  const cwd = summary?.cwd
  const [repo, refresh] = useRepoStatus(cwd)
  const syncJob = useSyncJob(cwd)
  const [menuOpen, setMenuOpen] = useState(false)
  const [confirm, setConfirm] = useState<ConfirmState | null>(null)
  const [pushBranch, setPushBranch] = useState<string | null>(null)
  /** Set when the push window is coming back after a failed push. */
  const [pushResume, setPushResume] = useState<PushFailure | undefined>(undefined)
  const [busy, setBusy] = useState(false)
  /** Inspect facts of the staged worktree removal, keyed to its directory:
   * a confirm staged for one path never shows another's facts, and a restage
   * while a probe is in flight keeps showing the new path's loading line. */
  const [removalPath, setRemovalPath] = useState<string | null>(null)
  const [removalFacts, setRemovalFacts] = useState<RemovalFacts>(undefined)
  /** Toasts wait their turn instead of overwriting each other. One flow
   * can raise two in a row — a worktree creation whose fetch warned, then
   * the auto-prune's report — and a single-slot state made the second
   * silently erase the first before anyone read it. Head renders, `onDone`
   * shifts. */
  const [toasts, setToasts] = useState<readonly { seq: number; text: string }[]>([])
  const toastSeq = useRef(0)
  const pushToast = useCallback((text: string) => {
    toastSeq.current += 1
    const seq = toastSeq.current
    setToasts(queue => [...queue, { seq, text }])
  }, [])
  const chipRef = useRef<HTMLButtonElement | null>(null)
  const busyRef = useRef(false)
  const currentCwdRef = useRef(cwd)
  currentCwdRef.current = cwd
  /** Is something already running that another git action must not overlap:
   * one of this dock's own actions, or a fetch/update the job store holds for
   * this directory (it outlives the dock, so a remounted dock still sees it). */
  const blocked = useCallback((): boolean => busyRef.current || findSyncJob(currentCwdRef.current) !== undefined, [])
  /** Branch the label is showing. The poll compares against this and does
   * not refetch while it is still empty (the mount fetch owns that). */
  const shownBranchRef = useRef<string | undefined>(undefined)
  shownBranchRef.current = repo.facts?.currentBranch
  /** One poll-triggered status fetch at a time. Focus and menu opens do not
   * take this flag; the generation in useRepoStatus orders those bodies. */
  const pollRefreshRef = useRef(false)

  useEffect(() => {
    // A moved session directory means a new repository context: any
    // half-open dialog belongs to the old one.
    setConfirm(null)
    setPushBranch(null)
    setPushResume(undefined)
    setMenuOpen(false)
  }, [cwd])

  useEffect(() => {
    // A push runs behind its card, with its window already closed. When it
    // fails, the window comes back with git's reason — here, or when the user
    // returns to a session whose dock was gone by then. (Declared after the
    // reset above, so a failure waiting at mount survives it.)
    const reopen = (): void => {
      const failure = takePushFailure(cwd)
      if (failure === undefined) return
      setConfirm(null)
      setMenuOpen(false)
      setPushResume(failure)
      setPushBranch(failure.branch)
    }
    reopen()
    return subscribeSyncJobs(reopen)
  }, [cwd])

  useEffect(() => {
    // The session started: the environment is fixed now, so a dialog staged
    // during the blank phase (a cutout or delete confirm) must not survive
    // into it — a keyboard-only send (no outside pointerdown to dismiss it)
    // can start the session while the dialog still floats. (Switches stage
    // no dialog — 签出 runs directly.)
    if (!session.blank) {
      setConfirm(null)
    }
  }, [session.blank])

  // External checkouts never notify this label. Focus and visibility cover
  // leaving the window and coming back; opening the menu refetches rows at
  // decision time. While the label is already showing a branch and the page
  // is visible, a shared poll re-reads HEAD and refetches the full status
  // only when that name moved. A tick during our own action is dropped —
  // the action refetches when it finishes.
  useEffect(() => {
    const refreshIfIdle = (): void => {
      if (busyRef.current) return
      void refresh()
    }
    const onVisibility = (): void => {
      if (document.visibilityState === 'visible') refreshIfIdle()
    }
    window.addEventListener('focus', refreshIfIdle)
    document.addEventListener('visibilitychange', onVisibility)
    return () => {
      window.removeEventListener('focus', refreshIfIdle)
      document.removeEventListener('visibilitychange', onVisibility)
    }
  }, [refresh])

  const watchingBranch = cwd !== undefined && repo.facts !== null
  useEffect(() => {
    if (!watchingBranch || cwd === undefined) return
    return subscribeCheckedOutBranch(cwd, (branch) => {
      if (busyRef.current || pollRefreshRef.current) return
      const shown = shownBranchRef.current
      if (shown === undefined || shown === branch) return
      pollRefreshRef.current = true
      void refresh().finally(() => { pollRefreshRef.current = false })
    })
  }, [cwd, refresh, watchingBranch])

  const showError = useCallback((message: string) => {
    pushToast(t('errorGeneric', { message }))
  }, [pushToast, t])

  /** Run one guarded confirm action: single-flight, toast on failure. On
   * success the confirm clears; the MENU closes unless `keepOpen` (the row
   * menu's rule: 原地动作 leave the picker up), and `onSettled` — the
   * flyout's success-only close hook — fires after both. */
  const runGuarded = useCallback(async (action: () => Promise<string | undefined>, keepOpen = false, onSettled?: () => void): Promise<void> => {
    if (blocked()) return
    busyRef.current = true
    setBusy(true)
    const failure = await action()
    busyRef.current = false
    setBusy(false)
    if (failure !== undefined) {
      showError(failure)
      return
    }
    setConfirm(null)
    if (!keepOpen) setMenuOpen(false)
    onSettled?.()
  }, [blocked, showError])

  /** In-place switch flow: POST /switch, then refetch the status. */
  const doSwitch = useCallback((branch: string, keepOpen = false) => runGuarded(async () => {
    if (cwd === undefined) return 'no session directory'
    const result = await requestSwitch(cwd, branch)
    if (!result.ok) return result.error
    await refresh()
    return undefined
  }, keepOpen), [cwd, refresh, runGuarded])

  /** Create-branch flow: POST /branch (`from` + `checkout` split the three
   * shapes — see the wire docs), then refetch the status. ALWAYS keep-open:
   * the row menu is the only entry now, and the whole point of the menu is
   * acting on more rows afterwards; `onSettled` closes the create flyout
   * on success only. */
  const doCreateBranch = useCallback((name: string, from: string | undefined, checkout: boolean, onSettled: () => void) => runGuarded(async () => {
    if (cwd === undefined) return 'no session directory'
    const result = await requestCreateBranch(cwd, name, from, checkout)
    if (!result.ok) return result.error
    await refresh()
    return undefined
  }, true, onSettled), [cwd, refresh, runGuarded])

  /** Rename-branch flow: POST /branch-rename (`git branch -m`, repository-
   * wide), then refetch the status — the chip label and the row follow the
   * new name. Keep-open + success-only `onSettled`, like the create. */
  const doRenameBranch = useCallback((name: string, newName: string, onSettled: () => void) => runGuarded(async () => {
    if (cwd === undefined) return 'no session directory'
    const result = await requestRenameBranch(cwd, name, newName)
    if (!result.ok) return result.error
    await refresh()
    return undefined
  }, true, onSettled), [cwd, refresh, runGuarded])

  /** Delete-branch flow: POST /branch-delete (the SAFE `-d`; git refuses
   * unmerged commits and occupied branches with a 400 toast), then refetch
   * the status — the refreshed rows drop the row, the menu stays. */
  const doDeleteBranch = useCallback((name: string) => runGuarded(async () => {
    if (cwd === undefined) return 'no session directory'
    const result = await requestDeleteBranch(cwd, name)
    if (!result.ok) return result.error
    await refresh()
    return undefined
  }, true), [cwd, refresh, runGuarded])

  /** Stage the worktree removal confirm from a RIGHT-CLICKED worktree row:
   * the dialog lands immediately and the inspect fills its fact lines in
   * place (the manager dialog's posture, one directory instead of a scan).
   * A failed probe degrades to the plain ask — git's own refusal of a dirty
   * non-forced removal stays the safety net. */
  const removalPathRef = useRef<string | null>(null)
  removalPathRef.current = removalPath
  const stageRemoveWorktree = useCallback((path: string, branch: string) => {
    setRemovalPath(path)
    setRemovalFacts(undefined)
    setConfirm({ kind: 'remove-worktree', branch, path })
    void requestInspectWorktree(path).then(
      (result) => {
        setRemovalFacts(cur => cur === undefined && removalPathRef.current === path
          ? (result.ok ? { dirty: result.dirty, ...result.ahead === undefined ? {} : { ahead: result.ahead } } : null)
          : cur)
      },
      () => { setRemovalFacts(cur => cur === undefined && removalPathRef.current === path ? null : cur) },
    )
  }, [])

  /** Worktree removal flow: the shared full removal (git first, archives
   * and unregistration after — the branch survives), then refetch the
   * status so the refreshed rows drop the worktree row, the menu stays. */
  const doRemoveWorktree = useCallback((path: string) => runGuarded(async () => {
    const dirty = removalPath === path ? removalFacts?.dirty ?? 0 : 0
    try {
      await removeWorktree(path, dirty > 0)
    } catch (cause: unknown) {
      return cause instanceof Error ? cause.message : String(cause)
    }
    await refresh()
    return undefined
  }, true), [refresh, removalFacts, removalPath, removeWorktree, runGuarded])

  /** Remote-sync flow: POST /fetch (fetch every remote + prune), then
   * refetch the status. Deliberately NOT runGuarded: its success closes the
   * menu, while the whole point of a sync is watching the refreshed branch
   * list in place. The run lives in the job store, not in this component:
   * the floating card shows its progress and cancels it, a remounted dock
   * still sees it, and while it runs the single-flight gate (`blocked`)
   * keeps every other git action out. A fetch has NO visible side effect
   * when the remote moved not — the card and the done toast ARE the
   * feedback. */
  const doFetch = useCallback(async () => {
    if (cwd === undefined) {
      showError('no session directory')
      return
    }
    if (blocked()) return
    const outcome = await runSyncJob(cwd, 'fetch', live => requestFetch(cwd, live))
    if (outcome === undefined || currentCwdRef.current !== cwd) return
    const { result, cancelled } = outcome
    // A cancel that lost the race with a finished fetch is just a finished fetch.
    if (cancelled && !result.ok) {
      // A remote fetched before the cancel already moved its tracking refs.
      await refresh()
      pushToast(t('fetchCancelled'))
      return
    }
    if (!result.ok) {
      showError(result.error)
      return
    }
    await refresh()
    pushToast(t('fetchDone'))
  }, [blocked, cwd, pushToast, refresh, showError, t])

  /** Update-current-branch flow: POST /update (fetch every remote, then
   * fast-forward the checked-out branch to its upstream), then refetch the
   * status in place — same job-store and keep-the-menu-open semantics as the
   * fetch sync. The toast tells the two apart: fast-forwarded vs already up
   * to date. */
  const doUpdate = useCallback(async () => {
    if (cwd === undefined) {
      showError('no session directory')
      return
    }
    if (blocked()) return
    const outcome = await runSyncJob(cwd, 'update', live => requestUpdate(cwd, live))
    if (outcome === undefined || currentCwdRef.current !== cwd) return
    const { result, cancelled } = outcome
    if (cancelled && !result.ok) {
      await refresh()
      pushToast(t('updateCancelled'))
      return
    }
    if (!result.ok) {
      const kind = explainUpdateFailure(result.error)
      if (kind !== null) pushToast(t(UPDATE_FAIL[kind]))
      else showError(updateErrorText(result.error))
      return
    }
    await refresh()
    pushToast(result.updated ? t('updateDone', { branch: result.branch }) : t('updateUpToDate'))
  }, [blocked, cwd, pushToast, refresh, showError, t])

  /**
   * Push flow: the window hands the push over and closes; the push itself
   * runs in the job store behind the floating card (progress from git,
   * cancellable, the page stays usable) like a fetch or update. Success is a
   * toast. A failure is NOT: the reason belongs next to the choices that
   * produced it, so it is recorded and the window comes back (see the effect
   * that reopens it) — here, or in whichever dock is on this directory later.
   * @returns an error only when nothing could be started (the window then
   * stays open with it); otherwise undefined at once.
   */
  const doPush = useCallback((body: Omit<PushBody, 'repoPath'>): Promise<string | undefined> => {
    if (blocked() || cwd === undefined) return Promise.resolve(t('pushBusy'))
    const remote = body.remote ?? ''
    const target = body.target ?? body.branch
    const failure = (error: string): PushFailure => ({ branch: body.branch, remote, target, tags: body.tags ?? 'none', error })
    // The card takes over from the window, in the same tick: the job
    // registers synchronously, so no other action can slip in between.
    setPushBranch(null)
    setPushResume(undefined)
    void (async () => {
      const outcome = await runSyncJob(cwd, 'push', live => requestPush({ repoPath: cwd, ...body }, live), { branch: body.branch, ...remote === '' ? {} : { remote } })
      if (outcome === undefined) {
        recordPushFailure(cwd, failure(t('pushBusy')))
        return
      }
      const { result, cancelled } = outcome
      // A cancel that lost the race with a finished push is just a finished push.
      const stopped = cancelled && !result.ok
      if (!result.ok && !stopped) recordPushFailure(cwd, failure(result.error))
      if (currentCwdRef.current !== cwd) return
      await refresh()
      if (currentCwdRef.current !== cwd) return
      if (stopped) pushToast(t('pushCancelled'))
      else if (result.ok) pushToast(t('pushDone', { branch: body.branch, remote: result.remote, target: result.target }))
    })()
    return Promise.resolve(undefined)
  }, [blocked, cwd, pushToast, refresh, t])

  /** Worktree-group flow: hop the session into the EXISTING worktree
   * directory. No git action, no confirm — the row menu's hop IS the jump
   * (a directory jump is reversible and touches nothing), and the owner's
   * adoptWorktree registers the folder and opens a blank session there. */
  const doAdoptWorktree = useCallback((path: string): void => {
    if (blocked()) return
    busyRef.current = true
    setBusy(true)
    adoptWorktree(path)
      .then(() => { setMenuOpen(false) })
      .catch((cause: unknown) => {
        showError(cause instanceof Error ? cause.message : String(cause))
      })
      .finally(() => {
        busyRef.current = false
        setBusy(false)
      })
  }, [adoptWorktree, blocked, showError])

  /** Worktree flow: POST /worktree (create-or-reuse, or cut out a new
   * branch under an explicit name), register the directory, hop sessions.
   * After the hop the lazy auto-prune fires (fire-and-forget — a slow
   * removal must not hold the confirm dialog open), and a failed
   * pre-create fetch surfaces as a toast without undoing the creation. */
  const doWorktree = useCallback((branch: string, cutout: boolean, name?: string) => runGuarded(async () => {
    if (cwd === undefined) return 'no session directory'
    const result = cutout
      ? await requestWorktreeCutout(cwd, branch, name)
      : await requestWorktree(cwd, branch)
    if (!result.ok) return result.error
    try {
      await adoptWorktree(result.path)
    } catch (cause) {
      return cause instanceof Error ? cause.message : String(cause)
    }
    if (result.fetchWarning !== undefined) {
      pushToast(t('fetchWarning', { message: result.fetchWarning }))
    }
    if (result.excludeWarning !== undefined) {
      pushToast(t('excludeWarning', { message: result.excludeWarning }))
    }
    void pruneWorktrees?.(result.path).then((report) => {
      if (report === undefined) return
      if (report.removed.length > 0) {
        pushToast(report.failed.length > 0
          ? `${t('pruneDone', { n: report.removed.length })} ${t('pruneFailed', { n: report.failed.length })}`
          : t('pruneDone', { n: report.removed.length }))
      } else if (report.failed.length > 0) {
        pushToast(t('pruneFailed', { n: report.failed.length }))
      }
    }).catch(() => { /* a prune failure must not disturb the session flow */ })
    return undefined
  }), [adoptWorktree, pruneWorktrees, cwd, pushToast, runGuarded, t])

  const facts = repo.facts
  // The session sits in a linked worktree when its own directory is NOT the
  // main checkout — the trigger for the scoped menu (see below) and for
  // hiding the worktree toggle. Read from `facts.main`, never from comparing
  // `facts.repoRoot` against the main entry of `facts.worktrees`: repoRoot IS
  // the main checkout from every worktree (it comes from the shared
  // `--git-common-dir`), so that comparison was a tautology and the whole
  // scope stayed silently off.
  const inLinkedWorktree = facts !== null && !facts.main
  const rows = useMemo(() => {
    if (facts === null) return []
    // A linked-worktree session gets its own branch plus the OTHER
    // worktrees as hop targets — never another BRANCH (see the two builders).
    // A main-checkout session gets the full list; that is where the whole
    // action surface lives and where the environment gets chosen.
    if (inLinkedWorktree) return buildLinkedWorktreeRows(facts.branches, facts.worktrees, facts.currentBranch)
    return buildBranchRows(facts.branches, facts.worktrees)
  }, [facts, inLinkedWorktree])
  // Every already-taken LOCAL name feeds the new-branch namespaces (cutout
  // prefill and the duplicate checks): local rows and worktree rows alike
  // (a worktree row IS a checked-out branch), while a remote row is no
  // claim at all — a remote branch with a same-named local twin never
  // reaches the client (the host hides those rows).
  const localNames = useMemo(
    () => rows.filter(row => row.kind !== 'remote').map(row => row.name),
    [rows],
  )

  // Non-repo and still-loading directories render nothing at all.
  if (facts === null) return null

  const confirmLocalName = confirm === null ? '' : localBranchName(confirm.branch)
  // The cutout dialog carries an EDITABLE new-branch name (pre-filled with
  // the first free `<branch>-wt`); validated exactly like the create
  // flyout — git ref-name rules plus a duplicate check against the rows.
  const isCutout = confirm?.kind === 'worktree-cutout'
  const cutoutDraft = isCutout ? confirm.draft ?? '' : ''
  const cutoutIssue = isCutout ? branchNameIssue(cutoutDraft) : null
  const cutoutDuplicate = isCutout && cutoutIssue === null && localNames.includes(cutoutDraft)
  const cutoutValid = cutoutIssue === null && !cutoutDuplicate
  const cutoutHint = cutoutDuplicate
    ? t('menuNewBranchExists')
    : cutoutIssue !== null && cutoutIssue !== 'empty'
      ? t('menuNewBranchBad')
      : undefined
  // Reuse applies only to the plain create flow: a cutout always cuts a
  // fresh branch, so the current-branch confirm can never reuse.
  const existingWorktree = confirm === null || confirm.kind !== 'worktree'
    ? undefined
    : facts.worktrees.find(w => w.branch === confirmLocalName)

  // The removal confirm's fact lines: only the STAGED directory's facts
  // render (a restage keeps the loading line until its own probe lands),
  // the dirty count reads red like the manager dialog's, and the DSH half
  // (archived-session count) rides the injected snapshot read.
  const removalFactsNow = confirm?.kind === 'remove-worktree' && confirm.path !== undefined && removalPath === confirm.path
    ? removalFacts
    : undefined
  const removalDetails = confirm?.kind === 'remove-worktree' && confirm.path !== undefined ? (
    <>
      {removalFactsNow === undefined && <p className={css.popDetail}>{t('worktreeRemove.inspecting')}</p>}
      {removalFactsNow != null && (
        <>
          <p className={(removalFactsNow.dirty ?? 0) > 0 ? `${css.popDetail} ${css.popDetailWarn}` : css.popDetail}>
            {(removalFactsNow.dirty ?? 0) > 0
              ? t((removalFactsNow.dirty ?? 0) === 1 ? 'worktreeRemove.dirty.one' : 'worktreeRemove.dirty.other', { n: removalFactsNow.dirty ?? 0 })
              : t('worktreeRemove.clean')}
          </p>
          {(removalFactsNow.ahead ?? 0) > 0 && (
            <p className={css.popDetail}>{t('worktreeRemove.ahead', { n: removalFactsNow.ahead ?? 0 })}</p>
          )}
          {(() => {
            const count = describeWorktreeRemoval(confirm.path).archiveCount
            return count > 0
              ? <p className={css.popDetail}>{t(count === 1 ? 'worktreeRemove.sessions.one' : 'worktreeRemove.sessions.other', { n: count })}</p>
              : null
          })()}
        </>
      )}
    </>
  ) : undefined

  /** One confirm bundle shared by the menu flyout and the standalone
   * dialog (whichever is showing). Switches stage NO dialog — 签出 runs
   * directly (keep-open); what remains is the destructive delete and the
   * worktree/cutout dialogs, the latter carrying the editable new-branch
   * name. Remote worktree picks keep the ask line SHORT and name the
   * branch on its own weight-500 line. */
  const confirmBundle = confirm === null ? null : {
    // The cutout dialog asks for the NAME, and names the base while it is
    // at it: the row that was right-clicked is gone by the time this
    // flyout replaces the menu, and "cut from which branch" is the half of
    // the action the input cannot express. The delete/worktree asks name
    // their consequence instead.
    ask: confirm.kind === 'worktree-cutout'
      ? t('cutoutFlyAsk', { branch: confirm.branch })
      : confirm.kind === 'delete'
        ? t('deleteBranchAsk', { branch: confirm.branch })
        : confirm.kind === 'remove-worktree'
          ? t('worktreeRemove.desc', { path: confirm.path ?? confirm.branch })
          : confirm.remote === true
            ? t('worktreeAskRemote')
            : t(existingWorktree !== undefined ? 'worktreeAskReuse' : 'worktreeAskNew', { branch: confirmLocalName }),
    ...confirm.kind === 'remove-worktree'
      ? { subject: t('worktreeRemove.descBranch', { branch: confirm.branch }), details: removalDetails }
      : confirm.remote === true ? { subject: confirm.branch } : {},
    confirmLabel: busy
      ? (confirm.kind === 'delete' ? t('deleteBranchBusy') : confirm.kind === 'remove-worktree' ? t('worktreeRemove.busy') : t('worktreeBusy'))
      : t(confirm.kind === 'remove-worktree' ? 'worktreeRemove.menu' : 'actionConfirm'),
    cancelLabel: t('actionCancel'),
    busy,
    // The cutout dialog carries an EDITABLE new-branch name (typed by
    // hand): the menu-open flyout renders the input from these fields —
    // same shape the standalone ChipConfirm spreads below.
    ...(confirm.kind === 'worktree-cutout'
      ? {
          draft: cutoutDraft,
          onDraftChange: (value: string) => { setConfirm(current => current?.kind === 'worktree-cutout' ? { ...current, draft: value } : current) },
          draftPlaceholder: t('menuNewBranchPlaceholder'),
          ...(cutoutValid ? {} : { draftInvalid: true }),
          ...(cutoutHint === undefined ? {} : { draftHint: cutoutHint }),
        }
      : {}),
    onConfirm: () => {
      if (confirm.kind === 'delete') {
        void doDeleteBranch(confirm.branch)
      } else if (confirm.kind === 'remove-worktree') {
        if (confirm.path !== undefined) void doRemoveWorktree(confirm.path)
      } else if (confirm.kind === 'worktree-cutout' && !cutoutValid) {
        return
      } else {
        void doWorktree(confirm.branch, confirm.kind === 'worktree-cutout', confirm.draft)
      }
    },
    onCancel: () => { if (!busy) setConfirm(null) },
  }

  const pushBranchInfo = facts.branches.find(entry => entry.kind === 'local' && entry.name === pushBranch)

  return (
    <>
      <span className={css.dock}>
        <button
          ref={chipRef}
          type="button"
          className={css.chip}
          title={facts.currentBranch}
          onClick={() => {
            // Toggling always unwinds any half-open confirm first.
            setConfirm(null)
            const opening = !menuOpen
            setMenuOpen(opening)
            // Fresh rows at decision time: branches may have moved outside
            // (terminal, other tools) since the last fetch. Non-blocking —
            // the menu opens on current data and re-renders when it lands.
            if (opening && !busyRef.current) void refresh()
          }}
        >
          <IconBranchOutlineRegular size={12} />
          <span className={css.branch}>{displayBranch(facts.currentBranch)}</span>
        </button>
      </span>
      <BranchMenu
        open={menuOpen}
        repoPath={cwd ?? facts.repoRoot}
        anchorRef={chipRef}
        rows={rows}
        currentBranch={facts.currentBranch}
        confirm={confirmBundle}
        canCreate={!inLinkedWorktree}
        // The hop group is offered wherever a hop makes sense: the main
        // checkout's BLANK session (where the environment is chosen) and
        // ANY linked-worktree session (moving between worktrees is what a
        // linked worktree is for, and the hop opens a fresh session without
        // touching any checkout). A STARTED main-checkout session keeps it
        // off — that is the one place where the group was ruled out, and
        // nothing here reopens it.
        canAdopt={session.blank || inLinkedWorktree}
        canWorktree={session.blank && !inLinkedWorktree}
        onWorktree={(branch) => {
          // The reuse/new/remote-twin confirm staged from a RIGHT-CLICKED
          // row: the anchor was staged by the menu; here we look the row up
          // for the remote wording and stage the dialog itself.
          const row = rows.find(r => r.name === branch)
          setConfirm({ kind: 'worktree', branch, remote: row?.kind === 'remote' })
        }}
        onCutWorktree={(base) => {
          // The cutout dialog staged from a RIGHT-CLICKED row: the base is
          // that row's branch (the current checkout included — the cut is
          // the isolated-worktree move). The new-branch name is typed by
          // hand (empty start, confirm disables until valid).
          setConfirm({ kind: 'worktree-cutout', branch: base })
        }}
        onRemoveWorktree={stageRemoveWorktree}
        // The running-session withhold reads the live snapshot at render
        // time (the injected face is synchronous) — a session that starts
        // while the menu is open disarms the verb without reopening.
        worktreeRemovalBlocked={(path) => describeWorktreeRemoval(path).running}
        // A running fetch/update holds the other git actions off, like any
        // in-flight action — but only this flag: the confirm dialogs keep the
        // plain `busy` (their labels turn into progress text, which would lie
        // about an action nobody started there).
        busy={busy || syncJob !== undefined}
        onCreate={(name, from, checkout, onSettled) => { void doCreateBranch(name, from, checkout, onSettled) }}
        onRename={(name, newName, onSettled) => { void doRenameBranch(name, newName, onSettled) }}
        onDelete={(branch) => {
          // The confirm flyout's anchor was staged by the row menu (it
          // knows the row element); here we only stage the dialog itself.
          setConfirm({ kind: 'delete', branch })
        }}
        onFetch={() => { void doFetch() }}
        fetchBusy={syncJob?.kind === 'fetch'}
        onUpdate={() => { void doUpdate() }}
        hasRemotes={repoHasRemotes(facts.branches)}
        onPush={(branch) => {
          if (blocked()) return
          setConfirm(null)
          setMenuOpen(false)
          setPushResume(undefined)
          setPushBranch(branch)
        }}
        updateBusy={syncJob?.kind === 'update'}
        onSelect={(branch) => {
          // Re-selecting the CURRENT branch is a plain close (worktree
          // creation lives in the row menu now — no mode bit reroutes
          // picks). Any other pick executes DIRECTLY — no confirm dialog on
          // the switch path (right-click 签出 and Enter are the same stroke,
          // keep-open so the picker stays up) — except a WORKTREE row: the
          // pick hops the session into that worktree directory (the menu
          // closes on success; the session moved).
          if (branch === facts.currentBranch) {
            setMenuOpen(false)
            return
          }
          const row = rows.find(r => r.name === branch)
          if (row?.kind === 'worktree' && row.path !== undefined) {
            doAdoptWorktree(row.path)
            return
          }
          // 签出, confirmation-free: an in-place `git switch` (remote rows
          // dwim their tracking twin), menu stays open.
          void doSwitch(branch, true)
        }}
        onClose={() => { setMenuOpen(false) }}
        t={t}
      />
      {confirmBundle !== null && !menuOpen && (
        <ChipConfirm
          anchorRef={chipRef}
          {...confirmBundle}
          {...isCutout ? { draft: cutoutDraft } : {}}
          {...isCutout
            ? { onDraftChange: (value: string) => { setConfirm(current => current?.kind === 'worktree-cutout' ? { ...current, draft: value } : current) } }
            : {}}
          draftPlaceholder={t('menuNewBranchPlaceholder')}
          {...isCutout && !cutoutValid ? { draftInvalid: true } : {}}
          {...cutoutHint === undefined ? {} : { draftHint: cutoutHint }}
        />
      )}
      {pushBranch !== null && cwd !== undefined && <PushDialog key={`${cwd}:${pushBranch}`} repoPath={cwd} repoName={facts.repoName}
        branch={pushBranch} busy={busy} t={t}
        {...(pushBranchInfo === undefined ? {} : { branchInfo: pushBranchInfo })}
        {...(pushResume === undefined ? {} : { resume: pushResume })}
        onClose={() => {
          if (busyRef.current) return
          setPushBranch(null)
          setPushResume(undefined)
        }}
        onPush={options => doPush({ branch: pushBranch, ...options })} />}
      {syncJob !== undefined && (
        <SyncProgress job={syncJob} branch={facts.currentBranch} t={t} onCancel={() => { cancelSyncJob(syncJob.cwd) }} />
      )}
      {toasts[0] !== undefined && (
        <Toast
          key={toasts[0].seq}
          text={toasts[0].text}
          onDone={() => { setToasts(queue => queue.slice(1)) }}
        />
      )}
    </>
  )
}
