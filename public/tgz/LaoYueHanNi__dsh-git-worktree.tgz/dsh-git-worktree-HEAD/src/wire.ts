/**
 * Shared wire contract between the host half (HTTP routes under
 * `/plugin/git-worktree`) and the browser half (chip + plugin settings card).
 * Zero runtime dependencies: constants and types only, imported by both
 * builds.
 */

/** Absolute pathname prefix every route of this plugin lives under. */
export const ROUTE_PREFIX = '/plugin/git-worktree'

/** GET ROUTE_PREFIX/status?path=<absolute dir> */
export const ROUTE_STATUS = `${ROUTE_PREFIX}/status`

/** GET ROUTE_PREFIX/head?path=<absolute dir> — checked-out branch only.
 * A file read of HEAD, not a git process. */
export const ROUTE_HEAD = `${ROUTE_PREFIX}/head`

/** Read-only POSTs: bounded history and one commit's full message/summary. */
export const ROUTE_HISTORY = `${ROUTE_PREFIX}/history`
export const ROUTE_COMMIT = `${ROUTE_PREFIX}/commit`

export interface HistoryBody {
  repoPath: string
  /** Explicit refs/heads/... or refs/remotes/...; HEAD for detached/unborn. */
  ref: string
  /** Subsequent pages stay pinned to the first response's tip. */
  tip?: string
  offset?: string
}

export interface HistoryCommit {
  oid: string
  parents: string[]
  author: string
  date: string
  subject: string
}

export interface CommitHistory {
  tip: string | null
  commits: HistoryCommit[]
  next: number | null
}

export interface CommitDetail extends HistoryCommit {
  body: string
  /** Summary relative to the first parent (empty tree for a root). */
  files: number
  firstFile: string | null
  added: number
  removed: number
  binaryFiles: number
}

export interface CommitBody { repoPath: string; oid: string }

/** POST ROUTE_PREFIX/worktree — create-or-reuse a worktree for a branch. */
export const ROUTE_WORKTREE = `${ROUTE_PREFIX}/worktree`

/** POST ROUTE_PREFIX/switch — in-place branch switch of the main checkout. */
export const ROUTE_SWITCH = `${ROUTE_PREFIX}/switch`

/** POST ROUTE_PREFIX/branch — create a NEW branch (at the current checkout
 * or an explicit start point, with or without checking it out). */
export const ROUTE_BRANCH = `${ROUTE_PREFIX}/branch`

/** POST ROUTE_PREFIX/branch-rename — rename a LOCAL branch (refs are
 * repository-wide; worktree HEADs pointing at it follow). */
export const ROUTE_BRANCH_RENAME = `${ROUTE_PREFIX}/branch-rename`

/** POST ROUTE_PREFIX/branch-delete — delete a LOCAL branch (`-d`, merged
 * only; git refuses the rest). */
export const ROUTE_BRANCH_DELETE = `${ROUTE_PREFIX}/branch-delete`

/** POST ROUTE_PREFIX/fetch — sync remote-tracking refs (fetch every remote + prune).
 * Streams {@link SyncFrame} lines (NDJSON) so a long transfer can show progress. */
export const ROUTE_FETCH = `${ROUTE_PREFIX}/fetch`

/** POST ROUTE_PREFIX/update — fast-forward the current branch to its upstream.
 * Streams {@link SyncFrame} lines (NDJSON), like {@link ROUTE_FETCH}. */
export const ROUTE_UPDATE = `${ROUTE_PREFIX}/update`

/** POST push-plan — resolve the selected branch's push destination. */
export const ROUTE_PUSH_PLAN = `${ROUTE_PREFIX}/push-plan`
/** POST push-preview — inspect one explicit destination without pushing. */
export const ROUTE_PUSH_PREVIEW = `${ROUTE_PREFIX}/push-preview`
/** POST push — push one explicit local branch. Streams {@link SyncFrame}
 * lines (NDJSON), like {@link ROUTE_FETCH}; the `done` body is a
 * {@link PushResult}. A cancel (499) kills `git push`; the remote only moves
 * a ref once the whole pack has arrived, so a stopped transfer changes nothing. */
export const ROUTE_PUSH = `${ROUTE_PREFIX}/push`

/** POST ROUTE_PREFIX/group — git belonging facts for a batch of workspace paths. */
export const ROUTE_GROUP = `${ROUTE_PREFIX}/group`

/** POST ROUTE_PREFIX/inspect — pre-delete facts for one worktree directory. */
export const ROUTE_INSPECT = `${ROUTE_PREFIX}/inspect`

/** POST ROUTE_PREFIX/remove — delete one linked worktree (git registration + folder). */
export const ROUTE_REMOVE = `${ROUTE_PREFIX}/remove`

/** POST ROUTE_PREFIX/exists — batch directory-existence probe (fs, no git). */
export const ROUTE_EXISTS = `${ROUTE_PREFIX}/exists`

/** POST ROUTE_PREFIX/ensure-directory — mkdir -p a missing worktree storage slot. */
export const ROUTE_ENSURE_DIRECTORY = `${ROUTE_PREFIX}/ensure-directory`

/** POST ROUTE_PREFIX/worktrees-all — scan the storage root: git facts for
 * every direct child directory (the plugin-planned worktree slots). */
export const ROUTE_WORKTREES_ALL = `${ROUTE_PREFIX}/worktrees-all`

/** POST ROUTE_PREFIX/purge — delete a NON-git directory sitting DIRECTLY in
 * the storage root (an orphaned leftover whose .git is already gone). */
export const ROUTE_PURGE = `${ROUTE_PREFIX}/purge`

/** One selectable branch row. */
export interface BranchEntry {
  /** Display name: a bare local name (`main`) or `<remote>/<name>`. */
  name: string
  kind: 'local' | 'remote'
  /** Commits the local branch is AHEAD of its upstream (local rows with an
   * upstream only; absent = no upstream or in sync). */
  ahead?: number
  /** Commits the local branch is BEHIND its upstream (same conditions). */
  behind?: number
  /** Configured upstream; absent means unpublished, not synchronized. */
  upstream?: string
  /** The configured upstream no longer exists in the local tracking refs. */
  upstreamGone?: true
}

export interface PushPlanBody {
  repoPath: string
  branch: string
}

export interface PushPlan {
  branch: string
  remotes: string[]
  remote: string
  target: string
  /** Publishing or changing the tracking destination requires a target dialog. */
  confirm: boolean
  upstream?: string
  /** `/push-plan` only: display-only snapshot of the default destination from
   * local refs, so opening the push window needs one request, not two. Absent
   * when it could not be built; never a substitute for the verified preview. */
  local?: PushPreview
}

export interface PushBody extends PushPlanBody {
  /** Both present only after the user confirms the publish destination. */
  remote?: string
  target?: string
  tags?: 'none' | 'all' | 'follow'
  /** Force only the destination branch, leased against the previewed OID. */
  force?: boolean
  /** Empty string means the remote branch did not exist in the preview. */
  expectedTarget?: string
  sourceOid?: string
}

export interface PushPreviewBody extends PushPlanBody {
  remote: string
  target: string
  /** Approximate display-only preview from local tracking refs; never contacts the remote. */
  localOnly?: boolean
}

export interface PushPreview {
  sourceOid: string
  targetOid: string | null
  commits: { oid: string; subject: string }[]
  total: number
  truncated: boolean
}

export interface PushResult {
  branch: string
  remote: string
  target: string
}

/** One existing worktree of the repository. */
export interface WorktreeEntry {
  /** Absolute path of the worktree directory. */
  path: string
  /** Checked-out local branch name; absent for a detached or bare worktree. */
  branch: string | undefined
  /** True for the main worktree (the one holding `.git`). */
  main: boolean
}

/** Response of GET status — `repo: false` for a directory outside any git repository. */
export type RepoStatus =
  | { repo: false }
  | {
      repo: true
      /** Main repository directory basename — the root folder of `<rootDir>/<repoName>/`. */
      repoName: string
      /** Absolute path of the main worktree directory. */
      repoRoot: string
      /** True when the queried directory IS the main worktree (its own
       * toplevel holds the shared `.git`). The client's "session sits in a
       * linked worktree" trigger — `repoRoot` cannot answer it, since it
       * names the main checkout from every worktree by construction. */
      main: boolean
      /** Branch checked out by the directory the client asked about. */
      currentBranch: string
      /** Local branches plus every remote's remote-only branches (those
       * without a same-named local twin; `<remote>/HEAD` dropped). */
      branches: BranchEntry[]
      /** Every worktree of the repository, main first (git order). */
      worktrees: WorktreeEntry[]
      /** Resolved worktree storage root (absolute) — what the settings say today. */
      rootDir: string
    }

/**
 * Response of GET head. `repo: false` — the directory is not inside a
 * repository. `pending` — a repository was found but HEAD could not be read
 * completely this tick (mid-checkout, partial write); callers skip the tick
 * rather than guess a name. `currentBranch` is the branch, or `HEAD` when
 * detached.
 */
export type HeadStatus =
  | { repo: false }
  | { repo: true; pending: true }
  | { repo: true; currentBranch: string }

/** POST worktree request body. */
export interface CreateWorktreeBody {
  /** Any directory inside the repository (workspace cwd). */
  repoPath: string
  /** Chosen branch display name: local (`feat-x`) or remote (`origin/feat-x`). */
  branch: string
  /** True: cut a NEW branch out of `branch` (the current checkout's
   * branch — occupied by the main worktree) and isolate it in a fresh
   * worktree. The storage folder is named after the new branch. */
  cutout?: boolean
  /** Cutout only: explicit name for the NEW branch. Default (absent):
   * derived `<branch>-wt`, suffixing past taken names. */
  name?: string
}

/** POST worktree response body. */
export interface CreateWorktreeResult {
  /** The worktree directory (created or reused). */
  path: string
  /** False when an existing worktree for the branch was reused. */
  created: boolean
  /** Present only when the pre-create remote sync (`fetchBeforeCreate`) was
   * enabled AND failed: the creation went ahead anyway (a local worktree
   * never consumes the fetch), this carries git's stderr summary for the
   * client to toast. */
  fetchWarning?: string
  /** Present only when the idempotent write of `/.dsh/gitworktree/` into
   * `<repo>/.git/info/exclude` failed: the worktree was created anyway (it
   * cannot be rolled back), so the SOURCE REPOSITORY now shows an untracked
   * `.dsh/` directory — the client must toast this or the user's next
   * `git status` reads as a mystery. */
  excludeWarning?: string
  /** Present only when copying declared configuration files into the new
   * worktree failed for one or more files: the worktree was created anyway,
   * this carries a summary of the failed copies for the client to toast. */
  copyWarning?: string
}

/** POST switch request body. */
export interface SwitchBody {
  /** Any directory inside the main worktree. */
  repoPath: string
  /** Target branch display name (local, or remote whose local twin is created by dwim). */
  branch: string
}

/** POST switch response body. */
export interface SwitchResult {
  /** The branch actually checked out after the switch. */
  branch: string
}

/** POST branch request body. */
export interface CreateBranchBody {
  /** Any directory inside the repository (workspace cwd). Without `from` the
   * new branch is cut from whatever this directory's HEAD points at and
   * checked out HERE. */
  repoPath: string
  /** User-typed name of the branch to create (a local name, verbatim). */
  name: string
  /** Optional start point (a local branch or a remote-tracking ref like
   * `origin/feat-x`). Absent keeps the original in-place semantics: create
   * AND check out here. */
  from?: string
  /** With `from`, ALSO check the new branch out in the queried directory
   * (`git switch -c <name> <from>`) instead of leaving every checkout
   * untouched (`git branch <name> <from>`). Ignored without `from` —
   * the no-`from` shape always checks out. */
  checkout?: boolean
}

/** POST branch response body. */
export interface CreateBranchResult {
  /** The branch created; checked out in the queried directory unless
   * created at a start point with `checkout` left false. */
  branch: string
}

/** POST branch-rename request body. */
export interface RenameBranchBody {
  /** Any directory inside the repository (branch refs are repository-wide). */
  repoPath: string
  /** The branch to rename (a LOCAL name; remote branches are not ours). */
  name: string
  /** User-typed new name (a local name, verbatim). */
  newName: string
}

/** POST branch-rename response body. */
export interface RenameBranchResult {
  /** The branch's new name. */
  branch: string
}

/** POST branch-delete request body. */
export interface DeleteBranchBody {
  /** Any directory inside the repository (branch refs are repository-wide). */
  repoPath: string
  /** The branch to delete (a LOCAL name; remote branches are not ours). */
  name: string
}

/** POST branch-delete response body. */
export interface DeleteBranchResult {
  /** The branch that was deleted. */
  branch: string
}

/** POST fetch request body. */
export interface FetchBody {
  /** Any directory inside the repository (workspace cwd). */
  repoPath: string
}

/** POST fetch response body — the fetch mutates refs server-side; the
 * client refetches /status for the fresh branch list. */
export interface FetchResult {
  /** What the fetch covered: "all" remotes (this plugin always fetches all). */
  remote: string
}

/** POST update request body. */
export interface UpdateBody {
  /** Any directory inside the repository (workspace cwd) — the branch
   * checked out by THIS directory is the one updated. */
  repoPath: string
}

/** POST update response body — fetch every remote, then fast-forward the
 * checked-out branch to its upstream. */
export interface UpdateResult {
  /** The branch that was updated (empty for a detached checkout, which
   * cannot be updated and always errors before this response). */
  branch: string
  /** False when the upstream already contained the branch (nothing moved). */
  updated: boolean
}

/** Content type of a streamed route: one JSON {@link SyncFrame} per line. */
export const NDJSON_TYPE = 'application/x-ndjson'

/**
 * A live event of a long route while it still runs.
 * - `progress` is git's own progress line (`Receiving objects:  3% (2147/58680),
 *   708.01 KiB | 128.00 KiB/s`) with its percentage when it has one, and the
 *   remote being fetched (the host fetches them one by one and names each
 *   ahead of its counter lines);
 * - `merge` marks the switch from fetching to the fast-forward, the one step
 *   that can no longer be cancelled.
 */
export type SyncEvent =
  | { type: 'progress'; text: string; percent?: number; remote?: string }
  | { type: 'merge' }

/**
 * One line of a streamed route response. The last line is always `done`,
 * carrying the status and body the same route would have answered in one piece
 * (the result, or a {@link RouteError}); a stream that ends without it was cut.
 */
export type SyncFrame = SyncEvent | { type: 'done'; status: number; body: unknown }

/** Error envelope every non-2xx response carries. */
export interface RouteError {
  error: string
}

/** Git belonging facts of one workspace directory; null = not a git repository. */
export interface WorkspaceGitFacts {
  /** Grouping key: the repository's main worktree directory (canonical). */
  repoRoot: string
  /** Group title: the main repository directory basename. */
  repoName: string
  /** Branch checked out by this directory; null = detached or unborn HEAD. */
  branch: string | null
  /** True when this directory IS the main worktree (holds the shared .git). */
  main: boolean
}

/** POST group request body. */
export interface GroupWorkspacesBody {
  /** Absolute workspace directories to probe (deduped server-side). */
  paths: string[]
}

/** POST group response body — one entry per DISTINCT requested path. */
export interface GroupWorkspacesResult {
  /** Git facts per path; null marks a path outside any git repository. */
  facts: Record<string, WorkspaceGitFacts | null>
}

/** POST inspect request body. */
export interface InspectWorktreeBody {
  /** The worktree directory to inspect (absolute). */
  path: string
}

/** POST inspect response body — the facts the remove-confirm dialog shows. */
export interface InspectWorktreeResult {
  /** Uncommitted changes in the directory (staged + unstaged + untracked
   * file rows of `git status --porcelain`). */
  dirty: number
  /** Commits the checked-out branch is ahead of its upstream; absent = no
   * upstream. Purely informational: the branch ref survives the removal, so
   * these commits are NOT lost. */
  ahead?: number
}

/** POST remove request body. */
export interface RemoveWorktreeBody {
  /** The linked worktree directory to delete (absolute). */
  path: string
  /** True: force past uncommitted changes (the confirm dialog already
   * showed the dirty count). */
  force?: boolean
}

/** POST remove response body. */
export interface RemoveWorktreeResult {
  /** The removed worktree directory. */
  path: string
  /** True when only a stale registration was pruned (the directory was
   * already gone); false when `git worktree remove` deleted a live folder. */
  pruned: boolean
}

/** POST exists request body. */
export interface PathExistsBody {
  /** Absolute directories to probe (deduped server-side). */
  paths: string[]
}

/** POST exists response body — one entry per DISTINCT requested path; true =
 * the path exists AND is a directory. The client gates the register action on
 * this, so a missing folder never reaches the DSH workspace API. */
export interface PathExistsResult {
  exists: Record<string, boolean>
  /** Per MISSING path: true when it sits DIRECTLY inside the plugin's
   * worktree storage root — a slot this plugin planned, so rebuilding the
   * empty directory is safe (historical sessions reattach automatically once
   * realpath matches again). Absent paths and directories outside the root
   * never appear here. */
  rebuildable?: Record<string, boolean>
}

/** POST ensure-directory request body. */
export interface EnsureDirectoryBody {
  /** The missing directory to create (absolute; must sit directly inside the
   * legacy storage root or a repository's `.dsh/gitworktree`). */
  path: string
}

/** POST ensure-directory response body. */
export interface EnsureDirectoryResult {
  /** Always true on 200 — the directory now exists (created, or already
   * present as a directory). */
  created: boolean
}

/** POST worktrees-all request body (all-optional for shape compatibility). */
export interface WorktreesAllBody {
  /** Absolute directories of the REGISTERED workspaces, from which the host
   * derives the repository-root set to scan `<repo>/.dsh/gitworktree` under
   * (each probed once, deduplicated). Absent/empty scans only the legacy
   * storage root. */
  workspaces?: string[]
}

/** One direct child directory of a worktree storage location. */
export interface WorktreeScanEntry {
  /** Absolute directory path. */
  path: string
  /** Main repository directory basename; null = the directory is not inside
   * a git repository (an orphan or foreign folder — shown as unrecognized,
   * never deleted, never counted against the prune cap). */
  repoName: string | null
  /** Branch checked out by the directory; null = unrecognized, detached, or
   * unborn HEAD. */
  branch: string | null
  /** Where the directory lives: `project` = inside `<repo>/.dsh/gitworktree`
   * (the current layout, auto-nested under its repository by the workspace
   * tree), `legacy` = inside the historical central storage root. */
  source: 'legacy' | 'project'
}

/** POST worktrees-all response body — one entry per DIRECT child of each
 * scanned storage location; a missing location answers its half as an empty
 * list. */
export interface WorktreesAllResult {
  worktrees: WorktreeScanEntry[]
  /** The resolved LEGACY storage root (historical central location): kept
   * read-only in the settings card so existing users can still find where
   * their old worktrees live. */
  legacyRoot: string
  /** False when the legacy root does not exist on disk — "未使用" rather
   * than hiding the field. */
  legacyRootExists: boolean
  /** Present and true when either scanned location held more children than
   * the scan probes: the list is the first slice, and the client says so
   * rather than presenting a truncated scan as the whole picture. */
  truncated?: boolean
}

/** POST purge request body. */
export interface PurgeDirectoryBody {
  /** The leftover directory to delete (absolute; must sit directly inside
   * the legacy storage root or a repository's `.dsh/gitworktree`, AND have
   * no git identity). */
  path: string
}

/** POST purge response body. */
export interface PurgeDirectoryResult {
  /** Always true on 200 — the directory (contents included) is gone. */
  path: string
  removed: boolean
}
