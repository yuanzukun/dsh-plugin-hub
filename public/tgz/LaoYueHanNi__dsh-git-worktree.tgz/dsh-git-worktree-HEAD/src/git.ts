/**
 * Git command wrapper for the host half. All git access goes through one
 * injectable `exec` seam (tests substitute it); every method is plain
 * argument assembly plus porcelain parsing, no ambient state.
 */

import { execFile, spawn, type ChildProcess } from 'node:child_process'
import { existsSync, readdirSync } from 'node:fs'
import { appendFile, mkdir, readFile, rm } from 'node:fs/promises'
import { basename, dirname, isAbsolute, join, normalize, resolve } from 'node:path'
import { localBranchName } from './normalize.js'
import { stripProgress } from './progress.js'
import type { BranchEntry, WorktreeEntry, WorkspaceGitFacts } from './wire.js'

/** One process result as the seam reports it. */
export interface ExecResult {
  code: number
  stdout: string
  stderr: string
  /** The run was stopped by its `signal` (set by a live run only). */
  cancelled?: boolean
}

/** Options of one {@link Exec} call. */
export interface ExecOptions {
  cwd: string
  /** Hard cap on the whole run. Absent = 20 s for a plain run, none for a
   * live one (which is bounded by `idleTimeoutMs` and its `signal`). */
  timeoutMs?: number
  nonInteractive?: boolean
  /** Live run: git's stdout and stderr text, chunk by chunk as it is written.
   * Any of the three live options moves the run onto a streaming spawn. */
  onOutput?: (chunk: string) => void
  /** Live run: aborting kills git and its transport children and answers
   * `cancelled`. */
  signal?: AbortSignal
  /** Live run: kill git after this long without a byte of output. */
  idleTimeoutMs?: number
}

/**
 * Process executor seam. Runs `file args` with cwd set, captures output as
 * UTF-8 text, and never throws — a non-zero exit is a normal result.
 */
export type Exec = (file: string, args: readonly string[], options: ExecOptions) => Promise<ExecResult>

/** Failure of one git invocation: non-zero exit with the stderr text. */
export class GitError extends Error {
  constructor(
    readonly args: readonly string[],
    readonly code: number,
    readonly stderr: string,
  ) {
    super(`git ${args.join(' ')} failed (exit ${code}): ${stderr.trim()}`)
    this.name = 'GitError'
  }
}

/** Facts the status route assembles: branches, worktrees, repo identity. */
export interface RepoFacts {
  /** Absolute main worktree path (`dirname` of `--git-common-dir`, not the
   * queried directory's `--show-toplevel` — a linked worktree's toplevel
   * dies during `worktree remove`). */
  repoRoot: string
  /** Main repository directory basename. */
  repoName: string
  /** The QUERIED directory's own toplevel — the worktree the session
   * actually sits in. Repository-wide commands (branch refs, fetch,
   * worktree registration) run at {@link RepoFacts.repoRoot}; commands that
   * act on the session's own checkout (switch/update/create-and-check-out)
   * run HERE, or a linked-worktree session would silently operate on the
   * main checkout instead. */
  toplevel: string
  /** Whether the QUERIED directory is the main worktree — see
   * {@link isMainWorktree}. `repoRoot` cannot answer this: it names the main
   * checkout from every worktree by construction. */
  main: boolean
  /** Branch checked out by the queried directory. */
  currentBranch: string
  branches: BranchEntry[]
  worktrees: WorktreeEntry[]
}

/** Appended to the stderr of a run that was killed for taking too long. */
const TIMED_OUT = 'Git command timed out; check the remote before retrying.'

/** Environment of one run: `nonInteractive` stops git (and its credential
 * helper) from waiting on a prompt nobody can answer. */
function execEnv(options: ExecOptions): { env: NodeJS.ProcessEnv } | Record<string, never> {
  return options.nonInteractive ? { env: { ...process.env, GIT_TERMINAL_PROMPT: '0', GCM_INTERACTIVE: 'never' } } : {}
}

/** Real executor over node:child_process: a buffered run with a hard timeout,
 * or — when the caller asks for live output / cancellation — a streaming one. */
export function childProcessExec(file: string, args: readonly string[], options: ExecOptions): Promise<ExecResult> {
  if (options.onOutput !== undefined || options.signal !== undefined || options.idleTimeoutMs !== undefined) {
    return liveProcessExec(file, args, options)
  }
  return new Promise((resolvePromise) => {
    execFile(file, args, { cwd: options.cwd, encoding: 'utf8', timeout: options.timeoutMs ?? 20_000, windowsHide: true, maxBuffer: 4 * 1024 * 1024,
      ...execEnv(options),
    }, (error, stdout, stderr) => {
      // execFile reports any failure (non-zero exit, spawn error, timeout) as
      // a truthy error; the specific exit code never carries signal here —
      // stderr does — so every failure collapses to 1.
      resolvePromise({ code: error !== null ? 1 : 0, stdout: stdout ?? '', stderr: error?.killed ? `${stderr ?? ''}\n${TIMED_OUT}` : stderr || error?.message || '' })
    })
  })
}

/** What a live run keeps of each stream: git's progress redraws can run to
 * megabytes, but only the head of stdout and the tail of stderr (where the
 * failure is) are ever read back. */
const STDOUT_KEEP = 1024 * 1024
const STDERR_KEEP = 256 * 1024

/**
 * Stop git AND the transport processes it started. `child.kill()` alone
 * leaves them running on Windows (it is TerminateProcess on one pid), so a
 * cancelled fetch would keep downloading in the background; POSIX git cleans
 * up its own children on SIGTERM.
 */
function killProcessTree(child: ChildProcess): void {
  if (child.pid === undefined || child.exitCode !== null) return
  if (process.platform === 'win32') {
    const killer = spawn('taskkill', ['/pid', String(child.pid), '/T', '/F'], { windowsHide: true, stdio: 'ignore' })
    killer.on('error', () => { child.kill() })
    return
  }
  child.kill('SIGTERM')
}

/** Streaming executor: reports output as it arrives and honours a signal. */
function liveProcessExec(file: string, args: readonly string[], options: ExecOptions): Promise<ExecResult> {
  return new Promise((resolvePromise) => {
    if (options.signal?.aborted) {
      resolvePromise({ code: 1, stdout: '', stderr: '', cancelled: true })
      return
    }
    const child = spawn(file, args, { cwd: options.cwd, windowsHide: true, stdio: ['ignore', 'pipe', 'pipe'], ...execEnv(options) })
    let stdout = ''
    let stderr = ''
    let cancelled = false
    let timedOut = false
    let settled = false
    let idleTimer: NodeJS.Timeout | undefined
    let hardTimer: NodeJS.Timeout | undefined

    const result = (code: number): ExecResult => ({
      code: cancelled || timedOut ? 1 : code,
      stdout,
      stderr: timedOut ? `${stderr}\n${TIMED_OUT}` : stderr,
      ...cancelled ? { cancelled: true } : {},
    })
    const settle = (outcome: ExecResult): void => {
      if (settled) return
      settled = true
      clearTimeout(idleTimer)
      clearTimeout(hardTimer)
      options.signal?.removeEventListener('abort', onAbort)
      resolvePromise(outcome)
    }
    const stop = (): void => { killProcessTree(child) }
    const onAbort = (): void => { cancelled = true; stop() }
    const armIdle = (): void => {
      if (options.idleTimeoutMs === undefined) return
      clearTimeout(idleTimer)
      idleTimer = setTimeout(() => { timedOut = true; stop() }, options.idleTimeoutMs)
    }

    options.signal?.addEventListener('abort', onAbort, { once: true })
    if (options.timeoutMs !== undefined) hardTimer = setTimeout(() => { timedOut = true; stop() }, options.timeoutMs)
    armIdle()

    child.stdout.setEncoding('utf8')
    child.stderr.setEncoding('utf8')
    child.stdout.on('data', (chunk: string) => {
      if (stdout.length < STDOUT_KEEP) stdout += chunk
      armIdle()
      options.onOutput?.(chunk)
    })
    child.stderr.on('data', (chunk: string) => {
      stderr += chunk
      if (stderr.length > STDERR_KEEP * 2) stderr = stderr.slice(-STDERR_KEEP)
      armIdle()
      options.onOutput?.(chunk)
    })
    child.on('error', (error) => { settle({ code: 1, stdout, stderr: stderr || error.message }) })
    // A killed run settles on exit: a transport grandchild that outlived the
    // kill could hold the pipes open and postpone `close` indefinitely.
    child.on('exit', (code) => { if (cancelled || timedOut) settle(result(code ?? 1)) })
    child.on('close', (code) => { settle(result(code ?? 1)) })
  })
}

/** Run one git command; a non-zero exit raises {@link GitError} with stderr. */
async function git(exec: Exec, cwd: string, args: readonly string[]): Promise<string> {
  const result = await exec('git', args, { cwd })
  if (result.code !== 0) throw new GitError(args, result.code, result.stderr)
  return result.stdout
}

/** Run one git command, mapping a non-zero exit to undefined instead of throwing. */
async function gitMaybe(exec: Exec, cwd: string, args: readonly string[]): Promise<string | undefined> {
  const result = await exec('git', args, { cwd })
  return result.code === 0 ? result.stdout : undefined
}

/** Directory-existence seam over the parsed worktree registrations. */
export type DirExists = (path: string) => boolean

/** Real existence check. */
export const fsDirExists: DirExists = path => existsSync(path)

/**
 * Leftover-directory sweeper after `git worktree remove` unregisters but
 * fails the final rmdir (Windows EPERM when a process still has the folder
 * as cwd). `gone` = deleted; `empty` = still there but vacant (cwd hold);
 * `occupied` = still has files — the caller must not pretend removal finished.
 */
export type SweepDir = (path: string) => Promise<'gone' | 'empty' | 'occupied'>

/** Real leftover sweep: `fs.rm` with Windows EPERM retries, then classify. */
export async function fsSweepDir(path: string): Promise<'gone' | 'empty' | 'occupied'> {
  if (!existsSync(path)) return 'gone'
  try {
    await rm(path, { recursive: true, force: true, maxRetries: 8, retryDelay: 100 })
  } catch {
    // Retries exhausted; classify whatever is still on disk.
  }
  if (!existsSync(path)) return 'gone'
  try {
    return readdirSync(path).length === 0 ? 'empty' : 'occupied'
  } catch {
    return 'occupied'
  }
}

/** stderr of a git rmdir that lost to an OS file lock (not git's dirty check). */
function isDirBusyGitError(error: GitError): boolean {
  const text = error.stderr
  return /permission denied/i.test(text)
    || /\bEPERM\b/i.test(text)
    || /\bEACCES\b/i.test(text)
    || /\bEBUSY\b/i.test(text)
}

/**
 * Whether a directory IS the main worktree of its repository: exactly when
 * its own toplevel holds the SHARED `.git` that `--git-common-dir` names.
 * From a linked worktree that path resolves to the shared `<repo>/.git` too,
 * but its toplevel is the linked folder — so the two differ and the answer
 * is false.
 *
 * Deliberately NOT "is the first entry of `worktree list`": that list is
 * filtered by directory existence downstream (a stale main registration
 * would flip the answer), it costs a second git spawn, and its `main` flag
 * describes a different question — which entry git considers main, not
 * which directory was asked about. Same rule as {@link probeWorkspaceGit}
 * applies for the sidebar's grouping, extracted here so both answers are the
 * same answer.
 * @param toplevel - the queried directory's own `--show-toplevel`.
 * @param gitDir - the SHARED git dir (`--git-common-dir`) every worktree
 * resolves back to.
 */
/**
 * Whether two paths refer to the same directory on disk, accounting for
 * trailing slashes, slash directions, and Windows case-insensitivity.
 */
function isSamePath(a: string, b: string): boolean {
  const normA = normalize(resolve(a))
  const normB = normalize(resolve(b))
  return process.platform === 'win32'
    ? normA.toLowerCase() === normB.toLowerCase()
    : normA === normB
}

function isMainWorktree(toplevel: string, gitDir: string): boolean {
  return isSamePath(resolve(toplevel, '.git'), gitDir)
}

/**
 * Resolve a directory to repository facts, or undefined outside any git
 * repository (including the `git` binary missing: ENOENT surfaces as a
 * non-zero exit through the seam).
 * @param exec - executor seam.
 * @param path - absolute directory the workspace reports.
 * @param dirExists - existence seam for stale-registration filtering.
 */
/** One process for the three facts both probes need. On Windows each git
 * spawn costs tens of milliseconds before it does any work, so folding
 * these flags is the difference between one round trip and three. */
const REV_PARSE_FACTS = ['rev-parse', '--show-toplevel', '--git-common-dir', '--abbrev-ref', 'HEAD'] as const

export async function probeRepo(exec: Exec, path: string, dirExists: DirExists = fsDirExists): Promise<RepoFacts | undefined> {
  const probed = await gitMaybe(exec, path, REV_PARSE_FACTS)
  if (probed === undefined) return undefined
  const [top = '', common = '', branchName = ''] = probed.split('\n').map(line => line.trim())
  if (top === '' || common === '') return undefined
  // repoName comes from the shared .git location: a linked worktree's own
  // toplevel would name the branch folder, not the repository. Both git
  // outputs carry forward slashes on Windows — normalize every derived path.
  const toplevel = normalize(top)
  const gitDir = normalize(resolve(path, common))
  // Main worktree, not the queried directory: a linked worktree's
  // `--show-toplevel` is its own folder, which `git worktree remove` then
  // destroys (including `.git`). Later `worktree list` / `worktree prune`
  // must still run in a living git dir — the shared checkout
  // (`dirname(--git-common-dir)`), same grouping key as probeWorkspaceGit.
  const repoRoot = dirname(gitDir)
  // Branch list and worktree list do not depend on each other. listBranches
  // itself overlaps the local and remote ref walks.
  const [branches, worktrees] = await Promise.all([
    listBranches(exec, repoRoot),
    listWorktrees(exec, repoRoot),
  ])
  return {
    repoRoot,
    repoName: basename(dirname(gitDir)),
    toplevel,
    main: isMainWorktree(toplevel, gitDir),
    // `--abbrev-ref HEAD` prints the synthetic `HEAD` when detached or unborn,
    // which is the same answer an empty `branch --show-current` used to map to.
    currentBranch: branchName === '' || branchName === 'HEAD' ? 'HEAD' : branchName,
    branches,
    // A stale registration (directory removed behind git's back) must not
    // reach the UI as a real worktree — it would disable branch rows for a
    // folder that no longer exists.
    worktrees: worktrees.filter(w => dirExists(w.path)),
  }
}

/**
 * Local branches (each carrying its ahead/behind vs the upstream when one
 * exists) plus remote-only branches across EVERY remote (`<remote>/HEAD`
 * dropped).
 *
 * Track follows the refname (`[` is forbidden in refs); a tab separates
 * the configured upstream. Keeping the upstream and [gone] fact lets the
 * UI distinguish unpublished branches from synchronized and deleted ones.
 */
async function listBranches(exec: Exec, repoRoot: string): Promise<BranchEntry[]> {
  const [localOut, remoteOut] = await Promise.all([
    git(exec, repoRoot, ['for-each-ref', 'refs/heads', '--format=%(refname:short)%(upstream:track)%09%(upstream:short)']),
    gitMaybe(exec, repoRoot, ['for-each-ref', 'refs/remotes', '--format=%(refname:short)']),
  ])
  const entries: BranchEntry[] = []
  for (const line of localOut.split('\n')) {
    const [label = '', upstream = ''] = line.split('\t')
    const trimmed = label.trim()
    if (trimmed === '') continue
    const bracket = trimmed.indexOf('[')
    const name = (bracket === -1 ? trimmed : trimmed.slice(0, bracket)).trim()
    if (name === '') continue
    const track = bracket === -1 ? '' : trimmed.slice(bracket)
    const ahead = /\bahead (\d+)/.exec(track)
    const behind = /\bbehind (\d+)/.exec(track)
    const entry: BranchEntry = { name, kind: 'local' }
    if (upstream !== '') entry.upstream = upstream.trim()
    if (track === '[gone]') entry.upstreamGone = true
    if (ahead !== null) entry.ahead = Number(ahead[1])
    if (behind !== null) entry.behind = Number(behind[1])
    entries.push(entry)
  }
  if (remoteOut !== undefined) {
    // Local names as a Set: the twin lookup runs once per remote row, and a
    // linear scan over the assembled list would make the loop quadratic —
    // felt at thousand-branch repos, free to avoid.
    const localNames = new Set(entries.filter(e => e.kind === 'local').map(e => e.name))
    for (const line of remoteOut.split('\n')) {
      const name = line.trim()
      if (name === '') continue
      const localName = localBranchName(name)
      // A bare ref directly under refs/remotes (shortname without `/`, like
      // a leftover `refs/remotes/origin`) is not a remote branch — git
      // branch -r hides it, the menu must not offer it either.
      if (localName === name) continue
      // A remote branch with a local twin stays hidden: the twin is the
      // actionable row, showing both would duplicate it in the menu.
      if (localName === 'HEAD' || localNames.has(localName)) continue
      entries.push({ name, kind: 'remote' })
    }
  }
  return entries
}

/** Parse `git worktree list --porcelain` into entries, main first. */
async function listWorktrees(exec: Exec, repoRoot: string): Promise<WorktreeEntry[]> {
  const out = await git(exec, repoRoot, ['worktree', 'list', '--porcelain'])
  const entries: WorktreeEntry[] = []
  let path: string | undefined
  let branch: string | undefined
  let detached = false
  const flush = (): void => {
    if (path === undefined) return
    // Porcelain reports forward slashes on Windows; normalize so consumers
    // can compare against join()-built paths.
    entries.push({ path: normalize(path), branch: detached || branch === undefined ? undefined : branch.replace('refs/heads/', ''), main: entries.length === 0 })
    path = undefined
    branch = undefined
    detached = false
  }
  for (const line of out.split('\n')) {
    if (line.startsWith('worktree ')) {
      flush()
      path = line.slice('worktree '.length).trim()
    } else if (line.startsWith('branch ')) {
      branch = line.slice('branch '.length).trim()
    } else if (line === 'detached') {
      detached = true
    }
  }
  flush()
  return entries
}

/**
 * Resolve a branch display name against the authoritative branch list of the
 * repository. Exported for the /worktree route's fetch gate: the pre-create
 * remote sync only earns its round trip when the display name is REMOTE-only
 * (a local branch's worktree never consumes fetched refs).
 * @returns the local name plus the tracking remote when the display name is
 * remote-only, or undefined when neither shape exists.
 */
export async function resolveBranch(exec: Exec, repoRoot: string, branch: string): Promise<{ local: string; remote: string | undefined } | undefined> {
  const localsOut = await git(exec, repoRoot, ['for-each-ref', 'refs/heads', '--format=%(refname:short)'])
  const locals = localsOut.split('\n').map(l => l.trim()).filter(l => l !== '')
  if (locals.includes(branch)) return { local: branch, remote: undefined }
  // A name without `/` can never name a remote branch — `<remote>/<name>`
  // always carries the slash. This guards the leftover bare `refs/remotes/<x>`
  // ref too: matching it would compute a garbage remote part.
  if (!branch.includes('/')) return undefined
  const local = localBranchName(branch)
  if (local !== branch && locals.includes(local)) return undefined // the display names a remote, but the local twin exists: use the twin
  const remoteOut = await gitMaybe(exec, repoRoot, ['for-each-ref', 'refs/remotes', `refs/remotes/${branch}`, '--format=%(refname:short)'])
  if (remoteOut !== undefined && remoteOut.trim() !== '') return { local, remote: branch.slice(0, branch.length - local.length - 1) }
  return undefined
}

/**
 * Create (or reuse) the worktree for one branch.
 *
 * Idempotence: git allows one worktree per checked-out branch, so an existing
 * worktree already on `branch` (compared by local name) is returned unreused.
 * A local branch gets `git worktree add <path> <name>`; a remote-only branch
 * gets a new local twin via `git worktree add <path> -b <name> <remoteRef>`.
 * @param exec - executor seam.
 * @param repoRoot - main worktree directory.
 * @param branch - branch display name.
 * @param targetPath - absolute directory to create.
 * @returns the worktree path and whether this call created it.
 */
export async function addWorktree(
  exec: Exec,
  repoRoot: string,
  branch: string,
  targetPath: string,
  dirExists: DirExists = fsDirExists,
): Promise<{ path: string; created: boolean }> {
  const resolved = await resolveBranch(exec, repoRoot, branch)
  if (resolved === undefined) throw new GitError(['worktree', 'add'], 1, `branch "${branch}" not found`)
  let worktrees = await listWorktrees(exec, repoRoot)
  const existing = worktrees.find(w => w.branch === resolved.local)
  if (existing !== undefined && dirExists(existing.path)) return { path: existing.path, created: false }
  if (existing !== undefined) {
    // Stale registration: the directory is gone but git's administrative
    // record still claims the branch. Prune (git-side no-op when clean) and
    // re-read before creating, or `worktree add` would refuse the branch.
    await git(exec, repoRoot, ['worktree', 'prune'])
    worktrees = await listWorktrees(exec, repoRoot)
    const afterPrune = worktrees.find(w => w.branch === resolved.local)
    if (afterPrune !== undefined && dirExists(afterPrune.path)) return { path: afterPrune.path, created: false }
  }
  if (resolved.remote === undefined) {
    await git(exec, repoRoot, ['worktree', 'add', targetPath, resolved.local])
  } else {
    await git(exec, repoRoot, ['worktree', 'add', targetPath, '-b', resolved.local, branch])
  }
  return { path: targetPath, created: true }
}

/**
 * Plan a new branch name to cut out of `base`: `<base>-wt`, or the first
 * `-wt<N>` suffix not already taken (`main` → `main-wt`; if that exists,
 * `main-wt2`, …). One `for-each-ref` pass decides; the worktree folder
 * name derives from the returned name, so the caller should resolve it
 * BEFORE computing the target path. With `folderTaken` given, a name is
 * only free when its storage folder is free too: a leftover folder of a
 * since-deleted branch would otherwise fail `worktree add` with a bare
 * "already exists" — the suffix walk skips it the same way.
 * @param exec - executor seam.
 * @param repoRoot - main worktree directory.
 * @param base - base branch local name (or `HEAD` when detached).
 * @param folderTaken - storage-folder occupancy probe (branch name → taken).
 * @returns the free cutout branch name.
 */
export async function cutoutBranchName(
  exec: Exec,
  repoRoot: string,
  base: string,
  folderTaken?: (branch: string) => boolean,
): Promise<string> {
  const out = await git(exec, repoRoot, ['for-each-ref', 'refs/heads', '--format=%(refname:short)'])
  const locals = new Set(out.split('\n').map(l => l.trim()).filter(l => l !== ''))
  // `base` is the checked-out branch (`branch --show-current` output), which
  // never carries a remote prefix — pass it through verbatim so a local name
  // containing '/' survives.
  const free = (candidate: string): boolean =>
    !locals.has(candidate) && !(folderTaken?.(candidate) ?? false)
  const stem = `${base}-wt`
  if (free(stem)) return stem
  for (let i = 2; ; i += 1) {
    const candidate = `${stem}${i}`
    if (free(candidate)) return candidate
  }
}

/**
 * Create a worktree on a brand-new branch cut out of `base`: the base is
 * checked out by the main worktree (git forbids a second worktree on it),
 * so the new branch is created from it and checked out in the fresh
 * worktree instead.
 * @param exec - executor seam.
 * @param repoRoot - main worktree directory.
 * @param base - base branch local name (`main` or `HEAD`).
 * @param newBranch - the cutout branch name (see {@link cutoutBranchName}).
 * @param targetPath - absolute directory to create.
 */
export async function addWorktreeCutout(
  exec: Exec,
  repoRoot: string,
  base: string,
  newBranch: string,
  targetPath: string,
): Promise<void> {
  await git(exec, repoRoot, ['worktree', 'add', targetPath, '-b', newBranch, base])
}

/**
 * In-place branch switch of the main checkout. A remote display name relies
 * on git's dwim: `git switch <local>` creates the tracking branch when
 * exactly one remote has it.
 * @param exec - executor seam.
 * @param repoRoot - main worktree directory.
 * @param branch - branch display name.
 * @returns the local branch name now checked out.
 */
export async function switchBranch(exec: Exec, repoRoot: string, branch: string): Promise<string> {
  const resolved = await resolveBranch(exec, repoRoot, branch)
  if (resolved === undefined) throw new GitError(['switch'], 1, `branch "${branch}" not found`)
  try {
    await git(exec, repoRoot, ['switch', resolved.local])
  } catch (error) {
    // A stale worktree registration claims the branch; prune (no-op on a
    // healthy repo) and retry once — a live worktree still refuses, as it must.
    const stale = error instanceof GitError && error.stderr.includes('already used by worktree')
    if (!stale) throw error
    await git(exec, repoRoot, ['worktree', 'prune'])
    await git(exec, repoRoot, ['switch', resolved.local])
  }
  return resolved.local
}

/**
 * Create a NEW branch. Three shapes:
 *
 *   - no `from`: cut from the current checkout and check it out in place
 *     (`git switch -c`) — the cut point is whatever the queried directory's
 *     HEAD points at, so a detached or unborn checkout cuts from the current
 *     commit too. Runs at the queried directory's own toplevel — a session
 *     inside a linked worktree creates and checks out within that worktree,
 *     never the main checkout (the same semantics as {@link switchBranch}).
 *   - `from` without `checkout`: create AT that start point WITHOUT touching
 *     any checkout (`git branch`) — a create aimed at another branch must
 *     not move this session's HEAD.
 *   - `from` with `checkout`: create at the start point AND check it out
 *     here in one stroke (`git switch -c <name> <from>`).
 * @param exec - executor seam.
 * @param cwd - directory whose HEAD the branch is cut from (worktree toplevel).
 * @param name - new branch name (git validates; failures raise GitError).
 * @param from - optional start point; absent keeps the in-place semantics.
 * @param checkout - with `from`, also check the new branch out here.
 * @returns the branch name now created (checked out unless created at a
 * start point with `checkout` false).
 */
export async function createBranch(exec: Exec, cwd: string, name: string, from?: string, checkout = false): Promise<string> {
  if (from === undefined || checkout) {
    const startPoint = from === undefined ? [] : [from]
    await git(exec, cwd, ['switch', '-c', name, ...startPoint])
    return name
  }
  await git(exec, cwd, ['branch', name, from])
  return name
}

/**
 * Rename a LOCAL branch (`git branch -m`): branch refs are repository-wide,
 * so the command runs at the repository root and every worktree HEAD pointing
 * at the old name follows the ref. Git validates the new name and refuses a
 * target that already exists; remote branches are not renameable (not ours).
 * @param exec - executor seam.
 * @param repoRoot - main worktree directory.
 * @param name - branch to rename.
 * @param newName - the new local name.
 * @returns the new name.
 */
export async function renameBranch(exec: Exec, repoRoot: string, name: string, newName: string): Promise<string> {
  await git(exec, repoRoot, ['branch', '-m', name, newName])
  return newName
}

/**
 * Delete a LOCAL branch (`git branch -d`, the SAFE form): git refuses a
 * branch with unmerged commits ("not fully merged") and one checked out in
 * any worktree — both caller-side state, mapped to 400 by the route. No
 * `-D` force variant on purpose: a menu click must never discard commits
 * (the terminal is the place for deliberate force-deletes). Runs at the
 * repository root; remote branches are not ours to delete.
 * @param exec - executor seam.
 * @param repoRoot - main worktree directory.
 * @param name - branch to delete.
 * @returns the name of the branch that was deleted.
 */
export async function deleteBranch(exec: Exec, repoRoot: string, name: string): Promise<string> {
  await git(exec, repoRoot, ['branch', '-d', name])
  return name
}

/**
 * Sync remote-tracking refs: fetch every remote and prune tracking branches
 * the remotes no longer carry (the CLI equivalent of IDEA's "synchronize
 * remote branches"). Pure metadata — the working tree, local branches, and
 * the current checkout are untouched. A plain call is bounded by the
 * executor's hard timeout; a {@link LiveRun} lifts that for a transfer the
 * user can watch and cancel.
 * @param exec - executor seam.
 * @param repoRoot - main worktree directory (fetch is repository-wide).
 * @param live - optional live output / cancellation of this run.
 */
export async function fetchAll(exec: Exec, repoRoot: string, live?: LiveRun): Promise<void> {
  if (live === undefined) {
    await git(exec, repoRoot, FETCH_ARGS)
    return
  }
  // One fetch per remote instead of `--all --progress`: with several remotes
  // git runs a child per remote and never hands it `--progress`, so the
  // counters would silently vanish exactly in the fork setups that have them.
  // Like `--all`, a failing remote does not stop the others.
  let failure: { code: number; messages: string[] } | undefined
  for (const remote of await fetchableRemotes(exec, repoRoot)) {
    live.onRemote?.(remote)
    // `--progress` because git only draws its counters on a terminal otherwise.
    const result = await exec('git', ['fetch', remote, '--prune', '--progress'], { cwd: repoRoot, ...liveExecOptions(live) })
    if (result.cancelled) throw new CancelledError()
    if (result.code !== 0) {
      failure ??= { code: result.code, messages: [] }
      // git's words without the thousand progress redraws before them, and
      // under a head that names the remote and its address: `git fetch --all`
      // itself reports neither, and a remote whose address was moved out
      // from under it is the failure the user must act on.
      failure.messages.push(`remote "${remote}" (url: ${await remoteUrl(exec, repoRoot, remote)})\n${stripProgress(result.stderr)}`)
    }
  }
  // The error names the command the user knows, not the per-remote plumbing.
  if (failure !== undefined) throw new GitError(FETCH_ARGS, failure.code, failure.messages.join('\n'))
}

/** The fetch every plain sync runs. */
const FETCH_ARGS: readonly string[] = ['fetch', '--all', '--prune']

/**
 * The address one remote points at. Read only after that remote's fetch
 * failed: the address is the one fact the failure message needs, and a
 * healthy fetch never pays for it.
 * @param exec - executor seam.
 * @param repoRoot - main worktree directory.
 * @param remote - remote name.
 * @returns the remote's address, or an empty string when git cannot say.
 */
async function remoteUrl(exec: Exec, repoRoot: string, remote: string): Promise<string> {
  const url = await gitMaybe(exec, repoRoot, ['remote', 'get-url', remote])
  return url?.trim() ?? ''
}

/**
 * The remotes `git fetch --all` would visit: all of them except those marked
 * `remote.<name>.skipFetchAll` — a live run walks them itself.
 * @param exec - executor seam.
 * @param repoRoot - main worktree directory.
 * @returns remote names, in git's order.
 */
async function fetchableRemotes(exec: Exec, repoRoot: string): Promise<string[]> {
  const names = (await git(exec, repoRoot, ['remote'])).split('\n').map(line => line.trim()).filter(line => line !== '')
  const flags = await gitMaybe(exec, repoRoot, ['config', '--bool', '--get-regexp', '^remote\\..+\\.skipfetchall$'])
  const skipped = new Set<string>()
  for (const line of (flags ?? '').split('\n')) {
    const name = /^remote\.(.+)\.skipfetchall\s+true$/i.exec(line.trim())?.[1]
    if (name !== undefined) skipped.add(name)
  }
  return names.filter(name => !skipped.has(name))
}

/** A live run's patience with a silent git: long enough for a remote that
 * takes minutes to enumerate a huge repository (or a pre-push hook that runs
 * the test suite), short enough that a stuck connection is not left spinning
 * for good. */
export const LIVE_IDLE_TIMEOUT_MS = 5 * 60_000

/**
 * The executor options that make one git run live: no whole-run cap, only
 * {@link LIVE_IDLE_TIMEOUT_MS} of silence, plus the caller's output sink and
 * cancellation signal.
 * @param live - the run's live channel.
 * @returns options to spread into an {@link Exec} call (next to `cwd`).
 */
export function liveExecOptions(live: LiveRun): Pick<ExecOptions, 'idleTimeoutMs' | 'onOutput' | 'signal'> {
  return {
    idleTimeoutMs: LIVE_IDLE_TIMEOUT_MS,
    ...live.onOutput === undefined ? {} : { onOutput: live.onOutput },
    ...live.signal === undefined ? {} : { signal: live.signal },
  }
}

/** Watching and stopping one long git run (a fetch the UI shows progress for). */
export interface LiveRun {
  /** git's stdout and stderr text as it is written. */
  onOutput?: (chunk: string) => void
  /** The fetch moves on to this remote; its output follows. */
  onRemote?: (remote: string) => void
  /** Aborting kills git; the call then throws {@link CancelledError}. */
  signal?: AbortSignal
  /** The fetch is over and the fast-forward begins — the last step, which
   * is quick and not worth interrupting half way. */
  onMerge?: () => void
}

/** A live run its caller aborted — not a failure anyone needs to hear about. */
export class CancelledError extends Error {
  constructor() {
    super('Cancelled')
    this.name = 'CancelledError'
  }
}

/** Outcome of {@link updateBranch}: the branch touched and whether it moved. */
export interface UpdateOutcome {
  branch: string
  updated: boolean
}

/**
 * Update the CURRENT checkout: fetch every remote, then fast-forward the
 * branch checked out by `cwd` to its upstream (`@{u}`) — IDEA's "update
 * selected branch" in its default merge mode. Deliberately `--ff-only`:
 * a diverged local branch refuses rather than silently rebase/merge, and
 * uncommitted working-tree changes are git's own call to reject — the
 * plugin never stashes behind the user's back. Runs at the queried
 * directory's own toplevel, so a linked-worktree session updates the
 * branch ITS worktree holds.
 * @param exec - executor seam.
 * @param cwd - directory whose checked-out branch is updated.
 * @param live - optional live output / cancellation of the fetch step.
 * @returns the branch name and whether HEAD actually moved (false = the
 * upstream already contained it).
 */
export async function updateBranch(exec: Exec, cwd: string, live?: LiveRun): Promise<UpdateOutcome> {
  await fetchAll(exec, cwd, live)
  // Cancelled in the instant between the fetch ending and now: honour it,
  // never move the user's branch after they said stop.
  if (live?.signal?.aborted) throw new CancelledError()
  live?.onMerge?.()
  const before = (await git(exec, cwd, ['rev-parse', 'HEAD'])).trim()
  await git(exec, cwd, ['merge', '--ff-only', '@{u}'])
  const after = (await git(exec, cwd, ['rev-parse', 'HEAD'])).trim()
  const branch = (await gitMaybe(exec, cwd, ['branch', '--show-current']))?.trim() ?? ''
  return { branch, updated: before !== after }
}

/** Guard for route inputs: a non-empty absolute directory path. */
export function isAbsoluteDir(value: string): boolean {
  return value.trim() !== '' && isAbsolute(value)
}

/** Pre-delete facts of one worktree directory, for the remove-confirm dialog. */
export interface WorktreeInspect {
  /** Uncommitted-change file rows (`git status --porcelain` line count). */
  dirty: number
  /** Commits ahead of the branch's upstream; undefined when no upstream. */
  ahead: number | undefined
}

/**
 * Inspect one worktree directory for removal: how many files carry
 * uncommitted changes (those ARE lost with the folder), and how many commits
 * the checked-out branch leads its upstream by (informational only — the
 * branch ref survives `worktree remove`, so those are kept).
 * @param exec - executor seam.
 * @param worktreePath - the worktree directory (absolute).
 */
export async function inspectWorktree(exec: Exec, worktreePath: string): Promise<WorktreeInspect> {
  const status = await git(exec, worktreePath, ['status', '--porcelain'])
  const dirty = status.split('\n').filter(line => line.trim() !== '').length
  // No upstream (local-only branch) fails the rev-list — that is a normal
  // answer, not an error: ahead stays undefined.
  const aheadOut = await gitMaybe(exec, worktreePath, ['rev-list', '--count', '@{u}..HEAD'])
  const parsed = aheadOut === undefined ? Number.NaN : Number(aheadOut.trim())
  return { dirty, ahead: Number.isFinite(parsed) ? parsed : undefined }
}

/**
 * Remove one linked worktree: `git worktree remove` deletes the folder and
 * the registration in one stroke. A stale registration (folder already gone
 * behind git's back) resolves through `worktree prune` instead — the outcome
 * the user asked for either way, which keeps the route idempotent.
 * @param exec - executor seam.
 * @param repoRoot - main worktree directory.
 * @param worktreePath - the linked worktree directory to delete (absolute).
 * @param force - pass `--force` past uncommitted changes.
 * @param dirExists - existence seam for the stale-registration branch.
 * @param sweepDir - leftover rmdir after git unregisters but the OS holds the
 * folder (Windows Permission denied on the empty directory).
 * @returns the path plus whether only a stale registration was pruned.
 * @throws GitError for the main worktree, an unregistered path, or a refused
 * removal (git's own stderr verbatim).
 */
export async function removeWorktree(
  exec: Exec,
  repoRoot: string,
  worktreePath: string,
  force: boolean,
  dirExists: DirExists = fsDirExists,
  sweepDir: SweepDir = fsSweepDir,
): Promise<{ path: string; pruned: boolean }> {
  const target = normalize(worktreePath)
  const worktrees = await listWorktrees(exec, repoRoot)
  const registered = worktrees.find(w => w.path === target)
  if (registered === undefined) {
    throw new GitError(['worktree', 'remove'], 1, `"${target}" is not a registered worktree of this repository`)
  }
  if (registered.main) {
    throw new GitError(['worktree', 'remove'], 1, 'cannot remove the main worktree')
  }
  if (!dirExists(target)) {
    // Stale registration: the folder is already gone, so removal means
    // clearing git's administrative record — exactly what prune does.
    await git(exec, repoRoot, ['worktree', 'prune'])
    return { path: target, pruned: true }
  }
  try {
    await git(exec, repoRoot, force ? ['worktree', 'remove', '--force', target] : ['worktree', 'remove', target])
    return { path: target, pruned: false }
  } catch (error) {
    // Windows: git often unregisters the worktree and empties the tree,
    // then fails the last rmdir (`Permission denied`) because some process
    // still has the folder as cwd. `--force` does not help — that flag only
    // bypasses dirty/lock checks, not OS handles. Relist from `repoRoot`
    // (the main checkout, which still has `.git`); listing from the target
    // path would throw "not a git repository" once git has stripped its
    // `.git`. If the registration is already gone, the git side is done;
    // sweep the leftover and succeed so the DSH archive+unregister half
    // can run. A still-occupied leftover (files remain) is a real refusal.
    if (!(error instanceof GitError) || !isDirBusyGitError(error)) throw error
    const remaining = (await listWorktrees(exec, repoRoot)).find(w => w.path === target)
    if (remaining !== undefined) throw error
    if (!dirExists(target)) return { path: target, pruned: false }
    const leftover = await sweepDir(target)
    if (leftover === 'occupied') throw error
    return { path: target, pruned: false }
  }
}

/**
 * Lightweight git belonging probe for ONE workspace directory: the three
 * facts the sidebar grouping needs and nothing else (no branch list, no
 * worktree list — {@link probeRepo} stays the full-facts path for the chip).
 *
 * All three facts come from ONE `git rev-parse` invocation: the sidebar
 * probes every registered workspace on each mount, and on Windows every git
 * call is a process spawn, so three sequential spawns per directory made the
 * startup probe cost scale with the workspace count directly. `rev-parse`
 * evaluates each flag in turn and prints one line per answer, so
 * `--show-toplevel`, `--git-common-dir`, and `--abbrev-ref HEAD` fold into a
 * single process.
 *
 * `repoRoot` — the grouping key — is derived from `--git-common-dir`, which
 * names the SHARED `<repo>/.git` from every worktree of the repository: the
 * main checkout reports it directly, a linked worktree reports the path back
 * to it. Both therefore resolve to the same repository root and group
 * together, wherever the linked folder physically lives.
 * `main` is decided without `worktree list`: a directory is the main worktree
 * exactly when its own toplevel holds that shared .git.
 * `branch` uses `--abbrev-ref HEAD`, whose detached/unborn output is git's
 * synthetic `HEAD` — normalized to null HERE so no consumer downstream ever
 * string-compares against it (the same contract the old `branch
 * --show-current` empty output mapped to).
 * @param exec - executor seam.
 * @param path - absolute directory the workspace reports.
 * @returns the facts, or undefined outside any git repository (a missing git
 * binary surfaces the same way — a non-zero exit through the seam).
 */
export async function probeWorkspaceGit(exec: Exec, path: string): Promise<WorkspaceGitFacts | undefined> {
  const out = await gitMaybe(exec, path, REV_PARSE_FACTS)
  if (out === undefined) return undefined
  const lines = out.split('\n').map(line => line.trim())
  const top = lines[0] ?? ''
  const commonDir = lines[1] ?? ''
  const branchName = lines[2] ?? ''
  if (top === '' || commonDir === '') return undefined
  const toplevel = normalize(top)
  // A directory whose git toplevel is an ancestor is an ordinary subdirectory,
  // not an independent worktree or repository root.
  if (!isSamePath(toplevel, path)) return undefined
  // Git outputs carry forward slashes on Windows — normalize every derived
  // path so consumers can compare against join()-built ones.
  const gitDir = normalize(resolve(path, commonDir))
  return {
    repoRoot: dirname(gitDir),
    repoName: basename(dirname(gitDir)),
    branch: branchName === '' || branchName === 'HEAD' ? null : branchName,
    main: isMainWorktree(toplevel, gitDir),
  }
}

/** The one local-ignore rule the project-internal worktree layout needs.
 * Exactly this pattern — NOT `/.dsh/` — so project-level `.dsh/` files a user
 * may want to commit stay trackable. */
export const WORKTREE_EXCLUDE_RULE = '/.dsh/gitworktree/'

/** fs seams for {@link appendWorktreeExclude}; tests substitute. */
export interface ExcludeSeams {
  /** Whole file as UTF-8 text; a missing file reads as '' (the rule is
   * simply not there yet). */
  readFile: (path: string) => Promise<string>
  /** Append text to the end of the file, creating it when missing. */
  appendFile: (path: string, text: string) => Promise<void>
  /** Recursive mkdir for the `info` directory (git init ships it; a stripped
   * or hand-moved clone may not). */
  mkdir: (path: string) => Promise<void>
}

/** Real fs-backed seams. */
export const fsExcludeSeams: ExcludeSeams = {
  readFile: async (path) => {
    try {
      return await readFile(path, 'utf8')
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code === 'ENOENT') return ''
      throw error
    }
  },
  appendFile: async (path, text) => {
    await appendFile(path, text, 'utf8')
  },
  mkdir: async (path) => {
    await mkdir(path, { recursive: true })
  },
}

/**
 * Idempotently add {@link WORKTREE_EXCLUDE_RULE} to the repository's local
 * ignore file (`<repo>/.git/info/exclude`, reachable from every worktree
 * because it lives in the SHARED git dir): the git-blessed place for rules
 * that must stay private to this clone — never committed, never cloned.
 *
 * The write never blocks a worktree creation (the folder cannot be rolled
 * back once built), so a failure is returned as text for the response to
 * carry, not thrown. Idempotent by full-content line match: an absent rule
 * is appended behind a newline guard so it never glues onto the user's last
 * line; an existing rule — or any pre-existing content — is left untouched.
 * @param seams - fs seams (tests substitute).
 * @param repoRoot - the repository's main worktree directory.
 * @returns undefined on success (or the rule already being present); the
 * failure text otherwise.
 */
export async function appendWorktreeExclude(seams: ExcludeSeams, repoRoot: string): Promise<string | undefined> {
  try {
    const infoDir = join(repoRoot, '.git', 'info')
    const excludePath = join(infoDir, 'exclude')
    const text = await seams.readFile(excludePath)
    if (!text.split(/\r?\n/).includes(WORKTREE_EXCLUDE_RULE)) {
      await seams.mkdir(infoDir)
      const prefix = text === '' || text.endsWith('\n') ? '' : '\n'
      await seams.appendFile(excludePath, `${prefix}${WORKTREE_EXCLUDE_RULE}\n`)
    }
    return undefined
  } catch (error) {
    return error instanceof Error ? error.message : String(error)
  }
}
