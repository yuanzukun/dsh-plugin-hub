/**
 * Route logic as pure functions: query/body in, status+body out. The HTTP
 * shell (index.ts) owns req/res mechanics; everything testable lives here.
 */

import { basename, dirname, join, resolve } from 'node:path'
import { mkdir, readdir, rm, stat } from 'node:fs/promises'
import { runPostCreateCopy, type CopyFilesSeams } from './copy-files.js'
import { appendWorktreeExclude, fsExcludeSeams, CancelledError, GitError, addWorktree, addWorktreeCutout, createBranch, cutoutBranchName, deleteBranch, fetchAll, fsDirExists, inspectWorktree, isAbsoluteDir, probeRepo, probeWorkspaceGit, removeWorktree, renameBranch, resolveBranch, switchBranch, updateBranch, type DirExists, type ExcludeSeams, type Exec, type LiveRun } from './git.js'
import { readCheckedOutBranch } from './head.js'
import { openPush, previewPush, pushBranch } from './push.js'
import { isAbsoluteConfigPath, sanitizeBranchDir } from './normalize.js'
import { createProgressReader } from './progress.js'
import { resolveRootDir } from './settings.js'
import type {
  CreateBranchBody, CreateBranchResult, CreateWorktreeBody, CreateWorktreeResult, DeleteBranchBody, DeleteBranchResult, EnsureDirectoryBody, EnsureDirectoryResult, FetchBody, FetchResult, GroupWorkspacesResult, HeadStatus, InspectWorktreeBody, InspectWorktreeResult, PathExistsResult, PushBody, PushPlan, PushPreview, PushPreviewBody, PushResult, PushPlanBody, PurgeDirectoryBody, PurgeDirectoryResult, RemoveWorktreeBody, RemoveWorktreeResult, RenameBranchBody, RenameBranchResult, RepoStatus, RouteError, SwitchBody, SwitchResult, SyncEvent, UpdateBody, UpdateResult, WorktreesAllResult,
} from './wire.js'

/** Everything the handlers need from the host half. */
export interface RouteDeps {
  exec: Exec
  /** The settings-resolved rootDir (absent/blank = the default location). */
  sectionRootDir: () => string | undefined
  /** Whether a worktree creation syncs the remotes first (absent = off). */
  sectionFetchBeforeCreate: () => boolean | undefined
  /** Post-create configuration files to copy when .worktreeinclude is absent. */
  sectionPostCreateCopyFiles?: () => string[] | undefined
  /** User home directory seam. */
  home: () => string
  /** `$DSH_HOME` environment value seam. */
  envHome: () => string | undefined
  /** Worktree-registration existence seam (tests substitute). */
  dirExists?: DirExists
  /** Local-ignore write seams (tests substitute). */
  excludeSeams?: ExcludeSeams
  /** Post-create file copy seams (tests substitute). */
  copyFilesSeams?: CopyFilesSeams
  /** Directory probe seam over fs.stat (true = exists AND is a directory);
   * tests substitute. */
  statDirectory?: (path: string) => Promise<boolean>
  /** Recursive mkdir seam (fs.mkdir recursive); tests substitute. */
  mkdirRecursive?: (path: string) => Promise<void>
  /** One-level directory listing seam (fs.readdir with dirents); tests
   * substitute. */
  listDir?: (path: string) => Promise<string[]>
  /** Recursive force rm seam (fs.rm with retries); tests substitute. */
  rmRecursive?: (path: string) => Promise<void>
}

/** Real fs-backed one-level directory listing (names only). Plain FILES are
 * filtered out — the storage root can carry strays (a legacy settings.json
 * was seen in the wild), and the scan lists worktree SLOTS, not entries. */
export async function fsListDir(path: string): Promise<string[]> {
  try {
    const dirents = await readdir(path, { withFileTypes: true })
    return dirents.filter(entry => entry.isDirectory()).map(entry => entry.name)
  } catch {
    // A missing storage root is the "no worktrees yet" answer, not an error.
    return []
  }
}

/** Real fs-backed directory probe: exists and is a directory. */
export async function fsStatDirectory(path: string): Promise<boolean> {
  try {
    return (await stat(path)).isDirectory()
  } catch {
    return false
  }
}

/** Real fs-backed recursive mkdir. */
export async function fsMkdirRecursive(path: string): Promise<void> {
  await mkdir(path, { recursive: true })
}

/** One route outcome: HTTP status plus the JSON body. */
export interface RouteOutcome {
  status: number
  body: PushPlan | PushPreview | PushResult | RepoStatus | HeadStatus | CreateWorktreeResult | SwitchResult | CreateBranchResult | FetchResult | UpdateResult | GroupWorkspacesResult | InspectWorktreeResult | RemoveWorktreeResult | PathExistsResult | EnsureDirectoryResult | WorktreesAllResult | PurgeDirectoryResult | RouteError
}

/** Uniform failure envelope. */
function fail(status: number, error: string): RouteOutcome {
  return { status, body: { error } }
}

/** Upper bound on distinct paths one /group request may probe. */
const GROUP_PATHS_LIMIT = 256

/** Probes per in-flight batch — polite on Windows, where each git call is a
 * process spawn. The probe itself is a single `rev-parse` per directory, so
 * the batch can ride wider than the old three-spawn shape without stacking
 * an unreasonable number of concurrent git processes. */
const GROUP_BATCH_SIZE = 16

/** Upper bound on children one /worktrees-all scan probes. The storage root
 * is this plugin's own slot directory, so a healthy one stays far below;
 * the cap exists so a root pointed at something enormous (a misconfigured
 * rootDir, a home directory) cannot turn one dialog open into thousands of
 * git spawns. Past it the scan answers its first slice plus `truncated`. */
const SCAN_CHILDREN_LIMIT = 512

/**
 * POST /group — git belonging facts for a batch of workspace directories.
 * Deduplicates, validates, probes in bounded batches, and answers 200 with
 * per-path facts (null for non-repositories); a repository-wide git failure
 * is a per-path null, never a 500 — the sidebar must degrade to flat, not
 * error out.
 * @param deps - host dependencies.
 * @param body - parsed request body: `{ paths }`.
 */
export async function handleGroupWorktrees(deps: RouteDeps, body: unknown): Promise<RouteOutcome> {
  if (typeof body !== 'object' || body === null || Array.isArray(body)) return fail(400, 'request body must be a JSON object')
  const paths = (body as Record<string, unknown>).paths
  if (!Array.isArray(paths)) return fail(400, 'body key "paths" must be an array of absolute directories')
  const unknownKeys = Object.keys(body as Record<string, unknown>).filter(key => key !== 'paths')
  if (unknownKeys.length > 0) return fail(400, `unknown body key "${unknownKeys[0]}"`)
  const distinct: string[] = []
  for (const candidate of paths) {
    if (typeof candidate !== 'string' || !isAbsoluteDir(candidate)) return fail(400, 'body key "paths" must be an array of absolute directories')
    if (!distinct.includes(candidate)) distinct.push(candidate)
  }
  if (distinct.length > GROUP_PATHS_LIMIT) return fail(400, `body key "paths" accepts at most ${String(GROUP_PATHS_LIMIT)} distinct directories`)

  const facts: Record<string, GroupWorkspacesResult['facts'][string]> = {}
  for (let start = 0; start < distinct.length; start += GROUP_BATCH_SIZE) {
    const batch = distinct.slice(start, start + GROUP_BATCH_SIZE)
    const probed = await Promise.all(batch.map(async (path) => {
      // A probe never throws here by contract (gitMaybe folds non-zero exits),
      // but a defensive catch keeps ONE bad path from sinking the batch.
      try {
        return [path, await probeWorkspaceGit(deps.exec, path) ?? null] as const
      } catch {
        return [path, null] as const
      }
    }))
    for (const [path, value] of probed) facts[path] = value
  }
  return { status: 200, body: { facts } }
}

/** The project-internal layout directory name every repository uses. */
const PROJECT_LAYOUT_DIR = join('.dsh', 'gitworktree')

/**
 * Whether `canonical` sits DIRECTLY inside a `<repo>/.dsh/gitworktree`
 * layout root whose repository actually exists on disk. The layout names its
 * own owner (two levels up must hold a `.git`), so no workspace list is
 * needed to gate the plugin's territory — a plain fs probe decides.
 */
function insideProjectLayout(canonical: string, dirExists: DirExists): boolean {
  const layout = dirname(canonical)
  if (basename(layout) !== 'gitworktree') return false
  const dsh = dirname(layout)
  if (basename(dsh) !== '.dsh') return false
  return dirExists(join(dirname(dsh), '.git'))
}

/**
 * POST /worktrees-all — git facts for every DIRECT child directory of the two
 * storage locations the plugin has ever used, merged:
 *
 * - legacy: the resolved central storage root (today a read-only historical
 *   location — existing worktrees stay put, `rootDir` still resolves it);
 * - project: `<repo>/.dsh/gitworktree` under every DISTINCT repository root
 *   derived from the caller's registered workspace paths (the current
 *   layout — its path prefix is what the workspace tree nests under).
 *
 * The management dialog's data source (and, through it, the lazy prune's):
 * one scan answers for all repositories at once, orphan directories included
 * (a child that probes as no git repository comes back with null facts
 * rather than being dropped — the dialog shows it as unrecognized). Missing
 * locations answer their half as an empty list; per-child probe failures
 * degrade to null facts, never a 500 — the dialog must render, not error
 * out. Each location that holds more than {@link SCAN_CHILDREN_LIMIT}
 * children answers its first slice, and any truncation marks the whole
 * response `truncated`, so a misconfigured location cannot turn one dialog
 * open into thousands of git spawns.
 * @param deps - host dependencies.
 * @param body - parsed request body: `{ workspaces? }`.
 */
export async function handleWorktreesAll(deps: RouteDeps, body: unknown): Promise<RouteOutcome> {
  if (typeof body !== 'object' || body === null || Array.isArray(body)) return fail(400, 'request body must be a JSON object')
  const workspacesRaw = (body as Record<string, unknown>).workspaces ?? []
  if (!Array.isArray(workspacesRaw)) return fail(400, 'body key "workspaces" must be an array of absolute directories')
  const unknownKeys = Object.keys(body as Record<string, unknown>).filter(key => key !== 'workspaces')
  if (unknownKeys.length > 0) return fail(400, `unknown body key "${unknownKeys[0]}"`)
  const workspaces: string[] = []
  for (const candidate of workspacesRaw) {
    if (typeof candidate !== 'string' || !isAbsoluteDir(candidate)) return fail(400, 'body key "workspaces" must be an array of absolute directories')
    if (!workspaces.includes(candidate)) workspaces.push(candidate)
  }
  if (workspaces.length > GROUP_PATHS_LIMIT) return fail(400, `body key "workspaces" accepts at most ${String(GROUP_PATHS_LIMIT)} distinct directories`)

  const listDir = deps.listDir ?? fsListDir
  const facts: WorktreesAllResult['worktrees'] = []
  let truncated = false
  const scanLocation = async (root: string, source: 'legacy' | 'project'): Promise<void> => {
    const listed = await listDir(root)
    if (listed.length > SCAN_CHILDREN_LIMIT) {
      truncated = true
      listed.length = SCAN_CHILDREN_LIMIT
    }
    for (let start = 0; start < listed.length; start += GROUP_BATCH_SIZE) {
      const batch = listed.slice(start, start + GROUP_BATCH_SIZE)
      const probed = await Promise.all(batch.map(async (child) => {
        const path = join(root, child)
        try {
          const gitFacts = await probeWorkspaceGit(deps.exec, path)
          return gitFacts === undefined
            ? { path, repoName: null, branch: null, source }
            : { path, repoName: gitFacts.repoName, branch: gitFacts.branch, source }
        } catch {
          return { path, repoName: null, branch: null, source }
        }
      }))
      facts.push(...probed)
    }
  }

  const legacyRoot = resolveRootDir(deps.sectionRootDir(), deps.home(), deps.envHome())
  await scanLocation(legacyRoot, 'legacy')
  const statDirectory = deps.statDirectory ?? fsStatDirectory
  const legacyRootExists = await statDirectory(legacyRoot)

  // Project half: one belonging probe per DISTINCT workspace path (bounded
  // batches, same as /group), then one scan per DISTINCT repository root.
  const repoRoots = new Set<string>()
  for (let start = 0; start < workspaces.length; start += GROUP_BATCH_SIZE) {
    const batch = workspaces.slice(start, start + GROUP_BATCH_SIZE)
    const probed = await Promise.all(batch.map(async (path) => {
      try {
        return await probeWorkspaceGit(deps.exec, path)
      } catch {
        return undefined
      }
    }))
    for (const workspaceFacts of probed) {
      if (workspaceFacts !== undefined) repoRoots.add(workspaceFacts.repoRoot)
    }
  }
  for (const repoRoot of repoRoots) {
    await scanLocation(join(repoRoot, PROJECT_LAYOUT_DIR), 'project')
  }

  return { status: 200, body: { worktrees: facts, legacyRoot, legacyRootExists, ...truncated ? { truncated } : {} } }
}

/** Real fs-backed recursive force rm (Windows file-lock retries included). */
export async function fsRmRecursive(path: string): Promise<void> {
  await rm(path, { recursive: true, force: true, maxRetries: 8, retryDelay: 100 })
}

/** Create the layout root through the deps seam (tests substitute a no-op). */
function mkdirSlot(deps: RouteDeps, layoutRoot: string): Promise<void> {
  const mkdirRecursive = deps.mkdirRecursive ?? fsMkdirRecursive
  return mkdirRecursive(layoutRoot)
}

/**
 * POST /purge — delete a NON-git directory sitting DIRECTLY inside one of the
 * plugin's two storage layouts: the legacy central root or a repository's
 * `.dsh/gitworktree`. The orphaned leftover a half-failed `worktree remove`
 * can leave behind (git registration and the .git file already gone,
 * contents stranded on disk). Triple-gated: one level below a storage
 * location (resolved forms, same slot boundary as /ensure-directory), a real
 * directory, and NOT a git repository — anything git still recognizes must
 * go through /remove, where the removal carries the session-archive and
 * unregistration half. Deletion is a plain recursive force rm.
 * @param deps - host dependencies.
 * @param body - parsed request body: `{ path }`.
 */
export async function handlePurgeDirectory(deps: RouteDeps, body: unknown): Promise<RouteOutcome> {
  const parsed = readBody<PurgeDirectoryBody>(body, ['path'])
  if (isOutcome(parsed)) return parsed
  const { path } = parsed
  if (!isAbsoluteDir(path)) return fail(400, '"path" must be an absolute directory')
  const configured = deps.sectionRootDir()?.trim()
  if (configured !== undefined && configured !== '' && !isAbsoluteConfigPath(configured)) {
    return fail(400, `configured rootDir "${String(deps.sectionRootDir())}" is not an absolute path`)
  }
  const rootDir = resolveRootDir(deps.sectionRootDir(), deps.home(), deps.envHome())
  const canonical = resolve(path)
  if (dirname(canonical) !== resolve(rootDir) && !insideProjectLayout(canonical, deps.dirExists ?? fsDirExists)) {
    return fail(400, `"${canonical}" is outside the plugin's worktree storage locations`)
  }
  const statDirectory = deps.statDirectory ?? fsStatDirectory
  if (!(await statDirectory(canonical))) {
    return fail(400, `"${canonical}" is not a directory`)
  }
  const gitFacts = await probeWorkspaceGit(deps.exec, canonical)
  if (gitFacts !== undefined) {
    return fail(400, `"${canonical}" is a git repository; remove it as a worktree instead`)
  }
  const rmRecursive = deps.rmRecursive ?? fsRmRecursive
  try {
    await rmRecursive(canonical)
    return { status: 200, body: { path: canonical, removed: true } }
  } catch (error) {
    return fail(500, error instanceof Error ? error.message : String(error))
  }
}

/** GitError to outcome: usage-shaped failures are 400, the rest 500. */
function gitFailure(error: GitError): RouteOutcome {
  const usage = error.stderr.includes('usage:')
    || error.stderr.includes('fatal: invalid')
    // A user-typed branch name git refuses (`'bad..name' is not a valid
    // branch name`) is caller misuse, not a host fault — the client
    // pre-flights the same rules, this is the backstop.
    || error.stderr.includes('not a valid branch name')
    // A name or storage folder that already exists is caller misuse too
    // (a stale worktree folder survives its branch's deletion): the client
    // pre-flights branch duplicates, this is the backstop.
    || error.stderr.includes('already exists')
    // Diverged/branchless states an update cannot fast-forward through are
    // the user's repo state, not host faults: no upstream to merge, a
    // detached HEAD, or local commits `--ff-only` must not paper over.
    || error.stderr.includes('Not possible to fast-forward')
    || error.stderr.includes('no tracking information')
    || error.stderr.includes("unknown revision")
    // A display name that resolves to no branch at all (a stale row the
    // menu no longer shows) is caller-side state, not a host fault. The
    // failure is the SYNTHETIC GitError from git.ts (`branch "x" not
    // found`), so match its `branch "` shape — git's own "not found"
    // texts (a remote that vanished mid-fetch: `Repository '...' not
    // found`) carry no quoted branch and stay 500 host faults.
    || error.stderr.includes('branch "')
    // Deletion refusals from `git branch -d` are the user's repo state the
    // same way: unmerged commits (the safe delete's whole point) and a
    // branch checked out in some worktree.
    || error.stderr.includes('is not fully merged')
    || error.stderr.includes('Cannot delete branch')
    // Removal refusals from git.ts are caller-side state the same way: the
    // main worktree (git refuses it too, but the route answers a clean 400
    // before ever spawning git) and a path the repository never registered
    // (a stale sidebar row racing a terminal-side removal).
    || error.stderr.includes('cannot remove the main worktree')
    || error.stderr.includes('is not a registered worktree')
  return fail(usage ? 400 : 500, error.message)
}

/**
 * GET /status 鈥?repository facts for one directory.
 * @param deps - host dependencies.
 * @param path - absolute directory the workspace reports.
 */
export async function handleStatus(deps: RouteDeps, path: string | undefined): Promise<RouteOutcome> {
  if (path === undefined || !isAbsoluteDir(path)) return fail(400, 'query parameter "path" must be an absolute directory')
  const facts = await probeRepo(deps.exec, path, deps.dirExists)
  const rootDir = resolveRootDir(deps.sectionRootDir(), deps.home(), deps.envHome())
  if (facts === undefined) return { status: 200, body: { repo: false } }
  return {
    status: 200,
    body: {
      repo: true,
      repoName: facts.repoName,
      repoRoot: facts.repoRoot,
      main: facts.main,
      currentBranch: facts.currentBranch,
      branches: facts.branches,
      worktrees: facts.worktrees,
      rootDir,
    },
  }
}

/**
 * GET /head — the checked-out branch of one directory, from the HEAD file.
 * `pending` is a skipped tick: the caller keeps the label it already has.
 * @param path - absolute directory the workspace reports.
 */
export async function handleHead(path: string | undefined): Promise<RouteOutcome> {
  if (path === undefined || !isAbsoluteDir(path)) return fail(400, 'query parameter "path" must be an absolute directory')
  const read = await readCheckedOutBranch(path)
  if (read.kind === 'absent') return { status: 200, body: { repo: false } }
  if (read.kind === 'unread') return { status: 200, body: { repo: true, pending: true } }
  return { status: 200, body: { repo: true, currentBranch: read.name } }
}

/** Validate a JSON body object with exactly the expected keys. */
function readBody<T>(
  body: unknown,
  keys: readonly (keyof T & string)[],
  booleanKeys: readonly (keyof T & string)[] = [],
  optionalKeys: readonly (keyof T & string)[] = [],
): T | RouteOutcome {
  if (typeof body !== 'object' || body === null || Array.isArray(body)) return fail(400, 'request body must be a JSON object')
  const record = body as Record<string, unknown>
  for (const key of Object.keys(record)) {
    if (!keys.includes(key as keyof T & string) && !booleanKeys.includes(key as keyof T & string) && !optionalKeys.includes(key as keyof T & string)) {
      return fail(400, `unknown body key "${key}"`)
    }
  }
  for (const key of keys) {
    if (typeof record[key] !== 'string') return fail(400, `body key "${key}" must be a string`)
  }
  for (const key of booleanKeys) {
    // Optional flag: absent stays absent (`cutout?: boolean`), present must type-check.
    if (record[key] !== undefined && typeof record[key] !== 'boolean') {
      return fail(400, `body key "${key}" must be a boolean`)
    }
  }
  for (const key of optionalKeys) {
    // Optional string: absent stays absent (`name?: string`), present must type-check.
    if (record[key] !== undefined && typeof record[key] !== 'string') {
      return fail(400, `body key "${key}" must be a string`)
    }
  }
  return record as T
}

/** Discriminator: a RouteOutcome carries the `status`/`body` pair no request body has. */
function isOutcome(value: unknown): value is RouteOutcome {
  return typeof value === 'object' && value !== null && 'status' in value && 'body' in value
}

/**
 * POST /worktree — create or reuse the worktree for a branch, then report the
 * directory so the client can register it as a workspace. The worktree lands
 * at `<repo>/.dsh/gitworktree/<branch>` (path prefix = repository, so the
 * native workspace tree nests it under its repository automatically); an
 * existing registration for the branch ANYWHERE is reused first (the
 * repository-wide worktree list is location-independent — legacy-central
 * worktrees keep being returned, never duplicated). With `cutout: true` the
 * branch is the CURRENT checkout (occupied by the main worktree, so git
 * refuses to add it): a new branch is cut out of it (`<branch>-wt`, first
 * free `-wt<N>` suffix) and isolated in the fresh worktree instead.
 * @param deps - host dependencies.
 * @param body - parsed request body.
 */
export async function handleCreateWorktree(deps: RouteDeps, body: unknown): Promise<RouteOutcome> {
  const parsed = readBody<CreateWorktreeBody>(body, ['repoPath', 'branch'], ['cutout'], ['name'])
  if (isOutcome(parsed)) return parsed
  const { repoPath, branch, cutout, name } = parsed
  if (!isAbsoluteDir(repoPath)) return fail(400, '"repoPath" must be an absolute directory')
  if (branch.trim() === '') return fail(400, '"branch" must be non-empty')
  try {
    const facts = await probeRepo(deps.exec, repoPath, deps.dirExists)
    if (facts === undefined) return fail(400, `"${repoPath}" is not inside a git repository`)
    // Local-ignore first, creation second: the rule is harmless when the
    // creation later fails (the directory simply does not exist), while the
    // reverse order leaves a created worktree visible as untracked on the
    // next `git status` when the write fails. A write failure never blocks
    // the creation — the worktree cannot be rolled back — it rides the
    // successful response as `excludeWarning` for the client to toast.
    const excludeWarning = await appendWorktreeExclude(deps.excludeSeams ?? fsExcludeSeams, facts.repoRoot)
    const layoutRoot = join(facts.repoRoot, PROJECT_LAYOUT_DIR)
    // Optional pre-create remote sync — but only when the branch actually
    // consumes remote data: a LOCAL branch's worktree (or an existing twin)
    // never reads the fetched refs, so the resolve runs first and the fetch
    // fires just for the remote-only shape (the twin `worktree add -b`
    // consumes it, the cutout's arbitrary base too). Deliberately NOT a
    // gate: a network hiccup must not block the creation — the failure
    // rides the successful response as `fetchWarning` for the client to
    // toast.
    let fetchWarning: string | undefined
    if (deps.sectionFetchBeforeCreate() === true) {
      const resolved = await resolveBranch(deps.exec, facts.repoRoot, branch)
      if (resolved?.remote !== undefined) {
        try {
          await fetchAll(deps.exec, facts.repoRoot)
        } catch (error) {
          fetchWarning = error instanceof GitError ? error.stderr.trim() : error instanceof Error ? error.message : String(error)
        }
      }
    }
    const warnings = { ...fetchWarning === undefined ? {} : { fetchWarning }, ...excludeWarning === undefined ? {} : { excludeWarning } }
    if (cutout === true) {
      // An explicit name skips the `-wt` suffix walk and is used verbatim —
      // both for the branch and the storage folder. A leading dash would
      // ride `worktree add -b` as a flag; any other git-invalid name
      // surfaces through the error envelope (the client pre-flights).
      const custom = name?.trim()
      if (custom !== undefined && custom !== '') {
        if (custom.startsWith('-')) return fail(400, '"name" must not start with "-"')
        const target = join(layoutRoot, sanitizeBranchDir(custom))
        await mkdirSlot(deps, layoutRoot)
        await addWorktreeCutout(deps.exec, facts.repoRoot, branch, custom, target)
        const copyWarning = await runPostCreateCopy(deps, facts.repoRoot, target)
        const copyWarnObj = copyWarning !== undefined ? { copyWarning } : {}
        return { status: 200, body: { path: target, created: true, ...warnings, ...copyWarnObj } }
      }
      // The new branch name must be known before the folder name can be
      // computed: the folder carries the NEW branch's directory name. The
      // name must be free in BOTH namespaces — the branch table and the
      // storage folder: a leftover folder of a since-deleted branch would
      // otherwise fail `worktree add` with a bare "already exists", so the
      // suffix walk probes the folder too.
      const dirExists = deps.dirExists ?? fsDirExists
      const newBranch = await cutoutBranchName(deps.exec, facts.repoRoot, branch, (candidate) =>
        dirExists(join(layoutRoot, sanitizeBranchDir(candidate))),
      )
      const target = join(layoutRoot, sanitizeBranchDir(newBranch))
      await mkdirSlot(deps, layoutRoot)
      await addWorktreeCutout(deps.exec, facts.repoRoot, branch, newBranch, target)
      const copyWarning = await runPostCreateCopy(deps, facts.repoRoot, target)
      const copyWarnObj = copyWarning !== undefined ? { copyWarning } : {}
      return { status: 200, body: { path: target, created: true, ...warnings, ...copyWarnObj } }
    }
    // The folder name carries the branch: `<repo>/.dsh/gitworktree/<branch>`.
    const target = join(layoutRoot, sanitizeBranchDir(branch))
    await mkdirSlot(deps, layoutRoot)
    const result = await addWorktree(deps.exec, facts.repoRoot, branch, target, deps.dirExists)
    let copyWarning: string | undefined
    if (result.created) {
      copyWarning = await runPostCreateCopy(deps, facts.repoRoot, result.path)
    }
    const copyWarnObj = copyWarning !== undefined ? { copyWarning } : {}
    return { status: 200, body: { ...result, ...warnings, ...copyWarnObj } }
  } catch (error) {
    if (error instanceof GitError) return gitFailure(error)
    return fail(500, error instanceof Error ? error.message : String(error))
  }
}

/**
 * POST /switch 鈥?in-place branch switch of the main checkout.
 * @param deps - host dependencies.
 * @param body - parsed request body.
 */
export async function handleSwitch(deps: RouteDeps, body: unknown): Promise<RouteOutcome> {
  const parsed = readBody<SwitchBody>(body, ['repoPath', 'branch'])
  if (isOutcome(parsed)) return parsed
  const { repoPath, branch } = parsed
  if (!isAbsoluteDir(repoPath)) return fail(400, '"repoPath" must be an absolute directory')
  if (branch.trim() === '') return fail(400, '"branch" must be non-empty')
  try {
    const facts = await probeRepo(deps.exec, repoPath, deps.dirExists)
    if (facts === undefined) return fail(400, `"${repoPath}" is not inside a git repository`)
    const switched = await switchBranch(deps.exec, facts.repoRoot, branch)
    const result: SwitchResult = { branch: switched }
    return { status: 200, body: result }
  } catch (error) {
    if (error instanceof GitError) return gitFailure(error)
    return fail(500, error instanceof Error ? error.message : String(error))
  }
}

/**
 * POST /branch — create a NEW branch. Without `from`, from the queried
 * directory's current checkout (whatever its HEAD points at, detached
 * included), checked out in place. With `from` (a local branch or a remote
 * tracking ref): checked out here too when `checkout` is set
 * (`git switch -c <name> <from>`), created with no checkout touched
 * otherwise (`git branch`) — a create aimed at another branch must not
 * silently move the session's HEAD unless the caller asked for exactly
 * that. Git validates both names; the client pre-flights the same rules
 * and only sends names it already accepts.
 * @param deps - host dependencies.
 * @param body - parsed request body.
 */
export async function handleCreateBranch(deps: RouteDeps, body: unknown): Promise<RouteOutcome> {
  const parsed = readBody<CreateBranchBody>(body, ['repoPath', 'name'], ['checkout'], ['from'])
  if (isOutcome(parsed)) return parsed
  const { repoPath, name, from, checkout } = parsed
  if (!isAbsoluteDir(repoPath)) return fail(400, '"repoPath" must be an absolute directory')
  if (name.trim() === '') return fail(400, '"name" must be non-empty')
  // A leading dash would ride `git switch -c` as a flag — reject before the
  // exec, not as an "unknown switch" GitError.
  if (name.startsWith('-')) return fail(400, '"name" must not start with "-"')
  // The same flag-ride guard for the start point, which lands on
  // `git branch <name> <from>` verbatim (a remote ref like `origin/x` is
  // the caller's legitimate shape — passed through untouched).
  if (from !== undefined) {
    if (from.trim() === '') return fail(400, '"from" must be non-empty when present')
    if (from.startsWith('-')) return fail(400, '"from" must not start with "-"')
  }
  try {
    const facts = await probeRepo(deps.exec, repoPath, deps.dirExists)
    if (facts === undefined) return fail(400, `"${repoPath}" is not inside a git repository`)
    // The session's OWN worktree: the no-`from` shape cuts from — and checks
    // out in — the queried directory's HEAD, and `from` + `checkout` checks
    // out HERE. `repoRoot` would move the main checkout instead of the
    // worktree the session sits in (identical directory when it IS the main
    // checkout).
    const created = await createBranch(deps.exec, facts.toplevel, name, from, checkout === true)
    const result: CreateBranchResult = { branch: created }
    return { status: 200, body: result }
  } catch (error) {
    if (error instanceof GitError) return gitFailure(error)
    return fail(500, error instanceof Error ? error.message : String(error))
  }
}

/**
 * POST /branch-rename — rename a LOCAL branch (`git branch -m`). Runs at the
 * repository root: branch refs are repository-wide and worktree HEADs
 * pointing at the old name follow the ref. Git validates the new name and
 * refuses a target that already exists; both map to 400 through
 * {@link gitFailure}.
 * @param deps - host dependencies.
 * @param body - parsed request body.
 */
export async function handleRenameBranch(deps: RouteDeps, body: unknown): Promise<RouteOutcome> {
  const parsed = readBody<RenameBranchBody>(body, ['repoPath', 'name', 'newName'])
  if (isOutcome(parsed)) return parsed
  const { repoPath, name, newName } = parsed
  if (!isAbsoluteDir(repoPath)) return fail(400, '"repoPath" must be an absolute directory')
  if (name.trim() === '') return fail(400, '"name" must be non-empty')
  if (newName.trim() === '') return fail(400, '"newName" must be non-empty')
  // Same flag-ride guard as the create route: the new name lands on
  // `git branch -m <name> <newName>` verbatim.
  if (newName.startsWith('-')) return fail(400, '"newName" must not start with "-"')
  try {
    const facts = await probeRepo(deps.exec, repoPath, deps.dirExists)
    if (facts === undefined) return fail(400, `"${repoPath}" is not inside a git repository`)
    const renamed = await renameBranch(deps.exec, facts.repoRoot, name, newName)
    const result: RenameBranchResult = { branch: renamed }
    return { status: 200, body: result }
  } catch (error) {
    if (error instanceof GitError) return gitFailure(error)
    return fail(500, error instanceof Error ? error.message : String(error))
  }
}

/**
 * POST /branch-delete — delete a LOCAL branch with the SAFE form
 * (`git branch -d`): git refuses unmerged commits and branches checked out
 * in any worktree, both mapping to 400 through {@link gitFailure}. No
 * force variant — a menu click must never discard commits.
 * @param deps - host dependencies.
 * @param body - parsed request body.
 */
export async function handleDeleteBranch(deps: RouteDeps, body: unknown): Promise<RouteOutcome> {
  const parsed = readBody<DeleteBranchBody>(body, ['repoPath', 'name'])
  if (isOutcome(parsed)) return parsed
  const { repoPath, name } = parsed
  if (!isAbsoluteDir(repoPath)) return fail(400, '"repoPath" must be an absolute directory')
  if (name.trim() === '') return fail(400, '"name" must be non-empty')
  // Same flag-ride guard as its sibling routes: the name lands on
  // `git branch -d <name>` verbatim.
  if (name.startsWith('-')) return fail(400, '"name" must not start with "-"')
  try {
    const facts = await probeRepo(deps.exec, repoPath, deps.dirExists)
    if (facts === undefined) return fail(400, `"${repoPath}" is not inside a git repository`)
    const deleted = await deleteBranch(deps.exec, facts.repoRoot, name)
    const result: DeleteBranchResult = { branch: deleted }
    return { status: 200, body: result }
  } catch (error) {
    if (error instanceof GitError) return gitFailure(error)
    return fail(500, error instanceof Error ? error.message : String(error))
  }
}

/**
 * The live side of a long route: events out while it runs, and a signal in
 * when the caller leaves. The HTTP shell owns both ends (stream and socket);
 * the handlers only emit and pass the signal on to git.
 */
export interface RouteLive {
  /** Aborted when the caller goes away — git is killed and the route answers
   * 499 to nobody. */
  signal: AbortSignal
  /** Send one event to the caller. */
  emit: (event: SyncEvent) => void
}

/**
 * Translate a route's live channel into a git {@link LiveRun}: git's raw
 * output goes through the progress reader, so the caller sees structured,
 * throttled events instead of a thousand `\r` redraws.
 * @param live - the route's channel; absent for a plain, non-streamed call.
 * @returns the run to hand to git (undefined = no live behaviour) and `end`,
 * which flushes the reader's last held observation.
 */
function startLive(live: RouteLive | undefined): { run: LiveRun | undefined; end: () => void } {
  if (live === undefined) return { run: undefined, end: () => undefined }
  const reader = createProgressReader(progress => { live.emit({ type: 'progress', ...progress }) })
  return {
    run: {
      onOutput: (chunk) => { reader.feed(chunk) },
      onRemote: (remote) => { reader.remote(remote) },
      signal: live.signal,
      // The merge event must come after the last progress line, not before.
      onMerge: () => { reader.end(); live.emit({ type: 'merge' }) },
    },
    end: () => { reader.end() },
  }
}

/**
 * POST /fetch — sync remote-tracking refs for the repository: fetch every
 * remote and prune tracking branches the remotes no longer carry. Pure
 * metadata — the working tree and the current checkout are untouched; the
 * client refetches /status afterwards for the fresh branch list.
 * @param deps - host dependencies.
 * @param body - parsed request body.
 * @param live - the streaming channel (absent = the plain request).
 */
export async function handleFetch(deps: RouteDeps, body: unknown, live?: RouteLive): Promise<RouteOutcome> {
  const parsed = readBody<FetchBody>(body, ['repoPath'])
  if (isOutcome(parsed)) return parsed
  const { repoPath } = parsed
  if (!isAbsoluteDir(repoPath)) return fail(400, '"repoPath" must be an absolute directory')
  const { run, end } = startLive(live)
  try {
    const facts = await probeRepo(deps.exec, repoPath, deps.dirExists)
    if (facts === undefined) return fail(400, `"${repoPath}" is not inside a git repository`)
    await fetchAll(deps.exec, facts.repoRoot, run)
    const result: FetchResult = { remote: 'all' }
    return { status: 200, body: result }
  } catch (error) {
    if (error instanceof CancelledError) return fail(499, error.message)
    if (error instanceof GitError) return gitFailure(error)
    return fail(500, error instanceof Error ? error.message : String(error))
  } finally {
    end()
  }
}

/**
 * POST /push-plan — read-only destination resolution for one local branch,
 * bundled with a display-only local snapshot of what it would push (see
 * `openPush`). Publishing is a separate explicit POST.
 * @param deps - host dependencies.
 * @param body - parsed request body: `{ repoPath, branch }`.
 */
export async function handlePushPlan(deps: RouteDeps, body: unknown): Promise<RouteOutcome> {
  return handlePushAction(deps, body, false)
}

/**
 * POST /push — push one explicit local branch to an explicit destination
 * (or, without one, to the confirmation-free default of `planPush`).
 * @param deps - host dependencies.
 * @param body - parsed request body.
 * @param live - the streaming channel (absent = the plain request, which
 * keeps its two-minute cap).
 */
export async function handlePush(deps: RouteDeps, body: unknown, live?: RouteLive): Promise<RouteOutcome> {
  return handlePushAction(deps, body, true, live)
}

/**
 * POST /push-preview — the commits one explicit remote/target would receive,
 * read from the real push destination (or from local tracking refs with
 * `localOnly`, which never touches the network). Pushes nothing.
 * @param deps - host dependencies.
 * @param body - parsed request body.
 */
export async function handlePushPreview(deps: RouteDeps, body: unknown): Promise<RouteOutcome> {
  const parsed = readBody<PushPreviewBody>(body, ['repoPath', 'branch', 'remote', 'target'], ['localOnly'])
  if (isOutcome(parsed)) return parsed
  if (!isAbsoluteDir(parsed.repoPath) || !parsed.branch.trim() || !parsed.remote?.trim() || !parsed.target?.trim()) return fail(400, 'An absolute repoPath, branch, remote and target are required')
  try {
    return { status: 200, body: await previewPush(deps.exec, parsed.repoPath, { ...parsed, remote: parsed.remote, target: parsed.target }) }
  } catch (error) {
    return fail(400, error instanceof Error ? error.message : String(error))
  }
}

async function handlePushAction(deps: RouteDeps, body: unknown, execute: boolean, live?: RouteLive): Promise<RouteOutcome> {
  const parsed = readBody<PushBody & PushPlanBody>(body, ['repoPath', 'branch'], execute ? ['force'] : [], execute ? ['remote', 'target', 'tags', 'expectedTarget', 'sourceOid'] : [])
  if (isOutcome(parsed)) return parsed
  if (!isAbsoluteDir(parsed.repoPath)) return fail(400, '"repoPath" must be an absolute directory')
  if (parsed.branch.trim() === '') return fail(400, '"branch" must be non-empty')
  if (parsed.tags !== undefined && !['none', 'all', 'follow'].includes(parsed.tags)) return fail(400, '"tags" must be none, all or follow')
  if (parsed.sourceOid !== undefined && !/^(?:[a-f0-9]{40}|[a-f0-9]{64})$/.test(parsed.sourceOid)) return fail(400, '"sourceOid" must be a full object ID')
  if ((parsed.remote === undefined) !== (parsed.target === undefined)) return fail(400, '"remote" and "target" must be provided together')
  if (parsed.remote !== undefined && (typeof parsed.remote !== 'string' || parsed.remote.trim() === ''
    || typeof parsed.target !== 'string' || parsed.target.trim() === '')) return fail(400, '"remote" and "target" must be non-empty strings')
  const { run, end } = startLive(execute ? live : undefined)
  try {
    return { status: 200, body: execute
      ? await pushBranch(deps.exec, parsed.repoPath, parsed, run)
      : await openPush(deps.exec, parsed.repoPath, parsed.branch) }
  } catch (error) {
    // Stopped by the caller: not a failure, and nobody is left to read it.
    if (error instanceof CancelledError) return fail(499, error.message)
    return fail(400, error instanceof Error ? error.message : String(error))
  } finally {
    end()
  }
}

/**
 * POST /update — update the CURRENT checkout: fetch every remote, then
 * fast-forward the branch checked out by the queried directory to its
 * upstream. Divergence, a missing upstream, and conflicting working-tree
 * changes all surface as 400 envelopes carrying git's own explanation.
 * @param deps - host dependencies.
 * @param body - parsed request body.
 * @param live - the streaming channel (absent = the plain request).
 */
export async function handleUpdate(deps: RouteDeps, body: unknown, live?: RouteLive): Promise<RouteOutcome> {
  const parsed = readBody<UpdateBody>(body, ['repoPath'])
  if (isOutcome(parsed)) return parsed
  const { repoPath } = parsed
  if (!isAbsoluteDir(repoPath)) return fail(400, '"repoPath" must be an absolute directory')
  const { run, end } = startLive(live)
  try {
    const facts = await probeRepo(deps.exec, repoPath, deps.dirExists)
    if (facts === undefined) return fail(400, `"${repoPath}" is not inside a git repository`)
    // The session's OWN worktree, not the main checkout: in a linked-worktree
    // session "update current branch" means the branch that worktree holds.
    // `repoRoot` would fast-forward the main checkout behind the user's back
    // (both are the same directory when the session IS the main checkout).
    const outcome = await updateBranch(deps.exec, facts.toplevel, run)
    const result: UpdateResult = { branch: outcome.branch, updated: outcome.updated }
    return { status: 200, body: result }
  } catch (error) {
    if (error instanceof CancelledError) return fail(499, error.message)
    if (error instanceof GitError) return gitFailure(error)
    return fail(500, error instanceof Error ? error.message : String(error))
  } finally {
    end()
  }
}

/**
 * POST /inspect — pre-delete facts for one worktree directory: the
 * uncommitted-file count (those die with the folder) and the checked-out
 * branch's ahead count (kept — the branch ref survives the removal).
 * Deliberately repo-wide neutral: any directory inside a repository answers,
 * so the dialog data stays meaningful even for odd shapes.
 * @param deps - host dependencies.
 * @param body - parsed request body: `{ path }`.
 */
export async function handleInspectWorktree(deps: RouteDeps, body: unknown): Promise<RouteOutcome> {
  const parsed = readBody<InspectWorktreeBody>(body, ['path'])
  if (isOutcome(parsed)) return parsed
  const { path } = parsed
  if (!isAbsoluteDir(path)) return fail(400, '"path" must be an absolute directory')
  try {
    const facts = await probeRepo(deps.exec, path, deps.dirExists)
    if (facts === undefined) return fail(400, `"${path}" is not inside a git repository`)
    const inspected = await inspectWorktree(deps.exec, path)
    const result: InspectWorktreeResult = { dirty: inspected.dirty, ...inspected.ahead === undefined ? {} : { ahead: inspected.ahead } }
    return { status: 200, body: result }
  } catch (error) {
    if (error instanceof GitError) return gitFailure(error)
    return fail(500, error instanceof Error ? error.message : String(error))
  }
}

/**
 * POST /remove — delete one linked worktree: git's registration plus the
 * folder in one stroke (`worktree remove`, `--force` past uncommitted
 * changes the dialog already showed). DSH-side cleanup (archiving the
 * workspace's sessions, dropping the workspace registration) is the
 * browser's follow-up, by design: git first, so a refused removal leaves
 * the workspace world untouched.
 * @param deps - host dependencies.
 * @param body - parsed request body: `{ path, force? }`.
 */
export async function handleRemoveWorktree(deps: RouteDeps, body: unknown): Promise<RouteOutcome> {
  const parsed = readBody<RemoveWorktreeBody>(body, ['path'], ['force'])
  if (isOutcome(parsed)) return parsed
  const { path, force } = parsed
  if (!isAbsoluteDir(path)) return fail(400, '"path" must be an absolute directory')
  try {
    const facts = await probeRepo(deps.exec, path, deps.dirExists)
    if (facts === undefined) return fail(400, `"${path}" is not inside a git repository`)
    const result = await removeWorktree(deps.exec, facts.repoRoot, path, force === true, deps.dirExists)
    return { status: 200, body: result }
  } catch (error) {
    if (error instanceof GitError) return gitFailure(error)
    return fail(500, error instanceof Error ? error.message : String(error))
  }
}

/**
 * POST /exists — batch directory-existence probe over plain fs (no git): true
 * per path that exists AND is a directory. The browser gates the
 * register-as-workspace action on this, so a missing folder (deleted, moved,
 * or a corrupted session-header cwd) is answered by THIS route — the DSH
 * workspace API never sees an unregistrable path.
 * @param deps - host dependencies.
 * @param body - parsed request body: `{ paths }`.
 */
export async function handlePathExists(deps: RouteDeps, body: unknown): Promise<RouteOutcome> {
  if (typeof body !== 'object' || body === null || Array.isArray(body)) return fail(400, 'request body must be a JSON object')
  const paths = (body as Record<string, unknown>).paths
  if (!Array.isArray(paths)) return fail(400, 'body key "paths" must be an array of absolute directories')
  const unknownKeys = Object.keys(body as Record<string, unknown>).filter(key => key !== 'paths')
  if (unknownKeys.length > 0) return fail(400, `unknown body key "${unknownKeys[0]}"`)
  const distinct: string[] = []
  for (const candidate of paths) {
    if (typeof candidate !== 'string' || !isAbsoluteDir(candidate)) return fail(400, 'body key "paths" must be an array of absolute directories')
    if (!distinct.includes(candidate)) distinct.push(candidate)
  }
  if (distinct.length > GROUP_PATHS_LIMIT) return fail(400, `body key "paths" accepts at most ${String(GROUP_PATHS_LIMIT)} distinct directories`)
  const statDirectory = deps.statDirectory ?? fsStatDirectory
  const exists: PathExistsResult['exists'] = {}
  await Promise.all(distinct.map(async (path) => {
    // One bad path must not sink the batch: a probe that throws reads as
    // "not a directory" — exactly the gating answer the client needs.
    exists[path] = await statDirectory(path).catch(() => false)
  }))
  // Rebuildability is a STORAGE-SLOT fact, not a general one: only a missing
  // path sitting DIRECTLY inside one of the plugin's storage locations (the
  // legacy root, or a repository's `.dsh/gitworktree`) is a slot this plugin
  // planned, so recreating the empty directory is safe self-healing (its
  // sessions reattach by realpath once the folder is back). Paths outside
  // both are the user's own territory — never rebuilt here.
  const rootDir = resolveRootDir(deps.sectionRootDir(), deps.home(), deps.envHome())
  const dirExists = deps.dirExists ?? fsDirExists
  const rebuildable: PathExistsResult['rebuildable'] = {}
  for (const path of distinct) {
    if (exists[path]) continue
    rebuildable[path] = dirname(resolve(path)) === resolve(rootDir) || insideProjectLayout(resolve(path), dirExists)
  }
  return { status: 200, body: { exists, ...Object.values(rebuildable).some(Boolean) ? { rebuildable } : {} } }
}

/**
 * POST /ensure-directory — recreate a MISSING worktree storage slot
 * (`mkdir -p`). Strictly gated to paths sitting DIRECTLY inside one of the
 * plugin's two storage layouts (the legacy central root, or a repository's
 * `.dsh/gitworktree`): those slots were planned and created by this plugin,
 * so rebuilding the empty folder is self-healing (historical sessions
 * reattach automatically once realpath matches again — DSH keeps the
 * workspace accounting and filters membership by the session header's cwd).
 * Anything else is outside this plugin's territory and is refused, so a
 * corrupted session-header cwd can never be materialized as stray folders.
 * @param deps - host dependencies.
 * @param body - parsed request body: `{ path }`.
 */
export async function handleEnsureDirectory(deps: RouteDeps, body: unknown): Promise<RouteOutcome> {
  const parsed = readBody<EnsureDirectoryBody>(body, ['path'])
  if (isOutcome(parsed)) return parsed
  const { path } = parsed
  if (!isAbsoluteDir(path)) return fail(400, '"path" must be an absolute directory')
  const configured = deps.sectionRootDir()?.trim()
  if (configured !== undefined && configured !== '' && !isAbsoluteConfigPath(configured)) {
    return fail(400, `configured rootDir "${String(deps.sectionRootDir())}" is not an absolute path`)
  }
  const rootDir = resolveRootDir(deps.sectionRootDir(), deps.home(), deps.envHome())
  const canonical = resolve(path)
  // Exactly one level below a storage location, compared on resolved forms
  // so `..` and spelling drift cannot escape the slot boundary.
  if (dirname(canonical) !== resolve(rootDir) && !insideProjectLayout(canonical, deps.dirExists ?? fsDirExists)) {
    return fail(400, `"${canonical}" is outside the plugin's worktree storage locations`)
  }
  const mkdirRecursive = deps.mkdirRecursive ?? fsMkdirRecursive
  try {
    const statDirectory = deps.statDirectory ?? fsStatDirectory
    if (await statDirectory(canonical)) return { status: 200, body: { created: true } }
    await mkdirRecursive(canonical)
    return { status: 200, body: { created: true } }
  } catch (error) {
    return fail(500, error instanceof Error ? error.message : String(error))
  }
}
