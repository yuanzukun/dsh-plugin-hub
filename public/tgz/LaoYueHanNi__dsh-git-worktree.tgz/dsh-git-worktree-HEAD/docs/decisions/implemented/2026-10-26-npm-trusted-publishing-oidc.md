# DR: npm 发布改用 Trusted Publishing（OIDC 免 token）

Status: implemented

## Problem

本仓库的 tag 触发流水线原计划用 granular access token 存入 GitHub Secret `NPM_TOKEN`，但仓库 Secrets 实际为空，workflow 从落地起就缺少可用凭据，发布链路从未真正跑通——要发版仍需先去 npm 造 token、再逐仓库配置 Secret。与此同时 npm 已公告收紧绕过 2FA 的 token（2026 年 8 月起限制账户变更，2027 年 1 月起限制直接发布），把长期发布凭据押在这种 token 上，等于押注一条会被政策收回的通道。

同账号的 `@laoyuehanni/dsh-token-usage` 已于 2026-10-26 改用 Trusted Publishing 并完成首次发布验证，路径与踩过的坑都已确认，本插件可直接复用而不必重新试错。

Trusted Publisher（OIDC）让 npm 在发布时按"仓库 + 工作流文件"换取短期令牌，仓库侧不存任何长期凭据。但它不是零成本：连接的 provider 与必填字段创建后不可修改，只能删除重建；连接建立后还有验证期限，逾期没有完成一次发布，npm 会把它视为未验证而失效。

## Decision

在 npm 包 `@laoyuehanni/dsh-git-worktree` 的包设置中建立 Trusted Publisher 连接：Publisher 为 GitHub Actions，组织或用户 `LaoYueHanNi`，仓库 `dsh-git-worktree`，工作流文件名 `publish.yml`，Environment name 留空（仓库未使用 GitHub Environment），允许 `npm publish`、`npm stage publish`、`npm dist-tag` 三项权限——前两项覆盖正式发布与 rc 的 `npm stage publish`，`npm dist-tag` 覆盖 rc 版的 `--tag next`。

CI 侧 `.github/workflows/publish.yml` 删除 `NODE_AUTH_TOKEN: ${{ secrets.NPM_TOKEN }}`，不再向发布步骤注入任何凭据，令牌由 npm CLI 用 OIDC 现场换取；因 setup-node 自带的 npm 版本偏旧，流程在发布前显式执行 `npm install -g npm@latest`（Trusted Publishing 要求 npm CLI 11.5.1 及以上）。`--provenance` 与 `permissions.id-token: write` 保留不变。

`actions/setup-node` 刻意不配置 `registry-url`：一配它，setup-node 就会写入 `.npmrc` 并注入占位 `NODE_AUTH_TOKEN`，那个假 token 会让 npm 认为已有静态凭据而跳过 OIDC 换取流程，发布时报 `401 Unauthorized ... token is invalid`；npm 默认 registry 即 `registry.npmjs.org`，无需额外指定。发布步骤同时显式把 `NODE_AUTH_TOKEN` 置空，确保 OIDC 是唯一认证路径。

本机手动发布的退路不变，且不需要新造长期凭据：npm 官网登录态支持交互式 WebAuthn / OTP 二次认证，本机 `npm publish` 走这条路径即可，无需绕过 2FA 的 token。因此仓库 Secrets 可以保持为空。

该连接已于 2026-10-26 由 `0.4.13` tag 触发的首次发布验证通过，npm 侧状态由 Pending validation 变为 Valid，验证窗口不再构成期限。

## Alternatives considered

- **继续用 granular access token 存进 `NPM_TOKEN`** —— 要在 GitHub Secrets 长期保管一份可发布凭据，轮换与泄露风险随时间累积；npm 已公告限制绕过 2FA 的 token，2027 年 1 月后该路径可能直接失效，届时发布链路要整体重建。输在把发布可用性押在一份会被政策收回的凭据上。
- **保持原 DR"暂缓迁移"的结论不动** —— 同账号 token-usage 已把 Trusted Publishing 走通并留下踩坑记录，两条链路并存会让"到底哪条才是发布路径"变得含糊；而 Secrets 为空这一事实说明 token 方案至今未落地。继续暂缓等于让一条不可用的路径继续占据决策记录。输在没有换来任何确定性。
- **改为本机 `npm login` 后手动发布，不要 CI 发布** —— 丢失"发布产物 ↔ 提交 ↔ tag"的一一对应，无法从 git 历史回溯某个版本从哪个 commit、哪个环境发出，也失去在干净环境强制 typecheck / test / 构建这道发布前质量门。输在可追溯性。
- **Trusted Publisher 同时配 GitHub Environment 隔离**（填 Environment name 并在 workflow 声明 `environment:`）—— 隔离更强，还能加审批与保护规则，但要多建一个 environment 并维护其规则，与单人维护的仓库复杂度不匹配；信任范围已由"仓库路径 + 工作流文件名"限定。输在收益不抵运维成本。

## Consequences

- 换来：CI 发布不再需要任何长期凭据，仓库 Secrets 为空也能发版；npm 收紧绕过 2FA token 的政策变化不再影响发布链路；包页面的 provenance 指向确切的仓库与工作流；同账号两个插件的发布路径就此统一，排查问题时只有一条链路要看。
- 代价：发布能力绑定到 npm 包侧的 Trusted Publisher 连接——provider 与必填字段创建后不可改，只能删除重建；建立后有验证期限（npm 给出的窗口约 48 小时），逾期未发布则连接失效需重新配置；仓库名、workflow 文件名或 CI 平台任一变化都会让连接失效。
