# DR: 工作树菜单行补齐上游落后超前指示并在试行后评估保留

Status: implemented

## Problem

在分支弹出菜单（`BranchMenu`）中，普通本地分支行会在右侧直观展示该分支相对于上游（upstream）的领先与落后计数箭头（如 `↑1`、`↓2`，参见 [本地分支行尾展示上游领先落后标记（↑N/↓N）](2026-08-30-ahead-behind-marks.md)）。然而，当分支被工作树检出后，它会被分类移动到「工作树」分组行展示。

此前客户端在从后端 `RepoStatus` 组装工作树行数据模型（`BranchRow`）时，未将对应本地分支已计算完毕的 `ahead`/`behind` 计数带入工作树行对象；同时，工作树扁平行渲染器（`renderFlatLeaf`）也遗漏了调用 `renderArrows(row)`。这导致同一分支在未建树时可清晰感知上游差异，一旦建立工作树后该指示便突然消失，破坏了视觉与信息一致性。

此外，针对工作树的未提交变更（dirty）状态，若在每次打开分支菜单时主动探测所有工作树的 `git status`，会导致弹窗伴随大量并发子进程开销（特别是在 Windows 平台），破坏菜单秒开的轻量交互体验。

## Decision

1. **工作树行数据透传**：在 `BranchChip` 的 `buildBranchRows` 和 `buildLinkedWorktreeRows` 中组装 `kind === 'worktree'` 条目时，通过 `w.branch` 在 `branches` 列表中检索同名本地分支，将其 `ahead` 与 `behind` 属性透传至 `BranchRow` 模型中。在 linked worktree 会话中，主工作树（`w.main: true`）同样通过主分支继承对应的 `ahead`/`behind` 计数。
2. **工作树扁平行渲染**：在 `BranchMenu` 的 `renderFlatLeaf` 中调用 `{renderArrows(row)}`，复用 `.menuRowArrow` 样式与 tooltip 文案，保持与普通本地分支一致的视觉表现；2026-10-15 起箭头和 upstream/gone 字段按[显式推送与 IDEA 同步箭头](2026-10-15-branch-push-and-colored-tracking.md)使用绿色 `↗N` / 蓝色 `↙N`，无 upstream 的绿色箭头不带数字。
3. **零开销与轻量秒开**：下拉菜单完全依赖 `/status` 已带有的 upstream tracking 事实，不增加任何额外的 Git 探测进程；工作树目录的未提交变更（dirty）探测严格限制在删除确认弹窗与全量管理模态框中按需发起，不在高频菜单展开时做并发扫描。
4. **试行评估机制**：本特性作为试行落地；若后续在实际编码与窄屏排版场景中发现工作树行空间拥挤或与点击跳转注意力冲突，通过后续决策评估调整或回退。

## Alternatives considered

- **下拉菜单打开时并发探测所有工作树的 Dirty 状态** —— Windows 下每次 `git status` 均为独立进程生成，工作树数量较多时会显著拖慢菜单弹出的帧率与流畅度，且大多数跳转换区分支场景并不需要立刻审视未提交细节。
- **工作树行完全不显示 `↑↓` 箭头** —— 数据早已由后端的单次 `git for-each-ref` 廉价解析出来，刻意隐藏使得用户必须切回普通分支视图才能确认是否需要更新，体验割裂。
- **直接作为永久规则而不设评估窗口** —— 工作树行具有专属的交互特征（点击跳转、物理路径 tooltip、右键管理等），其视觉密度需经过真实编码会话检验，保留试行评估更为审慎。

## Consequences

- 换来：工作树条目与普通本地分支具备一致的上游同步状态可见性，用户无需切回普通分支即可获知工作树分支是否需要 pull 或 push；复用既有 `/status` 返回数据与渲染函数，保持轻量秒开零额外开销。
- 代价：工作树行右侧视觉密度略微增加；在存在长分支名且有较大数字上游差异时占用更多横向空间（由现有 CSS 截断与弹性布局兜底）。
