# Changelog

## [0.3.5] - 2026-10-20

### 改进

- **OpenCode provider 的识别不再依赖 id 命名**：除 id 含 `opencode` 外，`baseURL` 指向 `opencode.ai`（含子域）的自定义 provider 同样算数；多个候选时优先采用「默认模型所用的那个」provider 的 `apiKeyEnv`，也就是 DSH 当前真正在花钱的那把 key。
- 抽出并导出 `parseProviders` / `parseDefaultProvider`，`parseOpenCodeProviders` 改为在其上过滤，便于复用与测试。

### 测试

- 新增 2 例：自定义 id + `opencode.ai` baseURL 的识别、默认模型 provider 的绑定优先级。全量 **34/34 通过**。

## [0.3.4] - 2026-10-20

### 新增

- **零配置 key 解析：自动使用 DSH 自己配置的那把 OpenCode key。** 解析顺序为 `OPENCODE_GO_API_KEY` → provider 绑定的 `apiKeyEnv` 在 `$DSH_HOME/.credentials.yaml` 的 `refs:` 里取名 → `$DSH_HOME/.env` → provider 块内联 `apiKey` → opencode CLI 的 `~/.local/share/opencode/auth.json`。只要 DSH 里已经把 OpenCode 配成模型提供商，装上即用，无需手工复制 key。
- 新增 `dshHome` 配置项：自定义 harness home（多 profile / 便携安装 / 测试）时也能定位凭据。

### 改进

- **错误不再吞掉上游原因**：401/403 识别 `api_key_expired`，直接给出可执行处置（Console 地址、要替换的位置）；未知认证失败与 5xx 附带上游 `message`。
- 收到 401/403 立即让 key 缓存失效：在 DSH 里换了 key，下一次轮询即生效，无需重启。
- 解析出的 key 经 shell spec 的 `env`（`OCG_QUOTA_KEY`）传给子进程，不写进脚本文本、不落临时文件；宿主不接受 `env` 时自动退回子进程自带解析。

### 修复

- 密钥过期时圆环只显示笼统的 `key rejected`，容易被误认为插件故障。

### 测试

- 新增 5 个用例：凭据文档解析、provider 绑定解析、`.env` 解析、解析优先级（env → 绑定 → 兜底层 → CLI）、以及凭据里的 key 经 `env` 到达子进程。全量 **32/32 通过**。

## [0.3.3] - 2026-10-08

### 修复

- **适配 DSH Desktop（以及任何 0.2+ 宿主）**：宿主 shell 执行器在 0.2 把 `ShellExecutor.run(spec)` 换成了 `execute(spec)`——后者返回进程句柄，退出码与输出要再 `await handle.result()` 才拿到。此前插件只调 `run(spec)`，在桌面端一律失败为 `shell.run failed: shell.run is not a function`，圆环显示灰色感叹号。现按宿主实际提供的方法选择调用路径，0.1.x 与 0.2+ 同时可用。
- **沙箱提示不再假设 CLI 启动方式**：原提示建议「从 workspace 目录启动 dsh web」，这在桌面端无意义（桌面宿主的工作目录固定为 `~/.dsh/profiles/desktop`，不由用户选择）。改为只给出唯一通用解法：在 profile 的 `cordis.patch.yml` 固定 `sandbox-policy.workspaceRoot`。

### 文档

- README 增加桌面端安装方式（用安装目录内的 `resources/runtime/cli/bin/dsh.cmd` 装进 `desktop` profile，再完全重启桌面端）、按 Web / 桌面端分述的沙箱 FAQ，以及两代 shell API 的兼容性说明。

### 测试

- 新增两个用例：现代宿主走 `execute(spec).result()`、旧宿主回退 `run(spec)`。全量 **27/27 通过**。

## [0.3.2] - 2026-08-15

### 新增

- **README「常见问题」**：Windows ACL 沙箱下圆环灰色感叹号（`sandbox-policy.workspaceRoot` 与 `dsh web` 启动目录耦合）的排障说明，及 key 缺失排查指引。

### 改进

- **沙箱错误人类可读化**：宿主沙箱不可用时（`windows-acl-run` / `no sandbox backend is usable`），tooltip 不再透传冗长的底层报错，改为可操作的中文提示（配置 workspaceRoot 或从 workspace 目录启动）。
- **key 解析增强**：支持环境变量 `OPENCODE_GO_API_KEY`（优先于 auth.json）；auth.json 容忍 UTF-8 BOM（此前带 BOM 会误报 "key not found"）；区分"文件缺失 / 解析失败 / 无 key"三类错误。

### 修复

- **失败结果短缓存**：错误 payload 此前按成功 TTL（60s）缓存，接口恢复后需等待或手动刷新；现按 `errorCacheTtl`（默认 5 秒，可配置）短缓存，恢复后快速显示真实用量。

### 测试

- 新增：BOM 容忍与错误区分、沙箱错误映射（throw / stderr 两分支）、错误缓存 TTL。全量 **25/25 通过**。

## [0.3.1] - 2026-08-15

### 修复

- **Prompt 注入不再依赖浏览器轮询**：system prompt 求值时若用量缓存缺失或过期，会在后台自动刷新（并发去重）。GUI 未打开（headless / API 会话）时额度提醒也能正常生效。
- **瞬时失败不再清空提醒记忆**：用量接口临时失败（网络/401/404 等）时保持静默且保留已提醒档位，恢复后不会重复提醒同一档；仅窗口重置（真实回落至警示阈值以下）才清除记忆。
- **阈值配置合法性检查**：`warnAt < criticalAt < escalateFrom` 不成立时打印 console.warn，避免档位阶梯被静默压平（如 75%/85% 全判为 0 档）。
- **`readBody` 超限响应修复**：请求体超过 4KB 上限时改为排空请求流并正常返回 400，此前 `req.destroy()` 会掐断连接，客户端收到的是 ECONNRESET。
- **圆环键盘可达性**：增加 `role="button"` / `tabIndex` / `aria-label`，支持 Enter / Space 切换 5h / 周 / 月窗口。
- **标签页唤醒刷新**：后台标签页唤醒且数据超过 1 分钟时强制刷新，不再展示过期额度。
- **README**：许可统一为 MIT（与 LICENSE、package.json 一致），删除重复段落。
- **CI 跨平台**：测试命令改为 `node --test "tests/*.test.mjs"`，修复 Windows 下 `node --test tests/` 目录参数失败的问题。

### 测试

- 新增 host 半测试 `tests/index.test.mjs`：路由注册、用量归一化、缓存 TTL、强制刷新、错误映射（404/401/403/5xx/子进程退出）、405/400、档位状态机、无数据记忆保留与 headless 自刷新回归、自定义阈值下发。全量 **21/21 通过**。

## [0.3.0] - 2026-08

- 新增 GitHub Actions CI（node --check + node --test）。
- 宿主错误日志与可配置 `cacheTtl`。
- 浏览器 console 调试日志（用量加载失败时）。
- 文档：`cacheTtl` 与错误行为说明。

## [0.2.0] - 2026-08

- 额度分级提醒（Codex CLI 式）：60% 注意 / 80% 告急 / 90% 起每 2% 递进一档，每档仅注入一次。
- 按窗口警示阈值（周 / 月圆环分别警示）。
- `lib/usage-text.js` 提示文案模块与对应单测。
