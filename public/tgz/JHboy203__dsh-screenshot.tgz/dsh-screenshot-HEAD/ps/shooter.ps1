# DSH screenshot plugin - the RESIDENT capture helper (one process, many captures).
#
#   pwsh -NoProfile -ExecutionPolicy Bypass -File shooter.ps1 -Dir <dir> -Tag <tag> [-ParentPid <n>]
#
# The problem it solves (all numbers measured on this machine, 1920x1080, one capture):
#   process start                     ~500ms
#   Add-Type -AssemblyName Drawing    ~260ms
#   compiling the C# interop          ~390ms
#   parsing + binding capture.ps1     ~250ms
#   ----------------------------------------
#   actual BitBlt + PNG encode        ~150ms      <- the ONLY part that is real work
# Every one-shot call pays all of it. This process pays it once, then serves each capture for
# ~200-300ms, which is what makes the overlay appear instantly instead of "after a few seconds".
#
# Protocol - THE FILESYSTEM IS THE ONLY CHANNEL. No pipes: the DSH file sandbox forbids
# CreatePipe, so `node.spawn` with a pipe is an instant EPERM, and the event-file pattern is
# already how ps/hotkey.ps1 talks to its Node half.
#
#   node  ->  req-<tag>.json    {"seq":N,"op":"cap","mode":..,"out":..,"hideSelf":.., ...}
#   this  ->  res-<tag>.json    {"seq":N,"ok":true,<the same fields capture.ps1's -Json prints>}
#   this  ->  ready-<tag>.json  written once Add-Type/DPI are done = "I can serve now"
#   node  ->  stop-<tag>.flag   graceful quit (node also kills the process if it does not leave)
#   this  ->  stderr            goes to a real file handle (see hotkey.mjs for why)
#
# <tag> is unique per Node start, so a daemon left over from a previous DSH process can never
# answer the new one's requests, and the parent-pid watchdog below makes it exit within ~2s
# anyway (a helper that outlives its host would keep a PowerShell + .NET process alive forever).
#
# ASCII only: the console is GBK and Windows PowerShell 5.1 mis-decodes BOM-less UTF-8.
param(
  [Parameter(Mandatory=$true)][string]$Dir,
  [string]$Tag = 'default',
  # The Node process that spawned us. 0 = do not watch (self-test / manual runs).
  [int]$ParentPid = 0,
  # Absolute lifetime cap, in case the parent check is defeated by pid reuse.
  [int]$MaxMinutes = 720,
  # Poll cadence. Idle is deliberately slower than hot: a capture bursts (long-screenshot loops
  # ask once per ~300ms) and then nothing happens for minutes.
  [int]$HotMs = 8,
  [int]$IdleMs = 40,
  [int]$HotSeconds = 4
)

$ErrorActionPreference = 'Stop'

if (-not (Test-Path -LiteralPath $Dir)) { New-Item -ItemType Directory -Path $Dir -Force | Out-Null }
$reqPath = Join-Path $Dir ("req-" + $Tag + ".json")
$resPath = Join-Path $Dir ("res-" + $Tag + ".json")
$readyPath = Join-Path $Dir ("ready-" + $Tag + ".json")
$stopPath = Join-Path $Dir ("stop-" + $Tag + ".flag")
$utf8 = [System.Text.UTF8Encoding]::new($false)

# Load the capture core exactly once. This is where the ~650ms of Add-Type goes, and it is the
# reason the helper answers fast: the type is in the AppDomain for every later request.
. (Join-Path $PSScriptRoot 'shotcore.ps1')

# Warm-up: the FIRST capture in a fresh process costs ~600ms while every later one costs ~230ms
# (measured, 1920x1080). That extra ~350ms is JIT + first-time GDI/PNG-encoder setup, not
# per-request work - and it is exactly the difference between "the overlay is instant" and "the
# overlay takes half a second". Paying it HERE is free: the user has not clicked yet, and the
# one thing this process must never do is make the first click slow. Failures are irrelevant
# (locked workstation, headless session, ...) and must never stop the helper from going ready.
$warmPath = Join-Path $Dir ("warmup-" + $Tag + ".png")
try { $null = Invoke-DshCapture -Mode 'desktop' -Out $warmPath } catch { }
if ([System.IO.File]::Exists($warmPath)) { Remove-Item -LiteralPath $warmPath -Force -ErrorAction SilentlyContinue }

function Write-JsonFile([string]$Path, [string]$Text) {
  # Write-then-rename: the reader polls for the file and must never see half a JSON document.
  $tmp = $Path + '.tmp'
  [System.IO.File]::WriteAllText($tmp, $Text, $utf8)
  if ([System.IO.File]::Exists($Path)) { Remove-Item -LiteralPath $Path -Force -ErrorAction SilentlyContinue }
  Move-Item -LiteralPath $tmp -Destination $Path -Force
}

function Test-TargetAlive([int]$TargetPid, [long]$StartTicks) {
  # "Cannot determine" counts as ALIVE: a daemon that exits spuriously would send every capture
  # back down the 1.9s one-shot path. The MaxMinutes cap bounds the damage either way.
  if ($TargetPid -le 0) { return $true }
  try {
    $proc = [System.Diagnostics.Process]::GetProcessById($TargetPid)
    # pid reuse is NOT hypothetical: a dead Node pid is handed to an unrelated process within
    # minutes on a busy machine, GetProcessById then SUCCEEDS and this helper would believe its
    # host is alive for the whole MaxMinutes cap (measured: a stray helper survived 20+ minutes
    # after its Node had exited). The parent's start time is the cheap, reliable discriminator.
    if ($StartTicks -gt 0) {
      try { if ($proc.StartTime.Ticks -ne $StartTicks) { return $false } } catch { }
    }
    return $true
  } catch {
    $msg = [string]$_.Exception.Message
    if ($msg -match 'not running|Cannot find|No process is associated') { return $false }
    return $true
  }
}

$sw = [System.Diagnostics.Stopwatch]::StartNew()

# The parent's start time, sampled once. See Test-TargetAlive for why the pid alone is not enough.
$parentTicks = 0
if ($ParentPid -gt 0) {
  try { $parentTicks = [System.Diagnostics.Process]::GetProcessById($ParentPid).StartTime.Ticks } catch { $parentTicks = 0 }
}

# Handshake: everything expensive (System.Drawing, the C# interop, DPI awareness, the warm-up) is
# done by now, so from this moment a request is served in a couple hundred milliseconds.
Write-JsonFile $readyPath (([ordered]@{
  ok = $true; stage = 'ready'; pid = $PID; tag = $Tag; parentPid = $ParentPid; parentTicks = $parentTicks
  psVersion = $PSVersionTable.PSVersion.ToString(); at = (Get-Date).ToString('o')
}) | ConvertTo-Json -Compress)

$hotUntil = $sw.ElapsedMilliseconds + ($HotSeconds * 1000)
$lastWatch = 0
$served = 0
$reason = 'stop-flag'

while ($true) {
  if ([System.IO.File]::Exists($stopPath)) { $reason = 'stop-flag'; break }

  if (-not [System.IO.File]::Exists($reqPath)) {
    # Nothing to do. [System.IO.File]::Exists is a direct .NET call (~microseconds), unlike the
    # Test-Path cmdlet, so polling this often costs no measurable CPU.
    if ($sw.ElapsedMilliseconds -lt $hotUntil) { [System.Threading.Thread]::Sleep($HotMs) }
    else { [System.Threading.Thread]::Sleep($IdleMs) }
  } else {
    $hotUntil = $sw.ElapsedMilliseconds + ($HotSeconds * 1000)
    $startedReq = $sw.ElapsedMilliseconds

    $body = ''
    try { $body = [System.IO.File]::ReadAllText($reqPath) } catch { $body = '' }
    # Consume the request immediately: a second read of the same request must never happen.
    Remove-Item -LiteralPath $reqPath -Force -ErrorAction SilentlyContinue

    $req = $null
    try { if ($body.Trim().Length -gt 0) { $req = $body | ConvertFrom-Json } } catch { $req = $null }

    if ($null -eq $req) {
      # Unparseable/empty request (a crash between write and rename, say). Nothing to answer.
      continue
    }

    $seq = 0
    try { $seq = [int]$req.seq } catch { $seq = 0 }

    $out = [ordered]@{ seq = $seq; ok = $false; error = ''; exitCode = 0; ms = 0 }
    try {
      $kind = [string]$req.kind
      if ($kind -eq 'hittest') {
        # Long-capture manual mode calls this on EVERY tick. Spawning hitwin.ps1 each time costs
        # ~1.2s of cold start and becomes the ceiling of the whole loop; doing it inside this
        # resident process costs microseconds. hitwin.ps1 remains the fallback for callers that
        # ask before this helper is warm.
        $hx = 0; $hy = 0
        try { $hx = [int]$req.x } catch { $hx = 0 }
        try { $hy = [int]$req.y } catch { $hy = 0 }
        $th = [DshShot]::HitTestRoot($hx, $hy)
        if ($th -eq [IntPtr]::Zero) {
          $out['ok'] = $false
          $out['error'] = 'no window at ' + $hx + ',' + $hy
        } else {
          $tsb = New-Object System.Text.StringBuilder 512
          [void][DshShot]::GetWindowTextW($th, $tsb, 512)
          $csb = New-Object System.Text.StringBuilder 256
          [void][DshShot]::GetClassNameW($th, $csb, 256)
          $tr = New-Object DshShot+RECT
          [void][DshShot]::GetWindowRect($th, [ref]$tr)
          $tpid = [uint32]0
          [void][DshShot]::GetWindowThreadProcessId($th, [ref]$tpid)
          $out['ok'] = $true
          $out['hwnd'] = [long]$th
          $out['title'] = $tsb.ToString()
          $out['class'] = $csb.ToString()
          $out['pid'] = [int]$tpid
          $out['x'] = [int]$tr.L
          $out['y'] = [int]$tr.T
          $out['w'] = [int]($tr.R - $tr.L)
          $out['h'] = [int]($tr.B - $tr.T)
        }
      } elseif ($kind -eq 'wheel') {
        # AUTO long screenshot asks this once per frame. Spawning ps/wheel.ps1 for each frame
        # cost ~600-900ms of process start (measured) for ~1ms of mouse_event, and the auto
        # loop could not go faster than that. Same order and waits as wheel.ps1; wheel.ps1
        # stays as the fallback for callers that ask before this helper is warm.
        $wx = 0; $wy = 0; $wd = 0; $times = 1
        try { $wx = [int]$req.x } catch { $wx = 0 }
        try { $wy = [int]$req.y } catch { $wy = 0 }
        try { $wd = [int]$req.delta } catch { $wd = 0 }
        try { $times = [Math]::Max(1, [Math]::Min(20, [int]$req.times)) } catch { $times = 1 }
        $moved = $true
        for ($i = 0; $i -lt $times; $i++) {
          if ([DshShot]::WheelAt($wx, $wy, $wd)) {
            [DshShot]::Wheel($wd)
          } else {
            # Cursor never got there (UIPI drops SetCursorPos for low-integrity callers).
            # Do NOT scroll: the wheel would land on a different window.
            $moved = $false
            break
          }
          if ($i -lt ($times - 1)) { Start-Sleep -Milliseconds 60 }
        }
        $out['ok'] = $true
        $out['moved'] = [bool]$moved
        $out['x'] = $wx; $out['y'] = $wy; $out['delta'] = $wd; $out['times'] = $times
      } elseif ($kind -eq 'postwheel') {
        # Wheel message addressed at the control under the region centre (R27, leaf-targeting
        # since R29): NO cursor move, no focus change. Used by the auto long screenshot first;
        # the caller decides whether the app honours it by comparing captured frames, so
        # `posted` only means "accepted by user32" - never "the page scrolled".
        #
        # `target` is the hwnd actually addressed (0 when refused): a WinForms scroll area only
        # reacts when the message goes to the control under the point, not to the top-level form.
        # `reason` separates "the point is no longer over the window we were told to scroll"
        # (transient - the caller should re-guard) from "user32 rejected it" (permanent - the
        # caller should stop posting and use the cursor method).
        $ph = [long]0; $px = 0; $py = 0; $pd = 0; $pt = 1
        try { $ph = [long]$req.hwnd } catch { $ph = 0 }
        try { $px = [int]$req.x } catch { $px = 0 }
        try { $py = [int]$req.y } catch { $py = 0 }
        try { $pd = [int]$req.delta } catch { $pd = 0 }
        try { $pt = [Math]::Max(1, [Math]::Min(20, [int]$req.times)) } catch { $pt = 1 }
        $posted = $false
        if ($ph -gt 0) { $posted = [DshShot]::PostWheel([IntPtr]::new($ph), $px, $py, $pd, $pt) }
        $targetHwnd = [long]0
        try { $targetHwnd = [long][DshShot]::WheelTarget } catch { $targetHwnd = 0 }
        $overTarget = $true
        try { $overTarget = [bool][DshShot]::WheelPointOverTarget } catch { $overTarget = $true }
        $out['ok'] = [bool]$posted
        $out['posted'] = [bool]$posted
        $out['target'] = $targetHwnd
        $out['overTarget'] = [bool]$overTarget
        $out['hwnd'] = $ph; $out['x'] = $px; $out['y'] = $py; $out['delta'] = $pd; $out['times'] = $pt
        if (-not $posted) {
          if (-not $overTarget) {
            $out['reason'] = 'point-moved'
            $out['error'] = 'the point is no longer over the target window; nothing was posted'
          } else {
            $out['reason'] = 'rejected'
            $out['error'] = 'PostMessage(WM_MOUSEWHEEL) rejected'
          }
        }
      } else {
      $mode = 'desktop'
      if ([string]$req.mode -eq 'window') { $mode = 'window' }
      $method = 'screen'
      if ([string]$req.method -eq 'print') { $method = 'print' }
      $target = [string]$req.target
      if ([string]::IsNullOrEmpty($target)) { $target = 'DeepSeek Harness' }
      $hwnd = 0
      try { $hwnd = [long]$req.hwnd } catch { $hwnd = 0 }

      $r = Invoke-DshCapture -Mode $mode -Out ([string]$req.out) -Target $target -Hwnd $hwnd `
        -HideSelf:([bool]$req.hideSelf) -Rect ([string]$req.rect) `
        -NoRestore:([bool]$req.noRestore) -Method $method

      if ($r.ok) {
        foreach ($prop in $r.info.PSObject.Properties) { $out[$prop.Name] = $prop.Value }
        $out['ok'] = $true
        $out['error'] = ''
      } else {
        $out['ok'] = $false
        $out['error'] = [string]$r.error
        $out['exitCode'] = [int]$r.exitCode
      }
      }
    } catch {
      # One bad request must never take the helper down - the Node side would then fall back to
      # the slow path for the rest of the session.
      $out['ok'] = $false
      $out['error'] = 'helper: ' + [string]$_.Exception.Message
      $out['exitCode'] = 1
    }

    $out['ms'] = [int]($sw.ElapsedMilliseconds - $startedReq)
    $served = $served + 1
    try { Write-JsonFile $resPath ($out | ConvertTo-Json -Compress) } catch { }
  }

  # Parent watchdog, checked roughly every 2 seconds (the same idea as ps/hotkey.ps1): if DSH is
  # force-killed its dispose never runs, and without this the helper would linger indefinitely.
  if (($sw.ElapsedMilliseconds - $lastWatch) -ge 2000) {
    $lastWatch = $sw.ElapsedMilliseconds
    if (-not (Test-TargetAlive $ParentPid $parentTicks)) { $reason = 'parent-gone'; break }
    if ($MaxMinutes -gt 0 -and $sw.ElapsedMilliseconds -gt ([long]$MaxMinutes * 60000)) { $reason = 'max-minutes'; break }
  }
}

# Leave nothing behind that a later reader could mistake for a live helper.
foreach ($f in @($readyPath, $reqPath, $stopPath)) {
  if ([System.IO.File]::Exists($f)) { Remove-Item -LiteralPath $f -Force -ErrorAction SilentlyContinue }
}
Write-Output ("shooter exited reason=" + $reason + " served=" + $served + " uptimeMs=" + $sw.ElapsedMilliseconds)
exit 0
