# dsh-liang-slider

> 仓库：[github.com/HansLin911/dsh-liang-slider](https://github.com/HansLin911/dsh-liang-slider) ·
> 最新安装包：[GitHub Releases v0.1.0](https://github.com/HansLin911/dsh-liang-slider/releases/download/v0.1.0/dsh-liang-slider-0.1.0.tgz)

DeepSeek Harness（DSH）前端插件：**梁系强度滑动条**。

把输入框中的「模型选择 + 推理等级」控件整体替换为一个 6 档滑动条，一次拖动同时切换模型与推理等级；鼠标悬停在进度条上时，在进度条正上方显示对应档位的形象图，切换时带交叉淡入淡出渐变。

| 档位 | 名称 | 模型 | 推理等级 |
|---|---|---|---|
| 0 | 小难梁 | DeepSeek-V4-Flash | off |
| 1 | 牢梁 | DeepSeek-V4-Flash | high |
| 2 | 梁子 | DeepSeek-V4-Flash | max |
| 3 | 梁圣 | DeepSeek-V4-Pro | off |
| 4 | 梁神 | DeepSeek-V4-Pro | high |
| 5 | 梁祖 | DeepSeek-V4-Pro | max |

## 功能

- 6 档滑动条整体替换内置的模型选择与推理等级按钮，一次拖动同时切换两者。
- 鼠标悬停进度条时，档位形象图（1:1，无黑边）淡入显示在**进度条正上方**，
  移开后淡出；拖动过程中实时跟随目标档位。
- 档位切换时图片 420ms 交叉淡入淡出（新图淡入、旧图淡出后移除）；
  `prefers-reduced-motion` 环境自动禁用全部动画。
- 当前档位以「梁名 + 模型 · 推理等级」芯片展示，切换请求在途时芯片呼吸闪烁。
- 档位变化通过 Harness 官方 `modelDirectories` 服务提交（`session.selectModel`），
  写入的是真实的模型 id 与 effort id，不改变任何实际请求语义。
- 通过 `conversation.input.model` 槽位覆盖内置控件（priority -10），卸载后自动恢复。
- 当前选择不在六档之内（例如其他 provider 的模型）时，芯片回退显示真实模型名，
  滑块仍可跳回任意档位。
- 6 张档位图在构建期以 data URL 内嵌进客户端 bundle，无网络请求、无外部静态资源。

## 兼容性

- 适用于提供 `conversation.input.model`、`modelDirectories` 与 `sessions` 服务的
  DeepSeek Harness **Web profile**，在 DSH `0.1.0-rc.6`（Windows，NSSM 服务部署）实测通过。
- 档位映射基于官方 `@deepseek-ai/dsh-llm-deepseek` 模型目录
  （`deepseek-v4-flash` / `deepseek-v4-pro`，effort `off` / `high` / `max`）。
  若你的 DSH 版本模型目录不同，请在源码 `src/levels.js` 中调整后重新构建。
- 运行时依赖 `@deepseek-ai/dsh-client-ui-conversation` 与
  `@deepseek-ai/dsh-client-ui-model-selection` 均为 DSH Web 安装自带包
  （`dsh.client.inject` 声明），无需额外安装。
- 子代理会话中模型选择不可用，插件自动隐藏。

## 安装

> 需要先安装 [Node.js](https://nodejs.org/) ≥ 18 与 [pnpm](https://pnpm.io/)（`dsh plugin` 命令依赖 pnpm）。

### 方式一：本地 / HTTP tarball（无需发布）

拿到 `dsh-liang-slider-0.1.0.tgz` 后，在任意目录执行：

```sh
dsh plugin --profile web add /path/to/dsh-liang-slider-0.1.0.tgz
# 或 http(s) 地址
dsh plugin --profile web add https://example.com/dsh-liang-slider-0.1.0.tgz
```

安装完成后重启 Harness 并刷新浏览器页面（插件在下次启动时挂载）。

### 方式二：GitHub Release tarball（推荐）

本插件已在 GitHub Releases 发布，直接安装：

```sh
dsh plugin --profile web add https://github.com/HansLin911/dsh-liang-slider/releases/download/v0.1.0/dsh-liang-slider-0.1.0.tgz
```

### 方式三：npm 发布后安装

发布到 npm registry（`npm publish`）后：

```sh
dsh plugin --profile web add dsh-liang-slider
```

## 卸载

```sh
dsh plugin --profile web remove dsh-liang-slider
```

卸载后重启 Harness 即恢复内置模型控件。插件的 bundle 层会由 `dsh plugin` 自动从
`dsh.profile.bundles` 中移除。

## 从源码构建

> 发行 tarball 已包含预构建的 `lib/`，普通安装**不需要**构建。

```sh
npm install          # 需要 Node ≥ 18；npm 11+ 需先 `npm approve-scripts esbuild`
npm run build        # 生成 lib/index.js（host 入口）与 lib/client.js（浏览器 bundle）
npm pack             # 生成 dsh-liang-slider-0.1.0.tgz
```

构建脚本 `build.mjs` 用 esbuild 把 `src/` 编译为：

- `lib/index.js` — Node ESM 宿主入口（`apply()`）；
- `lib/client.js` — 浏览器半部：CJS bundle（仅 `react` 外部依赖），以
  `window.__ModuleLoader__.load({ id, factory })` 格式包装，并把 `assets/` 中的
  6 张档位图（webp）作为 data URL 内嵌。

## 图片素材与版权声明

本插件的档位形象图取自
[Lichtspektrum/liang-intensity-calibrator](https://github.com/Lichtspektrum/liang-intensity-calibrator)
的 6 个阶段关键帧（`frame-00/06/12/18/24/30`，构建期内嵌为 data URL）。

该项目源代码以 MIT 许可发布，但其 README 声明：**`media` 与 `public/frames` 里的人像素材
不随 MIT 协议共享**。本项目维护者不拥有这些图像中人物的肖像权，也不通过本项目授予任何与
肖像、姓名、身份、公开权、隐私权、商标、版权或其他第三方权利有关的许可。若需公开传播、
商业使用、再分发或制作衍生版本，请自行确认所在司法辖区的适用法律、素材来源及所需授权。
如你是相关权利人并希望移除素材，请联系本插件维护者。

## 许可证

本插件代码以 [MIT-0](LICENSE) 许可发布（第三方图像素材的肖像权声明见上节）。
