/** Host entry for the browser-only 梁系强度滑块 plugin. */
export function apply() {}
