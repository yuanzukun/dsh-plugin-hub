export const styles = String.raw`
/* ---- 悬停横幅：fixed 定位在进度条正上方，1:1 与图片同比例 ---- */
.ls-banner {
  position: fixed;
  z-index: 50;
  box-sizing: border-box;
  width: 220px;
  padding: 0;
  opacity: 0;
  pointer-events: none;
  transform: translateX(-50%);
  transition: opacity 240ms ease;
}

.ls-banner-visible {
  opacity: 1;
}

.ls-banner-media {
  position: relative;
  width: 100%;
  aspect-ratio: 1 / 1;
  overflow: hidden;
  border: 1px solid rgba(49, 167, 255, 0.35);
  border-radius: 14px;
  background:
    radial-gradient(circle at 50% 20%, rgba(31, 122, 211, 0.28), transparent 62%),
    linear-gradient(155deg, rgb(14, 26, 41), rgb(5, 12, 22) 78%);
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.35), 0 0 18px rgba(38, 159, 255, 0.24);
}

.ls-banner-img {
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
  object-fit: cover;
  filter: drop-shadow(0 4px 10px rgba(0, 0, 0, 0.4));
}

.ls-banner-in {
  animation: ls-fade-in 420ms ease;
}

.ls-banner-out {
  opacity: 0;
  transition: opacity 420ms ease;
}

@keyframes ls-fade-in {
  from { opacity: 0; }
  to { opacity: 1; }
}

.ls-banner-stage {
  position: absolute;
  left: 50%;
  bottom: 8px;
  z-index: 2;
  padding: 2px 12px;
  border: 1px solid rgba(49, 167, 255, 0.4);
  border-radius: 999px;
  background: rgba(5, 19, 31, 0.72);
  color: rgb(89, 188, 255);
  font-size: 12px;
  line-height: 20px;
  font-weight: 650;
  letter-spacing: 0.12em;
  text-shadow: 0 0 8px rgba(43, 167, 255, 0.7);
  transform: translateX(-50%);
  white-space: nowrap;
  backdrop-filter: blur(3px);
}

/* ---- 输入框内的滑块控件 ---- */
.ls-root {
  display: flex;
  flex-direction: column;
  gap: 5px;
  box-sizing: border-box;
  width: 236px;
  padding: 8px;
  border: 1px solid var(--dsw-alias-border-l2);
  border-radius: 12px;
  background: var(--dsw-alias-interactive-bg-hover);
}

.ls-head {
  display: flex;
  align-items: center;
  gap: 8px;
  min-width: 0;
}

.ls-chip {
  display: inline-flex;
  align-items: baseline;
  gap: 6px;
  min-width: 0;
  padding: 1px 9px;
  border: 1px solid rgba(49, 167, 255, 0.32);
  border-radius: 999px;
  background: rgba(21, 128, 219, 0.12);
  color: rgb(89, 188, 255);
  line-height: 20px;
  white-space: nowrap;
}

.ls-busy .ls-name {
  animation: ls-pulse 900ms ease-in-out infinite alternate;
}

@keyframes ls-pulse {
  from { opacity: 1; }
  to { opacity: 0.45; }
}

.ls-name {
  font-size: 13px;
  font-weight: 650;
  letter-spacing: 0.04em;
}

.ls-sub {
  overflow: hidden;
  max-width: 130px;
  color: var(--dsw-alias-label-caption);
  font-size: 10px;
  line-height: 16px;
  text-overflow: ellipsis;
}

.ls-err {
  overflow: hidden;
  min-width: 0;
  color: var(--dsw-alias-state-error-primary);
  font-size: 11px;
  line-height: 16px;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.ls-range {
  width: 100%;
  height: 18px;
  margin: 0;
  appearance: none;
  -webkit-appearance: none;
  background: transparent;
  cursor: pointer;
}

.ls-range:disabled {
  cursor: default;
  opacity: 0.55;
}

.ls-range::-webkit-slider-runnable-track {
  height: 6px;
  border-radius: 999px;
  background: linear-gradient(90deg,
    rgb(56, 120, 178),
    rgb(96, 178, 244) 22%,
    rgb(52, 152, 236) 40%,
    rgb(189, 130, 66) 58%,
    rgb(222, 164, 86) 76%,
    rgb(240, 196, 108) 100%);
  box-shadow: inset 0 1px 2px rgba(0, 0, 0, 0.5);
}

.ls-range::-webkit-slider-thumb {
  width: 16px;
  height: 16px;
  margin-top: -5px;
  appearance: none;
  -webkit-appearance: none;
  border: 2px solid rgb(235, 244, 255);
  border-radius: 50%;
  background: radial-gradient(circle at 35% 30%, rgb(255, 255, 255), rgb(70, 150, 220));
  box-shadow: 0 1px 4px rgba(0, 0, 0, 0.55), 0 0 6px rgba(60, 160, 244, 0.5);
}

.ls-range::-moz-range-track {
  height: 6px;
  border-radius: 999px;
  background: linear-gradient(90deg,
    rgb(56, 120, 178),
    rgb(96, 178, 244) 22%,
    rgb(52, 152, 236) 40%,
    rgb(189, 130, 66) 58%,
    rgb(222, 164, 86) 76%,
    rgb(240, 196, 108) 100%);
}

.ls-range::-moz-range-thumb {
  width: 12px;
  height: 12px;
  border: 2px solid rgb(235, 244, 255);
  border-radius: 50%;
  background: radial-gradient(circle at 35% 30%, rgb(255, 255, 255), rgb(70, 150, 220));
  box-shadow: 0 1px 4px rgba(0, 0, 0, 0.55);
}

.ls-stations {
  display: flex;
  align-items: flex-start;
  height: 14px;
}

.ls-station {
  flex: 1;
  color: var(--dsw-alias-label-caption);
  font-size: 9.5px;
  line-height: 12px;
  text-align: center;
  white-space: nowrap;
}

.ls-station-active {
  color: rgb(78, 187, 255);
  font-weight: 650;
  text-shadow: 0 0 8px rgba(43, 167, 255, 0.7);
}

.ls-station[data-available='false'] {
  opacity: 0.4;
}

@media (prefers-reduced-motion: reduce) {
  .ls-banner,
  .ls-banner-visible {
    transition: none;
  }
  .ls-banner-in,
  .ls-banner-out {
    animation: none;
    transition: none;
  }
  .ls-busy .ls-name {
    animation: none;
  }
}
`
