import * as React from 'react'
import { useEffect, useId, useMemo, useRef, useState, useSyncExternalStore } from 'react'
import { LEVELS, levelKey } from './levels.js'
import { styles } from './styles.js'

export const inject = ['modelDirectories', 'sessions', 'slots']

/** Sub label shown beside the active level name, e.g. "DeepSeek-V4-Flash · high". */
function subLabel(entry) {
  const modelName = entry.model.name ?? entry.model.id
  return `${modelName} · ${entry.level.effort}`
}

/** Fallback label for a current selection that is not one of the six levels. */
function currentModelLabel(current, state) {
  for (const group of state.groups ?? []) {
    if (group.id !== current.provider) continue
    const model = group.models.find((m) => m.id === current.model)
    if (model) return model.name
  }
  return current.model
}

/**
 * Crossfade one stage image into the banner media box.
 * The new <img> fades in (ls-banner-in) while the previous one fades out
 * (ls-banner-out) and is removed after the transition.
 */
function crossfadeImage(media, image, name) {
  if (media.dataset.current === image) return
  media.dataset.current = image
  const prev = media.querySelector('img.ls-banner-img')
  const img = document.createElement('img')
  img.className = 'ls-banner-img ls-banner-in'
  img.src = image
  img.alt = name
  img.draggable = false
  media.appendChild(img)
  if (prev !== null && prev.src !== img.src) {
    prev.classList.remove('ls-banner-in')
    prev.classList.add('ls-banner-out')
    const remove = () => {
      if (prev.parentNode === media) media.removeChild(prev)
    }
    prev.addEventListener('transitionend', remove, { once: true })
    window.setTimeout(remove, 600)
  }
}

function LiangSlider({ locked, available, directory, load, select }) {
  const state = useSyncExternalStore(
    (notify) => directory.subscribe(notify),
    () => directory.getSnapshot(),
  )
  const [pending, setPending] = useState(null)
  const [actionError, setActionError] = useState(null)
  const rootRef = useRef(null)
  const bannerRef = useRef(null)
  const sliderId = useId()

  const resolved = useMemo(() => {
    const groups = state.groups ?? []
    return LEVELS.map((level) => {
      const group = groups.find((g) => g.models.some((m) => m.id === level.modelId))
      const model = group?.models.find((m) => m.id === level.modelId)
      return { level, group, model }
    })
  }, [state.groups])

  const activeIndex = useMemo(() => {
    const current = state.current
    if (!current) return -1
    return resolved.findIndex(({ level, group, model }) =>
      group !== undefined &&
      model !== undefined &&
      group.id === current.provider &&
      model.id === current.model &&
      (current.reasoningEffort ?? model.reasoning?.defaultEffort) === level.effort,
    )
  }, [state.current, resolved])

  useEffect(() => {
    if (available) load()
  }, [available, load])

  useEffect(() => {
    if (pending === null) return
    if (state.status === 'error' || activeIndex === pending) setPending(null)
  }, [pending, activeIndex, state.status])

  // ---- 悬停横幅：fixed 定位在输入框（composer）正上方，始终在视口内 ----
  // 原生事件 + 命令式 DOM，不依赖 React 合成事件与滚动区插入位置。
  useEffect(() => {
    if (!available) return undefined
    const root = rootRef.current
    if (root === null) return undefined

    const banner = document.createElement('div')
    banner.dataset.plugin = 'dsh-liang-slider-banner'
    banner.className = 'ls-banner'
    banner.innerHTML = '<div class="ls-banner-media"><span class="ls-banner-stage"></span></div>'
    document.body.appendChild(banner)
    bannerRef.current = banner

    const position = () => {
      // 定位到滑块控件（.ls-root）正上方，水平居中于进度条。
      const rootRect = root.getBoundingClientRect()
      const gap = 10
      const bottom = window.innerHeight - rootRect.top + gap
      banner.style.left = `${rootRect.left + rootRect.width / 2}px`
      banner.style.bottom = `${Math.max(8, bottom)}px`
    }
    const show = () => {
      position()
      banner.classList.add('ls-banner-visible')
    }
    const hide = () => {
      banner.classList.remove('ls-banner-visible')
    }
    const onEnter = () => show()
    const onLeave = () => hide()
    const onFocusIn = () => show()
    const onFocusOut = (event) => {
      if (!root.contains(event.relatedTarget)) hide()
    }

    root.addEventListener('mouseenter', onEnter)
    root.addEventListener('mouseleave', onLeave)
    root.addEventListener('focusin', onFocusIn)
    root.addEventListener('focusout', onFocusOut)
    window.addEventListener('resize', position)
    document.addEventListener('scroll', position, true)

    return () => {
      root.removeEventListener('mouseenter', onEnter)
      root.removeEventListener('mouseleave', onLeave)
      root.removeEventListener('focusin', onFocusIn)
      root.removeEventListener('focusout', onFocusOut)
      window.removeEventListener('resize', position)
      document.removeEventListener('scroll', position, true)
      if (banner.parentNode === document.body) document.body.removeChild(banner)
      bannerRef.current = null
    }
  }, [available])

  // 图片随显示档位（已提交或拖动中）交叉渐变切换。
  const displayIndex = pending ?? (activeIndex < 0 ? 0 : activeIndex)
  const displayEntry = resolved[displayIndex]
  useEffect(() => {
    const banner = bannerRef.current
    if (banner === null || displayEntry === undefined || displayEntry.level === undefined) return
    const media = banner.querySelector('.ls-banner-media')
    const stage = banner.querySelector('.ls-banner-stage')
    if (media === null) return
    crossfadeImage(media, displayEntry.level.image, displayEntry.level.name)
    if (stage !== null) stage.textContent = displayEntry.level.name
  }, [displayIndex]) // eslint-disable-line react-hooks/exhaustive-deps

  if (!available) return null

  const busy = state.status === 'selecting'
  const labelEntry = displayEntry?.group !== undefined ? displayEntry : undefined
  const label = labelEntry
    ? labelEntry.level.name
    : state.current
      ? currentModelLabel(state.current, state)
      : '选择模型'
  const sub = labelEntry
    ? subLabel(labelEntry)
    : state.current
      ? state.current.model
      : ''
  const missingLevels = resolved.some((entry) => entry.group === undefined)

  const selectLevel = async (index) => {
    const entry = resolved[index]
    if (entry === undefined || entry.group === undefined || entry.model === undefined) return
    setActionError(null)
    setPending(index)
    const accepted = await select({
      provider: entry.group.id,
      model: entry.model.id,
      reasoningEffort: entry.level.effort,
    })
    if (!accepted) {
      setPending(null)
      setActionError(directory.getSnapshot().error ?? '档位切换失败')
    }
  }

  return (
    <div className="ls-root" ref={rootRef}>
      <div className="ls-head">
        <span className={`ls-chip${busy ? ' ls-busy' : ''}`}>
          <span className="ls-name">{label}</span>
          {sub !== '' && <span className="ls-sub">{sub}</span>}
        </span>
        {(actionError ?? state.error) !== null && (
          <span className="ls-err" role="alert">{actionError ?? state.error}</span>
        )}
      </div>
      <input
        id={sliderId}
        className="ls-range"
        type="range"
        min="0"
        max={String(LEVELS.length - 1)}
        step="1"
        value={String(displayIndex)}
        disabled={locked || missingLevels}
        aria-label="模型与推理等级"
        aria-valuetext={label}
        onChange={(event) => { void selectLevel(Number(event.target.value)) }}
      />
      <div className="ls-stations" aria-hidden="true">
        {resolved.map(({ level, group }, index) => (
          <span
            key={levelKey(level)}
            className={`ls-station${displayIndex === index ? ' ls-station-active' : ''}`}
            data-available={group !== undefined}
          >
            {level.name}
          </span>
        ))}
      </div>
    </div>
  )
}

export function apply(ctx) {
  ctx.effect(() => {
    const tag = document.createElement('style')
    tag.dataset.plugin = 'dsh-liang-slider'
    tag.textContent = styles
    document.head.appendChild(tag)
    return () => tag.remove()
  })

  ctx.slots.inject('conversation.input.model', () => ctx.slots.register({
    name: 'conversation.input.model',
    priority: -10,
    inject: (sessionId) => {
      const directory = ctx.modelDirectories.directoryFor(sessionId)
      const available = ctx.sessions.subagentAddress(sessionId) === undefined
      return {
        available,
        directory: directory.store,
        load: () => {
          if (available) void directory.load().catch(() => {})
        },
        select: (selection) => available
          ? directory.select(selection).then(() => true, () => false)
          : Promise.resolve(false),
      }
    },
  }, LiangSlider))
}
