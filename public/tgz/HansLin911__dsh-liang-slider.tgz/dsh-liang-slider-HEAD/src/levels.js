/**
 * 梁系强度 6 档映射表。
 *
 * 每一档同时决定「模型」与「推理等级」，拖动滑块时一次调用
 * directory.select({ provider, model, reasoningEffort }) 完成切换。
 *
 * | 档位 | 名称 | 模型 id | 推理等级 | 关键帧 |
 * |---|---|---|---|---|
 * | 0 | 小难梁 | deepseek-v4-flash | off | frame-00 |
 * | 1 | 牢梁   | deepseek-v4-flash | high | frame-06 |
 * | 2 | 梁子   | deepseek-v4-flash | max  | frame-12 |
 * | 3 | 梁圣   | deepseek-v4-pro   | off | frame-18 |
 * | 4 | 梁神   | deepseek-v4-pro   | high | frame-24 |
 * | 5 | 梁祖   | deepseek-v4-pro   | max  | frame-30 |
 *
 * `image` 是构建期由 build.mjs 通过 esbuild define 注入的 webp data URL
 * （素材来自 Lichtspektrum/liang-intensity-calibrator 的关键帧）。
 */
export const LEVELS = Object.freeze([
  { modelId: 'deepseek-v4-flash', effort: 'off', name: '小难梁', image: __LIANG_IMG_0__ },
  { modelId: 'deepseek-v4-flash', effort: 'high', name: '牢梁', image: __LIANG_IMG_1__ },
  { modelId: 'deepseek-v4-flash', effort: 'max', name: '梁子', image: __LIANG_IMG_2__ },
  { modelId: 'deepseek-v4-pro', effort: 'off', name: '梁圣', image: __LIANG_IMG_3__ },
  { modelId: 'deepseek-v4-pro', effort: 'high', name: '梁神', image: __LIANG_IMG_4__ },
  { modelId: 'deepseek-v4-pro', effort: 'max', name: '梁祖', image: __LIANG_IMG_5__ },
])

export function levelKey(level) {
  return `${level.modelId}/${level.effort}`
}
