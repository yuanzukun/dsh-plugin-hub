from __future__ import annotations

from collections.abc import Iterable

from .registry import PROVIDER_SPECS
from .validation import MAX_QUERY_LENGTH


def build_tool_schema(enabled_providers: Iterable[str]) -> dict:
    """Build the public web_search schema from startup-enabled providers."""
    providers = list(dict.fromkeys(enabled_providers))
    properties = {
        "query": {
            "type": "string",
            "minLength": 1,
            "maxLength": MAX_QUERY_LENGTH,
            "description": (
                "A complete, detailed natural-language question or intent. "
                "Do NOT use fragmented keyword queries (e.g. avoid 'NVDA earnings'); "
                "instead pass the full question (e.g. 'What were the key highlights "
                "and market reactions to NVIDIA latest earnings?'). "
                "Model-native and semantic providers reason over full sentences "
                "to retrieve, read, and synthesize grounded evidence."
            ),
        },
        "max_results": {
            "type": "integer",
            "minimum": 1,
            "maximum": 20,
            "default": 5,
            "description": (
                "Desired maximum number of results. Providers "
                "enforce this natively or as a best-effort prompt constraint."
            ),
        },
        "time_range": {
            "type": "string",
            "enum": ["d", "w", "m", "y"],
            "description": "Optional time filter: past day, week, month, or year.",
        },
        "providers": {
            "type": "array",
            "items": {"type": "string", "enum": providers},
            "minItems": 1,
            "uniqueItems": True,
            "description": "Optional subset of the providers enabled at startup.",
        },
    }
    if "grok" in providers:
        properties["grok_search_mode"] = {
            "type": "string",
            "enum": ["web_search", "x_search", "both"],
            "default": "web_search",
            "description": (
                "Grok-only mode: use web search, X search, or expose both "
                "server-side tools in one request."
            ),
        }
    return {
        "name": "web_search",
        "description": (
            "Search the web using agent-native semantic search and "
            "LLM-grounding backends. Optimized for complete natural-language "
            "questions rather than traditional keyword queries. Enabled providers: "
            + "; ".join(
                PROVIDER_SPECS[name].description if name in PROVIDER_SPECS else name
                for name in providers
            )
            + ". Use a complete natural-language question. Failed providers are "
            "omitted from successful responses. If every enabled provider fails, "
            "the call returns a tool error with code all_providers_failed and "
            "per-provider diagnostics."
        ),
        "parameters": {
            "type": "object",
            "properties": properties,
            "required": ["query"],
            "additionalProperties": False,
        },
    }
