from __future__ import annotations

import math
import os
from concurrent.futures import ThreadPoolExecutor, as_completed

from .errors import exception_error
from .models import ProviderResponse, SearchRequest, SearchResponse, SearchResult
from .registry import DEFAULT_PROVIDER_NAMES, create_provider_pool
from .validation import validate_search_request


class SearchEngine:
    def __init__(self, providers=None, timeout: float | None = None):
        if timeout is None:
            raw_timeout = os.getenv("AGENT_WEB_SEARCH_TIMEOUT", "60")
            try:
                timeout = float(raw_timeout)
            except (TypeError, ValueError) as exc:
                raise ValueError(
                    "AGENT_WEB_SEARCH_TIMEOUT must be a positive number"
                ) from exc
            if not math.isfinite(timeout) or timeout <= 0:
                raise ValueError("AGENT_WEB_SEARCH_TIMEOUT must be a positive number")

        if providers is not None:
            # Explicit provider injection is a test/API escape hatch. Preserve
            # its existing semantics: use the supplied mapping verbatim and
            # ignore AGENT_WEB_SEARCH_PROVIDERS.
            self.providers = providers
        else:
            configured = [
                item.strip()
                for item in os.getenv(
                    "AGENT_WEB_SEARCH_PROVIDERS", ",".join(DEFAULT_PROVIDER_NAMES)
                ).split(",")
                if item.strip()
            ]
            self.providers = create_provider_pool(timeout, configured)
            if not self.providers:
                raise ValueError("no search providers are enabled")

    @property
    def enabled_provider_names(self) -> list[str]:
        return list(self.providers)

    @staticmethod
    def _validate_provider_response(response: object) -> ProviderResponse:
        """Reject malformed provider output before it reaches public serialization."""
        if not isinstance(response, ProviderResponse):
            raise TypeError("provider returned an invalid response")
        if not isinstance(response.answer, str) or (
            response.error is not None and not isinstance(response.error, str)
        ):
            raise TypeError("provider returned invalid response fields")
        if not isinstance(response.results, list) or not all(
            isinstance(item, SearchResult) for item in response.results
        ):
            raise TypeError("provider returned invalid results")
        for item in response.results:
            if not (
                isinstance(item.title, str)
                and isinstance(item.url, str)
                and isinstance(item.description, str)
                and (item.published_at is None or isinstance(item.published_at, str))
                and (item.author is None or isinstance(item.author, str))
            ):
                raise TypeError("provider returned invalid result fields")
        return response

    def search(self, request: SearchRequest) -> SearchResponse:
        problems = validate_search_request(request, self.enabled_provider_names)
        if problems:
            raise ValueError("; ".join(problems))
        if not self.providers:
            raise ValueError("no search providers are enabled")
        request = request.normalized()
        query = request.query
        selected = request.providers or list(self.providers)
        # A request may narrow the startup-enabled set, but cannot enable a
        # provider after registration/schema construction.
        output = {}
        with ThreadPoolExecutor(max_workers=max(1, len(selected))) as pool:
            futures = {}
            for name in selected:
                try:
                    futures[pool.submit(self.providers[name].search, request)] = name
                except Exception as exc:  # noqa: BLE001 - provider access is isolated
                    output[name] = ProviderResponse(
                        provider=name, error=exception_error(name, exc)
                    )
            for future in as_completed(futures):
                name = futures[future]
                try:
                    output[name] = self._validate_provider_response(future.result())
                except Exception as exc:  # noqa: BLE001 - providers must be isolated
                    output[name] = ProviderResponse(
                        provider=name, error=exception_error(name, exc)
                    )
        ordered = {
            name: output.get(
                name,
                ProviderResponse(provider=name, error="provider did not return"),
            )
            for name in selected
        }
        return SearchResponse(
            query=query,
            providers={
                name: response
                for name, response in ordered.items()
                if response.error is None
            },
            failed_provider_errors={
                name: response.error
                for name, response in ordered.items()
                if response.error is not None
            },
        )
