# Installation / 安装

[English](#english) · [简体中文](#简体中文)

## English

`dsh-cost-guard` is a Cordis **bundle** with a Host half (`index.js`) and a Web Client half (`client.js`). Both halves ship in one package: the bundle patch inserts the Host row and `dsh.client` makes the browser module available, so you never install them separately.

### Install from a local directory

1. Copy or clone this repository to a stable path, for example `D:\plugins\dsh-cost-guard`.
2. Open **Settings → Plugins → Bundles** in DSH and install from that directory, or use the CLI:

   ```sh
   dsh plugin --profile <profile> add "D:\plugins\dsh-cost-guard"
   ```

3. If the installer reports `restart-required`, restart DSH.

DSH runs `pnpm` inside the target profile, records the dependency, and selects the bundle. The row appears in **Settings → Plugins** as **Cost Guard**.

### Install from a git URL

```sh
dsh plugin --profile <profile> add "git+https://github.com/chenzhiyong1994/dsh-cost-guard.git"
```

A `file:` or absolute-path install links the directory instead of copying it, which is what you want for development: edit the files, reinstall, restart.

### Verify

- **Settings → Plugins** lists a `cost-guard` row with the title **Cost Guard** and its icon; the entry state is `active`.
- After a task records usage, a compact `¥` pill appears below the message composer. Click it for the model, input/output/cache tokens, model-call count, rate window, and session total.
- **Settings → Cost Guard** shows the pricing table, peak/off-peak controls (weekdays ×2, weekends/holidays off-peak), per-model samples, and configuration import/export.
- Host liveness probe: open `<the current DSH Web UI origin>/cost-guard/health` in the DSH GUI's browser (for example `http://127.0.0.1:2260/cost-guard/health`; use whatever port the UI actually uses). It returns `{"ok":true,...}` while the Host half is running.

Currency values are estimates based on the configured rates; confirm them against your provider bill.

### Update

Replace the files in the installed directory (or install the new version), then reinstall and restart when asked. Both halves reload from the new files; a bundle is never updated half at a time.

### Remove

**Settings → Plugins** → remove the bundle. DSH deselects it, runs `pnpm remove`, and the Host route disappears with the plugin. The pricing file `~/.dsh/cost-guard/config.json` is left in place; delete it manually to forget every custom rate.

## 简体中文

`dsh-cost-guard` 是一个 Cordis **bundle**，包含 Host 半部分（`index.js`）与 Web Client 半部分（`client.js`）。两者在同一个包里：bundle patch 插入 Host 行，`dsh.client` 让浏览器模块可被加载，不需要分开安装。

### 从本地目录安装

1. 把本仓库复制或克隆到一个固定路径，例如 `D:\plugins\dsh-cost-guard`；
2. 打开 DSH 的 **设置 → 插件 → 组合包**，从该目录安装；或使用命令行：

   ```sh
   dsh plugin --profile <profile> add "D:\plugins\dsh-cost-guard"
   ```

3. 安装器提示 `restart-required` 时重启 DSH。

DSH 会在目标 profile 中运行 `pnpm`、记录依赖并选中该组合包。**设置 → 插件** 中会出现 **开销监控** 一行。

### 从 git 地址安装

```sh
dsh plugin --profile <profile> add "git+https://github.com/chenzhiyong1994/dsh-cost-guard.git"
```

使用 `file:` 或绝对路径安装时会以链接方式装入而不是复制，适合边改边试：改完文件后重新安装并重启即可。

### 验证

- **设置 → 插件** 中出现 `cost-guard` 行，标题为 **开销监控**，带图标，状态为 `active`；
- 任务产生 usage 后，输入框下方出现一枚紧凑的 `¥` 价格标签；点开可看模型、输入 / 输出 / 缓存 token、调用次数、峰谷与会话累计；
- **设置 → 开销监控** 中能看到价格表、峰谷开关（工作日 ×2，周末 / 节假日谷时）、按模型统计与配置导入导出；
- Host 存活检查：在 DSH 界面所用浏览器中打开 `<当前 DSH Web UI 地址>/cost-guard/health`（例如 `http://127.0.0.1:2260/cost-guard/health`，端口以实际 UI 为准），Host 半部分运行时会返回 `{"ok":true,...}`。

金额由配置单价估算，请对照供应商实际账单检查价格。

### 更新

把安装目录里的文件替换为新版本（或安装新版本），按提示重新安装并重启。两个半部分会一起从新文件加载，bundle 不支持只更新一半。

### 卸载

在 **设置 → 插件** 中移除该组合包。DSH 会取消选中、执行 `pnpm remove`，Host 路由随插件一起消失。价格文件 `~/.dsh/cost-guard/config.json` 会保留，需要彻底忘记自定义单价时手动删除即可。
