# Screenshot assets / 截图素材

| File | Description |
| --- | --- |
| `hud-idle.png` | Real DSH conversation view with the idle Cost Guard HUD highlighted. |
| `settings-pricing.png` | Real Cost Guard settings view with pricing and per-model session totals. |

The two PNG screenshots were supplied by the project owner for public documentation and were visually reviewed before release. No API key, user name, local path, or private account identifier is visible.

The screenshots are from a v4.3 instance and still show the old full-width bar and the pre-2026-10-28 rates. `v5.1.0` uses a compact composer cost pill with a details popover, the current `deepseek-flash` rates, and weekday/weekend-aware peak pricing. Recapture both images from a v5.1 instance before publishing the release; keep the scenario free of private paths and account identifiers.

---

两张 PNG 是项目所有者提供的真实效果截图，发布前已检查可见像素；其中不含 API Key、用户名、本机路径或私密账号标识。

截图来自 v4.3 实例，仍是旧版全宽横条与 2026-10-28 之前的单价。`v5.1.0` 已改为紧凑的价格标签 + 明细弹层，并使用当前 `deepseek-flash` 价与区分工作日/周末的峰谷规则。发版前请从 v5.1 实例重新采集两张图，并继续避免出现本机路径与账号标识。
