<div align="center">
  <img src="docs/assets/hero-cost-guard.png" alt="DSH Cost Guard——用蓝发鲸尾女仆递上账单的餐厅场景表现任务开销" width="100%">
</div>

<div align="center">
  <a href="README.md">English</a> · <a href="README.zh-CN.md">简体中文</a> · <a href="https://chenzhiyong1994.github.io/dsh-cost-guard/">项目主页 ↗</a>
</div>

<div align="center">

[![Version](https://img.shields.io/badge/version-v5.1.0-7c3aed?style=flat-square)](CHANGELOG.md)
[![Check](https://img.shields.io/github/actions/workflow/status/chenzhiyong1994/dsh-cost-guard/check.yml?branch=main&style=flat-square&label=check)](https://github.com/chenzhiyong1994/dsh-cost-guard/actions/workflows/check.yml)
[![License: MIT](https://img.shields.io/badge/license-MIT-22c55e?style=flat-square)](LICENSE)
[![DSH plugin](https://img.shields.io/badge/DSH-plugin-7c3aed?style=flat-square)](https://github.com/topics/dsh-plugin)

</div>

# dsh-cost-guard

在任务执行过程中看清每一分钱花在哪里。`dsh-cost-guard` 是为 [DeepSeek Harness](https://github.com/deepseek-ai/deepseek-harness) 编写的本地 Cordis 插件包（bundle）：它把 DSH 记录的真实 token 用量转换成输入框下方的一枚紧凑价格标签，点开即可看 token 构成与会话累计，同时提供按模型统计和可编辑价格表。

插件只旁路观察，不会拦截、改写或路由 Agent 的执行。

**[访问项目主页 →](https://chenzhiyong1994.github.io/dsh-cost-guard/)** — 查看价格标签与价格设置截图、切换中英介绍，并一键复制安装提示词。主页由 **GitHub Pages** 托管，随 `main` 分支的相关更新自动部署。维护与发布方法见[主页说明](docs/website.md)。

> [!IMPORTANT]
> Token 数来自 DSH 的 usage 事件；金额由本地配置单价计算，是费用估算，不是权威账单。供应商可能随时调价，请始终以供应商实际账单为准。

## 实际效果

### 一枚安静的价格标签，需要时再展开

输入框下方只显示当前或上一次任务的 `¥` 金额；点开后才有模型、输入 / 输出 / 缓存 token、模型调用次数、峰谷与时序累计，不再重复输入框旁已有的 token 与缓存信息，也不会占满整行。

![开销监控空闲价格标签，点开可看模型、token、调用次数和会话累计](docs/screenshots/hud-idle.png)

### 价格和累计始终由你掌控

在 **设置 → 开销监控** 中编辑模型单价、添加自定义模型、启用官方峰谷计价、查看按模型累计，并导入或导出配置。

![开销监控设置页，包含模型定价与会话累计](docs/screenshots/settings-pricing.png)

> 截图来自早期 v4.3 实例，仍是旧版全宽横条。`v5.1.0` 已改为紧凑 pill，并使用下文 2026-10-28 核对的官方价；图片会在下次采集后更新。

## 为什么值得安装

- **基于真实用量，不猜提示词大小**：读取 DSH usage 中的输入、输出、缓存命中和缓存写入 token，并覆盖重试 / 中断的请求。
- **实时且一眼可见**：把本次任务金额放在输入框下方；点开看 token 构成与会话累计。
- **支持子代理汇总**：子代理用量回卷到根会话当前轮次，并按每次调用实际使用的模型计价。
- **重启可恢复**：首次查看某个会话时，从持久事件日志重建历史。
- **价格可审计**：所有模型单价和峰谷时段都能在设置页查看和修改。
- **中英双语**：价格标签与设置页跟随 DSH 通用设置的语言（中文 / English）自动切换。
- **完全本地**：无遥测、无外部服务、无账号访问，不收集 API Key。
- **零执行干预**：没有预测门禁、确认遮罩或模型路由。

## 快速开始

### 安装到当前 profile

`dsh-cost-guard` 是一个 Cordis **bundle**：`package.json` 用 `dsh.bundle.patch` 声明 Host 行，用 `dsh.client` 声明浏览器半部分。按 DSH 安装任何 bundle 的方式安装即可：

1. 把本仓库放到一个固定目录，例如 `D:\plugins\dsh-cost-guard`；
2. 打开 DSH 的 **设置 → 插件 → 组合包**，从本地目录安装；或使用等价的命令行：

   ```sh
   dsh plugin --profile <profile> add "D:\plugins\dsh-cost-guard"
   ```

3. 安装器报告 `restart-required` 时重启 DSH。

也可以直接让 DSH 智能体安装：

```text
把 D:\plugins\dsh-cost-guard 这个 DSH bundle 安装到当前 profile，
然后在插件清单里确认 cost-guard 这一行已经激活。
```

安装后 **设置 → 插件** 中会出现 **开销监控**，输入框下方出现一枚紧凑的价格标签。无需构建：两个半部分都是纯 JavaScript。

本地开发时把上面的路径换成 checkout 目录即可，安装器会以链接方式装入，改动后重新安装并重启生效。

### 运行要求

- DeepSeek Harness `0.2.1+`（桌面版或 `dsh web`），profile 需包含 Web 应用组合包。
- 价格标签和设置页需要 DSH Web UI。
- 只有开发时跑 `npm run check` 才需要 Node.js。

## 计价模型

`v5.1.0` 默认值与 **2026-10-28** 核对的 DeepSeek V4.1 Flash / V4 Pro 官方峰谷定价一致（[DeepSeek API 官方定价页](https://api-docs.deepseek.com/zh-cn/quick_start/pricing/)、[2026-09-10 调价更新](https://api-docs.deepseek.com/zh-cn/updates/)）；单位为人民币元 / 1M tokens，下为谷时价：

| 模型 | 输入·缓存未命中 | 输出 | 输入·缓存命中 |
| --- | ---: | ---: | ---: |
| `deepseek-flash` | ¥1.00 | ¥4.00 | ¥0.02 |
| `deepseek-v4-pro` | ¥4.50 | ¥13.50 | ¥0.15 |
| `default` 兜底 | ¥1.00 | ¥4.00 | ¥0.02 |

高峰时段为北京时间周一至周五 09:00–12:00、14:00–18:00（不含中国法定节假日），单价为谷价的 2 倍；周末与法定节假日全天为谷时。2026 年节假日安排已内置。峰谷计价**默认开启**，可在设置页关闭或修改窗口与倍率。

官方表格没有单列缓存写入价，因此缓存写入 token 按输入缓存未命中价计算。旧名称会映射到当前计费行：`deepseek-v4-flash`、`deepseek-v4-flash-vision-exp` → `deepseek-flash`，`deepseek-reasoner` → `deepseek-v4-pro`；已停用的 `deepseek-chat` 也映射到 Flash。

Search / Fetch 由 DeepSeek 另行按次计费（2026-11-01 起 ¥5 / 千次成功请求）。开销监控只统计模型 token，不含这部分请求费。

## 工作原理

```mermaid
flowchart LR
    A["session/event<br/>turn/start · request/context"] --> B["session/event<br/>assistant/message · assistant/attempt"]
    B --> C["配置单价<br/>计算本地估算"]
    C --> D["轮次与模型累计"]
    E["按需回填<br/>session.snapshotEvents"] --> D
    D --> F["Host 路由<br/>/cost-guard/live · /cost-guard/rpc"]
    F --> G["输入框价格标签<br/>设置面板"]
```

- **Host 半部分**（`index.js`）注入 `webServer`，折叠已入日志的会话事件、归属轮次、汇总子代理，首次查看时回填历史，并提供两条数据路由与一条健康检查路由。
- **Client 半部分**（`client.js`）是 `window.__ModuleLoader__` bundle，在 `conversation.composer.dock` 注册价格标签、在 `settings.section` 注册设置页，并通过 `fetch` 读取 Host。
- **数据流**只留在当前 DSH 进程内；路由是本机 HTTP，不访问外部网络。
- **价格状态**持久化到 `~/.dsh/cost-guard/config.json`（识别 `$DSH_HOME`），重启后仍在。

## 配置项

打开 **设置 → 开销监控**：

| 区块 | 可配置内容 |
| --- | --- |
| 模型定价 | 输入未命中、输出、输入命中单价；自定义模型；恢复默认（两步确认） |
| 峰谷计价 | 周一至周五 09:00–12:00、14:00–18:00（北京时间）×2，不含 2026 年法定节假日；周末 / 节假日全谷时 |
| 本次运行累计 | 已结算轮次、实际累计、可编辑汇率、按模型统计 |
| 配置备份 | JSON 导出与导入 |

明细中的美元金额使用可编辑的人民币 / 美元汇率近似换算。界面文字跟随 DSH 通用设置的语言（中文 / English）自动切换。

## 更新

bundle 整体替换。更新方式：

1. 把安装目录里的文件换成新版本（或拉取新 release）；
2. 在 **设置 → 插件** 重新安装，或再次执行 `dsh plugin --profile <profile> add <路径>`；
3. 安装器报告 `restart-required` 时重启 DSH；Host 与浏览器 bundle 都会从新文件重新加载。

## 安全与隐私

- 不发起外部请求，不含遥测，不读取凭据，不存储 API Key。
- Host 观察 DSH 会话 usage，并回放持久会话事件以重建累计。
- 导入配置通过校验后才会替换当前设置。
- DSH 插件接口仍在快速演进，请在安装第三方插件前审查源码。

安全问题反馈方式见 [SECURITY.md](SECURITY.md)。

## 项目结构

| 路径 | 用途 |
| --- | --- |
| [`index.js`](index.js) | Host 半部分：会话折叠、计价、HTTP 路由 |
| [`client.js`](client.js) | Client 半部分：价格标签与设置页 bundle |
| [`cordis.patch.yml`](cordis.patch.yml) | 插入 Host 行的 bundle patch |
| [`locale/`](locale) | 插件清单展示用的标题与描述 |
| [`icon.svg`](icon.svg) | 插件图标 |
| [`docs/install.md`](docs/install.md) | 安装、校验与卸载 |
| [`docs/index.html`](docs/index.html) | GitHub Pages 中英双语项目主页 |
| [`docs/website.md`](docs/website.md) | 主页预览、维护与部署说明 |
| [`scripts/check.cjs`](scripts/check.cjs) | bundle 布局、语法与发布不变量检查 |
| [`CHANGELOG.md`](CHANGELOG.md) | 版本记录 |

## 开发

```sh
npm run check
```

检查脚本会导入 Host 模块、以脚本方式编译 Client bundle，并核对 bundle 清单、patch、展示元数据与发布事实。想验证改动时直接把 checkout 目录装进 profile，重启后两个半部分都会重新加载。

欢迎阅读 [CONTRIBUTING.md](CONTRIBUTING.md) 后参与贡献。如果它帮你看清了 token 账单，也欢迎点 Star，让更多 DSH 用户找到它。

## 兼容性

插件依赖 DSH 的服务与 UI Slot（`webServer`、`sessions`、`session/event`、`conversation.composer.dock`、`settings.section`），这些并非稳定公开 API。反馈兼容问题时请附上 DSH 版本。

## License

[MIT](LICENSE)
