/**
 * dsh-cost-guard — Host half.
 *
 * Folds durable session events (`turn/start`, `request/context`,
 * `assistant/message`, `turn/end`) into per-turn token counters, prices them
 * with the configured table (peak / off-peak), and serves the result to the
 * browser half over two same-origin HTTP routes owned by this plugin:
 *
 *   GET  /cost-guard/live?sessionId=<id>   live snapshot for one session
 *   POST /cost-guard/rpc                   { method, args } configuration calls
 *   GET  /cost-guard/health                liveness probe
 *
 * Pricing configuration is persisted next to the Harness home
 * (`$DSH_HOME/cost-guard/config.json`) so it survives restarts.
 */
import { mkdirSync, readFileSync, writeFileSync } from 'node:fs'
import { homedir } from 'node:os'
import { join } from 'node:path'

// Source of truth (verified 2026-10-28):
//   https://api-docs.deepseek.com/zh-cn/quick_start/pricing/
//   https://api-docs.deepseek.com/zh-cn/updates/
// Flash was repriced when DeepSeek-V4.1-Flash launched on 2026-09-10; Pro is
// unchanged. The table stores OFF-PEAK prices; peak is exactly double.
const PRICING_VERIFIED = '2026-10-28'

// Chinese statutory holidays for 2026 (State Council notice, 2025-11-04):
//   https://www.gov.cn/zhengce/zhengceku/202511/content_7047091.htm
// Only the days off matter here: weekends are already off-peak, and make-up
// working weekends stay off-peak under the official "rest of the week" rule.
const HOLIDAYS_2026 = [
  '2026-01-01', '2026-01-02', '2026-01-03',
  '2026-02-15', '2026-02-16', '2026-02-17', '2026-02-18', '2026-02-19',
  '2026-02-20', '2026-02-21', '2026-02-22', '2026-02-23',
  '2026-04-04', '2026-04-05', '2026-04-06',
  '2026-05-01', '2026-05-02', '2026-05-03', '2026-05-04', '2026-05-05',
  '2026-06-19', '2026-06-20', '2026-06-21',
  '2026-09-25', '2026-09-26', '2026-09-27',
  '2026-10-01', '2026-10-02', '2026-10-03', '2026-10-04', '2026-10-05',
  '2026-10-06', '2026-10-07',
]

// Provider model names that still appear in old session logs, plus the retired
// 2025 aliases. They resolve to the current billing rows.
const MODEL_ALIASES = {
  'deepseek-v4-flash': 'deepseek-flash',
  'deepseek-v4-flash-vision-exp': 'deepseek-flash',
  'deepseek-chat': 'deepseek-flash',
  'deepseek-reasoner': 'deepseek-v4-pro',
}

const DEFAULTS = {
  pricing: {
    'deepseek-flash': { input: 1, output: 4, cacheRead: 0.02 },
    'deepseek-v4-pro': { input: 4.5, output: 13.5, cacheRead: 0.15 },
    default: { input: 1, output: 4, cacheRead: 0.02 },
    peak: {
      enabled: true,
      multiplier: 2,
      days: [1, 2, 3, 4, 5],
      windows: [{ start: 9, end: 12 }, { start: 14, end: 18 }],
      holidays: HOLIDAYS_2026,
    },
  },
  display: { usdRate: 7.2 },
}

const MAX_TURNS = 40
const FINAL = { completed: 1, aborted: 1, blocked: 1, error: 1, 'max-tokens': 1, interrupted: 1, forked: 1 }
const PRICE_FIELDS = ['input', 'output', 'cacheRead']
const MAX_BODY_BYTES = 64 * 1024
const BEIJING_OFFSET_MS = 8 * 3600 * 1000

const VERSION = (() => {
  try {
    return JSON.parse(readFileSync(new URL('./package.json', import.meta.url), 'utf8')).version || '0.0.0'
  } catch {
    return '0.0.0'
  }
})()

export const name = 'cost-guard'
export const inject = ['webServer']

const clone = (value) => JSON.parse(JSON.stringify(value))

function homeDirectory() {
  return process.env.DSH_HOME || join(homedir(), '.dsh')
}

function dataDirectory() {
  return join(homeDirectory(), 'cost-guard')
}

function configFile() {
  return join(dataDirectory(), 'config.json')
}

function num(value) {
  const n = typeof value === 'number' ? value : typeof value === 'string' && value.trim() !== '' ? Number(value) : NaN
  return Number.isFinite(n) ? n : null
}

const r2 = (v) => Math.round(v * 100) / 100
const r6 = (v) => Math.round(v * 1e6) / 1e6
const pad2 = (n) => String(n).padStart(2, '0')

function validDateKey(value) {
  if (typeof value !== 'string') return false
  const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(value)
  if (!match) return false
  const year = Number(match[1])
  const month = Number(match[2])
  const day = Number(match[3])
  const date = new Date(Date.UTC(year, month - 1, day))
  return date.getUTCFullYear() === year && date.getUTCMonth() === month - 1 && date.getUTCDate() === day
}

function canonicalModel(model) {
  const raw = String(model || '').trim()
  if (!raw) return 'unknown'
  const bare = raw.includes('/') ? raw.slice(raw.lastIndexOf('/') + 1) : raw
  return MODEL_ALIASES[raw] || MODEL_ALIASES[bare] || bare
}

/** Beijing date/hour/weekday for one epoch millisecond. */
function beijingParts(epoch) {
  const date = new Date(epoch + BEIJING_OFFSET_MS)
  return {
    hour: date.getUTCHours(),
    weekday: date.getUTCDay(),
    day: `${date.getUTCFullYear()}-${pad2(date.getUTCMonth() + 1)}-${pad2(date.getUTCDate())}`,
  }
}

/** Merge a persisted/imported object onto the defaults without trusting it. */
function sanitize(raw) {
  const merged = clone(DEFAULTS)
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return merged

  const pricing = raw.pricing && typeof raw.pricing === 'object' ? raw.pricing : null
  if (pricing) {
    for (const key of Object.keys(pricing)) {
      if (key === '__proto__' || key === 'constructor') continue
      if (key === 'peak') {
        const peak = pricing.peak
        if (peak && typeof peak === 'object') {
          if (peak.enabled !== undefined) merged.pricing.peak.enabled = !!peak.enabled
          const multiplier = num(peak.multiplier)
          if (multiplier !== null && multiplier >= 1 && multiplier <= 10) merged.pricing.peak.multiplier = r2(multiplier)
          if (Array.isArray(peak.windows)) {
            const windows = []
            for (const w of peak.windows) {
              if (!w || typeof w !== 'object') continue
              const start = num(w.start)
              const end = num(w.end)
              if (start === null || end === null || start < 0 || start > 23 || end < 0 || end > 23) continue
              windows.push({ start: Math.round(start), end: Math.round(end) })
            }
            merged.pricing.peak.windows = windows.slice(0, 4)
          }
          if (Array.isArray(peak.days)) {
            const days = []
            for (const value of peak.days) {
              const day = num(value)
              if (day === null || !Number.isInteger(day) || day < 0 || day > 6 || days.includes(day)) continue
              days.push(day)
            }
            merged.pricing.peak.days = days
          }
          if (Array.isArray(peak.holidays)) {
            const holidays = []
            for (const value of peak.holidays) {
              if (!validDateKey(value) || holidays.includes(value)) continue
              holidays.push(value)
              if (holidays.length >= 120) break
            }
            merged.pricing.peak.holidays = holidays
          }
        }
        continue
      }
      const row = pricing[key]
      if (!row || typeof row !== 'object') continue
      const next = {}
      let any = false
      for (const field of PRICE_FIELDS) {
        const v = num(row[field])
        if (v !== null && v >= 0 && v <= 1000) {
          next[field] = v
          any = true
        }
      }
      if (any) merged.pricing[key] = Object.assign({ input: 0, output: 0, cacheRead: 0 }, next)
    }
    // Migrate old persisted/imported model keys to the current billing rows.
    for (const [from, to] of Object.entries(MODEL_ALIASES)) {
      if (!pricing[from] || !merged.pricing[from]) continue
      if (!pricing[to]) merged.pricing[to] = { ...merged.pricing[from] }
      delete merged.pricing[from]
    }
  }

  if (raw.display && typeof raw.display === 'object') {
    const rate = num(raw.display.usdRate)
    if (rate !== null && rate >= 0.5 && rate <= 20) merged.display.usdRate = r2(rate)
  }
  return merged
}

export function apply(ctx) {
  // The sessions service may be provided after this row activates, so read it
  // lazily instead of capturing it once.
  const getSessions = () => {
    try {
      return ctx.get('sessions')
    } catch {
      return undefined
    }
  }
  const logger = ctx.logger

  const config = (() => {
    try {
      return sanitize(JSON.parse(readFileSync(configFile(), 'utf8')))
    } catch {
      return sanitize(null)
    }
  })()

  function persist() {
    try {
      mkdirSync(dataDirectory(), { recursive: true })
      writeFileSync(configFile(), JSON.stringify(config, null, 2) + '\n', 'utf8')
    } catch (error) {
      logger?.warn?.(`cost-guard: cannot persist pricing configuration: ${String(error && error.message ? error.message : error)}`)
    }
  }

  // ---------------- derived state ----------------
  /**
   * sessionId -> {
   *   turns: Map<number, Turn>, currentTurn, model, spentTotal,
   *   settledTurns, modelStats: Map<model, { count, input, output, cost }>,
   *   backfilled
   * }
   */
  const state = new Map()
  /** Child session id -> its last requested model, for stream-only attempts. */
  const childModels = new Map()
  /** Totals of sessions that left the live store, kept for the run total. */
  const retired = { spentTotal: 0, settledTurns: 0, modelStats: new Map() }

  function ensure(sid) {
    let st = state.get(sid)
    if (st === undefined) {
      st = {
        turns: new Map(),
        currentTurn: null,
        model: null,
        spentTotal: 0,
        settledTurns: 0,
        modelStats: new Map(),
        pendingChild: [],
        subagent: false,
        backfilled: false,
      }
      state.set(sid, st)
    }
    return st
  }

  function ensureTurn(st, turn) {
    let rec = st.turns.get(turn)
    if (rec === undefined) {
      rec = {
        turn,
        status: 'open',
        model: null,
        peak: null,
        retries: 0,
        startedAt: null,
        endedAt: null,
        actual: { input: 0, output: 0, cacheRead: 0, cacheWrite: 0, steps: 0, cost: 0 },
      }
      st.turns.set(turn, rec)
    }
    return rec
  }

  function latestTurn(st) {
    let best = null
    for (const key of st.turns.keys()) if (best === null || key > best) best = key
    return best === null ? null : st.turns.get(best)
  }

  function inPeak(epoch) {
    const peak = config.pricing.peak
    if (!peak || !peak.enabled) return false
    const { hour, weekday, day } = beijingParts(epoch || Date.now())
    const days = Array.isArray(peak.days) ? peak.days : DEFAULTS.pricing.peak.days
    if (!days.includes(weekday)) return false
    if ((peak.holidays || []).includes(day)) return false
    for (const w of peak.windows || []) {
      if (!w || w.start === w.end) continue
      if (w.start < w.end ? hour >= w.start && hour < w.end : hour >= w.start || hour < w.end) return true
    }
    return false
  }

  function pricingFor(model) {
    const raw = String(model || '').trim()
    if (raw && config.pricing[raw]) return config.pricing[raw]
    const key = canonicalModel(raw)
    if (config.pricing[key]) return config.pricing[key]
    if (/flash|chat/i.test(key)) return config.pricing['deepseek-flash'] || config.pricing.default || DEFAULTS.pricing.default
    if (/pro|reasoner/i.test(key)) return config.pricing['deepseek-v4-pro'] || config.pricing.default || DEFAULTS.pricing.default
    return config.pricing.default || DEFAULTS.pricing.default
  }

  function effectivePrice(row, epoch) {
    const peak = inPeak(epoch || Date.now())
    const multiplier = peak ? config.pricing.peak.multiplier || 1 : 1
    return {
      input: row.input * multiplier,
      output: row.output * multiplier,
      cacheRead: row.cacheRead * multiplier,
      cacheWrite: row.input * multiplier,
      multiplier,
      peak,
    }
  }

  /** Usage reported by one settlement, including a stream-only usage chunk. */
  function usageOf(event) {
    if (!event || !event.data) return undefined
    if (event.type !== 'assistant/message' && event.type !== 'assistant/attempt') return undefined
    if (event.data.usage) return event.data.usage
    const stream = Array.isArray(event.data.stream) ? event.data.stream : []
    for (let i = stream.length - 1; i >= 0; i--) {
      const record = stream[i]
      if (record && record.type === 'chunk' && record.chunk && record.chunk.type === 'usage' && record.chunk.usage) {
        return record.chunk.usage
      }
    }
    return undefined
  }

  /** Model recorded on the settlement message itself, when present. */
  function messageModel(event) {
    const source = event && event.data && event.data.message && event.data.message.source
    return source && typeof source.model === 'string' ? source.model : null
  }

  function addUsage(st, rec, usage, price) {
    const a = rec.actual
    const input = usage.inputTokens || 0
    const output = usage.outputTokens || 0
    const cacheRead = usage.cacheReadTokens || 0
    const cacheWrite = usage.cacheWriteTokens || 0
    a.input += input
    a.output += output
    a.cacheRead += cacheRead
    a.cacheWrite += cacheWrite
    a.steps += 1
    const before = a.cost
    a.cost = r6(
      before +
        (input / 1e6) * price.input +
        (cacheWrite / 1e6) * price.cacheWrite +
        (cacheRead / 1e6) * price.cacheRead +
        (output / 1e6) * price.output,
    )
    rec.peak = price.peak
    const delta = r6(a.cost - before)
    if (delta !== 0) {
      const key = rec.model || 'unknown'
      const ms = st.modelStats.get(key) || { count: 0, input: 0, output: 0, cost: 0 }
      ms.count += 1
      ms.input += input + cacheRead + cacheWrite
      ms.output += output
      ms.cost = r6(ms.cost + delta)
      st.modelStats.set(key, ms)
      // A subagent can report usage after the root turn was finalized; keep
      // the settled total in step with the turn it belongs to.
      if (FINAL[rec.status]) st.spentTotal = r6(st.spentTotal + delta)
    }
  }

  /** Re-apply a child's usage that was folded before the root log backfill. */
  function applyChildUsage(st, entry) {
    const rec = ensureTurn(st, entry.turn)
    rec.model = entry.model
    addUsage(st, rec, entry.usage, entry.price)
    if (entry.retry) rec.retries += 1
    if (!FINAL[rec.status]) rec.status = 'running'
  }

  function sumOpenCost(st) {
    let total = st.spentTotal
    for (const rec of st.turns.values()) if (!FINAL[rec.status]) total = r6(total + rec.actual.cost)
    return total
  }

  function mergeModelStats(target, source) {
    for (const [model, ms] of source) {
      const prev = target.get(model) || { count: 0, input: 0, output: 0, cost: 0 }
      target.set(model, {
        count: prev.count + ms.count,
        input: prev.input + ms.input,
        output: prev.output + ms.output,
        cost: r6(prev.cost + ms.cost),
      })
    }
  }

  function retire(st) {
    // A subagent's usage is already folded into its live root's state; counting
    // the child state again would double the run total.
    if (st.subagent) return
    retired.spentTotal = r6(retired.spentTotal + sumOpenCost(st))
    retired.settledTurns += st.settledTurns
    mergeModelStats(retired.modelStats, st.modelStats)
  }

  function parentOf(session) {
    const header = session && session.header
    if (!header || header.origin !== 'subagent' || !header.parentSession) return null
    const service = getSessions()
    return service ? service.get(header.parentSession) : null
  }

  function rootSessionOf(session) {
    let current = session
    for (let i = 0; i < 8; i++) {
      const parent = parentOf(current)
      if (!parent) break
      current = parent
    }
    return current
  }

  function openTurnOf(st) {
    if (st.currentTurn !== null) {
      const rec = st.turns.get(st.currentTurn)
      if (rec && !FINAL[rec.status]) return rec
    }
    return latestTurn(st)
  }

  function finalize(st, turn, reason) {
    const rec = st.turns.get(turn)
    if (!rec || FINAL[rec.status]) return
    const kind = reason && reason.kind ? reason.kind : 'completed'
    rec.status = FINAL[kind] ? kind : 'completed'
    rec.endedAt = Date.now()
    st.spentTotal = r6(st.spentTotal + rec.actual.cost)
    st.settledTurns += 1
    while (st.turns.size > MAX_TURNS) {
      const oldest = st.turns.keys().next().value
      st.turns.delete(oldest)
    }
  }

  /** Fold one durable session event into the counters. */
  function fold(session, event, forceRoot) {
    if (!session || !event || typeof event.type !== 'string') return
    const isRoot = forceRoot === true || !session.header || session.header.origin !== 'subagent'
    const root = forceRoot === true ? session : rootSessionOf(session)
    const rootId = String(root && root.id ? root.id : session.id)

    if (event.type === 'turn/start') {
      if (!isRoot) return
      const st = ensure(rootId)
      st.currentTurn = event.data && typeof event.data.turn === 'number' ? event.data.turn : st.currentTurn
      if (st.currentTurn !== null) {
        const rec = ensureTurn(st, st.currentTurn)
        if (rec.startedAt === null) rec.startedAt = event.time || Date.now()
      }
      return
    }

    if (event.type === 'request/context') {
      const model = event.data && (event.data.model || event.data.modelId)
      if (!model) return
      if (isRoot) ensure(rootId).model = String(model)
      else childModels.set(String(session.id), String(model))
      return
    }

    if (event.type === 'assistant/message' || event.type === 'assistant/attempt') {
      const usage = usageOf(event)
      if (!usage) return
      const st = ensure(rootId)
      let rec
      if (isRoot) {
        const turn = typeof event.data.turn === 'number' ? event.data.turn : st.currentTurn
        if (turn === null || turn === undefined) return
        rec = ensureTurn(st, turn)
      } else {
        rec = openTurnOf(st)
        if (!rec) return
      }
      // The settlement message names the model that actually served the call.
      // request/context is only the fallback for a stream-only attempt.
      const fallbackModel = isRoot ? st.model : childModels.get(String(session.id)) || st.model
      const model = canonicalModel(messageModel(event) || fallbackModel || rec.model || 'unknown')
      rec.model = model
      const price = effectivePrice(pricingFor(model), event.time || Date.now())
      addUsage(st, rec, usage, price)
      const retry = event.type === 'assistant/attempt'
      if (retry) rec.retries += 1
      if (!isRoot && !st.backfilled) {
        st.pendingChild.push({ turn: rec.turn, model, usage, price, retry })
        if (st.pendingChild.length > 200) st.pendingChild.shift()
      }
      if (!FINAL[rec.status]) rec.status = 'running'
      return
    }

    if (event.type === 'turn/end') {
      if (!isRoot) return
      const turn = event.data && typeof event.data.turn === 'number' ? event.data.turn : null
      if (turn === null) return
      finalize(ensure(rootId), turn, event.data.reason)
    }
  }

  /** Rebuild one session from its durable log the first time it is observed. */
  function backfill(session, st) {
    let events = null
    try {
      if (typeof session.snapshotEvents === 'function') events = session.snapshotEvents() || []
      else if (Array.isArray(session.events)) events = session.events
    } catch {
      // Do not mark the session as backfilled: the next look should retry.
      return st
    }
    if (!Array.isArray(events)) {
      st.backfilled = true
      return st
    }
    st.turns.clear()
    st.currentTurn = null
    st.model = null
    st.spentTotal = 0
    st.settledTurns = 0
    st.modelStats = new Map()
    for (const event of events) {
      try {
        // A child's own log is folded into the child state for its own view;
        // live child events still roll up into the root through the listener.
        fold(session, event, !!(session.header && session.header.origin === 'subagent'))
      } catch {
        /* a single malformed event must not abort the fold */
      }
    }
    // Child usage is not in the root log; replay what was folded live so the
    // backfill does not erase it.
    for (const entry of st.pendingChild) {
      try {
        applyChildUsage(st, entry)
      } catch {
        /* keep the root log fold */
      }
    }
    st.pendingChild = []
    st.backfilled = true
    return st
  }

  function sessionOf(sid) {
    const service = getSessions()
    if (!service) return undefined
    try {
      const direct = typeof service.get === 'function' ? service.get(sid) : undefined
      if (direct) return direct
      if (typeof service.list === 'function') {
        return (service.list() || []).find((session) => String(session.id) === sid)
      }
    } catch {
      return undefined
    }
    return undefined
  }

  // ---------------- live listeners ----------------
  ctx.on('session/event', (session, event) => {
    try {
      fold(session, event)
    } catch (error) {
      logger?.warn?.(`cost-guard: fold failed: ${String(error && error.message ? error.message : error)}`)
    }
  })

  ctx.on('session/disposed', (session) => {
    if (!session || session.id === undefined) return
    const sid = String(session.id)
    childModels.delete(sid)
    const st = state.get(sid)
    if (!st) return
    retire(st)
    state.delete(sid)
  })

  // ---------------- views ----------------
  function turnView(rec) {
    if (!rec) return null
    return {
      turn: rec.turn,
      status: rec.status,
      model: rec.model,
      peak: rec.peak,
      retries: rec.retries,
      startedAt: rec.startedAt,
      endedAt: rec.endedAt,
      actual: {
        input: rec.actual.input,
        output: rec.actual.output,
        cacheRead: rec.actual.cacheRead,
        cacheWrite: rec.actual.cacheWrite,
        steps: rec.actual.steps,
        cost: rec.actual.cost,
      },
    }
  }

  function totals() {
    let spentTotal = retired.spentTotal
    let turnsTracked = retired.settledTurns
    let sessions = 0
    const samples = new Map(retired.modelStats)
    for (const st of state.values()) {
      if (st.subagent) continue
      sessions += 1
      spentTotal = r6(spentTotal + sumOpenCost(st))
      turnsTracked += st.settledTurns
      mergeModelStats(samples, st.modelStats)
    }
    const modelStats = {}
    for (const [model, ms] of samples) modelStats[model] = { ...ms }
    return { sessions, spentTotal, turnsTracked, modelStats }
  }

  function liveView(sessionId) {
    const sid = String(sessionId)
    let session = sessionOf(sid)
    let st = state.get(sid)
    if (!st) {
      if (!session) {
        return {
          present: false,
          sessionId: sid,
          usdRate: config.display.usdRate,
          peakEnabled: !!config.pricing.peak.enabled,
          peakNow: inPeak(Date.now()),
        }
      }
      st = ensure(sid)
    }
    if (session) {
      const root = rootSessionOf(session)
      st.subagent = !!(
        session.header &&
        session.header.origin === 'subagent' &&
        root &&
        String(root.id) !== sid
      )
    }
    if (!st.backfilled) {
      if (!session) session = sessionOf(sid)
      if (session) {
        try {
          backfill(session, st)
        } catch {
          /* keep whatever the live listeners already folded */
        }
      }
    }
    const rec = (st.currentTurn !== null && st.turns.get(st.currentTurn)) || latestTurn(st)
    let lastFinal = null
    for (const turn of [...st.turns.keys()].sort((a, b) => b - a)) {
      const candidate = st.turns.get(turn)
      if (FINAL[candidate.status] && (!rec || candidate.turn !== rec.turn)) {
        lastFinal = turnView(candidate)
        break
      }
    }
    return {
      present: true,
      sessionId: sid,
      usdRate: config.display.usdRate,
      peakEnabled: !!config.pricing.peak.enabled,
      peakNow: inPeak(Date.now()),
      spentTotal: st.spentTotal,
      sessionTotal: sumOpenCost(st),
      current: rec ? turnView(rec) : null,
      lastFinal,
    }
  }

  // ---------------- configuration operations ----------------
  function applyPatch(patch) {
    const errors = []
    if (patch && patch.pricing && typeof patch.pricing === 'object') {
      for (const key of Object.keys(patch.pricing)) {
        if (key === '__proto__' || key === 'constructor') continue
        if (key === 'peak') {
          const p = patch.pricing.peak
          if (p && typeof p === 'object') {
            if (p.enabled !== undefined) config.pricing.peak.enabled = !!p.enabled
            if (p.multiplier !== undefined) {
              const v = num(p.multiplier)
              if (v === null || v < 1 || v > 10) errors.push('pricing.peak.multiplier')
              else config.pricing.peak.multiplier = r2(v)
            }
            if (p.windows !== undefined) {
              if (!Array.isArray(p.windows) || p.windows.length > 4) errors.push('pricing.peak.windows')
              else {
                const windows = []
                let ok = true
                for (const w of p.windows) {
                  const start = w && num(w.start)
                  const end = w && num(w.end)
                  if (start === null || end === null || start < 0 || start > 23 || end < 0 || end > 23) {
                    ok = false
                    break
                  }
                  windows.push({ start: Math.round(start), end: Math.round(end) })
                }
                if (ok) config.pricing.peak.windows = windows
                else errors.push('pricing.peak.windows')
              }
            }
            if (p.days !== undefined) {
              if (!Array.isArray(p.days)) errors.push('pricing.peak.days')
              else {
                const days = []
                let ok = true
                for (const value of p.days) {
                  const day = num(value)
                  if (day === null || !Number.isInteger(day) || day < 0 || day > 6) {
                    ok = false
                    break
                  }
                  if (!days.includes(day)) days.push(day)
                }
                if (ok) config.pricing.peak.days = days
                else errors.push('pricing.peak.days')
              }
            }
            if (p.holidays !== undefined) {
              if (!Array.isArray(p.holidays) || p.holidays.length > 120) errors.push('pricing.peak.holidays')
              else {
                const holidays = []
                let ok = true
                for (const value of p.holidays) {
                  if (!validDateKey(value)) {
                    ok = false
                    break
                  }
                  if (!holidays.includes(value)) holidays.push(value)
                }
                if (ok) config.pricing.peak.holidays = holidays
                else errors.push('pricing.peak.holidays')
              }
            }
          }
          continue
        }
        const price = patch.pricing[key]
        if (price === null) {
          delete config.pricing[key]
          continue
        }
        if (typeof price !== 'object') {
          errors.push('pricing.' + key)
          continue
        }
        const row = {}
        for (const field of PRICE_FIELDS) {
          if (price[field] === undefined) continue
          const v = num(price[field])
          if (v === null || v < 0 || v > 1000) errors.push(`pricing.${key}.${field}`)
          else row[field] = v
        }
        config.pricing[key] = Object.assign({ input: 0, output: 0, cacheRead: 0 }, config.pricing[key], row)
      }
    }
    if (patch && patch.display && typeof patch.display === 'object' && patch.display.usdRate !== undefined) {
      const v = num(patch.display.usdRate)
      if (v === null || v < 0.5 || v > 20) errors.push('display.usdRate')
      else config.display.usdRate = r2(v)
    }
    if (!errors.length) persist()
    return { ok: errors.length === 0, errors, config: clone(config) }
  }

  function methodTable() {
    return {
      'config.get': () => ({ config: clone(config), pricingVerified: PRICING_VERIFIED, ...totals() }),
      'config.set': (args) => applyPatch(args && args.patch),
      'config.reset-pricing': () => {
        config.pricing = clone(DEFAULTS.pricing)
        persist()
        return { ok: true, config: clone(config) }
      },
      'config.export': () => ({ json: clone(config) }),
      'config.import': (args) => {
        const json = args && args.json
        if (!json || typeof json !== 'object' || Array.isArray(json)) return { ok: false, errors: ['invalid-config'] }
        const merged = sanitize(json)
        config.pricing = merged.pricing
        config.display = merged.display
        persist()
        return { ok: true, config: clone(config) }
      },
      'live': (args) => (args && args.sessionId ? liveView(args.sessionId) : null),
      'turn': (args) => {
        const sid = args && args.sessionId ? String(args.sessionId) : null
        const st = sid ? state.get(sid) : null
        if (!st) return null
        const rec = st.turns.get(args.turn)
        return rec ? turnView(rec) : null
      },
      'debug': (args) => {
        const sid = args && args.sessionId ? String(args.sessionId) : null
        const session = sid ? sessionOf(sid) : undefined
        const st = sid ? state.get(sid) : undefined
        // Diagnostics: is the browser half composed into the client module graph?
        let clientModulePath = null
        try {
          const modules = ctx.get('clientModules')
          if (modules && typeof modules.clientPath === 'function') {
            clientModulePath = modules.clientPath('dsh-cost-guard') || modules.clientPath('cost-guard') || null
          }
        } catch {
          clientModulePath = null
        }
        return {
          hasSessionsService: !!getSessions(),
          sessionFound: !!session,
          sessionSeq: session && typeof session.seq === 'number' ? session.seq : null,
          canSnapshot: !!(session && typeof session.snapshotEvents === 'function'),
          backfilled: !!(st && st.backfilled),
          turns: st ? st.turns.size : 0,
          model: st ? st.model : null,
          clientModulePath,
        }
      },
    }
  }

  // ---------------- HTTP surface ----------------
  function sendJson(res, status, body) {
    try {
      const payload = JSON.stringify(body)
      res.writeHead(status, {
        'content-type': 'application/json; charset=utf-8',
        'content-length': Buffer.byteLength(payload),
        'cache-control': 'no-store',
        'x-content-type-options': 'nosniff',
      })
      res.end(payload)
    } catch {
      /* the socket may already be gone (oversized or aborted request) */
    }
  }

  function isJsonRequest(req) {
    const header = req.headers && req.headers['content-type']
    return typeof header === 'string' && header.split(';')[0].trim().toLowerCase() === 'application/json'
  }

  function readBody(req) {
    return new Promise((resolve) => {
      let size = 0
      const chunks = []
      req.on('data', (chunk) => {
        size += chunk.length
        if (size > MAX_BODY_BYTES) {
          resolve(null)
          req.destroy()
          return
        }
        chunks.push(chunk)
      })
      req.on('end', () => {
        if (!chunks.length) return resolve({})
        try {
          resolve(JSON.parse(Buffer.concat(chunks).toString('utf8')))
        } catch {
          resolve(null)
        }
      })
      req.on('error', () => resolve(null))
    })
  }

  ctx.effect(() =>
    ctx.webServer.register({
      kind: 'exact',
      path: '/cost-guard/health',
      handler: (req, res) => {
        sendJson(res, 200, { ok: true, plugin: name, version: VERSION })
      },
    }),
  )

  ctx.effect(() =>
    ctx.webServer.register({
      kind: 'exact',
      path: '/cost-guard/live',
      handler: (req, res) => {
        try {
          const url = new URL(req.url || '/', 'http://x')
          const sessionId = url.searchParams.get('sessionId')
          if (!sessionId) return sendJson(res, 400, { error: 'sessionId is required' })
          sendJson(res, 200, { result: liveView(sessionId) })
        } catch (error) {
          sendJson(res, 500, { error: String(error && error.message ? error.message : error) })
        }
      },
    }),
  )

  ctx.effect(() =>
    ctx.webServer.register({
      kind: 'exact',
      path: '/cost-guard/rpc',
      handler: async (req, res) => {
        if (req.method !== 'POST') return sendJson(res, 405, { error: 'POST required' })
        // A cross-origin HTML form cannot send application/json without a CORS
        // preflight, which this route never grants. Keep the write surface
        // same-origin even though the carrier adds no auth of its own.
        if (!isJsonRequest(req)) return sendJson(res, 415, { error: 'application/json required' })
        const body = await readBody(req)
        if (!body || typeof body !== 'object') return sendJson(res, 400, { error: 'invalid JSON body' })
        const table = methodTable()
        const handler = Object.prototype.hasOwnProperty.call(table, body.method) ? table[body.method] : null
        if (!handler) return sendJson(res, 404, { error: `unknown method: ${String(body.method)}` })
        try {
          sendJson(res, 200, { result: handler(body.args) })
        } catch (error) {
          sendJson(res, 500, { error: String(error && error.message ? error.message : error) })
        }
      },
    }),
  )
}

