/**
 * dsh-cost-guard — Web Client half.
 *
 * Registers two surfaces:
 *   - `conversation.composer.dock` — the compact cost pill and its details popover
 *   - `settings.section`           — pricing, totals, and backup controls
 *
 * Data comes from the Host half through same-origin HTTP routes
 * (`/cost-guard/live`, `/cost-guard/rpc`), so this module needs no gateway,
 * codegen, or build step.
 */
window.__ModuleLoader__.load({
  id: 'dsh-cost-guard',
  factory(require) {
    const React = require('react')
    const ReactDOM = require('react-dom')
    const h = React.createElement

    const STYLE_ATTR = 'dsh-cost-guard/styles'
    const POLL_MS = 1500

    const STRINGS = {
      zh: {
        nav: '开销监控',
        hud: {
          running: '执行中',
          idle: '空闲',
          title: '本次开销',
          titleLast: '上次开销',
          total: '本会话累计',
          model: '模型',
          inputMiss: '输入·未命中',
          in: '输入',
          out: '输出',
          cacheRead: '缓存命中',
          cacheWrite: '缓存写入',
          calls: '模型调用',
          callsUnit: ' 次',
          retries: '失败重试',
          price: '计价',
          peak: '峰时',
          offpeak: '谷时',
          open: '查看开销明细',
          stale: 'Host 未响应，数据可能已过期',
        },
        settings: {
          label: '开销监控',
          loading: '加载配置中…',
          saved: '✓ 已保存',
          hostUnreachable: '无法连接 Host（插件可能未运行）',
          saveFailed: '保存失败',
          saveConnFailed: '保存失败：连接错误',
          opFailed: '操作失败',
          opConnFailed: '操作失败：连接错误',
          pricingTitle: '模型定价（¥ / 1M tokens · 谷时价）',
          resetPricing: '恢复默认',
          resetConfirm: '确认恢复？',
          peakToggle: '峰谷计价',
          peakToggleSub: (mult, wins) =>
            '高峰时段 ' + wins + '，单价 × ' + mult + '；仅周一至周五（法定节假日除外）生效，周末与节假日全天为谷时',
          multiplier: '高峰倍率',
          multiplierSub: '高峰价 = 谷价 × 倍率',
          windows: '高峰时段',
          windowsSub: '北京时间；仅周一至周五生效；开始 = 结束则该窗口无效',
          holidaysNote: '已内置 2026 年法定节假日（33 天）；2027 年安排公布后随插件更新。',
          colModel: '模型',
          colInputMiss: '输入·未命中',
          colOutput: '输出',
          colCacheHit: '输入·命中',
          otherModel: '其他模型',
          addPlaceholder: '新模型 ID，如 deepseek-flash',
          add: '添加',
          duplicateModel: '该模型已存在',
          cacheWriteNote: '缓存写入 token 按「输入·未命中」价计费（官方无单独缓存写计费项）',
          totalsTitle: '本次运行累计',
          totalsSub: '插件启动以来，所有会话',
          statTurns: '已结算轮次',
          statSpent: '实际累计',
          statRate: '汇率（¥/USD）',
          rateSub: '用于明细中的美元换算',
          noSamples: '暂无样本——执行任务后自动积累',
          backupTitle: '配置备份',
          backupOpen: '导入 / 导出',
          backupClose: '收起',
          ioPlaceholder: '粘贴配置 JSON 后点击导入；导出会填入当前配置',
          importBtn: '导入',
          exportBtn: '导出当前配置',
          importBadJson: '导入失败：JSON 格式无效',
          importConnFailed: '导入失败：连接错误',
          priceSource: (date) => '价格与时段规则核对：' + date + '，DeepSeek 官方定价页。',
          pricingLink: '查看官方定价',
          searchNote: '不含 Search / Fetch 等按次计费项。',
          footnote:
            '开销监控作为 Cordis 插件运行（Host + Client 双半）。它只统计真实 token 用量，按官方峰谷价估算：北京时间周一至周五（法定节假日除外）9:00–12:00、14:00–18:00 为高峰，单价为谷价的 2 倍；周末与法定节假日全天为谷时。供应商调价后请更新单价。历史轮次在首次查看时从会话日志回填，定价配置保存在 ~/.dsh/cost-guard/config.json（识别 $DSH_HOME）。',
          notSet: '未设置',
        },
      },
      en: {
        nav: 'Cost Guard',
        hud: {
          running: 'Running',
          idle: 'Idle',
          title: 'This task',
          titleLast: 'Last task',
          total: 'Session total',
          model: 'Model',
          inputMiss: 'Input · miss',
          in: 'In',
          out: 'Out',
          cacheRead: 'Cache hit',
          cacheWrite: 'Cache write',
          calls: 'Model calls',
          callsUnit: '',
          retries: 'Failed retries',
          price: 'Rate',
          peak: 'Peak',
          offpeak: 'Off-peak',
          open: 'Show cost details',
          stale: 'Host not responding — data may be stale',
        },
        settings: {
          label: 'Cost Guard',
          loading: 'Loading…',
          saved: '✓ Saved',
          hostUnreachable: 'Cannot reach Host (plugin may not be running)',
          saveFailed: 'Save failed',
          saveConnFailed: 'Save failed: connection error',
          opFailed: 'Operation failed',
          opConnFailed: 'Operation failed: connection error',
          pricingTitle: 'Model pricing (¥ / 1M tokens · off-peak)',
          resetPricing: 'Reset defaults',
          resetConfirm: 'Confirm reset?',
          peakToggle: 'Peak / off-peak pricing',
          peakToggleSub: (mult, wins) =>
            'Peak windows ' +
            wins +
            ', price × ' +
            mult +
            '; weekdays only (excluding Chinese statutory holidays); weekends and holidays are off-peak all day',
          multiplier: 'Peak multiplier',
          multiplierSub: 'Peak price = off-peak price × multiplier',
          windows: 'Peak windows',
          windowsSub: 'Beijing time; weekdays only; start = end disables that window',
          holidaysNote:
            'Chinese statutory holidays for 2026 are built in (33 days); update when the 2027 schedule is published.',
          colModel: 'Model',
          colInputMiss: 'Input · miss',
          colOutput: 'Output',
          colCacheHit: 'Input · cache hit',
          otherModel: 'Other models',
          addPlaceholder: 'New model ID, e.g. deepseek-flash',
          add: 'Add',
          duplicateModel: 'That model already exists',
          cacheWriteNote: 'Cache-write tokens bill at the input-miss price (no separate official item)',
          totalsTitle: 'Run totals',
          totalsSub: 'All sessions since plugin start',
          statTurns: 'Settled turns',
          statSpent: 'Actual total',
          statRate: 'FX rate (¥/USD)',
          rateSub: 'Used for the USD conversion in the details',
          noSamples: 'No samples yet — they accumulate as tasks run',
          backupTitle: 'Config backup',
          backupOpen: 'Import / Export',
          backupClose: 'Collapse',
          ioPlaceholder: 'Paste config JSON then Import; Export fills the current config',
          importBtn: 'Import',
          exportBtn: 'Export current config',
          importBadJson: 'Import failed: invalid JSON',
          importConnFailed: 'Import failed: connection error',
          priceSource: (date) => 'Rates and schedule verified ' + date + ' against the official DeepSeek pricing page.',
          pricingLink: 'Official pricing',
          searchNote: 'Search / Fetch per-request billing is not included.',
          footnote:
            'Cost Guard runs as a Cordis plugin (Host + Client halves). It tallies real token usage and estimates it with the official peak/off-peak pricing: Beijing time Monday–Friday (excluding Chinese statutory holidays) 09:00–12:00 and 14:00–18:00 are peak at twice the off-peak price; weekends and holidays are off-peak all day. Update the rates if the provider changes them. History is rebuilt from the session log on first look, and pricing is stored in ~/.dsh/cost-guard/config.json ($DSH_HOME aware).',
          notSet: 'not set',
        },
      },
    }

    const CSS = `
.cg-root{font-family:inherit;color:var(--dsw-alias-label-primary)}
.cg-muted{color:var(--dsw-alias-label-secondary)}
.cg-mono{font-variant-numeric:tabular-nums}

/* ---------- composer dock cost pill ---------- */
.cg-cost-root{display:inline-flex;min-width:0;font:inherit;font-size:calc(var(--dsh-content-font-size-secondary,13px) - 1px);line-height:calc(20px + var(--dsh-content-font-delta-secondary,0px))}
.cg-cost-pill{box-sizing:border-box;display:inline-flex;align-items:center;gap:6px;max-width:100%;padding:1px 8px;border:0;border-radius:var(--dsw-radius-sm,6px);background:0 0;color:var(--dsw-alias-label-tertiary);font:inherit;font-variant-numeric:tabular-nums;line-height:inherit;white-space:nowrap;cursor:pointer;transition:background .15s ease,color .15s ease}
.cg-cost-pill:hover,.cg-cost-pill[aria-expanded="true"]{background:var(--dsw-alias-interactive-bg-hover);color:var(--dsw-alias-label-secondary)}
.cg-cost-pill:focus-visible{outline:2px solid var(--dsw-alias-brand-primary);outline-offset:2px}
.cg-cost-pill .cg-cost-dot{width:6px;height:6px;flex:none;border-radius:50%;background:var(--dsw-alias-state-success-primary);animation:cg-cost-pulse 1.6s ease-in-out infinite}
.cg-cost-value{color:var(--dsw-alias-label-primary);font-weight:500}
.cg-cost-pill[data-idle="true"] .cg-cost-value{color:inherit;font-weight:inherit}
@keyframes cg-cost-pulse{0%,100%{opacity:1}50%{opacity:.35}}
@media (prefers-reduced-motion:reduce){.cg-cost-pill .cg-cost-dot{animation:none}}

/* ---------- cost details popover ---------- */
.cg-pop{position:fixed;z-index:10000;box-sizing:border-box;width:252px;max-width:calc(100vw - 24px);max-height:calc(100vh - 24px);overflow:auto;padding:10px 12px;border-radius:var(--dsw-radius-lg,12px);background:var(--dsw-alias-bg-overlay);border:1px solid var(--dsw-alias-border-l1);box-shadow:var(--dsw-elevation-panel,0 10px 30px rgba(0,0,0,.18));color:var(--dsw-alias-label-primary);font-size:12px;line-height:18px;animation:cg-pop-in .14s ease}
@keyframes cg-pop-in{from{opacity:0;transform:translateY(3px)}to{opacity:1;transform:none}}
@media (prefers-reduced-motion:reduce){.cg-pop{animation:none}}
.cg-pop-title{display:flex;align-items:baseline;justify-content:space-between;gap:10px;font-size:12px;font-weight:600}
.cg-pop-title-value{font-size:15px;font-weight:650;font-variant-numeric:tabular-nums}
.cg-pop-rule{height:.5px;margin:8px 0;background:var(--dsw-alias-border-l2)}
.cg-pop-list{display:grid;grid-template-columns:auto minmax(0,1fr);gap:4px 12px;margin:0}
.cg-pop-list dt{color:var(--dsw-alias-label-secondary);white-space:nowrap}
.cg-pop-list dd{margin:0;overflow:hidden;text-align:right;text-overflow:ellipsis;white-space:nowrap;font-variant-numeric:tabular-nums}
.cg-pop-total{display:flex;align-items:baseline;justify-content:space-between;gap:10px;color:var(--dsw-alias-label-secondary)}
.cg-pop-total b{color:var(--dsw-alias-label-primary);font-weight:600;font-variant-numeric:tabular-nums}
.cg-pop-hint{margin-top:6px;color:var(--dsw-alias-label-secondary);font-size:11px;line-height:16px}
.cg-pop-hint.cg-error{color:var(--dsw-alias-state-error-primary)}

/* ---------- settings page ---------- */
.cg-settings{display:flex;flex-direction:column;gap:16px;padding:4px 2px 20px;font-size:13.5px}
.cg-section{background:var(--dsw-alias-bg-layer-1);border:1px solid var(--dsw-alias-border-l1);border-radius:var(--dsw-radius-lg,12px);padding:14px 16px}
.cg-section-title{font-size:13.5px;font-weight:650;margin-bottom:10px;display:flex;align-items:center;justify-content:space-between;gap:8px}
.cg-row{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:9px 0;border-bottom:.5px solid var(--dsw-alias-border-l2)}
.cg-row:last-child{border-bottom:none}
.cg-row-label{display:flex;flex-direction:column;gap:2px;min-width:0;flex:1}
.cg-row-label .sub{font-size:11px;color:var(--dsw-alias-label-secondary);line-height:1.4}
.cg-input{background:var(--dsw-alias-bg-layer-2);border:1px solid var(--dsw-alias-border-l1);color:var(--dsw-alias-label-primary);border-radius:8px;padding:6px 9px;font-size:13px;width:120px;transition:border-color .15s ease,box-shadow .15s ease;font-variant-numeric:tabular-nums}
.cg-input:focus{outline:none;border-color:var(--dsw-alias-brand-primary);box-shadow:0 0 0 2px color-mix(in srgb,var(--dsw-alias-brand-primary) 22%,transparent)}
.cg-input.small{width:76px}
.cg-switch{position:relative;width:42px;height:23px;border-radius:999px;border:1px solid var(--dsw-alias-border-l2);background:var(--dsw-alias-bg-layer-2);cursor:pointer;transition:background .2s ease,border-color .2s ease;flex:none;padding:0}
.cg-switch .cg-knob{position:absolute;top:2px;left:2px;width:17px;height:17px;border-radius:50%;background:var(--dsw-alias-label-secondary);transition:transform .22s cubic-bezier(.22,1,.36,1),background .2s ease,box-shadow .2s ease}
.cg-switch.on{background:var(--dsw-alias-brand-primary);border-color:transparent}
.cg-switch.on .cg-knob{transform:translateX(19px);background:#fff;box-shadow:0 1px 4px rgba(0,0,0,.35)}
.cg-switch:focus-visible{outline:2px solid var(--dsw-alias-brand-primary);outline-offset:2px}
.cg-status{display:flex;align-items:center;gap:8px;min-height:18px}
.cg-saved{color:var(--dsw-alias-state-success-primary);font-size:12px;animation:cg-pop .25s ease}
@keyframes cg-pop{from{opacity:0;transform:scale(.92) translateY(8px)}to{opacity:1;transform:none}}
.cg-error{color:var(--dsw-alias-state-error-primary);font-size:12px}
.cg-price-grid{display:grid;grid-template-columns:1.4fr repeat(3,76px) 28px;gap:6px;align-items:center;font-size:11px;color:var(--dsw-alias-label-secondary);padding:3px 0}
.cg-price-grid .head{font-size:10.5px}
.cg-price-grid .name{color:var(--dsw-alias-label-primary);font-size:12px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.cg-del{background:none;border:none;color:var(--dsw-alias-label-secondary);cursor:pointer;font-size:14px;padding:2px 6px;border-radius:6px}
.cg-del:hover{color:var(--dsw-alias-state-error-primary);background:var(--dsw-alias-bg-layer-2)}
.cg-addrow{display:flex;gap:8px;margin-top:10px}
.cg-addrow .cg-input{flex:1;width:auto}
.cg-btn2{padding:7px 13px;border-radius:8px;font-size:12.5px;font-weight:600;border:1px solid var(--dsw-alias-border-l2);background:var(--dsw-alias-bg-layer-2);color:var(--dsw-alias-label-primary);cursor:pointer;transition:transform .12s ease,filter .15s ease}
.cg-btn2:hover{filter:brightness(1.12)}
.cg-btn2:active{transform:scale(.96)}
.cg-btn2.primary{border-color:transparent;background:var(--dsw-alias-brand-primary);color:#fff}
.cg-btn2.danger{color:var(--dsw-alias-state-error-primary);border-color:currentColor;background:transparent}
.cg-statgrid{display:grid;grid-template-columns:repeat(2,1fr);gap:8px;margin-top:8px}
.cg-stat{background:var(--dsw-alias-bg-layer-2);border-radius:9px;padding:9px 11px}
.cg-stat .k{font-size:11px;color:var(--dsw-alias-label-secondary)}
.cg-stat .v{font-size:15px;font-weight:650;font-variant-numeric:tabular-nums}
.cg-io-area{width:100%;min-height:120px;background:var(--dsw-alias-bg-layer-2);border:1px solid var(--dsw-alias-border-l1);border-radius:8px;color:var(--dsw-alias-label-primary);font-family:ui-monospace,monospace;font-size:11px;padding:8px;margin-top:8px;box-sizing:border-box}
.cg-note{font-size:12px;line-height:1.6}
.cg-table{width:100%;border-collapse:collapse;font-size:12px}
.cg-table td{padding:6px 4px;border-top:.5px solid var(--dsw-alias-border-l1);color:var(--dsw-alias-label-secondary);font-variant-numeric:tabular-nums}
.cg-table td:first-child{color:var(--dsw-alias-label-primary)}
`

    function installStyles(ctx) {
      ctx.effect(() => {
        if (document.querySelector('style[data-plugin-css="' + STYLE_ATTR + '"]') !== null) return
        const el = document.createElement('style')
        el.setAttribute('data-plugin-css', STYLE_ATTR)
        el.textContent = CSS
        document.head.appendChild(el)
        return () => el.remove()
      })
    }

    async function rpc(method, args) {
      const response = await fetch('/cost-guard/rpc', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ method, args: args === undefined ? {} : args }),
      })
      if (!response.ok) throw new Error('HTTP ' + response.status)
      const body = await response.json()
      if (body && body.error) throw new Error(body.error)
      return body ? body.result : null
    }

    async function readLive(sessionId, signal) {
      const response = await fetch('/cost-guard/live?sessionId=' + encodeURIComponent(sessionId), {
        cache: 'no-store',
        signal,
      })
      if (!response.ok) throw new Error('HTTP ' + response.status)
      const body = await response.json()
      return body ? body.result : null
    }

    return {
      inject: ['slots'],
      apply(ctx) {
        const slots = ctx.get('slots') || ctx.slots
        if (!slots) return
        const localeSvc = ctx.get('locale')

        installStyles(ctx)

        function currentLang() {
          if (!localeSvc) return 'zh'
          try {
            let snapshot = null
            if (typeof localeSvc.getSnapshot === 'function') snapshot = localeSvc.getSnapshot()
            if (!snapshot && typeof localeSvc.getLocale === 'function') snapshot = localeSvc.getLocale()
            return snapshot && snapshot.active === 'en' ? 'en' : 'zh'
          } catch {
            return 'zh'
          }
        }

        function useLang() {
          const [lang, setLang] = React.useState(currentLang)
          React.useEffect(() => {
            if (!localeSvc || typeof localeSvc.subscribe !== 'function') return undefined
            return localeSvc.subscribe(() => setLang(currentLang()))
          }, [])
          return lang
        }

        function num(v) {
          const n = typeof v === 'number' ? v : Number(v)
          return Number.isFinite(n) && v !== '' ? n : null
        }
        function money(v) {
          if (v === null || v === undefined) return '—'
          const digits = v !== 0 && Math.abs(v) < 0.01 ? 4 : 2
          const text = v.toFixed(digits)
          const [whole, fraction] = text.split('.')
          return '¥' + whole.replace(/\B(?=(\d{3})+(?!\d))/g, ',') + (fraction ? '.' + fraction : '')
        }
        function usdEq(v, rate) {
          if (v === null || v === undefined || !rate) return ''
          const u = v / rate
          return '≈ $' + (u !== 0 && u < 0.01 ? u.toFixed(4) : u.toFixed(2))
        }
        function tok(v) {
          if (v === null || v === undefined) return '—'
          return v >= 1e6 ? (v / 1e6).toFixed(2) + 'M' : v >= 1000 ? (v / 1000).toFixed(1) + 'K' : String(Math.round(v))
        }
        function winsText(wins, lang) {
          if (!wins || !wins.length) return STRINGS[lang].settings.notSet
          return wins.map((w) => w.start + ':00–' + w.end + ':00').join(lang === 'en' ? ', ' : '、')
        }

        function Switch(props) {
          return h(
            'button',
            {
              type: 'button',
              role: 'switch',
              'aria-checked': !!props.on,
              'aria-label': props.label,
              className: 'cg-switch' + (props.on ? ' on' : ''),
              onClick: () => props.onToggle(!props.on),
            },
            h('span', { className: 'cg-knob' }),
          )
        }

        function DraftInput(props) {
          const [text, setText] = React.useState(String(props.value === undefined ? '' : props.value))
          const focused = React.useRef(false)
          React.useEffect(() => {
            if (!focused.current) setText(String(props.value === undefined ? '' : props.value))
          }, [props.value])
          const reset = () => setText(String(props.value === undefined ? '' : props.value))
          const commit = () => {
            const n = num(text)
            if (n === null) {
              reset()
              return
            }
            let v = n
            if (props.min !== undefined && n < props.min) v = props.min
            if (props.max !== undefined && n > props.max) v = props.max
            if (v === props.value) {
              reset()
              return
            }
            setText(String(v))
            props.onCommit(v)
          }
          return h('input', {
            ...(props.inputProps || {}),
            className: 'cg-input' + (props.small ? ' small' : ''),
            type: 'number',
            step: props.step === undefined ? 'any' : props.step,
            min: props.min,
            max: props.max,
            value: text,
            'aria-label': props['aria-label'] || props.label,
            onFocus: () => {
              focused.current = true
            },
            onChange: (event) => setText(event.target.value),
            onBlur: () => {
              focused.current = false
              commit()
            },
            onKeyDown: (event) => {
              if (event.key === 'Enter') event.currentTarget.blur()
              else if (event.key === 'Escape') {
                reset()
                event.currentTarget.blur()
              }
            },
          })
        }

        function NumField(props) {
          const [text, setText] = React.useState(String(props.value))
          React.useEffect(() => {
            setText(String(props.value))
          }, [props.value])
          const commit = (raw) => {
            const n = num(raw)
            if (n === null) {
              setText(String(props.value))
              return
            }
            let v = n
            if (props.min !== undefined && n < props.min) v = props.min
            if (props.max !== undefined && n > props.max) v = props.max
            if (v === props.value) {
              setText(String(props.value))
              return
            }
            setText(String(v))
            props.onCommit(v)
          }
          return h(
            'div',
            { className: 'cg-row' },
            h(
              'span',
              { className: 'cg-row-label' },
              h('span', null, props.label),
              props.sub ? h('span', { className: 'sub' }, props.sub) : null,
            ),
            h('input', {
              className: 'cg-input' + (props.small ? ' small' : ''),
              type: 'number',
              step: props.step === undefined ? 'any' : props.step,
              min: props.min,
              max: props.max,
              value: text,
              'aria-label': props.label,
              onChange: (e) => setText(e.target.value),
              onBlur: () => commit(text),
              onKeyDown: (e) => {
                if (e.key === 'Enter') e.target.blur()
              },
            }),
          )
        }

        function Row(props) {
          return h(
            'div',
            { className: 'cg-row' },
            h(
              'span',
              { className: 'cg-row-label' },
              h('span', null, props.label),
              props.sub ? h('span', { className: 'sub' }, props.sub) : null,
            ),
            props.control,
          )
        }

        function Section(props) {
          return h(
            'div',
            { className: 'cg-section' },
            h('div', { className: 'cg-section-title' }, props.title, props.right || null),
            props.children,
          )
        }

        // ---------------- composer dock cost pill ----------------
        function CostPill(props) {
          const sessionId = props.sessionId || (props.session && props.session.id)
          const [snap, setSnap] = React.useState(null)
          const [open, setOpen] = React.useState(false)
          const [pos, setPos] = React.useState(null)
          const [stale, setStale] = React.useState(false)
          const rootRef = React.useRef(null)
          const buttonRef = React.useRef(null)
          const panelRef = React.useRef(null)
          const panelId = typeof React.useId === 'function' ? React.useId() : 'cg-cost-detail'
          const lang = useLang()
          const s = STRINGS[lang].hud
          const sessionRunning =
            typeof props.useSession === 'function' ? props.useSession((state) => state && state.running === true) : undefined

          React.useEffect(() => {
            if (!sessionId) return undefined
            setSnap(null)
            setStale(false)
            let alive = true
            let timer = null
            let failures = 0
            const controller = new AbortController()
            const load = () => {
              if (document.hidden) return
              readLive(sessionId, controller.signal)
                .then((result) => {
                  if (!alive) return
                  failures = 0
                  setStale(false)
                  if (result && result.present) setSnap(result)
                })
                .catch(() => {
                  if (!alive) return
                  failures += 1
                  if (failures >= 3) setStale(true)
                })
            }
            load()
            timer = window.setInterval(load, POLL_MS)
            return () => {
              alive = false
              controller.abort()
              if (timer !== null) window.clearInterval(timer)
            }
          }, [sessionId])

          React.useEffect(() => {
            if (!open) return undefined
            const onPointer = (event) => {
              if (rootRef.current && rootRef.current.contains(event.target)) return
              if (panelRef.current && panelRef.current.contains(event.target)) return
              setOpen(false)
            }
            const onKey = (event) => {
              if (event.key !== 'Escape') return
              setOpen(false)
              if (buttonRef.current) buttonRef.current.focus()
            }
            document.addEventListener('pointerdown', onPointer, true)
            document.addEventListener('keydown', onKey)
            return () => {
              document.removeEventListener('pointerdown', onPointer, true)
              document.removeEventListener('keydown', onKey)
            }
          }, [open])

          React.useLayoutEffect(() => {
            if (!open) {
              setPos(null)
              return undefined
            }
            const place = () => {
              const button = buttonRef.current
              const panel = panelRef.current
              if (!button || !panel) return
              const anchor = button.getBoundingClientRect()
              const box = panel.getBoundingClientRect()
              const margin = 12
              const gap = 8
              let left = anchor.left + anchor.width / 2 - box.width / 2
              left = Math.max(margin, Math.min(left, window.innerWidth - box.width - margin))
              let top = anchor.top - box.height - gap
              if (top < margin) top = Math.min(anchor.bottom + gap, window.innerHeight - box.height - margin)
              setPos({ left, top })
            }
            place()
            window.addEventListener('resize', place)
            return () => window.removeEventListener('resize', place)
          }, [open])

          if (!snap) return null
          const cur = snap.current
          const logRunning = cur ? cur.status === 'running' || cur.status === 'open' : false
          const running = sessionRunning === undefined ? logRunning : sessionRunning
          const view = running ? cur : cur && cur.actual && cur.actual.cost > 0 ? cur : snap.lastFinal
          if (!view || !view.actual) return null
          const a = view.actual
          if (!running && a.cost === 0) return null
          const total = typeof snap.sessionTotal === 'number' ? snap.sessionTotal : snap.spentTotal || 0
          const rows = [
            ['model', s.model, view.model || '—'],
            ['input', s.inputMiss, tok(a.input)],
          ]
          if (a.cacheRead) rows.push(['cacheRead', s.cacheRead, tok(a.cacheRead)])
          if (a.cacheWrite) rows.push(['cacheWrite', s.cacheWrite, tok(a.cacheWrite)])
          rows.push(['output', s.out, tok(a.output)])
          rows.push(['calls', s.calls, String(a.steps) + s.callsUnit])
          if (view.retries) rows.push(['retries', s.retries, String(view.retries)])
          if (view.peak === true) rows.push(['rate', s.price, s.peak])
          else if (view.peak === false) rows.push(['rate', s.price, s.offpeak])

          return h(
            'span',
            { ref: rootRef, className: 'cg-cost-root', 'data-composer-stat': 'cost' },
            h(
              'button',
              {
                ref: buttonRef,
                type: 'button',
                className: 'cg-cost-pill',
                'data-idle': running ? 'false' : 'true',
                'aria-haspopup': 'dialog',
                'aria-expanded': open,
                'aria-controls': panelId,
                'aria-label': (running ? s.running : s.idle) + ' · ' + money(a.cost),
                title: s.open,
                onClick: () => setOpen(!open),
              },
              running ? h('span', { className: 'cg-cost-dot', 'aria-hidden': true }) : null,
              h('span', { className: 'cg-cost-value' }, money(a.cost)),
            ),
            open
              ? ReactDOM.createPortal(
                  h(
                    'div',
                    {
                      id: panelId,
                      ref: panelRef,
                      className: 'cg-pop',
                      role: 'dialog',
                      'aria-label': running ? s.title : s.titleLast,
                      style: pos ? { left: pos.left, top: pos.top } : { left: 0, top: 0, visibility: 'hidden' },
                    },
                    h(
                      'div',
                      { className: 'cg-pop-title' },
                      h('span', null, running ? s.title : s.titleLast),
                      h('span', { className: 'cg-pop-title-value' }, money(a.cost)),
                    ),
                    h('div', { className: 'cg-pop-rule' }),
                    h(
                      'dl',
                      { className: 'cg-pop-list' },
                      rows.map((row) =>
                        h(React.Fragment, { key: row[0] }, h('dt', null, row[1]), h('dd', null, row[2])),
                      ),
                    ),
                    h('div', { className: 'cg-pop-rule' }),
                    h('div', { className: 'cg-pop-total' }, h('span', null, s.total), h('b', null, money(total))),
                    snap.usdRate ? h('div', { className: 'cg-pop-hint' }, usdEq(total, snap.usdRate)) : null,
                    stale ? h('div', { className: 'cg-pop-hint cg-error' }, s.stale) : null,
                  ),
                  document.body,
                )
              : null,
          )
        }

        // ---------------- settings page ----------------
        function SettingsPage() {
          const [cfg, setCfg] = React.useState(null)
          const [extra, setExtra] = React.useState({ modelStats: {}, totals: {}, pricingVerified: null })
          const [saved, setSaved] = React.useState(false)
          const [err, setErr] = React.useState(null)
          const [addModel, setAddModel] = React.useState('')
          const [resetArmed, setResetArmed] = React.useState(false)
          const [ioOpen, setIoOpen] = React.useState(false)
          const [ioText, setIoText] = React.useState('')
          const timers = React.useRef([])
          const saveSeq = React.useRef(0)
          const lang = useLang()
          const s = STRINGS[lang].settings
          const hudS = STRINGS[lang].hud

          React.useEffect(
            () => () => {
              for (const id of timers.current) {
                try {
                  window.clearTimeout(id)
                } catch {
                  /* ignore */
                }
              }
              timers.current = []
            },
            [],
          )
          const later = (fn, ms) => {
            const id = window.setTimeout(fn, ms)
            timers.current.push(id)
            return id
          }

          React.useEffect(() => {
            rpc('config.get')
              .then((res) => {
                if (res && res.config) {
                  setCfg(res.config)
                  setExtra({
                    modelStats: res.modelStats || {},
                    totals: res,
                    pricingVerified: res.pricingVerified || null,
                  })
                }
              })
              .catch(() => setErr(s.hostUnreachable))
          }, [])

          const flash = () => {
            setSaved(true)
            setErr(null)
            later(() => setSaved(false), 1600)
          }
          const save = (patch) => {
            const seq = ++saveSeq.current
            rpc('config.set', { patch })
              .then((res) => {
                if (seq !== saveSeq.current) return
                if (res && res.ok && res.config) {
                  setCfg(res.config)
                  flash()
                } else setErr((res && res.errors && res.errors.join('、')) || s.saveFailed)
              })
              .catch(() => {
                if (seq === saveSeq.current) setErr(s.saveConnFailed)
              })
          }
          const callAndRefresh = (method, args) => {
            const seq = ++saveSeq.current
            rpc(method, args)
              .then((res) => {
                if (seq !== saveSeq.current) return
                if (res && res.ok && res.config) {
                  setCfg(res.config)
                  flash()
                } else setErr(s.opFailed)
              })
              .catch(() => {
                if (seq === saveSeq.current) setErr(s.opConnFailed)
              })
          }

          if (!cfg) {
            return h('div', { className: 'cg-settings cg-root' }, err ? h('div', { className: 'cg-error' }, err) : h('div', { className: 'cg-muted' }, s.loading))
          }

          const peak = cfg.pricing.peak
          const priceKeys = Object.keys(cfg.pricing).filter((k) => k !== 'peak')
          const builtins = { 'deepseek-flash': 1, 'deepseek-v4-pro': 1, default: 1 }
          const ms = extra.modelStats || {}
          const totals = extra.totals || {}
          const peakWins = peak.windows || []
          const editWindow = (i, field, value) => {
            const v = num(value)
            if (v === null || v < 0 || v > 23) return
            const wins = peakWins.map((w, j) => (j === i ? Object.assign({}, w, { [field]: Math.round(v) }) : w))
            save({ pricing: { peak: { windows: wins } } })
          }
          const setPrice = (key, field, raw) => {
            const v = num(raw)
            if (v === null || v < 0 || v > 1000) return
            const patch = { pricing: {} }
            patch.pricing[key] = {}
            patch.pricing[key][field] = v
            save(patch)
          }

          return h(
            'div',
            { className: 'cg-settings cg-root' },
            h(
              'div',
              { className: 'cg-status', 'aria-live': 'polite' },
              saved ? h('span', { className: 'cg-saved' }, s.saved) : null,
              err ? h('span', { className: 'cg-error' }, err) : null,
            ),

            h(
              Section,
              {
                title: s.pricingTitle,
                right: h(
                  'button',
                  {
                    className: 'cg-btn2' + (resetArmed ? ' danger' : ''),
                    onClick: () => {
                      if (!resetArmed) {
                        setResetArmed(true)
                        later(() => setResetArmed(false), 3000)
                        return
                      }
                      setResetArmed(false)
                      callAndRefresh('config.reset-pricing')
                    },
                  },
                  resetArmed ? s.resetConfirm : s.resetPricing,
                ),
              },
              h(Row, {
                label: s.peakToggle,
                sub: s.peakToggleSub(peak.multiplier, winsText(peakWins, lang)),
                control: h(Switch, {
                  on: peak.enabled,
                  label: s.peakToggle,
                  onToggle: (v) => save({ pricing: { peak: { enabled: v } } }),
                }),
              }),
              h(NumField, {
                label: s.multiplier,
                sub: s.multiplierSub,
                value: peak.multiplier,
                step: 0.5,
                min: 1,
                max: 10,
                onCommit: (v) => save({ pricing: { peak: { multiplier: v } } }),
              }),
              h(Row, {
                label: s.windows,
                sub: s.windowsSub,
                control: h(
                  'div',
                  { style: { display: 'flex', flexDirection: 'column', gap: 6, alignItems: 'flex-end' } },
                  peakWins.map((w, i) =>
                    h(
                      'div',
                      { key: i, style: { display: 'flex', gap: 6, alignItems: 'center' } },
                      h(DraftInput, {
                        small: true,
                        value: w.start,
                        min: 0,
                        max: 23,
                        step: 1,
                        label: s.windows + ' start',
                        onCommit: (v) => editWindow(i, 'start', v),
                      }),
                      h('span', { className: 'cg-muted' }, '—'),
                      h(DraftInput, {
                        small: true,
                        value: w.end,
                        min: 0,
                        max: 23,
                        step: 1,
                        label: s.windows + ' end',
                        onCommit: (v) => editWindow(i, 'end', v),
                      }),
                    ),
                  ),
                ),
              }),
              h('div', { className: 'cg-muted', style: { fontSize: 11, lineHeight: 1.5 } }, s.holidaysNote),
              h(
                'div',
                { className: 'cg-price-grid' },
                h('span', { className: 'head' }, s.colModel),
                h('span', { className: 'head' }, s.colInputMiss),
                h('span', { className: 'head' }, s.colOutput),
                h('span', { className: 'head' }, s.colCacheHit),
                h('span', null),
              ),
              priceKeys.map((key) =>
                h(
                  'div',
                  { className: 'cg-price-grid', key },
                  h('span', { className: 'name' }, key === 'default' ? s.otherModel : key),
                  ['input', 'output', 'cacheRead'].map((field, column) =>
                    h(DraftInput, {
                      key: field,
                      small: true,
                      value: cfg.pricing[key][field],
                      min: 0,
                      max: 1000,
                      step: 'any',
                      label: (key === 'default' ? s.otherModel : key) + ' ' + [s.colInputMiss, s.colOutput, s.colCacheHit][column],
                      onCommit: (v) => setPrice(key, field, v),
                    }),
                  ),
                  builtins[key]
                    ? h('span', null)
                    : h(
                        'button',
                        {
                          className: 'cg-del',
                          onClick: () => {
                            const patch = { pricing: {} }
                            patch.pricing[key] = null
                            save(patch)
                          },
                        },
                        '✕',
                      ),
                ),
              ),
              h(
                'div',
                { className: 'cg-addrow' },
                h('input', { className: 'cg-input', placeholder: s.addPlaceholder, value: addModel, onChange: (ev) => setAddModel(ev.target.value) }),
                h(
                  'button',
                  {
                    className: 'cg-btn2',
                    onClick: () => {
                      const name = addModel.trim()
                      if (!name) return
                      const exists = Object.keys(cfg.pricing).some(
                        (key) => key !== 'peak' && key.toLowerCase() === name.toLowerCase(),
                      )
                      if (exists) {
                        setErr(s.duplicateModel)
                        return
                      }
                      const base = cfg.pricing['deepseek-flash'] || cfg.pricing.default
                      const patch = { pricing: {} }
                      patch.pricing[name] = { input: base.input, output: base.output, cacheRead: base.cacheRead }
                      save(patch)
                      setAddModel('')
                    },
                  },
                  s.add,
                ),
              ),
              h('div', { className: 'cg-muted', style: { fontSize: 11, marginTop: 8 } }, s.cacheWriteNote),
            ),

            h(
              Section,
              { title: s.totalsTitle },
              h(
                'div',
                { className: 'cg-statgrid' },
                h('div', { className: 'cg-stat' }, h('div', { className: 'k' }, s.statTurns), h('div', { className: 'v' }, totals.turnsTracked || 0)),
                h('div', { className: 'cg-stat' }, h('div', { className: 'k' }, s.statSpent), h('div', { className: 'v' }, money(totals.spentTotal || 0))),
              ),
              h('div', { className: 'cg-muted', style: { fontSize: 11, marginTop: 6 } }, s.totalsSub),
              h(NumField, {
                label: s.statRate,
                sub: s.rateSub,
                value: cfg.display.usdRate,
                step: 0.1,
                min: 0.5,
                max: 20,
                onCommit: (v) => save({ display: { usdRate: v } }),
              }),
              Object.keys(ms).length
                ? h(
                    'table',
                    { className: 'cg-table' },
                    h(
                      'tbody',
                      null,
                      Object.keys(ms).map((model) => {
                        const row = ms[model]
                        return h(
                          'tr',
                          { key: model },
                          h('td', null, model + ' ×' + row.count),
                          h('td', null, hudS.in + tok(row.input) + ' · ' + hudS.out + tok(row.output)),
                          h('td', null, money(row.cost)),
                        )
                      }),
                    ),
                  )
                : h('div', { className: 'cg-muted' }, s.noSamples),
              h(
                'div',
                { className: 'cg-muted cg-note', style: { marginTop: 10 } },
                s.priceSource(extra.pricingVerified || '2026-10-28'),
                ' ',
                h(
                  'a',
                  {
                    href:
                      lang === 'en'
                        ? 'https://api-docs.deepseek.com/quick_start/pricing'
                        : 'https://api-docs.deepseek.com/zh-cn/quick_start/pricing/',
                    target: '_blank',
                    rel: 'noreferrer',
                  },
                  s.pricingLink,
                ),
              ),
              h('div', { className: 'cg-muted cg-note' }, s.searchNote),
            ),

            h(
              Section,
              { title: s.backupTitle, right: h('button', { className: 'cg-btn2', onClick: () => setIoOpen(!ioOpen) }, ioOpen ? s.backupClose : s.backupOpen) },
              ioOpen
                ? h(
                    'div',
                    null,
                    h('textarea', { className: 'cg-io-area', placeholder: s.ioPlaceholder, value: ioText, onChange: (ev) => setIoText(ev.target.value) }),
                    h(
                      'div',
                      { style: { display: 'flex', gap: 8, marginTop: 8 } },
                      h(
                        'button',
                        {
                          className: 'cg-btn2 primary',
                          onClick: () => {
                            let parsed = null
                            try {
                              parsed = JSON.parse(ioText)
                            } catch {
                              setErr(s.importBadJson)
                              return
                            }
                            rpc('config.import', { json: parsed })
                              .then((res) => {
                                if (res && res.ok && res.config) {
                                  setCfg(res.config)
                                  flash()
                                } else setErr(s.importBadJson)
                              })
                              .catch(() => setErr(s.importConnFailed))
                          },
                        },
                        s.importBtn,
                      ),
                      h(
                        'button',
                        {
                          className: 'cg-btn2',
                          onClick: () => {
                            rpc('config.export')
                              .then((res) => {
                                if (res && res.json) setIoText(JSON.stringify(res.json, null, 2))
                              })
                              .catch(() => {})
                          },
                        },
                        s.exportBtn,
                      ),
                    ),
                  )
                : null,
            ),

            h('div', { className: 'cg-muted cg-note' }, s.footnote),
          )
        }

        slots.inject('conversation.composer.dock', () =>
          slots.register({ name: 'conversation.composer.dock', id: 'cost', order: 2 }, CostPill),
        )
        slots.inject('settings.section', () =>
          slots.register(
            { name: 'settings.section', id: 'cost-guard', order: 40, label: () => STRINGS[currentLang()].settings.label },
            SettingsPage,
          ),
        )
      },
    }
  },
})
