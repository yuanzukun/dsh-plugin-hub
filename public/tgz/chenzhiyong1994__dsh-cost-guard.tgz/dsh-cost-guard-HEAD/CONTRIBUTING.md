# Contributing

Thanks for helping improve `dsh-cost-guard`.

## Before opening a change

- Search existing issues first.
- Keep pull requests focused on one behavior or documentation improvement.
- For compatibility bugs, include the DSH version, profile, operating system, and a minimal reproduction.
- Never commit credentials, DSH session logs, private configuration, or screenshots containing personal information.

## Development loop

1. Edit `index.js` (Host) and/or `client.js` (Web Client).
2. Run `npm run check`.
3. Reinstall the bundle in your profile (`dsh plugin --profile <profile> add <path>`), then restart DSH; a linked install picks up edited files on restart.
4. Confirm the `cost-guard` row is `active` in **Settings → Plugins**, then check the composer cost pill and **Settings → Cost Guard**.
5. Update `CHANGELOG.md` for user-visible behavior changes.

The Host half is a plain ES module (`export const inject`, `export function apply`); the Client half is a `window.__ModuleLoader__.load` bundle that takes React from the host module table. No transpiler, bundler, or JSX is involved.

## Project website

For homepage changes, follow the [website preview and publishing guide](docs/website.md). Keep both languages and installation instructions in sync, and verify the layout and interactions on desktop and mobile.

## Pricing changes

Price data changes quickly. Any default-rate update must link to a primary provider source and include the date it was verified. Currency values remain estimates; do not describe them as authoritative billing totals.

## Pull requests

Explain the user-facing problem, the chosen change, the DSH versions tested, and the verification performed. By contributing, you agree that your contribution is licensed under the MIT License.
