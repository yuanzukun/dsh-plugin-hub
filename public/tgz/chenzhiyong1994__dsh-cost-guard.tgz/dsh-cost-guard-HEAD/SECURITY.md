# Security Policy

## Supported version

Security fixes target the latest release.

## Reporting a vulnerability

Please use GitHub's private vulnerability reporting or a private security advisory when available. If neither option is available, contact the maintainer through the GitHub profile without publishing exploit details.

Include the affected version, DSH version, impact, reproduction steps, and any suggested mitigation. Please do not include real API keys, session logs, or personal data.

## Data boundary

`dsh-cost-guard` is designed to run locally. It observes DSH usage events, rebuilds totals from persisted session events on demand, stores pricing in `$DSH_HOME/cost-guard/config.json` (default `~/.dsh`), and serves three routes on the DSH web server: `GET /cost-guard/live`, `POST /cost-guard/rpc`, and `GET /cost-guard/health`.

Those routes enforce no authentication of their own; the DSH web server's bind address is the security boundary. The shipped Web composition binds loopback, but a profile that binds a non-loopback address exposes the routes to that network. `POST /cost-guard/rpc` additionally requires `Content-Type: application/json`, which blocks cross-origin form and no-preflight writes from a browser.

The plugin does not intentionally send telemetry, call external endpoints, read credentials, or store API keys. Pricing is an estimate from configured rates; it is not billing data.

The plugin relies on DSH services and UI slots. Review source changes before updating because those interfaces are not guaranteed stable.
