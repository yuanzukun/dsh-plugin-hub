// Bundle checks: the package must be a well-formed Cordis bundle with a Web
// Client half, and the public release facts must stay in sync.
const fs = require('fs')
const path = require('path')
const assert = require('assert')
const { pathToFileURL } = require('url')

const root = path.join(__dirname, '..')
let ok = true

function fail(label, error) {
  ok = false
  console.error(`[check] FAIL ${label}: ${error.message}`)
}

async function main() {
  // 1. syntax: the Host half is an ES module, the Client half is a script.
  try {
    await import(pathToFileURL(path.join(root, 'index.js')).href)
    console.log('[check] ok   index.js (ES module)')
  } catch (error) {
    fail('index.js', error)
  }
  try {
    // eslint-disable-next-line no-new-func
    new Function(fs.readFileSync(path.join(root, 'client.js'), 'utf8'))
    console.log('[check] ok   client.js (module-loader script)')
  } catch (error) {
    fail('client.js', error)
  }

  // 2. manifest and bundle layout
  try {
    const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'))
    assert.strictEqual(pkg.name, 'dsh-cost-guard')
    assert.strictEqual(pkg.type, 'module', 'the bundle must be an ES module package')
    assert.strictEqual(pkg.exports['.'], './index.js', 'the Host entry must be exported as "."')
    assert.strictEqual(pkg.exports['./client'], './client.js', 'the Client entry must be exported as "./client"')
    assert(pkg.exports['./locale/*.json'], 'locale resources must be exported')
    assert(pkg.exports['./icon'], 'the icon must be exported')
    assert.strictEqual(pkg.dsh.bundle.patch, './cordis.patch.yml', 'dsh.bundle.patch must point at the patch')
    assert.strictEqual(pkg.dsh.client.platform, 'web', 'the Client half must declare platform "web"')
    assert(Array.isArray(pkg.dsh.client.inject) && pkg.dsh.client.inject.length > 0, 'dsh.client.inject must order activation')
    for (const file of ['index.js', 'client.js', 'cordis.patch.yml', 'icon.svg']) {
      assert(fs.existsSync(path.join(root, file)), `missing ${file}`)
      assert(pkg.files.some((entry) => entry === file || entry.startsWith(file.split('/')[0])), `${file} must be listed in files`)
    }
    for (const locale of ['en', 'zh']) {
      const file = path.join(root, 'locale', `${locale}.json`)
      assert(fs.existsSync(file), `missing locale/${locale}.json`)
      const meta = JSON.parse(fs.readFileSync(file, 'utf8')).meta
      assert(meta && meta.title && meta.description, `locale/${locale}.json needs meta.title and meta.description`)
    }
    console.log('[check] ok   bundle manifest, exports, and display metadata')
  } catch (error) {
    fail('manifest', error)
  }

  // 3. the patch inserts exactly the shipped row
  try {
    const patch = fs.readFileSync(path.join(root, 'cordis.patch.yml'), 'utf8')
    assert(/^-\s*insert:/m.test(patch), 'cordis.patch.yml must declare an insert list')
    assert(/id:\s*cost-guard/.test(patch), 'cordis.patch.yml must insert the cost-guard row')
    assert(/name:\s*'dsh-cost-guard'/.test(patch), 'cordis.patch.yml must name the package')
    const host = fs.readFileSync(path.join(root, 'index.js'), 'utf8')
    assert(host.includes("inject = ['webServer']"), 'the Host half must inject webServer')
    assert(host.includes('/cost-guard/live') && host.includes('/cost-guard/rpc'), 'the Host half must serve its two routes')
    assert(host.includes('peakEnabled'), 'the Host half must report peak/off-peak state')
    assert(host.includes("PRICING_VERIFIED = '2026-10-28'"), 'the Host half must record the pricing verification date')
    assert(host.includes("'deepseek-flash'") && host.includes("'deepseek-v4-pro'"), 'the Host pricing must use the current model ids')
    assert(/input:\s*1,\s*output:\s*4,\s*cacheRead:\s*0\.02/.test(host), 'Flash defaults must be the 2026-10-28 off-peak rates')
    assert(/days:\s*\[1,\s*2,\s*3,\s*4,\s*5\]/.test(host), 'peak pricing must be weekday-only by default')
    assert(host.includes("'2026-10-01'") && host.includes("'2026-10-07'"), 'the 2026 statutory holidays must be built in')
    assert(host.includes('assistant/attempt'), 'the Host half must fold attempt usage')
    const client = fs.readFileSync(path.join(root, 'client.js'), 'utf8')
    assert(client.includes("id: 'dsh-cost-guard'"), 'the Client bundle must register the package id')
    assert(client.includes('conversation.composer.dock'), 'the Client half must register the composer cost pill')
    assert(client.includes('settings.section'), 'the Client half must register the settings section')
    assert(client.includes("data-composer-stat") && client.includes('cg-cost-pill'), 'the Client half must render the dock cost pill')
    assert(client.includes('cg-pop'), 'the Client half must render the cost details popover')
    console.log('[check] ok   patch, Host routes, pricing invariants, and Client registrations')
  } catch (error) {
    fail('wiring', error)
  }

  // 4. release facts
  try {
    const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'))
    const changelog = fs.readFileSync(path.join(root, 'CHANGELOG.md'), 'utf8')
    const readme = fs.readFileSync(path.join(root, 'README.md'), 'utf8')
    const readmeZh = fs.readFileSync(path.join(root, 'README.zh-CN.md'), 'utf8')
    assert(changelog.includes(`[${pkg.version}]`), 'CHANGELOG must include the package version')
    assert(readme.includes(`v${pkg.version}`), 'English README must include the package version')
    assert(readmeZh.includes(`v${pkg.version}`), 'Chinese README must include the package version')
    assert(readme.includes('README.zh-CN.md') && readmeZh.includes('README.md'), 'language switch links are missing')
    for (const required of ['LICENSE', 'README.md', 'README.zh-CN.md', 'CHANGELOG.md', 'CONTRIBUTING.md', 'SECURITY.md', 'docs/assets/hero-cost-guard.png', 'docs/screenshots/hud-idle.png', 'docs/screenshots/settings-pricing.png']) {
      assert(fs.existsSync(path.join(root, required)), `missing ${required}`)
    }
    console.log(`[check] ok   release facts v${pkg.version}`)
  } catch (error) {
    fail('release facts', error)
  }

  if (!ok) process.exit(1)
  console.log('[check] all checks passed: bundle layout, both halves, and release facts are consistent')
}

main()
