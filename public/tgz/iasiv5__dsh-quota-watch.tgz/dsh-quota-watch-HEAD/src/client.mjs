import { CLIENT_POLL_INTERVAL_MS, CLIENT_ROUTES, PROVIDER_IDS } from './shared.mjs'
import { remainingToUsed } from './core/adapters.mjs'
import { MARGIN, clampPoint, loadFloatPosition, loadSurfaceFlags, saveFloatPosition, saveSurfaceFlags, titlebarTopInset } from './client/prefs.mjs'
import { DRAG_SLOP_MOUSE, DRAG_SLOP_TOUCH, parseInset, clampFrame, dragSlop, grabOffset } from './client/drag.mjs'
import { createResetCards } from './client/reset-cards.mjs'

export const name = 'quota-watch-client'
// 2026-10-13: the shell-takeover sentinel reads the OFFICIAL slots ledger, so
// the client now touches ctx.slots — cordis denies undeclared service access
// ("cannot get property 'slots' without inject") and the whole activation
// dies. Declare BEFORE using; the bundle + package.json dsh.client.inject
// must stay in lockstep (locked by tests/package-shape.test.mjs).
export const inject = ['slots']

const CARD_SELECTOR = '[data-dsh-quota-watch-card]'
const FLOAT_SELECTOR = '[data-dsh-quota-watch-float]'
const FETCH_TIMEOUT_MS = 15_000
// Measured-size fallback for environments where getBoundingClientRect reports
// zeros (jsdom) or the capsule has not painted yet.
const FALLBACK_SIZE = { width: 38, height: 26 }
const ZERO_INSETS = { left: 0, right: 0, top: 0, bottom: 0 }
// Below this a mounted card would clip into unreadable text (collapsed web
// rails, squeezed desktop layouts) — hide it and let the capsule carry the
// entry. clientWidth 0 (no layout yet, jsdom) counts as "unknown", not narrow.
const CARD_MIN_WIDTH = 160
// Official sidebar foot action slot (dsh-client-ui-sidebar contract). The
// slot-first seat mounts the card through it; the sidebarCol/footArea
// substring discovery stays as the legacy-host fallback.
const CARD_SLOT_NAME = 'sidebar.footer.action'

/** Host React for the sidebar.footer.action slot seat (0.2.x shells render
 * registrant components with their own React). The module-loader factory
 * passes `require`; a direct ESM import (node --test, DOM tests) has none, in
 * which case slot mode simply stays off and the physical-insert fallback runs
 * exactly as before. Never throws. */
function loadReact() {
  try {
    return typeof require === 'function' ? require('react') : null
  } catch {
    return null
  }
}

export const COPY = {
  zh: {
    title: 'Token额度',
    openDetails: '查看详情',
    close: '关闭',
    actions: {
      showCard: '显示侧边栏卡片',
      hideCard: '隐藏侧边栏卡片',
      refreshNow: '立即刷新',
      refreshing: '刷新中',
    },
    backToOverview: '返回额度概览',
    providerNames: { glm: 'GLM', copilot: 'Copilot' },
    refresh: '刷新',
    loading: '读取中',
    failed: '查询失败',
    stale: '数据可能已过期',
    authRejected: '凭证已被服务商拒绝，请重新授权',
    requestFailed: '刷新失败，显示上次成功数据',
    available: '可用额度',
    used: '本期已用',
    reset: '重置',
    resetTime: '重置时间',
    windowUsed: '已用',
    todayTokens: '今日 Tokens',
    todayCalls: '调用次数',
    todayModelsUnavailable: '今日分模型数据暂不可用',
    weekUnlimited: '每周额度',
    unlimited: '♾️',
    unlimitedNote: '（ 无限 ）',
    // Full-width paren pair for zh: both window-grid notes share the same
    // glyph class so their left edges line up.
    noteOpen: '（ ',
    noteClose: ' ）',
    windows: {
      '5h': '5 小时额度',
      week: '每周额度',
      month: '每月额度',
      mcp: 'MCP（月）',
    },
    resetCards: {
      section: '额度重置卡',
      querying: '查询中',
      week: '每周重置卡',
      fiveHour: '5 小时重置卡',
      count: '{count} 张',
      none: '无可用',
      use: '重置',
      expiry: '{date} 前有效',
      expiryAssumed: '无时区字段按北京时间解读，非上游官方说明',
      unconfirmed: '结果未确认，请核对服务商官方卡数和额度',
      outcomeUnknownTitle: '上次手动用卡结果未确认',
      outcomeUnknownBody: '可能已消耗一张重置卡，且不会自动重试。请先核对服务商官方卡数与额度，再标记「我已核实」。',
      verifyButton: '我已核实',
      knownSuccessTitle: '上次手动用卡：已确认成功',
      knownRefusedTitle: '上次手动用卡：上游明确拒绝',
      acknowledgeButton: '我已了解结果',
      storageUnavailable: '手动用卡暂不可用（结果记录无法读取）',
      confirmTitle: '确认使用重置卡？',
      confirmWeek: '将消耗 1 张每周重置卡，立即重置每周额度与 5 小时额度。',
      confirmFiveHour: '将消耗 1 张 5 小时重置卡，立即重置 5 小时额度。',
      confirmIrreversible: '重置卡用掉即消失，无法撤销。',
      ok: '确认重置',
      cancel: '取消',
      working: '重置中…',
      succeeded: '已重置',
      failed: '重置失败',
    },
  },
  en: {
    title: 'Quota Watch',
    openDetails: 'View details',
    close: 'Close',
    actions: {
      showCard: 'Show sidebar card',
      hideCard: 'Hide sidebar card',
      refreshNow: 'Refresh now',
      refreshing: 'Refreshing',
    },
    backToOverview: 'Back to quota overview',
    providerNames: { glm: 'GLM', copilot: 'Copilot' },
    refresh: 'Refresh',
    loading: 'Loading',
    failed: 'Query failed',
    stale: 'Data may be stale',
    authRejected: 'Credential rejected by provider — re-authorize',
    requestFailed: 'Refresh failed; showing last successful data',
    available: 'Available credits',
    used: 'Used this cycle',
    reset: 'Resets',
    resetTime: 'Reset time',
    windowUsed: 'used',
    todayTokens: 'Today tokens',
    todayCalls: 'Calls',
    todayModelsUnavailable: 'Per-model data unavailable today',
    weekUnlimited: 'Weekly quota',
    unlimited: '♾️',
    unlimitedNote: '( unlimited )',
    // ASCII parens for en — and NO leading space: the note must start with
    // the same glyph as the reset notes or the grid's left edges diverge
    // (0.1.15 shipped ' ( unlimited )', which broke alignment against the
    // full-width （ Resets: … ） notes the template used to emit in en too).
    noteOpen: '( ',
    noteClose: ' )',
    windows: {
      '5h': '5-hour quota',
      week: 'Weekly quota',
      month: 'Monthly quota',
      mcp: 'MCP (month)',
    },
    resetCards: {
      section: 'Quota reset cards',
      querying: 'Checking',
      week: 'Weekly reset card',
      fiveHour: '5-hour reset card',
      count: '{count}',
      none: 'none',
      use: 'Reset',
      expiry: 'expires {date}',
      expiryAssumed: 'No-zone stamps are read as Beijing time — not an official upstream statement',
      unconfirmed: 'Outcome unconfirmed — check the official card count and quota',
      outcomeUnknownTitle: 'Last manual reset outcome unconfirmed',
      outcomeUnknownBody: 'A card may have been spent and nothing retries automatically. Check the official card count and quota first, then confirm below.',
      verifyButton: 'I verified it',
      knownSuccessTitle: 'Last manual reset: confirmed success',
      knownRefusedTitle: 'Last manual reset: refused upstream',
      acknowledgeButton: 'I acknowledge',
      storageUnavailable: 'Manual card use unavailable (outcome journal unreadable)',
      confirmTitle: 'Use a reset card?',
      confirmWeek: 'This spends 1 weekly reset card and immediately resets both the weekly and 5-hour quotas.',
      confirmFiveHour: 'This spends 1 5-hour reset card and immediately resets the 5-hour quota.',
      confirmIrreversible: 'The card is consumed and cannot be restored.',
      ok: 'Use card',
      cancel: 'Cancel',
      working: 'Resetting…',
      succeeded: 'Reset done',
      failed: 'Reset failed',
    },
  },
}

const STYLE_TEXT = `
:host { box-sizing: border-box; width: 100%; margin: 0 0 8px; color: var(--dsw-alias-label-primary, inherit); font: inherit; }
:host *, :host *::before, :host *::after { box-sizing: border-box; }
.dqw-card { position: relative; border: 1px solid var(--dsw-alias-border-secondary, rgba(128,128,128,.35)); border-radius: 10px; background: var(--dsw-alias-bg-base, rgba(128,128,128,.08)); padding: 5px 8px; display: flex; flex-direction: column; gap: 2px; }
.dqw-meta { margin: 0; font-size: 10px; line-height: 14px; opacity: .7; }
.dqw-body { display: flex; flex-direction: column; }
.dqw-row-summary { display: flex; align-items: center; gap: 6px; padding: 3px 6px; margin: 0 -2px; border-radius: 8px; }
.dqw-row-summary[data-expandable] { cursor: pointer; }
.dqw-row-summary[data-expandable]:hover { background: var(--dsw-alias-bg-hover, rgba(128,128,128,.12)); }
.dqw-row-summary:focus-visible { outline: 1px solid var(--dsw-alias-button-primary-fill, #5b8def); outline-offset: -1px; }
.dqw-row-summary.is-error { cursor: default; }
.dqw-label { font-size: 11px; font-weight: 600; width: 52px; flex: none; }
.dqw-label[data-action="refresh"] { cursor: pointer; border-radius: 4px; }
.dqw-label[data-action="refresh"]:hover { opacity: .75; }
.dqw-bar { display: block; flex: 1; height: 4px; overflow: hidden; border-radius: 4px; background: var(--dsw-alias-bg-tertiary, rgba(128,128,128,.2)); }
.dqw-bar-fill { display: block; height: 100%; border-radius: inherit; background: var(--dsw-alias-button-primary-fill, #5b8def); }
.dqw-bar-fill.warn { background: var(--dsw-alias-label-warning, #d29922); }
.dqw-bar-fill.danger { background: var(--dsw-alias-label-danger, #c93c3c); }
.dqw-pct { font-size: 10.5px; line-height: 14px; font-variant-numeric: tabular-nums; width: 30px; text-align: right; flex: none; }
.dqw-extra { font-size: 10px; line-height: 14px; opacity: .72; font-variant-numeric: tabular-nums; flex: none; min-width: 34px; text-align: right; }
.dqw-chev { font-size: 9px; line-height: 14px; opacity: .6; flex: none; width: 10px; text-align: center; }
.dqw-stale-mark { flex: none; font-size: 9px; line-height: 14px; color: var(--dsw-alias-label-warning, #b46900); cursor: help; }
.dqw-errtext { font-size: 10px; line-height: 14px; opacity: .7; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
@media print { :host { display: none !important; } }
`

// Float shell (capsule) and the panel live on their own shadow host at the
// document root — ADR 0001 isolation, and survival without any sidebar DOM
// (collapsed sidebar, desktop profile). Panel content shares the card's visual
// language, so the row/detail rules are duplicated into THIS shadow root; the
// card shadow keeps its own copies for the sidebar rows.
const FLOAT_STYLE_TEXT = `
:host { position: fixed; z-index: 2147483000; }
.dqw-capsule { display: inline-flex; align-items: center; gap: 6px; height: 26px; padding: 0 10px; border: 1px solid var(--dsw-alias-border-secondary, rgba(128,128,128,.35)); border-radius: 999px; background: var(--dsw-alias-bg-base, rgba(128,128,128,.08)); background: color-mix(in srgb, var(--dsw-alias-bg-base, #1f1f1f) 86%, transparent); -webkit-backdrop-filter: blur(10px) saturate(1.2); backdrop-filter: blur(10px) saturate(1.2); box-shadow: 0 4px 14px rgba(0,0,0,.22); color: var(--dsw-alias-label-primary, inherit); font: inherit; font-size: 11px; line-height: 24px; cursor: grab; user-select: none; white-space: nowrap; position: relative; touch-action: none; -webkit-tap-highlight-color: transparent; -webkit-touch-callout: none; }
.dqw-capsule::before { content: ''; position: absolute; inset: -9px; }
.dqw-capsule:hover { border-color: var(--dsw-alias-border-primary, var(--dsw-alias-border-secondary, rgba(128,128,128,.35))); box-shadow: 0 6px 18px rgba(0,0,0,.28); }
.dqw-capsule:active { transform: scale(.98); }
.dqw-capsule:focus-visible { outline: 2px solid var(--dsw-alias-brand-primary, #5b8def); outline-offset: 2px; }
.dqw-capsule-sep { opacity: .5; }
.dqw-capsule-glm, .dqw-capsule-copilot { font-variant-numeric: tabular-nums; font-weight: 600; }
.dqw-capsule-glm.warn, .dqw-capsule-copilot.warn { color: var(--dsw-alias-label-warning, #d29922); }
.dqw-capsule-glm.danger, .dqw-capsule-copilot.danger { color: var(--dsw-alias-label-danger, #c93c3c); }
.dqw-capsule[hidden] { display: none; }
.dqw-capsule [hidden] { display: none; }
.dqw-capsule--dragging { cursor: grabbing; -webkit-backdrop-filter: none; backdrop-filter: none; background: var(--dsw-alias-bg-elevated, var(--dsw-alias-bg-base, #1f1f1f)); box-shadow: 0 8px 24px rgba(0,0,0,.35); transform: scale(1.04); transition: none; }
@media (prefers-reduced-motion: no-preference) {
  .dqw-capsule[data-alert] { animation: dqw-pulse 1.6s ease-in-out infinite; }
  .dqw-capsule { transition: border-color .12s ease-out, box-shadow .12s ease-out; }
}
@media print { :host { display: none !important; } }
@keyframes dqw-pulse { 0%, 100% { transform: scale(1); } 50% { transform: scale(1.06); } }
.dqw-panel-actions { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; }
.dqw-panel-action { min-width: 0; margin: 0; padding: 6px 8px; border: 1px solid var(--dsw-alias-border-secondary, rgba(128,128,128,.35)); border-radius: 8px; background: transparent; color: var(--dsw-alias-label-secondary, inherit); font: inherit; font-size: 10px; line-height: 14px; opacity: .72; text-align: center; cursor: pointer; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.dqw-panel-action:hover { background: var(--dsw-alias-interactive-bg-hover, rgba(128,128,128,.12)); color: var(--dsw-alias-label-primary, inherit); opacity: 1; }
.dqw-panel { position: fixed; z-index: 2147483000; min-width: 166px; max-width: min(320px, calc(100vw - 24px)); max-height: calc(100vh - 24px); overflow-y: auto; padding: 10px 12px; border: 1px solid var(--dsw-alias-border-secondary, rgba(128,128,128,.35)); border-radius: 10px; background: var(--dsw-alias-bg-elevated, var(--dsw-alias-bg-base, #1f1f1f)); background: color-mix(in srgb, var(--dsw-alias-bg-base, #1f1f1f) 86%, transparent); -webkit-backdrop-filter: blur(14px) saturate(1.3); backdrop-filter: blur(14px) saturate(1.3); box-shadow: 0 8px 24px rgba(0,0,0,.25); color: var(--dsw-alias-label-primary, inherit); display: flex; flex-direction: column; gap: 8px; font: inherit; }
@supports not ((backdrop-filter: blur(1px)) or (-webkit-backdrop-filter: blur(1px))) { .dqw-panel { background: var(--dsw-alias-bg-elevated, var(--dsw-alias-bg-base, #1f1f1f)); } }
.dqw-panel--sheet { left:8px; right:8px; top:auto; bottom:calc(8px + env(safe-area-inset-bottom, 0px)); width:auto; max-width:none; max-height:calc(100dvh - 24px); }
/* Overview-only pin: the capsule pop matches the sidebar card (240px); detail
   views (GLM/Copilot) keep the 0.0.18 content-driven width above. :not() keeps
   the bottom sheet (≤480px) winning over the pin. Keyed off the data attr that
   syncPop already maintains — no JS state change. */
.dqw-panel[data-dsh-quota-watch-panel-overview]:not(.dqw-panel--sheet) { width: min(240px, calc(100vw - 24px)); }
.dqw-panel[hidden] { display: none; }
.dqw-panel *, .dqw-panel *::before, .dqw-panel *::after { box-sizing: border-box; }
.dqw-panel-header { display: flex; align-items: center; gap: 6px; min-width: 0; }
.dqw-panel-title { margin: 0; font-size: 11px; font-weight: 600; line-height: 16px; flex: 1; min-width: 0; }
.dqw-panel-back { display: inline-flex; flex: none; align-items: center; justify-content: center; width: 28px; height: 28px; margin: 0; padding: 0; border: 0; border-radius: 6px; background: transparent; color: var(--dsw-alias-label-secondary, inherit); cursor: pointer; }
.dqw-panel-back svg { display: block; width: 16px; height: 16px; }
.dqw-panel-back:hover { background: var(--dsw-alias-interactive-bg-hover, rgba(128,128,128,.12)); color: var(--dsw-alias-label-primary, inherit); }
.dqw-panel-refresh { flex: none; margin: 0; padding: 4px 6px; border: 0; border-radius: 6px; background: transparent; color: var(--dsw-alias-label-secondary, inherit); cursor: pointer; font: inherit; font-size: 10px; line-height: 14px; opacity: .72; }
.dqw-panel-refresh:hover { background: var(--dsw-alias-interactive-bg-hover, rgba(128,128,128,.12)); color: var(--dsw-alias-label-primary, inherit); opacity: 1; }
.dqw-panel-close { display: inline-flex; flex: none; align-items: center; justify-content: center; width: 24px; height: 24px; margin: 0; padding: 0; border: 0; border-radius: 6px; background: transparent; color: var(--dsw-alias-label-secondary, inherit); cursor: pointer; font: inherit; font-size: 12px; line-height: 1; }
.dqw-panel-close:hover { background: var(--dsw-alias-interactive-bg-hover, rgba(128,128,128,.12)); color: var(--dsw-alias-label-primary, inherit); }
.dqw-overview-list { display: flex; flex-direction: column; gap: 2px; }
.dqw-bar { background: var(--dsw-alias-bg-tertiary, rgba(128,128,128,.38)); }
.dqw-row-summary { display: flex; align-items: center; gap: 6px; padding: 3px 6px; margin: 0 -2px; border-radius: 8px; }
.dqw-row-summary[data-expandable] { cursor: pointer; }
.dqw-row-summary[data-expandable]:hover { background: var(--dsw-alias-bg-hover, rgba(128,128,128,.12)); }
.dqw-row-summary:focus-visible { outline: 1px solid var(--dsw-alias-button-primary-fill, #5b8def); outline-offset: -1px; }
.dqw-row-summary.is-error { cursor: default; }
.dqw-label { font-size: 11px; font-weight: 600; width: 52px; flex: none; }
.dqw-label[data-action="refresh"] { cursor: pointer; border-radius: 4px; }
.dqw-label[data-action="refresh"]:hover { opacity: .75; }
.dqw-bar { display: block; flex: 1 1 auto; width: auto; min-width: 36px; height: 4px; overflow: hidden; border-radius: 4px; background: var(--dsw-alias-bg-tertiary, rgba(128,128,128,.2)); }
.dqw-bar-fill { display: block; height: 100%; border-radius: inherit; background: var(--dsw-alias-button-primary-fill, #5b8def); }
.dqw-bar-fill.warn { background: var(--dsw-alias-label-warning, #d29922); }
.dqw-bar-fill.danger { background: var(--dsw-alias-label-danger, #c93c3c); }
.dqw-pct { font-size: 10.5px; line-height: 14px; font-variant-numeric: tabular-nums; width: 30px; text-align: right; flex: none; }
.dqw-extra { font-size: 10px; line-height: 14px; opacity: .72; font-variant-numeric: tabular-nums; flex: none; min-width: 34px; text-align: right; }
.dqw-chev { font-size: 9px; line-height: 14px; opacity: .6; flex: none; width: 10px; text-align: center; }
.dqw-stale-mark { flex: none; font-size: 9px; line-height: 14px; color: var(--dsw-alias-label-warning, #b46900); cursor: help; }
.dqw-errtext { font-size: 10px; line-height: 14px; opacity: .7; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.dqw-bignums { display: flex; gap: 6px; }
.dqw-big { flex: 1; border: 1px solid var(--dsw-alias-border-secondary, rgba(128,128,128,.25)); border-radius: 8px; padding: 5px 8px; }
.dqw-big .dqw-big-value { font-size: 15px; font-weight: 650; line-height: 19px; font-variant-numeric: tabular-nums; }
.dqw-big .dqw-big-label { font-size: 9.5px; line-height: 13px; opacity: .65; }
.dqw-muted { margin: 0; font-size: 10px; line-height: 14px; opacity: .7; }
.dqw-models { border-top: 1px dashed var(--dsw-alias-border-secondary, rgba(128,128,128,.25)); padding-top: 6px; display: flex; flex-direction: column; gap: 3px; }
.dqw-model-row { display: flex; justify-content: space-between; align-items: baseline; gap: 10px; font-size: 10.5px; line-height: 15px; font-variant-numeric: tabular-nums; }
.dqw-model-name { min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; opacity: .85; }
.dqw-model-value { flex: none; font-weight: 600; }
.dqw-kv { display: flex; justify-content: space-between; align-items: baseline; gap: 10px; font-size: 10.5px; line-height: 17px; font-variant-numeric: tabular-nums; }
.dqw-kv-label { flex: none; opacity: .65; }
.dqw-kv-value { min-width: 0; text-align: right; font-weight: 600; }
.dqw-kv-sub { min-width: 0; overflow-wrap: anywhere; font-weight: 400; opacity: .55; }
.dqw-wins { display: grid; grid-template-columns: max-content max-content max-content max-content 1fr; column-gap: 6px; row-gap: 3px; align-items: baseline; font-size: 10.5px; line-height: 17px; font-variant-numeric: tabular-nums; }
.dqw-win-name { opacity: .65; }
.dqw-win-mid { opacity: .65; white-space: nowrap; }
.dqw-win-used { opacity: .65; white-space: nowrap; }
.dqw-win-val { min-width: 0; font-weight: 600; }
/* Reset cards: keep the dashed divider even when an empty wallet collapses to
   one row. The panel's 立即刷新 is the only manual re-check control. */
.dqw-reset { border-top: 1px dashed var(--dsw-alias-border-secondary, rgba(128,128,128,.25)); padding-top: 6px; display: flex; flex-direction: column; gap: 4px; }
.dqw-reset-head, .dqw-reset-collapsed { display: flex; justify-content: space-between; align-items: baseline; gap: 8px; font-size: 10px; line-height: 14px; }
.dqw-reset-title { opacity: .65; }
.dqw-reset-lines { display: grid; grid-template-columns: max-content max-content minmax(0, 1fr) max-content max-content; column-gap: 6px; row-gap: 4px; align-items: center; font-size: 10.5px; line-height: 17px; font-variant-numeric: tabular-nums; }
.dqw-reset-row { display: contents; }
.dqw-reset-kind { white-space: nowrap; opacity: .65; }
.dqw-reset-mid { white-space: nowrap; text-align: center; opacity: .65; }
.dqw-reset-expiry { min-width: 0; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; opacity: .65; }
.dqw-reset-count { justify-self: end; white-space: nowrap; font-weight: 600; }
.dqw-reset-placeholder { min-width: 0; }

.dqw-reset-count.is-empty { font-weight: 400; opacity: .5; }
.dqw-reset-use { flex: none; border: 1px solid var(--dsw-alias-border-secondary, rgba(128,128,128,.4)); border-radius: 5px; background: var(--dsw-alias-bg-elevated, rgba(128,128,128,.1)); color: inherit; font: inherit; font-weight: 400; font-size: 10px; line-height: 14px; padding: 1px 7px; cursor: pointer; }
.dqw-reset-use:hover:not(:disabled) { background: var(--dsw-alias-bg-hover, rgba(128,128,128,.2)); }
.dqw-reset-use:disabled { cursor: default; opacity: .4; }
.dqw-reset-confirm { border: 1px solid var(--dsw-alias-label-warning, #d29922); border-radius: 6px; padding: 6px 8px; display: flex; flex-direction: column; gap: 5px; font-size: 10.5px; line-height: 15px; }
.dqw-reset-confirm-title { font-weight: 600; }
.dqw-reset-confirm-body { opacity: .8; }
.dqw-reset-confirm-warn { opacity: .65; }
.dqw-reset-confirm-actions { display: flex; gap: 6px; justify-content: flex-end; }
.dqw-reset-btn { border: 1px solid var(--dsw-alias-border-secondary, rgba(128,128,128,.4)); border-radius: 5px; background: var(--dsw-alias-bg-elevated, rgba(128,128,128,.1)); color: inherit; font: inherit; font-weight: 400; font-size: 10px; line-height: 14px; padding: 2px 9px; cursor: pointer; }
.dqw-reset-btn:hover:not(:disabled) { background: var(--dsw-alias-bg-hover, rgba(128,128,128,.2)); }
.dqw-reset-btn:disabled { cursor: default; opacity: .5; }
.dqw-reset-btn.is-primary { border-color: var(--dsw-alias-label-warning, #d29922); }
.dqw-reset-notice { font-size: 10px; line-height: 14px; }
.dqw-reset-notice.is-ok { color: var(--dsw-alias-label-success, #3fb950); }
.dqw-reset-notice.is-error { color: var(--dsw-alias-label-danger, #c93c3c); }
.dqw-error { margin: 0; font-size: 10px; line-height: 14px; color: var(--dsw-alias-label-warning, #b46900); }
/* A pending manual outcome turns the capsule into the always-visible warning entry. */
.dqw-capsule[data-outcome='true'] { box-shadow: 0 0 0 2px var(--dsw-alias-label-warning, #d29922); }
/* Narrow widths (~280px containers and the ≤480px bottom sheet): card rows
   wrap so kind, expiry and button never truncate horizontally; the expiry may
   grow onto its own line. The five-column alignment grid above stays for wide
   floating panels. */
@media (max-width: 480px) {
  .dqw-reset-lines { display: flex; flex-direction: column; gap: 4px; }
  .dqw-reset-row { display: flex; flex-wrap: wrap; align-items: baseline; column-gap: 6px; row-gap: 2px; }
  .dqw-reset-expiry { flex: 1 1 100%; white-space: normal; overflow: visible; text-overflow: clip; }
  .dqw-reset-use { margin-left: auto; }
}
`

/** Locale resolution follows the host, not just the browser: the DSH locale
 * feature mirrors its resolved preference (设置 → 语言) onto
 * `<html lang>` and keeps it updated on every switch, so prefer that signal
 * and fall back to navigator.language when the host has not synced yet. */
function localeFor(win) {
  const host = String(win?.document?.documentElement?.lang ?? '').trim()
  if (host !== '') return host.toLowerCase().startsWith('zh') ? 'zh' : 'en'
  return String(win?.navigator?.language ?? 'zh').toLowerCase().startsWith('zh') ? 'zh' : 'en'
}

function formatNumber(value, locale) {
  if (typeof value !== 'number' || !Number.isFinite(value)) return ''
  return new Intl.NumberFormat(locale === 'zh' ? 'zh-CN' : 'en-US', { maximumFractionDigits: 1 }).format(value)
}

function formatCompact(value, locale) {
  if (typeof value !== 'number' || !Number.isFinite(value)) return ''
  return new Intl.NumberFormat(locale === 'zh' ? 'zh-CN' : 'en-US', {
    notation: 'compact',
    maximumFractionDigits: 1,
  }).format(value)
}

function formatPercent(value, locale) {
  if (typeof value !== 'number' || !Number.isFinite(value)) return ''
  const clamped = Math.max(0, Math.min(100, value))
  const rounded = clamped >= 10 ? Math.round(clamped) : Number(clamped.toFixed(1))
  return `${formatNumber(rounded, locale)}%`
}

function formatTime(value, locale) {
  if (typeof value !== 'string' || value === '') return ''
  const date = new Date(value)
  if (Number.isNaN(date.getTime())) return ''
  const dateLocale = locale === 'zh' ? 'zh-CN' : 'en-US'
  const dateParts = new Intl.DateTimeFormat(dateLocale, {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).formatToParts(date)
  const part = (type) => dateParts.find((item) => item.type === type)?.value ?? ''
  const dateText = `${part('year')}/${part('month')}/${part('day')}`
  const timeText = new Intl.DateTimeFormat(dateLocale, { timeStyle: 'short' }).format(date)
  return `${dateText} ${timeText}`
}

function text(doc, tag, className, value) {
  const node = doc.createElement(tag)
  if (className) node.className = className
  node.textContent = String(value ?? '')
  return node
}

function quotaIcon(doc) {
  const namespace = 'http://www.w3.org/2000/svg'
  const svg = doc.createElementNS(namespace, 'svg')
  svg.setAttribute('viewBox', '0 0 24 24')
  svg.setAttribute('width', '16')
  svg.setAttribute('height', '16')
  svg.setAttribute('fill', 'none')
  svg.setAttribute('stroke', 'currentColor')
  svg.setAttribute('stroke-width', '2')
  svg.setAttribute('stroke-linecap', 'round')
  svg.setAttribute('stroke-linejoin', 'round')
  svg.setAttribute('aria-hidden', 'true')
  svg.setAttribute('focusable', 'false')
  const dial = doc.createElementNS(namespace, 'circle')
  dial.setAttribute('cx', '12')
  dial.setAttribute('cy', '12')
  dial.setAttribute('r', '10')
  const ticks = doc.createElementNS(namespace, 'path')
  ticks.setAttribute('d', 'M12 2.4v1.6M12 20v1.6M2.4 12h1.6M20 12h1.6M5.2 5.2l1.1 1.1M18.8 18.8l-1.1-1.1M18.8 5.2l-1.1 1.1M5.2 18.8l1.1-1.1')
  const needle = doc.createElementNS(namespace, 'path')
  needle.setAttribute('d', 'M12 12l4.5-4')
  const hub = doc.createElementNS(namespace, 'circle')
  hub.setAttribute('cx', '12')
  hub.setAttribute('cy', '12')
  hub.setAttribute('r', '1.4')
  hub.setAttribute('fill', 'currentColor')
  hub.setAttribute('stroke', 'none')
  svg.append(dial, ticks, needle, hub)
  return svg
}

/** Double-chevron icon for the panel's back affordance. */
function backIcon(doc) {
  const namespace = 'http://www.w3.org/2000/svg'
  const svg = doc.createElementNS(namespace, 'svg')
  svg.setAttribute('viewBox', '0 0 16 16')
  svg.setAttribute('width', '16')
  svg.setAttribute('height', '16')
  svg.setAttribute('fill', 'none')
  svg.setAttribute('stroke', 'currentColor')
  svg.setAttribute('stroke-width', '1.7')
  svg.setAttribute('stroke-linecap', 'round')
  svg.setAttribute('stroke-linejoin', 'round')
  svg.setAttribute('aria-hidden', 'true')
  svg.setAttribute('focusable', 'false')
  const chevrons = doc.createElementNS(namespace, 'path')
  chevrons.setAttribute('d', 'M11 4 7 8l4 4M7 4 3 8l4 4')
  svg.append(chevrons)
  return svg
}

/** Aligned label/value line used by the simplified Copilot detail. */
function kvRow(doc, label, value) {
  const row = doc.createElement('div')
  row.className = 'dqw-kv'
  row.append(text(doc, 'span', 'dqw-kv-label', label), text(doc, 'span', 'dqw-kv-value', value))
  return row
}

/**
 * One degradation decision for today's usage numbers, shared by the summary
 * row and the detail: ready shows real values, a short stale episode keeps the
 * last-good values, and a first error or a host-stamped `staleTooLong` hides
 * both big numbers and the per-model breakdown. The five-minute judgement
 * itself lives in the host (`usage.staleTooLong`) — the client never reads a
 * local clock for this.
 */
function displayableGlmUsage(usage) {
  if (usage?.status === 'ready') return usage
  if (usage?.status === 'stale' && usage?.staleTooLong !== true) return usage
  return undefined
}

/** GLM summary row view model: fixed 5h-window percent plus today's compact tokens. */
function glmRowModel(provider) {
  if (provider?.status === 'missing') return null
  if (provider?.status === 'error') return { kind: 'error', label: 'GLM', error: provider.error, errorKind: provider.errorKind }
  const windows = provider?.plan?.windows
  if (!Array.isArray(windows) || windows.length === 0) return null
  const five = windows.find((window) => window?.key === '5h')
  const tokens = displayableGlmUsage(provider?.usage)?.totalTokens
  return {
    kind: 'data',
    label: 'GLM',
    percent: five?.percent,
    stale: provider.status === 'stale',
    error: provider.error,
    errorKind: provider.errorKind,
    extra: tokens,
  }
}

/** Copilot summary row view model: used% inverted from the reported remaining percent. */
function copilotRowModel(provider) {
  if (provider?.status === 'missing') return null
  if (provider?.status === 'error') return { kind: 'error', label: 'Copilot', error: provider.error, errorKind: provider.errorKind }
  const quota = provider?.quota
  if (quota?.balanceAvailable !== true) return null
  const used = remainingToUsed(quota.percentRemaining)
  if (used === undefined) return null
  return {
    kind: 'data',
    label: 'Copilot',
    percent: used,
    stale: provider.status === 'stale',
    error: provider.error,
    errorKind: provider.errorKind,
    extra: typeof quota.creditsUsed === 'number' && quota.creditsUsed >= 0 ? quota.creditsUsed : undefined,
  }
}

function footArea(doc) {
  const sidebar = doc.querySelector('[class*="sidebarCol"]')
  return sidebar?.querySelector('[class*="footArea"]') ?? undefined
}

async function fetchJson(fetchImpl, path, method) {
  const response = await fetchImpl(path, {
    ...(method === 'POST' ? { method: 'POST' } : {}),
    cache: 'no-store',
    signal: AbortSignal.timeout(FETCH_TIMEOUT_MS),
  })
  if (!response.ok) throw new Error(`HTTP ${response.status}`)
  return response.json()
}

/** Mount a self-healing sidebar card. Dependencies are injectable for DOM tests. */
export function mountQuotaCard({
  doc = globalThis.document,
  win = globalThis.window,
  fetchImpl = globalThis.fetch,
  pollIntervalMs = CLIENT_POLL_INTERVAL_MS,
  retryNoDataMs = 2_000,
  retryBackoff = 2,
  // Q16: a confirmed SUCCESS notice lingers about five seconds before the
  // panel returns to the latest inventory. Injectable for tests.
  outcomeNoticeMs = 5_000,
  // Shell-takeover sentinel (2026-10-13 ds-bot): inject `ctx.slots` to arm it.
  // Injectable so DOM tests and exotic hosts keep the legacy behavior.
  slots = null,
  // Host React for the slot-first sidebar seat; default resolves through the
  // module-loader factory and stays null under node --test / DOM tests.
  react = loadReact(),
} = {}) {
  if (!doc?.body || typeof fetchImpl !== 'function') return () => {}
  if (doc.querySelector(CARD_SELECTOR) || doc.querySelector(FLOAT_SELECTOR)) return () => {}

  // Mutable so a host language switch (设置 → 语言 → <html lang>) re-renders
  // every surface with the new dictionary on the next pass — renderAll is the
  // one funnel all render paths share.
  let locale = localeFor(win)
  let copy = COPY[locale]
  const container = doc.createElement('div')
  container.dataset.dshQuotaWatchCard = ''
  container.dataset.dshPlugin = 'quota-watch'
  container.dataset.dshPart = 'sidebar-card'
  if (typeof container.attachShadow !== 'function') return () => {}
  // ADR 0001: the card and its stylesheet live inside an open shadow root, so
  // external actors cannot strip page-level style tags out from under it.
  const cardRoot = container.attachShadow({ mode: 'open' })
  let style = text(doc, 'style', '', STYLE_TEXT)
  const card = doc.createElement('section')
  card.className = 'dqw-card'
  card.setAttribute('aria-label', copy.title)
  const body = doc.createElement('div')
  body.className = 'dqw-body'
  // Status line doubles as the transport-error surface; hidden once data renders.
  const lastUpdated = text(doc, 'p', 'dqw-meta', copy.loading)
  lastUpdated.dataset.role = 'updated'
  body.append(lastUpdated)
  card.append(body)
  cardRoot.append(style, card)
  // Details open in a viewport-level floating panel — the only detail surface.
  const panel = doc.createElement('div')
  panel.className = 'dqw-panel'
  panel.setAttribute('role', 'dialog')
  panel.dataset.dshQuotaWatchPanel = ''
  panel.hidden = true
  doc.body.append(panel)
  // Float shell host at the document root; survives sidebar absence entirely.
  const floatHost = doc.createElement('div')
  floatHost.dataset.dshQuotaWatchFloat = ''
  const floatRoot = floatHost.attachShadow({ mode: 'open' })
  floatRoot.append(text(doc, 'style', '', FLOAT_STYLE_TEXT))
  const buildCapsule = () => {
    const el = doc.createElement('div')
    el.className = 'dqw-capsule'
    el.dataset.dshQuotaWatchCapsule = ''
    el.setAttribute('role', 'button')
    el.tabIndex = 0
    el.setAttribute('aria-haspopup', 'dialog')
    el.setAttribute('aria-expanded', 'false')
    el.append(
      text(doc, 'span', 'dqw-capsule-glm', ''),
      text(doc, 'span', 'dqw-capsule-sep', '·'),
      text(doc, 'span', 'dqw-capsule-copilot', ''),
    )
    return el
  }
  // Capsule is the only floating surface (0.1.1: the round ball was retired).
  let surface = buildCapsule()
  floatRoot.append(surface)
  /** The capsule is always present unless no provider reports anything. */
  const syncFloatVisibility = () => {
    surface.hidden = dataHidden
    floatHost.hidden = dataHidden
  }
  // Mount under <body>, NOT <html>: the DSH theme tokens (--dsw-alias-*) are
  // defined on <body>, and a sibling of <body> never inherits them — mounting
  // on documentElement silently stranded the float shell on hardcoded dark
  // fallbacks (broke the light theme). <body> is also transform-free, so
  // position:fixed stays viewport-anchored.
  doc.body.append(floatHost)
  /** Measured capsule size; zeros (jsdom / unpainted) fall back to the box. */
  const measureSurface = () => {
    const rect = surface.getBoundingClientRect()
    return rect.width > 0 ? { width: rect.width, height: rect.height } : FALLBACK_SIZE
  }
  /** Position = user preferred {x, y} clamped to viewport, safe-area insets
   * and the Windows shell titlebar band. */
  const applyPosition = () => {
    const viewWidth = win.innerWidth ?? 1024
    const viewHeight = win.innerHeight ?? 768
    const viewport = { width: viewWidth, height: viewHeight }
    const size = measureSurface()
    const insets = readInsets()
    const pos = loadFloatPosition(win.localStorage) ?? {
      x: viewWidth - MARGIN - insets.right - size.width,
      y: viewHeight - MARGIN - insets.bottom - size.height,
    }
    // Clamped visually so a restored or shrunk window never lets the capsule fall outside.
    const point = clampPoint(pos, viewport, size, insets)
    floatHost.style.left = `${Math.round(point.x)}px`
    floatHost.style.top = `${Math.round(point.y)}px`
  }
  // Safe-area probe: env() insets ride computed padding; jsdom reports '' which
  // parseInset normalizes to 0, so tests without a stub see zero insets.
  const safeAreaProbe = text(doc, 'div', '', '')
  safeAreaProbe.style.cssText = 'position:fixed;visibility:hidden;pointer-events:none;width:0;height:0;overflow:hidden;padding:env(safe-area-inset-top) env(safe-area-inset-right) env(safe-area-inset-bottom) env(safe-area-inset-left);'
  floatRoot.append(safeAreaProbe)
  // Windows Desktop titlebar band (0.1.20): with `titleBarStyle:hidden +
  // titleBarOverlay` the top strip of the window is the shell's full-width
  // `-webkit-app-region:drag` band — it wins pointer input by layout, ignoring
  // z-index, so a capsule dropped there is stuck for good (un-grabbable,
  // un-clickable, and the persisted position kept re-parking it). Folding the
  // band into the top inset routes it through every clamp path at once: live
  // drag frames, release docking, persisted-position restore and the default
  // dock — and mount-time clamping also self-heals positions saved by 0.1.19.
  // Same contract the shell's own floats consume: `data-windows-titlebar` +
  // `--dsh-windows-titlebar-height` on <html>, dropped under `data-fullscreen`.
  // DSH Web / browsers have neither attribute nor variable → 0, zero drift.
  const readTitlebarInset = () => {
    try {
      const html = doc.documentElement
      return titlebarTopInset({
        titlebar: html.hasAttribute('data-windows-titlebar'),
        fullscreen: html.hasAttribute('data-fullscreen'),
        height: parseInset(win.getComputedStyle(html)?.getPropertyValue('--dsh-windows-titlebar-height')),
      })
    } catch {
      return 0
    }
  }
  /** Live env(safe-area-inset-*) reading — re-probed on every use, so window
   * chrome changes (rotation, URL-bar collapse) need no explicit invalidation.
   * `top` is the larger of the safe-area inset and the shell titlebar band. */
  const readInsets = () => {
    try {
      const style = win.getComputedStyle(safeAreaProbe)
      return {
        top: Math.max(parseInset(style?.paddingTop), readTitlebarInset()),
        right: parseInset(style?.paddingRight),
        bottom: parseInset(style?.paddingBottom),
        left: parseInset(style?.paddingLeft),
      }
    } catch {
      return ZERO_INSETS
    }
  }
  applyPosition()
  // Panel lives inside the float shadow root from now on (契约总表「归属时序」).
  floatRoot.append(panel)

  let suppressNextClick = false
  /** One rAF (or a synchronous fallback when the host has none) — drag frames
   * and scroll re-placement share this gate so a burst of events costs one
   * layout read/write per frame. */
  const scheduleFrame = (fn) => (
    typeof win.requestAnimationFrame === 'function' ? win.requestAnimationFrame.call(win, fn) : fn()
  )
  /** Grab-offset + transform drag (ADR 0002): the pill keeps its grab point
   * under the cursor, moves via transform during the gesture (rAF-batched,
   * live-clamped to the measured size), and the dock is persisted on release —
   * optionally through a short snap transition when motion is allowed.
   * Move/up listen on `document` — pointer events always bubble there, in
   * browsers and jsdom alike. Returns a dispose function. */
  const attachDrag = (surfaceEl) => {
    let dragging = false
    let moved = false
    let originX = 0
    let originY = 0
    let slop = DRAG_SLOP_MOUSE
    let grab = { dx: 0, dy: 0 }
    let dragSize = FALLBACK_SIZE
    let restX = 0
    let restY = 0
    let lastPoint = null
    /** Doc-level move/up/cancel are bound only while a gesture is active —
     * the pill's resting state costs zero document-level listeners. */
    const bindGesture = () => {
      doc.addEventListener('pointermove', onPointerMove)
      doc.addEventListener('pointerup', onPointerUp)
      doc.addEventListener('pointercancel', onPointerCancel)
    }
    const unbindGesture = () => {
      doc.removeEventListener('pointermove', onPointerMove)
      doc.removeEventListener('pointerup', onPointerUp)
      doc.removeEventListener('pointercancel', onPointerCancel)
    }
    const onPointerDown = (event) => {
      if (event.button !== 0) return
      dragging = true
      moved = false
      originX = event.clientX
      originY = event.clientY
      // Graded slop: touch/pen get 10px so taps win over drags (Task 6).
      slop = dragSlop(event.pointerType)
      const rect = surfaceEl.getBoundingClientRect()
      grab = grabOffset({ x: event.clientX, y: event.clientY }, rect)
      dragSize = rect.width > 0 ? { width: rect.width, height: rect.height } : FALLBACK_SIZE
      restX = Number.parseFloat(floatHost.style.left) || 0
      restY = Number.parseFloat(floatHost.style.top) || 0
      surfaceEl.setPointerCapture?.(event.pointerId)
      bindGesture()
    }
    const onPointerMove = (event) => {
      if (!dragging) return
      if (!moved) {
        if (Math.hypot(event.clientX - originX, event.clientY - originY) < slop) return
        moved = true
        doc.body.style.userSelect = 'none'
        surfaceEl.classList.add('dqw-capsule--dragging')
      }
      lastPoint = { x: event.clientX, y: event.clientY }
      scheduleFrame(() => {
        if (!dragging || !lastPoint || disposed) return
        const viewWidth = win.innerWidth ?? 1024
        const viewHeight = win.innerHeight ?? 768
        const insets = readInsets()
        const topLeft = clampFrame(lastPoint, grab, dragSize, { width: viewWidth, height: viewHeight }, insets)
        const dx = topLeft.x - restX
        const dy = topLeft.y - restY
        floatHost.style.willChange = 'transform'
        floatHost.style.transform = `translate3d(${Math.round(dx)}px, ${Math.round(dy)}px, 0)`
      })
    }
    const finishDragRelease = (point) => {
      surfaceEl.classList.remove('dqw-capsule--dragging')
      floatHost.style.willChange = ''
      floatHost.style.transform = ''
      saveFloatPosition(win.localStorage, point)
      applyPosition()
      suppressNextClick = true
    }
    const onPointerUp = (event) => {
      if (!dragging) return
      dragging = false
      unbindGesture()
      doc.body.style.userSelect = ''
      if (!moved) return
      const viewWidth = win.innerWidth ?? 1024
      const viewHeight = win.innerHeight ?? 768
      const insets = readInsets()
      const viewport = { width: viewWidth, height: viewHeight }
      const point = clampFrame(
        { x: event.clientX, y: event.clientY },
        grab,
        dragSize,
        viewport,
        insets,
      )
      suppressNextClick = true
      finishDragRelease(point)
    }
    /** A canceled pointer (scroll takeover, incoming call, palm) resets the
     * gesture: no position is persisted and the trailing click stays allowed. */
    const onPointerCancel = () => {
      if (!dragging) return
      dragging = false
      unbindGesture()
      doc.body.style.userSelect = ''
      surfaceEl.classList.remove('dqw-capsule--dragging')
      floatHost.style.willChange = ''
      floatHost.style.transform = ''
    }
    surfaceEl.addEventListener('pointerdown', onPointerDown)
    const disposeDrag = () => {
      surfaceEl.removeEventListener('pointerdown', onPointerDown)
      unbindGesture()
    }
    return disposeDrag
  }
  let snapshot
  let normalSequence = 0
  let timer
  let noDataRetries = 0
  let disposed = false
  let queuedPlace = false
  let openKey
  let panelNav = false
  // The wallet lives ONLY in the host snapshot (`snapshot.reset`): the detail
  // never issues its own card-list GET, so a stale second source cannot fight
  // the host's ten-minute background list or a force refresh. The whole
  // redemption flow — the five states, the spend/acknowledge chain and the
  // Q16 notice timer — lives behind the reset-cards internal seam (ADR 0007);
  // its only channels back here are onDirty (re-render gate kept host-side)
  // and refresh (one authoritative overview read after each round trip).
  const resetCards = createResetCards({
    doc,
    win,
    fetchImpl,
    copy: () => copy,
    routes: CLIENT_ROUTES,
    refresh: () => poll(),
    onDirty: () => { if (openKey === 'glm') syncPop() },
    outcomeNoticeMs,
  })
  // Force/ordinary refresh watermark. An ordinary GET may only apply when it
  // started while NO force was in flight AND under the current force
  // generation — so a force result can neither be dropped by a later-started
  // GET that returned first, nor rolled back by a GET that started during the
  // force and returned late. Only a GET started after the force completed may
  // update the UI.
  let forceBusy = false
  let forceGeneration = 0
  // The ONE shared 立即刷新 busy state: the detail header button, the overview
  // action and every refresh click all honor this single flag.
  let refreshBusy = false
  let forcedResetForOpen = false   // the one-shot poll(true) guard per detail open
  // Cold until the first successful render: a mount whose first poll fails or
  // stalls must behave like the documented no-data state (hidden shell, fast
  // retries), not like a warm client showing an empty capsule.
  let dataHidden = true
  let surfaceFlags = loadSurfaceFlags(win.localStorage)
  const setCardHidden = (hidden) => {
    surfaceFlags = { cardHidden: hidden }
    saveSurfaceFlags(win.localStorage, surfaceFlags)
    renderAll()
  }

  const fillClass = (percent) => (percent > 95 ? 'dqw-bar-fill danger' : percent > 80 ? 'dqw-bar-fill warn' : 'dqw-bar-fill')

  /** Build the summary row for one provider, or null when it must not render. */
  const renderProvider = (key, model) => {
    if (model === null) return null
    const row = doc.createElement('div')
    row.className = 'dqw-row-summary'
    row.dataset.dshQuotaWatchRow = key
    const label = text(doc, 'span', 'dqw-label', model.label)
    // Clicking the provider name re-probes, standing in for the removed refresh button.
    label.dataset.action = 'refresh'
    label.title = `${model.label} · ${copy.refresh}`
    row.append(label)
    if (model.kind === 'error') {
      row.classList.add('is-error')
      row.append(text(doc, 'span', 'dqw-errtext', model.error ? `${copy.failed}: ${model.error}` : copy.failed))
      return [row]
    }
    row.setAttribute('role', 'button')
    row.tabIndex = 0
    row.setAttribute('aria-expanded', String(openKey === key))
    row.dataset.expandable = ''
    if (typeof model.percent === 'number' && Number.isFinite(model.percent)) {
      const bar = doc.createElement('span')
      bar.className = 'dqw-bar'
      bar.setAttribute('role', 'progressbar')
      bar.setAttribute('aria-valuemin', '0')
      bar.setAttribute('aria-valuemax', '100')
      bar.setAttribute('aria-valuenow', String(Math.max(0, Math.min(100, model.percent))))
      const fill = text(doc, 'span', fillClass(model.percent))
      fill.style.width = `${Math.max(0, Math.min(100, model.percent))}%`
      bar.append(fill)
      row.append(bar)
    }
    if (model.stale) {
      const mark = text(doc, 'span', 'dqw-stale-mark', '⚠')
      mark.dataset.dshQuotaWatchStale = ''
      mark.title = model.errorKind === 'auth' && model.error
        ? `${copy.authRejected}: ${model.error}`
        : (model.error ?? copy.stale)
      row.append(mark)
    }
    row.append(text(doc, 'span', 'dqw-pct', typeof model.percent === 'number' ? formatPercent(model.percent, locale) : '—'))
    if (model.extra !== undefined) {
      const extra = text(doc, 'span', 'dqw-extra', formatCompact(model.extra, locale))
      extra.dataset.dshQuotaWatchExtra = ''
      row.append(extra)
    }
    row.append(text(doc, 'span', 'dqw-chev', openKey === key ? '▾' : '▸'))
    return [row]
  }

  /** Panel chrome: optional back/refresh, title and close affordance. */
  const panelHeader = ({ title, showBack = false, showRefresh = false }) => {
    const header = doc.createElement('div')
    header.className = 'dqw-panel-header'
    if (showBack) {
      const back = doc.createElement('button')
      back.type = 'button'
      back.className = 'dqw-panel-back'
      back.dataset.action = 'back-to-overview'
      back.setAttribute('aria-label', copy.backToOverview)
      back.title = copy.backToOverview
      back.append(backIcon(doc))
      header.append(back)
    }
    header.append(text(doc, 'p', 'dqw-panel-title', title))
    if (showRefresh) {
      const refresh = doc.createElement('button')
      refresh.type = 'button'
      refresh.className = 'dqw-panel-refresh'
      refresh.dataset.action = 'panel-refresh'
      refresh.textContent = refreshBusy ? copy.actions.refreshing : copy.actions.refreshNow
      refresh.setAttribute('aria-label', refresh.textContent)
      refresh.disabled = refreshBusy
      header.append(refresh)
    }
    const close = doc.createElement('button')
    close.type = 'button'
    close.className = 'dqw-panel-close'
    close.dataset.action = 'panel-close'
    close.setAttribute('aria-label', copy.close)
    close.title = copy.close
    close.append(text(doc, 'span', '', '✕'))
    header.append(close)
    return header
  }

  /** Panel footer: the card toggle and a manual refresh sit side by side in an
   * equal-width grid (perceived width is the box, not the glyph count, so the
   * 1fr/1fr columns also survive label flips and other locales). This replaces
   * the retired capsule context menu: one click surface, no hidden gestures,
   * and it renders even in the loading/error empty state. */
  const overviewActions = () => {
    const actions = doc.createElement('div')
    actions.className = 'dqw-panel-actions'
    if (hasCardMount()) {
      const toggle = doc.createElement('button')
      toggle.type = 'button'
      toggle.className = 'dqw-panel-action'
      toggle.dataset.action = 'toggle-card'
      const toggleLabel = surfaceFlags.cardHidden ? copy.actions.showCard : copy.actions.hideCard
      toggle.textContent = toggleLabel
      toggle.setAttribute('aria-label', toggleLabel)
      actions.append(toggle)
    }
    const refresh = doc.createElement('button')
    refresh.type = 'button'
    refresh.className = 'dqw-panel-action'
    refresh.dataset.action = 'panel-refresh'
    refresh.textContent = refreshBusy ? copy.actions.refreshing : copy.actions.refreshNow
    refresh.setAttribute('aria-label', refresh.textContent)
    refresh.disabled = refreshBusy
    actions.append(refresh)
    return actions
  }

  const renderOverview = () => {
    panel.replaceChildren(panelHeader({ title: copy.title }))
    const providers = snapshot?.providers ?? []
    const glm = providers.find((provider) => provider?.key === 'glm')
    const copilot = providers.find((provider) => provider?.key === 'copilot')
    // The overview reuses the card's row-summary renderer verbatim so the
    // panel looks exactly like the 0.0.18 sidebar rows (label · bar · percent
    // · extra · chevron).
    const rows = [
      renderProvider('glm', glmRowModel(glm)),
      renderProvider('copilot', copilotRowModel(copilot)),
    ].filter(Boolean).flat()
    if (rows.length === 0) {
      panel.append(text(doc, 'p', 'dqw-muted', lastUpdated.textContent || copy.loading))
    } else {
      const list = doc.createElement('div')
      list.className = 'dqw-overview-list'
      list.append(...rows)
      // Tag the reused rows for the panel's own click/keyboard routing.
      for (const row of list.querySelectorAll('[data-dsh-quota-watch-row]')) {
        row.dataset.dshQuotaWatchPanelProvider = row.dataset.dshQuotaWatchRow
      }
      panel.append(list)
    }
    // The pending manual outcome is readable on the overview even when every
    // provider row is missing — this is the always-reachable warning surface.
    const outcomeBlock = resetCards.renderOutcomeBlock(snapshot)
    if (outcomeBlock !== null) panel.append(outcomeBlock)
    panel.append(overviewActions())
  }

  function renderDetail(detail, key, provider, fromPanelNav = false) {
    detail.replaceChildren()
    detail.append(panelHeader({ title: copy.providerNames[key], showBack: fromPanelNav, showRefresh: key === 'glm' }))
    if (provider?.status === 'stale') {
      const bannerPrefix = provider.errorKind === 'auth' ? copy.authRejected : copy.stale
      detail.append(text(doc, 'p', 'dqw-error', `${bannerPrefix}${provider.error ? `: ${provider.error}` : ''}`))
    }
    if (key === 'glm') {
      const usage = displayableGlmUsage(provider?.usage)
      const numbers = doc.createElement('div')
      numbers.className = 'dqw-bignums'
      const tokensBig = doc.createElement('div')
      tokensBig.className = 'dqw-big'
      tokensBig.append(
        text(doc, 'div', 'dqw-big-value', usage !== undefined ? formatCompact(usage.totalTokens, locale) : '—'),
        text(doc, 'div', 'dqw-big-label', copy.todayTokens),
      )
      const callsBig = doc.createElement('div')
      callsBig.className = 'dqw-big'
      callsBig.append(
        text(doc, 'div', 'dqw-big-value', usage !== undefined ? formatNumber(usage.totalCalls, locale) : '—'),
        text(doc, 'div', 'dqw-big-label', copy.todayCalls),
      )
      numbers.append(tokensBig, callsBig)
      detail.append(numbers)
      const raw = Array.isArray(provider?.plan?.windows) ? provider.plan.windows : []
      // Fixed display order (MCP, 5h, month, week); the weekly window shows an
      // unlimited placeholder until the provider starts reporting one.
      const order = { mcp: 0, '5h': 1, month: 2, week: 3 }
      const sorted = [...raw].sort((a, b) => (order[a?.key] ?? 99) - (order[b?.key] ?? 99))
      const items = []
      let weekPlaced = false
      for (const window of sorted) {
        if (!weekPlaced && (order[window?.key] ?? 99) > order.week) {
          items.push({ placeholder: true })
          weekPlaced = true
        }
        if (window?.key === 'week') weekPlaced = true
        items.push({ window })
      }
      if (!weekPlaced) items.push({ placeholder: true })
      // One grid keeps the name, ·, used/♾️, percent and weak-note columns aligned
      // across all window rows.
      const wins = doc.createElement('div')
      wins.className = 'dqw-wins'
      for (const item of items) {
        if (item.placeholder) {
          wins.append(
            text(doc, 'span', 'dqw-win-name', copy.weekUnlimited),
            text(doc, 'span', 'dqw-win-mid', '·'),
            text(doc, 'span', 'dqw-win-used', copy.unlimited),
            text(doc, 'span', ''),
            text(doc, 'span', 'dqw-kv-sub', copy.unlimitedNote),
          )
          continue
        }
        const window = item.window
        const percent = typeof window?.percent === 'number' && Number.isFinite(window.percent) ? window.percent : undefined
        const reset = formatTime(window?.resetsAt, locale)
        wins.append(text(doc, 'span', 'dqw-win-name', copy.windows[window?.key] ?? window?.key))
        wins.append(text(doc, 'span', 'dqw-win-mid', '·'))
        wins.append(text(doc, 'span', 'dqw-win-used', copy.windowUsed))
        wins.append(text(doc, 'span', 'dqw-win-val', percent !== undefined ? formatPercent(percent, locale) : '—'))
        wins.append(text(doc, 'span', 'dqw-kv-sub', reset ? `${copy.noteOpen}${copy.reset}: ${reset}${copy.noteClose}` : ''))
      }
      detail.append(wins)
      if (usage === undefined) {
        // The five-minute window rolled over or the first probe failed: the
        // whole per-model breakdown degrades together with the big numbers.
        detail.append(text(doc, 'p', 'dqw-muted', copy.todayModelsUnavailable))
      } else if (Array.isArray(usage.models) && usage.models.length > 0) {
        const models = doc.createElement('div')
        models.className = 'dqw-models'
        for (const model of usage.models) {
          const row = doc.createElement('div')
          row.className = 'dqw-model-row'
          row.append(
            text(doc, 'span', 'dqw-model-name', model?.name ?? '—'),
            text(doc, 'span', 'dqw-model-value', formatCompact(model?.tokens, locale)),
          )
          models.append(row)
        }
        detail.append(models)
      }
      // The reset block only makes sense with a configured DOMESTIC GLM credential:
      // the reset endpoints are verified for the domestic personal plan only, so an
      // international (z.ai) provider would only ever render a permanent failure.
      if (provider?.credential === 'configured' && provider?.providerId === PROVIDER_IDS.glmDomestic) {
        detail.append(resetCards.renderSection(snapshot))
        // The wallet lives only in the host snapshot: until the first reset
        // snapshot lands, show 查询中 and force ONE read-only refresh per open
        // — never a separate card-list GET.
        if (snapshot?.reset === undefined && !forcedResetForOpen) {
          forcedResetForOpen = true
          void poll(true)
        }
      }
      return
    }
    const quota = provider?.quota
    if (quota?.balanceAvailable === true) {
      detail.append(kvRow(doc, copy.available, `${formatNumber(quota.remaining, locale)} / ${formatNumber(quota.entitlement, locale)}`))
      const used = remainingToUsed(quota.percentRemaining)
      if (typeof quota.creditsUsed === 'number' && quota.creditsUsed >= 0) {
        const row = doc.createElement('div')
        row.className = 'dqw-kv'
        const value = doc.createElement('span')
        value.className = 'dqw-kv-value'
        value.append(text(doc, 'span', '', formatNumber(quota.creditsUsed, locale)))
        // The percent duplicates the summary bar, so render it weakened.
        if (used !== undefined) value.append(text(doc, 'span', 'dqw-kv-sub', ` · ${formatPercent(used, locale)}`))
        row.append(text(doc, 'span', 'dqw-kv-label', copy.used), value)
        detail.append(row)
      }
      const reset = formatTime(quota?.resetsAt, locale)
      if (reset) detail.append(kvRow(doc, copy.resetTime, reset))
    } else {
      detail.append(text(doc, 'p', 'dqw-muted', copy.stale))
    }
  }

  /** Anchor the panel beside its opener (a card row today, the float surface later). */
  // Anchor resolver: card rows are re-created on every render pass, so keep a
  // "how to find the anchor" closure instead of a detached element reference
  // (a detached node's getBoundingClientRect is all zeros → panel teleports).
  let lastAnchor = null
  const anchorFromRow = (key) => () => body.querySelector(`[data-dsh-quota-watch-row="${key}"]`)
  const anchorFromEl = (el) => () => el
  const placePanel = () => {
    if (panel.hidden) return
    const anchor = lastAnchor?.()
    if (!anchor || !anchor.isConnected) return
    if ((win.innerWidth ?? 1024) <= 480) {
      // Narrow viewport (phones): dock the panel to the bottom instead of
      // squeezing it beside the capsule — the sheet is CSS-positioned, so the
      // inline anchor coordinates are dropped.
      panel.classList.add('dqw-panel--sheet')
      panel.style.left = ''
      panel.style.top = ''
      return
    }
    panel.classList.remove('dqw-panel--sheet')
    const rect = anchor.getBoundingClientRect()
    const viewWidth = win.innerWidth ?? 1024
    const viewHeight = win.innerHeight ?? 768
    const width = panel.offsetWidth || 240
    const height = panel.offsetHeight || 160
    let left = rect.right + 8
    if (left + width > viewWidth - 8) left = rect.left - width - 8
    if (left + width > viewWidth - 8) left = viewWidth - width - 8
    left = Math.max(8, left)
    // The panel header carries the close button: keep its top edge below the
    // shell titlebar band (and safe-area top) for the same reason as the
    // capsule — layout-level drag hits ignore z-index. Web fallback: 8px, as before.
    const minTop = MARGIN + readInsets().top
    const top = Math.min(Math.max(rect.top, minTop), Math.max(minTop, viewHeight - height - 8))
    panel.style.left = `${Math.round(left)}px`
    panel.style.top = `${Math.round(top)}px`
  }

  const syncPop = () => {
    if (openKey === undefined || disposed) {
      panel.hidden = true
      panel.replaceChildren()
      delete panel.dataset.dshQuotaWatchPanelDetail
      delete panel.dataset.dshQuotaWatchPanelOverview
      lastAnchor = null
      panelNav = false
      surface.setAttribute('aria-expanded', 'false')
      return
    }
    if (openKey === 'overview') {
      renderOverview()
      delete panel.dataset.dshQuotaWatchPanelDetail
      panel.dataset.dshQuotaWatchPanelOverview = ''
      panel.setAttribute('aria-label', copy.title)
      panel.hidden = false
      placePanel()
      surface.setAttribute('aria-expanded', 'true')
      return
    }
    const provider = (snapshot?.providers ?? []).find((item) => item?.key === openKey)
    const row = body.querySelector(`[data-dsh-quota-watch-row="${openKey}"]`)
    if (!provider || (!panelNav && (!row || !row.hasAttribute('data-expandable')))) {
      openKey = undefined
      syncPop()
      return
    }
    renderDetail(panel, openKey, provider, panelNav)
    panel.dataset.dshQuotaWatchPanelDetail = openKey
    delete panel.dataset.dshQuotaWatchPanelOverview
    panel.setAttribute('aria-label', panelNav ? `${copy.providerNames[openKey]} · ${copy.title}` : copy.providerNames[openKey])
    panel.hidden = false
    placePanel()
    surface.setAttribute('aria-expanded', 'true')
  }

  const renderFloatFace = () => {
    const providers = snapshot?.providers ?? []
    const glm = glmRowModel(providers.find((provider) => provider?.key === 'glm'))
    const copilot = copilotRowModel(providers.find((provider) => provider?.key === 'copilot'))
    // A pending manual outcome keeps the capsule alive as the focusable warning
    // entry even when every provider row is gone; it hides again only once the
    // outcome is cleared AND nothing else has data to show.
    const pendingOutcome = snapshot?.manualOutcome !== undefined || snapshot?.manualOutcomeError !== undefined
    dataHidden = glm === null && copilot === null && !pendingOutcome
    if (dataHidden && openKey !== undefined) {
      openKey = undefined
      syncPop()
    }
    syncFloatVisibility()
    if (floatHost.hidden) return
    const paint = (span, model) => {
      const visible = model !== null && typeof model.percent === 'number' && Number.isFinite(model.percent)
      // 0.1.24: an emptied span stayed mounted as a zero-width flex item, so the
      // 6px capsule gap next to it survived and the asymmetric padding pushed
      // single-provider text off center (the two-provider layout was fine).
      // Hide the span outright: display:none flex items make no box, hence no gap.
      span.hidden = !visible
      span.textContent = visible ? `${model.label} ${formatPercent(model.percent, locale)}` : ''
      span.classList.toggle('warn', visible && model.percent > 80 && model.percent <= 95)
      span.classList.toggle('danger', visible && model.percent > 95)
      return visible
    }
    const glmVisible = paint(surface.querySelector('.dqw-capsule-glm'), glm)
    const copilotVisible = paint(surface.querySelector('.dqw-capsule-copilot'), copilot)
    surface.querySelector('.dqw-capsule-sep').hidden = !glmVisible || !copilotVisible
    const alert = [glm, copilot].some((model) => model !== null && typeof model.percent === 'number' && model.percent > 95)
    if (alert) surface.setAttribute('data-alert', 'true')
    else surface.removeAttribute('data-alert')
    if (pendingOutcome) surface.setAttribute('data-outcome', 'true')
    else surface.removeAttribute('data-outcome')
    const summary = [glm, copilot]
      .filter(Boolean)
      .map((model) => `${model.label} ${formatPercent(model.percent, locale)}`)
      .join(' · ')
    let label = summary === '' ? copy.title : locale === 'zh' ? `${copy.title}：${summary}` : `${copy.title}: ${summary}`
    if (pendingOutcome) {
      // The warning wording must match the pending kind: an unreadable record
      // or an unknown outcome is genuinely "unconfirmed", while a known
      // receipt already carries the real result.
      const outcome = snapshot?.manualOutcome
      const suffix = outcome?.status === 'known-success'
        ? copy.resetCards.knownSuccessTitle
        : outcome?.status === 'known-refused'
          ? copy.resetCards.knownRefusedTitle
          : copy.resetCards.outcomeUnknownTitle
      label = `${label} · ${suffix}`
    }
    surface.setAttribute('aria-label', label)
    surface.title = label
    applyPosition()
  }

  const onSurfaceClick = () => {
    if (suppressNextClick) {
      suppressNextClick = false
      return
    }
    // Toggle semantics (same as the 0.0.18 rail): any open panel closes first.
    if (openKey !== undefined && !panel.hidden) {
      openKey = undefined
      syncPop()
      return
    }
    openOverview(surface)
  }
  const onSurfaceKeydown = (event) => {
    if (event.key !== 'Enter' && event.key !== ' ') return
    event.preventDefault()
    onSurfaceClick()
  }
  const hasCardMount = () => (slotMode ? slotParent !== null : Boolean(footArea(doc)))

  // Cross-profile narrow-container detection: a measurably narrow foot would
  // clip the card into unreadable text regardless of HOW the host signals its
  // collapsed state — hide the card and let the capsule carry the entry.
  // clientWidth 0 (no layout yet, jsdom) counts as "unknown", not narrow.
  let currentFoot = null
  let footTooNarrow = false
  let noDataHidden = false
  // Slot-first seat state (2026-10-19): when the official sidebar.footer.action
  // slot carries the card, the CSS-substring discovery below is bypassed
  // entirely; it remains the fallback for hosts without the slot.
  let slotMode = false
  let slotParent = null
  let slotDispose = null
  // Owner share of the sidebar.footer.action contract (dsh-client-ui-sidebar
  // slots.d.ts): SidebarFooterActionOwnerProps { wide: boolean } — "false =
  // 56px rail". This is the OFFICIAL column-state signal, and the only sound
  // one for the slot seat: the collapsed rail shrink-wraps the mount div to
  // the card's own width, so a seat width measurement can never observe
  // narrowness (it reads the card's intrinsic 176px — the 0.1.33→0.1.36
  // collapsed-rail regression). Strict false, not falsy: a host that passes
  // no wide at all must keep the card visible, not hide it.
  let slotWide = true
  let anchorRetryTimer = null
  // The sidebar foot belongs to whoever registers sidebar.workspaces
  // (ui-sidebar doc: "the foot is the sidebar.workspaces registrant's"). The
  // official workspace tree registers at default priority 0 (ui-workspace); a
  // NEGATIVE-priority occupant is a takeover shell (ds-bot takes the seat at
  // -10 for its native bot sidebar) — while one is live the injected card
  // yields the whole foot, same contract as the dsh-skins/dsh-m footer rows.
  // The signal is the OFFICIAL slot ledger, not any ds-bot internal.
  let shellTakeover = false
  const syncShellTakeover = () => {
    try {
      shellTakeover = (slots?.entries?.('sidebar.workspaces') ?? []).some(
        (entry) => (entry.options.priority ?? 0) < 0,
      )
    } catch {
      shellTakeover = false
    }
  }
  const syncFootNarrowness = () => {
    // Slot mode skips the measurement on purpose: the seat is shrink-to-fit
    // (its width IS the card's width), so the reading is tautological — the
    // collapsed rail reports a healthy 176px while the foot is 35px. The
    // contract `wide` prop (slotWide) carries the collapsed signal instead.
    // Legacy physical-anchor seats keep the footArea measurement, where the
    // foot is a real rail-clamped container and the guard is meaningful.
    const seat = slotMode ? currentFoot : (slotParent ?? currentFoot)
    footTooNarrow = seat !== null && seat.clientWidth > 0 && seat.clientWidth < CARD_MIN_WIDTH
  }
  const syncCardVisibility = () => {
    syncFootNarrowness()
    // The sidebar card shows ONLY in an expanded sidebar. Two non-overlapping
    // signals carry that:
    //   • slot seat (0.2.x shells): the contract `wide` owner prop — false
    //     means the 56px collapsed rail (dsh-client-ui-sidebar slots.d.ts).
    //   • legacy anchor seat: the footArea width guard below. Host collapse
    //     ATTRIBUTES proved host-specific (0.2.0-rc.2 web never writes
    //     data-sidebar-collapsed), so only geometry is consulted there.
    const slotRail = slotMode && slotWide === false
    const showCard = !surfaceFlags.cardHidden && !footTooNarrow && !noDataHidden && !shellTakeover && !slotRail
    container.hidden = !showCard
    card.style.display = showCard ? '' : 'none'
  }
  // The slot registrant re-renders on every wide flip (the ref callback does
  // NOT re-fire for prop changes on the same element), so the render-phase
  // capture defers its visibility sync to a microtask — outside the host
  // React render, same escape hatch as the imperative container append.
  const scheduleSlotSync = () => {
    if (disposed) return
    queueMicrotask(() => { if (!disposed) syncCardVisibility() })
  }
  const footResizeObserver = typeof win.ResizeObserver === 'function'
    ? new win.ResizeObserver(() => { syncCardVisibility() })
    : null
  const renderAll = () => {
    locale = localeFor(win)
    copy = COPY[locale]
    const providers = snapshot?.providers ?? []
    const glm = providers.find((provider) => provider?.key === 'glm')
    const copilot = providers.find((provider) => provider?.key === 'copilot')
    const glmParts = renderProvider('glm', glmRowModel(glm))
    const copilotParts = renderProvider('copilot', copilotRowModel(copilot))
    const fragment = doc.createDocumentFragment()
    fragment.append(lastUpdated)
    if (glmParts) fragment.append(...glmParts)
    if (copilotParts) fragment.append(...copilotParts)
    body.replaceChildren(fragment)
    noDataHidden = glmParts === null && copilotParts === null
    syncCardVisibility()
    const updated = formatTime(snapshot?.updatedAt ? new Date(snapshot.updatedAt).toISOString() : '', locale)
    if (updated) {
      lastUpdated.hidden = true
    } else {
      lastUpdated.hidden = false
      lastUpdated.textContent = copy.loading
    }
    syncPop()
    renderFloatFace()
  }

  const render = (next) => {
    snapshot = next
    renderAll()
  }

  const showTransportError = () => {
    lastUpdated.hidden = false
    lastUpdated.textContent = snapshot ? copy.requestFailed : copy.failed
  }

  const poll = async (force) => {
    if (disposed) return
    if (force === true) {
      // One refresh at a time; its response always wins over any ordinary GET.
      if (refreshBusy) return
      refreshBusy = true
      forceBusy = true
      const generation = ++forceGeneration
      // Flip the shared busy state before the request: header button, overview
      // action and label clicks all re-render against it.
      renderAll()
      if (openKey !== undefined) syncPop()
      try {
        const next = await fetchJson(fetchImpl, CLIENT_ROUTES.refresh, 'POST')
        if (generation === forceGeneration && !disposed) render(next)
      } catch {
        if (!disposed) showTransportError()
      } finally {
        forceBusy = false
        refreshBusy = false
        if (!disposed) {
          renderAll()
          if (openKey !== undefined) syncPop()
        }
      }
      return
    }
    const sequence = ++normalSequence
    // Watermark captured at start: a GET that started during a force is never
    // applied, and neither is one started under an older force generation.
    const startedDuringForce = forceBusy
    const genAtStart = forceGeneration
    try {
      const next = await fetchJson(fetchImpl, CLIENT_ROUTES.overview, 'GET')
      const applicable = !startedDuringForce && genAtStart === forceGeneration
      if (sequence === normalSequence && applicable && !disposed) render(next)
    } catch {
      if (sequence === normalSequence && !disposed) showTransportError()
    } finally {
      // Self-scheduling chain (replaces the fixed interval): every completed
      // poll — success OR transport error — arms the next one, so the no-data
      // backoff also covers a cold start whose first request fails outright.
      // The force path never arms a second chain: only the latest ordinary
      // GET may re-arm the timer.
      if (timer === undefined && sequence === normalSequence && !disposed && doc.visibilityState !== 'hidden') {
        timer = win.setTimeout(() => {
          timer = undefined
          if (!disposed && doc.visibilityState !== 'hidden') void poll()
        }, nextPollDelay())
      }
    }
  }

  const place = () => {
    if (slotMode) return
    const foot = footArea(doc)
    if (!foot) return
    // Claim the first slot of the sidebar footer so the card sits above the
    // framework-rendered plugin entries and the settings row; the mutation
    // observer re-seats it whenever the framework displaces it.
    if (container.parentElement !== foot || foot.firstElementChild !== container) {
      foot.insertBefore(container, foot.firstChild)
    }
    if (currentFoot !== foot) {
      currentFoot = foot
      footResizeObserver?.disconnect()
      footResizeObserver?.observe(foot)
    }
  }

  const schedulePlace = () => {
    if (queuedPlace || disposed) return
    queuedPlace = true
    queueMicrotask(() => {
      queuedPlace = false
      if (!disposed) place()
    })
  }

  // Seat-gate (2026-10-15 perf): the body observer sees EVERY childList batch
  // in the whole app — during chat streaming that is a near-continuous stream —
  // and each scheduled place() used to open with an O(document) discovery scan
  // (`[class*="sidebarCol"]` cannot use a class index). The gate skips the
  // schedule entirely when this batch cannot change the seating:
  //   • Seat valid (card still first child of a connected foot): only a batch
  //     carrying a sidebarCol/footArea node — added OR removed, the element
  //     itself or anywhere inside it — can change WHICH foot is the doc-order
  //     first one or create a competing one. No such node ⇒ place() would be a
  //     measured no-op.
  //   • No live foot (null, or stale after the sidebar was torn down): a seat
  //     can only appear through a sidebar-introducing node, and class-only
  //     flips were already invisible to this childList-only observer.
  // A displacement inside a live foot fails seatValid() and re-arms place().
  // Invariant for the ResizeObserver rebind in place(): any batch that could
  // change which element IS the foot necessarily carries a marker node, so the
  // gate never masks a real foot swap (jsdom has no ResizeObserver; this
  // invariant is argued here, not exercised by tests). Marker-carrying batches
  // that change nothing still pay one discovery scan — the false-positive cost.
  const SEAT_MARKERS = ['sidebarCol', 'footArea']
  const seatValid = () => currentFoot !== null && currentFoot.isConnected
    && container.parentElement === currentFoot
    && currentFoot.firstElementChild === container
  const nodeTouchesSeatDiscovery = (node) => {
    if (node?.nodeType !== 1) return false
    const cls = node.getAttribute('class') ?? ''
    if (SEAT_MARKERS.some((marker) => cls.includes(marker))) return true
    return node.querySelector('[class*="sidebarCol"], [class*="footArea"]') != null
  }
  const batchTouchesSeatDiscovery = (records) => records.some((record) => {
    const touched = [...(record.addedNodes ?? []), ...(record.removedNodes ?? [])]
    return touched.some(nodeTouchesSeatDiscovery)
  })
  const observer = new win.MutationObserver((records) => {
    const noLiveFoot = currentFoot === null || !currentFoot.isConnected
    if (!batchTouchesSeatDiscovery(records) && (seatValid() || noLiveFoot)) return
    schedulePlace()
  })
  if (!slotMode) observer.observe(doc.body, { childList: true, subtree: true })
  // --- Slot-first seat (2026-10-19): 0.2.x shells render the official
  // sidebar.footer.action list slot (dsh-client-ui-sidebar contract: kind
  // 'list', owner passes only { wide }). Mounting through it removes the
  // sidebarCol/footArea CSS-substring anchor dependency entirely — the anchor
  // discovery below remains purely as the legacy-host fallback and engages
  // only when the slot is unavailable or not declared by the shell.
  if (slots && typeof slots.inject === 'function' && typeof slots.register === 'function'
    && react && typeof react.createElement === 'function') {
    try {
      // No declaration probe: the plugin facade's spec() proved unreliable on
      // 0.2.1-rc.2 (returns undefined even for shell-declared slots, while
      // register()+render works — the settings.section precedent). The mount
      // confirmation below is the real gate: if the shell never renders the
      // slot, the card falls back to the physical anchor seat within seconds.
      const SLOT_SEAT_ID = 'quota-watch-card'
        const CardSeat = (props) => {
          // Owner share is { wide }: the official contract column state.
          // Capture it every render — wide flips re-render this component
          // while the div ref stays mounted, so the ref callback alone would
          // never see the flip. Strict !== false: an absent prop keeps the
          // card visible (unknown is not collapsed).
          slotWide = props?.wide !== false
          scheduleSlotSync()
          return react.createElement('div', {
            ref: (el) => {
              if (!slotMode) return // a late render after fallback engaged: ignore, container is physically seated
              slotParent = el
              if (el) {
                // Adopt the imperative card container: React owns this mount
                // div but none of its (foreign) children, so the manual
                // append is the standard escape hatch and reconciles cleanly.
                if (container.parentElement !== el) el.appendChild(container)
                footResizeObserver?.observe(el)
              } else {
                footResizeObserver?.disconnect()
              }
            },
            'data-dsh-quota-watch-slot': '',
          })
      }
      slotDispose = slots.inject(CARD_SLOT_NAME, () => slots.register(
        { name: CARD_SLOT_NAME, id: SLOT_SEAT_ID },
        CardSeat,
      ))
      // Optimistic engage; the mount confirmation below is the truth test —
      // if the shell never renders the slot (declared but region absent),
      // the card would silently vanish, so fall back to the physical seat.
      slotMode = true
      syncCardVisibility()
      win.setTimeout(() => {
        if (disposed || !slotMode || slotParent) return
        try { win.console?.debug?.('[dsh-quota-watch] slot seat: host never rendered the slot mount — falling back to legacy anchor seat') } catch { /* no console */ }
        slotMode = false
        slotParent = null
        slotWide = true
        slotDispose?.()
        slotDispose = null
        schedulePlace()
        syncCardVisibility()
      }, 5_000)
    } catch (error) {
      try { win.console?.debug?.(`[dsh-quota-watch] slot seat unavailable (${error?.message ?? error}) — using legacy anchor seat`) } catch { /* no console */ }
    }
  } else {
    try { win.console?.debug?.('[dsh-quota-watch] slot seat: slots facade or host React unavailable — using legacy anchor seat') } catch { /* no console */ }
  }
  if (!slotMode) {
    // Blind-spot re-probe (fallback mode only): the seat-gate observer can
    // only schedule place() for batches carrying the anchor markers, so if
    // the shell ever renames those CSS-modules classes the gate would never
    // re-arm after a missed seat. A slow unseated-only retry bounds that
    // drift to one interval, and the warn-once makes the state diagnosable
    // instead of silent. Self-idles once seated; cleared on dispose.
    let anchorMisses = 0
    anchorRetryTimer = win.setInterval(() => {
      if (disposed || seatValid()) return
      schedulePlace()
      anchorMisses += 1
      if (anchorMisses === 4) {
        try {
          win.console?.warn?.('[dsh-quota-watch] sidebar anchor (sidebarCol/footArea) not found — sidebar card not mounted; capsule unaffected')
        } catch { /* console unavailable */ }
      }
    }, 15_000)
  }
  // The DSH locale feature mirrors every language switch onto <html lang>;
  // re-render on that flip so the UI follows 设置 → 语言 without a reload.
  // A no-op flip (same value) never fires, so this costs nothing at rest.
  const langObserver = typeof win.MutationObserver === 'function'
    ? new win.MutationObserver(() => { if (!disposed) renderAll() })
    : null
  langObserver?.observe(doc.documentElement, { attributeFilter: ['lang'] })
  // Arm the shell-takeover sentinel: re-probe on every workspaces-ledger
  // mutation (microtask-batched by the slot core) and once up front. Without
  // an injected slots service (DOM tests, exotic hosts) this is a no-op and
  // the card behaves exactly as before.
  let offShellTakeover = null
  try {
    if (slots && typeof slots.subscribe === 'function') {
      offShellTakeover = slots.subscribe('sidebar.workspaces', () => {
        if (disposed) return
        syncShellTakeover()
        syncCardVisibility()
      })
    }
  } catch {}
  syncShellTakeover()
  // Cold until data lands: keep the shell hidden so a slow or failed first
  // probe never flashes an empty capsule (startPolling arms the retry chain).
  syncFloatVisibility()
  place()

  /** Cold-start cadence: while no provider has rendered any data, re-poll on
   * a shortening backoff (retryNoDataMs × retryBackoffⁿ, capped at
   * pollIntervalMs) so a desktop cold start surfaces the capsule in seconds
   * instead of waiting out the fixed interval. A successful render resets the
   * chain to the normal cadence; a transport error keeps the previous
   * dataHidden state, so a cold client keeps retrying fast and a warm one
   * stays calm. */
  const nextPollDelay = () => {
    if (!dataHidden) {
      noDataRetries = 0
      return pollIntervalMs
    }
    const delay = retryNoDataMs * (retryBackoff ** noDataRetries)
    noDataRetries += 1
    return Math.min(delay, pollIntervalMs)
  }
  const startPolling = () => {
    if (timer !== undefined || doc.visibilityState === 'hidden' || disposed) return
    void poll()
  }
  const stopPolling = () => {
    if (timer !== undefined) win.clearTimeout(timer)
    timer = undefined
  }
  const onVisibilityChange = () => {
    if (doc.visibilityState === 'hidden') stopPolling()
    else startPolling()
  }
  const toggleRow = (key) => {
    panelNav = false
    lastAnchor = anchorFromRow(key)
    if (openKey !== key) forcedResetForOpen = false
    openKey = openKey === key ? undefined : key
    renderAll()
  }
  const openOverview = (anchorEl) => {
    panelNav = false
    lastAnchor = anchorFromEl(anchorEl)
    openKey = 'overview'
    syncPop()
  }
  const onPanelClick = (event) => {
    // Panel-scoped actions (the retired context menu now lives here): buttons
    // sit inside this shadow tree, so a panel-level listener sees the real
    // target with no retargeting ambiguity.
    if (event.target?.closest?.('[data-action="panel-refresh"]')) {
      // The host force-refresh re-lists cards too; do not issue a duplicate GET.
      void poll(true)
      return
    }
    if (event.target?.closest?.('[data-action="toggle-card"]')) {
      // renderAll → syncPop → renderOverview re-renders the footer, so the
      // label flips in place while the panel stays open.
      setCardHidden(!surfaceFlags.cardHidden)
      return
    }
    if (event.target?.closest?.('[data-action="panel-close"]')) {
      // Closing only ever discards an UNCOMMITTED confirmation; a POST that is
      // already in flight keeps waiting for its result (the module never
      // cancels an in-flight spend).
      resetCards.clearPending()
      openKey = undefined
      syncPop()
      return
    }
    if (event.target?.closest?.('[data-action="back-to-overview"]')) {
      resetCards.clearPending()
      openKey = 'overview'
      syncPop()
      return
    }
    const provider = event.target?.closest?.('[data-dsh-quota-watch-panel-provider]')
    if (provider) {
      forcedResetForOpen = false
      openKey = provider.dataset.dshQuotaWatchPanelProvider
      panelNav = true
      syncPop()
    }
  }
  // Both handlers ride the card's inner body element — INSIDE the card shadow
  // root — so shadow-host retargeting never applies and event.target is the
  // real row/label in every browser.
  const onBodyClick = (event) => {
    if (event.target?.closest?.('[data-action="refresh"]')) {
      if (refreshBusy) return
      void poll(true)
      return
    }
    const row = event.target?.closest?.('[data-dsh-quota-watch-row][data-expandable]')
    if (row) toggleRow(row.dataset.dshQuotaWatchRow)
  }
  const onBodyKeydown = (event) => {
    if (event.key !== 'Enter' && event.key !== ' ') return
    const row = event.target?.closest?.('[data-dsh-quota-watch-row][data-expandable]')
    if (row) {
      event.preventDefault()
      toggleRow(row.dataset.dshQuotaWatchRow)
    }
  }
  const onDocPointerDown = (event) => {
    if (openKey === undefined) return
    const path = typeof event.composedPath === 'function' ? event.composedPath() : []
    if (path.includes(panel) || path.includes(container)) return
    const target = event.target
    if (target === panel || target === container) return
    if (target?.getRootNode?.() === cardRoot || target?.getRootNode?.() === floatRoot) return
    // Same rule as panel-close: only an uncommitted confirmation dies here.
    resetCards.clearPending()
    openKey = undefined
    renderAll()
  }
  let scrollFrameQueued = false
  const onDocScroll = () => {
    // Coalesce scroll bursts into one placement per frame (mobile inertia).
    if (scrollFrameQueued || disposed) return
    scrollFrameQueued = true
    scheduleFrame(() => {
      scrollFrameQueued = false
      if (!disposed) placePanel()
    })
  }
  const onWinResize = () => {
    placePanel()
    syncCardVisibility()
    applyPosition()
  }
  const onDocKeydown = (event) => {
    if (event.key !== 'Escape') return
    if (openKey !== undefined) {
      // An uncommitted confirmation dies first and the detail stays open; an
      // in-flight POST cannot be cancelled and simply keeps waiting for its
      // result. A second Esc then closes the panel.
      if (openKey === 'glm' && resetCards.clearPending()) {
        renderAll()
        return
      }
      openKey = undefined
      renderAll()
    }
  }
  body.addEventListener('click', onBodyClick)
  body.addEventListener('keydown', onBodyKeydown)
  panel.addEventListener('click', onPanelClick)
  panel.addEventListener('keydown', (event) => {
    if (event.key !== 'Enter' && event.key !== ' ') return
    const row = event.target?.closest?.('[data-dsh-quota-watch-panel-provider][data-expandable]')
    if (!row) return
    event.preventDefault()
    openKey = row.dataset.dshQuotaWatchPanelProvider
    panelNav = true
    syncPop()
  })
  surface.addEventListener('click', onSurfaceClick)
  surface.addEventListener('keydown', onSurfaceKeydown)
  let disposeDrag = attachDrag(surface)
  doc.addEventListener('visibilitychange', onVisibilityChange)
  doc.addEventListener('pointerdown', onDocPointerDown, true)
  doc.addEventListener('scroll', onDocScroll, true)
  doc.addEventListener('keydown', onDocKeydown)
  win.addEventListener('resize', onWinResize)
  startPolling()

  return () => {
    disposed = true
    stopPolling()
    resetCards.dispose()
    if (anchorRetryTimer !== null) win.clearInterval(anchorRetryTimer)
    anchorRetryTimer = null
    slotDispose?.()
    observer.disconnect()
    langObserver?.disconnect()
    if (offShellTakeover) offShellTakeover()
    doc.removeEventListener('visibilitychange', onVisibilityChange)
    doc.removeEventListener('pointerdown', onDocPointerDown, true)
    doc.removeEventListener('scroll', onDocScroll, true)
    doc.removeEventListener('keydown', onDocKeydown)
    win.removeEventListener('resize', onWinResize)
    body.removeEventListener('click', onBodyClick)
    body.removeEventListener('keydown', onBodyKeydown)
    panel.removeEventListener('click', onPanelClick)
    surface.removeEventListener('click', onSurfaceClick)
    surface.removeEventListener('keydown', onSurfaceKeydown)
    disposeDrag()
    // A dispose landing mid-gesture must not leave the body unselectable.
    doc.body.style.userSelect = ''
    container.remove()
    panel.remove()
    floatHost.remove()
  }
}

export function apply(ctx) {
  ctx.effect(() => mountQuotaCard({ slots: ctx.slots ?? null }), 'dsh-quota-watch: sidebar')
}
