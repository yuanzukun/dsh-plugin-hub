function isIPv4Loopback(address) {
  const parts = address.split('.')
  return parts.length === 4
    && parts[0] === '127'
    && parts.every((part) => /^\d{1,3}$/.test(part) && Number(part) <= 255)
}

function isLoopbackAddress(address) {
  if (typeof address !== 'string') return false
  const normalized = address.toLowerCase()
  if (normalized === '::1') return true
  if (normalized.startsWith('::ffff:')) return isIPv4Loopback(normalized.slice('::ffff:'.length))
  return isIPv4Loopback(normalized)
}

function isLoopbackHostname(hostname) {
  if (hostname === 'localhost' || hostname === '[::1]') return true
  return isIPv4Loopback(hostname)
}

export function isSameOriginRequest(request) {
  if (request.headers?.['sec-fetch-site'] === 'cross-site') return false
  const origin = request.headers?.origin
  if (origin === undefined || origin === null || origin === '') return true
  const host = request.headers?.host
  if (typeof host !== 'string' || host === '') return false
  try {
    return new URL(origin).host === host
  } catch {
    return false
  }
}

export function isLoopbackRequest(request) {
  if (!isLoopbackAddress(request.socket?.remoteAddress)) return false
  const host = request.headers?.host
  if (typeof host !== 'string' || host === '') return false
  let hostname
  try {
    hostname = new URL(`http://${host}`).hostname
  } catch {
    return false
  }
  return isLoopbackHostname(hostname) && isSameOriginRequest(request)
}

function pairingService(ctx) {
  try {
    // Sanctioned non-throwing lookup: works whenever a future host provides
    // the pairing service again. On cordis Local a bare `ctx.remoteWebUiPairing`
    // property read throws for a non-injected service, so it must not be used
    // as a fallback (the service itself is absent from 0.2.x hosts — pairing
    // authorization currently degrades to loopback-only).
    const fromGet = typeof ctx.get === 'function' ? ctx.get('remoteWebUiPairing', false) : undefined
    if (fromGet && typeof fromGet.isPairedDevice === 'function') return fromGet
  } catch {
    // Missing optional pairing service stays loopback-only.
  }
  return undefined
}

/** Allow the local desktop or a browser session explicitly paired by the host. */
export function isPairedOrLoopbackAllowed(ctx, request) {
  if (isLoopbackRequest(request)) return true
  if (!isSameOriginRequest(request)) return false
  try {
    return pairingService(ctx)?.isPairedDevice(request) === true
  } catch {
    return false
  }
}

/** 官方信任检查的守卫式委派（dsh-m 0.9.0 同款）：connection 在位 → 官方判定；服务查不到（含未注入名 get 抛错）→ undefined 回落 pairing/loopback 栅栏；围栏执行抛错 → fail-closed 403。 */
export function officialRejection(ctx, request) {
  let connection, reject
  try {
    connection = ctx?.get?.('connection')
    reject = connection?.requestRejection
  } catch { return undefined }
  if (typeof reject !== 'function') return undefined
  try {
    return reject.call(connection, { headers: request.headers }) ?? undefined
  } catch { return 403 }
}
