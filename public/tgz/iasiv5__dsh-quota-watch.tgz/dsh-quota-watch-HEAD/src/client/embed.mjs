/**
 * The CEP v1 guest side (docs/interop/capsule-embed-protocol.md in
 * dsh-stock-kanban; ADR 0008 here): the embed protocol cluster of
 * mountQuotaCard. Listens for the host's window-level CustomEvents
 * (namespace `dsh-quota-watch:*`), answers probes with this guest's
 * capabilities, tracks the embedded lifecycle (engage / heartbeat watchdog +
 * standalone-heartbeat re-embed / disengage), and forwards open-panel anchors to the mount's
 * own toggle semantics.
 *
 * Internal seam of mountQuotaCard (ADR 0007): the external mountQuotaCard
 * interface is frozen; this module is wired only by src/client.mjs and is
 * tested directly by tests/client-embed.test.mjs. Pure win injection — no
 * DOM dependency — so the state machine stays unit-testable without jsdom.
 */

export const EMBED_PROTOCOL_VERSION = 1
export const EMBED_CAPABILITIES = ['hide-pill', 'anchored-panel', 'poll-pause']
/** 与 package.json version 同步（tests/package-shape.test.mjs 防漂移断言执有） */
export const EMBED_GUEST_VERSION = '0.1.42'

const NS = 'dsh-quota-watch'
const event = (type) => `${NS}:${type}`

export function createEmbed({ win, onEmbeddedChange, onOpenPanel, heartbeatTimeoutMs = 15000 }) {
  let embedded = false
  let watchdog = null

  const dispatch = (type, detail) => {
    try {
      win.dispatchEvent(new win.CustomEvent(event(type), { detail, composed: true, bubbles: true }))
    } catch {
      /* 无 CustomEvent 的环境静默：协议不可用不拖垮挂载 */
    }
  }

  const clearWatchdog = () => {
    if (watchdog !== null) {
      try { win.clearTimeout(watchdog) } catch { /* 同上 */ }
      watchdog = null
    }
  }
  const armWatchdog = () => {
    clearWatchdog()
    if (typeof win.setTimeout === 'function') {
      watchdog = win.setTimeout(() => {
        watchdog = null
        // 孤儿保护：宿主未及 disengage 消失（禁用/崩溃/HMR）→ 3 拍未达自恢复
        setEmbedded(false)
      }, heartbeatTimeoutMs)
    }
  }

  const setEmbedded = (next) => {
    if (embedded === next) return
    embedded = next
    if (typeof onEmbeddedChange === 'function') {
      try { onEmbeddedChange(next) } catch { /* 订阅者异常不扩散 */ }
    }
  }

  const onProbe = () => {
    dispatch('embed-capabilities', {
      v: EMBED_PROTOCOL_VERSION,
      capabilities: [...EMBED_CAPABILITIES],
      guestVersion: EMBED_GUEST_VERSION,
    })
  }
  const onEngage = () => {
    setEmbedded(true)
    armWatchdog()
  }
  const onHeartbeat = () => {
    // 心跳只在宿主 engage 期间发出（宿主 stopEngage 同步清心跳定时器后才派发 disengage，
    // 窗口级事件同步派发、无迟到心跳）。独立态收到心跳＝宿主仍认为合并中（看门狗超时
    // 误恢复 / 访客重挂后旧宿主心跳未断），直接回嵌入并武装看门狗——心跳兼作重嵌入
    // 信号，消灭「宿主 engaged / 访客 standalone」永久分脑（ADR 0008 语义修订，0.1.39）。
    setEmbedded(true)
    armWatchdog()
  }
  const onDisengage = () => {
    clearWatchdog()
    setEmbedded(false)
  }
  const onOpenPanelEvent = (ev) => {
    const anchor = ev?.detail?.anchor
    if (anchor === undefined) return
    if (typeof onOpenPanel === 'function') {
      try { onOpenPanel(anchor) } catch { /* 同上 */ }
    }
  }

  win.addEventListener(event('embed-probe'), onProbe)
  win.addEventListener(event('embed-engage'), onEngage)
  win.addEventListener(event('embed-heartbeat'), onHeartbeat)
  win.addEventListener(event('embed-disengage'), onDisengage)
  win.addEventListener(event('open-panel'), onOpenPanelEvent)

  return {
    isEmbedded: () => embedded,
    dispose() {
      clearWatchdog()
      win.removeEventListener(event('embed-probe'), onProbe)
      win.removeEventListener(event('embed-engage'), onEngage)
      win.removeEventListener(event('embed-heartbeat'), onHeartbeat)
      win.removeEventListener(event('embed-disengage'), onDisengage)
      win.removeEventListener(event('open-panel'), onOpenPanelEvent)
      embedded = false // 惰性化：isEmbedded 归 false（UI 恢复由挂载侧 teardown 负责，不通知）
    },
  }
}
