# dsh-context-maid — 自动上下文策展插件设计文档 v0.2（用户拍板后定稿）

> 日期：2026-09-08 | 状态：0.3.0 已收口（C0→M5→M6→M7 全落地，52 测试全绿，版本 0.3.0；设计稿 docs/design-0.3.0.md）——v0.2 基线（P0-1/P0-2 修复集 535d667，36 测试）（用户拍板：命名 dsh-context-maid、repo 在 my-plugins/、工具链 mjs+node --test、sweep aggressive 保留意见、新增 compact 模型用户可配 + 智能路由端点） | 前置调研：
> dsh-compaction-survey.md（本地基建）、context-mgmt-survey.md（业界）、
> context-compaction-assets-draft.md（资产）、context-compaction-survey-index.md（索引+实测）
> 用户拍板（verbatim 语义）：独立 repo；全阶段规划；阈值用户可调；
> **压缩重点 = 节约 tool 输出与无效日志**；**保护重点 = 正在进行的工作流 / 记忆 / 用户要求重点**；ACP 分类防御顺手修。

## 1. 背景与问题

DSH 自带 compaction 家族（自动 80% 窗口触发 + /compact + 固定头尾 pruner），但实测：
- 自动压缩从未触发（deepseek-v4-flash 默认 100 万窗口 → 阈值 80 万 token，会话到不了）
- 用户实际在 ~30-45% 上下文主动 /compact——手动是常态
- 官方 pruner 只做固定 head/tail 截断（不感知内容价值）；压缩 = 单次 LLM 总结，无记忆联动
- 上下文膨胀的主因不是对话本身，而是 **tool 输出堆积与无效日志**（重复读取、失败重试中间产物、
  超长 stderr、被取代的结果）——用户拍板：这才是压缩的主战场
- 同时：正在进行的工作流（goal/nextSteps）、记忆与用户明确要求的内容**不能被有损压缩误伤**
  （业界教训：Claude Code 指令/plan 被压丢 issue #24686/#36068；Governance Decay 论文：
  压缩静默删除安全约束）

## 2. 目标与非目标

### 目标
1. **自动、主动**地在上下文到达可调阈值前做策展（默认建议对齐用户习惯 ~35-45%）
2. **优先清理**：tool 输出（大结果、过时结果、重复读取）与无效日志（stderr 噪音、失败中间产物、
   被取代内容、僵尸消息）——按内容价值而非固定头尾
3. **保护**：进行中的工作流（work_state / 当前 goal / 活动 todo）、记忆与用户要求重点
   （user_explicit/user_correction 高 authority、用户明确"记住/重点"的内容）——物理钉扎，不进有损压缩
4. **归档**：被清理/压缩的高价值内容先进 ACP ledger（先沉淀后压缩），压缩摘要本身成为一条
   带 supersedes 链的证据——压缩可审计、可恢复
5. **可配置可观测**：阈值/开关全用户可调（设置页 + settings.yaml）；每次策展输出报告进审计

### 非目标（v0.1 不做）
- 不做跨会话共享上下文（单会话作用域，与官方一致）
- 不做 model-facing compact 工具（KNOWN_SESSION_EVENT_TYPES 门禁，探索期后置）
- 不重写 DSH compaction 引擎（继承/消费官方 seam）
- 不做图片/富块的压缩（官方限制同）

## 3. 核心概念：内容策展分级（Guardian Rating）

给 surface 上每个消息节点打「保留等级」，策展按等级决定去留：

| 等级 | 含义 | 处理 | 示例 |
|---|---|---|---|
| **PIN** | 钉扎：不可有损 | 永不进压缩/清理；如可能移到不可压缩前缀 | user_explicit/correction 原文、当前 goal、用户说"记住/重点"的内容、进行中步骤的指令 |
| **KEEP** | 保留：当前工作相关 | 正常保留，参与尾部预算 | 最近 N token 内的活动内容 |
| **SLIM** | 可瘦身：保价值去冗余 | 内容感知截断（非固定头尾） | 超长 tool 输出（保留关键段）、大 JSON/日志（保留结构+关键行） |
| **SWEEP** | 可清理：无效/过时 | 从 surface 移除（进 ledger 留痕） | 被后续取代的读取/结果、失败重试中间产物、stderr 噪音、僵尸消息 |
| **FOLD** | 可压缩：旧对话 | 标准 checkpoint 摘要（官方事务） | 早期对话、已归档的工作讨论 |

**判定依据（确定性为主，LLM 为辅）**：
- authority 高者（user_explicit/user_correction/system_policy）→ PIN（ACP authority 模型直接复用）
- work_state 引用 / 当前 turn 近邻 / 未完成步骤 → KEEP
- tool 结果：按体积、时效（是否有更新的同工具结果/supersede）、内容类型（错误信息保留、日志压缩）→ SLIM/SWEEP
- 僵尸特征：孤儿 tool-call（无 result）、被 replace 遮蔽段、重复读同一文件、失败后的成功重试前体 → SWEEP
- 其余旧内容按时间/相关性 → FOLD

## 4. 架构总览

```
dsh-context-maid（独立 cordis 插件）
│
├─ ctx.compaction 关系：注册自研后端（extends BasicCompactionEngine）或挂 auto:false +
│   自研触发监听（二选一，绝不双 auto）
│
├─ 模块：
│  ├─ classifier.mjs    内容分级（PIN/KEEP/SLIM/SWEEP/FOLD）——确定性规则引擎
│  ├─ pinner.mjs        钉扎段管理：识别 PIN 内容并保护（压缩范围排除 + 必要时前置）；
│  │                     planPinInstruction 外露注入记账 kept/omitted
│  ├─ anchor.mjs        （实现）确定性锚点原语：抽字面锚点 + 归一化包含比对（零 LLM）
│  ├─ fold-verify.mjs   （实现，2026-09-25）折叠后「不可丢约束」校验：折叠前清单摘要
│  │                     （PIN 集合 + sha256 稳定标识）+ 三态结论 ok/partial/lost
│  ├─ slimmer.mjs       tool 输出内容感知瘦身（可注册为 toolResultPruner 服务替换官方版）
│  ├─ sweeper.mjs       无效日志/僵尸清理（用官方 compactRegion 事务移除）
│  ├─ trigger.mjs       触发策略：可调阈值预检 + 事件触发 + 溢出回退 + 手动
│  ├─ archiver.mjs      归档：SWEEP/FOLD 内容 → ACP ledger（先沉淀后压缩）
│  ├─ summarizer.mjs    覆写 summarize()：归档后摘要 + 钉扎段保护（官方唯一子类钩子）
│  ├─ report.mjs        策展报告 + 审计（audit 表 + 每轮可查）
│  └─ index.mjs         apply 装配
│
├─ 数据：
│  ├─ 配置：Config schema（全部用户可调）+ 设置页卡片（namespace context-guardian）
│  └─ 审计：独立 SQLite（或复用 ctx 审计？见开放问题）—— 每次策展的决策记录
│
└─ 依赖：@deepseek-ai/dsh-compaction-basic（继承 + 复用事务）、ACP（可选：ledger 写入）、
     dsh-tools、dsh-session、schemastery
```

## 5. 关键机制设计

### 5.1 触发策略（trigger.mjs）——阈值用户可调
- **预检触发**（对齐 opencode）：agent/pre-step waterfall 中估算
  `totalTokens > 预算 − max(output预算, 安全buffer)` → 预算 = contextWindow × userRatio（默认 0.40，
  用户可调 0.2-0.8）；userRatio 是核心可调旋钮
- **内容事件触发**：大 tool 输出落地即处理（不等待总量阈值）——SLIM 立即瘦身、SWEEP 立即清；
  监听 session/event 的 tool/result 类型，体积 > slimThreshold（默认 4000 字符）即入队
- **溢出回退**：provider CONTEXT_WINDOW_EXCEEDED → 强制一轮（prune→retain=0 最大缩减）
- **手动**：注册 /context-guardian 命令族（status / run / slim-now / config）
- **节流与防抖**：同 turn 至多一次 FOLD；每日上限；与 ACP consolidation 错峰（后台队列）

### 5.2 钉扎段（pinner.mjs）——保护工作流/记忆/用户重点
- PIN 与摘要指令消息使用 `source.kind: plugin:dsh-context-maid`，不携带旧式 `source.plugin` 字段。
- PIN 内容来源：
  a) ACP authority 判定 user_explicit / user_correction / system_policy 的原文（如 ACP 在线，调 ctx.acp.query authority 过滤）
  b) 本插件自维护轻量判定：消息文本含用户指令特征 + 长度阈值 + 关键词（"记住/重点/必须/不要/改成"）
     + 当前 work_state.goal 相关段（若 work-continuity 在线）
- 保护机制：FOLD 压缩时**范围排除**——selectCompactableRange 只压 PIN 段之外的区域；
  实现 = 继承 BasicCompactionEngine 后覆写 compactIfNeeded/compactRegion 的区间选择，
  或自建 range 计算后调官方事务（官方事务本身尊重给定区间）
- 钉扎段的跨轮可见性：PIN 高价值短内容（用户要求）若在保留尾之外，压缩后**仍应注入**
  （每轮固定小段，~100-200 token，来源=ledger 高 authority observation）——这就是
  「记忆与用户要求重点不丢」的兜底

### 5.3 内容感知瘦身（slimmer.mjs）——tool 输出主战场
- 注册为 ctx.get('toolResultPruner') 的自研实现（官方结构：pruneSession(session): PruneResult，
  可重放、遵守影子价格协议）→ compaction-basic 自动使用
- 或独立于压缩在 tool/result 落地时瘦身（替换超大 result 为保留段）
- 策略（按内容类型，非固定 head/tail）：
  - 错误/stderr：保留尾部错误段 + 头部摘要行（诊断信息价值在尾部）
  - JSON/结构化：保留结构骨架 + 数组长度标注 + 关键字段采样
  - 长文本/日志：保留头尾 + 中间折叠计数
  - 文件读取：保留路径 + 行数 + 关键片段（若 ACP 已存全文则只留指针）
- 可回退：内容类型识别失败 → 官方 head/tail 策略
- 与官方 pruner 关系：默认替换官方版（卸载插件即恢复）

### 5.4 无效日志/僵尸清理（sweeper.mjs）
- 识别（确定性）：
  - 孤儿 tool-call（无配对 result）与已被 replace 遮蔽的段（compaction shadowedSeqs 可查）
  - 同工具连续多次调用中，被最后一次结果取代的前序结果（supersede 检测：同 toolName + 同参数指纹）
  - 失败中间产物：失败 tool 结果后同目标成功 → 失败段降级 SWEEP
  - permission/approval 噪音（非敏感、重复）
  - 超长 stderr 已解决（后续无相关错误引用）
- 执行：官方 compactRegion 事务移除（平衡边界内），每段留 audit
- 保守原则：拿不准就 SLIM 而非 SWEEP（宁可瘦身不可丢信息）；用户可设 aggressive 档

### 5.5 归档（archiver.mjs）——先沉淀后压缩
- SWEEP/FOLD 前：把区间内高价值内容写入 ACP ledger（ctx.acp.append，带 sourceRef 指向
  sessionEventId；ACP 离线时跳过——有 ACP 已摄入的事件不必重复）
- 摘要即证据：FOLD 的 checkpoint 摘要写入 ledger 为一条 observation
  （subject=session 标识，text=摘要，evidenceIds=被压段证据 id，supersedes 链关联）
- 效果：压缩后任何被压内容可经 ACP recall 找回；lineage = 递归总结链
- ⚠ **实现现状（2026-10-05 实测，与上两行不符）**：实际写的是 **evidence 而非 observation**；
  且因未声明 `input.ingest` 被 ingest 闸门判为未受信来源、落 `quarantined`（18/18）。
  PIN 那一端读 observation 轨，注入又冻结着，故**读不回来**。摘要仍可经 `acp_query`（`state:all`）
  人工查回。修法与代价见 `ops/maid-archive-route-plan.md`（结论：改描述即可，不值得为它动信任模型）。

### 5.6 摘要（summarizer.mjs）——继承官方、增强保护
- extends BasicCompactionEngine：
  - 覆写 summarize(input, agent, signal)：先跑 archiver（归档区间内容）→ 再调官方摘要
    （或增强版：摘要 prompt 注入「以下为必须保留的关键事实」清单——来自 ledger PIN observation）
  - 其余（事务/锁/收缩校验/影子价格）全复用
- 钉扎协同：FOLD 区间选择时排除 PIN 段（见 5.2）

### 5.7 策展报告与审计（report.mjs）
- 每次策展（SLIM/SWEEP/FOLD）写审计行：时间/类型/范围 seqs/token 前后/归档条目 id/摘要预览
- /context-guardian status：当前上下文预算占用、近 N 次策展、PIN 段清单
- 审计可导出（对齐 ACP export）

## 6. 配置全表（全部用户可调；设置页 + settings.yaml）

| 字段 | 类型 | 默认 | 说明 |
|---|---|---|---|
| enabled | bool | true | 总开关 |
| trigger.userRatio | number | 0.40 | 预检触发阈值（占 contextWindow 比例；用户主旋钮 0.2-0.8） |
| trigger.minTokens | number | 30000 | 低于此总 token 不触发（小会话不折腾） |
| trigger.eventSlim | bool | true | tool/result 落地即瘦身 |
| slim.thresholdChars | number | 4000 | 超过即瘦身的 tool 输出长度 |
| slim.tailChars | number | 800 | 错误类保留尾部长度 |
| slim.headChars | number | 800 | 文本类保留头部长度 |
| sweep.enabled | bool | true | 僵尸/无效日志清理 |
| sweep.aggressive | bool | false | 保守(false)/激进(true) 清理档 |
| fold.retainRatio | number | 0.16 | FOLD 保留尾比例（透传官方） |
| pin.enabled | bool | true | 钉扎段保护 |
| pin.inject | bool | true | 压缩后仍注入 PIN 摘要（~150 token） |
| archive.enabled | bool | true | 先沉淀后压缩（需 ACP 在线；离线自动跳过） |
| summarization.provider | string | '' | 摘要模型 provider（空=跟随对话模型；可配便宜/本地模型） |
| summarization.model | string | '' | 摘要模型名（与 provider 成对；空=跟随） |
| summarization.allowLocal | bool | true | 允许把摘要路由到本地/pi-ai 网关 provider（智能路由用） |
| debug | bool | false | 调试日志 |

## 7. 分阶段计划（全部规划，里程碑落地合并 main）

- **M1 骨架与触发**（可独立交付）：插件骨架 + Config/设置页 + trigger 预检接入官方事务 +
  手动命令 + 审计表。验收：挂载后能按 userRatio 触发一次官方 FOLD，报告可见
- **M2 清理主战场**（tool/日志）：slimmer（替换官方 pruner）+ sweeper（僵尸/无效清理）+
  事件触发。验收：长会话 tool 堆积被自动瘦身/清理，token 占用明显下降，无信息事故
- **M3 保护与归档**：pinner（钉扎排除 + PIN 注入）+ archiver（先沉淀后压缩 + 摘要即证据）。
  验收：压缩后用户要求与 goal 仍在；被压内容可经 ACP recall 找回
- **M4 增强摘要与打磨**：summarizer 知识感知摘要 + 报告/观测完善 + 长期会话回归。
  验收：多轮压缩会话无关键信息丢失（对比基线）
- 每里程碑：独立 feature 分支 → 测试全绿 → 文档同步 → squash 合并 main（沿用既有流程）
- 附带独立小修：ACP extract.mjs 对 user/ 前缀事件检查 source.kind==='plugin' → 降权/跳过
  （防御性；可先行单独提交）

## 8. 测试计划

- 单元：classifier 分级规则表、slimmer 各内容类型策略、sweeper 僵尸识别、pinner 排除逻辑、
  trigger 阈值计算
- 集成（mock session/event + fake tokenMeter/llm）：SLIM/SWEEP/FOLD 全链路、与官方事务共存
  （同一把锁）、双 auto 防护测试（挂载后不得双压）
- 回归：挂载本插件前后官方 /compact 行为不变；卸载即恢复
- 真实回归用例：拿现有超长会话（ee1a/75a4）回放——统计可瘦身/清理的 token 占比（作为 M2 验收基线）
- 门禁：vitest/tsc 全绿（沿用 dsh 风格）或 node --test（沿用 ACP 风格）——与 repo 形态一致

## 9. 决策记录与开放问题

### 已拍板（2026-09-03 用户）
1. 命名：**dsh-context-maid**（repo：D:\\DSH_workspace\\my-plugins\\dsh-context-maid）
2. repo 位置：my-plugins/（与 ACP 同）
3. 工具链：mjs + node --test（与 ACP 一致，轻量）
4. sweep aggressive 档：**保留意见**——设计保留 sweep.aggressive 配置项，默认 false（保守）；
   是否加审批门待后续讨论
5. **新增需求：compact 模型用户可配 + 智能路由端点**（见 §5.8 与 §6 配置扩展）

### 剩余开放问题
1. **继承 vs 旁路**：M1-M3 推荐「挂 auto:false 官方后端 + 自研触发/清理走官方事务」；
   M4 summarize 增强需要继承 BasicCompactionEngine——同进程只能有一个 ctx.compaction 实现，
   继承注册会替换官方实例（卸载恢复）——按此推进，如有异议随时提
2. **钉扎段技术细节**：PIN 段压缩范围排除的实现路径需在 M3 前 spike（selectCompactableRange
   是模块函数不可继承；可能需在 range 计算后自校验/或 fork 官方 region 逻辑）——spike 先行
3. **ACP 依赖方向**：通过 ctx.acp 可选服务（ACP 不在线自动降级），不制造硬依赖
4. **审计存储**：独立 SQLite（与 ACP 一致模式）
5. **与官方 pruner 并存**：替换官方 tool-result-pruner 后，command-compact 等仍正常工作
   （结构兼容）——需在 M2 验证

### §5.8 新增：compact 模型配置与智能路由端点（用户 2026-09-03 拍板）
- 动机：摘要任务不需要最强模型——用户可配便宜小模型或本地模型（如局域网 LM Studio /
  OpenAI 兼容网关）进一步节约预算；同时给「LLM 智能路由」提供接入端点
- 现状基础：DSH 的 llm-pi-ai 网关适配器（base 依赖，dormant 零路由）可把 OpenAI-compatible
  端点注册为 provider；compaction-basic 原生支持 summarizationProvider/summarizationModel 字段
- maid 设计（配置 + 可选服务）：
  a) \`summarization.provider\` / \`summarization.model\`：用户指定摘要模型；**留空 = 跟随对话模型**
     （默认，零配置可用）
  b) 设置页可填 provider/model（提示可用 provider：deepseek-official、deepseek-vision、
     本地 pi-ai 网关等）
  c) 智能路由接入点：maid 暴露 \`maid.resolveSummarizationTarget(session, defaultTarget)\` 服务方法；
     外部智能路由插件可覆写决策（便宜模型优先/本地模型优先/成本感知），
     maid 自身实现 = Config 显式值 ?? 跟随对话模型；该 seam 也是未来 model-facing compact
     工具的路由口
- 注意：摘要模型质量直接决定压缩质量——文档将引导用户「便宜但别太弱；压缩是不可逆的，
  省下的预算不该用关键信息丢失来换」（与业界 Cursor/Claude 结论一致：摘要质量是最大抱怨点）

## 9.5 实测记录（2026-09-03 live，正式 web profile）

**挂载**：profile patch disable 官方 compaction-basic / tool-result-pruner，
maid 作为 ctx.compaction / ctx.toolResultPruner 唯一提供者（同 key 单提供者约束）；
bundle 只允许同 id 配置覆盖，禁止二次插入（否则 boot 报 duplicate loader entry id）。

**/context-maid status 实测**：
```
engine: ctx.compaction = MaidCompactionEngine（maid 提供，阈值映射生效）
userRatio: 0.4（→ 官方 thresholdRatio）
enabled: true
```

**/compact 实测**：压缩 761 条历史记录（≈372,810 tokens）成功——
事务由 MaidCompactionEngine 继承的官方路径执行（阈值映射未破坏事务语义）。

**发现与修复（commit 6b4d680）**：压缩成功但 maid_audit 0 行——archiver
旧实现把 audit 写在 acp.append 之后且依赖 ACP 在线解析（ctx.get('acp')），
任一前置 return（ACP 不可达 / 摘要空）都无痕，无法区分「事件未达」与
「归档路径断开」。修复：**audit-first**——compaction/summary 事件到达即写
审计（op=fold，detail 记录归档结果或跳过原因），ACP 归档降为可选附加；
acp 解析多路兜底 ctx.get('acp') → ctx.acp。测试同步更新
（ACP 离线 → 不 append 但审计留痕）。重启后 /compact 应见 maid_audit 落行。

**联动防御（ACP commit c75544a）**：压缩 checkpoint 消息（user/message +
surfaceOp={op:replace}）与插件源消息不再冒充 user_input 入 ledger。
**第二轮实测与修复（commit 0732f60）**：重启后 /compact（1002 条 ≈409k tokens）
audit 落行但 archive_ids=[]，detail「acp.append 未返回 id」——根因：ACP
writeGuard secret 扫描 **block 而非 throw**（返回 {inserted:false, decision:'block'}），
压缩摘要含命令/配置样例（如 `frp token: 5a8cda…`）命中 SECRET_PATTERNS。
修复：archiver 内置 `redactSecrets`（键名保留、值掩码 [redacted]；高熵整段掩码），
block → 脱敏重试一次；detail 记录 decision + reasons。

**第三轮实测与修复（commit 594daf7）**：脱敏放行后暴露真身——detail「sensitivity
must be one of public|private|sensitive|secret, got \"internal\"」：archiver 一直传
`sensitivity:'internal'`（不在 ACP 枚举，store.append 以 TypeError 断言），此前被
secret block 挡在更外层、从未到达 store。修复：改 `sensitivity:'private'`（契约值，
与 ACP SENSITIVITIES 同步）。前两轮修复让内容逐层深入，才使该契约错误暴露——
audit-first 的可观测 detail 是逐轮定位的关键。

**最终验证（2026-09-03）**：本会话 /compact（session-58f5268c…，104,665 tokens，
range 336135:394182）→ maid_audit id=3 `archive_ids=["ev_ae44fc5f2319a4d7b33a95de"]`，
detail「已归档（decision=allow）」（干净路径，未触发脱敏）；ACP ledger 侧
ev_ae44fc5f2319a4d7b33a95de 存在：agent_authored / single_observation / experience /
sensitivity=private / content=【maid 压缩归档】摘要 / source_ref 含
sessionEventId 394607 + maidCompactionId。**归档链路端到端闭环。**


## 9.6 实测记录（2026-09-08 live，0.3.0 eventSlim/sweep 落地验证）

**验证方法**：会话内放超阈值 tool 输出探针（5966 chars）→ step 边界 → 查 maid.db 审计。
手动命令 /context-maid slim-now（0.3.0 新增）作为验证/运维口。

**实测结果**：eventSlim: 21 pruned / 217 checked（charsRemoved 134712）——
审计 op=slim 落行（原 seq→副本 seq 溯源完整，如 5986→1639 chars）。端到端闭环。

**发现与修复（三个集成级问题，单测未能覆盖——mock ctx 与真实 cordis 差异）**：
1. **private field 与 HMR/原型替换失配**：engine 状态用 JS private field（#cleanupTicks 等），
   运行时报 "Cannot read private member #cleanupTicks from an object whose class did not declare it"。
   修复：状态字段改构造期普通属性（_x 前缀）——HMR/loader 原型替换下普通属性存实例上不受影响。
2. **cordis Service 注入代理**：maid 直接 new Service 子类（M1 沿用，非 ctx.plugin 装配），
   cordis 注入代理未绑定 inject 属性——this.ctx.tokenMeter 属性访问抛
   "cannot get property tokenMeter without inject"（fail-open 吞错后 eventSlim 静默跳过）。
   修复：getTokenMeter(ctx) 走 ctx.get('tokenMeter') 服务查找（与 toolResultPruner 同路径）；
   MaidSlimmer 覆写 pruneSession（官方语义 + 安全 meter，官方实现内部属性访问无法覆写）。
3. **pre-step 节奏**：agent/pre-step 在 web GUI 会话按 turn/step 边界触发（cleanupTicks 证实），
   eventSlim 增量在每回合边界对新增超预算 tool 输出生效——与官方 FOLD 同节奏，符合设计 §5。

**运维口**：/context-maid slim-now（手动全跑一次 eventSlim+sweep 并回报统计）；
status 增加 cleanupTicks / pruner / eventSlim / sweep 诊断行。

**sweep 实测（14:11-14:16 live）**：patch 开 sweep.enabled=true 后自动路径立即工作——
会话历史遗留的同路径重复读取被逐个 superseded-read 处置（#238-241），实测序列
（同路径 read ×2 + 失败 read → 成功重试）触发 superseded-read（#241）+ failed-retry（#242）；
审计 op=sweep 落行（kind/reason/seq 溯源完整）。eventSlim 0 pruned（实测 read 均小体积）符合预期。
**实测前修复**：superseded-read 收紧为仅路径键指纹触发（fp 含 '|'）——name-only 工具
（run_code 等）同工具多次成功内容不同，误清前序会丢信息（+1 测试，53 全绿）。

**2026-09-09 阈值修正（slim.thresholdChars 4000→30000，profile patch 层）**：
用户信息摄取工作流发现 eventSlim 默认 4000（≈1k tokens）过低——>4k 字符的工具输出
在下一步模型请求前被常态压缩（头尾 800/骨架），模型从未见过中部全文（9-09 实测 28 次处置
49944→1639 等）。ACP 账本无损（session/event 实时摄入 append 原文 + isCompactionCheckpoint
跳过 replace 副本），损失面在模型会话内消费。修正：profile patch 阈值调至 30000
（≈7.5k tokens，覆盖单页网页/单文件；巨型输出仍压缩）。仓库默认值暂未动（4000，
新 profile 按需配置）。教训：eventSlim 的"常态前置压缩"语义下，阈值应瞄准
「巨型噪音」而非「中等输出」——信息摄取型工具输出不应被默认压。

**0.3.0 live 验证总结**：FOLD（status 确认）/ eventSlim（21 pruned，-134712 chars）/
sweep（自动 + 手动均处置）/ 审计闭环全部工作；集成问题 ×3 修复见上；运维口
/context-maid slim-now + status 诊断行。

## 9.7 实测记录（2026-09-21 live，B12/B14 可观测性）

### 为什么改

`/context-maid status` 原来只显示**最近一次** PIN 校验，形成幸存者偏差——调研者本人就因此误判为
「软保护 100% 有效」（首次只查了最近 12 行，恰好全是高命中）。把「最近一次」换成「近 N 次分布」
之后，本机随即暴露了真实形态。

### 本机实测（19 行 `op=pin`，2026-09-20 12:02 → 2026-09-21 14:58）

```
锚点总数        每次恒为 5（不是文档里的 4）
命中分布        0/5 ×10、1/5 ×4、3/5 ×4、2/5 ×1
全丢（0/N）     10/19 = 53%
可校验率        每次恒报「11 条事实无字面锚点」→ 16 事实抽 5 锚点 ≈ 31%
```

**结论**：软保护的实际强度远低于旧口径给人的印象，而且**每次都有约 7 成事实根本不可校验**
（纯自然语言偏好抽不出字面锚点）——「命中率高」与「保护有效」不是一回事，这正是 B12 要修的口径。

> **口径存疑，未结**：本机 19 行全是 5 锚点，而上游调研记录写的是 38 次、分母恒为 4、全丢仅 10.5%。
> 两者不是同一份样本，已列入待核对项（对齐 `06-measurements/maid-audit-snapshot.csv`），本文不下结论。

### foldDepth

按 `session_id` 反推（旧数据的形态，新代码会直接写在行里）：

```
session-7149728f  10 层      session-f91b0a3e  5 层
session-0d45cbf0   4 层      session-f853c934  2 层
```

深度是「这个会话还要不要继续」的判据，此前只能手写 `group by` 才看得到；现在 `status` 直接给。
阈值 10 起 warn（不阻断）。

### 两处设计偏离（都是被真实风险推着改的）

1. **foldDepth 用 `session.id` 字符串作键，不用 WeakMap 按对象**。原设计稿写 WeakMap（随会话回收、零新依赖），
   但对象身份在事件派发之间没有保证；一旦宿主每次派发都换包装对象，WeakMap 恒返回 0，深度会永远写 1 而且**没有任何报错**。字符串键的代价只是每会话一个整数。
2. **`op=pin` 的 `detail` 落盘前压长度**。审计表把 `detail` 截到 500 字符，而锚点列表是变长的：
   10 个 60 字符的锚点就能超过 500，写出**半截 JSON**——而 status 的分布正依赖它可解析。
   命中数改为独立字段，裁剪数组不再影响口径。

## 9.8 折叠后「不可丢约束」校验（2026-09-25）

### 为什么是「校验」而不是「更好的摘要」

同一批论文的实证结论一致：**压缩的失败点不在摘要质量，而在约束与结构的丢失**
（arXiv 2608.11242 / 2605.08580 / 2608.16370）。另一篇白盒实测更直接地打在 skill 机制上——
同一模型、同一任务，**干净上下文 10 过 8，污染上下文 10 过 3**（arXiv 2607.17937）：
「载入」不等于「约束生效」。落到 maid 上就是：折叠前把 PIN 注入摘要指令只是**请求**，
折叠后必须**校验**它还在不在。此前只有前半（`_verifyPinAnchors` 的 C6 v1），
本次把后半补齐，并把结论做成可审计的三态。

### 三个组成部分

1. **折叠前的清单摘要**（`buildConstraintManifest`）。记录 PIN 集合 + 每条约束的**稳定标识**：
   `sha256(kind + NUL + 归一化全文)` 前 10 位十六进制，其中 `kind` 由事实的固定前缀确定性判定
   （`[ACP <authority>]` / `[goal]` / `[user-pinned]`）。标识只依赖文本，跨折叠可比对，**不引入任何模型调用**。
2. **注入记账**（`pinner.planPinInstruction`）。PIN 有 1800 字符预算，超预算整条丢弃。
   旧实现只返回渲染文本，调用侧看不见截断——于是这些**从未发给模型**的事实也被拿去抽锚点、
   算进 `missed`。这不是小误差：它把**我们自己的截断记成了模型犯错**，命中率被系统性低估，
   而且排查方向从一开始就是错的。现在 `kept`/`omitted` 外露，审计里分成两个字段：
   `notInjectedFacts`（我们自己没发出去）与 `missed`/`lostIds`（发出去了、摘要没带）。
3. **折叠后的三态结论**（`verifyFoldConstraints`）。状态互斥，且刻意把三个「非丢失」情形摘出去：

   | status | 含义 | 是否告警 |
   |---|---|---|
   | `ok` | 全部可校验锚点都在（V/V） | 否 |
   | `partial` | 部分丢失（0 < hits < checked），`lostIds` 列出丢了哪些约束 | 否（只入审计） |
   | `lost` | 完全丢失（hits = 0 且 checked > 0） | **warn** |
   | `unverifiable` | 注入了但一条字面锚点都抽不出——「没得验」≠「验过了没丢」 | 否 |
   | `not-injected` | 一条都没注入（未启用 / 预算全截断 / 收集路径断开）——**路径问题，不是模型丢的** | **warn** |
   | `no-summary` | 摘要正文为空，无从校验（不冒充 lost，避免假警报） | 否 |
   | `idle` | 清单为空，无约束可校验——不制造噪声 | 否 |

   `partial` 只入审计不 warn 是刻意的：本机实测 partial 占比过半（§9.7），每次 fold 都告警会变成噪声墙，
   结果就是没人再看告警。**只对两个硬信号开口**：完全丢失、从未注入。

### 边界（诚实声明 —— 铁律 2）

**未接线：折叠后 session surface 侧的比对。** 不是省事，是**观测点在时序上不成立**。
官方 `dsh-compaction-basic` 的 `commitCompactionBody` 先 `session.append('compaction/summary', …)`
（`lib/index.js:589`），**其后**才 append 携带 `surfaceOp: { op: 'replace', start, end }` 的 checkpoint 消息
（`:605`）；而 maid 的 `summarize` 钩子由 `summarizeCompaction`（`:550`）调用，在两者**之前**。
此刻读 `session.surface` 拿到的是**折叠前**的节点集合——任何「约束仍在折叠后上下文里」的判定都会返回
「在」，也就是**假绿**。这种检查比不检查更糟：它会给出一个稳定漂亮的 100%，把真实丢失掩盖掉。
故只对**摘要正文**（真正替换被压区间的那段文本）做字面锚点比对，并把这个限制写进 README 与 AGENTS.md。

### 默认只告警不阻塞

校验结论**不改写任何折叠行为**。`fold.verify.enabled`（maid 自持点号键，默认 true）置 false 时
不校验、不留痕，折叠路径不变。本仓**刻意不提供**「校验失败即阻断折叠」的开关：软保护本就不可靠，
把校验变成硬门只会制造一个新的失败面（折叠被卡住）而不解决丢失。这与「审计 first」（铁律 4）一致——
先让丢失**可见**，再谈处置。

### 配置面（铁律 3）

`fold.verify.enabled` 是 maid 自持键，**不进 `toOfficialConfig`**（官方 `validateKeys` 拒未知键）。
`test/fold-verify.test.mjs` 里有一条测试直接钉住这一点，同时确保阈值语义没有被顺手改动
（`trigger.userRatio` → `thresholdRatio`、`fold.retainRatio` → `retainRatio` 映射不变）。

---
## 9.9 压缩迟滞（C3）与模型切换留痕（C6②）（2026-10-05）

### 为什么
控制论体检（weaver `project/wv-20260907-110` §七）列了十条，maid 侧占两条：
- **C3 压缩触发加迟滞带与冷却（防横跳）**：压缩触发 = 静态阈值阶跃，接近阈值时每轮判定可能反复触发/反复跳过；FOLD 有「1 次/turn + 日上限」节流，但**没有「触发-恢复」迟滞**。
- **C6② provider 切换基线快照**：最大扰动（模型升级 / 换 provider / 摘要模型质量漂移）此前**无观测、无回流**——每次摘要只写一行 logger，日志一滚就没了。

### C3 怎么做的
新增 `trigger.cooldownMs`（schema，默认 **0**）：距上次**成功压缩**不足该毫秒数的 `pressure` 触发被静默跳过，并在 maid-trace 留一行 `skip (C3 cooldown …)`。
- **代码与行为分离**：代码默认 0 → 不启用时行为与改动前**逐字一致**；启用与否交给配置那一行。两者能分开回滚。
- **context-overflow 永远豁免** —— 那是硬约束，跳过会把 turn 撑崩，宁可多压一次。
- **只在真压了才计时**：`super.compactIfNeeded` 返回 null（未达阈值）不占用冷却窗口。
- 本机取 **300000（5 分钟）**。依据：一次 FOLD 实测压掉约 10 万 token（shadowedTokens），压完 retainRatio 0.16，按当前证据增速涨回 thresholdRatio 0.40 约需一小时 —— 5 分钟只挡「刚压完又被一次大输出顶上阈值」的抖动，不误伤正常节奏。

### C6② 怎么做的
`_trackModelSwitch()`：在 `summarize()` 解析出 `{provider, model}` 后比对上一次的值，变了就落一条 `op=model-switch` 审计（detail 带 from/to/时刻/totalTokens）。同一个模型只落一次。

### 边界（诚实声明 —— 铁律 2）
C6② **没有做到原文要求的全部**。原文要的基线是「tool 调用分布 / 纠错次数 / 注入占用均值」，那些分散在别的插件里，maid 取不到，**也不该跨插件去抓**。此处只落 maid 自己能测的那部分 —— 切换时刻 + 当时的上下文体量。够回答「什么时候换的、换的瞬间上下文多大」，**不够做完整的 A/B**。缺口写在这里，别当成已经做到了。

## 10. 参考

- 本地：dsh-compaction-survey.md §5 扩展点 / §6 缺口 / §7 接口面
- 业界：context-mgmt-survey.md §3 洞察（1/2/3/4/5/7/8 直接对应本设计）
- 官方源码：packages/compaction/{compaction,compaction-basic,compaction-tool-result-pruner,command-compact}
- 我们的资产：ACP ledger/authority、consolidation 管道（刚修复）、work-continuity（P1-5/P1-6）、weaver
