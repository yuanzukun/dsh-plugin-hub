// test/audit-stats.test.mjs —— MAID-B17（2026-10-04 审计）
//
// 守护的 issue：audit.stats() 原写法 SUM(tokens_before - tokens_after) 对 fold **恒 NULL**。
// 三道坎叠在一起：① tokens_after 是设计上留空的（折叠完成时"折后实测"还不存在）；
// ② NULL 参与减法仍是 NULL；③ SUM 忽略 NULL。于是 93 次 fold 的节省量被一条 SQL 全部吞掉，
// /context-maid status 从上线起就没报过 fold 省了多少。
//
// 本文件两条测试：一条验新口径（回退到 detail.shadowedTokens），一条**守护旧口径仍然是 NULL**
// —— 后者不是测"功能"，是测"差异真实存在"，防止有人把回退逻辑顺手删了还以为没影响。

import { test } from 'node:test'
import assert from 'node:assert/strict'
import { mkdtempSync, rmSync } from 'node:fs'
import { tmpdir } from 'node:os'
import path from 'node:path'
import openMaidAudit from '../src/audit.mjs'

function withAudit(fn) {
  const dir = mkdtempSync(path.join(tmpdir(), 'maid-audit-b17-'))
  const audit = openMaidAudit(dir)
  try { return fn(audit) } finally { audit.close(); rmSync(dir, { recursive: true, force: true }) }
}

function seed(audit) {
  // fold：tokens_after 留空（设计如此），detail 里带 shadowedTokens
  audit.append({
    op: 'fold', sessionId: 's1', range: '8:995', tokensBefore: 236084,
    summary: 'compaction/summary → ACP ev_x（foldDepth 1）',
    detail: JSON.stringify({ shadowedTokens: 236084, foldDepth: 1 }),
  })
  // slim：before/after 都有（可原地量出）
  audit.append({ op: 'slim', sessionId: 's1', tokensBefore: 30166, tokensAfter: 1639, summary: 'eventSlim', unit: 'chars' })
  // pin：两个都没有 —— 应当显式计入 savedNull，而不是静默当 0
  audit.append({ op: 'pin', sessionId: 's1', summary: '折叠后约束校验：lost' })
}

test('MAID-B17：fold 的 saved 回退到 detail.shadowedTokens', () => {
  withAudit((audit) => {
    seed(audit)
    const st = audit.stats(7)
    const fold = st.find((s) => s.op === 'fold')
    const slim = st.find((s) => s.op === 'slim')
    const pin = st.find((s) => s.op === 'pin')

    assert.ok(fold, 'fold 行必须出现在 stats 里')
    assert.equal(fold.saved, 236084, 'fold 的 saved 应当回退到 shadowedTokens（旧写法此处恒 NULL）')
    assert.equal(fold.savedFromShadowed, 1, '应当记下这一条是从 shadowedTokens 回退来的')

    assert.equal(slim.saved, 30166 - 1639, 'slim 仍走 before - after 的差值口径')
    assert.equal(slim.savedFromShadowed, 0)

    assert.equal(pin.saved, null, '两个数都没有时不编造节省量')
    assert.equal(pin.savedNull, 1, 'savedNull 要显式暴露，不能静默当 0')
  })
})

test('MAID-B17 回归守护：旧口径对 fold 仍然是 NULL（差异真实存在）', () => {
  withAudit((audit) => {
    seed(audit)
    const old = audit.db
      .prepare('SELECT op, SUM(tokens_before - tokens_after) saved FROM maid_audit WHERE ts >= ? GROUP BY op')
      .all(0)
    const oldFold = old.find((r) => r.op === 'fold')
    const oldSlim = old.find((r) => r.op === 'slim')

    assert.equal(oldFold.saved, null, '旧 SQL 对 fold 恒 NULL —— 这正是被修掉的那条病')
    assert.equal(oldSlim.saved, 30166 - 1639, '对照：slim 在旧口径下本来就是好的')
  })
})

test('MAID-B17：返回形状只增不删（commands.mjs status 依赖 op/n/saved）', () => {
  withAudit((audit) => {
    seed(audit)
    for (const row of audit.stats(7)) {
      assert.equal(typeof row.op, 'string')
      assert.equal(typeof row.n, 'number')
      assert.ok('saved' in row, 'saved 字段必须存在（哪怕是 null）')
    }
  })
})
