// test/archiver-budget.test.mjs —— MAID-B18（2026-10-04 审计）
//
// 守护的 issue：摘要入 ACP 的预算原是 text.slice(0, 1800)，注释称「ACP 上限 8000」——
// 两半都站不住：① 8000 找不到依据（DB 无 CHECK、dsh-acp/lib/index.js 无长度校验）；
// ② 1800 装不下官方指令强制的 8 个 section，被砍的恰好是后半，
//    而 PIN 约束所在的 Critical Context **在最后一个** ⇒ 折叠后约束校验报 partial/lost 的结构性下限。
//
// 本文件测三件：常量值、保头保尾的截断行为、以及「旧写法确实会丢尾部」的回归守护。

import { test } from 'node:test'
import assert from 'node:assert/strict'
import { SUMMARY_BUDGET_CHARS, budgetSummary } from '../src/archiver.mjs'

const SECTIONS = [
  'Primary Request and Intent',
  'Key Technical Concepts',
  'Files and Code',
  'Errors and Fixes',
  'Pending Jobs',
  'Current Work',
  'Next Step',
  'Critical Context',
]

function fakeSummary(bodyLen = 0) {
  return SECTIONS.map((s, i) => '## ' + s + '\n- ' + (i === 7 ? '约束：绝不能丢这条' : 'x'.repeat(Math.ceil(bodyLen / 8)))).join('\n')
}

test('MAID-B18：预算是实证值 4000（依据写在同一处的注释里）', () => {
  assert.equal(SUMMARY_BUDGET_CHARS, 4000, '改动这个数要同步改注释里的实证依据')
})

test('MAID-B18：不超预算时原样返回（零改动）', () => {
  const s = 'short summary'
  assert.equal(budgetSummary(s), s)
  assert.equal(budgetSummary(''), '')
  assert.equal(budgetSummary(null), '', 'null 不能抛')
  assert.equal(budgetSummary(undefined), '')
})

test('MAID-B18：超预算时**保头保尾** —— 尾部（Critical Context）绝不能先丢', () => {
  const text = fakeSummary(20000)   // 远超预算
  const out = budgetSummary(text, 1000)

  assert.ok(out.length <= 1000 + 60, '长度要受控（截断标记本身占几十字符）')
  assert.ok(out.includes('## Primary Request and Intent'), '头部保留')
  assert.ok(out.includes('## Critical Context'), '**尾部必须保留** —— 约束在那儿')
  assert.ok(out.includes('绝不能丢这条'), '尾部那一节的具体内容也要在')
  assert.ok(out.includes('被截'), '要显式标出中段被截，不能假装完整')
})

test('MAID-B18 回归守护：旧写法 slice(0, N) 会连约束一起丢（差异真实存在）', () => {
  const text = fakeSummary(20000)
  const oldWay = text.slice(0, 1800)          // 被修掉的旧口径
  const newWay = budgetSummary(text)

  assert.ok(!oldWay.includes('## Critical Context'), '旧写法把约束所在的那一节**完整丢掉** —— 这正是被修掉的病')
  assert.ok(newWay.includes('## Critical Context'), '新写法保住了它')
})

test('MAID-B18：8 个 section 在 4000 预算下能装下（这是改预算的目的）', () => {
  // 造一份「每节都简短」的摘要 —— 这才是正常摘要的形状
  const realistic = SECTIONS.map((s) => '## ' + s + '\n- 一两行要点').join('\n')
  assert.ok(realistic.length < SUMMARY_BUDGET_CHARS, '正常长度的 8 节摘要不该被截')
  assert.equal(budgetSummary(realistic), realistic, '不该动它')
})
