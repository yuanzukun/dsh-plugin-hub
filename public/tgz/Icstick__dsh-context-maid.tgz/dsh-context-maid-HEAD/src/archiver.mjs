// src/archiver.mjs — 先归档后压缩：消费 compaction/summary 事件，把摘要写入 ACP ledger。
//
// 设计（docs/dsh-context-maid-design.md §5.5）：
//  - 摘要即证据：每次 FOLD 的 checkpoint 摘要成为 ledger 一条 observation
//    （subject=session 标识，text=摘要，evidenceIds=被压段证据 id，supersedes 链关联）
//  - 与引擎解耦：监听 session/event 的 compaction/summary（旁路模式同样工作）
//  - ACP 为可选服务：不在线自动跳过（maid 不制造硬依赖）
//
// 2026-09-03 实测修复（live 验证：/compact 成功但 maid_audit 0 行）：
//  - audit-first：事件到达即无条件写 audit（detail 记录归档结果/跳过原因），
//    审计不再依赖 ACP 在线——可区分「事件未达」与「归档路径断开」。
//  - acp 解析多路：ctx.get('acp') → ctx.acp（cordis provide 属性访问）兜底。
// 2026-09-03 二次实测（audit 落行但 archive_ids 空，detail=「acp.append 未返回 id」）：
//  - 根因一：ACP writeGuard secret 扫描 block——摘要正文含「token: 5a8cda…」等
//    疑似凭据格式（checkpoint 摘要保留命令/配置值，易命中）。ACP 安全功能正确，
//    归档侧适配：预脱敏（REDACT_PATTERNS 与 ACP governance.mjs SECRET_PATTERNS 同步），
//    block 后自动脱敏重试一次；detail 记录 append 的 decision/reasons（可观测）。
// 2026-09-03 三次实测（脱敏起效、越过 writeGuard 后暴露）：
//  - 根因二：sensitivity: 'internal' 不在 ACP 合法枚举
//    （public|private|sensitive|secret，store assertChoice 契约）——此前一直被
//    secret block 挡在 store 之前，未暴露。改为 'private'（归档摘要含会话内容，
//    按 ACP 默认 user 消息同级敏感度处理）。
//
// 注意：原始被压内容已在 ACP ledger（ACP 并行摄入全部会话事件）——
// 这里补的是「摘要级」沉淀。
//
// 2026-10-05 实测：这条「回流」路径**当前读不回来**。三道门——①②两机都关着，③按机而异：
//   ① ingest 闸门：本调用未声明 input.ingest，而 TRUSTED_INGEST 只认 session-event /
//      user-correction，故一律落 quarantined（C 机实测 archive_ids 18/18 全隔离）；
//   ② 形态：这里写的是 evidence，而 PIN 那一端读的是 observation 轨——两条不同的轨；
//   ③ 注入：observationInjection 默认 false（2026-09-02 冻结）；W 机 profile 里为 true，
//      所以这一道在 W 机是开着的——但①②仍关着，结论不变。
// 而且即便三门全开也进不去：ledger.query 是 ORDER BY observed_at DESC LIMIT 20，
// 旧摘要按时间序早已沉底。
// 摘要本身**人可查**（acp_query 带 state:all 可见 quarantined），只是不自动注入。
// 完整分析：ops/maid-archive-route-plan.md（C 机）。

/**
 * 从 compaction/summary 事件提取摘要文本。
 * @param {object} event - session/event 的 compaction/summary
 * @returns {string} 摘要文本（内容块拼接）
 */
export function summaryTextOf(event) {
  try {
    const summary = event?.data?.summary
    if (typeof summary === 'string') {
      try {
        const parsed = JSON.parse(summary)
        if (Array.isArray(parsed)) {
          return parsed.filter((b) => b?.type === 'text').map((b) => b.text).join('\n')
        }
        return summary
      } catch { return summary }
    }
    if (Array.isArray(summary)) {
      return summary.filter((b) => b?.type === 'text').map((b) => b.text).join('\n')
    }
    return ''
  } catch { return '' }
}

/**
 * 摘要预脱敏（归档内容消毒）。
 * 与 ACP governance.mjs SECRET_PATTERNS 同步维护（2026-09-03）：
 * ACP writeGuard 对疑似凭据 block——压缩摘要保留命令/配置值易命中（如
 * 「frp token: 5a8cda…」），整条被拒会丢失归档。这里把值打码后再 append。
 * 注意：若 ACP 侧 pattern 更新，此处需跟随（双保险：block 后还会重试一次）。
 * @param {string} text
 * @returns {string} 脱敏后文本
 */
export function redactSecrets(text) {
  if (typeof text !== 'string' || !text) return text
  let out = text
  // 键值对：保留 key 名，打码值（≥12 字符疑似凭据）
  out = out.replace(/\b((?:sk|pk|api[_-]?key|token|secret|password|passwd|pwd|credential|bearer|private[_-]?key|access[_-]?key)\b\s*[:=]\s*['"]?)[A-Za-z0-9_-]{12,}/gi, '$1[redacted]')
  // 高熵 token 形态整体打码
  out = out.replace(/\bghp_[A-Za-z0-9]{20,}\b/g, '[redacted]')          // GitHub PAT
  out = out.replace(/\bgho_\w{20,}\b/g, '[redacted]')
  out = out.replace(/\bxox[baprs]-[A-Za-z0-9-]{20,}\b/g, '[redacted]')   // Slack token
  out = out.replace(/\bAKIA[0-9A-Z]{16}\b/g, '[redacted]')               // AWS access key
  out = out.replace(/\beyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\b/g, '[redacted]') // JWT
  out = out.replace(/-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----/g, '[redacted]')
  return out
}

/**
 * 尝试把摘要写入 ACP；block（疑似凭据）时脱敏重试一次。
 * @param {object} acp - ACP service
 * @param {string} content - 待归档 content（已截断到预算内）
 * @param {object} sourceRef - { sessionEventId, maidCompactionId }
 * @param {string} seq - 事件 seq
 * @returns {{archiveIds: string[], note: string}}
 */
function appendArchive(acp, content, sourceRef) {
  const base = {
    sourceClass: 'agent_authored',
    authority: 'single_observation',
    confidence: 0.6,
    durability: 0.5,
    sensitivity: 'private', // ACP SENSITIVITIES 契约值（public|private|sensitive|secret）
    claimDomain: 'experience',
    sourceRef,
  }
  const attempt = (body) => acp.append({ ...base, content: body })
  let result = attempt(content)
  const verdictNote = (r) => {
    const parts = []
    if (r && r.decision) parts.push('decision=' + r.decision)
    if (r && Array.isArray(r.reasons) && r.reasons.length) parts.push('reasons=[' + r.reasons.join('; ') + ']')
    return parts.length ? '（' + parts.join(' ') + '）' : ''
  }
  if (result && result.id) {
    return { archiveIds: [result.id], note: '已归档 ' + result.id + verdictNote(result) }
  }
  // block / 异常返回 → 脱敏重试一次
  if (!(result && result.id)) {
    const sanitized = redactSecrets(content)
    if (sanitized !== content) {
      result = attempt(sanitized)
      if (result && result.id) {
        return { archiveIds: [result.id], note: '已归档 ' + result.id + '（内容含疑似凭据，已脱敏重试）' }
      }
    }
  }
  return {
    archiveIds: [],
    note: 'acp.append 未返回 id' + verdictNote(result)
      + (result && result.decision === 'block' ? '（block 含疑似凭据且脱敏后仍被拒）' : ''),
  }
}

/**
 * 解析 ACP service：多路兜底（ctx.get → ctx.acp）。
 * cordis 下 ctx.provide('acp', …) 注册的 service 可经 ctx.get('acp') 获取；
 * 部分宿主/上下文层级下 ctx.get 解析不到时，属性访问 ctx.acp 仍可命中。
 * @param {object} ctx
 * @returns {object|undefined} acp service（含 append 方法）或 undefined
 */
export function getAcpService(ctx) {
  if (!ctx) return undefined
  try {
    const viaGet = typeof ctx.get === 'function' ? ctx.get('acp') : undefined
    if (viaGet && typeof viaGet.append === 'function') return viaGet
  } catch { /* 继续下一路 */ }
  try {
    if (ctx.acp && typeof ctx.acp.append === 'function') return ctx.acp
  } catch { /* 继续 */ }
  return undefined
}

/**
 * 注册 archiver：session/event 上消费 compaction/summary → ACP ledger + 审计。
 * audit-first：事件到达即写审计（无论 ACP 是否在线/摘要是否为空），
 * detail 字段记录归档结果或跳过原因——保证策展可观测。
 * fail-open：任何异常只 warn，不阻断事件派发。
 * @param {object} ctx - cordis Context
 * @param {object} opts - { enabled, audit }
 */
// MAID-B14（2026-09-21）：FOLD 递归深度记账。
//
// 为什么必须记：深度是「这个会话还要不要继续」的唯一判据，而现在只能靠
// `count(op=fold) group by session_id` 反推（实测有会话折了 17 轮、另一个 6.7 分钟折 8 轮）。
//
// 为什么不用 WeakMap 按 session **对象**计数（原设计稿的写法）：对象身份在事件派发之间
// 没有任何保证——一旦宿主每次派发都换包装对象，WeakMap 会恒返回 0，深度永远写 1 而且
// **静默无声**。改用 session.id 字符串做键；单机会话数有界，增长可忽略。
// 进程重启后从审计库播种（表里已有历史 fold 行），不从 1 重来。
const foldDepthBySession = new Map()
const foldDepthSeeded = new Set()

/**
 * 取本会话的下一次折叠深度（1 起）。首次遇到该会话时从审计库播种。
 * @param {{id?: string}} session
 * @param {{recent?: (n: number) => Array<object>}} [audit]
 * @returns {number}
 */
export function nextFoldDepth(session, audit) {
  const id = String(session?.id ?? '')
  if (!id) return 1
  if (!foldDepthSeeded.has(id)) {
    foldDepthSeeded.add(id)
    let rows = 0
    let maxDepth = 0
    try {
      const recent = typeof audit?.recent === 'function' ? audit.recent(500) : []
      for (const r of recent) {
        if (!r || r.op !== 'fold' || String(r.sessionId ?? '') !== id) continue
        rows += 1
        const m = /"foldDepth"\s*:\s*(\d+)/.exec(String(r.detail ?? ''))
        if (m) maxDepth = Math.max(maxDepth, Number(m[1]))
      }
    } catch { /* 播种失败就从 1 开始，不阻断 */ }
    foldDepthBySession.set(id, Math.max(rows, maxDepth))
  }
  const next = (foldDepthBySession.get(id) ?? 0) + 1
  foldDepthBySession.set(id, next)
  return next
}

// MAID-B18（2026-10-04 审计）：摘要入 ACP 的字符预算。
//
// 原值 1800，注释写「observation text 预算（ACP 上限 8000）」—— 这句话**两半都站不住**：
//   · 「上限 8000」找不到依据：acp-ledger.db 的 evidence 表对 content 只有 TEXT NOT NULL、
//     **无 CHECK/长度约束**；dsh-acp/lib/index.js（唯一的实现文件，55KB）里也搜不到任何
//     content 长度校验。**注释不等于事实。**
//   · 1800 太短：官方摘要指令强制要求 **8 个 section**（never drop a section），而 1800 字符
//     装不下 —— 被砍的恰好是后半：Pending Jobs / Current Work / Next Step / **Critical Context**。
//     而 PIN 约束就在 Critical Context ⇒ 这是折叠后约束校验报 partial/lost 的**结构性下限**。
//     实测：103 条 maid 归档里 97 条 ≤1811（= 1800 + 前缀 11 字符）。
//
// 新值 4000 的依据（**实证，不是注释**）：acp-ledger.db 全表 content 最长 **4024 字符**，
// 且有一批恰好 4024 的条目 ⇒ ACP 至少能装 4024。取 4000 留出前缀余量。
// 若将来 ACP 侧真加了上限，appendArchive 的失败会走 note 回传（audit-first 不受影响）。
export const SUMMARY_BUDGET_CHARS = 4000

/** 按预算截断摘要文本。抽成函数是为了可测（见 test/archiver-budget.test.mjs）。 */
export function budgetSummary(text, limit = SUMMARY_BUDGET_CHARS) {
  const s = String(text ?? '')
  if (s.length <= limit) return s
  // 真到了必须截的那天：**保头保尾** —— 尾部是 Critical Context，约束在那儿，绝不能先丢。
  const head = Math.floor(limit * 0.7)
  const tail = limit - head
  return s.slice(0, head) + '\n…[中段 ' + (s.length - limit) + ' 字符被截]…\n' + s.slice(-tail)
}

export function registerArchiver(ctx, opts = {}) {
  const enabled = opts.enabled !== false
  ctx.on('session/event', (session, event) => {
    try {
      if (!enabled) return
      if (!event || event.type !== 'compaction/summary') return
      const data = event.data ?? {}
      const text = summaryTextOf(event)
      const acp = getAcpService(ctx)

      let archiveIds = []
      let note = ''
      if (!acp) {
        note = 'acp 不可用（ctx.get/ctx.acp 均未解析到 append）→ 跳过归档'
      } else if (!text) {
        note = 'summary 文本为空 → 跳过归档'
      } else {
        try {
          const summary = budgetSummary(text) // MAID-B18：预算与依据见文件内 SUMMARY_BUDGET_CHARS
          const out = appendArchive(acp, '【maid 压缩归档】' + summary, {
            sessionEventId: String(event.seq ?? ''),
            maidCompactionId: String(data.compactionId ?? ''),
          })
          archiveIds = out.archiveIds
          note = out.note
        } catch (err) {
          note = 'acp.append 失败: ' + (err instanceof Error ? err.message : String(err))
        }
      }
      // audit-first：无条件留痕（审计失败不阻断策展）
      const foldDepth = nextFoldDepth(session, opts.audit)
      try {
        opts.audit?.append?.({
          op: 'fold',
          sessionId: session?.id ?? '',
          range: data.shadowedRange ? data.shadowedRange.start + ':' + data.shadowedRange.end : '',
          // 口径 = 宿主 token-meter 的固定启发价（estTokens）；不得与 chars 口径混算。
          unit: 'estTokens',
          producer: 'dsh-context-maid',
          tokensBefore: data.shadowedTokenCount,
          archiveIds,
          summary: 'compaction/summary → ' + (archiveIds.length > 0 ? 'ACP ' + archiveIds[0] : note)
            + '（foldDepth ' + foldDepth + '）',
          // detail 改成 JSON：foldDepth 必须是可读字段，不能只靠 summary 里的一句话。
          // note 保留在 JSON 内，既有测试（/acp 不可用/、/脱敏/）继续成立。
          detail: JSON.stringify({
            note,
            foldDepth,
            compactionId: String(data.compactionId ?? ''),
            shadowedTokens: data.shadowedTokenCount ?? null,
          }),
        })
      } catch { /* 审计失败不阻断 */ }
    } catch (err) {
      ctx.logger?.warn?.('[context-maid] archive_failed reason='
        + (err instanceof Error ? err.message : String(err)))
    }
  })
}

export default registerArchiver
