// src/engine.mjs — MaidCompactionEngine：继承官方引擎，阈值/保留/摘要模型映射。
//
// 关键机制（设计文档 §5.1/§9）：
//  - cordis Service 构造即注册 ctx.compaction——maid 作为 ctx.compaction 提供者时，
//    宿主必须 disable 官方 compaction-basic（同 key 只能一个提供者）
//  - 阈值可调 = 官方原生 thresholdRatio：把 maid 的 trigger.userRatio 映射过去，
//    官方 pressure/overflow/manual 触发全保留，无需自建 pre-step 触发
//  - summarize() 官方唯一子类钩子：M4 知识感知摘要在此覆写
//  - 钉扎（M3 spike）：范围排除需在覆写点做，见设计 §5.2

import { BasicCompactionEngine } from '@deepseek-ai/dsh-compaction-basic'
import { maidSummarizeWithLlm } from './maid-summarizer.mjs'
import { scanSweepCandidates } from './sweeper.mjs'
import { stubToolResultNode, getTokenMeter } from './slimmer.mjs'
import { buildConstraintManifest, verifyFoldConstraints } from './fold-verify.mjs'

/** 折叠后约束校验的状态标签（审计 summary 用；取值域见 fold-verify.FOLD_VERIFY_STATUSES）。 */
const FOLD_VERIFY_LABEL = {
  ok: 'ok（约束全部保留）',
  partial: 'partial（部分丢失）',
  lost: 'lost（完全丢失）',
  unverifiable: 'unverifiable（无字面锚点，无从校验）',
  'not-injected': 'not-injected（未注入，路径断开）',
  'no-summary': 'no-summary（摘要为空，无从校验）',
  idle: 'idle（无约束）',
}
import { appendFileSync, mkdirSync } from 'node:fs'
import path from 'node:path'

/**
 * 把 maid Config 映射为官方 BasicCompactionConfig 子集。
 * 未配置项不传（官方默认）；userRatio 是核心旋钮。
 * @param {object} maid - maid 原始 Config（含点号键）
 * @returns {object} 官方 config 子集
 */
export function toOfficialConfig(maid = {}) {
  const out = { auto: maid.enabled !== false }
  const ratio = Number(maid['trigger.userRatio'])
  if (Number.isFinite(ratio) && ratio > 0) out.thresholdRatio = ratio
  const retain = Number(maid['fold.retainRatio'])
  if (Number.isFinite(retain) && retain > 0) out.retainRatio = retain
  const sp = String(maid['summarization.provider'] ?? '').trim()
  const sm = String(maid['summarization.model'] ?? '').trim()
  if (sp && sm) {
    out.summarizationProvider = sp
    out.summarizationModel = sm
  }
  return out
}

/**
 * MaidCompactionEngine：官方引擎 + maid 映射。
 * 保留官方全部事务/锁/收缩校验/影子价格语义。
 */
export class MaidCompactionEngine extends BasicCompactionEngine {
  /**
   * @param {import('@deepseek-ai/cordis').Context} ctx
   * @param {object} maidConfig - maid Config（点号键全集）
   */
  constructor(ctx, maidConfig = {}) {
    super(ctx, toOfficialConfig(maidConfig))
    this.maidConfig = maidConfig
    this._slimProgress = new WeakMap()
    this._sweepState = new WeakMap()
    this._cleanupTicks = 0
    this._cleanupLastAt = null
    this._cleanupLastResult = null
    this._resolvers = []
    // C3（2026-10-05）：上次**成功压缩**的时刻（ms）。null = 本次进程内还没压过。
    this._lastCompactAt = null
    // C6②（2026-10-05）：上次用过的摘要模型（'provider/model'），用于切换留痕。
    this._lastModelKey = null
  }

  // 状态字段全部用构造期普通属性（_x 前缀）而非 JS private field——
  // 原因（2026-09-08 实测）：cordis-plugin-hmr/loader 原型替换下 private field 槽位
  // 与新类方法失配（"Cannot read private member #cleanupTicks"），普通属性存实例上不受影响。
  // M5 eventSlim 增量游标：session → 已处理到的最大 seq（WeakMap 随会话生命周期回收）
  // M6 sweep 节流：session → { turns, maxSeq }
  // 诊断：runPreCleanup 调用统计（status/slim-now 展示）

  /** M5 前置清理入口（eventSlim；M6 将在此加入 sweep）——在官方测压/折叠之前执行。
   *  设计稿 §3：model-free、无锁、幂等；失败只 warn 不阻断官方路径（fail-open）；
   *  无模型信息（resolveModelInfo 失败）时官方永不清理的缺口在此被补上。 */
  async runPreCleanup(agent) {
    const maid = this.maidConfig ?? {}
    const session = agent?.session
    if (!session) return { eventSlim: null, sweep: null }
    this._cleanupTicks += 1
    this._cleanupLastAt = Date.now()
    // ① eventSlim 增量瘦身（trigger.eventSlim，默认 true）
    let eventSlim = null
    if (maid['trigger.eventSlim'] !== false) {
      try {
        const pruner = typeof this.ctx?.get === 'function' ? this.ctx.get('toolResultPruner') : undefined
        if (pruner && typeof pruner.pruneSession === 'function') {
          const fromSeq = this._slimProgress.get(session) ?? -1
          if (typeof pruner.incrementalSlim === 'function') {
            eventSlim = pruner.incrementalSlim(session, fromSeq, (row) => this._auditRow(row, session))
          } else {
            // 官方 pruner（maid slimmer 未接管）→ 全量退化（官方语义幂等）
            const out = pruner.pruneSession(session)
            eventSlim = out
            if (Array.isArray(out?.pruned) && out.pruned.length > 0) {
              this._auditRow({
                op: 'slim',
                unit: 'chars',
                producer: 'dsh-context-maid',
                summary: 'eventSlim（官方 pruner 全量退化）：' + out.pruned.length + ' 节点瘦身',
                detail: JSON.stringify({ kind: 'event-slim-fallback', pruned: out.pruned.length }),
              }, session)
            }
          }
          // 推进游标到当前 surface 最大 seq
          const nodes = session.surface?.nodes
          if (Array.isArray(nodes) && nodes.length > 0) {
            const maxSeq = Math.max(nodes[nodes.length - 1], eventSlim?.maxSeen ?? -1)
            this._slimProgress.set(session, maxSeq)
          }
        }
      } catch (err) {
        const msg = (err instanceof Error ? err.message : String(err))
        this.ctx?.logger?.warn?.('[context-maid] eventSlim failed: ' + msg + '——继续官方路径')
        eventSlim = { error: msg } // 暴露给 slim-now/status 诊断（fail-open 语义不变）
      }
    }
    // ② sweep 清扫（sweep.enabled，默认 false；M6）
    let sweep = null
    if (maid['sweep.enabled'] === true) {
      try {
        const state = this._sweepState.get(session) ?? { turns: 0, maxSeq: -1 }
        state.turns += 1
        const nodes = session.surface?.nodes
        const maxSeq = Array.isArray(nodes) && nodes.length > 0 ? nodes[nodes.length - 1] : -1
        const grown = maxSeq - state.maxSeq
        // 节流：距上次 ≥12 step 或 surface 新增 ≥8 节点才全量扫描（O(surface) 控制在低频）
        if (state.maxSeq < 0 || state.turns >= 12 || grown >= 8) {
          state.turns = 0
          // aggressive 规则未扩展（v1：保守档 superseded-read/failed-retry）；开关保留待后续
          const candidates = scanSweepCandidates(session)
          let swept = 0
          let charsRemoved = 0
          for (const c of candidates) {
            try {
              const out = stubToolResultNode(session, c.seq, c.kind, c.reason, {
                meter: getTokenMeter(this.ctx),
                onRow: (row) => this._auditRow({ ...row, sessionId: session?.id ?? '' }, session),
              })
              if (out) {
                swept += 1
                charsRemoved += out.charsBefore
              }
            } catch (err) {
              this.ctx?.logger?.warn?.('[context-maid] sweep stub failed on seq ' + c.seq + ': '
                + (err instanceof Error ? err.message : String(err)))
            }
          }
          state.maxSeq = maxSeq
          sweep = { candidates: candidates.length, swept, charsRemoved }
        }
        this._sweepState.set(session, state)
      } catch (err) {
        const msg = (err instanceof Error ? err.message : String(err))
        this.ctx?.logger?.warn?.('[context-maid] sweep failed: ' + msg + '——继续官方路径')
        sweep = { error: msg }
      }
    }
    const out = { eventSlim, sweep }
    this._cleanupLastResult = out
    return out
  }

  /** 审计落行（audit 由 index.apply 装配在 engine.maidAudit；审计失败不阻断） */
  _auditRow(row, session) {
    try {
      this.maidAudit?.append?.({ ...row, sessionId: session?.id ?? '' })
    } catch { /* 审计失败不阻断策展 */ }
  }

  /** 诊断落盘（仅 debug=true）：<auditDir>/maid-trace.log。任何失败都不阻断。 */
  _trace(line) {
    if (this.maidConfig?.debug !== true) return
    try {
      const dir = this.maidAuditDir
      if (!dir) return
      mkdirSync(dir, { recursive: true })
      appendFileSync(path.join(dir, 'maid-trace.log'), new Date().toISOString() + ' ' + line + '\n')
    } catch { /* 诊断失败不阻断 */ }
  }

  /** 压力路径探针（仅 debug=true，节流 60s）：单独验证注入绑定与计量值。 */
  _probePressure(agent, trigger) {
    if (this.maidConfig?.debug !== true || trigger !== 'pressure') return
    const now = Date.now()
    if (this._probeLastAt !== undefined && now - this._probeLastAt < 60000) return
    this._probeLastAt = now
    try {
      const meter = this.ctx.tokenMeter // 属性访问 = 注入代理是否绑定
      const m = meter.measure(agent.session)
      this._trace('probe: tokenMeter=ok totalTokens=' + m.totalTokens + ' session=' + (agent?.session?.id ?? ''))
    } catch (err) {
      this._trace('probe: tokenMeter THREW: ' + (err?.message ?? err))
    }
    try {
      this._trace('probe: llm=' + (this.ctx.llm ? 'ok' : 'missing'))
    } catch (err) {
      this._trace('probe: llm THREW: ' + (err?.message ?? err))
    }
  }

  /**
   * M3+M4：覆写官方唯一子类钩子——PIN 注入 + 智能路由摘要。
   * 目标解析链：
   *   1. 注册的 resolver（外部智能路由插件 registerSummarizationResolver 接入；
   *      可返回 null/undefined 表示不决策，继续下一环）
   *   2. maid Config 显式 summarization.provider/model（用户配便宜/本地模型）
   *   3. 官方回落（最近路由对话模型）→ super.summarize
   * PIN 事实注入在 1/2 路径同样生效（消息末尾追加 pin user message）。
   * @param {object} input - SummarizationInput { system?, tools?, messages }
   * @param {object} agent - Agent
   * @param {AbortSignal} [signal]
   */
  async summarize(input, agent, signal) {
    const maid = this.maidConfig ?? {}
    // PIN 事实收集（两种路径共用）
    let pinMessage = null
    let pinFacts = []
    let pinPlan = null
    try {
      if (maid['pin.enabled'] !== false) {
        const { collectPinnedFacts, planPinInstruction, pinPluginMessage } = await import('./pinner.mjs')
        const cwd = agent?.session?.cwd ?? ''
        const facts = await collectPinnedFacts(this.ctx, {
          scopeId: 'user-global',
          cwd,
          extra: Array.isArray(maid['pin.extra']) ? maid['pin.extra'] : [],
        })
        pinFacts = Array.isArray(facts) ? facts : []
        // 2026-09-25：PIN 预算截断掉的事实**从未发给模型**——把注入记账留在手边，
        // 否则校验阶段会把「我们自己没发出去」算成「模型丢了」。
        const plan = planPinInstruction(pinFacts)
        pinPlan = { injected: plan.kept, omitted: plan.omitted, budget: plan.budget }
        if (plan.text) {
          pinMessage = pinPluginMessage(plan.text)
        }
      }
    } catch (err) {
      this.ctx.logger?.warn?.('[context-maid] pin collect failed: ' + (err instanceof Error ? err.message : String(err)))
    }
    const messages = pinMessage ? [...(input?.messages ?? []), pinMessage] : input?.messages

    // —— M4 智能路由目标解析 ——
    try {
      const defaultTarget = { provider: String(maid['summarization.provider'] ?? ''), model: String(maid['summarization.model'] ?? '') }
      const resolved = await this.resolveSummarizationTarget(agent, defaultTarget)
      if (resolved && resolved.provider && resolved.model) {
        // C6②：落模型切换留痕（同一个模型只落一次）
        this._trackModelSwitch(resolved, agent)
        const result = await maidSummarizeWithLlm(this.ctx, { ...resolved, maxTokens: maid.summarizationMaxTokens ?? 8192 }, { ...input, messages }, agent, signal)
        // 审计：路由决策
        try {
          this.ctx.logger?.info?.('[context-maid] summarize routed to ' + resolved.provider + '/' + resolved.model)
        } catch { /* ignore */ }
        this._verifyPinAnchors(pinFacts, result, agent, pinPlan)
        return result
      }
    } catch (err) {
      this.ctx.logger?.warn?.('[context-maid] maid summarize failed, fallback to official: '
        + (err instanceof Error ? err.message : String(err)))
    }
    // 回落：官方路径（maid 显式配置经 toOfficialConfig 已映射 summarizationProvider/Model）
    const fallbackResult = await super.summarize({ ...input, messages }, agent, signal)
    this._verifyPinAnchors(pinFacts, fallbackResult, agent, pinPlan)
    return fallbackResult
  }

  /**
   * C6②（2026-10-05）：摘要模型的切换留痕与基线快照。
   *
   * 动因（C6 原文）：「最大扰动（模型升级/换 provider/摘要模型质量漂移）无观测、无回流」。
   * 此前 maid 每次摘要只写一行 logger（summarize routed to X/Y）——日志一滚就没了，
   * 换了模型之后想回头对齐「换之前的表现」无从下手。这里把切换落成审计行。
   *
   * 边界（诚实声明）：C6 原文要的完整基线是「tool 调用分布 / 纠错次数 / 注入占用均值」，
   * 那些分散在别的插件，maid 取不到，也不该跨插件去抓。此处只落 maid 自己能测的那部分——
   * 切换时刻 + 当时的上下文体量。够回答「什么时候换的、换的瞬间上下文多大」，
   * 不够做完整的 A/B。缺口写在这里，别当成已经做到了。
   * 纪律：fail-open——留痕失败绝不阻断摘要。
   */
  _trackModelSwitch(resolved, agent) {
    try {
      const key = String(resolved.provider) + '/' + String(resolved.model)
      if (this._lastModelKey === key) return
      const prev = this._lastModelKey
      this._lastModelKey = key
      let totalTokens = null
      try { totalTokens = this.ctx?.tokenMeter?.measure?.(agent?.session)?.totalTokens ?? null } catch { /* 测不到就留 null */ }
      this._auditRow({
        op: 'model-switch',
        unit: 'tokens',
        producer: 'dsh-context-maid',
        summary: (prev ? '摘要模型切换 ' + prev + ' → ' + key : '摘要模型基线 ' + key),
        detail: JSON.stringify({ kind: 'model-switch', from: prev || null, to: key, at: new Date().toISOString(), totalTokens }),
      }, agent?.session)
    } catch { /* fail-open */ }
  }

  /**
   * C6 v1（2026-09-09）+ 折叠后约束校验（2026-09-25）：PIN 事实有没有真的进摘要。
   *
   * 此前 PIN 只有「事前注入」这一半：摘要写完没有任何校验，丢没丢全靠猜。
   * 现在补上后半，且把结论做成**三态 + 注入记账**：
   *   - 折叠前的清单摘要：PIN 集合 + 每条约束的稳定标识（sha256，非 LLM）
   *   - 折叠后的可用性：ok / partial / lost / unverifiable / not-injected / no-summary
   *   - injectedFacts vs notInjectedFacts：区分「我们自己没发出去」与「模型丢了」
   * 结果落 audit op=pin（detail 带 status / lostIds / manifestIds），由 /context-maid status 展示。
   * 纪律：fail-open——任何异常只 warn，绝不阻断压缩；fold.verify.enabled=false 时不校验不落行。
   * 边界：只对摘要正文做字面锚点比对，**不读折叠后 session surface**——官方在 append
   * compaction/summary 之后才做 surface replace（compaction-basic lib/index.js:589→:605），
   * maid 的 summarize 钩子在其之前，此时 surface 仍是折叠前状态，读它只会假绿。
   * @param {string[]} facts - 收集到的 PIN 事实（原始文本，非渲染块）
   * @param {{summary?: Array<{type: string, text?: string}>}} result - summarize 返回
   * @param {object} agent
   * @param {{injected?: number, omitted?: number, budget?: number}} [plan] - planPinInstruction 的注入记账
   */
  _verifyPinAnchors(facts, result, agent, plan) {
    try {
      if (this.maidConfig?.['fold.verify.enabled'] === false) return
      const list = Array.isArray(facts) ? facts : []
      if (list.length === 0) return
      // 折叠前的清单摘要（确定性；注入记账来自 planPinInstruction，缺省视为全部注入）
      const injected = Number.isInteger(plan?.injected) ? plan.injected : list.length
      const manifest = buildConstraintManifest(list, { injected, budget: plan?.budget })
      const blocks = Array.isArray(result?.summary) ? result.summary : []
      const summaryText = blocks.map((b) => (b && typeof b.text === 'string' ? b.text : ''))
        .join(String.fromCharCode(10))
      const v = verifyFoldConstraints(manifest, summaryText)
      const checked = v.checked
      const pct = (x) => (x === null || x === undefined ? '—' : Math.round(x * 100) + '%')
      const verifiableRatio = manifest.injected > 0 ? manifest.verifiableFacts / manifest.injected : null
      // MAID-B12（2026-09-21）口径不能丢：可校验率与命中率必须同时出现，
      // 「没得验」不许被读成「验过了没丢」。
      const verifyText = '可校验 ' + manifest.verifiableFacts + '/' + manifest.injected
        + '（' + pct(verifiableRatio) + '）'
      const hitText = checked > 0
        ? '命中 ' + v.hits + '/' + checked + '（' + pct(v.ratio) + '）'
        : '命中 —（无可校验锚点）'
      // 只对两个硬信号告警（完全丢失 / 从未注入）。partial 只入审计——
      // 实测 partial 占比过半，每次 fold 都 warn 会变成噪声墙，反而没人看。
      if (v.status === 'lost') {
        this.ctx.logger?.warn?.('[context-maid] 折叠后约束完全丢失 0/' + checked + '：'
          + v.missed.join(', ') + '（本次摘要未携带任何可校验锚点）')
      } else if (v.status === 'not-injected') {
        this.ctx.logger?.warn?.('[context-maid] PIN 一条都没发出去（' + list.length
          + ' 条约束；PIN 预算 ' + (manifest.budget === null ? '—' : manifest.budget)
          + ' chars）——这是路径问题，不是模型丢失')
      }
      // audit 把 detail 截到 500 字符，而锚点/标识列表是变长的：
      // 超限会写出**半截 JSON**，而 /context-maid status 的分布正依赖它可解析（B12）。
      // 故先压长度再落盘；计数是独立标量字段，裁剪数组不影响口径。
      const pinDetail = {
        status: v.status,
        hits: v.hits,
        total: checked,
        checked,
        ratio: v.ratio,
        collectedFacts: list.length,
        injectedFacts: manifest.injected,
        notInjectedFacts: manifest.omitted,
        factsCount: list.length,
        verifiableFacts: manifest.verifiableFacts,
        verifiableRatio,
        budget: manifest.budget,
        manifestIdCount: manifest.idCount,
        manifestIds: manifest.ids.map((x) => x.id),
        anchors: manifest.anchors,
        missed: v.missed,
        lostIds: v.lostIds,
      }
      const shrinkKeys = ['anchors', 'missed', 'lostIds', 'manifestIds']
      while (JSON.stringify(pinDetail).length > 480) {
        let target = null
        for (const k of shrinkKeys) {
          const arr = pinDetail[k]
          if (Array.isArray(arr) && arr.length > 1 && (target === null || arr.length > pinDetail[target].length)) target = k
        }
        if (target === null) break
        pinDetail[target] = pinDetail[target].slice(0, -1)
      }
      this._auditRow({
        op: 'pin',
        producer: 'dsh-context-maid',
        unit: 'chars',
        summary: '折叠后约束校验：' + (FOLD_VERIFY_LABEL[v.status] ?? v.status)
          + ' · ' + verifyText + ' · ' + hitText
          + (manifest.omitted > 0
            ? '；未注入 ' + manifest.omitted + ' 条（PIN 预算 '
              + (manifest.budget === null ? '—' : manifest.budget) + ' 截断，非模型丢失）'
            : '')
          + (manifest.unverifiableFacts > 0
            ? '；' + manifest.unverifiableFacts + ' 条事实无字面锚点（不可校验）'
            : ''),
        detail: JSON.stringify(pinDetail),
      }, agent?.session)
    } catch (err) {
      this.ctx.logger?.warn?.('[context-maid] pin anchor verify failed: '
        + (err instanceof Error ? err.message : String(err)))
    }
  }

  /**
   * M5 覆写官方自动入口：先 runPreCleanup（eventSlim 增量瘦身），再走官方逻辑。
   * agent/pre-step 动态派发 → maid 覆写即成为每次 step 的入口；官方
   * pressure/overflow 触发与折叠事务语义全部保留在 super。
   * @param {object} agent - Agent
   * @param {'pressure'|'context-overflow'} trigger - 官方触发类型
   * @param {AbortSignal} signal
   */
  async compactIfNeeded(agent, trigger, signal) {
    // C3（2026-10-05）：压缩迟滞。刚压过就不再压，抑制阈值附近的抖动。
    // 默认 cooldownMs=0 → 本分支不生效，行为与改动前逐字一致。
    // context-overflow 豁免——那是硬约束，跳过会把 turn 撑崩（宁可多压一次）。
    const cooldownMs = Number(this.maidConfig?.['trigger.cooldownMs'] ?? 0)
    if (cooldownMs > 0 && trigger !== 'context-overflow' && this._lastCompactAt !== null) {
      const elapsed = Date.now() - this._lastCompactAt
      if (elapsed < cooldownMs) {
        this._trace('compactIfNeeded(' + trigger + ') → skip (C3 cooldown '
          + Math.round(elapsed / 1000) + 's / ' + Math.round(cooldownMs / 1000) + 's)')
        return null
      }
    }
    try {
      await this.runPreCleanup(agent)
    } catch (err) {
      this.ctx?.logger?.warn?.('[context-maid] runPreCleanup failed: '
        + (err instanceof Error ? err.message : String(err)))
    }
    // 诊断（2026-09-18）：官方路径抛错时，pre-step 处理器只 warn 到宿主日志——外部看不见。
    // debug=true 时把「注入是否可用 / 测得多大 / 抛了什么」写进 <auditDir>/maid-trace.log。
    this._probePressure(agent, trigger)
    try {
      const res = await super.compactIfNeeded(agent, trigger, signal)
      // C3：只有**真的压了**才计时（返回 null = 未达阈值，不该占用冷却窗口）
      if (res) this._lastCompactAt = Date.now()
      this._trace('compactIfNeeded(' + trigger + ') → '
        + (res ? 'compacted ' + JSON.stringify(res.shadowedRange ?? null) : 'null（未达阈值或无范围）'))
      return res
    } catch (err) {
      this._trace('compactIfNeeded(' + trigger + ') THREW: ' + (err?.stack ?? err))
      throw err
    }
  }

  /** 智能路由解析器注册表（外部插件接入点）——见 constructor _resolvers */

  /**
   * 注册摘要目标解析器。解析器签名：
   *   async (agent, defaultTarget) => { provider, model } | null | undefined
   * 返回 null/undefined = 不决策（继续 maid Config → 官方回落）。
   * @param {(agent: object, defaultTarget: object) => Promise<object|null|undefined>|object|null|undefined} fn
   * @returns {() => void} 注销函数
   */
  registerSummarizationResolver(fn) {
    if (typeof fn !== 'function') throw new TypeError('registerSummarizationResolver: fn must be a function')
    this._resolvers.push(fn)
    return () => { this._resolvers = this._resolvers.filter((f) => f !== fn) }
  }

  /** 依次询问注册的 resolver；全不决策返回 maid Config 显式目标或 null。 */
  async resolveSummarizationTarget(agent, defaultTarget) {
    for (const fn of this._resolvers) {
      try {
        const out = await fn(agent, defaultTarget)
        if (out && typeof out.provider === 'string' && out.provider && typeof out.model === 'string' && out.model) {
          return { provider: out.provider, model: out.model }
        }
      } catch (err) {
        this.ctx.logger?.warn?.('[context-maid] summarization resolver error: '
          + (err instanceof Error ? err.message : String(err)))
      }
    }
    if (defaultTarget && defaultTarget.provider && defaultTarget.model) return defaultTarget
    return null
  }

  /** 诊断统计（status 命令展示）：compactIfNeeded/runPreCleanup 被调次数与最近结果 */
  cleanupStats() {
    return {
      ticks: this._cleanupTicks,
      lastAt: this._cleanupLastAt,
      lastResult: this._cleanupLastResult,
    }
  }
}

export default MaidCompactionEngine
