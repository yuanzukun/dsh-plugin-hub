// src/audit.mjs — maid 策展审计（独立 SQLite，零依赖）。
// 每次策展（SLIM/SWEEP/FOLD/PIN）写一行；/context-maid status 与历史可查。

import { DatabaseSync } from 'node:sqlite'
import { mkdirSync, existsSync } from 'node:fs'
import path from 'node:path'

const SCHEMA = `
CREATE TABLE IF NOT EXISTS maid_audit (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ts INTEGER NOT NULL,
  op TEXT NOT NULL,              -- slim | sweep | fold | pin | config | status
  session_id TEXT NOT NULL DEFAULT '',
  range TEXT NOT NULL DEFAULT '', -- start:end seqs（适用时）
  tokens_before INTEGER,
  tokens_after INTEGER,
  archive_ids TEXT NOT NULL DEFAULT '[]', -- 归档到 ACP 的条目 id
  summary TEXT NOT NULL DEFAULT '',       -- 摘要/说明（截断 500）
  detail TEXT NOT NULL DEFAULT '',
  -- 2026-09-09（P0-2 记账货币纪律）：本表数值的口径必须显式声明，绝不与宿主 token-meter 混算。
  unit TEXT NOT NULL DEFAULT '',          -- chars | estTokens（空 = 未声明）
  producer TEXT NOT NULL DEFAULT ''       -- 事件生产者（plugin id / 模块名）
);
CREATE INDEX IF NOT EXISTS idx_maid_audit_ts ON maid_audit (ts);
`

export function openMaidAudit(dir) {
  if (!existsSync(dir)) mkdirSync(dir, { recursive: true })
  const db = new DatabaseSync(path.join(dir, 'maid.db'))
  db.exec('PRAGMA journal_mode = WAL; PRAGMA busy_timeout = 5000; PRAGMA synchronous = NORMAL;')
  db.exec(SCHEMA)
  // v0.3.1 迁移：unit / producer（列已存在时 ALTER 抛错，忽略即可）
  try { db.exec("ALTER TABLE maid_audit ADD COLUMN unit TEXT NOT NULL DEFAULT ''") } catch { /* 已迁移 */ }
  try { db.exec("ALTER TABLE maid_audit ADD COLUMN producer TEXT NOT NULL DEFAULT ''") } catch { /* 已迁移 */ }

  function append(row = {}) {
    try {
      db.prepare(`INSERT INTO maid_audit (ts, op, session_id, range, tokens_before, tokens_after, archive_ids, summary, detail, unit, producer)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`).run(
        Date.now(),
        String(row.op ?? ''),
        String(row.sessionId ?? ''),
        String(row.range ?? ''),
        row.tokensBefore ?? null,
        row.tokensAfter ?? null,
        JSON.stringify(row.archiveIds ?? []),
        String(row.summary ?? '').slice(0, 500),
        String(row.detail ?? '').slice(0, 500),
        String(row.unit ?? ''),
        String(row.producer ?? ''),
      )
    } catch { /* 审计失败不阻断策展 */ }
  }

  // MAID-B16（2026-09-25）：recent() 的行必须与 append() 的入参**同形**。
  //
  // 原写法只补了 archiveIds，其余多词列（session_id / tokens_before / tokens_after）
  // 仍是 SQLite 原生蛇形。而消费者读的是 camelCase ——
  //   archiver.mjs nextFoldDepth 读 r.sessionId、commands.mjs status 也读它 ——
  // 于是 r.sessionId 恒 undefined：**B14 的「从审计库播种 foldDepth」在生产路径上恒不生效**
  // （进程重启后每次都从 1 重来，status 的 foldDepth 恒显示 0）。
  // 老测试用 { sessionId } 的 mock 行，形状与真实行不一致，所以一直没抓住（见 test/m8.test.mjs）。
  //
  // 做法：**只增不删**。保留原生列（fold-verify 的测试照实断言过 rows[0].session_id），
  // 只把 camelCase 补齐。读侧容忍两种形状，写侧不因此改动。
  const toRow = (r) => ({
    ...r,
    sessionId: String(r.session_id ?? ''),
    tokensBefore: r.tokens_before ?? null,
    tokensAfter: r.tokens_after ?? null,
    archiveIds: JSON.parse(r.archive_ids),
  })

  function recent(limit = 20) {
    try {
      return db.prepare('SELECT * FROM maid_audit ORDER BY id DESC LIMIT ?').all(limit).map(toRow)
    } catch { return [] }
  }

  // MAID-B17（2026-10-04 审计）：原写法 SUM(tokens_before - tokens_after) 对 fold **恒 NULL**。
  //
  // 三道坎叠在一起：① tokens_after 是**设计上留空**的（折叠完成的那一刻，"折后实测"还不存在 ——
  // 同表 slim 能写是因为可原地量出）；② NULL 参与减法仍是 NULL；③ SUM 忽略 NULL。
  // 于是这一条 SQL 把 93 次 fold 的节省量全部吞掉，status 从上线起就没报过 fold 省了多少
  // （实测：fold 93 行 / tokens_after 93 行 NULL / saved 恒 NULL）。
  //
  // 做法：**回退到已经记着的那份数** —— archiver 写 fold 行时把 shadowedTokens（本次折掉的
  // estTokens）放进了 detail。tokens_after 有值就用差值，没有就用 shadowedTokens；
  // 两个都拿不到才计入 savedNull（**显式暴露，不静默当 0**）。
  //
  // 只增不删（沿用本文件 toRow 的同款纪律）：返回值仍带 {op, n, saved} —— commands.mjs status
  // 读的就是这三个 —— 另加 savedFromShadowed / savedNull 两列供诊断。
  //
  // ⚠️ 口径警告（2026-10-04 实测，别误读 saved）：
  //   fold 走的是 shadowedTokens 回退，那是**被折掉那一段逐条消息的启发式估价**，
  //   **≠「整个 prompt 净减少量」**。实测两者比 **1.59x**（口径差，不是少报）。
  //   要净省多少，用 .tooling/scripts/dsh-fold-audit.mjs（compactionId 精确配对会话日志）。
  //   依据：reports/dsh-audit-20261004/fold-measured-20261004.md
  function stats(days = 7) {
    const since = Date.now() - days * 86400000
    try {
      const rows = db.prepare('SELECT op, tokens_before, tokens_after, detail FROM maid_audit WHERE ts >= ?').all(since)
      const byOp = new Map()
      for (const r of rows) {
        let e = byOp.get(r.op)
        if (!e) { e = { op: r.op, n: 0, saved: 0, savedFromShadowed: 0, savedNull: 0 }; byOp.set(r.op, e) }
        e.n++
        let s = null
        if (r.tokens_before != null && r.tokens_after != null) s = r.tokens_before - r.tokens_after
        else {
          try {
            const d = JSON.parse(r.detail)
            if (d && d.shadowedTokens != null) { s = Number(d.shadowedTokens); e.savedFromShadowed++ }
          } catch { /* detail 非 JSON —— 老行或非策展事件 */ }
        }
        if (s == null || Number.isNaN(s)) e.savedNull++
        else e.saved += s
      }
      return [...byOp.values()].map((e) => ({ ...e, saved: e.saved || null }))
    } catch { return [] }
  }

  function close() { db.close() }

  return { db, append, recent, stats, close }
}

export default openMaidAudit
