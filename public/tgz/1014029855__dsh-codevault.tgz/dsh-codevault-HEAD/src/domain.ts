/**
 * Domain model + pure validation for dsh-codevault.
 *
 * This file holds NO I/O — every function is a pure function of its inputs,
 * which keeps it trivially testable in `smoke.mjs` without a cordis runtime.
 *
 * Deliberate design decisions (see DESIGN.md §1):
 *  - No 0-10 score, no "one-line impression", no rating statistics: this is a
 *    READING archive (what/where/when/understanding), not a music-review one.
 *  - The subject coordinate (repo -> path -> symbol) is the backbone.
 */

import { randomUUID } from 'node:crypto'

export type EntryKind = 'capture' | 'note'

/** The thing that was read. `repo` is mandatory; everything else optional. */
export interface ReadingSubject {
  /** owner/name (e.g. deepseek-ai/deepseek-harness) or a local folder name. */
  readonly repo: string
  /** Optional version / commit / branch the read happened against. */
  readonly ref?: string
  /** Optional file path relative to the repo root. */
  readonly path?: string
  /** Optional function/class/module/symbol that was read. */
  readonly symbol?: string
}

/** One row of library.jsonl — one reading event. */
export interface ReadingEntry {
  readonly id: string
  readonly kind: EntryKind
  /** ISO 8601 instant the reading was recorded. */
  readonly readAt: string
  readonly subject: ReadingSubject
  /** Optional: why the user was reading this / the question being chased. */
  readonly context?: string
  /** Human-readable content title (optional; falls back to subject-derived). */
  readonly title?: string
  /** One-sentence take (required for capture; doubles as card summary). */
  readonly note?: string
  /** Long-form deep-reading note body (kind === 'note', >= MIN_NOTE_BODY). */
  readonly bodyMarkdown?: string
  /** Self-distilled reusable points (note). */
  readonly takeaway: readonly string[]
  /**
   * Questions to answer the NEXT time this object is revisited — a retrieval
   * prompt, not trivia: they should force re-deriving the mechanism. Kept on the
   * event and merged (deduped) into the card's "回访问题" section.
   */
  readonly revisit: readonly string[]
  /** Free-form topic words for Obsidian tag search (NOT used for stats). */
  readonly tags: readonly string[]
  /**
   * Structured external vault links added AFTER the event was written
   * (direction A polish #3: suggest -> user confirms -> read_link persists).
   * Kept separate from body text so links are dedupable and renderable into
   * the card's "关联 vault 笔记" section.
   */
  readonly links: readonly string[]
  /**
   * Card file name WITHOUT `.md`, fixed at first commit so the archive keeps
   * stable links. Legacy rows written before this field existed fall back to
   * their `id` (see noteFileName in store.ts).
   */
  readonly noteFile?: string
  readonly updatedAt: string
}

export const MIN_NOTE_BODY = 200
export const MAX_TAGS = 12
export const MAX_REPO_LEN = 200
export const MAX_LINKS = 20
/** Cap on revisit questions kept per entry (2–3 is the intended shape). */
export const MAX_REVISIT = 6
export const MAX_REVISIT_LEN = 200

/**
 * Validate & normalize external-link targets (Obsidian note names, no [[]]):
 * trim, drop accidental brackets, cap count/length, dedupe keeping order.
 */
export function normalizeLinks(raw: readonly unknown[] | undefined): string[] {
  if (raw === undefined) return []
  if (!Array.isArray(raw)) throw new Error('links 必须是字符串数组（可省略）')
  if (raw.length > MAX_LINKS) throw new Error(`links 最多 ${MAX_LINKS} 个`)
  const out: string[] = []
  const seen = new Set<string>()
  for (const item of raw) {
    const link = String(item).trim().replace(/^\[\[|\]\]$/gu, '').trim()
    if (!link) continue
    if ([...link].length > 200) throw new Error(`link "${item}" 过长（≤200 字符）`)
    if (!seen.has(link)) {
      seen.add(link)
      out.push(link)
    }
  }
  return out
}

/** Clean a repo identifier: trim, collapse inner whitespace. */
export function normalizeRepo(raw: string): string {
  const repo = String(raw ?? '').trim().replace(/\s+/g, ' ')
  if (!repo) throw new Error('subject.repo 必填：仓库标识（owner/name 或本地目录名）不能为空')
  if (repo.length > MAX_REPO_LEN) throw new Error(`subject.repo 过长（≤${MAX_REPO_LEN} 字符）`)
  return repo
}

function cleanOptional(raw: string | undefined, label: string, max: number): string | undefined {
  const value = String(raw ?? '').trim()
  if (!value) return undefined
  if (value.length > max) throw new Error(`${label} 过长（≤${max} 字符）`)
  return value
}

/** Validate a model/user supplied subject; returns a canonical copy. */
export function normalizeSubject(raw: ReadingSubject): ReadingSubject {
  const repo = normalizeRepo(raw.repo)
  const ref = cleanOptional(raw.ref, 'subject.ref', 200)
  const path = cleanOptional(raw.path, 'subject.path', 500)
  const symbol = cleanOptional(raw.symbol, 'subject.symbol', 200)
  return { repo, ...(ref ? { ref } : {}), ...(path ? { path } : {}), ...(symbol ? { symbol } : {}) }
}

/**
 * Lenient tag normalization: trim -> lowercase -> collapse inner whitespace to
 * '-'. Tags are free topic words for Obsidian tag search, NOT a controlled
 * vocabulary and NOT used for statistics, so the check is deliberately loose.
 */
export function normalizeTags(raw: readonly unknown[] | undefined): string[] {
  if (raw === undefined) return []
  if (!Array.isArray(raw)) throw new Error('tags 必须是字符串数组（可省略）')
  if (raw.length > MAX_TAGS) throw new Error(`tags 最多 ${MAX_TAGS} 个`)
  const out: string[] = []
  const seen = new Set<string>()
  for (const item of raw) {
    const tag = String(item).trim().toLowerCase().replace(/\s+/g, '-').replace(/-+/g, '-')
    const len = [...tag].length
    if (len < 2 || len > 40) {
      throw new Error(`tag "${item}" 处理后需为 2–40 字符`)
    }
    if (!seen.has(tag)) {
      seen.add(tag)
      out.push(tag)
    }
  }
  return out
}

/**
 * Normalize revisit questions: trim, collapse inner whitespace, dedupe, cap
 * count/length. Empty entries are dropped (questions are optional).
 */
export function normalizeRevisit(raw: readonly unknown[] | undefined): string[] {
  if (raw === undefined) return []
  if (!Array.isArray(raw)) throw new Error('revisit 必须是字符串数组（可省略）')
  if (raw.length > MAX_REVISIT) throw new Error(`revisit 最多 ${MAX_REVISIT} 条`)
  const out: string[] = []
  const seen = new Set<string>()
  for (const item of raw) {
    const q = String(item).trim().replace(/\s+/gu, ' ')
    if (!q) continue
    if ([...q].length > MAX_REVISIT_LEN) {
      throw new Error(`revisit 单条过长（≤${MAX_REVISIT_LEN} 字符）：${clip(q, 40)}`)
    }
    if (!seen.has(q)) {
      seen.add(q)
      out.push(q)
    }
  }
  return out
}

export interface TagPolicyResult {
  /** Tags actually attached to the new event. */
  readonly accepted: string[]
  /** Suggested tags rejected because they are not part of the vocabulary. */
  readonly dropped: string[]
}

/**
 * Tag discipline (borrowed from WeKnora's auto-tagging rule): a model-suggested
 * tag is accepted only when it ALREADY exists in the archive vocabulary or on
 * this object, so tagging never silently explodes the vocabulary; genuinely new
 * topic words must be declared explicitly via `newTags`. Card tags are the union
 * over all events, so tags a human added earlier are never overwritten.
 *
 * `seedVocabulary` covers the one case where the rule cannot apply: an archive
 * with no tags at all yet (the very first records) — filtering against an empty
 * vocabulary would reject everything and no vocabulary could ever form, so those
 * writes seed it. After that the filter is strict.
 */
export function applyTagPolicy(
  suggested: readonly unknown[] | undefined,
  newTags: readonly unknown[] | undefined,
  vocabulary: readonly string[],
  objectTags: readonly string[] = [],
  seedVocabulary = false,
): TagPolicyResult {
  const declared = normalizeTags(newTags)
  const known = new Set([...vocabulary, ...objectTags, ...declared].map((t) => t.toLowerCase()))
  const accepted: string[] = []
  const dropped: string[] = []
  for (const tag of normalizeTags(suggested)) {
    if (known.has(tag) || seedVocabulary) accepted.push(tag)
    else dropped.push(tag)
  }
  return { accepted: [...new Set([...accepted, ...declared])], dropped }
}

/** Human-oriented title for one entry (used in card H1, hub & MOC lines). */
export function subjectTitle(s: ReadingSubject): string {
  const file = s.path ? (s.path.split(/[\\/]/u).pop() ?? s.path) : undefined
  const parts: string[] = []
  if (file) parts.push(file)
  if (s.symbol) parts.push(s.symbol)
  return parts.length > 0 ? parts.join(' :: ') : s.repo
}

/**
 * Canonical grouping key of a reading OBJECT — the deepest coordinate given:
 * `symbol` (repo+path+symbol) > `path` (repo+path) > `repo`. Events that share
 * the same key are the same object and project onto ONE card (object card).
 * The key is derived ONLY from the deepest granularity actually provided, so
 * "same file re-read" and "same symbol re-read" each stay one card.
 */
export function objectKey(s: ReadingSubject): string {
  const repo = normalizeRepo(s.repo)
  const path = s.path?.trim()
  const symbol = s.symbol?.trim()
  if (symbol) return `S\u0000${repo}\u0000${path ?? ''}\u0000${symbol}`
  if (path) return `P\u0000${repo}\u0000${path}`
  return `R\u0000${repo}`
}

/** Stable canonical key of an entry's object. */
export function entryObjectKey(e: ReadingEntry): string {
  return objectKey(e.subject)
}

/** The canonical (normalized) subject that an object key points at. */
export function subjectOfKey(key: string): ReadingSubject {
  const parts = key.split('\u0000')
  const kind = parts[0]
  const repo = parts[1] ?? ''
  if (kind === 'S') return { repo, ...(parts[2] ? { path: parts[2] } : {}), ...(parts[3] ? { symbol: parts[3] } : {}) }
  if (kind === 'P') return { repo, ...(parts[2] ? { path: parts[2] } : {}) }
  return { repo }
}

/**
 * Display title of an entry: an explicit `title` when given (that is the
 * user-facing content summary), otherwise a coordinate-derived fallback so
 * card H1 / hub / MOC always have something readable.
 */
export function entryTitle(e: ReadingEntry): string {
  return e.title ? e.title : subjectTitle(e.subject)
}

/** Stable display label like "deepseek-ai/deepseek-harness · src/core/plugin.ts#apply". */
export function subjectLabel(s: ReadingSubject): string {
  const tail = []
  if (s.path) tail.push(s.path)
  if (s.symbol) tail[tail.length - 1] = `${tail[tail.length - 1]} → ${s.symbol}`
  return tail.length > 0 ? `${s.repo} · ${tail.join(' · ')}` : s.repo
}

export function entryKindText(kind: EntryKind): string {
  return kind === 'note' ? '深读笔记' : '快记'
}

/**
 * Build a file-system & Obsidian-friendly file name from a display title:
 * keeps CJK/letters/digits/`._-`, collapses the rest to single `-`, trims
 * edge dashes, and caps length. Empty input falls back to `reading`.
 */
export function cardFileName(title: string): string {
  const cleaned = [...title.trim()]
    .map((ch) => (/[\p{L}\p{N}._-]/u.test(ch) ? ch : '-'))
    .join('')
    .replace(/-+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 72)
    .replace(/-+$/g, '')
  return cleaned || 'reading'
}

/** Build a new entry object (validate + stamp id/time) WITHOUT writing anything. */
export function buildEntry(input: {
  kind: EntryKind
  subject: ReadingSubject
  context?: string
  title?: string
  note?: string
  bodyMarkdown?: string
  takeaway?: readonly string[]
  revisit?: readonly unknown[]
  tags?: readonly unknown[]
  links?: readonly unknown[]
}): ReadingEntry {
  const subject = normalizeSubject(input.subject)
  const context = cleanOptional(input.context, 'context', 2000)
  const title = cleanOptional(input.title, 'title', 120)
  const now = new Date().toISOString()

  let note: string | undefined
  let bodyMarkdown: string | undefined
  if (input.kind === 'capture') {
    const n = String(input.note ?? '').trim()
    if (!n) throw new Error('capture 的 note 必填：写清这次读到了什么机制/关键点在哪/它为什么这样设计')
    if ([...n].length > 2000) throw new Error('capture 的 note 过长（≤2000 字符）——写 2–4 句要点即可，长篇请用深读笔记')
    note = n
  } else {
    const body = String(input.bodyMarkdown ?? '').trim()
    if ([...body].length < MIN_NOTE_BODY) {
      throw new Error(`bodyMarkdown 需至少 ${MIN_NOTE_BODY} 字（当前 ${[...body].length}）——请按阅读框架把坐标与机制写足再存档`)
    }
    if (!context) {
      throw new Error('深读笔记的 context 必填：先写清"为什么读到这 / 当时在解决什么问题"')
    }
    bodyMarkdown = body
  }
  const takeaway = (input.takeaway ?? [])
    .map((t) => String(t).trim())
    .filter((t) => t.length > 0)
  if (input.kind === 'note' && takeaway.length === 0) {
    throw new Error('深读笔记至少要有 1 条 takeaway（可复用的提炼要点）')
  }

  return {
    id: randomId(),
    kind: input.kind,
    readAt: now,
    subject,
    ...(context ? { context } : {}),
    ...(title ? { title } : {}),
    ...(note ? { note } : {}),
    ...(bodyMarkdown ? { bodyMarkdown } : {}),
    takeaway,
    revisit: normalizeRevisit(input.revisit),
    tags: normalizeTags(input.tags),
    links: normalizeLinks(input.links),
    updatedAt: now,
  }
}

/** Short lowercase alphanumeric id (8 chars from a uuid). */
export function randomId(): string {
  return randomUUID().replace(/-/g, '').slice(0, 8).toLowerCase()
}

/** Clip long free text for cheap model-facing summaries. */
export function clip(text: string, max = 120): string {
  if ([...text].length <= max) return text
  return `${[...text].slice(0, max).join('')}…`
}

/** One-line summary of an entry for cards/hub/MOC. */
export function entrySummary(e: ReadingEntry): string {
  if (e.kind === 'capture') return e.note ?? ''
  const t = e.takeaway[0]
  if (t) return t
  return clip(e.bodyMarkdown ?? '', 120)
}
