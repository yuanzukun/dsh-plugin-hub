import {readFile} from 'node:fs/promises';
import {readFileSync} from 'node:fs';
const matrixVersions=JSON.parse(readFileSync(new URL('../compatibility.json',import.meta.url),'utf8'));
const sdkPeers=['agent','commands','llm','session','storage-domain','tools'].map(name=>'@deepseek-ai/dsh-'+name);
import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
import {readOfficialChannels} from './official-channels.mjs';
// These contracts intentionally enumerate validated prereleases. Never bypass
// Host admission or silently widen compatibility after an upstream release.
export function validateCompatibility(metadata,version,verified=matrixVersions){
 if(!Array.isArray(verified)||!verified.length||verified.length>20||new Set(verified).size!==verified.length||verified.some(v=>typeof v!=='string'||!/^0\.\d+\.\d+-(?:rc|alpha)\.\d+$/.test(v)))throw Error('Invalid SDK matrix');
 const listed=range=>typeof range==='string'?range.split(/\s*\|\|\s*/).sort():[];
 const exact=range=>JSON.stringify(listed(range))===JSON.stringify([...verified].sort());
 if(!exact(metadata.engines?.dsh)||sdkPeers.some(name=>!exact(metadata.peerDependencies?.[name])))throw Error('Host and all SDK peers must exactly match the tested matrix');
 if(!verified.includes(version))throw Error('Official version is absent from the tested matrix: '+version);
 if(!/^0\.\d+\.\d+-(?:rc|alpha)\.\d+$/.test(version))throw Error('Invalid exact SDK version');
 const admits=range=>typeof range==='string'&&range.split(/\s*\|\|\s*/).includes(version);
 if(!admits(metadata.engines?.dsh))throw Error('Latest official SDK is outside validated host compatibility: '+version);
 for(const [name,range] of Object.entries(metadata.peerDependencies??{}))if(name.startsWith('@deepseek-ai/dsh-')&&!admits(range))throw Error('Required peer is outside validated compatibility: '+name+' '+version);
 return version;
}
export function validateOfficialChannels(metadata,observed,verified=matrixVersions){
 if(typeof observed?.sdkLatest!=='string'||typeof observed?.desktop!=='string')throw Error('Official desktop or latest lookup unavailable');
 const targets=[...new Set([observed.sdkLatest,observed.desktop])];
 for(const target of targets)validateCompatibility(metadata,target,verified);
 return{sdkLatest:observed.sdkLatest,desktop:observed.desktop,targets};
}
async function main(){
 const metadata=JSON.parse(await readFile(new URL('../package.json',import.meta.url)));
 let version=process.argv[2];
 if(version==='--matrix'){validateCompatibility(metadata,matrixVersions.at(-1));console.log(JSON.stringify({include:matrixVersions.map(sdk=>({sdk,node:sdk.startsWith('0.2.2-rc.')?'24.22.1':'22.22.0'}))}));return;}
 if(version==='--latest'){
  const observed=await readOfficialChannels();console.log(JSON.stringify({...validateOfficialChannels(metadata,observed),compatibilityOverride:false}));return;
 }
 validateCompatibility(metadata,version);console.log(JSON.stringify({supportedOfficialVersion:version,compatibilityOverride:false}));
}
if(process.argv[1]&&import.meta.url===pathToFileURL(resolve(process.argv[1])).href)main().catch(error=>{console.error(error.message);process.exitCode=1;});
