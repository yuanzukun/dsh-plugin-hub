import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
const module=await import('../src/client-goal-board.js').catch(()=>({}));
const {createDotGoalBoardViews:create}=module;
function harness(state){let values=[],cursor=0,pending=[];const React={createElement:(type,props,...children)=>({type,props:props??{},children:children.flat(Infinity).filter(v=>v!==null&&v!==false&&v!==undefined)}),useState:initial=>{const i=cursor++;if(!(i in values))values[i]=typeof initial==='function'?initial():initial;return[values[i],v=>{values[i]=typeof v==='function'?v(values[i]):v;}];},useRef:initial=>{const i=cursor++;if(!(i in values))values[i]={current:initial};return values[i];},useEffect:(fn,deps)=>{const i=cursor++,old=values[i];if(!old||deps.some((v,j)=>v!==old.deps[j])){old?.cleanup?.();values[i]={deps};pending.push(()=>values[i].cleanup=fn());}}};const listeners=new Set(),calls=[];const controller={getSnapshot:()=>state,subscribe:fn=>{listeners.add(fn);return()=>listeners.delete(fn);},refresh:()=>calls.push('refresh'),open:()=>calls.push('open'),cancel:()=>calls.push('cancel'),load:arg=>calls.push(['load',arg]),toggle:id=>calls.push(['toggle',id]),selectVisible:()=>calls.push('selectVisible'),selectAll:()=>calls.push('selectAll'),clearSelection:()=>calls.push('clearSelection'),save:()=>calls.push('save'),dismiss:()=>calls.push('dismiss'),recognize:()=>calls.push('recognize'),organize:()=>calls.push('organize'),mutate:(...args)=>calls.push(['mutate',...args])};return{React,controller,calls,render:(Component,props={})=>{cursor=0;return Component({controller,...props});},flush:()=>{const f=pending;pending=[];f.forEach(fn=>fn());},unmount:()=>{values.forEach(v=>v?.cleanup?.());values=[];},setState:value=>{state=value;listeners.forEach(fn=>fn());}};}
function nodes(tree,fn){const out=[];const visit=n=>{if(!n||typeof n!=='object')return;if(fn(n))out.push(n);for(const child of n.children??[])visit(child);};visit(tree);return out;}
function text(tree){return typeof tree==='string'?tree:(tree?.children??[]).map(text).join(' ');}
const button=(view,label)=>nodes(view,n=>n.type==='button'&&text(n).includes(label))[0];
const workspaceState=()=>({open:true,loading:false,saving:false,stale:false,error:'',query:'',selectedIds:['w1','w130'],delta:{added:1,removed:1},summary:{selectedCount:2,labels:[{id:'w1',label:'工作 A'}]},page:{total:137,matchedTotal:137,offset:120,limit:20,hasMore:false,nextOffset:null,items:[{id:'w130',label:'工作130',sessionCount:2,disambiguator:'合成目录'}]}});
const project=()=>({id:'p1',title:'交付一个结果',goal:'目标正文',constraints:['保留原约束'],state:'proposed',lane:'waiting',progress:'来源中的进展',nextStep:'请核对',stale:true,evidenceCount:2,sessionCount:2,workspaceCount:1});

test('same workspace dialog exposes exact delta, all-workspace selection, pagination and Escape cancellation',()=>{
 assert.equal(typeof create,'function');const h=harness(workspaceState()),{WorkspaceDialog}=create(h.React);const view=h.render(WorkspaceDialog);assert.match(text(view),/新增 1 个，移除 1 个/);assert.match(text(view),/全选全部 137 个/);assert.match(text(view),/已选 2 个/);button(view,'全选全部').props.onClick();assert.equal(h.calls.at(-1),'selectAll');button(view,'取消全选').props.onClick();assert.equal(h.calls.at(-1),'clearSelection');const checks=nodes(view,n=>n.type==='input'&&n.props.type==='checkbox');assert.equal(checks.length,1);assert.equal(checks[0].props.checked,true);checks[0].props.onChange();assert.deepEqual(h.calls.at(-1),['toggle','w130']);button(view,'上一页').props.onClick();assert.deepEqual(h.calls.at(-1),['load',{query:'',offset:100}]);let prevented=false;view.props.onKeyDown({key:'Escape',preventDefault:()=>prevented=true,stopPropagation(){}});assert.equal(prevented,true);assert.equal(h.calls.at(-1),'cancel');assert.equal(h.calls.includes('save'),false);h.unmount();
});
test('workspace guide works before WeChat pairing and exposes a metadata-only choice, never a grant',()=>{
 assert.equal(typeof create,'function');const state=workspaceState();state.open=false;state.summary={selectedCount:0,labels:[]};const h=harness(state),{WorkspaceGuide}=create(h.React);const view=h.render(WorkspaceGuide);button(view,'选择范围').props.onClick();assert.equal(h.calls.at(-1),'open');assert.match(text(view),/选择 Dot 能看的项目/);assert.equal(h.calls.includes('save'),false);h.unmount();
});
test('board shows exactly three objective lanes and blue proposed groups with stale/source boundaries',()=>{
 assert.equal(typeof create,'function');const state={status:{projects:[project()],scan:{phase:'complete',coverage:[{label:'工作 A',status:'partial',filesRead:1,sessionsRead:2,truncated:true}]},standaloneCount:1,uncertainCount:2},busy:false,loading:false,error:''};const h=harness(state),{ProjectBoard}=create(h.React);const view=h.render(ProjectBoard);assert.deepEqual(nodes(view,n=>n.props['data-goal-lane']).map(n=>n.props['aria-label']),['待我推进','推进中','等回复／确认']);const card=nodes(view,n=>n.props['data-logical-project']==='p1')[0];assert.match(card.props.className,/proposed/);assert.match(text(card),/交付一个结果.*目标正文.*进展需重新核对.*请核对/);assert.match(text(view),/来源中的记录.*验收/);assert.match(text(view),/部分资料.*截断/);button(view,'整理这些工作区的项目').props.onClick();assert.equal(h.calls.at(-1),'organize');h.unmount();
});
test('side sheet exposes canonical vision and evidence while mounting only native dedicated conversation',()=>{
 assert.equal(typeof create,'function');const state={projectId:'p1',detailLoading:false,busy:false,error:'',target:{sessionId:'dot-goal-1',revision:'native:dot-goal-1'},status:{projects:[project()]},detail:{project:project(),evidence:[{id:'e1',workspaceLabel:'工作 A',reference:'source:1',available:false,text:'REVOKED_PRIVATE_SENTINEL'},{id:'e2',workspaceLabel:'工作 B',reference:'source:2',available:true,text:'可见合成来源',truncated:true}]}};const h=harness(state),{ProjectSheet}=create(h.React),rendered=[];const view=h.render(ProjectSheet,{renderConversation:props=>{rendered.push(props);return h.React.createElement('native-conversation',props);}});assert.match(text(view),/目标正文.*保留原约束/);assert.doesNotMatch(text(view),/REVOKED_PRIVATE_SENTINEL/);assert.match(text(view),/已移出访问范围/);assert.equal(nodes(view,n=>n.type==='native-conversation').length,1);assert.deepEqual(rendered,[{projectId:'p1',target:state.target}]);assert.equal(nodes(view,n=>n.type==='textarea').length,0);button(view,'关闭项目').props.onClick();assert.equal(h.calls.at(-1),'dismiss');h.unmount();
});
test('sheet focus returns to its trigger and contains keyboard focus without discarding drafts',()=>{
 assert.equal(typeof create,'function');let returned=0,focused=0;const trigger={isConnected:true,focus:()=>returned++};globalThis.document={activeElement:trigger};try{const h=harness({projectId:'p1',detail:null,detailLoading:true,busy:false,error:'',target:null}),{ProjectSheet}=create(h.React);const view=h.render(ProjectSheet);const panel=nodes(view,n=>n.props.role==='dialog')[0];panel.props.ref.current={focus:()=>focused++,querySelectorAll:()=>[]};h.flush();assert.equal(focused,1);let prevented=0;panel.props.onKeyDown({key:'Tab',preventDefault:()=>prevented++});assert.equal(prevented,1);h.unmount();assert.equal(returned,1);}finally{delete globalThis.document;}
});
test('browser embeds the audited goal factories and keeps native per-project targets out of global remember',async()=>{
 const source=await readFile(new URL('../src/client.js',import.meta.url),'utf8');for(const name of ['createWorkspaceScopeController','createLogicalProjectController','createGoalConversationRegistry','createDotGoalBoardViews']){assert.equal(typeof module[name],'function');assert.equal(source.includes(module[name].toString()),true,`${name} must be embedded without drift`);}assert.match(source,/projectConversations\.acquire/);assert.match(source,/projectActive/);assert.match(source,/'dot\.project\.conversation'/);assert.doesNotMatch(source,/desktopController\.remember\([^)]*project/);
});

test('side-sheet Escape respects native child handling and IME composition before closing',()=>{
 assert.equal(typeof create,'function');const h=harness({projectId:'p1',detail:null,detailLoading:true,busy:false,error:'',target:null}),{ProjectSheet}=create(h.React),view=h.render(ProjectSheet),panel=nodes(view,n=>n.props.role==='dialog')[0];for(const event of [{key:'Escape',defaultPrevented:true},{key:'Escape',isComposing:true},{key:'Escape',nativeEvent:{isComposing:true}},{key:'Escape',keyCode:229}])panel.props.onKeyDown({...event,preventDefault(){},stopPropagation(){}});assert.equal(h.calls.includes('dismiss'),false);panel.props.onKeyDown({key:'Escape',preventDefault(){},stopPropagation(){}});assert.equal(h.calls.at(-1),'dismiss');h.unmount();
});

test("native composer theme pairs white input surface with readable labels without styling native controls",async()=>{const text=await readFile(new URL("../src/client.js",import.meta.url),"utf8");assert.ok(text.includes("--dsw-specific-input-major:#fff"));assert.ok(text.includes(".pc_goal_sheet button:not(:where(.pc_goal_native *))"));assert.ok(text.includes(".pc_dot button:not(:where(.pc_dot_conversation *))"));});

test('workspace bulk action names the applied search scope and disables itself while loading',()=>{
 const state=workspaceState();state.query='工作';state.page.matchedTotal=9;state.loading=true;state.selectingAll=true;
 const h=harness(state),{WorkspaceDialog}=create(h.React);let view=h.render(WorkspaceDialog);assert.equal(button(view,'正在全选').props.disabled,true);
 state.loading=false;state.selectingAll=false;view=h.render(WorkspaceDialog);assert.ok(button(view,'全选搜索结果 9 个'));assert.ok(button(view,'清空已选'));h.unmount();
});

test('workspace picker separates save-and-organize primary from save-only without an implicit read',()=>{
 const h=harness(workspaceState()),{WorkspaceDialog}=create(h.React),view=h.render(WorkspaceDialog);
 const primary=button(view,'保存并整理项目'),secondary=button(view,'仅保存范围');assert.ok(primary);assert.ok(secondary);assert.equal(primary.props.className,'pc_dot_primary');assert.equal(primary.props.disabled,false);secondary.props.onClick();assert.equal(h.calls.at(-1),'save');h.unmount();
});
test('saved scope has a compact direct organize action and honest processed count while cancelable',()=>{
 const state=workspaceState();state.open=false;const h=harness(state),{WorkspaceGuide}=create(h.React),organizer={getSnapshot:()=>({status:{scan:{phase:'running',processed:8,total:21}},busy:false}),subscribe:()=>()=>{},cancelRecognition:()=>h.calls.push('cancelRecognition')};
 const view=h.render(WorkspaceGuide,{organizer});assert.match(text(view),/已连接 2 个项目文件夹/);assert.match(text(view),/8.*21/);button(view,'停止整理').props.onClick();assert.equal(h.calls.at(-1),'cancelRecognition');h.unmount();
});

test('dialog focus prevents scroll so opening a project cannot move the underlying page',()=>{
 const h=harness({projectId:'p1',detail:null,detailLoading:true,busy:false,error:'',target:null}),{ProjectSheet}=create(h.React),view=h.render(ProjectSheet);let options;nodes(view,n=>n.props.role==='dialog')[0].props.ref.current={focus:o=>options=o};h.flush();assert.deepEqual(options,{preventScroll:true});h.unmount();
});

test('saved-scope progress polls only while its visible guide is running and never restarts organization',()=>{
 const interval=globalThis.setInterval,clear=globalThis.clearInterval;let tick,cleared=0,refreshes=0;
 globalThis.setInterval=fn=>{tick=fn;return 17;};globalThis.clearInterval=id=>{if(id===17)cleared++;};
 try{const state=workspaceState();state.open=false;const h=harness(state),{WorkspaceGuide}=create(h.React),organizer={getSnapshot:()=>({status:{scan:{phase:'running',processed:8,total:21,coverage:[]}},busy:false}),subscribe:()=>()=>{},refresh:()=>refreshes++};h.render(WorkspaceGuide,{organizer});h.flush();assert.equal(typeof tick,'function');tick();assert.equal(refreshes,1);assert.equal(h.calls.includes('recognize'),false);h.unmount();assert.equal(cleared,1);}finally{globalThis.setInterval=interval;globalThis.clearInterval=clear;}
});
