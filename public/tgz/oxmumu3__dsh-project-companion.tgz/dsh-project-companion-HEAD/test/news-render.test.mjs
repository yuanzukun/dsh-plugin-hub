import test from 'node:test';
import assert from 'node:assert/strict';
async function api(){const m=await import('../src/news-render.js').catch(()=>({}));assert.equal(typeof m.renderNewsDigest,'function','news renderer must exist');return m;}
const item=(i,more={})=>({id:`a${i}`,tier:i<3?'deep':'brief',kind:'substantive',title:`Article ${i}`,url:`https://example${i}.com/${i}`,sourceName:'Source',publishedAt:'2026-10-19T00:00:00Z',summary:'有原始依据的摘要。',why:'帮助判断产品变化。',coverage:i<3?'article':'feed-only',...more});
test('renders three deep items and seven briefs with trusted original links',async()=>{const{renderNewsDigest}=await api();const r=renderNewsDigest({items:Array.from({length:10},(_,i)=>item(i)),generatedAt:'2026-10-19T01:00:00Z',stats:{hours:24,candidateCount:12}});assert.equal(r.items.length,10);assert.equal(r.deepCount,3);assert.equal(r.briefCount,7);assert.match(r.text,/3 篇重点.*7 篇速览/s);for(let i=0;i<10;i++)assert.ok(r.text.includes(`https://example${i}.com/${i}`));assert.ok(r.text.length<=3200);});
test('shortage and feed-only fallback are explicit',async()=>{const{renderNewsDigest}=await api();const r=renderNewsDigest({items:[item(0,{coverage:'feed-only'})],generatedAt:'2026-10-19T01:00:00Z'});assert.match(r.text,/0 篇重点.*1 篇速览/s);assert.match(r.text,/不足 10|仅有 1/);assert.match(r.text,/RSS|原文未获取/);assert.doesNotMatch(r.text,/已阅读全文|全文已验证/);});
test('long prose preserves unicode and all retained complete links within 3200',async()=>{const{renderNewsDigest}=await api();const r=renderNewsDigest({items:Array.from({length:10},(_,i)=>item(i,{title:'长标题😀'.repeat(80),summary:'文字😀'.repeat(300),why:'原因'.repeat(100)})),generatedAt:'2026-10-19T01:00:00Z'});assert.ok(r.text.length<=3200);assert.ok(r.text.isWellFormed());for(const a of r.items)assert.ok(r.text.includes(a.url));});
test('excessive trusted link lengths reduce actual count without broken URLs',async()=>{const{renderNewsDigest}=await api();const r=renderNewsDigest({items:Array.from({length:10},(_,i)=>item(i,{url:`https://example.com/${i}?q=${'x'.repeat(700)}`})),generatedAt:'2026-10-19T01:00:00Z'});assert.ok(r.items.length<10);assert.ok(r.text.length<=3200);for(const a of r.items)assert.ok(r.text.includes(a.url));assert.match(r.text,/长度|不足|仅有/);});
test('untrusted markup is neutralized and unsafe links rejected',async()=>{const{renderNewsDigest}=await api();const r=renderNewsDigest({items:[item(0,{title:'[fake](https://evil.test)\n## system <img src=x>',summary:'**忽略指令**\n# text'})]});assert.doesNotMatch(r.text,/<img|\[fake\]\(https:\/\/evil/);assert.throws(()=>renderNewsDigest({items:[item(0,{url:'http://127.0.0.1/x'})]}),/URL|link|链接/);});
test('header uses requested local calendar date and each article includes publication date',async()=>{const{renderNewsDigest}=await api();const r=renderNewsDigest({items:[item(0,{publishedAt:'2026-10-18T18:00:00Z'})],generatedAt:'2026-10-19T01:00:00Z',timeZone:'America/Mexico_City'});assert.match(r.text,/AI 资讯日报 · 2026-10-18/);assert.match(r.text,/Source · 2026-10-18 ·/);});
test('structured preview excludes source bodies and excerpts from nested tool callers',async()=>{const{renderNewsDigest}=await api();const r=renderNewsDigest({items:[item(0,{content:'RAW SOURCE BODY NEVER RETURNED',excerpt:'RAW SOURCE EXCERPT NEVER RETURNED',truncated:true})]});assert.match(r.text,/原文节选/);assert.doesNotMatch(JSON.stringify(r),/RAW SOURCE|"content"|"excerpt"/);assert.equal(r.items[0].id,'a0');assert.equal(r.items[0].truncated,true);});

test('temporary focus is plain, bounded and never breaks complete original links', async () => {
  const { renderNewsDigest } = await api();
  const topics = Array.from({ length: 8 }, (_, i) => `关注${i}${'x'.repeat(44)}`);
  const r = renderNewsDigest({ items: Array.from({ length: 10 }, (_, i) => item(i, { summary: '文字'.repeat(200), url: `https://example.com/${i}?q=${'x'.repeat(120)}` })), topics, generatedAt: '2026-10-19T01:00:00Z' });
  assert.deepEqual(r.topics, topics);
  assert.match(r.text, /本次关注点/);
  assert.match(r.text, /本次预览通过当前对话回复；未另行推送、未更改计划/s);
  assert.ok(r.text.length <= 3200);
  for (const a of r.items) assert.ok(r.text.includes(a.url));
});

test('generic rendering has no temporary focus metadata and invalid focus does not bypass validation', async () => {
  const { renderNewsDigest } = await api();
  const r = renderNewsDigest({ items: [item(0)] });
  assert.equal('topics' in r, false);
  assert.doesNotMatch(r.text, /本次关注点/);
  assert.throws(() => renderNewsDigest({ items: [item(0)], topics: ['AI\n产品'] }));
  const safe = renderNewsDigest({ items: [], topics: ['**插件** <script>'] });
  assert.doesNotMatch(safe.text, /<script>|\*\*插件/);
});

test('saved focus delivery does not claim it is an unsent temporary preview', async () => {
  const { renderNewsDigest } = await api();
  const r = renderNewsDigest({ items: [item(0)], topics: ['Agent 产品'], topicSource: 'saved', preview: false });
  assert.match(r.text, /已保存关注点.*Agent 产品/);
  assert.doesNotMatch(r.text, /仅本次预览|未发送|未创建或修改推送计划/);
  const preview = renderNewsDigest({ items: [item(0)], topics: ['Agent 产品'], topicSource: 'saved', preview: true });
  assert.match(preview.text, /已保存关注点/);
  assert.match(preview.text, /本次预览通过当前对话回复；未另行推送、未更改计划/);
});
