# 连接邮箱、日历、云盘、笔记和清单

本页面向 `0.12.0-preview.4`，安装入口见[安装说明](install.md)。本版为普通 Google 三件套、单独日历的点击登录增加授权前用途说明，以及 macOS Keychain 密钥 + AES-256-GCM 本机凭据存储；旧普通明文授权仅在明确查询前受控迁移。滴答继续使用只读 Open API、保持 `tasks:read`；flomo 需要 MAX。此前日常 `0.12.0-preview.3` 已有滴答清单与 flomo 有限搜索证据，Google 有限读取来自更早阶段；这些历史记录不代表本版已在日常 App 升级。本版另于 2026-10-23 在隔离官方 Host 重启后，完成本人确认的另一 Google 账号三项有界读取；未覆盖任意账号或完整新用户开箱。源码、宿主与真实读取分别见[验证记录](verification.md)。

## 普通使用

1. 在「DSH Dot → 连接与设置」先阅读用途说明和隐私链接，再点击「同意并连接 Google」，前往 Google 官方页面登录并同意只读权限。无需创建 Cloud 项目或填写 Token、Client ID、密钥。
2. 返回 Dot，授权状态会自动更新；如果关闭过页面，可以手动刷新。只同意部分权限时，页面只显示真正已获授权的来源。
3. 启用需要的 Gmail、日历、Drive。可以说「查未来 24 小时的安排」「搜索关于项目的邮件」「在云盘找季度计划」。首次启用只核对读取合同，真实查询成功才证明 API 可以读取。
4. 日历读取主日历，默认未来 24 小时、最多七天十项。邮件与文件搜索每次最多十项，不自动翻页；再明确选择想读的内容。文档与幻灯片取纯文本，表格读取指定范围，最多 200 行、26 列、2000 格。图片/PDF 等不支持的文件格式会明确说明，不能当作空文档。
5. flomo、滴答清单分别点官方登录；flomo 需要 MAX。此前日常 `0.12.0-preview.3` 已完成 flomo 两条关键词搜索及滴答两项清单的真实读取；滴答普通账号走只读 API，不增加原 MCP 要求的写权限。任务正文与其他操作的证据范围见验证记录。

2026-10-22 最近一次控制台回读为 **External / In production**，显示累计 1 位用户、生命周期 100 位用户 cap，并仍需验证；2026-10-23 实读后没有再次回读名单或累计数。非测试名单账号可以尝试本人授权，不再逐个登记；未验证提示、组织账号策略和 cap 仍可能限制访问。本人确认的另一账号已在本版隔离官方 Host 完成授权后的三项有界读取；账号区别来自本人确认，没有追加 email/sub scope 或独立身份请求，也未核实该账号是否列于 Cloud 测试名单。品牌与 scope 验证尚未确认通过，不能宣传所有读者安装后已经可用。Search Console 项目 URL-prefix 已验证，品牌校验等待所有权同步；Google 提示可能需 24 小时，scope 入口当前不可提交，尚未提交 scope 审核。此前本人账号在 Testing 阶段的验收范围保留为历史，不把它改写成新用户实测。

桌面应用注册随源码分发的依据、用户 token 的边界和公众审核限制见[Google 桌面登录与公开分发说明](google-desktop-oauth.md)。

## 三件套权限与数据去向

普通连接申请三项只读 scope：`gmail.readonly`、`calendar.events.readonly`、`drive.readonly`。Docs/Sheets/Slides 的有限读取复用 Drive 权限，不另外申请写权限。Google 的 scope 范围比一次查询范围广，Dot 在代码里继续限制请求数量、文件/时间范围和只读操作。

目前连接后仅按需读取，没有私人资料持续扫描或主动订阅。项目日报与AI资讯日报不等于私人邮箱/清单监控。

此前 `0.12.0-preview.3` 的授权保存于自己的 Harness 原生 profile secret 配置；隐藏表单和文件权限不能当作加密证明。本版为普通 Google 三件套、单独日历的点击登录增加了 macOS Keychain 密钥 + profile AES-256-GCM 密文封装；访问令牌只在内存中缓存。密文绑定具体 Harness 配置位置、插件实例及授权种类。Keychain 不可用或密文不匹配时不会回退到明文。已有这两类明文授权只在用户明确查询、即将获取 Google 令牌前经过 guard 与原生 revision CAS 后迁移；重新点击登录可直接用新授权替换。状态查询、页面刷新不迁移或写配置。源码检查与本轮隔离 Host 有限实测不能代替日常安装、旧明文真实迁移、长期运行和完整新用户开箱，见[公众接入准备](google-public-onboarding.md)。

安全存储补强不覆盖手填高级 `googleRefreshToken`、flomo/滴答凭据、Harness 会话或历史备份，也不会自动加密旧备份。没有 Dot 中央服务器集中代存 Google 令牌。明确读取的结果会进入 Harness 会话，可能发给所配置的模型并进入宿主日志；通过微信回复还会经过微信桥接和微信通道。不能承诺所有资料永不离开电脑。`personal_context` 不自动写入长期项目记忆；但若会话所属项目已被关注，用户/助手摘要可被收为项目近期记录。连接启用关系只保存会话与凭据指纹，最近读取时间为进程内状态。

已保存的 Calendar-only 连接独立保留并优先使用，升级不会静默换成三件套账号。重新授权或更换微信绑定后需重新启用相应来源；同一连接自动刷新令牌不要求重新启用。存在三件套记录时，即使失效或缺少某项权限，也不会偷用旧 MCP 账号补读。

停用来源会中断当前待返回读取。清空本机 profile 授权字段会移除当前引用并停止使用；这不等于删除所有 Keychain 遗留项、已共享内容或历史备份，也不等于撤销 Google 账号里的 OAuth 许可。会话、宿主记录、项目摘录、模型和微信中的副本须分别管理。外部材料只作资料，不作为新的操作指令。

## 当前证据

| 环节 | 已验证范围 |
| --- | --- |
| 独立项目 | 专用 dsh-dot，Desktop 客户端；没有复用 Finvo 既有生产配置。 |
| 日历真实授权 | 本人已在官方页面同意；生产 OAuth 控制器在独立官方 Web Host 保存成功。 |
| 日历真实读取 | primary 主日历，2026-10-22T07:50:17.056Z 至 2026-10-29T07:50:17.056Z，最多十项，返回零项。仅证明该窗口成功返回，不代表账号没有日程。 |
| 冷启动刷新 | 重启同一独立宿主后，无新同意即可读同一窗口。 |
| 日常 App | 0.12.0-preview.3 已通过官方安装器升级并重开，官方管理页显示启用、一组件运行。安装后七个状态文件字节不变，cordis/patch/workspace 配置、其他插件依赖及启用列表保留；Google 三来源保留，flomo/滴答已恢复日常 Dot 启用，微信已连接，零待触发提醒、项目日报关闭。实读后五个状态文件仍字节不变，项目仅更新观察记录与会话ID，Context租约按临时启停及恢复而变化，计划未变。 |
| 日常三件套历史路径 | 本人在日常 preview.1 完成三项只读同意。Gmail 搜索三封、读取一封限长正文；日历七天返回零项；Drive 搜索十个匹配项。当时未实测 Drive 文档正文、非空日程与手机展示；不改写为本版验收。 |
| 本版另一账号 | 2026-10-23 06:34Z，本人确认的另一 Google 账号已完成授权；在已安装 preview.4 的隔离官方 Host 重启后，Gmail 近七天搜索、primary 日历未来 24 小时、Drive 文件名含小写 a 的首页搜索各 limit1，均返回一项并标裁剪，日历 hasMore。Gmail 仅搜索元数据（可含不超过 1200 字符的 snippet），不读完整邮件或附件；Drive 仅元数据，不读文档正文。逐项断开后，已有一项目、零计划、零提醒、零 outbox 前后一致；Host 正常停止。未调用模型或发送微信。 |
| flomo / 滴答 | 本人已完成两家官方登录。preview.3 原生 personal_context 实读：滴答 projects limit2 返回两项来源并有裁剪提示；flomo 搜索 DeepSeek limit2 返回两条、无裁剪提示。本轮仅一次会话、该工具，无微信发送或新计划；临时会话断开两来源后，原生页面恢复日常 Dot 启用。滴答仅验证清单元数据，任务正文未验；flomo 未读取 AI 画像。 |
| 公众受众配置 | 2026-10-22 控制台回读 External / In production，累计 1 / 100 位用户且需要验证；Search Console 已确认项目 URL-prefix 所有权。未验证提示与 scope/品牌审核仍须处理；另一账号已完成上述有界读取，但名单及新的累计数未回读，不以受众标签或单账号结果代替所有新用户实测。 |

早期日历独立宿主使用明确 fixture owner，真实微信桥接禁用，未发微信或创建计划。其私有授权没有迁入日常 App；日常 App 已另外完成本人三件套登录。本版已验非空日历的有界工具返回，但日常 App 和手机呈现未验；滴答任务正文、Drive 文档正文、长期令牌刷新、真实撤销/清除与手机展示仍分别待验；已验过一次日历冷启动刷新不等于长期可靠性通过。完整证据见[验证记录](verification.md)。

## 实现与官方协议

三件套与单独日历分别保存授权记录。均使用 Desktop public client、S256 PKCE、随机 127.0.0.1 回调、一次性 state/code、五分钟有效期、当前 owner/绑定/暂停检查及原生 revision CAS。刷新不扩大 scope。installed apps 不使用 incremental authorization 自动合并权限。

REST 只访问代码固定的 Google HTTPS 地址，拒绝重定向，设超时和响应字节上限，不跟随消息、文档里的链接。Gmail 搜索只读有限元数据，正文读取不下载附件、不执行 HTML；无可用纯文本时保留摘要并标注不完整。Drive 仅查标题与读取明确文件，Docs/Slides 通过纯文本导出，Sheets 通过指定 range 读取。取得令牌、发送请求和交付返回前都复查来源仍被启用。

一手来源（2026-10-22 核对）：[Desktop OAuth](https://developers.google.com/identity/protocols/oauth2/native-app)、[Gmail list](https://developers.google.com/workspace/gmail/api/reference/rest/v1/users.messages/list)、[Gmail get](https://developers.google.com/workspace/gmail/api/reference/rest/v1/users.messages/get)、[Drive get](https://developers.google.com/workspace/drive/api/reference/rest/v3/files/get)、[Drive export](https://developers.google.com/workspace/drive/api/reference/rest/v3/files/export)、[Sheets values.get](https://developers.google.com/workspace/sheets/api/reference/rest/v4/spreadsheets.values/get)、[Calendar events.list](https://developers.google.com/workspace/calendar/api/v3/reference/events/list)、[Google Testing 受众](https://support.google.com/cloud/answer/15549945)。

## Google 官方 remote MCP（高级兼容）

采用 Google 托管的 Streamable HTTP 服务，无需将社区 Google 服务端或作者的账户配置打包给用户：

| 来源 | 固定端点 | 首版只读工具示例 |
| --- | --- | --- |
| Gmail | `https://gmailmcp.googleapis.com/mcp/v1` | `search_threads`、`get_message` |
| Calendar（保留协议研究，当前普通入口不走此路） | `https://calendarmcp.googleapis.com/mcp/v1` | `list_events` |
| Drive | `https://drivemcp.googleapis.com/mcp/v1` | `search_files`、`read_file_content` |
| Docs | `https://docsmcp.googleapis.com/mcp/v1` | `read_doc` |
| Sheets | `https://sheetsmcp.googleapis.com/mcp/v1` | `get_values` |
| Slides | `https://slidesmcp.googleapis.com/mcp/v1` | `read_presentation` |

官方仍将这些服务标为 Developer Preview。用户需要加入 Google Workspace Developer Preview Program，有自己的 Google Cloud 项目并启用产品 API 和 MCP API。OAuth 客户端需要勾选 `Use this client for an AI-powered agent`。这不是装完 Dot 就自动完成的 Google 授权。

官方 Gemini CLI 教程创建 Desktop app OAuth client；Claude 与 Antigravity 示例使用各自回调 URL 的 Web application client。Dot 必须使用为自身配置的客户端和用户同意流程，不能复用作者的 Codex、Gemini、Chrome、gws 或其他客户端凭据。产品 OAuth 与 Google 模型订阅 OAuth 也不是同一件事。

旧高级 Google 授权页仍一次申请以下七个只读 scope（普通三件套仅申请前文的三项，不使用旧记录）；实际来源仍须逐项启用，不代表允许扫描整个账号：

- Gmail：`https://www.googleapis.com/auth/gmail.readonly`
- Calendar：`https://www.googleapis.com/auth/calendar.calendarlist.readonly` 与 `https://www.googleapis.com/auth/calendar.events.readonly`
- Drive：`https://www.googleapis.com/auth/drive.readonly`
- Docs：`https://www.googleapis.com/auth/documents.readonly`
- Sheets：`https://www.googleapis.com/auth/spreadsheets.readonly`
- Slides：`https://www.googleapis.com/auth/presentations.readonly`

官方配置教程同时展示读写功能，不应把其中的 `gmail.compose`、`drive.file` 或文档写权限直接加入只读版本。读取共享日历需要日历列表 scope；只读到主日历不能声明覆盖了所有日历。

Google 刷新授权要求 `access_type=offline`，已同意的用户重新取得 refresh token 还可能需要 `prompt=consent`。公有 OAuth metadata 支持 S256 PKCE，没有发布可发现的动态客户端注册端点。`gmailmcp.googleapis.com/.well-known/oauth-protected-resource/mcp/v1` 的 metadata 可公开读取；这不代表任何私人邮箱已经连接。

字段须遵循 MCP 版本，不能套用原 REST API 参数：

- `search_threads` 使用 `query/pageSize/pageToken/includeTrash/view`，返回 `threads[].messages[]`；Message 正文是 `plaintextBody`，不是 REST 的 `payload.body.data`。
- `list_events` 使用 `startTime/endTime/timeZone/calendarId/pageSize`；不是 REST 的 `timeMin/timeMax`。
- `search_files` 的查询字段使用 `title`；返回文件的 `title/viewUrl/contentSnippet`。
- `read_file_content` 返回 `fileContent` 和 `textFormattingNotSupported`，不支持转文本不能当作空文档。
- `read_doc` 使用 `documentId/commentsIncluded`，返回 `content` 对象。
- `get_values` 使用 `spreadsheetId/range`。
- `read_presentation` 使用 `presentationId/fields/commentsIncluded`，返回 `content` 对象。`fields` 应限定必要字段，例如 `title` 与 `slides.pageElements(objectId,shape.text)`。

一手说明与 schema：

- [配置 Google Workspace MCP](https://developers.google.com/workspace/guides/configure-mcp-servers)
- [Gemini CLI 官方 codelab](https://codelabs.developers.google.com/google-workspace-mcp-gemini-cli)
- [Gmail search_threads](https://developers.google.com/workspace/gmail/api/reference/mcp/tools_list/search_threads)
- [Gmail get_message](https://developers.google.com/workspace/gmail/api/reference/mcp/tools_list/get_message)
- [Calendar list_events](https://developers.google.com/workspace/calendar/api/v3/reference/mcp/tools_list/list_events)
- [Calendar list_calendars](https://developers.google.com/workspace/calendar/api/v3/reference/mcp/tools_list/list_calendars)
- [Drive search_files](https://developers.google.com/workspace/drive/api/reference/mcp/tools_list/search_files)
- [Drive read_file_content](https://developers.google.com/workspace/drive/api/reference/mcp/tools_list/read_file_content)
- [Docs read_doc](https://developers.google.com/workspace/docs/api/reference/mcp/tools_list/read_doc)
- [Sheets get_values](https://developers.google.com/workspace/sheets/api/reference/mcp/tools_list/get_values)
- [Slides read_presentation](https://developers.google.com/workspace/slides/api/reference/mcp/tools_list/read_presentation)

## 滴答与 flomo

- 滴答普通 OAuth 从 preview.3 起使用[官方 Open API](https://developer.dida365.com/docs/openapi.md)的只读 GET，已用现有 tasks:read 在实际安装版读取两项清单。旧手填 Token 的官方 MCP 固定使用 `https://mcp.dida365.com`，不猜测或追加 `/mcp` 路径。[官方 OAuth metadata](https://dida365.com/.well-known/oauth-authorization-server) 发布动态客户端注册与 S256 PKCE；[MCP 资源 metadata](https://mcp.dida365.com/.well-known/oauth-protected-resource)发布 `tasks:read` 与 `tasks:write`，Dot 只申请 `tasks:read`。[官方 Open API 授权文档](https://developer.dida365.com/docs/index.html#/openapi?id=authorization)也说明账号同意流程与上述权限。metadata 仅声明 `authorization_code`，因此 Dot 不猜测滴答支持刷新授权，过期后需重新连接。
- flomo 官方端点为 `https://flomoapp.com/mcp`。[官方自动授权教程](https://help.flomoapp.com/advance/mcp/connect-chatgpt-web.html)明确支持 OAuth 且无需个人 Token；[官方 OAuth metadata](https://flomoapp.com/.well-known/oauth-authorization-server)发布动态客户端注册、S256 PKCE 和刷新授权；[MCP 资源 metadata](https://flomoapp.com/.well-known/oauth-protected-resource)发布 `mcp` scope。flomo 当前没有公开更细的只读 OAuth scope，因此 Dot 的只读边界由下述工具白名单继续强制执行，不把账号授权范围描述成服务端只读许可。仍需 flomo MAX。
- 默认连接由用户点击后才注册此客户端、生成一次性授权链接，再由用户亲自在官方页面登录与同意。Dot 不接收账号密码，不复用作者或其他客户端的令牌；页面挂载和状态刷新不会注册客户端、开始登录或查询账号。
- 本机回调仅绑定 `127.0.0.1` 随机端口，授权有效期五分钟；校验原始 Host、回调路径、单值 state、可选 issuer 与 PKCE，授权码只交换一次。固定官方 HTTPS 端点拒绝重定向；HTTP、响应体与关闭取消均有上限。配置变化后的旧回调与旧刷新响应不能保存；关闭会中断请求并关闭回调监听。
- 授权流程绑定开始时的原对话、微信绑定和暂停状态，在注册、换码、保存及原生写入前重新验证。凭据写入同时核对原 OAuth 字段、兼容 Token 字段与原生配置 revision；授权期间清空、更换凭据不会被迟到回调覆盖；已换绑后到达的回调会被拒绝。原绑定检查以派发原生保存请求为界，不能原子撤销已进入其他插件事务的操作。刷新授权也使用相同的配置比较与当前来源授权检查。
- OAuth 凭据保存在本插件的原生 secret 配置中，连接状态仅返回布尔值和授权链接失效时间。flomo 刷新令牌轮换会保存新值；滴答仅保存有界访问令牌。服务端未提供过期秒数时，Dot 最多复用一小时；令牌不会因缺少到期字段无限期有效。
- 个人 Token 仍可按[官方 Token 教程](https://help.flomoapp.com/advance/mcp/token.html)作为高级兼容方式使用。存在 OAuth 凭据时，授权失效会明确要求重新连接，不悄悄回退到另一个账号的 Token。清除本机凭据与撤销服务商许可是两项操作；flomo 可在「设置 → MCP / API → MCP → OAuth 授权模式 → 应用列表」断开。
- 这两个端点都可能发布写工具。连接后也必须 exact-name 白名单与输入校验，不能因为工具描述声称只读就执行，不能在找不到工具时回退至第一项工具。
- flomo 搜索摘要与全文读取有不同截断边界；读取结果需要保留 `content_truncated/omitted_ids/truncated` 等标记。
- 不默认调用外部 AI 画像工具；来源内容不会自动升级为个人稳定事实或项目记忆。

## 传输层与当前验证范围

Google 普通连接与滴答普通 OAuth 走固定官方只读 REST；flomo、手填滴答 Token 及旧 Google 高级兼容走固定官方 MCP。所有来源都经过 exact-name 白名单、有界输入、owner/绑定/启用状态检查；资料内容不能改变工具权限。

三件套的合成测试覆盖部分授权、无 scope、拒绝后重试、一次性回调、并发 CAS、刷新、暂停/换绑/关闭，以及 Gmail/Drive/Sheets 读取的超时、字节与条数边界。这些合成测试只验证代码控制流。此前本人已完成 Gmail/日历/Drive 真实同意、邮件搜索及限长正文、日历空窗口、云盘文件名搜索；日历独立宿主也完成过冷启动刷新。本版另已完成本人确认的另一账号在隔离 Host 重启后的三项各一项读取，包含非空 primary 日历；Drive 正文、任意公众账号、日常 App 升级、微信和模型体验未由此证明，具体范围见上表。

## 可选复用路线与许可证

未将以下项目代码加入传输层：

- [googleworkspace/cli v0.22.5](https://github.com/googleworkspace/cli/releases/tag/v0.22.5)，Apache-2.0。统一 Workspace CLI，但 README 明确非受官方支持的 Google 产品；仍需自有 GCP client。若后续启用，必须隔离配置目录及环境，不能继承作者的 gws 凭据或当前项目 `.env`。
- [taylorwilsdon/google_workspace_mcp v2.1.0](https://github.com/taylorwilsdon/google_workspace_mcp/releases/tag/v2.1.0)，MIT。支持只读与 OAuth，但会增加 Python 服务，且同样需要自己的 OAuth client。
- [PerryLink/dsh-ticktick](https://github.com/PerryLink/dsh-ticktick/tree/6c922556e66e9bd235a266ad82fef352b3f6339a)，Apache-2.0。参考了其公开协议接入方向，没有复制实现。当前 Dot 的 JSON/SSE 和会话实现为独立编写。

官方文档链接是协议与服务出处，不表示本项目为官方插件、获得平台背书或取得第三方代码的版权。

### 滴答普通登录的读取范围

普通 OAuth 使用官方 Open API，保留 `tasks:read`。清单只取首批（最多10项），指定单个清单后读取其中任务（最多展示10条，响应上限1MiB），或者指定清单和任务读取一条。另支持账户级只读搜索：按标题、正文或备注跨清单搜索，单次最多返回 50 条并标记截断；内部最多枚举 1000 个清单、每个清单最多 1000 条任务、3 并发，超出直接失败而不是静默截断。不自动翻页。手填旧 token 的高级 MCP 路径保留；普通 OAuth 失败不会改用它。
