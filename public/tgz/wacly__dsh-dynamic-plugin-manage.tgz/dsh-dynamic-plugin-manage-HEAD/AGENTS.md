# AGENTS.md

给 DeepSeek Harness（`dsh`）动态插件补「持久化」：把当前会话的动态插件导出到磁盘仓库，之后按需 `define` + `run` 重放。磁盘目录默认 `~/.dsh/dynamic-plugins/`（有 `$DSH_HOME` 则用 `$DSH_HOME/dynamic-plugins/`）。

每个插件是一个**包**（目录），含 `define.json`（元信息 + code 文件引用）+ `host.js` / `client.js`（源码抽离）。

## 代码地图

- `src/index.ts` — host 半边：三个模型工具（`export/list/load_dynamic_plugins`）+ `/api/dynamicPlugins/*` HTTP 路由 + `DynamicPluginsApi`。入口 `apply(ctx)`。
- `src/types.ts` — 前后端共享的 wire 类型（纯 JSON 载荷）。
- `src/client/index.ts` — 浏览器半边：注入设置页栏目、调用 HTTP 路由、MutationObserver 替换导航图标。
- `src/client/DynamicPluginsSettingsSection.tsx` — 设置页 UI（无 JSX，用 `createElement`）。
- `src/client/locales.ts` — 中文/英文文案。
- `cordis.patch.yml` — bundle 配置层，挂载 host 插件。
- `tsdown.config.ts` — 双半边构建配置。
- `docs/architecture.md`、`docs/development.md` — 架构与开发文档。

## 关键约定

- **host 通信走普通 HTTP 路由**（`/api/dynamicPlugins/*`，exact 路由，POST `{ args }` → `{ ok, value|error }`），**不用 Typert Remote 服务**。因此本插件**不依赖** `@deepseek-ai/dsh-typert-protocol`，也不存在与 gateway 共享模块实例的问题。
- **依赖**：只用 `@deepseek-ai/dsh-tools`（`defineTool`）和 `@deepseek-ai/dsh-host-webserver`（仅 `WebRoute` 类型，构建期擦除）。依赖保持 external，不落到 `node_modules`。
- **包名规则**：导出时包名 = pluginId 去掉尾部数字后缀（`mychat-12` → `mychat`）。同包名覆盖，不同名另存。
- **加载语义**：每次 `define` 会 mint 新的 pluginId/packageId；插件归属发起加载的会话；带 client 半边可能返回 `awaiting-approval`。
- **设置页「导入」是静默的**：host 只 `define`，浏览器半再走 `dynamicCordisRunner.startUserRun`（用户手势路径，`agent.inject`），不唤醒模型。
- **UI 不用 JSX**：`DynamicPluginsSettingsSection.tsx` 用 `createElement as h`，避免依赖特定 JSX 转换。
- **导航图标**：设置 shell 按 section id 硬编码图标（在 deepseek-harness 里），插件不能改，只能通过 MutationObserver 打 DOM 补丁替换。

## 硬约束

- **不要修改主仓库 `deepseek-harness`**（含 CordisPanel）。所有改动只在本插件内。
- JSON schema 的 `parameters` 若含嵌套对象，`additionalProperties` 必须显式设为 `true` 或 `false`，否则编译器抛 `UNSUPPORTED_SCHEMA`。
- 不要引入 `link:` 依赖或独立一整套 `@deepseek-ai/dsh-typert-protocol` 到本插件 `node_modules`（会造成 Remote 装饰器标记分属不同模块实例，路由注册不上，404）。

## 构建与验证

```sh
pnpm install      # 只装 tsdown，@deepseek-ai/* 保持 external
pnpm run build    # 产物 lib/index.js（host）+ lib/client.js（browser）
```

- 产物：`lib/index.js`（ESM，host）；`lib/client.js`（CJS closure-factory，浏览器）。
- 安装运行：在主仓库 `deepseek-harness` 下 `pnpm dsh plugin --profile demo add <本插件绝对路径>`，然后 `pnpm dsh --profile demo web`。
- **改完代码必须重启 dsh**：host 半边只在启动时加载，客户端 HMR 不会重载宿主侧。

## 常见坑

- 旧格式顶层 `<pluginId>.json`（内联 code）需要迁移：`list`/`load` 时自动迁移，先写入并校验新包、确认无误才删旧文件。
- 直接对比「本批次已占用包名」会导致覆盖磁盘上已改名的插件；需同时对比磁盘上已存在包的 `readManifest().name`。
- 全局 `dsh` 通过软链指向本地代码时，纯 Node 会 realpath 解析插件路径，找不到 `~/.dsh/profiles/node_modules` 里的依赖；所以依赖要显式声明在 `package.json`（peerDependencies + devDependencies），不要依赖软链。