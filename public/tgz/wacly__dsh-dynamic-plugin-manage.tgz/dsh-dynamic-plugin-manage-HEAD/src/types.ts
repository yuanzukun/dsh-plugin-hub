/**
 * Wire types shared by the Host HTTP route handlers and the browser fetch
 * client. These are plain JSON payloads; no Host references cross the wire.
 *
 * The Host half serves `/api/dynamicPlugins/<method>` as plain HTTP routes
 * (the dsh-web-ui convention) instead of Typert Remote services, so no
 * `@deepseek-ai/dsh-typert-protocol` artifact or shared module instance is
 * involved.
 */

/** One package entry the Settings panel renders. */
export interface DynamicPluginsEntry {
  package: string
  name: string
  purpose: string
  hasHostHalf: boolean
  hasClientHalf: boolean
}

/** Result of `dynamicPlugins/list`. */
export interface DynamicPluginsListResult {
  dir: string
  count: number
  packages: DynamicPluginsEntry[]
}

/** Result of `dynamicPlugins/load`. */
export interface DynamicPluginsLoadResult {
  dir: string
  loaded: number
  results: Array<{
    package: string
    ok: boolean
    pluginId?: string
    packageId?: string
    hasClientHalf?: boolean
    status?: string
    error?: string
  }>
}

/** Result of `dynamicPlugins/exportSession`. */
export interface DynamicPluginsExportResult {
  dir: string
  count: number
  exported: Array<{
    pluginId: string
    package: string
    name: string
    path: string
  }>
}

/** Result of `dynamicPlugins/updatePackage`. */
export interface DynamicPluginsUpdateResult {
  ok: boolean
  package: string
  name?: string
  purpose?: string
  error?: string
}

/** Result of `dynamicPlugins/removePackage`. */
export interface DynamicPluginsRemoveResult {
  ok: boolean
  package: string
  error?: string
}

/** One loaded plugin's runtime state, as surfaced by `dynamicPlugins/runtime`. */
export interface DynamicPluginsRuntimeEntry {
  pluginId: string
  name: string
  purpose: string
  hasHostHalf: boolean
  hasClientHalf: boolean
  /** Whether the plugin currently has an active run. */
  running: boolean
  /** Package identity of the active run, when running. */
  activeRunPackageId?: string
  /** Immutable package versions, in define order. */
  packages: Array<{
    packageId: string
    name: string
    hasHostHalf: boolean
    hasClientHalf: boolean
  }>
}

/** Result of `dynamicPlugins/runtime`. */
export interface DynamicPluginsRuntimeResult {
  sessionId: string
  count: number
  plugins: DynamicPluginsRuntimeEntry[]
}

/** Result of `dynamicPlugins/unload`. */
export interface DynamicPluginsUnloadResult {
  ok: boolean
  pluginId: string
  error?: string
}

/** Result of `dynamicPlugins/reload`. */
export interface DynamicPluginsReloadResult {
  ok: boolean
  pluginId: string
  status?: string
  error?: string
}
