/**
 * Model-facing tools that persist and replay dynamic Cordis plugins, plus the
 * Host HTTP route family that powers the Web Settings "dynamic plugins" panel.
 *
 * `cordis_define` keeps definitions in process memory only — a restart loses
 * them. This plugin closes that gap with a fixed on-disk directory
 * (`~/.dsh/dynamic-plugins` by default, or `$DSH_HOME/dynamic-plugins`), where
 * each dynamic plugin is stored as a **package** (a directory):
 *
 * ```
 * <dir>/<packageName>/
 *   define.json   # name, purpose, idPrefix + code file references
 *   host.js       # host half source body (when present)
 *   client.js     # client half source body (when present)
 * ```
 *
 * `define.json` carries everything `cordis_define` needs EXCEPT the source,
 * which is split out into its own code file(s); the `code` field then only
 * references those files. The package name is the directory name — a
 * user-specified name on export, or the `pluginId` when none is given.
 *
 * Three model-facing tools:
 *   - `export_dynamic_plugins` — snapshot the current Session's dynamic plugins
 *     into packages (one package per plugin).
 *   - `list_dynamic_plugins`   — list the persisted packages.
 *   - `load_dynamic_plugins`   — selectively `cordis_define` + `cordis_run`
 *     persisted packages by name.
 *
 * One Host HTTP route family (`/api/dynamicPlugins/*`) for the browser:
 *   - `list` — the persisted catalog for the Settings panel.
 *   - `load` — one-click import of a persisted plugin into a live session.
 *
 * The routes are plain exact-path JSON routes registered on the dsh web server
 * (the dsh-web-ui convention), not Typert Remote services. This keeps the
 * plugin free of any `@deepseek-ai/dsh-typert-protocol` runtime dependency and
 * of the module-instance sharing that Typert's SRC fallback requires, so the
 * plugin works identically from a source checkout and from a profile install.
 *
 * @module dsh-dynamic-plugin-manage
 */

import { mkdir, readdir, readFile, rm, unlink, writeFile } from 'node:fs/promises'
import { homedir } from 'node:os'
import { isAbsolute, join, relative, resolve } from 'node:path'
import type { IncomingMessage, ServerResponse } from 'node:http'
import type { Context } from '@deepseek-ai/cordis'
import type { Agent } from '@deepseek-ai/dsh-agent'
import type { JsonValue } from '@deepseek-ai/dsh-session'
import { defineTool } from '@deepseek-ai/dsh-tools'
import type { ToolExecution } from '@deepseek-ai/dsh-tools'
import type { WebRoute } from '@deepseek-ai/dsh-host-webserver'
import type {
  DynamicPluginsExportResult,
  DynamicPluginsListResult,
  DynamicPluginsLoadResult,
  DynamicPluginsRemoveResult,
  DynamicPluginsReloadResult,
  DynamicPluginsRuntimeResult,
  DynamicPluginsUnloadResult,
  DynamicPluginsUpdateResult,
} from './types'

export const name = 'dynamic-plugin-manage'
export const inject = ['tools', 'dynamicCordisRunner', 'agents', 'webServer']

/** Directory name under the Harness home that holds persisted plugin packages. */
const DIR_NAME = 'dynamic-plugins'
/** Manifest filename inside every plugin package. */
const DEFINE_FILE = 'define.json'
/** Conventional code file names when a package has one source half. */
const HOST_CODE_FILE = 'host.js'
const CLIENT_CODE_FILE = 'client.js'

/**
 * One persisted plugin's manifest (`define.json`): the metadata `cordis_define`
 * needs, with `code` holding RELATIVE FILE references (inside the package)
 * instead of inline source bodies.
 */
interface PluginManifest {
  /** Short, readable package name (as passed to cordis_define). */
  name: string
  /** One-sentence user-facing purpose. */
  purpose: string
  /** Semantic id prefix (3–6 lowercase letters) reused on the next define. */
  idPrefix: string
  /** File references inside the package; at least one half must be present. */
  code: { host?: string; client?: string }
}

/** Resolved source bodies, read back from the referenced code files. */
interface ResolvedCode {
  host?: string
  client?: string
}

/** Resolve the persisted directory, honoring `$DSH_HOME` over the default `~/.dsh`. */
function dynamicPluginDir(): string {
  const envHome = process.env.DSH_HOME
  const home = envHome !== undefined && envHome.trim().length > 0
    ? envHome
    : join(homedir(), '.dsh')
  return join(home, DIR_NAME)
}

/** A dynamic-plugin tool runs inside an Agent-backed session; surface it clearly otherwise. */
function requireAgent(exec: ToolExecution): Agent {
  if (exec.agent === undefined) {
    throw new Error('dynamic-plugin tools require an Agent-backed session')
  }
  return exec.agent
}

/** Recover the semantic prefix from a `prefix-N` plugin id, with a safe fallback. */
function idPrefixOf(pluginId: string): string {
  const prefix = pluginId.replace(/-\d+$/, '')
  return prefix.length >= 3 ? prefix : 'dyn'
}

/**
 * Package (directory) name for an exported plugin: its pluginId with the
 * trailing numeric `-N` suffix removed (e.g. `mychat-12` → `mychat`). On
 * export a package with the same base name is overwritten; a plugin whose base
 * name differs from what is already on disk is saved as a new package.
 */
function candidateOf(pluginId: string): string {
  const base = pluginId.replace(/-\d+$/, '')
  return base.length > 0 && base !== pluginId ? base : pluginId
}

/** Plain JSON tool output. */
function renderJson(value: JsonValue): Array<{ type: 'text'; text: string }> {
  return [{ type: 'text', text: JSON.stringify(value, null, 2) }]
}

/** A package (directory) name must be a safe single path segment. */
function isSafePackageName(value: string): boolean {
  if (value.length === 0 || value === '.' || value === '..') return false
  if (value.includes('/') || value.includes('\\') || value.includes('\0')) return false
  return true
}

/**
 * Resolve a code-file reference against its package directory, rejecting any
 * path that would escape the package (absolute paths or `..` traversal).
 */
function resolveCodePath(packagePath: string, ref: string): string | undefined {
  const abs = resolve(packagePath, ref)
  const rel = relative(packagePath, abs)
  if (rel.length === 0 || rel.startsWith('..') || isAbsolute(rel)) return undefined
  return abs
}

/**
 * Read one package's `define.json` and normalize it to a {@link PluginManifest}.
 * @param packagePath - absolute path of the package directory.
 * @returns the parsed manifest, or `undefined` when the file is malformed.
 */
async function readManifest(packagePath: string): Promise<PluginManifest | undefined> {
  let parsed: unknown
  try {
    parsed = JSON.parse(await readFile(join(packagePath, DEFINE_FILE), 'utf8'))
  } catch {
    return undefined
  }
  if (typeof parsed !== 'object' || parsed === null) return undefined
  const manifest = parsed as Partial<PluginManifest>
  if (typeof manifest.name !== 'string') return undefined
  const code = typeof manifest.code === 'object' && manifest.code !== null ? manifest.code as Record<string, unknown> : {}
  const host = typeof code.host === 'string' ? code.host : undefined
  const client = typeof code.client === 'string' ? code.client : undefined
  if (host === undefined && client === undefined) return undefined
  return {
    name: manifest.name,
    purpose: typeof manifest.purpose === 'string' ? manifest.purpose : '',
    idPrefix: typeof manifest.idPrefix === 'string' && manifest.idPrefix.length >= 3 ? manifest.idPrefix : idPrefixOf(manifest.name),
    code: {
      ...(host === undefined ? {} : { host }),
      ...(client === undefined ? {} : { client }),
    },
  }
}

/** Read a single code file's text, or `undefined` on failure. */
async function readCodeFile(path: string): Promise<string | undefined> {
  try {
    return await readFile(path, 'utf8')
  } catch {
    return undefined
  }
}

/**
 * Read a package's manifest AND its referenced code files.
 * @returns the manifest plus resolved source bodies, or `undefined` when the
 * package is missing or any referenced file cannot be read.
 */
async function readPackage(dir: string, packageName: string): Promise<{ manifest: PluginManifest; code: ResolvedCode } | undefined> {
  const packagePath = join(dir, packageName)
  const manifest = await readManifest(packagePath)
  if (manifest === undefined) return undefined
  const code: ResolvedCode = {}
  if (manifest.code.host !== undefined) {
    const path = resolveCodePath(packagePath, manifest.code.host)
    const src = path === undefined ? undefined : await readCodeFile(path)
    if (src === undefined) return undefined
    code.host = src
  }
  if (manifest.code.client !== undefined) {
    const path = resolveCodePath(packagePath, manifest.code.client)
    const src = path === undefined ? undefined : await readCodeFile(path)
    if (src === undefined) return undefined
    code.client = src
  }
  return { manifest, code }
}

/**
 * Write one plugin package: the code files first, then `define.json`.
 * @param codeFileRefs - overrides the manifest's `code` refs (used by migration
 * to keep the conventional `host.js`/`client.js` names); defaults to the
 * manifest's own refs when omitted.
 */
async function writePackage(
  dir: string,
  packageName: string,
  manifest: PluginManifest,
  code: ResolvedCode,
  codeFileRefs?: { host?: string; client?: string },
): Promise<void> {
  const packagePath = join(dir, packageName)
  await mkdir(packagePath, { recursive: true })
  const refs = codeFileRefs ?? manifest.code
  if (code.host !== undefined) {
    await writeFile(join(packagePath, refs.host ?? HOST_CODE_FILE), code.host, 'utf8')
  }
  if (code.client !== undefined) {
    await writeFile(join(packagePath, refs.client ?? CLIENT_CODE_FILE), code.client, 'utf8')
  }
  await writeFile(join(packagePath, DEFINE_FILE), `${JSON.stringify(manifest, null, 2)}\n`, 'utf8')
}

/**
 * Read an old-format top-level `<pluginId>.json` (inline `code` strings) and
 * split it into the manifest + resolved code the new package format expects.
 * @param file - absolute path of the legacy JSON file.
 * @returns the pieces for migration, or `undefined` when the file is malformed.
 */
async function readLegacyRecord(file: string): Promise<{ manifest: PluginManifest; code: ResolvedCode } | undefined> {
  let parsed: unknown
  try {
    parsed = JSON.parse(await readFile(file, 'utf8'))
  } catch {
    return undefined
  }
  if (typeof parsed !== 'object' || parsed === null) return undefined
  const record = parsed as Partial<{ name: string; purpose: string; idPrefix: string; code: Record<string, unknown> }>
  if (typeof record.name !== 'string') return undefined
  const code = typeof record.code === 'object' && record.code !== null ? record.code : {}
  const host = typeof code.host === 'string' ? code.host : undefined
  const client = typeof code.client === 'string' ? code.client : undefined
  if (host === undefined && client === undefined) return undefined
  return {
    manifest: {
      name: record.name,
      purpose: typeof record.purpose === 'string' ? record.purpose : '',
      idPrefix: typeof record.idPrefix === 'string' && record.idPrefix.length >= 3 ? record.idPrefix : idPrefixOf(record.name),
      code: {
        ...(host === undefined ? {} : { host: HOST_CODE_FILE }),
        ...(client === undefined ? {} : { client: CLIENT_CODE_FILE }),
      },
    },
    code: {
      ...(host === undefined ? {} : { host }),
      ...(client === undefined ? {} : { client }),
    },
  }
}

/**
 * Migrate any old-format top-level `<pluginId>.json` files into packages.
 * Idempotent: a package is written and verified before its legacy file is
 * removed, so a failed conversion never loses data.
 * @returns the number of legacy files migrated.
 */
async function migrateLegacy(dir: string): Promise<number> {
  let entries
  try {
    entries = await readdir(dir, { withFileTypes: true })
  } catch {
    return 0
  }
  let migrated = 0
  for (const entry of entries) {
    if (!entry.isFile() || !entry.name.endsWith('.json')) continue
    const file = join(dir, entry.name)
    const legacy = await readLegacyRecord(file)
    if (legacy === undefined) continue
    const packageName = entry.name.slice(0, -'.json'.length)
    await writePackage(dir, packageName, legacy.manifest, legacy.code, legacy.manifest.code)
    const verified = await readPackage(dir, packageName)
    if (verified === undefined) continue
    try {
      await unlink(file)
    } catch {
      // Keep the legacy file when it cannot be removed; it is harmless.
    }
    migrated += 1
  }
  return migrated
}

/** One row of the persisted catalog, as the Settings panel (and tools) read it. */
interface PersistedPluginSummary {
  /** Package (directory) name — the identifier to pass to load. */
  package: string
  name: string
  purpose: string
  hasHostHalf: boolean
  hasClientHalf: boolean
}

/** List every valid persisted package, migrating any legacy files first. */
async function listPackages(dir: string): Promise<{ count: number; packages: PersistedPluginSummary[] }> {
  await migrateLegacy(dir)
  let entries
  try {
    entries = await readdir(dir, { withFileTypes: true })
  } catch {
    return { count: 0, packages: [] }
  }
  const packages: PersistedPluginSummary[] = []
  for (const entry of entries) {
    if (!entry.isDirectory()) continue
    const manifest = await readManifest(join(dir, entry.name))
    if (manifest === undefined) continue
    packages.push({
      package: entry.name,
      name: manifest.name,
      purpose: manifest.purpose,
      hasHostHalf: manifest.code.host !== undefined,
      hasClientHalf: manifest.code.client !== undefined,
    })
  }
  return { count: packages.length, packages }
}

/** The minimal face of `ctx.dynamicCordisRunner` this plugin consumes. */
interface DynamicCordisPluginInspectionLike {
  pluginId: unknown
  name: string
  purpose: string
  currentPackageId?: unknown
  activeRun?: { pluginRunId: unknown; packageId: unknown }
  packages: Array<{ packageId: unknown; name: string; hasHostHalf: boolean; hasClientHalf: boolean }>
}

interface DynamicCordisRunnerLike {
  define(input: {
    sessionId: string
    plugin: { kind: 'new'; idPrefix: string }
    name: string
    purpose: string
    code: { host?: string; client?: string }
  }): { pluginId: unknown; packageId: unknown }
  run(agent: Agent, pluginId: unknown, packageId: unknown, mode: 'run', signal?: unknown): Promise<{
    ok: boolean
    status?: string
    message?: string
  }>
  /** Stop the active run while retaining every package version. */
  stop(agent: Agent, pluginId: unknown): Promise<{ ok: boolean; reason?: string; message?: string }>
  /** Remove a plugin, its active run, and all its packages. */
  undefine(agent: Agent, pluginId: unknown): Promise<{ ok: boolean; reason?: string; message?: string }>
  listPlugins(agent: Agent): DynamicCordisPluginInspectionLike[]
  inspectPackage(agent: Agent, pluginId: unknown, packageId: unknown): {
    name: string
    purpose: string
    code: { host?: string; client?: string }
  }
}

/** The minimal face of the live Agent registry this plugin's API consumes. */
interface AgentsLike {
  get(sessionId: string): Agent | undefined
}

/** The minimal face of the dsh web server this plugin's routes consume. */
interface WebServerLike {
  register(route: WebRoute): () => void
}

// ── plain HTTP route plumbing (the dsh-web-ui convention) ────────────────────

/** Route prefix shared with the browser half. */
const API_BASE = '/api/dynamicPlugins'
/** Reject JSON bodies larger than this. */
const MAX_JSON_BODY_BYTES = 1024 * 1024

/** Loopback literal check plus browser same-origin markers (mirrors the pairing routes' fence). */
function isLoopbackRequest(request: IncomingMessage): boolean {
  const address = request.socket.remoteAddress
  if (address !== '127.0.0.1' && address !== '::1' && address !== '::ffff:127.0.0.1') return false
  const host = request.headers.host
  if (typeof host !== 'string') return false
  let hostUrl: URL
  try {
    hostUrl = new URL(`http://${host}`)
  } catch {
    return false
  }
  if (hostUrl.hostname !== '127.0.0.1' && hostUrl.hostname !== 'localhost' && hostUrl.hostname !== '[::1]') return false
  if (request.headers['sec-fetch-site'] === 'cross-site') return false
  const origin = request.headers.origin
  if (origin === undefined) return true
  try {
    return new URL(origin).host === hostUrl.host
  } catch {
    return false
  }
}

/** One JSON response. */
function writeJson(res: ServerResponse, status: number, body: unknown): void {
  const payload = JSON.stringify(body)
  res.writeHead(status, { 'content-type': 'application/json; charset=utf-8', 'referrer-policy': 'no-referrer' })
  res.end(payload)
}

/** Read a JSON request body (undefined when too large or unparseable). */
async function readJsonBody(req: IncomingMessage): Promise<Record<string, unknown> | undefined> {
  const chunks: Buffer[] = []
  let size = 0
  for await (const chunk of req) {
    const buffer = chunk as Buffer
    size += buffer.length
    if (size > MAX_JSON_BODY_BYTES) return undefined
    chunks.push(buffer)
  }
  try {
    const parsed: unknown = JSON.parse(Buffer.concat(chunks).toString('utf8'))
    return typeof parsed === 'object' && parsed !== null ? parsed as Record<string, unknown> : undefined
  } catch {
    return undefined
  }
}

/** One exact JSON route: POST `{ args }` → `{ ok: true, value }` / `{ ok: false, error }`. */
function jsonRoute<TArgs extends Record<string, unknown>, TValue>(
  method: string,
  invoke: (args: TArgs) => Promise<TValue>,
): WebRoute {
  return {
    kind: 'exact',
    path: `${API_BASE}/${method}`,
    handler: async (req, res) => {
      if (!isLoopbackRequest(req)) {
        writeJson(res, 403, { ok: false, error: { message: 'forbidden: loopback-only' } })
        return
      }
      if (req.method !== 'POST') {
        writeJson(res, 405, { ok: false, error: { message: 'method not allowed' } })
        return
      }
      const body = await readJsonBody(req)
      const args = (body?.args ?? {}) as TArgs
      try {
        writeJson(res, 200, { ok: true, value: await invoke(args) })
      } catch (error) {
        writeJson(res, 200, { ok: false, error: { message: error instanceof Error ? error.message : String(error) } })
      }
    },
  }
}

/**
 * Host API behind the Settings panel. Exposes the persisted catalog and a
 * one-click import into a live session. Served through plain HTTP routes
 * registered in {@link apply}, so the browser never needs a Typert Remote
 * service and no `@deepseek-ai/dsh-typert-protocol` module instance is shared.
 */
export class DynamicPluginsApi {
  constructor(private readonly ctx: Context) {}

  private get runner(): DynamicCordisRunnerLike {
    return this.ctx.dynamicCordisRunner as unknown as DynamicCordisRunnerLike
  }

  private get agents(): AgentsLike {
    return this.ctx.get('agents') as unknown as AgentsLike
  }

  /** List every persisted dynamic-plugin package, without loading anything. */
  async list(): Promise<DynamicPluginsListResult> {
    const dir = dynamicPluginDir()
    const { count, packages } = await listPackages(dir)
    return { dir, count, packages }
  }

  /**
   * Define one persisted package into the given live session, minting a fresh
   * `pluginId`/`packageId`. It deliberately does NOT run the package: the
   * browser half calls `dynamicCordisRunner.startUserRun` afterwards, which is
   * the user-driven path (`settleUserRun` → `agent.inject`) and therefore does
   * not wake the model with a steering message.
   */
  async load(packageName: string, sessionId: string): Promise<DynamicPluginsLoadResult> {
    const dir = dynamicPluginDir()
    await migrateLegacy(dir)
    const agent = this.agents.get(sessionId)
    if (agent === undefined) {
      return { dir, loaded: 0, results: [{ package: packageName, ok: false, error: 'session not found or agent not running' }] }
    }
    const pkg = await readPackage(dir, packageName)
    if (pkg === undefined) {
      return { dir, loaded: 0, results: [{ package: packageName, ok: false, error: 'not found or malformed' }] }
    }
    const receipt = this.runner.define({
      sessionId: agent.id,
      plugin: { kind: 'new', idPrefix: pkg.manifest.idPrefix },
      name: pkg.manifest.name,
      purpose: pkg.manifest.purpose,
      code: pkg.code,
    })
    return {
      dir,
      loaded: 1,
      results: [{
        package: packageName,
        ok: true,
        pluginId: String(receipt.pluginId),
        packageId: String(receipt.packageId),
        hasClientHalf: pkg.code.client !== undefined,
        status: 'defined',
      }],
    }
  }

  /**
   * Persist every dynamic plugin of one live session into the on-disk
   * repository — the same snapshot the `export_dynamic_plugins` tool takes,
   * addressed by session id instead of the executing agent. Writes files
   * only; running plugins are untouched. Each plugin is stored as a package
   * named after its pluginId without the trailing numeric suffix; a package
   * with the same base name is overwritten, one whose base differs is saved
   * as a new package.
   */
  async exportSession(sessionId: string): Promise<DynamicPluginsExportResult> {
    const dir = dynamicPluginDir()
    const agent = this.agents.get(sessionId)
    if (agent === undefined) {
      return { dir, count: 0, exported: [] }
    }
    await mkdir(dir, { recursive: true })
    const exported: DynamicPluginsExportResult['exported'] = []
    for (const plugin of this.runner.listPlugins(agent)) {
      const record = await this.persistPlugin(agent, plugin)
      if (record !== undefined) exported.push(record)
    }
    return { dir, count: exported.length, exported }
  }

  /**
   * Persist a single loaded dynamic plugin of one live session into the
   * on-disk repository, using the same package-naming rules as `exportSession`.
   */
  async exportPlugin(sessionId: string, pluginId: string): Promise<DynamicPluginsExportResult> {
    const dir = dynamicPluginDir()
    const agent = this.agents.get(sessionId)
    if (agent === undefined) {
      return { dir, count: 0, exported: [] }
    }
    await mkdir(dir, { recursive: true })
    const plugin = this.runner.listPlugins(agent).find(entry => String(entry.pluginId) === pluginId)
    const record = plugin === undefined ? undefined : await this.persistPlugin(agent, plugin)
    return { dir, count: record === undefined ? 0 : 1, exported: record === undefined ? [] : [record] }
  }

  /** Write one loaded plugin's current package to the repo; shared by both export paths. */
  private async persistPlugin(
    agent: Agent,
    plugin: DynamicCordisPluginInspectionLike,
  ): Promise<DynamicPluginsExportResult['exported'][number] | undefined> {
    const packageId = plugin.currentPackageId ?? plugin.packages.at(-1)?.packageId
    if (packageId === undefined) return undefined
    const inspected = this.runner.inspectPackage(agent, plugin.pluginId, packageId)
    const pluginId = String(plugin.pluginId)
    const packageName = candidateOf(pluginId)
    const manifest: PluginManifest = {
      name: inspected.name,
      purpose: inspected.purpose,
      idPrefix: idPrefixOf(pluginId),
      code: {
        ...(inspected.code.host === undefined ? {} : { host: HOST_CODE_FILE }),
        ...(inspected.code.client === undefined ? {} : { client: CLIENT_CODE_FILE }),
      },
    }
    const code: ResolvedCode = {
      ...(inspected.code.host === undefined ? {} : { host: inspected.code.host }),
      ...(inspected.code.client === undefined ? {} : { client: inspected.code.client }),
    }
    await writePackage(dynamicPluginDir(), packageName, manifest, code)
    return { pluginId, package: packageName, name: inspected.name, path: join(dynamicPluginDir(), packageName) }
  }

  /**
   * Read the runtime state of every dynamic plugin loaded into one live
   * session: which plugins exist, their current package's halves, and whether
   * each has an active run. Reads only — nothing is started or stopped.
   */
  async runtime(sessionId: string): Promise<DynamicPluginsRuntimeResult> {
    const agent = this.agents.get(sessionId)
    if (agent === undefined) {
      return { sessionId, count: 0, plugins: [] }
    }
    const plugins = this.runner.listPlugins(agent).map(plugin => {
      const current = plugin.currentPackageId === undefined
        ? undefined
        : plugin.packages.find(pkg => String(pkg.packageId) === String(plugin.currentPackageId))
      return {
        pluginId: String(plugin.pluginId),
        name: plugin.name,
        purpose: plugin.purpose,
        hasHostHalf: current?.hasHostHalf ?? plugin.packages.some(pkg => pkg.hasHostHalf),
        hasClientHalf: current?.hasClientHalf ?? plugin.packages.some(pkg => pkg.hasClientHalf),
        running: plugin.activeRun !== undefined,
        ...(plugin.activeRun?.packageId === undefined ? {} : { activeRunPackageId: String(plugin.activeRun.packageId) }),
        packages: plugin.packages.map(pkg => ({
          packageId: String(pkg.packageId),
          name: pkg.name,
          hasHostHalf: pkg.hasHostHalf,
          hasClientHalf: pkg.hasClientHalf,
        })),
      }
    })
    return { sessionId, count: plugins.length, plugins }
  }

  /**
   * Unload one dynamic plugin from a live session: remove its active run and
   * all its package versions. The on-disk repo is untouched.
   */
  async unload(sessionId: string, pluginId: string): Promise<DynamicPluginsUnloadResult> {
    const agent = this.agents.get(sessionId)
    if (agent === undefined) {
      return { ok: false, pluginId, error: 'session not found or agent not running' }
    }
    const result = await this.runner.undefine(agent, pluginId)
    return {
      ok: result.ok === true,
      pluginId,
      ...(result.ok === true ? {} : { error: result.message ?? result.reason ?? 'unload failed' }),
    }
  }

  /**
   * Reload one dynamic plugin in a live session: stop its current run (if
   * any) and re-run its current package version. A plugin with a client half
   * may return `awaiting-approval` and complete in the browser instead.
   */
  async reload(sessionId: string, pluginId: string): Promise<DynamicPluginsReloadResult> {
    const agent = this.agents.get(sessionId)
    if (agent === undefined) {
      return { ok: false, pluginId, error: 'session not found or agent not running' }
    }
    const plugin = this.runner.listPlugins(agent).find(entry => String(entry.pluginId) === pluginId)
    if (plugin === undefined) {
      return { ok: false, pluginId, error: 'plugin not found' }
    }
    const packageId = plugin.currentPackageId
    if (packageId === undefined) {
      return { ok: false, pluginId, error: 'plugin has no current package' }
    }
    if (plugin.activeRun !== undefined) {
      await this.runner.stop(agent, pluginId)
    }
    const run = await this.runner.run(agent, pluginId, packageId, 'run')
    return {
      ok: run.ok,
      pluginId,
      ...(run.ok ? (run.status === undefined ? {} : { status: run.status }) : { error: run.message ?? run.status ?? 'reload failed' }),
    }
  }

  /**
   * Update a persisted package's manifest metadata — its readable `name` and
   * `purpose` — in place. Only `define.json` is rewritten; the referenced code
   * files are untouched. Returns the fields as they are now stored, or an
   * error when the package is missing/malformed or the name is blank.
   */
  async updatePackage(
    packageName: string,
    name: string,
    purpose: string,
  ): Promise<DynamicPluginsUpdateResult> {
    const dir = dynamicPluginDir()
    const packagePath = join(dir, packageName)
    const manifest = await readManifest(packagePath)
    if (manifest === undefined) {
      return { ok: false, package: packageName, error: 'not found or malformed' }
    }
    const trimmedName = name.trim()
    if (trimmedName.length === 0) {
      return { ok: false, package: packageName, error: 'name must not be blank' }
    }
    const next: PluginManifest = { ...manifest, name: trimmedName, purpose }
    try {
      await writeFile(join(packagePath, DEFINE_FILE), `${JSON.stringify(next, null, 2)}\n`, 'utf8')
    } catch (error) {
      return { ok: false, package: packageName, error: String(error instanceof Error ? error.message : error) }
    }
    return { ok: true, package: packageName, name: trimmedName, purpose }
  }

  /**
   * Delete a persisted package (its whole directory, code files included) from
   * the on-disk repository. The name must be a safe single path segment and
   * resolve to a manifest-bearing package, so an arbitrary path can never be
   * removed. Returns `ok: true` once the directory is gone.
   */
  async removePackage(packageName: string): Promise<DynamicPluginsRemoveResult> {
    const dir = dynamicPluginDir()
    if (!isSafePackageName(packageName)) {
      return { ok: false, package: packageName, error: 'invalid package name' }
    }
    const packagePath = join(dir, packageName)
    const manifest = await readManifest(packagePath)
    if (manifest === undefined) {
      return { ok: false, package: packageName, error: 'not found or malformed' }
    }
    try {
      await rm(packagePath, { recursive: true, force: true })
    } catch (error) {
      return { ok: false, package: packageName, error: String(error instanceof Error ? error.message : error) }
    }
    return { ok: true, package: packageName }
  }
}

/** The single entry point: register the three tools and the HTTP route family. */
export function apply(ctx: Context): void {
  ctx.tools.register(defineTool({
    name: 'export_dynamic_plugins',
    description:
      'Snapshot the current Session\'s dynamic Cordis plugins into the on-disk plugin directory '
      + `(${DIR_NAME} under the Harness home). Each plugin becomes one PACKAGE (a directory named after `
      + 'the plugin, with the trailing numeric suffix of its id removed): a `define.json` holding its name, '
      + 'purpose and id prefix, plus separate code files '
      + '(`host.js` / `client.js`) that `define.json` references. Exporting writes files only; it does not '
      + 'change any running plugin. A package with the same base name is overwritten; a plugin whose base '
      + 'name differs from what is already on disk is saved as a new package.',
    parameters: {},
    output: { schema: { type: 'json' }, render: (_args, value) => renderJson(value) },
    async execute(_args, exec): Promise<JsonValue> {
      const agent = requireAgent(exec)
      const dir = dynamicPluginDir()
      const runner = ctx.dynamicCordisRunner as unknown as DynamicCordisRunnerLike
      const plugins = runner.listPlugins(agent)
      await mkdir(dir, { recursive: true })
      const exported: Array<Record<string, JsonValue>> = []
      for (const plugin of plugins) {
        const packageId = plugin.currentPackageId ?? plugin.packages.at(-1)?.packageId
        if (packageId === undefined) continue
        const inspected = runner.inspectPackage(agent, plugin.pluginId, packageId)
        const pluginId = String(plugin.pluginId)
        const packageName = candidateOf(pluginId)
        const manifest: PluginManifest = {
          name: inspected.name,
          purpose: inspected.purpose,
          idPrefix: idPrefixOf(pluginId),
          code: {
            ...(inspected.code.host === undefined ? {} : { host: HOST_CODE_FILE }),
            ...(inspected.code.client === undefined ? {} : { client: CLIENT_CODE_FILE }),
          },
        }
        const code: ResolvedCode = {
          ...(inspected.code.host === undefined ? {} : { host: inspected.code.host }),
          ...(inspected.code.client === undefined ? {} : { client: inspected.code.client }),
        }
        await writePackage(dir, packageName, manifest, code)
        exported.push({ pluginId, package: packageName, name: inspected.name, path: join(dir, packageName) })
      }
      return { dir, count: exported.length, exported }
    },
  }))

  ctx.tools.register(defineTool({
    name: 'list_dynamic_plugins',
    description:
      'List every dynamic plugin persisted in the on-disk plugin directory, without loading anything. '
      + 'Each entry names the package (directory) to pass to load_dynamic_plugins, the plugin\'s readable name, '
      + 'its purpose, and which halves it carries. Call this before load_dynamic_plugins to choose which plugins to load.',
    parameters: {},
    output: { schema: { type: 'json' }, render: (_args, value) => renderJson(value) },
    async execute(): Promise<JsonValue> {
      const dir = dynamicPluginDir()
      const { count, packages } = await listPackages(dir)
      return {
        dir,
        count,
        packages: packages.map(pkg => ({
          package: pkg.package,
          name: pkg.name,
          purpose: pkg.purpose,
          hasHostHalf: pkg.hasHostHalf,
          hasClientHalf: pkg.hasClientHalf,
        })),
      }
    },
  }))

  ctx.tools.register(defineTool({
    name: 'load_dynamic_plugins',
    description:
      'Replay persisted dynamic plugins: define and run the selected packages from the on-disk plugin directory. '
      + 'Pass `names` as the package (directory) names chosen from list_dynamic_plugins; omit `names` to list available '
      + 'packages without loading. Each selected plugin is redefined (a fresh id is minted) and run in `run` mode. '
      + 'A plugin with a client half may return awaiting-approval and complete in the browser.',
    parameters: {
      names: {
        type: 'array',
        items: { type: 'string' },
        description: 'Package (directory) names to load, as returned by list_dynamic_plugins. Omit to list only.',
      },
    },
    output: { schema: { type: 'json' }, render: (_args, value) => renderJson(value) },
    async execute(args, exec): Promise<JsonValue> {
      const agent = requireAgent(exec)
      const dir = dynamicPluginDir()
      const runner = ctx.dynamicCordisRunner as unknown as DynamicCordisRunnerLike
      const names: string[] = Array.isArray(args.names) ? args.names.filter((n: unknown) => typeof n === 'string') : []
      if (names.length === 0) {
        const { packages } = await listPackages(dir)
        return { dir, loaded: 0, available: packages.map(pkg => pkg.package), note: 'Pass `names` to load a selection.' }
      }
      await migrateLegacy(dir)
      const loaded: Array<Record<string, JsonValue>> = []
      for (const packageName of names) {
        const pkg = await readPackage(dir, packageName)
        if (pkg === undefined) {
          loaded.push({ package: packageName, ok: false, error: 'not found or malformed' })
          continue
        }
        const receipt = runner.define({
          sessionId: agent.id,
          plugin: { kind: 'new', idPrefix: pkg.manifest.idPrefix },
          name: pkg.manifest.name,
          purpose: pkg.manifest.purpose,
          code: pkg.code,
        })
        const run = await runner.run(agent, receipt.pluginId, receipt.packageId, 'run', exec.signal)
        loaded.push({
          package: packageName,
          ok: run.ok,
          pluginId: String(receipt.pluginId),
          packageId: String(receipt.packageId),
          status: run.ok ? run.status : run.message,
        })
      }
      return { dir, loaded: loaded.length, results: loaded }
    },
  }))

  const api = new DynamicPluginsApi(ctx)
  const routes: WebRoute[] = [
    jsonRoute('list', () => api.list()),
    jsonRoute('load', (args) => api.load(String(args.packageName ?? ''), String(args.sessionId ?? ''))),
    jsonRoute('exportSession', (args) => api.exportSession(String(args.sessionId ?? ''))),
    jsonRoute('exportPlugin', (args) => api.exportPlugin(String(args.sessionId ?? ''), String(args.pluginId ?? ''))),
    jsonRoute('updatePackage', (args) => api.updatePackage(String(args.packageName ?? ''), String(args.name ?? ''), String(args.purpose ?? ''))),
    jsonRoute('removePackage', (args) => api.removePackage(String(args.packageName ?? ''))),
    jsonRoute('runtime', (args) => api.runtime(String(args.sessionId ?? ''))),
    jsonRoute('unload', (args) => api.unload(String(args.sessionId ?? ''), String(args.pluginId ?? ''))),
    jsonRoute('reload', (args) => api.reload(String(args.sessionId ?? ''), String(args.pluginId ?? ''))),
  ]
  ctx.effect(() => {
    const webServer = ctx.get('webServer') as WebServerLike | undefined
    if (webServer === undefined) return
    const disposers = routes.map(route => webServer.register(route))
    return () => {
      for (const dispose of disposers) dispose()
    }
  }, 'dsh-dynamic-plugin-manage: /api/dynamicPlugins routes')
}
