/**
 * Settings section listing every persisted dynamic plugin, each with an
 * inline editor for its name/purpose plus a one-click "Import into current
 * session" button.
 *
 * No JSX is used so the out-of-tree bundle does not depend on a particular
 * JSX transform; `react` is a platform module resolved by the shell at runtime.
 */
import { createElement as h, Fragment, useEffect, useState, type ReactNode } from 'react'
import type {
  DynamicPluginsEntry,
  DynamicPluginsListResult,
  DynamicPluginsLoadResult,
  DynamicPluginsUpdateResult,
} from '../types'

/** Registration-side face the Settings renderer hands this section. */
export interface DynamicPluginsSettingsInjected {
  list: () => Promise<DynamicPluginsListResult>
  load: (packageName: string, sessionId: string) => Promise<DynamicPluginsLoadResult>
  updatePackage: (packageName: string, name: string, purpose: string) => Promise<DynamicPluginsUpdateResult>
  startRun: (request: { pluginId: string; packageId: string; hasClientHalf: boolean }) => Promise<void>
  currentSessionId: () => string | undefined
  solidify: (packageName: string, name: string) => Promise<{ imported: boolean; prompted: boolean }>
}

export interface DynamicPluginsSettingsProps extends DynamicPluginsSettingsInjected {
  t: (key: string) => string
}

type ViewState =
  | { readonly status: 'loading' }
  | { readonly status: 'error'; readonly message: string }
  | { readonly status: 'ready'; readonly catalog: DynamicPluginsListResult }

const styles: Record<string, React.CSSProperties> = {
  section: { display: 'flex', flexDirection: 'column', gap: 12 },
  headingRow: { display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 12 },
  heading: { margin: 0, fontSize: 15, fontWeight: 600 },
  muted: { margin: 0, color: 'var(--dsh-color-text-muted, #8a8f98)' },
  error: { margin: 0, color: 'var(--dsh-color-danger, #d64242)' },
  notice: { margin: 0, fontSize: 13 },
  noticeOk: { margin: 0, fontSize: 13, color: 'var(--dsh-color-success, #2e9e5b)' },
  list: { listStyle: 'none', margin: 0, padding: 0, display: 'flex', flexDirection: 'column', gap: 8 },
  card: {
    display: 'flex', alignItems: 'center', gap: 12, padding: '10px 12px',
    border: '1px solid var(--dsh-color-border, rgba(0,0,0,0.1))',
    borderRadius: 8, background: 'var(--dsh-color-surface, rgba(0,0,0,0.02))',
  },
  cardEditing: { flexDirection: 'column', alignItems: 'stretch' },
  actions: { flex: 'none', display: 'flex', alignItems: 'center', gap: 6 },
  editForm: { display: 'flex', flexDirection: 'column', gap: 8 },
  field: { display: 'flex', flexDirection: 'column', gap: 4 },
  label: { fontSize: 12, color: 'var(--dsh-color-text-muted, #6a6f78)' },
  input: {
    padding: '6px 8px', fontSize: 13, borderRadius: 6,
    border: '1px solid var(--dsh-color-border, rgba(0,0,0,0.15))',
    background: 'var(--dsh-color-surface, rgba(0,0,0,0.02))',
    color: 'var(--dsh-color-text-primary, #1f2329)',
    fontFamily: 'inherit',
  },
  textarea: {
    padding: '6px 8px', fontSize: 13, borderRadius: 6,
    border: '1px solid var(--dsh-color-border, rgba(0,0,0,0.15))',
    background: 'var(--dsh-color-surface, rgba(0,0,0,0.02))',
    color: 'var(--dsh-color-text-primary, #1f2329)',
    fontFamily: 'inherit', resize: 'vertical', minHeight: 44,
  },
  editActions: { display: 'flex', justifyContent: 'flex-end', gap: 6 },
  cardBody: { flex: 1, minWidth: 0, display: 'flex', flexDirection: 'column', gap: 2 },
  name: { fontSize: 14, fontWeight: 600 },
  purpose: { fontSize: 12, color: 'var(--dsh-color-text-muted, #8a8f98)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' },
  badges: { display: 'flex', gap: 6, marginTop: 2 },
  badge: {
    fontSize: 11, padding: '1px 7px', borderRadius: 999,
    background: 'var(--dsh-color-bg-subtle, rgba(0,0,0,0.05)',
    color: 'var(--dsh-color-text-muted, #6a6f78)',
  },
  button: {
    padding: '5px 12px', fontSize: 12, borderRadius: 6, cursor: 'pointer',
    border: '1px solid var(--dsh-color-border, rgba(0,0,0,0.15))',
    background: 'var(--dsh-color-accent, #2f6fed)', color: '#fff',
  },
  buttonSecondary: {
    padding: '5px 12px', fontSize: 12, borderRadius: 6, cursor: 'pointer',
    border: '1px solid var(--dsh-color-border, rgba(0,0,0,0.15))',
    background: 'transparent', color: 'var(--dsh-color-text-primary, #1f2329)',
  },
  buttonDanger: {
    padding: '5px 12px', fontSize: 12, borderRadius: 6, cursor: 'pointer',
    border: '1px solid var(--dsh-color-danger, #d64242)',
    background: 'transparent', color: 'var(--dsh-color-danger, #d64242)',
  },
  buttonDangerSolid: {
    padding: '5px 12px', fontSize: 12, borderRadius: 6, cursor: 'pointer',
    border: '1px solid var(--dsh-color-danger, #d64242)',
    background: 'var(--dsh-color-danger, #d64242)', color: '#fff',
  },
  buttonDisabled: { opacity: 0.55, cursor: 'default' },
  confirmText: { fontSize: 12, color: 'var(--dsh-color-text-muted, #6a6f78)' },
}

/** Row-level edit actions the section wires into each card. */
interface EditCallbacks {
  onStartEdit(plugin: DynamicPluginsEntry): void
  onCancelEdit(): void
  onSaveEdit(): void
  onDraftChange(field: 'name' | 'purpose', value: string): void
}

/** Row-level delete actions, armed through a two-step confirm. */
interface DeleteCallbacks {
  onStartDelete(plugin: DynamicPluginsEntry): void
  onCancelDelete(): void
  onConfirmDelete(): void
}

/**
 * Render one plugin row. In view mode it shows the card body plus "Edit",
 * "Import" and "Delete" actions; the delete action arms a two-step confirm
 * ("confirm / cancel") before anything is removed. While the row is being
 * edited it shows a full-width form (name + purpose) with Save/Cancel. Kept as
 * a plain render helper (not a component) so input focus is preserved across
 * keystrokes.
 */
function pluginRow(
  plugin: DynamicPluginsEntry,
  t: DynamicPluginsSettingsProps['t'],
  busy: string | null,
  editing: string | null,
  confirming: string | null,
  deleting: boolean,
  draft: { name: string; purpose: string },
  saving: boolean,
  edit: EditCallbacks,
  del: DeleteCallbacks,
  onImport: (packageName: string) => void,
  onSolidify: (plugin: DynamicPluginsEntry) => void,
): ReactNode {
  const importing = busy === plugin.package
  const isEditing = editing === plugin.package
  if (isEditing) {
    return h('li', { key: plugin.package, style: { ...styles.card, ...styles.cardEditing } },
      h('div', { style: styles.editForm },
        h('label', { style: styles.field },
          h('span', { style: styles.label }, t('editName')),
          h('input', {
            type: 'text',
            style: styles.input,
            value: draft.name,
            disabled: saving,
            placeholder: t('editNamePlaceholder'),
            onChange: (event: { target: { value: string } }) => edit.onDraftChange('name', event.target.value),
          }),
        ),
        h('label', { style: styles.field },
          h('span', { style: styles.label }, t('editPurpose')),
          h('textarea', {
            style: styles.textarea,
            value: draft.purpose,
            disabled: saving,
            placeholder: t('editPurposePlaceholder'),
            onChange: (event: { target: { value: string } }) => edit.onDraftChange('purpose', event.target.value),
          }),
        ),
        h('div', { style: styles.editActions },
          h('button', {
            type: 'button',
            style: saving ? { ...styles.button, ...styles.buttonDisabled } : styles.button,
            disabled: saving,
            onClick: () => edit.onSaveEdit(),
          }, saving ? t('saving') : t('save')),
          h('button', {
            type: 'button',
            style: styles.buttonSecondary,
            disabled: saving,
            onClick: () => edit.onCancelEdit(),
          }, t('cancel')),
        ),
      ),
    )
  }
  const isConfirming = confirming === plugin.package
  return h('li', { key: plugin.package, style: styles.card },
    h('div', { style: styles.cardBody },
      h('div', { style: styles.name }, plugin.name),
      plugin.purpose ? h('div', { style: styles.purpose, title: plugin.purpose }, plugin.purpose) : null,
      h('div', { style: styles.badges },
        plugin.hasHostHalf ? h('span', { style: styles.badge }, t('hostHalf')) : null,
        plugin.hasClientHalf ? h('span', { style: styles.badge }, t('clientHalf')) : null,
      ),
    ),
    h('div', { style: styles.actions },
      isConfirming
        ? h(Fragment, null,
            h('span', { style: styles.confirmText }, t('deleteConfirm')),
            h('button', {
              type: 'button',
              style: deleting ? { ...styles.buttonDangerSolid, ...styles.buttonDisabled } : styles.buttonDangerSolid,
              disabled: deleting,
              onClick: () => del.onConfirmDelete(),
            }, deleting ? t('deleting') : t('deleteConfirmYes')),
            h('button', {
              type: 'button',
              style: styles.buttonSecondary,
              disabled: deleting,
              onClick: () => del.onCancelDelete(),
            }, t('cancel')),
          )
        : h(Fragment, null,
            h('button', {
              type: 'button',
              style: styles.buttonSecondary,
              disabled: saving || deleting,
              onClick: () => edit.onStartEdit(plugin),
            }, t('edit')),
            h('button', {
              type: 'button',
              style: importing ? { ...styles.button, ...styles.buttonDisabled } : styles.button,
              disabled: importing || saving || deleting,
              onClick: () => onImport(plugin.package),
            }, importing ? t('importing') : t('import')),
            h('button', {
              type: 'button',
              style: busy === plugin.package ? { ...styles.buttonSecondary, ...styles.buttonDisabled } : styles.buttonSecondary,
              disabled: importing || saving || deleting,
              onClick: () => onSolidify(plugin),
            }, busy === plugin.package ? t('solidifying') : t('solidify')),
            h('button', {
              type: 'button',
              style: styles.buttonDanger,
              disabled: deleting,
              onClick: () => del.onStartDelete(plugin),
            }, t('delete')),
          ),
    ),
  )
}

/** The Settings section component, mounted by the settings slot renderer. */
export function DynamicPluginsSettingsSection(props: DynamicPluginsSettingsProps): ReactNode {
  const { list, load, updatePackage, removePackage, startRun, currentSessionId, solidify, t } = props
  const [state, setState] = useState<ViewState>({ status: 'loading' })
  const [request, setRequest] = useState(0)
  const [busy, setBusy] = useState<string | null>(null)
  const [editing, setEditing] = useState<string | null>(null)
  const [draft, setDraft] = useState<{ name: string; purpose: string }>({ name: '', purpose: '' })
  const [saving, setSaving] = useState(false)
  const [confirming, setConfirming] = useState<string | null>(null)
  const [deleting, setDeleting] = useState(false)
  const [notice, setNotice] = useState<{ kind: 'ok' | 'err'; text: string } | null>(null)

  useEffect(() => {
    let current = true
    void Promise.resolve().then(() => list()).then(
      (catalog) => { if (current) setState({ status: 'ready', catalog }) },
      (error: unknown) => {
        if (current) setState({ status: 'error', message: String(error instanceof Error ? error.message : error) })
      },
    )
    return () => { current = false }
  }, [list, request])

  const retry = (): void => {
    setState({ status: 'loading' })
    setRequest(value => value + 1)
  }

  const importPlugin = async (packageName: string): Promise<void> => {
    const sessionId = currentSessionId()
    if (sessionId === undefined) {
      setNotice({ kind: 'err', text: t('noSession') })
      return
    }
    setBusy(packageName)
    setNotice(null)
    try {
      const result = await load(packageName, sessionId)
      const entry = result.results[0]
      if (!entry?.ok) {
        setNotice({ kind: 'err', text: `${t('importFailed')}: ${entry?.error ?? entry?.status ?? ''}` })
      } else if (entry.pluginId !== undefined && entry.packageId !== undefined) {
        // User gesture: run it silently (agent.inject, no model reply).
        await startRun({ pluginId: entry.pluginId, packageId: entry.packageId, hasClientHalf: entry.hasClientHalf === true })
        setNotice({ kind: 'ok', text: t('imported') })
      } else {
        setNotice({ kind: 'ok', text: t('imported') })
      }
    } catch (error: unknown) {
      setNotice({ kind: 'err', text: `${t('importFailed')}: ${String(error instanceof Error ? error.message : error)}` })
    } finally {
      setBusy(null)
    }
  }

  const solidifyPlugin = async (plugin: DynamicPluginsEntry): Promise<void> => {
    const sessionId = currentSessionId()
    if (sessionId === undefined) {
      setNotice({ kind: 'err', text: t('noSession') })
      return
    }
    setBusy(plugin.package)
    setNotice(null)
    try {
      const { imported } = await solidify(plugin.package, plugin.name)
      setNotice({ kind: 'ok', text: imported ? t('solidifiedImported') : t('solidified') })
    } catch (error: unknown) {
      setNotice({ kind: 'err', text: `${t('solidifyFailed')}: ${String(error instanceof Error ? error.message : error)}` })
    } finally {
      setBusy(null)
    }
  }

  const startEdit = (plugin: DynamicPluginsEntry): void => {
    setEditing(plugin.package)
    setDraft({ name: plugin.name, purpose: plugin.purpose })
    setNotice(null)
  }

  const cancelEdit = (): void => {
    setEditing(null)
  }

  const draftChange = (field: 'name' | 'purpose', value: string): void => {
    setDraft(prev => (field === 'name' ? { ...prev, name: value } : { ...prev, purpose: value }))
  }

  const saveEdit = async (): Promise<void> => {
    const packageName = editing
    if (packageName === null) return
    setSaving(true)
    setNotice(null)
    try {
      const result = await updatePackage(packageName, draft.name, draft.purpose)
      if (!result.ok) {
        setNotice({ kind: 'err', text: `${t('editFailed')}: ${result.error ?? ''}` })
      } else {
        setEditing(null)
        setNotice({ kind: 'ok', text: t('edited') })
        // Reload the catalog so the row reflects the saved name/purpose.
        setRequest(value => value + 1)
      }
    } catch (error: unknown) {
      setNotice({ kind: 'err', text: `${t('editFailed')}: ${String(error instanceof Error ? error.message : error)}` })
    } finally {
      setSaving(false)
    }
  }

  const edit: EditCallbacks = { onStartEdit: startEdit, onCancelEdit: cancelEdit, onSaveEdit: saveEdit, onDraftChange: draftChange }

  const startDelete = (plugin: DynamicPluginsEntry): void => {
    setConfirming(plugin.package)
    setNotice(null)
  }

  const cancelDelete = (): void => {
    setConfirming(null)
  }

  const confirmDelete = async (): Promise<void> => {
    const packageName = confirming
    if (packageName === null) return
    setDeleting(true)
    setNotice(null)
    try {
      const result = await removePackage(packageName)
      if (!result.ok) {
        setNotice({ kind: 'err', text: `${t('deleteFailed')}: ${result.error ?? ''}` })
      } else {
        setConfirming(null)
        setNotice({ kind: 'ok', text: t('deleted') })
        // Reload the catalog so the removed row disappears.
        setRequest(value => value + 1)
      }
    } catch (error: unknown) {
      setNotice({ kind: 'err', text: `${t('deleteFailed')}: ${String(error instanceof Error ? error.message : error)}` })
    } finally {
      setDeleting(false)
    }
  }

  const del: DeleteCallbacks = { onStartDelete: startDelete, onCancelDelete: cancelDelete, onConfirmDelete: confirmDelete }

  return h('section', { style: styles.section },
    h('div', { style: styles.headingRow },
      h('h3', { style: styles.heading }, t('title')),
    ),
    h('p', { style: styles.muted }, t('description')),
    notice ? h('p', { style: notice.kind === 'ok' ? styles.noticeOk : styles.notice }, notice.text) : null,
    state.status === 'loading' ? h('p', { style: styles.muted }, t('loading')) : null,
    state.status === 'error' ? h(Fragment, null,
      h('p', { style: styles.error }, state.message),
      h('button', { type: 'button', style: styles.button, onClick: retry }, t('retry')),
    ) : null,
    state.status === 'ready' && state.catalog.packages.length === 0
      ? h('p', { style: styles.muted }, t('empty'))
      : null,
    state.status === 'ready' && state.catalog.packages.length > 0
      ? h('ul', { style: styles.list },
          state.catalog.packages.map(plugin => pluginRow(plugin, t, busy, editing, confirming, deleting, draft, saving, edit, del, importPlugin, solidifyPlugin)),
        )
      : null,
  )
}
