/**
 * Session "Plugins" view tab: the runtime state of every dynamic plugin
 * loaded into the current session, with stop-and-reload and unload actions.
 *
 * This is a `conversation.view` slot entry — the tab bar in the session
 * header renders it once the slot ledger has more than one view. The plugin
 * list is read from the Host over the plain `/api/dynamicPlugins/runtime`
 * route; unload/reload go through `/unload` and `/reload`.
 *
 * No JSX is used so the out-of-tree bundle does not depend on a particular
 * JSX transform; `react` is a platform module resolved by the shell at runtime.
 */
import { createElement as h, Fragment, useEffect, useState, type ReactNode } from 'react'
import type {
  DynamicPluginsExportResult,
  DynamicPluginsReloadResult,
  DynamicPluginsRuntimeEntry,
  DynamicPluginsRuntimeResult,
  DynamicPluginsUnloadResult,
} from '../types'

/** API face the session view injects (bound to the current session id). */
export interface PluginRuntimeViewInjected {
  list: () => Promise<DynamicPluginsRuntimeResult>
  unload: (pluginId: string) => Promise<DynamicPluginsUnloadResult>
  reload: (pluginId: string) => Promise<DynamicPluginsReloadResult>
  /** Persist every loaded plugin of the session to the on-disk repo. */
  exportAll: () => Promise<DynamicPluginsExportResult>
  /** Persist one loaded plugin to the on-disk repo. */
  exportPlugin: (pluginId: string) => Promise<DynamicPluginsExportResult>
  /** Prompt the model to convert the plugin named `name` into a standard dsh plugin. */
  solidify: (name: string) => Promise<void>
}

export interface PluginRuntimeViewProps extends PluginRuntimeViewInjected {
  t: (key: string) => string
}

type ViewState =
  | { readonly status: 'loading' }
  | { readonly status: 'error'; readonly message: string }
  | { readonly status: 'ready'; readonly plugins: readonly DynamicPluginsRuntimeEntry[] }

type Notice = { readonly kind: 'ok' | 'err'; readonly text: string } | null

const styles: Record<string, React.CSSProperties> = {
  root: { display: 'flex', flexDirection: 'column', gap: 12, padding: 16 },
  headingRow: { display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 12 },
  heading: { margin: 0, fontSize: 15, fontWeight: 600 },
  muted: { margin: 0, color: 'var(--dsh-color-text-muted, #8a8f98)' },
  error: { margin: 0, color: 'var(--dsh-color-danger, #d64242)' },
  noticeOk: { margin: 0, fontSize: 13, color: 'var(--dsh-color-success, #2e9e5b)' },
  noticeErr: { margin: 0, fontSize: 13, color: 'var(--dsh-color-danger, #d64242)' },
  list: { listStyle: 'none', margin: 0, padding: 0, display: 'flex', flexDirection: 'column', gap: 8 },
  card: {
    display: 'flex', alignItems: 'center', gap: 12, padding: '10px 12px',
    border: '1px solid var(--dsh-color-border, rgba(0,0,0,0.1))',
    borderRadius: 8, background: 'var(--dsh-color-surface, rgba(0,0,0,0.02))',
  },
  cardBody: { flex: 1, minWidth: 0, display: 'flex', flexDirection: 'column', gap: 2 },
  nameRow: { display: 'flex', alignItems: 'center', gap: 8 },
  name: { fontSize: 14, fontWeight: 600, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' },
  status: { fontSize: 11, padding: '1px 7px', borderRadius: 999, whiteSpace: 'nowrap' },
  statusRunning: { background: 'var(--dsh-color-success, #2e9e5b)', color: '#fff' },
  statusStopped: { background: 'var(--dsh-color-bg-subtle, rgba(0,0,0,0.05)', color: 'var(--dsh-color-text-muted, #6a6f78)' },
  purpose: { fontSize: 12, color: 'var(--dsh-color-text-muted, #8a8f98)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' },
  badges: { display: 'flex', gap: 6, marginTop: 2 },
  badge: {
    fontSize: 11, padding: '1px 7px', borderRadius: 999,
    background: 'var(--dsh-color-bg-subtle, rgba(0,0,0,0.05)',
    color: 'var(--dsh-color-text-muted, #6a6f78)',
  },
  actions: { flex: 'none', display: 'flex', alignItems: 'center', gap: 6 },
  buttonSecondary: {
    padding: '5px 12px', fontSize: 12, borderRadius: 6, cursor: 'pointer',
    border: '1px solid var(--dsh-color-border, rgba(0,0,0,0.15))',
    background: 'transparent', color: 'var(--dsh-color-text-primary, #1f2329)',
  },
  buttonDanger: {
    padding: '5px 12px', fontSize: 12, borderRadius: 6, cursor: 'pointer',
    border: '1px solid var(--dsh-color-danger, #d64242)',
    background: 'transparent', color: 'var(--dsh-color-danger, #d64242)',
  },
  buttonDisabled: { opacity: 0.55, cursor: 'default' },
}

function pluginCard(
  plugin: DynamicPluginsRuntimeEntry,
  t: PluginRuntimeViewProps['t'],
  busy: string | null,
  onReload: (pluginId: string) => void,
  onUnload: (pluginId: string) => void,
  onExport: (pluginId: string) => void,
  onSolidify: (pluginId: string, name: string) => void,
): ReactNode {
  const working = busy === plugin.pluginId
  return h('li', { key: plugin.pluginId, style: styles.card },
    h('div', { style: styles.cardBody },
      h('div', { style: styles.nameRow },
        h('span', { style: styles.name }, plugin.name),
        h('span', {
          style: { ...styles.status, ...(plugin.running ? styles.statusRunning : styles.statusStopped) },
        }, plugin.running ? t('running') : t('stopped')),
      ),
      plugin.purpose ? h('div', { style: styles.purpose, title: plugin.purpose }, plugin.purpose) : null,
      h('div', { style: styles.badges },
        plugin.hasHostHalf ? h('span', { style: styles.badge }, t('hostHalf')) : null,
        plugin.hasClientHalf ? h('span', { style: styles.badge }, t('clientHalf')) : null,
      ),
    ),
    h('div', { style: styles.actions },
      h('button', {
        type: 'button',
        style: working ? { ...styles.buttonSecondary, ...styles.buttonDisabled } : styles.buttonSecondary,
        disabled: working,
        onClick: () => onExport(plugin.pluginId),
      }, working ? t('working') : t('export')),
      h('button', {
        type: 'button',
        style: working ? { ...styles.buttonSecondary, ...styles.buttonDisabled } : styles.buttonSecondary,
        disabled: working,
        onClick: () => onSolidify(plugin.pluginId, plugin.name),
      }, t('solidify')),
      h('button', {
        type: 'button',
        style: working ? { ...styles.buttonSecondary, ...styles.buttonDisabled } : styles.buttonSecondary,
        disabled: working,
        onClick: () => onReload(plugin.pluginId),
      }, working ? t('working') : t('reload')),
      h('button', {
        type: 'button',
        style: working ? { ...styles.buttonDanger, ...styles.buttonDisabled } : styles.buttonDanger,
        disabled: working,
        onClick: () => onUnload(plugin.pluginId),
      }, t('unload')),
    ),
  )
}

/** The session view body behind the "Plugins" tab. */
export function PluginRuntimeView({ list, unload, reload, exportAll, exportPlugin, solidify, t }: PluginRuntimeViewProps): ReactNode {
  const [state, setState] = useState<ViewState>({ status: 'loading' })
  const [request, setRequest] = useState(0)
  const [busy, setBusy] = useState<string | null>(null)
  const [busyAll, setBusyAll] = useState(false)
  const [notice, setNotice] = useState<Notice>(null)

  useEffect(() => {
    let current = true
    setNotice(null)
    setState({ status: 'loading' })
    void Promise.resolve().then(() => list()).then(
      (result) => { if (current) setState({ status: 'ready', plugins: result.plugins }) },
      (error: unknown) => {
        if (current) setState({ status: 'error', message: String(error instanceof Error ? error.message : error) })
      },
    )
    return () => { current = false }
  }, [list, request])

  const refresh = (): void => setRequest(value => value + 1)
  const errMsg = (error: unknown): string => error instanceof Error ? error.message : String(error)

  const runAction = async (
    pluginId: string,
    action: (pluginId: string) => Promise<DynamicPluginsReloadResult | DynamicPluginsUnloadResult>,
  ): Promise<void> => {
    setBusy(pluginId)
    setNotice(null)
    try {
      const result = await action(pluginId)
      if (!result.ok) {
        setNotice({ kind: 'err', text: `${t('actionFailed')}: ${result.error ?? result.status ?? ''}` })
      } else {
        setNotice({ kind: 'ok', text: t('done') })
      }
      refresh()
    } catch (error: unknown) {
      setNotice({ kind: 'err', text: `${t('actionFailed')}: ${errMsg(error)}` })
    } finally {
      setBusy(null)
    }
  }

  const onReload = (pluginId: string): void => {
    void runAction(pluginId, (id) => reload(id))
  }
  const onUnload = (pluginId: string): void => {
    void runAction(pluginId, (id) => unload(id))
  }

  const onExportAll = async (): Promise<void> => {
    setBusyAll(true)
    setNotice(null)
    try {
      const result = await exportAll()
      setNotice({ kind: 'ok', text: t('exportedCount').replace('{count}', String(result.count)) })
      refresh()
    } catch (error: unknown) {
      setNotice({ kind: 'err', text: `${t('actionFailed')}: ${errMsg(error)}` })
    } finally {
      setBusyAll(false)
    }
  }

  const onExportPlugin = async (pluginId: string): Promise<void> => {
    setBusy(pluginId)
    setNotice(null)
    try {
      const result = await exportPlugin(pluginId)
      setNotice({ kind: 'ok', text: t('exportedCount').replace('{count}', String(result.count)) })
    } catch (error: unknown) {
      setNotice({ kind: 'err', text: `${t('actionFailed')}: ${errMsg(error)}` })
    } finally {
      setBusy(null)
    }
  }

  const onSolidify = async (pluginId: string, name: string): Promise<void> => {
    setBusy(pluginId)
    setNotice(null)
    try {
      await solidify(name)
      setNotice({ kind: 'ok', text: t('solidifiedPrompted') })
    } catch (error: unknown) {
      setNotice({ kind: 'err', text: `${t('actionFailed')}: ${errMsg(error)}` })
    } finally {
      setBusy(null)
    }
  }

  return h('section', { style: styles.root },
    h('div', { style: styles.headingRow },
      h('h3', { style: styles.heading }, t('title')),
      h('div', { style: styles.actions },
        h('button', {
          type: 'button',
          style: busyAll ? { ...styles.buttonSecondary, ...styles.buttonDisabled } : styles.buttonSecondary,
          disabled: busyAll,
          onClick: () => void onExportAll(),
        }, busyAll ? t('working') : t('exportAll')),
        h('button', { type: 'button', style: styles.buttonSecondary, onClick: refresh }, t('refresh')),
      ),
    ),
    h('p', { style: styles.muted }, t('view.pluginsDescription')),
    notice ? h('p', { style: notice.kind === 'ok' ? styles.noticeOk : styles.noticeErr }, notice.text) : null,
    state.status === 'loading' ? h('p', { style: styles.muted }, t('loading')) : null,
    state.status === 'error'
      ? h(Fragment, null,
          h('p', { style: styles.error }, state.message),
          h('button', { type: 'button', style: styles.buttonSecondary, onClick: refresh }, t('retry')),
        )
      : null,
    state.status === 'ready' && state.plugins.length === 0
      ? h('p', { style: styles.muted }, t('view.empty'))
      : null,
    state.status === 'ready' && state.plugins.length > 0
      ? h('ul', { style: styles.list },
          state.plugins.map(plugin => pluginCard(plugin, t, busy, onReload, onUnload, onExportPlugin, onSolidify)),
        )
      : null,
  )
}