/** Copy for the dynamic-plugins Settings section. */

export type DynamicPluginsLocaleKey =
  | 'title'
  | 'description'
  | 'loading'
  | 'error'
  | 'retry'
  | 'empty'
  | 'import'
  | 'importing'
  | 'imported'
  | 'importFailed'
  | 'export'
  | 'edit'
  | 'editName'
  | 'editNamePlaceholder'
  | 'editPurpose'
  | 'editPurposePlaceholder'
  | 'save'
  | 'saving'
  | 'cancel'
  | 'edited'
  | 'editFailed'
  | 'delete'
  | 'deleting'
  | 'deleted'
  | 'deleteFailed'
  | 'deleteConfirm'
  | 'deleteConfirmYes'
  | 'noSession'
  | 'hostHalf'
  | 'clientHalf'
  | 'solidify'
  | 'solidifying'
  | 'solidified'
  | 'solidifiedImported'
  | 'solidifyFailed'
  | 'view.plugins'
  | 'view.pluginsDescription'
  | 'view.empty'
  | 'running'
  | 'stopped'
  | 'reload'
  | 'unload'
  | 'working'
  | 'refresh'
  | 'done'
  | 'actionFailed'
  | 'exportAll'
  | 'exportedCount'
  | 'solidifiedPrompted'

export const en: Record<DynamicPluginsLocaleKey, string> = {
  title: 'Dynamic plugins',
  description: 'Saved dynamic plugins, imported into the current session on demand.',
  loading: 'Loading…',
  error: 'Failed to load the plugin catalog.',
  retry: 'Retry',
  empty: 'No dynamic plugins saved yet. Export one from a session to see it here.',
  import: 'Import',
  importing: 'Importing…',
  imported: 'Plugin imported into the current session.',
  importFailed: 'Import failed',
  export: 'Export',
  edit: 'Edit',
  editName: 'Name',
  editNamePlaceholder: 'Plugin name',
  editPurpose: 'Purpose',
  editPurposePlaceholder: 'What this plugin does',
  save: 'Save',
  saving: 'Saving…',
  cancel: 'Cancel',
  edited: 'Plugin updated.',
  editFailed: 'Update failed',
  delete: 'Delete',
  deleting: 'Deleting…',
  deleted: 'Plugin deleted.',
  deleteFailed: 'Delete failed',
  deleteConfirm: 'Delete this plugin?',
  deleteConfirmYes: 'Delete',
  noSession: 'Open a session first — dynamic plugins import into the current session.',
  hostHalf: 'host',
  clientHalf: 'client',
  solidify: 'Consolidate',
  solidifying: 'Consolidating…',
  solidified: 'Asked the model to convert the plugin into a standard DeepSeek plugin.',
  solidifiedImported: 'Imported the plugin, then asked the model to convert it into a standard DeepSeek plugin.',
  solidifyFailed: 'Consolidate failed',
  'view.plugins': 'Plugins',
  'view.pluginsDescription': 'Dynamic plugins loaded into the current session.',
  'view.empty': 'No dynamic plugins loaded into the current session yet.',
  running: 'Running',
  stopped: 'Stopped',
  reload: 'Reload',
  unload: 'Unload',
  working: 'Working…',
  refresh: 'Refresh',
  done: 'Done.',
  actionFailed: 'Action failed',
  exportAll: 'Export all',
  exportedCount: 'Exported {count} plugin(s).',
  solidifiedPrompted: 'Asked the model to consolidate the plugin into a standard DeepSeek plugin.',
}

export const zh: Record<DynamicPluginsLocaleKey, string> = {
  title: '动态插件',
  description: '已保存的动态插件，可一键导入到当前会话。',
  loading: '加载中…',
  error: '加载插件列表失败。',
  retry: '重试',
  empty: '还没有保存的动态插件，先在会话里导出一个即可在这里看到。',
  import: '导入',
  importing: '导入中…',
  imported: '插件已导入到当前会话。',
  importFailed: '导入失败',
  export: '导出',
  edit: '编辑',
  editName: '名称',
  editNamePlaceholder: '插件名称',
  editPurpose: '意图',
  editPurposePlaceholder: '该插件的用途说明',
  save: '保存',
  saving: '保存中…',
  cancel: '取消',
  edited: '插件已更新。',
  editFailed: '更新失败',
  delete: '删除',
  deleting: '删除中…',
  deleted: '插件已删除。',
  deleteFailed: '删除失败',
  deleteConfirm: '确认删除该插件？',
  deleteConfirmYes: '删除',
  noSession: '请先打开一个会话——动态插件会导入到当前会话。',
  hostHalf: 'host',
  clientHalf: 'client',
  solidify: '沉淀',
  solidifying: '沉淀中…',
  solidified: '已让模型将该插件转换为标准 DeepSeek 插件。',
  solidifiedImported: '已导入插件，并让模型将其转换为标准 DeepSeek 插件。',
  solidifyFailed: '沉淀失败',
  'view.plugins': '插件',
  'view.pluginsDescription': '当前会话已加载的动态插件。',
  'view.empty': '当前会话还没有动态插件。',
  running: '运行中',
  stopped: '已停止',
  reload: '重新加载',
  unload: '卸载',
  working: '处理中…',
  refresh: '刷新',
  done: '操作完成。',
  actionFailed: '操作失败',
  exportAll: '全部导出',
  exportedCount: '已导出 {count} 个插件。',
  solidifiedPrompted: '已让模型将该插件沉淀为标准 DeepSeek 插件。',
}
