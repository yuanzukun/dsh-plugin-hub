/**
 * Browser half: contributes a "dynamic plugins" page to the Web Settings
 * surface and talks to the Host through plain HTTP routes
 * (`/api/dynamicPlugins/*`) instead of a Typert Remote service — the
 * dsh-web-ui convention, which needs no shared `@deepseek-ai` module instance.
 *
 * Cross-plugin collaboration is service-only (cordis), matching the client
 * bundle purity rule: every `@deepseek-ai/*` import here is type-only.
 */
import type {} from '@deepseek-ai/dsh-client-locale/client'
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client'
import type {} from '@deepseek-ai/dsh-client-ui-settings/client'
// Type-only: pulls the 'conversation.view' SlotMap row (declared by the
// slot's owning package) so the register call for the session Plugins tab
// types against the real view-slot contract.
import type {} from '@deepseek-ai/dsh-client-ui-conversation/client'
import { DynamicPluginsSettingsSection, type DynamicPluginsSettingsInjected } from './DynamicPluginsSettingsSection'
import { PluginRuntimeView, type PluginRuntimeViewInjected } from './PluginRuntimeView'
import { en, zh, type DynamicPluginsLocaleKey } from './locales'
import type {
  DynamicPluginsExportResult,
  DynamicPluginsListResult,
  DynamicPluginsLoadResult,
  DynamicPluginsReloadResult,
  DynamicPluginsRemoveResult,
  DynamicPluginsRuntimeResult,
  DynamicPluginsUnloadResult,
  DynamicPluginsUpdateResult,
} from '../types'

export type { DynamicPluginsSettingsInjected } from './DynamicPluginsSettingsSection'
export type { PluginRuntimeViewInjected } from './PluginRuntimeView'
export type { DynamicPluginsLocaleKey } from './locales'

/** Dictionary namespace owned by this plugin. */
export const NS = 'settings.dynamicPlugins'

/** Route prefix served by the Host half. */
const API_BASE = '/api/dynamicPlugins'

/** One JSON RPC envelope the Host routes answer with. */
type WireEnvelope<T> =
  | { ok: true; value: T }
  | { ok: false; error: { message: string } }

function isWireEnvelope(value: unknown): value is WireEnvelope<unknown> {
  return typeof value === 'object' && value !== null && 'ok' in value
}

/**
 * POST one `/api/dynamicPlugins/<method>` JSON route. The Host answers
 * `{ ok: true, value }` / `{ ok: false, error: { message } }`; a non-JSON or
 * non-2xx response surfaces as an HTTP/transport error.
 */
async function call<T>(method: string, args: Record<string, unknown> = {}): Promise<T> {
  let response: Response
  try {
    response = await fetch(`${API_BASE}/${method}`, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ args }),
    })
  } catch (error) {
    throw new Error(`dynamicPlugins.${method} failed: ${error instanceof Error ? error.message : String(error)}`)
  }
  let data: unknown
  try {
    data = await response.json()
  } catch {
    throw new Error(`dynamicPlugins.${method} failed: HTTP ${response.status}`)
  }
  if (!response.ok || !isWireEnvelope(data) || data.ok !== true) {
    const detail = isWireEnvelope(data) && !data.ok
      ? data.error.message
      : `HTTP ${response.status}`
    throw new Error(`dynamicPlugins.${method} failed: ${detail}`)
  }
  return data.value as T
}

/**
 * Custom nav icon SVG path for the dynamic-plugins settings section.
 * A hollow (outlined) puzzle-piece shape — top nub, right nub, left notch,
 * flat bottom, rounded corners — drawn as a stroked centerline so the glyph
 * renders as an outline matching the reference puzzle-icon style.
 * 20×20 viewBox; consumed via SVG stroke (currentColor), not fill.
 */
const DYNAMIC_PLUGINS_ICON_PATH = 'M5.5 16.5H12.5A1.5 1.5 0 0014 15V13a2 2 0 000-4V7a1.5 1.5 0 00-1.5-1.5H12a2 2 0 00-4 0H5.5A1.5 1.5 0 004 7V9a2 2 0 010 4v2a1.5 1.5 0 001.5 1.5z'

/** Mark attribute placed on our custom SVG to avoid re-patching the same node. */
const PATCHED_MARK = 'data-dp-nav-icon'

/**
 * Replace the generic gear icon next to our "Dynamic Plugins" nav entry with
 * a dedicated hollow puzzle-piece glyph. The settings shell hardcodes icons by
 * section id (in deepseek-harness) and cannot be modified from a plugin, so we
 * patch the DOM reactively — watching for the panel to mount / React to swap
 * nodes and re-applying our icon whenever the nav button appears.
 */
function installNavIconPatcher(getLabel: () => string): () => void {
  function patch(root: ParentNode = document): void {
    const label = getLabel()
    const buttons = root.querySelectorAll<HTMLButtonElement>('button')
    for (const btn of buttons) {
      const span = btn.querySelector('span')
      if (span?.textContent?.trim() !== label) continue
      const existing = btn.querySelector('svg')
      if (!existing) continue
      // Already patched — skip.
      if (existing.hasAttribute(PATCHED_MARK)) continue
      const newSvg = document.createElementNS('http://www.w3.org/2000/svg', 'svg')
      newSvg.setAttribute('width', '20')
      newSvg.setAttribute('height', '20')
      newSvg.setAttribute('viewBox', '0 0 20 20')
      newSvg.setAttribute('fill', 'none')
      // The nav cells use flex with a 16px icon box; our icon is 20px so we
      // collapse the extra 4px via symmetric negative margins — this keeps the
      // 20px glyph visually centered on the 16px baseline while the label text
      // starts at the same x as every other row.
      newSvg.style.margin = '0 -2px'
      newSvg.setAttribute(PATCHED_MARK, '1')
      for (const cls of existing.classList) newSvg.classList.add(cls)
      const path = document.createElementNS('http://www.w3.org/2000/svg', 'path')
      path.setAttribute('d', DYNAMIC_PLUGINS_ICON_PATH)
      path.setAttribute('stroke', 'currentColor')
      path.setAttribute('stroke-width', '1.5')
      path.setAttribute('stroke-linecap', 'round')
      path.setAttribute('stroke-linejoin', 'round')
      newSvg.appendChild(path)
      existing.replaceWith(newSvg)
    }
  }
  const observer = new MutationObserver((records) => {
    for (const r of records) {
      r.addedNodes.forEach(n => {
        if (n instanceof Element) patch(n)
      })
      // Character-data changes (locale switch) can update <span> labels — re-scan
      // the nearest dialog (or whole document) so the icon stays attached after
      // a re-render that swaps the SVG back to the default gear.
      if (r.type === 'characterData') {
        const parent = r.target.parentElement
        if (parent) patch(parent.closest('[role="dialog"]') ?? document)
      }
    }
  })
  observer.observe(document.body, { childList: true, subtree: true, characterData: true })
  patch()
  return () => observer.disconnect()
}

interface SessionsFace {
  list: { getSnapshot(): { current: string | undefined } }
  binding(id: string): {
    session: {
      prompt(content: Array<{ type: 'text'; text: string }>, mode: 'queue' | 'steer'): Promise<{ ok: boolean; error?: { message?: string } }>
    }
  } | undefined
}

/** The client-side Cordis runner face (`ctx.dynamicCordisRunner`). */
interface DynamicCordisRunnerClientFace {
  startUserRun(request: {
    agentId: string
    pluginId: string
    packageId: string
    mode: 'run'
    hasClientHalf: boolean
  }): Promise<void>
}

/** Required services (cordis fiber inject). */
export const inject = ['slots', 'locale', 'sessions', 'dynamicCordisRunner']

/**
 * Register the locale dictionary and add the Settings section. The panel talks
 * to the Host through plain `/api/dynamicPlugins/*` fetch routes.
 * @param ctx - the browser plugin context.
 */
export function apply(ctx: ClientContext): void {
  ctx.effect(() => ctx.locale.register(NS, { zh, en }), 'dsh-dynamic-plugin-manage: dictionaries')

  const t = ctx.locale.bind(NS)

  const list = async (): Promise<DynamicPluginsListResult> => call<DynamicPluginsListResult>('list')

  const load = async (packageName: string, sessionId: string): Promise<DynamicPluginsLoadResult> =>
    call<DynamicPluginsLoadResult>('load', { packageName, sessionId })

  const exportSession = async (sessionId: string): Promise<DynamicPluginsExportResult> =>
    call<DynamicPluginsExportResult>('exportSession', { sessionId })

  const exportPlugin = async (sessionId: string, pluginId: string): Promise<DynamicPluginsExportResult> =>
    call<DynamicPluginsExportResult>('exportPlugin', { sessionId, pluginId })

  const updatePackage = async (packageName: string, name: string, purpose: string): Promise<DynamicPluginsUpdateResult> =>
    call<DynamicPluginsUpdateResult>('updatePackage', { packageName, name, purpose })

  const removePackage = async (packageName: string): Promise<DynamicPluginsRemoveResult> =>
    call<DynamicPluginsRemoveResult>('removePackage', { packageName })

  const runtime = async (sessionId: string): Promise<DynamicPluginsRuntimeResult> =>
    call<DynamicPluginsRuntimeResult>('runtime', { sessionId })

  const unload = async (sessionId: string, pluginId: string): Promise<DynamicPluginsUnloadResult> =>
    call<DynamicPluginsUnloadResult>('unload', { sessionId, pluginId })

  const reload = async (sessionId: string, pluginId: string): Promise<DynamicPluginsReloadResult> =>
    call<DynamicPluginsReloadResult>('reload', { sessionId, pluginId })

  const currentSessionId = (): string | undefined =>
    (ctx as unknown as { sessions: SessionsFace }).sessions.list.getSnapshot().current

  /**
   * Run a freshly-defined package via the user-driven path. This settles with
   * `agent.inject` (silent) instead of the model-driven `run()` round-trip that
   * steers the model into replying.
   */
  const startRun = async (request: {
    pluginId: string
    packageId: string
    hasClientHalf: boolean
  }): Promise<void> => {
    const sessionId = currentSessionId()
    if (sessionId === undefined) throw new Error('no current session')
    const runner = (ctx as unknown as { dynamicCordisRunner: DynamicCordisRunnerClientFace }).dynamicCordisRunner
    await runner.startUserRun({
      agentId: sessionId,
      pluginId: request.pluginId,
      packageId: request.packageId,
      mode: 'run',
      hasClientHalf: request.hasClientHalf,
    })
  }

  /**
   * Prompt the model to convert the plugin named `name` into a standard
   * DeepSeek plugin and export it into the current session project. Shared by
   * the Settings "沉淀" flow (which imports-then-prompt) and the session
   * Plugins tab (which prompts for an already-loaded plugin).
   */
  const promptSolidify = async (sessionId: string, name: string): Promise<void> => {
    const sessions = (ctx as unknown as { sessions: SessionsFace }).sessions
    const binding = sessions.binding(sessionId)
    if (binding === undefined) throw new Error('no session binding')
    const promptText = `请将此插件「${name}」转换为标准 DeepSeek 插件的格式，并导出到当前会话项目里。`
    const promptResult = await binding.session.prompt([{ type: 'text', text: promptText }], 'queue')
    if (!promptResult.ok) {
      throw new Error(promptResult.error?.message ?? 'prompt failed')
    }
  }

  /**
   * Solidify (沉淀): ensure the plugin is imported into the current session,
   * then prompt the model to convert it into a standard DeepSeek plugin and
   * export it into the session project. Import never deduplicates, so the
   * package is always (re)defined; `startRun` only runs it when it was newly
   * defined.
   */
  const solidify = async (packageName: string, name: string): Promise<{ imported: boolean; prompted: boolean }> => {
    const sessionId = currentSessionId()
    if (sessionId === undefined) throw new Error('no current session')
    const result = await load(packageName, sessionId)
    const entry = result.results[0]
    if (entry === undefined || !entry.ok) {
      throw new Error(entry?.error ?? entry?.status ?? 'load failed')
    }
    if (entry.pluginId !== undefined && entry.packageId !== undefined) {
      await startRun({ pluginId: entry.pluginId, packageId: entry.packageId, hasClientHalf: entry.hasClientHalf === true })
    }
    await promptSolidify(sessionId, name)
    return { imported: true, prompted: true }
  }

  const injected = (): DynamicPluginsSettingsInjected => ({ list, load, updatePackage, removePackage, currentSessionId, startRun, solidify })

  // Session "Plugins" tab: contribute one entry to the conversation view ring.
  // The session header renders the tab bar from the 'conversation.view' slot
  // ledger, so this makes the tab appear and the body swap to our runtime view
  // when selected. The inject face binds the API calls to the focused session.
  ctx.slots.inject('conversation.view', () => ctx.slots.register({
    name: 'conversation.view',
    id: 'dynamic-plugins-runtime',
    order: 20,
    locale: NS,
    label: () => t('view.plugins'),
    inject: (sessionId: string): PluginRuntimeViewInjected => ({
      list: () => runtime(sessionId),
      unload: (pluginId) => unload(sessionId, pluginId),
      reload: (pluginId) => reload(sessionId, pluginId),
      exportAll: () => exportSession(sessionId),
      exportPlugin: (pluginId) => exportPlugin(sessionId, pluginId),
      solidify: (name) => promptSolidify(sessionId, name),
    }),
  }, PluginRuntimeView))

  // Install the DOM patcher that swaps the generic gear icon for our custom
  // plugin-block glyph next to the "Dynamic Plugins" nav entry. The settings
  // shell hardcodes nav icons by section id (in deepseek-harness) and cannot
  // be modified from a plugin, so we patch the DOM reactively.
  ctx.effect(() => installNavIconPatcher(() => t('title')), 'dsh-dynamic-plugin-manage: nav icon patcher')

  ctx.slots.inject('settings.section', () => ctx.slots.register({
    name: 'settings.section',
    id: 'dynamic-plugins',
    order: 90,
    label: () => t('title'),
    locale: NS,
    inject: injected,
  }, DynamicPluginsSettingsSection))
}
