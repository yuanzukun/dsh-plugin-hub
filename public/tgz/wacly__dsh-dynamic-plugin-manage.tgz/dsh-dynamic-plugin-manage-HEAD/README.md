# dsh-dynamic-plugin-manage

给 DeepSeek Harness（`dsh`）的动态插件补上「持久化」能力：把当前会话里的动态插件导出到磁盘保存，之后按需选择性地加载重放回来，重启不丢失。

## 功能

安装后，模型（AI）可以调用三个工具：

- `export_dynamic_plugins`：把当前会话的动态插件逐个导出保存到磁盘
- `list_dynamic_plugins`：列出磁盘上已保存的插件
- `load_dynamic_plugins`：按 `names`（包名）选择性加载指定插件

同时，Web 界面提供两个入口：

- **设置 → 动态插件**：管理磁盘仓库里的包——列表、导入、改名、删除、沉淀。
- **会话顶部「插件」tab**：展示当前会话已加载插件的运行时状态，支持全部导出、单插件导出、沉淀、重新加载、卸载。

## 使用示例

```
导出：「把当前会话的动态插件导出一下」
选择加载：「先列出可加载的插件」→「加载 xxx 和 yyy 这两个」
运行时管理：在会话顶部的「插件」tab 里卸载/重新加载已加载的插件
沉淀：「把这个插件沉淀成标准的 DeepSeek 插件」
```

## 安装

前置要求：已安装 dsh 并已创建目标 profile（如 `demo`）。

```sh
# 1. 在 deepseek-harness 仓库根目录安装插件
pnpm dsh plugin --profile demo add /absolute/path/to/dsh-dynamic-plugin-manage

# 2. 校验配置（应能看到 # == dsh-dynamic-plugin-manage 一层）
pnpm dsh --profile demo --dump-config

# 3. 启动
pnpm dsh --profile demo web
```

打开 Web 界面后，进入「设置」→「动态插件」管理磁盘仓库；或进入任意会话，在顶部「插件」tab 查看并管理当前会话已加载的插件。