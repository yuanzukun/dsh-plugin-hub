# 开发指南

## 构建

```sh
pnpm install   # 或 npm install；只会装 tsdown，@deepseek-ai/* 保持 external 不落地
pnpm run build
```

产物：

- `lib/index.js` — Host 插件（ESM，`@deepseek-ai/*` 与 `node:*` 保持 external，运行时由 dsh 安装解析）。
- `lib/client.js` — 浏览器插件（CJS closure-factory，`react` 与 `@deepseek-ai/*` 由 shell 的模块表解析，只内联本包自己的文件）。

> 说明：设置页的宿主通信走**普通 HTTP 路由**（dsh-web-ui 全家桶的惯例），不用 Typert Remote 服务——因此本插件**不依赖** `@deepseek-ai/dsh-typert-protocol`，也就不存在「SRC fallback 要求与 gateway 共享同一模块实例」的问题，源码检出、profile 安装、任何人任何环境都能直接跑。

## 会话「插件」tab

会话顶部的「插件」tab 通过 `conversation.view` slot 注册（client 侧 `inject` 清单需包含 `@deepseek-ai/dsh-client-ui-conversation`）。它展示当前会话已加载插件的运行时状态，并支持全部/单插件导出、沉淀、重新加载、卸载。host 侧对应新增 `/api/dynamicPlugins/runtime`、`/unload`、`/reload`、`/exportPlugin` 路由。

## 依赖说明

本插件**只用** `@deepseek-ai/dsh-tools`（`defineTool`，devDependencies，已发布 rc.6）和 `@deepseek-ai/dsh-host-webserver`（仅 `WebRoute` 类型，构建期擦除），**不依赖 `@deepseek-ai/dsh-typert-protocol`**——设置页走普通 HTTP 路由，不走 Typert Remote/gateway，所以没有「必须与宿主共享同一模块实例」的要求，也没有 `link:` 之类的开发期特殊配置。源码检出、`dsh plugin add` 安装、任何 dsh 版本（rc.5/rc.6）都能直接跑。

> 改完代码后**必须重启 dsh**：host 半边只在启动时加载，客户端 HMR 不会重载宿主侧。