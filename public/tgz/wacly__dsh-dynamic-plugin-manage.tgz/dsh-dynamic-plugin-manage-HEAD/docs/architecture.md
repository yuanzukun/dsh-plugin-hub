# 架构设计

本插件解决的是 dsh 动态插件的一个短板——`cordis_define` 只存在进程内存里，重启即消失。它在磁盘上建了一个「动态插件仓库」，补齐「源码别丢 + 随时可再装」这一环。

## 固定目录与包格式

默认 `~/.dsh/dynamic-plugins/`，若设置了 `$DSH_HOME` 则用 `$DSH_HOME/dynamic-plugins/`。

每个插件是一个**包**（一个目录），包名即目录名；保存时可指定包名，不指定则默认用 pluginId。包内拆成两部分：

```
<dir>/<packageName>/
├── define.json   # 除 code 外的元信息 + code 文件引用
├── host.js       # host 半边源码（有则存在）
└── client.js     # client 半边源码（有则存在）
```

`define.json` 的内容：

```json
{
  "name": "my-tool",
  "purpose": "注册一个 xxx 工具",
  "idPrefix": "mytool",
  "code": {
    "host": "host.js",
    "client": "client.js"
  }
}
```

`code` 字段不再是内联源码，而是**引用包内对应的代码文件**；真正的源码抽离成 `host.js` / `client.js`（有需要时也可引用更多文件，`code` 里的值就是相对包目录的文件路径）。

这份内容就是 `cordis_define` 需要的全部字段，所以重放时无需原始对话上下文。

> 兼容性：插件在 `list`/`load` 时会自动把旧格式的顶层 `<pluginId>.json`（内联 code）迁移成新包格式，迁移前会先写入并校验新包、确认无误才删除旧文件。

## 工作原理

- **导出**：`ctx.dynamicCordisRunner.listPlugins(agent)` 拿当前会话的插件 → 对每个取 `currentPackageId`（当前版本）或最新版本 → `inspectPackage(agent, pluginId, packageId)` 读出 `code: { host?, client? }` → 拆成 `define.json` + `host.js`/`client.js` 写入包目录。单插件导出与整会话导出共用同一个 `persistPlugin` 落盘逻辑。
- **加载**：读包目录里的 `define.json` + 引用的代码文件 → 对每个 `ctx.dynamicCordisRunner.define({ sessionId, plugin: { kind: 'new', idPrefix }, name, purpose, code })` → `ctx.dynamicCordisRunner.run(agent, pluginId, packageId, 'run', signal)`。
- **设置页**：浏览器半通过**普通 HTTP 路由** `/api/dynamicPlugins/list` / `/load` 等（`ctx.webServer.register` 的 exact 路由，POST `{ args }` → `{ ok, value|error }`）访问 host 侧的仓库；`load` 只 `define`（mint 新的 pluginId/packageId），浏览器半再走 `dynamicCordisRunner.startUserRun` 这个静默用户手势路径完成运行。
- **会话「插件」tab**：向主仓库的 `conversation.view` slot 注册一个 `dynamic-plugins-runtime` 视图，会话顶部的 tab 栏即出现「插件」入口。它通过 `/api/dynamicPlugins/runtime` 读取当前会话已加载插件的运行时状态（是否运行、host/client 半边、包版本），并提供 `/unload`（`undefine`）、`/reload`（先 `stop` 再 `run` 当前版本）以及单插件导出（`/exportPlugin`）与沉淀操作。

## 会话「插件」tab 与设置页的分工

- **设置页（仓库视角）**：管理磁盘仓库里的包——列表、导入、改名、删除、沉淀。**不再承担导出**（导出已迁移到会话 tab）。
- **会话「插件」tab（运行时视角）**：展示当前会话已加载的插件及其运行态，支持：全部导出（把当前会话所有插件落盘）、单插件导出、沉淀（把插件转为标准 dsh 插件）、重新加载、卸载。
- **沉淀（原名「固化」）**：把插件转为标准 dsh 插件。会话 tab 里插件已加载，因此只向模型发一条提示词（`promptSolidify`），**不重新加载/运行**；设置页里操作的是磁盘包，需先 `load` + `startRun` 再发提示词。

## 边界约定

沿用 dsh 的边界约定：

- 加载时插件归属**发起加载的那个会话**（动态插件是 session 私有的）。
- 带 `client` 半边的插件，`run` 可能返回 `awaiting-approval`，需要在浏览器页面点「运行」完成（纯 `host` 插件无此步骤）。
- 每次加载会 mint 新的 `pluginId`，与上次运行的 id 无关。

## 与官方两套机制的关系

- 它**不是**把动态插件变成静态 bundle，也不做「启动自动加载」——加载仍是按需、由你（或 AI）显式触发。
- 它只是给动态插件补了「源码落盘」这一环，让「重启后重放」变成一条工具调用（或设置页里的一次点击），而不是靠记忆里的旧对话上下文。

## 目录结构

```
dsh-dynamic-plugin-manage/
├── package.json         # dsh.bundle 清单 + dsh.client 清单 + dev 依赖
├── cordis.patch.yml     # bundle 配置层：插入一行挂载本插件（host 半边）
├── tsdown.config.ts     # 双半边构建：host + browser client
├── src/index.ts         # host 半边：三个工具 + /api/dynamicPlugins/* 路由（含 runtime/unload/reload/exportPlugin）
├── src/types.ts         # 前后端共享的 wire 类型（纯 JSON 载荷）
└── src/client/          # 浏览器半边：设置页「动态插件」栏目 + 会话「插件」tab + 文案
```