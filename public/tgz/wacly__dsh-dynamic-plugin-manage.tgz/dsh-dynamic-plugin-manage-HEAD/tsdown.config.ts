/**
 * Build config for the dsh-dynamic-plugin-manage dual-face bundle.
 *
 * Two artifacts:
 *   - `lib/index.js`  — Host plugin (ESM, Node): the three tools plus the
 *     `/api/dynamicPlugins/*` HTTP route family. Everything under
 *     `@deepseek-ai/` and `node:` stays external and is resolved by the dsh
 *     installation.
 *   - `lib/client.js` — Browser plugin (CJS closure-factory): the Settings
 *     "dynamic plugins" section. `react` and every `@deepseek-ai/*` value stays
 *     external (the frozen module table answers those `require`s); only this
 *     package's own files are inlined.
 */
import { defineConfig } from 'tsdown'

const id = 'dsh-dynamic-plugin-manage'

/** Never bundle the dsh runtime or Node builtins — dsh resolves both. */
const NEVER_BUNDLE = [/^@deepseek-ai\//, /^node:/]

export default defineConfig([
  {
    name: id,
    entry: { index: 'src/index.ts' },
    outDir: 'lib',
    format: ['esm'],
    platform: 'node',
    target: 'es2024',
    dts: false,
    // Wipe stale output once (this config runs first), then the client config
    // appends lib/client.js without cleaning it away.
    clean: true,
    fixedExtension: false,
    deps: { neverBundle: NEVER_BUNDLE },
  },
  {
    name: `${id}/client`,
    entry: { client: 'src/client/index.ts' },
    outDir: 'lib',
    format: ['cjs'],
    platform: 'browser',
    target: 'es2024',
    dts: false,
    clean: false,
    deps: { neverBundle: [...NEVER_BUNDLE, /^react/] },
    outputOptions: {
      entryFileNames: 'client.js',
      // The shell's `window.__ModuleLoader__` registers this factory; `require`
      // resolves the platform modules (react, cordis DI entities) from the
      // frozen module table, so no globals or import map are involved.
      banner: `window.__ModuleLoader__.load({ id: ${JSON.stringify(id)}, factory: (require) => {`,
      footer: 'return module.exports; } });',
      intro: 'var module = { exports: {} }; var exports = module.exports;',
    },
  },
])
