import { clientBundle } from './build/tsdown.client.ts'

export default clientBundle('dsh-live2d-avemujica', ['src/index.ts'])
