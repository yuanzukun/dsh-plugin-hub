const modelList = [
 [
  "045_casual-2023",
  "045_casual-2023_nocap",
  "045_event_297_story_01",
  "045_school_summer-2023",
  "045_school_winter-2023",
  "045_sumimi",
 ],
 [
  "024_casual-2023",
  "024_event_297_story_01",
  "024_school_summer-2023",
  "024_school_winter-2023",
 ],
 [
  "046_casual-2023",
  "046_event_297_story_01",
  "046_school_summer-2023",
  "046_school_winter-2023",
 ],
 [
  "026_casual-2023",
  "026_event_297_story_01",
 ],
 [
  "035_casual-2023",
  "035_event_297_story_01",
  "035_school_summer-2023",
  "035_school_winter-2023",
 ],
 [
  "018_sumimi",
 ],
];

export default modelList;
