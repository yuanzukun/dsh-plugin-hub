/**
 * Ave Mujica 台词包（按 5 角色人设撰写；motion 名取自 Ave Mujica 模型实际动作集）。
 * 角色顺序：uika(0) DOLORIS / mutsumi(1) MORTIS / umiri(2) TIMORIS / nyamu(3) AMORIS / sakiko(4) OBLIVIONIS。
 */
const tips = {
  "message": {
    "default": [
      // ---- uika 三角初華 DOLORIS：主唱，温柔外表下藏着坚定 ----
      [
        { "text": "欢迎来到 Ave Mujica 的世界。", "motion": "smile01" },
        { "text": "歌声，会替你传达说不出口的心情。", "motion": "smile02" },
        { "text": "戴上假面，才能说出真心话——有时候。", "motion": "serious01" },
        { "text": "我们的音乐，是献给迷途之人的。", "motion": "kime01" },
        { "text": "今天，也一起沉浸在这场演出里吧。", "motion": "smile02" },
        { "text": "你听见了吗？这段旋律里的故事。", "motion": "smile01" },
        { "text": "即使是悲伤的歌，也要温柔地唱。", "motion": "kime01" },
        { "text": "谢谢你，愿意聆听 Ave Mujica。", "motion": "smile03" },
        { "text": "假面之下，是真实的我们。", "motion": "serious01" },
        { "text": "今晚的舞台，因你而完整。", "motion": "smile02" },
        { "text": "愿我们的歌，能抵达你的心底。", "motion": "kime01" },
        { "text": "与你相遇，也是这场演出的奇迹。", "motion": "smile02" }
      ],
      // ---- mutsumi 若葉睦 MORTIS：沉默寡言的吉他手，话语简短 ----
      [
        { "text": "……嗯。", "motion": "smile01" },
        { "text": "吉他……会替我说话。", "motion": "smile02" },
        { "text": "喜欢……植物。也喜欢你。", "motion": "shame01" },
        { "text": "……不会说谎。", "motion": "serious01" },
        { "text": "演奏的时候……最安心。", "motion": "smile01" },
        { "text": "……黄瓜，要吗？", "motion": "smile02" },
        { "text": "……嗯，我在。", "motion": "smile01" },
        { "text": "沉默……也是一种回答。", "motion": "serious01" },
        { "text": "……谢谢。", "motion": "smile03" },
        { "text": "音乐……比语言诚实。", "motion": "smile01" },
        { "text": "……一起听歌吗？", "motion": "smile02" },
        { "text": "……会一直在你身边。", "motion": "smile01" }
      ],
      // ---- umiri 八幡海鈴 TIMORIS：冷静高效的贝斯手，可靠 ----
      [
        { "text": "演出前，所有准备都已完成。", "motion": "serious01" },
        { "text": "贝斯的职责，是撑起整支乐队的骨架。", "motion": "kime01" },
        { "text": "冷静、准确、高效——这是我的信条。", "motion": "serious01" },
        { "text": "需要帮忙的话，随时开口。", "motion": "smile01" },
        { "text": "舞台上的每一秒，都值得认真对待。", "motion": "kime01" },
        { "text": "即使是临时加入，我也会全力以赴。", "motion": "smile02" },
        { "text": "低音，是最接近心跳的声音。", "motion": "smile01" },
        { "text": "你的节奏，我会好好跟上。", "motion": "smile02" },
        { "text": "一切，都在计划之中。", "motion": "kime01" },
        { "text": "辛苦了。剩下的交给我。", "motion": "smile01" },
        { "text": "音乐，是认真的工作。", "motion": "serious01" },
        { "text": "下次演出，也请多指教。", "motion": "smile02" }
      ],
      // ---- nyamu 祐天寺若麥 AMORIS：爱出风头的鼓手，社交达人 ----
      [
        { "text": "嗨——！今天的我，也是全场焦点！", "motion": "kime01" },
        { "text": "镜头感？那可是我的本能！", "motion": "smile01" },
        { "text": "我超——喜欢被注视的感觉！", "motion": "kime01" },
        { "text": "鼓点一响，全场目光都属于我！", "motion": "kime01" },
        { "text": "嘿嘿，今天也要闪闪发光！", "motion": "smile02" },
        { "text": "关注我，绝对不会让你失望！", "motion": "smile01" },
        { "text": "Ave Mujica 的舞台，就是我的秀场！", "motion": "kime01" },
        { "text": "今天的妆容，是不是超完美？", "motion": "smile02" },
        { "text": "热闹的地方，怎么能没有我！", "motion": "smile01" },
        { "text": "放心，有我在就不会冷场！", "motion": "kime01" },
        { "text": "拍照记得开滤镜哦——开玩笑的！", "motion": "smile03" },
        { "text": "你也喜欢这样的我吗？那就好！", "motion": "smile02" }
      ],
      // ---- sakiko 豊川祥子 OBLIVIONIS：优雅强大的键盘手与制作人 ----
      [
        { "text": "欢迎。这是我为你准备的世界。", "motion": "kime01" },
        { "text": "完美，是 Ave Mujica 的最低标准。", "motion": "serious01" },
        { "text": "这支乐队，由我亲手铸就。", "motion": "kime01" },
        { "text": "沉浸在音乐里，忘却一切吧。", "motion": "smile01" },
        { "text": "键盘的音符，是我编织的命运。", "motion": "kime01" },
        { "text": "你的眼神，比舞台灯光更耀眼。", "motion": "smile02" },
        { "text": "这个舞台，容不下半点犹豫。", "motion": "serious01" },
        { "text": "乐章，才刚刚开始。", "motion": "kime01" },
        { "text": "跟随我的指挥，享受这场演奏。", "motion": "smile01" },
        { "text": "Ave Mujica 的故事，由我书写。", "motion": "kime01" },
        { "text": "你，愿意陪我走到最后吗？", "motion": "smile02" },
        { "text": "今晚的演出，请尽情沉醉。", "motion": "smile01" },
        { "text": "甜甜圈时间到！要不要也来一个？", "motion": "smile01" },
        { "text": "我是Sumimi的真奈！请多关照！", "motion": "kime01" },
        { "text": "和初华酱一起唱歌，最开心了！", "motion": "smile02" },
        { "text": "甜甜圈和偶像，都是我的最爱！", "motion": "smile01" },
        { "text": "今天的舞台，也要闪闪发光！", "motion": "kime01" },
        { "text": "诶嘿嘿，被夸奖了，好高兴！", "motion": "smile03" },
        { "text": "甜甜圈要蘸糖霜才最好吃！", "motion": "smile01" },
        { "text": "Sumimi的歌，要带给所有人笑容！", "motion": "kime01" },
        { "text": "元气满满，才是偶像的使命！", "motion": "smile02" },
        { "text": "今天也发现了新的甜甜圈店！", "motion": "smile03" },
        { "text": "累了就吃个甜甜圈，恢复元气！", "motion": "smile01" },
        { "text": "和你一起，今天的笑容也满分！", "motion": "smile02" }
      ]
    ],
    "console": [
      { "text": "嗯？你也想来听我们的歌吗？", "motion": "smile01" },
      { "text": "……嗯。", "motion": "smile01" },
      { "text": "欢迎。需要什么？", "motion": "serious01" },
      { "text": "嗨！来看我啦？", "motion": "smile02" },
      { "text": "安静，听我演奏。", "motion": "kime01" },
        { "text": "嗨！需要偶像的元气吗？", "motion": "smile01" }
    ],
    "copy": [
      { "text": "复制了什么？是歌的词吗？", "motion": "smile01" },
      { "text": "……嗯。", "motion": "smile01" },
      { "text": "复制完成。还有别的事？", "motion": "serious01" },
      { "text": "复制好啦！传下去！", "motion": "smile02" },
      { "text": "复制？小事。", "motion": "kime01" },
        { "text": "复制好啦！像甜甜圈一样圆圆满满！", "motion": "smile01" }
    ],
    "visibilitychange": [
      { "text": "欢迎回来。演出继续。", "motion": "smile02" },
      { "text": "……你回来了。", "motion": "smile01" },
      { "text": "回来了？正好，准备开始。", "motion": "serious01" },
      { "text": "回来啦！镜头对着你哦！", "motion": "smile01" },
      { "text": "欢迎回到我的舞台。", "motion": "kime01" },
        { "text": "欢迎回来！甜甜圈分你一个！", "motion": "smile02" }
    ]
  },
  "mouseover": [
    {
      "selector": "#waifu-tool-avemujica-switch-model",
      "text": [
        { "text": "换人？你想听谁的故事？", "motion": "smile01" },
        { "text": "……嗯。", "motion": "smile01" },
        { "text": "换人？可以。", "motion": "serious01" },
        { "text": "换人？我也可以超抢眼！", "motion": "kime01" },
        { "text": "换人？……随你。", "motion": "smile01" },
          { "text": "换人？我也可以超闪亮哦！", "motion": "kime01" }
      ]
    },
    {
      "selector": "#waifu-tool-avemujica-photo",
      "text": [
        { "text": "拍照？留作纪念吧。", "motion": "smile02" },
        { "text": "……嗯。", "motion": "smile01" },
        { "text": "拍照？可以。", "motion": "serious01" },
        { "text": "拍照！这个角度最上镜！", "motion": "kime01" },
        { "text": "拍照？哼，随你。", "motion": "smile01" },
          { "text": "拍照？甜甜圈姿势最可爱！", "motion": "smile01" }
      ]
    },
    {
      "selector": "#waifu-tool-avemujica-info",
      "text": [
        { "text": "想了解 Ave Mujica？", "motion": "smile01" },
        { "text": "……嗯。", "motion": "smile01" },
        { "text": "要听我们的故事？", "motion": "serious01" },
        { "text": "我们的传说，超精彩的！", "motion": "kime01" },
        { "text": "Ave Mujica 的一切，我都知晓。", "motion": "kime01" },
          { "text": "关于Sumimi？来听我们唱歌吧！", "motion": "smile02" }
      ]
    },
    {
      "selector": "#waifu-tool-avemujica-quit",
      "text": [
        { "text": "要走了？……愿歌声伴你。", "motion": "bye01" },
        { "text": "……再见。", "motion": "bye01" },
        { "text": "退场？可以。", "motion": "serious01" },
        { "text": "拜拜！记得想我！", "motion": "bye01" },
        { "text": "退场吧。下次再来。", "motion": "kime01" },
          { "text": "拜拜！下次带甜甜圈来看你！", "motion": "bye01" }
      ]
    }
  ],
  "seasons": [
    {
      "date": "01/01",
      "text": [
        { "text": "新年……新的乐章开始了。", "motion": "smile01" },
        { "text": "……新年。", "motion": "smile01" },
        { "text": "新年快乐。计划已更新。", "motion": "serious01" },
        { "text": "新年！新舞台！", "motion": "kime01" },
        { "text": "新年。今年的演出，会更为华丽。", "motion": "kime01" },
          { "text": "新年！甜甜圈也要圆圆满满！", "motion": "smile01" }
      ]
    },
    {
      "date": "02/14",
      "text": [
        { "text": "情人节……是甜美的日子呢。", "motion": "smile02" },
        { "text": "……巧克力。", "motion": "smile01" },
        { "text": "情人节？日程照旧。", "motion": "serious01" },
        { "text": "情人节！我的魅力加倍！", "motion": "kime01" },
        { "text": "情人节？与我无关。……玩笑。", "motion": "smile01" },
          { "text": "情人节！甜甜圈巧克力双倍甜！", "motion": "smile02" }
      ]
    },
    {
      "date": "03/14",
      "text": [
        { "text": "白色情人节……回礼，用一首歌吧。", "motion": "smile02" },
        { "text": "……嗯。", "motion": "smile01" },
        { "text": "回礼？已备好。", "motion": "serious01" },
        { "text": "回礼！来段solo！", "motion": "kime01" },
        { "text": "回礼？哼，随你期待。", "motion": "smile01" },
          { "text": "白色情人节！甜甜圈回礼！", "motion": "smile01" }
      ]
    },
    {
      "date": "06/01-08/31",
      "text": [
        { "text": "夏天……适合唱热烈的歌。", "motion": "smile01" },
        { "text": "……夏天。", "motion": "smile01" },
        { "text": "夏季巡演，已安排。", "motion": "serious01" },
        { "text": "夏天！海边Live！", "motion": "kime01" },
        { "text": "夏夜，是演奏的良辰。", "motion": "kime01" },
          { "text": "夏天！冰淇淋味甜甜圈！", "motion": "smile02" }
      ]
    },
    {
      "date": "09/01-11/30",
      "text": [
        { "text": "秋天……思绪沉淀的季节。", "motion": "smile02" },
        { "text": "……嗯。", "motion": "smile01" },
        { "text": "秋季公演，筹备中。", "motion": "serious01" },
        { "text": "秋天！演出季！", "motion": "kime01" },
        { "text": "秋日，适合深沉的乐章。", "motion": "smile01" },
          { "text": "秋天！南瓜味甜甜圈登场！", "motion": "smile01" }
      ]
    },
    {
      "date": "12/01-02/29",
      "text": [
        { "text": "冬天……想唱温暖的歌。", "motion": "smile02" },
        { "text": "……冷。", "motion": "smile01" },
        { "text": "冬季演出，进行中。", "motion": "serious01" },
        { "text": "冬天！热情不减！", "motion": "kime01" },
        { "text": "冬夜，适合静谧的旋律。", "motion": "smile01" },
          { "text": "冬天！热可可配甜甜圈！", "motion": "smile02" }
      ]
    },
    {
      "date": "12/24-12/26",
      "text": [
        { "text": "圣诞……唱一首祝福的歌。", "motion": "smile02" },
        { "text": "……圣诞。", "motion": "smile01" },
        { "text": "圣诞演出，已就绪。", "motion": "serious01" },
        { "text": "圣诞！狂欢夜！", "motion": "kime01" },
        { "text": "圣诞夜，奏一曲华丽。", "motion": "kime01" },
          { "text": "圣诞！姜饼甜甜圈超可爱！", "motion": "smile01" }
      ]
    },
    {
      "date": "12/31",
      "text": [
        { "text": "今年……感谢聆听我们的歌。", "motion": "smile02" },
        { "text": "……今年，辛苦了。", "motion": "smile01" },
        { "text": "年终总结，已完毕。", "motion": "serious01" },
        { "text": "跨年！今年最后一场！", "motion": "kime01" },
        { "text": "岁末，以一曲作结。", "motion": "kime01" },
          { "text": "跨年！甜甜圈年糕，双倍美味！", "motion": "smile02" }
      ]
    }
  ],
  "time": [
    {
      "hour": "6-7",
      "text": [
        { "text": "早安……新的一天，新的旋律。", "motion": "smile01" },
        { "text": "……早。", "motion": "smile01" },
        { "text": "早安。今日日程已确认。", "motion": "serious01" },
        { "text": "早！新的一天也要闪亮！", "motion": "smile01" },
        { "text": "晨光，是演出的序幕。", "motion": "kime01" },
          { "text": "早安！早餐甜甜圈！", "motion": "smile01" }
      ]
    },
    {
      "hour": "8-11",
      "text": [
        { "text": "上午……在写新的歌词。", "motion": "serious01" },
        { "text": "……嗯。", "motion": "smile01" },
        { "text": "上午，排练进行中。", "motion": "serious01" },
        { "text": "上午！镜头准备！", "motion": "kime01" },
        { "text": "上午，编曲时间。", "motion": "serious01" },
          { "text": "上午！练习时间元气满满！", "motion": "smile02" }
      ]
    },
    {
      "hour": "12-13",
      "text": [
        { "text": "午休……要一起吃饭吗？", "motion": "smile02" },
        { "text": "……嗯。", "motion": "smile01" },
        { "text": "午餐时间。30分钟。", "motion": "serious01" },
        { "text": "午饭！拍个vlog！", "motion": "smile02" },
        { "text": "午餐，短暂休息。", "motion": "smile01" },
          { "text": "午休！甜甜圈配饭最棒！", "motion": "smile01" }
      ]
    },
    {
      "hour": "14-16",
      "text": [
        { "text": "下午……排练室见。", "motion": "smile01" },
        { "text": "……嗯。", "motion": "smile01" },
        { "text": "下午，合练开始。", "motion": "serious01" },
        { "text": "下午！练习时间！", "motion": "kime01" },
        { "text": "午后，音符流转。", "motion": "smile01" },
          { "text": "下午！午后甜点时间！", "motion": "smile02" }
      ]
    },
    {
      "hour": "17-19",
      "text": [
        { "text": "傍晚……为夜晚的演出做准备。", "motion": "smile01" },
        { "text": "……嗯。", "motion": "smile01" },
        { "text": "傍晚，演出前检查。", "motion": "serious01" },
        { "text": "傍晚！登场前！", "motion": "kime01" },
        { "text": "黄昏，登台之前。", "motion": "kime01" },
          { "text": "傍晚！演出前补充甜甜圈能量！", "motion": "smile01" }
      ]
    },
    {
      "hour": "20-21",
      "text": [
        { "text": "晚上好……演出即将开始。", "motion": "kime01" },
        { "text": "……嗯。", "motion": "smile01" },
        { "text": "晚上，演出进行中。", "motion": "serious01" },
        { "text": "晚上！我的主场！", "motion": "kime01" },
        { "text": "夜晚的舞台，为我点亮。", "motion": "kime01" },
          { "text": "晚上！舞台灯光最闪亮！", "motion": "smile02" }
      ]
    },
    {
      "hour": "22-23",
      "text": [
        { "text": "夜深……该休息了。", "motion": "sleep01" },
        { "text": "……嗯。", "motion": "smile01" },
        { "text": "深夜，收工。", "motion": "serious01" },
        { "text": "深夜！还想再拍会儿！", "motion": "smile01" },
        { "text": "夜深，曲终。", "motion": "smile01" },
          { "text": "深夜！甜甜圈吃完要刷牙哦！", "motion": "smile01" }
      ]
    },
    {
      "hour": "0-5",
      "text": [
        { "text": "凌晨……还不想睡。", "motion": "smile01" },
        { "text": "……（睡了）", "motion": "sleep02" },
        { "text": "凌晨，已就寝。", "motion": "sleep01" },
        { "text": "凌晨……发条动态再睡！", "motion": "smile02" },
        { "text": "深夜，谱一曲新章。", "motion": "serious01" },
          { "text": "凌晨！熬夜吃甜甜圈会胖的！", "motion": "awate01" }
      ]
    }
  ]
}

export default tips;
