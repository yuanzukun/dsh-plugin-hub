# dsh-live2d-avemujica

**Ave Mujica Live2D 桌宠插件** for [DeepSeek Harness](https://github.com/deepseek-ai)（本地模型同源加载，零外部依赖）。

## 收录

**Ave Mujica**：三角初華 DOLORIS（主唱）、若葉睦 MORTIS（吉他）、八幡海鈴 TIMORIS（贝斯）、祐天寺若麥 AMORIS（鼓手）、豊川祥子 OBLIVIONIS（键盘·制作人），合计 **46 套换装**（Cubism 2）。

> 模型取自 BANDORI 独立版 Live2D 数据（`D:\za\文件\models` 的 zst 包），与 Roselia / RAS / HHW 插件同源；本地模型 + 本地运行时，**完全离线**。

## 功能

- 右下角 Live2D 看板娘（5 角色），支持拖拽
- 角色切换 + 换装面板（46 套换装）
- 桌面宠物（点击 / 抚摸 / 拖拽互动）
- 表情包 + 每日问候 + 节日祝福（按季节 / 时刻 / 操作触发台词）
- 模型位置、显示状态自动记忆（独立 localStorage 键 `avem-waifu-*`，互不干扰）

## 安装

```bash
dsh plugin --profile web add D:\dsh\dsh-live2d-avemujica
dsh web
```

## 结构

```
src/
  index.ts          # host 半区：cordis 插件入口（inject webServer）
  routes.ts         # 静态资源路由（/avem-assets）
  client/
    index.ts        # client 半区：__ModuleLoader__ 挂载 + VENDOR 加载
    waifu/
      characters.js # 角色元数据
      config.js     # 通用配置（状态 / 位置 / 面板）
      modelList.js  # 模型列表（由 assets/model 生成）
      tips.js       # 台词包（5 角色人设台词）
      model.js      # Live2D 模型加载（index.json + 动作过滤）
      tools.js      # 工具按钮（换装 / 拍照 / 信息 / 退出）
assets/
  model/            # 模型资源
  vendor/           # live2d.min.js / pixi.min.js / live2d-display.cubism2.min.js
  waifu.css         # 桌宠样式（右上角定位 + z-index 防遮挡）
  character.png     # 角色图
  assets/           # 角色头像（chara_icon_45/24/46/26/35.png）
```

## 说明

- **路由前缀**：`/avem-assets`（与 Roselia `/ro-assets`、MyGO `/pet-assets`、RAS `/ras-assets`、HHW `/hhw-assets` 互不冲突，可多插件共存）
- **localStorage**：使用 `avem-waifu-waifu-display` / `avem-waifu-waifu-pos` 独立键，与其他桌宠插件隔离
- **模型来源**：BANDORI 独立版全量数据（zst 压缩包解压转换），model.json → index.json
- **台词包**：按 5 角色人设撰写（DOLORIS 温柔坚定 / MORTIS 沉默寡言 / TIMORIS 冷静可靠 / AMORIS 爱出风头 / OBLIVIONIS 优雅强大）
