import { describe, expect, it } from 'vitest'
import {
  COMPRESS_FAILURE_COOLDOWN,
  SURGE_RATIO,
  decidePressureCompaction,
  dynamicCompactionRatio,
  nextGrowthEma,
  shouldCompressHistory,
  shouldNudgeCompaction,
  type NudgeInput,
} from '../src/core.ts'

describe('decidePressureCompaction', () => {
  it('delegates when no narrowed window is known', () => {
    expect(decidePressureCompaction({
      declaredWindow: 100_000,
      narrowedWindow: undefined,
      measuredTokens: 999_999,
      thresholdRatio: 0.8,
    })).toEqual({ mode: 'delegate' })
  })

  it('skips while below the narrowed-window threshold', () => {
    // Local model: catalog declares 100K, probe finds the server runs 32K.
    // Threshold = floor(32768 × 0.8) = 26214.
    const decision = decidePressureCompaction({
      declaredWindow: 100_000,
      narrowedWindow: 32_768,
      measuredTokens: 20_000,
      thresholdRatio: 0.8,
    })
    expect(decision.mode).toBe('skip')
    expect(decision.thresholdTokens).toBe(26_214)
  })

  it('forces the balanced reduction once the real ceiling is approached', () => {
    // 27k measured tokens: below the declared threshold (80k) the base policy
    // would wait, but the 32K model cannot hold this conversation.
    const decision = decidePressureCompaction({
      declaredWindow: 100_000,
      narrowedWindow: 32_768,
      measuredTokens: 27_000,
      thresholdRatio: 0.8,
    })
    expect(decision.mode).toBe('force')
    expect(decision.thresholdTokens).toBe(26_214)
  })

  it('forces even when DSH has no declared capacity for the target', () => {
    const decision = decidePressureCompaction({
      declaredWindow: undefined,
      narrowedWindow: 32_768,
      measuredTokens: 27_000,
      thresholdRatio: 0.8,
    })
    expect(decision.mode).toBe('force')
  })

  it('delegates when the narrowed window matches the declared one (base retains a tail)', () => {
    // GLM-style: override == declared (1M). The base pressure path compacts
    // with proper tail retention at the same threshold — prefer it.
    const decision = decidePressureCompaction({
      declaredWindow: 1_000_000,
      narrowedWindow: 1_000_000,
      measuredTokens: 900_000,
      thresholdRatio: 0.8,
    })
    expect(decision.mode).toBe('delegate')
  })

  it('skips when a higher override keeps the base from compacting too early', () => {
    // Override (400K) > declared (128K): between the two thresholds the
    // override is authoritative and no compaction should run.
    const decision = decidePressureCompaction({
      declaredWindow: 131_072,
      narrowedWindow: 400_000,
      measuredTokens: 200_000,
      thresholdRatio: 0.8,
    })
    expect(decision.mode).toBe('skip')
    expect(decision.thresholdTokens).toBe(320_000)
  })

  it('honors a per-target threshold ratio override', () => {
    const decision = decidePressureCompaction({
      declaredWindow: 100_000,
      narrowedWindow: 32_768,
      measuredTokens: 15_000,
      thresholdRatio: 0.5,
    })
    expect(decision.mode).toBe('skip')
    expect(decision.thresholdTokens).toBe(16_384)
  })
})

describe('dynamicCompactionRatio', () => {
  it('applies the base ratio unchanged at or below 50% fill', () => {
    expect(dynamicCompactionRatio(0.8, 0.6, 0.4)).toBeCloseTo(0.8)
    expect(dynamicCompactionRatio(0.8, 0.6, 0.5)).toBeCloseTo(0.8)
    expect(dynamicCompactionRatio(0.8, 0.6, 0)).toBeCloseTo(0.8)
  })

  it('slides linearly between base and floor as the window fills past 50%', () => {
    // t = (0.6-0.5)/0.4 = 0.25 → 0.8 - 0.2×0.25 = 0.75
    expect(dynamicCompactionRatio(0.8, 0.6, 0.6)).toBeCloseTo(0.75)
    // t = (0.7-0.5)/0.4 = 0.5 → 0.8 - 0.2×0.5 = 0.7
    expect(dynamicCompactionRatio(0.8, 0.6, 0.7)).toBeCloseTo(0.7)
  })

  it('bottoms out at the floor at 90% fill and stays there', () => {
    expect(dynamicCompactionRatio(0.8, 0.6, 0.9)).toBeCloseTo(0.6)
    expect(dynamicCompactionRatio(0.8, 0.6, 1)).toBeCloseTo(0.6)
  })

  it('honors a custom base/floor pair', () => {
    expect(dynamicCompactionRatio(0.7, 0.5, 0.9)).toBeCloseTo(0.5)
    expect(dynamicCompactionRatio(0.7, 0.5, 0.5)).toBeCloseTo(0.7)
  })

  it('never raises the trigger above the base when the floor is unusable', () => {
    // A misconfigured floor (0.9 > base 0.7) used to win the `Math.max` and
    // push the trigger ABOVE the configured threshold — its exact opposite.
    expect(dynamicCompactionRatio(0.7, 0.9, 1)).toBeCloseTo(0.7)
    expect(dynamicCompactionRatio(0.7, 0.9, 0.6)).toBeCloseTo(0.7)
    expect(dynamicCompactionRatio(0.7, 0.7, 1)).toBeCloseTo(0.7)
    // Non-finite or non-positive floors collapse the curve to "always
    // compress", so they are ignored and the base ratio applies.
    expect(dynamicCompactionRatio(0.8, Number.NaN, 1)).toBeCloseTo(0.8)
    expect(dynamicCompactionRatio(0.8, -1, 1)).toBeCloseTo(0.8)
    expect(dynamicCompactionRatio(0.8, 0, 1)).toBeCloseTo(0.8)
  })
})

describe('decidePressureCompaction with dynamicRatio', () => {
  it('still skips below the (dynamically lowered) threshold', () => {
    const decision = decidePressureCompaction({
      declaredWindow: 100_000,
      narrowedWindow: 32_768,
      measuredTokens: 18_000, // fill ≈ 0.55 → ratio ≈ 0.775 → threshold ≈ 25400
      thresholdRatio: 0.8,
      dynamicRatio: true,
      dynamicRatioFloor: 0.6,
    })
    expect(decision.mode).toBe('skip')
    expect(decision.thresholdTokens ?? 0).toBeLessThan(26_214) // lower than the static 0.8 threshold
  })

  it('forces EARLIER than the static ratio once the real window fills past ~50%', () => {
    // Static (0.8): threshold 26214 → 24000 measured would SKIP.
    // Dynamic: fill 24000/32768 ≈ 0.732 → ratio ≈ 0.684 → threshold ≈ 22411 → FORCE.
    expect(decidePressureCompaction({
      declaredWindow: 100_000,
      narrowedWindow: 32_768,
      measuredTokens: 24_000,
      thresholdRatio: 0.8,
    }).mode).toBe('skip')
    const decision = decidePressureCompaction({
      declaredWindow: 100_000,
      narrowedWindow: 32_768,
      measuredTokens: 24_000,
      thresholdRatio: 0.8,
      dynamicRatio: true,
      dynamicRatioFloor: 0.6,
    })
    expect(decision.mode).toBe('force')
    expect(decision.thresholdTokens ?? 0).toBeLessThan(26_214)
  })

  it('never forces a window equal to the declared one, even when nearly full (online model)', () => {
    // 1M online model: at 90% fill the dynamic ratio drops to 0.6, but since
    // narrowed == declared (1M), the base path must handle it (proper tail
    // retention) rather than the overflow-style forced reduction.
    const decision = decidePressureCompaction({
      declaredWindow: 1_000_000,
      narrowedWindow: 1_000_000,
      measuredTokens: 900_000,
      thresholdRatio: 0.8,
      dynamicRatio: true,
      dynamicRatioFloor: 0.6,
    })
    expect(decision.mode).toBe('delegate')
    expect(decision.thresholdTokens).toBe(600_000)
  })

  it('forces with no declared capacity when over the dynamic threshold', () => {
    const decision = decidePressureCompaction({
      declaredWindow: undefined,
      narrowedWindow: 32_768,
      measuredTokens: 24_000,
      thresholdRatio: 0.8,
      dynamicRatio: true,
      dynamicRatioFloor: 0.6,
    })
    expect(decision.mode).toBe('force')
  })

  it('honors a custom dynamic floor', () => {
    const decision = decidePressureCompaction({
      declaredWindow: 100_000,
      narrowedWindow: 32_768,
      measuredTokens: 31_000,
      thresholdRatio: 0.8,
      dynamicRatio: true,
      dynamicRatioFloor: 0.5, // very aggressive: fires at half the window
    })
    expect(decision.mode).toBe('force')
    expect(decision.thresholdTokens).toBe(16_384)
  })
})

describe('shouldCompressHistory', () => {
  const base = {
    force: false,
    turn: 10,
    lastCompressedTurn: undefined,
    lastTokens: undefined,
    tokens: 0,
    triggerTokens: 700,
    windowTokens: 8_000,
    compressInterval: 7,
    failureCooldown: 0,
  }

  it('always compresses when forced', () => {
    expect(shouldCompressHistory({ ...base, force: true, tokens: 1 }))
      .toEqual({ compress: true, reason: 'forced' })
  })

  it('waits while below the trigger water level', () => {
    expect(shouldCompressHistory({ ...base, tokens: 700 }))
      .toEqual({ compress: false, reason: 'below-trigger' })
  })

  it('compresses on pressure once the interval has elapsed', () => {
    expect(shouldCompressHistory({
      ...base, tokens: 800, lastTokens: 750, turn: 10, lastCompressedTurn: 3,
    })).toEqual({ compress: true, reason: 'pressure' })
  })

  it('rate-limits pressure compression inside the interval', () => {
    expect(shouldCompressHistory({
      ...base, tokens: 800, lastTokens: 750, turn: 5, lastCompressedTurn: 3,
    })).toEqual({ compress: false, reason: 'rate-limited' })
  })

  it('bypasses the interval on a single-round token surge (long thinking turn)', () => {
    // 2_000-token growth ≥ SURGE_RATIO × 8_000 window: compress immediately
    // even though only 1 round passed since the last compression.
    expect(shouldCompressHistory({
      ...base, tokens: 2_800, lastTokens: 800, turn: 4, lastCompressedTurn: 3,
    })).toEqual({ compress: true, reason: 'surge' })
    expect(Math.floor(8_000 * SURGE_RATIO)).toBe(1_600)
  })

  it('does not treat slow growth as a surge', () => {
    expect(shouldCompressHistory({
      ...base, tokens: 1_200, lastTokens: 800, turn: 4, lastCompressedTurn: 3,
    })).toEqual({ compress: false, reason: 'rate-limited' })
  })

  it('waits out the failure cooldown, then compresses again', () => {
    const cooldown = shouldCompressHistory({
      ...base, tokens: 800, turn: 20, lastCompressedTurn: 3, failureCooldown: COMPRESS_FAILURE_COOLDOWN,
    })
    expect(cooldown).toEqual({ compress: false, reason: 'cooldown' })
    const recovered = shouldCompressHistory({
      ...base, tokens: 800, lastTokens: 750, turn: 20, lastCompressedTurn: 3, failureCooldown: 0,
    })
    expect(recovered).toEqual({ compress: true, reason: 'pressure' })
  })

  it('reports the FIRST observation as pressure, not surge, when over the trigger', () => {
    // A restored/imported session with a big history is not a single-round
    // surge — it is plain pressure. Compresses immediately (fresh session),
    // but with the honest reason.
    const first = shouldCompressHistory({
      ...base, tokens: 800, lastTokens: undefined, lastCompressedTurn: undefined,
    })
    expect(first).toEqual({ compress: true, reason: 'pressure' })
  })
})

describe('nextGrowthEma', () => {
  it('seeds on the first delta, then halves the weight of each new one', () => {
    expect(nextGrowthEma(undefined, 1_000)).toBe(1_000)
    expect(nextGrowthEma(1_000, 2_000)).toBe(1_500)
    expect(nextGrowthEma(1_500, 0)).toBe(750)
  })

  it('never goes negative and ignores a non-finite delta', () => {
    expect(nextGrowthEma(1_000, -500)).toBe(250)
    expect(nextGrowthEma(100, -1_000)).toBe(0)
    expect(nextGrowthEma(1_000, Number.NaN)).toBe(1_000)
    expect(nextGrowthEma(undefined, Number.NaN)).toBe(0)
  })
})

describe('shouldNudgeCompaction', () => {
  const base: NudgeInput = {
    enabled: true,
    tokens: 700,
    growthTokens: 200,
    triggerTokens: 800,
    turn: 10,
    failureCooldown: 0,
  }

  it('fires when the next step would cross the trigger anyway', () => {
    expect(shouldNudgeCompaction(base)).toBe(true)
    // Exactly reaching the trigger counts; the regular check stays authoritative.
    expect(shouldNudgeCompaction({ ...base, tokens: 600, growthTokens: 200 })).toBe(true)
  })

  it('stays quiet when growth cannot reach the trigger', () => {
    expect(shouldNudgeCompaction({ ...base, tokens: 100, growthTokens: 100 })).toBe(false)
  })

  it('defers to the regular trigger once over it', () => {
    expect(shouldNudgeCompaction({ ...base, tokens: 800 })).toBe(false)
    expect(shouldNudgeCompaction({ ...base, tokens: 900, growthTokens: 50 })).toBe(false)
  })

  it('is off when disabled, when growth is unknown, or during a cooldown', () => {
    expect(shouldNudgeCompaction({ ...base, enabled: false })).toBe(false)
    expect(shouldNudgeCompaction({ ...base, growthTokens: 0 })).toBe(false)
    expect(shouldNudgeCompaction({ ...base, growthTokens: Number.NaN })).toBe(false)
    expect(shouldNudgeCompaction({ ...base, failureCooldown: COMPRESS_FAILURE_COOLDOWN })).toBe(false)
  })

  it('never asks twice in the same turn', () => {
    expect(shouldNudgeCompaction({ ...base, lastCompressedTurn: 10 })).toBe(false)
    expect(shouldNudgeCompaction({ ...base, lastCompressedTurn: 9 })).toBe(true)
  })
})
