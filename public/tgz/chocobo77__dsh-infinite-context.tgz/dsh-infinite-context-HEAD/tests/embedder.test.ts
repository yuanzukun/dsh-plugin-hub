import { describe, expect, it } from 'vitest'
import {
  LightweightEmbedder,
  cosineSimilarity,
  createEmbedder,
  fnv1a,
  normalize,
  tokenize,
} from '../src/core.ts'

describe('createEmbedder', () => {
  it('fails fast when the optional transformers package is missing', async () => {
    // This checkout does not install the optional dependency, so the factory
    // must reject HERE with a clear message instead of handing back an embedder
    // whose every embed() later fails inside best-effort retrieval paths.
    // (If the package is ever added, revisit this expectation.)
    await expect(createEmbedder({ kind: 'transformers', dimension: 256 }))
      .rejects.toThrow(/@huggingface\/transformers/)
  })

  it('builds the default lightweight embedder', async () => {
    const embedder = await createEmbedder({ kind: 'lightweight', dimension: 64 })
    expect(embedder.dimension).toBe(64)
    expect(await embedder.embed('hello')).toHaveLength(64)
  })
})

describe('tokenize', () => {
  it('splits ASCII words, Han unigrams and Han bigrams', () => {
    expect(tokenize('Hello world')).toEqual(['hello', 'world'])
    // Han runs: unigrams PLUS adjacent bigrams — the standard CJK
    // lexical-retrieval feature set (compounds like 世界 become first-class
    // tokens; single characters alone carry almost no discriminative power).
    expect(tokenize('Hello World, 你好世界'))
      .toEqual(['hello', 'world', '你', '好', '世', '界', '你好', '好世', '世界'])
  })
})

describe('fnv1a', () => {
  it('is deterministic and differs across distinct tokens', () => {
    const a = fnv1a('alpha')
    const b = fnv1a('beta')
    expect(a).toBe(fnv1a('alpha'))
    expect(a).not.toBe(b)
    expect(a).toBeGreaterThanOrEqual(0)
    expect(a).toBeLessThan(0x1_0000_0000)
  })
})

describe('normalize', () => {
  it('L2-normalizes a non-zero vector', () => {
    const v = normalize([3, 4])
    expect(Math.hypot(v[0], v[1])).toBeCloseTo(1)
  })

  it('leaves a zero vector as-is', () => {
    const z = normalize([0, 0])
    expect(z).toEqual([0, 0])
  })
})

describe('cosineSimilarity', () => {
  it('returns 1 for identical vectors and 0 for orthogonal', () => {
    expect(cosineSimilarity([1, 0], [1, 0])).toBeCloseTo(1)
    expect(cosineSimilarity([1, 0], [0, 1])).toBeCloseTo(0)
  })

  it('returns 0 when lengths differ', () => {
    expect(cosineSimilarity([1], [1, 0])).toBe(0)
  })
})

describe('LightweightEmbedder', () => {
  it('produces a fixed-dimension normalized vector deterministically', async () => {
    const e = new LightweightEmbedder(64)
    const a = await e.embed('setup sqlite schema and index')
    const b = await e.embed('setup sqlite schema and index')
    expect(a).toHaveLength(64)
    expect(a).toEqual(b)
    const norm = Math.hypot(...a)
    expect(norm).toBeCloseTo(1)
  })

  it('gives lexically-similar texts a higher cosine than dissimilar ones', async () => {
    const e = new LightweightEmbedder(256)
    const q = await e.embed('how to configure the token budget')
    const related = await e.embed('configure token budget thresholds')
    const unrelated = await e.embed('deploy the web server over https')
    expect(cosineSimilarity(q, related)).toBeGreaterThan(cosineSimilarity(q, unrelated))
  })

  it('rejects a too-small dimension', () => {
    expect(() => new LightweightEmbedder(4)).toThrow(RangeError)
  })

  it('supports CJK text', async () => {
    const e = new LightweightEmbedder(256)
    const v = await e.embed('配置 token 预算和记忆管理')
    expect(v.some(x => x !== 0)).toBe(true)
  })
})

describe('createEmbedder', () => {
  it('builds a lightweight embedder by default', async () => {
    const e = await createEmbedder({ kind: 'lightweight', dimension: 128 })
    expect(e.name).toContain('lightweight')
    expect(e.dimension).toBe(128)
  })

  it('rejects an unknown kind', async () => {
    await expect(createEmbedder({ kind: 'bogus' as never, dimension: 128 })).rejects.toThrow()
  })
})
