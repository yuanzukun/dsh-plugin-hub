# 统一压缩治理方案（草案 v1）

> 状态：**已批准，分期实施中**。P1（统一曲线）与 P2（单一策略函数 + fold 执行器接线）已实现并通过全量测试；**P2 的行为变化需在真实会话上验证**（`compaction_governance` 可一键回退）。
> 实现前先读完本方案 + ARCHITECTURE.md §7.5–7.8 / §10–12。
> 目标：把当前四条改写下文的路径收敛成**一个决策点 + 两个执行器 + 一条兜底链**，并合并两套动态阈值。

---

## 0. 目标与非目标

### 目标
- **G1 单一决策点**：每一步只做一次『是否压 / 压哪条 lane / 压到哪』的判断。
- **G2 单一水位曲线**：合并 durable lane 的 dynamicCompactionRatio 与 fold lane 的 dynamicHistoryLevels。
- **G3′ 单一计量源（已修正，见 §13）**：统一接口为 SurfaceSnapshot，但 surface 取 **DSH meter 与插件 CJK 启发式的较大值**给保守上界；totalTokens 按同一增量抬起以保住 envelope。**不能**直接切 tokenMeter（它对 CJK 用 CHARS_PER_TOKEN=4，无 CJK 支路，会低估约 4×）。
- **G4 硬边界常开**：无论开关如何，trigger/target 都受硬上下限约束。
- **G5 可观测**：每步产生一条 CompactionPlan，落到 usage ledger 与 memory_status。
- **G6 默认行为等价、可回滚**：P0–P2 保持现有默认配置的实际行为（误差在验收阈值内），任一期可独立回退。

### 非目标（本方案不做）
- 不重写 compaction-basic 的 range 选择、durable 记录与 tool-pair 平衡逻辑。
- 不合并 fallbackTruncate 与 thinking-guard 的实现，只把它们纳入统一兜底链的定义。
- 不修改 RAG 注入语义（surface dedup、每轮一条、idempotent directive 保持不变）。

---

## 1. 现状精确定位

### 1.1 两条 lane、四个执行器

| lane | 执行器 | 入口 | 触发 | 改写对象 | 落点 |
|---|---|---|---|---|---|
| durable | super.compactIfNeeded / compactWithDynamicLine | MemoryCompactionEngine.compactIfNeeded | base 压力 / 溢出 / 窄窗强制 | session.surface（region） | durable compaction/summary + storeMemory('mid') |
| fold | HistoryCompressor.compress | agent/pre-step 第二个 hook | shouldCompressHistory（阈值/interval/surge/nudge） | decision.messages | user 摘要消息 + storeMemory('mid') |
| truncate | fallbackTruncate | 同上，注入之后 | 注入后仍超预算 | decision.messages | 直接丢消息 |
| guard | registerThinkingGuard | llm/stream | 生成中途逼近窗口 | 终止生成 | 注入 CONTEXT_WINDOW_EXCEEDED → 回到 durable |

问题：durable 与 fold 由**不同 hook、在不同数组上、用不同计量**各自评估；同一步可能先 durable 再 fold，或 fold 触发时 durable 已经改写完 surface。你上两轮遇到的两个 storm 都是这个结构的下游症状。

### 1.2 两套动态阈值
- durable：thresholdRatioFor(target) = modelPolicies[].thresholdRatio ?? config.thresholdRatio；曲线 dynamicCompactionRatio(thresholdRatio, compaction_dynamic_floor, fill)，fill = measuredTokens / narrowedWindow。
- fold：compress_trigger_ratio / compress_target_ratio；曲线 dynamicHistoryLevels(growthEMA, compressions, compressInterval...)，basis = window × (1 - headroom)。
- 二者开关也不同：compaction_dynamic_threshold vs compress_dynamic_levels。

### 1.3 三个计量源
1. ctx.tokenMeter.measure(session).totalTokens / surfaceTokens / nodes —— replay-aware、按 route 定价、baseline 可复用 provider usage（这是 DSH 提供的正确源）。
2. HistoryCompressor.estimateMessageTokens(messages) —— 插件自己实现的 CJK + other/4 启发式。
3. thinking-guard 内部的 estimateRequestTokens —— 第三份启发式。

fold lane（最频繁、最安全敏感）用的是第 2 种，而第 1 种明明已可用。**G3 就是删掉第 2 种作为决策依据。**

---

## 2. 目标架构

~~~
agent/pre-step  hook A (governor, 由本插件 override compactIfNeeded)
   measure(session, header) -> SurfaceSnapshot
   plan(snapshot, ledger, config) -> CompactionPlan   [纯函数]
   pendingPlan.set(session, plan)
     action == 'durable' -> 触发 durable 执行器（super 路径 / dynamic-line 路径）
     action == 'fold'    -> 不做 durable，留给 hook B
     action == 'none'    -> 什么都不做

agent/pre-step  hook B (injector)
   plan = pendingPlan.take(session)
   if plan.action == 'fold' -> fold executor 用 plan 改写 decision.messages
   retrieve -> inject -> fallbackTruncate

llm/stream  hook C (thinking guard)
   生成中途越线 -> CONTEXT_WINDOW_EXCEEDED -> durable 执行器
~~~

要点：
- plan() 每步只算一次（hook A），hook B 不再重新判断，只执行。
- hook A 看不到 decision.messages，但能看到 session.surface 与 tokenMeter；fold 的决策只需要 token 数与区间，执行才需要 messages，所以『A 决策、B 执行』可行。
- hook C 触发时 surface 已变，重新 measure 一次，只允许 durable lane。

---

## 3. 统一数据模型（拟新增 src/compaction-governance.ts）

~~~ts
/** 单步的归一化表面快照（全部来自 tokenMeter）。 */
export interface SurfaceSnapshot {
  /** 整个请求的压力（含 system/tools/envelope） */
  readonly totalTokens: number
  /** 仅 surface 节点之和 */
  readonly surfaceTokens: number
  /** totalTokens - surfaceTokens，即 system/tools/固定开销 */
  readonly fixedTokens: number
  /** 路由模型 resolved 的真实窗口（narrowed ?? declared ?? override） */
  readonly window: number
  /** DSH 声明窗口，用于判断 narrowed < declared */
  readonly declaredWindow?: number
  /** 本步请求的 header，用来让 measure 选定 route 定价 */
  readonly requestHeader?: EpochHeader
}

/** 统一治理输入。 */
export interface GovernanceInput {
  readonly snapshot: SurfaceSnapshot
  readonly ledger: SessionLedgerSnapshot
  readonly config: ResolvedGovernanceConfig
  /** base 传来的 trigger（pressure/context-overflow/...），供 durable 路径判别 */
  readonly incomingTrigger: string
  /** 手动强制压缩 */
  readonly force: boolean
}

export type GovernanceLane = 'none' | 'fold' | 'durable'

export interface CompactionPlan {
  readonly lane: GovernanceLane
  readonly reason:
    | 'below-trigger' | 'nudge' | 'surge' | 'pressure'
    | 'narrowed-window' | 'overflow' | 'fit-guard'
    | 'cooldown' | 'rate-limited' | 'forced'
  /** durable 触发线（totalTokens 口径） */
  readonly triggerTokens: number
  /** fold 触发线（surfaceTokens 口径 = triggerTokens - fixedTokens） */
  readonly surfaceTriggerTokens: number
  /** fold 目标水位（surfaceTokens 口径） */
  readonly targetSurfaceTokens: number
  readonly triggerRatio: number
  readonly targetRatio: number
  /** 观测量：三个驱动与合成 urgency，用于调参与排障 */
  readonly drivers: {
    readonly fill: number
    readonly growth: number
    readonly stage: number
    readonly urgency: number
  }
}
~~~

SessionLedgerSnapshot 由现有四份状态合并：turn、lastCompressedTurn、lastTokens、growthEma、lastSizeTokens、compressions、failureCooldown、lastForceAt。P0 只搬位置不改语义。

---

## 4. 统一水位曲线

### 4.1 输入归一化
~~~
pressure = totalTokens / window                 // 请求真实占用，provider 关心的量
growthRatio = clamp(growthEma / window, 0, 0.5)
stageRatio  = clamp(compressions / MATURE, 0, 1)
anchor      = clamp(laneAnchor, TARGET_FLOOR + MIN_BAND, CEILING)
floor       = min(anchor, TRIGGER_FLOOR)
~~~

### 4.2 触发（合并 fill-driven 与 growth/stage-driven）
~~~
fillPressure   = clamp((pressure - FILL_START) / FILL_SPAN, 0, 1)   // FILL_START=0.5, FILL_SPAN=0.4
growthPressure = clamp(growthRatio / HOT_GROWTH, 0, 1)
stagePressure  = stageRatio
urgency        = max(fillPressure, growthPressure, stagePressure)
triggerRatio   = anchor - (anchor - floor) * urgency
~~~
说明：fill 窗口沿用旧 dynamicCompactionRatio 的 0.5→0.9（这样才能行为等价）；旧的 dynamicCompactionRatio 只含 fillPressure，旧的 dynamicHistoryLevels 只含 growth/stage。取 max 后两条 lane 共用同一条曲线，且**单调、有界**。fill 项对 fold lane 缺省为 0，所以 fold 行为不变。

### 4.3 幅度（band 覆盖一个完整周期）
~~~
configuredBand = max(MIN_BAND, anchor - laneTargetAnchor)
reserve        = growthRatio * interval + SAFETY + STAGE_BAND * stageRatio
band           = clamp(max(configuredBand, reserve), MIN_BAND, MAX_BAND)
targetRatio    = clamp(triggerRatio - band, TARGET_FLOOR, max(TARGET_FLOOR, triggerRatio - MIN_BAND))
~~~
- fold lane：targetRatio 直接驱动 fold 的 foldTokensForTarget。
- durable lane：targetRatio 先作为**建议值**（P2 只用于决策线），保留策略仍走 base 的 retainRatio/retainTokens；P4 可选让 durable 也吃 targetRatio（需要改 resolveCompactSpec 的 retain 计算，风险单列）。

### 4.4 硬边界（常开）
| 常量 | 值 | 作用 |
|---|---|---|
| TRIGGER_CEILING | 0.92 | 任何配置/信号都不能让触发线高于它 |
| TRIGGER_FLOOR | 0.65 | 滑落下限（**相对 anchor**：配置的 anchor 低于它时以配置为准，防 churn 而不覆盖刻意的早压设置） |
| TARGET_FLOOR | 0.25 | 最低目标水位 |
| MIN_BAND | 0.08 | 每次压缩必须腾出的最小空间 |
| MAX_BAND | 0.45 | 防止一次压空 |

### 4.5 与旧曲线的等价性
- 当 growth=0、stage=0 时：urgency = fillPressure，trigger 退化到旧的 dynamicCompactionRatio；target 退化到 laneTargetAnchor。
- 当 fill < anchor 时 fillPressure=0，trigger 只被 growth/stage 拉低，与旧 dynamicHistoryLevels 一致。
- 提供**等价测试**：在旧参数网格上，新曲线的 trigger 与两条旧曲线分别比较（见 §9）。

---

## 5. 路由规则（lane 选择）

严格按优先级，先到先得：

~~~
function planCompaction(input): CompactionPlan {
  const { force, incomingTrigger } = input
  const { totalTokens, surfaceTokens, fixedTokens, window, declaredWindow } = snapshot
  const levels = compactionWaterLevels(...)          // §4
  const triggerTokens = floor(window * levels.triggerRatio)
  const surfaceTriggerTokens = max(1, triggerTokens - fixedTokens)

  // 0) 手动强制：默认走 fold（便宜、保留尾部）；溢出触发走 durable
  if (force) return fold('forced', ...)
  if (incomingTrigger === 'context-overflow') return durable('overflow', ...)

  // 1) 冷却 / 限流（surge 与 fit-guard 可豁免）
  const surge = (totalTokens - ledger.lastTokens) >= SURGE_RATIO * window
  const fitGuard = totalTokens >= window - guardReserve(window, config)
  if (fitGuard) return durable('fit-guard', ...)              // 最后保险，任何 gate 都不能挡
  if (ledger.failureCooldown > 0) return none('cooldown')
  if (ledger.roundsSinceCompaction < interval && !surge) return none('rate-limited')

  // 2) 越线：窄窗/真实窗口不足优先 durable，否则 fold
  const over = totalTokens >= triggerTokens
  const narrowedShort = declaredWindow !== undefined && window < declaredWindow
  if (over && (narrowedShort || incomingTrigger === 'pressure')) {
    // 窄窗：base 的 balanced reduction 更安全（保留尾部、tool-pair 对齐）
    return durable(narrowedShort ? 'narrowed-window' : 'pressure', ...)
  }
  if (over) return fold('pressure', ...)

  // 3) 预测：下一轮会越线则提前 fold
  if (config.nudge && surfaceTokens + growthEma >= surfaceTriggerTokens) return fold('nudge', ...)

  return none('below-trigger')
}
~~~

关键取舍：
- **durable 只在两类情况下走**：(a) 窄窗/溢出（真实窗口比声明小，或 provider 已报溢出）；(b) fit-guard 最后保险。其余稳态一律 fold，便宜且保留 recent 尾部。
- **surge 豁免 interval**，但**不豁免 cooldown**（沿用现语义）。
- **fit-guard 豁免所有 gate**，包括 cooldown/interval——这是『确保不爆』的硬兜底，等价于现在的 thinking-guard 触发但提前到 pre-step。
- 一步最多一条 lane（pendingPlan 独占）。

---

## 6. 状态模型（SessionLedger）

合并现有分散状态为**一个** per-session 条目，持久化到同一 KV key（compression:<sessionId>）：

~~~ts
interface SessionLedger {
  turn: number
  lastActive: number
  lastCompressedTurn?: number
  lastTokens?: number
  growthEma?: number
  lastSizeTokens?: number
  compressions: number
  failureCooldown: number
  lastForceAt?: number        // 由 Map<string,number> 迁入，天然随会话回收
}
~~~

- 单一 touch/restore/persist 路径；cleanupStale 只删这一个 Map。
- lastForceAt 从全局 Map 迁入 ledger 后，不再需要单独的 cleanupStaleForceMarks。
- 事件：compaction 成功/失败/跳过（含 reason）写入 usage ledger，供 memory_status 观测。

---

## 7. 配置合并与兼容

### 7.1 新增/复用
| 键 | 默认 | 语义 |
|---|---|---|
| compaction_governance | true | 统一总开关：关闭=两条 lane 都用静态 anchor（硬边界仍常开） |
| thresholdRatio | 0.7 | durable lane 的 anchor（保留 modelPolicies override） |
| compress_trigger_ratio | 0.75 | fold lane 的 anchor |
| compress_target_ratio | 0.6 | fold lane 的 configuredBand 来源 |
| compaction_dynamic_floor | 0.5 | 统一触发下限 floor（两条 lane 共享） |
| compress_round_interval | 7 | 统一 rate limit |

### 7.2 废弃（保留别名一个版本）
| 旧键 | 处理 |
|---|---|
| compaction_dynamic_threshold | 别名到 compaction_governance（true 则 true），加载时 logger.warn 一次 |
| compress_dynamic_levels | 同上 |

### 7.3 解析规则
- 若显式设置了 compaction_governance 用它；否则 governance = (compaction_dynamic_threshold ?? true) || (compress_dynamic_levels ?? true)。
- 两条 lane 的 anchor 各自保留：它们执行器不同、成本不同，per-lane anchor 是合法调参面；**被合并的是动态曲线、计量、状态与决策**，不是 anchor 值。
- 若要彻底单 anchor，可用 min(thresholdRatio, compress_trigger_ratio)（见 §12 Q1）。

---

## 8. 分期实施

| 期 | 内容 | 改动文件 | 行为变化 | 回滚 |
|---|---|---|---|---|
| P0 ✅(部分) | lastForceAt 并入 SessionCounter（单一 ledger、随 KV 持久化与清理）；新增 SurfaceSnapshot / toSurfaceSnapshot 统一计量原语（保守取 max + 测试）。fold 决策切换推迟到 P2（见 §13） | memory-compaction.ts、compaction-governance.ts、core.ts、tests | 无（等价测试 + force 冷却现可跨重启） | 恢复旧字段 |
| P1 ✅ | 新增 compactionWaterLevels / compactionTriggerRatio 纯函数；dynamicHistoryLevels / dynamicCompactionRatio 改成其薄适配器（两条 lane 共用同一条曲线） | 新增 compaction-governance.ts、compaction-policy.ts、core.ts、tests/compaction-governance.test.ts | 无（等价测试全绿） | 保留旧函数 |
| P2 ✅ | 新增 planCompaction（单一策略：lane + 水位 + fit-guard）；fold 执行器按 plan 执行；`compaction_governance` 总开关（显式 opt-in，出厂 true） | compaction-governance.ts、memory-compaction.ts、config.ts、tests | 有（fold 目标等价；新增 fit-guard），可一键回退 | compaction_governance=false |
| P3 ✅(文档部分) | `compaction_governance` 文档 + 启动提示；durable lane 硬上限 + fit-guard；旧键去留见 §12 Q5 | config.ts、memory-compaction.ts、docs | durable 触发点被 0.92 封顶（安全） | 恢复旧逻辑 |
| P4 | 删除死代码（dynamicCompactionRatio、重复状态、旧估计决策路径）；ARCHITECTURE 更新 | 多处 | 无 | git revert |

每期独立 PR、独立可验证、独立回滚。P2 之前默认行为不变。

---

## 9. 测试矩阵

### 9.1 纯函数（新增 governance.test.ts）
- 边界：trigger 永不 > CEILING、永不 < floor；target 永不 < TARGET_FLOOR；band ∈ [MIN_BAND, MAX_BAND]；非有限输入退化。
- 单调：growth ↑ / stage ↑ / fill ↑ ⇒ trigger 不升、target 不升。
- 等价：growth=0 & stage=0 时，trigger 与旧 dynamicCompactionRatio 在 fill 网格上误差 < 1e-6；fill<anchor 时与旧 dynamicHistoryLevels 一致。
- 路由矩阵：narrowed<declared × over × surge × cooldown × fit-guard 的真值表。

### 9.2 契约（假 Context）
- hook A 每步只产生一个 plan，pendingPlan 被 take 后置空。
- durable 执行后 hook B 不再 fold；fold 执行后不再 durable。
- fit-guard 在 cooldown/interval 下仍然触发。
- 计量：surfaceTriggerTokens + fixedTokens == triggerTokens（±1）。

### 9.3 golden 场景（回放脚本）
- 稳态慢增长：压缩频率 ≈ 总额外增长 / band，且相邻压缩间隔 >= interval。
- 热增长（大工具结果）：提前触发、不越窗口、无连续两轮压缩（上一轮 storm 的回归）。
- 空闲后恢复：stage 不导致额外压缩（decay 见 §12 Q2）。
- 窄窗模型：优先 durable，且触发点 ≈ window × triggerRatio。

### 9.4 观测
- 每次压缩写 usage 事件：lane、reason、trigger/target、drivers、saved tokens。
- memory_status 显示当前 plan 与最近 N 次决策。

---

## 10. 风险与回滚

| 风险 | 缓解 |
|---|---|
| hook A 与 decision.messages 的时序（A 看不到 messages） | A 只做 token 决策，B 执行；用 pendingPlan 显式传递；P2 前两者各自判断，P2 开关可回退 |
| tokenMeter 与 estimateMessageTokens 口径差导致触发点漂移 | P0 先并行度量、记录差值，确认 < 阈值再切；差值大则先修计量再 P1 |
| durable lane 的 targetRatio 语义与其 retain 机制不一致 | P2 只用于决策线；P4 才评估是否让 durable 吃 targetRatio，单列风险 |
| 继承 base 的内部契约 | 本方案不动继承结构；若 base 升级，另立『组合化』方案 |
| 配置别名迁移引发加载失败 | 别名只增不删一个版本；schema 保留旧键，解析层映射 |

---

## 11. 验收标准

1. 每步只有一条 lane 动作，日志/ledger 可证明。
2. 默认配置下，P2 前后的触发序列在 golden 回放上一致率 >= 95%（差异必须能由新曲线解释）。
3. 硬边界在全部测试与随机 fuzz 下成立。
4. 上一轮两个 storm 的回归用例恒通过。
5. 全量单测（现有 297 + 新增）通过；memory-compaction 首次有契约测试。

---

## 12. 待你拍板的开放问题

- ~~Q1 anchor 是否也合并~~ → **已定：保留 per-lane anchor**（用户 2026-xx 批准）。合并的是曲线/计量/状态/决策，anchor 仍分 lane。
- **Q2 stage 是否衰减**：backlog 里提过 stage 单调导致长会话永久激进；本方案是否顺带做时间/窗口衰减？
- ~~Q3 fit-guard 的 reserve~~ → **已定：window 百分比**（P2 实施，替代固定 2048）。
- **Q4 P4 是否让 durable 也吃统一 target**：收益是真正单曲线，代价是要改 base 的 retain 计算，风险较高。
- **Q5 旧键是否保留**：别名迁移一个版本后删除，还是长期保留？

---

## 13. 实施记录

### 13.1 P1（已合并）
- `src/compaction-governance.ts` 成为两条 lane 共用的唯一曲线实现；`dynamicCompactionRatio` / `dynamicHistoryLevels` 改为薄适配器，逐点等价。
- 测试：`tests/compaction-governance.test.ts`（等价 golden + 边界 + 单调 + fill 压力）。

### 13.2 P0（部分完成）
- **状态统一**：`lastForceAt` 从引擎的 `Map<string,number>` 移入 `SessionCounter`，经 `HistoryCompressor.markForce()` 读写；删除 `cleanupStaleForceMarks()`。副作用（正向）：force 冷却现在随 KV 持久化，重启后不会立刻再强制一次。
- **计量原语**：`toSurfaceSnapshot({totalTokens, surfaceTokens, window, declaredWindow?, alternateSurfaceTokens?})`。

### 13.3 关键修正：DSH meter 不是 CJK-aware（影响 G3/P2）
证据（DSH checkout `packages/llm/token-meter/lib/types/estimate.js`）：
~~~
const CHARS_PER_TOKEN = 4        // 无 CJK 支路
estimateContent: text → ceil(text.length / 4) + BLOCK_OVERHEAD
~~~
本插件 `estimateTokens`：`ceil(CJK×1 + other/4)`。同一段中文：插件 ≈ 1×字符数，DSH ≈ 0.25×字符数 ⇒ **DSH 低估约 4×**。

`measure()` 在稳定态会拿 provider 真实 usage 做 baseline（baseline.kind='usage'），但**anchor 之后新增的节点仍按 /4 重新定价**；中文持续增长的会话因此会在两次 anchor 之间被低估。

**修正后的 G3′**：
- 唯一接口仍是 `SurfaceSnapshot`；
- `surfaceTokens = max(meter.surfaceTokens, pluginCjkEstimate)`；
- `totalTokens` 按 `max(0, surfaceTokens - meter.surfaceTokens)` 抬起，保证 `fixedTokens`（system/tools/envelope）不变；
- P2 里 fold lane 的 `alternateSurfaceTokens` 传插件的 CJK 估计；durable lane 直接用 meter 值（它本来就有 usage anchor）。
- 遗留：与 provider usage 的在线校准（predicted/actual 系数）单列为后续项，不阻塞 P2。

这一修正意味着 P2 的验收标准要加一条：**中文回放会话在 P2 前后的触发点差异必须可由『保守取 max』解释**，不能出现在 meter 低估时更晚压缩的情况。

### 13.4 P2 实施（单一策略 + fold 接线）

- 新增 `planCompaction(input)`：唯一策略函数，按 `capabilities`（fold / durable）决定 lane、水位与 fit-guard；路由顺序刻意对齐旧 `shouldCompressHistory`（force → overflow → fit-guard → nudge → below-trigger → cooldown → surge → interval → rate-limited），保证 fold 行为等价。
- fold 执行器：`CompressOptions.plan`；`HistoryCompressor.compress()` 有 plan 时不再自行判断，直接按 plan 的 target 折叠；无 plan 时走旧路径。
- 统一计量：fold snapshot 用**插件 CJK 估计**作为 surface、`tokenMeter` 的 `totalTokens − surfaceTokens` 作为 envelope；`ledgerOf(sessionId, surfaceTokens)` 复算与执行器完全一致的 growth EMA。
- **basis 修正**（实施中发现）：fold 的基数是 `budget = window×(1−headroom)`、被测量是 surface；durable 是 `window`/total。原方案的单一 `window` 基数会让 fold 触发点从 ~0.56×window 跳到 0.75×window。现在 `GovernanceInput` 显式接收 `basisTokens` / `measuredTokens` / `fillRatio`，两条 lane 共用策略但各自基数。
- `compaction_governance` 显式 opt-in（缺省 false 保持旧行为）；出厂 `cordis.yml` / `bundle.patch.yml` 设为 true。

### 13.5 接线契约测试（纯化）

为消除『私有接线只靠 typecheck』的盲区，把两段引擎逻辑抽成**纯函数**并单测：
- `ledgerView(entry, surfaceTokens)`：upcoming turn（+1）、按当前 surface 复算 growth EMA、缺省值。`HistoryCompressor.ledgerOf` 直接委托。
- `planFoldCompaction(input)`：fold lane 的 snapshot（CJK surface + meter envelope）、effective-budget 基数、`fillRatio: 0`、injection 预留、fit-guard 降级。引擎直接调用。
- 新增 10 条用例（ledgerView 4 + planFoldCompaction 6，含 fit-guard 降级、rate-limit、nudge、目标水位算式、恶意输入）。

**仍缺**：真正构造假 Context 跑 `agent/pre-step` 的端到端测试（导入 `memory-compaction.ts` 会拉起 BasicCompactionEngine 与 DSH peer）。当前契约测试覆盖到纯接线层，hooks 层仍靠真实会话验证。

**待真实会话验证**：fold 触发序列、fit-guard 是否抢在 durable 之前、中文会话触发点不回退。任一异常可 `compaction_governance: false` 立即回退。
