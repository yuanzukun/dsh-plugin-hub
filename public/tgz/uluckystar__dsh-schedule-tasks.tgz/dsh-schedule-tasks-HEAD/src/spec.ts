/**
 * 定时任务的持久化 schema（自管 JSON 文件：$DSH_HOME/storages/schedule_tasks.json）。
 * 全部字段经 zod 校验，加载时容错（缺失/损坏返回空表）。
 */

import { z } from 'zod'
import type { ScheduleTask, ScheduleTaskAction, TaskId, TaskLogEntry } from './types.ts'

/** 非负安全整数（时间戳 / 毫秒耗时）。 */
const nonNegativeSafeInteger = z.number().int().nonnegative().max(Number.MAX_SAFE_INTEGER)

/** 任务 id：非空字符串，带品牌。 */
export const taskIdSchema = z.string().min(1).transform((id): TaskId => id as TaskId)

/** 触发动作：按 kind 判别。 */
export const taskActionSchema = z.discriminatedUnion('kind', [
  z.object({ kind: z.literal('shell'), command: z.string().min(1) }),
  z.object({ kind: z.literal('notify'), message: z.string().min(1) }),
]) as unknown as z.ZodType<ScheduleTaskAction>

/** 一次执行记录。 */
export const taskLogEntrySchema = z.object({
  id: taskIdSchema,
  at: nonNegativeSafeInteger,
  ok: z.boolean(),
  detail: z.string(),
  durationMs: nonNegativeSafeInteger,
}) as unknown as z.ZodType<TaskLogEntry>

/** 一条持久化任务。日志环形缓冲由宿主在写入时裁剪。 */
export const scheduleTaskSchema = z.object({
  id: taskIdSchema,
  name: z.string().min(1),
  cron: z.string().min(1),
  action: taskActionSchema,
  enabled: z.boolean(),
  createdAt: nonNegativeSafeInteger,
  updatedAt: nonNegativeSafeInteger,
  nextRunAt: nonNegativeSafeInteger.nullable(),
  lastRunAt: nonNegativeSafeInteger.optional(),
  lastResult: taskLogEntrySchema.optional(),
  logs: z.array(taskLogEntrySchema),
}) as unknown as z.ZodType<ScheduleTask>

/** 任务列表校验（自管 JSON 文件格式）。 */
export const taskListSchema = z.array(scheduleTaskSchema) as unknown as z.ZodType<ScheduleTask[]>
