/** 定时任务面板 UI 字典。 */

import type {} from '@deepseek-ai/dsh-client-ui-slots'

export const NS = 'scheduleTasks'

/** 简体中文文案。 */
export const zh = {
  'panel.trigger': '定时任务',
  'panel.triggerAria': '定时任务面板',
  'panel.title': '定时任务',
  'panel.enabledCount': '{count} 个启用',
  'panel.empty': '还没有定时任务，点击「新建任务」创建',
  'panel.loading': '读取中…',
  'panel.readFailed': '读取任务失败：{message}',
  'panel.operationFailed': '操作失败：{message}',
  'action.newTask': '新建任务',
  'action.save': '保存',
  'action.cancel': '取消',
  'action.runNow': '立即执行',
  'action.toggleOn': '启用',
  'action.toggleOff': '停用',
  'action.edit': '编辑',
  'action.delete': '删除',
  'action.confirmDelete': '删除该任务？',
  'status.enabled': '启用',
  'status.disabled': '停用',
  'status.noSchedule': '无可排程',
  'field.name': '任务名称',
  'field.namePlaceholder': '例如：每日备份数据库',
  'field.cron': 'Cron 表达式（分 时 日 月 周）',
  'field.cronPlaceholder': '例如：0 2 * * *（每天 02:00）',
  'field.cronHint': '支持 * ? a a-b */n a-b/n a,b,c；? 仅用于日/周字段',
  'field.action': '触发动作',
  'actionKind.shell': '执行 Shell 命令',
  'actionKind.shellPlaceholder': '例如：pg_dump mydb > /tmp/backup.sql',
  'actionKind.notify': '站内通知',
  'actionKind.notifyPlaceholder': '通知文案（显示在任务日志中）',
  'task.nextRun': '下次触发',
  'task.lastRun': '上次执行',
  'task.never': '从未执行',
  'task.logs': '执行日志（最近 {count} 条）',
  'task.noLogs': '暂无执行日志',
  'task.result.ok': '成功',
  'task.result.fail': '失败',
  'task.duration': '{ms}ms',
  'time.justNow': '刚刚',
} satisfies Record<string, string>

/** English copy (mirror keys). */
export const en: Record<keyof typeof zh, string> = {
  'panel.trigger': 'Scheduled Tasks',
  'panel.triggerAria': 'Scheduled tasks panel',
  'panel.title': 'Scheduled Tasks',
  'panel.enabledCount': '{count} enabled',
  'panel.empty': 'No scheduled tasks yet. Click "New Task" to create one.',
  'panel.loading': 'Loading…',
  'panel.readFailed': 'Failed to read tasks: {message}',
  'panel.operationFailed': 'Operation failed: {message}',
  'action.newTask': 'New Task',
  'action.save': 'Save',
  'action.cancel': 'Cancel',
  'action.runNow': 'Run Now',
  'action.toggleOn': 'Enable',
  'action.toggleOff': 'Disable',
  'action.edit': 'Edit',
  'action.delete': 'Delete',
  'action.confirmDelete': 'Delete this task?',
  'status.enabled': 'Enabled',
  'status.disabled': 'Disabled',
  'status.noSchedule': 'No schedule',
  'field.name': 'Task Name',
  'field.namePlaceholder': 'e.g. Daily database backup',
  'field.cron': 'Cron expression (min hour dom month dow)',
  'field.cronPlaceholder': 'e.g. 0 2 * * * (daily at 02:00)',
  'field.cronHint': 'Supports * ? a a-b */n a-b/n a,b,c; ? only in day fields',
  'field.action': 'Action',
  'actionKind.shell': 'Run Shell Command',
  'actionKind.shellPlaceholder': 'e.g. pg_dump mydb > /tmp/backup.sql',
  'actionKind.notify': 'In-app Notification',
  'actionKind.notifyPlaceholder': 'Notification text (shown in task logs)',
  'task.nextRun': 'Next Run',
  'task.lastRun': 'Last Run',
  'task.never': 'Never',
  'task.logs': 'Run Logs (last {count})',
  'task.noLogs': 'No run logs yet',
  'task.result.ok': 'OK',
  'task.result.fail': 'Failed',
  'task.duration': '{ms}ms',
  'time.justNow': 'just now',
}

/** 本插件 locale 命名空间键。 */
export type ScheduleTasksKey = keyof typeof zh

declare module '@deepseek-ai/dsh-client-ui-slots' {
  interface LocaleNamespaceMap {
    /** 定时任务面板文案。 */
    'scheduleTasks': ScheduleTasksKey
  }
}
