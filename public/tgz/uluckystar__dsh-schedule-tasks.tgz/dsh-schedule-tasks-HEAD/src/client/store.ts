/**
 * 任务列表快照源：宿主 `scheduleTasks.list()` 的最近一次读取。
 * 面板打开时轮询 refresh()（5s），动作成功后也 refresh()。
 * 读是 single-flight 的：并发轮询/连接重置不会叠读。
 */

import type { HostObservable } from '@deepseek-ai/dsh-client-ui-slots'
import type { ScheduleTask } from '../types.ts'

/** 面板读取的宿主快照。 */
export interface ScheduleTasksSnapshot {
  readonly tasks: readonly ScheduleTask[]
  /** 首次读取是否已落定（区分“尚无任务”与“还没读到”）。 */
  readonly read: boolean
  /** 最近一次读取失败。 */
  readonly error?: string
}

/** 宿主读取接缝（apply 闭包用 fetch 实现）。 */
export interface ScheduleTasksPort {
  list(): Promise<{ readonly ok: true; readonly value: readonly ScheduleTask[] } | { readonly ok: false; readonly error: { readonly code: string; readonly message: string } }>
}

/** 快照源：可订阅可观察对象 + 读取触发器。 */
export interface ScheduleTasksStore extends HostObservable<ScheduleTasksSnapshot> {
  /** 读一次；已有在途读取时忽略。 */
  refresh(): void
  /** 丢弃已读内容（连接重置后从零开始）。 */
  reset(): void
}

/**
 * 创建任务列表快照源。
 * @param port - RPC 读取接缝。
 * @param onError - 读取失败上报（生产环境 console）。
 * @returns 可观察对象与读取触发器。
 */
export function createTasksStore(
  port: ScheduleTasksPort,
  onError: (error: unknown) => void,
): ScheduleTasksStore {
  const listeners = new Set<() => void>()
  let snapshot: ScheduleTasksSnapshot = { tasks: [], read: false }
  let inFlight: Promise<void> | undefined
  let generation = 0

  const publish = (next: ScheduleTasksSnapshot): void => {
    snapshot = next
    for (const listener of [...listeners]) listener()
  }

  return {
    getSnapshot: () => snapshot,
    subscribe: (fn) => {
      listeners.add(fn)
      return () => { listeners.delete(fn) }
    },
    refresh: () => {
      if (inFlight !== undefined) return
      const issued = generation
      inFlight = port.list().then(
        (answered) => {
          if (issued !== generation) return
          if (!answered.ok) {
            onError(answered.error)
            publish({
              tasks: snapshot.tasks,
              read: snapshot.read,
              error: `${answered.error.code}: ${answered.error.message}`,
            })
            return
          }
          publish({ tasks: answered.value, read: true })
        },
        (error: unknown) => {
          if (issued !== generation) return
          onError(error)
          publish({
            tasks: snapshot.tasks,
            read: snapshot.read,
            error: error instanceof Error ? error.message : String(error),
          })
        },
      ).then(() => { if (issued === generation) inFlight = undefined })
    },
    reset: () => {
      generation += 1
      inFlight = undefined
      publish({ tasks: [], read: false })
    },
  }
}
