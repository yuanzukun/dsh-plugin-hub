/**
 * 定时任务面板：侧边栏底部按钮（wide 行 / rail 图标）+ 浮层面板。
 * 能力：任务列表（名称/cron/状态/下次触发/上次结果）、新建/编辑/启停/删除/
 * 手动触发、执行日志。打开时每 5s 轮询宿主刷新。
 */

import { useEffect, useMemo, useState } from 'react'
import type { FormEvent } from 'react'
import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots'
import type {} from '@deepseek-ai/dsh-client-ui-sidebar/client'
import { IconCheckOutline16, IconCloseOutline16, IconPlayOutline16, IconTrashOutline16, Tooltip } from '@deepseek-ai/dsh-client-ui-primitives'
import type {
  ScheduleTask, ScheduleTaskAction, ScheduleTaskInput, ScheduleTaskPatch, TaskId, TaskLogEntry,
} from '../types.ts'
import type { ScheduleTasksFace } from './face.ts'
import type { ScheduleTasksKey } from './locales.ts'
import css from './ScheduleTasksPanel.module.css'

/** 面板 props：槽运行时 + 注入面 + locale。 */
export type ScheduleTasksPanelProps =
  PropsRuntime<'sidebar.footer.action'> & InjectFace<ScheduleTasksFace> & PropsLocale<'scheduleTasks'>

/** 编辑器形态：新建或编辑既有任务。 */
interface EditorState {
  readonly mode: 'create' | 'edit'
  readonly taskId?: TaskId
  readonly name: string
  readonly cron: string
  readonly action: ScheduleTaskAction
}

/** 把时间戳格式化为本地可读文本。 */
function formatTime(value: number | undefined): string {
  if (value === undefined) return '—'
  return new Date(value).toLocaleString()
}

/** 最近一次执行结果的徽标文案。 */
function resultLabel(entry: TaskLogEntry | undefined, t: (key: ScheduleTasksKey, params?: Record<string, unknown>) => string): string {
  if (entry === undefined) return ''
  return entry.ok ? t('task.result.ok') : t('task.result.fail')
}

/** 初始化一个空编辑器。 */
function emptyEditor(): EditorState {
  return { mode: 'create', name: '', cron: '', action: { kind: 'notify', message: '' } }
}

/** 编辑器主区：名称 + cron + 动作类型与内容。 */
function TaskEditor({
  editor, t, onSave, onCancel,
}: {
  editor: EditorState
  t: (key: ScheduleTasksKey, params?: Record<string, unknown>) => string
  onSave(input: ScheduleTaskInput): void
  onCancel(): void
}) {
  const [name, setName] = useState(editor.name)
  const [cron, setCron] = useState(editor.cron)
  const [action, setAction] = useState<ScheduleTaskAction>(editor.action)

  const submit = (event: FormEvent): void => {
    event.preventDefault()
    onSave({ name, cron, action })
  }

  return (
    <form className={css.editor} onSubmit={submit} data-schedule-tasks-editor={editor.mode}>
      <label className={css.field}>
        <span>{t('field.name')}</span>
        <input
          value={name}
          onChange={(event) => { setName(event.target.value) }}
          placeholder={t('field.namePlaceholder')}
          required
        />
      </label>
      <label className={css.field}>
        <span>{t('field.cron')}</span>
        <input
          value={cron}
          onChange={(event) => { setCron(event.target.value) }}
          placeholder={t('field.cronPlaceholder')}
          required
        />
        <span className={css.fieldHint}>{t('field.cronHint')}</span>
      </label>
      <div className={css.field} role="group" aria-label={t('field.action')}>
        <span>{t('field.action')}</span>
        <div className={css.actionKindRow}>
          <button
            type="button"
            className={action.kind === 'shell' ? css.kindActive : css.kindInactive}
            onClick={() => { setAction(action.kind === 'shell' ? action : { kind: 'shell', command: '' }) }}
          >
            {t('actionKind.shell')}
          </button>
          <button
            type="button"
            className={action.kind === 'notify' ? css.kindActive : css.kindInactive}
            onClick={() => { setAction(action.kind === 'notify' ? action : { kind: 'notify', message: '' }) }}
          >
            {t('actionKind.notify')}
          </button>
        </div>
        {action.kind === 'shell' ? (
          <textarea
            value={action.command}
            onChange={(event) => { setAction({ kind: 'shell', command: event.target.value }) }}
            placeholder={t('actionKind.shellPlaceholder')}
            rows={2}
            required
          />
        ) : (
          <input
            value={action.message}
            onChange={(event) => { setAction({ kind: 'notify', message: event.target.value }) }}
            placeholder={t('actionKind.notifyPlaceholder')}
            required
          />
        )}
      </div>
      <div className={css.editorActions}>
        <button type="button" className={css.ghostButton} onClick={onCancel}>{t('action.cancel')}</button>
        <button type="submit" className={css.primaryButton}>{t('action.save')}</button>
      </div>
    </form>
  )
}

/** 单条任务的执行日志（最近 5 条）。 */
function TaskLogs({ task, t }: {
  task: ScheduleTask
  t: (key: ScheduleTasksKey, params?: Record<string, unknown>) => string
}) {
  const logs = task.logs.slice(-5)
  return (
    <details className={css.logs}>
      <summary>{t('task.logs', { count: logs.length })}</summary>
      {logs.length === 0 ? (
        <p className={css.logsEmpty}>{t('task.noLogs')}</p>
      ) : (
        <ul className={css.logsList}>
          {logs.map((entry) => (
            <li key={entry.id} className={entry.ok ? css.logOk : css.logFail}>
              <span className={css.logTime}>{formatTime(entry.at)}</span>
              <span className={css.logBadge}>{entry.ok ? t('task.result.ok') : t('task.result.fail')}</span>
              <span className={css.logDetail}>{entry.detail}</span>
              <span className={css.logDuration}>{t('task.duration', { ms: entry.durationMs })}</span>
            </li>
          ))}
        </ul>
      )}
    </details>
  )
}

/** 渲染一个任务行。 */
function TaskRow({
  task, t, pending, actionError,
  onToggle, onRunNow, onEdit, onDelete,
}: {
  task: ScheduleTask
  t: (key: ScheduleTasksKey, params?: Record<string, unknown>) => string
  pending: boolean
  actionError: string | undefined
  onToggle(): void
  onRunNow(): void
  onEdit(): void
  onDelete(): void
}) {
  const [confirming, setConfirming] = useState(false)
  const last = task.lastResult

  return (
    <li className={css.row} data-schedule-task={task.id} data-enabled={task.enabled || undefined}>
      <div className={css.rowHead}>
        <span className={css.rowName}>{task.name}</span>
        <span className={task.enabled ? css.statusOn : css.statusOff}>
          {task.enabled ? t('status.enabled') : t('status.disabled')}
        </span>
      </div>
      <div className={css.rowCron}>
        <code>{task.cron}</code>
        <span className={css.rowActionKind}>{task.action.kind === 'shell' ? 'shell' : 'notify'}</span>
      </div>
      <div className={css.rowDetail}>
        <span className={css.rowMeta}>
          {t('task.nextRun')}: {task.nextRunAt === null ? t('status.noSchedule') : formatTime(task.nextRunAt)}
        </span>
        <span className={css.rowMeta}>
          {t('task.lastRun')}: {task.lastRunAt === undefined ? t('task.never') : formatTime(task.lastRunAt)}
        </span>
        {last !== undefined && (
          <span className={last.ok ? css.resultOk : css.resultFail}>
            {resultLabel(last, t)}
          </span>
        )}
      </div>
      <div className={css.rowActions}>
        <Tooltip label={t('action.runNow')} side="bottom" delayMs={500}>
          <button type="button" className={css.actionButton} disabled={pending} onClick={onRunNow} aria-label={t('action.runNow')}>
            <IconPlayOutline16 size={14} />
          </button>
        </Tooltip>
        <Tooltip label={task.enabled ? t('action.toggleOff') : t('action.toggleOn')} side="bottom" delayMs={500}>
          <button type="button" className={css.actionButton} disabled={pending} onClick={onToggle} aria-label={task.enabled ? t('action.toggleOff') : t('action.toggleOn')}>
            {task.enabled ? <IconCloseOutline16 size={14} /> : <IconCheckOutline16 size={14} />}
          </button>
        </Tooltip>
        <Tooltip label={t('action.edit')} side="bottom" delayMs={500}>
          <button type="button" className={css.actionButton} disabled={pending} onClick={onEdit} aria-label={t('action.edit')}>
            <span className={css.editGlyph} aria-hidden>✎</span>
          </button>
        </Tooltip>
        <Tooltip label={t('action.delete')} side="bottom" delayMs={500}>
          <button
            type="button"
            className={css.actionButton}
            disabled={pending}
            onClick={() => {
              if (confirming) {
                setConfirming(false)
                onDelete()
              } else {
                setConfirming(true)
                window.setTimeout(() => { setConfirming(false) }, 3000)
              }
            }}
            aria-label={t('action.delete')}
            data-confirming={confirming || undefined}
          >
            <IconTrashOutline16 size={14} />
          </button>
        </Tooltip>
      </div>
      {confirming && <p className={css.confirmNote} role="alert">{t('action.confirmDelete')}</p>}
      {actionError !== undefined && <p className={css.rowError} role="alert">{actionError}</p>}
      <TaskLogs task={task} t={t} />
    </li>
  )
}

/** 侧边栏底部定时任务入口与浮层面板。 */
export function ScheduleTasksPanel({
  wide,
  useTasks,
  onCreate, onUpdate, onToggle, onDelete, onRunNow, onRefresh, t,
}: ScheduleTasksPanelProps) {
  const snapshot = useTasks(value => value)
  const [open, setOpen] = useState(false)
  const [editor, setEditor] = useState<EditorState | null>(null)
  const [pending, setPending] = useState(false)
  const [operationError, setOperationError] = useState<string | undefined>(undefined)

  // 打开时轮询宿主（第一版不做事件推送，5s 间隔足够调度场景）。
  useEffect(() => {
    if (!open) return undefined
    onRefresh()
    const timer = window.setInterval(() => { onRefresh() }, 5000)
    return () => { window.clearInterval(timer) }
  }, [open, onRefresh])

  const enabledCount = useMemo(
    () => snapshot.tasks.filter(task => task.enabled).length,
    [snapshot.tasks],
  )

  const runAction = async (operation: () => Promise<unknown>): Promise<boolean> => {
    if (pending) return false
    setPending(true)
    setOperationError(undefined)
    try {
      const result = await operation()
      if (result !== null && typeof result === 'object'
        && 'ok' in result && result.ok === false) {
        const error = (result as { error?: { message?: string } }).error
        setOperationError(error?.message ?? 'operation failed')
        return false
      }
      return true
    } catch (error) {
      setOperationError(error instanceof Error ? error.message : String(error))
      return false
    } finally {
      setPending(false)
      onRefresh()
    }
  }

  const saveEditor = (input: ScheduleTaskInput): void => {
    if (editor === null) return
    void runAction(() => editor.mode === 'create'
      ? onCreate(input)
      : onUpdate(editor.taskId as TaskId, {
        name: input.name,
        cron: input.cron,
        action: input.action,
      })).then((saved) => {
      if (saved) setEditor(null)
    })
  }

  const enabledTasks = snapshot.tasks.length

  return (
    <div className={wide ? css.layer : `${css.layer} ${css.rail}`}>
      {open && (
        <section className={css.panel} data-schedule-tasks-panel aria-label={t('panel.title')}>
          <header className={css.header}>
            <span className={css.title}>{t('panel.title')}</span>
            <button
              type="button"
              className={css.ghostButton}
              onClick={() => { setEditor(null); setOpen(false) }}
              aria-label={t('action.cancel')}
            >
              <IconCloseOutline16 size={14} />
            </button>
          </header>
          <div className={css.body}>
            {snapshot.error !== undefined && (
              <p className={css.readError} role="alert">
                {t('panel.readFailed', { message: snapshot.error })}
              </p>
            )}
            {!snapshot.read && snapshot.error === undefined && (
              <p className={css.note}>{t('panel.loading')}</p>
            )}
            {snapshot.read && enabledTasks === 0 && editor === null && (
              <p className={css.note}>{t('panel.empty')}</p>
            )}
            {editor !== null && (
              <TaskEditor editor={editor} t={t} onSave={saveEditor} onCancel={() => { setEditor(null) }} />
            )}
            {operationError !== undefined && (
              <p className={css.readError} role="alert">
                {t('panel.operationFailed', { message: operationError })}
              </p>
            )}
            {enabledTasks > 0 && (
              <ul className={css.rows}>
                {snapshot.tasks.map(task => (
                  <TaskRow
                    key={task.id}
                    task={task}
                    t={t}
                    pending={pending}
                    actionError={undefined}
                    onToggle={() => { void runAction(() => onToggle(task.id, !task.enabled)) }}
                    onRunNow={() => { void runAction(() => onRunNow(task.id)) }}
                    onEdit={() => { setEditor({
                      mode: 'edit', taskId: task.id, name: task.name, cron: task.cron, action: task.action,
                    }) }}
                    onDelete={() => { void runAction(() => onDelete(task.id)) }}
                  />
                ))}
              </ul>
            )}
            {editor === null && (
              <div className={css.newRow}>
                <button
                  type="button"
                  className={css.primaryButton}
                  disabled={pending}
                  onClick={() => { setEditor(emptyEditor()) }}
                >
                  {t('action.newTask')}
                </button>
              </div>
            )}
          </div>
        </section>
      )}
      <div className={css.footerButtons}>
        <button
          type="button"
          className={css.badge}
          data-schedule-tasks-badge={enabledTasks}
          data-active={open || undefined}
          aria-label={t('panel.triggerAria')}
          aria-expanded={open}
          onClick={() => { setOpen(value => !value) }}
        >
          <span className={css.clockGlyph} aria-hidden>⏱</span>
          {wide && (
            <>
              <span className={css.badgeLabel}>{t('panel.trigger')}</span>
              <span className={css.badgeCount}>{t('panel.enabledCount', { count: enabledCount })}</span>
            </>
          )}
        </button>
      </div>
    </div>
  )
}
