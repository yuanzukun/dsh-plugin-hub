/**
 * 定时任务插件浏览器入口（context-doctor 范式）：
 * - 注册 sidebar.footer.action 槽（id: schedule-tasks）→ 浮层面板
 * 数据通道：同源 fetch 调宿主 /api/schedule-tasks/*（见 api.ts），面板打开时轮询。
 */

import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client'
import type {} from '@deepseek-ai/dsh-client-locale/client'
import type {} from '@deepseek-ai/dsh-client-ui-sidebar/client'
import type { ScheduleTask, TaskId, TaskLogEntry } from '../types.ts'
import type { ApiEnvelope } from './api.ts'
import { ScheduleTasksPanel } from './ScheduleTasksPanel.tsx'
import {
  createTask, deleteTask, listTasks, runTaskNow, toggleTask, updateTask,
} from './api.ts'
import { createTasksStore, type ScheduleTasksPort } from './store.ts'
import type { ScheduleTasksFace } from './face.ts'
import { en, NS, zh } from './locales.ts'

/** 必需服务：槽系统与 locale 字典。 */
export const inject = ['slots', 'locale']

/** 把业务信封解包；失败时保持原样（面板统一读 error.message）。 */
function unwrap<R extends { readonly ok: boolean; readonly error?: { readonly message?: string } }>(
  answered: R,
): R {
  return answered
}

/**
 * 插件主体。
 * @param ctx - 浏览器根上下文。
 */
export function apply(ctx: ClientContext): void {
  ctx.effect(() => ctx.locale.register(NS, { zh, en }), 'schedule-tasks: dictionaries')

  const port: ScheduleTasksPort = {
    list: async () => listTasks(),
  }
  const tasks = createTasksStore(port, (error) => {
    console.error('[schedule-tasks] 读取任务失败:', error)
  })

  ctx.slots.inject('sidebar.footer.action', () => ctx.slots.register({
    name: 'sidebar.footer.action',
    id: 'schedule-tasks',
    order: 110,
    locale: NS,
    inject: (): ScheduleTasksFace => ({
      hooks: { tasks },
      onCreate: async (input): Promise<ApiEnvelope<ScheduleTask>> => {
        const result = unwrap(await createTask(input))
        tasks.refresh()
        return result
      },
      onUpdate: async (id, patch): Promise<ApiEnvelope<ScheduleTask>> => {
        const result = unwrap(await updateTask(id, patch))
        tasks.refresh()
        return result
      },
      onToggle: async (id, enabled): Promise<ApiEnvelope<ScheduleTask>> => {
        const result = unwrap(await toggleTask(id, enabled))
        tasks.refresh()
        return result
      },
      onDelete: async (id): Promise<ApiEnvelope<{ deleted: TaskId }>> => {
        const result = unwrap(await deleteTask(id))
        tasks.refresh()
        return result
      },
      onRunNow: async (id): Promise<ApiEnvelope<TaskLogEntry>> => {
        const result = unwrap(await runTaskNow(id))
        tasks.refresh()
        return result
      },
      onRefresh: () => { tasks.refresh() },
    }),
  }, ScheduleTasksPanel))

  tasks.refresh()
  ctx.on('connection/reset', () => {
    tasks.reset()
    tasks.refresh()
  })
}
