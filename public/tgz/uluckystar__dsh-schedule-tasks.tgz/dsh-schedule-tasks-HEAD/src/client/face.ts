/** sidebar.footer.action 槽的注入面（组件经 props 收到的数据与回调）。 */

import type {} from '@deepseek-ai/dsh-client-ui-sidebar/client'
import type { ScheduleTask, ScheduleTaskInput, ScheduleTaskPatch, TaskId, TaskLogEntry } from '../types.ts'
import type { ApiEnvelope } from './api.ts'
import type { ScheduleTasksStore } from './store.ts'

/** 面板读到的宿主快照形状（hooks 隔间的可观察对象）。 */
export interface ScheduleTasksFace {
  hooks: {
    /** 任务列表快照源（渲染器绑定为 `useTasks`）。 */
    tasks: ScheduleTasksStore
  }
  /** 新建任务；返回业务结果供面板展示失败原因。 */
  onCreate(input: ScheduleTaskInput): Promise<ApiEnvelope<ScheduleTask>>
  /** 编辑任务。 */
  onUpdate(id: TaskId, patch: ScheduleTaskPatch): Promise<ApiEnvelope<ScheduleTask>>
  /** 启停任务。 */
  onToggle(id: TaskId, enabled: boolean): Promise<ApiEnvelope<ScheduleTask>>
  /** 删除任务。 */
  onDelete(id: TaskId): Promise<ApiEnvelope<{ deleted: TaskId }>>
  /** 手动立即触发。 */
  onRunNow(id: TaskId): Promise<ApiEnvelope<TaskLogEntry>>
  /** 触发一次宿主重读。 */
  onRefresh(): void
}
