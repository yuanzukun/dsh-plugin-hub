/**
 * 定时任务浏览器端 API 客户端：同源 fetch 封装（context-doctor 范式）。
 * 每个端点返回业务信封 { ok:true, value } 或 { ok:false, error:{code,message} }；
 * 传输层失败（网络/非 JSON/HTTP 错误）合成同形失败信封。
 */
import type {
  ScheduleTask, ScheduleTaskInput, ScheduleTaskPatch, TaskId, TaskLogEntry,
} from '../types.ts'

/** 宿主 API 前缀（与宿主 routes.ts 一致）。 */
export const API_PREFIX = '/api/schedule-tasks'

/** 业务失败信封（code 放宽为字符串，涵盖传输层失败）。 */
export type ApiEnvelope<T> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: { readonly code: string; readonly message: string } }

/** 请求 JSON 并统一解信封。 */
async function request<T>(path: string, body?: unknown): Promise<ApiEnvelope<T>> {
  try {
    const response = await fetch(`${API_PREFIX}${path}`, {
      method: body === undefined ? 'GET' : 'POST',
      headers: body === undefined ? undefined : { 'content-type': 'application/json' },
      body: body === undefined ? undefined : JSON.stringify(body),
    })
    if (!response.ok) {
      return { ok: false, error: { code: 'http', message: `HTTP ${response.status}` } }
    }
    const data = (await response.json()) as ApiEnvelope<T>
    if (typeof data !== 'object' || data === null || !('ok' in data)) {
      return { ok: false, error: { code: 'bad-response', message: '宿主返回格式异常' } }
    }
    return data
  } catch (error) {
    return {
      ok: false,
      error: { code: 'offline', message: `请求失败: ${error instanceof Error ? error.message : String(error)}` },
    }
  }
}

/** 任务列表。 */
export function listTasks(): Promise<ApiEnvelope<readonly ScheduleTask[]>> {
  return request<readonly ScheduleTask[]>('/list')
}

/** 新建任务。 */
export function createTask(input: ScheduleTaskInput): Promise<ApiEnvelope<ScheduleTask>> {
  return request<ScheduleTask>('/create', input)
}

/** 编辑任务。 */
export function updateTask(id: TaskId, patch: ScheduleTaskPatch): Promise<ApiEnvelope<ScheduleTask>> {
  return request<ScheduleTask>('/update', { id, patch })
}

/** 启停任务。 */
export function toggleTask(id: TaskId, enabled: boolean): Promise<ApiEnvelope<ScheduleTask>> {
  return request<ScheduleTask>('/toggle', { id, enabled })
}

/** 删除任务。 */
export function deleteTask(id: TaskId): Promise<ApiEnvelope<{ deleted: TaskId }>> {
  return request<{ deleted: TaskId }>('/delete', { id })
}

/** 手动触发任务。 */
export function runTaskNow(id: TaskId): Promise<ApiEnvelope<TaskLogEntry>> {
  return request<TaskLogEntry>('/run-now', { id })
}
