/**
 * 定时任务宿主席位：ScheduleTasksGateway（HTTP API 通道，context-doctor 范式）。
 * - 浏览器面板经同源 JSON 接口 `/api/schedule-tasks/*` 读写（见 routes.ts）。
 * - cron 调度循环：ctx.timer.interval 每 tickIntervalMs 检查一次，命中即执行；
 *   每任务一把运行锁，杜绝重叠执行。
 * - 触发动作第一版：shell 命令（child_process exec，超时/输出截断）与
 *   站内通知（记录通知型日志）。
 * - 持久化：自管 JSON 原子写（$DSH_HOME/storages/schedule_tasks.json）。
 * - 启动策略：重启后从当前时刻重算 nextRunAt，不补跑错过的触发（避免重启风暴）；
 *   手动触发 runNow 可随时补跑。
 */

import { exec as execCallback } from 'node:child_process'
import { promisify } from 'node:util'
import { randomUUID } from 'node:crypto'
import { mkdtempSync, readFileSync, renameSync, writeFileSync, existsSync, mkdirSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { Context, Service } from '@deepseek-ai/cordis'
import s from '@deepseek-ai/schemastery'
import type {} from '@deepseek-ai/cordis-plugin-timer'
import { nextRunAt, parseCron } from './cron.ts'
import { taskListSchema } from './spec.ts'
import type {
  ScheduleTask, ScheduleTaskDeleteResult, ScheduleTaskInput, ScheduleTaskPatch,
  ScheduleTaskResult, ScheduleTaskRunResult, ScheduleTasksFailure, ScheduleTasksListResult,
  TaskId, TaskLogEntry,
} from './types.ts'

const execAsync = promisify(execCallback)

/** 部署可调项（cordis.yml config 可改，见 cordis.patch.yml）。 */
export interface ScheduleTasksConfig {
  /** 每任务保留的最近执行日志条数。 */
  readonly maxLogsPerTask: number
  /** shell 命令执行超时（毫秒）。 */
  readonly shellTimeoutMs: number
  /** 是否允许 shell 触发动作；false 时 shell 型任务创建/触发被拒绝。 */
  readonly allowShell: boolean
  /** 调度循环检查间隔（毫秒），最小 1000。 */
  readonly tickIntervalMs: number
  /** shell 命令工作目录；空串继承宿主进程 cwd。 */
  readonly workDir: string
}

/** shell 结果 detail 的单侧截断长度。 */
const RESULT_DETAIL_LIMIT = 2000

/** 业务结果构造器。 */
function ok<T>(value: T): { readonly ok: true; readonly value: T } {
  return { ok: true, value }
}

function rejected(error: ScheduleTasksFailure): { readonly ok: false; readonly error: ScheduleTasksFailure } {
  return { ok: false, error }
}

function failure(code: ScheduleTasksFailure['code'], message: string): ScheduleTasksFailure {
  return { code, message }
}

/** 定时任务服务：调度循环 + 任务 CRUD + 触发执行（HTTP API 通道）。 */
export class ScheduleTasksGateway extends Service {
  static inject = ['timer']

  /** Loader 校验的部署配置。 */
  static Config: s<ScheduleTasksConfig> = s.object({
    maxLogsPerTask: s.number().step(1).min(1).default(20),
    shellTimeoutMs: s.number().step(1).min(1000).default(60_000),
    allowShell: s.boolean().default(true),
    tickIntervalMs: s.number().step(1).min(1000).default(30_000),
    workDir: s.string().default(''),
  })

  private readonly config: ScheduleTasksConfig
  /** 持久化文件：$DSH_HOME/storages/schedule_tasks.json（自管原子写，不依赖 storage-domain 服务链）。 */
  private readonly storePath: string
  /** 内存任务表：持久化介质之上的读源，写路径串行。 */
  private readonly tasks = new Map<TaskId, ScheduleTask>()
  /** 全局读写串行链（文件写是异步的，避免交错）。 */
  private mutations: Promise<unknown> = Promise.resolve()
  /** 正在执行的任务集合（运行锁，防重叠触发）。 */
  private readonly running = new Set<TaskId>()

  /**
   * @param ctx - 宿主 Context（storageDomain + timer 服务）。
   * @param config - 部署配置。
   */
  constructor(ctx: Context, config: ScheduleTasksConfig) {
    super(ctx, 'scheduleTasks')
    this.config = config
    const base = ctx.baseUrl !== undefined ? new URL(ctx.baseUrl).pathname : ''
    const home = process.env.DSH_HOME ?? (base === '' ? '' : join(base, '..', '..', '..'))
    // DSH_HOME 优先；回退到 ctx.baseUrl 所在目录的上上级（profile 结构 ~/.dsh/profiles/<name>）
    this.storePath = home === '' ? '' : join(home, 'storages', 'schedule_tasks.json')
  }

  /** 装载持久化任务并启动调度循环。 */
  protected async [Service.init](): Promise<void> {
    // 装载：重启后从当前时刻重算 nextRunAt（不补跑错过的触发）。
    for (const task of this.loadStore()) {
      this.tasks.set(task.id, task)
    }
    await this.flushStore()

    const tickMs = Math.max(1000, this.config.tickIntervalMs)
    this.ctx.timer.interval(() => { void this.tick() }, tickMs)
  }

  /** 读取持久化文件（容错：缺失/损坏返回空表）。 */
  private loadStore(): ScheduleTask[] {
    try {
      if (!existsSync(this.storePath)) return []
      const raw = JSON.parse(readFileSync(this.storePath, 'utf8')) as unknown
      const parsed = taskListSchema.safeParse(raw)
      if (!parsed.success) return []
      return [...parsed.data]
    } catch {
      return []
    }
  }

  /** 原子写持久化文件：先写临时文件再 rename。 */
  private writeStore(): void {
    if (this.storePath === '') return
    try {
      mkdirSync(join(this.storePath, '..'), { recursive: true })
      const tmp = join(mkdtempSync(join(tmpdir(), 'dsh-st-')), 'store.json')
      writeFileSync(tmp, JSON.stringify([...this.tasks.values()], null, 2), 'utf8')
      renameSync(tmp, this.storePath)
    } catch (error) {
      this.ctx.logger.warn(`[schedule-tasks] 持久化写入失败: ${String(error)}`)
    }
  }

  /** 把一次写操作串到全局链尾并落盘。 */
  private enqueue<T>(operation: () => Promise<T>): Promise<T> {
    const result = this.mutations.then(operation, operation)
    this.mutations = result.then(() => undefined, () => undefined)
    return result
  }

  /** 落盘（在写链尾部执行）。 */
  private async flushStore(): Promise<void> {
    await this.enqueue(async () => { this.writeStore() })
  }

  /** 装载时对陈旧 cron 表达式的宽容：解析失败的任务保留原样并停用调度。 */
  private withCronError(task: ScheduleTask): ScheduleTask {
    const parsed = parseCron(task.cron)
    if (parsed.ok) return task
    return { ...task, nextRunAt: null, updatedAt: Date.now() }
  }

  /** 依当前时间重算 nextRunAt（禁用或解析失败 → null），返回新任务对象。 */
  private recomputeNextRun(task: ScheduleTask): ScheduleTask {
    if (!task.enabled) {
      return task.nextRunAt === null ? task : { ...task, nextRunAt: null, updatedAt: Date.now() }
    }
    const parsed = parseCron(task.cron)
    if (!parsed.ok) {
      return task.nextRunAt === null ? task : { ...task, nextRunAt: null, updatedAt: Date.now() }
    }
    const next = nextRunAt(parsed.schedule, new Date())
    if (next === null) {
      return task.nextRunAt === null ? task : { ...task, nextRunAt: null, updatedAt: Date.now() }
    }
    const nextRunAtValue = next.getTime()
    return task.nextRunAt === nextRunAtValue ? task : { ...task, nextRunAt: nextRunAtValue, updatedAt: Date.now() }
  }

  /** 调度 tick：触发所有到点且未在运行的任务。 */
  private async tick(): Promise<void> {
    const now = Date.now()
    for (const task of [...this.tasks.values()]) {
      if (!task.enabled) continue
      if (task.nextRunAt === null || task.nextRunAt > now) continue
      if (this.running.has(task.id)) continue
      void this.execute(task.id, task, now)
    }
  }

  /** 执行一个任务并落盘（运行锁保护；失败也记录并继续调度）。 */
  private async execute(taskId: TaskId, task: ScheduleTask, at: number): Promise<void> {
    this.running.add(taskId)
    try {
      const entry = await this.perform(task, at)
      await this.enqueue(async () => {
        const current = this.tasks.get(taskId)
        if (current === undefined) return
        const logs = [...current.logs, entry].slice(-this.config.maxLogsPerTask)
        const updated: ScheduleTask = {
          ...current,
          lastRunAt: entry.at,
          lastResult: entry,
          logs,
          updatedAt: Date.now(),
          nextRunAt: this.recomputeNextRun({ ...current, logs, lastRunAt: entry.at, lastResult: entry }).nextRunAt,
        }
        this.tasks.set(taskId, updated)
        this.writeStore()
      })
    } finally {
      this.running.delete(taskId)
    }
  }

  /** 执行动作本身，产出一次执行记录。 */
  private async perform(task: ScheduleTask, at: number): Promise<TaskLogEntry> {
    if (task.action.kind === 'notify') {
      return { id: this.newEntryId(), at, ok: true, detail: task.action.message, durationMs: 0 }
    }
    if (!this.config.allowShell) {
      return {
        id: this.newEntryId(), at, ok: false,
        detail: 'shell 动作被配置禁用（allowShell=false）', durationMs: 0,
      }
    }
    const started = Date.now()
    try {
      const { stdout, stderr } = await execAsync(task.action.command, {
        timeout: this.config.shellTimeoutMs,
        maxBuffer: 1024 * 1024,
        cwd: this.config.workDir === '' ? undefined : this.config.workDir,
        shell: '/bin/sh',
      })
      const tail = [stdout, stderr].map(text => text.trim()).filter(text => text !== '').join('\n')
      return {
        id: this.newEntryId(), at, ok: true,
        detail: truncate(tail === '' ? '(无输出)' : tail, RESULT_DETAIL_LIMIT),
        durationMs: Date.now() - started,
      }
    } catch (error) {
      const reason = error instanceof Error
        ? (error as Error & { killed?: boolean }).killed === true
          ? `命令超时（>${this.config.shellTimeoutMs}ms）`
          : error.message
        : String(error)
      return {
        id: this.newEntryId(), at, ok: false,
        detail: truncate(reason, RESULT_DETAIL_LIMIT), durationMs: Date.now() - started,
      }
    }
  }

  private newEntryId(): string {
    return randomUUID()
  }

  /** 把一次写操作串到全局链尾。 */
  private buildDraft(input: ScheduleTaskInput): { readonly ok: true; readonly draft: Omit<ScheduleTask, 'id' | 'createdAt' | 'updatedAt'> } | { readonly ok: false; readonly error: ScheduleTasksFailure } {
    const name = input.name.trim()
    if (name === '') return { ok: false, error: failure('invalid-action', '任务名称不能为空') }
    if (input.action.kind === 'shell' && !this.config.allowShell) {
      return { ok: false, error: failure('invalid-action', 'shell 动作被配置禁用（allowShell=false）') }
    }
    const parsed = parseCron(input.cron)
    if (!parsed.ok) return { ok: false, error: failure('invalid-cron', parsed.message) }
    const next = nextRunAt(parsed.schedule, new Date())
    return {
      ok: true,
      draft: {
        name, cron: input.cron.trim(), action: input.action, enabled: true,
        nextRunAt: next === null ? null : next.getTime(), logs: [],
      },
    }
  }

  /** 任务列表（按名称稳定排序），含下次触发与最近日志。 */
  async list(): Promise<ScheduleTasksListResult> {
    const tasks = [...this.tasks.values()].sort((left, right) => left.name.localeCompare(right.name))
    return ok(tasks)
  }

  /** 新建任务：校验 cron 与动作后落盘。 */
  async create(input: ScheduleTaskInput): Promise<ScheduleTaskResult> {
    const draft = this.buildDraft(input)
    if (!draft.ok) return draft
    const now = Date.now()
    const task: ScheduleTask = {
      ...draft.draft, id: this.newEntryId() as TaskId, createdAt: now, updatedAt: now,
    }
    await this.enqueue(async () => {
      this.tasks.set(task.id, task)
      this.writeStore()
    })
    return ok(task)
  }

  /** 编辑任务：cron/动作变更时重新校验并重算 nextRunAt。 */
  async update(id: TaskId, patch: ScheduleTaskPatch): Promise<ScheduleTaskResult> {
    return this.enqueue(async () => {
      const current = this.tasks.get(id)
      if (current === undefined) return rejected(failure('not-found', `任务 ${id} 不存在`))

      let next: ScheduleTask = { ...current, ...patch, updatedAt: Date.now() }
      if (patch.cron !== undefined) {
        const parsed = parseCron(patch.cron)
        if (!parsed.ok) return rejected(failure('invalid-cron', parsed.message))
        next = { ...next, cron: patch.cron.trim() }
      }
      if (patch.action !== undefined && patch.action.kind === 'shell' && !this.config.allowShell) {
        return rejected(failure('invalid-action', 'shell 动作被配置禁用（allowShell=false）'))
      }
      if (patch.name !== undefined && next.name.trim() === '') {
        return rejected(failure('invalid-action', '任务名称不能为空'))
      }
      next = this.recomputeNextRun(next)
      this.tasks.set(next.id, next)
      this.writeStore()
      return ok(next)
    })
  }

  /** 启停：enabled 翻转后重算 nextRunAt（禁用 → null）。 */
  async toggle(id: TaskId, enabled: boolean): Promise<ScheduleTaskResult> {
    return this.enqueue(async () => {
      const current = this.tasks.get(id)
      if (current === undefined) return rejected(failure('not-found', `任务 ${id} 不存在`))
      const next = this.recomputeNextRun({ ...current, enabled, updatedAt: Date.now() })
      this.tasks.set(next.id, next)
      this.writeStore()
      return ok(next)
    })
  }

  /** 删除任务。 */
  async delete(id: TaskId): Promise<ScheduleTaskDeleteResult> {
    return this.enqueue(async () => {
      if (!this.tasks.has(id)) return rejected(failure('not-found', `任务 ${id} 不存在`))
      this.tasks.delete(id)
      this.writeStore()
      return ok({ deleted: id })
    })
  }

  /** 手动立即触发（禁用任务也可触发）；返回本次执行记录并落盘。 */
  async runNow(id: TaskId): Promise<ScheduleTaskRunResult> {
    const task = this.tasks.get(id)
    if (task === undefined) return rejected(failure('not-found', `任务 ${id} 不存在`))
    if (this.running.has(id)) return rejected(failure('busy', `任务 ${id} 正在执行`))
    const entry = await this.perform(task, Date.now())
    await this.enqueue(async () => {
      const current = this.tasks.get(id)
      if (current === undefined) return
      const logs = [...current.logs, entry].slice(-this.config.maxLogsPerTask)
      const updated: ScheduleTask = {
        ...current,
        lastRunAt: entry.at,
        lastResult: entry,
        logs,
        updatedAt: Date.now(),
        nextRunAt: this.recomputeNextRun({ ...current, logs, lastRunAt: entry.at, lastResult: entry }).nextRunAt,
      }
      this.tasks.set(id, updated)
      this.writeStore()
    })
    return ok(entry)
  }
}

/** 截断长文本到上限（保留尾部，前加省略标记）。 */
function truncate(text: string, limit: number): string {
  if (text.length <= limit) return text
  return `…${text.slice(-limit)}`
}
