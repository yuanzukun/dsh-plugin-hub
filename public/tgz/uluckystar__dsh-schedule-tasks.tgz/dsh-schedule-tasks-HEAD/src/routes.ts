/**
 * 定时任务 HTTP 路由：浏览器面板经同源 JSON 接口读写（context-doctor 范式）。
 * - GET  /api/schedule-tasks/list     任务列表
 * - POST /api/schedule-tasks/create   新建（body: ScheduleTaskInput）
 * - POST /api/schedule-tasks/update   编辑（body: { id, patch }）
 * - POST /api/schedule-tasks/toggle   启停（body: { id, enabled }）
 * - POST /api/schedule-tasks/delete   删除（body: { id }）
 * - POST /api/schedule-tasks/run-now  手动触发（body: { id }）
 * 统一返回业务信封 { ok:true, value } 或 { ok:false, error:{code,message} }。
 */
import type { IncomingMessage, ServerResponse } from 'node:http'
import type { WebRoute } from '@deepseek-ai/dsh-host-webserver'
import type {
  ScheduleTask, ScheduleTaskDeleteResult, ScheduleTaskInput, ScheduleTaskPatch,
  ScheduleTaskResult, ScheduleTaskRunResult, ScheduleTasksListResult, TaskId,
} from './types.ts'
import type { ScheduleTasksGateway } from './gateway.ts'

/** 浏览器侧 API 前缀。 */
export const API_PREFIX = '/api/schedule-tasks'

/** 读请求体 JSON（限长 64KB）。 */
function readJson<T>(req: IncomingMessage): Promise<T> {
  return new Promise((resolve, reject) => {
    const chunks: Buffer[] = []
    let size = 0
    req.on('data', (chunk: Buffer) => {
      size += chunk.length
      if (size > 64 * 1024) {
        reject(new Error('请求体过大'))
        req.destroy()
        return
      }
      chunks.push(chunk)
    })
    req.on('end', () => {
      try {
        const raw = chunks.length === 0 ? '{}' : Buffer.concat(chunks).toString('utf8')
        resolve(JSON.parse(raw) as T)
      } catch (error) {
        reject(error)
      }
    })
    req.on('error', reject)
  })
}

/** 写 JSON 响应。 */
function json(res: ServerResponse, status: number, body: unknown): void {
  res.writeHead(status, { 'content-type': 'application/json; charset=utf-8' })
  res.end(JSON.stringify(body))
}

/** 统一应答：业务结果直接透传信封；异常转 400 失败信封。 */
function respond(res: ServerResponse, promise: Promise<unknown>): void {
  promise
    .then((value) => json(res, 200, value))
    .catch((error) => json(res, 400, {
      ok: false,
      error: { code: 'internal', message: String(error instanceof Error ? error.message : error) },
    }))
}

/** 构造定时任务路由表。 */
export function makeScheduleRoutes(gateway: ScheduleTasksGateway): WebRoute[] {
  return [
    {
      kind: 'exact',
      path: `${API_PREFIX}/list`,
      handler: (_req, res) => {
        void respond(res, gateway.list())
      },
    },
    {
      kind: 'exact',
      path: `${API_PREFIX}/create`,
      handler: (req, res) => {
        void readJson<ScheduleTaskInput>(req)
          .then((input) => respond(res, gateway.create(input)))
          .catch((error) => json(res, 400, {
            ok: false, error: { code: 'bad-request', message: String(error instanceof Error ? error.message : error) },
          }))
      },
    },
    {
      kind: 'exact',
      path: `${API_PREFIX}/update`,
      handler: (req, res) => {
        void readJson<{ id: TaskId; patch: ScheduleTaskPatch }>(req)
          .then((body) => respond(res, gateway.update(body.id, body.patch)))
          .catch((error) => json(res, 400, {
            ok: false, error: { code: 'bad-request', message: String(error instanceof Error ? error.message : error) },
          }))
      },
    },
    {
      kind: 'exact',
      path: `${API_PREFIX}/toggle`,
      handler: (req, res) => {
        void readJson<{ id: TaskId; enabled: boolean }>(req)
          .then((body) => respond(res, gateway.toggle(body.id, body.enabled)))
          .catch((error) => json(res, 400, {
            ok: false, error: { code: 'bad-request', message: String(error instanceof Error ? error.message : error) },
          }))
      },
    },
    {
      kind: 'exact',
      path: `${API_PREFIX}/delete`,
      handler: (req, res) => {
        void readJson<{ id: TaskId }>(req)
          .then((body) => respond(res, gateway.delete(body.id)))
          .catch((error) => json(res, 400, {
            ok: false, error: { code: 'bad-request', message: String(error instanceof Error ? error.message : error) },
          }))
      },
    },
    {
      kind: 'exact',
      path: `${API_PREFIX}/run-now`,
      handler: (req, res) => {
        void readJson<{ id: TaskId }>(req)
          .then((body) => respond(res, gateway.runNow(body.id)))
          .catch((error) => json(res, 400, {
            ok: false, error: { code: 'bad-request', message: String(error instanceof Error ? error.message : error) },
          }))
      },
    },
  ]
}

export type {
  ScheduleTask, ScheduleTaskDeleteResult, ScheduleTaskInput, ScheduleTaskPatch,
  ScheduleTaskResult, ScheduleTaskRunResult, ScheduleTasksListResult, TaskId,
}
