/**
 * 自研 cron 解析与下次触发时间计算（5 段式：分 时 日 月 周）。
 * 纯函数、零依赖，供 host 调度循环与离线验证使用。
 *
 * 支持的字段语法（每段独立）：
 * - `*`：任意值
 * - `?`：仅日/周字段可用，等价 `*`（Quartz 兼容子集）
 * - `a`：单个取值
 * - `a-b`：闭区间
 * - 斜杠步进（如 `*\/5`、`a-b\/5`）
 * - `a,b,c`：列表
 * - 周字段额外支持三字母英文名（SUN..SAT）与名字区间（如 MON-FRI）
 *
 * 第一版不支持 L / W / #（Quartz 扩展），遇到即报错。
 * 日与周字段同时受限时按标准 cron 的“或”语义匹配。
 */

/** 一段字段的解析结果：null 表示 `*`/`?`（任意），否则为允许取值集合。 */
export type CronField = ReadonlySet<number> | null

/** 一条解析成功的 cron 计划。 */
export interface CronSchedule {
  readonly minute: CronField
  readonly hour: CronField
  readonly dayOfMonth: CronField
  readonly month: CronField
  readonly dayOfWeek: CronField
}

/** 字段边界（含两端）。 */
const FIELD_BOUNDS: Readonly<Record<keyof CronSchedule, readonly [number, number]>> = {
  minute: [0, 59],
  hour: [0, 23],
  dayOfMonth: [1, 31],
  month: [1, 12],
  dayOfWeek: [0, 7], // 0 与 7 都表示周日；解析后 7 归一化为 0
}

/** 解析失败的描述（cron 表达式 + 失败原因，直接进 UI 报错）。 */
export interface CronParseFailure {
  readonly ok: false
  readonly message: string
}

/** 解析成功携带计划对象。 */
export interface CronParseSuccess {
  readonly ok: true
  readonly schedule: CronSchedule
}

export type CronParseResult = CronParseFailure | CronParseSuccess

/** 周字段的三字母英文名（SUN..SAT → 0..6），大小写不敏感。 */
const DAY_OF_WEEK_NAMES: Readonly<Record<string, number>> = {
  sun: 0, mon: 1, tue: 2, wed: 3, thu: 4, fri: 5, sat: 6,
}

/** 把周字段里的三字母名归一化为数字；未知名返回 undefined。 */
function normalizeDowToken(token: string): string | undefined {
  const name = DAY_OF_WEEK_NAMES[token.toLowerCase()]
  return name === undefined ? undefined : String(name)
}

/** 校验一段字段文本并展开为取值集合；返回 null 表示任意。 */
function parseField(
  name: keyof CronSchedule,
  raw: string,
): { readonly value: CronField } | { readonly error: string } {
  const [min, max] = FIELD_BOUNDS[name]
  const allowQuestion = name === 'dayOfMonth' || name === 'dayOfWeek'
  // 周字段支持 SUN..SAT 名（含 MON-FRI 区间形式）。
  const text = name === 'dayOfWeek' ? normalizeDowField(raw) : raw.trim()
  if (text === '') return { error: `${name} 字段为空` }
  if (text === '*') return { value: null }
  if (text === '?') {
    if (!allowQuestion) return { error: `? 只允许用于日/周字段（${name} 不允许）` }
    return { value: null }
  }

  const values = new Set<number>()
  for (const part of text.split(',')) {
    const item = part.trim()
    if (item === '') return { error: `${name} 字段含空列表项` }
    const parsed = parseListItem(name, item, min, max)
    if ('error' in parsed) return parsed
    for (const value of parsed.values) {
      if (name === 'dayOfWeek' && value === 7) values.add(0)
      else values.add(value)
    }
  }
  return { value: values }
}

/** 把周字段的英文名整体替换为数字；包含无法识别的名字时返回原样（随后按语法报错）。 */
function normalizeDowField(raw: string): string {
  const replaceToken = (token: string): string => normalizeDowToken(token) ?? token
  const replaced = raw.trim().split(/\s+/).map(replaceToken).join(' ')
  // 处理 a-b 区间内的名字，如 MON-FRI → 1-5。
  return replaced.replace(/\b([A-Za-z]{3})-([A-Za-z]{3})\b/g, (_match, low: string, high: string) => {
    const lowValue = normalizeDowToken(low)
    const highValue = normalizeDowToken(high)
    if (lowValue === undefined || highValue === undefined) return `${low}-${high}`
    const [start, end] = Number(lowValue) <= Number(highValue)
      ? [lowValue, highValue]
      : [highValue, lowValue]
    return `${start}-${end}`
  })
}

/** 解析列表中的一个条目（单值 / 区间 / 步进）。 */
function parseListItem(
  name: keyof CronSchedule,
  item: string,
  min: number,
  max: number,
): { readonly values: readonly number[] } | { readonly error: string } {
  const invalid = (): { readonly error: string } => ({
    error: `${name} 字段 "${item}" 语法不合法（支持 * 、? 、a 、a-b 、*/n 、a-b/n 、a,b,c）`,
  })

  const stepMatch = /^(.+)\/(\d+)$/.exec(item)
  const rangeText = stepMatch?.[1] ?? item
  const step = stepMatch == null ? 1 : Number(stepMatch[2])
  if (!Number.isInteger(step) || step < 1) return invalid()
  if (rangeText === '*') {
    const values: number[] = []
    for (let value = min; value <= max; value += step) values.push(value)
    return { values }
  }

  const rangeMatch = /^(\d+)-(\d+)$/.exec(rangeText)
  if (rangeMatch !== null) {
    const low = Number(rangeMatch[1])
    const high = Number(rangeMatch[2])
    if (!inRange(low, min, max) || !inRange(high, min, max)) {
      return { error: `${name} 字段 "${item}" 超出取值区间 ${min}-${max}` }
    }
    const [start, end] = low <= high ? [low, high] : [high, low]
    const values: number[] = []
    for (let value = start; value <= end; value += step) values.push(value)
    return { values }
  }

  if (/^\d+$/.test(rangeText)) {
    const value = Number(rangeText)
    if (!inRange(value, min, max)) {
      return { error: `${name} 字段 "${item}" 超出取值区间 ${min}-${max}` }
    }
    return { values: [value] }
  }

  return invalid()
}

function inRange(value: number, min: number, max: number): boolean {
  return Number.isInteger(value) && value >= min && value <= max
}

/**
 * 解析 5 段式 cron 表达式。
 * @param expression - 形如 `分 时 日 月 周` 的表达式（多余空白容忍）。
 * @returns 计划对象或明确失败。
 */
export function parseCron(expression: string): CronParseResult {
  const fields = expression.trim().split(/\s+/)
  if (fields.length !== 5) {
    return { ok: false, message: `cron 表达式需要 5 段（分 时 日 月 周），实际 ${fields.length} 段` }
  }
  const names: readonly (keyof CronSchedule)[] = ['minute', 'hour', 'dayOfMonth', 'month', 'dayOfWeek']
  const schedule: Record<string, CronField> = {}
  for (const [index, name] of names.entries()) {
    const parsed = parseField(name, fields[index] ?? '')
    if ('error' in parsed) return { ok: false, message: parsed.error }
    schedule[name] = parsed.value
  }
  return { ok: true, schedule: schedule as unknown as CronSchedule }
}

/**
 * 判断一个时间点是否命中计划（本地时间语义）。
 * @param date - 待判断时刻。
 * @param schedule - 解析后的计划。
 * @returns 是否命中。
 */
export function matchesCron(date: Date, schedule: CronSchedule): boolean {
  const minute = schedule.minute
  const hour = schedule.hour
  const month = schedule.month
  if (minute !== null && !minute.has(date.getMinutes())) return false
  if (hour !== null && !hour.has(date.getHours())) return false
  if (month !== null && !month.has(date.getMonth() + 1)) return false

  const dayOfMonth = schedule.dayOfMonth
  const dayOfWeek = schedule.dayOfWeek
  if (dayOfMonth === null && dayOfWeek === null) return true
  if (dayOfMonth === null) return (dayOfWeek as ReadonlySet<number>).has(date.getDay())
  if (dayOfWeek === null) return dayOfMonth.has(date.getDate())
  return dayOfMonth.has(date.getDate()) || dayOfWeek.has(date.getDay())
}

/** 向后扫描的窗口：8 年（覆盖 2 月 29 日这类低频率计划）。 */
const SCAN_WINDOW_MS = 8 * 366 * 24 * 60 * 60 * 1000

/**
 * 计算严格晚于 `from` 的下一次命中时刻。
 * @param schedule - 解析后的计划。
 * @param from - 起始时刻（通常为 now）。
 * @returns 下次命中时刻；扫描窗口内无命中返回 null。
 */
export function nextRunAt(schedule: CronSchedule, from: Date): Date | null {
  const candidate = new Date(from)
  candidate.setSeconds(0, 0)
  candidate.setMilliseconds(0)
  candidate.setMinutes(candidate.getMinutes() + 1)
  const limit = candidate.getTime() + SCAN_WINDOW_MS
  while (candidate.getTime() <= limit) {
    if (matchesCron(candidate, schedule)) return candidate
    candidate.setMinutes(candidate.getMinutes() + 1)
  }
  return null
}

/**
 * 解析并立即计算下次触发时间（便捷入口）。
 * @param expression - cron 表达式。
 * @param from - 起始时刻。
 * @returns 计划与下次触发时间，或失败。
 */
export function parseAndComputeNextRun(
  expression: string,
  from: Date,
): CronParseSuccess & { readonly nextRunAt: Date | null } | CronParseFailure {
  const parsed = parseCron(expression)
  if (!parsed.ok) return parsed
  return { ok: true, schedule: parsed.schedule, nextRunAt: nextRunAt(parsed.schedule, from) }
}
