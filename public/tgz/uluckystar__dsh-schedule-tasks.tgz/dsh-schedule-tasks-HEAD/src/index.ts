/**
 * 定时任务插件 host 入口（context-doctor 范式）：
 * - 挂载 ScheduleTasksGateway 服务（调度循环 + 任务 CRUD + shell/notify 执行）
 * - 有 web 服务时注册 /api/schedule-tasks/* 路由（浏览器面板数据通道），
 *   headless/CLI 环境无 webServer 时自动跳过，调度服务本身不受影响。
 */
import type { Context } from '@deepseek-ai/cordis'
// Type-only side-effect imports：拉取 timer / webServer 的 Context 增强。
import type {} from '@deepseek-ai/cordis-plugin-timer'
import type {} from '@deepseek-ai/dsh-host-webserver'
import { ScheduleTasksGateway, type ScheduleTasksConfig } from './gateway.ts'
import { makeScheduleRoutes } from './routes.ts'

export { ScheduleTasksGateway, type ScheduleTasksConfig } from './gateway.ts'
export { makeScheduleRoutes, API_PREFIX } from './routes.ts'
export { nextRunAt, parseCron } from './cron.ts'
export type {
  ScheduleTask, ScheduleTaskAction, ScheduleTaskInput, ScheduleTaskPatch,
  ScheduleTasksFailure, TaskId, TaskLogEntry,
} from './types.ts'

/** 插件名（cordis patch 里 id 与之一致）。 */
export const name = 'schedule-tasks'

/** 依赖服务。 */
export const inject = ['timer'] as const

/** 插件入口。 */
export function apply(ctx: Context, config: Partial<ScheduleTasksConfig> = {}): void {
  // 1. 调度服务
  // Service 构造即注册到插件上下文（供路由与外部读取），无需显式 provide
  const gateway = new ScheduleTasksGateway(ctx, config as ScheduleTasksConfig)

  // 2. HTTP 路由（浏览器面板数据通道；webServer 是可选能力，headless 自动跳过）
  const routes = makeScheduleRoutes(gateway)
  ctx.inject(['webServer'], (httpCtx) => {
    httpCtx.effect(() => {
      const disposers = routes.map((route) => httpCtx.webServer.register(route))
      return () => {
        for (const dispose of disposers) dispose()
      }
    }, 'schedule-tasks: routes')
  })
}
