/**
 * 定时任务插件的共享类型（host 与 client 两个 program 共用）。
 * 本文件必须零 import：它同时被 host（tsconfig.json）与 client
 * （tsconfig.client.json）编译，任何运行时导入都会污染另一面的声明合并。
 */

/** 任务 id：不透明品牌字符串（跨进程/跨介质身份）。 */
export type TaskId = string & { readonly __taskId: unique symbol }

/** shell 触发动作：在宿主机器上执行一条 shell 命令。 */
export interface ScheduleTaskActionShell {
  readonly kind: 'shell'
  readonly command: string
}

/** 站内通知触发动作：记录一条通知型执行日志（面板可见）。 */
export interface ScheduleTaskActionNotify {
  readonly kind: 'notify'
  readonly message: string
}

/** 第一版支持的触发动作联合。 */
export type ScheduleTaskAction = ScheduleTaskActionShell | ScheduleTaskActionNotify

/** 一次执行记录（结果 + 日志共用同一形状）。 */
export interface TaskLogEntry {
  readonly id: string
  /** 执行开始时间（epoch 毫秒）。 */
  readonly at: number
  /** 是否成功（shell 以退出码 0 且未超时为成功）。 */
  readonly ok: boolean
  /** 人可读结果：shell 为 stdout/stderr 摘要，notify 为通知文案。 */
  readonly detail: string
  /** 执行耗时（毫秒）。 */
  readonly durationMs: number
}

/** 一条持久化的定时任务。 */
export interface ScheduleTask {
  readonly id: TaskId
  readonly name: string
  /** 5 段式 cron 表达式：分 时 日 月 周。 */
  readonly cron: string
  readonly action: ScheduleTaskAction
  readonly enabled: boolean
  readonly createdAt: number
  readonly updatedAt: number
  /** 下次触发时间（epoch 毫秒）；禁用或表达式无法匹配时为 null。 */
  readonly nextRunAt: number | null
  readonly lastRunAt?: number
  readonly lastResult?: TaskLogEntry
  /** 最近执行的环形缓冲（按时间升序）。 */
  readonly logs: readonly TaskLogEntry[]
}

/** 新建任务的输入（cron 由宿主校验）。 */
export interface ScheduleTaskInput {
  readonly name: string
  readonly cron: string
  readonly action: ScheduleTaskAction
}

/** 编辑任务的局部补丁（至少一个字段；cron 变更时宿主重新校验并重算 nextRunAt）。 */
export interface ScheduleTaskPatch {
  readonly name?: string
  readonly cron?: string
  readonly action?: ScheduleTaskAction
  readonly enabled?: boolean
}

/** 业务失败联合：每个分支自带人可读 message。 */
export type ScheduleTasksFailure =
  | { readonly code: 'not-found'; readonly message: string }
  | { readonly code: 'invalid-cron'; readonly message: string }
  | { readonly code: 'invalid-action'; readonly message: string }
  | { readonly code: 'busy'; readonly message: string }

/** 业务结果信封：ok + value，或 ok:false + 明确失败。 */
export type ScheduleTasksResult<T> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: ScheduleTasksFailure }

export type ScheduleTasksListResult = ScheduleTasksResult<readonly ScheduleTask[]>
export type ScheduleTaskResult = ScheduleTasksResult<ScheduleTask>
export type ScheduleTaskDeleteResult = ScheduleTasksResult<{ readonly deleted: TaskId }>
export type ScheduleTaskRunResult = ScheduleTasksResult<TaskLogEntry>
