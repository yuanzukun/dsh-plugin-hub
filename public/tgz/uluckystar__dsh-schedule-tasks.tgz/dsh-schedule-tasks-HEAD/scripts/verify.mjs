#!/usr/bin/env node
/**
 * 定时任务插件离线冒烟验证（不启动任何 DSH 实例）。
 * 覆盖：cron 解析/下次触发纯函数、持久化域 schema 往返、Remote 端点与
 * 浏览器 bundle 存在性。需要先 `pnpm build`。
 *
 * 用法：node scripts/verify.mjs
 */

import { existsSync, readFileSync } from 'node:fs'
import { createRequire } from 'node:module'
import { join, dirname } from 'node:path'
import { fileURLToPath } from 'node:url'

const require = createRequire(import.meta.url)
const root = join(dirname(fileURLToPath(import.meta.url)), '..')

let failures = 0
function check(label, condition, detail = '') {
  if (condition) {
    console.log(`  PASS  ${label}`)
  } else {
    failures += 1
    console.error(`  FAIL  ${label}${detail ? ` — ${detail}` : ''}`)
  }
}

// 1/5 cron 纯函数
console.log('1/5 cron parse & next-run')
const { parseCron, matchesCron, nextRunAt, parseAndComputeNextRun } = await import('../lib/cron.js')

{
  const parsed = parseCron('*/5 * * * *')
  check('*/5 每分钟段解析成功', parsed.ok)
  if (parsed.ok) {
    const d = new Date(2026, 7, 14, 10, 0, 0)
    check('10:00 命中 */5', matchesCron(d, parsed.schedule) === true)
    check('10:02 不命中 */5', matchesCron(new Date(2026, 7, 14, 10, 2, 0), parsed.schedule) === false)
    const next = nextRunAt(parsed.schedule, new Date(2026, 7, 14, 10, 2, 30))
    check('10:02:30 后下次触发 10:05', next?.getHours() === 10 && next?.getMinutes() === 5)
  }
}

{
  const parsed = parseCron('0 2 * * *')
  check('每天 02:00 解析成功', parsed.ok)
  if (parsed.ok) {
    const next = nextRunAt(parsed.schedule, new Date(2026, 7, 14, 10, 0, 0))
    check('次日 02:00', next?.getDate() === 15 && next?.getHours() === 2 && next?.getMinutes() === 0)
  }
}

{
  const parsed = parseCron('30 8 1,15 * *')
  check('每月 1/15 日 08:30 解析成功', parsed.ok)
  if (parsed.ok) {
    const next = nextRunAt(parsed.schedule, new Date(2026, 7, 14, 10, 0, 0))
    check('下个 15 日 08:30', next?.getDate() === 15 && next?.getHours() === 8 && next?.getMinutes() === 30)
  }
}

{
  const parsed = parseCron('0 0 29 2 *')
  check('闰年 2 月 29 日解析成功', parsed.ok)
  if (parsed.ok) {
    const next = nextRunAt(parsed.schedule, new Date(2026, 7, 14, 0, 0, 0))
    check('2028-02-29 命中（闰年）', next?.getFullYear() === 2028 && next?.getMonth() === 1 && next?.getDate() === 29)
  }
}

{
  const parsed = parseCron('0 9 ? * MON-FRI')
  check('周字段 a-b 语法解析成功', parsed.ok)
  if (parsed.ok) {
    const next = nextRunAt(parsed.schedule, new Date(2026, 7, 14, 23, 0, 0)) // 2026-08-14 是周五
    check('周五后下次触发下周一 09:00', next?.getDay() === 1 && next?.getHours() === 9)
  }
}

check('非法字段（分 61）拒绝', parseCron('61 * * * *').ok === false)
check('非法字段（? 用于分钟）拒绝', parseCron('? * * * *').ok === false)
check('非法段数（4 段）拒绝', parseCron('* * * *').ok === false)
check('L 扩展拒绝', parseCron('0 0 L * *').ok === false)
check('parseAndComputeNextRun 快捷入口', parseAndComputeNextRun('0 12 * * *', new Date(2026, 7, 14, 10, 0, 0)).ok === true)

// 2/5 持久化 schema 往返
console.log('2/5 persistence schema round-trip')
const { scheduleTaskSchema, taskListSchema } = await import('../lib/spec.js')
{
  const task = {
    id: 'task-1',
    name: '备份',
    cron: '0 2 * * *',
    action: { kind: 'shell', command: 'echo hi' },
    enabled: true,
    createdAt: 1,
    updatedAt: 2,
    nextRunAt: 3,
    logs: [{ id: 'log-1', at: 1, ok: true, detail: 'ok', durationMs: 5 }],
  }
  const parsed = scheduleTaskSchema.safeParse(task)
  check('合法任务记录通过 schema', parsed.success === true, JSON.stringify(parsed.error ?? '').slice(0, 120))
  if (parsed.success) {
    check('schema 往返保留字段', parsed.data.id === 'task-1' && parsed.data.logs.length === 1)
  }
  const bad = scheduleTaskSchema.safeParse({ ...task, cron: '' })
  check('空 cron 被 schema 拒绝', bad.success === false)
  const badAction = scheduleTaskSchema.safeParse({ ...task, action: { kind: 'shell' } })
  check('缺 command 的 shell 动作被拒绝', badAction.success === false)
  const list = taskListSchema.safeParse([task, { ...task, id: 'task-2' }])
  check('任务列表 schema 通过', list.success === true)
  check('空列表 schema 通过', taskListSchema.safeParse([]).success === true)
}

// 3/5 Remote 端点与宿主契约
console.log('3/5 host gateway surface')
const { ScheduleTasksGateway } = await import('../lib/gateway.js')
{
  const remoteMethods = Object.getOwnPropertyNames(ScheduleTasksGateway.prototype)
    .filter(name => name !== 'constructor')
  check('Remote 方法齐全（list/create/update/toggle/delete/runNow）',
    ['list', 'create', 'update', 'toggle', 'delete', 'runNow'].every(name => remoteMethods.includes(name)),
    remoteMethods.join(','))
  check('static inject 声明 timer',
    Array.isArray(ScheduleTasksGateway.inject)
    && ScheduleTasksGateway.inject.includes('timer'))
  check('static Config 存在', ScheduleTasksGateway.Config !== undefined)
}

// 4/5 client bundle 形态
console.log('4/5 client bundle artifact')
const clientPath = join(root, 'lib', 'client.js')
{
  check('lib/client.js 存在', existsSync(clientPath))
  if (existsSync(clientPath)) {
    const text = readFileSync(clientPath, 'utf8')
    check('__ModuleLoader__.load 包装', text.includes('window.__ModuleLoader__.load({') && text.includes('id: "dsh-schedule-tasks"'))
    check('导出 apply/inject', text.includes('exports.apply = apply') && text.includes('exports.inject = inject'))
    check('CSS Modules 内联机制', text.includes('data-plugin-css'))
    check('react 走模块表 require（external）', /require\(["']react["']\)/.test(text))
    check('zod 已内联（无外部 require）', !/require\(["']zod["']\)/.test(text))
  }
}

// 5/5 清单一致性
console.log('5/5 manifest consistency')
{
  const pkg = JSON.parse(readFileSync(join(root, 'package.json'), 'utf8'))
  const patch = readFileSync(join(root, 'cordis.patch.yml'), 'utf8')
  check('package.json dsh.bundle.patch 指向 cordis.patch.yml',
    pkg.dsh?.bundle?.patch === './cordis.patch.yml')
  check('package.json dsh.client.platform=web',
    pkg.dsh?.client?.platform === 'web')
  check('exports["./client"] 指向 lib/client.js',
    pkg.exports?.['./client']?.default === './lib/client.js')
  check('patch 行 name 与包名一致',
    patch.includes(`name: ${pkg.name}`))
  check('types 产物存在', existsSync(join(root, 'lib', 'types', 'index.d.ts'))
    && existsSync(join(root, 'lib', 'types', 'client', 'index.d.ts')))
}

if (failures > 0) {
  console.error(`\n${failures} check(s) FAILED`)
  process.exit(1)
}
console.log('\nall checks passed')
