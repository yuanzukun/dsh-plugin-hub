en_export3),c=ug,Q=bf(e,kt.__wbindgen_export2,kt.__wbindgen_export3),E=ug;
kt.credential_storage_decrypt(l,B,c,Q,E);
var n=Mr().getInt32(l+0,!0),r=Mr().getInt32(l+4,!0),o=Mr().getInt32(l+8,!0),s=Mr().getInt32(l+12,!0),a=n,g=r;
if(s)throw a=0,g=0,kS(o);
return t=a,i=g,Ww(a,g)
}finally{
  kt.__wbindgen_add_to_stack_pointer(16),kt.__wbindgen_export4(t,i,1)
}
}function bfs(A,e){
  let t,i;
  try{
    let l=kt.__wbindgen_add_to_stack_pointer(-16),B=bf(A,kt.__wbindgen_export2,kt.__wbindgen_export3),c=ug,Q=bf(e,kt.__wbindgen_export2,kt.__wbindgen_export3),E=ug;
    kt.credential_storage_encrypt(l,B,c,Q,E);
    var n=Mr().getInt32(l+0,!0),r=Mr().getInt32(l+4,!0),o=Mr().getInt32(l+8,!0),s=Mr().getInt32(l+12,!0),a=n,g=r;
    if(s)throw a=0,g=0,kS(o);
    return t=a,i=g,Ww(a,g)
  }finally{
    kt.__wbindgen_add_to_stack_pointer(16),kt.__wbindgen_export4(t,i,1)
  }
}function Ffs(A){
  let e,t;
  try{
    let g=kt.__wbindgen_add_to_stack_pointer(-16),l=bf(A,kt.__wbindgen_export2,kt.__wbindgen_export3),B=ug;
    kt.decrypt_server_response(g,l,B);
    var i=Mr().getInt32(g+0,!0),n=Mr().getInt32(g+4,!0),r=Mr().getInt32(g+8,!0),o=Mr().getInt32(g+12,!0),s=i,a=n;
    if(o)throw s=0,a=0,kS(r);
    return e=s,t=a,Ww(s,a)
  }finally{
    kt.__wbindgen_add_to_stack_pointer(16),kt.__wbindgen_export4(e,t,1)
  }
}function Ufs(A){
  let e,t;
  try{
    let g=kt.__wbindgen_add_to_stack_pointer(-16),l=bf(A,kt.__wbindgen_export2,kt.__wbindgen_export3),B=ug;
    kt.generate_runtime_auth_fields(g,l,B);
    var i=Mr().getInt32(g+0,!0),n=Mr().getInt32(g+4,!0),r=Mr().getInt32(g+8,!0),o=Mr().getInt32(g+12,!0),s=i,a=n;
    if(o)throw s=0,a=0,kS(r);
    return e=s,t=a,Ww(s,a)
  }finally{
    kt.__wbindgen_add_to_stack_pointer(16),kt.__wbindgen_export4(e,t,1)
  }
}function Nfs(){
  let A,e;
  try{
    let n=kt.__wbindgen_add_to_stack_pointer(-16);
    kt.get_httpdns_account_id(n);
    var t=Mr().getInt32(n+0,!0),i=Mr().getInt32(n+4,!0);
    return A=t,e=i,Ww(t,i)
  }finally{
    kt.__wbindgen_add_to_stack_pointer(16),kt.__wbindgen_export4(A,e,1)
  }
}function Lfs(){
  let A,e;
  try{
    let n=kt.__wbindgen_add_to_stack_pointer(-16);
    kt.get_httpdns_config(n);
    var t=Mr().getInt32(n+0,!0),i=Mr().getInt32(n+4,!0);
    return A=t,e=i,Ww(t,i)
  }finally{
    kt.__wbindgen_add_to_stack_pointer(16),kt.__wbindgen_export4(A,e,1)
  }
}function Hfs(){
  let A,e;
  try{
    let n=kt.__wbindgen_add_to_stack_pointer(-16);
    kt.get_httpdns_secret_key(n);
    var t=Mr().getInt32(n+0,!0),i=Mr().getInt32(n+4,!0);
    return A=t,e=i,Ww(t,i)
  }finally{
    kt.__wbindgen_add_to_stack_pointer(16),kt.__wbindgen_export4(A,e,1)
  }
}function Ofs(){
  let A,e;
  try{
    let n=kt.__wbindgen_add_to_stack_pointer(-16);
    kt.get_profile_key_fingerprint(n);
    var t=Mr().getInt32(n+0,!0),i=Mr().getInt32(n+4,!0);
    return A=t,e=i,Ww(t,i)
  }finally{
    kt.__wbindgen_add_to_stack_pointer(16),kt.__wbindgen_export4(A,e,1)
  }
}function Jfs(A,e){
  let t,i;
  try{
    let l=kt.__wbindgen_add_to_stack_pointer(-16),B=bf(A,kt.__wbindgen_export2,kt.__wbindgen_export3),c=ug,Q=bf(e,kt.__wbindgen_export2,kt.__wbindgen_export3),E=ug;
    kt.model_cache_decrypt(l,B,c,Q,E);
    var n=Mr().getInt32(l+0,!0),r=Mr().getInt32(l+4,!0),o=Mr().getInt32(l+8,!0),s=Mr().getInt32(l+12,!0),a=n,g=r;
    if(s)throw a=0,g=0,kS(o);
    return t=a,i=g,Ww(a,g)
  }finally{
    kt.__wbindgen_add_to_stack_pointer(16),kt.__wbindgen_export4(t,i,1)
  }
}function Gfs(A,e){
  let t,i;
  try{
    let l=kt.__wbindgen_add_to_stack_pointer(-16),B=bf(A,kt.__wbindgen_export2,kt.__wbindgen_export3),c=ug,Q=bf(e,kt.__wbindgen_export2,kt.__wbindgen_export3),E=ug;
    kt.model_cache_encrypt(l,B,c,Q,E);
    var n=Mr().getInt32(l+0,!0),r=Mr().getInt32(l+4,!0),o=Mr().getInt32(l+8,!0),s=Mr().getInt32(l+12,!0),a=n,g=r;
    if(s)throw a=0,g=0,kS(o);
    return t=a,i=g,Ww(a,g)
  }finally{
    kt.__wbindgen_add_to_stack_pointer(16),kt.__wbindgen_export4(t,i,1)
  }
}function Yfs(A){
  try{
    let r=kt.__wbindgen_add_to_stack_pointer(-16),o=QZn(A,kt.__wbindgen_export2),s=ug;
    kt.profile_encrypt(r,o,s);
    var e=Mr().getInt32(r+0,!0),t=Mr().getInt32(r+4,!0),i=Mr().getInt32(r+8,!0);
    if(Mr().getInt32(r+12,!0))throw kS(i);
    var n=DSA(e,t).slice();
    return kt.__wbindgen_export4(e,1*t,1),n
  }finally{
    kt.__wbindgen_add_to_stack_pointer(16)
  }
}function hZn(){
  return{
    __proto__:null,"./qoder_auth_wasm_bg.js":{
      __proto__:null,__wbg_Error_2e59b1b37a9a34c3:function(A,e){
        return ZB(Error(Ww(A,e)))
      },__wbg___wbindgen_is_function_49868bde5eb1e745:function(A){
        return"function"==typeof om(A)
      },__wbg___wbindgen_is_object_40c5a80572e8f9d3:function(A){
        let e=om(A);
        return"object"==typeof e&&null!==e
      },__wbg___wbindgen_is_string_b29b5c5a8065ba1a:function(A){
        return"string"==typeof om(A)
      },__wbg___wbindgen_is_undefined_c0cca72b82b86f4d:function(A){
        return void 0===om(A)
      },__wbg___wbindgen_throw_81fc77679af83bc6:function(A,e){
        throw new Error(Ww(A,e))
      },__wbg_call_d578befcc3145dee:function(){
        return b6A(function(A,e,t){
          return ZB(om(A).call(om(e),om(t)))
        },arguments)
      },__wbg_crypto_38df2bab126b63dc:function(A){
        return ZB(om(A).crypto)
      },__wbg_getRandomValues_c44a50d8cfdaebeb:function(){
        return b6A(function(A,e){
          om(A).getRandomValues(om(e))
        },arguments)
      },__wbg_getRandomValues_d49329ff89a07af1:function(){
        return b6A(function(A,e){
          globalThis.crypto.getRandomValues(DSA(A,e))
        },arguments)
      },__wbg_length_0c32cb8543c8e4c8:function(A){
        return om(A).length
      },__wbg_msCrypto_bd5a034af96bcba6:function(A){
        return ZB(om(A).msCrypto)
      },__wbg_new_99cabae501c0a8a0:function(){
        return ZB(new Map)
      },__wbg_new_with_length_9cedd08484b73942:function(A){
        return ZB(new Uint8Array(A>>>0))
      },__wbg_node_84ea875411254db1:function(A){
        return ZB(om(A).node)
      },__wbg_now_88621c9c9a4f3ffc:function(){
        return Date.now()
      },__wbg_process_44c7a14e11e9f69e:function(A){
        return ZB(om(A).process)
      },__wbg_prototypesetcall_3e05eb9545565046:function(A,e,t){
        Uint8Array.prototype.set.call(DSA(A,e),om(t))
      },__wbg_randomFillSync_6c25eac9869eb53c:function(){
        return b6A(function(A,e){
          om(A).randomFillSync(kS(e))
        },arguments)
      },__wbg_require_b4edbdcf3e2a1ef0:function(){
        return b6A(function(){
          return ZB(module.require)
        },arguments)
      },__wbg_set_08463b1df38a7e29:function(A,e,t){
        return ZB(om(A).set(om(e),om(t)))
      },__wbg_static_accessor_GLOBAL_THIS_a1248013d790bf5f:function(){
        let A=typeof globalThis>"u"?null:globalThis;
        return Wq(A)?0:ZB(A)
      },__wbg_static_accessor_GLOBAL_f2e0f995a21329ff:function(){
        let A=typeof global>"u"?null:global;
        return Wq(A)?0:ZB(A)
      },__wbg_static_accessor_SELF_24f78b6d23f286ea:function(){
        let A=typeof self>"u"?null:self;
        return Wq(A)?0:ZB(A)
      },__wbg_static_accessor_WINDOW_59fd959c540fe405:function(){
        let A=typeof window>"u"?null:window;
        return Wq(A)?0:ZB(A)
      },__wbg_subarray_0f98d3fb634508ad:function(A,e,t){
        return ZB(om(A).subarray(e>>>0,t>>>0))
      },__wbg_versions_276b2795b1c6a219:function(A){
        return ZB(om(A).versions)
      },__wbindgen_cast_0000000000000001:function(A,e){
        return ZB(DSA(A,e))
      },__wbindgen_cast_0000000000000002:function(A,e){
        return ZB(Ww(A,e))
      },__wbindgen_object_clone_ref:function(A){
        return ZB(om(A))
      },__wbindgen_object_drop_ref:function(A){
        kS(A)
      }
    }
  }
}function ZB(A){
  U6A===Zq.length&&Zq.push(Zq.length+1);
  let e=U6A;
  return U6A=Zq[e],Zq[e]=A,e
}function jfs(A){
  A<1028||(Zq[A]=U6A,U6A=A)
}function DSA(A,e){
  return A>>>=0,SSA().subarray(A/1,A/1+e)
}function Mr(){
  return(null===LlA||!0===LlA.buffer.detached||void 0===LlA.buffer.detached&&LlA.buffer!==kt.memory.buffer)&&(LlA=new DataView(kt.memory.buffer)),LlA
}function Ww(A,e){
  return qfs(A>>>=0,e)
}function SSA(){
  return(null===F6A||0===F6A.byteLength)&&(F6A=new Uint8Array(kt.memory.buffer)),F6A
}function om(A){
  return Zq[A]
}function b6A(A,e){
  try{
    return A.apply(this,e)
  }catch(A){
    kt.__wbindgen_export(ZB(A))
  }
}function Wq(A){
  return null==A
}function QZn(A,e){
  let t=e(1*A.length,1)>>>0;
  return SSA().set(A,t/1),ug=A.length,t
}function bf(A,e,t){
  if(void 0===t){
    let t=N6A.encode(A),i=e(t.length,1)>>>0;
    return SSA().subarray(i,i+t.length).set(t),ug=t.length,i
  }let i=A.length,n=e(i,1)>>>0,r=SSA(),o=0;
  for(;
  o<i;
  o++){
    let e=A.charCodeAt(o);
    if(e>127)break;
    r[n+o]=e
  }if(o!==i){
    0!==o&&(A=A.slice(o)),n=t(n,i,i=o+3*A.length,1)>>>0;
    let e=SSA().subarray(n+o,n+i);
    o+=N6A.encodeInto(A,e).written,n=t(n,i,o,1)>>>0
  }return ug=o,n
}function kS(A){
  let e=om(A);
  return jfs(A),e
}function qfs(A,e){
  return(KQt+=e)>=Vfs&&((oCe=new TextDecoder("utf-8",{
    ignoreBOM:!0,fatal:!0
  })).decode(),KQt=e),oCe.decode(SSA().subarray(A,A+e))
}function CZn(A,e){
  return kt=A.exports,Kfs=e,LlA=null,F6A=null,kt
}async function Zfs(A,e){
  if("function"==typeof Response&&A instanceof Response){
    if("function"==typeof WebAssembly.instantiateStreaming)try{
      return await WebAssembly.instantiateStreaming(A,e)
    }catch(e){
      if(!A.ok||!function(A){
        switch(A){
          case"basic":case"cors":case"default":return!0
        }return!1
      }(A.type)||"application/wasm"===A.headers.get("Content-Type"))throw e;
      console.warn(_$d("JDIIDjMfAQwBVR8sagwDHwYNHB0FVgcwFxEfCRMBGwcLV1MzJQwBCRZMEAwPVgYmIUUUAwceUhoJRQUwNkUJAxcfUgcDQ1MmIRcbCVI7ExoBFwQ8MA1NDBMcAgUFVBIhLQoDQwUNAQQMFz4cCSBNGAscF0dMcRI5KAwDC1IOEwoHFwc6ZAU6CRAtARoJWhE5PUsEAgEYEwcYXhIhIQVNGxoFEQFMXgB1NwkCGxceXEkjRRoyLQsMAFIJABsDRUlf"),e)
    }let t=await A.arrayBuffer();
    return await WebAssembly.instantiate(t,e)
  }{
    let t=await WebAssembly.instantiate(A,e);
    return t instanceof WebAssembly.Instance?{
      instance:t,module:A
    }:t
  }
}function Wfs(A){
  if(void 0!==kt)return kt;
  void 0!==A&&(Object.getPrototypeOf(A)===Object.prototype?({
    module:A
  }=A):console.warn(_$d("MRYEAhVMFgwcRRY2JREICFIcExsNWhYhIRceTBQDAEkMXh08MDYUAhFEWwlXFwM0NxZNDVIfGwcLWxZ1KwcHCREYUgACRAcwJQE=")));
  let e=hZn();
  return A instanceof WebAssembly.Module||(A=new WebAssembly.Module(A)),CZn(new WebAssembly.Instance(A,e),A)
}async function Xfs(A){
  if(void 0!==kt)return kt;
  void 0!==A&&(Object.getPrototypeOf(A)===Object.prototype?({
    module_or_path:A
  }=A):console.warn(_$d("MRYEAhVMFgwcRRY2JREICFIcExsNWhYhIRceTBQDAEkYXxZ1LQsEGBsNHgAWVgc8KwtNCgcCER0FWB1uZBUMHwFME0kfXh0yKABNAxAGFwoYFxo7NxEIDRY="))),void 0===A&&(A=new URL("qoder_auth_wasm_bg.wasm",import.meta.url));
  let e=hZn();
  ("string"==typeof A||"function"==typeof Request&&A instanceof Request||"function"==typeof URL&&A instanceof URL)&&(A=fetch(A));
  let{
    instance:t,module:i
  }=await Zfs(await A,e);
  return CZn(t,i)
}bn(wZn,{
  ProfileEncryptor:()=>L6A,QoderContext:()=>H6A,RequestResult:()=>HlA,build_httpdns_url:()=>vfs,credential_storage_decrypt:()=>xfs,credential_storage_encrypt:()=>bfs,decrypt_server_response:()=>Ffs,default:()=>Xfs,generate_runtime_auth_fields:()=>Ufs,get_httpdns_account_id:()=>Nfs,get_httpdns_config:()=>Lfs,get_httpdns_secret_key:()=>Hfs,get_profile_key_fingerprint:()=>Ofs,initSync:()=>Wfs,model_cache_decrypt:()=>Jfs,model_cache_encrypt:()=>Gfs,profile_encrypt:()=>Yfs
});
var L6A,H6A,HlA,mZn,IZn,BZn,LlA,F6A,Zq,U6A,oCe,Vfs,KQt,N6A,ug,Kfs,kt,DZn=D(()=>{
  L6A=class{
    __destroy_into_raw(){
      let A=this.__wbg_ptr;
      return this.__wbg_ptr=0,mZn.unregister(this),A
    }free(){
      let A=this.__destroy_into_raw();
      kt.__wbg_profileencryptor_free(A,0)
    }encryptChunk(A,e){
      try{
        let o=kt.__wbindgen_add_to_stack_pointer(-16),s=QZn(A,kt.__wbindgen_export2),a=ug;
        kt.profileencryptor_encryptChunk(o,this.__wbg_ptr,s,a,e);
        var t=Mr().getInt32(o+0,!0),i=Mr().getInt32(o+4,!0),n=Mr().getInt32(o+8,!0);
        if(Mr().getInt32(o+12,!0))throw kS(n);
        var r=DSA(t,i).slice();
        return kt.__wbindgen_export4(t,1*i,1),r
      }finally{
        kt.__wbindgen_add_to_stack_pointer(16)
      }
    }header(){
      try{
        let i=kt.__wbindgen_add_to_stack_pointer(-16);
        kt.profileencryptor_header(i,this.__wbg_ptr);
        var A=Mr().getInt32(i+0,!0),e=Mr().getInt32(i+4,!0),t=DSA(A,e).slice();
        return kt.__wbindgen_export4(A,1*e,1),t
      }finally{
        kt.__wbindgen_add_to_stack_pointer(16)
      }
    }constructor(A){
      try{
        let i=kt.__wbindgen_add_to_stack_pointer(-16);
        kt.profileencryptor_new(i,A);
        var e=Mr().getInt32(i+0,!0),t=Mr().getInt32(i+4,!0);
        if(Mr().getInt32(i+8,!0))throw kS(t);
        return this.__wbg_ptr=e>>>0,mZn.register(this,this.__wbg_ptr,this),this
      }finally{
        kt.__wbindgen_add_to_stack_pointer(16)
      }
    }
  },Symbol.dispose&&(L6A.prototype[Symbol.dispose]=L6A.prototype.free),H6A=class{
    __destroy_into_raw(){
      let A=this.__wbg_ptr;
      return this.__wbg_ptr=0,IZn.unregister(this),A
    }free(){
      let A=this.__destroy_into_raw();
      kt.__wbg_qodercontext_free(A,0)
    }get_external_providers_access(){
      let A,e;
      try{
        let n=kt.__wbindgen_add_to_stack_pointer(-16);
        kt.qodercontext_get_external_providers_access(n,this.__wbg_ptr);
        var t=Mr().getInt32(n+0,!0),i=Mr().getInt32(n+4,!0);
        return A=t,e=i,Ww(t,i)
      }finally{
        kt.__wbindgen_add_to_stack_pointer(16),kt.__wbindgen_export4(A,e,1)
      }
    }constructor(A,e,t,i){
      try{
        let a=kt.__wbindgen_add_to_stack_pointer(-16),g=bf(A,kt.__wbindgen_export2,kt.__wbindgen_export3),l=ug,B=bf(e,kt.__wbindgen_export2,kt.__wbindgen_export3),c=ug,Q=bf(t,kt.__wbindgen_export2,kt.__wbindgen_export3),E=ug;
        var n=Wq(i)?0:bf(i,kt.__wbindgen_export2,kt.__wbindgen_export3),r=ug;
        kt.qodercontext_new(a,g,l,B,c,Q,E,n,r);
        var o=Mr().getInt32(a+0,!0),s=Mr().getInt32(a+4,!0);
        if(Mr().getInt32(a+8,!0))throw kS(s);
        return this.__wbg_ptr=o>>>0,IZn.register(this,this.__wbg_ptr,this),this
      }finally{
        kt.__wbindgen_add_to_stack_pointer(16)
      }
    }prepareInferRequest(A,e,t,i){
      try{
        let l=kt.__wbindgen_add_to_stack_pointer(-16),B=bf(A,kt.__wbindgen_export2,kt.__wbindgen_export3),c=ug,Q=bf(e,kt.__wbindgen_export2,kt.__wbindgen_export3),E=ug;
        var n=Wq(t)?0:bf(t,kt.__wbindgen_export2,kt.__wbindgen_export3),r=ug,o=Wq(i)?0:bf(i,kt.__wbindgen_export2,kt.__wbindgen_export3),s=ug;
        kt.qodercontext_prepareInferRequest(l,this.__wbg_ptr,B,c,Q,E,n,r,o,s);
        var a=Mr().getInt32(l+0,!0),g=Mr().getInt32(l+4,!0);
        if(Mr().getInt32(l+8,!0))throw kS(g);
        return HlA.__wrap(a)
      }finally{
        kt.__wbindgen_add_to_stack_pointer(16)
      }
    }prepareRequest(A,e,t,i,n,r){
      try{
        let c=kt.__wbindgen_add_to_stack_pointer(-16),Q=bf(A,kt.__wbindgen_export2,kt.__wbindgen_export3),E=ug,I=bf(e,kt.__wbindgen_export2,kt.__wbindgen_export3),u=ug,d=bf(t,kt.__wbindgen_export2,kt.__wbindgen_export3),C=ug,w=bf(i,kt.__wbindgen_export2,kt.__wbindgen_export3),h=ug;
        var o=Wq(n)?0:bf(n,kt.__wbindgen_export2,kt.__wbindgen_export3),s=ug,a=Wq(r)?0:bf(r,kt.__wbindgen_export2,kt.__wbindgen_export3),g=ug;
        kt.qodercontext_prepareRequest(c,this.__wbg_ptr,Q,E,I,u,d,C,w,h,o,s,a,g);
        var l=Mr().getInt32(c+0,!0),B=Mr().getInt32(c+4,!0);
        if(Mr().getInt32(c+8,!0))throw kS(B);
        return HlA.__wrap(l)
      }finally{
        kt.__wbindgen_add_to_stack_pointer(16)
      }
    }refreshAuthFields(A){
      try{
        let t=kt.__wbindgen_add_to_stack_pointer(-16),i=bf(A,kt.__wbindgen_export2,kt.__wbindgen_export3),n=ug;
        kt.qodercontext_refreshAuthFields(t,this.__wbg_ptr,i,n);
        var e=Mr().getInt32(t+0,!0);
        if(Mr().getInt32(t+4,!0))throw kS(e)
      }finally{
        kt.__wbindgen_add_to_stack_pointer(16)
      }
    }
  },Symbol.dispose&&(H6A.prototype[Symbol.dispose]=H6A.prototype.free),HlA=class A{
    static __wrap(e){
      e>>>=0;
      let t=Object.create(A.prototype);
      return t.__wbg_ptr=e,BZn.register(t,t.__wbg_ptr,t),t
    }__destroy_into_raw(){
      let A=this.__wbg_ptr;
      return this.__wbg_ptr=0,BZn.unregister(this),A
    }free(){
      let A=this.__destroy_into_raw();
      kt.__wbg_requestresult_free(A,0)
    }get body(){
      try{
        let t=kt.__wbindgen_add_to_stack_pointer(-16);
        kt.requestresult_body(t,this.__wbg_ptr);
        var A=Mr().getInt32(t+0,!0),e=Mr().getInt32(t+4,!0);
        let i;
        return 0!==A&&(i=Ww(A,e).slice(),kt.__wbindgen_export4(A,1*e,1)),i
      }finally{
        kt.__wbindgen_add_to_stack_pointer(16)
      }
    }get headerCount(){
      return kt.requestresult_headerCount(this.__wbg_ptr)>>>0
    }get headers(){
      return kS(kt.requestresult_headers(this.__wbg_ptr))
    }get url(){
      let A,e;
      try{
        let n=kt.__wbindgen_add_to_stack_pointer(-16);
        kt.requestresult_url(n,this.__wbg_ptr);
        var t=Mr().getInt32(n+0,!0),i=Mr().getInt32(n+4,!0);
        return A=t,e=i,Ww(t,i)
      }finally{
        kt.__wbindgen_add_to_stack_pointer(16),kt.__wbindgen_export4(A,e,1)
      }
    }
  },Symbol.dispose&&(HlA.prototype[Symbol.dispose]=HlA.prototype.free),mZn=typeof FinalizationRegistry>"u"?{
    register:()=>{
      
    },unregister:()=>{
      
    }
  }:new FinalizationRegistry(A=>kt.__wbg_profileencryptor_free(A>>>0,1)),IZn=typeof FinalizationRegistry>"u"?{
    register:()=>{
      
    },unregister:()=>{
      
    }
  }:new FinalizationRegistry(A=>kt.__wbg_qodercontext_free(A>>>0,1)),BZn=typeof FinalizationRegistry>"u"?{
    register:()=>{
      
    },unregister:()=>{
      
    }
  }:new FinalizationRegistry(A=>kt.__wbg_requestresult_free(A>>>0,1)),LlA=null,F6A=null,(Zq=new Array(1024).fill(void 0)).push(void 0,null,!0,!1),U6A=Zq.length,(oCe=new TextDecoder("utf-8",{
    ignoreBOM:!0,fatal:!0
  })).decode(),Vfs=2146435072,KQt=0,"encodeInto"in(N6A=new TextEncoder)||(N6A.encodeInto=function(A,e){
    let t=N6A.encode(A);
    return e.set(t),{
      read:A.length,written:t.length
    }
  }),ug=0
});
import{
  fileURLToPath as zfs,pathToFileURL as _fs
}from"node:url";
import{
  resolve as SZn,dirname as $fs,sep as ZQt
}from"node:path";
import{
  readFile as Aps
}from"node:fs/promises";
async function eps(){
  if(PZn)return sCe;
  PZn=!0;
  try{
    sCe=(await Promise.resolve().then(()=>(EZn(),pZn))).default
  }catch{
    sCe=void 0
  }return sCe
}async function RO(){
  return OlA||O6A||(O6A=(async()=>{
    try{
      let A=await eps();
      if(A){
        let e=await Promise.resolve().then(()=>(DZn(),wZn)),t=Buffer.from(A,"base64"),i=e.default;
        await i({
          module_or_path:t
        }),OlA=e
      }else{
        let A=$fs(zfs(import.meta.url)).replace(`${ZQt}dist${ZQt}`,`${ZQt}`),e=SZn(A,"pkg","qoder_auth_wasm.js"),t=await import(_fs(e).href),i=SZn(A,"pkg","qoder_auth_wasm_bg.wasm"),n=await Aps(i),r=t.default;
        await r({
          module_or_path:n
        }),OlA=t
      }return OlA
    }catch(A){
      throw O6A=null,A
    }
  })(),O6A)
}function fC(){
  if(!OlA)throw new Error(_$d("EyQ+IVIBHQ0ZWxZ1KgoZTBsCGx0FVh88PgAJQlIvEwUAFxo7LRE6DQEBWkBMURonNxFNDRwIUggbVhohZAwZQg=="));
  return OlA
}function JlA(A,e,t){
  let i=fC();
  if(kF)try{
    kF.free()
  }catch{
    
  }$z={
    machineId:A,cosyVersion:e,userInfoJson:t
  };
  let n=JSON.stringify(uE());
  return kF=new i.QoderContext(A,e,t,n)
}function tps(A){
  return 0!==A.__wbg_ptr
}function yZn(){
  if(!$z)throw new Error(_$d("FQoJCQAvHQcYUgshZDIsPz9MAgYFWQcwNkUEAgQNHgAIVgcwIEUMAhZMEQgCWRwhZAQYGB1BAAwPWAUwNkVFAh1MEQgPXxYxZBUMHhMBAUBC"));
  let{
    machineId:A,cosyVersion:e,userInfoJson:t
  }=$z;
  return kF=null,JlA(A,e,t)
}function z8(){
  if(!kF)throw new Error(_$d("FQoJCQAvHQcYUgshZAsCGFIPAAwNQxYxakUuDR4AUgoeUhIhISYCAgYJCh1EHlM0IhEIHlIAHQ4FWV0="));
  return tps(kF)?kF:yZn()
}function Qp(){
  return null!==kF
}function aCe(A){
  $z&&($z={
    ...$z,userInfoJson:A
  })
}function _8(){
  if(kF){
    try{
      kF.free()
    }catch{
      
    }kF=null
  }$z=null
}function Mc(A){
  try{
    return A(z8())
  }catch(e){
    if(e instanceof TypeError&&$z)return A(yZn());
    throw e
  }
}var sCe,PZn,OlA,O6A,kF,$z,GlA=D(()=>{
  cn(),PZn=!1,OlA=null,O6A=null,kF=null,$z=null
});
function YlA(A){
  try{
    return fC().decrypt_server_response(A)
  }catch{
    return A
  }
}async function TS(A){
  let e=await A.text();
  return JSON.parse(YlA(e))
}var WQt=D(()=>{
  GlA()
});
function vc(A){
  if(!A||"function"!=typeof A.forEach)throw new Error(_$d("EyQ+IVIPHQcYUgshZBcIGAceHAwIFxo7MgQBBRZMGgwNUxYnN0VFHB0fAQAOWwp1JwofHgccBgwIFxwnZAMfCRcIW0dMdBw7MAAVGFINBx0DGgEwJwobCQAVUgQNTlM9JRMITBQNGwUJU10="));
  let e={
    
  };
  return A.forEach((A,t)=>{
    e[t]=A
  }),e
}var J6A=D(()=>{
  
});
function A_(A){
  let e=Mc(e=>e.prepareRequest(A.endpoint,A.path,A.method,"auth",A.body,A.headers?JSON.stringify(A.headers):void 0));
  try{
    return{
      url:e.url,headers:vc(e.headers),...void 0!==e.body?{
        body:e.body
      }:{
        
      }
    }
  }finally{
    e.free()
  }
}var XQt=D(()=>{
  GlA(),J6A()
}),PSA={
  
};
bn(PSA,{
  createContext:()=>JlA,decryptServerResponse:()=>YlA,destroyContext:()=>_8,getContext:()=>z8,getWasm:()=>fC,hasContext:()=>Qp,headersMapToRecord:()=>vc,initWasm:()=>RO,parseDecryptedJson:()=>TS,prepareWasmAuthenticatedRequest:()=>A_,updateCachedUserInfo:()=>aCe,withWasmContextRetry:()=>Mc
});
var Ff=D(()=>{
  GlA(),WQt(),J6A(),XQt()
});
async function kZn(){
  let{
    initWasm:A
  }=await Promise.resolve().then(()=>(Ff(),PSA));
  await A()
}var TZn=D(()=>{
  
});
function pps(A){
  let e=RZn.exec(A);
  if(e)return`\\\\${e[1]}`;
  let t=MZn.exec(A);
  return t?t[1]:A
}function Xq(A){
  let e,t=Qps(A),i=A,n=!1,r=[],o=RZn.exec(A),s=MZn.exec(A),a=!1;
  return o?(i=`\\\\${o[1]}`,n=!0):s?(i=s[1],e="devicePath"):rps.test(A)?e="volumeGuid":ips.test(A)?e="wsl":ops.test(A)&&(a=!0,r.push("devicePath")),sps.test(A)&&r.push("ntObjectPath"),{
    input:A,canonical:i,sigil:t,network:Eps(i,e,n,a),local:Bps(i,r)
  }
}function Ym(A){
  return"network"===Xq(A).network.kind
}function lCe(A){
  return"suspicious"===Xq(A).local.kind
}function pC(A){
  let e=Xq(A);
  return"network"===e.network.kind||"suspicious"===e.local.kind&&e.local.reasons.some(A=>"devicePath"===A||"ntObjectPath"===A)
}function Eps(A,e,t,i){
  if(e)return{
    kind:"localMount",mount:e
  };
  if(i)return{
    kind:"local"
  };
  if(nps.test(A))return{
    kind:"network",host:Ips(A),via:t?"uncDevice":mps(A)?"webdav":"unc"
  };
  let n=lps.exec(A);
  return n?{
    kind:"network",host:n[1].toLowerCase(),via:"automount"
  }:{
    kind:"local"
  }
}function mps(A){
  return cps.some(e=>e.test(A))
}function Ips(A){
  let e=aps.exec(A);
  return e?e[1].toLowerCase().replace(/\.+$/,""):null
}function Bps(A,e){
  let t=[...e];
  hps(A)&&t.push("alternateDataStream"),fps.test(A)&&t.push("consecutiveDots");
  let i=A.split(/[\\/]/),n=!1,r=!1,o=!1;
  for(let A of i)""===A||"."===A||".."===A||(dps.test(A)&&(n=!0),/[. ]$/.test(A)&&(r=!0),gps.test(A)&&(o=!0));
  return n&&t.push("shortName83"),r&&t.push("trailingDot"),o&&t.push("reservedDeviceName"),t.length>0?{
    kind:"suspicious",reasons:t
  }:{
    kind:"clean"
  }
}function hps(A){
  return A.replace(ups,"").includes(":")
}function Qps(A){
  let e=/^[\\/]{
    2
  }/.exec(A);
  if(e){
    let[A,t]=e[0];
    return A!==t?"mixed":"\\"===A?"backslash":"slash"
  }let t=A.includes("\\"),i=A.includes("/");
  return t&&i?"mixed":t?"backslash":i?"slash":"none"
}var nps,ips,RZn,MZn,rps,ops,sps,aps,lps,cps,ups,gps,dps,fps,TP=D(()=>{
  nps=/^[\\/]{
    2
  }/,ips=/^[\\/]{
    2
  }wsl(?:\$|\.localhost)[\\/]/i,RZn=/^[\\/]{
    2
  }[?.][\\/]unc[\\/](.+)$/i,MZn=/^[\\/]{
    2
  }[?.][\\/]([A-Za-z]:(?:[\\/].*)?)$/,rps=/^[\\/]{
    2
  }[?.][\\/]volume\{
    [^
  }]*\
}(?:[\\/]|$)/i,ops=/^[\\/]{
  2
}[?.][\\/]/,sps=/^[\\/]\?\?[\\/]/,aps=/^[\\/]{
  2
}(?:[?.][\\/]unc[\\/])?([^\\/]+)/i,lps=/^[\\/]net[\\/]([^\\/]+)(?:[\\/]|$)/,cps=[/@SSL@\d+/i,/@\d+@SSL/i,/DavWWWRoot/i],ups=/^[A-Za-z]:/,gps=/^(?:con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\.|$)/i,dps=/~\d/,fps=/(?:^|[\\/])\.{
  3,
}(?:[\\/]|$)/
});
function yps(A){
  let e=Array.from(A).length;
  return e>=1&&e<=64&&!A.startsWith(" ")&&!A.endsWith(" ")&&!A.endsWith(".")&&"."!==A&&".."!==A&&Cps.test(A)&&!wps.test(A)
}function xZn(A){
  if(void 0===A.rawValue||""===A.rawValue)return{
    userConfigDirName:A.userDefault,projectConfigDirName:A.projectDefault
  };
  let e=A.rawValue.normalize("NFC");
  if(!yps(e))throw new Error(`${A.envName} ${Dps}; received ${JSON.stringify(A.rawValue)}`);
  if(Sps.has(e.toLowerCase()))throw new Error(`${A.envName} ${Pps}; received ${JSON.stringify(A.rawValue)}`);
  return{
    userConfigDirName:e,projectConfigDirName:e
  }
}var Cps,wps,Dps,vZn,Sps,Pps,bZn=D(()=>{
  Cps=/^[\p{
    L
  }\p{
    N
  }\p{
    M
  }._ -]+$/u,wps=/^(?:con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\.|$)/iu,Dps=_$d("KRAeGFIOF0kNFwU0KAwJTBYFAAwPQxwnPUUDDR8JUggKQxYnZCsrL1ICHRsBVh88PgQZBR0CSEldGkVhZDADBREDFgxMVBs0NgQOGBceAUkZRBo7I0UBCQYYFxsfG1M7MQgPCQAfXkkPWB43LQsEAhVMHwgeXAB5ZEdDTl5MUDZOG1N3aUdBTB0eUgACQxYnKgQBTAEcEwoJREh1LRFNAQcfBkkCWAd1NxEMHgZMHRtMUh0xZBIEGBpME0kfRxI2IUlNCRwIUh4FQxt1ZktPQFIDAEkZRBZ1JUUfCQEJAB8JU1M7JQgI"),vZn=[".git",".svn",".hg",".vscode",".idea",".husky",".github","node_modules","bower_components"],Sps=new Set(vZn.map(A=>A.toLowerCase())),Pps=`${_$d("KRAeGFICHR1MQgAwZBUfAwYJER0JU1MxLRcIDwYDABBMWRI4IV5NHAADBgwPQxYxZAsMARcfUggeUlM=")}${vZn.join(", ")}`
});
import eu from"node:path";
import $Qt from"node:os";
import*as ACt from"node:crypto";
import*as kSA from"node:fs";
import{
  fileURLToPath as kps
}from"node:url";
function TSA(){
  return globalThis[zQt]
}function Tps(A){
  let e=globalThis;
  void 0===A?delete e[zQt]:e[zQt]=eu.resolve(A).normalize("NFC"),UZn()
}function zl(){
  return ys(t6A,n6A)||$Qt.homedir()
}function si(){
  if(void 0!==cCe)return cCe;
  let A,e=TSA(),t=ys(i6A);
  if(e)A=e;
  else if(t)A=eu.resolve(t).normalize("NFC");
  else{
    let e=zl();
    A=e?eu.join(e,Uf).normalize("NFC"):eu.join(tCt(),Uf).normalize("NFC")
  }return cCe=A,A
}function Cd(...A){
  let e=si(),t=eu.join($Qt.homedir(),Uf).normalize("NFC");
  return void 0!==TSA()||ys(i6A)||ys(t6A,n6A)||e!==t?eu.join(e,...A):["~",Uf,...A].join("/")
}function UZn(){
  cCe=void 0
}function tCt(){
  return $Qt.tmpdir()
}function RSA(A){
  let e=zl();
  return A===e?"~":A.startsWith(e+eu.sep)?"~"+A.slice(e.length):A
}function EC(A,e=35){
  if(A.length<=e)return A;
  let t=()=>{
    let t=Math.floor((e-3)/2);
    return t<=0?A.substring(0,e-3)+"...":`${A.substring(0,t)}...${A.substring(A.length-t)}`
  },i=eu.parse(A).root,n=eu.sep,r=A.substring(i.length).split(n).filter(A=>""!==A);
  if(r.length<=1)return t();
  let o=r[0],s=r[r.length-1],a=i+o,g=[s],l=s.length;
  for(let A=r.length-2;
  A>0;
  A--){
    let t=r[A];
    if(!(a.length+n.length+3+n.length+l+n.length+t.length<=e))break;
    g.unshift(t),l+=n.length+t.length
  }let B=[o,...g],c=B.map((A,e)=>0===e?"start":e===B.length-1?"end":"center"),Q=g.length+1,E=i.length+Q*n.length+3,I=e-E,u=()=>{
    let A=`...${n}${s}`;
    if(A.length<=e)return A;
    if(i){
      let A=`${i}...${n}${s}`;
      if(A.length<=e)return A
    }return i&&`${i}${s}`.length<=e?`${i}${s}`:s.length<=e?s:t()
  };
  if(I<=0)return u();
  let d=B.map((A,e)=>0===e?Math.min(A.length,1):e===B.length-1?A.length:Math.min(A.length,1));
  if(I<d.reduce((A,e)=>A+e,0))return u();
  let C=B.map(A=>A.length),w=C.reduce((A,e)=>A+e,0),h=()=>{
    let A=-1,e=-1/0;
    for(let t=0;
    t<C.length;
    t++){
      if(C[t]<=d[t])continue;
      let i=(t===C.length-1?0:1e6)+C[t];
      i>e&&(e=i,A=t)
    }return A
  };
  for(;
  w>I;
  ){
    let A=h();
    if(-1===A)return u();
    C[A]--,w--
  }let p=B.map((A,e)=>((A,e,