import { test } from 'node:test'
import assert from 'node:assert/strict'
import { readFileSync, existsSync } from 'node:fs'
import { createRequire } from 'node:module'

const require = createRequire(import.meta.url)

test('dsh.bundle.patch 与 exports', () => {
  const pkg = require('../package.json')
  assert.equal(pkg.dsh.bundle.patch, './cordis.patch.yml')
  assert.ok(existsSync(new URL('../cordis.patch.yml', import.meta.url)))
  assert.equal(pkg.exports['./package.json'], './package.json')
})

test('cordis.patch.yml 插入行名为 dsh-docker', () => {
  const patch = readFileSync(new URL('../cordis.patch.yml', import.meta.url), 'utf8')
  assert.match(patch, /name: '@stardustlc\/dsh-docker'/)
  assert.match(patch, /- insert:/)
})

test('宿主操作无额外引擎依赖，更新控件使用共享库 + 名称版本', () => {
  const pkg = require('../package.json')
  assert.deepEqual(Object.keys(pkg.dependencies), ['@stardustlc/dsh-updates'])
  assert.match(pkg.dependencies['@stardustlc/dsh-updates'], /^\d+\.\d+\.\d+$/, 'Shared update dependency must be pinned exactly')
  assert.equal(pkg.name, '@stardustlc/dsh-docker')
  assert.match(pkg.version, /^\d+\.\d+\.\d+$/)
})
