// Mobile shell glue injected into index.html: drawer scrim, viewport lock,
// keyboard-aware height, and auto-close on conversation switch.
//
// 1) iOS zooms the page when a focused field computes below 16px; the composer
//    is a contenteditable div, so the fix lives in CSS (16px) plus this script
//    locking the viewport as a second line of defence.
// 2) iOS does not shrink the layout viewport for the on-screen keyboard, so the
//    composer would sit underneath it. visualViewport tracks the keyboard, so
//    its height feeds a CSS variable the shell height reads.
// 3) DSH has no "close the sidebar after picking a conversation"; the drawer
//    would stay open over the chat. A title mutation (which is what a session
//    switch changes) collapses it.
(function () {
  if (window.__dshMobileShell) return;
  window.__dshMobileShell = true;

  var scrim = null;
  var narrow = window.matchMedia("(max-width: 820px)");

  function collapseButton() {
    var buttons = document.querySelectorAll("button");
    for (var index = 0; index < buttons.length; index += 1) {
      var label = buttons[index].getAttribute("aria-label") || "";
      if (label.indexOf("收起侧边栏") >= 0 || label.indexOf("Collapse sidebar") >= 0) return buttons[index];
    }
    return null;
  }

  function removeScrim() {
    if (scrim === null) return;
    scrim.remove();
    scrim = null;
  }

  function addScrim() {
    if (scrim !== null) return;
    scrim = document.createElement("div");
    scrim.setAttribute("data-dsh-mobile-scrim", "");
    scrim.style.cssText = "position:fixed;inset:0;z-index:35;background:rgba(0,0,0,0.45);-webkit-tap-highlight-color:transparent;";
    scrim.addEventListener("click", function (event) {
      event.preventDefault();
      event.stopPropagation();
      collapseDrawer();
    });
    document.body.appendChild(scrim);
  }

  function collapseDrawer() {
    var button = collapseButton();
    if (button !== null) button.click();
    removeScrim();
  }

  // ── viewport lock ──────────────────────────────────────────────────────
  // iOS Safari ignores user-scalable=no since iOS 10, so the focus-zoom fix is
  // the 16px field size in CSS; this still stops Android/Chrome pinch-zoom and
  // keeps the layout viewport stable.
  var viewportMeta = document.querySelector('meta[name="viewport"]');
  if (viewportMeta !== null) {
    viewportMeta.setAttribute(
      "content",
      "width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, viewport-fit=cover",
    );
  }
  document.addEventListener("gesturestart", function (event) {
    event.preventDefault();
  }, { passive: false });

  // ── keyboard-aware inset ───────────────────────────────────────────────
  // iOS reports the keyboard only through visualViewport, and it reports
  // intermediate values while the keyboard animates. Shrinking the shell to
  // that value collapsed the whole layout into a sliver, so the shell keeps its
  // height and the conversation column is shifted up by a clamped inset:
  //   inset = layoutHeight - visualViewport.height, accepted only when it looks
  //   like a keyboard (80px .. 55% of the screen) and re-sampled for ~1.2s
  //   after focus, because iOS sometimes fires resize only at the animation
  //   start.
  var root = document.documentElement;
  var settleTimer = null;

  function syncKeyboardInset() {
    var vv = window.visualViewport;
    var layout = window.innerHeight;
    if (vv === undefined || vv === null || layout <= 0) {
      root.style.setProperty("--dsh-keyboard-inset", "0px");
      return;
    }
    var inset = Math.round(layout - vv.height);
    var plausible = inset > 80 && inset < layout * 0.55;
    root.style.setProperty("--dsh-keyboard-inset", plausible ? inset + "px" : "0px");
  }

  function settleInset() {
    var ticks = 0;
    window.clearInterval(settleTimer);
    syncKeyboardInset();
    settleTimer = window.setInterval(function () {
      syncKeyboardInset();
      ticks += 1;
      if (ticks > 12) window.clearInterval(settleTimer);
    }, 100);
  }

  if (window.visualViewport !== undefined && window.visualViewport !== null) {
    window.visualViewport.addEventListener("resize", syncKeyboardInset);
    window.visualViewport.addEventListener("scroll", syncKeyboardInset);
  }
  window.addEventListener("orientationchange", settleInset);
  window.addEventListener("resize", syncKeyboardInset);
  document.addEventListener("focusin", settleInset, true);
  document.addEventListener("focusout", function () {
    window.setTimeout(syncKeyboardInset, 250);
  }, true);
  syncKeyboardInset();

  // ── rotation hygiene ──────────────────────────────────────────────────
  // iOS can come back from a rotation with a stale visual-viewport scale or
  // offset: the layout looks right but taps land where the *scaled* layout was
  // ("UI and buttons are misaligned"). Rewriting the viewport meta forces
  // WebKit to recompute the scale, and scrolling to the origin drops any
  // leftover offset. Also clears a keyboard inset that outlived the keyboard.
  function resetViewportAfterRotation() {
    root.style.setProperty("--dsh-keyboard-inset", "0px");
    var viewport = window.visualViewport;
    var zoomed =
      viewport !== undefined && viewport !== null &&
      (Math.abs((viewport.scale === undefined ? 1 : viewport.scale) - 1) > 0.01 ||
        Math.abs(viewport.offsetTop) > 1 ||
        Math.abs(viewport.offsetLeft) > 1);
    if (Math.abs(window.scrollY) > 1 || Math.abs(window.scrollX) > 1) window.scrollTo(0, 0);
    if (!zoomed) return;
    var meta = document.querySelector('meta[name="viewport"]');
    if (meta === null) return;
    // Two different strings, so WebKit must re-evaluate instead of ignoring a
    // duplicate assignment.
    meta.setAttribute("content", "width=device-width, initial-scale=1, user-scalable=no");
    meta.setAttribute("content", "width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, viewport-fit=cover");
    window.scrollTo(0, 0);
  }

  window.addEventListener("orientationchange", function () {
    window.setTimeout(resetViewportAfterRotation, 120);
    window.setTimeout(resetViewportAfterRotation, 450);
    window.setTimeout(resetViewportAfterRotation, 1000);
  });

  // A resize that arrives without an orientationchange (address-bar show/hide,
  // split view, iPad multitasking) can also leave a stale scale behind.
  var rotationTimer = null;
  window.addEventListener("resize", function () {
    window.clearTimeout(rotationTimer);
    rotationTimer = window.setTimeout(resetViewportAfterRotation, 300);
  });

  // ── no autofocus when a conversation opens ─────────────────────────────
  // DSH focuses the composer whenever a session view mounts, which pops the
  // keyboard over the conversation the user just asked to read (and on iOS can
  // drag the whole layout around). Keep focus only when the tap came from
  // inside the composer; anything programmatic is dropped immediately, in the
  // same task as focusin, so the keyboard never starts to appear.
  // A short retry loop catches shells that re-assert focus right after mount.
  var composerTapAt = 0;
  var stats = window.__dshMobileStats = window.__dshMobileStats || { blurred: 0, allowed: 0 };
  document.addEventListener("pointerdown", function (event) {
    var target = event.target;
    if (target instanceof Element && target.closest("[data-composer-card]") !== null) composerTapAt = Date.now();
  }, true);

  function isComposerEditor(node) {
    if (!(node instanceof Element)) return false;
    var editable =
      node.getAttribute("contenteditable") === "true" || node.tagName === "TEXTAREA" || node.tagName === "INPUT";
    return editable && node.closest("[data-composer-card]") !== null;
  }

  function dropAutofocus() {
    var active = document.activeElement;
    if (!isComposerEditor(active)) return;
    if (Date.now() - composerTapAt < 800) return;
    active.blur();
    stats.blurred += 1;
  }

  document.addEventListener("focusin", function (event) {
    if (!narrow.matches) return;
    if (!isComposerEditor(event.target)) return;
    if (Date.now() - composerTapAt < 800) {
      stats.allowed += 1;
      return;
    }
    // Drop now (keeps the iOS keyboard from starting) and again on the next
    // frames in case the mount effect re-focuses.
    dropAutofocus();
    var tries = 0;
    var retry = window.setInterval(function () {
      dropAutofocus();
      tries += 1;
      if (tries > 20) window.clearInterval(retry);
    }, 100);
  }, true);

  // ── workspace files as a third conversation tab ─────────────────────────
  // The chat area has a tab strip (对话 / 轨迹). We append a sibling tab that
  // shows the file browser in an iframe over the conversation body, so switching
  // tabs feels in-app instead of leaving the SPA.
  var FILES_LABEL = "工作区文件";
  var filesActive = false;
  var filesPanel = null;
  var savedActiveTab = null;

  function findTablist() {
    return document.querySelector('[role="tablist"][data-conversation-tabs]');
  }

  function tablistTabs(tablist) {
    return Array.prototype.slice.call(tablist.querySelectorAll('[role="tab"]'));
  }

  function nativeTabs(tablist) {
    return tablistTabs(tablist).filter(function (tab) {
      return tab.getAttribute("data-dsh-files-tab") === null;
    });
  }

  /** The class DSH uses to mark the selected tab (hash-suffixed, so read it). */
  function activeClassOf(tablist) {
    var tabs = nativeTabs(tablist);
    var on = tabs.filter(function (tab) { return tab.getAttribute("aria-selected") === "true"; })[0];
    var off = tabs.filter(function (tab) { return tab.getAttribute("aria-selected") !== "true"; })[0];
    if (!on || !off) return null;
    for (var index = 0; index < on.classList.length; index += 1) {
      if (!off.classList.contains(on.classList[index])) return on.classList[index];
    }
    return null;
  }

  function ensureFilesTab() {
    var tablist = findTablist();
    if (tablist === null) return null;
    var existing = tablist.querySelector("[data-dsh-files-tab]");
    if (existing !== null) return existing;
    var sample = nativeTabs(tablist).filter(function (tab) {
      return tab.getAttribute("aria-selected") !== "true";
    })[0] || nativeTabs(tablist)[0];
    if (sample === undefined) return null;
    var tab = sample.cloneNode(true);
    tab.setAttribute("data-dsh-files-tab", "");
    tab.setAttribute("role", "tab");
    tab.setAttribute("aria-selected", filesActive ? "true" : "false");
    tab.removeAttribute("aria-controls");
    tab.textContent = FILES_LABEL;
    tab.addEventListener("click", function (event) {
      event.preventDefault();
      event.stopPropagation();
      activateFiles();
    });
    tablist.appendChild(tab);
    return tab;
  }

  /** The session the GUI is showing (persisted by DSH in localStorage). */
  function currentSessionId() {
    try {
      var raw = window.localStorage.getItem("dsh.sessions.current");
      if (!raw) return "";
      var parsed = JSON.parse(raw);
      return typeof parsed.sessionId === "string" ? parsed.sessionId : "";
    } catch (error) {
      return "";
    }
  }

  /** Page URL for the open session; the server defaults to that workspace. */
  function filesPageUrl() {
    var session = currentSessionId();
    return "/api/workspace-files" + (session === "" ? "" : "?session=" + encodeURIComponent(session));
  }

  function showFilesPanel() {
    var content = document.querySelector("[data-conversation-content]");
    var root = content === null ? null : content.parentElement;
    if (root === null) return;
    if (filesPanel !== null && !filesPanel.isConnected) filesPanel = null;
    if (filesPanel === null) {
      filesPanel = document.createElement("div");
      filesPanel.setAttribute("data-dsh-files-panel", "");
      filesPanel.style.cssText = "position:absolute;left:0;right:0;bottom:0;z-index:25;background:#16181c;";
      var frame = document.createElement("iframe");
      frame.title = FILES_LABEL;
      frame.style.cssText = "border:0;width:100%;height:100%;display:block;background:#16181c;";
      filesPanel.appendChild(frame);
    }
    // Follow the session the user switched to; leave in-frame navigation alone.
    var iframe = filesPanel.firstElementChild;
    if (iframe !== null) {
      var session = currentSessionId();
      if (iframe.getAttribute("data-dsh-session") !== session || iframe.getAttribute("src") === null) {
        iframe.setAttribute("data-dsh-session", session);
        iframe.src = filesPageUrl();
      }
    }
    if (filesPanel.parentElement !== root) root.appendChild(filesPanel);
    var header = root.querySelector("header");
    filesPanel.style.top = String(Math.round(header === null ? 76 : header.getBoundingClientRect().height)) + "px";
    // Match the app background so the iframe edge does not show a theme seam.
    var background = window.getComputedStyle(document.body).backgroundColor;
    if (background && background !== "rgba(0, 0, 0, 0)") {
      filesPanel.style.background = background;
      var frame = filesPanel.firstElementChild;
      if (frame !== null) frame.style.background = background;
    }
  }

  function hideFilesPanel() {
    if (filesPanel === null) return;
    filesPanel.remove();
    filesPanel = null;
  }

  function activateFiles() {
    filesActive = true;
    var tablist = findTablist();
    if (tablist !== null) {
      var activeClass = activeClassOf(tablist);
      var current = nativeTabs(tablist).filter(function (tab) {
        return tab.getAttribute("aria-selected") === "true";
      })[0];
      if (activeClass !== null && current !== undefined) {
        savedActiveTab = { tab: current, cls: activeClass };
        current.classList.remove(activeClass);
        current.setAttribute("aria-selected", "false");
      }
      var mine = ensureFilesTab();
      if (mine !== null) {
        mine.setAttribute("aria-selected", "true");
        if (activeClass !== null) mine.classList.add(activeClass);
      }
    }
    showFilesPanel();
  }

  function deactivateFiles() {
    if (!filesActive && filesPanel === null) return;
    filesActive = false;
    hideFilesPanel();
    var tablist = findTablist();
    var mine = tablist === null ? null : tablist.querySelector("[data-dsh-files-tab]");
    if (mine !== null && savedActiveTab !== null) mine.classList.remove(savedActiveTab.cls);
    if (mine !== null) mine.setAttribute("aria-selected", "false");
    if (savedActiveTab !== null) {
      savedActiveTab.tab.setAttribute("aria-selected", "true");
      savedActiveTab.tab.classList.add(savedActiveTab.cls);
      savedActiveTab = null;
    }
  }

  // Clicking one of DSH's own tabs leaves the file view.
  document.addEventListener("click", function (event) {
    var target = event.target;
    if (!(target instanceof Element)) return;
    if (target.closest("[data-dsh-files-tab]") !== null) return;
    if (target.closest('[role="tablist"][data-conversation-tabs]') !== null) {
      // Let DSH's own handler run first, then drop our panel.
      window.setTimeout(deactivateFiles, 0);
    }
  }, true);

  // Tab strips and conversation bodies are re-created on session switches, so a
  // slow tick keeps the tab present and re-attaches the panel when React
  // replaced the node it hung on.
  window.setInterval(function () {
    try {
      ensureFilesTab();
      if (filesActive) showFilesPanel();
    } catch (error) {
      if (window.console) window.console.warn("dsh-mobile-shell: files tab", error);
    }
  }, 700);

  // ── drawer scrim + auto-close on conversation switch ────────────────────
  function watch() {
    var panel = document.querySelector('[data-slot="sidebar"] > div');
    if (panel === null) {
      window.setTimeout(watch, 400);
      return;
    }

    var sync = function () {
      var open = narrow.matches && panel.getBoundingClientRect().width > 100;
      if (open) addScrim();
      else removeScrim();
    };
    if (typeof ResizeObserver === "function") new ResizeObserver(sync).observe(panel);
    window.addEventListener("resize", sync);
    window.addEventListener("orientationchange", sync);
    sync();

    // Switching conversation rewrites the document title; that is the signal
    // (the SPA keeps one URL). Collapsing on a title change also covers the
    // "new conversation" button.
    var titleNode = document.head.querySelector("title");
    if (titleNode !== null) {
      new MutationObserver(function () {
        if (narrow.matches && panel.getBoundingClientRect().width > 100) collapseDrawer();
        deactivateFiles();
      }).observe(titleNode, { childList: true, characterData: true, subtree: true });
    }
  }

  watch();
})();
