import {
  forwardRef,
  useImperativeHandle,
  useLayoutEffect,
  useRef,
  useState,
  type ClipboardEvent,
  type KeyboardEventHandler,
} from "react";
import type { Attachment } from "../types";
import { attachmentContentUrl, attachmentUrlId, isAttachmentUrl, resolvePersistedAttachmentUrl } from "../api";
import { useTaskboardI18n } from "../i18n";
import { clipboardImages, fileKey, MAX_ATTACHMENT_SIZE } from "./PendingAttachments";
import { LinearIcon } from "./LinearIcon";

interface InlineTextSegment {
  id: string;
  type: "text";
  text: string;
}

interface InlineImageSegment {
  id: string;
  type: "pending-image";
  token: string;
  file: File;
}

interface InlineExistingImageSegment {
  id: string;
  type: "existing-image";
  raw: string;
  alt: string;
  src: string;
}

export type InlineMediaSegment = InlineTextSegment | InlineImageSegment | InlineExistingImageSegment;
export type PendingInlineImage = InlineImageSegment;
type InlineMediaError = string | readonly [string, string];

export interface InlineMediaComposerHandle {
  focus: () => void;
  addImages: (files: FileList | File[]) => void;
}

interface InlineMediaComposerProps {
  segments: InlineMediaSegment[];
  placeholder: string;
  ariaLabel: string;
  disabled?: boolean;
  className?: string;
  onChange: (segments: InlineMediaSegment[]) => void;
  onError: (message: InlineMediaError | null) => void;
  onKeyDown?: KeyboardEventHandler<HTMLTextAreaElement>;
}

let segmentSequence = 0;

function segmentId(prefix: string): string {
  segmentSequence += 1;
  return `${prefix}-${Date.now().toString(36)}-${segmentSequence.toString(36)}`;
}

function textSegment(text = ""): InlineTextSegment {
  return { id: segmentId("text"), type: "text", text };
}

function imageSegment(file: File): InlineImageSegment {
  const id = segmentId("image");
  return {
    id,
    type: "pending-image",
    token: `<!--taskboard-inline-image:${id}-->`,
    file,
  };
}

const INLINE_IMAGE_PATTERN = /!\[([^\]]*)\]\((?:<([^>]*)>|([^)\s]+))(?:\s+"[^"]*")?\)/g;

function parseInlineImage(raw: string): { alt: string; src: string } | null {
  const match = raw.match(/^!\[([^\]]*)\]\((?:<([^>]*)>|([^)\s]+))(?:\s+"[^"]*")?\)$/);
  if (!match) return null;
  return { alt: match[1], src: match[2] ?? match[3] ?? "" };
}

function existingImageSegment(raw: string): InlineExistingImageSegment {
  const parsed = parseInlineImage(raw);
  return {
    id: segmentId("media"),
    type: "existing-image",
    raw,
    alt: parsed?.alt ?? "",
    src: parsed?.src ?? "",
  };
}

function splitInlineMediaSegments(value: string): InlineMediaSegment[] {
  const segments: InlineMediaSegment[] = [];
  let cursor = 0;
  for (const match of value.matchAll(INLINE_IMAGE_PATTERN)) {
    const start = match.index;
    if (start === undefined || start < cursor) continue;
    if (start > cursor) segments.push(textSegment(value.slice(cursor, start)));
    segments.push(existingImageSegment(match[0]));
    cursor = start + match[0].length;
  }
  const rest = value.slice(cursor);
  if (rest.length > 0 || segments.length === 0) segments.push(textSegment(rest));
  return segments;
}

export function createInlineMediaSegments(text = ""): InlineMediaSegment[] {
  return normalizeSegments(splitInlineMediaSegments(text));
}

export function inlineMediaImages(segments: InlineMediaSegment[]): PendingInlineImage[] {
  return segments.filter((segment): segment is PendingInlineImage => segment.type === "pending-image");
}

export function inlineMediaText(segments: InlineMediaSegment[]): string {
  return segments.flatMap((segment) => segment.type === "text" ? [segment.text] : []).join("");
}

export function serializeInlineMedia(segments: InlineMediaSegment[]): string {
  return segments.map((segment) => {
    if (segment.type === "text") return segment.text;
    // Persisted markdown images round-trip verbatim so re-saving an edited
    // description or comment keeps them byte-identical (no re-upload, no
    // spurious whitespace-only updates).
    if (segment.type === "existing-image") return segment.raw;
    return `\n\n${segment.token}\n\n`;
  }).join("");
}

export function resolveInlineMediaMarkdown(
  value: string,
  images: PendingInlineImage[],
  attachments: Attachment[],
): string {
  return images.reduce((markdown, image, index) => {
    const attachment = attachments[index];
    if (!attachment) return markdown;
    const alt = image.file.name.replace(/[\\[\]]/g, "\\$&");
    return markdown.replace(
      image.token,
      `![${alt}](${attachmentContentUrl(attachment)})`,
    );
  }, value);
}

function normalizeSegments(segments: InlineMediaSegment[]): InlineMediaSegment[] {
  const normalized: InlineMediaSegment[] = [];
  for (const segment of segments) {
    const previous = normalized.at(-1);
    if (segment.type === "text" && previous?.type === "text") {
      normalized[normalized.length - 1] = {
        ...previous,
        text: previous.text + segment.text,
      };
    } else {
      normalized.push(segment);
    }
  }
  if (normalized.length === 0) return [textSegment()];
  if (normalized[0].type !== "text") normalized.unshift(textSegment());
  if (normalized.at(-1)?.type !== "text") normalized.push(textSegment());
  return normalized;
}

function resizeTextarea(element: HTMLTextAreaElement | null) {
  if (!element) return;
  element.style.height = "0px";
  element.style.height = `${element.scrollHeight}px`;
}

function PendingImageBlock({
  segment,
  disabled,
  onRemove,
}: {
  segment: PendingInlineImage;
  disabled: boolean;
  onRemove: () => void;
}) {
  const [previewUrl, setPreviewUrl] = useState("");
  const { text } = useTaskboardI18n();

  useLayoutEffect(() => {
    const url = URL.createObjectURL(segment.file);
    setPreviewUrl(url);
    return () => URL.revokeObjectURL(url);
  }, [segment.file]);

  return (
    <figure className="inline-media-image">
      {previewUrl && <img src={previewUrl} alt={segment.file.name} />}
      <button
        type="button"
        disabled={disabled}
        aria-label={text(`移除 ${segment.file.name}`, `Remove ${segment.file.name}`)}
        onClick={onRemove}
      >
        <LinearIcon name="close" />
      </button>
    </figure>
  );
}

function ExistingImageBlock({
  segment,
  disabled,
  onRemove,
}: {
  segment: InlineExistingImageSegment;
  disabled: boolean;
  onRemove: () => void;
}) {
  const [failed, setFailed] = useState(false);
  const { text } = useTaskboardI18n();
  // Prose placeholders (attachment-shaped but no real upload id) never load;
  // go straight to the unavailable state without requesting them.
  const impossible = segment.src !== "" && isAttachmentUrl(segment.src) && attachmentUrlId(segment.src) === null;
  const src = segment.src && !impossible ? resolvePersistedAttachmentUrl(segment.src) : "";

  return (
    <figure className="inline-media-image">
      {src && !failed
        ? <img src={src} alt={segment.alt} onError={() => setFailed(true)} />
        : (
          <div className="inline-media-broken">
            <LinearIcon name="alert" />
            <span>{text("图片无法预览", "Image preview unavailable")}</span>
            <code>{segment.alt || segment.src}</code>
          </div>
        )}
      <button
        type="button"
        disabled={disabled}
        aria-label={text(
          `移除 ${segment.alt || segment.src}`,
          `Remove ${segment.alt || segment.src}`,
        )}
        onClick={onRemove}
      >
        <LinearIcon name="close" />
      </button>
    </figure>
  );
}

export const InlineMediaComposer = forwardRef<InlineMediaComposerHandle, InlineMediaComposerProps>(
  function InlineMediaComposer({
    segments,
    placeholder,
    ariaLabel,
    disabled = false,
    className = "",
    onChange,
    onError,
    onKeyDown,
  }, ref) {
    const textareas = useRef(new Map<string, HTMLTextAreaElement>());
    const pendingFocus = useRef<{ id: string; offset: number } | null>(null);
    const { text } = useTaskboardI18n();

    useLayoutEffect(() => {
      for (const element of textareas.current.values()) resizeTextarea(element);
      const focus = pendingFocus.current;
      if (!focus) return;
      const target = textareas.current.get(focus.id);
      if (!target) return;
      target.focus();
      target.setSelectionRange(focus.offset, focus.offset);
      pendingFocus.current = null;
    }, [segments]);

    useImperativeHandle(ref, () => ({
      focus() {
        const firstText = segments.find((segment) => segment.type === "text");
        if (firstText) textareas.current.get(firstText.id)?.focus();
      },
      addImages(files) {
        const selected = Array.from(files).filter((file) => file.type.startsWith("image/"));
        if (selected.length === 0) return;

        const oversized = selected.find((file) => file.size > MAX_ATTACHMENT_SIZE);
        if (oversized) {
          onError([
            `“${oversized.name}” 超过 25 MB，无法上传。`,
            `“${oversized.name}” is larger than 25 MB and cannot be uploaded.`,
          ]);
          return;
        }

        const existing = new Set(inlineMediaImages(segments).map((image) => fileKey(image.file)));
        const images = selected.filter((file) => {
          const key = fileKey(file);
          if (existing.has(key)) return false;
          existing.add(key);
          return true;
        });
        if (images.length === 0) return;
        onError(null);
        onChange(normalizeSegments([...segments, ...images.map(imageSegment)]));
      },
    }), [onChange, onError, segments]);

    function changeText(id: string, text: string) {
      onChange(segments.map((segment) => (
        segment.id === id && segment.type === "text" ? { ...segment, text } : segment
      )));
    }

    function pasteImages(
      event: ClipboardEvent<HTMLTextAreaElement>,
      segment: InlineTextSegment,
    ) {
      const clipboardFiles = clipboardImages(event.clipboardData);
      if (clipboardFiles.length === 0) return;
      event.preventDefault();

      const oversized = clipboardFiles.find((file) => file.size > MAX_ATTACHMENT_SIZE);
      if (oversized) {
        onError([
          `“${oversized.name}” 超过 25 MB，无法上传。`,
          `“${oversized.name}” is larger than 25 MB and cannot be uploaded.`,
        ]);
        return;
      }

      const existing = new Set(inlineMediaImages(segments).map((image) => fileKey(image.file)));
      const images = clipboardFiles.filter((file) => {
        const key = fileKey(file);
        if (existing.has(key)) return false;
        existing.add(key);
        return true;
      });
      if (images.length === 0) return;
      onError(null);

      const textarea = event.currentTarget;
      const start = textarea.selectionStart;
      const end = textarea.selectionEnd;
      const before = { ...segment, text: segment.text.slice(0, start) };
      const after = textSegment(segment.text.slice(end));
      const insertion = images.map(imageSegment);
      const next = segments.flatMap((candidate) => (
        candidate.id === segment.id ? [before, ...insertion, after] : [candidate]
      ));
      pendingFocus.current = { id: after.id, offset: 0 };
      onChange(next);
    }

    function removeImage(id: string) {
      onChange(normalizeSegments(segments.filter((segment) => segment.id !== id)));
    }

    const isEmpty = segments.every((segment) => (
      segment.type === "text" ? segment.text.length === 0 : false
    ));

    return (
      <div className={`inline-media-composer ${className}`.trim()} aria-label={ariaLabel}>
        {segments.map((segment, index) => (
          segment.type === "text" ? (
            <textarea
              key={segment.id}
              ref={(element) => {
                if (element) textareas.current.set(segment.id, element);
                else textareas.current.delete(segment.id);
              }}
              value={segment.text}
              rows={1}
              disabled={disabled}
              aria-label={index === 0 ? ariaLabel : text(`${ariaLabel}续写`, `${ariaLabel} continuation`)}
              placeholder={isEmpty && index === 0 ? placeholder : undefined}
              onChange={(event) => {
                changeText(segment.id, event.target.value);
                resizeTextarea(event.currentTarget);
              }}
              onPaste={(event) => pasteImages(event, segment)}
              onKeyDown={onKeyDown}
            />
          ) : segment.type === "existing-image" ? (
            <ExistingImageBlock
              key={segment.id}
              segment={segment}
              disabled={disabled}
              onRemove={() => removeImage(segment.id)}
            />
          ) : (
            <PendingImageBlock
              key={segment.id}
              segment={segment}
              disabled={disabled}
              onRemove={() => removeImage(segment.id)}
            />
          )
        ))}
      </div>
    );
  },
);
