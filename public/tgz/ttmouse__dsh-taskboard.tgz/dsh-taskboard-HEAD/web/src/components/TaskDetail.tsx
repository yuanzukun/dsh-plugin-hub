import { useCallback, useEffect, useRef, useState, type ImgHTMLAttributes, type KeyboardEvent, type MouseEvent } from "react";
import ReactMarkdown, { type Components } from "react-markdown";
import { defaultUrlTransform } from "react-markdown";
import remarkGfm from "remark-gfm";
import { taskboardStorage } from "../storage";
import { isDshThreadId } from "../threads";
import {
  ApiError,
  attachmentContentUrl,
  attachmentDownloadUrl,
  attachmentUrlId,
  createComment,
  deleteAttachment,
  deleteComment,
  cancelIssueRound,
  dispatchIssue,
  fetchDispatchState,
  isAttachmentUrl,
  listAttachments,
  listComments,
  listTaskActivities,
  markdownIncludesAttachment,
  resolveTaskboardUrl,
  resolvePersistedAttachmentUrl,
  uploadAttachment,
  uploadCommentAttachment,
  updateComment,
} from "../api";
import {
  taskPriorityLabel,
  taskStatusLabel,
  useTaskboardI18n,
  type TaskboardLanguage,
} from "../i18n";
import { TASK_PRIORITIES, TASK_STATUSES } from "../types";
import type {
  ActorIdentity,
  Attachment,
  Comment,
  DevelopmentContext,
  DevelopmentScan,
  IssueRelationType,
  Recurrence,
  Task,
  TaskChangeActivity,
  TaskDraft,
  TaskPriority,
  TaskRelationSummary,
  TaskStatus,
  WorkflowOption,
} from "../types";
import {
  CODEX_AGENT_ACTOR,
  DSH_AGENT_ACTOR,
  actorKey,
  assigneeTargetForActor,
} from "../actors";
import { ActorAvatar } from "./ActorAvatar";
import { STATUS_DETAILS, StatusIcon } from "./BoardColumn";
import { LabelPicker } from "./LabelPicker";
import { LinearIcon, LinearPriorityIcon } from "./LinearIcon";
import { TaskboardIcon } from "./TaskboardIcon";
import {
  fileKey,
  MAX_ATTACHMENT_SIZE,
  PendingAttachments,
} from "./PendingAttachments";
import {
  createInlineMediaSegments,
  InlineMediaComposer,
  inlineMediaImages,
  inlineMediaText,
  resolveInlineMediaMarkdown,
  serializeInlineMedia,
  type InlineMediaComposerHandle,
  type InlineMediaSegment,
} from "./InlineMediaComposer";
import {
  IssueParentLink,
  IssueRelationSidebar,
  IssueSubIssues,
  type RelationMutationResult,
} from "./IssueRelations";
import { TaskPropertyPicker } from "./TaskPropertyPicker";
import { CommentOptions } from "./CommentOptions";
import { buildIssueUrl } from "../issueRoute";
import copyIdIcon from "../assets/figma-taskboard/copy-id.svg";
import copyLinkIcon from "../assets/figma-taskboard/copy-link.svg";

type TaskDetailError = string | readonly [string, string];

interface TaskDetailProps {
  task: Task;
  tasks: Task[];
  currentUser: ActorIdentity;
  availableLabels: string[];
  workflows: WorkflowOption[];
  developmentScan: DevelopmentScan;
  developmentScanLoading: boolean;
  commentsRevision: number;
  attachmentsRevision: number;
  onUpdate: (task: Task, changes: Partial<TaskDraft>) => Promise<Task>;
  onOpenTask: (task: TaskRelationSummary) => void;
  onAddRelation: (
    task: Task,
    type: IssueRelationType,
    relatedTaskId: string,
  ) => Promise<RelationMutationResult>;
  onRemoveRelation: (
    task: Task,
    type: IssueRelationType,
    relatedTaskId: string,
  ) => Promise<RelationMutationResult>;
  onOpenThread: (threadId: string) => void;
  onOpenInThread: (task: Task) => void;
  onCopy: (text: string, announcement: string) => void;
  openingThread: boolean;
  onError: (message: TaskDetailError | null) => void;
  onAnnounce: (message: string) => void;
  onClose: () => void;
  /** 验收成功后回调：宿主负责落卡动画并退出详情回列表。 */
  onAccepted?: (taskId: string) => void;
  /** 属性栏折叠状态由宿主持有：开关按钮放在宿主顶栏图标行里。 */
  propertiesCollapsed: boolean;
  onSetPropertiesCollapsed: (next: boolean | ((current: boolean) => boolean)) => void;
}

function messageFor(error: unknown): TaskDetailError {
  if (error instanceof ApiError) return error.message;
  if (error instanceof Error) return error.message;
  return ["操作未完成，请重试。", "The action could not be completed. Try again."];
}

function issueMessageFor(error: unknown): TaskDetailError {
  if (error instanceof ApiError && error.code === "VERSION_CONFLICT") {
    return [
      "该议题已在其他位置更新，请刷新后重试。",
      "This issue changed elsewhere. Refresh and try again.",
    ];
  }
  return messageFor(error);
}

function exactTime(value: string, locale: string): string {
  return new Intl.DateTimeFormat(locale, {
    dateStyle: "medium",
    timeStyle: "short",
  }).format(new Date(value));
}

function relativeTime(value: string, locale: string): string {
  const seconds = Math.round((new Date(value).getTime() - Date.now()) / 1000);
  const formatter = new Intl.RelativeTimeFormat(locale, { numeric: "auto" });
  if (Math.abs(seconds) < 60) return formatter.format(seconds, "second");
  const minutes = Math.round(seconds / 60);
  if (Math.abs(minutes) < 60) return formatter.format(minutes, "minute");
  const hours = Math.round(minutes / 60);
  if (Math.abs(hours) < 24) return formatter.format(hours, "hour");
  const days = Math.round(hours / 24);
  if (Math.abs(days) < 30) return formatter.format(days, "day");
  return new Intl.DateTimeFormat(locale, { month: "short", day: "numeric" }).format(new Date(value));
}

function resizeTextarea(element: HTMLTextAreaElement | null) {
  if (!element) return;
  element.style.height = "0px";
  element.style.height = `${element.scrollHeight}px`;
}

function fileSize(value: number): string {
  if (value < 1024) return `${value} B`;
  if (value < 1024 * 1024) return `${(value / 1024).toFixed(value < 10 * 1024 ? 1 : 0)} KB`;
  return `${(value / (1024 * 1024)).toFixed(value < 10 * 1024 * 1024 ? 1 : 0)} MB`;
}

async function downloadAttachmentFile(attachment: Attachment) {
  const response = await fetch(resolveTaskboardUrl(attachmentDownloadUrl(attachment)));
  if (!response.ok) {
    throw new ApiError(response.status, await response.json().catch(() => ({})));
  }
  const url = URL.createObjectURL(await response.blob());
  const link = document.createElement("a");
  link.href = url;
  link.download = attachment.filename;
  document.body.appendChild(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
}

function contextValue(context: DevelopmentContext | null): string {
  return context ? JSON.stringify(context) : "";
}

function contextLabel(
  context: DevelopmentContext,
  text: (chinese: string, english: string) => string,
): string {
  if (context.type === "branch") return context.branch;
  const folder = context.path.split(/[\\/]/).filter(Boolean).at(-1) ?? context.path;
  return `${context.branch ?? text("分离 HEAD", "detached")} · ${folder}`;
}

const ACTIVITY_FIELD_LABELS: Record<string, readonly [string, string]> = {
  projectId: ["项目", "project"],
  title: ["标题", "title"],
  description: ["描述", "description"],
  status: ["状态", "status"],
  priority: ["优先级", "priority"],
  labels: ["标签", "labels"],
  assignee: ["负责人", "assignee"],
  workflowId: ["工作流", "workflow"],
  developmentContext: ["开发上下文", "development context"],
  startDate: ["开始日期", "start date"],
  dueDate: ["截止日期", "due date"],
  recurrence: ["重复", "recurrence"],
  archivedAt: ["归档状态", "archive status"],
  relation: ["关系", "relation"],
};

const RELATION_LABELS: Record<IssueRelationType, readonly [string, string]> = {
  parent: ["父议题", "Parent issue"],
  blocks: ["阻塞", "Blocks"],
  blocked_by: ["阻塞于", "Blocked by"],
  related: ["相关议题", "Related issue"],
};

/**
 * The comment box's placeholder IS the rule: it says what sending will do for
 * the state this issue is in right now, so nobody has to learn the board's
 * status semantics or pick a mode. One line, shown exactly when it matters.
 * @param status - the issue's current status.
 * @param text - the zh/en picker from the detail panel.
 */
function commentPlaceholder(
  status: TaskStatus,
  text: (zh: string, en: string) => string,
): string {
  switch (status) {
    case "in_review":
      return text(
        "写下要改的地方 —— 发送后它立刻改这一版",
        "Describe the change — sending makes it rework this version",
      );
    case "blocked":
      return text(
        "回答它，或说下一步 —— 发送后它继续",
        "Answer it or say what's next — sending continues the run",
      );
    case "in_progress":
      return text(
        "先说一句 —— 它会在这一轮结束后接上",
        "Say it now — it is picked up when this round ends",
      );
    case "todo":
    case "backlog":
      return text("记一笔（不会启动）", "Leave a note (nothing starts)");
    default:
      return text("记一笔", "Leave a note");
  }
}

function activityValue(
  field: string,
  value: unknown,
  language: TaskboardLanguage,
  locale: string,
  text: (chinese: string, english: string) => string,
): string {
  if (field === "archivedAt") {
    return typeof value === "string"
      ? text(`已归档（${exactTime(value, locale)}）`, `Archived (${exactTime(value, locale)})`)
      : text("未归档", "Not archived");
  }
  if (value === null || value === "") return text("未设置", "Not set");
  if (field === "status" && typeof value === "string" && value in STATUS_DETAILS) {
    return taskStatusLabel(language, value as TaskStatus);
  }
  if (field === "priority" && typeof value === "string" && TASK_PRIORITIES.includes(value as TaskPriority)) {
    return taskPriorityLabel(language, value as TaskPriority);
  }
  if (field === "labels" && Array.isArray(value)) {
    return value.length > 0
      ? value.join(language === "zh" ? "、" : ", ")
      : text("无标签", "No labels");
  }
  if (field === "assignee" && typeof value === "object") {
    const actor = value as ActorIdentity;
    return `${actor.name} @${actor.id}`;
  }
  if (field === "developmentContext" && typeof value === "object") {
    const context = value as { type: string; branch?: string | null; path?: string | null };
    if (context.type === "branch") return context.branch ?? text("未设置", "Not set");
    const folder = context.path?.split(/[\\/]/).filter(Boolean).at(-1);
    return `${context.branch ?? text("分离 HEAD", "detached")}${folder ? ` · ${folder}` : ""}`;
  }
  if (field === "recurrence" && typeof value === "object") {
    const recurrence = value as Recurrence;
    const units: Record<Recurrence["unit"], readonly [string, string]> = {
      day: ["天", "day"],
      week: ["周", "week"],
      month: ["月", "month"],
      year: ["年", "year"],
    };
    const [chineseUnit, englishUnit] = units[recurrence.unit];
    return text(
      recurrence.interval === 1 ? `每${chineseUnit}` : `每 ${recurrence.interval} ${chineseUnit}`,
      `Every ${recurrence.interval === 1 ? "" : `${recurrence.interval} `}${englishUnit}${recurrence.interval === 1 ? "" : "s"}`,
    );
  }
  if (field === "relation" && typeof value === "object") {
    const relation = value as { type: IssueRelationType; identifier: string; title: string };
    const [chineseLabel, englishLabel] = RELATION_LABELS[relation.type];
    return `${text(chineseLabel, englishLabel)} ${relation.identifier} · ${relation.title}`;
  }
  if (Array.isArray(value)) return value.join(language === "zh" ? "、" : ", ");
  if (typeof value === "object") return JSON.stringify(value);
  return String(value);
}

function ActivityChangeIcon({ field, before, after }: {
  field: string;
  before: unknown;
  after: unknown;
}) {
  const value = after ?? before;
  if (field === "status" && typeof value === "string" && value in STATUS_DETAILS) {
    return <StatusIcon status={value as TaskStatus} />;
  }
  if (field === "priority" && typeof value === "string" && TASK_PRIORITIES.includes(value as TaskPriority)) {
    return <LinearPriorityIcon priority={value as TaskPriority} />;
  }
  if (field === "relation" && typeof value === "object") {
    const relation = value as { type?: IssueRelationType };
    if (relation.type === "blocked_by") return <TaskboardIcon name="relationBlockedBy" />;
    if (relation.type === "blocks") return <TaskboardIcon name="relationBlocks" />;
    return <LinearIcon name="link" />;
  }
  if (field === "projectId" || field === "workflowId") return <LinearIcon name="project" />;
  if (field === "labels") return <LinearIcon name="label" />;
  if (field === "assignee") return <LinearIcon name="myIssues" />;
  if (field === "developmentContext") return <LinearIcon name="branch" />;
  if (field === "startDate" || field === "dueDate") return <LinearIcon name="calendar" />;
  if (field === "recurrence") return <LinearIcon name="recurrence" />;
  if (field === "archivedAt") return <LinearIcon name="trash" />;
  return <LinearIcon name="write" />;
}

// Attachment images load through fetch-then-render: the attachment route is
// same-origin, so the page fetches the bytes itself and renders the blob as
// the <img> source — the element then never issues its own network request.
// This sidesteps environments where <img> loads issued while a detail view
// mounts keep failing until a later manual retry, and it lets the retry
// chain keep running in the background over a long tail without visual
// churn. Failures carry the HTTP status into the placeholder. External
// (non-attachment) images stay on the plain <img> element — fetching them
// would need CORS they don't have — with remount-based retries instead.
const ATTACHMENT_RETRY_DELAYS_MS = [600, 1800, 4000, 8000, 15000, 30000] as const;
const IMAGE_RETRY_DELAYS_MS = [600, 1800, 4000, 8000] as const;

class ImageHttpStatusError extends Error {
  constructor(readonly status: number) {
    super(`HTTP ${status}`);
  }
}

type AttachmentImageState = {
  blobUrl: string | null;
  loading: boolean;
  failed: boolean;
  failureStatus: number | null;
  failureMessage: string | null;
};

function useAttachmentImage(src: string | null, nonce: number): AttachmentImageState {
  const [blobUrl, setBlobUrl] = useState<string | null>(null);
  const [loading, setLoading] = useState(Boolean(src));
  const [failed, setFailed] = useState(!src);
  const [failureStatus, setFailureStatus] = useState<number | null>(null);
  const [failureMessage, setFailureMessage] = useState<string | null>(null);
  const retryTimerRef = useRef<number | null>(null);

  useEffect(() => {
    if (retryTimerRef.current !== null) {
      window.clearTimeout(retryTimerRef.current);
      retryTimerRef.current = null;
    }
    if (!src) {
      setBlobUrl(null);
      setLoading(false);
      setFailed(true);
      setFailureStatus(null);
      setFailureMessage(null);
      return;
    }
    setBlobUrl(null);
    setLoading(true);
    setFailed(false);
    setFailureStatus(null);
    setFailureMessage(null);
    let cancelled = false;
    let objectUrl: string | null = null;

    // Transport matrix, in order: fetch with no-store (the normal path),
    // plain fetch, then XHR. Some desktop webviews fail one transport at the
    // network layer while another succeeds; walking the matrix both heals
    // those cases and names the failing transport in the final placeholder.
    const attempt = async (n: number): Promise<void> => {
      if (cancelled) return;
      const transport = n === 0 ? "fetch" : n === 1 ? "fetch-plain" : "xhr";
      try {
        let blob: Blob;
        if (transport === "xhr") {
          blob = await new Promise<Blob>((resolve, reject) => {
            const xhr = new XMLHttpRequest();
            xhr.open("GET", src);
            xhr.responseType = "blob";
            xhr.onload = () => {
              if (xhr.status >= 200 && xhr.status < 300) resolve(xhr.response as Blob);
              else reject(new ImageHttpStatusError(xhr.status));
            };
            xhr.onerror = () => reject(new Error("network error"));
            xhr.onabort = () => reject(new Error("aborted"));
            xhr.send();
          });
        } else {
          const response = await fetch(src, transport === "fetch" ? { cache: "no-store" } : undefined);
          if (cancelled) return;
          if (!response.ok) throw new ImageHttpStatusError(response.status);
          blob = await response.blob();
        }
        if (cancelled) return;
        objectUrl = URL.createObjectURL(blob);
        setBlobUrl(objectUrl);
        setLoading(false);
      } catch (error) {
        if (cancelled) return;
        const status = error instanceof ImageHttpStatusError ? error.status : null;
        if (n >= ATTACHMENT_RETRY_DELAYS_MS.length) {
          setLoading(false);
          setFailed(true);
          setFailureStatus(status);
          setFailureMessage(`${transport}: ${error instanceof Error ? error.message : String(error)}`);
          return;
        }
        retryTimerRef.current = window.setTimeout(() => {
          retryTimerRef.current = null;
          void attempt(n + 1);
        }, ATTACHMENT_RETRY_DELAYS_MS[n]);
      }
    };
    void attempt(0);
    return () => {
      cancelled = true;
      if (retryTimerRef.current !== null) {
        window.clearTimeout(retryTimerRef.current);
        retryTimerRef.current = null;
      }
      if (objectUrl !== null) URL.revokeObjectURL(objectUrl);
    };
  }, [src, nonce]);

  return { blobUrl, loading, failed, failureStatus, failureMessage };
}

// Image attachments show a real thumbnail in the attachment list: the bytes
// are fetched once through the same fetch-then-blob loader used by markdown
// images, and while loading (or after failure) the generic file icon stays.
function AttachmentThumbnail({ attachment }: { attachment: Attachment }) {
  // useAttachmentImage already re-runs whenever src changes, so no extra
  // state is needed here.
  const src = resolvePersistedAttachmentUrl(attachmentContentUrl(attachment));
  const image = useAttachmentImage(src, 0);

  if (image.blobUrl) {
    return <img className="attachment-thumb" src={image.blobUrl} alt="" aria-hidden="true" />;
  }
  return (
    <span className="attachment-file-icon" aria-hidden="true">
      <LinearIcon name="file" />
    </span>
  );
}

function MarkdownImage({ alt, src, ...props }: ImgHTMLAttributes<HTMLImageElement>) {
  const { text } = useTaskboardI18n();
  const [nonce, setNonce] = useState(0);
  const [plainAttempt, setPlainAttempt] = useState(0);
  const [plainFailed, setPlainFailed] = useState(!src);
  // Same-origin <img> requests have proven unreliable inside the desktop
  // webview, so when the plain element fails we stop retrying it and switch
  // to the fetch-then-blob loader instead — it renders through an object URL
  // and never asks <img> to issue the request itself.
  const [fetchFallback, setFetchFallback] = useState(false);
  const [fallbackNonce, setFallbackNonce] = useState(0);
  const plainTimerRef = useRef<number | null>(null);

  // Accept any spelling of the attachment namespace (missing leading slash,
  // bare api/…, absolute 127.0.0.1 URL) so the fetch-first path can take over.
  const normalizedSrc =
    typeof src === "string" && /(^|\/)api\/attachments\//.test(src) && !src.startsWith("blob:")
      ? resolvePersistedAttachmentUrl(src)
      : src;
  const isAttachment = typeof normalizedSrc === "string" && normalizedSrc !== "" && isAttachmentUrl(normalizedSrc);
  const attachment = useAttachmentImage(isAttachment ? normalizedSrc : null, nonce);
  const fallback = useAttachmentImage(fetchFallback && !isAttachment ? normalizedSrc ?? null : null, fallbackNonce);

  function isSameOriginUrl(value: string): boolean {
    if (/^https?:/i.test(value)) {
      try {
        return new URL(value, document.baseURI).origin === window.location.origin;
      } catch {
        return false;
      }
    }
    return true;
  }

  useEffect(() => {
    setPlainAttempt(0);
    setPlainFailed(!src);
    return () => {
      if (plainTimerRef.current !== null) {
        window.clearTimeout(plainTimerRef.current);
        plainTimerRef.current = null;
      }
    };
  }, [src]);

  // Prose examples like ![…](api/attachments/…) name an id no upload could
  // have produced. They can never load, so show the literal markup they are
  // instead of a doomed request with a retry button that never succeeds.
  if (src && isAttachmentUrl(src) && attachmentUrlId(src) === null) {
    return <code className="markdown-image-invalid">![{alt ?? ""}]({src})</code>;
  }

  function retryNow() {
    if (isAttachment) {
      setNonce((current) => current + 1);
      return;
    }
    if (plainTimerRef.current !== null) {
      window.clearTimeout(plainTimerRef.current);
      plainTimerRef.current = null;
    }
    setPlainAttempt(0);
    setPlainFailed(false);
    setFetchFallback(true);
    setFallbackNonce((current) => current + 1);
  }

  function handlePlainError() {
    // First failure: prefer the fetch loader over more <img> retries — the
    // request itself is what fails in the desktop webview.
    if (!fetchFallback && typeof normalizedSrc === "string" && isSameOriginUrl(normalizedSrc)) {
      setFetchFallback(true);
      return;
    }
    if (plainAttempt >= IMAGE_RETRY_DELAYS_MS.length) {
      setPlainFailed(true);
      return;
    }
    const delay = IMAGE_RETRY_DELAYS_MS[plainAttempt];
    plainTimerRef.current = window.setTimeout(() => {
      plainTimerRef.current = null;
      setPlainAttempt((current) => current + 1);
    }, delay);
  }

  if (isAttachment) {
    if (attachment.blobUrl) {
      return <img {...props} src={attachment.blobUrl} alt={alt ?? ""} />;
    }    if (attachment.failed) {
      const reason = attachment.failureStatus !== null
        ? `(HTTP ${attachment.failureStatus})`
        : `${text("（网络未连通）", "(network unreachable)")}${attachment.failureMessage ? ` ${attachment.failureMessage}` : ""}`;
      return (
        <span className="markdown-image-broken">
          <LinearIcon name="alert" />
          <span>{text("图片加载失败", "Image failed to load")}{reason}</span>
          <button type="button" onClick={retryNow}>
            {text("重试", "Retry")}
          </button>
        </span>
      );
    }
    return (
      <span className="markdown-image-loading">
        {text("图片加载中…", "Loading image…")}
      </span>
    );
  }

  if (fetchFallback && fallback.blobUrl) {
    return <img {...props} src={fallback.blobUrl} alt={alt ?? ""} />;
  }

  if (fetchFallback && fallback.failed) {
    const reason = fallback.failureStatus !== null
      ? `(HTTP ${fallback.failureStatus})`
      : `${text("（网络未连通）", "(network unreachable)")}${fallback.failureMessage ? ` ${fallback.failureMessage}` : ""}`;
    return (
      <span className="markdown-image-broken">
        <LinearIcon name="alert" />
        <span>{text("图片加载失败", "Image failed to load")}{reason}</span>
        <button type="button" onClick={retryNow}>
          {text("重试", "Retry")}
        </button>
      </span>
    );
  }

  if (fetchFallback || plainFailed || !src) {
    return (
      <span className="markdown-image-broken">
        <LinearIcon name="alert" />
        <span>{text("图片加载失败", "Image failed to load")}</span>
        <button type="button" onClick={retryNow}>
          {text("重试", "Retry")}
        </button>
      </span>
    );
  }

  // Remounting the element re-issues the request for the same clean URL;
  // mutating state alone would keep the identical src and never reload.
  return <img {...props} key={plainAttempt} src={src} alt={alt ?? ""} onError={handlePlainError} />;
}

// Click-to-view lightbox for image attachments. Reuses the same
// fetch-then-blob loader as inline images so it behaves identically in the
// desktop webview; Esc, the backdrop, or the close button dismiss it, and
// ←/→ step through the task's image attachments.
function AttachmentImageViewer({
  attachments,
  index,
  onNavigate,
  onClose,
  onDelete,
}: {
  attachments: Attachment[];
  index: number;
  onNavigate: (nextIndex: number) => void;
  onClose: () => void;
  onDelete: (attachment: Attachment) => void;
}) {
  const { text } = useTaskboardI18n();
  const attachment = attachments[index];
  const image = useAttachmentImage(attachmentContentUrl(attachment), 0);

  useEffect(() => {
    // Capture phase + stopPropagation: without this, the App-level Escape
    // handler (closes the whole task detail) fires for the same event and
    // ESC would exit both the viewer and the detail pane (issue -103).
    const handleKey = (event: Event) => {
      const key = (event as globalThis.KeyboardEvent).key;
      if (key === "Escape") {
        event.stopPropagation();
        onClose();
      } else if (key === "ArrowLeft" && index > 0) {
        event.stopPropagation();
        onNavigate(index - 1);
      } else if (key === "ArrowRight" && index < attachments.length - 1) {
        event.stopPropagation();
        onNavigate(index + 1);
      }
    };
    window.addEventListener("keydown", handleKey, true);
    return () => window.removeEventListener("keydown", handleKey, true);
  }, [onClose, onNavigate, index, attachments.length]);

  return (
    <div className="attachment-viewer-backdrop" role="dialog" aria-modal="true" aria-label={attachment.filename} onClick={onClose}>
      <figure className="attachment-viewer" onClick={(event) => event.stopPropagation()}>
        <figcaption className="attachment-viewer-caption">
          {attachments.length > 1 && (
            <button
              type="button"
              className="attachment-viewer-nav"
              aria-label={text("上一张", "Previous image")}
              title={text("上一张（←）", "Previous (←)")}
              disabled={index === 0}
              onClick={() => onNavigate(index - 1)}
            >
              <LinearIcon name="chevronLeft" />
            </button>
          )}
          <strong>{attachment.filename}</strong>
          {attachments.length > 1 && (
            <span className="attachment-viewer-count">{index + 1} / {attachments.length}</span>
          )}
          {attachments.length > 1 && (
            <button
              type="button"
              className="attachment-viewer-nav"
              aria-label={text("下一张", "Next image")}
              title={text("下一张（→）", "Next (→)")}
              disabled={index === attachments.length - 1}
              onClick={() => onNavigate(index + 1)}
            >
              <LinearIcon name="chevronRight" />
            </button>
          )}
          <span>{fileSize(attachment.size)}</span>
          <a
            href={attachmentDownloadUrl(attachment)}
            download={attachment.filename}
            aria-label={text("下载附件", "Download attachment")}
            title={text("下载附件", "Download attachment")}
          >
            <LinearIcon name="openExternal" />
          </a>
          <button
            type="button"
            aria-label={text(`删除 ${attachment.filename}`, `Delete ${attachment.filename}`)}
            title={text("删除附件", "Delete attachment")}
            onClick={() => onDelete(attachment)}
          >
            <LinearIcon name="trash" />
          </button>
          <button type="button" aria-label={text("关闭", "Close")} title={text("关闭", "Close")} onClick={onClose}>
            <LinearIcon name="close" />
          </button>
        </figcaption>
        {image.blobUrl ? (
          <img src={image.blobUrl} alt={attachment.filename} />
        ) : image.failed ? (
          <span className="markdown-image-broken">
            <LinearIcon name="alert" />
            <span>
              {text("图片加载失败", "Image failed to load")}
              {image.failureStatus !== null ? `(HTTP ${image.failureStatus})` : text("（网络未连通）", "(network unreachable)")}
            </span>
          </span>
        ) : (
          <span className="markdown-image-loading">{text("图片加载中…", "Loading image…")}</span>
        )}
      </figure>
    </div>
  );
}

// Keep renderer identities stable so composer edits preserve loaded images.
const markdownComponents: Components = {
  a: ({ node: _node, ...props }) => <a {...props} target="_blank" rel="noreferrer" />,
  img: ({ node: _node, ...props }) => <MarkdownImage {...props} />,
};

function DescriptionDocument({ value }: { value: string }) {
  return (
    <div className="issue-description-document">
      <ReactMarkdown
        remarkPlugins={[remarkGfm]}
        // Validate the persisted Markdown URL before resolving attachments to
        // the desktop's dsh-app: origin, which defaultUrlTransform rejects.
        urlTransform={(url) => resolvePersistedAttachmentUrl(defaultUrlTransform(url))}
        components={markdownComponents}
      >
        {value}
      </ReactMarkdown>
    </div>
  );
}

function ConversationLink({
  threadId,
  onOpen,
}: {
  threadId: string;
  onOpen: (threadId: string) => void;
}) {
  const { text } = useTaskboardI18n();
  return (
    <button
      className="issue-conversation-link"
      type="button"
      title={text(`查看对话 ${threadId}`, `View conversation ${threadId}`)}
      onClick={() => onOpen(threadId)}
    >
      <TaskboardIcon name="conversation" />
      <strong>{text("查看对话", "View conversation")}</strong>
      <span className="conversation-divider" aria-hidden="true" />
      <span className="conversation-thread-id">{threadId}</span>
    </button>
  );
}

export function TaskDetail({
  task,
  tasks,
  currentUser,
  availableLabels,
  workflows,
  developmentScan,
  developmentScanLoading,
  commentsRevision,
  attachmentsRevision,
  onUpdate,
  onOpenTask,
  onAddRelation,
  onRemoveRelation,
  onOpenThread,
  onOpenInThread,
  onCopy,
  openingThread,
  onError,
  onAnnounce,
  onClose,
  onAccepted,
  propertiesCollapsed,
  onSetPropertiesCollapsed,
}: TaskDetailProps) {
  const { language, locale, text } = useTaskboardI18n();
  // 折叠断点仍在此跟踪：容器拖宽时属性栏自动展开（状态本体在宿主）。
  // The breakpoint is tracked reactively: the host sidebar can be resized
  // at any time (拖宽侧边栏); when the container turns wide the aside reopens.
  useEffect(() => {
    const mq = window.matchMedia("(max-width: 720px)");
    const onChange = (event: MediaQueryListEvent) => {
      if (!event.matches) onSetPropertiesCollapsed(false);
    };
    mq.addEventListener("change", onChange);
    return () => mq.removeEventListener("change", onChange);
  }, []);
  // 原标题滚出视口后，顶部吸附条展示当前议题的标识与标题（滚动中也不丢失上下文）。
  const [titleScrolledOut, setTitleScrolledOut] = useState(false);
  // 离开底部较远时显示「回到底部」悬浮按钮（聊天应用习惯）。
  const [farFromBottom, setFarFromBottom] = useState(false);
  const [currentTask, setCurrentTask] = useState(task);
  const [title, setTitle] = useState(task.title);
  const [description, setDescription] = useState(task.description);
  const [descriptionSegments, setDescriptionSegments] = useState<InlineMediaSegment[]>(
    () => createInlineMediaSegments(task.description),
  );
  const [editingDescription, setEditingDescription] = useState(false);
  const [propertyMenu, setPropertyMenu] = useState<"status" | "priority" | "assignee" | "labels" | null>(null);
  const [savingProperty, setSavingProperty] = useState<string | null>(null);
  const [attachments, setAttachments] = useState<Attachment[]>([]);
  const [attachmentsLoading, setAttachmentsLoading] = useState(true);
  const [attachmentsError, setAttachmentsError] = useState<TaskDetailError | null>(null);
  const [uploadingAttachments, setUploadingAttachments] = useState(false);
  const [pendingAttachmentDelete, setPendingAttachmentDelete] = useState<Attachment | null>(null);
  const [viewedImageIndex, setViewedImageIndex] = useState<number | null>(null);
  const [deletingAttachment, setDeletingAttachment] = useState(false);
  const [comments, setComments] = useState<Comment[]>([]);
  const [taskActivities, setTaskActivities] = useState<TaskChangeActivity[]>([]);
  const [commentsLoading, setCommentsLoading] = useState(true);
  const [commentsError, setCommentsError] = useState<TaskDetailError | null>(null);
  const [commentSegments, setCommentSegments] = useState<InlineMediaSegment[]>(
    () => createInlineMediaSegments(
      taskboardStorage.getItem(`taskboard.comment-draft.${task.id}`) ?? "",
    ),
  );
  const [pendingCommentFiles, setPendingCommentFiles] = useState<File[]>([]);
  const [submitting, setSubmitting] = useState(false);
  const [dispatchBusy, setDispatchBusy] = useState(false);
  const [cancelingRound, setCancelingRound] = useState(false);
  const [dispatchStarting, setDispatchStarting] = useState(false);
  const [activeMenuId, setActiveMenuId] = useState<string | null>(null);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editingSegments, setEditingSegments] = useState<InlineMediaSegment[]>(
    () => createInlineMediaSegments(),
  );
  const [savingCommentId, setSavingCommentId] = useState<string | null>(null);
  const [pendingDelete, setPendingDelete] = useState<Comment | null>(null);
  const [deleting, setDeleting] = useState(false);
  const titleRef = useRef<HTMLTextAreaElement>(null);
  const descriptionComposerRef = useRef<InlineMediaComposerHandle>(null);
  const composerRef = useRef<InlineMediaComposerHandle>(null);
  const editingComposerRef = useRef<InlineMediaComposerHandle>(null);
  const attachmentInputRef = useRef<HTMLInputElement>(null);
  const commentAttachmentInputRef = useRef<HTMLInputElement>(null);
  const editCommentImageInputRef = useRef<HTMLInputElement>(null);
  const editingUploadedAttachmentsRef = useRef<Map<string, Attachment>>(new Map());
  const detailScrollRef = useRef<HTMLDivElement | null>(null);
  const landedTaskRef = useRef<string | null>(null);
  const draft = serializeInlineMedia(commentSegments);
  const commentInlineImages = inlineMediaImages(commentSegments);
  const editingDraft = serializeInlineMedia(editingSegments);
  const editingInlineImages = inlineMediaImages(editingSegments);
  const workflowAvailable = !currentTask.workflowId
    || workflows.some((workflow) => workflow.id === currentTask.workflowId);

  useEffect(() => {
    const taskChanged = currentTask.id !== task.id;
    setCurrentTask(task);
    if (document.activeElement !== titleRef.current) setTitle(task.title);
    if (taskChanged || !editingDescription) {
      setDescription(task.description);
      setDescriptionSegments(createInlineMediaSegments(task.description));
    }
    if (taskChanged) setEditingDescription(false);
  }, [task]);

  useEffect(() => {
    resizeTextarea(titleRef.current);
  }, [title]);

  useEffect(() => {
    if (!editingDescription) return;
    requestAnimationFrame(() => {
      descriptionComposerRef.current?.focus();
    });
  }, [editingDescription]);

  useEffect(() => {
    if (!editingId) return;
    requestAnimationFrame(() => {
      editingComposerRef.current?.focus();
    });
  }, [editingId]);

  useEffect(() => {
    const controller = new AbortController();
    setCommentsLoading(true);
    setCommentsError(null);
    void Promise.all([
      listComments(task.id, controller.signal),
      listTaskActivities(task.id, controller.signal),
    ]).then(
      ([nextComments, nextActivities]) => {
        setComments(nextComments);
        setTaskActivities(nextActivities);
        setCommentsLoading(false);
      },
      (error) => {
        if ((error as Error).name === "AbortError") return;
        setCommentsError(messageFor(error));
        setCommentsLoading(false);
      },
    );
    return () => controller.abort();
  }, [commentsRevision, task.activityKey, task.id]);

  // 轮次租约的界面投影：一轮的开始（ack）与结束（总结）都会推进
  // commentsRevision，租约状态随之刷新，「干一轮」按钮据此显示进行中（ADR-0001）。
  useEffect(() => {
    const controller = new AbortController();
    fetchDispatchState(task.id, controller.signal).then(
      (busy) => {
        if (!controller.signal.aborted) setDispatchBusy(busy);
      },
      () => {},
    );
    return () => controller.abort();
  }, [task.id, commentsRevision]);

  /**
   * Landing scroll: the timeline is append-only, so on open the newest work
   * sits at the bottom. If the latest entry is the agent's, the human hasn't
   * read it yet — land there (chat-app behavior), once per open. If the
   * latest entry is the human's own, nothing new waits — stay at the top
   * where the title and description live.
   */
  useEffect(() => {
    if (commentsLoading) return;
    if (landedTaskRef.current === task.id) return;
    landedTaskRef.current = task.id;
    const latest = comments[comments.length - 1];
    if (latest?.authorType !== "agent") return;
    requestAnimationFrame(() => {
      const scroller = detailScrollRef.current;
      if (scroller) scroller.scrollTop = scroller.scrollHeight;
    });
  }, [commentsLoading, comments, task.id]);

  // 顶部吸附条的显隐跟随真实标题是否滚出视口；回到底部按钮跟随是否离开底部。
  const updateScrollAffordances = useCallback(() => {
    const scroller = detailScrollRef.current;
    if (!scroller) return;
    const titleEl = titleRef.current;
    if (titleEl) {
      setTitleScrolledOut(titleEl.getBoundingClientRect().top < scroller.getBoundingClientRect().top);
    }
    const distanceToBottom = scroller.scrollHeight - scroller.scrollTop - scroller.clientHeight;
    setFarFromBottom(distanceToBottom > 160);
  }, []);
  useEffect(() => {
    const scroller = detailScrollRef.current;
    if (!scroller) return;
    updateScrollAffordances();
    scroller.addEventListener("scroll", updateScrollAffordances, { passive: true });
    return () => scroller.removeEventListener("scroll", updateScrollAffordances);
  }, [task.id, updateScrollAffordances]);

  useEffect(() => {
    const controller = new AbortController();
    setAttachmentsLoading(true);
    setAttachmentsError(null);
    void listAttachments(task.id, controller.signal).then(
      (nextAttachments) => {
        setAttachments(nextAttachments.filter((attachment) => !attachment.commentId));
        setAttachmentsLoading(false);
      },
      (error) => {
        if ((error as Error).name === "AbortError") return;
        setAttachmentsError(messageFor(error));
        setAttachmentsLoading(false);
      },
    );
    return () => controller.abort();
  }, [attachmentsRevision, task.id]);

  useEffect(() => {
    const key = `taskboard.comment-draft.${task.id}`;
    const text = inlineMediaText(commentSegments);
    if (text) taskboardStorage.setItem(key, text);
    else taskboardStorage.removeItem(key);
  }, [commentSegments, task.id]);

  useEffect(() => {
    function handleShortcut(event: globalThis.KeyboardEvent) {
      if (event.key.toLowerCase() !== "r" || event.metaKey || event.ctrlKey || event.altKey) return;
      const target = event.target as HTMLElement | null;
      if (target?.matches("input, textarea, select, [contenteditable='true']")) return;
      event.preventDefault();
      composerRef.current?.focus();
    }
    window.addEventListener("keydown", handleShortcut);
    return () => window.removeEventListener("keydown", handleShortcut);
  }, []);

  useEffect(() => {
    if (!activeMenuId) return;
    function closeMenu(event: PointerEvent) {
      const target = event.target as HTMLElement;
      if (!target.closest(`[data-comment-menu-root="${activeMenuId}"]`)) setActiveMenuId(null);
    }
    function closeWithEscape(event: globalThis.KeyboardEvent) {
      if (event.key === "Escape") setActiveMenuId(null);
    }
    document.addEventListener("pointerdown", closeMenu);
    window.addEventListener("keydown", closeWithEscape);
    return () => {
      document.removeEventListener("pointerdown", closeMenu);
      window.removeEventListener("keydown", closeWithEscape);
    };
  }, [activeMenuId]);

  async function saveTask(changes: Partial<TaskDraft>, property: string) {
    setSavingProperty(property);
    onError(null);
    try {
      const saved = await onUpdate(currentTask, changes);
      setCurrentTask(saved);
      setTitle(saved.title);
      setDescription(saved.description);
      onAnnounce(`${saved.identifier} 已更新。`);
      return saved;
    } catch (error) {
      onError(issueMessageFor(error));
      setTitle(currentTask.title);
      setDescription(currentTask.description);
      return null;
    } finally {
      setSavingProperty(null);
    }
  }

  /**
   * The acceptance gate, as one gesture: the human's own message plus the
   * status flip. Status lands first — `done` is outside the dispatch gate, so
   * the acceptance comment can never be mistaken for a "keep going" order —
   * then the acceptance message is posted in the user's own voice, so the
   * timeline reads: they accepted, here is when, in their words.
   */
  async function acceptTask() {
    const saved = await saveTask({ status: "done" }, "status");
    if (!saved) return;
    try {
      const comment = await createComment(saved.id, text("确认完成", "Accepted"));
      setComments((current) => [...current, comment]);
      onAnnounce(text(`${saved.identifier} 已验收。`, `${saved.identifier} accepted.`));
    } catch (error) {
      setCommentsError(messageFor(error));
    }
    // 状态已落盘：交给宿主播放落卡动画并退出详情，回到列表看卡片落进完成列。
    onAccepted?.(saved.id);
  }

  async function applyRelationMutation(
    mutation: () => Promise<RelationMutationResult>,
  ): Promise<RelationMutationResult> {
    onError(null);
    try {
      const result = await mutation();
      const nextCurrent = result.task.id === currentTask.id
        ? result.task
        : result.relatedTask.id === currentTask.id
          ? result.relatedTask
          : null;
      if (nextCurrent) setCurrentTask(nextCurrent);
      return result;
    } catch (error) {
      onError(issueMessageFor(error));
      throw error;
    }
  }

  function handleTitleKeyDown(event: KeyboardEvent<HTMLTextAreaElement>) {
    if (event.key === "Enter" && !event.shiftKey) {
      event.preventDefault();
      event.currentTarget.blur();
    }
    if (event.key === "Escape") {
      setTitle(currentTask.title);
      event.currentTarget.blur();
    }
  }

  async function saveTitle() {
    const normalized = title.trim();
    if (!normalized) {
      setTitle(currentTask.title);
      onError(["议题标题不能为空。", "Issue title cannot be empty."]);
      return;
    }
    if (normalized === currentTask.title) {
      setTitle(normalized);
      return;
    }
    await saveTask({ title: normalized }, "title");
  }

  async function saveDescription() {
    if (savingProperty === "description") return;
    const draftDescription = serializeInlineMedia(descriptionSegments).trim();
    const inlineImages = inlineMediaImages(descriptionSegments);
    if (draftDescription === currentTask.description && inlineImages.length === 0) {
      setEditingDescription(false);
      return;
    }

    setSavingProperty("description");
    onError(null);
    try {
      const uploaded = await Promise.all(
        inlineImages.map((image) => uploadAttachment(currentTask.id, image.file)),
      );
      const resolvedDescription = resolveInlineMediaMarkdown(
        draftDescription,
        inlineImages,
        uploaded,
      ).trim();
      const saved = await onUpdate(currentTask, { description: resolvedDescription }).catch((error) => {
        onError(issueMessageFor(error));
        return null;
      });
      if (!saved) return;
      setCurrentTask(saved);
      setDescription(saved.description);
      setDescriptionSegments(createInlineMediaSegments(saved.description));
      setAttachments((current) => [
        ...current,
        ...uploaded.filter((attachment) => !current.some((item) => item.id === attachment.id)),
      ]);
      setEditingDescription(false);
    } catch (error) {
      onError(messageFor(error));
    } finally {
      setSavingProperty(null);
    }
  }

  async function submitComment() {
    const body = draft.trim();
    if ((!body && pendingCommentFiles.length === 0 && commentInlineImages.length === 0) || submitting) return;
    setSubmitting(true);
    setCommentsError(null);
    try {
      const comment = await createComment(task.id, body);
      const [results, inlineAttachments] = await Promise.all([
        Promise.allSettled(
          pendingCommentFiles.map((file) => uploadCommentAttachment(comment.id, file)),
        ),
        Promise.all(
          commentInlineImages.map((image) => uploadCommentAttachment(comment.id, image.file)),
        ),
      ]);
      const uploaded = results.flatMap((result) => result.status === "fulfilled" ? [result.value] : []);
      const nextComment = commentInlineImages.length > 0
        ? await updateComment(
            comment,
            resolveInlineMediaMarkdown(body, commentInlineImages, inlineAttachments),
          )
        : { ...comment, attachments: [...comment.attachments, ...uploaded] };
      setComments((current) => [...current, nextComment]);
      // 同步清掉草稿存储：成功路径紧接着 onClose() 卸载本组件，挂载在
      // commentSegments 上的草稿落盘 effect 不会再执行，仅 setState 清空
      // 会把已发送的评论留在 localStorage，下次打开被当成草稿回填。
      taskboardStorage.removeItem(`taskboard.comment-draft.${task.id}`);
      setCommentSegments(createInlineMediaSegments());
      setPendingCommentFiles([]);
      if (commentAttachmentInputRef.current) commentAttachmentInputRef.current.value = "";
      const failed = results.length - uploaded.length;
      if (failed > 0) setCommentsError([
        `评论已发布，但有 ${failed} 个附件上传失败。`,
        `The comment was posted, but ${failed} attachments failed to upload.`,
      ]);
      else {
        onAnnounce(
          uploaded.length + inlineAttachments.length > 0
            ? "评论和附件已发布。"
            : "评论已发布。",
        );
        // 评论发布成功后直接退回列表（议题 09582F74F86A-70）；有失败时留在详情展示错误。
        onClose();
        return;
      }
      requestAnimationFrame(() => composerRef.current?.focus());
    } catch (error) {
      setCommentsError(messageFor(error));
    } finally {
      setSubmitting(false);
    }
  }

  /**
   * 干一轮：零输入、全状态的显式派发（ADR-0001）。同一事件管线承接待人工
   * 状态下的评论派发，按钮只是它的不打字版；忙碌（409）视为已在进行中。
   */
  async function runARound() {
    if (dispatchBusy || dispatchStarting || submitting) return;
    setDispatchStarting(true);
    setCommentsError(null);
    try {
      await dispatchIssue(task.id);
      setDispatchBusy(true);
      onAnnounce(text("已派发一轮，Agent 开始推进这个议题。", "Dispatched. The agent is on this issue."));
    } catch (error) {
      if (error instanceof ApiError && error.code === "DISPATCH_BUSY") {
        setDispatchBusy(true);
      } else {
        setCommentsError(messageFor(error));
      }
    } finally {
      setDispatchStarting(false);
    }
  }

  /**
   * 取消正在跑的那一轮。轮次在插件进程里跑，服务端把请求转成事件、
   * 由宿主停掉那个会话；租约由轮次自己收尾时释放，所以这里只等它转过去。
   */
  async function cancelRound() {
    if (cancelingRound) return;
    setCancelingRound(true);
    setCommentsError(null);
    try {
      await cancelIssueRound(task.id);
      setDispatchBusy(false);
      onAnnounce(text("已请求取消这一轮。", "Asked to cancel this round."));
    } catch (error) {
      if (error instanceof ApiError && error.code === "NOT_RUNNING") {
        // 轮次刚好自己结束了：这不是错误，界面跟着回正就行。
        setDispatchBusy(false);
      } else {
        setCommentsError(messageFor(error));
      }
    } finally {
      setCancelingRound(false);
    }
  }

  /**
   * Post a plain-text comment. The question card's answer buttons use this:
   * picking an answer IS writing that comment, so the same server path runs
   * (and, on a waiting issue, the same instant handoff to the agent).
   */
  async function postPlainComment(body: string) {
    const trimmed = body.trim();
    if (trimmed === "" || submitting) return;
    setSubmitting(true);
    setCommentsError(null);
    try {
      const comment = await createComment(task.id, trimmed);
      setComments((current) => [...current, comment]);
      onAnnounce(text("已回答。", "Answered."));
    } catch (error) {
      setCommentsError(messageFor(error));
    } finally {
      setSubmitting(false);
    }
  }

  function stageCommentFiles(files: FileList | File[]) {
    const selected = Array.from(files);
    const oversized = selected.find((file) => file.size > MAX_ATTACHMENT_SIZE);
    if (oversized) {
      setCommentsError([
        `“${oversized.name}” 超过 25 MB，无法上传。`,
        `“${oversized.name}” is larger than 25 MB and cannot be uploaded.`,
      ]);
      if (commentAttachmentInputRef.current) commentAttachmentInputRef.current.value = "";
      return;
    }
    setCommentsError(null);
    setPendingCommentFiles((current) => {
      const existing = new Set(current.map(fileKey));
      return [...current, ...selected.filter((file) => !existing.has(fileKey(file)))];
    });
  }

  function handleSubmitShortcut(event: KeyboardEvent<HTMLTextAreaElement>) {
    if (event.key === "Enter" && (event.metaKey || event.ctrlKey)) {
      event.preventDefault();
      void submitComment();
    }
  }

  function beginEdit(comment: Comment) {
    if (savingCommentId !== null) return;
    editingUploadedAttachmentsRef.current.clear();
    setEditingId(comment.id);
    setEditingSegments(createInlineMediaSegments(comment.body));
    setActiveMenuId(null);
  }

  function endCommentEdit() {
    setEditingId(null);
    editingUploadedAttachmentsRef.current.clear();
  }

  async function saveComment(comment: Comment) {
    const body = editingDraft.trim();
    if (!body || (body === comment.body && editingInlineImages.length === 0)) {
      if (body === comment.body) endCommentEdit();
      return;
    }
    setSavingCommentId(comment.id);
    setCommentsError(null);
    try {
      const uploaded: Attachment[] = [];
      for (const image of editingInlineImages) {
        let attachment = editingUploadedAttachmentsRef.current.get(image.id);
        if (!attachment) {
          attachment = await uploadCommentAttachment(comment.id, image.file);
          editingUploadedAttachmentsRef.current.set(image.id, attachment);
        }
        uploaded.push(attachment);
      }
      const updated = await updateComment(
        comment,
        resolveInlineMediaMarkdown(body, editingInlineImages, uploaded).trim(),
      );
      setComments((current) => current.map((item) => item.id === updated.id ? updated : item));
      endCommentEdit();
      onAnnounce("评论已更新。");
    } catch (error) {
      setCommentsError(messageFor(error));
    } finally {
      setSavingCommentId(null);
    }
  }

  async function confirmDelete() {
    if (!pendingDelete || deleting) return;
    setDeleting(true);
    setCommentsError(null);
    try {
      await deleteComment(pendingDelete);
      setComments((current) => current.filter((comment) => comment.id !== pendingDelete.id));
      setPendingDelete(null);
      onAnnounce("评论已删除。");
    } catch (error) {
      setCommentsError(messageFor(error));
    } finally {
      setDeleting(false);
    }
  }

  async function uploadFiles(files: FileList) {
    const selected = Array.from(files);
    if (selected.length === 0 || uploadingAttachments) return;
    let uploaded = 0;
    const oversized = selected.find((file) => file.size > MAX_ATTACHMENT_SIZE);
    if (oversized) {
      setAttachmentsError([
        `“${oversized.name}” 超过 25 MB，无法上传。`,
        `“${oversized.name}” is larger than 25 MB and cannot be uploaded.`,
      ]);
      if (attachmentInputRef.current) attachmentInputRef.current.value = "";
      return;
    }

    setUploadingAttachments(true);
    setAttachmentsError(null);
    try {
      for (const file of selected) {
        const attachment = await uploadAttachment(task.id, file);
        setAttachments((current) => current.some((item) => item.id === attachment.id)
          ? current
          : [...current, attachment]);
        uploaded += 1;
      }
      onAnnounce(uploaded === 1 ? "附件已上传。" : `${uploaded} 个附件已上传。`);
    } catch (error) {
      setAttachmentsError(messageFor(error));
    } finally {
      setUploadingAttachments(false);
      if (attachmentInputRef.current) attachmentInputRef.current.value = "";
    }
  }

  async function confirmAttachmentDelete() {
    if (!pendingAttachmentDelete || deletingAttachment) return;
    setDeletingAttachment(true);
    setAttachmentsError(null);
    try {
      await deleteAttachment(pendingAttachmentDelete);
      setAttachments((current) => current.filter((attachment) => attachment.id !== pendingAttachmentDelete.id));
      setComments((current) => current.map((comment) => ({
        ...comment,
        attachments: comment.attachments.filter((attachment) => attachment.id !== pendingAttachmentDelete.id),
      })));
      setPendingAttachmentDelete(null);
      onAnnounce("附件已删除。");
    } catch (error) {
      setAttachmentsError(messageFor(error));
    } finally {
      setDeletingAttachment(false);
    }
  }

  function handleAttachmentDownload(event: MouseEvent<HTMLAnchorElement>, attachment: Attachment) {
    event.preventDefault();
    setAttachmentsError(null);
    void downloadAttachmentFile(attachment).catch((error) => {
      setAttachmentsError(messageFor(error));
    });
  }

  const developmentOptions = [...developmentScan.contexts];
  if (
    currentTask.developmentContext
    && !developmentOptions.some((context) => contextValue(context) === contextValue(currentTask.developmentContext))
  ) {
    developmentOptions.unshift(currentTask.developmentContext);
  }
  const assigneeOptions = [currentTask.assignee, currentUser, CODEX_AGENT_ACTOR]
    .filter((actor, index, actors) => (
      actors.findIndex((candidate) => actorKey(candidate) === actorKey(actor)) === index
    ));
  const visibleTaskAttachments = attachments.filter(
    (attachment) => !markdownIncludesAttachment(description, attachment),
  );
  const imageAttachments = visibleTaskAttachments.filter((a) => a.contentType.startsWith("image/"));
  /** Newest comment timestamp: a question card older than it is already answered. */
  const latestCommentAt = comments.reduce<string | null>(
    (latest, comment) => (latest === null || comment.createdAt > latest ? comment.createdAt : latest),
    null,
  );
  /**
   * One deliverable, not three log lines: a status flip that rides on a
   * comment from the same actor within two minutes is folded into that
   * comment's entry instead of showing up as its own card. The fold is
   * direction-agnostic — the agent comments first and flips after, the
   * accept button flips first and speaks after; both read as one card.
   */
  const foldedChanges = new Map<string, Array<{ id: string; after: unknown }>>();
  const timelineItems = [
    ...taskActivities.flatMap((activity) => activity.changes.map((change, index) => ({
      kind: "change" as const,
      id: `${activity.id}-${index}`,
      createdAt: activity.createdAt,
      activity,
      change,
    }))),
    ...comments.map((comment) => ({
      kind: "comment" as const,
      id: comment.id,
      createdAt: comment.createdAt,
      comment,
    })),
  ].sort((left, right) => (
    left.createdAt.localeCompare(right.createdAt) || left.id.localeCompare(right.id)
  ));
  type TimelineItem = (typeof timelineItems)[number];
  const foldsInto = (item: Extract<TimelineItem, { kind: "change" }>, comment: Extract<TimelineItem, { kind: "comment" }>["comment"]) => (
    item.activity.actorName === comment.authorName
    && (() => {
      const gap = Date.parse(item.createdAt) - Date.parse(comment.createdAt);
      return Number.isFinite(gap) && Math.abs(gap) <= 120_000;
    })()
  );
  const activityTimeline = timelineItems.filter((item, index) => {
    if (item.kind !== "change" || item.change.field !== "status") return true;
    // Fold forward: the flip follows the comment (agent flow).
    const previous = timelineItems[index - 1];
    if (previous?.kind === "comment" && foldsInto(item, previous.comment)) {
      const bucket = foldedChanges.get(previous.comment.id) ?? [];
      bucket.push({ id: item.id, after: item.change.after });
      foldedChanges.set(previous.comment.id, bucket);
      return false;
    }
    // Fold backward: the flip precedes the comment (accept flow — status
    // must land first so the comment can't trip the dispatch gate).
    const next = timelineItems[index + 1];
    if (next?.kind === "comment" && foldsInto(item, next.comment)) {
      const bucket = foldedChanges.get(next.comment.id) ?? [];
      bucket.push({ id: item.id, after: item.change.after });
      foldedChanges.set(next.comment.id, bucket);
      return false;
    }
    return true;
  });

  return (
    <section
      className="issue-detail"
      aria-label={text(`${task.identifier} 议题详情`, `${task.identifier} issue details`)}
    >
      <div className="issue-detail-scroll" ref={detailScrollRef}>
        <div
          className={`issue-sticky-title${titleScrolledOut ? " visible" : ""}`}
          aria-hidden={!titleScrolledOut}
          onClick={() => {
            const scroller = detailScrollRef.current;
            if (scroller) scroller.scrollTo({ top: 0, behavior: "smooth" });
          }}
        >
          <div className="issue-sticky-title-inner">
            <span className="issue-sticky-title-text">{title || task.title}</span>
          </div>
        </div>
        <div className={`issue-detail-layout${propertiesCollapsed ? " properties-collapsed" : ""}`}>
          <div className="issue-detail-main">
            <article className="issue-editor" aria-label={text("议题内容", "Issue content")}>
              <div className="issue-editor-content">
                <textarea
                  ref={titleRef}
                  className="issue-title-input"
                  rows={1}
                  value={title}
                  aria-label={text("议题标题", "Issue title")}
                  disabled={savingProperty === "title"}
                  onChange={(event) => {
                    setTitle(event.target.value.replace(/\n/g, ""));
                    resizeTextarea(event.currentTarget);
                  }}
                  onKeyDown={handleTitleKeyDown}
                  onBlur={() => void saveTitle()}
                />
                <IssueParentLink
                  task={currentTask}
                  tasks={tasks}
                  onOpenTask={onOpenTask}
                  onAddRelation={(anchor, type, relatedTaskId) => applyRelationMutation(
                    () => onAddRelation(anchor, type, relatedTaskId),
                  )}
                  onRemoveRelation={(anchor, type, relatedTaskId) => applyRelationMutation(
                    () => onRemoveRelation(anchor, type, relatedTaskId),
                  )}
                />
                {editingDescription ? (
                  <div
                    className="issue-description-composer"
                    onBlur={(event) => {
                      if (event.currentTarget.contains(event.relatedTarget as Node | null)) return;
                      void saveDescription();
                    }}
                  >
                    <InlineMediaComposer
                      ref={descriptionComposerRef}
                      segments={descriptionSegments}
                      placeholder={text("添加描述…", "Add description…")}
                      ariaLabel={text("议题描述", "Issue description")}
                      disabled={savingProperty === "description"}
                      onChange={setDescriptionSegments}
                      onError={onError}
                      onKeyDown={(event) => {
                        if (event.key === "Escape") {
                          event.preventDefault();
                          setDescriptionSegments(createInlineMediaSegments(currentTask.description));
                          setEditingDescription(false);
                        }
                      }}
                    />
                  </div>
                ) : (
                  <div
                    className={`issue-description-read${description ? "" : " empty"}`}
                    role="button"
                    tabIndex={0}
                    aria-label={text("编辑议题描述", "Edit issue description")}
                    onClick={() => {
                      if (window.getSelection()?.isCollapsed === false) return;
                      setDescriptionSegments(createInlineMediaSegments(description));
                      setEditingDescription(true);
                    }}
                    onKeyDown={(event) => {
                      if (event.key === "Enter" || event.key === " ") {
                        event.preventDefault();
                        setDescriptionSegments(createInlineMediaSegments(description));
                        setEditingDescription(true);
                      }
                    }}
                  >
                    {description
                      ? <DescriptionDocument value={description} />
                      : text("添加描述…", "Add description…")}
                  </div>
                )}
                {currentTask.threadId && (
                  <div
                    className="issue-conversation-list"
                    aria-label={text("处理此议题的对话", "Conversations for this issue")}
                  >
                    <ConversationLink threadId={currentTask.threadId} onOpen={onOpenThread} />
                  </div>
                )}
              </div>
            </article>

            <IssueSubIssues
              task={currentTask}
              tasks={tasks}
              onOpenTask={onOpenTask}
              onAddRelation={(anchor, type, relatedTaskId) => applyRelationMutation(
                () => onAddRelation(anchor, type, relatedTaskId),
              )}
              onRemoveRelation={(anchor, type, relatedTaskId) => applyRelationMutation(
                () => onRemoveRelation(anchor, type, relatedTaskId),
              )}
            />

            {(visibleTaskAttachments.length > 0 || attachmentsLoading || attachmentsError) && (
            <section className="issue-attachments" aria-labelledby="attachments-heading">
              <header className="attachments-heading">
                <div>
                  <h2 id="attachments-heading">{text("附件", "Attachments")}</h2>
                  <span>{visibleTaskAttachments.length}</span>
                </div>
                <button
                  className="attachment-add-button"
                  type="button"
                  disabled={uploadingAttachments}
                  onClick={() => attachmentInputRef.current?.click()}
                >
                  <LinearIcon name="attachment" />
                  {uploadingAttachments
                    ? text("上传中…", "Uploading…")
                    : text("添加附件", "Add attachment")}
                </button>
              </header>

              {attachmentsLoading ? (
                <div className="attachments-loading" aria-label={text("正在加载附件", "Loading attachments")} aria-busy="true"><i /><i /></div>
              ) : visibleTaskAttachments.length > 0 ? (
                (() => {
                  const fileAttachments = visibleTaskAttachments.filter((a) => !a.contentType.startsWith("image/"));
                  return (
                    <>
                      {imageAttachments.length > 0 && (
                        <ul className="attachment-thumb-strip" aria-label={text("图片附件", "Image attachments")}>
                          {imageAttachments.map((attachment) => (
                            <li key={attachment.id}>
                              <button
                                type="button"
                                className="attachment-thumb-button"
                                title={text(`查看 ${attachment.filename}`, `View ${attachment.filename}`)}
                                aria-label={text(`查看 ${attachment.filename}`, `View ${attachment.filename}`)}
                                onClick={() => setViewedImageIndex(imageAttachments.findIndex((a) => a.id === attachment.id))}
                              >
                                <AttachmentThumbnail attachment={attachment} />
                              </button>
                            </li>
                          ))}
                        </ul>
                      )}
                      {fileAttachments.length > 0 && (
                        <ul className="attachment-list">
                          {fileAttachments.map((attachment) => (
                            <li key={attachment.id}>
                              <a
                                className="attachment-link"
                                href={attachmentDownloadUrl(attachment)}
                                download={attachment.filename}
                                title={text(`下载 ${attachment.filename}`, `Download ${attachment.filename}`)}
                                onClick={(event) => handleAttachmentDownload(event, attachment)}
                              >
                                <span className="attachment-file-icon" aria-hidden="true">
                                  <LinearIcon name="file" />
                                </span>
                                <span className="attachment-copy">
                                  <strong>{attachment.filename}</strong>
                                  <span>{fileSize(attachment.size)} · {relativeTime(attachment.createdAt, locale)}</span>
                                </span>
                              </a>
                              <div className="attachment-actions">
                                <a
                                  href={attachmentDownloadUrl(attachment)}
                                  download={attachment.filename}
                                  aria-label={text(`下载 ${attachment.filename}`, `Download ${attachment.filename}`)}
                                  title={text("下载附件", "Download attachment")}
                                  onClick={(event) => handleAttachmentDownload(event, attachment)}
                                >
                                  <LinearIcon name="openExternal" />
                                </a>
                                <button
                                  type="button"
                                  aria-label={text(`删除 ${attachment.filename}`, `Delete ${attachment.filename}`)}
                                  title={text("删除附件", "Delete attachment")}
                                  onClick={() => setPendingAttachmentDelete(attachment)}
                                >
                                  <LinearIcon name="trash" />
                                </button>
                              </div>
                            </li>
                          ))}
                        </ul>
                      )}
                    </>
                  );
                })()
              ) : null}
              {attachmentsError && (
                <div className="attachments-error" role="alert">
                  {typeof attachmentsError === "string"
                    ? attachmentsError
                    : text(attachmentsError[0], attachmentsError[1])}
                </div>
              )}
            </section>
            )}

            <section className="activity-section" aria-labelledby="activity-heading">
              <header className="activity-heading">
                <h2 id="activity-heading">{text("活动", "Activity")}</h2>
                <span>{activityTimeline.length}</span>
              </header>

              <div className="activity-stream">
                <div className={`activity-entry activity-created is-${currentTask.creatorType}`}>
                  <span className="activity-rail-icon activity-creator-icon" aria-hidden="true">
                    <ActorAvatar
                      className="comment-avatar"
                      actor={{
                        type: currentTask.creatorType,
                        id: currentTask.creatorId,
                        name: currentTask.creatorName,
                        avatarUrl: currentTask.creatorAvatarUrl,
                      }}
                    />
                  </span>
                  <p>
                    <strong>{currentTask.creatorName}</strong>
                    {text(" 创建了此议题", " created this issue")}
                    <time title={exactTime(currentTask.createdAt, locale)}>{relativeTime(currentTask.createdAt, locale)}</time>
                  </p>
                </div>

                {commentsLoading ? (
                  <div className="comments-loading" aria-label={text("正在加载活动", "Loading activity")} aria-busy="true"><i /><i /></div>
                ) : activityTimeline.map((item) => {
                  if (item.kind === "change") {
                    const { activity, change } = item;
                    const fieldLabels = ACTIVITY_FIELD_LABELS[change.field];
                    const fieldLabel = fieldLabels
                      ? text(fieldLabels[0], fieldLabels[1])
                      : change.field;
                    const beforeValue = activityValue(
                      change.field,
                      change.before,
                      language,
                      locale,
                      text,
                    );
                    const afterValue = activityValue(
                      change.field,
                      change.after,
                      language,
                      locale,
                      text,
                    );
                    return (
                      <article
                        className={`activity-entry activity-change is-${activity.actorType}`}
                        key={item.id}
                      >
                        <span className="activity-rail-icon" aria-hidden="true">
                          <ActivityChangeIcon
                            field={change.field}
                            before={change.before}
                            after={change.after}
                          />
                        </span>
                        <p>
                          <strong>{activity.actorName}</strong>
                          {" "}
                          {change.field === "description" ? (
                            <>{text("更新了描述", "updated the description")}</>
                          ) : change.field === "relation" && change.before === null ? (
                            <>{text("添加了 ", "added ")}<span className="activity-change-value">{afterValue}</span></>
                          ) : change.field === "relation" && change.after === null ? (
                            <>{text("移除了 ", "removed ")}<span className="activity-change-value">{beforeValue}</span></>
                          ) : language === "zh" ? (
                            <>
                              将{fieldLabel}从
                              <span className="activity-change-value">{beforeValue}</span>
                              改为
                              <span className="activity-change-value">{afterValue}</span>
                            </>
                          ) : (
                            <>
                              {`changed ${fieldLabel} from `}
                              <span className="activity-change-value">{beforeValue}</span>
                              {" to "}
                              <span className="activity-change-value">{afterValue}</span>
                            </>
                          )}
                          <time title={exactTime(activity.createdAt, locale)}>{relativeTime(activity.createdAt, locale)}</time>
                        </p>
                      </article>
                    );
                  }
                  const comment = item.comment;
                  return (
                  <article
                    className={`comment-entry is-${comment.authorType}`}
                    key={comment.id}
                    id={`comment-${comment.id}`}
                  >
                    <div className="comment-card">
                      <header className="comment-header">
                        <ActorAvatar
                          className="comment-avatar"
                          actor={{
                            type: comment.authorType,
                            id: comment.authorId,
                            name: comment.authorName,
                            avatarUrl: comment.authorAvatarUrl,
                          }}
                        />
                        <strong>{comment.authorName}</strong>
                        <span className="actor-id">@{comment.authorId}</span>
                        <time title={exactTime(comment.createdAt, locale)}>{relativeTime(comment.createdAt, locale)}</time>
                        {comment.version > 1 && (
                          <span
                            className="comment-edited"
                            title={text(
                              `编辑于 ${exactTime(comment.updatedAt, locale)}`,
                              `Edited ${exactTime(comment.updatedAt, locale)}`,
                            )}
                          >
                            {text("已编辑", "Edited")}
                          </span>
                        )}
                        {editingId !== comment.id && (
                          <div className="comment-actions" data-comment-menu-root={comment.id}>
                            <button
                              type="button"
                              className="comment-menu-trigger"
                              aria-label={text("评论操作", "Comment actions")}
                              aria-haspopup="menu"
                              aria-expanded={activeMenuId === comment.id}
                              onClick={() => setActiveMenuId((current) => current === comment.id ? null : comment.id)}
                            >
                              <LinearIcon name="more" />
                            </button>
                            {activeMenuId === comment.id && (
                              <div className="comment-action-menu" role="menu">
                                <button
                                  type="button"
                                  role="menuitem"
                                  disabled={savingCommentId !== null}
                                  onClick={() => beginEdit(comment)}
                                >
                                  <LinearIcon name="write" />
                                  {text("编辑评论", "Edit comment")}
                                </button>
                                <button
                                  type="button"
                                  role="menuitem"
                                  className="danger"
                                  onClick={() => { setPendingDelete(comment); setActiveMenuId(null); }}
                                >
                                  <LinearIcon name="trash" />
                                  {text("删除评论", "Delete comment")}
                                </button>
                              </div>
                            )}
                          </div>
                        )}
                      </header>

                      {editingId === comment.id ? (
                        <div className="comment-edit-form">
                          <InlineMediaComposer
                            ref={editingComposerRef}
                            className="comment-inline-media"
                            segments={editingSegments}
                            placeholder={text("编辑评论", "Edit comment")}
                            ariaLabel={text("编辑评论", "Edit comment")}
                            disabled={savingCommentId === comment.id}
                            onChange={setEditingSegments}
                            onError={setCommentsError}
                            onKeyDown={(event) => {
                              if (event.key === "Escape") endCommentEdit();
                              if (event.key === "Enter" && (event.metaKey || event.ctrlKey)) {
                                event.preventDefault();
                                void saveComment(comment);
                              }
                            }}
                          />
                          <div className="comment-edit-actions">
                            <button
                              className="button secondary"
                              type="button"
                              disabled={savingCommentId === comment.id}
                              onClick={() => editCommentImageInputRef.current?.click()}
                            >
                              <LinearIcon name="attachment" />
                              {text("添加图片", "Add images")}
                            </button>
                            <input
                              ref={editCommentImageInputRef}
                              type="file"
                              accept="image/*"
                              multiple
                              hidden
                              onChange={(event) => {
                                if (event.currentTarget.files) {
                                  editingComposerRef.current?.addImages(event.currentTarget.files);
                                }
                                event.currentTarget.value = "";
                              }}
                            />
                            <button
                              className="button secondary"
                              type="button"
                              disabled={savingCommentId === comment.id}
                              onClick={endCommentEdit}
                            >
                              {text("取消", "Cancel")}
                            </button>
                            <button
                              className="button primary"
                              type="button"
                              disabled={!editingDraft.trim() || savingCommentId === comment.id}
                              onClick={() => void saveComment(comment)}
                            >
                              {savingCommentId === comment.id
                                ? text("保存中…", "Saving…")
                                : text("保存", "Save")}
                            </button>
                          </div>
                        </div>
                      ) : (
                        comment.body && <div className="comment-body"><DescriptionDocument value={comment.body} /></div>
                      )}
                      <CommentOptions
                        body={comment.body}
                        stale={latestCommentAt !== null && latestCommentAt > comment.createdAt}
                        disabled={submitting}
                        onPick={(answer) => void postPlainComment(answer)}
                      />
                      {(foldedChanges.get(comment.id) ?? []).map((folded) => (
                        <p className="comment-folded-change" key={folded.id}>
                          <LinearIcon name="chevronRight" />
                          <span>
                            {text("状态", "Status")}
                            {" → "}
                            <strong>{activityValue("status", folded.after, language, locale, text)}</strong>
                          </span>
                        </p>
                      ))}
                      {comment.attachments.some(
                        (attachment) => !markdownIncludesAttachment(comment.body, attachment),
                      ) && (
                        <ul className="comment-attachment-list" aria-label={text("评论附件", "Comment attachments")}>
                          {comment.attachments
                            .filter((attachment) => !markdownIncludesAttachment(comment.body, attachment))
                            .map((attachment) => (
                              <li key={attachment.id}>
                                <a
                                  href={attachmentDownloadUrl(attachment)}
                                  download={attachment.filename}
                                  title={text(`下载 ${attachment.filename}`, `Download ${attachment.filename}`)}
                                  onClick={(event) => handleAttachmentDownload(event, attachment)}
                                >
                                  <span className="attachment-file-icon" aria-hidden="true">
                                    <LinearIcon name="file" />
                                  </span>
                                  <span><strong>{attachment.filename}</strong><small>{fileSize(attachment.size)}</small></span>
                                </a>
                                {editingId !== comment.id && (
                                  <button
                                    type="button"
                                    aria-label={text(`删除 ${attachment.filename}`, `Delete ${attachment.filename}`)}
                                    title={text("删除附件", "Delete attachment")}
                                    onClick={() => setPendingAttachmentDelete(attachment)}
                                  >
                                    <LinearIcon name="trash" />
                                  </button>
                                )}
                              </li>
                            ))}
                        </ul>
                      )}
                      {comment.threadId && (
                        <div className="comment-conversation-link">
                          <ConversationLink threadId={comment.threadId} onOpen={onOpenThread} />
                        </div>
                      )}
                    </div>
                  </article>
                  );
                })}
              </div>

              {commentsError && (
                <div className="comments-error" role="alert">
                  {typeof commentsError === "string"
                    ? commentsError
                    : text(commentsError[0], commentsError[1])}
                </div>
              )}

              {/* The gate stands at the end of the evidence chain: read the
                  issue top to bottom, and the decision waits beside the
                  composer — the same pattern as PR merge / review approval.
                  Not the top-right icon row: that shelf is for repeatable
                  utilities, not one-shot decisions. */}
              {currentTask.status === "in_review" && (
                <div className="accept-gate-banner" data-testid="accept-gate-banner">
                  <span className="accept-gate-text">
                    {text("这个议题已完成，等你确认。", "This issue is done and waiting for your acceptance.")}
                  </span>
                  <button
                    className="button primary gate-accept-button"
                    type="button"
                    disabled={savingProperty === "status"}
                    title={text("验收通过并关闭这个议题", "Accept the work and close this issue")}
                    onClick={() => void acceptTask()}
                  >
                    {text("确认完成", "Accept")}
                  </button>
                </div>
              )}

              <form className="comment-composer" onSubmit={(event) => { event.preventDefault(); void submitComment(); }}>
                <div className="composer-author">
                  <ActorAvatar
                    className="comment-avatar"
                    actor={currentUser}
                  />
                  <strong>{currentUser.name}</strong>
                  <span className="actor-id">@{currentUser.id}</span>
                </div>
                <InlineMediaComposer
                  ref={composerRef}
                  className="comment-inline-media"
                  segments={commentSegments}
                  placeholder={commentPlaceholder(currentTask.status, text)}
                  ariaLabel={text("留下评论", "Leave a comment")}
                  onChange={setCommentSegments}
                  onError={setCommentsError}
                  onKeyDown={handleSubmitShortcut}
                />
                <PendingAttachments
                  files={pendingCommentFiles}
                  disabled={submitting}
                  uploadLabel={text("发布后上传", "Upload after posting")}
                  ariaLabel={text("待上传评论附件", "Pending comment attachments")}
                  className="comment-composer-files"
                  onRemove={(index) => setPendingCommentFiles((current) => current.filter((_, itemIndex) => itemIndex !== index))}
                />
                <footer className="composer-footer">
                  <div className="composer-footer-leading">
                    <button
                      className="comment-attach-button"
                      type="button"
                      disabled={submitting}
                      aria-label={text("添加评论附件", "Add comment attachments")}
                      title={text("添加附件", "Add attachments")}
                      onClick={() => commentAttachmentInputRef.current?.click()}
                    >
                      <LinearIcon name="attachment" />
                    </button>
                    <span>{text("草稿会自动保存", "Drafts are saved automatically")}</span>
                    <input
                      ref={commentAttachmentInputRef}
                      type="file"
                      multiple
                      hidden
                      onChange={(event) => {
                        if (event.currentTarget.files) stageCommentFiles(event.currentTarget.files);
                      }}
                    />
                  </div>
                  <div>
                    <button
                      className="button"
                      type="button"
                      disabled={dispatchBusy || dispatchStarting || submitting}
                      title={text(
                        "不打字，直接让 Agent 推进这个议题（全状态可用）",
                        "Dispatch the agent on this issue without typing",
                      )}
                      onClick={() => void runARound()}
                    >
                      {dispatchBusy
                        ? text("Agent 进行中…", "Agent working…")
                        : dispatchStarting
                          ? text("派发中…", "Dispatching…")
                          : text("干一轮", "Run a round")}
                    </button>
                    {dispatchBusy && (
                      <button
                        className="button secondary"
                        type="button"
                        disabled={cancelingRound}
                        title={text(
                          "停掉正在跑的这一轮，不必等它自己超时",
                          "Stop the running round instead of waiting for it to time out",
                        )}
                        onClick={() => void cancelRound()}
                      >
                        {cancelingRound
                          ? text("取消中…", "Canceling…")
                          : text("取消本轮", "Cancel round")}
                      </button>
                    )}
                    <kbd>⌘ Enter</kbd>
                    <button
                      className="button primary"
                      type="submit"
                      disabled={(
                        !draft.trim()
                        && pendingCommentFiles.length === 0
                        && commentInlineImages.length === 0
                      ) || submitting}
                    >
                      {submitting ? text("发布中…", "Posting…") : text("评论", "Comment")}
                    </button>
                  </div>
                </footer>
              </form>
            </section>
          </div>

          {!propertiesCollapsed && (
          <aside className="issue-properties" aria-label={text("议题属性", "Issue properties")}>
            <div className="detail-primary-actions">
              <button
                className="detail-open-thread-action"
                type="button"
                disabled={openingThread}
                title={isDshThreadId(currentTask.threadId)
                  ? text("打开该任务关联的 DSH 会话，继续沟通", "Open the linked DSH session")
                  : text("新建 DSH 会话，让 AI 执行该任务", "Run this task in a new DSH session")}
                onClick={() => onOpenInThread(currentTask)}
              >
                <ActorAvatar
                  actor={isDshThreadId(currentTask.threadId) ? DSH_AGENT_ACTOR : CODEX_AGENT_ACTOR}
                  className="detail-thread-avatar"
                />
                <span>{openingThread
                  ? text("正在打开…", "Opening…")
                  : isDshThreadId(currentTask.threadId)
                    ? text("打开会话", "Open session")
                    : text("让 AI 执行", "Run with AI")}</span>
              </button>
              <button
                className="detail-copy-action"
                type="button"
                title={text(
                  `复制议题 ID ${currentTask.identifier}`,
                  `Copy issue ID ${currentTask.identifier}`,
                )}
                onClick={() => onCopy(
                  currentTask.identifier,
                  text(`${currentTask.identifier} 已复制。`, `${currentTask.identifier} copied.`),
                )}
              >
                <span className="detail-copy-action-icon" aria-hidden="true"><img src={copyIdIcon} alt="" /></span>
                <span className="detail-copy-action-label">{text("复制 ID", "Copy ID")}</span>
                <span className="detail-copy-identifier">{currentTask.identifier}</span>
              </button>
              <button
                className="detail-copy-action"
                type="button"
                onClick={() => onCopy(
                  buildIssueUrl(
                    document.baseURI,
                    currentTask.projectId,
                    currentTask.identifier,
                  ).href,
                  text("议题链接已复制。", "Issue link copied."),
                )}
              >
                <span className="detail-copy-action-icon" aria-hidden="true"><img src={copyLinkIcon} alt="" /></span>
                <span className="detail-copy-action-label">{text("复制链接", "Copy link")}</span>
              </button>
              <button
                className="detail-copy-action detail-attach-action"
                type="button"
                disabled={uploadingAttachments}
                title={text("上传附件（图片、文档等）", "Attach files (images, documents, etc.)")}
                onClick={() => attachmentInputRef.current?.click()}
              >
                <LinearIcon name="attachment" />
                <span className="detail-copy-action-label">{uploadingAttachments
                  ? text("上传中…", "Uploading…")
                  : visibleTaskAttachments.length > 0
                    ? text(`附件 ${visibleTaskAttachments.length} · 添加`, `Attachments ${visibleTaskAttachments.length} · Add`)
                    : text("添加附件", "Add attachment")}</span>
              </button>
            </div>
            <h2>{text("属性", "Properties")}</h2>
            <div className="detail-property-row">
              <span className="detail-property-label">{text("状态", "Status")}</span>
              <TaskPropertyPicker
                value={currentTask.status}
                options={TASK_STATUSES.map((status) => ({
                  value: status,
                  label: taskStatusLabel(language, status),
                  icon: <StatusIcon status={status} />,
                  className: `status-icon-${STATUS_DETAILS[status].tone}`,
                }))}
                open={propertyMenu === "status"}
                disabled={savingProperty === "status"}
                className="detail-property-picker"
                triggerClassName="detail-property-trigger"
                ariaLabel={text("状态", "Status")}
                onOpenChange={(open) => setPropertyMenu(open ? "status" : null)}
                onChange={(status) => void saveTask({ status }, "status")}
              />
              {/* The gate action renders in the main flow's accept banner,
                  not here: the properties pane is collapsible and a gate you
                  can't see is not a gate. Acceptance is still never a side
                  effect of commenting — see acceptTask. */}
            </div>
            <div className="detail-property-row">
              <span className="detail-property-label">{text("优先级", "Priority")}</span>
              <TaskPropertyPicker
                value={currentTask.priority}
                options={TASK_PRIORITIES.map((priority) => ({
                  value: priority,
                  label: taskPriorityLabel(language, priority),
                  icon: <LinearPriorityIcon priority={priority} />,
                  className: `priority-${priority}`,
                }))}
                open={propertyMenu === "priority"}
                disabled={savingProperty === "priority"}
                className="detail-property-picker"
                triggerClassName="detail-property-trigger"
                ariaLabel={text("优先级", "Priority")}
                onOpenChange={(open) => setPropertyMenu(open ? "priority" : null)}
                onChange={(priority) => void saveTask({ priority }, "priority")}
              />
            </div>
            <div className="detail-property-row assignee-property">
              <span className="detail-property-label">{text("负责人", "Assignee")}</span>
              <TaskPropertyPicker
                value={actorKey(currentTask.assignee)}
                options={assigneeOptions.map((actor) => ({
                  value: actorKey(actor),
                  label: actor.id === currentUser.id
                    ? `${actor.name}${text("（我）", " (me)")}`
                    : actor.name,
                  icon: <ActorAvatar actor={actor} className="task-property-assignee-avatar" />,
                }))}
                open={propertyMenu === "assignee"}
                disabled={savingProperty === "assignee"}
                className="detail-property-picker"
                triggerClassName="detail-property-trigger"
                ariaLabel={text("负责人", "Assignee")}
                onOpenChange={(open) => setPropertyMenu(open ? "assignee" : null)}
                onChange={(value) => {
                  const selected = assigneeOptions.find((actor) => actorKey(actor) === value);
                  const assigneeTarget = selected
                    ? assigneeTargetForActor(selected, currentUser)
                    : undefined;
                  if (assigneeTarget) void saveTask({ assigneeTarget }, "assignee");
                }}
              />
            </div>
            <div className="detail-property-row labels-property">
              <span className="detail-property-icon" aria-hidden="true">
                <LinearIcon name="label" />
              </span>
              <span className="detail-property-label">{text("标签", "Labels")}</span>
              <LabelPicker
                availableLabels={availableLabels}
                selectedLabels={currentTask.labels}
                open={propertyMenu === "labels"}
                disabled={savingProperty === "labels"}
                className="detail-label-picker"
                triggerClassName="detail-label-trigger"
                showSelectedAsChips
                placeholder={text("添加标签…", "Add labels…")}
                onOpenChange={(open) => setPropertyMenu(open ? "labels" : null)}
                onChange={(nextLabels) => void saveTask({ labels: nextLabels }, "labels")}
              />
            </div>
            <label className="detail-property-row workflow-property">
              <span className="detail-property-icon" aria-hidden="true">
                <LinearIcon name="dashboard" />
              </span>
              <span className="detail-property-label">{text("工作流", "Workflow")}</span>
              <select
                value={currentTask.workflowId ?? ""}
                disabled={savingProperty === "workflowId"}
                onChange={(event) => void saveTask({
                  workflowId: event.target.value || null,
                }, "workflowId")}
              >
                <option value="">{text("未绑定", "Not linked")}</option>
                {!workflowAvailable && currentTask.workflowId && (
                  <option value={currentTask.workflowId}>{text("当前设备未找到此流程", "Workflow not found on this device")}</option>
                )}
                {workflows.map((workflow) => (
                  <option value={workflow.id} key={workflow.id}>{workflow.name}</option>
                ))}
              </select>
            </label>
            <label className="detail-property-row development-property">
              <span className="detail-property-icon" aria-hidden="true">
                <LinearIcon name="branch" />
              </span>
              <span className="detail-property-label">{text("开发上下文", "Development context")}</span>
              <select
                value={contextValue(currentTask.developmentContext)}
                disabled={developmentScanLoading || savingProperty === "developmentContext"}
                title={currentTask.developmentContext?.type === "worktree" ? currentTask.developmentContext.path : undefined}
                onChange={(event) => void saveTask({
                  developmentContext: event.target.value ? JSON.parse(event.target.value) as DevelopmentContext : null,
                }, "developmentContext")}
              >
                <option value="">{developmentScanLoading
                  ? text("正在扫描 Git…", "Scanning Git…")
                  : text("未绑定", "Not linked")}</option>
                <optgroup label={text("代码分支", "Code branches")}>
                  {developmentOptions.filter((context) => context.type === "branch").map((context) => (
                    <option value={contextValue(context)} key={contextValue(context)}>{contextLabel(context, text)}</option>
                  ))}
                </optgroup>
                <optgroup label="Worktree">
                  {developmentOptions.filter((context) => context.type === "worktree").map((context) => (
                    <option value={contextValue(context)} key={contextValue(context)}>{contextLabel(context, text)}</option>
                  ))}
                </optgroup>
              </select>
            </label>
            <label className="detail-property-row">
              <span className="detail-property-icon" aria-hidden="true"><LinearIcon name="calendar" /></span>
              <span className="detail-property-label">{text("开始日期", "Start date")}</span>
              <input
                type="date"
                value={currentTask.startDate ?? ""}
                disabled={savingProperty === "startDate"}
                onChange={(event) => void saveTask({
                  startDate: event.target.value || null,
                }, "startDate")}
              />
            </label>
            <label className="detail-property-row">
              <span className="detail-property-icon" aria-hidden="true"><LinearIcon name="calendar" /></span>
              <span className="detail-property-label">{text("截止日期", "Due date")}</span>
              <input
                type="date"
                value={currentTask.dueDate ?? ""}
                disabled={savingProperty === "dueDate"}
                onChange={(event) => void saveTask({
                  dueDate: event.target.value || null,
                  ...(event.target.value ? {} : { recurrence: null }),
                }, "dueDate")}
              />
            </label>
            <label className="detail-property-row">
              <span className="detail-property-icon" aria-hidden="true"><LinearIcon name="recurrence" /></span>
              <span className="detail-property-label">{text("重复", "Recurrence")}</span>
              <select
                value={currentTask.recurrence?.unit ?? ""}
                disabled={!currentTask.dueDate || savingProperty === "recurrence"}
                onChange={(event) => void saveTask({
                  recurrence: event.target.value
                    ? { interval: 1, unit: event.target.value as Recurrence["unit"] }
                    : null,
                }, "recurrence")}
              >
                <option value="">{text("不重复", "Does not repeat")}</option>
                <option value="day">{text("每天", "Daily")}</option>
                <option value="week">{text("每周", "Weekly")}</option>
                <option value="month">{text("每月", "Monthly")}</option>
                <option value="year">{text("每年", "Yearly")}</option>
              </select>
            </label>
            <IssueRelationSidebar
              task={currentTask}
              tasks={tasks}
              onOpenTask={onOpenTask}
              onAddRelation={(anchor, type, relatedTaskId) => applyRelationMutation(
                () => onAddRelation(anchor, type, relatedTaskId),
              )}
              onRemoveRelation={(anchor, type, relatedTaskId) => applyRelationMutation(
                () => onRemoveRelation(anchor, type, relatedTaskId),
              )}
            />
            <div className="detail-timestamps">
              <span>{text(
                `创建于 ${exactTime(currentTask.createdAt, locale)}`,
                `Created ${exactTime(currentTask.createdAt, locale)}`,
              )}</span>
              {currentTask.updatedAt !== currentTask.createdAt && <span>{text(
                `更新于 ${exactTime(currentTask.updatedAt, locale)}`,
                `Updated ${exactTime(currentTask.updatedAt, locale)}`,
              )}</span>}
            </div>
          </aside>
          )}
        </div>
      </div>

      {pendingDelete && (
        <div className="delete-backdrop" role="presentation" onMouseDown={(event) => {
          if (event.target === event.currentTarget && !deleting) setPendingDelete(null);
        }}>
          <div className="delete-dialog" role="alertdialog" aria-modal="true" aria-labelledby="delete-comment-title">
            <h2 id="delete-comment-title">{text("删除这条评论？", "Delete this comment?")}</h2>
            <p>{text("此操作无法撤销。", "This action cannot be undone.")}</p>
            <div>
              <button className="button secondary" type="button" disabled={deleting} onClick={() => setPendingDelete(null)}>{text("取消", "Cancel")}</button>
              <button className="button danger" type="button" disabled={deleting} onClick={() => void confirmDelete()}>{deleting ? text("删除中…", "Deleting…") : text("删除评论", "Delete comment")}</button>
            </div>
          </div>
        </div>
      )}

      {pendingAttachmentDelete && (
        <div className="delete-backdrop" role="presentation" onMouseDown={(event) => {
          if (event.target === event.currentTarget && !deletingAttachment) setPendingAttachmentDelete(null);
        }}>
          <div className="delete-dialog" role="alertdialog" aria-modal="true" aria-labelledby="delete-attachment-title">
            <h2 id="delete-attachment-title">{text("删除这个附件？", "Delete this attachment?")}</h2>
            <p>{text(
              `“${pendingAttachmentDelete.filename}” 将被永久删除，此操作无法撤销。`,
              `“${pendingAttachmentDelete.filename}” will be permanently deleted. This action cannot be undone.`,
            )}</p>
            <div>
              <button className="button secondary" type="button" disabled={deletingAttachment} onClick={() => setPendingAttachmentDelete(null)}>{text("取消", "Cancel")}</button>
              <button className="button danger" type="button" disabled={deletingAttachment} onClick={() => void confirmAttachmentDelete()}>{deletingAttachment ? text("删除中…", "Deleting…") : text("删除附件", "Delete attachment")}</button>
            </div>
          </div>
        </div>
      )}
      {viewedImageIndex !== null && imageAttachments.length > 0 && (
        <AttachmentImageViewer
          attachments={imageAttachments}
          index={Math.min(viewedImageIndex, imageAttachments.length - 1)}
          onNavigate={setViewedImageIndex}
          onDelete={setPendingAttachmentDelete}
          onClose={() => setViewedImageIndex(null)}
        />
      )}
      {/* 附件上传的隐藏 input 常驻挂载：附件区块为空时不渲染，入口移到右栏。 */}
      <input
        ref={attachmentInputRef}
        type="file"
        multiple
        hidden
        onChange={(event) => {
          if (event.currentTarget.files) void uploadFiles(event.currentTarget.files);
        }}
      />
      {farFromBottom && (
        <button
          type="button"
          className="issue-scroll-bottom"
          aria-label={text("滚动到底部", "Scroll to bottom")}
          onClick={() => {
            const scroller = detailScrollRef.current;
            if (scroller) scroller.scrollTo({ top: scroller.scrollHeight, behavior: "smooth" });
          }}
        >
          <LinearIcon name="chevronDown" />
        </button>
      )}
    </section>
  );
}
