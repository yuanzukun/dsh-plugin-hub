import {
  lazy,
  Suspense,
  useCallback,
  useEffect,
  useLayoutEffect,
  useMemo,
  useRef,
  useState,
  type CSSProperties,
  type Dispatch,
  type SetStateAction,
} from "react";
import {
  isAutomationModel,
  isAutomationReasoningEffort,
  isSupportedModelEffort,
  type AutomationModel,
  type AutomationReasoningEffort,
} from "../../shared/taskboard-automation-options.mjs";
import {
  ApiError,
  acceptIssue,
  addTaskRelation,
  archiveTask as archiveTaskRequest,
  createTask as createTaskRequest,
  dispatchIssue,
  getTaskboardRevision,
  getWorkflowWorkspace,
  getTaskboardMetadata,
  getProjectAutomation,
  getClaimModels,
  isGlobalProjectId,
  listArchivedTasks,
  listDevelopmentContexts,
  listDeviceWorkspaces,
  updateProjectAutomation,
  listProjects,
  listTasks,
  moveTask as moveTaskRequest,
  removeTaskRelation,
  restoreTask as restoreTaskRequest,
  deleteArchivedTask as deleteArchivedTaskRequest,
  setCurrentUserActor,
  uploadAttachment,
  updateTask as updateTaskRequest,
  resolveTaskboardUrl,
} from "./api";
import { isDshThreadId } from "./threads";
import {
  actorForAssigneeTarget,
  assigneeTargetForActor,
} from "./actors";
import { BoardColumn, STATUS_DETAILS } from "./components/BoardColumn";
import { AiChat, type AiChatOpenThreadRequest } from "./components/AiChat";
import { DashboardView } from "./components/DashboardView";
import { HiddenColumns } from "./components/HiddenColumns";
import {
  resolveInlineMediaMarkdown,
  type PendingInlineImage,
} from "./components/InlineMediaComposer";
import { IssueListView } from "./components/IssueListView";
import { LinearIcon } from "./components/LinearIcon";
import { ProjectAutomationMenu } from "./components/ProjectAutomationMenu";
import { TaskContextMenu } from "./components/TaskContextMenu";
import { TaskDetail } from "./components/TaskDetail";
import { TaskEditor } from "./components/TaskEditor";
import { TaskFilterMenu } from "./components/TaskFilterMenu";
import { TaskboardIcon } from "./components/TaskboardIcon";
import { buildIssueUrl, readIssueIdentifier } from "./issueRoute";
import { DEFAULT_LABELS } from "./labels";
import {
  getTaskboardI18n,
  resolveTaskboardLanguage,
  TaskboardLanguageProvider,
} from "./i18n";
import { getThemeTarget, onTaskboardThemeChange, publishTheme } from "./themeTarget";
import {
  getTaskboardLocation,
  taskboardPushState,
  taskboardReplaceState,
} from "./taskboardUrl";
import {
  EMPTY_TASK_FILTERS,
  matchesTaskFilters,
  matchesTaskSearch,
  readTaskFilters,
  taskFilterCount,
  writeTaskFilters,
} from "./taskFilters";
import {
  BOARD_LANES,
  BOARD_LANE_ORDER,
  isLaneVisible,
  type BoardLane,
  type BoardLaneId,
} from "./boardColumns";
import {
  TASK_STATUSES,
  type ActorIdentity,
  type AiChatThread,
  type DevelopmentScan,
  type HostContext,
  type IssueRelationType,
  type Project,
  type Task,
  type TaskboardMetadata,
  type TaskDraft,
  type TaskStatus,
  type WorkflowOption,
} from "./types";
import {
  normalizeCodexThreadId,
  taskCardPresentation,
  type TaskCardPresentation,
  type TaskConversationItem,
} from "./taskConversations";
import {
  DEFAULT_WORKFLOW_OPTIONS,
  readLegacyWorkflowWorkspace,
  workflowOptionsFromWorkspace,
} from "./workflowStore";
// The poller stays in ESM JavaScript so its lifecycle can be tested directly with node:test.
// @ts-expect-error The module's option contract is enforced by its focused node tests.
import { createRevisionPoller, getRevisionPollingInterval } from "./revisionPolling.mjs";

type ConnectionState = "connecting" | "live" | "reconnecting";
type Theme = "light" | "dark";
type BoardView = "dashboard" | "issues" | "list" | "gantt" | "workflow";
type GanttZoom = "day" | "week" | "month";
const SHOW_WORKFLOW_BOARD_ENTRY = false;
const GANTT_ZOOM_OPTIONS: GanttZoom[] = ["day", "week", "month"];

const WorkflowBoard = lazy(() => import("./components/WorkflowBoard").then((module) => ({
  default: module.WorkflowBoard,
})));
const GanttView = lazy(() => import("./components/GanttView").then((module) => ({
  default: module.GanttView,
})));

interface EditorState {
  task: Task | null;
  status: TaskStatus;
  /** 「全局」视图下新建议题时人工选定的落点项目；普通项目视图省略。 */
  projectId?: string;
}

interface ContextMenuState {
  taskId: string;
  x: number;
  y: number;
}

interface ProjectChoice {
  id: string;
  name: string;
  issueCount: number;
  youCount: number;
  inProgressCount: number;
  openCount: number;
  inCodex: boolean;
  persisted: boolean;
}

interface UndoOperation {
  id: number;
  message: string;
  undo: () => Promise<void>;
}

interface UndoNotice {
  id: number;
  message: string;
}

/** 折叠态的列：只显示标题行与计数，点开才铺开卡片（按项目存）。 */
type LaneCollapsedByProject = Record<string, Partial<Record<BoardLaneId, boolean>>>;
/** 列的手动显隐（按项目存）；未记录的列用它的 defaultVisible。 */
type LaneVisibilityByProject = Record<string, Partial<Record<BoardLaneId, boolean>>>;
type ProjectAutomationStatus = "ACTIVE" | "PAUSED";
type AutomationQuotaState = "available" | "blocked" | "unknown" | "unavailable";
type AutomationIntervalMinutes = 5 | 10 | 15 | 30 | 60;

interface AutomationQuotaStatus {
  state: AutomationQuotaState;
  checkedAt: number;
  resetsAt?: number;
  reason?: "api-key";
}

interface ProjectAutomationRecord {
  automationId?: string;
  codexProjectId: string;
  /** 遗留字段：旧宿主记录（本地缓存仅用于兼容，不再使用）。 */
  host?: string;
  status: ProjectAutomationStatus;
  enabledByUser: boolean;
  quotaAware: boolean;
  quota?: AutomationQuotaStatus;
  intervalMinutes: AutomationIntervalMinutes;
  /** 认领模型：'' = 跟随 agent-default-model，否则为模型 id。 */
  model: string;
  reasoningEffort: AutomationReasoningEffort;
  /**
   * 承接会话绑定：'new' 每轮新建；'fixed' 固定挂在 sessionId 那个对话下；
   * 'task' 续在该议题上次的对话里。
   */
  sessionMode?: "new" | "fixed" | "task";
  sessionId?: string | null;
}

type ProjectAutomations = Record<string, ProjectAutomationRecord>;

interface AutomationHostItem {
  id: string;
  status: ProjectAutomationStatus;
  model: AutomationModel;
  reasoningEffort: AutomationReasoningEffort;
  rrule: string;
}

interface AutomationHostResponse {
  requestId: string;
  ok: boolean;
  item?: AutomationHostItem;
  items?: AutomationHostItem[];
  quota?: AutomationQuotaStatus;
  policy?: {
    automationId?: string;
    enabledByUser: boolean;
    quotaAware: boolean;
    intervalMinutes: AutomationIntervalMinutes;
    model: AutomationModel;
    reasoningEffort: AutomationReasoningEffort;
  };
  error?: string;
}

interface PendingAutomationRequest {
  resolve: (response: AutomationHostResponse) => void;
  reject: (error: Error) => void;
  timeoutId: number;
}

const DEFAULT_USER_ACTOR: ActorIdentity = {
  type: "user",
  id: "local-user",
  name: "本地用户",
  avatarUrl: null,
};

const LAST_PROJECT_KEY = "taskboard.lastProjectId";
const FAVORITE_PROJECTS_KEY = "taskboard.favoriteProjectIds";
const DEVICE_WORKSPACE_PATHS_KEY = "taskboard.deviceWorkspacePaths.v1";
/** 项目最近使用时间（projectId → 时间戳），用于全局新建议题菜单的「按最近使用」排序。 */
const RECENT_PROJECT_USAGE_KEY = "taskboard.recentProjectUsage.v1";
const LANE_COLLAPSED_KEY = "taskboard.laneCollapsed.v1";
const LANE_VISIBILITY_KEY = "taskboard.laneVisibility.v1";
const PROJECT_AUTOMATIONS_KEY = "taskboard.projectAutomations.v1";
/** DeepSeek Harness Web GUI 地址：dsh 心跳线程的"查看对话"指向其会话浏览页。 */
const DSH_WEB_URL = "http://127.0.0.1:3080";
const DEFAULT_AUTOMATION_OPTIONS = {
  enabledByUser: false,
  quotaAware: false,
  intervalMinutes: 5,
  model: "gpt-5.5",
  reasoningEffort: "high",
  host: "dsh",
  sessionMode: "new" as const,
  sessionId: null,
} as const;

/** 认领任务 id：与 server 心跳任务 id 保持一致。 */
function heartbeatTaskIdFor(projectId: string): string {
  return `taskboard_claim_${projectId}`;
}

const EVENT_NAMES = [
  "task.created",
  "task.updated",
  "task.moved",
  "task.archived",
  "task.restored",
  "task.relation.updated",
  "comment.created",
  "comment.updated",
  "comment.deleted",
  "attachment.created",
  "attachment.deleted",
  "project.created",
  "workflow.updated",
] as const;

function isTheme(value: unknown): value is Theme {
  return value === "light" || value === "dark";
}

function getInitialTheme(): Theme {
  const fromQuery = getTaskboardLocation().searchParams.get("theme");
  if (isTheme(fromQuery)) return fromQuery;
  const stored = window.localStorage.getItem("taskboard.theme");
  if (isTheme(stored)) return stored;
  return window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
}

function readFavoriteProjectIds(): Set<string> {
  try {
    const value = JSON.parse(window.localStorage.getItem(FAVORITE_PROJECTS_KEY) ?? "[]");
    return new Set(Array.isArray(value) ? value.filter((item): item is string => typeof item === "string") : []);
  } catch {
    return new Set();
  }
}

function readDeviceWorkspacePaths(): Record<string, string> {
  try {
    const value = JSON.parse(window.localStorage.getItem(DEVICE_WORKSPACE_PATHS_KEY) ?? "{}");
    if (!value || typeof value !== "object" || Array.isArray(value)) return {};
    return Object.fromEntries(Object.entries(value).filter((entry): entry is [string, string] => (
      typeof entry[1] === "string" && entry[1].trim().length > 0
    )));
  } catch {
    return {};
  }
}

function readProjectAutomations(): ProjectAutomations {
  try {
    const value = JSON.parse(window.localStorage.getItem(PROJECT_AUTOMATIONS_KEY) ?? "{}");
    if (!value || typeof value !== "object" || Array.isArray(value)) return {};
    const result: ProjectAutomations = {};
    for (const [projectId, record] of Object.entries(value)) {
      if (!record || typeof record !== "object" || Array.isArray(record)) continue;
      const candidate = record as Partial<ProjectAutomationRecord>;
      const model = candidate.model ?? "gpt-5.5";
      const reasoningEffort = candidate.reasoningEffort ?? "high";
      const enabledByUser = candidate.enabledByUser ?? candidate.status === "ACTIVE";
      const quotaAware = candidate.quotaAware ?? false;
      const host = candidate.host === "dsh" ? candidate.host : "dsh";
      if (
        (candidate.automationId !== undefined && typeof candidate.automationId !== "string")
        || typeof candidate.codexProjectId !== "string"
        || (candidate.status !== "ACTIVE" && candidate.status !== "PAUSED")
        || !isAutomationIntervalMinutes(candidate.intervalMinutes ?? 5)
        || !isAutomationModel(model)
        || !isAutomationReasoningEffort(reasoningEffort)
        || !isSupportedModelEffort(model, reasoningEffort)
        || (candidate.status === "ACTIVE" && !candidate.automationId)
        || typeof enabledByUser !== "boolean"
        || typeof quotaAware !== "boolean"
      ) continue;
      const quota = isAutomationQuotaStatus(candidate.quota) ? candidate.quota : undefined;
      result[projectId] = {
        automationId: candidate.automationId,
        codexProjectId: candidate.codexProjectId,
        host,
        status: candidate.status,
        enabledByUser,
        quotaAware,
        ...(quota ? { quota } : {}),
        intervalMinutes: candidate.intervalMinutes ?? 5,
        model,
        reasoningEffort,
      };
    }
    return result;
  } catch {
    return {};
  }
}

function isAutomationQuotaStatus(value: unknown): value is AutomationQuotaStatus {
  if (!value || typeof value !== "object" || Array.isArray(value)) return false;
  const candidate = value as Partial<AutomationQuotaStatus>;
  return (
    (candidate.state === "available"
      || candidate.state === "blocked"
      || candidate.state === "unknown"
      || candidate.state === "unavailable")
    && Number.isFinite(candidate.checkedAt)
    && (candidate.resetsAt === undefined || Number.isFinite(candidate.resetsAt))
    && (candidate.reason === undefined || candidate.reason === "api-key")
  );
}

function isAutomationHostPolicy(
  value: AutomationHostResponse["policy"] | undefined,
): value is NonNullable<AutomationHostResponse["policy"]> {
  return Boolean(
    value
    && (value.automationId === undefined || typeof value.automationId === "string")
    && typeof value.enabledByUser === "boolean"
    && typeof value.quotaAware === "boolean"
    && isAutomationIntervalMinutes(value.intervalMinutes)
    && isAutomationModel(value.model)
    && isAutomationReasoningEffort(value.reasoningEffort)
    && isSupportedModelEffort(value.model, value.reasoningEffort),
  );
}

function isAutomationIntervalMinutes(value: unknown): value is AutomationIntervalMinutes {
  return value === 5 || value === 10 || value === 15 || value === 30 || value === 60;
}

function intervalMinutesFromRrule(value: string): AutomationIntervalMinutes | null {
  const match = /^RRULE:FREQ=MINUTELY;INTERVAL=(5|10|15|30|60)$/.exec(value);
  return match ? Number(match[1]) as AutomationIntervalMinutes : null;
}

function readLaneBooleanByProject<T extends string>(
  key: string,
  allowed: readonly T[],
): Record<string, Partial<Record<T, boolean>>> {
  try {
    const value = JSON.parse(window.localStorage.getItem(key) ?? "{}");
    if (!value || typeof value !== "object" || Array.isArray(value)) return {};
    const result: Record<string, Partial<Record<T, boolean>>> = {};
    for (const [projectId, laneValue] of Object.entries(value)) {
      if (!laneValue || typeof laneValue !== "object" || Array.isArray(laneValue)) continue;
      const entry: Partial<Record<T, boolean>> = {};
      for (const id of allowed) {
        const flag = (laneValue as Record<string, unknown>)[id];
        if (typeof flag === "boolean") entry[id] = flag;
      }
      result[projectId] = entry;
    }
    return result;
  } catch {
    return {};
  }
}

function readLaneCollapsedByProject(): LaneCollapsedByProject {
  return readLaneBooleanByProject(LANE_COLLAPSED_KEY, BOARD_LANE_ORDER);
}

function readLaneVisibilityByProject(): LaneVisibilityByProject {
  return readLaneBooleanByProject(LANE_VISIBILITY_KEY, BOARD_LANE_ORDER);
}

function workspaceName(path?: string): string | null {
  if (!path) return null;
  const parts = path.split(/[\\/]/).filter(Boolean);
  return parts.at(-1) ?? path;
}

function errorMessage(error: unknown): string {
  if (error instanceof ApiError) return error.message;
  if (error instanceof Error) return error.message;
  return "Something went wrong while loading your issues.";
}

function isAutomationHostItem(value: unknown): value is AutomationHostItem {
  if (!value || typeof value !== "object" || Array.isArray(value)) return false;
  const item = value as Partial<AutomationHostItem>;
  return (
    typeof item.id === "string"
    && (item.status === "ACTIVE" || item.status === "PAUSED")
    && isAutomationModel(item.model)
    && isAutomationReasoningEffort(item.reasoningEffort)
    && isSupportedModelEffort(item.model, item.reasoningEffort)
    && typeof item.rrule === "string"
    && intervalMinutesFromRrule(item.rrule) !== null
  );
}

function isLocalTaskboardOrigin(origin: string): boolean {
  try {
    const { protocol, hostname } = new URL(origin);
    return (protocol === "http:" || protocol === "https:")
      && (hostname === "127.0.0.1" || hostname === "localhost");
  } catch {
    return false;
  }
}

function sortTasks(tasks: Task[]): Task[] {
  return [...tasks].sort(
    (left, right) => left.sortOrder - right.sortOrder || left.createdAt.localeCompare(right.createdAt),
  );
}

function taskToDraft(task: Task): TaskDraft {
  return {
    title: task.title,
    description: task.description,
    status: task.status,
    priority: task.priority,
    labels: task.labels,
    workflowId: task.workflowId,
    developmentContext: task.developmentContext,
    startDate: task.startDate,
    dueDate: task.dueDate,
    recurrence: task.recurrence,
  };
}

interface LocalRealtimeSyncProps {
  selectedProjectId: string;
  detailTaskId: string | null;
  refreshProjectList: () => Promise<void>;
  refreshTasks: (
    projectId: string,
    options?: { quiet?: boolean; signal?: AbortSignal },
  ) => Promise<void>;
  refreshWorkflowOptions: (projectId: string, signal?: AbortSignal) => Promise<void>;
  setConnection: Dispatch<SetStateAction<ConnectionState>>;
  setCommentsRevision: Dispatch<SetStateAction<number>>;
  setAttachmentsRevision: Dispatch<SetStateAction<number>>;
}

function LocalRealtimeSync({
  selectedProjectId,
  detailTaskId,
  refreshProjectList,
  refreshTasks,
  refreshWorkflowOptions,
  setConnection,
  setCommentsRevision,
  setAttachmentsRevision,
}: LocalRealtimeSyncProps) {
  useEffect(() => {
    const source = new EventSource(resolveTaskboardUrl("/api/events"));
    let refreshTimer: number | undefined;
    let refreshProjectsPending = false;
    let refreshTasksPending = false;

    const scheduleRefresh = (options: { projects?: boolean; tasks?: boolean }) => {
      refreshProjectsPending ||= options.projects === true;
      refreshTasksPending ||= options.tasks === true;
      window.clearTimeout(refreshTimer);
      refreshTimer = window.setTimeout(() => {
        if (refreshProjectsPending) void refreshProjectList();
        if (refreshTasksPending && selectedProjectId) {
          void refreshTasks(selectedProjectId, { quiet: true });
        }
        refreshProjectsPending = false;
        refreshTasksPending = false;
      }, 120);
    };

    const handleEvent = (event: Event) => {
      const message = event as MessageEvent<string>;
      let payload: { projectId?: string; taskId?: string } = {};
      try {
        payload = JSON.parse(message.data) as { projectId?: string; taskId?: string };
      } catch {
        // A malformed event should not interrupt later updates.
      }
      const affectsSelectedProject = Boolean(selectedProjectId)
        && (!payload.projectId || payload.projectId === selectedProjectId);
      if (event.type === "project.created") {
        scheduleRefresh({ projects: true });
        return;
      }
      if (event.type.startsWith("task.")) {
        scheduleRefresh({ projects: true, tasks: affectsSelectedProject });
        return;
      }
      if (!affectsSelectedProject) return;
      if (event.type === "workflow.updated") {
        if (selectedProjectId) void refreshWorkflowOptions(selectedProjectId);
        return;
      }
      if (event.type.startsWith("comment.")) {
        if (!detailTaskId || !payload.taskId || payload.taskId === detailTaskId) {
          setCommentsRevision((current) => current + 1);
        }
        scheduleRefresh({ tasks: true });
        return;
      }
      if (event.type.startsWith("attachment.")) {
        if (!detailTaskId || !payload.taskId || payload.taskId === detailTaskId) {
          setAttachmentsRevision((current) => current + 1);
          setCommentsRevision((current) => current + 1);
        }
      }
    };

    EVENT_NAMES.forEach((name) => source.addEventListener(name, handleEvent));
    source.onopen = () => {
      setConnection("live");
      scheduleRefresh({ projects: true, tasks: Boolean(selectedProjectId) });
      if (selectedProjectId) void refreshWorkflowOptions(selectedProjectId);
      if (detailTaskId) {
        setCommentsRevision((current) => current + 1);
        setAttachmentsRevision((current) => current + 1);
      }
    };
    source.onerror = () => setConnection("reconnecting");

    return () => {
      window.clearTimeout(refreshTimer);
      EVENT_NAMES.forEach((name) => source.removeEventListener(name, handleEvent));
      source.close();
    };
  }, [
    detailTaskId,
    refreshProjectList,
    refreshTasks,
    refreshWorkflowOptions,
    selectedProjectId,
    setAttachmentsRevision,
    setCommentsRevision,
    setConnection,
  ]);

  return null;
}

export function App() {
  const query = useMemo(() => new URLSearchParams(getTaskboardLocation().search), []);
  const embedded = query.get("host") === "codex";
  // Compact chrome (?chrome=min): the right-sidebar embed — the left nav,
  // the project switcher, and the view tabs are hidden; everything else
  // (create, drag, detail, automation menu, search) stays.
  const compact = query.get("chrome") === "min";
  // 详情属性栏折叠状态（宿主持有，开关按钮在顶栏图标行里）。
  const [propertiesCollapsed, setPropertiesCollapsed] = useState(() => window.innerWidth <= 720);
  // host=dsh enables the parent-message protocol (theme sync etc.) while
  // keeping automation on the direct local API path.
  const hostMode = query.get("host");
  const hostMessaging = hostMode === "codex" || hostMode === "dsh";
  // 「拖拽整个窗口」：面板头部（.workspace-drag-region）是窗口拖拽柄。
  // 议题 09582F74F86A-134：DSH GUI 的中间列面板由 PanelFrame 以 host=dsh 挂载，
  // 而拖拽柄此前只在 host=codex 时生效，于是在真实 App 里拖头部不动窗口。
  const windowDrag = hostMessaging;
  const undoShortcut = navigator.userAgent.includes("Macintosh") ? "⌘Z" : "Ctrl+Z";
  const [theme, setTheme] = useState<Theme>(getInitialTheme);
  const [navCollapsed, setNavCollapsed] = useState(
    () => window.localStorage.getItem("taskboard.navCollapsed") === "1",
  );
  const toggleNavCollapsed = useCallback(() => {
    setNavCollapsed((prev) => {
      window.localStorage.setItem("taskboard.navCollapsed", prev ? "0" : "1");
      return !prev;
    });
  }, []);
  const [hostContext, setHostContext] = useState<HostContext | null>(null);
  const language = resolveTaskboardLanguage(
    hostContext?.language ?? query.get("lang") ?? navigator.language,
  );
  const { locale, text } = getTaskboardI18n(language);
  const [developmentScan, setDevelopmentScan] = useState<DevelopmentScan>({ workspacePath: null, contexts: [] });
  const [developmentScanLoading, setDevelopmentScanLoading] = useState(false);
  const [manageTaskboardSkillPath, setManageTaskboardSkillPath] = useState("");
  const [taskboardMetadata, setTaskboardMetadata] = useState<TaskboardMetadata | null>(null);
  const [localAiChatAvailable, setLocalAiChatAvailable] = useState(false);
  const [aiThreads, setAiThreads] = useState<AiChatThread[]>([]);
  const [aiOpenThreadRequest, setAiOpenThreadRequest] = useState<AiChatOpenThreadRequest | null>(null);
  const [projects, setProjects] = useState<Project[]>([]);
  const [selectedProjectId, setSelectedProjectId] = useState("");
  const [tasks, setTasks] = useState<Task[]>([]);
  const [archivedTasks, setArchivedTasks] = useState<Task[]>([]);
  const [projectsLoading, setProjectsLoading] = useState(true);
  const [tasksLoading, setTasksLoading] = useState(false);
  const [hasLoadedTasks, setHasLoadedTasks] = useState(false);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [actionError, setActionError] = useState<string | null>(null);
  const [connection, setConnection] = useState<ConnectionState>("connecting");
  const [search, setSearch] = useState("");
  const [filters, setFilters] = useState(readTaskFilters);
  const [laneCollapsedByProject, setLaneCollapsedByProject] = useState(readLaneCollapsedByProject);
  const [laneVisibilityByProject, setLaneVisibilityByProject] = useState(readLaneVisibilityByProject);
  const [boardView, setBoardView] = useState<BoardView>(() => {
    // Initial view from the URL (?view=list), used by the right-sidebar
    // embed so the compact panel opens straight onto the list. Absent or
    // unknown values fall back to the board.
    const view = getTaskboardLocation().searchParams.get("view");
    if (view === "list" || view === "gantt" || view === "dashboard" || view === "workflow") {
      return view;
    }
    // Remembered view: reopening the sidebar returns to the last used view.
    const saved = window.localStorage.getItem("taskboard.boardView");
    if (saved === "issues" || saved === "list" || saved === "gantt" || saved === "dashboard" || saved === "workflow") {
      return saved;
    }
    // First open of the compact right-sidebar embed defaults to the list.
    return getTaskboardLocation().searchParams.get("chrome") === "min" ? "list" : "issues";
  });
  const [ganttZoom, setGanttZoom] = useState<GanttZoom>("week");
  const [ganttHideCompleted, setGanttHideCompleted] = useState(false);
  const [ganttTodayRequest, setGanttTodayRequest] = useState(0);
  const [ganttViewMenuOpen, setGanttViewMenuOpen] = useState(false);
  const [processingNow, setProcessingNow] = useState(() => Date.now());
  const [restoringTaskId, setRestoringTaskId] = useState<string | null>(null);
  const [deletingArchivedTaskId, setDeletingArchivedTaskId] = useState<string | null>(null);
  const [pendingArchivedTaskDelete, setPendingArchivedTaskDelete] = useState<Task | null>(null);
  const [editor, setEditor] = useState<EditorState | null>(null);
  const [detailTaskIdentifier, setDetailTaskIdentifier] = useState<string | null>(
    () => readIssueIdentifier(getTaskboardLocation().search),
  );
  const [commentsRevision, setCommentsRevision] = useState(0);
  const [attachmentsRevision, setAttachmentsRevision] = useState(0);
  const [workflowRevision, setWorkflowRevision] = useState(0);
  const [workflowOptions, setWorkflowOptions] = useState<WorkflowOption[]>(DEFAULT_WORKFLOW_OPTIONS);
  const [contextMenu, setContextMenu] = useState<ContextMenuState | null>(null);
  const [draggedTaskId, setDraggedTaskId] = useState<string | null>(null);
  const [draggedTaskHeight, setDraggedTaskHeight] = useState(0);
  const [dropTarget, setDropTarget] = useState<TaskStatus | null>(null);
  const [movingTaskId, setMovingTaskId] = useState<string | null>(null);
  const [settlingTaskId, setSettlingTaskId] = useState<string | null>(null);
  const [openingProjectId, setOpeningProjectId] = useState<string | null>(null);
  const [openingThreadTaskId, setOpeningThreadTaskId] = useState<string | null>(null);
  const issueListRef = useRef<HTMLDivElement>(null);
  // FLIP 动画：记录上一帧卡片位置，卡片换列（点「完成」、菜单移动等）时平滑飞到新列。
  const cardRectsRef = useRef<Map<string, { x: number; y: number; w: number; h: number }>>(new Map());
  const cardStatusRef = useRef<Map<string, string>>(new Map());
  const [projectMenuOpen, setProjectMenuOpen] = useState(false);
  // 「全局」视图新建议题时的项目选择菜单。
  const [globalCreateMenuOpen, setGlobalCreateMenuOpen] = useState(false);
  // 项目最近使用时间表（切换项目时打点），驱动全局新建菜单的「按最近使用」排序。
  const [projectUsageAt, setProjectUsageAt] = useState<Record<string, number>>(() => {
    try {
      const parsed = JSON.parse(window.localStorage.getItem(RECENT_PROJECT_USAGE_KEY) ?? "{}");
      return parsed && typeof parsed === "object" ? parsed : {};
    } catch {
      return {};
    }
  });
  const rememberProjectUsage = useCallback((projectId: string) => {
    setProjectUsageAt((current) => {
      if (current[projectId] && Date.now() - current[projectId] < 60_000) return current;
      const next = { ...current, [projectId]: Date.now() };
      window.localStorage.setItem(RECENT_PROJECT_USAGE_KEY, JSON.stringify(next));
      return next;
    });
  }, []);
  const [projectMenuQuery, setProjectMenuQuery] = useState("");
  const [favoriteProjectIds, setFavoriteProjectIds] = useState(readFavoriteProjectIds);
  const [deviceWorkspacePaths, setDeviceWorkspacePaths] = useState(readDeviceWorkspacePaths);
  const [projectAutomations, setProjectAutomations] = useState(readProjectAutomations);
  /** 认领模型目录：组合值 provider::model。 */
  const [claimModelChoices, setClaimModelChoices] = useState<string[]>([]);
  const [claimModelLabels, setClaimModelLabels] = useState<Record<string, string>>({});
  const [automationPending, setAutomationPending] = useState(false);
  const [automationError, setAutomationError] = useState<string | null>(null);
  const [announcement, setAnnouncementValue] = useState("");
  const [undoNotice, setUndoNotice] = useState<UndoNotice | null>(null);
  const tasksRequestRef = useRef(0);
  const tasksRef = useRef<Task[]>([]);
  const undoSequenceRef = useRef(0);
  const undoStackRef = useRef<UndoOperation[]>([]);
  const undoInFlightRef = useRef(false);
  const dragRegionRef = useRef<HTMLDivElement>(null);
  const selectedProjectIdRef = useRef(selectedProjectId);
  selectedProjectIdRef.current = selectedProjectId;

  const revisionPollingInterval = getRevisionPollingInterval(taskboardMetadata);
  const pendingAutomationRequestsRef = useRef(new Map<string, PendingAutomationRequest>());
  const automationRequestInFlightRef = useRef(false);
  const projectAutomationsRef = useRef(projectAutomations);

  const setAnnouncement = useCallback((message: string) => {
    setUndoNotice(null);
    setAnnouncementValue(message);
  }, []);

  const rememberDeviceWorkspacePath = useCallback((projectId: string, workspacePath: string) => {
    const normalizedPath = workspacePath.trim();
    setDeviceWorkspacePaths((current) => {
      if (current[projectId] === normalizedPath || (!normalizedPath && !(projectId in current))) {
        return current;
      }
      const next = { ...current };
      if (normalizedPath) next[projectId] = normalizedPath;
      else delete next[projectId];
      window.localStorage.setItem(DEVICE_WORKSPACE_PATHS_KEY, JSON.stringify(next));
      return next;
    });
  }, []);

  const selectedProject = projects.find((project) => project.id === selectedProjectId) ?? null;
  // 「全局」视图：聚合展示所有项目的议题（该条目本身没有工作目录，不提供新建议题入口）。
  const isGlobalView = isGlobalProjectId(selectedProjectId);
  const projectNames = useMemo(() => (
    Object.fromEntries(projects.map((project) => [project.id, project.name]))
  ), [projects]);
  const currentUser = hostContext?.user ?? DEFAULT_USER_ACTOR;
  const selectedDeviceWorkspacePath = deviceWorkspacePaths[selectedProjectId];
  const selectedProjectAutomation = projectAutomations[selectedProjectId];
  const automationProjectContext = useMemo(() => {
    // 独立模式（浏览器直接使用）：自动认领通过本地心跳任务实现，
    // workspacePath 取项目自身路径即可，菜单可用。
    if (!embedded || window.parent === window) {
      if (!selectedProject) return { unavailableReason: "请先选择项目" };
      const workspacePath = deviceWorkspacePaths[selectedProject.id]
        ?? selectedProject.workspacePath
        ?? null;
      if (!workspacePath) {
        return { unavailableReason: "该项目未设置本地目录，无法开启自动认领" };
      }
      return { workspacePath, codexProjectId: selectedProject.id, unavailableReason: null };
    }
    if (!isLocalTaskboardOrigin(window.location.origin)) {
      return { unavailableReason: "仅本地任务面板可用" };
    }
    if (!selectedProject) return { unavailableReason: "请先选择项目" };

    // ChatGPT cloud projects (`g-p-*`) are visible in the shared sidebar, but
    // local automations only accept local project IDs. Treating a cloud
    // project as a direct match makes the native API reject the request (432).
    const isLocalCodexProject = (projectId: string) => !projectId.startsWith("g-p-");
    const directCodexProject = isLocalCodexProject(selectedProject.id)
      && hostContext?.projects?.some((project) => project.id === selectedProject.id);
    const workspacePath = deviceWorkspacePaths[selectedProject.id]
      ?? selectedProject.workspacePath
      ?? (
        directCodexProject && hostContext?.projectId === selectedProject.id
          ? hostContext.workspacePath
          : undefined
      );
    const codexProjectId = directCodexProject
      ? selectedProject.id
      : hostContext?.projects?.find(
        (project) => (
          isLocalCodexProject(project.id)
          && deviceWorkspacePaths[project.id] === workspacePath
        ),
      )?.id;

    if (!workspacePath || !codexProjectId) {
      return { unavailableReason: "请先在宿主中添加并映射该项目目录" };
    }
    if (!manageTaskboardSkillPath) {
      return { unavailableReason: "任务面板还没有读取到 Skill 路径" };
    }
    return { workspacePath, codexProjectId, unavailableReason: null };
  }, [
    deviceWorkspacePaths,
    embedded,
    hostContext,
    manageTaskboardSkillPath,
    selectedProject,
  ]);
  const detailTask = detailTaskIdentifier
    ? tasks.find((task) => task.identifier === detailTaskIdentifier) ?? null
    : null;
  const detailTaskId = detailTask?.id ?? null;
  const contextMenuTask = contextMenu
    ? tasks.find((task) => task.id === contextMenu.taskId) ?? null
    : null;
  const availableLabels = useMemo(
    () => [...new Set([
      ...DEFAULT_LABELS.map((label) => label.name),
      ...tasks.flatMap((task) => task.labels),
    ])],
    [tasks],
  );
  const projectChoices = useMemo<ProjectChoice[]>(() => {
    const persistedById = new Map(projects.map((project) => [project.id, project]));
    const seen = new Set<string>();
    const choices: ProjectChoice[] = [];
    for (const project of hostContext?.projects ?? []) {
      if (!project.id || !project.name || seen.has(project.id)) continue;
      seen.add(project.id);
      choices.push({
        id: project.id,
        name: persistedById.get(project.id)?.name ?? project.name,
        issueCount: persistedById.get(project.id)?.issueCount ?? 0,
        youCount: persistedById.get(project.id)?.youCount ?? 0,
        inProgressCount: persistedById.get(project.id)?.inProgressCount ?? 0,
        openCount: persistedById.get(project.id)?.openCount ?? 0,
        inCodex: true,
        persisted: persistedById.has(project.id),
      });
    }
    for (const project of projects) {
      if (seen.has(project.id)) continue;
      choices.push({
        id: project.id,
        name: project.name,
        issueCount: project.issueCount,
        youCount: project.youCount,
        inProgressCount: project.inProgressCount,
        openCount: project.openCount,
        inCodex: false,
        persisted: true,
      });
    }
    return choices.sort((left, right) => (
      Number(favoriteProjectIds.has(right.id)) - Number(favoriteProjectIds.has(left.id))
    ));
  }, [favoriteProjectIds, hostContext?.projects, projects]);
  const projectsWithIssues = useMemo(
    () => projectChoices.filter((project) => project.issueCount > 0),
    [projectChoices],
  );
  const projectsWithoutIssues = useMemo(
    () => projectChoices.filter((project) => project.issueCount === 0),
    [projectChoices],
  );
  // 项目列表排序：「全局」固定第一（聚合全量入口），开启自动化的在前，
  // 其次按最近议题动态（最近有任务执行的）靠前，其余保持原有创建顺序。
  const sortedSidebarProjects = useMemo(() => {
    const activityTime = (project: Project) => {
      const value = project.lastActivityAt ?? project.updatedAt;
      const time = value ? Date.parse(value) : Number.NaN;
      return Number.isNaN(time) ? 0 : time;
    };
    return projects.map((project, index) => ({ project, index })).sort((left, right) => {
      const byGlobal = Number(isGlobalProjectId(right.project.id)) - Number(isGlobalProjectId(left.project.id));
      if (byGlobal !== 0) return byGlobal;
      const byAutomation = Number(right.project.automationEnabled) - Number(left.project.automationEnabled);
      if (byAutomation !== 0) return byAutomation;
      const byActivity = activityTime(right.project) - activityTime(left.project);
      if (byActivity !== 0) return byActivity;
      return left.index - right.index;
    }).map((entry) => entry.project);
  }, [projects]);
  // 全局新建议题菜单的项目顺序：按最近使用（切换/打点时间）靠前，没用过的按创建顺序排在最后；「全局」不是落点项目，不进菜单。
  const globalCreateProjects = useMemo(() => (
    sortedSidebarProjects
      .filter((project) => !isGlobalProjectId(project.id))
      .sort((left, right) => (projectUsageAt[right.id] ?? 0) - (projectUsageAt[left.id] ?? 0))
  ), [sortedSidebarProjects, projectUsageAt]);
  // 当前选中项目视为「最近使用」：加载恢复的选中项目也打点，保证菜单把它排前。
  useEffect(() => {
    if (selectedProjectId && !isGlobalProjectId(selectedProjectId)) rememberProjectUsage(selectedProjectId);
  }, [selectedProjectId, rememberProjectUsage]);
  const closeContextMenu = useCallback(() => setContextMenu(null), []);

  // 项目切换菜单：全局入口固定第一，其余按最近选择时间降序；同一使用时间沿用事项优先级作为稳定排序。
  const projectMenuChoices = useMemo(() => {
    const tier = (project: ProjectChoice) => {
      if (isGlobalProjectId(project.id)) return -1;
      if (project.youCount > 0) return 0;
      if (project.inProgressCount > 0) return 1;
      if (project.openCount > 0) return 2;
      return 3;
    };
    return [...projectChoices].sort((left, right) => {
      const byGlobal = Number(isGlobalProjectId(right.id)) - Number(isGlobalProjectId(left.id));
      if (byGlobal !== 0) return byGlobal;
      const byRecentUse = (projectUsageAt[right.id] ?? 0) - (projectUsageAt[left.id] ?? 0);
      if (byRecentUse !== 0) return byRecentUse;
      const byTier = tier(left) - tier(right);
      if (byTier !== 0) return byTier;
      const byFavorite = Number(favoriteProjectIds.has(right.id)) - Number(favoriteProjectIds.has(left.id));
      if (byFavorite !== 0) return byFavorite;
      const byIssues = right.openCount - left.openCount;
      if (byIssues !== 0) return byIssues;
      return left.name.localeCompare(right.name);
    });
  }, [favoriteProjectIds, projectChoices, projectUsageAt]);
  const filteredProjectMenuChoices = useMemo(() => {
    const query = projectMenuQuery.trim().toLowerCase();
    if (!query) return projectMenuChoices;
    return projectMenuChoices.filter((project) => project.name.toLowerCase().includes(query));
  }, [projectMenuChoices, projectMenuQuery]);

  const writeProjectAutomation = useCallback((
    projectId: string,
    record: ProjectAutomationRecord | null | undefined,
  ) => {
    setProjectAutomations((current) => {
      if (
        record
        && current[projectId]?.automationId === record.automationId
        && current[projectId]?.codexProjectId === record.codexProjectId
        && current[projectId]?.host === record.host
        && current[projectId]?.status === record.status
        && current[projectId]?.enabledByUser === record.enabledByUser
        && current[projectId]?.quotaAware === record.quotaAware
        && JSON.stringify(current[projectId]?.quota) === JSON.stringify(record.quota)
        && current[projectId]?.intervalMinutes === record.intervalMinutes
        && current[projectId]?.model === record.model
        && current[projectId]?.reasoningEffort === record.reasoningEffort
      ) {
        return current;
      }
      const next = { ...current };
      if (record) next[projectId] = record;
      else delete next[projectId];
      projectAutomationsRef.current = next;
      window.localStorage.setItem(PROJECT_AUTOMATIONS_KEY, JSON.stringify(next));
      return next;
    });
  }, []);

  const sendAutomationRequest = useCallback((
    operation: "ensure-active" | "pause" | "list" | "apply-policy",
    options: Pick<
      ProjectAutomationRecord,
      "enabledByUser" | "quotaAware" | "intervalMinutes" | "model" | "reasoningEffort"
    >,
    automationId?: string,
  ) => {
    if (
      !selectedProject
      || !automationProjectContext.codexProjectId
      || !automationProjectContext.workspacePath
    ) {
      return Promise.reject(new Error(
        automationProjectContext.unavailableReason ?? "无法读取项目自动化信息",
      ));
    }
    const requestId = window.crypto.randomUUID();
    const response = new Promise<AutomationHostResponse>((resolve, reject) => {
      const timeoutId = window.setTimeout(() => {
        pendingAutomationRequestsRef.current.delete(requestId);
        reject(new Error("宿主自动化没有响应，请稍后重试"));
      }, 10_000);
      pendingAutomationRequestsRef.current.set(requestId, { resolve, reject, timeoutId });
    });
    window.parent.postMessage({
      type: "taskboard:automation-request",
      payload: {
        requestId,
        operation,
        taskboardProjectId: selectedProjectId,
        codexProjectId: automationProjectContext.codexProjectId,
        projectName: selectedProject.name,
        workspacePath: automationProjectContext.workspacePath,
        skillPath: manageTaskboardSkillPath,
        ...(automationId ? { automationId } : {}),
        enabledByUser: options.enabledByUser,
        quotaAware: options.quotaAware,
        intervalMinutes: options.intervalMinutes,
        model: options.model,
        reasoningEffort: options.reasoningEffort,
      },
    }, "*");
    return response;
  }, [
    automationProjectContext,
    manageTaskboardSkillPath,
    selectedProject,
    selectedProjectId,
  ]);

  /**
   * Whether this host's server half understands the claim-conversation fields.
   * The board SPA ships ahead of a host that has not been reloaded yet, and an
   * older server rejects the unknown keys outright, so the panel only offers the
   * selector and only sends the fields when the host advertises them.
   */
  const sessionBindingSupportedRef = useRef<boolean | null>(null);
  const [sessionBindingSupported, setSessionBindingSupported] = useState<boolean | null>(null);

  const reconcileProjectAutomation = useCallback(async () => {
    if (automationProjectContext.unavailableReason) {
      setAutomationError(null);
      return;
    }
    if (!selectedProjectId || !automationProjectContext.codexProjectId || automationRequestInFlightRef.current) return;
    // 独立模式：从本地心跳任务读取状态
    if (!embedded || window.parent === window) {
      automationRequestInFlightRef.current = true;
      setAutomationPending(true);
      setAutomationError(null);
      try {
        const previous = projectAutomationsRef.current[selectedProjectId];
        const result = await getProjectAutomation(selectedProjectId);
        const supportsSessionBinding = Object.hasOwn(result, "sessionMode");
        sessionBindingSupportedRef.current = supportsSessionBinding;
        setSessionBindingSupported(supportsSessionBinding);
        writeProjectAutomation(selectedProjectId, {
          automationId: heartbeatTaskIdFor(selectedProjectId),
          codexProjectId: selectedProjectId,
          status: result.enabled ? "ACTIVE" : "PAUSED",
          enabledByUser: result.enabled,
          quotaAware: previous?.quotaAware ?? false,
          intervalMinutes: isAutomationIntervalMinutes(result.intervalMinutes)
            ? result.intervalMinutes
            : previous?.intervalMinutes ?? DEFAULT_AUTOMATION_OPTIONS.intervalMinutes,
          model: result.model ?? previous?.model ?? "",
          reasoningEffort: previous?.reasoningEffort ?? DEFAULT_AUTOMATION_OPTIONS.reasoningEffort,
          sessionMode: result.sessionMode === "fixed"
            ? "fixed"
            : result.sessionMode === "task" ? "task" : (previous?.sessionMode ?? "new"),
          sessionId: result.sessionId ?? previous?.sessionId ?? null,
        });
      } catch (error) {
        setAutomationError(error instanceof Error ? error.message : "无法读取自动认领状态");
      } finally {
        automationRequestInFlightRef.current = false;
        setAutomationPending(false);
      }
      return;
    }
    const stored = projectAutomationsRef.current[selectedProjectId];
    automationRequestInFlightRef.current = true;
    setAutomationPending(true);
    setAutomationError(null);
    try {
      const options = stored ?? {
        status: "PAUSED" as const,
        ...DEFAULT_AUTOMATION_OPTIONS,
      };
      const response = await sendAutomationRequest(
        stored ? "apply-policy" : "list",
        options,
        stored?.automationId,
      );
      const items = Array.isArray(response.items)
        ? response.items.filter(isAutomationHostItem)
        : [];
      if (!stored) {
        const policy = isAutomationHostPolicy(response.policy) ? response.policy : null;
        if (!policy) return;
        const item = items.find((candidate) => candidate.id === policy.automationId)
          ?? (items.length === 1 ? items[0] : undefined);
        writeProjectAutomation(selectedProjectId, {
          automationId: item?.id ?? policy.automationId,
          codexProjectId: automationProjectContext.codexProjectId,
          status: item?.status ?? "PAUSED",
          enabledByUser: policy.enabledByUser,
          quotaAware: policy.quotaAware,
          intervalMinutes: policy.intervalMinutes,
          model: policy.model,
          reasoningEffort: policy.reasoningEffort,
        });
        return;
      }
      const item = (isAutomationHostItem(response.item) ? response.item : undefined)
        ?? items.find((item) => item.id === stored?.automationId)
        ?? (items.length === 1 ? items[0] : undefined);
      if (!item) {
        if (stored) {
          writeProjectAutomation(selectedProjectId, {
            ...stored,
            automationId: undefined,
            status: "PAUSED",
            ...(response.quota ? { quota: response.quota } : {}),
          });
        }
        return;
      }
      const intervalMinutes = intervalMinutesFromRrule(item.rrule);
      if (!intervalMinutes) return;
      writeProjectAutomation(selectedProjectId, {
        automationId: item.id,
        codexProjectId: automationProjectContext.codexProjectId,
        status: item.status,
        enabledByUser: stored.enabledByUser,
        quotaAware: stored.quotaAware,
        ...(response.quota ? { quota: response.quota } : {}),
        intervalMinutes,
        model: item.model,
        reasoningEffort: item.reasoningEffort,
      });
    } catch (error) {
      setAutomationError(error instanceof Error ? error.message : "无法读取自动化状态");
    } finally {
      automationRequestInFlightRef.current = false;
      setAutomationPending(false);
    }
  }, [
    automationProjectContext,
    selectedProjectId,
    sendAutomationRequest,
    writeProjectAutomation,
  ]);

  const saveProjectAutomation = useCallback(async (options: {
    enabledByUser: boolean;
    quotaAware: boolean;
    intervalMinutes: AutomationIntervalMinutes;
    model: string;
    reasoningEffort: AutomationReasoningEffort;
    sessionMode: "new" | "fixed" | "task";
    sessionId: string | null;
  }) => {
    const stored = projectAutomations[selectedProjectId];
    if (
      !selectedProjectId
      || automationProjectContext.unavailableReason
      || !automationProjectContext.codexProjectId
      || automationRequestInFlightRef.current
    ) return;
    // DSH 原生模式：自动认领开关直接写看板数据库，由 claim-sweep 作业驱动。
    if (!embedded || window.parent === window) {
      if (automationRequestInFlightRef.current) return;
      automationRequestInFlightRef.current = true;
      setAutomationPending(true);
      setAutomationError(null);
      const previousRecord = stored;
      try {
        const result = await updateProjectAutomation(selectedProjectId, {
          enabled: options.enabledByUser,
          intervalMinutes: options.intervalMinutes,
          automationModel: options.model || null,
          ...(sessionBindingSupportedRef.current === true
            ? {
                sessionMode: options.sessionMode,
                sessionId: options.sessionMode === "fixed" ? options.sessionId : null,
              }
            : {}),
        });
        writeProjectAutomation(selectedProjectId, {
          automationId: heartbeatTaskIdFor(selectedProjectId),
          codexProjectId: selectedProjectId,
          status: result.enabled ? "ACTIVE" : "PAUSED",
          enabledByUser: result.enabled,
          quotaAware: false,
          intervalMinutes: isAutomationIntervalMinutes(result.intervalMinutes)
            ? result.intervalMinutes
            : options.intervalMinutes,
          model: options.model,
          reasoningEffort: options.reasoningEffort,
          sessionMode: result.sessionMode === "fixed" ? "fixed" : result.sessionMode === "task" ? "task" : "new",
          sessionId: result.sessionId ?? null,
        });
      } catch (error) {
        writeProjectAutomation(selectedProjectId, previousRecord);
        setAutomationError(error instanceof Error ? error.message : "无法更新自动认领");
      } finally {
        automationRequestInFlightRef.current = false;
        setAutomationPending(false);
      }
      return;
    }
    const previousRecord = stored;
    automationRequestInFlightRef.current = true;
    setAutomationPending(true);
    setAutomationError(null);
    try {
      // The embedded (Codex-host) automation API knows nothing about the
      // conversation binding: send it the legacy shape only.
      const { sessionMode: _sessionMode, sessionId: _sessionId, ...legacyOptions } = options;
      void _sessionMode;
      void _sessionId;
      const response = await sendAutomationRequest("apply-policy", legacyOptions, stored?.automationId);
      const item = isAutomationHostItem(response.item) ? response.item : undefined;
      writeProjectAutomation(selectedProjectId, {
        automationId: item?.id,
        codexProjectId: automationProjectContext.codexProjectId,
        status: item?.status ?? "PAUSED",
        enabledByUser: options.enabledByUser,
        quotaAware: options.quotaAware,
        ...(response.quota ? { quota: response.quota } : {}),
        intervalMinutes: options.intervalMinutes,
        model: options.model,
        reasoningEffort: options.reasoningEffort,
        sessionMode: options.sessionMode,
        sessionId: options.sessionId,
      });
    } catch (error) {
      writeProjectAutomation(selectedProjectId, previousRecord);
      setAutomationError(error instanceof Error ? error.message : "无法更新自动化");
    } finally {
      automationRequestInFlightRef.current = false;
      setAutomationPending(false);
    }
  }, [
    automationProjectContext,
    projectAutomations,
    selectedProjectId,
    sendAutomationRequest,
    writeProjectAutomation,
  ]);

  function openTaskDetail(task: Pick<Task, "identifier" | "projectId">) {
    closeContextMenu();
    setProjectMenuOpen(false);
    setDetailTaskIdentifier(task.identifier);
    const currentIssue = readIssueIdentifier(getTaskboardLocation().search);
    const boardUrl = buildIssueUrl(getTaskboardLocation().href, task.projectId, null);
    if (!currentIssue) {
      taskboardReplaceState(window.history.state, boardUrl);
    }
    const detailUrl = buildIssueUrl(
      currentIssue ? getTaskboardLocation().href : boardUrl.href,
      task.projectId,
      task.identifier,
    );
    taskboardPushState(window.history.state, detailUrl);
  }

  function closeTaskDetail() {
    setDetailTaskIdentifier(null);
    const url = buildIssueUrl(getTaskboardLocation().href, selectedProjectId || null, null);
    taskboardReplaceState(window.history.state, url);
  }

  /** 详情里「确认完成」后：播放落卡动画并退出详情，回到列表看卡片落进完成列。 */
  function acceptTaskFromDetail(taskId: string) {
    setSettlingTaskId(taskId);
    window.setTimeout(() => {
      setSettlingTaskId((current) => current === taskId ? null : current);
    }, 220);
    closeTaskDetail();
  }

  useEffect(() => {
    function syncRouteFromLocation() {
      const url = getTaskboardLocation();
      const routeProjectId = url.searchParams.get("project") ?? "";
      setDetailTaskIdentifier(readIssueIdentifier(url.search));
      if (routeProjectId === selectedProjectId) return;
      setBoardView("issues");
      setSelectedProjectId(routeProjectId);
      if (routeProjectId) window.localStorage.setItem(LAST_PROJECT_KEY, routeProjectId);
      else window.localStorage.removeItem(LAST_PROJECT_KEY);
    }

    window.addEventListener("popstate", syncRouteFromLocation);
    return () => window.removeEventListener("popstate", syncRouteFromLocation);
  }, [selectedProjectId]);

  useEffect(() => {
    const target = getThemeTarget();
    target.dataset.theme = theme;
    target.dataset.embedded = String(embedded);
    target.style.colorScheme = theme;
    publishTheme(theme);
    if (!embedded) window.localStorage.setItem("taskboard.theme", theme);
  }, [embedded, theme]);

  useEffect(() => onTaskboardThemeChange((next) => setTheme(next)), []);
  // 卡片换列 FLIP：渲染提交后对比上一帧位置，给换了列的卡片施加反向位移再过渡归零，
  // 让「点完成 / 菜单移动 / 拖拽落列」都呈现卡片动态飞到新列的效果。
  // 目标列折叠或卡片没有可见落点时，退化为「飞行卡」：一张临时卡从原位飞向目标列头再消隐，
  // 保证任何情况下都能看到卡片飞出去。
  useLayoutEffect(() => {
    const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const previousRects = cardRectsRef.current;
    const previousStatuses = cardStatusRef.current;
    if (!reduceMotion) {
      for (const task of tasks) {
        const previous = previousRects.get(task.id);
        if (!previous || previousStatuses.get(task.id) === task.status) continue;
        const node = document.querySelector<HTMLElement>(`.board-column [data-task-id="${task.id}"], .lane-body [data-task-id="${task.id}"]`)
          ?? document.querySelector<HTMLElement>(`[data-task-id="${task.id}"]`);
        const next = node && node.isConnected ? node.getBoundingClientRect() : null;
        if (node && next && next.width > 0 && next.height > 0 && !node.classList.contains("is-flipping")) {
          const dx = previous.x - next.x;
          const dy = previous.y - next.y;
          if (!dx && !dy) continue;
          // 先在无过渡状态下写入反向位移，再启用过渡清零——否则「设置位移」本身会被
          // 过渡动画化，一帧后清零只剩微小回弹，视觉上仍是瞬移。
          node.style.transition = "none";
          node.style.transform = `translate3d(${dx}px, ${dy}px, 0)`;
          void node.getBoundingClientRect();
          node.classList.add("is-flipping");
          node.style.transition = "";
          void node.getBoundingClientRect();
          requestAnimationFrame(() => {
            node.style.transform = "";
            window.setTimeout(() => {
              node.classList.remove("is-flipping");
              node.style.transform = "";
            }, 360);
          });
        } else {
          // 没有可见落点（目标列折叠等）：用临时飞行卡从原位飞向目标列。
          const ghost = document.createElement("div");
          ghost.className = "task-card-ghost";
          ghost.textContent = `${task.identifier} ${task.title}`;
          ghost.style.left = `${previous.x}px`;
          ghost.style.top = `${previous.y}px`;
          ghost.style.width = `${previous.w}px`;
          ghost.style.height = `${Math.min(previous.h, 64)}px`;
          document.body.appendChild(ghost);
          const target = document.querySelector<HTMLElement>(`.board-column.status-${task.status}`);
          const tr = target ? target.getBoundingClientRect() : null;
          void ghost.getBoundingClientRect();
          requestAnimationFrame(() => {
            ghost.classList.add("is-flying");
            if (tr) {
              ghost.style.left = `${tr.x + tr.width / 2 - 70}px`;
              ghost.style.top = `${tr.y + 14}px`;
            }
            ghost.style.width = "140px";
            ghost.style.height = "28px";
            ghost.style.opacity = "0.15";
            window.setTimeout(() => ghost.remove(), 420);
          });
        }
      }
    }
    previousRects.clear();
    previousStatuses.clear();
    for (const task of tasks) {
      // 正在飞行中的卡片位置被临时位移污染，保留旧条目等下一帧再测。
      const node = document.querySelector<HTMLElement>(`[data-task-id="${task.id}"]`);
      if (!node || node.classList.contains("is-flipping")) continue;
      const rect = node.getBoundingClientRect();
      previousRects.set(task.id, { x: rect.x, y: rect.y, w: rect.width, h: rect.height });
      previousStatuses.set(task.id, task.status);
    }
  }, [tasks]);

  useEffect(() => {
    writeTaskFilters(filters);
  }, [filters]);

  useEffect(() => {
    tasksRef.current = tasks;
  }, [tasks]);

  useEffect(() => {
    if (!projectMenuOpen) return;
    function closeProjectMenu(event: PointerEvent) {
      const target = event.target as HTMLElement;
      if (!target.closest("[data-project-switcher]")) {
        setProjectMenuOpen(false);
        setProjectMenuQuery("");
      }
    }
    function closeProjectMenuWithEscape(event: KeyboardEvent) {
      if (event.key === "Escape") {
        setProjectMenuOpen(false);
        setProjectMenuQuery("");
      }
    }
    document.addEventListener("pointerdown", closeProjectMenu);
    window.addEventListener("keydown", closeProjectMenuWithEscape);
    return () => {
      document.removeEventListener("pointerdown", closeProjectMenu);
      window.removeEventListener("keydown", closeProjectMenuWithEscape);
    };
  }, [projectMenuOpen]);

  useEffect(() => {
    setAutomationError(null);
    void reconcileProjectAutomation();
  }, [selectedProjectId, reconcileProjectAutomation]);

  useEffect(() => {
    if (!hostMessaging || window.parent === window) return;

    function receiveHostMessage(event: MessageEvent) {
      if (event.source !== window.parent || !event.data || typeof event.data !== "object") return;
      const message = event.data as { type?: string; payload?: unknown; theme?: unknown };

      if (message.type === "taskboard:automation-response" && message.payload) {
        const payload = message.payload as Partial<AutomationHostResponse>;
        if (typeof payload.requestId !== "string") return;
        const pending = pendingAutomationRequestsRef.current.get(payload.requestId);
        if (!pending) return;
        window.clearTimeout(pending.timeoutId);
        pendingAutomationRequestsRef.current.delete(payload.requestId);
        if (payload.ok) pending.resolve(payload as AutomationHostResponse);
        else pending.reject(new Error(
          typeof payload.error === "string" ? payload.error : "宿主无法更新自动化",
        ));
        return;
      }

      if (message.type === "taskboard:theme" && isTheme(message.theme)) {
        setTheme(message.theme);
        return;
      }

      if (message.type === "taskboard:thread-prepared") {
        setOpeningThreadTaskId(null);
        return;
      }

      if (message.type === "taskboard:thread-create-error" && message.payload) {
        const payload = message.payload as { taskId?: unknown; error?: unknown };
        setOpeningThreadTaskId(null);
        setActionError(typeof payload.error === "string" ? payload.error : "无法在宿主中创建对话。");
        return;
      }

      if (message.type === "taskboard:open-issue" && message.payload) {
        // 侧栏深链：tab 已挂载本应用时的卡片点击（同任务重复点击不触发 iframe
        // 重挂，插件改为发消息驱动），按 identifier 直接打开详情。
        const payload = message.payload as { issue?: unknown; projectId?: unknown };
        if (typeof payload.issue === "string" && payload.issue !== "") {
          const projectId = typeof payload.projectId === "string" ? payload.projectId : "";
          if (projectId !== "" && projectId !== selectedProjectIdRef.current) {
            setSelectedProjectId(projectId);
          }
          openTaskDetail({ identifier: payload.issue, projectId });
        }
        return;
      }

      if (message.type !== "taskboard:host-context" || !message.payload) return;
      const payload = message.payload as HostContext;
      setHostContext(payload);
      setCurrentUserActor(payload.user);
      if (isTheme(payload.theme)) setTheme(payload.theme);
    }

    window.addEventListener("message", receiveHostMessage);
    window.parent.postMessage({ type: "taskboard:ready" }, "*");
    return () => {
      window.removeEventListener("message", receiveHostMessage);
      for (const pending of pendingAutomationRequestsRef.current.values()) {
        window.clearTimeout(pending.timeoutId);
      }
      pendingAutomationRequestsRef.current.clear();
    };
  }, [hostMessaging]);

  useLayoutEffect(() => {
    if (!windowDrag || window.parent === window || !dragRegionRef.current) return;
    const region = dragRegionRef.current;
    const publish = () => {
      const rect = region.getBoundingClientRect();
      window.parent.postMessage({
        type: "taskboard:drag-region",
        payload: { x: rect.x, y: rect.y, width: rect.width, height: rect.height },
      }, "*");
    };
    const observer = new ResizeObserver(publish);
    observer.observe(region);
    window.addEventListener("resize", publish);
    publish();
    return () => {
      observer.disconnect();
      window.removeEventListener("resize", publish);
      window.parent.postMessage({ type: "taskboard:drag-region", payload: null }, "*");
    };
  }, [detailTaskId, embedded, selectedProjectId, windowDrag]);

  const loadProjectList = useCallback(async (signal?: AbortSignal) => {
    setProjectsLoading(true);
    setLoadError(null);
    try {
      const [nextProjects, metadata, workspaces] = await Promise.all([
        listProjects(signal),
        getTaskboardMetadata(signal),
        listDeviceWorkspaces(signal),
      ]);
      setTaskboardMetadata((current) => (
        current
        && current.mode === metadata.mode
        && current.realtime?.transport === metadata.realtime?.transport
        && current.realtime?.intervalMs === metadata.realtime?.intervalMs
        && current.manageTaskboardSkillPath === metadata.manageTaskboardSkillPath
        && current.localCapabilities?.available === metadata.localCapabilities?.available
          ? current
          : metadata
      ));
      setManageTaskboardSkillPath(metadata.manageTaskboardSkillPath ?? "");
      setLocalAiChatAvailable(metadata.capabilities?.localAiChat === true);
      setDeviceWorkspacePaths((current) => {
        const next = { ...current, ...workspaces };
        if (JSON.stringify(next) === JSON.stringify(current)) return current;
        window.localStorage.setItem(DEVICE_WORKSPACE_PATHS_KEY, JSON.stringify(next));
        return next;
      });
      setProjects(nextProjects);
      setSelectedProjectId((current) => {
        const fromQuery = getTaskboardLocation().searchParams.get("project");
        const remembered = window.localStorage.getItem(LAST_PROJECT_KEY);
        if (fromQuery && nextProjects.some((project) => project.id === fromQuery)) return fromQuery;
        if (current && nextProjects.some((project) => project.id === current)) return current;
        if (remembered && nextProjects.some((project) => project.id === remembered)) return remembered;
        return "";
      });
    } catch (error) {
      if ((error as Error).name !== "AbortError") setLoadError(errorMessage(error));
    } finally {
      setProjectsLoading(false);
    }
  }, []);

  useEffect(() => {
    const controller = new AbortController();
    void loadProjectList(controller.signal);
    return () => controller.abort();
  }, [loadProjectList]);

  const refreshProjectList = useCallback(async () => {
    try {
      setProjects(await listProjects());
    } catch (error) {
      setLoadError(errorMessage(error));
    }
  }, []);

  const refreshTasks = useCallback(async (
    projectId: string,
    options: { quiet?: boolean; signal?: AbortSignal } = {},
  ) => {
    const requestId = ++tasksRequestRef.current;
    if (!options.quiet) setTasksLoading(true);
    setLoadError(null);
    try {
      const [nextTasks, nextArchivedTasks] = await Promise.all([
        listTasks(projectId, options.signal),
        listArchivedTasks(projectId, options.signal),
      ]);
      if (requestId !== tasksRequestRef.current) return;
      setTasks(sortTasks(nextTasks));
      setArchivedTasks(sortTasks(nextArchivedTasks));
      setHasLoadedTasks(true);
    } catch (error) {
      if ((error as Error).name !== "AbortError" && requestId === tasksRequestRef.current) {
        setLoadError(errorMessage(error));
      }
    } finally {
      if (!options.quiet && requestId === tasksRequestRef.current) setTasksLoading(false);
    }
  }, []);

  useEffect(() => {
    if (!selectedProjectId) {
      setTasks([]);
      setArchivedTasks([]);
      setHasLoadedTasks(false);
      return;
    }
    setHasLoadedTasks(false);
    const controller = new AbortController();
    void refreshTasks(selectedProjectId, { signal: controller.signal });
    return () => controller.abort();
  }, [refreshTasks, selectedProjectId]);

  const refreshWorkflowOptions = useCallback(async (projectId: string, signal?: AbortSignal) => {
    const record = await getWorkflowWorkspace<unknown>(projectId, signal);
    if (!signal?.aborted) setWorkflowOptions(workflowOptionsFromWorkspace(record.workspace));
  }, []);

  useEffect(() => {
    if (!selectedProjectId) {
      setWorkflowOptions(DEFAULT_WORKFLOW_OPTIONS);
      return;
    }
    setWorkflowOptions(workflowOptionsFromWorkspace(readLegacyWorkflowWorkspace(selectedProjectId)));
    const controller = new AbortController();
    void refreshWorkflowOptions(selectedProjectId, controller.signal).catch((error) => {
      if ((error as Error).name !== "AbortError") {
        setWorkflowOptions(workflowOptionsFromWorkspace(readLegacyWorkflowWorkspace(selectedProjectId)));
      }
    });
    return () => controller.abort();
  }, [refreshWorkflowOptions, selectedProjectId]);

  useEffect(() => {
    if (!selectedProjectId) {
      setDevelopmentScan({ workspacePath: null, contexts: [] });
      return;
    }
    const controller = new AbortController();
    const codexProjectId = selectedProjectId === "local" ? hostContext?.projectId : selectedProjectId;
    const codexThreadId = hostContext?.threadId ?? detailTask?.threadId ?? undefined;
    setDevelopmentScan({ workspacePath: selectedDeviceWorkspacePath ?? null, contexts: [] });
    setDevelopmentScanLoading(true);
    void listDevelopmentContexts(
      selectedProjectId,
      codexProjectId,
      codexThreadId,
      controller.signal,
      selectedDeviceWorkspacePath,
    )
      .then((scan) => {
        setDevelopmentScan(scan);
        if (scan.workspacePath) rememberDeviceWorkspacePath(selectedProjectId, scan.workspacePath);
      })
      .catch((error) => {
        if ((error as Error).name !== "AbortError") {
          setDevelopmentScan({ workspacePath: selectedDeviceWorkspacePath ?? null, contexts: [] });
        }
      })
      .finally(() => {
        if (!controller.signal.aborted) setDevelopmentScanLoading(false);
      });
    return () => controller.abort();
  }, [
    detailTask?.threadId,
    hostContext?.projectId,
    hostContext?.threadId,
    rememberDeviceWorkspacePath,
    selectedProjectId,
    selectedDeviceWorkspacePath,
  ]);

  useEffect(() => {
    if (revisionPollingInterval === null) return;
    const controller = new AbortController();
    setConnection("connecting");
    const poller = createRevisionPoller({
      intervalMs: revisionPollingInterval,
      fetchRevision: async (since: number) => {
        try {
          const result = await getTaskboardRevision(since, controller.signal);
          setConnection("live");
          return result;
        } catch (error) {
          if (!controller.signal.aborted) setConnection("reconnecting");
          throw error;
        }
      },
      onInvalidate: () => {
        void refreshProjectList();
        const projectId = selectedProjectIdRef.current;
        if (projectId) {
          void refreshTasks(projectId, { quiet: true });
          void refreshWorkflowOptions(projectId).catch(() => {});
        }
        setWorkflowRevision((current) => current + 1);
        setCommentsRevision((current) => current + 1);
        setAttachmentsRevision((current) => current + 1);
      },
    });
    poller.start();
    return () => {
      controller.abort();
      poller.stop();
    };
  }, [
    revisionPollingInterval,
    refreshProjectList,
    refreshTasks,
    refreshWorkflowOptions,
  ]);

  function pushUndo(message: string, undo: () => Promise<void>, showNotice = true) {
    const operation = { id: ++undoSequenceRef.current, message, undo };
    undoStackRef.current = [...undoStackRef.current.slice(-19), operation];
    setAnnouncementValue("");
    setUndoNotice(showNotice ? { id: operation.id, message } : null);
  }

  async function performUndo() {
    if (undoInFlightRef.current) return;
    const operation = undoStackRef.current.at(-1);
    if (!operation) return;
    undoStackRef.current = undoStackRef.current.slice(0, -1);
    undoInFlightRef.current = true;
    setUndoNotice(null);
    setProjectMenuOpen(false);
    closeContextMenu();
    setActionError(null);
    try {
      await operation.undo();
    } catch (error) {
      setActionError(`无法撤回这次操作：${errorMessage(error)}`);
      if (selectedProjectId) void refreshTasks(selectedProjectId, { quiet: true });
    } finally {
      undoInFlightRef.current = false;
    }
  }

  async function restoreTaskDetails(
    snapshot: Task,
    changed: Task,
    assigneeTarget = assigneeTargetForActor(snapshot.assignee, currentUser),
  ) {
    const candidate = tasksRef.current.find((task) => task.id === changed.id);
    const current = candidate && candidate.version >= changed.version ? candidate : changed;
    const restored = await updateTaskRequest(current, {
      ...taskToDraft(snapshot),
      ...(assigneeTarget ? { assigneeTarget } : {}),
    });
    setTasks((tasks) => sortTasks(tasks.map((task) => task.id === restored.id ? restored : task)));
  }

  useEffect(() => {
    function handleShortcut(event: KeyboardEvent) {
      const target = event.target as HTMLElement | null;
      const isTyping = target?.matches("input, textarea, select, [contenteditable='true']");
      if (
        event.key.toLowerCase() === "z"
        && (event.metaKey || event.ctrlKey)
        && !event.shiftKey
        && !isTyping
        && !editor
      ) {
        event.preventDefault();
        void performUndo();
        return;
      }
      if (isTyping || contextMenu || projectMenuOpen) return;
      if (
        event.key.toLowerCase() === "c"
        && !event.metaKey
        && !event.ctrlKey
        && selectedProjectId
        && !isGlobalView
        && boardView === "issues"
      ) {
        event.preventDefault();
        setEditor({ task: null, status: "todo" });
      }
      if (event.key === "/" && !detailTaskId && selectedProjectId && boardView === "issues") {
        event.preventDefault();
        document.getElementById("task-search")?.focus();
      }
      if (event.key === "Escape" && detailTaskId) {
        closeTaskDetail();
      }
    }

    window.addEventListener("keydown", handleShortcut);
    return () => window.removeEventListener("keydown", handleShortcut);
  }, [boardView, contextMenu, detailTaskId, editor, isGlobalView, projectMenuOpen, selectedProjectId]);

  const filteredTasks = useMemo(() => {
    return tasks.filter(
      (task) => matchesTaskSearch(task, search, language) && matchesTaskFilters(task, filters),
    );
  }, [filters, language, search, tasks]);

  const activeFilterCount = taskFilterCount(filters);
  const hasActiveTaskFilters = Boolean(search.trim()) || activeFilterCount > 0;

  const taskPresentations = useMemo(() => Object.fromEntries(tasks.map((task) => {
    const runningNativeThreadId = hostContext?.threadRunning
      ? hostContext.threadId ?? null
      : null;
    const taskThreadId = normalizeCodexThreadId(task.threadId);
    return [task.id, taskCardPresentation(
      task,
      aiThreads,
      false,
      runningNativeThreadId,
      hostContext?.threadTodoProgress ?? null,
      taskThreadId ? null : undefined,
    )];
  })) as Record<string, TaskCardPresentation>, [
    aiThreads,
    hostContext?.threadId,
    hostContext?.threadRunning,
    hostContext?.threadTodoProgress,
    tasks,
  ]);

  const hasRunningTask = useMemo(
    () => Object.values(taskPresentations).some((presentation) => presentation.processing.running),
    [taskPresentations],
  );

  useEffect(() => {
    setProcessingNow(Date.now());
    if (!hasRunningTask) return;
    const timer = window.setInterval(() => setProcessingNow(Date.now()), 1_000);
    return () => window.clearInterval(timer);
  }, [hasRunningTask]);

  const tasksByStatus = useMemo(() => {
    return Object.fromEntries(
      TASK_STATUSES.map((status) => [status, filteredTasks.filter((task) => task.status === status)]),
    ) as Record<TaskStatus, Task[]>;
  }, [filteredTasks]);

  const laneCollapsed = laneCollapsedByProject[selectedProjectId];
  const laneVisibility = laneVisibilityByProject[selectedProjectId];

  /** 每条列的卡片，按状态顺序拼起来（「等你」= 待验收 + 被阻塞）。 */
  const laneTasks = useMemo(() => {
    return Object.fromEntries(
      BOARD_LANES.map((lane) => [
        lane.id,
        lane.statuses.flatMap((status) => tasksByStatus[status]),
      ]),
    ) as Record<BoardLaneId, Task[]>;
  }, [tasksByStatus]);

  /** 某条列此刻有没有内容——决定它该不该出现在看板上。 */
  function laneHasContent(lane: BoardLane): boolean {
    return lane.statuses.some((status) => tasksByStatus[status].length > 0);
  }

  // 看板上不该出现空列。默认只有「等你」例外：「没有等你的事」本身就是要看的信息，
  // 它消失会让人以为看板坏了。其余列空着就不占地方。
  const visibleLanes = useMemo(
    () => BOARD_LANES.filter((lane) => isLaneVisible(lane, laneHasContent(lane), laneVisibility?.[lane.id] === false)),
    [laneVisibility, tasksByStatus],
  );

  /** 有内容但没显示出来的列（收起来的通道）。 */
  const hiddenLanes = useMemo(
    () => BOARD_LANES
      .filter((lane) => laneHasContent(lane) && !visibleLanes.some((visible) => visible.id === lane.id))
      .map((lane) => lane.id),
    [visibleLanes, tasksByStatus],
  );

  function updateLaneCollapsed(lane: BoardLaneId, collapsed: boolean) {
    if (!selectedProjectId) return;
    setLaneCollapsedByProject((current) => {
      const next = {
        ...current,
        [selectedProjectId]: { ...current[selectedProjectId], [lane]: collapsed },
      };
      window.localStorage.setItem(LANE_COLLAPSED_KEY, JSON.stringify(next));
      return next;
    });
  }

  function updateLaneVisibility(lane: BoardLaneId, visible: boolean) {
    if (!selectedProjectId) return;
    setLaneVisibilityByProject((current) => {
      const next = {
        ...current,
        [selectedProjectId]: { ...current[selectedProjectId], [lane]: visible },
      };
      window.localStorage.setItem(LANE_VISIBILITY_KEY, JSON.stringify(next));
      return next;
    });
  }

  function selectBoardView(view: BoardView) {
    closeContextMenu();
    setGanttViewMenuOpen(false);
    setBoardView(view);
    window.localStorage.setItem("taskboard.boardView", view);
  }

  async function saveEditor(
    draft: TaskDraft,
    attachments: File[],
    inlineImages: PendingInlineImage[],
    runAfterCreate = false,
  ) {
    const targetProjectId = editor?.projectId ?? selectedProjectId;
    if (!targetProjectId || !editor) return;
    setActionError(null);
    try {
      const creating = editor.task === null;
      let saved = editor.task
        ? await updateTaskRequest(editor.task, draft)
        : await createTaskRequest(targetProjectId, draft);
      if (creating) {
        setProjects((current) => current.map((project) => (
          project.id === targetProjectId
            ? { ...project, issueCount: project.issueCount + 1 }
            : project
        )));
      }
      let uploadedAttachments = 0;
      let failedAttachments = 0;
      if (creating && (attachments.length > 0 || inlineImages.length > 0)) {
        const [results, inlineAttachments] = await Promise.all([
          Promise.allSettled(
            attachments.map((file) => uploadAttachment(saved.id, file)),
          ),
          Promise.all(
            inlineImages.map((image) => uploadAttachment(saved.id, image.file)),
          ),
        ]);
        uploadedAttachments = results.filter((result) => result.status === "fulfilled").length;
        failedAttachments = results.length - uploadedAttachments;
        if (inlineImages.length > 0) {
          const description = resolveInlineMediaMarkdown(
            draft.description,
            inlineImages,
            inlineAttachments,
          );
          saved = await updateTaskRequest(saved, { ...draft, description });
        }
      }
      setTasks((current) => sortTasks([
        ...current.filter((task) => task.id !== saved.id),
        saved,
      ]));
      setEditor(null);
      if (failedAttachments > 0) {
        setActionError(`${saved.identifier} 已创建，但有 ${failedAttachments} 个附件上传失败，可在详情页重试。`);
      }
      if (creating) {
        const totalUploaded = uploadedAttachments + inlineImages.length;
        const message = `${saved.identifier} 已创建${totalUploaded > 0 ? `，已上传 ${totalUploaded} 个附件` : ""}。`;
        pushUndo(message, async () => {
          const candidate = tasksRef.current.find((task) => task.id === saved.id);
          const current = candidate && candidate.version >= saved.version ? candidate : saved;
          await archiveTaskRequest(current);
          setTasks((tasks) => tasks.filter((task) => task.id !== saved.id));
        });
        if (runAfterCreate) {
          try {
            await dispatchIssue(saved.id);
          } catch {
            setActionError(`${saved.identifier} 已创建，但自动执行启动失败，可在详情页重试。`);
          }
        }
      } else if (editor.task) {
        const previous = editor.task;
        const previousAssigneeTarget = assigneeTargetForActor(previous.assignee, currentUser);
        if (!draft.assigneeTarget || previousAssigneeTarget) {
          pushUndo(
            `${saved.identifier} 已更新。`,
            () => restoreTaskDetails(previous, saved, previousAssigneeTarget),
          );
        }
      }
    } catch (error) {
      if (error instanceof ApiError && error.code === "VERSION_CONFLICT") {
        void refreshTasks(selectedProjectId, { quiet: true });
      }
      throw error;
    }
  }

  async function moveTask(
    task: Task,
    status: TaskStatus,
    beforeTaskId: string | null = null,
    silent = false,
  ) {
    if (movingTaskId) {
      setDropTarget(null);
      setDraggedTaskId(null);
      setDraggedTaskHeight(0);
      return;
    }

    const destination = tasks.filter((candidate) => candidate.status === status && candidate.id !== task.id);
    const insertionIndex = beforeTaskId
      ? destination.findIndex((candidate) => candidate.id === beforeTaskId)
      : destination.length;
    const targetIndex = insertionIndex < 0 ? destination.length : insertionIndex;
    const desiredOrder = [...destination];
    desiredOrder.splice(targetIndex, 0, task);
    const currentOrder = tasks.filter((candidate) => candidate.status === status);
    if (
      task.status === status
      && currentOrder.length === desiredOrder.length
      && currentOrder.every((candidate, index) => candidate.id === desiredOrder[index].id)
    ) {
      setDropTarget(null);
      setDraggedTaskId(null);
      setDraggedTaskHeight(0);
      return;
    }
    const previousTask = destination[targetIndex - 1] ?? null;
    const nextTask = destination[targetIndex] ?? null;
    const sortOrder = previousTask && nextTask
      ? (previousTask.sortOrder + nextTask.sortOrder) / 2
      : previousTask
        ? previousTask.sortOrder + 1024
        : nextTask
          ? nextTask.sortOrder - 1024
          : 1024;
    const previous = task;
    setActionError(null);
    setMovingTaskId(task.id);
    setTasks((current) => sortTasks(current.map((candidate) =>
      candidate.id === task.id ? { ...candidate, status, sortOrder } : candidate,
    )));

    try {
      const moved = await moveTaskRequest(task, status, sortOrder);
      setTasks((current) => sortTasks(current.map((candidate) =>
        candidate.id === moved.id ? moved : candidate,
      )));
      const message = task.status === status
        ? `${task.identifier} 排序已调整。`
        : `${task.identifier} 已移至${STATUS_DETAILS[status].label}。`;
      pushUndo(message, async () => {
        const candidate = tasksRef.current.find((current) => current.id === moved.id);
        const current = candidate && candidate.version >= moved.version ? candidate : moved;
        const restored = await moveTaskRequest(current, previous.status, previous.sortOrder);
        setTasks((tasks) => sortTasks(tasks.map((item) => item.id === restored.id ? restored : item)));
      }, !silent);
    } catch (error) {
      setTasks((current) => sortTasks(current.map((candidate) =>
        candidate.id === previous.id ? previous : candidate,
      )));
      setActionError(error instanceof ApiError && error.code === "VERSION_CONFLICT"
        ? "That issue changed elsewhere. The board has been refreshed."
        : errorMessage(error));
      if (selectedProjectId) void refreshTasks(selectedProjectId, { quiet: true });
    } finally {
      setMovingTaskId(null);
      setDropTarget(null);
      setDraggedTaskId(null);
      setDraggedTaskHeight(0);
    }
  }

  function finishTaskDrop(destination: TaskStatus, taskId: string, beforeTaskId: string | null = null) {
    const task = tasks.find((candidate) => candidate.id === taskId);
    setDraggedTaskId(null);
    setDraggedTaskHeight(0);
    setDropTarget(null);
    if (!task) return;
    setSettlingTaskId(task.id);
    window.setTimeout(() => {
      setSettlingTaskId((current) => current === task.id ? null : current);
    }, 220);
    void moveTask(task, destination, beforeTaskId, true);
  }

  async function updateTaskProperties(task: Task, changes: Partial<TaskDraft>, message?: string): Promise<Task> {
    const previous = task;
    const { assigneeTarget, ...taskChanges } = changes;
    const optimisticAssignee = assigneeTarget
      ? actorForAssigneeTarget(assigneeTarget, currentUser)
      : task.assignee;
    setActionError(null);
    setTasks((current) => current.map((candidate) =>
      candidate.id === task.id
        ? { ...candidate, ...taskChanges, assignee: optimisticAssignee }
        : candidate,
    ));

    try {
      const updated = await updateTaskRequest(task, { ...taskToDraft(task), ...changes });
      setTasks((current) => sortTasks(current.map((candidate) =>
        candidate.id === updated.id ? updated : candidate,
      )));
      const previousAssigneeTarget = assigneeTargetForActor(previous.assignee, currentUser);
      if (!assigneeTarget || previousAssigneeTarget) {
        pushUndo(
          message ?? `${task.identifier} 已更新。`,
          () => restoreTaskDetails(previous, updated, previousAssigneeTarget),
        );
      }
      return updated;
    } catch (error) {
      setTasks((current) => sortTasks(current.map((candidate) =>
        candidate.id === previous.id ? previous : candidate,
      )));
      setActionError(error instanceof ApiError && error.code === "VERSION_CONFLICT"
        ? "该议题已在其他位置更新，看板已重新同步。"
        : errorMessage(error));
      if (selectedProjectId) void refreshTasks(selectedProjectId, { quiet: true });
      throw error;
    }
  }

  /**
   * Acceptance from the board card: the human verified the work out in the
   * product, not in the issue text, so the gate follows them — flip to done
   * and post their acceptance message, then resync the board.
   */
  async function acceptIssueFromCard(task: Task) {
    setActionError(null);
    try {
      await acceptIssue(task, text("确认完成", "Accepted"));
      if (selectedProjectId) void refreshTasks(selectedProjectId, { quiet: true });
      setAnnouncement(text(`${task.identifier} 已验收。`, `${task.identifier} accepted.`));
    } catch (error) {
      setActionError(errorMessage(error));
      if (selectedProjectId) void refreshTasks(selectedProjectId, { quiet: true });
    }
  }

  async function mutateTaskRelation(
    action: "add" | "remove",
    task: Task,
    type: IssueRelationType,
    relatedTaskId: string,
  ) {
    setActionError(null);
    try {
      const result = action === "add"
        ? await addTaskRelation(task, type, relatedTaskId)
        : await removeTaskRelation(task, type, relatedTaskId);
      setTasks((current) => sortTasks(current.map((candidate) => {
        if (candidate.id === result.task.id) return result.task;
        if (candidate.id === result.relatedTask.id) return result.relatedTask;
        return candidate;
      })));
      if (selectedProjectId) void refreshTasks(selectedProjectId, { quiet: true });
      return result;
    } catch (error) {
      setActionError(error instanceof ApiError && error.code === "VERSION_CONFLICT"
        ? "该议题已在其他位置更新，看板已重新同步。"
        : errorMessage(error));
      if (selectedProjectId) void refreshTasks(selectedProjectId, { quiet: true });
      throw error;
    }
  }

  async function duplicateTask(task: Task) {
    setActionError(null);
    try {
      const duplicated = await createTaskRequest(task.projectId, {
        ...taskToDraft(task),
        assigneeTarget: assigneeTargetForActor(task.assignee, currentUser),
        developmentContext: null,
      });
      setTasks((current) => sortTasks([...current, duplicated]));
      pushUndo(`${duplicated.identifier} 副本已创建。`, async () => {
        const candidate = tasksRef.current.find((current) => current.id === duplicated.id);
        const current = candidate && candidate.version >= duplicated.version ? candidate : duplicated;
        await archiveTaskRequest(current);
        setTasks((tasks) => tasks.filter((item) => item.id !== duplicated.id));
      });
    } catch (error) {
      setActionError(errorMessage(error));
    }
  }

  async function archiveTask(task: Task) {
    setActionError(null);
    try {
      const archived = await archiveTaskRequest(task);
      setTasks((current) => current.filter((candidate) => candidate.id !== task.id));
      setArchivedTasks((current) => sortTasks([
        ...current.filter((candidate) => candidate.id !== archived.id),
        archived,
      ]));
      pushUndo(`${task.identifier} 已归档。`, async () => {
        const restored = await restoreTaskRequest(archived);
        setArchivedTasks((current) => current.filter((candidate) => candidate.id !== restored.id));
        setTasks((current) => sortTasks([
          ...current.filter((candidate) => candidate.id !== restored.id),
          restored,
        ]));
      });
    } catch (error) {
      setActionError(error instanceof ApiError && error.code === "VERSION_CONFLICT"
        ? "该议题已在其他位置更新，看板已重新同步。"
        : errorMessage(error));
      if (selectedProjectId) void refreshTasks(selectedProjectId, { quiet: true });
    }
  }

  async function restoreArchivedTask(task: Task) {
    setActionError(null);
    setRestoringTaskId(task.id);
    try {
      const restored = await restoreTaskRequest(task);
      setArchivedTasks((current) => current.filter((candidate) => candidate.id !== restored.id));
      setTasks((current) => sortTasks([
        ...current.filter((candidate) => candidate.id !== restored.id),
        restored,
      ]));
      setAnnouncement(`${restored.identifier} 已恢复。`);
    } catch (error) {
      setActionError(error instanceof ApiError && error.code === "VERSION_CONFLICT"
        ? "该议题已在其他位置更新，看板已重新同步。"
        : errorMessage(error));
      if (selectedProjectId) void refreshTasks(selectedProjectId, { quiet: true });
    } finally {
      setRestoringTaskId(null);
    }
  }

  async function deleteArchivedTask(task: Task) {
    setActionError(null);
    setDeletingArchivedTaskId(task.id);
    try {
      await deleteArchivedTaskRequest(task);
      setArchivedTasks((current) => current.filter((candidate) => candidate.id !== task.id));
      setPendingArchivedTaskDelete(null);
      setAnnouncement(`${task.identifier} 已永久删除。`);
    } catch (error) {
      setActionError(error instanceof ApiError && error.code === "VERSION_CONFLICT"
        ? "该议题已在其他位置更新，看板已重新同步。"
        : errorMessage(error));
      if (selectedProjectId) void refreshTasks(selectedProjectId, { quiet: true });
    } finally {
      setDeletingArchivedTaskId(null);
    }
  }

  async function copyText(text: string, message: string) {
    try {
      await navigator.clipboard.writeText(text);
      setAnnouncement(message);
    } catch {
      setActionError("无法写入剪贴板。");
    }
  }

  function openThread(threadId: string) {
    const trimmed = threadId.trim();
    // 早期共享线程 id（心跳机制升级前所有 dsh 认领共用）没有对应独立会话，
    // 回退到 dsh 会话浏览页。
    if (trimmed === "dsh-heartbeat") {
      window.open(`${DSH_WEB_URL}/sessions`, "_blank", "noopener,noreferrer");
      setAnnouncement(`${trimmed} 为早期共享线程 id，无对应独立会话，已打开 dsh 会话页。`);
      return;
    }
    // dsh 心跳线程由 DeepSeek Harness 执行，外部宿主无对应对话：
    // headless 会话 id 与线程 id 一致（runner 每次运行生成 dsh-<uuid> 并注入
    // DSH_SESSION_ID），因此用 ?session= 深链直达该次执行的真实会话。
    if (isDshThreadId(trimmed)) {
      // 宿主（codex/dsh）内嵌时交给宿主在当前页面内切换会话，不新开页面；
      // 独立模式回退到 dsh 深链新标签。
      if (hostMessaging && window.parent !== window) {
        window.parent.postMessage({
          type: "taskboard:open-thread",
          payload: { threadId: trimmed },
        }, "*");
        return;
      }
      window.open(`${DSH_WEB_URL}/?session=${encodeURIComponent(trimmed)}`, "_blank", "noopener,noreferrer");
      setAnnouncement(`${trimmed} 由 DeepSeek Harness 执行，已打开对应会话。`);
      return;
    }

    if (embedded && window.parent !== window) {
      window.parent.postMessage({ type: "taskboard:open-thread", payload: { threadId: trimmed } }, "*");
      return;
    }

    // 非 DSH 线程（如 AI 对话引擎创建的外部线程）：没有独立的本地会话页，
    // 打开 DSH 会话浏览页兜底。
    window.open(`${DSH_WEB_URL}/sessions`, "_blank", "noopener,noreferrer");
    setAnnouncement("该线程没有对应的本地会话，已打开会话浏览页。");
  }

  function openTaskConversation(conversation: TaskConversationItem) {
    if (conversation.kind === "local-ai" && conversation.aiThreadId) {
      setAiOpenThreadRequest((current) => ({
        threadId: conversation.aiThreadId!,
        requestId: (current?.requestId ?? 0) + 1,
      }));
      return;
    }
    if (conversation.nativeThreadId) openThread(conversation.nativeThreadId);
  }

  function expandCodexSidebar() {
    if (!embedded || window.parent === window) return;
    window.parent.postMessage({ type: "taskboard:expand-sidebar" }, "*");
  }

  function openTaskInThread(task: Task) {
    const threadId = task.threadId?.trim() ?? "";
    // dsh 心跳线程：直接打开该次执行的 dsh 会话，而不是新建外部对话。
    if (isDshThreadId(threadId)) {
      // 宿主（codex/dsh）内嵌时交给宿主在当前页面内切换会话，不新开页面；
      // 独立模式回退到 dsh 深链新标签。
      if (hostMessaging && window.parent !== window) {
        window.parent.postMessage({
          type: "taskboard:open-thread",
          payload: { threadId },
        }, "*");
        return;
      }
      window.open(`${DSH_WEB_URL}/?session=${encodeURIComponent(threadId)}`, "_blank", "noopener,noreferrer");
      setAnnouncement(`已打开 DeepSeek Harness 会话 ${threadId}。`);
      return;
    }
    if (!manageTaskboardSkillPath) {
      setActionError("任务面板还没有读取到 manage-taskboard Skill 路径，请刷新后重试。");
      return;
    }
    const worktreePath = task.developmentContext?.type === "worktree"
      ? task.developmentContext.path
      : null;
    const workspacePath = worktreePath
      ?? selectedDeviceWorkspacePath
      ?? developmentScan.workspacePath
      ?? hostContext?.workspacePath;
    const instruction = `e-taskboard Addressing the issues mentioned in ${task.identifier}`;
    const prompt = `[$manage-taskboard](${manageTaskboardSkillPath}) ${instruction}`;

    // host=dsh：在同一 GUI 内驱动真实 DSH 会话（由插件宿主监听执行）。
    // 判据只看「有没有宿主父窗口 + 宿主协议」，不再要求 host=codex：
    // 看板主面板由 PanelFrame 以 host=dsh 挂载，旧判据会把它的「让 AI 执行」
    // 误判成独立模式，直接报「请在 DSH Web GUI 中以插件方式打开看板」。
    // 只有真·独立模式（裸标签页，window.parent 就是自己）才没有执行通道——
    // 不要向自身 postMessage（会被静默丢弃）。
    if (window.parent !== window && hostMessaging) {
      window.parent.postMessage({
        type: "taskboard:dsh-execute",
        payload: {
          taskId: task.id,
          identifier: task.identifier,
          prompt,
          workspacePath,
          projectId: selectedProject?.id ?? null,
        },
      }, "*");
      return;
    }
    if (openingThreadTaskId) return;
    const codexProject = hostContext?.projects?.find((project) => project.id === selectedProject?.id);
    setOpeningThreadTaskId(task.id);
    setActionError(null);
    window.parent.postMessage({
      type: "taskboard:create-thread",
      payload: {
        taskId: task.id,
        identifier: task.identifier,
        instruction,
        skillName: "manage-taskboard",
        skillDisplayName: "Manage Taskboard",
        skillPath: manageTaskboardSkillPath,
        codexProjectId: codexProject?.id ?? (selectedProject?.id === "local" ? hostContext?.projectId : selectedProject?.id),
        projectName: selectedProject?.name,
        workspacePath,
        workspaceLabel: worktreePath ? workspaceName(worktreePath) : undefined,
      },
    }, "*");
  }

  function changeProject(projectId: string) {
    closeContextMenu();
    setProjectMenuOpen(false);
    setDetailTaskIdentifier(null);
    setBoardView("issues");
    setSelectedProjectId(projectId);
    window.localStorage.setItem(LAST_PROJECT_KEY, projectId);
    rememberProjectUsage(projectId);
    setSearch("");
    setFilters(EMPTY_TASK_FILTERS);
    setActionError(null);
    undoStackRef.current = [];
    setUndoNotice(null);
    const url = buildIssueUrl(getTaskboardLocation().href, projectId, null);
    taskboardReplaceState(null, url);
  }

  function returnToProjectHome() {
    closeContextMenu();
    setProjectMenuOpen(false);
    setDetailTaskIdentifier(null);
    setSelectedProjectId("");
    window.localStorage.removeItem(LAST_PROJECT_KEY);
    setSearch("");
    setFilters(EMPTY_TASK_FILTERS);
    setActionError(null);
    undoStackRef.current = [];
    setUndoNotice(null);
    const url = buildIssueUrl(getTaskboardLocation().href, null, null);
    taskboardReplaceState(null, url);
    void loadProjectList();
  }

  async function selectProject(choice: ProjectChoice) {
    if (openingProjectId) return;
    setOpeningProjectId(choice.id);
    setActionError(null);
    try {
      let project = projects.find((candidate) => candidate.id === choice.id) ?? null;
      if (!project) {
        // Projects mirror DSH workspaces (the host half syncs them); never
        // create a standalone project here. A missing row means the sync
        // hasn't caught up yet — refresh and retry.
        const nextProjects = await listProjects();
        setProjects(nextProjects);
        project = nextProjects.find((candidate) => candidate.id === choice.id) ?? null;
        if (!project) {
          setAnnouncement("项目尚未同步：请先在 DSH 中打开该目录（注册为工作区），看板会自动跟随。");
          return;
        }
      }
      changeProject(project.id);
    } catch (error) {
      setActionError(errorMessage(error));
    } finally {
      setOpeningProjectId(null);
    }
  }

  const contextName = workspaceName(hostContext?.workspacePath);
  // Compact chrome reuses the same tools node in the header actions row, so
  // the sidebar spends one row instead of two on search/filter.
  const toolbarTools = (boardView === "issues" || boardView === "list" || boardView === "gantt") ? (
    <div className="toolbar-tools">
            <label className={`search-field${search ? " has-value" : ""}`} title={text("搜索议题 (/)", "Search issues (/)")} >
              <LinearIcon className="search-icon" name="search" />
              <span className="sr-only">{text("搜索议题", "Search issues")}</span>
              <input
                id="task-search"
                type="search"
                value={search}
                onChange={(event) => setSearch(event.target.value)}
                placeholder={text("搜索议题…", "Search issues…")}
              />
              {!search && <kbd>/</kbd>}
            </label>
            {boardView === "gantt" && (
              <div className="gantt-toolbar-controls">
                <label className="gantt-hide-completed">
                  <input type="checkbox" checked={ganttHideCompleted} onChange={(event) => setGanttHideCompleted(event.target.checked)} />
                  <i><LinearIcon name="check" /></i>
                  <span>{text("隐藏已完成", "Hide completed")}</span>
                </label>
                <button type="button" className="gantt-today-button" onClick={() => setGanttTodayRequest((current) => current + 1)}>{text("今天", "Today")}</button>
                <div className="gantt-view-menu-wrap">
                  <button type="button" className="gantt-view-menu-trigger" aria-label={text("时间轴视图选项", "Timeline view options")} aria-expanded={ganttViewMenuOpen} onClick={() => setGanttViewMenuOpen((current) => !current)}>
                    <LinearIcon name="more" />
                  </button>
                  {ganttViewMenuOpen && (
                    <div className="gantt-view-menu" role="menu">
                      {GANTT_ZOOM_OPTIONS.map((value) => (
                        <button type="button" role="menuitemradio" aria-checked={ganttZoom === value} className={ganttZoom === value ? "active" : ""} onClick={() => { setGanttZoom(value); setGanttViewMenuOpen(false); }} key={value}>
                          <span>{language === "zh"
                            ? { day: "日视图", week: "周视图", month: "月视图" }[value]
                            : { day: "Day", week: "Week", month: "Month" }[value]}</span>
                          {ganttZoom === value && <LinearIcon name="check" />}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            )}
            <TaskFilterMenu
              tasks={tasks}
              search={search}
              labels={availableLabels}
              filters={filters}
              onChange={setFilters}
            />
            {(search || activeFilterCount > 0) && (
              <button
                className="clear-filter"
                type="button"
                aria-label="清除筛选"
                title="清除筛选"
                onClick={() => { setSearch(""); setFilters(EMPTY_TASK_FILTERS); }}
              >
                <LinearIcon name="close" />
              </button>
            )}
    </div>
  ) : null;

  const headerProjectName = selectedProject?.name ?? "任务面板";
  const appShellStyle = embedded
    ? { "--codex-titlebar-left-inset": `${hostContext?.titlebarLeftInset ?? 0}px` } as CSSProperties
    : undefined;

  return (
    <TaskboardLanguageProvider language={language}>
    <div className={`app-shell${embedded ? " embedded" : ""}${windowDrag ? " window-drag" : ""}${compact ? " compact" : ""}`} style={appShellStyle}>
      {taskboardMetadata && taskboardMetadata.mode !== "cloud" && (
        <LocalRealtimeSync
          selectedProjectId={selectedProjectId}
          detailTaskId={detailTaskId}
          refreshProjectList={refreshProjectList}
          refreshTasks={refreshTasks}
          refreshWorkflowOptions={refreshWorkflowOptions}
          setConnection={setConnection}
          setCommentsRevision={setCommentsRevision}
          setAttachmentsRevision={setAttachmentsRevision}
        />
      )}
      {!embedded && !navCollapsed && (
        <aside
          className="app-nav"
          aria-label="Taskboard navigation"
        >
          <div className="brand-row">
            <span className="brand-mark" aria-hidden="true"><LinearIcon name="project" /></span>
            <span>任务面板</span>
            <button
              className="nav-collapse-button"
              type="button"
              title="折叠侧边栏"
              aria-label="折叠侧边栏"
              aria-expanded={true}
              onClick={toggleNavCollapsed}
            >
              <LinearIcon name="chevronLeft" />
            </button>
          </div>

          <nav className="primary-nav" aria-label="Views">
            <span className="nav-label">工作区</span>
            <button className="nav-item active" type="button" aria-current="page">
              <span className="nav-glyph" aria-hidden="true">
                <LinearIcon name="myIssues" />
              </span>
              议题
              <span className="nav-count">{tasks.length}</span>
            </button>
          </nav>

          <div className="project-nav">
            <span className="nav-label">项目</span>
            {sortedSidebarProjects.map((project) => (
              <button
                key={project.id}
                type="button"
                className={`project-nav-item${selectedProjectId === project.id ? " active" : ""}`}
                onClick={() => changeProject(project.id)}
              >
                <span
                  className={`project-dot${project.automationEnabled ? " has-automation" : ""}`}
                  aria-hidden="true"
                  title={project.automationEnabled ? "已开启自动认领" : undefined}
                />
                <span>{project.name}</span>
              </button>
            ))}
          </div>

          <div className="nav-spacer" />
          <div className="nav-footer">
            <div className={`connection connection-${connection}`}>
              <span aria-hidden="true" />
              {connection === "live" ? "实时同步" : "正在重新连接…"}
            </div>
          </div>
        </aside>
      )}
      {!embedded && navCollapsed && !selectedProjectId && (
        <button
          className="nav-expand-button"
          type="button"
          title="打开侧边栏"
          aria-label="打开侧边栏"
          onClick={toggleNavCollapsed}
        >
          <LinearIcon name="chevronRight" />
        </button>
      )}

      <main className="workspace">
        {selectedProjectId ? (
          <header className="workspace-header">
          <div className="workspace-title">
            <div className="workspace-kicker">
              {/* 议题 09582F74F86A-137：紧凑面板（右侧边栏）里 SPA 自己的项目侧栏
                  被 CSS 永久隐藏，这个「打开侧边栏」箭头点了没有任何效果，所以只在
                  非紧凑的完整形态里渲染。 */}
              {!embedded && !compact && navCollapsed && (
                <button
                  className="detail-back-button nav-expand-inline"
                  type="button"
                  aria-label="打开侧边栏"
                  title="打开侧边栏"
                  onClick={toggleNavCollapsed}
                >
                  <LinearIcon name="chevronRight" />
                </button>
              )}
              {detailTask && (
                <button
                  className="detail-back-button"
                  type="button"
                  aria-label="返回议题看板"
                  title="返回议题看板 (Esc)"
                  onClick={closeTaskDetail}
                >
                  <LinearIcon name="chevronLeft" />
                </button>
              )}
              {embedded && hostContext?.sidebarCollapsed && (
                <button
                  className="detail-back-button codex-sidebar-expand-button"
                  type="button"
                  aria-label="展开宿主侧边栏"
                  title="展开侧边栏"
                  onClick={expandCodexSidebar}
                >
                  <LinearIcon name="codexSidebarExpand" />
                </button>
              )}
              {selectedProjectId && (
                <button
                  className="detail-back-button project-home-button"
                  type="button"
                  aria-label="返回项目首页"
                  title="返回项目首页"
                  onClick={returnToProjectHome}
                >
                  <LinearIcon name="home" />
                  <span>首页</span>
                </button>
              )}
              {selectedProjectId && !isGlobalView && (
                <button
                  className="global-view-button"
                  type="button"
                  aria-label="切换到全局模式"
                  title="切换到全局模式"
                  onClick={() => changeProject("local")}
                >
                  <LinearIcon name="dashboard" />
                </button>
              )}
              {selectedProjectId && <span className="breadcrumb-chevron" aria-hidden="true"><LinearIcon name="chevronRight" /></span>}
              {selectedProjectId ? (
                <div className="header-project-switcher" data-project-switcher>
                  <button
                    className="header-project-button"
                    type="button"
                    aria-label="切换项目"
                    aria-haspopup="menu"
                    aria-expanded={projectMenuOpen}
                    onClick={() => { setProjectMenuQuery(""); setProjectMenuOpen((current) => !current); }}
                  >
                    <span className="project-name">{headerProjectName}</span>
                    <LinearIcon className="project-switcher-chevron" name="chevronDown" />
                  </button>
                  {projectMenuOpen && (
                    <div className="header-project-menu" role="menu" aria-label="项目">
                      <input
                        className="header-project-search"
                        type="text"
                        placeholder="搜索项目…"
                        aria-label="搜索项目"
                        autoFocus
                        value={projectMenuQuery}
                        onChange={(event) => setProjectMenuQuery(event.target.value)}
                      />
                      {filteredProjectMenuChoices.map((project) => (
                        <button
                          type="button"
                          role="menuitemradio"
                          aria-checked={project.id === selectedProjectId}
                          disabled={openingProjectId !== null}
                          key={project.id}
                          onClick={() => {
                            setProjectMenuQuery("");
                            if (project.id === selectedProjectId) setProjectMenuOpen(false);
                            else void selectProject(project);
                          }}
                        >
                          <span>{project.name}</span>
                          {favoriteProjectIds.has(project.id) && <span className="project-menu-favorite" aria-label="已收藏"><LinearIcon name="favorite" /></span>}
                          {project.id === selectedProjectId && <span className="project-menu-check" aria-hidden="true"><LinearIcon name="check" /></span>}
                        </button>
                      ))}
                      {filteredProjectMenuChoices.length === 0 && (
                        <span className="header-project-empty">没有匹配的项目</span>
                      )}
                    </div>
                  )}
                </div>
              ) : (
                <>
                  <span className="project-name">{headerProjectName}</span>
                </>
              )}
              {!selectedProjectId && (
                <>
                  <span className="breadcrumb-chevron" aria-hidden="true"><LinearIcon name="chevronRight" /></span>
                  <strong>项目</strong>
                </>
              )}
              {!detailTask && selectedProjectId && embedded && contextName && <span className="codex-context">{contextName}</span>}
            </div>
          </div>

          <div ref={dragRegionRef} className="workspace-drag-region" aria-hidden="true" />

          <div className="header-actions">
            {/* 自动认领开关也是列表/项目视角的图标：详情打开时收起，避免歧义。 */}
            {selectedProjectId && !detailTask && (
              <ProjectAutomationMenu
                automation={selectedProjectAutomation}
                projectId={selectedProjectId}
                models={claimModelChoices}
                modelLabels={claimModelLabels}
                pending={automationPending}
                error={automationError}
                sessionBindingSupported={sessionBindingSupported === true}
                unavailableReason={automationProjectContext.unavailableReason}
                onOpen={() => {
                  void reconcileProjectAutomation();
                  void getClaimModels().then((catalog) => {
                    setClaimModelChoices(catalog.providers.flatMap((entry) =>
                      entry.models.map((model) => `${entry.provider}::${model}`),
                    ));
                    setClaimModelLabels(Object.fromEntries(
                      catalog.providers.map((entry) => [entry.provider, entry.label ?? entry.provider]),
                    ));
                  }).catch(() => {});
                }}
                onChange={(options) => void saveProjectAutomation(options)}
              />
            )}
            {compact && detailTask && (
              <button
                className="icon-button issue-properties-toggle"
                type="button"
                aria-expanded={!propertiesCollapsed}
                aria-label={propertiesCollapsed ? text("显示属性", "Show properties") : text("隐藏属性", "Hide properties")}
                title={propertiesCollapsed ? text("显示属性", "Show properties") : text("隐藏属性", "Hide properties")}
                onClick={() => setPropertiesCollapsed((current) => !current)}
              >
                <TaskboardIcon
                  name="dropdown"
                  style={propertiesCollapsed ? undefined : { transform: "rotate(180deg)" }}
                />
              </button>
            )}
            {/* 详情态隐藏列表工具（搜索/筛选/看板设置都是列表视角的功能）。 */}
            {compact && !detailTask && toolbarTools}
            {/* Compact chrome view toggle: the sidebar embed opens on the list,
                so the header icon row gets the one switch it hides — list ⟷
                issue board (the same views the full app's tabs offer). */}
            {compact && !detailTask && (boardView === "list" || boardView === "issues") && (
              <button
                className="icon-button"
                type="button"
                aria-label={boardView === "list" ? text("切换为看板视图", "Switch to board view") : text("切换为列表视图", "Switch to list view")}
                title={boardView === "list" ? text("切换为看板视图", "Switch to board view") : text("切换为列表视图", "Switch to list view")}
                onClick={() => selectBoardView(boardView === "list" ? "issues" : "list")}
              >
                <LinearIcon name={boardView === "list" ? "boardView" : "listView"} />
              </button>
            )}
            {selectedProjectId && boardView !== "workflow" && (
              <div className="header-create-anchor">
                <button
                  className="icon-button header-create-button"
                  type="button"
                  onClick={() => {
                    if (isGlobalView) setGlobalCreateMenuOpen((current) => !current);
                    else setEditor({ task: null, status: "todo" });
                  }}
                  aria-label={text("新建议题", "Create issue")}
                  title={isGlobalView ? text("新建议题（先选项目）", "Create issue (pick a project)") : text("新建议题 (C)", "Create issue (C)")}
                >
                  <TaskboardIcon name="create" />
                </button>
                {isGlobalView && globalCreateMenuOpen && (
                  <div className="sidebar-project-menu global-create-menu" role="menu" aria-label="选择议题所属项目">
                    {globalCreateProjects.map((project) => (
                      <button
                        key={project.id}
                        type="button"
                        role="menuitem"
                        onClick={() => {
                          setGlobalCreateMenuOpen(false);
                          setEditor({ task: null, status: "todo", projectId: project.id });
                        }}
                      >
                        <span className="project-dot" aria-hidden="true" />
                        <span>{project.name}</span>
                      </button>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>
          </header>
        ) : (
          <div ref={dragRegionRef} className="home-window-drag-region" aria-hidden="true" />
        )}

        {selectedProjectId && !detailTask && <div className="board-toolbar">
          <div className="view-tabs" aria-label="看板视图">
            <button
              className={`view-tab${boardView === "dashboard" ? " active" : ""}`}
              type="button"
              aria-pressed={boardView === "dashboard"}
              onClick={() => selectBoardView("dashboard")}
            >
              {text("仪表盘", "Dashboard")}
            </button>
            <button
              className={`view-tab${boardView === "issues" ? " active" : ""}`}
              type="button"
              aria-pressed={boardView === "issues"}
              onClick={() => selectBoardView("issues")}
            >
              {text("议题看板", "Issue board")}
            </button>
            <button
              className={`view-tab${boardView === "list" ? " active" : ""}`}
              type="button"
              aria-pressed={boardView === "list"}
              onClick={() => selectBoardView("list")}
            >
              {text("列表视图", "List")}
            </button>
            <button
              className={`view-tab${boardView === "gantt" ? " active" : ""}`}
              type="button"
              aria-pressed={boardView === "gantt"}
              onClick={() => selectBoardView("gantt")}
            >
              {text("甘特图", "Gantt")}
            </button>
            {SHOW_WORKFLOW_BOARD_ENTRY && (
              <button
                className={`view-tab${boardView === "workflow" ? " active" : ""}`}
                type="button"
                aria-pressed={boardView === "workflow"}
                onClick={() => selectBoardView("workflow")}
              >
                {text("节点模式", "Workflow")}
              </button>
            )}
          </div>
          {toolbarTools}
        </div>}

        {(loadError || actionError) && (
          <div className="error-banner" role="alert">
            <span className="error-mark" aria-hidden="true"><LinearIcon name="alert" /></span>
            <div><strong>Taskboard needs attention</strong><p>{actionError ?? loadError}</p></div>
            <button
              type="button"
              onClick={() => {
                setActionError(null);
                if (selectedProjectId) void refreshTasks(selectedProjectId);
                else void loadProjectList();
              }}
            >
              Try again
            </button>
          </div>
        )}

        {!selectedProjectId ? (
          <section className="project-home">
            <div className="project-home-heading">
              <span>任务面板</span>
              <h1>选择项目</h1>
              <p>从已保存的项目开始，或继续使用之前保存的项目。</p>
            </div>
            {projectsLoading ? (
              <div className="project-grid project-grid-loading" aria-label="正在加载项目" aria-busy="true">
                <span /><span /><span />
              </div>
            ) : projectChoices.length > 0 ? (
              <div className="project-home-groups">
                {[
                  { id: "with-issues", title: "已有议题", projects: projectsWithIssues },
                  { id: "without-issues", title: "尚未添加议题", projects: projectsWithoutIssues },
                ].map((group) => (
                  <section className="project-home-group" key={group.id} aria-labelledby={`project-group-${group.id}`}>
                    <div className="project-group-heading">
                      <h2 id={`project-group-${group.id}`}>{group.title}</h2>
                      <span>{group.projects.length}</span>
                    </div>
                    {group.projects.length > 0 ? (
                      <div className="project-grid">
                        {group.projects.map((project) => (
                          <div className="project-card" key={project.id}>
                            <button
                              className="project-card-open"
                              type="button"
                              disabled={openingProjectId !== null}
                              onClick={() => void selectProject(project)}
                            >
                              <span className="project-card-avatar" aria-hidden="true">
                                {project.name.slice(0, 1).toUpperCase()}
                              </span>
                              <span className="project-card-copy">
                                <strong>{project.name}</strong>
                                <span>
                                  {project.inCodex ? "宿主项目" : "已保存的项目"}
                                  {project.issueCount > 0 ? ` · ${project.issueCount} 个议题` : ""}
                                </span>
                              </span>
                              {favoriteProjectIds.has(project.id) && <span className="project-card-favorite" aria-label="已收藏"><LinearIcon name="favorite" /></span>}
                              <span className="project-card-action" aria-hidden="true">
                                {openingProjectId === project.id ? "正在打开…" : <LinearIcon name="chevronRight" />}
                              </span>
                            </button>
                            <label className="project-card-directory">
                              <LinearIcon name="folder" />
                              <input
                                key={deviceWorkspacePaths[project.id] ?? ""}
                                type="text"
                                defaultValue={deviceWorkspacePaths[project.id] ?? ""}
                                placeholder="设置此设备的项目目录"
                                aria-label={`${project.name} 在此设备上的项目目录`}
                                onBlur={(event) => rememberDeviceWorkspacePath(project.id, event.currentTarget.value)}
                                onKeyDown={(event) => {
                                  if (event.key === "Enter") event.currentTarget.blur();
                                }}
                              />
                            </label>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p className="project-group-empty">暂无项目</p>
                    )}
                  </section>
                ))}
              </div>
            ) : (
              <div className="project-home-empty">
                <span className="empty-orbit" aria-hidden="true"><i /><i /></span>
                <h2>还没有项目</h2>
                <p>在 DSH 中打开文件夹（注册为工作区）后，任务看板会自动跟随出现。</p>
              </div>
            )}
          </section>
        ) : detailTask && selectedProject ? (
          <TaskDetail
            key={detailTask.id}
            task={detailTask}
            tasks={tasks}
            currentUser={currentUser}
            availableLabels={availableLabels}
            workflows={workflowOptions}
            developmentScan={developmentScan}
            developmentScanLoading={developmentScanLoading}
            commentsRevision={commentsRevision}
            attachmentsRevision={attachmentsRevision}
            onUpdate={(current, changes) => updateTaskProperties(current, changes)}
            onOpenTask={openTaskDetail}
            onAddRelation={(current, type, relatedTaskId) => (
              mutateTaskRelation("add", current, type, relatedTaskId)
            )}
            onRemoveRelation={(current, type, relatedTaskId) => (
              mutateTaskRelation("remove", current, type, relatedTaskId)
            )}
            onOpenThread={openThread}
            onOpenInThread={openTaskInThread}
            onCopy={(content, message) => void copyText(content, message)}
            openingThread={openingThreadTaskId === detailTask.id}
            onError={(message) => setActionError(message === null ? null : typeof message === "string" ? message : message.join(" "))}
            propertiesCollapsed={propertiesCollapsed}
            onSetPropertiesCollapsed={setPropertiesCollapsed}
            onAnnounce={setAnnouncement}
            onClose={closeTaskDetail}
            onAccepted={acceptTaskFromDetail}
          />
        ) : boardView === "dashboard" ? (
          <DashboardView
            key={selectedProjectId}
            projectId={selectedProjectId}
            projectCreatedAt={selectedProject?.createdAt ?? null}
            tasks={tasks}
            presentations={taskPresentations}
            currentUser={currentUser}
            animateSummary={false}
            onSummaryAnimationStart={() => {}}
            onOpenTask={openTaskDetail}
            onOpenConversation={openTaskConversation}
          />
        ) : boardView === "list" ? (
          <IssueListView
            scrollRef={issueListRef}
            tasks={filteredTasks}
            presentations={taskPresentations}
            currentUser={currentUser}
            hasActiveFilters={hasActiveTaskFilters}
            projectNames={isGlobalView ? projectNames : undefined}
            onOpenTask={openTaskDetail}
            onOpenConversation={openTaskConversation}
            onUpdate={updateTaskProperties}
            onMoveTask={(status, taskId, beforeTaskId) => finishTaskDrop(status, taskId, beforeTaskId ?? null)}
          />
        ) : boardView === "gantt" ? (
          <Suspense fallback={<div className="workflow-board-loading">正在打开甘特图…</div>}>
            <GanttView
              tasks={filteredTasks}
              presentations={taskPresentations}
              hasActiveFilters={hasActiveTaskFilters}
              zoom={ganttZoom}
              hideCompleted={ganttHideCompleted}
              todayRequest={ganttTodayRequest}
              onOpenTask={openTaskDetail}
              onUpdate={updateTaskProperties}
            />
          </Suspense>
        ) : boardView === "workflow" ? (
          <Suspense fallback={<div className="workflow-board-loading">正在打开节点模式…</div>}>
            <WorkflowBoard
              key={selectedProject?.id ?? "local"}
              projectId={selectedProject?.id ?? "local"}
              projectName={selectedProject?.name ?? "当前项目"}
              workspacePath={
                selectedDeviceWorkspacePath
                ?? developmentScan.workspacePath
                ?? hostContext?.workspacePath
              }
              revision={workflowRevision}
              onWorkflowsChange={setWorkflowOptions}
            />
          </Suspense>
        ) : tasksLoading && !hasLoadedTasks ? (
          <div className="loading-board" aria-label="Loading issues" aria-busy="true">
            {TASK_STATUSES.map((status) => (
              <div className="loading-column" key={status}>
                <span /><div /><div />
              </div>
            ))}
          </div>
        ) : (
          <div className="board-scroll" aria-label="Issue board">
            <div className="board">
              {filteredTasks.length === 0 && tasks.length > 0 && (
                <section className="page-empty filter-empty board-filter-empty">
                  <span className="empty-search" aria-hidden="true"><LinearIcon name="search" /></span>
                  <h2>没有匹配的议题</h2>
                  <p>请更换搜索词，或移除一个筛选条件。</p>
                  <button
                    className="button secondary"
                    type="button"
                    onClick={() => { setSearch(""); setFilters(EMPTY_TASK_FILTERS); }}
                  >
                    清除筛选
                  </button>
                </section>
              )}
              {visibleLanes.map((lane) => (
                <BoardColumn
                  key={lane.id}
                  lane={lane}
                  statuses={lane.statuses}
                  tasks={laneTasks[lane.id]}
                  isCollapsed={laneCollapsed?.[lane.id] ?? lane.collapsible}
                  onToggleCollapsed={() => updateLaneCollapsed(lane.id, !(laneCollapsed?.[lane.id] ?? lane.collapsible))}
                  isDropTarget={lane.statuses.includes(dropTarget as TaskStatus)}
                  draggedTaskId={draggedTaskId}
                  draggedTaskHeight={draggedTaskHeight}
                  movingTaskId={movingTaskId}
                  settlingTaskId={settlingTaskId}
                  contextMenuTaskId={contextMenu?.taskId ?? null}
                  projectNames={isGlobalView ? projectNames : undefined}
                  canCreate={!isGlobalView}
                  onCreate={(initialStatus) => setEditor({ task: null, status: initialStatus })}
                  onEdit={openTaskDetail}
                  onContextMenu={(task, position) => setContextMenu({ taskId: task.id, ...position })}
                  onMove={(task, destination) => void moveTask(task, destination)}
                  onDragStart={(task, height) => {
                    setDraggedTaskId(task.id);
                    setDraggedTaskHeight(height);
                    setDropTarget(task.status);
                  }}
                  onDragEnd={() => {
                    setDraggedTaskId(null);
                    setDraggedTaskHeight(0);
                    setDropTarget(null);
                  }}
                  onDragEnter={setDropTarget}
                  onDrop={finishTaskDrop}
                  onOpenThread={openThread}
                  onHide={() => updateLaneVisibility(lane.id, false)}
                  onComplete={(task) => void acceptIssueFromCard(task)}
                  onUpdate={(task, changes) => updateTaskProperties(task, changes)}
                />
              ))}
              {hiddenLanes.length > 0 && (
                <HiddenColumns
                  lanes={hiddenLanes}
                  counts={Object.fromEntries(
                    BOARD_LANES.map((lane) => [lane.id, laneTasks[lane.id].length]),
                  ) as Record<BoardLaneId, number>}
                  dropTarget={dropTarget}
                  onDragTargetChange={setDropTarget}
                  onDrop={(destination, taskId) => finishTaskDrop(destination, taskId)}
                  onShow={(shownLane) => updateLaneVisibility(shownLane, true)}
                />
              )}
            </div>
          </div>
        )}
      </main>

      {editor && (
        <TaskEditor
          key={editor.task?.id ?? `new-${editor.status}-${editor.projectId ?? selectedProjectId ?? ""}`}
          task={editor.task}
          initialStatus={editor.status}
          labels={availableLabels}
          workflows={workflowOptions}
          currentUser={currentUser}
          developmentScan={developmentScan}
          developmentScanLoading={developmentScanLoading}
          onCancel={() => setEditor(null)}
          onSave={saveEditor}
        />
      )}

      {contextMenu && contextMenuTask && (
        <TaskContextMenu
          task={contextMenuTask}
          position={{ x: contextMenu.x, y: contextMenu.y }}
          labels={availableLabels}
          onClose={closeContextMenu}
          onEdit={openTaskDetail}
          onStatusChange={(task, status) => void moveTask(task, status)}
          onPriorityChange={(task, nextPriority) => void updateTaskProperties(
            task,
            { priority: nextPriority },
            `${task.identifier} 优先级已更新。`,
          ).catch(() => {})}
          onLabelsChange={(task, labels) => void updateTaskProperties(
            task,
            { labels },
            `${task.identifier} 标签已更新。`,
          ).catch(() => {})}
          onDuplicate={(task) => void duplicateTask(task)}
          onCopy={(text, message) => void copyText(text, message)}
          onOpenInThread={openTaskInThread}
          onArchive={(task) => void archiveTask(task)}
        />
      )}

      <AiChat
        available={localAiChatAvailable}
        projectId={selectedProjectId || null}
        issueId={detailTaskId}
        onThreadsChange={setAiThreads}
        openThreadRequest={aiOpenThreadRequest}
        hideLauncher={compact}
      />

      <div className="sr-only" role="status" aria-live="polite">{announcement}</div>
      {undoNotice && (
        <div
          className="toast undo-toast"
          role="status"
          onAnimationEnd={() => setUndoNotice((current) => current?.id === undoNotice.id ? null : current)}
        >
          <span className="toast-check" aria-hidden="true"><LinearIcon name="check" /></span>
          <span className="undo-toast-message">{undoNotice.message}</span>
          <button type="button" onClick={() => void performUndo()}>
            撤回 <kbd>{undoShortcut}</kbd>
          </button>
        </div>
      )}
      {announcement && (
        <div className="toast" role="status" onAnimationEnd={() => setAnnouncementValue("")}>
          <span aria-hidden="true"><LinearIcon name="check" /></span>{announcement}
        </div>
      )}
      {draggedTaskId && <div className="drag-hint" aria-hidden="true">拖到目标位置后松开</div>}
      <BuildBadge />
    </div>
    </TaskboardLanguageProvider>
  );
}

// Shows which frontend bundle is actually running. An iframe SPA keeps the
// old bundle in memory until the page reloads, so a fix that is "shipped"
// can still not be what the user sees; this badge makes that gap checkable
// from any screenshot of the board.
function BuildBadge() {
  const hash = useMemo(() => {
    const script = document.querySelector('script[type="module"][src*="index-"]');
    return script?.getAttribute("src")?.match(/index-([A-Za-z0-9_-]+)\.js/)?.[1]?.slice(0, 4) ?? null;
  }, []);
  if (!hash) return null;
  return <span className="build-badge" title={`前端构建 ${hash}`}>ui:{hash}</span>;
}
