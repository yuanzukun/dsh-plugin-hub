import type {
  ActorIdentity,
  AiChatCatalog,
  AiChatAttachmentInput,
  AiChatRun,
  AiChatSandbox,
  AiChatThread,
  AiChatThreadSnapshot,
  Attachment,
  Comment,
  DevelopmentScan,
  HostContext,
  IssueRelationType,
  Project,
  ProjectSummary,
  Task,
  TaskChangeActivity,
  TaskboardMetadata,
  TaskDraft,
  TaskStatus,
  WorkflowCapabilities,
  WorkflowWorkspaceRecord,
} from "./types";

// Re-export for component imports (SideTaskList uses type TaskDraft).
export type { TaskDraft };

const DEFAULT_USER_ACTOR: ActorIdentity = {
  type: "user",
  id: "local-user",
  name: "本地用户",
  avatarUrl: null,
};

let currentUserActor = DEFAULT_USER_ACTOR;
let apiText = (_chinese: string, english: string) => english;

export function setCurrentUserActor(actor?: ActorIdentity) {
  currentUserActor = actor?.type === "user" ? actor : DEFAULT_USER_ACTOR;
}

export function setApiText(text: typeof apiText) {
  apiText = text;
}

interface ApiErrorBody {
  error?: {
    code?: string;
    message?: string;
    details?: unknown;
  };
}

export class ApiError extends Error {
  readonly status: number;
  readonly code: string;
  readonly details?: unknown;

  constructor(status: number, body: ApiErrorBody) {
    super(body.error?.message ?? apiText(`请求失败（${status}）`, `Request failed (${status})`));
    this.name = "ApiError";
    this.status = status;
    this.code = body.error?.code ?? "REQUEST_FAILED";
    this.details = body.error?.details;
  }
}

export function resolveTaskboardUrl(path: string): string {
  return new URL(path.replace(/^\//, ""), document.baseURI).href;
}

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  const headers = new Headers(init?.headers);
  if (init?.body && !headers.has("Content-Type")) headers.set("Content-Type", "application/json");
  const method = (init?.method ?? "GET").toUpperCase();
  if (method !== "GET" && method !== "HEAD") {
    headers.set("X-Taskboard-User-Id", currentUserActor.id);
    headers.set("X-Taskboard-User-Name", encodeURIComponent(currentUserActor.name));
    if (currentUserActor.avatarUrl) {
      headers.set("X-Taskboard-User-Avatar", currentUserActor.avatarUrl);
    }
  }

  let response: Response;
  try {
    response = await fetch(resolveTaskboardUrl(path), { ...init, headers });
  } catch (error) {
    if (error instanceof Error && error.name === "AbortError") throw error;
    throw new ApiError(0, {
      error: {
        code: "SERVICE_UNAVAILABLE",
        message: apiText(
          "无法连接本地 Taskboard 服务，请重新通过 Taskboard 启动服务。",
          "Could not connect to the local Taskboard service. Start the service again.",
        ),
      },
    });
  }
  let body: T & ApiErrorBody;
  try {
    body = (await response.json()) as T & ApiErrorBody;
  } catch (error) {
    if ((error as Error).name === "AbortError") throw error;
    body = {} as T & ApiErrorBody;
  }

  if (!response.ok) throw new ApiError(response.status, body);
  return body;
}

export async function listProjects(signal?: AbortSignal): Promise<Project[]> {
  const data = await request<{ projects: Project[] }>("/api/projects", { signal });
  return data.projects;
}

export async function getProjectSummary(
  projectId: string,
  signal?: AbortSignal,
): Promise<ProjectSummary> {
  return request<ProjectSummary>(
    `/api/local/projects/${encodeURIComponent(projectId)}/summary`,
    { signal },
  );
}

export async function getTaskboardMetadata(signal?: AbortSignal): Promise<TaskboardMetadata> {
  return request<TaskboardMetadata>("/api/meta", { signal });
}

export async function getTaskboardRevision(
  since: number,
  signal?: AbortSignal,
): Promise<{ changed: boolean; revision: number }> {
  const query = new URLSearchParams({ since: String(since) });
  return request<{ changed: boolean; revision: number }>(`/api/revisions?${query}`, { signal });
}

export async function getHostRuntime(signal?: AbortSignal): Promise<HostContext | null> {
  const data = await request<{
    runtime: (Pick<HostContext, "threadId" | "threadRunning" | "threadTodoProgress"> & {
      updatedAt: number;
    }) | null;
  }>("/api/local/host-runtime", { signal });
  return data.runtime;
}

export async function publishHostRuntime(context: HostContext): Promise<void> {
  if (!context.threadId || context.threadRunning === undefined) return;
  await request("/api/local/host-runtime", {
    method: "PUT",
    body: JSON.stringify({
      threadId: context.threadId,
      threadRunning: context.threadRunning,
      threadTodoProgress: context.threadTodoProgress ?? null,
    }),
  });
}

export async function getAiChatCatalog(
  projectId: string,
  signal?: AbortSignal,
): Promise<AiChatCatalog> {
  return request<AiChatCatalog>(
    `/api/local/ai/catalog?projectId=${encodeURIComponent(projectId)}`,
    { signal },
  );
}

export async function listAiChatThreads(signal?: AbortSignal): Promise<AiChatThread[]> {
  const data = await request<{ threads: AiChatThread[] }>("/api/local/ai/threads", { signal });
  return data.threads;
}

export async function createAiChatThread(input: {
  projectId: string;
  issueId?: string;
  title?: string;
  model?: string;
  reasoningEffort?: string;
  sandbox?: AiChatSandbox;
}): Promise<AiChatThread> {
  const data = await request<{ thread: AiChatThread }>("/api/local/ai/threads", {
    method: "POST",
    body: JSON.stringify(input),
  });
  return data.thread;
}

export async function getAiChatThread(
  threadId: string,
  signal?: AbortSignal,
): Promise<AiChatThreadSnapshot> {
  return request<AiChatThreadSnapshot>(
    `/api/local/ai/threads/${encodeURIComponent(threadId)}`,
    { signal },
  );
}

export async function updateAiChatThread(
  threadId: string,
  input: {
    title?: string;
    model?: string;
    reasoningEffort?: string;
    sandbox?: AiChatSandbox;
  },
): Promise<AiChatThread> {
  const data = await request<{ thread: AiChatThread }>(
    `/api/local/ai/threads/${encodeURIComponent(threadId)}`,
    {
      method: "PATCH",
      body: JSON.stringify(input),
    },
  );
  return data.thread;
}

export async function deleteAiChatThread(threadId: string): Promise<void> {
  await request<void>(
    `/api/local/ai/threads/${encodeURIComponent(threadId)}`,
    { method: "DELETE" },
  );
}

export async function startAiChatTurn(
  threadId: string,
  input: {
    message: string;
    skillIds?: string[];
    attachments?: AiChatAttachmentInput[];
    dangerFullAccessConfirmed?: boolean;
  },
): Promise<AiChatRun> {
  const data = await request<{ run: AiChatRun }>(
    `/api/local/ai/threads/${encodeURIComponent(threadId)}/turns`,
    {
      method: "POST",
      body: JSON.stringify(input),
    },
  );
  return data.run;
}

export async function interruptAiChatRun(runId: string): Promise<AiChatRun> {
  const data = await request<{ run: AiChatRun }>(
    `/api/local/ai/runs/${encodeURIComponent(runId)}/interrupt`,
    { method: "POST" },
  );
  return data.run;
}

export function subscribeAiChatThread(
  threadId: string,
  onHint: (type: "ai.event" | "ai.run") => void,
  onError?: () => void,
): () => void {
  const source = new EventSource(
    resolveTaskboardUrl(`/api/local/ai/threads/${encodeURIComponent(threadId)}/events`),
  );
  source.addEventListener("ai.event", () => onHint("ai.event"));
  source.addEventListener("ai.run", () => onHint("ai.run"));
  if (onError) source.addEventListener("error", onError);
  return () => source.close();
}

export interface AutomationStateView {
  enabled: boolean;
  intervalMinutes: number | null;
  model: string | null;
  lastClaimAt: number | null;
  /** 'new' per round · 'fixed' one chosen conversation · 'task' the issue's own. */
  sessionMode?: "new" | "fixed" | "task";
  /** The chosen conversation while sessionMode is 'fixed'. */
  sessionId?: string | null;
  /** Rounds delivered into that conversation (rotation counter). */
  sessionTurns?: number;
}

export interface AutomationUpdateInput {
  enabled: boolean;
  intervalMinutes?: number;
  automationModel?: string | null;
  sessionMode?: "new" | "fixed" | "task";
  sessionId?: string | null;
  sessionTurns?: number;
}

/** One candidate conversation for the fixed-session setting. */
export interface ClaimSessionInfo {
  sessionId: string;
  startedAt: number | null;
  status: string | null;
  /** Rounds already delivered into this conversation. */
  rounds: number;
  digest: string | null;
}

/** 本项目历史承接会话（固定对话模式的候选，来自运行记录）。 */
export async function listClaimSessions(
  projectId: string,
  signal?: AbortSignal,
): Promise<ClaimSessionInfo[]> {
  const data = await request<{ sessions: ClaimSessionInfo[] }>(
    `/api/projects/${encodeURIComponent(projectId)}/claim-sessions`,
    { signal },
  );
  return data.sessions;
}

/** 认领模型目录（host 半从 ctx.llm 枚举全部 provider 写入 models.json）。 */
export interface ClaimModelCatalog {
  providers: { provider: string; label?: string; models: string[] }[];
  updatedAt: string;
}

export async function getClaimModels(signal?: AbortSignal): Promise<ClaimModelCatalog> {
  return request<ClaimModelCatalog>("/api/automation/models", { signal });
}

/** 最近一次例程运行记录（来自 dsh-routines 的 runs/ 目录）。 */
export interface RoutineRunInfo {
  status: string | null;
  startedAt: number | null;
  finishedAt: number | null;
  durationMs: number | null;
  exitCode: number | null;
  error: string | null;
  digest: string | null;
  sessionId: string | null;
  /** 认领前置检查（check gate）的摘要，skipped/failed 时存在。 */
  check?: {
    command?: string;
    todoCount?: number;
    timedOut?: boolean;
  } | null;
}

/** 一条例程：YAML 字段 + 最近运行。 */
export interface RoutineInfo {
  name: string;
  schedule?: string;
  timezone?: string;
  prompt?: string;
  cwd?: string;
  profile?: string;
  overlap?: string;
  timeoutMin?: string;
  deliver?: string[];
  paused?: boolean;
  source?: string;
  nextRunAt?: number | null;
  raw?: string;
  unknownKeys?: string[];
  lastRun?: RoutineRunInfo | null;
}

export interface RoutineCreateInput {
  name: string;
  schedule: string;
  timezone?: string;
  prompt: string;
  cwd?: string;
  profile?: string;
  overlap?: string;
  timeoutMin?: number;
  deliver?: string[];
}

/** 一条历史运行记录（/api/routines/:name/runs，按开始时间倒序）。 */
export interface RoutineRunRecord {
  runId?: string;
  routine?: string;
  status?: string | null;
  startedAt?: number | null;
  finishedAt?: number | null;
  durationMs?: number | null;
  exitCode?: number | null;
  error?: string | null;
  digest?: string | null;
  sessionId?: string | null;
}

/** 读取一个例程的运行历史（新→旧，最多 30 条）。 */
export async function getRoutineRuns(name: string, signal?: AbortSignal): Promise<{ runs: RoutineRunRecord[] }> {
  return request(`/api/routines/${encodeURIComponent(name)}/runs`, { signal });
}

/** 新建例程（写入 ~/.dsh/routines/<name>.yaml）。 */
export async function createRoutine(input: RoutineCreateInput): Promise<{ name: string }> {
  const data = await request<{ routine: { name: string } }>("/api/routines", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(input),
  });
  return data.routine;
}

/** 更新例程：传 raw（全文）或结构化字段（含 paused 开关）。 */
export async function updateRoutine(
  name: string,
  input: { raw: string } | (Partial<Omit<RoutineCreateInput, "name">> & { paused?: boolean }),
): Promise<{ updated: string }> {
  return request(`/api/routines/${encodeURIComponent(name)}`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(input),
  });
}

/** 测试执行：立即手动触发一次该例程（不等待完成，运行记录稍后出现在列表中）。
 * started 为 null 表示本轮被门控拦下（如认领例程无待认领议题），没有真正起跑。 */
export async function runRoutine(name: string): Promise<{ started: string | null; mode?: string }> {
  return request(`/api/routines/${encodeURIComponent(name)}/run`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({}),
  });
}

/** 删除例程文件。 */
/** 停止正在运行的例程（认领例程走进程内 handler）。 */
export async function stopRoutine(name: string): Promise<{ stopped: string | null }> {
  return request(`/api/routines/${encodeURIComponent(name)}/stop`, { method: "POST" });
}

export async function deleteRoutine(name: string): Promise<{ deleted: string }> {
  return request(`/api/routines/${encodeURIComponent(name)}`, { method: "DELETE" });
}

/** 读取 dsh-routines 列表（例程 YAML + 最近运行记录）。 */
export async function getRoutines(signal?: AbortSignal): Promise<{
  routinesDirectory: string | null;
  routines: RoutineInfo[];
}> {
  return request("/api/routines", { signal });
}

/** 读取项目自动认领状态（配置存看板数据库，由 DSH 原生 claim-sweep 作业驱动）。 */
export async function getProjectAutomation(
  projectId: string,
  signal?: AbortSignal,
): Promise<AutomationStateView> {
  const data = await request<{ automation: AutomationStateView }>(
    `/api/projects/${encodeURIComponent(projectId)}/automation`,
    { signal },
  );
  return data.automation;
}

/** 写入项目自动认领开关（启用后 DSH claim-sweep 作业按间隔驱动认领会话）。 */
export async function updateProjectAutomation(
  projectId: string,
  input: AutomationUpdateInput,
  signal?: AbortSignal,
): Promise<AutomationStateView> {
  const data = await request<{ automation: AutomationStateView }>(
    `/api/projects/${encodeURIComponent(projectId)}/automation`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(input),
      signal,
    },
  );
  return data.automation;
}

/** 从看板内启动 dsh 心跳 runner（launchd 优先，退化为主机后台拉起）。 */
export async function startHeartbeatRunner(): Promise<{
  started: boolean;
  pid: number | null;
  method?: string;
}> {
  return request<{ started: boolean; pid: number | null; method?: string }>(
    "/api/automation/heartbeat/start",
    { method: "POST" },
  );
}

export async function listDeviceWorkspaces(signal?: AbortSignal): Promise<Record<string, string>> {
  try {
    const data = await request<{ workspaces: Record<string, string> }>("/api/device-workspaces", { signal });
    return data.workspaces;
  } catch (error) {
    if (error instanceof ApiError && error.code === "LOCAL_COMPANION_REQUIRED") return {};
    throw error;
  }
}

export async function listWorkflowCapabilities(
  workspacePath?: string,
  signal?: AbortSignal,
): Promise<WorkflowCapabilities> {
  const query = new URLSearchParams();
  if (workspacePath) query.set("workspacePath", workspacePath);
  const suffix = query.size > 0 ? `?${query}` : "";
  return request<WorkflowCapabilities>(`/api/workflow-capabilities${suffix}`, { signal });
}

export async function getWorkflowWorkspace<T>(
  projectId: string,
  signal?: AbortSignal,
): Promise<WorkflowWorkspaceRecord<T>> {
  const data = await request<{ workflow: WorkflowWorkspaceRecord<T> }>(
    `/api/projects/${encodeURIComponent(projectId)}/workflow-workspace`,
    { signal },
  );
  return data.workflow;
}

export async function saveWorkflowWorkspace<T>(
  projectId: string,
  workspace: T,
  version: number,
): Promise<WorkflowWorkspaceRecord<T>> {
  const data = await request<{ workflow: WorkflowWorkspaceRecord<T> }>(
    `/api/projects/${encodeURIComponent(projectId)}/workflow-workspace`,
    {
      method: "PUT",
      body: JSON.stringify({ version, workspace }),
    },
  );
  return data.workflow;
}

export async function createProject(input: {
  id: string;
  name: string;
  workspacePath: string | null;
}): Promise<Project> {
  const data = await request<{ project: Project }>("/api/projects", {
    method: "POST",
    body: JSON.stringify(input),
  });
  return data.project;
}

export async function deleteProject(projectId: string): Promise<void> {
  await request(`/api/projects/${encodeURIComponent(projectId)}`, {
    method: "DELETE",
  });
}

export async function listDevelopmentContexts(
  projectId: string,
  codexProjectId?: string,
  codexThreadId?: string,
  signal?: AbortSignal,
  workspacePath?: string,
): Promise<DevelopmentScan> {
  const query = new URLSearchParams();
  if (codexProjectId) query.set("codexProjectId", codexProjectId);
  if (codexThreadId) query.set("codexThreadId", codexThreadId);
  if (workspacePath) query.set("workspacePath", workspacePath);
  const suffix = query.size > 0 ? `?${query}` : "";
  return request<DevelopmentScan>(
    `/api/projects/${encodeURIComponent(projectId)}/development-contexts${suffix}`,
    { signal },
  );
}

/** 「全局」项目的固定 id：不对应任何工作目录，仅作为聚合视图加载所有项目的议题。 */
export const GLOBAL_PROJECT_ID = "local";

export function isGlobalProjectId(projectId: string): boolean {
  return projectId === GLOBAL_PROJECT_ID;
}

async function listTasksByArchive(
  projectId: string,
  archived: "true" | "false",
  signal?: AbortSignal,
): Promise<Task[]> {
  const params = new URLSearchParams({ archived });
  // 「全局」视图：不带 projectId，聚合加载所有项目的议题（服务端已支持省略该参数）。
  if (!isGlobalProjectId(projectId)) params.set("projectId", projectId);
  const data = await request<{ tasks: Task[] }>(`/api/tasks?${params}`, { signal });
  return data.tasks;
}

export function listTasks(projectId: string, signal?: AbortSignal): Promise<Task[]> {
  return listTasksByArchive(projectId, "false", signal);
}

export function listArchivedTasks(projectId: string, signal?: AbortSignal): Promise<Task[]> {
  return listTasksByArchive(projectId, "true", signal);
}

export async function createTask(projectId: string, draft: TaskDraft, threadId?: string): Promise<Task> {
  const data = await request<{ task: Task }>("/api/tasks", {
    method: "POST",
    body: JSON.stringify({ projectId, ...draft, ...(threadId ? { threadId } : {}) }),
  });
  return data.task;
}

export async function updateTask(task: Task, draft: TaskDraft, threadId?: string): Promise<Task> {
  const data = await request<{ task: Task }>(`/api/tasks/${encodeURIComponent(task.id)}`, {
    method: "PATCH",
    body: JSON.stringify({ version: task.version, ...draft, ...(threadId ? { threadId } : {}) }),
  });
  return data.task;
}

export async function moveTask(
  task: Task,
  status: TaskStatus,
  sortOrder: number,
  threadId?: string,
): Promise<Task> {
  const data = await request<{ task: Task }>(
    `/api/tasks/${encodeURIComponent(task.id)}/move`,
    {
      method: "POST",
      body: JSON.stringify({ version: task.version, status, sortOrder, ...(threadId ? { threadId } : {}) }),
    },
  );
  return data.task;
}

export async function archiveTask(task: Task, threadId?: string): Promise<Task> {
  const data = await request<{ task: Task }>(
    `/api/tasks/${encodeURIComponent(task.id)}/archive`,
    {
      method: "POST",
      body: JSON.stringify({ version: task.version, ...(threadId ? { threadId } : {}) }),
    },
  );
  return data.task;
}

export async function restoreTask(task: Task, threadId?: string): Promise<Task> {
  const data = await request<{ task: Task }>(
    `/api/tasks/${encodeURIComponent(task.id)}/restore`,
    {
      method: "POST",
      body: JSON.stringify({ version: task.version, ...(threadId ? { threadId } : {}) }),
    },
  );
  return data.task;
}

export async function deleteArchivedTask(task: Task): Promise<void> {
  await request(`/api/tasks/${encodeURIComponent(task.id)}`, {
    method: "DELETE",
    body: JSON.stringify({ version: task.version }),
  });
}

export async function addTaskRelation(
  task: Task,
  type: IssueRelationType,
  relatedTaskId: string,
  threadId?: string,
): Promise<{ task: Task; relatedTask: Task }> {
  return request<{ task: Task; relatedTask: Task }>(
    `/api/tasks/${encodeURIComponent(task.id)}/relations/${type}/${encodeURIComponent(relatedTaskId)}`,
    {
      method: "POST",
      body: JSON.stringify({ version: task.version, ...(threadId ? { threadId } : {}) }),
    },
  );
}

export async function removeTaskRelation(
  task: Task,
  type: IssueRelationType,
  relatedTaskId: string,
  threadId?: string,
): Promise<{ task: Task; relatedTask: Task }> {
  return request<{ task: Task; relatedTask: Task }>(
    `/api/tasks/${encodeURIComponent(task.id)}/relations/${type}/${encodeURIComponent(relatedTaskId)}`,
    {
      method: "DELETE",
      body: JSON.stringify({ version: task.version, ...(threadId ? { threadId } : {}) }),
    },
  );
}

export async function listComments(taskId: string, signal?: AbortSignal): Promise<Comment[]> {
  const data = await request<{ comments: Comment[] }>(
    `/api/tasks/${encodeURIComponent(taskId)}/comments`,
    { signal },
  );
  return data.comments;
}

export async function listTaskActivities(
  taskId: string,
  signal?: AbortSignal,
): Promise<TaskChangeActivity[]> {
  const data = await request<{ activities: TaskChangeActivity[] }>(
    `/api/tasks/${encodeURIComponent(taskId)}/activities`,
    { signal },
  );
  return data.activities;
}

export async function createComment(taskId: string, body: string, threadId?: string): Promise<Comment> {
  const data = await request<{ comment: Comment }>(
    `/api/tasks/${encodeURIComponent(taskId)}/comments`,
    {
      method: "POST",
      body: JSON.stringify({ body, ...(threadId ? { threadId } : {}) }),
    },
  );
  return data.comment;
}

/**
 * The acceptance gate, shared by every entry point (detail banner, board
 * card). The status flip lands first — `done` is outside the dispatch gate,
 * so the acceptance message can never be mistaken for a "keep going" order —
 * then the acceptance message is posted in the user's own voice.
 */
export async function acceptIssue(task: Task, message: string): Promise<Comment> {
  const data = await request<{ task: Task }>(`/api/tasks/${encodeURIComponent(task.id)}`, {
    method: "PATCH",
    body: JSON.stringify({ version: task.version, status: "done" }),
  });
  return createComment(data.task.id, message);
}

export async function updateComment(comment: Comment, body: string, threadId?: string): Promise<Comment> {
  const data = await request<{ comment: Comment }>(
    `/api/comments/${encodeURIComponent(comment.id)}`,
    {
      method: "PATCH",
      body: JSON.stringify({ version: comment.version, body, ...(threadId ? { threadId } : {}) }),
    },
  );
  return data.comment;
}

/**
 * 干一轮：零输入、全状态的显式派发（ADR-0001）。忙碌时服务端抛
 * `DISPATCH_BUSY` 的 ApiError（409），调用方据它把按钮切到「Agent 进行中」。
 */
export async function dispatchIssue(taskId: string): Promise<void> {
  await request<{ task: Task; dispatch: { started: boolean } }>(
    `/api/tasks/${encodeURIComponent(taskId)}/dispatch`,
    { method: "POST" },
  );
}

/**
 * 取消正在跑的那一轮。人不必等 60 分钟租约过期才能纠正跑错方向的一轮。
 * 没有活轮次时服务端回 409 `NOT_RUNNING`。
 */
export async function cancelIssueRound(taskId: string): Promise<void> {
  await request<{ task: Task; canceled: { sessionId: string } }>(
    `/api/tasks/${encodeURIComponent(taskId)}/cancel`,
    { method: "POST" },
  );
}

export async function fetchDispatchState(taskId: string, signal?: AbortSignal): Promise<boolean> {
  const data = await request<{ dispatch: { busy: boolean } }>(
    `/api/tasks/${encodeURIComponent(taskId)}/dispatch`,
    { signal },
  );
  return data.dispatch.busy;
}

export async function deleteComment(comment: Comment, threadId?: string): Promise<void> {
  await request(`/api/comments/${encodeURIComponent(comment.id)}`, {
    method: "DELETE",
    body: JSON.stringify({ version: comment.version, ...(threadId ? { threadId } : {}) }),
  });
}

export async function listAttachments(taskId: string, signal?: AbortSignal): Promise<Attachment[]> {
  const data = await request<{ attachments: Attachment[] }>(
    `/api/tasks/${encodeURIComponent(taskId)}/attachments`,
    { signal },
  );
  return data.attachments;
}

export async function uploadAttachment(taskId: string, file: File): Promise<Attachment> {
  const data = await request<{ attachment: Attachment }>(
    `/api/tasks/${encodeURIComponent(taskId)}/attachments`,
    {
      method: "POST",
      headers: {
        "Content-Type": file.type || "application/octet-stream",
        "X-Taskboard-Filename": encodeURIComponent(file.name),
      },
      body: file,
    },
  );
  return data.attachment;
}

export async function uploadCommentAttachment(commentId: string, file: File): Promise<Attachment> {
  const data = await request<{ attachment: Attachment }>(
    `/api/comments/${encodeURIComponent(commentId)}/attachments`,
    {
      method: "POST",
      headers: {
        "Content-Type": file.type || "application/octet-stream",
        "X-Taskboard-Filename": encodeURIComponent(file.name),
      },
      body: file,
    },
  );
  return data.attachment;
}

export async function deleteAttachment(attachment: Attachment): Promise<void> {
  await request(`/api/attachments/${encodeURIComponent(attachment.id)}`, {
    method: "DELETE",
  });
}

export function attachmentContentUrl(attachment: Attachment): string {
  return `api/attachments/${encodeURIComponent(attachment.id)}/content`;
}

export function attachmentDownloadUrl(attachment: Attachment): string {
  // The server only exposes /content — there is no /download route, so the
  // previous URL here made every attachment download fail with
  // 404 "API route not found". The filename is kept via the <a download>
  // attribute in downloadAttachmentFile.
  return attachmentContentUrl(attachment);
}

export function resolvePersistedAttachmentUrl(value: string): string {
  if (/^\/?api\/attachments\/[^/?#]+\/content$/.test(value)) {
    return resolveTaskboardUrl(value);
  }
  try {
    const url = new URL(value);
    const match = url.pathname.match(/\/api\/attachments\/([^/]+)\/content$/);
    if (url.protocol === "http:" && url.hostname === "127.0.0.1" && match) {
      return resolveTaskboardUrl(`/api/attachments/${match[1]}/content`);
    }
  } catch {
    return value;
  }
  return value;
}

export function markdownIncludesAttachment(markdown: string, attachment: Attachment): boolean {
  return markdown.includes(`api/attachments/${encodeURIComponent(attachment.id)}/content`);
}

const ATTACHMENT_PATH_PATTERN = /\/api\/attachments\/([^/?#]+)(?:\/content)?$/;
const ATTACHMENT_ID_PATTERN = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

/** True when the value points into the attachment content namespace. */
export function isAttachmentUrl(value: string): boolean {
  try {
    return ATTACHMENT_PATH_PATTERN.test(new URL(value, document.baseURI).pathname);
  } catch {
    return false;
  }
}

/**
 * The attachment id a persisted attachment URL names, or null when the id is
 * one no upload could have produced — prose placeholders like `…` or `<id>`
 * written as markdown examples. Such URLs can never load, so callers render
 * them as the literal markup they are instead of requesting them.
 */
export function attachmentUrlId(value: string): string | null {
  let pathname: string;
  try {
    pathname = new URL(value, document.baseURI).pathname;
  } catch {
    return null;
  }
  const match = pathname.match(ATTACHMENT_PATH_PATTERN);
  if (!match) return null;
  const id = decodeURIComponent(match[1]);
  return ATTACHMENT_ID_PATTERN.test(id) ? id : null;
}
